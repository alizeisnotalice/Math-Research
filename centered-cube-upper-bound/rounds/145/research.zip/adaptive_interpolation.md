# R145：先付 H 包络再作零阶插值的自适应价格

状态：得到保留实际零阶接收质量的自适应界，以及可完整回代原低核门的真实 w 版本。与同一零阶锚、同一固定节点矩帽相比，H 费用从 1+nθ log(b/a) 改为 [1+nθ₀ log(b/a)]^{θ/θ₀}。这个费用比较严格成立；实际零阶质量、来源负矩、q/e 与跨单元价格尚未付款，不声称一般根阶闭合。仅写本文件，不改他人文件，不 Git/PDF。

## AI1. 历史定位与先行候选

已读取 R136 FK4–5/FKA、R144 softscale/capacity、R142 JR 单元，以及历史代理定位的 R137 interpolation_audit.md IA3、normalized_capacity.md NC3–4。R137 IA2 已有固定概率核的 (C_uC_v)^{1−4θ}M_*^{4nθ}；NC9–14 已有真实 w 零阶锚定及其 posterior 负权。本文不重证或登记这些基本插值为新成果。新增组合是：在正端点 θ₀ 先应用 R144 的实际 H 选择器包络，再相对实际零阶接收测度插值；并给自适应 s,L,R 单元的完整转接。

固定原 ξ=(ω,V,j,y,t)、同一 ν 及真实来源 z,u,v。令 0<θ₀<1/3 固定，0≤θ≤θ₀，r=θ/θ₀。b/2≤a≤L(x),H(x),R(x)≤b；H 保持任意实际可测选择器。选定事先给定、不依来源重选的 s,L,R 单元 C，沿用 JR5：

\[
\kappa_s=1+s_+-s_-,\quad \widetilde s=s_+/\kappa_s,
\quad E_{p,C}=(\kappa_s L_+/L_-)^n,\quad E_{R,C}=(R_+/R_-)^n,
\]
\[
\overline P_C(x-y)=\prod_iL_+^{-1}p_{\widetilde s}((x_i-y_i)/L_+),
\qquad p_x\le E_{p,C}\overline P_C,
\tag{AI1}
\]

其中 \overline P_C dx 是归一概率测度；实际选择器 p_x dx 不是。单元采用事前固定的半开网格、末格含右端点，形成实际参数的不交可测分区；若改用重叠覆盖，后文单元求和必须保留覆盖重数。设

\[
\mathcal C_y(u)=\prod_i C(|u_i-y_i|/b),\quad
\mathcal C_y(v)=\prod_i C(|v_i-y_i|/b),\quad 0<\mathcal C_y\le1,
\]
\[
\underline K_{C,H}(x-u)=\prod_iH^{-1}
\{(1-s_+)1_{|x_i-u_i|\le H/2}+s_-\phi((x_i-u_i)/H)\}.
\tag{AI2}
\]

实际 K_{s(x),H(x)}≥\underline K_{C,H(x)}，s_->0。令 Ω_C 为合法接收域与实际单元交集，任意 0≤m(x)≤1 均按实际参数取值，可包含原 good、low、Ψ、FA、history、ρ、hard 盒指示；m 不随插值指数重新定义。记

\[
Z_C=\int_{Ω_C}p_xm(x)dx\le E_{p,C},
\quad L_H=\log(b/a),\quad D_H(θ₀)=1+nθ₀L_H.
\]

**先行候选**（已先发 Sol 独立审查）是

\[
\begin{aligned}
&\int_{Ω_C}p_xm(x)
\frac{\mathcal C_y(u)\mathcal C_y(v)^{1+θ}}
 {[\underline K_{C,H(x)}(x-u)J_b(x-v)]^θ}dx\\
&\quad\le
[\mathcal C_y(u)\mathcal C_y(v)Z_C]^{1-r}
 E_{p,C}^{r}\,b^{2nθ}M_{θ₀,s_-}^{nr}D_H(θ₀)^r.
\end{aligned}
\tag{AI3}
\]

θ=0 按准确零阶值解释；Z_C=0 时全部积分为零，避免端点 0⁰。另有单端 H 版本，将 D_H(θ₀)^r 替换为 (b/a)^{nθ}。这两个完整上界在接收积分后比较；不在 x 上逐点优化 θ 或冻结 H 后再冒用乘积积分。

初探：θ=0、H=a、单元退化时式子分别返回真实零阶质量、端点核与固定参数。已有压力：Z_C 可大于1，α 可趋0、ν 无坐标独立性、来源逆矩仍须支付。扩大范围：下述证明覆盖所有单元内可测 s,L,R,H、hard 跳面、任意相关 ν 与全部实际门。本文未运行数值实验，不作数值认证声明。

## AI2. 正端点的单元核矩与 H 累积

本节仅说明已有 FK4 证明在单元上下包络之间如何合法转移，不重证固定参数零阶插值。

在固定 H 节点，分母有纯 soft 下界

\[
\underline K_{C,H}(x-u)\ge s_-^n\prod_i H^{-1}\phi((x_i-u_i)/H).
\tag{AI4}
\]

\overline P_C 的 soft 参数为 \widetilde s，通常不等于 s_-，所以下式不是直接扩大原 FK4 命题的量词。逐行检查 FK2–5 的证明可见：分母仅用 (s_-/H)φ；分子仅用一个 L_+/b∈[1/2,1] 的 hard/soft 混合概率，其 hard 与 soft 接收矩帽分别统一于混合参数。故同一已审常数仍给

\[
\int\overline P_C
\frac{\mathcal C_y(u)\mathcal C_y(v)^{1+θ₀}}
 {[\underline K_{C,H}J_b]^ {θ₀}}dx
\le b^{2nθ₀}M_{θ₀,s_-}^{n}.
\tag{AI5}
\]

这里

\[
M_{θ₀,s_-}=A_{θ₀}s_-^{-θ₀},\quad
A_{θ₀}=C_0^{2+θ₀}a_0^{-2θ₀}
\left[e^{3θ₀/2}(3/2)^{2θ₀}+\frac{2A_0}{1-3θ₀}\right]
\tag{AI6}
\]

完全沿用 FK5。也可先把下核归一化为质量 ζ=1-s_++s_- 的混合核；其分母 soft 参数 s_-/ζ，逆核归一费 ζ^{-nθ₀} 与 M 中的 ζ^{nθ₀} 正好抵消，不能另丢掉或重复算一次 ζ。该核本身的质量 ζ^n 不等于1。

R144 SS2 给 f_H=\underline K_{C,H}^{-θ₀} 的单侧式

\[
f_{H(x)}\le f_a+nθ₀\int_a^b1_{\{H(x)\ge h\}}f_h\,\frac{dh}{h}.
\tag{AI7}
\]

将它乘实际非负 p_xm\mathcal C_u\mathcal C_v^{1+θ₀}J_b^{-θ₀}，保留实际 m；只在上界中删除 H(x)≥h 与 m，使用 p_x≤E_p\overline P_C 和 AI5。得到**同一整个实际接收积分**的端点帽

\[
I_{θ₀,C}^{ad}\le E_{p,C}b^{2nθ₀}M_{θ₀,s_-}^n
[1+nθ₀\log(b/a)].
\tag{AI8}
\]

原 hard 跳面使 f 向下跳，AI7 的方向不变。单端选择 f_{H(x)}≤(b/a)^{nθ₀}f_a 给相应端点帽。全过程没有把实际 H 固定成某个节点，也不要求选择器是停止时。

对实际有限测度 p_xm1_{Ω_C}dx 作零阶 Hölder：本积分是 \mathcal C_u\mathcal C_v 乘同一非负函数的 θ 次矩，零阶准确为 \mathcal C_u\mathcal C_vZ_C。把 AI8 仅在正端点代入即得 AI3。这一使用不要求实际测度质量为1。

## AI3. 哪些费用确实变小，哪些没有

令共同节点端点帽、实际 Z_C 与来源 u,v 全部保持相同。若先在每个固定 H 节点插值，再在 θ 处调用 R144 H 连续式，得到的 H 费是 1+nθL_H；本文顺序给

\[
\boxed{[1+nθ₀L_H]^r\le1+nθL_H\le e^{nθL_H}=(b/a)^{nθ}.}
\tag{AI9}
\]

首个不等式来自 0≤r≤1 的幂凹性；在 0<θ<θ₀、L_H>0 时严格。故对同一真实锚和同一来源系数，本文完整右端确实较小，不只是少写一个 H 菜单。若 θ=c/n、θ₀ 固定、a≤b≤2a，则新费

\[
D_H(θ₀)^r=\exp\!\left(\frac{c}{nθ₀}\log[1+nθ₀L_H]\right)
=1+O_{c,θ₀}(\log n/n),
\tag{AI10}
\]

而先插值再包络的粗费为 1+cL_H，单端粗费为 e^{cL_H}。这只是 H 部分的费用比较，不是原总费用趋1。

对于核常数与来源尾，AI3 给

\[
M_{θ₀,s_-}^{nr}=A_{θ₀}^{nθ/θ₀}s_-^{-nθ},\qquad
[\mathcal C_u\mathcal C_v]^{1-r}.
\tag{AI11}
\]

因此 θ=c/n 时核常数是 A_{θ₀}^{c/θ₀}s_-^{-c}；保留 C_uC_v 的接近一次幂，无需再把每个 C 用 C₀e^{-|u|}/(1+|u|) 上界而制造 C₀^{2n}。若 s_- 接近原下门 s_min=1−2^{-1/n}，则 s_-^{-c}=O_c(n^c)，并非统一常数。若只想令这一软度因子有界，可取 θ=O(1/(n log n))；相应低门幂也进一步减弱。

E_p 的地位不同：准确式为 Z_C^{1-r}E_p^r。若将 Z_C≤E_p 粗化，则两者恢复 E_p，不能宣称上包络质量也只付 E_p^r。标准窄单元有 E_p≤γ^{2n}、E_R≤γ^n，属于单元常数；尚有 s,L,R 全菜单及其实际质量。θ=0 时 AI3 返回 C_uC_vZ_C；仅固定归一概率核、m=1、全空间积分时才能写成 C_uC_v。

## AI4. 带 hard 来源的测度与真实 w 端点

为回原交通，改用物理 hard 测度，避免把 hard 费藏成概率。令 m_ξ(x;z,u,v)∈[0,1] 包含原实际 good/bad、原低核门、Ψ、FA、history、合法窗口和旧已付补集，并把原 ρ_v(x) 单列：

\[
d\mu_C(x)=1_{Ω_C}p_xh_{R(x)}(x-z)m_\xi(x;z,u,v)\rho_v(x)dx,
\quad Z_C^{hard}=\mu_C(\mathbb R^n),
\]
\[
S_C=E_{p,C}E_{R,C}R_+^{-n},\qquad Z_C^{hard}\le S_C.
\tag{AI12}
\]

ρ 使用原共同 α=R_x/Q_J(x)，未重新分配储备；所有门按实际参数取值。hard 支持与原门完整留在 Z_C^{hard}。正端点只用 h_R≤E_RR_+^{-n}1_{Q_{R_+}(z)}≤E_RR_+^{-n}，故 AI3 的测度版用 Z_C^{hard},S_C 替换 Z_C,E_p 即成立。该式仍是对真实 dx 的估计。

若先把两份真实 w 在所有 θ 上都粗化，原 κ^{2n} 会留在零阶；R137 NC9 已指出应只在正端点粗化。本节沿用其机制但保留本轮的实际测度与 H 包络。设 w_u=w_t(y,u)、w_v=w_t(y,v)、κ=b/(c_jt)，定义低门所需的真实双来源矩

\[
F_{θ,C}^{ad}=\int d\mu_C(x)\,
w_u^{1+θ}w_v\frac{A_v(x)^θ}{[K_{s(x),H(x)}(x-u)J_b(x-v)]^θ}.
\tag{AI13}
\]

实际 A_v(x) 可变，仍有原 A_v≤w_{τ_j}、

\[
w_u\le κ^n\mathcal C_u,\qquad
w_vA_v(x)^{θ₀}\le κ^n(b/a)^{nθ₀}\mathcal C_v^{1+θ₀}.
\tag{AI14}
\]

只在 θ₀ 端拆出 w_u^{θ₀}，使用 AI14、AI8 与 AI12，得

\[
F_{θ₀,C}^{ad}\le w_u^{θ₀}κ^{2n}(b/a)^{nθ₀}
S_Cb^{2nθ₀}M_{θ₀,s_-}^nD_H(θ₀).
\tag{AI15}
\]

零阶准确为 w_uw_vZ_C^{hard}。由于 AI13 对同一实际测度是 (w_uA_v/(K_uJ_v)) 的 θ 次矩，再插值得

\[
\boxed{F_{θ,C}^{ad}\le
w_u^{1-r+θ}w_v^{1-r}(Z_C^{hard})^{1-r}
κ^{2nr}(b/a)^{nθ}b^{2nθ}
[S_CM_{θ₀,s_-}^nD_H(θ₀)]^r.}
\tag{AI16}
\]

θ=0 时准确返回 w_uw_vZ_C^{hard}，没有 κ^{2n} 基价。θ₀=1/4 时坏、好两端指数分别为 1−3θ、1−4θ；这与 R137 两端额外幂的定义不同，不能直接照抄 NC10 的对称指数。这里没有 Br^{1/r}，没有使用错误的 Minkowski 换序。来源坐标不需独立。

AI3 保留 C 来源尾；AI16 保留真实 w 零阶。两者是可选择的完整估计，不能同时领取两种不同零阶因子而未重新证明。两式均把每坐标粗常数只放在正端点，故不会遗留 C₀^{2n} 型假指数障碍。

## AI5. 原低门与完整来源回代

原 R144 C8 低门为

\[
K_uJ_v<\frac{\eta_nT(x)A_v(x)Q_J(x)w_u\delta(v,u)}{De_t},
\qquad\eta_n=\frac{4(n+1)^2}{3n}.
\tag{AI17}
\]

在实际低门内，对 0≤θ≤θ₀ 将其右左比的 θ 次幂乘入上界。该因子正是 (η_n/c_x(v,u))^θ≥1，是低门上界的费用，不是衰减收益；其倒数不能拿来减少原交通。保留原 m、ρ，得到原 pair 权的上界

\[
\frac{\delta^{1+θ}}{e_t^{2+θ}}\left(\frac{\eta_n}{D}\right)^θ
\int p_xh_Rm_\xi\rho_v\,
\frac{T(x)^θQ_J(x)^θ}{q(x)}
w_u^{1+θ}w_v\frac{A_v(x)^θ}{(K_uJ_v)^θ}dx.
\tag{AI18}
\]

AI18 在不调用任何 Q_J 帽时已经是原 q、Q_J 的完整接口，绝不能由 q≥Q₀ 单独推出 Q_J≤q。以下显式另调用 R136 active_bad_geometry.md §7 已注明的**原 FIRST 同行 Q_J≤q**；适用域仍须是该合同覆盖的原合法域。若某扩张域未认证此合同，就保留 AI18 的 Q_J^θ/q，不能使用下一式的 q_- 帽。

在该原合法域、同一 λ 层级 q≥q_->0 上，θ≤1 给 Q_J^θ/q≤q^{θ−1}≤q_-^{θ−1}。JR6 的同一 s,L,R 单元给 T≤T_{+,C}。以 AI16 代入并作非负 Tonelli，低门总正项（尚未乘 2Λ）满足

\[
\begin{aligned}
P_{low}^{leg}\le\mathbb E\sum_{V,j}\int d\beta_V(y)\int_a^b\frac{dt}{t}
\iiint d\nu(z)d\nu(u)d\nu(v)\,
&\frac{1_{Z_t}(u)1_{Z_t}(v)\delta^{1+θ}}{e_t^{2+θ}}
\left(\frac{\eta_n}{D}\right)^θ
κ^{2nr}(b/a)^{nθ}b^{2nθ}\\
&\cdot w_u^{1-r+θ}w_v^{1-r}
\sum_Cq_-^{θ-1}T_{+,C}^{θ}(Z_C^{hard})^{1-r}
[S_CM_{θ₀,s_-}^nD_H(θ₀)]^r.
\end{aligned}
\tag{AI19}
\]

也可保持两份原 posterior，准确改写为

\[
\begin{aligned}
P_{low}^{leg}\le\mathbb E\sum_{V,j}\int d\beta_V(y)\int_a^b\frac{dt}{t}
\left(\frac{\eta_n}{De_t}\right)^θκ^{2nr}(b/a)^{nθ}b^{2nθ}
\int d\nu(z)\iint d\Pi_t(u)d\Pi_t(v)\,
\delta^{1+θ}w_u^{θ-r}w_v^{-r}
\sum_Cq_-^{θ-1}T_{+,C}^{θ}(Z_C^{hard})^{1-r}
[S_CM_{θ₀,s_-}^nD_H(θ₀)]^r.
\end{aligned}
\tag{AI20}
\]

两 e 分母没有消失：AI20 的 e_t^{-θ}、两真实 Π_t 和来源负权正是 AI19 的代数重写。θ₀=1/4 时这些负权为 w_u^{-3θ}w_v^{-4θ}。外 hard 来源仍是独立于 u,v 身份的第三份原 ν，不将它变为 posterior；β 不换成 ν。

原 τ_j=a/c_j≥a、h≤bc_j≤b，所以外时间 [a,b] 合法；实际 τ_j≤t≤h、原 j(x) 与所有 history 仍在 μ_C。κ、T_{+,C}、Π_t 和 μ_C 依原 j，尚未消尽来源，不能提前使用唯一 j 合并。跨 λ 层级分别保留 q_-。零 e、零 A、零 δ 行按原零交通约定，避免负权形式的无定义商。

signed 母式支付价为 2Λ 乘 AI19 或 AI20，Λ=128/119。原 Ψ 内负项、futurebad、N_del、β−ν 与已付补集均按原账保留一次；没有把本正上界当作返回已消费 N_Z 的理由。

## AI6. s,L,R 菜单能压到何处

固定同一 q_- 层、θ 与 θ₀，令

\[
A_C^{end}=T_{+,C}^{θ₀}S_CM_{θ₀,s_-}^nD_H(θ₀).
\]

AI20 中的单元和为 q_-^{θ−1}Σ_C(Z_C^{hard})^{1-r}(A_C^{end})^r。对不交实际单元有 Z^{hard}=Σ_CZ_C^{hard}，再用有限和 Hölder，严格得到

\[
\boxed{\sum_C(Z_C^{hard})^{1-r}(A_C^{end})^r
\le (Z^{hard})^{1-r}\left(\sum_CA_C^{end}\right)^r.}
\tag{AI21}
\]

这是保留零阶实际接收质量的合法共同单元插值。原菜单数至多 N_C=(n+1)(2n+3)^2；仅当已有统一端点帽 A_C^{end}≤A_* 时，AI21 才给 (Z^{hard})^{1-r}N_C^rA_*^r。θ=c/n 时 N_C^r=exp(O(log n/n))，但 Z^{hard} 未被支付：若又用 Z^{hard}≤Σ_CS_C 粗界，它可能恢复完整菜单费。不得把后者藏掉，再宣称全部自适应菜单免费消失。

特别在 θ=0，AI21 只返回 Σ_CZ_C^{hard}，仍含真实自适应 p、hard 来源、ρ、原门和实际单元域；q^{-1}、原两 posterior、score、j/time 与外 ν 完整保留。把这个零阶锚本身定义成待付款交通，并不能自动给它一个已付帽。若在最外层再用 Hölder 得 P≤P^{1-r}B^r，解得的仍是 P≤B；不能把中间小幂当作最终维数收益。

## AI7. 已证改进与停止点

已证的实际费用比较是 AI9：同一真实零阶锚、同一端点核帽、同一 s,L,R 单元下，先包络 H 后插值给较小的完整接收上界。AI3 明确区分概率 \overline P_C 与上包络 E_p；AI16 把 R137 的真实 w 锚定推广到本轮实际 H 选择器和 hard/ρ 接收测度；AI19–20 完整显示外 ν/e²/q、δ、T、w 负矩、物理 b、κ、j 与 2Λ。AI21 记录单元共享零阶质量时的合法价，不登记免费来源容量。

尚缺的联合命题很具体：对 AI20（或保留真实 Q_J^θ/q 的 AI18）中的实际 Z_C^{hard}、w_u^{θ-r}w_v^{-r}、e_t^{-θ}、T_{+,C}^{θ} 与外 ν/q 作同一来源平均，证明其原层级总价≤可吸收 εX+根阶 polylog Wβ。小 θ 降低了核和 H 包络费，但也使原低核门罚接近1，现有估计没有给这个来源平均的统一帽。仅有固定来源有限性、C_uC_v 尾衰减或菜单小幂都不完成该步骤。

本稿没有重新登记 R137 固定参数插值，没有复用已付 high 子支，没有声称一般 n^{1/2+o(1)} 付款。完成并停止。
