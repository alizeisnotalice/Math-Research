from pathlib import Path
import json,sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as m
m.mp.dps=70
rows=[]
for stage,ns in [('initial',[1,4,16]),('pressure',[4,16,64]),('expanded',[64,256,1024])]:
 for n in ns:
  for ell in [m.mpf(0),m.log(2)]:
   for theta in [m.mpf(0),min(m.mpf(1)/n,m.mpf('.25')),m.mpf('.25')]:
    r=4*theta;A=(1+n*m.mpf('.25')*ell)**r;B=1+n*theta*ell;C=m.exp(n*theta*ell)
    assert A<=B*(1+m.mpf('1e-60')) and B<=C*(1+m.mpf('1e-60'))
    rows.append(dict(stage=stage,n=n,ell=m.nstr(ell,25),theta=m.nstr(theta,25),endpoint_then_interpolation=m.nstr(A,25),interpolation_then_continuous=m.nstr(B,25),single_endpoint=m.nstr(C,25)))
out={'status':'PASS','precision':70,'scope':'Finite scalar menu comparisons only; no source budget','rows':rows,'count':len(rows)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(rows))
