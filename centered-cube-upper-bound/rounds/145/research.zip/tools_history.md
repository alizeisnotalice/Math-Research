# R145 限定历史核查：零阶锚定已经存在，新增须落在真实低尾费用

**结论：本轮基本 Hölder 候选与 R137 IA3 的公式 IA2 完全相同；真实 w、来源归一化、完整原 Σ 上的插值也已有准确版本。** 不能将该基本插值登记为 R145 新成果。可以把它具体接到 R144 新 H 菜单；菜单总费取小幂的方式与直接逐单元小幂求和有差别，但其证明原理仍是既有接口，且单 H 端点帽没有额外二次节约。

## 1. 阅读范围与技能使用

本轮仅在 R131–144 的相关 kernel/frac/entropy 片段中定向检索，并实际读取 R136 `fractional_kernel_envelope.md` FK1–5、`active_bad_geometry.md` AB16–17，R137 `interpolation_audit.md` IA1–9、`normalized_capacity.md` NC1–26、`posterior_budget.md` PB1–15，以及 R144 `capacity.md` C1–15、`softscale.md` SS1–9。没有通读全史，未重述外测度路线。

选择更新的 **D03 参数化自由能**，已读其 `SKILL.md`、`references/provenance.md`、`cube-interface.md`。本轮未核读其列出的外部论文，未把技能的历史 full_read 标签当作本人本轮原文阅读。此处基础插值直接自证，不需要自动引入自由能变分或外部高级定理。D03 的实际约束是：固定倾斜参数、参考测度与指数矩，不能把换测度/KL 费用当作已付；本模型的 ν 可相关，故其自旋/物理来源不能按名称迁入。

## 2. 最近的历史原式与准确费用

1. **完全相同的 C 核插值已经核准。** [R137 interpolation_audit.md:43](/Users/zhengzhihao/Desktop/T/output/centered_cube_round137_20261015/interpolation_audit.md:43) IA3、式 IA2，固定归一 b=1、同一概率 p、0<s≤1、L,H∈[1/2,1]，准确写出
   \[
   Q_\theta=C_uC_v\int p(d)[C_v/(k(d-u)\phi(d-v))]^\theta dd,
   \quad Q_0=C_uC_v,
   \]
   \[
   Q_\theta\le(C_uC_v)^{1-4\theta}M_{1/4,s}^{4\theta}
   \quad(0\le\theta\le1/4).
   \]
   已同时保留 n 维来源衰减 \(\prod_i(C_{u_i}C_{v_i})^{1-4\theta}\) 与价格 \(M_*^{4n\theta}\)。原 s 下门随 n 时，\(\theta=c/n\) 只把 soft 价变为 \(s^{-c}\)，不能叫作绝对常数；若 \(\log(1/s)=O(\log n)\)，\(\theta\asymp1/(n\log n)\) 才把该项有界化。物理尺度仍有 \(b^{2n\theta}\)。这正是 R145 候选的既有版本。

2. **真实权零阶锚定和两份 e 也已有。** [R137 normalized_capacity.md:95](/Users/zhengzhihao/Desktop/T/output/centered_cube_round137_20261015/normalized_capacity.md:95) NC8–14：记 \(\kappa=b/(c_jt)\)，\(\eta\le1/4\)，\(r=1+\eta\)，\(\theta=\eta/r\le1/5\)。Jensen 内的真实核有
   \[
   F_\eta\le(w_uw_v)^{1-3\eta}
   \kappa^{8n\eta}(b/a)^{n\eta}b^{2n\eta}M_*^{4n\eta}.
   \]
   回到原 posterior 后仍留下
   \[
   K_\theta e_t^{-\theta}\mathcal S_\theta,
   \quad K_\theta=\kappa^{8n\theta}(b/a)^{n\theta}b^{2n\theta}M_*^{4n\theta},
   \]
   \[
   \mathcal S_\theta=\mathbb E_{v\sim\Pi_t}
   \left[w_v^{-4\theta}
   (\mathbb E_{u\sim\Pi_t}[\delta^{1+\eta}w_u^{-3\eta}])^{1/(1+\eta)}\right].
   \]
   因此小幂并未免费归一来源。NC17 的实际 high/FIRST 可在同一个 x 上用 \(Q_J/e_t\le p_x/(2K)\) 支付整体负幂，但额外 \(p_x^\theta\) 进入真实接收核；不能只拿 FK4 固定来源帽直接替代这一步。注意此处端点比较的是 η，不是 θ。

3. **连完整原 Σ 上的插值也已存在。** [R137 normalized_capacity.md:47](/Users/zhengzhihao/Desktop/T/output/centered_cube_round137_20261015/normalized_capacity.md:47) NC4–7 保留同一来源概率、原 FA/Ψ、ρ、全部外乘子和 history，得到
   \[
   P_+\le c_\theta I_\theta
   \le c_\theta I_0^{1-\theta/\theta_0}I_{\theta_0}^{\theta/\theta_0}.
   \]
   前提是两端来自同一实际 Σ；固定来源 FK4 只是取得完整端点价的核片段，不能充当 \(I_{\theta_0}\)。NC15–21 的带权列版本允许可测核参数，保留实际接收质量 M、乘子帽 H*（或无量纲接收比 \(\mathcal D\)），价格含 \(M^{1-4\theta}H_*^{4\theta}\widetilde M_*^{4n\theta}\)。不是免费冻结选择器。

4. **小 θ 的来源/熵边界也已写明。** [R137 normalized_capacity.md:280](/Users/zhengzhihao/Desktop/T/output/centered_cube_round137_20261015/normalized_capacity.md:280) NC23–26 给 \(\mathcal S_\theta\le n(\nu(Z_t)/e_t)^{7\theta}\)，并保留零端点 score 的更尖插值。\(\theta\downarrow0\) 回到 \(\mathcal S_0=\iint\delta\,d\Pi_t^2\)，不产生根阶 gain。[R137 posterior_budget.md:46](/Users/zhengzhihao/Desktop/T/output/centered_cube_round137_20261015/posterior_budget.md:46) PB5–13 精确识别同一 bad 容量参考 \(\Sigma_B=1_BK_0\nu/C_B\) 与 score 倾斜 \(P_v\)，其代价含 \(\exp\{\theta D_r(P_v\Vert\Sigma_B)\}\)。趋近1阶需一个实际正指数矩；只知有限 KL 不替代该矩，更不提供接收/time/history 外预算。

上述公式本轮直接查看了本地原件；历史 PASS 是当时审计结论，本文不把它升级为已经闭合。

## 3. R144 H 菜单先付端点再插值：准确区别

设同一固定非负测度 m、同一 θ 无关的选择器 H(x)，且函数族确有 \(J_\theta=\int X(x)^\theta dm\)。对 \(\lambda=\theta/\theta_0\)，基础 Hölder 给
\[
J_\theta\le J_0^{1-\lambda}J_{\theta_0}^{\lambda}.
\]
若先在 θ₀ 端用 R144 菜单证 \(J_{\theta_0}\le\sum_{m=1}^{N_H}B_m(\theta_0)\)，则
\[
J_\theta\le J_0^{1-\lambda}
[\sum_m B_m(\theta_0)]^{\lambda}.
\tag{TH1}
\]
当各端点帽≤B时，菜单价是 \(N_H^\lambda\)，而不是 \(N_H\)。**不要**先把小 θ 的每个单元单独上界再直接求和；这会丢掉同一零阶基线。若只有各单元零阶质量 a_m，可先保留它们：\(\sum a_m^{1-\lambda}B_m^\lambda\le(\sum a_m)^{1-\lambda}(\sum B_m)^\lambda\)；\(\sum a_m=J_0\) 须由真实不交分割或其他质量证明保证，不能对重叠菜单宣称概率总质量为1。

TH1 是 NC7/带权列插值的具体菜单实现；限定历史未见它以 R144 SS3 的新菜单单独写出。因而可登记“新菜单的具体接合/费用比较”，不能登记“新发现零阶 Hölder”。所有 θ 无关费用只能并入同一 m 后连基线一起支付，不能只对有利菜单取小幂、把 q/h_R/history 的基线质量删掉。

若只对 H 使用 R144 SS7e 的单端帽，\(K_{H(x)}^{-\theta_0}\le2^{n\theta_0}K_a^{-\theta_0}\)，再取 λ 恰得 \(2^{n\theta}\)，与直接小 θ 的单端式完全相同。θ=c/n 时均为2^c；没有第二次节约。SS3 的直接路线是首单元加 \(\theta\sum B_m(\theta)\)，TH1 则先取 θ₀ 端总和的小幂；两者应在完成真实接收积分后比较，不能逐项拼最小值。对 JR/CA 使用 TH1 时须先除去显式 cθ，并把 \([1-b]_+^{1+\theta}=[1-b]_+([1-b]_+)^\theta\) 等因子准确并入同一族；不同 θ 的门或测度不能直接插值。

## 4. 门罚与可实施的 C 尾保留

对真实低门 \(K_uJ_v<\varepsilon L_x\)，任意 θ>0 只有
\[
1_{\{K_uJ_v<\varepsilon L_x\}}
\le\varepsilon^\theta[L_x/(K_uJ_v)]^\theta.
\tag{TH2}
\]
本轮 \(L_x=\eta_nTA_vQ_Jw_u\delta/(De_t)\) 依同一 x、来源对和 ν；不能当作固定常数移出积分。θ=c/n 时若要求单凭门罚得到 \(n^{-1/2}\)，需 \(\log(1/\varepsilon)\ge n\log n/(2c)\)；仅多项式深度的尾给不出该因子。原 low 的 ε=1 没有此衰减，而 \(\eta_n^\theta\) 的量级亦趋近1。\(c_\theta=\theta^\theta/(1+\theta)^{1+\theta}\to1\)，也不产生根阶收益。

可立即实施、但仍不计付款的改进：R136 FK2/3 原本保留了来源尾，FK4 证明为了统一帽才删掉。固定 θ₀ 和 H 时可直接保留
\[
T_u=\frac{e^{-(1-\theta_0/H)|u|}}{(1+|u|)^{1-\theta_0}},\qquad
T_v=\frac{e^{-|v|}}{1+|v|},
\quad I_{\theta_0}(u,v)\le M_{\theta_0,s}T_uT_v.
\]
因此准确锚定可写为
\[
I_\theta(u,v)\le[C(u)C(v)]^{1-\lambda}
[M_{\theta_0,s}T_uT_v]^\lambda.
\tag{TH3}
\]
逐坐标乘积及物理 \(b^{2n\theta}\) 原样保留。若 H 可变但在[1/2,1]，可用 \(1-2\theta_0\) 替换 bad 尾指数作统一下界。此式是旧 FK2/3 的未删除尾因子加既有 Hölder，不是新的尾定理；它比只保留 C 的统一端点更尖，适合本轮真实来源积分测试。不得先对源取 sup 再声称保留了它；同一 ν 的归一化来源平均仍须和 e、TA、QJ 一同估价。

另一合法做法是同一 θ 无关的实际门 E 内插值，保留 \(I_0^E=\int_EpC_uC_v\)；只有另证该门的零阶接收质量衰减才带来新预算，不能把这个未知量重新命名为已付。

本轮未运行新数值或外文检索；没有证明 R144 低核尾总价。准确剩余仍是低门、good 门、共同 QJ/e 与真实来源/接收及全层级的联合付款。只新增本文件，完成停止。
