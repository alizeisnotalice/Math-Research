from pathlib import Path
import json,math,hashlib
from collections import defaultdict
r=Path(__file__).resolve().parent
paths=[r.parent/'centered_cube_round144_20261015/numeric_geometry.json',r.parent/'centered_cube_round142_20261015/numeric_receiver.json',r.parent/'centered_cube_round136_20261014/active_traffic_v2.json']
g,rec,orig=[json.loads(p.read_text()) for p in paths];sources={c['id']:c for c in orig['cases']};rows=[];groups=defaultdict(list)
for row in g['posthoc_capacity_split_screen']['pair_segment_records']:
 cid=row['case'];c=sources[cid];rr=rec['cases'][cid]['records'][row['id']];v=row['v'];u=row['u'];n=row['n'];H=float(c['derived']['Hhat']);b=float(c['parameters']['b']);K=float(c['parameters']['K']);wg=float(c['atoms'][v]['wg']);Jv=rr['J'][v];Ku=rr['K0'][u]
 gamma=rr['p']*wg/(K*Jv)
 for sm in row['samples']:
  E=n*math.log(b/H)+2*math.log(gamma)+math.log(Jv/Ku)+math.log(sm['c_over_eta'])
  out={'case':cid,'id':row['id'],'stage':row['stage'],'v':v,'u':u,'segment':row['segment'],'time_label':sm['label'],'E':E,'good_ratio':gamma,'FA_interior':sm['positive_interior_occupation']};rows.append(out)
  groups[cid+'/'+row['stage']].append(out)
summary={key:{'N':len(v),'positive_E':sum(x['E']>0 for x in v),'min_E':min(x['E'] for x in v),'max_E':max(x['E'] for x in v),'FA_interior_N':sum(x['FA_interior'] for x in v),'FA_interior_positive_E':sum(x['FA_interior'] and x['E']>0 for x in v)} for key,v in groups.items()}
out={'scope':'saved float pointwise diagnostic only; not full-window or general geometric proof','input_sha':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'rows':rows,'summary':summary,'count':len(rows)}
(r/'geometric_margin.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(summary,indent=2))
