#!/usr/bin/env python3
"""R266 bounded actual strong fixed gap / finite posterior diagnostics."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
from math import prod
import mpmath as mp

def enc(x):return mp.nstr(x,80)
def mm(x):
 f=F(str(x));return mp.mpf(f.numerator)/f.denominator
def phi(u):
 u=abs(u)
 if u<=mp.mpf('.5'):return 1-mp.expint(3,mp.mpf('.5')-u)-mp.expint(3,mp.mpf('.5')+u)
 return mp.expint(3,u-mp.mpf('.5'))-mp.expint(3,u+mp.mpf('.5'))
def C(r):
 r=abs(r)
 if r<=1:return 1-r+mp.mpf(1)/3-mp.expint(4,r)-mp.expint(4,1)+mp.expint(4,r+1)
 return mp.expint(4,r-1)-2*mp.expint(4,r)+mp.expint(4,r+1)
def P(s,L,x):return ((1-s)*(1 if abs(x)<L/2 else 0)+s*phi(x/L))/L

def menu():
 return [(1,'1/2','1/2','0','1/2','1/2'),(1,'1/2','1','1/10','1/100','1/5'),(1,'3/4','3/4','3/5','1/5','1/5'),(1,'1','1','11/10','1/2','1/2'),(8,'1/2','3/4','root_minus','1/2','1/2'),(8,'1/2','3/4','root_plus','1/2','1/2'),(8,'3/4','1','1/1000000','0','1/2'),(8,'1','1','2','1/100','1/100'),(128,'1/2','1/2','8','1/2','1/2'),(128,'3/4','27/32','4','1/5','1/100'),(128,'1','1','3/5','1/2','0'),(128,'1/2','1','1/100','0','0')]

def actual(dps,pilot=False):
 with mp.workdps(dps):
  c0=phi(mp.mpf('1.5'));assert c0>mp.mpf(1)/128;rows=[]
  root=mp.findroot(lambda r:C(r)-mp.mpf('.5'),(.6,.8))
  for n,ls,As,rs,ss,sigs in menu()[:4] if pilot else menu():
   L,A,s,sig=map(mm,[ls,As,ss,sigs]);r=root+(-1 if rs=='root_minus' else 1)*mp.mpf('1e-10') if rs.startswith('root_') else mm(rs)
   epsilon=mp.mpf('.5')/(8*mp.sqrt(n));half=(1+epsilon)/2;om=min(mp.mpf(1),C(r)/L)
   pts=sorted(set([-half,half]+[x for x in [-L/2,L/2,r-A/2,r+A/2] if -half<x<half]))
   val=sum(mp.quad(lambda x:P(s,L,x)*P(sig,A,x-r),[a,b]) for a,b in zip(pts,pts[1:]))
   logD=mp.log(L*val/om) if val else mp.ninf
   rhs=epsilon*s*sig-c0*(1-s)*(1-sig)*(1-C(r));assert logD<=rhs+mp.mpf('1e-30')
   rows.append({'stage':'initial' if n==1 else 'stress' if n==8 else 'expanded','n':n,'L':ls,'A':As,'r_input':rs,'r':enc(r),'s':ss,'sigma':sigs,'epsilon':enc(epsilon),'C_r':enc(C(r)),'Omega':enc(om),'saturated':C(r)>=L,'scalar_integral':enc(val),'scalar_log_normalized_square':enc(logD),'scalar_log_bound':enc(rhs),'scalar_log_margin':enc(rhs-logD),'tensor_log_normalized_square':enc(n*logD),'tensor_log_bound':enc(n*rhs),'tensor_log_margin':enc(n*(rhs-logD)),'hard_split_points':[enc(x) for x in pts]})
  return {'c0':enc(c0),'clamp_root_C_equals_half':enc(root),'cases':rows}

def wf(c,t):return prod(min(F(1),x/t) for x in c)
def laws():
 out=[]
 for n in [2,8,32]:
  out.append({'n':n,'sources':[{'mass':F(1,10**8),'c':[F(1)]*n,'delete':None},{'mass':F(1),'c':[F(1,2)]*n,'delete':None},{'mass':F(10**4),'c':[[F(5,8),F(7,8),F(999999,1000000)][i%3] for i in range(n)],'delete':None},{'mass':F(10**6),'c':[F(3,4)]*n,'delete':F(7,8)},{'mass':F(1,1000),'c':[F(999999,1000000)]*n,'delete':F(999999,1000000)}]})
 return out

def envelope(n,alpha):
 gamma=mp.mpf(1);cut=1/(mp.e*alpha*n);pts=sorted(set([mp.mpf('.5'),mp.mpf(1)]+[u for u in [1/gamma,(1-cut)/gamma] if mp.mpf('.5')<u<1]));val=mp.mpf(0)
 for a,b in zip(pts,pts[1:]):
  if 1-gamma*(a+b)/2<=cut:val+=n*mp.log1p((b-a)/a)
  else:val+=(mp.log1p((b-a)/a)-mp.log((1-gamma*b)/(1-gamma*a)))/(mp.e*alpha)
 return val

def posterior(dps):
 with mp.workdps(dps):
  rows=[]
  for law in laws():
   n=law['n'];src=law['sources'];knots=sorted({F(1,2),F(1)}|{x for j in src for x in j['c'] if F(1,2)<x<1}|{j['delete'] for j in src if j['delete']})
   intervals=[];rootcount=0
   for a,b in zip(knots,knots[1:]):
    mid=(a+b)/2;alive=[j for j,z in enumerate(src) if z['delete'] is None or z['delete']>mid];ks={j:sum(x<mid for x in src[j]['c']) for j in alive};coeff={j:src[j]['mass']*prod(x for x in src[j]['c'] if x<mid) for j in alive}
    def state(t):
     wt={j:mm(coeff[j])*t**(-ks[j]) for j in alive};e=sum(wt.values());pi={j:w/e for j,w in wt.items()};mean=sum(pi[j]*ks[j] for j in alive);return pi,mean
    aa,bb=mm(a),mm(b);roots=[]
    for k in sorted(set(ks.values())):
     left=state(aa)[1]-k;right=state(bb)[1]-k
     if left>0 and right<0:
      lo,hi=aa,bb
      for _ in range(4*dps+20):
       center=(lo+hi)/2
       if state(center)[1]>k:lo=center
       else:hi=center
      roots.append((lo+hi)/2)
    pts=sorted(set([aa,bb]+roots));rootcount+=len(roots)
    # Capture interval variables in a concrete record; no late closure reuse.
    intervals.append((alive,ks,coeff,pts))
   for alpha_name,alpha in [('actual_c0_over4',phi(mp.mpf('1.5'))/4),('diagnostic_0.05',mp.mpf('.05')),('diagnostic_0.2',mp.mpf('.2'))]:
    H=[mp.exp(-alpha*sum(1-min(F(1),x) for x in j['c'])) for j in src]
    initialmass=[j['mass']*wf(j['c'],F(1,2)) for j in src];initial=sum(H[j]*mm(w) for j,w in enumerate(initialmass))/mm(sum(initialmass))
    continuous=mp.mpf(0);N=mp.mpf(0);KH=mp.mpf(0);pairflow=mp.mpf(0)
    for alive,ks,coeff,pts in intervals:
     def f(t):
      weights={j:mm(coeff[j])*t**(-ks[j]) for j in alive};e=sum(weights.values());mean=sum(weights[j]*ks[j] for j in alive)/e
      return sum(H[j]*weights[j]/e*max(mp.mpf(0),mean-ks[j]) for j in alive)/t
     continuous+=sum(mp.quad(f,[a,b]) for a,b in zip(pts,pts[1:]))
     def main_density(t,which):
      weights={j:mm(coeff[j])*t**(-ks[j]) for j in alive};e=sum(weights.values());pi={j:w/e for j,w in weights.items()};mean=sum(pi[j]*ks[j] for j in alive)
      if which=='N':return mean*sum(H[j]*pi[j] for j in alive)/t
      if which=='KH':return sum(H[j]*ks[j]*pi[j] for j in alive)/t
      return sum(max(ks[i]-ks[j],0)*pi[i]*pi[j]*H[j] for i in alive for j in alive)/t
     for a,b in zip(pts,pts[1:]):
      N+=mp.quad(lambda t:main_density(t,'N'),[a,b]);KH+=mp.quad(lambda t:main_density(t,'KH'),[a,b]);pairflow+=mp.quad(lambda t:main_density(t,'pair'),[a,b])
    jumps=mp.mpf(0);signedjumps=mp.mpf(0);rho=F(0);jumpinfo=[]
    for t in sorted({j['delete'] for j in src if j['delete']}):
     pre={j:z['mass']*wf(z['c'],t) for j,z in enumerate(src) if z['delete'] is None or z['delete']>=t};post={j:w for j,w in pre.items() if src[j]['delete']!=t};epre=sum(pre.values());epost=sum(post.values());removed=epre-epost;rr=removed/epre;rho+=rr
     # Every surviving posterior increases and every deleted one drops to zero.
     assert sum(post[j]/epost-pre[j]/epre for j in post)==rr
     weighted=sum(H[j]*mm(post[j]) for j in post)*(1/mm(epost)-1/mm(epre));jumps+=weighted
     signed=sum(H[j]*mm(post[j])/mm(epost) for j in post)-sum(H[j]*mm(pre[j])/mm(epre) for j in pre);signedjumps+=signed
     assert -signed<=mm(rr)+mp.mpf('1e-35')
     jumpinfo.append({'t':str(t),'rho_increment_exact':str(rr),'weighted_positive_jump':enc(weighted),'signed_H_posterior_jump':enc(signed)})
    M=initial+continuous+jumps;env=envelope(n,alpha);C_alpha=2/(mp.e*alpha)*(1+max(mp.mpf(0),mp.log(mp.e*alpha*n)));assert env<=C_alpha
    bound=1+env+mm(rho);analytic_bound=1+C_alpha+mm(rho);assert M<=bound+mp.mpf('1e-30')
    terminalweights={j:z['mass']*wf(z['c'],F(1)) for j,z in enumerate(src) if z['delete'] is None};terminal=sum(H[j]*mm(w) for j,w in terminalweights.items())/mm(sum(terminalweights.values()))
    identity_rhs=terminal-initial+KH-signedjumps;identityres=abs(N-identity_rhs)/max(1,abs(N))
    assert identityres<mp.mpf('1e-30') and pairflow<=N+mp.mpf('1e-30') and N<=bound+mp.mpf('1e-30')
    rows.append({'stage':'initial' if n==2 else 'stress' if n==8 else 'expanded','n':n,'alpha_label':alpha_name,'alpha':enc(alpha),'H':list(map(enc,H)),'initial':enc(initial),'continuous_positive_variation':enc(continuous),'positive_jumps':enc(jumps),'M_H':enc(M),'sourcefunctional_N_H':enc(N),'weighted_score_KH':enc(KH),'terminal_H_posterior':enc(terminal),'signed_jump_H_sum':enc(signedjumps),'N_identity_rhs':enc(identity_rhs),'N_identity_relative_residual':enc(identityres),'pairflow_low_score_H':enc(pairflow),'pairflow_to_N_margin':enc(N-pairflow),'N_bound_margin':enc(bound-N),'rho_exact':str(rho),'rho':enc(mm(rho)),'clock_upper_envelope_integral':enc(env),'clock_analytical_C_alpha':enc(C_alpha),'analytical_bound_with_rho':enc(analytic_bound),'bound':enc(bound),'bound_margin':enc(bound-M),'ratio_to_bound':enc(M/bound),'threshold_intervals':len(intervals),'mean_score_crossings':rootcount,'jumps':jumpinfo})
  return {'cases':rows,'laws':[{'n':l['n'],'sources':[{'mass':str(z['mass']),'c':list(map(str,z['c'])),'delete':str(z['delete']) if z['delete'] else None} for z in l['sources']]} for l in laws()]}

def exact_moment():
 rows=[];midchecks=0
 for law in laws():
  src=law['sources'];N=len(src);knots=sorted({F(1,2),F(1)}|{c for z in src for c in z['c'] if F(1,2)<c<1}|{z['delete'] for z in src if z['delete']})
  continuous=[F(0)]*N;jumps=[F(0)]*N
  def posterior_at(t,alive):
   raw={j:src[j]['mass']*wf(src[j]['c'],t) for j in alive};e=sum(raw.values());return {j:w/e for j,w in raw.items()},raw,e
  initial=posterior_at(F(1,2),list(range(N)))[0];terminal=posterior_at(F(1),[j for j,z in enumerate(src) if z['delete'] is None])[0]
  for a,b in zip(knots,knots[1:]):
   mid=(a+b)/2;alive=[j for j,z in enumerate(src) if z['delete'] is None or z['delete']>mid];pa=posterior_at(a,alive)[0];pb=posterior_at(b,alive)[0]
   pi,raw,e=posterior_at(mid,alive);ks={j:sum(c<mid for c in src[j]['c']) for j in alive};edot=-sum(ks[j]*raw[j] for j in alive);mean=-edot/e
   for j in alive:
    continuous[j]+=pb[j]-pa[j]
    quotient=(-ks[j]*raw[j]*e-raw[j]*edot)/(e*e)
    assert quotient==(mean-ks[j])*pi[j];midchecks+=1
  for t in sorted({z['delete'] for z in src if z['delete']}):
   pre=posterior_at(t,[j for j,z in enumerate(src) if z['delete'] is None or z['delete']>=t])[0];post=posterior_at(t,[j for j,z in enumerate(src) if z['delete'] is None or z['delete']>t])[0]
   for j in range(N):jumps[j]+=post.get(j,F(0))-pre.get(j,F(0))
  residual=[continuous[j]+jumps[j]-terminal.get(j,F(0))+initial[j] for j in range(N)];assert residual==[F(0)]*N
  rows.append({'n':law['n'],'initial_posterior':list(map(str,[initial[j] for j in range(N)])),'terminal_posterior':list(map(str,[terminal.get(j,F(0)) for j in range(N)])),'continuous_signed_derivative_integrals_exact':list(map(str,continuous)),'signed_jump_coefficients_exact':list(map(str,jumps)),'coefficient_identity_residuals_exact':list(map(str,residual))})
 return {'source_coefficient_identities':15,'midpoint_quotient_checks':midchecks,'cases':rows,'meaning':'Exact per-source coefficient telescoping and quotient derivative certify the weighted moment identity algebraically for any static H. Actual N and KH integrals remain ordinary quadrature.'}

def J_scalar_screen():
 values=[]
 for dps in [40,70]:
  with mp.workdps(dps):
   direct=mp.quad(phi,[-mp.mpf('.5'),mp.mpf(0),mp.mpf('.5')]);formula=mp.mpf(1)/3+2*mp.expint(4,1)
   assert direct<mp.mpf('.8') and abs(direct-formula)<mp.mpf('1e-35')
   values.append({'dps':dps,'V0_direct':enc(direct),'V0_E4_formula':enc(formula),'formula_absolute_residual':enc(abs(direct-formula))})
 kappa=F(25,2**68);upper=F(4,5);records=[]
 for omega in [F(1,100),F(1,2),F(899,1000),F(9,10),F(999,1000),F(1)]:
  lhs=min(upper/omega,1-kappa*(1-omega));bound=1-kappa/10;assert lhs<=bound
  records.append({'Omega_exact':str(omega),'V0_upper_exact':str(upper),'min_expression_upper_exact':str(lhs),'bound_exact':str(bound),'margin_exact':str(bound-lhs)})
 with mp.workdps(100):relative=abs(mp.mpf(values[0]['V0_direct'])-mp.mpf(values[1]['V0_direct']))
 return {'exact_cases':records,'V0_checks':values,'V0_precision_absolute_difference':enc(relative),'kappa_exact':str(kappa),'cJ_exact':str(kappa/20),'scope':'Six exact scalar theorem-screen checks use the independent upper bound V0<=4/5; not six new actual kernels, not a FULL/source budget certificate.'}

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and k not in ['stage','L','A','r_input','s','sigma','alpha_label','rho_exact','t','rho_increment_exact','mass','delete']:
    try:
     z=mp.mpf(v)
     if mp.isfinite(z):out[path+k]=z
    except ValueError:pass
   elif isinstance(v,(dict,list)):out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=p.parse_args();low={'actual':actual(40),'posterior':posterior(40)};high={'actual':actual(70),'posterior':posterior(70)}
 with mp.workdps(100):
  x=fields(low);y=fields(high);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);assert diff[worst]<mp.mpf('1e-32')
 out={'schema':'R266-fixed-gap-posterior-v1','J_fixed_window_scalar_screen':J_scalar_screen(),'exact_weighted_moment_certificate':exact_moment(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'actual_kernel_cases_per_precision':12,'actual_stages':{'initial':4,'stress':4,'expanded':4},'finite_clamp_laws':3,'weighted_posterior_cases_per_precision':9,'J_scalar_rational_cases':6,'J_V0_actual_integrals':2,'exact_jump_mass_identities':6,'N_identity_and_pairflow_cases_per_precision':9,'exact_source_moment_coefficient_identities':15,'exact_midpoint_quotient_checks':exact_moment()['midpoint_quotient_checks'],'precision_fields_compared':len(diff)},'mp40':low,'mp70':high,'precision_max_relative_difference':md,'precision_worst_field':worst,'scope':['Actual moving-square kernel tests use b1,y0,L in[.5,1],L<=A<=1,s,sigma<=.5,W side1+epsilon; repeated-coordinate products n1/8/128. The stronger gap is 1-C(r), including saturated Omega=1.','Finite posterior laws use explicitly rational thresholds and finite atomic masses, not asserted to arise from actual C geometry, original source gates or positive L1 sources. Threshold and deletion knots, plus all interior mean-score crossings, split positive-variation integration.','Added sourcefunctional N(H)=integral mean_score*Pi(H). Its identity is terminal_H-initial_H+integral Pi(H k)-signed_jump_H_sum; full pairflow weights H on the lower-score j and uses (k_i-k_j)+<=k_i, never <=k_j.','M(H)=sum H_j[Pi_j(tau)+integral(Pi_j derivative)_+ dlogt+sum positive deletion jumps],H static. rho is exact sum removed_mass/e_pre. Toy interval tau=.5,b1; bound uses the fixed-b envelope min(n,1/(e alpha(1-u))) with u=t/b, no gamma; its exact closed integral is compared to C_alpha=2/(e alpha)(1+log_+(e alpha n)).','Actual alpha=c0/4 is separated from diagnostic alpha .05,.2. Ordinary mpmath40/70 is not directed interval arithmetic. Finite passing cases do not prove a universal lemma, FULL qualification, history, root gain or dimension order.']}
 args.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst}))
if __name__=='__main__':main()
