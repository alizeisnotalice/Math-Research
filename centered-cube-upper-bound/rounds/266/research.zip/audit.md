# R266 final independent audit

**PASS. No necessary correction found in the final integrated proof.**

Audited main: `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/266/work/proof.tex.txt`

SHA256: `e427ea2f3a1071706ccd81b21c7010c0f286aa47a00dabd13eb64867d8bfde97`.

The independent statement screening and its source-direction correction are preserved in `/tmp/r266_screen.md` (SHA256 `1d13d8100c92b4d9e720e67daff9505ac20bf262b926089bca035da86d865898`). This final review read the whole integrated main and the author manuscript `/tmp/r266_geometry.md` (SHA256 `adafa62a075d14a9f992973e7c0d2dfead3f674b3826b2d2a0abbb08d251d215`). No repository files, Git or PDF were modified or used.

## Mathematical findings

1. **G1–G3 fixed geometric gap: PASS.** The unequal-size hard intersection bound in G2 is valid. It avoids the false intermediate `(L−distance)+` formula when A>L. The bound C−A0≥r c0 is confined to r≤1; A0=0 handles the tail. Both asymmetric hard-soft factors and the common-window soft-soft collar have the correct normalization. The common clipped soft grid and Abel give D=8 c_n² M exp(nεs0²) and the norm weight H=exp[−c0(1−s0)²Δ_b/2]. There is one menu, no M² and no node FIRST assumption.

2. **G4 and actual G8 direction: PASS.** Frozen R223 NC2–NC4 directly binds the original positive difference to k_good−k_bad, with the half-kernel in the good slot. Therefore the other-slot integral is bounded by that kernel slot's k. At fixed original j,y,t the full Π is receiver-independent; time is not changed to u g(x). The exact static distance gap satisfies Δ_b≥(1−ξ)k for ξ=c_jt/b∈[a/b,c_j²]⊂[1/2,1]. This gives the displayed Bα without an endpoint 1, deletion rho or initial heavy ratio. Positive removal of masks is legitimate and does not authorize any analogous change to a negative term.

3. **Auxiliary G5–G7/G9: PASS, with their stated auxiliary status.** The signed weighted-posterior identity and deletion renormalization signs are correct. The positive-variation envelope identity is a weighted telescoping identity. Inner endpoint conventions and inclusion/exclusion of endpoint deletions are stated. The rho resource belongs only to the reverse-score/variation estimate, not to the actual main G8, and is never reclassified as the original continuous N_del credit. No representation is used twice.

4. **Uniform J G10–G12: PASS.** Same-window Cauchy gives D_J²≤V(0)/Ω. The explicit bound V(0)≤φ(0)≤2(1−e^(−1/2))<4/5 is valid; the 9/10 split and R224 yield c_J=κ/20 with the exact R=b,A=b normalization. The collar extension, L^(3/2) interpolation, Abel factor (3/2)^(2/3), clipped-grid sqrt(c_n)M^(2/3), a^(−n/3), and exponent in A_J are all correct. Fixed ORIGINAL time permits Minkowski against the same full Π; the full iid Gini bound n/4 then gives G12. This does not use pointwise normalization of the receiver-dependent relative-time posterior. Exponential decay is retained explicitly, not presumed to dominate the positive collar term at every finite n.

5. **Full-source accounting G13–G15: PASS as conditional explicit costs.** The old/new row minimum compares bounds for the same actual row. Setting the new row price Bα directly also gives a completely heavy-ratio-free option; old heavy data are optional, not a hidden assumption. G14's coefficient is C_out²/4=256Λ²Kγ^nD/27. All β, λ, a and receiver-multiplicity costs remain. G15 correctly uses the l^(3/2) norm over unique-j receiver masks, Z^J=(Σ_j[∫(n/4)L_yj dβ]^(3/2))^(2/3), and the true receiver Holder factor |E_(ω,V)|^(1/3). It does not discard the full β mass or infer receiver disjointness from source disjointness. The displayed finite j bound is a valid conservative count; empty/singleton rows contribute zero.

6. **Scope and limits: PASS.** The actual coarsest-light carrier, raw weights, original good classifier, source identities and all signed credits stay in place. The new estimate completes the moving and J auxiliary-posterior slots at fixed original time, but does not pay the remaining outer β/j/receiver objectives. The proof retains possibly infinite positive bounds under truncation/limits, does not perform infinite signed subtraction, and makes no general root/full-goal claim. The a^(−n/2) and a^(−n/3) dimensions and once-only original weight conversion remain explicit.

## Finite evidence and execution boundary

The main program's actual moving-kernel tests, finite atomic posterior laws and J scalar screens are finite diagnostics, not FULL inputs or interval certificates. Its stored posterior pairflow is explicitly a LOWER-score auxiliary test and must not be cited as direct testing of the actual upper-score positive law. The analytic actual-direction proof is G8.

I statically inspected the final numeric source. It computes the weighted score KH, while its embedded assertions primarily certify the auxiliary N identity/bound. I independently read the frozen JSON and checked all 9 KH values at each of mp40 and mp70 against the stored exact closed clock envelope (18 stored-field comparisons); all passed, minimum displayed margin approximately 0.8163510347. This was a stored-data consistency check, not a fresh numerical integration or a byte replay. Parent's reproduction is separately responsible for full execution and the explicit archived KH assertions.

Numerical files bound for this static review:

- numeric_checks.py: `5796df1202466d22efdbfa650f8f2834b972ebb59429afe4e11dc93bea648096`
- numeric_checks.json: `12a819e2c98d809cf031ba697b9320e350de1a0f0b3b2b1781796d86a1d719f0`

The earlier local screening ran only the documented bounded exact arithmetic/clock primitive diagnostics. No passed general proof or physical models were redundantly rerun here. All reviewed main statements are supported by the independent analytic derivations; no new global payment is registered.


---

# Preserved independent statement screening (including corrected source binding)

# R266 independent screening: terminal-good cap and the initial energy

Verdict (final orientation binding): frozen R223 NC2–NC4 fixes the ACTUAL positive direction as (k_GOOD−k_BAD)+. The stronger fixed gap therefore gives a direct weighted-score row price with no initial-degree or deletion charge (§6a). The reverse-score clock measure in §6b is only auxiliary. The terminal-good cap alone still does not cancel the likelihood cost; J also has a uniform mass gap (§7). Original β/j/receiver costs remain unpaid, and no general source/root payment is certified.

This note is statement-first. Only the frozen R262 identity was read to verify its endpoint/sign conventions. No R266 author proof was used. No repository/Git/PDF changes were made.

## 1. Fixed original row and exact target measure

Fix the complete actual row, including x,y,seed,V,j and original terminal g. Let p=p_y(x)>0, q,K>0, and T(v)=Q_x^*(v). The fixed terminal-good set G⊂Z_g obeys p w_g(v)≤K T(v), and ∫T dν≤q. G is not replaced by good-at-t. Every G source persists at all t≤g. Write

\[
 \Sigma_x(dv)=T(v)\nu(dv)/q,\quad
 a_G(v)=1_G(v)\frac{p w_g(v)}{K T(v)}\in[0,1],\quad
 L_t(v)=w_t(v)/w_g(v).
\]

Set a_G=0 on T=0; G has no positive-weight contribution there. Then the exact identity is

\[
 \boxed{1_G\Pi_t(dv)=\frac{Kq}{p e_t}\,a_G(v)L_t(v)\Sigma_x(dv).}
\]

The target measure is a subprobability, but depends on the original receiver x. All carrier, history, other source and signed weights must be retained. For clamps w_t=∏min(1,A_i/t),

\[
 1\le L_t(v)\le(g/t)^n,\qquad t\le g.
\]

The upper likelihood factor can be attained pointwise by an all-active source. Thus it cannot be replaced by one using the terminal cap alone. This observation is about a step of the estimate, not a counterexample to the full original geometric budget.

## 2. A genuine restricted-good positive-pair energy

On l≤t≤h≤g, put

\[
 H_G(t)=\int_Gw_t\,d\nu,\qquad
 M_{G,2}(t)=\int_G k_t(v)^2w_t(v)\,d\nu(v).
\]

No deletion occurs inside G. Since −dw_t/dlogt=k_tw_t and k_t²≤n k_t,

\[
 \boxed{\int_l^h M_{G,2}(t)\,dt/t
 \le n[H_G(l)-H_G(h)].} \tag{A}
\]

This uses ordinary absolute continuity of each clamp weight, Tonelli, and no derivative of k_t. Thresholds create no atoms in w_t. Inner endpoint weights are used if the full carrier has deletion jumps at l or h. G itself is never deleted, so its raw mass is continuous.

For the actual orientation δ+=(k_good−k_bad)+, let J_t be a masked G×B score traffic, under the SAME full posterior Π_t in both slots. This orientation is now directly bound to frozen R223 NC2–NC4. By δ+≤k_good and Cauchy on G×B,

\[
 J_t^2\le\Pi_t(B)\int_G k_v^2\Pi_t(dv)
 \le M_{G,2}(t)/e_t.
\]

Consequently

\[
 \boxed{\int_l^h e_tJ_t^2\,dt/t\le n[H_G(l)-H_G(h)].} \tag{B}
\]

This removes the irrelevant initial mass outside G from the raw fixed-row positive-pair energy. It is a valid useful refinement of applying the full-posterior e_tau bound here. The sharper Π_t(B) factor may be retained; no independence between coordinates or conditional sources is assumed.

The terminal cap gives only

\[
 H_G(l)-H_G(h)
 =\frac{Kq}{p}\int a_G(L_l-L_h)\,d\Sigma_x
 \le\frac{Kq}{p}(g/l)^n.
\]

The FIRST mass bound on Σ does not control this weighted integral without its likelihood factor. With a heavy floor e_t≥B_jt^n,

\[
 \int_l^h J_t\,dt/t
 \le\sqrt{\frac{H_G(l)-H_G(h)}{B_jl^n}
 [1-(l/h)^n]}. \tag{C}
\]

All source weights still accompany (C). This is an explicit alternative row price, not a paid source budget. In the R265 fixed-t receiver column, the same argument replaces e_tau by H_G(tau)−H_G(T) in the energy factor, but the uniform receiver column then loses access to a single actual-x-dependent G unless that dependence is separately kept or majorized. One cannot use the improved energy and simultaneously discard the x-dependent good classifier to obtain an unqualified static-source Minkowski bound.

A terminal-charged weighted version is also valid:

\[
 \int_l^h(t/g)^{2n} e_tJ_t^2\,dt/t
 \le nH_G(g)[(h/g)^n-(l/g)^n]
 \le\frac{nKq}{p}[(h/g)^n-(l/g)^n]. \tag{D}
\]

Indeed k²≤n² and w_t≤(g/t)^n w_g. Undoing (D) by time Cauchy necessarily retains the dual weight (g/t)^{2n}/e_t; it is not a free terminal-energy cancellation.

## 3. What retaining the R262 signed suffix graph actually gives

Keep the original fixed graph Z⊂B×G and its actual endpoint h≤g. It is not reselected on subwindows. With r_c(t)=w_t(c)/w_h(c), define

\[
 q_t(c)=\int_{\{b:(b,c)\in Z\}}
 [w_t(b)-w_h(b)r_c(t)]\,d\nu(b)\ge0.
\]

The sign follows from the established suffix-graph odds ordering. Then Q_sum(t)=∫_G w_t(c)q_t(c)dν(c), and the continuous compensated term from R262 is EXACTLY

\[
 \boxed{\mathcal C_{cont}
 =\frac{2Kq}{p}\int_l^h e_t^{-2}
 \int a_G(c)L_t(c)(m_t-k_t(c))q_t(c)
 \,d\Sigma_x(c)\,dt/t.} \tag{E}
\]

No e_t was dropped, and r_c uses w_h, not w_g. The good cap always uses the original g. Multiplying the original p/q mother indeed cancels that explicit p/q against Kq/p in (E), but leaves e_t^{-2}, L_t, the graph-weighted bad row q_t, the signed centered score, actual dx and all other original measures. This is a real source identity, not a final bound.

The restricted-positive energy (A) does not directly pay (E): (m−k_c) contains the FULL posterior mean. For example algebraically

\[
 \int_G(m-k_c)^2w_t\,d\nu
 =M_{G,2}-2mM_{G,1}+m^2H_G.
\]

The last term is not controlled by (A) alone. Bounding it by the full variance/energy returns to a full-degree cost; removing the likelihood from (E) instead introduces the terminal-to-initial factor. A useful new cancellation would require an original-measure bound on the joint signed expression in (E), or a genuine matching estimate with the existing future/loss traffic, including all graph/receiver weights. Neither follows from ∫Tν≤q and terminal-good mass alone.

Initial Q/e_l² plus the bad boundary were already paid together in R262. They cannot be repaid or reused as storage for this energy. The new Q-jump atoms and their deletion reserve must stay in the same representation; old H-only deletion conditions cannot be freely substituted. The original continuous N_del is not an extra fresh deletion credit.

## 4. Bounded calculation evidence

Executed 20 exact Fraction diagnostics on clamp laws n=1,2,4,8: eight raw-good energy/weighted-energy atom integrations and twelve same-full-posterior G×B pointwise inequalities eJ²≤M_G,2, with an outside source removed at t=1. Piecewise primitives use fixed threshold intervals, not numerical quadrature. All PASS. These diagnose the algebra only; they do not construct an original FULL/cube/source instance or certify a general receiver payment. General formulas (A)–(E) have the analytic proofs above.


## 5. Stronger moving-leg square gap independent of L

Put r=|y_i−v_i|/b, l=L/b≤a′=A/b≤1, Ω=min(1,C(r)/l), and Δ_b(y,v)=Σ_i[1−C(|y_i−v_i|/b)]. The hard-hard overlap length O between side-l and side-a′ intervals is

\[
 O=\max(0,\min(l,(l+a')/2-r)).
\]

Its fraction O/a′≤(1−r/a′)+≤A0(r). This follows separately when one interval is contained in the other and when the overlap is partial; equivalently O≤(a′−r)+. Since Ω≥C(r),

\[
 \frac{O/a'}\Omega\le\frac{A_0(r)}{C(r)}
 \le1-c_0[1-C(r)],\qquad c_0=\phi(3/2)>1/128.
\]

Important repairs: O cannot be replaced by (l−r)+ when A>L. Also C−A0≥r c0 is only used for 0≤r≤1; a global lower bound c0 min(r,1) is false in the tail. For r≥1, A0=0 proves the displayed ratio bound directly. For r≤1 use the established C−A0≥r c0, 1−C≤r, and C≤1.

For each hard-soft orientation on the common window, if Ω=1 use the source mass and target height to obtain normalized square factor≤L/A≤1. If Ω<1, radial enlargement of BOTH profiles to b gives factor≤(L/A)V/C≤1, in either orientation. The soft-soft term is at most 1+ε, ε=d/b, by the same collar window estimate as R264. Expanding the positive mixture and tensorizing therefore proves

\[
 \boxed{L^n\int_{W_y}
 \frac{P_{s,L}(x-y)P_{\sigma,A}(x-v)}{\bar w_L(y,v)}dx
 \le\exp\{n\varepsilon s\sigma-c_0(1-s)(1-\sigma)\Delta_b(y,v)\}.} \tag{F}
\]

This is the claimed fixed gap. Both moving legs, including clipped A=min(γL,b), qualify. It is stronger than the earlier Δ_L bound, since C≤Ω_L. The low-soft clipped grid preserves a uniform gap coefficient α0=c0(1−s0)². Abel and node/leg summation yield a receiver envelope E_v(x), independent of original t, with

\[
 \|E_v\|_2\le\sqrt D\,a^{-n/2}e^{-\alpha_0\Delta_b(y,v)/2},
 \qquad D=8c_n^2M e^{n\varepsilon s_0^2}
\]

for the sum of the two moving half-legs, with their original barw_L denominator. Original outside coefficients and any already paid weight comparison remain unchanged.

## 6a. Actual positive flow: direct weighted-score measure

Final original-source binding was checked by actually reading R223 frozen negative_contract.md NC2–NC4: c is terminal good, b is terminal bad, and the positive difference is (k_c−k_b)+. Earlier interim messages described the opposite direction as actual; that binding was incorrect and is superseded here. The mathematical reverse-orientation statement below remains valid only as an auxiliary result.

For the actual positive row, integrate its bad slot to obtain

\[
 \int_B(k_c-k_b)_+\,d\Pi_t(b)\le k_c.
\]

Define the FIXED-original-time positive measure

\[
 \mathcal K_{y,j}(dv)=\int_{I_y} k_t(v)\Pi_t(dv)\,dt/t.
\]

It is receiver-independent at fixed original y,j. With Hα=exp(−αΔ_b), the exact same ξ argument and primitive proved below give

\[
 \boxed{\mathcal K_{y,j}(H_\alpha)\le
 \frac2{e\alpha}[1+\log_+(e\alpha n)].}
\]

There is NO initial-degree term, no endpoint 1, and no deletion rho in this upper bound: it integrates kH under the actual probability directly, without differentiating that probability. The original upper-score direction is crucial. Take the receiver envelope from §5 and α=α0/2. Positive removal of original good/history/high masks (after the legitimate good-based half-density inequality) and fixed-t Minkowski yield

\[
 \left\|\int E_v\,d\mathcal K_{y,j}(v)\right\|_2
 \le\sqrt D\,a^{-n/2}\mathcal K_{y,j}(H_{\alpha_0/2}).
\]

Thus the R265 heavy initial-ratio row estimate is genuinely replaced for the current moving positive half-kernel by a logarithmic fixed-time row estimate. All original positive outside constants, authentic β integration, finite j aggregation and receiver multiplicity remain; this does not certify their global budget. Negative credits and signed recovery are untouched. Actual good is never redefined at t; dropping its positive mask enlarges only the already valid positive upper bound.

## 6b. Auxiliary reverse-score clock measure and deletion charge

For the opposite, auxiliary direction δ=(k_bad−k_good)+, integrating the bad slot gives

\[
 \int_B\delta\,\Pi_t(db)\le m_t=\int k_t\,d\Pi_t.
\]

Let I_y be a fixed original valid positive-degree interval at fixed y,j, independent of receiver x. Define the positive measure

\[
 \mathcal N_{y,j}(dv)=\int_{I_y}m_t\Pi_t(dv)\,dt/t.
\]

It is fixed before dx. No relative-time substitution is made. Actual good/history/high/terminal masks may be removed only in the positive bound, retaining the original receiver/j domain as needed. This bounds that AUXILIARY reverse-direction row by ∫E_v(x) dN(v). It is not the source binding for the original R223 positive flow; that uses K in §6a.

For any bounded nonnegative time-independent H(v), put F_t=Π_tH. Between deletion times,

\[
 F_t'=m_tF_t-\Pi_t(k_tH).
\]

On the common interval [l,h], inner endpoints give the EXACT identity

\[
 \boxed{\mathcal N(H)=F_{h-}-F_{l+}
 +\int_l^h\Pi_t(k_tH)\,dt/t
 -\sum_{l<t<h}\Delta F_t.} \tag{G}
\]

At a deletion, survivors renormalize upward, so −ΔF_t≤Π_(t−)(H·1_deleted). This is a positive source charge; it is not the old continuous N_del or a fresh negative credit.

For Hα(v)=exp(−αΔ_b(y,v)), α>0, the original ξ=c_jt/b lies in [a/b,1]⊂[1/2,1]. Every active coordinate C_i<ξ gives Δ_b≥(1−ξ)k_t. Hence

\[
 \Pi_t(k_tH_\alpha)\le
 \sup_{0\le k\le n}k e^{-\alpha(1-\xi)k}
 \le\min\{n,1/[e\alpha(1-\xi)]\}.
\]

Use dlogt=dξ/ξ, 1/ξ≤2 and the same split primitive as R264. A safe explicit bound is

\[
 \boxed{\mathcal N(H_\alpha)\le
 1+\frac2{e\alpha}[1+\log_+(e\alpha n)]+\rho_\alpha,\quad
 \rho_\alpha=\sum\Pi_{t-}(H_\alpha1_{deleted}).} \tag{H}
\]

There is no γ-terminal strip here: the gap itself is independent of L. One may also retain the exact (G), or the crude N(Hα)≤n log2. Finite forest truncation gives finite measures; broader limits require positive monotone/extended-integral care and do not silently erase a singular variation component.

Combining (F) with Minkowski under the FIXED original-time N gives

\[
 \left\|\int E_v\,d\mathcal N(v)\right\|_2
 \le\sqrt D\,a^{-n/2}\mathcal N(H_{\alpha_0/2})
\]

and then (H). This is a valid auxiliary reverse-direction bound with a geometry-weighted deletion row estimate. The full β integral, j sum, receiver multiplicity and ρ charge remain explicit. It is not an original source/root payment.

For comparison, a reverse-BV envelope M dominating every Π_t also exists:

\[
 M=\Pi_{h-}+\int(k-m)_+\Pi_t\,dt/t+
 \sum1_{deleted}\Pi_{t-}.
\]

Its Hα mass obeys the same bound. For a single fixed persistent G⊂Z_h, the deletion term vanishes after restriction to G. Actual terminal-good G_x varies with receiver and terminal g(x); that fact does not justify a single receiver-independent restricted envelope with ρ=0 over the enlarged whole clock. The N construction is a correct auxiliary reverse-direction bridge. It must not be substituted for the sharper actual upper-score K bridge in §6a.

## 7. Uniform J mass gap and fixed-time row consequence

In one dimension on Q_b(z), let D=∫sqrt(P_s,L P_1,b)/sqrtΩ. Cauchy gives D²≤V0/Ω, where V0=∫_[−1/2,1/2]φ≤φ(0)≤φ_1(0)=2(1−e^(−1/2))<4/5. The last strict bound follows, for example, from e<25/9. The R224 bound is simultaneously D²≤1−κ(1−Ω).

If Ω≥9/10 use D²≤8/9. Otherwise use D²≤1−κ/10. Since κ≤10/9, together these give

\[
 \boxed{D\le e^{-c},\qquad c=\kappa/20>0,}
\]

uniformly in source centers, s and L. The R224 normalization is again R=A=b, M=b, m=L; no missing b factor is present.

The common-window collar adds at most ε√(2s) per coordinate exactly as in R265. Thus

\[
 \int_{W_y}F_{s,L}\le
 \exp[-cn+e^c n\varepsilon\sqrt{2s}].
\]

Interpolating this with the existing J square bound gives

\[
 \int_{W_y}F_{s,L}^p\le L^{-n(p-1)}e^{U_p(s)},
\]

\[
 U_p(s)=-(2-p)cn+(2-p)e^c n\varepsilon\sqrt{2s}
 +(p-1)n\varepsilon s.
\]

Abel and the final clipped soft grid give a uniform-in-v Lp receiver column

\[
 A_J=\sqrt{c_n}M^{1/p}C_p^{1/p}
 a^{-n(1-1/p)}e^{U_p(s_0)/p}.
\]

For low soft s0=C logn/n and d=a/(8√n), the exponent is −(2−p)cn+O(√logn). Exponential decay is an asymptotic statement with constants/threshold depending on the tiny fixed audited κ; it is not asserted to dominate the collar for every finite n.

This uniform column can be used at ORIGINAL fixed time t, when the bare Π_(y,j,t) is receiver-independent. Minkowski with the same full pair law and positive removal of masks gives

\[
 \|\iint\delta F_v\,d\Pi_t(v)d\Pi_t(u)\|_p
 \le A_J\,\mathbb E(k-k')_+\le nA_J/4.
\]

The direction of the iid positive difference is immaterial for this full-law bound. Clock length≤log2 therefore yields row price nlog2 A_J/4, without e_tau and without a relative-time posterior substitution. The weaker nlog2 A_J bound is also valid. It would NOT be legitimate to infer this merely from pointwise normalization of Π_(y,ug(x)); the fixed-original-time argument is essential. Full β/j/receiver-volume costs and original prefactors still remain, so this is not a general source payment.

## 8. Additional finite evidence boundary

Executed 162 exact Fraction hard-overlap/Ω checks for the repaired geometry, and 12 ordinary mp50 closed-primitive checks of (H)'s continuous bound. All PASS. They do not certify a FULL example or replace the continuous proofs. No R266 author proof was read for §§5–7. No broad counterexample search was performed.


## 9. Source-direction correction receipt

The final actual-direction conclusion is independently bound to `/Users/zhengzhihao/Desktop/T/output/centered_cube_round223_20261016_final_checkpoint/negative_contract.md`, NC2 definition D_t(c,b)=k_c−k_b and NC4 positive G×B integral. Its NC3 also explicitly gives receiver independence of the bare Π at fixed original (seed,V,j,y,t). No R266 author proof was needed for this correction. Earlier actual bad−good wording in interim screening is superseded, not retained as an alternative convention. All statements involving that orientation are now explicitly marked auxiliary. No numerical rerun was needed: the earlier exact good-slot energy diagnostics already used the now-confirmed actual upper-score orientation.
