# R266: actual carrier reciprocity and a local stationary subsource

Scope: fixed original seed, retained V, physical ratio index j and original t. This note proves exact available source relations; it does not register raw reversibility again as new payment. No receiver-dependent relative-clock posterior is substituted. Only this /tmp file is changed.

## C1. Narrow original-definition audit

All references below are under `/Users/zhengzhihao/Desktop/T/output/`.

* `centered_cube_round113_20261014/joint_budget.md:39–45` (B5):
  D_V(y)=V∩{v:||v-y||_1≤17na}∩{v:||v-y||_∞≤b(5log n+1/2)}.
  Both coordinate distance conditions are symmetric when y,v∈V. Sourceborn restrictions of ν do not change that algebra.
* The same file `:64–79` defines the **original FULL forest**, original hard eligible mass h(A)=μ_hi(A∩{t_C≤b}), top cell T_0(y), and the forbidden block. It is not a partition built from β or from ν mass.
* `:163–175` proves that the coarsest-light nodes, completed by uncovered finest cells, form one common half-open partition. If no light ancestor exists, the original finest cell is the fallback. The distinct-child LCA and strict heaviness exclude two accepted sources from the same block, including a finest heavy fallback; same-top qualification gives the other carrier condition.
* `centered_cube_round114_20261014/proof.md:233–250` (S3–4) replaces the threshold by the common fixed-(j,t) value
  H_j(t)=q max{t^n,√n c_{j+1}^n t^n,√n(t²/b)^n}.
  A_{j,t}(y) is the coarsest h(A)≤H_j(t) ancestor, with the same finest fallback. Thus it is again one common partition, not a separately chosen block for each pair. The actual hard accepted pair remains in Z_{j,V}(y,g).
* `centered_cube_round117_20261014/joint_geometry.md:9–32` (JG1–2), retained in R128 `proof.md:637–650`, gives
  Z_t(y)=D_V(y)∩(T_0(y)\A_{j,t}(y)),
  w_t(y,v)=∏_i min(1,b C(|y_i-v_i|/b)/(c_jt)),
  K_t(y,v)=1_{Z_t(y)}(v)w_t(y,v), e_t(y)=∫K_t(y,v)ν(dv).
  These are fixed before receiver x; the normalized row is Π_y,t=K_t(y,·)ν/e_t(y).
* `centered_cube_round113_20261014/coupled_transport.md:51–82` (C6–8) preserves the actual hard tail and proves ν≤β^c≤α. It does not prove β≤ν or an upper bound on dβ/dν. Subsequent actual high, terminal classifier, process and history gates are not included in the raw K_t just defined.

Consequently for y,v∈V the exact raw kernel obeys

(1) K_t(y,v)=K_t(v,y).

Proof: equal top-cell membership is symmetric; membership in different blocks of one partition is symmetric; the two distance gates and the product w_t are symmetric. Half-open conventions give a unique partition block, so no arbitrary boundary choice is required. Fixing the same seed,V,j,t is essential. Different seeds/forests or one-sided process/high gates cannot be exchanged by (1).

## C2. What is stationary, and which sources it covers

Define Π_y=0 when e_y=0, and use the true normalized row when e_y>0. Then on ν×ν

(2) e_y ν(dy)Π_y(dv)=K_t(y,v)ν(dy)ν(dv)
                       =e_v ν(dv)Π_v(dy).

In particular eν is stationary: ∫e_yν(dy)Π_y(dv)=e_vν(dv). The missing zero-degree set contributes zero to both sides by Tonelli. This is a raw single-transition statement, not a claim that β or ν itself is stationary.

There is a concrete local stationary measure genuinely dominated by the original β. For each original top cell T put N_T=ν(V∩T). For N_T>0 define

(3) σ_t(dy)=1_{V∩T}(y) [e_t(y)/N_T]ν(dy),

and take zero on top cells with N_T=0. All K edges remain within one T, and 0≤e_t(y)≤N_T. Thus σ_t≤ν≤β and

(4) σ_t(dy)Π_y(dv)=σ_t(dv)Π_v(dy),   ∫σ_t(dy)Π_y(dv)=σ_t(dv).

Top cells are the original countable Borel partition, N_T is its actual ν mass, and e is a jointly measurable kernel integral. Hence (3) is a measurable construction. For a positive original traffic one may allocate the time-dependent fraction

r_t(y)=(e_t(y)/N_{T_0(y)}) (dν/dβ)(y)∈[0,1],

with zero branches as above. This keeps the original β,ν and posterior and merely splits that positive measure into σ_t and β−σ_t. It does not rebuild the extracted source, extend a cut/rank property to β, or allocate an original negative credit. Since σ_t varies with t, it is not a new source measure fixed through the whole clock.

For any nonnegative target F(v), each top cell separately satisfies the useful inverse-half-weight column estimate

(5) ∫_{V∩T}σ_t(dy)∫Π_y(dv) F(v)/√w_t(y,v)
    ≤∫_{V∩T}F(v)√[e_t(v)/N_T]ν(dv)
    ≤∫_{V∩T}F(v)ν(dv).

The integrand is zero outside Z; w_t>0 on finite source displacements. To prove (5), expand σ_tΠ_y/√w_t as N_T^{-1}1_Z√w_t ν(dy)ν(dv). For fixed v, symmetry and Cauchy give ∫1_Z√w_t ν(dy)≤√(N_T e_t(v)). Thus this partial-source column has an explicit local price and no inverse degree. The remainder β−σ_t is not bounded by this conclusion.

If p_y(x) is the actual anchor and F_x(v) is independent of y, source FIRST also gives the exact partial-source Cauchy bound

(6) ∫σ_t(dy)∫Π_y(dv)√[p_y(x)F_x(v)/w_t(y,v)]
    ≤√[q∫F_x(v)ν(dv)].

Indeed the first square integral is ∫p_yσ_t≤∫p_yβ≤q; the second is ∫σ_tΠ_y F_x/w_t≤∫F_xν, since ∫1_Zν(dy)≤N_T on each top cell. The inequality is extended nonnegative when the target integral is infinite. It has the clock denominator w_t, not w_g. Their exact ratio and the moving target's receiver column remain to be paid. On the original high subtraffic the old full-β TR3 bound below is already stronger in its K dependence, so (6) is not called a new original payment.

## C3. The exact complete-β column and original FIRST cap

Since ν≤β, the positive excess ξ=β−ν is well defined. For ν-almost every v with e_v>0,

(7) ∫β(dy) K_t(y,v)/e_y
    =e_v∫Π_v(dy)/e_y +∫ξ(dy)K_t(y,v)/e_y,

where the integrand is zero at e_y=0. Equality is extended nonnegative. The first term has the **reverse degree ratio**, and the second has genuine excess soft source. Neither is generally replaced by 1. The zero-degree v case has a zero ν-almost-everywhere column by Tonelli; no assertion is made at an exceptional ν-null point.

A particularly important positive restriction is the authentic fixed-receiver high/valid mask H_{x,t}(y). Original high says p_y(x)e_g(y)≥2Kq, and t≤g gives e_t≥e_g. Therefore

(8) ∫H_{x,t}(y)β(dy)/e_t(y)
    ≤(2Kq)^{-1}∫p_y(x)β(dy)≤1/(2K),

and consequently the H-restricted column in (7) is ≤1/(2K), because K_t≤1. This is exactly the existing R224 `traffic_reentry.md:41–80`, not an unweighted all-y cap. The operator form retains both source factors:

A_{x,t}=∫H p_yβ≤q,
m_{x,t}(v)=∫H sqrt(p_y(x))1_{Z_t(y)}(v)√w_t(y,v)β(dy)/e_t(y),
∫m_{x,t}(v)²ν(dv)≤A_{x,t}∫Hβ/e_t≤q/(2K).

The high mask is receiver dependent. One cannot use (8), then drop H and claim the same bound for the complete column (7), or cap an adaptive target receiver integral by a fixed density normalization. This is why full FIRST does not bound R265's β-integrated initial heavy ratios after its receiver relaxation.

## C4. Why this is not an exchange of the full two-posterior traffic

Even for the shared ν source, detailed balance exchanges only one transition. The original second posterior has the same anchor y. Its density under the stationary mother is proportional to

K_t(y,v)K_t(y,u)/e_y ·ν(dy)ν(dv)ν(du),

whereas exchanging y↔v produces K_t(y,v)K_t(v,u)/e_v. The two differ both by degrees and by a genuine missing-edge factor. K_t(v,u) can vanish because v,u lie in the same forbidden block or outside their mutual distance gate even when both connect to y. The original pair score k_t(y,v)−k_t(y,u), terminal good/bad classifier, hard-source capture and history also do not become the corresponding exchanged objects automatically. Symmetry of the scalar two-point k_t itself does not identify this three-source score with a state Dirichlet form.

Thus (3)–(6) provide a constructive reversible **positive source fraction** and its local single-column payment. They do not pay β−σ_t, a moving receiver target, the w_t/w_g factor, the second-posterior correlation, time integration or j summation. R265's complete heavy source price is not controlled by these identities. No existing negative credit has been found that estimates the two explicit terms in (7) on the changed R222 positive baseline; the original negative mother must remain intact.

## C5. Actual bounded arithmetic check

A Python Fraction test ran three symmetric positive kernels. The exact executed count is **27 checks**: nine stationarity columns, nine full-β/shared/excess column equalities, and nine source domination checks. It returned `PASS 27 max_stationary_fraction 2/3`, exit 0. These finite rational kernels test the algebra, not actual C values, FULL/history or a general geometry theorem. Complete code:

```python
from fractions import Fraction as F
checks=0;maxfrac=F(0)
for scale in (F(1,2),F(1),F(2)):
    nu=[F(1),F(2),F(3)]; beta=[F(3,2),F(2),F(4)]
    K=[[F(0),min(F(1),scale*F(1,2)),min(F(1),scale*F(1,3))],
       [min(F(1),scale*F(1,2)),F(0),min(F(1),scale*F(2,3))],
       [min(F(1),scale*F(1,3)),min(F(1),scale*F(2,3)),F(0)]]
    N=sum(nu)
    e=[sum(K[i][j]*nu[j] for j in range(3)) for i in range(3)]
    sig=[e[i]*nu[i]/N for i in range(3)]
    pi=[[K[i][j]*nu[j]/e[i] for j in range(3)] for i in range(3)]
    for j in range(3):
        assert sum(sig[i]*pi[i][j] for i in range(3))==sig[j]
        checks+=1
        col=sum(beta[i]*K[i][j]/e[i] for i in range(3))
        rev=e[j]*sum(pi[j][i]/e[i] for i in range(3))
        excess=sum((beta[i]-nu[i])*K[i][j]/e[i] for i in range(3))
        assert col==rev+excess
        checks+=1
    for i in range(3):
        assert sig[i]<=nu[i]<=beta[i]
        maxfrac=max(maxfrac,sig[i]/beta[i])
        checks+=1
print('PASS',checks,'max_stationary_fraction',maxfrac)
```
