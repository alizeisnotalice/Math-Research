#!/usr/bin/env python3
import argparse,hashlib,json,subprocess,sys,tempfile
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
p=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--check-only',action='store_true');args=ap.parse_args()
manifest=json.loads((p/'manifest.json').read_text())
def check():
    for name,h in manifest.items():
        assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h,name
check()
j=json.loads((p/'numeric_checks.json').read_text())
assert j['script_sha256']==hashlib.sha256((p/'numeric_checks.py').read_bytes()).hexdigest()
with localcontext() as ctx:
    ctx.prec=100
    for row in j['mp70']['posterior']['cases']:
        assert Decimal(row['weighted_score_KH'])<=Decimal(row['clock_upper_envelope_integral'])+Decimal('1e-60')
        assert Decimal(row['clock_upper_envelope_integral'])<=Decimal(row['clock_analytical_C_alpha'])
# Reproduce the source-reciprocity appendix's 27 exact finite checks.
checks=0
for scale in (F(1,2),F(1),F(2)):
    nu=[F(1),F(2),F(3)];beta=[F(3,2),F(2),F(4)]
    K=[[F(0),min(F(1),scale*F(1,2)),min(F(1),scale*F(1,3))],
       [min(F(1),scale*F(1,2)),F(0),min(F(1),scale*F(2,3))],
       [min(F(1),scale*F(1,3)),min(F(1),scale*F(2,3)),F(0)]]
    N=sum(nu);e=[sum(K[i][k]*nu[k] for k in range(3)) for i in range(3)]
    sig=[e[i]*nu[i]/N for i in range(3)]
    pi=[[K[i][k]*nu[k]/e[i] for k in range(3)] for i in range(3)]
    for k in range(3):
        assert sum(sig[i]*pi[i][k] for i in range(3))==sig[k];checks+=1
        assert sum(beta[i]*K[i][k]/e[i] for i in range(3))==e[k]*sum(pi[k][i]/e[i] for i in range(3))+sum((beta[i]-nu[i])*K[i][k]/e[i] for i in range(3));checks+=1
    for i in range(3):assert sig[i]<=nu[i]<=beta[i];checks+=1
assert checks==27
# Author's eight finite constant/continuous/deletion checks.
kap=F(25,2**68)
assert F(29,48)>F(3,5) and F(8,9)<=1-kap/10
for ks in ([0,1,3],[2,0,1],[1,2,2]):
    mu=[F(1,3),F(2,5),F(3,7)];H=[F(1,2),F(1,3),F(3,4)]
    e=sum(mu);pi=[x/e for x in mu];m=sum(k*q for k,q in zip(ks,pi));Q=sum(h*q for h,q in zip(H,pi));KH=sum(h*k*q for h,k,q in zip(H,ks,pi))
    assert sum(h*(m-k)*q for h,k,q in zip(H,ks,pi))==m*Q-KH
    keep=[0,2];ep=sum(mu[i] for i in keep)
    assert sum(H[i]*mu[i]/ep for i in keep)-Q==(1/ep-1/e)*sum(H[i]*mu[i] for i in keep)-H[1]*mu[1]/e
if not args.check_only:
    with tempfile.TemporaryDirectory() as t:
        out=Path(t)/'result.json'
        subprocess.run([sys.executable,str(p/'numeric_checks.py'),'--output',str(out)],check=True)
        assert out.read_bytes()==(p/'numeric_checks.json').read_bytes(),'JSON mismatch'
check()
print('PASS: manifest pre/post, 9 saved KH/clock bounds, 27+8 exact appendix checks; '+('saved evidence only' if args.check_only else 'full numeric replay byte-identical')+'; no FULL/global certificate.')
