#!/usr/bin/env python3
"""Round 44: exact rational guards and interval-certified finite-source bounds.
Standard library only. Grid certificates bound all positive thresholds; a grid
is not an exact optimizer. Root intervals and rectangle volumes use Fraction.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations, product
import json
import time
from pathlib import Path


def fs(q):
    return str(q)


def merge(points, weights):
    d = {}
    for p, w in zip(points, weights):
        p = tuple(map(F, p)); w = F(w)
        assert w > 0
        d[p] = d.get(p, F(0)) + w
    mass = sum(d.values(), F(0))
    return tuple(sorted(d)), tuple(d[p] / mass for p in sorted(d)), mass


def families(points, weights):
    n = len(points[0]); N = len(points); ans = []
    for mask in range(1, 1 << N):
        ids = [j for j in range(N) if mask >> j & 1]
        lo = tuple(min(points[j][i] for j in ids) for i in range(n))
        hi = tuple(max(points[j][i] for j in ids) for i in range(n))
        mass = sum((weights[j] for j in ids), F(0))
        close = sum(1 << j for j, p in enumerate(points)
                    if all(lo[i] <= p[i] <= hi[i] for i in range(n)))
        ans.append((mask, mass, lo, hi, close))
    return tuple(ans), tuple(a for a in ans if a[0] == a[4])


@lru_cache(None)
def root_interval(q, n, bits):
    """Monotone dyadic brackets: roots <=1 use [0,1]; larger roots use
    [2^k,2^(k+1)]. Within a bin the fixed-bit dyadic grid is shared;
    adjacent bins share an endpoint. Thus both enclosure endpoints are
    nondecreasing in q. Exact roots at dyadic grid points are collapsed.
    """
    assert q > 0
    if n == 1:
        return q, q
    hi = F(1)
    while hi ** n < q:
        hi *= 2
    if hi ** n == q:
        return hi, hi
    lo = F(0) if hi == 1 else hi / 2
    for _ in range(bits):
        mid = (lo + hi) / 2
        v = mid ** n
        if v == q:
            return mid, mid
        if v < q:
            lo = mid
        else:
            hi = mid
    assert lo ** n <= q <= hi ** n
    return lo, hi


def prune(boxes):
    boxes = sorted(set(b for b in boxes if all(l < h for l, h in b)))
    return tuple(b for k, b in enumerate(boxes)
                 if not any(k != j and all(c[i][0] <= b[i][0] and b[i][1] <= c[i][1]
                                            for i in range(len(b)))
                            for j, c in enumerate(boxes)))


@lru_cache(maxsize=100000)
def union_volume(boxes):
    boxes = prune(boxes)
    if not boxes:
        return F(0)
    cuts = sorted(set(z for b in boxes for z in b[0]))
    total = F(0)
    for l, h in zip(cuts, cuts[1:]):
        mid = (l + h) / 2
        active = tuple(b for b in boxes if b[0][0] < mid < b[0][1])
        if active:
            section = F(1) if len(boxes[0]) == 1 else union_volume(tuple(b[1:] for b in active))
            total += (h - l) * section
    return total


def inclusion_exclusion(boxes):
    boxes = prune(boxes); total = F(0)
    for k in range(1, len(boxes) + 1):
        for group in combinations(boxes, k):
            v = F(1)
            for i in range(len(boxes[0])):
                width = min(b[i][1] for b in group) - max(b[i][0] for b in group)
                v *= max(F(0), width)
            total += v if k % 2 else -v
    return total


def envelope(fam, lam, n, bits):
    inner = []; outer = []
    for _, mass, lo, hi, _ in fam:
        rl, ru = root_interval(mass / lam, n, bits)
        inner.append(tuple((hi[i] - rl / 2, lo[i] + rl / 2) for i in range(n)))
        outer.append(tuple((hi[i] - ru / 2, lo[i] + ru / 2) for i in range(n)))
    inner = prune(inner); outer = prune(outer)
    vl, vu = union_volume(inner), union_volume(outer)
    assert vl <= vu
    return vl, vu, inner, outer


def exact_max(points, weights, x):
    n = len(x); events = {}
    for p, w in zip(points, weights):
        r = max(abs(x[i] - p[i]) for i in range(n))
        if r == 0:
            return None  # infinity at an atom
        events[r] = events.get(r, F(0)) + w
    mass = F(0); best = F(0)
    for r in sorted(events):
        mass += events[r]  # all ties enter together
        best = max(best, mass / (2 * r) ** n)
    return best


def subset_hit(fam, points, x, lam):
    n = len(x)
    return any(lam * (2 * max(max(abs(x[i] - points[j][i]) for i in range(n))
                                   for j in range(len(points)) if mask >> j & 1)) ** n < mass
               for mask, mass, _, _, _ in fam)


def receiver_points(points):
    n = len(points[0])
    axes = []
    for i in range(n):
        vals = sorted(set(p[i] for p in points))
        axes.append(sorted(set([vals[0] - 1, vals[-1] + 1] + vals +
                               [(l + h) / 2 for l, h in zip(vals, vals[1:])])))
    return tuple(product(*axes))


def certificate(points, weights, fam, bits, ratio):
    n = len(points[0]); N = len(points)
    if N == 1:
        return dict(scope="all positive lambda; one merged atom", lower="1", upper="1", intervals=0)
    D = max(max(p[i] for p in points) - min(p[i] for p in points) for i in range(n))
    s = min(max(abs(p[i] - q[i]) for i in range(n)) for p, q in combinations(points, 2))
    amin = min(weights)
    low = (amin / (2 * n * D)) ** n; high = s ** (-n)
    assert D > 0 and s > 0 and low < high
    # Exact high-tail proof guards: radius of every singleton <= s; every
    # nonsingleton has span >= s and total mass <=1, so its open box is empty.
    for mask, mass, lo, hi, _ in fam:
        span = max(hi[i] - lo[i] for i in range(n))
        if mask.bit_count() > 1:
            assert mass <= high * span ** n
        else:
            assert mass / high <= s ** n
    # Low-tail analytic guard: every proper closed subset omits >=amin mass.
    for mask, mass, lo, hi, _ in fam:
        if mask != (1 << N) - 1:
            assert 1 - mass >= amin
    assert low * (2 * n * D / amin) ** n == 1
    grid = [low]
    while grid[-1] < high:
        grid.append(min(high, grid[-1] * ratio))
    assert all(F(1) < y / x <= ratio for x, y in zip(grid, grid[1:]))
    L = F(1); U = F(1); widths = []
    values = []
    for lam in grid:
        vl, vu, _, _ = envelope(fam, lam, n, bits)
        L = max(L, lam * vl)
        values.append((vl, vu)); widths.append(lam * (vu - vl))
    for k in range(len(grid) - 1):
        U = max(U, grid[k + 1] * values[k][1])
    assert L <= U
    return dict(scope="all positive lambda; certified analytic tails and finite geometric grid",
                lower=fs(L), upper=fs(U), lower_decimal=float(L), upper_decimal=float(U),
                root_bits=bits, grid_ratio=fs(ratio), intervals=len(grid)-1,
                lambda_low=fs(low), lambda_high=fs(high), amin=fs(amin), D=fs(D), s=fs(s),
                max_lambda_volume_envelope_gap=fs(max(widths)),
                note="L<=sup_lambda lambda*V(lambda)<=U; U is not an exact maximum")


def oracle(lam):
    if lam <= F(1, 4): return 1 - lam
    if lam <= F(3, 4): return lam + F(1, 2)
    if lam <= 1: return 2 - lam
    return F(1)


def fixtures():
    templates = [
        ("unequal", [(0, 0), (1, 2), (3, 1)], [1, 2, 7]),
        ("collinear", [(j, 2*j) for j in range(5)], [1, 3, 2, 7, 1]),
        ("nested", [(-2, -2), (-1, 1), (0, 0), (2, 2)], [1, 2, 11, 3]),
        ("correlated", [(0, 0), (1, 1), (2, 2), (3, 3), (2, 0)], [9, 1, 2, 1, 4]),
        ("duplicates", [(0, 0), (0, 0), (1, 2), (3, 1)], [1, 5, 2, 1]),
        ("spike", [(0, 0)], [37]),
    ]
    ans = []
    for name, pts, ws in templates:
        for n in (1, 2):
            ans.append((name + "_n" + str(n), [p[:n] for p in pts], ws))
    for n in (3, 4):
        ans.append(("two_correlated_n" + str(n), [tuple(0 for _ in range(n)), tuple(i+1 for i in range(n))], [1, 7]))
        ans.append(("three_nested_n" + str(n), [tuple(-2 for _ in range(n)), tuple(0 for _ in range(n)), tuple(2 for _ in range(n))], [1, 19, 2]))
    return ans


def main():
    start = time.monotonic(); out = []; sources = {}; point_count = 0; ie_count = 0
    for name, pts, ws in fixtures():
        points, weights, rawmass = merge(pts, ws); n = len(points[0]); full, closed = families(points, weights)
        sources[name] = (points, weights, full, closed)
        receivers = receiver_points(points)
        boundary_tests = 0
        for x in receivers:
            M = exact_max(points, weights, x)
            if M is None:
                test_lambdas = (F(1), F(10**6))
            else:
                test_lambdas = (M / 2, M, 2 * M)
            for boundary_lam in test_lambdas:
                hit = M is None or M > boundary_lam
                assert hit == subset_hit(full, points, x, boundary_lam) == subset_hit(closed, points, x, boundary_lam)
                boundary_tests += 1
                point_count += 1
        out.append(dict(stage="strict_boundary_membership", source=name, n=n,
                        receiver_tests=boundary_tests,
                        note="Includes lambda=exactM with strict exclusion, tied entries, and atom points with M=infinity",
                        status="PASS"))
        for lam in (F(1, 4), F(1), F(4)):
            roots = [root_interval(mass / lam, n, 16) for mass in sorted(set(a[1] for a in full))]
            assert all(a[0] <= b[0] and a[1] <= b[1] for a, b in zip(roots, roots[1:]))
            vl, vu, ib, ob = envelope(full, lam, n, 16)
            cl, cu, _, _ = envelope(closed, lam, n, 16)
            assert (vl, vu) == (cl, cu), (name, "closure envelopes")
            done = 0
            for b in (ib, ob):
                if len(b) <= 10:
                    assert union_volume(b) == inclusion_exclusion(b)
                    done += 1; ie_count += 1
            for x in receivers:
                M = exact_max(points, weights, x)
                hit = M is None or M > lam
                assert hit == subset_hit(full, points, x, lam) == subset_hit(closed, points, x, lam)
                point_count += 1
            out.append(dict(stage="exact_geometry", source=name, n=n, raw_atoms=len(pts), merged_atoms=len(points),
                            raw_mass=fs(rawmass), normalized_mass="1", subsets=len(full), closed_subsets=len(closed),
                            lambda_value=fs(lam), root_bits=16, volume_lower=fs(vl), volume_upper=fs(vu),
                            receiver_tests=len(receivers), inclusion_exclusion_checks=done,
                            status="PASS"))
    # Precision stages are compared for the same actual source and threshold.
    for name in ("unequal_n2", "nested_n2", "two_correlated_n4", "three_nested_n3"):
        points, weights, full, closed = sources[name]; n = len(points[0])
        for lam in (F(1, 7), F(3, 2)):
            prior = None
            for bits in (8, 16, 24):
                vl, vu, _, _ = envelope(closed, lam, n, bits)
                if prior: assert prior[0] <= vl <= vu <= prior[1]
                prior = (vl, vu)
                out.append(dict(stage="nested_root_precision", source=name, lambda_value=fs(lam), root_bits=bits,
                                volume_lower=fs(vl), volume_upper=fs(vu), status="PASS"))
    # Global certificates use only a few finite sources; dimension is not fitted.
    for name, bits, ratio in (("spike_n2",16,F(2)), ("collinear_n1",16,F(3,2)),
                              ("unequal_n2",16,F(2)), ("nested_n2",24,F(3,2)),
                              ("two_correlated_n3",16,F(2)), ("three_nested_n4",16,F(2)),
                              ("unequal_n2",24,F(9,8)), ("two_correlated_n3",24,F(9,8))):
        points, weights, full, closed = sources[name]
        c = certificate(points, weights, closed, bits, ratio)
        out.append(dict(stage="global_threshold_certificate", source=name, status="PASS", **c))
    points, weights, _ = merge([(0,), (1,)], [1,1]); full, closed = families(points, weights)
    for lam in (F(1,100),F(1,4),F(1,3),F(1,2),F(3,4),F(4,5),F(1),F(2),F(100)):
        vl, vu, _, _ = envelope(closed, lam, 1, 8)
        assert vl == vu and lam*vl == oracle(lam)
        out.append(dict(stage="two_atom_exact_oracle", lambda_value=fs(lam), weak_ratio=fs(lam*vl), status="PASS"))
    oracle_certificates = []
    for ratio in (F(2),F(3,2),F(9,8)):
        c = certificate(points, weights, closed, 8, ratio)
        assert F(c["lower"]) <= F(5,4) <= F(c["upper"])
        oracle_certificates.append(c)
        out.append(dict(stage="oracle_global_certificate", source="equal_two_atoms_n1", exact_supremum="5/4", status="PASS", **c))
    # An observed exact guard for this oracle; not a monotonicity claim for arbitrary grids.
    assert all(F(y["upper"]) <= F(x["upper"]) for x,y in zip(oracle_certificates,oracle_certificates[1:]))
    counts = {}
    for row in out: counts[row["stage"]] = counts.get(row["stage"], 0) + 1
    certs = [r for r in out if r["stage"] in ("global_threshold_certificate","oracle_global_certificate")]
    result = dict(round=44, status="PASS", arithmetic="standard-library Fraction; root enclosures by exact rational bisection",
                  total_cases=len(out), counts=counts, point_membership_comparisons=point_count,
                  independent_inclusion_exclusion_comparisons=ie_count, source_cases=len(sources),
                  dimensions=sorted(set(len(v[0][0]) for v in sources.values())),
                  merged_atom_count_range=[min(len(v[0]) for v in sources.values()),max(len(v[0]) for v in sources.values())],
                  full_threshold_certificate_intervals=sum(c["intervals"] for c in certs),
                  certificate_upper_range=[min(c.get("upper_decimal",1) for c in certs),max(c.get("upper_decimal",1) for c in certs)],
                  limitations=["Finite positive atomic sources only; no dimension-asymptotic estimate or sqrt(n) upper bound.",
                               "Receiver points only guard the exact two independent formulas; they are not volume quadrature.",
                               "Full-threshold grid produces certified bounds, not an exact optimizer.",
                               "Inclusion-exclusion is restricted to pruned unions with at most ten boxes.",
                               "No external files, floating-point geometry, solver, or literature assumptions are needed."],
                  cases=out)
    path = Path(__file__).with_name("results.json")
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
    summary = {k:result[k] for k in ("status","total_cases","counts","point_membership_comparisons",
                                     "independent_inclusion_exclusion_comparisons","full_threshold_certificate_intervals")}
    summary["runtime_seconds"] = time.monotonic() - start
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
