"""Exact public position couplings with real cube incidence and Lebesgue capacities."""

from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
from math import prod
from sys import version

DELTA = F(1, 16)
LAMBDA = F(2, 3)
MIDDLE = F(3, 4)
OLD = F(1, 2)


def box(center, radius):
    return tuple((c - radius, c + radius) for c in center)


def mass(a, b=None):
    if b is None:
        return prod(hi - lo for lo, hi in a)
    return prod(max(F(0), min(hi, hi2) - max(lo, lo2))
                for (lo, hi), (lo2, hi2) in zip(a, b))


def inflate(a):
    return tuple((lo - (hi - lo) * DELTA / 2, hi + (hi - lo) * DELTA / 2)
                 for lo, hi in a)


@dataclass(frozen=True)
class History:
    name: str
    center: tuple
    k: int
    pool_half: F
    cutoff: F
    beta: F

    def geometry(self):
        signs = list(product((-1, 1), repeat=len(self.center)))[:2*self.k]
        owners = [tuple(x + sign for x, sign in zip(self.center, s)) for s in signs]
        pool_centers = [tuple(x + F(5, 8) * sign for x, sign in zip(self.center, s))
                        for s in signs]
        positions = [box(c, self.pool_half) for c in pool_centers]
        small_cores = [box(c, self.pool_half) for c in owners]
        small_parents = [box(c, OLD) for c in owners]
        root_core = box(self.center, self.pool_half)
        parent = box(self.center, MIDDLE)
        return parent, root_core, small_parents, small_cores, positions


def map_budget(coupling, edges):
    row, col = {}, {}
    for (i, j) in edges:
        value = coupling.get((i, j), F(0))
        row[i] = row.get(i, F(0)) + value
        col[j] = col.get(j, F(0)) + value
    return row, col


def pay(weights, coupling, threshold):
    return sum(weights[e] * min(F(1), coupling.get(e, F(0)) / threshold) for e in weights)


def solve(history, global_e):
    parent, root, old, cores, positions = history.geometry()
    n, k = len(parent), history.k
    h = mass(root)
    t = history.cutoff * h
    beta = history.beta
    assert F(1, 2) < history.cutoff <= 1 and 0 <= beta < 1 and h / k <= t
    assert len(positions) == len(cores) == 2*k
    assert all(mass(p) == h for p in (*cores, *positions))

    # This single global set is used for every history. Restricted intersections
    # are full positive-width cells or empty, so no discretization error.
    expanded_parent = inflate(parent)
    active = [p for p in global_e if mass(p, expanded_parent) != 0]
    volume_e = sum(mass(p, expanded_parent) for p in global_e)
    assert set(active) == {root, *positions} and volume_e == (2*k + 1)*h
    for i, small in enumerate(old):
        expanded_small = inflate(small)
        assert {p for p in active if mass(p, expanded_small)} == {positions[i]}
        assert mass(positions[i], parent) == mass(positions[i], small) == h
        assert mass(positions[i], expanded_parent) == mass(positions[i], expanded_small) == h

    # mu has density one, hence original physical source mass equals volume.
    m_t = mass(parent)
    m_small = {mass(cube) for cube in old}
    overlap = {mass(parent, cube) for cube in old}
    assert m_small == {F(1)} and overlap == {F(1, 4)**n}
    a = next(iter(overlap))
    arm = h * a
    d = 2*k*arm/m_t
    omega = h * arm**2 / (m_t*m_t*d)
    # The two true c values are a/m_u=a/m_g (chi=1).
    # D*m_t*J/(m_u*m_g*c^-*c^+)=J/t.
    price_scale = a*a / (m_t*t)
    assert price_scale*m_t/(a*a) == 1/t

    diag = {(i, i) for i in range(k)}
    cycle = {(i, (i + 1) % k) for i in range(k)} if beta else set()
    assert diag.isdisjoint(cycle)
    gates = {e: F(1) for e in diag} | {e: beta for e in cycle}
    # Restrict the true W-core for the cycle records by an actual first-axis cut.
    weights = {}
    for (i, j), retain in gates.items():
        w = cores[k+j]
        lo, hi = w[0]
        selected = ((lo, lo + retain*(hi-lo)), *w[1:])
        assert mass(selected) / mass(w) == retain
        right_arm = mass(selected)*mass(parent, old[k+j])/mass(old[k+j])
        left_arm = mass(cores[i])*mass(parent, old[i])/mass(old[i])
        weights[i, j] = h * left_arm * right_arm / (m_t*m_t*d)
    assert weights == {e: omega * weight for e, weight in gates.items()}
    original = sum(weights.values())
    assert original == k * (1+beta) * omega

    # A positive repeated coupling lives on whole cross-cell rectangles, with
    # constant joint density x_ij/h^2. Marginal row and column integrals are from
    # these rectangles. The same-location alternative has zero on every edge.
    assert all(mass(positions[i], positions[k+j]) == 0 for i, j in gates)
    same_location = F(0)
    all_e_independent = pay(weights, {e: h*h/volume_e for e in gates}, t)
    best_independent = pay(weights, {e: h/k for e in gates}, t)
    # Rank-one upper bound: for any mass r, sum p_i q_pi(i)/r <= h.
    # Apply separately to diag and cycle, and then use min(1,x/t) <= x/t.
    assert best_independent == omega*(1+beta)*h/t
    assert all_e_independent == k*(1+beta)*omega*h*h/(volume_e*t)

    # Common LP uses paid mass y_ij=min(J_ij,t). To audit optimality it suffices
    # to restrict J to the active edges; adding other mass cannot pay a record.
    assert beta or t == h
    primal = {e: t for e in diag} | {e: h-t for e in cycle}
    assert all(0 <= value <= t for value in primal.values())
    rows, cols = map_budget(primal, gates)
    assert set(rows) == set(cols) == set(range(k))
    assert all(value == h for value in (*rows.values(), *cols.values()))
    objective = pay(weights, primal, t)

    dual_row = dual_col = beta*omega/(2*t)
    dual_claim = {e: (1-beta)*omega/t if e in diag else F(0) for e in gates}
    assert all(dual_row + dual_col + dual_claim[e] >= weights[e]/t for e in gates)
    dual = k*h*(dual_row+dual_col) + t*sum(dual_claim.values())
    assert objective == dual
    separate = pay(weights, {e: t for e in gates}, t)
    odds = len(diag) + len(cycle)
    loose_usage = (1 + int(beta > 0)) * t/h
    assert separate == original
    if beta:
        assert loose_usage > 1 and same_location < all_e_independent < best_independent < objective < separate
    assert m_t <= F(3, 2)**n

    print(f"  {history.name} n={n} K={k}, active records={odds}, each capacity h={h}, |E_t|/h={volume_e/h}")
    print(f"    original m_t={m_t}, m_u=m_g=1, each original intersection mass={a}")
    print(f"    c^-=c^+={a}, d={d}, D={price_scale}, clipping threshold/h={t/h}, cycle weight={beta}")
    print(f"    actual omega per diagonal={omega}, total original={original}")
    print(f"    paid original fractions, same point / full E independent / best separable / joint / per-record = "
          f"{same_location/original} / {all_e_independent/original} / {best_independent/original} / "
          f"{objective/original} / {separate/original}")
    print(f"    exact joint paid mass={objective}, {k} true rows and {k} true columns saturated at h")
    cycle_statement = f", each cycle mass/h={1-t/h}" if cycle else ""
    print(f"    each diagonal mass/h={t/h}{cycle_statement}, relaxed mass use/h per row or column={loose_usage}")
    print(f"    normalized dual (h/omega), each row and column={dual_row*h/omega}, "
          f"each diagonal clip cap={dual_claim[min(diag)]*h/omega}")
    return (original, same_location, all_e_independent, best_independent, objective, separate)


def stage(label, descriptions):
    histories = []
    n = descriptions[0][1]
    for shift, (name, dimension, k, denominator, cutoff, beta) in enumerate(descriptions):
        assert dimension == n
        center = (F(5*shift),) + (F(0),)*(n-1)
        histories.append(History(name, center, k, F(1, denominator), cutoff, beta))
    global_e = []
    for history in histories:
        _, root, _, cores, positions = history.geometry()
        global_e.extend([root, *cores, *positions])
    assert all(mass(a, b) == 0 for a, b in combinations(global_e, 2))
    # Every point in every core and position has all centered side-[1,2]
    # witnesses inside the same finite unit-density background [-4,8]^n.
    assert all(lo - 1 >= -4 and hi + 1 <= 8 for cell in global_e for lo, hi in cell)
    assert LAMBDA < 1 <= 2*LAMBDA
    print(f"{label}, global E has {len(global_e)} actual disjoint cells and volume={sum(map(mass,global_e))}.")
    totals = tuple(map(sum, zip(*(solve(history, global_e) for history in histories))))
    print(f"  aggregate original={totals[0]}, aggregate exact joint payment={totals[4]}, "
          f"joint/original={totals[4]/totals[0]}")


if __name__ == "__main__":
    print(f"Python {version.split()[0]}, exact Fraction.")
    print("Fixed physical middle side 3/2 and old side 1, delta=1/16. Actual source mu has unit density.")
    print("All genuine roots, left/right receiving cores and position pools are in the window height band with lambda=2/3.")
    print("The full original model here is |E_root|/(m_t^2 d) times the product of two arms")
    print("dmu(z) 1_{z in A_t intersect A_i} dU / m_i. The stated W-subcores select the records.")
    print("The earlier full historical R813 gates are outside the scope of this exact physical subflow.")
    stage("INITIAL", [("v0", 2, 2, 16, F(1), F(0))])
    stage("PRESSURE", [("v0", 3, 3, 32, F(3, 4), F(1, 2))])
    stage("EXPANDED", [("v0", 5, 8, 64, F(5, 8), F(1, 4)),
                       ("v1", 5, 6, 64, F(7, 8), F(3, 4))])
