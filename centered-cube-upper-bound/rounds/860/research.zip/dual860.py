"""Exact leftover-mask dual at the saved R860 hard-cut diagnostic.

For clips min(1,(h_left+h_right)/gamma), retaining a fraction s of each
original record pays a deletion cost (1-s) times its actual weight. A
feasible inequality D_C(y) <= u_y + v_C then pays the retained linear
score by the true mu_B input stock and the true Lebesgue output density.
This script finds no deletion or source-stock price in the fixed case.
"""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import runpy
import sys

PUBLIC = "5592e50a9c03b822ab3e36d592a1556f7d14cf34658f4fac7c516b4251a16839"
TAU = F(246354331389380694725739337173509533728950922705473059,
        18748125373815017986228277802731820946303221760)
GAMMA = F(1)


def load_public():
    path = Path(__file__).with_name("public860.py")
    assert sha256(path.read_bytes()).hexdigest() == PUBLIC
    return runpy.run_path(str(path))


def bits_for(parents, t, i):
    return parents[t]["bit"] | parents[i]["bit"]


def pressure(records, parents, src, cells, s):
    out = defaultdict(F)
    for (t,left,right), weight in sorted(records.items()):
        key = t,left,right
        for i,y,_ in (left,right):
            gate = bits_for(parents,t,i)
            for c in cells:
                if c&gate==gate:
                    out[y,c] += weight*s[key]/(GAMMA*src[y])
    return out


def thresholds(records, parents, src, cells, B, used, s, D, v, weight, fmt):
    total_fee = sum(cells[c]*v[c] for c in cells)
    integrated = sum(cells[c]*src[y]*D[y,c] for c in cells for y in used)
    retained = sum(records[k]*s[k] for k in records)
    for level in (0,30,50):
        H = tuple(c for c in cells if v[c]>level*weight)
        assert H
        measure = sum(cells[c] for c in H)
        fee = sum(cells[c]*v[c] for c in H)
        actual_d = sum(cells[c]*src[y]*D[y,c] for c in H for y in used)
        assert fee>0 and actual_d>0
        visible_y={y for y in used if any(D[y,c]>0 for c in H)}
        observed=[defaultdict(F),defaultdict(F)]
        either=both=F(0)
        for key,w in records.items():
            t,l,r=key
            seen=[]
            for side,(i,y,k) in enumerate((l,r)):
                gate=bits_for(parents,t,i)
                seen.append(any(c&gate==gate for c in H))
                if seen[-1]:
                    observed[side][i,k] += w*s[key]
            if any(seen):
                either += w*s[key]
            if all(seen):
                both += w*s[key]
        print(" E={v_C/F >",level,"}, cells",H,"; Leb(E) =",measure,
              "; share of physical target union",fmt(measure/sum(cells.values())))
        print("   share of output-price fee, integrated true source pressure:",
              fmt(fee/total_fee),fmt(actual_d/integrated))
        print("   positive-pressure input cells/used:",len(visible_y),"/",len(used),
              "; visible input true mu_B/mu(active):",
              fmt(sum(src[y] for y in visible_y)/sum(src[y] for y in used)),
              "; geometric mu(B intersect E)/mu(B):",
              fmt(sum(src[c] for c in H if c in B)/sum(src[y] for y in B)))
        for side,marginal in enumerate(observed):
            print("   ","UW"[side],"visible actual half-cores",len(marginal),
                  "; retained original weight share",fmt(sum(marginal.values())/retained),
                  "; max retained weight per actual half Lebesgue",
                  fmt(max(2*w/parents[i]["owner_volume"] for (i,k),w in marginal.items())))
        print("   either/both endpoint gate visible retained weight shares:",
              fmt(either/retained),fmt(both/retained))


def replay(rounds):
    public=load_public()
    parents,src,raw,hard,outward,pin814,cut=public["load"](rounds)
    cells,_=public["physical_cells"](parents,raw)
    mass=sum(raw.values())
    K,P,demand,cost,A,B,inside=cut
    assert all(z in B for key in hard for z in (key[1][1],key[2][1]))
    assert sum(hard.values())==demand
    sigma=cut[2]
    def fmt(lo,hi=None):
        return "0" if lo==0 and (hi is None or hi==0) else outward(lo,hi)

    # Validate the saved density externally by its archive benchmark bounds.
    # Only the one hard-cut evaluation below uses HiGHS in this replay.
    assert F("1.31402114e7")<=TAU<=F("1.31402115e7")
    model=public["Model"](src,cells,public["group"](hard,parents),mass)
    lower,old_hi,plan=model.solve(TAU,GAMMA)
    used=model.used
    s=dict.fromkeys(hard,F(1))
    D=pressure(hard,parents,src,cells,s)
    # Same calculation from compressed branches, with a multiplicity of two
    # when an actual source cell participates twice in a branch.
    exact_compressed=defaultdict(F)
    for (z,a,q,b),w in zip(model.obs,model.weights):
        for y,gate in ((z,a),(q,b)):
            for c in cells:
                if c&gate==gate:
                    exact_compressed[y,c] += mass*w/(GAMMA*src[y])
    assert dict(D)==dict(exact_compressed)
    u=dict.fromkeys(B,F(0))
    v={c:max(D[y,c] for y in B) for c in cells}
    assert all(F(0)<=x<=1 for x in s.values())
    assert min(u.values())>=0 and min(v.values())>=0
    assert all(D[y,c]<=u[y]+v[c] for y in B for c in cells)
    deleted=sum(w*(1-s[k]) for k,w in hard.items())
    retained=sum(w*s[k] for k,w in hard.items())
    source_fee=sum(src[y]*u[y] for y in B)
    target_fee=TAU*sum(cells[c]*v[c] for c in cells)
    upper=deleted+source_fee+target_fee
    exact_gap=upper/mass-lower
    assert deleted+retained==sigma
    assert 0<=exact_gap<F(1,10**11) and upper/mass<=old_hi
    # AB physical marginal denominators use the exact cut's 23 source cells,
    # including inactive cells whose route pressure is zero.
    chart={y:src[y] for y in B}
    row,use=model.row_column_bound(plan)
    print("Python",sys.version.split()[0],"; exact Fraction dual and hard-cut pressure.")
    print("Pinned public860.py",PUBLIC,"; R814",pin814)
    print("One saved diagnostic, gamma =",GAMMA,"; tau exact =",TAU)
    print("R859 hard cut:",len(hard),"original branches, actual half cores |A| =",len(A),
          "; actual source cells |B| =",len(B),"; true parents wholly in B",tuple(sorted(inside)))
    print("F(A,B)/F, old capacity/F, old deficit/F:",fmt(sigma/mass),fmt(cost/mass),fmt((sigma-cost)/mass))
    print("Total mu(B), active mu_B:",sum(chart.values()),sum(chart[y] for y in used))
    print("s_omega = 1 for all original hard branches; sigma retained/F, deleted/F:",
          fmt(retained/mass),fmt(deleted/mass))
    print("u_y = 0 for every physical source in B. D_C(y) checked on",len(B)*len(cells),
          "price-cell/target-cell pairs including both endpoints.")
    print("Input dual/F, output dual/F, certified lower/F, dual-lower/F:",
          *(fmt(x) for x in (source_fee/mass,target_fee/mass,lower,exact_gap)))
    print("Maximum primal source utilization and maximum untruncated record capture:",
          fmt(max(row)),fmt(max(model.all_hits(plan))))
    for c in cells:
        maximizers=tuple(y for y in sorted(B) if D[y,c]==v[c])
        assert maximizers
        print(" C",c,"Leb",cells[c],"; exact normalized v_C/F",v[c]/mass,
              "; attaining true price masks",maximizers,
              "; certified primal column utilization",fmt(use[model.cells.index(c)]*model.mass/(TAU*cells[c])))
    thresholds(hard,parents,src,cells,B,used,s,D,v,mass,fmt)
    print("Finite geometric score certificate. Converting this score into old contract payment requires a separate theorem.")


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--rounds",type=Path,required=True)
    replay(parser.parse_args().rounds)

