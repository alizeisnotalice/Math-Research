"""Exact product-cube test of a public intermediate point, with positive-width sources and targets."""
from fractions import Fraction as F
from math import comb
import sys


def volume_ratio(n, h):
    # The inner interval has one seventh of each coordinate's length.
    numerator = sum(comb(n, j) * 6**j for j in range(h))
    poly = [1] + [0] * (h - 1)
    for _ in range(n):
        for j in range(h - 1, 0, -1):
            poly[j] += 6 * poly[j - 1]
    assert sum(poly) == numerator
    return F(numerator, 7**n)


def floor_log2(q):
    k = q.numerator.bit_length() - q.denominator.bit_length()
    if F(2)**k > q:
        k -= 1
    assert F(2)**k <= q < F(2)**(k + 1)
    return k


def test(n, h):
    assert 0 < h < n
    source_half, target_lo, target_hi = F(1, 32), F(1), F(33, 32)
    core_half, extent = F(1, 4), F(7, 4)
    assert 2 * source_half < F(1, 8) and target_hi - target_lo < F(1, 8)
    assert source_half < core_half < target_lo < target_hi < extent < F(15, 8)
    # Every source-target straight segment stays in the open diagonal strip.
    # Every rectangular waypoint with h full coordinates lies outside that strip and E_h.
    assert target_lo - source_half > F(1, 8)
    gate_at_waypoint, gate_at_target = F(1, 2**h), F(1, 2**n)
    if n <= 12:
        signs = range(1 << n)
        needed = (1 << h) - 1
        assert sum((s & needed) == needed for s in signs) * gate_at_waypoint.denominator == 2**n
        assert sum(s == (1 << n) - 1 for s in signs) * gate_at_target.denominator == 2**n
    ratio = volume_ratio(n, h)
    print(f"n={n}, h={h}: public waypoint=2^-{h}, public endpoint=2^-{n}, "
          f"private endpoint=1, log2(waypoint/endpoint)={n-h}; "
          f"floor(log2(original obstacle fraction))={floor_log2(ratio)}")


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "integer/Fraction arithmetic")
    print("Source [-1/32,1/32]^n; target [1,33/32]^n; true boxes of side 2 have centers +/-3/4.")
    print("Obstacle E_h counts <h active coordinates; a positive-width diagonal strip can cover the full straight segment.")
    print("Public intermediate test changes h preselected coordinates, independent of the hidden signs.")
    for dims in [(4, 1), (8, 2), (12, 3), (32, 3), (128, 4), (512, 5)]:
        test(*dims)
    print("Finite geometric test of common source incidence; no R813 history or global contraction inferred.")
