"""R860. Exact rational certificates for a common physical price-cell kernel.

Within each original membership cell both price marginals are the normalized
restriction of the same source measure. Averaging each physical price kernel
over its source cell preserves the output bound. Jensen for min(1, s/gamma)
bounds the original continuous score above by the score of that averaged
kernel. Conversely, a source-cell constant kernel that sends uniformly to
each full positive-volume output incidence cell realizes the finite plan.
Output outside the counted gates never increases the score and can be dropped.
Thus the finite shared linear programs certify optima for this full physical
target library, including arbitrary measurable kernels in the archived sample.
"""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
from pathlib import Path
from zipfile import ZipFile
import json
import sys

import numpy as np
import scipy
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

PIN859 = "1e48d2b533ef52375172f5202d86fafcce52608f1d24226e99220692bd2d700a"
PINJOINT = "780aeaa320c14a46f709630becfd76069bcc57e9b0200edc2dd758ff0dac7a8a"
DENOM = 10**11


def load(rounds):
    path = rounds / "859" / "research.zip"
    assert sha256(path.read_bytes()).hexdigest() == PIN859
    with ZipFile(path) as z:
        name = "joint859.py"
        code = z.read(name)
        manifest = json.loads(z.read("MANIFEST.json"))
    assert sha256(code).hexdigest() == manifest["sha256"][name] == PINJOINT
    env = {"__name__": "public_from_r859", "__file__": name}
    exec(compile(code, name, "exec"), env)
    helper, network = env["helpers"](rounds)
    parents, src, raw, fmt, pin814 = helper["load"](rounds)
    expanded, sources, receivers = env["configuration"](raw, parents, src)
    independent, _, _ = helper["strata"](raw, src, parents, "central", True)
    K = max(helper["peak"](d, src)[0] for d in independent.values())
    receivers_only, _ = env["build"](expanded, "receiver")
    Pstar, _ = helper["peak"](receivers_only, receivers)
    P = Pstar / 2
    demands, _ = env["build"](expanded, "joint")
    cap = {k: K*m for k,m in sources.items()} | {k: P*m for k,m in receivers.items()}
    carry, _, _, (cut, supply, cells), _ = network(demands, cap, F(1))
    A = {(c[1],c[2]) for c in cells if c[0]=="receiver"}
    B = {c[1] for c in cells if c[0]=="source"}
    inside = {i for i,p in parents.items()
              if all(mask in B for mask in src if mask&p["bit"])}
    hard = {key:sum(raw[key]/2 for h in (0,1)
                    if {key[0],key[1][0],key[2][0]} <= inside
                    and {(key[0],h),(key[1][0],key[1][2]),(key[2][0],key[2][2])} <= A)
            for key in raw}
    hard = {k:w for k,w in hard.items() if w}
    assert sum(hard.values()) == cut
    assert K*sum(src[z] for z in B)+P*sum(parents[i]["j"]/2 for i,h in A)==supply
    assert cut-supply == sum(raw.values())-carry
    return parents, src, raw, hard, fmt, pin814, (K,P,cut,supply,A,B,inside)


def intersect(*boxes):
    return tuple((max(q[0] for q in axis), min(q[1] for q in axis))
                 for axis in zip(*boxes))


def volume(box):
    v = F(1)
    for a,b in box:
        v *= max(b-a,F(0))
    return v


def physical_cells(parents, records):
    # Keep disjoint atomic boxes only up to their exact complete incidence mask.
    # Disconnected pieces of the same mask may share a variable since all gates
    # have the same value there. Density is then uniform on their union.
    masks = {sum(p["bit"] for p in parents.values()):F(1)}
    representatives = {next(iter(masks)):()}
    for axis in zip(*(p["box"] for p in parents.values())):
        spans = sorted({q for ab in axis for q in ab})
        stage = defaultdict(F)
        witness = {}
        for a,b in zip(spans,spans[1:]):
            mid = (a+b)/2
            m = sum(p["bit"] for p,(lo,hi) in zip(parents.values(),axis) if lo<mid<hi)
            stage[m] += b-a
            witness.setdefault(m,(a,b))
        nxt = defaultdict(F)
        reps = {}
        for m,t in masks.items():
            for s,l in stage.items():
                new = m&s
                nxt[new] += t*l
                reps.setdefault(new,representatives[m]+(witness[s],))
        masks,representatives = nxt,reps
    needed = sorted({parents[t]["bit"]|parents[x[0]]["bit"]
                     for t,l,r in records for x in (l,r)})
    gates = tuple(needed)
    target = {c:v for c,v in sorted(masks.items()) if any(c&gate==gate for gate in gates)}
    # Check every pair-of-gates joint, not only the marginal gate volumes.
    for a,b in combinations(gates+(0,),2):
        bits=a|b
        boxes=[p["box"] for p in parents.values() if p["bit"]&bits]
        assert sum(v for c,v in target.items() if c&bits==bits)==volume(intersect(*boxes))
    return target, {k:representatives[k] for k in target}


def group(records, parents):
    out=defaultdict(F)
    for (t,l,r),amount in sorted(records.items()):
        b=parents[t]["bit"]
        z,q=l[1],r[1]
        out[(z,b|parents[l[0]]["bit"],q,b|parents[r[0]]["bit"])] += amount
    return dict(sorted(out.items()))


def rounded(x):
    return F(round(max(x,0.)*DENOM),DENOM)


class Model:
    def __init__(self, src, target, hit_mass, accounting_mass):
        self.obs = tuple(hit_mass)
        self.weights = [hit_mass[key]/accounting_mass for key in self.obs]
        self.used = tuple(sorted({z for z,i,q,j in self.obs} | {q for z,i,q,j in self.obs}))
        self.cells = tuple(sorted(target))
        self.mass = sum(src[z] for z in self.used)
        self.mu=tuple(src[z]/self.mass for z in self.used)
        self.vol=tuple(target[c] for c in self.cells)
        self.size=len(self.used)*len(self.cells)
        position={z:y for y,z in enumerate(self.used)}
        self.entries=[]
        for z,a,q,b in self.obs:
            hits=defaultdict(int)
            for y,k in ((position[z],a),(position[q],b)):
                for c,s in enumerate(self.cells):
                    if s&k==k:
                        hits[self.idx(y,c)] += 1
            self.entries.append(dict(hits))

    def idx(self,y,c):
        return y*len(self.cells)+c

    def all_hits(self,p):
        return [sum(p[e]*k for e,k in hits.items()) for hits in self.entries]

    def exact_objective(self,p,gamma,clip=True):
        values=(v/gamma for v in self.all_hits(p))
        return sum(w*(min(F(1),v) if clip else v) for w,v in zip(self.weights,values))

    def row_column_bound(self,p):
        row=[sum(p[self.idx(y,c)] for c in range(len(self.cells))) for y in range(len(self.used))]
        col=[sum(w*p[self.idx(y,c)] for y,w in enumerate(self.mu)) for c in range(len(self.cells))]
        return row,col

    def feasible(self,p,tau):
        assert len(p)==self.size and min(p)>=0
        row,col=self.row_column_bound(p)
        assert max(row)<=1 and all(a<=tau*b/self.mass for a,b in zip(col,self.vol))

    def sparse(self,rows,columns):
        triples=[(i,j,float(a)) for i,row in enumerate(rows) for j,a in row.items() if a]
        r,c,v=zip(*triples)
        return coo_matrix((v,(r,c)),shape=(len(rows),columns)).tocsr()

    def stock(self,tau):
        stock = [{self.idx(y,c):F(1) for c in range(len(self.cells))}
                 for y in range(len(self.used))]
        stock.extend({self.idx(y,c):w for y,w in enumerate(self.mu)}
                     for c in range(len(self.cells)))
        cap = [F(1)]*len(self.used)+[tau*v/self.mass for v in self.vol]
        return stock,cap

    def repair(self,p,tau):
        row,col=self.row_column_bound(p)
        for y,a in enumerate(row):
            if a>1:
                for c in range(len(self.cells)):
                    p[self.idx(y,c)] /= a
        _,col=self.row_column_bound(p)
        for c,capacity in enumerate(tau*b/self.mass for b in self.vol):
            if col[c]>capacity:
                ratio=capacity/col[c]
                for y in range(len(self.used)):
                    p[self.idx(y,c)] *= ratio
        self.feasible(p,tau)
        return p

    def solve(self,tau,gamma,clip=True):
        rows,cap=self.stock(tau)
        objective = [F(0)]*self.size
        if clip:
            for i,(hits,w) in enumerate(zip(self.entries,self.weights)):
                objidx=self.size+i
                rows += [{objidx:F(1)}, {objidx:F(1)} | {e:-k/gamma for e,k in hits.items()}]
                cap += [F(1),F(0)]
                objective.append(w)
        else:
            for hits,w in zip(self.entries,self.weights):
                for e,k in hits.items():
                    objective[e] += k*w/gamma
        result=linprog([-float(x) for x in objective],A_ub=self.sparse(rows,len(objective)),
                       b_ub=[float(x) for x in cap],method="highs",
                       options={"primal_feasibility_tolerance":1e-9,"dual_feasibility_tolerance":1e-9})
        assert result.success, result.message
        p=self.repair([rounded(x) for x in result.x[:self.size]],tau)
        if clip:
            p_all=p+[min(F(1),v/gamma) for v in self.all_hits(p)]
        else:
            p_all=p
        lo=sum(w*x for w,x in zip(objective,p_all))
        assert all(sum(a*p_all[j] for j,a in row.items())<=b for row,b in zip(rows,cap))
        # Round the solver's candidate dual upward as needed using free row
        # stock prices and capped-branch prices, then verify every inequality.
        dual=[rounded(-x) for x in result.ineqlin.marginals]
        cover=[F(0)]*len(objective)
        for d,row in zip(dual,rows):
            for j,a in row.items():
                cover[j] += d*a
        for y in range(len(self.used)):
            delta=max(F(0),max(objective[j]-cover[j] for j in rows[y]))
            dual[y] += delta
            for j in rows[y]:
                cover[j] += delta
        if clip:
            offset=len(self.used)+len(self.cells)
            for i in range(len(self.obs)):
                j=self.size+i
                delta=max(F(0),objective[j]-cover[j])
                dual[offset+2*i] += delta
                cover[j] += delta
        assert min(dual)>=0 and all(a>=b for a,b in zip(cover,objective))
        hi=sum(d*b for d,b in zip(dual,cap))
        if clip:
            hi=min(hi,sum(self.weights))
        assert lo<=hi and hi-lo<=F(2,10**6)
        return lo,hi,p

    def critical_estimate(self,gamma):
        rows,cap=self.stock(F(0))
        V=sum(self.vol)
        for c,v in enumerate(self.vol):
            rows[len(self.used)+c][self.size] = -v/V
        for hits in self.entries:
            rows.append({e:-F(k) for e,k in hits.items()})
            cap.append(-gamma)
        result=linprog([0.]*self.size+[1.],A_ub=self.sparse(rows,self.size+1),
                       b_ub=[float(x) for x in cap],method="highs")
        assert result.success, result.message
        return F(str(result.x[-1]))*self.mass/V

    def critical_bracket(self,gamma):
        estimate=self.critical_estimate(gamma)
        lower=estimate*F(999,1000)
        a,b,_=self.solve(lower,gamma)
        assert b<sum(self.weights)
        upper=estimate*F(1001,1000)
        _,_,p=self.solve(upper,gamma)
        # Exact full primal: mix the repaired p with a plan sending every
        # utilized input row to its actual positive complete-incidence cell.
        own={y:self.cells.index(z) for y,z in enumerate(self.used)}
        worst=min(self.all_hits(p))
        frac=max(F(0),(gamma-worst)/(2-worst)) if worst<gamma else F(0)
        full=[(1-frac)*x+frac*(j%len(self.cells)==own[j//len(self.cells)]) for j,x in enumerate(p)]
        assert min(self.all_hits(full))>=gamma
        _,col=self.row_column_bound(full)
        exact=max(x*self.mass/v for x,v in zip(col,self.vol))
        self.feasible(full,exact)
        assert lower<exact<=upper*F(1005,1000)
        return lower,exact


def incidence_volume(target,a,b):
    return sum(v for c,v in target.items() if c&a==a and c&b==b)


def separate_records(obs,source,target,tau,gamma,normalization):
    cap={}
    for z,a,q,b in obs:
        tags=(a,b)
        if tags not in cap:
            shared=incidence_volume(target,a,b)*tau
            cap[tags]=(incidence_volume(target,a,a)*tau-shared,
                       incidence_volume(target,b,b)*tau-shared,shared)
        L,R,B=cap[tags]
        if z==q:
            both=min(B,source[z])
            val=(2*both+min(L+R,source[z]-both))/source[z]
        else:
            m,n=source[z],source[q]
            l,r=min(L,m),min(R,n)
            if n<m:
                first=min(B,n-r)
                r+=first
                l+=min(B-first,m-l)
            else:
                first=min(B,m-l)
                l+=first
                r+=min(B-first,n-r)
            val=l/m+r/n
        yield obs[(z,a,q,b)]/normalization*min(F(1),val/gamma)


def fixed_parent(records,parents,src,tau,gamma,normalization,largest=False):
    # The input (complete source mask) selects one physically incident parent.
    # Its output is uniform on this actual owner's two half-cores.
    rows={z for z,_,q,_ in records}|{q for z,_,q,_ in records}
    options=sorted(parents,key=lambda i:(parents[i]["m"],i),reverse=largest)
    chosen={z:next(i for i in options if z&parents[i]["bit"]) for z in rows}
    volumes={i:sum(volume(b) for b in p["owner_halves"])
             for i,p in parents.items()}
    owner_mass=defaultdict(F)
    for z,i in chosen.items():
        owner_mass[i]+=src[z]
    scale={i:min(F(1),tau*volumes[i]/m) for i,m in owner_mass.items()}
    owners={i:p["owner_halves"] for i,p in parents.items()}
    assert all(volume(intersect(a,b))==0 for i,j in combinations(owners,2)
               for a in owners[i] for b in owners[j])
    prob={}
    gates={t for z,a,q,b in records for t in (a,b)}
    for i in owner_mass:
        for g in gates:
            boxes=[p["box"] for p in parents.values() if p["bit"]&g]
            X=sum(volume(intersect(E,*boxes)) for E in owners[i])
            prob[i,g]=scale[i]*X/volumes[i]
    return sum(w/normalization*min(F(1),(prob[chosen[z],a]+prob[chosen[q],b])/gamma)
               for (z,a,q,b),w in records.items())


def own_target(model,src,target,tau):
    # One output location per input, chosen by its own physical membership
    # mask. Distinct input masks have disjoint output incidence regions.
    p=[F(0)]*model.size
    for y,z in enumerate(model.used):
        c=model.cells.index(z)
        p[model.idx(y,c)]=min(F(1),tau*target[z]/src[z])
    model.feasible(p,tau)
    return p


def linear_sides(model,p,gamma):
    index={z:y for y,z in enumerate(model.used)}
    result=[F(0),F(0)]
    for (z,a,q,b),w in zip(model.obs,model.weights):
        for h,(key,gate) in enumerate(((z,a),(q,b))):
            result[h]+=w/gamma*sum(p[model.idx(index[key],c)]
                                  for c,m in enumerate(model.cells) if m&gate==gate)
    assert sum(result)==model.exact_objective(p,gamma,False)
    return result


def cross_margin(raw,subset,model,p,gamma,parents,fmt):
    compressed={}
    for r,h in zip(model.obs,model.all_hits(p)):
        compressed[r]=min(F(1),h/gamma)
    sums=[defaultdict(F),defaultdict(F)]
    base=[defaultdict(F),defaultdict(F)]
    M=sum(raw.values())
    witness=None
    for key,w in sorted(raw.items()):
        t,l,r=key
        a=parents[t]["bit"]|parents[l[0]]["bit"]
        b=parents[t]["bit"]|parents[r[0]]["bit"]
        if key in subset:
            factor=compressed[(l[1],a,r[1],b)]
            value=subset[key]*factor
        else:
            value=F(0)
        for h,endpoint in enumerate((l,r)):
            i,mask,k=endpoint
            sums[h][i,k]+=value
            base[h][i,k]+=w
        if value and witness is None:
            z=l[1]
            y=model.used.index(z)
            options=[(c,p[model.idx(y,j)]) for j,c in enumerate(model.cells)
                     if c&a==a and p[model.idx(y,j)]]
            if options:
                witness=(key,options[0],value/M)
    assert sum(sums[0].values())==sum(sums[1].values())==model.exact_objective(p,gamma)*M
    assert all(x<=base[h][i,k]<=parents[i]["owner_volume"]/2
               for h in (0,1) for (i,k),x in sums[h].items())
    return [fmt(max(2*x/parents[i]["owner_volume"] for (i,k),x in s.items())) for s in sums],witness


def main(rounds):
    parents,src,raw,hard,outward,pin814,cut=load(rounds)
    def fmt(lo,hi=None):
        return "0" if lo==0 and (hi is None or hi==0) else outward(lo,hi)
    target,reps=physical_cells(parents,raw)
    M=sum(raw.values())
    all_obs,cut_obs=group(raw,parents),group(hard,parents)
    all_model,cut_model=(Model(src,target,v,M) for v in (all_obs,cut_obs))
    assert set(cut_model.used)<=set(all_model.used)
    K,P,demand,cap,A,B,inside=cut
    print("Python",sys.version.split()[0],"NumPy",np.__version__,"SciPy",scipy.__version__)
    print("R859",PIN859,"; R814",pin814)
    print("Parents, true positive source cells, physical target cells, original rows:",
          len(parents),len(src),len(target),len(raw))
    print("Real Lebesgue target union",sum(target.values()),"; exact pair and pair-pair overlap checks passed")
    print("Original F",fmt(M),"; shared source K",fmt(K),"; actual-half receiver P",fmt(P))
    print("Hard F(A,B), total contracted capacities, actual deficit, relative to F:",
          *(fmt(x/M) for x in (demand,cap,demand-cap)), "; A,B,fully contained real parents",
          len(A),len(B),tuple(sorted(inside)))
    print("Compressed all/hard rows",len(all_obs),len(cut_obs),"; original hard positive rows",len(hard))
    print("Shared fixed kernel depends on actual input price mask only. Each output density is assigned on disjoint physical target cells.")
    print("Source averaging is valid by Jensen for the clipped score; constant-by-cell kernels realize the reduced model.")
    print("Fixed-parent comparisons use smallest/largest incident measured-mass true owner, uniform on the owner's half-cores.")
    print("Own-cell baseline uses the physical output cell matching the input's complete incidence mask.")
    print("Independent upper comparison gives each original record a separate kernel (single stock and output cap within each record).")
    print("Fractions below are normalized by full original F. LP entries are rigorous rational primal/dual intervals.")

    for gamma in (F(1,2),F(1),F(3,2)):
        critical=all_model.critical_bracket(gamma)
        print("gamma",gamma,"critical shared density all originals",fmt(*critical))
        for f in (F(1,16),F(1,4),F(3,4),F(1),F(2)):
            tau=f*critical[1]
            a,b,p=all_model.solve(tau,gamma)
            c,d,cp=cut_model.solve(tau,gamma)
            e,g,lp=all_model.solve(tau,gamma,clip=False)
            h,j,clp=cut_model.solve(tau,gamma,clip=False)
            independent=sum(separate_records(all_obs,src,target,tau,gamma,M))
            independent_cut=sum(separate_records(cut_obs,src,target,tau,gamma,M))
            assert 0<=a<=b and a<=independent and c<=independent_cut and a<=g and c<=j
            assert all_model.exact_objective(p,gamma,False)>=a
            cross=[p[all_model.idx(all_model.used.index(z),i)] for z in cut_model.used
                   for i in range(len(all_model.cells))]
            cut_model.feasible(cross,tau)
            cut_reuse=cut_model.exact_objective(cross,gamma)
            assert cut_reuse<=d
            small=fixed_parent(all_obs,parents,src,tau,gamma,M)
            big=fixed_parent(all_obs,parents,src,tau,gamma,M,largest=True)
            own=all_model.exact_objective(own_target(all_model,src,target,tau),gamma)
            own_cut=cut_model.exact_objective(own_target(cut_model,src,target,tau),gamma)
            assert max(small,big,own)<=b and own_cut<=d
            print(" tau / certified upper critical",f,"; density",fmt(tau))
            print("  shared all, linear all, independent all, fixed min/max:",
                  fmt(a,b),fmt(e,g),fmt(independent),fmt(small),fmt(big))
            print("  shared hard, linear hard, independent hard, all plan on hard:",
                  fmt(c,d),fmt(h,j),fmt(independent_cut),fmt(cut_reuse))
            print("  own-cell all/hard; linear left/right (all, hard):",fmt(own),fmt(own_cut),
                  [fmt(x) for x in linear_sides(all_model,lp,gamma)],
                  [fmt(x) for x in linear_sides(cut_model,clp,gamma)])
            if gamma==1 and f==F(1,4):
                by_fathers=defaultdict(dict)
                for key,w in raw.items():
                    t,l,r=key
                    by_fathers[t,l[0],r[0]][key]=w
                relaxed=[Model(src,target,group(v,parents),M).solve(tau,gamma)[:2]
                         for v in by_fathers.values()]
                triad_lo=sum(x[0] for x in relaxed)
                triad_hi=sum(x[1] for x in relaxed)
                assert a<=triad_hi and triad_lo<=independent
                print("  independent hidden father triads:",len(relaxed),
                      "; clipped paid over original",fmt(triad_lo,min(triad_hi,independent)))
                rows,cols=all_model.row_column_bound(p)
                print("  used input rows and saturated input/target capacities:",
                      len(rows),sum(x==1 for x in rows),
                      sum(x==tau*v/all_model.mass for x,v in zip(cols,all_model.vol)))
                margins,witness=cross_margin(raw,raw,all_model,p,gamma,parents,fmt)
                hmarg,_=cross_margin(raw,hard,cut_model,cp,gamma,parents,fmt)
                key,(target_mask,probability),weight=witness
                print("  original U,W max paid / actual half Lebesgue, all and hard:",margins,hmarg)
                print("  witnessed t,(u,z,U-half),(g,q,W-half), output mask and mass:",
                      key,target_mask,fmt(probability),fmt(weight))
                print("  one positively measured rectangle in this physical target cell:",reps[target_mask])
    print("All exact rational primal, dual, geometry, hard-cut, and computed receiver-marginal assertions passed.")


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--rounds",type=Path,required=True)
    main(parser.parse_args().rounds)

