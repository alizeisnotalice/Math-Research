# R165 主代理：消去局部化门对 good 来源的依赖

状态：自证推导，已送独立审查；尚未认证为原交通付款。

设 h=1_{[-1/2,1/2]}, w(r)=∫_0^1 exp(-|r|/a) da, φ=h*w, F=max(h,φ), C(d)=∫_{-1/2}^{1/2}F(x-d)dx。所有函数取非负实值；边界点值不影响积分。φ偶且递减，φ≤1，因此F在核心内为1，在核心外为φ，C偶且在正半轴非增。0<C≤1且C为1-Lipschitz。

对d≥1，直接Tonelli两次积分给
C(d)=∫_0^1 a²(1-exp(-1/a))² exp(-(d-1)/a) da.
尤其C(1)≥c0=(7/24)(1-exp(-1))²>0：只积分a∈[1/2,1]并用1-exp(-1/a)≥1-exp(-1)。对0≤d≤1，C(d)≥c0，故log C的绝对导数几乎处处≤1/c0。

对d≥1，令t=d-1、A(a)=a²(1-exp(-1/a))²，F0(t)=∫A(a)exp(-t/a)da。其负对数导数r(t)=∫a^-1 A exp(-t/a)/F0(t)。在t>0处微分得r'(t)=-Var_t(a^-1)≤0。t=0处前两阶矩有限（A/a²≤1），由支配收敛r连续且r(0)≤(∫_0^1a da)/c0=1/(2c0)。因此整条实轴上log C为L0=1/c0 Lipschitz；跨0与±1由连续性拼接。不存在远来源的1/C爆炸。

令b>0、a≤L,R≤b≤2a，p_y=P_{s,L}(·-y)、J_v=P_{1,b}(·-v)，wg(v)=∏min(1,C((y_i-v_i)/b)/zg)，zg∈[1/2,1]。因每个wg因子≥C_i，硬接收窗I_i=[z_i-R/2,z_i+R/2]满足
∫_{I_i} b^-1 φ((x-v_i)/b) dx / wg_i(v)
≤ C((z_i-v_i)/b)/C((y_i-v_i)/b)
≤ exp(L0 |z_i-y_i|/b).
这里R≤b允许窗扩大到b，φ≤F，均为正向支配。

设η=1-∫_{-1}^1φ>0、λ_s=-log(1-sη)。由R/L≤2与一维偶递减性，每个p窗质量≤1-sη。逐坐标Cauchy给
∫ h_R(x-z) sqrt(p_y(x)J_v(x)/wg(v)) dx
≤ R^-n exp[-nλ_s/2+L0||z-y||_1/(2b)].
这是对任意v一致的固定参数界。近硬来源条件
L0||z-y||_1/b≤nλ_s/2
因此同时覆盖所有v，给R^-n exp(-nλ_s/4)。相比使用Σlog(1+|z_i-y_i|/(b C_i(v)))，此门不再随good来源v变化。

在原good门p wg≤KQ，χJ=J/(3Q)，由χJ≤1与pχJ≤KJ/(3wg)两式相乘，pχJ≤sqrt(K/3)sqrt(pJ/wg)。任意固定v,u的score δ≤n、时间范围log2，于是固定来源核交通（只保留≤1的门、不含原归一化权重）≤sqrt(K/3) n log2 R^-n exp(-nλ_s/4)。当s>0，√n exp(-nλ_s/4)≤sqrt(2/(eλ_s))，得到根阶。s=0只能保留线性式；s趋0时系数发散，不能声称全soft一致。

关键限制：v-independent来源门不等于接收点权重独立。原q^-1、wt(v)wt(u)/et²、a_history、唯一j、receiver-dependent L,R,s以及β与ν的外来源仍不可擅自从dx提出。任意fixed-source界可对receiver-independent有限来源测度积分，但原实际交通不是自动满足这一条件。本结果改进几何门，未证明一般根阶预算。下一步需在此一致近域内直接估计原加权接收积分；远域仍必须覆盖。
