# R165：保留原 hard 来源的局部接收重叠

状态：得到一条新的、带明确来源几何条件的三源接收核估计；未支付一般来源的完整 raw 交通。核心变化是先保留 hard 窗，在窗内联合积分 p_y 与 good J_v；没有再次估计 R164 的逆核系数，也没有重复固定两源 Hellinger 根阶引理。

## 1. 原接口与量词

核验材料仅为本轮 task_contract.md、R164 上下文，以及 R136 ZIP 内 ordered_score_capacity.md §4、research.tex 原积分段、active_bad_geometry.md 原外行测度段。R136 明确原 raw 外行测度为

\[
 d\mathcal T=q^{-1}p_y(x)h_R(x-z')a_\omega\,
 dx\,d\beta(y)\,d\nu(z').                                  \tag{H1}
\]

a_ω 是原 history 权，本稿不重新定义其生成方式或假设它是常数。h_R 是原边长 R、积分为 1 的硬盒核。外硬来源 z′ 与原 bad 来源 u 必须区分。原期望、V/history、唯一 j、资格门、β–ν、连续参数选择均保留；没有将 β 换为 ν。

raw 内部乘原

\[
 \rho_v\chi_{J,v}1_G(v)1_{\rm bad}(u)
 (k_\xi(v)-k_\xi(u))_+\,d\Pi_\xi(v)d\Pi_\xi(u)\,{d\xi\over\xi},
 \qquad \xi=c_jt/b\in[1/2,z_g]\subset[1/2,1].              \tag{H2}
\]

此处用 ξ 表示阈值，避免与 hard 来源混淆。全部原 high、low-c、FA/Ψ 和支持门仍取实际值；共同 α 不改变。R136 §4 明确：只有先用 SI5 积分掉 hard 来源时才出现 16/3；本稿使用 (H1)，因此只恢复外 signed 因子 2Λ，不再叠加 16/3。

下面引理先固定 y、v、u、z′ 以及合法 s∈(0,1)、a≤L,R≤b≤2a、b、z_g。它允许原 good/bad 和 ρ 依赖 x；不允许在接收积分之后免费对尺度或来源取 supremum。

## 2. hard 窗内的三源收缩

记 f_s=(1−s)h+sφ，C_i=C((y_i−v_i)/b)>0，并定义

\[
 \eta=1-\int_{-1}^{1}\phi(r)\,dr,\qquad
 \lambda_s=-\log(1-s\eta)>0,
 \qquad d_i={|z'_i-y_i|\over b},
 \qquad M(y,v,z')=\sum_{i=1}^n\log(1+d_i/C_i).              \tag{H3}
\]

M 是明确可计算的几何条件，不是一个待证接收范数。以下全部常数自足核验。

**基本事实。** w 和 φ 的积分为 1，φ 偶对称且在正半轴单调不增；例如
φ′(r)=w(r+1/2)−w(r−1/2)≤0。由 0≤φ≤1，得 0≤F≤1。于是

\[
 |C(d)-C(e)|\le |d-e|,\qquad 0<C(d)\le1.                 \tag{H4}
\]

这里 Lipschitz 常数为 1：C 的平移导数是两个取值于 [0,1] 的端点值之差，而非两项绝对值之和。wg 的单坐标因子 γ_i=min(1,C_i/z_g) 满足 γ_i≥C_i。

η 也有显式正下界。将 φ 视为 U+W 的密度，其中 U 均匀于 [−1/2,1/2]、W 的密度为 w，则

\[
 \eta\ge\mathbb P(|W|>3/2)
 =2\int_0^1 r e^{-3/(2r)}dr\ge e^{-3}/2.                  \tag{H5}
\]

最后一步只积分 r∈[1/2,1]。

令 I_i=[z′_i−R/2,z′_i+R/2]。其内的一维 p 和 J 质量分别记 P_i、B_i。偶单峰密度在给定长度区间上的质量于中心区间最大；这个结论可直接将密度的超水平集写为中心区间并用层饼积分证明。由于 R/L≤2，

\[
 P_i\le\int_{-1}^{1}f_s(r)dr=1-s\eta=e^{-\lambda_s}.
\]

又因为 R≤b、φ≤F 和 (H4)，

\[
 B_i\le C((z'_i-v_i)/b)\le C_i+d_i.
\]

**不依赖 good 来源的改进。** 主代理提出对 log C 的全局控制；核验如下。对 d≥1，硬平顶已离开积分窗，直接计算 h*h*w 得

\[
 C(d)=\int_0^1 r^2(1-e^{-1/r})^2e^{-(d-1)/r}dr.
\]

令 c_0=7(1-e^{-1})^2/24、L_0=1/c_0。仅积分 r∈[1/2,1] 得 C(1)≥c_0。由 F 偶对称单调，C 亦在正半轴单调，故 0≤d≤1 时 C(d)≥c_0；配合 (H4)，该段 |(log C)′|≤L_0。对 d≥1，上式指数混合给出

\[
 - (\log C)'(d)=\mathbb E_d(1/r),\qquad
 {d\over dd}\mathbb E_d(1/r)=-\operatorname{Var}_d(1/r)\le0.
\]

各项在 d=1 已可积（方差的最高积分被积因子为 (1−e^{-1/r})²），故可直接微分或由双积分验证。首点分子不超过 ∫_0^1rdr=1/2，因此尾段斜率≤1/(2c_0)≤L_0。利用偶性，log C 在整条实线上是 L_0-Lipschitz。于是

\[
 {B_i\over\gamma_i}\le
 {C((z'_i-v_i)/b)\over C((y_i-v_i)/b)}
 \le\exp(L_0|z'_i-y_i|/b).
\]

设 D_1=\|z'-y\|_1/b、M_*=\min\{M,L_0D_1\}。在每个实际 hard 窗内应用 Cauchy–Schwarz，再用产品 Fubini，得到

\[
 \boxed{\quad
 \int_{\mathbb R^n} h_R(x-z')
       \sqrt{\frac{p_y(x)J_v(x)}{w_g(v)}}\,dx
 \le R^{-n}\exp\!\left(-\frac{n\lambda_s}{2}
                         +\frac{M_*}{2}\right).
 \quad}                                                   \tag{H6}
\]

这一步没有对来源坐标作独立性假设。产品性只来自固定来源后的原核与硬盒积分。一般相关 ν 完全允许。

(H6) 在 z′=y 时给出 R^{-n}e^{-nλ_s/2}；更有用的是不依赖 v 或 u 的非零宽度来源域

\[
 \mathcal N_s=\{\|z'-y\|_1/b\le n\lambda_s/(2L_0)\}.              \tag{H7}
\]

在此域，(H6) 右端至多 R^{-n}e^{-nλ_s/4}。不将 z′=y 的零厚度特殊情况冒充一般来源覆盖；实际可用分支是 (H7)，它同时覆盖该 hard 来源下的全部 good v。原更细门 M≤nλ_s/2 也可独立使用；本稿后文统一采用来源无关的 (H7)。

## 3. 与原 good 核、原 bad score 的准确连接

原 good 门与 χ_J 的定义给出两个同时有效的上界

\[
 1_Gp_y\chi_{J,v}\le p_y,
 \qquad 1_Gp_y\chi_{J,v}\le {KJ_v\over3w_g(v)}.
\]

所以

\[
 1_Gp_y\chi_{J,v}\le\sqrt{K/3}\,
       \sqrt{p_yJ_v/w_g(v)}.                              \tag{H8}
\]

这里 K 保留原值，不固定为 1。原 ρ 用同一 α 计算，只使用合法的 0≤ρ≤1 上放；未重新分配任何 α 或来源容量。

对每一个实际原 bad 来源 u，均有

\[
 \int_{1/2}^{1}(k_\xi(v)-k_\xi(u))_+\,{d\xi\over\xi}
 \le\int_{1/2}^{1}k_\xi(v)\,{d\xi\over\xi}
 =\sum_i\log\frac1{\max(C_i,1/2)}\le n\log2.             \tag{H9}
\]

u 没有被 hard 来源替代；这是对原 δ 的一个逐 u 上界。对非负项可先保留全部实际门，再上放到 (H9) 的时间区间。结合 (H6)–(H9)，在 (H7) 上得到固定来源组的真实接收核估计

\[
\begin{split}
 &\int dx\,h_R(x-z')\int\frac{d\xi}{\xi}\,
 1_G1_{\rm bad}1_{\rm actual\ gates}\rho_v
 p_y\chi_{J,v}(k_\xi(v)-k_\xi(u))_+\\
 &\qquad\le\sqrt{K/3}\,R^{-n}n\log2\,e^{-n\lambda_s/4}
 \le\boxed{\ \log2\sqrt{\frac{2K}{3e\lambda_s}}
                 \sqrt n\,R^{-n}\ }.                     \tag{H10}
\end{split}
\]

最后一步来自 sup_{r>0}√r e^{-λ_sr/4}=√(2/(eλ_s))。这不是完整 raw 交通：左侧尚未包含 q^{-1}、两份 e_ξ^{-1}、history 与来源权重。λ_s≥sη，因此对于固定中间 soft 下门 s≥s_0>0，(H10) 的常数显式统一于 λ_{s_0}；如下门随 n 变化，其 λ_{s_0}^{-1/2} 费用不能隐去。

## 4. raw 接缝：准确尚缺什么

把 dΠ_ξ 展开，(H1)–(H2) 中除 (H10) 已处理的核与 score 外，实际还乘

\[
 {a_\omega\,1_{Z_\xi}(v)1_{Z_\xi}(u)
          w_\xi(v)w_\xi(u)\over q\,e_\xi^2}
 \,d\beta(y)d\nu(z')d\nu(v)d\nu(u).                       \tag{H11}
\]

即使固定 y,v,u,z′，(H11) 的分母、history 和支持门仍可能依赖接收点。不能先证明 (H10)，随后把这些系数当作常数放回；也不能先消去 hard 来源得到 16/3 后，再对同一份交通使用 (H6) 的 hard 窗收缩。

一个具体充分接口如下，**本轮尚未证明它**：在原唯一 j/history 的合法固定参数分解中，为 (H7) 分支找到不依赖 x、ξ 的非负来源系数 B，支配 (H11) 的标量部分，并证明其合计来源价格

\[
 \mathbb E\sum_{V,j}\int R^{-n}B\,
          d\beta(y)d\nu(z')d\nu(v)d\nu(u)
 \le C(\log(n+2))^A W_\beta .                               \tag{H12}
\]

这里任何固定尺度分解费用都进入 B 的总预算；不得先对依赖 x 的 ν 或参数取最优，再称为固定参数。若 (H12) 成立且 K、s 的原统一范围已付，则 (H10) 给该近 hard 来源分支的完整 raw signed 价格

\[
 2\Lambda\log2\sqrt{\frac{2K}{3e\lambda_{s_0}}}\,
 C\sqrt n(\log(n+2))^A W_\beta .                            \tag{H13}
\]

C 是纯来源系数预算；所有显式常数均未吸收。没有额外 16/3。原唯一 j 必须沿其原合同消去，而不是在 (H12) 中重复计入；写求和是为保留原结构，不授予逐 j 免费预算。

(H12) 是足够而非必要的接缝条件。更精细的加权接收论证也可能支付 (H11)，但目前没有证明。远来源补集 ‖z′−y‖₁/b>nλ_s/(2L_0) 亦仍在原交通中；本稿未为其申领新预算。

## 5. 可直接核查的下一步与停止点

数值或解析核查应保留原 hard 来源，计算实际 hard 来源的 2L_0‖z′−y‖₁/(bnλ_s)、raw 交通在 (H7) 中的份额，以及 (H11) 在这一来源域中的实际权重。该首要判据不依赖 good/bad 来源；如另测更细的 M 门，则同时报告原 C_i(v)。这些计算不需要重算 α 或自由改变来源。

本轮新增的是 (H6) 和由它推出的 (H10)：真实 hard 局部化提供 n 维收缩，能在明确来源域内克服线性 score。尚缺的是该域的完整原来源／分母／history／selector 预算以及其补集的付款。因此不宣称一般 weak-(1,1) 已闭合，不把 (H12) 的未证系数重新命名为成果。有限单路线交付至此停止。


## 6. 有界延伸：精确 hard 窗的远位移抵消（追加，独立待核）

以下不改变上述已审结论。为下一轮筛查精确窗口路线，只考察固定参数的一维来源比，不将其称为 raw 付款。

先按要求取 s=1、L=R=b=1、y=0，记 hard 位移 d=z′≥0，并令

\[
 \mathcal B(t)=(h*\phi)(t),\qquad
 P(d)=\mathcal B(d),\qquad
 A=e(1-e^{-1})^2.
\]

由本稿 §2 的尾积分（端点 r=1 的直接 Laplace 换元）有

\[
 C(t)=\mathcal B(t)\sim A e^{-|t|}/|t|\qquad(|t|\to\infty).
\]

所以固定 d 后，v→±∞ 时

\[
 {\mathcal B(d-v)\over\min(1,C(v)/z_g)}\longrightarrow z_g e^{\pm d}.
\]

但乘回原窗口 P(d) 后，较大一侧仅渐近 z_g A/d，趋于零。不能仅见来源比增长 e^d 就否定精确窗路线。另一种必要检查是 v=d+a、a 固定；此时

\[
 P(d){\mathcal B(d-v)\over\min(1,C(v)/z_g)}
 \longrightarrow z_g e^a\mathcal B(a).                    \tag{H14}
\]

这个极限严格小于 1，而且有自足的统一上界。事实上
w(t)≤e^{-|t|}/(1+|t|)：对 t>0，由分部积分及
E_1(t)=e^{-t}∫_0^∞e^{-r}/(t+r)dr≥e^{-t}/(t+1)（Cauchy–Schwarz）即得；t=0 直接成立。又
\mathcal B(0)=1/3+2∫_0^1r²e^{-1/r}dr≤(1+2/e)/3。
当 a≤0，e^a\mathcal B(a)≤\mathcal B(0)；当 0≤a≤1/2，利用单峰性；当 a≥1/2，把三角卷积中 t∈[−1,0] 与 [0,1] 分开，得到

\[
 \sup_a e^a\mathcal B(a)
 \le c_*:=\max\left\{{\sqrt e+2/\sqrt e\over3},
                       e-2+{2\over3e}\right\}<0.964<1.    \tag{H15}
\]

第二项来自负半段不超过 (2/3)∫_{−1}^0(1+t)e^t dt=2/(3e)，正半段不超过 ∫_0^1(1−t)e^t dt=e−2。这里只给固定偏移族 (H14) 和明确常数 (H15)；**尚未将 v 的全上确界与 d→∞ 交换**。进一步的可检验候选是该交换成立，极限等于 z_g sup_a e^a\mathcal B(a)。需要另做逃逸来源的一致尾控制，不能直接把逐 v 渐近当成该结论。

另一方面，候选不能随意放宽原参数联动。仅对把 z_g 视为独立 (0,1] 参数的扩大核族，取 b=R=1、L=1/2、d=1/4，硬核部分的窗口质量为 1，故精确 P_s(d)≥1−s；v→+∞ 时 J 窗／终端权比仍趋于 z_g e^{1/4}。因此在这个扩大参数族中，任何拟议的全位置逐坐标常数 <1，至少须排除

\[
 z_g(1-s)e^{1/4}>1.                                      \tag{H16}
\]

原 z_g=c_jg/b 是否允许该区间，仍须核对原 c_j 范围，不能据此声称原合法域违反收缩。这只是对“放宽参数、无门的固定核乘积收缩”候选的量词筛查；未实现原 good/high/ρ/history，不是完整交通反例。它提示下一轮应保留真实 zg、L/R、soft、实际门，并检验原样本的精确乘积 P_i B_i/γ_i，而不能把全来源收缩当成当然事实。

对于 I1 是否被精确窗扩大域覆盖，本追加不作未经计算的断言。下一轮可直接核验明确不等式
\(
 \prod_i P_i(y,z')B_i(v,z')/\gamma_i(v)\le e^{-c n}
\)
在其实际 positive 来源组上的成立范围；然后仍须处理 (H11)，才可能转换为实际付款。延伸到此停止，不改变已证近域结果的覆盖范围。
