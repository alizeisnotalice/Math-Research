#!/usr/bin/env python3
"""Finite R165 hard-source overlap checks. No FULL traffic claim.

Only this file and hard_overlap_check.json/md are owned by this task. Formulae
use 1D product integration, with R^-n of the hard density retained explicitly.
"""
from pathlib import Path
import importlib.util
import json
import math
import hashlib

HERE = Path(__file__).resolve().parent
PRODUCER = Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015_final_checkpoint/work/receiver_probe.py')
spec = importlib.util.spec_from_file_location('r165_hard_kernels', PRODUCER)
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
np, mp = old.np, old.mp


def C(d):
    d = abs(float(d))
    # Stable equivalent of the specified G differences, including far sources.
    return float(1-d+1/3-old.expn(4, 1)-old.expn(4, d)+old.expn(4, d+1)) if d <= 1 else float(old.expn(4, d-1)-2*old.expn(4, d)+old.expn(4, d+1))


ETA = float(2*(old.expn(4, .5)-old.expn(4, 1.5)))
L0 = 24/(7*(1-math.exp(-1))**2)
NODES = {nn: np.polynomial.legendre.leggauss(nn) for nn in (48, 96)}
CACHE = {}


def one_dim(s, L, R, v, z, zg, order=96, b=1.):
    """Return I=b-free integral sqrt(p*J/wg) over the hard interval.

    L,R,v,z are ratios to b. Physical hard-overlap kernel is (b*R)^-1*I.
    """
    key = tuple(float(x) for x in (s, L, R, v, z, zg, order, b))
    if key not in CACHE:
        ll, rr, vv, zz = b*L, b*R, b*v, b*z
        lo, hi = zz-rr/2, zz+rr/2
        cuts = sorted(set([lo, hi]+[x for x in (-ll/2, ll/2, vv-b/2, vv+b/2) if lo < x < hi]))
        left, right = np.array(cuts[:-1]), np.array(cuts[1:])
        nodes, weights = NODES[order]
        x = (left[:, None]+right[:, None])/2+(right-left)[:, None]/2*nodes[None, :]
        p = ((1-s)*(np.abs(x) <= ll/2)+s*old.phi_np(x/ll))/ll
        J = old.phi_np((x-vv)/b)/b
        wg = min(1., C(v)/zg)
        value = float(np.sum((right-left)/2*(np.sqrt(p*J/wg)@weights)))
        CACHE[key] = value
    return CACHE[key]


def lam(s):
    return -math.log1p(-s*ETA)


def row(s, L, R, v, z, zg, name, b=1.):
    value = one_dim(s, L, R, v, z, zg, 96, b)
    m = math.log1p(abs(z)/C(v))
    mt = L0*abs(z)
    boundlog = (-lam(s)+m)/2
    ratio = math.exp(math.log(value)-boundlog) if value > 0 else 0.
    return dict(name=name, s=s, L_over_b=L, R_over_b=R, b=b, a_over_b=.5,
                v_minus_y_over_b=v, z_minus_y_over_b=z, zg=zg, C_v=C(v), wg=min(1., C(v)/zg),
                normalized_kernel=value, physical_kernel=value/(b*R),
                lambda_s=lam(s), M_one=m, log_normalized_bound=boundlog,
                Mtilde_one=mt, M_gate=s>0 and m<=lam(s)/2, Mtilde_gate=s>0 and mt<=lam(s)/2,
                kernel_to_Mtilde_candidate_ratio=math.exp(math.log(value)-(-lam(s)+mt)/2) if value>0 else 0.,
                kernel_to_candidate_ratio=ratio,
                GL48_GL96_abs_difference=abs(one_dim(s, L, R, v, z, zg, 48, b)-value))


def tensor(s, L, R, zg, groups, name, order=96):
    """groups=(multiplicity,v_i-y_i,z_i-y_i), all coordinates share scales."""
    n = sum(g[0] for g in groups)
    ll, m, mt = 0., 0., 0.
    for count, v, z in groups:
        if count:
            value = one_dim(s, L, R, v, z, zg, order)
            ll += count*math.log(value) if value > 0 else -math.inf
            m += count*math.log1p(abs(z)/C(v))
            mt += count*L0*abs(z)
    la = lam(s)
    candidate_log = (-n*la+m)/2
    gate = la > 0 and m <= n*la/2
    gate_tilde = la > 0 and mt <= n*la/2
    # Strip the common R^-n before comparison; report physical kernel in log.
    ratio = math.exp(ll-candidate_log) if math.isfinite(ll) else 0.
    root_fraction = math.exp(.5*math.log(n)+ll-.5*math.log(2/(math.e*la))) if gate and math.isfinite(ll) else (0. if gate else None)
    root_tilde = math.exp(.5*math.log(n)+ll-.5*math.log(2/(math.e*la))) if gate_tilde and math.isfinite(ll) else (0. if gate_tilde else None)
    return dict(name=name, s=s, n=n, L_over_b=L, R_over_b=R, zg=zg,
                groups=[list(x) for x in groups if x[0]], lambda_s=la, M=m,
                log_Rn_times_kernel=None if not math.isfinite(ll) else ll,
                log_kernel_b1=None if not math.isfinite(ll) else ll-n*math.log(R),
                log_candidate_Rn_times_bound=candidate_log, kernel_to_candidate_ratio=ratio,
                M_gate=gate, root_consequence_fraction=root_fraction,
                Mtilde=mt, Mtilde_gate=gate_tilde, root_Mtilde_consequence_fraction=root_tilde,
                kernel_to_Mtilde_candidate_ratio=math.exp(ll-(-n*la+mt)/2) if math.isfinite(ll) else 0.,
                root_comparison='n*log(2)*kernel / [log(2)*sqrt(2/(e*lambda))*sqrt(n)*R^-n]; no sqrt(K/3) factor')


def mp_C(v):
    d = abs(mp.mpf(str(v)))
    E = lambda t: mp.mpf(1)/3 if t == 0 else mp.expint(4, t)
    return 1-d+mp.mpf(1)/3-E(1)-E(d)+E(d+1) if d <= 1 else E(d-1)-2*E(d)+E(d+1)


def mp_ref(s, L, R, v, z, zg):
    s, L, R, v, z, zg = [mp.mpf(str(x)) for x in (s, L, R, v, z, zg)]
    lo, hi = z-R/2, z+R/2
    cuts = sorted(set([lo, hi]+[x for x in (-L/2, L/2, v-mp.mpf('.5'), v+mp.mpf('.5')) if lo < x < hi]))
    wg = min(1, mp_C(v)/zg)
    def f(x):
        p = ((1-s)*int(abs(x) <= L/2)+s*old.phi_mp(x/L))/L
        return mp.sqrt(p*old.phi_mp(x-v)/wg)
    return sum(mp.quad(f, [l, h]) for l, h in zip(cuts[:-1], cuts[1:]))


def main():
    initial = [row(s, .9, 1., v, z, zg, 'initial')
               for s in (0., .05, .5, 1.) for v in (0., .5, 2.) for z in (0., .25) for zg in (.5, 1.)]
    # Old I1 sources relative to original y=.3; source pairs only, no old traffic replay.
    oldcoords = [-1.1, -1.9, .5, 3.7, -.3]
    pressure = [row(s, .9, 1., v, z, 1., 'old_source_positions')
                for s in (0., .25, .5, 1.) for v in oldcoords for z in oldcoords]
    for s in (0., .05, .5, 1.):
        for L, R in ((.5, .5), (.5, 1.), (1., .5), (1., 1.)):
            edge = (L+R)/2
            for eps in (-1e-8, 0., 1e-8):
                pressure.append(row(s, L, R, 0., edge+eps, 1., 'hard_touching_boundary'))
        for v in (-32., -8., 8., 32.):
            pressure.append(row(s, .5, 1., v, 0., 1., 'far_source_stable_C'))
    svalues = [0., .001, .05, .25, .5, .9, 1.]
    scales = [(.5, .5), (.5, 1.), (.65, .9), (.9, .65), (1., 1.)]
    expanded = [row(s, L, R, v, z, zg, 'expanded_scalar')
                for s in svalues for L, R in scales for v in (-8., -2., -.5, 0., .5, 2., 8.)
                for z in (-1., -.05, 0., .05, 1.) for zg in (.5, .75, 1.)]
    tensors = []
    for s in svalues:
        for n in (1, 4, 16, 64, 256, 4096, 65536):
            for L, R in scales:
                for v in (0., .5, 2., 8.):
                    # Include gate center, near-gate, outside-gate. The latter is
                    # retained for the main candidate only, not root inference.
                    for factor in (0., .49, .75):
                        z = C(v)*math.expm1(factor*lam(s)) if s > 0 else 0.
                        tensors.append(tensor(s, L, R, 1., [(n, v, z)], f'uniform_M_factor_{factor}'))
                count = n//2
                tensors.append(tensor(s, L, R, .75, [(count, 0., 0.), (n-count, 8., 0.)], 'mixed_near_far_gate'))
    covariance = []
    for b in (.25, .5, 2., 4.):
        r = row(.5, .65, .9, 2., .05, .75, 'physical_scale_covariance', b)
        r['normalized_covariance_abs_error'] = abs(r['normalized_kernel']-one_dim(.5, .65, .9, 2., .05, .75))
        covariance.append(r)
    # Same z across all sources: expose source dependence of M and its removal
    # by the log-C bound. The two sufficient gates need not contain each other.
    uniform_examples = [row(s, .9, 1., v, z, 1., 'same_z_all_v')
                        for s in (.05, .5, 1.) for z in (.001, lam(s)/(4*L0))
                        for v in (0., .5, 2., 8., 32.)]
    logc_samples = [-64., -32., -8., -2., -1.-1e-8, -1., -.5, 0., .5, 1.-1e-8, 1., 1.+1e-8, 2., 8., 32., 64.]
    secants = [dict(v=v, u=u, logC_slope=abs(math.log(C(v))-math.log(C(u)))/abs(v-u))
               for i, v in enumerate(logc_samples) for u in logc_samples[i+1:]]
    maxsec = max(secants, key=lambda x:x['logC_slope'])
    # Decision check on the frozen R151 actual positive rows, with no new
    # receiver/kernel evaluations: does the new source-uniform gate cover any
    # of the six raw hard sources at all?
    template = next(x for x in json.loads(old.R136.read_text())['cases'] if x['id']=='I1')
    model = old.build(template, json.loads(old.R142.read_text())['cases']['I1'])
    points_path = Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json')
    oldrows = [r for r in json.loads(points_path.read_text())['point_records']['8'] if r['after'] and r['gates']['high'] and r['I']>0]
    threshold = model['n']*lam(model['s'])/2
    source_near = []
    old_sources = []
    for i, pos in enumerate(model['positions']):
        dist = sum(abs(float(x)-float(model['y'][j])) for j,x in enumerate(pos))/model['b']
        mt = L0*dist
        near = mt <= threshold
        source_near.append(near)
        old_sources.append(dict(index=i, name=template['atoms'][i]['name'], position=[float(x) for x in pos],
                                nu=float(model['nuF'][i]), l1_displacement_over_b=dist, Mtilde=mt, near=near))
    old_mass = []
    for r in oldrows:
        hm = sum((model['nuF'][i] for i in range(6) if r['hard_sources'][i]), old.F(0))
        nhm = sum((model['nuF'][i] for i in range(6) if r['hard_sources'][i] and source_near[i]), old.F(0))
        old_mass.append(dict(xq=r['xq'], hard_sources=r['hard_sources'], hardmass=float(hm), near_hardmass=float(nhm),
                             near_hardmass_fraction=float(nhm/hm) if hm else None))
    old_coverage = dict(scope='Frozen R151 I1 six-source model, eight original m8 after/high/I>0 rows; implementation gates only, not FULL.',
                        inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (old.R136,old.R142,points_path)},
                        s=model['s'], b=model['b'], n=model['n'], y=model['y'].tolist(), lambda_s=lam(model['s']), near_threshold=threshold,
                        source_records=old_sources, near_source_count=sum(source_near),
                        near_nu_mass_exact=old.fstr(sum((model['nuF'][i] for i in range(6) if source_near[i]),old.F(0))),
                        positive_rows=old_mass, decision='No source is near: coverage is exactly zero. No additional old-model sampling.')
    mp.mp.dps = 50
    references = []
    for pars in [(0., .5, 1., 0., 0., .5), (.05, .9, .7, 32., 0., 1.), (.5, .5, .5, .5, .5, .75), (1., 1., 1., 4., .01, 1.)]:
        rr = row(*pars, 'mp_reference')
        ref = mp_ref(*pars)
        rr.update(mp50_normalized_kernel=mp.nstr(ref, 30), GL96_mp50_abs_error=float(abs(mp.mpf(rr['normalized_kernel'])-ref)),
                  C_mp50_relative_error=float(abs(mp.mpf(C(pars[3]))/mp_C(pars[3])-1)))
        references.append(rr)
    scalar = initial+pressure+expanded+uniform_examples
    gates = [r for r in tensors if r['M_gate']]
    gates_tilde = [r for r in tensors if r['Mtilde_gate']]
    tensor_logdiff = tensor_rootdiff = 0.
    for rr in tensors:
        r48 = tensor(rr['s'],rr['L_over_b'],rr['R_over_b'],rr['zg'],rr['groups'],rr['name'],48)
        if rr['log_Rn_times_kernel'] is not None and r48['log_Rn_times_kernel'] is not None:
            tensor_logdiff=max(tensor_logdiff,abs(rr['log_Rn_times_kernel']-r48['log_Rn_times_kernel']))
        if rr['Mtilde_gate']:
            tensor_rootdiff=max(tensor_rootdiff,abs(rr['root_Mtilde_consequence_fraction']-r48['root_Mtilde_consequence_fraction']))
    s0 = [r for r in scalar if r['s'] == 0]
    out = dict(scope='Finite 1D-product hard-source overlap checks only. H=b scaling represented by dimensionless L/b,R/b; original FULL traffic not assumed.',
               source_producer=dict(path=str(PRODUCER), sha256=hashlib.sha256(PRODUCER.read_bytes()).hexdigest()),
               formula=dict(candidate='integral h_R(x-z)*sqrt(p*J_v/wg) dx <= R^-n*exp((-n*lambda+M)/2)',
                            eta='1-integral_[-1,1]phi=2*(E4(.5)-E4(1.5))', eta_value=ETA,
                            M='sum log(1+abs(z_i-y_i)/(b*C((y_i-v_i)/b)))',
                            Mtilde='L0*||z-y||_1/b', L0_value=L0,
                            wg='product min(1,C((y_i-v_i)/b)/zg)',
                            C_far='E4(d-1)-2*E4(d)+E4(d+1), d>1, avoiding cancellation of G constants',
                            hard_normalization='kernel=R^-n*product(one_dim_integral); R^-n retained once',
                            root='If M<=n*lambda/2 and lambda>0: n*log(2)*kernel <= log(2)*sqrt(2/(e*lambda))*sqrt(n)*R^-n; no sqrt(K/3) factor'),
               quadrature=dict(orders=[48, 96], domain='exact hard interval [z-R/2,z+R/2], no spatial truncation',
                               cuts='hard p and phi p endpoints +-L/2, phi J endpoints v+-b/2; physical scales used',
                               caveat='Float GL agreement and four mp50 checks are not interval certificates.'),
               stages=dict(initial=dict(count=len(initial), worst=max(initial, key=lambda x: x['kernel_to_candidate_ratio'])),
                           pressure=dict(count=len(pressure), worst=max(pressure, key=lambda x: x['kernel_to_candidate_ratio']),
                                         old_source_worst=max((r for r in pressure if r['name']=='old_source_positions'), key=lambda x:x['kernel_to_candidate_ratio']),
                                         hard_boundary_s0=[r for r in pressure if r['s']==0 and r['name']=='hard_touching_boundary']),
                           expanded=dict(s=svalues, scales_LR_over_b=scales, scalar_count=len(expanded), tensor_count=len(tensors),
                                         scalar_worst=max(expanded, key=lambda x:x['kernel_to_candidate_ratio']),
                                         tensor_worst=max(tensors, key=lambda x:x['kernel_to_candidate_ratio']),
                                         root_gate_count=len(gates), root_worst=max(gates, key=lambda x:x['root_consequence_fraction']),
                                         max_root_by_s={str(s): max((r for r in gates if r['s']==s), key=lambda x:x['root_consequence_fraction']) for s in svalues if s>0})),
               s0=dict(scalar_count=len(s0), main_candidate_max_ratio=max(r['kernel_to_candidate_ratio'] for r in s0),
                       root_consequence='Not evaluated: lambda=0 and lambda^-1/2 is undefined.'),
               physical_scale_covariance=covariance, mp50_checks=references,
               source_uniform=dict(logC_secant_max=maxsec, finite_secant_L0_fraction=maxsec['logC_slope']/L0,
                                   same_z_examples=uniform_examples,
                                   scalar_gate_counts={f'M={a},Mtilde={b}':sum(r['M_gate']==a and r['Mtilde_gate']==b for r in scalar)
                                                       for a in (False,True) for b in (False,True)},
                                   tensor_gate_counts={f'M={a},Mtilde={b}':sum(r['M_gate']==a and r['Mtilde_gate']==b for r in tensors)
                                                       for a in (False,True) for b in (False,True)},
                                   tilde_gate_tensor_count=len(gates_tilde),
                                   root_tilde_worst=max(gates_tilde,key=lambda r:r['root_Mtilde_consequence_fraction'])),
               frozen_I1_near_hard_coverage=old_coverage,
               summary=dict(scalar_count=len(scalar), tensor_count=len(tensors),
                            scalar_main_max_ratio=max(r['kernel_to_candidate_ratio'] for r in scalar),
                            tensor_main_max_ratio=max(r['kernel_to_candidate_ratio'] for r in tensors),
                            scalar_Mtilde_max_ratio=max(r['kernel_to_Mtilde_candidate_ratio'] for r in scalar),
                            tensor_Mtilde_max_ratio=max(r['kernel_to_Mtilde_candidate_ratio'] for r in tensors),
                            root_gate_max_fraction=max(r['root_consequence_fraction'] for r in gates),
                            root_Mtilde_gate_max_fraction=max(r['root_Mtilde_consequence_fraction'] for r in gates_tilde),
                            scalar_GL48_GL96_max_abs_difference=max(r['GL48_GL96_abs_difference'] for r in scalar),
                            tensor_GL48_GL96_max_log_kernel_difference=tensor_logdiff,
                            tensor_GL48_GL96_max_root_Mtilde_fraction_difference=tensor_rootdiff,
                            mp50_max_abs_kernel_error=max(r['GL96_mp50_abs_error'] for r in references),
                            mp50_max_relative_C_error=max(r['C_mp50_relative_error'] for r in references),
                            physical_scale_covariance_max_abs_error=max(r['normalized_covariance_abs_error'] for r in covariance),
                            main_scalar_exceedances=sum(r['kernel_to_candidate_ratio']>1+1e-10 for r in scalar),
                            main_tensor_exceedances=sum(r['kernel_to_candidate_ratio']>1+1e-10 for r in tensors),
                            Mtilde_scalar_exceedances=sum(r['kernel_to_Mtilde_candidate_ratio']>1+1e-10 for r in scalar),
                            Mtilde_tensor_exceedances=sum(r['kernel_to_Mtilde_candidate_ratio']>1+1e-10 for r in tensors),
                            root_gate_exceedances=sum(r['root_consequence_fraction']>1+1e-10 for r in gates),
                            root_Mtilde_gate_exceedances=sum(r['root_Mtilde_consequence_fraction']>1+1e-10 for r in gates_tilde)),
               limitations=['Finite menu only; no general theorem certified by these computations.',
                            'High-dimensional tensors use repeated coordinate groups; no high-dimensional quadrature or FULL traffic.',
                            'No rho/chiJ/alpha/Psi/FA/history selector or q inverse has been bounded here.',
                            'Raw hard density R^-n is retained; no additional hard16/3 cap is spent.'])
    (HERE/'hard_overlap_check.json').write_text(json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
    print(json.dumps(out['summary'], indent=2))


if __name__ == '__main__':
    main()
