# 第165轮当前合同与继承记录

本轮开始于已推送的R164提交83592d1aea0f99d4adb7bb832df30512552fa7f1。下文保留先前合同用于追溯；其中R162/R163“本轮”措辞均为历史上下文，不是当前成果。原raw保留硬来源时不乘16/3；只有切换SI5硬积分后版本才有该帽。这一规则覆盖历史段落中简写“至少保留hard16/3”的表述。

当前分工：主代理统一几何推导与source_uniform_localization.md；Astra high r164_triple_geometry负责hard_source_bridge.md；Sol high r164_audit负责audit.md并先独审命题；Sol high r164_geometry_probe负责hard_overlap_check.py/json/md。所有人不Git、不改别人文件、不自增任务。实际未启用其他agent；模型额度扣费数据不可得。

准确候选：固定原合法s,L,R,b,y,v与外硬来源z，联合积分h_R sqrt(p_y J_v/wg)；先核证明，再已有来源压力与扩大参数数值检验。主代理补充logC全局Lipschitz门，使来源近域不依v。只允许原定义、正Tonelli、Cauchy与自证初等积分；未调用GP-BRANCH未定义接口。最终一般目标未变，固定来源核界不等于原q、et、history和selector预算。外硬z不等于内部bad u，β关系不假定。

交付须明确固定参数量词、s=0边界、lambda_s费用与远域补集；检查原I1有限真实实现门上新近域覆盖率以决定下一步。独审通过后才能列为已证核工具；数值不能认证一般上界或FULL。当前轮结束后独立归档提交推送，不编译PDF。用户新8-agent配置从下一轮启用。

---

# R165 共同合同：高区混合约束与当前—终端耦合

一般目标仍为中心立方体极大算子任意正L1输入的一致 n^(1/2+o(1)) 弱型上界。本轮不继续扩大极小soft带。第162轮已提交ea6d696324b3e10ddaff6de8aff19d52344504e0。工作目录仅本round/work，各自文件负责，不操作Git，不覆盖他人改动。

原核 h=1[-.5,.5], w(u)=int_0^1 exp(-|u|/r)dr, phi=h*w,F=max(h,phi),C(d)=int_[-.5,.5]F(x-d)dx。b/2≤a≤L,R≤b≤2a（实际a≤L,R），p=P_s,L(x-y),J_v=P_1,b(x-v)，P_s,L=L^-n prod[(1-s)h+s phi]((x_i-y_i)/L)。本轮关心剩余中间soft，保留原合法s∈(0,1)，不预设产品来源。

固定预先标签和y的共同底集B0，有限正来源nu。C_i(v)=C((y_i-v_i)/b)，z∈[a/b,1]，w_z(v)=prod min(1,C_i(v)/z)，E_z=int_B0 w_z dnu，mu_z=1_B0 w_z nu/E_z。k_z(v)=#{i:C_i(v)<z}。实际Pi_j,t=eta_j(z)^-1 1_Zj,t mu_z，eta=e_t/E_z，z=c_j t/b。零分母沿原零交通；不得默认为eta下界。g=sqrt(LR),zg=c_jg/b≤1,wg=w_zg。原dt/t=dz/z；唯一j须先保留消去后再dx积分。

Q_v=(K1_v+K2_v+J_v)/3，K1=P_s,L(x-v),K2=P_s,L+(x-v),L+=min(b,(1+1/n)L)。good v: p wg(v)≤K Q_v；bad u反向严格。chiJ=J/(3Q)。K沿原参数，不能固定为1。rho_v=[1-(D K0_v+alpha J_v)/(T Delta_v)]_+；Delta_v=w_tau(v)-w_h(v)，T=c_j^(n/2)/(g^n sqrt(ell)),ell=1+log n，K0=P_s,Hhat，Hhat=max(a,min(b,H0)),H0=g c_j^(-1/2)(1-s+s phi(.5))ell^(1/(2n))。原共同alpha由alpha QJ=Dq-int U dnu，U=1_good,Delta>0 min(TDelta,DK0)，QJ=int Jdnu，q≥QJ及int K0dnu；不得重算alpha来方便估计。

实际待控接收/time交通含 p rho_v 1_good(v)1_bad(u) chiJ_v (kv-ku)+ dPi(v)dPi(u) dz/z dx，及原其他资格、hard与外beta。以上合同只显示相关因子；恢复原外价至少保留hard16/3、2Lambda及Wbeta。

已证工具：R161全位移hard矩缺口仅支s≤320000^-8/7；R160宽点也只s≤2^-80/7,zg≤2/3，均不能直接付中soft。原R159真实检验集局部矩工具已知但高权剩余未付。基础Fubini/Hölder/条件概率/直接微分可自证使用。任何新外部定理必须核原文条件。

准确pair门：L_v=J_v/wg(v)，H_v=(K1_v+K2_v+J_v)/J_v。good/bad强制 (K/3)H_u L_u<p≤(K/3)H_v L_v。若有实际H_v≤1+epsilon则仅可放松为 K L_u/3<p≤K(1+epsilon)L_v/3；epsilon必须付或来自已证门。score差delta=(|I+|-|I-|)+，I+={C_i(v)<z≤C_i(u)}，I-相反。这是全局产品似然约束，不能逐坐标分裂。

潜在线索（未证）：近阈值pair的score可大但活动时间窄；远阈值pair可能有接收似然抑制。需联合估计真实dx与共同mu_z时间，不能分别取最坏源与最坏z。已有禁区：裸时间总交通可线性；两端远同向但delta=0不能当成pair反例；固定source核分数矩在s=.25有>1有限压力点；一般来源没有独立坐标；alpha余量不能丢未控来源消费；仅有单源常数<1或改名范数不算本轮成功。

成功标准：新增可直接支付剩余实际正域的估计，或定位能改变下一步的联合几何数值规律并给准确可证明命题；必须保留所有费用。允许明确未闭合但不以重述旧归约为成果。各任务先审量词/实际可实现性，有限探路、已知压力、扩大范围分开；交付后停止，主代理整合。

## 本轮新增必须保留的原high合同

R147 audit_astra.md AA1–2已核：同一实际行q≥∫Qν及∫Jν, p e_g≥2Kq, e_t≥e_g。因此令μ_Q=Qν/q（共同次概率），r_t(v)=KQ_v/(p w_t(v)), L_t=Kq/(p e_t)≤1/2，则dΠ_t=1_Z L_t/r_t dμ_Q。r_t随t单调，dlogr_t/dlogt=k_t(v)。终端good有r_g≥1,bad有r_g<1。与R162裸核诊断不同，实际高区还强制 QJ/e_g≤p/(2K)。不能以仅满足pair/score的核数值替代这一条件。

R162新增固定pair跨core反集中有selector n(n+1)和终端振幅Ω费用，尚未付款。R144旧平方容量工具接成c≥eta_n d_v²的同域扩展证书，eta_n=4(n+1)²/(3n),d_v=(1−DK0/(TDelta))+。剩余须交c<eta_n d_v²；不能重报平方代数。严格R144付款域Hhat<Lplus,CJ≤3,Sg,D0/Psi/FA/hard/history；更大域不自动继承预算。

本轮主攻：不要再分别丢掉高区混合约束、实际同alpha和当前—终端权关系。目标是估计一般低核比来源交通，至少获得改变该瓶颈的联合界。已有R147截顶r_t势、R148/149优化源预算、R157满score固定群流量不可再重复登记。近阈值时间窄若先sup来源会失n，m跨core与score不是同一对象。本轮无需凑满模型或重复数值菜单。

## R164：必须接入原交通，而非仅优化补偿核费用
第163轮已提交5d5b918c4ae522417ce44bae94b08e6b2acbdf65；完整冻结附件在 /Users/zhengzhihao/Desktop/T/output/centered_cube_round163_20261015_final_checkpoint 。
原terminal πg=1Zg wgν/eg，R(v)=KQv/(pwg)，μ=1G(2R−1)πg，σ=(1−2R)+πg，A≤S。任意第一边际μ、第二边际≤σ的补偿计划Γ具有同alpha κ核预算≤1，其中κ=2K K0/(pwg)。m_t=(eg/et)(wt/wg)/(2R−1)恢复实际current-good边际。实际原bad u与δ(v,u)必须保留，不能替换为补偿w。补偿支上Qv/wgv>2Qw/wgw，至少一个K1/K2/J同点核比严格分离2倍。取首标签分成三支，不免除分支求和费。
已证任意有限μσ、非负有限bκ的inf费用=∫0^A bμ降序(r)κσ升序(r)dr；仅给补偿费用，不给原δ交通上界。不得再以精确lift/耦合/新未知范数命名作为本轮主要成果。
本轮准确目标：在一般剩余实际低c域，利用共同接收x下v,u,w及same-alpha、high、原产品核，得到能支付原score交通的联合几何界，最终外价C sqrt(n) polylog(n) Wβ；或用真实完整几何数值判定一种具体且可实现的预算分层是否有效，提出下一步准确命题。全部hard16/3、2Λ、原唯一j、时间、history及dx/dβ保持。若本轮不能达到，记录具体仍未证的不等式，不把row最优公式冒充付款。
原R163压力例曾错误把当前支持删到Zg的子集，最终已纠正为Zt=Zg、完整支持权重倾斜；未认证任何FULL核反例。未知η下界和receiver-dependent source优化不能免费使用。
所有人只写指定本轮文件，不Git，不改他人；先审命题、交付后停止。数值先初步、旧模型压力、扩大范围复核；有限证据不能给一般n阶。

## R165当前准确瓶颈与本轮方向
第164轮已提交83592d1aea0f99d4adb7bb832df30512552fa7f1，冻结材料在/Users/zhengzhihao/Desktop/T/output/centered_cube_round164_20261015_final_checkpoint。已证明固定参数0<H≤b、s∈[0,1]两源Hellinger重叠乘全time绝对score变化≤(8/√e)√n。它不能直接带receiver-dependent Π/Γ/selector。
原补偿lift给deficit D_x(w)=(pwg(w)−2KQw)+1Zg，三源score密度为ρ_v χJ_v wt(v)wt(u)D_x(w)/(et²egS)，含原good/bad/支持及全部门。与√(H_vH_w)比较出现逆核系数，尚未付款。R164八个原实现门正点n4的κ最优donor均原bad G4，所有positive仍lowc，κ成本比traffic小约16020；不能把这个有限结果当一般反例。
本轮避免再次仅分析该逆核量。重点保留原hard来源z'和raw q^-1 p h_R(x−z') a_ω ν(dz')，在原βdy、唯一j、history合同中先建立接收重叠，再考虑16/3硬帽；不得把硬帽与raw硬积分重复计价。需要读原定义时仅查R136 ordered_score_capacity.md §4及对应research.tex/原接口，不全读历史。
准确目标仍一般任意正L1一致sqrt(n)n^o(1)上界；本轮成功应为接回实际交通的真实付款分支或改变下一步决策的联合几何证据，而非新余项名称、固定核估计重复。所有分支和常数依赖须明示，finite模型不认证FULL。每人仅指定文件，完成停止，主代理统一Git。
