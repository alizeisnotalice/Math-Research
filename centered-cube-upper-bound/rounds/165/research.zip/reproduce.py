#!/usr/bin/env python3
"""Local replay: historical input paths are specified in hard_overlap_check.py."""
import argparse, hashlib, importlib.util, json, pathlib, sys
sys.dont_write_bytecode=True
root=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir');args=p.parse_args()
manifest=json.loads((root/'manifest.json').read_text())
for name,digest in manifest['sha256'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
print('Archive member hashes verified; this is not a mathematical proof.')
if not args.verify_only:
    if not args.output_dir:p.error('--output-dir is required for replay')
    target=pathlib.Path(args.output_dir).resolve();target.mkdir(parents=True,exist_ok=True)
    if target==root:p.error('use an output directory outside the frozen archive')
    spec=importlib.util.spec_from_file_location('r165_replay',root/'hard_overlap_check.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    m.HERE=target;m.main()
    expected=json.loads((root/'hard_overlap_check.json').read_text());actual=json.loads((target/'hard_overlap_check.json').read_text())
    assert actual==expected,'Replay output differs; investigate platform/numerical differences.'
    print('All replay JSON fields match.')
