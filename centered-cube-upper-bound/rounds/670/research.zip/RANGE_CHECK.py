from pathlib import Path
import flint,json,sys,platform,hashlib
from flint import arb,ctx
ctx.prec=256;ctx.threads=1
rows=[]
for stage,ns in [('preliminary',[256,1024]),('boundary_stress',[65536,2**20]),('expanded',[2**32,2**48])]:
 for N in ns:
  n=arb(N);c0=1+1/(32*n);c=c0**N;tau=16384*n.sqrt()
  log2=arb(2).log();m=N
  loss=2*c
  assert loss<arb(64)/31 and loss<tau/16
  assert log2/n<=log2
  retained=arb(1)/2-arb(1)/16-arb(1)/8
  assert retained==arb(5)/16 and retained>arb(1)/4
  conditional_log=arb(3).log()+2*n.log()-tau/64
  upper_log=(arb(72)/256**4).log()
  assert conditional_log<upper_log
  up_fee_log=arb(8).log()-tau.log()+n*(1+2*c0/n).log()
  rows.append({'stage':stage,'n':N,'subdivisions':m,'log_ratio':str(log2/m),'lower_deleted_rate_bound':str(loss),'lower_budget':str(tau/16),'conditional_log_fee':str(conditional_log),'upper_rim_fee_log':str(up_fee_log),'pass':True})
out={'pass':True,'precision_bits':ctx.prec,'python':platform.python_version(),'interpreter':sys.executable,'flint':flint.__version__,'cases':rows,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'six finite interval checks for final n-subdivision rule; geometric proof separate, within-bucket column budget remains unproved'}
Path(__file__).with_name('RANGE_RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'pass':True,'cases':len(rows),'subdivisions':[(r['n'],r['subdivisions']) for r in rows],'scope':out['scope']},indent=2))
