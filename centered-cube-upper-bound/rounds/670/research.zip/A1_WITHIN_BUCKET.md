# R670 A1 — a paid scale-edge branch and a fixed spatial arrangement

## Result and remaining scope

A real whole-family receiver branch is paid below:

    |Y_up| ≤ [8 e^(2c0)/tau] U.                            (0.1)

For every remaining actual target, subdivision of its dyadic radius bucket into exactly n equal-logarithmic intervals produces an auxiliary common source range with load greater than 5tau/16. Within each interval the source range and source prefix are fixed; the remaining pool is exactly the set of those fixed cubes containing the actual witness. The same fixed load function is high at the witness and at most 1 throughout the target's entire small box.

This yields a concrete arrangement-cell cover and a legal full-common-pool merging rule. Its global source-column cost remains unproved. Thus the paid branch (0.1) and the exact geometric reduction do not complete V_near≤CU, the original expected-receiver bound, or the general pure sqrt(n) theorem.

All original q_i, I_h, F_i, X_h, witnesses, radius order, L_h, Poisson pools, full first-k histories and repeat masks remain unchanged. Removing sources below refers only to auxiliary candidate cores for a deterministic cover. It never deletes the self source from the original pool or changes its random process. Original low-load bounds involving the complete I_h still include the correct 1+q_h term.

## 1. Pay actual receivers with substantial large-radius near load

For each actual near target define

    I_h^up={i∈I_h:s_i≥(n/2)s_h},
    T_h^up=Σ_{i∈I_h^up}q_i,
    H_up={h:T_h^up≥tau/8},
    Y_up=union_{h∈H_up}X_h.                                (1.1)

This is a deterministic partition of the actual receivers. It does not change any I_h. For h∈H_up, distribute its true demand by

    z_hi=|X_h| q_i/T_h^up     for i∈I_h^up.                 (1.2)

These transfers sum exactly to |X_h|. If i∈I_h^up, the actual witness geometry gives

    X_h⊂A_i+c0s_h Q
        ⊂Q(y_i,(1+2c0/n)s_i).                             (1.3)

The X_h are disjoint over the entire family, including different scales and buckets. Therefore the total debit of a fixed source is at most

    Σ_{h:i∈I_h^up}z_hi
      ≤(8q_i/tau) Σ_{h:i∈I_h^up}|X_h|
      ≤(8q_i/tau)(1+2c0/n)^n d_i.

Summing each true source capacity q_i d_i=|F_i| once yields

    |Y_up|≤(8/tau)(1+2c0/n)^n U
           ≤(8 e^(2c0)/tau)U.                             (1.4)

No target-count, scale-count or normal-direction factor is omitted. In particular, this fee is paid once globally, not once per dyadic bucket. Receiver roughness is irrelevant because only measure and disjointness were used. The proof is a direct allocation, not a random-key replacement.

For the remaining targets h∉H_up,

    T_h^up<tau/8.                                         (1.5)

## 2. Exactly n subdivisions eliminate the variable source scale range

Fix a dyadic target bucket [r,2r). Subdivide it into n intervals [a,b), with consecutive endpoints r·2^(j/n), j=0,…,n. Thus

    b/a=2^(1/n),     b≤2a.                                (2.1)

Only actual remaining targets with a≤s_h<b are considered in this interval. Put

    G_[a,b)={i:q_i>0, b≤s_i<na}.                           (2.2)

This range is the same for every such target. Define its retained auxiliary pool by

    J_h=I_h intersect G_[a,b).                             (2.3)

There are two possible scale deletions from I_h.

For sources with s_i<b, the actual common witness z_h lies in every A_i and F_i⊂B_i, so

    F_i⊂Q(z_h,c0b),       d_i≥(2a)^n.

The actual F_i are disjoint. Hence the entire lower-band rate obeys

    Σ_{i∈I_h:s_i<b}q_i
      =Σ |F_i|/d_i
      ≤(2c0b)^n/(2a)^n
      =2c0^n≤64/31.                                     (2.4)

No perimeter, product structure or density regularity of F_i is assumed. This rate bound includes the original self source when it is present; it does not remove that source from the original process.

For sources with s_i≥na, use s_h<b≤2a to get

    s_i≥na≥(n/2)s_h.

Thus this upper deletion is contained in I_h^up, and costs less than tau/8 by (1.5). Combining with T_h>tau/2,

    T(J_h)>3tau/8−2c0^n>5tau/16>tau/4.                   (2.5)

The second inequality holds in the actual nonempty-near regime n≥256; the inherited construction has no near targets below that regime. In fact 2c0^n≤64/31 is much smaller than tau/16 there.

This is a rate budget on an auxiliary core, not an alteration of the original saturation pool. The whole-family payment (1.4) is the only receiver mass removed in this preprocessing.

## 3. The remaining pools are exact sections of one fixed cube arrangement

The audited original definition is the full near witness pool

    I_h={i:q_i>0, z_h∈A_i, s_h≤s_i<ns_h}.                  (3.1)

It may include h. For i∈G_[a,b), however, s_i≥b>s_h, so actual radius-descending order puts i before every target in this subinterval. Also s_i<na≤ns_h. Therefore (2.3) becomes the exact identity

    J_h={i∈G_[a,b):z_h∈A_i}.                              (3.2)

There is no varying source-prefix condition left in (3.2). This conclusion uses the complete original pool definition and actual radius order, not an assumed independent or freely chosen source set.

Define the fixed spatial load

    g_G(z)=Σ_{i∈G_[a,b)}q_i1_{A_i}(z).                     (3.3)

Equation (2.5) says g_G(z_h)>5tau/16. Original center admission also supplies a stronger-than-receiver-only low-load fact. All G sources are earlier than h; if x∈B_h∩A_i, then

    ||y_h−y_i||∞≤s_i+s_h/a≤c0s_i.

Consequently, throughout the whole small box B_h,

    g_G(x)
      ≤Σ_{i∈G}q_i1_{Q(y_i,c0s_i)}(y_h)
      ≤1.                                                (3.4)

The true geometry after preprocessing is thus

    g_G(z_h)>5tau/16,
    g_G≤1 on B_h,
    ||z_h−y_h||∞≤s_h,
    X_h⊂B_h,  with the actual X_h disjoint.                 (3.5)

In particular, these are not arbitrary high-load incidence sets. A candidate cover must keep the witness positions, the low-load receiver boxes, the actual demands |X_h|, and the original source owners. It is not authorized to replace the true receivers by the entire neighborhood of the high-load set.

## 4. Concrete arrangement-cell cover and exact merge rule

For the finite fixed family {A_i:i∈G}, take its stratified axis-parallel face arrangement. Including lower-dimensional strata handles a witness on a parent boundary; no generic-position assumption is needed. Retain only strata which contain at least one actual remaining witness z_h in this subinterval.

Group the actual targets by their witness stratum. On such a stratum the containing-source set is constant, so each initial group C has common pool

    J_C=intersection_{h∈C}J_h,
    T_C=Σ_{i∈J_C}q_i>5tau/16.                              (4.1)

The receiver assigned to that group is exactly Y_C=union_{h∈C}X_h. It is not the full stratum or its full neighborhood.

More generally, for any group define its witness box hull

    Z_C=product_{ell=1}^n
          [min_{h∈C}z_h,ell, max_{h∈C}z_h,ell].

Because the A_i are axis-parallel boxes, the common pool has the exact geometric description

    J_C={i∈G:Z_C⊂A_i}.                                    (4.2)

Starting from the occupied-stratum groups, repeatedly merge two groups only if their updated full common pool has load at least tau/4. Namely use

    J_new=J_C1 intersect J_C2,
    Σ_{i∈J_new}q_i≥tau/4.                                 (4.3)

One may select the first eligible pair in a fixed finite ordering to make the rule deterministic. Each merge reduces the number of groups, so the procedure terminates. It preserves a partition of all remaining actual targets and keeps each group's full common load at least tau/4. Equation (4.3) recomputes the full intersection accumulated so far; it is not a pairwise-similarity surrogate for a many-target intersection.

For any final or intermediate group, let r_C=max_{h∈C}s_h and K_C=intersection_{i∈J_C}A_i. Every actual witness belongs to K_C, and the true receiver geometry yields

    Y_C⊂K_C+c0r_C Q.                                     (4.4)

All common sources have s_i≥b>r_C and s_i<na≤nr_C. The actual disjoint F_i and their weights are retained.

The separate R670 threshold-extension proof is required at this point: conditional on its independently bound extension of R662 to T_C≥4096 sqrt(n)=tau/4, the inherited complete-intersection estimate gives

    |Y_C|≤|K_C+c0r_C Q|
          ≤exp(−T_C/8) Σ_{i∈J_C}|F_i|.                   (4.5)

The author and preliminary independent audit of that threshold bridge reported success; final binding belongs to S1/S2, not this note. No new proof of the local theorem or its constants is claimed here.

## 5. Exact unpaid source-column budget

The concrete procedure above gives a legal integral cover, hence also a fractional cover with unit weights. It does **not** prove that its total source charge is bounded. More flexible nonnegative weighted groups lambda_C may also be considered, provided they cover the actual remaining receivers, for example by

    Σ_{C:h∈C}lambda_C≥1   for every remaining actual h.      (5.1)

The exact cumulative full-family source account is

    V_near
      ≤[8e^(2c0)/tau]U
         +Σ_i|F_i| Σ_{C:i∈J_C}lambda_C exp(−T_C/8).       (5.2)

This formula explicitly adds the already paid scale-edge branch and the subsequent core charges. It never spends a source again without recording its additional coefficient.

The main unproved quantity is the weighted column sum on the right of (5.2), within one fixed subinterval arrangement. A source can belong to many final cores. Failure of further pair merging gives only an intersection-load test; it does not establish a summable return or column bound. No per-source constant, exp(tau/64) column bound for each fixed subinterval, or weaker |F_i|-weighted total bound has been proved for this procedure.

The n subdivisions introduce only a known polynomial overhead. A source occurs in at most L_n=ceil(log2 n)+2 original dyadic near buckets, and thus at most nL_n fixed-range subintervals. If one could prove a within-subinterval fractional column bound M_n, then the remaining conditional fee would be

    nL_n M_n exp(−tau/32) U.                              (5.3)

Use the same fixed-subinterval convention throughout: if M_n≤exp(tau/64), then nL_n≤3n² and (5.3) gives the conditional remaining fee

    nL_n M_n exp(−tau/32) U
      ≤3n² exp(−tau/64) U
      ≤(72/256⁴) U.                                      (5.4)

Here tau/64=256 sqrt(n), and the last inequality follows from e^x≥x⁴/24 with x=256 sqrt(n). This column bound is required separately for every fixed subinterval; it is not a bound after combining a whole original dyadic bucket. The arrangement construction does not prove it.

The decisive missing geometric step is therefore specific: use the actual fixed cube arrangement, its disjoint source owners, and the high/low configuration (3.5) to control source reuse in a cover of only its actual occupied receiver groups. Counting all arrangement cells or summing whole expanded bodies without the column coefficient would reintroduce an unpaid, potentially large source repetition. The high/low constraints have been retained, but no such column inequality has been established in this bounded task.

## Verification and stop

The paid branch (1.4), narrow-band bound (2.4), exact fixed-ground-set identity (3.2), whole-box admission bound (3.4), and arrangement/full-intersection merge rule are proved analytically above. The original full I_h definition was checked against R669's source-index audit, which quotes the R660/R662 exact definitions. The parent confirmed the full-pool identity before its use here.

The parent assigned independent Sol verification of the paid scale-edge branch and fixed-arrangement reduction, as well as the separate threshold bridge. No duplicate numerical experiment, abstract incidence scan, MATLAB session, Git operation, PDF compilation or edit to another agent's file was performed. The earlier gamma-choice exploration is omitted in favor of the exact n-way equal-log subdivision.

This is a bounded checkpoint: one genuine full-family branch is paid, and the remaining geometry is made fixed in both scale and prefix. The original complete receiver budget is still open because the occupied-arrangement source-column estimate in (5.2) is not proved. Work stops here for independent audit and integration.
