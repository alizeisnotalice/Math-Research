from pathlib import Path
import json,platform,hashlib,time
import flint
from flint import arb,ctx
ctx.prec=256;ctx.threads=1
p=Path(__file__).resolve().parent
E=arb(1).exp()
constants=[]
for name,val,limit in [
 ('large_x_squared_ratio',128*E**8/2048**2,arb(1)/9),
 ('large_x_linear_ratio',32*E**9/2048**2,arb(1)/8),
 ('small_x_ratio',4*E.sqrt()/2048,arb(1)/4),
 ('n_over_k_coefficient',8*E**2,arb(100)),
 ('prefactor_absorption',(2*E+1).log(),arb(8192)),
 ('large_L_absorption',1+arb(3).log(),arb(8192)),
 ('tail_absorption',1+arb(3).log(),arb(32768))]:
 gap=limit-val;assert gap>0
 constants.append({'name':name,'positive_gap_interval':str(gap)})
results=[];skips=[];start=time.monotonic()
for stage,ns in [('preliminary',[256,2**20]),('seam_stress',[2**24]),('expanded',[2**32,2**48])]:
 for N in ns:
  n=arb(N);c0=1+1/(32*n);c=c0**N
  for factor in (1,2,8):
   T=4096*n.sqrt()*factor;theta=T/c;lower=theta-1
   seam=lower+n*(4*c0*n/theta).log()
   candidates=[('lower',lower),('x1',n),('seam_minus',seam-arb(1)/1024),('seam',seam),('seam_plus',seam+arb(1)/1024),('expanded_L',lower+n*n.log())]
   base=int(float(2*theta))
   while not arb(base)>=2*theta:base+=1
   for name,L in candidates:
    if name=='lower':legal=True
    else:legal=L>=lower
    if not legal:
     skips.append({'stage':stage,'n':N,'factor':factor,'L_kind':name,'reason':'below or unresolved against L>=theta-1'});continue
    useA=(name=='seam' or L>=seam)
    if not useA and not L<seam:
     skips.append({'stage':stage,'n':N,'factor':factor,'L_kind':name,'reason':'splice comparison unresolved'});continue
    for mult in (1,2,8):
     k=arb(base*mult)
     if useA:
      val=(arb(3)/c).log()+1-theta+n*(1+c0*((-L-1+theta)/n).exp()).log()
      branch='A'
     else:
      assert 2*L/theta>1
      A=n*(L/n).exp()
      first=arb(2).log()-L+2*(2*E*A*(2*L/theta).log()).sqrt()+8*E*A/k
      second=(k/(k-1)).log()+n*(1+c0).log()-T.log()-(k-1)*n
      assert first>second
      val=first+(1+(second-first).exp()).log();branch='C'
     target=100*n/k-T/8;res=val-target
     results.append({'stage':stage,'n':N,'factor':factor,'T':str(T),'L_kind':name,'L':str(L),'k':base*mult,'branch':branch,'residual_interval':str(res),'strict_negative':res<0})
assert results and all(r['strict_negative'] for r in results)
out={'pass':True,'precision_bits':ctx.prec,'python':platform.python_version(),'interpreter':__import__('sys').executable,'python_flint':flint.__version__,'checks':len(results),'constants':constants,'skips':skips,'results':results,'wall_seconds':time.monotonic()-start,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'finite 256-bit Arb point checks of inherited scalar bounds under candidate T>=4096sqrt(n); not continuous-domain proof, actual input construction, or global budget'}
(p/'SPLICE_RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({key:out[key] for key in ['pass','precision_bits','python','python_flint','checks','wall_seconds','scope']},indent=2))
