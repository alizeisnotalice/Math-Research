# R670 S2 — R662 intersection threshold lowered to `4096 sqrt(n)`

**Verdict: PASS.** For the same real common-point sources and the same iid-with-replacement sampling law as R662, the conclusion

```
E | (intersection of the k sampled A_i) + c0 r [-1,1]^n |
    ≤ U exp(100n/k - T/8)                                  (1)
```

holds under `n≥256`, `T≥4096 sqrt(n)` and integer `k≥2T/c`, where `c=c0^n`. The proof below checks the whole splice, including both branches, both ranges of `L/n`, the low-level tail and the final absorption. This is a local intersection lemma, not a global receiver-budget payment. It does not by itself bound repeated source charges across targets.

Read/applied: `math-research`, `python-math`, and `math-l03-rational-and-interval-certificates`, including the latter's provenance boundary. The allowed R662 estimates (A)–(C) are used as proved tools; no external theorem is imported. The only computation is the requested small 256-bit Arb constant certificate. No scan, MATLAB session, subprocess left running, or other file write.

## 1. Assumptions and all inherited ranges

Keep the R662 finite family:

- `a=32n`, `c0=1+1/a`, `c=c0^n`, `A_i=Q(y_i,s_i)`;
- genuine disjoint `F_i⊂Q(y_i,s_i/a)` with `q_i=|F_i|/(2s_i)^n`;
- all `A_i` contain one common point, and `s_i≥r>0`;
- `T=Σ_i q_i`, `U=Σ_i|F_i|`, and each sampled label has law `q_i/T`.

Zero-weight labels may be omitted. The new load assumption makes `T,U>0`. Put

```
theta = T/c,
L = log[ U/(c(2r)^n) ],
A = n exp(L/n).
```

The same cumulative-source-volume estimate used in R662 gives

```
L≥theta-1.                                               (2)
```

Indeed its layer bound gives `T≤c(1+L)`; `U≥T(2r)^n` ensures the relevant logarithmic branch is the one used there. Also

```
1≤c≤2,   1<c0≤2,
theta≥2048 sqrt(n)≥32768,
k≥2theta>1.                                              (3)
```

The sharper `c≤32/31` is available but unnecessary. In particular `L>0`, `L≥theta/2`, and `log(2L/theta)≥0`.

The prerequisites of R662's (A)–(C), before its old uniform-splice threshold is imposed, remain satisfied:

1. Its sample-minimum bound needs `theta≥2` and `k≥2theta`.
2. The low-level cut is above r because, for `lambda=T exp(-t)`,
   `L_lambda=L+log(2/theta)+t≥theta-1+log(2/theta)>0`.
3. The comparisons `L_lambda≤L+t` and `log(2L/theta)≥0` need only `theta≥2` and (2).
4. The low-level tail integration needs `k>1`.

Thus the old `8192 sqrt(n)` requirement does not reappear inside (A)–(C). The finite-parameter proof below changes only their splice.

Write M for the expectation on the left of (1). The imported bounds are

```
M ≤ (3/c) U exp(1-theta)
       [1+c0 exp(-(L+1-theta)/n)]^n,                       (A)
```

and

```
M ≤ 2U exp(-L+S+R) + D,                                  (C)
S = 2 sqrt(2e A log(2L/theta)),
R = 8e A/k,
D = [k/(k-1)] (1+c0)^n (U/T) exp(-(k-1)n).
```

These are exactly R662's displayed estimates, with no change to the sampling law or receiver measure.

## 2. Large-L branch

Suppose

```
L ≥ theta-1+n log(4c0n/theta).                             (4)
```

Then `c0 exp(-(L+1-theta)/n)≤theta/(4n)`, and `(1+t)^n≤exp(nt)` gives from (A)

```
M ≤ (3/c)U exp(1-3theta/4)
  ≤ U exp(-theta/2).                                      (5)
```

The last step uses `log(3/c)+1≤log 3+1<theta/4`, certified below at the minimum `theta=32768`. Since `T/8=c theta/8≤theta/4` and `100n/k≥0`, (5) implies (1). Equality in (4) is included in this branch.

## 3. Complementary branch and its full domain

Now suppose (4) fails. Set

```
v=theta/n,   x=L/n.
```

Combining its strict reverse with (2) yields

```
0<v<4c0≤8,
x≤v+log(8/v),
x≥v-1/n>0,
v²n=theta²/n≥2048².                                      (6)
```

The first inequality follows because the logarithm in (4) must be positive; thus no `v≥8` subdomain has been omitted. Also `2x/v=2L/theta>1`, so every logarithm below is nonnegative.

### 3a. The range `0<x≤1`

Here `A=n exp(x)≤en`. With `y=L/theta≥1-1/theta>1/2`, the elementary maximum

```
max_{y≥1/2} log(2y)/y² = 2/e
```

(obtained by differentiation, with critical point `y=sqrt(e)/2`) gives

```
S/L ≤ 4 sqrt(e) sqrt(n)/theta
    ≤ 4 sqrt(e)/2048 < 1/4.                               (7)
```

The actual `R` term is retained as an additive `n/k` cost:

```
R≤8e²n/k.
```

There is no need to claim `R/L` is small in this range. Therefore

```
-L+S+R
 ≤ -3L/4+8e²n/k
 ≤ -theta/2+1+8e²n/k,                                    (8)
```

using `L≥theta-1`. This covers x=1 as well.

### 3b. The range `x≥1`

From (6), `exp(x)≤8exp(v)/v`. Since `v<8` and `x≥1`,

```
v exp(x)/x ≤ 8e^8.                                       (9)
```

Furthermore, the elementary inequality

```
v log(2x/v) ≤ 2x/e       for every v>0
```

has equality at `v=2x/e`. Hence

```
v² exp(x) log(2x/v)/x²
 ≤ 8exp(v) v log(2x/v)/x²
 ≤ 16e^7/x
 ≤ 16e^7.                                                (10)
```

Consequently, retaining every n, v and k factor,

```
(S/L)²
 = 8e exp(x)log(2x/v)/(n x²)
 ≤ 128e^8/(v²n)
 ≤ 128e^8/2048²
 < 1/9,                                                 (11)
```

and, since `k≥2theta=2vn`,

```
R/L = 8e exp(x)/(kx)
    ≤ [4e/(v²n)] [v exp(x)/x]
    ≤ 32e^9/2048²
    < 1/8.                                              (12)
```

Thus `S/L<1/3` and

```
-L+S+R
 ≤ -(1-1/3-1/8)L
 = -13L/24
 ≤ -L/2
 ≤ -theta/2+1/2.                                        (13)
```

The strict inequalities in (11)–(12) were actually certified with Arb. Combining (8) and (13), the first term of (C), throughout the complementary branch, is at most

```
2e U exp(-theta/2+8e²n/k).                                (14)
```

## 4. Tail term and final absorption

From `T≥2`, `k≥2`, `1+c0≤3`,

```
D/U ≤ exp([log 3-(k-1)]n).
```

Because `k≥2theta` and `theta≥32768>1+log 3`,

```
k-1-log 3 ≥ theta,
D ≤ U exp(-theta n) ≤ U exp(-theta/2).                    (15)
```

Here `n≥256` is more than sufficient for the final comparison. Thus (14)–(15) yield

```
M ≤ (2e+1)U exp(-theta/2+8e²n/k).
```

Use the certified scalar inequalities

```
log(2e+1) < 32768/4 ≤ theta/4,
8e² < 100,
T/8=c theta/8≤theta/4.
```

It follows that

```
M ≤ U exp(8e²n/k-theta/4)
  ≤ U exp(100n/k-T/8),                                   (16)
```

as required. The large-L branch was already handled by (5). This completes the all-domain proof of the threshold reduction; no parameter grid or sampled input family is used.

## 5. Actual outward interval certificates

Executed the specified local interpreter `/Users/zzh/.local/share/math-research-tools/venv/bin/python`. It reported Python `3.12.14`, python-flint `0.9.0`, Arb precision `256` bits. All inputs were exact integers/rationals; e was evaluated by Arb exponential, and every test asserted a strictly positive *ball* residual. The printed balls below are certified enclosures, not point estimates.

```
128e^8/2048² = [0.0909716182568886802595090362381862998582753888 +/- 3.26e-47]
1/9 - above = [0.0201394928542224308516020748729248112528357223 +/- 4.37e-47]

32e^9/2048² = [0.0618216242033034058205413565783139035416524970 +/- 8.00e-48]
1/8 - above = [0.0631783757966965941794586434216860964583475030 +/- 8.02e-48]

4sqrt(e)/2048 = [0.00322015873183618778681377106994953822588628145 +/- 3.31e-48]
1/4 - above = [0.246779841268163812213186228930050461774113719 +/- 4.47e-46]

8e² = [59.1124487914452018178434196846000625054425246 +/- 3.56e-44]
100 - above = [40.8875512085547981821565803153999374945574754 +/- 3.56e-44]

log(2e+1) = [1.86199480405825108163497406628943420808088428 +/- 1.06e-45]
8192 - above = [8190.13800519594174891836502593371056579191912 +/- 4.29e-42]

1+log 3 = [2.09861228866810969139524523692252570464749056 +/- 2.18e-45]
8192 - above = [8189.90138771133189030860475476307747429535251 +/- 5.59e-43]
32768 - above = [32765.9013877113318903086047547630774742953525 +/- 9.45e-42]

ALL 7 CONSTANT CERTIFICATES PASS
```

Reproducer, embedded to respect single-file ownership:

```python
import sys, flint
from flint import arb, ctx
ctx.prec=256
e=arb(1).exp()
tests=[
 ('large_x_squared_sqrt_ratio',128*e**8/arb(2048)**2,arb(1)/9),
 ('large_x_Aterm_ratio',32*e**9/arb(2048)**2,arb(1)/8),
 ('small_x_sqrt_ratio',4*e.sqrt()/2048,arb(1)/4),
 ('retained_n_over_k_coefficient',8*e**2,arb(100)),
 ('constant_absorption_log',(2*e+1).log(),arb(32768)/4),
 ('large_L_prefactor_log',arb(3).log()+1,arb(32768)/4),
 ('tail_log_constant',1+arb(3).log(),arb(32768)),
]
print('Python:',sys.version.split()[0])
print('python-flint:',flint.__version__)
print('Arb precision bits:',ctx.prec)
for name,value,ceiling in tests:
    gap=ceiling-value
    assert value<ceiling and gap>0
    print(name)
    print('  enclosure =',value.str(45))
    print('  upper comparator =',ceiling.str(45))
    print('  positive residual =',gap.str(45))
print('ALL 7 CONSTANT CERTIFICATES PASS')
```

The finite computation certifies only these seven scalar inequalities. The all-parameter conclusion comes from §§1–4 with the already proved (A)–(C). No numerical library is treated as covered by the skill's unfinished general API audit. The actual process exited normally. The general `Vnear≤CU` objective is unaffected by this local threshold bridge alone.
