from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).resolve().parent
for name in ('SPLICE_CHECK.py','RANGE_CHECK.py','verify.py'):ast.parse((p/name).read_text())
for script,result in [('SPLICE_CHECK.py','SPLICE_RESULT.json'),('RANGE_CHECK.py','RANGE_RESULT.json')]:
 r=json.loads((p/result).read_text());assert r['pass']
 assert r['script_sha256']==hashlib.sha256((p/script).read_bytes()).hexdigest()
r=json.loads((p/'SPLICE_RESULT.json').read_text());assert r['checks']==192 and len(r['constants'])==7 and all(x['strict_negative'] for x in r['results'])
r=json.loads((p/'RANGE_RESULT.json').read_text());assert len(r['cases'])==6 and all(x['pass'] and x['subdivisions']==x['n'] for x in r['cases'])
s=(p/'REPORT.tex').read_text()
assert s.count(r'\begin{document}')==s.count(r'\end{document}')==1
assert sorted(re.findall(r'\\begin\{([^}]+)\}',s))==sorted(re.findall(r'\\end\{([^}]+)\}',s))
for name in ('REPORT.tex','A1_WITHIN_BUCKET.md','S2_THRESHOLD.md'):
 assert hashlib.sha256((p/name).read_bytes()).hexdigest() in (p/'S1_THRESHOLD_AUDIT.md').read_text(),name
m=p/'MANIFEST.json'
if m.exists():
 for name,v in json.loads(m.read_text())['members'].items():
  b=(p/name).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps({'pass':True,'scope':'artifact integrity, saved interval records and final audit bindings, not a proof verifier','manifest_checked':m.exists()}))
