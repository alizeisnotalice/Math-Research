# R670 continuation

General arbitrary-L1/all-scale/fixed-Lebesgue pure C_n<=K sqrt(n) remains OPEN. Latest previous push R669 32076797509502ee5b56878a107d4a6539a29f49; this round to be independently committed after final audit.

New verified bridge: same R662 iid intersection bound U exp(100n/k-T/8) now valid for n>=256,T>=4096sqrt(n)=tau/4,k>=2T/c. Whole-domain proof in S2 and independent exact/Arb audit, not extrapolation from 192 point checks. Complete-intersection fee U exp(-T/8) follows by fixed set containment and inf over k. This repairs the earlier insufficient common-core margin.

New full-family payment: upper-rim load R_h=sum_{Ih:si>=n sh/2}qi. Targets R_h>=tau/8 have Vup<=K_up(n) U/tau with K_up=8(1+2c0/n)^n<=8e^(2c0). Pay ONCE globally, never per bucket. Remaining targets have rim rate<tau/8.

Final exact preprocessing: divide each dyadic target bucket into n equal-log intervals [alpha,beta), beta/alpha=2^(1/n). Lower sources si<beta have rate<=2c<=64/31<tau/16; upper si>=nalpha are in rim with rate<tau/8. Auxiliary J_h=Ih intersect {beta<=si<nalpha} has rate>5tau/16. Ground G of those positive source labels is fixed for interval. Every G source strictly earlier than every target; J_h={i in G:zh in Ai}. Original q/Ih/Poisson pools unchanged; R669 self correction remains for original pools, and auxiliary self removal is explicitly paid by lower-band rate.

Actual spatial constraints: g_G(zh)>5tau/16, g_G<=1 on all Bh, zh in Ah, Xh subset Bh, genuine receiver pieces disjoint, true Fi disjoint small boxes. No arbitrary-incidence substitution.

A concrete LEGAL cover exists: occupied source-arrangement strata group true witnesses/targets, then merge only using full common core intersection with rate>=tau/4. Full core equals sources containing witness coordinate hull. This preserves all real receiver coverage and local theorem scope. WHAT IS UNPROVED: the integrated source-column debit of this or a better fractional cover. It is incorrect now to say mere legal cover existence is missing.

For each core C fee<=exp(-Tcore/8) sum_core |Fi|. Main required estimate is the weighted TOTAL column sum <=AU over actual receiver cover, not necessarily a stronger pointwise column cap. Sufficient conditional cap per subinterval is exp(tau/64): each source occurs in <=n(ceil log2n+2)<=3n^2 intervals; total remaining fee<=3n²exp(-tau/64)U<=72/256^4 U. Scalar absorption is not proof of column cap. Original full account includes U+(Kfar+Kup)U/tau+Vremaining; no source fees disappear.

Numerics: prescribedPython3.12.14/flint0.9.0, 256-bit Arb7 constants, 192 splice point checks (three stages with skips logged), 6 final n-subdivision scalar checks. No actual full geometric simulation or column certificate. No MATLAB/PDF/software installation.

Next: attack source reuse for the actual fixed arrangements/high-low receiver geometry. Do not re-prove threshold, scale preprocessing, generic Hall, conditional race or source-only chain identities. Max1 Astra+3Sol; no idle slot filling. Keep all source/data ownership and separate round commits; no full theorem claim before genuine column/receiver payment.
