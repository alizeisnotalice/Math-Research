# R670：local intersection 阈值4096√n独立审查

**最终结论PASS。** 在R662同一真实有限共点来源及同一iid-with-replacement抽样law下，将T阈值从8192√n降为4096√n，仍可保留

M=E| (∩_{ℓ≤k}Aᵢℓ)+c₀r[-1,1]ⁿ |
 ≤U exp(100n/k−T/8)，

适用n≥256、T≥4096√n、integer k≥2T/c，c=c₀ⁿ、a=32n、c₀=1+1/a。该结果是局部阈值桥，不是全局AU付款，也未构造qualified cluster cover。

按父任务要求，先独立核对全域拼接并发送结论、运行一次exact Fraction常数核对，随后才读作者S2_THRESHOLD.md。只使用已审R662(A)–(C)及L≥θ−1，不重跑任何parameter grid，不spawn/Git/PDF/MATLAB，不改其他文件。

## 1. 准确量词和继承前提

有限family的Aᵢ=Q(yᵢ,sᵢ)共同含一点，sᵢ≥r>0；真实不交Fᵢ⊂Q(yᵢ,sᵢ/a)，qᵢ=|Fᵢ|/(2sᵢ)ⁿ；T=Σqᵢ、U=Σ|Fᵢ|。每次label draw独立取qᵢ/T，允许有放回重复。不要求来源坐标独立，也不要求sᵢ≤nr。零q可省去；高T保证T,U正。

令θ=T/c，L=log[U/(c(2r)ⁿ)]，A=ne^(L/n)。原cumulative-volume论证给L≥θ−1。用粗范围1≤c≤2、1<c₀≤2即可得

θ≥2048√n≥32768， k≥2θ>1， L>0。

已审(A)–(C)内部只需θ≥2、k≥2θ、L≥θ−1等条件，故并未暗含旧8192√n阈值。特别L_λ=L+log(2/θ)+t≥θ−1+log(2/θ)>0，cut仍在r上方；L_λ≤L+t；K=log(2L/θ)≥0。低层tail仍可积分，不存在被截断的t>n区间。

本次复核不把有限近尺度空域说明当一般局部定理假设，也不把其旧低维范围扩展成新结论。n≥256在本命题中保留。

## 2. large-L分支覆盖边界

若

L≥θ−1+nlog(4c₀n/θ)，

则(A)中的n·c₀exp[−(L+1−θ)/n]≤θ/4，故

M≤(3/c)Ue^(1−3θ/4)≤Ue^(−θ/2)。

最后的prefactor只需1+log(3/c)≤θ/4；θ≥32768有巨大余量。该分支包括等号。它已强于最终目标，因为T/8=cθ/8≤θ/4且100n/k≥0。

若此分支不成立，L≥θ−1迫使log(4c₀n/θ)>0。写v=θ/n、x=L/n，则

0<v<4c₀≤8， 0<x≤v+log(8/v)， v²n≥2048²。

所以没有遗漏v≥8的互补域；在那些参数处large-L分支自动适用。2x/v=2L/θ>1，后面的log非负。

## 3. complementary分支：small x

记(C)指数的两项为

S=2sqrt[2eAlog(2L/θ)]， R=8eA/k。

对0<x≤1，A≤en。令y=L/θ≥1−1/θ>1/2，已用的elementary maximum max_{y≥1/2}log(2y)/y²=2/e给

S/L≤4sqrt(e)√n/θ≤4sqrt(e)/2048<1/4。

这里保留R≤8e²n/k为additive cost，不必也不应假称它在本分支都相对L很小。因此

−L+S+R≤−3L/4+8e²n/k≤−θ/2+1+8e²n/k。

x=1包含在该范围；它也允许归入下一分支，重合不构成遗漏。

## 4. large x的两项比例与独立exact常数

对x≥1，由e^x≤8e^v/v、v<8可得

v e^x/x≤8e⁸。

再用对所有v>0成立的vlog(2x/v)≤2x/e，得到

v²e^x log(2x/v)/x²≤16e⁷。

故

(S/L)²≤128e⁸/(v²n)≤128e⁸/2048²<1/9，

R/L≤32e⁹/(v²n)≤32e⁹/2048²<1/8。

首行是**平方比例**；取根后为S/L<1/3，不能直接将1/9和1/8当作原两项之和。正确为

S/L+R/L<1/3+1/8=11/24<1/2。

因此−L+S+R≤−13L/24≤−L/2≤−θ/2+1/2，与small-x分支统一给(C)首项≤2eUexp(−θ/2+8e²n/k)。

旧splice只使用e<3的声明在这两个新的specific rational comparisons处不足。本独立核对使用完全初等的更精确e<11/4：将exp series分到j=3，剩余自j=4起用比值≤1/5的几何级数，得e<8/3+5/96=87/32<11/4。于是无需interval计算即可严格认证：

128(11/4)⁸/2048²=214358881/2147483648<1/9，

32(11/4)⁹/2048²=2357947691/34359738368<1/8。

这两个rational上界已实际用Fraction核对；作者另外使用Arb认证真实e，二者相容。

## 5. 全低层tail及final absorption

(C)tail为D=[k/(k−1)](1+c₀)ⁿ(U/T)e^(−(k−1)n)。T≥2、k≥2、1+c₀≤3给

D/U≤exp([log3−(k−1)]n)。

k≥2θ且θ≥32768>1+log3，所以D≤Ue^(−θn)≤Ue^(−θ/2)。没有遗漏t>n或large-k参数。合并得到

M≤(2e+1)U exp(−θ/2+8e²n/k)。

log(2e+1)≤θ/4在θ≥32768下显然有余量，例如e<3给2e+1<7，而e^(θ/4)≥1+θ/4≥8193。又8e²≤8(11/4)²=121/2<100，且θ/4=T/(4c)≥T/8。因此

M≤Uexp(8e²n/k−θ/4)
 ≤Uexp(100n/k−T/8)。

所有T等于新门槛、arbitrary integer k≥2T/c、large-L等号、x=1、所有positive L、small/large v均已覆盖。没有用k的上界，也没有改变q/T抽样。

## 6. 本机实际独立Fraction检查

运行已有 `/Users/zzh/.local/share/math-research-tools/venv/bin/python`，只使用Fraction，未跑grid。实际输出：

- r1 upper =214358881/2147483648；1/9−r1=218253719/19327352832>0。
- r2 upper =2357947691/34359738368；1/8−r2=1937019605/34359738368>0。
- sqrt-ratio plus second-ratio upper=11/24；1/2−11/24=1/24。
- elementary e upper=87/32<11/4；8(11/4)²=121/2<100。

所有exact assertions通过。程序的关键输入为e上界11/4、denominator2048²、comparators1/9与1/8；通用全域证明是第1–5节，不来自有限点或有限族。

## 7. 作者稿第二阶段定点审查与哈希

独立完成上述命题审查后实际读取S2_THRESHOLD.md，SHA-256：

`9b8616e41e48046d31e3b05bb9d46bb40c621d2644855e8d260428a8bb10697b`。

作者§1正确重查(A)–(C)前提；§2包括large-L等号；§3a保留n/k additive term；§3b正确把squared ratio<1/9转为<1/3，并以11/24求和；§4tail和prefactor吸收完整。作者用7个256-bit Arb outward certificates代替本独立rational e上界，所录公式、比较方向、precision与作用范围准确。未发现必须修改点，最终local bridge PASS。

作者完整记录常数证书的代码、实际解释器/Arb版本和输出，并把它们限定为七个scalar inequalities的证书。父代理另报告SPLICE_CHECK.py的192个256-bit点；本代理未重复该grid，其有限结果不替代第1–5节全域证明，也不认证任意真实source family或cluster cover。

## 8. 可继承范围与明确未付项

τ=16384√n下，新阈值正好是τ/4。因此满足所有同一真实Fi/commonpoint/scale条件且T_core≥τ/4的core可用此局部定理；对完整core交集的deterministic corollary仍可对固定W的upper bounds取inf，得W≤U_core e^(−T_core/8)，从而在该load下≤U_core e^(−τ/32)。这不需要改变原Poisson sampling或actual keys。

本文件没有构造threshold-qualified覆盖，没有控制不同cores的weighted source-column费用，也没有将所有删减后的cores自动认作达到τ/4。local threshold bridge本身不等于全局AU、strict gain或一般sqrt(n)定理。

所有本次授权的独立statement与作者稿审查完成。只写本S1文件；无spawn/Git/PDF/MATLAB，无重复grid。交付后停止，待主代理另行给出后续具体候选。

## 9. 追加独审：upper-rim rows的真正全族付款

父代理追加了明确statement，要求先独立核对，未构造其余cover。以下使用n≥256；小维near为空的继承范围不变。定义

Rₕ^up=Σ_{i∈Iₕ:sᵢ≥(n/2)sₕ}qᵢ，
H_up={h:Rₕ^up≥τ/8}， V_up=Σ_{h∈H_up}|Xₕ|。

对h∈H_up，按该rim中的qᵢ/Rₕ^up分配|Xₕ|（其他source取0）。每target恰好全付，分母正，不使用qₕ。对incident source i，sₕ≤2sᵢ/n；actual witness保证Xₕ⊂Aᵢ+c₀sₕQ，所以

Xₕ⊂Q(yᵢ,(1+2c₀/n)sᵢ)。

全体原Xₕ真实不交，故对固定i，所有此类receivers在所有尺度上的union体积最多(1+2c₀/n)ⁿdᵢ。source总transfer因而≤(8/τ)qᵢ(1+2c₀/n)ⁿdᵢ。求i得到严格全族已付界

V_up≤(8/τ)(1+2c₀/n)ⁿU≤(8/τ)e^(2c₀)U。

这条不需要对target buckets求和，不能再乘其数量；没有将|Xₕ|替换为|Fₕ|，也没有conditional density帽。对n≥256，self h不可能满足sₕ≥(n/2)sₕ，因此原Iₕ允许positive self不影响rim计算。

这是本轮一个真正的新deterministic partial payment。它只支付H_up；低rim部分尚未付。可用c₀≤33/32将8e^(2c₀)统一上放为8e^(33/16)，无需优化。若与原far fee一起记账，只加一次该全族V_up费用，不把它按subbucket复制。

## 10. 最新n个equal-log子桶：精确删减及固定ground

父代理最初给出γ/m参数版本；该版本的负载界也合法，但最新正式构造可更简单：每个dyadic target bucket [R,2R)恰分n个equal-log subbuckets [α,β)，满足

β/α=2^(1/n)≤2。

只处理remaining rows Rₕ^up<τ/8，且sₕ∈[α,β)。

### 10.1 small-source负载≤2c

对i∈Iₕ且sᵢ<β，共点zₕ∈Aᵢ及Fi⊂Bi给Fi⊂Q(zₕ,c₀β)。这些真实Fi不交，且dᵢ≥(2sₕ)ⁿ≥(2α)ⁿ，因此

Σ_{i∈Iₕ:sᵢ<β}qᵢ
≤(2α)^(−n)Σ_{small}|Fi|
≤c(β/α)ⁿ=2c≤64/31<τ/16。

只用genuine source capacity；没有假设任意输入f或auxiliary jitter有密度帽。最后的不等式对n≥256有充分余量。

### 10.2 upper-source删减确为已分出的rim

若i∈Iₕ且sᵢ≥nα，则因sₕ<β≤2α，有sᵢ>(n/2)sₕ，故属于Rₕ^up。remaining row中此负载严格<τ/8。端点sᵢ=nα包含于被删upper部分；sᵢ=β不属于small部分而保留。由于n≥256，β<nα，两个被删source ranges不重叠。

定义辅助core

Jₕ=Iₕ∩{β≤sᵢ<nα}。

原Tₕ>τ/2，故

T(Jₕ)>τ/2−τ/16−τ/8=5τ/16>τ/4。

可保留更强表达T(Jₕ)>3τ/8−2c，但不必使用。本次删减给了实际统一margin，不是R669中无依据地忽略a^(−n)。

### 10.3 fixed ground与prefix消除完全合法

令G_{α,β}={i:qᵢ>0,β≤sᵢ<nα}。它只依subbucket及实际原来源，不依target h。对i∈G，sᵢ≥β>sₕ，radius order自动保证i<h；同时sᵢ<nα≤nsₕ。因此原near-pool定义精确给

Jₕ={i∈G_{α,β}:zₕ∈Aᵢ}。

没有残留随h变化的时间prefix或near-window endpoint条件。原Iₕ、q、Poisson rates、actual first-k keys全部未改；这是额外deterministic covering subset，不能拿它替代原随机key的定义。self被辅助small-source cutoff排除是合法显式选择，不是再次声称原Iₕ无self。

同一subbucket内，所有auxiliary source半径≥β。对任一共同core J_C⊂G，actual receiver union满足⋃Xₕ⊂K_{J_C}+c₀βQ，common witness可取任一参与target的zₕ。因此若T(J_C)≥τ/4，新local threshold theorem合法给cover fee≤e^(−τ/32)U_{J_C}。单个Jₕ有>5τ/16，但任意intersection core仍须另查τ/4；没有automatic cluster-cover声明。

## 11. 新subbucket的条件column费用：常数PASS但cover未构造

一个source参与actual near targets的dyadic bucket数仍≤Lₙ=ceil(log₂n)+2。每bucket恰n个subbuckets，所以全族至多nLₙ≤3n²个subbuckets；某source出现在一个cluster core时必是该subbucket某actual target的来源，因此可以使用这个计数。G中无incident demand的多余来源不会凭空被计作已付receiver。

条件前提：每个subbucket有其真实remaining receivers的fractional cover，所有common cores满足T≥τ/4、真实共点/Fi/scale条件，且每source在该subbucket的总fractional column weight≤e^(τ/64)。此时nonnegative source求和给

V_low≤nLₙ e^(τ/64)e^(−τ/32)U
      ≤3n²e^(−τ/64)U。

τ/64=256√n；e^x≥x⁴/24严格导出

3n²e^(−256√n)≤72/256⁴。

没有额外无限尺度数费用。总near budget在上述未证cover/column前提下才为

Vnear=V_up+V_low
≤[(8/τ)e^(2c₀)+72/256⁴]U。

scalar很小不构成空间cover证书，不能据此宣布AU已经证明。真正已无条件支付的是第9节V_up。remaining fixed-ground receivers的fractional arrangement cover及列预算仍OPEN。

## 12. 新statement与当前主账对照状态

已读取MAIN_FIXED_RANGE.md的初版γ/m参数账。其m=ceil[nlog2/log(τ/(16c))]与small-load≤τ/16也是合法条件构造，但父代理已选择更简单的正式n-subdivision；上面第10–11节只按最新版本签署，不要求保留不必要γ优化。

本追加审查未跑range grid、未改变作者文件、未生成新local机制。待作者正式稿/最终主报告形成后，只核对本次已签的rim全族费用、n子桶边界、fixed-ground等式、threshold-qualified core和未构造column范围及哈希。

## 13. 最终新增空间结构：g_G低载和合法cover已经构造

实际读取主REPORT完整正文及A1最终稿后，补充如下独立审核，全部PASS。

固定subbucket的G满足每个source半径≥β>sₕ，所以严格i<h来自这次明确的auxiliary scale选择，不是重新误读原Iₕ。若x∈Bₕ∩Aᵢ，则||yₕ−yᵢ||∞≤sᵢ+sₕ/a≤c₀sᵢ。原source-center admission因而给

g_G(zₕ)=q(Jₕ)>5τ/16， g_G(x)≤1 对每个x∈Bₕ。

低载在整个Bh成立，不仅在Xh a.e.；这保留actual spatial geometry，没有将高低载点替换成任意incidence数据。

最终稿还给了实际合法cover，不再仅是假设cover存在：在固定finite {Ai:i∈G}的stratified coordinate-face arrangement中，取含actual witnesses的occupied strata，按witness stratum分组。每stratum上membership set恒定，故组内所有Jh相同，初始full common load>5τ/16。包含lower-dimensional strata的做法对boundary witness亦合法；原generic witness合同本来已足够，但此加强不改变费用。

对任意组C，其full core精确为所有包含witness coordinate-box hull的G-sources，因为axis-parallel Ai包含一组点当且仅当包含其box hull。每actual witness在K_C中，真实receivers满足Y_C⊂K_C+c₀r_CQ。固定ground保证source半径≥β>r_C，且< nα≤n r_C，因此new local theorem的scale/commonpoint/Fi条件全部保留。

从初始occupied-cell partition出发，仅当两个current groups的**完整累计**common-core intersection有load≥τ/4才合并。每次减少finite group数，确定性tie-break即可有限终止；coverage、actual target partition及qualified core条件全过程保持。不是把每对target相似性升级成多target完整交集，也未声明最终不能再merge就有列预算。

因此本文件第8节和早期第11–12节“cover未构造”的阶段描述由本节更新：**合法有限integral cover已经构造；未构造/未证明的是可付款的source-column bound或具有所需column成本的更好fractional cover。** 原完整目标仍开放。

## 14. 最终A1/主报告定点比对及哈希

最终实际读取A1_WITHIN_BUCKET.md SHA-256：

`46a51263e19c4dd920ba90f484ec0c8d2c0139db1b605186eb11c4fa82da9784`。

最终实际读取REPORT.tex SHA-256：

`0850eaa2090a100f4f7f13240c08e40857470f3830a258d91f368e71d35ab298`。

S2_THRESHOLD.md最终实读SHA-256保持第7节：

`9b8616e41e48046d31e3b05bb9d46bb40c621d2644855e8d260428a8bb10697b`。

A1 §1的rim全族支付、§2的exact n subdivisions/2c删减、§3的fixed-ground与whole-Bh低载、§4的occupied-stratum/full-core merge以及§5的exact source debit，与第9–13节独立证明一致。A1已统一为**每fixed subinterval**的Mₙ≤e^(τ/64)条件口径；不是合并整个原dyadic桶后的同一budget。它与主报告的nLₙ≤3n²以及72/256⁴ scalar比较完全一致。

主报告的完整unconditional账为

V₀≤C_adm[U+(K_far+K_up(n))U/τ+V_rem]，

K_up(n)=8(1+2c₀/n)ⁿ≤8e^(33/16)。

这里actual Vnear被真实partition成Vup+Vrem；rim已经一次全族支付，不能再乘bucket数，也没有额外marked/repeat或completion费被重复加入。若以后统一证明Vrem≤AU，则原P₀≥U/τ与all-input finite recovery会完成条件回代；当前稿没有宣称该未付前提已经成立。

报告严格区分：local threshold改进已经证明；upper-rim branch已经付款；fixed arrangement合法有限cover已经构造；它的weighted source-column仍无有效统一预算。plain cover或merge终止本身不支付该列和，且任意fractional cover必须实际覆盖原remaining receiver，不能只任取非负λ。

数值scope准确：作者7项256-bit Arb只认证scalar constants；192个有限interval参数比较不代替全域splice，skipped地点不当作pass；6个range参数检查不实例化高维subbuckets，也不构造空间cover。本代理没有重复这些有限jobs。第6节独立Fraction证书与全域解析证明各自范围已明确。

**最终审查PASS，无剩余必须修改项。** 所有本次授权statement、作者稿与主报告整合已完成，并绑定上述实际所读版本。新local桥及rim付款均不等于一般AU；payable column estimate仍OPEN。只写/追加本S1文件，无spawn/Git/PDF/MATLAB，无重复grid，交付停止。
