from fractions import Fraction as F
from itertools import product
import json,hashlib
from pathlib import Path
# Exact physical cube cells. Linear perturbation has the same initial tangent as matched exponential growth.
rows=[]
for n in [1,2,3]:
 points=[(F(0),)*n,(F(3,4),)+(F(0),)*(n-1)]
 weights=[F(1),F(2**n-1)]
 scales=[F(1),F(2),F(4)]
 cuts=[sorted({y[k]+s*L/2 for y in points for L in scales for s in [-1,1]}) for k in range(n)]
 counts={'cells':0,'checks':0,'tied_cases':0,'strict_fixed_winner_defects':0,'platform_checks':0}
 witness=None
 for index in product(*(range(len(c)-1) for c in cuts)):
  x=tuple((cuts[k][j]+cuts[k][j+1])/2 for k,j in enumerate(index))
  volume=F(1)
  for k,j in enumerate(index):volume*=cuts[k][j+1]-cuts[k][j]
  vals=[[w/L**n if all(abs(x[k]-y[k])<L/2 for k in range(n)) else F(0) for y,w in zip(points,weights)] for L in scales]
  responses=[sum(v,F(0)) for v in vals];m=max(responses)
  counts['cells']+=1
  if not m:continue
  active=[j for j,v in enumerate(responses) if v==m]
  for rates in [(F(0),F(1)),(F(1),F(0)),(F(1),F(1)),(F(1,3),F(2,3))]:
   slopes=[sum((a*v for a,v in zip(rates,vs)),F(0)) for vs in vals]
   d=max(slopes[j] for j in active);frozen=slopes[active[0]]
   eps=F(1,64)
   for v,b in zip(responses,slopes):
    if v<m and b>d:eps=min(eps,(m-v)/(2*(b-d)))
   new=max(v+eps*b for v,b in zip(responses,slopes))
   assert new==m+eps*d
   counts['checks']+=1
   if len(active)>1:counts['tied_cases']+=1
   if d>frozen:
    counts['strict_fixed_winner_defects']+=1
    if witness is None:witness={'x':list(map(str,x)),'volume':str(volume),'rates':list(map(str,rates)),'responses':list(map(str,responses)),'slopes':list(map(str,slopes)),'right_max_slope':str(d),'frozen_slope':str(frozen)}
   # At tau=m, log_+ right derivative is d; strict-superlevel frozen expression is zero.
   z=eps*d/m
   # m*log(1+z)/eps lies in this exact rational interval and tends to d.
   lower=m*z/(1+z)/eps; upper=m*z/eps
   assert lower<=d==upper
   z2=z/2; lower2=m*z2/(1+z2)/(eps/2)
   assert lower<=lower2<=d
   counts['platform_checks']+=1
 assert counts['strict_fixed_winner_defects']>0
 rows.append({'n':n,'source':{'points':[list(map(str,y)) for y in points],'weights':list(map(str,weights)),'full_side_lengths':list(map(str,scales))},'counts':counts,'witness':witness})
print(json.dumps({'status':'PASS','scope':'Exact finite-scale full-cell directional max checks, no continuous-scale or asymptotic certification','rounds':rows},indent=2))
