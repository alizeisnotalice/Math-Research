from fractions import Fraction as F
from itertools import product
import json
rows=[]
for n,N in [(1,3),(2,5),(4,9)]:
 pts=[tuple(F(((j+1)*(2*k+3))%11-5,4) for k in range(n)) for j in range(N)]
 assert len(set(pts))==N
 weights=[F((j*j+3*j+1)%7+1,7) for j in range(N)]
 def maximum(x,deleted=None):
  dist=[2*max(abs(u-v) for u,v in zip(x,y)) for y in pts]
  cand=sorted({F(1),F(4)}|{r for r in dist if 1<=r<=4})
  vals=[sum((w for j,(w,r) in enumerate(zip(weights,dist)) if j!=deleted and r<=L),F(0))/L**n for L in cand]
  H=max(vals);idx=vals.index(H)
  return H,cand[idx],dist
 count=0;gap_count=0;max_gap=F(0);diffuse=0
 for x in product([F(-3,2),F(-3,4),F(0),F(3,4),F(3,2)],repeat=n):
  H,L,dist=maximum(x)
  if H==0:continue
  S=[j for j,r in enumerate(dist) if r<=L];m=sum((weights[j] for j in S),F(0))
  pi=[weights[j]/m if j in S else F(0) for j in range(N)]
  delta=[];beta=[]
  for j in range(N):
   minus,_,_=maximum(x,j);d=1-minus/H
   rminus=max([F(1)]+[dist[k] for k in S if k!=j])
   b=1-(1-pi[j])*(L/rminus)**n if j in S else F(0)
   assert 0<=d<=b<=pi[j]
   delta.append(d);beta.append(b);count+=1
  assert sum(beta)<=1
  gap=1-sum(beta);gap_count+=gap>0;max_gap=max(max_gap,gap)
  assert sum(b*b for b in beta)<=max(pi)*sum(beta)<=max(pi)
  for lam in [F(1,8),F(1,2),F(7,8)]:
   clipped=[min(b,1-lam) for b in beta]
   assert all(1-b>=lam for b in clipped)
   assert sum(b*b/(2*(1-b)) for b in clipped)<=sum(b*b for b in beta)/(2*lam)
  diffuse+=max(pi)<=F(1,2)
 rows.append({'n':n,'N':N,'points':[list(map(str,y)) for y in pts],'weights':list(map(str,weights)),'receiver_grid':[-1.5,-.75,0,.75,1.5],'atomic_deletion_comparisons':count,'positive_shrink_gap_points':gap_count,'maximum_gap':str(max_gap),'diffuse_points_at_epsilon_half':diffuse})
print(json.dumps({'status':'PASS','scope':'Exact rational continuous-scale winner and deletion at deterministic receiver points; no spatial quadrature or asymptotic fit','rounds':rows},indent=2))
