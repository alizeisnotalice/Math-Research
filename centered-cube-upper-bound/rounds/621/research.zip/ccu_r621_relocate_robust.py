import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,platform,resource,shlex,sys,time,warnings
from pathlib import Path
from fractions import Fraction as F
import numpy as np,scipy
from scipy.sparse import coo_matrix
from scipy.optimize import milp,Bounds,LinearConstraint
H=F(999999,1000000)

def solve(payload):
 g,r,fixed,cert=payload;t=time.monotonic();cpu=time.process_time();n=len(g['d']);C=len(g['patterns']);G=fixed['maximal_clique_masks'];masks=[p['mask'] for p in g['patterns']];z=[F(q,r['rounded_source_denominator']) for q in r['source_numerators']];M=sum(z,F()); znum=r['source_numerators'];den=r['rounded_source_denominator'];marg=[sum(z[i] for i,m in enumerate(masks) if m&(1<<j)) for j in range(n)];assert F(*map(int,cert['h_certified']))>=H
 # Independently validate certificate source allocations and embed per-cell residue in residual group.
 allocden=cert['allocation_denominator'];used=[F() for _ in range(C)];covered={(j,k):F() for j,k in cert['owners']}
 for i,k,v in cert['source_allocations']:
  mass=F(int(v),allocden);assert mass>=0;used[i]+=mass
  for j,h in covered:
   if h==k and masks[i]&(1<<j):covered[(j,h)]+=mass
 residual=[z[i]-used[i] for i in range(C)];assert min(residual)>=0
 assert len(set(j for j,k in covered))==len(covered)
 slacks=[]
 for (j,k),v in covered.items():assert G[k]&(1<<j);delta=v-H*g['d'][j];assert delta>=0;slacks.append(delta)
 baseline=sum((F(g['v'][j]) for j,k in covered),F());assert baseline==F(*map(int,cert['retained']))
 # Per-star total capture and global total are exactly the original z because residual is allocated in its original cell.
 assert sum(used,F())+sum(residual,F())==M
 for j in range(n):assert sum((used[i]+residual[i] for i,m in enumerate(masks) if m&(1<<j)),F())==marg[j]
 owners=[(j,k) for k,cl in enumerate(G) for j in range(n) if cl&(1<<j)];omap={o:i for i,o in enumerate(owners)};xs=[(i,-1) for i in range(C)]+[(i,k) for i,m in enumerate(masks) for k,cl in enumerate(G) if m&cl];nx=len(xs);ny=len(owners);rows=[];cols=[];vals=[]
 for col,(i,k) in enumerate(xs):
  rows.append(0);cols.append(col);vals.append(1.);active=masks[i]
  while active:
   bit=active&-active;j=bit.bit_length()-1;rows.append(1+j);cols.append(col);vals.append(1.);active^=bit
  if k>=0:
   active=masks[i]&G[k]
   while active:
    bit=active&-active;j=bit.bit_length()-1;rows.append(1+2*n+omap[(j,k)]);cols.append(col);vals.append(-1.);active^=bit
 for y,(j,k) in enumerate(owners):
  rows.extend((1+n+j,1+2*n+y,1+2*n+ny));cols.extend((nx+y,nx+y,nx+y));vals.extend((1.,float(H*g['d'][j]),-float(F(g['v'][j]))))
 A=coo_matrix((vals,(rows,cols)),shape=(2+2*n+ny,nx+ny)).tocsc();eq=np.array([float(M)]+[float(a) for a in marg]);lb=np.r_[eq,np.full(n+ny+1,-np.inf)];ub=np.r_[eq,np.ones(n),np.zeros(ny),-float(baseline)];v=np.array([float(F(s)) for s in g['v']]);c=np.r_[np.zeros(nx),[-v[j] for j,k in owners]]
 with warnings.catch_warnings():
  warnings.filterwarnings('ignore',message='Unrecognized options detected');sol=milp(c,integrality=np.r_[np.zeros(nx,dtype=int),np.ones(ny,dtype=int)],bounds=Bounds(np.zeros(nx+ny),np.r_[np.full(nx,float(M)),np.ones(ny)]),constraints=LinearConstraint(A,lb,ub),options={'time_limit':60,'threads':1,'mip_rel_gap':1e-8})
 out={'seed':g['seed'],'h0':[H.numerator,H.denominator],'baseline_exact':[baseline.numerator,baseline.denominator],'baseline_h_theta_exact':[(H*baseline/F(g['V'])).numerator,(H*baseline/F(g['V'])).denominator],'embedding':{'cell_residual_min':[min(residual).numerator,min(residual).denominator],'source_mass_error':[0,1],'star_capture_errors':[[0,1] for _ in marg],'owner_threshold_residuals':[[j,k,sl.numerator,sl.denominator] for (j,k),sl in zip(covered,slacks)],'certified_h':cert['h_certified'],'cell_residuals':[[z.numerator,z.denominator] for z in residual]},'status_code':int(sol.status),'status_message':str(sol.message),'mip_gap':None if getattr(sol,'mip_gap',None) is None else float(sol.mip_gap),'mip_dual_bound_retained':None if getattr(sol,'mip_dual_bound',None) is None else -float(sol.mip_dual_bound),'elapsed_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
 if sol.x is not None:
  xx=sol.x[:nx];yy=sol.x[nx:];ret=-float(sol.fun);values=A@sol.x;above=max(0.,float(np.max(values-ub)));below=max(0.,float(np.max(lb-values)))
  out.update({'retained_float':ret,'h_theta_float':float(H)*ret/float(F(g['V'])),'h_theta_dual_upper_float':None if out['mip_dual_bound_retained'] is None else float(H)*out['mip_dual_bound_retained']/float(F(g['V'])),'maximum_constraint_violation':max(above,below),'min_variable_value':float(np.min(sol.x)),'owner_j_clique':[list(owners[i]) for i in np.flatnonzero(yy>.5)],'source_cell_group_mass':[[xs[i][0],xs[i][1],format(float(xx[i]),'.17g')] for i in np.flatnonzero(xx>0)]})
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--barrier',type=Path,default=Path('/tmp/ccu_r619_barrier.json'));p.add_argument('--split',type=Path,default=Path('/tmp/ccu_r620_split.json'));p.add_argument('--joint',type=Path,default=Path('/tmp/ccu_r621_joint.json'));p.add_argument('--certificate',type=Path,default=Path('/tmp/ccu_r621_certificate.json'));p.add_argument('--output-dir',type=Path,default=Path('/tmp'));p.add_argument('--workers',type=int,default=2);a=p.parse_args();assert 1<=a.workers<=2;a.output_dir.mkdir(parents=True,exist_ok=True)
 b=json.loads(a.barrier.read_text());s=json.loads(a.split.read_text());j=json.loads(a.joint.read_text());c=json.loads(a.certificate.read_text());geos={x['seed']:x for x in b['geometries']};src={x['seed']:x for x in s['results'] if x['alpha']==.1};fixed={x['seed']:x for x in j['results'] if x['alpha']==.1 and x['h_exact']==[1,1]};cert={x['seed']:x for x in c['results'] if x['seed'] in (61902,61903) and x['h_requested']==['1','1']};out={'input_sha256':{str(z):hashlib.sha256(z.read_bytes()).hexdigest() for z in (a.barrier,a.split,a.joint,a.certificate)},'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'workers':a.workers,'results':[]};start=time.monotonic();path=a.output_dir/'ccu_r621_relocate_robust.json';md=a.output_dir/'ccu_r621_relocate_robust.md'
 def save():
  out['wall_seconds']=time.monotonic()-start;path.write_text(json.dumps(out));lines=['# R621 same-marginal relocation at a certified common threshold','','The fixed-source baseline is embedded exactly with h0=999999/1000000: residual source stays in its original cell, source-cell budgets, total M, all star captures and owner threshold slacks were verified using Fraction before solving. The model additionally imposes retention at least that certified baseline. The MILP numerical status and bound remain floating-point estimates.','','| seed | exact baseline | solver status | solver retained | h0 θ | solver gap | max float violation |','|---:|---:|---:|---:|---:|---:|---:|']
  for r in out['results']:
   lines.append('| %d | %s/%s | %d | %s | %s | %s | %s |'%(r['seed'],*r['baseline_exact'],r['status_code'],str(r.get('retained_float')),str(r.get('h_theta_float')),str(r['mip_gap']),str(r.get('maximum_constraint_violation'))))
  lines+=['','The earlier h=1 numerical anomaly had no exact nominal-h baseline for these cases: it undermined confidence in those results but did not prove a mathematical contradiction. No repeated parameter tuning or general-dimensional conclusion is made.'];md.write_text('\n'.join(lines)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  for f in concurrent.futures.as_completed([pool.submit(solve,(geos[k],src[k],fixed[k],cert[k])) for k in (61902,61903)]):
   r=f.result();out['results'].append(r);save();print('done',r['seed'],r['status_code'],r.get('retained_float'),r['status_message'],flush=True)
 save()
if __name__=='__main__':main()
