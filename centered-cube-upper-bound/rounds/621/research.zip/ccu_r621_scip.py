import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import sys
INSTALL=os.environ.get('CCU_SCIP_PACKAGE_PATH','/Users/zhengzhihao/.local/share/math-research-tools/solvers/scip-6.3.0')
sys.path.insert(0,INSTALL)
import argparse,concurrent.futures,hashlib,importlib.util,json,math,platform,resource,shlex,time
from pathlib import Path
from fractions import Fraction as F
from types import SimpleNamespace
import numpy as np,scipy,pyscipopt
from pyscipopt import Model,quicksum

def task(payload):
 g,s,j,ce,model_path=payload;t=time.monotonic();cpu=time.process_time();wire={}
 spec=importlib.util.spec_from_file_location('r621_robust_local',model_path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 def intercept(c,**kw):wire.update(kw);wire['objective']=c;return SimpleNamespace(status=4,message='matrix intercepted; SCIP used',x=None)
 mod.milp=intercept;mod.solve((g,s,j,ce));cons=wire['constraints'];A=cons.A.tocsr();lower=cons.lb;upper=cons.ub;objective=wire['objective'];bounds=wire['bounds'];integer=wire['integrality']
 masks=[q['mask'] for q in g['patterns']];groups=j['maximal_clique_masks'];n=len(g['d']);C=len(masks);den=ce['allocation_denominator'];z=[F(q,s['rounded_source_denominator']) for q in s['source_numerators']]
 allocations={(i,k):F(int(v),den) for i,k,v in ce['source_allocations']};used=[sum((v for (i,k),v in allocations.items() if i==c),F()) for c in range(C)]
 xs=[(i,-1) for i in range(C)]+[(i,k) for i,m in enumerate(masks) for k,cl in enumerate(groups) if m&cl];ys=[(jj,k) for k,cl in enumerate(groups) for jj in range(n) if cl>>jj&1];owners=set(map(tuple,ce['owners']));point=[z[i]-used[i] if k==-1 else allocations.get((i,k),F()) for i,k in xs]+[F(int(pair in owners)) for pair in ys];assert len(point)==A.shape[1] and all(v>=0 for v in point)
 model=Model('r621_same_marginals');model.hideOutput();model.setRealParam('limits/time',60.);model.setRealParam('limits/memory',380.);model.setIntParam('parallel/maxnthreads',1)
 params=model.getParams()
 if 'lp/threads' in params:model.setIntParam('lp/threads',1)
 vs=[model.addVar(vtype='B' if integer[k] else 'C',lb=float(bounds.lb[k]),ub=None if math.isinf(float(bounds.ub[k])) else float(bounds.ub[k]),obj=float(objective[k])) for k in range(A.shape[1])]
 for row in range(A.shape[0]):
  expr=quicksum(float(A.data[i])*vs[int(A.indices[i])] for i in range(A.indptr[row],A.indptr[row+1]));lo=float(lower[row]);hi=float(upper[row])
  if math.isfinite(lo) and math.isfinite(hi) and lo==hi:model.addCons(expr==lo)
  else:
   if math.isfinite(lo):model.addCons(expr>=lo)
   if math.isfinite(hi):model.addCons(expr<=hi)
 start=model.createSol()
 for k,q in enumerate(point):
  if q:model.setSolVal(start,vs[k],float(q))
 baseline_check=bool(model.checkSol(start,printreason=False,completely=True)); accepted=bool(model.addSol(start))
 model.optimize();status=str(model.getStatus());best=model.getBestSol();dual=float(model.getDualbound());primal=float(model.getPrimalbound());out={'seed':g['seed'],'h0':[999999,1000000],'SCIP_status':status,'baseline_retained_exact':str(F(*map(int,ce['retained']))),'baseline_check':baseline_check,'baseline_start_accepted':accepted,'SCIP_primal_bound_minimization':primal if math.isfinite(primal) else None,'SCIP_dual_bound_minimization':dual if math.isfinite(dual) else None,'SCIP_nodes':int(model.getNNodes()),'source_variables':len(xs),'binary_variables':len(ys),'matrix_rows':A.shape[0],'matrix_nonzeros':A.nnz,'elapsed_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
 if best is not None:
  x=np.array([model.getSolVal(best,v) for v in vs]);activity=A@x;lowererr=max(0.,float(np.max(lower-activity)));uppererr=max(0.,float(np.max(activity-upper)));ret=-float(np.dot(objective,x));V=float(F(g['V']));out.update({'retained_float':ret,'h_theta_float':float(F(999999,1000000))*ret/V,'lower_violation_max':lowererr,'upper_violation_max':uppererr,'bounds_violation_max':float(max(0,np.max(bounds.lb-x),np.max(x-bounds.ub))),'source_cell_group_mass':[[xs[i][0],xs[i][1],format(float(x[i]),'.17g')] for i in range(len(xs)) if x[i]>0],'owner_j_clique':[list(ys[i]) for i in range(len(ys)) if x[len(xs)+i]>.5]})
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--input-dir',type=Path,default=Path(__file__).resolve().parent);ap.add_argument('--output-dir',type=Path,default=Path('/tmp'));ap.add_argument('--workers',type=int,default=2);a=ap.parse_args();assert 1<=a.workers<=2;a.output_dir.mkdir(parents=True,exist_ok=True)
 paths=[a.input_dir/name for name in ('ccu_r621_relocate_robust.py','ccu_r619_barrier.json','ccu_r620_split.json','ccu_r621_joint.json','ccu_r621_certificate.json')];b,s,j,c=[json.loads(p.read_text()) for p in paths[1:]]; geos={g['seed']:g for g in b['geometries']};out={'input_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'pyscipopt':pyscipopt.__version__,'SCIP':'10.0.2','package_path':INSTALL,'documentation':'https://pyscipopt.readthedocs.io/en/stable/install.html','workers':a.workers,'solver_threads':1,'solver_time_limit_seconds':60,'scip_memory_limit_MiB':380,'results':[]};started=time.monotonic();path=a.output_dir/'ccu_r621_scip.json';md=a.output_dir/'ccu_r621_scip.md'
 def save():
  out['elapsed_seconds']=time.monotonic()-started;path.write_text(json.dumps(out));L=['# R621 independent SCIP cross-check','','The exact same SciPy MILP matrix and bounds are intercepted from the robust model. The exact rational fixed-source baseline is passed as a SCIP start. SCIP statuses and candidate allocations are numerical and do not certify optimality.','','| seed | status | baseline accepted | retained | lower violation | upper violation | primal min | dual min |','|---:|:---|:---|---:|---:|---:|---:|---:|']
  for q in out['results']:L.append('| %s | %s | %s | %s | %s | %s | %s | %s |'%(q.get('seed'),q.get('SCIP_status'),q.get('baseline_start_accepted'),q.get('retained_float'),q.get('lower_violation_max'),q.get('upper_violation_max'),q.get('SCIP_primal_bound_minimization'),q.get('SCIP_dual_bound_minimization')))
  L+=['',f"PySCIPOpt {out['pyscipopt']}; SCIP {out['SCIP']}; isolated package `{INSTALL}`. [Official installation documentation]({out['documentation']}).",'','This cross-check concerns only the two supplied finite models, not general solver quality or a dimensional theorem.'];md.write_text('\n'.join(L)+'\n')
 payload=[]
 for seed in (61902,61903):payload.append((geos[seed],next(q for q in s['results'] if q['seed']==seed and q['alpha']==.1),next(q for q in j['results'] if q['seed']==seed and q['alpha']==.1 and q['h_exact']==[1,1]),next(q for q in c['results'] if q['seed']==seed and q['h_requested']==['1','1']),str(paths[0].resolve())))
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  futures={pool.submit(task,p):p[0]['seed'] for p in payload}
  for f in concurrent.futures.as_completed(futures):
   try:r=f.result()
   except Exception as e:r={'seed':futures[f],'SCIP_status':'error','error':repr(e)}
   out['results'].append(r);save();print('done',r['seed'],r['SCIP_status'],r.get('baseline_start_accepted'),r.get('retained_float'),flush=True)
 save()
if __name__=='__main__':main()
