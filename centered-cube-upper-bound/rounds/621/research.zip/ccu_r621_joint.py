import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,platform,resource,shlex,sys,time,warnings
from pathlib import Path
from fractions import Fraction as F
import numpy as np,scipy
from scipy.sparse import coo_matrix
from scipy.optimize import milp,Bounds,LinearConstraint

def cliques(g):
 boxes=[[F(v) for v in x] for x in g['stars']];n=len(boxes); adj=[0]*n
 for i in range(n):
  for j in range(n):
   if i!=j and boxes[i][0]<boxes[j][1] and boxes[j][0]<boxes[i][1] and boxes[i][2]<boxes[j][3] and boxes[j][2]<boxes[i][3]:adj[i]|=1<<j
 out=[]
 def rec(r,p,x):
  if not(p|x):out.append(r);return
  pivot=max((j for j in range(n) if (p|x)&(1<<j)),key=lambda j:(p&adj[j]).bit_count());cand=p&~adj[pivot]
  while cand:
   bit=cand&-cand;j=bit.bit_length()-1;rec(r|bit,p&adj[j],x&adj[j]);p^=bit;x|=bit;cand^=bit
 rec(0,(1<<n)-1,0);out.sort();patterns={p['mask'] for p in g['patterns']}
 for c in out:
  ids=[j for j in range(n) if c&(1<<j)];assert max(boxes[j][0] for j in ids)<min(boxes[j][1] for j in ids) and max(boxes[j][2] for j in ids)<min(boxes[j][3] for j in ids);assert c in patterns
 return out

def build(g,r,threshold):
 start=time.monotonic();n=len(g['d']);G=cliques(g);C=len(g['patterns']);masks=[p['mask'] for p in g['patterns']];owners=[(j,h) for h,k in enumerate(G) for j in range(n) if k&(1<<j)];owner_index={x:i for i,x in enumerate(owners)}
 xs=[(i,h) for i,m in enumerate(masks) for h,k in enumerate(G) if m&k];nx=len(xs);ny=len(owners);rows=[];cols=[];data=[]
 for col,(i,h) in enumerate(xs):
  rows.append(i);cols.append(col);data.append(1.);active=masks[i]&G[h]
  while active:
   bit=active&-active;j=bit.bit_length()-1;rows.append(C+n+owner_index[(j,h)]);cols.append(col);data.append(-1.);active^=bit
 for y,(j,h) in enumerate(owners):
  rows.extend((C+j,C+n+y));cols.extend((nx+y,nx+y));data.extend((1.,float(threshold*g['d'][j])))
 mat=coo_matrix((data,(rows,cols)),shape=(C+n+ny,nx+ny)).tocsc();z=np.array(r['source_numerators'],dtype=float)/r['rounded_source_denominator'];assert len(z)==C
 v=np.array([float(F(q)) for q in g['v']]);obj=np.r_[np.zeros(nx),[-v[j] for j,h in owners]];bounds=Bounds(np.zeros(nx+ny),np.r_[z[[i for i,h in xs]],np.ones(ny)]);ub=np.r_[z,np.ones(n),np.zeros(ny)]
 return G,owners,xs,mat,obj,bounds,ub,time.monotonic()-start

def solve(payload):
 g,r,h=payload;start=time.monotonic();cpu=time.process_time();G,owners,xs,A,obj,bounds,ub,buildtime=build(g,r,h);nx=len(xs);ny=len(owners)
 with warnings.catch_warnings():
  warnings.filterwarnings('ignore',message='Unrecognized options detected');sol=milp(obj,integrality=np.r_[np.zeros(nx,dtype=int),np.ones(ny,dtype=int)],bounds=bounds,constraints=LinearConstraint(A,np.full(len(ub),-np.inf),ub),options={'time_limit':60.,'threads':1,'mip_rel_gap':1e-8})
 out={'seed':g['seed'],'alpha':r['alpha'],'h_exact':[h.numerator,h.denominator],'scaled_demand_exact':[str(h*d) for d in g['d']],'V_exact':g['V'],'status_code':int(sol.status),'status_message':str(sol.message),'maximal_clique_masks':G,'source_variables':nx,'owner_variables':ny,'constraints':len(ub),'matrix_nonzeros':int(A.nnz),'build_seconds':buildtime,'time_limit_seconds':60,'mip_gap':None if getattr(sol,'mip_gap',None) is None else float(sol.mip_gap),'mip_dual_bound_retained':None if getattr(sol,'mip_dual_bound',None) is None else -float(sol.mip_dual_bound),'mip_nodes':None if getattr(sol,'mip_node_count',None) is None else int(sol.mip_node_count),'elapsed_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
 if sol.x is not None:
  xx=sol.x[:nx];yy=sol.x[nx:];chosen=[list(owners[i]) for i in np.flatnonzero(yy>.5)];alloc=[[xs[i][0],xs[i][1],format(float(xx[i]),'.17g')] for i in np.flatnonzero(xx>0)];ret=-float(sol.fun);V=float(F(g['V']));vi=A@sol.x-ub
  out.update({'retained_float':ret,'lost_float':V-ret,'retained_fraction':ret/V,'h_theta':float(h)*ret/V,'h_theta_dual_upper':None if getattr(sol,'mip_dual_bound',None) is None else float(h)*(-float(sol.mip_dual_bound))/V,'owner_j_clique':chosen,'source_cell_clique_mass':alloc,'max_constraint_violation':max(0.,float(np.max(vi))),'min_variable_value':float(np.min(sol.x)),'incumbent_note':'floating solver candidate, not a rational feasibility certificate'})
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--barrier',type=Path,default=Path('/tmp/ccu_r619_barrier.json'));ap.add_argument('--split',type=Path,default=Path('/tmp/ccu_r620_split.json'));ap.add_argument('--output-dir',type=Path,default=Path('/tmp'));ap.add_argument('--phase',choices=('first','geometry','remaining','hscale'),required=True);ap.add_argument('--workers',type=int,default=1);a=ap.parse_args();assert 1<=a.workers<=12;a.output_dir.mkdir(parents=True,exist_ok=True);b=json.loads(a.barrier.read_text());s=json.loads(a.split.read_text());geos={g['seed']:g for g in b['geometries']};path=a.output_dir/'ccu_r621_joint.json';idx=a.output_dir/'ccu_r621_joint_index.json';md=a.output_dir/'ccu_r621_joint.md'
 if a.phase=='first':out={'barrier_sha256':hashlib.sha256(a.barrier.read_bytes()).hexdigest(),'split_sha256':hashlib.sha256(a.split.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'commands':[],'results':[]}; chosen=[r for r in s['results'] if r['seed']==61901 and r['alpha']==.1]
 else:
  out=json.loads(path.read_text());chosen=[r for r in s['results'] if (r['seed']!=61901 and r['alpha']==.1)] if a.phase=='geometry' else [r for r in s['results'] if r['alpha']!=.1]
 if a.phase=='hscale':chosen=[r for r in s['results'] if r['alpha']==.1]
 out['commands'].append(shlex.join([sys.executable]+sys.argv));start=time.monotonic()
 def save():
  path.write_text(json.dumps(out,separators=(',',':')));lines=['# R621 shared-source maximal-clique allocation','', 'Maximal cliques are enumerated from all 40 geometric stars and verified as complete incidence patterns. Every source cell has one shared budget across all cliques. Numerical MILP incumbents, gaps and feasibility residuals are floating estimates, not strict certificates.','','| seed | α | h | status | cliques | retained | lost | hθ | mip gap | max violation | time s |','|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
  for q in sorted(out['results'],key=lambda x:(x['seed'],-x['alpha'])):
   if 'retained_float' in q:lines.append('| %d | %.4g | %d/%d | %d | %d | %.8g | %.8g | %.8g | %s | %.3g | %.3g |'%(q['seed'],q['alpha'],*q['h_exact'],q['status_code'],len(q['maximal_clique_masks']),q['retained_float'],q['lost_float'],q['h_theta'],str(q['mip_gap']),q['max_constraint_violation'],q['elapsed_seconds']))
   else:lines.append(f"\nNo incumbent: {q['seed']} {q['alpha']} {q['status_message']}")
  md.write_text('\n'.join(lines)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  for f in concurrent.futures.as_completed([pool.submit(solve,(geos[r['seed']],r,h)) for r in chosen for h in ((F(1,2),F(1,4)) if a.phase=='hscale' else (F(1),))]):
   r=f.result();out['results'].append(r);save();print('done',r['seed'],r['alpha'],r['status_code'],r.get('lost_float'),flush=True)
 out['last_elapsed_seconds']=time.monotonic()-start;save();idx.write_text(json.dumps({'phase':a.phase,'completed':len(out['results']),'workers':a.workers,'wall_seconds':out['last_elapsed_seconds'],'cpu_sum_seconds':sum(q['cpu_seconds'] for q in out['results']),'max_worker_rss_bytes':max(q['peak_rss_bytes_macos'] for q in out['results']),'commands':out['commands'],'barrier_sha256':out['barrier_sha256'],'split_sha256':out['split_sha256'],'script_sha256':out['script_sha256']},indent=2))
if __name__=='__main__':main()
