# R621 有界资源与来源账目

## Joint h-allocation MILP

- `/tmp/ccu_r621_joint.json` 保存 18 个成功返回的浮点 MILP 结果：**9 个预定 α=0.1 的 h 决策案例**（3 seeds × h=1, 1/2, 1/4），以及**暂停指示到达前已经运行的 9 个额外小 α、h=1 案例**（同 3 seeds × α=0.01, 0.001, 0.0001）。两组分开理解，后者是额外已运行记录。
- 五条命令含 first(1 worker)、geometry(2)、remaining(7)、hscale(6)、修正后 hscale(6)。JSON 有 `last_elapsed_seconds=0.874297s`，仅为末阶段字段，不能当整个批次墙钟；没有全阶段总 wall。18 个保存结果行的 `cpu_seconds` 合计 12.356163 秒、行内 elapsed 合计 12.392062 秒，最大行内峰值 RSS 为 205,012,992 bytes。没有可确认的完整批次 CPU/RSS 采样；尤其不能确认 CPU 汇总是否纳入被丢弃的错误尝试，因此进程级 CPU 总量应记作未知。7 worker 是阶段并发设置，不表示持续七核满载。
- 输入绑定到 R619 barrier/split SHA。记录 Python 3.12.14、NumPy 2.5.4、SciPy 1.18.1。MILP `status_code=0`、HiGHS optimal、MIP gap=0 都是浮点求解状态；报告内约束最大违反有非零项（最高约 `3.06e-7`），故这些数值解不等于严格可行性/最优性证书。
- 有一个变量遮蔽 bug：首轮 hscale 中局部 clique index 遮蔽 threshold，六个尝试被丢弃，修正后才重跑。这些错误模型输出**不计证据**。记录列出执行/版本哈希：初始和主 `6f65d413…90640b05`；有 bug 的 hscale `517b26b9…39a3ebd2`；修正后 hscale `e6f1aff6…ed42f1`。完整值在 JSON。保存的 18 行是有效模型结果；资源统计与被丢弃六次尝试是否有重叠不能从现有文件确定。

## Same-marginal relocation MILP（后续已出现）

- `/tmp/ccu_r621_relocate.json/.md` 保存 3 个 seed、α=0.1 的 relocation 结果；所有 status_code=0，但这是保持总质量与每个原始 star capture 后移动 source 的浮点 MILP。capture 误差有非零项（最大约 `1.56e-7`），MIP gap=0 仍不是严格证书。
- 两阶段记录 first(1 worker)、remaining(2 workers)。`last_elapsed_seconds=2.215809s` 是末阶段，不是全批次 wall。3 行 CPU 合计 17.490899 秒、行 elapsed 合计 17.511281 秒；最大行内峰值 RSS 为 254,803,968 bytes。此处也没有全运行时间或同步多进程 RAM 记录。脚本 SHA `d07254ab…43b5228`；输入 SHA 指向 barrier、split、joint 文件。

## 证据边界与缺项

当前这些新增结果是数值 MILP 诊断；本次收到的 R621 文件中没有与 18 个 h 结果或 3 个 relocation 结果对应的严格有理证书。不能将 float optimal、零 gap 或显示值称为已认证界。暂停前已完成的额外九例可作为已发生的计算记录，但不会扩大其证据等级。

`/tmp/ccu_r621_index.json` 当前未出现。另无全阶段总墙钟、系统平均 CPU/内存、同步 RSS、以及被丢弃六次错误模型尝试的独立 CPU/内存回执。因而无法判断完整活动期间的累计资源；不能把 worker 数上限或单次机器快照解释为持续满载。

## 新增严格证书与交叉检查

- **α=0.1 的9个固定分配证书：** `/tmp/ccu_r621_certificate.md/json` 对9个预定 α=0.1 的 (seed,h-requested) 固定 owner 分配给出有理可行证书。认证门槛是逐例 `h_cert=min(h_requested, min_j cover_j/d_j)`；除 seed 61901、h=1 外，h_cert 均略小于名义 h。因此应记为“9例在各自 h_cert 下已证”，不能称9例都在完整名义 h 下通过。证书校验固定 owner、全部 clique/source masks、共同 source 预算与每个实际 star 覆盖，没有重跑 MILP，也不证明浮点优化器上界或全局最优。脚本 Fraction 运行：墙钟 0.217916 秒、CPU 0.213565 秒、峰值 RSS 29,310,976 bytes；Python 3.12.14，脚本 SHA `46caedf65916f0088815a4da6e4e2513d40cd3abe39419b4f6152dd4b473ac0e`。
- **Root certificate replay：** `/tmp/ccu_r621_root_certificate.json` 重放相同的9例，证书数学字段与前件相同；墙钟 0.214869 秒、CPU 0.210844 秒、峰值 RSS 29,065,216 bytes。记录使用相同脚本 SHA 和相同 joint/split/geometry 输入 SHA，故是同一有理检查器的重放，不能描述为不同算法的独立证明。
- **实际传入 MILP 稀疏矩阵检查：** `/tmp/ccu_r621_matrix_check.json` 对 seed 61902/61903 两个 actual matrix baseline 做逐项有理核验，检查其稀疏矩阵 float 系数的精确二进制有理值及 bounds；两例 lower/upper/bound violation arrays 均为空，`no_solver_executed=true`，耗时 0.44544 秒。这是给定矩阵上 baseline 可行性的严格核验，不是优化性证明。它与此前 HiGHS 对这两例报告的 infeasible 状态相冲突；冲突只限这两份输入/该次模型记录，不能泛化为 HiGHS 一般性问题或模型理论结论。
- **SCIP 交叉求解：** 实际独立包路径 `/Users/zhengzhihao/.local/share/math-research-tools/solvers/scip-6.3.0`，PySCIPOpt 6.3.0 / SCIP 10.0.2；两个模型，2 worker、每个 solver 1 thread、60 秒时限、380 MiB solver memory limit。seed 61902 为 `optimal`（约 7.05 秒）；seed 61903 为 `timelimit`（约 60.25 秒）。总 wall 60.3718 秒，逐案 CPU 合计 67.1983 秒；最大逐 worker RSS 456,605,696 bytes（约435.5 MiB）。这是 solver 的浮点状态和候选分配，两个结果最大 bounds violation 分别约 `3.49e-7`、`7.39e-7`；SCIP 的 optimal 也不构成严格最优/可行性证明。对这两案仅能记录 SCIP 交叉诊断和 time-limit。
- **精确 tensor 身份/子集检查：** `/tmp/ccu_r621_exact.json` 覆盖维数 2、4、6、8，行数 4、16、64、256；对应整数子集检查数 4、16、256、65,536，总计 **65,812**。Python 3.12.14、NumPy 2.5.4、SymPy 1.14.0；墙钟 0.01993 秒、CPU 0.015372 秒、峰值 RSS 96,976,896 bytes。记录范围是有限维 tensor 身份和枚举子集界的精确验证；它本身不是一般 n 的证明来源，通用论证需看 REPORT.tex/AUDIT.md。
