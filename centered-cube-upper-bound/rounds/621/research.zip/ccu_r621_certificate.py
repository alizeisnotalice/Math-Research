import argparse,json,time,sys,hashlib,platform,resource
from pathlib import Path
from fractions import Fraction as Q
start=time.perf_counter();cpu=time.process_time();p=argparse.ArgumentParser();p.add_argument('--joint',type=Path,required=True);p.add_argument('--split',type=Path,required=True);p.add_argument('--geometry',type=Path,required=True);p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args()
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();joint=json.loads(a.joint.read_text());split=json.loads(a.split.read_text());geo=json.loads(a.geometry.read_text());assert joint['barrier_sha256']==split['input_sha256']==hashfile(a.geometry) and joint['split_sha256']==hashfile(a.split)
def rect(v):
 r=tuple(map(Q,v));assert len(r)==4 and r[0]<r[1] and r[2]<r[3];return r
def area(r):return (r[1]-r[0])*(r[3]-r[2])
def inter(r,s):return max(Q(),min(r[1],s[1])-max(r[0],s[0]))*max(Q(),min(r[3],s[3])-max(r[2],s[2]))
def common(rs):return max(r[0] for r in rs)<min(r[1] for r in rs) and max(r[2] for r in rs)<min(r[3] for r in rs)
f=lambda z:[str(z.numerator),str(z.denominator)]
cache={}
for g in geo['geometries']:
 n=g['N'];stars=list(map(rect,g['stars']));vs=list(map(Q,g['v']));ds=list(map(Q,g['d']));assert len(g['records'])==len(stars)==len(vs)==len(ds)==n and all(v>0 for v in vs) and all(area(s)==d for s,d in zip(stars,ds))
 occ=set();small=[];large=[];vv=[]
 for r,x,y,cnt in g['records']:
  assert all(isinstance(z,int) for z in (r,x,y,cnt)) and r>0
  cells={(i,j) for i in range(x-r,x+r) for j in range(y-r,y+r)}-occ;assert len(cells)==cnt and cnt>0;occ.update(cells);vv.append(Q(cnt,16));small.append((Q(x-r,4),Q(x+r,4),Q(y-r,4),Q(y+r,4)));large.append((Q(x-8*r,4),Q(x+8*r,4),Q(y-8*r,4),Q(y+8*r,4)))
 assert stars==large and vv==vs and sum(vs,Q())==Q(len(occ),16)==Q(g['V'])
 cells=[rect(i['cell']) for i in g['patterns']];masks=[int(i['mask']) for i in g['patterns']]
 for c,mask in zip(cells,masks):
  assert 0<=mask<2**n
  for i,s in enumerate(stars):assert inter(s,c)==(area(c) if mask>>i&1 else 0)
 cache[g['seed']]=(n,stars,small,vs,ds,cells,masks)
results=[];cases=[r for r in joint['results'] if Q(str(r['alpha']))==Q(1,10) and Q(*r['h_exact']) in (Q(1),Q(1,2),Q(1,4))];assert len(cases)==9 and len({(r['seed'],tuple(r['h_exact'])) for r in cases})==9
D=2**40
for r in cases:
 st=time.perf_counter();seed=r['seed'];n,stars,small,vs,ds,cells,masks=cache[seed];h=Q(*r['h_exact']);sr=[x for x in split['results'] if x['seed']==seed and Q(str(x['alpha']))==Q(1,10)];assert len(sr)==1;sr=sr[0];z=[Q(k,sr['rounded_source_denominator']) for k in sr['source_numerators']];assert len(z)==len(cells) and all(q>=0 for q in z) and sum(z,Q())==Q(*sr['M_exact'])
 cliques=r['maximal_clique_masks'];G=len(cliques);assert len(set(cliques))==G
 for mask in cliques:
  inds=[j for j in range(n) if mask>>j&1];assert inds and 0<=mask<2**n and common([stars[j] for j in inds])
 owners=r['owner_j_clique'];assert len({j for j,k in owners})==len(owners) and all(0<=j<n and 0<=k<G and (cliques[k]>>j&1) for j,k in owners)
 for k in range(G):
  inds=[j for j,g in owners if g==k]
  if inds:assert common([stars[j] for j in inds])
 allocations={}
 for cell,k,raw in r['source_cell_clique_mass']:
  assert 0<=cell<len(cells) and 0<=k<G and (cell,k) not in allocations
  v=max(Q(),Q(str(raw)));allocations[(cell,k)]=v.numerator*D//v.denominator
 before=dict(allocations);cellgroups={}
 for (i,k),num in allocations.items():cellgroups.setdefault(i,[]).append(k)
 scaled_cells=0
 for i,groups in cellgroups.items():
  total=sum(allocations[(i,k)] for k in groups)
  if Q(total,D)>z[i]:
   scaled_cells+=1
   for k in groups:allocations[(i,k)]=(Q(allocations[(i,k)])*z[i]*D/total).__floor__()
 assert all(Q(sum(allocations[(i,k)] for k in groups),D)<=z[i] for i,groups in cellgroups.items())
 covers=[]
 for j,k in owners:covers.append(sum((Q(num,D) for (i,kg),num in allocations.items() if kg==k and masks[i]>>j&1),Q()))
 hcert=min([h]+[v/ds[j] for (j,k),v in zip(owners,covers)]);assert hcert>=0 and all(v>=hcert*ds[j] for (j,k),v in zip(owners,covers))
 retained=sum((vs[j] for j,k in owners),Q());V=sum(vs,Q());lost=V-retained;theta=retained/V
 results.append({'seed':seed,'h_requested':f(h),'h_certified':f(hcert),'h_loss':f(h-hcert),'theta':f(theta),'h_theta_requested':f(h*theta),'h_theta_certified':f(hcert*theta),'h_theta_gap':f((h-hcert)*theta),'retained':f(retained),'lost':f(lost),'V':f(V),'groups':G,'used_groups':len({k for j,k in owners}),'owners':owners,'source_allocations':[[i,k,str(num)] for (i,k),num in sorted(allocations.items()) if num],'allocation_denominator':D,'owner_cover':list(map(f,covers)),'scaled_cells':scaled_cells,'source_total':f(sum(z,Q())),'elapsed_seconds':time.perf_counter()-st})
print('certified',len(results),'max grid',D)
out={'results':results,'joint_sha256':hashfile(a.joint),'split_sha256':hashfile(a.split),'geometry_sha256':hashfile(a.geometry),'script_sha256':hashfile(Path(__file__)),'runtime':{'python':sys.version,'sys_executable':sys.executable,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'scope':'nine fixed alpha=.1 incumbents, certified reduced h, not MILP optimality'}
a.output.write_text(json.dumps(out,indent=2)+'\n')
