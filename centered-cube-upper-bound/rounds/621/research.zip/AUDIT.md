# R621 全family分源/common-clique整数机制：独立有界预审

日期：2026-10-28。仅独立审父任务给定模型，未读R621作者新稿，未改他人文件、未运行Git、未启动Agent、未扫描实例或反例。实际数学工具仅核验下述fractional恒等式及吸收代数；没有求解器实验。

## 1. 准确模型及结论

冻结全部supplied cubes B_j、stars A_j=aB_j、原正receiver increments I_j、v_j>0，V=Σv_j=|U|，d_j=|A_j|。同一个真实非负L1来源μ满足μ(A_j)≥d_j，总质量M。

令g遍历star交图的全部**inclusion-maximal cliques**，不是仅最大cardinality cliques。有限开轴平行cubes的Helly-2保证每个g有真实共同开交。用完整star incidence切source cells C，z_C=μ(C)。变量为

x_Cg≥0，Σ_gx_Cg≤z_C；
y_jg∈{0,1}，仅j∈g可非零，Σ_gy_jg≤1；
Σ_(C⊂A_j)x_Cg≥d_j y_jg。

最大化R=Σ_jg v_j y_jg。

**结论：** 该整数模型对“每块原I_j保留或丢弃；保留时唯一分给一个共同交star组；各组使用任意可测source submeasures且总和≤μ；每个owned star保持原阈值一”这一类方案是精确的。它不是任意坐标cut/tree或任意fractional receiver分配的精确模型，也没有由形式本身得到统一保留比例。

## 2. Source cell聚合不丢失该类方案

任意真实submeasures μ_g≥0、Σμ_g≤μ给x_Cg=μ_g(C)，各star捕获准确是Σ_(C⊂A_j)x_Cg。反向，若z_C>0，取

μ_g|C=(x_Cg/z_C) μ|C；z_C=0时取0。

这样Σμ_g≤μ，且所有star捕获及总质量都与x一致。无需μ在cell内均匀，也没有density cap。只按**相同完整incidence pattern**聚合不同空间cells亦不影响这些约束。

由于μ为L1、nonatomic，若需要真正互不相交的任意可测source sets，可在每个cell内按给定质量划分成不交部分，得到同样捕获；不必采用比例密度。因此soft submeasure与任意可测硬partition在这里有同样可达数据。若换成带不可分原子的硬partition，则此额外等价不再自动成立。

所有零质量cell由预算强迫x=0；source在stars之外的零incidence部分不帮助阈值，可不分配。边界对L1为零，完整cells必须使用真实开membership，不能将不同incidence误并或只测有限centers。

## 3. 只枚举maximal cliques不丢失整数方案

任意真实组的owned stars S共同相交，因此S包含于某个inclusion-maximal g。将组标为g不会增加阈值要求，因为额外unowned行的y=0。若多个原组映到同一个g，可合并其source submeasures并合并owners；捕获只会增加，总source不变，owned stars仍是g的子集。重复owner原可选定一组，符合whole-I_j唯一归属。

这一等价要求只对**owned**行施加d_j阈值，不能在扩成maximal g后强迫全部j∈g都达标。只枚举maximum-size cliques或截断部分maximal cliques，会缩小方案集；保留下来的整数可行方案仍有效，但其失败或低最优值不能排除未枚举分组。

## 4. 所有receiver/source费用完整

令S_g={j:y_jg=1}、m_g=Σ_Cx_Cg。若S_g非空，其stars共同相交，故

R_g=Σ_(j∈S_g)v_j≤|∪_(j∈S_g)B_j|
   ≤P max_(j∈S_g)d_j≤P m_g，P=(1+1/a)^n。

最后一步用每个owned star的μ_g(A_j)≥d_j。不得将max_owned换成max_(j∈g)，因为maximal扩张中的unowned大star未必由μ_g付款。空组可以置x=0。

各I_j原本不交且owner唯一，所以保留receiver正是R=Σ_gR_g，得到

R≤PΣ_gm_g≤PM。

这里无Ccov，因为v_j来自全supplied union。未保留volume为V−R，不能声称已被retained组覆盖。但若另有统一R≥θ_nV，就可比较体积得到θ_nV≤PM；不必假装未保留点已逐点覆盖。

在精确barrier合同M=Q+εV下，进一步有

(θ_n−Pε)V≤PQ。

若ε预先≤θ_n/(2P)，得到V≤2PQ/θ_n。此处θ_n的存在是实质待证命题；MIP有最优解不提供它。若事后观察θ随ε变化，须对实际θ−Pε核验正性，不能改ε后继续沿用旧来源和旧可行解。P要按a,n保留。

source近似或向上有理化不破坏本模型的来源partition证明，只要μ(A_j)≥d_j及所有预算严格核验；但连接Q+εV时必须另计KKT/总质量误差，不能把近似来源当作精确barrier。

## 5. 重要范围区别及可修复条件

当前x变量允许μ_g分布在很多source cells，只要求每个owned star捕获足够质量。它**不要求μ_g支持在owned stars的共同交中**。若“共同质量归并”本来意指后一条件，当前模型是其放松，不是等价。

可修复为：对每个owned j，禁止μ_g在A_j外分配；有限模型中，M_jC=0时加x_Cg≤z_C(1−y_jg)。不能直接要求source支持在整个maximal g的交中，否则额外unowned stars会误删方案。若需source块为一个坐标cell、连通块或真实cut-tree节点，还要加入对应几何限制；full incidence聚合本身不保存这些限制。

模型精确优化的是原ownership量Σv_j y_jg，不是删行后重新计算的retained cube union最优值。后者可能更大，是另一种覆盖目标。当前结论不需要改动原v_j，也不能悄悄改动。

## 6. Fractional-owner放松总能达到V，并非原阈值成功

将y放松到[0,1]后，完整模型的最优值实际上**恒为V**，条件仅是上述完整source/incidence/maximal-clique合同。

构造：把每个非空incidence source cell C的全部质量，分给包含该cell incidence clique的某个maximal g(C)。得到互不重复的μ_g，且对每个star j有Σ_gμ_g(A_j)=μ(A_j)。只要μ_g(A_j)>0，就有j∈g。置

y_jg=μ_g(A_j)/μ(A_j)。

于是Σ_gy_jg=1，且

μ_g(A_j)=y_jg μ(A_j)≥d_j y_jg。

所有relaxed约束成立，目标Σ_jv_jΣ_gy_jg=V；另一方面row owner预算已给目标≤V，故LP最优恰V。这甚至可用整source-cell分配实现，不依赖在cell内fractional拆源。

但y<1时只保证μ_g(A_j)≥y_jg d_j，正是R620已指出的variable-threshold transfer。它不是μ_g(A_j)≥d_j。不能将整数组付款R_g≤P m_g原样套给fractional y，也不能把“所有行fractional总owner=1”解释为真实whole-I_j方案。

因此该plain LP放松的全通过不包含整数retention信息。若希望从中取得整数方案，必须证明有受控损失的rounding/分组定理，或带全部threshold费用的weighted receiver付款；这仍是新的几何任务，不是LP强对偶的推论。

## 7. 可认证界方向及停止范围

* **整数可行解：** 精确预算、阈值和owner核验后，给整数最优保留量的下界，并真实证明相应R及R≤PM。固定有限实例的成功不推出对全部family统一θ_n。
* **Fractional可行解：** 不是整数最优的下界；这里总可达V，不能据此宣称整数成功。
* **连续放松的dual可行解：** 其最小化值上界LP最优，从而上界整数最优，方向是负面/上界证据。plain relaxation已恒V，row上界给出的trivial dual V准确但不提供有用integrality控制。
* **MIP最优/不可行结论：** 不能只凭浮点solver状态。负面结论还要求所有maximal cliques/真实cells完整，以及可验证的全局上界或完整分支证书。枚举受限模型的dual只约束该受限模型。
* **Strict child badness：** 当前模型是≥d_j。它足以支付几何receiver；若另要求>d_j，在固定source预算内不保证可无费缩放。可改用略低阈值并显式付归一成本，或证明另有source slack。

有限x预算有界、binary owner有限，所以整数最优确实达到；空owner总可行。但这只是存在性，甚至one-star保留仅给N相关的基线，未给根阶所需统一比例。该机制可能比最终弱型目标更强；其有限失败也不等于一般弱型目标失败。

数学venv的SymPy实际核验了fractional满额构造的row/objective恒等式、阈值差代数及θ−Pε吸收式；无solver、实例或反例扫描。当前通过的是精确表示与充分付款机制，尚未证明统一整数retention或可用rounding。有界预审完成，等待作者新增几何，不扩展工作。

## 8. 新增修复：同一个KKT边际面内一次全局择源

父任务新增候选独立核验通过。固定精确barrier解的λ、

a_j=d_j+εv_j/λ_j，M=Q+εV=Σ_jλ_ja_j。

若另选一个原admissible L1类内的非负来源μ′，满足全部μ′(A_j)=a_j及总质量M，则由全空间packing≤1，

∫[1−Σ_jλ_j1_Aj]dμ′=M−Σ_jλ_ja_j=0。

被积函数非负，故μ′-a.e. source packing饱和。其正体积cell masses z′满足stationarity M^Tz′=a和cell complementary slackness，因而确实是**同一个唯一λ**的另一组KKT source乘子。所有保留stars仍有a_j>d_j，原receiver几何、v_j、Q、ε及M均不变。μ′须仍是合法source；按全部正体积cells常密实现已足够，无需引入原子路线。

准确的共同source选择模型是先允许

z′_C≥0，Σ_(C⊂A_j)z′_C=a_j，Σ_Cz′_C=M，

再用Σ_gx_Cg≤z′_C做整族分组。应允许所有真实正体积incidence cells，包括旧来源质量为0而现在可用的cell；精确数据下可等价限制到λ-load=1的cells。若仅在旧正质量cells内移动，会额外限制可选KKT source，不能宣称已穷尽该边际面。

这是对第1节固定z模型的明确扩展，不是声称μ′≤旧μ。选择只可在全family上共同进行一次，随后所有分组仍共享这同一份M。不能为每个group各自重建一个具有总量M的新来源。

第4节付款不变：若一次选定的μ′上有整数方案R≥θV，则θV≤PM；精确barrier下仍按θ−Pε吸收。此桥只保留KKT及允许择源，不保证好的整数方案一定存在。

**数值残差不会被择源修复。** 若固定的是rounded a、M，则更换μ′后M−Σλa和每个a_j−d_j−εv_j/λ_j均原样保留。因此捕获边际/总量的rational可行证书仍可用于真实分源，但不能升级为精确KKT；精确关系必须逐项验证。保持rounded边际只是保持误差，而非消除误差。

## 9. 对固定source障碍的合法修复范围

“对每一个既定合法μ都能保留统一θ”的命题，比“对每个geometry可一次选择合适source后取得付款”的路线更强。即使某个固定source的完整整数模型经严格证明达不到θ，也只排除该fixed-source机制，不排除边际面内全局择源或其他packing/receiver方法。

若声称同几何另一个来源避开障碍，须说明它保持本节的全部a_j及M，或明确另用了哪种允许的新全局优化；仅是另一个满足≥d_j的来源，不自动属于同一KKT边际面。本审未阅读或认证新的tensor/C4障碍证明，不把它当作一般目标反例。

还应允许“已付款或推进”的机制：若该family现有可行Q已足够大、V/Q在目标界内，就无需再强求该family满足同样的group-retention比例。只有在未付regime中证明能择源/分组/递推推进，才是所需几何条件。V/Q很小的特殊family即使揭示fixed-source分组要求过强，也不反驳原全尺度目标。

当前最终已核：整数模型在限定方案类内的精确性、完整R≤PM费用、fractional LP恒满额V及正确对偶方向，以及同KKT边际面内一次全局择源桥。尚未证明统一整数保留率、同边际择源必成功或根阶收费。上述是机制修复与准确量词，不是新一般维数估计。有界审查完成，停止，等待必要作者材料。

## 10. 同一tensor C4的fixed-source指数障碍及修复：核心通过

本节仅审父任务指定的同一tensor C4机制，不扩展其他反例。采用原C4几何的最小centre L∞距离1、star半径3/4；明确取a≥2（例如a=(2m)^2）。这样small receivers半径(3/4)/a，确实两两不交。不能仅以a>√2代替这个几何前提。

m次Cartesian乘积后n=2m、N=4^m，所有star体积d相同，所有receiver增量v=d/a^(2m)相同。每个maximal clique有2^m行；maximal clique/source incidence patterns的数量是4^m。对每个该pattern取source质量

z=d/2^m+εv，λ_j=2^(−m)。

每个star属于2^m个patterns，所以μ(A_j)=2^m z=d+εv/λ_j；source cells的load都为1，且全图最大clique大小2^m保证packing全空间可行。因此这是精确barrier KKT来源，

Q=2^m d，M=4^m z=Q+εV，χ=ε(2/a²)^m，z=d(1+χ)/2^m。

**组合二阶界。** 任取owned clique subset S，延伸到一个maximal product clique T。将T标为{0,1}^m，j,k∈T同时属于的source cliques数为2^(m−dist_H(j,k))。对应kernel是[[2,1],[1,2]]的m重张量，每行和3^m，且非负。因此

Σ_C|S∩C|²=Σ_(j,k∈S)2^(m−dist_H(j,k))≤3^m|S|。

无遗漏cell/行数因子。该公式针对whole owned rows；不能直接套给fractional owner来推整数结论。

**共享source容量与Cauchy。** 对任一组S_g，假设每个owned star在该组来源上满足统一阈值μ_g(A_j)≥h d，h>0。令x_Cg=μ_g(C)、m_g=Σ_Cx_Cg。由于总分源≤原μ，每个x_Cg≤z。故

h d|S_g|≤Σ_Cx_Cg|S_g∩C|，
(h d|S_g|)²≤m_g z Σ_C|S_g∩C|²≤m_g z 3^m|S_g|。

非空组给m_g≥h²d²|S_g|/(z3^m)。再用Σ_gm_g≤M及唯一owner，令θ为保留行/receiver比例，则

θ≤(1+χ)²(3/4)^m/h²，
hθ≤(1+χ)(√3/2)^m。

第二式还使用θ≤1。只在χ受控时才可称该界为指数衰减；式子自身对所有ε保留χ。这个证明允许任意可测subsource分配，不要求source块位于组的共同交，因此确实约束第1节fixed-source整数机制。

**同a_j/M的另一KKT source可以全保留。** 在每个base C4取一对互不相交的edges作为vertex partition；乘积给2^m个互不重叠的maximal cliques，完整partition全部4^m行。只在这些partition cliques的source cell放质量

α=2^m z=d+ε2^m v，

其余source cells置0。每行恰属于其中一个partition clique，故新source的全部捕获仍为α，且总质量2^mα=4^m z=M，λ亦不变。这是第8节合法边际面内的一次全局source选择。将每个partition cell的来源给对应组后，全部owned stars达到原阈值d，θ=1。它不是原fixed μ的submeasure partition，不能将这项修复伪装成旧固定来源上成功。

**为何不是一般目标的障碍。** 同几何已有全空间可行λ且

V/Q=(2/a²)^m。

在本节a≥2的实际参数下该比值指数小，family本来已由Q付款；不必强求它在每一个既定合法source上都有根阶hθ。上述结论只排除过强的“对每个fixed source都uniform保留”的充分引理，不排除同边际择源，也不排除全局packing或原算子目标。下一机制可以采用“已付款，或在未付分支一次择源后推进”的形式。

实际数学venv仅核验该tensor的scalar/KKT归一及base kernel行和，没有solver、几何扫描或新反例。未审核任何正在调查的MILP异常，不将个别status或矩阵差异称为普遍solver bug。核心审查完成，停止扩展。

## 11. 最终groupwise阈值延伸：短核验通过

令k_g=|S_g|、c=(1+χ)(√3/2)^m。固定等质量tensor来源的逐组Cauchy费用给Σ_g h_g²k_g≤Nc²，唯一owner给Σ_gk_g≤N；再用Cauchy，Σ_g h_gk_g≤√[(Σ_g h_g²k_g)(Σ_gk_g)]≤Nc。因该族各v相同，准确结论为T/V≤c，而不是c²。最终REPORT中“亦至多右侧”应按这一显式c界理解，建议直接写出公式以免歧义。

对一般全family，逐组原阈值μ_g(A_j)≥h_gd_j和共同交给h_gV_g≤P||μ_g||，所以完整一次source账为T=Σ_gh_gV_g≤PM。令r=T/V（或取已证T/V下界），在同一精确barrier M=Q+εV下，只有r>Pε时才可推出V≤PQ/(r−Pε)。不能事后换ε却沿用旧μ、旧allocation或旧r；预先统一下界r_n与Pε≤r_n/2才给统一目标常数。

已只核 `/tmp/ccu_r621_final/REPORT.tex` 上述新增statement及其fixed-source适用范围，数学方向正确。未复核本次solver、matrix或数值回执，不对其作评价。原source障碍仍只约束固定来源的整数机制；同边际全局择源、已付款分支及未证一般目标的边界不变。本轮审计完成，停止。
