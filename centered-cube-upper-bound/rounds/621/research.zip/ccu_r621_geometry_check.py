import json, hashlib, time, sys, argparse
from pathlib import Path
from fractions import Fraction as Q
from itertools import combinations
parser=argparse.ArgumentParser(description='Exact rational geometry audit; no optimization is run.')
parser.add_argument('--barrier',type=Path,default=Path('/tmp/ccu_r619_barrier.json'))
parser.add_argument('--split',type=Path,default=Path('/tmp/ccu_r620_split.json'))
parser.add_argument('--joint',type=Path,default=Path('/tmp/ccu_r621_joint.json'))
parser.add_argument('--output',type=Path,default=Path('/tmp/ccu_r621_geometry_check.json'))
args=parser.parse_args()
B,S,J,OUT=args.barrier,args.split,args.joint,args.output
MD=OUT.with_suffix('.md')
if MD==OUT: parser.error('--output must not have a .md extension')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def box(s): return tuple(map(Q,s))
def intersects(a,b): return max(a[0],b[0]) < min(a[1],b[1]) and max(a[2],b[2]) < min(a[3],b[3])
def common(stars, ids):
 return [max(stars[i][0] for i in ids),min(stars[i][1] for i in ids),max(stars[i][2] for i in ids),min(stars[i][3] for i in ids)]
def fmt(q):return str(q)
def solve_cliques(stars):
 n=len(stars); adj=[set() for _ in range(n)]
 for i,j in combinations(range(n),2):
  if intersects(stars[i],stars[j]):adj[i].add(j);adj[j].add(i)
 cliques=[]
 def bk(R,P,X):
  if not P and not X: cliques.append(tuple(sorted(R))); return
  pivot=max(P|X,key=lambda z:len(P&adj[z])) if P|X else None
  for v in sorted(P-(adj[pivot] if pivot is not None else set())):
   bk(R|{v},P&adj[v],X&adj[v]); P.remove(v);X.add(v)
 bk(set(),set(range(n)),set())
 return sorted(cliques),sum(map(len,adj))//2
b=json.loads(B.read_text());s=json.loads(S.read_text()); joint=json.loads(J.read_text())
result={'input_hashes':{str(p):sha(p) for p in [B,S]+([J] if J.exists() else [])},'script_sha256':sha(Path(__file__)),'python':sys.version,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'geometries':[],'joint_input_available':bool(joint),'scope':'exact rational rectangle geometry and input mass accounting; no MILP or incumbent feasibility verified'}
for g in b['geometries']:
 seed=g['seed']; stars=list(map(box,g['stars'])); cells=[box(p['cell']) for p in g['patterns']]; n=len(stars); assert n==40
 cliques,edges=solve_cliques(stars); assert edges==g['graph_edge_count']
 violations=[]
 for k,(cell,pattern) in enumerate(zip(cells,g['patterns'])):
  assert cell[0]<cell[1] and cell[2]<cell[3]
  for i,star in enumerate(stars):
   inside=cell[0]>=star[0] and cell[1]<=star[1] and cell[2]>=star[2] and cell[3]<=star[3]
   separate=not intersects(cell,star); declared=bool(pattern['mask'] & (1<<i))
   if not (inside or separate) or inside!=declared: violations.append([k,i,inside,separate,declared])
 overlap_count=sum(intersects(cells[i],cells[j]) for i,j in combinations(range(len(cells)),2))
 assert not violations and overlap_count==0
 C=[]
 for clique in cliques:
  cb=common(stars,clique); assert cb[0]<cb[1] and cb[2]<cb[3]
  mask=sum(1<<i for i in clique)
  for j in range(n):
   if j not in clique: assert not all(intersects(stars[i],stars[j]) for i in clique)
  C.append({'mask':mask,'indices':list(clique),'common_bounds':list(map(fmt,cb)), 'v_exact':fmt(sum((Q(g['v'][i]) for i in clique),Q(0)))})
 profiles=[]
 for r in s['results']:
  if r['seed']!=seed:continue
  vals=r['source_numerators'];D=r['rounded_source_denominator']; assert len(vals)==len(cells) and all(x>=0 for x in vals)
  total=Q(sum(vals),D);assert total==Q(*r['M_exact'])
  aggregated={}
  for p,v in zip(g['patterns'],vals):aggregated[p['mask']]=aggregated.get(p['mask'],0)+v
  assert sum(aggregated.values())==sum(vals)
  receiver=[sum(v for m,v in aggregated.items() if m & (1<<i)) for i in range(n)]
  direct=[sum(v for p,v in zip(g['patterns'],vals) if p['mask']&(1<<i)) for i in range(n)]
  assert receiver==direct
  profiles.append({'alpha':r['alpha'],'denominator':D,'total_mass':fmt(total),'source_numerators_sum':sum(vals),'incidence_groups':len(aggregated),'conservation_exact':True})
 comparisons=[]
 if joint:
  for jr in joint['results']:
   if jr['seed']==seed:
    ref=jr['maximal_clique_masks'];ours=[x['mask'] for x in C]
    comparisons.append({'alpha':jr['alpha'],'h_exact':jr['h_exact'],'provided_count':len(ref),'duplicate_count':len(ref)-len(set(ref)),'missing_masks':sorted(set(ours)-set(ref)),'extra_masks':sorted(set(ref)-set(ours)),'equal':len(ref)==len(set(ref)) and set(ref)==set(ours)})
 for item in comparisons:
  assert item['equal'], f"joint group mismatch seed={seed} alpha={item['alpha']} h={item['h_exact']}: {item}"
 result['geometries'].append({'seed':seed,'receivers':n,'source_cells':len(cells),'pairs_checked':n*(n-1)//2,'graph_edges':edges,'overlapping_source_cell_pairs':overlap_count,'cell_star_checks':len(cells)*n,'cell_star_violations':violations,'maximal_clique_count':len(C),'maximal_cliques':C,'profiles':profiles,'joint_comparisons':comparisons})
if joint:
 expected=sum(len(x['joint_comparisons']) for x in result['geometries'])
 assert expected==len(joint['results']), 'joint includes a seed absent from barrier geometry'
OUT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_text(json.dumps(result,indent=2,ensure_ascii=False))
with MD.open('w') as f:
 f.write('# R621 独立几何与输入核验\n\n')
 f.write('以 Fraction 精确计算矩形正体积交：每对 receiver 检查两坐标开区间均有正长度；独立采用 Bron–Kerbosch 枚举极大团。每个极大团再独立求坐标公共交，验证各宽度严格为正，并对每个团外 receiver 检验极大性。二维轴平行矩形的区间 Helly 性给出两两正宽交等价于全体正面积交。\n\n')
 f.write('对每个源格与每个 star 检验：格的内部要么完全包含于 star，要么与 star 无正面积交，且与给定 mask 一致；同时核验源格之间没有正面积交。质量是 R620 原有精确分子除以原分母，不乘以几何面积、不修改 μ。按完整 incidence mask 聚合后，精确核对总质量及每个 receiver 的质量。共同交组的实际 v 求和与精确交区间详见 JSON。\n\n')
 f.write('| seed | 星 | 两两重叠边 | 源格 | 格-star 检验 | 极大团 | 与 joint 比较 |\n|---:|---:|---:|---:|---:|---:|---|\n')
 for x in result['geometries']:
  comp=x['joint_comparisons']; status=('; '.join(f"alpha={v['alpha']}, h={v['h_exact'][0]}/{v['h_exact'][1]}: {'一致' if v['equal'] else '不一致'}" for v in comp)) if comp else '该 seed 的 group 尚未提供'
  f.write(f"| {x['seed']} | {x['receivers']} | {x['graph_edges']} | {x['source_cells']} | {x['cell_star_checks']}（0 违例） | {x['maximal_clique_count']} | {status} |\n")
 f.write('\n报告不核验 MILP 可行性、求解最优性或整数认证；joint 文件可能仅含部分 seed，未提供的比较不推断。\n')
print(' '.join(f"{x['seed']}: cliques={x['maximal_clique_count']}, comparisons={x['joint_comparisons']}" for x in result['geometries']))
