import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[key]='1'
import argparse,json,time,platform,hashlib,itertools,resource
from pathlib import Path
from fractions import Fraction as F
import numpy as np
import sympy as sp
p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();start=time.perf_counter();cpu=time.process_time()
centers=[(0,0),(1,1),(2,0),(1,-1)];rad=F(3,4);stars=[(F(x)-rad,F(x)+rad,F(y)-rad,F(y)+rad) for x,y in centers];edges=[(i,(i+1)%4) for i in range(4)];cells=[]
for j,k in edges:
 cell=(max(stars[j][0],stars[k][0]),min(stars[j][1],stars[k][1]),max(stars[j][2],stars[k][2]),min(stars[j][3],stars[k][3]));assert (cell[1]-cell[0])*(cell[3]-cell[2])==F(1,4)
 members=[]
 for i,s in enumerate(stars):
  inside=cell[0]>=s[0] and cell[1]<=s[1] and cell[2]>=s[2] and cell[3]<=s[3]
  overlap=max(F(0),min(cell[1],s[1])-max(cell[0],s[0]))*max(F(0),min(cell[3],s[3])-max(cell[2],s[2]))
  assert inside or overlap==0
  if inside:members.append(i)
 assert set(members)=={j,k};cells.append(cell)
B=sp.Matrix([[int(j in edge) for edge in edges] for j in range(4)]);b=sp.Symbol('b',positive=True);assert B*sp.Matrix([b/2]*4)==sp.Matrix([b]*4)==B*sp.Matrix([b,0,b,0]);K=B[[0,1],:]*B[[0,1],:].T;assert K==sp.Matrix([[2,1],[1,2]])
results=[]
for m in (1,2,3,4):
 n=2*m;N=4**m;A=max(4,n*n);d=F(3,2)**n;v=d/F(A)**n;eps=F(1,2);z=d/F(2)**m+eps*v;capt=2**m*z;M=4**m*z;Q=2**m*d;V=N*v;assert M==Q+eps*V and capt==d+eps*v*2**m and F(V,Q)==F(2,A*A)**m and F(3,2*A)<1
 assert 2**m*capt==M
 kernel=np.array([[2,1],[1,2]],dtype=np.int64)
 for _ in range(m-1):kernel=np.kron(kernel,np.array([[2,1],[1,2]],dtype=np.int64))
 assert np.all(kernel.sum(axis=1)==3**m)
 # Exhaustive exact-integer subset test only up to 2^m=16; no asymptotic inference.
 k=2**m;bits=((np.arange(2**k,dtype=np.uint64)[:,None]>>np.arange(k,dtype=np.uint64))&1).astype(np.int64);sizes=bits.sum(axis=1);energies=np.sum((bits@kernel)*bits,axis=1);assert np.all(energies<=3**m*sizes)
 chi=eps*F(2,A*A)**m;bound_square=(1+chi)**2*F(3,4)**m
 results.append({'m':m,'dimension':n,'row_count':N,'a':A,'source_patterns':N,'clique_size':2**m,'subset_checks':2**k,'base_source_cell_volume':str(F(1,4)**m),'d':str(d),'v':str(v),'Q':str(Q),'M':str(M),'V_over_Q':str(F(V,Q)),'chi':str(chi),'fixed_source_weighted_retention_upper_squared':str(bound_square),'reselected_source_retention':str(F(1)),'exact_row_sum':3**m,'all_integer_subset_checks':True})
res={'results':results,'scope':'Exact finite checks of tensor identities and subset bound; general proof is in REPORT.tex and AUDIT.md, not inferred from tests.','python':platform.python_version(),'numpy':np.__version__,'sympy':sp.__version__,'elapsed_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};Path(a.output).write_text(json.dumps(res,indent=2));print('exact tensor checks:',len(results),'subset checks:',sum(r['subset_checks'] for r in results))
