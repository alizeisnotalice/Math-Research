import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[k]='1'
import argparse,importlib.util,json,hashlib,time
from pathlib import Path
from fractions import Fraction as F
from types import SimpleNamespace
p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--barrier',required=True);p.add_argument('--split',required=True);p.add_argument('--joint',required=True);p.add_argument('--certificate',required=True);p.add_argument('--output',required=True);a=p.parse_args();t=time.perf_counter()
spec=importlib.util.spec_from_file_location('relocation_model',a.model);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
wire={}
def intercept(c,**kw):
 wire.clear();wire.update(kw);wire['objective']=c
 return SimpleNamespace(status=4,message='intercepted for exact matrix check; no solver executed',x=None)
mod.milp=intercept
bar=json.loads(Path(a.barrier).read_text());split=json.loads(Path(a.split).read_text());joint=json.loads(Path(a.joint).read_text());cert=json.loads(Path(a.certificate).read_text());out=[]
for seed in (61902,61903):
 g=next(q for q in bar['geometries'] if q['seed']==seed);s=next(q for q in split['results'] if q['seed']==seed and q['alpha']==.1);j=next(q for q in joint['results'] if q['seed']==seed and q['alpha']==.1 and q['h_exact']==[1,1]);ce=next(q for q in cert['results'] if q['seed']==seed and q['h_requested']==['1','1'])
 mod.solve((g,s,j,ce))
 masks=[q['mask'] for q in g['patterns']];groups=j['maximal_clique_masks'];n=len(g['d']);C=len(masks);D=ce['allocation_denominator'];z=[F(q,s['rounded_source_denominator']) for q in s['source_numerators']]
 allocations={(i,k):F(int(v),D) for i,k,v in ce['source_allocations']};assert len(allocations)==len(ce['source_allocations']);used=[sum((v for (i,k),v in allocations.items() if i==c),F()) for c in range(C)]
 xs=[(i,-1) for i in range(C)]+[(i,k) for i,m in enumerate(masks) for k,cl in enumerate(groups) if m&cl];ys=[(jj,k) for k,cl in enumerate(groups) for jj in range(n) if cl>>jj&1];owners=set(map(tuple,ce['owners']));point=[z[i]-used[i] if k==-1 else allocations.get((i,k),F()) for i,k in xs]+[F(int(pair in owners)) for pair in ys]
 assert all(q>=0 for q in point)
 for i,k in allocations:assert (i,k) in xs
 cons=wire['constraints'];A=cons.A.tocsr();assert len(point)==A.shape[1];lower=cons.lb;upper=cons.ub
 violations=[];lowerbad=[];upperbad=[];boundbad=[]
 for row in range(A.shape[0]):
  val=sum((F(float(A.data[ii]))*point[int(A.indices[ii])] for ii in range(A.indptr[row],A.indptr[row+1])),F())
  if lower[row]!=float('-inf') and val<F(float(lower[row])):lowerbad.append((row,str(F(float(lower[row]))-val)))
  if upper[row]!=float('inf') and val>F(float(upper[row])):upperbad.append((row,str(val-F(float(upper[row])))))
 for k,q in enumerate(point):
  if q<F(float(wire['bounds'].lb[k])) or q>F(float(wire['bounds'].ub[k])):boundbad.append(k)
  if wire['integrality'][k]:assert q.denominator==1
 objective=sum((F(float(c))*q for c,q in zip(wire['objective'],point)),F());baseline=F(*map(int,ce['retained']));assert objective==-baseline
 out.append({'seed':seed,'rows':A.shape[0],'columns':A.shape[1],'nonzeros':A.nnz,'baseline':str(baseline),'exact_binary_float_coefficient_lower_violations':lowerbad,'exact_binary_float_coefficient_upper_violations':upperbad,'bound_violations':boundbad,'valid_actual_matrix':not(lowerbad or upperbad or boundbad)})
result={'results':out,'elapsed_seconds':time.perf_counter()-t,'no_solver_executed':True,'hashes':{k:hashlib.sha256(Path(getattr(a,k)).read_bytes()).hexdigest() for k in ('model','barrier','split','joint','certificate')}};Path(a.output).write_text(json.dumps(result,indent=2));print(json.dumps(out))
