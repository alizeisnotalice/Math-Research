# R621 复现、证据边界与依赖

一般 n^(1/2+o(1)) 上界未证明。REPORT.tex 是详细论证，AUDIT.md 是先独立检查后读作者的审查。不编译 PDF。新进展属于纠正全局择源量词、明确真实预算和经认证的有限共同分配；没有新的统一维数上界。

## 输入和实际环境

研究解释器 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`，Python3.12.14、NumPy2.5.4、SciPy1.18.1、SymPy1.14.0。输入 ccu_r619_barrier.json 与 ccu_r620_split.json 分别绑定 R619 完整几何/保存来源和 R620 向上有理化共同来源，源的上取整费用仍在输入中，未视为零。

PySCIPOpt6.3.0/SCIP10.0.2 独立安装在 `/Users/zhengzhihao/.local/share/math-research-tools/solvers/scip-6.3.0`，未覆盖原 venv。安装与实际版本/整数烟测见 ccu_r621_scip_installation.json。遵循[官方安装说明](https://pyscipopt.readthedocs.io/en/stable/install.html)。其他机器可在独立环境安装，并设置 `CCU_SCIP_PACKAGE_PATH` 为包所在目录。本轮未运行 MATLAB、Arb。

## 必要复核（不重跑优化）

在解压目录执行，写入新的 replay 文件，保留原记录：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r621_certificate.py --joint ccu_r621_joint.json --split ccu_r620_split.json --geometry ccu_r619_barrier.json --output replay_certificate.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r621_geometry_check.py --barrier ccu_r619_barrier.json --split ccu_r620_split.json --joint ccu_r621_joint.json --output replay_geometry.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r621_exact.py --output replay_exact.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r621_matrix_check.py --model ccu_r621_relocate_robust.py --barrier ccu_r619_barrier.json --split ccu_r620_split.json --joint ccu_r621_joint.json --certificate ccu_r621_certificate.json --output replay_matrix.json
```

预期：9个固定分配在各自 h_cert 下通过（不是全都在名义 h 下）；18行 group 清单完全一致（9行属于本轮阈值比较）；4维度共65,812个精确子集检验；两份实际 MILP 矩阵的基线有理检查全部无违反。矩阵检查拦截模型调用，不执行求解器。

证书 h_cert=min(请求h,各owner实际capture/d)，所有实际效能用 h_cert θ。SCIP/HiGHS 报告 optimal 或 gap0 不是严格最优证书。源部件矩形 membership、全部 group、原顺序真实 v 和总预算均在检查范围内。

## 可选重新优化

固定来源模型可用 ccu_r621_joint.py 指定 --barrier、--split、--output-dir，再按 --phase first、geometry、remaining、hscale 运行；仅 hscale 和 alpha=.1 的 h=1 三例用于当前阈值决策。旧 remaining 九个小alpha实例已实际发生，不建议为填CPU重新扫描。错误阈值模型的六个旧结果已废弃，保留的文件是修正后的版本；执行/修订 hash 见 index 与 RESOURCES.md。

同边际 h0=999999/1000000 模型：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r621_relocate_robust.py --barrier ccu_r619_barrier.json --split ccu_r620_split.json --joint ccu_r621_joint.json --certificate ccu_r621_certificate.json --output-dir rerun --workers 2
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r621_scip.py --input-dir . --output-dir rerun_scip --workers 2
```

原 HiGHS 在两个 robust 模型返回 infeasible，与精确基线冲突；不要把正常返回或这种状态视为证明。SCIP 接受两个基线，一例 optimal（仍有浮点残差），另一例 timelimit60s；尚无改选来源带来更好保留量的严格证书。

SCIP 可选脚本做了输入路径可移植化，算法与参数不改；保存运行记录属于原脚本 hash，PORTABILITY.json 同时给原执行 hash 和归档 hash。仅实际运行过的原实验记为数值证据；可移植版本仅语法/help检查，不声称重新执行了60秒实验。

## 资源及保留范围

使用 A04 共同选择技能的共享变量原则与 L03 有理证书要求，不借用未验证的最优性声明。模型额度没有可归属到本轮各模型的扣额数据，不猜模型成本比例。CPU、墙钟、worker和内存口径详见 RESOURCES.md；worker上限不等于持续满载。

本包不保存全部探索草稿；固定来源18行数据、严格证书、最终robust实际矩阵、SCIP交叉结果和必要精确验证已足以重放最终结论。一般几何证明须读 REPORT/AUDIT，不能由有限案例推出。MANIFEST.json绑定所有归档文件；ZIP CRC和各哈希另行核对。
