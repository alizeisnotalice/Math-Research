#!/usr/bin/env python3
"""Adversarial finite-positive-source exploration of actual all-space globally capped energy.
True complete arrival batches; signed all-log-volume events and infinity tail.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['VECLIB_MAXIMUM_THREADS']='1'
import argparse, hashlib, itertools, json, math, time
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
import numpy as np
C=1-math.exp(-1)


def arrays(src):
    W=F(src['W']);return np.array(src['coords'],float),np.array([float(F(p)/W) for p in src['weights']])



def integer_masses(src):
    masses=[F(p)/F(src['W']) for p in src['weights']];den=math.lcm(*(p.denominator for p in masses));assert den<2**60
    integers=np.array([p.numerator*(den//p.denominator) for p in masses],dtype=np.int64)
    return den,integers

def pack(coords,weights,family):
    merged={};weights=[F(p) for p in weights];W=sum(weights)
    for y,p in zip(coords,weights):merged[tuple(float(z) for z in y)]=merged.get(tuple(float(z) for z in y),F(0))+p/W
    return dict(family=family,n=len(coords[0]),N_requested=len(coords),N_labels=len(coords),N=len(merged),coords=[list(y) for y in merged],weights=[str(p) for p in merged.values()],W='1')

def family_source(kind,n,N):
    if kind=='grid':y=[[(j+.5)/N-.5]+[0.]*(n-1) for j in range(N)];p=[F(1,N)]*N
    elif kind=='nested_cluster':y=[[0.]*n]+[[2.**(-j)]*n for j in range(1,N)];p=[F(1,N)]*N
    elif kind=='unequal_nested':
        y=[[0.]*n]+[[2.**(-j)]*n for j in range(1,N)];p=[F(2**(j//max(1,N//16))) for j in range(N)]
    elif kind=='common_faces':y=[[(2*j+1-N)/N]+[0.]*(n-1) for j in range(N)];p=[F(1,N)]*N
    else:raise ValueError(kind)
    return pack(y,p,kind)

def binary_geometry(x,coords):
    xr=[float(z).as_integer_ratio() for z in x];yr=[[float(z).as_integer_ratio() for z in y] for y in coords]
    B=max(t.bit_length()-1 for u,t in xr+sum(yr,[]));xi=[u<<(B-(t.bit_length()-1)) for u,t in xr]
    ds=[max(abs(z-(u<<(B-(t.bit_length()-1)))) for z,(u,t) in zip(xi,row)) for row in yr]
    return ds,B

def exact_winner(x,src,H):
    ds,B=binary_geometry(x,src['coords']);den,ints=integer_masses(src);order=sorted(range(src['N']),key=lambda i:ds[i])
    cum=0;bestnum=0;bestden=1;best=-1
    for j,i in enumerate(order):
        cum+=int(ints[i])
        if j+1<len(order) and ds[i]==ds[order[j+1]]:continue
        d=ds[i]**src['n']
        if d==0:raise ValueError('Receiver coincides with an atom; null-set sample unsupported')
        if cum*bestden>bestnum*d:bestnum,bestden,best=cum,d,j
    M=F(bestnum,bestden)*F(src['W'])/den/F(2)**(src['n']*(1-B))
    capture=np.zeros(src['N'],dtype=bool);capture[order[:best+1]]=True
    return capture,M,H<M<=2*H,order,best


def receiver_draw(src,H,S,seed,mode='mixed'):
    rng=np.random.default_rng(seed);y,a=arrays(src);n=src['n'];V=float(F(src['W'])/F(H))
    center=rng.choice(src['N'],size=S,p=a);U=np.maximum(rng.random(S),np.nextafter(0.,1.));inner=rng.integers(0,2,size=S)==0
    individual=rng.integers(0,2,size=S)==0 if mode=='mixed' else np.ones(S,dtype=bool)
    lv=math.log(V)+np.where(inner,np.log(U),-np.log(U))+np.where(individual,np.log(a[center]),0)
    theta=rng.uniform(-1,1,size=(S,n));face=rng.integers(n,size=S);sign=rng.integers(0,2,size=S)*2-1;theta[np.arange(S),face]=sign
    return y[center]+(.5*np.exp(lv/n))[:,None]*theta,center,inner,U,face,sign,individual


def point_batch(x,src,H,mode='mixed'):
    y,a=arrays(src);S=len(x);n=src['n'];N=src['N'];den,ints=integer_masses(src);V=float(F(src['W'])/F(H))
    dist=np.max(abs(x[:,None,:]-y[None,:,:]),axis=2)
    with np.errstate(divide='ignore'):L=n*np.log(2*dist)-math.log(V)
    mf=np.exp(-2*np.maximum(L-np.log(a)[None,:],0))
    qmass=.5*np.sum(mf,axis=1);qglobal=.5*np.sum(a[None,:]*np.exp(-2*np.maximum(L,0)),axis=1)
    q=(qmass+qglobal)/2 if mode=='mixed' else qmass
    order=np.argsort(L,axis=1,kind='stable');sl=np.take_along_axis(L,order,axis=1)
    ends=np.concatenate([sl[:,1:]!=sl[:,:-1],np.ones((S,1),bool)],axis=1);groupfix=0;falsegroups=0
    for r in np.flatnonzero(np.any(abs(sl[:,1:]-sl[:,:-1])<=64*np.finfo(float).eps*(np.max(abs(sl),axis=1)[:,None]+2),axis=1)):
        ds,B=binary_geometry(x[r],src['coords']);oi=sorted(range(N),key=lambda i:ds[i]);order[r]=oi;sl[r]=L[r,oi]
        en=np.array([ds[oi[j]]!=ds[oi[j+1]] for j in range(N-1)]+[True]);falsegroups+=int(np.sum(en & ~np.concatenate([sl[r,1:]!=sl[r,:-1],[True]])))
        ends[r]=en;groupfix+=1
    cum=np.cumsum(ints[order],axis=1);arrival=np.where(ends,(cum/den)*np.exp(-sl),0);M=arrival.max(axis=1);cap=M<=1
    exactrows=0
    for r in np.flatnonzero(abs(M-1)<=128*np.finfo(float).eps*np.maximum(1,M)):
        _,mm,_,_,_=exact_winner(x[r],src,F(H));M[r]=float(mm/F(H));cap[r]=mm<=F(H);exactrows+=1
    lo=math.log(.25);hi=math.log(4)
    flow=np.sum(np.where(L<=lo,ints[None,:],0),axis=1)/den;fhi=np.sum(np.where(L<=hi,ints[None,:],0),axis=1)/den
    localM=np.maximum.reduce([4*flow,fhi/4,np.max(np.where(ends & (sl>=lo)&(sl<=hi),arrival,0),axis=1)])
    localcap=localM<=1
    assert np.all(~cap | localcap)
    # Integer cumulative masses replace cancellation-prone cumulative signed changes.
    ev=np.concatenate([L-1,L],axis=1);eo=np.argsort(ev,axis=1,kind='stable');ev=np.take_along_axis(ev,eo,axis=1);scalefix=0
    cross=(eo[:,1:]<N)!=(eo[:,:-1]<N)
    near=np.any(cross & (abs(ev[:,1:]-ev[:,:-1])<=64*np.finfo(float).eps*(np.max(abs(ev),axis=1)[:,None]+2)),axis=1)
    for r in np.flatnonzero(near):
        ds,B=binary_geometry(x[r],src['coords'])
        with localcontext() as ctx:
            ctx.prec=120;e=D(1).exp();vv=[D(d)**n for d in ds];values=[v/e for v in vv]+vv
            oi=sorted(range(2*N),key=lambda i:(values[i],i));eo[r]=oi;ev[r]=np.concatenate([L[r]-1,L[r]])[oi]
        scalefix+=1
    incoming=np.where(eo<N,ints[eo%N],0);current=np.where(eo>=N,ints[eo%N],0)
    Fadv=np.cumsum(incoming,axis=1)/den;Fcur=np.cumsum(current,axis=1)/den;coef=Fadv/math.e-Fcur
    gaps=np.maximum(ev[:,1:]-ev[:,:-1],0)
    factors=np.concatenate([-np.expm1(-2*gaps),np.ones((S,1))],axis=1)
    pieces=(coef*np.exp(-ev))**2*factors/2;full=pieces.sum(axis=1)
    right=np.concatenate([ev[:,1:],np.full((S,1),np.inf)],axis=1);left=np.maximum(ev,lo);rr=np.minimum(right,hi)
    window=np.sum(np.where(rr>left,(coef*np.exp(-left))**2*(-np.expm1(-2*np.maximum(rr-left,0)))/2,0),axis=1)
    # Tail beyond the last physical arrival, where F=Fadv=W, is retained exactly.
    last=sl[:,-1];tail=C*C*np.exp(-2*last)/2
    diag=C*np.sum(a[None,:]**2*np.exp(-2*L),axis=1)
    energy=np.where(cap,full,0);gwindow=np.where(cap,window,0);lwindow=np.where(localcap,window,0)
    score=energy/q;bound=(4 if mode=='mixed' else 2)*C*N
    assert np.all(np.isfinite(score)) and score.max()<=bound*(1+1e-9)
    assert np.max(lwindow/q)<=(32 if mode=='mixed' else 16)*N*(1+1e-9)
    assert np.max(abs(gwindow-np.minimum(gwindow,lwindow)))<1e-12
    return dict(M=M,localM=localM,cap=cap,localcap=localcap,q=q,energy=energy,full=full,window=window,gwindow=gwindow,lwindow=lwindow,diag=np.where(cap,diag,0),tail=np.where(cap,tail,0),groupfix=groupfix,falsegroups=falsegroups,scalefix=scalefix,exactrows=exactrows)


def summary(z,bound):
    sm=float(z.sum());ss=float(z@z);S=len(z)
    return dict(mean=float(z.mean()),sample_SE=float(z.std(ddof=1)/math.sqrt(S)),maximum=float(z.max()),ideal_score_bound=bound,formal_Hoeffding95_radius=bound*math.sqrt(math.log(40)/(2*S)),nonnegative_score_ESS=sm*sm/ss if ss else 0,top_one_percent_score_fraction=float(np.sort(z)[-max(1,S//100):].sum()/sm) if sm else 0)


def probe(src,H,S,seed,stage,mode='mixed'):
    x,center,inner,U,face,sign,individual=receiver_draw(src,H,S,seed,mode)
    chunks=[point_batch(x[j:j+128],src,H,mode) for j in range(0,S,128)];keys=['M','localM','cap','localcap','q','energy','full','window','gwindow','lwindow','diag','tail'];d={k:np.concatenate([z[k] for z in chunks]) for k in keys}
    score=d['energy']/d['q'];bound=(4 if mode=='mixed' else 2)*C*src['N'];wb=(32 if mode=='mixed' else 16)*src['N']
    def saved(i):return dict(receiver=x[i].tolist(),M_H=float(d['M'][i]),localM_H=float(d['localM'][i]),cap=bool(d['cap'][i]),localcap=bool(d['localcap'][i]),qcore=float(d['q'][i]),energycore=float(d['full'][i]),windowcore=float(d['window'][i]),score=float(score[i]),selected_center=int(center[i]),individual_component=bool(individual[i]),radial_inner=bool(inner[i]),U=float(U[i]),face=int(face[i]),sign=int(sign[i]))
    extremes=[saved(i) for i in np.argsort(score)[-2:][::-1]];gates=[]
    for accepted in [False,True]:
        ids=np.flatnonzero(d['cap']==accepted)
        if len(ids):gates.append(dict(accepted=accepted,**saved(int(ids[np.argmin(abs(np.log(d['M'][ids])))]))))
    return dict(source=src,H=str(H),samples=S,seed=seed,stage=stage,proposal=mode,cap_hits=int(d['cap'].sum()),energy=summary(score,bound),source_diagonal=summary(d['diag']/d['q'],bound),infinity_tail=summary(d['tail']/d['q'],bound),global_cap_window=summary(d['gwindow']/d['q'],wb),local_cap_window=summary(d['lwindow']/d['q'],wb),local_only_window=summary((d['lwindow']-d['gwindow'])/d['q'],wb),local_only_hits=int((d['localcap'] & ~d['cap']).sum()),minimum_gate_log_margin=float(abs(np.log(d['M'])).min()),extremes=extremes,closest_gates=gates,exact_binary_geometry_rows=sum(z['groupfix'] for z in chunks),false_log_groups_corrected=sum(z['falsegroups'] for z in chunks),Decimal_event_order_rows=sum(z['scalefix'] for z in chunks),exact_cap_rows=sum(z['exactrows'] for z in chunks))


def make_source(kind,n,N):
    if kind in ['nested_cluster','unequal_nested','common_faces','grid']:return family_source(kind,n,N)
    if kind=='single':return dict(family=kind,n=n,N_requested=1,N_labels=1,N=1,coords=[[.25]*n],weights=['3'],W='3')
    if kind=='vertices':return pack(list(itertools.product([-1.,1.],repeat=n)),[F(1)]*(2**n),kind)
    rng=np.random.default_rng(690071+1009*n+37*N)
    if kind=='unequal_cloud':y=(rng.integers(-512,513,size=(N,n))/512).tolist();p=[F((j+1)**2) for j in range(N)]
    elif kind=='correlated':
        center=np.array([(2*j+1-N)/(2*N) for j in range(N)])[:,None];y=(center+rng.integers(-8,9,size=(N,n))/1024).tolist();p=[F(1,N)]*N
    elif kind=='near_cluster':y=[[(2*j+1-N)/(2*N*1024)]*n for j in range(N)];p=[F(1,N)]*N
    else:raise ValueError(kind)
    return pack(y,p,kind)






# Fixed-decimal rational outward intervals: endpoints are integers / Q.
# Every arithmetic operation rounds by integer floor/ceiling, not Decimal.
Q=10**100
def ceildiv(a,b):return -((-a)//b)
def ivfrac(z):
    z=F(z);return (z.numerator*Q//z.denominator,ceildiv(z.numerator*Q,z.denominator))
def ivadd(a,b):return (a[0]+b[0],a[1]+b[1])
def ivneg(a):return (-a[1],-a[0])
def ivsub(a,b):return ivadd(a,ivneg(b))
def ivmul(a,b):
    z=[a[i]*b[j] for i in [0,1] for j in [0,1]];return (min(z)//Q,ceildiv(max(z),Q))
def ivrecip(a):
    assert a[0]>0;return (Q*Q//a[1],ceildiv(Q*Q,a[0]))
def ivsquare(a):
    lo=0 if a[0]<=0<=a[1] else min(a[0]**2,a[1]**2)
    return (lo//Q,ceildiv(max(a[0]**2,a[1]**2),Q))
def ivdiv(a,b):return ivmul(a,ivrecip(b))
def ivstr(a):return [str(F(a[0],Q)),str(F(a[1],Q))]


def exponential_bounds():
    term=F(1);lo=term
    for k in range(1,101):term/=k;lo+=term
    # First omitted term 1/101!, all subsequent ratios at most 1/102.
    hi=lo+term/F(101)/(1-F(1,102))
    assert lo<hi;return lo,hi


def actual_volumes(x,src,H):
    ds,B=binary_geometry(x,src['coords']);V=F(src['W'])/F(H);factor=F(2)**(src['n']*(1-B))/V
    return [d**src['n']*factor for d in ds],[F(p)/F(src['W']) for p in src['weights']]


def rational_energy_guard(x,src,H,mode='mixed'):
    vols,a=actual_volumes(x,src,H);groups={}
    for v,p in zip(vols,a):groups[v]=groups.get(v,F(0))+p
    vp=sorted(groups.items());cum=F(0);M=F(0);localM=F(0)
    for v,p in vp:
        cum+=p;M=max(M,cum/v)
        if F(1,4)<=v<=4:localM=max(localM,cum/v)
    for endpoint in [F(1,4),F(4)]:localM=max(localM,sum((p for v,p in vp if v<=endpoint),F(0))/endpoint)
    qg=sum((p/2*min(1,1/v**2) for v,p in zip(vols,a)),F(0));qm=sum((F(1,2)*min(1,(p/v)**2) for v,p in zip(vols,a)),F(0));q=(qg+qm)/2 if mode=='mixed' else qm
    el,eh=exponential_bounds();ee=(ivfrac(el)[0],ivfrac(eh)[1]);h=ivrecip(ee)
    events=[]
    for v,p in vp:
        vv=ivfrac(v);events.append((ivmul(vv,h),True,p));events.append((vv,False,p))
    events.sort(key=lambda z:(z[0][0]+z[0][1],not z[1]))
    ordered=all(events[j][0][1]<=events[j+1][0][0] for j in range(len(events)-1))
    if not ordered:return dict(event_order_certified=False,scope='Fixed interval precision did not separate every event; no energy enclosure asserted.')
    incoming=F(0);current=F(0);energy=(0,0);window=(0,0)
    def factor(l,r):
        z=ivsquare(ivrecip(l))
        if r is not None:z=ivsub(z,ivsquare(ivrecip(r)))
        return (max(0,z[0]),max(0,z[1]))
    for j,(v,inc,p) in enumerate(events):
        if inc:incoming+=p
        else:current+=p
        coef=ivsub(ivmul(ivfrac(incoming),h),ivfrac(current));cs=ivsquare(coef);right=events[j+1][0] if j+1<len(events) else None
        piece=ivmul(ivmul(cs,factor(v,right)),ivfrac(F(1,2)));energy=ivadd(energy,piece)
        l=(max(v[0],Q//4),max(v[1],Q//4));r=(4*Q,4*Q) if right is None else (min(right[0],4*Q),min(right[1],4*Q))
        if r[1]>l[0]:window=ivadd(window,ivmul(ivmul(cs,factor(l,r)),ivfrac(F(1,2))))
    score=ivdiv(energy,ivfrac(q)) if M<=1 else (0,0)
    b=point_batch(np.array([x],float),src,H,mode)
    assert bool(b['cap'][0])==(M<=1) and bool(b['localcap'][0])==(localM<=1)
    ef=F.from_float(float(b['full'][0]));wf=F.from_float(float(b['window'][0]));qf=F.from_float(float(b['q'][0]))
    er=float(max(abs(ef-F(energy[0],Q)),abs(ef-F(energy[1],Q)))/max(F(energy[0],Q),F(1,10**300)))
    wr=float(max(abs(wf-F(window[0],Q)),abs(wf-F(window[1],Q)))/max(F(window[0],Q),F(1,10**300))) if window[0]>0 else None
    qr=float(abs(qf-q)/q);assert er<1e-8 and qr<1e-10
    return dict(event_order_certified=True,receiver=[float(z) for z in x],M_H=str(M),localM_H=str(localM),cap=M<=1,localcap=localM<=1,physical_arrival_groups=len(vp),energy_enclosure=ivstr(energy),window_enclosure=ivstr(window),score_enclosure=ivstr(score),float_energy_relative_discrepancy=er,float_window_relative_discrepancy=wr,float_q_relative_discrepancy=qr,enclosure_relative_width=float(F(energy[1]-energy[0],max(energy[0],1))),scope='Exact binary-coordinate/rational source geometry and maximal gates. Finite integer outward-rounding event-energy enclosure with a Taylor remainder bound for e. This finite point enclosure is not a receiver-integral or sampler certificate.')


def decimal_energy_guard(x,src,H,precision,gram=False):
    vols,a=actual_volumes(x,src,H)
    with localcontext() as ctx:
        ctx.prec=precision;e=D(1).exp();h=1/e;c=1-h;dec=lambda z:D(z.numerator)/D(z.denominator);groups={}
        for v,p in zip(vols,a):groups[v]=groups.get(v,F(0))+p
        vp=[(dec(v),dec(p)) for v,p in sorted(groups.items())];events={}
        for v,p in vp:events[v/e]=events.get(v/e,D(0))+p/e;events[v]=events.get(v,D(0))-p
        keys=sorted(events);coef=D(0);event=D(0);window=D(0)
        for j,v in enumerate(keys):
            coef+=events[v];right=keys[j+1] if j+1<len(keys) else None
            event+=coef**2/2*(v**-2-(right**-2 if right is not None else 0))
            l=max(v,D('.25'));r=min(right,D(4)) if right is not None else D(4)
            if r>l:window+=coef**2/2*(l**-2-r**-2)
        out=dict(event=str(event),window=str(window))
        if gram:
            g=D(0)
            for v,p in vp:
                for w,t in vp:
                    small,big=min(v,w),max(v,w);ratio=big/small
                    kernel=(2-h-h*ratio**2)/(2*big**2) if ratio<=e else -c*c/(2*h*big**2)
                    g+=p*t*kernel
            out.update(Gram=str(g),event_Gram_relative=str(abs(g-event)/max(event,D('1e-1000'))));assert abs(g-event)/event<D(10)**(-precision+15)
        return out


def guards(rows):
    points=[];gates=[]
    for j,r in enumerate(rows):
        if r['stage']=='pilot':continue
        for z in r['extremes']:
            iv=rational_energy_guard(z['receiver'],r['source'],F(r['H']),r['proposal']);assert iv['event_order_certified']
            lo=decimal_energy_guard(z['receiver'],r['source'],F(r['H']),80,gram=r['source']['N']<=16);hi=decimal_energy_guard(z['receiver'],r['source'],F(r['H']),120,gram=r['source']['N']<=16)
            points.append(dict(row=j,receiver=z['receiver'],rational_interval=iv,Decimal80=lo,Decimal120=hi))
        for z in r['closest_gates']:
            cap,M,_,_,_=exact_winner(z['receiver'],r['source'],F(r['H']));assert (M<=F(r['H']))==z['accepted']
            gates.append(dict(row=j,receiver=z['receiver'],accepted=z['accepted'],exact_M_H=str(M/F(r['H'])),float_M_H=z['M_H']))
    tied=pack([[-.25,0.],[.25,0.]],[F(1,3),F(2,3)],'actual_face_tie')
    controlled=[]
    for x in [[0.,2.],[.125,2.],[0.,.5]]:
        controlled.append(dict(rational_interval=rational_energy_guard(x,tied,F(1)),Decimal80=decimal_energy_guard(x,tied,F(1),80,True),Decimal120=decimal_energy_guard(x,tied,F(1),120,True)))
    for n in [1,4,16,32]:
        s=make_source('unequal_cloud',n,8);x=[3.]*n
        controlled.append(dict(rational_interval=rational_energy_guard(x,s,F(1)),Decimal80=decimal_energy_guard(x,s,F(1),80,True),Decimal120=decimal_energy_guard(x,s,F(1),120,True)))
    return dict(actual_extremes=points,closest_gates=gates,controlled=controlled,e_series_terms=101,interval_decimal_grid=100,scope='Finite outward rational time-energy guards and exact machine-coordinate gate checks. Monte Carlo all-space integrals remain estimates.')




# All source weights are strictly positive rationals; pack merges duplicate sites.
BANK_KINDS=['binary','hierarchical','correlated','unequal_cloud','multi_cluster']
STRATA=[(1,16),(4,16),(8,32),(16,64)]

def structured_source(kind,n,N,seed):
    rng=np.random.default_rng(seed)
    if kind=='binary':
        if N<=2**n:
            labels=rng.choice(2**n,size=N,replace=False)
            y=np.array([[2*((int(j)>>k)&1)-1 for k in range(n)] for j in labels],float)
        else:
            y=rng.choice([-1.,1.],size=(N,n))+rng.integers(-8,9,size=(N,n))/64
        weights=[1]*N
    elif kind=='hierarchical':
        depth=max(1,(N-1).bit_length())
        code=rng.integers(0,2,size=(depth,n))*2-1
        y=np.array([sum((((j>>k)&1)*2-1)*2.**(-k)*code[k] for k in range(depth)) for j in range(N)])
        y/=max(1.,float(abs(y).max()));weights=[1]*N
    elif kind=='correlated':
        t=np.linspace(-1,1,N)[:,None]
        y=t+rng.integers(-4,5,size=(N,n))/128;weights=[1]*N
    elif kind=='unequal_cloud':
        y=rng.integers(-64,65,size=(N,n))/64;weights=[1+(j%8)**2 for j in range(N)]
    elif kind=='multi_cluster':
        centers=rng.choice([-1.,1.],size=(4,n));y=np.array([centers[j%4]+rng.integers(-8,9,size=n)*2.**(-4-j//4) for j in range(N)])
        weights=[1+3*(j%4==0) for j in range(N)]
    else:raise ValueError(kind)
    return pack(y.tolist(),[F(p) for p in weights],kind)


def digest(src,H):
    return hashlib.sha256(json.dumps(dict(source=src,H=str(H)),sort_keys=True,separators=(',',':')).encode()).hexdigest()


def slim_probe(src,H,S,seed,stage):
    row=probe(src,H,S,seed,stage)
    for key in ['global_cap_window','local_cap_window','local_only_window','local_only_hits']:
        row.pop(key,None)
    return row


def merit(row):return row['energy']['mean']-.5*row['energy']['sample_SE']


def mutate(src,H,rng,j):
    y=np.array(src['coords'],float);a=[F(p)/F(src['W']) for p in src['weights']];n=src['n'];N=src['N'];op=j%6
    p=list(a)
    if op==0:
        i=int(rng.integers(N));y[i]+=rng.integers(-8,9,size=n)/64;name='one_site_dyadic_perturbation'
    elif op==1:
        k=int(rng.integers(n));y[:,k]*=float(rng.choice([F(7,8),F(9,8)]));name='coordinate_stretch'
    elif op==2:
        k=int(rng.integers(n));shift=int(rng.choice([-1,1]))/8;y[y[:,k]>np.median(y[:,k]),k]+=shift;name='half_source_shift'
    elif op==3:
        p=[F(max(1,min(64,round(float(t/max(a))*32)))) for t in a];i=int(rng.integers(N));p[i]=F(int(rng.integers(1,65)));name='positive_integer_mass_reallocation'
    elif op==4:
        y+=rng.integers(-1,2,size=(N,n))/64;name='all_site_dyadic_perturbation'
    else:
        H*=F.from_float(2.**(int(rng.choice([-1,1]))*n/8));name='threshold_log_root_step'
        return src,H,name
    return pack(y.tolist(),p,src['family']),H,name


def search(pilots):
    traces=[];chosen=[];draws=0
    for chain,(n,N) in enumerate(STRATA):
        candidates=[r for r in pilots if r['source']['n']==n and r['source']['N_requested']==N]
        selected=max(candidates,key=merit);initial_src=selected['source'];initial_H=F(selected['H'])
        seed=700701+1009*chain;S=1024;cur=slim_probe(initial_src,initial_H,S,seed,'search_CRN');draws+=S
        initial=cur;trace=[dict(iteration=-1,operation='initial',source_digest=digest(cur['source'],F(cur['H'])),mean=cur['energy']['mean'],sample_SE=cur['energy']['sample_SE'],merit=merit(cur),accepted=True)]
        rng=np.random.default_rng(700801+1009*chain)
        for j in range(24):
            src,H,operation=mutate(cur['source'],F(cur['H']),rng,j)
            trial=slim_probe(src,H,S,seed,'search_CRN');draws+=S;accept=merit(trial)>merit(cur)
            trace.append(dict(iteration=j,operation=operation,source_digest=digest(src,H),mean=trial['energy']['mean'],sample_SE=trial['energy']['sample_SE'],merit=merit(trial),accepted=accept))
            if accept:cur=trial
        traces.append(dict(chain=chain,n=n,N_requested=N,receiver_seed=seed,samples_per_evaluation=S,objective='mean minus 0.5 sample SE; heuristic selection score, not confidence bound',initial=initial,selected=cur,trace=trace))
        chosen.append((initial_src,initial_H,cur['source'],F(cur['H'])))
        print('search',chain,n,N,'initial',initial['energy']['mean'],'selected',cur['energy']['mean'],'SE',cur['energy']['sample_SE'],flush=True)
    return traces,chosen,draws


def run_pilot():
    rows=[]
    for j,(n,N) in enumerate(STRATA):
        for k,kind in enumerate(BANK_KINDS):
            src=structured_source(kind,n,N,700101+1009*j+37*k)
            # Three fixed threshold roots; all are chosen before receiver draws.
            # Seed is common across thresholds of the same source (CRN only).
            for root in [F(1),F(3,2),F(2)]:
                H=F.from_float(2.**(-float(n*root)))
                row=slim_probe(src,H,512,700201+1009*j+37*k,'pilot');row['threshold_log2_root']=str(root);rows.append(row)
                print('pilot',n,N,kind,str(root),row['energy']['mean'],row['energy']['sample_SE'],flush=True)
    return rows


def final_rows(chosen):
    rows=[]
    # Held-out receivers never enter the selection criterion.
    for chain,(control,cH,winner,wH) in enumerate(chosen):
        for label,src,H in [('initial_control',control,cH),('optimized_candidate',winner,wH)]:
            for repeat in range(2):
                seed=701001+1009*chain+97*(label=='optimized_candidate')+repeat
                r=slim_probe(src,H,8192,seed,'heldout_selected');r.update(chain=chain,role=label);rows.append(r)
            print('heldout_selected',chain,label,rows[-1]['energy']['mean'],rows[-1]['energy']['sample_SE'],flush=True)
    # New fixed geometries change dimension and source count independently.
    # These are not optimized in their enlarged dimensions.
    for n in [2,8,32]:
        for N in [8,32,64]:
            for kind in ['binary','hierarchical']:
                src=structured_source(kind,n,N,702001+1009*n+37*N+(kind=='hierarchical'))
                H=F.from_float(2.**(-n*(1.5 if kind=='binary' else 1)))
                for repeat in range(2):
                    r=slim_probe(src,H,2048,703001+1009*n+37*N+211*(kind=='hierarchical')+repeat,'heldout_expanded');rows.append(r)
                print('expanded',n,N,kind,rows[-1]['energy']['mean'],rows[-1]['energy']['sample_SE'],flush=True)
    # Counterpressure thresholds for actual Boolean vertices; count 2^n is explicit.
    for n in [4,8]:
        src=make_source('vertices',n,2**n)
        for H in [F(1,2**(n+n//2+1)),F(1,4**n)]:
            for repeat in range(2):rows.append(slim_probe(src,H,4096,704001+1009*n+17*int(H.denominator.bit_length())+repeat,'counterpressure_vertices'))
    for n in [1,16]:
        r=slim_probe(make_source('single',n,1),F(7,3),4096,705001+1009*n,'one_atom_calibration');r['analytic_reference']=C;rows.append(r)
    two=pack([[-.5],[.5]],[F(1,2)]*2,'two_atom_calibration')
    for repeat in range(2):
        r=slim_probe(two,F(1),4096,705501+repeat,'two_atom_calibration');r['analytic_reference']=C+(math.e+2/math.e-3)/15;rows.append(r)
    return rows


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');args=ap.parse_args();start=time.perf_counter()
    pilots=run_pilot();traces,chosen,sd=search(pilots);rows=pilots if args.pilot else pilots+final_rows(chosen)
    g={} if args.pilot else guards(rows)
    counts=dict(rows=len(rows),receiver_draws=sum(r['samples'] for r in rows),search_evaluations=sum(len(t['trace']) for t in traces),search_draws=sd,total_draws=sd+sum(r['samples'] for r in rows),extreme_guards=len(g.get('actual_extremes',[])),gate_guards=len(g.get('closest_gates',[])),controlled_guards=len(g.get('controlled',[])))
    result=dict(round=70,status='PILOT' if args.pilot else 'FINAL',counts=counts,numpy_version=np.__version__,scope='Actual finite positive sources, full-space receiver Lebesgue importance, true full-scale maximal cap, signed full-time energy including infinity tail. CRN mutation search is a finite noisy heuristic; held-out seeds are independent. No fitted orders, uniform upper theorem, or weak counterexample inferred.',proposal='Half global/half individual-mass source-centered radial mixture; complete density evaluated at every receiver; cap score <=4(1-e^-1)N.',search=traces,rows=rows,guards=g)
    Path(__file__).with_name('adversarial_cap_results.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print('runtime',time.perf_counter()-start,flush=True)


if __name__=='__main__':main()
