# Round 70: exact reset laws and necessary signed long-range cancellation

2026-10-11. **The general sqrt(n)n^{o(1)} upper bound remains UNPROVED.**
The retained unconditional general benchmark is O(n log n).

This round attempts two genuinely general energy-budget mechanisms:
Markov representations of arbitrary inputs, and signed temporal scale
localization. It proves exact representations and refutes three excessive
payment claims on the ORIGINAL global good set. None of these
counterexamples refutes the actual complete signed cap-energy conjecture.

## Results and remaining interface

1. Whole-point cone-shell resets in volume time give the exact kernel
   K_uv=e^(u-v)delta_y+e^-v 1_(Q_v minus Q_u) dz. The backward law keeps
   an inner point or resamples the earlier uniform cube for an outer point.
   Actual filtrations/generators/compensators are specified. Mean cube
   averages are not silently promoted to martingales. Coordinate resets
   give a separate exact representation and reverse kernel.
2. A one-cube indicator at delta_n=(4n^2)^(-n) disproves a subpower
   one-copy squared-path-increment or bracket payment. The true squared
   mean remains small. The exact two-independent-copy signed formula
   preserves the missing rare-occupancy factor.
3. The conditional Cauchy repair gains that rare-event factor locally,
   but its natural mean-weighted XOR payment grows at least
   (9(1-e^-1)/256)log(N/96) on finite periodic interval unions, at
   rho=1/4=delta_1. It therefore cannot replace complete signed energy.
4. For any fixed R>=e, retaining ALL signed Gram interactions whose
   volume ratio is at most R leaves a positive omitted-tail magnitude
   kappa sum_j P_j F((t_j/R)^-)/t_j^2, kappa=e+e^-1-2.
   On a true-cap midpoint grid, the normalized truncated energy is at
   least kappa[1+floor(log2(N/(32R)))]/(256R). The exact negative prefix
   and tie-safe Stieltjes identity are retained, not charged separately.
5. Integer cube refinement is positive but a direct pointwise comparison
   of static energy with its child variance loses exactly 2^n-1 on a
   good single-atom receiver. This does not rule out an integrated repair.

The whole-point representation gives the actual shell innovation
D_u=(1-e^-1)(B_u-A_u), with B_u<=H/(1-e^-1) on the original cap.
What remains is a JOINT spatial/time cancellation estimate, uniformly
in atom count, input depth, threshold and scale window:

    integral_{M mu<=H} integral |A_{u+1}mu-A_u mu|^2 du dx
        <= K_n H mu(R^n),  K_n=n^{o(1)}.

It is a sufficient interface, not a necessary condition for the weak
bound. Round69 already proves that it implies
C_n<=C[1+sqrt(n log(n+2)K_n)]. This round neither proves that interface
nor substitutes a narrower special-source estimate for it. Future
attempts must retain both distant signed interactions and two-copy
averaging, or introduce a different paid general route.

## Validation

The actual cap-energy search has 60 pilot rows, 100 common-random-number
search evaluations, and 64 independent final rows: 387072 draws in the
final registered run. Dimension and source count are independently
varied in the enlarged matrix. The entire time tail and all spatial
proposal components are retained. Parent replay exited 0 and reproduced
the serialized results byte for byte in about 31.19 seconds.

The n=4 selected search value 0.81231 becomes 0.76153 +/- 0.00624 sample
SE on independent receivers; its control is 0.75771 +/- 0.00579. The n=1
candidate gives 0.72412 +/- 0.00722 with 13 distinct sites. Actual n=8
full vertices give 0.78896 +/- 0.01134 at H=1/8192. These are finite
numerical estimates, not uniform bounds, certified integration intervals,
or asymptotic exponents. The ideal finite-score Hoeffding radii are broad.
There are 128 retained extrema, 128 exact gate checks and seven controlled
points, with outward rational finite-point energy enclosures; these do
not certify the whole spatial integral.

Three supplemental guards are reproduced below and independently run:
whole-point rational identities, coordinate/reset/plateau checks, and
signed Gram/grid/prefix checks. All are finite checks supporting the
separately written proofs. Current 64 skill entries and 437 direct
references were rehashed against Round69 with no changes; all references
exist, and three shared evidence-resolution checks passed again.

## Reproduction and delivery

Extract research.zip to a temporary directory. Preserve the archived
results JSON before running `python3 -B adversarial_cap_probe.py`, which
writes that filename beside the script. The tested runtime is Python
3.12.14 with NumPy 2.3.5; the supplemental guards use only the standard
library. The exact parameters, source geometries, seeds and search traces
are in the script and JSON. Do not use --pilot for the final replay.

The archive contains exactly proof.md, proof.tex.txt,
adversarial_cap_probe.py, adversarial_cap_results.json, inventory.json.
The LaTeX source is saved as txt, not compiled, and no PDF is generated.
Historical required proofs and counterexamples remain in previous rounds.



---

# Round 70: whole-point shell reset, exact probability interface

Status: the transition, reverse transition, generator, compensator and one-step shell cap below are proved. They represent arbitrary nonnegative L1 inputs exactly. They do NOT establish a uniform capped energy or weak-type bound. This is independent of the coordinate-reset representation in the companion note.

Use volume time u=n log L. Write Q_u=[-e^{u/n}/2,e^{u/n}/2]^n, V_u=e^u, U_u=e^{-u}1_{Q_u}dz. Let S_u be normalized cone surface measure: choose one of 2n faces with equal probability and draw the remaining n-1 coordinates uniformly on that face. For a cube this agrees with normalized surface measure. Its essential identity, obtained by partitioning the shell into face cones (ties have Lebesgue measure zero), is

    d( integral_{Q_u} g(z) dz )/du = e^u S_u g,
    integral_a^b e^s S_s(dz) ds = 1_{Q_b\Q_a}(z) dz.

The second equality is a measure identity for arbitrary Borel sets; the first holds at almost every u for locally integrable g, everywhere for continuous g.

## Construction and exact transitions

At any finite initial time a, start Y_a with law U_a. On (a,infinity), take an independent rate-one Poisson clock, with independent face/cone marks. At a clock time s replace the ENTIRE point Y by an independent S_s point. Between clock times keep the physical point fixed. There are almost surely finitely many jumps on a bounded time interval, since the count is Poisson with its finite interval length; no general nonexplosion criterion is needed.

The natural filtration includes the initial point and all clock/mark information through the present time, completed and right-continuously augmented. For a<=u<v, the no-jump event has probability e^{u-v}. The density of the last clock time s in (u,v] is e^{s-v}ds, regardless of any earlier clocks. The last mark erases the old point. Thus, for y in Q_u,

    K_{u,v}(y,dz) = e^{u-v} delta_y(dz)
                 + e^{-v} 1_{Q_v\Q_u}(z) dz.                  (S1)

The second term has mass 1-e^{u-v}; it is NOT an unnormalized jump probability inadvertently counted twice. Multiplication of the two kernels gives K_{u,v}K_{v,w}=K_{u,w}: the middle and outer annular densities join with the same density e^{-w}. Integrating (S1) against U_u yields exactly U_v. These identities also consistently define an entrance law on all finite intervals, but no infinite-time stochastic interchange is used here.

For a nonnegative L1 function f, Tonelli gives for almost every receiver x and each fixed u

    E f(x+Y_u) = A_u f(x).

The marginal formula itself holds as an extended integral for every x. On any finite time interval the joint receiver/time integrals are finite, since integral A_u f dx=||f||_1. For atomic measures, delta masses must NOT be evaluated as ordinary path payoffs. One can mollify and pass to fixed cube captures at boundary-null receivers; the full atomic maximal transfer remains the separate Round69 theorem. No cap-energy convergence follows just from these marginals.

## Generator and compensation

For a bounded continuous spatial test g, the right small-time generator at (u,y) is

    L_u g(y) = S_u g - g(y).                                  (S2)

Continuity of S_s g at u proves this from (S1). For bounded Borel tests the predictable compensation formula remains meaningful without claiming that every time has a classical pointwise derivative. With the Poisson random measure of times and base marks, the predictable integrand is g(Z_s(mark))-g(Y_{s-}), where Z_s maps a face/uniform base mark to S_s. On a finite interval and for bounded g it is integrable and square integrable. Subtracting its deterministic-intensity compensator gives a square-integrable martingale, first for simple predictable functions by independent increments, then by L2 approximation. Its predictable bracket is

    integral [ S_s(g^2)-2 g(Y_{s-}) S_s g+g(Y_{s-})^2 ] ds.

All expectation/integration exchanges in this statement are bounded on a finite interval. It is not the square of S_s g-Eg(Y_s); replacing the latter by the bracket loses conditional averaging. Setting g=1 gives zero generator. For coordinate tests localized to the bounded union of the cubes in a finite interval, S_s z_i=0 so L_s z_i=-z_i, consistent with mean zero and whole-point resets. The process has no physical deterministic drift between jumps, despite this compensator drift.

## Exact backward kernel

Under the marginal law U_v, the conditional law of Y_u given Y_v=z is, for almost every z in Q_v,

    R_{v,u}(z,dy) = delta_z(dy)        if z in Q_u,
                 = U_u(dy)            if z in Q_v\Q_u.        (S3)

Proof: the forward joint measure is

    e^{-v} 1_{Q_u}(y)dy delta_y(dz)
      + e^{-(u+v)}1_{Q_u}(y)1_{Q_v\Q_u}(z)dy dz.

Dividing by the U_v density gives (S3). Consequently for bounded Borel f,

    E[f(x+Y_u)|Y_v=z] = 1_{Q_u}(z) f(x+z)
                      +1_{Q_v\Q_u}(z) A_u f(x).             (S4)

This is a conditional expectation with a deterministic cube-membership branch. It is NOT the scalar A_u f(x) everywhere, and it does not make u->A_u f(x) a martingale. Reversing time produces inward-moving deterministic cube boundaries with resampling at their hitting times, rather than a rate-one Poisson clock conditional on the current point. The original receiver measure is still Lebesgue dx throughout.

## Cap-compatible one-step innovation and the unpaid global part

Let h>0, beta=e^{-h}, c_h=1-beta and let B_{u,h} be the average of f over Q_{u+h}\Q_u. Then exactly

    A_{u+h}=beta A_u+c_h B_{u,h},
    A_{u+h}-A_u=c_h(B_{u,h}-A_u).                            (S5)

On the ORIGINAL set G_H={sup_s A_s f<=H}, nonnegativity gives

    0<=B_{u,h}<=H/c_h.

This is a real cap bound obtained without transporting x or replacing dx by a source prior. It is only a one-step bound, not a global complexity budget. At h=1 the desired energy becomes

    (1-e^{-1})^2 integral_{G_H} integral_R |B_{u,1}-A_u|^2 du dx.

The required subpower constant is still unproved. Bounding the two terms separately destroys the long-range cancellation exposed by the finite-range counterexample in the companion note. The reset construction is a state/time dependent Markov kernel, not a translation-invariant convolution factorization of two cube kernels, so it does not contradict Round41's positive-garbling obstruction.

## Skills and verification

Current J01, J04 and I02 entrances were reread. They serve to check finite-rate construction, true filtration and compensation hypotheses; no unverified general projection, stochastic Fubini or exit-settlement theorem is imported. The probability arguments above directly prove the finite-interval identities.

`shell_reset_guard.py` has pilot, pressure and expanded exact Fraction checks for nested cube volumes, Chapman-Kolmogorov, reverse joint measures and shell cap algebra, through n=128. The tests are finite audits only. Source positions/ties and the genuine supremum are handled by the independent atomic numerical suite; these probability identities do not replace those checks.


---

# Round70: exact coordinate resets and the missing cap payment

The coordinate reset process exactly represents centered cube averages. This note derives its genuine transition law, generator, compensator and reversed transition. It also proves that paying its quadratic variation, or its expected squared path increment, cannot give the retained subpower indicator cap-energy budget. The obstruction already uses one cube indicator at the prescribed threshold and receivers in the ORIGINAL global good set. It does not disprove the desired squared-mean energy estimate. The surviving two-copy signed interaction is stated precisely and is not bounded here.

The goal remains the general centered cube weak upper bound of order sqrt(n) times a subpower factor. The Round69 global/local conditional returns are available, but their cap-energy input is unproved. This note supplies no unconditional weak upper bound and does not transfer receiver Lebesgue measure to a source prior.

## 1. Construction, filtration, and correct marginal

Write L=exp(t), u=nt, q=exp(1/n), and h=1/n. Fix a finite initial time a. Let Y_i(a) be independent uniform random variables on [-exp(a)/2,exp(a)/2]. Independently for each coordinate, use a rate-one Poisson clock marked by independent fair signs. At a jump time s of coordinate i, replace Y_i(s) by sign*exp(s)/2. Between jumps the physical coordinate Y_i is constant.

Use the completed right-continuous natural filtration generated by these initial variables and marked clocks. A coordinate's marked counting measure has deterministic compensator ds*(delta_{-1}+delta_{+1})/2. A finite interval has finitely many jumps almost surely: total count is Poisson with mean n times its length. No general nonexplosion theorem is being imported.

For t>a, the no-jump component has mass exp(a-t) and is uniform on the initial interval. The last jump at s in (a,t] has density exp(s-t) ds and a fair sign. The change of variable |y|=exp(s)/2 gives density exp(-t) on each outer half-interval. The survived initial component has the same density exp(-t) on the inner interval. Thus Y_i(t) is uniform on [-exp(t)/2,exp(t)/2]. Coordinates are independent because their clocks and initial variables are independent. For EVERY bounded Borel f, including arbitrary non-product inputs,

\[
 {\mathbb E}f(x+Y(t))=A_{\exp(t)}f(x).                    \tag{1}
\]

This is an auxiliary stochastic representation, not an intrinsic generator of the maximal operator and not a translation-invariant positive garbling from an earlier cube average.

The exact forward transition from side L to qL is coordinatewise
\[
 Y'_i=\begin{cases}
 Y_i,&\text{with probability }q^{-1},\\
 V_i,&\text{with probability }1-q^{-1},
 \end{cases}                                           \tag{2}
\]
where V_i is uniform on [-qL/2,-L/2] union [L/2,qL/2], independent of the old vector and all other coordinate transitions. This follows from the last-jump density, conditional on at least one jump. Formula (2) composes for arbitrary successive side ratios. It is not restricted to dyadic ratios. If an all-time process is desired, use independent marked Poisson clocks on the whole real line and define Y_i(t) from the last clock jump at or before t. That last jump exists almost surely, and its backward age has an Exp(1) law, giving the same uniform marginal. All martingale calculations below are nevertheless made only on finite time intervals.

## 2. Actual generator and compensation

For a bounded continuous physical-state test F(y), the small-time generator is the following; for bounded Borel tests the same expression is the compensator (extended-generator) kernel, without asserting a pointwise small-time limit at every t:
\[
 {\cal L}_tF(y)=\sum_{i=1}^n
 \left[\frac{F(y^{i,+}_t)+F(y^{i,-}_t)}2-F(y)\right],      \tag{3}
\]
where y^{i,sign}_t replaces coordinate i by sign*exp(t)/2. For the normalized state Z=exp(-t)Y, the generator on C^1 tests is
\[
 {\cal A}\phi(z)=-z\cdot\nabla\phi(z)+
 \sum_i\left[\frac{\phi(z^{i,+})+\phi(z^{i,-})}2-\phi(z)\right],
                                                               \tag{4}
\]
with replacements by +/-1/2. For a one-coordinate monomial z^k, this is c_k-(k+1)z^k, where c_k=0 for odd k and c_k=2^{-k} for even k. Its uniform stationary moment is c_k/(k+1). These are checks of the actual drift, not a reversible diffusion claim.

Set F_t=f(x+Y(t)). For bounded Borel f and finite [a,b], the predictable jump integrands are evaluated at Y(t-). The compensated Poisson sum is a square-integrable martingale:
\[
 M_t=F_t-F_a-\int_a^t b_s\,ds,\qquad
 b_s=\sum_i\left[\frac{f(x+Y^{i,+}(s-))+f(x+Y^{i,-}(s-))}2-F_{s-}\right].
                                                               \tag{5}
\]
Its predictable quadratic variation is
\[
 \langle M\rangle_t=\int_a^t\Gamma_s\,ds,\quad
 \Gamma_s=\sum_i\frac{(f(x+Y^{i,+}(s-))-F_{s-})^2+
                         (f(x+Y^{i,-}(s-))-F_{s-})^2}{2}. \tag{6}
\]
These statements follow directly by conditioning successive independent Poisson increments; bounded f and finite time ensure absolute and square integrability. The expressions are not asserted for an atomic measure evaluated as a pointwise function. For nonnegative unbounded L1 functions (1) remains valid by Tonelli at each fixed time, but the martingale/bracket assertions need their own integrability conditions.

For smooth f the derivative of its mean is E b_t. For a finite rectangle indicator it holds for almost every t and agrees with the derivative of the cube-intersection polynomial:
\[
 \frac{d}{dt}A_{\exp(t)}f
 =\sum_i\frac{\text{two normalized coordinate-face integrals}}2
       -nA_{\exp(t)}f.                                  \tag{7}
\]
A cap on this mean does not give F_t<=H, b_t<=H, or Gamma_t<=H^2. Killing the process when F_t>H changes the averages in (1).

## 3. Exact reversal and why it does not solve the cap problem

For s<t, condition on the terminal physical vector Y(t)=y under the uniform marginal. In one coordinate,
\[
 {\mathbb P}(Y_i(s)\in dz\mid Y_i(t)=y_i)=
 \begin{cases}
 \delta_{y_i}(dz),&|y_i|<\exp(s)/2,\\
 \operatorname{Unif}[-\exp(s)/2,\exp(s)/2](dz),
                         &|y_i|>\exp(s)/2 .
 \end{cases}                                             \tag{8}
\]
Boundary equality is a terminal-marginal null event. The coordinate conditional kernels multiply. Indeed a terminal point in the inner interval could only have survived with no intervening coordinate reset; an outer terminal point was produced by a later jump whose clock and sign are independent of the earlier state.

In stationary normalized coordinates, reversal therefore expands deterministically until a face is hit, and then resets uniformly inside the interval. After a uniform reset the next boundary-hitting time has an Exp(1) distribution, but the NEXT boundary hit is already determined by the currently observed state. This distinction is relative to the state-revealing filtration; the marginal exponential renewal law alone is not a compensator statement in that filtration. Relative to the reversed natural filtration, its clock is a predictable boundary event, not a fresh rate-one Poisson clock. The exponential marginal interarrival law does not justify substituting a Poisson compensator.

For any fixed earlier a, the genuine reverse-filtration Doob martingale is E[f(x+Y(a)) | reverse history down to s]; the Markov property reduces this to the kernel (8) applied to the payoff. Its unconditional expectation is A_exp(a)f, CONSTANT in s, rather than A_exp(s)f. Thus calling the current payoff f(x+Y(s)) a reverse martingale would be incorrect. Partial-coordinate averages in (8) can exceed the all-coordinate receiver cap. No martingale cap inequality follows from (8) alone.

## 4. A general two-copy formula and a disproved strong payment interface

Let delta=h=1/n. From the construction, the event J_t that ANY coordinate jumps in (t,t+h] has probability
\[
 c=1-\exp(-1).
\]
It is independent of the initial vector Y(t). The path increment Delta_t=F_{t+h}-F_t vanishes off J_t. Therefore, without any conditional independence assumption on f,
\[
 (A_{qL}f-A_Lf)^2
   =c^2\,{\mathbb E}[\Delta_t^{(1)}\Delta_t^{(2)}
                        \mid J_t^{(1)},J_t^{(2)}],        \tag{9}
\]
where the complete coordinate reset constructions 1 and 2 are independent. The product is signed. On a finite receiver/time window, bounded f justifies integration and Fubini, so (9) is an exact general representation of the energy.

By contrast, the common one-copy bound is
\[
 |{\mathbb E}\Delta_t|^2\le c\,{\mathbb E}\Delta_t^2.       \tag{10}
\]
A proposed sufficient interface that pays the right side through
\[
 \int_{\{Mf\le H\}}\int {\mathbb E}\Delta_t^2\,du\,dx
       \le C_n H\|f\|_1
                                                               \tag{P}
\]
is FALSE with a subpower C_n, even at the single indicator threshold required by Round69. The same is true of replacing the left side by the corresponding bracket payment. No factor involving atom count or minimum atom mass is needed for the counterexample; the source is one bounded cube indicator.

## 5. Exact indicator pressure on the ORIGINAL cap

Take n>=1, 0<rho<1, ell=rho^{1/n}, and
\[
 f=1_V,\quad V=[-\ell/2,\ell/2]^n,\quad W=|V|=\rho,\quad H=\rho.
\]
Use receivers X=[1,3/2]^n, of volume 2^{-n}, and initial sides L in [4,8]. Every x in X belongs to {Mf<=rho}. To see this for ALL scales, any nonzero capturing cube has L>=2(1-ell/2)>=1, so its average is at most W/L^n<=rho. Strict ell<1 makes the endpoint issue harmless.

For every such initial L, the entire small source cube is captured, giving A_Lf=W/L^n. Every coordinate reset during [log L,log L+1/n] has a replaced coordinate outside V: x_i+L'/2>ell/2 and x_i-L'/2<-ell/2 for L'>=4. Once a coordinate resets the indicator payoff becomes zero and cannot return before this interval ends. Consequently
\[
 \Delta_t=-F_t1_{J_t},\quad
 {\mathbb E}\Delta_t=-cW/L^n,\quad
 {\mathbb E}\Delta_t^2=cW/L^n.                            \tag{11}
\]
These formulas use the same path coupling that proves (1); they are not an abstract coefficient model.

With du=n dL/L, the exact payments on X and [4,8] are
\[
 \begin{split}
 P_n&=\int_X\int_4^8{\mathbb E}\Delta_t^2\,n\,dL/L\,dx
       =cW(8^{-n}-16^{-n}),\\
 E_n&=\int_X\int_4^8|A_{qL}f-A_Lf|^2\,n\,dL/L\,dx
       ={c^2W^2\over2}(32^{-n}-128^{-n}).                 \tag{12}
 \end{split}
\]
In this window every face payoff is zero, so Gamma_t=nF_t^2. The integrated bracket over PHYSICAL logside time dt is
\[
 Q_n=\int_X\int_{\log4}^{\log8}{\mathbb E}\Gamma_t\,dt\,dx
     =W(8^{-n}-16^{-n})=P_n/c.                           \tag{13}
\]
If writing the process in u, its compensator and bracket rates are divided by n; this is the same Q_n. Treating dt and du as identical would introduce a spurious factor n.

At the retained delta_n=(4n^2)^{-n},
\[
 {Q_n\over \rho W}
 =\left({n^2\over2}\right)^n(1-2^{-n}),\qquad
 {P_n\over \rho W}=c\left({n^2\over2}\right)^n(1-2^{-n}).
                                                               \tag{14}
\]
This rules out any subpower bracket or one-copy squared-increment payment at that threshold. Meanwhile
\[
 {E_n\over \rho W}={c^2\over2}(32^{-n}-128^{-n}),
\]
which is small. Thus the example refutes the proposed payment, not the actual cap-energy estimate. Even in fixed n=1, letting rho decrease shows the missing small-cap factor for indicator sources; for arbitrary densities, height rescaling gives the corresponding unbounded-source pressure.

Equation (9) survives: on this example, two independent rare occupancies contribute (W/L^n)^2, exactly the missing factor. A possible general route must retain this two-copy interaction (or an equivalent cancellation) before estimating spatial/time integrals. Establishing its signed aggregate O(rho|V|) payment on arbitrary finite rectangle unions remains open. Merely applying the receiver mean cap to each replica separately and paying one replica's path bracket does not do it.

## 6. Whole-point shell reset: an independently audited comparison

The parent [whole-point shell-reset note](/Users/zhengzhihao/Desktop/T/output/centered_cube_round070_20261011/shell_reset.md) independently proves a rate-one reset of the entire point to a uniform cone-surface draw in VOLUME time u. I read and independently audited its proof. Its exact kernel on y in Q_u is
\[
 K_{u,v}(y,dz)=e^{u-v}\delta_y(dz)
                +e^{-v}1_{Q_v\setminus Q_u}(z)\,dz.       \tag{15}
\]
The last-jump mixture, cube-shell volume normalization, Chapman--Kolmogorov composition, and uniform marginals are correct. Its backward kernel keeps z in Q_u and otherwise resets uniformly into Q_u. Unlike coordinate resets, a whole-point jump erases all earlier coordinates at once. The parent note gives the full construction, generator, compensation and reverse proof; they are not duplicated here.

As in Section3, the state-revealing reversed filtration knows its next boundary-crossing time, so its Poisson compensation cannot be inferred from exponential marginal holding times. Bounded-payoff compensation is valid on finite windows. Nonnegative L1 marginal representation follows by Tonelli. Atomic measures are not pointwise payoffs; no atomic martingale or cap-energy approximation follows from these kernels alone.

For one volume-time step, the probability of a whole-point reset is c=1-e^{-1}. Given a reset, the final point is uniform on the whole shell Q_{u+1} minus Q_u, independent of the old point. Thus for an indicator let
\[
 a=A_L1_V(x),\quad
 b={1\over |Q_{u+1}|-|Q_u|}
       \int_{x+(Q_{u+1}\setminus Q_u)}1_V,\quad
 a'=A_{qL}1_V=e^{-1}a+cb.
\]
The exact one-copy XOR probability is
\[
 {\mathbb E}\Delta^2=c(a+b-2ab),\qquad
 {\mathbb E}\Delta=c(b-a).                               \tag{16}
\]
In n=1 this coupling coincides with the coordinate-reset coupling. The whole-point reset supplies more explicit temporal correlations, but the squared mean still requires the signed difference b-a rather than its one-copy turnover.

## 7. The cap-local Cauchy repair is correct, but its natural payment fails

For ANY coupling of two indicator payoffs, put p_xor=P(Delta!=0). Since Delta^2=1_{Delta!=0},
\[
 |{\mathbb E}\Delta|^2\le p_{\rm xor}{\mathbb E}\Delta^2
 \le (A_L1_V+A_{qL}1_V){\mathbb E}\Delta^2
 \le2\rho{\mathbb E}\Delta^2                             \tag{17}
\]
on the ORIGINAL cap. This repairs the rare-event factor in the local pressure example of Section5.

It does not furnish a finite global payment. Even for one interval in n=1, the full-spatial XOR integral tends to 2c|V| as L tends to infinity. Indeed the no-reset contribution to the old/new overlap is e^{-1}|V|; given a reset the old and shell positions are independent, and their difference is within the fixed source diameter with probability O(1/L). The original bad set is bounded, and its XOR contribution is at most |bad|(|V|/L+|V|/(eL)), tending to zero. Therefore the all-time XOR integral on the ORIGINAL cap is infinite. Multiplication by the constant 2rho does not repair that divergence.

Retaining the finer factor A_L1_V+A_{qL}1_V avoids this coarse-scale infinity but has its own logN obstruction, proved next. This explicitly falsifies the candidate uniform payment
\[
 \int_{\{M1_V\le\rho\}}\int
       (A_L1_V+A_{qL}1_V){\mathbb E}\Delta^2\,du\,dx
       \le C_1\rho|V|                                  \tag{WP}
\]
for the exact n=1 reset coupling. It does NOT falsify the square of the signed mean.

Take P=16, rho=4/P=1/4, N>96 a multiple of four, and
\[
 V_N=\bigcup_{j=0}^{N-1}[jP-1/2,jP+1/2],\quad W=N,
\]
\[
 X_N=\bigcup_{j=N/4}^{3N/4-1}
              [jP+P/4,jP+3P/4],\qquad |X_N|=NP/4.
\]
These are finite unions of balanced binary intervals. The infinite periodic source of period P has discrepancy at most one on every interval: subtracting its mean 1/P gives a periodic primitive with oscillation at most one. The finite source is bounded above by it. If a receiver in X_N captures anything, then L>=P/2-1, so
\[
 A_L1_{V_N}\le1/P+1/L\le1/P+1/(P/2-1)\le4/P=\rho.
\]
This proves X_N is contained in the ORIGINAL all-scale cap.

For initial sides 4P<=L<=NP/24, both the L and eL centered intervals lie within the finite periodic region: use e<3 and the explicit central receiver endpoints. Periodic discrepancy then gives
\[
 3/(4P)\le a=A_L1_{V_N}\le5/(4P),\quad
 A_{eL}1_{V_N}\ge3/(4P).
\]
The annulus consists of two intervals, so its discrepancy is at most two. Since e-1>1,
\[
 1/(2P)\le b\le3/(2P).
\]
Both a and b are at most 1/2. Thus (16) gives
\[
 {\mathbb E}\Delta^2=c(a+b-2ab)\ge c(a+b)/2
                                      \ge3c/(8P).
\]
Consequently, remembering u=log L in n=1,
\[
 {1\over\rho W}\int_{X_N}\int_{4P}^{NP/24}
      (A_L1_{V_N}+A_{eL}1_{V_N}){\mathbb E}\Delta^2\,dL/L\,dx
 \ge {9c\over256}\log(N/96)\longrightarrow\infty.          \tag{18}
\]
This uses actual interval occupancy and the actual reset law. The repeated positive/negative turnover on a long mean plateau is costly even after multiplying by the receiver's actual average. Neither (17) nor the original good geometry alone pays it by source mass. The signed two-copy cancellation in (9) remains the unresolved ingredient.

## 8. Scope, current skills, and reproducibility

The only source-family use is falsification of (P), not a proposed general upper theorem. The exact process identities apply to arbitrary bounded Borel source functions; finite-window expectations and spatial integrals use bounded f on finite receiver sets. All-time positive payments can be defined by Tonelli, but no all-time signed Fubini assertion is made without integrability. A finite-source-atomic direct pointwise payoff is deliberately not asserted.

The current disk versions of I02, J01 and J04 SKILL.md, method, cube-interface and provenance were reread on 2026-10-11. Their roles are respectively filtration/projection scope, deriving the ACTUAL generator, and justified predictable compensation/finite-window Fubini. No external source theorem, generic optional projection, generic random Fubini theorem, martingale cap theorem, or state-dependent Poisson compensator was imported. These skills explicitly require the stated conditions; the finite-rate bounded-payoff compensation here is proved from the construction.

Entry SHA256:
- I02: cdf12aaf5336cc68f33dfe5a16b922932de4c5d0679c4d61f5ad68c3fecbbabe
- J01: f4865974260d5f9e0cea773f2cd7f23f16ad089e73bc2d704330dffe4e4414b2
- J04: 99ac118256ab02b75adb01ea1c9c16d74655b16b14dca24c57e80606f5c68954

The standard-library guard below is standalone. Exact Fraction checks cover multistage transition marginals on overlapping finite rectangle unions, reversed joint kernels, monomial semigroup/stationary moments, and the threshold-payment ratios. Finite-h generator checks use floating log and are diagnostics, not interval certificates. No Monte Carlo or numerical cap test is passed off as a general theorem.

Actual replay on 2026-10-11: PASS. The additional plateau replay passes 96256 actual all-scale cap-endpoint checks at 45 receivers and 540 exact shell/XOR inequalities, for N=128,256,512,1024,4096 and rational q=2,5/2,271828/100000,3. These rational q values audit the analytic bounds uniformly used for 2<=q<=3; they are not a transcendental interval certificate for q=e. The exact checks also comprise 128 multistage finite-union marginal cases, 400 reversed joint interval cases, 108 moment/semigroup/stationarity cases, 67 pressure dimensions (n=1..64,128,256,1024), 67 actual cap-geometry checks, and 41856 individual actual reset-coordinate escape checks. The 63 floating finite-h diagnostics at h_side=2^{-8},2^{-12},2^{-16} have maximum errors 0.003110821764662819, 0.0001952568845160485, and 0.000012206813945314643. They are convergence diagnostics only. The exact bracket-cost ratios without the fixed factor c have log10 values about 3.5843 at n=4, 12.0395 at n=8, 33.7154 at n=16, and 5856.8396 at n=1024; these displayed logarithms are floating summaries of exact rational ratios.

```python
from fractions import Fraction as F
from itertools import product
from math import log, log10
import json, random

def intersection(a,b):
    return max(F(0),min(a[1],b[1])-max(a[0],b[0]))
def uniform_interval_prob(interval,L):
    return intersection(interval,(-L/2,L/2))/L
def outer_prob(interval,L,q):
    return (intersection(interval,(-q*L/2,-L/2))+
            intersection(interval,(L/2,q*L/2)))/((q-1)*L)
def components(ratios):
    # (weight, symmetric interval/annulus inner radius, outer radius)
    out=[(F(1),F(0),F(1,2))]
    L=F(1)
    for q in ratios:
        out=[(w/q,a,b) for w,a,b in out]
        out.append((1-1/q,L/2,q*L/2))
        L*=q
    return out,L
def component_prob(interval,cs):
    ans=F(0)
    for w,a,b in cs:
        if a==0:
            pp=intersection(interval,(-b,b))/(2*b)
        else:
            pp=(intersection(interval,(-b,-a))+
                intersection(interval,(a,b)))/(2*(b-a))
        ans+=w*pp
    return ans
def union_prob(rects,coordinate_prob):
    n=len(rects[0]); ans=F(0)
    for mask in range(1,1<<len(rects)):
        selected=[r for j,r in enumerate(rects) if (mask>>j)&1]
        cell=[(max(r[i][0] for r in selected),
               min(r[i][1] for r in selected)) for i in range(n)]
        if any(a>=b for a,b in cell):
            continue
        prob=F(1)
        for interval in cell:
            prob*=coordinate_prob(interval)
        ans+=prob if mask.bit_count()%2 else -prob
    return ans
def moment(q,z,k):
    ck=F(0) if k%2 else F(1,2**k)
    factor=q**(-(k+1))
    return factor*z**k+(1-factor)*ck/F(k+1)

def periodic_primitive(t,P):
    z=t+F(1,2)
    k=z//P
    r=z-k*P
    return F(k)+min(r,F(1))
def finite_periodic_mass(left,right,N,P):
    left=max(left,-F(1,2))
    right=min(right,(N-1)*P+F(1,2))
    if left>=right:
        return F(0)
    return periodic_primitive(right,P)-periodic_primitive(left,P)
def plateau_guards():
    P=F(16); rho=F(1,4)
    counts={"actual_global_cap_endpoint":0,"plateau_shell":0}
    for N in (128,256,512,1024,4096):
        for j in (N//4,N//2,3*N//4-1):
            for fraction in (F(1,4),F(1,2),F(3,4)):
                x=j*P+fraction*P
                radii={abs(x-(k*P+sign*F(1,2)))
                       for k in range(N) for sign in (-1,1)}
                # Average is monotone between capture endpoints, so checking
                # all positive endpoint radii proves this receiver's full cap.
                for r in radii:
                    if r==0:
                        continue
                    a=finite_periodic_mass(x-r,x+r,N,P)/(2*r)
                    assert a<=rho
                    counts["actual_global_cap_endpoint"]+=1
                for L in (4*P,(4*P+N*P/24)/2,N*P/24):
                    a=finite_periodic_mass(x-L/2,x+L/2,N,P)/L
                    assert F(3,4)/P<=a<=F(5,4)/P
                    for q in (F(2),F(5,2),F(271828,100000),F(3)):
                        new=finite_periodic_mass(x-q*L/2,x+q*L/2,N,P)/(q*L)
                        b=(q*new-a)/(q-1)
                        c=1-1/q
                        xor=c*(a+b-2*a*b)
                        assert F(1,2)/P<=b<=F(3,2)/P
                        assert new>=F(3,4)/P
                        assert xor>=3*c/(8*P)
                        assert (a+new)*xor>=9*c/(16*P**2)
                        counts["plateau_shell"]+=1
    return counts

def reset_guards():
    rng=random.Random(700602)
    counts={"multistage_union":0,"reverse_joint":0,"moment":0,
            "pressure":0,"cap_geometry":0,"face_escape":0,"generator_diagnostic":0}
    for n in (1,2,4,8):
        for trial in range(8):
            rects=[]
            for unused in range(4):
                r=[]
                for i in range(n):
                    a=F(rng.randrange(-12,9),8)
                    b=a+F(rng.randrange(1,13),8)
                    r.append((a,b))
                rects.append(r)
            ratios=[]
            for q in (F(3,2),F(4,3),F(5,4),F(7,5)):
                ratios.append(q)
                cs,L=components(ratios)
                assert sum(w for w,a,b in cs)==1
                assert union_prob(rects,lambda I:component_prob(I,cs))==\
                       union_prob(rects,lambda I:uniform_interval_prob(I,L))
                counts["multistage_union"]+=1
    for q in (F(3,2),F(2),F(11,10),F(271828,100000)):
        for j in range(100):
            a=F(rng.randrange(-8,8),8)
            b=a+F(rng.randrange(1,8),8)
            c=F(rng.randrange(-12,12),8)
            d=c+F(rng.randrange(1,12),8)
            A=(a,b); B=(c,d)
            common=(max(a,c),min(b,d))
            forward=(uniform_interval_prob(common,F(1))/q+
                     (1-1/q)*uniform_interval_prob(A,F(1))*outer_prob(B,F(1),q))
            inner_joint=intersection(common,(-F(1,2),F(1,2)))/q
            outside=(intersection(B,(-q/2,-F(1,2)))+
                     intersection(B,(F(1,2),q/2)))/q
            reverse=inner_joint+outside*uniform_interval_prob(A,F(1))
            assert forward==reverse
            counts["reverse_joint"]+=1
    for k in range(9):
        ck=F(0) if k%2 else F(1,2**k)
        stationary=ck/F(k+1)
        for q1,q2 in ((F(3,2),F(7,5)),(F(2),F(11,10))):
            for z in (F(-1,2),F(-1,3),F(0),F(1,4),F(1,2)):
                a2=q2**(-(k+1))
                composed=a2*moment(q1,z,k)+(1-a2)*stationary
                assert composed==moment(q1*q2,z,k)
                counts["moment"]+=1
            # Average the exact moment transition over stationary initial z.
            assert q1**(-(k+1))*stationary+(1-q1**(-(k+1)))*stationary==stationary
            counts["moment"]+=1
    max_errors=[]
    for power in (8,12,16):
        q=1+F(1,2**power)
        worst=0.0
        for k in range(7):
            ck=F(0) if k%2 else F(1,2**k)
            for z in (F(-2,5),F(0),F(1,3)):
                diagnostic=float(moment(q,z,k)-z**k)/log(float(q))
                actual=float(ck-(k+1)*z**k)
                err=abs(diagnostic-actual)
                assert err<40*float(q-1)
                worst=max(worst,err)
                counts["generator_diagnostic"]+=1
        max_errors.append(worst)
    assert max_errors[2]<max_errors[1]<max_errors[0]
    pressure=[]
    for n in tuple(range(1,65))+(128,256,1024):
        rho=F(1,(4*n*n)**n)
        ell=F(1,4*n*n)
        assert ell**n==rho
        assert 2*(1-ell/2)>1  # every nonzero capture is at a side larger than one
        counts["cap_geometry"]+=1
        # Actual initial and reset cubes, with arbitrary receiver-coordinate choices.
        for L in (F(4),F(5),F(8)):
            for unused in range(2):
                x=[F(1)+F(rng.randrange(0,9),16) for i in range(n)]
                captured=F(1)
                for xi in x:
                    captured*=intersection((-ell/2,ell/2),(xi-L/2,xi+L/2))
                    for sign in (-1,1):
                        # Even the smallest allowed reset radius misses the source.
                        assert not (-ell/2<=xi+sign*L/2<=ell/2)
                        counts["face_escape"]+=1
                assert captured==rho
        bracket_coefficient=F(1,8**n)-F(1,16**n)
        ratio=bracket_coefficient/rho
        exact=F(n*n,2)**n*(1-F(1,2**n))
        assert ratio==exact
        assert ratio>=F(n*n,2)**n/2
        # Exact coefficient of squared-mean energy divided by rho*W, before c^2.
        mean_ratio=(F(1,32**n)-F(1,128**n))/2
        assert 0<mean_ratio<1
        counts["pressure"]+=1
        if n in (1,2,4,8,16,64,128,256,1024):
            pressure.append({"n":n,"log10_bracket_over_rhoW":
                            log10(ratio.numerator)-log10(ratio.denominator)})
    return {"passed":True,"checks":counts,"plateau_checks":plateau_guards(),
            "generator_max_errors":max_errors,
            "pressure_without_c":pressure}
if __name__=="__main__":
    print(json.dumps(reset_guards(),sort_keys=True,separators=(",",":")))
```


---

# Round 70: signed finite-range truncation has an unpaid logarithmic tail

The general source-uniform cap-energy estimate remains unproved. This note attempts a signed scale-localization strategy and rules out its simplest missing-error claim: retaining every temporal Gram interaction up to any fixed volume ratio R, including all its signs, does not leave a source-uniform affordable error. The obstruction uses finite positive atomic sources, the original global good set, and genuine Lebesgue receiver volume. It does not refute the full signed energy, a subpower dimensional cap-energy bound, or the desired weak upper bound.

The actual general goal is unchanged. Round 69 proves conditionally that a global atomic estimate E_G<=K_n H W implies C_n<=C[1+sqrt(n log(n+2)K_n)]. Here neither K_n=n^{o(1)} nor a replacement sufficient general upper estimate is proved.

## 1. Exact signed range decomposition for every finite source

Let mu=sum_i p_i delta_{y_i}, W=sum_i p_i, p_i>0. At a receiver outside the finitely many source sites put v_i=(2||x-y_i||_infinity)^n. Merge equal physical volumes into t_1<...<t_m with masses P_j, and let F(t)=sum_{t_j<=t}P_j. The original cap is G_H={F(t)<=Ht for all t>0}. Set q=e^{-1}, c=1-q, and kappa=q+q^{-1}-2=c^2/q>0.

For s<=t the exact temporal Gram kernel is

    g(s,t)=1/2[(2-q)/t^2-q/max(s,qt)^2].                 (1)

It is the Gram of d_s(v)=[q 1_{v>=qs}-1_{v>=s}]/v in L2(dv/v). Thus the full point energy is the finite quadratic sum

    e(x)=sum_{j,k} P_j P_k g(t_j,t_k)>=0.

For a fixed R>=e, retain only pairs whose volume ratio is at most R:

    e_R(x)=sum_{j,k: max(t_j,t_k)<=R min(t_j,t_k)}
                           P_j P_k g(t_j,t_k).

The far kernel is exactly -kappa/(2t^2). Consequently

    e_R=e+C_R,
    C_R=kappa sum_j P_j F((t_j/R)^-)/t_j^2>=0.          (2)

The open prefix is essential: pairs at ratio exactly R are retained. Physical same-volume ties remain merged, and diagonal terms are always retained. The truncated kernel is not asserted to be positive semidefinite for arbitrary signed coefficients; (2) proves e_R>=0 for this positive source.

All terms in (2) are integrable on G_H for each fixed finite source. Indeed G_H gives t_j>=P_j/H, hence each individual source volume is bounded below by p_i/H. On bounded receiver regions all finite pair terms are bounded; outside a sufficiently large cube they are O(W^2||x||_infinity^{-2n}), which is integrable. This finite integrability is not a bound independent of atom count or positions.

## 2. A true-cap grid obstruction for every fixed interaction range

Fix R>=e. Let N be divisible by four and N>=32R, and take the actual one-dimensional source

    mu_N=N^{-1} sum_{j=1}^N delta_{(j-1/2)/N},
    W=1, H=4.

Define the receiver set

    S_N=[1/4,3/4] minus union_j
              ((j-1/2)/N-1/(4N),(j-1/2)/N+1/(4N)).

It has Lebesgue measure exactly 1/4. Every x in S_N is at distance at least 1/(4N) from every source site. An interval of length t contains at most Nt+1 grid sites. Before volume 1/(2N) there is no capture; afterwards F_x(t)/t<=1+1/(Nt)<=3. Thus S_N is contained in the original G_4, with a strict margin. No atom-to-density approximation or altered cap is used.

Put

    L_N=1+floor(log_2(N/(32R))),
    a_l=(8R/N)2^l,                 0<=l<L_N.

Then 2a_l<=1/2. At every x in S_N, the cube intervals of volumes up to 1/2 stay inside [0,1]. The number of physical source arrivals in [a_l,2a_l) is at least Na_l-2>=Na_l/2. For every such arrival t_i, an inner cube of volume t_i/(2R) contains at least Nt_i/(2R)-1>=Nt_i/(4R) sites. Therefore

    F_x((t_i/R)^-)>=F_x(t_i/(2R))>=t_i/(4R).

The bins are disjoint. Formula (2) now gives, pointwise on S_N,

    C_R(x)>=kappa/(4RN) sum_l sum_{a_l<=t_i<2a_l} 1/t_i
           >=kappa L_N/(16R).                            (3)

Since e_R>=C_R and |S_N|=1/4,

    integral_{G_4} e_R dx /(H W)
       >= integral_{S_N} C_R dx/4
       >=kappa L_N/(256R).                               (4)

For each finite dimension-only range R(n)>=e, set n=1 and hold R(1) fixed, then let N grow. The right side diverges. Thus no uniform finite-range signed Gram estimate can hold without retaining or paying its far-prefix correction. This is stronger than discarding all negative pairs: every bounded-ratio positive AND negative interaction is retained in e_R. In particular a finite-range Schur/Bellman approximation cannot justify an O(HW) truncation error solely from the original cap.

The same proof works for a general time shift -log(q), 0<q<1, with R>=q^{-1} and kappa=q+q^{-1}-2. The scientific target here uses q=e^{-1}; rational q values below are only finite algebra guards.

## 3. Pooling the negative prefix before bounding

The exact weak repair is to retain C_R in (2), not to claim it is a bounded separate error. It preserves one common source: each larger arrival is paired with all earlier captured source mass in its open prefix. There is no receiver-specific resplitting or extra source copy.

A temporal product integration by parts is available, including all ratio ties. Set P(t)=F(t)F(t/R). Its atomic product rule is

    dP(t)=F((t/R)^-)dF(t)+F(t)d[F(t/R)].

The second factor is evaluated on the RIGHT after a common jump. Consequently

    C_R/kappa + R^{-2} sum_j P_j F(Rt_j)/t_j^2
        =2 integral_0^infinity F(t)F(t/R)t^{-3} dt.        (5)

Proof. Integrate t^{-2}dP. The product divided by t^2 vanishes at zero, since the receiver has a positive first arrival, and at infinity, since P<=W^2. In the second jump sum substitute t=Rt_j. Standard finite Stieltjes summation then gives (5). This proof does not differentiate the spatial good-set indicator or invoke any boundary regularity for G_H.

For each finite source the terms are finite on G_H, so (5) can also be integrated there. But it has a bulk correlation on the right and a nonnegative advanced charge on the left. The true-cap grid lower bound (3) proves that the negative-prefix magnitude itself cannot be turned into an O(HW) separate fee. There is no paid cap-boundary term in this temporal identity. Bounding its two positive sides separately loses precisely the cancellation the actual energy needs.

Thus the genuine residual source-uniform estimate is the JOINT signed bound

    integral_{G_H} [e_R(x)-kappa sum_j
             P_j F_x((t_j/R)^-)/t_j^2] dx
          <=K_n H W.                                    (6)

Equation (6) is equivalent to the original cap-energy estimate, not new progress toward its numerical constant. The new result is the quantified obstruction to paying either finite-range localization or its negative tail separately. An integration-by-parts or spatial Bellman strategy must preserve the joint cancellation in (6) and prove its own boundary/defect budget. No such budget is proved here.

## 4. Attempted positive refinement and its precise limitation

There is an exact positive refinement identity for integer physical scales. If P_L denotes averaging over a cube of full side L, then

    P_{2L} f(x)=2^{-n} sum_{epsilon in {-1,1}^n}
                             P_L f(x+(L/2)epsilon).

The translated child cubes tile the parent cube, up to boundaries. This supplies a real Markov refinement after introducing the corner choice; the killed positive-martingale lemma from Round 60 is applicable to that genuine random-path process. It does not directly supply the static-receiver signed difference P_{2L}f(x)-P_Lf(x) on the original centered cap.

Even a one-step pointwise comparison has an exponential loss. For a single atom p delta_0 choose S=L^n>p/H and a receiver with p/H<v_x<S, away from the child boundaries. Then x is globally good, P_L mu(x)=p/S, and P_{2L}mu(x)=p/(2^nS). Exactly one randomly chosen translated child captures the atom. There is no killing at either level, and its martingale-increment second moment is

    (2^{-n}-2^{-2n})(p/S)^2.

The static squared difference is (1-2^{-n})^2(p/S)^2. Their ratio is exactly 2^n-1. This falsifies a dimension-subpower pointwise comparison of the static difference to this positive-refinement variance. It does not falsify an integrated comparison: the one-atom spatial volume can compensate the pointwise ratio, and no aggregate lower bound is inferred. The refinement attempt therefore leaves a genuinely spatial common-source comparison, while the scale-truncation attempt leaves the signed far-prefix cancellation (6).

## 5. Current skills and audit scope

F05/N04/L03 canonical SKILL.md entries, current methods and cube interfaces were reread during this round; after the user's latest reload instruction their entries and key interfaces were reread again and hashes recomputed. Current entrance SHA256 values are:

    F05 9b61d3e4cb62f20394285d8b071cace85c44260f56329fdd5ec2b11066a52dc9
    N04 0ec449afa32e815eae515b391f2c613e2c2f084496d3e8b3ce1d682da5e9a107
    L03 0e2d41f62f831a87047487abb1bbcd7c74243cfa8e16cd6d702fe829124f5a9c

No changed applicability condition was found. F05's absolute Schur test is not a signed tail estimate; no external Schur multiplier theorem is imported. N04 requires a uniform cumulative error budget before any infinite-scale conclusion; (4) disproves the proposed finite-range error budget. L03 distinguishes exact Fraction checks from nearest-rounded Decimal precision agreement. No unverified interval API or external mathematical theorem is used in this note.

The guard below tests: exact event-vs-Gram algebra, ratio ties and pooled integration by parts; true finite-grid caps and quantitative annular counts; the one-step refinement variance; and actual q=e^{-1} computations at two precisions. The listed finite arrival cases are physically realized in dimension one by source sites y_i=v_i/2 and receiver zero. Their total mass is one and minimum volume is at least one, so this receiver belongs to G_1. The guard does not test arbitrary receiver space or prove (6).

## 6. Reproducible staged guard

```python
from fractions import Fraction as F
from decimal import Decimal, localcontext
from bisect import bisect_left, bisect_right
from itertools import product

counts=dict(pair=0,tail=0,product=0,grid=0,bins=0,refinement=0,decimal=0)

def grouped(volumes,weights):
    data={}
    for v,p in zip(volumes,weights): data[v]=data.get(v,F(0))+p
    ts=sorted(data); ps=[data[t] for t in ts]
    prefix=[F(0)]
    for p in ps: prefix.append(prefix[-1]+p)
    return ts,ps,prefix

def gram(s,t,q):
    s,t=min(s,t),max(s,t)
    return ((2-q)/t**2-q/max(s,q*t)**2)/2

def event_energy(ts,ps,q):
    events={}
    for t,p in zip(ts,ps):
        events[q*t]=events.get(q*t,F(0))+q*p
        events[t]=events.get(t,F(0))-p
    coefficient=F(0); total=F(0); ev=sorted(events)
    for i,a in enumerate(ev):
        coefficient+=events[a]
        invnext=0 if i+1==len(ev) else 1/ev[i+1]**2
        total+=coefficient**2*(1/a**2-invnext)/2
    return total

cases=[([F(1),F(1),F(3),F(9)],[F(1,4)]*4),
       ([F(1),F(4),F(16)],[F(1,7),F(2,7),F(4,7)]),
       ([F(2),F(3),F(5),F(8)],[F(1,10),F(2,10),F(3,10),F(4,10)])]
for q in (F(7,20),F(3,8),F(2,5)):
    kappa=q+1/q-2
    for vv,ww in cases:
        ts,ps,prefix=grouped(vv,ww)
        full=sum((p*r*gram(s,t,q) for s,p in zip(ts,ps)
                  for t,r in zip(ts,ps)),F(0))
        assert full==event_energy(ts,ps,q) and full>=0
        counts['pair']+=1
        for R in (F(3),F(4),F(8)):
            assert R>=1/q
            near=sum((p*r*gram(s,t,q) for s,p in zip(ts,ps)
                      for t,r in zip(ts,ps) if max(s,t)<=R*min(s,t)),F(0))
            charge=sum((p*prefix[bisect_left(ts,t/R)]/t**2
                        for t,p in zip(ts,ps)),F(0))
            assert near-full==kappa*charge and near>=0
            counts['tail']+=1
            advance=sum((p*prefix[bisect_right(ts,R*t)]/t**2
                         for t,p in zip(ts,ps)),F(0))/R**2
            events=sorted(set(ts+[R*t for t in ts])); rhs=F(0)
            for i,a in enumerate(events):
                prod=prefix[bisect_right(ts,a)]*prefix[bisect_right(ts,a/R)]
                invnext=0 if i+1==len(events) else 1/events[i+1]**2
                rhs+=prod*(1/a**2-invnext)
            assert charge+advance==rhs
            counts['product']+=1

for R in (F(3),F(4),F(8),F(16)):
    for N in (128,256,512,1024):
        if N<32*R: continue
        ys=[F(2*j+1,2*N) for j in range(N)]
        L=0; a=8*R/N
        while 2*a<=F(1,2): L+=1; a*=2
        for j in range(N//4,3*N//4+1,max(1,N//32)):
            for offset in (F(-1,4),F(0),F(1,4)):
                x=F(j,N)+offset/N
                if not F(1,4)<=x<=F(3,4): continue
                vv=sorted(2*abs(x-y) for y in ys)
                assert min(vv)>=F(1,2*N)
                assert max(F(bisect_right(vv,t),N)/t for t in set(vv))<=3
                charge=sum((F(bisect_left(vv,t/R),N*N)/t**2 for t in vv),F(0))
                assert charge>=F(L,16)/R
                counts['grid']+=1
                a=8*R/N
                for ell in range(L):
                    outer=[t for t in vv if a<=t<2*a]
                    assert len(outer)>=N*a-2 and len(outer)>=N*a/2
                    for t in outer:
                        assert F(bisect_right(vv,t/(2*R)),N)>=t/(4*R)
                    counts['bins']+=1; a*=2

for n in (1,2,4,8,16,32):
    probability=F(1,2**n)
    variance=probability-probability**2
    static=(1-probability)**2
    assert static/variance==2**n-1
    # Physical source: p=H=1, L^n=2^n, x=(3/4,...,3/4).
    x=(F(3,4),)*n; L=F(2)
    v=(2*max(map(abs,x)))**n
    assert 1<v<L**n
    capture_count=1
    for coordinate in x:
        capture_count*=sum(abs(coordinate+L*sign/2)<=L/2 for sign in (-1,1))
    assert capture_count==1
    counts['refinement']+=1

def decimal_test(precision):
    with localcontext() as ctx:
        ctx.prec=precision; q=(-Decimal(1)).exp(); kappa=q+1/q-2
        output=[]
        def dec(f): return Decimal(f.numerator)/Decimal(f.denominator)
        for vv,ww in cases:
            ts,ps,prefix=grouped(vv,ww); ts=list(map(dec,ts)); ps=list(map(dec,ps))
            full=sum((p*r*gram(s,t,q) for s,p in zip(ts,ps)
                      for t,r in zip(ts,ps)),Decimal(0))
            events={}
            for t,p in zip(ts,ps):
                events[q*t]=events.get(q*t,Decimal(0))+q*p
                events[t]=events.get(t,Decimal(0))-p
            ev=sorted(events); co=Decimal(0); energy=Decimal(0)
            for i,a in enumerate(ev):
                co+=events[a]
                invnext=0 if i+1==len(ev) else 1/ev[i+1]**2
                energy+=co**2*(1/a**2-invnext)/2
            assert abs(full-energy)<Decimal(10)**(-precision+8)
            for R in map(Decimal,(3,4,8)):
                near=sum((p*r*gram(s,t,q) for s,p in zip(ts,ps)
                          for t,r in zip(ts,ps) if max(s,t)<=R*min(s,t)),Decimal(0))
                charge=sum((p*sum((r for s,r in zip(ts,ps) if R*s<t),Decimal(0))/t**2
                            for t,p in zip(ts,ps)),Decimal(0))
                assert abs(near-full-kappa*charge)<Decimal(10)**(-precision+8)
                output.append((full,near,kappa*charge))
        return output

coarse=decimal_test(80); fine=decimal_test(140)
with localcontext() as ctx:
    ctx.prec=160
    discrepancy=max(abs(a-b)/(1+abs(b)) for row,col in zip(coarse,fine)
                    for a,b in zip(row,col))
    assert discrepancy<Decimal('1e-65')
counts['decimal']=len(fine)
print('PASS signed range guard',counts)
print('nearest-rounded 80/140 maximum normalized discrepancy',discrepancy)
```

The guard passed: 9 exact pair/event cases, 27 signed-tail identities,
27 pooled product identities, 637 true-grid-cap receiver cases, 1,421
annular-bin checks, 6 refinement dimensions, and 9 Decimal pair/tail
cases. The maximum normalized 80/140 discrepancy was less than
7.857e-81. This reports nearest-rounded precision agreement, not an
interval error enclosure. Finite checks support the displayed finite
algebra; the analytic lower bound (4) proves the unboundedness.


### Standalone whole-point guard

```python
"""Exact rational checks for whole-point expanding-cube shell reset.
Run with Python 3, no third-party packages; checks do not prove general identities.
"""
from fractions import Fraction as F
from itertools import product
import json, random

def vol(box):
    ans=F(1)
    for a,b in box: ans*=max(F(0),b-a)
    return ans

def inter(*boxes):
    return tuple((max(b[i][0] for b in boxes),min(b[i][1] for b in boxes)) for i in range(len(boxes[0])))

def cube(n,side): return tuple((-side/2,side/2) for _ in range(n))
def inside(p,b): return all(a<=x<=z for x,(a,z) in zip(p,b))

def checks(seed,dims,trials):
    rng=random.Random(seed); counts=dict(marginal=0,chapman_kolmogorov=0,reverse_joint=0,cap_shell=0)
    for n in dims:
      for _ in range(trials):
        sides=sorted(set(F(rng.randrange(1,17),4) for _ in range(10)))[:3]
        assert len(sides)==3
        qs=[cube(n,s) for s in sides]; vs=[vol(q) for q in qs]
        A=tuple(sorted((F(rng.randrange(-12,13),4),F(rng.randrange(-12,13),4))) for _ in range(n))
        B=tuple(sorted((F(rng.randrange(-12,13),4),F(rng.randrange(-12,13),4))) for _ in range(n))
        # Add high-dimensional nonzero capture controls, avoiding all-zero tests.
        if n>4:
          A=tuple((-sides[0]/3,sides[0]/2) for _ in range(n))
          B=tuple((-sides[2]/2,sides[1]/3) for _ in range(n))
        a,b,c=[vol(inter(B,q)) for q in qs]
        assert (vs[0]/vs[1])*(a/vs[0])+(b-a)/vs[1]==b/vs[1]
        counts['marginal']+=1
        for point in [tuple(F(0) for _ in range(n)),tuple(sides[0]/3 for _ in range(n))]:
          indicator=F(int(inside(point,B)))
          ku_v=vs[0]/vs[1]*indicator+(b-a)/vs[1]
          composed=vs[1]/vs[2]*ku_v+(c-b)/vs[2]
          direct=vs[0]/vs[2]*indicator+(c-a)/vs[2]
          assert composed==direct
          counts['chapman_kolmogorov']+=1
        ac=vol(inter(A,qs[0])); abc=vol(inter(A,B,qs[0]))
        forward=abc/vs[1]+ac*(b-a)/(vs[0]*vs[1])
        reverse=(abc+(b-a)*ac/vs[0])/vs[1]
        assert forward==reverse
        counts['reverse_joint']+=1
        # Genuine nonnegative source mass captured in nested cubes; H is actual two-scale max.
        mass0=F(rng.randrange(0,21),20); shell=F(rng.randrange(0,21),20)
        H=max(mass0/vs[0],(mass0+shell)/vs[1]); beta=vs[0]/vs[1]
        shavg=shell/(vs[1]-vs[0]); assert shavg<=H/(1-beta)
        assert (mass0+shell)/vs[1]-mass0/vs[0]==(1-beta)*(shavg-mass0/vs[0])
        counts['cap_shell']+=1
    return counts

def main():
    stages=[('pilot',700101,[1,2,3,4],16),('pressure',700102,[1,2,4,8,16],24),('expanded',700103,[1,8,32,64,128],20)]
    out={'proof_scope':'Finite exact Fraction identities only. No uniform cap energy estimate.', 'stages':[]}
    for label,seed,dims,trials in stages:out['stages'].append(dict(stage=label,seed=seed,dimensions=dims,counts=checks(seed,dims,trials)))
    print(json.dumps(out,sort_keys=True,indent=2))
if __name__=='__main__':main()
```


---

# Round70: adversarial search of actual global cap energy

The optimized search values do not establish growth of the general cap-energy constant. The four-dimensional chain reached 0.81231 on its fixed search sample, but its two independent held-out samples give 0.76153 with combined sample SE 0.00624; the initial control gives 0.75771 with SE 0.00579. The one-dimensional candidate does retain a modest improvement, from 0.69804 to 0.72412 on independent receivers. Its source has 13 distinct sites after allowed collisions, versus 16 initially. The enlarged finite tests show neither a monotone dimension trend nor a counterexample to a dimension-only budget. They also cannot establish that budget.

This round uses positive finite atomic sources, actual complete-batch cube maxima, signed full-time energy, and full-space Lebesgue integration. It does not optimize an uncapped or positive-arrival proxy. No exponent or asymptotic order is fitted, and a large cap-energy value is not interpreted as a weak-type counterexample.

## Objective, exact events, and full-space proposal

For a positive source μ=Σ p_i δ_(y_i), W=Σp_i, let v_i(x)=(2||x−y_i||∞)^n and F_x(v)=Σ_(v_i≤v)p_i. The target is

E/(HW) = (HW)^−1 ∫_{Mμ(x)≤H} ∫_0^∞ [e^−1 F_x(ev)−F_x(v)]² dv/v³ dx.

The true M is the maximum of cumulative mass divided by volume over all complete physical-arrival batches. Source duplicates are merged before any computation. For a fixed receiver the signed numerator changes only at v_i/e and v_i. On an interval [l,r), coefficient c gives the exact time integral c²(l^−2−r^−2)/2; r=∞ is included. Incoming and current integer cumulative masses are computed separately, rather than summing nearly cancelling signed floating updates. Log distances and `expm1` are used for interval factors. Every source is positive throughout the search; the weights are never substituted with a signed or zero-mean source.

Write V=W/H, a_i=p_i/W and τ_i=v_i/V. The proposal chooses a source center with probability a_i, then chooses global radial scale V or individual radial scale a_iV with probability 1/2 each. At scale b it chooses volume bU or b/U with probability 1/2 each, and chooses a uniform cube-cone face, sign and free face coordinates. U=0 is replaced by the smallest positive machine float. The normalized radial density is 1/(2b) below b and b/(2v²) above b; its two integrals are both 1/2. Cube volume and normalized cone angle satisfy dx=dv dσ, so no missing surface factor occurs.

The **complete** spatial density at every receiver, including all centers and both scales, is q(x)=(H/W)q_core(x), with

q_core = (1/4)Σ_i a_i min(1,τ_i^−2) + (1/4)Σ_i min(1,(a_i/τ_i)²).

The receiver score is the true capped point-energy divided by H²q_core. No selected-component denominator is used. All space, all cone angles, and the radial infinity tail have proposal support; there is no spatial truncation. Full support does not prevent rare directions or rare large scores from dominating an integral.

On the actual gate τ_i≥a_i, so q_core≥Σ_i a_i²/τ_i² /4. A single atomic time kernel has squared norm (1−e^−1)a_i²/τ_i². Hilbert-space Cauchy therefore yields the finite ideal score envelope

0≤score≤4(1−e^−1)N,

where N is the number of distinct positive sites after merging. The source-diagonal statistic and infinity-tail statistic are diagnostics; the principal objective retains all signed cross terms. The tail after the last physical arrival is exactly (1−e^−1)²W²/(2v_max²).

## Registered stages and optimization limitations

The final deterministic program contains these stages:

| Stage | Evaluations/rows | Receivers each | Draws |
|---|---:|---:|---:|
| Pilot bank | 60 | 512 | 30,720 |
| Four CRN mutation chains, including four initial evaluations | 100 | 1,024 | 102,400 |
| Independent initial/candidate comparisons | 16 | 8,192 | 131,072 |
| Independent expanded configurations | 36 | 2,048 | 73,728 |
| Actual full Boolean-vertex counterpressure | 8 | 4,096 | 32,768 |
| One- and two-atom calibrations | 4 | 4,096 | 16,384 |
| Total | 224 evaluations | — | 387,072 |

There are 124 receiver rows in `rows` and 100 evaluations in `search`; their counts must not be added as if both were ordinary held-out rows. All final counts include only the final registered replay. Two preliminary pilot runs preceded this replay. The first omitted the threshold-root bank and motivated its addition; those preliminary search numbers are not pooled into final evidence.

Pilot strata are (n, requested N)=(1,16),(4,16),(8,32),(16,64). Each tests binary, hierarchical, correlated, unequal-cloud and multicluster sources at log2(1/H)/n∈{1,3/2,2}. The geometry seed is fixed; the same receiver seed across the three thresholds gives a common-random-number comparison. A winner is selected within each stratum by mean minus 0.5 sample SE. This is a heuristic score, not a confidence bound.

Each chain then evaluates its initial configuration and 24 trial mutations on one fixed 1,024-receiver seed. The six operations cycle through one-site dyadic perturbation, coordinate stretch, half-source shift, strictly positive integer mass reallocation, all-site dyadic perturbation, and a log-threshold-root step. Coordinate operations preserve masses; mass operations quantize positive relative masses to integers and change one mass, then normalize W=1. H remains strictly positive and is recorded as its exact machine rational. Collisions are permitted and merged. These operations parameterize a finite feasible search family; they do not cover all positive sources, and the greedy noisy search is neither a certified local nor a global optimizer. The archived traces save each proposal's digest, operation, score and acceptance; selected and initial sources are explicit.

The four candidates are locked before independent final seeds are used. Final receiver seeds are pairwise distinct and are disjoint from all pilot and search seeds. Two final seeds per configuration are combined by averaging their means; the quoted SE is sqrt(SE₁²+SE₂²)/2. Held-out evaluation removes receiver selection bias for a fixed candidate, but selecting these source families does not turn their maximum into a general-class conclusion.

The enlarged matrix independently varies n∈{2,8,32} and requested N∈{8,32,64}, with fresh binary and hierarchical geometries. Binary thresholds use root 3/2 and hierarchical thresholds root 1. These are new fixed configurations, not higher-dimensional optimizer solutions. In n=2, requested 64 binary labels merge to 61 sites; the actual count is used in all score bounds. The pilot n=1 binary source has 15 sites after merging. Full Boolean sources at n=4,8 separately have N=2^n; that branch is not counted as independent n-versus-N variation.

## Held-out results

All values below are normalized E/(HW); ± denotes combined sample SE, not a certified interval.

| Search stratum | Initial control | Optimized candidate | Interpretation |
|---|---:|---:|---|
| n=1, initial N=16 | 0.69804 ± 0.00703 | 0.72412 ± 0.00722 | Unequal cloud; candidate has 13 distinct sites and changed positive masses/H |
| n=4, N=16 | 0.75771 ± 0.00579 | 0.76153 ± 0.00624 | Full binary source deformed; H=1/64 and equal masses retained |
| n=8, N=32 | 0.68406 ± 0.00707 | 0.69730 ± 0.00717 | No mutation accepted: source and H are identical; difference is sampling noise |
| n=16, N=64 | 0.62409 ± 0.00743 | 0.63225 ± 0.00744 | Modified sites/masses; H changes from 2^−16 to 2^−22 |

The corresponding fixed-sample search means for the selected candidates are 0.73620, 0.81231, 0.72489 and 0.59170. In particular, the n=4 search improvement is much larger than its independent improvement. Reporting 0.81231 as a reliable integrated candidate value would be incorrect.

Representative expanded comparisons:

| n | Requested N | Binary | Hierarchical |
|---:|---:|---:|---:|
| 2 | 8 | 0.59084 ± 0.01147 | 0.41209 ± 0.00757 |
| 2 | 64 | 0.66331 ± 0.01656 | 0.49017 ± 0.01127 |
| 8 | 8 | 0.66816 ± 0.01159 | 0.54506 ± 0.01021 |
| 8 | 32 | 0.73202 ± 0.01447 | 0.38204 ± 0.00963 |
| 8 | 64 | 0.71393 ± 0.01474 | 0.34805 ± 0.01093 |
| 32 | 8 | 0.63304 ± 0.01116 | 0.62758 ± 0.01127 |
| 32 | 64 | 0.63824 ± 0.01496 | 0.39748 ± 0.01125 |

The actual full Boolean source gives 0.74465±0.00923 at n=4,H=1/128, versus 0.52618±0.00845 at H=1/256. At n=8 the corresponding H=1/8192 and 1/65536 values are 0.78896±0.01134 and 0.66116±0.01497. This finite threshold sensitivity motivates searching actual H jointly with geometry; it does not identify an asymptotic law.

The source-diagonal diagnostic can differ substantially from the whole energy: for the n=1 candidate it is 0.14214 while whole energy is 0.72412; the infinity tail alone is 0.18414. For the n=4 candidate, diagonal is 0.58380 while whole energy is 0.76153. Removing signed cross terms or the spatial/time tail would change the object being tested.

The one-atom analytic reference is 1−e^−1=0.6321205588 for every dimension, positive mass and H. At n=1 and 16 the estimates are 0.64076±0.00988 and 0.63058±0.00988. The two-atom source (.5δ_−.5+.5δ_.5),H=1 has the analytic companion's exact reference 0.6623899395; its two seed estimates are 0.67156±0.00955 and 0.67077±0.00957. The reference's strict improvement over one atom is analytic, not established by the sign of a Monte Carlo difference.

## Numerical audits and evidence boundary

The engine from Round69 retains exact binary-coordinate reconstruction for near tied distances. Physical arrivals use entire equal-distance groups, including ties on open receiver sets. Across ordinary rows, 177,526 receivers invoke this reconstruction; none required correction of a falsely merged distinct log group. No ordinary receiver activated the near-e Decimal event-order fallback or near-cap exact fallback in this replay. Their absence does not certify every floating comparison.

For every nonpilot row, the two largest energy scores are retained with exact machine receiver coordinates and proposal-component metadata: 128 actual extremes in total. The closest accepted and rejected gate points are also retained: 128 exact gate checks. Seven independent controls include three genuine common-face ties and four small-source high-dimensional points. All retained gate classifications agree with exact rational complete-batch maxima. The minimum ordinary-row absolute log(M/H) margin is 4.54853×10^−6.

At each retained energy point, the script constructs rational outward enclosures with integer endpoints on the 10^−100 grid. Arithmetic uses integer floor/ceiling; e is bounded by its 101-term rational Taylor sum and explicit geometric remainder. Exact rational input volumes and masses are used, event ordering is separated by the enclosures, all coefficient squares and inverse-volume factors are rounded outward, and the infinity interval is included. All 135 finite-point event orders pass. The actual-extreme relative enclosure widths are at most 2.561×10^−91; a tiny-energy far control has the wider relative width 1.435×10^−41.

Maximum float discrepancies against these finite point enclosures are 9.005×10^−15 for energy and 8.424×10^−15 for complete proposal density. Independently, 80/120-digit Decimal event sums differ by at most 1.398×10^−79 relatively. Pair-Gram checks are run for 56 actual extremes with N≤16 and all seven controls; their worst 80-digit event/Gram relative discrepancy is 6.365×10^−79. Decimal precision agreement alone is not an interval certificate. The narrow rational intervals enclose finite-point mathematical energies; the ordinary floating values typically differ at machine precision and are not asserted to lie inside those very narrow intervals.

These guards do **not** enclose the receiver-space integral, certify the whole floating sampler, or certify every gate on every ordinary draw. They test selected finite points with the exact machine source and receiver geometry. No generic outward-rounded library is assumed.

The final row SEs range from 0.00815 to 0.02389. The largest observed score is 15.6836 for n=8,N=256 vertices, against the much larger proved finite envelope 4(1−e^−1)256≈647.29. Per-row ideal IID Hoeffding 95% radii range from 0.05366 to 13.73574 and are usually too wide to settle the question. They use the true mathematical score envelope, are not simultaneous bounds over source selection, and do not absorb machine arithmetic or pseudorandom-sampling errors. Sample SE and nonnegative-score ESS are descriptive diagnostics; neither rules out an unobserved rare-angle contribution.

Current L02/L03/L04 entrances and their methods/interfaces were reread. Their relevant conditions are a faithful feasible source parameterization, independent candidate reconstruction/evaluation, distinction between finite search and general conclusions, and explicitly outward-rounded finite arithmetic when asserting a certificate. No external theorem is inferred from a skill or solver name. No optimization package was installed; this is a seeded greedy finite search, not a mathematical-programming optimality certificate.

## Replay and frozen files

Run without `--pilot`:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /Users/zhengzhihao/Desktop/T/output/centered_cube_round070_20261011/adversarial_cap_probe.py
```

The standalone program writes adjacent `adversarial_cap_results.json`. `--pilot` deliberately writes only the pilot bank/search output and overwrites that path; it is not the final replay command. No previous-round imports, external data paths or installs are required. The environment was Python 3.12.14 with NumPy 2.3.5. The completed final run exited 0 in 31.6627 seconds; runtime is printed but excluded from serialized JSON. No live execution session remains.

Frozen script SHA256: `7e7a55356220da96c0494d0790a2d9b9d76e678fe3df3692220e29dbf776a857`.

Frozen data SHA256: `a17a1d39c166d6856dd0c37cd8718deabdf5b88b0df72738210d51653176ae40`.

The script and data are frozen. The general source-independent cap estimate required by the upper-bound route remains unproved.
