# R500 独立终审

FINAL PASS（限定范围）。同 selector 双来源中心包络、真实 posterior cell-square 总预算及其完整祖先极近对应用成立；同一边界祖先域中的 far-inside 部分另有 SκW 价格。规定参数下这些实际子域费用为参数依赖的 O(√n log(n+2))W。中距 inside 与非近 outside 的联合价仍未证，**不是整个一般弱型上界闭合**。

独立 PRE 先核 pair 核、端点、真实分母与换序位置，再审最终白名单七件。未发现必要修补项。

1. **真实中心包络。** 兼容中心交体积为 ∏(s−d_i)₊，同一可测半径 selector 的 base+layercake 给 U₂≤S[p_b+n∫p_s ds/s]≤SA_n exp(−||x−z||₁/b)。a=b 非零 base、x=z、单坐标到 b 的零体积端点均正确。积分变量是接收 Lebesgue 中心，不给任意集中 μ 添加薄层密度帽，也不逐来源重选半径。
2. **新增来源平方价。** π_A(C)>θ 用完整 matching 强制 m_A<μ(C)/θ，从而接收中心处于真实膨胀盒。tq_A≤Sλ 及 R_A≥a 给 Sr(1+h/a)ⁿ μ(C)/θ 尾界；零格单列。对所有格先用2θ层饼再Tonelli，只总收一次 W。全局均匀平移的同格概率为乘积，L1近对上≥1−d/h；不使用坐标独立。取h=2d、d_n=a loglog(n+e)/(2n)，严格得极近全pair价4SrΦ_max log(n+e)W。不是固定比例空间尺度的近对定理。
3. **原完整祖先的适用位置。** 其同父双来源形式保 π_B(dx)π_B(dz)、z的head门及实际 V_xG；V_xG≤Φ_max 来自保原祖先核的 V_x1≤1。因此近对收费不要求 z∈Q_A。far-inside 先插入 z∈Q_A，再用 νhat(dA)/m_A=t(A)R_A^(−n)dA ds 的精确消去，才可调用U₂。保B,z的原head总量≤κTW，得SκΦ_max A_n exp(−D)W，D₀=log(Φ_max A_n)给SκW。外部z或人工w不能直接套该双捕获界。
4. **完整正分拆与阶数。** 在同一原boundary域先near，再inside且同时满足> d_n、≥bD₀；补集为中距inside与非近outside。bD₀≤d_n 时中距为空，严格/非严格边界无重复或遗漏。deep/head/empty与本轮near、far费用的主稿回代正确；用完整祖先near上界支配boundary近部分不重复计费。实际 T=ceil(max原三项)同时给上下界，Φ_max=O(√n)、κ=O(log(n+2))，故已付子域阶数来自一般参数不等式，不是高维样本外推。常数保r,S,τ,ε_g依赖；任意额外放大T不能沿用同一K价格。n=1的近对公式有效；其完整I沿R497的Φ_max KW帽处理，固定参数下L有界，无未展开的一维外部调用。

**独立实际复现。** 指定 Python `-I` 临时隔离运行 geometry、proof 嵌入代码及 numeric.py：geometry3、proof57、numeric136，共196项报告核验单位，stdout与冻结replay一致；不是196个连续模型。numeric JSON只去compute_index.seconds后逐字段一致，规范SHA256为 `e4bf80e156481bc7c569322d5d4df4500972f760a7d042461e57131c2d44e2bd`。两组native小场分别核selector pair积分及非均匀完整来源的posterior平方积分；未认证原high-rank/history。低维exact/SymPy积分、Arb160/384位检查及12个解析参数例范围清楚；区间含零只作已证解析恒等式的相容核验，不独立证明等式。numeric的旧near措辞仅其文件范围，主稿已明确极近由proof另付，剩余是中距/外部。

原τX、R495非rank收据、deep/empty、入口倍率及全尺度等未付槽全部保留；本分拆与R498 signed谱接口为备选，不重复抵扣信用。没有声明任一已付子域占固定比例，亦没有将raw核赋予旧成功low-Gram历史。真正尚未完成的是剩余两域的同权联合来源预算。

## 最终输入绑定

- `r500_main.md`: `30fe52d63ad93a171b1f1f03986946fd2a6f62d18588eae9760ea17e12278c56`
- `r500_geometry.md`: `b188ed54542a1d974241aa6078150ad81130a154d96f17bbe20cfd1179b55192`
- `r500_proof.md`: `0a85220a1f74b6dc32c7a90fc11802b13938a73585eb8ef7c6ba89fe2cad6e16`
- `r500_numeric.md`: `5d01d5c59eb87bfd3b0f923cae2760e546bf31a5f33db816a98eeb9f1105ea0f`
- `r500_numeric.py`: `70912dadd1d5343af2e156d66cf442b16063b0d4105892dc720c60cfa92f481c`
- `r500_numeric.json`: `75ee200e6a68b04c9d201fe9e0959dffcb22596c3f905aa7c46ec6c760872312`
- `r500_replay.json`: `e31ec13e3e98c35ed3a7cfe2cfc22ea0440516400e57772981f1d5b9c64e4f9d`
