from pathlib import Path
from fractions import Fraction as F
import json,sys,platform,time
import sympy as sp
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=384;start=time.perf_counter();checks=0

def ck(x):
 global checks
 assert x
 checks+=1

def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator

def ev(x):
 x=sp.sympify(x)
 if x.is_Rational:return ar(F(int(x.p),int(x.q)))
 if x.is_Add:return sum((ev(z) for z in x.args),arb(0))
 if x.is_Mul:
  out=arb(1)
  for z in x.args:out*=ev(z)
  return out
 if x.func==sp.log:return ev(x.args[0]).log()
 if x.is_Pow and x.exp.is_Integer:return ev(x.base)**int(x.exp)
 raise ValueError(x)
def rq(x):return sp.Rational(x.numerator,x.denominator)
def pp(di,side):
 v=F(1)
 for x in di:v*=max(F(0),1-x/side)
 return v
z,s=sp.symbols('z s',positive=True)
profiles=[]
for b,d in [(F(1),F(1,2)),(F(3,2),F(3,2)),(F(2),F(3,2))]:profiles.append(('initial_endpoint',F(1),b,[d]))
for b in (F(1),F(3,2),F(2)):
 profiles.append(('pressure_balanced',F(1),b,[F(3,4)*b]*2))
 profiles.append(('pressure_sparse',F(1),b,[F(3,2)*b,F(0)]))
profiles.extend([('expanded_balanced',F(1),F(2),[F(1,2)]*3),('expanded_sparse',F(1),F(2),[F(3,2),F(0),F(0)]),('zero_spread',F(1),F(3,2),[F(0),F(0)])])
records=[]
for label,a,b,di in profiles:
 n=len(di);D=sum(di);lo=max([a]+di);base=pp(di,b);integral=sp.Integer(0)
 if lo<b:
  poly=sp.Poly(sp.prod(1-rq(x)*z for x in di),z)
  for (k,),coef in poly.terms():
   integral+=coef*(sp.log(rq(b/lo)) if k==0 else (rq(lo)**(-k)-rq(b)**(-k))/k)
  independent=sp.integrate(sp.prod(1-rq(x)/s for x in di)/s,(s,rq(lo),rq(b)))
  ck(sp.simplify(sp.expand_log(integral-independent,force=True))==0)
 else:ck(base==0 or a==b)
 J=sp.simplify(rq(base)+n*integral);An=1+n*ar(b/a).log();bound=An*(-ar(D/b)).exp();value=ev(J)
 ck(value.is_finite());ck(bound.is_finite());ck(value>=0)
 if D==0:ck((bound-value).contains(0))
 else:ck(value<bound)
 if a==b:ck(sp.simplify(J-rq(base))==0)
 if max(di)>=b:ck(J==0)
 records.append(dict(label=label,n=n,a=str(a),b=str(b),coordinate_spread=list(map(str,di)),L1_distance=str(D),dimensionless_distance=str(D/b),positivepart_integral_start=str(lo),integral_empty=lo>=b,p_b=str(base),integral_exact=str(sp.simplify(integral)),J_exact=str(J),J_Arb=str(value),A_n=str(An),exponential_upper=str(bound),ratio_to_upper=str(value/bound)))
# Same total L1 spread, different geometry: balanced products dominate sparse ones here.
for b in ('1','3/2','2'):
 bal=next(r for r in records if r['label']=='pressure_balanced' and r['b']==b)
 sparse=next(r for r in records if r['label']=='pressure_sparse' and r['b']==b)
 ck(bal['L1_distance']==sparse['L1_distance']);ck(ev(sp.sympify(bal['J_exact']))>ev(sp.sympify(sparse['J_exact'])))
bal=next(r for r in records if r['label']=='expanded_balanced');sparse=next(r for r in records if r['label']=='expanded_sparse')
ck(bal['L1_distance']==sparse['L1_distance']);ck(ev(sp.sympify(bal['J_exact']))>ev(sp.sympify(sparse['J_exact'])))
# General algebra of the distance threshold; actual R495 parameter values only.
Phi,An,Sk=sp.symbols('Phi An Sk',positive=True)
ck(sp.simplify(Sk*Phi*An*sp.exp(-sp.log(Phi*An))-Sk)==0)
parameters=[]
for idx,(r,S,tau,eps) in enumerate([(1,1,F(1),F(1,4)),(3,1,F(1,4),F(1,16)),(1,2,F(2),F(1,16)),(3,2,F(1,2),F(1,4))]):
 P=F(r*S);H=F(S)/tau;Cg=512*P*H+4*P+S
 for nn in (2,256,10**12):
  L=ar(r).log()+nn*arb(2).log();root=(ar(16*P*Cg/eps)*(L+1)).sqrt().ceil().unique_fmpz();ck(root is not None)
  T=max(int(4096*P*H),(6*Cg/eps).__ceil__(),int(root))
  ck(ar(T*T)>=ar(16*P*Cg/eps)*(L+1))
  kappa=8*ar(F(T)/(256*P*H)).log();phi=(ar(P)/T).exp()*(1+ar(P)*L/T);an=1+nn*arb(2).log()
  threshold=(phi*an).log();ck(threshold>0)
  fee=S*kappa*phi*an*(-threshold).exp();target=S*kappa
  ck(fee.is_finite());ck((fee-target).contains(0))
  parameters.append(dict(profile=idx,n=nn,r=r,S=S,tau=str(tau),eps=str(eps),b_over_a='2',L=str(L),T=T,kappa=str(kappa),Phi_max=str(phi),A_n=str(an),distance_D_over_b=str(threshold),farinside_coefficient=str(fee),S_kappa=str(target)))
result=dict(scope='Exact two-point same-selector center envelope and scalar farinside coefficient only. No random f, actual history/cube flow, or outside-source contribution certification.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r500_numeric.py',seconds=time.perf_counter()-start),checks=checks,exact_lowdim_cases=len(records),analytic_coefficient_cases=len(parameters),formulas=dict(p='p_s=prod_i(1-di/s)_+',J='p_b+n integral_a^b p_s ds/s',envelope='J<=(1+n log(b/a))*exp(-sum(di)/b)',threshold='d0=log(Phi_max*A_n),S*kappa*Phi_max*A_n*exp(-d0)=S*kappa',scope='This ancestor far-pair payment applies only to inside z in QA using the actual posterior/head interface; no outside contribution is covered.'),records=records,parameters=parameters,decision='The positivepart endpoint and balanced/sparse tests confirm implementation. The selected distance threshold cancels both parent-depth and volume prefactors in the farinside scalar fee, leaving S*kappa W; nearinside/outside and original flow qualification remain separate.',errors='Exact Fraction/SymPy lowdim integrals with independent symbolic integral;384-bit Arb bounds and coefficient identities. General envelope follows factor inequality1-u<=exp(-u),not inference from12cases. No Monte Carlo or geometric scan.')
(ROOT/'r500_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact/Arb assertions;12 lowdim envelope cases,12 analytic farinside coefficients;no flow certification')
