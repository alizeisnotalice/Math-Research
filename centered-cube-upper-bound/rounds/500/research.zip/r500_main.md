# 第500轮：同选择器双来源包络与近远配对费用

日期：2026-10-21。状态：新增一般原积分子域预算；完整一般弱型上界仍未闭合。本轮不编译PDF。

## 1. 冻结合同与来源

继承R495–499的max-only原标量核与真实来源合同，不把R486的自然配置链、R483父链和本核视为同律。用户新给的《第486轮后联合估计攻坚建议》已读；其中逐代能量与短质量窗的建议不自动提供本核上的累计费用。保留其“同参考、一次来源预算、累计付款而非单步小概率”的约束，不把其待证B1–B2记为成果。

令 $\mu=f\,dx$, $f\ge0$, $W=\mu(\mathbb R^n)<\infty$；零流单列。固定 $a\le R_A\le b\le2a$，$q\le q_A\le\lambda$，$r=\lambda/q\ge1$，$m_A=\mu(Q_A)=q_AR_A^n$。每个中心使用同一个可测选择器 $R_A$。真实中心测度为 $\nu=tq_A\,dA|_{t\ge\tau}$，$0<\tau\le S$, $t\le S$；附加均匀mark后的测度为 $\widehat\nu$。所有相等质量按mark全序，不能假定质量严格下降。来源 $\pi_A=1_{Q_A}\mu/m_A$。

记来源秩 $v_x$、阈值 $K=\kappa T$；$b_R(B)=\pi_B\{v_z(B)<K\}$。继承原max-only核 $K_0$、$G=\sum_{j\ge0}(K_0^*)^j1$。定义
\[
c=rS,\quad L=\log r+n\log(b/a),\quad
\Phi_{\max}=e^{c/T}(1+cL/T),\qquad G\le\Phi_{\max}.
\]
原入口 $R_\tau=I+E_{\rm empty}$，$I=\int Gb_R\,d\widehat\nu=H_{\rm head}+I_{\rm anc}$，$H_{\rm head}\le KW$，$E_{\rm empty}\le C_{\rm empty}W$。R497已付深中心项 $C_{\rm deep}W$，余为边界祖先积分。取 $n\ge2$, $\zeta=1-n^{-1/2}$，$\chi_\partial(A,x)=1_{2\|A-x\|_\infty>\zeta R_A}$：
\[
 I_\partial=\frac1T\int\widehat\nu(dB)\pi_B(dx)\pi_B(dz)
 1_{v_z(B)<K}\int_{A\succ B}\frac{G(A)c_A(x)}{m_A}
 \chi_\partial(A,x)1_{v_x(A)\ge K}
 e^{-(v_x(A)-v_x(B))/T}\widehat\nu(dA),\qquad c_A(x)=1_{Q_A}(x).
\]
所有以下限制施加在这个同一积分上；不更换实际第二来源z，不删除来源质量分母，不替换原历史的成功门。本轮使用max-only核的已有合法支配，不能将旧successful lowGram门额外免费移植进来。n=1沿用R497的完整界 $I\le\Phi_{\max}KW$，此时L有固定参数上界，故费用并入固定常数；本轮近对引理本身也对n=1有效。

## 2. 来源格子平方预算：支付极近对

对边长h的固定来源格子C，$0<\theta<1$，若 $\pi_A(C)>\theta$，则 $m_A<\mu(C)/\theta$，中心须在C的扩张中，且 $R_A<(\mu(C)/(\theta q))^{1/n}$。非空事件时该上界至少a。真实中心密度 $tq_A\le S\lambda$ 给
\[
\nu\{\pi_A(C)>\theta\}\le \frac{Sr}{\theta}(1+h/a)^n\mu(C).
\]
零质量格的事件为空。对同一共同格子划分先作层蛋糕积分 $\int_0^1 2\theta\,d\theta$，再Tonelli：
\[
\sum_C\int\pi_A(C)^2\nu(dA)\le2Sr(1+h/a)^n W.
\]
这里是一次总来源W，不是每个格子收一次W。对一个共同均匀平移网格，碰撞概率为 $\prod_i(1-|x_i-z_i|/h)_+\ge1-\|x-z\|_1/h$。故 $d<h$ 时
\[
\int\nu(dB)\pi_B(dx)\pi_B(dz)1_{\|x-z\|_1\le d}
\le\frac{2Sr(1+h/a)^n}{1-d/h}W.
\]
对真实祖先算子 $V_xG\le\Phi_{\max}V_x1\le\Phi_{\max}$，取h=2d得到完整祖先近对子积分
\[
I_{\rm anc,near}(d)\le4Sr\Phi_{\max}(1+2d/a)^nW.
\]
该式不要求 $z\in Q_A$，因此同时支付内外极近对。取
\[
d_n=\frac{a\log\log(n+e)}{2n}>0,\qquad
C_{\rm near}=4Sr\Phi_{\max}\log(n+e),
\]
由 $(1+u/n)^n\le e^u$ 有 $I_{\rm anc,near}(d_n)\le C_{\rm near}W$。不能把此式无价推广到d与a可比；那样体积放大仍指数增长。完整证明和连续中心算例在proof稿。

## 3. 双来源共同中心包络：支付远内部对

对固定真实来源x,z，令 $d_i=|x_i-z_i|$，$p_s=\prod_i(1-d_i/s)_+$，$A_n=1+n\log(b/a)$。同一选择器的兼容中心体积是 $\prod_i(s-d_i)_+$，层蛋糕给
\[
U_2(x,z):=\int_E t(A)R_A^{-n}c_A(x)c_A(z)\,dA
\le S\left[p_b+n\int_a^b p_s\frac{ds}{s}\right]
\le SA_n e^{-\|x-z\|_1/b}.
\]
保留a=b时的基项；若任一 $d_i\ge b$，兼容中心零体积。这个体积只作用于真实勒贝格中心，并非任意集中来源的密度帽。

在原 $I_\partial$ 中先限制 $z\in Q_A$ 和 $\|x-z\|_1\ge bD$。此时 $\widehat\nu(dA)/m_A=t(A)R_A^{-n}dA\,ds$；正上界中放宽次序、秩、边界、void，保B,z原head，得到
\[
I_{\partial,\mathrm{in,far}}(D)
\le S\kappa\Phi_{\max}A_n e^{-D}W.
\]
取 $D_0=\log(\Phi_{\max}A_n)\ge0$ 即得 $S\kappa W$。外部z没有 $c_A(z)$，不能用R498引入的人工w替代z套此式；w依赖A,B且没有原head。这是明确适用边界。

## 4. 同一积分的互斥完整账

按以下四个集合划分原边界祖先域：

1. $\|x-z\|_1\le d_n$，不分内外；费用 $C_{\rm near}W$。
2. $z\in Q_A$，$\|x-z\|_1>d_n$ 且 $\|x-z\|_1\ge bD_0$；费用 $S\kappa W$。
3. $z\in Q_A$，$d_n<\|x-z\|_1<bD_0$；记 $I_{\rm middle,in}$，未付。
4. $z\notin Q_A$，$\|x-z\|_1>d_n$；记 $I_{\rm nonnear,out}$，未付。

若 $bD_0\le d_n$，第三集合为空，第二集合仍按两条件定义，不遗漏边界。由此
\[
\boxed{R_\tau\le (K+C_{\rm deep}+C_{\rm empty}+C_{\rm near}+S\kappa)W
 +I_{\rm middle,in}+I_{\rm nonnear,out}.}
\]
深中心与边界分开，near只在边界上计入一次；用完整祖先near上界支配它不会重复收负信用。本账是R498有符号谱表达的替代组织，不能再叠加同一信用。

## 5. 维数阶数由一般不等式而非参数样本确定

固定r,S,τ及 $\varepsilon_g>0$，沿R495实际参数选取
\[
H_0=S/\tau,\quad C_g=512cH_0+4c+S,\quad
T=\left\lceil\max\{4096cH_0,6C_g/\varepsilon_g,
\sqrt{16cC_g(L+1)/\varepsilon_g}\}\right\rceil,
\quad\kappa=8\log\frac{T}{256cH_0}.
\]
令 $C_3=16cC_g/\varepsilon_g$，$T_{\min}=4096cH_0$，$C_T=\max(4096cH_0,6C_g/\varepsilon_g,\sqrt{C_3})+1$，则
\[
\sqrt{C_3(L+1)}\le T\le C_T\sqrt{L+1},\qquad
L+1\le(1+\log r+\log2)n.
\]
所以 $\Phi_{\max}\le e^{c/T_{\min}}[1+c\sqrt{L+1}/\sqrt{C_3}]=O(\sqrt n)$，$\kappa=O(\log(n+2))$，$K=O(\sqrt n\log(n+2))$。新near费用与farinside费用合计 $O(\sqrt n\log(n+2))W$；继承deep及empty按同一实际T选取也已有根阶费用。不能对任意无上界的大T声称同一K价格。常数可依赖上述固定参数，不能依赖输入、质量带总指数或n。

剩余两项尚无 $\varepsilon X+C\sqrt n\log^A(n+2)W$ 的联合估计。本轮没有新的吸收项，不能宣布完整Rτ闭合。后续重点仍是同选择器、真实双来源和累计权下的联合几何，而非继续细分但不给总价。

## 6. 母账与文献边界

返回原入口仍有外乘数 $64(128/119)/(1-32\delta_{\rm old}-16\eta_{\rm old})$；局部ε须除此外乘数后分配，与其他吸收项的总和一起核验。τX、初始、删除跳跃、未来被删来源、宽距离、低强度、极端比例和全尺度拼接未被本轮自动支付。R495非rank费用的εgRτ已知估计与本轮子域预算不能替代这些槽。

有限历史去重核对了R439共同平移格子、R252固定尺度平方质量、R433指数网格Jensen：它们不等于这里的任意真实中心posterior平方尾界。此核对不是对500轮全部历史作新颖性保证。未引用未读外部定理；工具仅使用已明示的初等层蛋糕、Tonelli、共同平移与既有核合同。

## 7. 实际复现与证据层级

已在本机独立环境 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 运行 `/tmp/replay_r500.py`，以 `-I` 隔离重放geometry/proof嵌入代码与numeric.py；结果一致，JSON仅忽略动态compute_index.seconds。Python3.12.14、SymPy1.14.0、python-flint0.9.0。使用L03技能的证据区分要求；安装技能本身不认证新命题。

共196项报告核验单位：geometry3、proof57、numeric136；不是196个连续模型。geometry的同选择器二维连续中心算例实际值1/2，包络2log2。proof的一维连续中心六段精确积分为 $-6+\log(2097152\sqrt6/6561)$，约0.6630722170280015；39项有理检查、12项Arb160位检查覆盖n=1,2,9,64,1024,10^6。numeric对12个低维包络算例及12个实际参数组合（含n=10^12）作精确/Arb384检查，包括a=b、端点零、平衡/稀疏位移和D0系数。详见原代码和JSON的精确输入。

numeric文中的“nearinside未证”仅指该数值文件不核验near预算：本轮proof另已付极近全pair；未付的是中距inside及非近outside。一般命题由上文解析证明认证，有限计算不认证原hard流、全部历史或最终上界。区间含零只支持符号恒等式的数值相容，不是单独严格等式证明。初步探索、既有端点/集中来源压力检查及扩大维数参数复核均留在三个原稿的可复现代码中。
