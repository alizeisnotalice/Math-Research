# R500：近来源对的真实质量集中收据及适用尺度

保持同一实际单值边长选择器 \(a\le R_A\le b\le2a\)，
\(m_A=\mu(Q_A)=q_AR_A^n\)，\(q\le q_A\le\lambda\)，
\(r=\lambda/q\)，\(\nu(dA)=t(A)q_A\,dA\)，\(0\le t\le S\)。
\(\mu=f\,dx\) 是任意有限完整来源，\(W=\mu(\mathbb R^n)\)，\(\pi_A=1_{Q_A}\mu/m_A\)。
mark 积分仍为原均匀概率。以下不改变任何实际父、质量、rank 或 void。

本稿得到一个真实近对来源价；它直接适用于 R497 完整祖先核的同父双来源正限制。有效距离约为 \(a/n\)，不足以覆盖完整剩余，也没有证明近对自动占主导。

## 1. 完整 matching 把后验浓集转为中心容量

任取轴平行来源格 \(C\)，边长为 \(h>0\)，记 \(m_C=\mu(C)\)。对 \(0<\theta<1\)，
\(\pi_A(C)>\theta\) 强制
\[
Q_A\cap C\ne\varnothing,\qquad
R_A< R_*:=\left(\frac{m_C}{\theta q}\right)^{1/n}.
\]
若该父集非空，\(R_*\ge a\)。所有这些实际中心位于 \(C\) 向各坐标扩张 \(R_*/2\) 的盒中，故
\[
\nu\{A:\pi_A(C)>\theta\}
\le S\lambda(h+R_*)^n
\le\frac{Sr}{\theta}(1+h/a)^n m_C.
\tag{1}
\]
\(m_C=0\) 时左边为零。不要求 \(C\) 本身是接收者，也不赋予其匹配约束；使用的是 \(\mu(Q_A\cap C)\le\mu(C)\) 和实际 \(m_A\ge qR_A^n\)。这正是不能用薄中心体积代来源质量时仍合法的方向。

对任一边长 \(h\) 的完整格分割，层饼与 Tonelli 给
\[
\begin{aligned}
\int\sum_C\pi_A(C)^2\,d\nu(A)
&=\sum_C\int_0^1 2\theta\,
 \nu\{\pi_A(C)>\theta\}\,d\theta\\
&\le 2Sr(1+h/a)^n\sum_Cm_C
=2Sr(1+h/a)^nW.
\end{aligned}\tag{2}
\]
这是一次共同来源总账，不逐格再收 \(W\)；相交父可以重叠，平方权和层饼已保留其重数。

## 2. 无独立坐标假设的真实近对估计

仅随机平移辅助格，平移均匀于 \([0,h)^n\)，不随机化来源或实际选择器。固定 \(x,z\) 同格的概率恰为
\[
\prod_{i=1}^n(1-|x_i-z_i|/h)_+.
\]
在 \(\|x-z\|_1\le d<h\) 上，此概率至少 \(1-d/h\)。平均 (2) 得到
\[
\boxed{\int\nu(dA)\pi_A(dx)\pi_A(dz)
 1_{\{\|x-z\|_1\le d\}}
\le\frac{2Sr(1+h/a)^n}{1-d/h}\,W.}
\tag{3}
\]
此式对任意来源坐标相关成立。取 \(h=2d>0\) 得
\[
\int\nu\pi_A^2\,1_{\{\|x-z\|_1\le d\}}
\le4Sr(1+2d/a)^nW.\tag{4}
\]
\(d=0\) 对当前绝对连续 \(\mu\) 左边为零；亦可用 (3) 的 \(h\downarrow0\) 界。没有把来源球视为均匀体积。

## 3. 同一完整祖先核的近 pair 付款

采用 R497 同一个 \(K_0,G\)，\(G=1+K_0^*G\)。因此准确有
\[
I=H_{\rm head}+I_{\rm anc},\qquad
I_{\rm anc}=\int\widehat\nu(dB)\pi_B(dx)\pi_B(dz)
 1_{v_z(B)<K}\,(V_xG)(B),
\tag{5}
\]
其中 \(H_{\rm head}=\int b_Rd\widehat\nu\le KW\)，而
\[
(V_xG)(B)=\frac1T\int_{A\succ B}
 1_{v_x(A)\ge K}e^{-[v_x(A)-v_x(B)]/T}G(A)\,\rho_x(dA).
\]
这里 \(x\) 同时被实际祖先 \(A\) 与输出父 \(B\) 捕获；停止来源 \(z\) 被 \(B\) 捕获。没有擅自令 \(z\in Q_A\)，mass 原子继续通过原 mark 排序。

R497 已证 \(G(A)\le\Phi_{\max}=e^{c/T}(1+cL/T)\)，\(c=rS\)。且 \(V_x1\le1\)，所以保留完整 head、祖先质量顺序、void 和原 \(G\) 后正上放得到
\[
\boxed{I_{{\rm anc},\le d}
\le4Sr\Phi_{\max}(1+2d/a)^nW.}\tag{6}
\]
这正是 (5) 的同一四标签域 \((A,B,x,z)\) 上的近 pair 正部分；它对随后乘入任意冻结 \([0,1]\) 标记也成立。不是把实际接受权换成参考平均。

取
\[
d_n=\frac{a\log\log(n+e)}{2n},\qquad h_n=2d_n>0,
\]
则 \((1+2d_n/a)^n\le\log(n+e)\)，故
\[
I_{{\rm anc},\le d_n}\le
4Sr e^{c/T}(1+cL/T)\log(n+e)W.\tag{7}
\]
沿原参数 \(T\gtrsim\sqrt{L+1}\)、\(L=\log r+n\log(b/a)\)，固定合同常数下这是根阶乘对数的来源价。\(n=1\) 时同一公式直接成立，也可取 \(d=a/2,h=a\)，用 (6) 的明确常数 \(8Sr\Phi_{\max}\)。它没有隐藏维数例外。

与本轮另证的 far-inside 收据同域拼接时，记
\(A_n=1+n\log(b/a)\)、\(D_0=\log(\Phi_{\max}A_n)\)、\(\mathsf d=\|x-z\|_1\)。准确互斥分割为
\[
\begin{array}{ll}
\mathsf d\le d_n;&
\mathsf d>d_n,\ z\in Q_A,\ \mathsf d\ge bD_0;\\
 d_n<\mathsf d<bD_0,\ z\in Q_A;&
\mathsf d>d_n,\ z\notin Q_A.
\end{array}
\]
第二项用另稿的 far-inside 付款，本稿只付第一项；若 \(bD_0\le d_n\)，第三项为空。边界按显示的严格／非严格条件唯一归属。**后两项仍未支付，也不声称第一项占固定比例。** 这避免了先套 R499 式(5)后额外引入 \(\Phi_{\max}TW\) 粗边界价。

一般式(3)的代价含 \((1+h/a)^n/(1-d/h)\)，因此当前机制不能在 \(d\) 为 \(a\) 固定比例时继续给 root 价格。若需要比较任意 \(h>d\)，其最优正根满足
\(nh^2-(n+1)dh-ad=0\)；本稿采用易审的 \(h=2d\)，不把参数调优当解决中距。

历史范围核对：本轮实际检查 R454 的来源中心占用矩、R455 的高 \(p\) 原流收据及 R473 fractional/Bayes 代表核；这些分别控制来源中心体积或交叉代表成本，并非 (2) 的实际父后验格质量平方。这里只主张这次明确的祖先核近 pair 应用，不宣称已穷尽全部历史或首次发现一般弱型格估计。完整目标仍是同一个 \(I\)，未由新正分支自动闭合。

## 4. 本机复现与证据范围

下列独立检查包含真实一维连续中心、单值边长 \(R_A=1\)、非均匀完整来源 \(f=1_{[-2,0)}+2\,1_{[0,2]}\)、\(A\in[-1/2,1/2]\)。此时 \(m_A=A+3/2\in[1,2]\)，\(q=1,\lambda=2,t=1\)。准确计算边长 \(1/2\) 格的后验平方积分。它不是完整原 rank/history 模拟；一般式(1)–(5)由上述证明成立。

```python
import sympy as s
from fractions import Fraction as F
x=s.symbols('x',real=True)
h=s.Rational(1,2); m=x+s.Rational(3,2)
total=0; pieces=0
for j in range(-4,4):
    lo=j*h; hi=(j+1)*h; dens=1 if j<0 else 2
    cuts=sorted(set([-h,h]+[v for v in
        [lo-h,lo+h,hi-h,hi+h] if -h<v<h]))
    for a,b in zip(cuts,cuts[1:]):
        mid=(a+b)/2
        lower=x-h if mid-h>lo else lo
        upper=x+h if mid+h<hi else hi
        if (upper-lower).subs(x,mid)<=0:continue
        Ic=s.expand(dens*(upper-lower))
        assert Ic.subs(x,mid)>=0
        total+=s.integrate(Ic**2/m,(x,a,b)); pieces+=1
actual=s.simplify(total)
print('native continuous-center 1D cell-square integral:',
      actual,'=',s.N(actual,16))
checks=0
for n in [1,2,9,64]:
    for H in [F(1,4),F(1,2),F(1)]:
        for R in [F(1),F(3,2),F(2)]:
            assert (R+H)**n<=R**n*(1+H)**n; checks+=1
for ds in [(F(1,8),),(F(1,8),F(1,8)),(F(1,10),)*3]:
    p=F(1)
    for d in ds:p*=1-d
    assert p>=1-sum(ds); checks+=1
print(f'{pieces} exact native integration pieces; '
      f'{checks} Fraction envelope/collision checks PASS.')
from flint import arb,ctx
ctx.prec=160
interval_checks=0
for n in [1,2,9,64,1024,1000000]:
    N=arb(n); ell=(N+arb(1).exp()).log(); u=ell.log()/N
    assert u>0 and (1+u)**n<ell
    interval_checks+=2
print(f'{interval_checks} Arb interval assertions PASS; '
      'n=1,2,9,64,1024,1000000; 160 bits.')
```

实际运行：六段精确积分给
\(-6+\log(2097152\sqrt6/6561)\)，小数显示为
\(0.6630722170280015\)；第二阶段 39 条有理包络／碰撞检查通过；第三阶段在 n=1,2,9,64,1024,1000000 用 160-bit Arb 通过 12 条区间断言。第一阶段另有六段中点非负断言与六段精确原生积分，合计 57 条断言。没有把此数值范围当作全维证明。一般尺度不等式直接来自 \(\log(1+u)\le u\)。小数仅为显示，不承担一般界的证明。
