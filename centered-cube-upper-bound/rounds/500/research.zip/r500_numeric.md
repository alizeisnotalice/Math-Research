# R500：同 selector 双来源包络与 farinside 系数

完成 136 项 exact/Arb 断言：12 个低维精确积分例，12 个 R495 参数下的解析系数例。没有重跑 R499 mark 模型、随机 f 或 cube-flow 实验。

结论：positive-part 端点、base 项和指数包络均实施正确。取 D/b=log(Φ_max A_n)，farinside 标量系数准确变成 Sκ。按几何作者确认，这个付款只覆盖 inside 来源 z∈Q_A 的远 pair 分支；outside、nearinside 及原流资格仍需另证。

## 公式与一般推导

两来源各坐标差为 d_i≥0，D=Σd_i。令

p_s=∏_i(1−d_i/s)_+，J=p_b+n∫_a^b p_s ds/s。

p_s 是 side-s cube 的兼容中心体积除以 s^n。对同一个可变 side selector 的全中心包络，J 保末端 base 项；不是将两个 receiver 独立选择半径。

若有 d_i≥s，p_s=0；否则逐因子 1−u≤exp(−u) 给 p_s≤exp(−D/s)≤exp(−D/b)。因此

J≤[1+nlog(b/a)]exp(−D/b)=A_n exp(−D/b)。

这是一般代数推导，不由12例证明。脚本从 polynomial ∏(1−d_i z) 的有理系数计算积分，并与 SymPy 对 p_s/s 在真实正支撑起点的积分独立比较。

真实积分下端为 max(a,max_i d_i)。若该值≥b，积分为零；p_b 仍单独计算。特别：a=b 时积分零但 base 不一定零，d_i=b 时 p_b=0 且全部费用零。未错误把这两种情况混同。

## 固定 12 例及 spread 区分

初探三例：a=1，(b,d)=(1,1/2)、(3/2,3/2)、(2,3/2)。J 分别为 1/2、0、log(4/3)，覆盖 a=b 的非空 base、贴上端零以及 positive-part 起点落在 (a,b)。

压力测试 n=2、D/b=3/2，b/a=1,3/2,2。balanced 为 d=(3b/4,3b/4)，sparse 为 (3b/2,0)：

| b/a | balanced J | sparse J |
|---|---:|---:|
| 1 | 1/16 | 0 |
| 3/2 | −1/2+log(16/9)≈.07536414 | 0 |
| 2 | −1/2+log(16/9)≈.07536414 | 0 |

相同 L1 距离不意味着相同真实重叠；sparse 有单坐标超过 b，直接为空。指数包络只保 D，因此允许这部分松弛。

扩大仅取 n=3、a=1、b=2、D/b=3/4：balanced d=(1/2,1/2,1/2)，sparse d=(3/2,0,0)，J 分别为

−35/32+log8≈.98569154，−1/2+log(64/27)≈.36304622。

另加 n=2、a=1、b=3/2、d=(0,0) 的零 spread 边界，J=A_n=1+log(9/4)，指数界达到等号。共12例，不扩维度扫描。

## farinside 的明确系数

使用已证 Φ_max=exp(P/T)(1+PL/T)，P=rS。取 d0=log(Φ_max A_n)，则

Sκ Φ_max A_n exp(−d0)W=SκW。

SymPy 一般符号恒等式与 Arb 实际参数包围均核。高维不再算实际 spread/capture 或 f，只检查这一个解析系数。

四组 profile (r,S,τ,eps) 为 (1,1,1,1/4)、(3,1,1/4,1/16)、(1,2,2,1/16)、(3,2,1/2,1/4)。沿 R495 取 b/a=2、L=log r+nlog2、原 max T 与 κ；仅 n=2,256,10^12，共12参数例。

profile 0 的摘要：

| n | d0=D/b | 费用系数 Sκ |
|---|---:|---:|
| 2 | .86993400 | 31.04735408 |
| 256 | 5.19856444 | 31.04735408 |
| 10^12 | 35.69351778 | 106.32431710 |

严格区间、T、Φ_max、A_n 和相消前后费用均保 JSON。这不是在这些高维数构造了实际来源流，也不表明任意 pair 自动满足该远距离门。

与几何作者对齐：U2≤S J；将它接原 π_B²/head 的 farinside 账需要 inside z∈Q_A。此材料未覆盖 outside 来源，也未重测作者已有 native selector 小例。nearinside 的空间/流预算仍是实际缺桥。

## 复现与范围

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r500_numeric.py`

实际 Python3.12.14、SymPy1.14.0、python-flint0.9.0、Arb384 bits。低维积分为 exact Fraction/SymPy，对数及指数费用为 Arb 严格包围。没有数值 quadrature、浮点优化、离散格点或 Monte Carlo。

固定 stdout：`PASS 136 exact/Arb assertions;12 lowdim envelope cases,12 analytic farinside coefficients;no flow certification`。

唯一动态 JSON 字段是 `compute_index.seconds`，隔离重放比较时删该字段。输出写脚本自身目录。归档白名单仅 `/tmp/r500_numeric.py`、`/tmp/r500_numeric.json`、`/tmp/r500_numeric.md`。完成限定任务后停止。
