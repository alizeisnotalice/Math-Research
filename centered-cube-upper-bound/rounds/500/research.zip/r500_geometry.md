# R500：同一 selector 的双来源包络及远 inside 祖先费用

本稿证明一个一般中心包络，并把它代入原完整 ancestor 积分中的真实正部分。远距离且共同被祖先捕获的来源对有 \(S\kappa W\) 价；再接本轮互补 cell-square 输入可支付全部极近来源对。中距 inside 与远 outside 尚未结算，包络本身不等于完整根阶结论。

## 1. 同 selector 双来源包络

设 \(Q_A\) 是中心 \(A\)、边长 \(R_A\in[a,b]\) 的轴平行立方体，\(R_A\) 是同一个可测 selector，\(0\le t(A)\le S\)。对任意固定来源 \(x,z\) 定义
\[
 U_2(x,z)=\int_E\frac{t(A)}{R_A^n}c_A(x)c_A(z)\,dA,
 \quad d_i=|x_i-z_i|,
 \quad p_s(x,z)=\prod_{i=1}^n(1-d_i/s)_+.
\]
一般成立
\[
 U_2(x,z)\le S\left[p_b(x,z)+n\int_a^b p_s(x,z)\frac{ds}{s}\right]
 \le S A_n e^{-\|x-z\|_1/b},
 \qquad A_n=1+n\log(b/a). \tag{1}
\]

证明保留同一 \(R_A\)：逐中心
\[
 R_A^{-n}c_A(x)c_A(z)
 \le b^{-n}1_{\{x,z\in Q_b(A)\}}
 +\int_a^b n s^{-n-1}1_{\{x,z\in Q_s(A)\}}\,ds.
\]
若左边非零，右边至少包含 \(s\in[R_A,b]\) 的积分及顶端项，和恰为 \(R_A^{-n}\)；若左边为零不等式显然。积分真实中心 \(A\)，共同捕获中心集体积准确为
\(\prod_i(s-d_i)_+\)，Tonelli 给第一式。每个非零因子满足
\(1-d_i/s\le e^{-d_i/s}\)，且 \(s\le b\)，给第二式。
\(a=b\)、某 \(d_i\ge b\) 及边界零体积情形均含在公式内。
没有按来源重新选择半径，也没有对 \(f\) 施加密度帽。

## 2. 原权下真正可付的部分

沿 R497–499 的同一场：\(m_A=\mu(Q_A)=q_AR_A^n\)、
\(\widehat\nu=t(A)q_A\,dA\,ds_A\)、\(\pi_A=\mu|_{Q_A}/m_A\)，
\(\rho_x=c_A(x)\widehat\nu/m_A\)，\(v_x\) 是带连续 mark 的实际前缀。
\(K=\kappa T\)，\(h_B(z)=1_{\{v_z(\widehat B)<K\}}\)。保原
\(G=\sum_j(K_0^*)^j1\le\Phi_{\max}\)，其中
\[
 \Phi_{\max}=e^{c/T}(1+cL/T),\qquad c=rS.
\]
R497 boundary ancestor 的准确积分为
\[
 \frac1T\int\widehat\nu(d\widehat B)\pi_B(dx)\pi_B(dz)h_B(z)
 \int_{\widehat A\succ\widehat B}
 \frac{G(A)c_A(x)}{m_A}
 \chi_\partial(A,x)1_{\{v_x(A)\ge K\}}
 e^{-[v_x(A)-v_x(B)]/T}\,\widehat\nu(d\widehat A).
 \tag{2}
\]
这里 \(x,z\) 是同一真实 \(\pi_B\) 下的两来源；\(z\) 的低秩门不能删后再声称保留。原实际成功量由该同域 raw 核正支配，并不将新祖先赋予旧成功历史。

在 (2) 中取真实正限制
\[
 z\in Q_A,\qquad \|x-z\|_1\ge bD,\qquad D\ge0.
\]
只为上界删除 \(A\) 的次序、rank、boundary、void 限制并用 \(G\le\Phi_{\max}\)；
\(\widehat\nu/m_A=t(A)R_A^{-n}dA\,ds_A\)，故原祖先积分可直接用 (1)。保全部 \(B,z\) head 后，所得费用为
\[
 I_{\partial,\mathrm{in,far}}(D)
 \le \frac{S\Phi_{\max}A_n e^{-D}}T
       \int b_R\,d\widehat\nu
 \le S\kappa\Phi_{\max}A_n e^{-D}W. \tag{3}
\]
最后一步是原来源秩 CDF 的一次 head 价
\(\int b_R\,d\widehat\nu\le KW\)，不是对累计 \(G\) 删权。

取
\[
 D_0=\log(\Phi_{\max}A_n)\ge0
\]
便得到实际正部分的明确收据
\[
 I_{\partial,\mathrm{in,far}}(D_0)\le S\kappa W. \tag{4}
\]
沿既定 \(T\) 选择，\(\kappa=O(\log(n+2))\)、\(D_0=O(\log(n+2))\)，常数允许依赖已固定 \(r,S,\tau,\varepsilon_g\)。若阈值超过 \(Q_B\) 的最大可能来源距离，事件为空，式 (4) 仍有效。

## 3. 与已核 cell-square 输入在同一原域合并

本节只接入本轮互补证明负责的 cell-square 引理，不重复其证明。其准确输入为：对边长 \(h_c\) 的固定立方网格，
\[
 \sum_C\int\widehat\nu(dB)\pi_B(C)^2
 \le2Sr(1+h_c/a)^nW.
\]
对网格作一个全局独立随机平移，同格概率至少
\(1-\|x-z\|_1/h_c\)。因此 \(0<d<h_c\) 时
\[
 \int\widehat\nu(dB)\pi_B(dx)\pi_B(dz)
       1_{\{\|x-z\|_1\le d\}}
 \le\frac{2Sr(1+h_c/a)^n}{1-d/h_c}W. \tag{5}
\]
这是完整来源质量与匹配所得平方价，不是薄来源体积帽。

在同一个 (2) 中，原祖先积分 \(V_xG\le\Phi_{\max}\)，因为含高 rank 门的来源指数行积分不超过 1。故全部 near 正部分（无须 \(z\in Q_A\)）满足
\[
 I_{\partial,\mathrm{near}}(d)
 \le C_{\rm near}W,\qquad
 C_{\rm near}=4Sr\Phi_{\max}(1+2d/a)^n, \tag{6}
\]
这里取 \(h_c=2d\)，仅在上界中删 head，未替换 \(\pi_B\)。选择
\[
 d=\frac{a\log\log(n+e)}{2n}>0
\]
给 \(C_{\rm near}\le4Sr\Phi_{\max}\log(n+e)\)。沿原参数，\(\Phi_{\max}=O(1+\sqrt n)\)，因此确是根阶乘对数价。

统一分拆次序必须保持：先付全部 \(\|x-z\|_1\le d\)；再付 inside 且
\(\|x-z\|_1>d\)、\(\|x-z\|_1\ge bD_0\) 的部分，用 (4)。精确剩余为
\[
 \begin{cases}
 z\in Q_A,\quad d<\|x-z\|_1<bD_0, &\text{中距 inside},\\
 z\notin Q_A,\quad \|x-z\|_1>d, &\text{远 outside}.
 \end{cases}
\]
若 \(bD_0\le d\)，第一项为空。这些都是同一个 (2) 的互斥正限制；所有 rank、void、mark、\(G\)、boundary 及来源分母在定义中保留。完整备选账为
\[
 R_\tau\le
 (K+C_{\rm deep}+C_{\rm empty}+S\kappa+C_{\rm near})W
 +I_{\partial,\mathrm{middle\ in}}
 +I_{\partial,\mathrm{far\ out}}. \tag{7}
\]
原 \(\tau X\)、非rank 及入口倍率继续保留。式 (7) 与 R498 signed 谱接口是备选分析，不能重复抵扣其收益。

仍缺一个同权的联合来源分配。远 outside 没有第二个共同捕获因子，不能用 (1)。R498 虽将其质量精确输运到人工 \(w\in Q_A\setminus Q_B\)，该来源律依赖 \((A,B)\)，且 \(w\) 不保 head；不能将其当 (2) 固定的 \(\pi_B(dz)\)。中距 inside 的两点距离也不给某个固定 packet 占 \(m_A\) 的定量比例，因而不能由共同捕获两点就推出窄质量窗，再对随父改变的 packet 收一次 \(W\)。

本轮的两端费用 (4)、(6) 并不证明中间/外部一般类已经覆盖。未获该联合比较，不能将 (7) 写成完整根阶结论。

## 4. 本机精确核验

一般证明是上面的 Tonelli/中心体积推导。另用指定本机 Python 实跑以下有限接口核验。native 场为 \(n=2\)、\(f=1\) 于 \([-4,4]^2\)、\(E=[-2,2]^2\)、\(t=1\)，同 selector 在 \(A_1<0\) 取边长 1，在 \(A_1\ge0\) 取边长 2；所以完整匹配 \(q_A=1\)。固定 \(x=(0,0),z=(1/4,1/2)\) 得真实 \(U_2=1/2\)，而 (1) 第一式包络为 \(2\log2\)。该场仅核 native selector，未认证原高秩或成功历史。

```python
from fractions import Fraction as F
import sympy as s
r=s.symbols('r', positive=True)
p=(1-s.Rational(1,4)/r)*(1-s.Rational(1,2)/r)
env=s.simplify(p.subs(r,2)+2*s.integrate(p/r,(r,1,2)))
assert s.simplify(env-2*s.log(2))==0
x=(F(0),F(0)); z=(F(1,4),F(1,2))
def part(R,lo,hi):
    lengths=[]
    for i in range(2):
        low=max(F(-2),max(x[i],z[i])-R/2)
        high=min(F(2),min(x[i],z[i])+R/2)
        if i==0: low=max(low,lo); high=min(high,hi)
        lengths.append(max(F(0),high-low))
    return lengths[0]*lengths[1]/R**2
actual=part(F(1),F(-2),F(0))+part(F(2),F(0),F(2))
assert actual==F(1,2)
# log(2)=integral_1^2 dt/t >= 1/2.
assert 2*F(1,2)>=actual
print('pair envelope = 2*log(2); symbolic PASS')
print('native matched selector U2=1/2 <= envelope: exact PASS')
```

首次手算包络中的常数曾被符号断言检出不符；已改为准确的 \(2\log2\)，以上最终代码实际重跑通过。没有另作反例扫描。交付后停止。
