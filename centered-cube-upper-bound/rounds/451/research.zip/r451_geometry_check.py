"""R451 bounded exact checks; no certification of the target I2 inequality."""
import sympy as s
from fractions import Fraction as F

# 1. Coordinatewise nesting and inclusion for minimal source-capturing cubes.
count = 0
for omega in [(F(1),), (F(1), F(-1,3)), (F(-1), F(0), F(2,3))]:
    for r1, r2, side in [(F(1,4),F(1,2),F(3,2)),(F(1,2),F(1),F(2))]:
        assert 2*r2 <= side
        for v in omega:
            lo1, hi1 = r1*(v-1), r1*(v+1)
            lo2, hi2 = r2*(v-1), r2*(v+1)
            assert lo2 <= lo1 <= hi1 <= hi2
            assert r2*v-side/2 <= lo2 <= hi2 <= r2*v+side/2
            count += 1
print(f'stage 1: {count} exact coordinate nesting/inclusion checks PASS')

# 2. Actual full source f=1+||x||_infty^2 on [-1,1]^n,
# one fixed cube: continuous mass-rank polynomial moments.
t = s.symbols('t', nonnegative=True)
count = 0
for n in (1,2,4):
    M = 2**n * (t**n + s.Rational(n,n+2)*t**(n+2))
    mass = M.subs(t,1)
    for k in (0,1,2,3):
        lhs = s.integrate(s.diff(M,t)*(M/mass)**k,(t,0,1))
        assert s.simplify(lhs-mass/s.Integer(k+1)) == 0
        count += 1
print(f'stage 2: {count} exact native-source radial-rank moments PASS')

# 3. True Lebesgue-center selector: E=[-1,1], R(A)=max(1,2|A|),
# full f=1_{[-2,2]}; q_A=1. The displayed J is valid f-a.e.
y = s.symbols('y', positive=True)
J_inner = 1-y+s.log(2)/2
J_outer = s.log(2/y)/2
Jfirst = 2*(s.integrate(J_inner,(y,0,1))+s.integrate(J_outer,(y,1,2)))
Jsecond = s.simplify(2*(s.integrate(J_inner**2,(y,0,1))+s.integrate(J_outer**2,(y,1,2))))
assert s.simplify(Jfirst-2) == 0
assert s.simplify(Jsecond-s.Rational(5,3)) == 0
print('stage 3: continuous-center first moment =', Jfirst)
print('stage 3: continuous-center I2 =', Jsecond)
print('stage 3: per-source free radial envelope = 1+log(2); attained at y=0 only in this selector')
print('Scope: stage 2 tests one-cube source ranks; stage 3 is a real q-exact Lebesgue field in n=1.')
print('Neither calculation proves or refutes the general O(n polylog(n) W) target.')
