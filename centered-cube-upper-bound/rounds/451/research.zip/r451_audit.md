# R451 independent audit — FINAL PASS（限定范围）

FINAL PASS 仅认证本轮明确列举的恒等式、固定真实有限几何的LP弱对偶/六份有理最优证书，以及径向秩与一维实际selector的局部核算。**没有认证一般 q²∫fJ²≤Cn polylog(n+2)W、原R433预算或一般根阶弱型上界；没有新增原流付款。** 母账保持root稿第4节。下方保留先于作者稿形成的PRE；其临时有限表不计正式证据覆盖。

## 1. 数学后审

1. 有限几何LP使用正Lebesgue来源盒与中心盒，整个中心盒统一全捕获/不捕获，m_j=ΣB_ji a_i是真实完整来源质量。r=1时θ²∫fJ²=Σa_i d_i²精确；r>1仅为r²夹界。一般band双对偶的符号、θ项约束及固定θ等式LP的自由乘子均正确。θ=0强迫Ba=0并给零目标；修后稿已明确只有θ>0等值见证认证正q真实场，零最优不伪造正密度。六例均独立核θ=2^(−n)>0。
2. Sol的M2=∫DJ+Δ、对称交叠式、同盒密度差乘捕获差、union/q差公式的系数与符号正确；Δ可正可负，未当作正来源预算。条件吸收式保未证的Δ假设及均匀L²算子范数资格；Young回代常数正确。J≤An/q、∫D=|E|及∫fJ=|E|保证这些量有限，不作∞−∞。九个连续中心场的完整f、匹配质量、q-band、octave与精确有符号积分范围均符合所称结论，不认证原history门。
3. 几何稿的minimal捕获cube沿固定射线嵌套且包含于实际选定cube；J≤Jgrowth≤(λ/q)J成立。自由半径包络在常密度plateau回到An/q，仅说明外放松无改善，未变成真实高维反例。对任意L¹非负f、m_A>0，π_A下径向距离分布连续（各cube面源测度为零），故其累计捕获质量rank均匀，即使分布有平坦区间亦成立。rank的对数与负p矩积分精确，但不控制额外J权。一维R_A=max(1,2|A|)的所列J对f-a.e来源正确；y=0闭面产生的孤立跳不影响∫fJ=2、∫fJ²=5/3。首跑手填参考值纠错记录与最终脚本一致。
4. 数值六例对每个来源盒与所有中心位置具有至少9/1000的捕获间距，正体积/单值side/full-f质量及q-exact条件真实，不能看成任意关联矩阵。HiGHS仅搜候选，最终Fraction逐列弱对偶、原可行性和原对偶精确相等认证固定几何上的全来源最优。单尺度恒值(.576)^n由行空间身份核准；两尺度n2/n3正uniform gap说明此有限族中的来源相关性费用，未推渐近或全目标反例。

## 2. 实际复现与证据边界

指定 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 在新隔离目录
`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r451_audit_isolated_yc6g10c6`
实际运行三脚本。三份stdout与冻结输出逐字节一致，numeric生成JSON与冻结certificate逐字节一致；前两脚本在最后复现geometry时再核脚本字节未变，未无故重复计数。

正式证据分开列：numeric六LP/3855项有理检查；mainproof九个连续中心场符号/有理积分；geometry十二坐标包含、十二单cube径向rank核算及一个一维实际连续selector的两矩积分。检查项不是一般证明，三类不合并称为native完整history覆盖。资源文件是作者原实跑记录，本审查只核其范围，不将本次复跑计为新增参数搜索或扣额。未运行MATLAB，本轮无相应证据要求。

现冻结内容无未修实质阻断项。全M2几何预算与原余项仍未付，root所列16/32/64母账没有由这些恒等式或有限最优值自动改善。

## 3. 最终字节绑定（14输入）

- `r451_main.md`: `d4540f37446c7fe0ebbf652418c8289a15105a39e413d82c8d647662bd481d07`
- `r451_finite_geometry_lp.md`: `30b03d836861c8d64386d9579809e47bad88e93c4696f5fe08eca41751826449`
- `r451_geometry.md`: `a61cfba0c0bd5de8125c6890086aaef5feb03b6b2888cb10baf844225633c157`
- `r451_geometry_check.py`: `26776729e8088c5c602285d51b1e2497cb88b9bcd583b111c8779977cac1dc88`
- `r451_geometry.result.txt`: `455f075c17fe29494154c8a8fcc14bce7e399616fc4f820d8290dedfc3796085`
- `r451_mainproof.md`: `4d6fca67bb5c8e891559fbdbdf231243ef3acb0dd33c4a8ce7951cb580e18deb`
- `r451_mainproof_check.py`: `00bc4b42c24433c085a9237bb5e073e10bad6900274da8c7cddfbe622a646f18`
- `r451_mainproof.result.txt`: `f241789d666e88c719de531652545949432d14a758a3bb617562b22d21d1cbcb`
- `r451_numeric.md`: `c4ff9d96ca1ea9f74bfd0a244cb517e96887afc37254dcb92f9669b4a5c25abf`
- `r451_numeric.py`: `4cf2e73e69caf054ab3c8c802875b8785db85de3179f8ca5443bdb7d42c0183d`
- `r451_numeric_certificate.json`: `dc9106213158b53a0a03a84780c97a19459e1a351af383b9119e8fbd3cc6f175`
- `r451_numeric_run.txt`: `e17cfd0f83769cbf774012b8028513c0c36f860220c8d7100abc892362c964b5`
- `r451_numeric_resources.txt`: `b90cb44b4211a128a83a929da5c0556f6cf7d4686a15952aec35e81827ae5a8d`
- `r451_numeric_compute_index.md`: `2a00928a8c14a823989a830fe984c3d31c755230c6c2112dc13aa03eb079623b`

---

# R451 independent audit — PRE

PRE ONLY。独立核R450主证的必要片段及继承R435原合同，未读本轮作者新证明。目标q²∫fJ²≤C n log^A(n+2)W当前未证；本文只核量词、意义与可保原门的较弱合法矩，不搜泛反例、不把测试数当一般证明。

## 1. 强目标的精确量词与作用

对每个n（原主线n≥9）、任意完整非负f∈L1、实际Lebesgue中心E及单值可测边长a≤R_A≤b≤2a，要求真实m_A=f(Q_A)=q_AR_Aⁿ且0<q≤q_A≤λ，r=λ/q按原合同固定。记

J(y)=∫_E c_A(y)dA/m_A， W=∫f， X=∫_E q_A dA， M2=∫f(y)J(y)²dy。

拟证C及log幂不得依赖具体f/E/selector/scale或n隐藏增长；可声明所保r等固定合同依赖。零W使E为空并为零结论。缩放f、q及空间尺度的单位一致，不能把q当另一常阈值并改写X=q|E|。

现有J≤An/q只给q²M2≤An²W（一般O(n²)），不等于目标O(n polylog)。M2是source加权而非∫J²dy或f²权；精确Tonelli为∫_E∫_E I_AB dA dB/(m_A m_B)，I_AB=f(Q_A∩Q_B)，保同一完整来源匹配。

若目标成立，|E|=∫fJ≤√(WM2)，故q|E|≤√C√n log^(A/2)(n+2)W，且X≤λ|E|保r因子。这直接提供所选octave/q-band场的强根阶质量控制；还不能省略原全入口跨层/初始/尺度费用的统一手续。它不是一般弱型根界的已证必要条件，也不是已知weak工具：Cauchy是此处单向充分关系，没有反向M2结论。

## 2. 已证mass排序桥及其局限

R450原E_K=∫σ(dA)∫strict p_A(w)(1−p_A(w))dw/m_w，p_A=I_Aw/m_A，strict为m_w<m_A/K。

对无q_A的source共同far量F0，有q(1−1/K)F0≤E_K≤λF0。J²分为两个strictfar方向与closed comparable band；native闭窗质量≤(1+2logK)/q（core项保1/q、closed massatom未删除）。因此

M2≤4E_K/[q(1−1/K)]+[(1+2logK)/q]²W， E_K≤λM2/2。

K=e^√n时附加闭窗项已为O(nW/q²)。这些已证比较只说明E_K的nW/q价与M2的nW/q²价在固定合同下同一强量级，未支付其中任何一个。严格mass门p<1/K使负p²信用相对正p仅≤1/K；不能从这个指数小的相对差反推出所需√n净节省。masswindow或可测selector的有限检验不能替代全场pair重复捕获预算。

## 3. 保原剩余门的较弱合法几何目标

可以保一个共同已知static indicator L(A,y,z)：原Π433的source投影支持L=1，且原投影≤S L σ(dA)π_A(dy)π_A(dz)。例如仅取原high-Z/low-common、两个relative-rank及低TG/Tloc等已确认source-pair门的交集；不将路径或stage门假装成没有相应标签的static点态事件。

定义

E_{K,L}=∫σ(dA)∫π_A(dy)π_A(dz)L(A,y,z)[Z_A(y)−C_A(y,z)]。

它非负、≤E_K，且由原Z−C>(3−ε₀)h支持给

R433≤S E_{K,L}/[(3−ε₀)h]。

它保原共同父、完整双来源及strictK小质量捕获，未生成新source/history。展开真实receiver w后的准确内核是

E_{K,L}=∫σ(dA)∫_{m_w<m_A/K}dw/m_w
   ∫π_A(dy)π_A(dz)L(A,y,z)c_w(y)(1−c_w(z))。

等价先固定旧source y时，其新source系数必须保
B_L(A,y,w)=∫π_A(dz)L(A,y,z)(1−c_w(z))。

L依y,z时不能因子化为p_A(1−p_A)乘任意平均L，也不能把未捕获z的w赋原路径。丢L可正上放回E_K，但会丢本较弱目标的潜在几何节省。

若使用一般0≤L≤1而非indicator，必须另证真实投影density≤S L，不能仅因“support含L>0”就同样上放。若要求保所有history，可取原projection的真实RN平均除S；那仍是原测度的精确表示，不刷新来源，但证明该量的预算仍需原实际选择偏差，不能把这种定义当新独立工具。

证明E_{K,L}≤Cε n log^A(n+2)W/q即可给原R根价；更精确可允许

E_{K,L}≤[(3−ε₀)h/S] εX + Cε n log^A(n+2)W/q，

则R≤εX+[SCε ε₀ n/((3−ε₀)s)]log^A W。这个要求由强M2目标推出，但当前未证明其反向；保门版本可比全无标记M2预算弱，不再要求所有原共捕获pair同时受控。已有R435归一exclusive测试L(Z−C)/Z也是合法原门接口，其root来源价同样未证，不能将旧X价重新视为新结果。

这些都是准确可审核的目标，不是本PRE提出已证新几何桥。任务仍同原R433，不因写出E_{K,L}就完成。

## 4. 后审的建设性门槛与总账

作者若给全M2证明，需逐步保full-f匹配、source fdy、实际Leb中心及单值radius；不得把sourcecell质量当center原子，或将独立radius积分代替原selector。pair交换保持I_AB对称，但含q_A的流不是天然对σ可逆；strictfar与closedband等号、base项和massatoms必须保。所有常数依赖应显式，尤其目标nW不能以An²≈n²W冒充。

作者若证明保门E_{K,L}，必须指出静态L或真实条件RN的精确测度，并保old/new标签及stage/路径标记。receiver方向外放松只能取正上界，不能给新source原history；capacity总上界不能逆作覆盖下界。signed删除或负平方信用如使用，需同原流、终端和已付款范围全保，不重复扣信用。

若直接证原R≤εX+QεW，原入口只替换64Λ₀FhatR槽为64Λ₀Fhat(εX+QεW)，其余C433/V433和初始/删除/尺度费用照旧。R449或R447容量收据是替代路线，不与这个直接whole-R结算重复叠加；最终ε吸收仍须核余量。

## 5. 实际本机辅助与停止

指定math-research-tools Python/Fraction实际核一个三source有限capture表：marked exclusive双来源积分与保B_L的换序完全相等，为1/12；无门p(1−p)=1/4，不能再乘独立平均L。仅为条件核代数，不是native/history样本或反例扫描，不计新正式覆盖。

PRE结论：强M2是充分但未证、非一般weak目标必要条件；保原source-pair门的E_{K,L}给合法较弱整体几何入口，但其预算也未证。等待作者具体步骤后再审，不提前认证一般证明。
