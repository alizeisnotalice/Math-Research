#!/usr/bin/env python3
"""Six small LPs on genuine positive-volume packet/cube q-exact fields."""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import json,sys,platform,time
import numpy as np
from scipy.optimize import linprog
import scipy
ROOT=Path(__file__).resolve().parent
checks=0
def ck(x):
 global checks
 assert x
 checks+=1

def run(n,multiscale):
 points=list(product([Q(-3,4),Q(-1,4),Q(1,4),Q(3,4)],repeat=n))
 centers=list(product([Q(-1,2),Q(0),Q(1,2)],repeat=n))
 packet_half=Q(1,1000)
 ck(all(max(abs(x-y) for x,y in zip(a,b))>2*packet_half for k,a in enumerate(points) for b in points[k+1:]))
 cell_half=Q(6,25);volume=(2*cell_half)**n
 R=[Q(2) if multiscale and all(x==0 for x in c) else Q(1) for c in centers]
 ck(max(R)/min(R)<=2)
 ck(all(max(abs(x-y) for x,y in zip(c,d))>2*cell_half for k,c in enumerate(centers) for d in centers[k+1:]))
 capture=[];margin=Q(10)
 for center,side in zip(centers,R):
  row=[]
  for point in points:
   near=max(abs(x-y) for x,y in zip(center,point))
   hit=near+cell_half+packet_half<side/2
   miss=near-cell_half-packet_half>side/2
   ck(hit or miss)
   row.append(int(hit))
   margin=min(margin,side/2-near-cell_half-packet_half if hit else near-cell_half-packet_half-side/2)
  capture.append(row)
 corner_rows=[row for center,row in zip(centers,capture) if all(x!=0 for x in center)]
 ck(all(sum(row[i] for row in corner_rows)==1 for i in range(len(points))))
 # Corner rows partition all packets, so every q-exact feasible field has q=2^-n.
 q=Q(1,2**n);uniform=[Q(1,len(points))]*len(points)
 target=[q*side**n for side in R]
 ck(all(sum((a*b for a,b in zip(row,uniform)),Q(0))==t for row,t in zip(capture,target)))
 d=[sum((Q(row[i])/side**n for row,side in zip(capture,R)),Q(0)) for i in range(len(points))] # d_i / volume
 cost=[x*x for x in d]
 A=np.array(capture+[[1]*len(points)],dtype=float)
 b=np.array([float(x) for x in target]+[1.0])
 result=linprog(-np.array([float(x) for x in cost]),A_eq=A,b_eq=b,bounds=(0,None),method='highs')
 ck(result.success)
 a=[Q(float(x)).limit_denominator(10**6) for x in result.x]
 ck(all(x>=0 for x in a) and sum(a)==1)
 ck(all(sum((w*z for w,z in zip(row,a)),Q(0))==t for row,t in zip(capture,target)))
 # Max primal dual: sum_j lambda_j capture_ji + beta >= cost_i.
 lam=[Q(float(-x)).limit_denominator(10**6) for x in result.eqlin.marginals[:-1]]
 beta=Q(float(-result.eqlin.marginals[-1])).limit_denominator(10**6)
 defect=max(Q(0),max(cost[i]-beta-sum((l*row[i] for l,row in zip(lam,capture)),Q(0)) for i in range(len(points))))
 beta+=defect
 slacks=[beta+sum((l*row[i] for l,row in zip(lam,capture)),Q(0))-cost[i] for i in range(len(points))]
 ck(all(x>=0 for x in slacks))
 lower=sum((x*y for x,y in zip(a,cost)),Q(0))
 upper=beta+sum((l*t for l,t in zip(lam,target)),Q(0))
 ck(lower<=upper)
 ck(lower==upper)
 tensor_lambda=[Q(1) if all(x!=0 for x in center) else Q(3)**sum(x==0 for x in center) for center in centers]
 rowspace_identity=False
 if not multiscale:
  ck(all(sum((l*row[i] for l,row in zip(tensor_lambda,capture)),Q(0))==cost[i] for i in range(len(points))))
  rowspace_identity=True
 inner_distribution=[sum((a0 for pt,a0 in zip(points,a) if sum(abs(x)==Q(1,4) for x in pt)==k),Q(0)) for k in range(n+1)]
 inner_marginals=[sum((a0 for pt,a0 in zip(points,a) if abs(pt[k])==Q(1,4)),Q(0)) for k in range(n)]
 ck(sum(inner_distribution)==1)
 actual_uniform=volume**2*sum((x*y for x,y in zip(uniform,cost)),Q(0))
 actual_opt=volume**2*lower
 # Full matching q J_i = volume*d_i for every feasible mass vector.
 masses=[sum((z*x for z,x in zip(row,a)),Q(0)) for row in capture]
 J=[sum((volume*row[i]/m for row,m in zip(capture,masses)),Q(0)) for i in range(len(points))]
 ck(q*q*sum((x*j*j for x,j in zip(a,J)),Q(0))==actual_opt)
 ck(all(m==q*r**n for m,r in zip(masses,R)))
 return dict(n=n,multiscale=multiscale,source_points=points,packet_halfwidth=packet_half,
 center_points=centers,center_halfwidth=cell_half,center_volume=volume,R=R,capture=capture,
 q=q,W=Q(1),strict_capture_margin=margin,source_mass=a,receiver_mass=masses,
 d_over_volume=d,J=J,uniform_target=actual_uniform,optimal_target=actual_opt,
 optimization_gain=actual_opt/actual_uniform,uniform_gap=actual_opt-actual_uniform,
 rowspace_identity=rowspace_identity,tensor_rowspace_lambda=tensor_lambda if rowspace_identity else None,
 inner_count_distribution=inner_distribution,inner_marginals=inner_marginals,dual_lambda=lam,dual_beta=beta,
 dual_slack=slacks,dual_repair=defect,primal_scaled=lower,dual_scaled=upper,
 float_equality_residual=float(np.max(np.abs(A@result.x-b))),
 variables=len(points),equality_rows=len(target)+1,nonzero_mass=sum(x>0 for x in a))
results=[]
for n in (1,2,3):
 for multi in (False,True):results.append(run(n,multi))
out=dict(scope='finite genuine q-exact octave packet/center fields; no full original history or dimension extrapolation',
 executable=sys.executable,python=platform.python_version(),scipy=scipy.__version__,numpy=np.__version__,checks=checks,cases=results)
def encode(x):
 if isinstance(x,Q):return str(x)
 raise TypeError(type(x).__name__)
(ROOT/'r451_numeric_certificate.json').write_text(json.dumps(out,default=encode,indent=2)+'\n')
print('executable:',sys.executable,'Python:',platform.python_version(),'SciPy:',scipy.__version__,'NumPy:',np.__version__)
for a in results:
 print('n=',a['n'],'multiscale=',a['multiscale'],'variables=',a['variables'],'rows=',a['equality_rows'],'margin=',a['strict_capture_margin'])
 print(' uniform=',a['uniform_target'],float(a['uniform_target']),'opt=',a['optimal_target'],float(a['optimal_target']),'gain=',a['optimization_gain'])
 print(' scaled_primal_dual=',a['primal_scaled'],a['dual_scaled'],'repair=',a['dual_repair'],'nonzero_mass=',a['nonzero_mass'],'float_residual=',a['float_equality_residual'])
print('PASS',checks,'exact checks; six tiny LPs; finite field scope only')
