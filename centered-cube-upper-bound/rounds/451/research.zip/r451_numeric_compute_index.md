# R451 数值责任与状态

- 所有权：Sol medium，仅 `/tmp/r451_numeric*`；无git、spawn、repo或他人修改。
- 索引输入：先读 `/tmp/r451_model_index.md`；旧winner/atomic sampled模型未被当作本题全积分证据。实际采用root批准的4^n packet、3^n center-cell真几何。
- 参数：n=1,2,3，各单尺度与中央R2两尺度，共6个小LP；W1、q=2^-n、r1、octave≤2、fullcapture margin9/1000、center体积(.48)^n。
- 初步/压力/扩大：依次n1/n2/n3；最多64源变量、28等式，没有额外扫描。
- 实跑：指定Python3.12.14、SciPy1.18.1、NumPy2.5.4；.24s、RSS74,661,888bytes。
- 证书：3855 Fraction checks；6 primal=dual、dual repair0；全部源/中心几何和fullm匹配验证。单尺度rowspace identity额外精确核。
- 数学决策：单尺度目标恒定(.576)^n；两尺度n2/n3关联产生严格uniformgap，n3略高于单尺度；不猜general order、不认证原history/winner。
- 输出：r451_numeric.py、r451_numeric_certificate.json、r451_numeric_run.txt、r451_numeric_resources.txt、r451_numeric.md、本索引，均/tmp，可同目录归档。
- 状态：冻结停止。
