# R451 真 q-exact / octave 场的有限二阶矩决策（冻结）

六个极小真实几何 LP 均恢复精确有理原解与对偶相等，3855项检查通过。单尺度 tensor 场的二阶目标对所有可行源质量都相同；中央 receiver cell 改用 R=2 后，二维及三维源质量关联可严格提高目标。三维的最优两尺度值还略高于同维单尺度值。测试范围仅 n=1,2,3，不能据此猜测维数阶数。

## 1. 来源索引与最小场

先阅读 Luna 的 `/tmp/r451_model_index.md`。已有 τ·box+atom winner 及 lattice sampled-path 模型尚无本题全 Lebesgue J² 积分；L¹替代/积分还需额外工作，因此没有把这些旧样本重算称为本轮结果。改用 root 批准的完全可核小场，最多64个源变量。

在 n 维，源 packet 中心是 `{−3/4,−1/4,1/4,3/4}^n`，每个是半宽1/1000的正体积小立方体；质量 a_i≥0，Σa_i=W=1，packet 内密度为 a_i/(2/1000)^n。不同 packets 严格不交。receiver center cells 的中心为 `{−1/2,0,1/2}^n`，每个 cell 半宽6/25，真实 Lebesgue 体积 `v=(12/25)^n`，彼此严格不交。

基础 selector 在每个 cell 取 R=1。两尺度 selector **仅**在全零中心的那个 cell 取 R=2，其余 cell 仍取1；同一 cell 没有同时选两种 R。原 source f 在两场中使用相同 packet 位置，质量由各 LP 选择。每个 receiver cube 对每个完整 packet，在整个 center cell 上均严格全捕获或全不捕获，最小边距9/1000；没有任意 incidence 矩阵。

捕获 B_ji 为上述真实几何计算结果。每个 corner receiver（center无零坐标、R=1）捕获一个 disjoint source block，这2^n个 blocks 分割全部来源。因此任何 q-exact 可行场都强制 `q=θ=2^-n`。约束为

`Σ_i B_ji a_i = q R_j^n`。

uniform a_i=4^-n 在两场都严格可行。实际 q-band 比例 r=1，octave `maxR/minR≤2`；每个 cell 的完整质量都由同一全 f 计算。不是截断质量或浮点mask。无需另假设 θ。

这些场具有真实 source/center 体积、完整 mass/matching、q-band 和 octave，但未实现原 current/rank/soft/path/history；也未证明 selected R 是另一个连续尺度极大化问题的 winner。本题测量只针对这些指定 selector 场，不能称原完整历史全流证书。

## 2. 精确目标和 LP/dual 标准符号

`J_i=Σ_j v B_ji/m_j`，在整个 source packet 上常数。令 `d_i=Σ_j v B_ji/R_j^n`。完整匹配给 `qJ_i=d_i`，故真实目标恰是

`q² ∫fJ²/W = Σ_i a_i d_i²`。

为改善数值尺度，脚本优化 `c_i=(d_i/v)²`，最后乘回 v²。LP 为 `max c·a`，约束 `Ba=t`、`Σa=1`、a≥0，t_j=qR_j^n。dual 是

`min β+Σ_j λ_j t_j`，`β+Σ_j λ_j B_ji≥c_i`（每个 source i），λ和β自由。

SciPy HiGHS 仅寻找候选；a、λ、β 均恢复为 Fraction。脚本逐项核完整约束、所有 dual columns、primal=dual。六例 dual repair 均0；float equality residual 均0只是诊断，证书结论使用 Fraction。所有优化是对固定真实几何中**全部非负 source masses**的上界，不是一次猜测质量。若要求每个候选 packet 都严格正质量，可将最优 a 与 uniform 以 ε 混合；匹配仍严格相等，目标为两者线性混合，ε→0达到同一supremum。

## 3. 初步、压力、扩大：实际六例

| 阶段 | n | selector | uniform 真目标 | 精确最优真目标 | opt/uniform | support数 |
|---|---:|---|---:|---:|---:|---:|
| 初步 | 1 | R=1 | .576 | .576 | 1 | 2 |
| 初步 | 1 | 中央R=2 | .5184 | .5184 | 1 | 2 |
| 压力 | 2 | R=1 | .331776 | .331776 | 1 | 4 |
| 压力 | 2 | 中央R=2 | .29528064 | .32182272 | 97/89 | 4 |
| 有限扩大 | 3 | R=1 | .191102976 | .191102976 | 1 | 8 |
| 有限扩大 | 3 | 中央R=2 | .178299076608 | .196644962304 | 343/311 | 16 |

这里小数均为对应精确有理数的终止表示。两尺度 n2、n3 的 uniform gaps 分别为 `10368/390625=.02654208`、`4478976/244140625=.018345885696`。两尺度 n2 最优仍低于单尺度 n2；n3 则高出 .005541986304。没有新增维数、其他pattern或自由扫描。

### 单尺度不是集中增益

一维 capture rows 的系数 `(1,3,1)` 满足 source-wise identity `(d_i/v)²=Σ_j λ_jB_ji`。tensor 化给 `λ_center=3^(center零坐标数)`，脚本在 n=1,2,3 对每个 source 精确检查 identity，所有 dual slack=0。结合 m_j=q（R=1）得

`Σa_i(d_i/v)² = qΣλ_j=(5/2)^n`，

故真目标恒等 `(72/125)^n=.576^n`，对任意可行 source a 都相同。LP 的稀疏质量只是一个最优代表，不能解释成搜索获得集中收益。

### 两尺度允许的关联

令 inner 指坐标绝对值1/4。将中央R=1块改为R=2后，该块捕获全部来源，替代了原“所有坐标inner”质量约束；这释放了高阶相关性，同时也改变 d_i。n2最优的 inner坐标数分布为 `(1/2,0,1/2)`，每坐标inner边缘仍为1/2；inner事件正相关。n3最优分布为 `(0,3/4,0,1/4)`，各边缘仍1/2，是 odd-parity 关联；所有坐标inner的概率从 uniform 的1/8升至1/4。它说明单靠边缘占用或假定源tensor独立，可能丢失允许的二阶收益；不是一般维数增长证明。

### 实际最优support

按源坐标字母表 `(−3/4,−1/4,1/4,3/4)` 的 n-fold lexicographic顺序，索引从0开始。JSON存完整坐标及每项质量，以下为复现摘要：

- n1单尺度：索引0,2，各1/2；n1两尺度：0,3，各1/2。
- n2单尺度：4,6,12,14，各1/4；n2两尺度：3,5,10,12，各1/4。
- n3单尺度：8,16,22,30,40,48,54,62，各1/8。
- n3两尺度：1,7,8,14,16,22,25,31,35,37,42,44,50,52,59,61，各1/16。

上述不是唯一最优support，不做唯一性声明。

## 4. 复现和范围

使用指定数学解释器，Python3.12.14、SciPy1.18.1、NumPy2.5.4。当前冻结运行 .24秒、最大RSS74,661,888 bytes；3855项精确检查PASS。最大64变量、28条等式、27个receiver cells。脚本生成全部几何与捕获，JSON记录全原解、对偶、slacks、J、质量、体积与目标。无旧输入依赖，不读取NPZ、无repo/他人文件修改。

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r451_numeric.py
```

输出在脚本同目录。冻结白名单：`r451_numeric.py`、`r451_numeric_certificate.json`、`r451_numeric_run.txt`、`r451_numeric_resources.txt`、`r451_numeric.md`、`r451_numeric_compute_index.md`。完成停止。
