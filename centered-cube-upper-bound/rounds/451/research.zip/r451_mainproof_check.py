from fractions import Fraction as F
import sympy as S

x, A = S.symbols('x A')
def rat(v): return S.Rational(v.numerator,v.denominator) if isinstance(v,F) else S.Rational(v)
def overlap(l,r,c,R): return max(F(0),min(r,c+R/2)-max(l,c-R/2))
def fixture(d,Rc,Rr):
    groups=[(-F(1,4),F(1,4),Rc,Rc+2*d),(F(1),F(5,4),Rr,Rr)]
    assert all(F(1)<=m/R<=F(4,3) for l,r,R,m in groups)
    assert max(Rc,Rr)<=2*min(Rc,Rr)
    for l,r,R,m in groups:
        for a in (l,(l+r)/2,r):
            assert R+overlap(-d,d,a,R)==m
    pts=sorted(set([F(-4),F(4),-d,d]+[v for l,r,R,m in groups for v in (l-R/2,l+R/2,r-R/2,r+R/2)]))
    pieces=[]
    for l,r in zip(pts,pts[1:]):
        mid=(l+r)/2
        j=0; dd=0
        for el,er,R,m in groups:
            lo=max(el,mid-R/2); hi=min(er,mid+R/2)
            if lo<hi:
                lop=rat(el) if el>=mid-R/2 else x-rat(R/2)
                hip=rat(er) if er<=mid+R/2 else x+rat(R/2)
                j+=(hip-lop)/rat(m); dd+=(hip-lop)/rat(R)
        density=1+int(-d<mid<d)
        pieces.append((l,r,S.expand(j),S.expand(dd),density))
    def integ(poly,l,r): return S.integrate(poly,(x,rat(l),rat(r)))
    M2=sum(integ(f*j*j,l,r) for l,r,j,dd,f in pieces)
    U=sum(integ(dd*j,l,r) for l,r,j,dd,f in pieces)
    mean=sum(integ(f*j,l,r) for l,r,j,dd,f in pieces)
    W=8+4*rat(d)/2
    assert mean==sum(rat(r-l) for l,r,R,m in groups)
    def primitive(which, endpoint, amid):
        val=0
        for l,r,j,dd,f in pieces:
            pol=j*(f if which=='fJ' else 1)
            if endpoint.subs(A,rat(amid))>=rat(r): val+=integ(pol,l,r)
            elif endpoint.subs(A,rat(amid))>rat(l):
                val+=S.integrate(pol,(x,rat(l),endpoint)); break
            else: break
        return S.expand(val)
    cov=0
    for l,r,R,m in groups:
        cuts=sorted(set([l,r]+[p+sgn*R/2 for p in pts for sgn in (-1,1) if l<p+sgn*R/2<r]))
        for al,ar in zip(cuts,cuts[1:]):
            mid=(al+ar)/2
            fj=primitive('fJ',A+rat(R/2),mid)-primitive('fJ',A-rat(R/2),mid)
            jj=primitive('J',A+rat(R/2),mid)-primitive('J',A-rat(R/2),mid)
            # Exactly the double-source covariance divided by 2 m |Q|.
            pol=(2*rat(R)*fj-2*rat(m)*jj)/(2*rat(m)*rat(R))
            cov+=S.integrate(pol,(A,rat(al),rat(ar)))
    assert S.simplify(M2-U-cov)==0
    assert M2>=mean**2/W
    return M2,U,S.simplify(cov)

rows=[]
for stage, configs in [
    (1,[(F(1,8),F(1),F(1))]),
    (2,[(F(1,16),F(1),F(3,2)),(F(1,8),F(3,2),F(1))]),
    (3,[(d,Rc,Rr) for d in (F(1,32),F(1,16),F(1,8)) for Rc,Rr in ((F(1),F(1)),(F(3,2),F(3,2)))])]:
    for cfg in configs:
        result=fixture(*cfg)
        rows.append((stage,*(str(v) for v in cfg),*(str(v) for v in result)))
print('PASS: 9 native continuous-center fixtures, exact rational polynomial integrals.')
print('stage,d,Rcentral,Rremote,M2,uniform-term,signed-defect')
for row in rows: print(','.join(map(str,row)))
print('Each fixture: positive Lebesgue center intervals; single-valued side selector; full f=1[-4,4]+1[-d,d]; q-band [1,4/3]; octave sides.')
print('Checks: matching at selector breakpoints, first-moment identity, covariance factor/sign identity, and Cauchy. No original historical gates certified.')
