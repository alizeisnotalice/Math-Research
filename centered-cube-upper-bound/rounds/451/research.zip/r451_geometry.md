# R451 — one source-mass growth attempt, with the common selector retained

**Outcome.** No new estimate for the target
\[
q^2\int fJ^2\le Cn\operatorname{polylog}(n+2)W
\tag{1}
\]
is proved. The bounded attempt checks whether nested, source-capturing cubes along center rays supply the missing mass-growth control. They do supply a genuine full-source monotone quantity. Using it with the actual side lengths remains comparable to the original occupancy; removing those side lengths loses precisely the common-selector constraint. Neither observation disproves (1). The original flow and all existing fees remain unchanged.

## 1. Exact candidate and its native scope

Let \(f\ge0\) be integrable, \(W=\int f\), and let \(E\) be the actual measurable Lebesgue receiver set, with
\[
m_A=f(Q_A)=q_AR_A^n,\quad q\le q_A\le\lambda,
\quad a\le R_A\le b\le2a.
\]
Here \(R_A\) is the cube **side length**. Set \(c_A=1_{Q_A}\) and
\(J(y)=\int_Ec_A(y)dA/m_A\). All the following quantities use this same \(f\) and the same selected \(R_A\).

For a captured source \(y\), put \(r=\|A-y\|_\infty\). The minimal cube centered at \(A\) which captures \(y\) is \(Q(A,2r)\). Define
\[
M_{A,y}=f(Q(A,2r)).
\]
Writing \(A=y+r\omega\), \(\|\omega\|_\infty=1\), these cubes are
\(y+r(\omega+[-1,1]^n)\). They are nested as \(r\) increases along a fixed ray: every coordinate lower endpoint is nonincreasing and every upper endpoint nondecreasing. Moreover \(2r\le R_A\), so
\[
0\le M_{A,y}\le m_A,\qquad
\frac1{m_A}\le
\frac1{\max(qR_A^n,M_{A,y})}.
\tag{2}
\]
This uses actual captured source mass, not a boundary-volume estimate.

The screened candidate was to use this monotone mass to obtain a useful bound on
\[
J_{\rm growth}(y)=
\int_E\frac{c_A(y)}{\max(qR_A^n,M_{A,y})}\,dA.
\tag{3}
\]
But keeping the selected side lengths gives the exact scope bound
\[
J(y)\le J_{\rm growth}(y)\le\frac\lambda qJ(y).
\tag{4}
\]
Indeed the denominator in (3) is between \(qR_A^n\) and \(m_A\), and \(m_A/(qR_A^n)\le\lambda/q\). Thus (3) does not itself reduce the dimensional difficulty of the two-center integral. It remains possible to prove a joint geometric estimate for (3), but no such estimate was obtained here.

## 2. Why the tempting sourcewise radial optimization cannot supply that step

If the actual selector is discarded, (2) leads to the larger source-dependent envelope
\[
\int_{\|A-y\|_\infty\le b/2}
\frac{dA}{\max\{q\max(a,2\|A-y\|_\infty)^n,M_{A,y}\}}.
\tag{5}
\]
The source-dependent lower cubes in (5) are real; the simultaneous choice of the larger selected cubes has disappeared.

On a sufficiently large constant plateau \(f=q\), for every source well inside that plateau,
\(M_{A,y}=q(2\|A-y\|_\infty)^n\) throughout this integration domain. Consequently (5) is exactly
\[
\frac1q+\frac nq\int_a^b\frac{dt}{t}
=\frac{1+n\log(b/a)}q.
\tag{6}
\]
For example, \(f=q1_{[-2b,2b]^n}\) supplies such a plateau for \(y\in[-b,b]^n\). Squaring this relaxed bound costs the old quadratic dimensional factor on a positive source set. This is a statement about the relaxation, not a lower bound for the occupancy of any one fixed selector, and not a counterexample to (1).

The remaining geometric step is therefore specific: control the simultaneous two-center repetitions with both actual \(R_A,R_B\), subject to the same full matching equations \(f(Q_A)=q_AR_A^n\) and \(f(Q_B)=q_BR_B^n\). Independent raywise source growth cannot replace that coupling. In particular, neither the source law nor the selected-center law has a product-coordinate structure merely because the ambient cubes are products.

## 3. A valid common-selector identity, and its price

There is a useful exact check on what full matching does preserve. For each fixed actual \(A\), if \(Y\sim\pi_A=f c_A/m_A\), then
\[
V_A(Y)=\frac{f(Q(A,2\|Y-A\|_\infty))}{m_A}
\]
is uniform on \([0,1]\). The radial capture mass is continuous: spheres for the \(\ell^\infty\) norm are Lebesgue-null, and \(f\,dy\) is absolutely continuous. Its distribution function is continuous even if it has flat portions; the probability-integral transform therefore applies. Values at zero-rank sources have \(\pi_A\)-measure zero.

In particular,
\[
\int\pi_A(dy)\log\frac{m_A}{M_{A,y}}=1,
\qquad
\int\pi_A(dy)V_A(y)^{-p}=\frac1{1-p}\quad(0<p<1).
\tag{7}
\]
These identities cost \(|E|\) when integrated in \(dA\), or \(X_q\) when integrated in \(\sigma=q_A dA\). They do **not** bound the additional factor \(J(y)\) occurring in the desired second moment. No independence between the ranks belonging to two actual centers follows. Thus (7) is recorded as an exact retained-selector identity, not a new root-scale source payment.

A concrete next decision is to retain the common selector in any proposed two-center mass-growth estimate; replacing it by (5), or replacing the source mixture by a product distribution, already removes the information needed to improve the square. The present attempt does not establish that estimate and stops here.

## 4. Actual local computation and limits

The designated local Python ran `/tmp/r451_geometry_check.py`; stdout is `/tmp/r451_geometry.result.txt`.

1. Twelve exact Fraction coordinate checks verify nesting and inclusion of the minimal cubes in three dimensions/configurations.
2. Twelve exact SymPy checks verify the radial-rank moments for the full nonuniform sources \(f(x)=1+\|x\|_\infty^2\) on \([-1,1]^n\), \(n=1,2,4\), and moment orders \(0,1,2,3\). These are one-cube source identities, not receiver-field tests of (1).
3. A real continuous-center field is checked exactly in dimension one: \(f=1_{[-2,2]}\), \(E=[-1,1]\), \(R_A=\max(1,2|A|)\). It satisfies \(m_A=R_A\) and \(q_A=1\). For \(0<y<1\), \(J(y)=1-y+\tfrac12\log2\); for \(1\le y<2\), \(J(y)=\tfrac12\log(2/y)\); use symmetry for negative sources. Thus
\[
\int fJ=2,\qquad \int fJ^2=\frac53.
\]
At the single point \(y=0\), aligned closed faces give \(J(0)=1+\log2\), which does not affect either source integral. This illustrates the distinction between a selector's actual occupancy and the free sourcewise envelope. It does not settle high-dimensional behavior.

The first script run detected an incorrect hand-entered expected expression for the last second moment; the exact symbolic result is \(5/3\), and the assertion was corrected before the saved successful run. No finite computation is being used as a proof of (1), or as a disproof of the desired general budget. No additional source price, absorbable error, or paid branch was obtained.
