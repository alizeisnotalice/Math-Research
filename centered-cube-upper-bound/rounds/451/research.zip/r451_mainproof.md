# R451 — symmetrizing the matching error without discarding its sign

**Status.** One candidate was screened: replace one actual source posterior by the uniform law on the same actual cube, then use the matching constraint before estimating the error. The resulting symmetric overlap error has a precise sign-sensitive form. No new bound on the complete remainder, or on the desired second moment, was proved. The calculation identifies why uniform-center estimates alone do not complete this route. It does not introduce a new paid remainder.

## 1. Actual field and candidate

Let f≥0 belong to L¹, W=∫f, and let E have actual Lebesgue center measure. The measurable single-valued side selector obeys a≤R_A≤b≤2a. Write V_A=R_A^n, c_A=1_QA,

    m_A=∫f c_A=q_A V_A,   q≤q_A≤λ,
    J(y)=∫E c_A(y)dA/m_A,
    D(y)=∫E c_A(y)dA/V_A,
    M2=∫f J²,   An=1+n log(b/a).

The elementary actual-center bound J≤An/q and matching give ∫fJ=|E|, so all integrals below are finite. In particular |E|≤An W/q. Also qJ≤D≤λJ pointwise. There is no imposed bound on f and no modification of the receiver selector.

The precise candidate was to estimate the signed error Δ in

    M2 = U + Δ,       U=∫ D(y)J(y)dy.                         (1)

The point of doing the matching cancellation first is that Δ involves **excess mass of actual intersections over their uniform template**, not the absolute size of f. The question is whether this excess has a globally integrable favorable sign or a source-sized positive part.

## 2. Exact geometric symmetrization

Set I_AB=f(Q_A∩Q_B) and v_AB=|Q_A∩Q_B|. Tonelli and then symmetry in actual centers give

    Δ=∫E² [I_AB−(q_A+q_B)v_AB/2] dA dB/(m_A m_B).           (2)

Equivalently, using m_A=q_A V_A **inside each actual cube**,

    Δ=∫E dA/(2m_A V_A)
          ∫QA×QA [f(y)−f(z)][J(y)−J(z)]dy dz.               (3)

Both signs and the factor 1/2 matter. To prove (3), expand its inner integral: it equals

    2V_A∫QA fJ − 2m_A∫QA J.

After dividing and integrating this is M2−U. Inserting
J(y)−J(z)=∫[c_B(y)−c_B(z)]dB/m_B gives the actual incidence form

    Δ=∫E² dA dB/(m_A V_A m_B)
          ∫(QA∩QB)×(QA\QB) [f(y)−f(z)]dy dz.              (4)

Thus the part needing control is a source-density imbalance between the intersection and the complementary part of the **same parent**, averaged against its real second receiver. A boundary-volume bound is not a bound for (4).

For clarity about the geometric constraint missing from a putative union argument, let qbar=(q_A+q_B)/2. The numerator in (2) is exactly

    qbar |QA∪QB| − f(QA∪QB)
      + (q_A−q_B)(V_A−V_B)/2.                              (5)

When q_A=q_B, it is the negative of the uniform-template mass excess on the union. The union is not generally an actual receiver. Its average cannot be assigned the original q-band. For different q_A the last term is indispensable; it cancels with the union term even for disjoint cubes. We do not separately charge these two terms or assume matching on fictitious unions.

## 3. What a uniform-center estimate would and would not establish

Let T_R u(A)=V_A^−1∫QA u on the same actual selector and put N=||T_R||_{L²(dy)→L²(dA)}. This notation describes the uniform comparison only; no external maximal theorem is invoked as a new allowed receipt. Since D=T_R*1_E,

    U≤q^−1||D||²₂≤N²|E|/q.                                (6)

Even granting a dimension-independent N, (6) does not estimate Δ. For example, a sufficient absorption estimate would be

    Δ≤θ M2 + C n log^a(n+2)W/q²,   0≤θ<1.                 (7)

Together with |E|≤sqrt(W M2), (6) and Young's inequality would imply

    M2≤[N⁴/(1−θ)² + 2C n log^a(n+2)/(1−θ)] W/q².          (8)

Here (7) is **unproved**. It is stated to make the failed step falsifiable, not to count a renamed target as progress. In particular, replacing the signed expression (4) by its absolute value would be a stronger assertion for which no estimate has been obtained.

The R434 clipped neighbor-cell entropy bounds an integrated local mass-ratio functional. It supplies neither a sign for (4) nor a proved comparison between (4) and its entropy dissipation: the density difference and the actual capture difference occur at two positions inside the same cube, and the selector can vary with its center. Applying an entropy or independent-coordinate inequality to those positions would require an additional argument. No such argument is supplied here.

The stopping decision is therefore to retain the exact signed overlap excess (2), rather than continue optimizing a uniform comparison that leaves it untouched. This is a scope check of one candidate, not a claim that all geometric symmetrization routes fail. No original BH square, cross, or clock credit has been deducted, so no previous receipt is reused.

## 4. Native exact checks and scope

The local math Python ran `r451_mainproof_check.py`; actual stdout is `r451_mainproof.result.txt`. It checks **9 continuous-center fixtures** in three stages (1, 2, and 6 fixtures), by exact rational polynomial integration, not center sampling.

In every fixture,

    f=1_[−4,4]+1_[−d,d],
    E=[−1/4,1/4] ∪ [1,5/4].

The side is constant on each of these two disjoint positive-length center intervals and belongs to {1,3/2}. The central cubes contain the complete spike, the remote cubes miss it, and hence the full-f masses are exactly R_c+2d and R_r. The resulting q-band is contained in [1,4/3]. Source space includes the f=0 complement. The code verifies matching at the selector intervals' endpoints and interior, the exact first-moment identity, the double-source coefficient in (3), and the Cauchy inequality. The matching is constant throughout each interval by the displayed containment geometry; it is not certified merely by three sample points.

Actual values show why the signed error cannot simply be dropped:

- d=1/8, sides (1,1): Δ=59/9600>0.
- d=1/8, sides (3/2,3/2): Δ=−5/7056<0.

These are legitimate full-f/real-center/q-band/octave calculations. They do **not** certify the original high-rank, strict-far, deletion, or path-history gates and are not counterexamples to the requested general estimate. The general identities (1)–(5) are proved analytically above. The missing payment is (7), or another estimate of the same signed overlap excess retaining enough actual geometry; neither it nor the complete R budget has been established in this task.
