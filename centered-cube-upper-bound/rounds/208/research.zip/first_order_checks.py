#!/usr/bin/env python3
"""R208 finite first-order algebra and physical face diagnostics; noninterval."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import mpmath as mp
HERE=Path(__file__).resolve().parent

def fmt(x,p):return mp.nstr(x,p)
def h(t):return t/(1+t)

def phi(x):
    r=abs(x);half=mp.mpf('.5')
    if r>=half:return mp.expint(3,r-half)-mp.expint(3,r+half)
    return 1-mp.expint(3,half-r)-mp.expint(3,half+r)

def fs(x,s):return (1-s)*int(abs(x)<=mp.mpf('.5'))+s*phi(x)

def scalar_checks():
    rows=[]
    for theta_text in ['.25','.5','.75','.999']:
        runs=[]
        for p in (25,50):
            with mp.workdps(p):
                theta=mp.mpf(theta_text);star=(1-theta)/theta;C=theta**theta*(1-theta)**(1-theta)
                assert abs(C-h(star)/star**theta)<mp.mpf(10)**(-p+3)
                stationary=1/(1+star);assert abs(stationary-theta)<mp.mpf(10)**(-p+3)
                tests=[]
                for label,t in [('zero',mp.mpf(0)),('small',star/100),('below',star*mp.mpf('.9')),('maximum',star),('above',star*mp.mpf('1.1')),('far',star+100)]:
                    actual=h(t);bound=C*t**theta
                    assert actual<=bound+mp.mpf(10)**(-p+3)
                    tests.append(dict(label=label,t=fmt(t,p),h=fmt(actual,p),majorant=fmt(bound,p)))
                runs.append(dict(dps=p,t_star=fmt(star,p),C_theta=fmt(C,p),stationarity_theta=fmt(stationary,p),tests=tests))
        rows.append(dict(stage=('initial' if theta_text=='.25' else 'stress' if theta_text in ('.5','.75') else 'expanded'),theta=theta_text,runs=runs))
    endpoints=[]
    with mp.workdps(50):
        for t in map(mp.mpf,['0','.000001','1','1000000']):
            assert h(t)<=t
            if t>0:assert h(t)<t
            endpoints.append(dict(t=fmt(t,50),h=fmt(h(t),50),theta1_bound=fmt(t,50)))
    return dict(cases=rows,theta1_endpoint=dict(C_theta='1',positive_finite_t_never_attains=True,tests=endpoints),scope='Finite scalar evaluations and stationary equation; no uniform proof from this menu.',status='PASS_NUMERICAL_NONINTERVAL')

@lru_cache(maxsize=None)
def physical_factors(tt,ss,gg,dd,p,target_text):
    with mp.workdps(p):
        theta,s,g,d=map(mp.mpf,[tt,ss,gg,dd]);target=mp.mpf(target_text)
        rate=1-theta+theta/g
        logpref=mp.log(2*s)-theta*mp.log(g)+mp.mpf('.5')+theta*abs(d)/g-mp.log(rate)
        X=max(abs(d)+g/2+1,mp.mpf('1.5'),(logpref-mp.log(target))/rate+1)
        seams=sorted(set([-X,-mp.mpf('.5'),mp.mpf('.5'),d-g/2,d+g/2,X]))
        integral=sum(mp.quad(lambda u:fs(u,s)**(1-theta)*fs((u-d)/g,s)**theta,[lo,hi]) for lo,hi in zip(seams,seams[1:]))
        A=g**(-theta)*integral;tail=mp.exp(logpref-rate*X)
        assert tail<=target and 0<A<=A+tail<=1+mp.mpf('1e-15')
        face=(1-s)**theta*g**(-theta)*abs(d)*(fs(d-g/2,s)**(1-theta)+fs(d+g/2,s)**(1-theta))
        tstar=(1-theta)/theta;C=h(tstar)/tstar**theta
        return dict(dps=p,cutoff=fmt(X,p),seams=[fmt(v,p) for v in seams],A_truncated=fmt(A,p),A_tail_upper=fmt(tail,p),A_plus_analytic_tail=fmt(A+tail,p),face_c_theta=fmt(face,p),scalar_C_theta=fmt(C,p),C_times_face_c=fmt(C*face,p),tail_rate=fmt(rate,p),tail_target=target_text)



def positive(x):return max(F(0),x)

def denominator_checks(initial=False):
    table=[('initial',F(1),F(1),F(0)),('initial',F(1),F(1),F(1,2)),('initial',F(1),F(1),F(1)),('stress',F(0),F(1),F(1)),('stress',F(1),F(64),F(1)),('stress',F(1),F(1,64),F(1)),('expanded',F(1,10**6),F(10**6),F(1,10**12)),('expanded',F(10**6),F(1,10**6),F(10**12)),('expanded',F(7,11),F(13,17),F(19,23))]
    if initial:table=table[:3]
    rows=[]
    for stage,P,B,delta in table:
        sharpJ=P/B if P else F(1);experiments=[]
        for J in (sharpJ/2,sharpJ,2*sharpJ):
            for S in (J,2*J):
                for rho in (F(0),F(1,2),F(1)):
                    actual=rho*min(P,B*J)*J*delta/(S*(S+delta))
                    first=rho*min(P,B*J)*delta/(J+delta)
                    upper=F(0) if P==0 else rho*P*(B*delta)/(P+B*delta)
                    assert 0<=actual<=first<=upper
                    if P and J==sharpJ and S==J:assert actual==upper
                    independent=rho*min(P,B*J)*(J/S)*(delta/(S+delta));assert actual==independent
                    experiments.append(dict(J=J,S=S,rho=rho,D1=actual,independent_D1=independent,S_ge_J_bound=first,sharp_envelope=upper,sharp_J_equality=bool(P and J==sharpJ and S==J)))
        rows.append(dict(stage=stage,P=P,B=B,delta=delta,sharp_J=sharpJ if P else None,experiments=experiments))
    return dict(cases=rows,status='PASS_FINITE_EXACT',scope='Conditional scalar D1 inequality, not original physical/capture/history qualification. P=0 handled before ratio.')


def alpha_checks(initial=False):
    table=[('initial',F(0),F(0)),('initial',F(1),F(0)),('initial',F(1),F(1)),('stress',F(1,2),F(0)),('stress',F(1,2),F(1,2)),('stress',F(0),F(1)),('expanded',F(999,1000),F(999,1000)),('expanded',F(1,1000),F(1,2)),('expanded',F(3,5),F(5,13))]
    if initial:table=table[:3]
    rows=[]
    for stage,c,r in table:
        upper=c*(1-r);checks=[]
        for z in (F(0),F(1,4),F(1),F(4)):
            before=positive(1-z);after=positive(1-r*z);signed=c*after-before
            charge=positive(signed);assert signed<=upper and charge<=upper
            if z==1:assert signed==upper
            checks.append(dict(z=z,rho_minus=before,rho_plus=after,actual_signed_net=signed,positive_charge=charge,upper=upper))
        rows.append(dict(stage=stage,c=c,r=r,checks=checks))
    return dict(cases=rows,status='PASS_FINITE_EXACT',scope='Normalized linked-alpha profile: alpha_plus=r alpha_minus. c=0 is boundary limit, not finite positive S/(S+delta). Negative signed nets are not free credits; no full-source capture qualification.')


def capture_capacity_checks():
    specifications=[('initial','positive_alpha',[(F(2),F(1),F(1)),(F(3),F(1),F(1)),(F(2),F(1),F(1))],F(5),[F(0),F(1)]),('stress','alpha_plus_zero',[(F(2),F(1),F(1)),(F(3),F(1),F(1)),(F(2),F(1),F(1))],F(3),[F(1),F(0)]),('expanded','inactive_and_delta_zero',[(F(2),F(1),F(1)),(F(1),F(2),F(1)),(F(2),F(1),F(1))],F(5),[F(0),F(1)])]
    rows=[]
    for stage,label,atoms,C,deltas in specifications:
        nu=[F(1)]*3;a=[x[0] for x in atoms];k=[x[1] for x in atoms];J=[x[2] for x in atoms]
        Eminus=[True,True,False];Eplus=[True]*3;T=[0,1]
        Q=sum(J[i]*nu[i] for i in range(3))
        Uminus=[F(Eminus[i])*min(a[i],k[i]) for i in range(3)]
        Uplus=[F(Eplus[i])*min(a[i],k[i]) for i in range(3)]
        Hminus=C-sum(Uminus[i]*nu[i] for i in range(3));Hplus=C-sum(Uplus[i]*nu[i] for i in range(3))
        G=sum((Uplus[i]-Uminus[i])*nu[i] for i in range(3))
        assert Q>0 and C>=sum(k[i]*nu[i] for i in range(3)) and Hminus>=Hplus>=0
        assert all(not Eminus[i] or Eplus[i] for i in range(3)) and G==Hminus-Hplus
        alpha_minus=Hminus/Q;alpha_plus=Hplus/Q
        assert alpha_minus>0 and Hminus==alpha_minus*Q and Hplus==alpha_plus*Q
        r=alpha_plus/alpha_minus;assert 1-r==G/Hminus
        P=F(3,2);B=F(1);targets=[]
        recovered=slack=denominator=weighted_signed=weighted_positive=F(0)
        for i in T:
            assert Eminus[i] and a[i]>0 and J[i]>0
            S=F(2);delta=deltas[i];assert S>=J[i] and delta>=0
            d=1-k[i]/a[i];rm=positive(d-alpha_minus*J[i]/a[i]);rp=positive(d-alpha_plus*J[i]/a[i]);M=min(P,B*J[i])
            gain=a[i]*(rp-rm)
            threshold=(a[i]-k[i])/J[i]
            inactive_length=positive(alpha_minus-max(alpha_plus,threshold))
            loss=J[i]*inactive_length
            assert gain==(alpha_minus-alpha_plus)*J[i]-loss and gain>=0
            Vm=M*J[i]*rm/S;Vp=M*J[i]*rp/(S+delta);omega=M*J[i]/(a[i]*(S+delta))
            negative=M*J[i]*delta*rm/(S*(S+delta))
            assert Vp-Vm==M*J[i]*(rp-rm)/(S+delta)-negative
            D=a[i]*delta*rm/S
            assert (Vp-Vm)/omega==gain-D and 0<=positive(Vp-Vm)/omega<=gain
            recovered+=nu[i]*gain;slack+=nu[i]*loss;denominator+=nu[i]*D
            weighted_signed+=nu[i]*(Vp-Vm)/omega;weighted_positive+=nu[i]*positive(Vp-Vm)/omega
            targets.append(dict(index=i,S=S,delta=delta,d=d,rho_minus=rm,rho_plus=rp,a_delta_rho=gain,inactive_alpha_interval_length=inactive_length,exact_inactive_slack=loss,Vminus=Vm,Vplus=Vp,actual_signed_deltaV=Vp-Vm,actual_negative_denominator_term=negative,omega=omega,weighted_denominator_loss=D,zero_delta_positive_recovery=delta==0 and gain>0,inactive_both=rm==rp==0))
        JT=sum(J[i]*nu[i] for i in T)
        assert recovered==(G/Q)*JT-slack and 0<=recovered<=G
        assert weighted_signed==(G/Q)*JT-slack-denominator and weighted_signed<=G-denominator
        assert 0<=weighted_positive<=recovered<=G
        if label=='alpha_plus_zero':assert alpha_plus==0
        if label=='inactive_and_delta_zero':assert any(t['inactive_both'] for t in targets) and any(t['zero_delta_positive_recovery'] for t in targets)
        entry=sum(nu[i]*positive(a[i]-k[i]-alpha_plus*J[i]) for i in range(3) if Eplus[i] and not Eminus[i])
        rows.append(dict(stage=stage,label=label,nu=nu,a=a,k=k,J=J,Dq=C,Eminus=Eminus,Eplus=Eplus,T=T,Uminus=Uminus,Uplus=Uplus,Q=Q,Hminus=Hminus,Hplus=Hplus,G=G,alpha_minus=alpha_minus,alpha_plus=alpha_plus,r=r,P=P,B=B,targets=targets,total_a_delta_rho=recovered,JT=JT,total_inactive_slack=slack,total_weighted_denominator_loss=denominator,weighted_signed_deltaV=weighted_signed,weighted_positive_charge=weighted_positive,capacity_upper=G,excluded_new_entry_a_rho=entry))
    return dict(cases=rows,status='PASS_FINITE_EXACT',scope='Three common finite source/capture models with actual U/E recomputation. Only persistent T subset Eminus is charged to G; new-entry potential is recorded separately and not declared paid. Weights omega are not original raw/posterior weights; no physical/FIRST/FULL realization.')


def posterior_clock_checks():
    specifications=[('initial','two_sources',[F(1),F(2)],[F(1),F(1,2)],[F(0),F(1)],[[F(1),F(2)],[F(3),F(1)]],[[F(1),F(2)],[F(3),F(1)]],{1}),('stress','changed_f',[F(1),F(1,4),F(2)],[F(1,2),F(1),F(1,4)],[F(2),F(0),F(1,2)],[[F(1),F(1,2),F(0)],[F(2),F(3),F(1)],[F(0),F(1,4),F(1)]],[[F(1,2),F(1),F(1)],[F(0),F(2),F(1,2)],[F(1),F(1),F(2)]],{0}),('expanded','repeated_scores_two_deleted',[F(1,8),F(2),F(1,2),F(3)],[F(1),F(1,4),F(1,2),F(1,8)],[F(0),F(3,2),F(3,2),F(5)],[[F(1)]*4,[F(1,2)]*4,[F(1,4)]*4,[F(0)]*4],[[F(1,2),F(1),F(1,4),F(0)],[F(1),F(1,4),F(0),F(1,2)],[F(1,4),F(0),F(3,4),F(1)],[F(0),F(1,2),F(1),F(1,2)]],{0,3})]
    rows=[]
    for stage,label,nu,w,k,fminus,fplus,deleted in specifications:
        n=len(nu);assert all(v>0 for v in nu) and all(0<v<=1 for v in w) and all(v>=0 for v in k)
        e=sum(nu[i]*w[i] for i in range(n));Pi=[nu[i]*w[i]/e for i in range(n)]
        kbar=sum(k[i]*Pi[i] for i in range(n));Pidot=[(kbar-k[i])*Pi[i] for i in range(n)]
        mu=[[Pi[i]*Pi[j] for j in range(n)] for i in range(n)]
        mudot=[[Pidot[i]*Pi[j]+Pi[i]*Pidot[j] for j in range(n)] for i in range(n)]
        assert sum(Pi)==1 and sum(Pidot)==0
        for i in range(n):
            for j in range(n):assert mudot[i][j]==(2*kbar-k[i]-k[j])*mu[i][j]
        Ydot=sum(fminus[i][j]*mudot[i][j] for i in range(n) for j in range(n))
        flux=sum(fminus[i][j]*positive(k[i]-k[j])*mu[i][j] for i in range(n) for j in range(n))
        compensation=sum(fminus[i][j]*(2*kbar-k[j]-min(k[i],k[j]))*mu[i][j] for i in range(n) for j in range(n))
        assert flux==-Ydot+compensation
        epost=sum(nu[i]*w[i] for i in range(n) if i not in deleted)
        d=sum(Pi[i] for i in deleted);assert 0<=d<1 and epost==e*(1-d)
        Pipost=[F(0) if i in deleted else nu[i]*w[i]/epost for i in range(n)]
        mupost=[[Pipost[i]*Pipost[j] for j in range(n)] for i in range(n)]
        R=[[mu[i][j] if i in deleted or j in deleted else F(0) for j in range(n)] for i in range(n)]
        Rmass=sum(sum(row) for row in R);assert Rmass==2*d-d*d
        scale=1/(1-d)**2
        for i in range(n):
            for j in range(n):assert mupost[i][j]==scale*(mu[i][j]-R[i][j])
        oldY=sum(fminus[i][j]*mu[i][j] for i in range(n) for j in range(n))
        postY=sum(fplus[i][j]*mupost[i][j] for i in range(n) for j in range(n))
        renorm=(scale-1)*sum(fplus[i][j]*mu[i][j] for i in range(n) for j in range(n))
        removal=-scale*sum(fplus[i][j]*R[i][j] for i in range(n) for j in range(n))
        exchange=sum((fplus[i][j]-fminus[i][j])*mu[i][j] for i in range(n) for j in range(n))
        assert postY-oldY==renorm+removal+exchange
        constant_renorm=scale-1;constant_removal=-scale*Rmass
        assert constant_renorm+constant_removal==0 and sum(sum(row) for row in mupost)==1
        rows.append(dict(stage=stage,label=label,nu=nu,w=w,k=k,e=e,Pi=Pi,kbar=kbar,Pidot=Pidot,mu=mu,mudot=mudot,fminus=fminus,fplus=fplus,continuous_fixed_f=dict(Ydot=Ydot,positive_score_flux=flux,compensation=compensation,identity_rhs=-Ydot+compensation),deletion=dict(deleted=sorted(deleted),d=d,e_after=epost,Pi_after=Pipost,Rmass=Rmass,double_renormalization_factor=scale,Yminus=oldY,Yplus=postY,actual_jump=postY-oldY,renormalization=renorm,negative_removal=removal,coefficient_exchange=exchange,three_term_sum=renorm+removal+exchange,constant_f_one=dict(actual_jump=F(0),renormalization=constant_renorm,removal=constant_removal,exchange=F(0),sum=constant_renorm+constant_removal))))
    return dict(cases=rows,status='PASS_FINITE_EXACT',scope='Finite positive source-weight/posterior algebra with local wdot=-k w, fixed-f instantaneous continuous identities and one complete concurrent deletion per case. Arbitrary f changes are explicit; no time-integrated original forest/FIRST/FULL claim or free deletion credit.')


def nonlinear_face_checks(initial=False):
    table=[(1,'.5','1','.25','1','.5'),(2,'.25','1','.25','1','.5'),(2,'.5','1.2','.5','2','.5'),(2,'.99','1','.1','16','.75'),(2,'.01','2','.75','64','.25'),(2,'.999','1.005','2','.0625','.999')]
    if initial:table=table[:2]
    rows=[]
    for index,(n,ss,gg,dd,BB,tt) in enumerate(table):
        runs=[]
        for p,target in [(25,'1e-18'),(50,'1e-36')]:
            factors=physical_factors(tt,ss,gg,dd,p,target)
            with mp.workdps(p):
                s,g,d,B,theta=map(mp.mpf,[ss,gg,dd,BB,tt]);X=mp.mpf(40)
                seams=sorted(set([-X,-mp.mpf('.5'),mp.mpf('.5'),d-g/2,d+g/2,X]))
                faces=[fs(d-g/2,s),fs(d+g/2,s)];face_integrals=[]
                for face in faces:
                    if n==1:
                        P=face;delta=(1-s)*g**(-n);value=P*h(B*delta/P)
                    else:
                        def integrand(u):
                            P=face*fs(u,s);delta=(1-s)*g**(-n)*fs((u-d)/g,s)
                            return P*h(B*delta/P)
                        value=sum(mp.quad(integrand,[lo,hi]) for lo,hi in zip(seams,seams[1:]))
                    face_integrals.append(value)
                NB=n*abs(d)*sum(face_integrals)
                tail=mp.mpf(0) if n==1 else n*abs(d)*sum(faces)*2*s*mp.exp(mp.mpf('.5')-X)
                A=mp.mpf(factors['A_truncated']);Atail=mp.mpf(factors['A_tail_upper']);facec=mp.mpf(factors['face_c_theta']);C=mp.mpf(factors['scalar_C_theta'])
                majorant=C*B**theta*n*facec*A**(n-1)
                majorant_tail=C*B**theta*n*facec*(A+Atail)**(n-1)
                assert 0<=NB<=NB+tail<=majorant_tail
                runs.append(dict(dps=p,cutoff='40',seams=[fmt(z,p) for z in seams],face_source_values=[fmt(z,p) for z in faces],individual_face_integrals=[fmt(z,p) for z in face_integrals],N1_truncated=fmt(NB,p),N1_tail_upper=fmt(tail,p),N1_plus_analytic_tail=fmt(NB+tail,p),matching_affinity_factors=factors,tensor_majorant_truncated_A=fmt(majorant,p),tensor_majorant_A_plus_tail=fmt(majorant_tail,p),ratio_N1_to_tensor=fmt(NB/majorant_tail,p)))
        with mp.workdps(60):
            difference=abs(mp.mpf(runs[0]['N1_truncated'])-mp.mpf(runs[1]['N1_truncated']))
            assert difference<mp.mpf('1e-18')*max(1,abs(mp.mpf(runs[1]['N1_truncated'])))
        rows.append(dict(stage=('initial' if index<2 else 'stress' if index<4 else 'expanded'),n=n,s=ss,gamma=gg,d=dd,B=BB,theta=tt,L='1',runs=runs,crossprecision_N1_difference=fmt(difference,50),status='PASS_NUMERICAL_NONINTERVAL'))
    return dict(cases=rows,scope='Original first-order P h1(B delta/P) evaluated on actual repeated-coordinate physical faces, only n=1/2 and fixed L=1. No high-dimensional original flux, adaptive selector, capture/history/FIRST/FULL realization.',tail_formula='n |d| sum_sign fs(d+sign gamma/2) * 2s exp(.5-40) for n=2; n=1 has no integration tail.',status='PASS_NUMERICAL_NONINTERVAL')


def enc(value):
    if isinstance(value,F):return str(value)
    if isinstance(value,dict):return {k:enc(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [enc(v) for v in value]
    return value

def run(initial=False):
    return dict(schema='r208_first_order_v1',stage_menu='initial' if initial else 'all',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},dependency=dict(name='mpmath',version=mp.__version__,entry_sha256=hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()),denominator=denominator_checks(initial),linked_alpha=alpha_checks(initial),capture_capacity=capture_capacity_checks(),posterior_clock=posterior_clock_checks(),majorant=scalar_checks(),physical_faces=nonlinear_face_checks(initial),status='PASS_FINITE_EXACT_AND_NONINTERVAL',limitations=['Fraction scalar fixtures are conditional algebra, not original physical or same-source full capture qualification.','Physical density and original first-order N1 are actually recomputed; no old JSON is imported.','25/50dps quadrature/constant comparisons are noninterval; analytic truncation tails do not certify numerical rounding.','Matching tensor uses C_theta B^theta, not B^(1+theta); the N1 analytic tail has no B factor.','Fixed source/scale n=1/2 diagnostics do not pay original source/selector/time/gate/capture/history/FULL costs.'])

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'first_order_checks.json');ap.add_argument('--stage',choices=('initial','all'),default='all');args=ap.parse_args()
    result=run(args.stage=='initial');args.output.write_text(json.dumps(enc(result),indent=2,sort_keys=True)+'\n');print(result['status'],result['stage_menu'])
