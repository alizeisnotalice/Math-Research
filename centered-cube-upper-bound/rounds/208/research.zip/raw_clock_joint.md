# R208：原一阶交通、双归一化与完整时钟乘积法则

状态：给出原量的精确身份、连续/删除/门交换账，以及一个无 `n` 的真实端点上界。没有证明一般根阶来源价。本文不修改原捕获、森林、接收选择器或负信用；一阶尺度面价另见父稿 `first_order_face_geometry.md`。

## 1. 原始量与出处

窄读原文件 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md`：RT1–3（约607–634行）给完整原raw与未消费负项；RT4（637–650行）给尺度、时钟和后验及其不依接收点的量词；RT5–6（652–673行）给good/bad、三个共同测试与同一捕获。以下只继承这些定义，不继承旧文未修复的任何 `ν≤β` 声明。

原外测度为
\[
d\mathcal T_I=1_I1_{j(x)=j}q^{-1}p_yh_{R(x)}(x-z)
 a_\omega(x,y,z)\,dx\,\beta_V(dy)\nu_V(dz).
\tag{RC1}
\]
这里硬源 `z` 不等于下式bad源 `u`。原正交通内层是
\[
\int_{J_{far}}\frac{dt}{t}\int_{D_g}\int_{S_g}
 \Psi\chi_{FA}\rho_v\delta_t(v,u)\Pi_t(dv)\Pi_t(du),
\qquad \delta_t(v,u)=[k_t(v)-k_t(u)]_+ .
\tag{RC2}
\]
原总代价带 `2Λ`，`Λ=128/119`，负项为原 `N_{Z^c}` 和 `N_del`，本文没有消费它们。

令
\[
 p_y=P_{s,L}(x-y),\quad p_v=P_{s,L}(x-v),\quad
 p_v^+=P_{s,L^+}(x-v),\quad J_v=P_{1,b}(x-v),
\quad S_v=p_v+p_v^++J_v=3Q_v,
\]
\[
 z_v=J_v/S_v,\qquad A_v=1_{S_g}(v)\rho_v z_v .
\]
`A_v` 是终端固定目标权，不是同名的原 `Δ=w_τ-w_h`。已直接窄读R127 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round127_20261014/proof.md` SP2–3（约264–282行）：`S_g=Z_g\setminus D_g`、`D_g,S_g⊂Z_g`，原RC2的target正是在S_g上积分。因此此处加入S_g不是新增门。其它包含后来删除target的不同泛函，不属于本端点断言，必须另留其删除交通。J-share另乘 `z_v`，不能称全部母raw。

只用一次原hard帽 `16/3` 后，J-share正项满足
\[
 Raw_J^+\le {32\Lambda\over3}\mathcal I_J,
\quad
\mathcal I_J=\mathbb E\sum_{V,j}\int_Edx\int\beta_V(dy)
 \int_\ell^g\!\frac{dt}{t}\iint p_y A_v H_t(v,u)\delta_t(v,u)
 \Pi_t(dv)\Pi_t(du).
\tag{RC3}
\]
`H∈[0,1]` 保留high、bad、FA、Ψ、history、唯一j、原far时间窗、有限截断和任何所研究正子域；原far外取零。若仍保硬源，只须在RC1测度上逐行应用后文；RC3已明确用过hard帽。所有dx在原接收域E，任何扩大均须另说明。score `δ_t` 没有放进一个声称≤1的门。

同一原测度的能量–伴随分离是
\[
 \mathcal I_J\le\sqrt{\mathcal E_J\mathcal C_J},\quad
 \mathcal E_J\le {n\over2K}W_\nu,\quad
 \mathcal C_J=\int {p_y^2A_v^2\over J_v}H_t\,d\beta\,dx\,\Pi_t^2\,d\log t.
\tag{RC4}
\]
出处为R173冻结 `mass_energy_audit.md` §§2.1–2.2，来源结尾按R181共同父修复为 `Wν,Wβ≤WA`，不使用ν≤β。因此伴随核仅降到√n，不能给原raw根阶。本稿保持RC3一阶原量。

## 2. 原时钟与双e身份

固定 `(ω,V,j,y)`，令 `γ=1+1/n,c_j=γ^{-j},g=√(LR)`。原比例带满足
\[
 a\le L,R\le b\le2a,\quad
 c_{j+1}g\le\min(L,R)\le c_jg,\quad a/c_j\le g\le bc_j.
\]
定义 `C_i=C(|y_i-v_i|/b)`、`C_Π(v)=∏C_i`，为避免和FIRST阈值q混淆，写
\[
 \mathfrak q_v(\xi)=\prod_i\max(C_i,\xi),\quad
 \tau_t=c_jt/b,\quad \xi_g(x)=c_jg(x)/b.
\]
于是
\[
 w_t(v)={C_\Pi(v)\over\mathfrak q_v(\tau_t)},\quad
 w_g(v)={C_\Pi(v)\over\mathfrak q_v(\xi_g(x))},\quad
 \Pi_t(dv)={1_{Z_t}(v)w_t(v)\over e_t(y)}\nu_V(dv).
\tag{RC5}
\]
固定 `(ω,V,j,y,t)` 后，ν、Zt、wt、et和Πt均独立x；ξg、wg、ρ、good、α、原当前选择器及history不独立x。`Π_g`不能冒充固定t的Π。

原good上定义实际利用率
\[
 \chi_v={3p_yw_g(v)\over KS_v}\in[0,1].
\]
在S_g外令χ乘积为零（ρ无需重定义）。直接代入得到
\[
 \boxed{
 p_y A_v\Pi_t(dv)
 ={K\over3}\chi_v\rho_vJ_v
 {\mathfrak q_v(\xi_g(x))\over\mathfrak q_v(\tau_t)}
 {1_{Z_t}(v)\nu_V(dv)\over e_t(y)}.}
\tag{RC6}
\]
另一个槽仍是 `Π_t(du)=1_Zt(u)wt(u)ν(du)/et`：RC6没有消掉第二个e，也没有把ν/e当概率。共享捕获始终为
\[
 \alpha Q_J=Dq-\int U\,d\nu,
 \quad U=1_{E_{cap}}\min(T\Delta,DK_0),\quad Q_J=\int J\,d\nu.
\tag{RC7}
\]
固定原行时这些终端量不随辅助t重新计算；若人为随t重选，新增变化必须计费。

对一个合法、对t固定的分析钟ξ与 `B_0>0`，令 `B_ξ=B_0\mathfrak q_v(ξ)/C_Π(v)`。任意 `0<θ<1` 有
\[
 \Pi_t(dv)B_\xi^\theta
 ={1_{Z_t}(v)\over e_t}
 B_0^\theta C_\Pi(v)^{1-\theta}
 {\mathfrak q_v(\xi)^\theta\over\mathfrak q_v(\tau_t)}\nu(dv).
\tag{RC8}
\]
当Ci<τt时，其坐标因子是 `Ci^{1-θ} ξ^θ/τt`（在ξ≥τt范围）。没有个体倒Ci，但et和另一槽完全保留。对未归一权，在光滑时刻
\[
 \delta_t(v,u)w_t(v)B_\xi^\theta
 \le k_t(v)w_t(v)B_\xi^\theta
 =-\partial_{\log t}[w_t(v)B_\xi^\theta].
\tag{RC9}
\]
若ξ随t变，则还须加 `w_t\,d(B_ξ^θ)`；若ξ=ξg(x)，固定x的时间微分可冻结它，x积分不可把它提出。RC9不是归一化后自动成立的无误差FTC。

## 3. 双后验连续乘积法则

以下在一个固定原行和有限时间区间上，先假设e有正下界、有限删除事件，实际测试具有所需分段AC资格；BV推广保留下述全部连续奇异部分。所有只可测门的处理另见§5。记 `s_t=log t`（不是软度），
\[
 \mu_t=\Pi_t\otimes\Pi_t,\qquad \bar k_t=\int k_t\,d\Pi_t.
\]
无删除开区间上，原权导数给出
\[
 \dot e_t=-e_t\bar k_t,\quad
 \dot\Pi_t=(\bar k_t-k_t)\Pi_t,\quad
 \dot\mu_t=(2\bar k_t-k_t(v)-k_t(u))\mu_t.
\tag{RC10}
\]
这些是同一原Π，未引入辅助后验。对 `f_t(v,u)=p_yA_vH_t(v,u)` 及 `Y_t=∫f_t dμ_t`，利用
`δ_t=k_t(v)-min(k_t(v),k_t(u))`，得到完整恒等式
\[
\begin{split}
 \int_\ell^g\!\int f_t\delta_t\,d\mu_t\,d\log t
 ={}&Y_\ell-Y_g+\int_\ell^g\!\int\dot f_t\,d\mu_t\,d\log t\\
 &+\int_\ell^g\!\int f_t
 [2\bar k_t-k_t(u)-\min(k_t(v),k_t(u))],d\mu_t\,d\log t
 +\sum_{t\in\mathcal J}\Delta Y_t.
\end{split}
\tag{RC11}
\]
`𝒥` 包含所有删除及f的跳时；纯门跳也在内（此时RC12取d=0）。端态采用右连续起末状态，内部并发删除整体计一次；端点删除可先单独列相同跳式，再取内端点极限。三种连续新增项分别是：

* `+2 bar k`：双e倒数的共同归一化增长；
* `−k_u`：另一后验腿的真实未归一衰减；
* `−min(kv,ku)`：把positive score变成v单腿微分的准确代价。

最后一项不是借用原 `N_{Z^c}` 或 `N_del`，只是本正交通的恒等分解。不得在不同子支重复扣它。实际 `dot f=p_yA_v dot H`，因为原终端χ、ρ、α、p固定于该行；若更换终端行，则还必须保 `H d(p_yA_v)`。RC6写法中χρ也是这样，不产生可免费删除的新导数。

## 4. 删除的准确重标与移除

在一次删除时刻，令 `D_t=Z_{t-}\setminus Z_t`、`d_t=Π_{t-}(D_t)<1`，wt连续。定义
\[
 \mathcal R_t=\mu_{t-}-(\Pi_{t-}|_{D_t^c})^{\otimes2}\ge0,
 \qquad \|\mathcal R_t\|=2d_t-d_t^2.
\]
则
\[
 \mu_t=(1-d_t)^{-2}(\mu_{t-}-\mathcal R_t),
\]
\[
 \boxed{\Delta Y_t=
 [(1-d_t)^{-2}-1]\int f_t\,d\mu_{t-}
 -(1-d_t)^{-2}\int f_t\,d\mathcal R_t
 +\int(f_t-f_{t-})\,d\mu_{t-}.}
\tag{RC12}
\]
这是后态测试的完整有限乘积式。分别为存活重标、两腿实际移除、门/系数交换。不能只保移除负项。`d=0`无删除，`d=1`是死亡行；不得定义死亡后的概率，需在此前终止/单列零质量原支。

若一般删除极限含连续奇异移除，令未归一测度 `n_t=1_Zt wtν` 满足
\[
 dn_t=-k_tn_t\,d\log t-d\mathcal L_t,
 \qquad d\ell_t=d\mathcal L_t(V)\ge0.
\]
在连续部分，RC10之外还需
\[
 d\Pi_t|_{del,c}=(\Pi_t,d\ell_t-d\mathcal L_t)/e_t,
\]
\[
 d\mu_t|_{del,c}={2\mu_t,d\ell_t-
 (\Pi_t\otimes d\mathcal L_t+d\mathcal L_t\otimes\Pi_t)\over e_t}.
\tag{RC13}
\]
把 `∫f_t dμ_t|del,c` 加到RC11右端。若f本身仅为BV，RC11的`∫ dot f μ dlogt`须替换为完整连续Stieltjes项`∫⟨d_c f_t,μ_t⟩`，其中包括Cantor部分；f的所有跳仍只在𝒥中一次计入。此处需逐源可测BV代表及总变差可积，不能由原门可测性推得。有限删除且分段AC测试没有这些额外奇异项；通极限不能先假它为零。这里 `d\mathcal L` 是真实删除权，不是原raw负信用的新名字。

## 5. 只可测门：允许的有限式与不允许的微分

任意有限分割上，不论H是否BV，都有
\[
 Y_{i+1}-Y_i
 =\int f_{i+1}\,d(\mu_{i+1}-\mu_i)
 +\int(f_{i+1}-f_i)\,d\mu_i.
\tag{RC14}
\]
实际H变化的精确入口/退出可写
\[
 f_+\mu_+-f_-\mu_-
 \quad\text{按 }\min(H_-,H_+)\text{ 的共同部分及两个正门差分拆。}
\]
共同部分用RC12；入口系数用后态，退出用前态。每次α、good、high、history、far端点、j或来源状态变化均必须保真实交换。有限式不授予H的BV总价，也不自动保证分割极限等于连续导数。故RC11只在明示regularity支上是积分公式；原一般可测输入首先使用RC14及原正量RC3。有限e截断和有限交通截断先行，任何去截断须证明相应项收敛，不能用∞−∞。

## 6. 原条件确实可消去的一腿，以及仍在的费用

原A固定且支撑终端 `Z_g`，因此对所有t≤g其目标存活。先对原H作正放 `H≤1`，再用 `δ≤kv` 与原Πu概率性，只消去u腿：
\[
 \int\!\int p_y A_v H\delta_t\,d\Pi_t(v)d\Pi_t(u)
 \le {p_y\over e_t}\int A_vk_t(v)w_t(v)\,d\nu(v).
\]
原nested权给 `e_t≥e_g>0`，故可直接对未归一时钟FTC：
\[
 \boxed{I_{row}\le {p_y\over e_g}
 \int A_v[w_\ell(v)-w_g(v)]\,d\nu(v).}
\tag{RC15}
\]
它对原可测H成立，不需门BV，也没有额外n或log2。利用实际good利用率进一步得到
\[
 I_{row}\le {K\over3e_g}\int 1_{S_g}\chi_v\rho_vJ_v
 \left[{\mathfrak q_v(\xi_g(x))\over\mathfrak q_v(\tau_\ell)}-1\right]d\nu(v).
\tag{RC16}
\]
这是真实全删除端点界；它不把当前时钟改成新捕获。不声称比所有既有终端界严格更强。剩余clock比可以很大，且ξg依x；不能把RC16的ν/e当概率或将J积分后无条件收成Wν。

作为对RC11的检查，在 `H=1` 且f仅依v、目标终端存活时，令 `F_t=Π_t(A)`，有
\[
 I_{row}/p_y=F_\ell-F_g+
 \int\bar k_t F_t\,d\log t
 +\sum {d_t\over1-d_t}F_{t-}
 -\int\!\int A_v\min(k_v,k_u)\,d\Pi_t^2d\log t,
\tag{RC17}
\]
连续奇异删除另加 `∫F_t d\ell_t/e_t`。目标不被删使负移除为零，但归一化跳是正的，绝不自动消失。RC15通过冻结e_g支付这一重标，代价是准确的未来放大端点。

原high/FIRST给 `p_y e_g≥2Kq`、共同current容量上界；它们没有给RC11中的正补偿为零，也没有给RC16中clock加权J列常数。α全行固定恰使本辅助时间中 `dα=0`，除此之外没有证明capture可消归一化补偿。若在共同L变化上研究α恢复，须另用R200/205/206真实有限交换，不混为上述时间FTC。

## 7. 一阶面与同α接口在原式中的位置

high-A/good上合法帽 `B` 使 `P=p_y≤BJ_v` 时
\[
 V_v=\rho_v{J_v\over S_v}\min(P,BJ_v)=p_yA_v,
\quad V_v=\sqrt{J_vW_v},\quad
 W_v=\rho_v^2z_v^2\min(P^2,B^2J_v^2)/J_v.
\tag{RC18}
\]
因此父稿一阶D1是原系数V的真实分母下降量，不是把旧伴随W另命名为raw。但是它是共同尺度面上的有限负跳，不能直接代替RC3里的时间score积分。父稿给
`D1≤ρP h1(Bδ/P)` 以及分数面价；同α净恢复由辅助稿处理，保实际共同α比、其他target的δv=0恢复、重新充入捕获余量和门入口。所有cap参数冻结资格与clamp额外速度按各稿支付；任何source帽和选择器费用仍需回原共同面测度。

## 8. 下一条真正需要的联合预算

在未用RC4的同一个原测度上，需证明
\[
 {32\Lambda\over3}\mathbb E\sum_{V,j}\int_Edx\int\beta(dy)
 \int\!d\log t\iint H\,V_v\,[k_v-k_u]_+\,d\Pi_t^2
 \le\varepsilon\,\mathbb E\int_Eq\,dx
 +C_\varepsilon\sqrt n\,\operatorname{polylog}(n)W_A.
\tag{RC19}
\]
不是把此式作为已证新范数。这里的具体接缝已收窄为：在真实相同来源/面/时钟积分中，把RC8的分数来源乘积与RC9的单腿时钟衰减联用，同时控制RC11–13的实际归一化重标和RC14的入口；或直接证明RC16的共享high/FIRST加权列价。不能先付独立n能量再把一阶或平方核√n价代回。

固定j可定义辅助时间域与原域相交后才可Tonelli；实际far满足 `c_jt/b∈[1/2,1]`，正扩展共同域的长度≤log2。唯一j必须保留到真正得到统一接收行价时才能合并；逐j核价/来源价若先分开，保完整菜单和独立窗口费用。RC15自身不新增时间长度费，不意味着其它面/selector界自动免这些费用。所有来源只用共同父支配，不假ν≤β、每叶质量帽或来源坐标独立。

本轮证实了原raw一阶系数与无n端点FTC，并精确列出归一化后出现的全部新项；一般原来源价与共同尺度选择器仍未闭合。
