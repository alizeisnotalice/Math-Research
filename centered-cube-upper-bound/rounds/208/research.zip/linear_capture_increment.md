# R208：线性残余的尖锐共同增量与单次捕获储备

状态：证明共同几何/current 分母变化下的尖锐线性增量；进一步将持续 target 的实际 aν 线性恢复直接以同一份 capture 增益 G 支付，保留实际分母负项。后者没有倒 alpha 或对数次数费，但不是原 V beta Pi² 的无条件来源预算：换权、e、入口、几何与 recharge 均保留。仅有限状态恒等式，不凭可测资格宣告全路径 BV。

## LC1　实际对象、共同比较及零支

在原固定 `(omega,V,j,y,t)` 背景中，保同一原来源 nu、外 beta 和
\[
 \eta(v)=1_{Z_{j,V,y,t}}(v)w_t(y,v),\qquad
 e=\int\eta\,d\nu>0,\qquad \Pi(dv)=\eta(v)\nu(dv)/e.
 \tag{LC1}
\]
固定该背景时这些对象独立 receiver/current L；不因此冻结 terminal g、capture、softness、alpha 或其它 history。e=0 行先零；没有 nu<=beta。其它来源/时间改变时须另留共同支配测度下的密度交换。

令 P>=0、B>=0、J>0、a>0、k>=0、S>=J，设
\[
 M=\min(P,BJ),\quad d=1-k/a\le1,\quad
 \rho(\alpha)=(d-\alpha J/a)_+,\quad
 V(\alpha,S)={MJ\over S}\rho(\alpha).
 \tag{LC2}
\]
实际对应 a=T Delta、k=D K0、J=J_v、S=p_v+p_v^++J_v；本稿不重选核尺度或 capture。P 是原同一 outer current 密度，B 是原合法帽。V 的原 raw 身份与全部外门由主稿独立核验，本稿不以一个新抽象 V 代替它。

比较两个共同 P,B,J,a,k 的状态
\[
 S_+=S+\delta,\quad\delta\ge0,\quad
 \alpha_+=r\alpha_-,\quad0\le r\le1,\quad
 c={S\over S+\delta}\in(0,1].
 \tag{LC3}
\]
r 必须是该实际共同 alpha 的比，不许每个 target 另选。若 alpha_-=alpha_+=0，约定实际比 r=1，随后用直接零恢复式；不得用任意 r<1 从双零 alpha 领取恢复。若 alpha_->0、alpha_+=0，r=0 正常合法。下面所有有限量先在真实状态有定义时比较。

P=0 或 B=0 时 M=0，V=0。原 J=0 的 target 定义 V=0，不使用 z=alpha J/(a d+)；S=0 只能在此零支内。a=0 或原无 capture 资格的 target 先保其原零端值，不用 k/a 跨过去。d_+=0 时 rho 和 V 均零。本文任何换权均先排除 MJ=0。

## LC2　标量上确界：保共同分母下降的最佳常数

对 0<=c,r<=1，
\[
 \boxed{\sup_{z\ge0}\{c(1-rz)_+-(1-z)_+\}=c(1-r).}
 \tag{LC4}
\]
实际 c>0；c=0 是直接定义的边界辅助式。

证明：0<=z<=1 上差为 c-1+(1-cr)z，因 1-cr>=0，在 z=1 达到 c(1-r)。若 r>0，1<=z<=1/r 上为 c(1-rz)，不超过该值；z>=1/r 为零。r=0 时 z>=1 上恒为 c；r=1 时差为 (c-1)(1-z)+<=0，z>=1 取零。c=0 时最大为零，同样成立。因此对全部参数 z=1 均可取等，常数不可减。

若 d_+>0 且 alpha_->0，置
\[
 z={\alpha_-J\over a d_+};\qquad
 V_+-V_-={MJ\over S}d_+
 \{c(1-rz)_+-(1-z)_+\}.
\]
得到尖锐几何共同状态界
\[
 \boxed{[V_+-V_-]_+
 \le {MJ\over S+\delta}d_+(1-r)
 \le P d_+(1-r)\le P(1-r).}
 \tag{LC5}
\]
最后使用 M<=P、J<=S+delta，而非假定所有变量相等。前一个界在 z=1、M>0、d+>0 时取等；后一个 P 界另需相应密度/分母等号，不声称一般同时取等。

alpha_-=0 时两 alpha 都零，rho_+=rho_-=d+，因此
\[
 V_+-V_-=-{MJ\delta\over S(S+\delta)}d_+\le0.
 \tag{LC6}
\]
r=1 同理恢复零。delta=0 则 c=1，但只要 r<1，持续 target 仍可真实恢复：它不能因该 target 没有自身 current 跳幅就被忽略。所有恢复共用原同一个 r。

## LC3　精确净式与线性有界原函数

共同状态下精确有
\[
 V_+-V_-={MJ\over S+\delta}(\rho_+-\rho_-)
 -{MJ\delta\over S(S+\delta)}\rho_-.
 \tag{LC7}
\]
负项是实际端值，不可用其正上界冒充负补偿。rho+−rho-非负。LC4 把恢复和分母下降一起优化，比直接先丢负项所得 d+(1-r)MJ/S 更锐；c<1 且有正恢复时，尖锐上界严格多保 c 因子。

可用不除 alpha 的有界线性势
\[
 \psi(d,\zeta)=d_+-(d-\zeta)_+=\min(d_+,\zeta),
 \quad \zeta\ge0,\quad0\le\psi\le1,
 \quad\rho=d_+-\psi.
 \tag{LC8}
\]
它连续、分段线性，但在 zeta=d+ 的拐点不假称处处可微。全部共同有限状态中
\[
 V={MJ\over S}d_+-{MJ\over S}\psi,
 \qquad \Delta V=\Delta(MJd_+/S)-\Delta(MJ\psi/S)
 \tag{LC9}
\]
是精确有限差分，包括两项同时变化。不能用某个端点梯度代替全增量，也不由此授予任意可测门 BV。

## LC4　实际 capture 储备：新增 aν 恢复容量

现在固定有限正 nu、同一可积 J>=0、a>=0、k>=0、共同 Dq，以及真实 capture 两态 E_- subset E_+。a=0 槽按原零对象处理。设
\[
 Q=\int J\,d\nu\in(0,\infty),\qquad
 U_\pm=1_{E_\pm}\min(a,k),\qquad
 H_\pm=Dq-\int U_\pm d\nu=\alpha_\pm Q\ge0,
\]
\[
 G=\int(U_+-U_-)d\nu=H_--H_+\ge0.
 \tag{LC10}
\]
Q=0 时 J=0 为 nu-a.e.，原积分 target 槽先为零，不由零除式定义 alpha；只在 Q>0 使用本节比值。以下正界可取扩展非负值；LC14/16 的正部由 LC13 支配为有限，负补偿若积分无穷则 signed 式按负无穷解释，不作无穷减无穷。

这些是同一份实际捕获积分，不可将 G 换成上界后仍称 alpha 的实际变化。E 嵌套需要完整原 terminal support/Delta/good/其它 capture 资格的合法迹；不是只用一条 good 阈值便断言原 E 嵌套。

若 H_->0，则
\[
 1-r={G\over H_-};\qquad
 H_-=0\Longrightarrow H_+=G=0
 \tag{LC11}
\]
并按 LC1 的双零约定处理。这给 LC5 的实际恢复因子，但单独 G/Hminus 仍可奇异；下一条容量不作此分离。

对任何可测持续 target 集 T subset E_-（也可再交实际两态共同资格），
\[
 a\rho(\alpha)=(a-k-\alpha J)_+.
\]
因此逐 target 的精确积分式为
\[
 a(\rho_+-\rho_-)
 =\int_{\alpha_+}^{\alpha_-}J1_{\{a-k>\lambda J\}}\,d\lambda
 =(\alpha_--\alpha_+)J
 -\int_{\alpha_+}^{\alpha_-}J1_{\{a-k\le\lambda J\}}\,d\lambda.
 \tag{LC12}
\]
证明是正部仿射函数在 alpha 的绝对连续基本定理；阈值相等的单点在 dλ 积分下零。J=0 时该式两边零，毋须除 J。a=0 时亦以原零 target 的直接端值处理，不使用 rho 比值。

Tonelli 后得到真实单次容量
\[
 \boxed{\int_T a(\rho_+-\rho_-)\,d\nu
 ={G\over Q}\int_TJ\,d\nu-\mathcal L_T\le G,}
\]
\[
 \mathcal L_T=\int_T\int_{\alpha_+}^{\alpha_-}
 J1_{\{a-k\le\lambda J\}}d\lambda\,d\nu\ge0.
 \tag{LC13}
\]
这不是仅把未知恢复改名：右边 G 是原 capture 已知实际质量增量；无倒 a、倒 J、倒 alpha 或 nu 总质量因子。它确证持续 target 的 aν 线性恢复一次消耗不超过同一份捕获储备。换权回原 V 的费用仍在 LC6 以下明确保留。

## LC5　保留 current 负项的同源 signed 容量

在 T 上进一步共同 P,B,J,a,k 且 MJ>0，令
\[
 \omega_v={MJ\over a(S+\delta)},\qquad
 \mathcal D_T=\int_T {a\delta\over S}\rho_-\,d\nu\ge0.
\]
乘 LC7 的实际正换权，精确有
\[
 \boxed{\int_T{V_+-V_-\over\omega_v}\,d\nu
 ={G\over Q}\int_TJ\,d\nu-\mathcal L_T-\mathcal D_T
 \le G-\mathcal D_T.}
 \tag{LC14}
\]
同时
\[
 \int_T{[V_+-V_-]_+\over\omega_v}\,d\nu
 \le\int_Ta(\rho_+-\rho_-)\,d\nu\le G.
 \tag{LC15}
\]
换权无定义的 MJ=0 槽原 V 为零，应删去，而非写 0 乘无穷。a=0 槽同样先处理；LC14/15 不把该加权 measure 当原 raw。

可将共同 T 的有限 signed 增量先聚合后取正；不能每个 target 改选 alpha 或 receiver/current 状态以减弱负项。LC14 给整体非正的实际充分比较：D_T+L_T>=G J(T)/Q；未断言它在一般输入自动成立。

## LC6　原 posterior、窗口和换权费用没有消失

同一原 Pi 下，LC12/14 仍精确给
\[
 \int_T{V_+-V_-\over\omega_v}\,\Pi(dv)
 ={G\over Qe}\int_T\eta J\,d\nu
 -{\mathcal L_{T,\eta}\over e}
 -\int_T{a\delta\over S}\rho_-\,\Pi(dv),
 \tag{LC16}
\]
其中 L_T,eta 是 LC13 中再乘真实 eta 的非负 slack。eta<=1，所以
\[
 \int_T{[V_+-V_-]_+\over\omega_v}\,\Pi(dv)\le G/e.
 \tag{LC17}
\]
原 e 不因此可消。若去掉换权，直接得到的实际正界仅为
\[
 \int_T[V_+-V_-]_+\Pi(dv)
 \le {G\over Qe}\int_T\eta\,{MJ^2\over a(S+\delta)}\,d\nu.
 \tag{LC18}
\]
此式完整展示缺口，未将该加权 J 矩偷换成 Q 或 e。a 小、帽 B 的来源依赖、原 current/capture 和 e 都可使此费用大；本稿没有给它无条件 W_A 预算，也不新增一个未获价的门冒称付款。

全部原来源回代始终在
\[
 \mathbb E\sum_{V,j}\int_{I_j}{dt\over t}\int dx
 \int\beta_V(dy)\iint\Pi_{y,t}(dv)\Pi_{y,t}(du)
 \tag{LC19}
\]
及原唯一 j、time/high/history/receiver 门中进行。alpha、G、Q、换权均按原同一 row；不同 y 不得另拼自由共同比值。独立窗口分开记账，不能把一窗的恢复容量借给另一窗。beta、nu 仅共同父支配，不要求有序。固定 Pi 的 receiver 独立性只许合法 Fubini，不付 LC18 的 source 矩。

## LC7　全增益路径的实际线性储备，及 recharge

取有限共同 a,k,J,nu,Q,Dq 路径，真实 E_i 嵌套增加，H_0>=...>=H_N>=0，G_i=H_i−H_{i+1}。每步持续集 T_i subset E_i 可变化。由非负 LC12，
\[
 \sum_i\int_{T_i}a(\rho_{i+1}-\rho_i)d\nu
 \le\int a(\rho_N-\rho_0)d\nu
 \le\sum_iG_i=H_0-H_N.
 \tag{LC20}
\]
第一不等式不把一份恢复重复给不同层：每步仅使用其真实增量，然后用全来源 telescope；同一时段任意分片必须互斥，不能反复抄同一个 step 的 G。路径达到 H_N=0 也正常有限，无需对数或最小正 alpha 假设。

若 H 允许上升，正恢复只取下降步，实际总增益为
\[
 \sum_i(H_i-H_{i+1})_+
 =H_0-H_N+\sum_i(H_{i+1}-H_i)_+.
 \tag{LC21}
\]
第二项是必须付的真实 recharge。若 Q、Dq、a、k 或来源/资格随路径变化，LC20 的共同参数 telescope 不能直接使用；每步 alpha 比仍可用 LC4/5，但其捕获解释与其余变量变化需用实际有限分解。可数路径仅在对应正量单调极限合法时延拓，不凭此授连续原门 BV。

与 R205 的平方恢复 R_c=G/(H_-+H_+) 及其 gain-only 对数累计不同，这里 aν 线性恢复以实际 G 累计，甚至下降到零也无发散；二者支付的 target measure 不同，不能以 LC20 宣称原 V 或平方 W 都已获同价。

## LC8　真实几何、资格入口与 delta=0 target

对共同几何本身变化，不冻结真实变量冒作零误差。令 g=(a,k,J,P,B)，在 a_+>0,S_->0 时仅作代数中间值
\[
 \widetilde V_-={M_+J_+\over S_-}
 (1-k_+/a_+-\alpha_-J_+/a_+)_+.
\]
它不是重算 alpha 或资格的合法新状态。精确有
\[
 V_+-V_-=(V_+-\widetilde V_-)+(\widetilde V_--V_-).
 \tag{LC22}
\]
若 S_+>=S_-、alpha_+<=alpha_-，第一项用共同后态 g+ 的 LC4/5；第二项保全部真实几何交换。此处最后一步用 P 的界只需实际 S_+>=J_+；不假中间态具备原 good。a_+=0 或 S_-=0 先用原真实端值，不使用这个分式。alpha 上升且共同几何/分母非减时恢复项非正。

对于原非负门 H_±，令 h=min(H_-,H_+)，有完全有限恒等式
\[
 H_+V_+-H_-V_-
 =h(V_+-V_-)+(H_+-H_-)_+V_+
 -(H_--H_+)_+V_-.
 \tag{LC23}
\]
入口、退出和几何都不得用持续 target 的 G 容量删掉。尤其 E_+\E_- 的新 target 另有
\[
 \int_{E_+\setminus E_-}a\rho_+d\nu
 =\int_{E_+\setminus E_-}(a-k-\alpha_+J)_+d\nu,
 \tag{LC24}
\]
而本区对 G 的贡献是 ∫min(a,k)dν。k=0 的代数端点可前者正、后者零；实际 strictsoft k>0 仍没有这里所需的统一比较下界。因此 LC13 只付持续恢复，不冒付入口。原目标自身 delta_v=0 也能随其它来源捕获导致共同 alpha 降低而恢复，必须保 LC7/LC23；这与原有 delta_v>0 的 face 局部项是不同交通。

这些有限式不需假设任意 L1 输入光滑或所有门有迹/BV；欲沿 receiver/scale 路径使用导数、coarea 或累计变差，仍须原合法共同迹、完整跳跃和连续/Cantor 项。不能把端点梯度当共同有限差分，也不能把来源面零质量当 receiver 面不存在。

## LC9　可执行的最小有理同源校准

下列是原 reserve 结构的有限代数 fixture，不声称物理 FIRST/current 核/森林/FULL 实现。取两来源质量各 1，参数 0<=r<=1、epsilon>=0：
\[
 J_v=1,\quad J_z=\epsilon,\quad Q=1+\epsilon,\quad
 a_v=2,\ k_v=1,\quad
 k_z=(1-r)(1+\epsilon),\ a_z=k_z+1,
\]
\[
 E_-={v},\ E_+={v,z},\ Dq=2+\epsilon.
 \tag{LC25}
\]
由 U 真正重算而非自由指定，得到 H_-=1+epsilon、H_+=r(1+epsilon)、alpha_-=1、alpha_+=r；Σk<=Dq。目标 v 的 rho_-=0、rho_+=(1-r)/2，标量 z=1 恰取 LC4 最优点。

再取 P=3/2、B=1、S_-=2、delta>=0，则 M=1，
\[
 V_+-V_-={1-r\over2(2+\delta)},\qquad
 a_v(\rho_+-\rho_-)=1-r\le G=(1-r)(1+\epsilon).
 \tag{LC26}
\]
可用 r∈{0,1/2,1}、epsilon∈{1/4,1/16}、delta∈{0,1} 作小表；不是要求笛卡尔大扫描。epsilon↓0 时 LC13 的持续来源容量比趋一，epsilon=0 给辅助 J_z=0 端点等号，不能称 strictsoft 物理核实现。r=1 的 kz=0 也仅校准零增益端点。

例如 r=1/2,epsilon=1/4,delta=1：Q=5/4,G=5/8，rho+=1/4、Vdiff=1/12；加权 target 恢复为 1/2，剩余 G−1/2=1/8 来自新来源的 J 份额。delta=0 则 Vdiff=1/8>0，明确检查“target 无自身跳但共同 alpha 恢复”。另单列双零 alpha、d+0、M0、r1、J0 和实际入口端点，先走定义零支，禁止除零或 0×∞。

## LC10　本轮可确认进展及第一处未付项

LC4/5 是实际线性残余和分母共同变化的尖锐有限增量；LC13--21 是同一实际 capture 储备对持续 aν 恢复的单次累计预算，严格保原 denominator 负项和 recharge。它们不是未知 cut 的重命名，也不需按 target 另领一份储备。

原 raw 所需的缺口已经明确为 LC18 的真实加权来源矩，以及 LC23/24 的入口和 LC22 的几何交换；共同路径、receiver selector、全部 j/time/window 费用仍在。这里没有用有限标量/同源 fixture 认证一般物理覆盖，也没有推出一般根阶弱型闭合。
