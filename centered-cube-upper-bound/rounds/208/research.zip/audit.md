# R208 independent premise audit

## 1. Order, original object and scope

Read only `task_contract.md` before this independent candidate screen, not new author proofs. The auditor owns only this file and does not run Git, spawn agents, execute numerics or compile PDFs. The original J-share, both posterior slots, actual common source/alpha, gates, clock/score and receiver selector must remain when returning to raw traffic. A kernel estimate is not a general source payment.

For nonnegative rho,z and F=min(P^2,B^2J^2)/J, the exact identity is

    V=sqrt(J W)=rho z min(P,BJ),  W=rho^2 z^2 F.

Only on the actual target/capture/good slot with a proved cap P<=BJ does V=P A, with A=rho z there. A virtual rho outside that gate is not original traffic. This is the J-share identity; it does not cover other mother/share terms or remove the original u posterior, time, score or truncation.

## 2. Sharp first-order denominator envelope

For common P>=0,B>0,J>0,0<=rho<=1,S>=J and delta>=0,

    D1=rho min(P,BJ) J delta/[S(S+delta)].

Increasing S decreases this expression, so set S=J for an upper relaxation. On J<=P/B, B J delta/(J+delta) increases with J; on J>=P/B, P delta/(J+delta) decreases. Therefore

    D1<=rho P h1(B delta/P),  h1(t)=t/(1+t),

with sharp matching at S=J,J=P/B when P delta>0. P=0, delta=0, B=0 or rho=0 is zero first. This is an abstract scalar matching, not physical attainability. It requires the real common rho/J/P/cap and denominator-only change; simultaneous state changes retain their full finite products.

## 3. Necessary correction of the proposed power optimizer

For 0<theta<1, h1(t)/t^theta=t^(1-theta)/(1+t). Its log-t derivative is 1-theta-t/(1+t), so the unique maximizing positive point is

    t_star=(1-theta)/theta,

not the initially proposed reciprocal theta/(1-theta). This correction was sent to the parent before reading proofs. The best constant remains C_theta=theta^theta(1-theta)^(1-theta), whose symmetry hides the optimizer inversion. Both endpoint constants are one: theta=0 is attained only at infinity, theta=1 only as t decreases to zero. Endpoint support and zero jumps are treated directly, not by zero-power conventions.

The pointwise positive bound becomes C_theta B^theta P^(1-theta) delta^theta. It has no preceding B. The audited R206 physical face tensor and affinity chain therefore give C_theta K_theta [B(1-s)]^theta sqrt(n), with the same gamma range [1,2], fixed-source cap, traces and homothetic relative speed. Since C_theta<=1, the R207 half-interval/logarithmic argument gives

    N1<=65 sqrt(n) min(sqrt(R),sqrt(log(e+R))),  R=B(1-s).

R=0 is the actual zero branch. This concerns the defined positive first-order denominator-envelope face kernel. Clamp, simultaneous rho/capture changes, source occupation and soft/scale receiver selectors are not paid by it.

## 4. Common-alpha linear net increment

With common M=min(P,BJ),J,a,k and Splus=Sminus+delta, alpha_plus=r alpha_minus, set c=Sminus/Splus. For d_+>0 and alpha_minus>0 use z=alpha_minus J/(a d_+). Then

    sup_(z>=0)[c(1-rz)_+-(1-z)_+]=c(1-r).

On z<=1 the expression is affine increasing, with slope 1-cr>=0; on z>=1 its maximum is at z=1 (or the corresponding constant branch if r=0). Thus

    [Vplus-Vminus]_+
       <=MJ/Splus d_+(1-r)<=P d_+(1-r).

The exact finite difference also retains the denominator term -MJ delta rho_minus/[Sminus Splus]. The alpha_minus=0 branch has two zero alphas and nonpositive net denominator change; r must not be formed as 0/0. d_+=0 is zero first, r=1 gives no positive recovery. Targets with delta_v=0 still feel the same actual alpha change and cannot be omitted from the row return. New gates, outer/cap/current geometry and original event measures remain separate.

## 5. Additional same-source capacity candidate

The auxiliary author supplied, before its proof, the actual persistent-source capacity with common nu,J,a,k,Q and nested Eminus subset Eplus. It passes: a rho(alpha)=(a-k-alpha J)_+, so for any common persistent target set T,

    integral_T a(rho_plus-rho_minus)dnu
       <=(alpha_minus-alpha_plus) integral_T J dnu<=G,

where G=Hminus-Hplus and H=alpha Q. The exact slack is integral_T integral_(alpha_plus)^(alpha_minus) J 1_(a-k<=alpha J) d alpha dnu; equality boundaries do not alter this alpha integral. Multiplying the exact V difference by a Splus/(MJ) on MJ>0 leaves the negative term a delta rho_minus/Sminus and gives the stated signed weighted inequality. Zero slots are excluded before that reciprocal is formed. This is not the original raw weight. Gain-only sums of G telescope only with the same background and no recharge; changing a,k,J,Q,Dq, actual entries and source reuse retain their genuine exchanges.

## 6. Clock/source and stopping scope

The exact unnormalized clock identity is

    w_tau B_xi^theta
       =B0^theta C_product^(1-theta) q(xi)^theta/q(tau).

It preserves the extra C_product power and cannot replace either actual e_tau normalization or the second u-posterior, delta score or receiver-dependent terminal xi_g. It does not make the source product a probability. The original shared-cap/trace qualification and fixed-parameter kernel costs must be preserved before any source/global return. No general original raw or weak-type bound is certified. The optimizer correction in section 3 is required in all later proofs/checks; await full author manuscripts and raw-clock audit before final certification or hash binding.

## 7. Full parent first-order manuscript review

Read complete `first_order_face_geometry.md` FO1–6 after the independent screen. No necessary revision was found. The initially inverted optimizer is corrected explicitly to (1-theta)/theta, while the symmetric best constant is retained. The first-order scalar sharp bound, exact fractional face factors/no extra L^(-n), removal of the preceding B, logarithmic/half-power kernel price and zero/support qualifications agree with the independent derivations. V=PA is limited to the actual J-share high-A/good/capture qualification, and the text does not replace every raw term by that share.

The additional clamp claim also passes independently: P h1<=P pointwise even for a variable cap. Each fixed-L face integrates the other product coordinates to one and leaves at most 1/L; the two faces times b/2 give n b/L. On L_star>=b/gamma, gamma=1+1/n, its common log-scale path integral is at most n(b/L_star-1)<=1, with empty segments zero first. This does not require pulling out B, but still requires a common s at each L and does not control s(x,L). Original simultaneous finite exchanges and nonbounded score factors are not thereby included. The manuscript keeps e_t, the second posterior, actual score, time/window/gate and selector costs. A positive loss upper bound is not misused as the negative compensation needed elsewhere. Full original raw/clock and author joint manuscripts remain for later review.

## 8. Clock candidate independently screened before proof

For a fixed original row on a deletion-free segment, m_t=integral k_t dPi_t and mu_t=Pi_t tensor Pi_t give mu'_t=(2m_t-k_v-k_u)mu_t. With f_t=p_y A_v H_t and Y_t=integral f_t dmu_t, the identity delta_+=k_v-min(k_v,k_u) yields the proposed signed decomposition: Y_ell-Y_g, plus the continuous product derivative of f, plus integral f(2m_t-k_u-min(k_v,k_u))mu_t dlogt, plus the actual Y jumps. The jump sum has a positive sign when solving for the time integral.

At deletion fraction d<1, let R=mu_minus-(Pi_minus restricted to D^c)^tensor2, with mass 2d-d^2. Then mu_plus=(1-d)^(-2)(mu_minus-R). Expanding against the post-test f_plus gives exactly the stated renormalization, removed-two-leg and test-exchange terms. Death d=1 must be handled before these denominators. Merely measurable tests permit finite telescoping, not automatic differential/BV formulas. Any continuous singular deletion or Cantor test variation must stay in an actually qualified BV extension. If f depends only on v and no u gate remains, one may first integrate k_u to m_t, leaving one m_t; doing so under an actual pair gate is not justified. No normalized min-score or positive renormalization term is thereby zero. These conclusions were communicated from the accurate candidate before reading the full clock proof.

## 9. Full linear-capture manuscript review

Read complete 278-line `linear_capture_increment.md`, version `fedff25439e3cc7e7408cbb632be6c1ae451c866edf4fe8aae277dfff7504c66`. LC1–26 pass without a necessary revision. The sharp linked-alpha profile, actual negative denominator difference, virtual finite potential, Q=0/MJ=0/a=0 and double-zero-alpha guards agree with the independent screen. The actual common source U/E reconstruction of G, exact inactive-alpha slack and a-nu persistent recovery capacity are correct. Positive part is bounded by finite G before any extended signed integral is formed; an infinite negative contribution is interpreted as negative infinity, without infinity subtraction.

LC14–18 retain the real reciprocal weight and posterior e. The full-source gain-only telescope uses fixed a,k,J,nu,Q,Dq and nonnegative step recovery; varying persistent sets do not duplicate a step. Recharge and new target entry are separately recorded. The post-geometry intermediate value need not be a legal new state and is not used to reselect alpha; its final P bound uses the actual post-state Splus>=Jplus. The absence of a uniform entry comparison to k is not hidden by strict positivity. Neither the a-nu capacity nor finite fixtures are promoted to the original V beta Pi^2 budget.

## 10. Full original raw/clock review and source support

Read complete `raw_clock_joint.md`, including the final diffuse-deletion/BV clarification. Directly read R128 RT1–3 and R127 SP2–3 cited source passages. The original positive target is terminal S_g=Z_g minus D_g, S_g subset Z_g, and the posterior satisfies e_t>=e_g>0 on the earlier window. Thus terminal survival in RC15 is an original qualification, not a newly inserted paid subset. Other later-deleted-target functionals are explicitly outside that endpoint claim.

The hard cap is used once in RC3, the J-share is distinguished from all mother raw, and the unconsumed original negative terms are untouched. RC6 accurately expresses p_y A Pi_v with the good utilization and clock ratio; the u slot still contributes its own 1/e_t. RC8 is an unnormalized fractional-cap identity, not a probability cancellation. RC9 is only a one-leg unnormalized derivative, with any changing analysis clock coefficient retained.

RC10–14 pass: continuous double normalization has 2m_t, the exact score conversion retains min(k_v,k_u), all deletion/test jumps are included once, and the post-test deletion formula uses (1-d)^(-2). Zero/death rows are not continued as probabilities. Continuous singular deletion and the full diffuse Stieltjes test term including Cantor parts are explicitly conditional on actual regularity/integrability. Arbitrary measurable H has only the stated finite product identity. No new negative credit is borrowed.

RC15 follows by positive removal of H, delta<=k_v, integration of the genuine u probability, e_t>=e_g and the terminal surviving target's exact unnormalized FTC. RC16 preserves the actual receiver-dependent clock amplification and nu/e_g. RC17's one-leg check correctly retains positive deletion renormalization and the min-score term. The finite endpoint estimate is dimension-free but is not a clock-weighted source column bound. V=p_y A in RC18/19 is read with its preceding legal cap/high-A/good J-share qualification, not as a replacement for all mother traffic or for slots where the cap has not been established. No necessary mathematical revision was found.

## 11. Numerical and reproducer static review checkpoint

Read complete current `first_order_checks.py`, its notes and the reproducer without executing them. The D1 cases retain both scalar bounds, S/J/rho branches and actual sharp J matching. Linked-alpha profiles retain signed values. All four h1 menus use the corrected peak (1-theta)/theta and the independent relation 1/(1+t_star)=theta. Six direct physical n=1/2 N1 integrals have no preceding B, and their matching tensor uses C_theta B^theta. The analytic N1 tail has no B factor because P h1<=P; the affinity tail still has the correct gamma^(-theta) and rate. Exact parameter/precision cache keys prevent cross-configuration reuse. These are noninterval fixed-parameter diagnostics, not a raw/good/capture realization.

Statically read the newly added three common-source capture models. Each recomputes Uminus/Uplus, Q,Hminus/Hplus,G and both alphas from the same source, verifies nested E and full k capacity, checks LC12's exact inactive interval, the signed negative denominator and positive-part capacity, and records new-entry potential separately. The alpha-plus-zero and inactive/delta-zero recovery cases are actually represented. No original raw reciprocal weight or physical/FIRST qualification is inferred from the fixtures. Final notes/metadata and execution hashes remain to be bound when frozen.

The relocated-copy reproducer matches the established confined-manifest/required-coverage/fresh-output/full-JSON/after-run-hash procedure, with the actual R208 stem and CLI. Its static acceptance does not pre-report the parent's future execution. The default all-stage menu is the final reference; the optional initial menu is not substituted for it.

## 12. Final numerical, report and driver scope

Statically read the final three posterior-clock cases and final notes, JSON fields and report. The two posterior derivatives are computed independently before comparison to the double-normalization formula. Concurrent deletion uses the actual surviving w-nu measure, post-state f for renormalization/removal and old product measure for coefficient exchange. The constant-f witness exactly cancels positive renormalization against removal. The instantaneous fluxes 3/4,9/100,3/80 and deletion jumps -3/4,317/450,-7/45 match the displayed exact finite algebra. Scores include rational values; these cases do not assert physical integer-score or original terminal-support realization.

The three capture cases reconstruct actual U/E, both alphas and G from a common finite source, with the inactive-alpha slack, actual denominator loss, delta-zero recovery and new entry separated. They do not certify the original reciprocal raw weight. Final evidence is nine D1 configurations/162 experiments, nine linked-alpha profiles/36 signed evaluations, three capture cases, three posterior cases, four h1 menus and six actual physical n=1/2 face integrals at 25/50 digits. The final numeric author reports an actual isolated complete-JSON byte-identical replay, exit 0, 17.210 seconds. The auditor did not execute it. Fraction results certify their specified finite arrays; quadrature and cross-precision comparisons remain noninterval diagnostics.

Read the current report and default-all-stage relocated-copy driver. The report preserves the J-share qualification, unfinished normalized clock/source column, original gates/other shares and all selector/window costs. The driver verifies the manifest, runs the actual script CLI in a relocated copy, compares whole JSON bytes and verifies hashes again. No future parent driver execution or PDF compilation is certified here.

## 13. Full detailed TeX review

Read the entire detailed TeX after the independent candidate screens and full mathematical manuscripts. FO's sharp first-order denominator and corrected optimizer, physical tensor normalization/no preceding B, common-path unit clamp price, LC's shared-source G capacity and real reciprocal-weight obstruction, and RC's original target S_g subset Z_g, two posterior factors, all test/deletion jumps and full continuous BV/Cantor qualifications agree with the reviewed sources. The no-n endpoint is a genuine upper bound on the original terminal-surviving J-share row, not a completed source budget. The unclosed raw interface and unconsumed negative credits remain explicit.

Necessary transcription fixes were sent to the sole TeX author: three form-feed control characters followed by `rac` were restored to `\\frac`, and the finite posterior examples' score description now says nonnegative rational rather than integer. Verified all three repaired formulas and that the actual final bytes contain no abnormal ASCII control characters. The final file has 814 physical lines; the former count of 817 treated each form feed as another line separator. These fixes do not change intended mathematics or numerical inputs. The corrected detailed TeX is accepted within the stated scope.

## 14. Final mathematical decision

Accepted within the stated qualifiers: the sharp first-order scalar envelope and best power constant with corrected optimizer; the fixed-source physical first-order face bound with no preceding B and unit common-path clamp envelope; the sharp common-alpha linear net increment; the actual single-source persistent a-nu capacity and its real weighted slack; and the original double-posterior finite/qualified-continuous clock identities and terminal-surviving no-n endpoint bound. These are constructive estimates for their actual defined objects. No assertion that the general original raw budget, receiver selector, normalized clock-amplified source column or centered-cube root-order weak-type problem is closed is accepted. Other shares, entry/recharge, simultaneous geometry, original negative-credit consumption and complete source/j/time/window costs remain as explicitly recorded in the manuscripts.

The auditor performed mathematical and static code/document review only. No numerical script, final parent reproducer, Git operation or PDF compilation was executed by the auditor. A later manifest and archive replay belong to the parent and are outside this frozen audit's execution claims.

## 15. Frozen final file bindings

Final corrected TeX and updated report were re-read narrowly after repair. No remaining necessary revision was found. These ten current work files were hashed from their actual bytes after review. The audit does not hash itself or a future manifest. No parent-driver result is pre-reported.

| File | SHA256 |
| --- | --- |
| `first_order_checks.json` | `e9ae075dafa0af561c4ce20fd12b39a08d0c5b4e3b0a975bb4387ef2745a430f` |
| `first_order_checks.py` | `86f2b34658affb25a53b22c6c2f937277593224a5ae172fd82f9e2bd2c01f8ee` |
| `first_order_face_geometry.md` | `65ea9b306242e982374e94601d13e2051703fd5d78aa6101f1b611f99feba5c5` |
| `linear_capture_increment.md` | `fedff25439e3cc7e7408cbb632be6c1ae451c866edf4fe8aae277dfff7504c66` |
| `numeric_notes.md` | `24330b27b5611d45d5f63f6188fdc34c3c000cb8689f5b29976e614514598a71` |
| `proof.tex.txt` | `629cee971f2be10fe721a2ea82523dad763975cda759dd2d22f30a71daab4252` |
| `raw_clock_joint.md` | `e7ae241f7a30c91461ec444375d489f4af07f79553c39cfa0eaa94d9b79e0c1c` |
| `report.md` | `7098c6fc4db7bab817c0b33d7308c34090a4d0ef1764c2d17a2e428bc2b747b8` |
| `reproduce.py` | `9bbe0f902a54e2141a1b64dcd5c2bf0ead7b19c8d36afa8fb663bbd5bb16920c` |
| `task_contract.md` | `33081e6f9914f35cc45e4e61e4f7ea8b6abbe55fb1aa139a9dd735e48b1b0aaa` |

Status: accepted within the precise mathematical and finite-evidence scope above; frozen. General raw/root-order closure remains unproved. No further audit work is pending for this checkpoint.
