# R208 first-order finite checks

The prescribed three stages were actually run: an initial subset first, then the full menu. Final evidence comprises nine Fraction D1 configurations (162 J/S/rho experiments), nine linked-alpha profiles (36 signed evaluations), three common-source capture-capacity models, three double-posterior continuous/deletion models, four h1 constant/optimizer menus at 25/50dps, and six actual physical n=1/2 face integrals at both precisions. No old JSON is imported or reused. Kernel formulas were copied from the frozen R206 source into this standalone script; the physical density, affinity and integrals are recomputed.

## Exact denominator and linked-alpha algebra

D1=rho min(P,BJ)Jdelta/[S(S+delta)] is compared first to rho min(P,BJ)delta/(J+delta) using S>=J, then to rho P h1(Bdelta/P). P=0 is handled before any ratio, and delta=0 and rho=0 branches are included. Each nonzero P configuration uses J equal to half, exactly, or twice P/B; each uses S=J or 2J and rho=0,1/2,1. At J=P/B,S=J the sharp envelope is attained exactly. A separately factored D1 expression agrees exactly. These are conditional scalar fixtures, not original physical or same-source capture qualification.

Initial parameters have P=B=1 and delta=0,1/2,1. Pressure includes P=0, B=64 and B=1/64. Expanded rational ranges include P=10^-6,B=10^6,delta=10^-12 and the reciprocal large-scale tuple, plus a non-dyadic rational tuple. All divisions are exact Fraction operations.

The linked-alpha profile checks c(1-rz)_+-(1-z)_+<=c(1-r) for nine (c,r) pairs. It includes c/r zero and one, c=r=999/1000 and other off-winner combinations. Every row checks z=0,1/4,1,4; z=1 matches the supremum. The actual signed net is retained alongside its positive charge. Negative values are never offered as free payment credit. Alpha-plus=r alpha-minus is the linked scalar interface, not a full-source alpha capacity reconstruction; c=0 is a boundary limit rather than finite positive S/(S+delta).

## Three actual finite capture-reserve models

These additional models reconstruct G from a common finite source, rather than choosing it freely. All have three atoms with nu=J=(1,1,1), Q=3, Eminus={0,1}, Eplus={0,1,2} and persistent T={0,1}. Uminus/Uplus are separately calculated as 1_E min(a,k), Hminus/Hplus=Dq-sum U nu, alpha=H/Q, and G=sum(Uplus-Uminus)nu=Hminus-Hplus. The script verifies nested E, nonnegative H, sum k nu<=Dq and all required positive denominators.

Initial has a=(2,3,2),k=(1,1,1),Dq=5, giving H:3→2,alpha:1→2/3,G=1. Boundary uses the same arrays with Dq=3, giving H:1→0,alpha:1/3→0,G=1. Expanded pressure uses a=(2,1,2),k=(1,2,1),Dq=5; its second persistent target has d<0 and is inactive in both states, while the first has delta=0 but positive recovery. The initial/boundary denominator increments on T are (0,1)/(1,0), and pressure uses (0,1). All have S=2,P=3/2,B=1 and retain the same geometry per target across states.

The persistent total sum a Delta rho nu is respectively 2/3,2/3,1/3, bounded by the same actual G=1. Independently, the script integrates each inactive alpha interval exactly: L_v=J length{lambda in [alpha_plus,alpha_minus]:a-k<=lambda J}. It verifies sum a Delta rho=(G/Q)J(T)-L_T. The total inactive slacks are 0,0,1/3; thresholds and the inactive target are not erased.

With omega=MJ/[a(S+delta)], the actual negative denominator D_T=sum a delta rho_minus/S nu is 1/2,1/3,0. The directly computed weighted signed change sum Delta V/omega nu is 1/6,1/3,1/3, exactly (G/Q)J(T)-L_T-D_T. Positive charges also satisfy sum(Delta V)_+/omega nu<=sum a Delta rho<=G. The denominator term is its actual value, never a positive upper bound offered as negative credit. New-entry a rho is recorded separately and not charged to the persistent capacity. These are common-source conditional algebra examples, not original physical/FIRST/FULL or raw-posterior weight realization; omega does not replace the original measure.

## Double-posterior continuous and deletion identities

Three further exact models use positive rational nu,w, e=sum w nu and Pi_i=w_i nu_i/e, with nonnegative scores k. These define a consistent local clock derivative wdot=-kw. Each computes Pi-dot=(kbar-k)Pi, then computes the product derivative independently from the two Pi-dot factors and compares it to (2kbar-kv-ku)Pi_v Pi_u. For the fixed pre-deletion f, the direct positive score sum equals -Ydot+sum f[2kbar-ku-min(kv,ku)]Pi_vPi_u exactly. This is an instantaneous finite identity, not a numerical time integration of original history.

The initial model has two sources; pressure has three with an explicit f change; expanded has four, repeated scores and two sources deleted concurrently. Direct posterior re-normalization uses the surviving w nu/e_after, not an independently chosen posterior. In each case d=Pi(deleted)<1 and the removed two-leg mass is exactly 2d-d^2. The actual Y jump is compared with all three RC12 terms using post-state f in renormalization/removal and old product measure in the coefficient-exchange term. For the constant f=1 witness, the positive double renormalization and negative removal cancel exactly; neither is discarded.

Direct continuous positive-score sums are respectively 3/4,9/100,3/80. Actual deletion jumps are -3/4,317/450,-7/45, equal to their complete three-term decompositions. The models allow arbitrary fixed nonnegative f and explicitly charged f changes; they are finite source/posterior algebra, not a physical C-kernel, original terminal-support or FIRST/FULL assertion. No original negative credit is consumed by these identities.

## First-order scalar constant

The function is h1(t)=t/(1+t). For theta=1/4,1/2,3/4,999/1000, the tested optimizer is tstar=(1-theta)/theta and Ctheta=theta^theta(1-theta)^(1-theta). The independent derivative relation 1/(1+tstar)=theta and direct h1(tstar)/tstar^theta agree. Each menu checks zero, small, below-peak, peak, above-peak and far points at 25/50dps. The theta=1 boundary has constant one, unattained at finite positive t. Numerical constants/inequalities are noninterval evidence, not general optimization certificates.

## Actual physical N1 and matching tensor factors

The physical kernel uses phi=h*w with E3 inner/outer expressions and fs=(1-s)1_{|x|<=1/2}+s phi. The closed hard interval is used only for the displayed controlled face trace; an original coincident common jump is not declared separately paid. L=1 is fixed, source center is zero, target coordinates are all d and target scale is gamma. A window containing that target needs b>=gamma. This fixed-source calculation is not a receiver-adaptive or history/FIRST/FULL input.

The six (n,s,gamma,d,B,theta) configurations are (1,.5,1,.25,1,.5), (2,.25,1,.25,1,.5), (2,.5,1.2,.5,2,.5), (2,.99,1,.1,16,.75), (2,.01,2,.75,64,.25), and (2,.999,1.005,2,1/16,.999), with two per stage. At each face P=fs(d+-gamma/2) times the remaining source fs product and delta=(1-s)gamma^-n times the remaining target fs product. N1=n|d|sum_faces integral P h1(Bdelta/P), with no leading B. This is the geometric first-order envelope after rho<=1, not a certification of equality to the original raw A/good expression.

For n=1 there is no remaining integral. For n=2 finite integration is on [-40,40], split at +/-.5 and d+-gamma/2. Since P h1<=P, the omitted tail is at most n|d|sum_faces fs(face)*2s exp(.5-40). There is no B factor in this analytic tail. The bound controls truncation only; it does not certify numerical quadrature rounding.

For the same configuration and precision, Atheta=gamma^-theta integral fs(u)^(1-theta)fs((u-d)/gamma)^theta du and ctheta=(1-s)^theta gamma^-theta |d|sum_faces fs(face)^(1-theta) are recomputed. Affinity integration uses its own seam-split cutoff chosen for analytic tail targets 1e-18 and 1e-36. Cache reuse is only by an identical parameter/precision key in the same run. The compared tensor expression is Ctheta B^theta n ctheta Atheta^(n-1), not the earlier B^(1+theta) expression. The affinity's omitted tail is explicitly included in the reported tensor comparison. Both the N1-plus-tail and tensor-plus-tail expressions remain noninterval numerical quantities.

N1 values in case order are approximately .1000956051,.1941353414,.3723286472,.04490389983,1.075810325,.0004879242589. The ratios to their matching tensor expressions are approximately .926167,.847961,.815857,.989985,.769293,.983943. All absolute 25/50dps N1 differences are below 2.10e-25. These differences are empirical sensitivity diagnostics, not certified errors, uniform sharpness or a dimension fit. The B powers, full source/capture weights, posterior normalizers, raw score/time/window, clamp and receiver-selector costs are not erased or declared paid.

## Reproduction

The source uses normal mpmath import; dependency version and entry SHA are recorded. The actual local environment is mpmath 1.3.0 with:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
 /opt/homebrew/opt/python@3.14/bin/python3.14 first_order_checks.py --output first_order_checks.json
```

The default --stage all runs the final menu; --stage initial gives only the initial D1/alpha/physical subset (the scalar constant menu stays complete). The script and local task_contract.md suffice for relocation, with the contract bound by portable filename/SHA. Runtime and machine-specific paths are excluded from JSON. Fraction groups are exact for their finite arrays; all kernel integrals and transcendental constants are noninterval 25/50dps diagnostics.


The final script and contract were copied into a fresh temporary directory and actually run with subprocess exit 0. Complete JSON matched byte-for-byte. Isolated replay took 17.210 seconds (notes only); directory: /var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r208_capture_clock_final_pnbdxpzn.
