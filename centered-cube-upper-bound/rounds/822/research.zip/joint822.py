"""True positive-L1 common-source vs separated-source fan comparison.

Two distinct rays through common x=0 have different pivot blocks. Four small
source blocks are optional depending on alpha; all measures, prices and
candidate-root checks are exact rationals. Positive receiver neighborhoods
are checked by margin, not by replacing source mass with volume.
"""

from fractions import Fraction as F
from itertools import combinations

LOW = F(17, 20)
HIGH = F(17, 10)
T0 = F(9, 10)
T1 = F(23, 20)
EPS = F(1, 100000)
ETA = F(1, 200000)
LAM = F(1)
PPLUS = (F(-7, 20), F(-7, 20))
PMINUS = (F(-7, 20), F(7, 20))
CENTERS = ((F(0), F(0)), (F(1, 8), F(1, 8)), (F(1, 8), F(-1, 8)))
SURPLUS = T1 * T1 - T0 * T0


def norm(x, y):
    return max(abs(x[0] - y[0]), abs(x[1] - y[1]))


def captured(sources, center, t):
    ids = []
    for i, (location, mass, label) in enumerate(sources):
        distance = norm(location, center)
        if distance + EPS + ETA < t / 2:
            ids.append(i)
        else:
            assert distance - EPS - ETA > t / 2
    return tuple(ids)


def certify_last_root(sources, center, expected):
    """For every in-window subset root, eliminate wrong masks by margin.

    For a cube at scale s that partially touches a block, its touched set C
    has mass >= current mass. If that cube were superthreshold, sqrt(mu(C))
    would exceed s; strict candidate-face margins then force all touched
    blocks inside that candidate cube. Thus a later success implies a later
    matching subset root. Total mass below HIGH² rules out upper-end survival.
    """
    assert sum((m for _, m, _ in sources), F(0)) < HIGH * HIGH
    matching = []
    for mask in range(1, 1 << len(sources)):
        mass = sum((m for i, (_, m, _) in enumerate(sources) if mask >> i & 1), F(0))
        if not LOW * LOW < mass < HIGH * HIGH:
            continue
        impossible = False
        for i, (position, _, _) in enumerate(sources):
            distance = norm(position, center)
            surely_inside = 4 * (distance + EPS + ETA) ** 2 < mass
            surely_outside = (
                distance > EPS + ETA and 4 * (distance - EPS - ETA) ** 2 > mass
            )
            if (mask >> i & 1 and surely_outside) or (
                not (mask >> i & 1) and surely_inside
            ):
                impossible = True
                break
            if not surely_inside and not surely_outside:
                # An ambiguous coordinate is harmless if some other block
                # already contradicts this mask, checked by a second pass.
                continue
        if impossible:
            continue
        # For a potential root, require all blocks unambiguously in or out.
        for i, (position, _, _) in enumerate(sources):
            distance = norm(position, center)
            inside = 4 * (distance + EPS + ETA) ** 2 < mass
            outside = distance > EPS + ETA and 4 * (distance - EPS - ETA) ** 2 > mass
            assert inside or outside, (center, mask, i, "unresolved candidate face")
            assert inside == bool(mask >> i & 1)
        matching.append((mass, mask))
    assert matching and max(m for m, _ in matching) == expected * expected, (
        center,
        matching,
    )
    ids = captured(sources, center, expected)
    assert sum((sources[i][1] for i in ids), F(0)) == expected * expected
    return matching, ids


def run(alpha):
    # Both distinct ray directions pass through the actual common early x.
    theta = ((F(1, 2), F(1, 2)), (F(1, 2), F(-1, 2)))
    for i, pivot in enumerate((PPLUS, PMINUS)):
        assert tuple(pivot[j] + F(7, 10) * theta[i][j] for j in range(2)) == CENTERS[0]
        assert (
            tuple(pivot[j] + F(19, 20) * theta[i][j] for j in range(2))
            == CENTERS[i + 1]
        )
    assert CENTERS[1] != CENTERS[2]
    assert norm(CENTERS[1], CENTERS[2]) > 2 * ETA
    # alpha portion of the new mass is shared; remaining portions are
    # genuinely disjoint and separately selected by the two late boxes.
    sources = [(PPLUS, T0 * T0 / 2, "pivot+"), (PMINUS, T0 * T0 / 2, "pivot-")]
    if alpha:
        sources.append(((F(3, 5), F(0)), alpha * SURPLUS, "new_shared"))
    if alpha < 1:
        sources.extend(
            [
                ((F(0), F(69, 100)), (1 - alpha) * SURPLUS, "new_plus"),
                ((F(0), F(-69, 100)), (1 - alpha) * SURPLUS, "new_minus"),
            ]
        )
    assert all(m > 0 for _, m, _ in sources)
    assert all(
        norm(a, c) > 2 * EPS for (a, _, _), (c, _, _) in combinations(sources, 2)
    )
    roots = []
    captures = []
    for center, t in zip(CENTERS, (T0, T1, T1)):
        r, ids = certify_last_root(sources, center, t)
        roots.append(r)
        captures.append(set(ids))
    early, plus, minus = captures
    assert 0 in early and 0 in plus and 0 in minus
    plusnew = plus - early
    minusnew = minus - early
    added = [sum((sources[i][1] for i in ids), F(0)) for ids in (plusnew, minusnew)]
    union = plusnew | minusnew
    both = plusnew & minusnew
    unionmass = sum((sources[i][1] for i in union), F(0))
    bothmass = sum((sources[i][1] for i in both), F(0))
    assert added == [SURPLUS, SURPLUS]
    assert unionmass == SURPLUS * (2 - alpha) and bothmass == SURPLUS * alpha
    assert sum(added, F(0)) - unionmass == bothmass
    print(
        "\nCASE shared_fraction=",
        alpha,
        "source total=",
        sum((m for _, m, _ in sources), F(0)),
        "lambda=",
        LAM,
    )
    print("  sources=", [(name, str(m)) for _, m, name in sources])
    print(
        "  true roots mass/mask=",
        roots,
        "early,late capture ids=",
        [sorted(x) for x in captures],
    )
    print(
        "  per late added=",
        added,
        "summed=",
        sum(added, F(0)),
        "true union=",
        unionmass,
        "duplicate=",
        bothmass,
        "sum/union=",
        sum(added, F(0)) / unionmass,
    )
    print(
        "  q lies in pivot+ block of positive mass=",
        sources[0][1],
        "; early source mass=",
        T0 * T0,
        "late masses=",
        T1 * T1,
        "window=",
        (LOW, HIGH),
        "all three neighborhoods positive",
    )


if __name__ == "__main__":
    assert LOW < T0 < T1 < HIGH and HIGH / LOW == 2
    for alpha in (F(1), F(1, 2), F(0)):
        run(alpha)
    print(
        "\nPASS: exact positive-L1 three-center constructions and all later-root candidate checks"
    )
