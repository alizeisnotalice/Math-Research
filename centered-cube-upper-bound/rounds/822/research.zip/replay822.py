"""Replay all checked finite configurations and report the actual math runtime."""
import platform
import subprocess
import sys
from pathlib import Path

import flint


root = Path(__file__).resolve().parent
print("Python",platform.python_version(),"python-flint",flint.__version__,
      "FLINT",flint.__FLINT_VERSION__,flush=True)
for script in ("joint822.py","marginals822.py","births822.py","tails822.py"):
    print("\nRUN",script,flush=True)
    subprocess.run([sys.executable,"-B",str(root/script)],cwd=root,check=True)
print("All round 822 experiments completed",flush=True)
