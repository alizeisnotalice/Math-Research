"""Exact shell births in a Walsh family of centered-cube last roots.

Run with python3 -B births822.py. Only the Python standard library is used.
Each source is uniform on a full-dimensional cube. Each tested receiver
neighborhood has positive volume. The data test geometry at threshold one.
"""

from fractions import Fraction
from hashlib import sha256


F = Fraction


def exp_bounds(x, terms=24):
    """Rational lower and upper bounds for exp(x), using a geometric tail."""
    assert 0 <= x < terms + 2
    term = total = F(1)
    for k in range(1, terms + 1):
        term = term * x / k
        total += term
    next_term = term * x / (terms + 1)
    tail = next_term / (1 - x / (terms + 2))
    return total, total + tail


def bin_index(price):
    k = price.numerator.bit_length() - price.denominator.bit_length()
    if F(2) ** k > price:
        k -= 1
    assert F(2) ** k <= price < F(2) ** (k + 1)
    return k


def walsh_negative_masks(n):
    """Bit j records that the jth entry of the Walsh row is negative."""
    width, rows = 1, [0]
    while width < n:
        bits = (1 << width) - 1
        rows = ([r | (r << width) for r in rows]
                + [r | ((bits ^ r) << width) for r in rows])
        width *= 2
    assert width == n and len(set(rows)) == n
    assert all(row & 1 == 0 for row in rows)
    for i, first in enumerate(rows):
        assert all((first ^ other).bit_count() == n // 2
                   for other in rows[i + 1:])
    return rows


def interval_text(low, high, digits=8):
    scale = 10 ** digits
    lo = low.numerator * scale // low.denominator
    hi = -(-high.numerator * scale // high.denominator)
    def format_endpoint(value):
        whole, frac = divmod(value, scale)
        return f"{whole}.{frac:0{digits}d}"
    return f"[{format_endpoint(lo)},{format_endpoint(hi)}]"


def fingerprint(rationals):
    digest = sha256()
    for value in rationals:
        for integer in (value.numerator, value.denominator):
            assert integer >= 0
            data = integer.to_bytes(max(1, (integer.bit_length() + 7) // 8), "big")
            digest.update(len(data).to_bytes(4, "big"))
            digest.update(data)
    return digest.hexdigest()[:20]


def certify(n, same_layer=False):
    rows = walsh_negative_masks(n)
    if same_layer:
        t0, step = F(33, 32), 1 + F(3, n)
        displacement = t0 / (4 * n)
        name = "common-slack calibration"
    else:
        t0, step, displacement = F(9, 8), 1 + F(2, n), F(1, 5)
        name = "R821 Walsh parameters"

    sides = [t0 * step ** j for j in range(3)]
    v = [s ** n for s in sides]
    bins = [bin_index(value) for value in v]
    delta = F(1, 10000 * n)
    eps, eta = delta / 4, delta / 8
    r0 = t0 - displacement
    pivot_amplitude = r0 / 2
    centers = [(s - t0) / 2 for s in sides]
    birth_centers = [s - t0 / 2 - delta for s in sides[1:]]
    birth_mass = [v[j] - v[j - 1] for j in (1, 2)]
    pivot_mass = v[0] / n
    assert 1 < min(sides) < max(sides) < 2
    assert bins == sorted(set(bins)) and all(mass > 0 for mass in birth_mass)
    assert n * pivot_mass + sum(birth_mass) == v[-1] < 2 ** n

    # Pivot i is centered at -r0 times Walsh row i / 2; its true source box
    # has half-width eps. Birth h is centered at birth_centers[h-1] on axis 1.
    assert r0 > 2 * eps
    assert min(birth_centers) + pivot_amplitude > 2 * eps
    assert birth_centers[1] - birth_centers[0] > 2 * eps
    # All 1+2n receiver cubes (half-width eta) are disjoint: at fixed level
    # different signs differ by 2*c; between levels coordinate 1 differs.
    assert all(b - a > 2 * eta for a, b in zip(centers, centers[1:]))
    assert 2 * centers[1] > 2 * eta

    # At the canonical centers r_j=s_j-displacement and all points of the
    # same arm lie on the ray through its own pivot and the early center.
    radii = [s - displacement for s in sides]
    assert all(r - r0 == 2 * c for r, c in zip(radii, centers))
    if same_layer:
        assert r0 > 1 and all(1 <= (s / r) ** n < 2
                               for s, r in zip(sides, radii))
        _, exp2_high = exp_bounds(F(2))
        assert all((b / a) ** n > 2 * exp2_high
                   for a, b in zip(radii, radii[1:]))
        # Thus n log(s/r) lies in [0,1) and the consecutive radial log
        # prices are separated by more than log(2)+2 at the central rays.

    print("CASE", name, "n=", n, "Walsh pivots/arms=", len(rows))
    print("  scale order", ",".join(map(str, sides)), "dyadic log2 bins", bins,
          "source half-width", eps, "receiver half-width", eta)
    print("  source masses: n pivots each t0^n/n; birth j has t_j^n-t_(j-1)^n",
          "exact mass digest", fingerprint([pivot_mass, *birth_mass]))
    print("  physical receivers at levels 0,1,2:", [1, n, n],
          "orthogonal row pairs", n * (n - 1) // 2)

    exp1_low, exp1_high = exp_bounds(F(1, n))
    strict_margins = []
    contact_margins = []
    pivot_degree = 0
    birth_degree = [0, 0]
    for j, (t, c) in enumerate(zip(sides, centers)):
        copies = 1 if j == 0 else n
        first_margin = len(strict_margins)
        # All Walsh rows have positive first entry. Consequently the exact
        # maximum coordinate distance to EVERY initial pivot is c+r0/2,
        # even across different rays. No product-source model is used.
        pivot_margin = t / 2 - (c + pivot_amplitude + eps + eta)
        assert pivot_margin > 0
        strict_margins.append(pivot_margin)
        pivot_degree += copies
        capture = []
        for h, z1 in enumerate(birth_centers, start=1):
            distance = max(abs(z1 - c), c)
            inside = t / 2 - (distance + eps + eta)
            outside = distance - eps - eta - t / 2
            assert inside > 0 or outside > 0
            assert (inside > 0) == (h <= j)
            if inside > 0:
                capture.append(h)
                birth_degree[h - 1] += copies
                strict_margins.append(inside)
            else:
                strict_margins.append(outside)
                # Even first contact with any part of a later birth is
                # strictly past that later birth's own price.
                contact_margin = 2 * (z1 - c - eps - eta) - sides[h]
                assert contact_margin > 0
                contact_margins.append(contact_margin)
        assert n * pivot_mass + sum((birth_mass[h-1] for h in capture), F(0)) == t ** n
        # There is strict success immediately below t. At any later scale s,
        # either no new birth is touched, or the largest touched birth h>j
        # has s>t_h and the total touched mass <=t_h^n. This proves the
        # rightmost-root assertion on the entire open receiver neighborhoods.
        price_below = t - min(t - 1, min(strict_margins[first_margin:])) / 2
        assert 1 < price_below < t and price_below ** n < t ** n
        print("  root level", j, "captured all", n, "pivots; births", capture,
              "true number of captured source blocks", n + len(capture))

        if j == 0:
            continue
        # R822's early-centered envelope for H_j=n log(t_j/t0):
        # inner=t0 exp(-1/n), outer=t_j*(1+exp(1/n))-t0. Give certified
        # directed inequalities even for independent receiver perturbations.
        exact_inner = t0 - 4 * eta
        exact_outer = 2 * t - t0 + 4 * eta
        outer_low = t * (1 + exp1_low) - t0
        outer_high = t * (1 + exp1_high) - t0
        assert t0 / exp1_low < exact_inner
        assert exact_outer < outer_low <= outer_high < 2
        # The original Walsh pivots lie inside this inner envelope. In the
        # common-slack case they are between that envelope and Q_t0, still
        # entirely in the early source and therefore outside the shell.
        assert 2 * (pivot_amplitude + eps + eta) < t0
        if same_layer:
            assert 2 * (pivot_amplitude - eps - eta) > t0 / exp1_low
        else:
            assert 2 * (pivot_amplitude + eps + eta) < t0 / exp1_high
        shell_ids = []
        for h, z1 in enumerate(birth_centers, start=1):
            near, far = 2 * (z1 - eps - eta), 2 * (z1 + eps + eta)
            assert near > t0
            # In every point of this source block, relative to every early
            # receiver, only physical coordinate 1 exceeds the inner face.
            assert 2 * (eps + eta) < t0 / exp1_high < near
            if h <= j:
                assert far < exact_outer
                shell_ids.append(h)
            else:
                assert near > outer_high
        shell = sum((birth_mass[h-1] for h in shell_ids), F(0))
        assert shell_ids == capture and shell == t ** n - t0 ** n
        assert t ** n <= exact_outer ** n
        # Each of n late boxes sees this same physical new mass exactly once.
        print("    true common shell blocks", shell_ids, "active face: +1 only;",
              "per-late/union mass=1, summed/union=", copies,
              "shell mass digest", fingerprint([shell]))
        shell_fraction = shell / v[0]
        radial_use = shell / (exact_outer ** n - v[0])
        print("    outward decimal bounds for shell/early",
              interval_text(shell_fraction, shell_fraction),
              "and shell/centered future capacity", interval_text(radial_use, radial_use))
        print("    R822 inner side", interval_text(t0 / exp1_high, t0 / exp1_low),
              "outer side", interval_text(outer_low, outer_high))
        print("    all receiver perturbations: inner side t0-4*eta =", exact_inner,
              "outer side 2*t_j-t0+4*eta =", exact_outer,
              "strictly between R822's directed bounds, below window top 2")
    assert pivot_degree == 1 + 2 * n and birth_degree == [2 * n, n]

    # Actual common rays persist for a positive set of physical x and
    # independently chosen p_i near their nominal values. Set
    # y=x+(2*c/r0)*(x-p_i). Its perturbation is <=(1+2*max_scale)*tau.
    max_scale = 2 * centers[-1] / r0
    tau = min(eps, eta) / (4 * (1 + 2 * max_scale))
    assert 0 < tau < eps and (1 + 2 * max_scale) * tau < eta
    if same_layer:
        assert r0 - 4 * tau > 1
        for t, c in zip(sides, centers):
            ratio = 1 + 2 * c / r0
            assert ratio * (r0 + 4 * tau) < t
            assert (t / (ratio * (r0 - 4 * tau))) ** n < 2
        print("  actual positive ray neighborhoods stay in integer slack layer zero;",
              "each radial price ratio exceeds 2*exp(2)")
    receiver_mass = (1 + 2 * n) * (2 * eta) ** n
    assert 2 ** n * receiver_mass < v[-1]
    print("  true degrees by distinct receiver: each initial pivot", pivot_degree,
          "; births 1,2", birth_degree)
    print("  positive actual-ray subsample: early half-width and pivot half-width", tau,
          "; each tested receiver volume=(2*eta)^n, M/S<2^(-n)")
    print("  certified minimum strict root-membership margin", min(strict_margins),
          "; minimum later-birth first-contact margin", min(contact_margins),
          "; lambda=1; global last roots throughout; top 2 subthreshold")


def main():
    for n in (16, 64, 256, 1024):
        certify(n)
    certify(64, same_layer=True)
    print("PASS exact positive-L1 shell births, all Walsh receivers, face membership and true degrees.")
    print("The exterior blocks have positive volume and centers on axis 1; that one coordinate decides membership.")


if __name__ == "__main__":
    main()
