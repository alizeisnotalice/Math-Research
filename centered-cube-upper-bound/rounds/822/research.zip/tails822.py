"""Checks exact angular volumes and interval binomial tails in the receiver bound."""
import itertools
import math
from fractions import Fraction as F
from flint import arb, ctx


def rational_reference():
    for n in (2, 3, 5):
        grid = range(6)
        # Four of six equal subintervals form the inner interval on each axis.
        measured = [0] * (n + 1)
        for cell in itertools.product(grid, repeat=n):
            measured[sum(i in (0, 5) for i in cell)] += 1
        for j, count in enumerate(measured):
            assert F(count, 6**n) == F(math.comb(n, j) * 2**j * 4**(n-j), 6**n)
        print("exact receiver grid", n, measured)
    for n in (2, 8, 32, 128):
        # Equal l1 shifts lead to very different cube intersections.
        edge = F(1) - F(1, 2**n)
        axis = 1 - edge
        spread = (1 - edge / n)**n
        assert 0 < axis < spread < 1
        print("same l1 shift", n, "single-axis product", axis,
              "distributed product approx", format(float(spread), ".9g"))


def tail(n, h, ell):
    one = arb(1)
    outer = (arb(h)/n).exp() + (arb(h+1)/n).exp() - 1
    ratio = (-one/n).exp() / (outer * (arb(2).log()/n).exp())
    p = 1 - ratio
    mean_bound = arb(2*h+2) + arb(2).log()
    assert n*p < mean_bound and outer**n < arb(2*h+1).exp()
    # Sum the upper tail in positive terms, stable even for a small probability.
    j = ell + 1
    term = arb(math.comb(n, j)) * p**j * ratio**(n-j)
    prob = term
    while j < n:
        term = term * (n-j)*p / ((j+1)*ratio)
        prob += term
        j += 1
    chernoff = (arb(1).exp()*mean_bound/(ell+1))**(ell+1)
    assert prob > 0 and prob < chernoff
    return n*p, prob, chernoff


def interval_reference():
    cases = ((16,1,10),(64,2,25),(256,2,32),(1024,3,42),(4096,3,52))
    old = {}
    for precision in (256,384):
        ctx.prec = precision
        for case in cases:
            results = tail(*case)
            if case in old:
                assert all(a.overlaps(b) for a,b in zip(old[case],results))
            old[case] = results
            print("Arb",precision,"n,H,L",case,"mean,tail,bound",
                  *[x.str(13) for x in results])
        for n in (16,256,4096):
            u = arb(1)/4
            true = (1-u)**n
            assert true < (-u*n).exp()
            # Test against the weaker dyadic endpoint exponential of the proof.
            assert arb(2)*true < 2*(-u*n/2).exp()
    print("interval comparison passed at both precisions")


if __name__ == "__main__":
    rational_reference()
    interval_reference()
