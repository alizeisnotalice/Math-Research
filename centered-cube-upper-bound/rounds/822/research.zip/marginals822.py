"""Real-cube, real-source marginal capacity comparison for joint822.

The natural demand is lambda*|E_i|*P_i(z)*P_i(q), not an R813 history.
The amplified runs are explicitly labeled capacity-model sensitivity tests.
All flows and geometric areas use exact Fraction arithmetic.
"""

from collections import deque
from fractions import Fraction as F
import joint822 as geom


def optimal(demand, qmass, receiver_caps, mode):
    # s -> source pool(s) -> record nodes -> physical receiver -> sink
    nr = len(demand[0])
    ng = 2 if mode == "pair" else 1
    source = 0
    group0 = 1
    edge0 = group0 + ng
    recv0 = edge0 + 2 * nr
    sink = recv0 + nr
    N = sink + 1
    cap = [[F(0) for _ in range(N)] for _ in range(N)]
    for g in range(ng):
        cap[source][group0 + g] = qmass
    for z in range(2):
        for i in range(nr):
            v = edge0 + z * nr + i
            g = z if mode == "pair" else 0
            cap[group0 + g][v] = demand[z][i]
            cap[v][recv0 + i] = demand[z][i]
    for i in range(nr):
        cap[recv0 + i][sink] = (
            receiver_caps[i]
            if mode == "physical"
            else sum((demand[z][i] for z in range(2)), F(0))
        )
    residual = [row[:] for row in cap]
    flow = F(0)
    while True:
        prev = [-1] * N
        prev[source] = source
        queue = deque([source])
        while queue and prev[sink] < 0:
            v = queue.popleft()
            for j in range(N):
                if prev[j] < 0 and residual[v][j] > 0:
                    prev[j] = v
                    queue.append(j)
        if prev[sink] < 0:
            break
        path = []
        v = sink
        while v != source:
            path.append((prev[v], v))
            v = prev[v]
        increment = min(residual[a][b] for a, b in path)
        for a, b in path:
            residual[a][b] -= increment
            residual[b][a] += increment
        flow += increment
    allocations = [
        [
            cap[edge0 + z * nr + i][recv0 + i] - residual[edge0 + z * nr + i][recv0 + i]
            for i in range(nr)
        ]
        for z in range(2)
    ]
    assert sum((sum(row, F(0)) for row in allocations), F(0)) == flow
    for z in range(2):
        for i in range(nr):
            assert 0 <= allocations[z][i] <= demand[z][i]
    pools = [sum(allocations[g], F(0)) for g in range(2)] if mode == "pair" else [flow]
    assert all(v <= qmass for v in pools)
    recv = [sum((allocations[z][i] for z in range(2)), F(0)) for i in range(nr)]
    if mode == "physical":
        assert all(recv[i] <= receiver_caps[i] for i in range(nr))
    return (
        flow,
        allocations,
        [i for i, v in enumerate(pools) if v == qmass],
        (
            [i for i, v in enumerate(recv) if v == receiver_caps[i]]
            if mode == "physical"
            else "not imposed"
        ),
    )


def sample(alpha, eta):
    t0, t1 = geom.T0, geom.T1
    qmass = t0 * t0 / (2 * 30000**2)
    pivotmass = t0 * t0 / 2
    # q is a central subsquare of pivot+, with side 1/30000 of its host.
    # z0 is pivot-; z1 is the disjoint positive remainder of pivot+.
    left = (pivotmass, pivotmass - qmass)
    assert qmass > 0 and min(left) > 0
    sources = [(geom.PPLUS, pivotmass, "pivot+"), (geom.PMINUS, pivotmass, "pivot-")]
    if alpha:
        sources.append(((F(3, 5), F(0)), alpha * geom.SURPLUS, "shared"))
    if alpha < 1:
        sources.extend(
            [
                ((F(0), F(69, 100)), (1 - alpha) * geom.SURPLUS, "plus"),
                ((F(0), F(-69, 100)), (1 - alpha) * geom.SURPLUS, "minus"),
            ]
        )
    assert eta <= geom.ETA
    for center, t in zip(geom.CENTERS, (t0, t1, t1)):
        _, ids = geom.certify_last_root(sources, center, t)
        assert 0 in ids and 1 in ids
    assert all(
        geom.norm(a, b) > 2 * eta
        for i, a in enumerate(geom.CENTERS)
        for b in geom.CENTERS[i + 1 :]
    )
    area = (2 * eta) ** 2
    volumes = (t0 * t0, t1 * t1, t1 * t1)
    receiver_caps = [area / v for v in volumes]  # exact integral_{E_i} dx / v_i
    demands = [[area * left[z] * qmass / (v * v) for v in volumes] for z in range(2)]
    natural_total = sum((sum(row, F(0)) for row in demands), F(0))
    print(
        "\nGEOMETRY alpha=",
        alpha,
        "eta=",
        eta,
        "qmass=",
        qmass,
        "left actual masses=",
        left,
        "receiver masses=",
        receiver_caps,
    )
    print(
        "natural original two-source restricted demand=",
        natural_total,
        "lambda=1; NOT R813 parent history",
    )
    rho = 2 * qmass / sum(demands[0], F(0))
    for label, multiplier in [("natural", F(1)), ("sensitivity", rho)]:
        d = [[x * multiplier for x in row] for row in demands]
        values = []
        for mode in ("pair", "shared", "physical"):
            value, assignment, sourcesat, receiversat = optimal(
                d, qmass, receiver_caps, mode
            )
            values.append(value)
            print(
                "  ",
                label,
                "rho=",
                multiplier,
                "mode=",
                mode,
                "paid=",
                value,
                "paid_float=",
                float(value),
                "source saturated=",
                sourcesat,
                "physical receivers saturated=",
                receiversat,
                "model demand paid fraction=",
                value / sum((sum(row, F(0)) for row in d), F(0)),
            )
        assert values[0] >= values[1] >= values[2]
        if label == "natural":
            assert values[0] == values[1] == values[2] == natural_total
        else:
            assert values[0] > values[1] > values[2]
            assert (
                values[0] == 2 * qmass
                and values[1] == qmass
                and values[2] == sum(receiver_caps, F(0))
            )


if __name__ == "__main__":
    for alpha in (F(1), F(0)):
        sample(alpha, geom.ETA)
        sample(alpha, geom.ETA / 2)
    print(
        "\nPASS exact real cube and source marginals; amplified values are a finite capacity model, not R813 original mass"
    )
