#!/usr/bin/env python3
"""Finite exact polynomial integration checks; n=1 logarithms are noninterval."""
import argparse
from fractions import Fraction as F
import hashlib,json,math
from pathlib import Path

def run():
    cases=[('initial',2,F(1,2)),('initial',3,F(3,4)),('initial',4,F(1)),
           ('pressure',16,F(1,2)),('pressure',64,F(63,64)),('pressure',128,F(127,128)),
           ('expanded',256,F(1,2)),('expanded',512,F(511,512)),('expanded',1024,F(1023,1024))]
    rows=[]
    for stage,n,r in cases:
        normalized=F(n,n-1)*(1-r**(n-1))
        geometric=F(n,n-1)*(1-r)*sum((r**k for k in range(n-1)),F(0))
        unweighted=n*(1/r-1)
        assert normalized==geometric
        assert 0<=normalized<=2 and normalized<=unweighted
        assert (normalized==0)==(r==1)
        exact=f'{normalized.numerator}/{normalized.denominator}'
        rows.append(dict(stage=stage,n=n,r=str(r),normalized_exact_sha256=hashlib.sha256(exact.encode()).hexdigest(),normalized_display=float(normalized),unweighted=str(unweighted),geometric_sum_equal=True,normalized_le_2=True,normalization_not_dropped=True))
    logs=[]
    for r in (F(1,2),F(3,4),F(1)):
        v=-math.log(float(r))
        assert float(1-r)-1e-15<=v<=float((1-r)/r)+1e-15
        assert v<=math.log(2)+1e-15
        logs.append(dict(r=str(r),log_display=v,status='FINITE_NONINTERVAL_LOG_CHECK'))
    return dict(schema='r205_clamp_integral_v1',exact_cases=rows,n1_log_diagnostics=logs,scope='Finite polynomial/geometric-sum certificates and noninterval n=1 logs. The general integration proof is in PG5; no original weighted clamp budget or selector payment.',status='PASS_FINITE_CHECKS')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True,type=Path);a=ap.parse_args()
    out=run();a.output.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print('PASS 9 exact clamp integrals and 3 noninterval n=1 diagnostics')
