# R205 independent premise audit

## 1. Order and scope

Read only `task_contract.md` before this screen, not the new author manuscripts. The auditor owns only this file and performs no Git, spawning, numerical execution or PDF compilation. The original beta, two copies of Pi, common alpha, cap, receiver selector and window account remain part of the target problem.

## 2. Equal-cube face flux

Let C_y and C_v be closed axis-parallel cubes of common side L, let d=v-y and t_i=|d_i|/L. Consider the specified nonnegative face functional

    L^(-n) sum_i |d_i| integral_(partial_i C_v) 1_(C_y) dH^(n-1),

where partial_i includes both faces. Away from contact degeneracies its value is

    sum_i t_i 1_(t_i<=1) product_(j!=i) (1-t_j)_+.

The same formula with the stated closed-face convention holds at contact: each relevant end face is counted; zero-displacement coincident faces have zero coefficient. With all t_i in [0,1], this is the probability of exactly one success for independent auxiliary Bernoulli parameters t_i and is at most one. The auxiliary Bernoulli calculation is a finite algebraic proof, not an independence assumption on the physical sources. If some t_i>1, the expression is zero, except for the remaining product terms already killed by that coordinate; the same bound holds. Normalizing an actual face integral against the outer uniform density therefore gives a dimension-free bound for this exact translation-mismatch functional.

The coefficient |v_i-y_i| is justified for the material field X_y=x-y only when the v-cube side evolves proportionally to L: its boundary normal velocity cancels the radius part of X_y. This statement is not a bound for arbitrary face velocities or for a sum of unweighted areas. At coincident physical discontinuities, the specified closed-face functional remains a geometric upper tool, but a distributional product still requires the actual joint finite jump or chosen trace. A closed value cannot replace a side trace in the original current/capture product.

## 3. Unequal but proportional sides

For a target cube of side gamma L and outer cube of side L, write a_i=|I_y,i intersect I_v,i|/L and let N_i be the number of target endpoints inside the closed outer interval. Then the functional is exactly

    sum_i t_i N_i product_(j!=i) a_j.

Here 0<=a_i<=1 and elementary interval geometry gives

    t_i N_i <= 1-a_i+(gamma-1)_+/2.

For gamma<=1, two endpoints inside give 2t_i<=1-gamma=1-a_i; one endpoint inside gives t_i=(1+gamma)/2-a_i<=1-a_i. For gamma>=1 there is at most one endpoint inside, with t_i=(1+gamma)/2-a_i, including its contact bound. Thus the full functional is at most

    1 + (n/2)(gamma-1)_+,

and in particular at most 1+n|gamma-1|. The first sum uses the same exactly-one-success algebra with parameters 1-a_i; the added sum is bounded by n. This is for a common fixed proportional gamma and the translation mismatch above. For the actual clamped Lplus=min(b,gamma L), the proportional-velocity argument applies only in the unclamped cell. In the clamped cell the boundary velocity is zero and its omitted radius term must be retained separately. Endpoints and simultaneous y/v faces require whole finite changes.

## 4. Exact original-kernel application requirements

For fixed cap Bcap, fixed physical parameters and a current-v face at which p_y and J are continuous, F is continuous and the finite change of mathcalB=z^2 F is F Delta(z^2). Its magnitude is at most F, and F<=Bcap p_y. This makes the cube flux relevant to the outer hard-uniform component, with the actual cap still present. It does not itself estimate a common y/v jump, a changed cap, or the full rho/capture product. Those require the common-state finite identity, the actual shared alpha change and the gate-entry terms.

For full mixed f_s products, the outer density is a coordinatewise mixture. A pure uniform overlap identity cannot be applied to its soft coordinates: they have nonzero mass on faces outside the hard cube. Any expansion or separate soft bound must keep its exact mixture weights, face coefficients and all selector costs; the n+1 Bernstein envelope or an independently proved sharper joint argument cannot be silently omitted. Nor does bounded Delta(z^2) preserve a factor 1-s without an additional finite-jump estimate. The true current-v and K0 faces, changed a,k,rho, and the original capture/current simultaneous traces remain unpriced by this geometric lemma.

All these face estimates are fixed-pair statements. Passing to the original beta(dy) Pi_y,t(dv) Pi_y,t(du), a receiver-dependent selector or independent windows requires the genuine fixed-reference qualification and its actual mass/time/window price. In particular Bcap=B0/Wg is source dependent and potentially large; a face estimate proportional to Bcap does not pay that occupation. Only a common legal parameter family permits signed aggregation before positive part or scale supremum. Measurable gates acquire neither BV nor traces from this cube calculation. No general raw root-order payment is accepted at this initial stage.

## 5. Initial decision

The specified equal-size flux bound and the proportional unequal-size extension pass the independent screen with the precise conventions above. They are constructive geometric tools, not yet a full mixed-kernel/capture or global-source budget. Awaiting the authors' accurate statements and complete proofs for the next review stage.

## 6. Sharper generic-face supremum, independently checked

After the initial screen, the parent proposed an exact generic-face supremum. With strict interior endpoint counts (no contact trace assignment), the supremum over displacement is

    max(n(lambda-1)/2,(lambda+1)/2),                    lambda>=1;
    lambda^(n-1) max(n(1-lambda),(1+lambda)/2),          0<lambda<=1.

This passes. For lambda>=1 put c=(lambda-1)/2. In a partial coordinate the overlap q is in (0,1) and its one-face coefficient is c+1-q. The expression extended over q in [0,1]^n is multi-affine. At a vertex, all q=1 gives nc, a single q=0 gives c+1, and two or more zero coordinates give zero. Vertices needed for the supremum are approached by partial coordinates, not by assigning both traces at contact. Nonpartial coordinates with q=1 and zero face count cannot increase the upper bound. For lambda<=1 put c=(1-lambda)/2. A partial coordinate has q in (0,lambda) and coefficient c+lambda-q. A fully contained interval has q=lambda, with both faces strictly inside and coefficient 2|d| approaching 2c. Treat the possible partial coordinates multi-affinely; replace any endpoint q=lambda coefficient c by the larger full-containment value 2c. All-full vertices give n(1-lambda)lambda^(n-1); a single zero gives (c+lambda)lambda^(n-1); two zeros give zero. These bounds are approached by the corresponding generic configurations. The n=1 formulas and lambda=1 both agree, including the one-zero limiting configuration. Empty intersections do not give a hidden n-fold contribution.

If both uniform kernel densities are present, rather than just the outer probability weight used above, the functional has the additional factor (lambda L)^(-n). That normalization must be included explicitly in any original-kernel application. None of the exact generic suprema chooses a physical trace at a simultaneous discontinuity.

## 7. Full-softness mixed-kernel candidate screen

Before reading author proofs, independently checked the accurate mixed candidate sent as a statement. The probability representation is kappa_s=(1-s)delta_0+s w and f_s=h*kappa_s. An outer coordinate shift A_i has E|A_i|=2s/3. A target coordinate is hard with probability 1-s and then its shift is exactly zero; soft target coordinates have shift law w. These random variables represent only the known product receiver kernels. They do not assert physical-source independence.

For a selected hard target face, its effective center displacement is d_i/L-A_i. Thus |d_i|/L is bounded by the effective absolute displacement plus |A_i|. The first term is bounded, for every draw, by the pure-cube supremum C_(gamma,n), and is zero if no target coordinate is hard. Its expectation is at most C_(gamma,n)(1-s^n). For the remainder, the face count is at most two, and each other coordinate's independent expected overlap is exactly

    integral f_s(r) f_s((r-d_j/L)/gamma) dr.

Let c_star=1-phi(0)=2 integral_0^1 t exp(-1/(2t))dt. Since phi is even decreasing, f_s<=m_s=1-c_star s. The displayed overlap is at most m_s min(1,gamma), using either factor's supremum and integrating the other. Also c_star>=3/(4e), by restricting t to [1/2,1]. Independence of these other-coordinate shifts from the selected coordinate gives the sharpened bound

    F_s <= L^(-n) gamma^(-n) [ C_(gamma,n)(1-s^n)
             +(4/3)n s(1-s)(m_s min(1,gamma))^(n-1) ].

The normalization is the actual product of the two uniform-kernel densities. For gamma>=1, C_(gamma,n)/gamma^n<=1, while n(c_star s)(1-c_star s)^(n-1)<=1. Hence

    F_s <= [1+4/(3c_star)] L^(-n) <= (1+16e/9)L^(-n).

The cases n=1 (empty other-coordinate product), s=0 (pure geometry) and s=1 (no hard face, flux zero) are treated directly without ambiguous zero powers. The common softness in the two actual kernels is used in the mean-shift and overlap estimates; different softness parameters require their own formula. This removes the former n s remainder for this fixed-pair homothetic kernel functional. It is not a bound on the original weighted cap/capture face or a global source account.

## 8. Finite-denominator and clamp candidate screen

If only the target denominator enters a face, with F,J,Bcap and other qualifications frozen, S_plus=S_minus+delta p gives

    mathcalB_minus-mathcalB_plus
      =F J^2 delta p/S_minus^3 * (2+delta p/S_minus)/(1+delta p/S_minus)^2
      <=2(Bcap/J) p_y delta p.

The finite formula is correct. Simultaneous p_v and p_vplus entries use their total delta p once. If outer p_y/F, actual cap, rho/alpha or gates also change, this frozen-denominator formula must be embedded in the whole finite product; it cannot discard their traces. The mixed-kernel bound applies directly only after the real coefficient Bcap/J times the actual gate is uniformly bounded or otherwise paid, and that coefficient is not currently controlled by the geometry alone.

For a nonproportional target side ell(L), the material boundary coefficient is d_i+epsilon(ell-dot ell)/2, where dot ell=partial_logL ell. The omitted radius contribution has the valid crude additional price

    L^(-n)n(1-s)|1-dot ell/ell| min(1,gamma)^(n-1)/gamma^(n-1),

with gamma=ell/L. In particular clamp is not covered for free by the homothetic estimate. Its extra term, all actual weighted/finite-state terms and receiver/source/selector costs remain. Awaiting full manuscripts; these accurate candidates pass within this stated scope.

## 9. Further finite-jump candidates, before their proofs

The parent's sharper denominator proposal passes independently. For P>0 put x=BJ/P, t=B delta/P. Increasing the nonjump background q can only decrease the difference of the two inverse squares, so first set q=0 for an upper bound. The ratio of the loss to BP becomes

    min(x,1/x) [1-(x/(x+t))^2].

On x<=1 it increases: its derivative's positive numerator is t^2(3x+t). On x>=1 it decreases, since it equals 1/x-x/(x+t)^2 and its derivative is negative (equivalently differentiate t(2x+t)/[x(x+t)^2]). Hence the maximum is at x=1, giving

    D <= BP [1-(P/(P+B delta))^2] <= min(BP,2B^2 delta).

For P delta>0 equality occurs at q=0,J=P/B; P=0 or delta=0 is zero first. This removes J from this pointwise loss, but its nonlinear delta/P factor is not the bilinear kernel functional already bounded above. A common rho factor may be retained; changed rho, cap, outer current or gates need their true joint finite change.

The author's common-capture recovery coefficient also passes at the accurate candidate level. If alpha_minus>=alpha_plus>=0 and a,k,J,Q have genuine common traces, then with d_+=max(1-k/a,0),

    0<=rho_plus^2-rho_minus^2
      <=d_+^2 (alpha_minus-alpha_plus)/(alpha_minus+alpha_plus).

The double-zero branch is set to zero. Otherwise normalize r=alpha_plus/alpha_minus and z=alpha_minus J/(a d_+) when d_+>0: the sharp supremum of (1-rz)_+^2-(1-z)_+^2 is (1-r)/(1+r), at z=1/(1+r); d_+=0 is zero first. With actual nested capture traces, gain G=H_minus-H_plus gives the same scalar G/(H_minus+H_plus), shared once by all targets. On persistent common gates the identity splits into mathcalB_plus times this rho gain minus (mathcalB_minus-mathcalB_plus)rho_minus^2. Entries and all other exchanges remain. For positive H, the coefficient is tanh(half the log ratio) and is at most half that log ratio. Recharging requires the actual positive variation of log H; a zero endpoint retains the finite coefficient rather than an infinite-log substitution. These conditional trace statements do not prove that all original faces have that nesting or pay repeated recovery.

## 10. Full overlap manuscript review

After the screens, read the complete 228-line `overlap_face_geometry.md`, SHA-256 `a2015c1595192b17f64c4b3dce2a76da59c98260eef292c8d381d61467980520`. OF1–21 pass without a necessary revision. The pure-cube two-branch proof, all-s kernel labeling and the sharpened remaining-coordinate average in OF13, normalization and zero branches in OF14, and the extra m_s^n clamp face bound in OF17 are correct. The last refinement uses one source-face factor bounded by m_s and the n-1 overlap factors bounded by m_s min(1,gamma). OF18–21 retain the genuine fixed-F/trace restriction and the Bcap/J factor, and do not use an upper loss bound as a net negative credit. The manuscript distinguishes full hardface kernel geometry from continuous terms, source weights, alpha/capture exchanges and selector budgets. No general original payment is inferred.

## 11. Full parent weighted manuscript review

Read complete `parent_weighted_geometry.md` PG1–6 after the scalar screen. No necessary revision was found. The sharp scalar proof, matching abstract parameters, zero branches and the subadditivity for a total same-event jump are correct. Its warning that an upper bound on D cannot replace the true negative contribution -D by the more negative -G is essential and present. The exact gate exchange retains entry and exit.

The PG4 return to the positive physical face measure is accurate: G_B(P,delta)/(P delta)=B^2(2P+B delta)/(P+B delta)^2 on P delta>0. Zero-product contributions vanish first. The layer-cake identity integrates the real H K_B distribution under that measure and does not claim a uniform coefficient. Its total O(1) geometric mass alone cannot control an unbounded K_B. PG5 only integrates common parameter paths s(r),gamma(r) with gamma>=1 and preserves the L(r)^n normalization. It does not assert a receiver-dependent graph or free source/cap/window payment. The skill-use comment in the parent proof is not an imported external theorem in this audit.

## 12. Numerical code static review checkpoint

Read complete current `face_geometry_checks.py` without executing it. The 18 small-dimensional groups use exact interval intersections and strict face counts, independently checked by partition-midpoint lengths and explicit individual-face sums; direct products avoid division by zero overlaps. Contact configurations are rejected rather than assigned a physical trace. The 30 constructed higher-dimensional configurations are finite witnesses, not a general supremum proof. The two-density normalization is separately recorded.

The added recovery checks correctly recompute Hminus,Hplus and both alphas from one common two-source configuration, verify G/(Hminus+Hplus), and check the persistent denominator/recovery balance for each of two mathcalB pairs. Entering-source potential is explicitly outside that identity. Nine scalar recovery and two zero-branch cases have the right exact algebra. Nine cap-jump cases check the sharp inequality and both weaker caps with P=0/delta=0 first. Nine binomial cases use the conservative rational c0=1/4 and a full exact binomial expansion; the two-precision mpmath c_star/phi(0) computations are correctly labeled noninterval diagnostics. These finite checks do not certify the all-s theorem, original physical eligibility/history or a global source budget. Awaiting final notes/JSON binding and the remaining author/TeX integration.

## 13. Full joint manuscript review

Read complete `joint_face_budget.md`, version `947f80d8fec853ed84e295cef0cdf0c7dfe35347c02a777bb530d4e202802226`. JF1–17 pass without a necessary mathematical revision. The accurate capture nesting and common a,k,J,Q,Dq hypotheses are explicit, the scalar sharp recovery proof and all zero/end cases agree with the independent screen, and the persistent-target balance retains the actual negative denominator loss. Different outer y keep their own common alpha and recovery coefficient. Gain-only logarithmic accumulation does not remove varying target baseline masses; recharge and zero crossings have their actual costs. The post-geometry intermediate-state finite decomposition is exact and does not require recomputing alpha. Complete gate entry/exit and changed posterior/source measures remain.

The high-A entry band follows from Sminus>=J and Aplus<=J/Splus. The low-K0 entry ratio is not paid using positivity alone. Actual source traces and the original beta Pi^2, unique-j mask, time/window and selector account are retained. The fixed-source cap envelope with its full-soft/scale factor is only used under its established qualifications; source-dependent tiny Wg is not discarded. The common-source fixtures are explicitly abstract finite calibration, not physical/FIRST/FULL certificates. No general original root-order payment follows from this manuscript alone.

## 14. Added clamp path screen and static certificate

Independently checked the added PG5 statement before its final transcription. In the clamped segment ell=b, L0=max(a,b/gamma0), the OF17 extra face bound is

    A(L)<=L^(-n)n(1-s)m_s^n(L/b)^(n-1).

Dropping only (1-s)m_s^n<=1 and integrating with the explicit L^n factor gives n[1-(L0/b)^(n-1)]/(n-1)<=2 for n>=2; n=1 gives log(b/L0)<=log2. Without that factor, direct integration gives n b^(-(n-1))(1/L0-1/b), which retains an n-order price. These calculations are valid for common s=s(L); neither is a receiver-dependent selector bound or payment of continuous/bulk/gate terms. The manuscript and final report state that distinction.

Read `clamp_integral_checks.py/json` statically. The nine rational n>=2 cases compare the polynomial integral to an independently summed finite geometric series and preserve the zero interval. Their dimensionless unweighted comparison is the b=1/scaled expression n(1/r-1), r=L0/b. The three n=1 logarithms are explicitly ordinary noninterval floating-point diagnostics. No audit-side numerical execution was performed, and the finite checks are not a proof of a weighted original clamp budget.

## 15. Final numerical, report and reproducer review

Read the added `mixed_face_checks` and final `numeric_notes.md` plus the frozen JSON. The six physical repeated-coordinate menus use the exact OF12 tensor formula with gamma^(-n) retained, the original E3 piecewise phi, and all four hard seams. For n=1 the overlap is not computed because the product is empty. On the stated menus all seams lie inside [-30,30]. The omitted overlap tail is at most 2s exp(1/2-30), since the first factor is s phi outside that interval and the other factor is at most one. Raising q plus that tail to n-1 yields the recorded analytic tail enlargement; it does not certify quadrature or rounding. Both precisions, the actual finite comparisons against OF13/14 and the honest noninterval labels are consistent. The two split-delta envelope and two recharge ledger additions have correct exact directions. The JSON reports 18 groups, 2079 generic configurations, 2274 excluded contacts, 30 higher-dimensional constructions, 9 scalar recoveries, 5 common-source models with two balances each, 2 zero branches and 6 mixed configurations, consistently with the notes and report.

The final report distinguishes the three new tools from the unpaid K_B occupation, capture entry/recharge/current geometry, selector and full beta Pi^2/j/time/window costs. It also distinguishes the normalized clamp path from the original unweighted price. Read the reproducer: it verifies the future manifest, then executes both actual --output interfaces at fresh paths and compares each whole JSON byte-for-byte. This static audit does not pre-certify that future driver execution. Reported author/parent runs remain their finite evidence, not an audit-side run or general proof.

## 16. Full final TeX review and conclusion

Read the complete 860-line `proof.tex.txt` after the individual manuscripts, including all OF/PG/JF proofs, normalized and unweighted clamp integration, finite evidence and remaining scope. The mathematical transcription and stated evidence match the reviewed manuscripts. One necessary quantifier repair was identified independently by the parent and auditor: the common-path hypothesis must read s(r) in [0,1] and gamma(r)>=1, not s(r),gamma(r)>=1. The repaired line was actually reread. A subsequent single min-to-backslash-min notation repair does not change the formula. No PDF compilation was performed.

Accepted results are the exact pure-cube supremum, the full-s homothetic mixed-hardface bound, the qualified clamp path bounds, the sharp finite-denominator envelope and common-alpha recovery balance/ledger. They are not a general original raw source payment or weak-type closure. Actual cap coefficients and low-density K_B occupation, common finite capture/current traces and entries, recharge and geometry, receiver selectors, source occupation and original energy pairing all remain at their stated prices. No necessary mathematical revision remains. Final file hashes below exclude this audit and the future manifest; final package execution/archive status belongs to the parent after this freeze.

## 17. Frozen SHA-256 bindings

Byte hashes of the twelve reviewed files, excluding this audit and the future manifest:

| File | SHA-256 |
| --- | --- |
| `clamp_integral_checks.json` | `4ed9c474c1ca9049c30e1b905decad586d68a95c2eef91f07a0357d1ff79f6f0` |
| `clamp_integral_checks.py` | `30fa93e9db0d532462e4e430959cfb88c6d08a0f1d755503ee5677afd03b21a7` |
| `face_geometry_checks.json` | `5ede325d1bcb9b4efbe3f79efc4992f12eeec53e1f5727a54dc76afd75b77024` |
| `face_geometry_checks.py` | `56e9a6587b345578645be69b2a72d2425088f6d769067d2ed3589b89ad1fdfe0` |
| `joint_face_budget.md` | `947f80d8fec853ed84e295cef0cdf0c7dfe35347c02a777bb530d4e202802226` |
| `numeric_notes.md` | `90d01efb396c34aaa867d668bc5568e0a219011437b1aa7947cf780611c9a55f` |
| `overlap_face_geometry.md` | `a2015c1595192b17f64c4b3dce2a76da59c98260eef292c8d381d61467980520` |
| `parent_weighted_geometry.md` | `8a1ce63597a860792087ea45c03e57b1e51ae9e4cd6d0d94351adb7371e46c97` |
| `proof.tex.txt` | `9c268d8f3637f9f0bded57fa8a4cf698aa666b17e6cbd6704cf76825b2ec1fab` |
| `report.md` | `42e20aee5f832d07ba823984635be313256ef3b0220ae980f08421e1088aa618` |
| `reproduce.py` | `6a02a33f7a60e505b7282846ea645c0bef68fc7d89a9eafc240cba193e079e8a` |
| `task_contract.md` | `9cfa82c4a1c52bac9346785a40a5c95f432b768f126a17457f46a996c8d846f9` |

Final status: accepted within the stated qualifications; no necessary revision remains. Audit frozen after actual rereading of the final two TeX repairs.
