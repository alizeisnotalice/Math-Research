# R205：原中间硬层的联合面几何

基线 eb8dee5dbacb7157710a40d4140fc144b218b25e 已推送且远端核验，开始工作区干净。上轮已完成独审、两脚本重放和归档，是实质进展。一般根阶上界未完成。

本轮目标直接估计真实 current-v 硬面与共同来源捕获交换，不重命名余项。原 p=P_s,L(x-y)、p_v=P_s,L(x-v)、p_v+=P_s,min(b,gamma L)(x-v)、J_v=P_1,b(x-v)，F=min(p²,Bcap²J²)/J，mathcalB=z²F，z=J/(p_v+p_v++J)，Bcap=B0/Wg(y,v)。d=1−k/a，zeta=alpha J/a，rho=(d−zeta)+；原 a=TDelta、k=DK0、alpha Q=Dq−integral U nu、Pi=eta nu/e。保留 beta Pi²、全部门及选择器。

准确瓶颈：R204 JC23 的同源聚合潜能净下降，与真实 current k/a 面和 JC21 入口共同结算。目标是可代入原预算的新不等式，不把固定参数核价冒充一般付款。重点是接收空间的交叠面几何及共同源的符号，而非逐个面计数乘 n。

Astra 沿现有上下文集中 joint current/capture 面，交付实际新估计及完整费用或最窄未付项。Sol 辅助路线研究一般两立方体交叠面通量及混合核扩展，必须明确哪些界适用于原全 s 核，不能以 s=0 结束；主代理推导加权/尺度版本并接回真实预算。独审先独立筛选命题再读作者证据。数值 Sol 按确定公式做三阶段本机精确/高精度核验，不拟合渐近阶。

允许工具：R201 TI/ST 全部已审核的物理输运与 score 界；R204 BP/JC/ME 的共同 alpha 原函数、容量、weighted 矩包络。有限 cube 交叠与 Fubini 可自证。不得假定 full nu 位置矩、beta>=nu、资格门 BV、固定尺度与receiver selector换序、单行容量可每次重复领取或核 sqrt(n)可直接配 n 能量闭合。

文件责任：Astra joint_face_budget.md；辅助 Sol overlap_face_geometry.md；独审 audit.md；数值 Sol face_geometry_checks.py/json 及 numeric_notes.md；父 parent_weighted_geometry.md/report.md/proof.tex.txt/reproduce.py。不改他人文件，不自行spawn/git，完成就停止。只有完整核验的一轮才按紧凑包单独提交；不编译PDF。
