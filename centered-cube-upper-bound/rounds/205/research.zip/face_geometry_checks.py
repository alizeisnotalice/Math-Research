#!/usr/bin/env python3
"""Finite exact face/capture checks plus noninterval kernel constants; no FULL claim."""
import argparse,hashlib,json,math
from fractions import Fraction as F
from itertools import product
from pathlib import Path
HERE=Path(__file__).resolve().parent
HALF=F(1,2)


def enc(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x


def candidate(n,lam):
    assert n>=1 and lam>0
    if lam>=1:return max(n*(lam-1)/2,(1+lam)/2)
    return lam**(n-1)*max(n*(1-lam),(1+lam)/2)


def contact(d,lam):
    return any(a+sign*lam/2 in (-HALF,HALF) for a in d for sign in (-1,1))


def length_by_partition(center,lam):
    edges=sorted({-HALF,HALF,center-lam/2,center+lam/2})
    length=F(0)
    for left,right in zip(edges,edges[1:]):
        middle=(left+right)/2
        if -HALF<middle<HALF and center-lam/2<middle<center+lam/2:length+=right-left
    return length


def geometry(d,lam):
    n=len(d);assert n>=1 and lam>0 and all(x>=0 for x in d) and not contact(d,lam)
    q=[max(F(0),min(HALF,x+lam/2)-max(-HALF,x-lam/2)) for x in d]
    m=[sum(-HALF<x+sign*lam/2<HALF for sign in (-1,1)) for x in d]
    direct=sum((d[i]*m[i]*math.prod(q[j] for j in range(n) if j!=i) for i in range(n)),F(0))
    # Independent interval-partition lengths and individual-face enumeration.
    partition=[length_by_partition(x,lam) for x in d];assert partition==q
    faces=F(0)
    for i in range(n):
        for sign in (-1,1):
            face=d[i]+sign*lam/2
            if -HALF<face<HALF:
                faces+=d[i]*math.prod(partition[j] for j in range(n) if j!=i)
    assert direct==faces and 0<=direct<=candidate(n,lam)
    zeros=sum(x==0 for x in q)
    if zeros:assert direct==0
    return {'T':direct,'q':q,'m':m,'zero_overlap_coordinates':zeros,'bound':candidate(n,lam),'ratio':direct/candidate(n,lam)}


def small_grid(lam):
    a=abs(1-lam)/2;b=(1+lam)/2;epsilon=min(lam,F(1))/64
    values={F(0),a,a+epsilon,(a+b)/2,b-epsilon,b,b+epsilon}
    if a:values.add(a/2)
    if a>=epsilon:values.add(a-epsilon)
    return sorted(values),epsilon


def enumerate_group(stage,n,lam):
    values,epsilon=small_grid(lam)
    tested=rejected=zeros=multiple=0;maximum=None;zero_witness=None
    for d in product(values,repeat=n):
        if contact(d,lam):rejected+=1;continue
        result=geometry(d,lam);tested+=1
        zeros+=result['zero_overlap_coordinates']>0;multiple+=result['zero_overlap_coordinates']>=2
        if result['zero_overlap_coordinates']>=2 and zero_witness is None:zero_witness=list(d)
        if maximum is None or result['T']>maximum['T']:maximum={'center':list(d),**result}
    assert tested+rejected==len(values)**n
    return {'stage':stage,'n':n,'lambda':lam,'coordinate_grid':values,'grid_epsilon':epsilon,
        'generic_tested':tested,'contact_excluded':rejected,'enumerated_total':len(values)**n,
        'zero_overlap_tested':zeros,'multiple_zero_overlap_tested':multiple,'multiple_zero_witness':zero_witness,
        'maximum_on_this_grid':maximum,'status':'PASS'}


def family_group(n,lam,kind):
    a=abs(1-lam)/2;b=(1+lam)/2
    epsilon=min(lam,F(1),a if a else F(1))/(10000*n)
    if kind=='all_faces':
        if lam<1:d=[a-epsilon]*n
        else:d=[a+epsilon]*n
    else:
        d=[F(0)]*n;d[0]=b-epsilon
        if lam==1:
            for i in range(1,n):d[i]=epsilon
    result=geometry(d,lam)
    return {'stage':'expanded','n':n,'lambda':lam,'family':kind,'epsilon':epsilon,'center':d,**result,'status':'PASS'}


def pos(x):return max(F(0),x)


def recovery_checks():
    rows=[]
    cases=[('initial',F(0),F(0)),('initial',F(0),F(3)),('initial',F(1,2),F(2,3)),
        ('stress',F(1),F(10)),('stress',F(1023,1024),F(1024,2047)),('stress',F(1,4),F(4)),
        ('expanded',F(2,7),F(7,9)),('expanded',F(31,37),F(1000)),('expanded',F(1,1000),F(1))]
    for stage,r,z in cases:
        gain=pos(1-r*z)**2-pos(1-z)**2;bound=(1-r)/(1+r)
        assert 0<=gain<=bound
        if z<=1:assert bound-gain==(1-r*r)*(z-1/(1+r))**2
        rows.append(dict(stage=stage,r=r,z=z,gain=gain,bound=bound,equality=gain==bound))
    coupled=[]
    for index,r in enumerate([F(0),F(1,4),F(1,2),F(3,4),F(1)]):
        nu=[F(1),F(1)];J=[F(1),F(1)];a=[F(2),2*(1-r)/(1+r)+1];k=[F(1),2*(1-r)/(1+r)]
        Q=sum(J);C=1+2/(1+r);Em=[1,0];Ep=[1,1]
        Hm=C-sum(min(a[i],k[i])*nu[i]*Em[i] for i in range(2))
        Hp=C-sum(min(a[i],k[i])*nu[i]*Ep[i] for i in range(2))
        am=Hm/Q;ap=Hp/Q;assert am>0 and ap/am==r and sum(k)<=C
        d=1-k[0]/a[0];rm=pos(d-am*J[0]/a[0]);rp=pos(d-ap*J[0]/a[0])
        G=Hm-Hp;cap=G/(Hm+Hp);assert cap==(1-r)/(1+r)
        assert rp*rp-rm*rm==d*d*cap
        balances=[]
        for Bm,Bp in [(F(1),F(1)),(F(1),F(1,2))]:
            net=Bp*rp*rp-Bm*rm*rm
            rhs=Bp*d*d*G/(Hm+Hp)-(Bm-Bp)*rm*rm
            assert net==rhs
            balances.append(dict(Bminus=Bm,Bplus=Bp,net=net,exact_denominator_rhs=rhs))
        coupled.append(dict(stage=('initial' if index<2 else 'stress' if index<4 else 'expanded'),r=r,nu=nu,J=J,a=a,k=k,C=C,Eminus=Em,Eplus=Ep,QJ=Q,Hminus=Hm,Hplus=Hp,alpha_minus=am,alpha_plus=ap,d=d,rho_minus=rm,rho_plus=rp,balances=balances))
    # Degenerate alpha/d branches precede division, as required by normalization.
    zeros=[]
    for am,ap,d in [(F(0),F(0),F(1)),(F(1),F(1,2),F(0))]:
        gain=pos(d-ap)**2-pos(d-am)**2;assert gain==0
        zeros.append(dict(alpha_minus=am,alpha_plus=ap,d=d,gain=gain,ratio_not_formed=True))
    ledgers=[]
    for label,H in [('decreasing',[F(8),F(4),F(2),F(1)]),('recharge',[F(8),F(4),F(8),F(4)])]:
        decline=sum((pos(x-y) for x,y in zip(H,H[1:])),F(0))
        recharge=sum((pos(y-x) for x,y in zip(H,H[1:])),F(0))
        prices=sum((pos(x-y)/(x+y) for x,y in zip(H,H[1:])),F(0))
        assert decline==H[0]-H[-1]+recharge
        if label=='recharge':assert prices>(H[0]-H[-1])/(H[0]+H[-1])
        ledgers.append(dict(label=label,H=H,positive_decline=decline,positive_recharge=recharge,sum_drop_prices=prices,ledger_identity=True))
    return dict(scalar_cases=rows,same_source_cases=coupled,zero_branches=zeros,recharge_ledgers=ledgers,status='PASS_FINITE_EXACT',scope='Persistent target only; entering source has its own additional potential and is not erased. Hcap loss is recomputed from the full common source, not freely assigned alphas.')


def cap_jump_checks():
    cases=[('initial',F(0),F(1),F(1),F(0),F(1)),('initial',F(1),F(1),F(1),F(0),F(0)),('initial',F(1),F(1),F(1),F(0),F(1)),
        ('stress',F(1),F(2),F(1,2),F(0),F(3)),('stress',F(999,1000),F(1),F(1),F(1,1000),F(1,1000)),('stress',F(1001,1000),F(1),F(1),F(2),F(10)),
        ('expanded',F(1,1000000),F(1000),F(1,1000000000),F(0),F(1000)),('expanded',F(1000),F(1,1000),F(1000000),F(0),F(1,1000)),('expanded',F(7,11),F(13,17),F(19,23),F(29,31),F(37,41))]
    rows=[]
    for stage,P,B,J,q,delta in cases:
        Fcap=min(P*P/J,B*B*J)
        loss=Fcap*J*J*(1/(q+J)**2-1/(q+J+delta)**2)
        sharp=F(0) if not P else B*P*(1-(P/(P+B*delta))**2)
        crude=min(B*P,2*B*B*delta)
        assert 0<=loss<=sharp<=crude
        delta1=delta/3;delta2=2*delta/3
        envelope_parts=[F(0) if not P else B*P*(1-(P/(P+B*h))**2) for h in (delta1,delta2)]
        assert sharp<=sum(envelope_parts)
        if P and q==0 and J==P/B:assert loss==sharp
        rows.append(dict(stage=stage,P=P,B=B,J=J,q=q,delta=delta,F=Fcap,loss=loss,sharp_bound=sharp,crude_bound=crude,sharp_equality=loss==sharp,delta1=delta1,delta2=delta2,separate_envelopes=envelope_parts,joint_envelope_le_separate=True))
    return dict(cases=rows,status='PASS_FINITE_EXACT',scope='Scalar cap/denominator loss only; no original physical or global budget claim.')


def kernel_constant_checks():
    import mpmath as mp
    constants=[]
    for precision in (25,40):
        with mp.workdps(precision):
            phi0=1-2*mp.expint(3,mp.mpf('0.5'));c=1-phi0;lower=3/(4*mp.e)
            assert c>=lower>mp.mpf(1)/4 and mp.e<3
            constants.append(dict(dps=precision,phi0=mp.nstr(phi0,precision),c=mp.nstr(c,precision),analytic_comparison=mp.nstr(lower,precision),e=mp.nstr(mp.e,precision),status='PASS_NUMERICAL_NONINTERVAL'))
    with mp.workdps(40):
        assert abs(mp.mpf(constants[0]['c'])-mp.mpf(constants[1]['c']))<mp.mpf('1e-24')
    rows=[]
    for stage,n,s in [('initial',1,F(0)),('initial',1,F(1)),('initial',2,F(1)),('stress',4,F(1)),('stress',16,F(1,4)),('stress',64,F(1,16)),('expanded',128,F(1,32)),('expanded',256,F(1)),('expanded',1024,F(1,256))]:
        x=s/4;value=n*s*(1-x)**(n-1)
        # Independent full probability expansion, including endpoint x=0.
        binomial=sum((F(math.comb(n,k))*x**k*(1-x)**(n-k) for k in range(n+1)),F(0))
        onehit=n*x*(1-x)**(n-1)
        assert binomial==1 and 0<=onehit<=1 and value==4*onehit and value<=4
        rows.append(dict(stage=stage,n=n,s=s,c0=F(1,4),value=value,bound=F(4),one_hit_probability=onehit,full_binomial_sum=binomial))
    entry=Path(mp.__file__)
    return dict(constants=constants,binomial_cases=rows,dependency=dict(name='mpmath',version=mp.__version__,entry_sha256=hashlib.sha256(entry.read_bytes()).hexdigest()),scope='Constants are two-precision numerical diagnostics, not directed intervals. Rational envelope uses c0=1/4 only, and the full binomial expansion is exact on these finite cases.',status='PASS_MIXED_EXACT_AND_NONINTERVAL')


def mixed_face_checks():
    import mpmath as mp
    cases=[(1,'0.5','1','0.25'),(2,'0.25','1','0.25'),(4,'0.5','1.2','0.5'),(16,'0.01','1.02','0.1'),(64,'0.5','1','0.02'),(128,'0.99','1.005','0.1')]
    rows=[]
    for index,(n,ss,gg,dd) in enumerate(cases):
        runs=[]
        for precision in (25,40):
            with mp.workdps(precision):
                s=mp.mpf(ss);g=mp.mpf(gg);d=mp.mpf(dd);X=mp.mpf(30);half=mp.mpf('0.5')
                def phi(x):
                    r=abs(x)
                    if r>=half:return mp.expint(3,r-half)-mp.expint(3,r+half)
                    return 1-mp.expint(3,half-r)-mp.expint(3,half+r)
                def fs(x):return (1-s)*int(abs(x)<=half)+s*phi(x)
                seams=sorted(set([-X,-half,half,d-g/2,d+g/2,X]))
                tail=2*s*mp.exp(half-X)
                if n==1:q=None;power=mp.mpf(1);upperpower=mp.mpf(1)
                else:
                    q=sum(mp.quad(lambda u:fs(u)*fs((u-d)/g),[lo,hi]) for lo,hi in zip(seams,seams[1:]))
                    power=q**(n-1);upperpower=(q+tail)**(n-1)
                factor=(1-s)*g**(-n)*n*d*(fs(d-g/2)+fs(d+g/2))
                flux=factor*power;tail_enlarged=factor*upperpower
                m=1-s+s*phi(0);a=min(mp.mpf(1),g)
                C=mp.mpf(candidate(n,F(gg)).numerator)/candidate(n,F(gg)).denominator
                of13=g**(-n)*(C*(1-s**n)+mp.mpf(4)/3*n*s*(1-s)*(m*a)**(n-1))
                of14=1+16*mp.e/9
                assert 0<=flux<=tail_enlarged<=of13<=of14
                if q is not None:assert q+tail<=m*a
                def fmt(x):return None if x is None else mp.nstr(x,precision)
                runs.append(dict(dps=precision,q_truncated=fmt(q),q_tail_upper=fmt(tail),q_not_needed=n==1,seams=[fmt(x) for x in seams],flux_truncated=fmt(flux),flux_with_analytic_q_tail=fmt(tail_enlarged),OF13_bound=fmt(of13),OF14_bound=fmt(of14),q_pointwise_envelope=fmt(m*a),status='PASS_NUMERICAL_NONINTERVAL'))
        with mp.workdps(45):
            difference=abs(mp.mpf(runs[0]['flux_truncated'])-mp.mpf(runs[1]['flux_truncated']))
            tolerance=mp.mpf('1e-20')*max(1,abs(mp.mpf(runs[1]['flux_truncated'])))
            assert difference<tolerance
            diff=mp.nstr(difference,40)
        rows.append(dict(stage=('initial' if index<2 else 'stress' if index<4 else 'expanded'),n=n,s=ss,gamma=gg,d=dd,L='1',runs=runs,crossprecision_flux_difference=diff))
    return dict(cases=rows,status='PASS_NUMERICAL_NONINTERVAL',scope='Physical product mixed-kernel fixed-parameter face flux via its one-dimensional tensor formula; no original adaptive selector/capture/history/FIRST/FULL certificate. Analytic q tail is separate from uncertified quadrature rounding; tail-enlarged flux is not an interval enclosure.')


def run():
    lambdas=[F(1,8),F(1,3),F(1,2),F(1),F(3,2),F(2)]
    initial=[enumerate_group('initial',1,l) for l in lambdas]
    stress=[enumerate_group('stress',n,l) for n in (2,3) for l in lambdas]
    expanded=[]
    for n in (4,16,64,128):
        for lam in (1-F(1,2*n),F(1),1+F(1,n),1+F(4,n)):
            for kind in ('all_faces','one_face'):
                if lam==1 and kind=='all_faces':continue
                expanded.append(family_group(n,lam,kind))
    for kind in ('all_faces','one_face'):expanded.append(family_group(64,F(1,8),kind))
    assert len(expanded)==30
    return {'schema':'r205_face_and_capture_checks_v2','arithmetic':'Fraction exact groups; mpmath 25/40dps constants are noninterval',
        'inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'domain':'n>=1, lambda>0, center coordinates>=0; configurations with any face at outer +/-1/2 are excluded as nongeneric',
        'formulas':{'q_i':'max(0,min(1/2,d_i+lambda/2)-max(-1/2,d_i-lambda/2))',
            'm_i':'number of d_i +/- lambda/2 strictly inside (-1/2,1/2)',
            'T':'sum_i d_i m_i product_{j!=i} q_j',
            'bound_lambda_ge_1':'max(n(lambda-1)/2,(1+lambda)/2)',
            'bound_lambda_le_1':'lambda^(n-1) max(n(1-lambda),(1+lambda)/2)'},
        'initial_groups':initial,'stress_groups':stress,'expanded_families':expanded,
        'recovery_checks':recovery_checks(),'cap_jump_checks':cap_jump_checks(),'kernel_constant_checks':kernel_constant_checks(),'mixed_face_checks':mixed_face_checks(),
        'summary':{'small_dimension_groups':len(initial)+len(stress),
            'generic_grid_configurations':sum(g['generic_tested'] for g in initial+stress),
            'contact_grid_configurations_excluded':sum(g['contact_excluded'] for g in initial+stress),
            'expanded_constructed_configurations':len(expanded),
            'maximum_expanded_ratio':max(g['ratio'] for g in expanded)},
        'normalization':'T uses the outer-weight convention. For two uniform normalized cube densities the flux has the additional factor L^(-n) lambda^(-n); at outer side L=1 this is lambda^(-n).',
        'status':'PASS_FINITE_CHECKS_EXACT_AND_NONINTERVAL_CONSTANTS','limitations':['Finite exact local cube geometry only; no general supremum proof is inferred from the finite grid or near-extremal families.',
            'Contact configurations are excluded, not assigned a free closed-trace jump or counted as generic evidence.',
            'No zero-overlap division is used; products excluding one coordinate are computed directly.',
            'No high-dimensional Cartesian enumeration, asymptotic fit, uniform mixed-soft-kernel proof or original capture/history/FIRST/FULL certificate.']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'face_geometry_checks.json');args=ap.parse_args()
    r=run();args.output.write_text(json.dumps(enc(r),indent=2,sort_keys=True)+'\n')
    print(json.dumps(enc({'status':r['status'],'summary':r['summary']}),sort_keys=True))
