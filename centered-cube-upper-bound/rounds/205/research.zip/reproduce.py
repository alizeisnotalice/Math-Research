#!/usr/bin/env python3
"""Verify the frozen package and replay finite evidence; not a proof checker."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--verify-only',action='store_true')
parser.add_argument('--output-dir',type=Path)
parser.add_argument('--numeric-python',default=sys.executable)
a=parser.parse_args()
manifest=json.loads((root/'manifest.json').read_text())
for name,digest in manifest.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
print('Verified',len(manifest),'file hashes',flush=True)
if not a.verify_only:
    if a.output_dir is None:parser.error('--output-dir required')
    a.output_dir.mkdir(parents=True,exist_ok=True)
    for stem in ('clamp_integral_checks','face_geometry_checks'):
        out=a.output_dir/(stem+'.json')
        if out.exists():parser.error('Use a fresh output path')
        subprocess.run([a.numeric_python,str(root/(stem+'.py')),'--output',str(out)],check=True,env=os.environ.copy())
        assert out.read_bytes()==(root/out.name).read_bytes(),stem+' complete JSON differs'
        print(stem,'complete JSON byte-identical',flush=True)
