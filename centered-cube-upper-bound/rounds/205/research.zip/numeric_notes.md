# R205 exact relative cube-face checks

The author confirmed the domain n>=1, lambda>0, nonnegative center coordinates and strictly interior face counting. The finite Fraction checker then passed 18 small-dimensional grid groups and 30 high-dimensional constructed configurations. The cube and abstract capture groups are finite exact evidence. Six additional physical mixed-kernel face fluxes are noninterval high-precision diagnostics. None proves the general supremum, all-parameter mixed estimate or original capture/FIRST/history/FULL budget.

## Definitions and independent calculation

The outer cube is [-1/2,1/2]^n. For target side lambda and center d, q_i is the interval overlap length and m_i counts the two target faces d_i+-lambda/2 strictly within (-1/2,1/2). The tested quantity is T=sum_i d_i m_i product_{j!=i}q_j. Every product excluding one coordinate is computed directly; no division by a possibly zero q_i is used.

A second calculation partitions each coordinate by all interval endpoints, integrates the intersection indicator on the rational subintervals, then enumerates target faces individually with their intersection areas. It agrees exactly with the q/m formula. Generic configurations with any zero overlap give T=0, including multiple zero overlaps retained as counted cases and explicit witnesses.

The candidate upper bounds tested are max[n(lambda-1)/2,(1+lambda)/2] for lambda>=1, and lambda^(n-1)max[n(1-lambda),(1+lambda)/2] for lambda<=1. At lambda=1 the two expressions agree. The n=1 switch at lambda=1/3 is included. The code checks only the finite configurations, not a continuous supremum theorem.

## Three finite stages

Initial n=1 uses lambda=1/8,1/3,1/2,1,3/2,2. Pressure n=2,3 uses the same six lambdas and a finite rational coordinate grid built from zero, the containment/inner-face threshold and its neighbors, the outside-overlap threshold and its neighbors, and intermediate points. Exact contact values are included in enumeration but excluded from the generic evidence.

There are 2079 tested generic configurations and 2274 excluded contact configurations across the 18 groups. The JSON records the coordinate grids, epsilon, counts, each group's maximal witness and multiple-zero witnesses, rather than dumping every tuple. It is deterministic to regenerate the full enumeration. A contact is not silently assigned a closed-trace full jump or counted as a failed generic case; an original coincident source/target jump requires its own common-state treatment.

Expanded cases use n=4,16,64,128 and lambda=1-1/(2n),1,1+1/n,1+4/n. Only the stated all-face and one-face families are constructed; the unhelpful all-face lambda=1 family is omitted. Two additional n=64,lambda=1/8 families exercise small lambda. There are 30 configurations total and no high-dimensional Cartesian search. Their rational epsilons keep all faces generic and avoid the lambda=1 coincident-center case. The maximum observed ratio to the candidate bound is exactly 654079999/654080000. This demonstrates a close finite witness, not a fitted asymptotic rate or a general sharpness proof.

## Normalization and scope

T uses the outer-weight convention. For two uniform normalized cube densities at outer side L, the actual flux has the additional factor L^(-n)lambda^(-n); for L=1 it is lambda^(-n)T. That factor has not disappeared and can offset small unnormalized T. No conclusion about normalized soft mixtures or original scale/source payments is drawn from the displayed T ratios.

The cube portion is entirely Fraction arithmetic. The additional capture groups below are abstract finite algebra, not physical source/history data. Kernel constants and the six mixed-kernel configurations use mpmath, with explicitly noninterval accuracy labels.

## Sharp recovery and denominator loss

Nine scalar checks in three stages test (1-r z)_+^2-(1-z)_+^2 <= (1-r)/(1+r), with zero/one r, matching z=1/(1+r), near-one r, thresholds and far z. For z<=1, an independent square-deficit formula is checked exactly. Two degenerate alpha/d branches return zero before forming any ratio.

Five coupled two-source fixtures use nu=J=(1,1), target a=2,k=1, entering-source k=2(1-r)/(1+r), a=k+1, and C=1+2/(1+r). E changes from the target alone to both sources. Hminus/Hplus and alpha are recomputed from C-sum_E min(a,k)nu, with full k capacity retained. The target attains the scalar equality for r=0,1/4,1/2,3/4,1. This is persistent-target evidence; the entering source's additional potential is not discarded or certified paid.

For each source fixture both Bplus=Bminus=1 and Bplus=1/2,Bminus=1 retain the exact negative coefficient term. With G=Hminus-Hplus, the checked exact backsubstitution is net=Bplus*d^2*G/(Hminus+Hplus)-(Bminus-Bplus)*rho_minus^2. The ratio is alpha_plus/alpha_minus, not two freely assigned alpha values. Two exact H ledgers, [8,4,2,1] and [8,4,8,4], retain positive recharge. The second has summed drop prices 2/3, exceeding the endpoint-only 1/3; recharge cannot be discarded. These are finite ledger checks, not a general variation payment.

Nine cap-jump fixtures test F J^2[(q+J)^(-2)-(q+J+delta)^(-2)] <= BP[1-(P/(P+Bdelta))^2] <= min(BP,2B^2delta). Zero P is handled before the ratio. Zero delta, positive q, near/remote cap ratios and large/small scales are included; q=0,J=P/B cases match exactly. Each row also splits delta into delta/3 and 2delta/3 and verifies that the joint positive envelope is at most the sum of separate envelopes. This does not reverse or remove any actual signed negative term.

## All-softness constant and binomial envelope

At 25/40dps, phi0=1-2E3(1/2), c=1-phi0=2E3(1/2) is approximately .4432087285503569. Numerical comparisons c>=3/(4e)>1/4 and e<3 pass, and the c values agree within 1e-24. These transcendental evaluations are not directed interval certificates or proofs of those inequalities.

Nine Fraction cases in three stages use the conservative rational c0=1/4. They independently sum the full Binomial(n,s/4) probability mass and verify n*s*(1-s/4)^(n-1)=4*Pr{exactly one}<=4. n ranges from 1 to 1024, s includes zero, one, and interior peak-scale values. The n=1 zero case uses the polynomial convention exponent zero equals one. No general theorem is inferred solely from this finite menu. The binomial group does not certify a physical flux integral, original full capture/history/FIRST certificate, or dimension fit.

## Actual mixed-kernel fixed-face diagnostics

Six repeated-coordinate configurations (n,s,gamma,d) are (1,.5,1,.25), (2,.25,1,.25), (4,.5,1.2,.5), (16,.01,1.02,.1), (64,.5,1,.02), and (128,.99,1.005,.1), with two cases per stage and L=1. The physical phi is evaluated from the E3 piecewise formula and fs=(1-s)h+s phi, with the closed hard interval used for point traces. The scalar overlap q=integral fs(u)fs((u-d)/gamma)du has no target gamma^-1 factor. Thus the computed OF12 flux is (1-s)gamma^-n n*d*[fs(d-gamma/2)+fs(d+gamma/2)]q^(n-1), retaining gamma^-n. For n=1 the empty product is exactly one, and q is not evaluated.

At 25/40dps, integration is over [-30,30], split at both source and target hard seams, namely +/-.5 and d+-gamma/2. The omitted overlap tail is analytically at most 2s exp(.5-30), since the second fs factor is at most one. Both the finite integral flux and its q-tail-enlarged expression are recorded. That analytic truncation bound does not certify quadrature rounding, so even the latter expression is not called an interval enclosure. Cross-precision agreement is an empirical numerical sensitivity check only. All six configurations pass the OF13/14 comparisons; flux values in their listed order are approximately .1104163, .2181011, .03754143, .2445888, 1.10866e-15, and 3.31540e-60. The maximum absolute 25/40dps difference is below 9.02e-24. These are finite comparisons, not a fitted dimension rate.

The script checks the computed values against OF13, gamma^-n[C_n,gamma(1-s^n)+(4/3)n*s*(1-s)*(m_s min(1,gamma))^(n-1)], where m_s=1-s+s phi0 and C_n,gamma is the cube bound above. It also checks OF14, 1+16e/9, for these gamma>=1 cases, and checks q plus its analytic tail against m_s min(1,gamma). These are actual physical mixed-product kernel calculations through the exact tensor formula, not high-dimensional quadrature, an all-s proof, adaptive-receiver selection, or an original same-capture/history/FIRST example. The actual variable coefficient Bcap/J and all original joint source masses remain outside this diagnostic and are not declared paid.

## Reproduction

Use the existing mpmath 1.3.0 dependency (normal import, no hardcoded vendor path in source), without installation:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
  /opt/homebrew/opt/python@3.14/bin/python3.14 face_geometry_checks.py --output face_geometry_checks.json
```

Relocation needs the script and its local task_contract.md, whose portable filename hash is recorded in JSON. The local interpreter is /opt/homebrew/opt/python@3.14/bin/python3.14. The JSON records mpmath version and entry-file SHA, not its machine-specific path. The exact groups are inexpensive; the six pairs of high-precision physical quadratures dominate the full run. A fresh temporary-directory copy was independently executed and the complete JSON matched byte-for-byte. No runtime or absolute execution path enters JSON. Only the three assigned files were written. All old cube mathematical sections were compared against the prior checkpoint and remained identical. These finite certificates do not certify an all-input or mixed-kernel theorem.
