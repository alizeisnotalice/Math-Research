# R205：共同捕获恢复的尖锐有限增量与 current 分母负面

状态：得到不含逐 target 倒 a、倒 J 的共同捕获恢复界，保留实际 current 分母下降，并给出仅捕获增益路径上的对数累计费用。所有结论在原同一来源、同一 alpha 下成立；一般原中间 hard 净面积分尚未支付。新增资格、储备重新补充以及实际几何变化不能从恢复界中删掉。

## JF1　原对象与比较资格

沿用 R204 JC1 的记号，在固定原 `(omega,V,j,y,t)` 下，
\[
 \Pi(dv)=\eta(v)\nu(dv)/e,\qquad e>0,
 \quad Q=\int J_v\nu(dv),\quad
 H_c=Dq-\int U_v\nu(dv)=\alpha Q\ge0.
\]
这里原 nu、eta、e、Pi 独立 receiver x 和运行 current L；终端捕获、history、high、good 以及 current 参数并不因此冻结。零 e 行先取零。没有假设 nu 小于 beta。

在实际 capture 内的正 a target 上，
\[
 a_v=T\Delta_v>0,\quad k_v=DK_{0v}\ge0,\quad
 d_v=1-k_v/a_v\le1,\quad
 \rho_v=(d_v-\alpha J_v/a_v)_+,
\]
\[
 S_v=p_v+p_v^++J_v,\quad z_v=J_v/S_v,\quad
 F_v={\min(p_y^2,B_v^2J_v^2)\over J_v},\quad
 \mathcal B_v=z_v^2F_v,\quad W_v=\mathcal B_v\rho_v^2. \tag{JF1}
\]
a=0 的实际 target 项先置零，不在那里使用 k/a。下面在门外使用的平方正部只是一份虚拟比较函数，不能当作原门外交通。

首先比较两个同来源状态，假设 a、k、J、Q、Dq 共同，并且实际 capture 集合迹满足 E_- subset E_+。这要求保留原 terminal support、Delta>0、good 与其它捕获资格；不是只凭一条 good 不等式宣告所有原状态嵌套。设
\[
 U_\pm=1_{E_\pm}\min(a,k),\quad
 G=\int(U_+-U_-)\,d\nu\ge0,
 \quad H_\pm=Dq-\int U_\pm\,d\nu.
\]
则 H_+=H_--G，alpha_+-alpha_-=-G/Q。这是实际共同 capture 增益；没有用其上界代替其值。

## JF2　尖锐共同恢复系数

对任意 a>0、k>=0、J>0 和 alpha_->=alpha_+>=0，令
\[
 R(\alpha_-,\alpha_+)=
 \begin{cases}
 (\alpha_--\alpha_+)/(\alpha_-+\alpha_+),&\alpha_-+\alpha_+>0,\\
 0,&\alpha_-+\alpha_+=0.
 \end{cases}
\]
则
\[
 0\le\rho_+^2-\rho_-^2\le d_+^2 R(\alpha_-,\alpha_+). \tag{JF2}
\]
常数是该标量类的最佳常数。

证明：d_+=0 时两平方均零。alpha_-=0 时两 alpha 均零，差为零。其余令 r=alpha_+/alpha_-、z=alpha_-J/(a d_+)。要最大化
\[
 (1-rz)_+^2-(1-z)_+^2.
\]
在 0<=z<=1 上，它等于 `(1-r)[2z-(1+r)z^2]`，最大值为 `(1-r)/(1+r)`，在 z=1/(1+r) 取得。在 1<=z<=1/r 上，它不超过 `(1-r)^2 <= (1-r)/(1+r)`；再往外为零。r=0 时最大值为 1，r=1 时恒零。所有端点均由同一直接公式涵盖，无须除以 alpha_+。

在 JF1 的真实共同 capture 比较中，
\[
 R_c={G\over H_-+H_+}\in[0,1] \tag{JF3}
\]
（双 H=0 时 G=0，取 R_c=0）。因此恢复取决于共同剩余储备的相对消耗，不含任一 target 的倒 a 或倒 J。

## JF3　实际分母负面与来源聚合

暂时再要求 outer p_y、帽 B_v 和 J_v 不变，且 target current 增量使 S_+>=S_-。于是 mathcalB_+<=mathcalB_-。对仍在实际 capture 内的 target，精确有
\[
 W_+-W_-
 =\mathcal B_+(\rho_+^2-\rho_-^2)
  -(\mathcal B_--\mathcal B_+)\rho_-^2
\]
\[
 \le R_c\mathcal B_+d_+^2
  -(\mathcal B_--\mathcal B_+)\rho_-^2. \tag{JF4}
\]
第二项保留实际值。不能用该分母下降量的正上界来替换这里需要的负补偿。

令 h=min(Hgate_-,Hgate_+) 为两状态共同的全部剩余门，在同一原测度 beta(dy) Pi_y(dv) Pi_y(du) 及同一面/有限截断上积分。对每一 y 保留其真实 R_c(y)，得到
\[
 \int h(W_+-W_-)
 \le\int h R_c(y)\mathcal B_+d_+^2
       -\int h(\mathcal B_--\mathcal B_+)\rho_-^2. \tag{JF5}
\]
若固定同一 y，可将其 R_c 提出该行的 u,v 积分；不能把不同 y 的 alpha 选成共同自由标量。共同 current L 允许先在共同测度上聚合 signed 增量再取正部，不能按 target 各自另选 L。

式 JF5 比逐 target 正部计费严格保留更多实际负面。其整体非正的准确充分条件是右侧第一项不超过第二项；这里两项均为原状态的数值，未宣称该条件在一般输入下自动成立。

## JF4　捕获增益路径的累计与 recharge

H_->=H_+>0 时，
\[
 R_c=\tanh\!\left({1\over2}\log{H_-\over H_+}\right)
 \le {1\over2}\log{H_-\over H_+}. \tag{JF6}
\]
因为 tanh x<=x 对 x>=0 成立。故共同 Q、Dq 且只有捕获增益的有限路径 H_0>=...>=H_N>0 满足
\[
 \sum_{i=0}^{N-1}R_i\le\tfrac12\log(H_0/H_N). \tag{JF7}
\]
没有重新进入次数因子。若沿路径 H 有恢复增大，则仅对下降步可写
\[
 \sum_{H_{i+1}<H_i}R_i
 \le\tfrac12\left[
 \log{H_0\over H_N}
 +\sum_{H_{i+1}>H_i}\log{H_{i+1}\over H_i}\right]. \tag{JF8}
\]
右边第二项是必须另付的 recharge；不能每次重新领取初始储备。相等 H 步的恢复费为零。下降至 H=0 的一步 JF3 仍精确为 1，但不使用有限对数价；零后重新激活开启新的正 H 段，不能免费连接穿过零。若 Q 或 Dq 变化，纯 alpha 恢复仍可用 JF2，但 JF3、JF7 的 H 解释须改为实际 alpha 比，并另保 Q、Dq 的变化。

若每步的后态基准来源质量为 S_i=∫h_i mathcalB_{i,+}d_{i,+}^2，则实际正恢复费用是 sum R_i S_i。只有已证明共同 S_i<=S_* 时才能再用 S_* sum R_i。JF7 本身既不支付 S_*，也不授权把随 x、门和尺度变化的 S_i 移出积分。

## JF5　实际几何同时变化的有限分解

此处不冻结真实 a、k、J、F 或帽。令 rho(alpha;g) 表示在几何状态 g=(a,k,J) 上的虚拟平方正部，正 a 两状态内定义
\[
 \widetilde\rho_- =\rho(\alpha_-;g_+).
\]
它只是有限差分的中间值；不重算 alpha、不重选 capture。精确有
\[
 W_+-W_-=
 \mathcal B_+(\rho_+^2-\widetilde\rho_-^2)
 +(\mathcal B_+-\mathcal B_-)\widetilde\rho_-^2
 +\mathcal B_-(\widetilde\rho_-^2-\rho_-^2). \tag{JF9}
\]
若 alpha_+<=alpha_-，第一项由 JF2 支配为 R(alpha_-,alpha_+) mathcalB_+ (d_{+,post})^2。若 alpha 增大，第一项非正。第二项是实际分母/帽/outer current 变化；第三项保留实际 a、k、J 几何交换。它们不能凭第一项的无倒 a 界一并删去。跨 a=0 的状态用原 W 端值直接差分，不能用该中间比值。

同一分解也完全兼容 R204 有界原函数
\[
 \Psi=d_+^2-\rho^2,\qquad
 W=\mathcal B d_+^2-\mathcal P,
 \quad\mathcal P=\mathcal B\Psi:
\quad \Delta W=\Delta(\mathcal B d_+^2)-\Delta\mathcal P. \tag{JF10}
\]
这是全部实际变量的有限恒等式；JF9 选择先隔离共同 alpha 的恢复，而非假定其它势能变化无成本。

全部资格门使用精确交换
\[
 H_+W_+-H_-W_-=
 h(W_+-W_-)+(H_+-H_-)_+W_+
 -(H_--H_+)_+W_-,\qquad h=\min(H_-,H_+). \tag{JF11}
\]
H 可依 u,v，包括原 high、history、time、receiver 域。Pi 或来源测度若变，先在共同支配测度下保留相应密度交换；不能仅凭 fixed-(j,y,t) 的 Pi 性质删去变 j、变 t 或变来源项。这里无需假定 H 为 BV；跨有限状态是精确代数，转成全路径变差则仍需要存在的迹/变差或完整有限分割定义。

## JF6　current 新入口的准确窄带与第一处未付款

在只增加 S_v、保持 p_y、w_g、其它 good 背景资格的比较中，严格 bad 到 good 的新入口满足
\[
 S_v^-<3p_yw_g/K\le S_v^+. \tag{JF12}
\]
两端若落在阈值等号层，须用原实际 good 单侧迹；不能用背景闭不等式替代 one-sided eligibility。原 E 还包含 terminal support、Delta>0 及其它 capture 条件，故完整入口是 JF12 与这些实际迹的交。

若后态原 A=ρJ/S>1−eta（0<eta<1），则
\[
 S_+-J< {\eta\over1-\eta}J,
 \qquad 0\le S_+-S_-< {\eta\over1-\eta}J. \tag{JF13}
\]
这是 high-A 新入口的物理阈值窄带，但没有给其在 beta Pi² dx 下的占用价。任意 L1 来源无可用的统一面层密度帽。

新 active capture 上 a>k+alpha_+J，因此 U_+=k。这说明 capture 新增质量与新正 target 之间需要控制的准确比值为
\[
 {\mathcal B_+\rho_+^2\over k}
 \quad(k>0), \tag{JF14}
\]
并保其实际共同来源配重；k=0 时不得借此比值付款。原 strictsoft 下 k>0 并不提供统一正下界。不能把 K0 的真实 Hhat 尺度改成 current L，也不能把高 A 窄带直接当作低 K0 已排除。

有限 JF1 的 E 嵌套是明示条件。实际 current 面运行中，outer p_y 的跳、a/k 的连续或有限变化、terminal Z_g 删除和 high 交换都必须保留。nu 的绝对连续性可使固定物理面上的来源质量为零，却不自动消去来源壳流、good 阈值层或产生全路径 BV。因而本稿不把每个形式 target jump 赋予非零 alpha 跳；共同有限捕获变化仍由其真实来源积分决定。

## JF7　原预算回代与本轮边界

原共同来源/时间测度保留为
\[
 \mathbb E\sum_V\sum_j\int_{I_j}{dt\over t}
 \int_E dx\int\beta_V(dy)\int\Pi_{y,t}(dv)\Pi_{y,t}(du), \tag{JF15}
\]
其中原唯一 j 门、定义域、time/high/history 等留在 H 内。对 JF5/JF9/JF11 使用同一测度和共同尺度分割；仅在正放松之后，才可引用已证固定来源核包络。所有独立窗口分别计费，不能把不同窗的 q 或 alpha 储备合并重复使用。

例如共同 Bcap、固定 s,L 的合法核比较给 ∫F dx<=Bcap a_m；若用全 soft/current scale 包络，须支付 R198/R201 的
\[
 D_{all}=2\sqrt{2n}\,(1+2n\log2),
 \qquad\int\sup_{s,L}F\,dx\le D_{all}Bcap\,a_m. \tag{JF16}
\]
若帽随来源而变，Bcap a_m 留在实际 beta Pi² 来源积分内。JF16 不允许先移出 x-dependent R_c、门或重新归一后的来源；可正放松 R_c<=1，或在确已证明其统一上界的同一片上使用该上界。完整 j/time 代价 T_* 仍保留。实际 Bcap=B0/W_g 的 tiny-overlap 费用未因此支付。

因此本稿的新量化结论是：共同 capture 恢复以尖锐无量纲 R_c 计费，持续 target 的真实分母负面同时保留；仅增益路径的恢复因子有无事件数的对数账。它改进的是原同源净增量，而非另一份抽象正部或重新选择 alpha。

一般 FS14/JC23 仍需证明一个联合估计：在共同来源尺度路径上，实际恢复项、JF11 的新资格入口和 JF9 的真实几何交换，扣除实际分母下降及同源势能端项后，其正变差能以可用来源费/接收小费结算。最早未受控项是 JF12–14 的真实加权捕获入口与 recharge/geometry 的联合占用；既有静态 ∫aΨν<=2Hc 不能支付重复进入，JF16 也未压掉 inverse Wg。

若某个核级 sqrt(n) 估计作为 companion 直接配原 E_J<=nWnu/(2K)，仍可能只有 raw n^(3/4)；本稿不将其称为原一般根阶闭合。父/辅助本轮的全 s 两立方体 bilinear 面估计是另一已核几何工具，不能用其正上界替换 JF4 的负补偿下界。

## JF8　有限同源校准（不是 FULL 实例）

对 r∈{0,1/4,1/2,3/4,1}，取两来源质量均为 1、J 均为 1、Q=2。目标 v 取 a_v=2、k_v=1；另一来源取 k_z=2(1-r)/(1+r)、a_z=k_z+1。共同 Dq=1+2/(1+r)，E_-={v}、E_+={v,z}。由 U 而非自由指定 alpha 重算得
\[
 \alpha_-={1\over1+r},\quad\alpha_+={r\over1+r},\quad
 \rho_+^2-\rho_-^2={1\over4}{1-r\over1+r}. \tag{JF17}
\]
而 Σk<=Dq，JF2 在目标上取等。r=1 的第二来源 k=0 仅用于代数零端点，不声称 strictsoft 物理实现。可分别取 mathcalB_-=mathcalB_+=1，或 mathcalB_-=1、mathcalB_+=1/2，核验完整实际分母负项；新来源的入口 W 必须另列。H 路径 8,4,2,1 给 sum R_i=1，路径 8,4,8,4 则明确需要 recharge 账。这些例子仅校验共同来源有限代数，不认证原 FIRST、森林、current 核或 FULL 资格。
