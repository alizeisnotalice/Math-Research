# R205：共同来源两点的交叠面几何及全 soft 扩展

状态：辅助几何证明。本文证明全部维度、全部固定 homothetic 尺度比下的两立方体尖锐绝对相对面通量，并用原 mixed kernel 的正卷积表示把它推广至所有 s∈[0,1]。target 尺度不小于 outer 尺度时，得到真实 py 加权硬面核的维度无关价格。保留完整尺度归一化、真实 Bcap/J 权、共面有限跳、clamp、选择器与原来源账；没有宣称一般 raw 根阶闭合。

## OF1　固定几何、面及量纲

令n≥1、L>0、ℓ=γL，γ>0；outer中心y、target中心v，d=v−y、t_i=|d_i|/L。Cy为边长L的轴平行立方体，Cv为边长ℓ的同类立方体。两归一化uniform密度分别为L^−n 1Cy与ℓ^−n 1Cv。所有面首先用generic noncoincident配置的严格内部source迹；闭边界的最大迹只用于正上界，不把共同source/target跳自动解释成其中一个冻结迹。

一维overlap长度除以L为
\[
 q_\gamma(t)=\min\{a,(b_\gamma-t)_+\},\quad
 a=\min(1,\gamma),\quad b_\gamma=(1+\gamma)/2,
 \quad\delta=|1-\gamma|/2. \tag{OF1}
\]
其分段为：t≤δ时q=a，δ<t<bγ时q=bγ−t，t≥bγ时q=0。target两面落在outer区间的数为
\[
 m_\gamma(t)=1_{\{|t-\gamma/2|<1/2\}}
             +1_{\{t+\gamma/2<1/2\}}. \tag{OF2}
\]
闭迹上界把两个<改≤。γ>1、t<δ时target包含outer且m=0；γ<1、t<δ时target被包含且m=2；partial段m=1。不得把contained的两面当一面，也不能把γ>1的contained体积当有内部target面。

当L和ℓ同率缩放（γ固定）时，材料方向X=x−y相对target面的速度是d_i的法向分量。两uniform密度的绝对相对面通量为
\[
 \mathfrak F_{0,\gamma}(L;y,v)
 =L^{-n}\gamma^{-n}T_\gamma(\mathbf t),\quad
 T_\gamma=\sum_i t_i m_\gamma(t_i)\prod_{j\ne i}q_\gamma(t_j). \tag{OF3}
\]
推导：第i面的物理系数|d_i|=Lt_i，面积overlap为L^(n−1)Πq，两个密度为L^−nℓ^−n。另一常见functional只乘outer L^−n、未归一target，此时无量纲量是Tγ；不能与OF3混淆。n=1的空乘积为1。

## OF2　等大立方体：一份几何容量

γ=1的非退化交叠中，q_i=(1−t_i)+，每个0<t_i<1有且仅一个target面在outer内，因此
\[
 T_1=\sum_i(1-q_i)\prod_{j\ne i}q_j\le1. \tag{OF4}
\]
证明：将Π_i[q_i+(1−q_i)]=1按子集展开，OF4左侧恰是“只有一个缺失坐标”的非负项之和。无需把来源坐标当独立随机变量；这只是有限产品恒等式。若t_i>1，相关overlap为0且面不在outer，实际T仍被此表达式控制；t_i=1的闭最大迹对应q_i=0也包含在该正上界内。t_i=0虽两面可重合，速度系数为0。

因此同时两uniform密度下mathfrakF≤L^−n，而不是逐面n L^−n。此结论适用于任意固定来源对，不将输入f限为立方体。

## OF3　不等大：尖锐完整sup及退化

定义
\[
 C_{n,\gamma}=
 \begin{cases}
 \max\{n(\gamma-1)/2,(1+\gamma)/2\},&\gamma\ge1,\\
 \gamma^{n-1}\max\{n(1-\gamma),(1+\gamma)/2\},&0<\gamma\le1.
 \end{cases} \tag{OF5}
\]
**命题。** 全部n≥1、γ>0与位移下，Tγ≤Cn,γ；generic noncoincident配置的sup恰为该常数。闭迹最大计数同样服从该上界，但其特定共面值不是原完整finite jump的默认值。

证明γ≥1：此时a=1、δ=(γ−1)/2。partial段t_i=1+δ−q_i，m_i=1；contained段q_i=1且实际贡献0≤δ。outside段q_i=0、actual面贡献≤1+δ。因此
\[
 T_\gamma\le\sum_i(1+\delta-q_i)\prod_{j\ne i}q_j.
\]
右侧是各q_i∈[0,1]上的多仿射函数，最大值在顶点：全q=1时为nδ；恰一个q=0时为1+δ；至少两个q=0时为0。故得OF5第一支。使所有partial q_i↑1可逼近nδ；使一个partial q_i↓0、其余↑1可逼近1+δ。γ=1时第二族给sup1，第一族为0。

证明γ≤1：a=γ。contained段m_i=2且2t_i≤1−γ；partial段m_i=1且t_i=bγ−q_i。连接q=0时系数bγ与q=γ时系数1−γ的仿射majorant为
\[
 A_\gamma(q)=b_\gamma+{1-3\gamma\over2\gamma}q.
\]
partial段Aγ(q)−(bγ−q)=q(1−γ)/(2γ)≥0；contained及outside端点也成立。因此
\[
 T_\gamma\le\sum_i A_\gamma(q_i)\prod_{j\ne i}q_j.
\]
多仿射顶点值为全q=γ时n(1−γ)γ^(n−1)、恰一个q=0时bγ γ^(n−1)、其余为0。contained t_i↑δ从内可逼近第一族，单个partial q_i↓0且其余contained接近δ可逼近第二族。γ=1由前支一致。n=1时阈值γ=1/3正是两族交换主导的位置。

几何常数满足
\[
 C_{n,\gamma}\le\gamma^n\quad(\gamma\ge1),\qquad
 C_{n,\gamma}\le1\quad(0<\gamma\le1). \tag{OF6}
\]
第一式：γ^n≥1+n(γ−1)，分别控制n(γ−1)/2及(1+γ)/2。第二式：bγ γ^(n−1)≤1；n(1−γ)γ^(n−1)的最大值不超过1（n1直接；n≥2在γ=(n−1)/n取极大）。注意γ≤1时OF3仍含γ^−n，不能用Cn,γ≤1删掉target归一化。原target尺度通常ℓ≥L，正好使用第一支。

## OF4　原混合核的精确正表示

原一维核为
\[
 f_s=(1-s)h+s\phi=h*\kappa_s,\quad
 \kappa_s=(1-s)\delta_0+s\,w(r)dr,\quad0\le s\le1, \tag{OF7}
\]
其中h=1[-1/2,1/2]、φ=h*w、w(r)=∫0¹ exp(−|r|/a)da。κs为概率。其实际一阶偏移矩为
\[
 \int|r|\kappa_s(dr)=s\int|r|w(r)dr=2s/3. \tag{OF8}
\]
证明：w=∫0¹2a Laplace_a da，Laplace_a的E|r|=a，所以∫2a² da=2/3。该概率表示只表示已知物理receiver产品核，不假设原β/ν的坐标独立。

物理φ偶递减：φ′(r)=w(r+1/2)−w(r−1/2)≤0在r≥0，因为w偶递减。置
\[
 c_*=1-\phi(0)=2\int_0^1a e^{-1/(2a)}da\in(0,1),
 \quad m_s=1-c_*s.
\]
于是全实轴上
\[
 f_s(r)\le m_s,\qquad
 c_*\ge2e^{-1}\int_{1/2}^1a da={3\over4e}. \tag{OF9}
\]
φ0公式来自φ0=2∫0¹a(1−e^−1/(2a))da。outside core的sφ≤(1−s)+sφ0也服从同界。

## OF5　全 s 的真实 py 加权硬面公式

固定s、L、ℓ=γL、y、v，记
\[
 P_{s,L}(x-y)=L^{-n}\prod_i f_s((x_i-y_i)/L).
\]
target第i坐标的真正hard jump振幅为
\[
 \delta_iP_{s,\ell}(x-v)
 =(1-s)\ell^{-n}\prod_{j\ne i}f_s((x_j-v_j)/\ell),
 \quad x_i=v_i\pm\ell/2. \tag{OF10}
\]
不将soft部分的连续导数算成另一hard jump。定义正面核
\[
 \mathfrak F_{s,\gamma}(L;y,v)
 =\sum_{i,\varepsilon=\pm1}\int_{x_i=v_i+\varepsilon\ell/2}
 |d_i|P_{s,L}(x-y)\delta_iP_{s,\ell}(x-v)dH^{n-1}. \tag{OF11}
\]
source硬界的点值采用可控的正最大迹；若要当原共同面交通，仍须OF9节的实际有限跳资格。

一维tensorizable精确式是（ti可用有符号d_i/L，核偶性使结果不变）
\[
 O_{s,\gamma}(t)=\int_\mathbb R f_s(r)f_s((r-t)/\gamma)dr,
\]
\[
 \boxed{\mathfrak F_{s,\gamma}
 =L^{-n}(1-s)\gamma^{-n}\sum_i|t_i|
 [f_s(t_i-\gamma/2)+f_s(t_i+\gamma/2)]
 \prod_{j\ne i}O_{s,\gamma}(t_j).} \tag{OF12}
\]
O没有target的γ^−1，故γ^−n在公式外完整保留。s0恢复OF3；s1真实jump为0。n1空乘积为1，不写含糊0^0。

## OF6　所有soft度的维度无关硬面核价

**定理。** 令a=min(1,γ)，则
\[
 \boxed{\mathfrak F_{s,\gamma}
 \le L^{-n}\gamma^{-n}\left[
 C_{n,\gamma}(1-s^n)+{4\over3}n s(1-s)(m_sa)^{n-1}\right].} \tag{OF13}
\]
特别target尺度不小于outer尺度（γ≥1）时，
\[
 \boxed{\mathfrak F_{s,\gamma}
 \le\left(1+{4\over3c_*}\right)L^{-n}
 \le(1+16e/9)L^{-n},\qquad0\le s\le1.} \tag{OF14}
\]
边界的更精确值仍由OF13保留，s1为零。它是一般来源对的真实mixed物理核面价，不是将原输入限为s0。

证明：仅为表示kernel，令Ai独立服从κs；target第i坐标标签Ii取hard的概率1−s，hard时Bi=0，soft时Bi具有密度w。不同坐标及source/target这些辅助kernel变量独立。正Tonelli把OF11精确写成这些random shifts下，outer cube中心y+LA、target cube中心v+ℓB的uniform面核之期望，但第i面只在Ii=hard时计入。这时Bi=0，target面恰是原vi±ℓ/2。

设两个shifted中心的无量纲差为t'_i=d_i/L+γBi−Ai。当Ii=hard，
\[
 |d_i|/L\le|t'_i|+|A_i|.
\]
第一份|t'|是selected target faces的purecube通量，逐样本≤Cn,γ。没有hard标签时它为零，因此其期望≤Cn,γ P(至少一hard)=Cn,γ(1−s^n)。此处没有按每个面各领Cn,γ。

第二份|Ai|的每个坐标至多两面；其余overlap长度qγ(t'_j)≤a。关键是不能到此就丢掉mixed平均：对j≠i，独立kernel坐标及Tonelli给
\[
 \mathbb E q_\gamma(d_j/L+\gamma B_j-A_j)
 =\int f_s(r)f_s((r-d_j/L)/\gamma)dr
 \le m_s\min(1,\gamma)=m_sa. \tag{OF15}
\]
两边分别用f_s≤ms及两个积分1、γ给此min界。其余坐标独立于Ai和Ii，所以
\[
 \mathbb E\left[1_{\{I_i=hard\}}|A_i|\prod_{j\ne i}q_\gamma(t'_j)\right]
 \le(1-s){2s\over3}(m_sa)^{n-1}.
\]
乘两面再对i求和，恰为4n s(1−s)(msa)^(n−1)/3。加第一项并恢复L^−nγ^−n即得OF13。

γ≥1时a1、Cn,γ/γ^n≤1。令x=c*s∈[0,1]，则
\[
 n s(1-s)m_s^{n-1}\le c_*^{-1}n x(1-x)^{n-1}\le c_*^{-1}.
\]
最后不等式可由OF4的同参数r_i=1−x得出；n1为x≤1。故得OF14。没有使用原来源独立性、概率密度帽或ν≤β。正Tonelli对任意相关固定来源pair联合测度依旧可用，但其实际总质量/权重必须另计。

## OF7　clamp与非同比尺度速度

若ℓ=ℓ(L)并非γL，记dotℓ=dℓ/dlogL，κ=dotℓ/ℓ。target第i面的真实相对速度为
\[
 d_i+\varepsilon(\ell-\dot\ell)/2,\qquad\varepsilon=\pm1. \tag{OF16}
\]
这是X_i−ε dotℓ/2，X_i=d_i+εℓ/2。故OF11只支付其中di部分；额外绝对面价至多
\[
 \boxed{L^{-n}n(1-s)|1-\kappa|\,
 {m_s^n a^{n-1}\over\gamma^{n-1}}.} \tag{OF17}
\]
证明：三角不等式给额外速度|ℓ−dotℓ|/2；OF12的每个source面因子≤ms，其余overlap≤msa，两面求和后恢复归一化即为OF17。不把dotℓ/ℓ误设1。

对ℓ=min(b,γ0L)，未clamp处κ1，clamp处κ0；后一段还保OF17。若γ0固定且L变化，clamp区间log长度≤logγ0，但L^−n和原权重仍在积分内，不能因此免费提出。hard密度的完整transport还含n(1−κ)bulk项，mixed核另有连续变化；本节只记精确面接口，不宣称它们已相消。s小的clamp余价可能为n量级，未被OF14覆盖。

## OF8　固定参数和来源聚合的实际范围

OF13–14逐固定s,L,ℓ,y,v成立，位移无矩假设。可在固定窗口的共同尺度路径上逐slice使用，再积分实际dlogL；不同窗口保各自尺度及路径长度。receiver选择L(x)、s(x)时，不可将固定L的全空间面积价无费取sup。若具体选择器已有正包络价格，只能明示带该费使用；本稿没有给新的free selector。

在实际β(dy)Π_y(dv)（或包含otherΠu的joint）上可沿正Tonelli应用，但得到的仍是该真实联合测度与L^−n系数的积分。原common-parent只给线性来源账，不自动将pair质量或此weighted kernel价线性化。ν、β无次序假设；所有j/time/窗口、source reuse与真实dx保留。几何维度无关不代表已付原raw或配n能量即得根阶。

## OF9　截帽/分母有限跳：可合法接回的正项

在单个target进入面，先限J、F、Bcap及other gate有真实共同冻结迹，分母S= p_v+p_v+ +J从S-跳到S+=S-+δp，δp≥0。保持原mathcalB=FJ²/S²；其精确下降为
\[
 \mathcal B_- -\mathcal B_+
 =FJ^2{\delta p\over S_-^3}
 {2+\delta p/S_-\over(1+\delta p/S_-)^2}. \tag{OF18}
\]
括号在[0,2]，且F=min(py²,Bcap²J²)/J≤Bcap py、S-≥J，因此
\[
 \boxed{0\le\mathcal B_- -\mathcal B_+
 \le2{B_{cap}\over J}\,p_y\,\delta p.} \tag{OF19}
\]
这保留真实Bcap/J，不用J的虚假uniform下界。当前p_v与p_v+同层一起进入时，以总δp一次使用OF18，而不重复领取冻结分母下降。

因而这份denominator下降的正relative face交通，在该实际冻结迹资格下被
\[
 2\sum_{i,\varepsilon}\int {B_{cap}\over J}\,G_{\rm actual}
 p_y|d_i|\delta_i p_v\,dH^{n-1} \tag{OF20}
\]
控制。若确有真实系数(Bcap/J)Gactual≤M，则OF13–14给≤2M mathfrakFs；否则该权必须留在面内，不能当常数。原目标常含Bcap=B0/Wg，小终端overlap费用没有被几何消去。不同target尺度分别保归一化，clamp还加OF17。

若outer py也同刻跳、帽变化或gate/capture改变，冻结F的OF18不能独立代表整个事件。固定J时有完整代数
\[
 \mathcal B_+-\mathcal B_-=z_+^2(F_+-F_-)+F_-(z_+^2-z_-^2), \tag{OF21}
\]
其它J/来源变化另保实际差。ρ、sameα、Ψ的同步变化再用R204 whole finiteproduct与原同一状态；不将OF19的正上界当成净negative信用。原gate只有measurable时不自动有BV/迹；本节仅在实际状态或合法面迹内使用，不补造共同trace。

## OF10　证据接口与结论

数值作者可用有理n1临界γ1/3、γ1附近、n2/3小规模partial/contained切点邻域，以及高维少量两类near-extremizer检验OF5。严格内面计数与闭面上界、Tγ与两密度L^−nγ^−nTγ必须分开。纯cube有限证据不认证mixed物理/原cap或FULL。本文证明由有限几何顶点与正kernel表示给出，不依赖拟合或数值。

新可用工具是OF13–14：所有soft参数、一般固定来源对、真实py加权的homothetic target硬面核，拥有维度无关的上界。其余真实分母/帽权、sameα/capture/gate共同跳、clamp及continuous项、receiver selector和全source账尚未支付。主联合current/capture路线应使用OF18–21保同面全部变化，而非以纯cube或fixedslice结论代替原一般覆盖。至此停止，送全文审。
