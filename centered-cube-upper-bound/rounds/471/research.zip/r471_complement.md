# R471：真实质量层与 Poisson 极值压缩

本稿保留实际兼容父中心容量，给出归一的样本重排及大质量候选父的势占用衰减。它们尚未支付同一原 \(P\) 的完整质量；尤其不把候选父势的正部分当作原费用的正子流。

沿用 \(m_A=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(a\le R_A\le b\)、\(\mu=f\,dx\)、\(\sigma=q_A\,dA\)，\(X=\sigma(E)<\infty\)。新增 Poisson 强度记为 \(\tau\)，与质量带上界 \(\lambda\) 不混用。

## 1. 质量层先不放松：所有原子及端点

对有限样本 \(Y\) 设
\[
 C_Y(t)=\int_E c_A(Y)1_{\{m_A\le t\}}dA,\qquad
 F_Y(t)=\int_E q_Ac_A(Y)1_{\{m_A\le t\}}dA.
\]
令 \(m_0=qa^n,m_1=\lambda b^n\)。则实际
\[
 K_k(Y)=m_1^{-k}F_Y(m_1)
       +k\int_{m_0}^{m_1}F_Y(t)t^{-k-1}dt.                 \tag{1}
\]
这是右连续 CDF 的 Stieltjes 分部积分；\(m_0,m_1\) 的质量原子均已包含。
固定质量场 \(m_0=m_1\) 时只剩首项，不能删掉它。

若 \(H(Y)\) 为坐标盒 hull、\(M(Y)=\mu(H(Y))\)，则 \(C_Y(t)=0\) 当 \(t<M(Y)\)，并且
\[
 F_Y(t)\le\lambda C_Y(t)
 \le\lambda\prod_{\ell=1}^n
 \left(\min\{b,(t/q)^{1/n}\}-\operatorname{span}_{\ell}Y\right)_+.
                                                               \tag{2}
\]
父中心属于这个实际包含关系给出的盒；(2) 不推断来源密度。
下面重排可直接用于 (1) 中的真实 \(F_Y\)，不需要先使用 (2)。

## 2. 固定旧来源及全部接受权的极值积分

固定原完整记录 \(\xi\)，特别固定 \(A,y,z\) 及其历史。只附加 \(r\) 个独立 \(\pi_A\) 来源。对 \(\mu^r\)-a.e. 新样本，各坐标极值无新样本间的平局，因为 \(\mu\) 对 Lebesgue 绝对连续。

称新样本为 essential，当它是某坐标的唯一极值且严格越过旧 \(y,z\) 在该方向的极值。全部 essential 新样本唯一确定，有 \(j\le\min(r,2n)\) 个。记 \(\mathcal E_j(y,z)\) 为有序 \(j\)-元组中每个点均 essential 的集合，\(j=0\) 约定为空元组、\(\mu^0\) 质量为1、空捕获积为1，指数为0时取 \(0^0=1\)。令 \(H=H(y,z,Z)\)、\(M=\mu(H)\)。

对任意非负可测 hull 函数 \(\Psi(\xi,H)\)，精确地
\[
 \begin{split}
 \mathbb E_{\pi_A^{\,r}}\Psi(\xi,H(y,z,Y_r))
 =\sum_{j=0}^{\min(r,2n)}\binom rj
 \int_{\mathcal E_j(y,z)}
 \Psi(\xi,H)\,\frac{c_A(Z)}{m_A^j}
       \left(\frac{M}{m_A}\right)^{r-j}d\mu^j(Z).
                                                               \tag{3}
 \end{split}
\]
证明：按实际 essential 索引集分割。余下 \(r-j\) 个样本必须位于同一 hull 内；因 hull 已在 \(Q_A\) 内，其每份积分恰为 \(M/m_A\)。坐标边界为 \(\mu\)-零集，不产生重复归属。选择索引集贡献 \(\binom rj\)，旧 \(y,z\) 从未被积分掉。

因此原接受权若依赖旧来源、父、stage、path，仍保存在 \(\xi\)；(3) 是在每个原记录上的等式。若改用一个随新样本内部排列变化的权，不能未经条件平均仍称其为 hull 函数。

## 3. 归一 Poisson 混合：实际 \(m_A\) 下的补偿

令 \(N\sim\operatorname{Pois}(\tau)\)，\(\tau>0\)，给定 \(\xi\) 后独立生成 \(N\) 个 \(\pi_A\) 来源。所有混合权之和为1。由 Tonelli 及
\[
 \sum_{r=j}^{\infty}e^{-\tau}\frac{\tau^r}{r!}
 \binom rj x^{r-j}
 =\frac{\tau^j}{j!}e^{-\tau(1-x)}
 \quad(0\le x\le1),                                      \tag{4}
\]
(3) 化为真正有限的极值和
\[
\boxed{
 \mathbb E\Psi(\xi,H_N)
 =\sum_{j=0}^{2n}\frac{\tau^j}{j!}
 \int_{\mathcal E_j(y,z)}
 \Psi(\xi,H)\frac{c_A(Z)}{m_A^j}
       e^{-\tau(1-M/m_A)}d\mu^j(Z).
}                                                        \tag{5}
\]
取 \(\Psi=1\) 时，右侧对每个 \(\xi\) 均等于1；故乘原 \(dP(\xi)\) 后精确保全原质量和全部旧记录。没有以几何上确界或 \(M\) 重新归一化，也没有把辅助来源称作有原历史的来源。

这是实际的补偿：无限新增样本数变成至多 \(2n\) 个 essential 点的积分，同时保留真实外部来源质量比例 \(1-M/m_A\)。但不能丢掉指数、逐项将 \(m_A\) 换成 \(M\)，再声称 \(\tau^j/j!\) 不收费。接近 \(M=m_A\) 时指数接近1，极值来源积分的重叠仍须与父中心共同结算。

当 \(x=0,1\) 时 (4) 均成立；尤其 \(x=1\) 没有发散。
\(\tau=0\) 可直接定义只取 \(N=0\)。若必须只保有限 \(N\le N_0\)，真实丢失质量至多
\[
 P(N>N_0)|P|\le\frac{\tau}{N_0+1}|P|
 \le\frac{S\tau}{N_0+1}X,                               \tag{6}
\]
且随 \(N_0\to\infty\) 消失。不能把截断混合重新归一化而省略这笔费用。

## 4. 质量窗失败费与实际势的上行衰减

R470 保固定旧 \(y,z\) 的缺失质量界及
\[
 \mathbb E\frac1{N+1}=\frac{1-e^{-\tau}}{\tau}
\]
给
\[
 |P\{\mu(H_N)<(1-\delta)m_A\}|
 \le\frac{2n(1-e^{-\tau})}{\delta\tau}|P|
 \le\frac{2Sn}{\delta\tau}X.                            \tag{7}
\]
它是扩充上的真实正分割。要将该失败费降到 \(\eta X\)，可取
\(\tau\ge2Sn/(\delta\eta)\)；不是把固定旧两源误算为全新 iid 样本。

还有与 (5) 相容的真实势公式。令
\[
 \mathcal F_{r+2}(A,y,z,Y_r)=m_A^{r+1}K_{r+2}(y,z,Y_r),
 \qquad p_{BA}=\mu(Q_A\cap Q_B)/m_B.
\]
同父采样和质量消去给
\[
 \mathbb E\mathcal F_{N+2}
 =m_A\int_E\frac{\sigma(dB)c_B(y)c_B(z)}{m_B^2}
                   e^{-\tau(1-p_{BA})}.                 \tag{8}
\]
(8) 中 \(B\) 不带原历史。对任意 \(c>1\)，其 \(m_B\ge c m_A\) 部分积分于原 \(P\) 后至多
\[
 e^{-\tau(1-1/c)}\int\mathcal F_2\,dP
 \le S A_n e^{-\tau(1-1/c)}X.                            \tag{9}
\]
故选择
\(\tau\ge\log_+(S A_n/\eta)/(1-1/c)\) 可将这部分**势占用**付为 \(\eta X\)。
R470 的初值界用于最后一步；(9) 不支付原 \(P\) 本身，也不将整个初始势免费消掉。
(7) 的质量窗通常要求更大的 \(\tau\)，两项条件须同时满足。

本次可用桥是 (5)：实际中心质量层 (1) 与 essential 来源积分可按同一正测度交换，全部父分母及接受权保留，混合不增原费用。唯一尚缺的整体步骤是对 (5) 的同一父中心/essential 来源积分取得共享 \(W\) 结算，尤其 \(M/m_A\) 接近1且兼容父质量可比时。极值数上限 \(2n\)、(7) 的小失败费和 (9) 的上行衰减均不提供这个结算；因此原全余根阶目标未完成。

## 5. 实际本机精确检查

下列代码已用指定 Python/Fraction 实际运行：三阶段分别 8、56、48 项，共 112 项精确断言通过。它核：
真实 CDF 下/上质量原子的层式；Poisson 重排逐系数恒等式；固定旧区间时新增均匀来源的 \(j=0,1,2\) 极值权总和。最后一项只是连续一维条件来源积分的解析核验，不是原高维历史模拟。一般结论由以上证明给出。

~~~python
from fractions import Fraction as F
from math import factorial,comb
checks=0
# 1. Actual right-CDF atoms, including both endpoints.
masses=[F(1),F(2),F(4)]
weights=[F(2,3),F(1,2),F(3,4)]
for k in [1,2,3,8]:
    direct=sum(w*m**(-k) for m,w in zip(masses,weights))
    layer=sum(weights)*masses[-1]**(-k)
    cum=F(0)
    for j in range(len(masses)-1):
        cum+=weights[j]
        l,u=masses[j:j+2]
        layer+=cum*(l**(-k)-u**(-k))
    assert direct==layer
    fixed=sum(weights)*F(2)**(-k)
    assert fixed==sum(w*F(2)**(-k) for w in weights)
    checks+=2
print("phase 1 PASS",8)
# 2. Exact coefficient identity behind the infinite positive series.
local=0
for j in range(7):
    for r in range(j,11):
        assert F(comb(r,j),factorial(r))==F(1,factorial(j)*factorial(r-j))
        checks+=1;local+=1
print("phase 2 PASS",local)
# 3. Continuous uniform parent source, fixed old [p,q].
# j terms are integrals over genuine ordered extreme points.
local=0
for p,q in [(F(1,4),F(3,4)),(F(1,3),F(2,3)),
            (F(0),F(1)),(F(0),F(1,2))]:
    d=q-p
    for r in [0,1,2,4,16]:
        a0=d**r
        if r==0:
            a1=a2=F(0)
        else:
            a1=q**r+(1-p)**r-2*d**r
            a2=1-(1-p)**r-q**r+d**r
        assert a0>=0 and a1>=0 and a2>=0
        assert a0+a1+a2==1
        if r<2:
            assert a2==0
            checks+=1;local+=1
        checks+=2;local+=2
print("phase 3 PASS",local)
print("total PASS",checks,"counted Fraction assertions; no native-history claim")
~~~
