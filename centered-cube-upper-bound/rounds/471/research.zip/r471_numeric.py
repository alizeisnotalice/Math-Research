from fractions import Fraction as F
from pathlib import Path
import json,sys,platform,time
import sympy as s
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
start=time.perf_counter();checks=0;ctx.prec=224
B,t,h,d,ell=s.symbols('B t h d ell',positive=True)

def ck(z):
 global checks
 assert z
 checks+=1

def canon(expr):
 expr=s.expand_log(s.expand(expr),force=True)
 repl={}
 for atom in expr.atoms(s.log):
  arg=atom.args[0]
  if arg.is_Rational and arg>0:
   out=0
   for prime,power in s.factorint(int(arg.p)).items():out+=power*s.log(prime)
   for prime,power in s.factorint(int(arg.q)).items():out-=power*s.log(prime)
   repl[atom]=out
 expr=s.expand(expr.xreplace(repl))
 return s.cancel(expr) if not expr.has(s.log) else expr

def equal(a,b):ck(canon(a-b)==0)
def val(expr):
 out=arb(0)
 for term in s.Add.make_args(canon(expr)):
  co,re=term.as_coeff_Mul();c=arb(int(co.p))/arb(int(co.q))
  if re==1:out+=c
  else:
   ck(re.func==s.log)
   x=s.Rational(re.args[0]);out+=c*(arb(int(x.p))/arb(int(x.q))).log()
 return out

def nonnegative(expr):
 z=canon(expr)
 if z==0:ck(True)
 else:ck(val(z)>0)

def integ(expr,var,lo,hi):
 expr=s.expand_log(s.expand(expr),force=True)
 if not expr.has(s.log):expr=s.apart(s.cancel(expr),var)
 anti=0
 for term in s.Add.make_args(s.expand(expr)):
  anti+=s.integrate(term,var)
 return canon(anti.subs(var,hi)-anti.subs(var,lo))

def Cenv(lo,hi,tau):return max(F(0),min(F(1),lo+tau/2)-max(F(0),hi-tau/2))
def Cactual(hi,tau):
 b0=max(F(0),(2*hi-1)/3)
 return max(F(0),min(F(1),tau-1)-b0)

def primitive(poly,p,l,u):
 result=0
 for (power,),coef in s.Poly(s.expand(poly),t).terms():
  e=power-p
  result+=coef*s.log(u/l) if e==-1 else coef*(u**(e+1)-l**(e+1))/(e+1)
 return result
pointcases=[]
for lo,hi in ((F(0),F(1)),(F(1,4),F(3,4)),(F(1,2),F(1,2)),(F(1,10),F(3,5))):
 b0=max(F(0),(2*hi-1)/3);span=hi-lo
 for tau in (F(1),F(5,4),F(3,2),F(7,4),F(2)):
  ck(0<=Cactual(hi,tau)<=Cenv(lo,hi,tau)<=tau-span)
 for k in (2,4,8):
  bb=s.Rational(b0.numerator,b0.denominator)
  actual=integ((1+B)**(-k),B,bb,1)
  layer=2**(-s.Integer(k))*(1-bb)+k*primitive(t-1-bb,k+1,1+bb,s.Integer(2))
  equal(actual,layer)
  ends=sorted({F(1),F(2),*[z for z in (2*hi,2*(1-lo)) if F(1)<z<F(2)]})
  env=2**(-s.Integer(k))*s.Rational(Cenv(lo,hi,F(2)))
  for a,b in zip(ends,ends[1:]):
   nodes=[a+(b-a)*F(1,3),a+(b-a)*F(2,3)]
   pol=s.interpolate([(s.Rational(v.numerator,v.denominator),s.Rational(Cenv(lo,hi,v))) for v in nodes],t)
   mid=(a+b)/2;equal(pol.subs(t,s.Rational(mid)),s.Rational(Cenv(lo,hi,mid)))
   env+=k*primitive(pol,k+1,s.Rational(a),s.Rational(b))
  spanenv=(k-2**(1-s.Integer(k)))/(k-1)-s.Rational(span)
  nonnegative(env-actual);nonnegative(spanenv-env)
  upper=2*span-1
  good=integ((1+B)**(-k),B,bb,s.Rational(upper)) if upper>b0 else s.Integer(0)
  pointcases.append(dict(minY=lo,maxY=hi,k=k,b0=b0,good_upper_B=upper,K_actual=str(canon(actual)),K_actual_layer=str(canon(layer)),
   C_env_layer_upper=str(canon(env)),span_upper=str(canon(spanenv)),K_good=str(canon(good))))

c=s.Rational(1,2)
def source_measure(length,cut,k):return length**k-k*length*cut**(k-1)+(k-1)*cut**k
rows=[]
for k in (2,4,8):
 print('integrating k',k,flush=True)
 g=source_measure(ell,c,k)
 # Fixed side1, E=[-1/2,3/2]: exact common center length 1-range.
 fixed=integ(k*(k-1)*d**(k-2)*(1-d)**2,d,c,1)
 fixed_B=2*integ(g,ell,c,1);equal(fixed,fixed_B)
 # Variable R_B=1+B,E=[0,1], true Cactual layer by selected radius.
 ellsmall=(3*B+1)/2
 actual_B=integ(source_measure(ellsmall,c,k)/(1+B)**k,B,0,s.Rational(1,3))+integ(source_measure(1,c,k)/(1+B)**k,B,s.Rational(1,3),1)
 Kh=((2*(h+1)/3)**(1-k)-2**(1-s.Integer(k)))/(k-1)
 actual_minmax=k*integ((h**(k-1)-c**(k-1))*Kh,h,c,1);equal(actual_B,actual_minmax)
 # Good = R_B<=2 range, with exact B upper 2d-1 and lower b0(h).
 variable_cut=(1+B)/2
 good_B=integ(source_measure(ellsmall,variable_cut,k)/(1+B)**k,B,0,s.Rational(1,3))+integ(source_measure(1,variable_cut,k)/(1+B)**k,B,s.Rational(1,3),1)
 Khgood=((2*(h+1)/3)**(1-k)-(2*d)**(1-k))/(k-1)
 good_lower=integ(Khgood,h,d,3*d-1)
 good_upper=integ(Khgood,h,d,1)
 good_minmax=k*(k-1)*(integ(d**(k-2)*good_lower,d,c,s.Rational(2,3))+integ(d**(k-2)*good_upper,d,s.Rational(2,3),1))
 equal(good_B,good_minmax)
 # C_env(t): fixed side t compatibility with E=[0,1], not actual selector Cactual.
 G=(t-1)*source_measure(1,c,k)+2*integ(g,ell,t/2,1)
 Cenv_layer=2**(-s.Integer(k))*G.subs(t,2)+k*primitive(G,k+1,s.Integer(1),s.Integer(2))
 spanK=(k-2**(1-s.Integer(k)))/(k-1)-d
 span=integ(k*(k-1)*d**(k-2)*(1-d)*spanK,d,c,1)
 span_goodK=k/s.Integer(k-1)-d-(2*d)**(1-k)/(k-1)
 span_good=integ(k*(k-1)*d**(k-2)*(1-d)*span_goodK,d,c,1)
 old=2*k*(k-1)*(s.log(2)-c)
 for expr in (fixed,actual_B,good_B,Cenv_layer,span,span_good,old):nonnegative(expr)
 for diff in (Cenv_layer-actual_B,span-Cenv_layer,actual_B-good_B,span_good-good_B,old-span_good,old-fixed):nonnegative(diff)
 # Whole global f source identity remains distinct from the diagnostic subwindow.
 equal(integ((1+B)**(-k)*(1+B)**k,B,0,1),1)
 equal(integ(s.Integer(1),B,-s.Rational(1,2),s.Rational(3,2)),2)
 rows.append(dict(k=k,source_window='[0,1]^k, range in [1/2,1]',fixed_actual=str(canon(fixed)),fixed_actual_display=str(val(fixed)),
  variable_actual=str(canon(actual_B)),variable_actual_display=str(val(actual_B)),variable_good=str(canon(good_B)),variable_good_display=str(val(good_B)),
  C_env_layer_upper=str(canon(Cenv_layer)),C_env_layer_display=str(val(Cenv_layer)),span_upper=str(canon(span)),span_upper_display=str(val(span)),
  good_span_upper=str(canon(span_good)),old_good_mass_cap_integral=str(canon(old)),old_cap_display=str(val(old)),
  old_over_variable_good_display=str(val(old)/val(good_B)),all_source_integral_fixed=2,all_source_integral_variable=1))
# Analytic no-growth identity for this local uniform source-window span envelope.
kk=s.Symbol('kk',integer=True,positive=True)
ck(s.cancel(kk*(kk-1)*(1/(kk-1)-1/kk)-1)==0)
ck(s.cancel(kk*(kk-1)*(1/kk-1/(kk+1))-(kk-1)/(kk+1))==0)
untruncated=(kk-2**(1-kk))/(kk-1)-(kk-1)/(kk+1)
ck(s.cancel(untruncated-(2/(kk+1)+(1-2**(1-kk))/(kk-1)))==0)

# True cube/support checks, not arbitrary incidence.
ck(F(-1)>F(-4) and F(2)<F(4));ck(1<=F(1)+F(0)<=2 and 1<=F(1)+F(1)<=2)
out=dict(scope='Exact continuous uniform-f same-selector K_k layer/hull diagnostics on a source subwindow; not global accepted flow/history/root certificate',
 executable=sys.executable,python=platform.python_version(),sympy=s.__version__,arb_precision_bits=ctx.prec,checks=checks,
 geometry=dict(f='1 on [-4,4]',W=8,fixed=dict(E='[-1/2,3/2]',R=1,q=1,X=2),variable=dict(E='[0,1]',R='1+B',q=1,X=1,a=1,b=2),
 source_diagnostic='Y in [0,1]^k, hull range d in [1/2,1]',good_gate='R_B<=2d; delta=1/2',
 C_actual='(min(1,t-1)-b0)_+, b0=max(0,(2maxY-1)/3)',
 C_env='|[0,1] intersection [maxY-t/2,minY+t/2]|, compatibility envelope with hypothetical fixed t, not true selector Cactual'),
 pointwise_layer_certificates=pointcases,integrals=rows,
 identities=dict(actual_layer='K=b^-k Cactual(b)+k int_a^b t^-k-1 Cactual(t)dt',
 actual_good='B in [b0, min(1,2d-1)], empty if upper<=b0; minmax integration splits d=2/3',
 source_order='B-first source intersection integration equals exact source min/max integration',
 old_cap='2d^(1-k) integrated gives 2k(k-1)(log2-1/2), only asserted as good-mass-window bound',
 untruncated_local_span='Integral over all [0,1]^k of span envelope = 2/(k+1)+(1-2^(1-k))/(k-1); diagnostic range subwindow integral is smaller',
 all_source='int full mu^k K_k =X by full matching; this is separate from diagnostic source-window integrals'),
 compute_index=dict(status='complete',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r471_numeric.py',
 arithmetic='SymPy exact continuous interval/minmax integration and layer identities, Arb224 bound signs; no incidence discretization or quadrature',seconds=time.perf_counter()-start))
(ROOT/'r471_numeric.json').write_text(json.dumps(out,default=str,indent=2)+'\n')
print(sys.executable,'Python',platform.python_version(),'SymPy',s.__version__)
for row in rows:print('k',row['k'],'fixed',row['fixed_actual_display'],'variable',row['variable_actual_display'],'good',row['variable_good_display'],'Cenv',row['C_env_layer_display'],'span',row['span_upper_display'],'old',row['old_cap_display'])
print('PASS',checks,'exact/interval assertions; 2 actual continuous fields x k2/4/8; 12 pointwise layer certificates')
