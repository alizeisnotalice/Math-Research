# R471：真实共同中心体积与inverse-hull粗价的连续对照

在本次均匀source诊断中，保留共同中心体积后没有旧inverse-hull粗价的k²增长；实际可变side积分及span上界都远小于旧质量cap。这个局部结论不支付原accepted流的中心拥挤/历史权，也不是任意f、高维的一般根价。

## 两个真实连续场与诊断范围

f=1_{[-4,4]}，W=8。固定场E=[−1/2,3/2]、R_B=1、q=1、X=2；可变场E=[0,1]、R_B=1+B∈[1,2]、q=1、X=1。所有实际cube完全在f支撑内，完整质量m_B=R_B，真实Lebesgue中心，无incidence离散化。

只在诊断来源子窗Y∈[0,1]^k、d=range(Y)∈[1/2,1]上作比较，k=2,4,8。它不是全部原来源/原P。原good门取δ=1/2，即m_B≤d/(1−δ)=2d；旧cap只与good量比较，不授予全部父。

K_k(Y)=∫_E R_B^-k c_B(Y)dB。固定场K=1−d。可变场记u=minY、v=maxY，b0=max(0,(2v−1)/3)，则

K_k=∫_{b0}^1(1+B)^-k dB。

其实际layer累计中心量是

Cactual_Y(t)=|{B∈E:R_B≤t,c_B(Y)}|=(min(1,t−1)−b0)_+。

固定边长t的兼容中心包络另记

Cenv_Y(t)=|[0,1]∩[v−t/2,u+t/2]|。

Cenv不是实际selector下的Cactual。逐层Cactual≤Cenv≤(t−d)_+。核actual layer恒等式

K=2^-k Cactual(2)+k∫_1^2t^-k−1 Cactual(t)dt，

并比较相同layer式用Cenv所得上界及全空间span包络E_k。

## 积分顺序、边界与good质量门

可变场Q_B∩[0,1]的长度ℓ_B在B≤1/3时为(3B+1)/2，之后为1。一个长ℓ区间中range≥c的k来源体积为

g_k(ℓ,c)=ℓ^k−kℓc^(k−1)+(k−1)c^k（ℓ≥c）。

B-first实际积分：∫_0^1 R_B^-k g_k(ℓ_B,1/2)dB。独立的min/max积分利用精确密度k(k−1)d^(k−2)du dv，结果完全相等。

good B必须同时满足B≥b0、B≤2d−1，故真实交集是[b0,min(1,2d−1)]，空时零。min/max积分保v≤min(1,3d−1)，按d=2/3分段；独立B-first方法改range cutoff为R_B/2，也得到相同结果。没有省略E边界或把good门替换成center点判断。

另选4组有理(min,max)，含source tie、跨度端点与good空交集，在3个k下共12份pointwise layer证书；同时核Cenv片段与span界。实际source层积分是符号精确积分，不是这些点的数值求积。

## 实际结果

所有数值均为精确有理/对数式的显示，Arb224bit包围与符号证书在JSON：

| k | 固定场actual=good | 可变actual | 可变good | Cenv layer上界 | 全span上界 | 旧good质量cap |
|---:|---:|---:|---:|---:|---:|---:|
| 2 | .0833333 | .0804307 | .0191707 | .179907 | .208333 | .772589 |
| 4 | .2 | .0954587 | .0365672 | .377083 | .400521 | 4.63553 |
| 8 | .202257 | .0278793 | .0189653 | .336360 | .339015 | 21.6325 |

旧good cap为2d^(1−k)，来源子窗积分精确是

2k(k−1)(log2−1/2)。

Cenv与span保留了真实共同中心长度，不把每个hull都换成独立中心容量。对这里的uniform [0,1]^k，span包络（a=1,b=2）逐点为

E_k(d)=(k−2^(1−k))/(k−1)−d。

利用全窗range均值(k−1)/(k+1)，无range截断的span积分严格等于

2/(k+1)+(1−2^(1−k))/(k−1)。

因此本诊断截断子窗的span积分更小，局部样本数增长确实被消除；这是精确公式，不是仅凭k=2,4,8猜趋势。它不表明一般非均匀f或高维accepted权也有相同预算。

## 全来源身份与未付连接

独立保留全来源身份：∫_{R^k}K_k dμ^k=X，两个场分别为2、1，因为同一实际父上的m_B^k与分母精确相消。它与上述[0,1]^k诊断积分是不同对象；没有用诊断证明全局身份，更没有据全局归一替原accepted负载D_Y^ν付费。

本例证明了inverse-hull k²价可以是丢中心体积造成的粗化，而非K_k本身强迫的增长。后续仍需保实际接受权的共同中心拥挤与hull质量联合预算；原strict-K、stage/history及root价格未认证。

## 实际执行与冻结

205项exact/interval断言（含逐层/积分顺序/边界/符号界），不是205个独立场。2个场、3个k、12个pointwise层证书。Fraction坐标；SymPy精确部分分式/多项式积分与prime-log归一；Arb224bit界限正性。两次通用符号简化尝试因无必要的内存膨胀被主动中止，不作为验证证据；最终有界实现运行约.98秒，无浮点求积或solver。

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r471_numeric.py
```

Python3.12.14、SymPy1.14.0。脚本自含，输出写自身目录；JSON含compute_index、点层证书及全部精确积分。decimal和计时仅显示/元数据。

冻结白名单：r471_numeric.py、r471_numeric.json、r471_numeric.md。完成停止，不扩场或k。
