# R471：真实双父几何平均采样势与全局初值预算

**结论范围。** 本稿证明一个保真实来源采样的非负超鞅，其初始实际全积分至多 \(4SrX\)，优于 R470 非对称势的 \(SA_nX\)。Poisson 平均同时抑制两个方向的质量落差，平均漂移可获根阶来源价格；但未证明该漂移或势值恢复原 \(P\) 的固定比例，故不据此宣布原目标闭合。

沿原合同，\(\mu=f\,dx\)、\(m_A=\mu(Q_A)=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(r=\lambda/q\)、\(a\le R_A\le b\le2a\)、\(\sigma=q_A\,dA\)。同一实际原流 \(P\) 的 \((A,y,z)\) 投影至多 \(S\sigma(dA)\pi_A(dy)\pi_A(dz)\)。原接受、阶段、终端及历史保留在 \(P\)；测试父 \(B\) 始终是实际选择器中的父，但不获新历史。

## 1. 准确质量 profile 与对称候选

对来源串 \(Y\)，必须使用带 \(q_B\) 的闭 CDF
\[
 F_Y(t)=\int q_Bc_B(Y)1_{\{m_B\le t\}}dB.
\]
令 \(M_Y=\mu(\operatorname{boxhull}Y)\)、\(t_0=\max(qa^n,M_Y)\)、\(t_1=\lambda b^n\)。当 \(t_0\le t_1\)，
\[
 K_k(Y)=\frac{F_Y(t_1)}{t_1^k}
       +k\int_{t_0}^{t_1}F_Y(t)t^{-k-1}dt.\tag{1}
\]
最低质量原子已被此式保留，\(t_0=t_1\) 时不能删除基项；\(t_0>t_1\) 核为零。完整跨度上界仍是
\[
 F_Y(t)\le\lambda\prod_i\big(\min(b,(t/q)^{1/n})-d_i(Y)\big)_+,
 \quad t\ge t_0.
\]
来源积分后，该自由边长包络不能自动继承实际匹配质量上限。为避免先删跨度再估裸逆 hull 矩，本稿改在同一实际双父积分中保留交叠 \(I_{AB}=\mu(Q_A\cap Q_B)\)。

给定原父 \(A\)，令 \(Y_1=y,Y_2=z\)，后续样本条件 iid 为 \(\pi_A\)。定义
\[
 G_k^A(Y)=\int_E R_B^{-n}(m_A/m_B)^{(k-1)/2}c_B(Y)dB,
 \qquad g_{AB}=\frac{I_{AB}}{\sqrt{m_Am_B}}\le1.
\]
完整匹配给 \(I_{AB}\le\min(m_A,m_B)\)，故
\[
 \mathbb E_A[G_{k+1}^A\mid Y]
 =\int R_B^{-n}(m_A/m_B)^{(k-1)/2}c_B(Y)g_{AB}dB
 \le G_k^A(Y).\tag{2}
\]
所有质量有正下界、中心集有限，故各固定 \(k\) 可直接非负换序。此为原父下的真实采样超鞅；没有将来源律换成一个固定全局 law。

## 2. 实际全局初值：\(4SrX\)，不多收 \(A_n\)

对固定来源 \(x\)，原生中心质量 CDF 满足
\[
 F_x(t)=|\{B:x\in Q_B,m_B\le t\}|\le t/q.
\]
因为真实 \(m_B\ge qR_B^n\)，这些中心全部在以 \(x\) 为中心、边长 \((t/q)^{1/n}\) 的盒中。给定 \(m>0\)，函数
\[
 w_m(t)=t^{-1}\sqrt{\frac{\min(m,t)}{\max(m,t)}}
 =\begin{cases}(mt)^{-1/2},&t\le m,\\m^{1/2}t^{-3/2},&t\ge m\end{cases}
\]
连续、单调下降。Stieltjes 分部积分保所有质量原子，给
\[
 \int w_m(t)dF_x(t)
 \le\frac1q\int_0^\infty w_m(t)dt=\frac4q.\tag{3}
\]
零端边界由 \(F_x(t)w_m(t)\le\sqrt{t/m}/q\to0\) 控制；无穷端用中心集有限。没有来源密度帽。

原接受仅在正上界中放大一次。设 \(T_0=\int G_2^A(y,z)dP\)，则
\[
\begin{split}
 T_0&\le S\iint q_Aq_B\frac{I_{AB}^2}{(m_Am_B)^{3/2}}dA\,dB\\
 &\le S\int\mu(dx)\int\frac{q_Ac_A(x)}{m_A}dA
       \int\frac{q_Bc_B(x)}{m_B}
          \sqrt{\frac{\min(m_A,m_B)}{\max(m_A,m_B)}}dB\\
 &\le4Sr\int\mu(dx)D(x)=4SrX.\tag{4}
\end{split}
\]
其中第二行只用了 \(I_{AB}^2\le I_{AB}\min(m_A,m_B)\)，第三行是 (3) 与 \(q_B\le\lambda\)。这是真实全父、全来源预算；无需丢掉来源后另付一次 \(A_n\)。只在转成来源粗价时才用 \(X\le A_nW\)。

注意 (3) 依赖真实质量权单调下降。不能把它自动推广成任意高次交叠的 \(1/(p-1)\) 行界：当 \(\alpha=(p-1)/2>1\) 时，\(t^{-1}(t/m)^\alpha\) 在 \(t<m\) 递增，中心 CDF 上界不足以执行该分部积分。故本稿只使用已证的 \(p=2\) 初值，未声称完整 \(G_k\) 随 \(k\) 获得根阶价格。

## 3. Poisson 漂移、双向质量尾及未付终值

附加样本数为 \(N\sim\mathrm{Pois}(\tau)\)，与给定原记录下的样本独立。其真实条件平均为
\[
 \overline G_\tau(A,y,z)
 =\int R_B^{-n}\sqrt{m_A/m_B}\,c_B(y)c_B(z)
       e^{-\tau(1-g_{AB})}dB.
\]
令 \(T_\tau=\int\overline G_\tau dP\)。由 (4) 支配可微分，并有
\[
 0\le-T_\tau'\le\frac{4SrX}{e\tau}
 \le\frac{4SrA_n}{e\tau}W\quad(\tau>0),
 \qquad\int_0^\infty(-T_\tau')d\tau=T_0-T_\infty\le4SrX.\tag{5}
\]
特别 \(\tau\asymp1+\sqrt n\) 给辅助漂移的根阶来源价。若 \(L>1\)，在任一方向质量比超过 \(L\) 时 \(g_{AB}\le L^{-1/2}\)，所以
\[
 T_\tau\{m_B>Lm_A\ \text{或}\ m_A>Lm_B\}
 \le4Sr e^{-\tau(1-L^{-1/2})}X.\tag{6}
\]
取 \(\tau\ge\log_+(4Sr/\epsilon)/(1-L^{-1/2})\) 可将该**辅助势尾**压到 \(\epsilon X\)，不是直接支付原 \(P\) 对应子集。

单调收敛表明 \(T_\infty\) 仅保 \(g_{AB}=1\)，即质量相等且 \(\mu(Q_A\triangle Q_B)=0\) 的实际双父；不能无证明置零。更基本的唯一缺桥是：在原 low-common、质量下降和全部接受权下，如何把原流质量控制为此共同势的实际下降加可付终值。当前 \(G_2\) 不必逐记录有正下界，漂移也可能很小。故不将 (5) 的小幅度加权根价当作原流恢复，不赋 \(B\) 原历史，不宣布收缩闭合。

## 4. 实际本机检查

以下代码实际在指定 Python 运行。三组 Fraction 初值模型是连续原生场：来源小区间中心 \(-.83,0,.83\)，各长度 \(1/50\)，完整质量依次见代码；父中心块中心 \(-.4,.4\)，长度 \(1/100\)，边长 \(1,9/5\)，精确捕获为 \(\{1,2\}\)、\(\{2,3\}\)。它们为非等质量、真实 q-band、单 octave，但不认证原高维历史。SymPy 核质量权积分；Arb128 核有限漂移标量。未重复数值员的跨度 Beta 实验。

```python
from fractions import Fraction as F
from math import isqrt
import sympy as sp
from flint import arb,ctx
ctx.prec=128
u=sp.symbols('u',positive=True)
assert sp.integrate(u**(-sp.Rational(1,2)),(u,0,1))==2
assert sp.integrate(u**(-sp.Rational(3,2)),(u,1,sp.oo))==2
print('symbolic mass integrals PASS 2')
for M in ((3,1,8),(8,1,15),(15,1,24)):
    mass=[F(M[0]+M[1]),F(M[1]+M[2])]
    side=[F(1),F(9,5)];vol=F(1,100)
    qa=[m/R for m,R in zip(mass,side)]
    r=max(qa)/min(qa);X=sum(q*vol for q in qa)
    total=F(0)
    for a in range(2):
        for b in range(2):
            I=mass[a] if a==b else F(M[1])
            root=F(isqrt(mass[a].numerator*mass[b].numerator))
            assert root**2==mass[a]*mass[b]
            total+=vol**2*qa[a]*qa[b]*I**2/root**3
    assert total<=4*r*X
print('native initial potential PASS 3')
def A(x):return arb(x.numerator)/arb(x.denominator)
count=0
for tau in (F(1,2),F(1),F(2),F(4),F(8)):
    for x in (F(0),F(1,4),F(1,2),F(3,4),F(1)):
        lhs=A(x)*(-A(tau*x)).exp()
        rhs=(-arb(1)).exp()/A(tau)
        if tau*x==1:assert lhs.overlaps(rhs)
        else:assert rhs-lhs>0
        count+=1
print('Arb128 drift PASS',count,
      '(equality cases also certified by exact tau*x=1)')
```

实际 stdout：

```text
symbolic mass integrals PASS 2
native initial potential PASS 3
Arb128 drift PASS 25 (equality cases also certified by exact tau*x=1)
```
