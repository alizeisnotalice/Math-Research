# R471 FINAL PASS（限定真实 profile、归一极值压缩与对称辅助势）

独立 PRE 先于作者审读。本报告通过下述一般恒等式、辅助势估计及所列复现，不认证完整原 (P) 的根阶付款、固定比例恢复或一般弱型闭合。母账仍保 (|P|)，测试父和新增来源均未获得旧 history。

1. **质量层及极值压缩。** 精确层叠使用带 (q_A) 的闭 CDF，最低/最高质量原子、(m_0=m_1) 基项和严格质量空域处理正确。完整 span 体积仅是正上放，不能给自由边长中心赋原质量门。固定原记录后的 essential 新点几乎处处唯一，数目至多 (2n)；按其索引集分割，余点积分为 ((M_H/m_A)^{r-j})，故 Poisson 系数 (	au^j/j!) 与补偿指数准确。取测试1逐原记录归一，保旧两源、接受权及 history。只依 hull 的测试可直接压缩；依内部样本的测试需先条件平均，现稿已限定。失败费 (2Sn/(delta	au)X) 与截断费 (S	au X/(N_0+1)) 不混为来源价。

2. **(G_2) 的常数初值。** 同原父追加真实 (pi_A) 样本使 (G_k^A) 被积项乘 (g_{AB}=I_{AB}/\sqrt{m_Am_B}\le1)，超鞅公式成立。真实来源点中心 CDF (F_x(t)\le t/q) 加单调平方根质量权，经 Stieltjes 分部积分含原子给 (4/q)；零端/无穷端边界均消失。用 (I^2\le I\min(m_A,m_B))、完整来源 Tonelli 和一次 (q_B\le\lambda)，确得 (int G_2,dP\le4Sr_0X)，没有额外 (A_n) 或软因子分母。它改善辅助势初值的 (X) 系数，尚非原流 (W) 预算。

3. **Poisson 势及终值。** 同父混合准确产生 (e^{-\tau(1-g)})，初值支配足以微分/取极限。瞬时漂移 (4Sr_0X/(e\tau)) 与任意双向质量比 (>L) 的势尾指数正确；它们只付带势量。终值保 (g=1)（同质量且完整 (mu)-对称差零）的部分，未被无证删除。质量窗失败需更大强度时须同时满足，不能只取有利参数。原单位记录质量如何由下降与可付终值覆盖仍缺。

4. **撤回与数值边界。** 高次质量权在 (alpha>1) 的低质量段递增，不能沿用平方根 CDF 证明得到趋零行界；该错误推广已明确撤回、未进入任何费用。两个 uniform-source 诊断场保真实 selector、good 窗及完整 span，全部来源身份与截断来源子窗分开；其无 (k^2) 增长是所给模型的解析结论，不外推到任意 (f) 或原接受流。

## 独立隔离复现

指定本机 Python；目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r471_audit_a4c_wbp4`。提取 geometry、complement、main 内嵌代码并运行 numeric.py，共五份脚本 stdout 与冻结 replay 逐字节相同。范围分别为 geometry 2项符号积分、3个连续中心块初值、25项Arb漂移（内部平方根 sanity 不凑总数）；complement112；numeric205；主稿57和35。numeric JSON 仅删除 `compute_index.seconds` 后完全一致，规范化 SHA256 为 `aadada7a249ef68f9c005d37fc3233d420b8bfada343f81253d59fc93440074d`。有限算例未认证原 strict 路径、阶段或 history，计数不代表独立模型数。

## 冻结输入 SHA256

- `r471_main.md`: `c093656f1d4b970234b653eb0cc9a3a84e5e8a58c72222f428363bf48085cad8`
- `r471_geometry.md`: `4360d0193d26b5b0366081f565797b1aa8dd60541e81a463137e6b6f9f46cbe8`
- `r471_complement.md`: `413dd68d705ebb94b78fe26ae006ae1c04bbe96aeeb6e9804ef379c9ecd5de22`
- `r471_numeric.md`: `91c81bdb458be59f09d39884e5f2a60c30f5fc390285fc35f571eb35041695cf`
- `r471_numeric.py`: `5c82beca064a30c9f1fb27401bf63728cc6e4b3dd181c16a33dd381140e31174`
- `r471_numeric.json`: `90aaccd244c786616eb0bb01b81fe07bcdc146e7948076e332bd2c41480aa21c`
- `r471_replay.json`: `1b9cb61a3b04748901af1ac6d57f6326ba6b7ac10a1782684e13e1eb0d08a4de`
