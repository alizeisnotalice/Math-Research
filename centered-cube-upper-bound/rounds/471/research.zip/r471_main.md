# 第471轮：共同中心体积、归一极值压缩与对称采样势

一般n^(1/2+o(1))一致弱型上界仍未证明。本轮从第470轮的完整剩余积分出发，保留共同中心体积与真实质量分母，证明一种在每条原记录上归一的Poisson极值压缩，并建立对称采样势的全局初值费用。它降低了辅助势的初始价格，却尚未证明辅助势的下降能覆盖原流；不能以此宣布中间段硬层闭合。

## 1. 同一合同与质量层

记μ=f dx，W=μ(R^n)，m_A=q_A R_A^n，q≤q_A≤λ，r0=λ/q，a≤R_A≤b≤2a，σ=q_A dA，X=σ(E)，A_n=1+n log(b/a)。原P保旧双来源y,z、终端、stage及history，其静态投影≤Sσπ_A²。以下所有辅助来源均在原A内按完整π_A抽取，不更换原父或赋予测试父B原历史。

真实质量CDF必须带q_A：
\[
 F_Y(t)=\int_E q_A c_A(Y)1_{m_A\le t}dA,\quad
 K_k(Y)=m_1^{-k}F_Y(m_1)+k\int_{m_0}^{m_1}F_Y(t)t^{-k-1}dt,
\]
其中m0=qa^n，m1=λb^n。最低质量原子及固定质量基项均保留。实际捕获中心给
\[
 F_Y(t)\le\lambda\prod_i\bigl(\min[b,(t/q)^{1/n}]-\operatorname{span}_iY\bigr)_+.
\]
这个自由边长包络不能继承原选择器的质量门。其来源积分涉及自由cube的真实高次质量矩，而非自动得到一次W。

## 2. 在每个原记录上归一的极值压缩

固定原记录ξ，再取N~Pois(τ)个独立π_A样本，τ为辅助强度，不是质量带上界λ。由于μ对Lebesgue绝对连续，每个新样本串的坐标极值索引几乎处处唯一，至多2n个新点决定旧y,z之外的全部新极值。令E_j为j个点均相对旧hull贡献极值的集合，H=boxhull(y,z,Z)，M=μ(H)。对任何非负hull函数Ψ，附稿严格证明
\[
 \mathbb E\Psi(\xi,H_N)
 =\sum_{j=0}^{2n}\frac{\tau^j}{j!}
 \int_{E_j}\Psi(\xi,H)\frac{c_A(Z)}{m_A^j}
 e^{-\tau(1-M/m_A)}d\mu^j(Z).
\]
取Ψ=1时，每个原ξ上的右侧严格等于1。此式真正保原P、旧来源和history；没有用新hull质量代替m_A正常化。它消去无限样本数求和中的组合系数，但仍须保τ^j/j!、指数及完整来源积分。

同父hull质量窗失败费为
\[
 |P\{M<(1-\delta)m_A\}|\le\frac{2Sn}{\delta\tau}X.
\]
若数值实现截断N≤N0，还另有≤SτX/(N0+1)的截断费；不能免费重新归一化。接近M=m_A时指数几乎不衰减，极值来源的共享费用仍未解决。

## 3. 对称采样势的初值从A_nX降至常数X

记I_AB=μ(QA∩QB)，g_AB=I_AB/√(m_A m_B)≤1。固定旧y,z并逐次追加π_A来源，定义
\[
 G_k^A(Y)=\int_E R_B^{-n}(m_A/m_B)^{(k-1)/2}c_B(Y)dB.
\]
真实下一步条件平均把被积项乘g_AB，因此G_k是同原父采样下的非负超鞅。这里不采用技能F01中尚未定义的私有GP-BRANCH，而从上述明确公式直接证明。

核心初值估计是
\[
 T_0:=\int G_2^A(y,z)dP
 \le S\iint q_Aq_B\frac{I_{AB}^2}{(m_A m_B)^{3/2}}dA\,dB
 \le4Sr_0 X.
\]
证明保实际中心质量CDF |{B:x∈QB,m_B≤t}|≤t/q。质量权
\[
 w_m(t)=t^{-1}\sqrt{\min(m,t)/\max(m,t)}
\]
连续递减且∫_0^∞w_m(t)dt=4，所以Stieltjes分部积分的价格为4/q。再用I²≤I min(m_A,m_B)，将I展开到同一个μ(dx)后只收一次X，没有额外A_n。该初值界比第470轮非对称势的SA_nX确实更强，但仍不是原流的W预算。

Poisson混合给
\[
 T_\tau=\int dP\int R_B^{-n}\sqrt{m_A/m_B}\,c_B(y)c_B(z)
 e^{-\tau(1-g_{AB})}dB.
\]
于是
\[
 0\le-T_\tau'\le\frac{4Sr_0X}{e\tau}
 \le\frac{4Sr_0A_nW}{e\tau}.
\]
质量比任一方向超过L>1的辅助势占用≤4Sr0 exp[-τ(1−L^(-1/2))]X。τ约√n时，辅助漂移有根阶来源价；若同时需要小hull失败费，应按上一节更大的强度条件选τ，不能只选有利条件。

完整下降总量是T0−T∞；终值保留g_AB=1，即两实际cube质量相等且μ对称差为零的部分。原P并未被证明由该下降及可付终值支配。因此上述势尾、瞬时漂移和质量窗失败，不能直接作为原P的已付分支相加。

一次候选推广已在推导中纠正：将质量权改成t^(-1)(min/max)^α时，α>1的低质量段递增，不能再用同一CDF比较推出随高次幂趋零的行界。本轮仅保合法平方根版本；没有据被撤回的推广计入任何根阶费用。

## 4. 实际计算、总账及剩余步骤

本机数值附件对固定和可变边长的真实连续场作精确积分，保真正selector的质量CDF、自由固定边长包络及good窗三者区别。诊断均匀来源子窗内，保完整跨度的联合积分消除了旧质量帽中的k²增长；这只是两场、k=2,4,8的几何诊断及其所给解析式，不认证任意f或原history。

实际复现范围：几何附件2项符号质量积分、3个连续中心块初值检查、25项Arb漂移检查；互补附件112项Fraction检查；数值主脚本205项精确/区间断言；下附主代理57项Poisson分割和35项质量权代数检查。各报告区分辅助恒等式、严格区间结果与一般证明。曾终止的符号简化尝试未列为验证成功。独立审查与复现结果随包保存，不编译PDF。

母账仍为
\[
 R_{433}\le[S\zeta+2S\varepsilon_0/(1+\sqrt n)+2S\delta_{\rm round}]X+|P|.
\]
本轮没有删除|P|、旧母倍率或任何宽距离、低pe、初始、跳跃、删除费用。下一步需在同一真实接受权下，将归一极值积分与共同中心几何结合，证明原P能由可付耗散覆盖并结算终值。仅有归一、超鞅、瞬时根阶漂移或诊断子窗都不够。


### 主代理复现：Poisson压缩的连续一维条件分割

```python
import sympy as s
from flint import arb,ctx
ctx.prec=192
T,L,R,x,z=s.symbols('T L R x z', positive=True)
left=s.integrate(T*s.exp(-T*(x+R)),(x,0,L))
right=s.integrate(T*s.exp(-T*(L+z)),(z,0,R))
both=s.integrate(s.integrate(T**2*s.exp(-T*(x+z)),(x,0,L)),(z,0,R))
zero=s.exp(-T*(L+R))
assert s.simplify(zero+left+right+both-1)==0
assert s.simplify(left-(1-s.exp(-T*L))*s.exp(-T*R))==0
assert s.simplify(both-(1-s.exp(-T*L))*(1-s.exp(-T*R)))==0
checks=3
for phase,(ll,rr) in enumerate([(s.Rational(1,4),s.Rational(1,4)),(s.Rational(1,10),s.Rational(2,5)),(s.Rational(0),s.Rational(3,4))],1):
 for tau in [s.Rational(1,2),s.Rational(2),s.Rational(16)]:
  aa=arb(str(ll.p))/int(ll.q);bb=arb(str(rr.p))/int(rr.q);tt=arb(str(tau.p))/int(tau.q)
  e1=(-tt*aa).exp();e2=(-tt*bb).exp()
  weights=[e1*e2,(1-e1)*e2,e1*(1-e2),(1-e1)*(1-e2)]
  assert (sum(weights)-1).contains(0);checks+=1
  for w in weights:
   assert w.lower()>=0 and w.upper()<=1;checks+=1
 print('phase',phase,'closed continuous Poisson partition checked')
# Directed high-mass contribution: p_BA<=1/Lambda. Exact exponent comparison.
for lam in [s.Rational(2),s.Rational(3),s.Rational(8)]:
 for p in [s.Rational(0),1/(2*lam),1/lam]:
  assert s.simplify((1-p)-(1-1/lam))>=0;checks+=1
print('PASS',checks,'symbolic/interval assertions; 1D continuous hull partitions and scalar tail algebra, no original-history claim')
```


### 主代理复现：质量权的积分及单调性条件

```python
import sympy as s
from flint import arb,ctx
ctx.prec=192
x,t=s.symbols('x t', positive=True)
checks=0
# Exact sourcewise mass-CDF majorant integral, including both infinite tails.
for alpha in [s.Rational(1,4),s.Rational(1,2),s.Rational(1),s.Rational(2),s.Rational(4)]:
 lower=s.integrate(t**(alpha-1),(t,0,1))
 upper=s.integrate(t**(-alpha-1),(t,1,s.oo))
 assert s.simplify(lower+upper-2/alpha)==0;checks+=1
 for mass in [s.Rational(1,3),s.Rational(1),s.Rational(7)]:
  low=t**(alpha-1)/mass**alpha
  high=mass**alpha/t**(alpha+1)
  assert s.simplify(low.subs(t,mass)-high.subs(t,mass))==0;checks+=1
  # Stieltjes integrand is w(t)=t^{-1}(min/max)^alpha.
  # For alpha>1 its low branch INCREASES: retain this diagnostic explicitly.
  assert s.simplify(s.diff(low,t)-(alpha-1)*t**(alpha-2)/mass**alpha)==0;checks+=1
print('PASS',checks,'mass-weight identities; WARNING w increases below m when alpha>1')
```
