"""Exact local-mass/gain guards and log-domain parameter checks.
No finite good jitter environment or high-dimensional weak event is certified.
"""
from fractions import Fraction as F
from bisect import bisect_right
from decimal import Decimal as D, localcontext, ROUND_FLOOR, ROUND_CEILING
from itertools import product
from pathlib import Path
import json


def spike_primitive(K,u,pattern):
 width=F(1,K*u**4);events={F(0):F(0),F(1):F(0)}
 def add(a,b):
  if a<b:
   events[a]=events.get(a,F(0))+1/(K*width)
   events[b]=events.get(b,F(0))-1/(K*width)
 for j in range(K):
  phase=F(1,1024) if pattern==0 else (F(1023,1024) if j%2 else F(1,1024)) if pattern==1 else F((37*j)%1024*2+1,2048)
  x=(j+phase)/K;lo=x-width/2;hi=x+width/2
  add(max(F(0),lo),min(F(1),hi))
  if lo<0:add(1+lo,F(1))
  if hi>1:add(F(0),hi-1)
 nodes=sorted(events); density=[];cum=[F(0)];v=F(0)
 for j,x in enumerate(nodes):
  if j: cum.append(cum[-1]+density[-1]*(x-nodes[j-1]))
  v+=events[x];density.append(v)
 assert cum[-1]==1 and all(z>=0 for z in density)
 def prim(x):
  q=x.numerator//x.denominator;z=x-q
  j=bisect_right(nodes,z)-1
  return q+cum[j]+density[j]*(z-nodes[j])
 return nodes,prim


def local_mass():
 rows=[]
 for K,u in [(64,4),(256,8),(1024,16)]:
  for pattern in range(3):
   nodes,P=spike_primitive(K,u,pattern)
   for n in [16,64,256]:
    d=F(1,8*n)
    cuts=set(nodes[:-1])|{(x-d)%1 for x in nodes[:-1]}
    best=max(P(x+d)-P(x) for x in cuts)
    bound=d+F(2,K)
    assert best<=bound
    # Piecewise affine interval mass: all changes of slope are in cuts.
    rows.append(dict(K=K,u=u,pattern=pattern,n=n,grid_side=str(d),maximum_spike_interval_mass=str(best),bound=str(bound),tested_breakpoints=len(cuts)))
 return rows


def response(points,weights,x,n):
 radii=[max(F(1),2*max(abs(a-b) for a,b in zip(y,x))) for y in points]
 scales=sorted({F(1),F(2)}|{r for r in radii if r<=2})
 vals=[sum((w for w,r in zip(weights,radii) if r<=L),F(0))/L**n for L in scales]
 M=max(vals);R=scales[vals.index(M)]
 return M,R,scales,radii


def gain_guards():
 count=positive=0
 for n in [1,2,4,8]:
  points=[tuple(F(0) for _ in range(n)),tuple(F(3,8) if j%2==0 else F(-1,8) for j in range(n)),tuple(F(-5,8) if j%2==0 else F(1,4) for j in range(n))]
  for z in [F(-1,8),F(1,4),F(3,4)]:
   x=tuple(z if j%2==0 else -z for j in range(n))
   for w in [[F(1,3)]*3,[F(1,1024),F(1,4),F(767,1024)]]:
    M,R,scales,radii=response(points,w,x,n)
    if not M:continue
    for k in [1,4]:
     for counts in product(range(5),repeat=3):
      v=[a*b/k for a,b in zip(w,counts)]
      noise=max(abs(sum(((vv-ww) for vv,ww,r in zip(v,w,radii) if r<=L),F(0)))/L**n for L in scales)
      fixed=sum((vv for vv,r in zip(v,radii) if r<=R),F(0))/R**n
      for t in [F(1,2),F(3,4)]:
       mix=[(1-t)*a+t*b for a,b in zip(w,v)]
       Mt,_,_,_=response(points,mix,x,n);frozen=(1-t)*M+t*fixed
       assert frozen>0 and Mt>=frozen
       assert abs(Mt-M)<=t*noise
       assert Mt-frozen<=2*t*noise
       assert (Mt-frozen)/frozen<=2*t*noise/((1-t)*M)
       count+=1;positive+=Mt>frozen
 return dict(exact_histories=count,positive_reselection_cases=positive,scope='possible Poisson count histories; no expectation or global weak-ratio claim')


def parameters(precision):
 rows=[]
 with localcontext() as c:
  c.prec=precision
  for power in [8,12,16,24,32,48]:
   n=10**power;dn=D(n);cs=D(2).sqrt()/10
   kr=cs*dn.sqrt()/(64*(8*dn.ln()).sqrt())+D('.5')
   K=64*int(kr.to_integral_value(rounding=ROUND_FLOOR));assert K>=64
   u=cs*dn.sqrt()/K
   # E=16alpha/(3pi^4)<6, so actual M<=ceil((48u)^(1/3)).
   Mup=int(((48*u).ln()/3).exp().to_integral_value(rounding=ROUND_CEILING))
   Aup=D(8)/3*(1+D(Mup).ln())/K
   assert Aup<D('.25')
   d=1/(8*dn);r=2*(d+1/D(K));assert r<1
   logtheta=dn*r.ln()-(u*u/2-2)
   loggain=D(16).ln()+dn*r.ln()/2 # t=.5, kappa=1, V/W<=2.
   rows.append(dict(n=str(n),K=K,M_upper=Mup,low_spectrum_amplitude_upper=format(Aup,'.17g'),
    log_theta_upper=format(logtheta,'.17g'),log_reselection_gain_over_W_upper=format(loggain,'.17g'),
    log_gain_div_n_log_n=format(loggain/(dn*dn.ln()),'.17g')))
 return rows



def quantum_potential(precision):
 rows=[]
 with localcontext() as c:
  c.prec=precision
  for n in [1,4,8]:
   B=D(2)**n
   for alpha in ([D('.25'),D(1),D('.03125')] if n<=4 else [D('.25'),D(1)]):
    for u in [D('.75'),D('1.5'),D('1.5')*B]:
     rate=u/alpha;J=int(6*rate)+32
     def potential(v):
      if v<=1:return D(0)
      if v<=B:return v-1
      return B*(v/B).ln()+B-1
     pn=(-rate).exp();total=D(0)
     for N in range(J+1):
      if N:pn*=rate/N
      total+=pn*potential(alpha*N)
     # E(alpha N 1{N>J})/u = P(Poi(rate)>=J).
     pj=(-rate).exp()
     for j in range(1,J+1):pj*=rate/j
     tail=pj/(1-rate/(J+1))
     change=(total-potential(u))/u
     assert change>=-6*alpha-D('1e-30')
     rows.append(dict(n=n,alpha=str(alpha),u=str(u),rate=str(rate),cutoff=J,
      truncated_change_over_W=format(change,'.17g'),omitted_potential_over_W_bound=format(tail,'.17g')))
 return rows


def main():
 rows=local_mass();g=gain_guards();p70=parameters(70);p110=parameters(110);assert p70==p110
 q70=quantum_potential(70);q110=quantum_potential(110);assert q70==q110
 out=dict(status='PASS finite guards',local_mass=rows,gain=g,formal_parameters=p70,quantum_potential=q70,
  scope='No finite-n good environment, Cramer constants, nearmax, or true weak-event probability certified. Asymptotic high weak ratio is an accepted prior theorem, not these numerics.')
 Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(dict(status=out['status'],mass_cases=len(rows),gain_histories=g['exact_histories'],parameter_cases=len(p70),quantum_cases=len(q70))))

if __name__=='__main__':main()
