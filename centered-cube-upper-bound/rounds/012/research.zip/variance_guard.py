from fractions import Fraction as F
from itertools import product
from math import prod
import json

def log_bounds(x,terms=80):
 assert x>=1
 z=(x-1)/(x+1)
 lo=2*sum((z**(2*k+1)/F(2*k+1) for k in range(terms)),F(0))
 hi=lo+2*z**(2*terms+1)/(F(2*terms+1)*(1-z*z))
 return lo,hi

def entropy(parts,pts,b=F(2)):
 W=sum(map(sum,parts));lo=hi=W
 for i,g in enumerate(parts):
  wi=sum(g)
  for j,y in enumerate(pts):
   if not g[j]:continue
   outside=sum(sum(h[k] for k,z in enumerate(pts) if max(abs(u-v) for u,v in zip(y,z))<=b) for q,h in enumerate(parts) if q!=i)
   l,u=log_bounds(1+outside/wi);lo+=g[j]*l;hi+=g[j]*u
 return lo,hi

def scenarios(parts):
 choices=[[(i,w/sum(g)) for i,w in enumerate(g) if w] for g in parts]
 for row in product(*choices):yield [j for j,p in row],prod(p for j,p in row)

rows=[];merges=0;local=0
for n in [1,2,3]:
 pts=list(product([F(-1,4),F(1,4)],repeat=n)); N=len(pts)
 base=[F(j+1, N*(N+1)//2) for j in range(N)]
 Ls=[F(1),F(3,2),F(2)]
 cuts=sorted({y[0]+sign*L/2 for y in pts for L in Ls for sign in [-1,1]})
 patterns={}
 for ix in product(range(len(cuts)-1),repeat=n):
  x=[(cuts[i]+cuts[i+1])/2 for i in ix];vol=prod(cuts[i+1]-cuts[i] for i in ix)
  masks=tuple(tuple(j for j,y in enumerate(pts) if all(abs(xx-yy)<L/2 for xx,yy in zip(x,y))) for L in Ls)
  patterns[masks]=patterns.get(masks,F(0))+vol
 variants={
 'singleton':[[base[j] if j==i else F(0) for j in range(N)] for i in range(N)],
 'all':[base],
 'pairs':[[base[j] if j//2==i else F(0) for j in range(N)] for i in range(N//2)],
 'overlapping_iid_two':[[v/2 for v in base] for _ in range(2)]}
 for name,parts in variants.items():
  ws=list(map(sum,parts)); entlo,enthi=entropy(parts,pts)
  outcomes=list(scenarios(parts))
  if len(parts)>1:
   merged=[[a+b for a,b in zip(parts[0],parts[1])]]+parts[2:]
   nl,nu=entropy(merged,pts);assert nu<=entlo;merges+=1
  for tau,eps in product([F(1,8),F(1,2)],[F(1,4),F(1,2)]):
   c=(1-eps)*tau;I=weighted=expected=varint=F(0)
   for masks,vol in patterns.items():
    masses=[sum(base[j] for j in mask) for mask in masks]
    values=[m/L**n for m,L in zip(masses,Ls)]
    H=max(values);winner=values.index(H)
    if H>tau:
     mask=masks[winner];m=masses[winner]
     mi=[sum(g[j] for j in mask) for g in parts]
     sig=sum(w*v-v*v for w,v in zip(ws,mi));V=sig/(m*m)
     I+=tau*vol;weighted+=c*vol/(1+V/eps**2);varint+=tau*vol*V
     if len(parts)>1:
      nsig=(ws[0]+ws[1])*(mi[0]+mi[1])-(mi[0]+mi[1])**2+sum(w*v-v*v for w,v in zip(ws[2:],mi[2:]))
      diff=ws[0]*mi[1]+ws[1]*mi[0]-2*mi[0]*mi[1]
      assert nsig-sig==diff and diff>=0;local+=1
    success=F(0)
    for sample,p in outcomes:
     vals=[sum(w for w,j in zip(ws,sample) if j in mask)/L**n for mask,L in zip(masks,Ls)]
     expected+=p*c*vol*int(max(vals)>c)
     if H>tau:success+=p*int(vals[winner]>c)
    if H>tau:assert success>=1/(1+V/eps**2)
   assert weighted<=expected<=entlo
   if I:
    vb=varint/I;assert weighted>=(1-eps)*I/(1+vb/eps**2)
   else:vb=F(0)
   rows.append({'n':n,'partition':name,'tau':str(tau),'epsilon':str(eps),'I':str(I),'Vbar':str(vb),'weighted_retention':str(weighted),'expected_output_fee':str(expected),'entropy_lower_display':float(entlo),'outcomes':len(outcomes)})
# separated copies: the local entropy is exactly additive, unlike global label entropy.
parts=[[F(1),F(0)],[F(0),F(1)]];pts=[(F(0),),(F(10),)]
assert entropy(parts,pts)==(F(2),F(2))
scalar=[]
for G in [2,4,8]:
 for mode in ['skew','partial','deterministic']:
  weights=[F(2**j,2**G-1) for j in range(G)]
  ps=([F(j+1,G+1) for j in range(G)] if mode=='skew' else [F(1,2)]*G if mode=='partial' else [F(j%2) for j in range(G)])
  m=sum(w*p for w,p in zip(weights,ps));sig=sum(w*w*p*(1-p) for w,p in zip(weights,ps));V=sig/m**2
  for eps in [F(1,8),F(1,2),F(3,4)]:
   success=F(0)
   for bits in product([0,1],repeat=G):
    value=sum(w*v for w,v in zip(weights,bits));prob=prod(p if v else 1-p for p,v in zip(ps,bits))
    if value>(1-eps)*m: success+=prob
   assert success>=1/(1+V/eps**2)
   scalar.append({'groups':G,'mode':mode,'epsilon':str(eps),'success':str(success),'bound':str(1/(1+V/eps**2))})
background=[]
for n in [1,2,4,8,16,32,64,128,256,1024,4096]:
 beta=(1-F(1,8*n))**n
 ratio=((1+F(1,16*n))/(1-F(1,8*n)))**n
 fee=F(1,2)*(1+F(1,16*n))**n
 assert beta>=F(7,8) and ratio<2 and fee<F(8,15)
 background.append({'n':n,'interior_mass_fraction_display':float(beta),'volume_ratio_display':float(ratio),'actual_fee_upper_display':float(fee)})
# 1D exact constant-density component capture integrals on E0.
profile=[]
D=F(32);a=F(1);b=F(2);rho=F(2);left=b/2;right=D-b/2
for G in [1,2,4,16,64,256]:
 h=D/G;w=rho*h;integral=F(0)
 for j in range(G):
  lo=j*h;hi=(j+1)*h
  cuts=sorted({left,right,*[t for t in [lo-a/2,lo+a/2,hi-a/2,hi+a/2] if left<t<right]})
  def captured(x):return rho*max(F(0),min(hi,x+a/2)-max(lo,x-a/2))
  for u,v in zip(cuts,cuts[1:]):
   m0=captured(u);m1=captured(v)
   # Exact integral of affine m and quadratic m^2.
   integral+=(v-u)*(w*(m0+m1)/2-(m0*m0+m0*m1+m1*m1)/3)
 vbar=integral/((rho*a)**2*(right-left))
 Sleft=b;Sright=D-b;A=sum(w*rho*max(F(0),min((j+1)*h,Sright)-max(j*h,Sleft)) for j in range(G))/(rho*(Sright-Sleft))
 assert A<=2*rho*a*(1+vbar)
 profile.append({'components':G,'Vbar_E0':str(vbar),'source_weight_average':str(A)})
print(json.dumps({'background_constants':background,'background_exact_profiles':profile,'scalar_stress':scalar,'status':'PASS','scope':'finite scales; exact all receiver cells and all sampling outcomes; rational logarithm enclosure','spatial_rows':rows,'entropy_merge_checks':merges,'variance_merge_checks':local,'separated_copy_check':True},indent=2,sort_keys=True))
