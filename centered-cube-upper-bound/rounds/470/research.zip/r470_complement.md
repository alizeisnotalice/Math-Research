# R470：同父样本 hull 的质量压缩与实际 \(K_k\) 势

结论：可对同一原 \(P\) 作有价的近全来源 hull 压缩，且实际 \(K_k\) 给出保留原父的非负漂移。二者的正常化费用尚不能同时按 \(W\) 结算。以下全部使用原实际中心、质量和来源；没有用几何上确界归一化后验。

## 1. 实际预测核与 hull 内常密度

令 \(\mu=f\,dx\)、\(\sigma(dA)=q_A\,dA\)、\(X=\sigma(E)\)，并定义
\[
 K_k(Y)=\int_E\frac{\sigma(dA)}{m_A^k}
                  \prod_{j=1}^kc_A(y_j).
\]
Tonelli 给 \(\int K_{k+1}(Y,x)\mu(dx)=K_k(Y)\) 及
\(\int K_k\,d\mu^k=X\)。仅在 \(K_k(Y)>0\) 时定义实际父后验
\[
 \mathsf R_k(dA\mid Y)=K_k(Y)^{-1}
          m_A^{-k}\prod_jc_A(y_j)\sigma(dA).
\]
这不是原历史刷新。它是静态参考的条件律；原 \(P\) 的实际接受权仍在原记录上。

令 \(H(Y)\) 为坐标盒 hull、\(M(Y)=\mu(H(Y))\)。
因为每个兼容父都捕获整个 \(H(Y)\)，对 \(\mu\)-a.e. \(x\in H(Y)\)：
\[
 \frac{K_{k+1}(Y,x)}{K_k(Y)}
 =\mathbb E_{\mathsf R_k}[m_A^{-1}].                       \tag{1}
\]
故预测落入 hull 的概率恰为
\(M(Y)\mathbb E_{\mathsf R_k}(1/m_A)\le1\)。
若把原静态接受密度 \(0\le a(A,y,z)\le S\) 保留在两个积分中，
同一等式仍成立，但右边必须用该接受密度倾斜后的父后验；
不得把实际接受流换成 \(\mathsf R_k\)。

## 2. 同一原记录上的质量窗：小失败费，没有来源刷新

固定原完整记录（特别保留 \(A,y,z\) 和全部历史），独立追加
\(r\ge1\) 个 \(\pi_A\) 样本，令 \(H_r\) 包含这些样本及原 \(y,z\)。
这是一个概率扩充，投回原记录精确保全 \(P\)。

对一个额外的独立 \(\pi_A\) 样本，未落入新增样本 hull 必有某坐标是严格最小或严格最大。样本交换对称性及坐标并集界给
\[
 \mathbb E\left[1-\frac{\mu(H_r)}{m_A}\,\middle|\,\text{原记录}\right]
 \le \min\left(1,\frac{2n}{r+1}\right).                      \tag{2}
\]
只用不同样本独立，不用坐标独立；原 \(y,z\) 只会扩大 hull。
因此对于 \(0<\delta<1\)，扩充中坏事件
\(\mu(H_r)<(1-\delta)m_A\) 的总质量至多
\[
 \min\left(1,\frac{2n}{\delta(r+1)}\right)|P|
 \le\frac{2Sn}{\delta(r+1)}X.                              \tag{3}
\]
它是原费用的真实正分割，但尚非完整预算：好事件仍保留原费用。这里 \(k=r+2\)，所以分母是 \(\delta(k-1)\)；只有在全 \(k\) 个来源均为参考 \(\pi_A\) iid 时，才可用更强的 \(\delta(k+1)\)。Astra 的另一个 \(V_k\) 接口取 \(k\) 个全新辅助样本、父边缘为 \(P_A\)；两个样本指数不能直接拼接，原旧来源和历史并未移动。

好事件上 \(M\le m_A\le M/(1-\delta)\)。令 \(k=r+2\)。
直接对实际 good 父积分，使用
\[
 \left|\{A:c_A(y_1)=1,\ m_A\le T\}\right|\le T/q,
\]
得
\[
 \boxed{\quad
 K_k^{\rm good}(Y)\le\frac{\lambda}{q(1-\delta)}M(Y)^{1-k}.
 \quad}                                                   \tag{4}
\]
此处先用 \(m_A\ge M\) 保 \(m_A^{-k}\le M^{-k}\)，再用父中心体积
\(M/[q(1-\delta)]\)；**没有** \((1-\delta)^{-r}\)。
若直接把全部原样本的 \(\pi_A\) 换为 \(\mu|_H/M\)，则不能省略相应变换费用。

(4) 对全来源积分的确切上界是
\[
 |P_{\rm good}|
 \le \frac{S\lambda}{q(1-\delta)}
 \int_{\substack{M(Y)\ge(1-\delta)qa^n\\
                 \operatorname{diam}_\infty Y\le b}}
           M(Y)^{1-k}\,d\mu^k(Y).                         \tag{5}
\]
不是每个 hull 收一次 \(W\)。这个临界逆 hull 质量矩没有已证根阶预算。
量化其粗化代价：当 \(\mu=1_{[0,1]}dx\)、\(0<c<d\le1\) 时，
\[
 \int_{\{c\le\operatorname{range}Y\le d\}}
       (\operatorname{range}Y)^{1-k}\,d\mu^k
 =k(k-1)\,[\log(d/c)-d+c].                                \tag{6}
\]
证明是极值密度 \(k(k-1)t^{k-2}(1-t)dt\)。固定截断仍有 \(k^2\) 费用；
这仅诊断 (4) 的来源外放松，不是原匹配问题的反例。

## 3. 真 \(K_k\) 势的漂移，以及与质量窗的准确相容范围

在同一父 \(A\) 下追加 \(\pi_A\) 样本，定义
\[
 F_k(A,Y)=m_A^{k-1}K_k(Y),\qquad
 p_{BA}=\frac{\mu(Q_B\cap Q_A)}{m_B}.
\]
即便原 \(y,z\) 是按原接受流选定而非 iid，后续一步仍准确满足
\[
 \begin{split}
 F_k-\mathbb E[F_{k+1}\mid A,Y]
 &=m_A^{k-1}\int_E \frac{\sigma(dB)}{m_B^k}
       c_B(Y)(1-p_{BA})\\
 &=:\mathcal D_k(A,Y)\ge0.                                \tag{7}
 \end{split}
\]
原因是 \((m_A/m_B)p_{AB}=p_{BA}\)；没有新父历史。
所有量非负且 \(m_A\ge qa^n>0\)，故任意有限 \(N\)：
\[
 \sum_{k=2}^N\int\mathcal D_k\,dP_k
 =\int F_2\,dP-\int F_{N+1}\,dP_{N+1}.                    \tag{8}
\]
这里 \(P_k\) 是同一原 \(P\) 的样本扩充。

这是一个有方向的真实质量漂移：在 \(m_B\ge c\,m_A\)、\(c>1\) 上，
\(1-p_{BA}\ge1-1/c\)，从而该上行父部分的 \(F_k\) 占用受
\(\mathcal D_k/(1-1/c)\) 支配。另一方面，若 \(A\)-good 且 \(B\) 捕获同一 hull，
则 \(m_B\ge M\ge(1-\delta)m_A\)、\(p_{AB}\ge1-\delta\)。
**这不意味着** \(B\)-good，也不意味着 (7) 的反向 \(p_{BA}\) 接近1。

所以上行漂移和共同 hull 可以把候选 \(B\) 聚焦到
\([(1-\delta)m_A,c\,m_A]\)，但保同一势时仍有
\((m_A/m_B)^{k-1}\le(1-\delta)^{-(k-1)}\)。
若改用 \(M(Y)^{k-1}K_k(Y)\) 消除此比值，下一步 \(M\) 增长产生正恢复项，
(7) 就不再是其超鞅公式。具体令 \(M_k=\mu(H(Y_k))\)、\(\widehat F_k=M_k^{k-1}K_k\)，则
\[
 \widehat F_k-\mathbb E[\widehat F_{k+1}\mid A,Y_k]
 =M_k^{k-1}\int\frac{\sigma(dB)c_B(Y_k)}{m_B^k}
       \left[1-\frac{M_k}{m_A}p_{BA}\right]
 -\mathbb E[(M_{k+1}^{k}-M_k^{k})K_{k+1}\mid A,Y_k].       \tag{10}
\]
最后的非负量以负号出现，正是尚未支付的归一恢复项；不能同时免费使用两种正常化。

当前可付的初值仅为
\[
 \int F_2\,dP
 \le S\int\sigma(dB)\int R_A^{-n}p_{BA}^2\,dA
 \le S A_nX,\qquad A_n=1+n\log(b/a).                      \tag{9}
\]
最后用 \(p_{BA}^2\le p_{BA}\) 及真实来源点中心包络。
这是 \(X\) 价格，不是 \(W\)；原 \(T_G,T_{\rm loc}\) 低门仍保留在左侧，
这里没有证明它们足以改善该初值，也没有把 (8) 的负终值丢掉后称为新付款。

**本次决策。** (2)–(4) 给出合法的概率质量压缩，(7)–(8) 给出同原记录、
实际 \(K_k\) 的有向耗散。尚缺的具体比较是：保原接受权后，用 (8) 的负终值
或真实 hull 增长结算 (9) 的初值，使费用由 \(A_nX\) 转成允许的
\(\eta X+O_\eta(\sqrt n\,\mathrm{polylog}\,n)W\)；
不能以 (5) 的逐 hull 常数容量或两种正常化交替替代这一比较。
本稿没有完成原全余目标。

## 4. 实际有限检查

已用指定 Python 实际运行以下检查：36 项 Fraction 与 6 项 Arb 断言，共 42 项通过。Fraction 核验条件样本的 missing-mass 与 Markov 分割；
Arb 160 位仅检查 (6) 在三组有限参数的正值及 \(k(k-1)\) 缩放。
它们不是实际高维匹配场或原历史认证，解析证明独立于数值。

~~~python
from fractions import Fraction as F
from collections import defaultdict
from flint import arb,ctx
ctx.prec=160
checks=0
models=[
 ([(F(0),),(F(1,2),),(F(1),)],[F(1,4),F(1,2),F(1,4)]),
 ([(F(0),F(0)),(F(1),F(1)),(F(0),F(1))],
  [F(1,2),F(1,4),F(1,4)]),
 ([(F(0),F(0),F(0)),(F(1),F(0),F(0)),
   (F(0),F(1),F(0)),(F(0),F(0),F(1))],[F(1,4)]*4)
]
for phase,(pts,ws) in enumerate(models,1):
    n=len(pts[0]);local=0
    states={(x,x):w for x,w in zip(pts,ws)}
    for r in range(1,5):
        missing=F(0);bad=F(0)
        for (lo,hi),p in states.items():
            mass=sum(w for x,w in zip(pts,ws)
                     if all(lo[i]<=x[i]<=hi[i] for i in range(n)))
            missing+=p*(1-mass)
            if mass<F(1,2):bad+=p
        assert 0<=missing<=min(F(1),F(2*n,r+1))
        assert bad<=2*missing
        assert bad<=min(F(1),F(4*n,r+1))
        checks+=3;local+=3
        nxt=defaultdict(F)
        for (lo,hi),p in states.items():
            for x,w in zip(pts,ws):
                key=(tuple(min(lo[i],x[i]) for i in range(n)),
                     tuple(max(hi[i],x[i]) for i in range(n)))
                nxt[key]+=p*w
        states=nxt
    print("phase",phase,"PASS",local)
base=arb(4).log()-arb(3)/8 # c=1/8,d=1/2
for k in [2,8,32]:
    q=arb(k*(k-1))*base
    assert q.lower()>0
    assert (q/(k*(k-1))-base).contains(0)
    checks+=2
print("total PASS",checks,"36 Fraction + 6 Arb assertions; no native-history claim")
~~~
