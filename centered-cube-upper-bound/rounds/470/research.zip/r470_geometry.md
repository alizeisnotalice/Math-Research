# R470：同一真实父采样的跨父支持损失及未付上行项

**范围。** 记 \(\mu=f\,dx\)、\(m_A=\mu(Q_A)=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(r=\lambda/q\)、\(a\le R_A\le b\le2a\)、\(\sigma=q_A\,dA\)、\(A_n=1+n\log(b/a)\)。同一原流 \(P\) 的父边缘为 \(\nu\le S\sigma\)，\(R=|P|\le SX\)、\(X=\int\sigma\le A_nW\)。所有原接受和历史保留在 \(P\) 中；以下辅助测试父 \(B\) 无原历史。

本轮检验一个联合势：在给定原记录及父 \(A\) 后附 iid 样本 \(Y_j\sim\pi_A\)，用它们共同捕获的**实际中心**容量
\[
 V_k(Y)=\int_E R_B^{-n}\prod_{j=1}^k c_B(Y_j)\,dB,
 \qquad k\ge1.
\]
\(V_k\) 递减且 \(0\le V_k\le A_n\)。采样不改 \(P\)，也不把 \(\pi_A\) 换成固定来源律。记 \(I_{AB}=\mu(Q_A\cap Q_B)\)、\(p_{AB}=I_{AB}/m_A\)。Tonelli 给准确全积分
\[
 \mathcal L_k:=\int\mathbb E[V_k-V_{k+1}\mid A]\,d\nu(A)
 =\int\nu(dA)\int_E R_B^{-n}p_{AB}^k(1-p_{AB})\,dB.\tag{1}
\]
这保留 \(m_A^{-k}\)，没有用新来源替换旧 \(y,z\) 或终端。

## 1. 一个可证的真实匹配比较

令 \(k\ge2\)、\(L\ge1\)，按测试父质量 \(m_B\le Lm_A\) 分出 \(\mathcal L_k^{\le L}\)。设 \(c_j=j^j/(j+1)^{j+1}\)、\(c_0=1\)。则
\[
 \boxed{\quad\mathcal L_k^{\le L}
 \le SrL c_{k-2}X\le SrL c_{k-2}A_nW.\quad}\tag{2}
\]
证明不需来源密度帽。由于 \(I_{AB}\le m_B\)，
\[
 p_{AB}^{k-1}(1-p_{AB})
 \le c_{k-2}p_{AB}\le c_{k-2}m_B/m_A.
\]
将 (1) 中一个 \(p_{AB}\) 展开为 \(\int\pi_A(dx)c_B(x)\)，并用 \(R_B^{-n}=q_B/m_B\)，相应内层不超过
\[
 \frac{\lambda c_{k-2}}{m_A}
 |\{B:x\in Q_B,\ m_B\le Lm_A\}|
 \le rL c_{k-2}.
\]
最后一步是原生中心 sublevel：上述中心必在以 \(x\) 为中心、边长 \((Lm_A/q)^{1/n}\) 的盒中。完整匹配与同一个实际选择器都保留；并不要求固定 \(R_B\)。再积分 \(\nu\le S\sigma\) 得 (2)。固定 \(L\)、\(k\asymp\sqrt n\) 时这是辅助支持损失的根阶来源预算。

## 2. 仍缺的唯一跨父几何收费

剩下的是测试父比原父重的真实通量
\[
 \mathcal L_k^{>L}=
 \int\nu(dA)\int_{m_B>Lm_A}
 R_B^{-n}\frac{I_{AB}^{k}(m_A-I_{AB})}{m_A^{k+1}}\,dB.\tag{3}
\]
这里 \(m_A-I_{AB}=\mu(Q_A\setminus Q_B)\) 是**实际漏捕来源质量**；不是边界体积。质量较大的测试父可以只漏掉原父很少来源，而这份来源可被多个测试父重复计费。现有一般界只有
\[
 \mathcal L_k^{>L}\le c_{k-1}A_nR,
\]
来自一个 \(p\) 展开与 \(D(x)\le A_n\)；它没有把 \(R\) 变成 \(W\)。

不能用对称化假取消 (3)。在 \(\nu\le S\sigma\) 的正上放后，两实际父的基础核确有
\[
 q_AR_B^{-n}p_{AB}=q_BR_A^{-n}p_{BA}
 =\frac{I_{AB}}{R_A^nR_B^n}.
\]
但后续权分别是 \(p_{AB}^{k-1}(1-p_{AB})\) 与
\(p_{BA}^{k-1}(1-p_{BA})\)，而
\(p_{BA}=(m_A/m_B)p_{AB}\)。上行项可在前者接近最大时仍令后者极小；恒等式不产生负信用。尤其不能把 \(B\) 当成具有 \(A\) 原历史的父。

要使该势形成完整收缩，必须联合证明：实际上行漏捕通量 (3) 的可求和共享来源价，及该势在原 low-common/high-rank 流上的有效下降或可付终值。当前只知
\(\sum_{k=1}^{N}\mathcal L_k=\int\mathbb E[V_1-V_{N+1}]d\nu\)，其端点仍至多 \(A_nR\)。故 (2) **不是原 \(P\) 的新付款，也不是固定比例恢复**。大量样本的 hull 覆盖原父多数质量时，测试父可仍比原父重得多；这恰落在 (3)，不能用同父窄质量窗删除。

**改成 actual-K 核确实得到超鞅，但尚未支付其初值。** 令
\[
 K_k(Y)=\int_E q_Bm_B^{-k}c_B(Y)\,dB,\qquad
 W_k^A(Y)=m_A^{k-1}K_k(Y).
\]
在原父 \(A\) 下条件采样，严格有
\[
 W_k^A-\mathbb E_A[W_{k+1}^A\mid Y]
 =\int R_B^{-n}(m_A/m_B)^{k-1}c_B(Y)(1-p_{BA})\,dB\ge0.\tag{4}
\]
这使用真实 \(I_{AB}\le m_B\)，不需换选择器。采样平均的损失为
\(\int\nu(dA)\int R_B^{-n}p_{AB}p_{BA}^{k-1}(1-p_{BA})dB\)。若 \(\nu=\sigma\)，交换两实际父后它恰等于 (1)；对实际 \(\nu\) 只能保留它或正上放到 \(S\sigma\)，不能把交换后的父赋原接受。

精确地，
\[
 \int\mathbb E_AW_k^A\,d\nu(A)
 =\int\mu^{\otimes k}(dY)D_Y^\nu K_k(Y),\quad
 D_Y^\nu=\int c_A(Y)m_A^{-1}\nu(dA)\le SA_n.\tag{5}
\]
故若另已证明实际 \(B\)-采样的坏 hull 质量至多
\(2nX/[\delta(k+1)]\)，(5) 直接继承的上界仍为
\(SA_n\,2nX/[\delta(k+1)]\)，而不是原坏率本身。好 hull 的窄质量窗核即使有
\(K_k^{\rm good}(Y)\le r(1-\delta)^{-1}\mu(H_Y)^{1-k}\)，还须共同积分 \(D_Y^\nu\mu(H_Y)^{1-k}\)。这里的同一中心拥挤不能删除。初值只有 \(\int\mathbb E W_1^A d\nu\le A_nR\)。

因此 (4) 给出合法的 actual-K 有符号结算，避免逐点比较时的质量比幂；但完整收费仍缺 **同一被接受中心负载 \(D_Y^\nu\) 与 hull 质量增长的联合来源预算**。这与 (3) 的上行漏捕是同一尝试的两种积分次序，不是新增已付支。本轮停止于此，不以超鞅存在或端点重写声明根阶闭合。

## 3. 本机核验：真实连续中心块，范围有限

下列自含 Fraction 程序在指定 Python 实际运行。每模型为一维完整非均匀 \(f\)：三个长度 \(1/50\) 的来源区间，中心 \(-83/100,0,83/100\)，质量为代码中的 \(M\)；三个真实接收中心块长度均 \(1/100\)，中心 \(-2/5,2/5,0\)，选定边长分别 \(1,9/5,9/5\)。整个块内捕获关系严格不变，故矩阵运算是连续中心积分的准确计算。\(q_A=m_A/R_A\)、band 比逐模型真实计算，均为单 octave。保留权 \(1,1/2,2/3\) 仅是 \(\nu\le\sigma\) 的有限测试，不认证原高维质量门或历史；本稿一般证明不依赖该测试。

```python
from fractions import Fraction as F
from itertools import product
from math import prod
models=[(1,1,8),(1,3,9),(2,1,12)]
B=[(1,1,0),(0,1,1),(1,1,1)]
side=[F(1),F(9,5),F(9,5)]
volume=F(1,100); retain=[F(1),F(1,2),F(2,3)]
checks=0
for phase,M0 in enumerate(models,1):
    M=list(map(F,M0))
    mass=[sum(m*b for m,b in zip(M,row)) for row in B]
    qA=[m/R for m,R in zip(mass,side)]
    ratio=max(qA)/min(qA)
    sigma=[q*volume for q in qA]
    nu=[w*t for w,t in zip(sigma,retain)]
    X=sum(sigma); local=0
    overlap=[[sum(M[j]*B[a][j]*B[b][j] for j in range(3))
              for b in range(3)] for a in range(3)]
    for a,b in product(range(3),repeat=2):
        lhs=qA[a]/side[b]*overlap[a][b]/mass[a]
        rhs=qA[b]/side[a]*overlap[a][b]/mass[b]
        assert lhs==rhs;local+=1
    def EV(a,k):
        out=F(0)
        for word in product(range(3),repeat=k):
            probability=prod(M[j]*B[a][j]/mass[a] for j in word)
            v=sum(volume/side[b]*prod(B[b][j] for j in word)
                  for b in range(3))
            out+=probability*v
        return out
    for k in (2,3,4):
        direct=sum(nu[a]*(EV(a,k)-EV(a,k+1)) for a in range(3))
        pair=F(0);near=F(0)
        for a,b in product(range(3),repeat=2):
            p=overlap[a][b]/mass[a]
            term=nu[a]*volume/side[b]*p**k*(1-p)
            pair+=term
            if mass[b]<=2*mass[a]:near+=term
        assert direct==pair;local+=1
        c=F(1) if k==2 else F(k-2)**(k-2)/F(k-1)**(k-1)
        assert near<=2*ratio*c*X;local+=1
        assert pair-near>=0;local+=1
        forward=F(0);reverse=F(0)
        for a in range(3):
            wk=F(0);wk1=F(0);loss=F(0)
            for b in range(3):
                p=overlap[a][b]/mass[a]
                pback=overlap[a][b]/mass[b]
                weight=volume/side[b]
                wk+=weight*p*pback**(k-1)
                wk1+=weight*p*pback**k
                loss+=weight*p*pback**(k-1)*(1-pback)
                forward+=sigma[a]*weight*p**k*(1-p)
                reverse+=sigma[a]*weight*p*pback**(k-1)*(1-pback)
            assert wk-wk1==loss;local+=1
            assert loss>=0;local+=1
        assert forward==reverse;local+=1
    checks+=local
    print('phase',phase,'PASS',local,'qband ratio',ratio)
print('total PASS',checks,'native-block Fraction assertions; no original-history claim')
```

实际 stdout：

```text
phase 1 PASS 39 qband ratio 25/9
phase 2 PASS 39 qband ratio 65/36
phase 3 PASS 39 qband ratio 25/9
total PASS 117 native-block Fraction assertions; no original-history claim
```
