from fractions import Fraction as F
from pathlib import Path
from itertools import product
import json,sys,platform,time
import sympy as s
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
ctx.prec=192;start=time.perf_counter();checks=0

def ck(z):
 global checks
 assert z
 checks+=1

def sf(q):return s.Rational(q.numerator,q.denominator) if isinstance(q,F) else s.Rational(q)
def logf(q):return s.expand_log(s.log(sf(q)),force=True)
def logarb(expr):
 expr=s.expand(expr);ans=arb(0)
 for term in s.Add.make_args(expr):
  coeff,rest=term.as_coeff_Mul()
  if rest==1:ans+=arb(int(coeff.p))/arb(int(coeff.q));continue
  ck(rest.func==s.log)
  value=s.Rational(rest.args[0]);aa=arb(int(value.p))/arb(int(value.q))
  ans+=(arb(int(coeff.p))/arb(int(coeff.q)))*aa.log()
 return ans
H=F(1,100);R=F(6,5)
inputs=[('initial_disjoint_equal',[0,1],[1,1],[0,1]),('pressure_nested_unequal',[0,1],[1,2],[F(1,2),0]),('expanded_three_shared',[0,1,2],[1,2,1],[F(1,2),F(3,2),1])]
models=[]
for name,sources,masses,parents in inputs:
 sources=list(map(F,sources));mass=list(map(F,masses));parents=list(map(F,parents));B=[];margin=[]
 for a in parents:
  br=[];mr=[]
  for x in sources:
   hi=abs(a-x)+2*H;lo=max(F(0),abs(a-x)-2*H)
   if hi<R/2:br.append(1);mr.append(R/2-hi)
   else:ck(lo>R/2);br.append(0);mr.append(lo-R/2)
  B.append(br);margin.append(mr)
 for cs in (sources,parents):
  for i,x in enumerate(cs):
   for y in cs[i+1:]:ck(abs(x-y)>2*H)
 J=len(parents);I=len(sources);v=[2*H]*J;tau=[vv/R for vv in v]
 m=[sum(mass[i]*B[j][i] for i in range(I)) for j in range(J)]
 q=[mm/R for mm in m];nu=[m[j]*tau[j] for j in range(J)];X=sum(nu);W=sum(mass)
 overlap=[[sum(mass[i]*B[a][i]*B[b][i] for i in range(I)) for b in range(J)] for a in range(J)]
 p=[[overlap[a][b]/m[a] for b in range(J)] for a in range(J)]
 for a in range(J):
  ck(nu[a]==q[a]*v[a]);ck(0<q[a])
  for b in range(J):
   ck(0<=p[a][b]<=1);ck(q[a]/R*p[a][b]==q[b]/R*p[b][a]);ck(nu[a]*tau[b]*p[a][b]==nu[b]*tau[a]*p[b][a])
 V=[sum(nu[a]*sum(tau[b]*p[a][b]**k for b in range(J)) for a in range(J)) for k in range(9)]
 dissip=[sum(nu[a]*sum(tau[b]*p[a][b]**k*(1-p[a][b]) for b in range(J)) for a in range(J)) for k in range(8)]
 for k in range(8):ck(dissip[k]==V[k]-V[k+1]);ck(dissip[k]>=0)
 for N in (1,2,4,8):ck(sum(dissip[:N])==V[0]-V[N]);ck(V[N]>0)
 for k in range(1,8):
  cprev=F(1) if k==1 else F((k-1)**(k-1),k**k)
  # Fixed outer A source-law bound applies at selected B centers (subset of all B).
  for a in range(J):ck(sum(tau[b]*p[a][b]**k*(1-p[a][b]) for b in range(J))<=cprev)
  ck(dissip[k]<=X*cprev)
 fixed_law=[sum(tau[b]*(m[b]/W)**k for b in range(J)) for k in range(9)]
 tuple_summaries=[];examples=[]
 for K in (1,2,3,4):
  probsum=F(0);Ev=F(0);ElogV=0;ElogC=0;KL=0;maxRN=F(0);maxTV=F(0);positive=0
  for ids in product(range(I),repeat=K):
   captured=[all(B[a][i] for i in ids) for a in range(J)]
   Vtuple=sum(tau[a] for a in range(J) if captured[a])
   C=sum(nu[a]/m[a]**K for a in range(J) if captured[a])
   if not C:ck(Vtuple==0);continue
   positive+=1;prod_mass=F(1)
   for i in ids:prod_mass*=mass[i]
   jointmass=prod_mass*C;probsum+=jointmass;Ev+=jointmass*Vtuple
   actual=[nu[a]/m[a]**K/C if captured[a] else F(0) for a in range(J)]
   volume=[tau[a]/Vtuple if captured[a] else F(0) for a in range(J)]
   ck(sum(actual)==sum(volume)==1)
   stateKL=0
   for a in range(J):
    if not captured[a]:continue
    RN=actual[a]/volume[a]
    ck(RN==Vtuple/(C*m[a]**(K-1)))
    if K==1:ck(RN==1)
    maxRN=max(maxRN,RN);stateKL+=sf(actual[a])*logf(RN)
   tv=sum(abs(x-y) for x,y in zip(actual,volume))/2;maxTV=max(maxTV,tv)
   KL+=sf(jointmass)*stateKL;ElogV+=sf(jointmass)*logf(Vtuple);ElogC+=sf(jointmass)*logf(C)
   if len(set(ids))==1 and K in (1,2,4):
    examples.append(dict(K=K,packet=ids[0],sample_tuple=ids,joint_mass=jointmass,Vtuple=Vtuple,C_K=C,actual_parent_posterior=actual,volume_parent_posterior=volume,TV=tv,KL=str(s.expand(stateKL))))
  ck(probsum==X);ck(Ev==V[K])
  masslog=sum(sf(nu[a])*logf(m[a]) for a in range(J))
  KL=s.expand(KL);identity=s.expand(ElogV-ElogC-(K-1)*masslog)
  ck(s.simplify(KL-identity)==0)
  if KL==0:KLball='0'
  else:
   kb=logarb(KL);ck(kb>0);KLball=str(kb)
  tuple_summaries.append(dict(K=K,positive_tuple_cells=positive,joint_total=probsum,E_nu_VK=Ev,normalized_E_VK=Ev/X,
   same_fixed_global_source_expected_VK=fixed_law[K],expected_KL_actual_vs_volume=str(KL),expected_KL_arb=KLball,
   max_RN=maxRN,max_TV=maxTV,full_identity='E log(VK)-E log(CK)-(K-1)*int nu log m'))
 ck(V[0]>0)
 models.append(dict(name=name,source_centers=sources,source_masses=mass,source_density=[z/(2*H) for z in mass],parent_centers=parents,
  source_halfwidth=H,center_halfwidth=H,parent_side=R,capture=B,geometry_margins=margin,
  full_parent_mass=m,q=q,nu_sigma=nu,tau_volume_weight=tau,W=W,X=X,p_AB=p,
  E_nu_VK=V,Hk=dissip,terminal_N8=V[8],sum_H0_to_H7=sum(dissip),fixed_global_source_VK=fixed_law,
  tuple_certificates=tuple_summaries,posterior_examples=examples,
  original_strict_K_gap='not satisfied/claimed; max mass ratio <=3<exp(2) for n=1',history='not modeled'))
ck(models[1]['full_parent_mass'][0]!=models[1]['full_parent_mass'][1])
out=dict(scope='Three exact continuous 1D wholecapture static fields; true positive-volume centers, full f, actual sigma/pi Bayes and volume dissipation; no original history/root payment',
 executable=sys.executable,python=platform.python_version(),sympy=s.__version__,arb_precision_bits=ctx.prec,checks=checks,models=models,
 identities=dict(VK='sum_B |cellB|/R_B product captures of K samples',
 Hk='int nu(dA) sum_B |cellB|/R_B p_AB^k(1-p_AB)',
 telescope='sum_k=0..N-1 Hk=E_nu V0-E_nu VN',
 balance='q_A R_B^-1 p_AB=q_B R_A^-1 p_BA as Lebesgue double-center densities',
 actual_posterior='nu_B m_B^-K capture / C_K = tau_B m_B^(1-K) capture / C_K',
 volume_posterior='tau_B capture/VK',RN='VK/(C_K m_B^(K-1))',
 fixed_law_scope='For fixed outer A, rho=pi_A is independent of testing B and volume-loss applies conditionally; changing A to a Bayes-updated parent requires the recorded RN'),
 compute_index=dict(status='complete',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r470_numeric.py',
 input='3 rational interval fields; N1/2/4/8 matrix identities, K1..4 exact continuous packet tuple integration',
 arithmetic='Fraction actual interval geometry and all integrations; SymPy exact log identities; Arb192 KL positivity',seconds=time.perf_counter()-start))
(ROOT/'r470_numeric.json').write_text(json.dumps(out,default=str,indent=2)+'\n')
print(sys.executable,'Python',platform.python_version(),'SymPy',s.__version__)
for z in models:
 print(z['name'],'m',z['full_parent_mass'],'X',z['X'],'V0',z['E_nu_VK'][0],'sumH',z['sum_H0_to_H7'],'VN8',z['terminal_N8'])
 for row in z['tuple_certificates']:print(' K',row['K'],'actualEV/X',row['normalized_E_VK'],'global fixed law',row['same_fixed_global_source_expected_VK'],'maxTV',row['max_TV'],'KL',row['expected_KL_arb'])
print('PASS',checks,'exact/interval assertions;',len(models),'continuous fields')
