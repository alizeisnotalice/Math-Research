# 第470轮：同父采样耗散、真实后验与质量窗的联合费用

## 目标及状态

目标仍是任意正L1输入的一般中心立方体弱型上界，完整原剩余量须满足 εX+Cε√n log^A(n+2)W。本轮沿第469轮的多来源全局几何方向，核算共同中心支持损失与真实后验之间的转换。得到准确的双父比较、实际核超鞅和无指数替换损失的hull质量窗；**没有得到完整剩余流的根阶预算**。以下不是把辅助损失或筛选子量当作原流。

沿用 μ=f dx、W=μ(R^n)、σ(dA)=q_A dA、m_A=q_A R_A^n、q≤q_A≤λ、r0=λ/q、a≤R_A≤b≤2a、X=σ(E)、A_n=1+n log(b/a)。实际原流P保全部旧来源、终端及history，其父边缘ν≤Sσ。所有新增样本只在同一原父条件下独立抽取，不改变旧记录。取完整π_A=μ|QA/m_A；若另改成终端外来源，则必须重新保留条件化费用，本轮不自动迁移。

## 1. 几何支持损失及双父匹配

附加k个新样本Y，定义
\[
 V_k(Y)=\int_E R_B^{-n}\prod_{j=1}^k1_{Q_B}(Y_j)\,dB,
 \qquad p_{AB}=\frac{\mu(Q_A\cap Q_B)}{m_A}.
\]
同一原父采样的平均损失准确为
\[
 H_k=\int\nu(dA)\int_E R_B^{-n}p_{AB}^k(1-p_{AB})\,dB.
\]
它非负，有限部分和等于初始势减终端势，不能删掉终端。固定A时π_A确实独立于测试父B，所以固定来源律计算可逐A使用；困难是对原父A的总量结算，不是声称这一步不合法。

真实匹配给双向恒等式
\[
 q_A R_B^{-n}p_{AB}=q_B R_A^{-n}p_{BA}
 =\frac{\mu(Q_A\cap Q_B)}{R_A^nR_B^n}.
\]
对任意L≥1、k≥2，附稿利用实际中心子水平集体积，证明
\[
 H_k^{\{m_B\le Lm_A\}}\le S r_0 L c_{k-2}X
 \le S r_0 L c_{k-2}A_nW,
 \qquad c_j=j^j/(j+1)^{j+1},\ c_0=1.
\]
固定L、k约√n时这项辅助损失确有根阶来源价。剩余m_B>Lm_A方向及如何由损失恢复原P均仍需证明；没有把小幅度的可付损失当作单位记录覆盖。

## 2. 实际核超鞅使分母费用显式

令
\[
 K_k(Y)=\int_E\sigma(dB)\prod_j1_{Q_B}(Y_j)/m_B,
 \qquad F_k(A,Y)=m_A^{k-1}K_k(Y),\quad k\ge1.
\]
Tonelli给∫K_{k+1}(Y,x)μ(dx)=K_k(Y)。给定同一实际父A及已有Y，真实采样计算得到
\[
 \mathbb E_A(F_{k+1}\mid Y)
 =\int R_B^{-n}(m_A/m_B)^{k-1}1_{Q_B}(Y)p_{BA}\,dB\le F_k.
\]
这是实际分母下的非负超鞅，不是几何上确界核的虚假归一。其平均损失含p_AB p_BA^{k-1}(1-p_BA)。当ν=σ时，由上式交换A,B，恰等于H_k；因此它提供合法接口，但不额外创造一次几何节省。ν≤Sσ时只能对非负费用作上放，不能借此把测试父B赋予原history。

更准确地，
\[
 \int\nu(dA)\mathbb E_AF_k
 =\int D_Y^\nu K_k(Y)\,d\mu^k(Y),\qquad
 D_Y^\nu=\int\nu(dA)1_{Q_A}(Y)/m_A\le SA_n.
\]
故一个在参考K_k μ^k下仅知≤ηX的坏样本事件，在此加权势中只能直接保证≤SA_nηX，不能免费继承ηX。这个因子必须纳入样本数及吸收账。

## 3. 同一hull质量窗与尚未支付的来源积分

固定原记录，r个新π_A样本的坐标包围盒记H_r。其漏质量满足
\[
 \mathbb E_A\pi_A(Q_A\setminus H_r)\le2n/(r+1).
\]
因而失败事件m_A>μ(H_r)/(1−δ)的原扩充质量≤2n|P|/[δ(r+1)]。加入旧y,z只会扩大hull，不增加该失败费。参考场σπ_A^k的全部k个来源均iid时，可用2n/[δ(k+1)]；原旧双来源固定后仅新增k−2个样本时，使用2n/[δ(k−1)]。这两个口径不可混用。

设同一来源串hull的质量M=μ(H)>0。只对捕获H且M≤m_B≤M/(1−δ)的实际父取核，直接保分母给
\[
 K_k^{\rm good}(Y)\le\frac{r_0}{1-\delta}M^{1-k}.
\]
证明使用q_B/m_B^k≤λ/M^k及实际捕获中心体积≤M/[q(1−δ)]；没有(1−δ)^{-k}的指数损失。但是必须支付完整来源积分∫M^{1-k}dμ^k，并保M≥(1−δ)qa^n及实际尺度/捕获限制。当前未给其所需的全局根阶上界。

H对原A为good，只推出所有捕获H的B满足p_AB≥1−δ，并不推出B同样good。将两条估计共同使用时，B的坏质量窗及D_Y^ν权必须一起保留。因此没有将两个分别成立的结论直接拼成全流闭合。

改变正常化不能省掉hull增长的恢复项。置M_k=μ(H(Y_k))及\(\widehat F_k=M_k^{k-1}K_k\)，同父下一步的精确漂移为
\[
\widehat F_k-\mathbb E_A\widehat F_{k+1}
=M_k^{k-1}\int \frac{\sigma(dB)c_B(Y_k)}{m_B^k}
 [1-(M_k/m_A)p_{BA}]
-\mathbb E_A[(M_{k+1}^k-M_k^k)K_{k+1}].
\]
最后的非负项带负号，是从实际父质量正常化改成hull质量正常化的真实代价。此式保同一来源串，明确指出下一步必须结算的量；不能同时享受窄质量窗和原超鞅，却省去此项。

## 4. 总账、验证及下一步

本轮使用math-n04-summable-error-entropy-descent技能中的有限望远镜与非负极限记账，未凭技能名称引入任何额外几何定理。初始势、终端势和posterior迁移费全部显式。原母账仍为
\[
 R_{433}\le[S\zeta+2S\varepsilon_0/(1+\sqrt n)+2S\delta_{\rm round}]X+|P|.
\]
本轮没有降低右端|P|；旧宽距离、低pe、初始、跳跃、删除及旧母倍率均保留。

数值附件使用真实正Lebesgue体积的中心区间及L1来源区间，核验支持损失、双向匹配、真实后验分母和有限望远镜。它不认证原全部严格质量路径与history，有限模型不替代一般证明。实际验证分为几何附件117项Fraction、互补附件42项（36 Fraction、6 Arb）、数值主脚本581项精确或区间断言，共740项断言。三类真实连续场及参数、命令、误差范围与复现记录随附件归档；这些不是740个独立模型。

下一步必须直接控制同一来源串的共享质量积分或其带原接受权的版本，并同时处理上行父质量；仅压窄单父质量窗、把坏事件换一个名字或累计更多局部损失都不能完成原目标。


## 主代理：正常化恢复项的独立有限代数检查

三个有原子的有限测度父捕获集合，保完整质量；k=2,3,4的173个条件来源串，以Fraction逐项验证恢复项等式、恢复量非负及实际核超鞅，共519项断言通过。这仅核验有限条件概率代数，不认证连续cube或原history。加上附件740项，本轮共1259项断言；不以断言数代表独立模型数。代码如下，可由Markdown提取运行，无额外输入。

```python
from fractions import Fraction as F
from itertools import product
mu=[F(1),F(2),F(1)]
rows=[{0,1},{1,2},{0,1,2}]
mass=[sum(mu[j] for j in row) for row in rows]
sigma=[F(1,3),F(1,5),F(1,4)]
def kernel(Y):
 return sum(w/m**len(Y) for w,m,row in zip(sigma,mass,rows) if set(Y)<=row)
def hullmass(Y):
 return sum(mu[min(Y):max(Y)+1])
checks=0;cases=0
for k in (2,3,4):
 local=0
 for a,row in enumerate(rows):
  for Y in product(sorted(row),repeat=k):
   M=hullmass(Y); K=kernel(Y); nxt=F(0); recovery=F(0); frozen=F(0)
   for x in row:
    prob=mu[x]/mass[a];Ky=kernel(Y+(x,));My=hullmass(Y+(x,))
    nxt+=prob*My**k*Ky
    recovery+=prob*(My**k-M**k)*Ky
    frozen+=prob*mass[a]**k*Ky
   first=F(0)
   for b,rb in enumerate(rows):
    if not set(Y)<=rb:continue
    pba=sum(mu[x] for x in row&rb)/mass[b]
    first+=M**(k-1)*sigma[b]/mass[b]**k*(1-M/mass[a]*pba)
   assert M**(k-1)*K-nxt==first-recovery
   assert recovery>=0
   assert mass[a]**(k-1)*K>=frozen
   checks+=3;cases+=1;local+=3
 print('k',k,'PASS',local)
print('PASS',checks,'Fraction assertions;',cases,'finite atomic conditioning cases; no continuous/history claim')
```

实际输出：
```text
k 2 PASS 51
k 3 PASS 129
k 4 PASS 339
PASS 519 Fraction assertions; 173 finite atomic conditioning cases; no continuous/history claim
```
