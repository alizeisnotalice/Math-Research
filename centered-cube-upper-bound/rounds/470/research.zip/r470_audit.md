# R470 FINAL PASS（限定支持损失、真实核漂移及质量窗接口）

已先完成独立 PRE，再读本轮作者稿。通过下述有限列举结果及其数值复现；不认证完整原流 (P) 的根阶预算、有效下降比例或一般弱型闭合。原母账保留 (|P|)，没有重复记原已付费用或新父 history。本轮 PRE 的64项辅助断言不计入740项归档核验；PRE式(4)漏写的加号已修，PRE不归档。

1. **同父支持损失与真实中心容量。** (mathcal L_k) 是原父条件 iid 样本的准确平均势差；有限望远镜保终端。对 (m_B\le Lm_A)，(p^{k-1}(1-p)\le c_{k-2}p\le c_{k-2}m_B/m_A)，再展开一个 (p)，真实中心 sublevel 体积 (Lm_A/q) 给 (Sr_0Lc_{k-2}X)。变量 selector、完整来源质量、(k=2) 的 (c_0=1) 及方向都正确。上行质量通量并未被对称基础核取消，辅助损失没有被当成单位记录覆盖。

2. **actual (K_k) 的分母与接受权。** Tonelli 一致性成立；原父下一采样给 (F_k=m_A^{k-1}K_k) 的非负漂移，原因是 ((m_A/m_B)p_{AB}=p_{BA}\le1)。全部 (k) 点在父下 iid 时，全 (sigma) 平均交换两父恰等原支持损失。原旧 (y,z) 固定时，一步条件漂移仍成立，但不据此把它们说成 iid 或交换接受/history。来源重排保 (D_Y^\nu\le SA_n)，坏事件价格不能免费删除该权。

3. **hull 窗及正常化恢复。** missing-mass 的交换对称/并集界不要求坐标独立，旧点只扩 hull；原新样本 (r=k-2) 的失败分母为 (r+1=k-1)，参考全部 iid 时才是 (k+1)。good 核保 (m_B\ge M>0) 及中心容量 (M/[q(1-\delta)])，故常数只 (r_0/(1-\delta))，没有指数替换费。全来源逆 hull 质量矩、(m_0) 截断和捕获限制仍未付；一维临界矩公式正确。改变为 (M_k^{k-1}K_k) 时，式(10)的 (M_{k+1}^k-M_k^k\ge0) 项必须带负号，现稿保留。初值 (SA_nX) 只是 (X) 价。原两种样本口径未被混用，质量窗未被误当全流恢复。

4. **数值范围。** geometry 的连续正体积中心块与非等完整来源质量给准确有限积分；numeric 的同父样本与 global iid 不同，实际 Bayes/体积后验的 RN 与 KL 身份保全部质量分母。三类场未过原 strict-(K^2) 门，原阶段/history也未认证；这在正文明确，无外推。

主稿新增恢复项代码的173个有限有原子条件串逐项核验式(10)、恢复量非负与原父质量正常化超鞅，共519项断言，范围为有限测度代数，未用作连续cube或原历史认证。

## 独立隔离复现

指定本机 Python，目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r470_audit_oo51uafy`。提取 geometry/complement 内嵌代码及运行 numeric.py，117+42+581项断言全部通过；随后独立运行主稿恢复项代码519项，合计1259项；四份 stdout 与冻结 replay 逐字节相同。numeric JSON 只删除 `compute_index.seconds` 后完全一致，规范化 SHA256 为 `1170a809bcdd03c874c95f4bd4849f0cfc4478ad8c2f67e2e3a58aaff9a9bdef`。这些是所列有限几何/概率/区间断言，不是1259个独立原历史实例。

## 冻结输入 SHA256

- `r470_main.md`: `00fe8444ad63aff98287772a60153e68de274f83ae5cd2e9b10e23e6d12f03f6`
- `r470_geometry.md`: `dc1e5f6a27611de232b71d2c18fa7fdc4b8b7097eb13e575a24df84b92faa519`
- `r470_complement.md`: `380625e6f441d6e1ea2d94f68c5959ab3c405a068b810065f90323787e9370ea`
- `r470_numeric.md`: `602890b8f6a084945a73cad7acaa6f5b903c2931175d4554f520460ad68cd042`
- `r470_numeric.py`: `3aac9d62db42bcbc1189230392b2e6c7f87a1e2de8a2fcd4f4f8b1ac756e7402`
- `r470_numeric.json`: `6b1c13dd6c2a7262583f1ad3696a26361d58f6a65547c3d3fc3ecf4015f6b2cc`
- `r470_replay.json`: `22169c797f2ca4847693a94cc4e2cc44ff27b332facb3f9cd2161898949dfd33`
