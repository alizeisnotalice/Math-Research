# R470：真实连续父场中的多样本体积耗散与后验归一

3个真实1D场的全积分关系精确成立。固定外父A后，π_A独立于测试父B，固定source-law体积界可条件应用；但不能把条件iid π_A替换成global iid law，也不能在更新父后验后删除质量分母。耗散保非零终端，未证明它可支付原父费用。

## 模型与资格

source为半宽1/100的正体积packets，分块常f；receiver centerblocks半宽1/100，全部side R=6/5。最大captured距离≤13/25<3/5，miss距离≥49/50>3/5，整块捕获恒定，质量均由完整f积分。中心块之间不交、source包之间不交，跨域允许相交。

| 阶段 | source中心/质量 | 父center | 完整父质量m | X=σ(E) |
|---|---|---|---|---|
| 初步互斥 | (0,1)/(1,1) | 0,1 | 1,1 | 1/30 |
| 嵌套压力 | (0,1)/(1,2) | 1/2,0 | 3,1 | 1/15 |
| 扩大共享core | (0,1,2)/(1,2,1) | 1/2,3/2,1 | 3,3,2 | 2/15 |

真实q_A=m_A/R，ν=σ=q_A dA；固定side给合法octave，qband比率≤3。来源密度分别为质量除以packet长度，f为真正L1。该场不是原P，原strict-K²质量比失败（最大比3<e²）、高rank/阶段/history均未认证。不能以此数值付原余量。

## 准确全积分

令τ_B=|cellB|/R=1/60、p_AB=μ(QA∩QB)/mA，

V_k(tuple)=Σ_B τ_B ∏_{j≤k}c_B(Y_j)，
H_k=Σ_Aν_AΣ_Bτ_B p_AB^k(1−p_AB)。

Y_j是给定同一实际父A后的iid π_A来源；连续packet内核恒定，按完整packet质量积分，非packet中心代理。检查双向Lebesgue密度

q_A R_B^-1 p_AB=q_B R_A^-1 p_BA，

以及ν_Aτ_B p_AB=ν_Bτ_A p_BA。对k=0..7和N=1,2,4,8，精确核

H_k=EνV_k−EνV_{k+1}，Σ_{k<N}H_k=EνV0−EνVN。

k=0的0^0按空样本capture=1处理；它是独立初始体积项，未误用c_{k−1}于k0。K=1..4另枚举全部source packet tuples，独立重构EνVK，和overlap矩阵相等。

| 场 | EνV0 | ΣH0..H7 | EνV8 |
|---|---:|---:|---:|
| 互斥 | 1/900 | 1/1800 | 1/1800 |
| 嵌套 | 1/450 | 82/98415 | 1367/984150 |
| 共享core | 1/150 | 1261/393660 | 6817/1968300 |

终端全为正。共享core还给H_k=(2/3)^k/900及EνV∞=1/300；不能把terminal设零。侧长固定时，逐A的固定ρ=π_A全center bound给H_k≤X c_{k−1}（k≥1）；selected E是全center的子集，R^-1与∫p_BdB=R相消。该条件使用合法，但没有将linear Vk耗散自动变成原log/接受流费用。

## 两种积分顺序与真实后验费用

固定global ρ=μ/W时，体积期望是Στ_B(m_B/W)^K。这不是same-parent conditional抽样的EνVK/X。等质量互斥场已显示：后者所有K≥1恒1/60，而global law为2^(1−K)/60。原因是所有样本共享同一latent父；不能把它们换成global iid，即使质量相等也不行。

actual来源tuple的Bayes分母C_K=Σ_Bν_B m_B^-K capture。因ν_B=m_Bτ_B，actual后验∝τ_B m_B^(1−K)capture；几何volume后验∝τ_B capture。因此逐tuple/父节点精确核

RN=V_K/(C_K m_B^(K−1))。

K1恰相同，K>1低质量倾斜真实存在。这里专取ν=σ；若换成原真实子密度，后验还含该子密度相对σ的权，不能凭本例把它置1。以全部tuple的实际未归一质量（总量X）求费用，核完整等式

E KL(actual posterior||volume posterior)
=E log VK−E log CK−(K−1)∫ν log m。

所有日志项均保留，非“新增样本免费更新父”。对非等m场K2..4，Arb192bit核费用严格正；不额外扫描其他熵模型。

| 场，K=4 | 实际平均KL费用（总权X，未除X） | 最大TV |
|---|---:|---:|
| 互斥等m | 0 | 0 |
| 嵌套非等m | .0093172778721541011… | 13/28 |
| 共享core | .0095893623295059165… | 38/129 |

嵌套共享tuple给actual后验(1/28,27/28)，volume后验(1/2,1/2)；共享core tuple给actual(8/43,8/43,27/43)，volume(1/3,1/3,1/3)。全积分/分母迁移身份可核，但未证明该KL可由ΣH付款；这是剩余连接。

## 运行、索引与冻结

实际581项exact/interval断言（包含geometry、归一和tuple逐节点检查），非581独立模型；仅3场、N1/2/4/8与K1..4。Fraction几何/全积分，SymPy精确log等式，Arb192bit费用正性；无随机/浮点solver。

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r470_numeric.py
```

Python3.12.14、SymPy1.14.0，wall约.23秒。JSON内共享compute_index列命令/输入/责任/状态及全部精确矩阵、posterior示例和身份；decimal、运行计时仅显示/元数据。脚本自含，输出自身目录。

冻结白名单：r470_numeric.py、r470_numeric.json、r470_numeric.md。先前plan.md不列归档。完成停止；原全局付款、stage/history均未认证。
