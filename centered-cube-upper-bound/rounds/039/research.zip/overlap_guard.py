"""Exact common-cube overlap, Gram, and orientation guards.

Stdlib only. Fraction handles geometry, rectangle partitions, Gram sums
and shell fees. Decimal 70/110 logs are stability guards, not directed
interval certificates. No fitted exponent or general weak-type proof.
"""
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from itertools import product
from math import isqrt, ceil
from pathlib import Path
import json


def dec(x):
    return D(x.numerator) / D(x.denominator)


def show(x):
    return format(x, '.17g')


def fraction_sqrt(x):
    p, q = isqrt(x.numerator), isqrt(x.denominator)
    assert p * p == x.numerator and q * q == x.denominator
    return F(p, q)


def overlap_volume(L, y, K, z):
    assert len(y) == len(z) and L > 0 and K > 0
    volume = F(1)
    for yi, zi in zip(y, z):
        width = max(F(0), min(yi + L / 2, zi + K / 2)
                    - max(yi - L / 2, zi - K / 2))
        volume *= width
    return volume


def H_squared(L, y, K, z):
    n = len(y)
    return overlap_volume(L, y, K, z) ** 2 / (L * K) ** n


def pair_guards():
    rows = []
    ns_by_stage = ((1, 2, 4), (8, 16, 32), (64, 128, 256))
    for stage, ns in enumerate(ns_by_stage, 1):
        for n in ns:
            origin = tuple(F(0) for _ in range(n))
            patterns = [
                ('equal_same_center', F(1), F(1), origin),
                ('mixed_same_center', F(1), F(9, 4), origin),
                ('equal_correlated_partial', F(1), F(1),
                 tuple(F(1 if j % 2 == 0 else -1, 3) for j in range(n))),
                ('mixed_correlated_partial', F(1), F(9, 4),
                 tuple(F(1 if j % 3 else -1) for j in range(n))),
                ('one_axis_partial', F(1), F(1),
                 tuple(F(1, 2) if j == 0 else F(0) for j in range(n))),
                ('one_axis_tangent', F(1), F(1),
                 tuple(F(1) if j == 0 else F(0) for j in range(n))),
                ('one_axis_disjoint', F(1), F(9, 4),
                 tuple(F(2) if j == 0 else F(0) for j in range(n)))
            ]
            for label, L, K, z in patterns:
                volume = overlap_volume(L, origin, K, z)
                h2 = H_squared(L, origin, K, z)
                cap2 = (min(L, K) / max(L, K)) ** n
                assert 0 <= h2 <= cap2 <= 1
                assert h2 == H_squared(K, z, L, origin)
                if label.endswith('same_center'):
                    assert h2 == cap2
                if label.endswith('tangent') or label.endswith('disjoint'):
                    assert h2 == 0
                rows.append(dict(stage=stage, n=n, case=label, L=str(L), K=str(K),
                                 y=[str(x) for x in origin], z=[str(x) for x in z],
                                 exact_overlap_volume=str(volume), exact_H_squared=str(h2),
                                 exact_scale_only_cap_squared=str(cap2)))
    return rows


def atom_fixture(stage, n):
    N = stage + 2
    atoms = []
    for j in range(N):
        point = tuple(F(((j * j + 3 * axis * j + 2 * axis) % 9) - 4, 3)
                      for axis in range(n))
        weight = F((j + 1) * (stage + 1), j + 2)
        atoms.append((point, weight))
    L, K = ((F(1), F(1)), (F(4, 9), F(1)), (F(1), F(9, 4)))[stage - 1]
    return L, K, atoms


def in_cube(x, center, L):
    return all(abs(xi - yi) <= L / 2 for xi, yi in zip(x, center))


def partition_case(stage, n):
    L, K, atoms = atom_fixture(stage, n)
    root_volume_L = fraction_sqrt(L ** n)
    root_volume_K = fraction_sqrt(K ** n)
    breaks = []
    for axis in range(n):
        breaks.append(sorted({p[axis] + sign * scale / 2
                              for p, _ in atoms for scale in (L, K)
                              for sign in (-1, 1)}))
    intervals = [list(zip(axis, axis[1:])) for axis in breaks]
    actual = F(0)
    integral_fL = F(0)
    integral_fK = F(0)
    cells = 0
    for rectangle in product(*intervals):
        midpoint = tuple((lo + hi) / 2 for lo, hi in rectangle)
        volume = F(1)
        for lo, hi in rectangle:
            assert hi > lo
            volume *= hi - lo
        # Separate sums and common physical receiver midpoint: correlated
        # source coordinates are retained, not replaced by marginal laws.
        fL = sum((w for p, w in atoms if in_cube(midpoint, p, L)), F(0)) / root_volume_L
        fK = sum((w for p, w in atoms if in_cube(midpoint, p, K)), F(0)) / root_volume_K
        actual += volume * fL * fK
        integral_fL += volume * fL
        integral_fK += volume * fK
        cells += 1
    kernel_sum = F(0)
    H_entries = []
    for y, wy in atoms:
        row = []
        for z, wz in atoms:
            overlap = overlap_volume(L, y, K, z)
            h = overlap / (root_volume_L * root_volume_K)
            assert h * h == H_squared(L, y, K, z)
            assert h * h <= (min(L, K) / max(L, K)) ** n
            kernel_sum += wy * wz * h
            row.append(str(h))
        H_entries.append(row)
    W = sum((w for _, w in atoms), F(0))
    assert actual == kernel_sum
    assert integral_fL == W * root_volume_L
    assert integral_fK == W * root_volume_K
    assert actual <= W * W * fraction_sqrt((min(L, K) / max(L, K)) ** n)
    return dict(stage=stage, n=n, atom_count=len(atoms), L=str(L), K=str(K),
                atoms=[dict(position=[str(x) for x in p], weight=str(w)) for p, w in atoms],
                exact_mass=str(W), axis_breakpoint_counts=[len(x) for x in breaks],
                rectangle_count=cells, exact_partition_integral=str(actual),
                exact_common_kernel_sum=str(kernel_sum),
                exact_integral_fL=str(integral_fL), exact_integral_fK=str(integral_fK),
                exact_partition_minus_kernel='0', H_matrix=H_entries,
                normalization='f_L(x)=sum_j weight_j*1_{Q(center_j,L)}(x)/sqrt(L^n)')


def partition_guards():
    return [partition_case(stage, n) for stage in (1, 2, 3) for n in (1, 2, 3)]


def bessel_guards():
    rows = []
    for a, delta_label in ((F(1, 2), 'log(4)'), (F(1, 4), 'log(16)'),
                           (F(3, 4), 'log(16/9)')):
        bound = (1 + a) / (1 - a)  # coth(delta/4)
        previous_rayleigh = None
        for N in (4, 16, 64):
            row_sums = [sum((a ** abs(i - j) for j in range(N)), F(0))
                        for i in range(N)]
            rayleigh = sum(row_sums, F(0)) / N
            independent_sum = (F(N) + 2 * sum((F(N - d) * a ** d
                                               for d in range(1, N)), F(0))) / N
            maximum_row = max(row_sums)
            assert rayleigh == independent_sum
            assert 0 < rayleigh <= maximum_row < bound
            if previous_rayleigh is not None:
                assert rayleigh > previous_rayleigh
            previous_rayleigh = rayleigh
            # Actual same-center one-dimensional cubes have length ratio
            # a^{-2}. Their Gram overlap is exactly a^{|i-j|}.
            origin = (F(0),)
            for distance in range(N):
                L, K = F(1), (1 / a) ** (2 * distance)
                assert H_squared(L, origin, K, origin) == a ** (2 * distance)
            rows.append(dict(N=N, exact_a=str(a), delta=delta_label,
                             exact_volume_ratio=str(1 / (a * a)),
                             exact_coth_delta_over_4=str(bound),
                             exact_ones_rayleigh=str(rayleigh),
                             exact_maximum_row_sum=str(maximum_row),
                             exact_rayleigh_deficiency=str(bound - rayleigh),
                             exact_Gershgorin_upper_bound=str(maximum_row),
                             row_sums=[str(x) for x in row_sums],
                             scope='positive Gram from actual nested same-center normalized cubes; operator norm bounded by maximum absolute row sum, no eigenvalue solver'))
    return rows


def reverse_shell_guards():
    rows = []
    for stage, (a, W) in enumerate(((F(1, 2), F(1)), (F(1, 4), F(3)),
                                   (F(3, 4), F(7))), 1):
        bessel = (1 + a) / (1 - a)
        for N in (4, 16, 64):
            volumes = [(1 / a) ** (2 * i) for i in range(N + 1)]
            shell_ratio = F(0)
            for i in range(1, N + 1):
                shell = volumes[i] - volumes[i - 1]
                assert shell / volumes[i] == 1 - a * a
                shell_ratio += W * shell / volumes[i]
            exact_ratio = W * N * (1 - a * a)
            assert shell_ratio == exact_ratio
            # Raw source-square response is W^2 times the shell sum. The
            # displayed ratio divides it by source mass W, not by W^2.
            raw_response = W * exact_ratio
            normalized_by_W_squared = exact_ratio / W
            assert raw_response == W * W * N * (1 - a * a)
            full_reverse_attainer_input = F(N)  # f_j=K_j(.,0), each norm 1.
            full_reverse_attainer_output = W * N * N
            assert full_reverse_attainer_output / full_reverse_attainer_input == W * N
            rows.append(dict(stage=stage, N=N, exact_a=str(a), exact_W=str(W),
                             exact_volume_ratio=str(1 / (a * a)),
                             exact_single_shell_fraction=str(1 - a * a),
                             exact_raw_source_square_response=str(raw_response),
                             exact_reverse_response_over_W=str(exact_ratio),
                             exact_reverse_response_over_W_squared=str(normalized_by_W_squared),
                             exact_forward_Bessel_constant=str(bessel),
                             exact_T_selector_norm_squared=str(exact_ratio),
                             exact_T_selector_attainer_input_norm_squared=str(W),
                             exact_T_selector_attainer_output_norm_squared=str(raw_response),
                             exact_full_reverse_R_norm_squared=str(W * N),
                             exact_full_reverse_R_attainer_input_norm_squared=str(full_reverse_attainer_input),
                             exact_full_reverse_R_attainer_output_norm_squared=str(full_reverse_attainer_output),
                             exact_forward_S_norm_squared_upper_bound=str(W * bessel),
                             T_selector_orientation='L2(mu) -> L2(dx), disjoint E_j=Q_j minus Q_(j-1), T g=sum_j 1_Ej integral K_j(x,y)g(y)mu(dy)',
                             T_selector_adjoint='L2(dx) -> L2(mu), T* f=sum_j integral K_j(x,y)1_Ej(x)f(x)dx',
                             full_reverse_R_orientation='ell2_j L2(dx) -> L2(mu), R f=sum_j integral K_j(x,y)f_j(x)dx, no disjoint restriction',
                             forward_S_orientation='ell2_j L2(mu) -> L2(dx), S g=sum_j integral K_j(x,y)g_j(y)mu(dy)',
                             normalized_reverse_exceeds_Bessel=normalized_by_W_squared > bessel,
                             scope='disjoint nested receiver shells with scale chosen by shell index; demonstrates reverse orientation cannot inherit a forward Bessel bound; no fixed-lambda weak-event conclusion'))
    assert any(x['normalized_reverse_exceeds_Bessel'] for x in rows)
    return rows


def fixed_lambda_clipped_shell_guards(precision):
    """Use one common true-winner lambda band within each shell family."""
    with localcontext() as ctx:
        ctx.prec = precision
        rows = []
        for stage, (a, W) in enumerate(((F(1, 2), F(1)), (F(1, 4), F(3)),
                                       (F(3, 4), F(7))), 1):
            for N in (4, 16, 64):
                volumes = [(1 / a) ** (2 * i) for i in range(N + 1)]
                for location, index in zip(('early', 'middle', 'late'),
                                           (N // 4, N // 2, 3 * N // 4)):
                    v_mid = volumes[index]
                    lam = W / (2 * v_mid)
                    lo, hi = W / (2 * lam), W / lam
                    assert lo == v_mid and hi == 2 * v_mid
                    total = F(0)
                    clipped_pieces = []
                    for j in range(1, N + 1):
                        left = max(volumes[j - 1], lo)
                        right = min(volumes[j], hi)
                        clipped = max(F(0), right - left)
                        total += clipped / volumes[j]
                        if clipped:
                            assert lo <= left < right <= hi
                            clipped_pieces.append(dict(shell_index=j,
                                                       exact_left_volume=str(left),
                                                       exact_right_volume=str(right),
                                                       exact_shell_assigned_volume=str(volumes[j]),
                                                       exact_clipped_volume=str(clipped),
                                                       exact_fee=str(clipped / volumes[j])))
                    finite_lo, finite_hi = max(volumes[0], lo), min(volumes[-1], hi)
                    ratio = finite_hi / finite_lo if finite_hi > finite_lo else F(1)
                    continuous_band_fee = dec(ratio).ln()
                    # On each clipped shell, 1/v_j <= 1/v. Full real atom
                    # winner uses v_entry=v, so its unrestricted band is
                    # integral_[W/(2lambda),W/lambda] dv/v=log(2).
                    assert 0 <= dec(total) <= continuous_band_fee <= D(2).ln()
                    assert 1 <= ratio <= 2
                    rows.append(dict(stage=stage, N=N, exact_a=str(a), exact_W=str(W),
                                     threshold_location=location, mid_index=index,
                                     exact_lambda=str(lam), exact_true_band_lower_volume=str(lo),
                                     exact_true_band_upper_volume=str(hi),
                                     exact_shell_assigned_band_fee=str(total),
                                     exact_T_selector_band_norm_squared=str(W * total),
                                     finite_true_winner_band_integral=show(continuous_band_fee),
                                     exact_exp_finite_true_winner_band_integral=str(ratio),
                                     unrestricted_true_winner_band_integral='log(2)',
                                     clipped_shells=clipped_pieces,
                                     band_convention='lambda < M <= 2lambda iff W/(2lambda) <= v_entry < W/lambda; boundaries have zero volume',
                                     scope='one fixed lambda within each case, using true atom M=W/v_entry; invalid reverse shells removed before summation'))
        return rows


def finite_band_reverse_Schur_case(stage, n):
    _, _, atoms = atom_fixture(stage, n)
    scales = (F(1), F(3, 2), F(2))
    c, C, lam, fiber_cap = F(1, 4), F(4), F(1), 2
    N = len(atoms)
    W = sum((w for _, w in atoms), F(0))
    breaks = [sorted({p[axis] + sign * L / 2 for p, _ in atoms
                      for L in scales for sign in (-1, 1)})
              for axis in range(n)]
    intervals = [list(zip(axis, axis[1:])) for axis in breaks]
    H = [[F(0) for _ in range(N)] for _ in range(N)]
    direct_rows = [F(0) for _ in range(N)]
    histogram = {0: 0, 1: 0, 2: 0}
    selected_counting_time_volume = F(0)
    cell_count = 0
    nonempty_cells = 0
    for rectangle in product(*intervals):
        x = tuple((lo + hi) / 2 for lo, hi in rectangle)
        volume = F(1)
        for lo, hi in rectangle:
            volume *= hi - lo
        memberships = [[in_cube(x, p, L) for p, _ in atoms] for L in scales]
        densities = [sum((w for (_, w), inside in zip(atoms, membership) if inside), F(0)) / L ** n
                     for L, membership in zip(scales, memberships)]
        selected = [t for t, density in enumerate(densities) if c * lam <= density <= C * lam][:fiber_cap]
        assert len(selected) <= fiber_cap
        histogram[len(selected)] += 1
        cell_count += 1
        if selected:
            nonempty_cells += 1
        selected_counting_time_volume += volume * len(selected)
        for t in selected:
            L = scales[t]
            density = densities[t]
            assert c * lam <= density <= C * lam
            # Positivity gives a common centered support cap for every
            # source row: L^n<=W/(c lambda) whenever this band is selected.
            assert L ** n <= W / (c * lam)
            members = [i for i, inside in enumerate(memberships[t]) if inside]
            for i in members:
                direct_rows[i] += volume * density
                for j in members:
                    H[i][j] += volume / L ** n
    weighted_rows = [sum((w * H[i][j] for j, (_, w) in enumerate(atoms)), F(0))
                     for i in range(N)]
    assert weighted_rows == direct_rows
    assert all(H[i][j] == H[j][i] >= 0 for i in range(N) for j in range(N))
    maximum_row = max(weighted_rows)
    bound = (C / c) * W * fiber_cap
    assert 0 < maximum_row <= bound and nonempty_cells > 0
    return dict(stage=stage, n=n, atom_count=N,
                atoms=[dict(position=[str(x) for x in p], weight=str(w)) for p, w in atoms],
                scales=[str(L) for L in scales], exact_c=str(c), exact_C=str(C),
                exact_lambda=str(lam), exact_W=str(W), counting_time_fiber_cap=fiber_cap,
                selector='earliest at most 2 scale indices with c*lambda <= A_L <= C*lambda',
                density_definition='A_L(x)=mu(Q(x,L))/L^n',
                rectangle_count=cell_count, nonempty_selected_cells=nonempty_cells,
                selected_count_histogram=histogram,
                exact_selected_counting_time_volume=str(selected_counting_time_volume),
                exact_H_matrix=[[str(x) for x in row] for row in H],
                exact_weighted_H_rows=[str(x) for x in weighted_rows],
                exact_direct_density_integral_rows=[str(x) for x in direct_rows],
                exact_maximum_weighted_row=str(maximum_row),
                exact_Schur_norm_squared_upper_bound=str(bound),
                operator_orientation='R_F:ell2(scale indices) L2(dx)->L2(mu)',
                scope='finite counting-time band kernel only; no continuous-time delta factor, eigenvalue solver or general weak-type proof')


def finite_band_reverse_Schur_guards():
    return [finite_band_reverse_Schur_case(stage, n)
            for stage in (1, 2, 3) for n in (1, 2, 3)]


def correlated_two_atom_guards():
    rows = []
    for stage, ns in enumerate(((1, 2, 4), (8, 16, 32), (64, 128, 256)), 1):
        for n in ns:
            y = tuple(F(0) for _ in range(n))
            z = tuple(F(1, 2) for _ in range(n))
            L = F(1)
            cross = overlap_volume(L, y, L, z) / L ** n
            common_affinity = F(1, 4) + F(1, 4) + F(1, 2) * cross
            assert cross == F(1, 2) ** n
            assert common_affinity == F(1, 2) + F(1, 2) * F(1, 2) ** n
            false_independent_affinity = F(3, 4) ** n
            gap = common_affinity - false_independent_affinity
            assert (gap == 0 if n == 1 else gap > 0)
            rows.append(dict(stage=stage, n=n, L='1',
                             actual_source='(1/2)delta_(0,...,0)+(1/2)delta_(1/2,...,1/2)',
                             exact_common_cross_cube_affinity=str(cross),
                             exact_source_average_kernel_overlap=str(common_affinity),
                             quantity_definition="double integral of normalized cube-kernel L2 overlap against rho times rho; not the Hellinger affinity of the mixed density with itself",
                             exact_false_coordinate_product=str(false_independent_affinity),
                             exact_gap=str(gap),
                             scope='common two-atom source retains one shared mixture label across all coordinates; independent coordinate mixture is a different source'))
    return rows


def mixed_mass_guards(precision):
    """Analytic family formulas; the exponential number of atoms is not built."""
    with localcontext() as ctx:
        ctx.prec = precision
        rows = []
        for stage, n in enumerate((512, 2048, 8192), 1):
            h = D(2).ln()
            T = D(n) * h
            m = ceil(T.sqrt())
            d = T / m
            # (T-d)/(2*log(2))=n*(m-1)/(2m), so the count exponent
            # floor is exact rational arithmetic, not a huge floating exp.
            pre_floor = F(n * (m - 1), 2 * m)
            count_power = pre_floor.numerator // pre_floor.denominator
            N = 2 ** count_power
            logN = D(count_power) * h
            log_count_envelope = (T - d) / 2
            assert logN <= log_count_envelope < logN + h
            wS = D(2)
            log_wB = T - d - 2 * h
            wB = 2 * (T - d - 3 * h).exp()
            assert abs(wB / log_wB.exp() - 1) < D('1e-50')
            small_total = D(N) * wS
            W = wB + small_total
            log_small_total_over_big = (D(count_power + 1) * h) - log_wB
            small_total_over_big = log_small_total_over_big.exp()
            assert log_small_total_over_big <= 0
            assert 0 < small_total_over_big <= 1
            assert wB <= W <= 2 * wB
            assert m >= 16 and 3 * h < 2 * d
            small_tau = (D(0), h)
            big_tau = (T - d - 3 * h, T - d - 2 * h)
            assert 0 <= big_tau[0] < big_tau[1] <= T
            for lo, hi in (small_tau, big_tau):
                assert 0 <= lo < hi <= T - d
                assert hi + h <= T
            # Every atom has weight in [a^n,b^n], a=lambda=1,b=2.
            # Therefore the entire fixed-lambda level set fits the window.
            assert log_wB >= 0 and log_wB <= T
            assert 1 <= wS <= T.exp()
            # Centers y_i=(3*b*i,0,...) have distance >=3b>b. Hence
            # no cube L<=b sees two atoms, and all off-diagonal entries vanish.
            b = F(2)
            separation = 3 * b
            assert separation > b
            # For v_entry in [w_i/2,w_i], and time from entry to entry+h,
            # integral dv integral_0^h exp(-s)/v ds = log(2)*(1-1/2).
            exact_decay_fraction = F(1, 2)
            source_Gram_diagonal = h * dec(exact_decay_fraction)
            Gamma_big = wB * source_Gram_diagonal
            Gamma_small = wS * source_Gram_diagonal
            Gamma = Gamma_big
            V_i = source_Gram_diagonal
            V = D(N + 1) * V_i
            global_product_over_W = Gamma * V / W
            global_lower = h * h * D(N + 1) / 8
            assert global_product_over_W >= global_lower
            matched = Gamma_big * V_i + D(N) * Gamma_small * V_i
            matched_closed = W * h * h / 4
            assert abs(matched / matched_closed - 1) < D('1e-50')
            assert abs(matched / W - h * h / 4) < D('1e-50')
            band_volume = W / 2
            whole_window_level_volume = W
            assert abs(band_volume / W - D('0.5')) < D('1e-50')
            assert whole_window_level_volume / W == 1
            rows.append(dict(stage=stage, n=n, a='1', b='2', lambda_value='1',
                             T=show(T), m=m, d=show(d), h=show(h),
                             w_small='2', w_big_closed='2*exp(T-d-3*h)',
                             w_big=show(wB), total_mass_W=show(W),
                             exact_count_pre_floor=str(pre_floor), exact_count_power=count_power,
                             exact_N=str(N), log_N=show(logN),
                             N_definition='2^floor((T-d)/(2*log(2)))',
                             N_envelope='N <= exp((T-d)/2) < 2*N',
                             log_small_total_over_big=show(log_small_total_over_big),
                             small_total_over_big=show(small_total_over_big),
                             total_mass_bound='W=w_big+2*N <= 2*w_big',
                             center_family='y_i=(3*b*i,0,...,0); one big atom and N small atoms',
                             exact_nearest_center_separation=str(separation),
                             small_entry_time_band=[show(x) for x in small_tau],
                             big_entry_time_band=[show(x) for x in big_tau],
                             source_Gram_diagonal_closed='h/2', source_Gram_diagonal=show(source_Gram_diagonal),
                             source_Gram_off_diagonal='0, because no L<=b cube can contain two centers',
                             Gamma_closed='w_big*h/2', Gamma=show(Gamma),
                             V_closed='(N+1)*h/2', V=show(V),
                             global_Gamma_V_over_W=show(global_product_over_W),
                             global_Gamma_V_over_W_lower_closed='h^2*(N+1)/8',
                             global_Gamma_V_over_W_lower=show(global_lower),
                             matched_sum_closed='sum_i Gamma_i*V_i = W*h^2/4',
                             matched_sum=show(matched), matched_sum_over_W=show(matched / W),
                             normalized_true_lambda_to_2lambda_band_fee='1/2',
                             normalized_whole_window_lambda_level_fee='1',
                             scope='analytic separated finite-atom family parameter guard; no atom enumeration. Whole-window fee means a<=L<=b, not all scales. Contrasts global and matched budgets, not an operator upper-bound closure.'))
        return rows


def same_atom_band_guards(precision):
    with localcontext() as ctx:
        ctx.prec = precision
        rows = []
        for stage, (W, ns) in enumerate(((F(1), (1, 2, 3)),
                                        (F(3), (4, 8, 16)),
                                        (F(7), (32, 64, 128))), 1):
            lam = W / 4
            a, b = F(1), F(4)
            for n in ns:
                for entry in (F(0), F(3, 2), F(4), F(5)):
                    # A real receiver has first coordinate entry/2. Its
                    # other correlated coordinates have smaller norm.
                    receiver = tuple(entry / 2 if j == 0 else
                                     entry / 2 * F((-1) ** j, 2)
                                     for j in range(n))
                    actual_entry = 2 * max(abs(x) for x in receiver)
                    assert actual_entry == entry
                    occupied_start_volume = max(a ** n, entry ** n, W / (2 * lam))
                    occupied_end_volume = min(b ** n, W / lam)
                    exact_exp_time = (occupied_end_volume / occupied_start_volume
                                      if occupied_end_volume > occupied_start_volume else F(1))
                    assert 1 <= exact_exp_time <= 2
                    time = dec(exact_exp_time).ln()
                    assert 0 <= time <= D(2).ln()
                    if entry == 0:
                        assert exact_exp_time == 2
                    winner_scale = max(a, entry)
                    max_density = W / winner_scale ** n if entry <= b else F(0)
                    qualifies = max_density > lam
                    if not qualifies:
                        assert exact_exp_time == 1
                    rows.append(dict(stage=stage, n=n, W=str(W), lambda_value=str(lam),
                                     a=str(a), b=str(b), entry_scale=str(entry),
                                     receiver=[str(x) for x in receiver],
                                     exact_window_max_density=str(max_density),
                                     true_lambda_receiver=qualifies,
                                     true_maximum_in_lambda_to_2lambda_band=lam < max_density <= 2 * lam,
                                     exact_band_start_volume=str(occupied_start_volume),
                                     exact_band_end_volume=str(occupied_end_volume),
                                     exact_exp_occupied_time=str(exact_exp_time),
                                     occupied_time=show(time), occupied_time_upper='log(2)',
                                     band_convention='lambda < W/L^n <= 2lambda after source entry; equality-only endpoints have zero time',
                                     scope='true continuous single-atom cube maxima in a finite scale window; outside/low-density shells excluded from this fixed-lambda band'))
        return rows


def precision_compare(x, y, path='root'):
    if isinstance(x, dict):
        assert x.keys() == y.keys()
        for key in x:
            precision_compare(x[key], y[key], path + '.' + key)
    elif isinstance(x, list):
        assert len(x) == len(y)
        for j, (a, b) in enumerate(zip(x, y)):
            precision_compare(a, b, path + f'[{j}]')
    elif x == y:
        return
    else:
        assert isinstance(x, str) and isinstance(y, str), (path, x, y)
        with localcontext() as ctx:
            ctx.prec = 110
            a, b = D(x), D(y)
            norm = max(abs(a), abs(b))
            assert (a == b if norm == 0 else abs(a - b) <= norm * D('1e-15')), (path, x, y)


def main():
    band70 = same_atom_band_guards(70)
    band110 = same_atom_band_guards(110)
    precision_compare(band70, band110)
    clipped70 = fixed_lambda_clipped_shell_guards(70)
    clipped110 = fixed_lambda_clipped_shell_guards(110)
    precision_compare(clipped70, clipped110)
    mixed70 = mixed_mass_guards(70)
    mixed110 = mixed_mass_guards(110)
    precision_compare(mixed70, mixed110)
    suites = dict(common_cube_pairs=pair_guards(),
                  atomic_rectangle_partitions=partition_guards(),
                  discrete_Gram=bessel_guards(),
                  reverse_receiver_shells=reverse_shell_guards(),
                  single_atom_fixed_lambda_clipped_shells=clipped110,
                  finite_band_reverse_Schur=finite_band_reverse_Schur_guards(),
                  correlated_two_atom=correlated_two_atom_guards(),
                  mixed_mass_separated_family=mixed110,
                  single_atom_fixed_lambda_band=band110)
    counts = {key: len(value) for key, value in suites.items()}
    assert list(counts.values()) == [63, 9, 9, 9, 27, 9, 9, 3, 36]
    result = dict(status='PASS finite common-cube overlap guards',
                  counts=counts, log_precisions=[70, 110],
                  precision_comparison='relative 1e-15 on 17-digit presentations; exact fields unchanged',
                  scope=[
                      'No random sampling, eigenvalue solver, fitted exponent, or general upper-bound closure.',
                      'H is the L2 overlap of two normalized cube kernels at one common physical receiver space; H^2 and its scale-only upper bound use Fraction.',
                      'Atomic partition cases use arbitrary positive rational weights and correlated coordinates, with perfect-square side lengths so H itself and f_L*f_K integrals are rational.',
                      'All receiver rectangles formed by all source cube boundaries are integrated exactly; boundaries have zero Lebesgue measure.',
                      'Forward discrete Gram norm bounds apply to nested same-center normalized cubes; reverse shell fees are a different orientation.',
                      'Reverse response divided by W equals W*N*(1-a^2), while dividing by W^2 equals N*(1-a^2); both normalizations are recorded.',
                      'T_selector:L2(mu)->L2(dx) has exact norm squared W*N*(1-a^2); full reverse R:ell2 L2(dx)->L2(mu) has W*N; forward S:ell2 L2(mu)->L2(dx) has upper bound W*coth(delta/4). These orientations are distinct.',
                      'A shellwise assigned scale is not automatically the true winner at that receiver; the separate fixed-threshold single-atom suite uses actual continuous maxima.',
                      'Single-atom fixed-lambda band occupation is at most log(2), and invalid outer shells are excluded. It does not sum all reverse shells at a common threshold.',
                      'A separate common-lambda shell-clipping suite bounds sum_j |E_j intersect true atom band|/v_j by the continuum true-winner integral dv/v, at most log(2).',
                      'Finite band reverse Schur guards use counting time at 3 rational scales and fiber cap D=2; row kernels and direct density integrals agree exactly.',
                      'Two-atom common-source affinity is 1/2+(1/2)*2^(-n), while multiplying one-dimensional affinities gives (3/4)^n for a different, coordinate-independent source.',
                      'Mixed-mass separated-family formulas are checked at n=512,2048,8192 without enumerating exponentially many atoms; N uses an exact rational floor and its full exact integer is stored.',
                      'Mixed-mass global Gamma*V grows with N but the matched sum equals W*log(2)^2/4; true band fee is 1/2 and the finite-window lambda level fee is 1.',
                      'For the mixed family W may numerically round to w_big; the omitted tiny mass ratio is separately preserved with its logarithm. Numerical repetition is not a directed proof of exponential-mass identities.',
                      'Decimal repeats are stability guards rather than outward-rounded interval certificates.'
                  ], results=suites)
    destination = Path(__file__).with_name('results.json')
    destination.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps(dict(status=result['status'], **counts)))


if __name__ == '__main__':
    main()
