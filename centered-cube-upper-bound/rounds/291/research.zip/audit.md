# R291 independent audit: exact capped weak products and conserved cell expenses

## 1. Independent derivation before author proofs

This derivation was completed and sent to the parent before reading `/tmp/r291_unequal_capacity.md`, `/tmp/r291_main_aggregation.md`, or any new joint-geometry author. Only this audit file is owned/written; no repository/Git state is changed.

Let lambda>0 and finite A,B>=0. On a nonatomic Lebesgue receiver space assume 0<=F<=lambda, 0<=G<=4lambda and valid weak constants A,B:

    |{F>t}|<=A/t,  |{G>t}|<=B/t, t>0.

Define

    I(x,y)=min(x,y)[2+log(max(x,y)/min(x,y))],
    I(x,0)=I(0,y)=0.

For arbitrary caps U,V>0, rearrangement gives

    integral FG<=integral_0^infinity min(U,A/u)min(V,B/u)du
               =UV I(A/U,B/V)=I(VA,UB).

Thus the optimal universal bound under the stated GENERIC information is

    integral FG<=lambda I(4A,B).

If the only q information is q>=3lambda/4, the corresponding bound is

    integral FG/q<=(4/3)I(4A,B).

These are sharp information-level bounds: on (0,infinity), take F(u)=min(U,A/u), G(u)=min(V,B/u), and q at its minimum. All superlevel weak bounds below the caps are attained and the product integral equals the formula. These extremizers need not be L1 individually; truncations to finite intervals give L1 examples approaching the same supremum. Sharpness of this abstract information does NOT establish attainability by original convolution sources, actual selectors or complete histories. If A or B is zero, the relevant function vanishes almost everywhere and the product is zero.

### The actual extra FIRST cap is decisive

The original source-cell problem also has F<=q. Then

    F/q<=min(4F/(3lambda),1).

Its weak constant is at most 4A/(3lambda), while G/(4lambda) has cap one and weak constant B/(4lambda). Therefore the sharper ACTUAL-information bound is

    integral FG/q<=4lambda I(4A/(3lambda),B/(4lambda))
                 =I((16/3)A,B).

It is sharp under this stronger information as well: choose q=3lambda/4 and F=q min(1,A/(q u)), which also obeys F<=lambda, and match G's decreasing rearrangement. There is no generic 4/3 prefactor in this sharper formula. The generic cap-only estimate cannot simply be relabeled as the actual FIRST estimate.

For a source cell with A=kappa B_n rho(C), B=kappa nu(C), the correct cost is exactly

    I((16/3)kappa B_n rho(C),kappa nu(C))
      =kappa I((16/3)B_n rho(C),nu(C))
      <=kappa[(16/3)rho(C)+(1+log B_n)nu(C)].

This recovers the old orientation and constants by the established amplification inequality, without a 4/3 mismatch.

## 2. Independent aggregation and exact singular-cell deficit

I is homogeneous and jointly concave. On x<=y its Hessian is negative semidefinite with quadratic form -(dx-(x/y)dy)^2/x, and symmetrically on x>=y; first derivatives match at equality. Hence for countably many nonnegative cell pairs with finite totals X=sum x_C,Y=sum y_C,

    sum_C I(x_C,y_C)<=I(X,Y).

Finite partial sums and monotonicity/continuity of I justify the countable limit. In particular exact per-cell pricing may save substantially for mismatched cell ratios, but the worst aggregate at fixed totals is I(X,Y), attained by proportional positive pairs. There is no universal additional source saving based on disjointness alone.

For X,Y>0 finite set r=X/Y and phi(t)=I(t,1), phi(0)=0. Explicitly,

    phi(t)=t(2-log t) for 0<t<=1,
    phi(t)=2+log t for t>=1,
    phi'(r)=1-log r for r<=1, and 1/r for r>=1.

This is strictly concave, with phi'>0. Define its nonnegative concave tangent deficit

    D_phi(t,r)=phi(r)+phi'(r)(t-r)-phi(t).

Let X0=sum_(y_C=0)x_C. Then the exact general identity is

    I(X,Y)-sum_C I(x_C,y_C)
      =sum_(y_C>0)y_C D_phi(x_C/y_C,r)+phi'(r)X0.

Indeed sum_(y_C>0)x_C=X-X0. All component sums are finite under finite X,Y, so the countable identity is legitimate. This handles x-positive/y-zero cells without pretending their ratio is defined or their missing x mass enters the y-weighted average. Equality at positive totals requires X0=0 and x_C/y_C=r for all y_C>0 cells; zero-zero cells are irrelevant. If X=0 or Y=0, all product costs and the aggregate gap are zero, and this derivative formula is replaced by that separate zero case.

The same argument applies with sum replaced by an integral over a random-partition/cell measure space, provided the expected totals are finite and all labels/widths are jointly measurable. Infinite weighted capacities give only an extended-real upper bound, not a finite Jensen-deficit certificate.

## 3. Source conservation, matching, and novelty boundary

For actual cell geometry the appropriate coordinates are

    x_C=(16/3)kappa_C B_n rho(C),
    y_C=kappa_C nu(C).

Uniform kappa gives an aggregate bound kappa I((16/3)B_n W_rho,W_nu). Varying kappas require their ORIGINAL weighted capacities in X,Y; finite source masses do not by themselves imply those capacities are finite. Reusing source cells in overlapping packets can duplicate both coordinates and invalidate a purported unweighted source budget.

A conserved common partition pays only its SAME-CELL traffic, or the exact expected common-cell allocation A(y,z) for a random partition. Unmatched cross-cell traffic remains. To recover another original pair class, one still needs its actual lower coincidence probability (and the explicit reciprocal price) or a new source-conserving allocation argument. Optimizing cell ratios, widths, matches or orientations separately per observed pair does not supply that argument.

The capped product and concavity were already available in R283; retaining the exact per-cell I before its old amplification is a useful explicit refinement, not by itself a new maximal-operator theorem. The exact tangent deficit quantifies a real saved expense on an existing conserved allocation. No global coverage or root-price cut criterion has been proved by this scalar analysis.

## 4. Independent fixed-offset matching screen before joint author

The parent subsequently supplied a constructive fixed-offset grid proposal. This screen was derived and sent before reading its joint-geometry author.

For a fixed shared grid C_i with positive widths d_i and fixed k in Z^n, pair rho|C_i with nu|C_(i+k). Each restricted source is supported in its OWN translated cell. The two weak constants and actual caps require those individual support widths, not a rectangle enclosing their distant union. Thus the exact edge product bound and its old linear amplification are valid independently of the center separation. The map i->i+k is a bijection, so summing this perfect matching charges each source once and costs at most kappa_d S_(n,D).

For a uniform common shift, the exact averaged edge weight is

    A_(d,k)(y,z)=prod_i(1-| (z_i-y_i)/d_i-k_i |)_+.

The sign follows from cell_index(z)-cell_index(y)=k. On sum_i|z_i-y_i-k_i d_i|/d_i<=eta<1 it is at least 1-eta, giving the complete class price kappa_d S/(1-eta). Offset magnitude, including dense large k, incurs no extra charge in this FIXED matching theorem. It does not cover arbitrary unknown offsets for free.

A frozen nonnegative fractional matrix w_ij with each row and column sum<=1 has the same safe linear source price, by summing the original edge product inequalities. Its actual cell-pair allocation is between zero and one. A source/shift-dependent matrix is permitted only when fixed before the receiver and jointly measurable. Averaging such allocations is legitimate; selecting new matching/width/source copies independently for every observed pair is not. Multiple offsets require their explicit total matching weight or another proved coverage budget.

## 5. Final author review and frozen bindings

The three author files were read after Sections 1-4 were saved. The joint-geometry author's final conservative replacement of constants and removal of its optional Csoft corollary were checked afterward. Final bindings:

- `/tmp/r291_unequal_capacity.md`: `aa73f3571557d6a66e8b0216abb56068397462799e0e6bed36795504cb04458e`.
- `/tmp/r291_main_aggregation.md`: `adbfb3e1c75a12ae262371ff9009c4e669cb504f08439077686952a0f8e71cb4`.
- `/tmp/r291_joint_geometry.md`: `afa895075238cda45f6865749d2ac3a0acd24750ac793b86d2891f0cfe577f35`.
- `/tmp/r291_README.md`: `42cbb3b90339f0a3249f242dbc948585f1d7eb4a9649130ffb00f4cd864a2e42`.

**PASS for the stated response/mass receipts, cross-packet matching, exact product-envelope interaction certificate, and README integration. No correction remains requested.** No global root closure is certified.

The actual-FIRST bound U1 agrees with the independent sharper formula in Section 1 and correctly avoids a 4/3 multiplier on the hard-source argument. Its abstract sharpness and finite-receiver-volume formula are correct, with zero masses and endpoints stated separately. The exact cell receipt permits distinct soft and hard geometric factors and recovers the old source-linear orientation. Sharpness is explicitly an information-level response result, not a kernel-history construction.

The unequal-mass overlap/KL identities U5-U11 check exactly. One-sided cells remain in the larger-mass normalization. Under finite weighted totals, the log sum is finite (for example m log(l/m)<=l/e), and KL has the stated finite normalization and nonnegative value. The overlap Phi_S is increasing and concave on [0,S/2]. The fixed-total random-partition decomposition and variable-total joint-index version are properly separated. Its Hellinger bound and summability criteria are valid. The main aggregation file correctly includes the extra phi'(X/Y)X0 term for singular cells and handles zero totals separately, as independently derived in Section 2.

The cross-cell theorem uses each packet's OWN rectangular support, not their joint containing box. Its injective and fractional matchings conserve both source budgets. The integer-offset hat formula has the correct sign, and the arbitrary-real-translation extension follows by translating the hard partition once before receiver integration. Both are frozen allocations; a pair cannot choose its own new translation for free. The dense-wide fixed-translation example has kappa_d<=3 and the stated reciprocal capture factor. Any high continuous application still explicitly requires its original ns/R2 qualifications, full-posterior row bound, unique j and complete clock price.

The joint author's scale-envelope identity (5) is exact: the b-scale atom plus n dL/L over [a,b] integrates the normalized rectangle kernel to its true pointwise scale supremum. The finite binomial-max softness sum is a fixed all-soft envelope, with its exact coefficient fee retained. Thus J is a genuine fixed kernel product column; both scale measures are paid and integral J=Csoft_n A^2. The interval-overlap formula, J's finite point bound, and edge capacity (9) are correct for all shape tails by positive Tonelli. Receiver-dependent s,L,R are dominated BEFORE receiver integration; no fixed-parameter convolution is silently substituted for an adaptive product.

The row capacity is (16/3)Csoft_n A beta(C_i), and the column capacity is A nu(C_j). They follow from the original hard cap and beta FIRST respectively. Actual masks may be dropped only positively. The cut inequality (10) partitions edges into outside rows, selected columns and residual crossing edges; it is valid for finite or countable indices, with infinite right sides interpreted honestly. The source totals are used once per row or column. A root-cost cut is NOT established: the all-column choice only recovers A W_nu in general. The final all-soft B_n constants are the previously audited safe 10000e^2 bound; the optional square-root Csoft estimate has been omitted, and the exact finite sum suffices.

The README matches these formulas and explicitly distinguishes the prior scalar product/concavity tools from the newly organized mass and matching receipts. It leaves unknown-offset coverage, general root cut capacity, unqualified high-score traffic and original prefix/deletion/global ledgers unresolved. It does not infer a universal positive imbalance deficit. No new mathematical test was needed for the final weaker-constant change.

## 6. Bounded local check actually executed

A fresh 50-digit local run compared the sharp generic and actual-q decreasing-profile integrals in eight cases, checked six singular/zero-total gap identities, and used Fraction arithmetic for thirty exact offset-hat identities, including signed and large offsets. Output:

    PASS sharp cap/actual-q integral cases=8 singular gap cases=6 exact offset-hat checks=30
    Abstract finite diagnostics only; no original-convolution sharpness or unknown-offset coverage claimed.

The parent's separately rerun larger scalar/KL/geometry suites were not repeated here. These finite calculations do not establish a full original history, interval certificate, covered all-offset allocation, or general root cut bound. The analytic proofs and explicit original source/cap hypotheses support this verdict.

**Frozen final receipt: PASS at all four hashes in Section 5. Exact expenses and the stated constructive allocations are valid; the remaining coverage/global costs are still unpaid. Only this owned temporary audit file was written.**
