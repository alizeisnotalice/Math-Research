#!/usr/bin/env python3
"""R291 response weak-product/aggregation scalar diagnostics; requires mpmath."""
import json,random
from pathlib import Path
from fractions import Fraction as Q
import mpmath as mp
R=random.Random(29120261017)
def H(a,b):
 if not a or not b:return mp.mpf(0)
 lo=min(a,b);hi=max(a,b);return lo*(2+mp.log(hi/lo))
def piecewise(lam,a,b):
 # Integral FG for F=lam*min(1,a/x), G=4lam*min(1,b/x).
 # Constant interval [0,lo], 1/x interval [lo,hi], 1/x^2 tail [hi,infinity).
 if not a or not b:return mp.mpf(0)
 lo=min(a,b);hi=max(a,b)
 return 4*lam**2*(lo+lo*(mp.log(hi)-mp.log(lo))+a*b/hi)
def run(case,dp):
 with mp.workdps(dp):
  lam,A,B,c=map(mp.mpf,case);a=A/lam;b=B/(4*lam)
  product=piecewise(lam,a,b)/(3*lam/4);formula=16*lam/3*H(a,b)
  err=abs(product-formula)/max(1,abs(formula));assert err<mp.mpf('1e-35')
  # Exact degree-one homogeneity of H and response homogeneity when all response quantities scale.
  hom=abs(H(c*a,c*b)-c*H(a,b))/max(1,abs(c*H(a,b)));assert hom<mp.mpf('1e-35')
  shifted=piecewise(c*lam,a,b)/(3*c*lam/4)
  herr=abs(shifted-c*product)/max(1,abs(c*product));assert herr<mp.mpf('1e-35')
  return tuple(+v for v in [product,err,hom,herr])
def common(case,dp):
 with mp.workdps(dp):
  k,Bn,u,v,lam=map(mp.mpf,case);A=k*Bn*u;B=k*v
  exact=16*lam/3*H(A/lam,B/(4*lam));cancelled=16*k/3*H(Bn*u,v/4)
  safe=16*k*u/3+4*k*(1+mp.log(Bn))*v/3
  err=abs(exact-cancelled)/max(1,abs(exact));assert err<mp.mpf('1e-35')
  assert exact<=safe*(1+mp.mpf('1e-35'))
  return +exact,+(exact/safe),+err

def actualcap(case,co,dp):
 with mp.workdps(dp):
  lam,A,B,c=map(mp.mpf,case);a=4*A/(3*lam);b=B/(4*lam)
  actual=piecewise(mp.mpf(1),a,b)*lam # 4lambda integral of normalized min profiles.
  formula=4*lam*H(a,b)
  err=abs(actual-formula)/max(1,abs(formula));assert err<mp.mpf('1e-35')
  # Pointwise actual extremizer q=max(F,3lambda/4) gives exactly capped normalized F.
  if A and B:
   for x in [a/2,a,2*a,b/2,b,2*b]:
    f=lam*min(1,(A/lam)/x);g=4*lam*min(1,b/x);q=max(f,3*lam/4)
    left=f*g/q;right=g*min(1,a/x)
    assert abs(left-right)<=mp.mpf('1e-35')*max(1,abs(right))
  k,Bn,u,v,lam2=map(mp.mpf,co)
  cost=4*lam2*H(4*k*Bn*u/(3*lam2),k*v/(4*lam2));cost2=H(16*k*Bn*u/3,k*v)
  safe=16*k*u/3+k*(1+mp.log(Bn))*v
  assert cost<=safe*(1+mp.mpf('1e-35'))
  ce=abs(cost-cost2)/max(1,abs(cost));assert ce<mp.mpf('1e-35')
  return +actual,+err,+ce,+(cost/safe)

def ph(r):return mp.mpf(0) if not r else (r*(2-mp.log(r)) if r<=1 else 2+mp.log(r))
def phd(r):return 1-mp.log(r) if r<=1 else 1/r

def jensen(count,spread):
 groups=[]
 for j in range(count):
  group=[]
  for i in range(1+j%8):
   k=Q(R.randint(1,20),R.randint(1,20));rho=Q(R.randint(1,20),R.randint(1,20));nu=Q(R.randint(1,20),R.randint(1,20))
   if j%5==0:rho=2*nu # common ratios with variable capacities: zero gap.
   elif j%5==1 and i==0:nu=Q(0) # singular y=0,x>0.
   elif j%5==2 and i==0:rho=Q(0)
   elif j%5==3:rho=Q(0) # X=0 degenerate case.
   elif j%5==4:nu=Q(0) # Y=0 degenerate case.
   group.append((str(k.numerator),str(k.denominator),str(rho.numerator),str(rho.denominator),str(nu.numerator),str(nu.denominator)))
  groups.append(group)
 maxerr=mp.mpf(0);pe=mp.mpf(0);singular=0;zero=0
 for group in groups:
  values=[]
  for dp in [40,60]:
   with mp.workdps(dp):
    pairs=[]
    for kn,kd,rn,rd,nn,nd in group:
     k=mp.mpf(kn)/mp.mpf(kd);rho=mp.mpf(rn)/mp.mpf(rd);nu=mp.mpf(nn)/mp.mpf(nd)
     # Common Bn factor fixed as 100, variable kappa per cell.
     pairs.append((mp.mpf(16)/3*k*100*rho,k*nu))
    X=sum(x for x,y in pairs);Y=sum(y for x,y in pairs);gap=H(X,Y)-sum(H(x,y) for x,y in pairs)
    assert gap>=-mp.mpf('1e-35')*max(1,H(X,Y))
    if X and Y:
     t=X/Y;X0=sum(x for x,y in pairs if not y)
     correction=phd(t)*X0
     Dsum=sum(y*(ph(t)+phd(t)*(x/y-t)-ph(x/y)) for x,y in pairs if y)
     right=Dsum+correction
     err=abs(gap-right)/max(1,abs(H(X,Y)));assert err<mp.mpf('1e-35');maxerr=max(maxerr,err)
     if dp==60 and X0:singular+=1
    else:
     assert gap==0
     if dp==60:zero+=1
    values.append(+gap)
  with mp.workdps(90):pe=max(pe,abs(values[0]-values[1])/max(1,abs(values[1])))
 assert pe<mp.mpf('1e-35')
 return {'cases':count,'precision_runs':2*count,'singular_correction_cases':singular,'zero_total_corner_cases':zero,'variable_kappa':True,'max_normalized_gap_identity_error':mp.nstr(maxerr,12),'max_normalized_40_vs_60_gap_error':mp.nstr(pe,12),'max_violation':'0'}

def stage(count,spread,maxsum):
 cases=[];commons=[];groups=[]
 for j in range(count):
  lam='1e'+str(R.randint(-spread,spread));A='0' if j%16==0 else '1e'+str(R.randint(-spread,spread));B='0' if j%16==1 else '1e'+str(R.randint(-spread,spread));c='1e'+str(R.randint(-spread,spread));cases.append((lam,A,B,c))
  commons.append(tuple('1e'+str(R.randint(0,spread) if i==1 else R.randint(-spread,spread)) for i in range(5)))
 for j in range(max(8,count//4)):
  groups.append([('0' if (j+i)%11==0 else '1e'+str(R.randint(-spread,spread)),'0' if (j+i)%13==0 else '1e'+str(R.randint(-spread,spread))) for i in range(R.randint(1,maxsum))])
 pe=mp.mpf(0);ae=mp.mpf(0);he=mp.mpf(0);rr=mp.mpf(0);ce=mp.mpf(0)
 for case,co in zip(cases,commons):
  low=run(case,40);high=run(case,60);clow=common(co,40);chigh=common(co,60)
  with mp.workdps(90):
   pe=max(pe,*[abs(x-y)/max(1,abs(y)) for x,y in zip(low,high)],abs(clow[0]-chigh[0])/max(1,abs(chigh[0])))
   ae=max(ae,low[1],high[1]);he=max(he,*low[2:],*high[2:]);rr=max(rr,chigh[1]);ce=max(ce,clow[2],chigh[2])
 assert pe<mp.mpf('1e-35')
 aggratio=mp.mpf(0);agerr=mp.mpf(0)
 for group in groups:
  vals=[]
  for dp in [40,60]:
   with mp.workdps(dp):
    pairs=[tuple(map(mp.mpf,g)) for g in group];lhs=sum(H(a,b) for a,b in pairs);rhs=H(sum(a for a,b in pairs),sum(b for a,b in pairs))
    assert lhs<=rhs+mp.mpf('1e-35')*max(1,rhs)
    if rhs:aggratio=max(aggratio,lhs/rhs)
    vals.append(+lhs)
  with mp.workdps(90):agerr=max(agerr,abs(vals[0]-vals[1])/max(1,abs(vals[1])))
 assert agerr<mp.mpf('1e-35')
 # Exact rational check of cap normalization and weak norms of the rearrangement extremizers.
 for j in range(count):
  lam=Q(R.randint(1,100),R.randint(1,100));a=Q(R.randint(1,100),R.randint(1,100));b=Q(R.randint(1,100),R.randint(1,100))
  assert 4*lam*lam/(Q(3,4)*lam)==Q(16,3)*lam
  for x in [a/2,a,2*a]:assert x*lam*min(1,a/x)<=lam*a
  for x in [b/2,b,2*b]:assert x*4*lam*min(1,b/x)<=4*lam*b
 actualerr=mp.mpf(0);actualprec=mp.mpf(0);actualratio=mp.mpf(0)
 for case,co in zip(cases,commons):
  lo=actualcap(case,co,40);hi=actualcap(case,co,60)
  with mp.workdps(90):
   actualerr=max(actualerr,lo[1],hi[1],lo[2],hi[2]);actualprec=max(actualprec,abs(lo[0]-hi[0])/max(1,abs(hi[0])));actualratio=max(actualratio,hi[3])
 assert actualprec<mp.mpf('1e-35')
 return {'actual_F_le_q':{'cases':count,'precision_runs':2*count,'max_normalized_formula_error':mp.nstr(actualerr,12),'max_normalized_40_vs_60_error':mp.nstr(actualprec,12),'max_common_cost_to_original_asymmetric_price_ratio':mp.nstr(actualratio,12),'max_violation':'0'},'exact_Jensen_gap':jensen(max(12,count//32),spread),'response_cases':count,'response_precision_runs':2*count,'common_source_cases':count,'aggregation_cases':len(groups),'max_aggregation_terms':maxsum,'rational_extremizer_cases':count,'input_decimal_exponent_range':[-spread,spread],'max_piecewise_vs_formula_normalized_error':mp.nstr(ae,12),'max_response_normalized_40_vs_60_error':mp.nstr(pe,12),'max_homogeneity_normalized_error':mp.nstr(he,12),'max_common_source_lambda_cancellation_error':mp.nstr(ce,12),'max_common_cost_to_safe_price_ratio':mp.nstr(rr,12),'max_aggregation_lhs_to_rhs_ratio':mp.nstr(aggratio,12),'max_aggregation_40_vs_60_error':mp.nstr(agerr,12),'max_inequality_violation':'0'}
settings=[('simple',64,2,4),('extreme_unequal',256,20,12),('expanded',1024,100,32)]
stages=[dict(name=name,**stage(count,spread,terms)) for name,count,spread,terms in settings]
out={'status':'PASS','seed':29120261017,'scope':'Ordinary mpmath40/60 and exact Fraction scalar rearrangement extremizer diagnostics. Generic independent-cap extremizers are separate from actual F<=q extremizers; not intervals or a FULL/FIRST/source/history certificate. Three-piece antiderivatives integrate the entire half-line without tail truncation.','generic_independent_caps_formula':'(16lambda/3) H(A/lambda,B/(4lambda)); H=min(alpha,beta)*(2+log(max/min)), zero if either input is zero.','generic_independent_caps_common_source_exact_cost':'(16kappa/3) H(Bn*u,v/4)','generic_independent_caps_safe_comparison':'(16kappa/3)*u+(4kappa/3)*(1+log(Bn))*v','actual_F_le_q_formula':'4lambda H(4A/(3lambda),B/(4lambda))=H(16A/3,B)','actual_common_source_cost':'H((16/3)kappa Bn u,kappa v)<= (16/3)kappa u+kappa(1+logBn)v','aggregation':'sum H(alpha_i,beta_i)<=H(sum alpha_i,sum beta_i)','stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
