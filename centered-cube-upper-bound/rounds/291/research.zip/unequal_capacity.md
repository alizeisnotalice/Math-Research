# R291 — exact asymmetric mass bookkeeping and overlap/KL capacity pricing

The capped weak-product function I, its sharp rearrangement integral, homogeneity, amplification inequality and concavity are already established tools in R283 and the subsequent R285/R290 payments. This deliverable refines their exact original mass bookkeeping and overlap/KL profile; it is not a new maximal-operator theorem. Its intended geometric use is to price the parent’s separately proved cross-cell offset matching, without claiming that this pricing itself constructs coverage.

## 1. Screened response theorem and sharp constant

Let E be a measurable receiver domain, possibly of infinite measure. Let F,G>=0 and q be measurable on E, with

    0<=F<=q, q_-=3lambda/4<=q<=lambda, 0<=G<=4lambda,
    ||F||_(1,infinity)<=A, ||G||_(1,infinity)<=C,

where lambda>0 and A,C are finite. Define

    I(x,y)=min(x,y)[2+log(max(x,y)/min(x,y))],

with I=0 if either argument is zero. Then

    integral_E F G/q <= I((16/3)A,C).                  (U1)

This is SHARP under these response hypotheses. The cap F<=q is essential to the stated constant: it avoids inflating the hard-source argument C by 4/3.

Indeed, the ACTUAL normalized response f=F/q satisfies

    f<=min(1,F/q_-), ||f||_(1,infinity)<=A/q_-.

Set g=G/(4lambda), whose height is <=1 and weak constant <=C/(4lambda). Decreasing rearrangement, or layer cake of their superlevel intersections, gives

    integral_E F G/q
      <=4lambda integral_0^infinity
           min(1,A/(q_-t))min(1,C/(4lambda t))dt
      =4lambda I(A/q_-,C/(4lambda))
      =I((16/3)A,C).

No cap is assigned to a weak maximal envelope. Merely using F<=lambda and then pulling out q_-^(-1) would instead produce the weaker I((16/3)A,(4/3)C).

For sharpness on a nonatomic infinite receiver space, take q=q_-, and arrange the two normalized functions as the two displayed decreasing tails on a half-line (or on a unit-cross-section strip in R^n). Their product attains the integral exactly. If individual response integrability is also required, truncate the strip at length V and let V increase: the costs converge to (U1), so its constant remains sharp as a supremum. These are response extremizers, not a claim that arbitrary such profiles are realized by original cube kernels.

If A=0 or C=0, the corresponding response vanishes almost everywhere, and the product is zero even on an infinite receiver domain. The positive finite constants in (U1) guarantee product integrability; individual responses need not be integrable for the theorem.

For completeness, if |E|=V<infinity, put a=A/q_-, b=C/(4lambda), m=min(a,b), M=max(a,b). The exact sharp rearrangement integral is 4lambda J_V(a,b), where

    J_V=V,                         V<=m,
    J_V=m[1+log(V/m)],              m<V<=M,
    J_V=I(a,b)-ab/V,                M<V<infinity.

Use J_V=0 when V=0 or ab=0, and J_infinity=I(a,b). The formulas agree at the positive endpoints.

## 2. Exact original cell expense, including distinct weak constants

For one common source cell C_0, write u=rho(C_0), v=nu(C_0). Suppose its ACTUAL restricted responses retain the original caps and have valid weak constants

    A=kappa_soft B u, C=kappa_hard v,

with B>=1 and nonnegative finite kappa_soft,kappa_hard. Positivity of restrictions of the original sources supplies the actual caps. Equation (U1) gives the cell receipt

    E_cell=I(alpha,beta),
    alpha=(16/3)kappa_soft B u,
    beta=kappa_hard v.                                (U2)

Explicitly, if alpha<=beta the cost is alpha[2+log(beta/alpha)], and otherwise it is beta[2+log(alpha/beta)]. Zero cell masses give zero product and zero cost. The smaller WEIGHTED mass, rather than necessarily min(u,v), governs the gain.

The previous safe linear price follows from I(Bx,y)<=x+(1+log B)y:

    E_cell<=(16/3)kappa_soft u
                  +(1+log B)kappa_hard v.             (U3)

In particular for the equal geometric factor kappa of R290, it is exactly that original linear price, with no additional 4/3 on nu. The sharper formula (U2) keeps both mass regimes and permits geometric constants on the two sources to differ.

## 3. Exact overlap and KL decomposition of a common-partition receipt

Let cells j form a finite or countable COMMON source partition. Assume the response restrictions are positive and disjoint in source, and use their actual valid alpha_j,beta_j from (U2). The same-cell receiver traffic is bounded by

    E_part=sum_j I(alpha_j,beta_j).                    (U4)

The summation takes place AFTER the cell product has been integrated. It is not a sum of weak norms treated as an L1 norm, and it does not include unpaid cross-cell source pairs.

Assume for now that X=sum alpha_j and Y=sum beta_j are finite. Put

    m_j=min(alpha_j,beta_j), l_j=max(alpha_j,beta_j),
    M=sum m_j, L=sum l_j=X+Y-M.

If M=0, every product receipt is zero, so E_part=0. If M>0, define probability vectors P_j=m_j/M and Q_j=l_j/L. Then the EXACT identity is

    E_part=M[2+log(L/M)]-M KL(P||Q).                   (U5)

Proof: sum I=2M+sum m_j log(l_j/m_j), and substitute m_j=MP_j and l_j=LQ_j. The entropy convention is 0 log(0/Q_j)=0. Since P_j>0 implies Q_j>0, the KL term is defined; under finite X,Y it is finite and nonnegative. In fact KL(P||Q)<=log(L/M), since m_j<=l_j.

IMPORTANT ZERO-MASS CONVENTION: cells with m_j=0 and l_j>0 remain in L and Q. Their own product cost is zero, but their one-sided source mass affects the normalized Q and therefore the KL deficit. Removing those masses while still using L=X+Y-M would invalidate (U5).

Let S=X+Y and define

    Phi_S(t)=t[2+log((S-t)/t)], Phi_S(0)=0,
    0<=t<=S/2.

It is increasing and concave on this interval. For 0<t<S/2,

    Phi_S'(t)=1+log((S-t)/t)-t/(S-t)>=0,
    Phi_S''(t)=-S^2/[t(S-t)^2]<0.

Since M<=min(X,Y), (U5) yields

    E_part<=Phi_S(M)<=I(X,Y),                          (U6)

and its exact global deficit is

    I(X,Y)-E_part
      =[I(X,Y)-Phi_S(M)]+M KL(P||Q).                  (U7)

Thus both small overlap of the weighted cell masses and nonconstant smaller-to-larger ratios can reduce the source budget. Formula (U7) is an identity, not a presumption that either deficit has a useful positive size.

A second useful bound is

    E_part<=2sum_j sqrt(alpha_j beta_j).               (U8)

Indeed 2+log r<=2sqrt(r) for r>=1. For constant kappa_soft,kappa_hard,B and positive total source masses, this becomes

    2sqrt(XY) sum_j sqrt(P_rho,j P_nu,j),

where P_rho,j=u_j/W_rho and P_nu,j=v_j/W_nu are the two original source-mass distributions on the common partition. This is a genuine source overlap quantity, not an extra independence hypothesis.

Without finite X,Y, (U4) still holds by positive Tonelli, possibly with infinite right side. Its exact summability criterion is

    sum m_j<infinity,
    sum m_j log(l_j/m_j)<infinity,

with zero terms interpreted as zero. Normalized total/KL formulas are used only when their stated finite totals exist.

## 4. Common-partition averaging: fixed totals and variable geometry

For random common partitions with constant geometric factors, X and Y are fixed because source masses are conserved. Write M_omega and D_omega=KL(P_omega||Q_omega), assigning M_omega D_omega=0 when M_omega=0. Then

    E_omega E_part
      =E_omega Phi_S(M_omega)-E_omega[M_omega D_omega]
      <=Phi_S(E_omega M_omega).                       (U9)

The exact savings from the total-only I(X,Y) are

    I(X,Y)-E E_part
      =[I(X,Y)-Phi_S(E M)]
        +[Phi_S(E M)-E Phi_S(M)]
        +E[M D].                                     (U10)

All three terms are nonnegative. They are respectively the mean-overlap deficit, the concave Jensen deficit from varying overlaps, and the within-partition KL deficit. No finite-measure receiver assumption is used.

If geometric factors, menu constants or widths vary with the random draw, X_omega and Y_omega need NOT be fixed. Do not apply (U9)-(U10) with fictitiously constant totals. There is instead an exact joint-index formulation. On index space (omega,j), with probability measure in omega and counting measure in j, put

    barX=E sum alpha_omega,j, barY=E sum beta_omega,j,
    barM=E sum min(alpha_omega,j,beta_omega,j),
    barL=barX+barY-barM.

If barX,barY are finite and barM>0, normalize the joint smaller and larger mass densities to P_joint and Q_joint. Then homogeneity and the same algebra give

    E E_part=barM[2+log(barL/barM)]
                 -barM KL(P_joint||Q_joint)
             <=Phi_(barX+barY)(barM)<=I(barX,barY).     (U11)

If barM=0, the left side is zero. These are the ACTUAL expected weighted source totals; a varying kappa or a poorly integrable geometric law cannot be replaced by an unproved common root bound.

For a common-grid pair class whose same-cell probability is >=p_0>0, the existing source allocation step multiplies the averaged receipt in (U9) or (U11) by p_0^(-1). More general fixed weighted matching allocations may retain their exact corresponding weights. An attractive partition alone does not eliminate cross-cell traffic or its original capture-probability compensation.

The same receipts apply to an already constructed fixed offset or injective partial matching of source cells: pair F_C with G_D along each matched edge and use its alpha_C,beta_D in (U2). The product inequality requires the two responses’ individual weak bounds and actual caps, not coincident cell centers. Injectivity ensures each source mass is used at most once. A noninjective family requires its actual allocation weights and source incidence costs; neither those nor geometric pair coverage are supplied by the receipt. Thus the overlap/KL profile is directly usable as a refined price for the parent’s offset-matching allocation once that allocation’s own identity and compensation factor have been verified.

## 5. Does imbalance genuinely save the original common source budget?

YES, conditionally on actual common-partition imbalance; the saving can be arbitrarily large even when W_rho=W_nu. For two cells take

    (u_1,u_2)=(1-epsilon,epsilon),
    (v_1,v_2)=(epsilon,1-epsilon).

For fixed B,kappa>0 and c_0=16/3, equal geometric factors give, for sufficiently small epsilon,

    sum I(c_0 kappa B u_j,kappa v_j)
      =kappa epsilon[2+log(c_0 B(1-epsilon)/epsilon)]
       +c_0 kappa B epsilon
                    [2+log((1-epsilon)/(c_0 B epsilon))]
      ->0.

Both total source masses remain one. This is a real reduction of the diagonal common-partition capacity receipt. It is compatible with ordinary positive L1 sources having those cell masses; no singular source or nu<=rho hypothesis is involved. For a random-grid application, the imbalance must hold in its ACTUAL average as in (U9), not merely on a selectively favorable grid.

The gain is not automatic: rho=nu is an allowed original source pair. With constant equal kappa, every common partition then has u_j=v_j and

    sum I(c_0 kappa B u_j,kappa v_j)
      =kappa[2+log(c_0 B)]W_rho.

Here M=min(X,Y), the normalized smaller and larger mass distributions coincide, and both deficits in (U7) vanish. Thus the new receipt can save an actual common source budget when overlap/ratios permit it, but the mass hypotheses alone do not uniformly remove kappa or log B. Additional geometry or a proved matching/overlap control is needed to exploit the receipt on a general original traffic. No new coverage or full root theorem is claimed.

## 6. Actual bounded diagnostics

A local Python run checked the overlap/KL identity, its total-only upper bound and the Hellinger bound on 160 finite arrays with zero masses, mixed orientations and masses spanning eighteen orders of magnitude. One additional joint-index case had varying partition totals and a zero-overlap partition. Output:

    PASS overlap/KL identity, total bound, Hellinger bound
         and variable-total joint-index cases=161

For B=7,kappa=1, the two-cell example gave costs 1.2129038175304547, 0.0038647254698649497 and 0.000006512702156327267 at epsilon=.01,1e-5,1e-8 respectively. These are floating algebra diagnostics, not interval certificates or actual kernel-profile extremizers. The analytic derivations above prove the response and source-receipt formulas. Only this temporary Markdown file was written; no Git or other authors' files were modified.
