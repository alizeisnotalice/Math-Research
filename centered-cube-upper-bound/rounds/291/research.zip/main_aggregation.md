# R291 main: exact aggregation loss for unequal cell capacities
Status: analytic result reviewed independently; not a global closure.
Let H(x,y)=min(x,y)[2+log(max(x,y)/min(x,y))] for positive x,y, and H=0 if either is zero. Define phi(r)=r(2-log r) for 0<r<=1 and 2+log r for r>=1, phi(0)=0. H(x,y)=y phi(x/y). phi is C1 at 1, phi'=1-log r below1 and1/r above1; phi''=-1/r below1 and-1/r^2 above1. Thus H is jointly concave and degree-one homogeneous, continuous on the closed nonnegative quadrant.
For finite or countable cell budgets x_C,y_C with finite totals X,Y>0, concavity and homogeneity imply sum H(x_C,y_C)<=H(X,Y). Countable passage uses finite partial sums, continuity and monotone convergence.
If all positive x_C are on cells with y_C>0, put p_C=y_C/Y, r_C=x_C/y_C, rbar=X/Y. Then EXACTLY
 H(X,Y)-sum H(x_C,y_C)=Y sum p_C D_phi(r_C,rbar),
 D_phi(r,t)=phi(t)+phi'(t)(r-t)-phi(r)>=0.
Cells with y_C=0,x_C>0 require explicit missing-mass accounting; do not use the equality above without the stated condition. The weak inequality still holds. Also x_C=0 permitted with D_phi(0,t) by continuity.
For r>=t>0, D_phi(r,t)=integral_t^r (r-u) w(u)du; for 0<r<t, D_phi(r,t)=integral_r^t (u-r)w(u)du; w(u)=1/u if u<=1,1/u^2 if u>=1. These follow by integrating -phi''. Nonnegative integrals retain exact asymmetric behavior rather than using an unproved quadratic approximation.
Actual application, subject to response theorem review: x_C=(16/3) kappa_C B_n rho(C), y_C=kappa_C nu(C). Since actual F_C<=q and G_C<=4lambda, the paid samecell traffic is bounded by sum H(x_C,y_C). The total bound uses X=(16/3)B_n sum kappa_C rho(C),Y=sum kappa_C nu(C). The displayed deficit is an explicit saving from differing cell mass ratios in this response-only envelope. It does not pay crosscell traffic, does not remove B_n from the actual theorem, and does not provide sqrt(n) for arbitrary capacities. Comparing this bound with R290's old source-linear receipt and taking their minimum is legitimate on the SAME positive suballocation, but adding savings to a different suballocation is not.
No assertion that a lower bound on this deficit holds for arbitrary sources; coincident ratio budgets can have zero deficit. Next geometric requirement remains constructing a source-conserving covered allocation with small sum H, including any crosscell contributions. This identity is a tool for measuring an actual gain, not a renamed unproved remainder.

## General singular-cell identity
For X,Y>0 define X0=sum_{y_C=0}x_C. Then without a support restriction,
H(X,Y)-sum H(x_C,y_C)=sum_{y_C>0}y_C D_phi(x_C/y_C,X/Y)+phi'(X/Y)X0.
Indeed sum_{y_C>0}x_C=X-X0, and the tangent linear terms sum to -phi'(X/Y)X0. All right-hand terms are nonnegative. For X=0 or Y=0 the costs and gap are zero and the ratio formula is not used. For positive totals equality requires X0=0 and all positive-y ratios equal X/Y, by strict concavity. For a measurable random partition, use the product measure of its law and counting measure on the fixed cell index; finite expected X,Y suffice. This does not presume per-realization totals are fixed when cell widths vary.
