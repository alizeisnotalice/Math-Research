# R291: source-conserving interactions between distinct packets

## 1. Main result: fixed matchings pay wide interactions without a joint containing rectangle

Let n>=1, 0<a<=b<=2a, lambda>0, and q(x) in [q_-,lambda], q_-=3lambda/4. Retain the actual full-soft p_y(x)=P_(s(x),L(x))(x-y), L,R in [a,b], ns<=D, receiver dx, and the actual two caps

    integral p_y beta(dy)<=q(x),
    sup_(a<=t<=b) h_t*nu(x)<=4lambda.                       (1)

The independent positive L1 sources beta and nu are fixed before receiver integration. No source comparison is assumed. Arbitrary original masks a(x,y,z) in [0,1] remain allowed in

    dT=q(x)^(-1)p_y(x)h_R(x-z)a(x,y,z) dx beta(dy)nu(dz).

Partition the two sources by the same countable axis-parallel rectangular cells C_i, fixed before receiver selection. The partitions and the matching may depend on original sources, seeds and frozen outer data. Each cell has finite positive side vector d(i). Set

    kappa_i=2+sum_l log(1+d_l(i)/a),
    B=B_*(n,D),
    S_i^beta=(16/3)kappa_i beta(C_i),
    S_i^nu=(1+log B)kappa_i nu(C_i).

Here B is exactly the fixed R283/R290 full-soft entropy constant; its formula is in Section 5. If w_ij>=0 is any frozen fractional matching,

    sum_j w_ij<=1 for every i,   sum_i w_ij<=1 for every j,

then the actual positive interaction allocation satisfies

    integral w_(cell(y),cell(z)) dT
       <=sum_i S_i^beta+sum_j S_j^nu.                      (M1)

In particular any fixed injective matching of soft cells to hard cells costs each participating source once. A permutation may move cells arbitrarily far in every coordinate. No rectangle containing both matched packets is introduced and there is no displacement factor in (M1).

This is an actual source-conserving interaction theorem. It is not a claim that the full dense interaction matrix is substochastic or that a receiver-dependent matching inherits (M1).

## 2. Proof with separate translated-source weak constants

Define actual packet responses

    F_i(x)=integral_(C_i) p_y(x)beta(dy),
    G_j(x)=integral_(C_j) h_R(x-z)nu(dz).

By positivity, F_i<=q and G_j<=4lambda at original receivers. R290's rectangular weak theorem and its full-soft marked-shape extension give x-independent maximal envelopes with weak constants

    ||F_i||_(1,infinity)<=kappa_i B beta(C_i),
    ||G_j||_(1,infinity)<=kappa_j nu(C_j).                 (2)

Their translation centers need not coincide. Translation invariance is applied independently to each source packet; the weak theorem is not applied to their union. The masks need not factor: each masked pair integral is bounded above by integral F_i G_j/q.

For completeness use the already audited capped-product function

    I(A,B)=min(A,B)[2+log(max(A,B)/min(A,B))],
    I(A,0)=I(0,B)=0.

The two actual caps, (2), and q>=q_- imply

    integral_E F_i G_j/q
      <=4lambda I(kappa_i B beta(C_i)/q_-,
                     kappa_j nu(C_j)/(4lambda))
      <=(16/3)kappa_i beta(C_i)
                    +(1+log B)kappa_j nu(C_j).             (3)

The last step is the R283 amplification I(B A,C)<=A+(1+log B)C, with all factors retained. Multiplying (3) by w_ij and summing uses the row and column budgets exactly once and proves (M1). Zero source packets contribute zero. Countable sums follow by monotone convergence. No cap is imposed on a maximal envelope or latent soft component.

## 3. Exact offset overlap and a genuinely dense wide branch

For a grid with fixed positive sides d_l and a common uniform shift u, fix an offset k in Z^n. Match C_i to C_(i+k). This is a bijection of the full grid. The exact common-shift probability for a source pair is

    A_(d,k)(y,z)
       =product_l (1-|(z_l-y_l)/d_l-k_l|)_+.               (4)

This follows coordinatewise by intersecting intervals of shifts producing the specified cell-index difference. It is the exact overlap probability, not a support-radius majorant. Uniform independent coordinate shifts multiply these probabilities. Averaging (M1) therefore gives

    T_(A_d,k)<=kappa_d S_(n,D),
    kappa_d=2+sum_l log(1+d_l/a),
    S_(n,D)=(16/3)W_beta+(1+log B)W_nu.                    (M2)

For 0<=eta<1 put

    Gamma_(d,k,eta)
      ={sum_l |z_l-y_l-k_l d_l|/d_l<=eta}.

The elementary product bound gives A_(d,k)>=1-eta there, hence

    T_Gamma <=kappa_d S_(n,D)/(1-eta).                    (M3)

There is no assumption that the displacement k*d is small or sparse. For example take d_l=a/n and k_l=floor(n/2) in EVERY coordinate. The central displacement has l1 size about na/2, while kappa_d<=3. At eta=1/2, (M3) costs at most 6 S_(n,D) on the full positive-thickness class around this dense wide displacement. The exact n=1 center is zero; the broad example is intended for n>=2. This theorem concerns arbitrary L1 sources on the class, not point masses or fixed-scale receiver selectors.

The full all-soft case D=n gives S_(n,n)=O(log(n+2))(W_beta+W_nu). Thus the raw matching branch has logarithmic source price in that example. For the original high continuous slot, only when its ORIGINAL ns<=D, R2<=D and physical-clock qualifications are present, its separately proved full-posterior score/clock price B_D<=4sqrt(nD) gives

    P_Gamma<=2Lambda B_D kappa_d S_(n,D)/(1-eta).           (M4)

The example costs <=12Lambda B_D S_(n,D)<=48Lambda sqrt(nD)S_(n,D), root-polylog for polylogarithmic D. Formula (M4) retains the actual full posterior and original unique j; it does not assert those gates on arbitrary wide traffic. Low pe uses the raw (M3), with its original outer Lambda once. Initial or deletion-time atoms are not covered by a continuous clock formula.

The offset is frozen. A mixture of offsets with nonnegative weights alpha_k has row and column sum sum_k alpha_k, and therefore costs exactly that total weight times the right side of (M2). If sum alpha_k<=1 it is another fractional matching. Although sum_k A_(d,k)=1 pointwise over all offsets, summing all their separate estimates has infinite total weight. This identity does not give free coverage of all displacement classes.

The lattice restriction is unnecessary if the two partitions are translated separately. For ANY frozen v in R^n, use soft cells C_i(u) and hard cells C_i(u)+v, and match the same index i. Each source is still partitioned exactly once, the packet side widths and weak constants are unchanged, and the exact coincidence profile is

    A_(d,v)(y,z)=product_l (1-|z_l-y_l-v_l|/d_l)_+.

Thus (M2)-(M4) hold with k*d replaced by arbitrary v. In particular one may take v_l=a/2 in every coordinate and d_l=a/n: the dense center has l1 norm na/2 and the permitted residual is |z-y-v|_1<=a/(2n). The real translation is fixed before receiver integration; choosing v=z-y separately for each pair would not be this construction.

A spatially varying fixed permutation or injective matching is also legitimate by (M1), even though it has no single translated-hat formula. This flexibility is greater than choosing one global displacement, but a construction that covers the full original wide remainder at root cost remains unproved.

## 4. A complementary exact interaction certificate using receiver overlap

The following certificate is valid for the FULL softness interval and arbitrary original masks. It keeps every cost; it is not claimed to be a root-order bound in the worst case.

Write h for the one-dimensional unit interval density, phi for the original soft density, and

    Q_k=binom(n,k)^(-1) sum_(|S|=k)
             product_(l in S) phi(x_l) product_(l notin S) h(x_l).

Then P_(s,L)=sum_(k=0)^n b_(n,k)(s) Q_(k,L), where b is the binomial probability. Put

    a_(n,k)=max_(0<=s<=1)b_(n,k)(s),
    Csoft_n=sum_(k=0)^n a_(n,k).

For 0<k<n,

    a_(n,k)=binom(n,k)(k/n)^k(1-k/n)^(n-k),

and both endpoints equal 1. These are exact finite constants, with Csoft_n<=n+1. Every statement below uses this exact finite sum; no asymptotic softness-coefficient estimate is needed.

Let pi_k be the positive latent shape law: choose uniformly k soft coordinates, assign their independent original interval-mixture sides, and use side 1 in other coordinates. Let

    A=1+n log(b/a),  eta_scale=delta_b+n 1_[a,b](t)dt/t.

For a fixed shape Rvec, its common-scale kernel envelope has the EXACT positive representation

    K_Rvec(w)=sup_(a<=L<=b)H_(Rvec,L)(w)
             =integral H_(Rvec,L)(w) eta_scale(dL).         (5)

Its integral is A. For the hard shape use K_h. The fixed full-soft envelope

    K_soft=sum_k a_(n,k) integral K_Rvec pi_k(dRvec)

dominates every actual P_(s,L) pointwise and has integral Csoft_n A. This coefficient mixture accounts for receiver-dependent softness; it is not replaced by a single chosen s.

Define the computable fixed product-envelope column

    J(delta)=integral K_soft(w)K_h(w-delta)dw.              (6)

For A_l=L Rvec_l and hard side T, the exact interval overlap is

    ell(A_l,T,delta_l)
       =min{A_l,T,((A_l+T)/2-|delta_l|)_+}.

Consequently

    J(delta)=sum_k a_(n,k) integral pi_k(dRvec)
                integral eta_scale(dL)eta_scale(dT)
                product_l ell(L Rvec_l,T,delta_l)
                                /(L Rvec_l T).             (7)

All integrals are positive and Tonelli is applicable. In particular integral J=Csoft_n A^2. Also J(delta)<=a^(-n)Csoft_n A because K_h<=a^(-n). The exact same-receiver intersection is retained in (7); the potentially costly envelope selection has already been paid through BOTH scale measures and the full softness coefficient sum. No free pair-specific selector is hidden in J.

For any source-cell pair, let t_ij be its original actual masked traffic. The following three capacity families hold simultaneously:

    sum_j t_ij <= R_i=(16/3)Csoft_n A beta(C_i),
    sum_i t_ij <= C_j=A nu(C_j),                            (8)

    t_ij<=E_ij=min{
        4lambda I(kappa_i B_n beta(C_i)/q_-,
                     kappa_j nu(C_j)/(4lambda)),
        q_-^(-1) integral_(C_i) integral_(C_j)
                     J(z-y) beta(dy)nu(dz)}.               (9)

The row bound follows from sum_j G_j<=4lambda, q>=q_- and integral F_i<=Csoft_n A beta(C_i). The column bound follows from sum_i F_i/q<=1 and integral G_j<=A nu(C_j). Edge bounds use (3) before amplification and the pointwise fixed envelopes. These bounds retain arbitrary original masks by positivity, so apply to the original low-pe far/high-m traffic without changing e_g or m.

For every pair of index sets I,J one therefore has the explicit cut inequality

    sum_ij t_ij
       <=sum_(i notin I) R_i + sum_(j in J) C_j
                    +sum_(i in I,j notin J) E_ij.          (10)

Proof: split edges into rows outside I, edges from I into J, and the remaining cross edges. Bound the first class by the row capacities, the second by column capacities, and the third edgewise. Each soft row and each hard column source term occurs at most once. This is an algebraic positive-matrix inequality and needs no integrality assumption. Finite restrictions establish it first; monotone limits give the countable version, with infinite right sides interpreted honestly. It is equivalent to a finite capacitated bipartite min-cut upper certificate when the partition is finite.

Taking I all and J all recovers A W_nu, which is order n on a fixed octave. Thus (10) alone is not new root geometry. It is a rigorously derived decision tool combining exact geometric edge overlaps with nonduplicated global source capacities. To obtain a general root payment from it, one must construct a cut with root total cost or improve the edge capacities using the ORIGINAL low-pe constraint in the same receiver integral. The actual small-parent side bound does not localize full e_g to that pair's parent; no such localization is assumed here.

## 5. Constants, bookkeeping and a finite overlap example

The source-packet constant used in (2)-(4) is

    M=min(n,floor(D)+1),
    H_*=(D+2)[log(en)+log(2D+3)+15],
    E_*=H_*+log(n+1)+log(2D+3)+60e,
    B_*=e^2 M(D+3)[3+2log2+2log M+2E_*].

D=n covers all s in [0,1]. The previously audited safe bound is B_n<=10000e^2 n^3log(n+2), hence 1+log B_n<=[5+log(10000e^2)]log(n+2)=O(log(n+2)). Constants from distinct source/terminal ledgers are summed before applying their source bounds. Common grid randomness is independent of original auxiliary slots and clock; no packet posterior is substituted for full Pi. An input-dependent frozen matching is legal, but its choice must be measurable; countable indices and explicit measurable weights suffice.

A simple exact term in (7) uses n=2 and a=b=1, so eta_scale is a unit atom. For hard shape (1,1) and delta=(1/2,1/4), the column is (1/2)(3/4)=3/8. For shape (2,1/2), the intersection lengths are (1,1/2); the denominator product is 1, giving 1/2. These are fixed-shape positive mixture terms, not the entire full-soft J. At arbitrary a,b, (7) retains the scale measures with total mass A each.

## Bounded conclusion

The new proved geometric branch is the between-cell matching theorem (M1), including dense wide translated offsets (M2)-(M4). It changes the source budget from the width of a rectangle containing both packets to the separate packet widths, with no source duplication. The global interaction certificate (7)-(10) retains exact receiver overlap and all envelope fees. Neither result constructs a free all-offset matching or establishes the full original low-pe/high-continuous wide payment. The remaining task is a source-conserving grouping/selection covering that original traffic at the stated source price.

## Actual independent finite checks

The independent numeric worker executed /tmp/r291_geometry_checks.py with exact Fraction arithmetic, and the parent reran it. Results: 72 grid-envelope cases with 12,204 coordinate breakpoint checks through dimension 1000 and signed offsets of magnitude 10^20; 105 boundary cases; 12 multidimensional offset sums equal to one; three weighted translated-grid source-conservation cases with up to 25 cells; 16 and 256 exhaustive finite cuts plus 130 random/endpoint cuts on a 20-by-17 matrix. The cut identity and added capacity slacks were checked separately. Both fixed-shape overlap terms 3/8 and 1/2 were verified. All passed. These are finite algebra/geometry diagnostics, not a proof that the full original residual admits a low-cost matching or cut.
