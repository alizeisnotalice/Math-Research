#!/usr/bin/env python3
"""Exact rational translated-grid probabilities, matching ledgers and finite cuts."""
import json,random
from fractions import Fraction as F
from itertools import product
from pathlib import Path
R=random.Random(29120261018)
def fl(x):return x.numerator//x.denominator
def probability(y,z,d,k):
 assert d>0
 cuts=sorted(set([F(0),d,y-d*fl(y/d),z-d*fl(z/d)]));length=F(0)
 for a,b in zip(cuts,cuts[1:]):
  u=(a+b)/2
  if fl((z-u)/d)-fl((y-u)/d)==k:length+=b-a
 p=length/d;formula=max(F(0),1-abs((z-y)/d-k));assert p==formula
 delta=(z-y)/d;lo=fl(delta)
 assert sum(max(F(0),1-abs(delta-j)) for j in [lo,lo+1])==1
 return p

def grid_stage(count,ns,maxoffset):
 coordinates=0;envelopes=0;minimum=F(1)
 for j in range(count):
  n=ns[j%len(ns)];weights=[R.randint(1,100) for _ in range(n)];total=sum(weights)
  budget=[F(0),F(1,10),F(1,2)][j%3]
  deltas=[budget*w/total*R.choice([-1,1]) for w in weights]
  P=F(1);formula=F(1)
  for i,e in enumerate(deltas):
   d=F(R.randint(1,100),R.randint(1,100))*F(10)**R.randint(-3,3);y=F(R.randint(-100,100),R.randint(1,100));k=R.randint(-maxoffset,maxoffset)
   z=y+d*(k+e);p=probability(y,z,d,k);P*=p;formula*=1-abs(e);coordinates+=1
  assert P==formula and P>=1-sum(abs(e) for e in deltas)>=F(1,2)
  minimum=min(minimum,P);envelopes+=1
 # Strict boundaries, wrong offsets, negative source coordinates and large signed offsets.
 boundary=0
 for e in [F(-2),F(-1),F(-1,2),F(0),F(1,2),F(1),F(2)]:
  for k in [-maxoffset,-1,0,1,maxoffset]:
   d=F(7,13);y=F(-31,17);z=y+d*(k+e);probability(y,z,d,k);boundary+=1
 # Explicit multidimensional offset partition sums in small dimensions.
 partition=0
 for n in [1,2,3,4]:
  ds=[F(3*i+1,7) for i in range(n)];ys=[F(-i,3) for i in range(n)];zs=[ys[i]+ds[i]*F(7*i-3,5) for i in range(n)]
  choices=[[fl((zs[i]-ys[i])/ds[i]),fl((zs[i]-ys[i])/ds[i])+1] for i in range(n)]
  mass=F(0)
  for ks in product(*choices):
   p=F(1)
   for i,k in enumerate(ks):p*=probability(ys[i],zs[i],ds[i],k)
   mass+=p
  assert mass==1;partition+=1
 return {'envelope_cases':envelopes,'envelope_coordinate_checks':coordinates,'boundary_1d_cases':boundary,'explicit_multidimensional_offset_partition_cases':partition,'dimensions':ns,'max_integer_offset':str(maxoffset),'min_envelope_probability':str(minimum),'max_exact_formula_or_gate_error':'0'}

def matching(size):
 # Integer square grid, fixed translations; truncating boundary cells gives partial bijections.
 cells=list(product(range(size),repeat=2));idx={c:i for i,c in enumerate(cells)};N=len(cells)
 offsets=[(0,0),(1,-1),(-2,1),(10,0)];weights=[F(1,10),F(1,5),F(1,4),F(1,20)]
 assert sum(weights)<=1
 W=[[F(0) for _ in cells] for _ in cells]
 for off,w in zip(offsets,weights):
  targets=[]
  for c in cells:
   dest=tuple(c[i]+off[i] for i in range(2))
   if dest in idx:W[idx[c]][idx[dest]]+=w;targets.append(dest)
  assert len(targets)==len(set(targets))
 rows=[sum(row) for row in W];cols=[sum(W[i][j] for i in range(N)) for j in range(N)]
 assert max(rows)<=1 and max(cols)<=1
 rho=[F(R.randint(1,100),R.randint(1,100)) for _ in cells];nu=[F(R.randint(1,100),R.randint(1,100)) for _ in cells]
 paidrho=sum(W[i][j]*rho[i] for i in range(N) for j in range(N));paidnu=sum(W[i][j]*nu[j] for i in range(N) for j in range(N))
 assert paidrho<=sum(rho) and paidnu<=sum(nu)
 return {'cells_per_source':N,'fixed_offsets':[list(k) for k in offsets],'sum_offset_weights':str(sum(weights)),'max_row_allocation':str(max(rows)),'max_column_allocation':str(max(cols)),'paid_rho_fraction':str(paidrho/sum(rho)),'paid_nu_fraction':str(paidnu/sum(nu)),'max_source_budget_violation':'0'}

def cuts(n,m,randomcuts):
 t=[[F(R.randint(0,30),R.randint(1,30)) for j in range(m)] for i in range(n)]
 rows=[sum(row) for row in t];cols=[sum(t[i][j] for i in range(n)) for j in range(m)];total=sum(rows)
 rs=[F(R.randint(0,10),R.randint(1,10)) for _ in range(n)];cs=[F(R.randint(0,10),R.randint(1,10)) for _ in range(m)];es=[[F(R.randint(0,10),R.randint(1,10)) for j in range(m)] for i in range(n)]
 if randomcuts:
  pairs=[(set(i for i in range(n) if R.randrange(2)),set(j for j in range(m) if R.randrange(2))) for _ in range(randomcuts)]
  pairs.extend([(set(),set()),(set(range(n)),set(range(m)))])
 else:pairs=[(set(i for i in range(n) if ib>>i&1),set(j for j in range(m) if jb>>j&1)) for ib in range(1<<n) for jb in range(1<<m)]
 mingap=None
 for I,J in pairs:
  base=sum(rows[i] for i in range(n) if i not in I)+sum(cols[j] for j in J)+sum(t[i][j] for i in I for j in range(m) if j not in J)
  reverse=sum((t[i][j] for i in range(n) if i not in I for j in J),F(0))
  assert base-total==reverse>=0
  slack=sum(rs[i] for i in range(n) if i not in I)+sum(cs[j] for j in J)+sum(es[i][j] for i in I for j in range(m) if j not in J)
  capacity=sum(rows[i]+rs[i] for i in range(n) if i not in I)+sum(cols[j]+cs[j] for j in J)+sum(t[i][j]+es[i][j] for i in I for j in range(m) if j not in J)
  assert capacity-total==reverse+slack>=0
  mingap=capacity-total if mingap is None else min(mingap,capacity-total)
 return {'rows':n,'columns':m,'cuts_checked':len(pairs),'all_cuts_enumerated':not bool(randomcuts),'minimum_slack_capacity_minus_total_flow':str(mingap),'max_exact_cut_decomposition_error':'0','max_cut_violation':'0'}

def ell(A,R,d):return min(A,R,max(F(0),(A+R)/2-abs(d)))
def overlap(shape):
 z=[F(1,2),F(1,4)];R=F(1);v=F(1)
 for A,d in zip(shape,z):v*=ell(A,R,d)/(A*R)
 return v
hard=overlap([F(1),F(1)]);anis=overlap([F(2),F(1,2)]);assert hard==F(3,8) and anis==F(1,2)>hard
settings=[('small',12,[1,2,3],3,2,2,0),('boundary_negative_large',24,[1,4,10,32],10**6,3,4,0),('expanded',36,[1,64,257,1000],10**20,5,20,128)]
stages=[]
for name,count,ns,k,size,cn,randcuts in settings:
 stages.append({'name':name,'offset_probability':grid_stage(count,ns,k),'fractional_matching':matching(size),'bipartite_cut':cuts(cn,cn if not randcuts else 17,randcuts)})
out={'status':'PASS','seed':29120261018,'scope':'Exact finite Fraction translated-grid probabilities, frozen weighted matching source ledgers, overlap columns and finite bipartite cut algebra. No FULL/FIRST/source/history certificate, adaptive width/offset selection theorem, or paid crosscell closure.','offset_sign':'cell_index(z)-cell_index(y)=k','offset_probability':'product_i max(0,1-abs((z_i-y_i)/d_i-k_i))','overlap_column_example':{'hard_shape_1_1':str(hard),'anisotropic_shape_2_half':str(anis),'displacement':['1/2','1/4'],'R':'1','a_equals_b':'1'},'stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
