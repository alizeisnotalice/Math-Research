import json, random
from mpmath import mp
mp.dps=70
rng=random.Random(291)
def H(x,y):
    if not x or not y:return mp.mpf(0)
    m,M=sorted((x,y));return m*(2+mp.log(M/m))
results=[]
for count,span,size in [(8,2,4),(24,20,12),(64,100,32)]:
    err=mp.mpf(0)
    for _ in range(count):
        pairs=[(mp.mpf(rng.randint(0,9))*mp.power(10,rng.randint(-span,span)),mp.mpf(rng.randint(0,9))*mp.power(10,rng.randint(-span,span))) for j in range(size)]
        X=sum(x for x,y in pairs);Y=sum(y for x,y in pairs)
        M=sum(min(x,y) for x,y in pairs);L=X+Y-M
        val=sum(H(x,y) for x,y in pairs)
        if M:
            kl=sum((min(x,y)/M)*mp.log((min(x,y)/M)/(max(x,y)/L)) for x,y in pairs if min(x,y))
            rhs=M*(2+mp.log(L/M))-M*kl
        else: rhs=mp.mpf(0)
        e=abs(val-rhs)/max(1,abs(val),abs(rhs));err=max(err,e)
        assert e<mp.mpf('1e-60')
        assert val<=H(X,Y)+mp.mpf('1e-60')*max(1,H(X,Y))
        hell=2*sum(mp.sqrt(x*y) for x,y in pairs)
        assert val<=hell+mp.mpf('1e-60')*max(1,hell)
    results.append(dict(cases=count,exponents=span,terms=size,max_normalized_error=str(err)))
print(json.dumps(dict(status='PASS',scope='Finite deterministic-seed 70-digit algebra diagnostics, not interval or full-input certificates.',stages=results),indent=2))
