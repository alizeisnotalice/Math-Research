# R508：窄质量窗下原双来源流的近全保留

本稿使用 R507 geometry §3 的原场，不更换完整来源测度：
\[
 d\mu=f\,dx,\quad W=\mu(\mathbb R^n)<\infty,\quad
 m_B=\mu(Q_B)=q_BR_B^n,\quad a\le R_B\le b\le2a,
 \quad q\le q_B\le\lambda,
 \quad d\nu=t(B)q_B\,dB,\quad0\le t\le S.
\]
所有 \(R\) 是边长。记 \(r=\lambda/q\)、\(A_n=1+n\log(b/a)\)、
\(R_\tau=\nu(E)\)，并保原入口 \(R_\tau\le SX\)。本稿证明一个带绝对误差的原流转移，未证明量化余流的根阶总预算。

## 1. 可测量化、窗数与原中心的两笔费用

固定 \(\gamma=1+\eta>1\)，设
\[
 m_-=qa^n,\quad m_+=\lambda b^n,\quad
 N=1+\left\lceil\frac{\log(m_+/m_-)}{\log\gamma}\right\rceil,
 \qquad m_j=\gamma^{j-1}m_-\quad(0\le j<N).
 \tag{1}
\]
唯一选择 \(m_j<m_B\le\gamma m_j\)。只用非空窗，因而 \(0<m_j<m_B\le W\)，不需定义可能不存在的 \(r_W\)。如 R507 §2，固定质量首次达到尺度
\(r_m(B)=\inf\{R>0:\mu(Q(B,R))\ge m\}\)
连续且满足 \(\mu(Q(B,r_m(B)))=m\)。于是
\[
 \widetilde R_B=r_{m_{j(B)}}(B),\quad
 \widetilde Q_B=Q(B,\widetilde R_B)\subset Q_B,\quad
 \widetilde q_B=m_j/\widetilde R_B^n,\quad
 \theta_B=m_j/m_B\in[\gamma^{-1},1)
 \tag{2}
\]
均可测，且 \(\widetilde q_B\ge q_B/\gamma\)。窗数明确为
\[
 N\le2+\frac{\log r+n\log(b/a)}{\log(1+\eta)}
 \le2+\frac{1+\eta}{\eta}\,[\log r+n\log(b/a)].
 \tag{3}
\]
这不是维数无关窗数；逐窗支付 \(W\) 仍会产生该因子。

取 \(M\ge1\)。先删除 \(E_s=\{\widetilde R<a\}\)，再删除
\(E_p=\{\widetilde R\ge a,\ \widetilde q>Mq_B\}\)。保持原 \(\nu\)，有
\[
 \nu(E_s)\le\gamma SW,\qquad
 \nu(E_p)\le SA_nW/M.                                      \tag{4}
\]
证明：在第一集合上 \(\mu(Q(B,a))/a^n\ge q_B/\gamma\)，积分固定边长平均得第一式；在第二集合上
\(tq_B\le(S/M)\widetilde q\)。所有窗先合成同一个实际选择器 \(\widetilde R\in[a,b]\)，由 R507 的单来源中心积分界
\(\int1_{\widetilde Q_B}(x)\widetilde R_B^{-n}dB\le A_n\)
及 Tonelli 得第二式。两式均只收一次，没有 \(N\) 或额外 \(r\)。

余中心集 \(E_*\) 满足
\[
 a\le\widetilde R_B\le b,\quad q/\gamma\le\widetilde q_B\le M\lambda,
 \quad \frac{\widetilde R_B}{R_B}\ge(\gamma M)^{-1/n},
 \quad \log\frac{R_B}{\widetilde R_B}\le\frac{\log(\gamma M)}n.
 \tag{5}
\]
新密度带比为 \(\gamma Mr\)。保持全部原中心质量的重写为
\(d\nu=\widetilde t\widetilde q_BdB\)，其中
\(\widetilde t=tq_B/\widetilde q_B\le\gamma S\)。不能把新带比的维数增长隐藏在常数中。

## 2. 两来源与全部旧历史的精确正测度分解

设原完整记录的基底为
\[
 d\mathcal B=\nu(dB)\pi_B(dx)\pi_B(dz)\,
 \mathcal H_{B,x,z}(d\omega),\qquad
 d\mathcal P=L(B,x,z,\omega)d\mathcal B,\quad0\le L\le1.
 \tag{6}
\]
\(\mathcal H\) 是原条件历史概率核；它可依赖 \(B,x,z\)。若原记录只有次概率条件核，可加一个拒绝标签使之成为概率核。此处在原标准 Borel 记录空间作条件分解，不宣称历史独立。所有计算也可先将 \(L\) 条件平均，再用原条件历史核拉回。

令 \(\widetilde\pi_B=1_{\widetilde Q_B}\mu/m_j\)。关键是
\[
 1_{\widetilde Q_B}\pi_B=\theta_B\widetilde\pi_B,
 \qquad
 d\mathcal P_{\rm keep}
 =1_{E_*}(B)L\,\theta_B^2\nu(dB)
       \widetilde\pi_B(dx)\widetilde\pi_B(dz)
       \mathcal H_{B,x,z}(d\omega).
 \tag{7}
\]
右侧保留原 \(L,\mathcal H\)，它就是左侧原记录的正限制
\(1_{E_*}1_{\widetilde Q_B}(x)1_{\widetilde Q_B}(z)\mathcal P\)。没有为新盒生成历史，也没有把被删流归一化回去。

两来源密度的精确抵消进一步给
\[
 d\nu_{\rm keep}=\theta_B^2d\nu=t_{\rm keep}\widetilde q_BdB,
 \quad
 t_{\rm keep}=t\theta_B\left(\frac{\widetilde R_B}{R_B}\right)^n
 \le S.                                                     \tag{8}
\]
因此实际保留的双来源基底具有量化盒完整后验，同时中心系数仍不超过原 \(S\)，而非 \(\gamma S\)。未乘 \(\theta_B^2\) 的 \(\nu\widetilde\pi_B^2\) 不是这条原子流。

对任意可测来源集 \(D\)，保留基底的第一来源列为
\[
 \int_{E_*}\theta_B^2\nu(dB)\widetilde\pi_B(D)
 =\int_{E_*}\theta_B\nu(dB)\pi_B(D\cap\widetilde Q_B)
 \le\int_E\nu(dB)\pi_B(D).                                 \tag{9}
\]
第二来源相同，加入 \(L\le1\) 后仍成立。这里不将已有原来源列再声称为 \(O(W)\) 新价格。

在未删中心上，因原双来源独立于给定父后验的抽取结构，基底保留概率恰为 \(\theta_B^2\)。故任意原 gate 都有
\[
 0\le\mathcal P(E_*\text{上的全部记录})-|\mathcal P_{\rm keep}|
 \le\int_{E_*}(1-\theta_B^2)d\nu
 \le(1-\gamma^{-2})R_\tau\le2\eta SX.                        \tag{10}
\]
这是绝对正测度误差。\(L\) 可以只在被删部分取 1，此时被接受流的相对损失为 100%；不允许写成相对误差 \(\le2\eta\)。

## 3. 与原完整硬积分的直接连接及停止判据

记 \(R_L=|\mathcal P|\)。取 \(M=\max\{1,A_n/\sqrt n\}\)，式 (4)、(7)、(10) 在互斥记录部分上给
\[
 \boxed{R_L\le S(\gamma+\sqrt n)W
        +(1-\gamma^{-2})R_\tau+|\mathcal P_{\rm keep}|.}       \tag{11}
\]
若本入口允许误差 \(\varepsilon_{\rm loc}X\)，\(S>0\) 时可选
\(0<\eta\le\varepsilon_{\rm loc}/(2S)\)。若整条母账将此入口乘以已知常数 \(C_{\rm in}>0\)，应选
\(\eta\le\varepsilon_{\rm global}/(2C_{\rm in}S)\)，并把 (4) 同样乘 \(C_{\rm in}\)。\(S=0\) 时全流为零。两笔已付中心分支与来源删流均只入账一次。

式 (7)—(8) 是近全保留提供的具体正信息：**原硬积分本身**，包括旧 high-rank、low-common、路径及所有非连续指示门，可在匹配量化盒的完整双来源后验上精确表示；原门不须有连续性，中心权仍为 \(\le S\)。对任何固定可测记录测试 \(0\le F\le1\)，同一分解仍以 (10) 控制被删部分，并且保留项中 \(F\) 的值完全不变。因此不必先证明硬门对半径变化稳定，才可进行保留流上的积分换序。

但此信息只保留**旧门作为标签**：旧时钟、旧质量及外部见证盒不变。若后续论证要求这些门是由 \(\widetilde Q_B,m_j\) 重新生成的，则 (7) 不提供该资格。例如仅有尺度贴近 (5)，并不能使任意外部来源捕获门保持相同。对全部父均量化的纯质量比较，能无额外假设推出的仅是
\(m_A>K m_B\Rightarrow\widetilde m_A>(K/\gamma)\widetilde m_B\)；原阈值 \(K\) 不可默默保留。

固定质量的几何变换仍只能逐窗使用，其图像跨窗重复未由 (7) 控制。窄窗使 (10) 可吸收，但也使 (3) 的 \(N\) 增长。故本稿的停止点是：完整旧门已可带可付绝对误差进入真实量化后验，尚缺对该保留流的跨窗共同来源预算；没有证明 \(|\mathcal P_{\rm keep}|\) 已有根阶费用。

## 4. 本机精确检查（内嵌复现）

第一阶段检查不对称 gate、全部 gate、只接受删流的 gate；第二阶段是实际连续中心与完整来源的一维模型：\(f=1_{[-2,2]}\)、\(B\in[-1/4,1/4]\)、\(R_B=1,t=q_B=1\)，量化边长 \(\theta\)，因此所有质量与来源列都是真实 Lebesgue 积分。该模型只验证局部接口，不声称实现原完整历史。第三阶段核质量窗端点、保留系数与体积比界。代码只使用有理数；其有限通过不替代上述一般证明。

```python
from fractions import Fraction as F

counts = [0, 0, 0]
def ck(ok, stage):
    assert ok
    counts[stage] += 1

# 1. Original product probabilities, including asymmetric inherited gates.
for gamma in (F(11,10), F(3,2), F(2)):
    for theta in (1/gamma, (1+1/gamma)/2):
        p = [theta/3, 2*theta/3, 1-theta]
        pt = [F(1,3), F(2,3), F(0)]
        gates = [
            [[F(1) for j in range(3)] for i in range(3)],
            [[F((i+2*j)%4,3) for j in range(3)] for i in range(3)],
            [[F(i == 2) for j in range(3)] for i in range(3)],
        ]
        for gate in gates:
            old = sum(p[i]*p[j]*gate[i][j] for i in range(3) for j in range(3))
            keep = sum(p[i]*p[j]*gate[i][j] for i in range(2) for j in range(2))
            rewrite = theta**2*sum(pt[i]*pt[j]*gate[i][j]
                                   for i in range(3) for j in range(3))
            ck(keep == rewrite, 0)
            ck(0 <= old-keep <= 1-theta**2 <= 1-gamma**-2, 0)
        ck(old > 0 and keep == 0, 0)  # accepted relative loss is exactly one
        ck(1-gamma**-2 <= 2*(gamma-1), 0)

# 2. Continuous-center field: f=1[-2,2], B in [-1/4,1/4], R=1.
def length(l, r):
    return max(F(0), r-l)
def column(z, side):
    return length(max(-F(1,4), z-side/2), min(F(1,4), z+side/2))
nu_mass = F(1,2)
for theta in (F(10,11), F(2,3)):
    ck(theta**2*nu_mass + (1-theta**2)*nu_mass == nu_mass, 1)
    ck(theta**2 == theta * theta, 1)  # t_keep=t*theta*(Rtilde/R)^1
    # Each column is an exact intersection length, not point quadrature.
    for z in (F(-3,4), F(-1,2), F(0), F(1,2), F(3,4)):
        ck(theta*column(z,theta) <= column(z,F(1)), 1)
    old_outer_gate = (1-theta)*nu_mass
    ck(old_outer_gate > 0, 1)
    ck(old_outer_gate <= (1-theta**2)*nu_mass, 1)

# 3. Window boundaries and the true retained density coefficient.
for gamma in (F(11,10), F(3,2), F(2)):
    lower = [gamma**(j-1) for j in range(5)]
    samples = [gamma**j for j in range(5)]
    samples += [(gamma**j+gamma**(j+1))/2 for j in range(4)]
    for mass in samples:
        hits = [m for m in lower if m < mass <= gamma*m]
        ck(len(hits) == 1, 2)
        theta = hits[0]/mass
        ck(1/gamma <= theta < 1, 2)
    for theta in (1/gamma, (1+1/gamma)/2):
        for peak in (F(1), F(3)):
            for volume_ratio in (theta/peak, (1+theta/peak)/2):
                qratio = theta/volume_ratio
                tkeep = theta**2/qratio
                ck(tkeep == theta*volume_ratio <= 1, 2)
                ck(1/gamma <= qratio <= peak, 2)
                ck(volume_ratio >= 1/(gamma*peak), 2)
print('PASS', sum(counts), 'exact checks; stages:', *counts)
print('Stage 2 uses actual continuous centers and full interval source; no original history claim.')
```

实际标准输出与解释器记录见 r508_replay.json；只将实际运行结果计为证据。


## 5. 有界硬核的费用必须显式继承

前述式(6)—(11)适用于被原双来源基底支配、gate不超过1的记录质量。若目标实际是带额外硬核 H 的积分，且仅有 \(0\le H\le H_*<\infty\)，则对同一原记录保留 H 的值，完整比较变为
\[
J_H\le H_*S(\gamma+\sqrt n)W
 +H_*(1-\gamma^{-2})R_\tau+J_{H,\rm keep}.
\]
两笔中心删除的质量价格也须乘 H_*，不能只给来源删除项补帽。若旧母账已单独支付这些中心支，使用那份真实收据而不重复入账；未核验前不声称已有收据覆盖它们。

原母入口倍数为 C_in 时，为使来源删除误差至多 ε_global X，可在 S H_*>0 时取 η≤ε_global/(2 C_in S H_*)。H_*或C_in随维数的依赖必须保留。此处不猜测 Φ_max 的可用量级，若其作为 H_* 使用，须从旧完整合同核实；若无有限帽，就保实际删除积分而不套这个误差式。新窗数N及后续壳分配系数γ²/(γ−1)均随该η选择变化。

本轮证明一个正测度限制及其明确误差，不证明保留后的硬流已满足量化新父生成的几何门，不证明完整 J_H 或一般上界已闭合。
