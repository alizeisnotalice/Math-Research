# R508 独立预审：细质量量化的真实双来源限制

先于任何 R508 作者证明。保完整μ、原单选择器及 \(\nu=tq_BdB\)、\(t\le S\)。下述所有来源限制都在原 \(\nu(dB)\pi_B(dx)\pi_B(dz)\) 上进行；历史的原条件律作为标签保留，不重新生成。

## 1. 正确的是绝对原父损失，不是已接受流的相对损失

取γ=1+η>1，以 \(m_j<m_B\le\gamma m_j\) 选层；可取 \(m_j=\gamma^{j-1}qa^n\)、\(N=1+\lceil\log_\gamma[ r(b/a)^n]\rceil\)。只用非空层，故 \(0<m_j<m_B\le W\)，逆质量半径存在，且真实 \(\widetilde Q_B\subset Q_B\)、\(\mu(\widetilde Q_B)=m_j\)。令 \(\theta_B=m_j/m_B\in[\gamma^{-1},1)\)。准确子测度恒等式为
\[
\pi_B|_{\widetilde Q_B}=\theta_B\widetilde\pi_B,
\quad
(\pi_B\otimes\pi_B)|_{\widetilde Q_B^2}
=\theta_B^2\widetilde\pi_B\otimes\widetilde\pi_B.
\tag{1}
\]
对任意原非负history gate G≤1，保原条件历史分布 \(C(dh\mid B,x,z)\)，保留量准确是
\[
\theta_B^2\nu(dB)\widetilde\pi_B(dx)\widetilde\pi_B(dz)
\,C(dh\mid B,x,z)G(B,x,z,h).
\]
同一原gate删除的**绝对**质量≤\(\int(1-\theta_B^2)d\nu\le(1-\gamma^{-2})R_\tau\)。没有证明其≤\((1-\gamma^{-2})\int G\,d(\nu\pi_B^2C)\)：gate可只接受删掉的来源部分。

如果原hard integral另含核H，该结论须补核帽。\(0\le H\le K_H\) 时损失≤\(K_H(1-\gamma^{-2})R_\tau\)；有符号测试须用绝对帽。无该帽则只能保实际删除积分，不能从纯概率限制免费推出相同数值误差。尤其原J若只知H≤Φ_max，必须保Φ_max，除非它已经真实吸收进给定原测度。若沿原 \(X=\int_Eq_BdB\)，则进一步误差≤\(K_HS(1-\gamma^{-2})X\)，母倍率也须计入选η。不能把η直接当最终ε，或漏掉因此增加的 \(N\asymp(\log r+n\log(b/a))/\log\gamma\) 费用。

## 2. 两支付款、剩余场参数和使用入口

\(\widetilde R=r_{m_j}(B)\le R_B\)，\(\widetilde q\ge q_B/\gamma\)。小半径 \(\widetilde R<a\) 上，\(g_a\ge q_B/\gamma\)，全部层一次付 \(\gamma SW\)。其补集的 \(\widetilde q>Mq_B\) 上，保原q_B得 \(SA_nW/M\)，因为先合成同一B选择器再作来源层蛋糕。取 \(M=\max(1,A_n/\sqrt n)\) 即两项互斥合计≤\(S(\gamma+\sqrt n)W\)，不乘N或r。

余支仍是原ν的精确中心重写：
\[
a\le\widetilde R\le b,\quad q/\gamma\le\widetilde q\le M\lambda,
\quad\widetilde t=tq_B/\widetilde q\le\gamma S,
\quad0\le\log(R_B/\widetilde R)\le\log(\gamma M)/n.
\tag{2}
\]
新带比γMr随参数增长，不能视作原fixed-r常数。直接Rτ入口可使用该真实新场；用于旧hard integral则必须用(1)保θ²、旧gate与条件历史，并付已删源误差。中心分支收据不能在原Rτ与其hard子量中重复记账。

## 3. 固定u的逆质量盒确实嵌套，但只给特定层间控制

固定 \(u\in[-1/2,1/2]^n\)、\(0\le\delta<1\)、目标中心Y。定义
\[
C_s(Y)=Q(Y-\delta s u,s)
=Y+s([-1/2,1/2]^n-\delta u).
\]
每个坐标的两侧系数异号，故C_s随s嵌套，且
\(Q(Y,(1-\delta)s)\subset C_s\subset Q(Y,(1+\delta)s)\)。其质量从0连续增至W。对0<m<W，首次质量半径 \(s_m(Y)\) 满足 \(\mu C_{s_m}=m\)。它正是
\[
s=r_m(Y-\delta s u),\quad B_m=Y-\delta s_m u
\tag{3}
\]
的唯一解：r_m的2-Lipschitz性使右边对s为δ-contraction；若更小t已达到m，则r_m(Y−δtu)≤t，与该δ收缩和固定点s>t矛盾。因此这是固定质量T_u的真正逆，而非另选了来源代表。

同一Y,u的质量盒C_j因而嵌套。相邻质量比γ时，其来源概率的半L1距离准确为 \(1-1/\gamma\)，双来源概率则为 \(1-1/\gamma^2\)；层增量 \(C_{j+1}\setminus C_j\) 互斥。若z首次进入第k层，\(\sum_{j\ge k}1_{C_j}(z)/m_j\le\gamma/[(\gamma-1)m_k]\)。这是可用的点态几何尾，不是免费总列：对μ积分，\(\int\sum_j1_{C_j}/m_j=N\) 仍准确保留层数。

该嵌套不自动限制原分层中心图像的重叠重数。Y固定时各旧父为不同的B_j，实际相对来源位置、t、gate/history也随j变化；旧后验权例如 \(f(B_j+r_{m_j}(B_j)u)\) 不能改成同一固定μ列。上述TV比较只有对同一来源测试／共同参考才可用，不能对不同旧父的接受条件直接望远镜。要取得全价，必须证明这些原权下的图像/来源重复可按层增量共同结算，或给一个有价signed补偿；单独Jacobian与嵌套尚未给此桥。

本机实际运行 `/tmp/r508_audit_math_check.py` 的6项SymPy恒等式：双来源限制、γ误差、嵌套质量TV、逆盒中心与两端点。只是代数，不认证accepted-relative误差、原history或全局层间费用。独立预审交付后等待作者。
