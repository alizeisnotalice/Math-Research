# R508：逆质量盒的嵌套与全层联合来源分配

本稿针对剩余中心集上的完整接收质量，构造跨质量层的一个正分配。它确实避免先把每个质量层分别付一遍 W；但当前来源列仍只有线性于 n 的上界，不宣称根阶付款。分配使用新的辅助来源，不能当作原双来源历史律。

## 1. 冻结原场与质量层

令 μ=f dx，f≥0且W<∞，n≥1；原真实中心B∈E，a≤R_B≤b≤2a，m_B=μQ(B,R_B)=q_BR_B^n，q≤q_B≤λ，ν=tq_BdB，0≤t≤S。以γ>1的相邻绝对质量m_j分片，使m_j<m_B≤γm_j，并令E_j为这些互不相交的原中心片。可以再将E限制到R508 proof所述的余中心集E_*；下文所有E_j采用同一个限制。

只使用非空片及其以下必要的质量标签，均有0<m_j<W。最低层的前驱也定义为m_j/γ，不需要它有对应接收者。固定质量半径r_m(B)是连续、正且有限的首次达到半径，μQ(B,r_m(B))=m，且|r_m(B)−r_m(C)|≤2||B−C||∞。这些是R098/R507已证工具。

固定u∈[-1/2,1/2]^n和0≤δ<1，定义T_j(B)=B+δr_mj(B)u。扰动Lipschitz常数≤δ，因此T_j全局双Lipschitz、存在唯一逆，几乎处处Jacobian
\[
J_j(B)=1+\delta u\cdot\nabla r_{m_j}(B)\in[1-\delta,1+\delta].
\]
任意零测集上的J_j值可取1，面积公式不受影响。

## 2. 同一目标中心处的逆盒确实嵌套

固定Y，记B_j=T_j^{-1}Y，s_j=r_mj(B_j)。则B_j=Y−δs_j u，因而
\[
C_j(Y)=Q(B_j,s_j)=Y+s_j([-1/2,1/2]^n-\delta u).
\]
括号内的凸盒含原点于内部，因此C_s(Y)随s单调嵌套，质量对s连续，从0趋于W。

s_j正是该嵌套族首次达到质量m_j的半径：它已经有正确质量；若t<s_j也达到m_j，则r_mj(Y−δtu)≤t，利用2-Lipschitz性得到
\[
s_j\le t+\delta(s_j-t)<s_j,
\]
矛盾。故随j递增，s_j递增，C_j嵌套。质量平台不造成问题，因为这里使用首次达到半径且各m_j严格不同。

定义真实来源壳
\[
\Sigma_j(Y)=C_j(Y)\setminus C_{j-1}(Y),\qquad
\mu(\Sigma_j(Y))=(1-1/\gamma)m_j.
\]
对每个固定(Y,u,x)，至多一个壳指示为1。此性质是来源壳的互斥，不等于各T_j(E_j)图像互斥。

## 3. 保真实需求的联合分配

原第j片推前的实际需求密度为
\[
a_j(Y)=1_{E_j}(B_j)\,t(B_j)q_{B_j}/J_j(B_j).
\]
置
\[
d\mathcal A_u(Y,x)=\sum_j a_j(Y)
 \frac{1_{\Sigma_j(Y)}(x)}{(1-1/\gamma)m_j}\,dY\,d\mu(x).
\tag{A}
\]
所有量可测，和有限，Tonelli合法。对x积分准确得到Σ_j a_j(Y)dY，故总质量为ν(E)。没有以不明归一因子改变需求，也没有把Lebesgue中心测度换成代表点计数。

式(A)可以保原中心B_j及其质量、阶段作为旧标签，但其新来源x是壳上的条件测度，不是旧π_B。对直接接收质量目标这是合法辅助分配；用于旧硬历史流时必须另证保原来源、旧gate与该壳测度之间的比较。不能仅凭正分配存在而宣布原历史已迁移。

## 4. 两种互斥同时保留的来源列，以及当前合法上界

来源列K_u(x)=d(\mathcal A_u)_x/dμ的精确公式是
\[
K_u(x)=\frac{\gamma}{\gamma-1}\sum_j\int
 \frac{1_{E_j}(B_j)t(B_j)q_{B_j}}{m_jJ_j(B_j)}
 1_{\Sigma_j(Y)}(x)\,dY.
\tag{K1}
\]
在每一j内换回Y=T_j(B)，dY=J_j(B)dB，Jacobian严格消去：
\[
K_u(x)=\frac{\gamma}{\gamma-1}\sum_j\int_{E_j}
 \frac{t(B)q_B}{m_j}1_{\Sigma_j(T_jB)}(x)\,dB.
\tag{K2}
\]
注意内壳仍是Σ_j(T_jB)，不能擅自替换为与B同心的两盒之差。

其外盒恰为C_j(T_jB)=Q(B,r_mj(B))⊂Q(B,R_B)。因此保m_B/m_j≤γ，再用原E_j互斥，得
\[
0\le K_u(x)\le\frac{\gamma^2}{\gamma-1}
 \int_E t(B)R_B^{-n}1_{Q_B}(x)dB
 \le\frac{\gamma^2}{\gamma-1}S A_n,
\quad A_n=1+n\log(b/a).
\tag{K3}
\]
最后一步对固定来源x积分原立方体核的单比例带包络；a内核积分为1，a至b的壳积分为n log(b/a)。这里没有另加质量层数N、带比r、峰值阈值M或(1−δ)^{-1}。不需要把移动内壳视为同心；不需要来源密度上帽。

任意独立人工u概率分布，包括单位盒上的均匀分布，均可平均(A)—(K3)。其作用仅是构造直接需求的辅助分配；一般f下均匀u不是原相对后验。

γ=2时，(K3)系数为4。γ=1+η时系数为(1+η)^2/η：窄窗保原来源所需的小η，在这里仍会留下逆η费用。这比逐层付W明确消除了N，但并未把A_n变成sqrt(n)。不能把质量守恒∫K_u dμ=ν(E)重新称作来源预算。

真正待证的是在(K1)/(K2)保留原E_j门及移动壳门后，其同一μ积分能否获得额外几何节省，或同原硬流是否存在有价比较。本稿没有构造该根阶节省。已得到的双互斥分配是正几何结构，尚不能替代一般上界证明。

## 5. 最小精确代数核验

下列核验只检查嵌套端点、壳质量归一化、Jacobian消去系数；一般结论由上述解析证明给出。一维真实连续场的完整来源列由独立numeric附件计算。

```python
from fractions import Fraction as F
count=0
for delta in (F(0),F(1,4),F(3,4)):
 for u in (F(-1,2),F(0),F(1,2)):
  left=-F(1,2)-delta*u; right=F(1,2)-delta*u
  assert left<0<right; count+=1
  assert 2*left<=left<right<=2*right; count+=1
for gamma in (F(11,10),F(3,2),F(2)):
 m=F(3); shell=m-m/gamma
 assert shell>0 and (gamma/(gamma-1)/m)*shell==1; count+=1
 for J in (F(1,2),F(1),F(3,2)):
  t=F(2); q=F(5); a=t*q/J
  assert gamma*a/(gamma-1)/m*J==gamma*t*q/((gamma-1)*m); count+=1
 assert gamma/(gamma-1)*gamma==gamma*gamma/(gamma-1); count+=1
print('PASS',count,'exact nested-endpoint and shell-normalization identities; not a global root bound')
```
