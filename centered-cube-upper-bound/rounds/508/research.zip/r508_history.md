# R508 bounded history index: narrow mass windows, random grids, and nesting

**R430 is the closest prior payment for a narrow mass window, but its scope is a specific paired-parent flow.** `rounds/430/README.md` and `research.zip:r430_main.md` §4 (excerpt lines 75–101) take (H_{mass}=\max(\kappa_jm_w,\kappa_km_u)), then pay the disjoint actual event (H_{mass}<m_A\le e^B H_{mass}). The estimate uses (\rho_x\{L\le m_A\le U\}\le[1+\log(U/L)]/q), preserves atoms, and charges both old/new terminal labels. This is structurally the log-width window (m_j<m_B\le\gamma m_j) with width (B=\log\gamma), but it is not a general quantile-bin theorem for arbitrary source pairs. The R430 README and §5 state the remaining flow still has cross-parent, cross-source and cross-mass-layer constraints with no one-time root-order budget.

**R381 has already done source-adaptive closed windows and path-merge accounting.** `rounds/381/README.md`; `research.zip:r381_tree.md` §§2–4 (excerpt lines 27–98) proves for anchors (L(y)\le U(y)) a complete-window receipt costing at most
\[
q_-^{-1}\int f(y)b(y)[1+\log(U(y)/L(y))]dy,
\]
and an alternative soft receipt; the exact finite-tree path charge is source-mass entropy (E_T=\sum_{N,C}M_C\log(M_N/M_C)\), not receiver-clock telescoping. Its between-leaf/root ratio has a square-root retention bound. README explicitly leaves narrow-window coverage/window-outside cost and source-tree entropy control unresolved. This is substantial overlap with quantization + merge-before-charge; it does not prove the proposed two-source θ² retention for the new nested inverse boxes.

**R341 has already proved a shared random-grid retention identity for actual traffic.** `rounds/341/README.md`; `research.zip:geometry.md` §§“One common grid” and “Exact retained fraction” (excerpt lines 33–55, 109–135) use one common random shift and show the actual pair ((u,y)) lands in the same source cell with probability
\[
s_L(u,y)=\prod_i(1-|u_i-y_i|/L)_+\ge(1-1/(2n))^n\ge1/2
\]
when (y\in Q_u), (R_u\le b), (L=nb). Tonelli preserves that fraction of the original traffic and yields the stated fee. It is one-source-cell retention for a long grid; the excerpt explicitly says the universal retention can be exponentially small for a genuinely short grid (L\asymp b). It does not establish a two-source θ² bound under coupled quality quantization.

**Fixed-(u) inverse-box nesting is not located as the same result.** The keyword search hits R372’s README, which proves actual nested cube-shell certificates and a restricted same-scale three-cube price class, but says the next direction is异尺度共同覆盖; no fixed-(u) inverse-image family or quality-layer cost is stated there. R014’s README mentions inverse images/Jacobians only for fixed (n=1), a bounded window and finitely many winner branches, so it is not evidence for the proposed nested (Q(Y-\delta s u,s)) family. The elementary nesting claim may be compatible with these records, but it does not supply a source-conserving cumulative fee.

**Boundary / no duplication.** Narrow-window price, source-path entropy, and one-grid pair retention are each already proved under the displayed contracts. No inspected record combines them to show (i) θ²≥γ⁻² for two source labels simultaneously, (ii) a fixed-(u) inverse-image nesting across all quantized (s), and (iii) a summed source cost over those layers while retaining the original gates. R430 expressly leaves the cross-layer/source budget open; R381 leaves window coverage/outside price and entropy control open; R341 leaves the short-grid actual-average transport beyond its universal factor open. Do not add these separate receipts as one new estimate or call them a global payment.

**Read scope.** Searched only `rounds/*/README.md` for the requested keywords. Opened exactly three archive excerpts: R381 `r381_tree.md` lines 1–98; R430 `r430_main.md` lines 1–13 and 75–101, 114–143; R341 `geometry.md` lines 1–31, 33–56, 101–155. No other archive content was opened; this is a historical index, not a math audit.
