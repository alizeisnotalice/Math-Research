#!/usr/bin/env python3
"""R508 exact 1D continuous-source shell allocation and source columns."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,time,platform
import sympy as sp
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0

def ck(z):
 global checks
 assert bool(z)
 checks+=1

def aa(x):
 x=Q(x);return arb(x.numerator)/x.denominator

def addterm(p,power,k,c):
 key=(power,k);p[key]=p.get(key,Q(0))+c
 if p[key]==0:del p[key]

def addprofile(a,b,scale=Q(1)):
 out=a.copy()
 for (power,k),c in b.items():addterm(out,power,k,scale*c)
 return out

def overlap_profile(a,b,s):
 p={}
 for k,c in [(a-s/2,1),(b-s/2,-1),(a+s/2,-1),(b+s/2,1)]:addterm(p,1,k,Q(c))
 return p

def profile_value(p,x):return sum((c*max(Q(0),x-k)**power for (power,k),c in p.items()),Q(0))

def average_shift(p,d):
 out={}
 for (power,k),c in p.items():
  assert power==1
  addterm(out,2,k-d/2,c/(2*d));addterm(out,2,k+d/2,-c/(2*d))
 return out

def grid(gamma,beta):
 s=beta
 while s>1:s/=gamma
 rows=[]
 while s<2:
  a=max(Q(0),s-1);b=min(Q(1),gamma*s-1)
  if a<b:rows.append({'a':a,'b':b,'s':s,'previous':s/gamma})
  s*=gamma
 return rows

def profiles(rows,delta):
 uni={};shell={}
 for z in rows:
  a,b,s,old=z['a'],z['b'],z['s'],z['previous'];diff=s-old
  outer=overlap_profile(a,b,s)
  uni=addprofile(uni,outer,1/s)
  inner=average_shift(overlap_profile(a,b,old),delta*diff)
  shell=addprofile(shell,outer,1/diff)
  shell=addprofile(shell,inner,-1/diff)
 return uni,shell

def length(a,b,l,r):return max(Q(0),min(b,r)-max(a,l))

def independent_value(rows,delta,x):
 out=Q(0)
 for z in rows:
  a,b,s,old=z['a'],z['b'],z['s'],z['previous'];diff=s-old;d=delta*diff
  pts=sorted({Q(-1,2),Q(1,2),*[u for k in [a-old/2,b-old/2,a+old/2,b+old/2] if Q(-1,2)<(u:=(x-k)/d)<Q(1,2)]})
  def val(u):return length(a,b,x-d*u-old/2,x-d*u+old/2)
  inner=sum(((hi-lo)*(val(lo)+val(hi))/2 for lo,hi in zip(pts,pts[1:])),Q(0))
  out+=(length(a,b,x-s/2,x+s/2)-inner)/diff
 return out

def certify_profile(p):
 if not p:return {'mass':'0','max':'0','min':'0','max_at':'0','pieces':[]}
 points=sorted({k for power,k in p});pieces=[];integral=Q(0);candidates=[]
 for lo,hi in zip(points,points[1:]):
  mid=(lo+hi)/2;A=B=C=Q(0)
  for (power,k),coeff in p.items():
   if k<mid:
    if power==1:A-=coeff*k;B+=coeff
    else:A+=coeff*k*k;B-=2*coeff*k;C+=coeff
  integral+=A*(hi-lo)+B*(hi**2-lo**2)/2+C*(hi**3-lo**3)/3
  evalpoly=lambda x:A+B*x+C*x*x
  cand=[lo,hi]
  if C and lo<(-B/(2*C))<hi:cand.append(-B/(2*C))
  candidates.extend((evalpoly(x),x) for x in cand)
  pieces.append({'interval':[str(lo),str(hi)],'coefficients_constant_linear_quadratic':[str(A),str(B),str(C)]})
  assert evalpoly(mid)==profile_value(p,mid)
 maxval,maxat=max(candidates);minval,minat=min(candidates)
 # Outside the listed breakpoints, exact zero by physical compact support.
 assert profile_value(p,points[0]-1)==profile_value(p,points[-1]+1)==0
 return {'mass':str(integral),'max':str(maxval),'min':str(minval),'max_at':str(maxat),'pieces':pieces}

def image_pair_overlap(i,j,delta):
 lines=[(i['a'],delta*i['s']),(i['b'],delta*i['s']),(j['a'],delta*j['s']),(j['b'],delta*j['s'])]
 points={Q(-1,2),Q(1,2)}
 for k in range(4):
  for l in range(k):
   a,b=lines[k];c,d=lines[l]
   if b!=d:
    u=(c-a)/(b-d)
    if Q(-1,2)<u<Q(1,2):points.add(u)
 def at(u):return length(i['a']+delta*i['s']*u,i['b']+delta*i['s']*u,j['a']+delta*j['s']*u,j['b']+delta*j['s']*u)
 points=sorted(points)
 return sum(((b-a)*(at(a)+at(b))/2 for a,b in zip(points,points[1:])),Q(0))

def info(p):return [{'power':power,'knot':str(k),'coefficient':str(c)} for (power,k),c in sorted(p.items())]

def main():
 start=time.perf_counter()
 x,k,d=sp.symbols('x k d',positive=True)
 ck(sp.diff((x-k)**2/2,x)==x-k)
 ck(sp.simplify(((x-k+d/2)**2-(x-k-d/2)**2)/(2*d)-(x-k))==0)
 cases=[];mixtures=[]
 for delta in [Q(1,4),Q(1,16)]:
  for gamma in [Q(2),Q(3,2),Q(9,8)]:
   phase_profiles=[]
   for name,beta in [('phase_1',Q(1)),('phase_mid',(1+gamma)/2)]:
    rows=grid(gamma,beta);mass=sum((z['b']-z['a'] for z in rows),Q(0))
    ck(mass==1)
    ck(all(z['s']<2 and z['s']<=1+z['a'] and 1+z['b']<=gamma*z['s'] for z in rows))
    ck(all((1-delta)*(z['s']-z['previous'])/2>0 for z in rows))
    uni,shell=profiles(rows,delta);U=certify_profile(uni);H=certify_profile(shell)
    ck(Q(U['mass'])==Q(H['mass'])==1)
    ck(Q(U['min'])>=0 and Q(H['min'])>=0)
    # Whole source support contained [-3,3], all parent and quantized cubes are interior.
    ck(all(abs(z['a'])+z['s']/2<3 and abs(z['b'])+z['s']/2<3 for z in rows))
    audit=[Q(-1),Q(0),Q(1,2),Q(1),Q(2),Q(H['max_at'])]
    ck(all(profile_value(shell,x)==independent_value(rows,delta,x) for x in audit))
    imageL2=sum((image_pair_overlap(i,j,delta) for i in rows for j in rows),Q(0))
    ck(imageL2>=1)
    ck(imageL2==1+delta*(rows[-1]['s']-rows[0]['s'])/4)
    eta=1-1/gamma
    ck(Q(H['max'])<=Q(U['max'])/eta)
    remrows=[z for z in rows if z['s']>=1]
    remmass=sum((z['b']-z['a'] for z in remrows),Q(0))
    Ur,Hr=profiles(remrows,delta);hr=certify_profile(Hr)
    ck(Q(hr['mass'])==remmass and Q(hr['min'])>=0)
    phase_profiles.append(shell)
    cases.append({'phase':('initial' if gamma==2 else ('mass-window/phase pressure' if gamma==Q(3,2) else 'finer mass windows')),'delta':str(delta),'gamma_mass_ratio':str(gamma),'beta':str(beta),'phase_label':name,'eta_shell':str(eta),'crude_inverse_shell_fee':str(1/eta),'actual_receiver_mass':'1','actual_receiver_volume':'1','source_W':'6','source_qband':'q=lambda=1','mass_layer_count':len(rows),'image_multiplicity_L2_integrated_u_Y':str(imageL2),'image_excess_over_input_mass':str(imageL2-1),'layers':[{key:str(v) for key,v in z.items()} for z in rows],'uniform_quantized_column':U,'shell_column':H,'shell_profile':info(shell),'shell_peak_arb':str(aa(Q(H['max']))),'peak_vs_crude_inverse_eta':str(Q(H['max'])*eta),'discard_small_radius_mass':str(1-remmass),'remaining_receiver_mass':str(remmass),'remaining_shell_column':hr,'remaining_scope':'small-radius positive branch removed explicitly; no peak branch since qtilde=q=1'})
   mix=addprofile({},phase_profiles[0],Q(1,2));mix=addprofile(mix,phase_profiles[1],Q(1,2));m=certify_profile(mix)
   ck(Q(m['mass'])==1 and Q(m['min'])>=0)
   pair=cases[-2:]
   ck(Q(m['max'])<=(Q(pair[0]['shell_column']['max'])+Q(pair[1]['shell_column']['max']))/2)
   mixtures.append({'delta':str(delta),'gamma':str(gamma),'scope':'equal mixture of exactly two displayed phases, not random-phase expectation or individual-realization bound','source_column':m})
 out={'scope':'one true continuous 1D uniform-f, variable-radius receiver field; auxiliary direct-R shell allocation only, no general posterior/history transfer or higher-dimensional claim','environment':{'executable':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'command':f'{sys.executable} r508_numeric.py','checks':checks,'count_meaning':'2 symbolic primitives +12 configurations x11 aggregate exact certificates +6 two-point mixtures x2 guards; interval polynomial extrema also verified internally','model':{'n':1,'f':'1[-3,3]','W':'6','receiver_E':'[0,1]','R_B':'1+B','mass_B':'1+B','q_B':'1','t':'1','nu':'Lebesgue dB','Rtau':'1','u':'uniform[-1/2,1/2], equals relative full posterior in this uniform-f field','image':'Y=B+delta*s_j*u','allocation':'shell outer Q(B,s_j) minus inner Q(B+delta*(s_j-s_prev)u,s_prev), density1/(s_j-s_prev)','original_source_column_sup':'log(2)','original_source_column_sup_arb':str(arb(2).log()),'column_conservation':'integral shell K(x)dx=nu(E)=1, exact; peak is not separately normalized to hide mass'},'cases':cases,'two_phase_mixtures':mixtures,'compute_index':{'seconds':time.perf_counter()-start}}
 (ROOT/'r508_numeric.json').write_text(json.dumps(out,indent=2)+'\n')
 print(f'PASS {checks} aggregate exact certificates;12 continuous 1D configurations,6 two-point phase mixtures;no general-history claim')
 for c in cases:print(c['delta'],c['gamma_mass_ratio'],c['phase_label'],'N',c['mass_layer_count'],'uniformsup',float(Q(c['uniform_quantized_column']['max'])),'shellsup',float(Q(c['shell_column']['max'])),'remmass',c['remaining_receiver_mass'])
 print('mixture peaks',[(c['delta'],c['gamma'],float(Q(c['source_column']['max']))) for c in mixtures])
if __name__=='__main__':main()
