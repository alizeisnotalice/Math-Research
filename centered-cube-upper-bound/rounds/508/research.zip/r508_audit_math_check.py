import sympy as s

gamma,m,mold=s.symbols('gamma m mold',positive=True)
theta=m/mold
checks=0
assert s.simplify(theta**2/m**2-1/mold**2)==0
checks+=1
assert s.simplify(1-gamma**(-2)-(gamma-1)*(gamma+1)/gamma**2)==0
checks+=1
assert s.simplify(m*(1/m-1/(gamma*m))+(gamma*m-m)/(gamma*m)
                  -2*(1-1/gamma))==0
checks+=1
delta,u,Y,B,r=s.symbols('delta u Y B r',real=True)
assert s.expand((Y-delta*r*u)-B).subs(Y,B+delta*r*u)==0
checks+=1
assert s.expand((Y-delta*r*u-r/2)-(Y+r*(-s.Rational(1,2)-delta*u)))==0
checks+=1
assert s.expand((Y-delta*r*u+r/2)-(Y+r*(s.Rational(1,2)-delta*u)))==0
checks+=1
print(f'PASS {checks} exact pair-retention, nested-mass TV and inverse-box identities; no accepted-relative or global overlap certificate')
