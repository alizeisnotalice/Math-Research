"""R92 public, exact continuum cell envelopes; no private model or original gates.

Run with Python 3 stdlib. Logs are bounded by a rational atanh series.
Only the separate reconstruction diagnostics use floating point.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import inf, log, sqrt
import argparse
import json
import time

BITS = 44
DEN = 1 << BITS

def floorq(x):
    return x.numerator // x.denominator

def ceilq(x):
    return -floorq(-x)

def series_log(q):
    assert 1 <= q <= 2
    t = (q - 1) / (q + 1)
    s = F(0)
    p = t
    for j in range(40):
        s += 2 * p / (2*j + 1)
        p *= t*t
    tail = 2*p / (81*(1-t*t))
    return s, s+tail

LOG2 = series_log(F(2))

@lru_cache(None)
def log_bounds(q):
    assert q > 0
    k = 0
    z = q
    while z >= 2:
        z /= 2
        k += 1
    while z < 1:
        z *= 2
        k -= 1
    lo, hi = series_log(z)
    if k >= 0:
        lo, hi = lo+k*LOG2[0], hi+k*LOG2[1]
    else:
        lo, hi = lo+k*LOG2[1], hi+k*LOG2[0]
    return F(floorq(lo*DEN), DEN), F(ceilq(hi*DEN), DEN)

@lru_cache(None)
def energy(n, arrivals):
    """Integral (sum mass 1_{L>=r}/L**n - 1)_+**2 dL/L.
    arrivals is sorted tuple (full-side distance, mass), mass sums to one.
    Returns rigorous fixed-dyadic bounds or None for +infinity.
    """
    grouped = {}
    for r, m in arrivals:
        grouped[r] = grouped.get(r, F(0)) + m
    points = sorted(grouped)
    if points[0] == 0:
        return None
    total = F(0)
    elo = ehi = F(0)
    for i, r in enumerate(points):
        total += grouped[r]
        u0 = r**n
        u1 = min(total, points[i+1]**n) if i+1 < len(points) else total
        if u0 >= u1:
            continue
        rational = total*total*(1/u0**2-1/u1**2)/(2*n) - 2*total*(1/u0-1/u1)/n
        l0, h0 = log_bounds(u0)
        l1, h1 = log_bounds(u1)
        elo += rational+(l1-h0)/n
        ehi += rational+(h1-l0)/n
    return max(F(0), F(floorq(elo*DEN), DEN)), max(F(0), F(ceilq(ehi*DEN), DEN))

def arrivals_for_cell(atoms, lower, step, which):
    vals = []
    for a, mass in atoms:
        if which == 'near':
            d = max(max(lo-z, z-lo-step, F(0)) for z, lo in zip(a, lower))
        elif which == 'far':
            d = max(max(abs(lo-z), abs(lo+step-z)) for z, lo in zip(a, lower))
        else:
            d = max(abs(lo+step/2-z) for z, lo in zip(a, lower))
        vals.append((2*d, mass))
    return tuple(sorted(vals))

def as_rational(x):
    return {'numerator': str(x.numerator), 'denominator': str(x.denominator), 'float_diagnostic': float(x)}

def certificate(name, atoms, mesh, budget):
    n = len(atoms[0][0])
    assert sum(m for _,m in atoms) == 1
    h = F(1,mesh)
    # Every positive-excess cube has L<1 and must contain an atom.
    lower = [floorq((min(a[j] for a,_ in atoms)-F(1,2))*mesh) for j in range(n)]
    upper = [ceilq((max(a[j] for a,_ in atoms)+F(1,2))*mesh) for j in range(n)]
    cell_volume = h**n
    cap_cells = floorq(budget/cell_volume)
    records = []
    checks = 0
    for idx in product(*(range(a,b) for a,b in zip(lower,upper))):
        corner = tuple(F(i,mesh) for i in idx)
        lo = energy(n, arrivals_for_cell(atoms,corner,h,'far'))
        hi = energy(n, arrivals_for_cell(atoms,corner,h,'near'))
        mid = energy(n, arrivals_for_cell(atoms,corner,h,'middle'))
        assert lo is not None
        if mid is not None:
            assert lo[0] <= mid[1]
        if hi is not None:
            assert mid is not None and mid[0] <= hi[1]
            assert lo[0] <= hi[1]
        checks += 1
        records.append((idx, lo[0], None if hi is None else hi[1]))
    # Exact selected measurable cap: union of cells with largest upper bound.
    order = sorted(records, key=lambda x: (x[2] is None, F(0) if x[2] is None else x[2], x[0]), reverse=True)
    removed = min(cap_cells, len(order))
    kept = order[removed:]
    assert all(r[2] is not None for r in kept), 'cap too small to cover atomic singular cells'
    e_upper = cell_volume*sum((r[2] for r in kept), F(0))
    # Lower bound permits arbitrary measurable deletion of the specified volume.
    low_order = sorted((r[1] for r in records), reverse=True)
    fractional = budget/cell_volume-cap_cells
    e_lower = cell_volume*sum(low_order[cap_cells:], F(0))
    if fractional and cap_cells < len(low_order):
        e_lower -= fractional*cell_volume*low_order[cap_cells]
    e_lower = max(F(0),e_lower)
    assert e_lower <= e_upper
    return {'name': name, 'n':n, 'mesh':mesh, 'atoms':len(atoms),
            'cells':len(records), 'checks':checks, 'removed_cells':removed,
            'allowed_cap_volume':as_rational(budget), 'actual_cap_volume':as_rational(removed*cell_volume),
            'optimal_excess_energy_lower':as_rational(e_lower),
            'selected_cap_excess_energy_upper':as_rational(e_upper),
            'scope':'exact continuum cell bounds for this finite atomic input; not original Fnew; no asymptotic or uniform conclusion'}

def corners(n):
    return [(tuple(F(s,4) for s in signs), F(1,2**n)) for signs in product((-1,1),repeat=n)]

def run():
    stages = []
    specifications = [
        ('pilot', [('two_atoms',corners(1),8,F(1,2)),('square_four',corners(2),4,F(1))]),
        ('stress', [('unequal_chain',[((F(-1,2),),F(1,8)),((F(-1,8),),F(3,8)),((F(0),),F(1,4)),((F(1,2),),F(1,4))],32,F(1,2)),
                    ('square_four',corners(2),8,F(1)),('cube_eight',corners(3),4,F(1))]),
        ('expanded', [('two_atoms',corners(1),64,F(1,2)),('square_four',corners(2),16,F(1)),('cube_eight',corners(3),8,F(1))])]
    for stage,cases in specifications:
        stages.append({'stage':stage,'certificates':[certificate(*args) for args in cases]})
    # Three-stage floating checks of the exact reconstruction expression.
    diagnostics=[]
    for stage, ns, ts in [('pilot',[1,2,4],[2,4,8]),('stress',[8,64,256],[1.125,1.5,16]),('expanded',[1024,65536,1048576],[4,64,1024])]:
        count=0
        for n in ns:
            for t in ts:
                j=.5-2/t+(log(t)+1.5)/(t*t)
                assert 0 < j < .5
                # Independent Simpson integration after u = log(t) z.
                steps=4096
                a=log(t)
                from math import exp
                values=[(exp(-a*i/steps)-1/t)**2 for i in range(steps+1)]
                integral=a/(3*steps)*(values[0]+values[-1]+4*sum(values[1:-1:2])+2*sum(values[2:-1:2]))
                assert abs(integral-j) <= 2e-10*max(1,j)
                # Chosen t = 4+sqrt(2nB/A), A=B=1: rigorous bound proved in report.
                chosen=4+sqrt(2*n)
                jj=.5-2/chosen+(log(chosen)+1.5)/chosen**2
                fee=chosen+n/(chosen*jj)
                assert fee <= 4+2*sqrt(2*n)+1e-9
                count+=1
        diagnostics.append({'stage':stage,'floating_checks':count})
    return {'format':1,'proof_status':'conditional energy criterion only; no uniform cap energy proof',
            'kappa':1,'mass':1,'logarithm_certificate':'40-term rational atanh series, rigorous tail; outward 44-bit dyadic rounding',
            'stages':stages,'reconstruction_diagnostics':diagnostics,
            'total_continuum_cells':sum(c['cells'] for s in stages for c in s['certificates']),
            'total_floating_checks':sum(s['floating_checks'] for s in diagnostics)}

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    start=time.perf_counter()
    result=run()
    result['runtime_seconds']=time.perf_counter()-start
    with open(args.output,'w',encoding='utf-8') as out:
        json.dump(result,out,ensure_ascii=False,indent=2)
        out.write('\n')
    print(json.dumps({'output':args.output,'cells':result['total_continuum_cells'],'floating':result['total_floating_checks'],'runtime_seconds':result['runtime_seconds']}))
