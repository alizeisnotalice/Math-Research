# 中心立方体第92轮：薄环直接运输与全尺度能量接口

2026-10-12。目标仍为任意非负L1输入、真实勒贝格接收测度上的 n^(1/2+o(1)) 一致弱型上界。**一般目标尚未证明**，保留一般基准 O(n log n)。本轮复用八个研究角色，三条Astra high路线、Astra high与Sol high独审、两名Sol high数值角色和一名Sol high来源/更新64技能角色。

最直接的新支付是薄环捕获核的共同来源运输：按真实捕获行归一化，移除了该分支原有的自由坐标包络及包数对数损失。低集中计数分支获得根阶费用；但在高负载R远大于sqrt(n)时，已知计数下界k约为R，低计数分支可能为空，不能用它支付目标瓶颈。高计数流和重复阈值加权占用仍须处理。另一版本把全部薄环流付给精确来源计数权重，明确了要估计的跨阶段来源势。

覆盖路线得到对侧真实终端捕获的共同来源泄漏预算和精确前缀积分。它能付一个近饱和、高捕获份额部分，但尚未控制低份额、窗口外及原停止/分类逃逸。小位移过程路线则付清固定与移动接收最大值的比较以及新增位移缺陷，剩余有符号尺度差分仍未获得根阶支付。

主代理另证明全尺度正超额平方能量到弱型估计的精确条件性桥梁，并构造可复现的连续接收区域包络算法。它完全保留接收体积和同一例外集；有限低维证书支持算法与探路，关键一般能量前提仍开放。文献组核验热论文其余相关原文及更新技能，提取允许有符号高频弱费用的接口，未把球、热或Gamma恒等式直接移植成方体定理。

数值组保持原输入和阈值，用相位区间的坐标置换并集检验真实体积，保留精确多项式系数、全维宽度及所有原条件。三个候选并集的原粗门全部UNKNOWN，唯一追加角点也是UNKNOWN；共同来源运输反而证明所选小跨度类容量极小。完整结果、未知范围、三阶段核验和隔离重放记在文末。私人模型、原始配方和未公开下界构造仅留本地。

本轮报告与详细LaTeX文本独立归档，不编译PDF。所有原分支、全尺度及分层费用继续保留；有限可行单元、已付子集和条件性桥梁均不代替一般闭合。


## 第92轮保留主账与剩余量

令 `mu=f dy`，`Q(x,L)=x+[-L/2,L/2]^n`，`L in [1,2]`，需求为真实 `lambda dx`。保持原锚点 `A_1 f < lambda/2`、原平滑核的全窗口上界、严格后见证、原最早硬接触 `A_L* f=lambda` 及原中间下限 `exp(-s_n)/2`。每次实际删源并重选时重新检查全部门；来源主闭包保旧接触及旧前缀，不自动保原中间下限或严格后见证。

设 `H=1+n log 2`，`theta=log^-2(n+2)`，`alpha=epsilon=1/[10log(n+2)]`，`c=1-alpha-epsilon`，`beta=c/2`。已付费用完整保留：

- `B_base=4+2log2 sqrt(7n/3)`，`B_ext=2H/sqrt(n+2)`。
- `T_soft=1+log2 min(2n,sqrt[n(theta^-1+4theta/3)])`，粗平滑付 `T_soft/alpha`。
- 原包网格 `h0=1/(16n^2)`，`a=n^-p`、`rho=n^-1/2`，`p>0` 为原先固定值；`P_dom=(5+3log(1/a))/rho`。
- `h*=1/(16n^(3/2))`，`E=exp(nh*)`，`B_h=1+E[1+(2n^2+n)h*]`。后验物理碰撞至少 `3/4` 或平均网格熵至多 `sqrt n` 的并集一次支付 `P_phys=2[E+B_h+2(1+E)sqrt n]`。
- 完整未付余集 `Fnew=Fdiff ∩ {C_h*<3/4, Hbar_h*>sqrt n}`；`Fdiff` 为原粗平滑低中间分支删除原 dominant-packet 事件后的集合。

只有支付整个 `Fnew` 的 `D_new` 才能代入

`C_n^square <= C_loc log(n+2)[B_base+B_ext+T_soft/alpha+P_dom+P_phys+D_new]`。

若逐原 `kappa=1+log[lambda/(2P_1,L*)]` 二进层证明，则另付 `J_n=O(log n)`；第90轮薄片分支及本轮有限浓缩轮廓均未证明覆盖并支付整个 Fnew，原主账尚未因此得到一般新收益；这些层或全尺度费用均保留。私人诊断使用的某个 `p` 值只认证其对应分支，不能把该值替换原账上任意指定的 `p`。

### 保留的容量、规范方差与通量接口

对每个正规紧致 `B subset Fnew`、连续原尺度和每个正主割 `(A_s,S_s)`，真实源邻域等于 `S_s`（模 mu），`D_s=lambda|A_s|=integral_Ss b* dmu`。规范列 `b_A<=H`。第88轮已证明：若对每个这样的主割重新计算均有 `I_T(A_s)<=R_n mu(S_s)/n`，`T=sqrt(24nR_n+96)`，则所有割比至多 `2T`，经 Lusin、内正则性与 Borel Hall 得完整条件回代。所需 `R_n=n^{o(1)}` 尚未证明。

一般可测停止图保精确通量 `D-a=B_face-V_bulk`，且整体锚点 `a<=mu(S)`。故 `B_face-V_bulk<=C_root mu(S)+D/2` 足以推出 `D<=2(1+C_root)mu(S)`；仅凭逐点锚点小于半接触不能替代整体锚点预算。两项的逐正部分估计仍各为线性维数。第89轮配对抽样保留了该有符号差；第90轮有限厚度只支付其中一部分，完整差尚无统一根阶上界。

### 第90轮保留工具及其互补项

有限厚度 δ 的真实面替代项具有精确费用 a_n(δ)log2·M，a_n(δ)=E(Bin(n,δ)−nδ)_+/δ≤(1/2)sqrt[n(1−δ)/δ]。固定 δ=1/2 确实是根阶。完整余项仍为同一来源的平移差与两个接收行停止函数差的乘积积分；它没有消失。仅以来源 L1 平移模量支付时，允许 δ 依赖输入也存在至少 nM/2 的证书费用障碍。这不是对实际有符号余项或主割容量的反例。

部分坐标薄片分支的已证单包费用为 [1+(n−k)log2]prod_j(1+h_j)。一组共同来源包保留真实捕获份额，得到其分支的全子割支付；有限包覆盖的遗漏源还按 H_n W_bad/τ 显式支付。任意来源尚无满足根阶费用的此类覆盖；总坐标原子质量不足以推出接近全坐标的少包覆盖。若将这一分支加入原递推，每一步新费用与全部旧费用、阈值权重 t_i 及最终 H_n t_ell W_ell 必须保留；主账没有把该分支虚加为一般收益。原第89轮持续高负担逼出的坐标原子约束仍是必要条件，不是矛盾。

精确奇异平面模型中，sup_L L^(-k)A_L 的正核包络具有 1+m/k 型系数，但正常接收纤维的需求是 λ∫T^k。逐纤维层蛋糕回代恢复 1+(m+k)log2；直接已证费为 1+m log2。更强的真实弱型费尚未证明，也没有被该记账障碍否定。

Gamma 平滑的新增一般转移定理要求一个真实共同阈值事件并集、统一上下有界周期密度，以及完整维数/截断费用。它为任何共同 Cesàro 主项加全尺度误差的比较给出必要误差费用 (sqrt(B)−sqrt(A))_+²；没有构造该误差的上界。真实目录应用与新下界结论留在私人区，不在公开包中。直接假设 Gamma 极大族的 subpower 弱型界不再作为可用工具。

原 P1 与 coarse 的 Fourier 乘子、连续相位/尺度包络、级数尾及正有限截断方向已从定义证明。实际物理证书及其失败范围见数值节。连续首次接触和全窗口软上界均不能单独代替完整 Fnew；单元检验不涵盖未被选择的接收集或主来源割。一般规范高列方差、共同有符号差、来源集中跨层费用和完整回代均继续开放。

### 第92轮新增接口与实际未付量

直接薄环运输使用真实捕获核的行归一化，替代上一轮该分支的 H_(n-k) 与 log N 包覆盖费用。低坐标集中计数 r<=J 的流量充分时，J≈sqrt(n) 给该接收子集根阶支付；高计数互补流仍为线性费。保留精确 r(y) 的加权来源版本避免两类覆盖费用，但必须支付跨阶段 sum_i beta^-i r_i(y)1_(Z_(i+1)∩U_i) 的真实共同来源占用。没有单调性、总费用或退出支付的假设被偷偷加入。

对侧终端捕获的真实泄漏等于 integral_S b_B-D，不超过H_n M-D。它只能在实际近饱和且对侧捕获份额不太小时付根阶；低份额行、ambient B外以及原停止/分类逃逸仍缺估计。精确前缀系数 Psi/q 可以指数增长，不可用终端份额直接代替尺度占用。

小位移卷积链在同一[1,2]窗口内与固定接收最大值作常数比较，额外再居中核缺陷可按常数付清；剩余原尺度差分的有符号停止占用尚未支付。逐项绝对平移回固定轨道另有线性费用障碍，不是一般弱型下界。

新的全尺度正超额能量条件保留同一个真实接收例外集：若其体积<=A_n W/kappa且空间-尺度平方超额积分<=B_n kappa W，则弱型费用<=4A_n+2sqrt(2n A_n B_n)。该一般条件命题已证明，所需subpower A_n,B_n未证明。有限原子连续区域证书只验证所列固定输入；不把低维结果外推阶数。普通supported-cap的全尺度signed平方能量不能无条件继承到L1输入；允许从有限原子的统一弱界合法转移到L1，但不转移cap能量假设。

数值组的新置换盒并集以精确多项式系数和全部n维宽度计算真实Haar/Lebesgue体积；其最终原条件资格见数值报告，UNKNOWN不能当空集。全部余集、全部主割、高负担及最终一般回代仍未解决。


## 1. Outcome and retained setting

The requested payment of the **whole** mixed remainder is not proved. This round obtains a quantitative common-source leakage budget for every actual source-closed cut, and an exact improvement of the opposing-prefix estimate. Together they pay a specified portion of the opposing current when the cut nearly saturates the canonical envelope. They do not establish a root-order Hall bound: the estimate degenerates at the root-order range of cut ratios, and all omitted escape components remain explicit.

Fix the original nonnegative $f\in L^1(\mathbb R^n)$, $n\ge2$, $\lambda>0$, and original event $F=F_{\rm new}$ and selector $\tau\in(1,2]$. All original gates remain those of $f$. Let $B\subset F$ be a regular compact receiver set; here regular means only that $\tau|_B$ is continuous. For any measurable $A\subset B$ with essential source neighborhood $S=N(A)$, set
\[
 g=f1_S,\qquad M=\mu(S)>0,\qquad D=\lambda|A|,
 \qquad H_n=1+n\log2.                                      \tag{1}
\]
The same conclusions hold for measurable finite receiver sets with the stated original contact data. Write
\[
 b_B(y)=\int_B\tau_x^{-n}1_{Q(x,\tau_x)}(y)\,dx,
 \qquad q_S(x)=\frac{\mu(Q(x,\tau_x)\cap S)}{\lambda\tau_x^n}.
                                                               \tag{2}
\]
The original contact gives $0\le q_S\le1$ and the canonical envelope gives $b_B\le H_n$. Source closure gives $q_S=1$ for almost every $x\in A$. All integrals use actual Lebesgue receiver measure. No optimized-flow edge is identified with a canonical edge.

For a positive principal cut, the retained optimizer $b^*$ additionally satisfies $D=\int_S b^*\,d\mu$. This equality will only be used after integration. In particular $b_B-b^*$ need not be nonnegative pointwise.

The retained R90--91 identities are
\[
 D-a=F_{1/2}+E_{1/2},\quad a\le M,\quad
 |F_{1/2}|\le a_n(1/2)(\log2)M\le\tfrac12\sqrt n(\log2)M.
                                                               \tag{3}
\]
They do not pay $E_{1/2}$. The desired uniform estimate is still
$E_{1/2}\le C\sqrt n\,\log^a(n+2)M+D/2$, on every original positive principal cut or through a valid full all-cut reduction.

## 2. A shared-source budget for opposing terminal demand

**Theorem 1.** Define the actual canonical leakage
\[
 \mathcal L_B(A)=\int_S b_B\,d\mu-D.
\]
Then
\[
 \boxed{\ \mathcal L_B(A)=\lambda\int_{B\setminus A}q_S(x)\,dx,
 \qquad 0\le\mathcal L_B(A)\le H_nM-D.\ }                 \tag{4}
\]
For every measurable $R\subset B\setminus A$ and every $0<\eta\le1$,
\[
 \lambda\int_Rq_S\,dx\le\mathcal L_B(A),\qquad
 \lambda|R\cap\{q_S\ge\eta\}|\le\frac{\mathcal L_B(A)}\eta.
                                                               \tag{5}
\]
For a principal cut, $\mathcal L_B(A)=\int_S(b_B-b^*)d\mu$.

**Proof.** Tonelli and the definition of $q_S$ give
$\int_S b_Bd\mu=\lambda\int_Bq_Sdx$.
The same calculation on $A$, followed by source closure, gives
$\int_S b_Ad\mu=\lambda|A|=D$.
Subtracting the two equalities proves the identity in (4). Its left side is nonnegative because its right side integrates a nonnegative function; its upper bound follows from $b_B\le H_n$. Restriction to $R$ and $q_S\ge\eta$ gives (5). The principal formula uses only $\int_S b^*d\mu=D$. This proof does not require attainment of a maximum Hall ratio or pointwise comparison of columns. $\square$

This is a genuinely common-source budget: all opposing rows use the same $S$ and the same canonical column of the ambient $B$. It is not a sum of rowwise source masses. If $K=D/M$, it gives a demand fee $(H_n-K)M/\eta$. Thus near-envelope cuts have quantitatively little terminal leakage into other rows of $B$.

### 2.1 Completion with the ambient set kept fixed

Let
\[
 C_B(S)=\{x\in B:\mu(Q(x,\tau_x)\setminus S)=0\}.
\]
This is measurable, contains $A$ almost everywhere, and has $N(C_B(S))=S$ modulo $\mu$, by the retained Tonelli completion argument. With $D_C=\lambda|C_B(S)|$,
\[
 \mathcal L_B(C_B(S))=\mathcal L_B(A)-(D_C-D)\ge0.          \tag{6}
\]
Hence within-$B$ completion can only decrease this leakage budget. The original optimizing column need not remain the optimizer of the completed problem, and $D_C=\int_Sb^*d\mu$ is not asserted. Formula (6) follows directly from (4).

Global completion $C_F(S)$ is also legitimate as an all-cut reduction, but rows in $C_F(S)\setminus B$ cannot be added while retaining the old $b_B$ in (4). One must recompute the ambient canonical column. Likewise a bound for a restricted receiver set is not a fresh-variance inheritance theorem.

## 3. Exact prefix occupation from the terminal captured share

For an original row $x\in F$, define
\[
 J_S(x)=\int_1^{\tau_x}A_Lg(x)\,\frac{dL}{L}.
\]
**Theorem 2.** Put $t=\tau_x$, $q=q_S(x)$, and $c=qt^n$. Then
\[
 J_S(x)\le\lambda\Psi_n(q,t),                            \tag{7}
\]
where
\[
 \Psi_n(q,t)=
 \begin{cases}
 q(t^n-1)/n,&qt^n\le1,\\
 (\log(qt^n)+1-q)/n,&qt^n\ge1.
 \end{cases}                                             \tag{8}
\]
The branches agree when $qt^n=1$, the first includes $q=0$, and $\Psi_n(1,t)=\log t$. The function is nonnegative, increasing and concave in $q$, with
\[
 0\le\Psi_n(q,t)\le\log t,\qquad
 \Psi_n(q,t)\le q(t^n-1)/n.                              \tag{9}
\]

**Proof.** At every earlier scale the original first-contact property gives $A_Lf(x)\le\lambda$. Since $g\le f$, the same upper bound holds for $A_Lg$. Nested cubes and the actual terminal captured mass give the independent upper bound
\[
 A_Lg(x)\le L^{-n}\mu(Q(x,t)\cap S)
 =\lambda q(t/L)^n.
\]
Consequently
$J_S(x)/\lambda\le\int_1^t\min\{1,cL^{-n}\}\,dL/L$.
If $c\le1$, integrate the second term throughout. If $c\ge1$, split at $L_0=c^{1/n}\in[1,t]$. The two contributions are $\log L_0$ and $(1-q)/n$, giving (8). On the first branch the derivative in $q$ is $(t^n-1)/n$; on the second it is $(q^{-1}-1)/n$, nonnegative and decreasing. Their values agree at the junction. The integral formula proves (9), either by dropping the first or the second argument of the minimum. $\square$

No gates are inherited by the restricted input $g$. The proof uses only its domination by the original $f$, the old hard prefix, and nested capture.

## 4. Quantitative payment and its exact missing complement

Use the same augmented law, involution and unmatched density $\rho=(g-g\circ T)_+$ as R91. Explicitly $L$ is log-uniform on $[1,2]$, $i$ and the sign $\sigma$ are uniform, $v\in[0,1]$ is uniform, and the transverse coordinates $z_{-i}$ are uniform in their unit cube. The two rows are
\[
 r_f=u+Lz_{-i}+\sigma Le_i/2,\qquad
 r_a=u+Lz_{-i}-\sigma(1-v/2)Le_i/2.
\]
Let $d\Omega$ include Lebesgue $du$ and these probability laws. For measurable $R\subset F\setminus A$, define the **positive** opposing current
\[
 \mathcal P_A(R)=n\log2\int\rho\,
 1_{\{\chi(r_f,L)=1,\ r_a\in R,\ L<\tau_{r_a}\}}\,d\Omega.
                                                               \tag{10}
\]
The opposite row is inactive because it is outside $A$; the requirement $L<\tau_{r_a}$ is retained. This is one positive part of the complete signed remainder, not the whole remainder.

**Theorem 3.** For the original data above,
\[
 \mathcal P_A(R)\le
 \min\left\{2n\lambda\int_R\Psi_n(q_S,\tau)dx,
 n\lambda\int_R\Psi_n(q_S,\tau)dx+
 a_n(1/2)\log2\,M\right\}.                              \tag{11}
\]
In particular, for $R_\eta=(B\setminus A)\cap\{q_S\ge\eta\}$,
\[
 \boxed{\ \mathcal P_A(R_\eta)\le
 \min\left\{\frac{2n\log2}{\eta}\mathcal L_B(A),
 \frac{n\log2}{\eta}\mathcal L_B(A)+a_n(1/2)\log2\,M\right\}.\ }
                                                               \tag{12}
\]
If $\mathcal L_B(A)\le\eta M/\sqrt n$, the second bound is at most
$\tfrac32\sqrt n(\log2)M$. This is a genuine quantitative root-order fee for that specified part of the current.

**Proof.** Since $\rho\le g$, drop the active-face condition in (10). The resulting opposite-row marginal is exactly the half-thickness slab kernel applied to $g$, integrated on $R$ up to its original stopping scale. Its density relative to the unit cube is at most two, so it is bounded by $2n\int_RJ_Sdx$. Alternatively split that slab kernel into the cube kernel plus the retained centered slab difference. The latter has absolute fee $a_n(1/2)\log2 M$ for the same source and any measurable stopped receiver indicator. This gives $n\int_RJ_Sdx$ plus that fee. Theorem 2 proves (11). For $R_\eta$, use $\Psi_n\le\log2$ and Theorem 1; this proves (12). The final assertion also uses $a_n(1/2)\le\sqrt n/2$. $\square$

This does not settle the problem. In terms of the crude envelope, the displayed root fee is guaranteed only when $H_n-D/M\le\eta/\sqrt n$, whereas the desired general threshold is of order $\sqrt n$ times logarithms. At that target range the available slack is still of order $nM$. No stability theorem turns an intermediate large Hall ratio into near-saturation of $H_n$.

For a globally completed cut the three R91 inactive classes remain: outside original $F$, original stopping scale at most $L$, and capture of source outside $S$ before the opposing original stop. Formula (12) treats only the last kind inside the fixed ambient $B$ and with a lower bound on its terminal share of $S$. Its complement includes:

- both first two inactive classes;
- all opposing rows outside $B$;
- the low-share rows $q_S<\eta$ even inside $B$;
- the possible unused signed cancellations between these pieces.

All these remain in the full signed $E_{1/2}$. They have not been discarded, assigned an ordinary receiver weak fee without its pushed-law density, or charged to $M$ without proof.

## 5. Why the low-share part needs scale-sensitive common-source information

At $qt^n\le1$, (8) gives the exact coefficient
\[
 \frac{\Psi_n(q,t)}q=\frac{t^n-1}{n}.                    \tag{13}
\]
Thus the new leakage control of $\lambda\int q_S$ cannot be substituted into (11) with a dimension-polynomial coefficient using this scalar envelope alone. The lower coefficient is exponential for fixed $t>1$. The physical pressure material and any conclusions about its realization are confined to the private section. No fully qualified original-$F_{\rm new}$ principal-cut obstruction, or obstruction to the actual paired current, is asserted in this public argument.

The precise additional physical duty is to control the low-share **pushed current**, including its correlation with the active partner, rather than only its terminal canonical mass. For example, a proof using this route would need a quantitative bound on
\[
 n\log2\int\rho\,
 1_{\{\chi(r_f,L)=1,\ r_a\in B\setminus A,\
 L<\tau_{r_a},\ q_S(r_a)<\eta\}}\,d\Omega,               \tag{14}
\]
together with the external-$B$ and other two escape contributions. Bounding (14) by $2n\lambda\int_{q_S<\eta}\Psi_n(q_S,\tau)$ is valid but does not supply that duty. A root-order estimate for an arbitrary marginal function with the same $q$-budget is excluded by (13); an actual cross-row constraint would have to use more information. Neither independence, an invariant source law, nor a positive-flow exchange cycle has been assumed.

## 6. Verification and scope

Both candidate theorems and the private coefficient-pressure statement were sent to both independent auditors before the proofs. Both auditors subsequently read the complete current Markdown and matching TeX, including the private scope, and returned mathematical and consistency PASS. Independent arithmetic receipts remain the responsibility of the audit owners and are not inferred from the author checks.

Three new author stages passed 631 exact rational assertions (205 pilot, 213 pressure, 213 expanded). They checked the piecewise formula's derivatives and junction, the exact common-source leakage and threshold inequalities in finite algebra models, and anonymous hard-prefix/first-contact inequalities for the private positive-volume family. The run took 0.006518792 seconds. Finite leakage models are NONPHYSICAL; the private family checks only the explicitly listed hard conditions. No old test counts were reused, and no actual high-load principal cut was sampled.

The current D01 and M03 skill scopes were read: a positive source/receiver coupling is not an invariant measurement law, and no general near-extremizer stability theorem is supplied. The arguments above prove the needed identities and inequalities directly, without importing such a theorem. Numeric roles were informed of $q_S,\tau,J_S$ as optional same-input observables; their unchanged-source search is not a premise here.

The full general upper bound, the low-share/external escape payment, and the complete return to the weak bound remain **OPEN**. No new general Hall fee or asymptotic exponent is claimed.

## 1. Result and actual accounting space

The new payment uses actual captured annular incidences directly. It removes both the free-coordinate envelope H_(n−k) and logarithmic packet-count factor from the R91 thin branch. A low coordinate-count part has a root-order all-subcut Hall payment. Its high-count complement has an explicit linear payment. Either alternative removes a definite fraction of original receivers. The full source occupation, threshold changes, other branches and terminal remain; this is not a general root-order theorem.

A second result tests the proposed common fractional direction cover. In a genuine positive-L1 thin-annulus geometry, any source-common direction weights of total budget B retain at most B/n of the traffic. Thus a root-sized directional budget can lose a root-sized factor of captured traffic. This is an obstruction to that certificate using only face geometry and coordinate concentration. The example deliberately has no common-threshold contact or original Fnew qualification, and is not an obstruction to the full actual recursion or the cube weak endpoint.

Use the retained original definitions. n≥2, H_n=1+n log2, alpha=epsilon0=[10log(n+2)]^(−1), c=1−alpha−epsilon0, beta=c/2. At stage i the actual source is mu_i=f_i dy=mu_0|Z_i, mass W_i; lambda_i=beta^i lambda_0; B_i is the current receiver subset of the freshly recomputed whole Fnew_i. The original earliest selector has full side 1≤L_i≤2 and mu_i(Q_i(x))=lambda_i L_i(x)^n. Set D_i=lambda_i|B_i|, R_i=D_i/W_i, t_i=beta^(−i), and b_i(y)=∫_Bi L_i^(−n)1_Qi(y)dx≤H_n.

The original captured-stop kernel satisfies 0≤k_i≤L_i^(−n)1_Qi and row integral >c lambda_i. Its column is q_i; S_i={q_i>K}; mu_{i+1}=mu_i|S_i and rho_i=W_{i+1}/W_i. Let Bhat_{i+1} denote the tentative bad-row child after all fresh classifications, before the new receiver deletion. On it L_{i+1}<L_i, so the actual cubes nest. All zero-mass branches stop without evaluating ratios.

The source reach probability is m_i=W_i/W_0, with survival rho_i and exit mass m_i(1−rho_i). The compensated source mass is instead

    v_i=t_iW_i,     v_{i+1}=(rho_i/beta)v_i.                  (1)

No receiver deletion changes that immediate source transition. A finite unfinished recursion retains H_n v_ell; an empty remaining receiver event has zero terminal demand, even if its source mass is positive. E03's actual node-mass and terminal requirements are used as a bookkeeping check, not as a source of a Bellman constant.

## 2. Concentrated-face incidences, without a packet cover

Suppress the stage index. Write V=|B|, D=lambda V, R=D/W, mu'=mu|{q>K}, W'=rho W and pi=mu'/W'. Assume the actual R91 band

    R≥8K/c,   |Bhat'|/V≥1−c/16,   c/4≤rho≤3c/4.            (2)

For 0<h≤1/n define

    C_h=exp((n−1)h)(log2+h),  epsilon=5R/(96nV),
    d=5R/(48C_h),  k=ceil(d),
    T_j={z:pi_j([z−2h,z+2h])≥epsilon},
    r(y)=Σ_j1_Tj(y_j),  U={r≥k},
    E(h)={x∈Bhat':log(L(x)/L'(x))≥h}.

Here 0<epsilon<1, 1≤k≤n, and k is comparable to 1+R. All profiles use the SAME actual child probability pi. Retain zeta=5c/192 and gamma=zeta/2=5c/384.

The first alternative is |E(h)|≥zeta V, which is the retained large-radius progress. Otherwise define a physical subkernel on x∈Bhat'\E(h):

    K(x,y)=L(x)^(−n) 1_(Q(x,L)\Q(x,L'))(y) 1_U(y)
        ×1_{there is j with y_j∈T_j and
                         exp(−h)L(x)/2<|x_j−y_j|≤L(x)/2}. (3)

This is a union of incidences, not their multiplicity. It may equivalently be assigned to the first qualifying coordinate. The choice is measurable, common to the fixed input, and changes neither the kernel value nor its support.

The strengthened thin alternative is

    ∫∫K(x,y)dmu'(y)dx ≥zeta D,
    ∫K(x,y)dx ≤C_h r(y),  for every y.                     (4)

Also each row has mu'-mass at most lambda, because K≤L^(−n)1_Q and mu'≤mu.

Proof. The actual annular identity yields total A≥5cD/16 and A/W'≥5R/12. Each j-th thin-face column is at most C_h: put s=|x_j−y_j|, use exp(−h)/2<s≤1, 2s≤L<2exp(h)s, and transverse volume at most (2exp(h)s)^(n−1); both signs give exp((n−1)h)∫ds/s=C_h. The large-drop rows contribute at most 5R/48 in normalized traffic. On the remaining rows, face intervals have length at most h. A face interval meeting T_j^c has marginal mass below epsilon, so the union of unqualified-face incidences contributes at most 2nV epsilon=5R/48. Qualified-face traffic on U^c is at most dC_h=5R/48, since r<ceil(d) implies r<d. Removing these three contributions from 20R/48 leaves at least 5R/48 for the UNION in (3). Multiplication by W' gives (5rho/48)D≥zeta D. Finally its column is bounded by the sum of the r(y) qualifying coordinate face columns. This proof uses actual annular incidence, not source mass in U or packet entropy.

## 3. A direct shared transport with root and linear alternatives

Fix an integer 1≤J≤n, and set

    V_lo={k≤r≤J},       V_hi={r>J}.

If k>J, V_lo is empty. Let K_lo=K1_Vlo and K_hi=K1_Vhi. Their total traffic sums to that in (4). Choose the low part when its traffic is at least gamma D; otherwise the high part has traffic at least gamma D and is chosen. For the chosen part b∈{lo,hi}, put

    d_b(x)=∫K_b(x,y)dmu'(y),
    E_b={x∈Bhat'\E(h): d_b(x)≥gamma lambda/2},
    eta=gamma/2=5c/768.

Since 0≤d_b≤lambda and ∫d_b≥gamma lambda V,

    |E_b|≥gamma V/(2−gamma)≥eta V.                         (5)

On E_b define the transport density relative to dx dmu'

    A_b(x,y)=lambda K_b(x,y)/d_b(x).                       (6)

Every row has mass lambda; all its edges are in the ORIGINAL old cube. Its source column obeys

    ∫_Eb A_b(x,y)dx≤P_b 1_Vb(y),
    P_lo=2C_h J/gamma,       P_hi=2C_h n/gamma.             (7)

Therefore for every measurable subcut A⊂E_b,

    lambda|A|≤P_b mu'(N_old(A)∩V_b).                       (8)

One may define N_old(A) measurably up to source-null sets by positive capture incidence; (8) follows directly from the displayed physical transport. No separate flow-existence theorem or preservation of soft gates under source closure is required.

Equations (5)–(8) prove an actual shared allocation and receiver deletion with neither H_(n−k) nor log N. At h=1/n and J=ceil(sqrt n), C_h≤e(log2+1/2), so P_lo=O(sqrt n), with absolute constants through gamma. P_hi=O(n). The exact complement is high-count annular traffic, not high-count source mass. In particular, when k>J the whole selected traffic is in the linear branch. The actual q>K and band hypotheses do not presently force the low branch.

Delete E_b from the tentative child and continue with B'=Bhat'\E_b, keeping the SAME mu'. Thus |B'|≤(1−eta)|B|. All new q columns and original gates at the next genuine restriction are computed from the resulting current input and receiver subset. This deletion is paid at OLD lambda and OLD L. It leaves rho/beta in (1) unchanged. On large-radius stages no additional E_b deletion is made.

A stronger variable-capacity alternative keeps the exact source profile. Use the whole union K, with total traffic at least 2gamma D, and let E_*={x:d_K(x)≥gamma lambda}. The row bound d_K≤lambda gives |E_*|≥gamma V/(1−gamma)≥gamma V. Normalizing lambda K/d_K supplies the all-subcut weighted capacity

    lambda|A|≤(C_h/gamma)∫_(N_old(A)∩U) r(y)dmu'(y),
                       for every A⊂E_*.                   (8a)

This is an alternative deletion algorithm, not an additional deletion or payment on top of the low/high algorithm. It avoids both previous prices on the whole thin branch while retaining the exact high-profile weight. A common constant source cap is not asserted.

## 4. Exact recursion, exits, and the remaining occupation price

Let A_old be the complete retained paid-branch coefficient and G=2K/c, with the constants listed in Section 6. Let E_init be the original initial event before its retained stage-zero paid branches, with B_0 the current residual. If B_0 is empty the initial event is paid by A_old W_0, with no D_0-priced claim. Otherwise the full finite ledger is

    lambda_0|E_init|≤Σ_(i<ell)[A_old v_i
          +G t_i(W_i−W_{i+1})
          +t_i P_(b_i) mu_{i+1}(V_(b_i))]
          +H_n v_ell.                                    (9)

The added term is zero on stages where no new thin-branch payment is made. Every out-of-band stage and every old branch remains. Since the row payment is at lambda_i, its multiplier is t_i, not t_{i+1}.

The new source charge has the exact common-space expression

    Σ_i t_iP_(b_i)mu_{i+1}(V_(b_i))
      =∫Σ_i t_iP_(b_i)1_(Z_(i+1)∩V_(b_i))(y)dmu_0(y).      (10)

There is no cross-stage disjointness. Source-common face weights at one stage do not remove the threshold weights or supply a potential paying (10).

For the alternative (8a), replace the added term in (9) by (C_h/gamma)t_i∫_(U_i)r_i dmu_{i+1}. Its exact source occupation is

    (C_h/gamma)∫Σ_i t_i r_i(y)1_(Z_(i+1)∩U_i)(y)dmu_0(y).  (10a)

The corresponding receiver-progress constant is gamma instead of eta, so its band budget replaces 1/eta by 1/gamma. A worst-case fee is C_h n/gamma. These are separate valid ledgers, not summed algorithms. The sets T_j and profiles r_i are recomputed from normalized restricted sources and changing thresholds; no pointwise monotonicity or paid telescoping of (10a) has been established. This is a concrete remaining source-potential interface, not a root-order bound assumed as a premise.


For fixed h, removed thin-stage receiver sets are disjoint and have measure at least eta|B_i|. Large-stage receivers belong to the FINAL child, where actual nested logarithmic drops sum to at most log2 per original receiver. Consequently

    Σ_band t_iD_i≤Q_h D_0,
    Q_h=1/eta+192log2/(5ch).                               (11)

This holds with other stages interspersed, but controls only its displayed band terms. If all selected stages have R_i≥R_min>0, their number is at most Q_h|B_0|/R_min, and

    Σ_band v_i≤Q_hD_0/R_min.                              (12)

The band itself allows R_min=8K/c. Hence a positive run cannot stay in this band indefinitely; it must terminate or leave it within this finite stage count. Leaving the band does NOT pay the exit terminal or subsequent stages.

For a completed run with every active stage in the band and empty remaining receiver demand, all old and new repeated fees are bounded by

    [A_old+G+2C_h n/gamma] Q_h D_0/R_min.                   (13)

The terminal is zero because the receiver event is empty. For a formal infinite all-band run, (12) would force v_ell→0, but the finite stage count already excludes indefinitely positive behavior. An unfinished finite horizon retains H_n v_ell. If every thin stage takes the low part, n in (13) can be replaced by J; (12) is still D_0/R_min-priced and cannot be declared root-order W_0 occupation. At h=1/n, Q_h=O(n); substituting only D_0≤H_nW_0 is insufficient. This is the exact remaining recursive price, not an omitted terminal.

## 5. An exact price for source-common fractional directions

Here is a separate certificate-pressure lemma, not an assertion about the original residual. Suppose a physical annular subkernel is partitioned into n disjoint directional kernels whose source columns all equal the same constant d>0, mu-a.e., for a probability source mu. For arbitrary measurable source-common fractional weights 0≤w_j(y)≤1 with Σ_jw_j(y)≤B, 0≤B≤n, Fubini gives

    total original traffic=n d,                           (14)
    weighted traffic=d∫Σ_jw_j(y)dmu(y)≤B d,                (15)
    weighted/original traffic≤B/n.                        (16)

Equality holds when the weight sum equals B almost everywhere. No independence or constant-weight assumption is used. Thus common fractional direction weights alone can trade a root-sized source-column budget for a root-sized loss of retained traffic. Restoring a fixed traffic fraction by rescaling restores the linear factor. Choosing favorable directions can instead retain a small receiver fraction, which does not furnish the definite progress in (5).

A positive-L1, actual-Lebesgue thin-annulus realization of the equal-column premise is verified in the internal pressure appendix. It does not have a common contact threshold, earliest-contact selector or the original Fnew gates. The statement therefore blocks free averaging based only on face caps and coordinate concentration; it does not refute the actual gated high-count route or assert an operator lower bound. Actual contact/gate information or a coupled source-and-receiver potential remains available for a future repair. The concrete physical recipe stays outside the public extract.

## 6. Retained fees and three-stage verification

Every genuine source restriction retains original anchor, all-L P1 upper gate, strict later witness, earliest contact, original exp(−s_n)/2 middle lower, theta=log^(−2)(n+2), original packet and collision/entropy tests, and any original kappa stratum. Whole Fnew=Fdiff∩{C_h*<3/4,Hbar_h*>sqrt n} is recomputed; B_i is only its current subset. No normalized variance monotonicity is used.

With h*=1/(16n^(3/2)), a0=n^(−p) for the original fixed p, rho0=n^(−1/2), the unchanged coefficients are

    B_base=4+2(log2)sqrt(7n/3), B_ext=2H_n/sqrt(n+2),
    T_soft=1+(log2)min(2n,sqrt(n[theta^(−1)+4theta/3])),
    P_dom=[5+3log(1/a0)]/rho0,
    E_*=exp(nh*), B_*=1+E_*[1+(2n²+n)h*],
    P_phys=2[E_*+B_*+2(1+E_*)sqrt n],
    A_old=B_base+B_ext+T_soft/alpha+P_dom+P_phys.

The physical union is paid once. All-scale return still pays C_loc log(n+2); separate original-kappa summation retains J_n=O(log n). These are not absorbed into an unproved potential.

Pilot: verify the disjoint first-face kernel, row normalization, both source-column caps and all-subcut coupling; actual R91 quarter accounting supplies its traffic. Pressure: test the exact directional-weight price (14)–(16) and its internal physical realization, with original common-contact/gates explicitly absent. Expansion: the direct allocation and finite ledger hold for every n≥2, every actual correlated L1 child and measurable original selector, all 0<h≤1/n and 1≤J≤n, and arbitrary finite horizons. The pressure inequalities hold uniformly for all n≥16, with exact rational sufficient tests at expanded dimensions. These are distinct checks, not reused R91 counts. Numerical roles were given the same-child traffic observable only conditional on a qualified high-q child; no such actual empirical profile or general root-order conclusion is claimed.

The general arbitrary-positive-$L^1$ root-order weak bound remains unproved. This round pays two expenses for an explicit class of small convolution shifts: moving and fixed receiver maxima are comparable at dimension-free constants on the same side interval $[1,2]$, and the additional recentering part of the signed compensator costs at most $q\log2$ times source mass. The remaining signed scale-difference occupation is not paid. A new Euclidean example shows that transporting that remaining occupation back to the fixed scale orbit by termwise absolute errors can still cost linearly in dimension.

## 1. State, admissibility, and receiver measure

Let $n\ge2$, $q=1+1/n$, $J=\lfloor\log2/\log q\rfloor$, and $r_j=q^j$ for $0\le j\le J$. Append $r_{J+1}=2$ if necessary and call the final index $K$. Thus $r_0=1$, $r_K=2$, and every adjacent ratio is at most $q$. Write
\[
 U_r=r^{-n}1_{[-r/2,r/2]^n},\quad B_rf=U_r*f,\quad
 Gf(x)=\max_{1\le r\le2}B_rf(x),\quad M=\|f\|_1.
 \tag{1}
\]
Throughout, $f\ge0$ is in $L^1$ and $M>0$. For fixed $x$, cube integrals are continuous in $r$ by dominated convergence, so the maximum is attained and is measurable (equivalently use rational sides).

For each input and threshold, choose arbitrary probability laws $\nu_j$ satisfying
\[
 \operatorname{supp}\nu_j\subseteq
 \{v:\|v\|_\infty\le(r_j-r_{j-1})/(2n)\}.
 \tag{2}
\]
The laws may depend on the whole input and threshold, but are frozen before running the path, are independent of the evolving receiver, and do not depend on the initial receiver $x$. Let the increments $V_j\sim\nu_j$ be independent and set
\[
 Z_K=x,\qquad Z_{j-1}=Z_j-V_j,\qquad
 H_k=B_{r_{K-k}}f(Z_{K-k}).
 \tag{3}
\]
The filtration at chronological step $k$ contains $x$ and the already used increments. This is a finite chain, with deterministic atomic transition times and predictable mark laws $\nu_j$; there is no continuous-time intensity assertion or nonexplosion issue. Translation invariance gives
\[
 \int \mathbb E_x a(Z_j)\,dx=\int a(y)\,dy
 \tag{4}
\]
for every nonnegative measurable $a$. These are actual Lebesgue marginals on a sigma-finite path measure, not a normalized receiver probability. Receiver-dependent or path-adapted transition laws are not included.

## 2. The fixed and moving maxima are comparable on the same interval

Define
\[
 c_n=(1+1/n)^n\le e,\qquad C_n=(1+2/n)^n\le e^2.
\]
For every allowed path and every receiver,
\[
 C_n^{-1}Gf(x)\le\max_{0\le k\le K}H_k
                    \le c_nGf(x).
 \tag{5}
\]
Moreover, the consecutive moving cubes are nested.

Indeed, telescoping (2) gives the exact deterministic displacement bound
\[
 \|Z_j-x\|_\infty\le D_j:=\frac{2-r_j}{2n}.
 \tag{6}
\]
The moving cube at side $r_j$ is contained in the fixed cube centered at $x$ with side $s_j=r_j+(2-r_j)/n$. This side belongs to $[1,2]$ and $s_j/r_j\le q$. Positivity proves the upper half of (5).

For a given fixed side $r\in[1,2]$, put $t=(nr+2)/(n+1)$ and choose the smallest grid side $r_j\ge t$. Such a side exists, including at the endpoint $r=2$, where $r_j=2$ and $Z_j=x$. We have $r_j-r\ge(2-r_j)/n=2D_j$, so the fixed cube of side $r$ lies inside the moving cube at $r_j$. The grid ceiling also gives $r_j\le qt$ and hence
\[
 \frac{r_j}{r}\le q\frac{nr+2}{(n+1)r}
 \le q\frac{n+2}{n+1}=1+\frac2n.
\]
This proves the lower half. No receiver map is pushed forward at a stopping time, and no unproved multiplicity or Jacobian statement is needed: the containment holds on every path starting from the same actual receiver.

Finally, (2) implies
\[
 Q(Z_{j-1},r_{j-1})\subseteq Q(Z_j,r_j),\qquad
 H_{k+1}\le c_nH_k.
 \tag{7}
\]
Consequently a first threshold hit occurring after the initial observation has payoff at most $c_n\lambda$. Initial hits require a separate mass payment; (7) is not an overshoot bound for them.

## 3. Exact signed settlement and what it would suffice to pay

Define
\[
 e_j=U_{r_j}-\nu_j*U_{r_{j-1}},\qquad
 \tau=\min\bigl(\{k:H_k\ge\lambda\}\cup\{K\}\bigr),
\]
using $\lambda>0$ and the convention that a path with no hit is stopped at $K$. All hit and weak-level sets below use the same $\ge$ convention. The exact compensated martingale is
\[
 H_k+\sum_{\ell<k}(e_{K-\ell}*f)(Z_{K-\ell}).
\]
Write the globally signed, integrated compensator as
\[
 A_\tau(f;\nu)=\int\mathbb E_x
       \sum_{k<\tau}(e_{K-k}*f)(Z_{K-k})\,dx.
 \tag{8}
\]
This quantity is not the integral of the negative part of a conditional compensator. Finite optional stopping and (4) give
\[
 \int\mathbb E_xH_\tau\,dx=M-A_\tau(f;\nu),\qquad
 \lambda|\{Gf\ge C_n\lambda\}|\le M-A_\tau(f;\nu).
 \tag{9}
\]
To justify integration, each $H_k\le M$, $\int\mathbb E H_k=M$, $H_\tau\le\sum_{k=0}^KH_k$, and each residual has full $L^1$ norm at most two. Thus every displayed signed integral is absolutely integrable. The sign in (9) follows from the reverse increment $Z_{j-1}=Z_j-V_j$. The event implication used in (9) is pathwise (5).

The connection to the full local weak problem can be quantified in both directions. Define
\[
 W_n=\sup_{f\ge0,\,0<M<\infty,\,\theta>0}
       \frac{\theta|\{Gf\ge\theta\}|}{M}.
\]
Fix any rule $\mathcal R$ that chooses admissible frozen laws for each $(f,\lambda)$ and set
\[
 S(\mathcal R)=\sup_{f,\lambda}
       \left[\frac{-A_\tau(f;\mathcal R(f,\lambda))}{M}\right]_+.
\]
Then
\[
 W_n\le C_n(1+S(\mathcal R)),\qquad
 S(\mathcal R)\le1+c_n^2W_n.
 \tag{10}
\]
The first inequality follows from (9), with $\theta=C_n\lambda$. For the second, partition stopped paths into initial hits, later hits, and paths that never hit. The initial-hit payoff integrates to at most $\int B_2f=M$. By (7), later-hit payoff is at most $c_n\lambda$ times the integrated hit probability. The upper half of (5) bounds that probability by $|\{Gf\ge\lambda/c_n\}|$, so this contribution is at most $c_n^2W_nM$. On nonhitting paths the payoff is $H_K$, whose unrestricted integral is $M$ by (4). Therefore $\int\mathbb E H_\tau\le(2+c_n^2W_n)M$; subtracting $M$ proves (10).

This proves a dimension-free receiver and overshoot settlement, not a root-order estimate for $S$. In particular, choosing a different admissible frozen shift rule does not make the required signed estimate quantitatively weaker than the original local weak estimate.

## 4. A new constant payment for the recentering remainder

Separate the original scale difference from the added shift:
\[
 e_j=e_j^0+h_j,\qquad
 e_j^0=U_{r_j}-U_{r_{j-1}},\qquad
 h_j=U_{r_{j-1}}-\nu_j*U_{r_{j-1}}.
 \tag{11}
\]
For every bounded stopping time $\sigma\le K$, not only the first-hit rule,
\[
 \int\mathbb E_x\left|\sum_{k<\sigma}(h_{K-k}*f)(Z_{K-k})\right|dx
 \le M\sum_{j=1}^K\|h_j\|_1
 \le M\sum_{j=1}^K\frac{r_j-r_{j-1}}{r_{j-1}}
 \le q\log2\,M.
 \tag{12}
\]
Indeed, exact translated-cube geometry gives
\[
 \|U_r(\cdot-v)-U_r\|_1
 =2\left[1-\prod_{i=1}^n(1-|v_i|/r)_+\right]
 \le\frac{2}{r}\sum_i|v_i|.
\]
Averaging over (2) proves $\|h_j\|_1\le(r_j-r_{j-1})/r_{j-1}$. The triangle inequality, dropping the stopping indicator, (4), and Young's inequality give the first bound in (12). Finally, for $1\le u\le q$, $u-1\le u\log u\le q\log u$; sum over adjacent ratios to obtain $q\log2$. The shortened endpoint step is included in every sum.

Thus the remaining exact quantity is
\[
 A^0_\tau=\int\mathbb E_x\sum_{k<\tau}
                 (e^0_{K-k}*f)(Z_{K-k})\,dx,
 \qquad |A_\tau-A^0_\tau|\le q\log2\,M.
 \tag{13}
\]
A bound $A^0_\tau\ge-B_nM$ for all inputs and the selected rule would give $W_n\le C_n(1+B_n+q\log2)$. The intended $B_n=\sqrt n\,n^{o(1)}$ is not established. The evaluations in (13) remain at moving receivers and do not telescope as a fixed scale orbit.

## 5. An actual linear obstruction to absolute transport of the remaining term

One natural continuation is to replace $(e_j^0*f)(Z_j)$ by $(e_j^0*f)(x)$ and pay all translation errors absolutely. Even inside the small-shift class (2), this proposed payment can be linear.

Choose the admissible deterministic increments
\[
 V_j=\frac{r_j-r_{j-1}}{2n}\mathbf1,
 \quad Z_j=x-D_j\mathbf1,
 \quad L=\left\lfloor\frac{\log(3/2)}{\log q}\right\rfloor.
\]
For each $1\le j\le L$,
\[
 \|e_j^0(\cdot-D_j\mathbf1)-e_j^0\|_1\ge\frac27.
 \tag{14}
\]
To prove this, put $a=r_{j-1}$, $b=r_j$, and $D=D_j$. Since $a+b\ge2$, we have $D\le(b-a)/2$. Therefore the union of the two side-$a$ cubes, centered at $0$ and $D\mathbf1$, lies in the intersection of the corresponding two side-$b$ cubes. On the symmetric difference of the smaller cubes, the larger-cube terms in the translated scale difference cancel exactly, leaving magnitude $a^{-n}$. Its integral is
\[
 2\left[1-(1-D/a)^n\right].
\]
As $b\le3/2$ and $a\le3/2$, we have $D/a\ge1/(6n)$. The elementary inequality $(1-x)^{-n}\ge1+nx$ gives $(1-1/(6n))^n\le6/7$, proving (14).

Consequently the full absolute translation certificate is at least
\[
 \sum_{j=1}^K\|e_j^0(\cdot-D_j\mathbf1)-e_j^0\|_1
 \ge\frac{2L}{7}
 \ge\frac27\left(n\log(3/2)-1\right).
 \tag{15}
\]
For every $\eta>0$, one nonnegative unit-mass approximate identity makes the corresponding sum of actual input-convolved $L^1$ errors at least $2L/7-\eta$, since there are finitely many integrable residual kernels. This is an actual Euclidean operator-norm pressure test for the newly attempted absolute state-transport step. It is not a lower bound for the signed stopped sum, for any threshold event, or for the cube weak maximal norm. In particular, cancellation across steps remains possible.

## 6. Verification and remaining complement

The exact comparison and overshoot statement, the constant remainder payment, and the separate transport-pressure statement were each sent to both independent auditors before their proofs. Both auditors subsequently read the complete proofs and matching TeX and returned substantive mathematical PASS with no correction requested.

Three new stages were executed using Python's standard-library exact rational arithmetic. The pilot covers $n=2$ path geometry and continuum kernel norms; the stress stage adds asymmetric shifts, initial hits, genuine later hits, terminal nonhits, the natural half-threshold cap and the new absolute-transport obstruction; the expanded stage increases geometry through dimension 256, exact continuum kernel norms through dimension 6, receiver enumeration through dimension 4, and source concentration from side $1/8$ to $1/128$. Every assertion passed.

In pilot/stress/expanded order, the runs checked respectively 30/853/23017 continuous-scale geometry segments; 64/347/6046 exact support-partition cell multisets for Euclidean norms; and 99/5466/59865 stopped-path nodes at 9/150/775 rational receivers. The continuum norm partitions include the exact multinomial multiplicity of each coordinate-permuted cell. The path nodes use actual cube averages; their finite receiver enumeration is not a continuum stopped-path integral. Geometry-segment tests check the endpoints of affine containment inequalities covering whole scale intervals, not just selected scale samples. Rational lower series for $\log2$ certify the constant defect-budget comparison. Wrong reverse-increment signs are detected at 16/44/164 nodes.

The executable code and full per-stage receipt are retained in the private appendix of the companion Markdown file. These are author's executed tests, distinct from the auditors' independent evidence and from any parent replay. None qualifies original residual-event gates or establishes universal quantifiers without the proofs above.

The proposed signed route has gained a dimension-free moving-to-fixed receiver settlement and a constant payment for the added recentering defect. Nested cubes and frozen convolution marginals alone have not paid the remaining signed occupation (13). Bounding its state-transport errors absolutely is ruled out by (14)--(15), while (10) makes clear the quantitative strength required of a genuinely signed estimate. The heat-paper odometer mechanism supplied by the sources role has additional potential-evolution and generator defects; no matching paid potential is constructed here and no heat high-frequency estimate is transferred to cube orbits. All scales outside this local interval and all original gate, threshold and layer expenses still require the retained ledger. The arbitrary-input root-order goal remains open.

## S1. Primary source and actual reading boundary

[Spector–Stockdale, arXiv:2609.05377v1](https://arxiv.org/pdf/2609.05377v1), posted 4 September 2026, concerns Euclidean balls and heat evolution, not cube averages. This round actually read extracted original PDF printed pp.17–24: after (3.17), completion of Theorem 1.3, all relevant proofs in §§4–6. The layer definitions and Lemma 3.3, printed pp.14–16, were also checked for dependencies. No screenshot inspection, full earlier obstacle-proof reread, or independent reading of every external reference is claimed.

Theorem 1.3 assumes n≥3, a finite positive atomic ν of mass W, and Laplacian partial balayage ν=κ1_Ω dx−Δu with u≥0 and Ω={u>0}. Its Abel-power square integral outside Ω is bounded by an unspecified absolute constant times √N κW. Equations (4.8)–(4.9) recover the low Mellin energy; Lemma 5.1 converts its linear bandwidth growth into a squared logarithmic maximal budget. Section 6 selects κ proportional to the target height divided by log(eΛ), using the exterior sign of the ergodic average. All printed implicit constants remain unspecified; no invented numeric constant is attributed to the paper.

The critical dependence is a single free/killed resolvent system and absorption density, not arbitrary stopping layers. Lemma 3.3 uses the actual killed evolution, Poisson layers, and common μ=κ1_Ω: their sum is μ, their logarithmic integrated mass at layer j≥1 is W/j, and their pointwise size is O((j+1)^−1/2)μ. The late-layer estimate needs the positive Beta kernel and both Schur bounds. Its terminal layer uses the same L2 decay; passing regularized atoms to atoms uses support separation and Fatou. No retained cube tree or posterior has yet supplied these prerequisites.

## S2. Own geometry-independent low-frequency lemma, with constants

Let (X,dx) be a fixed sigma-finite receiver measure space. Let F(x,v) be jointly measurable and F_x∈L1(R_v) for almost every x. Use Fourier convention Fhat_x(ξ)=∫e^(−2πiξv)F_x(v)dv and r(ξ)=2πiξ/(1+2πiξ). Assume Λ≥1, K≥0 and

E(B):=∫_X∫_{|ξ|≤B}(2πξ)^2|Fhat_x(ξ)|²dξdx ≤ KB  (1≤B≤Λ).        (S2.1)

Define the inverse LOW-cutoff residual, rather than the original maximal function,

T_Λ(x)=sup_v |∫_{|ξ|≤Λ}e^(2πiξv)r(ξ)Fhat_x(ξ)dξ|.

Then, with J=ceil(log2Λ),

||T_Λ||²_L2(dx) ≤ [√2+(2/π)J]²K ≤ [3/2+(2/3)J]²K.              (S2.2)

Proof. On |ξ|≤1, |r/(2πξ)|≤1 (continuous interpretation at zero), so Cauchy–Schwarz and interval length 2 give ||T_0||_2≤√(2K). For each nonempty shell a=2^(j−1)<|ξ|≤b=min(2^j,Λ), use |r|≤1 and

∫_{a<|ξ|≤b}(2πξ)^−2dξ=(1/(2π²))(1/a−1/b).

Thus ||T_j||²_2≤Kb(1/a−1/b)/(2π²)≤K/(2π²), which is even stronger than the stated (2/π)²K. Minkowski sums at most J shells. These estimates also prove absolute integrability of the low inverse multiplier for almost every x. Its inverse is continuous in v by dominated convergence, so the supremum over rational v is the full supremum and is measurable. Tonelli and the given energy premise cover the receiver integration; no uncountable union of null sets is used.

The argument does not require balls, heat, independence, or receiver motion. It also does not give (S2.1) for the actual cube orbit. Energy outside Ω in the paper cannot be renamed energy of an original principal cut without proving the change of domain and the same common source.

## S3. Gamma smoothing recovers energy only with a paid square budget

For integer N≥1 let Φ_N(r)=N^N r^(N−1)e^(−Nr)/Γ(N), and define

G_N(x,v)=∫_0^∞Φ_N(r)F(x,v+log r)dr.

For F∈L2(dx dv), this is a contraction defined as convolution by a probability law. Its multiplier, with ω=2πξ, is

M_N(ξ)=N^(−iω)Γ(N+iω)/Γ(N),
|M_N(ξ)|²=∏_{q≥0}(1+ω²/(N+q)²)^−1.                            (S3.1)

The identity follows from the Gamma integral and Euler's ratio product; the positive argument N fixes the ordinary real logarithm in N^(−iω). Also

1/N ≤ Σ_{q≥0}(N+q)^−2 ≤ 2/N.

The upper sum estimate and log(1+x)≤x imply |M_N|≥e^(−1/4) on |ξ|≤√N/(4π). If the ACTUAL weak derivative satisfies

S_N:=∫_X∫_R |∂_vG_N|²dvdx ≤ C√N κW for every N≥1,             (S3.2)

Plancherel and N_B=ceil(16π²B²) give, for B≥1,

E_F(B) ≤ e^(1/2)S_(N_B) ≤ e^(1/2)C√(16π²+1) BκW.              (S3.3)

This scalar transfer does not need a semigroup: a Gamma-smoothed cube dilation orbit has the same multiplier identity. The critical √N square budget in (S3.2) is the missing hypothesis, not a consequence of the scalar smoothing identity.

A genuinely usable weaker bound is available without differentiating a hard cube. Let μ be an L1 density on R^n with 0≤μ≤κ and ∫μ=W. For full-side cube A_Lμ and a measurable cutoff 0≤χ≤1 supported on [a,b], H=b−a<∞, put F(x,v)=χ(v)A_(e^v)μ(x). Positive averaging gives ∫||F(·,v)||²_2dv≤HκW. From the LOWER sum estimate and the product inequality ∏(1+x_q)≥1+Σx_q,

ω²|M_N|² ≤ ω²/(1+ω²/N) ≤ N.

Consequently its smoothed weak derivative exists in L2 and

S_N ≤ NHκW.                                                    (S3.4)

This is a true cap-density finite-window cube estimate, with no smooth-source or original scale-derivative assumption. Its growth is N, rather than √N, so choosing N≈B² yields a quadratic bandwidth baseline, not the paper's critical linear energy. Cutoff endpoints, Gamma leakage outside the original window, comparison with the unsmoothed maximal function, and producing such a cap component from arbitrary f all remain separate costs. No original cube gate is inherited from χ or Gamma smoothing.

## S4. Own nonhomogeneous exterior absorption and its exact defects

Work on the SAME fixed L1(dx) receiver space. Let G_s be strongly measurable bounded operators with locally integrable norms, generating a positive mass-preserving evolution U(t,s), U(s,s)=I, whose backward-parameter derivative is ∂_sU(t,s)=−U(t,s)G_s. Let u_s∈L1 be nonnegative and absolutely continuous, and require G_su_s, u'_s, e_s to be strongly integrable on each finite interval. Put σ_s=−G_su_s+e_s. The product rule gives

∫_0^t U(t,s)σ_s ds
 = u_t−U(t,0)u_0−∫_0^tU(t,s)u'_s ds+∫_0^tU(t,s)e_s ds.         (S4.1)

On {u_t=0}, positivity yields the a.e. upper bound

(1/t)∫_0^tU(t,s)σ_s ds ≤ (1/t)∫_0^tU(t,s)[(−u'_s)_+ +(e_s)_+]ds. (S4.2)

This is an own strong-domain statement, not an unbounded heat-generator theorem under insufficient domains. For a fixed nonnegative potential u and a reference σ=−G_0u, the mismatch is explicitly e_s=(G_s−G_0)u. The autonomous case e_s=0,u'_s=0 has the exterior nonpositive sign. General nonhomogeneous evolution pays both potential decrease and generator mismatch. L1 contraction gives only the fixed-time integral bound by their L1 masses divided by t; it does not control the supremum over t. Neither hidden-source stopping laws nor moving receiver settlement are identified by (S4.1). Alternative has no current u/G candidate paying these terms; its small-shift moving-to-fixed comparison is a separate own route.

## S5. Own quantitative absorption with WEAK signed high-frequency payment

This interface deliberately replaces the excessive absolute Mellin-tail requirement. For every chosen κ>0, assume a common fixed receiver dx decomposition ν=μ_κ+σ_κ, an exceptional set Ω_κ of measure≤W/κ, and a positive averaging family T_t with sup_t T_tμ_κ≤κ. On Ω_κ^c assume

sup_t T_tν ≤ κ+T_κ+H_κ+J_κ,
||T_κ||²_2 ≤ CκW L²,
||H_κ||_(1,∞)≤AW,   ||J_κ||_(1,∞)≤BW.                         (S5.1)

All three envelopes are nonnegative and measurable. C,L,A,B must be uniform in κ and on this SAME dx; otherwise the cap choice below is circular. H_κ may be a signed high-frequency RESIDUAL maximal envelope. It need not be the integral of absolute Fourier coefficients. J_κ is the true positive defect from S4 or any independently justified error. Define q=max(1,√C L), and choose κ=α/(4q). Then

α|{sup_tT_tν>α}| ≤ [8q+4(A+B)]W.                              (S5.2)

Indeed Ω costs 4qW. Outside Ω, κ≤α/4, so one of T,H,J exceeds α/4. L2 Chebyshev costs 16CκWL²/α=4CL²W/q≤4qW; the two weak bounds cost 4(A+B)W. This proves the formula, including C=0 and zero envelopes. It is enough that the decomposition and estimates hold at this explicitly chosen cap with constants known independently of it; a uniform all-cap contract is a sufficient way to ensure this.

With L of logarithmic size from S2/S3 and bounded A,B, this genuinely closes an abstract fixed-receiver weak endpoint. It supplies no actual cube H_κ or J_κ budget. In particular R91's absolute high-tail obstruction does not logically refute the weaker signed-high hypothesis, and a weak high bound cannot be substituted into the absolute Fourier inversion argument without a new residual decomposition. The required sign of the low averaged σ and existence/measure of Ω must also be proved for the actual family. A cube principal source set is not automatically a Laplacian balayage exterior.

## S6. Three-stage verification and exact scope

Pilot: explicit one-block dyadic bounds, Gamma harmonic/product inequalities and finite-state product rule. Stress: empty band Λ=1, low zero energy, cap choice C=0, decreasing nonhomogeneous potential, and nonconstant generator; defects cannot be suppressed. Expanded checks vary integer N, frequency, truncation, receiver dimension and asymmetric evolution. Fresh inline Python stdlib Fraction execution passed 449 exact assertions in 0.005570 seconds: Gamma harmonic/product 175; dyadic shell 120; absorption cap 100; instantaneous nonhomogeneous product rule 54. No old-round counts are inherited. These are arithmetic/formula checks, not arbitrary-input energy or original gate certificates. Expanded input details: N∈{1,2,4,8,32}, product truncation R∈{1,2,4,16,64}, ω∈{0,1/4,1,4,16}; partial inverse-square sums plus the exact integral tail brackets and finite product inequality were checked. Dyadic j=1,…,12 and b/a∈{1,5/4,3/2,7/4,2} check the shell factor. Absorption uses C=c², c∈{0,1/4,1,2,8}, L∈{0,1/2,1,3,16}, q=max(1,cL), and (A,B)=(0,0),(1,2),(3/4,7/3). The local product-rule checks use conservative 2-state density generators [[−a,b],[a,−b]], (a,b)=(0,0),(1,2),(3/2,1/4), stochastic U=[[p,q],[1−p,1−q]] with (p,q)=(1,0),(1/3,2/3),(3/4,1/5), and the literal choices (u,u′,e)=((0,1),(−2,3),(1,−1)), ((2,4),(1,−5),(−2,3)), ((0,0),(0,0),(0,0)), including signed derivatives and zero states. This tests the instantaneous algebra conditional on U_s=−UG, not construction of a full evolution or any physical stopped chain. Finite harmonic brackets rely on the analytically proved monotone integral tail bounds; no finite product is substituted for the infinite Gamma product.

No H01/H02/H04/D02 asymptotic or annealed theorem has been used for the numeric pipeline. A constrained empirical phase profile under true Haar law must retain its multinomial probability and literal RN weights; neither optimized profile nor posterior law becomes iid Haar by naming a tilt. A requested exact numeric theorem requires a frozen phase law/statistic/rate and finite error direction before any such source transfer.

Current useful advance: a geometry-independent explicit low-frequency bound; Gamma recovery with its exact √N hypothesis and an actual N-growth cap baseline; and a signed-WEAK absorption interface permitting a separately proved weak high-frequency remainder. General cube closure, weighted recursion, original gate inheritance and unknown complements remain open.

# Parent: positive excess energy, exact reconstruction, and continuum cap probes

Status: a proved conditional general bridge and finite certified diagnostics. The new uniform excess-energy inequality below is OPEN. No original-gate qualification, general exponent, or weak-maximal lower bound is inferred from the probes. This is a public neutral construction, independent of private lower inputs.

## 1. The all-input criterion

Use full-side centered cubes, T_L nu(x)=L^(-n)nu(x+[-L/2,L/2]^n), for a finite nonnegative Borel measure nu of mass W. Fix constants A_n,B_n>=0. Suppose for EVERY nu and EVERY kappa>0 there exists ONE measurable receiver set Omega=Omega(nu,kappa), independent of L, such that

|Omega| <= A_n W/kappa,

E_kappa^+(nu;Omega):= integral_{Omega^c} integral_0^infinity (T_L nu(x)-kappa)_+^2 dL/L dx <= B_n kappa W.    (E)

All receiver integration is actual Lebesgue measure. The hypothesis is not a per-source or per-scale choice of exceptional sets. No such uniform estimate is established here. If it holds, the all-scale weak constant satisfies

C_n <= inf_{t>1} [A_n t + n B_n/(t J(t))],

J(t)=1/2-2/t+(log t+3/2)/t^2 >0.                                      (1)

For A_n,B_n>0 this in particular gives

C_n <= 4 A_n+2 sqrt(2n A_n B_n).                                    (2)

Thus subpower bounds for A_n and B_n would suffice for the requested general exponent. They are missing, not assumptions imported from a skill or a paper.

Proof. Positivity and nested cubes give T_{exp(v+s)}nu(x)>=exp(-ns)T_{exp(v)}nu(x), s>=0. For any strict witness T_{exp(v)}nu(x)>lambda and t=lambda/kappa>1, integrate the positive lower bound lambda exp(-ns)-kappa for 0<s<log(t)/n. Its squared integral is exactly lambda^2 J(t)/n. This is a receiver-wise implication and needs no measurable choice of a maximizing scale. Tonelli then gives lambda |{M nu>lambda}\Omega| <= n B_n W/(t J(t)); the exceptional set costs A_n t W. The event is measurable: for finite measures the mass of decreasing closed cubes tends to the limiting mass, so every strict witness persists along rational side lengths approaching from above. A countable supremum suffices.

Direct differentiation gives J(1)=0 and J'(t)=2(t-1-log t)/t^3>0. Also J(t)<1/2 for t>1, since log t+3/2<2t. For the explicit upper bound choose s=sqrt(2n B_n/A_n), t=4+s. Then tJ(t)>=t/2-2=s/2, so the fee is at most 4A_n+A_n s+2nB_n/s, proving (2). This is an exact order computation. Conversely every value in (1) is at least A_n t+2nB_n/t>=2sqrt(2n A_nB_n). Hence the optimized reconstruction cost lies within 4A_n of this root expression; the exponent is not fitted from the numerical data. If one constant is zero, retain the infimum formula and its limit, without division by that constant. W=0 is immediate.

## 2. Relation to signed caps and the small-scale limitation

If a common nonnegative density mu is bounded by kappa, then (T_L nu-kappa)_+ <= (T_L(nu-mu))_+ <= |T_L(nu-mu)|. Consequently a full signed log-scale L2 budget implies (E). This implication requires only the pointwise density bound; it does not require mu to vanish outside Omega.

However, the often-used convention mu=0 on Omega^c makes a full signed budget unsuitable for arbitrary diffuse input. If nu=f dx and f>0 on a positive-measure subset of Omega^c, differentiation of cube averages gives T_L(nu-mu)(x)->f(x)>0 there as L decreases to zero. Its squared integral against dL/L is infinite for almost every such x. This does not refute other caps with mu=f outside Omega, and it does not refute the positive-excess hypothesis (E). It prevents silently extending a finite-atomic signed-energy premise to all L1 inputs.

It is enough to prove a UNIFORM weak estimate derived from finite atomic caps, then extend the weak estimate itself. For compactly supported nonnegative f, partition into successively finer grids and move each cell's entire f mass to one representative, obtaining finite positive nu_j with the same mass. For every x and fixed L, nu_j(Q(x,L))->integral_Q f, because the boundary of that cube has Lebesgue measure zero and dominated convergence applies to f. A strict witness for M f>lambda therefore gives M nu_j>lambda eventually. Fatou preserves the same weak constant. Finally truncate a general nonnegative L1 f on expanding compact cubes and use monotone convergence of the maximal averages. This transfers a uniform weak bound, not caps or energy limits.

## 3. A general finite-input continuum certificate

The numerical target is the least possible excess energy after deleting a set of prescribed TRUE volume. The companion code normalizes W=kappa=1 and uses finitely many rational atoms in arbitrary finite dimension n. It does not merely evaluate a grid of receiver points.

For a receiver cell C and atom a_i of mass m_i, let r_i^- be twice the minimum infinity-distance from C to a_i and r_i^+ twice the maximum. Then the step profiles with entry sides r_i^+ and r_i^- bound T_L nu(x) below and above for EVERY x in C and EVERY L>0. Therefore their positive-excess energies bound the entire cell's energy. Endpoint choices do not affect the integral.

On an interval with captured mass m and constant entry pattern, put u=L^n. The exact positive-energy contribution, with endpoints u0<u1<=m, is

m^2/(2n)(u0^-2-u1^-2) - 2m/n(u0^-1-u1^-1) + (1/n)log(u1/u0).          (3)

When the next entry exceeds the positivity threshold, u1=m; no numerical nth root is needed. Every nonlogarithmic quantity is rational. If entry occurs at zero, the upper cell energy is infinite and that entire cell must be deleted in a finite upper certificate.

Logs are enclosed with 40 terms of log z=2 sum_{j>=0} w^(2j+1)/(2j+1), w=(z-1)/(z+1), after exact power-of-two reduction to 1<=z<2. The omitted tail is at most 2 w^81/[81(1-w^2)]. Log2 uses the same positive series. Negative power-of-two exponents reverse the appropriate interval endpoints. Every final conversion is outward to a 44-bit dyadic, using integer floor/ceiling. The interval endpoints are certificates; their JSON decimal views are only display approximations.

All positive-excess receivers lie in the union of side-one cubes about the atoms: a positive excess requires L<1 and at least one captured atom. The code covers a bounding box of that union by disjoint grid cells and pays nothing outside, where the excess is identically zero. Each cell has its full n-dimensional volume. Delete the allowed number of cells having largest certified upper energies, including all infinite cells. The sum of remaining upper energies times cell volume is a certified continuum upper bound for this explicit measurable cap. Its volume is at most the allowed budget.

A complementary LOWER bound for the optimum over ALL measurable caps comes from the lower step field: remove its largest cell values first, allowing fractional deletion of the last cell. This is the elementary rearrangement minimum for a cellwise constant function. Since the true energy dominates that field, no admissible cap can have a smaller retained energy. This lower bound is for a fixed finite input and the declared cap budget, not an operator weak lower bound or a uniform dimensional obstruction.

## 4. Three stages actually executed

Run: python3 -B parent_energy_probe.py --output parent_energy_results.json. Standard library only. The exact source configurations and every cap selection rule are in that public neutral script.

|Stage|Input|n|Mesh denominator|Continuum cells|Cap volume|Optimal lower|Selected-cap upper|
|---|---|---:|---:|---:|---:|---:|---:|
|pilot|two atoms|1|8|12|0.5|0.00247607|0.14486039|
|pilot|four square corners|2|4|36|1|0|0.04828680|
|stress|unequal chain|1|32|64|0.5|0.00266531|0.03783055|
|stress|four square corners|2|8|144|1|0|0.01207170|
|stress|eight cube corners|3|4|216|1|0|0.43321699|
|expanded|two atoms|1|64|96|0.5|0.02562130|0.04341934|
|expanded|four square corners|2|16|576|1|0|0.00184743|
|expanded|eight cube corners|3|8|1728|1|0|0.06642733|

The printed decimals summarize rational endpoints retained in JSON. The run covers 2,872 continuum cells, with exact envelope/order/volume assertions, plus 27 explicitly FLOATING reconstruction diagnostics. The latter compare J(t) with independent Simpson integration and check the explicit choice in (2), at dimensions from 1 through 1,048,576. They do not compute actual high-dimensional cube inputs and are not interval certificates. Measured producer runtime was 0.27032825 seconds. Parent isolated reproduction and independent audit receipts will be recorded separately.

Pilot includes atomic jump singularities; the stress stage includes unequal masses, zero-entry cells and changes of dimension; expanded stages increase spatial resolution and confirm narrowing bounds for repeated inputs. No iid probability, phase model, Fnew membership, asymptotic cap bound or accepted lower-family status is asserted. These calculations make a general candidate inequality testable, but do not establish it. In particular, small-dimensional feasible caps cannot justify B_n=n^{o(1)}.

## 5. Next exact bottleneck and skill scope

The required new geometric theorem is (E), or a finite-atomic signed-cap construction uniformly implying it, with A_n B_n subpower and A_n subpower. The optimal-cap formulation retains true receiver volume, all scales, and one common set; it cannot be replaced by pointwise source caps, fixed-scale L2 norms or independently deleted scale events. The current package does not prove this theorem. It is a candidate for adversarial higher-dimensional/structured tests and a common-source variational argument, not a new assumed tool.

The parent reread current N03 skill, its method and cube-interface, and inspected the provenance boundaries; no advanced van der Corput, Guo or private half-density theorem was imported. The proof above uses elementary positivity, integration, differentiation and exact rational arithmetic. The source group separately reviewed the remaining primary heat-paper mechanism; it does not provide the cube excess-energy estimate. The general root-order weak bound remains OPEN.

本轮在同一冻结的有限正 L1 输入及同一阈值下，进行了一次有界确定性相位轮廓搜索。没有新增独立同分布抽样，也没有把优化轮廓当成 Haar 概率。三个新测试保留全部坐标的独立区间宽度，计算坐标置换形成的真实接收集合。

设相位区间 I_j 两两不交，正整数坐标计数 k_j 满足 sum(k_j)=n。恰有 k_j 个坐标属于 I_j 的集合 Gamma，其真实 Lebesgue 体积为：

    |Gamma| = [n! / product(k_j!)] * product(|I_j|^k_j).

不同置换盒仅在零测边界相交。本轮保存完整整数多项式系数及有理对数上下界，保留组合因子和全部坐标宽度。三个体积的对数近似为 −485101.135、−348822.854、−266488.059；小数仅显示量级，严格端点采用有理数。组合因子大幅增加体积，但所得集合仍非常小。

三个完整区间盒都取得原连续尺度最早硬接触的区间证书：严格排除从尺度 1 开始的无间隙前缀，包括更早切触，并给出对全盒成立的严格后续见证。全部坐标独立变化；同形因子的计数压缩没有降低维数。来源的坐标置换对称性把证书传递给整个 Gamma。其补集仍未认证。

本轮还取得一个真实容量的定量否定。若 Gamma 位于 [a,b]^n，w=b−a<1，且原接触边长均至少为 1，则共同来源盒

    G = [b−1/2, a+1/2]^n

被每个接触立方体捕获。若实际来源密度在 G 上至少为 m0^n>0，将真实需求 lambda dx 按同一个 mu|G / mu(G) 分配，便得到连续来源运输：

    K_opt <= lambda*|Gamma| / [m0*(1−w)]^n
          <= lambda * [sum(|I_j|)/(m0*(1−w))]^n.

该上界适用于 Gamma 中任何实际通过全部门槛的子集。位于有限支持内的整数平移副本，其共同来源盒边长小于 1，彼此不交，所以最高列负载取最大值，无需乘副本数。三个所选集合的精确有理参数均给出很小的容量上界，不能充当高 Hall 负担证据。这个结论只涉及所选小相位跨度类；它不是整个残余集合的上界，也不是规范后验列的上界。

新软核运行中，三个原全窗软核上门均通过，三个接触处粗门均为 UNKNOWN；尚无完整资格认证。UNKNOWN 保留整个相应集合的不确定性，不能置零。原中门标量条件与包参数的后验分支是不同条件；本来源已证明的包参数域为 0<p<=n，域外仍为 UNKNOWN。没有取得高负载主割、径向预算或一般根号维数上界。

The numerical checks retained the true receiver volume of wider phase boxes, including all coordinate widths and permutation multiplicities. The original full-window upper gate passed on the selected sets, while the uniform coarse gate remained unresolved. One bounded corner check also produced no certified exclusion. These results supply no qualified residual-volume, probability or high-load conclusion; the general weak bound remains open.

## R92 independent Astra audit

**General root-order closure remains OPEN.** Exact statements were independently checked before new proofs; complete Markdown and matching TeX were then read for all three theoretical routes, source transfers and the parent energy criterion. Mathematical PASS below means the stated theorem with its recorded scope, not an unrestricted endpoint result.

- **Actual annular allocation — PASS.** A nonnegative union kernel and exact row normalization give common-source capture allocations and every-subcut capacity bounds. Low coordinate-count traffic has a root-size one-stage fee; high-count traffic has a linear fee. The alternative exact profile-weighted capacity is a separate algorithm, not an extra charge. All threshold weights, repeated source occupation, out-of-band stages and finite terminals remain. The complete-band bound is still priced in D0/R_min, not W0.
- **Principal leakage and opposing occupation — PASS.** The canonical leakage identity is integrated over the same source set; it does not assume a pointwise comparison with the optimizer. The piecewise prefix function and its actual slab-pushforward bound pay the specified high-share opposing current only under near-envelope leakage. Low-share, external-ambient and other inactive-partner currents remain unpaid. Completion keeps the ambient column fixed or recomputes it explicitly.
- **Moving receivers and signed stopping — PASS.** Frozen small convolution shifts give a dimension-free comparison with the fixed-receiver local maximal function, correct overshoot/initial-hit accounting and the signed endpoint identity. The added recentering defect has a constant mass fee. The remaining stopped scale-difference occupation at moving receivers is unproved. The absolute state-transport pressure rules out only that absolute certificate; it does not rule out signed cancellation or establish a weak lower bound.
- **Energy and source interfaces — PASS, conditional.** The explicit low-frequency lemma, Gamma multiplier recovery and bounded-generator defect identity retain their hypotheses. The actual capped-density baseline grows like N, whereas the desired square budget grows like sqrt(N). Weak signed-high absorption needs separately paid high-frequency and generator defects. The parent positive-excess criterion gives fee inf over t>1 of A*t+n*B/(t*J(t)), and hence 4*A+2*sqrt(2*n*A*B), but its uniform all-input energy premise is OPEN. Finite-atomic approximation transfers only a uniform final weak bound to L1, not the cap-energy premise. Primary-paper page reading remains attributed to the source author.
- **Actual volume and gates — PASS with UNKNOWN retained.** Exact multinomial factors and all n coordinate widths were retained for the selected permutation unions. Three whole-bin original first-contact certificates and all-window upper gates pass; all three coarse gates and one exact corner remain UNKNOWN. The point supplies no exclusion or volume conclusion. A direct common-capture allocation proves that this selected small-span class has very small feasible capacity, also for any actual qualified subset. Neither the selected sets nor their complement establish a whole-residual high-load result. Original middle and packet-domain statements remain separate; packet coverage is only 0<p<=n.

New independent executions: alternative exact three-stage kernel/path checks passed in 13.461320666 seconds; parent energy continuum certificate reproduced exactly in 0.325264750 seconds (2872 continuum cells, with 27 separately labeled floating diagnostics); receiver search/root/true-volume objects reproduced exactly in 1.327724125 seconds; the complete frozen soft result reproduced exactly in 110.857443917 seconds, ignoring only its two timing keys. Finite tests are not universal proofs, and prior-round counts are not included.

Original common input and threshold, actual dx, whole-event versus subset distinctions, source reselection, all old paid branches, the physical union fee once, localization and any original layer count remain in force. Private physical pressure details stay outside this public extract. Public formulas use plain text to avoid escape corruption.

## R92 independent audit — final

The general centered-cube weak bound of order sqrt(n)n^{o(1)} for arbitrary positive L1 input remains UNPROVED. Sol read the complete new contract and reviewed the six exact candidates before their proofs. The full coverage, adaptive, alternative and sources Markdown proofs and matching TeX, parent energy proof and matching TeX, numerical code/reports, and retained intro/ledger/header scope subsequently PASS within the stated limits. Source-author primary-paper and skill reading receipts belong to that author; Sol does not claim those external pages were personally reread.

Coverage pays only a near-envelope, high-terminal-share opposing-current portion using the SAME source, exact canonical leakage and prefix coefficient. Low share, receivers outside the ambient compact set, other stopping/classification escapes and the complete signed current remain unpaid. Completion does not preserve the former principal optimizer identity automatically. Adaptive direct transport genuinely removes the former packet-envelope/log-count prices on its traffic-defined receiver set; the low-count branch has a root fee, while high-count traffic and repeated threshold-weighted source occupation remain. When the guaranteed count k exceeds J, the low-count part is empty; k is comparable to1+R, so high-load R much larger than sqrt(n) is not paid by choosing J of order sqrt(n). The variable-count version is an alternative algorithm, with its own exact weighted ledger. Neither variant gives a general source-mass closure or pays arbitrary band exit/unfinished terminal events.

The small-shift convolution process pays fixed-versus-moving comparison and the added recentering defect on actual Lebesgue receivers. Its remaining stopped signed scale-difference occupation is OPEN; the linear termwise absolute transport obstruction is scoped to that certificate, not a weak-maximal lower bound. Low-frequency, Gamma and nonautonomous source interfaces retain their actual energy, strong-domain, common-measure and signed-high/defect hypotheses. The proved cube cap cutoff gives N growth, not the required sqrt(N) budget. Parent energy proves the exact conditional fee inf(t>1)[A_n t+n B_n/(t J(t))] and the bound4A_n+2sqrt(2n A_n B_n); its common exceptional-set positive-excess hypothesis is OPEN. A uniform finite-atomic weak bound can transfer to L1, while signed cap-energy assumptions do not automatically transfer.

The fresh public stdlib guard reconstructs518 generic rational assertions and2916 saved public-energy assertions, including all2872 genuine continuum receiver cells,8 cap-volume/energy certificates and binding of the public producer/result hashes. It imports no author algorithm or private input. The27 producer reconstruction diagnostics are FLOATING and are not counted as exact energy proofs. The five-member mock public assembly, with the guard extracted from the sole proof.md Python fence, passes3438 assertions including4 portability checks:0.312537417 seconds internally,0.336928125 seconds wall time, exit0 and empty stderr. This verifies mock archive independence; final actual-package verification remains the assembler's separate receipt. No earlier-round checks or author counts are counted as this new independent guard.

Sol actually isolated-replayed the public energy producer: exact JSON after deleting only its top-level runtime_seconds,0.360414375 seconds. Sol also isolated-replayed the alternative embedded exact code: all three JSON receipts exact with no ignored fields,13.684021583 seconds; its23900 geometry segments,6457 support-partition multisets and65430 finite path nodes are record units rather than assertion counts or continuum stopped integrals.

The new receiver replay is exact on every JSON field, with none removed,2.599221542 seconds. It reproduces three whole-bin original first-contact certificates,23 gapless strict prefix segments and true full-dimensional permutation-union volumes with their complete multinomial factor. Sol separately checked the prefix threshold/brackets and combination/width arithmetic. The deterministic optimizer and its floating screens are not iid Haar draws. A common physical source cube provides a valid transport upper for any qualified subset of the selected phase-span class; these sets cannot supply high Hall burden. This does not bound the canonical allocation or the unexamined residual complement.

The final full soft replay, including the one fixed corner discriminator, is exact on every mathematical JSON field after recursively deleting ONLY runtime_seconds and runtime_seconds_diagnostic:113.561964167 seconds, exit0 and empty stderr. All three original ALL-window soft upper gates pass; all three uniform original coarse gates and the single exact corner coarse gate remain UNKNOWN. Unknown candidate volume is retained, with no certified HIGH, a.e. exclusion, bad-volume or full-residual-volume claim. Original middle is independent of the packet parameter; packet qualification is certified only in the stated0<p<=n domain, with n<p UNKNOWN. There is no iid/RN confidence, high-load principal cut or canonical I_T certificate.

All original branch prices, same-source quantifiers, actual lambda dx, full all-principal variance requirements, source survival/threshold switches, C_loc log(n+2), additional layer fee J_n and terminal/exit terms remain in the main ledger. Finite certificates and paid subsets do not establish general root-order closure.

## 第92轮实际验证及可复现边界

本轮新增论证的命题先交由 Astra high 与 Sol high 分别检查量词和潜在反例，再逐项阅读完整 Markdown 与对应 LaTeX。两审均确认已证明部分的范围，未确认一般根阶上界。主代理保留原主账、完整软硬条件、真实来源/接收测度、阈值漂移、退出与终项费用。

公开精确审核程序的新检查共3434项：覆盖114、小位移路线246、薄环直接运输77、来源接口39、能量桥梁30、真实体积12、公开连续能量证书独立重建2916。最后一组使用独立90项有理对数原函数重建全部2872连续接收格及8个删集证书，不导入生产程序。主代理隔离运行0.302819209秒、exit0、stderr空。最终五成员归档提取运行另外检查4项可携带性；这不算新增数学论证，也不把重放次数叠加成新实验。

小位移路线的中性精确程序实际检查23900连续尺度几何分段、6457支持划分多重集和65430有限接收/路径节点。三种计数单位不同，不相加为断言数，也不代表连续停止路径积分。主代理完整隔离重放12.326719917秒，三条阶段JSON全部精确一致，没有忽略字段。两审独立执行分别13.461320666和13.684021583秒。

公开正超额能量程序生成8个有限原子输入的实际连续接收区域上下证书，共2872格。全部维度、体积与任意可测删集下界保留。另27项重构公式的Simpson检查是FLOAT诊断；其中高维参数只用于公式，不是真实高维输入证书。生产0.270328250秒，主代理隔离重放0.342715208秒；两审分别0.325264750、0.360414375秒。JSON仅删除顶层runtime_seconds后精确一致。有限低维结果不推出一般能量前提或其维数阶数。

私人压力输入保持来源与共同阈值不变。一次20轮廓FLOAT确定性筛选后冻结候选，检验3个逐渐增宽的全维相位置换并集；真实体积包含完整组合系数与全部坐标宽度。3组原连续最早接触均获认证，共23无间隙前缀段、74端点计算。最终生产1.852472375秒；主代理在软核辅助程序冻结后隔离重放2.711738834秒，JSON全字段精确一致。两个审计者的独立运行分别1.327724125秒（非写入字段重建）和2.599221542秒（完整隔离重放）。这些并集仍极小，实际共同来源运输给出所选类的小容量上界，不能称作高负载例子。

软门初探保留整箱相位范围和完整原首触括号，压力阶段核验非零宽度及真正全维计数，扩大阶段对3箱执行完整原全窗和粗门。生产三阶段86.519591500秒，另一次有界角点增量21.372236250秒；作者并未声称该最终版本曾一次性完整生产运行。3组原全窗上门PASS，3组原粗门全部UNKNOWN；额外8角点仅为FLOAT诊断，唯一精确点的原首触虽获认证，其粗门仍UNKNOWN。没有正体积坏集、完整Fnew资格、全余集测度或渐近负载结论。原中门标量条件独立于包指数；已证后验包分支仅0<p<=n，n<p未知。未知集合与补集都没有置零。

最终软程序由两审及主代理分别一次完整隔离重放：110.857443917、113.561964167、113.299071459秒，均exit0、stderr空。所有数学JSON字段精确一致，递归仅忽略明确列出的runtime_seconds和runtime_seconds_diagnostic；所有冻结来源、接收与代码哈希保持一致。重放同一确定性检验不产生新抽样或置信结论。

更新后的64技能入口字节被记录为快照，快照只确认版本。实际定向阅读是N03及来源组F04/F05/N03的入口、方法、课题接口和相关证据边界；不是64篇定理全部重新验收。来源组阅读记录明确球/热论文原文页码、外引边界和Gamma导数能量仍缺的平方根费用。没有把技能名称、候选题录、哈希或论文作者结论直接当作方体定理。

复现公开部分：解压research.zip，用Python3运行parent_energy_probe.py并另存结果；从proof.md唯一Python代码块保存audit_guard.py，与其余成员置于同目录运行。标准库即可，无私人输入依赖。生产结果中的小数仅显示，有理端点才是区间证书。所有原文推导和私人程序保存在本地只读轮次目录；公开包只含明确公共段落、中性输入、必要代码与清单。

LaTeX仅作环境配对、括号、重复标签、内部引用及控制字符静态检查，不编译，不生成PDF。一般n^(1/2+o(1))弱上界仍未证明；主要缺口是高计数与重复加权来源占用、低捕获份额及退出分支、有符号尺度占用或统一全尺度正超额能量预算。


## 独立公开审核程序

```python
#!/usr/bin/env python3
"""Independent R92 finite rational guard, no producer/private imports.
Finite models test NEW interfaces only; continuum and gate claims need proofs.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
import hashlib
import math
import re
import time
from functools import lru_cache

COUNTS={}
STAGES={}

def check(value, route, stage):
    assert value,(route,stage)
    COUNTS[route]=COUNTS.get(route,0)+1
    STAGES[stage]=STAGES.get(stage,0)+1

def log_unit(x):
    z=(x-1)/(x+1)
    v=2*sum((z**(2*j+1)/F(2*j+1) for j in range(90)),F(0))
    tail=2*abs(z)**181/(181*(1-z*z))
    return v-tail,v+tail

@lru_cache(None)
def logbox(x):
    x=F(x);assert x>0
    k=0
    while x>2:x/=2;k+=1
    while x<1:x*=2;k-=1
    lo,hi=log_unit(x);a,b=log_unit(F(2))
    return (lo+k*a,hi+k*b) if k>=0 else (lo+k*b,hi+k*a)

def coverage(stage,dims):
    for n,tau in product(dims,[F(4,3),F(7,4)]):
        qt=tau**(-n)
        for q in [qt/3,qt,F(1,2),F(1)]:
            c=q*tau**n
            if c<=1:
                psi=c*(1-tau**(-n))/n
                check(psi/q==(tau**n-1)/n,'coverage',stage)
                check(0<=psi<=1/n,'coverage',stage)
            else:
                a,b=logbox(c)
                lo,hi=a/n+(1-q)/n,b/n+(1-q)/n
                lt=logbox(tau)
                check(lo>=0 and (lo<=lt[1] and lt[0]<=hi if q==1 else hi<=lt[0]),'coverage',stage)
                check((1-q)/(n*q)>=0,'coverage',stage)
        check((1-qt)/n==1*(1-tau**(-n))/n,'coverage',stage)
    # Canonical captured-row mass, not pointwise optimized-column comparison.
    lam=F(5,3); rows=[F(2,7),F(3,5),F(4,9)]; q=[F(1),F(2,5),F(3,4)]
    D=lam*rows[0]; HM=lam*sum(v*p for v,p in zip(rows,q))+F(2,11)
    leak=lam*sum(v*p for v,p in zip(rows[1:],q[1:]))
    eta=F(1,2)
    eligible=sum(v for v,p in zip(rows[1:],q[1:]) if p>=eta)
    check(leak<=HM-D and lam*eligible<=leak/eta,'coverage',stage)
    check(HM-D>=0 and D<=HM,'coverage',stage)

def alternative(stage,dims):
    for n in dims:
        q=1+F(1,n);grid=[F(1)]
        while grid[-1]*q<2:grid.append(grid[-1]*q)
        if grid[-1]!=2:grid.append(F(2))
        for r in [F(1),F(9,8),F(3,2),F(2)]:
            t=(n*r+2)/(n+1);R=next(v for v in grid if v>=t)
            D=(2-R)/(2*n)
            check(R-r>=2*D and R/r<=1+F(2,n),'alternative',stage)
        defect=F(0)
        for a,b in zip(grid,grid[1:]):
            delta=b-a;D=(2-b)/(2*n)
            check(delta/(2*n)<=delta/2,'alternative',stage)
            check(b+(2-b)/n<=2 and (b+(2-b)/n)/b<=q,'alternative',stage)
            shift=delta/(2*n)
            tv=2*(1-(1-shift/a)**n)
            check(tv<=delta/a,'alternative',stage)
            defect+=delta/a
            if b<=F(3,2):
                check(D<=delta/2 and D/a>=F(1,6*n),'alternative',stage)
                check(2*(1-(1-D/a)**n)>=F(2,7),'alternative',stage)
        check(defect<=q*logbox(F(2))[1],'alternative',stage)
    # New stopping/overshoot partition coefficients, no reused old process test.
    c=F(5,2);W=F(3,4);M=F(7,3)
    stopped_bound=2*M+c*c*W*M
    check((stopped_bound-M)/M==1+c*c*W,'alternative',stage)

def adaptive(stage):
    nr,ns=[(3,4),(5,6),(7,9)][stage]
    dx=[F(2+i,11+i) for i in range(nr)]
    mu=[F(1+j,9+j) for j in range(ns)]
    lam=F(3)
    K=[[F(1+(2*i+3*j)%5,13) for j in range(ns)] for i in range(nr)]
    load=[sum(k*m for k,m in zip(row,mu)) for row in K]
    top=max(load)
    if top>lam:
        K=[[k*lam/top for k in row] for row in K]
        load=[sum(k*m for k,m in zip(row,mu)) for row in K]
    total=sum(d*r for d,r in zip(dx,load));V=sum(dx);a=total/(lam*V)
    chosen=[i for i,r in enumerate(load) if r>=a*lam/2]
    cap=max(sum(dx[i]*K[i][j] for i in range(nr)) for j in range(ns))
    allocation=[[lam*K[i][j]/load[i] for j in range(ns)] for i in chosen]
    check(0<a<=1 and sum(dx[i] for i in chosen)>=a*V/(2-a),'adaptive',stage)
    for row in allocation:check(sum(k*m for k,m in zip(row,mu))==lam,'adaptive',stage)
    for j in range(ns):
        check(sum(dx[i]*allocation[u][j] for u,i in enumerate(chosen))<=2*cap/a,'adaptive',stage)
    for subset in [chosen[:1],chosen[::2],chosen]:
        neighbours={j for i in subset for j in range(ns) if K[i][j]>0}
        check(lam*sum(dx[i] for i in subset)<=2*cap/a*sum(mu[j] for j in neighbours),'adaptive',stage)
    # Variable-capacity alternative: same whole kernel, not a second charge.
    gamma=a/2
    profile=list(range(1,ns+1))
    Ch=max(sum(dx[i]*K[i][j] for i in range(nr))/profile[j] for j in range(ns))
    check(sum(dx[i] for i in chosen)>=gamma*V/(1-gamma),'adaptive',stage)
    for j in range(ns):
        check(sum(dx[i]*allocation[u][j] for u,i in enumerate(chosen))<=Ch*profile[j]/gamma,'adaptive',stage)
    check(lam*sum(dx[i] for i in chosen)<=Ch/gamma*sum(p*m for p,m in zip(profile,mu)),'adaptive',stage)
    # Common directional budget tradeoff; correlated weights on one source.
    n=[16,32,128][stage];budget=F(3,2)
    weights=[[budget*F(1+j%3,sum(1+t%3 for t in range(n))) for j in range(n)] for _ in range(3)]
    check(all(sum(row)==budget for row in weights),'adaptive',stage)
    check(sum(F(1,3)*sum(row) for row in weights)/n==budget/n,'adaptive',stage)
    # Public tests use only generic equal-column algebra, no private cone recipe.

def sources(stage):
    # Weighted frequency shells after removing the pi factor, with last cutoff.
    for a,b in [(F(1),F(3,2)),(F(2),F(4)),(F(4),F(5))]:
        squared=b*2*(1/a-1/b)/4
        check(b<=2*a and 0<squared<=1,'sources',stage)
    N=[1,4,19][stage]
    partial=sum((F(1,(N+j)**2) for j in range(4*N)),F(0))
    remainder_upper=F(1,N+4*N-1)
    check(partial+remainder_upper<=F(2,N),'sources',stage)
    check(partial+F(1,N+4*N)>=F(1,N),'sources',stage)
    # Integral comparison gives full sum>=1/N; finite product>=1+sum.
    omega=F(1,3);factors=[1+omega**2/F((N+j)**2) for j in range(4)]
    value=math.prod(factors)
    check(value>=1+sum((v-1 for v in factors),F(0)),'sources',stage)
    # New nonzero-generator instantaneous product rule; conditional on U_s=-UG.
    def mv(A,x):return [sum(a*b for a,b in zip(row,x)) for row in A]
    def mm(A,B):return [[sum(A[i][k]*B[k][j] for k in range(2)) for j in range(2)] for i in range(2)]
    rate=F(stage+2,3);back=F(5,stage+4)
    G=[[-rate,back],[rate,-back]]
    U=[[F(1,4),F(3,5)],[F(3,4),F(2,5)]]
    u=[F(2),F(5)];du=[F(-1),F(3)];e=[F(-2,5),F(3,7)]
    Us=[[-v for v in row] for row in mm(U,G)]
    derivative=[x+y for x,y in zip(mv(Us,u),mv(U,du))]
    sigma=[-x+y for x,y in zip(mv(G,u),e)]
    check(mv(U,sigma)==[x-y+z for x,y,z in zip(derivative,mv(U,du),mv(U,e))],'sources',stage)
    check(all(sum(G[i][j] for i in range(2))==0 for j in range(2)),'sources',stage)
    C,L,A,B,alpha=F(9,4),F(2),F(3,5),F(7,9),F(11,6)
    q=F(3);kappa=alpha/(4*q)
    check(4*C*L*L/q<=4*q,'sources',stage)
    check(alpha/kappa+16*C*kappa*L*L/alpha+4*(A+B)<=8*q+4*(A+B),'sources',stage)
    for c,L in [(F(0),F(7)),(F(5,7),F(0)),(F(11,7),F(13,9))]:
        q=max(F(1),c*L);kappa=alpha/(4*q)
        check(4*c*c*L*L/q<=4*q and kappa<=alpha/4,'sources',stage)

def energy(stage):
    for t in [F(5,4),F(2),F(4+stage)]:
        lo,hi=logbox(t)
        Jlo=F(1,2)-2/t+(lo+F(3,2))/t**2
        Jhi=F(1,2)-2/t+(hi+F(3,2))/t**2
        check(Jlo>0 and Jlo<=Jhi,'energy',stage)
        check(t-1-hi>0,'energy',stage) # J'=2(t-1-logt)/t^3.
        check(1-1/t>0,'energy',stage)
    # At t=4, the improved J payment dominates the earlier slab witness.
    log2lo=logbox(F(2))[0];log4lo=logbox(F(4))[0]
    J4=F(1,2)-F(1,2)+(log4lo+F(3,2))/16
    check(J4>=log2lo/16,'energy',stage)

def volume(stage):
    counts=[[2,2],[2,3,1],[3,4,2]][stage];n=sum(counts)
    widths=[F(1,5+j) for j in range(len(counts))]
    denom=math.prod(math.factorial(c) for c in counts)
    mult=F(math.factorial(n),denom)
    # Independent sequential choice equals the multinomial coefficient.
    remaining=n;ways=1
    for c in counts:ways*=math.comb(remaining,c);remaining-=c
    check(mult==ways and mult.denominator==1,'volume',stage)
    box=math.prod(w**c for w,c in zip(widths,counts))
    check(0<mult*box<=1 and mult*box>=box,'volume',stage)
    check(n==sum(counts) and box!=math.prod(widths),'volume',stage)
    # Newly added common-capture transport upper uses the actual union volume,
    # bounded by the full product union; the multinomial factor is retained.
    check(mult*box<=sum(widths)**n,'volume',stage)

def saved_energy(root):
    """Rebuild the public neutral finite-cell integrals, never import producer."""
    path=root/'parent_energy_results.json'
    if not path.exists():return
    saved=json.loads(path.read_text())
    check(saved['total_continuum_cells']==2872 and saved['total_floating_checks']==27,'saved_energy',3)
    check(hashlib.sha256(path.read_bytes()).hexdigest()=='b6e5d8f0eba8f9b183075d8dfa1e05fbbc466f63ef12ca732b0df281095db83d','saved_energy',3)
    check(hashlib.sha256((root/'parent_energy_probe.py').read_bytes()).hexdigest()=='9d8ae1e787d6444b4bad02309f58ee9e7cd33015df1d7a7d64bb35d8fc605718','saved_energy',3)
    def corners(n):
        return [(tuple(F(s,4) for s in signs),F(1,2**n)) for signs in product((-1,1),repeat=n)]
    specs=[(corners(1),8,F(1,2)),(corners(2),4,F(1)),
           ([((F(-1,2),),F(1,8)),((F(-1,8),),F(3,8)),((F(0),),F(1,4)),((F(1,2),),F(1,4))],32,F(1,2)),
           (corners(2),8,F(1)),(corners(3),4,F(1)),(corners(1),64,F(1,2)),
           (corners(2),16,F(1)),(corners(3),8,F(1))]
    @lru_cache(None)
    def primitive(n,arrivals):
        entries=sorted(set(r for r,m in arrivals))
        if entries[0]==0:return None
        lo=hi=F(0)
        for j,r in enumerate(entries):
            m=sum((mass for side,mass in arrivals if side<=r),F(0))
            a=r**n;b=min(m,entries[j+1]**n) if j+1<len(entries) else m
            if a>=b:continue
            rational=m*m*(a**-2-b**-2)/(2*n)-2*m*(1/a-1/b)/n
            l,u=logbox(b/a)
            lo+=rational+l/n;hi+=rational+u/n
        return max(F(0),lo),max(F(0),hi)
    certificates=[c for stage in saved['stages'] for c in stage['certificates']]
    for (atoms,mesh,budget),record in zip(specs,certificates):
        n=len(atoms[0][0]);step=F(1,mesh);cellvol=step**n
        ranges=[]
        for axis in range(n):
            low=min(a[axis] for a,m in atoms)-F(1,2)
            high=max(a[axis] for a,m in atoms)+F(1,2)
            ranges.append(range(math.floor(low*mesh),math.ceil(high*mesh)))
        lows=[];highs=[]
        for index in product(*ranges):
            left=tuple(F(i,mesh) for i in index)
            near=[];far=[]
            for point,mass in atoms:
                near.append((2*max(max(F(0),a-x,x-a-step) for a,x in zip(left,point)),mass))
                far.append((2*max(max(abs(a-x),abs(a+step-x)) for a,x in zip(left,point)),mass))
            lower=primitive(n,tuple(sorted(far)));upper=primitive(n,tuple(sorted(near)))
            check(lower is not None and (upper is None or lower[0]<=upper[1]),'saved_energy',3)
            lows.append(lower[0]);highs.append(None if upper is None else upper[1])
        num=math.floor(budget/cellvol)
        highs.sort(key=lambda v:(v is None,F(0) if v is None else v),reverse=True)
        lows.sort(reverse=True)
        kept=highs[num:]
        check(all(v is not None for v in kept),'saved_energy',3)
        upper=cellvol*sum(kept,F(0))
        lower=cellvol*sum(lows[num:],F(0))
        if num<len(lows):lower-=(budget/cellvol-num)*cellvol*lows[num]
        def q(obj):return F(int(obj['numerator']),int(obj['denominator']))
        check(len(lows)==record['cells']==record['checks'],'saved_energy',3)
        check(q(record['actual_cap_volume'])==num*cellvol<=budget==q(record['allowed_cap_volume']),'saved_energy',3)
        # Our independent 90-term direct-ratio primitive is tighter than the
        # producer's twice rounded 40-term logarithms. Compare rigorous sides.
        check(q(record['optimal_excess_energy_lower'])<=max(F(0),lower),'saved_energy',3)
        check(upper<=q(record['selected_cap_excess_energy_upper']),'saved_energy',3)
    check(len(certificates)==len(specs)==8,'saved_energy',3)

def portable(root):
    if (root/'proof.md').exists():
        check((root/'proof.tex.txt').exists() and (root/'inventory.json').exists(),'portability',3)
        check((root/'parent_energy_probe.py').exists() and (root/'parent_energy_results.json').exists(),'portability',3)
        fences=re.findall(r'^```python\s*\n(.*?)^```\s*$',(root/'proof.md').read_text(),re.M|re.S)
        check(len(fences)==1,'portability',3)
        check(fences[0].strip()==Path(__file__).read_text().strip(),'portability',3)

def main():
    start=time.perf_counter()
    for stage,dims in enumerate([[2,3],[5,9],[17,33]]):
        coverage(stage,dims);alternative(stage,dims);adaptive(stage)
        sources(stage);energy(stage);volume(stage)
    portable(Path(__file__).resolve().parent)
    saved_energy(Path(__file__).resolve().parent)
    print(json.dumps({'status':'PASS','assertions':sum(COUNTS.values()),'route_counts':COUNTS,
                      'stage_counts':STAGES,'scope':'NEW finite exact generic algebra; no full physical gate or arbitrary-input closure',
                      'runtime_seconds':time.perf_counter()-start},sort_keys=True))

if __name__=='__main__':main()
```
