# R298 — variable row scales: a joint scale-profile bound and an explicit source-distribution receipt

## 1. Scope

Keep the complete original low-pe/high-m traffic, FIRST, selected p_y,L,R,q,e_g,m, and history/source masks. The sources beta,nu are arbitrary finite positive L1, of masses B,N. Fix measurable source data r(y) in [a,b] and 0<=omega(y,z)<=1, independently of receiver and clock, and restrict ACTUAL traffic to min(L,R)>=r(y). Assume only the row budget

    integral omega(y,z)nu(dz)<=C q_- r(y)^n.             (1)

The desired receipt const*[1+log_+(kappa C)+log(1+n log(b/a))]*(B+N) is NOT proved here. Nor is it disproved for actual original cube kernels. The result is the exact source-scale receipt (8), with its complete nu multiplicity and entropy bookkeeping. A single scalar model explains why Jensen/row-cap relaxation alone cannot supply the guessed logarithmic scale fee. It is explicitly NOT an original cube counterexample.

## 2. Shared-FIRST envelope before any scale partition

Use a valid actual pointwise height, on this suballocation,

    p_y<=kappa r(y)^(-n(1-theta)) R(x)^(-n theta),
    R(x)>=r(y), 0<theta<=1.                            (3)

R297 proves that the original gates supply theta=1/2,kappa=2K/(ell M), or theta=3/4,kappa=(2K/(ell M))gamma^(n/2), gamma=1+1/n, on BOTH orientations. The sharper R297 minimum of these two heights can also be retained. The original e_g cancels only between its actual low and high conditions, and is never replaced by a local source mass.

Put v(y)=r(y)^n, a0=a^n, b0=b^n. For each original hard source z define the explicit frozen cumulative profile

    M_z(V)=(kappa/q_-)V^(-theta)
                 integral_(v(y)<=V) v(y)^(-(1-theta))
                                      omega(y,z)beta(dy),
                         a0<=V<=b0.                    (4)

Define its one-dimensional hard-envelope functional

    J_z=integral_0^b0 sup_(max(a0,u)<=V<=b0)
                           V^(-1)min(1,M_z(V))du.       (5)

This is a computable scale profile of ORIGINAL frozen sources, not a receiver-dependent new posterior. Its universal bound is J_z<=1+log(b0/a0). Then the original covered traffic satisfies

    T_(r,omega)<=integral J_z nu(dz).                   (6)

Proof: at an actual receiver with V=R(x)^n, integrate beta FIRST while retaining the actual masks. Original FIRST bounds this beta integral divided by q by one. Height (3), the gate v(y)<=V, and q>=q_- give the simultaneous bound M_z(V). Multiply min(1,M_z(V)) by the actual hard cube kernel and enlarge to the whole hard physical menu. For u=(2|x-z|_infinity)^n, the volume of its sublevel set is u. Thus the exact radial integral of this enlarged hard envelope is (5), proving (6) by positive Tonelli.

The cumulative integral in (4) is right-continuous in V. Its normalization and minimum preserve right-continuity. The supremum in (5) can be taken over rational V in the physical interval together with b0, using approximation from above; it is therefore measurable. Finite original source masses and a0>0 ensure all displayed quantities are finite. Taking min<=1 in (5) gives exactly 1+log(b0/a0), including a=b.

Equation (6) keeps the ONE original FIRST budget. Replacing it immediately by a sum of separate scale FIRST bounds loses information. Nevertheless (6) alone is not a uniform source payment of the size in (2); Sections 3-5 quantify what it does pay.

## 3. A rigorous optimized scale-distribution receipt

Choose any h>0 in logarithmic V units. Partition [a0,b0] into J=max(1,ceil(log(b0/a0)/h)) bins with lower endpoints

    u_k=a0 exp(kh), k=0,...,J-1,

and final upper endpoint b0; use disjoint half-open bins and close the last endpoint. When a=b use the single bin u_0=a0. Let Y_k be the ORIGINAL beta source points with v(y) in the kth bin, and define the frozen quantities

    B_k=beta(Y_k),
    b_k(z)=integral_(Y_k) omega(y,z)beta(dy),
    Z_k={z:b_k(z)>0}, N_k=nu(Z_k),
    E_k=integral b_k(z)nu(dz)
       =integral_(Y_k) beta(dy)integral omega(y,z)nu(dz),
    A_k=b0/u_k.

These source supports and masses contain no receiver supremum. Zero B_k or N_k contributes zero. On Y_k, u_k<=v(y)<=e^h u_k. The exact pair mass obeys

    E_k<=C q_- integral_(Y_k) v(y)beta(dy)
       <=C e^h q_-u_k B_k.                             (7)

The original traffic with y in Y_k has actual R>=u_k^(1/n), and (3) is bounded by the same theta-height with lower physical endpoint u_k^(1/n). The original full beta FIRST bounds this source-restricted beta response, so R296's hard-envelope proof and Jensen apply without a new FIRST. It follows that

    T_(r,omega)
      <=sum_k N_k F_(A_k,theta)
                       (kappa E_k/(q_-u_k N_k)),        (8)

where

    F_(A,theta)(x)=min(1,x)+integral_1^A min(1,x t^(-theta))dt/t.

In particular, with a_h=kappa C e^h,

    T_(r,omega)
       <=sum_k N_k F_(A_k,theta)(a_h B_k/N_k).           (9)

Equation (8) is sharper and uses the EXACT frozen pair mass, not merely the row-cap upper bound. Formula (9) is a fully paid bound in terms of the original beta scale distribution and hard-source support masses. Every repeated hard-source charge is present. One may optimize the right side of (8) or (9) over h, or over any finite deterministic partition of logarithmic source scales, provided the actual bin lower endpoints and pair masses are retained. No chosen h creates disjoint hard-source mass.

The simultaneous R297 payment remains valid for the SAME traffic. If kappa0=2K/(ell M), its sharpened form is

    T_(r,omega)<=kappa0 integral beta(dy)
           [integral omega(y,z)nu(dz)/(q_-v(y))]
                                  Psi_G(b0/v(y)),      (10)

with G=gamma^(n/2) and the explicit Psi_G from R297. Thus one may take the minimum of (6), (8), (9), (10), and the independent original FIRST bound (1+log(b0/a0))N. Each is a positive upper bound for this SAME covered allocation. They are not separate credits against its complement.

## 4. Exact multiplicity and the scale entropy term

Let the sum below run only over active bins, and put

    B_* =sum_k B_k<=B,
    N_sum=sum_k N_k=integral m(z)nu(dz),
    m(z)=sum_k 1_(Z_k)(z).

Thus N_sum, rather than N, is the precise hard-source mass paid by the separate-scale receipt. It can be as large as JN. Countable source overlaps are not made disjoint by naming their scales.

The uniform-A majorant is

    F_(infinity,theta)(x)=(1+1/theta)x,               x<=1;
    F_(infinity,theta)(x)=1+(1+log x)/theta,          x>=1.

Let p_k=B_k/B_*, w_k=N_k/N_sum, and x=a_h B_*/N_sum, with zero total mass handled by zero contribution. Then (9) gives the explicit distribution-sensitive bound

    T_(r,omega)<=N_sum sum_k w_k
                          F_(infinity,theta)(x p_k/w_k). (11)

This keeps the complete source-scale mass profile. Concavity yields the simpler but potentially weaker bound

    T_(r,omega)<=N_sum F_(infinity,theta)(a_h B_*/N_sum)
       <=c_theta(a_h)(B_*+N_sum),                      (12)

where the sharp R296 coefficient is

    c_theta(a)=(1+1/theta)a/(1+a),                 a<=theta;
    c_theta(a)=W(a exp(theta))/theta,             a>=theta,
    c_theta(a)<=1+(1/theta)log_+(a/theta).

Consequently a bound on m(z), or on its nu-weighted total, is a REAL sufficient extra source premise for (12). It must be proved, not inferred from the row cap.

There is an exact entropy improvement of the scalar receipt (11) when every argument x p_k/w_k>=1. In that regime its right side equals

    N_sum[1+1/theta+log(x)/theta
                         -D_KL(w||p)/theta],            (13)
    D_KL(w||p)=sum_k w_k log(w_k/p_k)>=0.

This is simply the logarithmic branch summed with its actual weights. It records the Jensen deficit rather than suppressing the distribution. Outside that regime use the piecewise expression (11); applying (13) below its branch threshold would be wrong. The KL identity is an analytic bookkeeping refinement, not a new operator estimate beyond (8).

For example, if active hard-source supports are disjoint, N_sum<=N and (12) costs only a logarithm of kappa C e^h with both ORIGINAL source masses. More generally if N_sum<=D N, then (12) costs c_theta(a_h)(B+D N). To obtain a logarithm in D instead of this explicit multiplicity from these formulas needs further information; it is not supplied by relabeling scales. If all active supports equal the full nu support, then N_sum=JN and that cost stays in (11)-(12), even when beta masses are equal or the source radius distribution is regular.

## 5. One scalar screen, explicitly NOT an original cube counterexample

Here is the precise limitation of using only the cumulative height (4) and the shared FIRST truncation in (5). Normalize a0=q_-=1, b0=exp(T), with n large enough that T<=n log 2. On the logarithmic row-scale variable s in [0,T], set

    beta(ds)=(N/T)ds, B=N, v(s)=exp(s),
    omega(s,z)=exp(s-T), N=C exp(T), kappa C=T.

The hard source space is any finite nonatomic space of mass N. Then omega<=1 and integral omega(s,z)nu(dz)=C v(s), so (1) is exact. The cumulative profile is identical for all z:

    M(t)=(1-exp(-theta t))/theta, t=log V in [0,T].       (14)

For t>=1/theta, min(1,M(t))>=1-exp(-1). Evaluating the hard envelope at its own radial scale gives

    J_z>=(1-exp(-1))(T-1/theta).                         (15)

Thus this relaxed functional can be order TN, while B=N, kappa C=T, and the guessed coefficient is order log T. For reproducibility its exact envelope is J=M(T) when T<=t_*=log(1+theta)/theta; otherwise

    J=1/(1+theta)+integral_(t_*)^T min(1,M(t))dt.         (16)

The coefficient exp(-t)min(1,M(t)) increases to t_* and decreases thereafter, proving this formula. Split the integral at -log(1-theta)/theta if theta<1.

This screens ONLY the relaxed source-scale/height/FIRST deduction. It does NOT realize the actual phi soft kernels, spatial hard-source geometry or original accepted hard caps. Therefore it is not an original-traffic counterexample and does not refute the desired stronger inequality. A proof of that inequality must use extra actual spatial/profile information to prevent persistent overlapping saturated columns.

For integration, the usable receipts are (8), its explicit multiplicity version (12), and the independent R297 own-scale receipt (10). Original witness hard caps may supply C=16/3, but do not by themselves bound m(z): one hard source may lie in witness cubes attached to many beta-scale rows. All old e_g,m and masks stay unchanged. Applying full W_nu once per bin and then claiming only log J total would omit a real fee. No claim about the independent spatial/receiver routes is made here.

## 6. Actual bounded diagnostics and single-file reproduction

A local Python/mpmath run at 45 digits passed 18 scale-column exact-envelope comparisons for theta=1/2,3/4,1 and T=0.1,1,2,8,64,1024. It passed 100 weighted-perspective/KL identities and Jensen checks. At theta=3/4,T=1024, the relaxed J was 1023.6212583152791999, and J/[1+log T+log(1+T)] was 68.8661725285044. These are scalar diagnostics, not original-traffic counterexamples.

The code actually run is included here for reproduction; it writes no files.

```python
import sys, random
try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0, '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
    import mpmath as mp
mp.mp.dps=45
count=0
for theta in map(mp.mpf, ['.5', '.75', '1']):
    for T in map(mp.mpf, ['.1', '1', '2', '8', '64', '1024']):
        star=mp.log1p(theta)/theta
        M=lambda t: (1-mp.exp(-theta*t))/theta
        if T<=star:
            exact=M(T)
        else:
            cap=-mp.log1p(-theta)/theta if theta<1 else mp.inf
            end=min(T,cap)
            primitive=lambda t: t/theta+mp.exp(-theta*t)/theta**2
            exact=1/(1+theta)+primitive(end)-primitive(star)+max(0,T-cap)
        pts=sorted(set([mp.mpf(0),min(T,star),T]+
                       ([min(T,-mp.log1p(-theta)/theta)] if theta<1 else [])))
        numeric=M(min(T,star))
        if T>star:
            numeric+=sum(mp.quad(lambda t: min(1,M(t)),[p,q])
                         for p,q in zip(pts,pts[1:]) if p>=star)
        assert abs(exact-numeric)<mp.mpf('1e-35')
        if T>=2/theta:
            assert exact>=(1-mp.exp(-1))*(T-1/theta)
        count+=1
        if theta==mp.mpf('.75') and T==1024:
            print('column relaxation T=1024: J=',mp.nstr(exact,20),
                  'ratio=',mp.nstr(exact/(1+mp.log(T)+mp.log1p(T)),15))
def Finf(theta,u):
    return (1+1/theta)*u if u<=1 else 1+(1+mp.log(u))/theta
rng=random.Random(298)
entropy=0
for k in range(100):
    J=1+k%8
    p=[mp.mpf(rng.randint(1,20)) for _ in range(J)]
    p=[x/sum(p) for x in p]
    w=[mp.mpf(rng.randint(1,20)) for _ in range(J)]
    w=[x/sum(w) for x in w]
    theta=mp.mpf('.75')
    x=1+max(wi/pi for pi,wi in zip(p,w))
    val=sum(wi*Finf(theta,x*pi/wi) for pi,wi in zip(p,w))
    KL=sum(wi*mp.log(wi/pi) for pi,wi in zip(p,w))
    formula=1+1/theta+mp.log(x)/theta-KL/theta
    assert abs(val-formula)<mp.mpf('1e-35')
    assert val<=Finf(theta,x)+mp.mpf('1e-35')
    entropy+=1
print('PASS scale-column exact integral comparisons=',count)
print('PASS source-scale perspective / KL identities=',entropy)
```

Only /tmp/r298_variable_scale.md was written; other authors and Git state were preserved. The task stops with the proved source-distribution receipt and the precise missing geometric premise above.
