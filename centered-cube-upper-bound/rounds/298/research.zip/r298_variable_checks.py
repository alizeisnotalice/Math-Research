import sys, random
try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0, '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
    import mpmath as mp
mp.mp.dps=45
count=0
for theta in map(mp.mpf, ['.5', '.75', '1']):
    for T in map(mp.mpf, ['.1', '1', '2', '8', '64', '1024']):
        star=mp.log1p(theta)/theta
        M=lambda t: (1-mp.exp(-theta*t))/theta
        if T<=star:
            exact=M(T)
        else:
            cap=-mp.log1p(-theta)/theta if theta<1 else mp.inf
            end=min(T,cap)
            primitive=lambda t: t/theta+mp.exp(-theta*t)/theta**2
            exact=1/(1+theta)+primitive(end)-primitive(star)+max(0,T-cap)
        pts=sorted(set([mp.mpf(0),min(T,star),T]+
                       ([min(T,-mp.log1p(-theta)/theta)] if theta<1 else [])))
        numeric=M(min(T,star))
        if T>star:
            numeric+=sum(mp.quad(lambda t: min(1,M(t)),[p,q])
                         for p,q in zip(pts,pts[1:]) if p>=star)
        assert abs(exact-numeric)<mp.mpf('1e-35')
        if T>=2/theta:
            assert exact>=(1-mp.exp(-1))*(T-1/theta)
        count+=1
        if theta==mp.mpf('.75') and T==1024:
            print('column relaxation T=1024: J=',mp.nstr(exact,20),
                  'ratio=',mp.nstr(exact/(1+mp.log(T)+mp.log1p(T)),15))
def Finf(theta,u):
    return (1+1/theta)*u if u<=1 else 1+(1+mp.log(u))/theta
rng=random.Random(298)
entropy=0
for k in range(100):
    J=1+k%8
    p=[mp.mpf(rng.randint(1,20)) for _ in range(J)]
    p=[x/sum(p) for x in p]
    w=[mp.mpf(rng.randint(1,20)) for _ in range(J)]
    w=[x/sum(w) for x in w]
    theta=mp.mpf('.75')
    x=1+max(wi/pi for pi,wi in zip(p,w))
    val=sum(wi*Finf(theta,x*pi/wi) for pi,wi in zip(p,w))
    KL=sum(wi*mp.log(wi/pi) for pi,wi in zip(p,w))
    formula=1+1/theta+mp.log(x)/theta-KL/theta
    assert abs(val-formula)<mp.mpf('1e-35')
    assert val<=Finf(theta,x)+mp.mpf('1e-35')
    entropy+=1
print('PASS scale-column exact integral comparisons=',count)
print('PASS source-scale perspective / KL identities=',entropy)
