% R298 finite genuine axis-parallel cube cover LPs. Does not change MATLAB path.
r298Cases = r298MakeCases();
r298Results = repmat(struct(), numel(r298Cases), 1);
r298Options = optimoptions('linprog', 'Display', 'none');
for r298Index = 1:numel(r298Cases)
    r298CaseData = r298Cases(r298Index);
    r298Targets = r298CaseData.target_num;
    r298Centers = r298CaseData.center_num;
    r298Sides = r298CaseData.side_num(:);
    r298A = false(size(r298Targets,1),size(r298Centers,1));
    for r298Witness = 1:size(r298Centers,1)
        % Exact small-integer test in common rational coordinate units.
        r298A(:,r298Witness) = all(2*(abs(r298Targets-r298Centers(r298Witness,:))+r298CaseData.target_half_num) <= r298Sides(r298Witness),2);
    end
    assert(all(any(r298A,2)), 'Uncovered target in R298 input.');
    r298Cost = (r298Sides / r298CaseData.coord_den).^r298CaseData.n;
    [r298Primal,r298Tau,r298Flag,r298Output] = linprog(r298Cost,-double(r298A),-ones(size(r298A,1),1),[],[],zeros(size(r298A,2),1),[],r298Options);
    [r298Dual,r298NegativeDual,r298DualFlag,r298DualOutput] = linprog(-ones(size(r298A,1),1),double(r298A)',r298Cost,[],[],zeros(size(r298A,1),1),[],r298Options);
    assert(r298Flag>0 && r298DualFlag>0, 'R298 linprog did not return a finite optimum.');
    r298Result = r298CaseData;
    r298Result.incidence_target_by_witness = double(r298A);
    r298Result.cost_double = r298Cost;
    r298Result.primal_lambda = r298Primal;
    r298Result.primal_value = r298Tau;
    r298Result.dual_d = r298Dual;
    r298Result.dual_value = -r298NegativeDual;
    r298Result.primal_exitflag = r298Flag;
    r298Result.dual_exitflag = r298DualFlag;
    r298Result.primal_iterations = r298Output.iterations;
    r298Result.dual_iterations = r298DualOutput.iterations;
    if r298Index == 1
        r298Results = r298Result;
    else
        r298Results(r298Index) = r298Result;
    end
    fprintf('R298 %s n=%d targets=%d witnesses=%d primal=%.12g dual=%.12g\n',r298CaseData.name,r298CaseData.n,size(r298A,1),size(r298A,2),r298Tau,-r298NegativeDual);
end
r298Meta = struct('status','SOLVER_RESULTS_REQUIRE_EXACT_CERTIFICATION','matlab_version',version,'geometry_convention','Closed axis-parallel cubes; incidence iff entire target cell is contained: 2*(abs(target-center)+target_halfwidth)<=side in integer units. Point cells have halfwidth0. a=1; sides in [1,2].','scope','Finite explicit menu LPs only; no general dimension-order or FULL traffic certificate.','cases',r298Results);
r298File = fopen('/tmp/r298_cover_lp.json','w');
assert(r298File>=0,'Cannot write R298 solver output.');
fwrite(r298File,jsonencode(r298Meta,PrettyPrint=true),'char');
fprintf(r298File,'\n');
fclose(r298File);

function cases = r298MakeCases()
    cases = repmat(r298Case('unused','unused',1,0,0,4),0,1);
    cases(end+1) = r298Case('initial','disjoint_intervals',1,[0;12;24],[0;12;24],[4;4;4]);
    [z,x,s] = r298Triangles(2,1,0);
    cases(end+1) = r298Case('initial','fractional_triangle',2,z,x,s);
    cases(end+1) = r298Case('initial','interval_chain_nonconstant',1,[-4;0;4;8],[-2;2;6;2],[4;4;4;6]);
    [z,x,s] = r298Triangles(2,1,6);
    cases(end+1) = r298Case('overlap_boundary','triangle_redundant_nonconstant',2,z,x,s);
    [z,x,s] = r298Triangles(4,2,4);
    cases(end+1) = r298Case('overlap_boundary','two_embedded_triangles',4,z,x,s);
    z=[-2,-2;-2,2;2,-2;2,2];x=[0,0;z];s=[5;4;4;4;4];
    cases(end+1) = r298Case('overlap_boundary','square_full_cover_nonconstant',2,z,x,s);
    [z,x,s] = r298Triangles(8,3,20);
    cases(end+1) = r298Case('expanded','three_triangles_dimension8',8,z,x,s);
    [z,x,s] = r298Triangles(16,4,30);
    cases(end+1) = r298Case('expanded','four_triangles_dimension16',16,z,x,s);
    n=8;z=zeros(1+2*n,n);x=zeros(2*n+1,n);s=[4*ones(2*n,1);8];
    for k=1:n
        z(2*k,k)=4;z(2*k+1,k)=-4;x(2*k-1,k)=2;x(2*k,k)=-2;
    end
    cases(end+1) = r298Case('expanded','axis_star_dimension8',n,z,x,s);
    c=r298Case('initial','positive_cells_disjoint_intervals',1,[0;12;24],[0;12;24],[4;4;4]);
    cases(end+1)=r298Cells(c);
    c=r298Case('overlap_boundary','positive_cells_partial_intersection_rejected',1,[0;4;12],[0;4;12;2],[4;4;4;4]);
    cases(end+1)=r298Cells(c);
    [z,x,s]=r298Triangles(2,1,3);s(s==4)=5;s(4)=8;
    c=r298Case('overlap_boundary','positive_cells_fractional_triangle',2,z,x,s);
    cases(end+1)=r298Cells(c);
    z=[-2,-2;-2,2;2,-2;2,2];x=[0,0;z];s=[5;4;4;4;4];
    cases(end+1)=r298Cells(r298Case('overlap_boundary','positive_cells_square_nonconstant',2,z,x,s));
    [z,x,s]=r298Triangles(8,2,8);s(s==4)=5;s(4:4:8)=8;
    cases(end+1)=r298Cells(r298Case('expanded','positive_cells_dimension8',8,z,x,s));
    [z,x,s]=r298Triangles(16,1,4);s(s==4)=5;s(4)=8;
    cases(end+1)=r298Cells(r298Case('expanded','positive_cells_dimension16',16,z,x,s));
end
function c = r298Case(stage,name,n,z,x,s)
    c=struct('stage',stage,'name',name,'n',n,'coord_den',4,'a_num',4,'target_num',z,'center_num',x,'side_num',s(:),'target_half_num',zeros(size(z)),'target_kind','point');
end
function [z,x,s] = r298Triangles(n,groups,duplicates)
    z=zeros(3*groups,n);x=zeros(4*groups+duplicates,n);s=4*ones(4*groups+duplicates,1);
    for group=1:groups
        offset=[20*(group-1),0];
        z(3*group-2:3*group,1:2)=[0,0;4,0;2,4]+offset;
        x(4*group-3:4*group-1,1:2)=[2,0;1,2;3,2]+offset;
        x(4*group,1:2)=[2,2]+offset;s(4*group)=5;
    end
    for k=1:duplicates
        group=1+mod(k-1,groups);x(4*groups+k,1:2)=[2,0]+[20*(group-1),0];
    end
end

function c = r298Cells(c)
    c.target_num=2*c.target_num;c.center_num=2*c.center_num;c.side_num=2*c.side_num;
    c.coord_den=8;c.a_num=8;c.target_half_num=ones(size(c.target_num));c.target_kind='positive_volume_cells';
end
