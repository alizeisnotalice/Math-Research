from fractions import Fraction as F
from itertools import product
import json
cases=[(1,[(F(0),),(F(1,2),),(F(2),)],[F(1),F(1),F(2)],[F(1,2),F(1,3),F(1,6)]),
 (2,[(F(0),F(0)),(F(1,2),F(0)),(F(1),F(1))],[F(1),F(3,2),F(2)],[F(1,4),F(1,4),F(1,2)]),
 (3,[(F(0),)*3,(F(1,2),F(0),F(0)),(F(3),)*3,(F(-1),)*3],[F(2),F(1),F(3,2),F(1)],[F(1,10),F(2,10),F(3,10),F(4,10)])]
counts={'configuration_checks':0,'probability_checks':0,'rank_checks':0,'source_ledger_checks':0,'threshold_checks':0}
for n,centers,radii,probs in cases:
    zs=list(dict.fromkeys(centers+[tuple(c[k]+r/F(2) for k in range(n)) for c,r in zip(centers,radii)]))
    masses=[F(1,len(zs))]*len(zs)
    inside=lambda z,i: all(abs(z[k]-centers[i][k])<=radii[i]/2 for k in range(n))
    for N in range(1,5):
        obs={(z,t):F(0) for z in zs for t in [F(1),F(5,4),F(3,2),F(2)]}
        for inds in product(range(len(probs)),repeat=N):
            weight=F(1)
            for i in inds: weight*=probs[i]
            ledger=F(0)
            for z,mass in zip(zs,masses):
                choices=[k for k,i in enumerate(inds) if inside(z,i)]
                best=min(choices,key=lambda k:(radii[inds[k]],k)) if choices else None
                if best is not None: ledger+=mass/(F(3,4)*radii[inds[best]]**n)
                for t in [F(1),F(5,4),F(3,2),F(2)]:
                    direct=any(inside(z,i) and radii[i]<=t for i in inds)
                    assigned=best is not None and radii[inds[best]]<=t
                    assert direct==assigned
                    obs[z,t]+=weight*int(assigned)
                    counts['configuration_checks']+=1
            assert ledger<=F(16,3)*N
            counts['source_ledger_checks']+=1
        for (z,t),value in obs.items():
            C=sum((p for i,p in enumerate(probs) if inside(z,i) and radii[i]<=t),F(0))
            assert value==1-(1-C)**N
            counts['probability_checks']+=1
            for eta in [F(1,8),F(1,4),F(1,2),F(3,4),F(1)]:
                if C>=eta:
                    assert value>=1-(1-eta)**N
                    assert (1-(1-eta)**N)>0
                    counts['threshold_checks']+=1
        for z in zs:
            vals={r:sum((probs[i] for i in range(len(probs)) if radii[i]==r and inside(z,i)),F(0)) for r in set(radii)}
            m=sum(vals.values(),F(0)); cumulative=F(0); lhs=F(0)
            for r,v in sorted(vals.items()):
                cumulative+=v; lhs+=v*(1-cumulative)**N
            assert lhs<=(1-(1-m)**(N+1))/F(N+1)
            counts['rank_checks']+=1
result=json.dumps({'status':'PASS','stages':['equal-radius ties','unequal radii and cube faces','disconnected 3D wider menu'],'counts':counts},sort_keys=True)
print(result)
from pathlib import Path
Path('/tmp/r298_ordered_checks.json').write_text(result+'\n')
