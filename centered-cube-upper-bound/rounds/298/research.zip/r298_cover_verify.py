#!/usr/bin/env python3
"""Reconstruct and certify finite MATLAB cube-cover LPs using exact Fractions."""
import json,hashlib
from fractions import Fraction as F
from pathlib import Path
BASE=Path(__file__).parent

def vector(x):return x if isinstance(x,list) else [x]
def matrix(x,n):
 if n==1:return [[v] if not isinstance(v,list) else v for v in vector(x)]
 return [x] if x and not isinstance(x[0],list) else x

def qguess(x):
 if abs(x)<1e-8:return F(0)
 return F(str(x)).limit_denominator(10**7)

def affine_solve(A,b,guess):
 # Exact RREF; use reconstructed solver values only for free coordinates.
 if not guess:
  assert all(not x for x in b);return []
 width=len(guess);rows=[[F(v) for v in a]+[F(y)] for a,y in zip(A,b)];pivots=[];r=0
 for col in range(width):
  pivot=next((i for i in range(r,len(rows)) if rows[i][col]),None)
  if pivot is None:continue
  rows[r],rows[pivot]=rows[pivot],rows[r];scale=rows[r][col];rows[r]=[v/scale for v in rows[r]]
  for i in range(len(rows)):
   if i!=r and rows[i][col]:
    factor=rows[i][col];rows[i]=[x-factor*y for x,y in zip(rows[i],rows[r])]
  pivots.append(col);r+=1
  if r==len(rows):break
 for row in rows:
  if not any(row[:width]):assert not row[-1],'Inconsistent exact support equations.'
 sol=list(guess)
 for i,col in reversed(list(enumerate(pivots))):sol[col]=rows[i][-1]-sum(rows[i][j]*sol[j] for j in range(width) if j!=col)
 return sol

def certify(case):
 n=case['n'];den=case['coord_den'];a=F(case['a_num'],den)
 targets=matrix(case['target_num'],n);half=matrix(case['target_half_num'],n);centers=matrix(case['center_num'],n);sides=list(map(int,vector(case['side_num'])))
 assert all(a<=F(s,den)<=2*a for s in sides)
 A=[[int(all(2*(abs(int(z[k])-int(x[k]))+int(h[k]))<=s for k in range(n))) for x,s in zip(centers,sides)] for z,h in zip(targets,half)]
 assert all(any(row) for row in A)
 # Never trust the solver's floating incidence/cost as an exact certificate.
 recorded=matrix(case['incidence_target_by_witness'],len(centers));assert A==recorded
 costs=[(F(s,den)/a)**n for s in sides];nv=len(centers);nt=len(targets)
 lpraw=vector(case['primal_lambda']);dualraw=vector(case['dual_d'])
 I=[i for i,x in enumerate(lpraw) if x>1e-8];J=[j for j,x in enumerate(dualraw) if x>1e-8]
 assert I and J
 psub=affine_solve([[A[j][i] for i in I] for j in J],[F(1)]*len(J),[qguess(lpraw[i]) for i in I])
 dsub=affine_solve([[A[j][i] for j in J] for i in I],[costs[i] for i in I],[qguess(dualraw[j]) for j in J])
 p=[F(0)]*nv;d=[F(0)]*nt
 for i,x in zip(I,psub):p[i]=x
 for j,x in zip(J,dsub):d[j]=x
 assert all(x>=0 for x in p+d)
 cover=[sum(A[j][i]*p[i] for i in range(nv)) for j in range(nt)]
 price=[sum(A[j][i]*d[j] for j in range(nt)) for i in range(nv)]
 assert all(x>=1 for x in cover),'Exact primal infeasible.'
 assert all(x<=c for x,c in zip(price,costs)),'Exact dual infeasible.'
 tau=sum(c*x for c,x in zip(costs,p));dual=sum(d);assert tau==dual and tau>0,'Nonzero exact duality gap.'
 uniform=[sum(F(A[j][i],nv)/costs[i] for i in range(nv)) for j in range(nt)];natural=min(uniform)
 optimal_pi=[costs[i]*p[i]/tau for i in range(nv)];assert sum(optimal_pi)==1
 opt_capture=[sum(optimal_pi[i]*A[j][i]/costs[i] for i in range(nv)) for j in range(nt)]
 assert min(opt_capture)==1/tau and natural<=1/tau
 dual_probability=[x/tau for x in d];assert sum(dual_probability)==1
 assert all(sum(dual_probability[j]*A[j][i]/costs[i] for j in range(nt))<=1/tau for i in range(nv))
 tight_faces=sum(2*(abs(int(z[k])-int(x[k]))+int(h[k]))==s for z,h in zip(targets,half) for x,s in zip(centers,sides) for k in range(n))
 partial=sum(all(2*abs(int(z[k])-int(x[k]))<s+2*int(h[k]) for k in range(n)) and not A[j][i] for j,(z,h) in enumerate(zip(targets,half)) for i,(x,s) in enumerate(zip(centers,sides)))
 volumes=[]
 if case['target_kind']=='positive_volume_cells':
  for h in half:
   vol=F(1)
   for v in h:assert v>0;vol*=F(2*int(v),den)
   assert vol>0;volumes.append(str(vol))
 else:assert all(not v for h in half for v in h)
 if volumes:
  assert all(any(abs(int(targets[j][k])-int(targets[l][k]))>=int(half[j][k])+int(half[l][k]) for k in range(n)) for j in range(nt) for l in range(j))
 return {'name':case['name'],'stage':case['stage'],'target_kind':case['target_kind'],'positive_target_volumes':volumes,'positive_volume_partial_intersections_rejected':partial,'dimension':n,'targets':nt,'witnesses':nv,'exact_tau':str(tau),'exact_dual_objective':str(dual),'exact_gap':'0','primal_nonzero':sum(bool(x) for x in p),'dual_nonzero':sum(bool(x) for x in d),'primal_certificate':[str(x) for x in p],'dual_certificate':[str(x) for x in d],'exact_costs':[str(x) for x in costs],'natural_uniform_min_Pi':str(natural),'optimal_min_Pi':str(1/tau),'optimal_over_natural':str((1/tau)/natural),'optimal_witness_probability':[str(x) for x in optimal_pi],'dual_target_probability':[str(x) for x in dual_probability],'exact_maxmin_identity':'max_pi min_j sum_i pi_i A_ji/c_i = 1/tau','exact_primal_min_coverage':str(min(cover)),'exact_dual_min_slack':str(min(c-v for c,v in zip(costs,price))),'boundary_coordinate_equalities':tight_faces,'solver_primal_exitflag':case['primal_exitflag'],'solver_dual_exitflag':case['dual_exitflag']}

def main():
 path=BASE/'r298_cover_lp.json';raw=path.read_bytes();data=json.loads(raw);rows=[certify(case) for case in data['cases']]
 out={'status':'PASS_EXACT_PRIMAL_DUAL_CERTIFICATES','scope':'Finite explicit genuine axis-parallel closed-cube witness menus. Positive target cells require full containment, giving covers for any L1 source supported on those cells; point diagnostics are labelled separately. MATLAB linprog proposes support; exact Fraction geometry, costs, nonnegativity, primal/dual feasibility and zero gap certify each finite optimum. Natural uniform witness selection is compared with the exact optimal cost-weighted probability, not a full original traffic/source theorem or a general n-order claim. Optimality refers to this full-containment cell-incidence LP, not arbitrary subdivisions or partial-cell covers. Original FIRST and low/high gates are not supplied by this finite geometry.','matlab_version':data['matlab_version'],'solver_output_sha256':hashlib.sha256(raw).hexdigest(),'cases':rows,'counts':{'cases':len(rows),'positive_cell_cases':sum(r['target_kind']=='positive_volume_cells' for r in rows),'point_cases':sum(r['target_kind']=='point' for r in rows),'dimensions':sorted(set(r['dimension'] for r in rows)),'stages':{s:sum(r['stage']==s for r in rows) for s in ['initial','overlap_boundary','expanded']},'all_exact_gaps_zero':True}}
 target=BASE/'r298_cover_verify.json';target.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'status':out['status'],'counts':out['counts'],'summary':[{k:r[k] for k in ['name','dimension','targets','witnesses','exact_tau','natural_uniform_min_Pi','optimal_min_Pi','optimal_over_natural']} for r in rows]},indent=2))
if __name__=='__main__':main()
