# R298 — local receiver normalization and certified fractional witness covers

## 1. Keep the original positive traffic

Fix the original sources beta,nu, receiver selectors, and outer data as in R297. Write q_-=3lambda/4, Q=q_-a^n, gamma=1+1/n, ell=1+log n, and kappa_*=2K gamma^(n/2)/(ell M). All original low,m>M, accepted, source and history qualifications remain on the target traffic. A row weight U_y(x) is supported on accepted receivers, dominates its intended original pair kernel after multiplication by h_R, and has finite Z_y=integral U_y dx. It is not a substituted posterior or a new source.

## 2. Localization improves the normalized capture without losing near traffic

For the already paid R296 spatial cutoff D>1, let N_D(y,z)=1{|y-z|_infinity<=Db}. Define

    U_y^D(x)=U_y(x)1{|x-y|_infinity<=(D+1/2)b},
    Z_y^D=integral U_y^D(x)dx,
    J_D(y,z)=integral U_y^D(x)h_(R(x))(x-z)dx.

On EVERY near pair N_D=1,

    J_D(y,z)=J(y,z),                                  (L1)

because a positive hard edge satisfies |x-z|_infinity<=R(x)/2<=b/2. The triangle inequality then forces the retained closed receiver cutoff. Thus this restriction removes no witness capture capable of reaching that near pair. It is stronger than merely dropping positive terms from a numerator.

Since Z_y^D<=Z_y, on nonzero near rows

    P_D(y,z)=a^nJ_D(y,z)/Z_y^D >= a^nJ(y,z)/Z_y=P(y,z). (L2)

If Z_y^D=0, the actual near row traffic is zero by positivity. Define P_D=0 there. Every expression is measurable; there is no selection of a new center separately for each pair.

Apply the R297 finite-Poisson construction to U^D, retaining its own normalization. The same volume budget e^H, row bound (16/3)Qe^H and threshold rho_H=4 log(4)e^-H hold. The near traffic on P_D>=rho_H has price

    2[1+(4/3)log_+((64/9)kappa_*e^H)](W_beta+W_nu).    (L3)

The original far traffic is separately paid by epsilon W_beta with the R296 choice of D. No additional spatial-grid fee or factor Z/Z_D is paid in (L3). The old near strong-capture branch is contained in the new one by (L2); near traffic with P_D<rho_H remains. An arbitrary reduction of Z without the exact numerator identity (L1) would not justify this comparison.

## 3. A finite witness-menu geometry with meaningful positive-volume targets

Consider a fixed finite family of ACTUAL capped receiver cubes B_i=Q_(r_i)(x_i), a<=r_i<=b, and measurable target cells D_j, j=1,...,m. The cells may have positive volume. Define

    A_(j,i)=1 if D_j subset B_i, and 0 otherwise,
    c_i=(r_i/a)^n>0.

A partially intersecting cube is not declared to cover a whole cell. Assume each cell is contained in at least one witness, so the following problem is feasible:

    tau=min {sum_i c_i lambda_i : lambda_i>=0,
                                  sum_i A_(j,i)lambda_i>=1 for every j}. (L4)

For ANY feasible coefficients, define the clipped fractional union

    omega(z)=min(1,sum_i lambda_i 1_(B_i)(z)).          (L5)

It equals one on the entire target union, including overlapping cells. Real hard caps at the SAME witness radii give

    integral omega(z)nu(dz)
      <=sum_i lambda_i nu(B_i)
      <=4lambda a^n sum_i c_i lambda_i.                (L6)

Thus a verified feasible menu supplies actual full coverage of those cells and a source capacity, not only an expected capture statement. For measurable row-dependent data and coefficients with cost <=T uniformly, the R296 fixed-field row theorem pays the original traffic whose hard source lies in those row target cells by

    [1+(4/3)log_+((64/9)kappa_*T)](W_beta+W_nu).        (L7)

The coefficient 64/9 is (4/3)*(16/3). If T=0 the covered target traffic is empty and is handled separately. The original source pair and scale qualifications are retained; (L7) grants no coverage beyond the specified cells. Source use across all beta rows is charged by the aggregate mixed-source theorem, not by a fresh W_nu for each row.

Measurability of the row witness maps, cells and chosen coefficients is a premise of this row application. A pointwise numerical optimizer is not silently converted into a globally measurable optimizer. Constant certified menus on a measurable beta partition give a direct admissible instance. Finite point targets used for numerical boundary checks are distinguished from positive-volume cells; a point calculation alone does not certify an arbitrary L1 source region.

## 4. Exact relation between receiver mixing and fractional cover cost

For the fixed finite menu define the best normalized common capture

    g=max_(pi_i>=0,sum pi_i=1) min_j sum_i pi_i A_(j,i)/c_i. (L8)

Then

    tau=1/g.                                          (L9)

This identity needs no invocation of an unverified infinite-dimensional minimax theorem. The simplex is compact and its objective is continuous. Since every target is covered, uniform positive pi gives g>0. For any feasible lambda of cost t, set pi_i=c_i lambda_i/t; then every target capture is at least1/t, so g>=1/t. Conversely a maximizing pi yields lambda_i=pi_i/(c_i g), which is feasible and has cost1/g. These two explicit maps prove (L9) and attainment of the finite minimum.

Consequently a poor receiver mixture can produce small capture even when a better common mixture has a certified, inexpensive cover. The optimization changes one COMMON mixture for the entire target family; it does not choose a separate favorable mixture for each target. This is a constructive option for part of the weak-capture geometry. It is not a proof that tau is always exp(root-polylog) for all original source targets.

A dual packing vector d_j>=0 with sum_j A_(j,i)d_j<=c_i supplies the rigorous lower certificate

    sum_j d_j <= tau.                                (L10)

For an explicit primal lambda and dual d, both feasible, equality of their objectives proves optimality by multiplication and summation of the inequalities. No solver status is accepted in place of these inequalities. General LP strong duality is not needed to validate any returned zero-gap certificate.

## 5. Evidence policy and remaining geometry

Local MATLAB linprog is used only to propose finite-menu coefficients. The reproducible verifier reconstructs rational coefficients and checks the primal inequalities, dual inequalities, nonnegativity and objective equality with Fraction arithmetic. Each successfully certified case is a finite geometric optimization result. The targets, witness radii, incidence convention and costs are retained in its data.

These finite menus are actual axis-parallel cube geometries; they are not automatically full original maximal-operator histories. Their receiver hard caps, original low/high qualification, and coverage of all hard-source support must still be supplied when applying (L7). The experiments do not establish a general dimension exponent.

The new conclusions are the unconditional near numerator preservation (L1) and monotone capture improvement (L2), plus an exact finite constructive bridge from optimized common receiver mixing to certified full-cell fractional coverage (L4)-(L10). The remaining global task is a controlled cover of all original weak-capture traffic, or a separate actual payment of its uncovered part. The ongoing ordered-scale sampling route addresses a different normalization loss and is not assumed to solve this one. All original outer factors remain in the original source ledger.
