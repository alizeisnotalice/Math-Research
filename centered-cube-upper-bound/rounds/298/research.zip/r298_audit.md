# R298 independent preauthor screen

Scope: only the original fixed-field low-pe, m>M traffic, arbitrary original softness/orientation and all original masks. Original e_g and m are unchanged. Write q_-=3lambda/4, kappa0=2K/(ell M), kappa*=gamma^(n/2)kappa0, Q=q_-a^n, D_gamma=3-2/(3gamma^n). All raw receipts require the original outer Lambda once; any further outer/clock ledger is separate. This file is owned solely by the independent auditor.

## 1. Variable own-scale rows and logarithmic fees

R297 gives, for frozen measurable r(y) in [a,b], frozen omega(y,z), and the ACTUAL additional gate min(L,R)>=r(y), the linear source receipt kappa0 D_gamma integral [nu(omega_y)/(q_-r(y)^n)] beta(dy). The row capacity is measured at its own scale, with no r/a loss. For a common fixed r, R296 may instead be rerun at lower endpoint r and yields the logarithmic joint-source fee with row bound nu(omega_y)<=C q_-r^n. Original FIRST is available for original beta restrictions at each actual receiver; it is not automatically available for source-renormalized weights.

For a continuously varying r(y), the fixed-r Jensen proof cannot simply sum its W_nu fee once per source/scale block and call the total logarithmic in n. A scale grouping needs its aggregate source ledger. Thus a log(C) and only log(n)-scale theorem is not a free consequence of these two earlier receipts; a new aggregation argument is required. This is a limitation of that proposed inference, not a claim that such a theorem is impossible.

## 2. Exact local row normalization

Fix the entire original receiver field. Let U_y(x) be the original accepted row weight, Z_y=integral U_y dx, J(y,z)=integral U_y(x)h_R(x-z)dx, with the actual target pair kernel bounded by J. For near pairs |y-z|_infinity<=Db, set U_y^D=U_y 1{|x-y|_infinity<=(D+1/2)b}, Z_D=integral U_D. Since R<=b and hard capture implies |x-z|_infinity<=R/2, every nonzero capture for a near pair lies in the retained receiver region. Therefore J_D(y,z)=J(y,z) EXACTLY on near pairs, while Z_D<=Z. If Z_D>0, P_D=a^n J_D/Z_D>=a^n J/Z=P. If Z_D=0 the near target kernel vanishes. Closed boundary conventions are retained.

The R297 normalized Poisson cover can consequently be rebuilt with U_D, retaining its same row capacity and source fee; its paid P-high near branch may enlarge. No claim that all weak-capture traffic disappears follows. For an arbitrary row truncation, reducing Z alone does not suffice: one must separately show target K<=J_new, and numerator preservation is needed for the displayed monotonicity of P. Field-dependent but current-receiver-independent source masks are legitimate only with the deterministic fixed-field proof and its separate outer ledger.

## 3. Independent iid witness screen: PASS

Assume Z_y>0 and sample N>=1 accepted receivers iid under pi_y(dx)=U_y(x)dx/Z_y. Each sample u_i supplies its OWN selected radius r_i=R(u_i) and original hard cap nu(Q_ri(u_i))<=4lambda r_i^n. For each finite realization, partition the union in z by the smallest containing radius, breaking ties by finite index. These are frozen measurable source pieces D_i(y), disjoint and contained in their respective witness cubes.

Apply the R297 multiple-block theorem with omega_i=1_Di and the actual gate min(L(x),R(x))>=r_i(y). Each normalized source mass is at most 16/3, so the covered raw traffic is at most (16/3)kappa0 D_gamma N W_beta. It is not necessary to choose a global simultaneous random field of witnesses: the finite product probability kernel pi_y^N and positive Tonelli yield the same source integral. The source partition may depend on the fixed original receiver field, but is fixed before the current x integration. Actual selected witness caps at their same radii are essential.

For t=min(L(x),R(x)), define C_y(t,z)=pi_y{u:R(u)<=t and z in Q_R(u)(u)}. A finite realization covers the actual triple exactly if at least one sampled cube contains z with radius <=t. Hence the averaged gated mask is EXACTLY H_N(x,y,z)=1-(1-C_y(t,z))^N. This is a receiver-dependent mask, proved by averaging valid frozen-partition/gated allocations; it is not inserted into R296 as a source-only mask.

On C_y(t,z)>=1-2^(-1/N), H_N>=1/2. The sufficient gate C_y(t,z)>=log(2)/N is valid. Thus the original traffic on this high-capture branch costs at most (32/3)kappa0 D_gamma N W_beta, with no W_nu repetition and no (a/R)^n penalty. Zero-Z rows have zero J and zero original traffic; define C=H_N=0 there. The exact complementary original traffic is obtained by the complementary C gate; no universal lower capture bound is asserted. All original low/high/history/scale gates remain unchanged.

Actual local diagnostics: 72 exact Fraction finite-menu cases (N=1,...,6, four incidence patterns, three physical thresholds) verified that the averaged minimum-radius allocation equals 1-(1-C)^N. Twelve floating threshold cases passed. These diagnostics support bookkeeping only; the iid product identity and source theorem above are the proof.

## 4. Finite fractional-cover screen: PASS with explicit scope

For a FINITE witness menu with positive costs c_i=(r_i/a)^n and a finite set of target incidence types A_ji in {0,1}, assume every retained target type is coverable. Let tau=min{sum c_i lambda_i:A lambda>=1, lambda>=0}, and g=max_{pi in simplex} min_j sum_i pi_i A_ji/c_i. Direct normalization proves tau=1/g: lambda maps to pi_i=c_i lambda_i/tau and gives score >=1/tau; conversely pi maps to lambda_i=pi_i/(c_i g), a feasible cover of cost 1/g. Finiteness and positive costs give attainment; uncovered target rows give g=0 and tau=infinity.

A measurable feasible coefficient family gives omega(y,z)=min(1,sum lambda_i(y)1_Qri(ui)(z)), equal to one on the specified covered targets. The actual accepted witness caps imply nu(omega_y)<=4lambda a^n sum c_i lambda_i=(16/3)Q tau. R296 therefore pays the covered original traffic by [1+(4/3)log_+((64/9)kappa* tau)](W_beta+W_nu), for a uniform tau bound; for row-varying costs a valid integrated/aggregate version must be explicitly stated. Existence of a cheap full cover, measurable optimizing coefficients for an arbitrary family, and affordable full traffic coverage are not inferred. Positive-volume cell incidence only tests the target source region it actually represents; excluded/null boundaries need the stated source-null convention or direct treatment.

No author proof was read before this independent screen was saved. Further author-file audit is pending.

## 5. Author-file audit after the independent screen

PASS: /tmp/r298_local_cover.md L1-L10 agrees with the independently screened near identity and finite fractional-cover theorem. L7 has the correct (64/9)kappa_*T logarithmic argument. Its uniform T, measurable coefficients and actual same-radius caps are explicit. The finite target region is the exact certified coverage; no source-null or partial-cell point test is substituted for it.

PASS: /tmp/r298_capture_geometry.md equations (1)-(11) give the independently screened finite-product/minimum-radius construction and its complete rowwise payment. The additional inclusive-CDF rank inequality (13) is valid with atoms: decreasing (1-t)^N evaluated at the right endpoint of every CDF jump is bounded by its integral across that jump. On L>=R, actual min equals R, so dropping the remaining masks gives the weighted Stieltjes bound (14). Replacing r^-n by a^-n then gives (15), retaining its source-product/concentration cost. This rank argument is explicitly not transferred to L<R, and the actual receiver-dependent H_N is never used as a frozen pair mask in R296. Outer fees remain displayed conditionally.

PASS: /tmp/r298_variable_scale.md equations (4)-(6) preserve the one actual FIRST budget before scale decomposition. Its cumulative profile is right-continuous, and the measurable supremum over rational scales plus b0 is valid by approximation from above. Equation (8) uses actual source pair masses E_k and only then Jensen; (7) gives the explicitly weaker row-cap version. Separate-bin hard-source multiplicity N_sum=integral m dnu is retained in every aggregate receipt. The KL identity is asserted only on its logarithmic branch and handles the active supports as stated. The scalar example is a limitation of that relaxation, explicitly not an original-kernel counterexample or disproof. Its displayed profile and exact envelope formula are algebraically consistent.

These three proofs give genuine paid suballocations and explicit source-distribution receipts. They do not establish cheap full coverage, remove the original weak ordered-capture branch, or prove the variable-row log(C)+log(n) target without further spatial information. No upstream proof was reaudited, and no new research claim is made.

Author/evidence SHA256 bindings at this checkpoint:
- /tmp/r298_local_cover.md: 39f88a41b3f64059f577b9de846215bffee917bdda6356bae29062dfc5fa8d5f
- /tmp/r298_capture_geometry.md: 1154aae69bc2fcfedb26603697ef01e43790a2d43b4cc7ad2188b4c6e8ef11af
- /tmp/r298_variable_scale.md: 1f36102f6cfaf4b874fbe297d445137f42250bb79de69327ce468e46165fd19c
- /tmp/r298_ordered_checks.py: 1c77bb3e886b9c6598ce01ca26ceaf79843f93c8285e01d7da6915b28d7c7012
- /tmp/r298_ordered_checks.json: 711b970223c945a9ad6fd3ecc519c5bd942b4b14951b686f1896c06a762d5dd1

## 6. Final integration/evidence receipt — PASS and frozen

The final /tmp/r298_README.md matches all three mathematical proofs and their conditional scope. It preserves the kappa0 and outer-source qualifications for the root payment, the exact ordered-capture residual, the weighted rank/concentration cost, the L<R mismatch, and scale-source multiplicity. It explicitly leaves global weak-type closure and the remaining original outer/history ledger open. The positive-cell finite LP numbers (uniform normalized capture 153/700, optimized 32/75, tau=75/32) agree exactly with the certified case. No formula or scope correction is needed.

Inspected actual evidence outputs: ordered JSON reports PASS for 16160 configuration, 304 iid, 76 rank, 580 source-ledger and 528 threshold checks. Cover verifier JSON reports 15 exact zero-gap primal/dual certificates in dimensions 1,2,4,8,16, comprising 9 point and 6 positive-volume cell cases. The variable-scale rerun log records 18 scale-integral comparisons and 100 KL/Jensen checks PASS, consistent with the embedded proof code. The parent reports the actual reruns; this audit inspected the output artifacts and does not claim to have independently run those full scripts. The auditor independently executed the additional 72 Fraction iid/min-radius and 12 threshold checks documented in Section 3. Finite diagnostics remain separate from the analytic proofs and do not supply original FIRST/low/high histories.

Final SHA256 bindings:
- /tmp/r298_README.md: 6c76a6ee668e7d4273d3e7fdbcdf8d7f8f6c2ad2561e0c3cd8b90c6abb56be50
- /tmp/r298_local_cover.md: 39f88a41b3f64059f577b9de846215bffee917bdda6356bae29062dfc5fa8d5f
- /tmp/r298_capture_geometry.md: 1154aae69bc2fcfedb26603697ef01e43790a2d43b4cc7ad2188b4c6e8ef11af
- /tmp/r298_variable_scale.md: 1f36102f6cfaf4b874fbe297d445137f42250bb79de69327ce468e46165fd19c
- /tmp/r298_ordered_checks.py: 1c77bb3e886b9c6598ce01ca26ceaf79843f93c8285e01d7da6915b28d7c7012
- /tmp/r298_ordered_checks.json: 711b970223c945a9ad6fd3ecc519c5bd942b4b14951b686f1896c06a762d5dd1
- /tmp/r298_cover_lp.m: af18d741aca7d6bca66b42f30beeb343148f275083420ddb1055f4f6c7eef939
- /tmp/r298_cover_lp.json: aa4d627d42c8134ec2bae9dc22dc1066d190be3366a46fc8e18ed272b557fa90
- /tmp/r298_cover_verify.py: eca5a4bf84a7f207d24f983761900bbe94ca2ddaa8215e129549b796530c5a4f
- /tmp/r298_cover_verify.json: d6bc8cff7a8884eea075106df01b35897ea012b49dde1fc9083936733909d5a2
- /tmp/r298_variable_checks.py: a6bb562660b3d4487cb7c011ffc68978229358a69620d1a4f33c14693a4c0364
- /tmp/r298_variable_checks.log: aa0f2201f3126aef8f596fa0db13ad04dc0f75b088888145a38645e98e113aad

Final bounded verdict: PASS. No unresolved defect in the audited statements. Exact remaining gap: a controlled payment/cover for all original weak ordered-capture traffic (including the L<R mismatch and weighted rank/concentration fee), plus the original global/outer ledger. The variable-row logarithmic scale candidate is neither proved nor disproved by this round. Audit frozen; no further research or tests requested.

## 7. Reproduction-only README correction

PASS. Read the final reproduction paragraph and checked the MATLAB script's literal fopen('/tmp/r298_cover_lp.json','w'). The updated instruction places reproduction files in /tmp and invokes /tmp/r298_cover_lp.m, matching this fixed output and the adjacent Fraction verifier paths. This supersedes only the earlier README hash in Section 6; no mathematical statement or proof changed, and no mathematics or tests were repeated.

Final README SHA256: a6f6028a0ddd7fae9c7cbb99c316dda891a65de81daf4655d3062c1e2c2b4e9e.
Audit re-frozen after this bounded editorial receipt.
