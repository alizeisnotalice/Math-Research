# R298 — a common finite witness cover at its own physical scales

## 1. Precise new payment, before the construction

Fix one complete original outer-data/clock instance. Retain finite positive L1 sources beta,nu, the original measurable receiver fields s,L,R,q, the original accepted set E, physical scales a<=L,R<=b<=2a, and q_-=3lambda/4<=q<=lambda. At every receiver in E use the ORIGINAL FIRST cap integral p_y beta(dy)<=q and ORIGINAL maximal hard cap; in particular nu(Q_(R(x))(x))<=4lambda R(x)^n. Q_r(x) denotes the centered cube of side r. Let I0(x,y,z) in [0,1] be the full original low-pe, m>M, accepted and all remaining positive history/source mask, for any fixed M>0. Write

    dT=I0(x,y,z) p_y(x) h_(R(x))(x-z)/q(x)
                                    dx beta(dy)nu(dz),
    kappa0=2K/(ell M), gamma=1+1/n,
    psi_inf=3-2/(3gamma^n)<2.754748.

The original full e_g, original m, unique band and actual common s,L,R remain unchanged. In particular the low/high gates give the same point-height qualifications used by R297, not gates recomputed for a witness source. All statements below apply simultaneously to all original bands and both orientations.

Define

    U_y(u)=1_E(u)p_y(u)/q(u), I_y=integral U_y(u)du,
    pi_y(du)=U_y(u)du/I_y                         if I_y>0.

The full-soft scale envelope gives I_y<=S/q_-, where S=(1+n log(b/a))Csoft_n and Csoft_n<=1+(pi/2)sqrt(n). This is used for finiteness only. Zero rows have zero original traffic and are assigned zero cover and zero capture. For nonzero rows define the ORDERED capture

    C_y(t,z)=integral 1{R(u)<=t}1{z in Q_(R(u))(u)}pi_y(du).
                                                               (1)

This is in [0,1]. Crucially its definition contains no factor (a/R(u))^n. For any positive integer N, define the actual edge allocation

    H_N(x,y,z)=1-[1-C_y(min(L(x),R(x)),z)]^N.             (2)

Then the new all-scale estimate is

    T_(H_N)<= (16/3) psi_inf kappa0 N W_beta.             (3)

Consequently, for any 0<eta<=1,

    T_{C_y(min(L,R),z)>=eta}
       <= [(16/3)psi_inf kappa0 N]/[1-(1-eta)^N] W_beta. (4)

For eta=log(2)/N this implies

    T_{C>=log(2)/N} <=(32/3)psi_inf kappa0 N W_beta.       (5)

With N=ceil(sqrt(n)), (5) is an actual source-linear root payment, with its explicit kappa0 and original outer price retained. There is no W_nu charge per scale and no exponential normalization at the smallest physical scale a. The exact covered allocation (2) is itself payable even without restricting to (5).

This is not a claim that all remaining original traffic satisfies the new capture gate. Section 5 gives its exact complement and a genuine rank bound, including the source-concentration cost which that bound does not eliminate.

## 2. Finite common witnesses and the exact allocation identity

For each nonzero row y integrate over N dummy witnesses u_1,...,u_N with product probability pi_y^N. Put r_i=R(u_i). For each source z lying in at least one witness cube, assign it to the containing witness of SMALLEST radius, breaking equal-radius ties by its index. Denote the resulting source pieces by D_i(y;u_1,...,u_N). Explicitly,

    z in D_i iff z in Q_(r_i)(u_i) and no containing witness k
               has (r_k,k) lexicographically smaller than (r_i,i).

These finitely many source sets are measurable, disjoint, and each D_i is contained in its own witness cube. They are frozen with respect to the actual traffic receiver x. They are selected once for the entire receiver integral, not anew for each x. The associated actual suballocation is

    H_config(x,y,z)=sum_i 1_(D_i)(z)1{min(L(x),R(x))>=r_i}.
                                                               (6)

It is in [0,1]. The smallest-radius rule gives the exact pointwise identity

    H_config=1{some i satisfies z in Q_(r_i)(u_i)
                                     and r_i<=min(L(x),R(x))}.   (7)

For fixed x,y,z the event for one witness has probability (1). Independence of the N dummy witnesses therefore gives

    integral H_config product_i pi_y(du_i)
                  =1-(1-C_y(min(L(x),R(x)),z))^N=H_N.             (8)

Equation (8), not average coverage by itself, produces the precise pointwise traffic domination in (4). A configuration can fail to cover an edge; its failure probability is exactly retained.

All these formulas are finite product integrals of measurable kernels. No measurable choice of one global random function y -> configuration is needed. The family pi_y is a probability kernel on nonzero rows; zero rows can be filled with an arbitrary fixed probability for measure-theoretic notation while every allocation there is explicitly set to zero. Actual receiver null exceptional sets are harmless because pi_y is absolutely continuous with respect to true Lebesgue measure du. Cubes may be taken closed: their boundaries have zero nu mass for the assumed L1 source, and the tie convention remains valid regardless.

## 3. Own-scale source payment, including the complete ledger

We use the proved R297 own-scale estimate (scale_budget.md, equations (9),(12)), whose short analytic content is repeated here. For any frozen lower radius r in [a,b], on ORIGINAL low,m>M traffic with min(L,R)>=r, the actual band geometry gives simultaneously

    p_y<=kappa0 r^(-n/2)R^(-n/2),
    p_y<=kappa0 gamma^(n/2) r^(-n/4)R^(-3n/4).

No soft approximation or cap on a latent component is used. Put G=gamma^(n/2). The hard support envelope has exact integral

    integral dx sup_(r<=R<=b) R^(-n)1_(Q_R(z))(x)r^(-n)
            min((R/r)^(-n/2),G(R/r)^(-3n/4))
      =r^(-n) Psi_G((b/r)^n),

where

    Psi_G(S)=1+integral_1^S min(w^(-3/2),G w^(-7/4))dw
              <=psi_inf.

Thus, for EACH fixed row y and fixed witness configuration, after keeping all original qualifications until these height inequalities have been applied, positive extension of dx gives

    integral dx nu(dz) I0 p_y h_R/q H_config
      <=(kappa0/q_-)sum_i r_i^(-n)Psi_G((b/r_i)^n)nu(D_i).
                                                               (9)

This is a rowwise proof; integrating it against a row-dependent configuration law is legal. It does not require a global random measurable selection before applying a theorem only stated for deterministic row maps.

Every witness u_i is a genuine accepted receiver at its SAME actual radius r_i. Therefore

    nu(D_i)<=nu(Q_(r_i)(u_i))<=4lambda r_i^n,
    sum_i nu(D_i)/(q_-r_i^n)<=(16/3)N.                  (10)

The precise averaged capacity is actually

    C_N(y)=integral [sum_i nu(D_i)/(q_-r_i^n)]pi_y^N,
    T_(H_N)<=psi_inf kappa0 integral C_N(y)beta(dy),
    0<=C_N(y)<=(16/3)N.                                (11)

Source overlap can lower (11); no unproved overlap gain is inserted. A given hard source may be used on different beta rows, and its full cost is present in the displayed beta integral. Disjointness within a row prevents double-counted traffic, not all cross-row source costs.

Average (9), use (8),(10), and integrate beta by positive Tonelli. This proves (3). On C>=eta, H_N>=1-(1-eta)^N, proving (4). Since (1-log(2)/N)^N<=1/2, (5) follows. This is one finite common cover with at most N witnesses per row, at arbitrary continuously varying physical scales. It is not N independently charged W_nu estimates, nor a separate source fee for every scale interval.

## 4. What geometric loss has actually been removed

The old R297 probability P_y(z)=integral (a/R)^n1_capture pi_y can be very small solely because a witness radius is large. The new ordered probability tests the actual radius eligibility and capture without this normalization. For example, if the witnesses in a row all have radius r0 and an actual edge has min(L,R)>=r0, then

    C_y(min(L,R),z)=pi_y{capture z},
    P_y(z)=(a/r0)^n pi_y{capture z}.

The theorem is general; this identity merely identifies the eliminated factor. It does not assert that ordered capture dominates old capture everywhere. Actual edges with L<R and no capturing witness below L can still have zero ordered capture. A witness larger than the actual minimum scale does not receive an invented own-scale cap at the smaller radius.

The construction may be performed for any fixed legal receiver probability kernel in place of pi_y, provided its support consists of accepted receivers with the stated hard cap. The payment proof is unchanged. The canonical pi_y above relates capture to actual p_y dx and permits the rank estimate below. No optimization or existence claim for a better probability is required.

## 5. Exact residual and a bounded new rank receipt

There is an exact positive split

    T=T_(H_N)+T_((1-C_y(min(L,R),z))^N).                 (12)

Every factor in the residual is evaluated on the original actual receiver; e_g and m are unchanged. In particular small C is not automatically a small total-source expense.

There is nevertheless a true rank estimate for the L>=R part. Fix y,z and push the subprobability

    1{z in Q_(R(u))(u)}pi_y(du)

forward by R(u). Denote this measure on [a,b] by mu_yz, its mass by m_yz<=1, and its inclusive CDF by F_yz(r)=mu_yz([a,r])=C_y(r,z). For N>=1,

    integral (1-F_yz(r))^N mu_yz(dr)
        <=[1-(1-m_yz)^(N+1)]/(N+1)<=1/(N+1).           (13)

At a CDF jump, the endpoint value of the decreasing function (1-t)^N times the jump is at most its integral over that jump interval. Together with the continuous part this proves (13); equivalently use quantile pushforward and the inclusive CDF. No tie randomization is needed for this upper bound.

On L>=R, min(L,R)=R, so dropping the remaining original nonnegative masks after writing U_y dx=I_y pi_y gives the exact weighted upper bound

    T_((1-C)^N,L>=R)
      <=integral beta(dy) I_y integral nu(dz)
                integral_[a,b] r^(-n)(1-F_yz(r))^N mu_yz(dr).
                                                               (14)

Consequently

    T_((1-C)^N,L>=R)
       <= [W_nu/(a^n(N+1))] integral I_y beta(dy)
       <= [S/(N+1)] W_beta W_nu/(q_-a^n).              (15)

Independently actual hardcap/q gives T_residual<=(16/3)S W_beta, and aggregate FIRST followed by the hard-scale envelope gives T_residual<=(1+n log(b/a))W_nu. The minimum of valid bounds can be taken; none removes the normalized source concentration in (15).

For L<R, formula (12) still applies exactly, but C_y(L,z) is not the inclusive CDF at the actual hard radius R. Equations (13)-(15) are not claimed for that portion. Even in L>=R, (15) is a genuine 1/(N+1) rank gain with a source-product cost, not an unconditional root source-linear estimate. Keeping the r^(-n) integral in (14) rather than replacing it by a^(-n) is a precise possible next geometry target. The present proof supplies no uniform bound that pays this weighted rank integral and the L<R mismatch by root-polylog times W_beta+W_nu.

Thus (3)-(5) are the completed new all-scale payment, while (12),(14) state exactly what is still unpaid. Neither original hardcap alone nor exchangeability has been used to infer an unsupported 1/N source-linear bound.

## 6. Outer parameters and actual numerical verification

All arguments are conditional on the full original outer field. If it depends on xi, the finite integral formulas are jointly measurable in xi. With the original positive raw-to-original price Lambda(xi), equation (3) contributes exactly

    integral Lambda(xi) (16/3)psi_inf(n)kappa0(xi)N(xi)
                                            W_beta(xi) dmu(xi),

and the strong branch (5) has twice that fee. Original outer source-allocation or clock lemmas must pay this displayed quantity; no new free integration over xi, bands or source copies is claimed. The cover is inserted into the already positive original traffic and not differentiated through an unrelated signed clock identity. The original FIRST and hardcap remain hypotheses; the new own-scale proof primarily uses the low/high height and actual witness hardcap.

A local Python run with exact Fractions checked three stages: equal-radius ties; unequal radii and cube faces; and a disconnected three-dimensional wider menu. It passed 16160 configuration/event checks, 304 exact iid probability identities, and 76 inclusive-CDF rank inequalities, including finite atoms. Every tested normalized source ledger obeyed (10). This is finite diagnostic evidence, separate from the proof above. The following is the actual reproducible code and writes no files.

```python
from fractions import Fraction as F
from itertools import product
import json
cases=[(1,[(F(0),),(F(1,2),),(F(2),)],[F(1),F(1),F(2)],[F(1,2),F(1,3),F(1,6)]),
 (2,[(F(0),F(0)),(F(1,2),F(0)),(F(1),F(1))],[F(1),F(3,2),F(2)],[F(1,4),F(1,4),F(1,2)]),
 (3,[(F(0),)*3,(F(1,2),F(0),F(0)),(F(3),)*3,(F(-1),)*3],[F(2),F(1),F(3,2),F(1)],[F(1,10),F(2,10),F(3,10),F(4,10)])]
counts={'configuration_checks':0,'probability_checks':0,'rank_checks':0}
for n,centers,radii,probs in cases:
    zs=list(dict.fromkeys(centers+[tuple(c[k]+r/F(2) for k in range(n)) for c,r in zip(centers,radii)]))
    masses=[F(1,len(zs))]*len(zs)
    inside=lambda z,i: all(abs(z[k]-centers[i][k])<=radii[i]/2 for k in range(n))
    for N in range(1,5):
        obs={(z,t):F(0) for z in zs for t in [F(1),F(5,4),F(3,2),F(2)]}
        for inds in product(range(len(probs)),repeat=N):
            weight=F(1)
            for i in inds: weight*=probs[i]
            ledger=F(0)
            for z,mass in zip(zs,masses):
                choices=[k for k,i in enumerate(inds) if inside(z,i)]
                best=min(choices,key=lambda k:(radii[inds[k]],k)) if choices else None
                if best is not None: ledger+=mass/(F(3,4)*radii[inds[best]]**n)
                for t in [F(1),F(5,4),F(3,2),F(2)]:
                    direct=any(inside(z,i) and radii[i]<=t for i in inds)
                    assigned=best is not None and radii[inds[best]]<=t
                    assert direct==assigned
                    obs[z,t]+=weight*int(assigned)
                    counts['configuration_checks']+=1
            assert ledger<=F(16,3)*N
        for (z,t),value in obs.items():
            C=sum((p for i,p in enumerate(probs) if inside(z,i) and radii[i]<=t),F(0))
            assert value==1-(1-C)**N
            counts['probability_checks']+=1
        for z in zs:
            vals={r:sum((probs[i] for i in range(len(probs)) if radii[i]==r and inside(z,i)),F(0)) for r in set(radii)}
            m=sum(vals.values(),F(0)); cumulative=F(0); lhs=F(0)
            for r,v in sorted(vals.items()):
                cumulative+=v; lhs+=v*(1-cumulative)**N
            assert lhs<=(1-(1-m)**(N+1))/F(N+1)
            counts['rank_checks']+=1
print(json.dumps({'status':'PASS','stages':['equal-radius ties','unequal radii and cube faces','disconnected 3D wider menu'],'counts':counts},sort_keys=True))
```

At the parent's explicit request, the same three-stage checker was also saved as /tmp/r298_ordered_checks.py, with /tmp/r298_ordered_checks.json produced by an actual successful run. That saved version additionally passed 580 source-ledger checks and 528 rational-threshold domination checks. These finite atomic configurations test the cover algebra; they are not claimed to be a verification of every original full-soft input or its low/high gates. The analytic argument supplies that interface. Only this proof and those explicitly assigned diagnostic files were written. No previous frozen proof, other author file or Git state was changed.
