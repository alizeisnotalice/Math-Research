# 第234轮：分数几何与全亏损三次对数来源预算

## 目标、状态和路线调整

本轮目标是在原真实接收几何内改进第233轮的来源拥挤费，不重复归约、不以固定尺度或特殊输入认证一般闭合。一般非负L1输入的一致n^(1/2+o(1))弱型上界仍未证明。

用户20261016材料作为可调整建议使用：保留其中共同来源/历史平均预算的重点。先对真实soft核的平方affinity收费作有限探路，再依据结果选择正向分数幂插值。裸affinity与单核的免费比较缺少支持，未把其失败解释成原FULL反例，也未继续大规模排除路线。最终得到全终端亏损、全部原合法节点的三次对数来源价；后续焦点是该价的真实空间/历史平均结算。

## 已证明的本轮估计及全部费用

详细LaTeX见proof.tex.txt，独立作者推导见spatial_geometry.md，原FIRST适用域与联合容量桥见first_capacity.md，独审见audit.md。已证依赖是原good定义、合法物理节点比较、同capture类QG半列估计、真实hard cap、同原posterior的Gini界与原heavy分母；没有把技能中的待验证外部结论当成已证工具。

n≥2，0<a≤b≤2a，q,K>0，C0=16/3，ell=1+logn，gamma=1+1/n，c_j=gamma^(-j)，rho=||nu||/(qa^n)。共同nu,q,a,beta须在同原V内跨j固定。选择R=1+log_+rho+log_+K和theta=1/(2R)，在receiver、time和node之前固定。若来源随j改变，只能保逐j估计。

原good条件给p1_good≤(K/3)^theta sum_i p^(1−theta)K_i^theta/w_g^theta，只替换正项。物理覆盖e^4对theta一致；同测度Holder插值Jtheta≤J0^(1−2theta)Jhalf^(2theta)≤M^(−n)。hard来源先在真实Omega积分，列价Ftheta≤min(C0wstar^(−theta),||nu||/(qM^n))，两种容量信用取min，不相乘。

对总指数≤n的一般非负仿射乘积，单arcsine网格N=ceil(pi sqrt n)满足sup H_s≤e sum H_r。菜单选点依据posterior p而非原s的最近角；同一个菜单同时覆盖所有theta，保持endpoint/zero条件。不再使用两套网格或额外logn软度费用。

令M0=a/c²，x=nlog(M/M0)，z=x−U>0，U≥0。原全heavy分母e_t>ell q c^(−n/2)t^n给
A_theta=(C0/(2theta))(rho/ell)^theta c^(3theta n/2)exp(theta x)(1−exp(−2theta z))。
同posterior的Gini另给G=(rho/4)c^(2n)exp(−x)z。每节点取min(A_theta,G)，正规节点与唯一b cap均保留。theta趋零的1/theta和j求和费用明确保留；不能让参数趋零免费。

分x≤2log_+rho与其补集，实际全j/M求和得到
(K/3)^theta sum min(A_theta,G)≤Dstar R³，Dstar=9C0 exp(3/2)+2sqrt(e)。rho0真实交通为0。全原far正交通因此满足
P_far(U)≤12Lambda exp(5)ceil(pi sqrt n)Dstar E sum_V ||beta_V||[1+log_+rho_V+log_+K]^3。
12Lambda保原2Lambda、三腿、两朝向；e5为e4物理与e软度。无额外sqrtK幂费、无终端亏损截断、无late余项，仅针对所选原far分支。

如保空间量alpha_theta(y,v)=int_Omega capture P_y^(1−theta)Q_v^theta dx，则来源总质量可在相应节点clock中换为mtheta(y)=int alpha_theta^(1/theta) dnu；不同腿、朝向、菜单的量不能免费合并。FIRST只在原receiver允许的future-soft区无额外价；backward节点要保chi费用。FC10/11给共同Omega内的联合容量桥，但未消除其接收测度与尾价。

## 三阶段数值探路与复现边界

本机Python实际执行，未安装新库。初探12种真实一维hard/soft/J缩放配置，以GL64/128、空间步长1/128与1/256核验，10个独立mpmath点另用25/40dps分片积分。核截尾解析界、求积误差、空间误差、FFT舍入分别记录；无限Lebesgue来源的核费用只是诊断，不是有限L1实例或FULL反例。

新策略经原product权/真实heavy门压力测试：9个一般theta时钟，18个实际节点组；扩大至35个全节点三次对数价配置和65个一般lambda/零边界arcsine族，40/70dps交叉核验。详见numeric_notes.md及完整affinity_checks.json。n到10^6、logrho到1000、logK到100；巨大正规网格以唯一A/G crossing和有限几何和精确表达，只截j并保正遗漏尾。唯一crossing的证明为d log(A/G)/ds=1+theta coth(theta s)−1/s≥1；不是由有限采样猜测单调性。

全价有限样本最大归一上界约0.00232378758；最大配置的几何公式覆盖375392452个正规节点，j正尾归一界约1.19e−48。arcsine有限族最大log损失约0.0624837960<1。以上不是一般锐常数，也不是区间算术认证。作者附录与审查者独立脚本的实际计数另在audit.md列出，不与主脚本混计。

冻结复现通过reproduce.py：包外复制script和contract、重算完整JSON逐字节比较、manifest运行前后校验。运行回执保在包外；归档成员与检查点/ZIP备份逐字节核验后才移除本轮work。未编译PDF。无可归属本轮的实际额度扣减数据。

## 剩余缺口和下一步决策

本轮真正改进是从rho^(2/3)来源费到log³费用，并把soft菜单降到单一O(sqrt n)。仍需证明原共同历史下E sum ||beta|| R³的可付款预算，或保mtheta/联合chi得到更好的平均价；还须原互补分支、source-to-input质量桥与共同截断最终回代。不能把R有界作为全输入假设，也不能把节点FIRST或source-adaptive上确界免费放入nu积分。

R≤B log(n+2)的来源族得到CB³sqrt n log³(n+2)乘自身beta质量，是明确的条件性已付far分支，绝非一般闭合。下一任务应保真实共同接收位置和来源历史，推导平均联合空间费用；不再重做已审的重门代数或裸核反例排除。
