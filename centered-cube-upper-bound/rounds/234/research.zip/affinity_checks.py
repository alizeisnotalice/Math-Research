#!/usr/bin/env python3
"""R234 bounded actual 1D affinity/fee diagnostics, not FULL."""
import argparse,hashlib,importlib.util,json,math
from fractions import Fraction
from pathlib import Path
import numpy as np
import mpmath as mp
HERE=Path(__file__).resolve().parent
Z=80.
CASES=[('initial_hard',0,1,0,1),('initial_small',.01,1,.01,1),('initial_mid',.5,1,.5,1),('initial_soft',1,1,1,1),('stress_hard_J',0,1,1,1),('stress_small_J',.01,1,1,1),('stress_mid_J',.5,1,1,1),('expanded_half_same',.5,.5,.5,.5),('expanded_half_Lplus',.5,.5,.5,17/32),('expanded_half_J',.5,.5,1,1),('expanded_A_double',.5,1,.5,2),('expanded_L_double',.5,2,.5,1)]

def phi_mp(x):
 x=abs(x);h=mp.mpf('.5')
 def E3(t):return h if not t else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
 return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def fs_mp(x,s):return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi_mp(x)
def primitive_mp(x):
 h=mp.mpf('.5');sg=mp.sign(x);t=abs(x)
 return x if t<=h else sg*(h-mp.expint(4,t-h)+mp.expint(4,t+h)+mp.mpf(1)/3-mp.expint(4,1))
def C1(d):return primitive_mp(mp.mpf('.5')-abs(d))-primitive_mp(-mp.mpf('.5')-abs(d))

def phi_gl(x,order):
 x=np.abs(x);r,w=np.polynomial.legendre.leggauss(order);r=(r+1)/2;w=w/2;out=np.empty_like(x);inside=x<=.5
 for mask,core in ((inside,True),(~inside,False)):
  xx=x[mask,None]
  if core:values=2*r-r*np.exp(-(.5+xx)/r)-r*np.exp(-(.5-xx)/r)
  else:values=r*(np.exp(-(xx-.5)/r)-np.exp(-(xx+.5)/r))
  out[mask]=values@w
 return out

def profile(s,L,dx,order):
 N=int(round(2*Z/dx));x=(np.arange(N)+.5)*dx-Z;ph=phi_gl(x/L,order)/L;p=(1-s)*(np.abs(x)<=L/2)/L+s*ph
 return p

def cost_tail(s,L,sig,A):
 def B(s,L):return math.sqrt(L)*(math.sqrt(1-s)+4*math.exp(.25)*math.sqrt(s))
 def e(s,L):return 4*math.sqrt(s*L)*math.exp(.25)*math.exp(-Z/(2*L))
 return 2*min(B(s,L),B(sig,A))*(e(s,L)+e(sig,A))

def fft_cases(dx,order):
 cache={};rows=[]
 for name,s,L,sig,A in CASES:
  for key in ((s,L),(sig,A)):
   if key not in cache:
    p=profile(*key,dx,order);N=len(p);nfft=1<<(2*N-2).bit_length();cache[key]=(np.fft.rfft(np.sqrt(p),nfft),float(np.sum(p)*dx),N,nfft)
  fp,pm,N,nfft=cache[(s,L)];fq,qm,_,_=cache[(sig,A)];alpha=np.fft.irfft(fp*fq,nfft)[:2*N-1]*dx;fee=float(np.sum(alpha*alpha)*dx);points=[]
  with mp.workdps(40):
   for d in (0,.5,1,2,4,8):
    value=float(alpha[N-1+int(round(d/dx))]);ph=float(phi_mp(mp.mpf(str(d))));row={'d':d,'affinity':value,'squared_over_common_J_phi1':value*value/ph}
    if L==A==1:row['squared_over_baseline_C1']=value*value/float(C1(mp.mpf(str(d))))
    points.append(row)
  rows.append({'name':name,'s':s,'L':L,'sigma':sig,'A':A,'dx':dx,'phi_GL_order':order,'space_truncation_Z':Z,'target_mass_grid':pm,'source_mass_grid':qm,'integral_affinity_squared_dd':fee,'continuous_truncation_fee_error_upper_evaluated':cost_tail(s,L,sig,A),'points':points})
 return rows

def mp_affinity(case,d,dps):
 with mp.workdps(dps):
  name,s,L,sig,A=case;s,L,sig,A=map(lambda x:mp.mpf(str(x)),(s,L,sig,A));d=mp.mpf(str(d));zz=mp.mpf(80)
  knots=sorted(set([-zz,zz,-L/2,L/2,mp.mpf(0),d-A/2,d+A/2,d]));knots=[x for x in knots if -zz<=x<=zz]
  def f(x):return mp.sqrt(fs_mp(x/L,s)*fs_mp((x-d)/A,sig)/(L*A))
  value=mp.quad(f,knots);rate=(1/L+1/A)/2;pref=mp.sqrt(s*sig/(L*A))*mp.exp(mp.mpf('.5')+abs(d)/(2*A));tail=2*pref/rate*mp.exp(-rate*zz) if s*sig else mp.mpf(0)
  return {'affinity':mp.nstr(value,32),'affinity_squared':mp.nstr(value*value,32),'squared_over_common_J':mp.nstr(value*value/phi_mp(d),32),'squared_over_baseline_C1':mp.nstr(value*value/C1(d),32) if L==A==1 else None,'split_points':[mp.nstr(x,12) for x in knots],'finite_integral_range':[-80,80],'absolute_integral_tail_upper_evaluated':mp.nstr(tail,16),'dps':dps,'scope':'Ordinary split mpmath quadrature plus analytical tail template, not outward interval certification.'}

def frac_mp(v):
 v=Fraction(v);return mp.mpf(v.numerator)/v.denominator

def theta_clock(n,theta_text,dps):
 with mp.workdps(dps):
  theta=frac_mp(theta_text);C0=mp.mpf(16)/3;eta=frac_mp(Fraction(25,2**69));tau=Fraction(1,2);end=Fraction(1);B=mp.mpf(1 if n==2 else 10**6 if n==16 else 10**100)
  atoms=[{'mass':'1','alpha':'3/5','delete':None},{'mass':'2','alpha':'4/5','delete':None},{'mass':'3','alpha':'11/20','delete':'3/4'},{'mass':'1/7','alpha':'19/20','delete':'17/20'}];nu=sum((Fraction(a['mass']) for a in atoms),Fraction(0));A=nu*Fraction('1e-100' if n==512 else '1/1000');Fs=[];source=[]
  for a in atoms:
   wstar=min(Fraction(1),Fraction(a['alpha']))**n;Delta=n*(1-min(Fraction(1),Fraction(a['alpha'])));f=min(C0*frac_mp(wstar)**(-theta),B*mp.exp(-2*theta*eta*frac_mp(Delta)));Fs.append(f);source.append({'mass':a['mass'],'alpha':a['alpha'],'delete':a['delete'],'actual_additive_Delta_exact':str(Delta),'Ftheta':mp.nstr(f,32),'wstar_fraction_sha256':hashlib.sha256(str(wstar).encode()).hexdigest()})
  knots=sorted(set([tau,end]+[Fraction(a['alpha']) for a in atoms]+[Fraction(a['delete']) for a in atoms if a['delete']]));total=mp.mpf(0);heavy_intervals=[]
  for lo,hi in zip(knots,knots[1:]):
   mid=(lo+hi)/2;indices=[i for i,a in enumerate(atoms) if not a['delete'] or mid<Fraction(a['delete'])];ks={i:n if Fraction(atoms[i]['alpha'])<mid else 0 for i in indices}
   def wt(i,t):return frac_mp(atoms[i]['mass'])*min(1,frac_mp(atoms[i]['alpha'])/t)**n
   def e(t):return sum(wt(i,t) for i in indices)
   def gap(t):return e(t)-frac_mp(A)*(t/frac_mp(tau))**n
   left,right=frac_mp(lo),frac_mp(hi);stop=left
   if gap(left)>0:
    if gap(right)>=0:stop=right
    else:
     rl,rh=left,right
     for _ in range(4*dps):
      mm=(rl+rh)/2
      if mm==rl or mm==rh:break
      if gap(mm)>0:rl=mm
      else:rh=mm
     stop=(rl+rh)/2
   value=mp.mpf(0)
   if stop>left:
    def integrand(u):
     t=mp.exp(u);return sum(Fs[i]*ks[i]*wt(i,t) for i in indices)/e(t)
    value=mp.quad(integrand,[mp.log(left),mp.log(stop)]);total+=value
   heavy_intervals.append({'from_t_exact':str(lo),'to_t_exact':str(hi),'alive_source_count':len(indices),'heavy_stop':mp.nstr(stop,32),'score_integral':mp.nstr(value,32)})
  z=n*mp.log(2);bound=C0/(2*theta)*frac_mp(nu/A)**theta*2**(theta*n)*(-mp.expm1(-2*theta*z));assert total<=bound*(1+mp.mpf(10)**(-dps+8))
  return {'n':n,'theta_exact':theta_text,'source_atoms':source,'B':mp.nstr(B,32),'eta_exact':str(Fraction(25,2**69)),'A_exact':str(A),'nu_total_exact':str(nu),'tau':'1/2','h_gstar':'1','r0':'1/2','z_n_log_h_over_tau':mp.nstr(z,32),'fee_one_over_two_theta':mp.nstr(1/(2*theta),32),'actual_heavy_integral':mp.nstr(total,32),'general_theta_heavy_bound':mp.nstr(bound,32),'ratio_to_bound':mp.nstr(total/bound,32),'heavy_intervals':heavy_intervals,'scope':'Same finite actual product clocks and full current normalizer, deletion atoms included; static Ftheta uses actual additive Delta. Not spatial/source/FULL qualification.'}

def theta_node_samples(n,theta_text,T_text,dps):
 with mp.workdps(dps):
  theta=frac_mp(theta_text);T=mp.mpf(T_text);rho=mp.exp(T);ell=1+mp.log(n);C0=mp.mpf(16)/3;gamma=Fraction(n+1,n);h=n*mp.log(frac_mp(gamma));U=mp.mpf('.5');out=[]
  for j in (0,1):
   M0=gamma**(2*j)
   if M0>2:continue
   kmax=int(mp.floor(n*mp.log(frac_mp(Fraction(2)/M0))/h));ks=sorted(set([1,max(1,kmax//2),kmax]));nodes=[('regular',M0*gamma**k,k) for k in ks if k>=0 and M0*gamma**k<2]+[('cap',Fraction(2),None)]
   for kind,M,k in nodes:
    x=n*mp.log(frac_mp(M/M0));s=x-U
    if s<=0:continue
    c=frac_mp(gamma**(-j));Ag=C0/(2*theta)*(rho/ell)**theta*c**(mp.mpf(3)*theta*n/2)*mp.exp(theta*x)*(-mp.expm1(-2*theta*s));G=rho/4*c**(2*n)*mp.exp(-x)*s
    out.append({'j':j,'node_kind':kind,'k':k,'M':mp.nstr(frac_mp(M),32),'M_fraction_sha256':hashlib.sha256(str(M).encode()).hexdigest(),'x':mp.nstr(x,32),'s_x_minus_U':mp.nstr(s,32),'A_theta':mp.nstr(Ag,32),'Gini_B':mp.nstr(G,32),'actual_min':mp.nstr(min(Ag,G),32),'active_branch':'A_theta' if Ag<=G else 'Gini_B'})
  return {'n':n,'theta_exact':theta_text,'log_rho':T_text,'U':'1/2','a':'1','b':'2','node_samples':out,'scope':'Finite actual regular/capped nodes only, no all-j/node sum or unapproved global theta bound.'}

def global_theta_menu():
 rows=[]
 for n in (2,16,512,1000000):
  for T,logK in (('-10','0'),('0','0'),('10','6'),('1000','100')):
   for U in ('0','3'):rows.append({'stage':('initial' if n<=16 else 'stress' if n==512 else 'expanded'),'n':n,'b':'2','log_rho':T,'log_K':logK,'U':U})
 rows.append({'stage':'rho_zero','n':512,'b':'2','log_rho':'0','log_K':'6','U':'0','rho_zero':True})
 for n in (16,512):rows.append({'stage':'cap_node_boundary','n':n,'b_gamma_power':2,'log_rho':'10','log_K':'6','U':'0'})
 return rows

def global_theta_sum(c,dps):
 with mp.workdps(dps):
  n=c['n'];h=n*mp.log(1+mp.mpf(1)/n);ell=1+mp.log(n);T=mp.mpf(c['log_rho']);logK=mp.mpf(c['log_K']);U=mp.mpf(c['U']);X=min(c['b_gamma_power']*h,n*mp.log(2)) if 'b_gamma_power' in c else n*mp.log(frac_mp(c['b']));R=1+max(T,0)+max(logK,0);theta=1/(2*R);C0=mp.mpf(16)/3;Cstar=9*C0*mp.exp(mp.mpf('1.5'))+2*mp.sqrt(mp.e);pref=theta*(logK-mp.log(3));logprice=mp.log(Cstar)+3*mp.log(R)
  actualj=max(0,int(mp.floor(X/(2*h)))+1)
  while actualj and 2*(actualj-1)*h>X:actualj-=1
  while 2*actualj*h<=X:actualj+=1
  if c.get('rho_zero'):return {'configuration':c,'R':mp.nstr(R,32),'theta':mp.nstr(theta,32),'Cstar':mp.nstr(Cstar,32),'actual_j_count':actualj,'evaluated_j_count':0,'sum_over_Cstar_R_cubed_upper':'0','margin_to_one':'1','rho_zero_branch':True,'scope':'Exact empty source zero-price branch, no logarithm of zero.'}
  loglinear=T-U+pref;J=min(actualj,max(1,int(mp.ceil((max(loglinear-logprice,0)+110)/(2*h)))));total=mp.mpf(0);regular_node_count=0;regular_A_count=0;regular_G_count=0;cap_count=0
  def geo(qlog,N):
   if not N:return mp.mpf(0)
   return mp.expm1(qlog*N)/mp.expm1(qlog)
  def G_moments(N):
   if not N:return mp.mpf(0),mp.mpf(0)
   q=mp.exp(-h);qn=mp.exp(-h*N);d=1-q
   return -mp.expm1(-h*N)/d,(q-N*qn+(N-1)*qn*q)/(d*d)
  def logratio(j,s):
   loga=mp.log(C0/(2*theta))+theta*(T-mp.log(ell))-mp.mpf('1.5')*theta*j*h+theta*U
   logb=T-mp.log(4)-2*j*h-U
   return loga-logb+(1+theta)*s+mp.log(-mp.expm1(-2*theta*s))-mp.log(s)
  def node(j,x):
   s=x-U
   if s<=0:return mp.mpf(0)
   loga=mp.log(C0/(2*theta))+theta*(T-mp.log(ell))-mp.mpf('1.5')*theta*j*h+theta*x+mp.log(-mp.expm1(-2*theta*s));logb=T-mp.log(4)-2*j*h-x+mp.log(s)
   return mp.exp(min(loga,logb)+pref-logprice)
  for j in range(J):
   cap=X-2*j*h;first=max(0,int(mp.floor(U/h))+1)
   while first*h<=U:first+=1
   count=max(0,int(mp.ceil(cap/h))-first)
   while count and (first+count-1)*h>=cap:count-=1
   while (first+count)*h<cap:count+=1
   # Monotone Atheta/G ratio locates the sole switching integer; sum both branches geometrically.
   left,right=0,count
   while left<right:
    mid=(left+right)//2;s=(first+mid)*h-U
    if logratio(j,s)<=0:left=mid+1
    else:right=mid
   NA=left;NG=count-NA;regular_node_count+=count;regular_A_count+=NA;regular_G_count+=NG
   loga=mp.log(C0/(2*theta))+theta*(T-mp.log(ell))-mp.mpf('1.5')*theta*j*h+theta*U
   if NA:
    s0=first*h-U;part=mp.exp(theta*s0)*geo(theta*h,NA)-mp.exp(-theta*s0)*geo(-theta*h,NA);total+=mp.exp(loga+pref-logprice)*part
   if NG:
    s0=(first+NA)*h-U;g0,g1=G_moments(NG);logb=T-mp.log(4)-2*j*h-U;total+=mp.exp(logb-s0+pref-logprice)*(s0*g0+h*g1)
   if cap>U:total+=node(j,cap);cap_count+=1
  tail=mp.exp(loglinear-logprice-2*J*h) if J<actualj else mp.mpf(0);upper=total+tail;assert upper<=1+mp.mpf('1e-27')
  brute_diff=None
  if n<=16:
   gamma=Fraction(n+1,n);b=min(gamma**c['b_gamma_power'],Fraction(2)) if 'b_gamma_power' in c else Fraction(c['b']);check=mp.mpf(0);j=0
   while gamma**(2*j)<=b:
    M0=gamma**(2*j);M=M0
    while M<b:check+=node(j,n*mp.log(frac_mp(M/M0)));M*=gamma
    check+=node(j,n*mp.log(frac_mp(b/M0)));j+=1
   brute_diff=abs(check-total);assert brute_diff<mp.mpf('1e-27')
  return {'configuration':c,'R':mp.nstr(R,32),'theta':mp.nstr(theta,32),'Cstar':mp.nstr(Cstar,32),'actual_j_count':actualj,'evaluated_j_count':J,'summed_regular_nodes_by_formula':regular_node_count,'A_branch_regular_node_count':regular_A_count,'G_branch_regular_node_count':regular_G_count,'positive_caps':cap_count,'sum_over_Cstar_R_cubed_partial':mp.nstr(total,32),'positive_omitted_j_tail_over_price_upper':mp.nstr(tail,16),'sum_over_Cstar_R_cubed_upper':mp.nstr(upper,32),'margin_to_one':mp.nstr(1-upper,32),'small_n_original_physical_loop_difference':mp.nstr(brute_diff,16) if brute_diff is not None else None,'actual_empty_clock_window':X<=U,'scope':'Geometric sums on all regular nodes of each evaluated j, single switching min branch, unique physical cap. Remaining j use a positive Gini tail majorant; ordinary high precision, not interval certification.'}

def arcsine_menu_cases():
 rows=[]
 for n in (2,512,1000000):
  patterns=[('single_endpoint',['1'],['0'],[Fraction(n)]),('fractional_mixed',['1','0'],['0','1'],[Fraction(n,3),Fraction(n,5)]),('zero_coeff_zero_weight',['1/100','3','0','2'],['4','0','0','2'],[Fraction(n,7),Fraction(n,11),Fraction(0),Fraction(n,13)]),('full_weight_endpoints',['0','1'],['1','0'],[Fraction(n,2),Fraction(n,2)]),('constant',['2','0','1'],['2','0','1'],[Fraction(n,4),Fraction(0),Fraction(n,8)]),('zero_total_weight',['0','1'],['0','0'],[Fraction(0),Fraction(0)]),('zero_family',['0','1'],['0','2'],[Fraction(1),Fraction(n-1,2)])]
  for name,a,b,lam in patterns:
   for s in ('0','3/10','1'):rows.append({'stage':('initial' if n==2 else 'stress' if n==512 else 'expanded'),'n':n,'name':name,'a':a,'b':b,'lambda':[str(v) for v in lam],'s':s})
 for s in ('1e-12','0.999999999999'):
  rows.append({'stage':'arcsine_endpoint_pressure','n':16,'name':'near_endpoint','a':['0','1'],'b':['1','0'],'lambda':['8','4'],'s':s})
 return rows

def arcsine_check(c,dps):
 with mp.workdps(dps):
  n=c['n'];a=list(map(Fraction,c['a']));b=list(map(Fraction,c['b']));lam=list(map(Fraction,c['lambda']));s=Fraction(c['s']);Nw=sum(lam,Fraction(0));N=int(mp.ceil(mp.pi*mp.sqrt(n)));assert Nw<=n and min(lam)>=0
  vals=[(1-s)*aa+s*bb for aa,bb in zip(a,b)];zero=any(ll>0 and f==0 for ll,f in zip(lam,vals))
  if zero:return {'n':n,'N_menu':N,'N_weight_exact':str(Nw),'F_s_zero_branch':True,'domination_check':True,'scope':'Zero weighted product gives the trivial covering inequality, zero exponents omitted.'}
  p=sum((ll*s*bb/f for ll,bb,f in zip(lam,b,vals) if ll>0),Fraction(0))/Nw if Nw else Fraction(0);assert 0<=p<=1;angle=mp.asin(mp.sqrt(frac_mp(p)));Delta=mp.pi/(2*N);j=min(N-1,max(0,int(mp.floor(angle/Delta))));beta=(j+mp.mpf('.5'))*Delta;r=mp.sin(beta)**2
  logFs=sum(frac_mp(ll)*mp.log(frac_mp(f)) for ll,f in zip(lam,vals) if ll>0);logFr=sum(frac_mp(ll)*mp.log((1-r)*frac_mp(aa)+r*frac_mp(bb)) for ll,aa,bb in zip(lam,a,b) if ll>0);gap=logFs-logFr;assert gap<=1+mp.mpf(10)**(-dps+9)
  return {'n':n,'N_menu':N,'N_weight_exact':str(Nw),'posterior_p_exact':str(p),'chosen_single_cell_index':j,'chosen_sin_squared_midpoint':mp.nstr(r,32),'log_F_s':mp.nstr(logFs,32),'log_F_grid':mp.nstr(logFr,32),'log_cover_loss':mp.nstr(gap,32),'factor_Fs_over_selected_Fr':mp.nstr(mp.exp(gap),32),'factor_e_bound_margin_in_log':mp.nstr(1-gap,32),'F_s_zero_branch':False,'zero_weight_total_branch':Nw==0,'one_menu_not_squared':True,'scope':'Posterior angle cell, not nearest original s; arbitrary noninteger weights and zero coefficients handled explicitly. Finite coverage check, not a proof by sampling.'}

def main(output):
 low=fft_cases(1/128,64);high=fft_cases(1/256,128);rows=[]
 for a,b in zip(low,high):rows.append({'configuration':{k:b[k] for k in ('name','s','L','sigma','A')},'coarse':a,'refined':b,'fee_refinement_difference':abs(a['integral_affinity_squared_dd']-b['integral_affinity_squared_dd'])})
 checks=[]
 for index,d in ((0,.5),(1,2),(2,4),(3,8),(4,2),(6,4),(9,2),(10,4),(2,1),(3,1)):
  a=mp_affinity(CASES[index],d,25);b=mp_affinity(CASES[index],d,40);fft=next(v['affinity'] for v in high[index]['points'] if v['d']==d)
  with mp.workdps(40):
   pdiff=abs(mp.mpf(a['affinity'])-mp.mpf(b['affinity']));assert pdiff<mp.mpf('1e-20')
  checks.append({'affinity_25_40dps_abs_difference':mp.nstr(pdiff,16),'case_name':CASES[index][0],'d':d,'at_25dps':a,'at_40dps':b,'FFT_refined_affinity':fft,'FFT_minus_mp':mp.nstr(mp.mpf(str(fft))-mp.mpf(b['affinity']),16)})
 theta_clocks=[];theta_nodes=[]
 for n in (2,16,512):
  for theta in ('1/2','1/10','1/100'):
   lo=theta_clock(n,theta,40);hi=theta_clock(n,theta,70)
   with mp.workdps(70):
    td=abs(mp.mpf(lo['ratio_to_bound'])-mp.mpf(hi['ratio_to_bound']));assert td<mp.mpf('1e-25')
   theta_clocks.append({'at_40dps':lo,'at_70dps':hi,'bound_ratio_40_70dps_difference':mp.nstr(td,16)})
   for T in ('10','50'):
    nl=theta_node_samples(n,theta,T,40);nh=theta_node_samples(n,theta,T,70);assert len(nl['node_samples'])==len(nh['node_samples'])
    with mp.workdps(70):
     nd=max((abs(mp.mpf(a['actual_min'])-mp.mpf(b['actual_min']))/max(1,abs(mp.mpf(b['actual_min']))) for a,b in zip(nl['node_samples'],nh['node_samples'])),default=mp.mpf(0));assert nd<mp.mpf('1e-25')
    theta_nodes.append({'at_40dps':nl,'at_70dps':nh,'node_min_relative_precision_difference':mp.nstr(nd,16)})
 phi_validation=[]
 with mp.workdps(40):
  xx=np.array([0.,.49,.5,.51,1.,4.,8.]);ref=[float(phi_mp(mp.mpf(str(x)))) for x in xx]
  for order in (64,128):
   vv=phi_gl(xx,order);phi_validation.append({'order':order,'points':xx.tolist(),'maximum_absolute_error_against_mpmath_E3':max(abs(float(a)-b) for a,b in zip(vv,ref))})
 global_checks=[]
 for c in global_theta_menu():
  lo=global_theta_sum(c,40);hi=global_theta_sum(c,70)
  with mp.workdps(70):
   gd=abs(mp.mpf(lo['sum_over_Cstar_R_cubed_upper'])-mp.mpf(hi['sum_over_Cstar_R_cubed_upper']));assert gd<mp.mpf('1e-25')
  global_checks.append({'at_40dps':lo,'at_70dps':hi,'normalized_precision_difference':mp.nstr(gd,16)})
 arcsine_checks=[]
 for c in arcsine_menu_cases():
  lo=arcsine_check(c,40);hi=arcsine_check(c,70);assert lo['N_menu']==hi['N_menu'] and lo['F_s_zero_branch']==hi['F_s_zero_branch']
  if not hi['F_s_zero_branch']:
   with mp.workdps(70):
    ad=abs(mp.mpf(lo['log_cover_loss'])-mp.mpf(hi['log_cover_loss']));assert ad<mp.mpf('1e-25')
  else:ad=mp.mpf(0)
  arcsine_checks.append({'configuration':c,'at_40dps':lo,'at_70dps':hi,'log_cover_loss_precision_difference':mp.nstr(ad,16)})
 result={'general_theta_global_formula':'R=1+log_+(rho)+log_+(K),theta=1/(2R); sum_actual_j,M (K/3)^theta min(A_theta,Gini_B) <= Cstar R^3, Cstar=9 C0 exp(3/2)+2 sqrt(e).','new_source_price_outer_prefix':'Original 12 Lambda exp(5) N, N=ceil(pi sqrt(n)), and original source/receiver measures remain outside this finite source-price check.','soft_menu_fee':'Single posterior-arcsine menu, factor exp(1)*N, not N squared.','check_counts':{'kernel_configurations':len(rows),'independent_mpmath_points':len(checks),'general_theta_clocks':len(theta_clocks),'finite_node_groups':len(theta_nodes),'global_cubic_source_price_cases':len(global_checks),'general_lambda_arcsine_families':len(arcsine_checks)},'general_lambda_arcsine_menu_checks':arcsine_checks,'general_theta_cubic_source_price_checks':global_checks,'phi_GL_independent_validation':phi_validation,'general_theta_product_heavy_checks':theta_clocks,'general_theta_actual_node_samples':theta_nodes,'general_theta_global_sum_status':'Author-approved explicit Cstar R^3 source-price candidate checked on actual nodes; remaining original source expectation/branches not paid by finite checks.','schema':'R234_real_1D_affinity_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'contract_sha256':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest(),'libraries':{'numpy':np.__version__,'mpmath':mp.__version__,'scipy_available':importlib.util.find_spec('scipy') is not None},'kernel':'phi=h*int_0^1 exp(-abs(x)/r)dr, p_s=(1-s)h+s phi, P_s,L(x)=p_s(x/L)/L','kernel_case_count':len(rows),'FFT_cases':rows,'independent_mp_checks':checks,'exact_control':{'hard_hard_L_A_1_integral_affinity_squared_exact':'2/3','FFT_refined_hard_control_error':high[0]['integral_affinity_squared_dd']-2/3,'exact_formula':'alpha(d)=(1-abs(d))_+, integral alpha^2=2/3'},'scope':['Actual one-dimensional physical kernels; FFT and quadrature are ordinary numerical evidence.','GL r quadrature uses the analytically integrated hard convolution; all physical hard boundaries align with midpoint grids.','Continuous truncation error and mesh/GL refinement are separate; no interval mesh/GL guarantee.','Uniform infinite source interpretation of integral alpha^2 is a kernel diagnostic, not positive L1/FULL.','Pointwise alpha^2/phi1(d) is a common-J fee diagnostic, not a claimed uniform source bound.','Only L=A=1 baseline C1 ratio has the stated original weight interpretation.','No fitted dimension order, original capture/Omega/history realization or global payoff claim.']}
 output.write_text(json.dumps(result,indent=2)+'\n');print([(a['configuration']['name'],a['refined']['integral_affinity_squared_dd']) for a in rows],flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'affinity_checks.json');main(ap.parse_args().output)
