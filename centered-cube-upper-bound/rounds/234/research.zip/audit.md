# R234 independent audit — statement-first screen

Status: FINAL PASS for the stated original positive far-traffic estimates, integrated proofs and recorded numerical implementation. Sections 1–6 preserve the statement-first screening, completed before reading either R234 author proof; subsequent final review is recorded below. Only this file is auditor-owned. The arbitrary-positive-L1 root target remains open.

## 1. Exact object and double-receiver identity

Fix all original outer labels and one certified node, orientation, leg and common-soft menu value. Its spatial parameters and the capture function must already be fixed independently of clock time and the other posterior source. Put
\[
\alpha(y,v)=\int_\Omega C(x,v)\sqrt{P_y(x)T_v(x)}\,dx,
\quad 0\le C\le1,\quad
m_\alpha(y)=\int_{Z_\tau}\alpha(y,v)^2\,d\nu(v).
\]
Here both receiver variables below have actual Lebesgue measure; the source is the same \(\nu\), restricted to \(Z_\tau\) if that is the stated clock moment. Tonelli gives exactly
\[
m_\alpha(y)=\int_{\Omega^2}\sqrt{P_y(x)P_y(x')}
\int_{Z_\tau}C(x,v)C(x',v)\sqrt{T_v(x)T_v(x')}\,d\nu(v)\,dx\,dx'.
\]
The two capture factors are both required. An independently selected source in the second receiver factor, a diagonal-only expression, or a replacement of \(dx\,dx'\) by source measure is not this identity. All exchanges are legal for nonnegative measurable kernels, even before integrability is proved; any finite claimed bound still needs its own estimate.

For actual adaptive kernels the algebraic identity remains true if the selected integrands are measurable, but their integrals need not be normalized translation-kernel integrals. Fixed-node normalization/QG applies only after a paid cover, not by changing the selector separately in \(x\) and \(x'\). The existing single common-soft menu and three physical legs/orientations retain their full expense.

## 2. What original FIRST actually supplies

The first narrow check was R128 RT4–5. At fixed original \((\omega,V,j,y,t)\), \(\nu,Z_t,w_t,e_t,\Pi_t\) are independent of the receiver and hard source. Original terminal sets, scales, soft parameter, high/capture/history gates and \(w_g\) are not. R128 explicitly lists \(J,Q^*,K_0\) caps. Positivity of \(Q^*=(K_1+K_2+J)/3\) alone would give individual caps \(3q\); **that is not the full original FIRST contract**.

After the compare author's source pointer, independently read `/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md` §1 (the original global FIRST statement) and R116 `astra_first.md` §1 (the current/future selector convention). The authentic stronger statement is
\[
P_{s_{\rm actual}(x),L(x)}f(x)=q,\qquad
P_{r,A}f(x)\le q\quad\text{for every }r\ge s_{\rm actual}(x),\ A\in[a,b].
\]
Thus each actual \(K_1,K_2,J\) has cap \(q\), and every fixed enlarged node with legal \(A\) also has cap \(q\) **on its future-soft receiver domain** \(\{s_{\rm actual}(x)\le r\}\). For inherited source measures dominated by the same complete \(f\,dx\), including the authentic \(\nu,\beta\), positivity transfers this bound without recomputing FIRST on the restricted source. The original actual selector and full-input qualification must remain explicit.

For the common third leg \(T_v(x)=J(x-v)=P_{1,b}(x-v)\), both receiver points in the original allowed set have the same genuine FIRST cap. Consequently
\[
\int_{Z_\tau}C(x,v)C(x',v)\sqrt{J(x-v)J(x'-v)}d\nu(v)
\le\sqrt{(J*\nu)(x)(J*\nu)(x')}\le q.
\]
This is a valid weak consequence:
\[
m_\alpha(y)\le q\left(\int_\Omega\sqrt{P_y(x)}dx\right)^2.
\]
It keeps its receiving-volume/tail cost. It is not a free dimension-uniform bound on \(m_\alpha\); replacing the remaining integral by 1 would be incorrect. The same common J remains J under the certified nodes. A node menu value below \(s_{\rm actual}(x)\) has no unit cap merely from the above future authorization. For \(r<s<1\), the coordinate inequality gives the valid explicit price
\[
P_{r,A}\le\left(\frac{1-r}{1-s}\right)^nP_{s,A}.
\]
At \(s=1,r<1\) this particular price is infinite, not a unit cap. A finite common-J fallback for all \(r\in[0,1]\), \(A\in[a,b]\) is
\[
P_{r,A}(z)\le D_{r,A}^nJ(z),\qquad
D_{r,A}=\frac bA\left[r+\frac{1-r}{\phi(A/(2b))}\right].
\]
This follows from radial monotonicity of \(\phi\), \(A\le b\), and the core lower bound \(\phi((A/b)u)\ge\phi(A/(2b))\) for \(|u|\le1/2\). It is an explicitly paid, potentially exponential price. Let \(\chi(x)\) be the minimum of the applicable future price and this fallback. The legitimate Gram bound is then \(q\sqrt{\chi(x)\chi(x')}\), and its spatial consequence is \(m_\alpha(y)\le q(\int_\Omega\sqrt{P_y(x)\chi(x)}dx)^2\). The actual receiver weight stays inside that integral.

Likewise the target-side cap transfers to a fixed enlarged soft-node target on its future domain, or with its explicit \(\chi(x)\) price; it is not an unqualified unit cap for every node soft value on all receivers. Any target-side Cauchy/Schur argument must identify this domain/price and preserve \(\beta\) rather than normalize it into a posterior. A future parameter may be chosen at each receiver because the original inequality is simultaneous in those parameters, but it may not depend on the integrated source inside a supremum and still be charged as a single FIRST response (R116 explicitly cautions against this). The hard-source local cap is used on the original receiver hardband \(\Omega\), not after that domain has been discarded.

## 3. Static capture and operator qualifications

The retained capture function can be a certified fixed-node exclusion, with the R229 qualification: the actual \(R\le L\) branch permits its specified enlarged exclusion, while \(R>L\) permits the common \(Q_a\) exclusion only on the actual upper-clamp \(H_0\ge a\) subbranch. A lower-clamp row is not automatically excluded from that core. Actual selector/capture gates depending on \(t\) or the other posterior source must remain inside the original weighted traffic or be uniformly dominated; they cannot enter a static \(\alpha\) by notation alone. Empty capture regions mean empty regions, not a zero-side singleton cube.

One legal formulation is an operator
\(Tf(v)=\int_\Omega C(x,v)\sqrt{T_v(x)}f(x)dx\) from \(L^2(dx)\) to \(L^2(1_{Z_\tau}\nu)\). Then \(m_\alpha=\|T\sqrt{P_y}\|^2\). A two-measure Schur bound needs explicit positive weights \(a(x),b(v)\) and both verified inequalities
\[
\int C(x,v)\sqrt{T_v(x)}b(v)d\nu(v)\le A a(x),\qquad
\int_\Omega C(x,v)\sqrt{T_v(x)}a(x)dx\le B b(v).
\]
Only then does \(m_\alpha\le AB\int_\Omega P_y dx\) follow. FIRST on \(T_v\), which is the square of this half-density kernel, is not by itself the first Schur inequality with the desired constant. A Hilbert–Schmidt alternative must pay \(\int_\Omega\int C^2T_vd\nu dx\); for common J the immediate bound is \(q|\Omega|\). Neither formulation automatically supplies orthogonality, a square-summable scale family, or removal of a source moment.

## 4. Exact expense that an author improvement must control

R233 permits, separately for each node/leg/menu/orientation, the genuine cost
\[
C_0(g^*/\tau)^{n/2}\sqrt{m_\alpha(y)/A_\tau}
\bigl[1-(\tau/h_M)^n\bigr],\quad
A_\tau=\ell q a^n c^{-3n/2},\quad h_M=g^*e^{-U/n}.
\]
It can be compared by min with that same node's QG/Gini or distribution-sensitive bound. Before a uniform domination is proved, the outer expense is the actual
\(2\Lambda\sqrt{K/3}\,4e^4\,\mathbb E\sum_{V,j,M,\mathrm{legs,orientations,menu}}\int\beta_V(dy)\)
of those costs. Different affinities cannot be extracted as a free common object or independently optimized after clock integration. To conclude a new input/root payment, a proposed spatial bound must control this expected, scale-weighted original-source sum, or a correctly reassembled equivalent, including its \(K,\ell,q,a\) dependence. A pointwise source norm or one fixed-scale overlap is insufficient.

The original hard source has already been retained through the column step; it cannot be capped a second time. The two original posteriors must keep the same \(e_t\), actual heavy/valid time and original source roles. This positive route introduces no new signed/deletion credit. The source matrix or Schur constant, if used, must be explicitly bounded in the original measures rather than named and treated as paid. No general endpoint, complementary-branch payment or free node FIRST is presently certified.

## 5. Actual bounded local verification

Independent local Python/Fraction run, exit 0: 27 exact checks on simple functions supported on finite Lebesgue receiver/source cells. The double-receiver identity and the stated common row-cap consequence were verified; the off-diagonal contribution was strictly positive in these checks. This is an exact finite algebra check of the interface, not an instance of the physical cube kernels, a FULL construction or a substitute for the Tonelli/Cauchy proof.

The complete-future FIRST source correction above was added after narrowly reading the supplied authentic old sources, before reading a new R234 author proof. Await the authors' exact quantitative proposition; no R234 author draft has been read at this checkpoint. No Git, PDF or spawned agent was used.

## 6. New fractional-power proposition: independent screen before author proof

The parent supplied a more direct candidate while the initial capacity screen was pending. For a fixed \(0<\theta\le1/2\), the original good inequality \(pw_g\le(K/3)\sum_iQ_i\), positivity and subadditivity of \(z^\theta\) give
\[
p1_{\rm good}\le(K/3)^\theta\sum_{i=1,2,J}
 p^{1-\theta}Q_i^\theta/w_g^\theta.
\]
The same positive, physical-node cover must still be proved/retained. Fixed-node interpolation itself is valid: with the original hard window and exact-min node weight,
\[
J_0=\int h_Rp\,dx\le\min(L^{-n},R^{-n})=M^{-n},\qquad
J_{1/2}\le M^{-n}E_*.
\]
Hölder on that same hard-window measure, with any retained identical static receiver mask, gives
\(J_\theta\le J_0^{1-2\theta}J_{1/2}^{2\theta}\le M^{-n}E_*^{2\theta}\).
The alternative local-cap column is \(F_\theta\le C_0w_*^{-\theta}\); it is not multiplied by the QG column bound.

The growing-floor calculation independently extends without a subset endpoint:
\[
\int F_\theta k_t\,d\Pi_t
\le nC_0(g^*/t)^{n\theta}(\|\nu\|/e_t)^\theta,
\]
by Hölder on the same current carrier. On actual heavy times only, integrate its positive majorant to the node window. For \(s=x-U>0\), the resulting node price is
\[
\frac{C_0}{2\theta}(\rho/\ell)^\theta
c^{3n\theta/2}e^{\theta x}(1-e^{-2\theta s}).
\]
It agrees with R233 at \(\theta=1/2\). Its other same-node bound remains \((\rho/4)c^{2n}e^{-U}se^{-s}\). Thus the improved \(\rho^{2\theta/(1+\theta)}\) exponent has an explicit \(\theta\)-dependent cost, not a free limit as \(\theta\downarrow0\).

### One common arcsine menu

Independently screened the supplied statement for finite nonnegative affine factors
\(F_s=\prod_j[(1-s)a_j+sb_j]^{\lambda_j}\), \(\lambda_j\ge0\), \(N_w=\sum_j\lambda_j\le n\). Zero-weight factors can be omitted. If \(F_s=0\), the domination is immediate; if \(N_w=0\), the function is constant. Otherwise, for \(0<s<1\) and \(F_s>0\), weighted AM–GM gives, with \(p=N_w^{-1}\sum_j\lambda_jsb_j/[(1-s)a_j+sb_j]\),
\[
\log(F_r/F_s)\ge N_w\{D(p\|s)-D(p\|r)\}
\ge-N_wD(p\|r).
\]
The first nonnegative relative-entropy term must be dropped in this direction, not silently declared an equality. Put \(N=\lceil\pi\sqrt n\rceil\), \(\Delta=\pi/(2N)\), \(r_i=\sin^2((i+1/2)\Delta)\). For \(p=\sin^2\alpha\), the nearest midpoint \(\beta\) has \(|\delta|=|\alpha-\beta|\le\Delta/2\) and \(\sin\beta\cos\beta\ge\Delta/\pi\). Taylor's inequality gives
\[
\frac{|p-r_i|}{\sqrt{r_i(1-r_i)}}
\le2|\delta|+\frac{\delta^2}{\sin\beta\cos\beta}
\le(2+\pi/2)|\delta|<4|\delta|.
\]
Therefore \(nD(p\|r_i)\le n\chi^2(p\|r_i)\le4n\Delta^2\le1\), and
\(\sup_sF_s\le e\sum_{i=0}^{N-1}F_{r_i}\).
Endpoints \(s=0,1\) follow by continuity; all menu points are interior. This menu is independent of \(\theta\). For the two common-soft legs the exponent sum is \(n\), and for the common-J leg it is \(n(1-\theta)\le n\). Thus there is a single \(O(\sqrt n)\) menu, not a product of two menus. The physical-node expansion and original measures still require their own accounting.

### Safe explicit small-theta source charge

An independent safe bound, useful for checking any sharper author constant, is as follows. For regular spacing in \([\log2,1]\) and one capped node,
\[
\sum_s\min(ae^{\theta s},bse^{-s})
\le\min\{3b,(6/\theta)a^{1/(1+\theta)}b^{\theta/(1+\theta)}
(1+\log_+(b/a))^{\theta/(1+\theta)}\}.
\]
For \(b/a\ge1\), split at \(t=[\log(b/a)+\log(1+\log(b/a))]/(1+\theta)\). The growing prefix plus cap costs at most \((2/\theta+1)ae^{\theta t}\), the decreasing tail plus cap at most \(3b(t+1)e^{-t}\), and \(t+1\le2(1+\log(b/a))\); these give the displayed safe constant. For \(b/a<1\), use the linear branch. This is a bound on the actual same-node min, before taking any source budget.

For common sources across \(j\), set
\[
a_0=\frac{C_0}{2\theta}(\rho/\ell)^\theta e^{\theta U},\quad
b_0=(\rho/4)e^{-U},\quad
K_\theta=(C_0/(2\theta))^{1/(1+\theta)}
4^{-\theta/(1+\theta)}\ell^{-\theta/(1+\theta)}
\rho^{2\theta/(1+\theta)}.
\]
The \(j\) exponent is \(7\theta/[2(1+\theta)]\), whose geometric sum is \(\le2/\theta\). A safe total is consequently
\[
\min\{\rho e^{-U},\ (12/\theta^2)K_\theta
(1+\log_+(b_0/a_0))^{\theta/(1+\theta)}\}.
\]
This makes the roughly \(\theta^{-3}\) expense explicit. The original outer factor becomes \(2\Lambda(K/3)^\theta\), with all three legs, orientations and the single menu still charged. One may choose \(\theta\) from fixed outer source labels, common over \(j\), only after proving these uniform estimates; a source-by-source or receiver-by-receiver optimization cannot be inserted and factored for free. Choosing \(\theta\) of order \(1/\log\rho\) can give a polylogarithmic congestion price, but does not itself supply the required expected source/input budget or settle \(K\) and complementary branches.

Actual additional local computation, exit 0: 433 checks, including exact Fraction backward-softness comparisons, 70-dps arcsine/KL endpoint checks for \(n=2,16,512,10^6\), and the general-\(\theta\) scalar primitive. Maximum tested \(nD(p\|r_i)\) was `0.12496759591180161246`. These are finite implementation diagnostics; the displayed general conclusions follow from the independent arguments above. No new R234 author proof has yet been read.

### Sharper chosen-theta all-node screen

The parent's subsequently supplied explicit logarithmic-cubic sum is also independently verified before the author draft. Set
\[
R=1+\log_+\rho+\log_+K,\qquad\theta=(2R)^{-1},\qquad T=2\log_+\rho.
\]
For \(x\le T\), there are at most \(T/h+2\le3R\) nodes per \(j\), including the unique cap; here \(h=n\log\gamma\ge\log2\ge2/3\). Also
\[
\sum_jc_j^{3\theta n/2}\le1+2/(3\theta h)\le3R,
\quad (K/3)^\theta\rho^\theta e^{\theta T}\le e^{3/2},
\quad C_0/(2\theta)=C_0R.
\]
The small-node contribution, already including the original good-comparison factor, is at most \(9C_0e^{3/2}R^3\). For \(x>T\), the full regular-plus-cap tail obeys \(\sum xe^{-x}\le3(T+1)e^{-T}\). The Gini price, \(\sum_jc_j^{2n}\le4/3\) and \((K/3)^\theta\le\sqrt e\) therefore give a total \(\le\sqrt e\rho(T+1)e^{-T}\le2\sqrt eR\). These estimates include \(\rho<1,T=0\); zero-source rows are directly zero. Consequently a safe total source charge is
\[
C_*R^3,\qquad C_*=9C_0e^{3/2}+2\sqrt e,
\]
with the physical cover/menu/leg coefficient \(2\Lambda\times6e^5N=12\Lambda e^5N\), \(N=\lceil\pi\sqrt n\rceil\). This replaces the coarser fixed-theta optimization above; it does not rely on a source density cap.

Choosing \(\theta_V\) this way is legitimate because \(\rho_V,q_V,a_V,K\) are fixed measurable outer-leaf data, common over \(j\), and all fractional inequalities plus the same arcsine menu hold uniformly in \(\theta\). No physical selector is reoptimized and no source-dependent FIRST supremum is introduced. The unproved remaining quantity is the actual expected \(\beta\)-weighted \(R_V^3\) moment, as well as the original complementary branches. It must not be replaced by an assumed dimension-free log-moment bound.

Actual local 60-dps run: 128 finite chosen-theta count/geometric-series/exponent checks passed for \(n=2,16,512,10^6\); the computed scalar constant is `218.418517917627367778595963661`. This is a finite diagnostic evaluation, not an interval certificate or input-mass payment. Await the actual author proofs for final integration review.

## 7. Full author and integration audit

Read complete `spatial_geometry.md` SG1–SG14, `first_capacity.md` FC1–FC11, parent `proof.tex.txt` (1)–(12), the updated contract, final report and driver. Their general fractional-good/node/menu/clock/logarithmic-cubic chain agrees with the independent derivations above.

The following qualifications were checked explicitly:

- The same actual terminal-good inequality gives the fractional three-leg comparison, with outer \((K/3)^\theta\). All fractional exponents are positive where needed; zero kernel factors are handled directly. The physical cover remains \(e^4\) in both orientations for every \(0<\theta\le1/2\), and the fixed-b J leg only reduces its exponent.
- The \(J_0,J_{1/2},J_\theta\) interpolation uses the same hard source and static capture/receiver measure. The exact-min node weight, legitimate three legs and certified capture class remain prerequisites. No lower-clamp core exclusion or extra hard-cap factor is introduced. The spatial refinement is the genuine \(m_\theta=\int\alpha_\theta^{1/\theta}d\nu\), kept separately for each finite leg/menu/orientation term.
- The arcsine selection uses the posterior Bernoulli parameter, not the nearest angle of the original soft value. Its AM–GM direction, relative-entropy remainder, total exponent \(\le n\), zero-exponent/zero-family/constant cases and endpoint limits are correct. The uniform single menu is valid for every frozen outer-leaf \(\theta\); no hidden second menu or theta grid occurs.
- The growing-floor estimate uses the complete current \(e_t\) only on original heavy/valid times, followed by a nonnegative majorant over the node window. It does not impose a floor on a subset mass, differentiate the normalizer, reuse negative credit or add a late error. Its comparison with Gini is a min of bounds on the same actual node traffic.
- The chosen \(\theta_V\) is a measurable function of common outer source data, before all receiver/y/j/node/time choices. The small-node count, unique cap, small-node j sum, large-node tail and coefficient \(D_*=9C_0e^{3/2}+2\sqrt e\) are correct. The remaining coefficient is \(12\Lambda e^5\lceil\pi\sqrt n\rceil\). The proof retains the common-source-over-j qualification and the zero-source branch.
- FC8–9 uses the authentic full-future FIRST domain and explicit backward-soft price. FC10 is Minkowski with exponent \(1/\theta\) on the real \(\nu\) measure; FC11 is Hölder on real \(\beta\), over one common receiver set. The receiver weights, volume/tail cost, zero-beta case and potentially infinite positive integrals are kept. This bridge is not declared an automatically absorbable \(\varepsilon X\) or source-mass budget.

Minor reviewed fixes: parent proof now defines \(\delta=\alpha-\beta\) in the menu calculation; the author supplied the full SG8 103-parameter generation rule and distinguishes its **author-reported 421 checks** from independent checks. The complete-future FIRST correction was made in this audit before author review, rather than preserving the initial weaker inference from R128's listed mixture cap. No substantive mathematical repair remains required.

The report accurately limits the result to the selected original far positive traffic, all terminal deficits, actual soft/physical choices and original heavy clock. The explicit conditional source family with bounded logarithmic congestion is genuinely paid at the displayed \(\sqrt n\log^3 n\) price; it is not the full arbitrary input class. The expected original \(\beta\)-weighted logarithmic source moment, other original branches, source/input bridge and common-truncation absorption remain unpaid.

## 8. Numerical source, execution and evidence boundaries

Read the entire final `affinity_checks.py` and final notes. The analytic E3/E4 formulas reproduce the actual one-dimensional \(\phi\) and baseline \(C\). Midpoint hard boundaries are aligned in the declared configurations. FFT refinement, GL refinement and continuous truncation are separate diagnostics. The continuous fee-tail majorant follows from the stated square-root-density L1 tail plus Young/Cauchy; it is not a guarantee for FFT/mesh/quadrature error. Full-space/infinite-uniform-source diagnostics do not certify an original finite-L1/capture/history configuration.

The general-theta clock calculation retains the same finite product weights, current normalizer, deletion atoms and actual heavy exits. Additive QG deficit is computed exactly as a Fraction; it is distinct from log deficit. The node formula retains the actual grid and unique cap. Its binary search has an analytic justification: for \(s>0\),
\[
\frac d{ds}\log(A_\theta/G)=1+\theta\coth(\theta s)-1/s\ge1,
\]
since \(z\coth z\ge1\). Thus there is at most one switching index. The increasing branch sums \(e^{\theta s}-e^{-\theta s}\); the decreasing branch sums the zeroth and first geometric moments. These formulas were checked algebraically. The uncomputed j tail is explicitly bounded by the positive Gini/R230 tail, with \((K/3)^\theta\) retained. It is not discarded. Small-n independent Fraction physical-node loops and ordinary 40/70-dps agreement are finite diagnostics, not interval certification of the general bound.

Independent actual runs, counted separately:

- Statement-first local tests: 27 exact simple-function double-receiver/cap checks; 433 exact-Fraction/70-dps fractional/menu/primitive checks; 128 chosen-theta count/constant checks. These are the auditor's separate tests, not the author's 421.
- Extracted final `first_capacity.md` embedded script and executed it locally: **300 checks, PASS, exit 0**.
- Executed the final standalone numerical source once, using the bundled Python 3.12 runtime and existing vendor libraries (`numpy 2.3.5`, `mpmath 1.3.0`, scipy unavailable), with `--output /tmp/r234_independent_audit_affinity_checks.json`: **exit 0**. The complete **452,457-byte JSON is byte-identical** to the frozen result, SHA256 `2436b3998309fbf0b78e1beb606192ee55df93d1bba1b566dbcdb5e0a3ffc154`.

The standalone categories are 12 physical-kernel configurations, 10 independent mpmath points, 9 general-theta clocks, 18 finite node groups, 35 full cubic-price cases and 65 weighted arcsine families. The largest recorded global-price upper ratio is `0.0023237875764829065`. This is not a universal sharp constant. The source and contract hashes inside JSON match the actual files; both Python scripts parse. The author's SG8 421 checks remain author-reported, with a complete parameter rule now available; they were not relabelled as an auditor run.

The driver is correctly configured to copy the contract and standalone source outside the package, replay the full JSON and verify the same manifest before and after. This auditor reviewed it statically and ran the underlying full script as above. The parent's subsequent final manifest/package replay and its external receipt are separate evidence, not pre-certified here. No PDF compilation, Git operation or spawned agent was used.

## 9. Final conclusion and frozen SHA256 binding

**Pass.** The new theorem gives the displayed \(O(\sqrt n)\) menu and a cubic logarithmic original-source price, including logarithmic rather than power dependence on K. It preserves the actual receiver/source measures and explicit source expectation. It does not establish a uniform budget for that expectation or the general endpoint theorem. There are no remaining requested corrections blocking this stated scope.

| File | SHA256 |
|---|---|
| `task_contract.md` | `b2543fa43c9274275fee06f2090c8e32554353f9a3b098601e55f51af3a01dfb` |
| `proof.tex.txt` | `845f003e19d65e4e52a472d3d94f720a0560a0b17e8a101b0f5c93a39dfc4f8c` |
| `spatial_geometry.md` | `895b94220fddc4a741cdb5681e979f18425f710d8f0cf709caffed532c45a358` |
| `first_capacity.md` | `eab13ac541b7088561bfca11fa8b4cb7f9508e2360bfbe1518bf2ed2f9df91f0` |
| `affinity_checks.py` | `99ae4bcf718cdfbe89dd5059d60cfe21bc672a9867d5bda3dea8e3a0ed7041de` |
| `affinity_checks.json` | `2436b3998309fbf0b78e1beb606192ee55df93d1bba1b566dbcdb5e0a3ffc154` |
| `numeric_notes.md` | `6a840ef2ec9d84d4489b060af086fbe4a0b1cdb6511a5b43511b6ca7d0691fc2` |
| `report.md` | `b78954c5d514c37ccf22044bfeef43b65aa27c991f7f177449c4496e29386a68` |
| `reproduce.py` | `5788b6b768d7076f7c34158e48a6fc472bba8c9296bd455df7c719320d4e58d3` |

Audit itself is excluded from its own hash table. Audit frozen; writing has stopped.
