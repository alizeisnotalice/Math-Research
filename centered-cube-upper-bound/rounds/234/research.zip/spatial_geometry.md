# R234：共同 soft 菜单与可调幂次的真实多对数来源价

本稿证明一个覆盖全部实际 soft/物理尺度、全部 terminal deficit 和原 far heavy clock 的新上界。把终端 good 的平方根替换推广为 `0<θ≤1/2`，同一个 `O(√n)` soft 菜单仍有效；随后按共同来源 V 选择 θ，将 R233 的正幂拥挤价和外 `√K` 一并降为显式 `log³(Kρ)` 来源矩。该来源矩尚非免费 `W_β` 预算，不宣称一般根阶目标闭合。原 Ω、hard 来源、capture 与实际后验在取得合法列界前均保留。

## SG1 原接口与不变的资格

沿用 R233 HG1：固定原 `(ω,V,j,y)`，`γ=1+1/n,c=γ^{-j},n≥2,0<a≤b≤2a,q>0,ell=1+log n`，

\[
\tau=a/c,\quad w_t(v)=\prod_i\min(1,A_i(y,v)/t),\quad
\Pi_t=1_{Z_t}w_t\nu/e_t,\quad e_t=\int_{Z_t}w_t\,d\nu.
\]

`Z_t` 是原递减 carrier，`0≤k_t≤n`，原 positive score 为 `δ_t(v,u)=(k_t(v)-k_t(u))_+`。只在实际 heavy 有效时间使用

\[
e_t>A_f(t/\tau)^n,\qquad A_f=\ell q a^n c^{-3n/2}.\tag{SG1}
\]

原 high、good/bad、capture、suffix、RN/history、先前付款补集等门保在原正量中。下文可正上放 `[0,1]` 门，但不能向新增时刻授予 SG1。`e_t=0` 或无效时刻置零，不重建后验。

原终端 good 给 `p_y w_g(v)≤(K/3)(Q_1(v)+Q_2(v)+Q_3(v))`，其中三腿仍是
`Q_1=P_{s,L}, Q_2=P_{s,min(b,γL)}, Q_3=J=P_{1,b}`。
对任意固定 `0<θ≤1/2`，次可加性给

\[
\boxed{p_y1_{\rm good}\le(K/3)^\theta
\sum_{i=1}^3\frac{p_y^{1-\theta}Q_i(v)^\theta}{w_g(v)^\theta}.}\tag{SG2}
\]

这是同一原 good 门的正上界，不改变 bad/source 权。θ 可依原 `(ω,V)` 的共同参数确定；本文最终选择不依 receiver x、y、j、节点、clock 或 soft。K 视为原共同正参数。

## SG2 一份适用非整数幂次的共同 soft 菜单

**引理。** 设 `a_j,b_j≥0,λ_j≥0,Σ_jλ_j=N_w≤n`，

\[
F_s=\prod_j[(1-s)a_j+s b_j]^{\lambda_j},\quad0\le s\le1.
\]

零指数忽略。令

\[
N=\lceil\pi\sqrt n\rceil,\quad\Delta=\pi/(2N),\quad
r_i=\sin^2((i+1/2)\Delta),\quad i=0,\ldots,N-1.
\]

则同一确定性菜单对所有上述系数、权和 s 有

\[
\boxed{\sup_{0\le s\le1}F_s\le e\sum_{i=0}^{N-1}F_{r_i}.}\tag{SG3}
\]

**证明。** `N_w=0` 时恒定；`F_s=0` 时不需估计。先取 `0<s<1,F_s>0`。写
`p_j=s b_j/[(1-s)a_j+s b_j]`，`k=Σλ_jp_j`，`p=k/N_w∈[0,1]`。逐因子加权 AM–GM 得

\[
\frac{F_r}{F_s}\ge
(r/s)^k((1-r)/(1-s))^{N_w-k}
=\exp\{N_w[D(p\Vert s)-D(p\Vert r)]\}
\ge e^{-N_wD(p\Vert r)}.\tag{SG4}
\]

这里 D 是 Bernoulli 相对熵，端点按连续值解释。令 `α=arcsin√p`，取其所在角度小区间的中点 β，`r=sin²β`，`d=α−β`。于是 `|d|≤Δ/2`，`β∈[Δ/2,π/2−Δ/2]`，

\[
\sin\beta\cos\beta\ge\tfrac12\sin\Delta\ge\Delta/\pi,
\quad
|p-r|\le2\sin\beta\cos\beta|d|+d^2.
\]

后一式由 sin² 的二阶导数绝对值≤2。故

\[
\frac{|p-r|}{\sqrt{r(1-r)}}
\le(2+\pi/2)|d|<4|d|\le2\Delta,
\quad D(p\Vert r)\le\frac{(p-r)^2}{r(1-r)}\le4\Delta^2.
\]

`N_wD≤nπ²/N²≤1`。SG4 给所选节点 `F_r≥e^{-1}F_s`，再正上放为菜单和。`s=0,1` 由连续性和有限菜单取极限；菜单自身全在 `(0,1)`，不引入零端点除法。证毕。

对移动的前两腿，`P_s^{1−θ}Q_s^θ` 恰是 2n 个 affine 因子的加权乘积，权和为 n。J 腿只有 n 个随 s 的因子，权和 `n(1−θ)≤n`；J 因子为常数。故 SG3 是**一份共同菜单**，无需 N²，也无需预先扩大 soft FIRST 资格。依 s 的实际门先按合法正方向去掉，只保已经证明的共同几何支持，不将门塞入 affine 系数。

## SG3 物理节点和共同窗口的 θ 插值

R229 节点从 `M_0=a/c²` 按 γ 向上，末点截于 b 且不重复。若 `M_0>b` 则为空。两朝向仍取
`(L^*,R^*)=(M,c²M)` 或 `(c²M,M)`，`g_*=cM,w_* = w_{g_*}=\bar w_{c²M}`。
三腿的第三尺度为 `L^*,min(b,γL^*),b`，没有自由 A 网格。

向上尺度覆盖的损失为

\[
(R^*/R)^n(L^*/L)^{n(1-\theta)}(A_i^*/A_i)^{n\theta}\le\gamma^{4n}\le e^4.\tag{SG5}
\]

因为两朝向中三个比例分别不超过 `(γ³,γ,γ)` 与 `(γ,γ³,γ³)`；J 的第三比例实际为1。`g_*≥g` 使 `w_g≥w_*`，分母替换不需反向比较。

固定节点、菜单值及 hard 来源 z，令

\[
J_\theta(y,z,v)=\int \chi_*(x,v)h_{R^*}(x-z)
\frac{P_{r,L^*}(x-y)^{1-\theta}Q_{i,r}^*(x-v)^\theta}{w_*(y,v)^\theta}\,dx.
\]

`χ_*` 可保 Ω 和合法固定 capture 排除。原 `R≤L` 分支保 `Q_max(a,R*/γ³)(v)` 排除；原 `R>L` 只有 upper-clamp 才授 `Q_a(v)` 排除，lower-clamp 无此资格。无排除时指示为1。

归一性与 `P_{r,L*}≤(L*)^{-n}` 给

\[
J_0\le\min((L^*)^{-n},(R^*)^{-n})=M^{-n}.
\]

已证共同窗口 QG 给 `J_{1/2}≤M^{-n}E_*(y,v)`，`E_*=exp(-ηΔ_*),η=25/2^{69}`。对同一共同 hard 窗口使用 Hölder，

\[
\boxed{J_\theta\le J_0^{1-2\theta}J_{1/2}^{2\theta}
\le M^{-n}E_*^{2\theta}.}\tag{SG6}
\]

可保更精确的 capture 因子：若对应半密度共同窗口界有 `E_*Φ_*`，右边改成 `M^{-n}(E_*Φ_*)^{2θ}`。θ=1/2 直接为旧界。此插值没有声称一般 θ 核另有免费 affinity 性质。

## SG4 真正 hard 来源列和空间精化

保原 Ω 的全部合法 hard 尺度局部帽 `h_B*ν≤C_0q,C_0=16/3`，定义

\[
\begin{aligned}
F_\theta(y,v)&=q^{-1}\int\nu(dz)J_\theta(y,z,v),\\
\alpha_\theta(y,v)&=\int_\Omega\chi_*(x,v)
P_{r,L^*}(x-y)^{1-\theta}Q_{i,r}^*(x-v)^\theta\,dx\le1.
\end{aligned}
\]

SG6 和局部帽是同一列的两个上界：

\[
\boxed{F_\theta\le\min\{C_0\alpha_\theta/w_*^\theta,
B_ME_*^{2\theta}\},\quad B_M=\|\nu\|/(qM^n).}\tag{SG7}
\]

没有重复 cap hard 来源，亦不需给上调 soft 节点新授 FIRST。固定节点的精确空间来源量为

\[
m_\theta(y)=\int_{Z_\tau(y)}\alpha_\theta(y,v)^{1/\theta}\nu(dv)\le\|\nu\|.\tag{SG8}
\]

θ=1/2 恢复 R233 平方 affinity 质量。不同腿、朝向、soft 节点的 mθ 不同，保精化时必须逐项求和；不免费合并它们。

## SG5 全 carrier growing-floor 与同节点 Gini

任意固定静态 `F≤C_0 α/w_*^θ`、`0≤α≤1`，令 `mθ=∫Zτ α^{1/θ}dν`。由真实乘积权 `w_t≤(g_*/t)^n w_*` 和 Hölder，实际 heavy 时间上

\[
\begin{aligned}
\iint\chi F(v)\delta_t(v,u)d\Pi_t^2
&\le\int Fk_t\,d\Pi_t
\le nC_0(g_*/t)^{\theta n}
\frac{\int_{Z_t}\alpha w_t^{1-\theta}d\nu}{e_t}\\
&\le nC_0(g_*/t)^{\theta n}(m_\theta/e_t)^\theta\\
&\le nC_0(g_*/\tau)^{\theta n}(m_\theta/A_f)^\theta(t/\tau)^{-2\theta n}.
\end{aligned}
\]

只有末行的非负解析 majorant 被积分到整个节点窗。因此 `h>τ` 时

\[
\boxed{\mathcal K_\theta\le\frac{C_0}{2\theta}
(g_*/\tau)^{\theta n}(m_\theta/A_f)^\theta
[1-(\tau/h)^{2\theta n}].}\tag{SG9}
\]

`mθ=0`、无 heavy 行或 `h≤τ` 时交通零。不需要 persistent subset、subset endpoint 下界、e_t 导数、末端 late 项或删除负信用。

设 `ρ=||ν||/(qa^n),U≥0,x=nlog(M/M_0),s=x−U`，`h=g_*e^{-U/n}`。`s≤0` 为空窗。取 `mθ≤||ν||`，SG9 与 SG7 的 `F≤B_M` 加原同 Π 的 `∫δdΠ²≤n/4`，得同一个实际节点交通的两个估计

\[
\boxed{\mathcal K_{jM,\theta}\le\min\left\{
\frac{C_0}{2\theta}(\rho/\ell)^\theta c^{3\theta n/2}
e^{\theta x}(1-e^{-2\theta(x-U)}),\quad
\frac\rho4c^{2n}e^{-x}(x-U)_+\right\}.}\tag{SG10}
\]

SG10 对所有 y 一致才可提出 β 积分。若保 mθ，则第一项把 ρ 换成 `mθ/(qa^n)`，而第二项仍用原 hard 来源质量。两界取 min，不相乘或重复计费。

## SG6 全 j/节点的显式三次对数价格

对固定原 V，a,q,β,ν 在 j 间共同。`ρ=0` 行为零；以下 `ρ>0,K>0`。令

\[
L_\rho=1+\log_+\rho+\log_+K,\qquad
\theta_V=(2L_\rho)^{-1},\qquad T=2\log_+\rho.
\]

θ 对整条原 V 来源固定，因此不支付额外 receiver/节点选择费。记 `h_0=nlogγ∈[log2,1]`。

**小节点 `x≤T`。** 每个 j 的正规点加至多一个截 b 点，个数≤`T/h_0+2≤3Lρ`；这里用 `log2≥2/3` 和 `T=2log_+ρ≤2(Lρ−1)`。`ell^{-θ}≤1`，并且

\[
(K/3)^\theta\rho^\theta e^{\theta T}
\le\exp\{\theta(\log_+K+3\log_+\rho)\}\le e^{3/2}.
\]

几何级数与 `1/(1-e^{-z})≤1+1/z` 给

\[
\sum_jc_j^{3\theta n/2}
\le1+\frac2{3\theta h_0}
\le1+\frac{4L_\rho}{3\log2}\le3L_\rho.
\]

所以计入原 good 因子 `(K/3)^θ` 后，小节点总费用≤

\[
\frac{C_0}{2\theta}e^{3/2}(3L_\rho)(3L_\rho)
=9C_0e^{3/2}L_\rho^3.\tag{SG11}
\]

**大节点 `x>T`。** 用 SG10 的 Gini 分支且 `(x−U)_+≤x`。正规尾首点 x0>T，以 `q0=e^{-h0}≤1/2` 计算
`Σ_{k≥0}(x0+kh0)e^{-(x0+kh0)}≤2(x0+1)e^{-x0}≤2(T+1)e^{-T}`。
唯一截 b 点再付 `(T+1)e^{-T}`。于是 `Σnode,x>T xe^{-x}≤3(T+1)e^{-T}`。再用 `Σjc_j^{2n}≤4/3`、`(K/3)^θ≤√e`、`ρe^{-T}≤1`，大节点费用≤

\[
\sqrt e(T+1)\le2\sqrt eL_\rho\le2\sqrt eL_\rho^3.\tag{SG12}
\]

合并得到全域、全 U≥0 的实际共同来源价格

\[
\boxed{(K/3)^{\theta_V}\sum_{j,M}\mathcal K_{jM,\theta_V}
\le D_*L_\rho^3,\quad
D_*=9C_0e^{3/2}+2\sqrt e.}\tag{SG13}
\]

空带和物理上端截断只减少左边。如果 a,q 或来源依 j 改变，则不得调用 SG13，须保 SG10 的逐 j 费用。`U≥nlog(b/a)` 的全部节点直接为空。该统一上界没有保 far 的额外衰减；可与旧衰减界对同一交通取 min。

## SG7 原量结算、明确已付分支与剩余费用

原正量外因子为 `2Λ`，SG2 给 `(K/3)^θ` 和三腿；两朝向、物理覆盖 e4、SG3 的一份 eN 菜单。因此

\[
\boxed{\mathcal P_{\rm far}(U)\le
12\Lambda e^5ND_*\,
\mathbb E\sum_V\|\beta_V\|
[1+\log_+\rho_V+\log_+K]^3,
\quad N=\lceil\pi\sqrt n\rceil.}\tag{SG14}
\]

同一个 Π/e/k 的 receiver 独立性允许先取得静态列 SG7，随后使用 SG9；这不重归一来源、不把 β 当 ν 或 Π，不再消费 FIRST、负项、删除或已付支预算。Ω/capture 保到静态共同列；此处粗版只按正方向丢它们，精确 SG8 版本可继续保真实空间信息。所有 terminal deficit 已包含，无 `w_g≥e^{-D}` 前提；`U=0` 涵盖该原 far 分支全部有效 clock，不自动支付另外划分的其它母量。

这是对 R233 正幂来源价的定量降低：原 `ρ^{2/3}` 和外 `√K` 现变成一个共同三次对数来源矩，同时 soft 菜单为纯 O(√n)，没有额外 log n 菜单费。一般 `Σ||β_V||≤W_β` 并不控制该对数矩，故仍不宣称任意输入的根阶闭合。

一个明确已付的大分支是任意固定 `B≥0` 下的来源叶集合

\[
\log_+\rho_V+\log_+K\le B\log(n+1).
\]

在这一真实来源子集上，SG14 给
`12Λ e5(π+1)D_* √n[1+B log(n+1)]³ W_β`；原 θ、两 Π、所有实际 soft/尺度、capture/history 和整个 far clock 均在该估计内。其补集保原对数矩费用，不能通过声明叶子很少或调用未证密度帽删掉。该分支不是限制为特殊 hard 或同中心核族。

## SG8 本机检查与证明范围

作者本机 mpmath 60位实际完成421项检查：n=2,16,512,10^6 的103个 Bernoulli 参数（含0、1、10^-40及相邻端点）对应412项菜单 KL 上界；θ=.5,.1,.001 与三种 clock 长度的9项 SG9 原函数核查。返回 `PASS`，最大已查 `nD(p||r)=0.12496759591180161246`。有限高精度证据不替代 SG2–SG6 的一般证明，也不是实际 FULL 输入认证。

精确复现参数：设置 `mpmath.mp.dps=60`；对每个 `n∈{2,16,512,1000000}`，取同一103项列表
`p=[0,1,mp.mpf('1e-40'),1-mp.mpf('1e-40')]+[mp.mpf(k)/100 for k in range(1,100)]`。
令 `N=ceil(pi*sqrt(n)),Δ=pi/(2N)`，`i=min(N−1,floor(asin(sqrt(p))/Δ))`，`r=sin((i+.5)Δ)^2`，计算
`D=(p*log(p/r) if p else 0)+((1-p)*log((1-p)/(1-r)) if p!=1 else 0)`，逐项断言 `n*D≤1+mp.mpf('1e-50')`。
另对 `θ∈{mp.mpf('.5'),mp.mpf('.1'),mp.mpf('.001')}` 和 `s∈{mp.mpf('.0001'),mp.mpf('.3'),mp.mpf('2')}` 的9个组合，用 `mp.quad(lambda z:mp.exp(-2*θ*z),[0,s])` 与 `-mp.expm1(-2*θ*s)/(2*θ)` 比较，断言绝对差 `<mp.mpf('1e-50')`。以上共 `4×103+3×3=421` 项，均为作者实际运行；独审自己的测试另行记数，不冒称已复跑本421项。独立数值作者的真实核 affinity 诊断亦分开记数；不以未施 Ω/capture 的全空间核数据否定原目标。

本轮到 SG14 的真实多对数来源价停止。下一步最小剩余任务是支付原共同 β 权的对数拥挤矩，或利用 SG8 的实际空间量进一步削减该矩；没有将其命名后当作免费预算。
