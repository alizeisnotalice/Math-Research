# R234：一般 θ 的原 good、物理覆盖及 FIRST 容量桥

**范围。** 主结果是：原三腿的 `θ∈(0,1/2]` good 替换仍有外因子 `(K/3)^θ`；R229 的全部实际物理尺度覆盖仍只付 `e^4`；共同 capture 支持上的节点列满足 `J_θ≤M^{-n}E^{2θ}Φ^{2θ}`。原共同 soft 只出现一个参数，总权重≤n，可接主稿的一份 weighted soft 菜单，不需要独立两菜单。末节恢复完整 future FIRST，并给可直接接 actual mean fee 的联合 receiver 容量式；它的 receiver 积分仍须付款。

## FC1 原三腿的 θ-good 替换

固定原实际 receiver 与全部来源，记 `p=P_{s,L}(x-y)`、`w=w_g(y,v)>0`，以及

\[
 K_1=P_{s,L}(x-v),\quad K_2=P_{s,\min(b,\gamma L)}(x-v),\quad
 K_3=J=P_{1,b}(x-v),\quad Q^*=(K_1+K_2+J)/3.
\]

在原 terminal-good 支 `pw≤KQ^*` 上，对任何在 receiver/clock 积分前固定的 `0<θ≤1/2`，

\[
 \boxed{p\le (K/3)^\theta\sum_{i=1}^3
       \frac{p^{1-\theta}K_i^\theta}{w^\theta}.} \tag{FC1}
\]

证明：`p=p^{1-θ}p^θ≤K^θp^{1-θ}(Q^*)^θ/w^θ`，再用非负数的 `θ` 次幂次可加性 `(∑K_i)^θ≤∑K_i^θ`。p=0 时两边取零；p>0 的 good 行自动有 Q*>0。原外 `2Λ` 与 `q^{-1}` 均仍在，故后续外因子是 `2Λ(K/3)^θ`，不能保留旧 `√K` 或漏掉 `3^{-θ}`。

θ 可以由原冻结叶等标签预先选择，例如依该叶原来源质量；不能把 receiver 内任意 θ(x) 当静态列代价。原 good/bad、capture、FA、history、suffix、high 与已付支正补集仍是实际原门，只在明确正放松时删除，不借回任何负信用。

## FC2 全部物理尺度的 e4 费用不随 θ 增长

沿 R229 `adaptive_geometry.md` AG1–4，`γ=1+1/n`、`c=c_j`，`a≤L,R≤b≤2a`，`g=√(LR)`，实际 band 为 `c/γ≤min(L,R)/g≤c`。向上节点 `M≥M_0=a/c²`，记 `g^*=cM`、`m^*=c²M`，并取

\[
 (L^*,R^*)=(M,c^2M)\quad(R\le L),\qquad
 (L^*,R^*)=(c^2M,M)\quad(R>L).
\]

三腿节点仍为 `A_1^*=L^*`、`A_2^*=min(b,γL^*)`、`A_3^*=b`，soft 分别为 `s,s,1`。所有节点尺度在 `[a,b]`，上端 b 不超窗。

一维 `f_s=(1-s)h+sφ` 偶且沿半径非增，所以 `B^*≥B` 时
`P_{s,B}≤(B^*/B)^nP_{s,B^*}`。因此一般 θ 原核

\[
 h_R(x-z)\,p^{1-\theta}K_i^\theta/w_g^\theta
\]

的物理替换费至多

\[
 (R^*/R)^n(L^*/L)^{n(1-\theta)}(A_i^*/A_i)^{n\theta}. \tag{FC2}
\]

R≤L 朝向的三个比值≤`γ³,γ,γ`，总指数为 `3+(1-θ)+θ=4`；R>L 朝向≤`γ,γ³,γ³`，总指数为 `1+3(1-θ)+3θ=4`。第二腿的截 b 比值不超过 `L^*/L`；J 腿 `A_3^*/A_3=1`，只会减少指数。由于 `g^*≥g`，节点 `w_*=\bar w_{cg^*}≤w_g`，负 θ 次幂直接按正确方向替换，**不另乘一个 weight 比值费**。故

\[
 \boxed{\text{物理覆盖损失}\le\gamma^{4n}\le e^4.} \tag{FC3}
\]

这保全部真实尺度、两个朝向与原三腿。原 far 门仍逐节点给 `[a/c,cM e^{-U/n}]`，不能先统一成长 clock。原 capture 支持按 R229 AG4 继承；没有在节点重算。

## FC3 单个共同 soft 的总权重

固定物理节点后，前两腿的 soft 依赖是 n 个 affine 因子的权重 `1-θ` 与另外 n 个 affine 因子的权重 θ；总权重恰 n。J 腿的 target soft 固定1，可并入独立 s 的系数，剩余总权重 `n(1-θ)≤n`。

所以可直接使用本轮 `spatial_geometry.md` 中按总权重≤n 证明的 weighted soft 菜单；其 arcsine 菜单及常数由该作者稿和独审负责，本稿不重复证明。若暂只使用已审 R220 菜单，同样有

\[
 \sup_s H_s\le4\sum_{r\in S_n}H_r,\qquad
 |S_n|\le8+4\sqrt n\log(n-1). \tag{FC4}
\]

原因是原 R220 曲率证明仅用 `(log H)''≥-sumweights/min(s,1-s)^2` 与端部费 `(1-1/n)^{-sumweights}≤4`；总权重≤n 已足够，非整数 θ 不改变证明。这不是对独立自适应 softs 的无价扩展：原两腿共用 s，J 腿固定1；若真的独立选两个 soft，不能据此省掉第二菜单。依 soft 的原门不并入 affine 系数，先保其已认证支持再作合法正上放。

## FC4 零次列与 θ 列的共同 capture 插值

固定一个节点、来源 y,v,z 与同一个已认证 receiver 支持 `G`（capture 窗口补集，或无排除时全空间）。令 `p_*=P_{r,L^*}(x-y)`、`T_*=P_{σ,A^*}(x-v)`、`w_*=\bar w_{m^*}(y,v)`，并定义

\[
 J_\theta=\int_G h_{R^*}(x-z)
        p_*^{1-\theta}T_*^\theta w_*^{-\theta}dx.
\]

因 `0≤f_r≤1`、`∫p_*=1`，以及 hard 核归一，

\[
 J_0\le\min\{(L^*)^{-n},(R^*)^{-n}\}=M^{-n}. \tag{FC5}
\]

令 `A(x)=1_Gh_{R^*}(x-z)p_*(x)`、`B(x)=1_Gh_{R^*}(x-z)√(p_*T_*)/√w_*`。对 `0<θ<1/2`，`J_θ=∫A^{1-2θ}B^{2θ}`，Hölder 给

\[
 \boxed{J_\theta\le J_0^{1-2\theta}J_{1/2}^{2\theta}
 \le M^{-n}E_*^{2\theta}\Phi_*^{2\theta}.} \tag{FC6}
\]

θ=1/2 直接是原半密度列。第二步仅对 R229 的 exact-min 节点和原三腿使用已审 QG `J_{1/2}≤M^{-n}E_*Φ_*`，不授给任意 w。所有插值使用同一个 hard 来源与同一个 G；不分别归一两 overlap。若端点列为零，非负积分本身使 θ∈(0,1/2] 的相应列为零；不计算 `0/0` 或 `0^0`。θ=0 另由 FC5 处理，不把 FC6 的 Φ^0 当额外 capture 收益。

实际捕获乘积差亦可直接保留：若 `G=ℝ^n\Q_d(v)`，令 `a_i(ξ)=p_{*,i}(ξ)^{1-θ}T_{*,i}(ξ)^θ`，则

\[
 J_\theta=\frac1{(R^*)^n w_*^\theta}
 \left[\prod_i\int_{z_i-R^*/2}^{z_i+R^*/2}a_i
 -\prod_i\int_{[z_i-R^*/2,z_i+R^*/2]\cap[v_i-d/2,v_i+d/2]}a_i\right]. \tag{FC7}
\]

无排除时第二乘积取零。此差非负，三腿只改变 r,σ,L*,A*；不能将上截断原支的 `Q_a` 排除给下截断支。

## FC5 恢复完整 future FIRST：物理节点合法，soft 节点有条件

精确原文是 [master GENERAL_CURRENT_REDUCTION.md:9–13](/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md:9)：原共同 q 的 interior FIRST 满足 `P_{s_0,L}f=q`，且 `P_{s,A}f≤q` 对**全部** `s≥s_0,A∈[a,b]`。同文件第5行明确不在 cut/restricted source 上重启 FIRST。

[R116 astra_first.md:27–31](/Users/zhengzhihao/Desktop/T/output/centered_cube_round116_20261014/astra_first.md:27) 把当前 s 明确为原 selector 值，并给合法 future 区间 `s≤s'≤1,a≤A≤b`；[R117 joint_geometry.md:34–39](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:34) 重申三测试同 x 合法 current/future。这是完整原 FIRST 的继承，不是仅由混合帽 `Q^*ν≤q` 推出各腿 q。仅使用 R128 RT5 混合帽时，仍只能先得 `K_1ν+K_2ν≤3q-Jν`；两种依据须区分。

因此在同一个实际 receiver x，向上物理节点 A∈[a,b] 本身不使 future 失格；但 soft 菜单 r 可能小于原 `s(x)`，不能一律授 node FIRST。对任何 `μ≤f dx`（特别 β 或 ν），有准确有价桥

\[
 \int P_{r,A}(x-v)\mu(dv)\le q\,\chi_r^{\rm fut}(x),\quad
 \chi_r^{\rm fut}(x)=
 \begin{cases}
 1,&r\ge s(x),\\
 ((1-r)/(1-s(x)))^n,&r<s(x)<1,\\
 +\infty,&r<s(x)=1.
 \end{cases} \tag{FC8}
\]

前一支直接用合法 future；第二支逐坐标 `f_r≤[(1-r)/(1-s)]f_s` 后用该物理节点的合法 `P_{s,A}`。这保留了 r 与真实 selector s(x) 的共同位置关系。

只用原共同 `J=P_{1,b}` 帽，也能给全部 soft/scale 的有限价格。φ 偶且径向非增、A≤b，所以

\[
 P_{r,A}(x-v)\le\Gamma_{r,A}^n J(x-v),\quad
 \Gamma_{r,A}=\frac bA\left[r+\frac{1-r}{\phi(A/(2b))}\right]. \tag{FC9}
\]

软项用 `φ(u/A)≤φ(u/b)`；硬项在 `|u|≤A/2` 上用 `φ(u/b)≥φ(A/(2b))`。因此节点容量可取 `qχ_{r,A}(x)`，其中 `χ_{r,A}=min(χ_r^{fut},Γ_{r,A}^n)`。J 腿 r=1,A=b 给χ=1。一般Γ^n明确可能指数增长，不称其为根阶价。

## FC6 不分别取 sup 的 joint capacity 与 actual mean fee

固定节点，取共同可测实际 receiver 集 Ω，其上完整 FIRST 成立；Ω 不随 y,v 改变，其余来源依赖门可保在 G 中。令 `α_θ(y,v)=∫_Ω G(x;y,v)p_{r,L^*}(x-y)^{1-θ}P_{σ,A^*}(x-v)^θdx`，`0≤G≤1` 为真实 Ω/capture 支持，且若作为静态列用于 clock，G 不依辅助时间 t；`m_θ(y)=∫α_θ(y,v)^{1/θ}ν(dv)`。两 receiver 的实际 Lebesgue 积分始终保留；θ=1/2 时正是原 `∫α²ν`，没有 diagonal substitution。

β、ν 是原有限正来源。以下对 Ω 的非负积分允许取∞，先截断 Ω 与核后由单调极限证明；若 β=0，所有含 β 的量单独定义为零，不写 `0×∞`。Minkowski 的 `L^{1/θ}(ν)` 形式与 ν 槽的 FC8–9 给

\[
 \boxed{m_\theta(y)^\theta
 \le q^\theta\int_\Omega p_{r,L^*}(x-y)^{1-\theta}
                           \chi_{\sigma,A^*}(x)^\theta dx.} \tag{FC10}
\]

G≤1 只用于正上放。再对真实 β 积分、用 Hölder 于 β 槽及同 x 的 source-node 容量 `∫P_{r,L^*}(x-y)β(dy)≤qχ_{r,L^*}(x)`，得到

\[
 \boxed{\int m_\theta(y)^\theta\beta(dy)
 \le q\|\beta\|^\theta\int_\Omega
    \chi_{r,L^*}(x)^{1-\theta}\chi_{\sigma,A^*}(x)^\theta dx.} \tag{FC11}
\]

这是明确的联合 receiver 费用。两个节点价格与原 soft selector 保在**同一个 x 积分**中，不对菜单与 χ 分别取最坏值后声称相消；同 soft 两腿共享该 selector，J 腿 target χ=1。若只关心 θ=1/2 的 Gram，Cauchy 亦给 `∫√(T(x-v)T(x'-v))ν(dv)≤q√(χ(x)χ(x'))`，与 FC10 一致。

它接本轮 general-θ heavy mean fee 的准确位置是

\[
 \frac{C_0}{2\theta}r_0^{-n\theta}A_f^{-\theta}
 (1-e^{-2\theta s})\int m_\theta(y)^\theta\beta(dy),\quad
 A_f=\ell qa^nc^{-3n/2},\quad r_0=M_0/M,
\]

另保原 good 外 `2Λ(K/3)^θ`、三腿、朝向、soft 菜单与物理 `e^4`。用 FC11 替换后，真实 receiver 积分、`||β||^θ/A_f^θ` 和 `1/(2θ)` 均仍要付款；不把它自动认作可吸收 `εX` 或免费的 `W_β`。这比指数 maxratio 给出更细的实际 joint 权，但不单独闭合全来源预算。

## FC7 实际本机检查与交付边界

本机 Python Fraction 与 mpmath 60位实际完成300项检查：四个 θ 值核对两朝向/J腿指数≤4；12组有限正 receiver/source 矩阵、四个 θ 值核对 FC10–11 的 weighted Minkowski/Hölder 容量价及原 good 三腿不等式。全部 PASS。它们只验证有限代数，不是原空间 FIRST/FULL 实例或区间证书；一般结论由上文证明承担。

实际脚本如下；本机仅使用已有 mpmath vendor，将 `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor` 加入 `PYTHONPATH`，未安装或改写依赖。

```python
from fractions import Fraction as F
import mpmath as mp
mp.mp.dps=60
checks=0
for theta in (F(1,100),F(1,10),F(1,4),F(1,2)):
    assert 3+(1-theta)+theta==4; checks+=1
    assert 1+3*(1-theta)+3*theta==4; checks+=1
    assert 3+(1-theta)<=4 and 1+3*(1-theta)<=4; checks+=1
for seed in range(1,13):
  nr,ns,nv=5,4,6
  beta=[mp.mpf(i+1)/(ns+2) for i in range(ns)]
  nu=[mp.mpf(i+2)/(nv+3) for i in range(nv)]
  P=[[mp.mpf(1+((seed*(x+2)+(y+1)**2)%11)) for y in range(ns)]
      for x in range(nr)]
  T=[[mp.mpf(1+((seed*(x+3)+(v+2)**2)%13)) for v in range(nv)]
      for x in range(nr)]
  for x in range(nr):
    pp=sum(a*b for a,b in zip(P[x],beta))
    tt=sum(a*b for a,b in zip(T[x],nu))
    P[x]=[p/pp for p in P[x]]; T[x]=[t/tt for t in T[x]]
  for theta in (mp.mpf('.01'),mp.mpf('.1'),mp.mpf('.25'),mp.mpf('.5')):
    aa=[[sum(P[x][y]**(1-theta)*T[x][v]**theta for x in range(nr))
         for v in range(nv)] for y in range(ns)]
    moments=[sum(a**(1/theta)*w for a,w in zip(row,nu))**theta for row in aa]
    for y in range(ns):
      assert moments[y]<=sum(P[x][y]**(1-theta) for x in range(nr))+mp.mpf('1e-50')
      checks+=1
    assert sum(b*m for b,m in zip(beta,moments))<=sum(beta)**theta*nr+mp.mpf('1e-50')
    checks+=1
    p=[mp.mpf(seed+1),mp.mpf(seed+2),mp.mpf(seed+4)]
    K=mp.mpf(256); w=mp.mpf('.4'); qstar=sum(p)/3
    cur=K*qstar/w*mp.mpf('.9')
    bound=(K/3)**theta*sum(cur**(1-theta)*a**theta for a in p)/w**theta
    assert cur<=bound+mp.mpf('1e-45'); checks+=1
print({'mpmath_dps':mp.mp.dps,'fraction_and_high_precision_assertions':checks,
       'result':'PASS','scope':'finite algebra and capacity checks, not FULL or interval certificate'})
```

实际返回 `fraction_and_high_precision_assertions=300,result=PASS`。

本稿完成的是一般 θ 的原参数/尺度/共同来源接口、完整 FIRST 的准确可用域及显式联合容量价。新 arcsine 菜单与 general-θ 全节点来源求和由主作者稿负责，不预报其未经本稿审查的结论；原全弱型闭合仍须由完整总账确认。
