# R234 运行前有限方案

先做12个真实1D核配置：same-soft s0/.01/.5/1、目标hard/small/mid与sigma1的J腿、L=.5的same/.53125 Lplus/J1、L/A=1/2及2/1。phi=h*integral_0^1 exp(−|x|/r)dr，p_s=(1−s)h+sphi；不将无限Lebesgue来源当有限L1/FULL。scipy在现bundled Python不可导入，使用已装numpy的Legendre和FFT，不安装包。

phi的r积分先解析卷掉h：core内inner=2r−r exp(−(.5+x)/r)−r exp(−(.5−x)/r)，core外inner=r[exp(−(|x|−.5)/r)−exp(−(|x|+.5)/r)]，再GL64/128。空间用对称midpoint网格、dx1/128与1/256、截到|x|≤80；hard边界精确对齐。FFT卷积sqrt(P)*sqrt(Q)给alpha(d)，全卷积保支撑|d|≤160，sum alpha² dx给来源费用。保存各精度质量误差、费用差、原始选d比价；求积不是区间认证。

尾误差明确：phi(x)≤exp(.5)exp(−|x|)，所以sqrt(P_s,L)在|x|>Z的L1尾≤4sqrt(sL)exp(.25)exp(−Z/(2L))。Young+Cauchy给affinity²来源费用截尾误差≤2min(BP,BQ)(epsP+epsQ)，B(P)=sqrtL[sqrt(1−s)+4exp(.25)sqrts]。这只约束连续截尾误差，另有非区间GL与空间网格误差。个别alpha用mpmath实际E3 phi公式25/40dps独立分片求积，分片含两hard/phi端点和中心；|x|>Z点积尾用指数majorant单列。

输出费用integral alpha² dd，以及d0/.5/1/2/4/8处alpha²/phi(d)作为共同J价格诊断。baseline L=A=1额外给alpha²/C1(d)，C1=∫hard max(h,phi)的E4原函数；不把其它缩放腿的裸C1比解释为原weight资格。原3腿逐一保留，不作维数阶拟合。先报告少量决定值，按作者具体命题再补必要证书，避免巨大网格。

## 真实核初探实际结果与转向

12个核配置已实跑。dx1/256、GL128下same-scale费用∫alpha²dd，s0/.01/.5/1依次约.666671753/.752466463/2.321330439/3.631864419；hard→J≈.969934357，mid→J≈2.870162891。hard-hard精确控制为2/3，refined误差约5.08626e−6，coarse/refined差约1.52588e−5；不能把refined当精确值。L.5三腿same/.53125Lplus/J1费用约1.160663716/1.195830318/1.810829218；L/A1/2与2/1费用同为约3.094190526（交换对称性）。GL128对7个E3独立点最大绝对误差约1.04e−12（GL64约1.68e−9）；profile质量误差≤4.45e−16不代表affinity²费用没有网格误差。

10个选d用实际E3/E4 phi、hard/phi端点分片mpmath25/40dps独立积分：affinity精度差最大约1.245e−26；refined FFT−mp affinity最大约3.551e−7。所有连续尾误差单列，scale2时费用尾界约9.19e−8，其余多远小于mesh差；这是普通上界模板求值，非区间认证。hard-hard支撑外的FFT极小非零值仅浮点卷积舍入，不当正来源费用证据。

决定值：baseline L=A1时，s.5、d1的mp alpha²/C1≈2.18970966076005，s1、d1≈3.80661622423651。s1、d8共同J比alpha²/phi≈42.8400948864833；mid→J、d4≈11.7900892216638；hard→J、d2≈1.0422240641067。这些是全空间核、未加Omega/capture的比价诊断，说明不能免费假设裸alpha²≤C或≤J；不是原FULL反例，也不由有限d推一般阶。依据这些证据，本轮主路线转向分数good-source插值，不继续大网格搜裸affinity反例。

## 一般theta重时钟有限核验

父级明确新候选后，追加n2/16/512×theta1/2,1/10,1/100共9个真实product/heavy有限模型，沿R233完整原normalizer、所有当前来源和S外删除规则。Ftheta=min(C0 wstar^(−theta),B exp(−2theta eta Delta*))，eta25/2^69，Delta*为实际additive有理和，不用log deficit。真实heavy et>A(t/tau)^n；tau=.5,h=gstar1，n512A/e_tau1e−100避免门在首threshold前空掉。

全部40/70dps通过C0/(2theta)(nu/A)^theta r0^(−theta n)(1−exp(−2theta z))，显式保1/(2theta)费用1、5、50，没有让theta→0免费。n512的actual积分随theta.5/.1/.01约1.04792e67/7.070997e13/104.2279134，相应bounds约6.17558e127/6.89770e26/92658.026；这是不同固定Ftheta的有限价对照，不是同一原交通的渐近结论。18组实际j/首/中/末cap节点另保A_theta/Gini的min直接值，节点费用不改定义。

## 准global cubic价的真实节点三阶段

待peak/audit给准式后才实施全sum：R=1+log_+rho+log_+K，theta=1/(2R)，Cstar=9C0 exp(3/2)+2sqrt(e)≈218.418518。35例覆盖n2/16/512/1e6，logrho−10/0/10/1000、logK0/6/100，U0/3，cap恰等regular节点及rho0独立分支。左侧完整保(K/3)^theta乘sum_actualj,M min{A_theta,Gini}，每节点x=nlog(M/M0)、s=x−U>0，原12Lambda exp5 N等外前缀没有吸收。

大节点范围未粗截clock：每j上A/G比关于s严格递增，定位唯一整数crossing，A段用exp(±theta h)有限几何和、G段用指数0/1阶矩，独立保唯一b cap。只截未评估j的正尾，以Gini和R230每j价给rho exp(−U) exp(−2Jh)，再乘(K/3)^theta/当前总价归一。小n用Fraction物理M=M0 gamma^k原始loop独立复核。最大归一上界约.00232378757648，n1e6、logrho1000、logK100、U0、R1101、theta约.000454133；实际j346574，评估542个j，以几何公式覆盖375392452个regular节点，正遗漏尾归一上界约1.19e−48。40/70dps及小nloop一致仅是数值证据，不作区间证书或由最大比拟合常数。

## 单arcsine菜单：一般lambda与零边界

按peak准规则F_s=product((1−s)a_i+s b_i)^lambda_i，lambda_i≥0且Nw=sumlambda≤n。N=ceil(pi sqrt n)，角cell中点r_j=sin²((j+.5)pi/(2N))。匹配的不是原s最近角：计算posterior p=(sum lambda_i s b_i/f_i(s))/Nw，选asin(sqrt p)所在cell中点。65个有限family含非整数lambda、sumlambda<n、零a/b、零lambda、Nw0、F_s0以及s0/1/近端点，n2/512/1e6；只选同一菜单的对应一个j，不构造两菜单或N²。

全部40/70dps过F_r≥F_s/e。27例F_s0单独为trivial分支；Nw0常数分支不除零，0次幂因子略去。最大log cover loss约.0624837960（n1e6单endpoint族、s0、N3142），即比约1.06447721<e。一般证明来自作者AMGM/KL，有限检查不替代证明。有效菜单费用是eN，保原soft/方向的原始共同选择资格。

最终只交付本轮三文件；12kernel配置、10独立mp点、9theta clock、18有限node组、35global价与65一般lambda family，未生成大dump、未安装库。裸核诊断不认证FULL，新cubic价亦未支付原beta期望log³source价格、其余分支/源桥。合同已绑定父级最终追加版本。

单一crossing的解析支撑（按独审要求补明，不改测试）：s>0时，log(A_theta/G)'=1+theta coth(theta s)−1/s≥1，因为z coth(z)≥1。故A/G严格递增，每个固定j的regular节点只有一个切换索引；A段可用exp(±theta s)的两个有限几何和，G段可用exp(−s)的0/1阶矩。此性质是算法分块的解析依据，不是有限节点观察所得。

最终冻结：完整源码以两个独立--output路径全JSON复跑，均与正式JSON逐字节一致。最后一次/usr/bin/time实际wall 7.22秒、user 7.14秒、sys .06秒（只在笔记记录，不进入JSON）。当前JSON字节数452457；JSON SHA256：2436b3998309fbf0b78e1beb606192ee55df93d1bba1b566dbcdb5e0a3ffc154；源码SHA256：99ae4bcf718cdfbe89dd5059d60cfe21bc672a9867d5bda3dea8e3a0ed7041de。counts={'kernel_configurations': 12, 'independent_mpmath_points': 10, 'general_theta_clocks': 9, 'finite_node_groups': 18, 'global_cubic_source_price_cases': 35, 'general_lambda_arcsine_families': 65}。JSON无runtime/输出路径字段。全部本轮有界工作完成，停止。
