from fractions import Fraction as F
from pathlib import Path
from math import isqrt
import json,sys,platform,time
ROOT=Path(__file__).resolve().parent
start=time.perf_counter();checks=0

def ck(z):
 global checks
 assert z
 checks+=1

def root(x):
 a=isqrt(x.numerator);b=isqrt(x.denominator);ck(a*a==x.numerator and b*b==x.denominator)
 return F(a,b)

def make_model(name,masses,stages,equal=False):
 if equal:
  pieces=[(F(-11,100),F(-9,100),F(1)),(F(9,100),F(11,100),F(1))]
  centers=[F(-1,10),F(1,10)];sides=[F(1)]*2;vol=[F(1,50)]*2
 else:
  M=list(map(F,masses));pieces=[(F(-84,100),F(-82,100),M[0])]
  if stages==2:pieces.extend([(F(-1,100),F(0),M[1]/2),(F(0),F(1,100),M[1]/2)])
  else:pieces.append((F(-1,100),F(1,100),M[1]))
  pieces.append((F(82,100),F(84,100),M[2]))
  centers=[F(-2,5),F(2,5)];sides=[F(1),F(9,5)];vol=[F(1,100),F(9,500)]
 capture=[];margins=[]
 for A in range(2):
  c0=centers[A]-vol[A]/2;c1=centers[A]+vol[A]/2;br=[];mr=[]
  for lo,hi,mu in pieces:
   far=max(abs(c0-hi),abs(c1-lo));near=max(F(0),c0-hi,lo-c1)
   if far<sides[A]/2:br.append(1);mr.append(sides[A]/2-far)
   else:ck(near>sides[A]/2);br.append(0);mr.append(near-sides[A]/2)
  capture.append(br);margins.append(mr)
 ck(abs(centers[0]-centers[1])>(vol[0]+vol[1])/2)
 mu=[z[2] for z in pieces];J=len(mu);m=[sum(mu[j]*capture[A][j] for j in range(J)) for A in range(2)]
 q=[m[A]/sides[A] for A in range(2)];sig=[vol[A]*q[A] for A in range(2)];r=max(q)/min(q);W=sum(mu);X=sum(sig)
 I=[[sum(mu[j]*capture[A][j]*capture[B][j] for j in range(J)) for B in range(2)] for A in range(2)]
 g2=[[I[A][B]**2/(m[A]*m[B]) for B in range(2)] for A in range(2)]
 delta=[[1-I[A][B]**2/(m[A]*max(m[A],m[B])) for B in range(2)] for A in range(2)]
 deltabar=[[(delta[A][B]+delta[B][A])/2 for B in range(2)] for A in range(2)]
 for A in range(2):
  for B in range(2):
   ck(0<=delta[A][B]<=2*(1-g2[A][B]));ck(0<=deltabar[A][B]<=F(3,2)*(1-g2[A][B]))
 stage_data=[]
 for stage in range(stages):
  b=[F(1) if stages==1 or (j<2 if stage==0 else j>=2) else F(0) for j in range(J)]
  a=[[F(1) if equal or (j+A+stage)%2==0 else F(1,4) for j in range(J)] for A in range(2)]
  theta=[]
  for A in range(2):
   vals=[]
   for j in range(J):
    line=[]
    for l in range(J):
     if equal:t=F(int(j==A and l==A))
     else:t=(F(1),F(1,4),F(0))[(j+2*l+A+stage)%3]
     line.append(t)
    vals.append(line)
   theta.append(vals)
  weight=[[[a[A][j]*b[l]*theta[A][j][l] for l in range(J)] for j in range(J)] for A in range(2)]
  for A in range(2):ck(all(0<=weight[A][j][l]<=b[l] for j in range(J) for l in range(J)))
  E=[[[F(capture[A][j]*capture[A][l],m[A]) for l in range(J)] for j in range(J)] for A in range(2)]
  original=[sum(mu[j]*mu[l]*weight[A][j][l]*E[A][j][l]**2 for j in range(J) for l in range(J)) for A in range(2)]
  cross=[[F(0)]*2 for _ in range(2)];signed=[[F(0)]*2 for _ in range(2)];markedD=[[F(0)]*2 for _ in range(2)];geomD=[[F(0)]*2 for _ in range(2)];unmarkedcross=[[F(0)]*2 for _ in range(2)];oldGram=[[F(0)]*2 for _ in range(2)]
  Jb=[[sum(mu[l]*b[l]*capture[A][l]*capture[B][l] for l in range(J)) for B in range(2)] for A in range(2)]
  beta=[sum(mu[l]*b[l]*capture[A][l] for l in range(J))/m[A] for A in range(2)]
  for A in range(2):
   for B in range(2):
    for j in range(J):
     for l in range(J):
      mass=mu[j]*mu[l];ea=E[A][j][l];eb=E[B][j][l];w=weight[A][j][l];diff=ea*ea-ea*eb
      cross[A][B]+=mass*w*ea*eb;signed[A][B]+=mass*w*diff
      markedD[A][B]+=mass*w*max(F(0),diff);geomD[A][B]+=mass*b[l]*max(F(0),diff)
      unmarkedcross[A][B]+=mass*b[l]*ea*eb
      oldGram[A][B]+=mass*root(weight[A][j][l])*root(weight[B][j][l])*ea*eb
    formula=beta[A]-I[A][B]*Jb[A][B]/(m[A]*max(m[A],m[B]))
    ck(geomD[A][B]==formula);ck(0<=markedD[A][B]<=geomD[A][B]);ck(signed[A][B]<=markedD[A][B])
    ck(original[A]==cross[A][B]+signed[A][B]);ck(cross[A][B]<=unmarkedcross[A][B])
  stage_data.append(dict(b=b,a=a,theta=theta,marked_weight=weight,original_density=original,cross=cross,signed=signed,
   marked_positive_defect=markedD,geometry_positive_defect=geomD,unmarked_cross=unmarkedcross,old_Psi_Gram=oldGram,J_AB=Jb,beta=beta))
 for j in range(J):ck(sum(z['b'][j] for z in stage_data)==1)
 for A in range(2):
  for B in range(2):ck(sum(z['geometry_positive_defect'][A][B] for z in stage_data)==delta[A][B])
 partitions=[]
 for label,cells in (('grouped',[[0,1]]),('separate',[[0],[1]])):
  original=cross=signed=markedD=geomD=unmarked=oldmean=variance=cover=dgap=dbarcost=F(0)
  for C in cells:
   sc=sum(sig[A] for A in C)
   for stage in stage_data:
    tr=sum(sig[A]*stage['original_density'][A] for A in C)
    mean=sum(sig[A]*sig[B]*stage['old_Psi_Gram'][A][B] for A in C for B in C)/sc
    vr=sum(sig[A]*sig[B]*(stage['old_Psi_Gram'][A][A]+stage['old_Psi_Gram'][B][B]-2*stage['old_Psi_Gram'][A][B]) for A in C for B in C)/(2*sc)
    ck(tr==mean+vr);ck(vr>=0)
    original+=tr;oldmean+=mean;variance+=vr
    for A in C:
     for B in C:
      ww=sig[A]*sig[B]/sc
      cross+=ww*stage['cross'][A][B];signed+=ww*stage['signed'][A][B]
      markedD+=ww*stage['marked_positive_defect'][A][B];geomD+=ww*stage['geometry_positive_defect'][A][B];unmarked+=ww*stage['unmarked_cross'][A][B]
    cover+=sum(mu[j]*stage['b'][j]*sum(sig[A]*capture[A][j] for A in C)/sc for j in range(J))
   dgap+=sum(sig[A]*sig[B]*(1-g2[A][B]) for A in C for B in C)/sc
   dbarcost+=sum(sig[A]*sig[B]*deltabar[A][B] for A in C for B in C)/sc
  ck(original==cross+signed);ck(original<=cross+markedD);ck(cross<=unmarked<=4*r*cover)
  ck(original<=4*r*cover+geomD);ck(geomD==dbarcost);ck(dbarcost<=F(3,2)*dgap)
  ck(original==oldmean+variance)
  partitions.append(dict(name=label,original_R=original,actual_mark_preserving_cross=cross,signed_difference=signed,
   actual_marked_positive_defect=markedD,unmarked_geometry_defect=geomD,unmarked_cross=unmarked,cover_source_mass=cover,
   cross_row_upper=4*r*cover,old_R472_mean=oldmean,old_R472_variance=variance,
   symmetric_delta_cost=dbarcost,one_minus_g2_cost=dgap,coefficient_3over2_upper=F(3,2)*dgap))
 ck(partitions[0]['original_R']==partitions[1]['original_R']<=X)
 if equal:
  ck(all(z==0 for rr in delta for z in rr));ck(partitions[0]['unmarked_geometry_defect']==0)
  ck(partitions[0]['old_R472_variance']>0);ck(partitions[0]['actual_mark_preserving_cross']==partitions[0]['original_R'])
 # Actual-source fractional representative kernel, same static continuous field.
 Dx=[sum(sig[A]*capture[A][j]/m[A] for A in range(2)) for j in range(J)]
 P=[[sig[B]*sum(mu[j]*capture[A][j]*capture[B][j]/(m[A]*m[B]*Dx[j]) for j in range(J) if Dx[j]) for B in range(2)] for A in range(2)]
 for A in range(2):
  ck(sum(P[A])==1)
  for B in range(2):ck(sig[A]*P[A][B]==sig[B]*P[B][A])
 cost=sum(mu[j]*sum(sig[A]*F(capture[A][j],m[A])**2*m[A] for A in range(2))/Dx[j] for j in range(J) if Dx[j])
 touched=sum(mu[j] for j in range(J) if Dx[j]);ck(cost==touched<=W)
 R=partitions[0]['original_R']
 C=sum(sig[A]*P[A][B]*stage['cross'][A][B] for stage in stage_data for A in range(2) for B in range(2))
 signed=sum(sig[A]*P[A][B]*stage['signed'][A][B] for stage in stage_data for A in range(2) for B in range(2))
 Eplus=sum(sig[A]*P[A][B]*stage['marked_positive_defect'][A][B] for stage in stage_data for A in range(2) for B in range(2))
 Eformula=F(0)
 for stage in stage_data:
  for A in range(2):
   for j in range(J):
    for l in range(J):
     retention=sum(P[A][B]*min(F(1),m[A]/m[B])*capture[B][j]*capture[B][l] for B in range(2))
     ea=F(capture[A][j]*capture[A][l],m[A])
     Eformula+=sig[A]*mu[j]*mu[l]*stage['marked_weight'][A][j][l]*ea*ea*(1-retention)
 ck(R==C+signed);ck(Eplus==Eformula);ck(R<=C+Eplus);ck(C<=4*r*cost)
 fractional=dict(D_x=Dx,P_AB=P,exact_square_weight_cost=cost,source_touched_mass=touched,original_R=R,
  marked_cross=C,signed_defect=signed,actual_positive_defect=Eplus,retention_formula_defect=Eformula,
  positive_defect_over_R=Eplus/R if R else None,cross_bound_4rW=4*r*W,
  geometry_positive_defect=sum(sig[A]*P[A][B]*delta[A][B] for A in range(2) for B in range(2)))
 if equal:ck(Eplus==0 and C==R)

 return dict(name=name,source_pieces=pieces,parent_centers=centers,parent_sides=sides,parent_center_volumes=vol,
 capture=capture,geometry_margins=margins,m=m,q=q,sigma=sig,qband_ratio=r,W=W,X=X,I_AB=I,g_squared=g2,delta=delta,delta_bar=deltabar,
 stage_data=stage_data,partitions=partitions,source_fractional=fractional,scope='Static marks only: no original history, strict-K/highrank/path claim')
models=[make_model('initial_low_overlap',(3,1,8),1),make_model('pressure_distinct_centers_equal_capture',(1,1),1,True),
 make_model('expanded_high_overlap_two_stages',(25,144,81),2),make_model('expanded_massratio4_two_stages',(1,3,13),2)]
out=dict(scope='Four actual continuous wholecapture 1D fields; exact mark-preserving geometric positive-part interface, not original-history/root proof',
 executable=sys.executable,python=platform.python_version(),checks=checks,models=models,
 identities=dict(mark_preserving='Original R = cross with v_A^2 e_A e_B + signed difference; no v_A v_B substitution',
 D='mu_b(QA)/mA-I_AB J_AB/(mA max(mA,mB))',
 delta='1-I_AB²/(mA max(mA,mB)); full source stage partition makes sum_i D_i=delta',
 symmetric='delta_bar=(delta_AB+delta_BA)/2 <= (3/2)(1-g²)',
 old_comparison='R472 variance uses sqrt(v_A² v_B²), new cross keeps v_A²; equal-capture means new defect zero even opposite marks'),
 compute_index=dict(status='complete',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r473_numeric.py',
 arithmetic='Fraction exact continuous-cell integrations and rational square marks; no solver or scan',seconds=time.perf_counter()-start))
(ROOT/'r473_numeric.json').write_text(json.dumps(out,default=str,indent=2)+'\n')
print(sys.executable,'Python',platform.python_version())
for z in models:
 row=z['partitions'][0]
 print(z['name'],'m',z['m'],'R',row['original_R'],'old variance',row['old_R472_variance'],'new marked defect',row['actual_marked_positive_defect'],'geom defect',row['unmarked_geometry_defect'],'symdelta',row['symmetric_delta_cost'])
for z in models:print('fractional',z['name'],'P',z['source_fractional']['P_AB'],'cost',z['source_fractional']['exact_square_weight_cost'],'C',z['source_fractional']['marked_cross'],'E',z['source_fractional']['actual_positive_defect'],'E/R',z['source_fractional']['positive_defect_over_R'])
print('PASS',checks,'exact assertions; 4 continuous fields, 2 partitions each; no scan')
