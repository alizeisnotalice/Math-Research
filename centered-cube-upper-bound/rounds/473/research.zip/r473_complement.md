# R473：共同来源分数分组的真实总价与原接受缺陷

本稿构造一个无需硬 partition 的可测代表父计划。它的交叉项只花一次来源价；原接受权完全留在原父上。未证明其原接受缺陷可吸收，因此没有得到完整根阶预算。

## 1. 一般分数分组，不跨父替换标记

采用冻结合同的 \(\mu=f\,dx,\sigma=q_A dA,m_A,\pi_A,X,W,r=\lambda/q\)。令辅助指标测度为 \(\lambda_0\)，可测 \(w_\xi(A)\ge0\) 满足
\[
 \int w_\xi(A)d\lambda_0(\xi)=1\quad(\sigma\text{-a.e.}),\qquad
 d_\xi=\int w_\xi(A)d\sigma(A).
\]
零 \(d_\xi\) 项置零。构造
\[
 P(A,dB)=\int w_\xi(A)\frac{w_\xi(B)\sigma(dB)}{d_\xi}
 d\lambda_0(\xi).                                             \tag{1}
\]
Tonelli 给 \(P1=1\)（零组不影响 \(\sigma\)-a.e. 行）及 \(\sigma(dA)P(A,dB)\) 对称。设
\(e_A(y,z)=c_A(y)c_A(z)/m_A\)，原标记
\(v_{i,e,A}^2=a_i^e(A,y)b_i(z)\theta_i^e(A,y,z)\)。定义
\[
 C_P=\sum_{i,e}\int\sigma(dA)P(A,dB)\,d\mu(y)d\mu(z)
             v_{i,e,A}^2e_Ae_B.
\]
这是原父标记，不是 \(v_Av_B\)。准确式及正上界为
\[
 R=C_P+\sum_{i,e}\int v_{i,e,A}^2(e_A^2-e_Ae_B),\qquad
 R\le C_P+E_P,                                                \tag{2}
\]
其中所有积分沿 (1)，且
\[
 E_P=\sum_{i,e}\int\sigma\pi_A^2,a_i^e b_i\theta_i^e
 \left[1-\int P(A,dB)\min(1,m_A/m_B)c_B(y)c_B(z)\right].        \tag{3}
\]
(3) 是同一原接受流的正缺陷；没有给代表父任何旧历史。

对 \(I_{AB}=\mu(Q_A\cap Q_B),\ J_{AB,i}=\mu_{b_i}(Q_A\cap Q_B)\)，冻结的加权行界为
\[
 H_i(A,B)=\frac{I_{AB}J_{AB,i}}{(m_Am_B)^{3/2}},\quad
 \int H_i(A,B)d\sigma(B)\le4r\pi_A(b_i).
\]
对称核及 \(2xy\le x^2+y^2\)，应用于 \(x=w_\xi(A)\sqrt{m_A}\)，给
\[
 C_P\le4rS\mathcal B(w),\qquad
 \mathcal B(w)=\int\frac{\int w_\xi(A)^2m_A\,d\sigma(A)}{d_\xi}
                   d\lambda_0(\xi).                          \tag{4}
\]
这里先保留每个 \(b_i\)，再用 \(\sum_i b_i\le1\)；没有阶段次数，也没有把 projective 和换成平方和。非负无界函数先截断，Tonelli 取极限；下面的具体 \(\mathcal B\) 有限。

## 2. 真正可实现的来源预算

取指标就是实际来源 \(x\)，\(\lambda_0=\mu\)，
\[
 w_x(A)=\frac{c_A(x)}{m_A},\qquad
 D(x)=\int\frac{c_A(x)}{m_A}d\sigma(A).
\]
它满足 (1) 的行归一。真实 \(m_A=\mu(Q_A)\) 精确消去平方权：
\[
 \mathcal B(w)=\int_{D>0}\frac{\int c_A(x)/m_A\,d\sigma(A)}{D(x)}d\mu(x)
             =\mu\{D>0\}\le W.                              \tag{5}
\]
因此 \(C_P\le4rSW\)。这是合法的共同来源 Bayes 代表核，通常不接近恒等核；(5) 不能自动支付 (3)。

还可保质量接近性。将完整质量区间
\([qa^n,\lambda b^n]\) 分成 \(N\) 个对数宽度至多 \(\ell\) 的不交带 \(J_j\)，最后一带包含右端点。取
\(w_{j,x}(A)=1_{m_A\in J_j}c_A(x)/m_A\)，指标测度为 counting \(\times\mu\)。同一计算给
\[
 \mathcal B=\sum_j\mu\{D_j>0\}\le NW,\quad
 N\le1+\frac{\log r+n\log(b/a)}{\ell},\quad
 C_P\le4rSNW.                                                \tag{6}
\]
零长度质量区间用一带。取 \(\ell=\sqrt n\)，在固定 \(r\)、单 octave 下得到根阶交叉价格；没有删极端质量带，也没有每阶段重收。

与硬 partition 候选的几何常数核对：忽略接受权后单向缺陷为
\[
 D_i(A,B)=\frac{\mu_{b_i}(Q_A)}{m_A}
 -\frac{I_{AB}J_{AB,i}}{m_A\max(m_A,m_B)}.
\]
共享分组、先合并 \(b_i\) 后，几何缺陷是
\(\delta(A,B)=1-I_{AB}^2/[m_A\max(m_A,m_B)]\)。因 (1) 对称，令
\(g^2=I_{AB}^2/(m_Am_B),\ \rho=\min(m_A,m_B)/\max(m_A,m_B)\ge g^2\)，则
\[
 \tfrac12(\delta(A,B)+\delta(B,A))
 =1-\tfrac12g^2(1+\rho)
 \le(1-g^2)(1+g^2/2)\le\tfrac32(1-g^2).                     \tag{7}
\]
实际研究应优先保 (3)；(7) 只是安全外放松，不提供新的接受恢复。

## 3. 与原门的准确兼容性及唯一未证步

带内代表计划的捕获保留率明确为
\[
 \frac1{m_A}\int_{Q_A}\frac{d\mu(x)}{D_j(x)}
 \int_{m_B\in J_j}\frac{q_B}{m_B}c_B(x)c_B(y)c_B(z)
                         \min(1,m_A/m_B)dB.                  \tag{8}
\]
分母为零的集合对该带 \(\sigma\)-a.e. 父的 \(\pi_A\) 零测，由 Tonelli 保证。
若 \(\ell\le\log K=\sqrt n\)，所有代表满足 \(m_B\ge m_A/K\)。故原
\[
 Z_A(y)=\int_{m_B<m_A/K}c_B(y)\,dB/m_B,\qquad
 C_A(y,z)=\int_{m_B<m_A/K}c_B(y)c_B(z)\,dB/m_B
\]
恰位于另一质量域。其 high-\(Z\)/low-\(C\) 不能直接给 (8) 所需的正下界。对未分带计划，low-\(C\) 也只给严格小质量子积分的上界，方向仍不是恢复下界。

因此本构造真正消除了来源重复价与跨父标记差，却尚缺同一原接受测度下 (3) 的可吸收比较，例如
\(E_P\le\eta R+\varepsilon X+C_\varepsilon\sqrt n\,\mathrm{polylog}(n)W\)，\(\eta<1\)。该式未证明；(6) 已付的交叉项不能被当作它的证明。没有引入额外历史、刷新原来源或重复扣旧信用。

## 4. 实际有限核验范围

脚本 `/tmp/r473_complement_check.py` 已运行，输出 **48 Fraction assertions PASS**。三种分组（全并、部分分带、全分带），核验行守恒、可逆性、平方权总价的精确来源消去，以及保原父标记的有符号恒等式和 (3) 正缺陷。它是有限 incidence 的代数核查，不是连续原场或完整历史认证；一般证明为以上 Tonelli 与真实匹配计算。

完整复现脚本如下（仅依赖 Python 标准库）：

```python
from fractions import Fraction as F
mu=[F(1),F(2)]; sig=[F(1,3),F(1,4),F(1,5)]
c=[[1,0],[1,1],[0,1]]
m=[sum(mu[x]*c[A][x] for x in range(2)) for A in range(3)]
checks=0
for bins in [[0,0,0],[0,1,1],[0,1,2]]:
    latent=[(j,x) for j in sorted(set(bins)) for x in range(2)]
    w={(j,x):[F(c[A][x],m[A]) if bins[A]==j else F(0) for A in range(3)] for j,x in latent}
    d={l:sum(sig[A]*w[l][A] for A in range(3)) for l in latent}
    P=[[sum(mu[x]*w[j,x][A]*sig[B]*w[j,x][B]/d[j,x] for j,x in latent if d[j,x]) for B in range(3)] for A in range(3)]
    for A in range(3):
        assert sum(P[A])==1;checks+=1
        for B in range(3):
            assert sig[A]*P[A][B]==sig[B]*P[B][A];checks+=1
    cost=sum(mu[x]*sum(sig[A]*w[j,x][A]**2*m[A] for A in range(3))/d[j,x] for j,x in latent if d[j,x])
    assert cost==sum(mu[x] for j,x in latent if d[j,x]);checks+=1
    R=C=Esigned=Eplus=Eformula=F(0)
    for A in range(3):
        for y in range(2):
            for z in range(2):
                mark=F(1+A+y+z,7)
                ea=F(c[A][y]*c[A][z],m[A])
                for B in range(3):
                    eb=F(c[B][y]*c[B][z],m[B])
                    base=sig[A]*P[A][B]*mu[y]*mu[z]*mark
                    R+=base*ea**2;C+=base*ea*eb
                    Esigned+=base*(ea**2-ea*eb)
                    Eplus+=base*max(F(0),ea**2-ea*eb)
                    Eformula+=base*ea**2*(1-min(F(1),m[A]/m[B])*c[B][y]*c[B][z])
    assert R==C+Esigned;checks+=1
    assert Eplus==Eformula;checks+=1
    assert R<=C+Eplus;checks+=1
print('PASS',checks,'Fraction assertions: fractional conservation/reversibility, exact cover cost, retained-parent marked defect. Finite incidence algebra only; no native-history claim.')
```

已实际运行的 stdout：

```text
PASS 48 Fraction assertions: fractional conservation/reversibility, exact cover cost, retained-parent marked defect. Finite incidence algebra only; no native-history claim.
```
