# R473 FINAL PASS（限定原父标记保持式、分数分组及恢复量比较）

已先独立 PRE，再审全部冻结稿。通过下述一般接口及有限复现；未证明原接受缺陷可吸收、质量可比代表有足够恢复，亦未完成一般根阶预算。完整旧母账与未付项目保留。

1. **固定原 mark 的准确替换。** 原费用的交叉项始终用 (v_A^2e_Ae_B)，不是 (v_Av_B)。原式保有符号差；取其正支后，实际差可由 (B_e\mathfrak d_i) 支配，且 (\mathfrak d_i=\mu_{b_i}(Q_A)/m_A-I_{AB}J_{AB,i}/[m_A\max(m_A,m_B)]) 精确。交叉项使用 R472 的带 (b_i) 对称行界给 (4r\mathcal B)。这免去父间 history 标记差的正上界费用，但不声称 history 相等、免费运输或保旧 mean 不变。共享对称组中 (g^2\le\rho\le1)，几何缺陷平均系数 (3/2) 正确；原实际负差未被无标记对称性免费扣除。

2. **实际可构造的 fractional 计划。** 一般指标平方权公式由同一来源上的 (\sum_i b_i\le1) 与 (\sum_eB_e=S) 得出。具体 (w_x=c_A(x)/m_A) 的行归一、(sigma)-可逆及零 (D(x)) 行处理均由 Tonelli 合法；平方权费用精确为 (\mu\{D>0\}\le W)，故交叉项 (\le4rSW)，不重复 stage 或来源费。完整对数质量带包含两端点、零长度用一带，(N\le1+[\log r+n\log(b/a)]/\ell) 正确，全部带交叉价 (4rSNW)；没有遗漏极端质量补集。同带 (ell\le\log K) 时 (m_B\ge m_A/K)，与原严格小质量门确属不同域。正缺陷 (8) 是同一原接受流上的实际量，不因该交叉上界自动可付。

3. **原门与完整费用方向。** 原 (P) 附 (x\sim\pi_A) 后来源列 (\le SD(x)\mu(dx))，所以低 (D\le d) 的辅助标签正分数费用 (\le SdW) 成立；它不是未附源的确定父事件，亦不可重收旧信用。高 (D) 的未截断交叉量确有 geometry(6) 的 (m_B^{-2}) 分母。严格小质量用 (I_{AB}\le m_B) 与原 low-common 得 (\lambda h/d)；严格大质量用 (I_{AB}\le m_A) 与闭质量 CDF 平方尾得 (2r/(dK))，质量原子及完整中间范围保留。这两项是**恢复量上界**，不能当成原 (R) 对应质量分支的付款或据此扣去 (R)。原 high-Z/low-C 尚不给中间范围的恢复下界，主稿未作此宣称。充分吸收式(11)仍未证。

4. **证据范围。** 四个正 Lebesgue 连续场保完整来源、实际 selector、静态父标记和两种分组；equal-capture 压力例正确说明新缺陷可为零而旧标记方差正，新 cross 同时改变。不得保旧 cross 再免费替换 variance。有限模型的缺陷比值不认证原接受流统一吸收率；geometry 的 (K=2) 已标辅助阈值，非原项目 (e^{\sqrt n})。没有用任一 finite 场声称原全部 high-rank/history 非空或一般恢复。

## 独立隔离复现

指定本机 Python；目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r473_audit_v47b5o0g`。提取 geometry/complement/main 代码及运行 numeric.py，387、48、147、964项断言全部通过，四份 stdout 与冻结 replay 逐字节一致。numeric JSON 仅删除 `compute_index.seconds` 后完全一致；规范化 SHA256 为 `7662340cffc93df1a3e3d7453f7bfb11616cb87b62f7e00d9a6f3ecf642dd960`。PRE80项代数辅助不计入归档验证数，未扩研究范围。

## 冻结输入 SHA256

- `r473_main.md`: `6f38141dabfaac61d5656021931b62b4be49dd8dff5a14abcf5d156bc0c7e738`
- `r473_geometry.md`: `5fbe656a80a7dcf3fc1a6a1d158ea303fa49c6199798279914a278ae6ff68519`
- `r473_complement.md`: `43681c856c346955256192b9016b2ef02f8ea53d93591c6b2f708ba3fd216cee`
- `r473_numeric.md`: `264c893921c9b60101ab1e41f6dc425057370ec546582de2f0ace7ca1d1f0921`
- `r473_numeric.py`: `7553446defa224c2871ff7da4a3e2bcefdaec6de681d0f7fb9863cd0cb15c6be`
- `r473_numeric.json`: `3141d3dda6d496443f395bd5f5b50e4e6e69d803c657c0b7ec9576d51376e5df`
- `r473_replay.json`: `d7b28ee94813e27b64bb4de3fcb02921b2a7d2f99489fe47f4ab5580eadeabaf`
