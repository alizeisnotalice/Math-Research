# R473：保原父标记的几何正支替换——四场精确证书

关键压力例成功区分两接口：两个实际centerblocks位置不同、cube不同，但捕获相同完整μ；父theta支持完全不交时，R472 variance=1/100，新几何缺陷=0，真实R=1/50。它消除了对父间标记正则性的要求。但新cross也变了，不能保旧mean而只免费替换旧variance。未证明root几何cover预算。

## 三阶段真实几何

初步、扩大场使用来源packets中心(-.83,0,.83)、半宽.01，父centerblocks中心(-.4,.4)、长度(.01,.018)，side(1,1.8)，完整capture为{左,中}、{中,右}。初步source质量(3,1,8)；扩大只取(25,144,81)及(1,3,13)，分别提供高重叠与massratio4。两扩大场将中包在0处分成两个正体积source cells，b1为左包+中包左半，b2为中包右半+右包，故b1+b2=1于完整f支撑。

压力equal-capture场：来源包中心±.1、半宽.01、质量各1；两个父centerblocks亦中心±.1、长度.02、side1。不同center/cube均完整捕获全部μ，m=(2,2)，g²=1。a=1、b=1；父0的theta仅留左×左source对，父1仅留右×右，完全不同静态标记。

全部f分块常、正质量L1；中心是实际Lebesgue正体积cell，整块capture/miss严格边距逐项核。各域内部不交，跨域允许相交。其余场a取1或1/4，theta取0、1/4、1的原父依赖source-cell函数；sqrt marks有理，保实际theta(A,y,z)，不赋新父旧history。真实q=m/R及qband、单octave均记录于JSON。原strict-K/highrank/路径/history不认证。

## 正支与交叉项的准确核验

每stage定义e_A=c_A(y)c_A(z)/m_A、v_A²=a_i(A,y)b_i(z)theta_i(A,y,z)。在同组C按σ_B/σ_C平均，逐来源积分核

R=Cross_A-mark+SignedDiff，
Cross_A-mark使用v_A² e_Ae_B，而不是v_Av_B。

实际正部Def_mark=∫v_A²(e_A²−e_Ae_B)_+，SignedDiff≤Def_mark。忽略a theta但保b后，逐(A,B)直接积分得到

D_i(A,B)=μ_bi(QA)/m_A−I_AB J_AB,i/[m_A max(m_A,m_B)]。

同时核0≤Def_mark≤D_i、cross≤unmarked cross，进而共同cell partition下

R≤Cross_A-mark+Def_mark≤4r·cover_source_mass+Σ_i grouped D_i。

两stage b分割完整μ，所以Σ_iD_i=δ(A,B)=1−I_AB²/[m_A max(m_A,m_B)]。这是静态几何替换，不是原stage合法性认证。每场还核R≤X及同组/分组原R不变。

## 对称改进1.5

精确对称费用δbar=(δAB+δBA)/2。令t=min(m_A,m_B)/max(m_A,m_B)、s=g²≤t，则

δbar=1−(1+t)s/2，
(3/2)(1−s)−δbar=[(1−t)²+(t−s)(2−t)]/2≥0。

因此同组对称σ_Aσ_B权下，精确δ费用等于δbar费用，且≤(3/2)∫grouped(1−g²)，强于方向性2系数。全部pair均精确核验，含same-parent零项。

## 实际对照（两父同组）

| 场 | m | 原R | R472 variance | 新marked正部 | 无标记几何费用=δbar费用 |
|---|---|---|---|---|---|
| 初步低重叠 | 4,9 | 2143/57600 | 15079/748800 | 5053/249600 | 127/2340 |
| distinct centers equal capture | 2,2 | 1/50 | 1/100 | 0 | 0 |
| 高重叠两stage | 169,225 | 886007/845000 | 130675383/332930000 | 95753223/332930000 | 496737/492500 |
| massratio4两stage | 4,16 | 3409/102400 | 6373/512000 | 1501/128000 | 467/8000 |

equal-capture场新cross恰R=1/50，而旧mean=1/100；新缺陷零不代表R零。其作用是允许按几何捕获聚类而不要求历史标记接近。

其他场的新marked正部未必小于旧variance，去标记后的几何价也可能更大；没有提出无条件数值优越性。各父分开时新缺陷均0，但cover会重复同一来源。故仍须同时控制真实共同来源重复与几何距离，不能只看几何缺陷。

## 同场追加：真实共同来源分数代表核

未另建几何。对真实source cells精确算

D_x=Σ_Aσ_A c_A(x)/m_A，
P_AB=σ_BΣ_x μ_x c_A(x)c_B(x)/(m_A m_B D_x)。

逐行Σ_BP=1，逐pair σ_AP_AB=σ_BP_BA。平方权总价直接按原定义积分，精确消去为B(w)=Σ_{D_x>0}μ_x；本四场所有source均被捕获，故B(w)=W，未产生stage数或hard-cover重复因子。

保持同一原父a/theta，计算C_P=Σσ_AP_AB∫v_A²e_Ae_B及E_P=Σσ_AP_AB∫v_A²(e_A²−e_Ae_B)_+。独立核positive-defect retention式

E_P=Σσ_A∫v_A²e_A²[1−Σ_BP_AB min(1,m_A/m_B)c_B(y)c_B(z)]。

所有场精确满足R=C_P+signed、R≤C_P+E_P、C_P≤4rW（此处S=1）。

| 场 | B(w)=W | C_P | E_P/R |
|---|---:|---|---|
| 初步低重叠 | 12 | 139217/4147200 | 5053/51432 |
| equal capture | 2 | 1/50 | 0 |
| 高重叠两stage | 250 | 3004610111/3570125000 | 766025784/3743379575 |
| massratio4两stage | 17 | 91481/3276800 | 4503/27272 |

P在equal-capture场为全1/2，故代表父实际改变而新缺陷仍零；其他P与完整cost均存JSON。这说明来源重复价可精确付一次W，仍不能把四个有限E/R值当成原accepted流的统一吸收率。原门下E_P可吸收仍未认证。

## 执行及scope

964项精确断言，包括大量rational-square sanity、geometry、逐pair/source正支与分组身份；不是964样本。只有4个连续场、每场同组/分组两partition，最多两stage；未扩参数扫描。Fraction处理全部积分，连续source-cell与center-cell上的核恒定，有限求和是整块真实积分，非中心点近似。未调用float solver或Monte Carlo。

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r473_numeric.py
```

Python3.12.14，标准库Fraction，数学判定无浮点误差；运行秒数仅元数据。JSON含全部真实区间、严格边距、a/b/theta、方向性D、δbar及两个partition的完整账目；输入自含、输出脚本同目录。

冻结白名单：r473_numeric.py、r473_numeric.json、r473_numeric.md。完成停止。共同来源fractional方案已在同四场追加；原历史、一般接受缺陷吸收及root付款仍未认证。
