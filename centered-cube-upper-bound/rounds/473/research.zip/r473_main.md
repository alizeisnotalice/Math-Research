# 第473轮：保持原父接受权的几何替换与共同来源代表计划

## 结果及其限制

本轮修复第472轮接口中的一个不必要困难：无需比较两个父的历史标记。交叉替换时始终保留原父的标记，只替换捕获核；正误差可按真实来源上的捕获亏损估计。进一步实际构造共同来源的分数分组，其交叉总价为 \(4rSW\)，无需先证明一个低重数硬分割存在。按完整对数质量带限制代表父时，交叉价为根阶来源价。

**仍未完成一般根阶上界。** 便宜交叉项的上界不提供对原费用的恢复下界。原 high-Z/low-common 门能控制部分极端质量代表的恢复上界，不能据此认证质量可比部分有足够恢复。本轮把后续几何攻坚集中到这个准确原接受测度下的恢复问题，避免继续要求任意父间历史权的正则性。

## 1. 同一原输入与已证明工具

\(\mu=f\,dx\)、\(f\ge0\)、\(W=\mu(\mathbb R^n)<\infty\)。实际 Lebesgue 中心 \(A\in E\)，单值边长 \(a\le R_A\le b\le2a\)、\(a>0\)，\(Q_A\) 为中心立方体，\(c_A=1_{Q_A}\)，\(m_A=\mu(Q_A)=q_AR_A^n\)、\(q\le q_A\le\lambda\)，\(r=\lambda/q\)、\(\sigma=q_A dA\)、\(X=\sigma(E)\)，\(\pi_A=c_A\mu/m_A\)。真实阶段密度满足
\[
 0\le a_i^e(A,y)\le B_e,\quad\sum_eB_e=S=\beta+C_{\rm col},\quad
 b_i=(\delta g_i/f)(1-s/D_i)_+,\quad\sum_i b_i(z)\le1.
\]
\(D_i\) 为原阶段占用，勿与下文新符号 \(D(x)\) 混同。原接受条件平均 \(\theta_i^e\in[0,1]\) 保全部原路径、early、soft、严格初始质量及当前门。写
\[
 e_A(y,z)=c_A(y)c_A(z)/m_A,\quad
 v_{i,e,A}^2(y,z)=a_i^e(A,y)b_i(z)\theta_i^e(A,y,z),\quad
 R=\sum_{i,e}\int\sigma(dA)\int e_A^2v_{i,e,A}^2\,d\mu^2. \tag{1}
\]
对当前任何正保留原流也可如此表示；不把静态支配当作原历史定义。

已证真实质量 CDF \(F_x(t)=|\{B:x\in Q_B,m_B\le t\}|\le t/q\)。第472轮给
\[
 I_{AB}=\mu(Q_A\cap Q_B),\quad J_{AB,i}=\int c_Ac_B b_i\,d\mu,\quad
 H_i(A,B)=\frac{I_{AB}J_{AB,i}}{(m_Am_B)^{3/2}},\quad
 \int H_i(A,B)\sigma(dB)\le4r\pi_A(b_i). \tag{2}
\]
该核对称，故对任意 \(g\) 有
\(\iint g(A)g(B)H_i\,d\sigma^2\le4r\int|g|^2\pi_A(b_i)d\sigma\)，对复数按绝对值处理。

## 2. 原父标记保持不动，几何正缺陷的准确公式

给定任意代表父 \(B\)，准确的有符号分解为
\[
 e_A^2v_A^2=e_Ae_Bv_A^2+(e_A^2-e_Ae_B)v_A^2. \tag{3}
\]
右侧始终使用 \(v_A\)，没有 \(v_B\)。对于每个阶段，
\[
 \mathfrak d_i(A,B):=\int b_i(z)(e_A^2-e_Ae_B)_+d\mu^2
 =\frac{\mu_{b_i}(Q_A)}{m_A}
 -\frac{I_{AB}J_{AB,i}}{m_A\max(m_A,m_B)}. \tag{4}
\]
证明：在 \((Q_A\cap Q_B)^2\) 上系数为 \(m_A^{-2}-(m_Am_B)^{-1}\)，在其余 \(Q_A^2\) 上为 \(m_A^{-2}\)。分 \(m_B\ge m_A\) 与 \(m_B<m_A\) 两种情形取正支，直接得到 (4)。这对任意集中 \(f\) 成立；边界的体积从未替代边界来源质量。

若每个 \((i,e)\) 使用 \(\sigma\)-可测中心分割 \(\mathcal C_{i,e}\)，在同块内按 \(\sigma(B)/\sigma(C)\) 平均 (3)，然后仅正上放 \(a_i^e\theta_i^e\le B_e\)，由 (2) 得
\[
 R\le4r\mathcal B+\sum_{i,e}B_e\sum_{C\in\mathcal C_{i,e}}
 \frac1{\sigma(C)}\int_{C^2}\mathfrak d_i(A,B)\,d\sigma(A)d\sigma(B), \tag{5}
\]
\(\mathcal B=\int\sum_{i,e}B_e b_i(x)N_{i,e}(x)d\mu(x)\)，
\(N_{i,e}(x)=\sum_C\sigma(C)^{-1}\int_Cc_A(x)d\sigma(A)\)。实际带标记的正缺陷比 (5) 的外放松更小，研究时可保留它。

对所有阶段共用的分割，合并同一来源上的 \(b_i\)，令
\[
 g_{AB}^2=I_{AB}^2/(m_Am_B),\qquad
 \delta(A,B)=1-\frac{I_{AB}^2}{m_A\max(m_A,m_B)}.
\]
\(0\le g^2\le\rho:=\min(m_A,m_B)/\max(m_A,m_B)\le1\)，且
\[
 \frac{\delta(A,B)+\delta(B,A)}2
 =1-\frac{g^2(1+\rho)}2
 \le(1-g^2)(1+g^2/2)\le\tfrac32(1-g^2). \tag{6}
\]
因此 (5) 的误差不超过 \(\frac32 S\sum_C\sigma(C)^{-1}\int_{C^2}(1-g^2)d\sigma^2\)。这消除了第472轮的跨父标记方差要求，但尚未构造足够便宜且几何亏损小的硬分割。

## 3. 共同来源给出真实、可付的分数分组

无需先寻找硬分割。取实际来源 \(x\) 为组指标，
\[
 D(x)=\int_E\frac{c_A(x)}{m_A}\sigma(dA),\qquad
 P(A,dB)=\int\pi_A(dx)\frac{c_B(x)\sigma(dB)}{m_BD(x)}. \tag{7}
\]
零分母处置零；由 Tonelli，零分母集合对 \(\sigma(dA)\pi_A(dx)\) 零测。\(P1=1\) 对 \(\sigma\)-a.e. \(A\) 成立，\(\sigma(dA)P(A,dB)\) 对称。\(x\) 仅是辅助抽样，不获任何旧历史。

定义交叉项及实际正缺陷
\[
 C_P=\sum_{i,e}\int\sigma(dA)P(A,dB)\int v_{i,e,A}^2e_Ae_Bd\mu^2,
\]
\[
 E_P=\int d\Pi(A,y,z)
 \left[1-\int P(A,dB)\min(1,m_A/m_B)c_B(y)c_B(z)\right], \tag{8}
\]
其中 \(d\Pi=\sum_{i,e}\sigma(dA)e_A^2v_{i,e,A}^2d\mu^2\) 为同一个原接受推前测度。则
\[
 R\le C_P+E_P,\qquad C_P\le4rSW. \tag{9}
\]
费用证明不隐藏组数：以一般指标权 \(w_\xi(A)\ge0\)、\(\int w_\xi(A)d\lambda_0(\xi)=1\)，记 \(d_\xi=\int w_\xi d\sigma\)。对 \(g(A)=w_\xi(A)\sqrt{m_A}\) 应用 (2)，再在同一来源上合并阶段，交叉价至多
\[
 4rS\int\frac{\int w_\xi(A)^2m_A\,d\sigma(A)}{d_\xi}d\lambda_0(\xi).
\]
对 (7)，\(w_x(A)=c_A(x)/m_A\)、\(d\lambda_0=d\mu\)，该积分准确为 \(\mu\{D>0\}\le W\)，因为 \(c_A^2=c_A\)。这是实际构造，不是另加未证分组存在性条件。

如需代表质量可比，把完整区间 \([qa^n,\lambda b^n]\) 划分为对数宽至多 \(\ell\) 的带 \(J_j\)，使用 \(w_{j,x}=1_{m_A\in J_j}c_A(x)/m_A\)。每个父保留唯一质量带，所有带均纳入；零长度区间取一带。总数
\[
 N\le1+\frac{\log r+n\log(b/a)}\ell,
 \qquad C_{P_{\rm band}}\le4rSNW. \tag{10}
\]
\(\ell=\sqrt n\) 时，固定 \(r\)、单比例带内交叉项是根阶来源价；没有依赖维数猜测或遗漏极端质量的补集。其实际缺陷仍是 (8) 换该核，尚未证明可吸收。

## 4. 原门对恢复方向的限制

(9) 并不意味着 \(R\) 有一次来源价。它只表明恢复量 \(C_P\) 便宜；未知的是同一原接受流中 \(E_P\) 是否可吸收。充分条件为
\[
 E_P\le\eta R+\varepsilon X+C_\varepsilon\sqrt n\log^A(n+2)W,
 \qquad\eta<1, \tag{11}
\]
或对应的实际有符号恢复下界；(11) 没有证明。

几何附件对未分带计划给出原门的准确作用。原 \(K=e^{\sqrt n}\)，\(h=s/(\varepsilon_0q)\)，\(s=1+\sqrt n\)，原 \(C_A(y,z)=\int_{m_B<m_A/K}c_B(y)c_B(z)dB/m_B<h\)。将原记录另附 \(x\sim\pi_A\) 后，\(D(x)\le d\) 部分的实际费用至多 \(SdW\)。这不是刷新 \(y,z\) 或历史，也不是可以二次使用的旧信用。

在 \(D(x)>d\) 的交叉恢复中，每条原记录的严格小质量代表 \(m_B<m_A/K\) 恢复系数至多 \(\lambda C_A(y,z)/d<\lambda h/d\)。大质量代表 \(m_B>K m_A\) 系数至多 \(2r/(dK)\)。前者用实际交集质量 \(I_{AB}\le m_B\)，后者用 \(I_{AB}\le m_A\) 和真实质量 CDF 的平方尾。质量端点不丢失；\([m_A/K,Km_A]\) 为保留的完整中间范围。

取 \(d\) 为固定倍数 \(\lambda h\)，低 \(D\) 来源标签费为根阶 \(SdW\)。但两个极端范围的结论都是**恢复上界**：不能把它们从原 \(R\) 中当作已付费用扣走，也不能推出中间范围恢复下界。若用 (10) 且 \(\ell\le\log K\)，原 high-Z/low-C 见证所在严格小质量域甚至不在该代表带内；必须建立新的共同来源几何桥，而不能直接借原门作正恢复保证。

## 5. 完整费用账与后续唯一目标

本轮已证 (3)–(10) 及上述极端代表恢复上界；未证明 (11)。原完整入口的所有宽距离、低pe、初始、删除跳跃、未来被删来源、极端尺度比和全尺度拼接仍按旧账保留。第458轮恢复系数 \(S\zeta+2S\varepsilon_0/s+2S\delta_{\rm round}\) 及其余全局母账乘数没有被修改；尚无新增已确认可吸收系数。

下一步集中于原接受测度上、质量可比共同来源代表的几何恢复或其真实可求和递推。没有恢复下界之前，不以 (10) 的根阶交叉价格替代整个原积分。主证明与审计均保持这一量词区别。

## 6. 本机计算、技能与证据边界

采用指定独立 Python。主代理147项精确代数核验检查正支质量分母和对称常数；数值附件使用真实正 Lebesgue 中心块与完整来源，直接积分原父标记保持式，包含相同来源捕获但标记完全不同的压力情形。辅助分数分组的有限代数检查验证行守恒、可逆性与平方权消去。精确核验和区间比较分别记录，所有有限模型均不认证原 strict-gap/early/clock 历史，也不外推一般维数或未知恢复下界。

已读取64项数学工具中的 M03 近极值稳定性技能及方法/课题边界：只用其明确亏损、量词和常数的审核流程，未调用任何通用稳定性定理。G03 私有捕获树映射未定义，不从其名称导入几何定理。L03 精确证书工作流沿用。计算只为区分本轮替换策略的合法性与费用，不进行无关扫描；不编译PDF。最终脚本、stdout及独审绑定随精简归档保存。

主代理实际复现代码：

```python
from fractions import Fraction as F
import sympy as s
checks=0
x,t=s.symbols('x t',nonnegative=True)
bar=1-x*(1+t)/2
assert s.expand(s.Rational(3,2)*(1-x)-bar)==(1-2*x+x*t)/2;checks+=1
assert s.expand((1-2*x+x*t)-((1-x)**2+x*(t-x)))==0;checks+=1
# All realisable three-region masses: intersection plus two exclusive parts.
for common in [F(1,100),F(1),F(100)]:
 for left in [F(0),F(1,100),F(1),F(10)]:
  for right in [F(0),F(1,100),F(1),F(10)]:
   ma=common+left;mb=common+right;g=common**2/(ma*mb)
   da=1-common**2/(ma*max(ma,mb));db=1-common**2/(mb*max(ma,mb))
   rho=min(ma,mb)/max(ma,mb)
   assert (da+db)/2==1-g*(1+rho)/2;checks+=1
   assert (da+db)/2<=F(3,2)*(1-g);checks+=1
   # Actual positive part of density difference in AA-square.
   direct=(ma**2-common**2)/ma**2+common**2*max(F(0),1/ma**2-1/(ma*mb))
   assert da==direct;checks+=1
# Limit sharpness of symmetric estimate, nested nearly equal masses.
h=s.symbols('h',positive=True)
g=1/(1+h)
expr=(1-g*(1+g)/2)/(1-g)
assert s.limit(expr,h,0,dir='+')==s.Rational(3,2);checks+=1
print('PASS',checks,'exact positive-part/symmetric-defect checks; finite mass triples not original-history models')
```
