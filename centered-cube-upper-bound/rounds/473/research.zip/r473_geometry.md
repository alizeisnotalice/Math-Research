# R473 几何附件：原 low-common 门对交叉恢复的实际作用

## 1. 同一原流与合法比较

沿冻结合同，记 \(\mu=f\,dx\)、\(\sigma(dA)=q_A\,dA\)、\(r=\lambda/q\)、\(K=e^{\sqrt n}\)、\(s=1+\sqrt n\)、\(h=s/(\epsilon _0q)\)。以下 \(P\) 是完整原接受流，含 stage、旧来源 \(y\)、新来源 \(z\) 及所有历史，\(R=|P|\)，其 \((A,y,z)\) 投影不超过 \(S\sigma(dA)\pi_A(dy)\pi_A(dz)\)。原记录满足
\[
 C_A(y,z)=\int_{m_B<m_A/K}c_B(y)c_B(z)\,\frac{dB}{m_B}<h.
\tag{1}
\]

本轮交叉替换式方向正确。保原父的全部标记，只替换 \(e_A^2\) 为 \(e_Ae_B\)，其中 \(e_A=c_A(y)c_A(z)/m_A\)。单 stage 正差恰为
\[
 D_i(A,B)=\beta_i(A)-\frac{I_{AB}J_{AB,i}}{m_A\max(m_A,m_B)}.
\tag{2}
\]
这是在共同捕获域和其补集分别积分得到的；不需要新父 \(B\) 有原历史。交换 \(A,B\) 后，共享分割几何损失的系数可取 \(3/2\)：令 \(g^2=I_{AB}^2/(m_Am_B)\)、\(\rho=\min(m_A,m_B)/\max(m_A,m_B)\)，则
\[
 \overline\delta=1-\tfrac12g^2(1+\rho)\le\tfrac32(1-g^2),
\tag{3}
\]
因为 \(g^2\le\rho\le1\)。这只校正几何比较，不构造廉价分割。

## 2. 保原标签的人工来源扩展与极端质量恢复上界

定义真实占用
\[
 D(x)=\int\frac{c_B(x)}{m_B}\,\sigma(dB),\qquad
 R_x(dB)=\frac{c_B(x)\sigma(dB)}{m_BD(x)}.
\]
在 \(D(x)>0\) 上 \(R_x\) 是概率核。于每个原记录之后独立附 \(x\sim\pi_A\)，仅用于分析；不给 \(x\) 或 \(B\) 原历史。对任意 \(d>0\)，实际正子流
\[
 R_{\rm low}(d)=\int P(d\xi)\,\pi_A\{D\le d\}\le SdW.
\tag{4}
\]
证明是先用原静态支配、再 Tonelli：来源 \(x\) 的边缘不超过 \(S D(x)\mu(dx)\)。零占用没有正费用。

在 \(D(x)>d\) 上定义比较恢复（原父标记完全不变）
\[
 Q_d(\mathcal M)=\int P(d\xi)\int\pi_A(dx)1_{D(x)>d}
 \int R_x(dB)1_{\mathcal M(A,B)}\frac{m_A}{m_B}c_B(y)c_B(z).
\tag{5}
\]
固定一条原记录，其被积恢复密度精确等于
\[
 \int_{\mathcal M}\frac{\sigma(dB)}{m_B^2}c_B(y)c_B(z)
       \int_{Q_A\cap Q_B}\frac{1_{D(x)>d}}{D(x)}\,d\mu(x).
\tag{6}
\]
不能在此把 \(y,z\) 刷新为 \(B\) 的后验。

**原门比较。** 对 \(\mathcal M_- =\{m_B<m_A/K\}\)、\(\mathcal M_+=\{m_B>Km_A\}\)，
\[
 Q_d(\mathcal M_-)\le\frac{\lambda h}{d}R,\qquad
 Q_d(\mathcal M_+)\le\frac{2r}{dK}R.
\tag{7}
\]
第一式用内积分 \(\le I_{AB}/d\le m_B/d\)、\(\sigma\le\lambda dB\)，逐原记录得到 \(\lambda C_A(y,z)/d\)，然后用 (1)。第二式用 \(I_{AB}\le m_A\)，只删除 \(c_B(z)\)，并用真实中心质量 CDF
\[
 F_y(t)=|\{B:y\in Q_B,m_B\le t\}|\le t/q,
 \qquad\int_{m_B>M}\frac{c_B(y)}{m_B^2}\,dB\le\frac2{qM}.
\tag{8}
\]
(8) 由 \(m^{-2}=\int_m^\infty2t^{-3}dt\) 及 Tonelli 得出；严格质量切割、质量原子均合法。取 \(M=Km_A\) 即得 (7)。没有用体积限制来源密度。

例如取 \(d=8\lambda h=8rs/\epsilon _0\)，则
\[
 R_{\rm low}\le\frac{8Sr}{\epsilon _0}sW,
 \quad Q_d(\mathcal M_-\cup\mathcal M_+)
 \le\left(\frac18+\frac{\epsilon _0}{4sK}\right)R.
\tag{9}
\]
这保留全部参数，且低占用收费是同一原流的正分拆；若主账已有相同支，不能重复收费。式 (7)–(9) 是**交叉恢复量上界**，绝不可从原 \(R\) 中扣除。

## 3. 决定性缺口及本轮范围

这里原 strict-mass/low-common 的实质作用已经进入 (6)：它使极端比较父能提供的恢复量有限，而不是保证多数原流被恢复。剩下的具体几何问题是：在原接受记录及真实 \(x\)-后验下，质量可比区
\(m_A/K\le m_B\le Km_A\) 是否具有足够共同捕获与合适归一质量，使 (5) 恢复原高占用费用，或使其**带原标记**的正差可付。

现有高 \(Z\)、低共同捕获只约束旧 \(y,z\) 的小质量见证，并未给人工 \(x\) 的上述可比质量恢复下界。原父与比较父接近亦不能凭此删除接受权；这里没有再引入父间标记差。一般 Bayes 交叉项已有 \(4rSW\) 价（由 R471 Schur 应用于 \(c_A(x)/\sqrt{m_A}\)，再积分 \(x\)），但缺少从原质量到该交叉项的恢复估计。故本附件不宣称完整根阶预算，不把未控 metric cover 或新的缺额名称当进展。

## 4. 自含有限精确检查

下列本机 Fraction 检查采用三个非均匀完整来源 packet（中心 \(-4/5,0,4/5\)，边长 \(1/50\)）和三个正 Lebesgue 中心块（中心 \(0,-2/5,2/5\)，边长 \(1/100\)），选定 cube 边长为 \(2,1,1\)。所有捕获在块上恒定，故代码中的积分是实际连续块积分。\(K=2\) 只是辅助质量切割阈值；一般解析证明用原 \(e^{\sqrt n}\)。检查不认证原高秩、时钟或全部历史；只核原生中心平方尾和 (6)–(7) 的代数、(3) 系数。不会据此声称原接受流非空。

```python
from fractions import Fraction as F
checks=0
vol=F(1,100)
caps=((1,1,1),(1,1,0),(0,1,1))
sides=(F(2),F(1),F(1))
for mu in ((F(1),F(2),F(8)),(F(3),F(1),F(8)),(F(1),F(4),F(2))):
    m=[sum(mu[x]*caps[a][x] for x in range(3)) for a in range(3)]
    qa=[m[a]/sides[a] for a in range(3)]
    q,lam=min(qa),max(qa)
    sig=[qa[a]*vol for a in range(3)]
    D=[sum(sig[a]*caps[a][x]/m[a] for a in range(3)) for x in range(3)]
    K=F(2)
    for d in (min(D)/2,min(D),max(D)):
        for a in range(3):
            for y in range(3):
                for z in range(3):
                    if not caps[a][y]*caps[a][z]: continue
                    vals=[]
                    for b in range(3):
                        ix=sum(mu[x]*caps[a][x]*caps[b][x]/D[x]
                               for x in range(3) if D[x]>d)
                        vals.append(sig[b]*caps[b][y]*caps[b][z]*ix/m[b]**2)
                    small=sum(vals[b] for b in range(3) if m[b]<m[a]/K)
                    common=sum(vol*caps[b][y]*caps[b][z]/m[b]
                               for b in range(3) if m[b]<m[a]/K)
                    large=sum(vals[b] for b in range(3) if m[b]>K*m[a])
                    assert small<=lam*common/d;checks+=1
                    assert large<=2*lam/(q*d*K);checks+=1
        for a in range(3):
            for b in range(3):
                I=sum(mu[x]*caps[a][x]*caps[b][x] for x in range(3))
                g2=I*I/(m[a]*m[b]);rho=min(m[a],m[b])/max(m[a],m[b])
                db=1-g2*(1+rho)/2
                assert db<=F(3,2)*(1-g2);checks+=1
print('PASS',checks,'Fraction native-block static-interface assertions; no full-history claim')
```

实际运行输出：

```text
PASS 387 Fraction native-block static-interface assertions; no full-history claim
```
