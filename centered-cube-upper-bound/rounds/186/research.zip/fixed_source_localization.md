# R186：固定原时钟的正流量参考、线性来源质量与重叠整片付款

本稿用原 fixed-(j,y,t) posterior 构造一个真正不依 receiver x 的正流量参考，代替 R185 MA 的全父 product/M² 参考。其质量以实际 j/time 总长及 score 的 n/4 上界支付，不出现 M/e 的点态放大。积分 bad 源后仍是固定相关 pair 参考，所有 receiver/terminal/bad/alpha/history 门留在显式密度中。由原 good 关系可不再附加旧 B 小条件，直接支付一整片终端重叠 w_g≥delta 的原正交通。soft 参数尾、极小重叠尾仍未付，一般根阶目标未闭合。

## FL1. 真正固定的原对象与窄来源定位

固定同一个原 (omega,V,a,b,q)，a≤b≤2a，q 是原共同阈值。beta_V、nu_V 分别受共同父 A_V 支配，不假定彼此支配。原不交叶来源账为

    Wbeta=E_omega Σ_V||beta_V||≤WA≤||f||1.

没有每叶 lambda b^n 帽，也没有给独立重复窗口免费重用 WA。以下任何跨窗口结算按原总账求和。

令 gamma=1+1/n，c_j=gamma^(−j)，tau_j=a/c_j。固定 (omega,V,j,y,t) 时，

    Z_j,y,t=D_V(y)∩(T0(y)\A_j,t(y)),
    w_j,y,t(z)=∏_i min(1,b C(|y_i−z_i|/b)/(c_jt)),
    e_j,y,t=∫_Zj,y,t w_j,y,t(z)nu_V(dz),
    Pi_j,y,t(dz)=1_Zj,y,t(z)w_j,y,t(z)nu_V(dz)/e_j,y,t.

e_t=0 时取零核；其余 Pi 是概率。原 C=h*max(h,phi)，h=1_[−1/2,1/2]、phi=h*w，均按冻结原定义。

这里的 x 独立性是实际原合同，不是新选择假设：R128 research.zip::proof.md RT4 后第648–650行明确说 fixed-(omega,V,j,y,t) 的 nu,Z_t,w_t,e_t,Pi_t 在接收点前构造；同文第837行和 RT22 实际使用该事实。R117 research.zip::proof.md JG1 给 Z/w/e，JG2 第45–52行给实际物理窗

    tau_j≤t≤b c_j.                                      (FL1)

JG2 还给 receiver 前固定的 heavy 初始区间 I_j,V,y；这里可以正扩大到整个 FL1 窗。保留 fixed q 与原森林，不能在 x 变化时重构它们。

相反，current s(x),L(x)、g、w_g、terminal A、alpha、rho、good/bad、high、FA 与所有历史门不固定；它们全部保留在后述 receiver 密度。特别 Pi_g 不是本稿 fixed-time 参考。已审 R181 common_parent_budget 及 R185 JP1/MA4 的来源链提供共同父预算，不能替代上述精确 fixed-time 条款。

## FL2. 精确 j/time 费用，不能免费删除 j

写 hwin=log(b/a)∈[0,log2]、c=log gamma>0。FL1 非零长度须 c_j²>a/b。包含零长度端点而不影响 dt/t，令

    Jmax=floor[hwin/(2c)],
    T_n(a,b)=Σ_(j≥0) log_+(b c_j²/a)
            =(Jmax+1)hwin−c Jmax(Jmax+1).               (FL2)

hwin=0 时 T_n=0，全部相关 dt/t 交通为零，后面不除 T_n。非零范围有

    T_n≤hwin+hwin²/(4log gamma)
       ≤log2+(n+1)log²2/4.                              (FL3)

证明对递减三角函数 (hwin−2ct)_+ 用首项加积分上界，并用 log(1+1/n)≥1/(n+1)。这是实际 O(n) clock/reference 费用，不是免费的唯一-j 取消。实际唯一 j(x) 一直保留；正扩大后不同 j 的参考测度不同，所以最终真实付 FL2 的和。

## FL3. canonical fixed 正 score 耦合

辅助 score 为 k_j,y,t(z)=#{i:b C(|y_i−z_i|/b)<c_jt}∈[0,n]。闭阈值采用原版本，孤立时间点对 dt/t 无影响。定义

    d_j,y,t(v,u)=[k_j,y,t(v)−k_j,y,t(u)]_+.

它与 Pi_j,y,t 一样，在固定 j,y,t 后不依 x。对 Pi 的任意实际 score 分布，Tonelli 给

    ∬d(v,u)Pi(dv)Pi(du)
      =∫_0^n Pi{k>r}Pi{k≤r}dr≤n/4.                     (FL4)

这是原两个 posterior 槽的真实 product，不是假定来源坐标独立，也没有假定分布接近 Bernoulli。e_t=0 的零核仍满足此上界。

现在不优化、不选择新的耦合，而取原全正 score 流量本身作为固定参考：

    Gamma_V^+(dj,dt,dy,dv,du)
      =Σ_j1_[tau_j,bc_j](t) dt/t beta_V(dy)
            d_j,y,t(v,u)Pi_j,y,t(dv)Pi_j,y,t(du).         (FL5)

它可以有相关的 y,u,v；它的每个定义参数都在 x 前固定。原 masked 流量仅在此测度下乘原0到1门，所以实际受其正支配。FL2–4 给有限质量

    ||Gamma_V^+||≤L_V||beta_V||,
    L_V=(n/4)T_n(a_V,b_V),
    Tstar=sup_(omega,V) T_n(a_V,b_V),   L_n=(n/4)Tstar,
    EΣ_V||Gamma_V^+||≤L_n Wbeta≤L_n WA.                 (FL6)

共同窗时 Tstar=T_n(a,b)。若原同一来源族的窗随 V/omega 变，所有后续全局显示中的 L_n 都指这个确定的 supremum 版本，绝不把单窗 T_n 从 EΣ_V 直接提出。FL3 的统一上界也控制 Tstar。没有 M_V/e_t、nu 总质量比或森林节点数的附加系数。参考的质量已经真实支付 O(n²) 的 score-clock 因子 L_n；不能把它写成1。

## FL4. 积分 bad-u 后的固定 pair 参考

令

    h_j,y,t(v)=∫d_j,y,t(v,u)Pi_j,y,t(du),
    Gamma_V,pair^+(dj,dt,dy,dv)
       =Σ_j1_[tau_j,bc_j](t) dt/t beta_V(dy)
                 h_j,y,t(v)Pi_j,y,t(dv).                (FL7)

这是 FL5 的精确 u 边缘，仍不依 x，质量相同。取原 H_x(j,t,y,v,u)∈[0,1]，包含唯一1_{j(x)=j}、actual far/heavy、接收/high、reciprocal bad-u、seed/history、旧已付集合补集以及其他原分数门；不要把原 A 重复放进 H。定义 h>0 时

    chi_x(j,t,y,v)
      =∫d(v,u)H_x(j,t,y,v,u)Pi(du)/h_j,y,t(v)∈[0,1],

h=0 时 chi=0。分子对 u 的积分发生在同一固定 Pi；没有把原 bad 子域归一为概率，也没有把 chi 声称为固定来源。alpha、rho、terminal 及 bad 的 x 依赖全在 A 或 chi 中。零 e/h 时先分支，不造0/0。

## FL5. 原 capped raw 的精确固定参考分解

保留原 current p_y=P_s(x),L(x)(x−y)、固定 J_v=P_(1,b)(x−v)、terminal

    A_y(v)=1_good rho_v J_v/(3Q_v),
    Q_v=(p_v+pplus_v+J_v)/3,
    0≤A≤1,  supp A⊂Z_g.

原 source-hard 因子已经只用一次16/3帽；原外2Lambda也只用一次。令 Raw_capped 指该正帽上界，原正 raw≤它。严格软有效核 p_y,J_v 正，零交通先延拓为零，则有代数恒等式

    Raw_capped
      =(32Lambda/3)EΣ_V∫dx∫sqrt[p_y J_v]
                  D_x(j,t,y,v)dGamma_V,pair^+,
    D_x=A_y(v)sqrt[p_y/J_v] chi_x(j,t,y,v).              (FL8)

证明在 FL7 中消去 h 与 chi 的分母，再用 sqrt(p_yJ_v)sqrt(p_y/J_v)=p_y，恰恢复原全部 u,v posterior、score、A、H 与 dt/t。保留1_j在 chi 中，绝未以固定 Gamma 替代 x-dependent posterior selection。无 receiver 密度被吸收成来源测度，dx 仍是原 Lebesgue 接收积分。

相较 R185 MA 的 beta⊗nu⊗nu/M² 参考，FL5 对其点态 RN 密度确可很大，但它的**总质量**已由 FL4–6 支付。归一化 e_t 全部留在原 fixed Pi 里面，故 FL8 的显式密度没有 M²/e_t²。这个消除并非声称 e_t≈M，而是改变合法积分次序及固定参考后使用其真实质量。原 R128 RT22 在 s=0 边界扩展中已采用 fixed-time Pi 的 Tonelli 思路；当时相应 actual 子支为空。本文新付款来自把它接到 R185 mixed full-selector affinity 和下文实际 good-overlap 几何，不把历史固定性首创化。

## FL6. 原 good 给可检验的整片几何控制

记 w_v=w_g(y,v)，r_v=(p_v+pplus_v)/J_v≥0。active good target 有 A= rho_v/(1+r_v)，且原 good 是

    p_y w_v≤KQ_v=KJ_v(1+r_v)/3,     K=1 actual.

因此逐点

    A sqrt(p_y/J_v)
      ≤rho_v sqrt[K/(3w_v(1+r_v))]
      ≤sqrt[K/(3w_v)],
    0≤D_x≤sqrt[K/(3w_v)].                               (FL9)

这一步保持同一 x,y,v 与同一 alpha/rho；不使用 bad-u 的大重叠来替代 good-v 的小重叠。FL9 已把完整 posterior score 流量与源质量比移入固定 Gamma 的付费质量，只剩真实 kernel/good 几何。

## FL7. 全 adaptive 混核预算及真实整片付款

固定0<sbar<1。R185 MA 已审的 mixed kernel 包络对任意 fixed y,v 给

    ∫sup_(0≤s≤sbar,a≤H≤b)
           sqrt[P_s,H(x−y)J_b(x−v)]dx≤A_n(sbar),
    A_n(sbar)=e(n+1)(1+(n/2)log2)a(sbar)^n,
    a(s)=sqrt[r_s tau_phi]+sqrt[(1−r_s)(1−tau_phi)],
    r_s=1−s+s tau_phi,  tau_phi=∫_[-1/2,1/2]phi<2/3.

这个费用已经包含共同 soft/scale 选择及硬跳，不能再将实际 s,L 固定后免费取 sup。对 fixed Gamma_pair^+ 可合法 Tonelli；j,t 在参考中只作为额外标记，核仍是同一 fixed y,v 的 current/J 核。

取任意0<delta≤1，在此前尚未支付的原正交通上限制

    s(x)≤sbar,       w_g(y,v)≥delta.                     (FL10)

这些门可以加进原 H、故 chi≤1，也可在 FL8 后正切片；两种写法产生同样原交通，不重算 A、Pi、alpha 或旧 mask。在该整片上 FL9 给 D≤sqrt[K/(3delta)]，与 FL6、MA 包络合为

    Raw_original^+[FL10]
      ≤(32Lambda/3) A_n(sbar)L_n sqrt[K/(3delta)] WA.     (FL11)

这是真正的线性来源价，不要求每个原行接近极值、不要求旧 MA 的 B 小，也不要求父质量与后验分母可比。可以同时保留原 high-A、low-Fcal、中央时钟等限制，因为它们只是原正切片。

当 Tstar>0，令

    delta_n=K A_n(sbar)^2 L_n^2/(3n)
            =K n A_n(sbar)^2 Tstar^2/48.              (FL12)

仅在0<delta_n≤1时取 delta=delta_n，得到规范根阶付款

    Raw_original^+[s≤sbar,w_g≥delta_n]
        ≤(32Lambda/3)sqrt(n) WA.                        (FL13)

若 delta_n>1，则这个示例门不提供非空结论，保持一般 FL11，不把 w≤1 改写成满足它。若 Tstar=0/L_n=0，原时钟交通已为零，不能先除 L_n。sbar=0 可用 MA 单独硬核预算，但当前 strictsoft actual 该参数支为空；本文实际付款用0<sbar<1。

另一种合法结算是不取 supremum：逐窗用 L_V 及 delta_(n,V)=K A_n(sbar)^2 L_V^2/(3n)，在各自 0<delta_(n,V)≤1 的片上先取得同一个 sqrt(n)||beta_V|| 根价，再 EΣ_V≤WA。零 L_V 直接无交通；阈值大于1的窗不自动纳入付款。这个逐窗阈值与上面的全局统一 delta_n 是两个不同分割，不能混用其阈值和价格。不同独立重跑窗口仍保留真实来源重用费用。

## FL8. soft-gap 的可用范围，指数阈值不是无费全覆盖

MA4/9 给明确上界

    A_n(sbar)≤e(n+1)^2 exp[−n(1−sbar)^2/18].

令 cT=log2+log²2/4，则 Tstar≤cT(n+1)。FL12 因而满足

    delta_n≤C_K(n+1)^7 exp[−n(1−sbar)^2/9],
    C_K=K e²cT²/48.                                    (FL14)

给定 m>0，若真实参数允许

    n(1−sbar)^2/9≥(m+7)log(n+1)+log_+(C_K),

则 delta_n≤(n+1)^(−m)。若右侧要求1−sbar>1，或与原 strictsoft 下门不相容，该示例范围为空，不能据此登记付款。固定 sbar<1 时，大 n 下该 soft-gap 条件可以检验；sbar趋1时必须保留它的退化。

FL13 因此允许一个可显式很小的 terminal overlap 门，而非只支付常数 w 或要求旧 B 的无价小矩。这个结果仍不证明原剩余交通普遍达到此门，也不认证某个满足全部 FIRST/history/L1 条件的严格新差集。与旧 Fcal 的同阈值物理覆盖不能只由代数阈值比较宣布。

## FL9. 固定来源支撑与分层费用：不以新分组重领父质量

FL5 已保留原 support：对每个 fixed j,t,y，u,v 均在

    D_V(y)∩T0(y),

实际禁块的排除和原 C 重叠权也仍在 Pi 中。因此新参考不是整个父来源的自由 product，而是实际森林和原几何支持上的 canonical 正流量。它未改变原森林，更没有借一个新的随机移位独立性。

若需按 fixed source 距离（例如 ||y−v||_1/b、||u−v||_1/b）划固定半开 annuli，直接以这些指示限制 Gamma^+ 得不交 Gamma_r。它们均不依 x，且 Σ_r||Gamma_r||=||Gamma^+||，不产生额外层数费。若给不同层不同阈值/密度上界，则必须真实支付 Σ_r A_n B_r||Gamma_r||；不能先把每层再归一成一份完整 beta 或逐 receiver 选择最优耦合。

仅用固定几何 carrier N(y)=D_V(y)∩T0(y) 也能定义 m(y)=nu(N(y))、beta(dy)nu|N⊗nu|N/m(y)^2，质量≤||beta||，m=0先零；它覆盖全部原支持，无须每叶帽。然而它仍把 m²/e_t² 留在显式密度中。FL5 的 fixed-time/score 耦合比这个局部 product 更直接地保留原归一化，并用真实 clock-score 质量替代该放大；本文不再对前者单独登记一次来源预算。

## FL10. 首个剩余缺口与原总账

对已付旧集合 O，先从其补集中取 FL10/13，新增来源费只收一次。新参考并未重构 rho/alpha/capture/bad，未消费任何原 signed 负项或已经用过的 suffix。也未删除原 hard/source carrier：只使用原16/3硬帽接口及外2Lambda各一次。独立窗口、seed 与父来源重用继续按原总账列价。

在适用 soft-gap 范围，FL13 后尚未支付的是 s>sbar，或 s≤sbar 但 w_g(y,v)<delta_n 的实际交通及其与 high-A/low-Fcal/central 的交集。这里的 sqrt(1/w_g) 是 FL9 的真实价格，不能从 bad-u reciprocal 的 w_g(y,u)>kappa 推 good-v 重叠大。极小 good 重叠和 normalized original flux 可以同时出现；本稿没有证明其 Gamma 质量小、没有来源独立性，也没有每个 x 的新最优参考。

参考归一化的 M/e 障碍已在本付款中被固定时钟积分次序消除，但得到的是 explicit L_n=O(n²) 来源参考费，再由真实 mixed soft-gap affinity 吸收。它不是一般后验点态上界，也不是说所有大旧 B 已自动满足新几何门。若要处理最后的小重叠尾，仍需把 mixed current/J 的位置衰减、same-alpha 条件和真实 good overlap 联合付款，或另付 soft尾；不能仅重命名旧 B 为另一个密度后宣称闭合。

## FL11. 解析核验范围与停止点

初步检查：e_t=0、h_t(v)=0 时固定参考没有相应质量，chi先零；无score差时 Gamma^+=0，FL8恢复零交通。边界检查：n=1 的极端二点 score 分布给 n/4 取等，支持三角窗的末端零长度不被当作时间原子；a=b 时 T_n=0。delta_n=1 等号合法，delta_n>1 的示例空支保留。扩大检查：任意实际 source score 分布、任意相关 beta/nu 共享父、全部原 j/physical time、全部同窗 adaptive soft/scale 选择均按明确费用处理，没有 source 坐标独立或新shift假设。

本稿不含新的 FULL 数值构造或维数拟合。可用有限 Fraction 检查 FL4 的双和/层糕、FL8 的 h/chi 边缘恒等式和固定参考线性质量；T_n 的精确 sum/闭式可单独检查。一般证明是上述实际源核、正 Tonelli 与已审 mixed affinity 的组合，有限检查不能替代 fixed-time 来源资格。

交付止于实际原整片付款 FL11–13、固定参考/质量证明、精确 j/time费及剩余 small-overlap/soft尾。一般 arbitrary positive L1 的根阶目标保持未完成。
