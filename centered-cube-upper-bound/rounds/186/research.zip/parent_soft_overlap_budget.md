# Parent: explicit soft-gap / overlap geometry

Status: analytic consequence submitted for independent review; not a general closure.

Use the R185 mixed-affinity envelope and the R186 actual fixed positive-score-flow reference, whose mass is at most L_n W_A, L_n=n T_n/4. For n>=1, K>0 and 0<sbar<1 put g=1-sbar. All receiver gates and real dx remain as in the original capped J-share. The branch is the actual geometric set {s<=sbar, w_g(y,v)>=delta}; no posterior amplification cap is imposed.

R185 gives A_n<=e(n+1)^2 exp(-n g^2/18). Since T_n<=log2+(n+1)log(2)^2/4<=n+1, the exact sufficient overlap threshold satisfies

    delta_n = K n A_n^2 T_n^2/48
            <= [K e^2 n(n+1)^6/48] exp(-n g^2/9) =: D_n(g).

The estimate T_n<=n+1 follows from log2/(n+1)+log(2)^2/4 <= log2/2+log(2)^2/4 <1. For T_n=0 the original time integral is zero and no threshold division is used.

Consequently, for every prescribed delta in (0,1], if

    n g^2 >= 9 log(K e^2 n(n+1)^6/(48 delta)),

then the whole above geometric branch has original capped raw <=(32 Lambda/3) sqrt(n) W_A. This is sufficient, not necessary; if the logarithm is negative the displayed condition is automatically satisfied for positive g. The exact threshold can be used instead of this deliberately coarse envelope.

For fixed K and p>=0, taking delta=n^(-p), the sufficient right side equals 9[(p+7)log n + 6log(1+1/n)+log(K e^2/48)]. Thus a soft gap with n g^2 exceeding this explicit expression pays the entire polynomial-overlap region. This is an analytic dimension calculation, not a finite-data fit. It is only meaningful with 0<g<1. For a fixed positive g, D_n(g) is exponentially small up to its displayed degree-seven polynomial, so the payable overlap region extends to exponentially small actual terminal overlap.

Remaining obligations: no theorem here proves arbitrary actual inputs satisfy these soft/overlap inequalities. The complementary joint traffic with s>sbar or w_g<delta is still unpaid. Different choices of sbar/delta are alternative bounds; summing multiple bands requires explicit new ownership and source-reuse costs. No logarithmic-count stratification is silently free. No strict physical enlargement over the R185 calibrated branch has been certified.

For varying original windows, global T_n and L_n denote their supremum over the original window family (bounded by the same displayed uniform estimate), or the root threshold is applied separately per original window before the permitted source sum. No extra independent window budget is inferred.
