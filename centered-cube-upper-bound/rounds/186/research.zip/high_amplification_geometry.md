# R186：低重叠核心的同 alpha 似然分离与实际接收硬面

本稿给出大 MA 放大量、低 Fcal、高 A 剩余交通的一条新的无假设必要几何关系：同一个原接收点上的 J/current 比值，在 good-v 和 reciprocal bad-u 之间必须有显式间隔。保留实际同 alpha 捕获余量后，该间隔进一步增强。它精确分解为源位移和当前硬面差，而不是分别对来源取上确界。

本稿没有证明这一剩余交通的根阶或 epsilon 接收价。新的实际付款来自本轮另稿的固定时间 posterior 与 mixed affinity；这里给出其极小 good 重叠补集上的准确联合几何和最早未付的面层积分步骤。必要分离不登记为已付分支，也不重新扩大反例搜索。

## HG1. 原量词与已付范围

固定原 (omega,V,a,b,q) 窗口，保留真正的 receiver x、唯一 j(x)、current s,L、g=√(LR)、实际 terminal good/capture/bad、同一个 alpha_y 及原删除历史。beta、nu 只分别受共同父 A_V 支配；没有 nu≤beta、每叶质量帽或接近全软的假定。所有 dx 是原 E_rec 上的 Lebesgue 积分。

沿用 R185 JP/MA：

    p_z=P_(s,L)(x−z),       J_z=P_(1,b)(x−z),
    gamma=1+1/n,           Lplus=min(b,gamma L),
    Q_z=(p_z+pplus_z+J_z)/3,       QJ=∫J_z nu(dz),
    g=√(LR), c_j=gamma^(−j), ell_n=1+log n,
    T=c_j^(n/2)/(g^n√ell_n),
    Hhat=max(a,min(b,g c_j^(−1/2)(1−s+s phi(1/2))ell_n^(1/(2n)))),
    k_z=D P_(s,Hhat)(x−z),       a_v=T Delta_y(v).

原 D≥1 固定，k_z 是静态储备密度，不是辅助 score k_t(y,z)。在 active capture 槽，

    alpha QJ=Dq−∫_E min(a_z,k_z)nu(dz),
    rho_v=1−(k_v+alpha J_v)/a_v>0,
    A_y(v)=rho_v J_v/(p_v+pplus_v+J_v).

rho=0、a_v=0、QJ=0 等零交通先按原合同分支；本文几何比值只在严格软核正的实际有效槽使用。alpha0 的 bad 零交通需要原 K0>0，不能推给允许零核的抽象数据。

此前 MA 使用固定父质量 M=||A_V|| 的参考 pi=beta⊗nu⊗nu/M²，保持实际密度 B。其门 s≤sbar、B≤√n/A_n(sbar) 已付；大 B 补集没有因此成为大质量事件。JP 支付 Fcal≥theta，

    Fcal=w_g(y,v)² max(1,L_y(u))/rho_v²,
    L_y(u)=q k_u/(alpha QJ p_u).

本稿可以直接限制到上述所有未付补集及 R184 EC 的中央时钟，不变更 B、A、alpha、Pi，也不要求所有行 near saturation。

## HG2. 固定时间参考的准确原出处与资格

已直接读取 rounds/128/research.zip::proof.md：637 行给原 far 域 I_(j,V,y)∩[a/c_j,hstop]，643–648 行给

    alpha_i(y,z)=(b/c_j)C(|y_i−z_i|/b),
    w_t(y,z)=∏min(1,alpha_i(y,z)/t),
    Pi_y,t(dz)=1_Zj,V,y,t(z)w_t(y,z)nu(dz)/e_y,t.

650 行明确：固定 (omega,V,j,y,t) 后，nu、Z_t、w_t、e_t、Pi_t 均在接收点前构造，不依 x 或硬源。不可移出的对象是 D_g、S_g、w_g、A、current scales/softness、RC alpha、FA/Psi 及全部原历史门。不能把 Pi_g 当作固定 Pi_t。

因此固定 j,xi=c_jt/b 后，

    Gamma_(j,xi)(dy,du,dv)=beta(dy)Pi_y,t(du)Pi_y,t(dv)

确为不依 x 的正参考，质量至多 ||beta||；e=0 或原定义域外取零行。这里没有省略原 1_Z 或重归一来源。但若逐 j 用不同 Gamma 应用空间核估计，原唯一 j 不能自动消掉不同参考的费用；需保留实际菜单和时间成本。

本轮 fixed_source_localization.md 已独立处理这一换序及 actual mixed-affinity 付款。本文不重复其证明。其剩余核心包含极小 good 重叠 w_g(y,v)<delta_n（在该稿 delta_n≤1 的参数范围）及 soft 参数尾；下面关系对所有参数均成立，因而可用于这两个补集。不得将以下必要几何改称该参考的免费列预算。

## HG3. 同一接收点上的 current/J 似然间隔

写

    a_n=1+gamma^(−n),       d_n=a_n/3,
    kappa=K d_n,           R_J(z)=J_z/p_z,
    w_u=w_g(y,u),          w_v=w_g(y,v).

K 是原固定常数（实际应用 K=1），没有重选 K。径向单调给 pplus_z≥gamma^(−n)p_z，因此 Q_z≥d_n p_z。

实际互反 bad 同时满足

    p_y w_u>K Q_u,       p_u w_u>K Q_y.

故 w_u>kappa；kappa≥1 时该域空。以下 kappa<1。联合两条 bad 和 Q_y≥d_n p_y，而不是分别丢门，得到

    Q_u/p_u<w_u²/(K kappa),
    R_J(u)<3w_u²/(K kappa)−a_n
          =a_n(w_u²/kappa²−1).                         (HG1)

右侧严格正来自原 w_u>kappa；没有用 good-v 的重叠替换它。

现在固定 0<eta<kappa²，并限制原 high-A 槽 A_y(v)>1−eta。定义保留同 alpha 的实际余量

    c_v=(k_v+alpha J_v)/a_v=1−rho_v,
    eta_eff(v)=eta−c_v.

原高 A 恒等式给

    c_v+(1−eta)(p_v+pplus_v)/J_v<eta,
    0<eta_eff≤eta,
    R_J(v)>(1−eta)a_n/eta_eff(v).                       (HG2)

这比只丢掉 k_v+alpha J_v 后写 J_v/p_v≫1 更强；c_v 中保留实际 Hhat、T Delta 和同一个 alpha，未重新选择任何系数。

将 HG1–2 相除，体积及 a_n 精确抵消：

    log[R_J(v)/R_J(u)] > G_vu,
    G_vu=log{ kappa²(1−eta)/
                  [eta_eff(v)(w_u²−kappa²)] } >0.       (HG3)

统一下界为

    G_vu≥G_eta=log{ kappa²(1−eta)/[eta(1−kappa²)] }>0.  (HG4)

当 actual capture 费用 c_v 接近 eta，或 reciprocal bad 的 w_u 接近其最小值 kappa，HG3 的强制间隔增大。这是必要条件，不意味着这些行稀少。

## HG4. 体积消去后的精确连续项与 current 硬面差

令 f_s(r)=(1−s)1_{r≤1/2}+s phi(r)，m(s)=1−s+s phi(1/2)，

    jump_s=log[m(s)/(s phi(1/2))],
    tilde f_s(r)=f_s(r)exp(−jump_s 1_{r≤1/2}).

在原严格软 s>0 下 tilde f_s 连续，去跳后的负 log 导数 beta_s≥0。使用 R184/R185 已审核的 phi 斜率常数

    Lphi=2/(1−exp(−1)),
    0≤beta_s≤Lphi,       0≤−(log phi)'≤Lphi

（几乎处处）。记

    d_i(z)=|x_i−z_i|,
    B_J(d)=log phi(d/b)−log tilde f_s(d/L),
    N_L(z)=Σ_i1_{d_i(z)≤L/2}.

由原 product 核直接展开，

    log R_J(z)=nlog(L/b)+Σ_i B_J(d_i(z))−jump_s N_L(z).

所以同一原 x,s,L,b 的两个来源满足准确恒等式

    log[R_J(v)/R_J(u)]
      =Σ_i[B_J(d_i(v))−B_J(d_i(u))]
           +jump_s[N_L(u)−N_L(v)].                     (HG5)

这是 J/current 比值，而不是 R185 SD 的 K0/current 比值。nlog(L/b) 在同一点真正抵消，不能在两个来源上独立取尺度。

几乎处处有

    B_J'(d)=beta_s(d/L)/L−[-(log phi)'(d/b)]/b.

两个被减项非负且各至多 Lphi/L（L≤b），因此不多收因子2：

    |B_J'(d)|≤Lphi/L,
    |Σ_i[B_J(d_i(v))−B_J(d_i(u))]|
       ≤Lphi ||u−v||_1/L.                              (HG6)

闭面 membership 采用原 ≤L/2 约定；source 原子在硬面上时不能删掉跳项。s=1 时 jump_s=0，连续式仍成立。

结合 HG3 和 HG5–6，得到新联合必要不等式

    G_vu < Lphi ||u−v||_1/L
                    +jump_s [N_L(u)−N_L(v)].           (HG7)

特别地，至少发生下列一个事件：

    ||u−v||_1 > L G_vu/(2Lphi),                         (HG8a)

或

    jump_s [N_L(u)−N_L(v)] > G_vu/2.                   (HG8b)

第二项要求正的 signed current 硬面差；不是任意两侧面数的总和。jump=0 时 HG8b 为空。更一般若实际距离≤d L，则

    jump_s [N_L(u)−N_L(v)] > G_vu−Lphi d.

整个命题无需 ν 与 β 的支配、来源独立或质量帽，且对原 high、central、low-Fcal、large-B/history 进一步限制保持成立。它不对这些事件分配任何来源或接收价格。

## HG5. 极小 good 重叠的另一项必须保留的费用

若本轮已付分支外还有 w_v<delta、w_u>kappa，则同一实际 terminal 时钟给

    log(w_u/w_v)>log(kappa/delta).                     (HG9)

当 delta 很小时，这确为很大的源重叠差，但它不能直接认作实际 far 时间内的 score 收益。对任意固定 pair，原权重的绝对连续部分满足

    log[w_g(y,u)/w_g(y,v)]
      =log[w_tau(y,u)/w_tau(y,v)]
          +∫_tau^g [k_t(y,v)−k_t(y,u)]dt/t.            (HG10)

实际正交通只在原 far 子域且 hstop≤g，仍带 Z_t、history、A、Pi²。HG10 的初始重叠差可以承担 HG9，积分也有符号；不能把整段 terminal 对数差当作实际正交通的可用负信用或强制消散。所有核严格正时该式正常；各坐标阈值处为有限个导数跳，不产生额外 dt 质量。原删除不改变物理 w_t，但仍改变 Pi，故不能在 HG10 中以 w 的恒等式替换删除后的概率演化。

HG7 与 HG9 同时成立，保留 x 的 current/J 对比和 y 的辅助重叠对比。一般 source-coordinate 独立性既没有使用，也不能由二者推出。

## HG6. 最早未付的 receiver 硬面步骤

令 H_core 保留原大 B、低 Fcal、高 A、中央时钟及所有原门。HG8 将相应实际正交通仅作不交几何分割：先取 HG8a，其补集必须在 HG8b。其正被积密度仍为

    p_y A_y(v)(k_t(y,v)−k_t(y,u))_+
        H_core Pi_y,t(dv)Pi_y,t(du) beta(dy) dx dt/t.    (HG11)

hard 帽16/3及外2Lambda仍只用一次。HG8a 的真实加权远源列及 HG8b 的真实加权 current 面层列均未获得根阶/epsilon 价格，不能因为已经写成位移或面事件便登记为付款。

具体尝试中的第一处缺口如下。逐坐标有准确几何包含

    {1_{|x_i−u_i|≤L/2}≠1_{|x_i−v_i|≤L/2}}
       ⊂{dist(|x_i−v_i|,{L/2})≤|u_i−v_i|}.             (HG12)

对固定 L 和固定 u_i,v_i，两区间指示之差的 Lebesgue 支持长度至多2|u_i−v_i|。但原 L=L(x) 是共同 FIRST selector，而非固定于 dx 之前。若只正放宽到全部 a≤L≤b，HG12 变成

    dist(|x_i−v_i|,[a/2,b/2])≤|u_i−v_i|.

这一放大的集合长度上界为 b−a+4|u_i−v_i|，含非消失的尺度带宽 b−a。因此该朴素正包络本身不再提供 O(|u_i−v_i|) 的面层费用。更何况 HG11 还含 receiver 相关 p_y、A、same alpha、高低核门及其他坐标密度；不能将一维未加权长度直接乘入原积分。

固定 j,t 的 Pi 独立 x 已获原出处，故这不是一个虚构的“Pi 无法换序”障碍。准确缺失的是：在同一固定时间参考下，原 FIRST 所选 current 硬面的占用，能否带着 HG3 的实际捕获余量和 HG11 的密度收取小费，而不是对所有 L 作上述尺度带放大。现有 MA 的 mixed affinity 支付指定有界乘子，但不自动收取该面层密度；原 high/FIRST 容量也没有给相应的 source 面层质量帽。

同样，HG8a 的距离下界不能直接付远对：源距离是总 l1，少数坐标即可承担它，且原密度不是无权同核 affinity。不能将同核 product 衰减免费移入 J/current 的实际 target 密度。若证明所需的新加权面层或远对估计，必须在原 dx/source/time 上完成，并保留实际 j/window 费用。

## HG7. 本轮付款与停止点

本稿与 fixed_source_localization.md 的实际付款互补使用：先在原交通正分割中移除旧已付分支及该稿已付分支，再在其补集应用 HG3–8 的必要关系。这里没有新增 B 阈值、没有归一化为未知小矩，也没有独立消费负项或复制窗口预算。

新增可核内容是 actual same-alpha 加强的 J/current 似然间隔 HG3、共同 receiver 的精确硬面分解 HG5 和位移/正硬面差分歧 HG7–8。它们把下一步定位到 FIRST-selected current 面层及对应加权远对列；HG10 防止将巨大 terminal overlap 差误付为实际时间消散。一般低重叠、大放大核心的来源根价或 epsilon 接收价仍未证明。

全部结论为解析必要式，不需要新有限物理样本或反例库。本文在该有界检查点停止。
