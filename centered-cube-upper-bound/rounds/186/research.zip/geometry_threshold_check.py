#!/usr/bin/env python3
"""Finite exact score checks and high-precision geometry threshold diagnostics."""
from fractions import Fraction as F
from pathlib import Path
import argparse,hashlib,json
import mpmath as mp
HERE=Path(__file__).resolve().parent

def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [enc(v) for v in x]
 return x

def score(name,stage,n,values,probs):
 values,probs=list(map(F,values)),list(map(F,probs));n=F(n)
 assert len(values)==len(probs) and sum(probs)==1 and all(p>=0 for p in probs) and all(0<=x<=n for x in values)
 direct=sum((p*q*max(x-y,0) for x,p in zip(values,probs) for y,q in zip(values,probs)),F(0));xs=sorted(set(values));cdf=F(0);via=F(0)
 for lo,hi in zip(xs,xs[1:]):
  cdf=sum((p for x,p in zip(values,probs) if x<=lo),F(0));assert cdf*(1-cdf)<=F(1,4);via+=(hi-lo)*cdf*(1-cdf)
 assert direct==via<=n/4
 return dict(name=name,stage=stage,n=n,values=values,probabilities=probs,iid_positive_score_direct=direct,cdf_integral=via,bound=n/4,equality=direct==n/4,checks_pass=True)

def numeric(dps):
 mp.mp.dps=dps
 def phi(r):
  r=abs(r)
  return 1-mp.expint(3,mp.mpf('.5')+r)-mp.expint(3,mp.mpf('.5')-r) if r<=mp.mpf('.5') else mp.expint(3,r-mp.mpf('.5'))-mp.expint(3,r+mp.mpf('.5'))
 tau=mp.mpf(1)/3+2*mp.expint(4,1);td=mp.quad(phi,[-mp.mpf('.5'),0,mp.mpf('.5')]);tol=mp.mpf('1e-30');assert abs(tau-td)<tol
 Tcases=[]
 for stage,n,kind,m in [('initial',16,'integer',0),('initial',16,'integer',1),('initial',16,'log2',None),('stress',64,'integer',1),('stress',64,'integer',10),('stress',64,'log2',None),('expanded',1000000,'integer',1),('expanded',1000000,'integer',100000),('expanded',1000000,'log2',None)]:
  lg=mp.log1p(mp.mpf(1)/n);h=2*m*lg if kind=='integer' else mp.log(2);assert 0<=h<=mp.log(2)
  # Known integer seam: j=m contributes zero, so count only j=0,...,m-1.
  N=m if kind=='integer' else int(mp.floor(h/(2*lg)))+1
  T=N*h-lg*N*(N-1);upper=h+h*h/(4*lg)
  # Independent formula: a triangle integral plus exact sawtooth remainder.
  u=h/(2*lg);frac=u-N;alternative=lg*(u*u+u-frac*(frac+1))
  assert abs(T-alternative)<tol and -tol<=T<=upper+tol
  positive_price='zero traffic before any division' if h==0 else 'threshold identity evaluated on positive-h table'
  Tcases.append(dict(stage=stage,n=n,h_kind=kind,m=m,h=h,log_gamma=lg,positive_term_count=N,T=T,alternative_T=alternative,upper_bound=upper,gap=upper-T,zero_seam_included_only_as_zero=kind=='integer',raw_zero_branch=positive_price,checks_pass=True))
 table=[]
 for n in [16,64,256,4096,65536,1000000]:
  stage='initial' if n<=64 else ('stress' if n<=4096 else 'expanded');nn=mp.mpf(n);lg=mp.log1p(1/nn);h=mp.log(2);N=int(mp.floor(h/(2*lg)))+1;T=N*h-lg*N*(N-1);L=nn*T/4
  specs=[('constant_1/4',mp.mpf(1)/4),('constant_1/20',mp.mpf(1)/20)]+[('c'+str(c)+'_sqrt_log_n_over_n',c*mp.sqrt(mp.log(nn)/nn)) for c in [1,2,4,8,10]]
  for label,requested in specs:
   gap=min(mp.mpf(3)/4,requested);s=1-gap;r=1-s+s*tau;aff=mp.sqrt(r*tau)+mp.sqrt((1-r)*(1-tau));logA=1+mp.log(nn+1)+mp.log1p(nn/2*mp.log(2))+nn*mp.log(aff);logdelta=2*logA+2*mp.log(L)-mp.log(3*nn);logprice=logA+mp.log(L)-(mp.log(3)+logdelta)/2;target=mp.log(nn)/2
   assert abs(logprice-target)<tol and s>1-mp.power(2,-1/nn)
   table.append(dict(stage=stage,n=n,softgap_label=label,softgap_requested=requested,softgap=gap,cap_applied=requested>mp.mpf(3)/4,sbar=s,affinity_a=aff,log_A=logA,log10_A=logA/mp.log(10),T=T,L=L,log_delta=logdelta,log10_delta=logdelta/mp.log(10),delta=mp.exp(logdelta),delta_at_most_one=logdelta<=0,log_raw_price=logprice,log_sqrt_n=target,raw_identity_residual=logprice-target,strictsoft_margin=s-(1-mp.power(2,-1/nn)),checks_pass=True))
 def stringify(x):
  if isinstance(x,mp.mpf):return mp.nstr(x,38)
  if isinstance(x,dict):return {k:stringify(v) for k,v in x.items()}
  if isinstance(x,list):return [stringify(v) for v in x]
  return x
 return stringify(dict(dps=dps,tau_formula=tau,tau_direct_quadrature=td,tau_residual=td-tau,T_cases=Tcases,threshold_table=table))

def run():
 scores=[score('endpoint_equal','initial',16,[0,16],[F(1,2)]*2),score('constant','initial',16,[7],[1]),score('three_points','initial',16,[0,8,16],[F(1,4),F(1,2),F(1,4)]),score('endpoint_unbalanced','stress',64,[0,64],[F(1,100),F(99,100)]),score('zero_probability_slot','stress',64,[0,32,64],[F(1,2),0,F(1,2)]),score('interior_support','stress',64,[10,20,30],[F(1,3)]*3),score('large_endpoint_equal','expanded',1000000,[0,1000000],[F(1,2)]*2),score('high_mass_range','expanded',1000000,[0,1,999999,1000000],[F(1,2**40),F(1,2)-F(1,2**40),F(1,2)-F(1,2**40),F(1,2**40)]),score('seven_slots','expanded',1000000,[F(1000000*i,6) for i in range(7)],[F(1,7)]*7)]
 low,high=numeric(40),numeric(70);diffs=[]
 for a,b in zip(low['threshold_table'],high['threshold_table']):
  delta=abs(mp.mpf(a['log_delta'])-mp.mpf(b['log_delta']));assert delta<mp.mpf('1e-28') and a['delta_at_most_one']==b['delta_at_most_one'];diffs.append(mp.nstr(delta,12))
 assert abs(mp.mpf(low['tau_formula'])-mp.mpf(high['tau_formula']))<mp.mpf('1e-35')
 root=Path(mp.__file__).resolve().parent;sha=hashlib.sha256()
 for p in sorted(root.rglob('*.py')):sha.update(p.relative_to(root).as_posix().encode());sha.update(p.read_bytes())
 return dict(schema='r186_geometry_threshold_v1',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},dependencies=dict(mpmath_version=mp.__version__,mpmath_source_tree_sha256=sha.hexdigest()),score_cases=scores,low_precision=low,high_precision=high,log_delta_precision_differences=diffs,summary=dict(exact_score_cases=len(scores),T_cases=len(high['T_cases']),threshold_rows=len(high['threshold_table']),usable_delta_rows=sum(x['delta_at_most_one'] for x in high['threshold_table']),all_checks_pass=True,unexpected_failures=[]),scope=['T sums over j>=0; integer seams are prescribed symbolically; log2 positive counts are numerical with 40/70 consistency','h=0 is a zero traffic branch, not an evaluation of 0/0; raw price identity is only asserted for positive h','IID score checks are exact finite algebra, not arbitrary dependent scores','mpmath log-domain/tau/quadrature and precision differences are not directed interval bounds','The cap is on requested softgap at 3/4; actual gap and cap flag are retained','No physical FULL/FIRST/history instance or general asymptotic claim is inferred; source/window selector costs remain in A and L'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'geometry_threshold_check.json');args=p.parse_args();r=run();args.output.write_text(json.dumps(enc(r),indent=2,sort_keys=True)+'\n');print(json.dumps(r['summary'],sort_keys=True))
