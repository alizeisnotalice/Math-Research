# R186 独立预检与后审

责任仅本文件；不Git/spawn/PDF、不运行数值、不改他人文件。第一阶段在未读本轮作者稿前独立检查。186/work已存在但首次读取task_contract.md尚未落盘，暂按父级R186明确任务和已审R184/R185接口；合同到齐后再核范围。

## 1. 准确未付目标与固定来源资格

本轮目标是原指定J-share的中央时钟、低Fcal、高A及R185大B补集上的正交通，不是一个自由重构的来源模型。原same-alpha/capture/bad、完整Z_t/Π_t、clamped Hhat、real dx、原唯一j和窗口都保持。A(v)=1_good rho_v J_v/(3Q_v)沿辅助t固定并支持Z_g；Fcal及其他pair门只作正切片，不参加固定A导数。一般弱型根阶目标仍未闭合。

原β、ν仅共同受A_V支配，均有限；不假ν≤β，不假每叶质量帽。共同seed/window不交V给Wβ,Wν≤W_A。来源总质量M=||A_V||固定，R185三源π=β⊗ν⊗ν/M²固定且质量≤M；所有M²/e_t²放大留于B。该归一不能因high或合法FIRST而自动替换为局部e_t，更不能由∫pβ≤q推出局部父质量帽。

原固定(omega,V,j,y,t)的ν、Z_t、w_t、e_t、Π_t独立receiver x；终端g/wg/A/alpha及原s/L/R/Hhat/history仍依x。固定t后验是合法reference的候选，但终端Π_g或按receiver选择的t(x)不可直接视为固定reference。

## 2. 可无额外质量费的固定source局部化引理

令N(y)为固定source规则，可依原omega,V、source y及预先固定几何数据，但不依receiver x或其selector。取m(y)=A_V(N(y))，在m(y)>0定义

    π_N(dy,du,dv)=β(dy)1_N(y)(u)ν(du)1_N(y)(v)ν(dv)/m(y)²。

这是固定的相关三源测度，无需来源独立；其质量≤∫β(dy)≤M。m(y)=0时ν(N(y))=0，原该局部正片先取零。对原u,v∈N(y)部分，R185 capped因子身份可将M²换成m(y)²，而π换π_N；R185 mixed affinity仍能固定source Tonelli，不附每叶masscap。该结论只覆盖所指定的原局部正片，u或v落在N(y)外的所有交叉片不得删除。

固定outer partition与固定neighborhood是上述特例。若多个规则N_l都重用同一β，则聚合价格为Σ_l||π_Nl||，至多规则重数乘M，不能凭每个单规则价≤M就一概只收M。若有真正互斥source ownership，须显式证明其聚合reference质量界；不能把每一pair唯一owner偷换成outer β不重复，因为不同inner labels仍可能重复同一outer质量。

若m或N依x，π_N也依x，MA固定reference的界不再适用。合法修复需要一个固定支配reference及其真实密度、可收费的选择菜单、或独立证明接收积分预算；不能对每个x局部归一后再直接Tonelli套原固定source核积分。若对多个局部规则取最优，同样需固定owner或选择费。

## 3. 原固定t后验参考的可用与不可省费用

固定y,j,t且e_t>0时，可定义β(dy)Π_y,t(du)Π_y,t(dv)，其总质量≤||β||。它保持原Z_t与完整归一，且先于receiver x，因此作为该时间切片的固定相关reference是合法的。这一观察本身不付全交通：实际far端点依x，只能作为正H保留或在合法共同时钟上扩大；将t换成ξ=c_jt/b后每个固定j的reference仍可能不同。

若reference因j改变，Σ_j1_j(x)=1本身不能在source积分后免费把Σ_j||reference_j||化成一份M。需保持共同固定reference支配/聚合质量界，或显式付j数；不同window重复亦然。若receiver所选t(x)带入reference，则不再属于本节固定t引理。原score、A、high/alpha与选择器残余必须仍在密度或原门内；不能一面将reference概率化，一面又沿用已含其分母的R185 B次数。

## 4. 行稳定性升级真实dx预算的最低义务

同alpha稳定式可比较固定ν、共同q/J/k的两行；改变source center、receiver selector或支持Z时，capture/bad门、alpha、分母和history的交换项均需明确。仅有行L1误差或核比Lipschitz不推出其p_yβ(dy)dx积分是ε∫q或√n W_A。

一个真正全局新估计须给出：原未付集合的覆盖或明确有界正切片；固定reference的质量聚合；可积receiver主核及所有soft/scale/j/window费用；剩余实际密度的有价控制。任意定义新B或任意cut后得到条件付款，不能登记为一般目标已推进至闭合，尤其不得把大旧B补集重新命名为小新密度而不证明覆盖。原负信用与ε接收费只消费一次。

## 5. 第一阶段停止点

当前可用的建设性替代是§2固定source局部reference和§3固定时间后验reference的合法量词；尚无其覆盖原大B∩低Fcal高A中央交通且聚合费用根阶的证明。此处只筛接口，不自行扩反例/数值/新路线。待合同及准确作者候选后，先独筛再全文后审并按最终文件绑定。


## 6. 合同补读

父级随后落盘task_contract.md已实读：本轮以aa75ada592ce0a7db08950cfb304bdc14ca09bd7为起点，责任、允许工具、来源/归一禁项及一般目标均与前述独立预检一致。D01仅资格检查，不提供未经证明的强对偶或动态耦合。无准确新候选时停于本检查点等待，不自行扩路线。


## 7. 首个准确候选独筛：固定时间后验的原参考

在未读本轮作者证明前，实读必要原窄段：R117 research.zip::proof.md JG2 lines45–52给τ_j=a/c_j≤t≤bc_j；R128同名proof.md RT4 lines648–650明确固定(omega,V,j,y,t)的ν/Zt/wt/et/Πt先于x，line837给actualt可扩大到上述物理窗。所引原时间资格是JG2，不从current核归一推断。

令h=log(b/a)、l=logγ、J=floor[h/(2l)]，定义

    Γ_V(dj,dt,dy,dv)=Σ_j1_[a/cj,bcj](t) dt/t β_V(dy)Π_j,y,t(dv)。

e_t=0取Π=0。Γ完全固定于receiver之前；总质量≤T_n||β_V||，其中

    T_n=Σ_j(h−2jlogγ)_+=(J+1)h−logγ J(J+1)
       ≤h+h²/(4logγ)≤log2+(n+1)log²2/4。

整数边界最后一项为0无误，h=0则Γ=0、实际时间交通零，不能形成Bcap/T_n的除法。这里全j/time费已真实收取，不再凭uniquej删除。

原u积分保留全部actual H（含1_j(x)、far、high、reciprocal、terminal与未付补集），令

    D_x(j,t,y,v)=√(p_y/J_v) A_v ∫H_x δ+ Π_j,y,t(du)。

则指定J-share capped正量精确为(32Λ/3)∫dx∫√(p_yJ_v)D_x dΓ。没有M²/e_t²的外提因子，但原归一仍完整留于固定Π及u积分，绝非重选source/alpha。D≤n√(p_y/J_v)A≤n√(p_y/J_v)。用R185 MA给s≤sbar、D≤Dcap支价格(32Λ/3)Dcap A_n T_n Wβ≤同系数W_A；Dcap=√n/(A_n T_n)给明确根阶来源支。

这是有真实j/time价格的替代reference；不能只因换了门就说原大B核心已受一般控制。D大、soft尾、外源/target核比和实际原正片覆盖仍是关键，成稿须明确其几何充分条件或未付边界。当前仅候选筛查通过，尚未读作者完整稿。


## 8. 非任意cut的实际重叠充分支与Astra接口先筛

令w=wg(y,v)、r_v=(p_v+pplus_v)/J_v，实际A=ρ/(1+r_v)。good给p_y/J_v≤K(1+r_v)/(3w)，所以

    A√(p_y/J_v)≤ρ√[K/(3w(1+r_v))]≤√[K/(3w)]。

δ+≤k_t(v)≤n，故§7的真实D在目标w≥δ上满足D≤n√[K/(3δ)]。整片{s≤sbar,wg≥δ}（保原good/terminal等资格，包含旧大B而不要求其另小）因此有

    Raw≤(32Λ/3) A_n(sbar) T_n n√[K/(3δ)] W_A。

T_n>0且δ_n=K n A_n² T_n²/3∈(0,1]时，取δ=δ_n即得(32Λ/3)√n W_A。常数3、n及完整T_n皆准确；T_n=0为原零time支先处理，不造δ0除法。它是明确物理重叠充分条件下的真实付款，优于仅随意改名Dcut，但尚不证明低Fcal/高A全部满足w≥δ_n。soft上门与实际低重叠w<δ_n的其余交通仍原位保留，亦未认证相对Fcal的strict物理差集。

Astra独立提出固定j,ξ双星Γ=β(dy)Π_y,t(du)Π_y,t(dv)质量≤||β||的接口，亦筛查正确。good给pA≤√(K/3)ρ√(pJ)/√wg；原ξg≤1时wg≥W_b=∏C_i。若以W_b替代，则在正放ρ≤1后，MA只留下固定来源的∫βΠ_v W_b^(-1/2)矩。该逆重叠矩没有无条件质量预算；不能因Π总质量1或同alpha储备而把它当已付。此与Sol已付w≥δ支的低重叠补集精确一致，不另把同一未知矩登记为一般进展。


## 9. 固定实际正flux参考的精化独筛

在作者成稿前再筛准确精化：把固定j,y,t的真实δ+=(k_t(v)−k_t(u))_+并入原Π⊗Π，定义Γ^+（保固定物理窗，原未定义/零行先取零）。对同一实际Π的两独立哑槽，score K∈[0,n]有

    E(K−K′)_+=∫_0^n P(K>r)P(K′≤r)dr≤n/4。

故Γ^+质量≤L_n||β||，L_n=nT_n/4。这是实际原正flux的固定支配，不是优化或改变source。可先将u积分成h_t(v)=∫δ+Π(du)，并令

    χ_x(j,t,y,v)=∫δ+H_xΠ(du)/h_t(v)∈[0,1]。

h=0先零；参考h_t固定x，但χ包含全部原bad/reciprocal/terminal/history、1j及actualtime门，绝不宣称χ固定。指定capped原量精确为(32Λ/3)∫√(p_yJ_v)[A√(p_y/J_v)χ_x]dΓ_pair^+ dx。§8 good bound仍成立，因此重叠整片{s≤sbar,wg≥δ}现在获价

    (32Λ/3) A_n(sbar)L_n√[K/(3δ)]W_A。

T_n>0、δ_n=K A_n²L_n²/(3n)=K nA_n²T_n²/48∈(0,1]时为(32Λ/3)√n W_A。此精化替代§8的nΓ粗界，常数3→48来自n/4而非另假独立来源；Π⊗Π本来就是原两槽。零time先分支，source/window重用与低重叠/soft尾仍全保留。尚未读完整作者证明。


## 10. 父soft-gap后果窄审与HG准确候选先筛

parent_soft_overlap_budget.md已实读。由A_n≤e(n+1)²exp[−n(1−sbar)²/18]及T_n≤log2+(n+1)log²2/4≤n+1，得到

    δ_n≤K e² n(n+1)^6 exp[−n(1−sbar)²/9]/48。

因此n(1−sbar)²≥9log[K e² n(n+1)^6/(48δ)]是指定δ∈(0,1]重叠支的根价充分条件；δ=n^(−p)展开(p+7)logn+6log(1+1/n)+log(Ke²/48)正确。负log、T0、softgap范围及多band聚合费均处理明确；该后果在Γ+正式成稿通过前按已筛接口条件成立，不认证actual输入自动满足。

Astra新HG候选在未读其稿前筛查：r_z=J_z/p_z，d_n=(1+γ^(−n))/3，κ=Kd_n。高A>1−η及pplus/p≥γ^(−n)给

    r_v>Rη=(1−η)(1+γ^(−n))/η。

同一互反bad两方向给Q_u/p_u<wg(y,u)²/(Kκ)，从而

    r_u<3wg(y,u)²/(Kκ)−(1+γ^(−n))≤Rrec=3/(Kκ)−(1+γ^(−n))。

Rrec≤0时该域为空；只有Rη>Rrec>0时取正log gap。对同一current L，去跳f~_s及B_J(d)=logφ(d/b)−logf~_s(d/L)，精确为

    log(r_v/r_u)=Σ[B_J(|x−v|)−B_J(|x−u|)]
                     +jump_s[N_L(u)−N_L(v)]。

两非负log斜率各≤Lphi/L，故|B_J′|≤Lphi/L（不需加倍）。必要共同几何为

    log(Rη/Rrec)<Lphi||u−v||1/L+jump_s[N_L(u)−N_L(v)]。

硬面闭端点及signed方向必须保留。此对象为J/current而非旧K0/current；它仅定位actual高A/互反源对的远位移或current硬面分歧，不支付其receiver加权质量。


## 11. 作者全文后审及必需修订落实

独立阶段后已全文实读fixed_source_localization.md FL1–FL11，主证明通过。原RT4/JG2窄来源核验与§7一致；score收入实际Γ+而非改选耦合，n/4层糕、h/χ精确边缘身份、actual全部H、good提供的常数3、δ_n分母48、零time/零e/零h、soft上门与极小target重叠尾均正确。其实际几何整片付款不要求R185旧B小，故不只是把B重命名后任意切小值；但原一般交通仍需覆盖余下事件。

父/独审要求的两处窄修已实际核到最终稿：全局聚合先逐V用L_V=nT_n(a_V,b_V)/4，统一阈值时改确定的Tstar=sup_(omega,V)T_n及L_n=nTstar/4，或逐窗阈值先付再汇总，二者不得混门/价格；不再把单窗系数直接提出EΣV。无效的R185 parent_localization文件名引用已改为R181 common_parent_budget和R185 JP1/MA4。最终FL12为δ_n=K nA_n²Tstar²/48；§7–10单窗公式均按此聚合资格使用。

high_amplification_geometry.md HG1–HG7已全文实读，通过。其主必要式进一步保留实际c_v=(k_v+αJ_v)/a_v，ηeff=η−c_v>0，η<κ²；HG3对数分离

    G_vu=log[κ²(1−η)/(ηeff(w_u²−κ²))]>0

及统一G_eta下界准确。HG5为同点J/current精确signed当前硬面差，HG7–8为必要位移/正面差二分，未登记付款。HG10保留初始重叠差与整段signed时钟，避免把巨大terminal比当actualfar强制耗散。HG12固定L未加权长度≤2|u_i−v_i|，adaptiveL粗包络新增非消失b−a带宽，真实加权面列/远对列仍未付；未以此开展一般反例搜索。

## 12. 数值、来源索引与整合全文审查

geometry_threshold_check.py与numerical_review.md已全文静态审过，未运行。9个Fraction IID score双和/CDF层糕检查、9个T sum与三角/sawtooth独式（整数缝按符号菜单）、42个40/70dps logdomain阈值及12个δ≤1可用行的实现/标签一致。softgap cap、strictsoft必要资格、δ>1不适用、零time先分派、τ的E4/directquad比较均明确；mpmath经验残差非interval，有限数组非physical/FIRST/history或一般阶数认证。只哈希.py依赖、完整JSON与assert失败非零退出的工程范围正确。

parent_localization_contract.md已实读，仅作原共同父/支撑与窗口来源复用的窄定位，未用其代替新fixed-time资格证明，也不将ν≤β、每叶帽或新森林独立性引入。parent_soft_overlap_budget.md全文通过，单窗/统一上界参数按最终FL资格解释。

proof.tex.txt与report.md已全文实读。窄修已落实：原capped全局身份显式E_omegaΣV及Γ_V^+，不同窗使用T*或逐窗结算，混核参数明0<sbar<1。常数48、n/4质量、真正Lebesgue/selector费用、指定J-share原正量≤一次hard帽、WA来源界及未付范围与作者稿一致。reproduce.py已静态读，使用现有依赖、全JSON逐字节比较与失败退出；不运行、不编译PDF。

父级parent_replay.json已实读，记录实际重放exit0及完整JSON逐字节一致，hash与保留geometry_threshold_check.json相符。本独审的静态通过、数值作者独立重放和父实际回执分开，不虚称本独审运行。未生成manifest/zip前的哈希不作为最终归档验收。

## 13. 最终结论、文件绑定与停止

在明确原合同范围内通过本轮三份数学文件及整合稿：fixed actual positive-flow reference以真实L_n=O(n²)来源质量消去显式M/e放大，good与混核包络给整个soft上门/target重叠下门的线性根阶来源付款；HG给其极小重叠补集的same-alpha必要联合几何，不附无价付款。一般低重叠/soft尾、加权FIRST硬面与远对列、其他原分支及窗口来源重用仍未闭合。没有把arbitrary cut、有限数值或必要关系认证为一般目标完成。

下表实际实算最终SHA256，不包括自身、后生成manifest/inventory或归档验证。修订范围与标签已冻结，本独审完成并停止，不自行扩研究。

| 文件 | SHA256 |
|---|---|
| fixed_source_localization.md | `7a793a5f6e0322957906e20abe090c7de4c76f21603bb16bafbc6025d240a662` |
| geometry_threshold_check.json | `b6304fe27c6a0d97a4e58e7fd4d2023c877e3d7ca82f53bf9cadb935999b714f` |
| geometry_threshold_check.py | `76dd2f722ac985cef63b7f51d62471465644654f72554a4824d000016e41e18d` |
| high_amplification_geometry.md | `1bf099dd0fde35fed3b743dc51bd96ea0f91c96e59ce150e96dc1c071936599c` |
| numerical_review.md | `958bb65919bf9b45cef6a617ec321f0d58ca8c020432ee1fff5b8c38bcc42e9f` |
| parent_localization_contract.md | `9a802443e8dc8d4b332dd7dc3e6f739ac211037e870161380c866aecd2cda0a3` |
| parent_replay.json | `2d014f169aa1e4b97223fbd0ecc43f19c94c87cefc65ba31e6682bd30a154593` |
| parent_soft_overlap_budget.md | `a59177518416403ee30f3602a046b021c2f8b9700f80d022e6b0b6adecc4c697` |
| proof.tex.txt | `6d389776642802d3f38398d65a7109bf864fe2b41490ff55cd84a0924db5a304` |
| report.md | `2e1da818ff0b6fd510fa2cc09fdce16afd9062fb52f522bb626149f31dba8833` |
| reproduce.py | `e00021a8a54fda0ad9735f77ba9e38c46f1a4104aefbe4405eca9c647b3c1883` |
| task_contract.md | `db42a62b174f10fb21128efb961f7f04c7b61d568e6638f5547d01a463e44490` |
