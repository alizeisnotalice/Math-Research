# R186 geometry-threshold numerical review

Retained results: 9 exact Fraction IID-score cases, 9 high-precision scale-sum cases, and 42 high-precision threshold-table rows. All checks pass. The script is self-contained apart from adjacent `task_contract.md` and standard-import mpmath 1.3.0. No original source/history/FIRST instance or general dimension-order claim is certified.

## Conventions checked before execution

The scale sum is over integers j≥0, including the j=0 contribution h. At a prescribed seam h=2m logγ, the j=m term is exactly zero; the code counts only the m strictly positive terms. For h=0 it records T=L=0 and a zero-traffic branch. It does not evaluate A L/sqrt(3δ) at δ=0 or assert 0/0=sqrt(n). The positive-h threshold identity is tested separately.

For h=log2, the positive term count is computed numerically at both 40 and 70 dps. For every integer seam the prescribed integer m is used, so a one-ulp floor ambiguity cannot alter the count. The computed sum is T=N h−logγ N(N−1). An independent triangle/sawtooth expression, writing u=h/(2logγ) and f=u−N, is logγ[u²+u−f(f+1)]. Both formulas agree within the stated numerical residual threshold and satisfy T≤h+h²/(4logγ). Cases include h=0, exact integer seams, h=log2, n=16/64/1000000, and a seam with m=100000. These logarithmic calculations are numerical consistency checks, not rational interval certificates.

## Exact score checks

All distributions are normalized finite probability distributions on [0,n], with X and Y independent and identically distributed. The direct double sum Σp_i p_j(x_i−x_j)+ equals the independent CDF formula ∫F(t)(1−F(t))dt exactly in Fraction arithmetic. The latter is at most n/4. Endpoint weights 1/2,1/2 attain n/4 exactly at n=16 and n=1000000. Other cases cover constant/interior support, unequal endpoint weights, a zero-probability slot, seven slots, and a 2^-40 mass scale. This IID hypothesis must not be replaced by arbitrary dependent score pairs.

## Affinity and threshold evaluation

The implementation uses the actual φ=h*w E3 expressions, and verifies τ=1/3+2E4(1) against direct quadrature of φ on [−1/2,1/2] at 40 and 70 dps. The value is approximately 0.50545831598245478984. The affinity factor is computed as a=sqrt(rτ)+sqrt((1−r)(1−τ)), r=1−s+sτ.

Every positive-h table row retains the full coarse factor

`A_n=e(n+1)(1+(n/2)log2)a(sbar)^n`,

`L=nT/4`, and `δ=A_n²L²/(3n)` (K=1).

A_n and δ are evaluated in logarithms, without converting to machine floats. The raw-price residual tests log(A_n L/sqrt(3δ))−log(sqrt(n)). Algebraically this identity follows from the same positive threshold definition; it is a check on the retained constants and implementation, not evidence that a root-price application satisfies its original qualifications. Rows with δ>1 are explicitly marked unavailable for a δ∈(0,1] cut, even though their algebraic identity still holds.

The table contains n=16,64,256,4096,65536,1000000 and seven softgap specifications: 1/4,1/20 and c sqrt(log n/n) for c=1,2,4,8,10. Requested gaps above 3/4 are clipped to 3/4, with both the requested and actual gap and the cap flag recorded. Such clipped rows do not represent the unmodified c sqrt(log n/n) regime.

There are 12 usable δ≤1 rows. No row at n=16 or 64 is usable. At n=256 the c=8,10 rows are usable only after clipping. For n=4096 and above, the unmodified c=8,10 rows are usable; examples are:

| n | c | log10 δ | cap |
|---:|---:|---:|---|
| 4096 | 8 | −37.99310948 | no |
| 4096 | 10 | −74.60391750 | no |
| 1000000 | 8 | −55.56119797 | no |
| 1000000 | 10 | −108.46771318 | no |

The c≤4 rows in this finite menu do not satisfy δ≤1. This is a finite formula-range observation, not a proof of a sharp transition or guessed asymptotic order. The rigorous coarse-condition analysis belongs to the parent proof.

## Precision, portability, and replay

Both 40 and 70 dps outputs are saved. Their log δ values differ by at most 2e-35 at the saved precision, with identical δ≤1 flags. The script requires numerical residuals below 1e-30 for the identities, and precision differences below 1e-28. These are empirical controls, not directed rounding or certified quadrature errors. All failed assertions exit nonzero.

The default system python3 does not include mpmath. The actual local command is:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 geometry_threshold_check.py
```

Standard `import mpmath` is used; no dependency path is hardcoded in the script or JSON and no installation was performed. The dependency version and SHA256 of relative-name `.py` source files are recorded, excluding bytecode caches. The only local input key is `task_contract.md`. `--output /tmp/result.json` redirects output.

An isolated replay copies only the script and task contract to `/tmp/r186_geometry_review/`, supplies the same existing mpmath via PYTHONPATH, and compares the entire JSON. No timing or absolute output-path field is part of the mathematical output. Source/receiver/window/selector prices retained in A_n and L have not been dropped, and the finite scalar table does not certify a physical FULL or general weak-bound instance.
