# R186 bounded source-localization contract

Scope: narrow localization of the R185 MA/JP source formulas through the source indices and contracts in R181/R183. Archive citations use `rounds/<n>/research.zip::<member>#<line>` with one-based lines. This note identifies inherited qualifications and gaps; it does not independently certify any new estimate. The R185 and R181 `research.zip` archives were inspected, along with the relevant R183 contract members.

## Fixed common parent and source mass

R185 JP1 states that the actual inner and outer measures \(\nu_V,\beta_V\) are each dominated by the same parent \(A_V\), with no \(\nu_V\le\beta_V\) assumption and no use of \(Q_J\le q\) or a per-leaf cap (R185 `joint_extremal_payment.md` JP1, lines 5–19). Its MA construction sets \(M_V=\|A_V\|\) and, for \(M_V>0\), freezes
\[
\pi_V(dy,du,dv)=\beta_V(dy)\nu_V(du)\nu_V(dv)/M_V^2,
\qquad \|\pi_V\|\le M_V.
\]
This is a fixed finite reference measure, not a probability or the actual posterior; the true posterior factors remain in the density \(B_V\) (R185 `mixed_affinity_raw_budget.md` MA4–5, lines 85–122; proof lines 102–118). The later MA15 price is linear in \(W_A=\mathbb E_\omega\sum_V M_V\); windows and repeated use of a parent retain their actual source costs (MA6, lines 124–149). Likewise JP14 pays with \(W_\nu\le W_A\), not by substituting \(W_\beta\) (R185 `joint_extremal_payment.md` lines 158–174).

R181 supplies the provenance of this common parent. For a fixed seed \(\omega\), the original terminal leaves \(V\) are pairwise disjoint, \(A_V=\mu_{hi,\omega}|_V\), and \(\nu_V\le\sigma_V\le A_V\); R113 B2 gives \(\beta_V\le A_V\) (R181 `common_parent_source_index.md` lines 5–17; `common_parent_budget.md` CP1–2, lines 7–24). R107 D2 gives the inherited domination by \(1_V f\), and disjointness yields the aggregate bound \(\sum_V M_V\le\mu_{hi,\omega}(\mathbb R^n)\le\|f\|_1\) (source index lines 7–17). These are common-seed aggregate mass bounds. They do not assert a local estimate \(M_V\le C\lambda b^n\) or analogous per-cell cap (source index lines 25–27).

## Fixed partition, receiver integration, and independence

The usable partition for that mass sum is the original terminal-leaf partition at a fixed \(\omega\), with the original common window. R181's source index says R112 fixes the same window and common \(q\), and its finite scale/menu extraction uses cumulative increments of one source split rather than charging the same \(A\) afresh per menu entry (R181 `common_parent_source_index.md` lines 19–23). This does not make independently chosen windows or source constructions free, and ratio-band \(j\) remains in the posterior/traffic and must be summed with its actual cost (same lines 21–23).

R185 MA10 permits source dependence/correlation in a finite positive \(\Gamma(dy,dv)\) only when \(\Gamma\) is fixed independently of receiver \(x\). It explicitly excludes an \(x\)-dependent posterior or a source measure reselected and renormalized after truncation (R185 `mixed_affinity_raw_budget.md` lines 85–99). MA11's \(\pi_V\) satisfies this fixed-reference condition; \(x\)-dependence remains in the explicit density and the receiver integral is genuine Lebesgue \(dx\) (MA5 lines 101–122). This is not an assertion that the posterior itself is independent of \(x\).

For shifted-grid arguments, R183 `forest_geometry_contract.md` lines 5–15 locates the independent random shift for pre-shift fixed points and warns that selection depending on the shift can bias that law. Lines 17–29 distinguish R107's new shifted forest from R113's original FULL forest and original \(A_{j,t}\) blocks; the fixed-cell split calculation does not identify those partitions. Lines 39–43 state that no weighted separation estimate retaining arbitrary \(\beta,\nu\) dependence and all later masks follows from the cited facts alone. Accordingly, neither R107's translated cells nor shift independence can silently replace the original \(V\) partition or justify receiver-dependent selection. The R183 task contract also records that \(\beta,\nu\) only share a parent and that no post-selection shift independence is free (lines 7–10).

## Fixed-cell mass substitution and source reuse

No corresponding theorem in these inspected members permits replacing \(M_V=\|A_V\|\) by a geometric fixed-cell volume/mass without a further source bound and accounting for reuse. MA11's inequality \(\|\pi_V\|\le M_V\) uses the three actual source masses and the denominator \(M_V^2\); MA13–15 then sums the resulting \(M_V\) against \(W_A\). R181 explicitly says the common-parent argument is global, not a per-leaf \(C\lambda b^n\) estimate. Thus a cell-based denominator would require a separately proved relation between the actual parent mass and that cell quantity, plus a multiplicity/source-reuse budget across cells, seeds, and windows. Neither is supplied by the common-parent localization. The existing disjoint-leaf sum pays one aggregate parent mass for the one original source construction; it does not authorize repeated fixed-cell copies of that mass.

The known warnings remain: \(\nu\le\beta\) is not established, and the per-leaf \(\lambda b^n\) mass cap is not established (R181 `common_parent_source_index.md` lines 17, 25–27). R183's distinction also prevents treating R107's new translated forest as the R113 original forbidden forest (`forest_geometry_contract.md` lines 17–29).
