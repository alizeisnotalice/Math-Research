#!/usr/bin/env python3
"""Verify archive integrity, optionally reproduce the finite checks."""
import argparse,hashlib,json,os,subprocess,sys
from pathlib import Path
base=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=Path);args=p.parse_args()
manifest=json.loads((base/'manifest.json').read_text())
for name,digest in manifest['sha256'].items():
    assert hashlib.sha256((base/name).read_bytes()).hexdigest()==digest,name
print('Archive hashes verified:',len(manifest['sha256']))
if not args.verify_only:
    if args.output_dir is None: p.error('--output-dir required unless --verify-only')
    args.output_dir.mkdir(parents=True,exist_ok=False)
    target=args.output_dir/'geometry_threshold_check.json'
    subprocess.run([sys.executable,str(base/'geometry_threshold_check.py'),'--output',str(target)],check=True,env=os.environ.copy())
    assert target.read_bytes()==(base/'geometry_threshold_check.json').read_bytes(),'Full JSON differs; inspect dependency/version fingerprints before using results'
    print('Full numerical JSON reproduced byte-for-byte')
