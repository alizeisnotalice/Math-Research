from fractions import Fraction as F
from itertools import product
from math import prod
ct={'same_center_shell':0,'two_receiver_contact':0,'winner_zero_defect':0,'nonwinner_defect':0}
def box(center,side):return [(x-side/2,x+side/2) for x in center]
def overlap(*boxes):
 return prod(max(F(0),min(B[i][1] for B in boxes)-max(B[i][0] for B in boxes)) for i in range(len(boxes[0])))
for dims in ((1,2),(4,8),(16,)):
 for n in dims:
  full=[(F(-1,2),F(1,2))]*n
  half=[(F(0),F(1,2))]+[(F(-1,2),F(1,2))]*(n-1)
  for c,step,Ru,Rw,nu in product((F(0),F(1,10),F(1,4)),(F(0),F(1,100),F(1,20)),(F(1),F(5,4),F(3,2)),(F(1),F(5,4),F(3,2)),(full,half)):
   u=(c,)*n;w=tuple(c+step*(-1 if i%2 else 1) for i in range(n))
   Cu=box(u,Ru);Cw=box(w,Rw)
   G_u=overlap(full,box(u,F(1)));G_w=overlap(full,box(w,F(1)))
   D_u=G_u*Ru**n-overlap(full,Cu);D_w=G_w*Rw**n-overlap(full,Cw)
   assert D_u>=0 and D_w>=0
   if Ru==1:assert D_u==0;ct['winner_zero_defect']+=int(Ru==1)
   if Ru>1:ct['nonwinner_defect']+=1
   delta=max(abs(x-y) for x,y in zip(u,w))+abs(Ru-Rw)/2
   if Ru+2*delta>2 or Rw+2*delta>2:continue
   Eu=box(u,Ru+2*delta);Ew=box(w,Rw+2*delta)
   shellu=overlap(nu,Eu)-overlap(nu,Cu)
   shellw=overlap(nu,Ew)-overlap(nu,Cw)
   boundu=G_u*((Ru+2*delta)**n-Ru**n)+D_u
   boundw=G_w*((Rw+2*delta)**n-Rw**n)+D_w
   assert shellu<=boundu and shellw<=boundw;ct['same_center_shell']+=2
   diff=overlap(nu,Cu)+overlap(nu,Cw)-2*overlap(nu,Cu,Cw)
   assert diff<=shellu+shellw<=boundu+boundw
   ct['two_receiver_contact']+=1
print('PASS',ct)
