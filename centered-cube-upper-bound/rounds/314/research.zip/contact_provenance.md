# R314 — hard-contact provenance for R302

## Conclusion

R302 itself does **not** establish that its selected R(x) is the hard maximizing scale of a complete source f, nor that its arbitrary source ν is dominated by that same f. It assumes arbitrary finite positive L1 sources β,ν and the SAME-receiver / SAME-selected-radius cap for ν. That contract is enough for R302’s stated estimate, but it is not a maximal-hardcap contract.

A separate native contract is available in GENERAL_CURRENT_REDUCTION: the source is the full positive input f (or μ=f dy); G0 is the hard endpoint maximal response; and the “original hard winner” R_h is used at the same original output. The accepted text states the hard winner identity/interface and the all-scale hard ceiling. This native contract may be used when working on that original event. The notes examined do not identify R302’s arbitrary ν and R(x) with f and R_h. Such a bridge requires the target to retain the native selectors and, for a restricted hard source, the order ν≤f; it cannot be inferred from matching symbols.

## Exact source evidence

1. R302 source: /tmp/r302_geometry.md §1, lines 3–18. It says “arbitrary finite positive L1 sources β,ν,” retains the original accepted set E, FIRST and SAME-receiver/SAME-radius hard caps, and defines U_y and A_yz using the actual selected R(x). It does not define f, G0, a maximizing property for R(x), or ν≤f. Its line 20–22 clipped target still uses that chosen R(x). R303 repeats the same original interface: /tmp/r303_geometry.md lines 3–18.
2. Native hardband: /Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md §1, lines 5–13, fixes one complete input f, defines G_s=sup_(a≤L≤b) P_s,L*f, works on 2λ<G0≤4λ, and gives the original FIRST. Lines 123–129, especially line 125, explicitly call R_h the “ORIGINAL hard winner” at that output.
3. The same native source contract is explicit in /Users/zhengzhihao/Desktop/T/output/cube_general_20261003/UNCUT_FIRST_LEDGER.md lines 5–14: same complete positive input μ=f dy, hard ceiling G0/q≤16/3, and the hard zero-mask term evaluated at “its own hard winner.” Its review, UNCUT_FIRST_LEDGER_REVIEW.md line 13, explains the relation q=G_sigma≥(1−sigma)^n G0. That q relation gives a softness margin from the full-source hard maximum; it is not itself a hard cap for another measure.
4. For the native near-pair theorem, /Users/zhengzhihao/Desktop/T/output/cube_general_20261003/signed_band_geometry/hard_soft_witness_route.md §HS1, lines 7–12, retains the complete original μ and states sup_(a≤R≤b) h_R*μ(x)≤C_hq. The hard-winner response/qualification is carried separately at lines 20–25. This is the all-radius ceiling needed by that native argument, not merely the value at a chosen radius.

## Distinctions for reuse

- Same-radius cap: R302’s cap is at R(x) for each accepted receiver, for ν. It does not imply ν(Q_t(x))≤4λt^n for other t∈[a,b]. The implication needs an independently stated all-radius cap.
- Hard-max equality: R302’s notation R(x) is an actual selected scale in its rows; the R302 source text does not assert h_R*f(x)=G0(x)=sup_t h_t*f(x). The native GENERAL reduction’s hard winner belongs to its own full-source selector contract.
- Source identity: R302’s ν is arbitrary in its theorem statement. It is not licensed to rename it f or to claim ν≤f. A ν obtained as a positive restriction of the native f would inherit its hard upper caps by monotonicity, provided the receiver set and radii remain those of the native event; arbitrary ν does not.
- q: q∈[3λ/4,λ] is the common soft FIRST level. The hard band separately supplies G0/q≤16/3. The range of q alone is no hard response cap and does not identify a hard maximizing radius.

Therefore the safe historical statement is: a valid native full-source hard-winner/all-radius-cap interface exists for GENERAL_CURRENT_REDUCTION; R302’s independently stated arbitrary-(β,ν), same-radius interface has not been shown here to be that same interface. No absence claim beyond the inspected source text is intended.

## R314 follow-up: upstream selector and source ancestry

The upstream check separates the two issues more sharply:

- **Restricted source domination is proved for the R237/R112 hard tail.** `rounds/237/research.zip::source_ledger.md`, SL1 table rows 17–23 and SL3 lines 81–85, records the chain `ν_V≤σ_V≤α_V=μ_hi,ω|_V≤f dz` and disjoint terminal leaves. `rounds/112/research.zip::proof.md`, lines 401–407, gives the same current R112 object (`ν_V≤σ_V≤α_V`) but its selector interface only states `h_{R(x)}f(x)≤4λ` at the selected R(x), not a maximizing identity. This is genuine source domination for those frozen ν_V objects, not for an arbitrary ν in the standalone R302 theorem.
- **The all-radius cap is inherited from the native hardband, independently of whether R(x) is the maximizer.** `rounds/244/research.zip::receiver_ledger.md`, RL1 lines 9–29, traces the ancestor to `GENERAL_CURRENT_REDUCTION.md` lines 5–13, uses `P_{0,R}=h_R`, and explicitly records `(h_R*f)(x)≤4λ≤(16/3)q` for every `R∈[a,b]` on the same original E. Positivity then passes that cap to each R237/R112 restriction ν_V≤f. Thus a matched R237/R112 receiver/source slot can supply the all-radius ceiling needed by R302 even when its retained selected R(x) is not known to maximize. The old abstract R302 contract does not itself perform this ancestry matching.
- **No original equality R(x)=argmax is certified for the R107/R112/R302 slot.** R107 `research.zip::proof.md`, R1 lines 899–913, names original selectors `L_s(x),R(x)` and gives only the selected-radius inequality `h_{R(x)}f(x)≤4λ≤C_hq` at lines 905–911. R112 repeats the selected-radius form at lines 401–407. The R244 all-scale bound is stronger as a cap, but it does not make the selected `R(x)` a maximizing selector. By contrast, the later native GENERAL text explicitly calls `R_h` the original hard winner (GENERAL_CURRENT_REDUCTION.md §7, line 125); `G_0` is the hard-family supremum in §1, lines 5–13, and `UNCUT_FIRST_LEDGER.md` lines 9–14 says the hard zero-mask term is evaluated at its own hard winner. Those native statements support the `R_h` winner contract for that event, not identity with R107/R112’s symbol R(x).

Updated applicability verdict: **source-cap inheritance is available for the identified R237/R112 hard submeasures when the exact original receiver event is retained; hard-max equality for the old R302/R107/R112 selected R(x) remains unlocated.** Consequently the all-radius hard-cap hypothesis can be imported into a carefully matched old-slot application by the source domination plus R244’s same-E all-scale hardband. One must still not claim the stronger equality `h_{R(x)}f(x)=G_0(x)` or silently identify `R(x)=R_h`.

