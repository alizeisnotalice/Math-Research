#!/usr/bin/env python3
"""Exact finite physical L1 hard-contact diagnostics; no dependencies."""
from fractions import Fraction as Q
from collections import Counter
from pathlib import Path
import json
counts=Counter(); nonzero=Counter()
def ck(name,test):
 counts[name]+=1
 assert test,name

def box(center,R): return tuple((x-R/2,x+R/2) for x in center)
def vol(B):
 out=Q(1)
 for lo,hi in B: out*=max(Q(0),hi-lo)
 return out

def inter(*Bs): return tuple((max(z[0] for z in zs),min(z[1] for z in zs)) for zs in zip(*Bs))
def source(n,slab): return ((Q(0),slab),)+((Q(-1,8),Q(1,8)),)*(n-1)
def nu(n,slab,*Bs): return vol(inter(source(n,slab),*Bs))/(3*Q(1,4)**(n-1))
def center(n,g):return (-g,)+(Q(0),)*(n-1)
def avg(n,g,R): return max(Q(0),R/2-g)/(3*R**n)
def winner(n,g):return min(Q(2),max(Q(1),2*n*g/(n-1)))
def normalize(x):
 if isinstance(x,Q): return str(x)
 if isinstance(x,dict):return {k:normalize(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [normalize(v) for v in x]
 return x

def stage(ns,name):
 start=sum(counts.values()); summaries=[]
 for n in ns:
  receivers=[]
  for R in [Q(1)+Q(i,8) for i in range(9)]:
   g=(n-1)*R/(2*n); G=avg(n,g,R); cb=box(center(n,g),R)
   ck('winner_formula',winner(n,g)==R)
   ck('positive_source_capture',nu(n,Q(3),cb)==(R/2-g)/3>0)
   for r in [Q(1)+Q(i,32) for i in range(33)]+[2*g,R]:
    if 1<=r<=2: ck('winner_grid',avg(n,g,r)<=G)
   # Outside the interior-winner range, clipped endpoint winners.
   for gg in [Q(0),Q(n-1,4*n),Q(n-1,n)+Q(1,16)]:
    rr=winner(n,gg)
    for r in [Q(1),Q(5,4),Q(3,2),Q(7,4),Q(2)]:ck('clipped_winner_grid',avg(n,gg,r)<=avg(n,gg,rr))
   for slab in [Q(3),Q(1,8),Q(1,2)]:
    ck('restricted_source',nu(n,slab,cb)<=nu(n,Q(3),cb))
    for delta in [Q(0),Q(1,32*n),Q(1,8*n)]:
     if R+2*delta<=2:
      big=box(center(n,g),R+2*delta); shell=nu(n,slab,big)-nu(n,slab,cb)
      bound=G*((R+2*delta)**n-R**n)
      ck('winner_shell',0<=shell<=bound)
      nonzero['shell']+=shell>0
    for chosen in [Q(1),Q(5,4),Q(7,4)]:
     delta=Q(1,32*n)
     if chosen+2*delta<=2:
      small=box(center(n,g),chosen); big=box(center(n,g),chosen+2*delta)
      defect=chosen**n*(G-avg(n,g,chosen))
      shell=nu(n,slab,big)-nu(n,slab,small)
      ck('nonwinner_defect_shell',shell<=G*((chosen+2*delta)**n-chosen**n)+defect)
      ck('defect_nonnegative',defect>=0)
      nonzero['nonwinner_positive_defect']+=defect>0
      nonzero['nonwinner_shell_needs_defect']+=shell>G*((chosen+2*delta)**n-chosen**n)
   receivers.append((g,R,G,cb))
  pair_records=[]
  for (g,R,G,cb),(gg,RR,GG,cc) in zip(receivers,receivers[1:]):
   delta=abs(g-gg)+abs(R-RR)/2
   for slab in [Q(3),Q(1,8),Q(1,2)]:
    diff=nu(n,slab,cb)+nu(n,slab,cc)-2*nu(n,slab,cb,cc)
    nonzero['pair_difference']+=diff>0
    # Geometric inclusion holds even when inflated radii exceed b;
    # max-contact shell bounds are checked only for legal inflations.
    shell1=nu(n,slab,box(center(n,g),R+2*delta))-nu(n,slab,cb)
    shell2=nu(n,slab,box(center(n,gg),RR+2*delta))-nu(n,slab,cc)
    ck('pair_union_shell',0<=diff<=shell1+shell2)
    if max(R,RR)+2*delta<=2:
     ck('pair_contact_shell',diff<=G*((R+2*delta)**n-R**n)+GG*((RR+2*delta)**n-RR**n))
    pair_records.append(dict(R=R,Rnext=RR,slab=slab,delta=delta,difference=diff))
  top=[]
  for eps,h in [(e,e/(16*n)) for e in [Q(1),Q(1,8),Q(1,128)]]+[(None,Q(1,2))]:
   kap=(1+2*h)**n-1; t=max(Q(1),Q(2)-2*h)
   if eps is not None: ck('epsilon_kappa',4*kap<=eps)
   ck('top_ratio',2/t<=1+2*h)
   # Original radius atoms, positive finite receiver quadrature only.
   selected=[receivers[i] for i in [0,4,8]]; weights=list(map(Q,[1,2,3]))
   for slab in [Q(3),Q(1,8)]:
    levels=sorted({t,Q(2)}|{R for _,R,_,_ in selected if R>=t})
    lhs=Q(0)
    for k,r in enumerate(levels):
     ell=r**(-n)-(levels[k+1]**(-n) if k+1<len(levels) else 0)
     M=sum((u*nu(n,slab,cb) for u,(_,R,_,cb) in zip(weights,selected) if R<=r),Q(0))
     lhs+=ell*M
    rhs=sum((u*nu(n,slab,cb)/max(R,t)**n for u,(_,R,_,cb) in zip(weights,selected)),Q(0))
    ck('top_tonelli_terminal_atom',lhs==rhs)
    for g,R,G,cb in selected:
     points=sorted({Q(0),slab,max(Q(0),min(slab,R/2-g)),max(Q(0),min(slab,t/2-g))})
     for lo,hi in zip(points,points[1:]):
      z=(lo+hi)/2
      for transverse in [Q(0),Q(1,8)]:
       distance=max(g+z,transverse); needed=max(t,2*distance)
       envelope=needed**(-n) if needed<=2 else Q(0)
       selected_kernel=max(R,t)**(-n) if distance<=R/2 else Q(0)
       ck('top_kernel_envelope',selected_kernel<=envelope)
    top.append(dict(epsilon=eps,h=h,kappa=kap,t=t,slab=slab,top_M=lhs))
  summaries.append(dict(n=n,source_density=1/(3*Q(1,4)**(n-1)),full_source_mass=Q(1),slab_mass=Q(1,24),receiver_data=[dict(g=g,R=R,G=G,lambda_for_single_receiver=G/4,capture=nu(n,Q(3),cb)) for g,R,G,cb in receivers],pair_records=pair_records,top_records=top))
 return dict(stage=name,dimensions=ns,checks=sum(counts.values())-start,models=summaries)

def main():
 stages=[stage([2],'initial'),stage([3],'endpoint_defect_pressure'),stage([4,8,32],'expanded')]
 result=dict(status='PASS',arithmetic='exact Fraction',scope='Actual positive-volume uniform L1 box and restricted source; real cube intersections and rational scale comparisons. Receiver sums are finite quadrature, not actual FIRST or space-envelope integration.',check_counts=dict(counts),total_checks=sum(counts.values()),nonzero_counts=dict(nonzero),stages=stages)
 Path(__file__).with_suffix('.json').write_text(json.dumps(normalize(result),sort_keys=True,indent=2)+'\n')
 print(json.dumps(normalize({k:result[k] for k in ['status','check_counts','total_checks','nonzero_counts']}),sort_keys=True))
if __name__=='__main__':main()
