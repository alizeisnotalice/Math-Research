# R314 — hard-winner contact pays actual nearby-receiver disagreement

## 1. Precise additional input and the new paid branches

Keep the exact B_H contract from `/tmp/r313_input_302.md`: actual full-soft U_y(x)=alpha(x,y)1_E(x)P_(s(x),L(x))(x-y)/q(x), actual selected hard radius R(x) in [a,b], a<=b<=2a, full J_y(r)=integral_{R(x)<=r}U_y(x)dx, original FIRST f_U(x):=integral U_y(x)beta(dy)<=1, and

    B_H=integral beta(dy)ell_n(dr)1{J_y(r)>=H}
       (1/(2J_y(r))) integral_{R(u),R(w)<=r} U_y(u)U_y(w)
                  nu(Q_(R(u))(u) Delta Q_(R(w))(w))du dw,
    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)dr.   (1)

H>0, so zero rows do not contribute. Formula (1) is the physical-cube B_H in the supplied contract; a different functional with additional z-dependent binary qualification disagreement cannot be substituted for its symmetric difference without separately retaining that disagreement. All original alpha, low-pe,m, full e_g, aspect v0, q, and outer factors remain. This is not a new definition of N or an equivalent quota interface.

The NEW geometric input is an original full source f with nu<=f dx and

    G0(x)=sup_(a<=t<=b)[h_t*f](x)<=4lambda on E.       (2)

For a general selected R retain its actual nonnegative winner defect

    Delta(x)=R(x)^n[G0(x)-h_(R(x))*f(x)]>=0.           (3)

When R is the original full-source hard winner, Delta=0. A selected-radius cap alone does not imply (2) or Delta=0. In the native canonical mixed-witness route, `GENERAL_CURRENT_REDUCTION.md` section 7 and `GENERAL_MIXED_POTENTIAL_LEDGER.md` lines 7–12 explicitly provide the original full-source winner R_h and mu_hi<=f, so this input is valid for their fields. Identification of the older R302 selected R with that native winner is not supplied by this note. Without that identification the theorem below must retain (2),(3) as an explicit qualification; it is not silently imported from R312. The completed upstream audit `/tmp/r314_contact_provenance.md` now verifies more for a carefully matched old slot: R237 records nu_V<=sigma_V<=alpha_V<=f, and R244 records the all-radius hard cap for this same full f on the same original E. Thus (2) and source domination are available for those identified R237/R112 restrictions without invoking the later native winner. This does not certify the old selected R as a maximizer; Delta and D_eff must still be retained. The standalone arbitrary-(beta,nu) R302 theorem does not itself perform this ancestry matching.

Fix h>0 and define

    delta(u,w)=||u-w||_infinity+|R(u)-R(w)|/2,
    t_h=max(a,b-2h),
    kappa_h=(1+2h/a)^n-1,
    A_top=1+n log(b/t_h).                            (4)

Split (1) EXACTLY into the layers r>=t_h, and the lower layers r<t_h. On lower layers split the actual receiver pair by delta<=h or delta>h. Call the three nonnegative pieces B_top, B_contact and B_far respectively. Every original factor in (1) remains in all three pieces. Then

    B_top<=A_top W_nu,                               (5)
    B_contact<=4 kappa_h X+D_eff,
    X=lambda|E|,
    D_eff=integral_E f_U(x)[G0(x)-h_(R(x))*f(x)]dx.    (6)

One may replace 4kappa_h X by 4lambda kappa_h integral I_y beta(dy), where I_y=integral U_y. Moreover

    A_top<=1+log(1+kappa_h).                          (7)

Thus full-source hard winners give the genuinely paid geometric split

    B_H <=[1+log(1+kappa_h)]W_nu+4kappa_h X+B_far.    (8)

For any epsilon>0 choose the physical contact width

    h=(a/2)[(1+epsilon/4)^(1/n)-1].                  (9)

Then

    B_H<=[1+log(1+epsilon/4)]W_nu+epsilon X+B_far.    (10)

For small epsilon the width is of order epsilon*a/n. The finite exponential volume factor is retained exactly; this does not assert a comparable payment at h of order a/sqrt(n). Both the whole top-layer part and the original close-receiver part are paid. The far-receiver remainder and any actual winner defect are NOT paid here.

If X is infinite, the receiver version is only an extended-value estimate; the version with integral I_y beta is still the exact analytic statement. Absorption requires the original finite target/receiver entry. No new matching of X and a target is invented.

## 2. Same-center outward shell from the actual hard maximum

For an original accepted receiver x, put R=R(x). If R+2delta<=b, then

    nu(Q_(R+2delta)(x)\Q_R(x))
       <=f(Q_(R+2delta)(x))-f(Q_R(x))
       <=G0(x)[(R+2delta)^n-R^n]+Delta(x).            (11)

The first inequality uses nu<=f as measures, not a density ceiling. The second uses the hard maximum at the SAME center x and the definition of Delta. For a winner f(Q_R(x))=G0(x)R^n, and its defect vanishes. No cap is used at a virtual center. For fixed selected R that is not a winner, omitting Delta would be false in general.

For two actual cubes C_u=Q_(R(u))(u), C_w=Q_(R(w))(w), the definition of delta gives

    C_w subset Q_(R(u)+2delta)(u),
    C_u subset Q_(R(w)+2delta)(w).

Therefore each side of their symmetric difference lies in the appropriate outward shell of the OTHER cube. Whenever both enlarged scales are legal, (11) gives

    nu(C_u Delta C_w)
       <=sum_(x=u,w) {G0(x)[(R(x)+2delta)^n-R(x)^n]
                                                   +Delta(x)}. (12)

For delta<=h and R(x)>=a, the normalized shell factor is at most kappa_h. On r<t_h and R(u),R(w)<=r, legality is automatic: if t_h>a then R(x)+2delta<=r+2h<b; if t_h=a there are no lower layers. Hence on the exact contact piece,

    nu(C_u Delta C_w)
       <=4lambda kappa_h[R(u)^n+R(w)^n]
                                     +Delta(u)+Delta(w). (13)

The geometry uses the full source only through same-center maximality and source domination. It is not a thin-boundary volume estimate multiplied by an assumed density of nu.

## 3. The contact fee has no scale or row multiplicity

Insert (13) into the contact piece of (1). After that estimate, drop its remaining nonnegative restrictions only to obtain an upper bound. Symmetry of the two endpoints and the true factor 1/(2J_y(r)) imply

    B_contact
      <=4lambda kappa_h integral beta(dy)ell_n(dr)
                        integral_{R(u)<=r}U_y(u)R(u)^n du
        +integral beta(dy)ell_n(dr)
                        integral_{R(u)<=r}U_y(u)Delta(u)du. (14)

Indeed integration of the other endpoint gives the SAME full J_y(r), cancelling its denominator. This uses no upper or lower estimate for that J. All original high-J qualifications were retained until positive domination. The exact inclusive identity

    ell_n([R(u),b])=R(u)^(-n)

and Tonelli reduce (14) to

    B_contact<=4lambda kappa_h integral beta(dy)I_y
       +integral_E f_U(u)Delta(u)R(u)^(-n)du.         (15)

Original FIRST f_U<=1 gives integral beta I<=|E|, proving (6). It is used only at actual original receivers. Radius atoms, including the top atom b, are contained in the displayed inclusive identity; no continuous-crossing assumption is made.

The defect term in (15) is genuine and dimensionally correct. The crude bound is D_eff<=4lambda integral beta I<=4X, which is not a small error. On an actual approximate-winner contact subbranch whose two endpoints satisfy

    G0(x)-h_(R(x))*f(x)<=4lambda zeta,

the same proof pays that subbranch by 4(kappa_h+zeta)X. The complementary receiver pairs must remain. This is an exact checkable winner-defect qualification, not a consequence of the original selected hard cap.

## 4. All top layers use a single hard-source column

The top-layer price needs neither winner identity nor source domination nu<=f. It follows solely from the original FIRST and actual capture geometry. Let

    M_y(r)=integral nu(dz)A_yz(r).

The variance inequality Q_y(r)/J_y(r)<=M_y(r) gives

    B_top<=integral beta(dy)ell_n(dr)1{r>=t_h}M_y(r).

Tonelli, including the endpoint atom, yields

    B_top<=integral_E f_U(x)
       nu(Q_(R(x))(x))/max(R(x),t_h)^n dx.            (16)

For each source z, the actual spatial kernel in (16) is bounded by

    sup_(t_h<=r<=b) h_r(x-z).

If R(x)<=t_h its cube is contained in Q_(t_h)(x) and its denominator is t_h^n. If R(x)>t_h it is exactly a member of the displayed hard family. Only after original FIRST f_U<=1 do we extend x to all space and integrate this positive envelope. Its integral is exactly 1+n log(b/t_h), so (5) follows with ONE nu source charge.

Finally, if t_h=b-2h>=a, then b/t_h=1+2h/t_h<=1+2h/a. If t_h=a, then b<=a+2h gives the same inequality. This proves (7). When a=b, the entire layer measure is its top atom and (5) alone pays B_H<=W_nu; the lower-layer contact/far pieces are empty. This case does not need a positive-width geometric argument.

Unlike a sum of prices over many thin radius windows, (16) pays the entire terminal layer interval once. No hard source is copied per row, pair or scale. This is why the upper physical endpoint does not invalidate the contact payment.

## 5. Exact original target and all retained costs

Under the SAME winner/source-domination hypotheses, insert (10) into the already proved R302 entry at its original H. With the equal-coefficient choice H=sqrt(d A_n/(4lambda)), that entry is

    T_target<=4sqrt(lambda d A_n)(W_beta+W_nu)+2B_H.

The new valid continuation is

    T_target<=4sqrt(lambda d A_n)(W_beta+W_nu)
       +2[1+log(1+epsilon/4)]W_nu
       +2epsilon X+2B_far.                          (17)

For a nonwinner include +2D_eff, without deleting it. Alternatively retain the original unequal-source/receiver version of the R302 entry and substitute (8); the contact theorem itself does not choose H or alter d. In all cases

    lambda d=(4/3)kappa0 psi_inf/v0

retains the original low-m, aspect and outer costs. Every original positive outer multiplier Lambda multiplies all terms of (17) inside the original outer integration. No free outer time or source normalization is introduced. The epsilon X term can be absorbed only if the established complete original ledger licenses that SAME finite X; this note does not assert such an entry merely from (17).

The exact unpriced geometric part is

    B_far = original integral (1) restricted to
                   r<t_h and delta(u,w)>h.           (18)

It contains the original full U at both endpoints, all full e_g/alpha qualifications, the same J, H and selected scales. Neither a source restriction nor a posterior is recomputed. We have not proved its root price. If the old selector is not known to be a winner, the explicit D_eff in addition remains, and if no full f dominating nu with (2) is available, the shell-contact theorem cannot be invoked for that old input at all. The unconditional top-layer theorem (5) still applies. In particular, the source/event matching certified by `/tmp/r314_contact_provenance.md` permits the full estimate WITH +2D_eff for the identified old R237/R112 slot, using nu_V<=f and the R244 same-E all-radius cap. It does not permit the defect-free version of (17) there. No claim about arbitrary unrelated beta,nu or receiver sets is added.

For the native canonical R_h fields, (2) and winner identity are indeed established. They justify the geometric B_H contact lemma constructed from those fields. This does NOT itself turn a two-receiver B_H contact subbranch into an actual positive subbranch of the one-receiver native R_HP; a legitimate original entry connecting that B_H to the intended native target remains necessary. Thus no unsupported R312-to-R302 history mapping is used.

## 6. Why this changes the failed packing strategy, and what it does not do

The initially considered pure soft-row grouping was not used: comparable unqualified P_(s,L)(x-y) need not make the row-gated cumulative captures comparable, and changing a quota threshold after dropping alpha can discard actual positive traffic. No such comparison is assumed in (11)–(17).

Instead the new payment uses actual full-source hard maximality to obtain a SOURCE-MASS contact bound at each accepted center. This is information absent from the selected-radius cap alone and from an unweighted crossing-chain count. The two shell bounds are integrated with their actual row/prefix weights, producing a complete fee rather than a boundary-volume heuristic. It pays an actual positive part of B_H, together with the full terminal layers, while keeping every remaining incidence explicit.

For wider contact widths the factor kappa_h=(1+2h/a)^n-1 can be exponential. Setting h proportional to a/sqrt(n) and dropping that factor would be invalid. This proof supplies no root contact estimate at that wider scale and no source-root estimate for (18). The global theorem therefore remains open. It also does not claim that old N_(H,d) is identical to B_H or that the quota target is fully paid.

## 7. Executed finite source-geometry checks

The script below uses actual axis-aligned cubes and an L1 full source f=1_(Q_1). Centers stay inside Q_1 and physical radii lie in [1,2]. For these centers each one-dimensional cube average is nonincreasing in radius, so the true full hard winner is R=1; its exact value is computed by intersection volume. The tests include both winner selections and nonwinner selections with their required defects, and full/half-box dominated L1 hard sources. Three stages cover n=1,2; n=4,8; and n=16. A fresh isolated Python process passed 1380 same-center shell checks, 690 two-receiver contact checks, 270 winner-zero-defect checks and 540 nonwinner-defect checks. All comparisons are exact Fraction arithmetic. This verifies the shell and defect geometry, not the unproved far-receiver budget or the original historical selector identification. The analytic proof gives the original continuum source payment.

```python
from fractions import Fraction as F
from itertools import product
from math import prod
ct={'same_center_shell':0,'two_receiver_contact':0,'winner_zero_defect':0,'nonwinner_defect':0}
def box(center,side):return [(x-side/2,x+side/2) for x in center]
def overlap(*boxes):
 return prod(max(F(0),min(B[i][1] for B in boxes)-max(B[i][0] for B in boxes)) for i in range(len(boxes[0])))
for dims in ((1,2),(4,8),(16,)):
 for n in dims:
  full=[(F(-1,2),F(1,2))]*n
  half=[(F(0),F(1,2))]+[(F(-1,2),F(1,2))]*(n-1)
  for c,step,Ru,Rw,nu in product((F(0),F(1,10),F(1,4)),(F(0),F(1,100),F(1,20)),(F(1),F(5,4),F(3,2)),(F(1),F(5,4),F(3,2)),(full,half)):
   u=(c,)*n;w=tuple(c+step*(-1 if i%2 else 1) for i in range(n))
   Cu=box(u,Ru);Cw=box(w,Rw)
   G_u=overlap(full,box(u,F(1)));G_w=overlap(full,box(w,F(1)))
   D_u=G_u*Ru**n-overlap(full,Cu);D_w=G_w*Rw**n-overlap(full,Cw)
   assert D_u>=0 and D_w>=0
   if Ru==1:assert D_u==0;ct['winner_zero_defect']+=int(Ru==1)
   if Ru>1:ct['nonwinner_defect']+=1
   delta=max(abs(x-y) for x,y in zip(u,w))+abs(Ru-Rw)/2
   if Ru+2*delta>2 or Rw+2*delta>2:continue
   Eu=box(u,Ru+2*delta);Ew=box(w,Rw+2*delta)
   shellu=overlap(nu,Eu)-overlap(nu,Cu)
   shellw=overlap(nu,Ew)-overlap(nu,Cw)
   boundu=G_u*((Ru+2*delta)**n-Ru**n)+D_u
   boundw=G_w*((Rw+2*delta)**n-Rw**n)+D_w
   assert shellu<=boundu and shellw<=boundw;ct['same_center_shell']+=2
   diff=overlap(nu,Cu)+overlap(nu,Cw)-2*overlap(nu,Cu,Cw)
   assert diff<=shellu+shellw<=boundu+boundw
   ct['two_receiver_contact']+=1
print('PASS',ct)
```

Only /tmp/r314_geometry.md is owned and written; other authors' files and Git are unchanged.
