# R314 independent preauthor screen

Independent theorem screen PASS under the EXPLICIT full-f domination/maximum/winner hypotheses. Saved BEFORE reading any R314 author proof or provenance note. Own audit only; no Git or other-author files changed.

## Same-center shell contact and exact defect

Assume fixed original f>=0, nu<=f dy, original G(x)=sup_(a<=s<=b)h_s*f(x)<=4lambda on actual accepted receivers, and a<=R(x)<=b. For any δ>=0 with R+2δ<=b, positivity and full-f maximum give

nu(Q_(R+2δ)(x)\Q_R(x))
 <=G(x)[(R+2δ)^n-R^n]+Delta(x),
Delta=R^n[G(x)-h_R*f(x)]>=0.

The shell estimate is dimensionally normalized and uses the ORIGINAL FULL f inside and outside. It is not implied by a selected-radius cap alone. Exact full-f hard winners have Delta=0 even if nu itself is a restricted source and does not share that response equality. No cap at a virtual center or density bound on nu is used.

For actual u,w put δ=||u-w||inf+|R(u)-R(w)|/2. Then each cube lies in the δ-inflation of the other, so their symmetric difference is contained in the union of the two outside shells. With δ<=h and both inflated radii legal,

nu(Q_u Delta Q_w)<=4lambda κ[R(u)^n+R(w)^n]+Delta(u)+Delta(w),
κ=(1+2h/a)^n-1.

## Top auxiliary layers and low-layer near pairs

Let t=max(a,b-2h), h>0. In low layers r<t, actual prefix radii R(u),R(w)<=r imply R+2δ<=r+2h<b on δ<=h. If t=a there are no low layers at all. Define the original B_H top part on ALL r>=t and low parts on r<t, split by δ<=h vs δ>h, keeping original J>=H and every original prefix/near/history/source mask as applicable. This is an exact positive split of the SAME fee, not a replacement of its full J.

For top layers use F=Q/J<=M and positive Tonelli. The layer tail is ell([max(R,t),b])=max(R,t)^(-n), including the terminal b atom. ORIGINAL source FIRST gives rho(x)=integral_beta U_y(x)<=1 BEFORE receiver extension; Q_R is contained in Q_max(R,t). The full hard envelope on [t,b] then pays

BH_top<=[1+n ln(b/t)]Wnu.

Since b/t<=1+2h/a in BOTH t>a and t=a cases, this is <=[1+ln(1+κ)]Wnu. There is no need for FIRST or a hard cap at the enlarged/extended receiver kernel. Actual R must be a receiver field shared across source y, as in the input.

For low-near pairs, the original half in UU/(2J) and symmetry of [R(u)^n+R(w)^n] cancel exactly to the one prefix moment V(r)=integral_prefix U R^n. Swapping layers gives integral_beta ell V=integral_E rho dx<=|E|. Thus

BH_low,near<=4κ X+D_eff,
X=lambda|E|,
D_eff=integral_E rho(x)[G(x)-h_(R(x))*f(x)]dx.

The defect has coefficient ONE, not two: the two endpoint defects combine under the same half/symmetry and then ell tail R^(-n) cancels their R^n normalization. It is nonnegative and generally cannot be discarded. Dropping the original layer/near gates occurs only in this positive upper estimate. Exact full-f winners have D_eff=0.

Hence

BH<=[1+ln(1+κ)]Wnu+4κX+D_eff+BH_far,

where BH_far is the EXACT low-r<t,δ>h part of the original B_H and retains all its original masks. For ε>0 choose h=(a/2)[(1+ε/4)^(1/n)-1], κ=ε/4. This yields the parent's claimed bound with εX, plus the defect whenever winners are not certified. Top is still fully paid when t=a; the source coefficient includes its b atom.

## Scope and ledger obligations

The abstract R302 input only has a selected SAME-radius cap. It does not provide nu<=f, the all-radius full-f maximum or its actual winner identity. These are additional hypotheses unless an original interface supplies them. The native original hard-winner family is a legitimate place to verify them; an identity with the legacy R302 target/outer data cannot be guessed. A matching global target is needed before absorbing local εX; source rho also belongs to the SAME original instance. Original outer Lambda multiplies all fees once inside its actual integral.

This exact top/low-near/far split is not the R313 common-rank initialization split. They are two different positive bounds for BH; adding their paid parts as disjoint credits is invalid without a new common refinement. No root price for BH_far, or for the independent R313 post-rank remainder, is established by this screen. Arbitrary L1 source boundary mass has not been replaced by boundary volume.

## Actual bounded diagnostics

{'shell_inclusion_Fraction': 17550, 'top_ratio_Fraction': 20, 'near_symmetry_Fraction': 3, 'layer_gate_Fraction': 60}

Executed exact Fraction cube-shell inclusion, top-ratio/layer legality and symmetric-prefix coefficient checks. All PASS. These finite geometric/algebraic tests do not certify the full original selector/history/source bridge, winner property or root source price for far pairs. Author/provenance comparison and final delivery binding remain pending.

## Author and provenance comparison

After the independent screen above, read contact_provenance, final geometry and final independent joint note. Geometry PASS: shell bound uses original full-f maximum at the same accepted center, source domination nu<=f, and actual Delta; near double-prefix symmetry and ell tail give coefficient4κX and exactly one D_eff. The all-top-layers source column uses FIRST before positive extension, includes the b atom and cases a=b or t=a, and costs one Wnu. Contact width and volume factor remain explicit; a/sqrt(n) cannot replace a/n without paying the exponential factor. Original BH is physical cube disagreement; any additional marked/history qualification disagreement is not silently substituted or paid.

Provenance note agrees with directly inspected original GENERAL_CURRENT_REDUCTION section7 and GENERAL_MIXED_POTENTIAL_LEDGER section1: native original R_h is the FULL-f hard winner, and mu_hi is dominated by f. It correctly refuses to infer a winner, full-f source domination or all-scale ceiling from abstract R302 selected-radius hypotheses. This note documents an available local native contract, not an identity between its B_H and legacy R302 history or one-receiver R_HP target.

The independent overflow alternative is also valid: close-pair overflow of at least one inflated scale forces BOTH actual radii>b-4h. Dropping pair masks then yields a restricted first moment, paid by the hard envelope on[max(a,b-4h),b]. With h=eta a/n it costs <=(1+4eta)Wnu, and legal shell cost<=4(exp(2eta)-1)X+D_contact. Choosing eta=(1/2)ln(1+epsilon/4) gives the displayed epsilonX+(1+epsilon/2)Wnu bound using ln(1+u)<=u. It is an alternative allocation with a different far residue/width, not an extra endpoint fee to add to the primary top-layer argument.

The earlier concave shared-quota screen was also read before its replacement by the final contact check: FIRST gives C_z(r)<=r^n and Jensen retains the indispensable Wbeta in min(dWbeta,C_z); integrating produces the existing piecewise capped logarithm. It supplies no new generic root expense and no source-shared quota can be inserted without domination. Its scalar spread illustration was expressly not an original cube counterexample.

Author finite checks have the stated scope. Geometry's exact positive-volume L1 boxes verify genuine winner/defect/shell intersections, not an original full-FIRST/history realization. Independent overflow containment/endpoints are exact, but its Decimal exponential/log comparisons are ordinary70-digit diagnostics rather than interval certificates. This auditor independently executed the rational cases recorded above. No general root far-pair or entry-bridge result follows from finite evidence.

Current frozen author bindings:
- /tmp/r314_geometry.md: 154fffa16e5527ee274eae2ab3e0781022a15346943ea6c66b6aa8acda2d3d82
- /tmp/r314_joint.md: 46f4b4afa5371e2763d77cbda6ea6490c1b9014d691b808634cd7683c60c8fe9
- /tmp/r314_contact_provenance.md: e7c3f7d7feb0c65011785712a5bc1f229bf23c615e332addf2a6f6e7af6b2811

## Final integration, provenance spot-check and freeze

Read final checkpoint combined.md, research.tex and README. PASS for all displayed formulas and scope. The main full-BH split retains top ALL r>=t, low near and exact low far; the source constant, epsilon width, nonwinner defect, top atom and local callback2epsilonX/2D_eff are correct. The callback uses the SAME R302 H and original d/aspect/outer multiplier. Local X=lambda|E| must match an established finite original entry before any absorption; no automatic global adoption is asserted. R303 near-window numerator/full-J is not substituted for full variance. R313 rank initialization and the present layer/pair split are not declared disjoint, and R312 native alternative is not added to the old ledger. All independent old source/time/outer/entry gaps remain.

The final geometry author only appended carefully matched source-cap provenance; its analytic proof and code are unchanged. I verified the appended wording still retains old winner Delta/D_eff and makes no arbitrary-(beta,nu) transfer. The native hard winner itself is directly documented in the original GENERAL and mixed-potential interfaces inspected in prior screens.

Additional bounded direct archive spot-check performed: R237 research.zip::source_ledger.md17--25 gives the specific source ancestry and coupled original restrictions; R112 proof.md401--407 gives nu_V<=sigma_V<=alpha_V and its actual selected-radius cap; R244 receiver_ledger.md9--29 explicitly inherits the SAME-original-E all-radius full-f cap and forbids added receivers/out-of-octave scales. These support the source/cap inheritance claimed for matched old slots, not arbitrary new measures. R107 proof.md905--913 formal display specifies only the selected response cap. Its introductory prose line901 DOES refer to an entire hard winner, a hint that must not be hidden; this bounded audit does not certify an explicit retained-R(x)=argmax identity from that prose. Thus the safe status is 'the stronger legacy equality/connector has not been certified by the checked interface', not a claim that no historical winner wording exists. Retaining D_eff makes the delivered estimate valid regardless of that unresolved certification.

The independent actual numeric slab has response (R/2-g)_+/(3R^n) for the tested n>=2, R in[1,2]. On its positive branch the derivative is[ng-(n-1)R/2]/(3R^(n+1)); hence the clipped2ng/(n-1) winner is analytically justified, including all-zero exterior cases. Grid checks are not used as the continuous maximization proof. Full source domination, restricted slabs and nonzero shells/defects are genuine positive-volume L1 geometry; receiver weights are still finite quadrature, not full original FIRST/history samples.

Fresh-run evidence: parent reports isolated local numeric4431 and geometry2880 exact Fraction checks PASS with numeric JSON byte-identical. I read checkpoint logs and verified final numeric JSON SHA256c4343cdf70091d52ae2230b61a537251ddb3bd370f3ef8fb12c80cb440e7015c for both temporary and checkpoint copies. Independent overflow log reports3260 checks, correctly split into1424 exact rational geometry and1836 ordinary70-digit Decimal exponent/log diagnostics. These are not all interval/exact checks. This auditor's separately executed exact cases are recorded above; parent runs are attributed to the parent. No redundant final rerun was needed.

Final bounded verdict PASS. New conditional/native contact geometry and unconditional top-column payment are valid. Low-layer far-receiver source budget, actual legacy winner defect/identity, original global matching/absorption and every other retained old slot remain unresolved. General root weak bound is not proved. Audit FROZEN.

### Final byte bindings
- /tmp/r314_geometry.md: 3673028dea173a848d2c4b065fa4250348e589b8780185cbbb7e1bd5612b9ac9
- /tmp/r314_joint.md: 46f4b4afa5371e2763d77cbda6ea6490c1b9014d691b808634cd7683c60c8fe9
- /tmp/r314_contact_provenance.md: e7c3f7d7feb0c65011785712a5bc1f229bf23c615e332addf2a6f6e7af6b2811
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round314_20261018_final_checkpoint/combined.md: 29c99c4c694b9854aa287bb9ec83b72f558665818a9d6bcb90c042b29d2f5acc
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round314_20261018_final_checkpoint/research.tex: f30ad1bafa8b28bc55e68b15351f0b00e4a889f266b5825007761f740df8474f
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round314_20261018_final_checkpoint/README.md: 09afc6239fc6806b3da902048d7c6d759f04e545053dbc85fbd0d187d3d16341
- /tmp/r314_numeric.py: 3b74af002be6df818343ef36eb7edf4009ac3179f9b2f0d4b12559436665b9da
- /tmp/r314_numeric.json: c4343cdf70091d52ae2230b61a537251ddb3bd370f3ef8fb12c80cb440e7015c
- /tmp/r314_numeric.md: 1d8ac0fa24aa32abd90e5a0181445ac416bcdcfaa7beb9696a2f1477bd5d60fe
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round314_20261018_final_checkpoint/numeric.py: 3b74af002be6df818343ef36eb7edf4009ac3179f9b2f0d4b12559436665b9da
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round314_20261018_final_checkpoint/geometry_checks.py: a97f36e04937d670ef93a563fce6decd35bd1e67c0551898f7749f042986463f
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round314_20261018_final_checkpoint/joint_checks.py: 8f1d1410b683c1c8c70674d993839b64ac2316ef2ca14ebdb2ff8397263b160b
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round314_20261018_final_checkpoint/numeric_checks.log: e8c7983a7a6eacb41adeda9f986c60870bafeee2552f8763b577d5186a530009
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round314_20261018_final_checkpoint/geometry_checks.log: b55198032d5236df6e8ef5e676487cb8b8936a509b8fcf4e9decfd9717e0c9c8
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round314_20261018_final_checkpoint/joint_checks.log: d8f3730cfe60e4ae8d32853dc5b80856277005b9d86c0199c6667c9021d3fb80
