from fractions import Fraction as F
from decimal import Decimal, localcontext
from itertools import product
ct={'close_geometry':0,'endpoint_implication':0,'shell_exponent':0,'top_fee':0}
with localcontext() as ctx:
 ctx.prec=70
 def dec(q): return Decimal(q.numerator)/Decimal(q.denominator)
 for n,eta,b in product((1,2,8,64),(F(1,64),F(1,8),F(1,2)),
                        (F(1),F(129,128),F(5,4),F(2))):
  a=F(1);h=eta*a/n
  lower=max(a,b-4*h)
  fee=Decimal(1)+n*dec(b/lower).ln()
  assert fee<=dec(1+4*eta)+Decimal('1e-60');ct['top_fee']+=1
  for ru,rw,shift in product((a,(a+b)/2,b),(a,(a+b)/2,b),
                              (F(0),h/4,h/2)):
   delta=shift+abs(ru-rw)/2
   if delta>h: continue
   assert shift+rw/2<=ru/2+delta
   assert shift+ru/2<=rw/2+delta
   ct['close_geometry']+=1
   if max(ru+2*delta,rw+2*delta)>b:
    assert min(ru,rw)>b-4*h
    ct['endpoint_implication']+=1
   for radius in (ru,rw):
    lhs=dec((1+2*delta/radius)**n)
    rhs=(2*dec(eta)).exp()
    assert lhs<=rhs+Decimal('1e-60')
    ct['shell_exponent']+=1
print('PASS',ct)
