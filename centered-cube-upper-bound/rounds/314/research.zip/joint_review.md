# R314 — independent contact check and the exact contract defect

## 1. Scope and checked statement

This short auxiliary check verifies the close-pair payment proposed by the parent. It is valid under the native full-source hard-winner contract. It is **not** an unconditional addition to the arbitrary-(beta,nu), same-selected-radius R302 contract. Provenance is recorded separately in `/tmp/r314_contact_provenance.md`; the input definitions are `/tmp/r313_geometry.md` and `/tmp/r313_input_302.md`.

Keep their actual U_y(x), selected R(x), FIRST integral U_y(x)beta(dy)<=1, J_y(r), physical cube capture, ell_n and B_H. In particular

    B_H=integral beta(dy)ell_n(dr) 1{J_y(r)>=H}/(2J_y(r))
          integral_{R(u),R(w)<=r} U_y(u)U_y(w)
             nu(Q_(R(u))(u) symmetric_difference Q_(R(w))(w))du dw.

There is no division when J=0. All source/history masks, common softness, q, low-pe/m and aspect costs remain in the original U. Fix eta>0 and set

    h=eta*a/n,
    delta(u,w)=|u-w|_infinity+|R(u)-R(w)|/2,
    c_eta=exp(2eta)-1,
    v(x)=integral U_y(x)beta(dy)<=1,
    X=lambda|E|.

Let B_H^close be the positive restriction delta<=h. Assume a full source f, nu<=f, and measurable G0(x)<=4lambda such that, at retained actual receivers,

    f(Q_t(x))<=G0(x)t^n for R(x)<=t<=b.

Write the nonnegative selected-radius contact defect

    Delta(x)=G0(x)R(x)^n-f(Q_(R(x))(x)),
    D_contact=integral_E v(x)Delta(x)R(x)^(-n)dx.

The verified general-defect receipt is

    B_H^close <=4lambda c_eta integral I_y beta(dy)
                      +(1+4eta)W_nu+D_contact
              <=4c_eta X+(1+4eta)W_nu+D_contact.       (1)

The second inequality uses FIRST and may be read with finite receiver truncations if X is used for absorption. A native actual hard winner has Delta=0. Merely knowing G0<=4lambda does not set Delta to zero. In particular, contact is f(Q_R)=G0 R^n, **not** f(Q_R)=4lambda R^n.

## 2. Independent proof, including the top-scale fallback

The geometry gives Q_(R(w))(w) subset Q_(R(u)+2delta)(u), and its version with u,w exchanged. When both inflated sides are <=b, domination nu<=f and the all-radius ceiling give

    nu(Q_u symmetric_difference Q_w)
      <=G0(u)[(R(u)+2delta)^n-R(u)^n]
        +G0(w)[(R(w)+2delta)^n-R(w)^n]
        +Delta(u)+Delta(w)
      <=4lambda c_eta[R(u)^n+R(w)^n]+Delta(u)+Delta(w). (2)

Indeed R>=a and delta<=eta*a/n imply (1+2delta/R)^n<=exp(2eta). This estimates the true source masses of shells using full-source contact; it does not use a source density or boundary-volume approximation.

Insert (2) into the double integral. Drop only positive pair restrictions and 1{J>=H}. The two symmetric terms cancel the factor 2J. Tonelli and ell_n([R,b])=R^(-n), including its b atom, yield exactly the first term and D_contact in (1). Original FIRST is used only at the actual receivers. Additional original pair masks bounded by one can be retained and then positively dropped in the same proof.

For the remaining close pairs, at least one inflated side exceeds b. If, for example, R(u)+2delta>b, then R(u)>b-2h and |R(u)-R(w)|<=2h, so **both** actual sides exceed b-4h. Use nu(Q_u symmetric_difference Q_w)<=nu(Q_u)+nu(Q_w), drop the remaining pair restriction, and cancel 2J again. This part is at most the original first moment restricted to R>b-4h. FIRST, followed by positive extension, bounds it by

    [1+n log(b/t0)]W_nu,
    t0=max(a,b-4h).

Here only the usual hard envelope over [t0,b] is used. Since 0<=b-t0<=4h and t0>=a,

    n log(b/t0)<=n(b-t0)/t0<=4eta.

This proves the endpoint term in (1), including b-a<=4h, b=a, and radius atoms. A strict overflow uses strict R>b-4h; enlarging to the closed envelope [t0,b] is harmless.

## 3. Reuse and exact limitation

For a true native hard winner, take eta=(1/2)log(1+epsilon/4). Then

    B_H^close<=epsilon X+(1+epsilon/2)W_nu.            (3)

The complementary positive allocation B_H^far, delta>eta*a/n, is retained in full. In the R302 displayed entry, **if that target has independently been identified with this native contract**, substitution gives

    T_target<=4sqrt(lambda*d*A_n)(W_beta+W_nu)
               +2epsilon X+(2+epsilon)W_nu
               +2D_contact+2B_H^far.                 (4)

An original outer Lambda multiplies every term. No global target entry or finite-X absorption is certified here. The legacy R302 statement alone does not supply nu<=f, the all-radius G0 ceiling, or the selected-radius contact identity. If source domination or the ceiling is unavailable, (1) itself is not authorized; D_contact repairs only the absence of exact contact under the other stated premises.

The parent/Astra alternative pays the whole ell_n layer r>=max(a,b-2h), making all lower-layer close inflations legal. That is a different, potentially sharper allocation. It is an **alternative** to this overflow allocation; their endpoint fees must not be added. This note records only the independent check and the contract defect, not a separate new theorem count.

The initially screened fixed-z concavity route yielded only C_z(r)=integral beta A_yz(r)<=r^n and integral beta min(d,A)<=min(dW_beta,C_z). Its integrated price is the existing capped logarithm in dW_beta/a^n. It supplies no new general payment for N_(H,d); no source-shared quota is substituted for the original per-row quotas.

## 4. Executed minimal geometry checks

The following standard-library code returned `PASS {'close_geometry': 894, 'endpoint_implication': 530, 'shell_exponent': 1788, 'top_fee': 48}`. Containment and endpoint tests use exact Fractions; the exponential/log evaluations are 70-digit numerical diagnostics, not interval certificates. The proof of (1) is the analytic argument above. These diagnostics do not claim to realize the full original soft-kernel history or verify the native/legacy selector identification.

```python
from fractions import Fraction as F
from decimal import Decimal, localcontext
from itertools import product
ct={'close_geometry':0,'endpoint_implication':0,'shell_exponent':0,'top_fee':0}
with localcontext() as ctx:
 ctx.prec=70
 def dec(q): return Decimal(q.numerator)/Decimal(q.denominator)
 for n,eta,b in product((1,2,8,64),(F(1,64),F(1,8),F(1,2)),
                        (F(1),F(129,128),F(5,4),F(2))):
  a=F(1);h=eta*a/n
  lower=max(a,b-4*h)
  fee=Decimal(1)+n*dec(b/lower).ln()
  assert fee<=dec(1+4*eta)+Decimal('1e-60');ct['top_fee']+=1
  for ru,rw,shift in product((a,(a+b)/2,b),(a,(a+b)/2,b),
                              (F(0),h/4,h/2)):
   delta=shift+abs(ru-rw)/2
   if delta>h: continue
   assert shift+rw/2<=ru/2+delta
   assert shift+ru/2<=rw/2+delta
   ct['close_geometry']+=1
   if max(ru+2*delta,rw+2*delta)>b:
    assert min(ru,rw)>b-4*h
    ct['endpoint_implication']+=1
   for radius in (ru,rw):
    lhs=dec((1+2*delta/radius)**n)
    rhs=(2*dec(eta)).exp()
    assert lhs<=rhs+Decimal('1e-60')
    ct['shell_exponent']+=1
print('PASS',ct)
```

Only `/tmp/r314_joint.md` is written; other authors' files and Git are unchanged.
