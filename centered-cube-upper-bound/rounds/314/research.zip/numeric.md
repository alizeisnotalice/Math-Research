# R314 actual positive-L1 hard-contact diagnostic

The standalone standard-library script passes 4,431 exact Fraction assertions in fresh processes. Three stages: n=2 initial (873 checks); n=3 endpoint/nonwinner-defect pressure (875); n=4,8,32 expanded (2,683). No repository files or prior numeric scripts are imported.

The complete source f is uniform with total mass 1 on [0,3] × [-1/8,1/8]^(n-1), of density 1/[3(1/4)^(n-1)]. The tested hard sources are this f and its restrictions to first-axis slabs [0,1/8] and [0,1/2], retaining the original density (masses 1/24 and 1/6). Thus every source is genuinely positive-volume L1 and nu<=f. Cube R means side length R, with halfwidth R/2.

Receivers are x=(-g,0,...,0); R runs 1,9/8,...,2 and g=(n-1)R/(2n). All transverse thin coordinates are fully covered. Direct tensor cube/source intersections verify f(Q_R)=(R/2-g)/3>0. The asserted candidate maximizer R*=clip_[1,2](2ng/(n-1)) is checked against a rational 33-scale grid, the activation point 2g when legal, and the exact candidate. Separate g below/above the interior regime tests clipped endpoint winners. These finite comparisons do not prove continuous maximization; the derivative proof is separate.

With G=f(Q_R)/R^n at the candidate winner, all 375 legal same-center shell checks satisfy nu(Q_(R+2delta)\Q_R)<=G[(R+2delta)^n-R^n]. There are 192 positive shell masses, so the fixture does not erase the boundary mechanism. Nonwinner selected radii 1,5/4,7/4 are checked in 405 defect inequalities using Delta=R^n[G-h_R*f]>=0. Of these, 95 require a positive defect: the shell exceeds the bound with Delta omitted. This confirms the distinction between winner contact and a selected-radius ceiling within these fixtures.

For adjacent winner receivers, delta=|g-g'|+|R-R'|/2 is exact. All 120 source symmetric-difference checks satisfy the sum of the two actual outside-shell masses; 96 differences are positive. The 90 pairs whose two inflated radii remain <=2 also satisfy the contact shell upper bound. At n=2, R=1 and R'=9/8, the full-source difference is 1/96 and delta=3/32. No all-scale hard cap is invoked for illegal inflations. G varies with receiver; lambda=max G/4 may provide a common cap, but the sharper tested bounds use each actual G, never replace G by an asserted equality 4lambda.

For epsilon=1,1/8,1/128 and every tested n, h=epsilon/(16n), kappa=(1+2h)^n-1 and exact rational comparison gives 4kappa<=epsilon. With t=max(1,2-2h), 2/t<=1+2h also passes. A further h=1/2 fixture checks t=a=1 explicitly. For three finite nonnegative receiver weights 1,2,3, all 40 top-layer identities verify

    integral_[t,2] ell_n(dr) sum_(R_i<=r) u_i nu(Q_Ri)
    = sum_i u_i nu(Q_Ri)/max(R_i,t)^n.

The finite layer weights are r^(-n)-r_next^(-n), including terminal 2^(-n); receivers with R<t remain in every top prefix. There are also 504 pointwise kernel checks against the actual hard-scale envelope with scale max(t,2||z-x||inf), using source interval cells and transverse center/boundary samples. These are finite point checks, not a space-envelope integral or FIRST theorem.

Scope: this verifies actual source geometry and finite rational interface diagnostics. Receiver sums are finite quadrature, not a realization of full original FIRST, legacy selectors or low/e/m history. Numerical winner-grid evidence does not supply continuous winner proof or identify R302's arbitrary nu with this native full f. No root-order price for far pairs or general dimension order is asserted.

Reproduce:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r314_numeric.py
```

JSON is written beside the script, with deterministic exact rational values, stage counts, physical receiver/source parameters and nonzero diagnostics. No floating-point values decide any assertion.
