from fractions import Fraction as F
from itertools import product

def conditional(weights,values,j):
    den={}; num={}
    for x,w in weights.items():
        key=x[:j]; den[key]=den.get(key,F(0))+w
        num[key]=num.get(key,F(0))+w*values[x]
    return {x:(num[x[:j]]/den[x[:j]] if den[x[:j]] else F(0)) for x in weights}
def avg(weights,values): return sum(w*values[x] for x,w in weights.items())
counts={}; positives=0
for label,ns,seeds in [('initial',[1,2,3],[0,1]),('correlation',[2,3,4],[2,3,4]),('matched_expanded',[4,6,9],[5,6])]:
    num=0
    for n,seed in product(ns,seeds):
        bits=list(product([0,1],repeat=n)); zero=(0,)*n; p=F(1,2**n)
        raw={x:F(1+((sum((j+1)*x[j] for j in range(n))+seed*sum(x)**2)%7)) for x in bits if x!=zero}
        total=sum(raw.values()); weights={zero:p}
        weights.update({x:(1-p)*r/total for x,r in raw.items()})
        capture={x:F(x==zero) for x in bits}
        for mode in range(3):
            mark={x:F((sum((j+1)*x[j] for j in range(n))+mode+seed)%5,4) for x in bits}
            ps=[conditional(weights,capture,j) for j in range(n+1)]
            aa=[conditional(weights,mark,j) for j in range(n+1)]
            energy=F(0); amark=F(0); cov=F(0)
            for j in range(1,n+1):
                dp={x:ps[j][x]-ps[j-1][x] for x in bits}
                da={x:aa[j][x]-aa[j-1][x] for x in bits}
                energy+=sum(weights[x]*dp[x]**2 for x in bits)
                amark+=sum(weights[x]*da[x]**2 for x in bits)
                cov+=sum(weights[x]*dp[x]*da[x] for x in bits)
            ma=avg(weights,mark)
            assert energy==p*(1-p)
            assert amark==sum(weights[x]*(mark[x]-ma)**2 for x in bits)
            assert avg(weights,{x:mark[x]*capture[x] for x in bits})==p*ma+cov
            assert cov*cov<=energy*amark
            # Nested coordinate cut masses and exact first-failure partition.
            masses=[sum(weights[x] for x in bits if all(a==0 for a in x[:j])) for j in range(n+1)]
            assert sum(masses[j-1]-masses[j] for j in range(1,n+1))==1-p
            assert all(masses[j]<=masses[j-1] for j in range(1,n+1))
            # Full-f continuous packet realization: each bit cell is an n-cube
            # of side 1/8 centered at coordinates 1/4 or 3/4, mass weights[x].
            # Actual center blocks side l=1/16 near (1/2,...),R=1 and
            # (1/4,...),R=1/2 capture all packets / precisely zero packet.
            l=F(1,16); Eu=l**n; Ev=l**n; mu=F(1); mv=p
            assert mu/F(1)**n==mv/F(1,2)**n==1 # actual q matching
            zeta=Eu*Ev/mv*(1-mv/mu)
            native_energy=zeta*energy
            Jmax_actual=Eu+Ev/mv; X=Eu+Ev
            assert native_energy<=Jmax_actual*X
            # Expanded native far: 2^n>e^sqrt(n), certified by e<3 and
            # sqrt(n)<=ceil(sqrt(n)); no floating threshold decision.
            if label=='matched_expanded':
                k=next(k for k in range(n+1) if k*k>=n)
                assert 2**n>3**k
            positives+=int(cov!=0); num+=1
    counts[label]=num
print('PASS',counts,'total',sum(counts.values()),'nonzero covariance',positives)
print('Fraction Doob identities and genuine continuous source/center blocks. Marks diagnostic; no native high-rank/history qualification.')
