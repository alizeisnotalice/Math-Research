% User's 24-step wide-window row law. Deterministic quadrature, not a proof.
% A=1+d is the ONE-row atomic centered average; averaged over U and x.
% At a fixed L endpoints use distinct atom cells (L in I, K>=48).
ks=[1 2 3 4 5 6 8 9 10 11];
coeff=[-54 -9/2 36 3;17 5/4 -19/2 -3/4;-27 -2 18 3/2;105/2 15/4 -27 -9/4;0 -1/2 0 1/2;71 5 -36 -3;107/2 15/4 -27 -9/4;-27 -3 18 3/2;17 5/4 -17/2 -3/4;-54 -5 36 5/2];
qq=coeff*[1;sqrt(2);sqrt(3);sqrt(6)];
h=sum(sqrt(2*qq).*cos(ks(:)*(pi*(0:23)/12)),1);
D=37/36; cutsH=[0 cumsum(h)/24];
assert(all(qq>0));
fprintf('MATLAB %s wide-window rows, quadrature not interval-certified\n',version);
fprintf('qsum %.16g hmean %.3g hsecond %.16g hmax %.9g\n',sum(qq),mean(h),mean(h.^2),max(abs(h)));
allerr=0; cases=0;
for phase=1:3
 if phase==1, Ks=48; Ls=[25/24 29/24 11/8];
 elseif phase==2, Ks=[48 96]; Ls=linspace(25/24,11/8,17);
 else, Ks=[192 384]; Ls=linspace(25/24,11/8,33); end
 for K=Ks
  mus=[]; vars=[]; maxerr=0; momenterr=0;
  for L=Ls
   out8=rowmom(K,L,h,cutsH,D,8);
   out16=rowmom(K,L,h,cutsH,D,16);
   out32=rowmom(K,L,h,cutsH,D,32);
   maxerr=max(maxerr,max(abs([out8-out16 out16-out32])));
   momenterr=max(momenterr,max(abs(out32(1:3)-[1 0 1])));
   sigma=1/(sqrt(3*D)*(K+20));
   % Size-bias by A, exactly normalized since E A=1 analytically.
   mu=out32(4)/out32(1); vv=out32(5)/out32(1)-mu^2;
   mus(end+1)=mu/(sigma^2/2); vars(end+1)=vv/sigma^2;
   assert(vv>0 && out32(1)>0 && all(isfinite(out32)));
   cases=cases+1;
  end
  allerr=max(allerr,maxerr);
  fprintf('phase%d K%d Lcount%d maxMomentError%.3g quad8_16_32diff%.3g muOverSigma2half[%.9g,%.9g] varOverSigma2[%.9g,%.9g]\n',phase,K,numel(Ls),momenterr,maxerr,min(mus),max(mus),min(vars),max(vars));
 end
end
fprintf('cases%d maxQuadratureDifference%.3g; no asymptotic/exponent or upper-bound inference\n',cases,allerr);
function out=rowmom(K,L,h,H,D,order)
 c=sort([0 1 mod((0:K-1)/K-L/2,1) mod((0:K-1)/K+L/2,1) mod((0:23)/24-L/2,1) mod((0:23)/24+L/2,1)]);
 lo=c(1:end-1); hi=c(2:end); keep=hi>lo; lo=lo(keep);hi=hi(keep);
 j=1:order-1; off=j./sqrt(4*j.^2-1); [V,E]=eig(diag(off,1)+diag(off,-1));
 [nodes,ix]=sort(diag(E)); weights=2*V(1,ix).^2;
 x=((lo+hi)/2)'+((hi-lo)/2)'*nodes'; w=((hi-lo)/2)'*weights;
 x=x(:);w=w(:);
 plus=x+L/2; minus=x-L/2;
 sp=mod(K*plus,1);sm=mod(K*minus,1);
 b=(primitive(plus,h,H)-primitive(minus,h,H))/L;
 sigma=1/(sqrt(3*D)*(K+20)); out=zeros(1,5);
 for bp=0:1
  for bm=0:1
   prob=(bp*sp+(1-bp)*(1-sp)).*(bm*sm+(1-bm)*(1-sm));
   Y=sqrt(3*D)*(bp-bm-sp+sm)/L+b;
   av=1+sigma*Y; logav=log1p(sigma*Y);
   assert(all(av>0)); wp=w.*prob;
   out=out+[sum(wp.*av),sum(wp.*Y),sum(wp.*Y.^2),sum(wp.*av.*logav),sum(wp.*av.*logav.^2)];
  end
 end
end
function val=primitive(x,h,H)
 p=mod(x,1); idx=min(23,floor(24*p));
 val=H(idx+1)'+h(idx+1)'.*(p-idx/24);
end
