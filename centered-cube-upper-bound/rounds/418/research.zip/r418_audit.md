# R418 independent audit — frozen

FINAL PASS within the bounded scope: exact same-posterior signed Doob identity, actual G_order normalization, native-center V_cap bound, and the stated finite single-row numerical implementation. Final main/README/auxiliary proof and code reviewed; the Fraction script independently rerun with delivered stdout byte-identical. No new R414 payment, no P and no general root bound are certified. Original ledger unchanged. Only this audit file edited.

## Independent proposition check

On the SAME complete source posterior π_u, take the full coordinate filtration ℱ_j and p_j=E[1_Qv|ℱ_j], a_j=E[a|ℱ_j]. Its terminal sigma-field reveals the source point, so martingale orthogonality gives

E[a1_Qv]=p Ea+Σ_j E[Δa_j Δp_j],
ΣE(Δp_j)^2=p(1−p), ΣE(Δa_j)^2=Var(a).

This is valid for arbitrary correlated f; no product-source law is needed. Distinct levels are orthogonal under this one posterior, not under posterior distributions taken from different parents. Full-value coordinate observation and binary coordinate-pass observation must not be confused. The auxiliary text correctly distinguishes them and restricts p_j=1_Fj I/M_j to the binary filtration. Zero-mass conditioning branches can be set arbitrarily; if I=0, common old-source traffic is zero. Atoms of the binary observations are retained.

Pairwise Cauchy gives the absolute covariance bound sqrt[p(1−p)Var(a)], with signed identity retained before taking absolute values. Applying Cauchy over the positive REAL pair measure yields the displayed sqrt(V_a V_cap)/h. Finite E and m_v≥q_-a^n make this pair measure finite; bounded a ensures all variances are integrable. Coordinate conditional kernels can be selected measurably from the full f slices. None of this proves a positive increment sum dominates original staged traffic.

## Exact original normalization and its scope

Checked the actual r389_geometry (15a)–(15b): θbar_actual uses R_u^n ell(dr) ONCE and includes T_u/max(J_y(r),T_u), original high-J and other marks. It is bounded by1. The live original strict-high-past support implies T_u>h; setting a=h θbar_actual/T_u to zero off that support gives0≤a≤1.

With ζ=σ(du)μ(dv)1_far1_Iuv>0(1−m_v/m_u), substitution π_u=f c_u dy/m_u gives exactly

h^−1∫ζ E_{π_u}[a c_v]
=∫f c_u c_v μ(du)μ(dv) q_u θbar_actual(1−m_v/m_u)/T_u
=G_order.

Thus no additional m_u, q ratio or clock normalization is missing. The Iuv=0 exclusion changes no actual traffic. This is the retained ACTUAL G_order, not merely the larger G_prefix mark.

For the real-center capture variance, drop only positive gates and use p=π_u(c_v):

V_cap≤∫σ(du)π_u(dy)∫c_v(y)μ(dv)
=∫σπ_u J≤J_max X_q,
J_max=[1+n log(b/a)]/q_-.

It is an X_q receiver price, not a once-only W source price. V_a and G_mean remain unbudgeted. In R414 the new source, b_i, old-source conditional density and path/history labels change the observable and cumulative measure; a≤1 is not licensed for those stage-conditioned weights by this computation. In particular, conditioning on common capture can introduce division by p, for which strict far matching supplies only an upper bound. Final reports correctly retain this limitation and keep the original R414/feedback/entrance account unchanged.

## Wide-window single-row implementation

Read the construction definitions and 24-step spectral table in the supplied internal source file (not its full lower-bound proof). All ten coefficient rows, frequencies, h_j, D=37/36, σ=[sqrt(3D)(K+20)]^−1 and the periodic source mixture in the MATLAB script agree with those definitions. No certification of the draft's asymptotic lower bound, tilting/cluster steps or continuum approximation is made here.

For fixed x,L, the atomic cumulative error at an endpoint is (B−s)/K. For L∈[25/24,11/8], K≥48, the periodic cell indices of x±L/2 differ: floor(K(L−1))≥2 and the separation remains strictly below K. Hence the two relevant U_j variables are distinct, so the two Bernoulli variables are conditionally independent at THAT fixed length. Periodic copies of the same atom cell are not erroneously treated as independent. Endpoint coincidences have zero source/center measure. Consequently the four-state formula for Y and A=1+σY is correct.

The periodic primitive for h has no period drift because the theoretical background mean is zero. The script cuts x at every atomic-cell and background break point for both endpoints. It integrates all four Bernoulli probabilities and the functions A, Y, Y², A log A and A(log A)². Analytical EA=1 makes A dP the proper size-biased law. Dividing numerical weighted moments by the computed EA is an appropriate numerical normalization, not a new theoretical identity. Gauss–Legendre orders8/16/32 are deterministic floating quadrature; logarithmic moments are not integrated exactly and their mutual agreement supplies no rigorous error enclosure.

The nonempty985-byte output is consistent with the final script and main:103(K,L) configurations, maximum moment error about1.03e−14, order-to-order difference about1.21e−14, and the reported tilted mean/variance ratio ranges. Parent reports actual MATLAB execution; auditor reviewed the formula/script/output but did not independently invoke MATLAB. No PRNG or sampling issue arises in this deterministic integration, and no interval or analytic quadrature error certificate is supplied.

This is a periodic measure single-row calculation, not already a finite full-space L1 fixture, original high-rank/history example, n-dimensional rare-event experiment or cross-length process law. In particular, independently drawing these length marginals would destroy the same-U dependence needed for the original cluster argument. Final main/README state this limitation and infer neither a dimension exponent nor a general upper bound.

## Fraction evidence and bounded conclusion

Independent rerun of r418_aux_check.py: [18,27,18] configurations, total63,62 nonzero signed covariances; stdout exactly matches the supplied result. The source packet masses are nonproduct, their total is1, the all-zero packet has mass2^−n, and the two disjoint continuous center blocks capture all packets / exactly the zero packet. Packet and center margins make these captures constant across whole blocks, so q_u=q_v=1 is actual full-f matching. The coordinate-value observations reveal the bit label plus independent uniform within-cell coordinates, so the discrete conditional calculations correctly represent these packet examples. The V_cap test uses the actual block volumes and masses. Expanded dimensions4/6/9 certify strict far mass with integer inequalities and e<3; early dimensions are algebra diagnostics.

There are21 base dimension/seed configurations, each with three prescribed mark functions, giving63 parameter/mark configurations, not63 distinct fields or independent original-history realizations. The marks are diagnostic and do not realize the actual θbar/history or a nonzero native G_order/R414. These tests check identities and inequalities, not a missing transfer theorem. The separate geometry note is a scope checkpoint without new payment; its two reported local variance executions are not added to the63 deliverable records.

No substantive correction to the final bounded claims remains. The original marked mean/variance source budget and P remain unproved. No coordinate square, old capture credit or numerical count is substituted for a receipt.

## SHA-256 bindings

Final reviewed bytes follow; no later TeX/manifest/package is bound here.

- `r418_main.md`: `047ef8b331216eac8f74cd672a7252038ccc33c927b1642b9dc8632685f39ee6`
- `r418_readme.md`: `85aecb51493d962331260b898c7ac634461203801c2e41588b761ec1ddaa53ab`
- `r418_aux.md`: `6f259bc40b8fb721d4ebb3a16f1f092cafa6e700251bbfc14059312636d50136`
- `r418_geometry.md`: `747aa4323b30272eff8387a3c688c12a4fa3627da80e1b54326eff282ceb8ee5`
- `r418_aux_check.py`: `47b8b2a5fd5f7c83c085a2d5232674fc4ea2f31d05471fde83d1b0efb15065dc`
- `r418_aux.result.txt`: `19c3fe8c213c6b206d26ac7a967adfc12abf12888e454012ff6e44da9181c661`
- `r418_wide_window.m`: `fe1ed2c38d838e887a734afa3bca9c5357c52ad67e81ba6a71a14333b81df936`
- `r418_wide_window.result.txt`: `fcb909c6effcf95d64203cea23d9f7a43f0938fc7f907fff6b7bf9f18709fb1c`
- `r389_geometry.md`: `e007b0a5fca2af7e19fd8f7574c110c2ce1029de5d46d056c837fdecb22f2985`
- `r414_main.md`: `4b22ddb135ac2f13eb1f282b7e5c965b293f2ea4ec259d5efa8a6f961e390ddc`
- Supplied24-step construction source `/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/inputs/centered_cube_wide_window_cluster_lower_bound_20261001(1).txt`: `1edcae8168482f25991581deceb58dcdf59a807be84bc3464cce75f9530b8243`
