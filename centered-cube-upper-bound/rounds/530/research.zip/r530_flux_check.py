from fractions import Fraction as Q
from pathlib import Path
import json,random,sys,platform

def mul(p,q):
 out=[Q(0)]*(len(p)+len(q)-1)
 for i,x in enumerate(p):
  for j,y in enumerate(q):out[i+j]+=x*y
 return out

def case(n,seed,stress=False):
 rng=random.Random(seed);R=Q(2);s=Q(4,5)
 if stress:
  x=[Q(-1,5)]*n;y=[Q(2,5)]*n
 else:
  x=[Q(rng.randrange(-8,9),10) for _ in range(n)]
  y=[Q(rng.randrange(-8,9),10) for _ in range(n)]
 delta=[abs(y[i]-x[i]) for i in range(n)]
 eps=[(y[i]>x[i])-(y[i]<x[i]) for i in range(n)]
 k=[R/2-eps[i]*y[i] for i in range(n)]
 assert all(v>0 for v in k)
 cuts=sorted(set([Q(0)]+[v for i in range(n) for v in [(delta[i]-s)/k[i],delta[i]/k[i]] if v>0]))
 totals=[Q(0)]*n;identities=0
 for low,high in zip(cuts,cuts[1:]):
  mid=(low+high)/2;du=high-low;factors=[];active=[]
  for i in range(n):
   z=delta[i]-k[i]*mid
   if z<=0:factors.append([Q(1)]);active.append(False)
   elif z>=s:factors.append([Q(0)]);active.append(False)
   else:factors.append([1-(delta[i]-k[i]*low)/s,k[i]*du/s]);active.append(True)
  product=[Q(1)]
  for p in factors:product=mul(product,p)
  derivative=[(j+1)*product[j+1]/du for j in range(len(product)-1)] or [Q(0)]
  totalpoly=[Q(0)]*max(n,len(derivative))
  for i in range(n):
   if not active[i]:continue
   p=[k[i]/s]
   for j in range(n):
    if j!=i:p=mul(p,factors[j])
   for j,v in enumerate(p):totalpoly[j]+=v
   totals[i]+=du*sum((v/Q(j+1) for j,v in enumerate(p)),Q(0))
  derivative+= [Q(0)]*(len(totalpoly)-len(derivative))
  assert derivative==totalpoly;identities+=1
 initial=Q(1)
 for v in delta:initial*=max(Q(0),1-v/s)
 assert sum(totals)==1-initial
 gate_checks=0
 for _ in range(24):
  B=[x[i]+s*Q(rng.randrange(-9,10),20) for i in range(n)]
  u=Q(rng.randrange(21),10)
  gaps=[max(Q(0),(sign*(y[i]-B[i])-s/2)/(R/2-sign*y[i])) for i in range(n) for sign in [-1,1]]
  direct=max(gaps)<=u
  intervals=all(max(x[i]-s/2,y[i]-s/2-(R/2-y[i])*u)<=B[i]<=min(x[i]+s/2,y[i]+s/2+(R/2+y[i])*u) for i in range(n))
  assert direct==intervals;gate_checks+=1
 return {'n':n,'seed':seed,'simultaneous_faces':stress,'R':str(R),'s':str(s),'x':list(map(str,x)),'y':list(map(str,y)),'breakpoints':list(map(str,cuts)),'face_integrals':list(map(str,totals)),'flux_total':str(sum(totals)),'one_minus_initial_overlap':str(1-initial),'polynomial_identities':identities,'exact_gate_checks':gate_checks}

cases=[case(2,53001),case(8,53002,True),case(32,53003)]
out={'scope':'Fixed-radius all-face positive-flux identity and exact gate algebra only; not an arbitrary-selector or I/J weighted budget','environment':{'executable':sys.executable,'python':platform.python_version(),'arithmetic':'fractions.Fraction'},'stages':['initial','simultaneous_first_faces','expanded_dimension'],'cases':cases}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print('PASS',[(x['n'],x['polynomial_identities'],x['flux_total']) for x in cases], '72 rational gate checks')
