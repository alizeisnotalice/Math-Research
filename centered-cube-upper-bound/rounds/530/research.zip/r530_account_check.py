from fractions import Fraction as F
from pathlib import Path
import json, sys, platform
# Exact continuum example: f=1_[0,1], lambda=1/2, full equal-level E=[0,1].
# The outermost side is 2; D ramps on [-1,0], equals 1/2 on [0,1], ramps down on [1,2].
W=F(1); lam=F(1,2); E=F(1)
X=lam*E; A=F(1,4); norm2=2*F(1,12)+F(1,4); M=lam*norm2
G=A-M
assert (X,A,M,G)==(F(1,2),F(1,4),F(5,24),F(1,24))
assert X*X==W*A
# For each nested pair the full intersection numerator is exactly zero.
nested=[F(k,13) for k in range(1,14)]
assert all(lam*v-lam*v==0 for v in nested)
# Discrete Abel is a cumulative bound, not a pointwise density bound.
mass=[F(1),F(0),F(4)]; capincrements=[F(2),F(2),F(2)]; weights=[F(4),F(2),F(1)]
assert all(sum(mass[:k])<=sum(capincrements[:k]) for k in range(1,4))
assert mass[2]>capincrements[2]
actual=sum(x*y for x,y in zip(mass,weights)); upper=sum(x*y for x,y in zip(capincrements,weights))
assert actual<=upper
out={'scope':'Exact continuum normalization and finite Abel algebra only; no general covariance bound',
'environment':{'executable':sys.executable,'python':platform.python_version(),'arithmetic':'Fraction'},
'continuum':{k:str(v) for k,v in dict(W=W,level=lam,E_measure=E,X=X,A=A,Lebesgue_D2=norm2,M=M,Gamma=G).items()},
'abel':{'mass':list(map(str,mass)),'cap_increments':list(map(str,capincrements)),'weights':list(map(str,weights)),'actual':str(actual),'upper':str(upper)},'nested_algebra_checks':13}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
