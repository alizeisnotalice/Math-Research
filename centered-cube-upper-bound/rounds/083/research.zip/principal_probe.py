#!/usr/bin/env python3
"""Exact principal Hall peeling on finite physical hard-window dx cells.

Positive atomic source, finite rational scales, paid unit anchor. No continuous
first-hit or L1-input assertion. All Hall subsets and independent integer flow.
"""
from fractions import Fraction as F
from pathlib import Path
from itertools import product
from collections import deque
from math import prod,lcm
import json,random,time,hashlib

SEED=830611


def clean(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [clean(v) for v in x]
    return x


def mass_table(weights):
    out=[F(0)]*(1<<len(weights))
    for mask in range(1,len(out)):
        bit=mask&-mask;out[mask]=out[mask^bit]+weights[bit.bit_length()-1]
    return out


def fixture(label,n,centers,weights,scales,lam):
    centers=[tuple(map(F,y)) for y in centers];weights=list(map(F,weights));scales=list(map(F,scales))
    assert all(p>0 for p in weights) and len(centers)<=10 and len(centers)==len(weights)
    assert scales==sorted(set(scales)) and scales[0]==1 and scales[-1]<=2
    return dict(label=label,n=n,N=len(centers),centers=centers,weights=weights,W=sum(weights),scales=scales,lambda_value=F(lam),fresh_ratio_q=F(1,2))


def cells(src):
    n,N,K=src['n'],src['N'],len(src['scales']);q=src['fresh_ratio_q'];full=(1<<N)-1
    mass=mass_table(src['weights']);axes=[];lengths=[];mids=[];tables=[]
    for j in range(n):
        axis=sorted({y[j]+a*L*side for y in src['centers'] for L in src['scales'] for a in (F(1),q) for side in (F(-1,2),F(1,2))})
        axes.append(axis);lengths.append([b-a for a,b in zip(axis,axis[1:])]);mids.append([(a+b)/2 for a,b in zip(axis,axis[1:])])
        table=[]
        for x in mids[-1]:
            row=[]
            for L in src['scales']:
                for factor in (F(1),q):
                    row.append(sum(1<<i for i,y in enumerate(src['centers']) if abs(x-y[j])<factor*L/2))
            table.append(row)
        tables.append(table)
    patterns={};cell_count=0;digest=hashlib.sha256()
    for indices in product(*(range(len(x)) for x in lengths)):
        vol=prod(lengths[j][indices[j]] for j in range(n));capture=[];old=[]
        for k in range(K):
            c=o=full
            for j in range(n):c&=tables[j][indices[j]][2*k];o&=tables[j][indices[j]][2*k+1]
            capture.append(c);old.append(o);assert o&c==o
        key=tuple(capture+old)
        if key not in patterns:patterns[key]=dict(volume=F(0),cell_count=0,representative=[mids[j][indices[j]] for j in range(n)])
        row=patterns[key];row['volume']+=vol;row['cell_count']+=1;cell_count+=1
        digest.update((str(indices)+':'+str(vol)+':'+str(key)+'\n').encode())
    records=[];retained=[];integrals=[F(0)]*K
    for key,item in patterns.items():
        capture=list(key[:K]);old=list(key[K:]);averages=[mass[c]/L**n for c,L in zip(capture,src['scales'])]
        hits=[k for k,a in enumerate(averages) if a>src['lambda_value']]
        first=hits[0] if hits else None;paid=averages[0]>=src['lambda_value']/2;keep=first is not None and not paid
        for k,a in enumerate(averages):integrals[k]+=a*item['volume']
        rec=dict(**item,captured_masks=capture,inner_masks=old,averages=averages,paid_anchor=paid,first_strict_scale_index=first,retained=keep)
        if keep:
            k=first;L=src['scales'][k];c=capture[k];o=old[k];fresh=c^o
            assert k>0 and fresh and mass[o]<=mass[capture[0]]<src['lambda_value']/2
            assert mass[c]>src['lambda_value']*L**n
            residual=mass[fresh]-(src['lambda_value']*L**n-src['lambda_value']/2)
            assert residual>0
            rec.update(captured_neighborhood=c,fresh_neighborhood=fresh,captured_mass=mass[c],fresh_mass=mass[fresh],
                       first_strict_scale=L,overshoot_mass=mass[c]-src['lambda_value']*L**n,
                       fresh_mass_over_lambda_scale_volume=mass[fresh]/(src['lambda_value']*L**n),
                       fresh_fraction_of_capture=mass[fresh]/mass[c],anchor_fresh_lower_bound=src['lambda_value']*L**n-src['lambda_value']/2,
                       strict_fresh_bound_residual=residual)
            retained.append(rec)
        records.append(rec)
    assert integrals==[src['W']]*K
    anchor_volume=sum(r['volume'] for r in records if r['paid_anchor']);assert src['lambda_value']*anchor_volume<=2*src['W']
    retained_volume=sum(r['volume'] for r in retained)
    return dict(axes=axes,complete_cell_count=cell_count,pattern_count=len(records),cell_digest=digest.hexdigest(),patterns=records,
                scale_average_integrals=integrals,paid_anchor_volume=anchor_volume,paid_anchor_fee=src['lambda_value']*anchor_volume,
                paid_anchor_budget=2*src['W'],positive_grid_event_volume=sum(r['volume'] for r in records if r['first_strict_scale_index'] is not None),
                retained_volume=retained_volume,retained_demand=src['lambda_value']*retained_volume,
                retained_cell_count=sum(r['cell_count'] for r in retained),retained_pattern_count=len(retained),
                min_fresh_mass_over_lambda_scale_volume=min((r['fresh_mass_over_lambda_scale_volume'] for r in retained),default=None),
                min_fresh_fraction_of_capture=min((r['fresh_fraction_of_capture'] for r in retained),default=None)),retained


def grouped_rows(src,retained,key):
    rows={}
    for r in retained:
        mask=r[key];k=r['first_strict_scale_index'];item=rows.setdefault((mask,k),dict(neighborhood=mask,first_scale_index=k,volume=F(0),cell_count=0))
        item['volume']+=r['volume'];item['cell_count']+=r['cell_count']
    out=list(rows.values())
    for row in out:row['demand']=src['lambda_value']*row['volume']
    return out


class Flow:
    def __init__(self,N):self.graph=[[] for _ in range(N)];self.original=[]
    def edge(self,a,b,c):
        ai=len(self.graph[a]);bi=len(self.graph[b]);self.graph[a].append([b,bi,c]);self.graph[b].append([a,ai,0]);self.original.append((a,b,c,ai))
    def maxflow(self,s,t):
        value=0;N=len(self.graph)
        while True:
            level=[-1]*N;level[s]=0;q=deque([s])
            while q:
                v=q.popleft()
                for w,rev,c in self.graph[v]:
                    if c and level[w]<0:level[w]=level[v]+1;q.append(w)
            if level[t]<0:break
            ptr=[0]*N
            def dfs(v,f):
                if v==t:return f
                while ptr[v]<len(self.graph[v]):
                    e=self.graph[v][ptr[v]];w,rev,c=e
                    if c and level[w]==level[v]+1:
                        z=dfs(w,min(f,c))
                        if z:e[2]-=z;self.graph[w][rev][2]+=z;return z
                    ptr[v]+=1
                return 0
            while True:
                z=dfs(s,sum(c for a,b,c,i in self.original if a==s))
                if not z:break
                value+=z
        reachable={s};q=deque([s])
        while q:
            v=q.popleft()
            for w,rev,c in self.graph[v]:
                if c and w not in reachable:reachable.add(w);q.append(w)
        return value,reachable


def transport(src,rows):
    N=src['N'];masses=mass_table(src['weights']);subset_demands=[F(0)]*(1<<N)
    for row in rows:
        assert row['neighborhood'];subset_demands[row['neighborhood']]+=row['demand']
    # Exact subset zeta transform: sum of demands whose neighborhood is in S.
    for i in range(N):
        for S in range(1<<N):
            if S>>i&1:subset_demands[S]+=subset_demands[S^(1<<i)]
    K=max((subset_demands[S]/masses[S] for S in range(1,1<<N)),default=F(0))
    maximizers=[S for S in range(1,1<<N) if subset_demands[S]==K*masses[S]]
    total=sum(row['demand'] for row in rows);assert K>=total/src['W']
    scale=1
    for z in [row['demand'] for row in rows]+[K*p for p in src['weights']]:scale=lcm(scale,z.denominator)
    R=len(rows);s=0;row_start=1;source_start=1+R;t=source_start+N;g=Flow(t+1)
    for r,row in enumerate(rows):
        g.edge(s,row_start+r,int(row['demand']*scale))
        for i in range(N):
            if row['neighborhood']>>i&1:g.edge(row_start+r,source_start+i,int(total*scale))
    for i,p in enumerate(src['weights']):g.edge(source_start+i,t,int(K*p*scale))
    value,reach=g.maxflow(s,t);flows=[];balance=[0]*(t+1)
    for a,b,c,idx in g.original:
        f=c-g.graph[a][idx][2];assert 0<=f<=c
        balance[a]-=f;balance[b]+=f;flows.append((a,b,F(c,scale),F(f,scale)))
    assert balance[s]==-value and balance[t]==value and all(balance[v]==0 for v in range(t+1) if v not in (s,t))
    cut=sum(c for a,b,c,idx in g.original if a in reach and b not in reach)
    assert value==cut==int(total*scale)
    assigned=[F(0)]*N;assignments=[]
    for a,b,c,f in flows:
        if row_start<=a<source_start and source_start<=b<t and f:
            r=a-row_start;i=b-source_start;assigned[i]+=f;assignments.append(dict(row=r,source=i,amount=f))
    loads=[z/p for z,p in zip(assigned,src['weights'])];assert max(loads,default=F(0))<=K
    posterior=[F(0)]*N
    for row in rows:
        M=masses[row['neighborhood']]
        for i,p in enumerate(src['weights']):
            if row['neighborhood']>>i&1:posterior[i]+=row['demand']*p/M
    posterior_loads=[z/p for z,p in zip(posterior,src['weights'])];Kpost=max(posterior_loads,default=F(0))
    assert K<=Kpost and sum(posterior)==total
    hall_residuals=[K*masses[S]-subset_demands[S] for S in range(1,1<<N)];assert min(hall_residuals,default=F(0))>=0
    # The maximizing source subset is also a lower-bound cut certificate.
    S=maximizers[0];forced=sum(row['demand'] for row in rows if row['neighborhood']&~S==0)
    assert forced==K*masses[S]
    return dict(rows=rows,K_optimal=K,all_nonempty_source_subsets_checked=(1<<N)-1,
                source_subset_masses=masses,source_subset_forced_demands=subset_demands,Hall_maximizers=maximizers,
                Hall_lower_witness=dict(source_subset=S,forced_demand=forced,source_mass=masses[S],ratio=forced/masses[S]),
                Hall_min_residual=min(hall_residuals,default=F(0)),total_demand=total,weighted_average_load=total/src['W'],
                maxflow=dict(integer_capacity_scale=scale,value=F(value,scale),cut=F(cut,scale),source_side=sorted(reach),
                             source_node=s,sink_node=t,row_node_start=row_start,physical_source_node_start=source_start,
                             arcs=flows,nonzero_assignments=assignments,capacity_bounds_verified=True,flow_conservation_verified=True,
                             all_receiver_demands_saturated=True),
                optimal_source_assigned_mass=assigned,optimal_source_normalized_loads=loads,
                canonical_posterior_assigned_mass=posterior,canonical_posterior_normalized_loads=posterior_loads,
                canonical_posterior_max_load=Kpost,posterior_minus_optimal_max_load=Kpost-K,
                posterior_over_optimal=Kpost/K if K else None)


def fixtures():
    L=[F(1),F(5,4),F(3,2),F(7,4),F(2)];out=[]
    out.append(('pilots_and_source_splitting',fixture('single_n1',1,[(0,)],[1],L,F(1,4))))
    coarse=fixture('same_input_coarse_n1',1,[(F(-3,4),),(0,),(F(3,4),)],[F(31,64),F(1,32),F(31,64)],L,F(1,4))
    out.append(('pilots_and_source_splitting',coarse))
    split=fixture('same_input_split_n1',1,[y for y in coarse['centers'] for _ in range(2)],[p/2 for p in coarse['weights'] for _ in range(2)],L,F(1,4))
    out.append(('pilots_and_source_splitting',split))
    for N in (2,5,8):
        ys=[(F(2*i-N+1,32*N),) for i in range(N)]
        out.append(('pilots_and_source_splitting',fixture('distinct_cluster_n1_N'+str(N),1,ys,[F(1,N)]*N,L,F(1,4))))
    out.append(('correlated_lacunary_and_spikes',fixture('lacunary_n1_N5',1,[(F(-3,2),),(F(-3,4),),(0,),(F(3,8),),(F(3,2),)],[F(1,16),F(1,8),F(1,2),F(1,4),F(1,16)],L,F(1,8))))
    out.append(('correlated_lacunary_and_spikes',fixture('density_spike_n2_N5',2,[(0,0),(F(1,32),0),(F(-1,32),0),(F(-7,8),F(3,4)),(F(7,8),F(-3,4))],[F(3,8),F(1,4),F(1,4),F(1,16),F(1,16)],L,F(1,8))))
    out.append(('correlated_lacunary_and_spikes',fixture('diagonal_correlated_n2_N6',2,[(F(2*i-5,8),F(2*i-5,8)) for i in range(6)],[F(1,6)]*6,L,F(1,8))))
    out.append(('correlated_lacunary_and_spikes',fixture('old_light_anchor_n2_N4',2,[(0,0),(F(-3,4),0),(F(3,4),0),(0,F(3,4))],[F(1,64),F(21,64),F(21,64),F(21,64)],L,F(1,8))))
    rng=random.Random(820611) # Preserve the frozen R82 base fixture exactly.
    weights=[rng.randrange(1,12) for _ in range(7)];W=sum(weights)
    centers=[(F(rng.randrange(-12,13),8),F(rng.randrange(-8,9),8)) for _ in range(7)]
    out.append(('correlated_lacunary_and_spikes',fixture('random_rational_n2_N7',2,centers,[F(w,W) for w in weights],L,F(1,16))))
    for n in (1,2,3):
        ys=[tuple([F(-3,4)]+[F(0)]*(n-1)),tuple([F(0)]*n),tuple([F(3,4)]+[F(0)]*(n-1))]
        out.append(('dimension_scale_and_threshold_extension',fixture('axis_n'+str(n)+'_N3',n,ys,[F(1,4),F(1,2),F(1,4)],L,F(1,2**(n+2)))))
    out.append(('dimension_scale_and_threshold_extension',fixture('n3_dense_scale_N5',3,[tuple([F(2*i-4,8)]+[F(0)]*2) for i in range(5)],[F(1,5)]*5,[F(1)+F(j,8) for j in range(9)],F(1,16))))
    out.append(('dimension_scale_and_threshold_extension',fixture('old_light_anchor_n3_N4',3,[(0,0,0),(F(-3,4),0,0),(F(3,4),0,0),(0,F(3,4),0)],[F(1,64),F(21,64),F(21,64),F(21,64)],L,F(1,16))))
    out.append(('dimension_scale_and_threshold_extension',fixture('n2_coarse_scale_N3',2,[(F(-3,4),0),(0,0),(F(3,4),0)],[F(1,4),F(1,2),F(1,4)],[F(1),F(2)],F(1,8))))
    return out


def hall_cut(src,rows,current,remaining):
    N=src['N'];mass=mass_table(src['weights']);forced=[F(0)]*(1<<N)
    for r in current:
        neighborhood=rows[r]['neighborhood']&remaining
        assert neighborhood
        forced[neighborhood]+=rows[r]['demand']
    for i in range(N):
        for S in range(1<<N):
            if S>>i&1:forced[S]+=forced[S^(1<<i)]
    allowed=[S for S in range(1,1<<N) if S&~remaining==0]
    assert allowed
    K=max(forced[S]/mass[S] for S in allowed)
    maximizers=[S for S in allowed if forced[S]==K*mass[S]]
    union=0
    for S in maximizers:union|=S
    assert forced[union]==K*mass[union]
    return K,union,maximizers,forced


def principal(src,arr,retained,with_flows=True):
    N=src['N'];mass=mass_table(src['weights']);rows=grouped_rows(src,retained,'captured_neighborhood')
    remaining=(1<<N)-1;current=list(range(len(rows)));blocks=[];assignment={};earlier=0
    while remaining:
        K,S,maximizers,forced=hall_cut(src,rows,current,remaining)
        selected=[r for r in current if (rows[r]['neighborhood']&remaining)&~S==0]
        assert sum(rows[r]['demand'] for r in selected)==K*mass[S]
        if blocks:assert K<blocks[-1]['K']
        block=dict(index=len(blocks),K=K,source_mask=S,source_mass=mass[S],source_indices=[i for i in range(N) if S>>i&1],
                   remaining_source_mask_before=remaining,earlier_source_mask=earlier,all_maximizing_cuts=maximizers,
                   forced_subset_demands=forced,assigned_original_rows=selected,total_demand=K*mass[S])
        for r in selected:assignment[r]=len(blocks)
        if with_flows:
            ids=block['source_indices'];local=dict(src,N=len(ids),weights=[src['weights'][i] for i in ids],W=mass[S],centers=[src['centers'][i] for i in ids])
            localrows=[]
            for r in selected:
                row=dict(rows[r]);row['neighborhood']=sum(1<<j for j,i in enumerate(ids) if row['neighborhood']>>i&1)
                localrows.append(row)
            flow=transport(local,localrows);assert flow['K_optimal']==K
            assert flow['optimal_source_assigned_mass']==[K*src['weights'][i] for i in ids]
            block['saturated_block_flow']=flow
        current=[r for r in current if r not in selected];remaining&=~S;earlier|=S
        if remaining:
            nextK,nextS,nextM,nextF=hall_cut(src,rows,current,remaining);assert nextK<K
            block['residual_Hall_maximum_after']=nextK;block['density_gap_to_next']=K-nextK
        else:block['residual_Hall_maximum_after']=None;block['density_gap_to_next']=None
        blocks.append(block)
    assert not current and len(assignment)==len(rows)
    for r,row in enumerate(rows):
        block=blocks[assignment[r]];C=row['neighborhood'];M=mass[C]
        row.update(assigned_block=assignment[r],original_captured_mass=M,
                   assigned_block_captured_mass=mass[C&block['source_mask']],
                   discarded_earlier_captured_mass=mass[C&block['earlier_source_mask']],
                   retained_captured_fraction=mass[C&block['source_mask']]/M,
                   discarded_captured_fraction=mass[C&block['earlier_source_mask']]/M)
    rowlookup={(row['neighborhood'],row['first_scale_index']):i for i,row in enumerate(rows)}
    geometry=[];max_loss=F(0);failed_scale_volume=F(0);lost_event_volume=F(0);best_score=F(0);best=None
    for r in retained:
        rowidx=rowlookup[r['captured_neighborhood'],r['first_strict_scale_index']];j=assignment[rowidx];block=blocks[j]
        c=r['captured_neighborhood'];M=mass[c];kept=mass[c&block['source_mask']];discarded=mass[c&block['earlier_source_mask']]
        assert kept>0 and kept+discarded==M
        loss=discarded/M;max_loss=max(max_loss,loss);k=r['first_strict_scale_index'];L=src['scales'][k]
        blockaverages=[mass[C&block['source_mask']]/ell**src['n'] for C,ell in zip(r['captured_masks'],src['scales'])]
        residualaverages=[mass[C&block['remaining_source_mask_before']]/ell**src['n'] for C,ell in zip(r['captured_masks'],src['scales'])]
        hits=[a for a,v in enumerate(blockaverages) if v>src['lambda_value']];residualhits=[a for a,v in enumerate(residualaverages) if v>src['lambda_value']]
        first=hits[0] if hits else None;residualfirst=residualhits[0] if residualhits else None
        assert blockaverages[0]<src['lambda_value']/2 and residualaverages[0]<src['lambda_value']/2
        assert first is None or first>=k;assert residualfirst is None or residualfirst>=k
        fails=blockaverages[k]<=src['lambda_value'];lost=first is None
        if fails:failed_scale_volume+=r['volume']
        if lost:lost_event_volume+=r['volume']
        gap=blocks[j-1]['K']-block['K'] if j else None
        relativegap=gap/blocks[j-1]['K'] if j and blocks[j-1]['K'] else None
        score=loss/(relativegap+F(1,1024)) if relativegap is not None else F(0)
        item=dict(original_row=rowidx,assigned_block=j,volume=r['volume'],cell_count=r['cell_count'],representative=r['representative'],
                  original_captured_mask=c,original_captured_mass=M,assigned_block_captured_mass=kept,discarded_earlier_captured_mass=discarded,
                  retained_captured_fraction=kept/M,discarded_captured_fraction=loss,
                  original_first_scale_index=k,original_first_scale=L,original_all_scale_averages=r['averages'],
                  block_only_all_scale_averages=blockaverages,residual_input_all_scale_averages=residualaverages,
                  block_only_anchor_average=blockaverages[0],block_only_paid_anchor=False,
                  block_only_first_strict_scale_index=first,residual_input_first_strict_scale_index=residualfirst,
                  block_loses_original_selected_crossing=fails,block_loses_all_grid_crossings=lost,
                  preceding_block_density_gap=gap,preceding_block_relative_density_gap=relativegap,leakage_gap_search_score=score)
        box=[]
        for axis,x in zip(arr['axes'],r['representative']):
            box.append(next([a,b] for a,b in zip(axis,axis[1:]) if a<x<b))
        item['representative_open_cell_box']=box
        item['representative_open_cell_volume']=prod(b-a for a,b in box)
        geometry.append(item)
        if score>best_score:best_score=score;best=item
    for block in blocks:
        gs=[row for row in geometry if row['assigned_block']==block['index']]
        block['physical_geometry_summary']=dict(original_receiver_volume=sum(row['volume'] for row in gs),
                                                max_discarded_captured_fraction=max((row['discarded_captured_fraction'] for row in gs),default=F(0)),
                                                lost_selected_crossing_volume=sum(row['volume'] for row in gs if row['block_loses_original_selected_crossing']),
                                                all_grid_crossings_lost_volume=sum(row['volume'] for row in gs if row['block_loses_all_grid_crossings']))
    Lmatrix=[[F(0)]*len(blocks) for _ in blocks]
    for r,row in enumerate(rows):
        j=assignment[r];M=mass[row['neighborhood']]
        for k,block in enumerate(blocks):
            z=row['demand']*mass[row['neighborhood']&block['source_mask']]/M
            if k>j:assert z==0
            Lmatrix[j][k]+=z
    B=[sum(row[k] for row in Lmatrix) for k in range(len(blocks))]
    lhs=sum(block['K']*B[k] for k,block in enumerate(blocks))-sum(block['K']**2*block['source_mass'] for block in blocks)
    rhs=sum((blocks[k]['K']-blocks[j]['K'])*Lmatrix[j][k] for j in range(len(blocks)) for k in range(j))
    assert lhs==rhs>=0 and all(sum(Lmatrix[j])==block['total_demand'] for j,block in enumerate(blocks))
    low=[]
    for threshold in (F(1,8),F(1,4),F(1,2)):
        bs=[block for block in blocks if block['K']<=threshold];d=sum(block['total_demand'] for block in bs);p=sum(block['source_mass'] for block in bs)
        assert d<=threshold*p;low.append(dict(threshold=threshold,demand=d,source_mass=p,budget=threshold*p,residual=threshold*p-d))
    return dict(original_rows=rows,blocks=blocks,row_assignment=[assignment[r] for r in range(len(rows))],row_geometry=geometry,
                initial_optimal_Hall_K=blocks[0]['K'],max_discarded_captured_fraction=max_loss,
                failed_original_selected_crossing_volume=failed_scale_volume,all_block_grid_crossings_lost_volume=lost_event_volume,
                best_leakage_gap_score=best_score,best_leakage_gap_row=best,
                canonical_posterior_identity=dict(L_jk=Lmatrix,B_k=B,left_side=lhs,right_side=rhs,exact_identity_verified=True),
                low_density_paid_branches=low,strict_density_descent_verified=True,all_blocks_flow_saturated=with_flows)


def pressure_search():
    rng=random.Random(SEED+1);trials=360;best=[];nonempty=0;multiblock=0;positive_multiblock=0;losses=0
    for trial in range(trials):
        N=3+trial%5;coords=sorted(rng.sample(range(-20,21),N));ints=[rng.randrange(1,31) for _ in range(N)];W=sum(ints)
        scales=[F(1),F(5,4),F(3,2),F(7,4),F(2)];lam=(F(1,16),F(1,8),F(3,16),F(1,4),F(3,8),F(1,2))[trial%6]
        src=fixture('pressure_trial_'+str(trial),1,[(F(x,16),) for x in coords],[F(w,W) for w in ints],scales,lam)
        arr,retained=cells(src)
        if not retained:continue
        nonempty+=1;p=principal(src,arr,retained,False)
        if len(p['blocks'])>1:multiblock+=1
        if sum(b['K']>0 for b in p['blocks'])>1:positive_multiblock+=1
        if p['all_block_grid_crossings_lost_volume']>0:losses+=1
        score=p['best_leakage_gap_score'];best.append((score,p['max_discarded_captured_fraction'],trial,src))
    best.sort(key=lambda z:(z[0],z[1],-z[2]),reverse=True)
    selected=best[:3]
    return [z[3] for z in selected],dict(seed=SEED+1,trials=trials,nonempty_retained_events=nonempty,multiple_block_cases=multiblock,
                                          multiple_positive_density_block_cases=positive_multiblock,
                                          cases_losing_all_block_grid_crossings=losses,ranking='Exact max over rows: discarded_fraction/(relative preceding-block K gap + 1/1024).',
                                          selected_trials=[z[2] for z in selected],selected_scores=[z[0] for z in selected])


def main():
    start=time.monotonic();records=[];base=fixtures();searched,search=pressure_search()
    specs=[]
    for oldstage,src in base:
        stage='dimension_scale_and_threshold_extension' if oldstage.startswith('dimension') else 'pilots_and_source_splitting' if oldstage.startswith('pilots') else 'correlated_and_leakage_pressure'
        specs.append((stage,src))
    specs.extend(('correlated_and_leakage_pressure',src) for src in searched)
    for stage,src in specs:
        arr,retained=cells(src);p=principal(src,arr,retained,True)
        records.append(dict(stage=stage,source=src,arrangement=arr,principal=p))
        print(src['label'],'blocks',[str(b['K']) for b in p['blocks']],'maxloss',str(p['max_discarded_captured_fraction']),'lostvolume',str(p['all_block_grid_crossings_lost_volume']),'seconds',round(time.monotonic()-start,3),flush=True)
    bylabel={r['source']['label']:r for r in records};coarse=bylabel['same_input_coarse_n1'];split=bylabel['same_input_split_n1']
    expand=lambda mask:sum((3<<(2*i)) for i in range(coarse['source']['N']) if mask>>i&1)
    assert coarse['arrangement']['retained_volume']==split['arrangement']['retained_volume']
    assert [b['K'] for b in coarse['principal']['blocks']]==[b['K'] for b in split['principal']['blocks']]
    assert [expand(b['source_mask']) for b in coarse['principal']['blocks']]==[b['source_mask'] for b in split['principal']['blocks']]
    out=dict(status='EXACT_PRINCIPAL_HALL_PEELING_VERIFIED',dependencies='Python standard library only',seed=SEED,base_fixture_seed=820611,
             source_scope='Positive finite atomic measure and full dx cells; finite side-scale first STRICT crossing after paid unit anchor. No continuous first-hit, E2 smooth-gate or independent-block weak theorem.',
             peeling='At each step take union of all maximum-density source cuts; peel exactly forced receiver rows and source block, then delete block sources from remaining row neighborhoods.',
             physical_geometry='Each row retains its original physical selector and original all-grid masks; block-only and residual source inputs are recomputed at every physical grid scale.',
             counts=dict(stages=3,fixtures=len(records),complete_dx_cells=sum(r['arrangement']['complete_cell_count'] for r in records),
                         principal_blocks=sum(len(r['principal']['blocks']) for r in records),
                         saturated_block_flows=sum(len(r['principal']['blocks']) for r in records),
                         positive_density_blocks=sum(b['K']>0 for r in records for b in r['principal']['blocks']),
                         original_demand_rows=sum(len(r['principal']['original_rows']) for r in records),
                         original_physical_geometry_patterns=sum(len(r['principal']['row_geometry']) for r in records)),
             pressure_search=search,fixtures=records,
             same_measure_source_splitting=dict(receiver_volume_equal=True,principal_densities_equal=True,principal_source_blocks_expand_exactly=True),
             limitations=['Principal blocks solve an abstract capacity problem; they need not retain original physical crossings.',
                          'The fixed finite grid can overshoot lambda; deleting physical source mass may delay or remove every grid crossing.',
                          'No dimension/source-count asymptotic, continuum selector or parent smooth deletion is certified.'])
    p=Path(__file__).with_name('principal_results.json');p.write_text(json.dumps(clean(out),indent=2,sort_keys=True)+'\n')
    print('PASS',out['counts'],'search',search,'seconds',round(time.monotonic()-start,3),'bytes',p.stat().st_size,flush=True)


if __name__=='__main__':main()
