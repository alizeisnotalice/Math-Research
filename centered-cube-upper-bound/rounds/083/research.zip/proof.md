# 第83轮：可调平滑似然、共同容量分块与内部新鲜质量

日期：2026-10-11。覆盖、软层、几何论证：Astra medium；完整空间数值与独立审计：Sol high；主代理逐项复核、整合与隔离重放。

**核心目标尚未完成。** 对任意正 L1 输入的一般中心立方体弱型上界仍只保留 O(n log n) 基准；本轮没有证明 sqrt(n)n^{o(1)}。本轮的一般性进展是扩大已支付分支，并证明新的固定物理尺度接口，不能用它们替代仍未完成的自适应尺度估计。

## 本轮目标与已证推进

在第81轮实际 [1,2] 全边长窗口、原勒贝格接收测度、同一真实 hard 首次接触处继续研究。先支付 A_1>=lambda/2 与 sup_L P_(1,L)>lambda/2，费用为 [4+2 log(2)sqrt(7n/3)]||f||_1。保留事件实际越阈且首接触 A_L=lambda，P_(1,L)<=lambda/2。本文所有新增似然标签都在这个原选择器处读取，不能给不同分支另造私人来源或尺度。

1. 对任意预定有限或可数宽度 eta_j 与总和不超过一的权重 a_j，极低平滑似然分支的并集费用至多 2(1+n log2)||f||_1/sqrt(n+2)。它直接使用来源锥包络，不需支付每个窄平滑极大算子。实际 E2 核的有限 Chernoff 率给出 eta<=1/n 时 beta=n^{-o(1)} 的可用截止值；次幂结论依赖 r=O(log n)，并非对任意极小权重一致。
2. 固定物理全边长 L 时，所有噪声宽度的绝对变化总和至多 (2+log51)sqrt(n)||f||_1。证明使用真实噪声尺度 Fisher <=min(1,51eta)。这不是随 x 选择 L(x) 的预算，二者不能交换。
3. 共同 Hall 容量具有精确最大紧割分块及饱和共同流；分块负载对所有凸费用最优。二次亏损等于负载平方误差与密度差加权回流之和。K_j<=sqrt(n) 的低密度块可支付，高密度块的几何费用仍未证明。
4. 两个真实几何障碍被精确定位：小密度差不能保证来源截断后的捕获损失小；最大捕获 Hall 割也可能所有来源都在方体并集深处，外边界层源质量为零。后者已通过原平滑/锚点门槛，但其 Hall 比值很小，不反驳高比值专门估计。

## 一般返回与剩余最小接口

令 E_rem 是第81轮保留事件扣除本轮所有注册宽度的极低比值事件后余下的接收集合。它同时满足 P_(eta_j,L(x))>beta_j lambda。令 D_rem(n) 表示对所有输入统一有效的 lambda|E_rem|/||f||_1 上界；此量尚未证明达到 sqrt(n)n^{o(1)}。若能够证明，则已核验的局部化给出

    C_n^square <= C_loc log(n+2)
      [4+2 log2 sqrt(7n/3)+2(1+n log2)/sqrt(n+2)+D_rem(n)].

这里不再另加第82轮极低分支费用：本轮多宽度分支是一次新的完整并集拆分；若还同时使用另一个独立例外集，必须明确再计费。 窄核的次幂下界是对 P_eta 的新约束，不是对原 P_1 下界的增强，也不自动证明 E_rem 包含于第82轮的中间事件。n=1 保留固定维度工具，不影响渐近目标。

一个足够但仍未证的动态接口是在 E_rem 的原选择器 L(x) 上控制

    integral_E_rem integral_0^1 |f*(eta partial_eta Phi_eta)_(L(x))(x)| d eta/eta dx.

在这个表达式中，不能把固定 L 的空间积分估计直接代入。共同容量路线等价地需要实际接收集合的高 Hall 比值几何预算。主分块恒等式没有提供该预算；删除早块后晚块甚至可能失去所有 hard 越阈。下文保留这些限制，不把重新表述当作目标证明。

## 主代理补核：自适应选择器的硬端点是否合法

令 W_(eta L) 为 w 在 n 维的乘积概率核，噪声的实际宽度为 eta L。由卷积结合律，P_(eta,L)=A_L(f*W_(eta L))，因而

    sup_x |P_(eta,L)(x)-A_L f(x)|
      <= L^{-n} integral W_(eta L)(v)||f(.-v)-f||_1 dv.

在 1<=L<=2 上，L^{-n}<=1。给定 epsilon>0，L1 平移连续性使小 |v| 区域的差小于 epsilon；补集由 2||f||_1 乘噪声尾概率控制。对每个固定 n，缩放概率核的尾在 L in[1,2] 上一致趋零。因此 P_(eta,L)→A_L f 在所有 x 与窗口 L 上一致，无需对选择器 L(x) 另加 Lebesgue 点假设。这里没有声称收敛速率对所有 f 一致。

有限 eta 区间上的普通微分恒等式和上述极限，给出在原选择器处

    |A_(L(x))f(x)-P_(1,L(x))f(x)|
      <= integral_0^1 |f*(eta partial_eta Phi_eta)_(L(x))(x)| d eta/eta.

所以保留接触事件上右侧至少 lambda/2；若能证明其在 E_rem 上的积分为 sqrt(n)n^{o(1)}||f||_1，便足以支付 E_rem。该结论准确地区分“恒等式可在选择器上成立”和“固定尺度范数估计可在选择器上成立”：前者已核验，后者仍未证明。此处仅补齐接口合法性，不宣称新弱型上界。

## 数值范围与证据等级

完整空间程序只用标准库、有理数与整数最大流：20 个实例、123724 个完整原空间单元、34 个主分块流（含2个零块）、363 个接收行、999 个空间模式。三阶段覆盖初探、压力搜索与维度/尺度扩展；压力搜索种子830612，共360次试验，基础随机输入种子820611。范围是维数1--3、至多8个来源标签、至多9个窗口网格尺度，不能据此拟合一般维数阶数。

三个内嵌核验分别检查有限主分块/真实 L1 参数、连续门槛的有理包络、E2 标量积分与有限率函数。E2 Simpson 积分只作诊断，不是区间证书；几何门槛采用有理数全连续包络，不能与有限网格最大值混淆。独立审计与主代理执行结果、真实 stdout、脚本 SHA 及数据字节一致性记录在 inventory.json。任何 PASS 均限于脚本实际检查范围。

## 文件、技能及复现

归档只保存合并 proof.md、详细 proof.tex.txt、principal_probe.py、principal_results.json、inventory.json。证明稿内保留三个组件核验及独审脚本。先解压 research.zip，运行 `python3 principal_probe.py`；或从 proof.md 提取最后一个 python 代码块保存为 audit_guard.py，再运行 `python3 audit_guard.py`，即可执行便携独审及各组件检查。无第三方包依赖。不编译 LaTeX，不生成 PDF；静态环境/括号检查不宣称编译成功。

本轮重新读取更新后的64技能相关入口及接口：M03/G01 不提供现成一般稳定性或方体 Carleson 预算；A02/D02/H04/E03/B01/N02 只按已核条件使用。具体使用范围见各组件。技能路径及字节清单用于版本追踪，不等于所有64项原文已全文阅读或数学验收。

第81轮保留门槛和全尺度返回、第82轮来源运输与锥包络作为已证依赖继续保存。前一目标轮有实际新证据与文件产出，属于进展；本轮独审与重放完成后单独提交，不合并轮次。以下是完整推导与实际反例。


# R83: tunable E2 likelihoods and the cost of narrow physical smoothing

**Status.** A countable family of actual tunable smooth likelihood branches can be paid at O(sqrt(n)) on [1,2], with a common original hard selector. At noise width eta<=1/n the paid cutoff can be n^{-o(1)} for a different, narrower kernel. This is not a stronger P_1 lower bound or an automatic set inclusion into R82's former middle. This conditional branch does NOT require paying a new narrow smooth maximal baseline. Separately, for 0<eta<=1/48 the actual physical-dilation flux has size comparable to min(n,sqrt(n/eta)); therefore replacing the old baseline by very narrow smoothing and using its absolute continuous-variation budget cannot preserve sqrt(n)n^{o(1)}. The resulting middle, where all registered likelihoods exceed their cutoffs, remains unpaid.

A02 and D02 retain actual domination, source and likelihood directions. H04 was read: no asymptotic LDP is invoked. The finite Chernoff bound below is derived from the actual bounded reference variable. Independence is used only for product kernel laws or uniform cube cone geometry, never for arbitrary input f.

## 1. Actual tunable kernel and scalar identities

Let w(x)=integral_0^1 exp(-|x|/t)dt, w_eta(x)=eta^{-1}w(x/eta), h=1_{[-1/2,1/2]}, phi_eta=h*w_eta and Phi_eta=phi_eta^tensor n. Throughout 0<eta<=1. For f>=0, W=||f||1, define A_L=f*H_L and P_eta,L=f*(Phi_eta)_L on the FIXED physical window 1<=L<=2, T=log 2.

Write m_eta=phi_eta(1/2), M_eta=phi_eta(0), ell_eta=-log phi_eta on the hard interval, and mu_eta=integral_(-1/2)^(1/2) ell_eta. Exact formulas are

    m_eta=integral_0^1 t(1-exp(-1/(eta t)))dt,
    M_eta=1-2 integral_0^1 t exp(-1/(2eta t))dt,
    p_eta=integral_Q (1-phi_eta)
         =2eta integral_0^1 t^2(1-exp(-1/(eta t)))dt. (1)

The established scalar bound m_1>1/3, together with monotonicity, gives m_eta>1/3 and phi_eta<=1. Thus with b=log 3,

    log 2<ell_edge,eta=-log m_eta<b,
    0<=ell_eta<=b,
    eta/3<=p_eta<=2eta/3,
    eta/3<=mu_eta<=2eta.                             (2)

For the lower p bound use 1-exp(-1/(eta t))>=1-exp(-1)>1/2. For the logarithm use 1-u<=-log u<=(1-u)/m_eta on u in [m_eta,1]. In particular the mean likelihood penalty really has order eta, not order eta^2.

## 2. Physical-scale Fisher information: upper and lower bounds

Let g_eta(x)=-(phi_eta+x phi_eta')/phi_eta. Its mean under phi_eta is zero, and its variance is the physical-dilation Fisher information J_eta. Because

    phi_eta=integral_0^1 2t (h*Laplace_(eta t))dt,

and R78's direct scalar Laplace calculation gives J(h*Laplace_s)<=1/(2s)+2s for s<=1, pointwise mixture Cauchy yields

    J_eta<=1/eta+4eta/3<=7/(3eta).                  (3)

This is a physical dilation of the whole kernel, not a derivative in eta alone.

For completeness we prove a matching order lower bound in the narrow range 0<eta<=1/48 and a fourth-moment bound with explicit, deliberately loose constants. If eta<=1/48, take x=1/2+eta u, 0<=u<=1/2. Then

    |phi_eta'(x)|=(1/eta) integral_0^1
        exp(-u/t)(1-exp(-1/(eta t)))dt >=1/(12eta).

Restrict t to [1/2,1], use exp(-u/t)>=exp(-1)>1/3 and 1-exp(-1/eta)>1/2. Since phi_eta<=1 and x>=1/2,

    |phi_eta+x phi_eta'|>=1/(24eta)-1>=1/(48eta).

Integrating over the two outside intervals of total length eta gives

    J_eta>=1/(2304eta), eta<=1/48.                  (4)

Also, for every eta<=1,

    integral g_eta^4 phi_eta<=100000/eta^3.         (5)

Here are the details needed for this uniform moment bound. Inside the hard interval, let d_x=1/2-|x|. Then phi_eta>=1/3 and |phi_eta'|<=eta^{-1}exp(-d_x/eta), giving

    integral_inside x^4 phi_eta'^4/phi_eta^3
          <=27/(32eta^3).

Outside, put x=1/2+eta u. Let F=phi_eta(x) and G=eta|phi_eta'(x)|. The common integral formulas show G<=w(u), while

    F>= (1/2) integral_0^1 t exp(-u/t)dt >=w(u)/4.

The last inequality is the elementary positive association of the two increasing functions t and exp(-u/t) under uniform t. Thus |phi_eta'|/phi_eta<=4/eta outside, and F<=exp(-u)/2. Since integral_0^infinity (1/2+u)^4 exp(-u)du=633/16, both tails contribute at most 10128/eta^3 to the preceding fourth-derivative integral. Finally |1+z|^4<=8(1+|z|^4) proves (5). The exponential tails justify the mean-zero integration by parts.

## 3. The actual tensor physical flux has the predicted tradeoff

The physical dilation derivative of Phi_eta is the signed density

    D_(n,eta)(z)=Phi_eta(z) sum_j g_eta(z_j).

Under the product KERNEL law its scalar scores are independent and centered. Therefore

    ||D_(n,eta)||1<=min(2n,sqrt(n(1/eta+4eta/3))).    (6)

The bound 2n follows from the scalar identity integral |x phi_eta'|=1 for an even decreasing probability density. No source-coordinate independence is assumed.

There is a converse for eta<=1/48:

    ||D_(n,eta)||1 >= n/[40000000 sqrt(1+n eta)].    (7)

Indeed, for S=sum_j g_eta(X_j), E S^2=nJ_eta and

    E S^4=n E g_eta^4+3n(n-1)J_eta^2
       <=100000n/eta^3+(49/3)n^2/eta^2.

Holder interpolation gives E|S|>=(E S^2)^(3/2)/(E S^4)^(1/2). Insert (3)-(5) and use 2304^(3/2)=48^3 and sqrt(100000)<320 to obtain (7). Thus, on 0<eta<=1/48, the scaling min(n,sqrt(n/eta)) is real up to absolute constants; it is not an artefact of one Cauchy upper bound.

For arbitrary f, the fixed-window physical variation has upper bound T||D_(n,eta)||1 W. Its optimal universal constant cannot be smaller than T||D_(n,eta)||1: positive approximate-identity inputs converge in L1 after convolution to each dilated flux, and dominated convergence on the compact physical window applies. This concerns the ABSOLUTE space-time continuous-variation budget. It does not prove a lower bound of that size for a weak maximal norm, nor exclude a method retaining additional cancellation.

For example eta approximately 1/n makes this variation order n for all sufficiently large n, when eta<=1/48. Width eta=n^{-o(1)} permits the upper budget sqrt(n)n^{o(1)}, but its mean cone potential n mu_eta has order n eta, still very large. This tradeoff matters only if one tries to use the narrow kernel as a new globally paid smooth baseline.

## 4. Conditional likelihood payment does not require a narrow baseline

At any original common source/receiver/scale with A_L>0, the hard posterior is pi(z)=f(x-Lz)H(z)/A_L. Put ell_eta(z)=sum_j ell_eta(z_j). The actual captured smooth contribution gives

    E_pi exp(-ell_eta)<=P_eta,L/A_L.                (8)

For s real, P_eta,L/A_L<=exp(-s)/2 forces at least half the captured source mass into {ell_eta>s}. Its radial cone enlargement K_(eta,s)=H(z)1_{ell_eta(omega)>s}, omega=z/(2||z||infinity), is ray decreasing and has mass delta_(eta,s). The R82 sourcewise envelope argument, unchanged in direction, proves for ANY selected common scale in [1,2],

    lambda |{A_L>=lambda, P_eta,L/A_L<=exp(-s)/2}|
       <=2(1+nT) delta_(eta,s) W.                   (9)

No maximal estimate for P_eta is used in (9). In particular, keeping the old eta=1 smooth exception in the original hard first-hit reduction, one can inspect additional small eta likelihoods conditionally without paying their O(n) physical baseline variation.

Under uniform cube cone measure,

    delta_(eta,s)=Pr{ell_edge,eta+sum_(j=1)^(n-1) X_j>s},
    X_j=ell_eta(U_j), U_j independent uniform[-1/2,1/2]. (10)

These are reference geometry variables, not the input posterior coordinates.

## 5. Finite Bennett-type bound and a subpower cutoff at eta<=1/n

A plain bounded-range Hoeffding estimate loses the small eta variance. A sharper exact finite mgf bound follows just from (2). For t>=0, the chord bound on [0,b] gives

    E exp(tX)<=1+[(exp(tb)-1)/b] EX
       <=exp[(2eta/b)(exp(tb)-1)].                 (11)

Let N=n-1 and Lambda_eta=2N eta/b. For n>=2, eta>0, Chernoff optimization at exp(tb)=z/Lambda_eta gives

    Pr{sum_j X_j>=b z}<=exp[-I_(Lambda_eta)(z)],
    I_Lambda(z)=z log(z/Lambda)-z+Lambda,
    z>=Lambda.                                    (12)

This is a proved finite-sample upper bound, not an LDP or a tail asymptotic. For r>0 let z(Lambda,r)>Lambda be the unique root I_Lambda(z)=r, and take

    s(eta,r)=ell_edge,eta+b z(Lambda_eta,r).         (13)

Then delta_(eta,s)<=exp(-r). One may conservatively replace ell_edge,eta by b in this threshold; this makes the paid branch smaller but leaves the proof valid. For n=1 the cone potential is deterministic and may be handled directly.

If eta<=1/n, Lambda_eta<2. For r>=exp(4), elementary substitution proves

    z(Lambda_eta,r)<=4r/log r.                     (14)

Indeed I_Lambda(z) is decreasing in Lambda for Lambda<z, so it suffices to use Lambda=2. At z=4r/log r, log(z/2)-1>=log r/2 for log r>=4; hence I_2(z)>=2r. Consequently when r=O(log n),

    s(eta,r)=O(log n/log log n),
    beta(eta,r)=(1/2)exp[-s(eta,r)]=n^{-o(1)}.      (15)

The bound is not asserted uniformly in r below exp(4); there one uses the exact unique root in (13). Constants and finite n are therefore explicit. For a coarse finite width the conservative threshold can exceed n ell_edge,eta; the corresponding cone event is then empty. Such a cutoff is not evidence of useful coverage of the complementary event. A variance-sensitive Bernstein alternative also follows from Var X<=2b eta, but (12) is strictly more useful for the bounded-total-mean regime n eta=O(1).

## 6. Many tunable widths at one actual hard selector

Let eta_j in (0,1] be any finite or countable predetermined collection, with weights a_j>0 and sum_j a_j<=1. Set

    r_j=(1/2)log(n+2)+log(1/a_j),
    s_j=s(eta_j,r_j), beta_j=exp(-s_j)/2.

At the SAME original selected hard scale L(x), the union of all events

    A_L>=lambda and P_(eta_j),L/A_L<=beta_j

has the all-input bound

    lambda |union_j E_j|
       <=2(1+nT)W/sqrt(n+2).                       (16)

This follows from (9), delta_j<=exp(-r_j)=a_j/sqrt(n+2), and the ordinary countable union bound. It is not a weak quasi-norm sum, not conditional weak-norm averaging, and not a collection of private selectors. A selector j(x) chosen after seeing the input is also covered by this union. No baseline payment for every eta_j is inserted or needed.

For example eta_j=2^{-j}, a_j=1/[(j+1)(j+2)] has total weight one. The first j with eta_j<=1/n has j=O(log n), r_j=O(log n), and hence a subpower beta_j as in (15). After the O(sqrt(n)) exception in (16), this narrow-scale likelihood satisfies P_(eta_j),L>beta_j A_L. This is a subpower floor for the different kernel P_(eta_j). It does not strengthen the old P_1 floor, and no automatic set inclusion between this complement and the R82 middle is asserted. The finite-rate cutoff at eta=1 may itself be more conservative than the former cutoff.

The budget in (16) is for the new single union only. The old eta=1 smooth-baseline exception from the hard first-hit reduction is distinct from the R82 extreme-likelihood deletion. Retaining that old extreme-likelihood deletion in addition to (16) requires its additional explicit O(sqrt(n)) charge, unless both families are incorporated into a newly allocated common threshold budget. No such extra deletion is silently included here.

It does NOT pay the complementary receivers. On them a narrow smooth average can be comparable to the original hard average; its maximal operator has not been bounded by the desired constant. Replacing the old smooth baseline with it would incur the genuine variation obstruction (7). A further argument must use the common family and signed/conditional structure without making that replacement.

## 7. Distinct noise-parameter differentiation: a valid bridge with an unpaid adaptive step

There is a different Fisher statement that must not be confused with (3)-(7). For fixed physical L, differentiate only eta. The noise w_eta is a fixed mixture of Laplace_(eta t) with mixing density 2t. Each Laplace noise scale score has mean zero and variance one. Conditional expectation under the mixture, followed by convolution with the independent uniform h variable, contracts its squared score. Hence

    integral (eta partial_eta phi_eta)^2/phi_eta<=1,
    ||eta partial_eta Phi_eta||1<=sqrt(n).          (17)

The actual scalar formula gives a stronger small-width estimate, not merely the contraction bound. Write a=(x-1/2)/eta, c=(x+1/2)/eta. Exactly eta partial_eta phi_eta=a w(a)-c w(c). Inside Q this is -u w(u)-v w(v), with u,v the two nonnegative scaled distances. Using phi_eta>=1/3, w(u)<=exp(-u), and (r+s)^2<=2r^2+2s^2, the integrated noise Fisher contribution is at most 3eta. Outside, put u=(|x|-1/2)/eta and c=1/eta>=1. Then phi_eta>=w(u)/4 and w(u+c)<=exp(-c)w(u). The two outside contributions are at most

    16eta [2+exp(-2c)(2+2c+c^2)]<=48eta.

The bracketed second term is decreasing for c>=1 and is less than one there. Hence

    integral (eta partial_eta phi_eta)^2/phi_eta<=min(1,51eta).

For every FIXED physical L and every f this proves the full-width variation budget

    integral dx integral_0^1
             |f*(eta partial_eta Phi_eta)_L| d eta/eta
       <=(2+log 51)sqrt(n) W.                      (18)

Indeed integrate sqrt(n min(1,51eta)) against d eta/eta, splitting at eta=1/51. The bound is uniform even when the registered widths approach zero. On finite eta intervals the differentiation identity is ordinary; the hard endpoint is obtained by approximate-identity convergence of w_eta and the finite integrated variation.

This is a general fixed-L statement. The exact common-source identity

    P_eta,L=P_1,L-integral_eta^1 f*(v partial_v Phi_v)_L dv/v

also holds at an actual selected L(x). But (18) cannot simply be used after making L depend on x: that requires a new budget for the selected physical-scale parameter flux. Interchanging a supremum and an integral does not supply this budget. The distinction between the two scale parameters is essential; the bounded noise-parameter Fisher information does not contradict the large physical-dilation norm in (7).

## 8. Validation and proof status

The main new general result is the common-selector multi-width payment (16), with the actual E2 finite-rate threshold (12)-(15). The actual physical flux lower bound (7) explains the limit of paying a narrow smooth baseline by absolute variation. The noise-parameter bridge (18) is valid only with its fixed-physical-scale hypothesis.

The independent guard below uses three stages of actual scalar E2 quadrature over eta and n, checks the exact rate-root inequalities and the common-weight budget, and reports the physical Fisher/likelihood tradeoff. Quadrature values are diagnostics, not interval certificates. The analytic proofs, not the numerical probes, establish the universal statements. The final weak centered-cube theorem and the complementary multi-width likelihood event remain open.

```python
import math
from functools import lru_cache
b=math.log(3)
T=math.log(2)
@lru_cache(None)
def AW(u,N=200):
    if u==0: return (.5,1.)
    if u>80: return (0.,0.) # Exponentially small diagnostic tail, not a certificate.
    sa=sw=0.
    for j in range(1,N+1):
        t=j/N
        coef=1 if j==N else (4 if j%2 else 2)
        z=math.exp(-u/t)
        sa+=coef*t*z; sw+=coef*z
    return sa/(3*N),sw/(3*N)
def simpson(f,a,c,N=320):
    if c<=a:return 0.
    return (c-a)*(f(a)+f(c)+sum((4 if j%2 else 2)*f(a+(c-a)*j/N) for j in range(1,N)))/(3*N)
def fields(eta,x):
    if x<=.5:
        u=(.5-x)/eta; v=(.5+x)/eta
        au,wu=AW(u); av,wv=AW(v)
        p=1-au-av; dp=(wv-wu)/eta
        noise=-u*wu-v*wv
    else:
        u=(x-.5)/eta; v=(x+.5)/eta
        au,wu=AW(u); av,wv=AW(v)
        p=au-av; dp=(wv-wu)/eta
        noise=u*wu-v*wv
    return p,dp,noise

def scalar(eta):
    cut=max(0.,.5-8*eta)
    def integ_inside(fun):
        return 2*simpson(lambda x:fun(*fields(eta,x),x),0,cut,80)+2*eta*simpson(lambda u:fun(*fields(eta,.5-eta*u),.5-eta*u),0,(.5-cut)/eta)
    def integ_out(fun):
        return 2*eta*simpson(lambda u:fun(*fields(eta,.5+eta*u),.5+eta*u),0,30)
    mu=integ_inside(lambda p,dp,q,x:-math.log(p))
    score2=lambda p,dp,q,x:(p+x*dp)**2/p
    score4=lambda p,dp,q,x:(p+x*dp)**4/p**3
    noise2=lambda p,dp,q,x:q*q/p
    J=integ_inside(score2)+integ_out(score2)
    fourth=integ_inside(score4)+integ_out(score4)
    Jnoise=integ_inside(noise2)+integ_out(noise2)
    edge=-math.log(fields(eta,.5)[0])
    return mu,J,fourth,Jnoise,edge

def rate(Lam,z):return z*math.log(z/Lam)-z+Lam

def root(Lam,r):
    lo=Lam; hi=Lam+r+1
    while rate(Lam,hi)<r:hi*=2
    for _ in range(100):
        mid=(lo+hi)/2
        if rate(Lam,mid)<r:lo=mid
        else:hi=mid
    return hi

checks=0
assert 48**3*320<40000000 and 49/3<100000
checks+=1
for n in [16,64,256]:
    j=math.ceil(math.log2(n)); weight=1/((j+1)*(j+2))
    r=.5*math.log(n+2)+math.log(1/weight)
    for eta in [1/math.log(n+2),2**(-j)]:
        mu,J,m4,Jnoise,edge=scalar(eta)
        assert eta/3-1e-5<=mu<=2*eta+1e-5
        assert J<=1/eta+4*eta/3+.002
        assert Jnoise<=1.002
        assert Jnoise<=51*eta+.002
        assert m4<=100000/eta**3
        checks+=5
        if eta<=1/48:
            assert J>=1/(2304*eta)-1e-5
            checks+=1
        Lam=2*(n-1)*eta/b; z=root(Lam,r)
        assert abs(rate(Lam,z)-r)<1e-10
        checks+=1
        threshold=edge+b*z
        beta=.5*math.exp(-threshold)
        fluxupper=min(2*n,math.sqrt(n*(1/eta+4*eta/3)))
        fluxlower=n/(40000000*math.sqrt(1+n*eta)) if eta<=1/48 else 0.
        print('E2_stage',n,'eta',format(eta,'.8g'),'mu_quad',format(mu,'.8g'),
              'Jphysical_quad',format(J,'.8g'),'Jnoise_quad',format(Jnoise,'.8g'),
              'fourth_quad',format(m4,'.8g'),'cone_cutoff',format(beta,'.8g'),
              'physical_flux_bounds',(fluxlower,fluxupper))
    total=sum(math.exp(-(.5*math.log(n+2)+math.log((k+1)*(k+2)))) for k in range(j+1))
    assert total<=1/math.sqrt(n+2)+1e-14
    checks+=1
# Three finite exact-rate pressure ranges beyond the asymptotic cutoff condition.
for r in [math.exp(4),1000.,1000000.]:
    z=4*r/math.log(r)
    assert rate(2.,z)>=2*r-1e-9
    checks+=1
print('PASS',checks,'assertions; deterministic E2 quadrature and rate-root diagnostics')
```

Actual stdout:

```text
E2_stage 16 eta 0.34597626 mu_quad 0.2648115 Jphysical_quad 1.7234833 Jnoise_quad 0.43367828 fourth_quad 11.746093 cone_cutoff 3.9519772e-11 physical_flux_bounds (0.0, 7.323030446924103)
E2_stage 16 eta 0.0625 mu_quad 0.047948536 Jphysical_quad 8.5254348 Jnoise_quad 0.083972092 fourth_quad 1059.3074 cone_cutoff 9.3522002e-05 physical_flux_bounds (0.0, 16.041612554021285)
E2_stage 64 eta 0.23868315 mu_quad 0.18318973 Jphysical_quad 2.3280914 Jnoise_quad 0.31721004 fourth_quad 22.72674 cone_cutoff 4.7239945e-24 physical_flux_bounds (0.0, 16.98545061127687)
E2_stage 64 eta 0.015625 mu_quad 0.011987134 Jphysical_quad 34.549134 Jnoise_quad 0.020992999 fourth_quad 73966.141 cone_cutoff 2.9340214e-05 physical_flux_bounds (1.131370849898476e-06, 64.0104158190941)
E2_stage 256 eta 0.18008415 mu_quad 0.13819407 Jphysical_quad 3.001377 Jnoise_quad 0.24201268 fourth_quad 45.200214 cone_cutoff 5.5976198e-59 physical_flux_bounds (0.0, 38.51008149199113)
E2_stage 256 eta 0.00390625 mu_quad 0.0029967903 Jphysical_quad 138.88013 Jnoise_quad 0.0052482499 fourth_quad 4866790.8 cone_cutoff 1.2319343e-05 physical_flux_bounds (4.525483399593904e-06, 256.0026041534213)
PASS 45 assertions; deterministic E2 quadrature and rate-root diagnostics
```

Guard SHA256: `fe7b5452612e90010919a9b55e94b25c6dd1ca30be6dda21a83615a8d5a88792`.


# R83 peeling: principal Hall blocks, an exact recycling deficit, and actual first-hit leakage

**Status.** The finite principal partition and common transport are proved exactly. The resulting load vector minimizes every convex source-load cost, with an explicit quadratic deficit identity. Low-density blocks are genuinely paid. An actual positive L1 first-hit family inside a fixed physical window shows that an arbitrarily small gap between block densities does not imply small captured-source loss: a later block can lose arbitrarily close to all its original captured mass. Its anchor gate is retained; the smooth gate is not asserted. No dimension-uniform estimate for the high-density blocks is proved, so the general sqrt(n)n^{o(1)} goal remains open.

Read the updated E03, M03 and B01 boundaries. Tree mass flow is proved for this finite graph, not inferred for nonnested centered cubes. The stability identity below is derived directly; no generic near-extremizer theorem is invoked. Receiver demands always retain original dx volume. Only these two owned files and the embedded guard are changed; no Git or TeX compilation.

## 1. The actual finite graph and its maximal tight block

Take positive source masses p_i and positive receiver demands d_r. Each row has a nonempty original allowed neighborhood N_r, either capture or fresh at a frozen actual selector. For finite geometric cells d_r=lambda |cell_r|. Define

    p(S)=sum_(i in S)p_i,
    F(S)=sum_(r:N_r subset S)d_r, F(empty)=0.

F is supermodular: F(A)+F(B)<=F(A union B)+F(A intersection B). Each indicator 1{N_r subset S} obeys the inequality, hence so does their positive sum. The optimal common source capacity is the exact Hall value

    K=max_(nonempty S) F(S)/p(S).

This source-subset form equals the receiver-subset Hall formula: the rows forced by S have neighborhood inside S, and any receiver subset is forced by its neighborhood union.

The zero set of G(S)=F(S)-Kp(S)<=0 is closed under union and intersection, including the empty set. Indeed supermodularity and the nonpositive bound force equality in both terms whenever A and B are tight. There is therefore a unique maximal maximizing set S_1, the union of all positive-density maximizers. Remove S_1 and exactly its forced rows R_1={r:N_r subset S_1}. Delete S_1 from every remaining neighborhood. None becomes empty, because such a row would already have been forced.

For a remaining source subset T,

    F_res(T)=F(S_1 union T)-F(S_1)<=Kp(T).                 (1)

If T is nonempty and equality holds, S_1 union T was also a maximizer, contradicting maximality. Hence the next positive maximum is strictly smaller than K. This strictness requires p_i>0 and the MAXIMAL tight block; choosing one arbitrary smaller tight set need not give it.

Repeat. Write source blocks S_j, cumulative C_j=union_(k<=j)S_k, row blocks R_j, and densities

    K_1>K_2>...>K_m>0.

Sources unused after all rows are removed form a final density-zero block. Original row r lies in R_j exactly when N_r subset C_j but N_r is not subset C_(j-1). Its residual neighborhood is N_r intersection S_j, nonempty. In particular

    F(C_j)=sum_(k<=j)d(R_k)=sum_(k<=j)K_k p(S_k).          (2)

This is a finite principal partition with real shared source ownership. It is not a geometric tree of independently centered cubes.

## 2. Common transport and a genuine paid low-density branch

Inside block j, every source subset U subset S_j forces at most K_j p(U) of its block-row demand. This is the residual Hall inequality. Therefore the finite Hall theorem supplies a block transport with source capacities K_j p_i. Its total demand is exactly K_j p(S_j), so EVERY source in S_j is saturated to that load. Taking the disjoint union of these flows produces a common transport of all original demands with normalized source load

    k_i=K_j for i in S_j, k_i=0 on unused sources.          (3)

No source capacity is independently recreated for different rows or different peeling times. The maximum load is the original optimal K_1; transport still uses original allowed edges, since every residual edge was an original edge.

For any threshold t>=0, rows in blocks with K_j<=t have the exact payment

    sum_(j:K_j<=t)d(R_j)=sum_(j:K_j<=t)K_jp(S_j)
                         <=t sum_(j:K_j<=t)p(S_j)<=t W.   (4)

Thus t=sqrt(n) gives a valid general square-root payment for these low-density blocks, once the finite graph represents the actual event. This says neither that many rows lie there nor that K_1<=t. The remaining high-density blocks are not paid by (4).

## 3. Convex optimality and an exact quadratic stability identity

Let any other feasible transport have normalized source loads b_i, so sum p_i b_i=sum d_r. Every cumulative C_j must receive at least its forced demand F(C_j). Hence, for any t>=0, choosing C_j as the blocks with K_j>t gives

    sum_i p_i(b_i-t)_+ >=sum_(i in C_j)p_i(b_i-t)
                        >=sum_i p_i(k_i-t)_+.             (5)

By piecewise linear interpolation of a convex function at the finitely many b_i and k_i values, (5) and equality of total load imply

    sum_i p_i Phi(b_i)>=sum_i p_i Phi(k_i)                 (6)

for EVERY convex Phi on the relevant finite interval. This includes squared load, powers, and b log b with 0 log0=0. These are source-LOAD functionals, not a claim about input entropy or near-extremizer geometry. Strict convexity makes the optimal load vector unique; the realizing edge flow need not be unique.

There is a sharper exact identity. For the given feasible flow let L_jk be its mass sent from row block j to source block k. Original adjacency forces k<=j; rows in block j have no edges outside C_j. Let B_k=sum_(j>=k)L_jk=sum_(i in S_k)p_i b_i. Then

    sum_(k<=j)L_jk=K_j p(S_j),
    sum_i p_i k_i(b_i-k_i)
        =sum_(j>k)(K_k-K_j)L_jk >=0.                     (7)

Consequently

    sum_i p_i b_i^2-sum_i p_i k_i^2
      =sum_i p_i(b_i-k_i)^2
         +2 sum_(j>k)(K_k-K_j)L_jk.                     (8)

This is a proved quantitative stability statement, with all constants explicit. Small quadratic excess controls weighted L2 load error and density-gap-weighted recycling. It does NOT control unweighted cross-block mass unless a positive density gap is available. If K_k-K_j>=g>0 on a selected set of pairs, their transported mass is at most [quadratic excess]/(2g). No uniform g is supplied by first-hit geometry.

More generally any increasing phi gives the accounting identity

    sum_i p_i b_i phi(k_i)-sum_i p_i k_i phi(k_i)
      =sum_(j>k)[phi(K_k)-phi(K_j)]L_jk.

This is bookkeeping on the one shared flow. It does not create a favorable upper bound on its right side.

## 4. Physical capture leakage is distinct from transport recycling

For the canonical captured-source posterior on an original geometric row, let m_r=mu(Q_r), and define pi_ri=p_i 1{i captured}/m_r. It is a feasible row transport after multiplying by d_r. On the CAPTURE graph, a row in R_j has original captured sources only in C_j, and

    ell_r=mu(Q_r intersection C_(j-1))/mu(Q_r)

is exactly its posterior fraction assigned to earlier blocks. Thus

    sum_r d_r ell_r =sum_(j>k)L_jk.                       (9)

At a true continuous level contact m_r=lambda L_r^n, restriction to the new physical block gives

    A_(L_r)(mu|S_j)=(1-ell_r)lambda.                     (10)

It usually fails to reach the original threshold. Its old hard first hit and the hard/smooth ratio labels must not be inherited. Smooth positive convolutions only decrease under source restriction; a lower ratio floor need not survive, and even an upper gate at a newly lowered threshold needs a fresh check. On a FRESH graph, excluded old sources may not belong to any graph neighborhood, so (9)--(10) must be replaced by their allowed-source versions; the full hard captured-mass interpretation is asserted only for the capture graph.

There is a safe general window leakage bound, but it is only linear in n. Original receiver blocks are disjoint, and for each physical source the later-row domain is a subset of the whole receiver domain. The true hard [1,2] source envelope therefore gives

    sum_r d_r ell_r <=(1+n log2)W                          (11)

at exact contacts, by Tonelli. The same inequality holds for first strict finite-grid hits because d_r/m_r=lambda |cell_r|/m_r<=|cell_r|/L_r^n. Consequently the rows with ell_r>=a have demand at most (1+n log2)W/a. This has no extra number-of-blocks factor, but does not achieve the desired square-root fee. Equations (8) and (11) identify two legitimate budgets and their actual limitations.

## 5. A true L1 first-hit countertest: tiny density gaps with almost total later loss

This is continuous hard first-hit geometry, not a finite-grid surrogate. Work in n=1, lambda=1, with f=4 1_[0,1]. At receiver x=-a, 0<a<1, the actual first-hit half-radius is r=2a, full side L=4a, and the captured source is [0,a]. For r<a there is no mass; for a<r<2a the average is 2-2a/r<1; at r=2a it equals one and then crosses strictly while r-a<1.

Choose

    a_0=13/32, a_1=7/16, K_1=(a_1-a_0)/(4a_1)=1/56,
    0<delta<1/16, b_1=a_1+delta,
    0<epsilon<K_1, K_2=K_1-epsilon,
    b_0=b_1-4K_2 delta.

Let receiver a range over I_1=[a_0,a_1] and I_2=[b_0,b_1]. Both have positive Lebesgue length; b_0>a_1. Every selected L=4a lies in [1,2], and the unit-anchor average is 4(1/2-a)<=3/8<1/2. The local density f(x) is zero. The smooth upper gate is NOT asserted, so this is not advertised as the whole retained middle-event counterexample.

### Exact continuum Hall blocks

The captured-source neighborhoods are nested intervals [0,a]. Any source subset forcing receivers up to a parameter s must contain [0,s] up to source-null sets, hence has mass at least 4s. Extra non-prefix mass forces no additional receivers. The forced-demand density on the first receiver interval is (s-a_0)/(4s), increasing to K_1 at s=a_1. On the gap it decreases. On the second interval it increases to

    [(a_1-a_0)+(b_1-b_0)]/(4b_1)
      =[K_1(4a_1)+K_2(4delta)]/[4a_1+4delta]<K_1.

Thus the unique maximal first block is S_1=[0,a_1] modulo null sets. After deleting it, the remaining neighborhoods are (a_1,a]; their maximal density is K_2 at S_2=(a_1,b_1]. The unused source (b_1,1] has density zero. This is the continuum counterpart of the exact finite principal partition, proved directly for the real input.

There are explicit common block transports: in block one assign the receiver parameter

    a=a_0+4K_1 y,   0<=y<=a_1,

and in block two assign

    a=b_0+4K_2(y-a_1),   a_1<=y<=b_1.

The maps satisfy y<=a, hence use actual captured edges. Source density 4K_j dy pushes forward to receiver density da, so each block saturates precisely its common capacity K_j f(y)dy. The reflection x=-a preserves dx. No source is used in both blocks.

### Loss and the failure of gap-only stability

For a receiver in I_2, the lost captured fraction is

    ell(a)=a_1/a >=a_1/(a_1+delta),

which tends to one as delta tends to zero. At its unchanged original first hit, the block-only average is

    A_(4a)(f 1_S2)=(a-a_1)/a <=delta/(a_1+delta),

rather than the original level one. Since the restricted input is pointwise smaller, no earlier original-threshold hit can have appeared. The old selector is therefore not a first hit for that physical block.

The actual canonical recycling mass is

    L_21=integral_b0^b1 a_1/a da=a_1 log(b_1/b_0),
    [a_1/b_1](b_1-b_0)<=L_21<=[a_1/b_0](b_1-b_0).       (12)

For fixed delta, as epsilon decreases to zero, L_21 stays bounded away from zero whereas (K_1-K_2)L_21=epsilon L_21 tends to zero. Thus density-gap-weighted recycling alone does not control unweighted leakage even in this actual fixed-window first-hit geometry. Taking delta small additionally makes the lost fraction arbitrarily close to one. This does not contradict the full quadratic identity (8), which retains the load-variance term, nor does it produce a large weak maximal constant. It disproves precisely the proposed automatic small-gap-to-small-loss inference.

## 6. What remains and what the exact structure provides

The principal transport removes source-load imbalance optimally for every convex objective and yields the general paid low-density branch (4). It also gives an exact, non-assumed recycling deficit (8). These are usable certificates. They do not bound the first density K_1 or the mass of the high-density blocks. In particular, top-block restriction recovers a genuine hard retained input only through the earlier properly inflated capture-cut argument; later blocks cannot reuse that argument after old captured sources are deleted. The actual example above shows the failure concretely.

A square-root route now needs an independent geometric estimate for high-density blocks, or an upper bound for a recycling/deficit quantity strong enough to pay their residual rows with no division by arbitrarily small gaps. None is established here. Finite first-hit cell computations owned by the numerical agent test the exact identities and record changes of selector after block restriction; they do not by themselves prove this missing geometry.

### Complete spatial finite-grid witness

An independently supplied spatial input, rechecked by the embedded guard on its entire face arrangement, has n=1, lambda=1/8, sides (1,5/4,3/2,7/4,2), sites (-9/8,0,1/16,1/2,5/8), and masses (23/70,3/70,3/10,6/35,11/70). Removing the anchor-paid rows A_1>=lambda/2 gives principal densities (35/184,35/192,105/736,5/96). The entire open cell (-5/8,-9/16), of volume 1/16, has anchor average zero and first strict side 5/4 with average 52/175. Its captured mass is 13/35 from the sites -9/8 and zero. It belongs to block two, whose only source is zero with mass 3/70. Thus it loses fraction 23/26. The block-only averages at the five sides are (0,6/175,1/35,6/245,3/140), all below lambda. This is positive-volume actual hard-cube finite-grid geometry; it is not claimed to be continuous-first-hit or a smooth retained-event example.

## 7. Embedded guard

The stdlib guard verifies supermodularity, maximal-cut peeling, residual strictness, exact feasible block flows, the convex hinge inequalities and quadratic recycling identity on rational finite graphs. It separately verifies the actual positive L1 first-hit family and its physical capture loss with exact rational inequalities; logarithmic displays in (12) are diagnostics. Independent numerical files use complete spatial receiver cells and are not replaced by these algebra tests.

```python
from fractions import Fraction as Q
from collections import deque
from random import Random

def mass(p,S): return sum((p[i] for i in S),Q(0))
def subsets(S):
    a=sorted(S)
    return [frozenset(a[i] for i in range(len(a)) if z>>i&1) for z in range(1<<len(a))]
def forced(rows,S): return sum((d for N,d in rows if N<=S),Q(0))
def peel(p,rows):
    left=set(range(len(p))); rr=list(range(len(rows))); blocks=[]
    while rr:
        fs=subsets(left)[1:]
        vals=[(forced([(rows[r][0]&left,rows[r][1]) for r in rr],S)/mass(p,S),S) for S in fs]
        K=max(v for v,S in vals)
        S=frozenset().union(*(S for v,S in vals if v==K))
        R=[r for r in rr if rows[r][0]&left<=S]
        assert K>0 and sum((rows[r][1] for r in R),Q(0))==K*mass(p,S)
        if blocks: assert K<blocks[-1][0]
        blocks.append((K,S,R)); left-=S; rr=[r for r in rr if r not in R]
    return blocks

def flow(p,rows,K,S,R):
    # Exact residual max flow; the final capacity sum equals row demand.
    root=('root',); sink=('sink',); cap={}; adj={}
    def edge(a,b,c):
        adj.setdefault(a,[]).append(b); adj.setdefault(b,[]).append(a)
        cap[a,b]=c; cap[b,a]=Q(0)
    D=sum((rows[r][1] for r in R),Q(0))
    for r in R:
        edge(root,('r',r),rows[r][1])
        for i in rows[r][0]&S: edge(('r',r),('s',i),D)
    for i in S: edge(('s',i),sink,K*p[i])
    total=Q(0)
    while True:
        prev={root:None}; queue=deque([root])
        while queue and sink not in prev:
            a=queue.popleft()
            for b in adj[a]:
                if b not in prev and cap[a,b]>0: prev[b]=a; queue.append(b)
        if sink not in prev: break
        b=sink; aug=D
        while prev[b] is not None: a=prev[b]; aug=min(aug,cap[a,b]); b=a
        b=sink
        while prev[b] is not None: a=prev[b]; cap[a,b]-=aug; cap[b,a]+=aug; b=a
        total+=aug
    assert total==D
    assert all(cap[('s',i),sink]==0 for i in S)

def check(p,rows):
    allS=subsets(set(range(len(p)))); F={S:forced(rows,S) for S in allS}
    for A in allS:
        for B in allS: assert F[A]+F[B]<=F[A|B]+F[A&B]
    blocks=peel(p,rows); ki=[Q(0)]*len(p); owner={}; rowowner={}
    for j,(K,S,R) in enumerate(blocks):
        flow(p,rows,K,S,R)
        for i in S: ki[i]=K; owner[i]=j
        for r in R: rowowner[r]=j
    b=[Q(0)]*len(p); L={}
    for r,(N,d) in enumerate(rows):
        for i in N:
            z=d*p[i]/mass(p,N); b[i]+=z/p[i]
            j,k=rowowner[r],owner[i]; assert k<=j
            L[j,k]=L.get((j,k),Q(0))+z
    for t in set(b+ki+[Q(0)]):
        assert sum(p[i]*max(b[i]-t,0) for i in range(len(p)))>=sum(p[i]*max(ki[i]-t,0) for i in range(len(p)))
        assert sum(sum((rows[r][1] for r in R),Q(0)) for K,S,R in blocks if K<=t)<=t*sum(p)
    excess=sum(p[i]*(b[i]**2-ki[i]**2) for i in range(len(p)))
    var=sum(p[i]*(b[i]-ki[i])**2 for i in range(len(p)))
    recycle=sum((blocks[k][0]-blocks[j][0])*z for (j,k),z in L.items() if j>k)
    assert excess==var+2*recycle
    return blocks

rng=Random(8301); counts=[0,0,0]
for n in range(2,7):
    for trial in range(12):
        p=[Q(rng.randint(1,12),13) for i in range(n)]
        rows=[]
        for r in range(2*n+1):
            N=frozenset(i for i in range(n) if rng.randrange(2)) or frozenset([rng.randrange(n)])
            rows.append((N,Q(rng.randint(1,15),17)))
        check(p,rows); counts[0]+=1

# Full dx arrangement, not endpoint sampling. Every hard capture mask is constant per cell.
def spatial(ys,p,lam,J):
    faces=sorted(set(y+s*L/2 for y in ys for L in J for s in [-1,1]))
    rows=[]; cells=[]
    for a,b in zip(faces,faces[1:]):
        x=(a+b)/2
        masks=[frozenset(i for i,y in enumerate(ys) if abs(x-y)<L/2) for L in J]
        av=[mass(p,N)/L for N,L in zip(masks,J)]
        if av[0]>=lam/2: continue
        hits=[j for j,v in enumerate(av) if v>lam]
        if not hits: continue
        j=hits[0]; rows.append((masks[j],lam*(b-a))); cells.append((a,b,j,masks,av))
    return rows,cells
J=list(map(Q,[1]))+[Q(5,4),Q(3,2),Q(7,4),Q(2)]
fixtures=[([Q(-3,4),Q(0),Q(3,4)],[Q(31,64),Q(1,32),Q(31,64)],Q(1,4)),
([Q(-7,8),Q(-3,4),Q(13,16)],[Q(13,50),Q(11,50),Q(13,25)],Q(1,8)),
([Q(-9,8),Q(0),Q(1,16),Q(1,2),Q(5,8)],[Q(23,70),Q(3,70),Q(3,10),Q(6,35),Q(11,70)],Q(1,8))]
for ys,p,lam in fixtures:
    rows,cells=spatial(ys,p,lam,J); blocks=check(p,rows); counts[1]+=1
    if len(ys)==5:
        assert [K for K,S,R in blocks]==[Q(35,184),Q(35,192),Q(105,736),Q(5,96)]
        r=next(r for r,c in enumerate(cells) if c[:2]==(Q(-5,8),Q(-9,16)))
        a,b,j,masks,av=cells[r]; assert j==1 and av[j]==Q(52,175) and av[0]==0
        assert r in blocks[1][2] and blocks[1][1]==frozenset([1])
        N=rows[r][0]; assert N==frozenset([0,1])
        assert p[0]/mass(p,N)==Q(23,26)
        blockav=[mass(p,M&blocks[1][1])/L for M,L in zip(masks,J)]
        assert blockav==[Q(0),Q(6,175),Q(1,35),Q(6,245),Q(3,140)]
        assert all(v<lam for v in blockav)

# Actual continuous L1 input 4*1_[0,1], exact interval integrations.
a0=Q(13,32); a1=Q(7,16); K1=Q(1,56)
for delta in [Q(1,64),Q(1,256),Q(1,1024)]:
    for denom in [2,16,256,4096]:
        eps=K1/denom; K2=K1-eps; b1=a1+delta; b0=b1-4*K2*delta
        assert a0<a1<b0<b1<Q(1,2)
        assert (a1-a0)/(4*a1)==K1 and (b1-b0)/(4*delta)==K2
        assert ((a1-a0)+(b1-b0))/(4*b1)<K1
        for a in [a0,(a0+a1)/2,a1,b0,(b0+b1)/2,b1]:
            L=4*a; assert 1<L<2 and 4*(Q(1,2)-a)<Q(1,2)
            for factor in [Q(1,2),Q(3,4),Q(1),Q(9,8)]:
                r=2*a*factor; A=4*max(Q(0),min(Q(1),r-a))/(2*r)
                assert (A<1 if factor<1 else A==1 if factor==1 else A>1)
        for y in [Q(0),a1/2,a1]: assert y<=a0+4*K1*y
        for y in [a1,(a1+b1)/2,b1]: assert y<=b0+4*K2*(y-a1)
        for a in [b0,(b0+b1)/2,b1]:
            loss=a1/a; residual=(a-a1)/a
            assert loss>=a1/b1 and residual<=delta/b1 and loss+residual==1
        lower=a1/b1*(b1-b0); upper=a1/b0*(b1-b0)
        assert 0<lower<=upper and eps*upper<K1*upper
        counts[2]+=1
print('PASS',dict(zip(['rational_graphs','complete_spatial_inputs','continuous_L1_parameters'],counts)))
```


# R83: Hall-cut slack, spatial erosion, and interior fresh overlap

**Status.** The general square-root weak bound is still unproved. This component derives exact variational conditions for a worst capture-Hall cut, and an exact source-weighted decomposition of fresh incoming mass into an outer-boundary term and an interior-overlap term. The latter cannot be dropped: a genuine L1 input has a worst capture-Hall set satisfying the physical [1,2] window, both R81 gates, and the R82 middle condition, yet has zero source mass in a large outer boundary layer of its selected-cube union. Every receiver still has positive fresh incoming mass. Its Hall constant is small; this is not a counterexample to a high-Hall-ratio theorem or to the maximal conjecture.

N02 and G01 updated skills were read. No log-concavity of arbitrary f, PL/BBL bound for its weighted unions, or Carleson packing theorem is assumed. The set inclusions, variational identities, and explicit geometry below are proved directly. The source measure is always mu(dy)=f(y)dy and receiver demand is lambda dx.

## 1. Actual common selector and the capture-Hall functional

Let f>=0 belong to L1(R^n), and use half-side radius r in [a,b]=[1/2,1]. Write Q_x=x+[-r(x),r(x)]^n. On the retained receiver set X, r(x) is the actual first strict window hit at level lambda:

    A_(1/2)f(x)<lambda/2,   A_(r(x))f(x)=lambda,
    A_s f(x)<=lambda for 1/2<=s<r(x),
    sup_(1/2<=s<=1) P_1 f(x;s)<=lambda/2.

Retain the R82 middle condition P_1 f(x;r(x))>(lambda/2)exp(-s_n) as well. For the geometric identities it suffices to work with a regular compact X and continuous actual r, as in the established R82 transport interface. All sets considered below have measurable source neighborhoods; the explicit witness consists of compact receiver boxes with continuous first radii. No private receiver or source selector is substituted.

For a receiver subset A, define

    U_A=union_(x in A) Q_x,
    K(A)=lambda |A|/mu(U_A),
    F_K(A)=lambda|A|-K mu(U_A).                                (1)

A cut with positive demand and zero source mass has infinite ratio. That does not occur here, since every selected cube has positive captured mass. If a maximum cut A_* exists at finite K_*=sup_A K(A), then F_(K_*)<=0 for every cut and F_(K_*)(A_*)=0. The following statements are conditional on attainment; they also have versions with explicit maximizing-sequence slack. They are not an existence theorem for all measurable selectors.

For B disjoint from A_*, adding B and removing B subset A_* yield respectively

    lambda|B|<=K_* mu(U_B minus U_(A_*)),                       (2a)
    K_* mu(U_(A_*) minus U_(A_* minus B))<=lambda|B|.           (2b)

The first inequality prices truly new sources. The second prices sources private to the removed receivers. Shared interior sources are not private and need not contribute to either marginal source term. These facts do not force source mass onto the outer boundary of U_(A_*).

For any two cuts A,B, the exact supermodular slack is

    F_K(A union B)+F_K(A intersect B)-F_K(A)-F_K(B)
      =K mu((U_A intersect U_B) minus U_(A intersect B))>=0.    (3)

If A and B are both tight maximum cuts, then their union and intersection are tight, and the overlap on the right has zero source mass. In particular disjoint tight cuts have source-disjoint neighborhoods modulo mu. This is a statement about two already-tight cuts, not arbitrary pieces of one tight set. It supplies a legitimate source-component rule if such tight pieces can first be proved to exist.

For an approximate maximizer with F_K(A)=-eta<=0 and F_K<=0 on all cuts, (2a) has the additive error eta on its right, and (2b) has eta on its right as written. This follows by substituting the exact change in F_K; no continuity of the union map is needed.

## 2. Exact erosion identity for actual fresh incoming mass

Fix 0<q<1 and assume q r(x)>=1/2 on the cut under study. Let

    F_x=Q_x minus [x+[-q r(x),q r(x)]^n],
    U=U_A,
    I_A(y)=integral_A 1_(Q_x)(y)/(2r(x))^n dx,
    J_A(y)=integral_A 1_(F_x)(y)/(2r(x))^n dx.

The first-hit property gives the exact row identity and its lower bound

    mu(F_x)/(2r(x))^n
      =lambda-q^n A_(q r(x))f(x)>=lambda(1-q^n).               (4)

The left side is actual source mass entering between physical half-radii q r(x) and r(x), normalized by the terminal cube volume. It is not a guessed arrival process. Integration against the actual receiver measure gives

    lambda(1-q^n)|A|<=integral f(y)J_A(y)dy,
    lambda|A|=integral f(y)I_A(y)dy.                           (5)

For delta<= (1-q)a, let U_delta={y:y+[-delta,delta]^n subset U} be the spatial erosion, and B_delta=U minus U_delta its outer boundary layer. If y is in the inner q-cube of ANY selected Q_x, then y+[-delta,delta]^n is contained in Q_x and hence in U. Therefore on B_delta every capturing row is fresh:

    J_A(y)=I_A(y), y in B_delta.

Consequently the exact corrected boundary/interior payment is

    integral f J_A
      =integral_(B_delta) f I_A + integral_(U_delta) f J_A.    (6)

The second term is interior fresh OVERLAP, not old mass. A source can be deep inside the union while freshly entering many of its constituent cubes. The actual common-source column weight J_A must be retained.

The elementary fixed-window kernel envelope gives I_A(y)<=1+n log2 for every y: the unit-side cube contributes one, and the side-length radii between one and two contribute n log2. Thus (5)-(6) imply the rigorous but incomplete bound

    lambda(1-q^n)|A|
       <=(1+n log2)mu(B_delta)+integral_(U_delta)f J_A.         (7)

Both terms use source mass, not Lebesgue volume of a boundary layer. Brunn--Minkowski-type volume growth would not control mu(B_delta) for arbitrary positive L1 f. No such unproved weighted replacement is made.

The elementary spatial inclusion A+[-a,a]^n subset U, equivalently A subset U_a, likewise controls geometry without controlling the arbitrary density f. The desired square-root gain must pay the remaining weighted interior term jointly with the boundary term, or produce a separately paid large-Hall-ratio branch.

## 3. A worst capture-Hall set with all source mass deep inside U

Here n=2 and lambda=1. Take

    L=41/100, d=2/5, e=1/10000,
    S=[0,L]^2, f=16 1_S, W=16L^2.

For each of the four corner sign choices sigma, let X_sigma be the closed receiver square of halfwidth e centered at a point whose coordinates are each either -d or L+d. Put X=union_sigma X_sigma. Each component has area v=(2e)^2, and the components are disjoint.

Reflecting in the midpoint L/2 separately in each coordinate reduces every component to x_j=-d_j with d-e<=d_j<=d+e. Until a coordinate saturates its source interval,

    A_r f(x)=4(r-d_1)_+(r-d_2)_+/r^2.

This increases from zero through one at the genuine first root. Comparison with the two diagonal configurations gives

    2(d-e)<=r(x)<=2(d+e),
    d-3e<=r(x)-d_j<=d+3e<L.                                  (8)

Thus the root lies in the interior of the fixed window, has a strictly positive radial derivative, and has immediate strict crossings afterward. It is the global first hit as well. Define

    t=d-3e=3997/10000,       R=3(d-e)=11997/10000.

Every selected cube of a component contains, in the corresponding coordinate direction, either [-R,t] or [L-t,L+R]. In particular every selected cube captures the common source core

    C=[L-t,t]^2,
    mu(C)/W=((2t-L)/L)^2>3/4.                                (9)

Any four selected cubes, one from each receiver component, cover all of S. In fact their union contains the entire large square [-R,L+R]^2, because t>L/2 makes the left and right coordinate intervals overlap.

Now take ANY admissible receiver subset A subset X. If it meets all four components, its source neighborhood has mu(U_A)=W, so K(A)<=|X|/W. If it misses a component, then |A|<=3v and mu(U_A)>=mu(C)>3W/4, giving the strict inequality

    K(A)<=3v/mu(C)<4v/W=K(X).                                 (10)

The empty set has zero demand. Thus X itself is an actual maximum capture-Hall cut, even against partial subsets inside the receiver components, not merely against four discrete representative rows. Its exact capacity ratio is

    K(X)=|X|/W=e^2/L^2=1/16810000.                            (11)

This value is small. The example does not disprove a theorem restricted to cuts whose Hall ratio is already large, and makes no claim to maximize the fresh-relation Hall ratio.

Since U_X contains [-R,L+R]^2, every source point in S has distance at least R from the complement of U_X. Therefore

    mu(B_delta)=0 for every 0<delta<R.                        (12)

Take q=9/10 and delta=(1-q)a=1/20. By (8), q r(x)>1/2 for every row, so (4) gives

    integral f J_X >=(1-q^2)|X|=19|X|/100>0.

All of this fresh source-weighted charge lies in U_delta; the outer-boundary contribution in (6) is exactly zero. Consequently no inequality of the form lambda|A|<=C mu(B_delta), with any finite universal C, can hold for all worst capture-Hall cuts satisfying the retained conditions. This is an obstruction to boundary-only payment, not to a payment using total source mass or the interior-overlap term.

## 4. The two R81 gates and the R82 middle condition really hold

The anchor is uniformly bounded by

    A_(1/2) f(x)<= [4(1/2-d+e)]^2<1/2.                       (13)

For the continuous E2 smooth gate, use the R82 kernel phi=h*w with h=1_[-1/2,1/2] and w(t)=integral_0^1 exp(-|t|/u)du. At every reflected coordinate, the absolute source displacement is d_j+y with y in [0,L]. Positivity and monotonicity imply

    sup_(ell in[1,2]) P_1 f(x;ell)
      <= [sup_(ell in[1,2]) (4/ell)integral_0^L
                         phi((d-e+y)/ell)dy]^2.               (14)

The embedded guard applies the same rigorous rational continuum upper envelope as R82: scale cells [ell_lo,ell_hi], prefactor 4/ell_lo, source argument (d-e+y)/ell_hi, a left source Riemann sum, and a right Riemann sum in the E2 integral. For t>1/2 use phi(t)<=phi(1/2). For 0<=t<=1/2 the E2 integrand is increasing in u. Replacing exp(-s) by the rational lower bound (1-v+v^2/2-v^3/6)^32 for v=s/32<1 (and zero otherwise) makes the resulting phi estimate an upper bound. These are whole-cell continuum certificates, not grid maxima. At N=32 the one-coordinate bound is approximately .676842011 and is strictly below 7/10 by exact rational comparison. Hence (14) is below 49/100<1/2 on every point of X.

For completeness, the R82 middle condition in dimension two follows uniformly at any hard level contact. Let m=phi(1/2)>1/3, M=phi(0)<3/4, D=log(M/m), and mu_ell=integral_(-1/2)^(1/2)(-log phi). The reference threshold is

    s_2=-log m+mu_ell+(D/2)sqrt(log4).

Since mu_ell>=-log M and sqrt(log4)>1,

    (1/2)exp(-s_2)
      <=(1/2)m^2 sqrt(M/m)<(3/4)m^2.                         (15)

On every captured cube phi tensor2>=m^2, so the SAME actual source satisfies P_1/A>=m^2. Thus it lies strictly above the extreme cutoff. The witness therefore survives the R82 middle split as well as both R81 minimal gates. No optional further deletion is asserted.

## 5. General remaining geometric duty

The exact marginal Hall constraints (2) price new and private sources, while (6) isolates shared sources that are fresh relative to constituent cubes but interior to their union. The worst-cut witness shows that neither Hall maximality nor the retained gates forces these sources onto an outer boundary layer. A packing argument based on spatial erosion must therefore carry a term for this interior fresh overlap.

One possible precise target is a uniform estimate for the joint right side of (6), or a direct Hall-ratio estimate on cuts with large K(A), at sqrt(n) times a subpolynomial loss. The elementary sourcewise envelope only gives order n and the witness does not refute improvement in the high-ratio regime. No geometry or skill theorem currently supplies that improvement. The desired weak bound remains open.

## 6. Three-stage actual-input guard

All displayed certificate comparisons use Fraction. Each stage refines actual receiver coordinates and brackets the true quadratic first root, then refines the full-continuum E2 envelope. The Hall proof is the continuum component/core argument above; the grid checks validate its inequalities and are not substituted for all receiver subsets. Decimal outputs only summarize exact rational bounds.

```python
from fractions import Fraction as F
L=F(41,100);d=F(2,5);e=F(1,10000);q=F(9,10)
t=d-3*e;R=3*(d-e);v=(2*e)**2;W=16*L*L
assert t>L/2 and 4*(2*t-L)**2>3*L*L
assert 3*v/(16*(2*t-L)**2)<4*v/W
assert 4*v/W==F(1,16810000)
assert F(1,20)<R
assert (4*(F(1,2)-d+e))**2<F(1,2)
# Middle cutoff / captured-likelihood <=(1/2)*sqrt(M/m)<3/4.
assert F(9,4)==F(3,2)**2 and F(3,4)<1

def root_bracket(d1,d2):
    def poly(r): return 4*(r-d1)*(r-d2)-r*r
    lo=2*(d-e);hi=2*(d+e)
    assert lo>max(d1,d2) and hi<min(d1+L,d2+L)
    assert poly(lo)<=0<=poly(hi)
    for _ in range(48):
        mid=(lo+hi)/2
        if poly(mid)<0: lo=mid
        else: hi=mid
    assert poly(lo)<=0<=poly(hi)
    assert q*lo>F(1,2) and q*hi<lo
    assert poly(q*hi)<0
    assert lo-max(d1,d2)>=t and hi-min(d1,d2)<=d+3*e
    return lo,hi

def exp_lower(s):
    v=s/32
    return F(0) if v>=1 else (1-v+v*v/2-v*v*v/6)**32

def phi_upper(z,N):
    z=min(z,F(1,2))
    return sum((u*(2-exp_lower((F(1,2)+z)/u)
                       -exp_lower((F(1,2)-z)/u))
                for u in (F(j,N) for j in range(1,N+1))),F(0))/N

def continuum_bound(N):
    values=[]
    for k in range(N):
        lo=1+F(k,N);hi=lo+F(1,N)
        values.append(4*L/lo/N*sum((phi_upper((d-e+L*F(j,N))/hi,N)
                                  for j in range(N)),F(0)))
    return max(values)

for stage,(grid,N) in enumerate(((2,8),(4,16),(8,32)),1):
    checks=0
    for i in range(grid+1):
        for j in range(grid+1):
            root_bracket(d-e+2*e*F(i,grid),d-e+2*e*F(j,grid))
            checks+=1
    upper=continuum_bound(N)
    print('stage',stage,'actual first-root brackets',checks,
          'continuum E2 upper',float(upper),'below .7',upper<F(7,10))
    if stage==3:
        assert upper<F(7,10) and upper*upper<F(49,100)<F(1,2)
print('worst capture-Hall K',4*v/W,'source-free outer layer thickness',R)
print('fresh weighted duty >=', (1-q*q)*4*v,'with zero outer-boundary source mass')
print('PASS: actual L1/window/anchor/full-smooth/middle; no general root-n bound claimed')
```


# R83 principal Hall peeling and physical leakage

The guard certifies 34 principal source blocks for 20 exact finite-grid fixtures over 123,724 complete original receiver cells. Every block has a saturated rational transport flow, and successive residual Hall densities decrease strictly. Nevertheless, a block can lose most of its original captured physical mass and cease to be a hard crossing on a whole positive-volume receiver cell. Abstract block transport feasibility does not imply an independent hard-input decomposition.

## Geometry and certificate scope

The script contains its own complete-cell and integer-flow implementations; it has no dependency on older-round scripts. The 17 base inputs are exactly the frozen R82 finite atomic fixtures, including the rational random fixture with seed 820611. Dimensions are n=1,2,3, with at most eight positive source labels and at most nine rational physical side lengths in [1,2]. The original event excludes A_1>=lambda/2 and then selects the first STRICT A_L>lambda among the finite scales. It retains the original selector rather than maximizing A_L.

All physical source faces for L and L/2 are included in the original dx arrangement. Each cell has exact rational volume and constant source-capture masks at every scale. Averages are computed from the same physical source masses. The unit-anchor fee and the integrals of every scale average are checked as in R82. These are positive atomic inputs and finite-grid hits; no continuum first-hit, L1 realization, E2 smooth deletion or asymptotic dimension estimate is claimed here.

The three stages are the six pilot/source-splitting fixtures, eight correlated/leakage-pressure fixtures and six dimension/scale-extension fixtures. The pressure stage runs 360 deterministic rational one-dimensional trials with seed 830612 and freezes its three highest-ranked leakage/gap examples. There are 304 nonempty retained events, 167 cases with multiple positive-density blocks and 21 cases where some assigned block loses all grid crossings on positive receiver volume. The search ranking is the exact maximum row value of discarded captured fraction divided by relative preceding density gap plus 1/1024. This is a bounded search, not an exhaustive search over rational inputs.

## Exact maximal-cut peeling

At a residual step, the row neighborhood is its original captured mask minus already peeled physical sources. Every nonempty residual source subset S is checked. Its density is the demand of rows whose entire residual neighborhood lies in S, divided by the physical mass of S. The block is the union of ALL maximizing subsets, not an arbitrary tied maximizer. The union is itself checked to have the maximizing ratio.

The guard assigns exactly those forced rows to that source block, removes them, deletes the block from remaining neighborhoods and checks the new exact Hall maximum. With positive source masses the next density is strictly smaller. Unused leftover sources may form a final zero-density block, with no receiver demand. The reported 34 flows include these trivial zero-capacity blocks.

For each block, a separately constructed integer maximum-flow network uses its residual allowed neighbors and capacities K_j p_i. It saturates every receiver demand. Since total block demand is exactly K_j times the whole source-block mass, every source capacity in that block is saturated as well. The results save all maximal cuts, their union, residual forced-demand arrays, assigned original row IDs, all capacities, flow arcs and residual cuts. Every row demand remains lambda times its original dx volume.

## Physical source-cut accounting

For every original row and every constant physical cell pattern, the guard records the original captured mass, the mass in its assigned source block, and the mass discarded in earlier blocks. Original captured neighbors contain no later source block at assignment, so the two recorded masses sum exactly to the original capture. It also recomputes all physical scale averages for the block alone and for the remaining source input before that block.

The block and residual anchor averages stay below lambda/2 because deleting positive source mass cannot increase them. A first crossing cannot move earlier than the original finite-grid selector, but it can move later or disappear. Both outcomes are recorded separately from transport feasibility. Each witness contains an actual open face cell and its exact positive volume, rather than just an isolated receiver.

## Small density gap with large physical loss

Pressure trial 235 has n=1, sites (-7/8,-3/4,13/16), masses (13/50,11/50,13/25), lambda=1/8 and side scales (1,5/4,3/2,7/4,2). Its principal densities are

    25/104, 75/416, 125/704.

The gap between the last two is 25/9152, only 1/66 of the preceding density. On the whole receiver interval (0,1/16), the last block is the single site -3/4. The original first grid hit is L=7/4, with average 74/175 and captured mass 37/50. The block keeps 11/50 and discards 13/25: the lost fraction is 26/37. Its own average 22/175 still barely exceeds lambda. Thus a small principal density gap does not force a small physical captured-mass loss.

## A block that loses every hard grid crossing

Pressure trial 307 has n=1, lambda=1/8, the same five scales, and

| Site | Mass |
|---|---:|
| -9/8 | 23/70 |
| 0 | 3/70 |
| 1/16 | 3/10 |
| 1/2 | 6/35 |
| 5/8 | 11/70 |

Its principal densities are 35/184, 35/192, 105/736 and 5/96. The second block is the source at zero alone. The preceding relative density gap is 1/24. On the whole receiver interval (-5/8,-9/16), of volume 1/16, the original anchor average is zero and the first strict grid hit is L=5/4, with average 52/175. Its captured sources have mass 13/35. The second block keeps only 3/70 and discards 23/70, a fraction 23/26.

The independent block averages at all five scales are exactly

    0, 6/175, 1/35, 6/245, 3/140.

Every value is below 1/8, so the assigned block has no hard crossing anywhere on that whole cell. The residual input after deleting the first source block instead delays the first crossing to L=3/2, using sources in later blocks. Meanwhile the second block's abstract transport flow is saturated exactly. This separates row-demand feasibility from physical hard-input survival.

A simpler three-source failure occurs in pressure trial 345: sites (-5/4,-1,3/4), masses (4/23,15/23,4/23), lambda=1/4. On (-1/8,0) the last block loses fraction 15/19 of the original captured mass and every grid crossing. Its relative principal density gap is 1/20. These counterexamples concern the complete finite-grid, paid-anchor event. They are not assertions about the parent's smooth-event deletion or continuous first-hit selector.

## Canonical posterior and low-density payment

Let L_jk be the original canonical-posterior demand sent from receiver block j to physical source block k, and B_k=sum_{j>=k}L_jk. All entries with k>j are zero. The guard verifies exactly

    sum_k K_k B_k - sum_j K_j^2 p(S_j)
      = sum_{j>k}(K_k-K_j)L_jk >= 0.

For trial 235 both sides equal 25/1667072. This identity keeps the original posterior and explicitly accounts for its transfer to earlier source blocks; it does not replace it by the assigned-block posterior. For thresholds 1/8,1/4,1/2, each fixture also checks the paid branch sum of demands over K_j<=threshold is at most threshold times the corresponding total source-block mass. This does not estimate the leading density K_1.

The same-input atom-splitting test preserves receiver volume, every principal density and the principal source blocks after expanding each original label into its two coincident half-mass labels. This is invariance of the same physical measure, not invariance under moving refined sites.

## Replay

Run python3 principal_probe.py. It uses only the Python standard library and writes principal_results.json next to itself. The full deterministic pressure search, exact cell reconstruction and all flow certificates run in about three seconds on the present machine. All realized sources, thresholds, scales, complete arrangements, row mass fractions, selector losses and canonical identities are saved. No fitted exponent, free representative column or independent-block weak theorem is inferred from the data.


# R83 independent audit: common likelihood payment, principal Hall blocks, and spatial leakage

**Conclusion.** The audited all-input multi-width likelihood payment is valid. The finite principal partition, shared block flows, convex load optimality, and exact quadratic recycling identity are valid. The two actual spatial obstructions have the stated scopes. No unresolved concrete mathematical or arithmetic defect was found in the final frozen components. The general centered-cube goal \(C_n^\square\leq\sqrt n\,n^{o(1)}\) remains **unproved**: there is no target-sized bound on the complementary common likelihood event, high-density principal blocks, or adaptive-physical-scale noise-parameter variation.

The review read `tunable.md` and its TeX counterpart, `peeling.md` and its TeX counterpart, `geometry.md` and its TeX counterpart, and the complete principal program, saved certificates, and numerical report. TeX was read statically; no compilation or PDF claim is made. L03 certificate boundaries were retained: exact rational residuals and monotone integral bounds are distinguished from floating quadrature and finite rate-root diagnostics. Only this audit's two files were edited; no author file or Git state was changed.

## 1. Tunable likelihoods: hypotheses, constants, and the unpaid bridge

For the actual \(\phi_\eta=h*w_\eta\), the scalar identities for edge value, maximum, escaped mass, and mean log penalty are correct. The bounds \(m_\eta>1/3\), \(\eta/3\leq\mu_\eta\leq2\eta\), and \(0\leq-\log\phi_\eta\leq\log3\) use the true hard interval. The lower escaped-mass bound is linear in \(\eta\). For example the inherited scalar estimate is supported directly by \(e^{-1/t}\leq t/e\), which gives \(m_1\geq1/2-1/(3e)>1/3\).

The finite mgf chord bound and its Chernoff optimization are valid. With \(b=\log3\) and \(\Lambda_\eta=2(n-1)\eta/b\), the rate
\[
I_\Lambda(z)=z\log(z/\Lambda)-z+\Lambda
\]
is used as an exact finite upper bound, not an asymptotic LDP. Its unique increasing-branch root gives the actual angular cone threshold. Independence belongs only to reference cube-cone coordinates. No arbitrary source posterior is assumed independent.

The radial cone domination retains the same input, receiver measure, and original hard selector. For predetermined finite or countable widths and weights \(a_j>0\), \(\sum a_j\leq1\), the union is paid once:
\[
\lambda\left|\bigcup_j\left\{A_L\geq\lambda,
P_{\eta_j,L}/A_L\leq\tfrac12e^{-s_j}\right\}\right|
\leq\frac{2(1+n\log2)}{\sqrt{n+2}}W.
\]
This is a sourcewise positive envelope and a countable event union, with no sum of weak quasi-norms and no averaging of conditional weak bounds. An adaptive choice among the registered widths is covered by the same union.

For \(\eta\leq1/n\), \(\Lambda_\eta<2\). The estimate \(z\leq4r/\log r\) is proved for \(r\geq e^4\); smaller finite values use the rate root. In the dyadic example the first \(j\) with \(\eta_j\leq1/n\) has \(j=O(\log n)\), and its reciprocal-polynomial weight gives \(r_j=O(\log n)\). Hence the registered narrow kernel has a lower floor \(\beta_j=n^{-o(1)}\) outside the paid union. This floor is for a **different, narrower kernel**. It does not strengthen the same-kernel \(P_1\) floor or imply that the new remainder is a subset of R82's remainder. The \(\eta=1\) finite-rate threshold can be more conservative than the old Hoeffding threshold. Keeping a separate old R82 deletion requires its separate explicit fee or a joint threshold allocation; the new single union itself is charged only once.

The physical-dilation bounds are also correct within their final scope. Mixture Cauchy gives \(J_\eta\leq1/\eta+4\eta/3\). For \(0<\eta\leq1/48\), the outside layer gives \(J_\eta\geq1/(2304\eta)\). Independently recomputing the fourth-moment constants gives an inside contribution \(27/(32\eta^3)\), two-tail contribution \(10128/\eta^3\), and total score fourth moment below \(100000/\eta^3\). Centered product-kernel independence and interpolation then give
\[
\|D_{n,\eta}\|_1\geq\frac{n}{40000000\sqrt{1+n\eta}}.
\]
The final matching-order assertion retains \(\eta\leq1/48\); the order-\(n\) statement at \(\eta\asymp1/n\) is for sufficiently large dimensions. Positive approximate-identity inputs establish the lower coefficient for absolute physical space-time variation. This is a limitation of that payment method, not a lower bound for the weak maximal constant and not an obstruction to a method retaining more cancellation.

Noise-width differentiation is a distinct parameter direction. The scalar noise score has mean zero. Its mixture/convolution Fisher contraction gives at most one; direct inside and outside estimates give \(3\eta+48\eta\), so
\[
J_{\mathrm{noise},\eta}\leq\min(1,51\eta),\qquad
\int dx\int_0^1|f*(\eta\partial_\eta\Phi_\eta)_L|\frac{d\eta}{\eta}
\leq(2+\log51)\sqrt n\,W
\]
for **fixed physical \(L\)**. The hard endpoint is legitimate. In fact
\(P_{\eta,L}=A_L(f*w_{\eta L}^{\otimes n})\), and the translation-modulus bound is uniform in \(x\) and \(1\leq L\leq2\). Uniform tightness of the scaled noise and L1 translation continuity give \(P_{\eta,L}\to A_L\) uniformly. Thus the endpoint identity holds even when evaluated at the original selected \(L(x)\), and selected absolute noise variation is at least \(\lambda/2\) at retained contacts with \(P_{1,L}\leq\lambda/2\). This pointwise fact does not provide the integrated budget after making physical scale depend on \(x\). The fixed-L estimate cannot be inserted at that adaptive step.

## 2. Principal partition and physical source restriction

With positive source masses and positive row demands, the forced-demand function is supermodular. Taking the union of all maximum-density cuts is necessary: its maximality gives strict descent of the next residual positive Hall density. The forced rows are removed exactly, and remaining neighborhoods stay nonempty. Each block's total row demand equals its total source capacity \(K_jp(S_j)\). Exact Hall feasibility therefore saturates every source of that block, and disjoint block flows form one feasible common transport on original edges. Unused sources form a zero-density block.

The cumulative-block forced demands imply the convex hinge inequalities. Equality of total loads then proves optimality for every convex source-load functional. The triangular original adjacency gives
\[
\sum_i p_i b_i^2-\sum_i p_i k_i^2
=\sum_i p_i(b_i-k_i)^2
+2\sum_{j>k}(K_k-K_j)L_{jk}.
\]
This identity keeps both the load-variance term and gap-weighted recycling. It controls unweighted cross-block mass only when a positive gap is supplied. The low-density branch \(\sum_{K_j\leq t}d(R_j)\leq tW\) is a genuine payment, but it neither bounds \(K_1\) nor estimates demand in higher-density blocks.

Canonical captured-source recycling equals actual earlier-block capture loss on the capture graph. It must not be given that full physical interpretation on a fresh graph that omits old captured sources. Restricting an actual input to a later source block does not preserve the old first hit or a lower smooth-ratio floor. Positive smooth upper fields decrease, but a lowered threshold needs a new gate check.

The continuous L1 countertest is valid: \(f=4\mathbf1_{[0,1]}\), receiver \(x=-a\), first half-radius \(2a\), and side \(4a\). Nested neighborhoods prove the stated two continuum principal blocks directly. The explicit source-to-receiver maps preserve captured edges and push \(4K_jdy\) to original \(da=dx\). The second block loses fraction at least \(a_1/(a_1+\delta)\), arbitrarily close to one. For fixed \(\delta\), its unweighted canonical recycling stays positive as the density gap tends to zero. This refutes gap-only leakage control; it does not contradict the full quadratic deficit. It is a receiver subevent with the actual window and anchor gate, not a claim about the smooth retained event or the entire weak level set.

## 3. Worst capture-Hall geometry and its gates

The variational add/remove inequalities and the supermodular slack formula have the correct directions, including the additive error for approximate maximizers. Two already-tight cuts can have source-disjoint neighborhoods; arbitrary pieces of one tight cut need not. Attainment and measurable neighborhoods remain explicit hypotheses.

For actual fresh cubes with \(qr(x)\geq1/2\), the normalized row identity is \(\lambda-q^nA_{qr(x)}\geq\lambda(1-q^n)\). Spatial erosion gives \(J_A=I_A\) on the outer boundary layer, but the exact split also includes \(\int_{U_\delta}fJ_A\). This is interior **fresh overlap**, not old source mass. Arbitrary source density prevents replacing its weighted mass with a Lebesgue boundary-volume estimate.

The four-component n=2 L1 witness is a maximum capture-Hall cut against all receiver subsets, not only four representatives. The common source core exceeds three quarters of the source mass; missing a component strictly reduces the ratio, while meeting all four covers the entire support. The selected-cube union contains the stated surrounding square, so all sources are deep inside the union even though every row has positive fresh mass. Its exact ratio is only \(1/16810000\). It is not a high-Hall-ratio counterexample or a maximum-fresh-Hall claim.

The actual root is interior and strictly crossing. Both the anchor and **full-continuum** E2 smooth gates hold uniformly on the receiver boxes. The rational monotone envelope certifies the smooth factor below \(7/10\), hence its square below \(1/2\). The scalar lower likelihood \(P_1/A\geq m^2\) also places the witness in the R82 middle. No optional further deletion is asserted. These gates refute boundary-only payment, not the maximal conjecture or a payment retaining the interior term.

## 4. Independent certificates and reproduction

The audit guard imports neither the producer nor any previous-round program. It independently reconstructs geometric source-index sets, cell volumes, all-scale averages, anchor deletion and earliest strict finite-grid hits. Residual forced demands are summed by brute source-subset enumeration rather than the producer's zeta transform. Saved flows are checked for exact capacities, conservation, row and source saturation, residual cuts, and local Hall lower witnesses.

| Independent frozen-JSON check | Result |
|---|---:|
| Complete original dx cells | 123,724 |
| Principal source blocks / flows | 34, including 32 positive-density blocks |
| Brute residual source cuts | 882 |
| Exact flow arcs | 1,337 |
| Original demand rows / physical patterns | 363 / 999 |
| Exact convex hinge comparisons | 101 |

All per-pattern block-only and residual averages, delayed or absent first grid hits, actual open cell boxes, retained/lost mass fractions, summary volumes, canonical triangular entries, and the complete quadratic deficit were recomputed. Same-measure coincident-label splitting preserves the source blocks after expansion. The three selected pressure inputs were independently reconstructed from their RNG seed; the bounded search is not an exhaustive search over inputs.

Trial 307 is a concrete positive-volume failure of independent block-input survival: the full cell \((-5/8,-9/16)\) loses fraction \(23/26\). The assigned block's five averages are \(0,6/175,1/35,6/245,3/140\), all below \(1/8\), while its transport remains saturated. These numerical fixtures are positive atomic inputs and finite firstSTRICT grid hits. They do not certify continuous first contacts, an L1 realization, E2 smooth deletion, or a dimension/source-count asymptotic.

Additional independent checks comprise nine actual continuous L1 parameter cases with rational log enclosures, exact fourth-moment constants, four rational bounded-mgf chords, and five partial-plus-tail weight budgets. The geometry check uses 49 different actual root brackets and 15 component patterns. A different fifth-order/16-subdivision exponential lower construction gives a rational full-window E2 factor upper strictly below \(7/10\), displayed approximately as **0.6768404205845436**. The decimal display is not an outward-rounded interval. The all-subset continuum Hall assertion follows the analytic common-core proof, not a grid approximation.

An independent stable direct Laplace-box midpoint mixture supplied 20 noise-parameter finite-difference diagnostics, with maximum absolute discrepancy **3.618966237795007e-11**. Noise Fisher quadrature at \(\eta=1/16,1/64,1/256\) was approximately **0.08397116, 0.02099282, 0.00524821**. These floating calculations have no certified integration error; they do not establish the analytic Fisher bound or pay the adaptive-L bridge.

The standalone producer was run in an independent temporary directory: exit 0, empty stderr, and `principal_results.json` byte-identical in **1.992249541 s**. Separate temporary-directory component replays passed: tunable **0.093305667 s** (45 diagnostic assertions), peeling **0.090354584 s** (60 rational graphs, three complete spatial inputs, 12 continuous L1 parameter cases), geometry **1.439501458 s** (9/25/81 root brackets and three continuum envelope refinements). Exact geometry comparisons and diagnostic quadrature are labelled separately in those outputs.

## 5. Frozen hashes and portability

| File or embedded payload | SHA256 |
|---|---|
| principal_probe.py | `a1e4d406b2de282071478230db9d00a3805e1fc0aa485dd6bf717dc70bcf9ea1` |
| principal_results.json | `29b348ec80684579a7a38eed5982e71922768cff8801208cd3e0a1926ec64ca4` |
| tunable embedded guard | `fe7b5452612e90010919a9b55e94b25c6dd1ca30be6dda21a83615a8d5a88792` |
| peeling embedded guard | `eeb2c08cf4737691ec98c0bfadfd560c1cb2d0a38f0b4962939f051d20b115f2` |
| geometry embedded guard | `9f1ea6e2af0a83c3a7618af714f0784dd9c25da93897c10df90c7666d9868d13` |
| audit_guard.py | `40449bdbf1f40e57bc361a885e075512dc9174b735813d34097712b4578c0953` |

Final portability was actually tested with only the planned archive files (`proof.md`, `proof.tex.txt`, main Python/JSON, inventory) and the extracted audit guard. The merged proof contained exactly four Python fences, in order tunable/peeling/geometry/audit. All three payloads were identified by frozen hash and executed with exit 0 and empty stderr. The complete independent audit passed in **4.679971625 s**. A second run removed `proof.md` and used the three same-directory extracted component guards; it passed in **4.622736959 s**.

The lookup order is extracted local component guard, component Markdown as a development fallback, then frozen matching fence in merged `proof.md`. The archive path requires no original component Markdown, older-round file, external skill, solver, or absolute workspace path. All executable audit code uses Python standard library. It verifies main-file hashes and independently checks the saved certificates; it does not rerun the main producer internally. The separate byte-reproduction receipt above supplies that distinct evidence.

**Remaining obligation.** The common multi-width exception and low-density principal blocks are paid. None of the PASS receipts supplies the missing uniform high-density Hall geometry or selected-physical-scale parameter-flux budget. The general target remains open.


## 独立审计核验脚本

```python
#!/usr/bin/env python3
"""Independent R83 physical cells, principal certificates and proof guard replay.
Standard library only; no import of the producer or dependency on older rounds.
"""
from fractions import Fraction as Q
from pathlib import Path
from itertools import product
from collections import deque
from functools import lru_cache
import json,math,hashlib,re,subprocess,tempfile,sys,time,random
BASE=Path(__file__).resolve().parent

def mask_of(s):return sum(1<<i for i in s)
def subset_mass(S,p):return sum((p[i] for i in range(len(p)) if S>>i&1),Q(0))

def saved_principal():
    data=json.loads((BASE/'principal_results.json').read_text());total_cells=blocks=positive=cuts=arcs=all_rows=patterns=hinges=0
    for fixture in data['fixtures']:
        src=fixture['source'];n,N=src['n'],src['N'];ys=[list(map(Q,y)) for y in src['centers']];p=list(map(Q,src['weights']));Ls=list(map(Q,src['scales']));lam=Q(src['lambda_value']);q=Q(src['fresh_ratio_q']);K=len(Ls)
        assert all(a>0 for a in p) and sum(p)==Q(src['W']) and 1==Ls[0]<=Ls[-1]<=2 and q==Q(1,2)
        axes=[sorted({y[j]+a*L*sgn for y in ys for L in Ls for a in (Q(1),q) for sgn in (-Q(1,2),Q(1,2))}) for j in range(n)]
        arr=fixture['arrangement'];assert axes==[list(map(Q,a)) for a in arr['axes']]
        lengths=[[b-a for a,b in zip(axis,axis[1:])] for axis in axes];coordinates=[[(a+b)/2 for a,b in zip(axis,axis[1:])] for axis in axes]
        # Independent geometric sets, not the production bitset intersections.
        allowed=[]
        for j in range(n):
            allowed.append([[{i for i,y in enumerate(ys) if abs(x-y[j])<a*L/2} for L in Ls for a in (Q(1),q)] for x in coordinates[j]])
        rebuilt={};count=0;digest=hashlib.sha256()
        for indices in product(*(range(len(v)) for v in lengths)):
            vol=math.prod(lengths[j][indices[j]] for j in range(n));captures=[];inners=[]
            for k in range(K):
                captures.append(mask_of(set.intersection(*(allowed[j][indices[j]][2*k] for j in range(n)))))
                inners.append(mask_of(set.intersection(*(allowed[j][indices[j]][2*k+1] for j in range(n)))))
            key=tuple(captures+inners)
            if key not in rebuilt:rebuilt[key]=[Q(0),0]
            rebuilt[key][0]+=vol;rebuilt[key][1]+=1;count+=1
            digest.update((str(indices)+':'+str(vol)+':'+str(key)+'\n').encode())
        saved={tuple(r['captured_masks']+r['inner_masks']):[Q(r['volume']),r['cell_count']] for r in arr['patterns']}
        assert saved==rebuilt and count==arr['complete_cell_count'] and digest.hexdigest()==arr['cell_digest'];total_cells+=count
        integrated=[Q(0)]*K;anchor=retained_volume=Q(0);rows={kind:{} for kind in ('captured','fresh')}
        for row in arr['patterns']:
            cap,inner=row['captured_masks'],row['inner_masks'];vol=Q(row['volume']);v=[subset_mass(S,p)/L**n for S,L in zip(cap,Ls)]
            assert v==list(map(Q,row['averages']))
            paid=v[0]>=lam/2;hits=[k for k,a in enumerate(v) if a>lam];first=hits[0] if hits else None;keep=bool(hits) and not paid
            assert paid==row['paid_anchor'] and first==row['first_strict_scale_index'] and keep==row['retained']
            integrated=[a+b*vol for a,b in zip(integrated,v)]
            if paid:anchor+=vol
            if keep:
                k=first;C=cap[k];O=inner[k];F=C&~O;M=subset_mass(C,p);m=subset_mass(F,p)
                assert O&~cap[0]==0 and O&~C==0 and F>0
                assert subset_mass(O,p)<lam/2 and M>lam*Ls[k]**n and m>lam*Ls[k]**n-lam/2>=lam*Ls[k]**n/2
                assert C==row['captured_neighborhood'] and F==row['fresh_neighborhood']
                assert m==Q(row['fresh_mass']) and M==Q(row['captured_mass']) and M-lam*Ls[k]**n==Q(row['overshoot_mass'])
                retained_volume+=vol
                for kind,S in (('captured',C),('fresh',F)):
                    key=(S,k)
                    if key not in rows[kind]:rows[kind][key]=[Q(0),0]
                    rows[kind][key][0]+=vol;rows[kind][key][1]+=row['cell_count']
        assert integrated==[sum(p)]*K and anchor==Q(arr['paid_anchor_volume']) and lam*anchor<=2*sum(p)
        assert retained_volume==Q(arr['retained_volume']) and lam*retained_volume==Q(arr['retained_demand'])
        principal=fixture['principal'];rr=principal['original_rows'];bs=principal['blocks']
        assert {(r['neighborhood'],r['first_scale_index']):[Q(r['volume']),r['cell_count']] for r in rr}==rows['captured']
        demands=[Q(r['demand']) for r in rr];assert all(d==lam*Q(r['volume']) for d,r in zip(demands,rr))
        masses=[subset_mass(S,p) for S in range(1<<N)];remaining=(1<<N)-1;earlier=0;current=set(range(len(rr)));owners={};ki=[Q(0)]*N
        for j,block in enumerate(bs):
            forced=[sum((demands[r] for r in current if (rr[r]['neighborhood']&remaining)&~S==0),Q(0)) for S in range(1<<N)]
            allowed=[S for S in range(1,1<<N) if S&~remaining==0];cuts+=len(allowed)
            density=max(forced[S]/masses[S] for S in allowed)
            maximizers=[S for S in allowed if forced[S]==density*masses[S]];S=0
            for mask in maximizers:S|=mask
            selected=sorted(r for r in current if (rr[r]['neighborhood']&remaining)&~S==0)
            assert forced[S]==density*masses[S]
            assert density==Q(block['K']) and S==block['source_mask'] and maximizers==block['all_maximizing_cuts']
            assert forced==list(map(Q,block['forced_subset_demands']))
            assert remaining==block['remaining_source_mask_before'] and earlier==block['earlier_source_mask'] and selected==block['assigned_original_rows']
            assert Q(block['source_mass'])==masses[S] and sum(demands[r] for r in selected)==Q(block['total_demand'])==density*masses[S]
            if j:assert density<Q(bs[j-1]['K'])
            ids=[i for i in range(N) if S>>i&1];assert ids==block['source_indices'] and block['index']==j
            for i in ids:ki[i]=density
            for r in selected:owners[r]=j
            localp=[p[i] for i in ids];localrows=[(mask_of({k for k,i in enumerate(ids) if rr[r]['neighborhood']>>i&1}),demands[r]) for r in selected]
            arcs+=verify_flow(block['saturated_block_flow'],localp,localrows,density)
            blocks+=1;positive+=density>0
            current-=set(selected);remaining&=~S;earlier|=S
            if remaining:
                nextdensity=max(sum((demands[r] for r in current if (rr[r]['neighborhood']&remaining)&~T==0),Q(0))/masses[T] for T in range(1,1<<N) if T&~remaining==0)
                assert nextdensity<density and nextdensity==Q(block['residual_Hall_maximum_after']) and density-nextdensity==Q(block['density_gap_to_next'])
            else:assert block['residual_Hall_maximum_after'] is None and block['density_gap_to_next'] is None
        assert not current and remaining==0 and [owners[r] for r in range(len(rr))]==principal['row_assignment']
        assert Q(principal['initial_optimal_Hall_K'])==Q(bs[0]['K'])
        for r,row in enumerate(rr):
            block=bs[owners[r]];C=row['neighborhood'];M=masses[C];kept=masses[C&block['source_mask']];lost=masses[C&block['earlier_source_mask']]
            assert kept>0 and kept+lost==M and owners[r]==row['assigned_block']
            assert M==Q(row['original_captured_mass']) and kept==Q(row['assigned_block_captured_mass']) and lost==Q(row['discarded_earlier_captured_mass'])
            assert kept/M==Q(row['retained_captured_fraction']) and lost/M==Q(row['discarded_captured_fraction'])
        bykey={(r['neighborhood'],r['first_scale_index']):i for i,r in enumerate(rr)}
        retained={tuple(r['captured_masks']+r['inner_masks']):r for r in arr['patterns'] if r['retained']}
        geometries=principal['row_geometry'];assert len(geometries)==len(retained)
        seen=set();failed=lostvolume=Q(0);maxloss=Q(0)
        for g in geometries:
            x=list(map(Q,g['representative']));box=[list(map(Q,b)) for b in g['representative_open_cell_box']]
            assert all(a<xj<b and [a,b] in [[u,v] for u,v in zip(axis,axis[1:])] for xj,(a,b),axis in zip(x,box,axes))
            assert Q(g['representative_open_cell_volume'])==math.prod(b-a for a,b in box)>0
            cap=[mask_of({i for i,y in enumerate(ys) if all(abs(xj-yj)<L/2 for xj,yj in zip(x,y))}) for L in Ls]
            inner=[mask_of({i for i,y in enumerate(ys) if all(abs(xj-yj)<q*L/2 for xj,yj in zip(x,y))}) for L in Ls]
            key=tuple(cap+inner);assert key in retained and key not in seen;seen.add(key);row=retained[key];k=row['first_strict_scale_index'];r=bykey[(cap[k],k)];j=owners[r];block=bs[j]
            assert g['original_row']==r and g['assigned_block']==j and Q(g['volume'])==Q(row['volume']) and g['cell_count']==row['cell_count']
            C=cap[k];M=masses[C];kept=masses[C&block['source_mask']];discarded=masses[C&block['earlier_source_mask']];loss=discarded/M
            ba=[masses[c&block['source_mask']]/L**n for c,L in zip(cap,Ls)];ra=[masses[c&block['remaining_source_mask_before']]/L**n for c,L in zip(cap,Ls)]
            first=next((a for a,v in enumerate(ba) if v>lam),None);rf=next((a for a,v in enumerate(ra) if v>lam),None)
            assert g['original_captured_mask']==C and Q(g['original_captured_mass'])==M and Q(g['assigned_block_captured_mass'])==kept and Q(g['discarded_earlier_captured_mass'])==discarded
            assert Q(g['retained_captured_fraction'])==kept/M and Q(g['discarded_captured_fraction'])==loss
            assert g['original_first_scale_index']==k and Q(g['original_first_scale'])==Ls[k] and list(map(Q,g['original_all_scale_averages']))==list(map(Q,row['averages']))
            assert ba==list(map(Q,g['block_only_all_scale_averages'])) and ra==list(map(Q,g['residual_input_all_scale_averages']))
            assert first==g['block_only_first_strict_scale_index'] and rf==g['residual_input_first_strict_scale_index'] and (first is None or first>=k) and (rf is None or rf>=k)
            assert ba[0]<lam/2 and ra[0]<lam/2 and Q(g['block_only_anchor_average'])==ba[0]
            assert (ba[k]<=lam)==g['block_loses_original_selected_crossing'] and (first is None)==g['block_loses_all_grid_crossings']
            if j:
                gap=Q(bs[j-1]['K'])-Q(block['K']);relative=gap/Q(bs[j-1]['K'])
                assert gap==Q(g['preceding_block_density_gap']) and relative==Q(g['preceding_block_relative_density_gap'])
                score=loss/(relative+Q(1,1024))
            else:
                assert g['preceding_block_density_gap'] is None and g['preceding_block_relative_density_gap'] is None;score=Q(0)
            assert score==Q(g['leakage_gap_search_score'])
            failed+=Q(g['volume'])*(ba[k]<=lam);lostvolume+=Q(g['volume'])*(first is None);maxloss=max(maxloss,loss)
        assert seen==set(retained) and failed==Q(principal['failed_original_selected_crossing_volume']) and lostvolume==Q(principal['all_block_grid_crossings_lost_volume']) and maxloss==Q(principal['max_discarded_captured_fraction'])
        best=max((Q(g['leakage_gap_search_score']) for g in geometries),default=Q(0))
        assert best==Q(principal['best_leakage_gap_score'])
        if best>0:assert principal['best_leakage_gap_row'] in geometries and Q(principal['best_leakage_gap_row']['leakage_gap_search_score'])==best
        else:assert principal['best_leakage_gap_row'] is None
        for j,block in enumerate(bs):
            gs=[g for g in geometries if g['assigned_block']==j];summary=block['physical_geometry_summary']
            assert Q(summary['original_receiver_volume'])==sum((Q(g['volume']) for g in gs),Q(0))
            assert Q(summary['max_discarded_captured_fraction'])==max((Q(g['discarded_captured_fraction']) for g in gs),default=Q(0))
            assert Q(summary['lost_selected_crossing_volume'])==sum((Q(g['volume']) for g in gs if g['block_loses_original_selected_crossing']),Q(0))
            assert Q(summary['all_grid_crossings_lost_volume'])==sum((Q(g['volume']) for g in gs if g['block_loses_all_grid_crossings']),Q(0))
        Lmatrix=[[Q(0)]*len(bs) for _ in bs];posterior=[Q(0)]*N
        for r,row in enumerate(rr):
            C=row['neighborhood'];j=owners[r]
            for i,pi in enumerate(p):
                if C>>i&1:posterior[i]+=demands[r]*pi/masses[C]
            for k,block in enumerate(bs):Lmatrix[j][k]+=demands[r]*masses[C&block['source_mask']]/masses[C]
        assert all(Lmatrix[j][k]==0 for j in range(len(bs)) for k in range(j+1,len(bs)))
        B=[sum(row[k] for row in Lmatrix) for k in range(len(bs))];identity=principal['canonical_posterior_identity']
        assert Lmatrix==[list(map(Q,row)) for row in identity['L_jk']] and B==list(map(Q,identity['B_k']))
        assert [sum(row) for row in Lmatrix]==[Q(block['total_demand']) for block in bs]
        lhs=sum(Q(block['K'])*B[k]-Q(block['K'])**2*Q(block['source_mass']) for k,block in enumerate(bs))
        rhs=sum((Q(bs[k]['K'])-Q(bs[j]['K']))*Lmatrix[j][k] for j in range(len(bs)) for k in range(j))
        assert lhs==rhs==Q(identity['left_side'])==Q(identity['right_side'])>=0
        bi=[z/pi for z,pi in zip(posterior,p)]
        quadratic=sum(pi*(b*b-k*k) for pi,b,k in zip(p,bi,ki));variance=sum(pi*(b-k)**2 for pi,b,k in zip(p,bi,ki))
        assert quadratic==variance+2*rhs
        for threshold in set(bi+ki+[Q(0)]):
            assert sum(pi*max(b-threshold,0) for pi,b in zip(p,bi))>=sum(pi*max(k-threshold,0) for pi,k in zip(p,ki));hinges+=1
        for paid in principal['low_density_paid_branches']:
            t=Q(paid['threshold']);low=[b for b in bs if Q(b['K'])<=t];d=sum(Q(b['total_demand']) for b in low);mass=sum(Q(b['source_mass']) for b in low)
            assert d==Q(paid['demand']) and mass==Q(paid['source_mass']) and t*mass==Q(paid['budget']) and t*mass-d==Q(paid['residual'])>=0
        all_rows+=len(rr);patterns+=len(geometries)
    bylabel={r['source']['label']:r for r in data['fixtures']};coarse=bylabel['same_input_coarse_n1'];split=bylabel['same_input_split_n1']
    expand=lambda S:sum(3<<(2*i) for i in range(coarse['source']['N']) if S>>i&1)
    assert Q(coarse['arrangement']['retained_volume'])==Q(split['arrangement']['retained_volume'])
    assert [b['K'] for b in coarse['principal']['blocks']]==[b['K'] for b in split['principal']['blocks']]
    assert [expand(b['source_mask']) for b in coarse['principal']['blocks']]==[b['source_mask'] for b in split['principal']['blocks']]
    expected=data['counts'];assert total_cells==expected['complete_dx_cells']==123724 and blocks==expected['principal_blocks']==34 and positive==expected['positive_density_blocks']==32
    assert all_rows==expected['original_demand_rows']==363 and patterns==expected['original_physical_geometry_patterns']==999
    # Independent random-source reconstruction of the saved pressure candidates.
    rng=random.Random(830612)
    for trial in range(360):
        num=3+trial%5;coords=sorted(rng.sample(range(-20,21),num));ints=[rng.randrange(1,31) for _ in range(num)]
        if trial in (235,307,345):
            src=bylabel['pressure_trial_'+str(trial)]['source']
            assert [list(map(Q,y)) for y in src['centers']]==[[Q(x,16)] for x in coords] and list(map(Q,src['weights']))==[Q(w,sum(ints)) for w in ints]
    return dict(full_original_dx_cells=total_cells,principal_blocks=blocks,positive_blocks=positive,brute_residual_source_cuts=cuts,exact_flow_arcs=arcs,original_rows=all_rows,physical_patterns=patterns,exact_hinge_comparisons=hinges,
                scope='Exact finite positive atomic source, original dx and finite firstSTRICT grid hit; no E2 gate, continuous firsthit or independent-block weak theorem.')

def verify_flow(cert,p,rows,bound):
    N=len(p);masses=[subset_mass(S,p) for S in range(1<<N)];forced=[sum((d for C,d in rows if C&~S==0),Q(0)) for S in range(1<<N)]
    assert masses==list(map(Q,cert['source_subset_masses'])) and forced==list(map(Q,cert['source_subset_forced_demands']))
    assert max((forced[S]/masses[S] for S in range(1,1<<N)),default=Q(0))==bound==Q(cert['K_optimal'])
    assert [S for S in range(1,1<<N) if forced[S]==bound*masses[S]]==cert['Hall_maximizers']
    assert [(r['neighborhood'],Q(r['demand'])) for r in cert['rows']]==rows
    witness=cert['Hall_lower_witness'];S=witness['source_subset'];assert Q(witness['ratio'])==forced[S]/masses[S]==bound and Q(witness['source_mass'])==masses[S] and Q(witness['forced_demand'])==forced[S]
    total=sum(d for C,d in rows);flow=cert['maxflow'];R=len(rows);s=0;rs=1;ss=1+R;t=ss+N
    assert flow['source_node']==s and flow['sink_node']==t and flow['row_node_start']==rs and flow['physical_source_node_start']==ss
    expected={(s,rs+r):d for r,(C,d) in enumerate(rows)};expected.update({(rs+r,ss+i):total for r,(C,d) in enumerate(rows) for i in range(N) if C>>i&1});expected.update({(ss+i,t):bound*pi for i,pi in enumerate(p)})
    records=[(a,b,Q(c),Q(f)) for a,b,c,f in flow['arcs']];assert {(a,b):c for a,b,c,f in records}==expected and len(records)==len(expected)
    balance=[Q(0)]*(t+1);residual=[[] for _ in balance];assigned=[Q(0)]*N;assignments={}
    for a,b,c,f in records:
        assert 0<=f<=c;balance[a]-=f;balance[b]+=f
        if c>f:residual[a].append(b)
        if f>0:residual[b].append(a)
        if rs<=a<ss and ss<=b<t:
            assigned[b-ss]+=f
            if f:assignments[(a-rs,b-ss)]=f
        if a==s or b==t:assert f==c
    assert balance[s]==-total and balance[t]==total and all(v==0 for i,v in enumerate(balance) if i not in (s,t))
    seen={s};work=deque([s])
    while work:
        a=work.popleft()
        for b in residual[a]:
            if b not in seen:seen.add(b);work.append(b)
    assert t not in seen and sorted(seen)==flow['source_side'] and sum(c for a,b,c,f in records if a in seen and b not in seen)==total==Q(flow['value'])==Q(flow['cut'])
    assert assignments=={(r['row'],r['source']):Q(r['amount']) for r in flow['nonzero_assignments']}
    assert assigned==list(map(Q,cert['optimal_source_assigned_mass']))==[bound*pi for pi in p] and list(map(Q,cert['optimal_source_normalized_loads']))==[bound]*N
    posterior=[sum((d*pi/masses[C] for C,d in rows if C>>i&1),Q(0)) for i,pi in enumerate(p)]
    assert posterior==list(map(Q,cert['canonical_posterior_assigned_mass'])) and sum(posterior)==total
    canonical=[z/pi for z,pi in zip(posterior,p)];assert canonical==list(map(Q,cert['canonical_posterior_normalized_loads'])) and max(canonical,default=Q(0))==Q(cert['canonical_posterior_max_load'])>=bound
    return len(records)

def exact_analytic_checks():
    # Different exact constants/parameter cases, not assertions imported from a guard.
    tail_moment=sum(Q(math.comb(4,j)*math.factorial(j),2**(4-j)) for j in range(5))
    assert tail_moment==Q(633,16) and 256*tail_moment==10128
    assert 8*(1+Q(27,32)+10128)<100000 and 48**3*320<40000000
    assert sum(Q(2)**j/math.factorial(j) for j in range(4))>5
    chord=weights=0
    # t*b=4log2, X/b=j/4 => all exponential values are rational powers of 2.
    for raw in ((1,2,3,4,5),(9,1,1,1,1),(100,10,3,2,1),(3,5,7,11,13)):
        law=[Q(a,sum(raw)) for a in raw];mean=sum(law[j]*Q(j,4) for j in range(5));mgf=sum(law[j]*2**j for j in range(5))
        assert mgf<=1+15*mean;chord+=1
    for m in (1,2,7,64,4096):
        partial=sum((Q(1,(j+1)*(j+2)) for j in range(m)),Q(0));tail=Q(1,m+1)
        assert partial+tail==1;weights+=1
    # Actual continuous L1 interval firsthits, principal capacities and maps.
    a0=Q(13,32);a1=Q(7,16);k1=Q(1,56);continuous=0
    for delta in (Q(1,64),Q(1,1024),Q(1,16384)):
        for ratio in (3,17,257):
            eps=k1/ratio;k2=k1-eps;b1=a1+delta;b0=b1-4*k2*delta
            assert a0<a1<b0<b1<Q(1,2)
            assert (a1-a0)/(4*a1)==k1 and (b1-b0)/(4*delta)==k2
            assert (a1-a0+b1-b0)/(4*b1)<k1
            for a in (a0,(a0+a1)/2,a1,b0,(b0+b1)/2,b1):
                assert 1<4*a<2 and 4*(Q(1,2)-a)<Q(1,2)
                for factor in (Q(2,3),Q(1),Q(7,6)):
                    r=2*a*factor;A=4*max(Q(0),min(Q(1),r-a))/(2*r)
                    assert (A<1 if factor<1 else A==1 if factor==1 else A>1)
            for y in (Q(0),a1/3,a1):assert y<=a0+4*k1*y
            for y in (a1,(2*a1+b1)/3,b1):assert y<=b0+4*k2*(y-a1)
            z=(b1-b0)/(b1+b0);lo=2*sum((z**(2*j+1)/Q(2*j+1) for j in range(20)),Q(0));hi=lo+2*z**41/(41*(1-z*z))
            assert a1/b1*(b1-b0)<=a1*lo<=a1*hi<=a1/b0*(b1-b0)
            assert a1/b1>Q(9,10) and delta/b1<Q(1,10)
            continuous+=1
    return dict(exact_moment_and_constant_checks=4,rational_bounded_mgf_chords=chord,exact_weight_partial_tail_budgets=weights,independent_continuous_L1_parameters=continuous,
                scope='Exact algebra and actual interval firsthit/map/log envelopes; all-input mgf, moment and fixed-L noise variation claims are analytic proofs, not inferred from finite samples.')

@lru_cache(None)
def alternate_exp_lower(s):
    u=s/16
    if u>=1:return Q(0)
    p=sum(((-u)**j/Q(math.factorial(j)) for j in range(6)),Q(0))
    assert p>0
    return p**16

@lru_cache(None)
def alternate_phi_upper(z):
    z=min(z,Q(1,2));N=32
    return sum((u*(2-alternate_exp_lower((Q(1,2)+z)/u)-alternate_exp_lower((Q(1,2)-z)/u)) for u in (Q(j,N) for j in range(1,N+1))),Q(0))/N

def geometry_checks():
    L=Q(41,100);d=Q(2,5);e=Q(1,10000);q=Q(9,10);t=d-3*e;R=3*(d-e);W=16*L*L;volume=16*e*e
    assert volume/W==Q(1,16810000) and ((2*t-L)/L)**2>Q(3,4) and t>L/2
    assert (4*(Q(1,2)-d+e))**2<Q(1,2) and Q(1,20)<R
    roots=0
    for i in range(7):
        for j in range(7):
            d1=d-e+e*Q(i,3);d2=d-e+e*Q(j,3);lo=2*(d-e);hi=2*(d+e)
            poly=lambda r:4*(r-d1)*(r-d2)-r*r
            assert lo>max(d1,d2) and hi<min(d1+L,d2+L) and poly(lo)<=0<=poly(hi)
            assert q*lo>Q(1,2) and q*hi<lo and poly(q*hi)<0
            assert lo-max(d1,d2)>=t and hi-min(d1,d2)<=d+3*e;roots+=1
    # Four product rectangles contain a full surrounding square; sources are deep in U.
    left=(-R,t);right=(L-t,L+R);assert left[1]>right[0] and -R<0<L<L+R
    assert (1-q*q)*volume==Q(19,625000000)>0
    # Every nonempty component subset misses a component or covers all source support.
    for mask in range(1,16):
        count=mask.bit_count()
        if count<4:assert count*(4*e*e)/(16*(2*t-L)**2)<volume/W
        else:assert volume/W==Q(1,16810000)
    # Independent fifth-order/16-subdivision exponential lower construction.
    bound=max(4*L/lo/32*sum((alternate_phi_upper((d-e+L*Q(j,32))/hi) for j in range(32)),Q(0)) for lo,hi in ((1+Q(k,32),1+Q(k+1,32)) for k in range(32)))
    assert bound<Q(7,10) and bound*bound<Q(49,100)<Q(1,2)
    return dict(independent_actual_root_brackets=roots,component_Hall_cases=15,exact_worst_capture_Hall=str(volume/W),independent_E2_continuum_upper_approx=float(bound),upper_below_7_over_10_exact=True,
                scope='Actual n2 L1 cube, full continuous E2 gate via rational monotone bounds; all-subset continuum Hall maximality and middle condition follow the analytic core argument. Small K, no maximum fresh-Hall or weak counterclaim.')

def scalar_diagnostics():
    # Independent midpoint mixture, stable direct Laplace-box formula (no tail cutoff).
    def fields(eta,x):
        x=abs(x);sums=[0.,0.,0.];N=512
        for j in range(N):
            t=(j+.5)/N;u=(x-.5)/eta;v=(x+.5)/eta
            if x<=.5:
                a=-u;e1=math.exp(-a/t);e2=math.exp(-v/t)
                p=2*t-t*(e1+e2);dp=(e2-e1)/eta;noise=-a*e1-v*e2
            else:
                e1=math.exp(-u/t);e2=math.exp(-v/t)
                p=t*e1*(-math.expm1(-1/(eta*t)));dp=(e2-e1)/eta;noise=u*e1-v*e2
            for k,a in enumerate((p,dp,noise)):sums[k]+=a/N
        return sums
    residual=0.;checks=0
    for eta in (1.,.125,.03125,.00390625):
        for x in (0.,.25,.5,.5+eta/3,.5+2*eta):
            p,dp,q=fields(eta,x);h=eta*1e-5
            fd=eta*(fields(eta+h,x)[0]-fields(eta-h,x)[0])/(2*h)
            residual=max(residual,abs(fd-q));assert abs(fd-q)<2e-8
            checks+=1
    def simpson(f,a,b,N):
        return (b-a)*(f(a)+f(b)+sum((4 if j%2 else 2)*f(a+(b-a)*j/N) for j in range(1,N)))/(3*N)
    vals=[]
    for eta in (.0625,.015625,.00390625):
        cut=max(0.,.5-12*eta)
        def integrand(x):
            p,dp,q=fields(eta,x)
            return q*q/p
        noise=2*simpson(integrand,0,cut,64)+2*eta*simpson(lambda u:integrand(.5-eta*u),0,(.5-cut)/eta,256)+2*eta*simpson(lambda u:integrand(.5+eta*u),0,40,512)
        assert noise<min(1,51*eta)+1e-4
        vals.append(dict(eta=eta,noise_Fisher_quad=noise))
    return dict(independent_noise_parameter_finite_differences=checks,max_absolute_derivative_residual=residual,noise_Fisher_midpoint_mixture_diagnostics=vals,
                scope='Floating direct Laplace-mixture/finite-difference diagnostics; no outward integration or all-input certificate. Fixed-L and selected-L distinction remains analytic.')

MAIN_HASHES={'principal_probe.py':'a1e4d406b2de282071478230db9d00a3805e1fc0aa485dd6bf717dc70bcf9ea1','principal_results.json':'29b348ec80684579a7a38eed5982e71922768cff8801208cd3e0a1926ec64ca4'}
COMPONENT_HASHES={'tunable':'fe7b5452612e90010919a9b55e94b25c6dd1ca30be6dda21a83615a8d5a88792','peeling':'eeb2c08cf4737691ec98c0bfadfd560c1cb2d0a38f0b4962939f051d20b115f2','geometry':'9f1ea6e2af0a83c3a7618af714f0784dd9c25da93897c10df90c7666d9868d13'}

def frozen_inputs():
    for name,h in MAIN_HASHES.items():assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==h
    return MAIN_HASHES

def component_payload(name,expected):
    direct=BASE/(name+'_guard.py')
    if direct.exists():
        code=direct.read_text();assert hashlib.sha256(code.encode()).hexdigest()==expected
        return code,direct.name
    for path in (BASE/(name+'.md'),BASE/'proof.md'):
        if path.exists():
            payloads=[x.rstrip()+'\n' for x in re.findall(r'```python\n(.*?)```',path.read_text(),re.S)]
            matching=[x for x in payloads if hashlib.sha256(x.encode()).hexdigest()==expected]
            if matching:
                assert len(matching)==1
                return matching[0],path.name
    raise AssertionError('Missing frozen '+name+' guard; provide extracted local guard or merged proof.md')

def component_replays():
    out=[]
    for name,h in COMPONENT_HASHES.items():
        code,origin=component_payload(name,h)
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'guard.py';path.write_text(code);start=time.monotonic();r=subprocess.run([sys.executable,'-B',str(path)],capture_output=True,text=True,timeout=60)
            assert r.returncode==0 and not r.stderr
            out.append(dict(component=name,sha256=h,origin=origin,exit=r.returncode,empty_stderr=not r.stderr,elapsed_seconds=round(time.monotonic()-start,4),stdout=r.stdout))
    return out

def main():
    start=time.monotonic();out=dict(status='PASS',frozen_main_hashes=frozen_inputs(),component_replays=component_replays(),principal=saved_principal(),analytic_algebra=exact_analytic_checks(),geometry=geometry_checks(),noise_parameter=scalar_diagnostics())
    out['elapsed_seconds']=round(time.monotonic()-start,4)
    print(json.dumps(out,indent=2,sort_keys=True))

if __name__=='__main__':main()
```
