#!/usr/bin/env python3
import argparse,hashlib,json,pathlib,shutil,subprocess,sys
sys.dont_write_bytecode=True
root=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir');a=p.parse_args()
for n,h in json.loads((root/'manifest.json').read_text())['sha256'].items():
    assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
print('Archive hashes verified; not a mathematical proof.')
if not a.verify_only:
    if not a.output_dir:p.error('--output-dir required')
    out=pathlib.Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=True)
    if out==root:p.error('use a separate output directory')
    for name in ('window_certificate','actual_window_probe','weighted_receiver_check'):
        target=out/(name+'.py');shutil.copy2(root/(name+'.py'),target)
        subprocess.run([sys.executable,'-B',str(target)],check=True)
        if name=='actual_window_probe':subprocess.run([sys.executable,'-B',str(target),'--explore-only'],check=True)
        expected=json.loads((root/(name+'.json')).read_text());actual=json.loads((out/(name+'.json')).read_text())
        if name=='window_certificate':expected.pop('wall_seconds');actual.pop('wall_seconds')
        assert expected==actual,name
    print('All mathematical JSON fields match; wall time is excluded.')
