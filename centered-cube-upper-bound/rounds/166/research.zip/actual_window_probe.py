#!/usr/bin/env python3
"""R166 frozen R151 positive-row / actual outer-hard-source window probe.

All model parameters, same-alpha and source masses are retained. This producer
uses a rowwise max-three q; full FIRST instead has a common scalar q. For fixed
(omega,V,j,y,t), Pi_t and e_t do not depend on x. Window kernel diagnostics still
need the receiver-dependent s,L,R,g,wg,rho and time/qualification gates handled.
"""
from pathlib import Path
import importlib.util
import hashlib
import json
import math
import sys

HERE = Path(__file__).resolve().parent
R165 = Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round165_20261015_final_checkpoint/hard_overlap_check.py')
POINTS = Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json')
spec = importlib.util.spec_from_file_location('r165_window_tools', R165)
tools = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tools)
old, np, mp = tools.old, tools.np, tools.mp


def G(x):
    x = float(x)
    t = abs(x)
    result = t-old.expn(4, .5-t)+old.expn(4, .5+t) if t <= .5 else .5-old.expn(4, t-.5)+old.expn(4, t+.5)
    return math.copysign(float(result), x)


def mass_phi(lo, hi):
    return G(hi)-G(lo)


def window(model, v, z):
    b, L = model['b'], model['L']
    # Original producer hard_sources uses exact half-width 1/2 and b=1,
    # hence R=b here; g^2=L*R is checked in main, not retuned.
    R = b
    zg = model['cj']*model['g']/b
    ps, bs, gs, direct48, direct96 = [], [], [], [], []
    for i in range(model['n']):
        y = float(model['y'][i])
        vv, zz = float(model['positions'][v][i]), float(model['positions'][z][i])
        lo, hi = zz-R/2, zz+R/2
        hardlength = max(0., min(hi,y+L/2)-max(lo,y-L/2))
        ps.append((1-model['s'])*hardlength/L+model['s']*mass_phi((lo-y)/L,(hi-y)/L))
        bs.append(mass_phi((lo-vv)/b,(hi-vv)/b))
        gs.append(min(1.,tools.C((y-vv)/b)/zg))
        direct48.append(tools.one_dim(model['s'],L/b,R/b,(vv-y)/b,(zz-y)/b,zg,48,b))
        direct96.append(tools.one_dim(model['s'],L/b,R/b,(vv-y)/b,(zz-y)/b,zg,96,b))
    product = math.prod(ps[i]*bs[i]/gs[i] for i in range(model['n']))
    cs = math.sqrt(product)
    direct = math.prod(direct96)
    Cvals=[tools.C((float(model['y'][i])-float(model['positions'][v][i]))/b) for i in range(model['n'])]
    displacement=[abs(float(model['positions'][z][i])-float(model['y'][i]))/b for i in range(model['n'])]
    M = sum(math.log1p(displacement[i]/Cvals[i]) for i in range(model['n']))
    mt = tools.L0*sum(displacement)
    la = tools.lam(model['s'])
    cap = math.exp((-model['n']*la+min(M,mt))/2)
    exponential_threshold = math.exp(-model['n']*la/4)
    rootnorm = math.sqrt(2/(math.e*la))*math.sqrt(model['n'])
    return dict(v=v,z=z,P_mass=ps,B_mass=bs,gamma=gs,
                coordinate_P_B_over_gamma=[ps[i]*bs[i]/gs[i] for i in range(model['n'])],
                direct_1d_GL96=direct96,
                gamma_product=math.prod(gs),original_wg=float(model['wg'][v]),
                P_B_over_gamma_product=product,CS_Rn_times_kernel=cs,direct_Rn_times_kernel=direct,
                R=R,R_inverse_n=R**(-model['n']),CS_kernel=R**(-model['n'])*cs,direct_kernel=R**(-model['n'])*direct,
                direct_GL48_GL96_abs_difference=abs(math.prod(direct48)-direct),
                CS_to_direct_ratio=cs/direct if direct else None,
                M=M,Mtilde=mt,R165_Rn_times_exponential_cap=cap,
                direct_to_165_cap=direct/cap,CS_to_165_cap=cs/cap,
                R165_near_gate=mt<=model['n']*la/2,
                exact_exponential_kernel_threshold=exponential_threshold,
                exact_CS_exponential_gate=cs<=exponential_threshold,
                exact_direct_exponential_gate=direct<=exponential_threshold,
                root_time_Rn_times_cap=math.log(2)*rootnorm,
                nlog2_CS_to_root_time_cap=model['n']*cs/rootnorm,
                nlog2_direct_to_root_time_cap=model['n']*direct/rootnorm)


def mp_mass_and_window(model,v,z):
    mp.mp.dps=50
    conv=lambda x:mp.mpf(x.numerator)/x.denominator if isinstance(x,old.F) else mp.mpf(str(x))
    s,L,b,g,cj=[conv(model[k]) for k in ('sF','LF','bF','gF','cjF')]
    R=b;zg=cj*g/b
    ps=[];bs=[];direct=[]
    for i in range(model['n']):
        y=mp.mpf('.3');vv=conv(model['positions'][v][i]);zz=conv(model['positions'][z][i])
        lo,hi=zz-R/2,zz+R/2
        cuts=sorted(set([lo,hi]+[x for x in (y-L/2,y+L/2,vv-b/2,vv+b/2) if lo<x<hi]))
        gamma=min(1,tools.mp_C((y-vv)/b)/zg)
        pp=lambda x:((1-s)*int(abs(x-y)<=L/2)+s*old.phi_mp((x-y)/L))/L
        jj=lambda x:old.phi_mp((x-vv)/b)/b
        ps.append(sum(mp.quad(pp,[l,h]) for l,h in zip(cuts[:-1],cuts[1:])))
        bs.append(sum(mp.quad(jj,[l,h]) for l,h in zip(cuts[:-1],cuts[1:])))
        direct.append(sum(mp.quad(lambda x:mp.sqrt(pp(x)*jj(x)/gamma),[l,h]) for l,h in zip(cuts[:-1],cuts[1:])))
    return dict(P_mass=[float(x) for x in ps],B_mass=[float(x) for x in bs],direct_Rn_times_kernel=float(mp.fprod(direct)))


def main():
    template=next(x for x in json.loads(old.R136.read_text())['cases'] if x['id']=='I1')
    model=old.build(template,json.loads(old.R142.read_text())['cases']['I1'])
    rows=[r for r in json.loads(POINTS.read_text())['point_records']['8'] if r['after'] and r['gates']['high'] and r['I']>0]
    assert len(rows)==8
    R=model['b'];zg=model['cj']*model['g']/model['b']
    assert R==1 and abs(model['g']**2-model['L']*R)<1e-14 and abs(zg-model['cj']*math.sqrt(model['L']*R)/model['b'])<1e-14
    # Preserve original finite source support and all row-specific alpha/rho.
    groups={};records=[]
    for row in rows:
        replay=old.one_point(model,[old.Fq(x) for x in row['xq']],template)
        assert replay['I']==row['I'] and replay['alpha']==row['alpha'] and replay['after']
        values=old.eval_batch(model,np.array([row['x']]))
        J,Q=values[4][0],values[5][0]
        k1nu=float(values[2][0]@model['nu']);k2nu=float(values[3][0]@model['nu'])
        active_v=sorted(set(p['v'] for p in row['pair_terms']))
        hardmass=sum((model['nuF'][z] for z in range(6) if row['hard_sources'][z]),old.F(0))
        z_records=[]
        for z in range(6):
            hard=row['hard_sources'][z]
            z_records.append(dict(z=z,actual_hard=hard,nu=float(model['nuF'][z]),
                                  raw_hard_nu_density=float(model['nuF'][z])*R**(-model['n']) if hard else 0.,
                                  raw_hardmass_fraction=float(model['nuF'][z]/hardmass) if hard else 0.,
                                  nu_over_q=float(model['nuF'][z])/row['q'] if hard else 0.))
            if hard:
                for v in active_v:
                    groups.setdefault((v,z),window(model,v,z))
        chiI=sum(p['I']*float(J[p['v']]/(3*Q[p['v']])) for p in row['pair_terms'])
        time_records=[]
        for pair in row['pair_terms']:
            v,u,delta=[pair[k] for k in ('v','u','delta')]
            seg=model['profiles'][pair['segment']]
            lo=float(seg['lo']);hi=min(float(seg['hi']),(model['BFA']*delta*row['p']*float(seg['c'][v])/float(Q[v]))**.25)
            t=math.sqrt(lo*hi)
            wt=[float(seg['c'][i])*t**(-seg['k'][i]) for i in range(6)]
            et=sum(model['nu'][i]*wt[i] for i in range(6));pi=[model['nu'][i]*wt[i]/et for i in range(6)]
            dv=max(1-model['D']*float(values[1][0,v])/(model['T']*model['A'][v]),0.)
            lowc=model['D']*float(values[1][0,u])*float(J[v])*et/(model['T']*model['A'][v]*row['QJ']*wt[u]*delta)
            endpoint_lowc=[]
            for endpoint in (lo,hi):
                wend=[float(seg['c'][i])*endpoint**(-seg['k'][i]) for i in range(6)]
                eend=sum(model['nu'][i]*wend[i] for i in range(6))
                cend=model['D']*float(values[1][0,u])*float(J[v])*eend/(model['T']*model['A'][v]*row['QJ']*wend[u]*delta)
                endpoint_lowc.append(cend/((25/3)*dv*dv))
            assert seg['k'][v]==4 and seg['k'][u]==0 and max(endpoint_lowc)<1
            time_records.append(dict(v=v,u=u,original_FA_window=[lo,hi],midpoint=t,Pi_mid=pi,e_mid=et,
                                     q=row['q'],Pi_pair_product_over_q=pi[v]*pi[u]/row['q'],
                                     lowc_ratio_mid=lowc/((25/3)*dv*dv),
                                     lowc_ratio_endpoints=endpoint_lowc,whole_original_window_lowc_by_monotonicity=True,
                                     rho=row['rho'][v],chiJ=float(J[v]/(3*Q[v])),score_delta=delta,
                                     original_chiJ_score_I=pair['I']*float(J[v]/(3*Q[v]))))
        records.append(dict(xq=row['xq'],p=row['p'],q=row['q'],p_over_q=row['p']/row['q'],alpha=row['alpha'],rho=row['rho'],
                            necessary_q_source_tests=dict(K1_nu=k1nu,K2_nu=k2nu,
                                K1_nu_over_q=k1nu/row['q'],K2_nu_over_q=k2nu/row['q'],
                                q_ge_K1_nu=row['q']>=k1nu,q_ge_K2_nu=row['q']>=k2nu,
                                original_three_candidates=row['q_tests'],original_max_three=max(row['q_tests']),
                                original_max_three_over_q=max(row['q_tests'])/row['q']),
                            positive_good_sources=active_v,hardmass=float(hardmass),raw_z=z_records,Pi_q_time_records=time_records,
                            actual_kernel_groups=[[v,z] for v in active_v for z in range(6) if row['hard_sources'][z]],
                            original_chiJ_score_I=chiI,
                            implemented_raw_inner_without_2Lambda_history_beta=row['p']/row['q']*float(hardmass)*R**(-model['n'])*chiI,
                            dx_weight_corrected=row['dx_weight_corrected']))
    actual=list(groups.values())
    # Existing-model pressure only: all six raw z windows at the SAME original
    # L,R,s,zg and original positive v. Non-CORE windows have zero hard support at
    # these eight receiver rows and are not relabelled as actual traffic.
    pressure=[window(model,v,z) for v in sorted({v for v,z in groups}) for z in range(6)]
    refs=[]
    for v,z in [(0,5),(2,5),(0,0),(2,4)]:
        w=window(model,v,z);ref=mp_mass_and_window(model,v,z)
        refs.append(dict(v=v,z=z,actual_group=(v,z) in groups,
                         mp50_direct=ref['direct_Rn_times_kernel'],direct_abs_error=abs(w['direct_Rn_times_kernel']-ref['direct_Rn_times_kernel']),
                         max_abs_P_error=max(abs(a-b) for a,b in zip(w['P_mass'],ref['P_mass'])),
                         max_abs_B_error=max(abs(a-b) for a,b in zip(w['B_mass'],ref['B_mass']))))
    # Time pressure is kept inside each original positive FA window: full
    # original Pi/q is recomputed at 3 log-midpoints, no alternative support.
    pressure_time=[]
    for record,row in zip(records,rows):
        for pair in record['Pi_q_time_records']:
            sg=model['profiles'][next(p['segment'] for p in row['pair_terms'] if p['v']==pair['v'] and p['u']==pair['u'])]
            lo,hi=pair['original_FA_window'];vv=pair['v'];uu=pair['u'];samples=[]
            for k in range(3):
                t=lo*(hi/lo)**((k+.5)/3)
                wt=[float(sg['c'][i])*t**(-sg['k'][i]) for i in range(6)];et=sum(model['nu'][i]*wt[i] for i in range(6))
                pi=[model['nu'][i]*wt[i]/et for i in range(6)]
                samples.append(pi[vv]*pi[uu]/row['q'])
            pressure_time.append(dict(xq=row['xq'],v=vv,u=uu,Pi_pair_over_q_range=[min(samples),max(samples)]))
    rawsum=sum(float(old.Fq(r['dx_weight_corrected']))*r['implemented_raw_inner_without_2Lambda_history_beta'] for r in records)
    out=dict(scope='Eight frozen R151 m8 after/high/I>0 rows, same six-source nu/alpha/rho and original L,R,s,cj,zg; implementation gates only, not FULL.',
             inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (R165,Path(old.__file__),old.R136,old.R142,POINTS)},
             parameters=dict(n=model['n'],s=model['s'],L=model['L'],R=R,b=model['b'],cj=model['cj'],zg=zg,y=model['y'].tolist(),
                             eta=tools.ETA,lambda_s=tools.lam(model['s']),R_inverse_n=R**(-model['n'])),
             normalization_contract=dict(full_FIRST='For fixed (omega,V,j,y,t), q is a common scalar and Pi_t,e_t do not depend on x.',
                                         this_diagnostic='Original producer q=max(K0*nu,J*nu,Q*nu) is retained separately in each receiver row; it does not certify the full FIRST common-q model.',
                                         receiver_dependence='s,L,R,g,wg,rho and time/qualification gates require handling in original traffic.'),
             source_names=[a['name'] for a in template['atoms']],source_positions=[[float(x) for x in pos] for pos in model['positions']],
             actual_window_groups=actual,positive_rows=records,
             stages=dict(initial='Original eight rows replayed exactly; only actual hard source and positive-good source groups.',
                         existing_model_pressure=dict(all_six_outer_z_windows=pressure,original_FA_time_samples=pressure_time),
                         expanded='No parameter expansion: changes would require re-establishing original qualification. No new receiver grid.'),
             mp50_checks=refs,
             summary=dict(receiver_rows=len(records),actual_row_v_z_groups=sum(len(r['actual_kernel_groups']) for r in records),
                          distinct_actual_v_z_groups=len(actual),actual_outer_z=sorted({z for v,z in groups}),
                          exact_CS_gate_covered_groups=sum(w['exact_CS_exponential_gate'] for w in actual),
                          exact_direct_gate_covered_groups=sum(w['exact_direct_exponential_gate'] for w in actual),
                          R165_near_gate_covered_groups=sum(w['R165_near_gate'] for w in actual),
                          actual_direct_kernel_range=[min(w['direct_kernel'] for w in actual),max(w['direct_kernel'] for w in actual)],
                          actual_CS_kernel_range=[min(w['CS_kernel'] for w in actual),max(w['CS_kernel'] for w in actual)],
                          actual_CS_root_time_fraction_range=[min(w['nlog2_CS_to_root_time_cap'] for w in actual),max(w['nlog2_CS_to_root_time_cap'] for w in actual)],
                          all_original_positive_pairs_lowc_mid=all(p['lowc_ratio_mid']<1 for r in records for p in r['Pi_q_time_records']),
                          all_original_positive_pairs_lowc_whole_window=all(p['whole_original_window_lowc_by_monotonicity'] for r in records for p in r['Pi_q_time_records']),
                          all_q_ge_K1_nu=all(r['necessary_q_source_tests']['q_ge_K1_nu'] for r in records),
                          all_q_ge_K2_nu=all(r['necessary_q_source_tests']['q_ge_K2_nu'] for r in records),
                          K1_nu_over_q_range=[min(r['necessary_q_source_tests']['K1_nu_over_q'] for r in records),max(r['necessary_q_source_tests']['K1_nu_over_q'] for r in records)],
                          K2_nu_over_q_range=[min(r['necessary_q_source_tests']['K2_nu_over_q'] for r in records),max(r['necessary_q_source_tests']['K2_nu_over_q'] for r in records)],
                          max_gamma_product_vs_original_wg_relative_error=max(abs(w['gamma_product']/w['original_wg']-1) for w in pressure),
                          max_direct_GL48_GL96_abs_difference=max(w['direct_GL48_GL96_abs_difference'] for w in pressure),
                          max_mp50_direct_abs_error=max(r['direct_abs_error'] for r in refs),
                          finite_dx_weighted_implemented_raw_inner=rawsum),
             limitations=['Fixed-source exact-window kernel gates cover source groups numerically; receiver-dependent s,L,R,g,wg,rho and time/qualification/history/selector gates remain to be handled.',
                          'For fixed (omega,V,j,y,t), Pi_t,e_t do not depend on x and full FIRST has a common scalar q; this producer instead retains its original rowwise max-three q.',
                          'External raw hard z is distinct from inner bad u; only z with actual row hard support enters raw mass shares.',
                          'The implemented raw inner value omits 2Lambda, history and beta/j selectors; it is not a FULL budget.',
                          'No duplicate hard16/3 cap is applied. GL/mp computations are not interval certificates.'])
    (HERE/'actual_window_probe.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(out['summary'],indent=2))


def exploratory_scan():
    """Append a bounded single-coordinate search, without replaying old rows."""
    path=HERE/'actual_window_probe.json'
    out=json.loads(path.read_text())
    pars=out['parameters']
    assert pars['s']==.25 and pars['L']==.9 and pars['R']==1 and pars['b']==1
    zg=math.sqrt(.9)
    def a(v,order=96):
        return tools.one_dim(.25,.9,1.,float(v)-.3,-.3,zg,order)
    grid=[i/50 for i in range(-400,401)]
    values=[a(v) for v in grid]
    peaks=[i for i in range(1,len(grid)-1) if values[i]>=values[i-1] and values[i]>=values[i+1]]
    seeds=sorted(set(peaks+[max(range(len(grid)),key=lambda i:values[i])]))
    local=[]
    for i in seeds:
        lo,hi=max(-8.,grid[i]-.04),min(8.,grid[i]+.04)
        vs=np.linspace(lo,hi,1001)
        vals=[a(v) for v in vs]
        j=max(range(len(vs)),key=lambda k:vals[k])
        vv=float(vs[j])
        fine=np.linspace(max(-8.,vv-.002),min(8.,vv+.002),401)
        refined=[a(v) for v in fine]
        k=max(range(len(fine)),key=lambda q:refined[q])
        bestv=float(fine[k])
        local.append(dict(seed_v=grid[i],seed_A=values[i],local_v=bestv,local_A=refined[k],
                          local_step=float(fine[1]-fine[0]),GL48_GL96_abs_difference=abs(a(bestv,48)-refined[k])))
    tails=[dict(v=v,A=a(v),GL48_GL96_abs_difference=abs(a(v,48)-a(v))) for v in (-64.,-32.,-16.,16.,32.,64.)]
    best=max(local,key=lambda r:r['local_A'])
    mp.mp.dps=50
    reference=tools.mp_ref(.25,.9,1.,best['local_v']-.3,-.3,zg)
    allpoints=[dict(v=r['local_v'],A=r['local_A']) for r in local]+[dict(v=r['v'],A=r['A']) for r in tails]
    result=dict(scope='Independent exploratory single-coordinate scan only; old eight rows not replayed and no model parameters changed.',
                fixed=dict(y=.3,z=0.,L=.9,R=1.,b=1.,s=.25,zg=zg),
                A='integral_[-.5,.5] sqrt(P_.25,.9(x-.3)*P_1,1(x-v)/min(1,C(.3-v)/sqrt(.9))) dx',
                grid=dict(lo=-8.,hi=8.,step=.02,count=len(grid),maximum_v=grid[max(range(len(grid)),key=lambda i:values[i])],maximum_A=max(values)),
                local_extrema=local,tail_checks=tails,observed_maximum=max(allpoints,key=lambda r:r['A']),
                mp50_best_local_A=mp.nstr(reference,30),mp50_best_local_abs_error=float(abs(mp.mpf(best['local_A'])-reference)),
                limitations=['Finite grid/local refinement/tail samples are not a whole-source supremum certificate.',
                             'No interchange of source suprema and limits is made; no original Pi/q/history budget is proved.'])
    out['exploratory_single_coordinate_scan']=result
    path.write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':
    exploratory_scan() if '--explore-only' in sys.argv else main()
