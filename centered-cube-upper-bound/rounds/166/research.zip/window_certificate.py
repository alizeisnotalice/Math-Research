#!/usr/bin/env python3
"""R166: directed-decimal hard-window certificate; stdlib only; no float oracle.

Run python3 window_certificate.py. Writes its owned JSON sibling; the Markdown sibling explains the proof.
All analytic inputs are exact Fractions. exp is enclosed by an elementary Taylor
remainder. sqrt is enclosed by integer isqrt. E_n is enclosed by convex midpoint
and trapezoid sums. This is intentionally one I1 source pair, not a source scan.
"""
from decimal import Decimal, Context, ROUND_FLOOR, ROUND_CEILING
from fractions import Fraction as F
from functools import lru_cache
from math import isqrt
from pathlib import Path
import json, hashlib, time

PREC=42
DN=Context(prec=PREC,rounding=ROUND_FLOOR)
UP=Context(prec=PREC,rounding=ROUND_CEILING)
ZERO=Decimal(0); ONE=Decimal(1)

class I:
    __slots__=('lo','hi')
    def __init__(self,a,b=None):
        if isinstance(a,I): self.lo,self.hi=a.lo,a.hi; return
        if b is not None: self.lo,self.hi=Decimal(a),Decimal(b); return
        a=F(a); self.lo=DN.divide(Decimal(a.numerator),Decimal(a.denominator)); self.hi=UP.divide(Decimal(a.numerator),Decimal(a.denominator))
    def __add__(a,b):
        b=I(b); return I(DN.add(a.lo,b.lo),UP.add(a.hi,b.hi))
    __radd__=__add__
    def __neg__(a): return I(a.hi.copy_negate(),a.lo.copy_negate())
    def __sub__(a,b): return a+-I(b)
    def __rsub__(a,b): return I(b)+-a
    def __mul__(a,b):
        b=I(b); ds=[DN.multiply(x,y) for x in (a.lo,a.hi) for y in (b.lo,b.hi)]; us=[UP.multiply(x,y) for x in (a.lo,a.hi) for y in (b.lo,b.hi)]
        return I(min(ds),max(us))
    __rmul__=__mul__
    def __truediv__(a,b):
        b=I(b); assert b.lo>0
        return a*I(DN.divide(ONE,b.hi),UP.divide(ONE,b.lo))
    def __rtruediv__(a,b): return I(b)/a
    def __pow__(a,n):
        assert n>=0; result=I(1)
        while n:
            if n&1: result=result*a
            a=a*a; n//=2
        return result
    def nonnegative(a): return I(max(ZERO,a.lo),max(ZERO,a.hi))
    def capped_one(a): return I(min(ONE,a.lo),min(ONE,a.hi))
    def sqrt(a):
        assert a.lo>=0
        scale=10**38
        def floorroot(d):
            q=F(d)*scale*scale
            return isqrt(q.numerator//q.denominator)
        lo=floorroot(a.lo); hi=floorroot(a.hi)
        # Construct exact finite decimals through strings, never ambient rounding.
        def dec(k): return Decimal(str(k)+'e-38')
        return I(dec(lo),dec(hi+1))
    def out(a): return [str(a.lo),str(a.hi)]

@lru_cache(None)
def exp_neg(x):
    x=F(x); assert x>=0
    if not x: return I(1)
    k=0
    while x>F(1,8): x/=2; k+=1
    r=I(x); term=I(1); total=I(1)
    for j in range(1,25):
        term=term*r/I(j); total=total+term
    # exp(r): positive tail, successive ratios <= r/(26) after term 25.
    first=term*r/I(25)
    tail=first/(I(1)-r/I(26))
    result=I(1)/I(total.lo,(total+tail).hi)
    for _ in range(k): result=result*result
    return result

@lru_cache(None)
def E(n,t,N):
    """Integral_0^1 a^(n-2) exp(-t/a) da; n=3,4; g(0)=0."""
    t=F(t); assert n in (3,4) and t>=0
    if not t: return I(F(1,n-1))
    def g(a): return I(a**(n-2))*exp_neg(t/a)
    # Convexity: g''=exp(-t/a)*(k(k-1)a^(k-2)
    # +2t(k-1)a^(k-3)+t^2 a^(k-4)) >=0 for k=n-2=1,2.
    midpoint=sum((g(F(2*j+1,2*N)) for j in range(N)),I(0))/I(N)
    trapezoid=(sum((g(F(j,N)) for j in range(1,N)),I(0))+g(F(1))/I(2))/I(N)
    return I(midpoint.lo,trapezoid.hi)

@lru_cache(None)
def phi(r,N):
    r=abs(F(r)); half=F(1,2)
    ans=(I(1)-E(3,half-r,N)-E(3,half+r,N)) if r<=half else (E(3,r-half,N)-E(3,r+half,N))
    return ans.nonnegative()

def Phi(r,N):
    """Odd primitive of phi, Phi(0)=0, via E4 derivatives."""
    r=F(r)
    if r<0: return -Phi(-r,N)
    if r<=F(1,2): return I(r)-E(4,F(1,2)-r,N)+E(4,F(1,2)+r,N)
    return I(F(1,2))-E(4,r-F(1,2),N)+E(4,r+F(1,2),N)

def C(r,N):
    r=abs(F(r))
    if r<=1: return (I(1-r)+I(F(1,3))-E(4,1,N)-E(4,r,N)+E(4,r+1,N)).nonnegative()
    return (E(4,r-1,N)-2*E(4,r,N)+E(4,r+1,N)).nonnegative()

def bounds_phi(lo,hi,center,scale,N):
    # phi is even and decreasing on [0,infty): follows directly by integrating
    # the even decreasing w over a centered interval, or phi'=w(r+.5)-w(r-.5).
    a=(lo-center)/scale; b=(hi-center)/scale
    near=F(0) if a<=0<=b else min(abs(a),abs(b)); far=max(abs(a),abs(b))
    return I(phi(far,N).lo,phi(near,N).hi)/I(scale)

S=F(1,4); L=F(9,10); R=F(1); B=F(1); Y=F(3,10)
V=F(-4,5); Z=F(0); CJ=F(1)

def certificate(nx,na):
    zg=(I(L*R).sqrt()*I(CJ))/I(B)
    cv=C((Y-V)/B,na); gamma=(cv/zg).capped_one(); assert gamma.lo>0
    left=Z-R/2; right=Z+R/2
    # Include p jumps, both centers, and phi formula switches. Only p jumps
    # require one-sided treatment; singleton boundary values integrate to zero.
    cuts=sorted({left,right}|{x for x in (Y-L/2,Y+L/2,Y,V,V-B/2,V+B/2) if left<x<right})
    integ=I(0)
    for l,h in zip(cuts[:-1],cuts[1:]):
        for j in range(nx):
            lo=l+(h-l)*F(j,nx); hi=l+(h-l)*F(j+1,nx)
            hard=1 if abs((lo+hi)/2-Y)<L/2 else 0
            pp=(I((1-S)*hard)+I(S)*bounds_phi(lo,hi,Y,L,na)*I(L))/I(L)
            jj=bounds_phi(lo,hi,V,B,na)
            integ=integ+I(hi-lo)*(pp*jj/gamma).sqrt()
    overlap=max(F(0),min(right,Y+L/2)-max(left,Y-L/2))
    P=(I((1-S)*overlap/L)+I(S)*(Phi((right-Y)/L,na)-Phi((left-Y)/L,na))).nonnegative()
    BB=(Phi((right-V)/B,na)-Phi((left-V)/B,na)).nonnegative()
    product=P*BB/gamma
    cs=product.sqrt()
    def width(q): return str(UP.subtract(q.hi,q.lo))
    return dict(x_subdivisions_per_segment=nx,a_subdivisions=na,segments=[[str(x),str(y)] for x,y in zip(cuts[:-1],cuts[1:])],
        cells=nx*(len(cuts)-1),zg=zg.out(),C=cv.out(),gamma=gamma.out(),P=P.out(),B=BB.out(),P_B_over_gamma=product.out(),
        direct_integral=integ.out(),direct_width=width(integ),CS_sqrt_PB_over_gamma=cs.out(),
        tensor_n4_Rn_times_kernel=(integ**4).out(),tensor_n4_CS_Rn_times_bound=(cs**4).out())

def main():
    start=time.monotonic()
    rows=[certificate(nx,na) for nx,na in ((8,16),(16,32),(32,64),(64,128))]
    names=('C','gamma','P','B','P_B_over_gamma','direct_integral','CS_sqrt_PB_over_gamma')
    monotone={name: all(Decimal(rows[j+1][name][0])>=Decimal(rows[j][name][0]) and Decimal(rows[j+1][name][1])<=Decimal(rows[j][name][1]) for j in range(len(rows)-1)) for name in names}
    assert all(monotone.values()),monotone
    assert Decimal(rows[-1]['direct_integral'][1]) < Decimal(rows[-1]['CS_sqrt_PB_over_gamma'][0])
    assert Decimal(rows[-1]['direct_integral'][1]) < 1 < Decimal(rows[-1]['P_B_over_gamma'][0])
    source=Path('/Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015/centered_cube_round136_20261014/active_traffic_v2.json')
    template=next(c for c in json.loads(source.read_text())['cases'] if c['id']=='I1')
    assert all(F(template['parameters'][k])==value for k,value in dict(s=S,L=L,b=B,y=Y,a=F(1,2)).items())
    assert F(template['derived']['cj'])==CJ and template['n']==4
    atoms={atom['name']:atom for atom in template['atoms']}
    assert all(F(x)==V for x in atoms['G1']['position'])
    assert all(F(x)==Z for x in atoms['CORE']['position'])
    data=dict(scope='One original I1 coordinate: good source G1 v=-4/5, hard source CORE z=0, y=3/10; all four coordinates repeat. Frozen geometry only, no current high/good/rho certification.',
        arithmetic='No float arithmetic enters bounds: Fraction exact inputs, Decimal directed operations, rational Taylor exp remainder, integer-isqrt square roots, convex midpoint/trapezoid E3/E4 sums.',
        parameters={k:str(x) for k,x in dict(s=S,L=L,R=R,b=B,y=Y,v=V,z=Z,cj=CJ,a=F(1,2)).items()},
        zg_rule='cj*sqrt(L*R)/b (interval computed, not rounded frozen g string)',input_sha256={str(source):hashlib.sha256(source.read_bytes()).hexdigest()},
        precision=PREC,exp_terms=24,sqrt_decimal_places=38,refinements=rows,raw_intervals_nested=monotone,
        certified_decisions={'strict_direct_upper_below_CS_lower':True, 'direct_integral_strictly_below_one':True, 'P_B_over_gamma_strictly_above_one':True},
        limitations='No original q/e_xi^2/history/selector budget is paid; one finite geometry example does not certify all I1 source pairs or a uniform theorem.',
        wall_seconds=round(time.monotonic()-start,3))
    here=Path(__file__).resolve().parent
    (here/'window_certificate.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({'seconds':data['wall_seconds'],'finest':rows[-1],'nested':monotone},indent=2))

if __name__=='__main__': main()
