# R166 原来源、FIRST 与 history 的有界恢复合同

状态：来源合同恢复有实质加强；没有证明完整 raw 付款。只写本文件。先由 ZIP 成员名索引定位 R140 `beta_source_contract.md`，再回查 R113、R117、R128 原证明的最小行段，并核本机原 `TASK_CONTEXT.md`。没有通读全历史、外网检索、数值运行、Git、PDF 或子代理。

## 1. 可引用的准确命题与量词

**SC1（实际耦合来源合同）。** 对同一完整输入 \(f\ge0\)、共同标量 \(q\)、同一原随机种子 \(\omega\) 与其原不交终端叶 \(V\)，取 R113 C/I **耦合构造后的**实际软余源
\[
 \alpha_V=\mu_{{hi},\omega}|_V,\quad 0\le\mu_{{hi},\omega}\le fdx,
 \qquad \beta_V^c=\alpha_V-\eta_{\alpha,V}^c.
\]
保持原硬尾 \(\nu_V\) 不变。该构造给出
\[
 0\le\nu_V\le\zeta_{\sigma,V}^*\le\beta_V^c\le\alpha_V\le fdx,
 \qquad W_{\eta_\alpha^c}+W_{\beta^c}=W_\alpha\le W_{hi},
 \quad W_\beta:=\mathbb E\sum_V\|\beta_V\|.
 \tag{SC1}
\]
这里 \(\mu_{{hi},\omega}\) 沿原输入的高来源及原种子记号；不从master最初的确定性高低密度分解反推后继所有带种子限制的来源都与原 \(f1_{f>q\sqrt n}dx\) 相等。R107 `integration.md:17–20` 明给 \(\sigma_\omega\le\mu_{{hi},\omega}\le fdz\)、\(W_{hi}=\mathbb E\|\mu_{{hi},\omega}\|\)。在此路线的后继稿中 \(\beta\) 省略上标 \(c\)。\(c\) 是“coupled 构造”的标签，不是可逐接收点选择的数值参数；原来源与软网络选择可依 \(\omega,V\) 及原有限菜单，但在接收点选择之前冻结，不依当前 \(x\) 重新选流。SC1 是测度支配，故也给 \(\nu_V\ll\beta_V\)、\(0\le d\nu_V/d\beta_V\le1\)；不提供反向支配、相等、独立性或逐 piece 常数比例。

**SC2（实际 FIRST，不是有限 producer 的 max）。** 对原当前 \(s=s(x),L=L(x)\)，
\[
 P_{s,L}f(x)=q,\qquad
 P_{s',L'}f(x)\le q\quad\text{所有 }s'\in[s,1],\ L'\in[a,b],
 \quad q\in[3\lambda/4,\lambda],\quad h_{R(x)}f(x)\le4\lambda.
 \tag{SC2}
\]
这里 q 由完整原输入给定，是同一 FIRST 水平，不以截取来源重新定义。于是同一当前行中
\[
 K_1=P_{s,L}(x-\cdot),\quad
 K_2=P_{s,L^+}(x-\cdot),\ L^+=\min(b,(1+1/n)L),
 \quad J=P_{1,b}(x-\cdot),\quad Q=(K_1+K_2+J)/3
\]
均给 \(\int K_1d\nu_V,\int K_2d\nu_V,\int Jd\nu_V,\int Qd\nu_V\le q\)。若使用原 \(K_0=P_{s,\widehat H}(x-\cdot)\)，需保留 \(\widehat H=\max(a,\min(b,H_0))\in[a,b]\)，才有 \(\int K_0d\nu_V\le q\)。上述也适用于 \(\beta_V\le fdx\)；当前核还给 \(\int K_1d\beta_V\le q\)。核/混合参数可以依接收行，但同一测试不得依被积分来源点逐点重选。有限 producer 写 \(q=\max\{\int K_0\nu,\int J\nu,\int Q\nu\}\) 仅为必要模型定义，不能替换 SC2。

**SC3（原 history 是受支配核的 RN 因子）。** 原真实外交通为
\[
 d\mathcal T_I=1_I1_{\{j(x)=j\}}q^{-1}P_{s(x),L(x)}(x-y)
 h_{R(x)}(x-z)a_\omega(x,y,z)\,dx\,d\beta_V(y)d\nu_V(z),
 \quad 0\le a_\omega\le1.
 \tag{SC3}
\]
\(a_\omega\) 是原联合软核相对于 \(q^{-1}P_{s,L}d\beta_V\) 的 RN 因子，保留 FULL/FIRST、strict CP/GP/deep、原失败币、种子/共同叶、原父限制、新旧删除门等实际资格。它不是自由挑选的任意 \([0,1]\) 函数。外 \(\mathbb E\sum_{V,j}\)、唯一 \(j(x)\)、实际时间域全部保留；没有恢复出额外的“history 概率和为1”合同，也不需要猜出这一性质。外硬 \(z\) 与内 bad \(u\) 是不同积分槽。如果另按更细 history 标签拆分，SC3的 \(a_\omega\le1\) 只属于原聚合RN因子；不能给每个拆分各领取一次该帽再免费求和，须先恢复拆分恒等式/不交性或总和支配。

## 2. 直接可用的总质量/行预算，以及不能推出的预算

由 SC1 和原叶不交，逐种子有
\[
 \sum_V\|\nu_V\|\le\sum_V\|\beta_V\|
 \le\sum_V\|\alpha_V\|\le W_{hi};
 \quad \mathbb E\sum_V\|\nu_V\|\le W_\beta\le W_{hi}.
 \tag{SC4}
\]
这是真实总质量预算，不是质量为1。若对 \(d\nu\) 的非负单槽被积函数作上放，可用 \(\int Fd\nu\le\int Fd\beta\)；**外 \(d\beta(y)\) 不能反向换成 \(d\nu(y)\)**。\(W_\eta+W_\beta=W_\alpha\) 只允许准确互补来源账合并，不能再次免费领取已付来源费。

同一实际行另有
\[
 b_\omega(x,y):=\int h_R(x-z)a_\omega(x,y,z)d\nu_V(z)\le4\lambda,
 \qquad q^{-1}\int P_{s,L}(x-y)d\beta_V(y)\le1.
 \tag{SC5}
\]
故可在原资格上先积硬 z 得 \(b_\omega/q\le16/3\)，或得到已有 \(T_{small}\le4X\)。这不将 \(\beta,\nu\) 概率化，也不支付 \(d\beta/e_t\)、\(e_t^{-2}\nu\otimes\nu\)、适应参数或全部时间积分。raw 仍带 \(h_R\) 时不再乘16/3。signed 外价仍为 \(2\Lambda\)。

固定 \((\omega,V,j,y,t)\) 后，原 \(\nu_V,Z_{j,V,y,t},w_t,e_t,\Pi_t\) 不依 x 或外 hard z；R128 RT4 明文准许这一固定量词下移出 x。但 \(t=g(x)\)、\(e_{g(x)}\)、\(L/R/s\)、\(D_g/S_g\)、same-alpha、\(\rho\)、当前 high、history 等仍依接收行。按 R166 的 \(\xi=c_jt/b\) 改元时需固定原 b,j，保留原允许时间域。SC1–SC5 因而改善 R165“β–ν关系未建立”的信息状态，却没有证明 R165 H12 所需不依 x,ξ 的完整来源系数预算。

## 3. 可追踪证据与同名 β 的分界

以下行号均是 UTF-8 解码后按换行计数；ZIP 不解压也可定位。

|证据位置|实读内容|结论及限制|
|---|---|---|
|`rounds/113/research.zip:proof.md` 27–34（B2）|原独立软网络 \(\beta=\zeta_\alpha\)，明确未假定 \(\nu\le\beta\)|这是旧路线的同名β；不能直接从名称推出SC1。|
|同成员 422–443（C6–C8）|同一叶/pieces，保留原硬提取的扩张；以α共同支配取有限菜单RN运行最大值；\(\nu\le\zeta_\alpha^*\le\alpha\)|SC1的实际构造证据；软提取一般不是每piece常数倍。|
|同成员 457–485（I1–I3）|\(\beta^c=\alpha-\eta_\alpha^c\)、质量分账、接收前冻结、原FULL不重选|允许用耦合β；原hard rank/低叶均值不转移给β。|
|本机 `output/centered_cube_round114_20261014/ratio_settlement.md:9`、`:128`|明确“严格取R113耦合构造后的实际核Γ_F^c/T_F^c”，β=β^c，ν≤β，后继余项继续保留|不是仅建议可换一条路线；R114实际采用该路线。|
|本机 `output/centered_cube_round115_20261014/integration.md:7,26,30`|继承R114全部原门及共同ν≤β、\(W_\eta+W_\beta\le W_{hi}\)|后继Tsmall仍为同路线。|
|`rounds/117/research.zip:proof.md` 67–82（JG5–6）、264–310（CL1–3）|\(a_\omega\in[0,1]\)、实际RN交通、ν≤β≤f、唯一j、硬帽和低pe限制|SC3/SC5直接原文，不靠history名称猜界；明说ν≤β不能控制dβ/e。|
|本机 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/TASK_CONTEXT.md:5–9`|FIRST完整等式/全future、ν≤β≤f、原不交叶、history门|SC2最短原合同；第5行实际严格soft下门也保持。|
|`rounds/128/research.zip:proof.md` 604–667（RT1–6）|原完整行、Wβ定义、两e分母、固定(ω,V,j,y,t)的x独立性、三个合法tests、K0与same-alpha|原source/q/history合同进入当前正余泛函的公开归档定位。|
|`rounds/136/research.zip:centered_cube_round136_20261014/active_bad_geometry.md` 157–175、268–274；`ordered_score_capacity.md` 127–130|原raw交通与β–ν保留；FIRST给QJ≤q；同一完整原积分付Wβ|R136沿用的是原合法行，未宣布替换为旧独立β。R136自身不重述C/I构造，需以上祖链一并引入。|
|`rounds/140/research.zip:beta_source_contract.md` 7–38|已整理同一条R113→R117→R128合同及精确本机定位|仅作本轮定向检索导航；上述结论已回读原证明最小段。|
|`rounds/142/research.zip:receiver_contract_audit.md` 25–29|有限tests的max不等于FIRST；history=1只是必要放松|防止把R136/R151有限producer的q误称原q。|

本机短文件的完整路径前缀为 `/Users/zhengzhihao/Desktop/T/`；ZIP路径前缀为本仓库 `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/`。历史原始门的每一布尔项/随机币生成算法未在本有界恢复中展开，不能仅凭SC3为新模型授予FULL/history身份。当前积分若确实沿原继承合同，使用SC1–SC5无需重建该算法；若另造有限模型，则这些缺项仍须真实实现。

## 4. 64工具的实际迁移筛查（A02、D01）

本轮读取以下已安装技能及其 `references/cube-interface.md`、来源状态，不把技能标题当成外部定理；没有新引用未经本轮核原文的外部数学定理。

- `/Users/zhengzhihao/.codex/skills/math-a02-outer-relaxation-budget/SKILL.md:21–26`：需要真实可行集X、放松Y、映射T，以及逐点目标 \(F\le G\circ T+\epsilon\) 和有限误差预算。只有集合包含不够。迁移到raw时可将a≤1或ν≤β用于明确非负上界，但必须写出同一raw目标及所有分母/尺度因素；有限放松模型的正交通不能反向认证FULL。若用norm-induced cut还需紧域、连续目标、全域Lipschitz上界及单调范数，每个master全局求解才能升级最优性；本轮没有这些数据，故未调用该算法。
- `/Users/zhengzhihao/.codex/skills/math-d01-kantorovich-duality/SKILL.md:22–28`：静态正OT先需匹配总质量与可行耦合，弱对偶 \(\varphi+\psi\le c\) 在最小化给下界、可行计划给上界。SC1只有子测度支配，不是指定β与ν为两个等质量边缘；\(\Pi_t\)归一化不修补原β–ν质量差。向量KR要求Polish度量空间、总向量质量0及有限一阶矩；其“P1π−P2π=μ”的向量中性计划不是原正耦合。带跳SOT还需闭凸/有界特征、小跳统一条件、成本可测下半连续凸等；与当前静态raw没有已建立映射。故不得由“Kantorovich对偶”直接支付source/history或声称最优计划存在。若未来构造新运输证书，须先证明它同时保持原hard捕获/因果门、e分母、允许参数和所需上界方向。

成功判据是将SC1–SC5及原共同测试真实代入完整raw，证明统一 \(C\sqrt n\operatorname{polylog}(n)W_\beta\)（或明确许可的\(\epsilon X\)）预算。失败/未完成判据是仍需假设未证的dβ/e、两后验分母、x适应尺度、history总和或FULL实现；本轮属于“已恢复合同、未付完整预算”，不将条件改名为新定理。


## 5. 追加：叶/父尺寸与是否存在 qa^n 局部质量帽

**SC6（本轮准确结果：有叶均值帽与当前hard盒帽，没有恢复出统一全叶 qa^n 帽）。** R117 来源索引明确指回 R107 原位置硬尾，因此只按该指向回读 `output/centered_cube_round107_20261013/integration.md` 的 R9/R12/R22–26 最小片段；没有泛读其他历史。

1. 原叶并不是边长a或R的立方体。上述R107原文件77–109行：原最细共同格边长固定为 \(256na\)；终端叶 \(V\) 有
   \[
   |V|=(256na)^n,\qquad M_*<\|\sigma_V\|
   <\frac{K_{256}\lambda}{\sqrt n}|V|,
   \quad M_*=\lambda a^ne^{\sqrt n},\quad K_{256}=4e^{1/128}.
   \tag{SC6a}
   \]
   当前 \(\nu_V\le\sigma_V=\sigma_\omega|_V\)，故最多直接得到
   \[
   \frac{\|\nu_V\|}{qa^n}
   <\frac{4K_{256}}{3\sqrt n}(256n)^n.
   \tag{SC6b}
   \]
   这是指数维数的粗帽，不能改写成绝对C或polylog(n)。此“低叶均值”按巨大体积 \(|V|\) 计，不是任意边长a子盒的均值帽。树轻停止阈值也是 \(M_*=\lambda a^ne^{\sqrt n}\)，不是 \(Cqa^n\)。
2. R107同文件180–222行在receiver前固定 \(\nu_V=\widehat\zeta_V-\widehat\zeta_V^{top}\)、\(m_V=\|\nu_V\|\)，并区分轻尾 \(m_V\le M_*\) 与重尾 \(m_V>M_*\)。轻尾高行已有单独窗口付款R25；因此该段绝不提供一般 \(m_V=O(qa^n)\) 结论。若要进一步断言当前每个叶仍属于原重尾支，须沿当前明确的子核继承门核对；本追加不以名称代替这一步。
3. 可用的局部上界保留当前接收点。R107 R1（9–17行）及 R128 RT1（ZIP `proof.md:604–611`）给原实际 \(Q_x=x+[-R(x)/2,R(x)/2]^n\) 与 \(h_Rf(x)\le4\lambda\)，因而
   \[
    \nu_V(S\cap Q_x)\le\nu_V(Q_x)\le4\lambda R(x)^n
    \le\frac{16}{3}qR(x)^n\quad(\text{任意可测 }S).
    \tag{SC6c}
   \]
   对 \(R\in[a,b]\subset[a,2a]\)，粗化到a给 \((16/3)2^nqa^n\)，仍不能冒作维数无关帽。若S在某个固定**实际**接收点的hard盒内，可用该点的帽；若先积分x并移去hard盒，再对与y接近或源域near的固定z集合收费，SC6c不能直接替代全叶质量。原FIRST也只给与同一x上的合法核加权质量帽；不提供所有空间中心、所有小盒的无权局部qa^n帽。
4. 当前小parent是接收资格，不是重新定义的来源支撑。R115 `integration.md:9–16`给 \(\operatorname{side}(P)<576na/\epsilon\) 的LCA截断，明说 \(T_{small}\) 为原核子核、不重选parent/来源/receiver。R113 ZIP `proof.md:43–52`只给 \(Q_x\subset V,y\in V\) 和原 \(D_V(y)=V\cap\{z:\|z-y\|_1\le17na\}\)；即便保留该距离门，也没有引出qa^n无权质量帽。不能据小parent门把整份冻结 \(\nu_V\) 支撑换成P或边长a的盒。
5. R117 ZIP `proof.md:360–366`确有对任意可测A的 \(\nu_V(A)\le h(A)=\mu_{hi}(A\cap B)\)。本机 `sources_scope.md:105`还给原最粗轻块 \(h(A)\le H_j(g)\) 时 \(\nu(A)\le H_j(g)\)；但当前 \(Z_t\) 正是排除该light块的域，不能把light块质量帽施于其补集或整个叶。没有读到将任意near/local来源域嵌入一个具有 \(H_j\lesssim qa^n\) 已证帽的同一light块的构造。

因此 raw 若最后剩 \(q^{-1}a^{-n}\|\nu_V\|\)，仅靠已恢复低叶均值/parent合同不能付成统一常数。可保留SC6c的同一x相关hard载体另作联合估计，但那仍是未完成的加权接收问题；本合同不声称不存在任何未检索的更强结构。

## 6. 追加：原比例 j 的有限菜单、唯一归属与每列时间窗

**SC7（可安全支付的显式 j 数）。** 原比例菜单是
\[
 \gamma=1+1/n,\quad c_j=\gamma^{-j},\quad
 J=\left\lfloor\frac{\log(b/a)}{2\log\gamma}\right\rfloor,
 \qquad j=0,1,\ldots,J.
 \tag{SC7a}
\]
它不是无限几何网格，也不是固定的 j=1,…,n 或 O(log n) 菜单。菜单由固定 n,a,b 在receiver之前给定；因为 b/a≤2，有明确有限粗界 \(N_j=J+1\le n+2\)。该粗界已在 R139 原证明中明文使用，不需要新的原合同假设。

**唯一 j 的含义。** 它来自原receiver的尺度比 \(v(x)=|\log(L(x)/R(x))|\)，以 \(v_j=2j\log\gamma\) 分割：[v_j,v_{j+1})，0≤j<J；最后列为闭区间 [v_J,log(b/a)]。端点 log(b/a)=v_J 时保留最后单点；a=b时只有j=0单点。因此唯一的是 \(j(x)\)，不是任意固定时间t上只有一个合法j。固定t后，不同列的允许时间窗可以重叠；若正上界已删去原 \(1_{\{j(x)=j\}}\)，须真实支付最多N_j≤n+2列，不能再凭“唯一j”免去该求和。

每个j的物理时间与heavy窗为
\[
 \tau_j=a/c_j\le t\le bc_j,\qquad
 e_{j,V,y,t}>B_jt^n,\quad B_j=\ell q c_j^{-n/2},\quad\ell=1+\log n.
 \tag{SC7b}
\]
原 \(I_{j,V,y}\) 是这一区间中从τ_j开始的strict-heavy初始区间，右端按原门决定可闭可开；空集贡献0，不定义除e的后验。当前far正项还限制 \(J_{far}=I_{j,V,y}\cap[\tau_j,h]\)、\(h=g\exp(-u/n)\le g\)。对每j可安全上放到固定窗 [a/c_j,bc_j]，其对数长度
\[
 \int_{a/c_j}^{bc_j}\frac{dt}{t}
 =\log(b/a)+2\log c_j\le\log2
 \tag{SC7c}
\]
（空窗按0；单点dt/t质量0）。固定 \((\omega,V,j,y,t)\) 后再使用Π_t的x独立性。若改元 \(\xi=c_jt/b\)，必须每j各自保留其改元窗和原上端h；不得把多个j的Π_t当成同一个后验。

最小实读证据：

- 本机 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round114_20261014/ratio_settlement.md:11–24`（S1–S2）：完整j范围、半开/最后闭端点、唯一receiver归属、\(a/c_j\le g\le bc_j\)、菜单接收前固定。
- 本机 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:25–32`（JG2）；对应 `rounds/117/research.zip:proof.md:45–52`：每j物理窗、strict-heavy初始区间与空窗处理。
- `rounds/128/research.zip:proof.md:637–650`（RT4前后）：原far时间窗和固定(j,y,t)的后验接口。
- `rounds/139/research.zip:joint_hard_margin.md:149,165–172`：明确 \(N_j\le n+2\)、每j时间≤log2，实际付款证明按这些价格求和；该处只作j/time计数证据，不将其条件hard-margin付款移给本轮新分支。

因此，新核/source证明若对全部允许j具有同一非负上界，可安全乘显式 \((n+2)\log2\)（若时间已另处理，只乘n+2）。此结论只处理本octave内原比例菜单；另有绝对尺度带/不同原输入块的求和仍须其原预算，不能凭SC7扩展成无界菜单。
