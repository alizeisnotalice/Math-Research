#!/usr/bin/env python3
"""Finite floating exploration of RB4/RB5; analytic tails bounded separately."""
from pathlib import Path
import importlib.util,json,math,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
p=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round165_20261015_final_checkpoint/hard_overlap_check.py')
spec=importlib.util.spec_from_file_location('weighted166',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
np=m.np;old=m.old

def G(t):
    t=abs(float(t))
    return t-old.expn(4,.5-t)+old.expn(4,.5+t) if t<=.5 else .5-old.expn(4,t-.5)+old.expn(4,t+.5)
def primitive(t):return math.copysign(G(t),t)
def phi_window(v):return primitive(.5-v)-primitive(-.5-v) if abs(v)<2 else m.C(v)
def run(order):
    nodes,weights=np.polynomial.legendre.leggauss(order)
    # Integrate the tail after the change u=t/theta; split for stability.
    t=np.concatenate([(i+(nodes+1)/2) for i in range(40)])
    wt=np.tile(weights/2,40)*np.exp(-t)
    records=[];lp=2/(1-math.exp(-1))
    for s0 in (.001,.01,.25,1.):
        eps=s0*m.ETA;theta=lp+(16+8*math.exp(lp))/eps
        A=1-.75*eps;B=1+.25*eps
        for L in (.5,.75,1.):
            for s in sorted(set((s0,(1+s0)/2,1.))):
                core=1-s+s*2*G(.5/L)
                # Outside [-.5,.5] no hard contribution for L<=1.
                val=core+2*s/L/theta*float(wt@old.phi_np((.5+t/theta)/L))
                tail=4/theta*math.exp(-40)
                records.append(dict(kind='p',s0=s0,s=s,L=L,value=val,tail_bound=tail,bound=A,margin=A-val-tail))
        for v in (-32.,-8.,-1.,-.5,0.,.5,1.,8.,32.):
            core=phi_window(v)/m.C(v)
            val=core+float(wt@(old.phi_np(.5+t/theta-v)+old.phi_np(-.5-t/theta-v)))/theta/m.C(v)
            tail=2*math.exp(lp)/(theta-lp)*math.exp(-(1-lp/theta)*40)
            records.append(dict(kind='J',s0=s0,v=v,value=val,tail_bound=tail,bound=B,margin=B-val-tail))
    return records

def main():
    a,b=run(48),run(96)
    out=dict(scope='Finite RB4/RB5 floating check, not a proof or interval certificate; GL error not certified by doubling.',count=len(b),records=b,max_order_difference=max(abs(x['value']-y['value']) for x,y in zip(a,b)),min_margin=min(x['margin'] for x in b),exceedances=int(sum(x['margin']<0 for x in b)),eta=m.ETA,stages=['s0=.25 centered and near-source baseline','far-source +-8,+-32, hard-scale endpoints','s0=.001,.01,1 with L=.5,.75,1 and soft endpoints'],limitations='Analytic omitted tails are bounded; the retained quadrature rounding/integration error remains floating evidence.')
    (HERE/'weighted_receiver_check.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='records'},indent=2))
if __name__=='__main__':main()
