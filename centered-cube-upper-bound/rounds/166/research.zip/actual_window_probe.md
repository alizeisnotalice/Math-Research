# R166：原正行的实际硬窗核

**原模型的两组实际来源，直接 sqrt 窗核均有明显余量；精确窗CS仍损失过大。** 原8个R151正行产生12个 `(positive-good v, actual-hard z)` 组，去重后仅 `(G1,CORE)` 与 `(G3,CORE)`。直接核为 `.42876746/.41783555`，均低于 `exp(-n*lambda/4)=.94038207`；CS核为 `1.05423957/.97498122`，均未过该门。G1组的 `product(P_i*B_i/gamma_i)=1.11142106>1`，因此现有真实来源已经给出“CS逐坐标必收缩”路线的数值压力。

这支持优先研究直接重叠中的位置关系，不能据此宣布原Pi/q加权交通已付款。原行仅过实现门，完整FIRST/history及来源合同仍未认证。

## 固定对象与量词

只读原R151 producer、六源模板/nu及8个m8 `after/high/I>0` 行。逐行原样重放I与共同alpha；没有改q、rho、good、来源质量或当前支持。保留原 `s=.25,L=.9,R=b=1,cj=1`，`zg=cj*sqrt(LR)/b=.9486832981`；R=1由原hard支持的半宽1/2确定，并核对g²=LR。

逐个外hard来源z和原positive-good来源v，算

\[
P_i=\int_{z_i-R/2}^{z_i+R/2}L^{-1}f_s((x-y_i)/L)dx,
\quad B_i=\int_{z_i-R/2}^{z_i+R/2}b^{-1}\phi((x-v_i)/b)dx,
\quad\gamma_i=\min(1,C((y_i-v_i)/b)/z_g).
\]

P/B用解析phi原函数积分；直接核用逐维GL48/96积分。输出同时保留
`R^-n*sqrt(product(P_i*B_i/gamma_i))` 与
`R^-n*product(integral sqrt(p_i*J_i/gamma_i))`。
本模型R^-n=1，JSON仍明确记录该因子，没有再领取16/3硬帽。

## 原8行初步与实际来源覆盖

所有原正pair的bad u均为G4；**外hard z则均为CORE**，没有把二者混同。八行的实际hard来源质量都是
`nu(CORE)=6.274594676962957e-8`，在该行raw hard质量中的份额100%；其余五源虽有正nu，但在这些receiver的hard支持为零，raw份额为0。

| 实际(v,z) | 出现行数 | CS平方乘积 | CS核 | 直接核 |
|---|---:|---:|---:|---:|
| G1,CORE | 8 | 1.11142106 | 1.05423957 | .42876746 |
| G3,CORE | 4 | .95058838 | .97498122 | .41783555 |

四维P_i均为`.6622712073`。G1的B_i均为`.2587374825`，gamma_i均为`.1668881755`，故每坐标 `P_i*B_i/gamma_i=1.0267616888`，但每坐标直接积分只有`.8091992184`。G3另两坐标对应`.9495691465`与`.7988168904`。p中心y=.3，而J中心在−.8或−1.6；CS将它们在原硬窗中的位置关系丢掉，给出明显更大的上界。

R165的 `min(M,Mtilde)` 指数帽分别为7.4107180、17.9316695，近硬门均不通过。精确直接核却对这两组都通过`.94038207`门，覆盖原12个正来源组；精确CS门覆盖0组。这是有限直接核证据，不是区间证书或新一般定理。

另比较完整时间帽

\[
n\log2\,\mathrm{kernel}\quad\text{对}\quad
\log2\sqrt{2/(e\lambda_s)}\sqrt nR^{-n}.
\]

n=4、lambda=.0614690240时，右端为4.79617537。CS比例分别`.60943825/.56362033`，直接核比例`.24786329/.24154374`，均小于1；**较宽的n4时间帽通过，不等于指数收缩门通过，也不能推一般n阶。** 未乘sqrt(K/3)。

## 原Pi/q、low-c与必要来源资格

JSON逐行保留q、alpha、rho、全部六源当前Pi、外nu(z)/q，以及原positive FA窗口内midpoint的 `Pi(v)*Pi(u)/q`。又在原窗口取3个log-midpoint作压力检查；没有删改当前支持或替换为terminal权。

必须区分原定义与有限producer：固定 `(omega,V,j,y,t)` 后，完整FIRST模型的q是共同标量，Pi_t及e_t不依赖x。这里保留的producer却逐receiver取 `q=max(K0*nu,J*nu,Q*nu)`；它没有认证完整FIRST共同q合同。同一固定t下的Pi不因receiver而变化；实际仍须处理的接收依赖是s,L,R,g,wg,rho及时间/资格门，另有history和selector合同。

原 `p/q` 约为4270116–4479034。midpoint `Pi(G1)*Pi(G4)/q` 约645097–661371，G3对应约32120–32883；在这些行的同一midpoint，Pi相同，上述比值差异来自producer逐行q。保留已知因子后的逐行实现内量

`p/q * sum_z nu(z)h_R(x-z) * original_chiJ_score_I`

约`.02388926–.02644873`，按原校正dx权加总为`.0001232961620`。此值未含2Lambda、history、beta及唯一j等外合同，故不记作FULL预算。

所有原positive pair的low-c比在原FA窗口两端均小于1。该窗口k_v=4、k_u=0，c随时间递减；端点覆盖完整原窗口，不仅是midpoint。因此上述来源组确实对应旧实现门下的low-c正交通。

按主代理恢复的必要来源条件，直接核查原q对K1*nu、K2*nu：八行全部满足，且没有调整q。

| 必要检验 | 八行比值范围 |
|---|---:|
| K1*nu / q | .28853745–.30158436 |
| K2*nu / q | .19314676–.19969044 |
| 原max(K0*nu,J*nu,Q*nu) / q | 全为1 |

这只排除这些逐行必要不等式的失败，不能建立同一个f、nu≤beta≤f dx、完整FIRST共同q及history的可实现性。数值q未作调整。

## 同模型压力、误差与复现

压力只用同一模型的六个外z原硬窗与两个positive v，共12个去重窗组；其中非CORE的10组在原8个receiver上没有实际hard支持，未计作实际交通。它们直接核也都低于指数门，CS门只在实际CORE两组失败。未改参数或增加receiver网格，因为那需要重新核原资格。

GL48/96直接核最大差`1.714e-12`。实际两组及另两个旧窗做mp50核对，直接核最大绝对差`2.904e-14`，P/B质量最大绝对差约`1.53e-16`。gamma乘积与原wg最大相对差`2.67e-15`。这些高精对照不构成区间证书。

在仓库根运行：

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 centered-cube-upper-bound/rounds/166/work/actual_window_probe.py
```

脚本只写同目录JSON，所需旧producer/工具及输入SHA均保留。没有改他人文件，没有Git操作。完整FIRST共同q合同尚未认证，接收参数、rho、时间资格门、history与selector的加权积分仍未支付；本任务到此停止。

## 独立追加：固定原硬窗的有界来源扫描

按主代理追加任务，固定**单坐标** `y=.3,z=0,L=.9,R=b=1,s=.25,zg=sqrt(.9)`，只考察直接窗积分A(v)。未重放旧8行，没有改变模型；结果独立写在JSON的 `exploratory_single_coordinate_scan` 字段。

[-8,8]步长.02的801点网格最大为`.8092206027`，在v=−.82。该极值邻域加密至步长1e−5后，观测最大为

`A(−.81393)=.8092254240397452`。

该点GL48/96差`7.81e−13`，mp50值`.8092254240397321714`，相差`1.31e−14`。六个尾点：

| v | A(v) |
|---:|---:|
| −64 | .78167564 |
| −32 | .78243165 |
| −16 | .78382284 |
| 16 | .64220480 |
| 32 | .64436970 |
| 64 | .64551182 |

有限菜单显示最大值与1有明显间隔，值得继续尝试严格的全来源直接窗包络；**它不是全来源sup证书**，没有排除采样间或更远尾部的未观测极大值，也未交换sup与极限。

只追加该探路、保留既有8行结果的复现命令：

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 centered-cube-upper-bound/rounds/166/work/actual_window_probe.py --explore-only
```

追加任务结束，不扩展参数或FULL交通。
