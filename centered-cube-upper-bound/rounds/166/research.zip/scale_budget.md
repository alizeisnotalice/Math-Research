# R166：精确硬窗的连续尺度正包络与收缩余量支付

状态：完成连续 receiver 选择器的解析覆盖，给出全 octave、整个软度中间段的显式费用。**在已有统一指数收缩的来源域内，尺度选择可保留根阶；一般来源尚未证明所需精确窗收缩，故这不是 FULL 或原 raw 加权预算。** 采用本轮恢复的固定时间后验合同；本稿负责尺度包络及其对接接口，不承担另一责任稿的完整来源费用证明。不改共同 alpha，不改变原门。

责任范围仅本文件。读取 R166 task_contract、R165 hard_source_bridge §§1–4（§6仅用于识别未证交换）、hard_overlap_check 的原 I1 覆盖信息，以及 joint_future_scale_budget 中已支付的 averaged-softness selector；后据父代理通知追加读取 R166 source_contract.md 的 SC1–SC5。以下新推导只用单调性、有限求和、Cauchy–Schwarz 和一元微分；没有调用未经核原文的外部定理，没有数值证书。

## 1. 命题与量词筛查

固定 n≥1、b/2≤a≤b、来源 y,v,z、原标签 c_j>0，以及 0<s_0≤s_1≤1。只在原实际选择满足

\[
 a\le L(x),R(x)\le b,\qquad s_0\le s(x)\le s_1,
 \qquad z_g(x)=c_j\sqrt{L(x)R(x)}/b\in[1/2,1]
\]

的可测 receiver 集上应用。y、v、z 不许随 x 重新选择，b、a、c_j 也在本命题内固定。若它们属于原 history 的标签，则须在其原求和／积分之外逐标签使用，并另付原总预算。

设 C_i=C((y_i-v_i)/b)，J_v=P_{1,b}(x-v)，

\[
 \gamma_i(L,R)=\min(1,C_i/z_g),\quad
 K_{L,R,s}(x)=R^{-n}{\bf1}_{Q(z,R)}(x)
       \sqrt{P_{s,L}(x-y)J_v(x)/\prod_i\gamma_i(L,R)}.
\]

精确固定核质量是

\[
 \int K_{L,R,s}=R^{-n} A_{L,R,s},\qquad
 A_{L,R,s}=\prod_i\int_{z_i-R/2}^{z_i+R/2}
 \sqrt{L^{-1}f_s((x-y_i)/L)b^{-1}\phi((x-v_i)/b)/\gamma_i}\,dx.
 \tag{1}
\]

逐维 Cauchy 给

\[
 A_{L,R,s}\le E_{L,R,s}:=\sqrt{\prod_i P_iB_i/\gamma_i}.
 \tag{2}
\]

所需新量词是对任意上述可测 L(x),R(x),s(x) 控制 \(\int K_{L(x),R(x),s(x)}(x)dx\)。固定参数 (1)–(2) 本身不允许这个交换。

已知费用筛查：裸 hard 尺度包络具有线性 n 费用；此前 averaged-softness 固定包络有 O(√n log n) column 费用，但其核是软度正平均，不能直接支配这里的原 f_s、原硬窗、原 gamma 倒权。两者都不能作为本对象的免费 selector，本稿不重证这些旧工具，也不借其费用申领新付款。下文给的是新的、直接作用于 (1) 的有限正覆盖。

## 2. 初步：严格覆盖参数，含闭面、归一化和 zg 联动

f_s=(1-s)h+s phi 偶对称且径向单调不增。若 L≤L'，则包括硬支撑闭面在内有

\[
 P_{s,L}(x-y)\le(L'/L)^nP_{s,L'}(x-y).
 \tag{3}
\]

若 0<s'≤s，则逐坐标

\[
 f_s\le(s/s')f_{s'},
 \tag{4}
\]

因为软项系数相同，而 \((s/s')(1-s')\ge1-s\)。这允许 s=1；不用对 1-s 求逆。

令 d=log(b/a)、U=log(s_1/s_0)。定义物理网格

\[
 r_k=\min\{b,a e^{k/n}\},\quad k=0,\ldots,m,
 \qquad m=\lceil nd\rceil,
\]

以及软度网格

\[
 \sigma_t=s_0e^{t/n},\quad t=0,\ldots,\lfloor nU\rfloor.
\]

b=a 时物理网格只有 a；s_1=s_0 时软度网格只有 s_0。对每个原 L,R 取最小不低于它的物理节点 L',R'，对 s 取最大不高于它的 sigma。于是

\[
 L'/L\le e^{1/n},\quad R'/R\le e^{1/n},\quad s/\sigma\le e^{1/n}.
 \tag{5}
\]

右端点 b 明确入网格，故没有遗漏硬面。由 (3)–(5)，

\[
 \sqrt{P_{s,L}}\le e\sqrt{P_{\sigma,L'}}.
 \tag{6}
\]

为处理原 zg≤1 的弯曲合法域，**覆盖核**使用确定性值

\[
 \widehat z_g(L',R')=\min\{1,c_j\sqrt{L'R'}/b\},
 \qquad \widehat\gamma_i=\min(1,C_i/\widehat z_g).
 \tag{7}
\]

因原 zg≤1 且 L'≥L、R'≥R，必有 \(\widehat z_g\ge z_g\)，故 \(\widehat\gamma_i\le\gamma_i\)。同时 \(\widehat z_g\le1\) 给 \(\widehat\gamma_i\ge C_i\)。这两向都用于下文。

(7) 不是让原 zg 独立变化。原交通的 zg 仍严格等于 c_j√(LR)/b，所有 high、good、bad、rho、history 和唯一 j 都沿原值保留。若某覆盖节点未满足原未截断等式的 zg≤1，它仅是明确定义的正 majorant，**不称原可选状态，也不在该节点重验或搬移原门**。若该标签本来 c_j≤1，则截断从不触发。

以帽号表示用 (7) 的覆盖核和精确质量。逐点得到

\[
 K_{L,R,s}(x)\le e^2\widehat K_{L',R',\sigma}(x).
 \tag{8}
\]

其中 e 是 (6)，另一个 e 正是 \((R'/R)^n\)。没有丢掉 R^{-n}。

因此对任意 receiver 选择器，有限求和、Tonelli 和 (1)–(2) 给

\[
 \boxed{\int K_{L(x),R(x),s(x)}(x)dx
 \le e^2\sum_{\ell,k,t} r_k^{-n}\widehat A_{r_\ell,r_k,\sigma_t}
 \le e^2\sum_{\ell,k,t}r_k^{-n}\widehat E_{r_\ell,r_k,\sigma_t}.}
 \tag{9}
\]

这是完全显式的连续尺度覆盖式；右边是有限个已定义的一维精确硬窗积分乘积，而非新命名的未知范数。总节点数至多 \((n d+2)^2(nU+1)\)，无需对来源位置或坐标做网格。

## 3. 已有压力：能保留什么，不能免费抹掉什么

(9) 若只代入固定参数的根阶上界再求和，会引入多项式费用；不能因此得到目标。需要保留尚未消耗的收缩余量。

而且 R^{-n} 并不随 n 无害。例如 a=b/2 时 a^{-n}=2^n b^{-n}。下面将 (9) 写成 a^{-n} 的形式只是一条真实但较粗的上界，不能把原来源预算中的 R^{-n} 自动换成 a^{-n}，也不能把两者称为同常数。

具体地，对于几何物理网格，除可能截短的末节点外 \(r_k^{-n}=a^{-n}e^{-k}\)，于是

\[
 \sum_k r_k^{-n}\le C_R a^{-n},\qquad
 C_R=1+(1-e^{-1})^{-1}.
 \tag{10}
\]

该式也含退化 octave，常数可更好但不需要。它说明物理质量求和中 R 网格不必额外花 n，但代价基准变成 a^{-n}。

另有保留选择器自身 R(x) 的无量纲版本。定义

\[
 H_{L,R,s}=R^nK_{L,R,s}.
\]

对固定 L,s，H 随 R 单调增加：硬窗增大，zg 增大使 gamma 降低；截断 (7) 后该结论仍成立。因此直接上放 R 到 b，随后只覆盖 L,s，得到

\[
 \boxed{\int R(x)^n K_{L(x),R(x),s(x)}(x)dx
 \le e\sum_{\ell,t}\widehat A_{r_\ell,b,\sigma_t}
 \le e\sum_{\ell,t}\widehat E_{r_\ell,b,\sigma_t}.}
 \tag{11}
\]

(11) 的左边是带 R(x)^n 的积分；不能把该因子拿出积分，再声称为原未加权核结论。此处确实去掉了 R 节点数，而没有对原 K 的 R^{-n} 作不合法单调判断。

原 I1 六源在 R165 统一 near 来源域的覆盖为 0。这是本路线已有的实质压力：下节虽将 near 核结论从固定尺度提升至全部选择器，但仍不覆盖这些已知正交通，不能据尺度接缝闭合就登记来源覆盖进展。

## 4. 扩大：全 octave、全中间段的根阶选择器预算

先给可核验的充分条件：对 (9) 全部覆盖节点，若精确积分或 CS 乘积满足

\[
 \widehat A_{r_\ell,r_k,\sigma_t}\le e^{-\kappa n}
 \quad\text{（充分的是 }\widehat E_{r_\ell,r_k,\sigma_t}\le e^{-\kappa n}\text{）},
 \tag{12}
\]

其中 κ>0 可依来源或预先固定参数但不依 receiver 选择，则由 (9)–(10)

\[
 \int K_{L(x),R(x),s(x)}dx
 \le e^2 C_R a^{-n}(nd+2)(nU+1)e^{-\kappa n}.
 \tag{13}
\]

只需 (12) 在 R=b 的节点成立，便由 (11) 有

\[
 \int R(x)^nK_{L(x),R(x),s(x)}dx
 \le e(nd+2)(nU+1)e^{-\kappa n}.
 \tag{14}
\]

这里 (12) 是精确有限节点不等式，不能未经证据声称其对全部来源成立。它与固定尺度小特例不同：节点覆盖任意可测 L(x),R(x),s(x)，并且费用独立于 receiver 振荡次数。

**一个实际已证的非零宽度适用域。** 取 R165 的常数

\[
 \lambda_0=-\log(1-s_0\eta),\quad
 \eta=1-\int_{-1}^1\phi>0,\quad
 L_0=24/[7(1-e^{-1})^2].
\]

若固定来源满足

\[
 L_0\|z-y\|_1/b\le n\lambda_0/2,
 \tag{15}
\]

则**所有**覆盖节点满足 (12)，κ=λ_0/4。核验如下：每个节点仍 L,R∈[a,b]、R/L≤2、sigma≥s_0，故 \(P_i\le e^{-\lambda_0}\)；由 R≤b 和 \(\widehat\gamma_i\ge C_i\)，R165 已证的 log C 平移控制给

\[
 B_i/\widehat\gamma_i\le e^{L_0|z_i-y_i|/b}.
\]

乘积再开根即 \(\widehat E\le\exp[-n\lambda_0/2+L_0\|z-y\|_1/(2b)]\le e^{-n\lambda_0/4}\)。这里重用已审基础引理来检查网格邻域适用性，不重新声称发现固定尺度 near 定理。

**原时间 score 的费用（核组件）。** 对固定原 v,u，原阈值上界 zg(x)≤1 给逐 receiver

\[
 \int_{1/2}^{z_g(x)}\delta_\xi(v,u)d\xi/\xi\le n\log2.
 \tag{16}
\]

其余资格门与 0≤rho≤1 只能下降。由原 good 比较 \(1_Gp\chi_J\le\sqrt{K/3}\sqrt{pJ/w_g}\)，令 T(x) 表示原 good/bad/rho/score 时间积分（不含 q、posterior、history），则 (13)–(14) 给

\[
 \int h_{R(x)}(x-z)T(x)dx
 \le\sqrt{K/3}\,e^2 C_R\log2\,a^{-n}
 (d+2)(U+1)n^3e^{-\kappa n},
 \tag{17}
\]

\[
 \int R(x)^n h_{R(x)}(x-z)T(x)dx
 \le\sqrt{K/3}\,e\log2\,(d+2)(U+1)n^3e^{-\kappa n}.
 \tag{18}
\]

这里若原 K 也变化，须有已付的共同 K_max，公式中用 K_max；不默认 K=1。若 s,L,R 在时间 ξ 内另行变化，(16) 后固定核的操作不再直接成立，本命题只处理合同给定的 receiver/history 参数。

最后只用一元极值

\[
 n^{5/2}e^{-\kappa n}\le(5/(2e\kappa))^{5/2}
\]

将 (17)–(18) 的 \(n^3e^{-\kappa n}\) 改写为

\[
 \boxed{(5/(2e\kappa))^{5/2}\sqrt n.}
 \tag{19}
\]

因此，在任意固定中间软度段 s≥s_0>0、整个 b/a≤2、统一 near 域 (15) 上，全部连续 receiver 尺度选择可以保持根阶。明确费用是 \((1+\log(s_1/s_0))\lambda_0^{-5/2}\)，再乘 (17) 或 (18) 展示的常数与相应物理权重。它没有额外 n 幂。若 s_0 随 n 下降，该费用必须保留；当 s_0^{-1} 为 polylog 且其他固定常数已付时，仍为根阶乘 polylog。s_0=0 不在本命题中。

这项结论的新增部分正是从固定尺度积分到任意 receiver 选择器的合法提升；它不是重复固定尺度界后免费取 sup，也不是把选择器费用改名。统一指数余量支付了有限网格的多项式规模。

### 4.1 按恢复合同固定时间：真实 raw 的正确入口

R166 source_contract（回查原 R128 RT4）给出的量词是：固定 \((\omega,V,j,y,t)\) 后，\(\nu,Z_t,w_t,e_t,\Pi_t\) 不依 x；固定 b,j 后同样适用于 \(\xi=c_jt/b\)。q 是共同 FIRST 标量，原聚合 history 因子 \(0\le a_\omega\le1\)。因此不得延续 R165 中“当前 e 一律依 x”的过强说法。终端 \(g(x),w_g,\Delta,\rho\) 以及时间允许域仍依 x，包络保留／上放它们的方式如上。

使用时先 Tonelli 固定 ξ、v、u，再用 \(\delta_\xi\le n\) 与原 good 比较。若来源对 y,z 满足统一 near 门 (15)，(13) 的界对 v,u 一致。于是对固定原标签、固定 y,z，确有

\[
 \int_{1/2}^{1}\!\int d\Pi_\xi(v)d\Pi_\xi(u)
 \int dx\,h_R p\chi_J\rho\,1_G1_{\rm bad}
 1_{\{\xi\le z_g(x)\}}1_{\rm original\ gates}\,
 a_\omega\delta_\xi
 \le \sqrt{K/3}\,e^2 C_R\log2\,a^{-n}
 (nd+2)(nU+1)n e^{-\kappa n}.
 \tag{20}
\]

先对 x 积分后两份 \(\Pi_\xi\) 才归一；零 e 沿原零交通约定。式 (20) 中原 j 的 receiver 指示可保留或对当前单标签上放，**不授予逐 j 免费相加**。没有将后验当成接收点常数而犯错，因为其独立性正是恢复的固定时间合同；也没有在依 ξ 的两份后验外擅自使用 (16) 的固定 v,u 时间积分。

因此 near 分支尺度路线留下的确切来源接口可写为

\[
 \mathcal S_{\rm near}
 =\mathbb E\sum_{V,j}q^{-1}a^{-n}
 \int {\bf1}_{\{L_0\|z-y\|_1/b\le n\lambda_0/2\}}
 d\beta_V(y)d\nu_V(z),
 \tag{21}
\]

并保留原唯一 j 的实际分解，不能无条件放大后再以唯一性消去。若 a,b,s_0 等按标签变化，(20) 的对应常数同样须留在 (21) 内。把 (19) 与外 signed 因子 2Λ 合并，(20) 给 \(C\sqrt n\mathcal S_{\rm near}\)；没有再乘 SI5 的16/3。另一来源预算路线若能为原有 j 结构建立 \(\mathcal S_{\rm near}\le\operatorname{polylog}(n)W_\beta\)，便可直接完成这一分支；本稿未证明它。

SC1 的 \(\nu\le\beta\) 与 SC4 的总质量已恢复，故不是“β–ν关系未知”；它们仍不单独推出 (21)。也不能因 \(a_\omega\le1\) 就在更细 history 拆分里重复领取该上界。式 (21) 是说明最终仍需付的已有来源对量，而非把它改名作为已证成果。以上仅修正并给出尺度接口，完整后验／来源账由独立责任稿处理。


## 5. 精确成功标准、未证接缝与本轮检验

本路线已成功：

- (9) 是任何原合法连续尺度选择器的精确窗有限正 majorant；所有节点、系数、截断与 R^{-n} 均显式。
- (11) 是保留真实 R(x)^n 权重的较小包络，只须 O(n²(1+log(s_1/s_0))) 个 L,s 节点。
- (15) 上的任意 receiver 尺度与软度选择满足 (17)–(19)，不要求参数分片数、光滑性或低振荡。

尚未成功：

- 对一般来源未证 (12)，尤其不能把 R165 §6 的固定参数尾极限改成 uniform 源上确界；(12) 需精确窗口的新解析证据。数值点检查也不足以认证来源连续域。
- 固定时间后两份 posterior 已可如 (20) 归一，q 也是共同标量，history 有原聚合 a_omega≤1，且 nu≤beta 已恢复；未付的是 (21) 的真实来源对／物理权重及原唯一 j 总预算。不能把已恢复合同继续列作未知。带 R(x)^n 的 (18) 本身不能支付原未加权交通。
- (17) 的 a^{-n} 若用于来源预算，必须真的支付 a^{-n}；不能用原较便宜的 R^{-n} 来源价替代。更精细预算可直接保留 (9) 的逐节点 r_k^{-n} 进行核算，但本文件不假设那份来源预算成立。
- 如果 b 或 c_j 本身也按 receiver 选择，须加入原标签分解费用；当前命题不覆盖把它们免费加入 sup。

实际检验为完整符号检查：向上物理舍入含 b 闭面、向下软度舍入含 s=1、zg 截断的两向不等式、R^{-n} 的 e 因子、R 网格几何和、R^n 归一化后的单调性、near 门在所有覆盖节点稳定、未加权核组件的 score 时间上界、真实 raw 先固定 ξ 再用 δξ≤n 后验归一的次序，以及最后一元极值。没有执行浮点／GL／mp，也没有将它们冒充区间证书。未改其他文件，未 Git，任务交付至此停止。
