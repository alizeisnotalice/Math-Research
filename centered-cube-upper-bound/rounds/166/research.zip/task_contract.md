# R166 精确硬窗与原加权预算
起点：R165 ddab5ac08454e47896f854426b5d268ce9ea90a1已推送，工作区干净。冻结原稿 /Users/zhengzhihao/Desktop/T/output/centered_cube_round165_20261015_final_checkpoint。仅读所需章节，不重复全历史。所有Agent共享文件，但只改指定责任文件，不Git，不覆盖他人，交付停止，不自行扩展。

一般目标任意正L1的一致sqrt(n)n^o(1)弱型上界未闭合。定义h=1[-.5,.5],w(r)=∫0¹e^{-|r|/a}da,φ=h*w,F=max(h,φ),C=h*F，p=P_s,L(x-y),Jv=P1,b(x-v)，a≤L,R≤b≤2a。ξ=cj t/b∈[.5,zg],zg=cj√(LR)/b≤1,wξ(v)=∏min(1,C((y_i-v_i)/b)/ξ),kξ(v)=#{Ci(v)<ξ},eξ=∫Zξwξν,Πξ=1Zξwξν/eξ。原Zg⊂Zξ、high p eg≥2Kq、q≥∫Qν,∫Jν,∫K0ν。Q=(K1+K2+J)/3,K1=P_s,L,K2=P_s,Lplus,Lplus=min(b,(1+1/n)L)。good pwg≤KQ，bad反向，χJ=J/(3Q)，rho原same-alpha，0≤rho≤1，但不可另选alpha。需要精确rho则查165继承合同。

原raw为2Λ EΣVj∫ q^-1 p h_R(x-z) a_history rho_v χJ_v 1good1bad δξ(v,u) dΠξ(v)dΠξ(u) dξ/ξ dx dβ(y)dν(z)，δ=(kv-ku)+。外硬z不是内bad u。β与ν关系未建立，不得概率化或互换。实际history、所有资格门/lowc、唯一j保留。raw不能重复乘SI5的16/3。

R165已证固定参数/source：∫hR sqrt(pJv/wg)≤R^-n exp[(-nλ_s+min(M,L0||z-y||1/b))/2]，λ=-log(1-sη),η=1-∫[-1,1]φ,L0=24/[7(1-e^-1)^2],M=Σlog(1+|z-y|/(bCi(v)))。near L0||z-y||1/b≤nλ/2给核时间root式但q/eξ²/history/selector未付。I1六源和8positive行near覆盖0。s=0无有限λ^-1/2界。

R166精确窗：Pi=∫[z_i-R/2,z_i+R/2]L^-1 f_s((x-y_i)/L)dx；Bi=∫同窗 b^-1φ((x-v_i)/b)dx；γi=min(1,C((y_i-v_i)/b)/zg)。固定核CS上界R^-n sqrt(∏Pi Bi/γi)。也可直接逐维积分sqrt(p_i J_i/γi)。成功必须产生真实适用预算、或改变下一步的真实模型精确窗/权重证据，不重复归约改名。

已知限制：全参数逐坐标严格收缩未经证，不可由数值猜；R165§6探索附录未独审，尤其sup来源与极限不得交换。high、zg与cj,L,R联动必须保留。固定来源核界不能提出x-dependent Π、q或选尺度。有限模型不是FULL，GL/mp不是区间证书。

任务交付先命题/量词筛查，再推导；初步—已有压力—扩大范围三阶段。自证初等积分/Tonelli/Cauchy可用；其他外部定理须核原文。每人标明准确命题、假设、费用、失败/成功判据和实际检验，不为凑数重复。主代理整合并独立提交推送；不编译PDF。
