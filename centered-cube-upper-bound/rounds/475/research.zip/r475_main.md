# 第475轮：原高占用流的联合能量与来源平均捕获付款

## 目标及结论边界

承接第474轮的完整原接受流，研究选带数量与带内几何费用的联合预算。本轮得到保留高占用接收限制的二次捕获能量界，并由此证明高接受密度共同来源处存在规模与密度成正比的近不交父族。一次交叠与二次捕获之间仍有真实缺口，没有取得一般根阶上界。数值验证促使停止把孤立高占用或单纯加宽质量带当作足够机制。

## 完整输入

$\mu=f dx$，$W=\mu(\mathbb R^n)$，实际中心 $A\in E$，边长 $a\le R_A\le b\le2a$。$m_A=\mu(Q_A)=q_AR_A^n$，$q\le q_A\le\lambda$，$r=\lambda/q$，$\sigma=q_A dA$，$X=\sigma(E)$。$c_A=1_{Q_A}$，$\pi_A=c_A\mu/m_A$。

原测度为 $d\Pi=\ell(A,y,z)\sigma(dA)\pi_A(dy)\pi_A(dz)$，其中 $0\le\ell\le S$ 且完整保留原阶段、初始、严格质量路径、soft/early及删除历史。令 $t(A)=\int\ell\,d\pi_A^2$，$R=\int t\,d\sigma$。新取样源不能继承旧历史。原附源 $x\sim\pi_A$ 仅作正分拆。

$D(x)=\int c_A(x)m_A^{-1}d\sigma(A)$，$H=\{D>d\}$，$p_A=\pi_A(H)$，$Y=R_{\rm hi}=\int t p_A d\sigma$，$M=\mu(H)$。有
\[
R\le SdW+Y,\qquad M\le\min(W,X/d).
\]
完整质量区间分成宽度不超过 $L$ 的 $N$ 带，$N\le1+(\log r+n\log(b/a))/L$，两端及空带保留。定义
\[
u_j(x)=\int_{m_A\in J_j}t(A)c_A(x)m_A^{-1}d\sigma(A),\quad u=\sum_j u_j,
\quad e(x)=\sum_j u_j(x)^2,\quad E_H=\int_H e\,d\mu.
\]
记 $I_{AB}=\mu(Q_A\cap Q_B)$，$I^H_{AB}=\mu(H\cap Q_A\cap Q_B)$。非负Tonelli给准确身份
\[
E_H=\sum_j\int_{A,B\in J_j}t_A t_B\frac{I^H_{AB}}{m_Am_B}\,d\sigma_A d\sigma_B,
\qquad Y^2\le NM E_H. \tag{1}
\]
$M=0$时$Y=0$，此后含$1/M$的条件仅用于$M>0$。

## 保留接收限制的混合能量

置 $g_{AB}=I_{AB}/\sqrt{m_Am_B}\in[0,1]$，
\[
G_H=\sum_j\int_{A,B\in J_j}t_A t_B
\frac{I^H_{AB}I_{AB}}{(m_Am_B)^{3/2}}d\sigma_A d\sigma_B.
\]
真实来源CDF $|\{B:x\in Q_B,m_B\le v\}|\le v/q$ 给出
\[
\int\frac{I^H_{AB}I_{AB}}{(m_Am_B)^{3/2}}d\sigma_B\le4r p_A.
\]
确切地，先对 $x\in Q_A\cap H$ 积分，用 $I_{AB}\le\min(m_A,m_B)$；递减函数 $w(v)=\min(m_A,v)v^{-3/2}$ 的积分为 $4\sqrt{m_A}$。CDF与 $q_B\le\lambda$ 给内积分至多 $4r\sqrt{m_A}$。这不使用任何来源密度帽。对称性与 $2t_A t_B\le t_A^2+t_B^2$ 得
\[
\boxed{G_H\le4r\int t_A^2p_A d\sigma_A\le4rS Y.} \tag{2}
\]
这个界不收带数 $N$，并保留 $H$；它不是 $E_H$ 的界。固定带或随机平移带的对称掩码都只减少核，故同界成立。F05技能仅用于明确两侧核与底测度，未调用未核外部谱定理。

## 实际原流中的来源平均捕获

将(2)的核在共同源处换序，定义
\[
v(x)=\sum_j\int_{A,B\in J_j}t_A t_B
\frac{c_A(x)c_B(x)I_{AB}}{(m_Am_B)^{3/2}}d\sigma_A d\sigma_B.
\]
$0\le v\le e$，$\int_H v=G_H$。式(2)对任意可测来源集合$B$均成立，且固定同一个$t$，故测度支配给出
\[
v(x)\le4rS u(x)\quad\mu\text{-几乎处处}. \tag{3}
\]
这也可直接以$2t_A t_B\le S(t_A+t_B)$、$I_{AB}\le\min(m_A,m_B)$及来源CDF逐点验证。

对固定$0<\rho\le1$，在$e>0$上定义$H_\rho=H\cap\{v\ge\rho e\}$。因为$e\ge u^2/N$，有
\[
H_\rho\subset\{u\le4rSN/\rho\}\quad(\bmod\ \mu),\qquad
Y_\rho:=\int_{H_\rho}u\,d\mu\le\frac{4rSN}{\rho}\mu(H_\rho). \tag{4}
\]
这是同一原附源流的正分数，直接付$W$而不需要相对吸收。令$Y_-=\int_{H\setminus H_\rho}u\,d\mu$，则
\[
R\le SdW+Y_-+\frac{4rSN}{\rho}W. \tag{4a}
\]
不能将这个来源类重复计入已付的低接受密度部分。其意义是准确揭示几何方向：真正$u\gg N$的困难来源必然有低平均捕获$v/e\le4rSN/u$，而不是能从高拥挤直接推出高捕获。$Y_-$没有得到预算，式(4a)不是一般闭合。保持原双来源权及原历史，没有把$t$移给代表父；集合仅为事后可测分析分拆。

## 从高接受密度抽取共同来源质量打包

不分质量带，将(3)应用于完整父族。在$u(x)>0$处取实际父后验
\[
P_x(dA)=\frac{t(A)c_A(x)}{m_Au(x)}d\sigma(A),\qquad
\mathbb E_{P_x\otimes P_x}g_{AB}\le\alpha:=\frac{4rS}{u(x)}.
\]
设$S>0$、$u(x)\ge32rS$，令$k=\lfloor u(x)/(32rS)\rfloor$。独立取$k$个父，存在一次取样使有向非对角亲和总和不超过$2\alpha k(k-1)$（零期望时全和几乎处处零）。删除在原样本中非对角行和大于$1/2$的父，删除数至多$4\alpha k(k-1)\le(k-1)/2$。保留族$\mathcal F_x$满足
\[
|\mathcal F_x|\ge k/2,\quad
\sum_{B\in\mathcal F_x\setminus\{A\}}g_{AB}\le1/2.
\]
每个父都真实包含$x$；不同保留项不能有相同来源后验，因为此时$g=1$。令$M_x=\sum_{A\in\mathcal F_x}m_A$。真实来源下的二阶矩满足
\[
\int\left(\sum_{A\in\mathcal F_x}c_A\right)^2d\mu
=M_x+\sum_{A\ne B}g_{AB}\sqrt{m_Am_B}\le\tfrac32 M_x,
\]
故
\[
\boxed{\mu\left(\bigcup_{A\in\mathcal F_x}Q_A\right)\ge\tfrac23 M_x.}
\]
此外归一化来源向量的Gram谱处于$[1/2,3/2]$，由每行非对角和直接得到。这个打包结论没有同质量假设，没有来源密度帽，也未以体积代替来源质量。

**可测随机实现及未付费用。** 取可测版本后，按整数$k(x)$分层，令$\mathcal A_x$为样本有向非对角总和不超过$2\alpha k(k-1)$的事件。$k=1$时概率为1；其余由Markov至少为$1/2$。因此
\[
\mathcal K_x(d\mathbf A)=
\frac{1_{\mathcal A_x}(\mathbf A)P_x^{\otimes k(x)}(d\mathbf A)}
 {P_x^{\otimes k(x)}(\mathcal A_x)}
\]
是可测概率核，并且相对未条件化乘积核的密度至多2。按原索引删去坏行是可测映射，故获得可测的随机保留父族；没有声称确定性或历史可预测的选择。可将此概率核附于原记录的$x$之后，原记录边缘保持不变，新父没有原历史。

局部并集质量仍不能直接对$x$积分并反复使用同一个$W$。下一步需控制这个明确概率核诱导的全局来源列重复，而非再补可测性接口。所有条件化及删除费用（包括至多2的密度因子）必须保留。这是本轮正向几何结构的交付，不是完成全局预算。

## 不另乘带宽的整体充分条件

与(3)独立的一条整体桥是保持准确差值 $E_H-G_H\ge0$。若能证明
\[
E_H-G_H\le\theta E_H+B Y+
(1-\theta)\varepsilon^2 X^2/(NM),\quad 0\le\theta<1, \tag{5}
\]
其中 $B$对维度、尺度和历史一致，则(1)–(2)给
\[
Y^2\le\frac{4rS+B}{1-\theta}NM Y+\varepsilon^2X^2,
\quad
R\le\varepsilon X+\left[Sd+\frac{4rS+B}{1-\theta}N\right]W. \tag{6}
\]
推导只用非负根 $y^2\le ay+b^2\Rightarrow y\le a+b$。式(5)尚未证明；它保留联合能量可容许的二次误差，不能用粗带内帽替代。自然齐次预算为$S Y$或$S^2X$，不能把任意可变$S$藏成独立常数。

粗界 $D_j\le\min(1+n\log(b/a),1+L+\log r)$ 只推出 $E_H\le S(1+L+\log r)Y$。再用(1)得$Y\le SN(1+L+\log r)M$，当$L\sim\sqrt n$一般仍为线性费用。单交集核与平方交集核差一个$g_{AB}$，同带质量可比不能补这个因子。不同接受记录的阶段来源亦不可强行合并成同一条历史。

## 实跑、证据与研究决定

数值附件使用指定独立Python环境、SymPy与240位Arb，6个真实连续场、每场两种带宽，通过209项检查。三例一维完整$H$能量；三例扩维只核core子集下界，不声称完整$H$。集中一维例$E_H/X=1.491901\ldots$，只排除系数1。扩维$core$的高$D$伴随基底$W$快速增大，未逼近一般预算；因此不把这些模型当作式(5)的证据。加宽带降低选择损失同时提高能量，下一轮应检查同一原接受碰撞图的来源平均捕获，而不是孤立优化$N$。

互补附件给随机平移带的准确三角核和后验Hellinger差值身份；它使端点可核，但本身不付缺陷。数值证据、代数身份、一般核估计及条件性回代分列。文献定位没有核得可直接替换上述缺桥的带权极大定理。

## 完整母账

本轮尚未解决低平均捕获的完整原流，未消除原宽距离、低pe、初始、跳跃删除、未来被删来源、极小尺度比及全尺度拼接费用。第458轮母系数 $S\zeta+2S\varepsilon_0/s+2S\delta_{\rm round}$ 和全部旧乘数继续保留；式(6)的$\varepsilon$必须与其余吸收一起结算。没有一般证明，不宣称闭合。每轮单独提交，保留LaTeX源而不编译PDF；实际扣额数据不可得。
