# R475：Fefferman–Stein 文献接口

Luque–Parissis, *The endpoint Fefferman-Stein inequality for the strong maximal function*，原文 PDF 第4页（零基页码 P3）“Fefferman-Stein inequality”段转述经典 Hardy–Littlewood 估计：
\[
\int (Mg)^p w\lesssim_{n,p}\int |g|^p Mw,\qquad 1<p<\infty,
\]
对非负局部可积权 w 成立。这里 M 是全 Hardy–Littlewood maximal operator；该段是作者对经典结果的转述，不是原始证明。来源：[arXiv 原文 PDF](https://arxiv.org/pdf/1211.2950)。

取 g=1_E、w=f 后，得到相近形式 \(\int f(M1_E)^2\lesssim_{n,2}\int_E Mf\)。这没有给指定线性化 T 的估计：\(T^*1_E=D\)，而 M 是对所有立方体取上确界；并且 \(Tf\le Mf\) 只能给右侧反向比较，不能将 \(\int_E Mf\) 换成较小的 \(\int_E Tf\)。

本合同已有更直接且更强的占用帽：\(D(y)=\int_E1_{Q_A}(y)R_A^{-n}\,dA\le A_n:=1+n\log(b/a)\)（第474轮主稿§1；本轮主稿亦保留该定义）。由 Tonelli，
\[
\int f(T^*1_E)^2=\int fD^2\le A_n\int fD
=A_n\int_E Tf.
\]
故当前可用系数是 \(A_n\)，octave 时为 \(1+n\log 2\)，非 \(2^n\)。所核文献未提供把此系数进一步改善、同时将 maximal-function 右侧换成指定 \(Tf\) 的结果。
