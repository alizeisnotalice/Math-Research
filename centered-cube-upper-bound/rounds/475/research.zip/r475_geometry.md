# R475：带内来源亲和能量及原接受流的可付来源支

## 1. 同一输入与能量

沿 R474 原合同：\(\mu=f\,dx\)、\(\sigma(dA)=q_A\,dA\)、\(m_A=\mu(Q_A)=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(r=\lambda/q\)。原完整接受流为 \(\Pi\)，\(\Pi_A=t(A)\sigma(dA)\)，\(0\le t\le S\)。\(t\) 是实际父边缘；下面的正限制始终附在同一原记录上，不给代表父原历史。

令 \(J_1,\ldots,J_N\) 为完整质量区间的互不交带，\(H=\{D>d\}\)。定义
\[
 u_j(x)=\int_{m_A\in J_j}\frac{t(A)c_A(x)}{m_A}\sigma(dA),\quad
 u=\sum_j u_j,\quad e(x)=\sum_j u_j(x)^2.
\tag{1}
\]
原附源 \(x\sim\pi_A\) 的高占用质量为 \(R_{\rm hi}=\int_Hu\,d\mu\)，目标能量为 \(E=\int_He\,d\mu\)。其精确核是
\[
 E=\sum_j\int_{J_j\times J_j}
 t(A)t(B)\frac{I^H_{AB}}{m_Am_B}\,\sigma(dA)\sigma(dB),
 \quad I^H_{AB}=\mu(H\cap Q_A\cap Q_B).
\tag{2}
\]
这里是线性交叠 \(I^H\)，不能直接当作 R471 的平方交叠核。

## 2. 真实来源质量 CDF 给逐来源混合预算

置 \(\gamma_{AB}=I_{AB}/\sqrt{m_Am_B}\in[0,1]\)，其中 \(I_{AB}=\mu(Q_A\cap Q_B)\)。定义实际接受列的带内亲和能量
\[
 a(x)=\sum_j\int_{J_j\times J_j}
 \frac{t(A)t(B)c_A(x)c_B(x)}{m_Am_B}
 \gamma_{AB}\,\sigma(dA)\sigma(dB),
 \qquad v(x)=\int\frac{t(A)^2c_A(x)}{m_A}\sigma(dA).
\tag{3}
\]
以下界保留真实质量匹配，且没有带数或 stage 数因子：
\[
 \boxed{\quad0\le a(x)\le4r\,v(x)\le4rS\,u(x)\quad}
 \qquad(\mu\text{-a.e.}).
\tag{4}
\]

**证明。** 固定 \(x,m>0\)，真实中心 CDF 为
\(F_x(s)=|\{B:x\in Q_B,m_B\le s\}|\le s/q\)。非增函数
\[
 w_m(s)=\frac1s\sqrt{\frac{\min(m,s)}{\max(m,s)}}
\]
满足 \(\int_0^\infty w_m(s)ds=4\)，故包含质量原子的 Stieltjes 层饼给
\[
 \int\frac{c_B(x)}{m_B}\gamma_{AB}\,\sigma(dB)
 \le\lambda\int c_B(x)w_{m_A}(m_B)dB\le4r.
\tag{5}
\]
第一步只用 \(I_{AB}\le\min(m_A,m_B)\)。对每带的对称双积分用 \(2t(A)t(B)\le t(A)^2+t(B)^2\)，再用 (5)。每个 \(A\) 只属于一带，于是得到 \(a\le4rv\)，再由 \(t^2\le St\) 得 (4)。全过程未用来源密度帽，也未将选择器改成任意 incidence。

特别地，对任意可测来源集 \(B_0\)，包括由整个原场和 \(t\) 选出的集合，
\[
 \int_{B_0}a\,d\mu\le4r\int t(A)^2\pi_A(B_0)\sigma(dA)
 \le4rS\int_{B_0}u\,d\mu.
\tag{6}
\]
取 \(B_0=H\) 得真正 mixed-energy 价格 \(\int_Ha\le4rS R_{\rm hi}\)。这比先以全 \(H\) 上界再对小来源集使用更精确。

## 3. 作用于原流的无反馈 root 来源收据

固定 \(0<\rho\le1\)，令
\[
 H_\rho=\{x\in H:u(x)>0,\ a(x)\ge\rho e(x)\}.
\]
在此集，Cauchy 和 (4) 给
\[
 \frac{\rho}{N}u(x)^2\le\rho e(x)\le a(x)\le4rS u(x),
 \qquad u(x)\le\frac{4rSN}{\rho}.
\]
因此原 \(\Pi\) 附 \(x\sim\pi_A\) 后的实际正分数具有
\[
 \boxed{R_\rho:=\int\Pi(d\xi)\pi_A(H_\rho)
 =\int_{H_\rho}u\,d\mu
 \le\frac{4rSN}{\rho}\mu(H_\rho)\le\frac{4rSN}{\rho}W.}
\tag{7}
\]
不用 \(\eta R\) 反馈，不放大任何旧账。还得到同一集上的未加亲和能量
\(\int_{H_\rho}e\le4rS R_\rho/\rho\)。

与原低 \(D\) 分拆顺序使用，准确有
\[
 R\le\left(Sd+\frac{4rSN}{\rho}\right)W+R_{\rm bad},\qquad
 R_{\rm bad}=\int\Pi(d\xi)\pi_A(H\setminus H_\rho).
\tag{8}
\]
取带宽 \(L=\sqrt n\)，则
\(N\le1+(\log r+n\log(b/a))/\sqrt n\)。取 \(d=1+\sqrt n\)、\(\rho=1/2\)，本次两支总价为 \(S[d+8rN]W\)，固定 \(r\) 时为 root 阶，且没有新增 \(X\) 费用。

**准确范围。** (7) 是几何认证的原接受列低密度支：它证明 \(H_\rho\subset\{u\le4rSN/\rho\}\)，并未保证其占固定比例。若同一低 \(u\) 正分数此前已付，不能重复收费。剩余来源的同带接受父对虽然共同捕获 \(x\)，其全来源归一亲和平均低；\(u\gg N\) 时 (4) 本身就迫使该现象。完整 \(E\) 预算仍未证。

唯一未付步骤是对这些**实际接受权 \(t(A)t(B)\)** 下的低亲和来源，利用原双来源、严格质量门、时钟及删除结构取得整体费用，而非再删 \(t\) 为常数。原 high-rank/low-common 门作用于原 \(y,z\)，不能自动用于附加的 \(x\)。仅把 \(a\) 替换回 \(e\)，会遗漏恰好未受控制的一份交叠因子。原能量随 \(t\) 二次齐次；因此自然的统一 mixed 目标是 \(E\lesssim S R_{\rm hi}\)（或 \(S^2X\)），若写 \(CSX\) 且把 \(S\) 也视为自由参数，必须另说明常数依赖。

## 4. 自含本机精确检查

完整非均匀来源为三个长度 \(1/50\) 的 packet，中心 \(-4/5,0,4/5\)，质量 \((3,1,8)\)。两个正中心块长度 \(1/100\)，中心 \(-2/5,2/5\)，cube 边长 \(1,9/5\)，在块上恒定捕获前两/后两 packet。因此 \(m=(4,9)\)、\(q_A=(4,5)\)、\(r=5/4\)，是实际连续中心、完整来源积分。检查两种覆盖全父的质量带、三个静态接受权、三个辅助高占用阈值。有限场不认证原时钟或全部 hard gates；只核本证明通用的源列/能量及分拆接口。

```python
from fractions import Fraction as F
mu=(F(3),F(1),F(8));caps=((1,1,0),(0,1,1));m=(F(4),F(9))
rootm=(F(2),F(3));side=(F(1),F(9,5));vol=F(1,100)
sig=tuple(m[a]/side[a]*vol for a in range(2));r=F(5,4);S=F(1);W=sum(mu)
D=[sum(sig[a]*caps[a][x]/m[a] for a in range(2)) for x in range(3)]
I=[[sum(mu[x]*caps[a][x]*caps[b][x] for x in range(3)) for b in range(2)] for a in range(2)]
gamma=[[I[a][b]/(rootm[a]*rootm[b]) for b in range(2)] for a in range(2)]
checks=0
for x in range(3):
 for a in range(2):
  assert sum(sig[b]*caps[b][x]*gamma[a][b]/m[b] for b in range(2))<=4*r;checks+=1
for t in ((F(1),F(1,4)),(F(1,8),F(3,4)),(F(0),F(0))):
 for bins in ((0,0),(0,1)):
  N=max(bins)+1
  u=[];e=[];aff=[];v=[]
  for x in range(3):
   cols=[sum(sig[a]*t[a]*caps[a][x]/m[a] for a in range(2) if bins[a]==j) for j in range(N)]
   u.append(sum(cols));e.append(sum(z*z for z in cols))
   aff.append(sum(sig[a]*sig[b]*t[a]*t[b]*caps[a][x]*caps[b][x]*gamma[a][b]/(m[a]*m[b])
                  for a in range(2) for b in range(2) if bins[a]==bins[b]))
   v.append(sum(sig[a]*t[a]**2*caps[a][x]/m[a] for a in range(2)))
   assert 0<=aff[x]<=e[x];checks+=1
   assert aff[x]<=4*r*v[x]<=4*r*S*u[x];checks+=1
   assert u[x]**2<=N*e[x];checks+=1
  R=sum(sig[a]*t[a] for a in range(2))
  for d in (min(D)/2,min(D),max(D)):
   H=[D[x]>d for x in range(3)]
   Rhi=sum(mu[x]*H[x]*u[x] for x in range(3))
   assert sum(mu[x]*H[x]*aff[x] for x in range(3))<=4*r*S*Rhi;checks+=1
   assert R-Rhi<=S*d*W;checks+=1
   for rho in (F(1,4),F(1,2)):
    good=[H[x] and u[x]>0 and aff[x]>=rho*e[x] for x in range(3)]
    Rg=sum(mu[x]*good[x]*u[x] for x in range(3))
    Wg=sum(mu[x]*good[x] for x in range(3))
    Eg=sum(mu[x]*good[x]*e[x] for x in range(3))
    for x in range(3):
     if good[x]:assert u[x]<=4*r*S*N/rho;checks+=1
    assert Rg<=4*r*S*N*Wg/rho;checks+=1
    assert Eg<=4*r*S*Rg/rho;checks+=1
    Rbad=Rhi-Rg
    assert R<=S*d*W+4*r*S*N*Wg/rho+Rbad;checks+=1
print('PASS',checks,'Fraction native source-affinity/interface assertions; no full-history claim')
```

实际运行输出：

```text
PASS 244 Fraction native source-affinity/interface assertions; no full-history claim
```


## 5. 高实际接受占用迫使共同来源的质量打包

本节不分质量带。假设 \(S>0\)，固定满足 \(0<u(x)<\infty\) 的来源点。由实际接受父边缘定义概率核
\[
 P_x(dA)=\frac{t(A)c_A(x)}{m_Au(x)}\sigma(dA),\qquad
 \alpha_x=\frac{4rS}{u(x)},\qquad
 k(x)=\left\lfloor\frac{u(x)}{32rS}\right\rfloor.
\tag{14}
\]
式 (4) 的单带版本给
\[
 \mathbb E_{P_x\otimes P_x}\gamma_{AB}\le\alpha_x.
\tag{15}
\]
因此若 \(k\ge1\)，存在至少 \(k/2\) 个实际父 \(A_1,\ldots,A_l\)，都捕获同一 \(x\)，满足
\[
 \sum_{j\ne i}\gamma_{A_iA_j}\le\frac12\quad(1\le i\le l),
 \qquad
 \frac12 I\preceq (\gamma_{A_iA_j})_{i,j}\preceq\frac32 I,
\tag{16}
\]
以及真实完整来源质量的估计
\[
 \boxed{\quad
 \mu\!\left(\bigcup_{i=1}^lQ_{A_i}\right)
 \ge\frac23\sum_{i=1}^l m_{A_i}.
 \quad}
\tag{17}
\]
当 \(u(x)\ge64rS\) 时，\(l\ge u(x)/(128rS)\)。\(k=0\) 时结论为空；\(u=0\) 或 \(S=0\) 没有相应接受质量。

**证明。** 取 \(k\) 个独立 \(P_x\) 样本，令有向非对角总和
\(O=\sum_{i\ne j}\gamma_{A_iA_j}\)。其期望不超过
\(\alpha_x k(k-1)\)。对 \(k\ge2\)，Markov 给事件
\[
 O\le2\alpha_x k(k-1)
\tag{18}
\]
概率至少 \(1/2\)；\(k=1\) 则概率为一。这里只用两倍期望上界，未假设期望值可取到。删除原样本行和大于 \(1/2\) 的所有索引。若删除数为 \(d_k\)，则
\[
 d_k\le2O\le4\alpha_x k(k-1)
 \le\frac{k-1}{2}<\frac k2,
\tag{19}
\]
最后一步用 \(\alpha_x k\le1/8\)。保留后的行和只会减小。向量
\(e_A=c_A/\sqrt{m_A}\in L^2(\mu)\) 的 Gram 即 \(\gamma\)；对任意实系数用
\(2|z_iz_j|\le z_i^2+z_j^2\) 和行和帽得到 (16)。两份相同的归一化来源向量有亲和度一，不能同时保留。

再用 \(2\sqrt{m_im_j}\le m_i+m_j\)，得
\[
 \int\left(\sum_i c_{A_i}\right)^2d\mu
 =\sum_i m_i+\sum_{i\ne j}\sqrt{m_im_j}\gamma_{ij}
 \le\frac32\sum_i m_i.
\]
在真实并集上使用 Cauchy–Schwarz 即得 (17)。没有以边界体积估计来源质量。

**可测随机版本与费用边界。** 真实中心空间为标准 Borel 空间，\(P_x\)、\(u(x)\)、交叠积分均可测。按可测整数 \(k(x)\) 分层，在 \(P_x^{\otimes k}\) 下条件化于 (18)，然后按原索引实施上述删除，得到可测的随机打包核。成功概率 \(q(x)\ge1/2\)，故条件化密度因子不超过二；\(k=0,1\) 直接处理。不需要确定性可测选择定理。这里保留的父仅来自原实际接受父边缘的支持，不继承某条原记录的历史。

本结论将高 \(u\) 的困难具体化为：同一来源附近存在数量线性于 \(u/(rS)\) 的、来源质量几乎可加的真实父。它不是新的一笔 \(W\) 付款。不同 \(x\) 产生的并集与父可以重复，随机核的条件化因子二也不解决这种跨来源重复。因而本节不对逐点打包质量直接积分后宣称一次 \(W\) 价，不改变 §3 的已付支与完整未付补集。

### 本节有限有理核验

下面仅检验删行、Gram 与真实指标向量的质量并集代数，不声称这些有限来源向量来自原生高占用立方体场或完整历史。每个向量由一个共同原子及一个私有原子构成，质量均一；大样例另加入一个重复向量检验实际删除。共七个有限接口例。之前 §4 的 244 项原生静态场核验保持独立，不合并为原历史证据。

```python
from fractions import Fraction as F
checks=0; cases=0
for k in (2,4,8,16,32):
 for duplicate in ((False,True) if k>=16 else (False,)):
  alpha=F(1,8*k); common=F(1,32*k)
  labels=list(range(k))
  if duplicate: labels[1]=labels[0]
  G=[[F(1) if labels[i]==labels[j] else common
      for j in range(k)] for i in range(k)]
  rows=[sum(G[i][j] for j in range(k) if i!=j) for i in range(k)]
  O=sum(rows)
  assert O<=2*alpha*k*(k-1); checks+=1
  kept=[i for i in range(k) if rows[i]<=F(1,2)]
  assert k-len(kept)<=4*alpha*k*(k-1)<=F(k,2); checks+=1
  assert len(kept)>=F(k,2); checks+=1
  for i in kept:
   assert sum(G[i][j] for j in kept if i!=j)<=F(1,2); checks+=1
  assert len({labels[i] for i in kept})==len(kept); checks+=1
  for z in ([F(1) for i in kept],
            [F((-1)**i) for i in kept],
            [F(i+1,len(kept)) for i in kept]):
   norm=sum(a*a for a in z)
   quadratic=sum(z[a]*z[b]*G[i][j]
                 for a,i in enumerate(kept) for b,j in enumerate(kept))
   assert norm/2<=quadratic<=3*norm/2; checks+=1
  totalmass=F(len(kept))
  unionmass=common+len(kept)*(1-common)
  squaremass=common*len(kept)**2+len(kept)*(1-common)
  assert squaremass<=3*totalmass/2; checks+=1
  assert unionmass>=2*totalmass/3; checks+=1
  cases+=1
print('PASS',cases,'finite indicator-Gram cases;',checks,'Fraction assertions; no native high-occupancy/history claim')
```

实际运行输出：

```text
PASS 7 finite indicator-Gram cases; 169 Fraction assertions; no native high-occupancy/history claim
```
