# R475：平移质量窗中的单交集能量及保高来源门的平方核部分

本稿给出完整原父接受边缘上的随机平移恒等式，并证明其中一个正能量部分有维度无关价格。其余是准确的后验差异能量；尚无将它吸收的几何估计。因此不宣称完整原余项已付，也不把此正分解视作旧 BH 的负平方信用。

## 1. 原边缘不变，平移质量窗只作用于分析

沿 R474，\(\mu=f\,dx,\sigma=q_A dA,\pi_A=c_A\mu/m_A\)，
\(t(A)=\int\ell(A,y,z)\pi_A(dy)\pi_A(dz)\in[0,S]\) 是**完整原接受权**的父边缘。令 \(D(x)=\int c_A(x)d\sigma(A)/m_A\)，\(H=\{D>d\}\)，\(p_H(A)=\pi_A(H)\)，
\[
 R_{\rm hi}=\int t(A)p_H(A)d\sigma(A),\qquad R-R_{\rm hi}\le SdW.
\]
不将 \(t(A)\) 替代原记录中的 \(\ell(A,y,z)\)；以下只是这个准确父边缘的二次型。

取对数宽度 \(L>0\)，对 \(v\in[0,L)\) 均匀平移半开质量带，
\[
 J_{j,v}=\{A:jL+v\le\log(m_A/m_-)<(j+1)L+v\},\quad m_-=qa^n.
\]
\(m_+=\lambda b^n\)，令 \(N_*=2+\log(m_+/m_-)/L\)，每个平移的非空带数不超过 \(N_*\)。这稍宽的常数保留端点与原子；不以未平移最优分带的带数代替它。
定义 \(u_{j,v}(x)=\int_{J_{j,v}}t(A)c_A(x)d\sigma(A)/m_A\)，\(E_v=\int_H\sum_j u_{j,v}^2d\mu\)，\(\bar E=L^{-1}\int_0^L E_vdv\)。Tonelli 及区间重叠长度给
\[
 \bar E=\iint t(A)t(B)\frac{I_H(A,B)}{m_Am_B}
           \omega_L(A,B)d\sigma(A)d\sigma(B),                 \tag{1}
\]
\[
 I_H=\mu(H\cap Q_A\cap Q_B),\qquad
 \omega_L=\left(1-\frac{|\log m_A-\log m_B|}{L}\right)_+.
\]
端点平移对每对质量只有零测例外，故质量原子也符合 (1)。每个平移的来源 Cauchy–Schwarz 再平均得到
\[
 R_{\rm hi}^2\le N_*\mu(H)\bar E.                            \tag{2}
\]
随机化没有重建来源、时钟或历史，也没有收取每个平移的额外费用。

## 2. 平方交集核能支付哪一部分

置 \(I_{AB}=\mu(Q_A\cap Q_B)\)、\(g_{AB}=I_{AB}/\sqrt{m_Am_B}\in[0,1]\)。式 (1) 的核是**单交集** \(I_H/(m_Am_B)\)，不能直接套 R472 的平方交集行界。准确正分解为
\[
 \bar E=G+V,
\quad G=\iint t_At_B\omega_L
             \frac{I_{AB}I_H}{(m_Am_B)^{3/2}}d\sigma^2,
\]
\[
 V=\iint t_At_B\omega_L\frac{I_H}{m_Am_B}(1-g_{AB})d\sigma^2.
                                                               \tag{3}
\]
使用已证带来源权 \(b=1_H\) 的真实行界
\[
 \int\frac{I_{AB}I_H}{(m_Am_B)^{3/2}}d\sigma(B)
              \le4r p_H(A),
\]
由对称性、\(2t_At_B\le t_A^2+t_B^2\)、\(0\le\omega_L\le1\)，严格得到
\[
 \boxed{G\le4r\int t(A)^2p_H(A)d\sigma(A)
                 \le4rS R_{\rm hi}.}                         \tag{4}
\]
这里没有质量带数、阶段数或来源平方总质量；也没有以 operator norm 冒充 HS/trace 范数。

剩余 \(V\) 的几何内容不是新的任意权：
\[
 1-g_{AB}=\frac12\int
 \left(\frac{c_A(x)}{\sqrt{m_A}}-
       \frac{c_B(x)}{\sqrt{m_B}}\right)^2d\mu(x).              \tag{5}
\]
它是两个实际父来源后验之间的 Hellinger 差异，乘以原接受父边缘、真实高来源交集及质量窗。可进一步保真实差集质量，但不能换成边界体积。式 (5) 没有证明其价格小；它尤其不是可以再次从原 BH 扣除的一笔负能量。

## 3. 完整条件回代及当前停止点

以下给出需要验证的比较的**正确尺度**，而非声称它成立。若同一原边缘满足
\[
 V\le\eta\bar E+C S R_{\rm hi}
          +\frac{\delta X^2}{N_*W},\qquad0\le\eta<1,          \tag{6}
\]
则由 (2)–(4)、\(\mu(H)\le W\)，
\[
 R_{\rm hi}^2\le
 \frac{(4r+C)SN_*W}{1-\eta}R_{\rm hi}
 +\frac{\delta}{1-\eta}X^2.
\]
因此（\(W=0\) 时全零，另行约定）
\[
 \boxed{R\le SdW+
       \frac{(4r+C)SN_*W}{1-\eta}
       +\sqrt{\frac\delta{1-\eta}}X.}                         \tag{7}
\]
取 \(d,L\asymp\sqrt n\)、固定 \(r\)，并令 \(\delta\le(1-\eta)\varepsilon^2\)，才得到目标量级。这里给出全部恢复费用，未把 (6) 当成定理。

本次没有证明 (6)。随机平移仅改变带的硬边界，不压低单交集能量。当 \(L\le\log K\)，\(\omega_L>0\) 只连接 \(m_A/K<m_B<Km_A\)；原 high-\(Z\)/low-\(C\) 门则控制各自严格较小质量的接收者。因而它们不会直接约束 (5) 中的可比质量父差异。欲用原门，需要一个保原 \(\ell\) 的联合几何比较，把可比父之间这种差异与各自更小质量见证联系；当前合同未给出该比较。父边缘乘积只是准确能量的换序，不能将其中一个父的历史交给另一个。

已有粗窗容量只能给 \(\bar E\lesssim S(1+L+\log r)R_{\rm hi}\)，恢复后 \(N_*L\asymp n\)。本稿不把这称为改善，也没有新阈值分支或未付项更名后声称闭合。可保留的准确进展是 (4) 的全带高来源加权价格，以及 (6)–(7) 明确的恢复尺度；其余停止在上述具体几何比较。

## 4. 实际有限验证

下列标准库 Fraction 脚本实际运行输出：

```text
PASS 54 Fraction assertions; shifted-window and high-source-weighted energy algebra only
```

质量为 \(1,4,16\)，对数坐标用 \(\log4\) 为单位；宽度为2，该例平移核在两个等长区间上常数，故两个中点是**精确积分**，不是随机近似。三种来源门、三种接受父边缘核对 (1)–(5) 和来源 Cauchy–Schwarz。脚本只用该有限模型实际算出的加权行常数，不冒称验证真实几何常数 \(4r\)。这是有限 incidence 代数，不是原连续场或历史认证。

```python
from fractions import Fraction as F
mu=[F(1),F(3),F(12)];sig=[F(1,3),F(1,4),F(1,5)]
c=[[1,0,0],[1,1,0],[1,1,1]];m=[F(1),F(4),F(16)];rt=[F(1),F(2),F(4)]
D=[sum(sig[A]*c[A][x]/m[A] for A in range(3)) for x in range(3)]
I=[[sum(mu[x]*c[A][x]*c[B][x] for x in range(3)) for B in range(3)] for A in range(3)]
g=[[I[A][B]/(rt[A]*rt[B]) for B in range(3)] for A in range(3)]
checks=0
for A in range(3):
 for B in range(3):
  metric=sum(mu[x]*(F(c[A][x],rt[A])-F(c[B][x],rt[B]))**2 for x in range(3))/2
  assert metric==1-g[A][B];checks+=1
  assert 0<=g[A][B]<=1;checks+=1
for d in [F(0),min(D),max(D)]:
 p=[sum(mu[x]*c[A][x] for x in range(3) if D[x]>d)/m[A] for A in range(3)]
 IH=[[sum(mu[x]*c[A][x]*c[B][x] for x in range(3) if D[x]>d) for B in range(3)] for A in range(3)]
 hh=[[I[A][B]*IH[A][B]/(m[A]*m[B]*rt[A]*rt[B]) for B in range(3)] for A in range(3)]
 row=max([sum(sig[B]*hh[A][B] for B in range(3))/p[A] for A in range(3) if p[A]]+[F(0)])
 for t in [[F(1)]*3,[F(1,4),F(1),F(1,2)],[F(0)]*3]:
  Eavg=F(0)
  for shift in [F(1,2),F(3,2)]:
   bins=[int((F(A)-shift)//2) for A in range(3)]
   E=sum(mu[x]*sum(sum(t[A]*c[A][x]*sig[A]/m[A] for A in range(3) if bins[A]==j)**2 for j in set(bins)) for x in range(3) if D[x]>d)
   Eavg+=E/2
  Eker=Eaff=Edef=F(0)
  for A in range(3):
   for B in range(3):
    omega=max(F(0),1-F(abs(A-B),2))
    v=sig[A]*sig[B]*t[A]*t[B]*IH[A][B]/(m[A]*m[B])*omega
    Eker+=v;Eaff+=v*g[A][B];Edef+=v*(1-g[A][B])
  assert Eavg==Eker;checks+=1
  assert Eker==Eaff+Edef;checks+=1
  assert Eaff<=row*sum(sig[A]*t[A]**2*p[A] for A in range(3));checks+=1
  Rhi=sum(sig[A]*t[A]*p[A] for A in range(3))
  WH=sum(mu[x] for x in range(3) if D[x]>d)
  assert Rhi**2<=3*WH*Eker;checks+=1
print('PASS',checks,'Fraction assertions; shifted-window and high-source-weighted energy algebra only')
```
