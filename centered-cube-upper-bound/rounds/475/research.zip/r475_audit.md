# R475 FINAL PASS（限定局部亲和预算、可测共同来源 packing 及条件回代）

先独立预审，再审冻结作者稿和主稿。通过下述一般几何/测度结果及有限复现；未证明低平均亲和原流的完整预算、packing 核的跨来源共享列价或一般根阶闭合。原接受权、历史、完整补集和旧母账继续保留。

1. **联合能量与接收限制。** (E_H) 的精确核为一次交叠 (I^H_{AB}/(m_Am_B))，不是已证平方核。(Y^2\le N\mu(H)E_H) 以及 (D_j\le\min(A_n,1+L+\log r)) 的质量/边长换算正确，固定边长基项及质量原子保留。混合能量通过 (I_{AB}I^H_{AB}/(m_Am_B)^{3/2}) 的真实来源加权行界得到 (G_H\le4r\int t^2p_Hd\sigma\le4rSY)，不收阶段数或带数。一次与二次核间缺失的 (g_{AB}) 未被同带质量可比性免费补上。

2. **局部化与实际可付来源支。** 同一固定 (t) 下，对任意来源集合应用加权行界合法；由测度支配得逐点 (v\le4rSu)，且 (v\le e)、(e\ge u^2/N)。故高平均捕获 (v\ge\rho e) 的附源正分数确有 (u\le4rSN/\rho)，价 (4rSN\mu(H_\rho)/\rho)，无需反馈。它是原接受列的低 (u) 类，不能与已付低 (u) 支重复收款。真正很大的 (u) 自动迫使低平均捕获；剩余低亲和类完整保留，没有固定比例保证。集合是固定输入上的事后可测分析，不声称原时钟下的非前视控制或把原历史交给代表父。

3. **共同来源的随机 packing。** 不分带时，真实父后验 (P_x=t(A)c_A(x)d\sigma/(m_Au)) 给 (mathbb E g\le\alpha=4rS/u)。在 (S>0,u\ge32rS) 上，(k=\lfloor1/(8\alpha)\rfloor\ge1)；(k\ge2) 的两倍期望事件概率至少 (1/2)，(k=1) 单独处理。删去原 row-off (>1/2) 的索引后，删除数 (\le4\alpha k(k-1)\le(k-1)/2)，保留至少 (k/2)。Gram 谱 ([1/2,3/2])、真实 (mu)-union (\ge(2/3)\sum m_A) 以及 (u\ge64rS) 时数量下界均正确。中心/selector/权取不改变相关积分的 Borel 版本后，按整数 (k) 分层的显式条件乘积核可测，条件化密度帽2保留；不需要确定性选择定理。它可作为原附源后的概率扩充，但辅助父不获原 history。逐 (x) 的 union 价不可跨 (x) 重复当作一次 (W)，该具体核的全局列重复仍未付。

4. **缺陷、随机窗与完整回代。** 随机平移质量窗的三角核、稍宽端点数 (N_*=2+\log(m_+/m_-)/L) 及 (ar E=G+V) 正分解正确；(1-g) 为真实完整来源后验的 Hellinger 差，不是旧 BH 的可重扣信用。main 的整体条件以 (M>0) 使用，预算常数 (B) 取非负（可无损放大），则 (a=(4rS+B)/(1-\theta)\ge0)，根式比较及 (Y\le aNM+\varepsilon X) 的费用正确。complement 的 (\delta X^2/(N_*W)) 条件及 (\sqrt{\delta/(1-\eta)}X) 系数也正确，(W=0) 全零另处理。两份条件均未被称为已证估计，S齐次性、低 (D) 费用及全部母倍率未隐藏。

5. **证据与文献范围。** 三个1D场计算完整高占用集，三个扩维场只算 core 能量下界；真实完整质量与径向 shell 积分正确，不能由 core 下界证明或否定全 (H) 常数界。packing 的7个有限指标例不认证原生高占用 cube/history。文献附件的经典 Hardy–Littlewood 转述已对照 [Luque–Parissis 原 PDF 第4页](https://arxiv.org/pdf/1211.2950)；它不提供将 maximal-function 右侧换成指定 (Tf) 的所需预算，亦未进入本轮证明。已有 (D\le A_n) 的 (\int fD^2\le A_nX) 接口及比较方向正确。

## 独立隔离复现

指定本机 Python；目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r475_audit_quy585ha`。提取 geometry 两块、complement 一块并运行 numeric.py：244、169、54、209项分别通过，四份 stdout 与冻结 replay 逐字节一致。numeric JSON 仅删除 `compute_index.seconds` 后完全一致；规范化 SHA256 为 `bddcaf62cfde654af63dd44d38207876b6b8cbf7e9a494d376bd6b7cd846603f`。有限断言不当独立原历史实例，PRE两组辅助代数不加入归档统计。

## 冻结输入 SHA256

- `r475_main.md`: `4de3d3ad5918ec74839d768d01c93440c29e9dd6730f4dc923b0a957ce2e4d45`
- `r475_geometry.md`: `230adb9c8b9651307887c3b22471d2d620639092a850091340afe74dd53a5854`
- `r475_complement.md`: `980468b377aecff3b03d4301895cdda04ce1ee045d5242a4b08a3245d1b70a4b`
- `r475_numeric.md`: `b266beae378bc717a809d9c4048bc60250992b97bcc277ba1aaaf04320be61c2`
- `r475_numeric.py`: `b74539dc711b845753a534e8022707b4c09ab841acdfff2ade3c9071bd90ab9d`
- `r475_numeric.json`: `a02ee40002c39a40cb5d3e09a0b32351cbad1ac6df02855d3008af29e4c0298a`
- `r475_replay.json`: `4e41dbd9c884a1179d6d659f966e04aacfbbaf9574f786d1087e9823641f408f`
- `r475_literature.md`: `265e5ccebe3e80496a28cf99c5db15b4d0eadc42d82eabce49108ce14f6e1c47`
