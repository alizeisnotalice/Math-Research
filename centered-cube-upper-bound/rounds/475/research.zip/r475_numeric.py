from fractions import Fraction as Q
from pathlib import Path
from math import comb
import json,sys,platform,time
import sympy as sp
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=240
start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def ar(v):
 v=Q(v);return arb(v.numerator)/v.denominator

def val(v):return str(v)
def shell(n,e,lo,hi):
 ans=n*(hi/lo).log()
 for k in range(1,n):ans+=ar(-Q(n*comb(n-1,k),k)*(-2*e)**k)*(hi**(-k)-lo**(-k))
 return ans

# Exact symbolic derivative of all radial-shell primitives actually used.
r=sp.symbols('r',positive=True)
for n in (1,2,4,8):
 e=Q(1,20*n);ee=sp.Rational(e.numerator,e.denominator)
 prim=n*sp.log(r)+sum(-sp.Rational(n*comb(n-1,k),k)*(-2*ee)**k*r**(-k) for k in range(1,n))
 ck(sp.cancel(sp.diff(prim,r)-n*(r-2*ee)**(n-1)/r**n)==0)

cases=[]
parameters=[('initial',1,Q(1,20),Q(1)),('concentration_pressure',1,Q(1,20),Q(16)),('narrow_core_pressure',1,Q(1,100),Q(4))]+[('dimension_expanded',n,Q(1,20*n),Q(1)) for n in (2,4,8)]
for phase,n,e,M in parameters:
 c0=1-2*e;H=M+(2*e)**n;vol=(2-2*e)**n;W=(4-2*e)**n+M
 ck(0<e<Q(1,2));ck(c0>0)
 # For central and radial pieces every actual cube contains core, and
 # is contained in base support in each coordinate. Check extremal bounds.
 for s in [Q(0),Q(1,2)-e,1-e]:
  R=max(Q(1),2*(s+e));ck(1<=R<=2);ck(s-R/2<=-e);ck(s+R/2<=2-e)
 qlo=1+M/Q(2**n);qhi=1+M;ratio=qhi/qlo
 ck(1<ratio<2 if M==1 else ratio>1)
 D=ar(c0**n)+shell(n,e,arb(1),arb(2));An=1+n*arb(2).log()
 ck(D>ar(Q(3,2)));ck(D<An)
 X=ar(vol)+ar(M)*D;Rcore=ar(H)*D
 ck(Rcore<X)
 row=dict(phase=phase,n=n,eta=str(e),M=str(M),q_min=str(qlo),q_max=str(qhi),r=str(ratio),W=str(W),core_mass=str(H),center_volume=str(vol),D_core=val(D),An=val(An),X=val(X),X_over_W=val(X/ar(W)),core_load_over_X=val(Rcore/X),scope='FULL H={D>3/2} energy' if n==1 else 'CORE SUBSET ONLY: lower bound on H={D>3/2} energy; no full-H integration',bands=[])
 if n==1:
  Dout=ar(c0)+arb(2).log()/2;ck(Dout<ar(Q(3,2)))
  row['outside_essential_D_max']=val(Dout)
 for label,L in [('L=1',arb(1)),('L=sqrt(n)',arb(n).sqrt())]:
  # Bands start at actual q*a^n, not at actual minimum mass.
  # This retains empty low bands in the prescribed complete interval.
  top=ar(qhi*Q(2**n));base=ar(qlo);low=base;Ds=[];indices=[];j=0
  while low<top:
   high=base*((j+1)*L).exp()
   if high>top:high=top
   mlo=ar(M+1) if low<ar(M+1) else low
   mhi=ar(M+2**n) if high>ar(M+2**n) else high
   if mlo<mhi:
    rl=(mlo-ar(M))**(arb(1)/n);rh=(mhi-ar(M))**(arb(1)/n)
    # Exact endpoints are inserted instead of an interval exponent there.
    if mlo==ar(M+1):rl=arb(1)
    if mhi==ar(M+2**n):rh=arb(2)
    dj=shell(n,e,rl,rh)
    # Assign the R=1 atom by the fixed half-open mass convention.
    if low<=ar(M+1) and high>ar(M+1):dj+=ar(c0**n)
    ck(dj>0);Ds.append(dj);indices.append(j)
   low=base*((j+1)*L).exp();j+=1
   ck(j<100)
  ck((sum(Ds,arb(0))-D).contains(0))
  mx=max(Ds);en=ar(H)*sum((z*z for z in Ds),arb(0));T=ar(H)*mx
  ck(en>0)
  if len(Ds)==1:ck((T-Rcore).contains(0))
  else:ck(T<Rcore)
  if j==1:ck((T*j-Rcore).contains(0))
  else:ck(T*j>Rcore)
  ck(en<=An*X)
  row['bands'].append(dict(label=label,L=val(L),complete_interval=[str(qlo),str(qhi*Q(2**n))],total_band_count=j,nonempty_core_band_indices=indices,D_j_core=list(map(val,Ds)),sumD=val(sum(Ds,arb(0))),maxD_over_L=val(mx/L),core_energy=val(en),core_energy_over_X=val(en/X),core_energy_over_LX=val(en/(L*X)),core_selected_T=val(T),core_retention_fraction=val(T/Rcore),inverse_retention_loss=val(Rcore/T),effective_energy_band_count=val(D*D/sum((z*z for z in Ds),arb(0))),whole_H_energy_upper_AnX=val(An*X)))
 cases.append(row)
result=dict(scope='Six actual continuous cube fields, static t=S=1. No original gates/history. n=1 full high-D energy; n>1 core lower bound only.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,seconds=time.perf_counter()-start,command='"'+sys.executable+'" r475_numeric.py'),checks=checks,cases=cases,errors='Exact rational geometry, SymPy shell derivatives. All logarithms/exponentials/band endpoints and diagnostics enclosed by 240-bit Arb; no Monte Carlo or numerical quadrature.')
(ROOT/'r475_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'checks; 6 continuous static fields, 2 band widths each; n>1 core lower bounds only')
