"""R722 capped law: exact pivots, pair columns, truncated global inequality.

Only audit.json is created. Local Fraction/Arb384; remote exact Fraction and
Decimal110 crosscheck when available, otherwise an explicitly local fallback.
"""
from fractions import Fraction as F
from pathlib import Path
from random import Random
import hashlib,json,platform,socket,subprocess,sys


def fixtures():
    out=[];rng=Random(72220261118)
    # Repeated volumes exercise inclusive upper versus strict upper conventions.
    out.append(('tied_pivot',[F(1),F(2),F(2),F(8)],[F(1,8),F(1,16),F(1,16),F(1,8)],[(F(1),[0,1,2,3])],{}))
    for j in range(40):
        N=rng.randrange(2,8);G=rng.randrange(1,9)
        d=[F(rng.randrange(1,8),1<<rng.randrange(0,4)) for i in range(N)]
        theta=[F(rng.randrange(1,6),16) for i in range(N)]
        if sum(theta)<F(1,4):theta[0]+=F(1,4)
        groups=[]
        for g in range(G):
            pool=[i for i in range(N) if rng.randrange(2)]
            for i in sorted(range(N),key=lambda i:-theta[i]):
                if sum((theta[k] for k in pool),F(0))>=F(1,4):break
                if i not in pool:pool.append(i)
            groups.append((F(rng.randrange(1,9),8),pool))
        out.append((f'rational_{j}',d,theta,groups,{}))
    for b in [32,48,64]:
        for layout in ['shared_ordinary','private_ordinary']:
            for value in ['unit_value','huge_value']:
                G=16;epsilon=F(1,1<<(2*b));giant=F(1<<(2*b if value=='unit_value' else 4*b))
                d=[giant]+[F(1)]*(1 if layout=='shared_ordinary' else G)
                theta=[epsilon]+[F(1,4)]*(len(d)-1)
                groups=[(F(1,G),[0,1 if layout=='shared_ordinary' else g+1]) for g in range(G)]
                out.append((f'rare_giant_{b}_{layout}_{value}',d,theta,groups,
                            {'ambient_n_symbolic':f'2^{b}','layout':layout,'giant_theta_exact':str(epsilon),'giant_volume_exact':str(giant),
                             'scope':'Abstract paired graph; ambient n labels parameter sizes, not a constructed cube history.'}))
    return out


def exact_case(fixture):
    name,d,theta,groups,meta=fixture;p=F(1,8);a=[x*y for x,y in zip(d,theta)]
    capped=[];value=[];Zs=[];Cs=[];pivots=[];terms=[]
    for mass,pool in groups:
        Q=sum((theta[i] for i in pool),F(0));assert Q>=F(1,4)
        cumulative=F(0)
        for C in sorted({d[i] for i in pool},reverse=True):
            cumulative+=sum((theta[i] for i in pool if d[i]==C),F(0))
            if cumulative>=p:break
        inclusive=sum((theta[i] for i in pool if d[i]>=C),F(0))
        strict=sum((theta[i] for i in pool if d[i]>C),F(0))
        assert inclusive>=p and strict<=p
        alternatives=[]
        for alternative in sorted({d[i] for i in pool}):
            inc=sum((theta[i] for i in pool if d[i]>=alternative),F(0))
            above=sum((theta[i] for i in pool if d[i]>alternative),F(0))
            if inc>=p and above<=p:
                zalt=sum((a[i]*min(F(1),alternative/d[i]) for i in pool),F(0))
                assert zalt>=p*alternative
                alternatives.append({'C':str(alternative),'strict_upper_theta':str(above),'Z_over_C':str(zalt/alternative)})
        u={i:min(F(1),C/d[i]) for i in pool}
        Z=sum((a[i]*u[i] for i in pool),F(0));Dg=sum((a[i] for i in pool),F(0))
        assert Z>=p*C
        q={i:a[i]*u[i]/Z for i in pool};v={i:a[i]/Dg for i in pool}
        assert sum(q.values())==1
        capped.append(q);value.append(v);Zs.append(Z);Cs.append(C)
        terms.append({i:mass*u[i]/Z for i in pool})
        pivots.append({'C':str(C),'Q':str(Q),'inclusive_upper_theta':str(inclusive),'strict_upper_theta':str(strict),
                       'Z_over_C':str(Z/C),'Z_ge_pC':True,'all_admissible_observed_pivots_checked':alternatives})
    capmax=valuemax=F(0)
    for g in range(len(groups)):
        for h in range(len(groups)):
            for i in capped[g].keys()&capped[h].keys():
                actual=capped[g][i]*capped[h][i]/a[i]
                bound=theta[i]/(p*p*d[i])
                assert actual<=bound
                capmax=max(capmax,actual/bound);valuemax=max(valuemax,(value[g][i]*value[h][i]/a[i])/bound)
    eps=max(v for row in terms for v in row.values());lam=F(25,16)*eps
    L=[sum((row.get(i,F(0)) for row in terms),F(0)) for i in range(len(d))]
    M=sum((m for m,pool in groups),F(0));D=sum(a,F(0))
    assert sum((aa*ll for aa,ll in zip(a,L)),F(0))==M
    tail=F(0);high=[]
    for i,load in enumerate(L):
        cross=load*load-sum((row.get(i,F(0))**2 for row in terms),F(0))
        assert cross>=0
        if load>lam:
            assert load-lam<=cross/(4*eps)
            tail+=a[i]*cross;high.append(i)
    RHS=lam*D+tail/(4*eps)
    assert M<=RHS
    result={'name':name,'p_exact':str(p),'sources':len(d),'groups':len(groups),'metadata':meta,
            'pivots':pivots,'max_capped_pair_over_bound_exact':str(capmax),
            'max_value_bias_pair_over_same_bound_exact':str(valuemax),
            'M_exact':str(M),'D_exact':str(D),'epsilon_exact':str(eps),'lambda_exact':str(lam),
            'high_columns':high,'lambda_D_exact':str(lam*D),'truncated_cross_tail_exact':str(tail),
            'global_RHS_exact':str(RHS),'global_gap_exact':str(RHS-M),'mass_identity_exact':True}
    if meta:
        result['giant_capped_probability_exact']=str(capped[0][0])
        result['giant_value_bias_probability_exact']=str(value[0][0])
        result['giant_probability_reduction_factor_exact']=str(value[0][0]/capped[0][0])
    return result


def decimal_checks():
    from decimal import Decimal as D,localcontext
    with localcontext() as c:
        c.prec=110;real=[];support=[]
        for b in [32,48,64]:
            n=1<<b;a=32*n;root=1<<(b//2);l2=D(2).ln();t=D(root)/l2
            lh=(1+D(1)/a).ln();g=(1-D(2)/a).ln();Q=(D(n-1)*g).exp();W=(1-Q)/8+Q/a
            JA=int(D(root)/W);cstar=-t*(1-D(1)/8).ln();ell=int(cstar/W)
            before=1-(-D(ell)*W/t).exp();lp=D(n)*g-W/t
            fd=(1-(-W/t).exp())/(1-lp.exp())
            zratio=before+(-D(ell)*W/t).exp()*fd
            real.append({'b':b,'ell':str(ell),'values':[str(zratio),str((D(1)/8/zratio)**2),str((D(1)/8/fd)**2)]})
        for b in [12,16,24,32,48,64]:
            n=1<<b;l2=D(2).ln();L=D(b)*l2;h=1+D(1)/(32*n);q=h*(l2/n).exp()
            bins=int(4*D(n)*D(n+1).ln())+1
            logfactor=l2+D(n)*(2+q).ln()
            combined=D(bins).ln()+logfactor-2*D(n)*l2
            support.append({'b':b,'values':[str(logfactor),str(combined)]})
        return {'host':socket.gethostname(),'python':sys.version,'real':real,'support':support}


if '--remote' in sys.argv:
    print(json.dumps({'exact_cases':[exact_case(x) for x in fixtures()],'numbers':decimal_checks()}))
    raise SystemExit(0)


from flint import arb,ctx
BASE=Path(__file__).resolve().parent
def st(x):return x.str(38)
def floor_unique(x):
    v=x.floor().unique_fmpz();assert v is not None
    return int(v)


def real_case(b,bits):
    ctx.prec=bits;A=arb;n=1<<b;a=32*n;root=1<<(b//2);l2=A(2).log();t=A(root)/l2;p=A(1)/8
    g=(-A(2)/a).log1p();Q=((n-1)*g).exp();W=-((n-1)*g).expm1()/8+Q/a
    JA=floor_unique(A(root)/W);eA=root-JA*W;ell=floor_unique((-t*(-p).log1p())/W)
    assert ell<JA
    strict=-(-ell*W/t).expm1();inclusive=-(-(ell+1)*W/t).expm1()
    assert strict<=p and inclusive>=p
    lp=n*g-W/t
    def fd(count,last):return (-(-W/t).expm1())*(-(count*lp).expm1())/(-lp.expm1())+(count*lp).exp()*(-(-last/t).expm1())
    Z_over_C=strict+(-ell*W/t).exp()*fd(JA-ell,eA)
    assert Z_over_C>=p
    fullDA=fd(JA,eA)
    capmax=(p/Z_over_C)**2;value_max=(p/fullDA)**2
    assert capmax<=1 and value_max>1
    first_mass=-(-W/t).expm1()
    capped_first=first_mass/Z_over_C;value_first=first_mass/fullDA
    return {'b':b,'n':f'2^{b}','actual_pool':'original A half-crossing pool of the genuine R715/R717 histories',
            'distinct_real_group_interpretation':'Any two distinct retained receiving owners have this same A pool and hence these same capped pair coefficients.',
            'actual_Q_exact':'1/2','p_exact':'1/8','t_definition':'sqrt(n)/log2','pivot_shell_index':str(ell),
            'pivot_C_formula':'2^n*(RA*rho^ell)^n; works for every K4,8,16 scaling of this actual A pool',
            'strict_upper_theta':st(strict),'inclusive_upper_theta':st(inclusive),'Z_over_C':st(Z_over_C),
            'max_capped_pair_over_bound':st(capmax),'max_value_bias_pair_over_same_bound':st(value_max),
            'first_full_shell_capped_probability':st(capped_first),'first_full_shell_value_bias_probability':st(value_first),
            'actual_pair_improvement_factor':st(value_max/capmax),'precision_bits':bits,
            '_values':(Z_over_C,capmax,value_max)}


def support_case(b,bits):
    ctx.prec=bits;A=arb;n=1<<b;l2=A(2).log();L=b*l2;h=1+A(1)/(32*n);q=h*(l2/n).exp()
    bins=floor_unique(4*n*A(n+1).log())+1
    logfactor=l2+n*(2+q).log();combined=A(bins).log()+logfactor-2*n*l2
    assert combined<-A(n)/4
    return {'b':b,'n':f'2^{b}','bin_count_coarse_upper':str(bins),
            'support_volume_bound_formula':'2*B*(2+h*2^(1/n))^n',
            'log_support_volume_over_B':st(logfactor),
            'log_bins_times_4_minus_n_times_support_over_B':st(combined),
            'combined_at_most_exp_minus_n_over_4':True,'precision_bits':bits,'_values':(logfactor,combined)}


def main():
    exact=[exact_case(x) for x in fixtures()];real=[];support=[]
    for b in [32,48,64]:
        lo=real_case(b,256);hi=real_case(b,384)
        for x,y in zip(lo['_values'],hi['_values']):assert x.overlaps(y)
        hi['_check']=[float(x) for x in hi['_values']];del hi['_values'];real.append(hi)
    for b in [12,16,24,32,48,64]:
        lo=support_case(b,256);hi=support_case(b,384)
        for x,y in zip(lo['_values'],hi['_values']):assert x.overlaps(y)
        hi['_check']=[float(x) for x in hi['_values']];del hi['_values'];support.append(hi)
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    run=subprocess.run(command,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=40)
    remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
    if run.returncode==0:check=json.loads(run.stdout);remote['result']=check
    else:check={'exact_cases':[exact_case(x) for x in fixtures()],'numbers':decimal_checks()};remote['local_fallback']=check
    assert exact==check['exact_cases']
    for left,right in [(real,check['numbers']['real']),(support,check['numbers']['support'])]:
        for local,other in zip(left,right):
            assert local['b']==other['b']
            for x,y in zip(local['_check'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
    remote['independent_crosscheck_passed']=True
    for row in real+support:del row['_check']
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'exact_cases':exact,
            'genuine_A_cases':real,'support_cases':support,'remote':remote,
            'exact_proofs':['Choose observed-volume pivot C with theta mass at d>=C at leastp, and at d>C at mostp. Then Z=sum theta*d*min(1,C/d)>=p*C.',
                            'q_gi=theta_i*d_i*u_gi/Zg. Thus q_gi*q_hi/(d_i theta_i)=d_i theta_i u_gi u_hi/(Zg Zh)<=theta_i/(p^2 d_i). Every finite pair, including diagonal pairs, is checked exactly.',
                            't_gi=m_g u_gi/Zg, Li=sum_g t_gi, epsilon=max t_gi. Exact mass identity is M=sum_i a_i Li, a_i=d_i theta_i. Let lambda=25epsilon/16, whose denominator(sqrt(lambda)+sqrt(lambda-epsilon))^2=4epsilon exactly.',
                            'For Li>lambda, Li-lambda<=sum_{g!=h}t_gi t_hi/(4epsilon). Therefore M<=lambda D+sum_{Li>lambda}a_i sum_{g!=h}t_gi t_hi/(4epsilon). The truncation and all contributions are exact Fractions.',
                            'Indeed sum_{g!=h}t_gi t_hi>=Li(Li-epsilon), and Li(Li-epsilon)-4epsilon(Li-lambda)=(Li-5epsilon/2)^2>=0 for lambda25epsilon/16.',
                            'For the true A shell pool, theta mass is sorted by physical source volume. The quantile layer is floor(-t log(1-p)/W). Its actual C and complete/partial layer sums give Z/C exactly by positive geometric formulas.'],
            'scope':['The53 rational and rare-giant graphs are algebraic stress tests, not cube histories. The three genuine A pools are compressed actual histories valid at every earlier K4,8,16 parameter; no source coefficient is fabricated.',
                     'The cap can greatly reduce rare giant-source probability and the normalized pair column compared with value bias. These finite tests do not prove a general optimized allocation bound.',
                     'The support-volume formula is tested as the specified geometric upper bound. Multiplication by a coarse O(n log n) bin count and4^-n is certified<=exp(-n/4) in all six dimension ranges.',
                     'The separate new primary single-bin proof is not claimed here; its required upper tail is STRICTLY higher bins, so the terminal first-cross bin itself is excluded from that upper-tail sum.',
                     'Exact Fraction comparisons, Arb256/384 and independent Decimal110 agree. The backend actual host/status is recorded. Only audit.py/json are written; no Git or remote files.']}
    output=BASE/'audit.json';output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'exact_cases':len(exact),'remote_exit':run.returncode,
                      'independent_crosscheck':True,'real_A':real,'support':support},indent=2))


if __name__=='__main__':main()
