from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from random import Random
import json

def lists_trial(seed):
    rng=Random(seed)
    N=256
    delta=F(1,16)
    tau=delta/(8*N)
    cap=F(1,256)
    chosen=[]
    paid=0
    min_choices=N
    for g in range(70):
        bins=[cap*F(rng.randint(4,8),8) if rng.randrange(5) else tau/2 for _ in range(N)]
        assert sum(bins)>=F(1,4)
        candidates=[]
        mass=F(0)
        for j in reversed(range(N)):
            if bins[j]<tau:
                continue
            assert sum(bins[j+1:])<=3*delta/8
            candidates.append(j)
            mass+=bins[j]
            if mass>=delta/4:
                break
        min_choices=min(min_choices,len(candidates))
        assert len(candidates)>=delta/(4*cap) and mass>=delta/4
        # Incoming potential conflict costs; each earlier group already has one shell.
        costs=[rng.randint(1,20000) for _ in chosen]
        K=int(delta/(8*cap))
        important=sorted(range(len(chosen)),key=costs.__getitem__,reverse=True)[:K]
        forbidden={chosen[h] for h in important}
        options=set(candidates)-forbidden
        values={j:sum(v for h,v in enumerate(costs) if chosen[h]==j) for j in options}
        choice=min(values,key=lambda j:(values[j],j))
        assert all(choice!=chosen[h] for h in important)
        assert values[choice]*len(options)<=sum(values.values())
        chosen.append(choice)
        paid+=values[choice]
    return min_choices,paid

def angular(n):
    with localcontext() as ctx:
        ctx.prec=75
        v=D(n); e=D(1).exp();logtwo=D(2).ln(); h=1+1/(32*v)
        k0=int(v.sqrt())
        ks=range(k0,n+1) if n<=2**16 else (k0,k0+1,n//8,n//4,n//2,n-1,n)
        worst=0
        for k in ks:
            k=D(k)
            # Left exponent divided by k+1. Test the analytic uniform upper coefficient.
            ratio=2*(2*(k/v).exp()/D(128)).sqrt()
            assert ratio<=e.sqrt()/4+D('1e-72') and ratio<D('0.413')
            worst=max(ratio,worst)
        tiny=(2+h*(logtwo/v).exp())/4
        assert tiny<D('0.76')
        return {'n':n,'number_of_strip_tests':len(ks),'largest_coefficient':str(worst),'tiny_base':str(tiny)}
if __name__=='__main__':
    trials=[lists_trial(s) for s in range(64)]
    print(json.dumps({'list_fixture_runs':len(trials),'groups_per_run':70,'minimum_list_count':min(k for k,p in trials),'angular':[angular(n) for n in (4096,65536,2**24,2**48,2**64)],'scope':'List fixtures check finite arithmetic and choices, without claiming greedy histories. Decimal tests check coefficients only.'},indent=2))
