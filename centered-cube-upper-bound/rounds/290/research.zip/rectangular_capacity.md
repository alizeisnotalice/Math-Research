# R290 — rectangular-source weak capacity and an anisotropic full-soft source payment

## Result

The proposed logarithmic rectangular generalization is valid:

    ||M_[a,b] mu||_(1,infinity)
       <=[2+sum_i log(1+d_i/a)]||mu||.                  (R1)

Here mu is any nonnegative finite L1 source supported in an axis-parallel rectangle with positive full sides d_i, and 0<a<=b. No density cap, FIRST, receiver restriction or source product law is needed. The proof generalizes the actual R251 threshold-dependent common-window argument by choosing a threshold-dependent INNER RECTANGLE of the right volume; merely replacing n log(1+d/a) by a coordinate sum without this step would be unjustified.

It extends to a full-soft two-source anisotropic-grid payment with the SAME R283 entropy factor B_*(n,D), without a width-dependent entropy surcharge. The result gives actual paid broad directional pair classes. It does not assert that arbitrary wide pairs belong to such a class, or that choosing a separate optimal grid for each pair is free.

## 1. Derivation from the actual R251 proof

I read R251 `shared_scale_geometry.md` SG5 and its independent audit directly from the archived `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/251/research.zip`. Its cube proof pays a threshold core of volume m/u, then confines every external witness to one common short scale window. The following is that argument with a different core.

Let mu be supported in C=product_i[z_i-d_i/2,z_i+d_i/2], with mass m. If m=0 or u>=m/a^n, the strict maximal superlevel set is empty. Otherwise put

    r=(m/u)^(1/n)>a,
    G_a=[product_i(a+d_i)]^(1/n).

Every original superlevel witness R satisfies R<r. The scaling kernel envelope K_[A,B]=sup_(A<=R<=B)h_R has exact mass 1+n log(B/A), including the single-scale case A=B.

If r<=G_a, every superlevel point is witnessed inside [a,min(b,r)]. A single envelope/Tonelli/Markov step gives

    u|{M_[a,b]mu>u}|
       <=[1+n log(r/a)]m
       <=[1+sum_i log(1+d_i/a)]m.                      (R2)

No core is needed in this case.

If r>G_a, there is a unique A>a such that

    product_i(A+d_i)=r^n.

Let C_A be the rectangle centered at z with full sides A+d_i. It has volume r^n, so its entire superlevel contribution costs at most u|C_A|=m. At a point outside C_A, one coordinate satisfies 2|x_i-z_i|>A+d_i. Every source point in C is therefore more than A/2 away from x in that coordinate. A cube witnessing positive response must have R>A. Together with R<r, every external superlevel witness belongs to the SINGLE frozen interval

    [A,B], B=min(b,r).

If B<A there are no external superlevel points. Otherwise one envelope/Tonelli/Markov step costs at most [1+n log(B/A)]m. Finally,

    n log(r/A)=sum_i log(1+d_i/A)
               <=sum_i log(1+d_i/a).

Adding the core m proves (R1). The core, A and the envelope depend only on the whole packet mass, threshold and side vector; they are fixed before receiver integration. Nothing is selected per source point. This proof also shows that b<=2a is unnecessary for (R1), although the applications below retain the original octave.

## 2. Full-soft fixed-shape bound with no width entropy

Return to 0<a<=b<=2a and the original full-soft family with ns<=D. Put

    c_i=log(1+d_i/a), kappa_d=2+sum_i c_i.

For a fixed rounded rectangle kernel shape Rvec=(R_i), diagonal change of variables transforms the source support sides to d_i/R_i. The determinant cancels in its weak-L1 constant, exactly as in R283. Equation (R1) gives

    ||sup_(a<=L<=b) H_(Rvec,L)*mu||_(1,infinity)
       <=[2+sum_i log(1+d_i/(aR_i))]m.                 (R3)

Hard-labelled coordinates have R_i=1. For u>=0 and R>0,

    log(1+u/R)<=log(1+u) max(1,R^(-1)).

For R<=1 this follows from concavity of log(1+u) and its value zero at u=0; for R>=1 it is monotonicity. Therefore the bracket in (R3) is at most

    kappa_d U_(d,R),
    U_(d,R)=1+sum_(soft i) w_i/R_i,
    w_i=c_i/kappa_d,  sum_i w_i<1.                    (R4)

Use the SAME R283 fixed common-soft menu, rounded labelled laws and inverse-side tilted law. Mark 0 has unnormalized weight 1, and mark i has weight 1{soft i}w_i/R_i. Split each maximal shape function into these fractions divided by U_(d,R); they sum exactly to one. Each marked piece has its assigned weak constant kappa_d m times the unnormalized marked weight, so the construction does not duplicate the source.

At each menu node, if t_k is its soft-label probability and z_1 is the inverse rounded-side mean, R283 gives z_1<=1. Hence the mean marked mass is

    Z_k=1+t_k z_1 sum_i w_i<=2<=D+3.                  (R5)

Conditionally on mark i>0, the constant w_i cancels. Coordinate i is forced soft with the SAME inverse-side tilted shape law as R283; all other kernel labels retain their original law. Mark 0 keeps the original shape law. Widths change only the mark-index probabilities, whose entropy remains <=log(n+1). Thus the SAME entropy upper bound E_* and the SAME B_*(n,D) are valid; no entropy of the vector d is charged or assumed finite.

For clarity, one valid retained choice is

    M=min(n,floor(D)+1),
    H_*=(D+2)[log(en)+log(2D+3)+15],
    E_*=H_*+log(n+1)+log(2D+3)+60e,
    B_*=e^2 M(D+3)[3+2log2+2log M+2E_*].               (R6)

The existing countable weak-sum lemma applied to the exact marked decomposition yields

    ||sup_(ns<=D,a<=L<=b)P_(s,L)*mu||_(1,infinity)
       <=kappa_d B_* m.                              (R7)

All infinite shape tails remain present. There is no cap on a maximal envelope or a latent component. Taking D=n permits the complete softness range; then B_* is exactly the safe all-soft B_n used in `/tmp/r289_geometry.md` and log B_n=O(log(n+2)).

## 3. Anisotropic-grid two-source payment

Fix positive widths d_i BEFORE the receiver and original auxiliary slots are selected. Draw a uniformly shifted axis-parallel rectangular grid with these widths. For each realization both original sources are partitioned by the SAME cells C, and

    sum_C ||rho|C||=W_rho, sum_C ||nu|C||=W_nu.

No source point is copied to every intersecting cell. The exact same-cell probability for a source pair is

    p_d(y-z)=product_i(1-|y_i-z_i|/d_i)_+.

For 0<=eta<1 define the original pair gate

    Gamma_(d,eta)={sum_i |y_i-z_i|/d_i<=eta}.

On that gate p_d>=1-eta. For each cell its actual restricted responses F_C and G_C retain the ORIGINAL full caps F_C/q<=1 and G_C/(4lambda)<=1. Their weak constants are at most kappa_d B_*rho(C)/q_- and kappa_d nu(C)/(4lambda), where q_-=3lambda/4. The capped weak-product function and its amplification inequality therefore give

    integral_E F_C G_C/q
       <=kappa_d[(16/3)rho(C)+(1+log B_*)nu(C)].

Only these integrated linear source prices are summed. Averaging the grid and dividing by the actual same-cell lower bound gives the raw original pair payment

    T_Gamma <= [kappa_d/(1-eta)] S_(n,D),
    S_(n,D)=(16/3)W_rho+(1+log B_*)W_nu.              (R8)

All current original positive masks can be retained on the left and dropped only in the majorant. Receiver measure is actual dx, and no posterior is changed. For eta=1/2 this is 2kappa_d S_(n,D). It strictly improves the isotropic R289 cost in directional classes where only a few coordinate widths need be large.

If the existing actual upper-slot score condition R_2<=D and the physical clock are also present, define the new pair gate before applying the original full-posterior score estimate. Its auxiliary-slot independence permits the established bound and clock substitution in their original order. Equation (R8) then gives

    P_Gamma <=2Lambda B_D [kappa_d/(1-eta)]S_(n,D),
    B_D<=4sqrt(nD).                                   (R9)

No second Lambda, source duplication or scale-menu multiplicity is added. A physical minimum a_xi can replace a in kappa_d at each clock, while a fixed grid chosen from the original a stays unchanged.

## 4. Genuine broad-distance classes and their exact root budgets

Fix the FIRST coordinate in advance and consider the pair class

    |y_1-z_1|<=na,
    |y_i-z_i|<=a/n^3 for i>1.

Choose the single common grid with

    d_1=4na, d_i=4a/n^2 for i>1.

Then sum_i |y_i-z_i|/d_i<=1/4+(n-1)/(4n)<=1/2, while

    kappa_d=2+log(1+4n)+(n-1)log(1+4/n^2)
              <=2+log(1+4n)+4/n.                     (R10)

This pair class has positive transverse thickness and allows l1 distance of order na. It is not a singular-line or atomic-source exception; arbitrary finite positive L1 sources may be used. Thus (R8) has logarithmic packet cost on a genuine broad-distance configuration. With D=O(log(n+2)), (R9) is a root-polylog original score-clock source payment for this class.

More generally a frozen width vector with sum log(1+d_i/a)<=C sqrt(n)polylog(n) gives a raw root-polylog payment by (R8). To retain root order AFTER the generic B_D clock fee when D is polylogarithmic, a polylogarithmic width cost suffices, as in (R10). These raw and score-clock assertions must not be conflated.

The direction must remain fixed or be priced. Covering all n coordinate-axis versions by an unweighted union can cost n. Drawing those n needle grids uniformly gives coincidence probability only about 1/n on a pair compatible with one direction and incompatible with the others; its compensation is not free. No assertion here covers the whole unrestricted l1 ball of radius comparable to na.

## 5. Exact fixed-envelope optimal widths and allowed mixtures

Suppose a designated pair class is contained in the coordinate box |y_i-z_i|<=v_i with fixed v_i>0. For a chosen eta in (0,1), sufficient widths satisfy sum_i v_i/d_i<=eta. Minimize the proven packet cost sum_i log(1+d_i/a) subject to that constraint.

Set t_i=v_i/a and x_i=v_i/d_i. The equivalent optimization is

    minimize sum_i log(1+t_i/x_i),
    x_i>0, sum_i x_i<=eta.

Each summand is strictly convex and decreasing: its derivative is -t_i/[x_i(x_i+t_i)] and its second derivative is positive. The unique optimizer uses sum_i x_i=eta and satisfies

    x_i=[sqrt(t_i^2+4t_i/tau)-t_i]/2,
    sum_i x_i=eta, tau>0,
    d_i=v_i/x_i.                                      (R11)

The multiplier tau is uniquely determined because the displayed sum decreases continuously from infinity to zero. This is an actual optimal width assignment for the stated proven bound and fixed envelope, not an unpriced pair-dependent infimum. It may be computed once before forming any receiver or source-cell response. Optimizing eta itself is a further scalar minimization of kappa_d/(1-eta), if desired.

A fixed probability law Pi over width vectors is also legitimate. For each draw use one common source grid. If c(Delta)=E_Pi p_d(Delta), then any nonnegative pair weight omega(Delta)<=c(Delta) has raw payment

    T_omega <= E_Pi[kappa_d] S_(n,D),                  (R12)

provided that expectation is finite. If c>=p_0>0 on a designated class, its indicator is paid at E[kappa_d]/p_0. This states both the exact allocation weight and its source cost. It does not allow selecting widths separately at each pair and then summing a new copy of both source masses.

## 6. Actual local checks and evidence limits

A local 60-digit calculation checked 36 rectangular threshold logarithm identities and their comparison at A>=a; five rational broad-direction capture ratios and logarithmic-cost comparisons were also checked. A finite exact labelled-shape calculation verified weighted marked mass 23/20<=2 and six inverse-tilted marginal identities, including cancellation of the width weights. Three 60-digit multiplier solves checked (R11) against the constraint and all stationarity equations. Output:

    PASS rectangular threshold log identities / directional captures=41
    PASS exact weighted mark mass=23/20 inverse-tilted marginal checks=6
    PASS optimal-width multiplier cases=3

These are local algebra, geometry and optimization diagnostics, not interval certificates or continuous-history models. The analytic proofs establish (R1)-(R12). No repository, Git or other author files were modified; only this temporary Markdown deliverable was written.
