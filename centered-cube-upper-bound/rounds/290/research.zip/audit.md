# R290 independent audit: axis-rectangle support and anisotropic source capacity

## 1. Independent preauthor statement screen

The following derivation was completed and sent to the parent before reading `/tmp/r290_rectangular_capacity.md`. Only this temporary audit file is owned/written; no repository or Git operation is involved. No source uniform-density assumption is made.

Let a>0, m=||rho||<infinity, u>0 and rho be supported in a fixed axis rectangle centered at c, with finite side lengths d_i>=0. Put r=(m/u)^(1/n) and G_a=[prod_i(a+d_i)]^(1/n). A witnessing scale R>=a for h_R*rho>u must satisfy R<r. If r<=a, there is no witness; if m=0, the statement is trivial.

For a<r<=G_a, the scale envelope over [a,min(b,r)] has strong column mass at most 1+n log(r/a). Markov and positive convolution yield

    u|{M_[a,b]rho>u}|
      <=m[1+n log(r/a)]
      <=m[1+sum_i log(1+d_i/a)].

For r>G_a there is a unique A>a with prod_i(A+d_i)=r^n. It satisfies A<=r. The inner rectangle S+Q_A, with side lengths A+d_i, has volume r^n and hence costs at most m in the level estimate. Outside that rectangle, any cube intersecting the source support must have R>A. A level witness also has R<r. If A>=b, or A=r, there are no such outside witnesses. Otherwise the point envelope for A<R<min(b,r) has strong column mass at most 1+n log(r/A). Its contribution is therefore at most m times that quantity. Finally

    n log(r/A)=sum_i log(1+d_i/A)
                <=sum_i log(1+d_i/a).

This proves the proposed universal weak constant

    kappa_d=2+sum_i log(1+d_i/a).

The proof even allows arbitrary finite positive source measures as a hard-kernel statement; support alone is used. Closed-inner-rectangle boundaries have zero receiver volume. The actual [a,b] window and its empty-witness cases are retained, not replaced by a scale claim beyond the allowed interval.

For fixed positive shape sides R_i and x_i=d_i/a,

    log(1+x_i/R_i)<=max(1,R_i^-1)log(1+x_i).

The hard labels have R_i=1, while max_i max(1,R_i^-1)<=U_R=1+sum_soft R_i^-1. Hence

    kappa_(d/R)<=kappa_d U_R.

An invertible diagonal change of coordinates preserves source mass and cancels its determinant in weak L1. The same R283 fixed marked inverse-side law at D=n consequently yields full-soft weak factor kappa_d B_n, provided its already audited fixed-weight/countable-label construction is retained. The hard factor is kappa_d. Both original actual response caps then give the usual cell source price kappa_d[(16/3)rho(C)+(1+log B_n)nu(C)].

For a shared axis grid with POSITIVE widths d_i fixed before receiver selection, the pair's exact same-cell probability is prod_i(1-|y_i-z_i|/d_i)_+. On the actual gate sum_i |y_i-z_i|/d_i<=eta<1 this is at least 1-eta. Disjoint source-cell sums and averaging therefore give the proposed raw branch price

    kappa_d/(1-eta)[(16/3)W_rho+(1+log B_n)W_nu].

The rectangle weak theorem permits zero side lengths, but the grid formula requires strictly positive widths or a separate explicit degenerate convention. For L1 source-pair inputs, any branch requiring equality of a coordinate has product measure zero, which can handle a zero grid width separately.

The axes and widths must remain frozen before the receiver and must refer to the original coordinate system. An unknown rotated rectangle, receiver-dependent choice, or multiple orientation/width menu requires its own justified cost. This screen grants no arbitrary-wide coverage, no original radial-weight comparison, and no global closure.

## 2. Completed author readings and version bindings

The completed Sol author was then read in full, including its strengthened width-weighted marking, broad-direction example, optimization and mixtures:

`/tmp/r290_rectangular_capacity.md`: SHA256 `b1202cb6816de5a16337b4841dee518adf0d938344adc633198c09bb5f3f4507`.

The parent's partition consequence was read in full, followed by its appended original-score statement P5. The requested fixed-index joint-measurability clarification was then read in the revised theorem. Final binding:

`/tmp/r290_partition.md`: SHA256 `301fa2b21f233d5dd328e6b595a7e17cb5f85d89f4c66a57cc03b676f711a1d1`.

**PASS for R1-R12 and P1-P5 at those hashes, with their stated scopes. No outstanding mathematical correction is requested.** The earlier arbitrary-source hard screening argument is stronger than needed; the author and all full-soft/source-pair applications are accepted here on their explicit finite nonnegative L1 input domain. Arbitrary finite density profiles are allowed; no uniform density is assumed.

## 3. Hard rectangle theorem: thresholds and every window guard

The author treats m=0 and u>=m/a^n first, so the strict superlevel is empty there. In the nonempty case r>a, every witness has R<r. The low-r case uses the SINGLE global convolution envelope over [a,min(b,r)], whose exact point-column mass is 1+n log(min(b,r)/a)<=1+n log(r/a). This is a strong envelope estimate followed by Markov, not an asserted norm-one selected column.

For r>G_a, the product equation for A is strictly increasing and gives unique a<A<=r. The inner rectangle's volume is exactly m/u. Outside its closed boundary, which is null for receiver volume, any cube meeting the support needs R>A. If B=min(b,r)<A no exterior point is witnessed. If B=A the author may charge the single-scale envelope even though the strict exterior witness interval is empty; that harmless overestimate remains valid. Otherwise the one fixed [A,B] envelope applies. Thus A>=b, A=r, b=a, and scales at the endpoints create no missing case or negative logarithm.

The identity n log(r/A)=sum_i log(1+d_i/A) and A>a yield the advertised constant 2+sum_i log(1+d_i/a). It is uniform in the source distribution and actual measurable scale selector. The hard theorem does not need b<=2a; the later full-soft/menu applications correctly retain that original octave. The author states positive widths; deterministic zero-width envelope cases in P1 follow by positive enlargement and limits (and have zero L1 mass if truly confined to a coordinate hyperplane). No side-zero random grid is used.

## 4. Full-soft transformation and the stronger width-weighted marks

The invertible diagonal shape change transforms support sides to d_i/R_i, preserves source mass and cancels its receiver determinant in weak L1. The original [a,b] scale parameter remains the same. The scalar logarithm inequality in Section 1 is valid for every positive shape side.

The author's weighted refinement also checks. With c_i=log(1+d_i/a), kappa_d=2+sum c_i and w_i=c_i/kappa_d,

    2+sum_i log(1+d_i/(aR_i))
      <=kappa_d+sum_(soft i)c_i/R_i
      =kappa_d[1+sum_(soft i)w_i/R_i].

Here sum w_i<1. The exact mark decomposition therefore has total U_(d,R)=1+sum_soft w_i/R_i. At each fixed common-soft node its mean is 1+t_k z_1 sum w_i<=2<=D+3. Conditionally on mark i, the fixed width coefficient w_i cancels and leaves precisely the previously audited inverse-side tilted shape law; mark zero leaves the original label law. Widths only change the mark-index probabilities, whose entropy is at most log(n+1). Zero mark weights are omitted.

Consequently the same countable fixed-weight weak-sum theorem, all small-side tails and the same E_* bound give the stated R283 B_*(n,D) without any width-vector entropy fee. D>=0 is allowed; D=n covers all actual s in [0,1]. The actual response caps remain separate height statements and are never assigned to a maximal envelope, rounded component or reweighted source.

## 5. Shared grids, constants, broad example, and optional constructions

Positive grid widths are fixed from the original datum before x and auxiliary slots. Same-cell probability is exactly prod_i(1-|y_i-z_i|/d_i)_+, at least 1-eta on Gamma_(d,eta), with 0<=eta<1. For each cell, both actual response restrictions inherit the original caps. Applying the capped product with the two weak constants and q_-=3lambda/4 gives exactly

    integral_E F_C G_C/q
      <=kappa_d[(16/3)rho(C)+(1+log B_*)nu(C)].

Only these already integrated linear mass terms are summed. There is no sum of weak norms interpreted as an L1 norm. Averaging yields the exact raw price kappa_d S_(n,D)/(1-eta), with no factor 2Lambda until original score/clock traffic is restored.

For the prescribed first-axis broad envelope, d_1=4na and d_i=4a/n^2 give normalized displacement <=1/4+(n-1)/(4n)<1/2. The packet cost is bounded by 2+log(1+4n)+4/n. This is a positive-thickness source-pair class with distances of order na. At full softness D=n it has O(log^2(n+2)) raw source price, but it does not cover all directions. At small D and the separately retained auxiliary qualifications, its score/clock price is root-polylog as stated.

The fixed-envelope optimizer R11 is correct for v_i>0. With x_i=v_i/d_i, each summand log(1+t_i/x_i) is strictly convex, decreasing and diverges at x_i=0. The unique optimum uses sum x_i=eta. Its stationarity t_i/[x_i(x_i+t_i)]=tau yields the displayed square-root formula. The sum decreases continuously from infinity to zero with tau, so the multiplier is unique. This is an optimizer for ONE frozen envelope; it is not an unpriced pairwise selector.

The fixed width-law mixture R12 is likewise valid: Tonelli averages actual common-grid source allocations and their already integrated kappa_d source prices. It pays a weight omega(Delta)<=E p_d(Delta) at E kappa_d S_(n,D), provided the latter expectation is finite. Compensating a class by a common lower coincidence probability is explicitly charged. No entropy is needed after this source-linear integration, but no individual pair may choose a fresh width/source copy for free.

## 6. General partitions: measurability, zero cells, and finiteness

P1 applies the cell theorem to the actual two original restrictions on the SAME countable partition cell. Each cell's finite axis-rectangle envelope is an explicit hypothesis. The displayed capacities use those fixed envelope widths, not an unproved minimal or rotated geometry. P3 is the exact identity prod_i(a+d_(C,i))/a^n for the expanded rectangle volume. It does not replace logarithmic capacity by raw volume.

For random P2, the final theorem now explicitly uses one fixed countable index k, jointly measurable indicators 1_(C_k(omega))(y), and measurable envelope widths/kappa_k. These are the required hypotheses for the written expectations and Tonelli steps. This clarification was requested during this review and is present in the frozen hash. The original integrand is fixed independently of this proof randomization, conditional on original sources/outer data.

For every realization the common-cell sum is between zero and one. Thus A(y,z) is measurable and in [0,1]. Each source point belongs to only one cell, so sum rho(C)=W_rho and sum nu(C)=W_nu, with no copies. Countable sums and expectation are nonnegative Tonelli operations. Empty/zero-source cells have zero product cost; their upper-bound overcharge, if the other source has mass, is harmless. Finite widths ensure each kappa_C is finite, but the weighted sums/expectations K_rho,K_nu can still be infinite. The author explicitly treats that only as an extended-real upper bound and requires a proved finite capacity budget for a genuine payment.

It follows exactly that

    integral A dT<=(16/3)K_rho+(1+log B_n)K_nu,

and the remaining ORIGINAL raw integrand is (1-A)dT. No positive lower bound on A is supplied. A low-cost common partition distribution, or a coverage/omission estimate on actual traffic, remains to be constructed if one wants more than this partial allocation.

## 7. P5: conditional actual broad continuous traffic

The appended P5 is a valid additional original-traffic statement. It explicitly restricts original physical softness to ns<=D and ORIGINAL upper auxiliary displacement to R2(y,v)<=D. The latter is not the source-pair distance |y-z|. The fixed anisotropic source-pair gate is independent of auxiliary slots. On each original row, positive score<=min(n,D/(1-xi)^2) is bounded inside the FULL unchanged posterior BEFORE changing xi=c_jt/b. The unique original j and actual legal receiver set are retained through the needed clock qualification.

At fixed xi the actual scale interval is contained in [a,b], so the same raw anisotropic theorem and original caps apply, with B_*(n,D). The original scalar clock integral J_D<=4sqrt(nD), including its zero-score convention at D=0, gives exactly

    P_(Gamma,ns<=D,R2<=D)
      <=2Lambda J_D kappa_d/(1-eta)
          [(16/3)W_rho+(1+log B_*(n,D))W_nu].

No source-near receiver window is used in the rectangular theorem, so this P5 branch may have genuinely broad source distance. It does not assume the ENTIRE broad original traffic satisfies its ns/R2 qualifications. In particular no previously paid R279 source-NEAR tail is transferred to wide source pairs. The unqualified large-softness/large-auxiliary-displacement domain, other width/direction classes and original prefix slots remain outside P5. P1-P4 alone are raw bounds and do not remove the high-score/clock factor.

## 8. Actually run bounded mathematical diagnostics

Using the existing local vendored mpmath at 60 digits, a fresh run checked 75 level-root regimes across dimensions through 512, zero/thin/mixed support widths, and radius factors. It checked 135 outside-window guards and 75 unweighted shape comparisons. Actual output:

    PASS level-root regimes=75 outside-window guards=135 soft-shape comparisons=75

An additional fresh run checked the stronger width-weighted shape inequality on fifteen anisotropic profiles and solved three multiplier systems, checking both the sum constraint and all stationarity equations:

    PASS weighted-width shape comparisons=15 optimal-width multiplier systems=3

These are ordinary finite multiprecision diagnostics, not interval certificates, actual continuous-history constructions or evidence of universal coverage. The analytic proofs establish the hard rectangle and source-capacity conclusions; no diagnostic supplies an unknown direction menu or a missing global source ledger.

**Final bounded receipt: PASS at the author and revised partition hashes in Section 2. Genuine raw and explicitly qualified score-clock broad branches are paid; arbitrary-wide coverage, unqualified high-score traffic, prefix slots and the complete global problem remain unresolved. Only this owned audit file was written.**

## 9. Final README integration freeze

The final integrated README was read in full and hash-checked:

`/Users/zhengzhihao/Desktop/T/output/centered_cube_round290_20261017_final_checkpoint/README.md`: `5715252a843a328942ef3ac51111f2adab4d6bbb43bca6a28628d204c7459937`.

**PASS for its mathematical formulas and bounded scope.** It agrees with the two frozen proofs in Section 2: logarithmic hard rectangle capacity; unchanged full-soft entropy factor; exact shared-grid and source-weighted random-partition prices; required joint measurability and finite capacities; the fixed-axis broad example; and P5's full original score/clock fee with explicit ns<=D and upper-slot R2<=D. The elementary safe minimum with the strong scale-envelope constant is valid; it does not remove any source or qualification. The fixed-envelope optimization and its selection-cost limitations are stated correctly.

The README preserves original beta-FIRST reentry and the single low-pe outer Lambda. It explicitly leaves unknown directions, width/partition selection, insufficient coverage, wide large-ns/R2 tails, original prefix/deletion slots and global closure unpaid. It does not transfer R279's tiny-near tail payment to wide pairs or omit high-score costs. Its numerical section states appropriate finite-test limits; this integration check does not re-run the parent's larger reported diagnostic suite.

Author hash remains `b1202cb6816de5a16337b4841dee518adf0d938344adc633198c09bb5f3f4507`; revised partition hash remains `301fa2b21f233d5dd328e6b595a7e17cb5f85d89f4c66a57cc03b676f711a1d1`. No correction requested. Only this owned audit file was appended; bounded work stops here.
