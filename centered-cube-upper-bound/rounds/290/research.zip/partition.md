# R290: common rectangular partitions and logarithmic volume capacity

## Precise theorem
Fix n>=1, 0<a<=b<=2a, positive finite L1 sources rho,nu, and actual measurable s(x) in[0,1], L(x),R(x) in[a,b], q(x) in[3lambda/4,lambda] on E. Assume the actual caps integral P_(s,L)(x-y)rho(dy)<=q(x) and sup_(a<=t<=b)(h_t*nu)(x)<=4lambda. Let dT=q^-1 p_y(x)h_R(x-z)dx rho(dy)nu(dz), with any retained original factor in[0,1].

Let P be a countable measurable partition of source space, fixed before receiver selection. Every cell C is contained in some axis-parallel rectangle B_C with finite widths d_(C,i)>=0. Define

 kappa_C=2+sum_i log(1+d_(C,i)/a).

For this fixed partition,

 integral sum_C 1_C(y)1_C(z) dT
 <=sum_C kappa_C[(16/3)rho(C)+(1+log B_n)nu(C)],            (P1)

where B_n is R289's all-soft marked kernel constant. A cell of zero source mass contributes zero. The inequality also applies to arbitrary positive cell widths with degeneracy handled by enlargement; no zero-width random grid is used.

If P is random, its law, cell envelopes and all widths must be fixed from the original sources/outer data before x. Present its cells using a fixed countable index k, with jointly measurable indicators 1_(C_k(omega))(y) in (omega,y), and measurable containing rectangles/widths and kappa_k(omega); empty cells are allowed. These hypotheses make the following Tonelli integrals well defined. Write

 A(y,z)=E_P sum_C 1_C(y)1_C(z),
 K_rho=E_P sum_C kappa_C rho(C),
 K_nu=E_P sum_C kappa_C nu(C).

Then the actual A-weighted original traffic has the source price

 integral A(y,z)dT <=(16/3)K_rho+(1+log B_n)K_nu.           (P2)

These are exact source-weighted capacities, not asserted universal constants. If they are bounded by C sqrt(n)log^p(n+2) times their respective original source masses, the paid fraction has the corresponding root-polylog price. The remaining original positive integrand is exactly (1-A)dT; P2 alone supplies no lower bound on A.

## Proof
For each source cell restrict rho and nu to that SAME cell. The rectangular weak-source theorem gives the hard response weak constant kappa_C nu(C). Its R283 marked-shape extension gives soft weak constant kappa_C B_n rho(C), uniformly in all actual s,L. This applies to source subsets contained in the envelope rectangle; uniform density is not required. The actual response caps remain valid by positivity, not from a new artificial FIRST declaration.

The two-cap weak product integral and amplification inequality give

 integral_E F_C(x)G_C(x)/q(x)dx
 <=kappa_C[(16/3)rho(C)+(1+log B_n)nu(C)].

Retained original factors only decrease this positive expression. Sum over disjoint cells. Tonelli handles countably many cells and the random law, proving P1-P2. If K_rho or K_nu is infinite, the extended-real upper bound remains valid but is not a finite source payment. Finiteness must be proved before invoking a uniform price. Independent original terminal leaf budgets can be added under their previously checked disjoint source ledger; no nu<=rho or nu<=beta is used.

For a rectangular cell itself,

 kappa_C=2+log[|B_C+Q_a|/a^n].                            (P3)

Thus the capacity is the logarithm of the expanded geometric volume, weighted once by each original source mass. It is not the volume itself, nor an unproved covering number. This is the genuinely stronger geometry of the new rectangular theorem.

## Shared-grid specialization and broad-distance receipt
For a common uniformly shifted rectangular grid with positive widths d_i,

 A_d(y,z)=prod_i (1-|y_i-z_i|/d_i)_+.

All cells have the same kappa_d. Thus P2 becomes

 integral A_d dT <=kappa_d[(16/3)||rho||+(1+log B_n)||nu||]. (P4)

On the prescribed source envelope sum_i |y_i-z_i|/d_i<=eta<1, A_d>=1-eta; dividing by 1-eta pays that ENTIRE original subbranch. This inequality remains valid even for large l1 distances, and applies to low pe through its verified beta FIRST. Widths cannot be selected separately for every observed pair without an additional common-partition/selection argument.

For example, fix one coordinate before receiver choice. On the envelope |y_1-z_1|<=na and |y_i-z_i|<=a/n^3 for i>1, take d_1=4na and d_i=4a/n^2 for i>1. The normalized displacement sum is at most 1/4+(n-1)/(4n)<1/2, while

 kappa_d<=2+log(1+4n)+4/n.

Consequently this original broad-distance subbranch has O(log^2(n+2)) raw source price with full softness. The direction is prescribed; a union over arbitrary directions or shapes is not free. This example demonstrates a real improvement beyond an l1 cutoff, not a proof that every source pair is of this form.

## Coverage required for the actual full objective
The unpriced broad low-pe and high continuous traffic from R289 can cross cells of every chosen partition. To close them using P2 one would need a source-conserving distribution of partitions satisfying BOTH a source-weighted capacity bound and a pointwise or original-integrated coverage/omission bound on that actual traffic. Merely minimizing kappa_d for each pair proves neither condition.

For the high continuous term, its original posterior/score/clock factor has NOT been removed or priced by P1-P4. A scalar multiplier can be used only after deriving a valid original-row bound and retaining all clock/j costs. The present theorem directly prices the raw low-pe and other raw suballocations with factors in[0,1]. It is not a replacement for the R288 high-score theorem outside its near window.

The exact remaining raw low-pe integrand after using a prescribed partition distribution is (1-A)1_low dT, optionally retaining the previous far/high-m gates. Root order for the whole original problem remains unproved. No old signed credit is used and no claimed new theorem consists only of renaming that remainder.

## Conditional original broad continuous-score receipt

The raw result also gives a genuine high-traffic suballocation after paying its score, with qualifications kept explicit. Restrict the ORIGINAL upper good slot to R2(y,v)<=D and the original physical softness to ns<=D, for a fixed outer D. On the original row the positive score is <=f_D(xi)=min(n,D/(1-xi)^2), where xi=c_j t/b. Use the full unchanged posterior probabilities before the physical clock substitution; the unique original j remains. R280 supplies

 J_D=integral_(a/b)^1 f_D(xi) dxi/xi<=4sqrt(nD).

At every physical clock the scale interval is a SUBinterval of [a,b], so the same rectangular source bound with the original a and the general R283 constant B_*(n,D) remains valid. For the frozen anisotropic distance branch Gamma_d={sum_i|y_i-z_i|/d_i<=eta}, its complete positive traffic including one outer 2Lambda obeys

 P_(Gamma_d,ns<=D,R2<=D)
 <=[2Lambda J_D kappa_d/(1-eta)]
       [(16/3)W_rho+(1+log B_*(n,D))W_nu].                (P5)

Here R2 is the auxiliary upper-slot displacement, not the original hard source distance |y-z|. All positive original history/high/FA/capture masks are retained until legitimate upper bounds; no new posterior or FIRST is assigned. The bound is independent of whether the original source pair is within the tiny radius r. Thus the broad fixed-axis example above, with kappa_d=O(log(n+2)) and a fixed D=O(log(n+2)), has a root-polylog price for its actual continuous traffic as well as a full-soft raw low-pe price.

It would be incorrect to assert that the entire broad-source domain already satisfies ns+R2<=D: R279's previously paid tail used its source-near receiver window. P5 only pays the indicated actual branch. Its complement includes arbitrary source directions/width profiles, large ns or R2, and the original prefix slots. No R279 near-tail payment is transferred to wide source pairs.
