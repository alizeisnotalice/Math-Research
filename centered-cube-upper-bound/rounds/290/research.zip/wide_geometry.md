# R290: exact rectangular overlap allocation and the remaining wide-selection bridge

## 1. Precise theorem before proof

Let n>=1, 0<a<=b<=2a, lambda>0, and let beta,nu be arbitrary finite positive L1 measures. On the actual measurable receiver set E retain s(x) in [0,1], L(x),R(x) in [a,b], q(x) in [3lambda/4,lambda], and the FULL product soft kernel p_y(x)=P_(s(x),L(x))(x-y). Assume the actual caps

    integral p_y(x) beta(dy)<=q(x),
    sup_(a<=t<=b) h_t*nu(x)<=4lambda.

For any fixed positive rectangle side vector d=(d_1,...,d_n), set

    kappa(d)=min{1+n log(b/a), 2+sum_i log(1+d_i/a)},
    A_d(y,z)=product_i (1-|y_i-z_i|/d_i)_+,
    S_n=(16/3)||beta||+(1+log B_n)||nu||,

where B_n is the R283 full-soft menu constant with D=n, given in Section 4. Then the following actual original-source estimate holds:

    integral_E q(x)^(-1) integral integral
        A_d(y,z) p_y(x) h_R(x-z) beta(dy)nu(dz) dx
      <= kappa(d) S_n.                                      (T1)

Any original measurable mask between zero and one, including low pe, accepted-hard, actual small-parent, and m>M, may be retained on the left. No source is replaced, no posterior is localized, and actual dx is unchanged.

In particular, for the anisotropic region

    N_d={sum_i |y_i-z_i|/d_i<=1/2},

one has the full, not merely fractional, branch payment

    T_(original,N_d)<=2 kappa(d) S_n.                       (T2)

If sum_i d_i<=a sqrt(n), (T2) is O(sqrt(n)log(n+2)) times the original source masses. This condition permits wide source displacements in a few predetermined directions; it is substantially different from the tiny isotropic source-near condition. The vector d must be fixed before receiver and source-pair selection. There is no claim that an unpriced adaptive choice of d covers the entire original wide remainder.

## 2. Rectangular weak capacity used as a separate input

The independent R290 rectangular-capacity argument supplies

    ||M_[a,b] mu||_(1,infinity)
       <=[2+sum_i log(1+d_i/a)]||mu||.                      (W1)

This is stronger than the arithmetic-mean-width estimate initially screened here; the full proof belongs to the separately owned rectangular-capacity note. Its decisive threshold root is A determined by product_i(A+d_i)=m/u: the core rectangle has exactly the threshold volume, and every exterior witness has R>A. The common-window envelope costs n log(r/max(a,A)), bounded by sum_i log(1+d_i/a). Cases without a nonnegative root use the global scale envelope. The independent global bound 1+n log(b/a) may always be taken as a minimum. No duplicate novelty claim is made for (W1).

For comparison, the weaker linear-width bound used in the initial screen follows immediately from log(1+t)<=t. The actual overlap/source allocation below uses the stronger (W1) as its explicit input.

## 3. Full-soft packet extension and exact source allocation

Fix a uniformly shifted grid of rectangles of side d. Every beta and nu source point is allocated to precisely one grid cell C. No source is copied. For each fixed rounded latent rectangle shape Rvec from R283, diagonally rescale x_i by 1/Rvec_i. The transformed source cell has side d_i/Rvec_i. By (W1), concavity of log(1+t), and the global scale envelope, the shape maximal operator has weak constant at most

    min{1+n log(b/a), 2+sum_i log(1+d_i/(a Rvec_i))} beta(C)
      <= kappa(d) U_R beta(C),
    U_R=1+sum_(soft coordinates i) 1/Rvec_i.                (W2)

Indeed log(1+c/R)<=max(1,1/R)log(1+c). For hard coordinates R=1; all positive log terms are bounded by their sum times U_R. The constant 2 is also <=2U_R. If the global constant is the smaller choice, its bound is <=that constant times U_R because U_R>=1. Jacobian factors cancel in weak L1. The rectangular weak theorem is valid for arbitrary transformed widths, so no restriction on tiny latent sides is inserted.

The fixed marked-shape entropy argument of R283 now gives the FULL soft envelope weak constant

    ||F_C||_(1,infinity)<=kappa(d) B_n beta(C).

The hard response has weak constant <=kappa(d)nu(C). By positivity their actual restrictions retain F_C/q<=1 and G_C<=4lambda. The R283 capped-product lemma yields

    integral_E F_C G_C/q dx
      <=kappa(d)[(16/3)beta(C)+(1+log B_n)nu(C)].             (W3)

Sum over the disjoint source cells and average the one common grid shift. For each fixed source pair, the probability of occupying a common cell is EXACTLY

    product_i (d_i-|y_i-z_i|)_+/d_i = A_d(y,z).

This is an exact product of normalized interval intersection lengths, not a ball-support majorant. Tonelli proves (T1). On N_d the elementary product inequality product_i(1-u_i)>=1-sum_i u_i gives A_d>=1/2, proving (T2).

Zero source cells contribute zero and are omitted from entropy normalization. All shifts, finite shape-node laws, and marked countable latent laws are fixed independently of the receiver. Half-open grid cells make the allocation measurable; boundary null sets cause no issue for L1 sources. The proof retains original true dx throughout.

## 4. Constants and original low-pe reentry

The full-soft D=n menu has

    H_n=(n+2)[log(en)+log(2n+3)+15],
    E_n=H_n+log(n+1)+log(2n+3)+60e,
    B_n=e^2 n(n+3)[3+2log2+2log n+2E_n].

The elementary R289 estimates give B_n<=15000 n^3 log(n+2) and 1+log B_n<=15log(n+2). Thus when sum_i d_i<=a sqrt(n),

    T_(original,N_d)<=90 sqrt(n)log(n+2)(W_beta+W_nu),       (T3)

using 2(2+sqrt(n))<=6sqrt(n). The actual weighted allocation (T1) has half that bound.

For the exact low-pe traffic, use

    dT=q^(-1)p_y h_R a_omega dx beta_V(dy)nu_V(dz),
    e_g=integral_(Z_g(y)) w_g(y,v)nu_V(dv),
    m=e_g/[ell_n q c_j^(-n/2)g^n]>1.

R117 CL3 certifies beta FIRST directly. The fixed vector d may be used on the original remaining branch

    1{p_y e_g<2Kq} 1{|y-z|_1>a/(16sqrt(n))} 1{m>M} dT.

Both (T1) and (T2) pay their stated allocation of this genuinely wide low branch, with all source sums and original expectation taken once. The original outer fee is Lambda=128/119, once. The argument makes no claim about the high-continuous score/clock factor: retaining that factor requires its actual pointwise or integrated bound, and would multiply the corresponding source price. Neither a full posterior nor a time atom is silently replaced by this raw theorem.

## 5. Exact same-receiver overlap and the unresolved selection operation

For fixed physical parameters s,L,R and one latent soft rectangle with side A_i=L Rvec_i, let delta_i=|y_i-z_i|. The exact one-coordinate intersection length is

    ell_i(A_i,R,delta_i)=min{A_i,R,((A_i+R)/2-delta_i)_+}.

Consequently the fixed-parameter full column is exactly

    integral_(R^n) P_(s,L)(x-y)h_R(x-z) dx
      =integral product_i [ell_i(A_i,R,delta_i)/(A_i R)]
                  pi_s(dRvec).                            (O1)

This preserves the common latent softness law and actual rectangular overlap. There is no product of independently optimized coordinate soft parameters. Equation (O1) follows directly by Tonelli from the positive interval mixture. It is an identity for fixed parameters, not a bound obtained by substituting the receiver-dependent s(x),L(x),R(x) into the integral after x has been integrated out.

For original selectors, replacing their integrand by a supremum BEFORE integrating x is valid but needs its own priced column bound. The earlier R114 ratio column does this at the explicit price C_n c_j^n t^(-n) w_t(y,z), C_n=4+pi sqrt(n). Its integration over the original hard source produces FULL e_t, so on high-m rows the resulting bound is proportional to m. The original low gate gives a clipped density p_y<=2K c_j^(n/2)/(ell_n g^n m), but it does not directly clip (O1) by 1/m: (O1) already integrated over x, whereas both m and the chosen parameters vary with x. This is the precise joint operation still needed.

An equivalent constructive route through (T1) would be a frozen partition law, depending on the original input but independent of the receiver, whose exact common-cell profile captures the wide traffic at controlled cost. For a probability law over fixed widths, all fees remain explicit:

    A_mix(y,z)=integral A_d(y,z) dpi(d),
    integral A_mix dT <= [integral kappa(d)dpi(d)] S_n.       (O2)

More generally, a nonnegative mixture of total mass other than one has exactly the same formula with its actual unnormalized total cost. To cover the whole residual, one must prove an actual pointwise majorization of its allocation by a controlled multiple of A_mix, or an original integrated comparison with a separately source-paid error. No such comparison follows from low pe alone in this note.

For source-dependent adaptive rectangular partitions with nonuniform cell widths, the exact valid statement is

    integral A_partition dT
      <= E_partition sum_C kappa(d(C))
           [(16/3)beta(C)+(1+log B_n)nu(C)],                (O3)

provided each cell is an axis-aligned rectangle and the partition is fixed before receiver choice. Here A_partition is the actual common-cell probability. This retains true source conservation and permits a future input-dependent construction. A pair-dependent choice of d has not supplied a partition and cannot be substituted into (O2) or (O3).

The remaining geometric bridge can therefore be stated without changing sources: construct such an actual partition/overlap allocation for the original wide, low-pe, m>M traffic with root-polylog right side in (O3), and prove its uncovered original traffic has epsilon X plus root-polylog source price. Alternatively prove a clipped version of the actual common-parameter column estimate that uses the inverse-m height in the SAME receiver integral and is summable over m and the unique ratio bands. These alternatives identify the missing selection/overlap inequality; neither is asserted proved.

## 6. Quantified width-selection diagnostic and actual computation

The frozen-width requirement is substantive even before source histories enter. For a balanced displacement delta_i=t and desired A_d>=theta in (0,1), set v_i=-log(1-t/d_i). Then sum_i v_i<=-log theta. The function

    f(v)=log(1+(t/a)/(1-exp(-v)))

is decreasing and convex on v>0 (its derivative is negative, and differentiating once more gives a positive derivative). Jensen gives the exact lower bound

    sum_i log(1+d_i/a)
      >= n log(1+(t/a)/(1-theta^(1/n))).                   (O4)

Equality holds for equal widths d_i=t/(1-theta^(1/n)). This is a scalar capacity diagnostic, not a claim that such displacement traffic is an admissible FULL original example. It records the fee a frozen common-grid overlap method must pay if it insists on a uniform capture fraction at that displacement. The independent global scale-envelope cap can reduce this fee to order n, but not to root order by this calculation alone.

Python Fraction actually checked the exact intersection formula against direct interval endpoints in 60 rational cases (A in {1/2,1,3/2,2}, R in {1/2,1,2}, delta in {0,1/4,1/2,1,2}); all passed. Python math evaluated the equality case in (O4) with a=1, t=1/sqrt(n), theta=1/2 for n=1,2,16,256,4096. The respective log-width costs were 1.098612, 2.455894, 30.896648, 814.798986, 18580.487801; the calculated overlap was 0.5 in every case. These checks validate scalar formulas only, not the original wide theorem or a numerical counterexample.

## Bounded outcome

The exact overlap allocation (T1), its full anisotropic branch (T2), and the adaptive-partition cost identity (O3) are legitimate source-paid statements using the independently supplied rectangular weak input. They are available on the original wide low branch and retain every actual cap. They do not prove a uniform wide coverage fraction. The broad low-pe/high-continuous bottleneck remains the original common-receiver overlap selection with source-conserving adaptive geometry; all extra high score/clock costs remain outside this raw theorem. No global closure is claimed.
