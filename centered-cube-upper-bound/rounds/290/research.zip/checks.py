#!/usr/bin/env python3
"""R290 finite rectangular-capacity and frozen-width optimization diagnostics."""
import json,random
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp
R=random.Random(29020261017)
def bisect(fn,lo,hi,dp):
 for _ in range(4*dp+30):
  mid=(lo+hi)/2
  if fn(mid)>0:hi=mid
  else:lo=mid
 return (lo+hi)/2

def rectangle(case,dp):
 with mp.workdps(dp):
  aa,dd,ee,bb=case;a=mp.mpf(aa);ds=list(map(mp.mpf,dd));n=len(ds);ep=mp.mpf(ee);b=a*mp.mpf(bb)
  lgG=sum(mp.log(a+d) for d in ds)/n;lr=lgG+mp.log1p(ep);r=mp.exp(lr)
  A=bisect(lambda x:sum(mp.log(x+d) for d in ds)/n-lr,a,r,dp)
  lv=sum(mp.log(A+d) for d in ds);volumeerr=abs(lv-n*lr)/max(1,abs(n*lr))
  fee=n*mp.log(r/A);sumfee=sum(mp.log1p(d/A) for d in ds);cap=sum(mp.log1p(d/a) for d in ds)
  err=abs(fee-sumfee)/max(1,abs(sumfee));assert volumeerr<mp.mpf('1e-30') and err<mp.mpf('1e-30')
  assert A>=a*(1-mp.mpf('1e-35')) and fee<=cap+mp.mpf('1e-30')*max(1,cap)
  # A point beyond an expanded-cell face forces separation >A/2 in that coordinate.
  for d in ds:
   gap=A/2+A/100 # algebraically (A+d)/2+A/100-d/2; avoid large-width cancellation
   assert gap>A/2
  # b>a is allowed; b imposes no extra restriction in the arbitrary-scale scalar construction.
  return tuple(+v for v in [A,r,volumeerr,err,fee,cap,b/a])
def rectangle_stage(count,spread,maxdim):
 cases=[]
 for j in range(count):
  n=1+j%maxdim;a='1e'+str(R.randint(-spread,spread));ds=['0' if (j+i)%7==0 else '1e'+str(R.randint(-spread,spread)) for i in range(n)]
  cases.append((a,ds,['1e-12','1e-6','.1','10'][j%4],['1','2','1000000'][j%3]))
 prec=mp.mpf(0);ve=mp.mpf(0);fe=mp.mpf(0);ratio=mp.mpf(0)
 for c in cases:
  x=rectangle(c,40);y=rectangle(c,60)
  with mp.workdps(90):
   prec=max(prec,*[abs(u-v)/max(1,abs(v)) for u,v in zip(x,y)])
   ve=max(ve,x[2],y[2]);fe=max(fe,x[3],y[3]);ratio=max(ratio,y[4]/y[5] if y[5] else 0)
 assert prec<mp.mpf('1e-28')
 return {'cases':count,'precision_runs':2*count,'max_dimension':maxdim,'width_and_a_exponents':[-spread,spread],'max_normalized_log_volume_error':mp.nstr(ve,12),'max_normalized_fee_identity_error':mp.nstr(fe,12),'max_normalized_40_vs_60_error':mp.nstr(prec,12),'max_fee_to_log_capacity_ratio':mp.nstr(ratio,12),'max_forcing_or_capacity_violation':'0','kappa_definition':'2+sum(log(1+d_i/a))','mass_over_u_definition':'r^n (evaluated in logarithms)'}

def optimal(e,dp):
 with mp.workdps(dp):
  e=list(map(mp.mpf,e));n=len(e);eta=mp.mpf('.5')
  def ts(lam):return [(2*x/lam)/(mp.sqrt(x*x+4*x/lam)+x) for x in e]
  lower=max(e)/(eta*(eta+max(e)))
  lam=mp.exp(bisect(lambda loglam:eta-sum(ts(mp.exp(loglam))),mp.log(lower),mp.log(mp.mpf(n)/eta),dp))
  t=ts(lam);cost=sum(mp.log1p(x/y) for x,y in zip(e,t));equal=sum(mp.log1p(x/(eta/n)) for x in e)
  equalwidth=n*mp.log1p(sum(e)/eta)
  assert cost<=equalwidth+mp.mpf('1e-30')*max(1,equalwidth)
  sumerr=abs(sum(t)-eta)
  kkterr=max(abs(x/(y*(y+x))-lam)/max(1,abs(lam)) for x,y in zip(e,t))
  assert sumerr<mp.mpf('1e-30') and kkterr<mp.mpf('1e-30')
  assert cost<=equal+mp.mpf('1e-30')*max(1,equal)
  # Deterministic feasible nonconstant multiplicative perturbations.
  for shift in [0,1,3]:
   v=[y*(1+mp.mpf((i+shift)%7)/10) for i,y in enumerate(t)];total=sum(v);v=[y*eta/total for y in v]
   pcost=sum(mp.log1p(x/y) for x,y in zip(e,v));assert cost<=pcost+mp.mpf('1e-30')*max(1,pcost)
  return tuple(+x for x in [cost,equal,sumerr,kkterr,lam,equalwidth])
def optimization(ns,spread):
 profiles=[]
 for n in ns:
  profiles.extend([(n,'dense',['1']*n),(n,'one_axis',[('1' if i==0 else '1e-'+str(spread)) for i in range(n)]),(n,'multiscale',['1e'+str(-spread+((i*7)%(2*spread+1))) for i in range(n)])])
 rows=[];pe=mp.mpf(0);se=mp.mpf(0);ke=mp.mpf(0)
 for n,name,e in profiles:
  x=optimal(e,40);y=optimal(e,60)
  with mp.workdps(90):
   err=max(abs(a-b)/max(1,abs(b)) for a,b in zip(x,y));assert err<mp.mpf('1e-28');pe=max(pe,err);se=max(se,x[2],y[2]);ke=max(ke,x[3],y[3])
   rows.append({'dimension':n,'profile':name,'optimized_log_capacity':mp.nstr(y[0],18),'equal_allocation_log_capacity':mp.nstr(y[1],18),'lambda':mp.nstr(y[4],18),'equal_width_log_capacity':mp.nstr(y[5],18)})
 return {'cases':len(profiles),'precision_runs':2*len(profiles),'perturbations_per_run':3,'eta':'1/2','max_normalized_40_vs_60_error':mp.nstr(pe,12),'max_allocation_sum_error':mp.nstr(se,12),'max_normalized_KKT_error':mp.nstr(ke,12),'rows':rows,'max_comparison_violation':'0','stable_formula':'t_i=(2 e_i/lambda)/(sqrt(e_i^2+4 e_i/lambda)+e_i)'}
def exact_probability(ns):
 count=0
 for n in ns:
  for pattern in ['dense','one_axis','unequal']:
   weights=[1]*n if pattern=='dense' else ([1000]+[1]*(n-1) if pattern=='one_axis' else [R.randint(1,100) for _ in range(n)])
   total=sum(weights);ts=[F(w,2*total) for w in weights];d=[F(R.randint(1,100),R.randint(1,100)) for _ in weights];delta=[x*y for x,y in zip(ts,d)]
   assert sum(delta[i]/d[i] for i in range(n))==F(1,2)
   p=F(1)
   for i in range(n):p*=1-delta[i]/d[i]
   assert p>=1-sum(ts)==F(1,2);count+=1
 return {'cases':count,'exact_eta':'1/2','max_exact_probability_violation':'0'}
settings=[('initial',12,2,5,[1,2,5]),('anisotropic_stress',24,12,12,[1,10,50]),('expanded',36,30,30,[1,100,1000])]
stages=[]
for name,count,spread,dim,ns in settings:
 stages.append({'name':name,'rectangular_threshold':rectangle_stage(count,spread,dim),'optimized_widths':optimization(ns,spread),'shifted_grid':exact_probability(ns)})
out={'status':'PASS','seed':29020261017,'scope':'Finite ordinary mpmath40/60 rectangular threshold and convex frozen-width scalar diagnostics, plus exact Fraction same-cell probability. Zero widths appear in threshold checks as a limit geometry; optimization envelopes remain strictly positive. No FULL/FIRST/source/history certificate or asymptotic order inference.','stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
