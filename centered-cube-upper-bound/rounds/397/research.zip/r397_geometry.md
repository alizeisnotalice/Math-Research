# R397 — External-lift column screening; no new payment

This is a bounded checkpoint on the actual R391 core, using only R390–391 and the R392 ledger. All original labels, physical clocks, strict mass past, spatial/rank gates and fractional marks remain frozen. No additional receiver qualifies for an original history. The target root-order budget has **not** been proved.

## Candidate screened

Write γ=γ_core, G=γ(E×E), and q_u a_u du=γ(du,E), so 0≤a_u≤β. The specific proposed geometric improvement was a constant column bound for the *external witness receiver*, retaining the subtraction f(Q_u∩Q_w∩Q_v), rather than replacing its arrival kernel by the ordinary capture kernel. This would control a genuine reuse mechanism; it is not furnished by the old column bound for the original endpoint v. Even such a new column estimate would require a separate source/terminal settlement before giving the requested W price.

For the R390 lift let c=9/49; on the present support E_uv>ch. Its exact w-arrival measure is A(w)dw, where

 A(w) = (1/m_w) ∫ γ(du,dv) 1_{m_w<m_u/K}
        [f(Q_u∩Q_w)−f(Q_u∩Q_w∩Q_v)]/(m_u E_uv).       (1)

All terms are finite nonnegative before writing the bracket as a difference. The equality follows by Tonelli from the normalized R390 lift, and

                  ∫ A(w)dw = ∫ f(z)L_ext(z)dz = G.     (2)

Thus (2) is conservation, not a price. It cannot be entered into the ledger as an improvement.

## Precisely where the available estimate stops

Define the outgoing actual-edge occupancy

 D_out(z)=∫ γ(du,dv)c_u(z)/m_u
         =∫ a_u c_u(z)R_u^(−n)du.

Dropping the subtraction and the strict-w mass restriction in (1), and using E_uv≥ch, gives the rigorous but insufficient estimate

       A(w) ≤ (ch)^(−1) ∫ D_out(z)π_w(dz).              (3)

This is an estimate relative to actual **dw**. Relative to σ(dw)=q_wdw its right side has the additional divisor q_w. In particular, it is not the old K_cold column bound. The actual-center octave envelope gives D_out≤β A_n, hence only

       A(w)/q_w ≤ β A_n/(c h q_-).                     (4)

With frozen h=(1+√n)/(ε_0q_-), this is β ε_0 A_n/[c(1+√n)], of order √n in the octave regime. Finite strict-far chain depth does not turn (4) into a root-order source payment: no conserved terminal source measure or inherited history has been established, and multiplying these two bounds is not a proof.

The audited L4 estimate controls D_out in Lebesgue measure. Equation (3) samples it under the complete f-weighted π_w. It supplies no corresponding f-weighted column bound; inserting one would be a density assumption. The R391 clipping potential already accounts for the available Lebesgue moment and is not charged again here.

The exact geometric step still missing is a simultaneous control of (1), with its pair-dependent normalizer E_uv, that reduces repeated use of the same (u,z,w) across the original v traffic. Any such control must exploit the retained triple-intersection subtraction *at these same weights*, or exploit the original marks to settle the resulting excess. The known row/column bounds concern (u,v), whereas (1) sums over an additional w; neither full matching nor the lower bound E_uv≥ch relates their columns. The old core posterior property likewise concerns only endpoints of retained original edges. No estimate presently proves that witness w has that property.

This identifies a concrete first column inequality to investigate, rather than claiming that a normalized lift, finite chain length, or an Lp contraction pays G. The candidate has not been proved, and no nontrivial new paid branch or complete complement split is asserted.

## Actual calculation and ledger

Executed `python3 /tmp/r397_geometry_check.py`:

    PASS {'normalization': 7, 'columns': 70,
          'subtraction': 70, 'domination': 70} total 217

These are exact Fraction checks of (1)–(3) for seven piecewise-constant source densities on eight unit source cells, actual interval incidences, exactly matched receiver masses, positive receiver quadrature, and strict rational far parameter K=2. They verify the source and receiver lift totals, the triple-intersection subtraction, and domination using the actual minimum E_uv. They do **not** verify native Lebesgue du, the frozen exponential K, the core or its history/spatial gates, or any improved column estimate. The analytic Tonelli proof above covers the actual field; the computation only checks its algebra and measures.

No fees or negative credits are added. The existing slot stays

 BH ≤ 2G_core + E387 X_q + [S390+8(1+√n)]W.

A future bound G_core≤εX_q+CW would contribute 2εX_q+2CW in this slot and 4Λ times the new core bound at the entrance. This checkpoint has no such bound and stops here.
