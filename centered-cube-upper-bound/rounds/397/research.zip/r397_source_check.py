from fractions import Fraction as F
from itertools import product

cnt={'switch_telescoping':0,'uniform_sum':0,'scalar_clipping':0}
def psi(f,x,s,T): return f*min(x,s)+min(f,T)*max(x-s,F(0))
for f,s in product((F(0),F(1,2),F(1),F(3),F(9)),(F(1,2),F(1),F(2))):
 for Ds in ((F(6),F(4),F(2),F(0)),(F(3),F(3),F(1),F(1)),(F(1),F(1,2),F(0),F(0))):
  for Ts in ((F(1,4),F(1),F(4)),(F(1),F(2),F(8))):
   loss=sum(psi(f,Ds[i],s,Ts[i])-psi(f,Ds[i+1],s,Ts[i]) for i in range(3))
   Bs=[(min(f,Ts[i])-min(f,Ts[i-1]))*max(Ds[i]-s,F(0)) for i in (1,2)]
   assert loss==psi(f,Ds[0],s,Ts[0])-psi(f,Ds[3],s,Ts[2])+sum(Bs)
   assert all(x>=0 for x in Bs)
   cnt['switch_telescoping']+=1
   assert sum(Bs)<=max(f-Ts[0],F(0))*max(Ds[0]-s,F(0))
   assert psi(f,Ds[0],s,Ts[0])+sum(Bs)<=f*Ds[0]
   cnt['uniform_sum']+=1
for f,D,s,T,M in product((F(0),F(1,2),F(2),F(8)),(F(0),F(1,2),F(2),F(5)),(F(1,2),F(1),F(3)),(F(1,4),F(1),F(4)),(F(2),F(5),F(8))):
 if D>M: continue
 split=f*min(D,s)+min(f,T)*max(D-s,F(0))+max(f-T,F(0))*max(D-s,F(0))
 assert split==f*D
 assert f*D<=s*f+T*D**4/s**3+M*max(f-T,F(0))
 cnt['scalar_clipping']+=1
print('PASS',cnt,'total',sum(cnt.values()))
