r397_n=[16 64 256 1024]; r397_A=2; r397_out=[];
for r397_k=1:numel(r397_n)
 r397_M=1+r397_n(r397_k)*log(2);
 for r397_F=[1 1e3 1e9]
  r397_t=[0 logspace(-12,0,10001)*r397_F];
  r397_b=(r397_A*r397_t).^(1/3)+r397_M*max(0,1-r397_t/r397_F);
  r397_exact=min(r397_M,(r397_A*r397_F)^(1/3));
  assert(abs(min(r397_b)-r397_exact)<1e-9*max(1,r397_exact));
  r397_out=[r397_out;r397_n(r397_k),r397_F,r397_exact,min(r397_exact,r397_M/2)/(1+sqrt(r397_n(r397_k)))];
 end
end
fprintf('n F clipping_bound bound_over_root\n'); fprintf('%d %.0e %.9g %.9g\n',r397_out.');
disp('R397: 12 scalar clipping optimizations PASS; abstract diagnostic only, not a cube realization.');
