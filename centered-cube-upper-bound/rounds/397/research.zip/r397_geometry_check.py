from fractions import Fraction as F
# Exact source-cell integration and receiver quadrature; not native du or core gates.
Q = [set(range(8)), set(range(6)), set(range(2,8))]
Q += [set(range(i,i+2)) for i in range(7)]
rw = [F(i+1,20) for i in range(len(Q))]
counts = dict(normalization=0, columns=0, subtraction=0, domination=0)
for k in range(1,8):
    f = [F(1+(k*i)%3) for i in range(8)]
    m = [sum(f[z] for z in q) for q in Q]
    mu = [rw[i]/m[i] for i in range(len(Q))]
    edges = [(u,v,F(1+u+v,100)) for u in range(3) for v in range(3,len(Q)) if m[u]>2*m[v] and Q[u]&Q[v]]
    E, Z = {}, {}
    for u,v,g in edges:
        Z[u] = [sum(mu[w] for w in range(len(Q)) if m[w]<m[u]/2 and z in Q[w]) for z in range(8)]
        E[u,v] = sum(f[z]*Z[u][z] for z in Q[u]-Q[v])/m[u]
        assert E[u,v]>0
    emin = min(E.values())
    L = [sum(g*Z[u][z]/(m[u]*E[u,v]) for u,v,g in edges if z in Q[u]-Q[v]) for z in range(8)]
    arrivals = []
    dout = [sum(g/m[u] for u,v,g in edges if z in Q[u]) for z in range(8)]
    for w in range(len(Q)):
        actual = sum(g*mu[w]*sum(f[z] for z in (Q[u]&Q[w])-Q[v])/(m[u]*E[u,v]) for u,v,g in edges if m[w]<m[u]/2)
        signed = sum(g*mu[w]*(sum(f[z] for z in Q[u]&Q[w])-sum(f[z] for z in Q[u]&Q[w]&Q[v]))/(m[u]*E[u,v]) for u,v,g in edges if m[w]<m[u]/2)
        assert actual == signed
        counts['subtraction'] += 1
        direct = sum(g*mu[w]*f[z]/(m[u]*E[u,v]) for u,v,g in edges if m[w]<m[u]/2 for z in (Q[u]&Q[w])-Q[v])
        assert actual == direct
        counts['columns'] += 1
        upper = rw[w]*sum(f[z]*dout[z] for z in Q[w])/(m[w]*emin)
        assert actual <= upper
        counts['domination'] += 1
        arrivals.append(actual)
    G = sum(g for u,v,g in edges)
    assert sum(f[z]*L[z] for z in range(8)) == G == sum(arrivals)
    counts['normalization'] += 1
print('PASS', counts, 'total', sum(counts.values()))
