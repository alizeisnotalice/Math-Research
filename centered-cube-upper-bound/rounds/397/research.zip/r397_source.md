# R397 — frozen density-threshold cascades and their switching cost

**Conclusion.** Raising the density cutoff can eventually delete every edge while keeping full f, q, masses and histories frozen. This does not provide a root price: the exact inter-stage switching cost remains. It is uniformly finite, bounded at the scale of the original traffic, so it should not be mislabeled as an uncontrolled infinite entropy. A directly verifiable density-tail criterion is available from the existing moment and clipping tools; it is not a new general cascade receipt.

## 1. Actual frozen field and one usable density-tail bound

Start with the actual R391 core γ, of cost G, and retain every original label. Every further operation below restricts existing endpoints only. Full f, m_u=f(Q_u), q_u, π_u=f c_u/m_u, selected cubes, physical clock and old marks are fixed. Let

D_A(z)=∫γ_A(du,dv)[c_u(z)/m_u+c_v(z)/m_v]=T_R^*s_A(z),
0≤s_A≤S,  ∫fD_A=2G_A,
∫D_A^4≤A G_A,  A=2C_*^4S³/q_-.

The factor 2 is the actual two-endpoint occupation. The real-center envelope also gives

D_A(z)≤M:=S A_n,  A_n=1+n log(b/a).                        (1)

Indeed c_u(z)/R_u^n≤1_{2||u−z||∞≤b}/max(a,2||u−z||∞)^n. Its integral in actual du is exactly bounded by 1+n log(b/a). This is a receiver-volume estimate, not a bound on the density of f.

Write W=∫f and E_f(T)=∫(f−T)_+. For any T>0 and s>0 the exact source decomposition is

fD=f min(D,s)+min(f,T)(D−s)_++(f−T)_+(D−s)_+.

Therefore, for any actual restricted flow γ_A,

2G_A≤sW+(AT/s³)G_A+M E_f(T).                               (2)

Choosing s=(AT)^(1/3) gives the explicit bound

G_A≤(AT)^(1/3)W+M E_f(T),
G_A≤inf_{T>0}{(AT)^(1/3)W+M E_f(T)}.                        (3)

No minimizer is asserted or needed. In particular, at any prescribed s>0,

E_f(s³/A)≤sW/M  implies  G_A≤2sW.                          (4)

For s=1+√n this is a root source price, with the full constants A,M retained in its verifiable hypothesis. It permits unbounded f; it does not assume a density cap. The R391 core contract does not imply (4), since it supplies high-density posterior concentration rather than a quantitative upper bound on this full-source tail.

Equation (3) is a useful optimized-threshold consequence of the already available L4 moment and source clipping, not a new mechanism for the arbitrary tail. In particular it must not be added to the same clipped-source payment twice. If (4) is verified and (3) is used to replace the unpaid core, the R392 ledger receives 2G_core≤4sW, hence an additional 4sW in BH and 8ΛsW at the original entrance. All old fees remain. No unconditional new ledger entry is made here.

## 2. Finite threshold cascade with the exact terminal potential

Fix θ∈(0,1), s>0 and increasing thresholds 0<T_0<T_1<.... At stage i start with A_i and run the full R391 deletion rule at threshold T_i on its actual surviving edge measure. Let A_{i+1} be that stage's limiting retained set, γ_i=1_{A_i²}γ, G_i=γ_i(E²), D_i=D_{A_i}. Thus A_i decreases; no source normalization or kernel is reconstructed.

Define

Ψ_T(z,x)=f(z)min(x,s)+min(f(z),T)(x−s)_+.

The old proof gives, for each stage,

θ(G_i−G_{i+1})≤∫[Ψ_Ti(z,D_i)−Ψ_Ti(z,D_{i+1})]dz.           (5)

The finite N-stage sum is exactly bounded by

θ(G_0−G_N)≤∫Ψ_T0(z,D_0)dz−∫Ψ_T(N−1)(z,D_N)dz
                     +Σ_{i=1}^{N−1}B_i,                  (6)

where the switching costs are the nonnegative quantities

B_i=∫[min(f,T_i)−min(f,T_{i−1})](D_i−s)_+ dz.               (7)

The terminal term in (6) has not been dropped or reused. The sign in (7) is essential: increasing the threshold increases the potential at a surviving occupancy, and that increase is not a deletion credit.

For a literal marked-edge representation set, with zero conventions on f=0 or D_i=0,

b_i(z)=[min(f,T_i)−min(f,T_{i−1})]/f(z) ·(1−s/D_i(z))_+.

Then 0≤b_i≤1 and exactly

B_i=∫γ_i(du,dv)[π_u(b_i)+π_v(b_i)].                         (8)

These are the unchanged full-f posteriors and the original surviving edge labels. The witness source in (8) is not substituted for an old transported source. Thus (8) records the actual endpoint/source cost of switching criteria rather than hiding it in a new normalized input.

The switching partial sums have the uniform bound

Σ_{i=1}^{N−1}B_i
 ≤∫[min(f,T_{N−1})−min(f,T_0)](D_0−s)_+dz
 ≤∫(f−T_0)_+(D_0−s)_+dz
 ≤M E_f(T_0).                                             (9)

Moreover the first two potential pieces and the last source remainder sum pointwise to fD_0, so

∫Ψ_T0(z,D_0)dz+Σ B_i≤∫fD_0=2G_0.                          (10)

This proves uniform finiteness with no assumption beyond L1 f and the actual occupation identity. It does not produce a small absorbable coefficient: using (10) in (6) only gives a traffic-scale bound.

## 3. Infinite thresholds do clear the core, but do not pay it

Suppose T_i→∞. Every w surviving stage i satisfies the R391 limiting posterior condition

π_w[1_{D_{i+1}≥s}(1−T_i/f)_+]≥1−θ,

and hence π_w[(1−T_i/f)_+]≥1−θ. Since f is finite almost everywhere for the original π_w, dominated convergence makes the last expression tend to zero. Thus the intersection of all A_i is null for the actual receiver marginal; countably many stage null sets cause no issue. Because γ has absolutely continuous endpoint marginals, G_N↓0.

Also D_N↓0 for f dz-almost every source: monotone convergence and ∫fD_N=2G_N prove this. The terminal term in (6) tends to zero, since

0≤Ψ_T(N−1)(z,D_N)≤f(z)D_N(z)≤f(z)D_0(z),

and fD_0 is integrable. Consequently the legitimate limit of (6) is

θG_0≤∫Ψ_T0(z,D_0)dz+Σ_{i≥1}B_i.                           (11)

Choose T_0=ρ θ s³/A with 0<ρ<1. The moment bound controls the first term by sW+ρ θG_0, leaving

(1−ρ)θG_0≤sW+Σ_{i≥1}B_i.                                  (12)

This is the exact missing summable inequality for this approach: a useful root theorem still requires a root-scale bound on the cumulative switching cost, or a smaller absorbable coefficient plus that source price. Formula (9) gives a tail-dependent price, but not such a universal one. Substituting (9) into (12) is weaker than the direct optimized-tail estimate (3). Therefore proving that the threshold cascade eventually empties the core is not an additional payment.

No conclusion is drawn that another joint geometric argument cannot bound (7). The present available identities merely do not provide that estimate. Changing the threshold schedule alone supplies no established uniform tail rate, and no claim of a logarithmic or finite-round fee follows from T_i→∞.

## 4. Local arithmetic check

The companion `/tmp/r397_source_check.py` uses only standard-library Fraction arithmetic. It verifies the finite telescoping identity, positive threshold-switch formula, uniform partial-sum bound, and the scalar clipped-moment bound used in (2). It does not simulate a full qualified geometric core or certify hypothesis (4). Counts are recorded below after the actual run. The native du and all history preservation follow from the analytic marked-edge identities above.

Actual run:

`PASS {'switch_telescoping': 90, 'uniform_sum': 90, 'scalar_clipping': 396} total 576`

All 576 checks used exact Fraction arithmetic. They certify the finite algebra only; no tail hypothesis or general root budget is inferred from them. Bounded delivery ends here.
