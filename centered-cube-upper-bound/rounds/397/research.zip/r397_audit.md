# R397 source-threshold and external-column audit — FINAL PASS

FINAL PASS for the exact threshold/switching and external-arrival identities, bounded source-tail consequence and honest no-payment presentation. No arbitrary-source root bound is certified. Only this file is edited. The independent reasoning below preceded the R397 author proof. Fix the same full f, actual gamma_core, original source/receiver fields and marks. Let G=gamma(E^2), D=T_R^*s, integral fD=2G, 0<=D<=M=S A_n, and integral D^4<=A G with A=2C_*^4S^3/q_-. These are inherited conditional tools; no new cube maximal theorem is assumed.

For W=integral f and E_f(T)=integral(f-T)_+, split at occupancy L>0 and density T>0:

    2G<=L W+M E_f(T)+(T/L^3) integral D^4
       <=L W+M E_f(T)+(AT/L^3)G.

For A>0 choose L=(AT)^(1/3), giving

    G<=(AT)^(1/3)W+M E_f(T)

for every T>0 and hence their infimum. This is a consequence of the inherited fourth moment/cap plus actual full-source matching, not a root estimate for arbitrary f. No measurable minimizing threshold is needed. If G=0 there is no residual. M=0 or A=0 forces D=0 (Lebesgue a.e in the latter case), hence G=0; W=0 likewise. All integrals are finite for the actual finite field. A fixed positive T is a density threshold on the existing full f, not a changed matched source. Tail E_f(T)->0 as T increases does not give a small total price, because the first term increases as T^(1/3).

For the fixed source potential Psi_T(d)=f min(d,s)+min(f,T)(d-s)_+, an increase of T at the same occupancy d creates the POSITIVE switching increment Delta min(f,T)(d-s)_+. It cannot be ignored when joining separately valid cascades. If nested edge restrictions give D_i<=D_0, then pointwise initial potential plus all increasing-threshold increments is <=fD_0; integrating gives at most 2G_0. The coefficient is not a contraction. Even if arbitrarily large thresholds empty the final core, a positive switching bill remains and no factor strictly below one is supplied to absorb it.

Reviewer actually ran 324 Fraction scalar checks of this clipping inequality and the initial-potential/switching upper bound on bounded arrays. They are finite arithmetic diagnostics, not native cube or cascade geometry. No author proof was read before this screen. The complete author and final integration audit follows. No general root claim is certified.


## Source-threshold proof and infinite-stage review

Read the full frozen r397_source.md and its complete check script. The inherited actual endpoint incidence satisfies D_A=T_R^*s_A, integral fD_A=2G_A, s_A<=S and integral D_A^4<=A G_A. The factor two is retained. The pointwise real-center bound D_A<=S[1+n log(b/a)] has the correct measure and no q divisor: D_A integrates s_A c_u/R_u^n against actual du. This bounds receiver geometry, not f density.

The three-term source split in §1 is exactly fD, all terms nonnegative. Using (D-s)_+<=D 1_{D>s}<=D^4/s^3 and min(f,T)<=T gives equation (2), and the specified s=(AT)^(1/3) proves (3). With the actual fixed positive constants A,M, the hypothesis E_f(s^3/A)<=sW/M indeed implies G_A<=2sW, but no general current-core source tail estimate proves it. If invoked conditionally, replacing 2G_core by 4sW and carrying the entrance coefficient to 8Lambda sW is correct. This is not an unconditional extra ledger entry or an independently chargeable second use of the same clipping moment.

The finite stages use a nested positive restriction of the ORIGINAL actual gamma. Full f, pi, m,q,J/clock and histories are not redefined. At each threshold the old endpoint-deletion argument pays against the full potential drop with the negative terminal term intact. Summing and changing thresholds yields exactly the POSITIVE B_i in (7). Formula (8) is the full-endpoint-posterior representation of that switching expense, with f=0/D_i=0 conventions correct. It supplies no new qualification for the old transported source or witness receiver.

The uniform switching bound follows from D_i<=D_0 and monotone min(f,T_i). Initial potential plus all switching costs is bounded by fD_0 pointwise after integrating, hence <=2G_0. Uniform finiteness is real and should not be mislabeled divergent entropy; it still does not give a coefficient strictly below one at the necessary deletion scale. If T_i increases without bound, dominated convergence under every unchanged pi_w makes the limiting-survival condition impossible. Countable stage-null sets and absolutely continuous actual endpoint marginals justify G_N down to zero. The terminal potential vanishes by domination by fD_0. What remains is the positive switching sum, not a free root price.

Equation (12) with T0=rho theta s^3/A has the correct coefficient (1-rho)theta. Its tail-dependent consequence from (9) is weaker than the direct fixed-T bound, and threshold scheduling alone yields no rate for the unknown density tail. Core emptiness is therefore not mistaken for proof of payment.

Reviewer actually ran r397_source_check.py: exit 0, 576 Fraction checks, split 90 switch telescoping, 90 uniform sum, 396 scalar clipping. They check finite algebra and not actual core geometry/tail condition. The preceding reviewer-only 324 inline checks were execution-only preliminary scalar diagnostics; no separate file was saved or counted in the parent's 576+217. They are redundant to the supplied reproducible source checks and no general proof relies on them.

## Actual external-arrival geometry and measure review

Read r397_geometry.md and its entire script, and reread the needed R390 geometric lift formulas. The current core is a positive restriction of that frozen original support; the convenient lower E_uv>(9/49)h uses its stated fixed D=2, epsilon0<=1/2/live-dimension conditions. It is not a parameter-free inequality for arbitrary cores. The exact normalized additional witness probability is over the external source z outside Q_v and actual smaller receiver w, with density f c_u(1-c_v)c_w/(m_u E_uv) relative to dz dmu(w).

Projecting that same lift onto actual dw gives precisely the displayed A(w), including 1/m_w and the pair-specific E_uv. The triple intersection subtraction is genuinely f(Qu intersect Qw outside Qv), a nonnegative finite source quantity. Tonelli proves integral A(w)dw=G and integral f L_ext=G. This is cost conservation, not a W payment, and the new z/w laws are not original transported-source or history laws.

Dropping the subtraction and strict-w mass gate gives A(w)<=(ch)^(-1) E_(pi_w)D_out. This is a density with respect to dw. Dividing by q_w is REQUIRED for a density relative to sigma=qdw. Original outgoing capacity gives D_out=integral a_u c_u/R_u^n du<=beta A_n and hence the displayed beta A_n/(ch q_-) bound. In the synchronized h this grows at order sqrt(n) in an octave, and neither finite mass-chain depth nor the old (u,v) column bound supplies an external-w source/terminal settlement. L4 Lebesgue occupation does not become an f-weighted posterior bound. Keeping all triple weights, normalizers and reuse is still the missing joint estimate.

Reviewer actually ran r397_geometry_check.py: exit 0, 217 Fraction checks (7 normalization and 70 each columns, subtraction, domination). These use eight actual source cells/interval incidence, exactly matched masses, receiver QUADRATURE and rational K=2. They do not realize native Lebesgue receiver du, exponential K, synchronized old gates or a qualified core. The note explicitly distinguishes that finite algebra from its analytic actual-field identity. The script's actual arrival value is a marginal mass at the quadrature receiver (contains its rw), consistent with the continuous dw-density statement when integrated.

## MATLAB scalar tool and final report scope

Read r397_matlab_check.m and its recorded output; this reviewer did NOT rerun MATLAB. The parent reports the actual 12-case local MATLAB execution separately. The test fixes an abstract A=2, M=1+n log2 and mass-one constant-density F, not the audited but numerically unspecified C_* or an actual geometric core.

Analytically its tail is (1-T/F)_+. On [0,F] the proposed bound (AT)^(1/3)+M(1-T/F) is concave, and after F it increases. Thus the infimum over T>0 is min(M,(AF)^(1/3)); T=0 in the grid denotes the limiting endpoint. The independently available G<=M/2 is also correctly retained in the displayed bound/root column. The finite grid including endpoints verifies this known scalar formula in ordinary double precision; it is not an interval certificate, a modeled original G, or a cube counterexample. A linear-in-n diagnostic upper expression cannot itself prove impossibility of a different root geometric bound.

Read final main and readme. They correctly record 576+217 Fraction checks, MATLAB's 12 scalar cases separately, no data-based model-billing comparison, the finite receiver-quadrature limitation, the unchanged full field and the missing joint source budget. The source-tail condition is not assumed for arbitrary L1 input; increasing T to make the tail small also increases the moment term. No new X absorption, W receipt, reusable square credit or multistep history transition is claimed.

The r392 ledger remains unchanged: BH<=2G_core+E387 X_q+[S390+8(1+sqrt(n))]W and entrance coefficient 4Lambda on the unpaid core. A future proven bound must use that actual core and its original marks/fees. FINAL PASS certifies the displayed identities, conditional tail estimate and honest bounded outcome only. The general root source budget is unproved.

## Frozen SHA256 bindings

The historical dependencies below supply inherited definitions, not a fresh re-audit of all prior reductions or the external Lp theorem.

- `/tmp/r397_main.md`: `c4c9c14e0e1f65b4bd9244db3a50ac4cf3793122192701c5816698eca8c481b1`
- `/tmp/r397_readme.md`: `0a14c0ec18a9b963155d3adebe2fbc9dbd8f31425adae42eea39816fe2497dbe`
- `/tmp/r397_source.md`: `897f5256b56b482c9f964a690471de940dd771022048912f92ebf5fb6ff9381a`
- `/tmp/r397_source_check.py`: `3bc702006fbeeceb397e970189f2558c07dcf30b74ac036aff19a55bcf26b7db`
- `/tmp/r397_source.result.txt`: `a2e7d9d9815e9f0cc234fec45b9df0edc386098edf22045692d0b64077b18e8f`
- `/tmp/r397_geometry.md`: `3426b79b1d221e0ad37d5f349cfc7b9b77443ae8eaedea7d907332b5fb8f79de`
- `/tmp/r397_geometry_check.py`: `40a288e98ac3e61f78ec2ccac6b12fc1f1f272414202905efc9e7d1f0d707c59`
- `/tmp/r397_geometry.result.txt`: `02cfc5cbb3500c1774dedde9a608b40122f8102b75e4550b7c309990a0df7898`
- `/tmp/r397_matlab_check.m`: `a0baf63a99914d6383f69591dde0870c7e20e47d6e5ff9bb29e2489488ae896e`
- `/tmp/r397_matlab.result.txt`: `f9dc8461577b5c3bc048fb769eea5e6549123fdd3751cfc297ccc7eb823203b7`
- `/tmp/r390_geometry.md`: `4cc51254b6d0314500888c61d65ff09c43890a50efdda600c05fae75bff45b34`
- `/tmp/r391_geometry.md`: `1ccdc3446df5d157fcf6700f32d3790d65c98c48127318a5acd951a110290c23`
- `/tmp/r392_ledger.md`: `4031079b6dcb0660da0460e316c19e4d71ff2dff055ba616aa41a4d376cc79f1`
