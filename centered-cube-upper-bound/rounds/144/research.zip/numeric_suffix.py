#!/usr/bin/env python3
"""Exact suffix certificates for three frozen R136 six-source time models only."""
import sys,json,hashlib,datetime,importlib.util,time
from pathlib import Path
from fractions import Fraction as Q
sys.set_int_max_str_digits(0)
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'centered_cube_round136_20261014/active_traffic_v2.json'
PRIM=ROOT.parent/'centered_cube_round143_20261015/numeric_flux.py'
spec=importlib.util.spec_from_file_location('frozen_primitive',PRIM); old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def m(x):return mp.mpf(x.numerator)/x.denominator if isinstance(x,Q) else mp.mpf(x)
def dec(x,n=45):return mp.nstr(m(x),n)
def ex(x):return {'numerator':str(x.numerator),'denominator':str(x.denominator)}
def val(x):return {'exact':ex(x),'decimal':dec(x)}
def suffix(z):
 out=[Q(0)]*(len(z)+1)
 for l in range(len(z)-1,-1,-1):out[l]=out[l+1]+z[l]
 return out
def matrix(segs,nu,dps):
 with mp.workdps(dps):
  T=[[mp.mpf(0) for j in nu] for i in nu]
  for s in segs:
   lo,hi,ks,cs=s['lo'],s['hi'],s['k'],s['c'];levels=sorted(set(ks));group={k:sum(nu[i]*cs[i] for i in range(6) if ks[i]==k) for k in levels}
   if len(levels)==1:continue
   if len(levels)==2:
    low,high=levels;d=high-low;A,B=group[high],group[low];z0,z1=lo**(-d),hi**(-d);fac=(z0-z1)/((A*z0+B)*(A*z1+B))
    for i in range(6):
     for j in range(6):
      if ks[i]>ks[j]:T[i][j]+=m(nu[i]*nu[j]*cs[i]*cs[j]*fac)
   else:
    assert len(levels)==3 and levels==[0,8,16]
    A,B,C=[group[k] for k in reversed(levels)];d=8
    a=old.primitive(m(lo)**d,A,B,C);b=old.primitive(m(hi)**d,A,B,C);ints=[x-y for x,y in zip(b,a)];assert min(ints)>0
    for i in range(6):
     for j in range(6):
      if ks[i]>ks[j]:idx={(2,1):0,(2,0):1,(1,0):2}[(levels.index(ks[i]),levels.index(ks[j]))];T[i][j]+=m(nu[i]*nu[j]*cs[i]*cs[j])*ints[idx]
  return [[mp.nstr(v,dps) for v in row] for row in T]
def case(c):
 nu=[Q(a['nu']) for a in c['atoms']];segs=[dict(lo=Q(s['lo']),hi=Q(s['hi']),k=s['k'],c=[Q(v) for v in s['c']]) for s in c['score_segments']]
 breaks=[segs[0]['lo']]+[s['hi'] for s in segs];assert breaks==list(map(Q,c['time_breakpoints']))
 for l in range(len(segs)-1):assert segs[l]['hi']==segs[l+1]['lo']
 e=[];q=[];joins=[]
 for s in segs:
  ee=[sum(nu[i]*s['c'][i]*t**(-s['k'][i]) for i in range(6)) for t in [s['lo'],s['hi']]];assert 0<ee[1]<=ee[0];e.append(ee);q.append([v**-2 for v in ee])
 for l in range(len(segs)-1):
  joins.append(dict(at=val(breaks[l+1]),w_right_minus_left=[val(segs[l+1]['c'][i]*breaks[l+1]**(-segs[l+1]['k'][i])-segs[l]['c'][i]*breaks[l+1]**(-segs[l]['k'][i])) for i in range(6)],e_right_minus_left=val(e[l+1][0]-e[l][1]),q_right_minus_left=val(q[l+1][0]-q[l][1])))
 vp=sum(b-a for a,b in q)+sum(max(q[l+1][0]-q[l][1],Q(0)) for l in range(len(q)-1));vm=sum(max(q[l][1]-q[l+1][0],Q(0)) for l in range(len(q)-1))
 low=matrix(segs,nu,400);high=matrix(segs,nu,500);pairs=[];maxerr=mp.mpf(0)
 for i in range(6):
  for j in range(6):
   inc=[]
   for s in segs:
    d=s['k'][i]-s['k'][j];p=s['k'][i]+s['k'][j];inc.append(d*s['c'][i]*s['c'][j]*(s['lo']**(-p)-s['hi']**(-p))/p if p else Q(0))
   fs=suffix(inc);M=max(fs);mn=min(fs);assert M>=0 and mn<=0
   saved=next(z for z in c['pairs'] if z['v']==c['atoms'][i]['name'] and z['z_prime']==c['atoms'][j]['name']);assert bool(M>0)==saved['Psi']
   maximum_breaks=[l for l,v in enumerate(fs) if v==M];plateaus=[l for l,v in enumerate(inc) if v==0 and fs[l]==M]
   lower=nu[i]*nu[j]*(fs[0]*q[0][0]+mn*vp-M*vm);upper=nu[i]*nu[j]*(fs[0]*q[0][0]+M*vp-mn*vm);weak=nu[i]*nu[j]*(M*q[-1][1]+(M-mn)*vm)
   P=mp.mpf(high[i][j]);N=mp.mpf(high[j][i]);S=P-N
   err=max(abs(P-mp.mpf(low[i][j]))/max(abs(P),mp.mpf('1e-1000')),abs(N-mp.mpf(low[j][i]))/max(abs(N),mp.mpf('1e-1000')));maxerr=max(maxerr,err)
   assert S<=m(upper)+mp.mpf('1e-90')*max(abs(S),abs(m(upper)),mp.mpf('1e-1000'));assert S>=m(lower)-mp.mpf('1e-90')*max(abs(S),abs(m(lower)),mp.mpf('1e-1000'))
   pairs.append(dict(v=c['atoms'][i]['name'],u=c['atoms'][j]['name'],good_bad_eligible=saved['good_bad_eligible'],Psi_exact=M>0,Psi_saved=saved['Psi'],Psi_agreement=True,increments=[val(v) for v in inc],suffix_values=[val(v) for v in fs],max_positive_suffix=val(M),min_suffix=val(mn),maximum_break_indices=maximum_breaks,maximum_times=[val(breaks[l]) for l in maximum_breaks],maximum_plateau_segment_indices=plateaus,saved_suffix_max_abs_difference=dec(max(abs(v-Q(w)) for v,w in zip(fs,saved['suffix_values'])),80),normalized_positive_flow=dec(P,100),normalized_negative_flow=dec(N,100),normalized_signed_flow=dec(S,100),normalized_400_500_relative_difference=dec(err,30),stieltjes_lower=val(lower),stieltjes_upper=val(upper),positive_envelope_upper=val(weak),signed_over_M_nunu_qh=dec(S/m(nu[i]*nu[j]*M*q[-1][1])) if M else None,upper_over_signed=dec(m(upper)/S) if S>0 else None,positive_flow_over_M_nunu_qh=dec(P/m(nu[i]*nu[j]*M*q[-1][1])) if M else None))
 assert maxerr<mp.mpf('1e-80')
 # Frozen original rho, terminal good versus terminal bad. All sums carry original nu.
 f=[Q(a['rho']) if a['good'] else Q(0) for a in c['atoms']];Dplus=Dminus=PSplus=PSminus=mp.mpf(0);B=[Q(0)]*len(breaks)
 for i in range(6):
  for j in range(6):
   r=pairs[6*i+j];dif=f[i]-f[j]
   if dif>0:
    Dplus+=m(dif)*mp.mpf(high[i][j]);Dminus+=m(dif)*mp.mpf(high[j][i])
    if r['Psi_exact']:PSplus+=m(dif)*mp.mpf(high[i][j]);PSminus+=m(dif)*mp.mpf(high[j][i])
   if c['atoms'][i]['good'] and not c['atoms'][j]['good'] and r['Psi_exact']:
    inc=[Q(int(z['exact']['numerator']),int(z['exact']['denominator'])) for z in r['increments']];pp=suffix([max(v,Q(0)) for v in inc]);nn=suffix([max(-v,Q(0)) for v in inc])
    for l in range(len(B)):B[l]+=nu[i]*nu[j]*(Q(c['atoms'][i]['rho'])*pp[l]-nn[l])
 caps=[]
 for l in range(len(breaks)):
  ee=[e[0][0]] if l==0 else ([e[-1][1]] if l==len(breaks)-1 else [e[l-1][1],e[l][0]])
  caps.append(max(max(B[l],Q(0))/(e[-1][1]*v) for v in ee))
 return dict(id=c['id'],n=c['n'],nu_exact=[val(v) for v in nu],nu_total=val(sum(nu)),breakpoints=[val(v) for v in breaks],segments=[dict(lo=val(s['lo']),hi=val(s['hi']),k=s['k'],c=[val(v) for v in s['c']],e_endpoints=[val(v) for v in e[l]],q_endpoints=[val(v) for v in q[l]]) for l,s in enumerate(segs)],joins=joins,q_positive_variation=val(vp),q_negative_jump_variation=val(vm),pairs=pairs,normalized_precision_dps=[400,500],max_relative_precision_difference=dec(maxerr,40),original_good_rho_graph=dict(full_positive=dec(Dplus),full_negative=dec(Dminus),full_signed=dec(Dplus-Dminus),Psi_positive=dec(PSplus),Psi_negative=dec(PSminus),Psi_signed=dec(PSplus-PSminus),missing_signed=dec((Dplus-Dminus)-(PSplus-PSminus))),joint_original_good_bad_Balpha=dict(breakpoint_values=[val(v) for v in B],breakpoint_caps=[val(v) for v in caps],max_breakpoint_cap=val(max(caps)),is_continuous_time_supremum=False,scope='Only breakpoint diagnostic; no interior critical-point search'),summary=dict(pair_count=36,Psi_count=sum(r['Psi_exact'] for r in pairs),positive_flow_edges=sum(mp.mpf(r['normalized_positive_flow'])>0 for r in pairs),negative_signed_Psi_edges=sum(r['Psi_exact'] and mp.mpf(r['normalized_signed_flow'])<0 for r in pairs),all_Psi_agree=True))
def saved_I1_pressure(c, certified):
 recpath=ROOT.parent/'centered_cube_round142_20261015/numeric_receiver.json';fluxpath=ROOT.parent/'centered_cube_round143_20261015/numeric_flux.json'
 rec=json.loads(recpath.read_text())['cases']['I1'];saved=next(r for r in json.loads(fluxpath.read_text())['cases']['I1']['records'] if r['id']==1871)
 nu=[Q(int(v['numerator']),int(v['denominator'])) for v in rec['nu_exact']];f=list(map(Q,saved['f_saved']));T=[[Q(0) for j in range(6)] for i in range(6)]
 for s in c['score_segments']:
  lo,hi=Q(s['lo']),Q(s['hi']);ks=s['k'];cs=list(map(Q,s['c']));levels=sorted(set(ks))
  if len(levels)==1:continue
  assert len(levels)==2
  low,high=levels;d=high-low;A=sum(nu[i]*cs[i] for i in range(6) if ks[i]==high);B=sum(nu[i]*cs[i] for i in range(6) if ks[i]==low);z0,z1=lo**(-d),hi**(-d);fac=(z0-z1)/((A*z0+B)*(A*z1+B))
  for i in range(6):
   for j in range(6):
    if ks[i]>ks[j]:T[i][j]+=nu[i]*nu[j]*cs[i]*cs[j]*fac
 full=sum(f[i]*(T[i][j]-T[j][i]) for i in range(6) for j in range(6));ps=sum(f[i]*(T[i][j]-T[j][i]) for i in range(6) for j in range(6) if certified['pairs'][6*i+j]['Psi_exact']);missing=full-ps
 assert full<0 and ps>0 and missing<full
 return dict(scope='One existing I1 receiver pressure record, not a new sample or 6951-row rerun; uses its modified nu, separate from original-R136-nu results',receiver_input_sha256=sha(recpath),flux_input_sha256=sha(fluxpath),saved_record_id=1871,main_gates_pass=saved['main_gates_pass'],accepted_positive=saved['accepted_positive'],f_exact=[val(v) for v in f],nu_exact=[val(v) for v in nu],complete_source_signed=val(full),Psi_source_signed=val(ps),missing_Psi_source_signed=val(missing),saved_complete_signed=saved['endpoint_difference'],comparison_to_saved=dec(full-Q(saved['Dplus'])+Q(saved['Dminus']),80),geometry_recertified=False)
def main():
 mp.mp.dps=500;start=time.monotonic();src=json.loads(SRC.read_text());out=dict(status='running',source_sha256=sha(SRC),primitive_sha256=sha(PRIM),script_sha256=sha(Path(__file__)),plan_sha256=sha(ROOT/'numeric_suffix_plan.md'),scope='R136 I1/I2/P1 original saved nu, exact serialized finite time model only',new_x_samples=0,new_receiver_samples=0,old_6951_rows_recomputed=0,arithmetic='Exact Fraction suffix/envelopes; normalized analytic kernels 400/500 mp digits',cases=[],stages=[])
 for cid,stage in [('I1','initial exploration and known missing-Psi pressure'),('I2','expanded check'),('P1','expanded mixed-score check')]:
  row=case(next(c for c in src['cases'] if c['id']==cid));out['cases'].append(row);out['stages'].append(dict(case=cid,stage=stage,completed=True,summary=row['summary']));
  if cid=='I1':
   out['selected_saved_I1_pressure']=saved_I1_pressure(next(c for c in src['cases'] if c['id']=='I1'),row);out['stages'].append(dict(case='I1:1871',stage='known missing-Psi pressure',completed=True))
  print(cid,row['summary'],'graph',row['original_good_rho_graph'],'cap',row['joint_original_good_bad_Balpha']['max_breakpoint_cap']['decimal'],flush=True)
 out.update(status='completed',elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),summary=dict(exact_pair_certificates=108,all_Psi_agree=True,FULL=False,general_geometry_verified=False))
 (ROOT/'numeric_suffix.json').write_text(json.dumps(out,ensure_ascii=False,separators=(',',':'))+'\n');print('completed',out['elapsed_seconds'],flush=True)
if __name__=='__main__':main()
