from pathlib import Path
from fractions import Fraction as F
import json,sys,hashlib
sys.set_int_max_str_digits(0)
r=Path(__file__).resolve().parent
src=r.parent/'centered_cube_round136_20261014/active_traffic_v2.json'
s=json.loads(src.read_text());d=json.loads((r/'numeric_suffix.json').read_text())
def q(x):return F(int(x['exact']['numerator']),int(x['exact']['denominator']))
count=0
for c in s['cases']:
 if c['id'] not in {v['id'] for v in d['cases']}:continue
 cert=next(v for v in d['cases'] if v['id']==c['id'])
 for i in range(6):
  for j in range(6):
   inc=[]
   for seg in c['score_segments']:
    lo,hi=F(seg['lo']),F(seg['hi']);ki,kj=seg['k'][i],seg['k'][j];p=ki+kj
    val=F(0) if p==0 else F(ki-kj,p)*F(seg['c'][i])*F(seg['c'][j])*(lo**(-p)-hi**(-p))
    inc.append(val)
   f=[sum(inc[k:]) for k in range(len(inc)+1)]
   row=cert['pairs'][i*6+j]
   assert [q(x) for x in row['suffix_values']]==f
   assert q(row['max_positive_suffix'])==max(F(0),*f)
   assert row['Psi_exact']==(max(f)>0)==row['Psi_saved']
   count+=1
# Three scalar stress stages, exact rational shared-capacity inequality.
stages={}
for name,den,etamax in [('initial',4,4),('pressure',16,16),('expanded',31,128)]:
 ncheck=0
 for ai in range(den+1):
  a=F(ai,den)
  for bi in range(den*2+1):
   b=F(bi,den)
   for eta in [F(1,etamax),F(1),F(etamax)]:
    for fraction in [F(0),F(1,2),F(1)]:
     sh=b/eta*fraction;rho=max(a-b,0)
     assert rho*sh<=a*a/(4*eta)
     ncheck+=1
 stages[name]=ncheck
out={'status':'PASS','exact_pair_suffix_certificates':count,'capacity_scalar_checks':stages,'scope':'Saved rational finite time models and scalar algebra only; not general receiver geometry','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest()}
(r/'certificate_check.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
