# R144：原 Ψ 图上的联合后缀势及共同 α 容量尾缺口

本稿只处理合同指定的替代路线。结论是一个可直接核验、可回代的全后缀分支，以及尚未证明的具体接收几何不等式；没有新的一般外预算。所有恒等式与旧 FTC 比较均不登记新付款。未操作 Git/PDF，未改其他文件。只调用 R143 `score_flux_budget.md`、R138 `signed_flux_connection.md`、R122 `weighted_suffix_integration_private.md` 的原对象。

## 1. 准确命题、原符号和外预算

固定完整实际行 \(\mathfrak r=(x,y,z,\omega,V,j,\text{history},s,L,R,g,T)\)，保留完整原 heavy 远窗 \([\tau,h]\)。\(G=S_g\)、\(D_0=D_g\cap Z_g\) 都为终端存活来源，\(Z_g\subset Z_t\)；\(w_t(v)=\prod_i\min(1,a_i(v)/t)\)、\(k_t(v)=\#\{i:a_i(v)<t\}\)、\(e_t=\int_{Z_t}w_t\,d\nu\)、\(d\Pi_t=1_{Z_t}w_t\,d\nu/e_t\)。原 \(\nu\) 可以任意相关。以下先在有限截断上工作，\(0<\tau<h<\infty\)、\(e_h>0\)，\(e_t\) 非增且取相容右连续版本；所有来源积分绝对可积。最终扩张仍须原截断及可积性手续。

令 \(\Delta_{vu}(t)=k_t(v)-k_t(u)\)，\(\delta_\pm=(\pm\Delta)_+\)。原未归一后缀和门严格为
\[
F_{vu}(r)=\int_r^h\Delta_{vu}(t)w_t(v)w_t(u)\frac{dt}{t},\qquad
\Psi(v,u)=1_{\{\exists r\in[\tau,h]:F_{vu}(r)>0\}}.
\tag{JS1}
\]
不重定义 Ψ，不用归一后缀或正门后缀决定资格。定义原未归一正负后缀
\[
P_{vu}(r)=\int_r^h\delta_+w_vw_u\frac{dt}{t},\qquad
N_{vu}(r)=\int_r^h\delta_-w_vw_u\frac{dt}{t};\quad F=P-N.
\tag{JS2}
\]
正端系数仍是 \(\rho_v\chi(t;v,u)\)，\(0\le\chi\le1\)，其中
\[
 A_v=w_\tau(v)-w_h(v),\qquad
 \rho_v=\left(1-\frac{DK_v+\alpha J_v}{TA_v}\right)_+,
\]
\[
 \alpha=\mathcal R/Q_J,\quad Q_J=\int J_vd\nu(v),\quad
 \mathcal R=D(q-Q_0)+\int(DK_v-U_v)d\nu(v)\ge0.
\tag{JS3}
\]
本式取原 \(0<Q_J<\infty\) 的有限截断；\(A_v=0\) 按原约定 \(\rho_v=0\)。任何额外原门强制 \(\rho=0\) 只改善以下上界。

准确候选如下：在原 Ψ 图内定义
\[
 B_\alpha(r)=\iint_{G\times D_0}\Psi(v,u)
       [\rho_vP_{vu}(r)-N_{vu}(r)]\,d\nu(v)d\nu(u).
\tag{JS4}
\]
若一个非负、实际行可测的量 \(c_{\mathfrak r}\) 满足**整段原后缀证书**
\[
 \boxed{B_\alpha(r)\le c_{\mathfrak r}\,e_h e_r\quad
               (\tau\le r\le h),}
\tag{JS5}
\]
则原终端存活 signed 槽满足
\[
 \boxed{S_{\rm surv}\le (2-e_h/e_\tau)c_{\mathfrak r}\le2c_{\mathfrak r}.}
\tag{JS6}
\]
这是可证明的条件分支，不是宣称 JS5 的 \(c\) 已付。先聚合原 Ψ 边再作比较，条件弱于逐 pair 非正或逐边分配同样势帽；它仍是充分条件，不是原目标的必要条件。\(c=0\) 是直接的零费分支，仍仅适用于实际认证 JS5 的行。

所需的真正外预算为：用原
\[
 d\mathcal T_{\mathfrak r}=q^{-1}p(x,y)h_R(x-z)a_{\rm history}
       \,dx\,d\beta(y)d\nu(z)
\]
及所有原门、\(\mathbb E\sum_{V,j}\)、\(2\Lambda\)，控制
\[
2\Lambda\mathbb E\sum_{V,j}\int
 \big[(2-e_h/e_\tau)c_{\mathfrak r}
          +S_{\rm future,\mathfrak r}-N_{\rm del,\mathfrak r}\big]
 \,d\mathcal T_{\mathfrak r}
\le\varepsilon X+C_\varepsilon\sqrt n\log^A(2+n)W_\beta.
\tag{JS7}
\]
这里原 future 块仍为 \(G\times[D_g\cap(Z_t\setminus Z_g)]\) 上、原 Ψ 与原正负系数下的交通。未经完整域匹配，不消去 \(N_{\rm del}\)。不同 history、\(s,L,R,g,T\)、\(j\) 或种子均未删除。一个逐行 \(c\le1\) 不能支付 JS7。

## 2. 联合势证明：不拆端点与 missing Ψ

先定义带原正门的精确势
\[
 B_\chi(r)=\iint_{G\times D_0}\Psi
 \int_r^h[\rho_v\chi(t;v,u)\delta_+-\delta_-]
                 w_vw_u\frac{dt}{t}\,d\nu^2.
\tag{JS8}
\]
\(B_\chi\) 绝对连续，\(B_\chi(h)=0\)。R122 同一个 Stieltjes 计算直接给
\[
 \boxed{S_{\rm surv}=\frac{B_\chi(\tau)}{e_\tau^2}
                      +\int_{(\tau,h]}B_\chi(r)\,d(e_r^{-2}).}
\tag{JS9}
\]
这里**先在原图上求和，最后才考虑正上包络**。没有构造完整图，没有把缺失 Ψ 域加回，也没有分别取 R143 的端点和缺边估计。原负项已经完整含在 \(B_\chi\)，只使用一次。\(\chi\le1\) 给 \(B_\chi(r)\le B_\alpha(r)\)，而 \(d(e^{-2})\ge0\)，故
\[
 S_{\rm surv}\le\frac{B_\alpha(\tau)}{e_\tau^2}
                 +\int_{(\tau,h]}B_\alpha(r)d(e_r^{-2}).
\tag{JS10}
\]
保留 \(\chi\) 可得到更小证书，但不必依赖它的时间正则性。

JS4 也可写成
\[
 B_\alpha(r)=\iint_{G\times D_0}\Psi
       [\rho_vF_{vu}(r)-(1-\rho_v)N_{vu}(r)]\,d\nu^2.
\tag{JS11}
\]
因此每条原 Ψ 边在某些后缀上的负 \(F\)，以及共同 α 造成的抑制，都在同一个势中留下；没有把 \(F\) 换成 \(F_+\)，也没有逐边取正部。JS11 说明它确实使用原未归一后缀结构，而非裸 score 的另一名称。

证明 JS6：JS5 与 JS10 给
\[
 S_{\rm surv}\le c e_h/e_\tau
                   +c e_h\int_{(\tau,h]}e_r,d(e_r^{-2}).
\]
非增右连续 \(e\) 的连续 BV 部分满足 \(e\,d(e^{-2})=2d(e^{-1})\)；在下降跳 \(e_-=a\ge b=e_+\) 处，
\[
 b(b^{-2}-a^{-2})=b^{-1}-b/a^2
                  \le2(b^{-1}-a^{-1}).
\]
故 \(\int e_r d(e_r^{-2})\le2(e_h^{-1}-e_\tau^{-1})\)，得到 JS6。原删除跳均保留；没有假设 \(Z_t\) 恒定。\(B\) 连续，跳点的 Stieltjes 乘积无版本歧义。

取 \(c=\sup_r(B_\alpha(r))_+/(e_he_r)\) 总能形式上成立，但**这种定义本身不提供外估计**。本稿不把它登记为进展；有内容的分支必须从真实几何验证 JS5，并支付 JS7。若保留 JS10 的有符号积分，它可以严格优于 JS6；不要求为了使用这一势而丢弃所有负后缀。

## 3. 共同 α 对接到的最小具体几何尾

将 JS4 按正来源分组，定义
\[
 P_v(r)=\int_{D_0}\Psi(v,u)P_{vu}(r)d\nu(u),\qquad
 \mathcal N(r)=\iint_{G\times D_0}\Psi N_{vu}(r)d\nu^2.
\]
对 \(A_v>0\) 置 \(H_v(r)=P_v(r)/(TA_v)\)，\(A_v=0\) 置 \(H_v=0\)。由于 \(A_v=0\) 时 good 来源在整窗无连续下降，\(\delta_+\le k_v\) 给 \(P_v=0\)，此约定准确。由 JS3，
\[
 \boxed{B_\alpha(r)=\int_G(TA_v-DK_v-\alpha J_v)_+H_v(r)d\nu(v)
                       -\mathcal N(r).}
\tag{JS12}
\]
额外清零门存在时，右边给上界，足以使用 JS5。这个表达让同一个 \(\alpha\) 同时作用于全部来源；没有对每个 \(r\)、每个 pair 重新选择 α。

在 \(J_v>0\) 上置
\[
 \theta_v=(TA_v-DK_v)/J_v,\qquad d\mu_J(v)=J_vd\nu(v)/Q_J.
\]
\(\mu_J\) 是全来源上的概率测度，内积分仍限定 \(G\)。另记
\[
 E_0(r)=\int_{G\cap\{J=0\}}(TA_v-DK_v)_+H_v(r)d\nu(v).
\]
层蛋糕给出准确的源尾表达
\[
 \boxed{B_\alpha(r)=Q_J\int_{\alpha}^{\infty}
       \int_{G\cap\{J>0,\theta_v>a\}}H_v(r)d\mu_J(v)\,da
       +E_0(r)-\mathcal N(r).}
\tag{JS13}
\]
若额外原门将部分 \(\rho\) 清零，JS13 的右侧与 JS12 一样只是对真实 \(B\) 的上界，JS14 仍为充分证书。

这不是新的测试门：\(\theta\) 只用于表达原 \(\rho\)，Ψ 仍是 JS1。\(\mathcal N\) 是原 Ψ 图内尚在当前 signed 槽的负后缀，绝不包含已消费 \(N_Z\)。

因此 JS5 的**具体待证几何命题**是：在真实接收核和共同
\(\alpha=\mathcal R/Q_J\) 下，原 Ψ 后缀流加权的容量尾满足
\[
 Q_J\int_{\mathcal R/Q_J}^{\infty}
       \int_{G\cap\{J>0,\theta>a\}}H_v(r)d\mu_J(v)da+E_0(r)
 \le\mathcal N(r)+c_{\mathfrak r}e_he_r
 \quad\text{对所有原 }r,
\tag{JS14}
\]
且这些 \(c_{\mathfrak r}\) 在原外测度下满足 JS7。这比一个未指定“图能量有帽”的问题更具体：需要控制同一来源上 \(H_v(r)\) 与大 \(\theta_v\) 的联合质量，而所有 \(H_v\) 都由原 Ψ 的真实坏接收端及真实剩余时间生成。仅知道 \(\int J=Q_J\) 和 \(\alpha Q_J=\mathcal R\)，不含这种联合几何信息。

现有工具只能验证以下回退，不能支付 JS14。令 \(W_D(r)=\int_{D_0}w_r(u)d\nu(u)\)，则
\[
 0\le P_v(r)\le W_D(r)[w_r(v)-w_h(v)]\le W_D(r)A_v,
 \qquad H_v(r)\le W_D(r)/T.
\tag{JS15}
\]
证明仅用 \(\Psi\le1\)、\(\delta_+\le k_v\)、\(w_t(u)\le w_r(u)\) 和来源 FTC。若把 JS13 内的 \(H_v\) 换成这个统一帽，就丢失 \(H\) 与 \(\theta\) 的相关，回到旧的 \(\int_G\rho_vA_vd\nu/e_h\) 来源费用；不能出现新根阶支付。共同 \(\mathcal R\) 的标量恒等式也不能恢复这些相关。

一个可复核的直接回代上界是
\[
 S_{\rm surv}\le\min\left\{(2-e_h/e_\tau)c_{\mathfrak r},\
                \frac{1}{e_h}\int_G\rho_vA_vd\nu(v)\right\}
\tag{JS16}
\]
（第一项仅在 JS5 已验证时使用）。第二项是旧 FTC，不是新额度；这是两个**完整行上界**取最小，不是从 SF143.10/15 中逐项拼小值。只有实际证书的第一项严格更小且其外价已付时，才能登记费用下降。本稿没有宣称一般存在这种下降。

## 4. 可检验范围与已知压力

有限原来源模型中，\(P,N,B_\alpha\) 在坐标阈值之间都是 \(s=1/r\) 的多项式，次数至多 \(2n\)：每项 \(w_vw_u=Ct^{-m}\)，非零 \(\delta_\pm\) 强制 \(m\ge1\)，积分不产生 \(\log r\) 项。\(e_r\) 在坐标阈值和实际删除事件之间是次数至多 \(n\) 的多项式。因此验证 JS5，须检查分段端点、删除事件的两侧以及分段内部的多项式极小值；只查原 F 的断点不足以认证 \(B_\alpha/e\) 的全窗上确界。可直接检查多项式 \(c e_h e_r-B_\alpha(r)\ge0\)，或检查比值驻点；后者的导数分子次数至多 \(3n-1\)。这是有限模型认证方法，不是一般接收几何证明或免费尺度覆盖。

初探：JS9--16 的代数与删除跳已逐式检查；没有把计算外包后未实际运行的数值称为通过。已知压力：R143 原 179 个正点的 Ψ 内负项为零，意味着这些行的 \(\mathcal N(\tau)=0\)，从非负性进一步得到所有 \(\mathcal N(r)=0\)。只要其中实际保留正交通非零，\(B_\alpha(\tau)>0\)。故不能把 JS14 的 \(c=0\) 分支推广到所有真实行。此压力仅否定普遍零费，未否定 JS14 的可支付正余量，也没有重复搜索裸 score 反例。

数值代理本轮已实际计算的三个原模型，给出断点上的 \(B_\alpha^+/(e_he_r)\) 最大值：I1 为 \(0.00711514435203\)，I2 为 \(7.21040990452\times10^{-6}\)，P1 为 \(2.86244763773\times10^{-5}\)。这些只是断点统计，**不是连续上确界证书**，不能据此使用 JS6。三个原模型的 Ψ 内负交通均为零；其结果用于压力检查，不认证一般付款。数值代理另发现 P1 一条边的归一 signed 积分约为裸未归一后缀帽的 397 倍，故 JS9 的归一权不能省去。详见本轮 `numeric_suffix_notes.md` 和 `numeric_suffix.json`；这里没有重复运行或把旧179点称为新检验。

扩大范围：尚无一般维数、一般相关 ν、全实际接收平均上的 JS14 证明。特别是在上述 Ψ 内无负边的行，所需改进必须直接压低 \(H\)-加权的大 \(\theta\) 尾，或把它以真实外核输送到 \(W_\beta\)；完整图端点的负值与缺失 Ψ 的反向交通都不能用于这个支出。

## 5. 交付边界

可回代结果是 JS9 的原图联合势、JS6 的全后缀证书分支、JS13--14 的共同 α 加权尾接口，以及 JS16 与旧 FTC 的合法比较。它们保留原 Ψ、原共同 ν、原分母和一次性负账；不把恒等式算新支付。

最小尚需几何内容已缩到 JS14 的 \(H_v(r)\) 与 \(\theta_v\) 联合尾，并须完成 JS7 的真实外付款；future 与 \(N_{\rm del}\) 域差仍原位。现有材料没有给出这一联系。因此本稿不声称一般 \(\sqrt n\operatorname{polylog}n\) 目标闭合，不把 \(c\) 的定义或端点常数伪装成降低费用。完成后停止。
