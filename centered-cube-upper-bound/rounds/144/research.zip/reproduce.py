"""python reproduce.py REPO NEW_WORK [checks|full]
Python >=3.11, mpmath. checks validates frozen certificates and scale tests;
full also regenerates suffix and geometry diagnostics from archived inputs.
"""
from pathlib import Path
import sys,json,zipfile,subprocess,shutil
src=Path(__file__).resolve().parent;repo=Path(sys.argv[1]).resolve();work=Path(sys.argv[2]).resolve();mode=sys.argv[3] if len(sys.argv)>3 else 'checks'
assert mode in ['checks','full'];assert not work.exists();work.mkdir(parents=True)
out=work/'centered_cube_round144_20261015';out.mkdir()
for p in src.iterdir():
 if p.suffix in ['.py','.json','.md']:shutil.copy2(p,out/p.name)
items=[(139,'active_traffic_v2.json','centered_cube_round136_20261014')]
if mode=='full':items += [(142,n,'centered_cube_round142_20261015') for n in ['numeric_receiver.json','time_primitive_check.json']]+[(143,n,'centered_cube_round143_20261015') for n in ['numeric_flux.py','numeric_flux.json']]
for rnd,name,folder in items:
 with zipfile.ZipFile(repo/f'centered-cube-upper-bound/rounds/{rnd}/research.zip') as z:data=z.read(name)
 target=work/folder;target.mkdir(exist_ok=True);(target/name).write_bytes(data)
for name in ['certificate_check','scale_probe']:
 subprocess.run([sys.executable,str(out/(name+'.py'))],check=True,stdout=subprocess.DEVNULL)
 assert json.loads((out/(name+'.json')).read_text())==json.loads((src/(name+'.json')).read_text()),name
if mode=='full':
 for name in ['numeric_suffix','numeric_geometry']:
  subprocess.run([sys.executable,str(out/(name+'.py'))],check=True,stdout=subprocess.DEVNULL)
  got=json.loads((out/(name+'.json')).read_text());saved=json.loads((src/(name+'.json')).read_text())
  for key in ('elapsed_seconds','finished_utc','started_utc'):
   got.pop(key,None);saved.pop(key,None)
  assert got==saved,name
 print('Full deterministic outputs reproduced; only UTC/elapsed metadata excluded.')
print('PASS portable exact certificates and scale tests')
