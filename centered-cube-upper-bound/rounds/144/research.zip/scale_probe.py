from pathlib import Path
import sys,json,hashlib
from functools import lru_cache
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as m
m.mp.dps=60
@lru_cache(None)
def phi(x):
 x=abs(x);h=m.mpf('.5');E=lambda t:m.mpf('.5') if t==0 else m.expint(3,t)
 return 1-E(h-x)-E(h+x) if x<=h else E(x-h)-E(x+h)
def logk(H,blocks,slo,shi):
 return sum(count*m.log(((1-shi)*(abs(r)<=H/2)+slo*phi(r/H))/H) for r,count in blocks)
rows=[]
menus=[('initial',[1,4],['0','0.3','2']),('pressure',[4,16],['0.5','0.500000000001','0.999999999999']),('expanded',[64,128],['0.1','0.75','8'])]
for stage,ns,rs in menus:
 for n in ns:
  N=int(m.ceil(m.log(2)/m.log(1+m.mpf(1)/n)));grid=[m.power(2,m.mpf(i)/N) for i in range(N+1)]
  for rr in rs:
   blocks=[(m.mpf(rr),n)];slo=m.mpf('.1');shi=m.mpf('.2')
   logs=[logk(H,blocks,slo,shi) for H in grid]
   for theta in [m.mpf(0),1/m.mpf(n),m.mpf('.5')]:
    f0=m.exp(-theta*logs[0]);endcap=m.power(2,n*theta)*f0
    cells=[m.exp(-theta*(logs[i]-n*m.log(grid[i+1]/grid[i]))) for i in range(N)]
    sumcap=f0+theta*sum(cells);old=sum(cells)
    worst=max(m.exp(-theta*l) for l in logs)
    assert worst<=min(endcap,sumcap)*(1+m.mpf('1e-50'))
    rows.append(dict(stage=stage,n=n,r=rr,theta=str(theta),N=N,endpoint_over_old=m.nstr(endcap/old,20),stieltjes_over_old=m.nstr(sumcap/old,20),max_grid_over_best=m.nstr(worst/min(endcap,sumcap),20)))
out={'status':'PASS','precision':60,'scope':'finite actual phi, repeated-coordinate profiles, no full receiver/source budget','rows':rows,'cases':len(rows),'protocol_sha256':hashlib.sha256(Path(__file__).with_name('scale_probe_plan.md').read_bytes()).hexdigest()}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(rows))
