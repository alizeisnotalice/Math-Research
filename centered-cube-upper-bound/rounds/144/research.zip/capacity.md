# R144：共同储备迫使坏后验进入何种真实接收尾

状态：得到了保留实际 bad 域的、常数明确的容量／核比二分，并把唯一剩余量写为两来源低核乘积与 good 门的联合接收尾。高核比部分在原合法 hard 接收域可完整支付 25Λ√nWβ；低核比部分尚无新的总价。故本稿登记一个实际可付子支，不声称改善完整未付域的总费用或完成一般闭合。方差乘剩余二阶矩的候选因仅重现旧接口而不展开。

## 1. 量词与先行候选

固定合同中的实际 ω,V,j,y,t 及原 ν；接收参数可以依 x 自适应。全部 e_t、QJ、R、q、T、A 按原 ν 计算。本文不冻结参数、不作参数菜单覆盖，不变更 Ψ。先在有限正商行证明，零交通行沿原约定处理。

令 b_t(u)=1_{Z_t}(u)w_t(u)/e_t，dΠ_t=b_t dν。对实际 terminal good 来源 v，记

\[
\delta(v,u)=[k_t(v)-k_t(u)]_+,
\quad a_v=[1-DK_v/(TA_v)]_+,
\quad r_v=\frac{RJ_v}{TA_vQ_J},
\quad\rho_v=[a_v-r_v]_+.
\tag{C1}
\]

在本稿的正部估计中，坏来源域取原实际 \(\mathcal B_v\subset D_0\subset D_g\cap Z_t\) 与 δ>0；可保留原 Ψ 和 FA 门。不依赖外 hard 来源 z 的门可全部留在此域。若另有 z 依赖 history 门，保留在原左边，取得正上界时仅删这些门。原负项、futurebad、Ndel 不改变。

这里必须恢复 R143 SR4 中为了正放松而删除的 bad 资格。原捕获合同给 U=0 于 D_g，故

\[
R\ge D\int_{D_g}K_u\,d\nu(u).
\tag{C2}
\]

SR4 的 σ 对整个 Π 积分，单独对该放松量不能由 R 小推出 score 小：R=0 仍允许来自非 bad 来源的 score。实际 bad 域则相反，严格正 K 与 (C2) 给 R=0 时 ν(D_g)=0，实际正 pair 为零。不能把这两种量词混用。

**准确候选。** 对 δ>0、u∈B_v 定义

\[
c_x(v,u)=\frac{D K_uJ_v}{TA_vQ_J\,b_t(u)\delta(v,u)}
 =\frac{D K_uJ_ve_t}{TA_vQ_Jw_t(u)\delta(v,u)}.
\tag{C3}
\]

对每个预先给定 η>0，令

\[
s_\pm(v)=\int_{\mathcal B_v}\delta(v,u)
 1_{\{c_x(v,u)\gtreqless\eta\}}d\Pi_t(u),
\tag{C4}
\]

其中 + 取 ≥η，− 取 <η，分割等号只属于 +。候选不等式为

\[
\boxed{\rho_vs_+(v)\le\frac{a_v^2}{4\eta},\qquad
\rho_v\int_{\mathcal B_v}\delta\,d\Pi_t
\le\frac{a_v^2}{4\eta}+\rho_vs_-(v).}
\tag{C5}
\]

这是一个允许一般输入的完整二分，未丢掉小 c 区域。η 不依正在积分的 u 或 z 重选。

## 2. 证明与共同容量审计

由 (C2) 及非负性，对每个固定 v，

\[
r_v\ge\frac{DJ_v}{TA_vQ_J}
\int_{\mathcal B_v\cap\{c\ge\eta\}}K_u\,d\nu(u)
=\int_{\mathcal B_v\cap\{c\ge\eta\}}
 c_x(v,u)\delta(v,u)d\Pi_t(u)
\ge\eta s_+(v).
\tag{C6}
\]

于是 ρ_vs_+≤s_+[a_v−ηs_+]_+≤a_v²/(4η)，常数 1/4 来自实数 s≥0 的二次最大化，且在 s=a_v/(2η) 时尖锐。这里只对同一个实际 R 取上界，没有按 v 重选 α。不同 v 的 C6 不是可累加的独立储备支出；下一步只对所得数值上界按概率 Π_t(v) 平均，因此没有复制 R。

R=0、δ=0、A_v=0、e_t=0、QJ=0 各支先按零交通处理；不计算对应商。原 soft 核严格正，b_t>0 于实际 bad 后验支持。若某积分无限，先用原归一化量截断非负积分，不重新归一化 ν；C6 的有限 R 自动限制相应高 c score 积分。R=∞ 且 J_v>0、TA_v 有限时原剩余直接为零。

## 3. good 门确实落在同一个低核乘积上

原 good 门为 p_xw_g(v)≤KJ_v。因此

\[
c_x(v,u)\ge
\underline c_x(v,u):=
\frac{D p_xw_g(v)K_u e_t}
 {KTA_vQ_Jw_t(u)\delta(v,u)}.
\tag{C7}
\]

小 c 剩余必同时满足

\[
\boxed{\quad p_xw_g(v)\le KJ_v,
\qquad K_uJ_v<
 \frac{\eta TA_vQ_Jw_t(u)\delta(v,u)}{D e_t}.\quad}
\tag{C8}
\]

从而亦满足

\[
\frac{K_u}{w_t(u)}<
\frac{\eta KTA_vQ_J\delta(v,u)}{D e_tp_xw_g(v)}.
\tag{C9}
\]

(C8) 保留了真正两个不同来源 u、v 的接收几何及同一 QJ；(C9) 较弱，只用于指出来源后验与核质量转换的障碍。不把其中 QJ/e_t、TA_v/w_g 或 p_x 的倒数当常数，也不使用 α 的负幂。

这给“大储备／小储备”的准确含义：r_v≥a_v 时该 good 来源完全无剩余；r_v<a_v 时，(C6) 限制的是高核比坏 score，未被限制的后验必须留在 (C8)。单说 R 小不足以推出后验集中到已付款区域；需要对 (C8) 在真实 p_xh_R(x−z)dx 下估价。

## 4. 已付高核比子支及完整接收／时间回代

独立审计已核对 R141 JG9/JG16 及 R140 JT14。这里使用其**统一接收付款合同**，不要求本子支满足旧 JG14 的 Θ 小门。

准确付款域 \(\mathcal G_{leg}\) 是本轮原未付正交通中的下列实际子域：先剔除全部旧已付正支，保持原 H<L⁺、terminal good v∈G=S_g（含 C_J≤3 的既有资格）、原实际窗口 τ_j≤t≤h、u∈D0=D_g∩Z_g、δ>0，保留原 Ψ、χ_FA、ρ、history／qualification 以及原唯一 j(x) 指示。在此域新增 c≥η_n，取

\[
\eta_n=\frac{4(n+1)^2}{3n}.
\tag{C10}
\]

证明中可删除额外正门，但必须保留原 hard 帽适用的 \(a_\omega(x,y,z)\) 或其原资格上包络；它给

\[
\frac1{q(x)}\int h_{R_{scale}}(x-z)a_\omega(x,y,z)d\nu(z)
\le C_H=16/3.
\tag{C11a}
\]

先在原实际 x 调用此帽，再用 C5 和两份真实 posterior 积分，得到不含 p 的行系数

\[
I_{hi,j}(x,y,t)
\le\frac{C_H}{4\eta_n}\int_{S_g}a_v^2d\Pi_t(v)
\le\frac4{3\eta_n}=\frac{n}{(n+1)^2}.
\tag{C11b}
\]

该帽不依 j,x,y,t,V，来源已经消尽。现才使用 JT14：原 c_j=γ^{−j}≤1，故 τ_j=a/c_j≥a 且 h≤g≤bc_j≤b；所有原非空时间窗先放松到共同 [a,b]，合并 Σ_j1_{j(x)=j}≤1，再付原 s,L 接收包络。于是

\[
\boxed{\begin{aligned}
2\Lambda P_{hi}^{leg}
&\le\frac{6\Lambda n\log2(2n+3)}{(n+1)^2}D_nW_\beta\\
&\le36\Lambda\log2\sqrt nW_\beta
<25\Lambda\sqrt nW_\beta,
\qquad D_n\le3\sqrt n.
\end{aligned}}
\tag{C12}
\]

C12 是**已证明的真实子支付款**，不是待证 M 接口。它已包含 dt/t、实际 dx、dβ、EΣ_V 和唯一 j；未使用“单位时间帽直接给 8ΛX”。先前作者稿仅将此回代写成条件式，独审确认 C11b 已满足 JT14 的同域量词后，在此修正。无需再假设 R>L、H₀≥a、外 hard 来源位于 core、λ_S>0 或旧 Θ 门。原 hard 帽只领取一次，且在任何 JR 全盒接收放松之前领取。

为准确列剩余，将仍保留的原非负门及旧已付补集写为 χ_orig(x,y,z,v,u,t)；其中 aω 单独显示，χ_orig≤1，不将其附给负项。合法域的低核比剩余为

\[
\begin{aligned}
\mathcal T_{\eta_n}^{leg}:={}&\mathbb E\sum_{V,j}
\int d\beta_V(y)\int\frac{dt}{t}\int dx\,
\frac{p_x}{q(x)}\int h_{R_{scale}}(x-z)a_\omega(x,y,z)\\
&\quad\cdot\int_{S_g}d\Pi_t(v)
\int_{D_0}\chi_{orig}(x,y,z,v,u,t)\rho_v\delta(v,u)
1_{\{c_x(v,u)<\eta_n\}}d\Pi_t(u)\,d\nu_V(z).
\end{aligned}
\tag{C13}
\]

此处内层积分的 z 依赖保留在外 ∫dν(z) 的作用域内。时间仅在完整原窗，接收域和所有原层级照旧。展开来源权为

\[
\frac{p_xh_{R_{scale}}(x-z)a_\omega\chi_{orig}}{q(x)e_t(y)^2}
1_{Z_t}(v)1_{Z_t}(u)w_t(v)w_t(u)
\rho_v\delta(v,u)\,d\nu(z)d\nu(v)d\nu(u)\,dx.
\tag{C14}
\]

它仍含两份 e 分母、三份原 ν、实际 q 和 β。故合法 terminal 正交通有

\[
\boxed{2\Lambda P_{terminal}^{leg}
\le25\Lambda\sqrt nW_\beta+2\Lambda\mathcal T_{\eta_n}^{leg}.}
\tag{C15}
\]

原 R144 terminal 未付域继承的基础资格正是上述原接收／good／窗口合同；不自动继承 c≥η_n。futurebad、Ndel、D0 外来源及原 Ψ 内负项不属于本子支付款，继续按原账保留。若将本稿 C1–C9 用于此前删门后的更大 Ω，或用于丢失 aω／唯一 j／接收包络的域，其差集记为 P_exc，不在 C12 的覆盖内；对应更大正项只能写成 C15 右侧另加 2ΛP_exc。对于该差集，高部分至多有 ΛM_exc/(2η_n)，其中

\[
M_{exc}=\mathbb E\sum_{V,j}\int d\beta_V(y)\int\frac{dt}{t}
\int_{\Omega_{exc}}\frac{p_xH(x)}{q(x)}dx,
\tag{C15e}
\]

保留全部窗口及层级，不声称此额外 M 已付款。该例外用于说明代数推广域与原付款域的边界，不把原已认证的合法域付款降回条件接口。

## 5. 三阶段检查与真正尚缺的命题

**初探。** (C6) 把实际共同储备同时用于坏来源核质量和 good 端余量；精确标量最大化给 1/(4η)，不需独立 ν、统一 α 或菜单覆盖。以上为解析证明，没有声称运行数值。

**已知压力。** 数值代理报告的冻结 P1 数据中，主 good 来源的匹配比例 RJ/(QJTA) 约为 10⁻³，而非因 J/QJ 本身小；这是已有有限行压力，不是一般结论，本稿未自行运行或认证该数值。当坏来源 K_u/w_t(u) 很小，c 可以低于 η_n，且原 Ψ 内负项未必提供任何付款。R143 已知正样本的这一压力不能由 (C6) 排除。把 C13 的 δ≤n、ρ≤1 后称它为“低核能量”不降低费用。特别是把 bad 门删掉再讨论 R=0，会丢掉本稿唯一的容量约束。

数值代理随后对 179 个冻结合法正点的 690 个 pair-segment 作段端点／几何中点三点初筛，共 2070 个 samples，报告 c/η_n 最大约 9.13×10⁻⁶，高门命中为 0；这不是全窗低门认证，也不是一般高子支空集证明。本稿未自行运行该初筛，不将有限初筛当成 C12 的覆盖收益。

**扩大范围。** 证明已覆盖任意固定一般 ν 和实际自适应参数，且余部对所有输入明列。若为 C8 用负幂 Chernoff 或 JR 乘积积分，便引入坏来源 K_u 的逆核因子；原 R136 的相关全位置分数核包络只给含 M_{θ,s}^n 及完整尺度、两 e 分母的价格。若进一步冻结自适应参数，JR 的菜单还须逐单元支付。这里没有证据将这些价格降至根阶；不能把固定来源可积性升级为一般接收平均预算。

合法 high 子支已由 C12 付清；就其同阈值低核比尾而言，尚需的实质命题可以具体陈述为：在原完整输入类、原未付域和上述 η_n 下，利用 (C8) 的 good／两源低核乘积交叠，证明

\[
2\Lambda\mathcal T_{\eta_n}^{leg}
\le\varepsilon X+C\sqrt n\operatorname{polylog}(n)W_\beta,
\tag{C16}
\]

其中 C 不依 ν、接收选择器或层数，且必须给出所有尺度层级总价。这比仅说“控制加权责任边际”具体：困难的坏核 K_u 与 good 核 J_v 已被放进同一个显式接收尾；但 C16 **尚未证明**。本稿没有用 C16 当作假设回报成功，也没有把 C13 改名登记付款。

结论：小 R 的真实作用可严格定位为“高核比 bad score 受限，剩余进入 C8”；合法高核比子支已支付 25Λ√nWβ，目前不能证明低核比剩余集中于已付接收区域。一般根阶目标仍未完成。仅写本文件；不修改他人文件，不运行 Git/PDF。
