# R144：逆核尺度的单侧积分与实际加权菜单

状态：取得可直接与 JR7 比较的严格尺度估计。保留原 s,L,R 单元，将 H 菜单改为一个端点加 nθ 倍连续积分；在原比值 1+1/n 网格上，其实际标量费用至多为首单元费用加 θ 倍全 H 菜单费用。改进具有明确的端点非集中条件；没有证明一般来源平均满足此条件，也没有取得一般根阶付款。本文只处理尺度包络，不处理 reserve 的来源边际。

## SS1. 先给候选及其准确量词

固定原 ξ=(ω,V,j,y,t)，原共同 ν、Z_t、w_t、e_t、Π_t；仍使用完整原远窗、原 Ψ、原 good/bad 与 FA。固定外 hard 来源 z 和两个原内来源 v,u。s,L,R 仍可依接收点 x 自适应，H(x)∈[a,b]、b≤2a，绝不将 H 当常数。选定先于这些来源的 s,L,R 单元 C，沿用 JR5–6 的 E_p,E_R、\bar p、R_+、g_+、T_+、A_+、w_+；这些量都不需要 H 单元。设

\[
\underline k_{C,r}(d)=r^{-1}\{(1-s_+)1_{|d|\le r/2}+s_-\phi(d/r)\},\quad
\underline K_{C,r}(x-v)=\prod_i\underline k_{C,r}(x_i-v_i),
\]
\[
f_r(x,v)=\underline K_{C,r}(x-v)^{-\theta},\qquad
0\le\eta\le1,\quad\theta\ge0.
\tag{SS1}
\]

s_->0，故所有分母严格正。实际核满足 K_{s(x),H(x)}≥\underline K_{C,H(x)}。候选为

\[
\boxed{f_{H(x)}(x,v)\le f_a(x,v)+n\theta\int_a^{H(x)}f_r(x,v)\,\frac{dr}{r}.}
\tag{SS2}
\]

这是所有实际 H 同时适用的确定性式，不依选择器的停止时性质。θ=0 时两边均为1，H 菜单完全消失，但此时没有逆核增益，不能冒称低核双门已经付款。

对同一 C 的原 H 网格 a=H_0<⋯<H_M=b，H_{m+1}/H_m≤γ=1+1/n，令 B_{C,m} 为原 JR7 在四维单元 C×[H_m,H_{m+1}] 的完整系数。B_C^{cont} 专指去掉 q 权及接收门后的可比较标量帽：用后文 SS4 的 U_C 定义为 ∫U_Cf_a dx+nθ∫_a^b∫U_Cf_r dx dr/r；它不含 q_-^{-1}。候选的第二个、可比较的结论是

\[
\boxed{B_C^{cont}\le B_{C,0}+n\theta\sum_{m=0}^{M-1}\log(H_{m+1}/H_m)B_{C,m}
\le B_{C,0}+\theta\sum_m B_{C,m}.}
\tag{SS3}
\]

B 含原 w_+^{-η}、(T_+A_+/D)^θ、全部逆核、hard 归一化及位移。SS3 是这些实际系数的加权比较，非仅把菜单数由四维改名为三维。

初探：θ=0 及 H=a 两边方向正确；H 向上穿过 hard 跳面时 f 只向下跳，与 SS2 相容。已知压力：低尺度端点逆核可能主导整个菜单，SS3 不给无条件 θ 比例收益。扩大范围：下述证明覆盖所有原自适应 H、软度端单元 s_+=1、hard 跳面及原共同 α。主代理另按冻结协议 scale_probe_plan.md 实际运行 scale_probe.py；scale_probe.json 记载 60 位、54 个三阶段有限核样例全部通过单端与加权菜单帽，维数覆盖 1,4,16,64,128，θ 包括 0、1/n、1/2。本人仅读取该协议及结果，未另跑实验；这不是区间证书、任意 L1 验证或来源平均付款。

## SS2. SS2 的证明与共同 alpha 保留

固定 x,v。由 φ 偶且径向非增，r^n\underline K_{C,r} 随 r 非减。因此 r^{-nθ}f_r 非增。采用右连续代表时，在任意有限区间的 Stieltjes 意义下

\[
df_r\le n\theta f_r\,d\log r.
\]

证明无需假设 soft 核光滑：写 f_r=r^{nθ}g_r，g_r 非增，用有界变差乘积法则即可；其奇异项非正。积分得 SS2。原 hard 端点如采用另一边界约定，可使用相应单侧极限；硬跳向下，式子仍成立。

记 Ω_C 为原合法接收域与实际 s,L,R∈C 的交集。所有其余实际正门/权重统一记为 m_ξ(x;z,v,u)∈[0,1]；包括需要保留的原 Ψ、χ_FA、history、good/bad 资格等，不按辅助尺度 r 重算。good 蕴含 p_xw_g≤KJ_v；该推论只用在原 good 域。共同 α 始终为原 R_x/Q_J(x)，q≥Q_0，且只在 Ω_C 使用。设

\[
U_C(x;y,z,v)=c_\theta E_p^{1-\eta}E_R
 (K/w_+)^\eta(T_+A_+/D)^\theta
 h_{R_+}(x-z)\prod_i\bar p_i(x_i-y_i)^{1-\eta}J_v(x)^\eta,
\]
\[
b_C(x,v)=\frac{\alpha(x)J_v(x)}{T_+A_+},\qquad
d_C(x,v)=[1-b_C(x,v)]_+^{1+\theta}.
\tag{SS4}
\]

A_+=0 的行直接为零，以下仅写 A_+>0。CA4 及实际 TA_v≤T_+A_+ 给

\[
p_xh_R1_{good}\rho_v\le U_C f_{H(x)}d_C\quad(x\in Ω_C).
\tag{SS5}
\]

这一步同时保留 DK 与同一整份 ν 决定的 αJ；未用 α 的正下界或负幂。令

\[
\mathcal I_C(r;E)=\int_{Ω_C\cap E}\frac{m_\xi(x;z,v,u)}{q(x)}
 U_C(x;y,z,v)f_r(x,v)d_C(x,v)\,dx.
\tag{SS6}
\]

则原 C 上的正交通接收积分有完整上界

\[
\boxed{\mathcal B_C^{\alpha,q}
=\mathcal I_C(a;\mathbb R^n)
+n\theta\int_a^b\mathcal I_C(r;\{x:H(x)\ge r\})\,\frac{dr}{r}.}
\tag{SS7}
\]

集合方向必须是 H(x)≥r，因为积分从 a 到实际 H(x)。m、α、q 均按实际参数评价；不能给积分节点 r 重新选择 q、reserve 或来源资格。SS7 是非负积分，避免无穷大相减。它适用于任意可测自适应尺度，包括可测停止选择；停止选择本身不提供额外正交性或容量。

另有主代理提出的更简洁单端版本。由同一个单调性，逐点有

\[
f_{H(x)}\le (H(x)/a)^{n\theta}f_a\le (b/a)^{n\theta}f_a,
\]
\[
\boxed{\mathcal B_C^{end,\alpha,q}:=\int_{Ω_C}\frac{m_\xi}{q}
U_Cd_C(H(x)/a)^{n\theta}f_a\,dx
\le(b/a)^{n\theta}\mathcal I_C(a;\mathbb R^n).}
\tag{SS7e}
\]

SS7e 与 SS7 分别是原完整接收积分的上界。二者均在接收积分完成后选择较小值；不声称把 x 依赖的最优参数放进一维乘积公式。θ≤c/n 时单端损失≤2^c；θ 为固定正常数时，损失可为2^{nθ}，这时单端路线可能远差于连续积分。

## SS3. 与原菜单的实际费用比较

原 H 单元的下核为

\[
\underline k_{C,m}^{JR}(d)=H_{m+1}^{-1}
\{(1-s_+)1_{|d|\le H_m/2}+s_-\phi(d/H_m)\}.
\]

对 r∈[H_m,H_{m+1}] 逐坐标有 \underline k_{C,r}≥\underline k_{C,m}^{JR}，因归一化、hard 支持和 φ 三项方向均正确。因此

\[
f_r\le\prod_i(\underline k_{C,m}^{JR}(x_i-v_i))^{-\theta}.
\tag{SS8}
\]

删除 SS7 的 H(x)≥r 与其余接收域、m,d_C，并用 q≥q_-，得到

\[
\boxed{\mathcal B_C^{\alpha,q}\le q_-^{-1}
 [B_{C,0}+n\theta\sum_m\log(H_{m+1}/H_m)B_{C,m}].}
\tag{SS9}
\]

同格比较的单端实际价为

\[
\boxed{\mathcal B_C^{end,\alpha,q}\le q_-^{-1}(b/a)^{n\theta}B_{C,0}.}
\tag{SS9e}
\]

因此可在完成接收积分后选用旧完整菜单、SS9 连续价、SS9e 单端价三者的最小值。它们都保留同一 θ,η 和原 B 定义，未将两种积分公式的不同好项混拼。

证明没有产生新来源距离矩或更坏的逆核下包络：右侧恰使用原 JR 单元的 B。α 在 SS7 中完整保留，SS9 仅是明确舍去该削减后的可比较标量帽。若需在比较中也保留 α，定义 \widetilde B_{C,m}^{α,q} 为在整个 Ω_C 上积分 q_-mU_Cd_C/q 乘 SS8 右侧，得到同样带权式；此定义明确扩张了原 H 单元域，不能声称优于保留各自 H 单元域的最精细 CA9。所有比较均为两个完整非负上界的比较，不把不同等价母式的好项逐项拼接。

原 s,L,R 菜单至多 (n+1)(2n+3)^2。若仅为显示确定性尺度权总量、而临时对同一 C 的 B_{C,m} 有已经证明的共同帽 B_C^*，SS9 才进一步给

\[
q_-^{-1}[1+n\theta\log(b/a)]B_C^*.
\tag{SS10}
\]

这里 B_C^* 必须真有付款；不能免费取 max 后把它当常数。θ≤c/n 时 H 权总量≤1+c log2，旧 H 网格为 O(n)。这一节只消去 H 自由度的额外重复付款，s,L,R、w_+^{-η}、TA 与逆核仍完整在 B_C^* 或各 B 中。

更不依赖共同帽的检验是设 S_C=Σ_m B_{C,m}<∞、r_C=B_{C,0}/S_C，则三个完整标量价给

\[
q_-^{-1}S_C\min\{1,\ r_C+\theta,\ (b/a)^{n\theta}r_C\}.
\tag{SS10r}
\]

若 θ≤c/n 且 r_C≤c'/n，真实系数价确实降低 O(n) 倍。若 r_C≈1，便没有统一改善。这是可核验分支条件，不声称原约束已经推出 r_C≤c'/n。两种新帽各有优势；例如主代理有限核记录 n=128、θ=1/2、重复坐标0.75时，单端/旧菜单约1.09×10^18，而连续菜单/旧菜单约0.559；它只说明两个完整帽需分别保留，不能外推一般阶数。

## SS4. 回代外 ν、两 e 分母、j、q 与 signed 母式

记 δ_t^+(v,u)=[k_t(v)-k_t(u)]_+。按照 JR8 的同一 RT4 合同，固定 ξ 后 ν、Z_t,w_t,e_t 不依 x,z。真实未付正部 P^{rem}（未乘 signed 母式的 2Λ）满足

\[
\begin{aligned}
P^{rem}\le\mathbb E\sum_{V,j}\int d\beta_V(y)\int_a^b\frac{dt}{t}\,
\frac1{e_t(y)^2}\iiint
&1_{Z_t}(v)1_{Z_t}(u)w_t(v)w_t(u)\delta_t^+(v,u)\\
&\cdot\sum_C\mathcal B_C^{\alpha,q}(y,z,v,u,t)
\,d\nu_V(z)d\nu_V(v)d\nu_V(u).
\end{aligned}
\tag{SS11}
\]

原 τ_j=a/c_j≤t≤h(x)、s,L,R,g,T 与全部 history 保留在 Ω_C,m。原 c_j=γ^{-j}≤1，故 τ_j≥a，且 h(x)≤g≤bc_j≤b；因此共同外时间区间 [a,b] 是合法扩张，旧 JR8/JT14 没有漏窗。此前把 τ_j 判断为小于 a 是本稿作者的错误，已更正。不同原 j 及 λ 层级各用自身 q_-，不能先把它们合并为常数。e_t=0 行按零交通约定处理。

以 SS9 代入，右侧完整显式价为

\[
\frac1{q_-}\mathbb E\sum_{V,j}\int d\beta_V(y)\int\frac{dt}{t}
\iiint\frac{1_{Z_t}(v)1_{Z_t}(u)w_t(v)w_t(u)}{e_t^2}
\delta_t^+(v,u)
\sum_C\left[B_{C,0}+n\theta_C\sum_m\log\frac{H_{m+1}}{H_m}B_{C,m}\right]
\,d\nu(z)d\nu(v)d\nu(u).
\tag{SS12}
\]

θ_C、η_C 在接收积分前固定；本稿无需逐点优化。原时间非空与 t≤h_{C,+} 可继续留在各 C 项。SS12 的每个 B 按原实际 j 计算 T_+、τ_j、A_+，不能忽略 j 对系数及 Π_t 的依赖。

SS12 中的方括号也可整体替换为 (b/a)^{nθ_C}B_{C,0}，得到单端版的完整三来源账；或者在同一 C 的接收积分结束后使用 SS10r。SS11 则可用 SS7 与 SS7e 的最小值，保留原共同 α 和实际 q；这两种写法都没有更改 e_t 或 j。

若进一步用 δ^+≤n 消去 u，则仍是

\[
\frac n{q_-}\mathbb E\sum_{V,j}\int d\beta_V(y)\int\frac{dt}{t}
\int d\nu(z)\int d\Pi_t(v)
\sum_C\left[B_{C,0}+n\theta_C\sum_m\log\frac{H_{m+1}}{H_m}B_{C,m}\right].
\tag{SS13}
\]

这不是 n 乘一个概率期望：外 ν(dz)/q_- 仍有量纲，且 fixed-source 有限不推出其来源平均有限。若用一个事实上已证明的共同来源平均帽作纯费用盘点，θ=O(1/n) 时尚有 O(n³) 个 s,L,R 单元、δ≤n、至多 log(b/a)≤log2 的共同时间长度与 O(n) 个原 j；仅这些确定性费用可达 O(n⁵)。在未消去来源的 SS11–13 中，j 对 Π_t 与 B 的依赖仍须保留，不能据这个盘点提前合并。该共同来源帽本身仍未证明；此盘点不是实际付款断言。

回到 signed 母式，SS11/12 的价再乘 2Λ，Λ=128/119。原 Ψ 内的负交通、futurebad 与 N_del 各仍按原式出现一次；本文没有把完整图抵消代替原 Ψ 负项，没有返还已消费 N_Z。SS11 是正项估计，不能单凭它核销这些其他账目。

## SS5. 共同尺度/停止选择为何尚不能完成一般预算

1. **端点集中是具体障碍。** SS2 的端点 f_a 不能删掉，H=a 时积分为零。任意停止选择定理如要移除端点，必须提供来自原接收域的额外估计。原约束并未在本文推出这种估计。SS12 是全 H 菜单带权价改善，但最坏端点集中时新旧费用同阶。
2. **小 θ 的尺度节约伴随低核收益变弱。** θ=c/n 能省 H 菜单，但原逆核仍为 \underline K^{-c/n}，good 权 w_+^{-η} 与 (TA/D)^{c/n} 完整保留。没有证明这组幂足够控制外 ν/e² 来源平均。距离可无界，不能仅因 θ 小就把逆核矩界成绝对常数。
3. **共同 g 积分仍有真实变差成本。** R133 MS8–14 的 n dlogH 价来自正尺度核的单调包络。本次逆核的方向相反、系数为 nθ；不能用本次 nθ 替换 L、R 正核的 n，也不能把 g 冻结消去 w_g 的真实来源权。把所有尺度强绑成一个共同 r 会漏掉原独立可行的 L,R,H，除非另证明覆盖。
4. **α 保留但没有免费统一削减。** SS7 中的 d_C 使用原共同 α，可能为1；SS9 仅作可比较帽，绝不把其损失登记为新 reserve 容量。直接控制 SS11 所需的是同一接收权下的来源平均几何，不属于本稿的尺度恒等式。

下一步所需的确切联合命题可以写成：在原完整来源与时间权下，证明 SS11 的端点部分加 nθ 连续部分≤可吸收 εX+C√n polylog(n)W_β/(2Λ)，或先证明端点在同一真实加权菜单中占比 O(1/n)、且剩余三维尺度来源平均有已付帽。仅证明 B 的形式菜单减少、有限源实例、或原端点≤1 均不足。

结论：SS7 与 SS7e 是保留共同 α/q/原门的自适应 H 连续及单端包络，SS12 及其单端替换给出全部实际价；SS9/SS9e/SS10r 提供确实减少加权 H 重复费用的可审估计与可验证分支。一般 n^{1/2+o(1)} 付款仍未证。仅写本文件，未改他人文件，未执行 Git/PDF；完成后停止。
