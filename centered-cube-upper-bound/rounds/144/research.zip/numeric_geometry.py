#!/usr/bin/env python3
"""Frozen R144 saved-data geometry diagnostic. No kernels, sampling or integration."""
import json,math,hashlib,datetime,time,statistics
from pathlib import Path
from fractions import Fraction as Fr
from collections import Counter,defaultdict
ROOT=Path(__file__).resolve().parent
INPUTS={
 'receiver':('centered_cube_round142_20261015/numeric_receiver.json','c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55'),
 'primitive':('centered_cube_round142_20261015/time_primitive_check.json','44758cfaba246b3fa8ed28ef05aa9919c6b6db58cfb3f7c99a530e457eff23e9'),
 'flux':('centered_cube_round143_20261015/numeric_flux.json','d43c449225d9d0eea6a5b3a6ceb977f8734d2813c09215324e70c79c9e836bb8'),
 'source':('centered_cube_round136_20261014/active_traffic_v2.json','1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de')}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def f(v):return Fr(str(v))
def jf(v):return Fr(int(v['numerator']),int(v['denominator']))
def rat(a,b):return a/b if b else None
def quant(v):
 v=sorted(x for x in v if x is not None and math.isfinite(x))
 if not v:return {'N':0}
 def q(p):
  z=(len(v)-1)*p;i=int(z);return v[i]+(v[min(i+1,len(v)-1)]-v[i])*(z-i)
 return {'N':len(v),**{str(p):q(p) for p in [0,.1,.5,.9,.99,1]}}
def corr(x,y):
 xy=[(a,b) for a,b in zip(x,y) if a is not None and b is not None and math.isfinite(a) and math.isfinite(b)]
 if len(xy)<3:return None
 x,y=map(list,zip(*xy));mx=statistics.mean(x);my=statistics.mean(y);dx=[a-mx for a in x];dy=[b-my for b in y];den=math.sqrt(sum(a*a for a in dx)*sum(b*b for b in dy));return sum(a*b for a,b in zip(dx,dy))/den if den else None
def ranks(v):
 so=sorted(range(len(v)),key=lambda i:v[i]);out=[0]*len(v);i=0
 while i<len(v):
  j=i+1
  while j<len(v) and v[so[j]]==v[so[i]]:j+=1
  for k in range(i,j):out[so[k]]=(i+j-1)/2
  i=j
 return out
def correlations(rows,keys):
 out={}
 for ia,a in enumerate(keys):
  for b in keys[ia+1:]:
   xy=[(r[a],r[b]) for r in rows if r.get(a) is not None and r.get(b) is not None]
   if not xy:continue
   x,y=map(list,zip(*xy));out[a+' ~ '+b]={'N':len(x),'spearman':corr(ranks(x),ranks(y)),'pearson_log_positive':corr([math.log(v) if v>0 else None for v in x],[math.log(v) if v>0 else None for v in y])}
 return out
BINS=[0,.01,.1,.5,.9,1,math.inf]
def tails(sources):
 totals={k:sum(s[k] for s in sources) for k in ['W','WD','Wrho']}
 out=[]
 for lo,hi in zip(BINS,BINS[1:]):
  ss=[s for s in sources if lo<=s['b']<hi];out.append({'lo':lo,'hi':None if math.isinf(hi) else hi,'N':len(ss),'rho_zero':sum(s['rho']==0 for s in ss),**{k+'_fraction':rat(sum(s[k] for s in ss),totals[k]) for k in totals}})
 return {'totals':totals,'bins':out,'quantiles':{k:quant([s[k] for s in sources]) for k in ['a','b','reserve_over_B','reserve_over_D','rho','L','j','B','W']}}
def summarize(rows,N=None):
 N=len(rows) if N is None else N
 out={'N':N,'positive_N':len(rows)}
 if not rows:return out
 keys=['p','q_over_lambda','R','R_over_Dq','reserve_qgap_fraction','hardmass_over_q','x_mean','x_min','x_max','F','internal','H0','HD','HR','HD_over_H0','HR_over_HD','internal_over_HR']
 out['quantiles']={k:quant([r[k] for r in rows]) for k in keys}
 out['good_patterns']=dict(Counter(r['good_pattern'] for r in rows));out['hard_patterns']=dict(Counter(r['hard_pattern'] for r in rows))
 out['correlations']=correlations(rows,['p','R','R_over_Dq','x_mean','H0','HD_over_H0','HR_over_HD','F'])
 out['source_joint']=tails([s for r in rows for s in r['sources']])
 names=list(rows[0]['source_weights'])
 out['source_allocation']={name:{
  'cap_active_rows':sum(r['source_weights'][name]['cap_active'] for r in rows),
  **{key:sum(r['source_weights'][name][key] for r in rows) for key in ['W','WD','Wrho','accepted_partial','accepted_accounting_lower','accepted_accounting_upper']}}
  for name in names}
 for weight in ['unweighted','outer','integration']:
  sums={k:sum(r[k]*(1 if weight=='unweighted' else r[weight]) for r in rows) for k in ['Eall','H0','HD','HR','internal']}
  out[weight+'_ladder']={'sums':sums,'position_ratio_H0_over_Eall':rat(sums['H0'],sums['Eall']),'local_ratio_HD_over_H0':rat(sums['HD'],sums['H0']),'reserve_ratio_HR_over_HD':rat(sums['HR'],sums['HD']),'FA_ratio_internal_over_HR':rat(sums['internal'],sums['HR'])}
 out['empirical_integral']=sum(r['F']/(r['p'] if r['distribution']=='p' else 1) for r in rows)/N if N else None
 out['incomplete_pair_rows']=sum(not r['pair_complete'] for r in rows)
 return out
start=time.monotonic();data={};hashes={}
for key,(rel,expected) in INPUTS.items():
 path=ROOT.parent/rel;actual=sha(path);assert actual==expected,(key,actual);hashes[key]=actual;data[key]=json.loads(path.read_text())
source={c['id']:c for c in data['source']['cases']};recovered={r['id']:r for r in data['primitive']['records']};flux={cid:{r['id']:r for r in c['records']} for cid,c in data['flux']['cases'].items()}
checks={'rows':0,'negative_R_direct':[],'negative_R_split_terms':[],'max_abs_Ralpha_minus_direct':0,'max_relative_Ralpha_minus_direct':0,'max_abs_Rsplit_minus_direct':0,'max_relative_Rsplit_minus_direct':0,'max_R_subtraction_condition':0,'max_abs_rho_rebuild_error':0,'max_rho_error_row':None,'zero_A_source_rows':0,'positive_zero_A_rows':0,'max_partial_excess_relative':0,'max_ladder_excess_relative':0}
allpos=[];cases={}
for cid,case in data['receiver']['cases'].items():
 src=source[cid];names=[a['name'] for a in src['atoms']];nu=list(map(jf,case['nu_exact']));D=f(src['parameters']['D']);T=f(src['derived']['T']);A=[f(a['A']) for a in src['atoms']];TA=[T*a for a in A];mat=[[float(v) for v in row] for row in data['flux']['cases'][cid]['time_kernels']['matrix_T_decimal']];psi=[[src['pairs'][i*6+j]['Psi'] for j in range(6)] for i in range(6)];Eall=sum(map(sum,mat));counts=defaultdict(Counter);rows=[];residuals=[]
 for r in case['records']:
  checks['rows']+=1;rid=r['id'];group=r['stage']+'/'+r['distribution'];counts[group]['N']+=1;counts[group]['main_pass']+=r['traffic']['main_gates_pass'];counts[group]['uncertain']+=bool(r['uncertain'])
  for gate,ok in r['gates'].items():counts[group]['fail:'+gate]+=not ok
  q=f(r['q']);qj=f(r['QJ']);U=list(map(f,r['U']));K0=list(map(f,r['K0']));J=list(map(f,r['J']));sumU=sum(nu[i]*U[i] for i in range(6));q0=sum(nu[i]*K0[i] for i in range(6));R=D*q-sumU;Ra=f(r['alpha'])*qj;gap=D*(q-q0);deficits=[D*K0[i]-U[i] for i in range(6)];Rsplit=gap+sum(nu[i]*deficits[i] for i in range(6));assert Rsplit==R
  for label,value in [('Ralpha',Ra),('Rsplit',Rsplit)]:
   checks['max_abs_'+label+'_minus_direct']=max(checks['max_abs_'+label+'_minus_direct'],float(abs(value-R)));checks['max_relative_'+label+'_minus_direct']=max(checks['max_relative_'+label+'_minus_direct'],float(abs(value-R)/max(abs(R),Fr(1,10**300))))
  condition=float((abs(D*q)+abs(sumU))/max(abs(R),Fr(1,10**300)));checks['max_R_subtraction_condition']=max(checks['max_R_subtraction_condition'],condition)
  if R<0:checks['negative_R_direct'].append([cid,rid,float(R)])
  if gap<0 or min(deficits)<0:checks['negative_R_split_terms'].append([cid,rid,float(gap),list(map(float,deficits))])
  sources=[];sw={};H0=HD=HR=0
  capactive={v['v'] for v in r['traffic'].get('FA_caps',[])}
  for i in range(6):
   W=sum(mat[i][j] for j in range(6) if r['bad'][j] and psi[i][j]) if r['good'][i] else 0.
   if not TA[i]:
    checks['zero_A_source_rows']+=1;checks['positive_zero_A_rows']+=r['rho'][i]>0;sw[names[i]]=dict(W=W,WD=0.,Wrho=0.,cap_active=i in capactive);continue
   a=D*K0[i]/TA[i];B=max(TA[i]-D*K0[i],Fr(0));j=J[i]/qj;b=R*j/TA[i];L=max(B-R*j,Fr(0));rho_calc=float(L/TA[i]) if r['good'][i] else 0.;err=abs(rho_calc-r['rho'][i]);
   if err>checks['max_abs_rho_rebuild_error']:checks['max_abs_rho_rebuild_error']=err;checks['max_rho_error_row']=[cid,rid,i]
   wd=float(B/TA[i])*W;wr=r['rho'][i]*W;H0+=W;HD+=wd;HR+=wr;sw[names[i]]=dict(W=W,WD=wd,Wrho=wr,cap_active=i in capactive)
   if r['good'][i]:sources.append(dict(source=names[i],source_index=i,a=float(a),B=float(B),j=float(j),b=float(b),reserve_over_B=float(R*j/B) if B else None,reserve_over_D=float(R*j/(D*K0[i])) if K0[i] else None,L=float(L),rho=r['rho'][i],W=W,WD=wd,Wrho=wr,cap_active=i in capactive))
  accepted=r['traffic']['positive_raw'] and r['traffic']['main_gates_pass'];counts[group]['positive']+=accepted
  if not accepted:continue
  fl=flux[cid][rid];F=float(fl['accepted_F']);internal=float(fl['accepted_internal']);outer=r['p']*r['hardmass']/r['q'];assert abs(F-internal*outer)<=1e-9*max(abs(F),1e-300)
  if cid=='P1':assert abs(F-float(recovered[rid]['F_raw']))<=1e-12*max(abs(F),1e-300)
  partial=r['traffic'].get('pair_contributions',[0]*36);partial=[float(v) for v in partial];psum=sum(partial);excess=max(psum-internal,0)/max(internal,1e-300);checks['max_partial_excess_relative']=max(checks['max_partial_excess_relative'],excess);unassigned=max(internal-psum,0);complete=r['traffic']['computed']
  for i,name in enumerate(names):
   own=sum(partial[i*6:(i+1)*6]);sw[name].update(accepted_partial=own,accepted_accounting_lower=own,accepted_accounting_upper=own+(unassigned if i in capactive and not complete else 0))
  excess=max(internal-HR,0)/max(HR,1e-300);checks['max_ladder_excess_relative']=max(checks['max_ladder_excess_relative'],excess)
  row=dict(case=cid,id=rid,stage=r['stage'],distribution=r['distribution'],p=r['p'],q_over_lambda=r['q']/case['lambda_saved'],R=float(R),R_over_Dq=float(R/(D*q)),R_qgap=float(gap),R_deficits=[float(nu[i]*deficits[i]) for i in range(6)],reserve_qgap_fraction=float(gap/R) if R else None,R_subtraction_condition=condition,hardmass_over_q=r['hardmass']/r['q'],x_mean=statistics.mean(r['x']),x_min=min(r['x']),x_max=max(r['x']),F=F,internal=internal,Eall=Eall,H0=H0,HD=HD,HR=HR,HD_over_H0=rat(HD,H0),HR_over_HD=rat(HR,HD),internal_over_HR=rat(internal,HR),outer=outer,integration=outer/(r['p'] if r['distribution']=='p' else 1),good_pattern=','.join(names[i] for i in range(6) if r['good'][i]),hard_pattern=','.join(names[i] for i in range(6) if r['hard_sources'][i]),source_weights=sw,sources=sources,pair_complete=complete,partial_total=psum,unassigned_internal=unassigned)
  rows.append(row)
 groups={g:summarize([r for r in rows if r['stage']+'/'+r['distribution']==g],cc['N']) for g,cc in counts.items()}
 cases[cid]={'n':case['n'],'layer_j':src['derived']['j'],'names':names,'parameters':{'D':str(D),'T':str(T),'TA':list(map(str,TA))},'counts':{g:dict(c) for g,c in counts.items()},'strata':groups,'positive_summary':summarize(rows),'positive_rows':rows};allpos.extend(rows)
assert checks['rows']==6951 and len(allpos)==179
out={'status':'completed_saved_data_diagnostic','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_sha256':hashes,'plan_sha256':sha(ROOT/'numeric_geometry_plan.md'),'script_sha256':sha(Path(__file__)),'scope':'No sampling/kernel/quadrature. Float saved-model diagnostics, not interval certificate, no order fit. Pressure separated from iid.','checks':checks,'cases':cases,'all_legal_positive_summary_descriptive_only':summarize(allpos),'elapsed_seconds':time.monotonic()-start}
# Post-hoc candidate requested by parent after first frozen diagnostic.
capacity_rows=[];capacity_strata={};positive_keys={(r['case'],r['id']) for r in allpos}
for cid,case in data['receiver']['cases'].items():
 src=source[cid];nu=list(map(jf,case['nu_exact']));n=case['n'];eta=Fr(4*(n+1)**2,3*n);D=f(src['parameters']['D']);T=f(src['derived']['T']);A=[f(a['A']) for a in src['atoms']];names=[a['name'] for a in src['atoms']]
 for r in case['records']:
  if (cid,r['id']) not in positive_keys:continue
  qj=f(r['QJ']);caps=r['traffic']['FA_caps']
  for si,seg in enumerate(src['score_segments']):
   ks=seg['k'];cs=list(map(f,seg['c']));lo=f(seg['lo']);hi=f(seg['hi']);mid=f(math.sqrt(float(lo*hi)))
   for v in range(6):
    if not r['good'][v] or not A[v]:continue
    for u in range(6):
     delta=ks[v]-ks[u]
     if not r['bad'][u] or delta<=0:continue
     psi=src['pairs'][v*6+u]['Psi'];cap=next((z for z in caps if z['segment']==si and z['v']==v and z['bad']==u),None);samples=[]
     for label,t in [('lo_right',lo),('geometric_mid',mid),('hi_left',hi)]:
      w=[cs[i]*t**(-ks[i]) for i in range(6)];et=sum(nu[i]*w[i] for i in range(6));c=D*f(r['K0'][u])*f(r['J'][v])*et/(T*A[v]*qj*w[u]*delta);ratio=float(c/eta)
      caplo=f(cap['lo']) if cap else None;caphi=f(cap['hi']) if cap else None
      in_closed=bool(cap and caplo<=t<=caphi);in_open=bool(cap and caplo<t<caphi);positive_interior=bool(psi and in_open and r['rho'][v]>0)
      samples.append({'label':label,'t':float(t),'c_over_eta':ratio,'high':c>eta,'Psi':psi,'FA_closed':in_closed,'FA_strict_interior':in_open,'positive_interior_occupation':positive_interior})
     capacity_rows.append({'case':cid,'id':r['id'],'stage':r['stage'],'distribution':r['distribution'],'n':n,'eta':float(eta),'v':v,'u':u,'v_name':names[v],'u_name':names[u],'segment':si,'delta':delta,'rho_v':r['rho'][v],'FA_cap':cap,'samples':samples})
for stage in ['initial','pressure','expanded']:
 prs=[r for r in capacity_rows if r['stage']==stage];samples=[s for r in prs for s in r['samples']];highprs=[r for r in prs if any(s['high'] for s in r['samples'])];occprs=[r for r in prs if any(s['high'] and s['positive_interior_occupation'] for s in r['samples'])]
 capacity_strata[stage]={'legal_positive_rows':sum(r['stage']==stage for r in allpos),'tested_pair_segments':len(prs),'tested_rows':len({(r['case'],r['id']) for r in prs}),'high_pair_segments':len(highprs),'high_rows':len({(r['case'],r['id']) for r in highprs}),'high_positive_interior_pair_segments':len(occprs),'high_positive_interior_rows':len({(r['case'],r['id']) for r in occprs}),'ratio_min':min(s['c_over_eta'] for s in samples) if samples else None,'ratio_max':max(s['c_over_eta'] for s in samples) if samples else None,'high_interior_examples':[r for r in occprs[:6]]}
out['posthoc_capacity_split_screen']={'protocol_append_date':'2026-10-15','scope':'Three saved endpoint/geometric midpoint checks per original score segment; endpoints use segment one-sided score. Not a whole-window classification or payment. e_t reconstructed from same R142 nu and saved source score coefficients.','strata':capacity_strata,'pair_segment_records':capacity_rows}
psi_fa_counts={}
for stage in ['initial','pressure','expanded']:
 prs=[r for r in capacity_rows if r['stage']==stage and r['samples'][0]['Psi']];fas=[(r,s) for r in prs for s in r['samples'] if s['positive_interior_occupation']]
 psi_fa_counts[stage]={'Psi_positive_pair_segments':len(prs),'Psi_positive_rows':len({(r['case'],r['id']) for r in prs}),'Psi_sample_count':3*len(prs),'Psi_high_sample_count':sum(s['high'] for r in prs for s in r['samples']),'FA_positive_strict_interior_sample_count':len(fas),'FA_positive_strict_interior_high_sample_count':sum(s['high'] for r,s in fas),'Psi_c_over_eta_min':min(s['c_over_eta'] for r in prs for s in r['samples']),'Psi_c_over_eta_max':max(s['c_over_eta'] for r in prs for s in r['samples'])}
out['posthoc_capacity_split_screen']['Psi_and_FA_separate_counts']=psi_fa_counts
out['execution_history']={'initial_saved_data_diagnostic_runs':1,'after_parent_append_full_arithmetic_replay_runs':1,'additional_summary_only_reads':'No re-evaluation of kernels, samples or integrals. Original 6951 arithmetic summary replayed once to add requested candidate, before later parent instruction to avoid repeating that summary. Subsequent update is JSON-only summary.'}
out['saved_data_full_diagnostic_execution_count']=2
(ROOT/'numeric_geometry.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':out['status'],'elapsed_seconds':out['elapsed_seconds'],'checks':checks,'positive':len(allpos)},ensure_ascii=False))
