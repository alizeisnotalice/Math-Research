# R144 冻结接收几何联合诊断协议

冻结后执行一次后处理，不新增接收点、核求值、时间求积、模型或维度拟合。读取R142 numeric_receiver.json、time_primitive_check.json，R143 numeric_flux.json及R136 active_traffic_v2.json的保存参数/score/Psi；不运行原producer，不修改旧数据。

## 符号与可计算字段

每行有x,p,K0,J,Q,q,q_tests,QJ,alpha,good/E/U/rho,hard_sources,CJ、门/margin、FA_caps；R142有原逐pair贡献（P1部分未算），恢复JSON补总F；R143保存原完整score积分T_ij（含ν_iν_j）而非FA截窗值。读取前SHA绑定。

A_v=0保留零行，所有归一化除法返回null。对A_v>0定义a_v=DK0_v/(TA_v)，B_v=[TA_v−DK0_v]+，j_v=J_v/QJ，b_v=Rj_v/(TA_v)，L_v=[B_v−Rj_v]+，rho=L_v/(TA_v)。j_v是密度比，原层级j仍保留在源参数中。R按三条保存数据式核对：R_alpha=alpha QJ；R_direct=Dq−ΣνU；R_split=D(q−Q0)+Σν(DK0−U)。使用十进制Fraction对保存字段做精确算术，报告差异、消减因子、负分量；负小值不截零。用于抑制的R取R_direct，另核对保存rho，说明float标签/核未获区间认证。

## 固定分层与输出

按原initial/pressure/expanded/control、case及uniform/p/pressure分层，所有6951行保留计数。合法正集合以原main_gates_pass且positive_raw定义，预期179；不以新阈值删行。压力点只作门边界诊断，不与随机流合算体积。uniform积分经验量是sum F/N；p流是sum(F/p)/N；恢复P1总F原样使用。报告位置(p、q/λ、坐标摘要、good模式、hard源)、余量与交通的描述性分位/相关性，不引入推断置信或阶数。

## 同一行的联合损失阶梯

定义W_v=Σ_{u bad}1_Psi T_vu，H0=Σ_good W_v，HD=Σ_good [1−a_v]+ W_v，HR=Σ_good rho_v W_v。Eall=ΣT_vu。T为原score正部整窗，无FA；故H0/HD/HR只称包络，不称原积分。保存rhos用于HR，并另核Fraction重建一致性。阶梯为Eall→H0（good/bad/Psi位置）→HD（D本地）→HR（共同reserve）→Iaccepted（FA）；允许有float舍入小超额，全部列出。

每层分别给未加dx权、真实外权p hardmass/q及抽样积分权（uniform:外权；p:外权/p）的总量与比。不同分布不混作一个积分；跨stage仅以各自N归一比较。W、[1−a]+W、rho W用于来源分配。原FA活跃来源由caps报告；完整pair行给原贡献，未完整行的保存非负partial为下界，recovered_total−partial为未分配余额，上界允许该余额全归任一活跃源，绝不伪装已恢复source值。

## 联合尾与相关统计

在合法正行的good且A>0来源上，固定b分箱[0,.01),[.01,.1),[.1,.5),[.5,.9),[.9,1),[1,∞)，同时报未削减W、HD权与HR权比例、rho=0计数；报告b、Rj/B、Rj/(DK0)、L/(TA)、R/Rq、j等分位，以及Spearman/Pearson(log)与接收位置p、R、j、a的描述关联。阈值固定为.01/.1/.5/.9/1，不优化。尾比例同时报W和rho W，说明点数与贡献是否分离。

## 误差与边界

本次无新增核或原函数验证；Fraction仅证明保存十进制模型内的代数，不认证真实核。P1总F已恢复，63行来源分配仍有缺项；partial与总量的微小差报告。三例不是维度序列，零命中不证明空集，实测相关不推出ν坐标独立、统一alpha下界或全局capacity。若需推理缺失处，明确标为待证联合几何命题。

## 追加协议（2026-10-15，事后容量二分候选）

主代理新增要求后，仅在原179合法正行上，使用实际good v、bad u及原score分段delta>0，计算
c(t)=D K0_u J_v e_t/(T A_v QJ w_t(u) delta)，eta_n=4(n+1)^2/(3n)。同一R142 nu及R136保存的每score段c_i/k_i恢复w_i=c_i t^(−k_i)、e_t=Σnu_i w_i。每段取原保存lo、sqrt(lo hi)、hi三个样本，端点采用该段单侧score/权表达。无新核、求积、采样或窗参数选择。

按原initial/pressure/expanded汇总tested pair/行、c>eta的pair/行、c/eta最小最大；另检查高点是否落原Psi且原FA_caps且rho_v>0的真实正占用（hi端点同时记录为截窗边界，不能凭单端点声称正测度）。保留具体case/id、源、段、t、c/eta和FA截端例。报告all good×bad正score与原Psi/FA占用两个版本。点检不判定全段高低门，不声称全段付款。追加后允许重新执行这个纯保存数据后处理，原诊断冻结内容及旧证据不改。
