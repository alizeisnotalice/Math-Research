# R289: full-soft spatial capacity profile, with explicit radius and source budgets

## Statement
Let n>=1, 0<a<=b<=2a, lambda>0. Let rho,nu be finite positive L1 measures fixed before the receiver choice. On a measurable E use measurable s(x) in [0,1], L(x),R(x) in [a,b], q(x) in [3lambda/4,lambda], and the original product kernel p_y(x)=P_(s(x),L(x))(x-y). Assume the ACTUAL two caps

 integral p_y(x)rho(dy)<=q(x),
 sup_(a<=t<=b)(h_t*nu)(x)<=4lambda.

No independence between the two source measures is assumed. Define the raw positive source-pair functional

 T(r0)=int_E q(x)^(-1) int int 1_{||y-z||_1<=r0}p_y(x)h_R(x-z)rho(dy)nu(dz)dx.

There is no posterior/score/time factor in this definition. Arbitrary original masks between zero and one can be retained. For every r0>0,

 T(r0)<=4(1+n r0/a) S_n,
 S_n=(16/3)||rho||+(1+log B_n)||nu||,                       (G1)

where B_n is exactly the R283 B_* with D=n:

 H_n=(n+2)[log(en)+log(2n+3)+15],
 E_n=H_n+log(n+1)+log(2n+3)+60e,
 B_n=e^2 n(n+3)[3+2log2+2log n+2E_n].                     (G2)

In particular B_n<=10000 e^2 n^3 log(n+2), hence

 1+log B_n <= [5+log(10000e^2)]log(n+2).                  (G3)

Thus r0=a/(16sqrt(n)) yields an all-soft O(sqrt(n)log(n+2)) source price. This is not a claim that all original traffic satisfies this radius bound. r0 comparable to na instead yields O(n^2 log n); that explicit cost must not be suppressed.

## Proof using the audited R281/R283 kernel geometry

The R281/R283 entropy construction is valid for arbitrary D>=0, not only D=O(log n). Taking D=n leaves the complete actual softness interval [0,1], with M=n rounded common soft laws. It yields the same finite weak-sum envelope constant B_n for every fixed source cube; D=O(log n) was used only to state a smaller asymptotic corollary.

Use a uniformly shifted grid of cubes of side d=2r0. For each original source pair, the probability of common-cell membership is

 prod_i (1-|y_i-z_i|/d)_+.

On ||y-z||_1<=r0 it is at least 1-sum_i|y_i-z_i|/d>=1/2. The grid is drawn independently before receiver selection and each source is allocated to one cell, with no copies.

We check that the R283 cluster-envelope proof works for this arbitrary positive d. For any fixed rounded rectangular shape Rvec, put U=1+sum_(soft i) Rvec_i^(-1)>=1. The diagonal coordinate change places the cell source inside a cube of side ell=d/min_i Rvec_i (including hard coordinates with side1). If ell<=a, R251 gives weak constant 2+n log(1+ell/a)<=2+n(d/a)U<=(2+nd/a)U. If ell>a, the universal strong scale envelope has mass 1+n log(b/a)<=1+n log2<2+n. Since (d/a)U>1, this is <=(2+nd/a)U. Thus in both cases the original shape bound remains valid with kappa_d=2+nd/a. No restriction d<=a is used. The same proof for the ordinary hard response gives weak constant <=kappa_d||nu_C||, using the strong scale envelope when d>a.

The fixed marked shape entropy argument of R283 is independent of d and gives weak constant kappa_d B_n ||rho_C||. The two actual response caps hold for restrictions to C by positivity. Its two-cap product lemma therefore yields

 int_E F_C G_C/q dx <= kappa_d[(16/3)||rho_C||+(1+log B_n)||nu_C||].

Sum over disjoint source cells, average the common shifts, and use the same-cell probability >=1/2 on the designated radius. This proves T(r0)<=2kappa_d S_n=4(1+n r0/a)S_n. This proof uses original dx; the shift is not a replacement receiver measure. For terminal collections, apply it before summing, and require the existing terminal-source mass ledger to bound each total source mass by W.

For (G3), write ell_n=log(n+2)>=1. For n>=1,
 log(en)<=2ell_n, log(2n+3)<=log5+ell_n,
 H_n<=3n(18+log5)ell_n<=60n ell_n,
 E_n<228n ell_n.
The bracket in B_n is at most 463n ell_n, and n(n+3)<=4n^2, yielding B_n<=1852e^2 n^3ell_n<=10000e^2 n^3ell_n. Then log n<=ell_n and log ell_n<=ell_n imply (G3). Constants are deliberately coarse and absolute.

## A genuine weighted spatial extension

For a nonnegative right-continuous nonincreasing radial weight psi with limit zero at infinity, finite psi(0), and integral_0^infinity psi(r)dr<infinity, the Stieltjes layer-cake of (G1) gives

 int_E q^(-1) int int psi(||y-z||_1)p_y h_R rho(dy)nu(dz)dx
 <=4S_n[psi(0)+(n/a)int_0^infinity psi(r)dr].             (G4)

Use the positive Stieltjes measure of -dpsi, Tonelli, and the strict/closed radius inequalities by monotone approximation. The identity integral r(-dpsi)=integral psi holds by Tonelli, without unproved boundary decay. Source-pair diagonal mass is zero for L1 measures; finite positive atoms can instead be treated by an explicit psi(0) term. Step weights follow exactly by finite summation. This supplies an actual weighted capacity budget when an original integrand admits such a majorant. It does NOT establish that the unresolved wide-distance traffic has this weight.

## Exact original reentry and its limit

R117 CL3 supplies the original beta cap int p beta<=P_(s,L)f=q and beta<=f; thus the theorem may use rho=beta without requiring beta=rho_current=beta-sigma_infty. The original hard source satisfies its independent hard cap. Accordingly the low-pe original T_(A^c) restricted ALSO to ||y-z||_1<=a/(16sqrt n) has the stated root-log source price, without using K, high, posterior or continuous score.

However R115 AR11's earlier near gate concerns ||x-y||_1<=16na; it implies only ||y-z||_1<=17na. R256/R257 introduced the much smaller source-near domain as a paid suballocation and explicitly retained its distance complement. The original low-pe wide complement cannot be declared paid using (G1). Likewise R288's score result concerns its small-source-near good-slot traffic, not all original high continuous traffic at arbitrary source distance. The historical/global notes provide precise references. The remaining task is a joint geometry bound for the genuinely wide source-pair traffic, or an original weighted comparison eligible for (G4), together with remaining prefix slots and full X ledger.
