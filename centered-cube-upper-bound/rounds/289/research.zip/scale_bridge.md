# R289 — a verified conditional bridge from whole-input octaves to all cube scales

## Result

The scale bridge is available with one logarithmic dimension factor. It requires an UNCONDITIONAL whole-input hard-cube octave weak estimate, uniformly over the octave location. It does not require summing source fees over infinitely many octaves. The missing premise in the supplied current reduction is completion of that whole-input octave estimate, rather than a new all-scale source-energy hypothesis.

The primary localization result was read directly: Assaf Naor and Terence Tao, *Random Martingales and localization of maximal inequalities*, arXiv:0912.1140v2, Theorem 1.1 and equations (10)-(11), PDF printed pages 5-6. It localizes the weak-(1,1) norm of a centered metric-ball maximal operator to radius blocks [r,nr] under n-microdoubling. [Primary paper](https://arxiv.org/pdf/0912.1140).

## 1. Precise sufficient octave hypothesis

For a full cube side L>0 write

    A_L f(x)=L^(-n) integral_{x+[-L/2,L/2]^n} f(y)dy,
    M_[a,2a]f=sup_{a<=L<=2a} A_L f,
    M_all f=sup_{L>0} A_L f.

Assume a finite constant A_n exists such that, for EVERY nonnegative f in L1(R^n), every lambda>0 and every a>0,

    lambda |{M_[a,2a] f>lambda}|<=A_n ||f||_1.           (OCT)

It suffices to prove this for [1,2] with the same arbitrary-input quantifier. For g(u)=f(au), both source mass and output measure acquire the factor a^(-n), while cube averages at sides 1 to 2 become those at sides a to 2a. Thus dilation gives the required uniformity without another dimension cost.

The same A_n must be independent of a,lambda,f, the number of scales, source partitions and any chosen selector. This is a theorem for the whole original input, not solely the retained FIRST/high/good/near/capture subclass. All complementary branches and threshold-band bookkeeping needed to reach (OCT) must be paid before the following conclusion is used.

Define

    m_n=max(1,ceil(log_2 n)),
    alpha_n=1+log(log 5)/(1+log n).

Let C_NT denote the universal implicit constant in Naor-Tao Theorem 1.1, equation (10), specialized to p=1. Then (OCT) implies

    ||M_all||_(L1 -> L1,infinity)
       <=C_NT[5+alpha_n m_n A_n].                       (ALL)

In particular this is at most C[1+A_n log(n+2)] for an absolute C. The imported theorem states its constant implicitly; this note preserves it as C_NT and does not invent an explicit numerical value. The displayed 5, alpha_n and m_n are retained exactly.

Consequently A_n<=C_0 sqrt(n)log^p(n+2) implies an all-scale coefficient C_1 sqrt(n)log^(p+1)(n+2), where C_1 depends only on C_0 and the fixed localization constant. The more general order sqrt(n)n^{o(1)} is also preserved.

## 2. Verified source applicability of Naor-Tao

Use ambient metric-measure space (R^n,||.||_infinity,dx). It is separable; dx is Radon; each nonzero finite-radius ball has finite positive measure. A metric radius r corresponds to full cube side 2r. The microdoubling ratio is exactly

    |B(x,(1+1/n)r)|/|B(x,r)|=(1+1/n)^n<=e<5.

Thus K=5 is a legal dimension-independent parameter in Theorem 1.1, whose hypothesis permits K>=5. The averaging denominator and the output measure are both the original Lebesgue measure. The arbitrary input f is an integrand, not the ambient measure. No doubling property of f dy, source comparability, product source law or bounded source density is required. [Theorem 1.1 and the metric-measure setup](https://arxiv.org/pdf/0912.1140).

This theorem applies directly to the HARD centered cube operator M_all. The soft P_s,L family with unbounded tails is not a family of metric-ball averages. A bound for a larger complete family containing s=0 would imply (OCT), but there is no direct Naor-Tao localization of the soft family asserted here.

## 3. Proof of the finite-block step and (ALL)

Fix a metric radius r>0. Its localization block [r,nr] corresponds to full cube sides [2r,2nr]. Since 2^{m_n}>=n, that block is covered by the FINITE list of full-side octaves

    [2^(j+1)r,2^(j+2)r], j=0,...,m_n-1.

At each fixed threshold lambda, a union bound and (OCT) therefore give

    lambda |{M_radius_[r,nr]f>lambda}|
       <=m_n A_n ||f||_1.

This bound is uniform in r, so the supremum over block operator norms is at most m_n A_n. Naor-Tao equation (10), with p=1 and K=5, now yields (ALL). Their equation (11) supplies the equivalent direct finite subdivision formulation. Only this finite number of source-W fees is summed. The passage from all blocks to the full operator is the localization theorem, not a second union bound over r.

For n=1, m_n=1 and [r,nr]=[r,r] is a single radius; the same argument is valid. There is no zero-length-log or missing low-dimensional case.

## 4. Arbitrary positive L1 and measurable finite-radius selections

The hypothesis can equivalently be supplied first for finite-valued measurable selections within each octave. For a fixed a, choose a countable dense set of full sides in [a,2a], including endpoints. For positive L, the average A_L f(x) is continuous in L at every x: cube boundaries have Lebesgue measure zero, and the locally bounded kernel densities admit dominated convergence against f(y)dy. Therefore the supremum over that countable set equals the full octave supremum.

For its first N sides, assign each point to the first side whose average exceeds lambda. This is a finite-valued measurable selector. A uniform selected-success bound gives (OCT) for the finite maximum; increasing N and using monotone convergence of superlevel sets gives (OCT) for the full octave. Thus an arbitrary continuous-radius supremum is not silently substituted into a finite-parameter estimate.

Once (ALL) holds, any measurable finite positive radius selection R(x) satisfies

    (2R(x))^(-n) integral_{B_infinity(x,R(x))} f
       <=M_all f(x),

and hence the same all-scale weak coefficient, irrespective of how large or small its finite selected radii are. For a finite or countable collection of radii, the same conclusion follows immediately; no selector-dependent constant is introduced.

If the proof of (OCT) is initially available only for nonnegative bounded compactly supported inputs, set

    f_j=min(f,j)1_{[-j,j]^n}.

These inputs increase to f. Each is treated as its OWN complete input in the universal octave theorem; one does not inherit the original f's FIRST equality on the cut. For every L, A_L f_j increases to A_L f, so the octave maximal functions also increase, and the mass norms increase to ||f||_1. The same A_n extends by monotone convergence. Naor-Tao may then be applied on all of L1. This extension uses positivity and the universal input quantifier, not a source truncation with a recomputed FIRST inside a previously fixed row.

## 5. What the supplied current reduction does and does not provide

I read `/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md`, sections 1-5, and the associated `/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION_REVIEW.md`. The reduction explicitly works with full sides in ONE octave and the SAME whole input and common threshold. Its section 5 says the localization step is available AFTER its two remaining source/output obligations are proved. The review certifies that conditional reduction and explicitly does not certify either remaining spatial payment or the full endpoint.

Thus the source applicability claimed there is correct: once the original octave weak estimate is complete for arbitrary positive inputs, the localization theorem supplies the permitted extra log(n+2). No common original FIRST cap across different octaves is a necessary hypothesis. The universal completed octave theorem can be applied to any inputs arising inside the known localization theorem without transporting a previous input's selected cap.

The smallest missing bridge is therefore the following precise input theorem, if not separately established in a later audited ledger:

    For all positive L1 inputs and all thresholds, the ENTIRE
    hard-cube single-octave success set has weak coefficient A_n
    at the proposed dimension order, uniformly in the octave.

An estimate only for an original near traffic, a good upper auxiliary slot, an actual FIRST subclass, a selected common-cap event or a residual with unpaid complements is insufficient for this quantifier. R288's conditional original near payment is a legitimate ingredient in such a proof, but is not itself (OCT). This file does not certify that R288 matches and closes every residual of the historical GENERAL reduction, or that all upstream payments, source ledgers and absorption constants now close.

No additional all-octave summability hypothesis is needed once (OCT) is actually proved. Conversely a finite-octave bound whose constant depends on the number of octaves does not supply (OCT) with the required uniform coefficient and cannot replace the localization argument.

## 6. Checked source identity and scope

The verified localization paper is Naor-Tao arXiv:0912.1140v2, not arXiv:1304.3392. The latter occurs nearby in the local literature notes as a different localization/disjoint-source reference. This audit used the original Naor-Tao Theorem 1.1, equation (10), its finite subdivision consequence (11), and the original Lebesgue cube microdoubling computation; no secondary summary was used as a substitute for the theorem's hypotheses.

## 7. Actual local arithmetic diagnostics

A local Python run checked 71 dimensions, including n=1, powers of two, adjacent non-powers and n=1000000. It verified the finite octave coverage 2^{m_n}>=n, exact rational microdoubling bounds below 3, the logarithmic bound on m_n and the dimension-uniform alpha_n bound. Output:

    PASS exact octave-cover / microdoubling / localization-factor cases=71
    alpha_max=1.4758849953271105

These arithmetic diagnostics check the explicit transfer parameters. The all-scale implication rests on the stated primary theorem and the finite-block proof above, not on numerical evidence. Only this temporary Markdown file was written; no repository or Git edits were made.
