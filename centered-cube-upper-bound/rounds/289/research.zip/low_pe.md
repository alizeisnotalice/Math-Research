# R289 — exact low-pe target, legitimate beta FIRST, and the all-soft near payment

## 1. Exact original target and its qualifications

Read directly from rounds/116/research.zip proof.md, embedded integration I1-I3, and rounds/117/research.zip proof.md CL1-CL6. The original low branch is

T_low=E_omega sum_V integral 1{p(x,y)e_(j,V)(y,g(x))<2Kq(x)} dT,

dT=q(x)^(-1)p(x,y)h_(R(x))(x-z)a_omega(x,y,z)
                                      dx beta_V(dy)nu_V(dz),          (1)

where p=P_(s(x),L(x))(x-y), g=sqrt(LR), j=j(x) is the unique actual ratio band, and 0<=a_omega<=1 retains ALL original FULL/FIRST/CP/GP/deep, accepted-hard, cut/rank, heavy, history, and R115 small-parent qualifications. The original e_g is the weighted nu mass on the original Z_g, not a local replacement:

e_g(y)=integral_(Z_g(y)) w_g(y,v)nu_V(dv).

The original heavy condition is

e_g>ell_n q c_j^(-n/2)g^n>0,  ell_n=1+log n.                (2)

Thus low pe implies p<2K c_j^(n/2)/(ell_n g^n). This is a kernel-density upper bound, not a bound on beta mass, posterior occupation, or receiver volume.

The outer R116 decomposition is T_small<=T_low+2H_K. The older outer reduction uses Lambda T_small, Lambda=128/119. Therefore a new estimate of T_low is multiplied by Lambda ONCE; it does not acquire the high-branch factor 2 or an auxiliary continuous score/clock integral.

The desired full statement remains a direct source-linear root-polylog bound, or epsilon X plus such a bound, for (1). The constructive result proved here pays its SMALL SOURCE-DISTANCE subbranch. The remaining scope defect is spatial, not failure of beta FIRST.

## 2. Archive lookup and the beta-versus-rho issue resolved

The targeted README search for low-pe references found explicit unpaid statements at rounds 117,118,119,120,121,122,125,126 and 241. R241 specifically says its source gate does not delete low-pe complements. R119 FA22 continues to carry T_low separately from H_init, H_jump and the high continuous terms. No established full low-pe payment was found in this targeted lookup; this is not a claim to have exhaustively reread every archive.

R117 CL3 explicitly states

integral p(x,y)beta_V(dy)/q(x)
 <=P_(s(x),L(x))f(x)/q(x)=1.                              (3)

The source chain in the original low object is beta_V<=mu_hi,omega<=f dx; equivalently the documented actual FIRST gives the required <=q. Thus beta inherits the necessary actual FIRST directly from f. No transfer from a later rho=beta-sigma_infty response is needed.

The R283 full proof in /tmp/r283_bellman.md uses arbitrary positive finite L1 soft sources satisfying their actual FIRST and independent hard sources satisfying the original hard cap. It never needs rho to be a particular complementary extraction. Hence applying that theorem with rho=beta_V is legitimate. No nu<=beta assumption is needed for that theorem, though the older low object records that stronger source relation. The original hard maximal cap gives h_R*nu_V<=4lambda, and q>=q_-=3lambda/4.

This resolves the source/cap concern positively. The remaining applicability condition is R283's source-near restriction, examined in Section 4.

## 3. New direct all-soft root payment on the legitimate source-near branch

Set r=a/(16sqrt(n)) and define

T_low,near=integral 1{|y-z|_1<=r}1{pe_g<2Kq} dT.            (4)

Every original remaining gate stays in (4). Apply the R283 raw near theorem with D=n, which is allowed because 0<=s<=1 automatically gives ns<=n. This has no auxiliary score, no posterior manipulation and no additional clock fee. Its fixed all-soft menu constants are

M=n,
H_n=(n+2)[log(en)+log(2n+3)+15],
E_n=H_n+log(n+1)+log(2n+3)+60e,
B_n=e^2 n(n+3)[3+2log 2+2log n+2E_n],
kappa_0=2+sqrt(n)/8.

The exact source estimate is

T_low,near<=2kappa_0[(16/3)W_beta+(1+log B_n)W_nu].         (5)

The low-pe gate, heavy gate, small-parent gate and original seed-dependent masks are only dropped positively in the upper majorant. The two source ledgers are summed once over their original disjoint terminal leaves and seed law. There is no use of high pe, no good-slot certification, and no borrowing of the R288 high continuous theorem.

For completeness the polynomial menu size is explicit. With L_n=log(n+2)>1,

H_n<=57nL_n,
E_n<=224nL_n,
B_n<=15000n^3L_n,
1+log B_n<=15L_n.

Indeed log(en)<=2L_n, log(2n+3)<=2L_n, n+2<=3n, 60e<164, e^2<8, and n+3<=4n. The final logarithmic inequality follows from log15000<10 and log L_n<=L_n. Consequently

T_low,near<=64sqrt(n)log(n+2)(W_beta+W_nu).                (6)

Its original outer price is Lambda times (5) or (6). It can be added to the high-route prices; the source costs cannot be replaced by a maximum merely because the traffic domains are disjoint.

The underlying R283 proof sums disjoint original coarse cell restrictions, uses both ACTUAL response caps, and averages the coarse shifts with the exact near-pair factor P_d^(-1)<=2, d=2r. That source allocation is why (5) is an actual dx/source bound rather than a sum of unpriced local weak estimates.

## 4. The spatial bridge required to apply (5) to ALL old low pe is absent

The old R115 near condition is NOT the same as (4). In rounds/115/research.zip proof.md AR11, the retained original near restriction is

|x-y|_1<=16na.

The original hard capture x-z in Q_R gives only

|y-z|_1<=16na+nR/2<=17na,                                (7)

exactly as R115's note following AR12 records. Its small-parent restriction side(P)<576na/epsilon does not improve (7) to r=a/(16sqrt(n)).

Thus the word "near" changed geometric scope: the old low-pe traffic can have source distances between r and 17na. The R283 coarse normalization P_d>=1/2 is guaranteed at |y-z|_1<=d/2=r. It cannot be used at the much larger distance (7) without a new cost or a proved earlier reduction covering the LOW branch. The R257 README still explicitly retains far-source/global terms, and the R273/R279 routes inspected here retain terminal-high. They do not furnish that missing low-pe bridge.

Accordingly it would be incorrect to claim that D=n in R283 pays all of (1). The exact newly unpaid expression after (5) is

T_low,far=integral 1{pe_g<2Kq}1{|y-z|_1>r} dT.             (8)

This remains an original positive traffic integral, with the same beta,nu,Z_g,e_g, actual selectors and true dx. The new result settles its source-near counterpart only.

## 5. Constructive combined split and smallest verified remaining interface

The already established R117 moderate-heavy root estimate can be applied to (8) without changing sources. Put

m_j(y,g)=e_g/[ell_n q c_j^(-n/2)g^n]>1.

For a fixed M>=1 chosen before receiver and input, R117 CL4 pays

T_low,far,m<=M <= M C_n ell_n S_n W_beta,
C_n=4+pi sqrt(n),  S_n<4.                                (9)

This is an OLD payment, not a new theorem. Together (5) and (9) give a valid disjoint decomposition and a smaller explicit remaining target:

T_low,far,m>M
 =integral 1{pe_g<2Kq}1{|y-z|_1>r}1{m_j(y,g)>M} dT.       (10)

For polylogarithmic M, the two displayed source payments remain root-polylog. The still-needed geometric inequality is

T_low,far,m>M <=epsilon X+C_epsilon sqrt(n)polylog(n)W_hi.  (11)

No claim of proving (11) is made. It must use the original accepted source/cut and broad-distance geometry, or a source-distance reduction VALID ON LOW pe. A constructive route is to establish such a reduction with explicit source responsibility: if its far part is paid with the right price, then the all-soft estimate (5) pays its near part immediately, with beta FIRST already verified. The source-distance reduction cannot be borrowed from a high-only posterior theorem.

For comparison, FIRST alone already gives the honest but insufficient global bound

T_low,far,m>M <=[1+n log(b/a)]W_nu,

by integrating the exact hard point-scale envelope after the beta source is consumed by FIRST. The actual pointwise cap also gives <=4X. Neither is a small epsilon X or a root source bound. The density restriction from (2) does not make d beta/e_g a probability measure, and no auxiliary source sampled from Z_g acquires the original hard capture gate.

The R288 linear affinity theorem requires an actual kernel certification p_y w_g(v)<=K K_i(x,v). Low pe alone gives only p_y e_g<2Kq, an integrated mass inequality; it does not provide that pointwise certification. Therefore no part of (10) has been silently charged to R288 on this basis.

## 6. Original source and measurability bookkeeping

All added distance and m gates are measurable functions of original data. Heavy rows have e_g>0; if p=0 their original traffic is zero. Full source zero sets require no inverse-mass convention in (5), since its proof uses only positive source restrictions and actual caps. The R283 all-soft D=n menu and shape laws are fixed independently of receiver; no new beta posterior or source-position change is used.

The low source ledger is the original W_beta=E sum_V ||beta_V|| and W_nu=E sum_V ||nu_V||, bounded by the corresponding original high-source ledger as recorded in R115/R117. When a,b or original data vary outside a leaf, all intermediate constants remain within those original sums until the stated dimension-only bound is applied.

The target extraction and source qualification are rigorous; the all-soft near payment is new at this ledger position. Full low-pe closure remains conditional on the far-distance/high-normalized-mass bridge (11).

## 7. Bounded examination of the inverse-m and small-parent route

The actual low gate gives the sharper density bound

p(x,y)<2K c_j^(n/2)/[ell_n g(x)^n m_j(y,g(x))].             (12)

This does not insert a factor 1/m into the original raw functional (1): replacing its density p by p/m would make a smaller traffic, whose recovery still costs m. Replacing p by the right side of (12) is valid, but loses the original soft kernel and hence its FIRST/source-cell weak bound. A mixed estimate retaining both facts would be new; neither step alone proves it.

The R289 spatial profile can be used if an actual nonincreasing radial majorant psi is proved, with source budget

4 S_n[psi(0)+(n/a) integral_0^infinity psi(t)dt].           (13)

For a root-polylog result, its bracket must be O(sqrt(n)polylog(n)); in particular the effective radial integral must be O(a/sqrt(n)polylog(n)) when psi(0) is bounded. The old source-radius ceiling 17na alone has integral 17na, yielding O(n^2) inside that bracket. Thus (12) must supply a genuine integrated spatial transfer, not merely a renamed high-m gate.

The precise small-parent issue can be seen directly in R114 S3-S5. Write

H_j(t)=q max{t^n,sqrt(n)c_(j+1)^n t^n,sqrt(n)(t^2/b)^n},
Z_j(y,g)=D_V(y) intersect [T_0(y) minus A_(j,g)(y)],

where A_(j,g)(y) is the coarsest original path node of hard mass <=H_j(g), with the documented finest-cell fallback. The accepted pair's actual LCA P obeys h(P)>H_j(g). Its small-parent upper bound controls the SIDE of this actual P. In contrast, e_g integrates the full original Z_j(y,g), not just P or the sources in P. Consequently e_g<=h(P) is not supplied by these definitions. Restricting its numerator to P would change the heavy mass and original low gate. Moreover h(P)>H_j(g) is a lower mass bound; a bound on side(P) alone does not reverse it into a mass upper bound.

This identifies a concrete interface for further construction: prove a source-conserving localization or mixed kernel-density estimate for (10) that retains the FULL e_g in its low gate and turns (12) into a radial budget of the form (13). A claim based solely on m being large, or on the actual pair having a small LCA, has not crossed this interface. No extra pointwise decay in |y-z| is asserted here.

## 8. Actual finite arithmetic diagnostic

Python 3 math was executed on n in {1,2,3,8,10,64,100,512,1000,1024,10000,100000,1000000,10000000,100000000,1000000000}. All five comparisons in Section 3 passed. Maximum observed ratios were respectively 0.843622 for H_n/(57nL_n), 0.886784 for E_n/(224nL_n), 0.790672 for B_n/(15000n^3L_n), 0.635650 for (1+log B_n)/(15L_n), and 0.633167 for the exact coefficient in (5) divided by 64sqrt(n)L_n. These are finite diagnostics; the elementary inequalities in Section 3 supply the proof for every n>=1.

Final scope: beta FIRST is resolved, the all-soft tiny-source-near low branch is source-paid, and the old moderate-heavy branch can be added at its stated cost. The original wide-distance, high-normalized-mass low-pe integral (10) remains unpaid. No global closure follows from this note.
