# R289 historical extraction: original `K` in the good/bad gate

## Finding

The archived original gate uses a **fixed positive parameter** `K`:

- `good`: `p_y w_g(v) <= K Q_x^*(v)`;
- `bad`: `p_y w_g(v) > K Q_x^*(v)`;
- `Q_x^*=(K_1+K_2+J)/3`, with `K_1=P_{s,L}(x-·)`, `K_2=P_{s,L^+}(x-·)`, `J=P_{1,b}(x-·)`, `L^+=min(b,γL)`.

The originating threshold calculation allows **any K>0**. I found no additional original admissibility restriction such as `K>=1` in the authoritative R116/R117 formulas. Later estimates can impose their own K conditions for a specific consequence. The R128 numerical harness explicitly says its chosen `K=64` does not certify legality under the original theorem; do not treat that finite-instance value as the original constraint.

## Exact excerpts and locations

1. **R116 `research.zip`, `proof.md`, lines 125–139 (F13–F14).** Exact quote: “给定 (K>0)” defines `D_K={z': p(x,y)W(x,y,z')>K Q_b(x,z')}`; integration over its complement gives `p(x,y)[e(x,y)-b_K(x,y)]<=Kq`; and “在真正高分支 (pege2Kq) 上…(b_K/ege1/2).” This is the source threshold derivation. It has no lower bound on K beyond positivity. The fee implication is linear in K in the threshold (`2Kq`) and yields the fixed one-half posterior mass; it is not itself an inverse-K estimate.

2. **R117 `research.zip`, `proof.md`, lines 54–65 (JG3–JG4).** It defines the actual three tests exactly as above and `D_K={z': p w_g(z')>KQ_x^*(z')}`, high set `A={p e_g>=2Kq}`. “R116 的证明逐字适用” gives `p e_g[1-Π_g(D_K)]<=Kq`, hence `Π_g(D_K)>=1/2` on A.

3. **R117 `proof.md`, lines 67–82 (JG5–JG6).** On the high/bad traffic, `T_small<=T_{A^c}+2H_K` (line 74). Using the original hard cap and `q>=3λ/4`, `H_K<=16/3 ...` (lines 76–80). This is the receiver/source reduction factor; note the factor 2 remains when returning to `T_small`. No inverse K appears in this step. The bound retains `e_g` inside `Π_g` (line 82).

4. **R217 `research.zip`, `audit.md`, lines 61–65.** With actual hypotheses `β<=f dx`, same-row `∫p_y β(dy)<=q`, and high gate `p_y e_g>=2Kq`, it states exactly `∫1_high β(dy)/e_g(y)<=1/(2K)` for fixed actual `x,V,j`. This is an inverse-K receiver/source-column fee from the original high normalization; the audit says FIRST must be the current actual one and x is fixed before removing y.

5. **R217 `research.zip`, `report.md`, lines 7–21.** A separate paid branch has complete price `16Λ L0 ε/(3K) W_A` on its stated mixed/good subregion (lines 15–19); choosing `L0=K√n`, `ε=1` gives root order (line 21). Here K enters the construction parameter `c=3L0/K` (line 10), and cancels under that choice; this is a later branch estimate, not a new admissibility rule on the original gate K.

6. **R226 `research.zip`, `boundary_payment.md`, lines 3–10.** Another later estimate prices a static gate by `16Λ/(3Kr) X`; selecting `r=16Λ/(3K ε_st)` yields `ε_st X`. This is inverse-K payment after choosing an additional gate parameter r. It does not constrain the original K.

7. **R226 `research.zip`, `audit.md`, lines 141–143.** For a separate uniform strict-contraction claim, it requires `K>max(16Λ/ε_st,3)` and explicitly characterizes this as a sufficient condition for that claim, not a necessary condition for pointwise descent. This is a later auxiliary condition, not a modification of original `K>0` legality.

8. **R128 `research.zip`, `proof.md`, lines 652–658 (RT5).** Confirms the exact `Q*` tests and original good/bad thresholds, then says “K 固定沿原定义.” `FIRST` gives upper bounds on the integrals of `K0`, `J`, and `Q*`; it does not give reverse mass bounds on low-kernel domains.

9. **R128 `proof.md`, lines 1540–1542 and 16481–16485.** The finite audit implementation requires explicit positive rational `--K`, but records `K_legal_for_original_theorem=NOT_CERTIFIED`; it says uniform `K=64` is not a proof of original-constant legality (1540). Its protocol likewise calls the CLI value merely an original-constant instance parameter and says the script does not certify original-theorem eligibility (16483). These are finite-check safeguards, not the theorem's admissibility rule.

10. **R128 `proof.md`, lines 811–817 (RT19).** A separate good-kernel receiver integral in the special exponential-affinity route costs `sqrt(K/3) exp(-c_* n)` per mesh point. Thus that receiver-side estimate grows like `sqrt(K)`; don't merge it with the inverse-K high-column fees above.

## Interpretation for the Sol/main review

Keep three roles distinct:

- Original parameter legality: R116 states `K>0`; the gate partition is valid for every such fixed K.
- High normalization: `p_y e_g>=2Kq` yields the inverse-K column estimate `1/(2K)` under the listed FIRST/source hypotheses.
- Later payment knobs: R217 and R226 have inverse-K formulas coupled to independently chosen `L0` or `r`; R226's `K>max(...)` only serves its uniform strict-contraction statement.

No new mathematical certification was performed. Search was limited to the relevant R116/R117/R128/R132/R135/R217/R226 archive members and targeted files; no repository or Git files were changed.
