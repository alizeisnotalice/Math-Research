# R289 independent parameter audit

## 1. Preauthor exponent screen

This statement-level screen was derived and sent to the parent before reading a new R289 author derivation. Only this audit file is owned/written; no repository state is changed.

Put ell=log(n+2)>1. Under 0<K(n)<=K0(n+2)^p and epsilon(n)=epsilon0(n+2)^(-p),

    log_+(sqrt(K)/epsilon)
      <=(1/2)log K0+log(1/epsilon0)+(3p/2)ell.

Thus the R279/R288 explicit log_+ tail thresholds, whose remaining factors are fixed constants and n^3(n+1), have D,H<=C(p,K0,epsilon0)ell. This uses only an upper bound on K and does not introduce log(1/K), so allowing K to approach zero is harmless for these threshold formulas themselves.

For the stated explicit R283 B_*, M=O(ell), H_*=O(ell^2), E_*=O(ell^2), and D+3=O(ell). Hence B_*=O(ell^4) with constants depending on the same parameters, and log B_*=O(1+log ell). The R288 small-soft complement price is therefore

    O(sqrt(n) ell^2[1+log ell])W,

which is bounded by C sqrt(n)ell^3 W. The high-soft exception uses kappa_0<=2+4sqrt(D) and is O(sqrt(n)ell[1+log ell])W; finite n<1024 is likewise harmless. Three source masses may each be bounded by W separately; their prices are added without claiming those source measures are disjoint.

This does not yet certify the complete conditional near-functional bound. The exact R277 exponential J price, its parameter range and the precise union of all original domains must be checked. A crude C_abs sqrt(K) bound does not yield the proposed result for arbitrary p. No assertion that any chosen K is legal in an earlier global reduction, or that the full weak theorem closes, is screened here.

## 2. Exact imported versions and final scope

The exact R277 statement, its completed audit, the R279 menu/tail statement and audit, the corrected R288 author, and the arbitrary-D R283 formula were read. Checked author bindings:

- `/tmp/r277_main.md`: `5394aa7d88d9ae8d912726cfacb9ec11aad826d51c88a5820a4356cefc63918e`.
- `/tmp/r277_final_audit.md`: `23c4737be24438b9d35ad51d1b04b0bc577518870f18b59aaa660fe4c4a37fac`.
- `/tmp/r279_main.md`: `16bb4d5e568fe9b5ecf2e3894964639b1d7e0924f5fb2735567ac7d5148d5d88`.
- `/tmp/r279_final_audit.md`: `14bda2764c7d67c4e6f771a3fab672fc46851f01a627ffa913d968d5c6dd3b9a`.
- `/tmp/r288_linear_gap.md`: `b5d9154b1e9cb6103ed4b4d96e00b421e53ba3d88cecf6b4f4679aec29de26b4`.
- `/tmp/r283_bellman.md`: `b557ed8a5e62c89da8cf036003f07922cf5f7d9a86b962cc8a1c5a8f1fc7124c`.

**PASS as a bounded conditional secondary consequence:** for fixed p>=0,K0>=1,epsilon0 in (0,1], the PRECISE current original good-upper-slot positive functional with SOURCE distance |y-z|_1<=a/(16sqrt(n)), actual original response caps, and all imported R277/R279/R288 row/source/clock qualifications has a C(p,K0,epsilon0)sqrt(n)log^3(n+2)W budget whenever 0<K(n)<=K0(n+2)^p and epsilon(n)=epsilon0(n+2)^(-p). Here Lambda=128/119 is fixed and each original source total is at most W. No assertion that such K(n) is a legal choice in the older global reduction is made.

This is not a claim about arbitrary near traffic: the J/moving covering uses the ORIGINAL GOOD qualifier p_y w_g<=K(K1+K2+J)/3. Bad slots, broader R115 |x-y|_1<=16na geometry, earlier reduction errors, signed credits and global absorption are outside this consequence. In particular the old broad source distance can be as large as 17na; it must not be substituted for the tiny source-near condition above.

## 3. Complete exact-J polynomial-parameter proof

R277 is valid for every K>0 and gives

    P_J<=(32Lambda/3)e^(3/2)sqrt(K)n^3(n+1)
          exp[-c_J n+A_J sqrt(n)]W_beta,
    c_J=(25/2^68)/20,
    A_J=e^(c_J)sqrt(2)/8.

Let m=4+p/2. For n>=1,

    sqrt(K)<=sqrt(K0)3^(p/2)n^(p/2),
    n^3(n+1)<=2n^4,
    A_J sqrt(n)<=(c_J/2)n+A_J^2/(2c_J).

The exact exponential price is therefore bounded uniformly by C_J(p,K0)W_beta, with the explicit finite choice

    C_J=(64Lambda/3)e^(3/2)sqrt(K0)3^(p/2)
          exp[A_J^2/(2c_J)] [2m/(e c_J)]^m,

using sup_(x>0)x^m exp(-c_J x/2)=[2m/(e c_J)]^m. This absorbs every fixed polynomial K growth. Replacing the exact R277 expression first by C_abs sqrt(K) would lose the argument and is not done here. No lower bound on K appears.

## 4. Uniform tail thresholds and explicit B_* growth

Write ell=log(n+2)>1 and C_tail=(64Lambda/3)e^(5/2). One may choose the SAME dimension-only threshold for every original source/outer datum using the cap on K:

    T_n=log_+[C_tail sqrt(K0)(n+2)^(p/2)
                         n^3(n+1)/epsilon(n)],
    D_n=H_n=1+(2/c)(B_c+T_n),
    c=(25/2^68)/432, B_c=18e^(4c)/c.

The actual K only decreases either tail prefactor, so the quadratic and linear moving tails each cost at most epsilon(n)W_beta. Let

    a0=log_+[C_tail sqrt(K0)/epsilon0],
    q0=4+3p/2,
    d_*=1+(2/c)(B_c+a0+q0).

Since n^3(n+1)<=(n+2)^4, T_n<=a0+q0 ell, and consequently 1<=D_n=H_n<=d_*ell. This establishes uniformity over original sources and scales, without silently taking variable parameters outside an original outer sum.

For any D<=d_*ell, define constants

    h_*=(d_*+2)[18+log(2d_*+3)],
    e_*=h_*+log(2d_*+3)+2+60e,
    b_*=3+2log2+2[log(d_*+1)+1]+2e_*,
    C_*=e^2(d_*+1)(d_*+3)b_*.

All are finite and depend only on p,K0,epsilon0 and the fixed structural constants. The provided formula, with its required 60e term, obeys

    M<= (d_*+1)ell,
    H_*<=h_*ell^2,
    E_*<=e_*ell^2,
    B_*<=C_*ell^4.

For example log(en)<=2ell, log(2D+3)<=log(2d_*+3)+log ell, and log ell<=ell give these inequalities directly. C_*>=1. With each W_rho,W_nu<=W, the source bracket satisfies

    S_D=(16/3)W_rho+(1+log B_*)W_nu
       <=C_S ell W,
    C_S=19/3+log C_*+4.

This intentionally adds the separate source prices; it assumes no disjointness between their masses.

## 5. Exact domain union, exceptions, and log-cubed payment

On the retained original good domain, outside E_J, KJ<p_yw_g and K(K1+K2+J)>=3p_yw_g force at least one moving certification p_yw_g<K K_i. Use a measurable deterministic tie allocation. Thus J and its moving complement cover this ORIGINAL GOOD source-near domain, without modifying Q*, FIRST or the complete posterior.

On the moving complement, first pay the quadratic tail ns+R2>=D_n by R279. On its exact complement ns+R2<D_n, split the physical exception n<1024 first and then n>=1024,s>1/1024. These branches have respectively the valid prices

    96Lambda sqrt(nD_n)S_D,
    16Lambda(2+4sqrt(D_n))sqrt(nD_n)S_D.

They are bounded by fixed multiples of sqrt(n)ell^3W using Section 4. For the second branch, n<1024D_n follows from ns<D_n and s>1/1024. No small-soft menu is applied there.

The remaining n>=1024,s<=1/1024 moving branch is split by the new linear tail ns+D1>=H_n, with source price at most epsilon(n)W_beta. Its exact complement has D1<H_n and is paid by R288 at

    4Lambda kappa_0 J_n(H_n)S_D,
    kappa_0=2+sqrt(n)/8<=17sqrt(n)/8.

Since H_n>=1,

    J_n(H_n)<=H_n[1+log_+(n/H_n)]
              <=2d_*ell^2.

The final small-soft price is therefore at most

    17Lambda d_* C_S sqrt(n)ell^3W.

The two tails add at most 2epsilon0W. The exact-J charge is at most C_J W. The two exceptions add at most

    [96Lambda sqrt(d_*)C_S
      +16Lambda(2+4sqrt(d_*))sqrt(d_*)C_S]
       sqrt(n)ell^3W.

Thus an explicit finite constant is the sum of these displayed coefficients, C_J, and 2epsilon0. The resulting bound is uniform for every n>=1, every permitted K(n)>0, arbitrary finite original sources satisfying the stated caps, and every original scale window a<=b<=2a. There is no hidden asymptotic restriction on n relative to the enormous structural constants. Cases where thresholds exceed all possible geometry simply have empty tail branches and still satisfy the same positive bounds.

All branches are restrictions of the same original functional. Source/receiver/clock prices use their respective audited order, and no original posterior is normalized anew. The source masses are bounded by W separately and their explicit prices are added. The physical exceptions and tail/complement assignments are made disjointly before adding them; no earlier paid branch is recreated.

**Frozen secondary receipt: PASS for this precise conditional source-near good-slot consequence and exponent three. It proves neither legal upstream K selection, broader spatial coverage, nor full global closure. Only this owned temporary audit file was written.**
