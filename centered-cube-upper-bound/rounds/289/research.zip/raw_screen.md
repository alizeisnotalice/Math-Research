# R289 independent all-soft raw-near screen

## 1. Preauthor algebra screen before R283 inspection

The following derivation was sent to the parent before inspecting R283's proof for this new application. It is conditional at this stage on P2 genuinely holding for arbitrary D>=0 under precisely the stated actual caps and original near radius. No beta/FIRST bridge, posterior, score, or global theorem is certified here.

At D=n>=1, the provided formula has M=n,

    H_*=(n+2)[log(en)+log(2n+3)+15]=O(n log(n+2)),
    E_*=H_*+log(n+1)+log(2n+3)+60e=O(n log(n+2)).

Thus B_*=e^2 n(n+3)[3+2log2+2log n+2E_*] is at most C n^3 log(n+2), with an absolute C and no source/scale dependence. Consequently log B_*<=C'log(n+2). Since kappa_0=2+sqrt(n)/8<=17sqrt(n)/8, the proposed P2 bound

    T_near<=2kappa_0[(16/3)W_rho+(1+log B_*)W_nu]

would give

    T_near<=C''sqrt(n)log(n+2)(W_rho+W_nu).

Every actual s in [0,1] satisfies ns<=n, so D=n removes the softness qualification. A truncated-coordinate auxiliary quadratic sum is also at most n, if one is present. This is an ALL-SOFT RAW near conclusion only: original actual response caps, actual selectors, Lebesgue receiver measure and near radius still have to be retained. It does not pay any posterior/score/physical-clock weighting by itself, and it must not be applied to a larger source beta without proving beta has the required actual FIRST cap.

The new audit obligation is to check that arbitrary-D P2 and its entropy/packet/source allocation proof contain no hidden D=O(log n), small-soft, scale, or source-comparison hypothesis.

## 2. Independent arbitrary-radius and radial-weight screen before new author

The parent then proposed a constructive arbitrary-radius extension. Before reading `/tmp/r289_geometry.md`, the following statement was independently screened and sent to the parent.

For r0>0 set coarse side d=2r0. The correct cluster factor is kappa=2+nd/a. A diagonal fixed-shape transformation puts the source in a cube of side ell=d/min R_i. If ell<=a, use the existing R251 support-qualified bound and log(1+ell/a)<=ell/a. If ell>a, use the universal strong scale envelope A=1+n log(b/a) instead. Since (d/a)min_i R_i^-1>1 and U_R>=max(1,min_i R_i^-1), kappa U_R>n+2>A in that second case. This also proves the hard cluster bound at arbitrary d by the same guard, without applying R251 outside its support-side hypothesis.

For |y-z|_1<=r0=d/2, the shifted coarse same-cell probability is at least 1/2. The unchanged marked entropy proof and actual capped product therefore give

    T(r0)<=2kappa S_n=4(1+nr0/a)S_n.

The case r0=0 has zero original product mass on its diagonal for L1 sources and is handled separately, not by a side-zero grid.

For a nonnegative nonincreasing radial profile psi with finite psi(0), finite integral and zero limit at infinity, Stieltjes layer cake applied to these radius inequalities gives

    T_psi<=4S_n[psi(0)+(n/a)integral_0^infinity psi(r)dr].

Open/closed radius endpoints are harmless because every fixed distance sphere has zero rho x nu product measure for L1 sources. For a non-right-continuous profile one may take its right-continuous version, which differs only on countably many such spheres; its total Stieltjes mass is psi(0+)<=psi(0). The first moment of that measure is integral psi. No claim is made that actual wide traffic possesses any desired decaying profile.

The requested bound B_n<=10000e^2 n^3log(n+2) is safe directly from the provided formula: with ell=log(n+2)>=1, H_*<=60n ell, E_*<=244n ell, the bracket is <=495n ell, and n(n+3)<=4n^2. This even gives 1980e^2 as a safe coefficient. The author's stated 10000e^2 therefore leaves ample room.

## 3. R283 arbitrary-D proof inspection and frozen dependencies

R283's complete proof and existing final audit were read, together with the relevant arbitrary-D common-soft and entropy statements from R281. Checked bindings:

- `/tmp/r283_bellman.md`: `b557ed8a5e62c89da8cf036003f07922cf5f7d9a86b962cc8a1c5a8f1fc7124c`.
- `/tmp/r283_audit.md`: `80af66d197e276b4ae61ef73a79af06ca550d36132943c079f4880066b62510f`.
- `/tmp/r281_soft.md`: `e5e04dfc7d21a7cdb5f1495eb81df78c77e1a3e3ae590acf926bf84a342f3681`.
- `/tmp/r281_soft_audit.md`: `3f58b9c60f3fb3471ac7d61973986d2ee637c3110496ee5bde53261fd2a0fdb1`.

There is NO hidden D=O(log n) hypothesis in P1/P2 or their entropy proof. D>=0 is the theorem domain. The smaller-D condition occurs only in the asymptotic corollary. At D=n the full interval 0<=s<=1 is covered, including s=1; M=n, the common-soft coefficient cover is valid, upward shape rounding still costs at most e, and nt_k<=D+2 remains true. The inverse-side moment and entropy bounds are uniform in D. Their geometric reference has exact normalization 2D+3, and no limiting small-D assumption is used.

The marked shape law is a fixed exact decomposition: U_R=1+sum_soft R_i^-1 has finite mean <=D+3. The inverse-side tilted law has its explicitly positive normalizer and finite entropy <=log(2D+3)+60e. Splitting each profile by its mark fractions does not duplicate its source or response. The countable fixed-weight weak-sum theorem therefore gives the stated B_*. All independence is that of kernel labels, never of the original rho,nu.

Both source cells are positive restrictions of the ORIGINAL sources. Actual F_C/q<=1 and G_C/(4lambda)<=1 follow by positivity from their respective original caps. Their envelopes receive weak bounds only. The capped product gives exactly kappa[(16/3)rho(C)+(1+log B)nu(C)]. Summing an actual disjoint grid charges each source mass once; averaging the original near same-cell probability contributes the sole factor two. Variable q(x) and arbitrary measurable actual selectors are legitimate because their actual functions are capped before the uniform weak envelopes and q_- are used.

Accordingly the ALL-SOFT RAW conclusion at D=n is valid under precisely the stated actual caps and scale/near qualifications. It supplies no posterior, score, j-clock or beta-FIRST bridge by itself.

## 4. Completed new author audit and constants

The new arbitrary-radius author proof was read in full:

`/tmp/r289_geometry.md`: SHA256 `22e303cbcbe0d2aa2f03cfacb652e771fde10ab00de9fd4524a8fb3d3fdd2224`.

**PASS for G1-G4 and their declared scope. No mathematical correction requested.** The general-d proof matches the independent screen in Section 2. In particular it handles ell>a by the strong scale envelope, for BOTH the hard cluster and every transformed soft shape. It does not invoke the support-qualified R251 theorem outside its range. The envelope mass 1+n log(b/a) is invariant under the fixed diagonal shape transform. Its determinant cancels in the weak level estimate. The exact same marked entropy proof is independent of d, so no radius-dependent label count or extra overlap factor occurs.

The random shift is a proof allocation fixed before receiver choice. Same-cell probability is exactly prod_i(1-|y_i-z_i|/d)_+, at least 1/2 on |y-z|_1<=d/2. Sources are restricted to unique cells, not copied into every neighborhood. The actual receiver measure remains dx. Positivity permits all original masks in [0,1] on the left. Thus, for every r0>0,

    T(r0)<=4(1+nr0/a)[(16/3)W_rho+(1+log B_n)W_nu].

There is no hidden source-density ratio, scale ratio beyond b/a<=2, inverse q factor, or source independence. This is a raw source-pair functional only. Outer-data-dependent radii/profiles and source constants must be kept in their actual original sums until a uniform comparison is supplied.

The author's explicit B_n bound is correct. Its H_n<=60n ell and E_n<228n ell, ell=log(n+2)>1, give a bracket <=463n ell, hence B_n<=1852e^2n^3ell<=10000e^2n^3ell. Therefore 1+log B_n<=[5+log(10000e^2)]ell as claimed. These are absolute constants, uniform for every n>=1.

## 5. Weighted radial theorem, endpoints, and spatial limitation

For the stated nonnegative right-continuous nonincreasing psi, let mu=-dpsi be its positive Stieltjes measure on (0,infinity). Limit zero and right-continuity at zero give total mass psi(0). Its tail recovers psi with the appropriate strict endpoint convention. Since original sources are L1, every fixed-distance sphere has rho x nu product measure zero, including the diagonal, and Tonelli permits any strict/closed radius version in the weighted traffic. A side-zero random grid is never used.

Apply G1 under the positive Stieltjes integral. Tonelli gives integral r mu(dr)=integral_0^infinity psi(r)dr directly, so no unjustified boundary limit of r psi(r) is required. This proves exactly

    T_psi<=4S_n[psi(0)+(n/a)integral psi].

Step profiles are included by the same argument. The author's sentence concerning positive atoms is read only as an endpoint-accounting observation; this audit's kernel/source theorem is for the stated L1 inputs and does not certify an additional arbitrary-atomic source theorem.

The theorem requires an ACTUAL radial weight/majorant if used on another original integrand. It does not create such a profile from low pe, large accepted mass, small-parent side, or another source moment. At the tiny radius a/(16sqrt(n)) it gives a root-log price. At r0=17na it only gives order n^2log n; no favorable tiny-radius factor can be substituted for that broad geometry.

## 6. Distinct low-pe coefficient check and precise reentry scope

The low-pe author's exact source/cap and historical-scope trace was supplied separately. This audit does not repeat that archive-history investigation. The completed note was read, including its final added inverse-m/small-parent discussion:

`/tmp/r289_low_pe.md`: SHA256 `d1540f1f24482b8e8479e5cbb7f8c32aa4d8fca5babe3cc7e7ebb24088829c9e`.

The displayed all-soft numerical coefficient is independently verified. With ell=log(n+2)>1,

    log(en)<=2ell, log(2n+3)<=2ell,
    H_n<=57n ell,
    E_n<=224n ell             (using 60e<164),
    B_n<=15000n^3ell          (e^2<8, n+3<=4n).

Indeed the last bracket is at most 455n ell, so the preceding constants already give 14560n^3ell. Since log15000<10 and log ell<=ell,

    1+log B_n<=15ell,
    2kappa_0<=17sqrt(n)/4.

The exact P2 bracket is consequently at most

    (255/4)sqrt(n)ell(W_beta+W_nu)
      <64sqrt(n)ell(W_beta+W_nu).

Thus the claimed 64 constant is safe. This direct raw low-pe subbranch has only its original outer Lambda multiplier, not the high continuous factor two or an auxiliary score clock. Different source prices must still be ADDED, even when their traffic branches are disjoint.

Reentry with rho=beta is accepted under the separately checked original R117 CL3 cap integral p beta<=q; it is not inferred from the later cap for rho=beta-sigma_infinity. The source-near condition is an independent indispensable qualification. The supplied original R115 broad |x-y|_1<=16na and hard support imply only |y-z|_1<=17na. The low-pe gate is an integrated pe_g bound, not a pointwise moving-kernel certification. Therefore neither the new raw theorem nor R288's high good-slot result silently pays the old broad-distance low-pe complement.

The low-pe note correctly retains the exact original far-distance/high-normalized-mass remainder after its stated older moderate-heavy payment. Its extra discussion does not infer e_g<=mass(actual pair LCA), a 1/m factor in the original integrand, or an actual decaying radial profile from a small-parent side bound. Those would each require a new source-conserving estimate. The beta-FIRST repair and tiny-source-near payment do not close that spatial gap.

## 7. Actually run bounded diagnostics

The existing local vendored mpmath was used at 50 digits. Nine dimensions through 10^100 checked the four explicit menu/log bounds and the resulting coefficient 64. Sixty scalar fixed-shape guards checked both ell<=a and ell>a over dimensions, radii and inverse-side factors. Eight Fraction identities checked positive multistep Stieltjes budgets exactly. Actual output:

    PASS all-soft explicit constants=9 general-d fixed-shape guards=60 exact weighted-step identities=8
    Finite exact/scalar diagnostics only; no actual-wide-traffic decay, beta-FIRST, or global closure certificate.

These are finite diagnostics. The analytic proofs above establish all-radius and all-weight assertions. The computations do not certify a full original L1 history, a source-FIRST bridge, outward-rounded intervals, or any posterior/geometry correlation.

## 8. Final README mathematical integration check

The final README was read in full at

`/Users/zhengzhihao/Desktop/T/output/centered_cube_round289_20261017_final_checkpoint/README.md`: SHA256 `45cb980ff76002c6aa80a8d6a7574ce22bd28441c443dde4dc37fe69315f7832`.

**PASS for mathematical integration of the audited claims.** Its arbitrary-radius coefficient, B_n bound, weighted profile conditions and price, tiny-source-near root-log consequence, explicit broad-radius n^2log n cost, low-pe constant 64 and single Lambda multiplier match the audited proofs. Its parameter consequence is restricted to the original good/high/source-near qualifiers, consistently with the separately frozen `/tmp/r289_parameter_audit.md` proof. It does not treat polynomial K control as legal upstream K selection or suppress inverse-K/global absorption obligations.

The README explicitly leaves broad low-pe, original prefix/deletion slots, continuous far-source traffic, original-X entrance and full global absorption unproved. It correctly distinguishes R115 receiver-near from the later tiny source-near allocation. Its scale-localization discussion says a COMPLETE arbitrary-input one-octave theorem would still be required; this audit does not independently re-review the parent's primary-paper scale theorem verification or certify that missing premise. The numerical section clearly limits finite tests. No global root theorem or automatic radial-weight property is asserted.

**Frozen final receipt: PASS for the constructive capacity theorem and its exact stated reentries, at the author/README hashes above. Near ONLY where the tiny radius is invoked; the true wide-distance and prefix/global gaps remain. Only this owned temporary audit file was written.**
