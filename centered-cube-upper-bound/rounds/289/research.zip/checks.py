#!/usr/bin/env python3
"""R289 bounded scalar/finite rational diagnostics; mpmath required."""
import json,random
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp
R=random.Random(28920261017)

def constants(n,dp):
 with mp.workdps(dp):
  n=mp.mpf(str(n));H=(n+2)*(mp.log(mp.e*n)+mp.log(2*n+3)+15)
  E=H+mp.log(n+1)+mp.log(2*n+3)+60*mp.e
  B=mp.e**2*n*(n+3)*(3+2*mp.log(2)+2*mp.log(n)+2*E)
  C=10000*mp.e**2;Cp=5+mp.log(C)
  rB=B/(C*n**3*mp.log(n+2));rlog=(1+mp.log(B))/(Cp*mp.log(n+2))
  assert rB<=1 and rlog<=1
  return tuple(+x for x in [H,E,B,rB,rlog])
def constant_stage(ns):
 worst=mp.mpf(0);maxB=mp.mpf(0);maxlog=mp.mpf(0)
 for n in ns:
  low=constants(n,40);high=constants(n,60)
  with mp.workdps(90):
   err=max(abs(x-y)/max(1,abs(y)) for x,y in zip(low,high));assert err<mp.mpf('1e-35')
   worst=max(worst,err);maxB=max(maxB,high[3]);maxlog=max(maxlog,high[4])
 return {'cases':len(ns),'precision_runs':2*len(ns),'n_values':[str(n) for n in ns],'max_B_over_Cn3log_ratio':mp.nstr(maxB,15),'max_logB_over_Cprime_log_ratio':mp.nstr(maxlog,15),'max_normalized_40_vs_60_error':mp.nstr(worst,15),'max_bound_violation':'0'}

def samecell(ns):
 count=0;minp=F(1)
 for n in ns:
  for style in ['concentrated','equal','rational_random']:
   for mass in [F(0),F(1,1000000),F(1,4),F(1,2)]:
    d=F(R.randint(1,30),R.randint(1,30))
    if style=='concentrated':ds=[mass*d]+[F(0)]*(n-1)
    elif style=='equal':ds=[mass*d/n]*n
    else:
     weights=[R.randint(1,100) for _ in range(n)];total=sum(weights);ds=[mass*d*w/total for w in weights]
    assert sum(ds)<=d/2
    p=F(1)
    for delta in ds:p*=max(F(0),1-delta/d)
    assert p>=1-sum(ds)/d>=F(1,2)
    minp=min(minp,p);count+=1
 return {'cases':count,'dimension_values':ns,'profiles':['concentrated','equal','rational_random'],'minimum_samecell_probability':str(minp),'max_exact_bound_violation':'0'}

def layercake(count,maxsteps):
 for j in range(count):
  n=R.randint(1,10000);a=F(R.randint(1,100),R.randint(1,100));S=F(R.randint(0,100),R.randint(1,100))
  k=R.randint(1,maxsteps);widths=[F(R.randint(1,100),R.randint(1,100)) for _ in range(k)]
  weights=sorted([F(R.randint(1,100),R.randint(1,100)) for _ in range(k)],reverse=True)+[F(0)]
  radius=F(0);lhs=F(0);area=F(0)
  for i in range(k):
   radius+=widths[i];area+=weights[i]*widths[i]
   kappa=2+2*n*radius/a
   # 2*kappa*S = 4*(1+nR/a)*S; atoms of -dpsi at step endpoints.
   lhs+=2*kappa*S*(weights[i]-weights[i+1])
  rhs=4*S*(weights[0]+n/a*area)
  assert lhs==rhs
 return {'cases':count,'max_steps':maxsteps,'max_exact_layercake_error':'0','boundary_convention':'psi is right-continuous on [0,infinity); positive width steps; final value zero; -dpsi atoms at positive right endpoints.'}

settings=[('initial',list(range(1,33)),[1,2,3,10],24,3),('boundary_stress',[63,64,65,511,512,513,1023,1024,1025,2047,2048,2049],[1,31,64,128],64,10),('expanded',[10**k for k in [1,2,3,4,6,10,20,50,100]],[1,100,257,1000],128,32)]
stages=[]
for name,ns,dims,lc,steps in settings:
 stages.append({'name':name,'R283_constants':constant_stage(ns),'random_shift_samecell':samecell(dims),'radial_layercake':layercake(lc,steps)})
out={'status':'PASS','seed':28920261017,'constant_C':'10000*e^2','constant_Cprime':'5+log(C)','scope':'Finite ordinary mpmath40/60 checks of explicit R283 D=n constants and exact Fraction random-shift probability / decreasing-step layercake algebra. Not intervals, an actual FIRST/source certificate, a continuous-history model, or a theorem-ledger audit.','stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
