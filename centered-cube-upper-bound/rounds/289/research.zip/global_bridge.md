# R289 bounded constructive original global-bridge audit

## Result

I did not obtain the requested unconditional

`X <= A_old W + alpha_old X + C_geom P_cur`, `alpha_old<1`,

with **all** other branches priced and `P_cur` exactly the R277 current original positive near traffic (already including `2 Lambda`). The strongest explicitly assembled ancestor ledger found contains **four additional nonnegative original slots**: low `pe`, initial low test, deletion-jump low test, and large deletion dissipation. The requested reduction cannot follow merely by pricing the current continuous near positive slot.

This is a bounded positive result about the actual surviving integral, not a claim that no later proof can pay those slots. The later explicit audit R227 independently identified the same missing consolidation. R288's audited conditional positive payment is assumed; its finite-kernel argument is not re-proved here.

Only `/tmp/r289_global_bridge.md` was written; no repo/Git/PDF changes.

## Priority scope finding: tiny source-near was an added subpart, not a global reduction

The decisive geometric distinction is now verified directly in the analytic original files:

- R115 `astra_receiver.md:117` proves only `||y-z||_1<=16na+nR/2<=17na` from the actual original receiver-near support. It does not prove `||y-z||_1<=a/(16sqrt(n))`.
- R256 `cluster_payment.md:185–205` **defines a new restriction** `N_D` with `||y-z||_1<=D/2` and proves its price. Lines204–205 expressly say this is not an assertion that all original contributing source pairs are near.
- R257 `actual_bridge.md:195–205` adds the metric-near restriction to the original continuous positive traffic and explicitly says its genuine distance complement is unpaid. `mixed_geometry.md:214–223`, after the full score/clock price for strong-soft near traffic, explicitly retains low-soft near **and all far-source pairs**.
- R259 `joint_geometry.md:43–48` defines its H by inserting `1_{||y-z||_1<=r}`, `r=a/(16sqrt(n))`; the later useful inequality `e_g>=eta R^n H` is therefore a near-restricted statement, not a deduction of near support for all original traffic.

Thus the most concrete missing geometric bridge is the positive far-source complement

`P_cont,far = 2Lambda E sum_(V,j) integral 1_A 1_{||y-z||_1>r} dT_(j,V)`

`             integral_(Jfar) dt/t integral_(v in terminal-good) integral_(u in terminal-bad)`

`             [original unspent positive weights] [k_t(v)-k_t(u)]_+ dPi_t(v)dPi_t(u)`.

The original support restricts this to `r<||y-z||_1<=17na`, not to the empty set. The upper cutoff comes from actual original support, not a new source truncation. A payment for all of the current **near** P_cur cannot price P_cont,far. Neither R256 nor R257 furnished such a far-source payment. Targeted analytic supplement/header search across R257–R288 found no complete replacement far-source ledger; this is a bounded search statement, not a claim of a proof of nonexistence.

Split every prefix in section2 using the same original source-pair indicator: `T_Ac=T_Ac,near+T_Ac,far`, and similarly I/J/D. Parent-reported independent verification now supplies original beta FIRST (`R117 CL3`) and a direct `D=n` use of R283's full-soft raw near bound; this can price **T_Ac,near** without any score. It does not reach T_Ac,far. The initial/jump/deleted slots still require their own actual weights/time measures or independent payments; I do not infer them closed from the raw-near estimate.

Accordingly, after accepting the new near low-pe and R288 near-continuous payments, the explicit broader remaining candidate is

`U_far+atoms/deleted = Lambda T_Ac,far + 2Lambda(I_rem+J_rem+D_rem) + P_cont,far`,

with any separately proved near I/J/D prices subtracted only by their exact positive allocations. The negative credits remain once on the original common measure. This far-versus-near coverage issue is more immediate than the separate original-X entrance audit below.

## 1. Strongest explicit downstream ancestor ledger

Use original `X=lambda |E_0|`, `Lambda=128/119`, full source `f`, real receiver `dx`, original seeds, terminal leaves and unique `j(x)`.

R113 `joint_budget.md:339–349` (B36), coupled-source replacement `integration_main.md:9–29`, R114 `proof.md:307–340` (S11–S14), and R115 `astra_receiver.md:165–176` (AR17) yield the following original remainder inequality:

`R_out <= A_pre + alpha_pre X + Lambda T_small`.                 (B1)

Here one may take

`A_pre = P104 + B105 W_mu + C_h A_far W_hi`

`        + Lambda [A_tree W_stop + K_(eta*,r) W_eta* + A_tail(delta) W_light`

`        + (C_mix K_s sqrt(n)+C_GP+n^-1+C_n ell_n+Kcal_alpha) W_hi]`,

`alpha_pre = 19/768 + Lambda(epsilon+delta+k0 kappa_n+epsilon_LP)`.

Definitions:

- `19/768=1/768+3/128` exactly combines the pre-tree error with R112 I4's hard/soft row fees; no old epsilon is suppressed.
- `epsilon_LP` is R115's new large-parent error, giving `Lambda epsilon_LP X` (AR17). It is independent of earlier errors.
- `B105=2+3sqrt(n)+log(16/beta^2)`, `beta=1/6144`, from R107 `proof.md:946–950` and R105 `proof.md:15–21`.
- `C_h=16/3`, `C_n=4+pi sqrt(n)`, `ell_n=1+log n`.
- `Kcal_alpha` is given fully in R113 `joint_budget.md:295–304` (B32), including `C_s(n)=1+34log2+(1+36log2)(1+log n)`; it is `O(sqrt(n)log^3(n+2))`.
- B36 is legitimate after R114 because `K_beta,114<10 C_n ell_n<=Kcal_alpha` and the soft extracted/residual masses are exactly complementary. This does **not** merge soft fees into the five-part hard-source ledger.
- R104 `proof.md:825–842` gives the explicit earlier price `P104`: with `epsilon104=1/3072`, `D104=2sqrt(n)`, `beta=1/6144`,

`P104 = [C2^2/(4epsilon104)]sqrt(n) W_cap`

`        +{D104[1+log(4D104/epsilon104)]+1+log(4/beta^2)+sqrt(n)} W_res`.

`W_cap+W_res<=W`; the separate `X/768` is already included in `alpha_pre`. The symbol `K=sqrt(n)` in this R104 cap construction is **not** R116's later good-test parameter K.

The remaining older tree/hard/GP coefficients in `A_pre` are preserved with their original named definitions. I did not replace them by an unverified new absolute constant or independently recertify every old source price. Even assuming their advertised root/polylog order, B1 still has the additional slots below.

## 2. Exact additional slots from the original full decomposition

R123 `current_ledger.md:59–73`, G123-current, gives

`Lambda T_small <= (epsilon_near+epsilon_FA+epsilon_IJ+epsilon_D+epsilon_G) X`

`                    + C_G(epsilon_G)sqrt(n) W_beta + Lambda T_Ac`

`                    + 2Lambda I_rem+2Lambda J_rem+2Lambda D_rem`

`                    + 2Lambda P_(Zc,1-b)-2Lambda N_Zc-2Lambda N_del`.   (B2)

The current R125 AC11 version is explicitly reproduced in `research_checkpoint.md:37–52`: it **only replaces** the continuous positive capture weight `b` by `b_D` at the same price; low `pe`, I/J/D and both negative quantities remain. R126/RC and subsequent SP/MA likewise act on this last positive slot, not on the four other terms; R128 RT1–RT3 and R223 NC4–NC5 bind its exact original normalization.

Combining B1+B2 yields the actual constructive inequality

`R_out <= A_pre+C_G sqrt(n)W_beta + alpha_down X + U_prefix`

`         + 2Lambda P_(Zc,1-b_D)-2Lambda N_Zc-2Lambda N_del`,          (B3)

where

`alpha_down=19/768+Lambda(epsilon+delta+k0 kappa_n+epsilon_LP)`

`           +epsilon_near+epsilon_FA+epsilon_IJ+epsilon_D+epsilon_G`,

`U_prefix=Lambda T_Ac+2Lambda(I_rem+J_rem+D_rem) >=0`.

This is an explicit surviving **integral**, not just a missing label. At the old stage its definitions are as follows.

### Low pe

R116 `integration.md:15–31` (I1–I3), R117 `proof.md:264–308` (CL1–CL3):

`dT_(j,V)=1_{j(x)=j} q^-1 p_y(x) h_R(x-z) a_omega(x,y,z)`

`          dx d beta_V(y) d nu_V(z)`, `0<=a_omega<=1`,

`A={p_y(x)e_(j,V)(y,g(x))>=2Kq}`,

`T_Ac=E sum_(V,j) integral 1_{p_y e_g<2Kq} dT_(j,V)`.

The source density bound `p_y<2K c_j^(n/2)/(ell_n g^n)` is not a spatial payment. CL3 only directly gives `T_Ac<=4X`. For K=1 the exact low branch is already defined and valid. The bounded-degree subbranch CL4 pays `T_low,m<=M <= M C_n ell_n S_n W_beta`, `S_n<4`, but its `m>M` complement remains an explicit separate term; taking M→infinity makes the price diverge.

### Initial and deletion-jump low tests

R120 `initial_jump.md:154–181` (IJ15), R121 `global_ledger_audit_private.md:55–80`:

`I_rem = E sum_(V,j) integral 1_A dT_(j,V)`

`        [e_tau^-1 integral_(D_g) 1_{ell_tau<B_IJ theta0} w_tau d nu]`,

`J_rem = E sum_(V,j) integral 1_A dT_(j,V)`

`        sum_(u in true deletion times) [Pi_u(D_g)/e_(u-)]`

`        integral_(Z_(u-)\Z_u) 1_{ell_u<B_IJ theta_u} w_u d nu`,

where `ell_t=Q_x*/(p_y w_t)`, `theta0=e_g/e_tau`, `theta_u=Pi_u(D_g)e_g/e_(u-)`. The jump is a time atom, not a `dt/t` contribution. It cannot be covered by a theorem about the continuous score integral by assigning a new time density. These retain the original hard z and real dx; auxiliary deletion points do not inherit hard capture.

### Large deletion dissipation

R120 `deleted_dissipation.md:210–223` (MG22–MG23), R121 `global_ledger_audit_private.md:20–36`:

`D_rem = E sum_(V,j) integral 1_A dT_(j,V) integral_(Jfar) dt/t`

`        integral_(b in D_g) integral_(v in Z_t\Z_g)`

`        1_{mathscr D_j(y,g;u)>d_D} 1_{ell_t(v)<B_FA delta_t(v,b)}`

`        delta_t(v,b) dPi_t(v)dPi_t(b)`.

Here `delta_t(v,b)=[k_t(v)-k_t(b)]_+` and `mathscr D_j` is the actual integrated weight-decrease quantity of MG5. The paid complementary domain `mathscr D_j<=d_D` costs `8Lambda d_D X`. In `D_rem`, v is future-deleted, **not terminal good**. The R277 raw good-event cover relies on `p_y w_g(v)<=KQ_x*(v)` and does not apply to this deleted slot. R223 `negative_contract.md:58–75` explicitly distinguishes D_rem from the still-unused continuous negative `N_del` and from actual deletion jumps.

## 3. Relation to the R277/R288 slot

R223 `negative_contract.md:44–75`, R227 `signed_budget.md:7–46`, and R128 RT1–RT3 establish that the later ongoing research treats the original high **continuous** `terminal-good x terminal-bad` positive part, while earlier paid subdomains are removed through a `[0,1]` positive allocation. Its `P_cur` contains the one outside `2Lambda`.

Consequently if the later positive allocations have known prices `A_post W+alpha_post X`, and their exact cover leaves the full R277 near traffic, the legally reintegrated form would be

`R_out <= [A_pre+C_G sqrt(n)+A_post]W`

`         +(alpha_down+alpha_post)X + U_prefix + P_cur`

`         -2Lambda N_Zc-2Lambda N_del`.                            (B4)

The coefficient of **P_cur is 1**, since it includes `2Lambda`. This coefficient is settled at the downstream normalization. The coefficient from an **original X bound** is not settled merely by B4.

B4 requires an explicit cover and sum of post-stage prices; this audit did not rederive all R126–R288 allocations, and does not certify them by author summaries. Even if that cover and R288's complete conditional `P_cur<=B288 W` are accepted, `U_prefix` remains and cannot be dropped. R288's theorem was not assumed to price low pe, initial atoms, deletion atoms, or future-deleted positive terms.

This is consistent with the much later independent R227 `signed_budget.md:119–123`: its K audit could not locate a complete newer global consolidation paying these older slots; it expressly does not declare them closed from progress on the high continuous term. R223 NC2's table at line65 still positively identifies these as separate old slots.

## 4. Receiver coefficient and K: what can be resolved without a new theorem

The old downstream absorption arithmetic is not intrinsically an obstruction: independent fixed error parameters can be made small. As a transparent illustration only, set

`epsilon=delta=epsilon_LP=1/(128Lambda)` and

`epsilon_near=epsilon_FA=epsilon_IJ=epsilon_D=epsilon_G=1/640`.

Then `alpha_down=43/768+Lambda k0 kappa_n`. If the actual original top-k choice satisfies `Lambda k0 kappa_n<=1/128`, this is at most `49/768<1`. Actual Python Fraction execution verified `43/768` and `49/768`. This does not count any original X-to-R_out coefficient, post-stage receiver price, or payment of U_prefix. It is therefore not a global absorption certificate. I did not invent a different top-k choice to assert that condition.

The new K issue can be narrowed: R116 introduces K as a free test threshold, and R117 CL1 uses K=1 in a fully explicit original split. R227 `signed_budget.md:103–123` checks that the listed previously paid FA/IJ/capture/clock prices are K^0 after their exact parameter choices; it permits globally preselecting controlled K(n) while retaining all classifications. Thus this audit does **not** claim a hidden mandatory superpolynomial K. K must simply be selected once for the whole construction; increasing it enlarges low-pe A^c, so it cannot be adjusted only inside the terminal P_cur estimate. R277's sqrt(K) remains explicit and is harmless for fixed K; R279/R288 conditional thresholds must use that same choice.

## 5. The original X entrance remains an independent missing bridge

The canonical local `Math-Research/centered-cube-upper-bound/current_joint_budget_20261007.md:74–89` starts from the imported interface

`X<=2 B_paid+(4096/49)R_heavy`,

then derives a valid conditional absorbed ledger. However `Math-Research/centered-cube-upper-bound/阶段研究与数值检验笔记.tex.txt:17–25` explicitly says that this interface was supplied in a new prompt and that the complete three upstream source documents had not been located; it does not independently certify their constants or paid branches. The MD's own opening calls it a conditional interface. I did not treat that prose as a proof of the entrance inequality.

Moreover R104 `hard_bridge.md` and `proof.md:817–842` explicitly choose **R_out**, not a possibly easier edge alternative, as their start. No direct identity `R_out=R_heavy` or `R_angle=R_out` was located in these bounded original sources; names cannot supply it. The cited full WeChat master file from R104's private location no longer exists at that path. The locally available earlier general reduction retains independent full-event spatial remainders and cannot be identified with the later current near slot for free.

Thus the strongest justified conclusion is B3, together with the exact high-continuous normalization in B4 conditional on its intervening positive allocation ledger. A proved original entrance `X<=A_ent W+alpha_ent X+C_ent R_out`, and root-order payment (or explicit later paid evidence) of U_prefix are needed before the requested final formula can be written with P_cur alone.

## Bounded stopping conclusion

The new theorem can close the current continuous positive near traffic and still leave an incomplete general proof. The minimum concrete outstanding object found here is

`U_prefix=Lambda integral_(p_y e_g<2Kq) dT`

`          +2Lambda(I_low-test + J_deletion-atom-low-test + D_large-dissipation)`.

This is a sum of original nonnegative traffic integrals with different domains and, for jumps, different time measures. They are not a second copy of P_cur and are not canceled by unused negative credits. A follow-on bridge should either exhibit their actual later payments with exact original references and summed errors, or state them as additional precise remaining targets. No closed status is inferred.
