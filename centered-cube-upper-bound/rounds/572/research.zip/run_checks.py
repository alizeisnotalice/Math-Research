"""Replay only the two bounded certificates; no optimization or PDF compilation."""
from pathlib import Path
import subprocess, sys, os, json, tempfile, hashlib

root = Path(__file__).resolve().parent
env = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
checks = []
with tempfile.TemporaryDirectory(prefix='ccu_r572_replay_') as work:
    for name, keys in [
        ('continuous_probe', ['status','source','centers','parameters','symbolic','rows']),
        ('ball_cube_certificate', ['status','dimension_list','exact_dimensions','rows','exact_moment_checks']),
    ]:
        script = root/'numeric'/f'{name}.py'
        output = Path(work)/f'{name}.json'
        cmd = [sys.executable, str(script), str(output)]
        subprocess.run(cmd, env=env, check=True, capture_output=True, text=True)
        actual = json.loads(output.read_text())
        expected = json.loads((root/'numeric'/f'{name}_baseline.json').read_text())
        for key in keys:
            if actual[key] != expected[key]:
                raise AssertionError(f'{name}: {key} differs; inspect version/rounding or mathematics')
        checks.append({'name':name,'command':cmd,'math_fields_identical':keys,
                       'python':actual['python_version'],'sympy':actual['sympy_version'],
                       'python_flint':actual['python_flint_version'],
                       'runtime_seconds':actual['runtime_seconds'],
                       'peak_rss_bytes':actual['peak_rss_bytes'],
                       'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest()})
result = {'status':'PASS','scope':'Two fixed certificates only; not a general upper-bound proof',
          'interpreter':sys.executable,'checks':checks,'pdf_compiled':False}
dest = Path(sys.argv[1]) if len(sys.argv)>1 else root/'VERIFICATION_reproduced.json'
dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
