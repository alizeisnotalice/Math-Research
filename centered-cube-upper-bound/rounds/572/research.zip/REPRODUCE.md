# 第572轮复现

一般弱型根阶上界尚未证明。REPORT.tex 是最终数学文本；audits/ 保留独审。
proofs/ 仅保留主报告缩写的来源包络和局部质量熵推导，不把失败付款计为改善。

在解压目录运行：

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python run_checks.py
```

实际环境 Python 3.12.14、SymPy 1.14.0、python-flint 0.9.0，Arb 192位。
需要这些库；本轮没有安装、升级或覆盖环境，没有运行 MATLAB，不编译 PDF。
两项脚本单进程顺序执行；不含随机抽样、优化器或历史敏感网格。
默认输出 VERIFICATION_reproduced.json；也可传第一个命令行参数指定输出文件。

1. continuous_probe.py：4个真实一维 Lebesgue 中心积分实例，整盒资格为有理端点证书，
   SymPy 对时间窗直接积分与双中心 Gram 重建一致，Phi 用 Arb 根式包围。
   只是实现自检，不证明一般能量预算。
2. ball_cube_certificate.py：固定 n 列表的几何闭式 Arb 包围，及 n=2,4,6,8 的有理多项式矩。
   它不独立证明球形异常集合定理；解析证明和独审在 REPORT.tex 与 audits/。

numeric/*_baseline.json 是原始执行记录；命令字段指当时仓库外脚本。
可移植脚本仅修改输出路径/运行命令元数据，不改数学；run_checks.py 另记录实际解释器、命令、版本和脚本 SHA。
自动比较数学字段；运行时间、临时目录和进程内存不应与基线逐字相同。
若库版本使区间显示发生变化，比较失败应人工核查，不能直接把失败改成通过。
Arb 输出误差是各自球半径，巨大数值的绝对误差不与小量统一；一维 Phi 的 4.30e-51
只适用于该4例，不是所有证书的绝对误差。

VERIFICATION.json 是打包前实际运行的两组复核；MANIFEST.json 记录包内成员哈希。
旧第571轮研究包只通过提交号及 REPORT SHA 引用，不再复制。未归档作者草稿的必要结论
已合并进 REPORT.tex，原始检查点哈希见 SOURCES.json。没有进行全历史优先性宣称。
