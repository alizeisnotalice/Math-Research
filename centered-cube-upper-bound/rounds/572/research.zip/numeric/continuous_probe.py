"""One CPU, four preregistered n=1 Lebesgue-center geometries; no sampling."""
import json, resource, time, sys, platform
import sympy, flint
from fractions import Fraction as F
from pathlib import Path
import sympy as S
from flint import arb, ctx
start=time.perf_counter()
ctx.prec=192
out=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('continuous_probe_reproduced.json')
t,y,sigma=S.symbols('t y sigma', positive=True)
delta=S.symbols('delta',nonnegative=True)
a,b=S.Rational(0),S.Rational(1,10)
c,d=S.Rational(9,10),S.Rational(1)
r1,r2=S.Rational(1),S.Rational(6,5)
v2=S.Rational(1,10)
# Primitive signed-volume integrals, without substituting center point samples.
B,C=S.symbols('B C')
u1=S.integrate(1/r1,(B,0,t))
u2=S.integrate(1/r2,(C,S.Rational(9,20),S.Rational(11,20)))
overlap=1-delta
# Exact original windows [0,1], [delta,delta+1], delta in {1/2,1}.
HA=S.integrate(u1**2,(sigma,0,delta))+S.integrate((u1+u2)**2,(sigma,delta,1))+S.integrate(u2**2,(sigma,1,1+delta))
HB=S.integrate(u2**2,(sigma,delta,1+delta))
Q=S.integrate(10*HA,(y,a,b))+S.integrate(10*HB,(y,c,d))
Phi=S.integrate(10*S.sqrt(HA),(y,a,b))+S.integrate(10*S.sqrt(HB),(y,c,d))
Qgram=S.integrate(S.integrate(1,(C,0,t)),(B,0,t))+2*S.integrate(S.integrate(1/r2**2,(C,S.Rational(9,20),S.Rational(11,20))),(B,S.Rational(9,20),S.Rational(11,20)))+2*overlap*S.integrate(S.integrate(1/r2,(C,S.Rational(9,20),S.Rational(11,20))),(B,0,t))
assert S.simplify(Q-Qgram)==0
assert S.simplify(HA-(t*t+(1-delta)*t/6+S.Rational(1,144)))==0

def box_captures(E,R,source):
    # Every x in E has source wholly inside its centered interval.
    return E[1]-R/2<=source[0] and E[0]+R/2>=source[1]
def box_disjoint(E,R,source):
    return E[1]+R/2<source[0] or E[0]-R/2>source[1]
def ballrat(q):
    q=F(q)
    return arb(q.numerator)/arb(q.denominator)
rows=[]
for gamma,tv in [(g,v) for g in [2,4] for v in [F(1,10),F(3,10)]]:
    dv=S.simplify(S.log(2)/S.log(gamma))
    E1=(F(0),tv);E2=(F(9,20),F(11,20));A=(F(0),F(1,10));Z=(F(9,10),F(1))
    checks={'E_disjoint':E1[1]<E2[0], 'E1_captures_A':box_captures(E1,F(1),A),'E1_excludes_Z':box_disjoint(E1,F(1),Z),'E2_captures_A':box_captures(E2,F(6,5),A),'E2_captures_Z':box_captures(E2,F(6,5),Z),'radii_band':all(F(1)<=r<=F(2) for r in [F(1),F(6,5)]),'q_band':all(F(1)<=q<=F(2) for q in [F(1),F(5,3)]),'source_cell_margin': all(F(-4)<=x<=F(4) for x in E1+E2)}
    assert all(checks.values())
    subst={t:S.Rational(tv.numerator,tv.denominator),delta:dv}
    ha=F(HA.subs(subst));hb=F(HB.subs(subst));q=F(Q.subs(subst))
    ph=ballrat(ha).sqrt()+ballrat(hb).sqrt()
    # Rigorous endpoint decimal displays come from Arb's ball, no float claims.
    rows.append({'gamma':gamma,'time_shift':str(dv),'triangle_overlap':str(1-dv),'t':str(tv),'checks':checks,'W':'2','m':['1','2'],'q':['1','5/3'],'H_A':str(ha),'H_Z':str(hb),'Q0':str(q),'Q0_over_W':str(q/2),'Phi_exact':str(S.simplify(Phi.subs(subst))),'Phi_Arb':ph.str(50),'Phi_over_W_Arb':(ph/2).str(50),'Phi2_over_WQ0_Arb':(ph**2/ballrat(2*q)).str(50),'ordered_shared_center_pairs_volume':str(2*tv*F(1,10)),'shared_source_mass':'1','cross_term_Q0':str(F(1-dv)*tv/6),'self_E1':str(tv**2),'self_E2':'1/72'})
result={'status':'PASS_EXACT_LEBESGUE_CENTER_AND_ARB','scope':'two prescribed geometries x two gamma, n=1 only; no dimensional inference','source':'f=10*1_[0,1/10]+10*1_[9/10,1]','centers':'E1=[0,t], R1=1; E2=[9/20,11/20], R2=6/5','parameters':{'a':'1','lambda':'2','G':'2','eta':'1/2','b':'8','fixed_source_cell':'[-8,8]'},'old_windows':['[0,1]','[delta,delta+1]'],'symbolic':{'H_A':str(S.expand(HA)),'H_Z':str(HB),'Q0':str(S.expand(Q)),'Phi':str(Phi),'independent_Gram_check':True},'rows':rows,'interpreter':sys.executable,'python_version':platform.python_version(),'sympy_version':sympy.__version__,'python_flint_version':flint.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+sys.executable+' '+str(Path(__file__).resolve())+(' '+sys.argv[1] if len(sys.argv)>1 else ''),'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'Arb_precision_bits':ctx.prec,'limits':'one process, no BLAS or parallel jobs, no optimization'}
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
