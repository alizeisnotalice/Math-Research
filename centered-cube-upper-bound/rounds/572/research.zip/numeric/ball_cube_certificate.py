"""Fixed closed-form certificate only; one process, no sampling/optimization."""
import sys,platform,json,time,resource,math
from fractions import Fraction as F
from pathlib import Path
import sympy as S
import flint
from flint import arb,ctx
ctx.prec=192
start=time.perf_counter()
ns=[2,4,8,16,32,64,128,256,512]
rows=[]
for n in ns:
    omega=arb.pi()**(n//2)/arb(n//2).gamma()/(n//2) # gamma(n/2+1)
    # Independent recurrence-equivalent gamma form checked by ball intersection.
    omega2=arb.pi()**(n//2)/arb(n//2+1).gamma()
    assert (omega-omega2).contains(0)
    j=2*omega*(arb(n)/12)**(n//2)
    fee=(j-2)/4
    rows.append({'n':n,'omega_n':omega.str(50),'Jn':j.str(50),'Jn_minus_2_over_4':fee.str(50),'Jn_gt_2_certified':bool(j>2),'fee_positive_certified':bool(fee>0)})
exact=[]
for n in [2,4,6,8]:
    k=n//2
    xs=S.symbols('u0:'+str(n))
    polynomial=S.Poly(S.expand(sum(x*x for x in xs)**k),*xs)
    # Exact expectation integrates each monomial over [-1,1]^n / 2^n.
    # Rational arithmetic and a separate SymPy univariate definite integral agree.
    expectation=F(0)
    for powers,coeff in polynomial.terms():
        term=F(int(coeff))
        for power in powers:
            assert power%2==0
            one=F(1,power+1)
            integ=S.integrate(xs[0]**power,(xs[0],-1,1))/2
            assert integ==S.Rational(one.numerator,one.denominator)
            term*=one
        expectation+=term
    mean_power=F(n,3)**k
    assert expectation>=mean_power
    omega=arb.pi()**k/arb(k+1).gamma()
    exact_ratio=2*omega*arb(expectation.numerator)/expectation.denominator/(2**n)
    j=2*omega*(arb(n)/12)**k
    if expectation==mean_power:
        assert (exact_ratio-j).contains(0)
    else:
        assert exact_ratio>j
    exact.append({'n':n,'monomials':len(polynomial.terms()),'E_sum_U_squared_power_exact':str(expectation),'Jensen_mean_power_exact':str(mean_power),'exact_Jensen_gap':str(expectation-mean_power),'Jensen_direction':'E X^k >= (E X)^k','exact_I_over_kappa_m_Arb':exact_ratio.str(50),'Jn_Arb':j.str(50),'ratio_exact_over_Jn_rational':str(expectation/mean_power),'lower_bound_verified':True})
result={'status':'PASS_FIXED_FORMULA_ARB_AND_EXACT_MOMENTS','precision_bits':192,'dimension_list':ns,'exact_dimensions':[2,4,6,8],'rows':rows,'exact_moment_checks':exact,'formula':'omega_n=pi^(n/2)/Gamma(n/2+1); Jn=2*omega_n*(n/12)^(n/2); exact I/(kappa*m)=2*omega_n*2^(-n)*E(sum U_i^2)^(n/2)','scope':'Numerical supplement restricting ball exceptional-set full-scale cube L2 transfer; not a general weak-type bound. Proof and normalization supplied by root/Astra.','interpreter':sys.executable,'python_version':platform.python_version(),'sympy_version':S.__version__,'python_flint_version':flint.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+sys.executable+' '+str(Path(__file__).resolve())+(' '+sys.argv[1] if len(sys.argv)>1 else ''),'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'method':'Arb192 balls with 50-digit radius displays; exact Fraction polynomial moments with SymPy monomial integration; no center sampling','processes':1}
Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).with_name('ball_cube_certificate_reproduced.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
