# R572：共同来源先积分的一条完整、但维数不足的付款

状态：未解决一般目标。独立起步，只读冻结合同及 R571 REPORT §§2–3、7；未读 Astra 新稿，未改变 repo 或他人文件，未 spawn，未作数值实验。以下只有一条机制：真实中心包络 → Tonelli → 同一来源一次分配。末尾响应 root 的 Φ/Ψ steering，不重证其新母式。

## 1. 精确阈值窗给出的完整包络

记

\[
C_{\rm ex}=1+\ln(2G\gamma),\qquad A_{\rm graph}=1+n\ln2+\ln G.
\]

对任意合同允许的共享概率 \(p_{Bj}\)，包括所有真实 bulk 中心及所有源格，有

\[
\boxed{B_\pi\le C_{\rm ex}A_{\rm graph}W.}\tag{A}
\]

这不使用 bulk score，所以也对 bulk 成立。它保留全部 O–N、不同父和不同坐标交叉；不是逐层领取 W。相对 R571 的一般残余窗包络，精确阈值窗只允许将常数中 \(\gamma^{1+h}\) 改成 \(\gamma\)。这只是已知中心包络机制的精确化，不是维数突破。

证明：在固定 \((i,j,y,\sigma)\) 上，非零项的旧质量 \(m_B\) 落在比值为 \(\gamma\) 的区间 \([M,\gamma M]\)。因 \(q_B\in[\lambda/2,\lambda]\)，实际动作边长 \(P_{Bj}=g_{Bj}^{1/n}R_B\) 满足

\[
(M/\lambda)^{1/n}\le P_{Bj}\le(2G\gamma M/\lambda)^{1/n}.
\]

原窗或按 j 平移回去的窗均有这一性质。真实 Lebesgue 中心的径向包络是

\[
\int_{\mathbb R^n}\sup_{r\in[u,v]}r^{-n}{\bf1}_{Q(B,r)}(y)\,dB
=1+n\ln(v/u).
\tag{B}
\]

内立方体贡献 1，外层用 \(d(r^n)r^{-n}\) 积分。因为单项 \(p_{Bj}\le1\)，(B) 给完整非负场 \(A_{ij}(y,\sigma)\le C_{\rm ex}\)。故

\[
\sum_{ij}\int A_{ij}^2\,d\mu_i d\sigma
\le C_{\rm ex}\sum_{ij}\int A_{ij}\,d\mu_i d\sigma
=C_{\rm ex}\int_{\rm bulk}q_B\sum_j\Gamma_jp_{Bj}/g_{Bj}\,dB.
\tag{C}
\]

最后一个等式用真实 \(\mu Q_B(g_{Bj})=m_B\Gamma_j\) 以及长度恰为 1 的窗；未丢任何交叉。

再交换一次真实来源积分。对 \(y\) 位于第 i 源格，定义

\[
w_i(y)=\int_{E_i^{\rm bulk}}\sum_jp_{Bj}P_{Bj}^{-n}{\bf1}_{Q(B,P_{Bj})}(y)\,dB.
\]

所有 \(P_{Bj}\in[a,2aG^{1/n}]\)，且每个 B 先合 \(\sum_jp_{Bj}=1\)，所以

\[
w_i(y)\le\int\sup_{P\in[a,2aG^{1/n}]}P^{-n}{\bf1}_{Q(B,P)}(y)\,dB
=A_{\rm graph}.
\]

因此 (C) 的末积分恰为 \(\sum_i\int w_i\,d\mu_i\le A_{\rm graph}W\)，证明 (A)。概率决策可以依赖全输入；证明没有在来源抽取后改变它，也没有假设来源坐标独立。

## 2. 对冻结 Q0 母式的真实作用

形式上 (A) 是 \(a=0,L=C_{\rm ex}A_{\rm graph}\) 的完整付款，故确有 \(G^2Ja=0<1\)。但它不满足目标所需的剩余常数规模。合同母式及一次 Young 给

\[
Q_0\le\bigl[2c+G^2J C_{\rm ex}A_{\rm graph}\bigr]W.
\]

令 \(D_{\rm old}=1+(n+1)\ln2/\ln\gamma\)。无论如何选择 \(\gamma>1\)，

\[
D_{\rm old}C_{\rm ex}\ge(n+1)\ln2,\qquad A_{\rm graph}\ge1+n\ln2.
\]

因此由该付款代入 R571 一般输入总账，所得估计常数中的 \(\sqrt{D_{\rm old}G^2J C_{\rm ex}A_{\rm graph}}\) 至少为常数乘 n；它不能提供所需的 \(\sqrt n\,\mathrm{polylog}(n)\) 上界。这是在评价该证书给出的上界，不是实际最优常数的下界。

本机指定 Python/SymPy 实际核查了 \(D_{\rm old}C_{\rm ex}-(n+1)\ln2\) 的展开；令 \(l=\ln\gamma>0,g=\ln G>0\)，输出全为正项。这只是上述代数检查，无数值证据或新实验。

## 3. 唯一明确障碍：来源已一次分配，容量仍为 n

这个积分次序确实给共同来源的一次分配：以 \(w_i(y)/A_{\rm graph}\) 为领取比例，总比例至多 1。因此不存在逐旧质量层/逐相位重复领取 W 的缺口；真正未改进的是总真实中心容量 \(A_{\rm graph}\)。

冻结 bulk 条件没有直接提供更小的逐来源容量。\(e_B=\langle L_i,k_B\rangle=C_0q_B\alpha_B\) 只控制旧来源上的平均旧场；它不给每个旧质量层一份两两不交的新来源，也不使不同中心的旧盒在固定 y 周围成为嵌套族。不能从 \(\mu Q_B=m_B\) 和相隔质量层自动推出可累加的来源质量增量。把上述 \(w_i\) 按层拆开再各估计，只会回到被禁止的逐层 W；按总和归一化则准确回到 (A)，不产生增益。

所需的新信息必须真正降低 \(\int w_i\,d\mu_i\) 或控制完整平方场对高容量来源的集中。当前这一条机制没有证明这种信息，不能把它重命名为一个待付 carrier 后宣称已付款。

## 4. 对 root 新 Φ/Ψ 接口的有限检查

沿用同一来源函数 \(w_i\)，从 (C) 的逐来源版本直接有

\[
H_i(y):=\sum_j\int A_{ij}(y,\sigma)^2d\sigma\le C_{\rm ex}w_i(y).
\]

故对 root 指定的完整来源范数

\[
\Psi_\pi=\sum_i\int\sqrt{H_i(y)}\,d\mu_i(y)
\le\sqrt{C_{\rm ex}A_{\rm graph}}\,W.
\tag{D}
\]

代入 root 给出的 \(\Phi\le(1+G)W+G\sqrt J\,\Psi_\pi\) 和 \(X\le\sqrt{D_{\rm old}}\Phi\)，仍含同一 \(\sqrt{D_{\rm old}C_{\rm ex}A_{\rm graph}}\) 线性 n 级费用。因此该新接口没有使本机制得到 polylog 来源预算。不将 \(\mu/S\) 视为新来源，也未套用原来源质量曲线的 head/core 估计。

结论：本轮这条互补机制已完整支付 (A)/(D)，但只到线性 n 级一般估计；未付目标所需的维数改进。按任务边界停止，待命。
