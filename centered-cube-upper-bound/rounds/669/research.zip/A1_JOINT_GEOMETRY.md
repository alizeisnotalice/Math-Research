# R669 A1 — joint source reuse: exact merging and the remaining within-scale budget

## Status

No absolute V_near≤CU bound, and no uniformly absorbable E|T(1)|≤eta V_near+CU estimate, is proved here. The bounded task establishes the exact accounting constraints for two concrete attempts: residual-capacity allocation and common-pool geometric merging. It also isolates a finite cross-scale factor: the arbitrary total number of scales is not the remaining obstacle, because each source can enter at most ceil(log2 n)+2 near-scale buckets. The unproved step is a jointly payable covering by qualified common pools within each bucket.

These are conditional accounts and precise stopping points, not a new global AU payment. No Hall reduction or local-intersection proof is repeated. All original sources, q_i, I_h, witnesses, true disjoint F_i and X_h, original L_h, full shared Poisson histories and future-repeat masks remain unchanged. The deterministic arguments below bypass random coverage without altering any of its pools.

## 1. Correct index convention and actual directional information

The full saturation prefix allows i≤h. Thus I_h may contain h. Set

    a=32n, c0=1+1/a, tau=16384 sqrt(n),
    D_h=(2s_h)^n, d_i=(2s_i)^n, b_i=|F_i|=q_i d_i.

The actual demand satisfies

    |X_h|≤|B_h|=D_h/a^n.                                   (1.1)

The source geometry gives s_h≤s_i<ns_h for i∈I_h. In particular d_i≥D_h, including the possible self source i=h.

Original center admission controls only strictly earlier labels. With

    chi_ih=1{y_h∈Q(y_i,c0s_i)},

its valid consequence on the complete pool is

    Σ_{i∈I_h}q_i chi_ih≤1+q_h,
    Σ_{i∈I_h:chi_ih=0}q_i≥T_h−1−q_h.                     (1.2)

Moreover chi_ih=0 implies A_i∩B_h is empty. Indeed, for x∈B_h,

    ||x−y_i||∞ > c0s_i−s_h/a
                    =s_i+(s_i−s_h)/a ≥s_i.

Thus most of the high pool load corresponds to whole-parent separation from the actual receiver box, not just to pointwise non-membership at one x. A source-to-source capture chain restricted to chi=1 acts on the small complementary load; it does not directly pay this separated main part.

Likewise the safe receiver inequality is

    Σ_{i∈I_h}q_i1_{A_i}(x)≤1+q_h,
    Σ_{i∈I_h}q_i1_{A_i^c}(x)≥T_h−1−q_h,
                         a.e. x∈X_h.                     (1.3)

For an ordered subfamily, the union of earlier target pools can include the current target label, so its corresponding bound is also 1+q_h. No label is removed to restore an incorrect bound of 1, and no Poisson process is changed.

## 2. Residual-capacity allocation uses the actual tiny receiver demand

Suppose a deterministic allocation procedure has remaining fractions rho_i∈[0,1] of each actual source capacity b_i. At target h, if

    Σ_{i∈I_h}rho_i q_i≥a^(−n),                             (2.1)

then

    Σ_{i∈I_h}rho_i b_i
      ≥D_h Σ_{i∈I_h}rho_i q_i
      ≥D_h/a^n≥|X_h|.                                    (2.2)

Therefore the current target can be paid from its incident remaining capacities. This criterion uses the real D_h/a^n demand and d_i≥D_h, rather than treating a target as an arbitrary unit demand. The own source h, if present, remains available exactly like any other incident source.

Conversely, if the actual remaining capacity is insufficient,

    Σ_{i∈I_h}rho_i b_i<|X_h|,

then

    Σ_{i∈I_h}rho_i q_i<|X_h|/D_h≤a^(−n),
    T_h^spent:=Σ_{i∈I_h}(1−rho_i)q_i>T_h−a^(−n).          (2.3)

Thus a failed row has almost all of its q-load supported by already used capacities. Measurable portions F_i^spent⊂F_i of volumes (1−rho_i)|F_i| can realize these spent amounts; their disjointness is inherited. This observation does not alter original q or sampling: it only represents spent capacity for a prospective geometric estimate.

There are two exact gaps in turning (2.3) into a global payment.

First, the frozen R662 local theorem requires T≥8192 sqrt(n)=tau/2, not merely T>tau/2−a^(−n). Although T_h>tau/2, there is no supplied uniform lower bound on T_h−tau/2. Therefore T_h^spent need not meet the theorem's threshold. Any local invocation on spent portions must check all of R662's hypotheses, including T_h^spent≥tau/2. The thin-margin branch cannot be discarded because a^(−n) is small. No constant-stability extension has been proved here.

Second, even in a threshold-qualified branch, a strong local estimate says only that this new receiver body is small compared with already used incident source capacity. That same spent capacity may be invoked by many later failed rows. No bound on the sum of these new debits follows without a column budget or a geometric merging rule. The q-load in (2.3) and the used mass Σ(1−rho_i)q_i d_i are different quantities; radii cannot be silently removed from one to obtain the other.

## 3. An exact common-pool geometric merging rule

Let C be a finite nonempty cluster of actual near targets, and put

    J_C=intersection_{h∈C} I_h,
    r_C=max_{h∈C}s_h,
    K_C=intersection_{i∈J_C}A_i,
    T_C=Σ_{i∈J_C}q_i,
    U_C=Σ_{i∈J_C}|F_i|.                                  (3.1)

Assume J_C is nonempty. Every actual witness z_h for h∈C belongs to K_C. The actual own-target geometry gives ||x−z_h||∞≤c0s_h for x∈X_h. Hence the whole cluster, irrespective of how many different populations it contains, satisfies

    union_{h∈C}X_h ⊂ K_C+c0r_C Q.                         (3.2)

This inclusion uses the common intersection of all the pools in C. A sum of pairwise-overlap estimates is not a substitute for J_C.

Every common source satisfies s_i≥r_C, because it belongs to the population of a target attaining r_C. It also satisfies s_i<nr_C, from that same target. A common point exists, namely any z_h in the cluster. Therefore, if all remaining hypotheses of the frozen R662 complete-population statement hold and in particular

    n≥256,       T_C≥8192 sqrt(n)=tau/2,                   (3.3)

its already proved full-intersection fee gives the conditional cluster payment

    |K_C+c0r_C Q|≤exp(−T_C/8) U_C.                        (3.4)

The local theorem and its limit in sample size are inherited, not re-proved. This note does not apply (3.4) to a tau/4 core or a core obtained by an unbudgeted load loss. In actual near dimensions excluded by the inherited construction there are no targets to merge.

In particular, a qualified common core really does merge distinct populations geometrically: it pays their entire receiver union once. The missing issue is not this inclusion; it is finding enough such cores while controlling repeated source capacities.

## 4. The exact global debit of a fractional merged cover

A finite collection of qualified clusters may be given nonnegative weights lambda_C. A sufficient receiver-covering condition is

    for a.e. x∈Y,
    Σ_C lambda_C 1_{union_{h∈C}X_h}(x)≥1.                 (4.1)

The stronger targetwise condition Σ_{C:h∈C}lambda_C≥1 also suffices, since the actual X_h are disjoint. With (3.2)–(3.4), the full joint charge is

    V_near
      ≤Σ_C lambda_C exp(−T_C/8) U_C
      =Σ_i |F_i| B_i,
    B_i:=Σ_{C:i∈J_C}lambda_C exp(−T_C/8).                 (4.2)

The right side counts each source's true capacity times its total fractional debit. It does not count clusters as if all lambda_C were one. A uniform bound B_i≤C is sufficient, but the weaker weighted bound Σ_i|F_i|B_i≤CU would already finish the task.

No collection meeting (4.1) and a payable (4.2) has been constructed here. The original single-target clusters provide coverage, but not a proved global bound on B_i. Conversely, arbitrary large merging can destroy J_C's load and violate (3.3).

Within one proposed cluster grown by adding targets h_1,h_2,…, the lost sets

    J_r=intersection_{j≤r}I_{h_j},
    D_r=J_{r−1} minus I_{h_r}

are disjoint as r varies. Thus both Σ_r q(D_r) and Σ_r|F_{D_r}| telescope within that cluster. This does not telescope across different clusters: a source removed from one common core can belong to the initial or final core of many others. Original center admission and the whole-box separation in (1.2) have not yet been converted into a bound on these returns. That is the exact missing joint-geometric implication, not a claimed impossibility of such an implication.

## 5. Arbitrary total scale range causes only a finite near-window factor

There is one valid summable constraint on this source reuse. Partition targets into dyadic radius buckets

    H_j={h:2^j≤s_h<2^(j+1)}.

If source i occurs in a target pool, the actual near-scale window gives

    s_i/n<s_h≤s_i.                                        (5.1)

Hence source i can occur in at most

    K_n=ceil(log2 n)+2                                    (5.2)

target buckets, irrespective of the full family's total scale range. This also bounds the number of buckets containing a cluster core J_C that includes i, provided each cluster is contained in one target bucket.

Suppose, conditionally, that in every bucket a nonnegative weighted cover of its true receivers by clusters satisfying (3.3) has been obtained, and suppose its within-bucket source-column weights obey

    for every i,j,
    Σ_{C⊂H_j:i∈J_C}lambda_C≤M_n.                          (5.3)

Then (4.2), with T_C≥tau/2, yields the exact full-family conditional fee

    V_near≤K_n M_n exp(−tau/16) U.                         (5.4)

Every dimension factor and the fractional column weight is retained. For example, even the bound M_n≤exp(tau/32) would suffice: for n≥256, K_n≤n and log n≤sqrt(n), so

    log(K_n M_n exp(−tau/16))
      ≤log K_n−tau/32
      ≤−511 sqrt(n)<0.                                   (5.5)

Thus unbounded global scale count need not be paid again. The remaining difficult construction is within a single radius bucket: cover actual receivers by threshold-qualified common cores with a payable source-column weight. Neither (5.3) nor such a fractional cover has been proved. Equations (5.4)–(5.5) are a conditional account, not a new AU theorem.

## 6. Actual bounded computation and exact stopping point

Before calculating, the decision was fixed: verify the dimensional coefficient in (5.4)–(5.5), especially the number of buckets and the tau/16 versus tau/32 exponent, without testing any abstract incidence model or assuming the unproved cover. The following local python3 code was actually run. It uses exact integer square roots and bucket counts; the displayed logarithms are floating-point diagnostics. The all-n bound is the analytic inequality above.

```python
from math import isqrt, log
print('Conditional cross-scale coefficient check; no within-bin cover assumed')
for n in [256,1024,65536,4294967296]:
    sqrt_n=isqrt(n)
    assert sqrt_n*sqrt_n==n
    ceil_log2_n=(n-1).bit_length()
    K=ceil_log2_n+2
    tau=16384*sqrt_n
    log_fee=log(K)-tau/32
    assert K<=n
    assert log_fee<=-511*sqrt_n
    print('n=%d buckets_bound=%d log_fee=%.12g upper_log_fee=%d' % (n,K,log_fee,-511*sqrt_n))
```

Actual output:

```text
Conditional cross-scale coefficient check; no within-bin cover assumed
n=256 buckets_bound=10 log_fee=-8189.69741491 upper_log_fee=-8176
n=1024 buckets_bound=12 log_fee=-16381.5150934 upper_log_fee=-16352
n=65536 buckets_bound=18 log_fee=-131069.109628 upper_log_fee=-130816
n=4294967296 buckets_bound=34 log_fee=-33554428.4736 upper_log_fee=-33488896
```

No MATLAB session was started. No abstract counterexample scan, Git operation, PDF compilation, or other agent's file edit was performed.

The bounded task stops with three explicit unresolved requirements: a residual-allocation failure still needs a global used-capacity debit; any spent or common core must retain the actual R662 load threshold; and qualified within-scale geometric clusters must have controlled fractional source-column weight. The arbitrary total number of scales is accounted for by (5.2), but that does not resolve the within-scale geometry. No new full receiver payment or strict terminal contraction is claimed.
