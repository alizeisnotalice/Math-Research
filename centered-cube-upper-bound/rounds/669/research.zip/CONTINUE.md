# R669 continuation

Original all-L1/all-scale pure sqrt(n) objective remains OPEN. R669 corrects R668; it does not prove a new AU fee.

Critical correction: R660 actual saturation pool I_h contains only indices <=h, not strictly <h. Positive self q_h may belong. Never delete self or change keys. Joint earlier-pool load on X_h is <=1+q_h; exterior rate >=T_h-1-q_h. Correct crude annulus denominator tau/2-1-a^(-n). R668 strict-index audit certification withdrawn in S1; global-mask S2 law, full receiver account, coarea/parent fee and R662 survive unchanged. Local exact correction factor<=262112/262111. Old commit preserved, explicit corrigendum in this round.

Actual admission source-captured chain costs <=U, but high-T demand predominantly uses noncaptured source edges; chi_ih=0 implies whole B_h disjoint A_i. Cannot replace terminal |F_h| by |X_h|, because q_h can vanish. Source-only chain identities do not pay receiving demand.

Astra's residual-capacity test pays a target if unused source-rate >=a^(-n). Failure makes used rate>T_h-a^(-n), but this may be below R662 threshold tau/2. Common-pool clusters cover their true receivers geometrically and receive local exponential fee only IF their remaining load meets the original threshold. Crosscluster source return has no proven column budget.

Near window supplies a real global scale bookkeeping fact: a source participates in <=ceil(log2 n)+2 dyadic target buckets, independent of total scale span. IF each bucket has a true fractional common-core cover with coreload>=tau/2 and per-source weighted cluster count M_n<=exp(tau/32), the inherited exponential fee would give absolute total cost. That within-bucket spatial cover, including load threshold, is UNPROVED. Do not turn this conditional account into progress on AU or repeat generic Hall reformulation.

Next meaningful work: construct/quantitatively bound actual within-bucket shared-source geometry, or pay the complete receiver union by a more flexible mechanism retaining admission. Do not re-prove local R662, resample independent target histories, or make abstract counterexample scans. Only 1 Astra+3 Sol maximum, useful tasks not required full. Exact local math tools for decision/verification; close MATLAB promptly after use. Per truly finished round independent audit and compact archive/commit/push, no PDF.
