# R669 S2 — what actual center admission pays, and the source-to-receiver bridge it does not provide

**Result.** No new global payment for `Vnear` is proved. Actual center admission pays the source-to-source triangular interaction, including arbitrary increasing chains, with fee at most `U`. The decisive bridge fails at a precise geometric location: for every actual high-load receiver row, the center-captured part of its pool has mass at most `1+q_h`; the remaining mass, at least `T_h-1-q_h`, consists of sources whose original parent misses **all** of the receiver's small cube `B_h`. Those are the main edges of the exterior receiving demand. The paid triangular interaction controls their complement. The small individual receiver bound does not convert its receiving weight into source capacity, because that conversion would cost `a^(-n)/q_h`, with actual loss rows allowed to have `q_h=0`.

This bounded attempt stops at this missing bridge. It does not assert a pointwise square-root load bound, all-subsets Hall inequality, or abstract counterexample. No local regrouping or conditional race is proposed. Only this assigned file is written.

## 1. Frozen actual data and the source triangular form

Use the actual radius order, the true disjoint `F_i⊂B_i=Q(y_i,s_i/a)`, and

```
a=32n,  c0=1+1/a,
d_i=(2s_i)^n,  q_i=|F_i|/d_i≤a^(-n),
U=Σ_i |F_i|.
```

For `i<j` define the directed center-capture indicator

```
chi_ij = 1{y_j∈Q(y_i,c0s_i)}.
```

Actual admission states

```
Σ_{i<j} q_i chi_ij ≤ 1                                 (1)
```

for every actual row j. It is valid without replacing the family or source law. Therefore the true source interaction obeys

```
B_src := Σ_j |F_j| Σ_{i<j}q_i chi_ij ≤ U.                (2)
```

The same bound holds after restricting either endpoint to any chosen subset of positive source labels. This uses the terminal capacity `|F_j|`; there is no bound here with arbitrary receiver weights in its place.

There is also a pointwise geometric implication. If `x∈B_j∩A_i` and `i<j`, then radius ordering gives

```
||y_j-y_i||∞ ≤ s_i+s_j/a ≤ c0s_i,
```

so the pair is captured. Hence

```
Σ_{i<j}q_i 1_{A_i}(x) ≤ 1     for every x∈B_j,           (3)
Σ_{i<j}q_i |F_j∩A_i| ≤ |F_j|.
```

Thus (2) is consistent with, and is not an improvement over, the already available low-preceding-load consequence of admission. In particular (2) alone cannot be announced as a new source reuse payment.

## 2. Captured source chains remain paid, with no hidden multiplicity

For any integer `m≥1`, define the actual increasing-label chain sum

```
C_m = Σ_{i_0<...<i_m}
      |F_{i_m}| ∏_{r=0}^{m-1}[q_{i_r} chi_{i_r,i_{r+1}}]. (4)
```

Then

```
0≤C_m≤U.                                                (5)
```

Proof: sum `i_0` first for each fixed `i_1,...,i_m`. Equation (1) bounds that innermost sum by one. The remaining expression is bounded in precisely the same way for `i_1`, and so on. The final sum is `Σ_{i_m}|F_{i_m}|=U`. Every chain is increasing, and every product uses the actual `q`; the proof does not introduce independent pair samples or different target laws. Any nonnegative mixture with coefficients `alpha_m` and `Σ_m alpha_m<∞` therefore costs at most `(Σ_m alpha_m)U`.

This proves the possible multi-source budget honestly. It changes the global fee **only if** the demanded receiver transfer is dominated by such captured chains with an absolutely summable total coefficient. No such domination has been established. Section 3 shows why it cannot simply be read off the actual pool incidence.

## 3. The dominant actual receiver incidence is outside the paid edge set

Fix an actual near-loss row h. Its source pool only guarantees `i≤h`, not `i<h`. Write

```
T_h=Σ_{i∈I_h}q_i>tau/2.
```

Define its center-captured source mass, including the possible self source,

```
J_h = {i∈I_h : i<h and chi_ih=1} ∪ (I_h∩{h}),
A_h^cap = Σ_{i∈J_h}q_i.
```

The actual center-admission inequality, followed by the self correction, gives

```
A_h^cap ≤ 1+q_h ≤ 1+a^(-n).                              (6)
```

Consequently the complementary mass satisfies

```
Σ_{i∈I_h\J_h}q_i
  ≥ T_h-1-q_h
  > tau/2-1-q_h.                                        (7)
```

The receivers and sources in (7) have a stronger separation than a missing center indicator. For each such i, `i<h` and `chi_ih=0`, so

```
||y_h-y_i||∞ > c0s_i = s_i+s_i/a.
```

For every `x∈B_h`, radius ordering gives

```
||x-y_i||∞ ≥ ||y_h-y_i||∞-s_h/a
          > s_i+(s_i-s_h)/a
          ≥ s_i.
```

Therefore

```
B_h∩A_i=∅,   and in particular X_h⊂A_i^c.                (8)
```

This is a rigorous implication for the real finite input, not a proposed construction. The common saturation witness still ensures that these sources have expanded coverage of `X_h` at the actual target scale. Thus they belong to the genuine exterior receiving demand while lying outside the paid center-capture edges.

The fraction of each actual pool accounted for by the directly paid captured relation is at most

```
A_h^cap/T_h ≤ 2(1+a^(-n))/tau.                           (9)
```

Most pool mass is on the other relation. The argument is uniform in the number of sources and scales and makes no claim about a large `Vnear/U` example.

For clarity, the analogous *source-to-source* pool calculation has the same direction. For a fixed real pool `I_h`, let

```
E_h^cap = Σ_{i<j, i,j∈I_h}q_i q_j chi_ij.
```

Admission gives `E_h^cap≤T_h`, whereas the total distinct unordered pair mass is `(T_h²-Σ_{i∈I_h}q_i²)/2`. The noncaptured pair mass is therefore at least

```
T_h²/2 - (1+a^(-n)/2)T_h.                               (10)
```

So a high-load common-witness pool cannot be priced merely by assuming its pairs mostly lie on the controlled triangular relation. Formula (10) is a mass comparison; it is not a receiving-volume estimate and is not counted as a new global improvement.

## 4. The tiny single-row receiver volume does not remove the measure mismatch

The actual demand does satisfy

```
|X_h|≤|B_h|=a^(-n)d_h.                                   (11)
```

For a positive source row h, comparison with its source capacity gives only

```
|X_h|≤[a^(-n)/q_h] |F_h|.                                (12)
```

The factor in brackets has no dimension- and input-independent upper bound. More decisively, a true residual-loss row can have `q_h=0`; then `F_h` has zero capacity while `X_h` may have positive demand. Equation (11) is still true, but no finite coefficient turns it into a bound by `|F_h|`.

This is the exact failure in substituting `|X_j|` for the terminal source weight in (2) or (4). The valid formal estimate after that substitution would merely be

```
Σ_h |X_h| Σ_{i<h}q_i chi_ih ≤ Vnear,                     (13)
```

and using (11) yields at best an expression involving `a^(-n)Σ_h d_h`, not `U`. Neither expression closes the budget. No domination of that latter sum by `U` is supplied by source admission.

Disjoint receiver pieces also do not, by themselves, repair this step. For a fixed incident source i, their union is contained in the expanded source cube supplied by the witness and scale comparison; this is exactly the annulus envelope already exposed in R668. Bounding that union by all available annulus volume discards its relation to the other actual source pools and recovers the existing exponential coefficient. Tiny individual pieces do not reduce a sum of their disjoint volumes without an additional geometric restriction on the positions or number of those pieces.

## 5. Exact unpaid bridge and stopping decision

The promising part of the attempted bridge was real: actual admission gives an absolute budget for arbitrarily long chains of center-captured **sources**, via (5). The attempted transfer from these chains to the real receiver demand is not justified. There are two separate obstructions:

1. The terminal measure in (5) is true source capacity. Its replacement by demand has the unbounded fee (12), including zero-capacity loss rows.
2. The dominant incident pool mass in (7) is supported where the direct center-capture relation is absent, with the genuine whole-small-cube exterior property (8). No captured-source chain has been shown to transport that exterior demand to a final positive-capacity owner at bounded total fee.

A proof of the missing transport domination might exploit further global geometry, but it does not follow from the triangular integral, the chain bound, the common-witness condition, or the row-size inequality as currently combined. I have not assumed it, nor reformulated it as an all-subsets Hall requirement. The R662 single-population exponential estimate remains valid; no new bound on repeated source charges across its different actual populations is obtained here.

There was no mathematical candidate requiring numerical optimization or enumeration after this bridge audit. Accordingly I did not request or launch a numerical job, consistent with the parent's centralized computation instruction. The exact inequalities above are proved directly; there is no numerical evidence being promoted to a proof. This bounded attempt ends here with the complete receiving quantity still unpaid.
