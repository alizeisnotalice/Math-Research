# R669：R668 source-pool 索引错误的独立定位与最小修正

**结论：R668 将 i≤h 误写/误审为 i<h，确有索引推导错误。** 原实际pool没有删去当前来源；若n>1且qₕ>0，则h∈Iₕ。正确joint低载为1+qₕᵣ，正确exterior-rate下界为Tₕ−1−qₕ；canonical exterior allocation不变，只需把其已知粗容量系数的分母修正。全mask计数、原receiver恢复和已付fees不受影响。

本文件只按授权回读R660/R662/R665原定义及R668对应断言。不改任何旧已提交报告，不删自身来源，不spawn/Git/PDF/MATLAB。R668中本代理此前给出“all labels precede h_r”和“T_out≥T_h−1”的PASS依赖错误索引，本文件明确撤回这两项及其未修正分母的认证；其余结论按下文逐项区分。

## 1. 原始定义逐段定位

### R660：完整饱和前缀包含当前j

文件 `/Volumes/data/CodexTemp/centered-cube-r660-20261115/REPORT.tex`：

- lines27–33：qⱼ=min{wⱼ,(τ−ℓⱼ)₊}，ℓⱼ=ess sup_{Aⱼ}Σ_{i<j}qᵢ1_Aᵢ，Xⱼ=Eⱼ\Fⱼ。
- lines64–79：“完整饱和前缀”命题明确Σᵢqᵢ1_Aᵢ(zⱼ)=τ，且正来源含zⱼ只保证i≤j。证明明写“包含当前行的完整前缀恰为τ”，未来正行才被排除。
- lines71–72：Iⱼ={i:qᵢ>0,zⱼ∈Aᵢ,sⱼ≤sᵢ<nsⱼ}，没有i<j条件，没有排除i=j。

SHA-256：`5395915b3b9a9969a30068d10f65f7193e16028709197d67d5167f55efc1d759`。

### R662：再次明确including current row，沿用同一个pool

文件 `/Volumes/data/CodexTemp/centered-cube-r662-20261115/REPORT.tex`：

- lines70–72：“including the current row in the prefix”，complete load τ；只有future positive sources不含zⱼ。
- lines79–80：同一个Iⱼ定义及Tⱼ>τ/2，没有删除当前j。
- lines94–95：Lₕ仍是{Σ_{i<h}qᵢ1_Aᵢ≤1}，这是严格前缀clip，不能据此把pool改成严格前缀。

SHA-256：`0a5e929166066e4c9e1c0cf3b0fad93fbc64b464522caf14e705631e159f2770`。

### R665：保留原pool，未引入删除self的改动

文件 `/Volumes/data/CodexTemp/centered-cube-r665-20261115/REPORT.tex`：

- lines65–72：near target沿用actual Iₕ、witness及τ/2<Tₕ≤τ；Lₕ继续只对i<h求和。
- lines101–102：明确“Keep q_i,I_h,z_h,s_h,L_h, all first-event lists and all source order unchanged.”

该轮没有把Iₕ定义为i<h，也没有删self或重新生成first-event list。SHA-256：`b4101a958a1df3f0a9b52a712d19a02519ba9a3295ee22186b98074c3ce31017`。

## 2. self来源确实不能当作已排除

对n>1、qₕ>0的near损失行，zₕ∈Aₕ且sₕ≤sₕ<nsₕ，所以原定义直接给h∈Iₕ。n=1的near分支为空，不构成删除self的理由。

损失条件qₕ<wₕ不推出qₕ=0：递推允许0<τ−ℓₕ<wₕ时的partial loss，此时qₕ=τ−ℓₕ>0、ℓₕ+qₕ=τ。原R660证明还专门将qⱼ=0描述为其包含的边界情况，没有将所有损失行限制为零q。现有合同及所读后轮没有排除positive-self情况。

本审查没有另造actual high-T输入；也不需要用抽象counterexample作索引判断。原定理给的就是i≤h，原pool在qₕ>0时明确包含h。因此任何使用i<h的证明必须补合法余项，不能无证增加qₕ=0假设。旧≤1或T_out≥Tₕ−1是否还能由别的额外几何成立，不是本文件证明的反例命题；本文件确认其R668给出的strict-index推导不成立。

## 3. 正确joint triangular低载

对ordered target subset H={h₁<⋯<h_m}，保持原

N_r=⋃_{j≤r}Iₕⱼ。

每个label只保证i≤h_r。N_r\{h_r}都严格早于h_r；在真实Xₕᵣ⊂Lₕᵣ上，正确可继承约束为

Σ_{i∈N_r\{h_r}}qᵢ1_Aᵢ(x) ≤ 1， a.e. x∈Xₕᵣ，

Σ_{i∈N_r}qᵢ1_Aᵢ(x) ≤ 1+qₕᵣ。

这里Xₕᵣ⊂Bₕᵣ⊂Aₕᵣ，所以当前term若存在确实是qₕᵣ；若qₕᵣ=0则自动退化回1。旧“all labels in N_r precede h_r”须改成“all labels are no later than h_r; separate the possible current label”。

对单个owner pool同理，x∈Xₕ时

Σ_{i∈Iₕ}qᵢ1_Aᵢ(x) ≤1+qₕ，

Tₕ^out(x):=Σ_{i∈Iₕ}qᵢ1_{Aᵢ^c}(x)
 =Tₕ−Σ_{i∈Iₕ}qᵢ1_Aᵢ(x)
 ≥Tₕ−1−qₕ
 >τ/2−1−qₕ。

self本来就不产生exterior incidence，因为Xₕ⊂Aₕ，所以若h∈Iₕ，则外部分配的zₕₕ=0。不能在Tₕ总负载中计算qₕ、同时在inside负载上把qₕ丢掉。

## 4. canonical exterior transfer不变，粗指数分母需修正

原定义仍合法：对i∈Iₕ，

zₕᵢ=∫_{Xₕ} qᵢ1_{Aᵢ^c}(x)/Tₕ^out(x) dx；

其他i取0。它仍满足Σᵢzₕᵢ=|Xₕ|。原q cap给qₕ≤ρₙ:=a^(−n)≤1/32，所以统一正分母可取

Dₙ=τ/2−1−ρₙ >0。

因此positive-capacity source的已知whole-annulus费用应改为

(Σₕzₕᵢ)/(qᵢdᵢ)
 ≤ [((1+c₀)ⁿ−1)/(τ/2−1−a^(−n))]。

也可用稍粗的τ/2−33/32作统一分母。精确source ratio中原Tₕ^out定义没有变化；变化的是此前错误声称的lower bound及由它推出的粗upper coefficient。qᵢ=0来源不转账，仍不作0/0。

此修正只把一个已经exponential、尚未闭合的粗系数稍微增大，不制造新维数损失，也不把它变成绝对source付款。若仅比较新旧书面系数，其放大因子最多

(τ/2−1)/(τ/2−1−ρₙ) ≤262112/262111。

这只是修正规模的统一上界，不认证旧系数本来有效，也不主张n=1实际near能够取到该界。

## 5. 受影响文件/断言与不受影响范围

需要在R669新账中明确修正而不改旧已提交文件：

- R668 A1_RECEIVER_BUDGET.md §3的“All labels in N_r precede h_r”、(3.3)≤1、(3.4)Tₕ^out≥Tₕ−1及其文字解释。
- 同文件(4.3)的τ/2−1分母及依赖它的exterior crude capacity解释。
- R668 REPORT.tex末节对应N_r不等式、because every source precedes h_r、Tₕ^out>τ/2−1和per-source annulus分母。
- 本代理R668 S1_RECEIVER_SCOPE.md §12对这些strict-prefix断言的PASS及由此§13–14作出的无保留认证，按上述精确范围撤回；本文件为独立纠正记录。

保持有效的结论：

1. 全子集Hall criterion对实际原Iₕ图仍是该网络的充分/等价条件；self source与target是bipartite不同侧的顶点，允许边h→source h不破坏finite flow theorem。网络criterion是否成立仍未证明。
2. exterior transfer的定义、每需求恰好分配、exact source ratio、disjoint receiver/annulus空间步骤仍正确，仅统一分母修正。非exterior qᵢ/Tₕ transfer的2(1+c₀)ⁿ/τ粗界也未用i<h，保持不变。
3. R668 S2全mask计数律、Iₕ⊂D_x、μ>14τ/5、Chernoff、repeat fee及rescue方向不依赖所有i<h，因此不改。特别若qₕ>0，则对本owner receiver x∈Bₕ有x∈Aₕ′，所以h∈C_x；其count被global void条件强制为0，S2的Iₕ\C_x公式已经精确处理，不漏self。
4. measurable-Y coarea、E|T|=P_Y+C_Y、C_Y≤16U/31、完整marked/repeat fee、receiver completion恢复及其条件常数不使用错误strict pool索引，保持有效。原Iₕ、rates、first-k lists和Tₕ>τ/2都完全保留。
5. R662共点交集定理、完整K_I covering Xₕ及其历史去重推论只用原pool的真实共点/高T/尺度/不交Fi，不要求i<h，保持有效。不能跨I相加的缺口也保持。

不得以删去h来回避本错误。删除后至少pool总负载变为Tₕ−qₕ，实际first-k law/keys也被修改；这不是原被冻结构造。本文件的最小修复正是保留所有原数据并计入self余项。

## 6. 本机实际轻量精确检查

实际运行用户已有Python数学环境，使用Fraction核对新分母的统一正性和书面系数变化：τ/2≥8192，ρₙ≤1/32，所以

Dₙ≥8192−1−1/32=262111/32>0，

8191/(8191−1/32)=262112/262111，

该比值−1=1/262111。

实际输出与断言均通过。只核对本次新增self修正，不重复旧扫描或S2已过计算；普遍bounds由第3–4节解析推导。

## 7. 有界交付

原定义核查完成：当前来源未被后轮删除，R668 strict-index认证有误，正确余项和最小分母修复已明确。未改任何旧报告，不新增source选择或研究目标，不声称原总目标闭合。授权有界审核完成，交付停止。

## 8. 追加有界独审：S2_SOURCE_INTERACTION

实际读取本轮S2_SOURCE_INTERACTION.md，独立核验后结论PASS。只认证文中明确来源与量词，不认证任何新AU。

1. 对i<j，χᵢⱼ=1{yⱼ∈Q(yᵢ,c₀sᵢ)}。原admission的Σ_{i<j}qᵢχᵢⱼ≤1逐j成立，因此Σⱼ|Fⱼ|Σ_{i<j}qᵢχᵢⱼ≤U。任意增加label链C_m，先对i₀求和用该界，再依次对i₁等求和，最终≤Σ|Fᵢ|=U。无独立pair law或隐藏chain multiplicity。非负可求和mixture的fee也是其系数和乘U，而不是免费无穷叠加。
2. 若i<j且x∈Bⱼ∩Aᵢ，则||yⱼ−yᵢ||∞≤sᵢ+sⱼ/a≤c₀sᵢ。因此χᵢⱼ=0严格推出Bⱼ∩Aᵢ=∅；S2给的reverse-triangle严格距离证明同样正确，结论是整块为空，不仅a.e.。
3. 实际pool只含i≤h。captured subset把self单独加入，质量≤1+qₕ。故noncaptured质量≥Tₕ−1−qₕ；其中均为i<h且χᵢₕ=0，所以整块Bₕ在其parent外。self修正未再次遗漏。
4. pool内captured unordered-pair mass≤Tₕ；total distinct-pair mass=(Tₕ²−Σqᵢ²)/2，且Σqᵢ²≤a^(−n)Tₕ。相减得到noncaptured pair mass≥Tₕ²/2−(1+a^(−n)/2)Tₕ，常数和方向准确。这是source-rate质量对比，不是receiver-volume付款。
5. captured-chain末端权是|Fₕ|。原|Xₕ|≤a^(−n)dₕ只能以a^(−n)/qₕ与|Fₕ|比较，该因子无统一界，qₕ=0的loss行更不能用正demand替代零capacity。把末端权换成|Xₕ|后只得到≤Vnear，不得到≤U。S2正确把这一步列为未证桥梁，未以receiver不交或小尺寸掩盖指数annulus envelope。

S2没有证明receiver transfer被captured chains支配，也没有把pair mass或chain bound当作新的跨pool source budget；其停止处分准确。未运行数字实验或重复旧计算。

## 9. A1_JOINT_GEOMETRY：residual tests、完整core及threshold独审

先独立核对父代理给出的statement，再实际读取A1_JOINT_GEOMETRY.md关键式。最终所读SHA-256：

`799a29897ac838387c04e729889a901fc36dafc70f55f8a492fb54246bd1fdb6`。

**A1的精确条件式和停止范围PASS，没有新增AU。**

### 9.1 只把充分rate测试用于它能证明的方向

令Dₕ=(2sₕ)ⁿ、bᵢ=qᵢdᵢ、0≤ρᵢ≤1为actual remaining fractions。i∈Iₕ保证dᵢ≥Dₕ，故

Σ_{Iₕ}ρᵢqᵢ≥a^(−n)
⇒Σ_{Iₕ}ρᵢbᵢ≥Dₕa^(−n)≥|Xₕ|。

这是合法的sufficient quick test。它失败时不能反推容量不足；A1没有犯这个逆推错误。A1(2.3)明确从更强的actual failure Σρᵢbᵢ<|Xₕ|出发，才得到Σρᵢqᵢ<a^(−n)，进而

Tₕ^spent=Σ_{Iₕ}(1−ρᵢ)qᵢ>Tₕ−a^(−n)。

self source可在这条非exterior capacity allocation中作为普通邻居容量使用，不与本文件此前canonical exterior zₕₕ=0混淆。spent fractions可用原Fi内真实measurable portions实现，保持disjoint及Bi支撑；但这不把spent capacity变成新可支出容量，也不改变原Poisson rates/keys。

### 9.2 threshold是独立的未付条件，不能用“差很小”略去

原Tₕ>τ/2没有统一margin，故spent load>Tₕ−a^(−n)只保证>τ/2−a^(−n)，不能保证≥τ/2。R662 frozen theorem要求n≥256和T≥8192√n=τ/2；旧证明没有在本轮被扩展到低一点的threshold。因此每个spent pool必须另行核对阈值，thin-margin分支确实仍存在。common core删labels也可能落到阈值下方，不能默认每个failed row/core都能调用R662。

A1 §2和§3明确保留该问题，未以τ/4替代、未忽略a^(−n)、未改变原pool来维持旧结论。该处分正确。

### 9.3 qualified common core的几何与R662 scale条件准确

对非空finite cluster C，J_C=∩_{h∈C}Iₕ、r_C=max_{h∈C}sₕ。若J_C非空，则每个zₕ均属于K_C=∩_{i∈J_C}Aᵢ；每个真实Xₕ⊂zₕ+c₀sₕQ，故整个union包含于K_C+c₀r_CQ。source i∈J_C属于达到r_C的target pool，故sᵢ≥r_C（甚至sᵢ<nr_C），共点条件可取任一zₕ。

在n≥256且T_C=Σ_{J_C}qᵢ≥τ/2时，真实Fi、共点及scale条件全部满足R662，直接继承

|K_C+c₀r_CQ|≤e^(−T_C/8)U_C。

本轮没有重证local theorem；实际near的n<256分支沿旧构造为空，不能将R662的n条件当成被删除。若是spent portions，需同时用相应真实spent Fi与其q质量，并重新检查同一阈值；不能只沿用原pool的Tₕ。

### 9.4 fractional cover与列预算没有被省略

若实际receiver-cover满足a.e. Σ_Cλ_C1_{⋃_{h∈C}Xₕ}≥1，非负积分给

Vnear≤Σ_Cλ_Ce^(−T_C/8)U_C
     =Σ_i |Fᵢ| Σ_{C:i∈J_C}λ_Ce^(−T_C/8)。

λ_C是实际fractional weights，不能当作全为1。统一column bound或其|Fi|-weighted total version仍未证明。单个core增长时删掉的labels确实只被删除一次、可在该core内telescoping；其他core可重新包含同一label，所以不能跨core telescope。A1完整保留receiver-cover、threshold preservation及column debit三项要求，没有以local exponential fee替代joint budget。

## 10. finite near-scale桶的条件总账独立核验

main REPORT及A1的新条件scale账PASS。若i∈Iₕ，则原strict near window sᵢ<nsₕ与sₕ≤sᵢ恰给

sₕ∈(sᵢ/n,sᵢ]。

该log-length为log₂n的区间至多碰到Lₙ=ceil(log₂n)+2个dyadic target buckets，bound与全input scale range无关。每cluster必须位于一个bucket；若i在该cluster的common core，则i确实参与该bucket的至少一个actual target，所以同一source的bucket次数也由Lₙ控制。

条件前提是每个bucket存在真实receiver fractional cover、每个core有T_C≥τ/2且符合R662，以及逐source逐bucket的weighted count Σ_{C:i∈J_C}λ_C≤Mₙ。则逐bucket与source求和准确给

Vnear≤LₙMₙe^(−τ/16)U。

没有未写出的额外cluster数或global scale数fee。该式在n≥256的R662有效范围使用；实际n<256 near为空，所以不会把旧定理误用到不合格的有target状态。

若额外有尚未证明的Mₙ≤e^(τ/32)，则主报告统一scalar比较为

Lₙe^(−τ/32)
≤3n/e^(512√n)
≤3/131072，

因为ceil(log₂n)≤n、n+2≤3n（integer n≥1），且e^x≥x²/2给e^(512√n)≥131072n。常数和τ/16、τ/32的方向均正确。

A1另写n≥256时Lₙ≤n、logn≤√n，从而log fee≤−511√n；这一更强scalar upper bound也正确，与主报告的较粗统一3/131072没有冲突。有限四个scale点只诊断这个已解析证明的coefficient，未构造cover，未付Mₙ。

因此“无限总尺度范围不必再次计费”是合法conditional bookkeeping；它既不构造within-bucket qualified cover，也不证明Mₙ或weighted column预算，不能列作新AU/strict contraction。threshold与column缺口是独立条件，二者都保留。

## 11. 最终主报告与S2哈希绑定

实际读取主REPORT完整数学正文后，发现noncaptured距离行的`,qquad`少反斜线，已通知主代理。其后实际读取最终修复行及最后复现scope；排版typo已修为`,\qquad`，数学内容未变。

最终实际读取REPORT.tex SHA-256：

`c1959a46a73cf6b1c9b70dce4cbe65f36a457bd7faafd8d350be3d6fa1bb4db8`。

最终实际读取S2_SOURCE_INTERACTION.md SHA-256：

`a1c988a5fb760b5944f13f4b1e0f9b7a96f86fdbcb2d14404efdd59974ce63fb`。

A1最终实读哈希为第9节所列`799a29897ac838387c04e729889a901fc36dafc70f55f8a492fb54246bd1fdb6`。

最终整合审核PASS：原self勘误、corrected denominator、unchanged full fees/recovery、source-capture chain及measure mismatch、actual residual failure测试、qualified core几何、thin-threshold分支和weighted column缺口均准确。source-chain bounds未被当作receiver预算，actual partition/keys/rates未改。全桶conditional fee明确不是已构造cover。

报告最后记录主代理用指定Python3.12.14独立replay四个conditional scale诊断，bucket bounds10、12、18、34及浮点log比较通过，并明确不是within-bucket cover或general geometry证书。本代理未重复这些已过计算。主报告没有新AU或closure主张。

**无剩余必须修改项。** 旧strict-prefix误审已在本新文件明确纠正，旧commit未改。所有本轮授权有界审核完成；只追加本S1，无spawn/Git/PDF/MATLAB，交付停止。
