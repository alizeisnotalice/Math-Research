from fractions import Fraction as F
from pathlib import Path
import sympy as sp
import json,sys,platform,hashlib
T,old,selfq=sp.symbols('T old selfq', real=True)
assert sp.expand((T-(old+selfq))-(T-selfq-old))==0
qmax=F(1,32); amin=F(8192)
assert amin-1-qmax>0
ratio=(amin-1)/(amin-1-qmax)
assert ratio==F(262112,262111)
# Uniform bound follows analytically because (t-1)/(t-1-q) decreases in t and increases in q.
t,q=sp.symbols('t q',positive=True)
r=(t-1)/(t-1-q)
assert sp.simplify(sp.diff(r,t)+q/(t-1-q)**2)==0
assert sp.simplify(sp.diff(r,q)-(t-1)/(t-1-q)**2)==0
from math import isqrt,log
scale_checks=[]
for n in (256,1024,65536,4294967296):
    root=isqrt(n); assert root*root==n
    K=(n-1).bit_length()+2
    log_fee=log(K)-512*root
    assert K<=n and log_fee<=-511*root
    scale_checks.append({'n':n,'buckets':K,'floating_log_fee':log_fee,'analytic_upper_log_fee':-511*root})
out={'pass':True,'python':platform.python_version(),'interpreter':sys.executable,'sympy':sp.__version__,'denominator_min':str(amin-1-qmax),'max_correction_factor':str(ratio),'conditional_scale_diagnostics':scale_checks,'scope':'exact correction algebra and derivative identities; four finite floating scale diagnostics only, no cover construction or geometric capacity bound','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
Path(__file__).with_name('INDEX_RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
