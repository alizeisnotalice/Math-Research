# 第106轮：密度停时树、细格容量与真实接收核心

2026-10-13。本轮继承第105轮提交 `60c2b23f9da3f8a44eed2a8506e5b8de19f2e533` 的实际中间段。目标仍是任意正 L1 输入的中心立方体 n^(1/2+o(1)) 一致弱型上界，允许对数损失；一般目标尚未证明。

本轮把来源分解与接收交通的对应关系作为几何估计的基础。独立平移的嵌套树让一个最细格边界事件同时控制全部层，避免逐层累积边界费。轻质量和高密度节点首次停止后，来源只付一次；剩余每个原赢家整体位于一个边长16na的低平均密度终端叶。

逐叶对原细格质量作连续容量截顶，用格内正输运和固定p=2的cube强型支付容量占优接收行。在其余接收行中，容量来源与超容量来源仍都存在；额外Young估计支付前者后，才真正得到被小体积细格并承载的超容量子来源交通。跨叶目标密度可能重叠，证明按叶使用L2与同一真实接收集的Cauchy估计，不假设重叠目标密度有全局上界。

原deep门还给出新的确定性删源付款：在每个叶中预冻结地删除质量最大的k个出生细格，每个接收点仅见一个叶，所以实际删除交通至多kκ_nX，其中κ_n=e² exp(−√n)/√n。随后统一删除低实际尾行；若剩余尾来源质量不超过λa^n exp(√n)，由冻结半径窗口按根阶来源价格付款。它覆盖了原总质量很大而少数细格集中后尾量变轻的叶，余下重尾仍完整保留。

真实列价剥离再把可付款来源和剩余接收核心联结：删除来源按当前列价收费，删除接收行按累计已删捕获收费，三角求和避免同一来源被每层重复收费。保留原门的双端共同接收核给同细格小能量及异细格来源付款证书；这些证书不构成一般高列核心的总预算。

全部新增误差和费用在密度树吸收后带8/7因子。旧P104、R105来源费及X/768保持原位置。后文的总账逐项保留来源质量、接收体积和新增小量误差；一般终端仍须保留有限窗口H_n质量包络，不以重命名余项代替完成。

## 工具、审查和数值边界

本轮实际使用更新64项技能中E03的跨层预算检查、D01的正输运接口、A02的正支配与误差账、F05的真实双端核检查和L03的精确有理认证方法。各模块说明实际读取范围；不宣称全部64项原文重新全文读毕。外部分析工具只有已核的固定p=2中心cube强型，不借用p趋1的免费常数。其余新增命题附自含证明。

作者与审查者分工，审查者先核准确命题和量词，再读最终证明。代理角色中断后由明确接手者继续，未把未落盘草稿计为已审证明。主代理负责复核、统一总账、精确程序隔离重放以及本轮单独提交。

固定三阶段数值输入为n=4、64、1024的非原子紧支撑来源。检验真实Lebesgue接收量、全均匀平移边界概率、正测度相位域中的实际停止/终端分类、逐叶容量与余量守恒。阶段2、3构造完整f及真实点态余额；阶段1仅检验较宽的树引理。未认证原FULL森林或全部上游资格，不把必要出生不等式当成原FULL证书。详细结果和实际执行状态见数值、验证章节。

研究中未得到净收益的随机稀疏化和振荡接口只保留准确失败原因：前者的质量减小被高度补偿抵消，后者缺少高细格均值及原门下的偏差预算。它们不进入新增付款，也不宣称反例否定一般目标。

本轮仅提交精简报告、详细LaTeX文本和必要复现代码；不编译PDF，不发布私人下界配方或私人程序。更细的剩余任务是从真实空间几何及原FULL共同来源条件，推出高列核心的总根阶付款或可求和的质量下降，而非重复低列价的条件性筛选。


## density tree

本节对 R105 的实际中间段增加一个多层来源分解。来源树在独立随机平移后冻结，轻质量节点和高平均质量节点在首次达到资格时停止。所有已停来源只收费一次；跨任何树层边界的实际交通由最细格的一个事件统摄，平均不超过原中间段的固定比例，可以直接吸收。最终赢家整只立方体落在一个边长 `cna` 的终端格中。该格仍重，但有低平均余额密度；一般终端的根阶预算仍未证明。

## 1. 原交通、额外独立随机性与参数

记 `η_ω` 为 R105 `μ′_ω` 限制到其未付中间质量 canonical 盒的预冻结来源，

\[
 W_\eta=\mathbb E\|\eta_\omega\|\le W_\mu,\qquad
 dT=G_0(x,z,\omega)h_{R(x)}(x-z)dx\,d\eta_\omega(z)dP(\omega).
 \tag{1}
\]

`T` 可取完整 `T_mid`，也可取其任何**不依赖下述新随机平移**的可测子交通。`0≤G_0≤1`，完整 `f` 和原选择器保持不变，`a≤R≤2a`，`A_Rf≤4λ`。所有 FULL、harmonicbad、原细格 birthdeep 以及既有新旧来源标签都保留在 `G_0` 中。新源不吸收依赖 `x` 的 deep 门。

设 `b_0=β/2=1/12288`。由原 canonical 盒的唯一捕获性质，在 (1) 的实际交通上

\[
 \eta_\omega(Q_x)\ge b_0\lambda R(x)^n.
 \tag{2}
\]

可将这个行指示函数显式乘进 `G_0`，不改变 (1)。这样以后删除其他正门时仍有正确的贡献资格。并非在所有不活跃行上声称 `η(Q_x)` 等于原捕获量。

取任意预先固定 `c>2`，令

\[
 \varepsilon_c=2/c<1,\quad s_*=cna,\quad
 s_0=(L-3)a,\quad
 D=\min\{d\in\mathbb Z_{\ge0}:2^d s_*\ge s_0\},\quad
 S=2^Ds_*,\quad s_\ell=S2^{-\ell}\ (0\le\ell\le D),
 \tag{3}
\]

其中 `L=3+ceil(6√n(1+n log2))`。所以 `D=O(log(n+2))`；`D=0` 允许。再记

\[
 M_*=\lambda a^n e^{\sqrt n},\qquad
 A_n=1+\sqrt n+\log(4/b_0^2),\qquad H_n=1+n\log2.
 \tag{4}
\]

引入独立于全部原变量的 `ξ∼Unif([0,S)^n)`，将概率空间扩充为原空间与此立方体的乘积。原 `T` 不依赖 `ξ`，扩充后其期望不变。没有依据某个当前接收点选平移，也不需要选择一个最优平移。

## 2. 单一嵌套格与最细边界事件

在新种子 `ξ` 下定义全局格

\[
 Q_{\ell,k}(\xi)=\xi+s_\ell(k+[0,1)^n),\qquad k\in\mathbb Z^n.
 \tag{5}
\]

每个节点在所有坐标各二等分，生成 `2^n` 个立方体孩子。每向下一层边长准确减半；不是将单坐标二叉步数误作层数。

令 `Bad(x,ξ)` 表示 `Q_x=Q(x,R(x))` 不能包含在某一个最细层 `s_*` 格内；其补集为 `Good`。对固定原 `x,ω`，`ξ` 模 `s_*` 在每个坐标上独立均匀。因为 `R≤2a<s_*`，一个长 `R` 的坐标区间跨最细格面的概率为 `R/s_*`（端点相等是零概率情形）。由并集界，

\[
 \boxed{\mathbb P_\xi(\operatorname{Bad}(x,\xi))
 \le\frac{nR(x)}{s_*}\le\frac2c=\varepsilon_c.} \tag{6}
\]

若 `Q_x` 整体位于一个最细格，它也整体位于该格的每一祖先。因此 (6) 已同时控制所有层的跨边界事件，没有再乘 `D` 或逐层并集费。

写 `T_bad=E_ξ∫1_Bad dT`。原交通与新种子独立，非负 Tonelli 给

\[
 \boxed{T_{\rm bad}\le\varepsilon_c T.} \tag{7}
\]

这是实际 `dx dη dP` 的交通估计。没有把小的随机边界概率冒充来源删除质量，也没有把某个有利平移的数值当作全部平移的平均。原 `T≤H_nW_η<∞`，所以后面的吸收合法。

## 3. 来源质量停时树

固定 `ω,ξ`，对每个有正 `η` 质量的根格开始下列确定规则。节点 `Q=Q_{ℓ,k}` 的质量始终为

\[
 m(Q)=\eta_\omega(Q),
 \qquad V(Q)=|Q+Q_{2a}|=(s_\ell+2a)^n. \tag{8}
\]

1. 若 `m(Q)≤M*`，标记为轻停止节点。质量为零的分支直接略去。
2. 否则，若 `m(Q)≥4λV(Q)/√n`，标记为密度停止节点。
3. 其余节点在 `ℓ<D` 时细分；在 `ℓ=D` 时保留为终端。

先轻后密度，资格若重叠只取第一类。测试始终先于深度终止，所以最后的每个终端均满足两个严格反向不等式。停止节点不再细分，因而所有轻停止、密度停止与最终终端共同构成一个来源分区。记它们的来源质量期望为 `W_light,W_dense,W_term`，其中期望现在同时对 `ω,ξ` 取，且

\[
 W_{\rm stop}=W_{\rm light}+W_{\rm dense},\qquad
 \boxed{W_{\rm stop}+W_{\rm term}=W_\eta.} \tag{9}
\]

这是一份跨所有树层的准确账本。同一来源只登记在首次停止节点或最终终端，不按它经过的每个祖先再次收质量。

原来源支持位于有限截断 `K`。对固定 `ξ`，只有有限个正质量根；所有层深度有限，故以上是有限森林。在整个 `ξ∈[0,S)^n` 上还可用一个固定有限根指标范围枚举包含 `K` 的候选根。所有节点来自 (5) 的联合可测有限库，质量测试和有限优先规则可测。有限树可能有很多节点；本证明没有把其计算复杂度称为多项式时间，也没有将节点数隐藏在付款常数中。

## 4. 好接收点的准确分配和停止节点付款

在 `Good` 上，`Q_x` 整体属于唯一最细格，沿其祖先链恰遇到一个停止节点或终端。因此每份好接收点交通都归于唯一来源包；跨孩子来源没有遗漏。若该唯一包为 `Q`，则

\[
 \eta_\omega(Q\cap Q_x)=\eta_\omega(Q_x)
 \ge b_0\lambda R(x)^n. \tag{10}
\]

所有原来源仍按 (1) 中的 `η` 和 `G_0` 积分。全局新格可以包含多个旧 canonical 盒的来源；这种预冻结合并不改变原门。由 (2) 和 `Q_x⊂Q`，(10) 对该节点的**全部实际捕获**成立，不需要重新给新节点判 FIRST 或 deep。

对于轻停止包，`m<b_0λa^n` 时 (10) 不可能发生，故其好交通为零。其余轻包可用固定标签

\[
 c_Q=b_0\lambda a^n/m(Q)\in(0,1],\qquad \beta_Q=b_0.
\]

根据 (10)、`R≥a`，两比例门均成立。R104 的对数单包付款给

\[
 T_{Q,\rm good}
 \le m(Q)\left[1+\log\frac{4m(Q)}{b_0^2\lambda a^n}\right]
 \le A_nm(Q). \tag{11}
\]

这里标签、包质量及所属树均在当前接收点之前冻结。该正界只使用原完整 `f` 的 hard 行上界，不要求子来源具有新的原门资格。

对于密度停止包，凡 `z∈Q` 被原 `Q_x` 捕获，必有 `x∈Q+Q_{2a}`。因此按真实接收测度，

\[
 T_{Q,\rm good}\le
 \int_{E\cap(Q+Q_{2a})}A_Rf(x)dx
 \le4\lambda V(Q)\le\sqrt n\,m(Q). \tag{12}
\]

来源包是反链；其接收邻域无需互不交。先逐包按 (11) 或 (12) 收实际质量，再对不交来源求和，有

\[
 \boxed{T_{\rm good,stop}
 \le A_nW_{\rm light}+\sqrt nW_{\rm dense}
 \le A_nW_{\rm stop}.} \tag{13}
\]

(13) 同时覆盖所有层，没有深度因子。原停源质量在此只使用一次；与此前 R104/R105 的已付模块若使用同一来源，其系数仍须相加。

## 5. 完整终端、边界吸收和主估计

令 `𝓛(ω,ξ)` 为最终终端节点。准确保留的实际量是

\[
 T_{\rm term}=\mathbb E_{\omega,\xi}\int_E\int
 G_0(x,z,\omega)h_{R(x)}(x-z)
 \mathbf1_{\rm Good}(x,\xi)
 \mathbf1_{\cup_{Q\in\mathcal L}Q}(z)
 d\eta_\omega(z)dx. \tag{14}
\]

于是非负积分的精确分解为

\[
 T=T_{\rm bad}+T_{\rm good,stop}+T_{\rm term}.
\]

结合 (7)、(13)，得到本轮树路线的付款结论

\[
 \boxed{(1-\varepsilon_c)T\le A_nW_{\rm stop}+T_{\rm term},
 \qquad\varepsilon_c=2/c.} \tag{15}
\]

例如 `c=16` 时 `ε_c=1/8`，

\[
 \boxed{T\le\tfrac87 A_nW_{\rm stop}+\tfrac87 T_{\rm term}.} \tag{16}
\]

最终每个活跃终端均是边长 `s*=cna` 的格，满足

\[
 \boxed{\lambda a^n e^{\sqrt n}<m(Q)
       <\frac{4\lambda(s_*+2a)^n}{\sqrt n},\qquad
 \frac{m(Q)}{|Q|}<\frac{4e^{2/c}\lambda}{\sqrt n}.} \tag{17}
\]

最后一式用 `(1+2/(cn))^n≤e^{2/c}`。终端的每个赢家立方体**整体在同一终端格中**，并满足 (10) 的原贡献下门。它仍保留原 birthdeep 逐细格约束、原完整 `f`、真实 `dx` 和全部未付门。这是比只说明来源落在若干小格内更强的实际几何性质。

为防止隐藏终端，始终保留

\[
 \boxed{T_{\rm term}\le H_nW_{\rm term}.} \tag{18}
\]

证明为固定 `ω,ξ` 后，对预冻结终端来源使用原有限半径包络，最后取期望。`W_term` 没有已证统一收缩。尽管停源付款的潜在账本可写成 `A_n m(Q)` 沿树守恒，不能将这个质量势当成实际终端交通的上界；(18) 的 `H_n` 一般大于 `A_n`。

## 6. 回代位置与准确进展

写 R105 已证主式为

\[
 R_{\rm out}\le P_{104}+B_{105}W_\mu+X/768+T_{\rm mid},
 \quad B_{105}=2+3\sqrt n+\log(16/\beta^2).
\]

直接对完整 `T=T_mid` 使用 (15)，得到

\[
 \boxed{R_{\rm out}\le
 P_{104}+B_{105}W_\mu+X/768
 +\frac{A_n}{1-2/c}W_{\rm stop}
 +\frac1{1-2/c}T_{\rm term}.} \tag{19}
\]

`1/(1−2/c)` 只来自对中间段自己的边界交通吸收；没有放大此前 `P104`、`B105 Wμ` 或 `X/768`。若先有其他本轮付款 `T_mid≤P_new+T`，而 `T` 是独立于新 `ξ` 的实际子交通，则在 (19) 右端原位置加 `P_new`，对这份 `T` 应用 (15)；不得把已有费用再次乘该因子。

本构造实付了内部首次出现的轻来源块和高质量密度块，所有层共用一次不交来源预算。随机边界吸收使赢家整块落在唯一终端节点，解决了直接细分时“一个赢家同时捕获许多孩子”的漏项，且未逐层删除来源或重付走廊费。新终端空间边长从 `O(n^(3/2))a` 降到固定 `cna`，保留 (17) 的低盒均值与实际包贡献资格。

但剩余质量的对数跨度仍可达 `n log(cn+2)+log4−(log n)/2`。低平均和原细格 deep 不自动给 (14) 根阶预算；没有证明每次细分会退出固定比例来源。本文没有免费迭代 (15)，也没有消去 (18)。一般 `n^(1/2+o(1))` 目标仍未闭合。

## tools

本节支付原中间段的一份明确接收子交通：原冻结余额中，按细格容量保留的来源承担至少一半实际 cube 捕获质量的接收行。格内高峰可以远高于原点态截顶；付款只要求其冻结细格质量可被均匀化到受控密度。整行付款不增加 `X` 误差。剩余行仍保持原交通，并增加“超过细格容量的来源承担至少一半捕获”的条件。没有证明这项覆盖对一般输入占统一比例。

## 1. 输入、变量映射与准确命题

使用本轮同一预冻结 `μ′_ω≤νres,ω`，原出生细格为半开不交分区 `C`，全边长
\[
 d=a/n.
\]
原 `H_C=μhi(C)`、出生半径和 `Bdeep(x,z)` 完全保留。以下截顶使用的质量是 `m_C(ω)=μ′_ω(C)`，不是 `H_C`，也不是按当前 receiver 的 deep 门条件化所得质量。

给定一个与 receiver 无关的容量密度 `τ>0`，令
\[
 \theta_C=\begin{cases}\min(1,\tau d^n/m_C),&m_C>0,\\1,&m_C=0,\end{cases}
 \quad d\eta_\omega(z)=\theta_{C(z)}d\mu'_\omega(z),
 \quad \zeta_\omega=\mu'_\omega-\eta_\omega,
 \quad W_\tau=\mathbb E\|\eta_\omega\|.
 \tag{T1}
\]
这是在 receiver 之前进行的连续来源截顶，每格保留质量 `min(m_C,τd^n)`；它允许保留高质量格的一个固定比例，而不必整格删除。定义仅需原冻结来源和可数细格分区，故联合可测。零质量格没有任何实际来源交通。`Wτ≤E‖μ′ω‖≤Wμ`；原 canonical 盒的 `m_j` 及其轻/中/top 类别不据 `η` 重算。

记 `r_mid(x,ω)` 为同一原 `Tmid` 的真实 row 密度，即仍以原 `μ′` 积分，保留所有原 `Ĝ`、deep、盒质量与其它门。取其准确可测接收行集合 `E_mid,ω`（允许包含零交通行），其中
\[
 a\le R(x)\le2a,\quad b'(x,\omega)=\mu'_\omega(Q_x)\ge\frac\beta2\lambda R(x)^n,
 \qquad r_{\rm mid}(x,\omega)\le A_{R(x)}f(x)\le4\lambda.
 \tag{T2}
\]
这里 `Q_x=Q(x,R(x))` 为全边长 `R(x)` 的中心 cube。令
\[
 U_{\tau,\omega}=\{x\in E_{\rm mid,\omega}:\eta_\omega(Q_x)\ge b'(x,\omega)/2\},
 \quad T_U=\mathbb E\int_{U_{\tau,\omega}}r_{\rm mid}(x,\omega)dx.
 \tag{T3}
\]
`Uτ` 依赖 `ω` 和真实原 winner；不是另选接收测度或对新来源重跑 FIRST。

**命题。** 令 `C2` 为已核的维数一致中心 cube 强 `L²` 常数。对 (T1)–(T3)，
\[
 \boxed{T_U\le\frac{64e^4C_2^2}{\beta^2}\frac\tau\lambda W_\tau.}
 \tag{T4}
\]
特别取 `τ=√nλ`，得到 `T_U≤C_cell√n Wτ`，其中 `C_cell=64e^4C2²/β²` 与维数、尺度、来源峰值及细格数无关，无新增 `X` 费。该常数较大，不能隐去 `β`。

工具变量的映射如下。

|工具对象|本节实际对象|已核连接|
|---|---|---|
|正耦合第一边缘|容量截顶来源 `ηω`|`ηω≤μ′ω`，在 receiver 前冻结|
|正耦合第二边缘|格内均匀密度 `sω dz`|逐格质量相同、`0≤sω≤τ`|
|位移限制|同一原细格内 `‖z−y‖∞≤d`|捕获 cube 只扩为全边长 `R+2d`|
|正支配代价|`((R+2d)/R)^n≤e²`|使用 `R≥a` 和 `d=a/n`|
|受控接收集合|原 winner 的 `Uτω`|原活跃下门给 `Msω≥βλ/(4e²)`|
|付款质量|`Wτ=E‖ηω‖`|整行价格由强 `L²` 测度界与原 `4λ` 行帽给出|

## 2. 自含正输运构造与证明

固定 `ω`，定义
\[
 s_\omega(y)=\sum_C\frac{\eta_\omega(C)}{d^n}\mathbf1_C(y),
 \quad 0\le s_\omega\le\tau,
 \quad \int s_\omega=\|\eta_\omega\|,
 \quad \|s_\omega\|_2^2\le\tau\|\eta_\omega\|.
 \tag{T5}
\]
可直接给出正输运计划
\[
 d\pi_\omega(z,y)=\sum_C\mathbf1_C(z)\,d\eta_\omega(z)\,
                  \frac{\mathbf1_C(y)}{d^n}dy.
 \tag{T6}
\]
其第一、第二边缘分别为 `ηω` 和 `sωdy`，总质量相同，且所有配对点处于同一细格。这里不调用输运强对偶、最优计划或向量测度定理；(T6) 是显式可行正计划。

若 `C∩Q(x,R)` 有正 `ηω` 质量，则整个 `C⊂Q(x,R+2d)`。因此，对每个 `R≥a`，非负求和给
\[
 \eta_\omega(Q(x,R))
 \le\sum_{C:\eta_\omega(C\cap Q(x,R))>0}\eta_\omega(C)
 \le\int_{Q(x,R+2d)}s_\omega(y)dy.
 \tag{T7}
\]
除以 `R^n` 得到正确方向的点态支配
\[
 A_R\eta_\omega(x)
 \le\left(1+\frac{2d}{R}\right)^nA_{R+2d}s_\omega(x)
 \le\left(1+\frac2n\right)^nMs_\omega(x)
 \le e^2Ms_\omega(x).
 \tag{T8}
\]
解析比较用的 `R+2d` 可以超出原 `[a,2a]`；原实际 winner 没有更换，强 `L²` 是全尺度 cube 定理。均匀化目标无需满足 `sω≤f`，也不会获得原 FULL 或出生资格；它只用于原交通的正上界。

在 `Uτω` 上，(T2)–(T3) 给
\[
 A_R\eta_\omega(x)\ge\frac{b'}{2R^n}\ge\frac\beta4\lambda,
 \qquad Ms_\omega(x)\ge\frac{\beta\lambda}{4e^2}.
 \tag{T9}
\]
由 Chebyshev、强 `L²` 与 (T5)，
\[
 |U_{\tau,\omega}|
 \le\frac{16e^4}{\beta^2\lambda^2}\|Ms_\omega\|_2^2
 \le\frac{16e^4C_2^2\tau}{\beta^2\lambda^2}\|\eta_\omega\|.
 \tag{T10}
\]
最后对真实 `dx` 用原行帽 `r_mid≤4λ`，再取同一概率平均，即得 (T4)。这一步支付 `Uτ` 上原 `μ′` 的**整行**交通，包含该行中 `ζ` 的交通；不要求容量来源自身的 deep 交通承载一半，只要求其实际 cube 捕获质量承载一半。门 `Bdeep(x,z)` 始终留在原 `r_mid` 内。

## 3. 精确新终端与正收益范围

有非负精确行拆分
\[
 T_{\rm mid}=T_U+T_{\rm exc},\qquad
 T_{\rm exc}=\mathbb E\int_{E_{\rm mid,\omega}\setminus U_{\tau,\omega}}
 r_{\rm mid}(x,\omega)dx.
 \tag{T11}
\]
在每个仍未付的行上，
\[
 \boxed{\zeta_\omega(Q_x)>b'/2\ge\frac\beta4\lambda R(x)^n.}
 \tag{T12}
\]
凡 `ζω(C)>0`，必有
\[
 m_C>\tau d^n,\qquad
 \zeta_\omega(C)=m_C-\tau d^n.
 \tag{T13}
\]
`T_exc` 仍以原 `μ′` 和全部原门积分，**不能**将其直接改写成以 `ζ` 为唯一来源的交通；(T12) 是其新增 receiver 资格。其有限终端仍可用原 `H_n W_mid`，没有得到一般根阶闭合。后续可将这个冻结的高细格均值来源 `ζ` 交给真实捕获容量工具，而不必对 receiver-dependent deep 来源另造边缘。

正收益条件是原实际交通在 `Uτ` 上为正；若整个来源的所有细格都满足 `m_C≤τd^n`，则 `η=μ′`、`Uτ=E_mid`，(T4) 支付全部中间段。这项条件允许细格内任意高峰；它比点态密度上界 `μ′≤τdz` 严格宽。一般输入中连续截顶保留高质量格的一部分，也可能产生比整格二分更大的 `Uτ`，但没有覆盖比例或统一收缩保证。

原深出生只给当前参与格 `H_C<e²qR^n exp(−√n)/√n`，并不保证 `m_C≤√nλ(a/n)^n`。两阈值之比准确为 `e²(q/λ)(R/a)^n n^n exp(−√n)/n`，不能把大量细格小质量误写成细格均值上界。低 canonical 大盒均值也不排除质量集中在少量高均值细格，故不能免费推出 `Uτ` 非空或占固定比例。

本节不付 receiver 投影为零的抽象测度，也不声称构造出完整 FULL 补集中的统一正覆盖实例。它给的是明确合法、可与所有原门相交的付款分支与更强余项。

## 4. 可选来源付款及其完整误差账

若后续需要只支付容量来源自身的全部现存交通，令 `T_η` 为原 `Tmid` 中将 `μ′` 换成 `η` 的正子交通。由 (T8)、Cauchy–Schwarz 和概率平均，对原有限接收集合 `E`、`X=λ|E|`，
\[
 T_\eta\le e^2C_2\sqrt{\tau W_\tau |E|}
 \le\frac{e^4C_2^2\tau}{4\varepsilon\lambda}W_\tau+\varepsilon X,
 \qquad\varepsilon>0.
 \tag{T14}
\]
若接收集合本身依 `ω`，准确写 `X_E=λE|Eω|` 后以同一联合 Cauchy–Schwarz 得相同形式。本轮主结论用无 `X` 的 (T4)，不将 (T14) 的额外 `εX` 默认为已被旧 `X/768` 预算覆盖。若两种付款都用于同一余额，其来源系数需照价相加，先付行与后付来源交通须取互补实际门。

## 5. 放在密度停时树之后的逐叶容量推论

采用独立随机平移密度停时树，固定 `c=16`、终端叶边长 `s*=16na`。为避免来源混同，记树的冻结输入为
\[
 \sigma_\omega=\mu'_\omega\big|_{\text{原中间质量 canonical 盒并}},
 \qquad W_{\rm tree}=\mathbb E\|\sigma_\omega\|.
 \tag{T15}
\]
树中的质量测试针对 `σ`；下文不能把它替换成仍包含原已付轻/top 盒来源的全局 `μ′`。若在集成记号中已经将这份未付冻结输入简记为 `μ′`，本节的 `σ` 正是那份 `μ′`。

对每个 `ω,ξ` 的终端叶 `V` 定义 `μV=σω|V`、`mV=μV(V)`。终端叶彼此不交，与已停来源也不交；在该叶的好接收行上，原 winner 满足
\[
 Q_x\subset V,\quad \mu_V(Q_x)=\sigma_\omega(Q_x)
 \ge\frac\beta2\lambda R(x)^n,
 \quad m_V<\frac{4\lambda(s_*+2a)^n}{\sqrt n}.
 \tag{T16}
\]
所有原 `G0`、birthdeep 及实际行帽仍保留；原源并未根据当前 `x` 改选。

在每个叶中分别对**原**细格做连续容量截顶，取 `τ=√nλ`，
\[
 m_{V,C}=\mu_V(C),\quad
 \theta_{V,C}=\min(1,\tau d^n/m_{V,C})\quad(m_{V,C}>0),
 \quad\theta_{V,C}=1\quad(m_{V,C}=0),
 \quad \eta_V=\theta_{V,C(z)}\mu_V,\qquad
 \zeta_V=\mu_V-\eta_V.
 \tag{T17}
\]
该分解在新平移后、receiver 前冻结。质量用 `μV(C)=σ(C∩V)`，原细格可以跨叶边界；绝不能用全局 `μ′(C)` 给每叶判定同一质量。树节点和叶标签来自联合可测有限库，(T17) 的可数细格运算及其质量因此联合可测。

记 `rV(x,ω,ξ)` 为好行终端交通归属叶 `V` 时、以原 `μV` 和原门计算的 row 密度。定义
\[
 U_V=\{x:Q_x\subset V,\ x\text{具有原好终端行资格},\
                      \eta_V(Q_x)\ge\mu_V(Q_x)/2\},
 \quad W_{\rm leafcap}=\mathbb E_{\omega,\xi}\sum_V\|\eta_V\|.
 \tag{T18}
\]
这些接收行按唯一终端叶分配，不重复付行。逐叶应用 (T5)–(T10)，然后对同一 `ω,ξ` 的叶求和，得
\[
 \boxed{T_{\rm leafcap}:=\mathbb E_{\omega,\xi}\sum_V\int_{U_V}r_Vdx
       \le C_{\rm cell}\sqrt n\,W_{\rm leafcap},
 \qquad C_{\rm cell}=64e^4C_2^2/\beta^2.}
 \tag{T19}
\]
证明中每个叶分别构造 `sV=Σ_CηV(C)d^{-n}1C≤τ`。不同 `sV` 可以在跨叶原细格上重叠，所以不能先合成它们再声称 `ΣVsV≤τ`；(T19) 使用逐叶强 `L²` 价格及不交**来源**预算，故没有叶数、原细格数或新平移的维数费。

设 `Tleaf,exc` 为好终端交通去掉这些 `UV` 后的原实际余项，则有精确行拆分
\[
 T_{\rm term}=T_{\rm leafcap}+T_{\rm leaf,exc}.
 \tag{T20}
\]
仍未付的叶内接收行满足
\[
 \boxed{\zeta_V(Q_x)>\mu_V(Q_x)/2\ge\frac\beta4\lambda R(x)^n.}
 \tag{T21}
\]
`Tleaf,exc` 的被积来源仍是 `μV`，不是 `ζV`；(T21) 是其真实新增行资格。

定义原高细格均值的整格并
\[
 S_V=\bigcup_{C:m_{V,C}>\tau d^n}C.
 \tag{T22}
\]
`ζV` 被 `S_V∩V` 承载。由于原细格不交，且每个入选格至少贡献 `τd^n` 质量，入选格数有限，并有真实 Lebesgue 体积界
\[
 \boxed{|S_V|=d^n\#\{C:m_{V,C}>\tau d^n\}
       \le\frac{m_V}{\tau}
       <\frac4n(s_*+2a)^n
       \le\frac{4e^{1/8}}n|V|.}
 \tag{T23}
\]
最后一步使用 `s*=16na`，所以 `(1+2a/s*)^n=(1+1/(8n))^n≤e^{1/8}`。`S_V` 是完整细格并，允许伸出 `V`，界 (T23) 仍成立，因为计数质量始终用叶限制 `μV(C)`。这不是点态密度界，也不能从 `|S_V|` 小免费推出其 cube 邻域或接收点体积小。

停止节点来源与叶内 cap 来源互不交，故密度树已有 `Wstop+Wterm=Wtree` 可进一步精确写为
\[
 W_{\rm stop}+W_{\rm leafcap}+W_{\rm leafexc}=W_{\rm tree},
 \quad W_{\rm leafexc}:=\mathbb E_{\omega,\xi}\sum_V\|\zeta_V\|.
 \tag{T24}
\]
因此停止节点费与 (T19) 可以共享最大系数：
\[
 A_nW_{\rm stop}+C_{\rm cell}\sqrt nW_{\rm leafcap}
 \le\max\{A_n,C_{\rm cell}\sqrt n\}
       (W_{\rm stop}+W_{\rm leafcap})
 \le\max\{A_n,C_{\rm cell}\sqrt n\}W_{\rm tree}.
 \tag{T25}
\]
该共享只用于这些不交来源类别；与 R104/R105 的旧费用仍可能使用同一来源，不能因此减掉旧项。`Wleafexc` 是冻结来源余量，而 `Tleaf,exc` 仍包含容量来源在未付行的交通，不能未经额外支配便把其有限包络价格写成 `HnWleafexc`。

树的既有边界吸收 `(7/8)Tmid≤A_nWstop+Tterm` 与 (T19)–(T25) 给
\[
 \boxed{T_{\rm mid}\le\frac87\left[
       A_nW_{\rm stop}+C_{\rm cell}\sqrt nW_{\rm leafcap}
                         +T_{\rm leaf,exc}\right]
       \le\frac87\max\{A_n,C_{\rm cell}\sqrt n\}W_{\rm tree}
                         +\frac87T_{\rm leaf,exc}.}
 \tag{T26}
\]
所有质量与交通在相同 `ξ` 上计算后积分；没有另选一个有利平移，也没有再次收跨边界费。`8/7` 来自既有树边界吸收，仍乘本次新费与终端；此前 `P104`、`B105Wμ`、`X/768` 不被放大。

本推论将真正余项加强为：原 winner 整体位于一个边长 `16na` 的低均值叶；一份 receiver 前冻结的细格超容量来源，被体积不到 `4e^{1/8}|V|/n` 的原细格并承载，并在每个未付行承担至少 `βλR^n/4` 捕获。没有据此证明一般根阶终端，也没有把小来源体积当作小接收体积。

## 6. 工具证据边界

本轮实际阅读 D01 正输运 Skill、方法与 cube 接口，采用其“先给正边缘及真实可行计划、另证最大算子连接”的流程；本节 (T6)–(T8) 是自含构造。没有借用向量 KR、随机路径输运或未读外部强对偶定理。实际阅读 A02 正支配记账 Skill；(T11)、(T14) 逐项保留实际门、来源价格和误差。

实际阅读 F05 Skill 与 cube 接口：单一 Schur 行列界不控制连续尺度上确界，故本节没有将 Schur 名称用于代替 cube maximal 定理。另读 E01、F03、G01，当前实际输入缺过程流守恒、Hilbert 正交层或全树 packing，不从相邻名称推一般接收几何。

唯一使用的外部分析结果仍是已继承的固定 `p=2` 中心 cube 强型。本文另核 [Bourgain, *On the Hardy–Littlewood maximal function for the cube*](https://arxiv.org/pdf/1212.2661) 第 1 页 (1.1)–(1.2)、第 3 页 Theorem 与 `B∞=[−1/2,1/2]^n` 约定，确认全尺度、真实 Lebesgue 测度、固定 `p>1` 常数与维数无关。没有重读并重证整篇 Fourier 证明，也没有使用 `p→1` 的免费常数。格内正输运、连续细格容量及整行付款是本文推导，与原文定理区别明确。

## birth occupancy

原深出生门允许在每个终端叶中预先删除质量最大的若干出生细格；这笔删除按真实接收交通支付。每个接收立方体完全落在唯一叶中，所以删除费用不乘叶数。删除后的轻尾源可以按根阶窗口支付。下面给出确定性来源选择、完整费用及准确剩余项。

### 1. 实际来源、唯一叶及深出生门

设 `λ,a>0`，`E` 可测且有限，`X=λ|E|`。共同变量 `ω` 服从概率测度；所有来源选择先于 receiver `x` 冻结。取可数不交可测叶 `V=V(ω)` 及来源

\[
 \nu_\omega=\sum_V\nu_{V,\omega},\qquad
 \operatorname{supp}\nu_V\subset V,\qquad
 \nu_V\le1_V\mu_{hi},\qquad
 W_\nu=\mathbb E\sum_V\|\nu_V\|<\infty.
 \tag{B1}
\]

叶及测度具有共同可测编号。设实际交通为

\[
 T=\int_E\mathbb E\int G(x,z,\omega)h_{R(x)}(x-z)d\nu_\omega(z)dx,
 \quad 0\le G\le1,\quad
 h_R=R^{-n}1_{Q(0,R)},\quad a\le R\le2a.
 \tag{B2}
\]

它保留原完整 `f`、选择器及全部原门。其每个非零实际 row 的 `Q_x=Q(x,R(x))` 完全包含于唯一叶 `V_x(ω)`。半开格的边界按零测集处理；原来源被 `f dz` 支配，故不造成额外交通。这正是本轮 nested-tree 的 Good 子交通性质。其它 receiver 的实际交通为零。来源可以取该终端交通的实际 `ν_V`；若某工具只支付 whole row、在补集仍保留原来源，则使用该原来源，不能擅自换成容量 excess 来源。

原出生细格 `C_j(ω)` 全边长 `a/n`，构成可数半开分区。其旧质量和出生尺度是

\[
 H_j=\mu_{hi}(C_j),\qquad
 t_j=(H_j\sqrt n/(e^2q))^{1/n},\qquad
 3\lambda/4\le q\le\lambda.
\]

只对正实际交通使用原深门 `n log(R/t_j)>√n`。所以该格在当前 receiver 有正交通时

\[
 H_j<\frac{e^2q}{\sqrt n}R^ne^{-\sqrt n}.
 \tag{B3}
\]

`H_j=0` 时其来源为零，无须定义正出生对数。原 FULL 的适用维数为 `n≥512`；若在其它维数独立给定 (B1)–(B3)，以下引理仍成立，但不因此获得小维 FULL。原 `q,H_j,t_j` 都不按新来源重算。

### 2. 预冻结质量 top-k 及其可测性

固定整数 `k≥0`。在每个叶中按**来源质量**

\[
 m_{V,j}=\nu_V(C_j\cap V),\qquad m_V=\sum_jm_{V,j}
\]

取最大的至多 `k` 个正质量格，等质量按预定编号 `j` 的先后解 tie，记索引集 `I_k(V,ω)`。选择不依赖 `x`、`R(x)`、当前 row 或 current capture。定义

\[
 \nu_V^{\rm top}=\sum_{j\in I_k(V)}1_{C_j}\nu_V,
 \qquad \nu_V^{\rm tail}=\nu_V-\nu_V^{\rm top},\qquad
 m_V^{\rm tail}=\|\nu_V^{\rm tail}\|.
 \tag{B4}
\]

可数排序同样合法。非负可数质量和有限时，若余质量的 supremum `s>0`，只有有限个质量至少 `s/2`，故 `s` 被达到。取达到 `s` 的最小编号，再递归 `k` 次；无正质量时停止。`s` 是可数可测函数的 supremum，选择第 `j` 个最大值的事件由 `m_j=s>0` 及前面有限编号未达到 `s` 表示，故每一步与最终有限选择集可测。`k=0` 取空集。这也覆盖当前 finite `K0` 中的有限出生格库，不增加实现复杂度断言。

若旧细格跨越多个叶，选择的是各叶中的来源片 `C_j∩V`。这些片互不交，因而 (B4) 是一份真正的预冻结来源分解，不是 receiver-dependent 门改称来源。

### 3. top-k 删除的真实接收费用

固定 receiver 与共同变量，设其唯一叶为 `V`。第 `j` 格的实际分量

\[
 r_{V,j}(x,\omega)=\int_{C_j}G h_Rd\nu_V
\]

若为正，由 (B3) 及 `ν_V≤μhi` 得

\[
 r_{V,j}\le H_j/R^n
 <\frac{e^2q}{\sqrt n}e^{-\sqrt n}
 \le\kappa_n\lambda,\qquad
 \kappa_n=\frac{e^2}{\sqrt n}e^{-\sqrt n}.
 \tag{B5}
\]

其为零时同一弱界成立。每个 receiver 只见该叶所选的至多 `k` 个格，因此删除交通满足

\[
 \boxed{T_{\rm top}\le k\kappa_n X.}
 \tag{B6}
\]

这笔预算使用原 `dx`，没有来源质量包络费、kernel 高度放大、叶数或森林深度因子。某个被删除格的质量可以很大；(B6) 仍只使用它被原深门允许贡献时的实际 row 上界。删除不要求这些格具有任何重新计算的出生资格。

### 4. 真实尾 row、轻尾源付款及重尾余项

令 `νtail=Σ_V ν_Vtail`，使用同一原 `G` 定义

\[
 r_{\rm tail}(x,\omega)=\int G h_Rd\nu^{\rm tail}_\omega.
\]

固定 `0<δ≤1`。将 `r_tail≤δλ` 的尾交通直接支付，费用至多 `δX`。剩余实际 row 满足 `r_tail>δλ`。它仍只有一个叶，且

\[
 \delta\lambda<r_{\rm tail}
 \le\frac{\nu_V^{\rm tail}(Q_x)}{R^n}
 \le\frac{m_V^{\rm tail}}{R^n}.
 \tag{B7}
\]

这是新增筛选得到的**真实加权 row 下界**，不是继承旧 raw capture 下门。它还给新 raw tail capture `ν_Vtail(Q_x)>δλR^n`。

设

\[
 M_*=\lambda a^ne^{\sqrt n},\qquad
 \mathcal L=\{V:m_V^{\rm tail}\le M_*\},\qquad
 W_{\rm tail,light}=\mathbb E\sum_{V\in\mathcal L}m_V^{\rm tail}.
\]

对轻尾叶，若 `m_Vtail<δλa^n`，不存在 (B7) 的高 row。其余高 row 的半径属于在 receiver 前冻结的窗

\[
 a\le R\le r_V^+:=
 \min\{2a,(m_V^{\rm tail}/(\delta\lambda))^{1/n}\}.
 \tag{B8}
\]

有限半径正包络具有精确质量

\[
 \int_{\mathbb R^n}\sup_{a\le R\le r_V^+}h_R(v)dv
 =1+n\log(r_V^+/a).
 \tag{B9}
\]

自含证明：令 `u=2||v||∞`。`u≤a` 时包络为 `a^{-n}`，`a<u≤r_V^+` 时为 `u^{-n}`，其余为零；`|{u≤s}|=s^n`，故积分为 `1+∫_a^{r_V^+}u^{-n}d(u^n)=1+n log(r_V^+/a)`。Tonelli、`G≤1` 及 (B8) 对每份轻尾源分别给

\[
 \begin{split}
 T_{\rm tail,light,high}
 &\le A_n(\delta)W_{\rm tail,light},\\
 A_n(\delta)
 &=1+\min\{n\log2,\sqrt n+\log(1/\delta)\}.
 \end{split}
 \tag{B10}
\]

这里每份来源片只属于一个叶；叶的窗口可不同，但没有重复来源或跨层费用。零质量叶为空。不活跃轻叶也可计入右端，因为 `A_n(δ)>0`。

定义余项为真实原门上的交通

\[
 T_{\rm distributed}
 =\int_E\mathbb E\int
 1_{\{m_{V_x}^{\rm tail}>M_*,\ r_{\rm tail}>\delta\lambda\}}
 G h_Rd\nu^{\rm tail}_\omega dx.
 \tag{B11}
\]

无唯一叶的零交通处该指示定义零。来源仍是预冻结的 `νtail`；(B11) 的 joint 门没有被吸收为来源。其保留旧深门、旧 FULL 门、唯一叶及新的真实尾 row 下界。准确分解与付款是

\[
 \boxed{
 T\le(k\kappa_n+\delta)X
       +A_n(\delta)W_{\rm tail,light}
       +T_{\rm distributed}.}
 \tag{B12}
\]

此式支付了一类新实际交通：原叶质量即使超过 `M*`，只要删除 top-k 后尾质量不超过 `M*`，其全部原交通均进入已付款分支。删除的来源质量没有乘任何 coupon；这与取样后放大 kernel 的方案不同。

### 5. 参数、层费及未付责任

给任意预定 `0<ε<1`，可以取

\[
 \delta=\epsilon/2,\qquad
 k=\left\lfloor\frac{\epsilon}{2\kappa_n}\right\rfloor.
 \tag{B13}
\]

于是新增接收误差 `kκ_nX+δX≤εX`，来源价格为
`A_n(ε/2)≤1+√n+log(2/ε)`。该整数有限，可在每叶正格不足时提前停止；若小维或极小预算使 `k=0`，结论照常成立，没有凭空删源。原应用仍要求 `n≥512`。保持 (B13) 的有限 `k` 比在无穷来源格上删无限多格更强，也避免无穷接收误差。

若接在本轮 side `s*=cna` 的树后，已证边界关系是

\[
 (1-2/c)T_{mid}\le A_{stop}W_{stop}+T_{term}.
\]

将 (B12) 用于真实 `Tterm`，得到

\[
 (1-2/c)T_{mid}\le
 A_{stop}W_{stop}+A_n(\delta)W_{\rm tail,light}
 +(k\kappa_n+\delta)X+T_{\rm distributed}.
 \tag{B14}
\]

`Wν` 在 (B1) 中仅指本引理的终端输入来源，不含 stop。令 `Wtree` 为停时树原输入来源总质量；在本引理来源是该树终端来源的子测度时，`Wstop+Wtail,light≤Wstop+Wν≤Wtree`。stop 来源与原终端来源不交，尾源又是实际终端输入的子测度。若本引理在其后其它已付工具留下的子来源上应用，同一不等式仍由支配成立。没有额外 tree depth 费。取 `c=16`，所有本式新费用和余项回代时乘 `8/7`。例如纯符号参数 `ε=7/24576`、`δ=7/49152` 给回代后的新增接收费用最多 `X/3072`，来源价格显式为 `(8/7)[1+min{n log2,√n+log(49152/7)}]`。这笔是新增费用，不能复用此前 `X/768`；若后续沿用 (B11) 的高 row，不再为同一低尾 row 重收 `δX`。

余项还满足严格的排序限制：令 `b_V=max_j ν_Vtail(C_j)`，则

\[
 k b_V\le\|\nu_V^{\rm top}\|,
 \qquad (k+1)b_V\le m_V,
 \qquad m_V^{\rm tail}>M_*.
 \tag{B15}
\]

若尾为空取 `bV=0`；有限正格不足 `k` 时尾必空。前两式来自每个已选质量不小于任何尾格质量。它们以**原叶总质量**为右端，不是假称尾格密度帽或尾格质量由尾总质量平均控制。没有证明所有叶的尾质量必变轻，也没有证明一般重尾交通的根阶预算。(B11) 的共同来源几何、原 FULL 与严格 CP/GP 如何进一步支付，仍是剩余责任；本次确定性删源与轻尾付款不声称一般闭合。

## capacity

本节给出一份来源只收费一次的列价剥离定理。它支付低实际列价来源及由其触发删除的接收行，保留同一个真实接收测度、原半径和原门。无限步终端具有双侧下界，但这些下界本身不构成一般根阶付款。

## 1. 输入和命题

固定 \(n\ge1\)、\(a,\lambda>0\)、\(\delta>0\)、\(0<\theta<1\) 和列价阈值 \(C_n>0\)。设 \(E\subset\mathbb R^n\) 可测且有限测度，\(\mu_0\) 是有限正 Borel 测度，\(R:E\to[a,2a]\) 可测，\(J:E\times\mathbb R^n\to[0,1]\) 联合可测。定义
\[
 Q_x=x+[-R(x)/2,R(x)/2]^n,\qquad
 w(x,z)=J(x,z)\mathbf1_{Q_x}(z),\qquad
 k(x,z)=R(x)^{-n}w(x,z),
 \tag{C1}
\]
\[
 r_0(x)=\int k(x,z)d\mu_0(z),\qquad
 T_0=\int_Er_0(x)dx,\qquad X_E=\lambda|E|.
 \tag{C2}
\]
在当前应用中 \(r_0\le4\lambda\)、\(\mu_0\le\mu_{\rm hi}\le f\,dz\)，且 \(J\) 保留所有原 FULL、出生 deep、选择器和此前门。一般命题的费用证明只需要以上可测性和有限性，不另用 \(4\lambda\) 行帽。所有原标签、\(R,J,\mu_0\) 在迭代中冻结。

存在可测递减接收集 \(E_i\) 和来源集 \(F_i\)，令
\[
 E_\infty=\bigcap_{i\ge0}E_i,\quad
 F_\infty=\bigcap_{i\ge0}F_i,\quad
 P=F_\infty^c,\quad
 \mu_\infty=\mu_0|_{F_\infty},\quad
 T_\infty=\int_{E_\infty}\int k(x,z)d\mu_\infty(z)dx.
\]
则
\[
 \boxed{T_0\le\delta X_E+\frac{C_n}{\theta}\mu_0(P)+T_\infty.}
 \tag{C3}
\]
终端满足
\[
 \boxed{r_\infty(x):=\int k(x,z)d\mu_\infty(z)
 \ge(1-\theta)r_0(x)>(1-\theta)\delta\lambda,
 \quad x\in E_\infty,}
 \tag{C4}
\]
\[
 \boxed{c_\infty(z):=\int_{E_\infty}k(x,z)dx\ge C_n,
 \quad z\in F_\infty.}
 \tag{C5}
\]
若原输入只按几乎处处给定，则取可测版本并按相应零集理解结论。(C5) 是非严格下界，不能声称极限已经是“删除所有 \(c\le C_n\)”规则的严格固定点。

## 2. 准确递归

先删低行
\[
 L=\{x\in E:r_0(x)\le\delta\lambda\},\qquad
 E_0=E\setminus L,\qquad F_0=\mathbb R^n.
 \tag{C6}
\]
其交通至多 \(\delta\lambda|E|\)。若输入已满足所有行 \(r_0>\delta\lambda\)，则 \(L=\varnothing\)，直接从 \(E_0=E\) 开始，(C3) 的低行费用准确为零；(C4) 仍以同一 \(\delta\) 成立。给定 \(E_i,F_i\)，先计算当前真实列价并删除其低价全集：
\[
 c_i(z)=\int_{E_i}k(x,z)dx,\qquad
 S_i=\{z\in F_i:c_i(z)\le C_n\},\qquad
 F_{i+1}=F_i\setminus S_i.
 \tag{C7}
\]
令累计删除来源集和其原捕获为
\[
 U_i=\bigcup_{j=0}^iS_j=F_{i+1}^c,\quad
 a_0(x)=\int w(x,z)d\mu_0(z),\quad
 a_{U_i}(x)=\int_{U_i}w(x,z)d\mu_0(z).
\]
随后删除
\[
 D_i=\{x\in E_i:a_{U_i}(x)\ge\theta a_0(x)\},
 \qquad E_{i+1}=E_i\setminus D_i.
 \tag{C8}
\]
由于 \(R(x)^{-n}\) 对同一行的全部来源相同，(C8) 等价于按实际 \(k\) 行交通的累计比例删除。其分母始终是原 \(a_0\)，不是每轮剩余捕获。\(S_i\) 两两不交，\(D_i\) 两两不交，且 \(i\ge j\) 时 \(D_i\subset E_j\)。

## 3. 三角计费，不重复收累计来源

令当前剩余交通为
\[
 T_i^{\rm rem}=\int_{E_i}\int_{F_i}k(x,z)d\mu_0(z)dx.
\]
本轮先删来源的交通和随后删行的剩余交通分别为
\[
 P_i=\int_{S_i}\int_{E_i}k(x,z)dx\,d\mu_0(z)
 \le C_n\mu_0(S_i),
\]
\[
 Q_i=\int_{D_i}\int_{F_{i+1}}k(x,z)d\mu_0(z)dx.
 \tag{C9}
\]
此处精确恒等式为 \(T_i^{\rm rem}=P_i+Q_i+T_{i+1}^{\rm rem}\)。在 \(D_i\) 上，累计删源的 \(k\) 交通至少是原交通的 \(\theta\) 倍，故剩余交通至多是累计删源交通的 \((1-\theta)/\theta\) 倍。于是非负 Tonelli 给
\[
\begin{aligned}
 \sum_{i\ge0}Q_i
 &\le\frac{1-\theta}{\theta}
   \sum_{i\ge0}\sum_{j\le i}
       \int_{S_j}\int_{D_i}k(x,z)dx\,d\mu_0(z)\\
 &=\frac{1-\theta}{\theta}
   \sum_{j\ge0}\int_{S_j}
       \int_{\bigcup_{i\ge j}D_i}k(x,z)dx\,d\mu_0(z)\\
 &\le\frac{1-\theta}{\theta}\sum_{j\ge0}P_j.
\end{aligned}
 \tag{C10}
\]
第二行用 \(D_i\) 互不相交；第三行用 \(\bigcup_{i\ge j}D_i\subset E_j\)。这正是三角索引 \(j\le i\) 的作用。不能先把各轮累计 \(\mu_0(U_i)\) 独立估价后求和。

有限轮恒等式求和，再令轮数趋于无穷，得到
\[
 T_0^{\rm high}=\sum_{i\ge0}(P_i+Q_i)+T_\infty
 \le\frac1\theta\sum_{i\ge0}P_i+T_\infty
 \le\frac{C_n}{\theta}\mu_0(P)+T_\infty.
 \tag{C11}
\]
加回 (C6) 即得 (C3)。这里 \(T_0^{\rm high}\) 指低行删除后的交通，区别于 (C2) 的原总量。

## 4. 极限、可测性和参数平均

有 \(0\le k\le a^{-n}\)。因此 \(k\) 在有限乘积测度 \(dx|_E\otimes\mu_0\) 下可积，\(T_i^{\rm rem}\to T_\infty\) 由递减指示函数的支配收敛成立，(C11) 没有隐藏余项。

若 \(x\in E_\infty\)，则对每个 \(i\) 有 \(a_{U_i}(x)<\theta a_0(x)\)。单调收敛给 \(a_P(x)\le\theta a_0(x)\)，减去该部分并乘 \(R(x)^{-n}\) 得 (C4)。若 \(z\in F_\infty\)，则每个 \(c_i(z)>C_n\)；\(k(\cdot,z)\le a^{-n}\mathbf1_E\) 可积，故 \(c_i(z)\downarrow c_\infty(z)\ge C_n\)。有限轮的严格不等式到极限可以变为等号。

集合 (C6)–(C8) 仅使用联合可测函数的非负积分、阈值测试及可数并交，故全部可测。更一般地，若所有输入还依赖参数 \(\alpha\)（原随机种子、新平移及有限或可数叶标签），要求 \(\mu_{0,\alpha}\) 为有限可测测度核，\(E_\alpha,R_\alpha,J_\alpha\) 联合可测；同一递归产生联合可测的来源与行集。此处没有按参数选 argmax 或最优集合的步骤，不需要一般可测选择定理。

对每个样本的互不相交接收集 \(E_{\alpha,V}\subset E\) 分别应用 (C3)，再求和与概率平均，可用
\[
 \lambda\mathbb E\sum_V|E_{\alpha,V}|\le\lambda|E|=X
 \tag{C12}
\]
合并低行费为 \(\delta X\)。来源删除费则按各叶实际来源质量求和；若各叶来自同一正测度的分解，总质量账无叶数因子。每个叶的 \(J\)、来源和原捕获分母均须保持各自原定义。

## 5. 真实接收体积与有限窗口包络

对任意当前接收集 \(E'\subset E\)，记
\[
 V^J_{E'}(z)=\int_{E'}w(x,z)dx,\qquad
 c_{E'}(z)=\int_{E'}R(x)^{-n}w(x,z)dx.
\]
因 \(R\le2a\)，\(w(\cdot,z)\) 支撑于 \(z+[-a,a]^n\)，故 \(V^J_{E'}(z)\le(2a)^n\)。设 \(t(x)=2\|x-z\|_\infty\)。在捕获支撑上 \(R\ge\max(a,t)\)，故
\[
 c_{E'}(z)\le\int u(x)\min\{a^{-n},t(x)^{-n}\}dx,
 \qquad u=\mathbf1_{E'}w(\cdot,z),\quad 0\le u\le1.
\]
\(\{t<s\}\) 的体积是 \(s^n\)。令 \(v=\int u\)，层蛋糕与 \(\int_Au\le\min(v,|A|)\) 给
\[
 c_{E'}(z)\le\int_0^{a^{-n}}\min\{v,s^{-1}\}ds
 =\Phi(v/a^n),\quad
 \Phi(t)=\begin{cases}t,&0\le t\le1,\\1+\log t,&1\le t\le2^n.\end{cases}
 \tag{C13}
\]
\(t=0\) 时按零值解释。特别
\[
 c_{E'}(z)\le H_n:=1+n\log2,\qquad
 T_\infty\le H_n\|\mu_\infty\|.
 \tag{C14}
\]
若 \(1\le C_n\le H_n\)，(C5)、(C13) 反解为
\[
 V^J_{E_\infty}(z)\ge a^n e^{C_n-1}.
 \tag{C15}
\]
因此本轮取 \(C_n=1+\sqrt n\)、\(\theta=1/2\)，有
\[
 T_0\le\delta X_E+2(1+\sqrt n)\mu_0(P)+T_\infty,
 \quad c_\infty\ge1+\sqrt n,
 \quad r_\infty>\delta\lambda/2.
 \tag{C16}
\]
在 \(1+\sqrt n\le H_n\) 的维数范围，另有 \(V^J_{E_\infty}\ge a^n e^{\sqrt n}\)。原 FULL 范围 \(n\ge512\) 满足此条件；若 \(C_n>H_n\)，第一次低列价测试即删除所有有质量来源，终端为空。

(C13) 表明“低实际接收体积”只是低列价的一份充分证书。若通过另一已证条件也能推出当轮 \(c_i(z)\le C_n\)，它已包含在 (C7) 的低列价全集内，无须另加一轮来源费用。也可允许任意可测 \(S_i\subset F_i\) 且其上 \(c_i\le C_n\)，(C3)、(C4) 仍成立；但不再自动有 (C5)。

本定理没有改变真实 \(dx\)，没有放大或重算 \(J\)，没有重选 \(R\)，也没有把 \(x\) 相关 deep 门吸收到来源测度里。原 \(\mu_\infty\le\mu_0\le\mu_{\rm hi}\) 与出生标签继承。终端高列价和正行下界尚不足以把 (C14) 的 \(H_n\) 换成统一根阶价格。

## core budget

本节把加权来源剥离所得核心连接到一个显式的几何相互作用预算。得到的是一类真实来源子交通的根阶付款，以及一个准确的未付核心条件；没有证明一般输入的低相互作用来源占统一比例，也没有证明一般根阶上界。

## 1. 必须使用实际门的核心

固定所有已经冻结的随机种子、叶和原选择器。来源为有限正测度 `μ0≤μhi`，实际交通为
\[
 T_0=\int_{E_0}\int J(x,z)h_{R(x)}(x-z)d\mu_0(z)dx,
 \quad h_R(u)=R^{-n}\mathbf1_{[-R/2,R/2]^n}(u),
 \quad a\le R(x)\le2a.
 \tag{1}
\]
`E0` 为原有限接收集，`λ|E0|≤X`。`J∈[0,1]` 固定并保留原 FULL、出生 deep、原选择及此前门，不能在迭代中改选。原实际行密度 `r0≤4λ`。例如 `μ0` 可为已单独支付容量来源后的逐叶 `ζV`；此时叶、高均值细格支撑及全部原交通门都继承。

先删除 `r0(x)≤δλ` 的接收行，实际费用不超过 `δλ|E0|`。对其余行应用固定权
\[
 w(x,z)=J(x,z)\mathbf1_{Q_x}(z)
 \tag{2}
\]
的来源一次收费剥离：来源容量按 `∫Ej w(x,z)dx` 测试，行删除按累计删除来源的 `w` 捕获占原 `w` 捕获的比例 `θ` 测试。既有加权剥离证明给
\[
 T_0\le \delta\lambda|E_0|
 +\frac{1+\sqrt n}{\theta}\mu_0(P)
 +T_{\rm core},
 \tag{3}
\]
其中 `P` 为累计删除来源，`μ=μ0|Pᶜ`，核心实际行集记为 `E`，且
\[
 \begin{split}
 &r(x):=\int J(x,z)h_{R(x)}(x-z)d\mu(z)
       >(1-\theta)\delta\lambda=:b\lambda,\qquad x\in E,\\
 &V^J_E(z):=\int_EJ(x,z)\mathbf1_{Q_x}(z)dx
       \ge a^n e^{\sqrt n}\quad\text{对存活来源几乎处处成立}.
 \end{split}
 \tag{4}
\]
`r≤4λ`。列下界在无限步只能写 `≥`；它不证明剩余集是严格不动点。`δλ|E0|` 是新增误差，不隐入此前的 `X/768`。有限性由原有限窗口 `T0≤(1+n log2)‖μ0‖` 保证。

式 (3) 引用固定 `w` 的来源剥离账，不在此重复其三角 Tonelli 证明。其重要连接是 (4) 的**实际**行、列条件同时成立。若只对无门 `1Q` 剥离，高无门接收体积不能代入含 deep 的来源储备式。

## 2. 真实共同接收核

令
\[
 g_z(x)=\mathbf1_E(x)J(x,z)h_{R(x)}(x-z),\qquad
 c(z)=\int_Eg_z(x)dx,
\]
\[
 B_J(s,z)=\int_EJ(x,z)J(x,s)h_{R(x)}(x-z)h_{R(x)}(x-s)dx.
 \tag{5}
\]
对任意有限组点及实系数，非负平方积分给
\[
 \sum_{i,j}a_i a_j B_J(z_i,z_j)
   =\int_E\left|\sum_i a_i g_{z_i}(x)\right|^2dx\ge0.
 \tag{6}
\]
这里确有相同的两端实际门，故核对称且为 Gram 核。该性质本身不提供所需总费用。(6) 只需有限和展开；后续非负核与测度积分交换使用 Tonelli。本节不调用抽象 Schur 或谱定理。

实际行下界给精确储备式
\[
 b\lambda c(z)\le
 \int B_J(s,z)d\mu(s)
 =\int_Eg_z(x)r(x)dx\le4\lambda c(z).
 \tag{7}
\]
两端共同接收核 (5) 的量纲是体积的倒数，不能与只含一个 `R⁻ⁿ` 的共同接收核混用。

## 3. 出生半径与显式几何核

原细格 `C` 边长 `d=a/n`，质量参数 `H_C=μhi(C)`，原出生半径为
\[
 t_C=\left(\frac{H_C\sqrt n}{e^2q}\right)^{1/n},\qquad
 \rho_C=\max\{a,t_Ce^{1/\sqrt n}\},\qquad 3\lambda/4\le q\le\lambda.
 \tag{8}
\]
只要 `J(x,z)>0` 且 `z∈C`，原 deep 门给 `R(x)>t_Ce^{1/√n}`。因此 (5) 的正被积项必须满足
\[
 R(x)\ge\rho_{C(z),C(s)}:=\max\{\rho_{C(z)},\rho_{C(s)}\}.
 \tag{9}
\]
若某端 `ρC≥2a`，其实际交通为零，可先删去。对 `a≤ρ<2a` 定义
\[
 L_\rho(u)=
 \frac{\prod_{i=1}^n(2a-|u_i|)_+}{(2a)^{2n}}
 +2n\int_\rho^{2a}
       \frac{\prod_{i=1}^n(r-|u_i|)_+}{r^{2n+1}}dr.
 \tag{10}
\]
则有真正的正上界
\[
 \boxed{B_J(s,z)\le L_{\rho_{C(z),C(s)}}(s-z)\le L_a(s-z).}
 \tag{11}
\]
证明用恒等式 `R⁻²ⁿ=(2a)⁻²ⁿ+2n∫R^(2a)r⁻²ⁿ⁻¹dr`，并在 `R≤r` 时用 `Q(x,R)⊂Q(x,r)`。对接收变量 `x` 积分，两点同时被全边长 `r` 的中心 cube 捕获的体积准确是 `∏i(r−|s_i−z_i|)+`。若保留实际 `E`，该乘积可进一步换成 `|E∩Q(s,r)∩Q(z,r)|`，得到更小的上界；(10) 则完全由冻结来源位置及出生标签确定。

几何核有精确质量
\[
 \boxed{\int_{\mathbb R^n}L_\rho(u)du
       =1+2n\log(2a/\rho).}
 \tag{12}
\]
因为一维三角函数 `(r−|u|)+` 的积分为 `r²`。特别 `‖La‖1=1+2n log2`，没有免费根阶改善。

## 4. 异细格的无误差来源付款

记
\[
 d_n=\frac{q}{\lambda}\frac{e^2e^{-\sqrt n}}{\sqrt n}.
 \tag{13}
\]
在 `g_z(x)>0` 的实际行上，`z∈C` 的原 deep 门给
\[
 \frac{\mu(C)}{R(x)^n}\le\frac{H_C}{R(x)^n}<d_n\lambda.
 \tag{14}
\]
从 (5) 得
\[
 \int_{C(z)}B_J(s,z)d\mu(s)
 \le\int_Eg_z(x)\frac{\mu(C(z))}{R(x)^n}dx
 \le d_n\lambda c(z).
 \tag{15}
\]
此处只在 `g_z>0` 时使用 deep；不对所有无门 receiver 强加 (14)。结合 (7)，若 `b>d_n`，则
\[
 \boxed{(b-d_n)\lambda c(z)
 \le\int_{C(z)^c}B_J(s,z)d\mu(s)
 \le\kappa_\mu(z),}
 \tag{16}
\]
其中冻结几何势为
\[
 \kappa_\mu(z)=\int_{C(z)^c}
 L_{\rho_{C(z),C(s)}}(s-z)d\mu(s).
 \tag{17}
\]
对任意来源可测集 `A`，其原实际子交通 `TA=∫A c(z)dμ(z)` 因而满足
\[
 \boxed{T_A\le\frac1{(b-d_n)\lambda}
                     \int_A\kappa_\mu(z)d\mu(z).}
 \tag{18}
\]
特别给定固定 `K>0`，取
\[
 A_K=\{z:\kappa_\mu(z)\le K\lambda\sqrt n\},
\]
就得到
\[
 \boxed{T_{A_K}\le\frac K{b-d_n}\sqrt n\,\mu(A_K).}
 \tag{19}
\]
这是实际整个来源子交通的付款，没有新增 `X` 费，没有来源数、细格数、叶数或尺度层数因子。它不要求来源有点态密度上界，格内尖峰允许任意高。势 (17) 不含当前 receiver 变量；筛选可在后续 receiver 积分之前冻结。

一个可直接采用的参数是 `θ=1/2, δ=β/4, b=β/8`，`β=1/6144`。对 `n≥512`，`√n>16` 及 `e>2` 给
\[
 d_n<e^{-14}/16<2^{-18}<\beta/16,
 \tag{20}
\]
故 (19) 的系数可取 `16K/β`。加权剥离新增的低行费用为 `βX/4`，须与既有误差完整相加。

若对不同叶和种子使用 (19)，在各自真实不交来源上付款后求和即可；不能先合并来源测度再假称仍有同一个局部势界。若改用原冻结 `μ0` 替代 (17) 中的 `μ≤μ0`，正性给更强但同样有效的预冻结充分条件。

## 5. 统一迭代与列价证书

上述几何付款可与 (2) 的来源剥离放在同一轮迭代中，避免反复降低行下界。设 `μi=μ0|Fi`，`Ei` 为当前接收集，所有行删除均仍按**累计**删除来源相对原 `w` 捕获的比例 `θ` 判断。则每一步在 `Ei` 上都有 `ri≥bλ`，其中固定 `b=(1−θ)δ`。

用 `(μi,Ei)` 定义 `ci,Bi`，以及实际异细格势
\[
 k_i(z)=\int_{C(z)^c}B_i(s,z)d\mu_i(s).
 \tag{21}
\]
可把删除条件取为
\[
 V_i^J(z)\le a^ne^{\sqrt n}
 \quad\text{或}\quad
 k_i(z)\le A\lambda\sqrt n.
 \tag{22}
\]
由列容量与 (16)，每个此轮被删来源在删除前的真实列价至多
\[
 C_n=\max\left\{1+\sqrt n,\frac{A\sqrt n}{b-d_n}\right\}.
 \tag{23}
\]
故同一个来源一次收费证明给全部层的预算
\[
 \boxed{T_0\le\delta\lambda|E_0|
       +\frac{C_n}{\theta}\mu_0(P)+T_\infty.}
 \tag{24}
\]
没有迭代层数因子。若改用由 `μi` 定义的几何上界势 `κi` 作为 (22) 第二个测试，同一结论也成立。

极限 `μ∞,E∞` 保留原同一个门 `J`，且
\[
 r_\infty\ge b\lambda,\qquad
 V_\infty^J\ge a^ne^{\sqrt n},\qquad
 k_\infty\ge A\lambda\sqrt n
 \tag{25}
\]
（几何势测试对应最后一式为 `κ∞≥Aλ√n`）。这些是几乎处处的非严格下界。`Ei,Fi` 双双递减，且
\[
 0\le L_a(u)\le(2-2^{-n})a^{-n},
\]
所以有限 `μ0` 给统一可积支配，核与来源积分的极限合法。来源仍受原固定高细格集合 `S_V` 承载；**不能**据此声称当前 `μ∞(C)` 仍高于原容量，或重新按当前质量生成同一个 `S_V`。

还应明确这一统一筛选的证据地位：直接删除 `ci(z)≤Cn` 的来源，是同一列价预算下更强且更简洁的规则。(22) 的两种条件都只是这个列价上界的充分证书。对直接列价剥离，(24) 仍成立，并且极限满足 `c∞≥Cn`；由 (16) 自动有 `k∞≥(b−dn)λCn`。若 `1≤Cn≤Hn`，列容量还给
\[
 V_\infty^J\ge a^n e^{C_n-1}.
 \tag{26}
\]
若 `Cn>Hn=1+n log2`，全部来源已在第一次列价筛选中删除。这里没有新的几何定理：真正的几何任务仍是证明高实际列价核心不能承担过多总交通。

## 6. 总预算边界与尚缺的几何结论

上述结论能支付具有小异细格相互作用势的实际来源。对于一般核心，(12) 只给几何核的 Lebesgue 总质量，不能把叶平均 `μ(V)/|V|≲λ/√n` 填成全空间点态密度。来源支撑在体积小的细格并中，也不控制按 `dμ` 加权的势积分。因此本节没有推出
\[
 \int\kappa_\mu(z)d\mu(z)\lesssim\lambda\sqrt n\,\|\mu\|,
 \tag{27}
\]
也没有证明 (19) 的来源占核心质量的统一比例。式 (27) 若成立确能闭合本核心，但当前不能把它当作假设免费使用。

可复用的实质接口是：(4) 已把原深门与双侧可见性合法联结；(10)–(12) 给精确几何核及维数价格；(16)–(19) 把同来源的异细格储备变成无需新误差的实际来源付款；(24) 给统一累计行删除下的全部层预算。相互作用高的来源核心仍未付，原 `Hn‖μ∞‖` 包络须保留。不能从正核、固定高格支撑或 (24) 的迭代形式推出一般终端已获根阶费用。

## fullgate

本节始终恢复原软端与唯一 LCA，再作软端积分。得到的禁止同块约束比 `G≤1` 强，并对后续来源截顶、细格余量及来源—接收剥离保留；但尚未由此证明饱和核心的根阶费用。本节不增加一笔已付费用，也不把剩余项改称已解决。

## 1. 同一原后验与合法的父组恢复

冻结原输入、原森林种子 `θ` 以及接收点 `x`。原 `σ(x),L_s(x),R(x),q` 对所有软来源和历史共同使用。置

\[
 ds_x(y)=q^{-1}P_{\sigma(x),L_s(x)}(x-y)d\mu_{\rm hi}(y),
 \qquad s_x(A)=\int_A ds_x\le1,
\]
\[
 h(A)=\mu_{\rm hi}(A\cap\mathcal B),\qquad
 \mathcal B=\{t_C\le b\}.
 \tag{F1}
\]

`s_x` 为原完整软概率的子测度，未给高来源重新归一化。原 `S_core(x,z)/q` 来自原初始软来源 `y`、首跳、完整 continuation 及全部门的正积分；在这个精确联合测度内乘 `1_{LCA(y,z)=P}` 才是父组分量。它不是在积分后的 `G` 中选取一个新父组。

固定 `x,z,θ`，删除历史和其它接受门后，原软来源边际由 `s_x` 支配。所有接受对仍须同顶格，且在唯一 LCA 的不同孩子内。后文只对这个未作参考放大的原表示取正上界。

因此，原共同重捕获 `s_x(P)>τ`，`τ=49/32768`，确实给每一父层的活跃父组数 `<1/τ`；全森林至多 `J/τ`。这是同一 `s_x` 对每层不交父格的质量预算，不是把不同历史各自的活跃标签数相加。该计数本身没有全空间来源费用。

## 2. 严格 CP/GP 产生的禁止同块分区

记原软度带为 `j=j(σ(x))`，原严格门的共同质量阈值为

\[
 H_x=\max\left\{
 \frac{q\min(L_s,R)^n\sqrt n}{v_j},
 q(L_sR)^{n/2}\right\},\qquad v_j>0.
 \tag{F2}
\]

原接受父组必有 `h(P)>H_x`。在原有限深度森林中，取所有满足 `h(A)≤H_x` 的最粗节点；它们构成反链。再加入未被这些节点覆盖的全部最细格，得到整个来源空间的半开分区 `𝒜_x`。若一个顶格已轻，则它本身就是分区成员。最细格可以重；加入它是利用 distinct-child LCA，绝不是冒称其质量轻。

令 `A_x(z)` 为唯一包含 `z` 的分区块，`T(z)` 为原顶格。分区依 `x` 的原阈值而变，仅用于逐行约束，不被当成接收点之前冻结的来源分包。

**命题。** 任意原 FULL 接受对 `(y,z)` 满足

\[
 y\in T(z)\setminus A_x(z).
 \tag{F3}
\]

证明分两类。若 `A_x(z)` 为轻节点，同块两端若有 distinct-child LCA `P`，则 `P⊂A_x(z)`，所以 `h(P)≤h(A_x(z))≤H_x`，与 (F2) 的严格补集矛盾。若两端同处最细格，则根本不存在允许的 distinct-child LCA。重最细补块也由后一理由排除。同顶格条件给其余包含关系。等号 `h=H_x` 属已付门，故不留下端点漏洞。

于是对于原规范表示中的接收系数，以及只在它上面增加 `[0,1]` 门的任意子交通，逐 `x,z,θ` 有

\[
 \boxed{0\le G(x,z,\theta)
 \le s_x(T(z))-s_x(A_x(z))
 \le1-s_x(A_x(z)).}
 \tag{F4}
\]

证明先在原联合测度内应用 (F3)，再用软边际支配；无需将未积分历史密度比视作概率。不同 LCA 的 sibling 区域本来不交，因此这里没有标签数因子。原失败币、lowS、owntrace、early 及其它门仍在左侧，只有为取上界时删除它们。

## 3. 对任意真实硬子源的行缺口

令 `ν≤μ_hi` 为接收点之前冻结的真实硬子源；允许它还依原种子及独立新格种子而定。取规范原 `G` 的子门 `J≤G`，写

\[
 b_A(x)=\nu(A\cap Q(x,R)),\quad b(x)=\sum_{A\in\mathcal A_x}b_A(x),
 \quad r(x)=\int J(x,z)h_R(x-z)d\nu(z).
 \tag{F5}
\]

把 (F4) 逐来源积分，得到

\[
 \boxed{
 r(x)\le\frac1{R^n}\sum_A
 [s_x(T_A)-s_x(A)]b_A
 \le\frac b{R^n}-\frac1{R^n}\sum_A s_x(A)b_A.}
 \tag{F6}
\]

`T_A` 是包含 `A` 的原顶格。没有把原 `h(A)` 换成 `ν(A)`，也没有把完整硬行下界搬给 `ν`。

在原 `L_s≥R` 分支，张量软核的无软化项给

\[
 P_{\sigma,L_s}(x-y)
 \ge(1-\sigma)^nL_s^{-n}\mathbf1_{Q(x,R)}(y),
\]

故 `ν≤μ_hi` 蕴含 `s_x(A)≥(1−σ)^n b_A/(qL_s^n)`。代回 (F6)：

\[
 \boxed{r(x)\le\frac b{R^n}
 -\frac{(1-\sigma)^n}{qL_s^nR^n}\sum_A b_A(x)^2.}
 \tag{F7}
\]

一般两尺度可保留准确交集量 `b_A^∩=ν(A∩Q_R∩Q_{L_s})`，把 (F7) 的平方和换成 `Σ_A b_A^∩b_A`。该量非负，但不能在 `L_s<R` 时免费替换成 `Σb_A²`。

## 4. 接入实际核心后仍需支付什么

对任何原子交通的来源限制与接收限制，(F4)–(F7) 继续成立；特别包括保持原系数的 finecell excess 与来源—接收剥离核心。若更换表示时曾将来源质量乘小系数、同时把系数除以该数放大，则不能仅凭新 `J≤1` 自动继承 (F4)；须回到原规范表示核验。这里未使用这种倒数放大。

对固定真实来源 `z` 定义核心列价

\[
 c(z)=\int_E J(x,z)h_{R(x)}(x-z)dx,
\]
\[
 D(z)=\int_E s_x(A_x(z))h_{R(x)}(x-z)dx.
\]

由 (F4) 和有限窗口包络，

\[
 \boxed{c(z)+D(z)
 \le\int_Es_x(T(z))h_R(x-z)dx
 \le H_n=1+n\log(b/a).}
 \tag{F8}
\]

这保留了 FULL 的共同软来源缺口，而不是仅给自由列帽 `H_n`。但已知核心条件 `c(z)≥1+√n`、`r(x)≥b_*λ` 并不要求单行 `J(x,z)` 接近一。它们尚未给 `D(z)≥H_n−O(√n)`，也未给这种强点态下界的来源加权替代。

所以真正待付的量仍为原核心的

\[
 T_{\rm core}=\mathbb E\int_{Z_{\rm core}}c(z)d\nu(z),
 \qquad c(z)\ge1+\sqrt n\quad\nu\hbox{-a.e. on }Z_{\rm core}.
 \tag{F9}
\]

本节没有证明 (F9) 的根阶来源费或统一可吸收收缩。`𝒜_x` 的标签随接收点改变，不能对它们逐块领取来源一次费用；(F7) 的因子还必须保留 `(1−σ)^n(R/L_s)^n` 及有效捕获块数。原 fullfuture 上限没有自动变成这些缺口的全空间下界。对 (F8) 的逐点或来源加权估计仍是实质缺口，而非省略的代数步骤。

## integration

本轮将原中间段分解为首次停止来源、逐叶细格容量来源、可按真实列价剥离的来源及一个保留全部原门的核心。关键补步是显式支付容量来源在少数捕获行上的交通，之后才把剩余交通的来源改为超容量部分。新增误差和树吸收系数全部保留；一般核心的根阶上界尚未证明。

## 1. 共同对象与已有账

固定原有限接收集 \(E\)，\(X=\lambda|E|\)，维数在原 FULL 范围 \(n\ge512\)。沿用
\[
 \beta=1/6144,\quad b_0=\beta/2,\quad
 H_n=1+n\log2,\quad
 A_n=1+\sqrt n+\log(4/b_0^2),
\]
\[
 B_{105}=2+3\sqrt n+\log(16/\beta^2).
 \tag{I1}
\]
上一轮已证
\[
 R_{\rm out}\le P_{104}+B_{105}W_\mu+X/768+T_{\rm mid}.
 \tag{I2}
\]
\(P_{104}\) 保持既有明确根对数价格；这里没有改写或重新收费该模块。令 \(\sigma_\omega\) 为原走廊删除后 \(\mu'_\omega\) 限制到未付中间质量 canonical 盒并的冻结来源，
\[
 W_{\rm tree}=\mathbb E_\omega\|\sigma_\omega\|\le W_\mu.
\]
原 \(T_{\rm mid}\) 使用同一个 \(f\)、\(dx\)、\(a\le R(x)\le2a\)、\(2\lambda<A_Rf(x)\le4\lambda\) 和所有原门 \(G_0(x,z,\omega)\in[0,1]\)。来源不吸收依赖 \(x\) 的出生 deep 门。

## 2. 独立树的准确终端

采用密度停时树的独立平移 \(\xi\)，取最细叶边长 \(s_*=16na\)。其最细跨边界事件概率至多 \(1/8\)，同时覆盖所有祖先层；首次轻停止和密度停止的来源合计质量为 \(W_{\rm stop}\)。树的已证交通账为
\[
 \boxed{\frac78T_{\rm mid}\le A_nW_{\rm stop}+T_{\rm term}.}
 \tag{I3}
\]
固定 \(\alpha=(\omega,\xi)\)，记终端叶为 \(V\)，\(\mu_V=\sigma_\omega|_V\)、\(m_V=\|\mu_V\|\)。对每个叶定义其好终端接收集 \(E_V\subset E\)：原 winner \(Q_x\) 整体属于唯一该叶，且满足原终端行资格。每个样本中这些 \(E_V\) 两两不交，
\[
 \sum_V|E_V|\le|E|,\qquad
 Q_x\subset V,\qquad
 \mu_V(Q_x)=\sigma_\omega(Q_x)\ge b_0\lambda R(x)^n\quad(x\in E_V).
 \tag{I4}
\]
终端来源有
\[
 \lambda a^ne^{\sqrt n}<m_V<\frac{4\lambda(s_*+2a)^n}{\sqrt n},
 \qquad \frac{m_V}{|V|}<\frac{4e^{1/8}\lambda}{\sqrt n}.
 \tag{I5}
\]
这里低均值不是点态密度上界。设原行密度
\[
 r_V(x)=\int G_0(x,z,\omega)h_{R(x)}(x-z)d\mu_V(z),
 \qquad 0\le r_V\le4\lambda,
\]
则真实终端准确为
\[
 T_{\rm term}=\mathbb E_\alpha\sum_V\int_{E_V}r_V(x)dx.
 \tag{I6}
\]
每个 \(\mu_V\) 与叶标签均在当前 receiver 积分之前冻结，全部原门仍留在被积函数中。

## 3. 逐叶容量与多数行付款

令原出生细格边长 \(d=a/n\)，容量密度 \(\tau=\sqrt n\lambda\)。对每个叶和原细格定义
\[
 m_{V,C}=\mu_V(C),\qquad
 t_{V,C}=\begin{cases}\min\{1,\tau d^n/m_{V,C}\},&m_{V,C}>0,\\1,&m_{V,C}=0,\end{cases}
\]
\[
 d\eta_V(z)=t_{V,C(z)}d\mu_V(z),\qquad
 \zeta_V=\mu_V-\eta_V,\qquad
 W_{\rm cap}=\mathbb E_\alpha\sum_V\|\eta_V\|.
 \tag{I7}
\]
细格可以跨叶边界，故这里质量是 \(\sigma(C\cap V)\)，不是把全局 \(\sigma(C)\) 对每个叶重复使用。来源有准确正测度分解 \(\mu_V=\eta_V+\zeta_V\)。两部分可以在同一点同时有正密度，因此下文的来源分区是质量分账，不主张它们的空间支撑互不相交。

将 \(E_V\) 分成
\[
 U_V=\{x\in E_V:\eta_V(Q_x)\ge\mu_V(Q_x)/2\},\qquad
 M_V=E_V\setminus U_V.
 \tag{I8}
\]
逐叶容量的已证整行价格为
\[
 T_{\rm maj}:=\mathbb E_\alpha\sum_V\int_{U_V}r_Vdx
 \le C_{\rm cell}\sqrt n\,W_{\rm cap},\qquad
 C_{\rm cell}=\frac{64e^4C_2^2}{\beta^2},
 \tag{I9}
\]
其中 \(C_2\) 是固定 \(p=2\) 中心 cube maximal 的维数一致强型常数。简述连接：均匀化
\[
 s_V(y)=\sum_C\frac{\eta_V(C)}{d^n}\mathbf1_C(y),\quad
 0\le s_V\le\tau,\quad \|s_V\|_2^2\le\tau\|\eta_V\|
 \tag{I10}
\]
保留逐格质量，位移至多 \(d\)，故
\[
 A_R\eta_V(x)\le(1+2d/R)^n A_{R+2d}s_V(x)\le e^2Ms_V(x).
 \tag{I11}
\]
在 \(U_V\) 上 \(A_R\eta_V\ge\beta\lambda/4\)，强 \(L^2\) 测度界再乘原 \(4\lambda\) 行帽即得 (I9)。该费用支付 \(U_V\) 上以原 \(\mu_V\) 积分的整行；没有重定义原门。

## 4. 少数行必须先拆来源，再付容量交通

原未付少数行量仍以 \(\mu_V\) 积分：
\[
 T_{\rm min}=\mathbb E_\alpha\sum_V\int_{M_V}\int
 G_0h_R\,d\mu_V\,dx.
\]
因此只能在使用 (I7) 后精确写为
\[
 T_{\rm term}=T_{\rm maj}+T_{\eta,\rm min}+T_{\zeta,\rm min},
 \tag{I12}
\]
其中后两项分别把来源换成 \(\eta_V\)、\(\zeta_V\)，接收集均是原 \(M_V\)，原 \(G_0,h_R\) 不变。单有
\[
 \zeta_V(Q_x)>\mu_V(Q_x)/2\ge\beta\lambda R(x)^n/4
 \quad(x\in M_V)
 \tag{I13}
\]
不足以省去 \(T_{\eta,\rm min}\)。

由 (I11)，逐叶有
\[
 \int_{M_V}\int G_0h_R\,d\eta_V\,dx
 \le e^2\int_{M_V}Ms_Vdx
 \le e^2C_2\sqrt{\tau\|\eta_V\||M_V|}.
 \tag{I14}
\]
先在同一样本中对叶用 Cauchy–Schwarz，利用 \(M_V\subset E_V\) 的互不相交性，再对概率平均用 Cauchy–Schwarz，得到
\[
\begin{aligned}
 T_{\eta,\rm min}
 &\le e^2C_2\sqrt\tau\,
 \mathbb E_\alpha\sqrt{
       \left(\sum_V\|\eta_V\|\right)
       \left(\sum_V|M_V|\right)}\\
 &\le e^2C_2\sqrt{\tau W_{\rm cap}|E|}
 =e^2C_2\sqrt{\sqrt n\,W_{\rm cap}X}.
\end{aligned}
 \tag{I15}
\]
这一步没有合并 \(s_V\) 后宣称总密度受 \(\tau\) 控制；不同均匀化目标确可在跨叶细格上重叠。无叶数因子来自真实接收集互不相交和来源总质量加性。

对任意保留为符号的 \(\varepsilon>0\)，Young 不等式给
\[
 \boxed{T_{\eta,\rm min}
 \le\frac{e^4C_2^2}{4\varepsilon}\sqrt n\,W_{\rm cap}
       +\varepsilon X.}
 \tag{I16}
\]
合并多数与少数行费用，应定义
\[
 K_{\rm cap}(\varepsilon)=C_{\rm cell}+\frac{e^4C_2^2}{4\varepsilon}
 \tag{I17}
\]
并得到
\[
 T_{\rm term}\le K_{\rm cap}(\varepsilon)\sqrt n\,W_{\rm cap}
                  +\varepsilon X+T_{\zeta,\rm min}.
 \tag{I18}
\]
(I9) 与 (I16) 使用同一 \(W_{\rm cap}\)，其系数必须相加，不能取最大值。只有到 (I18) 才能合法地把全部未付来源写成 \(\zeta_V\)。

## 5. 对真实超容量交通统一剥离

对固定 \(\alpha,V\)，将列价定理应用于
\[
 E^{\rm in}=M_V,\quad\mu_0=\zeta_V,\quad J=G_0,
 \quad C_n=1+\sqrt n,\quad\theta=1/2,
 \tag{I19}
\]
其中 \(G_0\) 在 \(M_V\) 上包括全部继承的行、来源与出生门。低行测试使用真实 \(\zeta_V\) 交通
\[
 r_{\zeta,V}(x)=\int G_0h_R\,d\zeta_V,
\]
而不是把 (I13) 的无门捕获当成含 deep 的行下界。取任意 \(\delta>0\)，先删 \(r_{\zeta,V}\le\delta\lambda\) 的行，再按同一原 \(J\) 删低列价全集，并按累计删除来源占原 \(J\) 捕获的比例 \(1/2\) 删行。

所得删除来源 \(\zeta_V|_{P_V}\) 与核心 \(\mu_{\infty,V}=\zeta_V|_{P_V^c}\) 的平均质量记为
\[
 W_{\rm removed}=\mathbb E_\alpha\sum_V\zeta_V(P_V),\qquad
 W_{\rm core}=\mathbb E_\alpha\sum_V\|\mu_{\infty,V}\|.
 \tag{I20}
\]
核心接收集 \(E_{\infty,V}\subset M_V\)，实际交通为
\[
 T_{\rm core}=\mathbb E_\alpha\sum_V\int_{E_{\infty,V}}
                  \int G_0(x,z,\omega)h_{R(x)}(x-z)d\mu_{\infty,V}(z)dx.
 \tag{I21}
\]
由各叶接收集不交，低行费合计至多 \(\delta X\)。三角计费按每份被删来源只收一次，故
\[
 \boxed{T_{\zeta,\rm min}\le
 \delta X+2(1+\sqrt n)W_{\rm removed}+T_{\rm core}.}
 \tag{I22}
\]
这一步沿用同一个 \(dx,R,G_0\)；不为核心重跑 FIRST 或出生测试。逐叶核心满足
\[
 r_{\infty,V}(x)>\delta\lambda/2\quad(x\in E_{\infty,V}),
 \qquad c_{\infty,V}(z)\ge1+\sqrt n,
 \tag{I23}
\]
\[
 \int_{E_{\infty,V}}G_0(x,z,\omega)\mathbf1_{Q_x}(z)dx
 \ge a^ne^{\sqrt n}
 \quad\text{对存活来源几乎处处成立}.
 \tag{I24}
\]
无限步列下界只有非严格 \(\ge\)。此外
\[
 \boxed{T_{\rm core}\le H_nW_{\rm core}.}
 \tag{I25}
\]
该包络是保留的未付一般终端，不能改称根阶价格。

核心仍位于原终端叶，受固定高均值细格并
\[
 S_V=\bigcup_{C:m_{V,C}>\sqrt n\lambda d^n}C,\qquad
 |S_V|\le\frac{m_V}{\sqrt n\lambda}
          <\frac{4e^{1/8}}n|V|
 \tag{I26}
\]
承载，并且 \(\mu_{\infty,V}\le\zeta_V\le\mu_V\le\mu_{\rm hi}\)。不能据此要求剥离后的 \(\mu_{\infty,V}(C)\) 仍超过容量，也不能把 (I13) 的阈值传给核心来源；合法保留的是 (I23) 的实际行下界及原固定门。

## 6. 统一来源账与最终主式

树停止来源与终端叶先按空间不交分解，随后每叶按 \(\mu_V=\eta_V+\zeta_V\) 分解，再把 \(\zeta_V\) 分成删除与存活部分。因此有准确质量账
\[
 \boxed{W_{\rm stop}+W_{\rm cap}+W_{\rm removed}+W_{\rm core}
        =W_{\rm tree}\le W_\mu.}
 \tag{I27}
\]
即使 \(\eta_V\)、\(\zeta_V\) 支撑重叠，这个加性正测度恒等式仍成立。由 (I3)、(I18)、(I22)，
\[
 \boxed{
 T_{\rm mid}\le\frac87\left[
 A_nW_{\rm stop}
 +K_{\rm cap}(\varepsilon)\sqrt n\,W_{\rm cap}
 +2(1+\sqrt n)W_{\rm removed}
 +(\varepsilon+\delta)X+T_{\rm core}\right].}
 \tag{I28}
\]
不同质量类别可共享最大系数。具体令
\[
 K_n(\varepsilon)=\max\{A_n,
 K_{\rm cap}(\varepsilon)\sqrt n,2(1+\sqrt n)\},
\]
则
\[
 T_{\rm mid}\le\frac87\left[
 K_n(\varepsilon)(W_{\rm tree}-W_{\rm core})
 +(\varepsilon+\delta)X+T_{\rm core}\right].
 \tag{I29}
\]
若只求有限包络，可再使用 (I25)，保持 \(H_nW_{\rm core}\) 的维数代价；不把它隐藏进根阶 \(K_n\)。

代回原主式，得到
\[
\boxed{
\begin{aligned}
 R_{\rm out}\le{}&P_{104}+B_{105}W_\mu
   +\left[\frac1{768}+\frac87(\varepsilon+\delta)\right]X\\
 &+\frac87\left[
 A_nW_{\rm stop}+K_{\rm cap}(\varepsilon)\sqrt nW_{\rm cap}
 +2(1+\sqrt n)W_{\rm removed}+T_{\rm core}\right].
\end{aligned}}
 \tag{I30}
\]
\(8/7\) 只吸收本轮原中间段的跨格交通；它乘所有树之后新费用和 \((\varepsilon+\delta)X\)，不乘旧 \(P_{104}\)、\(B_{105}W_\mu\) 或 \(X/768\)。旧来源费与本轮费用可能使用同一来源，必须相加。

## 7. 已付款范围与未付责任

(I30) 实际支付：首次停止的轻质量/高密度节点；容量来源承担至少半数捕获的整行；互补行中容量来源本身；以及在固定实际门下可统一剥离的低列价来源和其触发的行。有限树、原细格及剥离轮数均未进入价格。所有随机量先在同一 \((\omega,\xi)\) 中定义再积分，没有选有利平移。

剩余核心具有完整赢家落在低均值 \(16na\) 叶、固定小体积高均值细格支撑、原 deep 标签、正实际行和高实际列价这些共同约束。原 deep 还给同格贡献小及双端实际 Gram 核的异格储备；这些必要限制或低相互作用充分证书本身尚未证明一般核心获根阶付款。特别不能把低叶均值代入点态密度估计，也不能由正半定性免费推出跨格总预算。当前一般结论保留 (I21)、(I25)，不宣称一般 \(n^{1/2+o(1)}\) 上界已经闭合。


## 8. 本轮采用的增强顺序：先删最大细格，再剥离重尾

前述 (I19)–(I30) 是不使用出生排序的基础方案。现在保留共同的 (I1)–(I18)，用本节替代基础方案的剥离输入和总账；两条方案是替代关系，不把两笔低行误差叠加。

固定整数 \(k\ge0\) 及 \(0<\delta'\le1\)。在每个叶中按冻结超容量来源 \(\zeta_V(C)\) 的质量大小，选择至多 \(k\) 个最大正质量原出生细格，等质量按固定编号破并列；定义
\[
 \zeta_V^{\rm top}=\zeta_V\big|_{\text{所选细格并}},\qquad
 \rho_V=\zeta_V-\zeta_V^{\rm top},\qquad
 m_V^{\rm tail}=\|\rho_V\|,
 \tag{I31}
\]
\[
 W_{\rm top}=\mathbb E_\alpha\sum_V\|\zeta_V^{\rm top}\|,
 \qquad \kappa_n=e^2e^{-\sqrt n}/\sqrt n.
\]
所选对象是原细格在该叶中的来源片，质量并非原 \(H_C\)，也不依当前 receiver。有限总质量下，可数正格质量的正上确界总能达到：大于其一半的格只有有限个。依次选达到最大值的最小编号，有限重复 \(k\) 次，得到可测选择。这与有限截断的原细格库相容。

原 deep 门保证任一出生格的实际行贡献至多 \(\kappa_n\lambda\)。每个 \(x\in M_V\) 只见唯一叶 \(V\)，故
\[
 T_{{\rm top},\rm min}
 :=\mathbb E_\alpha\sum_V\int_{M_V}\int G_0h_Rd\zeta_V^{\rm top}dx
 \le k\kappa_n\lambda\mathbb E_\alpha\sum_V|M_V|
 \le k\kappa_nX.
 \tag{I32}
\]
原出生标签 \(H_C,t_C,q\) 与 \(G_0\) 不重算。来源质量再大也只在其实际深门允许贡献时使用单格行帽；此处未放大核，也没有来源数或叶数费用。

以同一实际门定义剩余尾行
\[
 r_{{\rm tail},V}(x)=\int G_0(x,z,\omega)h_{R(x)}(x-z)d\rho_V(z),
 \quad H_V=\{x\in M_V:r_{{\rm tail},V}(x)>\delta'\lambda\}.
 \tag{I33}
\]
所有叶低尾行的尾交通合计至多 \(\delta'X\)。这份低行付款发生在 top 来源支付后，因而只需支付尾交通。余下高行具有真正的同门行下界，并且
\[
 \delta'\lambda<r_{{\rm tail},V}(x)
 \le R(x)^{-n}\rho_V(Q_x)\le R(x)^{-n}m_V^{\rm tail}.
 \tag{I34}
\]

令 \(M_*=\lambda a^ne^{\sqrt n}\)，将叶按尾质量分成
\[
 \mathcal L_k=\{V:m_V^{\rm tail}\le M_*\},\qquad
 \mathcal D_k=\{V:m_V^{\rm tail}>M_*\},\qquad
 W_{\rm tail,light}=\mathbb E_\alpha\sum_{V\in\mathcal L_k}m_V^{\rm tail}.
 \tag{I35}
\]
对轻尾高行，(I34) 将原半径限制在预冻结窗口
\[
 a\le R(x)\le r_V^+
 :=\min\{2a,(m_V^{\rm tail}/(\delta'\lambda))^{1/n}\}.
\]
若 \(m_V^{\rm tail}<\delta'\lambda a^n\)，高行为空。其余窗口的正包络积分为
\[
 \int\sup_{a\le r\le r_V^+}h_r(u)du=1+n\log(r_V^+/a).
\]
这是将 \(u_*=2\|u\|_\infty\) 分为 \(u_*\le a\)、\(a<u_*\le r_V^+\) 两段直接积分，得到 \(1+\int_a^{r_V^+}nr^{-1}dr\)。由此每份轻尾来源只收一次价格
\[
 A_n^{\rm tail}(\delta')
 =1+\min\{n\log2,\sqrt n+\log(1/\delta')\},
\]
\[
 T_{{\rm tail},\rm light,high}
 \le A_n^{\rm tail}(\delta')W_{\rm tail,light}.
 \tag{I36}
\]
特别，原 \(\mu_V\) 仍重而删去最大细格后尾质量变轻的叶，其 \(\zeta\) 交通已全部进入 (I32)、低尾行费和 (I36) 的已付分支。

对重尾叶 \(V\in\mathcal D_k\)，从输入
\[
 \mu_0=\rho_V,\qquad E_0=H_V,\qquad J=G_0,\qquad
 C_n=1+\sqrt n,\quad\theta=1/2
 \tag{I37}
\]
开始统一列价剥离。输入全部满足 \(r_0>\delta'\lambda\)，因此 capacity 定理的初始低行集合为空。这里没有在 (I33) 与 (I37) 之间改变来源、门或行下界，故不再加基础方案的 \(\delta X\)，也不再加第二个 \(\delta'X\)。轻尾和重尾是按叶标签分流；在重尾叶中仍是完整同一 \(\rho_V\)。

令该剥离所删与存活来源质量分别为 \(W_{\rm removed}^{(k)}\)、\(W_{\rm core}^{(k)}\)，实际余项为 \(T_{\rm core}^{(k)}\)。逐叶具体定义仍是 (I20)–(I21)，只将来源输入改为 \(\rho_V\)、接收输入改为 \(H_V\)、叶范围改为 \(\mathcal D_k\)，使用此次递归得到的删除集和极限行集。则
\[
 T_{\zeta,\rm min}\le(k\kappa_n+\delta')X
 +A_n^{\rm tail}(\delta')W_{\rm tail,light}
 +2(1+\sqrt n)W_{\rm removed}^{(k)}+T_{\rm core}^{(k)}.
 \tag{I38}
\]
核心仍按原同一个 \(G_0,h_R,dx\) 积分，满足
\[
 r_{\rm core}^{(k)}>\delta'\lambda/2,\qquad
 c_{\rm core}^{(k)}\ge1+\sqrt n,\qquad
 V_{\rm core}^{J,(k)}\ge a^ne^{\sqrt n},\qquad
 T_{\rm core}^{(k)}\le H_nW_{\rm core}^{(k)}.
 \tag{I39}
\]
这些条件作用于相应实际行或来源几乎处处。重尾资格 \(m_V^{\rm tail}>M_*\) 是剥离前冻结尾源的标签；不声称剥离后核心质量仍大于 \(M_*\)。

完整质量账现在是
\[
 \boxed{W_{\rm stop}+W_{\rm cap}+W_{\rm top}
 +W_{\rm tail,light}+W_{\rm removed}^{(k)}+W_{\rm core}^{(k)}
 =W_{\rm tree}\le W_\mu.}
 \tag{I40}
\]
\(W_{\rm top}\) 不能丢失。它的来源价格是零，是因为对应实际交通已经由 (I32) 的 \(X\) 费用支付；不是声称该来源质量为零。此处所有类别均为同一原正测度的加性分账，包括容量来源的分数分解。

本轮最终采用的增强总式为
\[
\boxed{
\begin{aligned}
 R_{\rm out}\le{}&P_{104}+B_{105}W_\mu
 +\left[\frac1{768}+\frac87(\varepsilon+\delta'+k\kappa_n)\right]X\\
 &+\frac87\big[
 A_nW_{\rm stop}
 +K_{\rm cap}(\varepsilon)\sqrt n\,W_{\rm cap}
 +A_n^{\rm tail}(\delta')W_{\rm tail,light}\\
 &\hspace{40mm}+2(1+\sqrt n)W_{\rm removed}^{(k)}
 +T_{\rm core}^{(k)}\big].
\end{aligned}}
 \tag{I41}
\]
\(\varepsilon>0\)、\(0<\delta'\le1\) 与有限整数 \(k\ge0\) 均显式保留。式 (I41) 替代 (I30)，不与其相加。树后 Young、低尾行及最大细格删除三份新增误差全部乘 \(8/7\)，旧三项保持原位。

若需要共享来源系数，令
\[
 K_n^{(k)}(\varepsilon,\delta')=
 \max\{A_n,K_{\rm cap}(\varepsilon)\sqrt n,
        A_n^{\rm tail}(\delta'),2(1+\sqrt n)\}.
\]
(I41) 方括号内的已付来源部分至多
\[
 K_n^{(k)}(\varepsilon,\delta')
 \big(W_{\rm tree}-W_{\rm top}-W_{\rm core}^{(k)}\big).
 \tag{I42}
\]
这次最大值用于不同来源质量类别；(I17) 中多数与少数行的容量系数仍必须先相加。

最后，记 \(b_V=\sup_C\rho_V(C)\)。原排序给
\[
 kb_V\le\|\zeta_V^{\rm top}\|,\qquad
 (k+1)b_V\le\|\zeta_V\|.
 \tag{I43}
\]
这些是对冻结尾源的准确附加限制，连同原低均值叶、高格支撑和原出生门均可供后续几何估计使用。它们没有保证全部重尾消失，也未给出一般核心的根阶交通上界；最终一般终端仍完整保留为 (I39) 的 \(H_nW_{\rm core}^{(k)}\)。

## Scope and common exact conventions

Three newly constructed, public, non-atomic compactly supported L1 inputs test the random-grid and per-terminal-leaf payment mechanisms. They do not certify the original FULL forest, upstream corridor cut, FIRST, or all original gates. Stage 1 is standalone; stages 2 and 3 additionally realize the actual pointwise residual σ=(g−√n)+ with g=f and retain the already capped source g−σ separately. These examples use explicit σ≤f, actual Lebesgue receiver measure, and source capture; they are not claimed to be original I11 hard instances. In all stages a=λ=R=1, β=1/6144, b0=1/12288, c=16, d=1/n, τ=√n. Qx is the centered cube of full side 1; G0=1_E(x)1_Qx(z). Hence row density is A1σ, and T=∫E A1σ dx. The source and receiver are fixed before the independent uniform ξ∈[0,S)^n.

Use s*=16n, s0=ceil(6√n(1+n log 2)), D=min{j≥0:2^j s*≥s0}, S=2^D s*. All n are perfect squares. The common finest-boundary result is an exact full-uniform average, not a sampled phase: p_bad=1−(1−1/s*)^n, T_bad=p_bad T. Check 0<p_bad≤1/16<1/8 and retain the exact rational T_good=(1−p_bad)T. This follows coordinatewise for every fixed receiver, without assuming the source tree is constant in ξ.

Source tests always use the true m(Q)=σ(Q): light first at m≤exp(√n), otherwise dense at m≥4(s+2)^n/√n, otherwise split until D, and retain true terminal leaves. First stops and leaves are a source antichain; no source receives multiple labels. We certify explicit subsets of these labels instead of exhaustively integrating the enormous random forest. Uncertified phase/source balances remain in an explicitly named unresolved ledger; they are never relabelled as actual terminal leaves. Their full mass and possible traffic are retained.

Each terminal leaf V is capped with mVC=σ(C∩V), θVC=min(1,τd^n/mVC); use μV=σ|V, ηV=θVCμV, ζV=μV−ηV. A whole original row is paid on ηV(Qx)≥μV(Qx)/2. Excess rows retain the original μV integrand. High cells use the strict condition mVC>τd^n; their full untrimmed volumes d^n are counted, even if a cell crosses V.

## Stage 1 — n=4, positive dense stops and full-uniform boundary flow

Set ρ=5/2, f=σ=ρ1_[0,4S)^4 and E=[S,3S]^4. Here D=0, S=s*=64. Every receiver cube lies inside the source support, so A1f=A1σ=5/2∈(2,4], σ(Qx)=5/2≥b0, |E|=(2S)^4, W=ρ(4S)^4, T=ρ(2S)^4.

For every ξ outside null boundary phases, there are exactly 3^4 full grid roots inside [0,4S)^4, each with mass ρS^4. Verify ρS^4>exp(2) and ρS^4≥2(S+2)^4. Thus these are true first dense-stop roots, with certified dense mass 3^4ρS^4. Every good receiver in E belongs to one of these full roots. Consequently T_good,dense=(1−p_bad)T exactly, and the actual terminal receiver traffic from E is zero. Other source pieces have mass W−3^4ρS^4 and receive an unresolved source classification; no claim about their averaged light/dense/terminal split is made. The certified full roots plus all other true roots partition the source, so this unresolved source mass is not lost. Verify T_good,dense≤√n·(3^4ρS^4).

This stage is a stand-alone density-stop example. It does not fit a single original canonical box and does not claim the original low canonical mean/corridor assumptions. Its global source density is 5/2; this limitation must remain in the report.

## Stage 2 — n=64, low-mean massive terminal and nontrivial cell smoothing

Let H=32 and B=[0,H)^n. Define f=g=20·1_B·1_{ {nz1}<3/20 }, where {t} is fractional part, and σ=(g−8)+=12·1_B·1_{ {nz1}<3/20 }. Only the first coordinate is striped; all remaining coordinates repeat the full interval [0,H). This is a finite union of ordinary boxes, not atomic data. E=[1,H−1]^n. A length-one receiver interval covers exactly n periods in coordinate one, so A1f=3 and A1σ=9/5 for every x∈E. W=9H^n/5, |E|=(H−2)^n, T=9(H−2)^n/5. The already pointwise capped source g−σ has mass 6H^n/5 and row density 6/5; the physical f-mass is 3H^n. Every original fine cell inside B has σ-mass 9d^n/5 and f-mass 3d^n, although the residual source peak 12 exceeds τ=8. Thus this cap branch yields a genuinely new payment after the initial pointwise cap.

Define the explicit positive-measure phase domain A={ξ: ξ_i mod s*∈[H,s*) for every i}. It has exact probability α=((s*−H)/s*)^n under the entire uniform [0,S)^n distribution, including all dyadic blocks. For every ξ∈A, B lies wholly inside one finest leaf V. Its unique positive source chain has constant mass W. Verify W>exp(8) and W<4(s*+2)^n/8; because coarser thresholds are larger, no ancestor is light or dense. Thus V is a genuine terminal leaf, all E rows are good, and mVC=9d^n/5 on exactly (Hn)^n cells. ηV=μV, ζV=0, all original E rows are cap-dominant, and their entire traffic is paid. Exact phase-subdomain contributions are W_term,A=αW, W_cap,A=αW, T_leafcap,A=αT>0, W_exc,A=0 and |S_V|=0. Full-uniform cap traffic is at least αT; it is not equated to αT. All other phase traffic is retained, with unresolved good traffic T_good−αT and unresolved source-phase mass (1−α)W. Display the actual ratio T_leafcap,A/(√n W_cap,A) beside the symbolic price C_cell√n W_cap,A; C2 is not assigned an invented numerical value.

The source fits in a canonical-size box [0,s0)^n. Check exp(√n)<W<4(s0+2)^n/√n and W/s0^n<4exp(1/3)/√n. The pointwise residual is exact; these canonical checks verify numerical mass/mean inequalities only, not upstream corridor or component provenance.

## Stage 3 — n=1024, positive terminal excess and real high-cell occupancy

Let H=32, B=[0,H)^n and f=g=128·1_B·1_{ {z1}<3/128 }, σ=(g−32)+=96·1_B·1_{ {z1}<3/128 }. Again only coordinate one is striped. E=[1,H−1]^n. Every length-one receiver interval sees hot length 3/128, hence A1f=3, A1σ=9/4, W=9H^n/4 and T=9(H−2)^n/4. The already pointwise capped source g−σ has mass 3H^n/4 and row density 3/4; physical f-mass is 3H^n. The hot strips align exactly with the original d=1/1024 cells: 24 hot cells per unit first-coordinate interval. Exactly N_hi=3(Hn)^n/128 full fine cells have σ-mass 96d^n and f-mass 128d^n; all others have zero mass.

Use the same A and α as Stage 2, now with s*=16384. Verify W>exp(32) and W<4(s*+2)^n/32, so A contains a genuine single terminal source leaf with all E rows good. Each hot cell has θ=1/3, hence ηV=μV/3, ζV=2μV/3. Every E row is strictly excess because ηV(Qx)=3/4<9/8 and ζV(Qx)=3/2>9/8≥β/4. The full original residual row remains 9/4, not 3/2; the complete f-row is 3. Exact contributions on A: W_term,A=αW, W_cap,A=αW/3, W_exc,A=2αW/3, T_leafcap,A=0, T_leafexc,A=αT>0. Within these excess rows cap-source traffic is αT/3 and excess-source traffic is 2αT/3; their sum is the full original residual traffic αT. This explicitly distinguishes capped source mass from paid row traffic.

For each certified V, |S_V|=N_hi d^n=3H^n/128, while mV/τ=9H^n/128. Verify |S_V|≤mV/τ<4(s*+2)^n/n≤4exp(1/8)|V|/n. Retain the actual leaf volume |V|=(s*)^n. Full-uniform excess traffic is at least αT. Other phases retain unresolved good traffic T_good−αT and unresolved source-phase mass (1−α)W. Verify the same canonical-size mass/mean inequalities as Stage 2, with the same provenance limitation.

## Common checks, arithmetic, output and stop rule

For every stage record exact tensor box specification, densities, physical volumes, |E|, W, T, b0 capture margin, strict 2<A1f≤4, σ≤f, p_bad, T_bad, T_good, certified paid/excess traffic and unresolved balances. No volume is normalized away. Giant exact integers/rationals may be represented by an exact exponent expression plus their directed log10 interval and a reproducible numerator/denominator hash; calculations retain the full Fraction. Tensor repetition is a compact representation of physical n-dimensional Lebesgue measure.

Check the numerical birth necessary inequality using H_C=f(C) as an explicitly labelled dominating proxy for a possible μhi≤f: H_C<e²R^n exp(−√n)/√n with q=1, R=1. This checks t_C≤1 and n log(1/t_C)>√n for the proxy. It does not construct the original μhi, FIRST birth labels or FULL forest and therefore never awards FULL status. Stage 1 maximum H_C=ρd^n; Stage 2 3d^n; Stage 3 128d^n.

Implementation uses Python integers and Fraction for every physical quantity. The fixed ln2 enclosure uses exactly 128 terms of 2Σ_{k≥0}(1/3)^(2k+1)/(2k+1), k=0,...,127, with remainder at most 2·3^−257/[257(1−1/9)]. The only positive exp parameters are the fixed menu {2,8,32,1/8,1/3}; each uses exactly 256 Taylor terms k=0,...,255. With first omitted term b=t^256/256!, the remainder is at most b/(1−t/257). Birth bounds use exp(2)/exp(√n), so no extra exp parameter is introduced. Strict tests are accepted only when these fixed rational bounds separate them; failure is UNKNOWN, with no additional terms or altered parameters. Exact physical quantities receive directed integer log10 brackets from rational comparisons with powers of ten; these are display bounds, not floating logarithms. Constants C2 and C_cell remain symbolic: no invented numeric maximal constant or verification of the external L2 theorem.

Frozen execution rule, now completed: write one standalone numeric.py, perform exactly one producer invocation, append its complete result ledger here; parent performs one isolated replay. No exploratory parameter scan, old-round rerun or adaptive menu extension. Any failed certificate or unresolved arithmetic yields UNKNOWN and stops execution without changing the menu. This protocol demonstrates distinct payment mechanisms; it does not prove a general root-order bound or a uniform positive paid fraction over arbitrary inputs.


## Frozen single-producer result

The one authorized producer completed with **PASS, 257 checks**. No parameter or precision was changed after freezing, and no producer rerun occurred. Exact values and SHA256 certificates follow; displayed intervals are outward rational decimal enclosures.

| n | (s0,D,S) | Full-uniform T_bad/T | Certified positive mechanism |
|---|---|---|
| 4 | (46,0,64) | [0.061050355434417724, 0.061050355434417725] | True dense-stop traffic is exactly T_good, at least 0.938949644565582275 T; dense price ratio <0.092735767364501954. |
| 64 | (2178,2,4096) | [0.060615624038187818, 0.060615624038187819] | On A, every original residual row is cap-paid; α∈[0.131084032478475052,0.131084032478475053]. The actual paid/sqrt-source ratio is <0.002009424543869079, beside the symbolic C_cell price. |
| 1024 | (136471,4,262144) | [0.060588729045947683, 0.060588729045947684] | On A, every original residual row is excess; α∈[0.135070870467745658,0.135070870467745659]. Its cap-source and excess-source flows remain αT/3 and 2αT/3, together αT. |

The n=1024 high-cell volume is exactly 3·32^1024/128, compared with mV/τ=9·32^1024/128 and the actual leaf volume 16384^1024. The n=64 case has zero high cells on A despite the residual peak 12 exceeding τ=8. The full source, receiver, cap, excess, boundary and unresolved volumes/masses are retained below. Results on A are lower contributions to the full-uniform classification, not a claim that other phases contribute zero. General root-order closure remains unproved.

<!-- R106-NUMERIC-RESULT-BEGIN -->
```json
{
  "arithmetic": {
    "exp_bound_hashes": {
      "1/3": {
        "lower_fraction_sha256": "58ee7621fec168640abec3f3bba9b261a095e8d8384d100c2e33d2d248735afc",
        "relative_width_upper": [
          "0.000000000000000000",
          "0.000000000000000001"
        ],
        "upper_fraction_sha256": "176cb28325c809c7605950921dd2ac0a990b695e9d8eb1032a2eeb0175851eb2"
      },
      "1/8": {
        "lower_fraction_sha256": "e87387957c086944c16a634824bba28d0c47eb939958d508570cc3338e60eb4a",
        "relative_width_upper": [
          "0.000000000000000000",
          "0.000000000000000001"
        ],
        "upper_fraction_sha256": "db69caee09ce8e5b7f55cfb56793525bebff6ffb7f49975a38aab7b17f8c951f"
      },
      "2": {
        "lower_fraction_sha256": "5578cc01a369781e3398f9cf40fc1af9c96fb1f3d7b5dec2f9cc07b21e6878e2",
        "relative_width_upper": [
          "0.000000000000000000",
          "0.000000000000000001"
        ],
        "upper_fraction_sha256": "4bc738f3c16bed3177eb5af5f7a2a14f8f4998ed479c7e4b6c916d85e3da04b8"
      },
      "32": {
        "lower_fraction_sha256": "7f472215cf1fce2d8766792152375222d6b464b934948317ce9aa949f8db663a",
        "relative_width_upper": [
          "0.000000000000000000",
          "0.000000000000000001"
        ],
        "upper_fraction_sha256": "5d2f016a40d439b70684210eb7d96bdc4f6cb012273b71edafae20f86325a58c"
      },
      "8": {
        "lower_fraction_sha256": "6a2822efa7cc6f57c866f5314236ad9a4d719e7fabbc3baa6508688a8a29c55d",
        "relative_width_upper": [
          "0.000000000000000000",
          "0.000000000000000001"
        ],
        "upper_fraction_sha256": "4b77eb3bfdcac1d604d3a07c6543881f69ef3a18469620b884b486b4556848f4"
      }
    },
    "exp_positive_parameters": [
      "2",
      "8",
      "32",
      "1/8",
      "1/3"
    ],
    "exp_terms": 256,
    "ln2_directed_interval": [
      "0.693147180559945309",
      "0.693147180559945310",
      "0.693147180559945309",
      "0.693147180559945310"
    ],
    "ln2_terms": 128,
    "log10_brackets": "exact comparisons 10^k<=x<10^(k+1); zero=null",
    "physical_quantities": "exact Python Fraction",
    "quantity_hash_serialization": "sha256(str(numerator)+\"/\"+str(denominator))"
  },
  "check_labels": [
    "exp fixed menu and convergent tail 2",
    "exp fixed menu and convergent tail 8",
    "exp fixed menu and convergent tail 32",
    "exp fixed menu and convergent tail 1/8",
    "exp fixed menu and convergent tail 1/3",
    "n=4: exact square",
    "n=4: unique canonical integer",
    "n=4: minimal tree depth",
    "n=4: exact bad probability in (0,1/16]",
    "n=4: strict c16 absorption budget",
    "n=4: physical f hard row",
    "n=4: source dominated by full f",
    "n=4: active source capture",
    "n=4: true positive source and receiver",
    "n=4: exact full-uniform traffic split",
    "n=4: full-f fine-cell proxy is birth-deep",
    "n=4: finest halo exponential bound",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "stage1: true dense root is not light",
    "stage1: true dense root qualification",
    "stage1: source antichain mass ledger",
    "stage1: full good row dense payment",
    "stage1: positive actual dense payment",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "n=64: exact square",
    "n=64: unique canonical integer",
    "n=64: minimal tree depth",
    "n=64: exact bad probability in (0,1/16]",
    "n=64: strict c16 absorption budget",
    "n=64: actual pointwise residual peak",
    "n=64: complete initial cap ledger",
    "n=64: complete source-volume mass",
    "n=64: exact physical f mean",
    "n=64: initial cap row ledger",
    "n=64: stripe divides unit receiver",
    "n=64: phase A has positive measure and is all-good",
    "n=64: phase A support fits unique finest leaf",
    "n=64: true terminal heavy",
    "n=64: true terminal below least dense threshold",
    "n=64: canonical support fits",
    "n=64: canonical middle mass upper",
    "n=64: canonical low mean",
    "n=64: physical f hard row",
    "n=64: source dominated by full f",
    "n=64: active source capture",
    "n=64: true positive source and receiver",
    "n=64: exact full-uniform traffic split",
    "n=64: full-f fine-cell proxy is birth-deep",
    "n=64: finest halo exponential bound",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "n=64: exact finecell count and source mass",
    "n=64: prescribed cap factor",
    "n=64: per-leaf source cap conservation",
    "n=64: phase-mass ledger",
    "n=64: full traffic ledger including outside A",
    "n=64: unresolved traffic retained nonnegative",
    "n=64: full high-cell occupancy bound",
    "n=64: source cap and excess row sum",
    "stage2: positive full-row cap payment",
    "stage2: new residual peak exceeds pointwise cap",
    "stage2: cell mean fits cap despite peak",
    "stage2: actual price ratio at most one",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "n=1024: exact square",
    "n=1024: unique canonical integer",
    "n=1024: minimal tree depth",
    "n=1024: exact bad probability in (0,1/16]",
    "n=1024: strict c16 absorption budget",
    "n=1024: actual pointwise residual peak",
    "n=1024: complete initial cap ledger",
    "n=1024: complete source-volume mass",
    "n=1024: exact physical f mean",
    "n=1024: initial cap row ledger",
    "n=1024: stripe divides unit receiver",
    "n=1024: phase A has positive measure and is all-good",
    "n=1024: phase A support fits unique finest leaf",
    "n=1024: true terminal heavy",
    "n=1024: true terminal below least dense threshold",
    "n=1024: canonical support fits",
    "n=1024: canonical middle mass upper",
    "n=1024: canonical low mean",
    "n=1024: physical f hard row",
    "n=1024: source dominated by full f",
    "n=1024: active source capture",
    "n=1024: true positive source and receiver",
    "n=1024: exact full-uniform traffic split",
    "n=1024: full-f fine-cell proxy is birth-deep",
    "n=1024: finest halo exponential bound",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "n=1024: exact finecell count and source mass",
    "n=1024: prescribed cap factor",
    "n=1024: per-leaf source cap conservation",
    "n=1024: phase-mass ledger",
    "n=1024: full traffic ledger including outside A",
    "n=1024: unresolved traffic retained nonnegative",
    "n=1024: full high-cell occupancy bound",
    "n=1024: source cap and excess row sum",
    "stage3: positive original full-row excess",
    "stage3: strict excess capture half gate",
    "stage3: positive high finecell mean",
    "stage3: retained cap-source on excess row",
    "stage3: physical high-cell volume",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket",
    "nonnegative physical display value",
    "exact integer log10 bracket"
  ],
  "checks_passed": 257,
  "not_claimed": [
    "original FULL/FIRST forest",
    "upstream component/corridor provenance",
    "full-uniform exact stop/cap/excess classification outside certified domains",
    "uniform paid fraction for arbitrary input",
    "general root-order endpoint bound"
  ],
  "protocol": "R106 frozen residual-consistent 3-stage menu",
  "replay": "run this file with no arguments; compare stdout JSON with numeric.md stored JSON",
  "stages": [
    {
      "S": 64,
      "T": {
        "exact_expression": "source_row * receiver_volume",
        "fraction_sha256": "425076e7b98cd664bf32583eb55efafa45267c414e837ce5a82be4dce265bb51",
        "log10_closed_bracket": [
          8,
          9
        ]
      },
      "T_bad_full_uniform": {
        "exact_expression": "p_bad*T",
        "fraction_sha256": "5de2c044e699a88ebfd7099527fdac95c50492d7f872d6f7fe06a05adf0d6592",
        "log10_closed_bracket": [
          7,
          8
        ]
      },
      "T_good_full_uniform": {
        "exact_expression": "(1-p_bad)*T",
        "fraction_sha256": "bca1f87656b11d19fdbb34e7ea27dcaeae12d368c35b5d5a7c444523c7d16c66",
        "log10_closed_bracket": [
          8,
          9
        ]
      },
      "all_phase_forest_classification_claimed": false,
      "birth_proxy_only": true,
      "certified": {
        "actual_good_dense_traffic_exact_full_uniform": {
          "exact_expression": "T_good",
          "fraction_sha256": "bca1f87656b11d19fdbb34e7ea27dcaeae12d368c35b5d5a7c444523c7d16c66",
          "log10_closed_bracket": [
            8,
            9
          ]
        },
        "actual_terminal_receiver_traffic_exact_full_uniform": {
          "exact_expression": "0",
          "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
          "log10_closed_bracket": null
        },
        "dense_payment_ratio": {
          "directed_decimal_interval": [
            "0.092735767364501953",
            "0.092735767364501954"
          ],
          "exact_expression": "T_good/(sqrt_n*certified_dense_mass)",
          "fraction_sha256": "414adeb62a26f78540c590b3c2a4c9048fd1a676b8d7e3b57a624fc7d9fc596b",
          "log10_closed_bracket": [
            -2,
            -1
          ]
        },
        "dense_root_mass": {
          "exact_expression": "(5/2)*64^4",
          "fraction_sha256": "df339cd432b3dc51dea49b60f003f52584253fa59b33f981a3da1a6a7de74daf",
          "log10_closed_bracket": [
            7,
            8
          ]
        },
        "dense_source_mass_lower_bound_full_uniform": {
          "exact_expression": "3^4*(5/2)*64^4",
          "fraction_sha256": "0140a7ee6fd4d927a5c26e345426641490f14614e72cafaf99e4bda19c73945b",
          "log10_closed_bracket": [
            9,
            10
          ]
        },
        "full_dense_root_count_each_phase": 81,
        "paid_good_fraction_of_T": {
          "directed_decimal_interval": [
            "0.938949644565582275",
            "0.938949644565582276"
          ],
          "exact_expression": "1-p_bad",
          "fraction_sha256": "c770bd11e9ede0027bdbaa83676538546825f177aaf3e6dbc3ab77f6b55bbc97",
          "log10_closed_bracket": [
            -1,
            0
          ]
        },
        "unresolved_source_class_mass": {
          "exact_expression": "W-3^4*(5/2)*64^4",
          "fraction_sha256": "6c77da7ccf87052dc808389f90818f5a2dffcb8a516fb59412708687a20809a4",
          "log10_closed_bracket": [
            9,
            10
          ]
        }
      },
      "depth": 0,
      "dimension": 4,
      "f_peak": "5/2",
      "f_row": {
        "directed_decimal_interval": [
          "2.500000000000000000",
          "2.500000000000000000"
        ],
        "exact_expression": "5/2",
        "fraction_sha256": "06a89c05b4eae0f2acac44075fe7d5dcde1e2d1a23aeb7270b11556c42a39315",
        "log10_closed_bracket": [
          0,
          1
        ]
      },
      "finest_leaf_volume": {
        "exact_expression": "(16*n)^n",
        "fraction_sha256": "1ff99a57d6078bfd67da127a59c767c15e2917cbda17788d5a3a59ce1e809598",
        "log10_closed_bracket": [
          7,
          8
        ]
      },
      "full_f_mass": {
        "exact_expression": "f_row * enclosing_box_volume",
        "fraction_sha256": "1f97d94e9708ad7a3db110a654982c8f3e1c02270aeea736b8891ae598c3e9e0",
        "log10_closed_bracket": [
          10,
          11
        ]
      },
      "initial_pointwise_cap_mass": null,
      "max_full_f_birth_proxy_cell_mass": {
        "exact_expression": "f fine-cell mass specified in protocol",
        "fraction_sha256": "36f7416fba25b0bfb7f68a54f9b4b1ffc84119d6be7b45e1182556567ad1bbcf",
        "log10_closed_bracket": [
          -3,
          -2
        ]
      },
      "max_source_cell_mass": {
        "exact_expression": "source fine-cell mass specified in protocol",
        "fraction_sha256": "36f7416fba25b0bfb7f68a54f9b4b1ffc84119d6be7b45e1182556567ad1bbcf",
        "log10_closed_bracket": [
          -3,
          -2
        ]
      },
      "occupied_source_volume": {
        "exact_expression": "(4*S)^n",
        "fraction_sha256": "8ef663964e57d4944b00c3fcbbe124b29d6571a2ecf968181bc43ad044546649",
        "log10_closed_bracket": [
          9,
          10
        ]
      },
      "original_source_row": {
        "directed_decimal_interval": [
          "2.500000000000000000",
          "2.500000000000000000"
        ],
        "exact_expression": "5/2",
        "fraction_sha256": "06a89c05b4eae0f2acac44075fe7d5dcde1e2d1a23aeb7270b11556c42a39315",
        "log10_closed_bracket": [
          0,
          1
        ]
      },
      "p_bad_full_uniform": {
        "directed_decimal_interval": [
          "0.061050355434417724",
          "0.061050355434417725"
        ],
        "exact_expression": "1-(1-1/(16*n))^n",
        "fraction_sha256": "2c047d730a568a7aec12ac30f4dc157418ea071a557a96b4481b9f5e350ff69a",
        "log10_closed_bracket": [
          -2,
          -1
        ]
      },
      "receiver_volume": {
        "exact_expression": "(2*S)^n",
        "fraction_sha256": "1db1cb4b6f64872161772925b7e745ddf79dcc47b79ea159318b3a815476841c",
        "log10_closed_bracket": [
          8,
          9
        ]
      },
      "s0": 46,
      "s_star": 64,
      "scope": "standalone dense example; no canonical provenance",
      "source_enclosing_box_volume": {
        "exact_expression": "(4*S)^n",
        "fraction_sha256": "8ef663964e57d4944b00c3fcbbe124b29d6571a2ecf968181bc43ad044546649",
        "log10_closed_bracket": [
          9,
          10
        ]
      },
      "source_peak": "5/2",
      "sqrt_n": 2,
      "tree_source_mass": {
        "exact_expression": "source_row * enclosing_box_volume",
        "fraction_sha256": "1f97d94e9708ad7a3db110a654982c8f3e1c02270aeea736b8891ae598c3e9e0",
        "log10_closed_bracket": [
          10,
          11
        ]
      }
    },
    {
      "S": 4096,
      "T": {
        "exact_expression": "source_row * receiver_volume",
        "fraction_sha256": "2219112c3463c1d14c39e5eaab3d52a67cbd473e92e726f94e17f8cb417cc2da",
        "log10_closed_bracket": [
          94,
          95
        ]
      },
      "T_bad_full_uniform": {
        "exact_expression": "p_bad*T",
        "fraction_sha256": "bd13e0c91852038a617b5baea205a2c29de8a55d0b8b34ea37fdc90220239522",
        "log10_closed_bracket": [
          93,
          94
        ]
      },
      "T_good_full_uniform": {
        "exact_expression": "(1-p_bad)*T",
        "fraction_sha256": "0191c7cea3db94340f8f53d71eb58367151f40210c254f998b7e09f0ae4ae53e",
        "log10_closed_bracket": [
          94,
          95
        ]
      },
      "all_phase_forest_classification_claimed": false,
      "birth_proxy_only": true,
      "certified": {
        "actual_row_payment_to_sqrt_mass_ratio": {
          "directed_decimal_interval": [
            "0.002009424543869078",
            "0.002009424543869079"
          ],
          "exact_expression": "paid_A/(sqrt_n*cap_mass_A)",
          "fraction_sha256": "f2c79b65bb61592fac085e3503ee27ac5929c65c2db384a526316dd1f8379585",
          "log10_closed_bracket": [
            -3,
            -2
          ]
        },
        "canonical_mean": {
          "exact_expression": "W/s0^n",
          "fraction_sha256": "d7e167ff1f42d9bac557b40a71db8e6e8160813aa15a97b5dfd9483e5ccd32df",
          "log10_closed_bracket": [
            -118,
            -117
          ]
        },
        "cap_capture_row": {
          "directed_decimal_interval": [
            "1.800000000000000000",
            "1.800000000000000000"
          ],
          "exact_expression": "9/5",
          "fraction_sha256": "7af8536c5a4c2206aea984bc1eff8081ee843156d0f70e25818fda435efbc5c2",
          "log10_closed_bracket": [
            0,
            1
          ]
        },
        "excess_capture_row": {
          "directed_decimal_interval": [
            "0.000000000000000000",
            "0.000000000000000000"
          ],
          "exact_expression": "0",
          "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
          "log10_closed_bracket": null
        },
        "fine_cell_count": {
          "exact_expression": "(32*n)^n",
          "fraction_sha256": "6f5e24252eb292735cbc9c0854752ebaaa96e12bed806ab1c53476b2c1fbf00e",
          "log10_closed_bracket": [
            211,
            212
          ]
        },
        "high_cell_count": {
          "exact_expression": "0",
          "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
          "log10_closed_bracket": null
        },
        "high_cell_full_volume_per_certified_leaf": {
          "exact_expression": "0",
          "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
          "log10_closed_bracket": null
        },
        "high_cell_occupancy_fraction_of_leaf": {
          "exact_expression": "high_cell_full_volume/(16*n)^n",
          "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
          "log10_closed_bracket": null
        },
        "phase_A_cap_source_mass": {
          "exact_expression": "alpha*theta*W",
          "fraction_sha256": "9493dfabd646264661ebbb877dc7fc28ecc35f25df1cc1e3c68590b82f1bbba2",
          "log10_closed_bracket": [
            95,
            96
          ]
        },
        "phase_A_cap_source_traffic_on_excess_rows": {
          "exact_expression": "0",
          "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
          "log10_closed_bracket": null
        },
        "phase_A_entire_row_paid_traffic": {
          "exact_expression": "alpha*T",
          "fraction_sha256": "d7a8dfdb3575ffdf0d7866a98fbc13fcafa2b80b6c0dd5d51b5834dda12a7ce1",
          "log10_closed_bracket": [
            93,
            94
          ]
        },
        "phase_A_excess_source_mass": {
          "exact_expression": "alpha*(1-theta)*W",
          "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
          "log10_closed_bracket": null
        },
        "phase_A_excess_source_traffic_on_excess_rows": {
          "exact_expression": "0",
          "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
          "log10_closed_bracket": null
        },
        "phase_A_original_row_excess_traffic": {
          "exact_expression": "0",
          "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
          "log10_closed_bracket": null
        },
        "phase_A_terminal_mass": {
          "exact_expression": "alpha*W",
          "fraction_sha256": "9493dfabd646264661ebbb877dc7fc28ecc35f25df1cc1e3c68590b82f1bbba2",
          "log10_closed_bracket": [
            95,
            96
          ]
        },
        "phase_probability_alpha": {
          "directed_decimal_interval": [
            "0.131084032478475052",
            "0.131084032478475053"
          ],
          "exact_expression": "((16*n-32)/(16*n))^n",
          "fraction_sha256": "2d70461cb935e79e9efebaa2c894a74ea3933d0c9566ccc353e9bdb64f0b14a7",
          "log10_closed_bracket": [
            -1,
            0
          ]
        },
        "positive_certified_traffic_fraction_of_T": {
          "directed_decimal_interval": [
            "0.131084032478475052",
            "0.131084032478475053"
          ],
          "exact_expression": "alpha",
          "fraction_sha256": "2d70461cb935e79e9efebaa2c894a74ea3933d0c9566ccc353e9bdb64f0b14a7",
          "log10_closed_bracket": [
            -1,
            0
          ]
        },
        "symbolic_row_payment_price": "C_cell*sqrt_n*phase_A_cap_source_mass; C_cell=64*exp(4)*C2^2/beta^2, C2 unassigned",
        "theta": {
          "directed_decimal_interval": [
            "1.000000000000000000",
            "1.000000000000000000"
          ],
          "exact_expression": "1",
          "fraction_sha256": "253d950f11ebdbeb4c2d54c57803deb69869b832a2e03010620d462a85d15290",
          "log10_closed_bracket": [
            0,
            1
          ]
        },
        "unresolved_good_traffic_outside_A": {
          "exact_expression": "T_good-alpha*T",
          "fraction_sha256": "7a97a15c4bb72cc3c56d3ac6ed1006570b998a56929bd388297f3487bd598a46",
          "log10_closed_bracket": [
            94,
            95
          ]
        },
        "unresolved_source_phase_mass": {
          "exact_expression": "(1-alpha)*W",
          "fraction_sha256": "eb4171cc022e441ad428cb5ed9a083deb4adc897a018692b8ca5983a713618af",
          "log10_closed_bracket": [
            96,
            97
          ]
        }
      },
      "depth": 2,
      "dimension": 64,
      "f_peak": "20",
      "f_row": {
        "directed_decimal_interval": [
          "3.000000000000000000",
          "3.000000000000000000"
        ],
        "exact_expression": "3",
        "fraction_sha256": "02925afd44e2946e583a7f6434585a77c146fcf4533cd4b3793f62f0d5b7c60c",
        "log10_closed_bracket": [
          0,
          1
        ]
      },
      "finest_leaf_volume": {
        "exact_expression": "(16*n)^n",
        "fraction_sha256": "63378a6fa7939c54927cca00419f19a6bea9f38982d012b6726ea90a7adc30f4",
        "log10_closed_bracket": [
          192,
          193
        ]
      },
      "full_f_mass": {
        "exact_expression": "f_row * enclosing_box_volume",
        "fraction_sha256": "b65ea66a6c46752efd7b883a7a833d23b5ac70c577424ddd76585671a5e807a8",
        "log10_closed_bracket": [
          96,
          97
        ]
      },
      "initial_pointwise_cap_mass": {
        "exact_expression": "sqrt_n * occupied_source_volume",
        "fraction_sha256": "09e4b98900afc4b9a822f61b427395083ef3f432be37d4d9fc0b1ee3e110872d",
        "log10_closed_bracket": [
          96,
          97
        ]
      },
      "max_full_f_birth_proxy_cell_mass": {
        "exact_expression": "f fine-cell mass specified in protocol",
        "fraction_sha256": "4d8325e4e7b0063a39fb498997e24702cae0359ae8e96b08a7fe7e9132705bfb",
        "log10_closed_bracket": [
          -116,
          -115
        ]
      },
      "max_source_cell_mass": {
        "exact_expression": "source fine-cell mass specified in protocol",
        "fraction_sha256": "80cbede4fc0e9fb2629b330d0fb357aa29dd0867a95cce485ee29511cca7ee23",
        "log10_closed_bracket": [
          -116,
          -115
        ]
      },
      "occupied_source_volume": {
        "exact_expression": "3*32^n/20",
        "fraction_sha256": "c19f66b374d964b4d96ecbde3b5d1b59aa62dd73b8e0ed4d94feb9a745752361",
        "log10_closed_bracket": [
          95,
          96
        ]
      },
      "original_source_row": {
        "directed_decimal_interval": [
          "1.800000000000000000",
          "1.800000000000000000"
        ],
        "exact_expression": "9/5",
        "fraction_sha256": "7af8536c5a4c2206aea984bc1eff8081ee843156d0f70e25818fda435efbc5c2",
        "log10_closed_bracket": [
          0,
          1
        ]
      },
      "p_bad_full_uniform": {
        "directed_decimal_interval": [
          "0.060615624038187818",
          "0.060615624038187819"
        ],
        "exact_expression": "1-(1-1/(16*n))^n",
        "fraction_sha256": "59a6bfd4a0ccf1548d99597fc45c155d43dcba0872c5917d1a6b022714977a62",
        "log10_closed_bracket": [
          -2,
          -1
        ]
      },
      "receiver_volume": {
        "exact_expression": "30^n",
        "fraction_sha256": "2ed9e297d61f167cde2095d4363da65fd6746308b6df5f6e269303e178a6913b",
        "log10_closed_bracket": [
          94,
          95
        ]
      },
      "s0": 2178,
      "s_star": 1024,
      "scope": "exact cap-first residual; canonical inequalities only; no original FULL forest",
      "source_enclosing_box_volume": {
        "exact_expression": "32^n",
        "fraction_sha256": "c2319ed368076b30f1d14994ac3bd4f917c95b49a40fb03350b4d7de8e0876fb",
        "log10_closed_bracket": [
          96,
          97
        ]
      },
      "source_peak": "12",
      "sqrt_n": 8,
      "tree_source_mass": {
        "exact_expression": "source_row * enclosing_box_volume",
        "fraction_sha256": "6bb1a9fbedfb9f90d2e74d50db58c5fd7479008d4275dc9e5433c9ad3106325a",
        "log10_closed_bracket": [
          96,
          97
        ]
      }
    },
    {
      "S": 262144,
      "T": {
        "exact_expression": "source_row * receiver_volume",
        "fraction_sha256": "6e9c0d7b845f04fea58c16a6baf37ef015b84a3b120659448d254b44afb6a579",
        "log10_closed_bracket": [
          1512,
          1513
        ]
      },
      "T_bad_full_uniform": {
        "exact_expression": "p_bad*T",
        "fraction_sha256": "5ef8537abcef5fd0668d16fcad62ad19b26c22872266ef84848536d8960c2baa",
        "log10_closed_bracket": [
          1511,
          1512
        ]
      },
      "T_good_full_uniform": {
        "exact_expression": "(1-p_bad)*T",
        "fraction_sha256": "7ee7176bcfb840be05583df3071b0e9e3f2f73a2d52682dcf34c2bc732d74153",
        "log10_closed_bracket": [
          1512,
          1513
        ]
      },
      "all_phase_forest_classification_claimed": false,
      "birth_proxy_only": true,
      "certified": {
        "actual_row_payment_to_sqrt_mass_ratio": {
          "directed_decimal_interval": [
            "0.000000000000000000",
            "0.000000000000000000"
          ],
          "exact_expression": "paid_A/(sqrt_n*cap_mass_A)",
          "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
          "log10_closed_bracket": null
        },
        "canonical_mean": {
          "exact_expression": "W/s0^n",
          "fraction_sha256": "975dcd0309ffb59a6486ead7c2f2655ee97b5a1b09e2b13877833af1ba2b300a",
          "log10_closed_bracket": [
            -3717,
            -3716
          ]
        },
        "cap_capture_row": {
          "directed_decimal_interval": [
            "0.750000000000000000",
            "0.750000000000000000"
          ],
          "exact_expression": "3/4",
          "fraction_sha256": "5132a20379415fe98f3a0700afc2a901e9b01af839b5454a8659152f0782c223",
          "log10_closed_bracket": [
            -1,
            0
          ]
        },
        "excess_capture_row": {
          "directed_decimal_interval": [
            "1.500000000000000000",
            "1.500000000000000000"
          ],
          "exact_expression": "3/2",
          "fraction_sha256": "6d27ca189b30af4f85eab024881ab00a37ef4bab14248c18349e900f40510397",
          "log10_closed_bracket": [
            0,
            1
          ]
        },
        "fine_cell_count": {
          "exact_expression": "3*(32*n)^n/128",
          "fraction_sha256": "520722a6080cfe7a6b5cc28e653f30bd5867b605c79cd959c2dc26607c83b414",
          "log10_closed_bracket": [
            4622,
            4623
          ]
        },
        "high_cell_count": {
          "exact_expression": "3*(32*n)^n/128",
          "fraction_sha256": "520722a6080cfe7a6b5cc28e653f30bd5867b605c79cd959c2dc26607c83b414",
          "log10_closed_bracket": [
            4622,
            4623
          ]
        },
        "high_cell_full_volume_per_certified_leaf": {
          "exact_expression": "3*32^n/128",
          "fraction_sha256": "d2678fd950b94a90e006887552aeb9b90415c5c52e84aa365d718a940cf5a6f2",
          "log10_closed_bracket": [
            1539,
            1540
          ]
        },
        "high_cell_occupancy_fraction_of_leaf": {
          "exact_expression": "high_cell_full_volume/(16*n)^n",
          "fraction_sha256": "607f2393dd10da7bb7d61a82f9b87977772295698b22db346fd7267925b9196b",
          "log10_closed_bracket": [
            -2776,
            -2775
          ]
        },
        "phase_A_cap_source_mass": {
          "exact_expression": "alpha*theta*W",
          "fraction_sha256": "29dbeab7ec072ef4f00e8d4f125177d645c33e7b49b5abf12252517db15f04d2",
          "log10_closed_bracket": [
            1540,
            1541
          ]
        },
        "phase_A_cap_source_traffic_on_excess_rows": {
          "exact_expression": "alpha*T/3",
          "fraction_sha256": "8f2a4c3e976d62f5cdd2fd0733f10d30e33cfa4c521d7971e367659458c4c3ed",
          "log10_closed_bracket": [
            1511,
            1512
          ]
        },
        "phase_A_entire_row_paid_traffic": {
          "exact_expression": "0",
          "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
          "log10_closed_bracket": null
        },
        "phase_A_excess_source_mass": {
          "exact_expression": "alpha*(1-theta)*W",
          "fraction_sha256": "7108aac000379a2ed38e0ca97138475096df116b34f1acb47895ec09eaef19f4",
          "log10_closed_bracket": [
            1540,
            1541
          ]
        },
        "phase_A_excess_source_traffic_on_excess_rows": {
          "exact_expression": "2*alpha*T/3",
          "fraction_sha256": "a3587be52968b674db64ee9a266d4a4209f3b2cd36e068fd97fd86944158f4cc",
          "log10_closed_bracket": [
            1511,
            1512
          ]
        },
        "phase_A_original_row_excess_traffic": {
          "exact_expression": "alpha*T",
          "fraction_sha256": "0cc3d15a3c052f68086970163394694572ea1fe977015f27d2b5daa218c7136f",
          "log10_closed_bracket": [
            1512,
            1513
          ]
        },
        "phase_A_terminal_mass": {
          "exact_expression": "alpha*W",
          "fraction_sha256": "a7d5f88de4b767961913d160aeeb06e02f4d5960c8b2f86e8992e8f1cd7fea27",
          "log10_closed_bracket": [
            1540,
            1541
          ]
        },
        "phase_probability_alpha": {
          "directed_decimal_interval": [
            "0.135070870467745658",
            "0.135070870467745659"
          ],
          "exact_expression": "((16*n-32)/(16*n))^n",
          "fraction_sha256": "0fccd95d2f28d8bce012cb8751618b87210206658a0933b6f87c3801d97df36c",
          "log10_closed_bracket": [
            -1,
            0
          ]
        },
        "positive_certified_traffic_fraction_of_T": {
          "directed_decimal_interval": [
            "0.135070870467745658",
            "0.135070870467745659"
          ],
          "exact_expression": "alpha",
          "fraction_sha256": "0fccd95d2f28d8bce012cb8751618b87210206658a0933b6f87c3801d97df36c",
          "log10_closed_bracket": [
            -1,
            0
          ]
        },
        "symbolic_row_payment_price": "C_cell*sqrt_n*phase_A_cap_source_mass; C_cell=64*exp(4)*C2^2/beta^2, C2 unassigned",
        "theta": {
          "directed_decimal_interval": [
            "0.333333333333333333",
            "0.333333333333333334"
          ],
          "exact_expression": "1/3",
          "fraction_sha256": "0d7f0e336166042f8cc9e4c20ae427ba367c279d6e3dfd1bd7247b0fbce61d50",
          "log10_closed_bracket": [
            -1,
            0
          ]
        },
        "unresolved_good_traffic_outside_A": {
          "exact_expression": "T_good-alpha*T",
          "fraction_sha256": "12608ddb6219c95e85ca5119a0f253f8f33071f0634a52d73f6169f491b260f4",
          "log10_closed_bracket": [
            1512,
            1513
          ]
        },
        "unresolved_source_phase_mass": {
          "exact_expression": "(1-alpha)*W",
          "fraction_sha256": "edc1486bef595ee0e9bde3b344a2835d73a6c35d9dc265de7645784daca83baf",
          "log10_closed_bracket": [
            1541,
            1542
          ]
        }
      },
      "depth": 4,
      "dimension": 1024,
      "f_peak": "128",
      "f_row": {
        "directed_decimal_interval": [
          "3.000000000000000000",
          "3.000000000000000000"
        ],
        "exact_expression": "3",
        "fraction_sha256": "02925afd44e2946e583a7f6434585a77c146fcf4533cd4b3793f62f0d5b7c60c",
        "log10_closed_bracket": [
          0,
          1
        ]
      },
      "finest_leaf_volume": {
        "exact_expression": "(16*n)^n",
        "fraction_sha256": "a14e25017a035df8467002a8ba54f881fd7e7fe9618e9b57477ae27b99daf426",
        "log10_closed_bracket": [
          4315,
          4316
        ]
      },
      "full_f_mass": {
        "exact_expression": "f_row * enclosing_box_volume",
        "fraction_sha256": "a57c185eefee46c8397a49bc066d441c91ed7e1db1443954ab0fbbcd4d294c7d",
        "log10_closed_bracket": [
          1541,
          1542
        ]
      },
      "initial_pointwise_cap_mass": {
        "exact_expression": "sqrt_n * occupied_source_volume",
        "fraction_sha256": "e107853f25e4f99fade20715864c1947100846fe4b9dbf72cc66b00c57ac8ee9",
        "log10_closed_bracket": [
          1541,
          1542
        ]
      },
      "max_full_f_birth_proxy_cell_mass": {
        "exact_expression": "f fine-cell mass specified in protocol",
        "fraction_sha256": "ca873b61c4877054e64f4dce70e911dfd4a902de8e0c238c55ec2eb727c96815",
        "log10_closed_bracket": [
          -3081,
          -3080
        ]
      },
      "max_source_cell_mass": {
        "exact_expression": "source fine-cell mass specified in protocol",
        "fraction_sha256": "763738334f46fbd9b4840ecc9ca9cbdb4ca3c2cd538567553fcb69eedfe8cc4e",
        "log10_closed_bracket": [
          -3081,
          -3080
        ]
      },
      "occupied_source_volume": {
        "exact_expression": "3*32^n/128",
        "fraction_sha256": "d2678fd950b94a90e006887552aeb9b90415c5c52e84aa365d718a940cf5a6f2",
        "log10_closed_bracket": [
          1539,
          1540
        ]
      },
      "original_source_row": {
        "directed_decimal_interval": [
          "2.250000000000000000",
          "2.250000000000000000"
        ],
        "exact_expression": "9/4",
        "fraction_sha256": "aceea65272192df3e9cee56f5c2b5e7bc88abad6a54dc4b3c98254d079fc5242",
        "log10_closed_bracket": [
          0,
          1
        ]
      },
      "p_bad_full_uniform": {
        "directed_decimal_interval": [
          "0.060588729045947683",
          "0.060588729045947684"
        ],
        "exact_expression": "1-(1-1/(16*n))^n",
        "fraction_sha256": "300a8a0f7a3d0970b54fe97588e4b8e29a7a2937862f8b8d141bd449772f4f4e",
        "log10_closed_bracket": [
          -2,
          -1
        ]
      },
      "receiver_volume": {
        "exact_expression": "30^n",
        "fraction_sha256": "0445263e434d573c593e121e74aabd86f3e2159b28d28ea33982286d6cb8ab03",
        "log10_closed_bracket": [
          1512,
          1513
        ]
      },
      "s0": 136471,
      "s_star": 16384,
      "scope": "exact cap-first residual; canonical inequalities only; no original FULL forest",
      "source_enclosing_box_volume": {
        "exact_expression": "32^n",
        "fraction_sha256": "2b2a10db22ec6329b78c225229a8ae804114032132340cd864290082f3bed7b8",
        "log10_closed_bracket": [
          1541,
          1542
        ]
      },
      "source_peak": "96",
      "sqrt_n": 32,
      "tree_source_mass": {
        "exact_expression": "source_row * enclosing_box_volume",
        "fraction_sha256": "cbf44edd4b1ff56a5c31336694c0f9ec0f139f96762ae050a006f6d4bf1b8d38",
        "log10_closed_bracket": [
          1541,
          1542
        ]
      }
    }
  ],
  "status": "PASS"
}
```
<!-- R106-NUMERIC-RESULT-END -->

## 实际验证与复现记录

数值作者按执行前冻结的三个输入运行一次，主代理将完整程序复制到新临时目录后独立运行一次。两次均退出码0；隔离重放标准错误为空；输出41034字节逐字节相同。程序只用Python标准库，整数和Fraction保存实际物理量，exp固定256项、ln2固定128项，并用已证明的余项方向认证严格不等式。没有随机抽样、参数扫描或在失败后增加项数。

共有257项通过检查，包含守恒关系、参数门、几何不等式和显示量的正性/十进对数夹取，不称257个独立实验。三个实例仅验证所列机制：n=4正密度停止，n=64正细格容量整行付款，n=1024正超容量余行。完整f行与余额行分别记录；全均匀平移边界交通精确计算，仅正测度相位域内部作终端细分，域外来源质量及交通不丢失。

程序SHA-256：`2b3bab131abc13ce8fd8feefab5b84486e6dcfdbed32820b3b1b30fd10cd2ee8`。
确定性JSON输出SHA-256：`2f781bf8595dfee6f7fcce808fec65146863719ade361572f22ed60e7de8ccec`。

复现：解压research.zip，从proof.md最后唯一标明“公开几何核验证程序”的Python代码块提取为numeric.py，运行 `python3 numeric.py`。stdout应与报告中R106-NUMERIC-RESULT-BEGIN和END之间的JSON代码块（包括末尾换行）完全一致，并得到上述哈希。默认无参数运行不修改任何文件；`--record`仅用于作者首次落账，复现不要使用。精确巨数以表达式、有理分子/分母哈希及整数十进对数有向夹取紧凑记录，程序内部仍保留完整Fraction。

数学模块采用准确命题预审及最终全文核验；主代理另核tree、逐叶cap、真实共同核、FULL必要约束、统一列价与总账。数值代码全文静态审核与结果核对独立于作者，未据数值通过宣布一般定理。新增top-k和无限列价剥离是自含解析证明；本轮三输入数值不额外声称已检验它们的任意配置。

公开归档只取标明的最终数学正文、完整有限数值结果及必要复现程序。独立原门文献核验说明适用范围，未把历史阅读卡冒充本轮全部原文重读。LaTeX文本保留每个显示公式；仅检查结构、环境和分隔符，不运行TeX编译、不生成PDF。归档只含proof.md、proof.tex.txt、inventory.json三个成员。

一般目标未证明；全部有限数值检查不能替代高列分布重尾核心的根阶预算，也没有给出任意输入统一已付比例。已付与未付来源、真实接收测度和所有小量误差均须按总账共同使用。


## 公开几何核验证程序

```python
#!/usr/bin/env python3
"""Frozen R106 three-input exact certificate. No sampling or adaptive precision.
Default: deterministic JSON on stdout. --record PATH appends that JSON to the
owned numeric.md, once; replay without --record never mutates any files.
"""
from fractions import Fraction as F
from math import isqrt
from hashlib import sha256
import json
import sys
from pathlib import Path

sys.set_int_max_str_digits(0)
CHECKS = []


def check(label, condition):
    if not condition:
        raise ArithmeticError('UNKNOWN: ' + label)
    CHECKS.append(label)


def exp_bounds(t):
    """256 terms; omitted-term ratios after term 256 are <= t/257."""
    t = F(t)
    term = F(1)
    total = F(0)
    for k in range(256):
        total += term
        term *= t / (k + 1)
    check('exp fixed menu and convergent tail ' + str(t),
          t in [F(2), F(8), F(32), F(1, 8), F(1, 3)] and t < 257)
    return total, total + term / (1 - t / 257)


def ln2_bounds():
    lo = sum((F(2, (2*k+1)*3**(2*k+1)) for k in range(128)), F(0))
    tail = F(2, 257*3**257) / (1 - F(1, 9))
    return lo, lo + tail


def ceil_fraction(x):
    return -((-x.numerator) // x.denominator)


def digest(x):
    x = F(x)
    return sha256((str(x.numerator) + '/' + str(x.denominator)).encode()).hexdigest()


def pow10(k):
    return F(10**k) if k >= 0 else F(1, 10**(-k))


def integer_log_bracket(x):
    """Directed log10 enclosure, using integers only, with no log calls."""
    x = F(x)
    if x == 0:
        return None
    check('nonnegative physical display value', x > 0)
    k = len(str(x.numerator)) - len(str(x.denominator))
    if x < pow10(k):
        k -= 1
    elif x >= pow10(k+1):
        k += 1
    check('exact integer log10 bracket', pow10(k) <= x < pow10(k+1))
    return [k, k+1]


def ratio_interval(x, digits=18):
    """Closed directed decimal enclosure at a frozen display resolution."""
    x = F(x)
    scale = 10**digits
    low = (x.numerator*scale) // x.denominator
    high = low if F(low, scale) == x else low+1
    def dec(z):
        sign = '-' if z < 0 else ''
        z = abs(z)
        return sign + str(z//scale) + '.' + str(z % scale).zfill(digits)
    return [dec(low), dec(high)]


def quantity(expr, value, small=False):
    value = F(value)
    out = {'exact_expression': expr, 'fraction_sha256': digest(value),
           'log10_closed_bracket': integer_log_bracket(value)}
    if small:
        out['directed_decimal_interval'] = ratio_interval(value)
    return out


def stage(n, exp, ln2):
    k = isqrt(n)
    check(f'n={n}: exact square', k*k == n)
    s = 16*n
    s0lo = ceil_fraction(6*k*(1+n*ln2[0]))
    s0hi = ceil_fraction(6*k*(1+n*ln2[1]))
    check(f'n={n}: unique canonical integer', s0lo == s0hi)
    s0 = s0lo
    D = 0
    S = s
    while S < s0:
        S *= 2
        D += 1
    check(f'n={n}: minimal tree depth', S >= s0 and (D == 0 or S//2 < s0))
    dvol = F(1, n**n)
    pb = 1-F(s-1, s)**n
    check(f'n={n}: exact bad probability in (0,1/16]', 0 < pb <= F(1,16))
    check(f'n={n}: strict c16 absorption budget', pb < F(1,8))
    leafvol = F(s**n)
    halo = F((s+2)**n)
    dense_threshold = 4*halo/k
    if n == 4:
        row = F(5,2)
        frow = row
        boxvol = F((4*S)**n)
        occupied = boxvol
        E = F((2*S)**n)
        W = row*boxvol
        Wf = W
        initial_cap = None
        source_peak = row
        fpeak = row
        mcell = row*dvol
        fcell = mcell
        alpha = F(1)
    else:
        H = 32
        boxvol = F(H**n)
        E = F((H-2)**n)
        frow = F(3)
        row = F(9,5) if n == 64 else F(9,4)
        source_peak = F(12) if n == 64 else F(96)
        fpeak = F(20) if n == 64 else F(128)
        duty = F(3,20) if n == 64 else F(3,128)
        occupied = duty*boxvol
        W = row*boxvol
        Wf = frow*boxvol
        initial_cap = k*occupied
        mcell = F(9,5)*dvol if n == 64 else 96*dvol
        fcell = 3*dvol if n == 64 else 128*dvol
        alpha = F(s-H,s)**n
        check(f'n={n}: actual pointwise residual peak', source_peak == fpeak-k)
        check(f'n={n}: complete initial cap ledger', W+initial_cap == Wf)
        check(f'n={n}: complete source-volume mass', source_peak*occupied == W)
        check(f'n={n}: exact physical f mean', fpeak*occupied == Wf)
        check(f'n={n}: initial cap row ledger', row+k*duty == frow)
        check(f'n={n}: stripe divides unit receiver', n*duty == F(48,5) if n == 64 else n*duty == 24)
        # In stage 2 the period is d, hence a unit interval contains n periods.
        # In stage 3 the period is one, with exactly 24 full hot fine cells.
        check(f'n={n}: phase A has positive measure and is all-good', 0 < alpha <= 1-pb)
        check(f'n={n}: phase A support fits unique finest leaf', H < s)
        check(f'n={n}: true terminal heavy', W > exp[F(k)][1])
        check(f'n={n}: true terminal below least dense threshold', W < dense_threshold)
        check(f'n={n}: canonical support fits', H < s0)
        check(f'n={n}: canonical middle mass upper', W < F(4*(s0+2)**n,k))
        check(f'n={n}: canonical low mean', W/F(s0**n) < 4*exp[F(1,3)][0]/k)
    T = row*E
    bad = pb*T
    good = (1-pb)*T
    check(f'n={n}: physical f hard row', 2 < frow <= 4)
    check(f'n={n}: source dominated by full f', 0 < source_peak <= fpeak)
    check(f'n={n}: active source capture', row >= F(1,12288))
    check(f'n={n}: true positive source and receiver', W > 0 and E > 0 and T > 0)
    check(f'n={n}: exact full-uniform traffic split', bad+good == T)
    birth_lower = exp[F(2)][0] / (k*exp[F(k)][1])
    check(f'n={n}: full-f fine-cell proxy is birth-deep', fcell < birth_lower)
    check(f'n={n}: finest halo exponential bound', halo/leafvol < exp[F(1,8)][0])
    common = {
      'dimension': n, 'sqrt_n': k, 's0': s0, 's_star': s, 'depth': D, 'S': S,
      'scope': 'standalone dense example; no canonical provenance' if n == 4 else
               'exact cap-first residual; canonical inequalities only; no original FULL forest',
      'f_row': quantity(str(frow),frow,True), 'original_source_row':quantity(str(row),row,True),
      'f_peak':str(fpeak), 'source_peak':str(source_peak),
      'source_enclosing_box_volume':quantity('(4*S)^n' if n == 4 else '32^n',boxvol),
      'occupied_source_volume':quantity('(4*S)^n' if n == 4 else ('3*32^n/20' if n==64 else '3*32^n/128'),occupied),
      'receiver_volume':quantity('(2*S)^n' if n==4 else '30^n',E),
      'finest_leaf_volume':quantity('(16*n)^n',leafvol),
      'full_f_mass':quantity('f_row * enclosing_box_volume',Wf),
      'tree_source_mass':quantity('source_row * enclosing_box_volume',W),
      'initial_pointwise_cap_mass':None if n==4 else quantity('sqrt_n * occupied_source_volume',initial_cap),
      'max_source_cell_mass':quantity('source fine-cell mass specified in protocol',mcell),
      'max_full_f_birth_proxy_cell_mass':quantity('f fine-cell mass specified in protocol',fcell),
      'birth_proxy_only':True,
      'T':quantity('source_row * receiver_volume',T),
      'p_bad_full_uniform':quantity('1-(1-1/(16*n))^n',pb,True),
      'T_bad_full_uniform':quantity('p_bad*T',bad),
      'T_good_full_uniform':quantity('(1-p_bad)*T',good),
      'all_phase_forest_classification_claimed':False,
    }
    if n == 4:
        fullroots = 3**n
        rootmass = row*leafvol
        certified = fullroots*rootmass
        unresolvedW = W-certified
        check('stage1: true dense root is not light', rootmass > exp[F(k)][1])
        check('stage1: true dense root qualification', rootmass >= dense_threshold)
        check('stage1: source antichain mass ledger', certified+unresolvedW == W)
        check('stage1: full good row dense payment', good <= k*certified)
        check('stage1: positive actual dense payment', good > 0)
        common['certified'] = {
          'full_dense_root_count_each_phase':fullroots,
          'dense_root_mass':quantity('(5/2)*64^4',rootmass),
          'dense_source_mass_lower_bound_full_uniform':quantity('3^4*(5/2)*64^4',certified),
          'unresolved_source_class_mass':quantity('W-3^4*(5/2)*64^4',unresolvedW),
          'actual_good_dense_traffic_exact_full_uniform':quantity('T_good',good),
          'actual_terminal_receiver_traffic_exact_full_uniform':quantity('0',0),
          'dense_payment_ratio':quantity('T_good/(sqrt_n*certified_dense_mass)',good/(k*certified),True),
          'paid_good_fraction_of_T':quantity('1-p_bad',1-pb,True),
        }
    else:
        theta = F(1) if n==64 else F(1,3)
        cellcount = (32*n)**n if n==64 else 3*(32*n)**n//128
        check(f'n={n}: exact finecell count and source mass', cellcount*mcell == W)
        check(f'n={n}: prescribed cap factor', min(F(1),k*dvol/mcell) == theta)
        capW = theta*W
        excW = (1-theta)*W
        caprow = theta*row
        excrow = (1-theta)*row
        highcount = 0 if n==64 else cellcount
        highvol = highcount*dvol
        paid = alpha*T if caprow >= row/2 else F(0)
        excT = alpha*T-paid
        unresolvedW = (1-alpha)*W
        unresolvedT = good-alpha*T
        check(f'n={n}: per-leaf source cap conservation', capW+excW == W)
        check(f'n={n}: phase-mass ledger', alpha*capW+alpha*excW+unresolvedW == W)
        check(f'n={n}: full traffic ledger including outside A', bad+paid+excT+unresolvedT == T)
        check(f'n={n}: unresolved traffic retained nonnegative', unresolvedT >= 0)
        check(f'n={n}: full high-cell occupancy bound', highvol <= W/k < 4*halo/n)
        check(f'n={n}: source cap and excess row sum', caprow+excrow == row)
        if n==64:
            check('stage2: positive full-row cap payment', paid > 0 and excT == 0)
            check('stage2: new residual peak exceeds pointwise cap', source_peak > k)
            check('stage2: cell mean fits cap despite peak', mcell < k*dvol)
            check('stage2: actual price ratio at most one', paid <= k*alpha*capW)
        else:
            check('stage3: positive original full-row excess', excT > 0 and paid == 0)
            check('stage3: strict excess capture half gate', excrow > row/2 >= F(1,24576))
            check('stage3: positive high finecell mean', mcell > k*dvol)
            check('stage3: retained cap-source on excess row', alpha*T/3+2*alpha*T/3 == excT)
            check('stage3: physical high-cell volume', highvol == F(3,128)*boxvol)
        common['certified'] = {
          'phase_probability_alpha':quantity('((16*n-32)/(16*n))^n',alpha,True),
          'phase_A_terminal_mass':quantity('alpha*W',alpha*W),
          'fine_cell_count':quantity('(32*n)^n' if n==64 else '3*(32*n)^n/128',cellcount),
          'theta':quantity(str(theta),theta,True),
          'phase_A_cap_source_mass':quantity('alpha*theta*W',alpha*capW),
          'phase_A_excess_source_mass':quantity('alpha*(1-theta)*W',alpha*excW),
          'cap_capture_row':quantity(str(caprow),caprow,True),
          'excess_capture_row':quantity(str(excrow),excrow,True),
          'phase_A_entire_row_paid_traffic':quantity('alpha*T' if n==64 else '0',paid),
          'phase_A_original_row_excess_traffic':quantity('0' if n==64 else 'alpha*T',excT),
          'phase_A_cap_source_traffic_on_excess_rows':quantity('0' if n==64 else 'alpha*T/3',F(0) if n==64 else alpha*T/3),
          'phase_A_excess_source_traffic_on_excess_rows':quantity('0' if n==64 else '2*alpha*T/3',F(0) if n==64 else 2*alpha*T/3),
          'unresolved_source_phase_mass':quantity('(1-alpha)*W',unresolvedW),
          'unresolved_good_traffic_outside_A':quantity('T_good-alpha*T',unresolvedT),
          'high_cell_count':quantity('0' if n==64 else '3*(32*n)^n/128',highcount),
          'high_cell_full_volume_per_certified_leaf':quantity('0' if n==64 else '3*32^n/128',highvol),
          'high_cell_occupancy_fraction_of_leaf':quantity('high_cell_full_volume/(16*n)^n',highvol/leafvol),
          'canonical_mean':quantity('W/s0^n',W/F(s0**n)),
          'actual_row_payment_to_sqrt_mass_ratio':quantity('paid_A/(sqrt_n*cap_mass_A)',paid/(k*alpha*capW),True),
          'symbolic_row_payment_price': 'C_cell*sqrt_n*phase_A_cap_source_mass; C_cell=64*exp(4)*C2^2/beta^2, C2 unassigned',
          'positive_certified_traffic_fraction_of_T':quantity('alpha',alpha,True),
        }
    return common


def produce():
    exp = {t:exp_bounds(t) for t in [F(2),F(8),F(32),F(1,8),F(1,3)]}
    ln2 = ln2_bounds()
    stages = [stage(n,exp,ln2) for n in [4,64,1024]]
    bounds = {str(t):{'lower_fraction_sha256':digest(v[0]),'upper_fraction_sha256':digest(v[1]),
                     'relative_width_upper':ratio_interval((v[1]-v[0])/v[0])} for t,v in exp.items()}
    report = {
      'status':'PASS', 'protocol':'R106 frozen residual-consistent 3-stage menu',
      'arithmetic':{'physical_quantities':'exact Python Fraction', 'ln2_terms':128,'exp_terms':256,
                    'exp_positive_parameters':['2','8','32','1/8','1/3'],
                    'exp_bound_hashes':bounds,'ln2_directed_interval':ratio_interval(ln2[0]) + ratio_interval(ln2[1]),
                    'quantity_hash_serialization':'sha256(str(numerator)+"/"+str(denominator))',
                    'log10_brackets':'exact comparisons 10^k<=x<10^(k+1); zero=null'},
      'stages':stages, 'checks_passed':len(CHECKS), 'check_labels':CHECKS,
      'not_claimed':['original FULL/FIRST forest','upstream component/corridor provenance',
                     'full-uniform exact stop/cap/excess classification outside certified domains',
                     'uniform paid fraction for arbitrary input','general root-order endpoint bound'],
      'replay':'run this file with no arguments; compare stdout JSON with numeric.md stored JSON',
    }
    return json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+'\n'


def main():
    try:
        payload = produce()
    except Exception as exc:
        print(json.dumps({'status':'UNKNOWN','reason':str(exc),'checks_completed':len(CHECKS)},ensure_ascii=False))
        return 2
    if len(sys.argv)==1:
        print(payload,end='')
        return 0
    if len(sys.argv)==3 and sys.argv[1]=='--record':
        path=Path(sys.argv[2])
        previous=path.read_text()
        marker='<!-- R106-NUMERIC-RESULT-BEGIN -->'
        if marker in previous:
            print('UNKNOWN: producer result already exists; refusing a second record')
            return 2
        block='\n## Frozen single-producer result\n\n'+marker+'\n```json\n'+payload+'```\n<!-- R106-NUMERIC-RESULT-END -->\n\n'
        previous=previous.replace('<!-- PUBLIC-END -->',block+'<!-- PUBLIC-END -->')
        previous=previous.replace('FROZEN, NOT YET EXECUTED','FROZEN, SINGLE PRODUCER PASS')
        previous += '\nPRIVATE producer receipt: one invocation completed; deterministic report SHA256 '+sha256(payload.encode()).hexdigest()+'. Parent isolated replay remains separate.\n'
        path.write_text(previous)
        parsed=json.loads(payload)
        print(json.dumps({'status':'PASS','checks_passed':parsed['checks_passed'],
                          'report_sha256':sha256(payload.encode()).hexdigest(),
                          'dimensions':[4,64,1024], 'recorded_in':str(path)},ensure_ascii=False))
        return 0
    print('Usage: numeric.py [--record path/to/numeric.md]')
    return 2


if __name__=='__main__':
    sys.exit(main())
```
