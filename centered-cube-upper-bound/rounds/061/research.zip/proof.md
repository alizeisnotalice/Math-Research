# Round 61: bounded total replacement, signed projection, and localized capacity

2026-10-11. **The general centered-cube weak bound sqrt(n)n^{o(1)} is not proved.** The retained fully general benchmark is O(n log n). This round develops an interface for arbitrary finite positive sources, diagnoses two independent missing estimates, and tests actual cube profiles. It does not replace the requested theorem by a finite optimization problem.

## Goal and retained inputs

For the centered axis-parallel cube maximal operator, the desired weak constant is at most sqrt(n)L(n), with L(n)=n^{o(1)} uniformly in the source, threshold, atom count, and scale depth. Write u=n log L and D_mu(x,u)=A_{u+1}mu(x)-A_u mu(x). The receiver restriction is always the original G={M mu<=H}; it is never recomputed from a proposed replacement. The mass is W=mu(R^n).

The retained Round57 all-L2 spectral estimate is ||D_F||_2^2<=kappa_n||F||_2^2, with kappa_n<=3log(n+2)/n. Consequently a positive mass-W density F bounded by beta H costs at most kappa_n beta HW in the spectral part. At beta=n this cost is logarithmic. The required input-specific signed error is a separate quantity. Round60 excluded charging its complete history by total positive drift and excluded the proposed absolute transport-column shortcut; those failures are retained.

This round proves: (i) a well-posed relaxed output projection with exact-mass approximation; (ii) its signed dual, optimality conditions, and a nonnegative gap identity; (iii) a finite-atom localized allocation at height 3^n H and the exact Hall condition needed for a smaller height; (iv) genuine source tests exposing trace bookkeeping and capacity-height shortcuts. These statements do not give a source-uniform mixed-error upper bound.

## Current skills and evidence boundary

All 64 current top-level mathematical SKILL.md files were checked again: 277108 bytes in total, all SHA-256 values equal the Round55 manifest; 437 direct local links exist. The reported update is not visible as a further change in those main files. Current D01/F04/F05/L01/L02/L03/L04 instructions and the actually used method/interface files were reread by the responsible agents. This is not a claim that every linked paper was reread, that every skill has passed a complete mathematical audit, or that finite numerical evidence certifies an operator bound.

D01 is used to distinguish genuine positive marginal constraints from merely naming a transport theorem. F05 requires the actual signed Gram form rather than its trace. L03/L04 require separate feasibility, objective directions, and arithmetic-error accounting. No unverified advanced duality theorem is imported: the finite allocation and Hilbert duality statements below are proved directly.

## Why the new interface does not yet close the theorem

The triangle inequality gives

    E_H(mu)^(1/2) <= ||D_mu-D_F||_(G x R) + sqrt(kappa_n beta HW).

Therefore a proved affordable mixed-error bound would transfer to the capped energy. Neither choosing F by minimization nor writing its exact dual estimates that minimum. For beta=n, the minimum is trapped between (sqrt(E_H)-sqrt(kappa_n n HW))_+ and sqrt(E_H); it still carries the unresolved difficulty.

Localized geometric allocation has two logically independent tests: total density must fit the Hall capacities, and the signed mixed error must be affordable. The current 3^n-height construction passes the first test only at an unaffordable height. Even a future O(n)-height allocation would still require the second test. Conversely a nonlocal bounded replacement might work without satisfying these particular localization constraints; failure of a stronger geometric construction would not disprove the original maximal theorem.

Passing from a finite-cell numerical model to the continuum requires a bound for receiver integration, true cap geometry, and arithmetic errors. The calculations below provide exact rational mass/height witnesses, but the computed objectives remain numerical quadratures. The adjoint in the full Hilbert-space dual is an L2 equivalence class; it must not be evaluated at source atoms without a separately justified pointwise representative or finite-time limiting argument.

The final weak-type and all-scale return is not claimed from a projection identity or a capacity statement. All constants in any eventual closing lemma must be independent of N, source entropy, input depth, and the optimization discretization.


# Round 61: signed bounded-density replacement

This audit proves a variational interface, an exact primal–dual gap formula, and two obstructions to shortcuts. It does **not** prove a source-uniform mixed-error budget or the general centered-cube weak estimate. 

## Current methods and scope

The current F04, F05, D01, and L03 skill files and their `references/method.md` and `references/cube-interface.md` files were reread. F04 does not authorize treating cube differences as a heat semigroup. F05 does not turn a PSD trace into a bound for the all-ones quadratic form. D01 requires actual marginals and a proved link between transport and the target error. L03 distinguishes numerical optimization from a proof certificate. The arguments below are direct Hilbert-space and scalar threshold arguments; no external duality theorem is invoked.

Fix a finite positive atomic source

\[
 \mu=\sum_{i=1}^N p_i\delta_{y_i},\qquad p_i>0,\quad W=\sum_i p_i,
 \qquad G=\{x:M\mu(x)\le H\}.
\]

The receiver set is always this original source's good set. Put

\[
 A_u\nu(x)=e^{-u}\nu\bigl(x+[-e^{u/n}/2,e^{u/n}/2]^n\bigr),\qquad
 D_\nu(x,u)=A_{u+1}\nu(x)-A_u\nu(x).
\]

Let \(\mathcal Y=L^2(G\times\mathbb R,dx\,du)\), \(b=D_\mu|_G\), and \(TF=D_F|_G\). There is a direct finite-source proof that \(b\in\mathcal Y\), without using the entropy estimate. Put \(c=1-e^{-1}\) and \(v_i(x)=(2\|x-y_i\|_\infty)^n\). On \(G\), \(v_i\ge p_i/H\), because the cube of that radius captures atom \(i\). The single-atom time energy is exactly \(c p_i^2/v_i^2\). Also \(|\{x:v_i(x)\le t\}|=t\) for \(t>0\). Consequently

\[
 \|D_{p_i\delta_{y_i}}\|_{\mathcal Y}^2
 \le c p_i^2\int_{p_i/H}^{\infty}v^{-2}\,dv=cHp_i,
 \qquad E_H(\mu)\le cH\left(\sum_i\sqrt{p_i}\right)^2\le cHNW,
\]

where the last two inequalities are the finite Hilbert triangle inequality and Cauchy–Schwarz. This is an integrability bound, not a source-uniform estimate. The retained full-source theorem gives

\[
 \|TF\|_{\mathcal Y}^2\le\kappa_n\|F\|_2^2,
 \qquad \kappa_n\le 3\log(n+2)/n.
\]

Thus \(T:L^2(\mathbb R^n)\to\mathcal Y\) is bounded. We write \(E=\|b\|^2\), and choose a total density ceiling \(\rho=\beta H\); the intended affordable choice is \(\beta\asymp n\).

## 1. Exact mass can be imposed without changing the infimum

Define

\[
 K^-_{\rho,W}=\{F\in L^2:0\le F\le\rho\text{ a.e.},\ \int F\le W\},\qquad
 K_{\rho,W}=\{F\in K^-_{\rho,W}:\int F=W\}.
\]

The submass set is convex and weakly compact in real \(L^2\). Indeed \(\|F\|_2^2\le\rho W\). The order constraints are norm-closed convex constraints, hence weakly closed. The mass constraint is the intersection of the weakly closed inequalities \(\int_{B_R}F\le W\), with integer radii \(R\), because \(F\ge0\). Weak compactness follows from reflexivity. Consequently the quadratic objective attains a minimum on \(K^-\). Its optimal output \(TF_*\) is unique: if two distinct outputs minimized the distance, their midpoint would strictly reduce the squared distance.

The exact-mass set is not weakly closed on the whole space: a fixed compact density translated to infinity converges weakly to zero. This observation alone does not establish nonattainment for the actual cube objective. We do not claim exact-mass attainment.

Nevertheless exact mass and submass have equal infima. Given \(F\in K^-\), let \(\delta=W-\int F\). On a large bounded measurable region \(R\), set

\[
 C_R=\int_R(\rho-F),\qquad
 g_R=\frac{\delta}{C_R}(\rho-F)\mathbf1_R.
\]

If \(\delta=0\), use \(g_R=0\). Otherwise \(C_R\ge\rho|R|-W\to\infty\), and choose \(C_R\ge\delta\). Then \(F+g_R\in K\), and

\[
 \|g_R\|_2^2\le\|g_R\|_\infty\int g_R
 \le\frac{\rho\delta^2}{C_R}\longrightarrow0.
\]

The boundedness of \(T\) proves

\[
 d^2:=\min_{F\in K^-}\|b-TF\|^2
 =\inf_{F\in K}\|b-TF\|^2.
\]

This also produces concrete exact-mass approximants to the relaxed optimum, with
\(\|b-T(F_*+g_R)\|\le d+\sqrt{\kappa_n\rho}\,\delta/\sqrt{C_R}\).

## 2. Signed dual and a checkable gap identity

For \(a\in L^2\), the scalar support function is

\[
 s(a)=\sup_{F\in K^-}\int aF
 =\min_{\lambda\ge0}\left\{\lambda W+\rho\int(a-\lambda)_+\right\}.
\]

Proof: every feasible \(F\) satisfies \(\int aF\le\lambda W+\rho\int(a-\lambda)_+\). If \(|\{a>0\}|\le W/\rho\), take \(\lambda=0\) and \(F=\rho\mathbf1_{\{a>0\}}\). Its objective is finite by Cauchy–Schwarz on this finite-measure set. Otherwise choose \(\lambda>0\) with
\(|\{a>\lambda\}|\le W/\rho\le|\{a\ge\lambda\}|\); fill \(\{a>\lambda\}\) at height \(\rho\), fill the necessary fraction of the level set, and set the density to zero below that level. Such a threshold follows from monotonicity and the right/left limits of the distribution function. For positive \(\lambda\), \(\int(a-\lambda)_+\) is finite since \((a-\lambda)_+\le a_+^2/(4\lambda)\). These choices attain equality. The same support value holds for \(K\), by the completion lemma and continuity of pairing with \(a\).

For \(h\in\mathcal Y\), put \(a=T^*h\). Then

\[
 \boxed{d^2=\sup_{h\in\mathcal Y,\ \lambda\ge0}
 \left[2\langle b,h\rangle-\|h\|^2-2\lambda W
       -2\rho\int(T^*h-\lambda)_+\right].}
\]

An infinite hinge integral gives value \(-\infty\). The expression is a **lower** bound for the distance for every test pair; it is not an upper budget. To prove equality without invoking an abstract strong-duality theorem, choose the relaxed minimizer \(F_*\), set \(h_*=b-TF_*\), and differentiate the objective along the segment from \(F_*\) to any feasible \(F\). This gives
\(\langle T^*h_*,F-F_*\rangle\le0\). Hence \(F_*\) attains the scalar support function, and substitution yields equality.

For any feasible \(F\in K^-\) and any finite dual test \((h,\lambda)\), write \(m=\int F\). The following is an **exact** identity:

\[
\begin{aligned}
 \|b-TF\|^2-\mathcal L(h,\lambda)
 ={}&\|b-TF-h\|^2+2\lambda(W-m)\\
 &+2\int\left[\rho(a-\lambda)_+-(a-\lambda)F\right].
\end{aligned}
\]

Every term on the right is nonnegative. This separates the Hilbert residual, unused mass, and pointwise threshold defect. At an optimum there is a threshold \(\lambda_*\ge0\) such that

\[
 h_*=b-TF_*,\qquad
 F_* =\rho\ \text{on }\{T^*h_*>\lambda_*\},\qquad
 F_*=0\ \text{on }\{T^*h_*<\lambda_*\},\qquad
 \lambda_*(W-\int F_*)=0.
\]

On the threshold level, any value in \([0,\rho]\) is permitted. Conversely these conditions imply optimality, by the gap identity. They characterize the optimum; they do not estimate its dimension dependence.

For a bounded receiver/time test, the adjoint has the actual cube form

\[
 T^*h(y)=\int_G\int_{\mathbb R}h(x,u)e^{-u}
 \left[e^{-1}\mathbf1_{2\|x-y\|_\infty\le e^{(u+1)/n}}
       -\mathbf1_{2\|x-y\|_\infty\le e^{u/n}}\right]du\,dx.
\]

The full adjoint is the \(L^2\) extension of this formula. Bounded compactly supported tests justify this expression directly by finite-time Fubini. An arbitrary \(h\in\mathcal Y\) is handled by \(L^2\) approximation, rather than assuming pointwise absolute integrability of an all-time signed kernel.

## 3. What distance control would buy, and why optimization alone is not a new upper bound

Every feasible density has \(\|TF\|\le R:=\sqrt{\kappa_n\rho W}\). The zero density is relaxed-feasible and exact-mass approximations have arbitrarily small \(L^2\) norm. Therefore

\[
 \boxed{(\sqrt E-R)_+\le d\le\sqrt E.}
\]

The left inequality is the Hilbert triangle inequality, applied to all feasible \(F\). If an independently proved construction or certificate gave \(d^2\le\varepsilon_n HW\), then

\[
 E_H(\mu)\le\bigl(\sqrt{\varepsilon_n}+\sqrt{\kappa_n\beta}\bigr)^2HW.
\]

For \(\beta=n\), the paid spectral term is at most \(3\log(n+2)\). Conversely any cap-energy estimate already bounds \(d^2\), by the right inequality. Thus declaring the optimized error uniformly affordable, without a feasible construction or a proved estimate for the objective, is a reformulation of the missing cap-energy estimate up to the known spectral radius. The dual is useful for lower-pressure certificates and validation, not an automatic upper-bound mechanism.

## 4. Couplings retain cancellation but do not create an extra optimization variable

For a positive coupling \(\gamma\) with first marginal \(\mu\) and second marginal \(F(y)dy\), total mass \(W\), let \(T_R\) denote receiver restriction and time restriction to \([-R,R]\). With \(k_y=T_R\delta_y\),

\[
 T_R\mu-T_RF=\int(k_y-k_z)\,d\gamma(y,z),
\]

and consequently

\[
 \|T_R\mu-T_RF\|^2
 =\iint\langle k_y-k_z,k_{y'}-k_{z'}\rangle
     d\gamma(y,z)d\gamma(y',z').
\]

This is the actual signed four-term Gram objective. The finite-time atom kernels have uniformly bounded Hilbert norm, independent of their centers, so both Bochner integration and this double Fubini are legitimate. The double integrand need not be pointwise positive. As \(R\to\infty\), the left side increases to \(\|b-TF\|^2\); the full outputs converge in the Hilbert space. We do not interchange the signed double integral with an all-time limit without a separate domination argument.

The formula depends only on the two marginals. Every feasible target density has a positive coupling, for example \(\mu(dy)F(z)dz/W\). Thus minimizing this signed objective over couplings is exactly the density problem above. A geometric coupling can help construct or analyze a feasible total density, but changing the plan at fixed marginals cannot improve the true quadratic error. Replacing this objective by a positive scalar transport cost introduces an additional majorization loss and is not justified by the signed identity.

## 5. An actual-source splitting test for diagonal bookkeeping

Fix \(\mu=p\delta_y\), its original good set, and a feasible density \(F\) with nonzero error \(e=b-TF\). Such a density exists: put a bounded compact target far from a bounded good receiver annulus and use a finite time interval in which the atom is captured while the target is not. The resulting error is nonzero on a positive-measure receiver/time set.

Split the same source into \(N\) identical atoms of mass \(p/N\), and use \(f_i=F/N\). Then every replacement is positive and has its source mass, while the total density and total capped error are unchanged. Nevertheless

\[
 e_i=e/N,\qquad C_{ij}=\langle e_i,e_j\rangle=\|e\|^2/N^2,
 \qquad \operatorname{tr}C=\|e\|^2/N,\qquad
 \mathbf1^TC\mathbf1=\|e\|^2.
\]

This is a PSD Gram matrix arising from the actual source and actual cube operator. It rules out a representation-independent conversion from a diagonal trace to total signed error. Duplicate merging avoids this particular representation, but does not supply an off-diagonal estimate for genuinely different atoms. The example is a bookkeeping obstruction, not a counterexample to the desired source-uniform cap-energy bound.

## 6. Finite numerical interface and the remaining lemma

A finite positive target-cell model should impose **total** density coefficients \(0\le F_j\le\rho\), mass \(\sum_j |Q_j|F_j=W\), and use the actual signed objective \(\|b-T\sum_jF_j\mathbf1_{Q_j}\|^2\). A primal feasible point yields an upper bound only for that represented operator/problem; a dual witness yields a lower bound. The gap formula supplies the correct directions and residuals. Receiver-cell, time-tail, cap-indicator, source-kernel, and arithmetic errors must be paid before a finite calculation certifies the continuum problem. High-precision agreement is a diagnostic and is not an outward-rounded certificate. No numerical results are asserted in this audit.

The missing general lemma is now precise: construct, for every finite positive source and its original good set, a positive exact-mass density with \(F\le CnH\) and

\[
 \|D_\mu-D_F\|_{L^2(G\times\mathbb R)}^2
 \le\varepsilon_n HW
\]

with a sufficiently small dimension-dependent \(\varepsilon_n\), while retaining all mixed signs. The variational theorem makes this a well-posed output projection and gives exact optimality and numerical certificate identities. It does not prove that missing uniform bound.



# Round 61: exact local Hall allocation at exponential height

2026-10-11. For every finite positive atomic source, the construction below preserves mass, stays in the original bad set, and moves each atom less than its distance to the original good set. Its proved height is \(3^nH\), not \(O(n)H\). It does not close the arbitrary-source signed-energy problem.

## Current skills and interfaces

The current disk versions of /Users/zhengzhihao/.codex/skills/math-d01-kantorovich-duality/SKILL.md and /Users/zhengzhihao/.codex/skills/math-l03-rational-and-interval-certificates/SKILL.md, together with each one's references/method.md and references/cube-interface.md, were re-read. D01 is used only for static positive couplings: equal mass, actual marginals and displacements, and a separate energy connection. No vector KR or path-law theorem is transferred. L03 distinguishes exact rational witnesses from floating evidence. The finite Hall proof is supplied here; no general arbitrary-cost transport strong duality or numerical interval claim is made.

## Definitions and boundaries

Let \(\mu=\sum_{i=1}^Np_i\delta_{y_i}\), \(p_i>0\), \(H>0\), and \(W=\sum_i p_i\). Use closed centered cubes \(Q(x,r)=x+[-r,r]^n\) and
\[
M\mu(x)=\sup_{r>0}\frac{\mu Q(x,r)}{(2r)^n},\quad G=\{M\mu\le H\},\quad\Omega=\{M\mu>H\}.
\]
For nonempty \(I\), write \(p_I=\sum_{i\in I}p_i\) and \(d_I(x)=\max_{i\in I}\|x-y_i\|_\infty\). Directly from the finite capture radii,
\[
M\mu(x)=\max_{I\ne\varnothing}\frac{p_I}{(2d_I(x))^n},
\]
with infinite value at zero denominator. Thus
\[
\Omega=\bigcup_{I\ne\varnothing}\bigcap_{i\in I}\{x:\|x-y_i\|_\infty<\tfrac12(p_I/H)^{1/n}\}
\]
is open and bounded. The set \(G\) is closed and nonempty, and every atom lies in \(\Omega\). Define
\[
r_i=\operatorname{dist}_\infty(y_i,G),\qquad S_i=y_i+(-r_i,r_i)^n.
\]
Each \(r_i\) is positive and finite. A nearest \(g_i\in G\) is attained, because a bounded minimizing sequence has a convergent subsequence and \(G\) is closed. The open cube \(S_i\) lies in \(\Omega\), and its boundary is Lebesgue null. Every cap used below is the original full-source cap, at the attained \(g_i\).

## Exact finite Hall criterion

For finite bounded Borel allowed sets \(S_i\) and \(B>0\), there exist \(f_i\ge0\), zero outside \(S_i\), with \(\int f_i=p_i\) and \(\sum_i f_i\le B\) almost everywhere if and only if
\[
p_I\le B\left|\bigcup_{i\in I}S_i\right|\quad\text{for every subset }I. \tag{H}
\]
Necessity follows by integrating on the union. For sufficiency partition the union into membership cells
\[
A_T=\{z:\{i:z\in S_i\}=T\},\qquad T\ne\varnothing.
\]
Use a finite network with source-to-\(i\) capacity \(p_i\), \(i\)-to-\(T\) capacity \(2W\) when \(i\in T\), and \(T\)-to-sink capacity \(B|A_T|\). A maximum flow exists by compactness of the finite feasible polytope. At a maximum no augmenting residual path exists; residual reachability therefore gives a minimum cut. A cut crossing an \(i\)-to-\(T\) edge costs at least \(2W\). Any cut crossing none, with source-side atom set \(I\), must place every cell touching \(I\) on the source side and costs at least
\[
W-p_I+B\left|\bigcup_{i\in I}S_i\right|\ge W.
\]
Thus a flow of value \(W\) exists. With its values \(a_{iT}\), set
\[
f_i(z)=\sum_{T:|A_T|>0}\frac{a_{iT}}{|A_T|}\mathbf1_{A_T}(z).
\]
Null cells carry zero flow. This yields the actual positive coupling
\[
\pi(dy,dz)=\sum_i\delta_{y_i}(dy)f_i(z)\,dz,\qquad \pi_1=\mu,\quad\pi_2=F\,dz,\quad F=\sum_i f_i.
\]
Equivalently, (H) says \(\sum_i p_i\lambda_i\le B\int\max_{i:z\in S_i}\lambda_i\,dz\) for all \(\lambda_i\ge0\), with empty maximum zero. Layer cake proves equivalence; indicator weights recover (H). This is a finite capacity certificate, not a general transport-cost dual claim.

## Localized \(3^n\)-Hall and construction

For the original cap-distance cubes,
\[
\boxed{p_I\le3^nH\left|\bigcup_{i\in I}S_i\right|\quad\text{for every }I.} \tag{1}
\]
Greedily select a remaining cube of largest radius and remove it and all intersecting cubes. Selected open cubes are disjoint. If \(i\) is removed with selected \(j\), then \(r_i\le r_j\) and
\[
\|y_i-y_j\|_\infty<r_i+r_j\le2r_j,\quad
\|y_i-g_j\|_\infty<3r_j.
\]
That cluster's complete mass is at most
\[
\mu Q(g_j,3r_j)\le H(6r_j)^n=3^nH|S_j|.
\]
Sum over the disjoint selected cubes, which lie in the full union. The same original cap is used for every subset. Applying (H) therefore gives
\[
\boxed{0\le F\le3^nH,\quad\int F=W,\quad F=0\text{ a.e. on }G,\quad
\|z-y_i\|_\infty<r_i\quad\pi\text{-a.e.}} \tag{2}
\]

The enclosing-radius factor \(3\) in this proof cannot simply be tightened to \(2\). In dimension one, let \(\mu=2H\delta_0+2H\delta_{2-\varepsilon}\), \(0<\varepsilon<1\). Direct enumeration of the single-atom and two-atom capture sets gives \(\Omega=(-1,3-\varepsilon)\), with both \(r_i=1\). The allowed intervals intersect. Whichever is selected, the other atom lies \(3-\varepsilon\) from the selected atom's nearest good point. This obstructs that enclosure strategy only; it does **not** prove the mass factor \(3^n\) sharp.

## Exact atomic pressure against a factor below \(2\)

In dimension one let \(y_j=jh\), \(p_j=2Hh\), \(j=0,\ldots,m-1\). At \(x=-d<0\), every capture is a prefix. The best average capturing its first \(k\) atoms is
\[
\frac{kHh}{d+(k-1)h}>H\quad\Longleftrightarrow\quad d<h.
\]
Interior points have a nearest atom within \(h/2\), giving maximal value at least \(2H\); the right exterior calculation is symmetric. Hence exactly
\[
\Omega=(-h,mh),\quad r_j=h\min(j+1,m-j),\quad W=2mHh.
\]
When \(m\) is odd, the middle allowed interval equals \(\Omega\), so the full-subset Hall ratio is exactly
\[
\frac{W}{H|\bigcup_jS_j|}=\frac{2m}{m+1}\longrightarrow2. \tag{3}
\]
Rational \(h,H\) give exact rational inputs. For \(m=3,5,9,33\) the ratios are \(3/2,5/3,9/5,33/17\). No claim that the full subset maximizes every finite example is needed.

For every fixed dimension, put \(s=2/m\), use the \(m^n\) cell centers of the grid in \([-1,1]^n\), and assign each atom mass \(2Hs^n\). Then \(W=2H2^n\), and
\[
\Omega\subset(-1-ns/2,1+ns/2)^n. \tag{4}
\]
Indeed, at an exterior coordinate \(x_j=1+d\), \(d\ge ns/2\), every capturing radius has \(r\ge d+s/2\). The grid-coordinate count is at most \((r-d+s/2)/s\) in that direction, and \(2r/s+1\) in each other direction. Thus with \(t=s/(2r)\) and \(A=2d/s-1\ge n-1\),
\[
\frac{A_{2r}\mu(x)}H\le(1-At)(1+t)^{n-1}\le1.
\]
The first factor is positive in the capturing regime, and its logarithmic derivative is
\[
-\frac A{1-At}+\frac{n-1}{1+t}\le0.
\]
Noncapturing radii give zero; left exterior coordinates are symmetric. This bounds all radii, not a finite scale sample. Since \(\bigcup_iS_i\subset\Omega\),
\[
\frac{W}{H|\bigcup_iS_i|}\ge\frac{W}{H|\Omega|}\ge2(1+ns/2)^{-n}\longrightarrow2 \tag{5}
\]
for fixed \(n\) as \(m\to\infty\). This is an explicit discrete estimate, with no unproved maximal-cap convergence interface.

Separately, the bounded density \(f=2H\mathbf1_{[-1,1]^n}\) has \(\Omega=(-1,1)^n\): interior points see \(2H\); at every exterior point each centered cube has overlap fraction at most \(1/2\) in some coordinate, giving \(Mf\le H\). Hence \(\int f=2H|\Omega|\). This is a genuine-density pressure; the preceding grid proof supplies its separate atomic counterpart.

## Destination-clearance capacity obstruction

For \(\mu=p\delta_y\), write \(r=\frac12(p/H)^{1/n}\), so \(\Omega=y+(-r,r)^n\). Every mass-preserving \(F\le\beta H\) supported there obeys
\[
\int_{\{\operatorname{dist}_\infty(z,G)\ge sr\}}F(z)\,dz
\le\beta(1-s)^np,\qquad0\le s\le1.
\]
Thus at least half the mass has destination clearance at most
\(r[1-(2\beta)^{-1/n}]\le r\log(2\beta)/n\).
Separately, at least half must move distance at least \(r(2\beta)^{-1/n}\), by the source-centered cube capacity. These are separate half-mass statements, with no simultaneous half-mass assertion. Requiring every destination to have clearance \(\gamma r\) forces \(\beta\ge(1-\gamma)^{-n}\). Height \(O(n)\) cannot retain a dimension-independent clearance fraction. This is capacity pressure for the existing two-endpoint transport cost, not a signed-energy lower bound.

## Exact remaining condition and scope

Define
\[
\Gamma_n=\sup_{\mu,H,I\ne\varnothing}
\frac{p_I}{H|\bigcup_{i\in I}Q^\circ(y_i,\operatorname{dist}_\infty(y_i,G))|},
\]
over finite positive atomic sources and their original cap sets. We have proved \(2\le\Gamma_n\le3^n\). By the exact Hall criterion, \(\Gamma_n=O(n\,\mathrm{polylog}(n))\) is equivalent to affordable-height allocation with these particular allowed sets. That estimate is unproved. A global bound for \(W/(H|\Omega|)\) omits proper-subset capacities. An affordable allocation would still need the total signed-error estimate paying mixed Gram terms; the Round 60 diagonal estimate alone does not provide it.

For an arbitrary non-atomic source, putting all mass into \(\Omega\) is impossible without qualification: a nonzero density bounded by \(H\) may have \(\Omega=\varnothing\). One must retain a suitable good-set density part or specify a source part to allocate. Only finite atomic allocation is proved here. No general-source limit, capped-energy convergence, or coupling compactness extension is silently claimed.


## A proved receiver-face aliasing obstruction in the actual capped problem

This section explains a numerical error discovered during this round. It is not a counterexample to the weak-type goal. Full-scale point energy can have a strict downward jump on a target-density cell face. Consequently a receiver quadrature aligned with those faces can undercount energy, even after all floating endpoint gaps have been removed.

Let q=exp(1/n), c_q=1-q^(-1), L0=1/(4q), W=2^(n-1),

    mu = W delta_{(-1/2,0,...,0)}, H=4W,
    F = 1_{[-1,0] x [-1,1]^(n-1)}, x_epsilon=(epsilon,0,...,0).

The positive replacement F has the same mass W, and F<=H. For 0<=epsilon<=L0/2, M mu(x_epsilon)=W/(1+2epsilon)^n<=W<H, so these are receivers in the original good set. At all 0<L<=L0 the two source averages vanish. Both replacement cubes see only the right flat face of F, giving A_L F(x_epsilon)=(1/2-epsilon/L)_+. At epsilon=0 this is 1/2 for both scales, and D_F=0 throughout the small-scale window.

For epsilon>0, set t=L/(2epsilon). On 1/q<=t<1 the difference is (1-1/(qt))/2; on t>=1 it is c_q/(2t), and below 1/q it is zero. Since du=n dt/t, direct integration gives

    J_n = n/4 (log q - 1 + q^(-1))
        = n/4 (1/n - 1 + exp(-1/n)) > 0,
    integral_{u <= n log L0} |D_mu-D_F|^2 du
        = J_n - n c_q^2 epsilon^2/(2 L0^2),  0<epsilon<=L0/2.

Indeed the entry integral is n/4[log q+2/q-1/(2q^2)-3/2], and the settling integral up to T=L0/(2epsilon) is n c_q^2(1-T^(-2))/8. Their sum is the displayed formula. Positivity of J_n follows from exp(-a)>1-a for a>0. For n=1, J_1=1/(4e).

The small-scale value is exactly zero at epsilon=0 but tends to J_n from the positive side of the flat face. The remaining u>=n log L0 energy is continuous here: the bounded-density averages are spatially continuous, atomic averages converge except at finitely many arrival times, and the fixed lower scale supplies an integrable O(W^2 exp(-2u)) majorant. Thus the full capped point-error energy also has a downward face jump. There is no contradiction with almost-everywhere integration or with the retained L2 spectral theorem. The moving small-scale contribution escapes to u=-infinity as epsilon tends to zero.

Numerical consequence: a fixed midpoint rule is unsafe when target-cell and receiver grids share faces, especially if the two grids are refined together. The final pressure calculations use rationally shifted receivers and independently changed receiver phases, plus same-target refinement. These changes remove the diagnosed face alignment; they do not furnish a continuum error bound. Pilot midpoint data are retained only as diagnostic evidence.

The formula was checked at n=1,2,4,16,64,1024,4096 and six positive epsilon/L0 values from 1/2 to 10^(-60), using independent antiderivative forms at Decimal 80 and 140 digits. All 42 pairs passed the stated tolerance checks. At 80 digits, the 10^(-120) tail correction can lie below rounding resolution: an initial strict decimal ordering test failed by up to about 2e-77, and was replaced by an explicitly reported tolerance comparison. The exact monotonicity comes from the analytic formula, not rounded decimal signs; these checks are not interval certification.


The finite replacement experiments favor optimizing the total signed error. They provide feasible positive step densities and accurate finite time quadrature, while spatial quadrature remains the main uncertainty. They do not establish a source-independent continuous replacement bound.

The actual source has mass W=1 and is one of: a spike, five unequal nearby atoms, nested depth8/16 (17/33 atoms), eight correlated diagonal atoms, or twelve seeded random atoms with unequal positive weights. Tests use n=1,2,3; β=1,n,2n (duplicates removed); mostly H1, with H4 threshold/cluster checks. Exact rational source weights are normalized to one. Receivers are integrated over [-2,2]^n using finite point rules on the true atomic cap G={Mμ≤H}; cap membership is determined by rational distance-volume arrival batches at the represented source/receiver coordinates.

The variable r_j is replacement mass in a cell C_j, not source-atom mass or density. The constraints are 0≤r_j≤βH|C_j| and ∑r_j=1, with replacement support [-1,1]^n. The signed feature column is the difference between the actual cube/cell intersection averages at sides L and e^(1/n)L. Positive quadrature weights give an explicit feature Gram. A self-contained accelerated projected-gradient method on the capped mass simplex minimizes the total squared error. No external optimization solver or package was installed; the existing bundled NumPy runtime is used.

Three initial midpoint/log-time pilot QPs expose source-time quadrature discrepancies of 1.5–3.4%. The final37 QPs use Gauss8/16 on every atom-arrival and cell-face breakpoint, including their divided-by-e^(1/n) partners. Additional geometric subdivisions bound each positive interval's endpoint ratio by1.5. The time window contains every nonzero difference at each receiver: below the first geometry event both profiles are constant, and beyond side2(R_receiver+1) their equal total masses are fully captured, so the replacement error is zero. The source-alone terminal tail is recorded separately for comparison with its analytical event integral.

Two mesh pitfalls were corrected before the final run. Direct Fraction construction of intended endpoints/midpoints removes artificial floating gaps. That alone does not solve true face aliasing: full-time density-difference energy can have an isolated downward jump exactly on a cell face. Final receivers therefore use shifted rational phases α_i=(37+11i)/101. All retained final receivers have positive distance to every target cell face; the minimum is .00353607. Four same-candidate checks use doubled receiver resolution and a second phase (73−7i)/103. The pilot midpoint rows remain diagnostic only.

Selected final finite-mesh errors, normalized by HW:

| Configuration | Optimized | Global uniform | Projected cell-average blobs |
|---|---:|---:|---:|
| n1 spike H1 β1 | .206406 | .446060 | .239696 |
| n2 spike H1 β2 | .373431 | .639476 | .406977 |
| n1 spike H4 β1 | .211362 | .554750 | .248900 |
| n1 depth16 H1 β1 | .044280 | .185286 | .062620 |
| n2 depth16 H1 β2 | .137700 | .307338 | .149499 |
| expanded n2 unequal cluster H1 β2 | .403222 | .731848 | .480048 |
| expanded n3 diagonal H1 β3 | .170896 | .257861 | .182551 |

The blob comparison first cell-averages independent source-centered uniform blobs of height βH. Its raw sum may violate the cell density cap;18 final cases do. The projected comparison is a feasible capped-simplex redistribution. These are actual cell step densities, rather than evaluations of the original continuous blob sum; cell-averaged raw overlap is separately recorded. Low errors from an infeasible raw comparison do not compete with the constrained optimum.

Spatial sensitivity remains substantial. For the identical optimized n2 cluster β2 candidate, the original estimate .507695 becomes .300534 on the doubled mesh and .418116 with the second phase. The n3 diagonal β3 candidate changes .262015 to .316719 and .190578. The n1 nested candidate is more stable: .044280 becomes .044461/.044442. For unit atoms the exact source energy inside this receiver box is c(1−1/(H4^n)), c=1−e^−1; the source mesh discrepancy reaches6.62% in n2. Neither refinement differences nor alternate phases certify a spatial error bound.

A loose exterior bound is available. Both positive mass-one sources have support inside [-1,1]^n. For r=||x||∞≥2, Jensen gives each source's full-time point energy at most c/[2(r−1)]^(2n). Integrate with n2^n r^(n−1)dr and use r≤2(r−1): each exterior energy is at most c/2. The triangle square bound for their difference therefore gives2c, or2c/H after normalization. This bound is independent of β and intentionally loose; it does not certify the sampled interior integral.

Final diagnostics: all40 QPs completed (3 pilot,31 pressure,1 threshold,2 depth,3 expanded). The maximum final Gauss8 source/event discrepancy is4.06e−14; Gauss16 is5.18e−15. The largest same-candidate order8/16 error change is2.25e−14. Direct weighted feature evaluation and Gram evaluation differ by at most4.00e−15. The maximum full-error Frank-Wolfe gap/H is1.99e−8, KKT infinity residual3.97e−7, and numerical mass residual1.12e−16; no numerical capacity violation occurs. A greedy gradient fill gives the finite-QP variational gap. Its reported primal-minus-gap interval concerns only this floating finite objective, with no lower bound on the unrestricted continuous replacement problem.

Each optimized vector also has an exact rational primal witness on ideal rational cells: nonnegative masses sum exactly to one and respect βH volume capacities. The largest correction from the floating optimizer is2.63e−16 in mass l2. The floating features use machine endpoints, so this proves feasibility of a real density, not its continuous objective value. No outward rounding is performed.

For the legitimate proportional allocation F_i=p_iF, the signed error Gram records trace, total, off-diagonal sum and normalized eigenvalue. Total/trace ranges from .17815 to3.03491 across final cases; mixed terms can cancel or reinforce. Exact label splitting guards separately show that splitting an unchanged atom into N labels and using F_i=F/N preserves total error while dividing trace by N. Diagonal information cannot determine the total signed error. Six positive-source and four zero-mass dipole event/Gram checks pass (maximum discrepancy1.67e−15). The dipole gate uses its positive total-variation source and is only an implementation guard, not a negative-source weak theorem.

Current L01/L02/L03/L04 skills and relevant local method/interface/provenance restrictions were reread. Feasible rational densities, floating finite-QP diagnostics, spatial exploration and continuous mathematical claims are kept separate. No exponent fit or general theorem is inferred.

Final run:80.184s, using existing Python3.12.14 and NumPy2.3.5. Runtime is printed but omitted from deterministic JSON. Reproduction command (run the script from any directory; output is results.json beside it):

```sh
OPENBLAS_NUM_THREADS=1 /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /Users/zhengzhihao/Desktop/T/output/centered_cube_round061_20261011/replacement_projection_probe.py
```

The script also sets its process BLAS thread limits to one and contains no absolute runtime import path. The only non-standard dependency is installed NumPy. The parent independently replayed from a temporary directory and obtained byte-identical JSON; the receipt below records that run.


## Parent exact guards and independent replay

The following standard-library code blocks are complete standalone guards. Save them under the indicated names in a temporary directory and run each with Python 3. Each writes its own deterministic JSON. These supplementary files are embedded here to keep the repository file count small.


### hall_exact_guard.py

22 exact rational one-dimensional cases, all 7468 nonempty source subsets, and 126 true tensor-grid exterior checks up to n=64. The tensor counts represent m^n atoms without expanding them. No higher-dimensional growth rate is inferred.

```python
#!/usr/bin/env python3
"""Exact rational one-dimensional pressure checks, not a general proof."""
from fractions import Fraction as F
import json,random
from pathlib import Path

def union(intervals,strict=False):
    out=[]
    for a,b in sorted(intervals):
        if a>=b:continue
        if out and (a<out[-1][1] if strict else a<=out[-1][1]):
            out[-1]=(out[-1][0],max(out[-1][1],b))
        else:out.append((a,b))
    return out

def cap_intervals(src,H):
    src=sorted(src); intervals=[]
    for j in range(len(src)):
        mass=F(0)
        for k in range(j,len(src)):
            mass+=src[k][1]
            intervals.append((src[k][0]-mass/(2*H),src[j][0]+mass/(2*H)))
    return union(intervals,strict=True)

def hall(src,H):
    omega=cap_intervals(src,H); balls=[]
    for y,p in src:
        comp=[(a,b) for a,b in omega if a<y<b]
        assert len(comp)==1
        a,b=comp[0];r=min(y-a,b-y);balls.append((y-r,y+r))
    maximum=F(0);winner=None
    for bits in range(1,1<<len(src)):
        ix=[j for j in range(len(src)) if bits>>j&1]
        vol=sum((b-a for a,b in union([balls[j] for j in ix])),F(0))
        mass=sum((src[j][1] for j in ix),F(0));ratio=mass/(H*vol)
        if ratio>maximum:maximum=ratio;winner=ix
    assert maximum<=3 # general proven geometry in n=1
    return dict(source=[[str(y),str(p)] for y,p in src],H=str(H),omega=[[str(a),str(b)]for a,b in omega],hall_ratio=str(maximum),hall_ratio_float=float(maximum),maximizing_subset=winner,subsets_checked=(1<<len(src))-1)

def grid_max(n,m,x):
    spacing=F(2,m);nodes=[-1+(F(j)+F(1,2))*spacing for j in range(m)]
    radii=sorted({abs(a-y) for a in x for y in nodes})
    maxima=F(0)
    for r in radii:
        if r==0:continue
        number=1
        for a in x:number*=sum(abs(a-y)<=r for y in nodes)
        maxima=max(maxima,2*spacing**n*number/(2*r)**n)
    return maxima

def high_dimension_grid_guards():
    rows=[]
    for n in [1,2,4,8,16,32,64]:
        for m in [3,9,31]:
            for mult in [F(1),F(3,2)]:
                d=F(n,m)*mult
                for offset in [F(0),F(1,m),F(1,3)]:
                    x=[1+d]+[offset]*(n-1);value=grid_max(n,m,x)
                    assert value<=1,(n,m,d,offset,value)
                    rows.append(dict(n=n,m=m,first_face_gap=str(d),transverse_coordinate=str(offset),exact_M_over_H=str(value),float_M_over_H=float(value),volume_Hall_lower=str(2/(1+F(n,m))**n)))
    return rows

def main():
    rows=[]
    for m in [1,3,5,7,9,11]:
        h=F(1,m);src=[(j*h,2*h) for j in range(m)]
        row=hall(src,F(1));ratio=F(row['hall_ratio']);expected=F(2*m,m+1)
        assert ratio==expected,(m,ratio,expected)
        assert cap_intervals(src,F(1))==[(-h,m*h)]
        row.update(stage='exact_atomic_pressure',family='uniform_chain',expected_full_Hall_ratio=str(expected));rows.append(row)
    rng=random.Random(610031)
    for N in [3,5,7,9]:
        for H in [F(1,4),F(1),F(4)]:
            ys=sorted(rng.sample(range(-32,33),N));ws=[rng.randrange(1,20) for _ in ys];s=sum(ws)
            src=[(F(y,32),F(w,s))for y,w in zip(ys,ws)]
            row=hall(src,H);row.update(stage='rational_adversarial_pressure',family='random_unequal');rows.append(row)
    for depth in [2,3,4,5]:
        src=[(F(0),F(1,2**depth))]
        for j in range(1,depth+1):
            for sign in [-1,1]:src.append((F(sign,2**j),F(1,2**(j+1))))
        row=hall(src,F(2**depth));row.update(stage='expanded_depth',family='nested',depth=depth);rows.append(row)
    out=dict(schema='round061_rational_Hall_pressure_v1',arithmetic='fractions.Fraction, exact rational cap interval union and all source subsets',cases=rows,total_subsets=sum(r['subsets_checked']for r in rows),seed=610031,high_dimension_grid_cases=high_dimension_grid_guards(),scope='Finite n=1 exact instances support the formulas; no dimension-uniform capacity theorem is inferred.')
    p=Path(__file__).with_name('hall_exact_results.json');p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'cases':len(rows),'subsets':out['total_subsets'],'maximum_ratio':max(r['hall_ratio_float']for r in rows),'output':str(p)}))
if __name__=='__main__':main()
```

### dual_exact_guard.py

120 exact finite rational primal-dual gap identities and Frank-Wolfe direction checks. This tests algebraic signs, not a continuum cube theorem.

```python
#!/usr/bin/env python3
"""Exact finite algebra checks. These do not certify a continuum cube objective."""
from fractions import Fraction as F
import random,json
from pathlib import Path

def dot(x,y):return sum((a*b for a,b in zip(x,y)),F(0))
def mat(B,x):return [dot(row,x) for row in B]
def sub(x,y):return [a-b for a,b in zip(x,y)]
def linear_min(a,cap,W):
    s=[F(0) for _ in a];left=W
    for i in sorted(range(len(a)),key=lambda i:a[i]):
        s[i]=min(cap[i],left);left-=s[i]
    assert left==0
    return s

def main():
    rng=random.Random(610041);rows=[]
    cap=[F(1),F(2,3),F(1,3)];W=F(1)
    for trial in range(120):
        B=[[F(rng.randrange(-9,10),7)for _ in cap]for _ in range(4)]
        b=[F(rng.randrange(-9,10),5)for _ in range(4)]
        h=[F(rng.randrange(-9,10),11)for _ in range(4)]
        lam=F(trial%5,3)
        v=linear_min([F(rng.randrange(-9,10))for _ in cap],cap,W)
        w=linear_min([F(rng.randrange(-9,10))for _ in cap],cap,W)
        full=[(a+2*c)/3 for a,c in zip(v,w)]
        r=[a/(1+(trial%2)) for a in full]
        a=[sum((B[j][i]*h[j]for j in range(4)),F(0))for i in range(3)]
        err=sub(b,mat(B,r));primal=dot(err,err)
        hinge=sum((c*max(F(0),z-lam)for c,z in zip(cap,a)),F(0))
        dual=2*dot(b,h)-dot(h,h)-2*lam*W-2*hinge
        residual=dot(sub(err,h),sub(err,h));unused=2*lam*(W-sum(r,F(0)))
        defect=2*sum((c*max(F(0),z-lam)-(z-lam)*m for c,z,m in zip(cap,a,r)),F(0))
        assert primal-dual==residual+unused+defect and min(residual,unused,defect)>=0
        efull=sub(b,mat(B,full));grad=[-2*sum((B[j][i]*efull[j]for j in range(4)),F(0))for i in range(3)]
        s=linear_min(grad,cap,W);gap=dot(grad,sub(full,s));lower=dot(efull,efull)-gap
        assert gap>=0
        for candidate in [v,w,s]:
            e=sub(b,mat(B,candidate));assert dot(e,e)>=lower
        rows.append(dict(trial=trial,primal=str(primal),dual=str(dual),gap_identity_residual='0',finite_FW_gap=str(gap)))
    out=dict(schema='round061_rational_dual_algebra_v1',seed=610041,cases=rows,scope='120 exact finite rational gap identities and feasible linear-oracle/FW direction checks; no cube or continuum theorem inferred.')
    path=Path(__file__).with_name('dual_exact_results.json');path.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print('PASS',len(rows),'exact gap identities and FW direction checks')
if __name__=='__main__':main()
```

### face_alias_guard.py

42 analytic face-jump parameter pairs at Decimal80/140, n up to4096. Decimal comparisons are tolerance diagnostics, not interval certificates.

```python
#!/usr/bin/env python3
"""Independent Decimal antiderivative checks; no outward-rounded interval claim."""
from decimal import Decimal as D,localcontext
from pathlib import Path
import json

def evaluate(n,ratio,precision):
    with localcontext() as ctx:
        ctx.prec=precision
        nd=D(n);eta=1/nd;q=eta.exp();c=1-1/q;t=1/(2*D(ratio));L0=1/(4*q);epsilon=D(ratio)*L0
        # Direct antiderivative on t in [1/q,1], and then [1,T].
        enter=nd/4*(q.ln()+2/q-1/(2*q*q)-D(3)/2)
        settle=nd*c*c/8*(1-1/(t*t));direct=enter+settle
        limit=nd/4*(eta-1+1/q)
        formula=limit-nd*c*c*epsilon*epsilon/(2*L0*L0)
        error=abs(direct-formula)
        assert direct>0 and limit>0
        assert direct-limit<D(10)**(-(precision-12))
        assert error<D(10)**(-(precision-12))
        return dict(n=n,epsilon_over_L0=ratio,precision=precision,face_value='0',one_sided_small_scale_limit=str(limit),truncated_energy=str(formula),antiderivative_energy=str(direct),absolute_discrepancy=str(error),rounded_direct_minus_limit=str(direct-limit))

def main():
    rows=[]
    for n in [1,2,4,16,64,1024,4096]:
        for ratio in ['0.5','0.25','0.0625','1e-8','1e-30','1e-60']:
            a=evaluate(n,ratio,80);b=evaluate(n,ratio,140)
            with localcontext() as ctx:
                ctx.prec=160
                assert abs(D(a['truncated_energy'])-D(b['truncated_energy']))<D('1e-65')
            rows.append({'low':a,'high':b})
    out=dict(schema='round061_face_alias_v1',cases=rows,analytic_formula='n/4*(1/n-1+exp(-1/n))-n*(1-exp(-1/n))^2*epsilon^2/(2*L0^2), epsilon>0, L0>=2epsilon',scope='Exact formula proved analytically; 42 parameter pairs checked at Decimal80/140. Agreement is not an interval certificate. At epsilon=0 the small-scale value is exactly zero, not the positive one-sided limit.')
    p=Path(__file__).with_name('face_alias_results.json');p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print('PASS',len(rows),'face discontinuity parameter pairs at 80/140 digits')
if __name__=='__main__':main()
```

### Verification receipt

```json
{
  "additional_independent_checks": "Direct feature versus quadratic objective; proportional error Gram sum; positive receiver-face distance for final pressure cases; floating FW diagnostics only.",
  "auxiliary_replays": {
    "dual_exact_guard.py": {
      "exit_code": 0,
      "results_byte_identical": true,
      "results_sha256": "4d9d47ce305863159ebb4115423cc2e516474c64d97f96a4ba64670a35a48288",
      "stdout": "PASS 120 exact gap identities and FW direction checks"
    },
    "face_alias_guard.py": {
      "exit_code": 0,
      "results_byte_identical": true,
      "results_sha256": "55db488888167696e5e24c3411c373595607d7e4627197cf974c357014f4fe4c",
      "stdout": "PASS 42 face discontinuity parameter pairs at 80/140 digits"
    },
    "hall_exact_guard.py": {
      "exit_code": 0,
      "results_byte_identical": true,
      "results_sha256": "3dabb376a38b7debf8a89c2457e9b30a00e0aa679f56e67c80eaaba067409d39",
      "stdout": "{\"cases\": 22, \"subsets\": 7468, \"maximum_ratio\": 1.8333333333333333, \"output\": \"/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round061-replay-5l9jcs_q/run/hall_exact_results.json\"}"
    }
  },
  "cases": 40,
  "environment": {
    "OMP_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "PYTHONDONTWRITEBYTECODE": "1",
    "VECLIB_MAXIMUM_THREADS": "1"
  },
  "exact_rational_primal_witnesses_verified": 40,
  "interpreter": "/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3",
  "main_exit_code": 0,
  "main_input_zip_sha256": "ead394af25eefb8b29848c7eb05c8c3b9aa4bfb152b8ae4df5f6c381ffffe8de",
  "main_replay_byte_identical": true,
  "main_replay_directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round061-replay-5l9jcs_q",
  "main_results_sha256": "692946dfa40503cd30d589e0a367d0b7c8a8b2d7cd7279142cbab75c952c3193",
  "main_runtime_seconds": 76.22741462499835,
  "main_script_sha256": "5e989ff92b59ad947f79c9f0fbaf1d372c172b9a81d12e8545bc3e5872deb830",
  "numpy_version": "2.3.5",
  "scope": "Numerical and algebraic checks do not certify a continuum bound; LaTeX not compiled."
}
```

### Final numerical summary

```json
{
  "cases": 40,
  "dimensions": [
    1,
    2,
    3
  ],
  "final_shifted_cases": 37,
  "max_FW_full_gap": 1.982115764229131e-08,
  "max_final_source_time_discrepancy": 4.054242805509358e-14,
  "max_final_time_refinement_change_over_HW": 2.2426505097428162e-14,
  "raw_blob_infeasible_cases": 20,
  "source_families": [
    "correlated_diagonal",
    "deep_nested",
    "deep_nested16",
    "random_weighted",
    "spike",
    "unequal_cluster"
  ]
}
```

## Remaining general interface

The core theorem remains unproved. For the localized route, improve the all-subset Hall bound from 3^n to an affordable height, and independently control the full signed mixed error on the original good set. The general bounded-density projection can bypass that particular localization, but its optimum still requires a new source-uniform estimate. Neither finite-QP optimality, an exact mass witness, nor the face-aliasing repair establishes that estimate. The retained general weak upper bound is O(n log n); no new sqrt(n)n^{o(1)} bound is claimed. Subsequent weak-type and all-scale recovery must also be proved.
