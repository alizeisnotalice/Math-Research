#!/usr/bin/env python3
"""Finite-cell signed replacement candidates; requires installed NumPy, no solver package."""
import argparse,itertools,json,math,random,sys,time,os
from pathlib import Path
from fractions import Fraction as F
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['VECLIB_MAXIMUM_THREADS']='1'
import numpy as np
C=1-math.exp(-1)

def source_raw(kind,n):
    if kind=='spike':return [(tuple(0.0 for _ in range(n)),1.0)]
    if kind=='unequal_cluster':return [(tuple((j-2)/64 for _ in range(n)),p) for j,p in enumerate((.05,.10,.15,.25,.45))]
    if kind.startswith('deep_nested'):
        d=16 if kind.endswith('16') else 8;rows=[(tuple(0.0 for _ in range(n)),2.0**(-d))]
        for j in range(1,d+1):
            for sign in (-1,1):rows.append((tuple(sign*2.0**(-j) for _ in range(n)),2.0**(-j-1)))
        return rows
    if kind=='correlated_diagonal':return [(tuple((j-3.5)/8 for _ in range(n)),.125) for j in range(8)]
    rng=random.Random(610000+n);ws=[rng.random()**3+.01 for _ in range(12)];total=sum(ws)
    return [(tuple(rng.uniform(-.5,.5) for _ in range(n)),w/total) for w in ws]

def source(kind,n):
    rows=source_raw(kind,n);masses=[F(str(p)) for y,p in rows];total=sum(masses,F(0))
    return [(y,p/total) for (y,_),p in zip(rows,masses)]

def exact_cap(x,src,n,H):
    xr=tuple(F(float(t)) for t in x);batches={}
    for y,p in src:
        v=(2*max(abs(a-F(float(b))) for a,b in zip(xr,y)))**n
        if v==0:return False
        batches[v]=batches.get(v,F(0))+p
    acc=F(0);height=F(str(H))
    for v,p in sorted(batches.items()):
        acc+=p
        if acc>height*v:return False
    return True

def atom_events(x,src,n):
    batches={}
    for y,p in src:
        v=(2*max(abs(a-b) for a,b in zip(x,y)))**n
        batches[v]=batches.get(v,0.0)+p
    rows=sorted(batches.items());acc=0.;M=0.
    for v,p in rows:
        acc+=p
        if v==0:return rows,math.inf
        M=max(M,acc/v)
    return rows,M

def exact_point_energy(rows):
    events=[]
    for v,p in rows:
        if v==0:return math.inf
        events.extend(((v/math.e,p/math.e),(v,-p)))
    events.sort();coef=0.;prev=None;out=0.
    for t,jump in events:
        if prev is not None and t>prev:out+=.5*coef*coef*(prev**-2-t**-2)
        coef+=jump;prev=t
    if prev is not None:out+=.5*coef*coef/prev**2
    return out

def grid(n,side,radius,phase=None):
    radius=F(str(radius));step=2*radius/side
    axislo=[float(-radius+j*step) for j in range(side)]
    axishi=[float(-radius+(j+1)*step) for j in range(side)]
    phases=phase or [F(1,2)]*n
    axismid=[[float(-radius+(F(j)+alpha)*step) for j in range(side)] for alpha in phases]
    lo=np.array(list(itertools.product(*[axislo]*n)),dtype=float)
    hi=np.array(list(itertools.product(*[axishi]*n)),dtype=float)
    midpoint=np.array(list(itertools.product(*axismid)),dtype=float)
    return lo,hi,float(step**n),midpoint

def features(src,n,H,cells,receivers,T,Rx=2.,method='gauss',evaluate=None,build_gram=True,phase_override=None):
    phase=phase_override or ([F(1,2)]*n if method=='log_midpoint' else [F(37+11*i,101) for i in range(n)])
    lo,hi,vol,_=grid(n,cells,1.);rlo,rhi,dx,xs=grid(n,receivers,Rx,phase=phase)
    q=math.exp(1/n);N=len(lo);G=np.zeros((N,N));linear=np.zeros(N);a2=0.;exact=0.;retained=0
    masses=np.array([float(p) for y,p in src]);ys=np.array([y for y,p in src]);lower_all=math.inf;upper=2*(Rx+1)*1.01;node_count=0;interval_count=0;direct={name:0. for name in (evaluate or {})}
    error_gram=np.zeros((len(src),len(src)));min_face_distance=math.inf
    nodes,weights=np.polynomial.legendre.leggauss(T if method=='gauss' else 8)
    for x in xs:
        rows,M=atom_events(x,src,n)
        if not exact_cap(x,src,n,H):continue
        retained+=1;exact+=dx*exact_point_energy(rows)
        distances=2*np.max(np.abs(ys-x),axis=1)
        faces=2*np.abs(np.concatenate((lo-x,hi-x),axis=0)).ravel();min_face_distance=min(min_face_distance,float(np.min(faces))/2)
        if method=='gauss':assert np.min(faces)>0,'Receiver on replacement-cell face'
        breaks=np.concatenate((distances,distances/q,faces,faces/q));breaks=np.unique(breaks[(breaks>0)&(breaks<upper)])
        lower=float(breaks[0])/2;lower_all=min(lower_all,lower)
        if method=='gauss':
            aligned=[lower]
            for endpoint in list(breaks)+[upper]:
                while endpoint>1.5*aligned[-1]:aligned.append(1.5*aligned[-1])
                aligned.append(float(endpoint))
            ends=np.array(aligned);left=ends[:-1];right=ends[1:];half=(right-left)/2;mid=(right+left)/2
            ls=(mid[:,None]+half[:,None]*nodes).ravel();ws=(half[:,None]*weights*n/(mid[:,None]+half[:,None]*nodes)).ravel()*dx
            interval_count+=len(left)
        else:
            us=np.linspace(n*math.log(lower),n*math.log(upper),T+1);ls=np.exp((us[:-1]+us[1:])/(2*n));ws=np.full(T,dx*(us[-1]-us[0])/T)
        node_count+=len(ls);r=ls[:,None,None]/2
        def kernels(mult):
            left=x[None,None,:]-mult*r;right=x[None,None,:]+mult*r
            overlap=np.maximum(0,np.minimum(hi[None,:,:],right)-np.maximum(lo[None,:,:],left))
            return np.prod(overlap,axis=2)/(vol*(mult*ls[:,None])**n)
        B=kernels(q)-kernels(1.)
        S=((q*ls[:,None]>=distances[None,:])*masses)/(q*ls[:,None])**n
        S-=((ls[:,None]>=distances[None,:])*masses)/ls[:,None]**n
        a=S.sum(axis=1);aw=a*np.sqrt(ws);a2+=float(aw@aw)
        if build_gram:
            Bw=B*np.sqrt(ws[:,None]);G+=Bw.T@Bw;linear+=Bw.T@aw
        if evaluate and 'optimized' in evaluate and build_gram:
            error=S-(B@evaluate['optimized'])[:,None]*masses
            error*=np.sqrt(ws[:,None]);error_gram+=error.T@error
        for name,mass in (evaluate or {}).items():direct[name]+=float(((a-B@mass)**2)@ws)
    source_tail=retained*dx*C*C/(2*upper**(2*n))
    return dict(G=G,b=linear,a2=a2,lo=lo,hi=hi,vol=vol,dx=dx,xs=xs,cap_points=retained,all_points=len(xs),lower_L=lower_all,upper_L=upper,exact_source_energy=exact,exact_source_window_energy=exact-source_tail,source_terminal_tail=source_tail,mesh_source_energy=a2,cells=N,Rx=Rx,quadrature=method,node_count=node_count,interval_count=interval_count,direct_objectives=direct,proportional_error_Gram=error_gram,receiver_phase=[str(t) for t in phase],minimum_retained_receiver_cell_face_distance=min_face_distance)

def project(v,cap,W=1.):
    left=float(np.min(v-cap));right=float(np.max(v))
    for _ in range(55):
        mid=(left+right)/2;z=np.clip(v-mid,0,cap)
        if z.sum()>W:left=mid
        else:right=mid
    z=np.clip(v-(left+right)/2,0,cap)
    delta=W-float(z.sum())
    if delta>0:
        for i in np.argsort(-(cap-z)):
            step=min(delta,float(cap[i]-z[i]));z[i]+=step;delta-=step
            if delta<=0:break
    elif delta<0:
        for i in np.argsort(-z):
            step=min(-delta,float(z[i]));z[i]-=step;delta+=step
            if delta>=0:break
    return z

def linear_min(g,cap,W=1.):
    s=np.zeros(len(g));remaining=W
    for i in np.argsort(g,kind='stable'):
        amount=min(remaining,float(cap[i]));s[i]=amount;remaining-=amount
        if remaining<=1e-15:break
    return s

def optimize(G,b,cap,start,maxiter=6000):
    eig=np.linalg.eigvalsh(G);L=max(float(eig[-1]),1e-15)
    r=start.copy();y=r.copy();t=1.;best=r.copy();bestvalue=float(.5*r@G@r-b@r);used=0
    scale=max(1.,float(np.max(np.abs(b))))
    for it in range(1,maxiter+1):
        z=project(y-(G@y-b)/L,cap);newt=(1+math.sqrt(1+4*t*t))/2
        y=z+(t-1)/newt*(z-r);r=z;t=newt;used=it
        if it%25==0:
            value=float(.5*r@G@r-b@r)
            if value<bestvalue:bestvalue=value;best=r.copy()
            grad=G@best-b;s=linear_min(grad,cap);gap=float(grad@(best-s))
            if gap<1e-8*scale:break
    r=best;grad=G@r-b;s=linear_min(grad,cap);gap=max(0.,float(grad@(r-s)))
    free=(r>1e-9)&(r<cap-1e-9)
    lam=-float(np.mean(grad[free])) if np.any(free) else -float((np.min(grad[r<cap-1e-9])+np.max(grad[r>1e-9]))/2)
    residual=np.where(r<=1e-9,np.minimum(grad+lam,0),np.where(r>=cap-1e-9,np.maximum(grad+lam,0),grad+lam))
    return r,dict(iterations=used,status='floating feasible candidate',half_objective_FW_gap=gap,full_squared_error_FW_gap=2*gap,min_Gram_eigenvalue=float(eig[0]),max_Gram_eigenvalue=float(eig[-1]),KKT_stationarity_infinity=float(np.max(np.abs(residual))),mass_residual=float(r.sum()-1),lower_capacity_violation=max(0.,-float(r.min())),upper_capacity_violation=max(0.,float(np.max(r-cap))))

def naive_blobs(src,n,H,beta,lo,hi,vol):
    raw=np.zeros(len(lo));missing=0.
    for y,p in src:
        p=float(p)
        side=(p/(beta*H))**(1/n);y=np.array(y)
        fractions=np.prod(np.maximum(0,np.minimum(hi,y+side/2)-np.maximum(lo,y-side/2)),axis=1)/side**n
        raw+=p*fractions;missing+=p*(1-float(fractions.sum()))
    return raw,missing

def metric(data,r,H,beta):
    diag=data['a2'];replacement=float(r@data['G']@r);cross=float(data['b']@r);E=max(0.,diag+replacement-2*cross)
    return dict(signed_error_over_HW=E/H,source_energy_over_HW=diag/H,replacement_energy_over_HW=replacement/H,signed_source_replacement_cross_over_HW=cross/H,identity_residual=float(E-(diag+replacement-2*cross)),mass=float(r.sum()),maximum_density=float(r.max()/data['vol']),density_cap=beta*H)

def run_case(kind,n,H,beta,cells,receivers,T,stage,refine=True):
    src=source(kind,n);method='log_midpoint' if stage=='pilot' else 'gauss';data=features(src,n,H,cells,receivers,T,method=method);vol=data['vol'];cap=np.full(data['cells'],beta*H*vol)
    assert cap.sum()>=1
    uniform=np.full(data['cells'],1/data['cells']);raw,missing=naive_blobs(src,n,H,beta,data['lo'],data['hi'],vol);blob=project(raw,cap)
    G=data['G'];b=data['b']
    start=min((uniform,blob),key=lambda r:metric(data,r,H,beta)['signed_error_over_HW'])
    opt,solver=optimize(G,b,cap,start)
    views={name:metric(data,r,H,beta) for name,r in [('optimized',opt),('global_uniform',uniform),('projected_independent_blobs',blob),('raw_independent_blobs',raw)]}
    row=dict(source=kind,n=n,H=H,beta=beta,stage=stage,source_atoms=len(src),source_definition=[[list(y),str(p)] for y,p in src],receiver_box_radius=2.,replacement_box_radius=1.,cells_per_axis=cells,cell_count=data['cells'],cell_volume=vol,receiver_phase=data['receiver_phase'],minimum_retained_receiver_cell_face_distance=data['minimum_retained_receiver_cell_face_distance'],receiver_points=data['all_points'],cap_receiver_points=data['cap_points'],time_quadrature_method=method,event_subinterval_max_ratio=1.5 if method=='gauss' else None,time_order_or_log_nodes=T,total_feature_nodes=data['node_count'],breakpoint_intervals=data['interval_count'],time_lower_L=data['lower_L'],time_upper_L=data['upper_L'],time_geometry_truncation='Zero error outside this scale window at every retained receiver for this finite-cell/source geometry; spatial quadrature remains approximate.',source_mesh_energy_over_HW=data['mesh_source_energy']/H,source_exact_event_energy_at_same_receivers_over_HW=data['exact_source_energy']/H,source_exact_window_energy_at_same_receivers_over_HW=data['exact_source_window_energy']/H,source_known_terminal_tail_over_HW=data['source_terminal_tail']/H,source_time_quadrature_relative_discrepancy=abs(data['mesh_source_energy']-data['exact_source_window_energy'])/max(data['exact_source_window_energy'],1e-30),solver=solver,candidates=views,optimized_cell_masses=opt.tolist(),raw_blob_clipped_mass=missing,raw_blob_feasible=abs(raw.sum()-1)<1e-10 and float(np.max(raw-cap))<=1e-10,fullspace_spatial_tail_upper_over_HW=4*C*2**(-n)*2**(n-1)/(H),tail_bound_scope='Triangle+source Jensen; both positive mass-one supports inside [-1,1]^n; very loose bound outside receiver box, independent of cap.',continuous_conclusion='No continuous-space optimum or general replacement theorem certified.')
    if refine:
        fine=features(src,n,H,cells,receivers,2*T,method=method,evaluate={'optimized':opt,'global_uniform':uniform,'projected_independent_blobs':blob})
        row['time_refinement_same_candidate']={name:metric(fine,r,H,beta) for name,r in [('optimized',opt),('global_uniform',uniform),('projected_independent_blobs',blob)]}
        row['time_refinement_absolute_energy_change_over_HW']=abs(row['time_refinement_same_candidate']['optimized']['signed_error_over_HW']-views['optimized']['signed_error_over_HW'])
        row['source_time_refined_relative_discrepancy']=abs(fine['mesh_source_energy']-fine['exact_source_window_energy'])/max(fine['exact_source_window_energy'],1e-30)
        row['direct_feature_vs_Gram_objective_discrepancies']={name:abs(fine['direct_objectives'][name]/H-row['time_refinement_same_candidate'][name]['signed_error_over_HW']) for name in fine['direct_objectives']}
        errorgram=fine['proportional_error_Gram'];trace=float(np.trace(errorgram));total=float(errorgram.sum());ps=np.sqrt(np.array([float(p) for y,p in src]));normalized=errorgram/(H*ps[:,None]*ps[None,:]);row['proportional_source_allocation_mixed_errors']=dict(allocation='F_i=p_i F; legitimate common positive density, not independent optimizer per atom',error_Gram_over_H=(errorgram/H).tolist(),trace_over_H=trace/H,total_error_over_H=total/H,offdiagonal_sum_over_H=(total-trace)/H,total_over_trace=total/max(trace,1e-30),normalized_Gram_max_eigenvalue=float(np.linalg.eigvalsh(normalized)[-1]),total_Gram_vs_direct_difference=abs(total/H-fine['direct_objectives']['optimized']/H))
    spatial_selected=(stage=='pressure' and ((kind=='deep_nested' and n==1 and beta==1) or (kind=='unequal_cluster' and n==2 and beta==2) or (kind=='correlated_diagonal' and n==2 and beta==2) or (kind=='correlated_diagonal' and n==3 and beta==3)))
    if spatial_selected:
        newr=2*receivers if n<3 else 16
        space=features(src,n,H,cells,newr,16,method='gauss',evaluate={'optimized':opt},build_gram=False)
        row['spatial_refinement_same_candidate']=dict(receiver_per_axis=newr,receiver_points=space['all_points'],cap_receiver_points=space['cap_points'],optimized_error_over_HW=space['direct_objectives']['optimized']/H,absolute_change_over_HW=abs(space['direct_objectives']['optimized']/H-row['time_refinement_same_candidate']['optimized']['signed_error_over_HW']),source_exact_event_energy_over_HW=space['exact_source_energy']/H,receiver_phase=space['receiver_phase'],minimum_retained_receiver_cell_face_distance=space['minimum_retained_receiver_cell_face_distance'],scope='Receiver mesh comparison for identical F, with Gauss16; difference is diagnostic, not a spatial error bound.')
        alt=features(src,n,H,cells,receivers,16,method='gauss',evaluate={'optimized':opt},build_gram=False,phase_override=[F(73-7*i,103) for i in range(n)])
        row['independent_receiver_phase_same_candidate']=dict(receiver_phase=alt['receiver_phase'],minimum_retained_receiver_cell_face_distance=alt['minimum_retained_receiver_cell_face_distance'],receiver_per_axis=receivers,cap_receiver_points=alt['cap_points'],optimized_error_over_HW=alt['direct_objectives']['optimized']/H,absolute_change_over_HW=abs(alt['direct_objectives']['optimized']/H-row['time_refinement_same_candidate']['optimized']['signed_error_over_HW']),scope='Second rational receiver phase, identical F; deterministic quadrature sensitivity, not statistical uncertainty.')
    return row

def primal_witness(row):
    """Exact rational box/mass constraints; objective still floating quadrature."""
    row['blob_comparison_scope']='Raw comparison is the cell average of independent source-centered uniform blobs; projected comparison is its capped-simplex projection. Neither is an evaluation of the original continuous blob sum.'
    blob_sides=[(float(F(p))/(row['beta']*row['H']))**(1/row['n']) for y,p in row['source_definition']]
    row['original_continuous_blob_interior_overlap_detected']=any(all(abs(row['source_definition'][i][0][k]-row['source_definition'][j][0][k])<(blob_sides[i]+blob_sides[j])/2 for k in range(row['n'])) for i in range(len(blob_sides)) for j in range(i))
    if row['source']=='spike':
        true=C*(1-1/(row['H']*4**row['n']))
        row['one_atom_true_receiver_box_source_energy_over_HW']=true
        row['one_atom_source_spatial_quadrature_relative_discrepancy']=abs(row['source_exact_event_energy_at_same_receivers_over_HW']-true)/true
    row['source_seed']=610000+row['n'] if row['source']=='random_weighted' else None
    row['source_scale_depth']=16 if row['source']=='deep_nested16' else (8 if row['source']=='deep_nested' else None)
    volume=F(2,row['cells_per_axis'])**row['n'];capacity=F(str(row['beta']))*F(str(row['H']))*volume
    original=[F(float(v)) for v in row['optimized_cell_masses']]
    masses=[max(F(0),min(capacity,v)) for v in original];delta=F(1)-sum(masses,F(0))
    for i in range(len(masses)):
        if delta>0:
            step=min(delta,capacity-masses[i]);masses[i]+=step;delta-=step
        elif delta<0:
            step=min(-delta,masses[i]);masses[i]-=step;delta+=step
        else:break
    assert delta==0 and sum(masses,F(0))==1 and all(0<=v<=capacity for v in masses)
    perturbation=math.sqrt(sum(float(a-b)**2 for a,b in zip(masses,original)))
    energy=row['candidates']['optimized']['signed_error_over_HW']*row['H'];normbound=math.sqrt(max(0.,row['solver']['max_Gram_eigenvalue']))*perturbation
    row['exact_primal_witness']=dict(cell_volume=str(volume),cell_mass_capacity=str(capacity),cell_masses=[str(v) for v in masses],total_mass='1',maximum_density=str(max(masses)/volume),density_cap=str(F(str(row['beta']))*F(str(row['H']))),mass_and_box_constraints_exact=True,correction_l2_from_optimizer=perturbation,finite_quadrature_objective_change_estimate_over_HW=(2*math.sqrt(energy)*normbound+normbound**2)/row['H'],scope='Exact rational feasibility of a real step density on ideal rational cells. Floating features use machine endpoints: no strict validation of this witness continuous objective is claimed; objectives and eigenvalue estimates are not interval-certified.')
    value=row['candidates']['optimized']['signed_error_over_HW'];gap=row['solver']['full_squared_error_FW_gap']/row['H']
    row['floating_finite_QP_objective_interval_over_HW']=[max(0.,value-gap),value]
    return row

def pilot_plan():
    yield ('spike',1,1.,1.,24,128,64,'pilot')
    yield ('unequal_cluster',1,4.,1.,32,192,96,'pilot')
    yield ('correlated_diagonal',2,1.,2.,8,16,64,'pilot')

def full_plan():
    kinds=('spike','unequal_cluster','deep_nested','correlated_diagonal','random_weighted')
    for n in (1,2,3):
        chosen=kinds if n<3 else ('correlated_diagonal','random_weighted')
        betas=(1.,2.) if n==1 else (1.,float(n),float(2*n))
        for kind in chosen:
            for beta in betas:
                c,r,t=(32,192,8) if n==1 else ((8,20,8) if n==2 else (4,10,8))
                yield (kind,n,1.,beta,c,r,t,'pressure')
    yield ('spike',1,4.,1.,32,256,8,'threshold_pressure')
    yield ('deep_nested16',1,1.,1.,32,192,8,'depth_pressure')
    yield ('deep_nested16',2,1.,2.,8,20,8,'depth_pressure')
    yield ('deep_nested',1,1.,1.,64,384,8,'expanded')
    yield ('unequal_cluster',2,1.,2.,12,28,8,'expanded')
    yield ('correlated_diagonal',3,1.,3.,6,12,8,'expanded')

def guards():
    rows=[]
    for n in (1,2,3):
        src=source('random_weighted',n)
        for x in [tuple(2.+j/7 for j in range(n)),tuple(-1.25 for _ in range(n))]:
            arrivals,_=atom_events(x,src,n);e=exact_point_energy(arrivals)
            # Compare with independent direct kernel-overlap Gram formula below.
            gram=0.
            for v,p in arrivals:
                for w,r in arrivals:
                    a,b=min(v,w),max(v,w)
                    q=math.exp(-1);ratio=b/a
                    kernel=(2-q-q*ratio*ratio)/(2*b*b) if ratio<=1/q else -C*C/(2*q*b*b)
                    gram+=p*r*kernel
            err=abs(e-gram)/max(e,1e-30)
            assert err<2e-12,(n,e,gram)
            rows.append(dict(n=n,point=list(x),event_energy=e,Gram_energy=gram,relative_discrepancy=err))
    for n,x in [(1,(2.,)),(2,(2.,2.25)),(3,(2.,2.25,2.5)),(1,(.125,))]:
        signed=[(tuple(0. for _ in range(n)),F(1,2)),(tuple(.25 for _ in range(n)),F(-1,2))]
        tv=[(y,abs(p)) for y,p in signed];batch={}
        for y,p in signed:
            v=(2*max(abs(a-b) for a,b in zip(x,y)))**n;batch[v]=batch.get(v,0.)+float(p)
        arrivals=sorted((v,p) for v,p in batch.items() if p!=0);event=exact_point_energy(arrivals);gram=0.
        for y,p in signed:
            v=(2*max(abs(a-b) for a,b in zip(x,y)))**n
            for z,r in signed:
                w=(2*max(abs(a-b) for a,b in zip(x,z)))**n;a,b=min(v,w),max(v,w);q=math.exp(-1);ratio=b/a
                kernel=(2-q-q*ratio*ratio)/(2*b*b) if ratio<=1/q else -C*C/(2*q*b*b)
                gram+=float(p*r)*kernel
        error=abs(event-gram)/max(abs(event),1.)
        assert error<2e-12
        rows.append(dict(kind='signed_zero_mass_dipole',n=n,point=list(x),signed_total_mass='0',total_variation_mass='1',cap_uses='positive total variation source, H=1',TV_cap=exact_cap(x,tv,n,1.),event_energy=event,signed_Gram_energy=gram,absolute_or_relative_discrepancy=error,scope='Signed kernel implementation guard; no negative-source weak theorem.'))
    return rows

def main():
    p=argparse.ArgumentParser();p.add_argument('--pilot',action='store_true');args=p.parse_args();start=time.monotonic();check=guards();rows=[]
    for cfg in list(pilot_plan())+([] if args.pilot else list(full_plan())):
        row=primal_witness(run_case(*cfg));rows.append(row);print(row['stage'],row['source'],row['n'],row['beta'],'E',row['candidates']['optimized']['signed_error_over_HW'],'FW',row['solver']['full_squared_error_FW_gap'],'qerr',row['source_time_quadrature_relative_discrepancy'],flush=True)
        data=dict(schema='round061_finite_cell_projection_v1',pilot=args.pilot,numpy_version=np.__version__,cell_variables='mass r_j; density r_j/vol_j; 0<=r_j<=beta H vol_j; sum r_j=1',objective='actual signed adjacent volume D; explicit positive weighted feature Gram; shifted rational-phase receiver cells, atom/cell-event-aligned Gauss time quadrature; exact rational atomic cap at machine receiver/source coordinates',solver='self-contained capped-simplex accelerated projected gradient; greedy exact-form linear subproblem for floating Frank-Wolfe gap',cases=rows,event_Gram_guards=check,label_split_guard=[dict(labels=k,total_error_multiplier='1',trace_multiplier=str(F(1,k)),offdiagonal_multiplier=str(F(k-1,k)),normalized_total_over_trace=k) for k in (1,2,8,32,128)],evidence_limits=['Inner finite-cell replacement class and receiver/time quadratures; no bound on full continuous optimum.', 'Source time quadrature compared with exact point event integral on the same time window; known terminal source tail recorded separately.', 'PSD by explicit feature Gram; eigenvalues/KKT/FW diagnostics are floating, not interval certificates.', 'Finite receiver box omitted exterior has stated loose mathematical bound; no claim empirical refinement bounds spatial quadrature error.', 'Raw independent blobs may violate summed density cap; projected comparison is separately mass-feasible.', 'No source-count or dimension exponent fitting.', 'Current L01/L02/L03/L04 skills reread; no outward rounding or continuous optimization certification.'])
        Path(__file__).with_name('results.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    print('PASS',len(rows),'runtime_seconds',time.monotonic()-start,flush=True)
if __name__=='__main__':main()
