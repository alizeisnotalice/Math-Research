"""R152: regenerate cut budgets from pinned R151 details, plus finite pressure checks."""
from pathlib import Path
import argparse,json,shutil,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--rounds',required=True,type=Path);ap.add_argument('--receiver-detail',required=True,type=Path);ap.add_argument('--destination',required=True,type=Path);a=ap.parse_args();dst=a.destination.resolve();dst.mkdir(parents=True,exist_ok=False)
w=dst/'rounds/152/work';w.mkdir(parents=True);prev=dst/'rounds/151';prev.mkdir();shutil.copy2(a.rounds/'151/research.zip',prev/'research.zip')
for n,member in [(139,'active_traffic_v2.json'),(142,'numeric_receiver.json')]:
 with zipfile.ZipFile(a.rounds/str(n)/'research.zip') as z:(dst/member).write_bytes(z.read(member))
for f in ['cut_probe.py','cut_verify.py','pressure_check.py','cut_numeric_plan.md']:shutil.copy2(ROOT/f,w/f)
common=['--detail',str(a.receiver_detail.resolve()),'--r151-zip',str(prev/'research.zip'),'--r136',str(dst/'active_traffic_v2.json'),'--r142',str(dst/'numeric_receiver.json')]
subprocess.run([sys.executable,str(w/'cut_probe.py'),*common,'--out',str(w/'cut_probe.json')],check=True)
assert json.loads((w/'cut_probe.json').read_text())==json.loads((ROOT/'cut_probe.json').read_text())
r=subprocess.run([sys.executable,str(w/'cut_verify.py'),*common,'--cut-json',str(w/'cut_probe.json')],check=True,capture_output=True,text=True)
assert json.loads(r.stdout)['status']=='PASS';(dst/'verification.json').write_text(r.stdout)
subprocess.run([sys.executable,str(w/'pressure_check.py')],check=True)
a0=json.loads((ROOT/'pressure_check.json').read_text());b0=json.loads((w/'pressure_check.json').read_text())
a0['input'].pop('archive');b0['input'].pop('archive');assert a0==b0
print('PASS: identical cut output, reference cut verification, identical pressure results except archive location. No new kernels, FULL claim or certified spatial quadrature.')
