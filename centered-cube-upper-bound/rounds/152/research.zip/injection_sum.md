# R152：good 阈值注入的保留质量对数尾帽与跨切口求和

结论：对任意相关共同ν，证明了good注入的retention log-tail上帽。它保持当前来源／时间事件筛选、实际ρ和固定c，不把注入统一放成I^G/c；精确版本总不大于该旧线性帽。跨cut可由同一来源的有序阈值序列求和。参照终端g时，原terminal good和三核容量把中等保留比部分化成log(1+(C/c)m)，高保留比仅留下截断逆r超额。未证明组合后实际接收积分的一般根阶外价，不登记全一般付款。

## 1. 量词、保留的原门及端点

沿R151的实际行ξ=(ω,V,j,x,y)及原合法窗τ≤t≤h≤g。原ν、E_*⊂E₊、D₀、ρ、共同α、三核Q_v、μ=Qν/q、C=Kq/p均不变；E_*、D₀互斥且存活到g。c=c(ξ)为任意整窗固定常数，0<c≤e_g；可取c=e_g，也可用原high取c=2C。所有选择在外hard来源z积分以前固定。原输入不要求来源坐标独立。

沿用R151各cut r=0,…,n−1的

\[
 A_r(t)=\int_{E_*}\rho_vw_t(v)1_{\{k_t(v)>r\}}d\nu(v),\quad
 B_r(t)=\int_{D_0}w_t(v)1_{\{k_t(v)\le r\}}d\nu(v),
\]
\[
 S_r=A_r+B_r+c,\quad\Phi_r=A_r/S_r,\quad
 d_r=B_r(\tau)/[B_r(\tau)+(r+1)c].
 \tag{IS1}
\]

θ_r(v)为该来源第r+1个坐标阈值；k使用右态初始化，故θ=τ已在初端质量中，不重复收费。R151的总注入J_r保留原连续Lebesgue–Stieltjes部分以及同刻联合跳。

本轮对ST8联合总量统一约定以下**原分子分项，其和不变**。若在s有good进入原始质量a、bad离开质量b，旧值为A_−,B_−，S_−=A_−+B_−+c，S_+=S_−+a−b，则

\[
 \Delta J_r^G=\frac{(B_-+c)a}{S_-S_+},\qquad
 \Delta J_r^D=\frac{A_-b}{S_-S_+}.
 \tag{IS2}
\]

两项之和为Φ(s)−Φ(s−)。这不是“先good、后bad”两段差的替换。连续部分仍为(B+c)S^{-2}dI^G和AS^{-2}dI^D，包括奇异连续测度。

**终点整块抵消。** h处的联合阈值跳满足ΔJ_h=Φ_h−Φ_{h−}，故精确地

\[
 \Phi_\tau-\Phi_h+J_{(\tau,h]}
 =\Phi_\tau-\Phi_{h-}+J_{(\tau,h)}.
 \tag{IS3}
\]

以下所有事件集合统一使用τ<θ_r(v)<h，Φ终点统一改为h−。不能只删除good端点注入而继续用右态Φ_h。连续积分无端点原子；源阈值原子、good/bad同刻跳均包含在IS2–3。若h=τ，原交通为零，以下按空窗处理。

## 2. 可保留任意合法事件筛选的good注入命题

固定参照时间T∈[h,g]。它是本行整窗固定参数。令

\[
 \Gamma_r=\{v\in E_*:\tau<\theta_r(v)<h\},\qquad
 R_{r,T}(v)=\frac{w_{\theta_r(v)}(v)}{w_T(v)}\ge1.
 \tag{IS4}
\]

任选可测0≤χ_r(v)≤1作为阈值事件筛选；它可依ξ、实际θ_r和来源v，但不得按正在积分的外hard z重新选。定义终端保留质量

\[
 d\zeta_{r,T,\chi}(v)=1_{\Gamma_r}(v)\chi_r(v)\rho_vw_T(v)d\nu(v),
 \qquad
 M_{r,T,\chi}(\lambda)=\zeta_{r,T,\chi}\{R_{r,T}>\lambda\}.
 \tag{IS5}
\]

χ只是选取原注入的非负部分，不改变原ρ或α。在连续注入中按源χ加权；在原子处令a_χ为被选good原始质量，以IS2的共同系数(B_-+c)/(S_-S_+)乘a_χ，得到选中注入J^G_{r,χ}。因此对任意一组事件筛选都准确有J^G=J^G_χ+J^G_{1−χ}，没有复制容量。

**一般命题。** 保留上述全部量词，则

\[
 \boxed{J^G_{r,\chi}((\tau,h))
 \le\mathscr L_c(\zeta_{r,T,\chi},R_{r,T})
 :=\int_0^\infty\log\left(1+\frac{M_{r,T,\chi}(\lambda)}c\right)d\lambda.}
 \tag{IS6}
\]

此处ν可有原子、连续部分或任意坐标相关；时间推前测度可含绝对连续、奇异连续和原子。所有原正weights在有限合法行严格正，R有限；由wθ/wT≤(T/θ)^n≤(T/τ)^n，右侧有限。本命题没有把pair门Ψ/FA直接移植到注入：只有已合法选出的来源／时间事件可作χ。若完整ST4仍含未选J^G_{1−χ}，必须保留或另行支付它；不能仅因原交通带某pair门就无证明删除这部分注入。

## 3. IS6的逐层对数证明：连续与联合原子同时成立

固定r,T,χ。对每个λ≥0，定义被选终端质量的累计到达量

\[
 F_\lambda(t)=\int_{\Gamma_r\cap\{\theta_r\le t\}}
 1_{\{R_{r,T}>\lambda\}}\chi_r\rho_vw_T(v)d\nu(v),
 \quad \tau\le t<h.
 \tag{IS7}
\]

F_λ非减，F_λ(τ)=0、F_λ(h−)=M(λ)。每个已到达good来源此后仍在该cut高侧且不会删除，w_t≥w_T，所以

\[
 A_r(t)\ge F_\lambda(t),\qquad A_r(t-)\ge F_\lambda(t-).
 \tag{IS8}
\]

### 连续部分

源权重层分解给dI^G_χ=∫₀^∞dF_λ dλ，因为w_θ=R w_T。对连续部分，

\[
 \frac{B+c}{S^2}\le\frac1{A+c}\le\frac1{F_\lambda+c}.
\]

对各λ的连续Stieltjes测度积分，包含奇异连续部分，得到其对数增量上界。这里未把源事件取时间sup，也未交换任何来源上确界。

### 同刻原子

设本时刻全部good进入原始质量a、被选质量a_χ，全部bad离开质量b。设被选事件在该时刻的终端质量为f，选中并满足R>λ的质量为f_λ；F_-(λ)为此前被选λ层累计，F_-为此前全部被选终端累计。由IS2和S_-≥B_-+c、S_+≥A_-+a+c，

\[
 \Delta J^G_\chi\le\frac{a_\chi}{A_-+a+c}
 \le\frac{a_\chi}{F_-+f+c}.
\]

第二步用A_-≥F_-及a≥f，不把a替成a_χ或忽略bad的实际b。又a_χ=∫f_λdλ，且F_-(λ)≤F_-、f_λ≤f，故

\[
 \Delta J^G_\chi
 \le\int_0^\infty\frac{f_\lambda}{c+F_-(\lambda)+f_\lambda}d\lambda
 \le\int_0^\infty
 \log\frac{c+F_-(\lambda)+f_\lambda}{c+F_-(\lambda)}d\lambda.
 \tag{IS9}
\]

这直接处理多来源及同刻good/bad混合原子；没有改变IS2的分项，没有给同刻来源安排额外收费次序。最后把连续对数增量和原子对数差相加，对各λ望远镜为log(1+M(λ)/c)，再用非负Tonelli，证明IS6。所用仅为层分解、log链式法则和x/(1+x)≤log(1+x)，不援引未核重排定理。

## 4. 与旧帽的比较、条件对数结论

由log(1+x)≤x和层分解，

\[
 \boxed{\mathscr L_c\le\frac1c\int R_{r,T}d\zeta_{r,T,\chi}
 =\frac1c\int_{\Gamma_r}\chi_r\rho_vw_{\theta_r(v)}d\nu(v).}
 \tag{IS10}
\]

所以IS6精确log-tail版本始终不大于旧I^G_χ/c。T=h保留较多终端质量、R较小；T=g更直接与三核terminal good相接。本文不比较两个最终总帽的单调性。

若实际选中事件满足R_{r,T}≤R₀，则

\[
 J^G_{r,\chi}\le R_0\log\left(1+\frac{\zeta_{r,T,\chi}(\Gamma_r)}c\right).
 \tag{IS11}
\]

R₀是实际保留比条件，不能由“同一ν”或来源独立性替代；无该条件时使用IS6。尤其wθ/wT在一般窗可很大，本文不把R₀设为绝对常数再声称全一般结果。

## 5. 跨cut的单来源阈值序列与熵压缩

令D=Σ_rd_r。D=0时所有加权注入为零；以下D>0。定义

\[
 \mathcal N_{T,\chi}(v,\lambda)=
 \sum_{r:\tau<\theta_r(v)<h}d_r\chi_r(v)
 1_{\{R_{r,T}(v)>\lambda\}},
\]
\[
 \Xi_{T,\chi}(\lambda)
 =\int_{E_*}\rho_vw_T(v)\mathcal N_{T,\chi}(v,\lambda)d\nu(v)
 =\sum_rd_r M_{r,T,\chi}(\lambda).
 \tag{IS12}
\]

逐λ以权d_r/D对log作Jensen（亦可直接由log凹性验证）得到

\[
 \boxed{\sum_rd_rJ^G_{r,\chi}
 \le\sum_rd_r\mathscr L_{c,r}
 \le D\int_0^\infty\log\left(1+\frac{\Xi_{T,\chi}(\lambda)}{cD}\right)d\lambda.}
 \tag{IS13}
\]

右侧虽比逐cut精确log-tail帽略大，但同样≤(1/c)Σ_rd_rI^G_{r,χ}，不会恢复旧α₀β₀H_n乘积作为必付价。

这是真正的单来源跨cut求和：θ_r随r非减，w_θ随θ非增，故R_{r,T}随r非增。对固定v、λ，窗内满足R>λ的cut是从k_τ(v)开始的一段前缀（χ可在此前缀中再删事件）。设其右端为K_λ(v)，空前缀取K_λ(v)=k_τ(v)，并令H₀=0；R151给d_r≤min(1,β₀/(r+1))，其中β₀=∫D₀w_τdν/c。因此

\[
 0\le\mathcal N_{T,\chi}(v,\lambda)
 \le\min\{K_\lambda(v)-k_\tau(v),\,
 \beta_0[H_{K_\lambda(v)}-H_{k_\tau(v)}]\}.
 \tag{IS14}
\]

同刻多坐标阈值以相同θ、相同R出现于多个cut，按原重数保留。IS14没有假设d_r自身单调，也不把“每源n次”误作一份固定概率下的n次预算。

## 6. 用真实三核容量支付中等保留比；保留高尾超额

现在取T=g，保持原terminalgood门p w_g(v)≤KQ_v，即r_g(v)≥1。准确地

\[
 d\zeta_{r,g,\chi}
 =C\frac{\rho_v}{r_g(v)}\chi_r1_{\Gamma_r}d\mu(v),
 \qquad R_{r,g}(v)=\frac{r_g(v)}{r_{\theta_r(v)}(v)}.
 \tag{IS15}
\]

因此IS13可写成完全基于同一原三核容量的log-tail上帽

\[
 \sum_rd_rJ^G_{r,\chi}
 \le D\int_0^\infty\log\left[
 1+\frac{C}{cD}\int_{E_*}\frac{\rho_v}{r_g(v)}
 \mathcal N_{g,\chi}(v,\lambda)d\mu(v)\right]d\lambda.
 \tag{IS16}
\]

任意整行共同R₀≥1，分开λ≤R₀与λ>R₀；前者保留log，后者仅用log(1+x)≤x。得到新的两项上帽

\[
 \boxed{\begin{aligned}
 \sum_rd_rJ^G_{r,\chi}\le{}&
 D R_0\log\left[1+\frac{C}{cD}\int_{E_*}\frac{\rho_v}{r_g(v)}
 \sum_{r:\tau<\theta_r(v)<h}d_r\chi_r(v)d\mu(v)\right]\\
 &+\frac Cc\int_{E_*}\rho_v
 \sum_{r:\tau<\theta_r(v)<h}d_r\chi_r(v)
 \left(\frac1{r_{\theta_r(v)}(v)}-\frac{R_0}{r_g(v)}\right)_+
 d\mu(v).
 \end{aligned}}
 \tag{IS17}
\]

第一项进一步≤D R₀log(1+(C/c)m)，因为Σcross d_rχ≤D、ρ≤1、r_g≥1且μ(E_*)≤m=μ(E₊)。取c=e_g时，原high给C/c≤1/2，故

\[
 \boxed{\sum_rd_rJ^G_{r,\chi}\le
 D R_0\log(1+m/2)
 +\frac C{e_g}\int_{E_*}\rho_v\sum_{\mathrm{cross}}d_r\chi_r(v)
 \left(\frac1{r_{\theta_r(v)}(v)}-\frac{R_0}{r_g(v)}\right)_+d\mu(v).}
 \tag{IS18}
\]

未重选α或ρ。首项是共同三核容量的对数费，**不是**原始good质量α₀的线性费。第二项只保留高retention阈值的截断逆r超额；若实际事件全部满足w_θ/w_g≤R₀，则它为零，这是有效条件结论。一般输入中它未获统一上帽，不能把它删掉。

**低retention并非新增实付空间分支。** JG总量不等于可求和的净输运费；特别晚时才穿越的R≈1事件，可能尚未来得及耗散。IS3及IS20始终保留−Φ(h−)，没有为取得IS18而删除或重复领取该终端减项。

IS17–18是方便的分支放大，可能比精确IS16松；“总不超过旧线性帽”严格指IS6/IS13的完整log-tail版本，不能对任意粗化后的IS18重复作此保证。可随时取这些合法上帽与旧线性帽的较小者，而不额外复制来源容量。

## 7. 与bad log、边界项及原接收外价的组合

bad注入的独立log帽由Astra负责，本稿不重证或登记；已读同目录injection_audit.md的IA1–3，核对分项与端点一致。使用其与IS2相同分项的结论

\[
 J_r^D((\tau,h))\le\frac14
 \log\frac{B_r(\tau)+c}{B_r(h-)+c}.
 \tag{IS19}
\]

全槽组合取χ=1（若χ<1，另加未选good注入或它已有的合法费用）。定义

\[
 \mathcal E_{log}(\xi)=
 \sum_rd_r[\Phi_r(\tau)-\Phi_r(h-)]
 +\sum_rd_r\mathscr L_c(\zeta_{r,T,1},R_{r,T})
 +\frac14\sum_rd_r\log\frac{B_r(\tau)+c}{B_r(h-)+c}.
 \tag{IS20}
\]

由IS3、IS6、IS19和R151 ST4，有H_cut≤E_log且E_log≥0，并得原完整剩余正交通的合法外价

\[
 \boxed{2\Lambda P_{rem}\le\frac{128\Lambda}{3}
 \mathbb E\sum_{V,j}\int p(x-y)\mathcal E_{log}(\omega,V,j,x,y)
 \,dx\,d\beta_V(y).}
 \tag{IS21}
\]

如需单来源crosscut形式，可把good项改用IS13、IS16或IS17，仍是明确上界。初末Φ边界必须保留；不能将其负端点复制到原signed负账。实际c=e_g、C、d_r、终端集合、ρ、T或g、窗口、r_θ及三核都依原ξ；这些依赖仍在接收x积分内，不能当作与x或j无关的统一常数。β没有换成ν，原hard帽16/3只用一次，dt/t已在注入与输运中处理，不另乘log2。

尚欠估计是IS21右侧≤εX+Cε√n polylog(2+n)Wβ。新增进展把good注入从旧线性质量费严格压到保留比分布的log-tail，并以真实三核容量支付中等保留比；余部是IS17中的阈值截断逆r超额、实际bad log及端点／选择器接收费用。没有一般retention常数R₀，没有免费跨j合并，也没有将这些尚未支付的实际接收函数改名为全一般付款。

仅写本文件；未Git、未修改他人文件。有限证明任务完成后停止。
