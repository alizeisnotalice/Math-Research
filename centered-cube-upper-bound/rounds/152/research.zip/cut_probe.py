#!/usr/bin/env python3
"""Rebuild R152 cut-potential summaries from frozen R151 points; no kernels."""
from fractions import Fraction as F
from pathlib import Path
from decimal import Decimal,localcontext,ROUND_FLOOR,ROUND_CEILING
import argparse,json,zipfile,hashlib,math,sys
sys.set_int_max_str_digits(0)
W=Path(__file__).resolve().parent
R151=W.parent.parent/'151/research.zip'
DETAIL=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json')
R136=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/active_traffic_v2.json')
R142=Path('/Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015/centered_cube_round142_20261015/numeric_receiver.json')
OUT=W/'cut_probe.json'
HASH={'compact':'6bfc604946efcb7461b354e1d1f5347319b519548e1c4448a35643b5f911b731','detail':'6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9','r136':'1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de','r142':'c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55'}
def f(x): return x if isinstance(x,F) else F(str(x))
def sh(b): return hashlib.sha256(b).hexdigest()
def weight(th,t): return math.prod((min(F(1),a/t) for a in th),start=F(1))
def prof(th,t,right): return [weight(x,t) for x in th],[sum(a<=t if right else a<t for a in x) for x in th]
def enclosure(q,p=50):
    n,d=q.numerator,q.denominator
    if not n:return {'lo':'0','hi':'0','digits':p}
    sign='-' if n<0 else '';n=abs(n);e=len(str(n))-len(str(d))
    if e>=0:
        if n<d*10**e:e-=1
    elif n*10**(-e)<d:e-=1
    qexp=e-p+1
    def ds(k,places=0):
        sg='-' if k<0 else '';z=str(abs(k))
        if places:
            if len(z)<=places:z='0'*(places+1-len(z))+z
            z=z[:-places]+'.'+z[-places:];z=z.rstrip('0').rstrip('.')
        return sg+z
    if qexp>=0:
        step=10**qexp;den=d*step;lo=n//den*step;hi=((n+den-1)//den)*step
        if sign:lo,hi=-hi,-lo
        return {'lo':ds(lo),'hi':ds(hi),'digits':p}
    places=-qexp;scale=10**places;num=n*scale;lo=num//d;hi=(num+d-1)//d
    if sign:lo,hi=-hi,-lo
    return {'lo':ds(lo,places),'hi':ds(hi,places),'digits':p}
def enc(x):
    if isinstance(x,F):return enclosure(x)
    if isinstance(x,Decimal):return str(x)
    if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x

def exact_cut(th,nu,rho,good,tau,h,c):
    events=sorted({a for tt in th for a in tt if tau<a<h});times=[tau,*events,h]
    def state(t,right):
        w,k=prof(th,t,right)
        A=[sum((rho[i]*nu[i]*w[i] for i in range(6) if good[i] and rho[i]>0 and k[i]>r),F(0)) for r in range(4)]
        B=[sum((nu[i]*w[i] for i in range(6) if not good[i] and k[i]<=r),F(0)) for r in range(4)]
        return w,k,A,B,[A[r]/(A[r]+B[r]+c) for r in range(4)]
    s0=state(tau,True); sh=state(h,False);d=[s0[3][r]/(s0[3][r]+(r+1)*c) for r in range(4)]
    init=sum((d[r]*s0[4][r] for r in range(4)),F(0));term=-sum((d[r]*sh[4][r] for r in range(4)),F(0));G=D=drift=T=F(0);evlog=[];seglog=[]
    for t in events:
        l=state(t,False);rr=state(t,True)
        for r in range(4):
            a=rr[2][r]-l[2][r];b=l[3][r]-rr[3][r];den=(l[2][r]+l[3][r]+c)*(rr[2][r]+rr[3][r]+c)
            assert a>=0 and 0<=b<=l[3][r]
            jg=(l[3][r]+c)*a/den;jd=l[2][r]*b/den;j=rr[4][r]-l[4][r];assert j==jg+jd
            G+=d[r]*jg;D+=d[r]*jd;evlog.append({'t':t,'r':r,'a':a,'b':b,'Phi_minus':l[4][r],'Phi_plus':rr[4][r],'JG':jg,'JD':jd,'ST8':j})
    for l,rgt in zip(times,times[1:]):
        pl=state(l,True);pr=state(rgt,False);mid=(l+rgt)/2;k=pl[1] if l<rgt else []
        for r in range(4):
            diff=pl[4][r]-pr[4][r];assert diff>=0;drift+=d[r]*diff;seglog.append({'lo':l,'hi':rgt,'r':r,'drop':diff,'weighted_drop':d[r]*diff})
        cs=[math.prod((a for a in tt if a<mid),start=F(1)) for tt in th];ks=[sum(a<mid for a in tt) for tt in th];assert set(ks)<={0,4}
        az=sum((nu[i]*cs[i] for i in range(6) if ks[i]==4),F(0));bz=sum((nu[i] for i in range(6) if ks[i]==0),F(0));zl=l**-4;zr=rgt**-4;el=az*zl+bz;er=az*zr+bz
        for v in range(6):
            if not(good[v] and rho[v]>0):continue
            for u in range(6):
                if good[u] or ks[v]-ks[u]!=4:continue
                T+=rho[v]*nu[v]*nu[u]*cs[v]*cs[u]*(zl-zr)/(el*er)
    H=init+term+G+D;assert H==drift and 0<=T<=4*H
    rawA=sum((nu[i]*rho[i]*s0[0][i] for i in range(6) if good[i] and rho[i]>0),F(0));rawB=sum((nu[i]*s0[0][i] for i in range(6) if not good[i]),F(0));alpha=rawA/c;beta=rawB/c;sd=sum(d);coarse=4*(alpha+beta/4)*sd;harm=4*(alpha+beta/4)*min(F(4),beta*F(25,12));assert 4*H<=coarse<=harm
    logd=[];lor=[];linG=[];linD=[]
    with localcontext() as ctx:
      ctx.prec=80;dec=lambda x:Decimal(x.numerator)/Decimal(x.denominator)
      for r in range(4):
        logd.append((dec((s0[3][r]+c)/(sh[3][r]+c))).ln()/4)
        vals=[]
        for i in range(6):
            theta=sorted(th[i])[r]
            if good[i] and rho[i]>0 and tau<theta<h:
                wh=weight(th[i],h);vals.append((weight(th[i],theta)/wh,rho[i]*nu[i]*wh))
        ll=Decimal(0);last=F(0)
        for R in sorted({x[0] for x in vals}):
            tail=sum((z for ratio,z in vals if ratio>=R),F(0));ll+=dec(R-last)*(1+dec(tail/c)).ln();last=R
        lor.append(ll);linG.append(dec(sum((z*R for R,z in vals),F(0))/c))
        bevent=sum((nu[i]*weight(th[i],t) for t in events for i in range(6) if not good[i] and sum(a<t for a in th[i])<=r<sum(a<=t for a in th[i])),F(0))
        linD.append(dec(bevent/(4*c)))
      nl={key:sum((dec(d[r])*x[r] for r in range(4)),Decimal(0)) for key,x in [('logD',logd),('LorentzG',lor),('linearG',linG),('linearD',linD)]}
    assert all(lor[r]<=linG[r] for r in range(4))
    cert={'initial':init,'negative_terminal':term,'HG':G,'HD':D,'Hcut':H,'4H':4*H,'Tcut':T,'coarse_exact_dr':coarse,'coarse_harmonic':harm,'alpha0':alpha,'beta0':beta,'sum_d':sd,'rawA_tau':rawA,'rawB_tau':rawB,'logD_weighted':nl['logD'],'lorentzG_weighted':nl['LorentzG'],'linearG_weighted':nl['linearG'],'linearD_weighted':nl['linearD'],'candidateHcut_80_digit':str(dec(init+term)+nl['logD']+nl['LorentzG']),'identity_checks':{'ST8_events':len(evlog),'ST9_segments':len(seglog),'Tcut_le_4H':True,'4H_le_coarse':True,'coarse_le_harmonic':True}}
    logcert={'weighted':{k:str(v) for k,v in nl.items()},'checks':{'LorentzG_le_linearG':True,'logD_vs_event_linearD':'no order assumed'}}
    return cert,evlog,seglog,logcert

def num(th,nu,rho,good,tau,h,c):
    tf=float(tau);hf=float(h);cf=float(c);af=[[float(a) for a in tt] for tt in th];nf=list(map(float,nu));rf=list(map(float,rho))
    def state(t,right):
        w=[math.prod(min(1.,a/t) for a in aa) for aa in af];k=[sum(a<=t if right else a<t for a in aa) for aa in af]
        A=[sum(rf[i]*nf[i]*w[i] for i in range(6) if good[i] and rf[i]>0 and k[i]>r) for r in range(4)];B=[sum(nf[i]*w[i] for i in range(6) if not good[i] and k[i]<=r) for r in range(4)];phi=[A[r]/(A[r]+B[r]+cf) for r in range(4)];return w,k,A,B,phi
    events=sorted({x for aa in af for x in aa if tf<x<hf});times=[tf,*events,hf];s0=state(tf,True);sh=state(hf,False);d=[s0[3][r]/(s0[3][r]+(r+1)*cf) for r in range(4)]
    init=sum(d[r]*s0[4][r] for r in range(4));term=-sum(d[r]*sh[4][r] for r in range(4));G=D=0.;IG=[0.]*4;ID=[0.]*4
    for t in events:
        l=state(t,False);rr=state(t,True)
        for r in range(4):
            a=rr[2][r]-l[2][r];b=l[3][r]-rr[3][r];den=(l[2][r]+l[3][r]+cf)*(rr[2][r]+rr[3][r]+cf);G+=d[r]*(l[3][r]+cf)*a/den;D+=d[r]*l[2][r]*b/den;IG[r]+=a;ID[r]+=b
    T=0.
    for l,rgt in zip(times,times[1:]):
        mid=(l+rgt)/2;ks=[sum(a<mid for a in aa) for aa in af];cs=[math.prod(a for a in aa if a<mid) for aa in af];az=sum(nf[i]*cs[i] for i in range(6) if ks[i]==4);bz=sum(nf[i] for i in range(6) if ks[i]==0);zl=l**-4;zr=rgt**-4;den=(az*zl+bz)*(az*zr+bz)
        for v in range(6):
            if good[v] and rf[v]>0:
                for u in range(6):
                    if not good[u] and ks[v]-ks[u]==4:T+=rf[v]*nf[v]*nf[u]*cs[v]*cs[u]*(zl-zr)/den
    rawA=sum(rf[i]*nf[i]*math.prod(min(1.,a/tf) for a in af[i]) for i in range(6) if good[i] and rf[i]>0);rawB=sum(nf[i]*math.prod(min(1.,a/tf) for a in af[i]) for i in range(6) if not good[i]);alpha=rawA/cf;beta=rawB/cf;sd=sum(d);coarse=4*(alpha+beta/4)*sd;harm=4*(alpha+beta/4)*min(4.,beta*25/12)
    logD=0.;lor=0.;linG=linD=0.
    for r in range(4):
        bh=state(hf,False)[3][r];bt=s0[3][r];logD+=d[r]*.25*math.log((bt+cf)/(bh+cf));vals=[]
        for i in range(6):
            theta=sorted(af[i])[r]
            if good[i] and rf[i]>0 and tf<theta<hf:
                wh=math.prod(min(1.,a/hf) for a in af[i]);wt=math.prod(min(1.,a/theta) for a in af[i]);vals.append((wt/wh,rf[i]*nf[i]*wh))
        last=0.
        for R in sorted({x[0] for x in vals}):
            lor+=d[r]*(R-last)*math.log1p(sum(z for rr,z in vals if rr>=R)/cf);last=R
        linG+=d[r]*sum(z*R for R,z in vals)/cf
        be=sum(nf[i]*math.prod(min(1.,a/t) for a in af[i]) for t in events for i in range(6) if not good[i] and sum(a<t for a in af[i])<=r<sum(a<=t for a in af[i]));linD+=d[r]*be/(4*cf)
    H=init+term+G+D;return {'eligible':True,'initial':init,'negative_terminal':term,'HG':G,'HD':D,'Hcut':H,'4H':4*H,'Tcut':T,'coarse_exact_dr':coarse,'coarse_harmonic':harm,'logD_weighted':logD,'lorentzG_weighted':lor,'linearG_weighted':linG,'linearD_weighted':linD,'candidateHcut':init+term+logD+lor,'numeric_errors':{'ST9_abs':abs(H-(init+term+G+D)),'Tcut_bound_violation':max(0.,T-4*H),'coarse_bound_violation':max(0.,4*H-coarse),'harmonic_bound_violation':max(0.,coarse-harm)},'candidate_checks':{'LorentzG_le_linearG':lor<=linG+1e-12}}

def fa_x0(th,nu,rho,good,tau,h,p,Q,bfa):
    events=sorted({a for tt in th for a in tt if tau<a<h});times=[tau,*events,h];ans=F(0);count=0
    for l,rgt in zip(times,times[1:]):
        mid=(l+rgt)/2;k=[sum(a<mid for a in tt) for tt in th];cs=[math.prod((a for a in tt if a<mid),start=F(1)) for tt in th];az=sum(nu[i]*cs[i] for i in range(6) if k[i]==4);bz=sum(nu[i] for i in range(6) if k[i]==0);zl=l**-4;zr=rgt**-4;el=az*zl+bz
        for v in range(6):
            if not(good[v] and rho[v]>0):continue
            for u in range(6):
                if good[u] or k[v]-k[u]!=4:continue
                zcut=Q[v]/(bfa*4*p*cs[v]);zlo=max(zr,zcut)
                if zlo<zl:ans+=rho[v]*nu[v]*nu[u]*cs[v]*cs[u]*(zl-zlo)/(el*(az*zlo+bz));count+=1
    return ans,count

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--detail',type=Path,default=DETAIL);ap.add_argument('--r136',type=Path,default=R136);ap.add_argument('--r142',type=Path,default=R142);ap.add_argument('--r151-zip',type=Path,default=R151);ap.add_argument('--out',type=Path,default=OUT);a=ap.parse_args()
    cb=zipfile.ZipFile(a.r151_zip).read('receiver_probe.json');db=a.detail.read_bytes();b136=a.r136.read_bytes();b142=a.r142.read_bytes()
    assert [sh(x) for x in (cb,db,b136,b142)]==[HASH['compact'],HASH['detail'],HASH['r136'],HASH['r142']]
    old=json.loads(cb);detail=json.loads(db);r136=json.loads(b136);r142=json.loads(b142);src=next(x for x in r136['cases'] if x['id']=='I1');atoms=src['atoms'];th=[[f(z) for z in x['thresholds']] for x in atoms];nu=list(map(f,old['constants']['nu_exact']));tau=f(src['derived']['tau']);h=f(src['derived']['h']);g=f(src['derived']['g']);eg=sum((nu[i]*weight(th[i],g) for i in range(6)),F(0))
    rows=[]
    for m in ('4','8'):
        for i,r in enumerate(detail['point_records'][m]):
            rho=list(map(f,r['rho']));c2=2*f(r['q'])/f(r['p']);legal=r['gates']['high'] and c2<=eg;cs={}
            for key,c,ok in [('eg',eg,True),('2C',c2,legal)]:cs[key]=num(th,nu,rho,r['good'],tau,h,c) if ok else {'eligible':False}
            rows.append({'m':m,'i':i,'orig':r,'candidates':cs,'legal2c':legal})
    aggregate={};keys=('4_initial','negative_4_terminal','4_HG','4_HD','4_Hcut','Tcut','ST14_exact','ST14_harmonic','4_logD','4_lorentzG','4_linearG','4_linearD','4_candidateHcut','saved_I')
    fields={'4_initial':('initial',4),'negative_4_terminal':('negative_terminal',4),'4_HG':('HG',4),'4_HD':('HD',4),'4_Hcut':('Hcut',4),'Tcut':('Tcut',1),'ST14_exact':('coarse_exact_dr',1),'ST14_harmonic':('coarse_harmonic',1),'4_logD':('logD_weighted',4),'4_lorentzG':('lorentzG_weighted',4),'4_linearG':('linearG_weighted',4),'4_linearD':('linearD_weighted',4),'4_candidateHcut':('candidateHcut',4)}
    for m in ('4','8'):
      for wt in ('original','corrected'):
       for cv in ('eg','2C'):
        for domain in ('pre','post','pre_high_legal','post_high_legal'):
         A={k:0. for k in keys};B=A.copy();mass=vol=hmass=0.;count=0
         for z in rows:
            if z['m']!=m:continue
            r=z['orig'];d=z['candidates'][cv]
            if not d['eligible'] or (domain.startswith('pre') and not r['before']) or (domain.startswith('post') and not r['after']) or (domain.endswith('high_legal') and not z['legal2c']):continue
            w=float(f(r['dx_weight' if wt=='original' else 'dx_weight_corrected']));p=r['p'];q=r['q'];hard=float(f(r['hardmass']));aweight=w*p;bweight=aweight*hard/q if q else 0.;count+=1;mass+=aweight;vol+=w;hmass+=w*hard
            vals={name:float(d[field])*mult for name,(field,mult) in fields.items()};vals['saved_I']=r['I']
            for name,v in vals.items():A[name]+=aweight*v;B[name]+=bweight*v
         def share(X):
            gross=X['4_initial']+X['4_HG']+X['4_HD'];net=X['4_Hcut'];return {'gross_positive':gross,'initial_over_gross':X['4_initial']/gross if gross else None,'HG_over_gross':X['4_HG']/gross if gross else None,'HD_over_gross':X['4_HD']/gross if gross else None,'terminal_return_over_gross':-X['negative_4_terminal']/gross if gross else None,'net_piece_shares':{q:X[q]/net if net else None for q in ('4_initial','negative_4_terminal','4_HG','4_HD')},'injection_over_initial':(X['4_HG']+X['4_HD'])/X['4_initial'] if X['4_initial'] else None}
         aggregate[f'{m}/{wt}/{cv}/{domain}']={'count':count,'sum_p_weight':mass,'dx_volume':vol,'hard_mass_weighted':hmass,'A':A,'B':B,'A_shares':share(A),'B_shares':share(B)}
    controls=[]
    selected=[]
    for m in ('4','8'):
        xx=old['summaries'][m]['extrema']['max_weighted_B_contribution']['xq'];ii=next(z['i'] for z in rows if z['m']==m and z['orig']['xq']==xx);selected.append((f'm{m}_max_weighted_B',m,ii))
    for label,m,i in selected:
        z=next(z for z in rows if z['m']==m and z['i']==i);r=z['orig'];rho=list(map(f,r['rho']))
        for cv,c,ok in [('eg',eg,True),('2C',2*f(r['q'])/f(r['p']),r['gates']['high'] and 2*f(r['q'])/f(r['p'])<=eg)]:
            if not ok:continue
            ce,ev,sg,lc=exact_cut(th,nu,rho,r['good'],tau,h,c);controls.append({'label':label,'grid_m':m,'row_index':i,'xq':r['xq'],'c_version':cv,'c':enclosure(c),'cut_certificate':enc(ce),'events':enc(ev),'continuous_drops':enc(sg),'log_candidate_80_digit':lc})
    x0=old['x0_control'];rrho=list(map(f,x0['rho']));cc0=next(x for x in r142['cases']['I1']['verifications'] if x['id']==0 and x['distribution']=='control');p0=f(cc0['p']);Q=[sum((f(cc0[k][i]) for k in ('K1','K2','J')),F(0))/3 for i in range(6)];bfa=f(src['parameters']['B_FA']);fa,nfa=fa_x0(th,nu,rrho,x0['good'],tau,h,p0,Q,bfa)
    for cv,c in [('eg',eg),('2C',2*f(x0['q'])/f(x0['p']))]:
        ce,ev,sg,lc=exact_cut(th,nu,rrho,x0['good'],tau,h,c);assert fa<=ce['Tcut']<=ce['4H']
        controls.append({'label':'x0_control','xq':['0']*4,'c_version':cv,'c':enclosure(c),'cut_certificate':enc(ce),'events':enc(ev),'continuous_drops':enc(sg),'log_candidate_80_digit':lc,'canonical_FA':{'value':enclosure(fa),'integrated_pair_terms':nfa,'p':enclosure(p0),'Q_v':enc(Q),'B_FA':enclosure(bfa),'checks':{'IFA_le_Tcut':True,'Tcut_le_4Hcut':True}}})
    # profile rounding discrepancies
    wg=max(abs(weight(th[i],g)-f(atoms[i]['wg'])) for i in range(6));dc=dr=F(0);pc=0
    for s in src['score_segments']:
        mid=(f(s['lo'])+f(s['hi']))/2
        for i in range(6):
            v=math.prod((a for a in th[i] if a<mid),start=F(1));diff=abs(v-f(s['c'][i]));dc=max(dc,diff);dr=max(dr,diff/v);pc+=1
    def sci(q):
        with localcontext() as ctx:
            ctx.prec=60;return format(Decimal(q.numerator)/Decimal(q.denominator),'.30E')
    residuals={k:max((z['candidates'][cv].get('numeric_errors',{}).get(k,0.) for z in rows for cv in ('eg','2C') if z['candidates'][cv]['eligible']),default=0.) for k in ('ST9_abs','Tcut_bound_violation','coarse_bound_violation','harmonic_bound_violation')}
    numchecks={'LorentzG_le_linearG':all(z['candidates'][cv]['candidate_checks']['LorentzG_le_linearG'] for z in rows for cv in ('eg','2C') if z['candidates'][cv]['eligible']),'ST9_pass_1e-12':residuals['ST9_abs']<1e-12,'Tcut_le_4H_numeric':residuals['Tcut_bound_violation']==0,'4H_le_ST14_numeric':residuals['coarse_bound_violation']==0,'ST14_le_harmonic_numeric':residuals['harmonic_bound_violation']==0}
    out={'status':'completed','scope':'fixed-I1 finite saved-point cut-potential postprocess; no kernel or receiver point evaluations; no FULL or quadrature certificate','inputs':{'r151_compact_sha256':sh(cb),'r151_zip_sha256':sh(a.r151_zip.read_bytes()),'detail_sha256':sh(db),'r136_sha256':sh(b136),'r142_sha256':sh(b142),'plan_sha256':sh((W/'cut_numeric_plan.md').read_bytes()),'producer_sha256':sh(Path(__file__).read_bytes())},'canonical':{'nu_exact':list(map(str,nu)),'tau':enclosure(tau),'h':enclosure(h),'g':enclosure(g),'eg':enclosure(eg),'source_count':6,'profile_discrepancy_vs_R136_saved':{'wg_max_abs_decimal':sci(wg),'score_c_max_abs_decimal':sci(dc),'score_c_max_relative_decimal':sci(dr),'source_comparisons':6,'score_segment_comparisons':pc}},'certificate_representation':'Fraction exact controls encoded as 50-digit outward decimal enclosures via integer division; 80-digit Decimal logarithmic diagnostics; every other saved point is binary64 formula diagnostic','execution_audit':{'new_kernel_evaluations':0,'new_receiver_points':0,'rows_processed':len(rows),'binary64_formula_row_c_versions':sum(z['candidates'][cv]['eligible'] for z in rows for cv in ('eg','2C')),'numeric_identity_checks':4*sum(z['candidates'][cv]['eligible'] for z in rows for cv in ('eg','2C')),'exact_fraction_control_rows':len(controls),'producer_invocations':None,'failed_invocations':None,'completed_invocations':None,'adopted_result_invocation':'latest successful output; historical ordinal unavailable','numeric_max_residuals':residuals,'numeric_check_summary':numchecks},'aggregate':aggregate,'exact_controls':controls,'rows_omitted_regenerable_from_pinned_inputs':len(rows),'rows':[]}
    a.out.write_text(json.dumps(out,separators=(',',':'))+'\n');print('rows',len(rows),'sha',sh(a.out.read_bytes()),'bytes',a.out.stat().st_size)
if __name__=='__main__':main()
