# R152 已存receiver点的cut费用纯后处理（冻结方案）

目标仅判别R151有限接收诊断的cut上帽主要来自初端势还是阈值注入，不增加质量、接收点、核评价或网格。输入仍单I1(12,8,8)、原m4/m8共8376个已存点及原权/精确重叠修正权。实现cut_probe.py/json/notes由Luna独占；Sol独立核验控制点及聚合。不把必要模型或canonical冻结系数称FULL，不拟合维数阶。

## 1. 冻结输入与canonical合同

R151 research.zip内receiver_probe.json SHA `6bfc604946efcb7461b354e1d1f5347319b519548e1c4448a35643b5f911b731`，detail路径由其detail_output读取并核SHA `6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9`。明细默认 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json`。R136 source SHA `1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de`；R142 SHA `c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55`。只读历史ZIP/原输入，不复制大明细进本轮归档。R151 x0_control独立作为额外已存在控制记录，不计新receiver点。

父已批准canonical模型：由R136保存的thresholds十进制转Fraction，定义连续权w_i(t)=∏min(1,a_ij/t)，score右态k_i(t)=#{a_ij<=t}。全部six-source nu保持R151 constants.nu_exact；各row rho、good、p、q、外hardmass与资格按保存数值十进制转Fraction冻结，不重新优化或重生成alpha。E+=good且rho>0且原A>0；D=bad（good补集），E*=全E+。不由原FA出现与否删source，不归一化两组，不删CORE/far的共同e。

先缓存canonical各阈值/时间的w以及canonical eg=Σnu w(g)。逐source/score段精确比较canonical c=∏当前活动threshold与R136保存score c、canonical wg与保存wg，记录最大绝对/相对差。R151保存profile为有限精度小数，不将它们当成同一精确连续w，不把舍入差伪装成额外阈值跳。canonical模型冻结rho/good未再次由alpha重生，不能升级为原FULL实例。

## 2. 时间、切口与共同事件

r=0,1,2,3。时间窗[τ,h]，端点一律右态；θ=τ初始化不再收费，τ<θ<=h收费（含终点）。事件取所有six-source阈值落窗内的不同有理值，按时间排序，同刻全部good进入/全部bad离开联合更新。来源被取terminal固定且模型Z全six-source，无删源事件；不据此证明真实FULL无删除。

各cut：

    A_r=ΣE+ rho_i nu_i w_i 1_{k_i>r};
    B_r=ΣD nu_i w_i 1_{k_i<=r};
    e=Σ全部six-source nu_i w_i;
    Phi_r=A_r/(A_r+B_r+c);
    d_r=B_r(τ,right)/(B_r(τ,right)+(r+1)c)。

连续score段中A、B按相同profile自然衰减；其D_r积分**精确等于Phi段起右态−Phi段末左态**，无需求积或log原函数。各段该差>=0须精确检查。

同刻θ的left/right定义：k_left=#{a<θ}，k_right=#{a<=θ}，w同一个连续值。a=A+−A-，b=B-−B+，S-=A-+B-+c，S+=A++B++c。a,b>=0且b<=B-。ST8：

    J=( (B-+c)a + A-b )/(S-S+) = Phi+−Phi-。

为四项占比，采用**同一联合分子的顺序无关分解**：

    JG=(B-+c)a/(S-S+)，JD=A-b/(S-S+)。

JG、JD非负，JG+JD=J；不先good再bad或先bad再good，不把ST12的顺序证明逐项无审照搬到JG/JD。ST12/14总帽仍可比较。

## 3. 两个c、四项与粗帽

版本eg：c=canonical eg，全部定义有效pre点可算。

版本2C：c=2Kq/p，p/q取R151该row冻结十进制；**仅原high标签为真且精确c<=canonical eg**的点允许。两条件分别保存；canonical检不通过则skip/invalid而非沿用旧浮点high。为可比，另报eg版本在同一pre_high_valid子域的结果；after域本已要求high，但仍逐row验canonical c合法性。

定义按d加权的四项：

    H_initial=Σr d_r Phi_r(τ,right);
    H_terminal=Σr d_r Phi_r(h,right);
    H_G=Σr d_r Σevents JG；H_D=Σr d_r Σevents JD；
    Hcut=H_initial−H_terminal+H_G+H_D。

精确核Hcut=Σr d_r Σcontinuous段(Phi_start−Phi_end)>=0。同时核每cut ST9及同刻ST8。输出4Hcut四项，末端带负号。报告net占比(initial/H、−terminal/H、HG/H、HD/H)时允许>100%，它们和为1；H=0标undefined。另报正账gross占比initial/(initial+HG+HD)、HG/gross、HD/gross及terminal返还/gross，避免抵消导致误读“主要贡献”。比较注入总HG+HD与initial，分别报告good/bad，不能只报一个净残值。

粗ST14保存两层：Arawτ=ΣE+rho nu wτ，Brawτ=ΣDnu wτ，α0=Arawτ/c、β0=Brawτ/c；

    coarse_exact_dr=4(α0+β0/4)Σd_r；
    coarse_harmonic=4(α0+β0/4)min(4,β0 H4)，H4=25/12。

核4Hcut<=coarse_exact_dr<=coarse_harmonic（前者由总费用界，后者由Σd上界）。不将粗帽之分项分别套到联合JG/JD。记录Σd、α0、β0、ST14/4Hcut及原source项，无来源费用遗失。

## 4. 裸cut时间交通及旧FA数据的边界

canonical裸terminal正交通Tcut=∫ΣE+×D rho[kv−ku]+Pi_vPi_u dt/t。分score段重建六源共同e，不丢分母源。此I1每来源只取0/4分数，正pair的δ=4；z=t^-4、e=Az+B，对完整score段pair积分为

    rho_v nu_v nu_u c_v c_u (z_lo−z_hi)/(e_lo e_hi)。

对全部positive pair、全部score段求和，精确核Tcut=Σr∫A_rB_r/e²及Tcut<=4Hcut；勿额外乘δ=4。本轮cut没有FA/Psi限制，原target这些门仍<=1。

**数据缺项必须明确**：R151 detail未保存逐source Q_v(x)，只有总q、p、rho/good及旧I/pair_terms，故无新核评价时不能一般重建canonical原FA端z_FA=Q_v/(B_FAδpc_v)。旧saved I只保存为diagnostic，与canonical Tcut的数值比/差可报告；**不得把旧profile I跨过舍入差强断言I<=canonical Tcut**。x0有R142 mp70逐核缓存，允许用其Q、p及本row冻结rho与canonical profile重算canonical FA完整I，精确核I_FA<=Tcut<=4Hcut。若确有既存逐Q外部缓存，额外读入须父先定位并冻结SHA，不能新扫核或反推Q。其余点canonical FA I标not_reconstructed_missing_Q；这不会妨碍STcut本身精确身份与初端/注入决策。

## 5. 聚合口径与输出

沿R151 m4/m8分别原weight与corrected_weight各算，推荐决策看corrected而保原对照。每个c版本/合法域分pre和post，保存以下同一row费用的A/B：

    A_X=Σdx_weight p X，B_X=Σdx_weight p hardmass/q X，

其中X为4H_initial、−4H_terminal、4H_G、4H_D、4Hcut、Tcut及两个ST14。完整资格mask固定R151，不新增/删除receiver选择器；2C前域还交其合法high域。明确Σp质量、dx体积、skip和invalid。分项比例从**聚合分项再求比**，不要平均逐row百分比。旧A_I/B_I仍沿R151值另列diagnostic，不与canonical证书混名。

各row exact Fraction计算可只给紧凑向外小分母有理区间及身份检查摘要，全部8376核点不拷贝大旧fields。共享profile/事件w缓存，角色mask可缓存，但rho权始终本row。保存x0及两个既存最高贡献row（按R151m4/m8最高weightedB或父固定选择）详细有理certificate：A/B左右态、a/b、Phi、d、JG/JD、连续段漂移、四项、Tcut与合法性；无新point选择搜索。

输出cut_probe.py/json/notes、input/archive/member/plan/script SHA、attempt账与all-exact计数。只stdlib Fraction，不需numpy/scipy/新核。若全8376精确计算过重，不能偷偷改成浮点证书；先通x0/固定控制并报告实际未完成规模，父可再限定。

## 6. 独立核验与停止

Sol不import producer：独立从canonical threshold排序/每事件变化核x0与预声明最高贡献点，检查完整six-source e、c资格与rho/E+/D固定；用两种写法核ST8、逐连续段Phi差与ST9、Tcut两score积分，核x0 canonicalFA（Q已缓存）。再独立重求和紧凑输出与原dx权的A/B分项、占比和skip。普通保存float转Fraction是冻结输入系数，不认证实际核/alpha误差。一般外价和维数阶仍未证，后处理只指导“初端vs注入”下一步决策。完成固定数据后停止。

### 父最后执行口径补充

父批准不补Q、不重扫核。全点可采用canonical公式的高精度/浮点数值一致性后处理（必须明确非全点有理证书），并在预声明控制点作精确Fraction证书；不用为全8376追求笨重全有理输出。全点关注Tcut<=4Hcut<=ST14的一致性与分项贡献，旧I仅并列；x0用已有Q同步canonicalFA精确比较。若实现全点Fraction合理可保留，但不是阻止交付的额外要求。此条优先于上文“all-exact计数”的默认方案，输出须分别报数值检查数与精确证书数。

## 7. 父新增同点候选log/Lorentz上帽对照

仍纯后处理同8376点。统一h左态、事件τ<θ<h，θ=h的注入与末端整体取消；本I1两事件均严格<h，故与原右态数值相同。每cut另记录

    logD=(1/4)log[(Bτ+c)/(Bh,left+c)]；
    lorentzG=∫0∞log[1+ζ_r{R>λ}/c]dλ，
    ζ_i=rho_i wh_i nu_i，R_i=wθ_i/wh_i（good且该cut窗内跨越）。

有限来源取不同R的升序0=R0<R1<...<Rk，精确层长乘log1p：Σ_j(Rj−Rj−1)log1p(Σ_{Ri>=Rj}ζ_i/c)。对照旧linearG=IG_r/c、linearD=ID_r/(4c)；数值核lorentzG<=linearG，核实际联合JG/JD与候选成本关系并照实报告失败/误差，不从有限相合推一般定理。log为超越数，全点及控制点分别标浮点/高精度数值一致，不能包装Fraction精确log证书。

按相同d_r加权、同c版本/合法域聚合A/B，输出旧线性与新log/Lorentz注入总费用及比例；保持初端、负末端不变，可另列候选总帽4(initial−terminal+lorentzG+logD)，但其一般可用性依父独审，数值不独自授予付款资格。仍以实际ST8四项分解作为“初端vs注入”主诊断。
