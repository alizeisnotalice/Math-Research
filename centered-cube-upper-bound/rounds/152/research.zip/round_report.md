# 第152轮：阈值注入的对数预算与保留比容量

## 目标与证明状态
一般中心立方体极大算子的 n^(1/2+o(1)) 一致弱型上界仍未闭合。固定原合法行、原终端互斥来源、整窗rho及c，改善第151轮实际切口注入预算；完整定义见research.tex及两篇证明附件。两项新一般BV估计、端点处理和外价常数经Sol独审；不是仅固定离散模型的结论。

坏侧联合注入由线性质量帽改为阈值消耗的对数帽，扣除自然衰减；原子保留更锐的tanh界。好侧由到达顺序与终端保留比得到Lorentz型对数尾积分帽，并给出原Q*容量的低保留比/超额分解。起末势、跨切口重数、实际p dx dβ、ν、ρ、α、Q*及维数/层/尺度/history合同均保留。详见research.tex、joint_cut_geometry.md、injection_sum.md、injection_audit.md。

这些改进不是新增无条件根阶付款。一般接收空间中起末势、对数阈值消耗及高保留比尾的共同预算尚未证明；不得把D_c、m_*或选择器当免费常数。有限必要模型不等同FULL实现。

## 数值范围、结论及失败修复
仅后处理R151的8376个既存点、8619个合法c版本，0新核评价、0新接收点。六个预定控制用Fraction精确重建并核验整数格向外区间；全点为浮点公式一致性，不是全点有理或真实接收求积证书。控制点超越对数用80位数值，不声称区间证明。

m8 corrected-overlap门后：c=eg时初端占正账42.4394%、bad注入57.5606%、good为0、终点返还占19.5668%；2C时分别38.1614%、61.8386%、0、21.4915%。log帽改善旧线性帽，但仍高于实际bad注入。当前接收样本不检验非零good机制；补充原固定seed的52个合成模型、849切口、1560精确事件身份，四项有限数值比较均无失败。粗细网格未认证收敛，不外推维数阶。

审核中修正d应固定于tau、terminalbad限制、linearG用R而非R-1、linearD不得含自然衰减，以及Decimal近似除法不能保证向外舍入。生成脚本曾被笔记误覆盖，恢复后重新执行。恢复作者此前读过核验源码，未复制其函数/结构；因此恢复后两脚本的一致不表述为盲独立实现，原产物的独立核算与恢复产物的回归核算分开记录。历史尝试次数无完整日志，记unknown。

主级复现A因封装器漏复制cut_numeric_plan.md而失败；修复后B完整退出0，生成JSON与冻结结果逐值一致，核验PASS，压力摘要除路径外一致。没有编译PDF。

## 复现
Python3；压力脚本使用mpmath 1.3.0（本机可用vendor路径在脚本中）。解压本归档后运行：

    python3 reproduce.py --rounds /绝对路径/centered-cube-upper-bound/rounds --receiver-detail /绝对路径/receiver_probe_points.json --destination /不存在的新目录

输入来源：139轮active_traffic_v2.json、142轮numeric_receiver.json、151轮research.zip及其可重建16.55MB receiver_probe_points.json。后者SHA256为6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9，可由151轮reproduce.py生成，不重复上传。输入和代码SHA写入cut_probe.json/manifest.json。

主级成功运行目录：/Users/zhengzhihao/Desktop/T/output/r152_parent_replay_20261015_b。verification.json收录于validation.json。依赖旧轮归档是明确复现依赖，非单ZIP完全独立实验。

## 下一步与协作
next_bottleneck.md仅为未独审候选：让切口系数随当前B变化，Ψ=AB/[(B+(r+1)c)(A+B+c)]，使无bad交通时势漂移也为零。下一轮先审完整BV身份和有符号联合注入，再检查真实外价与同点数值收益，不计入本轮已证结果。

本轮使用既有1 Astra high、2 Sol high、1 Sol medium、2 Luna medium的独立任务；下一轮遵循最多1 Astra、3 Sol、4 Luna的按需配置。没有可核验的实际扣额数据，不猜模型成本比例。工具适用条件见tool_conditions.md；N04仅用于后续误差/势差预算审查，不把技能名称当作根阶定理。
