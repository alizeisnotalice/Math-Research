# R152：原 bad 阈值注入的对数容量帽与接收费用

状态：JC2–JC6 给一个新的、一般原来源下的 bad 注入上界。直接估计本轮对 ST8 顺序无关总注入所统一约定的 bad 分项，保持 ST8 总量不变，不引入逆核矩。它把旧线性质量价改为对数价，并明确保留真实接收外费；尚未证明完整 H_cut 的根阶空间预算。按本轮有界任务停止于该可审检查点，不额外扩展空间分支。

## JC1. 对象与主命题

沿本轮 `prior_score_transport.md` 的原合法有限行、右态端点、固定 terminal 两组及整窗常数 0<c≤e_g。对切口 r，简记

\[
A=A_r,\quad B=B_r,\quad S=A+B+c,\quad
\Phi=A/S,\quad d_r=\frac{B_r(\tau)}{B_r(\tau)+(r+1)c}.
\]

原 BV 身份为

\[
dB_r=-K_r^B(t)\frac{dt}{t}-dI_r^D,
\qquad K_r^B\ge0,
\tag{JC1}
\]

所以 B_r 非增。terminal 来源未被删除，不能把 futurebad 或被删来源加入此恒等式。ν 任意相关，注入测度允许绝对连续、奇异连续及原子部分。

原 ST8 给出同刻 good 进入 a≥0、bad 离开 b≥0（b≤B₋）时的联合总注入。本轮统一约定以下联合分项，其和准确等于该总注入：

\[
\Delta J_r^G=\frac{(B_-+c)a}{S_-S_+},\qquad
\Delta J_r^D=\frac{A_-b}{S_-S_+},\qquad
S_+=S_-+a-b.
\tag{JC2}
\]

连续 bad 分项是 d(J_r^D)^cont=A_r/S_r²·d(I_r^D)^cont。以下 J_r^D 始终指这些**本轮联合分项**的和。R151 ST8 只登记联合总量，ST12 的顺序拆分用于上界；这里不将历史顺序上界认作相同分项，也不把本轮分项改成先加 good 或先移 bad 的另一笔费用。

欲证并已证明：

\[
\boxed{
J_r^D\le\frac14\left[
\log\frac{B_r(\tau)+c}{B_r(h)+c}
-\int_\tau^h\frac{K_r^B(t)}{B_r(t)+c}\frac{dt}{t}\right]
\le\frac14\log\frac{B_r(\tau)+c}{B_r(h)+c}.
}
\tag{JC3}
\]

方括号非负，它是由同一 B 的真实阈值离开产生的对数消耗；减去的 regular 衰减不是领取旧负项预算。

## JC2. 同刻联合原子的精确比较

设 u=B₋+c、v=B₋−b+c，则 u≥v>0。因为 a≥0，S₊≥A₋+v，直接从 JC2 得

\[
\Delta J_r^D\le\frac{A_-b}{(A_-+u)(A_-+v)}.
\]

这一步没有改注入顺序，也没有改变 JC2 约定的 JG 项。对 A≥0 的右侧求最大值，导数的符号由 uv−A² 决定；最大点 A=√(uv)。于是

\[
\boxed{
\Delta J_r^D\le\frac{b}{(\sqrt u+\sqrt v)^2}
=\frac{\sqrt u-\sqrt v}{\sqrt u+\sqrt v}
=\tanh\!\left(\frac14\log\frac uv\right)
\le\frac14\log\frac uv.
}
\tag{JC4}
\]

b=0 时两边为0；a 可以任意大，原分母只会增大。1/4 是局部 sharp 常数：a=0、A=B+c 且 b趋于0时，原增量与 log(u/v) 的比值趋于1/4。这仅是代数常数核验，不作为 FULL 原来源实现声明。

## JC3. 连续、奇异及原子统一累计

在非原子部分，

\[
\frac{A}{(A+B+c)^2}\le\frac1{4(B+c)},
\qquad
 d(J_r^D)^{cont}\le\frac14
 \frac{d(I_r^D)^{cont}}{B_r+c}.
\tag{JC5}
\]

由 JC1 对 log(B+c) 使用 BV 链式法则，得到准确身份

\[
\begin{aligned}
\log\frac{B_r(\tau)+c}{B_r(h)+c}
={}&\int_\tau^h\frac{K_r^B(t)}{B_r(t)+c}\frac{dt}{t}
+\int\frac{d(I_r^D)^{cont}}{B_r+c}\\
&+\sum_{s\in(\tau,h]}\log
\frac{B_r(s-)+c}{B_r(s)+c}.
\end{aligned}
\tag{JC6}
\]

B_r(s)=B_r(s−)−b_s；同刻 good 进入不改变 B。将 JC4–JC5 代入 JC6 即得 JC3。奇异连续注入已包括在 cont 中，没有只把 J 认作跳之和。右态初始化不收 θ=τ，收 θ=h，与原 ST5–ST9 保持一致。若与另一份估计联合并先准确消去 h 处终端原子，则本稿整窗改取 (τ,h)，JC3、JC6、JC7 中相应终端量统一使用 h−；不能仅删除注入而保留右态 B(h) 的同一身份。

更细且仍可直接使用的版本是保留 JC4 的 tanh 原子帽：连续部分仍按 JC5，原子不放大为其 log。JC3 选择 log 是为获得可加的整窗共同量，不声称大原子时它 sharp。

## JC4. 跨切口费用的显式改进

令上述联合分配的 bad 注入正分量

\[
\mathcal H_D:=\sum_{r=0}^{n-1}d_rJ_r^D\ge0,
\qquad \beta_0=\frac{\int_{D_0}w_\tau d\nu}{c}.
\]

定义每个切口的真实注入对数消耗

\[
\mathcal L_r^D:=
\log\frac{B_r(\tau)+c}{B_r(h)+c}
-\int_\tau^h\frac{K_r^B}{B_r+c}\frac{dt}{t}\ge0.
\]

由 JC3 和原 ST11 有

\[
\boxed{\mathcal H_D\le\frac14\sum_rd_r\mathcal L_r^D
\le\frac14\log(1+\beta_0)
        \min\{n,\beta_0H_n\}.}
\tag{JC7}
\]

证明只用 B_r(τ)/c≤β₀、B_r(h)≥0 与 Σd_r≤min(n,β₀H_n)。旧 ST12 和 B 的单调性给出的对应粗帽是
β₀ min(n,β₀H_n)/4；本轮把前面的 β₀ 改为 log(1+β₀)。这是整份 bad 注入的实际改进，不是把原费用换名。

不能把 JC7 当作完整 H_cut 的帽。准确分解仍是

\[
\mathcal H_{cut}=
\sum_rd_r\{\Phi_r(\tau)-\Phi_r(h)+J_r^G\}
+\mathcal H_D.
\tag{JC8}
\]

第一项可能有符号；若要独立正上界，可保留其完整结构或放大为 Σd_r(Φ_r(τ)+J_r^G)。本稿不再支付 good/起始费用，也不把 −Φ(h) 转作一笔已付负账。

## JC5. 原接收测度中的实际全价与尚欠空间控制

ST15 前因子为128Λ/3。对其中上述联合分配的正 bad 注入分量，本轮给准确外账

\[
\boxed{
\frac{128\Lambda}{3}\mathbb E\sum_{V,j}\int p\,\mathcal H_D\,dx\,d\beta_V(y)
\le\frac{32\Lambda}{3}\mathbb E\sum_{V,j}\int
p\sum_rd_r\mathcal L_r^D\,dx\,d\beta_V(y).
}
\tag{JC9}
\]

所有实际 j 选择、窗口、softness/尺度、terminal 两组和 history 沿 ST15 保留。β 没有改成 ν，三核与 α 没有独立选择，hard 帽已包含于128Λ/3中，不能再收一份或漏掉它。时间已经累计，不能另乘 log2。

JC9 右侧是尚待支付的真实空间对数容量平均；本轮没有证明它≤εX+Cε√n polylog(n)Wβ。具体区别是：注入不再要求对裸 bad 原质量作线性空间支付，而要求支付同一实际 B_r 的对数下降，且只计阈值注入，剔除了自然权重衰减。原共同 α 仍约束这些 D₀ 来源，但 JC4 为得到统一帽暂时最大化了实际 good 质量 A；若空间估计需要 α 或 good/bad 接收夹层收益，应回到 JC2/JC5 保留 A，不能称其已由 JC7 自动支付。

为量化现有工具能给什么，可合法选 c=e_g。terminal D₀ 整窗存活，逐源 w_τ≤(g/τ)^n w_g，且 g/τ≤2，因此

\[
\beta_0\le2^n,\qquad
\mathcal H_D\le\tfrac14n\log(1+2^n).
\tag{JC10}
\]

这一共同行帽确实允许此时才合并唯一 j。JT13 给出的完整粗价为

\[
\boxed{
\frac{128\Lambda}{3}\mathbb E\sum_{V,j}\int p\mathcal H_D\,dx\,d\beta
\le32\Lambda n\log(1+2^n)(2n+3)D_nW_\beta,
\quad D_n\le3\sqrt n.
}
\tag{JC11}
\]

单个 near-soft 带若直接用 CS10，其价为
(32Λ/3)n log(1+2ⁿ)·Env_n(D)Wβ，仍非根阶。这些粗价是为暴露剩余费用，绝不作为主目标完成；甚至没有理由要求独立 bad 注入放大项比原裸交通粗价更小，因为原 ST9 尚有端点抵消。

原 high 只给 e_g≥2Kq/p，不给 β₀ 的绝对常数帽；选择 c=2Kq/p 时不能照抄 JC10。FIRST 也不能把 p·log(B_r+c) 的空间平均变成免费三核质量。没有在 H_D 仍依实际 j/来源时提前删除唯一 j。

## JC6. 本轮结论边界

已证：保持原 ST8 总量的本轮联合 bad 分项的一次联合原子 sharp tanh 上帽、包含所有连续注入的整窗 log 帽、跨 cut 的 JC7、以及原外账 JC9。未证：共同 α 与相反接收检验能将 JC9、good 注入和起始/终端项合计支付为一般根阶多对数费用。没有登记一个虚构空间分支，没有再次扩大反例搜索。

所有截断固定原 ν 及 e、ρ、A、B、d_r 与资格，只截断非负积分；一般无限行按原既有合同处理，不截断 ν 后重算归一并声称单调。仅写本文件，不改他人或 Git，完成后停止。
