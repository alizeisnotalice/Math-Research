# R152 Sol 独立审计：good tail 注入与 bad 对数预算

状态：先独立推导两命题；尚未读取本轮作者证明。仅拥有本文件，不改他人文件、不 Git、不新增数值。以下结论是原固定行上的注入预算简化，不是一般真实接收外价闭合。

## 1. 固定原量与同刻注入分项

沿R151原有限合法行，terminal E_*⊂E₊与D₀固定、互斥、整窗存活，ρ∈[0,1]固定，0<c≤e_g≤e_t固定。A、B、S=A+B+c、Φ=A/S及阈值注入测度均取同一原ν，不重新归一。连续注入（含绝对连续与奇异连续部分）为
\[
 dJ_G^c=\frac{B+c}{S^2}dI_G^c,\qquad
 dJ_D^c=\frac{A}{S^2}dI_D^c.
\]
同刻good进入a≥0、bad离开b≥0，0≤b≤B_-，记
\(S_-=A_-+B_-+c,\ S_+=S_-+a-b\)。
本轮联合分项为
\[
 \Delta J_G=\frac{(B_-+c)a}{S_-S_+},\qquad
 \Delta J_D=\frac{A_-b}{S_-S_+}.
\tag{IA1}
\]
二者非负、总和等于真实ΔΦ。R151 ST8登记的是联合总和，ST12仅使用“先good后bad”的顺序拆分作上界。本轮IA1统一指定原分子分项；不能将此分项与顺序拆分中的一部分混加，也不能宣称两种拆分逐项相同。连续部分相同。已针对本轮prior_score_transport.md副本实际核对该历史范围。

一般ν下阈值推前可含连续、奇异连续和原子，以下所有J均包括完整测度；只算跳变之和不成立。同一来源多个坐标同阈值时，每个被跨过的切口各收费一次，保留跨cut重数。

## 2. 命题一：bad总注入对数界独立成立

固定单次bad移除b，令x=B_-+c、y=B_--b+c>0。混合good a只增大IA1中JD分母，故
\[
 \Delta J_D\le\frac{A_-b}{(A_-+x)(A_-+y)}.
\]
对A≥0精确优化，最大点为A=√(xy)，最大值为
\[
 \frac{\sqrt x-\sqrt y}{\sqrt x+\sqrt y}
 =\tanh\!\left(\frac14\log\frac{x}{y}\right)
 \le\frac14\log\frac{x}{y}.
\tag{IA2}
\]
b=0时两端均零；c>0保证任意b≤B_-时y>0，不存在log零分母。

连续部分
\[
 \frac{A}{(A+B+c)^2}\le\frac1{4(B+c)},
\]
故\(dJ_D^c\le dI_D^c/[4(B+c)]\)。
B的总变化为\(-dB=K_B\,dt/t+dI_D\)，本身非增。连续漂移造成的B下降只会增加可用log预算；每个原子由IA2支付。链式求和得到
\[
 \boxed{J_D\le\frac14\log\frac{B_\tau+c}{B_{\mathrm{end}}+c}.}
\tag{IA3}
\]
端点必须与原BV身份相同。若采用τ右态、h左态，则J仅含τ<θ<h，B_end=B(h-)。若终点采用右态并收h原子，则使用B(h+)及对应Φ_h，整个h注入与终点势一起保留。不能只去掉h的good项而保留原右态总势。

这是确实的来源容量简化：原先bad注入逐阈值线性质量上帽，替换为由实际单调B端点支付的log比。没有使用e_t删除跳来制造额外预算，也未要求A单调。IA3不控制外dx、β、j或soft费用；Bτ/c也没有一般上帽。

## 3. 命题二：good terminal-tail界独立成立

以下统一采用τ右态初始化、h左态结束，所有窗内穿越严格为τ<θ_r(v)<h，完全消除h阈值的整项注入并同步以Φ(h-)结束。τ端已跨切口的来源在初始势中，不重复收注入。

固定切口r，令
\[
 d\zeta(v)=\rho_vw_h(v)1_{\{\tau<\theta_r(v)<h\}}d\nu(v),\qquad
 R(v)=w_{\theta_r(v)}(v)/w_h(v)\ge1.
\]
R只需在ζ的有效支撑上定义。w_h=0的来源在正τ窗口内w_θ也为零，故无该注入；先按零质量拆去，不计算0/0。定义到达累计
\[
 Z(t)=\zeta\{\theta_r\le t\}.
\]
此前已到达来源在时刻t的权重w_t≥w_h，故连续时刻A(t)≥Z(t)，每个原子前A_-≥Z_-。

连续注入有\(dJ_G^c\le dI_G^c/(A+c)\)。在来源侧仅限制到非原子到达时刻后，其积分由\(\int R(v)/(c+Z(\theta_r(v)))\,d\zeta(v)\)控制；这里的连续/原子划分针对到达时间的推前，不能误按来源空间的原子性划分。
单次good原子a=∫block R dζ，令δ=ζ(block)，R≥1保证a≥δ。由IA1，
\[
 \Delta J_G\le\frac a{A_-+a+c}
 \le\frac a{c+Z_-+\delta}
 =\int_{\mathrm{block}}\frac{R}{c+Z_{\mathrm{post}}}\,d\zeta.
\tag{IA4}
\]
第一步只用S_-≥B_-+c及S_+≥A_-+a+c；即使同刻有bad移除仍成立。该证明不需要把原来源原子真的拆分成新来源，右态Stieltjes上帽已经处理全部原子。

因此
\[
 J_G\le\int\frac{R(v)}{c+Z(\theta_r(v))}\,d\zeta(v).
\]
对每个λ≥0，取E_λ={R>λ}及其到达累计Z_λ。Z≥Z_λ，且对一般含原子单调累计
\[
 \int\frac{dZ_\lambda}{c+Z_\lambda}
 \le\log(1+Z_\lambda(\mathrm{end})/c).
\]
这里原子δ/(c+Z_post)≤log((c+Z_post)/(c+Z_pre))；连续及奇异连续部分由链式法则给等号。非负layercake和Tonelli遂得
\[
 \boxed{J_G\le
 \mathcal L_c(\zeta,R):=
 \int_0^\infty\log\!\left(1+\frac{\zeta\{R>\lambda\}}c\right)d\lambda.}
\tag{IA5}
\]
一般ν、任意相关坐标与同刻阈值均适用。没有以坐标独立性或免费可测见证作为假设。

基础一致性检查：
\[
 \mathcal L_c(\zeta,R)\le c^{-1}\int R\,d\zeta=I_G/c.
\tag{IA6}
\]
若R≤R₀<∞在ζ几乎处处成立，则
\[
 \mathcal L_c(\zeta,R)\le R_0\log(1+\zeta(\mathbb R^n)/c).
\tag{IA7}
\]
R₀上帽必须实际给出；不能为每个来源分别取上帽后把sup费用删除。原τ>0、h有限的几何给粗R≤(h/τ)^n，但该因子未必有可用维数价格。

ζ=0时原注入I_G=0、JG=0、tail积分零；R不需定义。有限原行上ζ质量≤∫E_*ρw_hdν，∫R dζ≤∫E_*ρwτdν<∞，IA6保证有限。若放宽至扩展无穷量，IA5至多给扩展上界；不能从∞或未定义比值登记有限费用。积分截断保持原ν、A、B、c、ρ和阈值不变，不截断ν重算门。

## 4. 跨cut单log与真实未付费用

沿原固定d_r≥0，设D=Σ_rd_r。D=0时所有相关加权项为零。D>0时Jensen给
\[
 \sum_rd_rJ_{G,r}
 \le D\int_0^\infty
 \log\!\left(1+
 \frac{\sum_rd_r\,\zeta_r\{R_r>\lambda\}}{cD}\right)d\lambda.
\tag{IA8}
\]
权重dr/D在该行固定，与λ无关。该式是对加权log和的上界，不是等价身份；weighted tail仍保留同一来源跨过不同cut的重数，不能把它识别成一份原μ概率。bad项则可用Σdr/4乘各自准确B端点log，若再合并须另写合法Jensen或单调放松。

good初始势仍在原总费用中；IA5只处理严格窗内good注入。终点Φ(h-)也仍在精确输运身份中。若为正上界丢弃其负号，必须明说是放松，不能同时领取h原子抵消或当成新的来源退款。

取原C=Kq/p、c=2C时，
\[
 \frac{\zeta_r(\mathbb R^n)}C
 =\int_{E_*}\frac{\rho_v1_{\{\tau<\theta_r<h\}}}{r_h(v)}\,d\mu(v),
 \qquad
 \frac{I^G_r}C
 =\int_{E_*}\frac{\rho_v1_{\{\tau<\theta_r<h\}}}{r_{\theta_r(v)}(v)}\,d\mu(v).
\tag{IA9}
\]
所以μ次概率并不直接控制terminal-tail质量或穿越质量：还有实际逆r、跨cut权重、实际接收x依赖。bad log端点亦依同行几何。必须支付原EΣV,j∫p dx dβ及soft/尺度/history合同，不能由IA3或IA8本身宣称根阶外价。

当前先审接受两命题的上述准确形式。等待作者文件后，只作对应证明与范围一致性后审，不扩大历史或数值范围。


## 5. 追加独立审查：terminal g参照与可认证低保留比项

参照时间可取任意原固定T∈[h,g]。将第3节ζ中的w_h换为w_T、R换为wθ/w_T，因θ<t≤h≤T仍有w_t≥w_T，故IA4–IA8同样成立。T不能依来源阈值单独重选后省掉相应tail费用。

针对T=g，已实际核对本轮prior_geometry_contract.md第53行：原terminal good门是pw_g≤KQ*，所以E_*上r_g≥1。该门不能换成r_h≥1。令原m=μ(E₊)，则
\[
 d\zeta_r^g=\frac{C\rho_v}{r_g(v)}
 1_{\{\tau<\theta_r(v)<h\}}d\mu(v),\qquad
 M_r:=\zeta_r^g(\mathbb R^n)\le Cm.
\tag{IA10}
\]
即使E_*更小，也保持原m而不免费重归一。

对任何共同固定R₀≥1，将tail log积分在R₀处切开，低段用tail≤M，高段用log(1+x)≤x，得到
\[
 \mathcal L_c(\zeta,R)
 \le R_0\log(1+M/c)
  +c^{-1}\int(R-R_0)_+d\zeta.
\tag{IA11}
\]
原R₀一般不是真实全体R的上帽；第二项不能删除。D=Σd_r>0时对加权tail先用IA8，再以Σdr M_r≤DCm，得到
\[
 \sum_rd_rJ_{G,r}
 \le DR_0\log(1+Cm/c)
 +\frac Cc\int_{E_*}\rho_v
  \sum_{r:\tau<\theta_r<h}d_r
  \left(\frac1{r_{\theta_r}(v)}-\frac{R_0}{r_g(v)}\right)_+d\mu(v).
\tag{IA12}
\]
这里R_r=r_g/rθ，恒等回代中正部方向准确。D=0时直接取零，不作除法。c=e_g≥2C时，低段进一步有
\[
 DR_0\log(1+Cm/c)\le DR_0\log(1+m/2).
\tag{IA13}
\]
尾项仍保留原实际C/c，若再以1/2放松须明确。

IA13是有内容的原来源容量简化：terminal good把每cut终端ζ质量接上原μ的质量m，从而低保留比部分取得可认证帽。它未控制D的维数阶、R₀截尾尾项或实际接收平均，不构成一般外价付款。若对完整RHS作可测的逐行R₀选择，必须保留该选择后的整个RHS；不得分别优化低项和尾项后拼合不同R₀，亦不得由“任意R₀”声称其并集免费。


## 6. 两作者文件实际后审

已在独立推导后实际通读 joint_cut_geometry.md 的JC1–JC11与 injection_sum.md 的IS1–IS21，未以作者摘要替代审核。

### 6.1 bad文件

JC3保留的更强版本为
\[
 J_D\le\frac14\left[
 \log\frac{B_\tau+c}{B_h+c}
 -\int_\tau^h\frac{K_B}{B+c}\frac{dt}{t}\right].
\tag{IA14}
\]
已独立核其括号由非负阈值消耗构成：完整log下降减去regular权重衰减，剩余恰含连续阈值log链式量与原子log差。与IA2–IA3一致；不是重复领取原signed负项。独立右态版本包括h注入，联合使用h左态时整体换端点，不能只改good一边。

JC7用β₀=∫D₀wτdν/c给加权bad注入帽
\(\frac14\log(1+\beta_0)\min(n,\beta_0H_n)\)，与原线性质量粗帽相比确有log替换。JC9系数为32Λ/3乘原加权log阈值消耗，来自R151的128Λ/3再乘1/4，正确。

JC10–JC11限c=e_g使用原合法窗g/τ≤2，才有β₀≤2ⁿ；不能照抄到c=2C。其JT13粗价32Λnlog(1+2ⁿ)(2n+3)D_nWβ系数核算正确，但维数费用远大于主目标。该段只暴露尚欠费用，不登记根阶预算。

### 6.2 good文件

IS6允许合法来源/阈值事件0≤χ_r≤1，仍保留全原A/B与同刻原子共同系数。逐原子选中aχ的费用与补χ费用准确相加。作者明确不从pair Ψ/FA直接推导χ，也不删未选注入，量词正确。

IS7–IS9将时间推前的连续/奇异连续和同刻原子分别处理，对每λ由Fλ≤A提供完整log链式上界，不依赖原子真的重分源。IS13的Jensen单log上帽虽比逐cut精确帽松，但仍不大于原加权线性I_G/c；IS17–18进一步粗化不保证保持此比较，正文已准确区分。

IS14保留有序阈值前缀重数：对固定来源R_{r,T}随r非增，严格窗内满足R>λ的cut是从右态kτ开始的前缀，χ可再筛去部分。谐和差H_K−H_{kτ}由逐cut dr≤β₀/(r+1)给出，不需要dr单调。多坐标同刻跨越仍按原cut重数计入。

IS15–18与本审计IA10–IA13一致，特别尾正部为(1/rθ−R₀/r_g)_+，方向正确。低项使用r_g≥1，未改成r_h≥1，m保持原值。

IS20在χ=1时以h左态同时处理两种注入、Φ终点与边界，故E_log≥原H_cut≥0；signed边界未被当作独立正费用。IS21完整外系数128Λ/3、β、实际接收x、j与hard/history保持，正确。该上界尚待一般真实空间付款。

两稿当前公式未发现须修正问题。已请作者只更正一处历史措辞：R151 ST8仅登记联合注入总量，ST12的顺序拆分仅作上界；本轮可统一约定IA1原分子分项，但不应称历史已登记独立JG/JD。待最终冻结稿后绑定。


## 7. 父稿对应审查、修复记录与最终三稿绑定

已实际通读research.tex，核对其原分子联合分项、bad tanh与log下降减漂移、good完整tail log、跨cut Jensen、T∈[h,g]、T=g的原r_g容量回代、截断正部尾项及128Λ/3/32Λ/3外费，与上列独立证明及两作者稿一致。

父稿使用m_*=μ(E_*)，合法且比原m=μ(E₊)上帽更紧：IA10可直接以μ(E_*)界定每cut质量。这只是本轮容量上界中的新记号，不改变任何旧门使用的原m。

实际发现并已关闭的问题：

1. 两作者初稿历史措辞把R151 ST8联合总量表述成历史已独立登记的JG/JD。已要求统一改成本轮对同一总量约定原分子分项。joint最终第24/33行及injection最终第23行均已实际复读；本审计第1节也按本轮prior副本修正。
2. 父稿good段ζ定义原先少写E_*的来源限制。若不补，ζ到达≤A以及r_g≥1的容量步骤不成立。已要求加入1_{\{v∈E_*,τ<θ<h\}}；最终第38行已实际复读确认修复。
3. 父稿切到h左态后，已要求明确bad项也同步去掉h原子、B终点改h−。最终第36行已实际复读；joint独立右态式与组合左态式的转换也已在其第96行明确。

最终绑定SHA256：

- joint_cut_geometry.md：\(\texttt{58cbc584766d30d6c5ddc7c5a28b3dd9a4c1310e51168db15a522e182df0a91b}\)。
- injection_sum.md：\(\texttt{af79ccd6d46d9f68cc4e85951050abdbcabd7ab24a8dfed639a988e364c25a69}\)。
- research.tex：\(\texttt{87b107ff86c7f1a770a40aee813e1c6738b6a7ad52cb187e343058f4c6f09452}\)。

三稿数学证明及范围一致性审查通过。可登记的结果是一般原来源下bad对数注入帽、good terminal-retention log-tail帽及合法的原三核低保留比/高尾分解。一般真实接收预算、截断逆r超额的空间付款和完整主目标仍未证明。没有新增实验、PDF编译或Git操作；只修改本文件，指定审查结束。




