# R152 cut-potential 后处理实现说明

实现冻结合同见同目录 `cut_numeric_plan.md`。本轮只读取 R151 保存的 8376 个接收点与 R136/R142 历史输入；没有新质量模型、receiver 点或 kernel 评价。旧完整点明细在 JSON 记录的外部路径，仓库内只放紧凑统计和预声明控制证书，逐点统计可用脚本从固定 SHA 输入确定性重建。

`cut_probe.py` 从 R136 I1 六来源阈值重建连续 canonical 权重、score 右态和 `eg=Σνw(g)`，固定每个 R151 点的 rho/good/p/q/hardmass/FA 门标签。逐点计算四个 cut 的 `A_r,B_r,Phi_r,d_r`、同刻事件联合 `JG/JD`、连续端点势差、精确两score `Tcut`、4Hcut 和两层 ST14 粗帽。窗口端点采用方案指定的右态；初端不收费。`Tcut` 只累计 good rho-positive 到 terminal-bad 的 pair，不乘额外 δ=4。

全点以 binary64 按 canonical 公式重算，明确是有限数值诊断，不是误差认证。控制点采用 `Fraction` 逐阈值、事件和两score原函数精确计算；JSON将有理值写成经整数除法严格向外舍入的50位十进制区间。控制点为 x0（已有 R142 mp70 Q/p）、m4与m8各自 R151 `max_weighted_B_contribution` 位置，并分别计算合法 eg 与 2C。x0 的 canonical FA 使用缓存的逐来源 Q 和 B_FA，精确切分四次幂截点；三个FA pair合计得到 I_FA，验证 `I_FA≤Tcut≤4Hcut`。其他点没有逐来源 Q，故只报告无FA截断的 canonical `Tcut`，不声称重建它们的 canonical FA。

所有逐点费用由同刻ST8联合分子分成good/bad两部分，未按顺序注入。新增的 `logD` 与 Lorentz `G` 对照按冻结§7公式计算：全点 binary64，控制点 80位 Decimal 数值；它们不是有理超越数证书，也不单凭这批数值建立一般付款。`linearG` 按 `ΣζR/c`，`linearD` 仅计bad事件离开项 `Σb_event/(4c)`；`logD` 与事件线性项不预设大小次序。逐点行因可从固定输入重建而未重复存储。

结果摘要（corrected overlap 权重、eg 版本、pre 子域）：m4 的 A 口径 `4Hcut=0.2126353`、`Tcut=0.00571621`、`ST14_exact=5.06576`；m8 为 `0.1186382`、`0.00337726`、`2.80671`。B 口径对应 `0.0533494 / 0.00145475 / 2.12315` 与 `0.0434237 / 0.00125600 / 1.47202`。m4/m8 正账的 good 注入为零；bad 注入分别占 gross 约58.1%与57.1%，初端约41.9%与42.9%，负末端返还约19.0%与19.7%。因此这个有限模型的 cut 帽主要受 bad 侧阈值注入影响。2C 只在 saved high 且精确 `2q/p≤eg` 的点汇总。所有值是有限离散统计，不能外推为全接收积分或 FULL 定理。

R136 canonical 与保存的 wg/score-segment c 仅有约 `10^-121` 的最大绝对差，作为输入舍入诊断单列，未混入阈值或模型。初始射程里 unused 的旧 saved I 只作并列诊断，不用它替代 canonical FA。

执行账：历史终端日志没有完整保留，精确 producer 尝试次数、失败数与完成数均记为 unknown（null），不凭记忆补记。已确认的失败类型包括归档路径、变量遮蔽/汇总初始化、把不在中点网格的 x0 当作网格行、ST8 分母、ST9 权重与 Python 大整数序列化；这些实现问题已修正。最终采用当前完整输出（0新kernel，8376既存点、8619个合法c版本、6个精确控制）；原独立 verifier 曾核验旧产物；恢复后的脚本与 JSON 已经Sol参考计算核验及主级新目录复现通过；恢复作者此前读过核验源码，不主张恢复后盲独立。之前中间JSON已被最终摘要覆盖。

当前文件哈希：`cut_probe.py` SHA256 `ff2d099b622b2f50332f39108d264df2cf6b8f42a85a0e94b8f5cab020e90714`；`cut_probe.json` SHA256 `b24358e26103860d8125ba93d6709720fd6609d8836db8e2b719ae901763b4ff`。JSON内绑定producer及历史输入/方案SHA；结果为全点数值一致性检查，不是全点有理证书。
