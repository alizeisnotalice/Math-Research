# R152 cut分项后处理：独立核验

数学本体通过复核，恢复后的可执行producer与输出已实际回归检查通过；最终SHA如下冻结。全部结果限canonical冻结必要模型的已存receiver点，不认证FULL、实际核误差或真实dx求积误差。

## 主要决策结果

以m8 corrected-overlap权、必要receiver门后域为主，精确ST8的正账gross由“初端+good注入+bad注入”构成：

| c | 初端占gross | good注入 | bad注入 | 末端返还/gross |
|---|---:|---:|---:|---:|
| canonical eg | 42.4394% | 0 | 57.5606% | 19.5668% |
| 2Kq/p（合法high域） | 38.1614% | 0 | 61.8386% | 21.4915% |

bad阈值注入略占主，不能把这个样本简化为初始势单独主导。good注入在当前8376点都是0，因此本数据没有实质检验good Lorentz机制。域/网格仍沿R151，m4与m8差异明显，不能由此推一般接收积分或维数阶。

门后m8的A口径数值：

| c | Tcut | 4Hcut（实际ST8） | ST14 Σd粗帽 | 用log/L替代注入的候选帽 |
|---|---:|---:|---:|---:|
| eg | .0003992734 | .0142296185 | .1256324858 | .0309547629 |
| 2Kq/p | .0003992734 | .0173271319 | .1769362855 | .0366323766 |

log/L注入候选改善旧线性注入帽，但比精确ST8实际费用仍松。eg下bad log成本约为旧linearD的38.6%，为实际JD的2.64倍；2C下约为旧linearD的33.5%，为实际JD的2.41倍。因此下一步仍须保留与对方cut的耦合，不能把更小的log形式误称已付或精确费用。一般新候选证明由独立理论审查负责，有限数值相合不授予一般付款。

上述Tcut为canonical裸terminal交通；全点旧saved I只并列诊断，未借其接近Tcut跨过profile舍入差强证原FA上界。x0具有已有逐source Q缓存，另作真正canonical FA精确计算。

## 独立核证方法

`cut_verify.py`不import producer、不新求核或receiver点：

- 从R151归档compact及固定SHA外部detail恢复原nu/rho/good/p/q/hardmass和两套dx权；由R136 thresholds重新定义同一个连续canonical w、右态score与canonical eg。
- 对x0、m4/m8各自原最高weighted-B贡献点的两个合法c，共6组，独立Fraction重建全部4cut、共同事件、d_tau、连续Phi差及ST8联合JG/JD。严格检查所有输出有理区间端点包住自己计算的精确值，不信digits字段。ST8同刻先后无关，d始终固定在tau。
- 从六源完整e独立计算bad-only Tcut的两score原函数，精确检查Tcut<=4Hcut<=ST14 Σd<=ST14 harmonic；没有good低score端混入D，也没有额外乘delta=4。
- 从旧detail独立重建全部8376点的binary64 cut费用、2C合法性及32组A/B聚合，未读取producer省略的逐点rows；复核gross/net占比、末端负号、p/hardmass/q口径及原weight/corrected权。全点仍是数值一致性，不宣称Fraction认证所有点。
- log/L候选在6个控制用自己80位Decimal按不同R层排序重新计算，核对生产结果至约65位；超越log没有包装为有理精确证书。linearG确为ΣζR/c，linearD仅实际bad阈值离开b_event/(4c)，不将连续衰减混入。
- 精确比较canonical与原保存profile，最大wg绝对差约8.16e-121、score c差约6.51e-121，记录了模型舍入区别，未当作额外阈值跳。

x0使用R142已有mp70逐核缓存精确重建Q=(K1+K2+J)/3，canonical正FA积分约.08733319051928236；它与Tcut在显示位一致，并精确满足IFA<=Tcut。4Hcut分别约3.1698002924（eg）、3.3942383508（2C）；费用随c不预设单调。

## 修复与执行来源

审核阻断并要求修正：exact事件权误用随时刻变化的d而非d_tau；Tcut缺bad端限制；linearG误用R−1；linearD误含连续B衰减；Decimal近似除法不能普遍证明向外舍入；后者已要求用精确整数divmod格点，并由verifier对端点包含独立检查。历史尝试次数未完整留存，报告采用unknown及确认的失败类型，不按记忆填精确次数。

这些修复不代表新的数学实验；全轮新核评价0、新receiver点0，输入仍R151两档8376点。canonical rho/good是冻结系数，不宣称重新从alpha生成了FULL。

## 源码覆盖异常、恢复及独立性边界（最终检查点）

producer源码在整理执行账/notes时被误覆盖为3705字节Markdown说明。我实际读文件发现并阻断冻结；当时JSON数学结果仍完整，独立cut_verify.py未损坏。随后Luna按方案摘要从头重建可执行producer，AST/py_compile通过并运行生成新输出。原损坏前产物已经由我的另写程序独立推导、Fraction控制及全点数值重建检查通过；这个历史独立核验事实保留。

恢复实现作者准确披露：未复制verifier函数/代码结构，但此前只读检查过verifier，恢复也以已核方案摘要为依据。因此**不宣称恢复后的producer与verifier代码盲独立**。恢复产物的验收是对预先固定数学结果的回归、与既有独立参考计算一致，以及ST8/ST9等精确身份检查；不能把它改写成两套完全隔离代码互相认证。恢复不是对被覆盖原源码的字节级还原。

我未因恢复改写verifier数学方法。对恢复输出实际再次执行cut_verify.py，exit0/PASS：6个Fraction控制（含实际x0 canonicalFA）、8376个独立重建数值行、32组A/B汇总、log80控制与所有gross/net占比通过。父随后在干净wrapper replay B实际重跑producer与verifier成功，producer JSON逐值一致；wrapper A因漏复制cut_numeric_plan.md失败，属于复现材料缺项，修复后B通过。父同时报告其52压力模型849cut/1560事件检查一致；该压力检查属于父单独核验，不冒记为我新增的模型实验。

历史精确调用次数无法据完整日志还原，最终执行账保持unknown/null，另列确认失败类型；不因恢复而倒改失败次数。无新增receiver/kernel/质量网格，所有费用保留原六源及原域。

最终冻结SHA256：

- cut_probe.py：`ff2d099b622b2f50332f39108d264df2cf6b8f42a85a0e94b8f5cab020e90714`。
- cut_probe.json：`b24358e26103860d8125ba93d6709720fd6609d8836db8e2b719ae901763b4ff`。
- cut_verify.py：`a614f0b6c7523b4e0855f21c695375ba3b3230de8d60b417f8b886ca9ccadf9d`。
- R151外部detail：`6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9`。

复现命令（所有参数显式可搬到新输入目录）：

    python3 cut_probe.py --r151-zip R151_RESEARCH_ZIP --detail R151_DETAIL_JSON --r136 R136_SOURCE_JSON --r142 R142_RECEIVER_JSON --out cut_probe.json
    python3 cut_verify.py --cut-json cut_probe.json --r151-zip R151_RESEARCH_ZIP --detail R151_DETAIL_JSON --r136 R136_SOURCE_JSON --r142 R142_RECEIVER_JSON

两程序均只用Python标准库；本次Sol实际解释器为 `/opt/homebrew/opt/python@3.14/bin/python3.14`，PYTHONPATH未设置。producer需cut_numeric_plan.md同目录绑定方案SHA。日志里Fraction精确值由整数格向外包围；log控制仍仅80位数值一致。全部工作现保存为可审检查点并停止，不扩展。
