#!/usr/bin/env python3
"""Independent R152 Fraction control identities and all saved aggregate sums.
No producer import, no kernel evaluation. All-point values remain diagnostics.
"""
from fractions import Fraction as F
from pathlib import Path
from decimal import Decimal,localcontext
import argparse,json,zipfile,hashlib,math,sys
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent

def f(x):return F(str(x))
def sha(b):return hashlib.sha256(b).hexdigest()
def enclosed(z,value):
    if isinstance(z,dict):assert f(z['lo'])<=value<=f(z['hi'])
    else:assert f(z)==value
def close(a,b):assert math.isclose(float(a),float(b),rel_tol=2e-11,abs_tol=2e-13),(a,b)
def weight(th,t):return math.prod((min(F(1),a/t) for a in th),start=F(1))

def certificate(th,nu,rho,good,tau,h,c):
    events=sorted({z for tt in th for z in tt if tau<z<h});times=[tau,*events,h]
    def state(t,right):
        w=[weight(tt,t) for tt in th];k=[sum(a<=t if right else a<t for a in tt) for tt in th]
        A=[sum((rho[i]*nu[i]*w[i] for i in range(6) if good[i] and rho[i]>0 and k[i]>r),F(0)) for r in range(4)]
        B=[sum((nu[i]*w[i] for i in range(6) if not good[i] and k[i]<=r),F(0)) for r in range(4)]
        return A,B,[A[r]/(A[r]+B[r]+c) for r in range(4)]
    a0,b0,p0=state(tau,True);ah,bh,ph=state(h,False);d=[b0[r]/(b0[r]+(r+1)*c) for r in range(4)]
    initial=sum(d[r]*p0[r] for r in range(4));terminal=-sum(d[r]*ph[r] for r in range(4));G=D=drift=T=F(0);IG=[F(0)]*4;ID=[F(0)]*4
    for t in events:
        am,bm,pm=state(t,False);ap,bp,pp=state(t,True)
        for r in range(4):
            a=ap[r]-am[r];b=bm[r]-bp[r];assert a>=0 and 0<=b<=bm[r];den=(am[r]+bm[r]+c)*(ap[r]+bp[r]+c)
            jg=(bm[r]+c)*a/den;jd=am[r]*b/den;assert jg+jd==pp[r]-pm[r]
            G+=d[r]*jg;D+=d[r]*jd;IG[r]+=a;ID[r]+=b
    for l,rr in zip(times,times[1:]):
        aa,bb,pl=state(l,True);aa,bb,pr=state(rr,False)
        for r in range(4):assert pl[r]>=pr[r];drift+=d[r]*(pl[r]-pr[r])
        mid=(l+rr)/2;k=[sum(a<mid for a in tt) for tt in th];cs=[math.prod((a for a in tt if a<mid),start=F(1)) for tt in th];assert set(k)<={0,4}
        A=sum(nu[i]*cs[i] for i in range(6) if k[i]==4);B=sum(nu[i] for i in range(6) if k[i]==0);zl=l**-4;zr=rr**-4
        for v in range(6):
            for u in range(6):
                if good[v] and rho[v]>0 and not good[u] and k[v]-k[u]==4:T+=rho[v]*nu[v]*nu[u]*cs[v]*cs[u]*(zl-zr)/((A*zl+B)*(A*zr+B))
    H=initial+terminal+G+D;assert H==drift and 0<=T<=4*H
    rawA=sum(nu[i]*rho[i]*weight(th[i],tau) for i in range(6) if good[i] and rho[i]>0);rawB=sum(nu[i]*weight(th[i],tau) for i in range(6) if not good[i]);alpha=rawA/c;beta=rawB/c;sd=sum(d);coarse=4*(alpha+beta/4)*sd;harm=4*(alpha+beta/4)*min(F(4),beta*F(25,12));assert 4*H<=coarse<=harm
    out=dict(initial=initial,negative_terminal=terminal,HG=G,HD=D,Hcut=H,Tcut=T,coarse_exact_dr=coarse,coarse_harmonic=harm,alpha0=alpha,beta0=beta,sum_d=sd,rawA_tau=rawA,rawB_tau=rawB);out['4H']=4*H
    # Log/Lorentz are high-precision numerical values, not rational certificates.
    with localcontext() as ctx:
        ctx.prec=80
        dec=lambda z:Decimal(z.numerator)/z.denominator
        logD=[];Lor=[]
        for r in range(4):
            logD.append((dec((b0[r]+c)/(bh[r]+c))).ln()/4)
            vals=[]
            for i in range(6):
                if good[i] and rho[i]>0:
                    ts=sorted(th[i])[r]
                    if tau<ts<h:
                        wh=weight(th[i],h);vals.append((weight(th[i],ts)/wh,rho[i]*nu[i]*wh))
            prev=F(0);ll=Decimal(0)
            for R in sorted({z[0] for z in vals}):
                tail=sum((zeta for ratio,zeta in vals if ratio>=R),F(0));ll+=dec(R-prev)*(1+dec(tail/c)).ln();prev=R
            Lor.append(ll)
            assert ll<=dec(IG[r]/c)+Decimal('1e-70')
        nonlinear=dict(logD_weighted=sum(dec(d[r])*logD[r] for r in range(4)),lorentzG_weighted=sum(dec(d[r])*Lor[r] for r in range(4)),linearG_weighted=sum(dec(d[r]*IG[r]/c) for r in range(4)),linearD_weighted=sum(dec(d[r]*ID[r]/(4*c)) for r in range(4)))
    return out,nonlinear

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--cut-json',default=str(ROOT/'cut_probe.json'));ap.add_argument('--detail',default='/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json');ap.add_argument('--r151-zip',default=str(ROOT.parents[1]/'151/research.zip'));ap.add_argument('--r142',default='/Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015/centered_cube_round142_20261015/numeric_receiver.json');ap.add_argument('--r136',default='/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/active_traffic_v2.json');args=ap.parse_args()
    jb=Path(args.cut_json).read_bytes();j=json.loads(jb);db=Path(args.detail).read_bytes();assert sha(db)=='6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9';dd=json.loads(db)['point_records']
    with zipfile.ZipFile(args.r151_zip) as z:cb=z.read('receiver_probe.json')
    assert sha(cb)=='6bfc604946efcb7461b354e1d1f5347319b519548e1c4448a35643b5f911b731';old=json.loads(cb);sb=Path(args.r136).read_bytes();assert sha(sb)=='1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de';src=next(c for c in json.loads(sb)['cases'] if c['id']=='I1');th=[[f(z) for z in a['thresholds']] for a in src['atoms']];nu=list(map(f,old['constants']['nu_exact']));tau=f(src['derived']['tau']);h=f(src['derived']['h']);g=f(src['derived']['g']);eg=sum(nu[i]*weight(th[i],g) for i in range(6));enclosed(j['canonical']['eg'],eg)
    r142b=Path(args.r142).read_bytes();assert sha(r142b)=='c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55';base=next(r for r in json.loads(r142b)['cases']['I1']['verifications'] if r['id']==0 and r['distribution']=='control');Qx0=[sum(f(base[z][i]) for z in ['K1','K2','J'])/3 for i in range(6)];px0=f(base['p']);bfa=f(src['parameters']['B_FA'])
    dw=max(abs(weight(th[i],g)-f(src['atoms'][i]['wg'])) for i in range(6));dc=dr=F(0)
    for sg in src['score_segments']:
        mid=(f(sg['lo'])+f(sg['hi']))/2
        for i in range(6):
            cv=math.prod((a for a in th[i] if a<mid),start=F(1));diff=abs(cv-f(sg['c'][i]));dc=max(dc,diff);dr=max(dr,diff/cv)
    disc=j['canonical']['profile_discrepancy_vs_R136_saved']
    for key,value in [('wg_max_abs_decimal',dw),('score_c_max_abs_decimal',dc),('score_c_max_relative_decimal',dr)]:assert abs(float(disc[key])/float(value)-1)<1e-20
    exact_n=0;fa_values=[]
    for cc in j['exact_controls']:
        row=old['x0_control'] if cc['label']=='x0_control' else dd[cc['grid_m']][cc['row_index']];assert row['xq']==cc['xq'];c=eg if cc['c_version']=='eg' else 2*f(row['q'])/f(row['p']);enclosed(cc['c'],c);assert 0<c<=eg
        ex,nl=certificate(th,nu,list(map(f,row['rho'])),row['good'],tau,h,c)
        for k,v in ex.items():enclosed(cc['cut_certificate'][k],v)
        saved_nl=cc.get('log_candidate_80_digit',{}).get('weighted',{})
        for key,val in nl.items():
            sk={'logD_weighted':'logD','lorentzG_weighted':'LorentzG','linearG_weighted':'linearG','linearD_weighted':'linearD'}[key]
            if sk in saved_nl:assert abs(Decimal(saved_nl[sk])-val)<Decimal('1e-65')
        if cc['label']=='x0_control':
            rho=list(map(f,row['rho']));good=row['good'];I=F(0);pairs=0
            times=sorted({tau,h}|{z for tt in th for z in tt if tau<z<h})
            for l,rr in zip(times,times[1:]):
                mid=(l+rr)/2;ks=[sum(a<mid for a in tt) for tt in th];cs=[math.prod((a for a in tt if a<mid),start=F(1)) for tt in th];A=sum(nu[i]*cs[i] for i in range(6) if ks[i]==4);B=sum(nu[i] for i in range(6) if ks[i]==0);zl=l**-4
                for v in range(6):
                    for u in range(6):
                        if not(good[v] and rho[v]>0 and not good[u] and ks[v]-ks[u]==4 and src['pairs'][6*v+u]['Psi']):continue
                        zr=max(rr**-4,Qx0[v]/(bfa*4*px0*cs[v]))
                        if zr<zl:I+=rho[v]*nu[v]*nu[u]*cs[v]*cs[u]*(zl-zr)/((A*zl+B)*(A*zr+B));pairs+=1
            fa=cc['canonical_FA'];enclosed(fa['value'],I);enclosed(fa['p'],px0);enclosed(fa['B_FA'],bfa)
            for i in range(6):enclosed(fa['Q_v'][i],Qx0[i])
            assert pairs==fa['integrated_pair_terms'] and I<=ex['Tcut']<=ex['4H'];fa_values.append(dict(c_version=cc['c_version'],I_FA=float(I),Tcut=float(ex['Tcut']),fourH=float(ex['4H'])))
        exact_n+=1
    # Recompute every floating row independently from canonical endpoint masses.
    ts=sorted({tau,h}|{z for tt in th for z in tt if tau<z<h});nuN=list(map(float,nu));cache={}
    for t in ts:
        for side in [False,True]:cache[t,side]=([float(weight(tt,t)) for tt in th],[sum(a<=t if side else a<t for a in tt) for tt in th])
    segments=[]
    for l,rr in zip(ts,ts[1:]):
        mid=(l+rr)/2;ks=[sum(a<mid for a in tt) for tt in th];cs=[float(math.prod((a for a in tt if a<mid),start=F(1))) for tt in th];A=sum(nuN[i]*cs[i] for i in range(6) if ks[i]==4);B=sum(nuN[i] for i in range(6) if ks[i]==0);zl=float(l**-4);zr=float(rr**-4);segments.append((ks,cs,(zl-zr)/((A*zl+B)*(A*zr+B))))
    def numeric(row,c):
        rho=row['rho'];good=row['good'];c=float(c)
        def st(t,side):
            w,k=cache[t,side];A=[sum(rho[i]*nuN[i]*w[i] for i in range(6) if good[i] and rho[i]>0 and k[i]>r) for r in range(4)];B=[sum(nuN[i]*w[i] for i in range(6) if not good[i] and k[i]<=r) for r in range(4)];return A,B,[A[r]/(A[r]+B[r]+c) for r in range(4)]
        a0,b0,p0=st(tau,True);ah,bh,ph=st(h,False);d=[b0[r]/(b0[r]+(r+1)*c) for r in range(4)];ini=sum(d[r]*p0[r] for r in range(4));ter=-sum(d[r]*ph[r] for r in range(4));G=D=0.;IG=[0.]*4;ID=[0.]*4
        for t in ts[1:-1]:
            am,bm,pm=st(t,False);ap,bp,pp=st(t,True)
            for r in range(4):
                a=ap[r]-am[r];b=bm[r]-bp[r];den=(am[r]+bm[r]+c)*(ap[r]+bp[r]+c);G+=d[r]*(bm[r]+c)*a/den;D+=d[r]*am[r]*b/den;IG[r]+=a;ID[r]+=b
        T=sum(rho[v]*nuN[v]*nuN[u]*cs[v]*cs[u]*factor for ks,cs,factor in segments for v in range(6) for u in range(6) if good[v] and rho[v]>0 and not good[u] and ks[v]-ks[u]==4)
        rawA=sum(rho[i]*nuN[i]*cache[tau,True][0][i] for i in range(6) if good[i] and rho[i]>0);rawB=sum(nuN[i]*cache[tau,True][0][i] for i in range(6) if not good[i]);alpha=rawA/c;beta=rawB/c;sd=sum(d);logD=sum(d[r]*.25*math.log((b0[r]+c)/(bh[r]+c)) for r in range(4));Lor=0.
        for r in range(4):
            vals=[]
            for i in range(6):
                theta=sorted(th[i])[r]
                if good[i] and rho[i]>0 and tau<theta<h:
                    wh=cache[h,False][0][i];vals.append((float(weight(th[i],theta))/wh,rho[i]*nuN[i]*wh))
            last=0.
            for R in sorted({z[0] for z in vals}):Lor+=d[r]*(R-last)*math.log1p(sum(z for ratio,z in vals if ratio>=R)/c);last=R
        H=ini+ter+G+D
        return dict(eligible=True,initial=ini,negative_terminal=ter,HG=G,HD=D,Hcut=H,Tcut=T,coarse_exact_dr=4*(alpha+beta/4)*sd,coarse_harmonic=4*(alpha+beta/4)*min(4.,beta*25/12),logD_weighted=logD,lorentzG_weighted=Lor,linearG_weighted=sum(d[r]*IG[r]/c for r in range(4)),linearD_weighted=sum(d[r]*ID[r]/(4*c) for r in range(4)),candidateHcut=ini+ter+logD+Lor,**{'4H':4*H})
    rows=[]
    for m in ['4','8']:
        for i,row in enumerate(dd[m]):
            c2=2*f(row['q'])/f(row['p']);legal=row['gates']['high'] and c2<=eg
            rows.append(dict(grid_m=m,row_index=i,xq=row['xq'],weights=dict(original=row['dx_weight'],corrected=row['dx_weight_corrected']),high_2C_legal=legal,candidates={'eg':numeric(row,eg),'2C':numeric(row,c2) if legal else {'eligible':False}}))
    assert len(rows)==8376;rowmap={(r['grid_m'],r['row_index']):r for r in rows};assert len(rowmap)==8376
    for m in ['4','8']:
        for i,row in enumerate(dd[m]):
            rr=rowmap[m,i];assert rr['xq']==row['xq'];assert rr['weights']['original']==row['dx_weight'] and rr['weights']['corrected']==row['dx_weight_corrected'];legal=row['gates']['high'] and 2*f(row['q'])/f(row['p'])<=eg;assert legal==rr['high_2C_legal']
            for cv,z in rr['candidates'].items():
                assert z['eligible']==(cv=='eg' or legal)
                if not z['eligible']:continue
                close(z['Hcut'],z['initial']+z['negative_terminal']+z['HG']+z['HD']);assert z['Tcut']<=z['4H']+1e-11 and z['4H']<=z['coarse_exact_dr']+1e-10 and z['coarse_exact_dr']<=z['coarse_harmonic']+1e-10
    metricmap={'4_initial':('initial',4),'negative_4_terminal':('negative_terminal',4),'4_HG':('HG',4),'4_HD':('HD',4),'4_Hcut':('Hcut',4),'Tcut':('Tcut',1),'ST14_exact':('coarse_exact_dr',1),'ST14_harmonic':('coarse_harmonic',1),'4_logD':('logD_weighted',4),'4_lorentzG':('lorentzG_weighted',4),'4_linearG':('linearG_weighted',4),'4_linearD':('linearD_weighted',4),'4_candidateHcut':('candidateHcut',4)}
    for key,ag in j['aggregate'].items():
        m,wt,cv,domain=key.split('/');A={k:0. for k in metricmap};B=A.copy();A['saved_I']=B['saved_I']=0.;count=0;mass=vol=0.
        for i,row in enumerate(dd[m]):
            rr=rowmap[m,i];z=rr['candidates'][cv]
            if not z['eligible'] or (domain.startswith('post') and not row['after']) or (domain.startswith('pre') and not row['before']) or (domain.endswith('high_legal') and not rr['high_2C_legal']):continue
            w=float(f(row['dx_weight'] if wt=='original' else row['dx_weight_corrected']));af=w*row['p'];bf=af*float(f(row['hardmass']))/row['q'];mass+=af;vol+=w;count+=1
            for k,(field,mul) in metricmap.items():A[k]+=af*mul*z[field];B[k]+=bf*mul*z[field]
            A['saved_I']+=af*row['I'];B['saved_I']+=bf*row['I']
        assert count==ag['count'];close(mass,ag['sum_p_weight']);close(vol,ag['dx_volume'])
        for k in A:close(A[k],ag['A'][k]);close(B[k],ag['B'][k])
        for vals,shares in [(A,ag['A_shares']),(B,ag['B_shares'])]:
            gross=vals['4_initial']+vals['4_HG']+vals['4_HD'];net=vals['4_Hcut'];close(shares['gross_positive'],gross)
            if gross:
                for field,key2 in [('initial_over_gross','4_initial'),('HG_over_gross','4_HG'),('HD_over_gross','4_HD')]:close(shares[field],vals[key2]/gross)
                close(shares['terminal_return_over_gross'],-vals['negative_4_terminal']/gross)
            if net:
                for kk in ['4_initial','negative_4_terminal','4_HG','4_HD']:close(shares['net_piece_shares'][kk],vals[kk]/net)
            if vals['4_initial']:close(shares['injection_over_initial'],(vals['4_HG']+vals['4_HD'])/vals['4_initial'])
    print(json.dumps(dict(status='PASS',scope='Six exact canonical control certificates and all saved A/B aggregate reconstruction; all-point floating formulas remain numerical diagnostics, no FULL or spatial integration error certificate',exact_control_count=exact_n,rows=len(rows),aggregate_count=len(j['aggregate']),x0_canonical_FA=fa_values,cut_json_sha256=sha(jb),detail_sha256=sha(db),verifier_sha256=sha(Path(__file__).read_bytes())),indent=2))
if __name__=='__main__':main()
