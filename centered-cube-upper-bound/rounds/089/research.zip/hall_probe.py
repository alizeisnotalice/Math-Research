"""PUBLIC neutral exact finite change-of-measure certificates.
No physical input, continuous first-hit event, private recipe, or Hall theorem.
Run: python3 hall_probe.py. Standard library only.
"""
from fractions import Fraction as F
import itertools,json,math
from pathlib import Path

def log_bounds(x):
    x=F(x);k=0
    while x>F(3,2):x/=2;k+=1
    while x<F(3,4):x*=2;k-=1
    def base(q):
        z=(q-1)/(q+1);v=2*sum(z**(2*j+1)/F(2*j+1) for j in range(100))
        e=2*abs(z)**201/F(201)/(1-z*z);return v-e,v+e
    a=base(x);b=base(F(2))
    return a[0]+k*(b[0] if k>=0 else b[1]),a[1]+k*(b[1] if k>=0 else b[0])
def sqrt_upper(x):
    lo=F(0);hi=max(F(1),x)
    for _ in range(100):
        mid=(lo+hi)/2
        if mid*mid>=x:hi=mid
        else:lo=mid
    assert hi*hi>=x
    return hi

def stage(n,gamma,pad,holdout):
    Y=[[F(3,4),F(5,4)],[F(5,4),F(3,4)],[F(1),F(1)]]
    U=[[y+pad for y in row] for row in Y]
    Z=[sum(u*u for u in row)/2 for row in U]
    lam=F(6,5)**n
    M=min(1/gamma,max(F(3)*z**n/((1-gamma)*lam**2) for z in Z))
    normalization=F(0);rn_integral=F(0);eventmass=F(0);ea=F(0);eb=F(0);covermass=F(0);records=[]
    for bits in itertools.product((0,1),repeat=n):
        yh=[math.prod(Y[j][b] for b in bits) for j in range(3)]
        uh=[math.prod(U[j][b] for b in bits) for j in range(3)]
        density=[math.prod(U[j][b]**2/Z[j] for b in bits) for j in range(3)]
        q=gamma+(1-gamma)*sum(density)/3
        w=1/q;ev=max(yh)>lam;cover=max(uh)>=lam
        # UNKNOWN is a declared loss of classification, not fabricated success.
        unknown=cover and sum(bits)%3==1
        a=w if ev and not unknown else F(0)
        b=w if (ev or unknown) and cover else F(0)
        assert F(0)<=a<=w*ev<=b<=M
        assert q>=gamma
        if ev:assert cover
        if cover:assert w<=M
        p=F(1,2**n)
        normalization+=p*q;rn_integral+=p*q*w;eventmass+=p*ev;covermass+=p*cover
        ea+=p*q*a;eb+=p*q*b
        records.append({'bits':list(bits),'q':str(q),'rn':str(w),'event':ev,'cover':cover,
                        'unknown':unknown,'a':str(a),'b':str(b)})
    assert normalization==rn_integral==1 and ea<=eventmass<=eb
    radius=sqrt_upper(M*M*log_bounds(F(60))[1]/(2*holdout))
    # This is the exact radius formula for hypothetical iid frozen-Q holdout,
    # not an empirical run or a physical-event confidence certificate.
    return {'scope':'NONPHYSICAL finite product exercise','dimension':n,'gamma':str(gamma),
        'pad':str(pad),'lambda':str(lam),'Z':list(map(str,Z)),
        'global_bound':str(1/gamma),'event_cover_bound':str(M),
        'normalization_exact':str(normalization),'rn_integral_exact':str(rn_integral),
        'event_probability_exact':str(eventmass),'cover_probability_exact':str(covermass),
        'expected_lower':str(ea),'expected_upper':str(eb),'unknown_weight_exact':str(eb-ea),
        'hypothetical_iid_holdout_N':holdout,'delta':'1/20','radius_upper_exact':str(radius),
        'records':records}

def main():
    out={'schema':'R89-public-neutral-mixture-v1',
      'scope':'Exact generic proposal and three-valued payoff exercises only; no actual physical input or Hall claim.',
      'identities':{'proposal':'q=gamma+(1-gamma)/3 sum_j product_i U_j(x_i)^2/Z_j',
        'Z':'E_base U_j^2','RN':'1/q (full mixture, independent of sampled latent branch)',
        'cover':'actual finite-node event subset union_j{product U_j>=lambda}',
        'event_bound':'min(1/gamma,max_j 3 Z_j^n/((1-gamma)lambda^2))',
        'unknown':'use certified-cover-supported upper, or cap a valid upper at the proved global true-payoff bound M; untruncated unknown RN alone has only the defensive bound',
        'three_value':'0<=a<=true RN payoff<=b<=M',
        'iid_radius':'M sqrt(log(3/delta)/(2N)); conditional on frozen Q and correct uniform classification'},
      'stages':[stage(2,F(1,4),F(0),32),stage(4,F(1,8),F(1,32),128),stage(6,F(1,16),F(1,16),512)],
      'not_certified':['continuous first root','actual E2 gates','whole Fnew coverage','physical source sampling','principal Hall capacity'],
      'ideal_continuous_sampling':'Rational cell masses plus uniform-within-cell latent bits define continuous Haar proposal; finite representative evaluation alone does not certify it.'}
    p=Path(__file__).with_name('hall_results.json');p.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'status':'PASS','states':sum(len(s['records']) for s in out['stages']),'stages':3,'output':p.name}))
if __name__=='__main__':main()
