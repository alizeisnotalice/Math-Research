"""Exact NONPHYSICAL sampling-account checks; no physical gate certificate."""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import json

CHECKS=0
def check(condition):
    global CHECKS
    CHECKS+=1
    assert condition

def tail_num(n,k,r,d):
    return sum(comb(n,j)*r**j*(d-r)**(n-j) for j in range(k,n+1))

def table(n,eta,bits):
    d=2**bits; low=[F(0)]
    for k in range(1,n+1):
        left,right=0,d
        while left+1<right:
            mid=(left+right)//2
            if tail_num(n,k,mid,d)*eta.denominator<=eta.numerator*d**n:left=mid
            else:right=mid
        p=F(left,d);low.append(p)
        check(F(tail_num(n,k,left,d),d**n)<=eta)
        check(F(tail_num(n,k,left+1,d),d**n)>eta)
    high=[1-low[n-k] for k in range(n)]+[F(1)]
    check(all(low[k]<=low[k+1] and high[k]<=high[k+1] for k in range(n)))
    check(all(low[k]<=high[k] for k in range(n+1)))
    for k in range(n):
        p=high[k]
        cdf=1-F(tail_num(n,k+1,p.numerator,p.denominator),p.denominator**n)
        check(cdf<=eta)
    return low,high

def binomial_mass(n,k,p):
    return F(comb(n,k))*p**k*(1-p)**(n-k)

def calibration(n,eta,low,high):
    out=[]
    for p in map(F,[0,F(1,256),F(1,16),F(1,2),F(15,16),F(255,256),1]):
        lf=sum((binomial_mass(n,k,p) for k in range(n+1) if p<low[k]),F(0))
        uf=sum((binomial_mass(n,k,p) for k in range(n+1) if p>high[k]),F(0))
        check(lf<=eta and uf<=eta and lf+uf<=2*eta)
        out.append(dict(p=str(p),lower_failure=str(lf),upper_failure=str(uf)))
    return out

def randomized_envelopes(n,low,high,eta,unknown):
    # A weighted three-state model, not a cube input or radius approximation.
    q=[F(2,5),F(2,5),F(1,5)]
    g=[F(1,14),F(1,7),F(1)]
    a=[F(0) if i in unknown else v for i,v in enumerate(g)]
    b=[F(1) if i in unknown else v for i,v in enumerate(g)]
    p=sum((qi*gi for qi,gi in zip(q,g)),F(0))
    probs=[sum((qi*(1-bi) for qi,bi in zip(q,b)),F(0)),
           sum((qi*(bi-gi) for qi,bi,gi in zip(q,b,g)),F(0)),
           sum((qi*(gi-ai) for qi,gi,ai in zip(q,g,a)),F(0)),
           sum((qi*ai for qi,ai in zip(q,a)),F(0))]
    flags=[(0,0,0),(0,0,1),(0,1,1),(1,1,1)]
    check(sum(probs)==1 and min(probs)>=0)
    states={(0,0,0):F(1)}
    for _ in range(n):
        next_states={}
        for ks,pr in states.items():
            for ds,pb in zip(flags,probs):
                key=tuple(x+y for x,y in zip(ks,ds))
                next_states[key]=next_states.get(key,F(0))+pr*pb
        states=next_states
    check(sum(states.values())==1)
    bad=F(0)
    for (km,k,kp),mass in states.items():
        check(km<=k<=kp)
        if p<low[km] or p>high[kp]:bad+=mass
        if len(unknown)==3:check(low[km]==0 and high[kp]==1 or mass==0)
    check(bad<=2*eta)
    return dict(n=n,unknown_states=sorted(unknown),true_normalized_mean=str(p),joint_states=len(states),failure_probability=str(bad))

def moment_box(b,m1,m2,bm,bp,m1m,m1p,m2m,m2p,T):
    # ell=1 is an exact normalization of the scalar bounded observable.
    true=(m2/b-(m1/b)**2) if b>T else F(0)
    if bp<=T:lo=hi=F(0)
    else:
        hi=max(F(0),min(F(1,4),m2p/max(T,bm)-(m1m/bp)**2))
        lo=max(F(0),m2m/bp-(m1p/bm)**2) if bm>T else F(0)
    check(lo<=true<=hi)
    return dict(T=str(T),b=str(b),true=str(true),lower=str(lo),upper=str(hi),box=[str(v) for v in [bm,bp,m1m,m1p,m2m,m2p]])

def main():
    stages={};tables=[];envelopes=[];boxes=[]
    for stage,ns,bits,eta in [('pilot',[1,2,4,8],12,F(1,20)),('pressure',[4,8],16,F(1,100)),('expanded',[16,32,64,128],24,F(1,20))]:
        start=CHECKS
        for n in ns:
            low,high=table(n,eta,bits)
            tables.append(dict(stage=stage,n=n,eta=str(eta),bits=bits,lower=list(map(str,low)),upper=list(map(str,high)),calibration=calibration(n,eta,low,high)))
            if n<=8:
                for unknown in [set(),{2},{0,1,2}]:envelopes.append(randomized_envelopes(n,low,high,eta,unknown))
        stages[stage]=CHECKS-start
    # Exact event-only inverse tilt bound and an unresolved-region countercheck.
    p=[F(1,2),F(1,2)];exp_score=[F(100),F(1)];z=sum(a*b for a,b in zip(p,exp_score))
    q=[v/z for v in exp_score];M=z/100
    check(1/q[0]==M and 1/q[1]>M)
    gamma=F(1,4);qdef=[gamma+(1-gamma)*v for v in q]
    check(sum(a*b for a,b in zip(p,qdef))==1 and max(1/v for v in qdef)<=1/gamma)
    tilt=dict(reference=list(map(str,p)),density=list(map(str,q)),event_indices=[0],event_bound=str(M),unknown_inverse_weight=str(1/q[1]),defensive_density=list(map(str,qdef)),defensive_bound=str(1/gamma))
    low,high=table(8,F(1,20),16)
    check(high[0]<1)
    missing=dict(n=8,true_payoff='1 at every point',correct_unknown_interval=['0','1'],naive_unknown_as_outside_upper=str(high[0]),naive_coverage_probability='0')
    for T in [F(1,2),F(1),F(2)]:
        for factor in [F(0),F(1,2),F(1),F(11,10),F(2),F(4)]:
            for frac in [F(0),F(1,4),F(1,2),F(1)]:
                for width in [F(0),T/10,T/2]:
                    b=T*factor;m1=m2=b*frac
                    boxes.append(moment_box(b,m1,m2,max(0,b-width),b+width,max(0,m1-width),m1+width,max(0,m2-width),m2+width,T))
    result=dict(scope='Exact NONPHYSICAL finite-sampling and moment-box arithmetic. No actual physical gate, source integral, or general dimensional certificate.',counts=dict(assertions=CHECKS,tables=len(tables),envelope_models=len(envelopes),moment_boxes=len(boxes)),stages=stages,tables=tables,envelope_models=envelopes,tilt=tilt,unknown_countercheck=missing,moment_boxes=boxes)
    Path(__file__).with_name('parent_sampling_results.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(dict(status='PASS',counts=result['counts'],stages=stages),sort_keys=True))

if __name__=='__main__':main()
