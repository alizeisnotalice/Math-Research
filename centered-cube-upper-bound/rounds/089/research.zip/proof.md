# 中心立方体第89轮：真实递推的集中约束、共同半群障碍与稀尾测量

日期：2026-10-12。一般正 L1 输入上的目标 `C_n^square <= sqrt(n) n^{o(1)}` **尚未证明**；保留的一般基准为 `O(n log n)`。本轮不修改第82轮原事件、第87轮已付分支或真实勒贝格接收测度。

本轮严格证明了实际高负担递推的环带质量下界及来源弱极限的坐标原子约束；在明确的归一化边际反集中条件下给出有限阶段费用和终项。另一条路线构造了合法共同卷积半群，并证明该整个指定族的任意正时间混合均有 `Omega(n/log^2 n)` 的逐点立方体比较障碍。这个障碍不是立方体极大算子的弱型下界，也不否定其他半群或有偿误差路线。

实际径向秩重分配给出了可行耦合，但仅使用逐行前缀约束的外包络仍付 `n log 2`。新增的来源抽样面与内部配对公式和严格的三值分类统计预算，旨在使罕见事件的真实测度可以检验；它们本身不证明一般容量界。私人数值部分只公开结论和证据范围，实际输入配方、抽样程序与环境参数保留本地。

按用户配置，研究由3位 Astra high 路线作者、Astra high 与 Sol high 两位独立审核者、2位 Sol high 数值作者及1位 Sol high 来源作者并行完成。审核者先检查命题与反例风险，再阅读证明；主代理逐项整合并执行隔离复现。模型结论不能替代数学证明或实际运行回执。

符号约定：`Q(x,L)` 始终使用全边长，原窗口为 `[1,2]`；替代路线单独使用半边长 `r`，已经在文中明示。递推中的 `alpha,epsilon,c,beta` 保持原定义；Lévy 指数 `alpha` 只在替代路线内部使用，不能代入递推账。接收集 `B_0` 与已付系数 `B_base` 分开。条件方差始终来自真实规范耦合，不换成优化耦合，不假定对接收子集单调。

更新后的64项技能按实际需要使用，并记录入口字节快照；这不是全库定理或原文的统一验收。本轮详细 LaTeX 仅静态核验，按要求不编译 PDF。


## 第89轮主账与剩余量

令 `mu=f dy`，`Q(x,L)=x+[-L/2,L/2]^n`，`L in [1,2]`，需求为真实 `lambda dx`。保持原锚点 `A_1 f < lambda/2`、原平滑核的全窗口上界、严格后见证、原最早硬接触 `A_L* f=lambda` 及原中间下限 `exp(-s_n)/2`。每次实际删源并重选时重新检查全部门；来源主闭包保旧接触及旧前缀，不自动保原中间下限或严格后见证。

设 `H=1+n log 2`，`theta=log^-2(n+2)`，`alpha=epsilon=1/[10log(n+2)]`，`c=1-alpha-epsilon`，`beta=c/2`。已付费用完整保留：

- `B_base=4+2log2 sqrt(7n/3)`，`B_ext=2H/sqrt(n+2)`。
- `T_soft=1+log2 min(2n,sqrt[n(theta^-1+4theta/3)])`，粗平滑付 `T_soft/alpha`。
- 原包网格 `h0=1/(16n^2)`，`a=n^-p`、`rho=n^-1/2`，`p>0` 为原先固定值；`P_dom=(5+3log(1/a))/rho`。
- `h*=1/(16n^(3/2))`，`E=exp(nh*)`，`B_h=1+E[1+(2n^2+n)h*]`。后验物理碰撞至少 `3/4` 或平均网格熵至多 `sqrt n` 的并集一次支付 `P_phys=2[E+B_h+2(1+E)sqrt n]`。
- 完整未付余集 `Fnew=Fdiff ∩ {C_h*<3/4, Hbar_h*>sqrt n}`；`Fdiff` 为原粗平滑低中间分支删除原 dominant-packet 事件后的集合。

只有支付整个 `Fnew` 的 `D_new` 才能代入

`C_n^square <= C_loc log(n+2)[B_base+B_ext+T_soft/alpha+P_dom+P_phys+D_new]`。

若逐原 `kappa=1+log[lambda/(2P_1,L*)]` 二进层证明，则另付 `J_n=O(log n)`；本轮没有新增已付分支，也未取消这些层或全尺度费用。私人诊断使用的某个 `p` 值只认证其对应分支，不能把该值替换原账上任意指定的 `p`。

### 保留的容量、规范方差与通量接口

对每个正规紧致 `B subset Fnew`、连续原尺度和每个正主割 `(A_s,S_s)`，真实源邻域等于 `S_s`（模 mu），`D_s=lambda|A_s|=integral_Ss b* dmu`。规范列 `b_A<=H`。第88轮已证明：若对每个这样的主割重新计算均有 `I_T(A_s)<=R_n mu(S_s)/n`，`T=sqrt(24nR_n+96)`，则所有割比至多 `2T`，经 Lusin、内正则性与 Borel Hall 得完整条件回代。所需 `R_n=n^{o(1)}` 尚未证明。

一般可测停止图保精确通量 `D-a=B_face-V_bulk`，且整体锚点 `a<=mu(S)`。故 `B_face-V_bulk<=C_root mu(S)+D/2` 足以推出 `D<=2(1+C_root)mu(S)`；仅凭逐点锚点小于半接触不能替代整体锚点预算。两项的逐正部分估计仍各为线性维数。新的配对抽样保留了该有符号差，尚未给其统一的根阶上界。

### 本轮实际递推所得与未付费用

在真正坏来源限制递推中，沿持续接收行的原立方体严格嵌套。在 `R_i>=R_*>=8K/c`、接收保留比例 `s_i>=1-c/16`、来源比例 `rho_i<=3c/4` 的阶段，环带来源贡献至少 `5cD_i/16`；归一化子来源的该贡献至少 `5R_i/12`。

若这样的高负担阶段无限持续，则自动有共同有界来源支持，且归一化子来源的每个相应弱极限 nu 必须满足 `sum_j atom(nu_j)>=5R_*/(12log2)`。这里 atom 指坐标边缘的总原子质量。该结论没有矛盾：绝对连续源经归一化限制可以趋向奇异测度；原各门不传给极限。

若另有明确尺度 h 上的统一归一化边际反集中模量，则完整阶段的重复费用及 `H t_m W_m` 已在正文显式支付。这个额外模量未对一般输入建立，费用仍以 `D_0` 计，不是所需的根阶 `W_0` 预算。其余阶段、跨阶段循环及最终终项仍保留在主账，不能凭定性紧性宣布终止或免除费用。

### 本轮失败路线与下一实质缺口

径向秩在每个真实后验下均匀，但同一来源跨接收行的秩不因此均匀或独立。仅保留标量前缀的 rank-envelope 优化，其最小外壳费用恰为 `n log2`；失败的是这个放松，不是已经构造实际反例否定任意共同重分配。

指定的稳定立方跳跃半群确有单一生成元、所有尺度共同钟和 Cesàro 弱型常数1。其一大跳比较只能给 `O(n log n)`；完整核分布的角点稳定性进一步证明该族任意正时间混合的点态比较费用至少 `Omega(n/log^2 n)`，对随维数选择的跳跃指数也统一。该证明排除在这个族内靠优化时钟或完整分布获得根阶点态支配；有偿误差、其他共同族及直接 Gamma 平滑极大估计仍开放。

数值方面，条件于冻结的真实输入和提议律，用精确 RN、分类上下包络、有限样本尾界及显式未判定质量。有限节点硬见证不是连续首达或完整余集；节点补集也没有覆盖完整余集。有限探路、有限精确证书、概率置信区间和一般证明在后文分开记录。

共同来源的实际跨行抵消、归一化来源集中费用、完整首达/粗平滑门的数值认证及所有尺度的最终返回仍未闭合。一般目标继续开放。


## 1. Outcome and original principal scope

**No general quantitative Hall improvement is proved in this component.** The attempted radial-rank mechanism produces genuine positive couplings for arbitrary actual inputs, but its proposed scalar-prefix envelope cannot improve even the outer $n\log2$ fee. The failure is proved sharply as a statement about that relaxation, without presenting a nongated example as a counterexample to the cube theorem. A coupled same-source face/interior observable, a bounded source-sampled demand estimator, and their dimension-dependent qualification-error budgets are also proved.

Fix $n\ge2$, $f\ge0$ in $L^1(\mathbb R^n)$, $d\mu=f\,dy$, and $\lambda>0$. Let $B$ be a regular compact subset of the **unchanged** R88 event $F_{\rm new}$, with its original continuous selector. For a principal pair $A=A_s$, $S=S_s$, put
\[
 \tau_x=L_*(x),\qquad M=\mu(S),\qquad D=\lambda|A|.
\]
All original anchor, smooth, middle, coarse and R87 physical-event conditions remain those of the original input. The source restriction $g=f1_S$ preserves old hard prefixes and the whole captured posterior on $A$, but need not preserve the middle lower gate or strict later witness. No such inheritance is used.

The retained finite identity, with $\chi_A(x,L)=1_A(x)1_{\{1<L<\tau_x\}}$, is
\[
 D-a=n\int_S\int_1^2(q_y(L)-p_y(L))\,\frac{dL}{L}\,d\mu(y),
 \qquad a=\int_A A_1g(x)\,dx\le M.                         \tag{1}
\]
Here $p_y$ is uniform cube occupancy and $q_y$ is occupancy on a uniformly chosen one of the $2n$ unit-area faces. The exact quantitative target tested was
\[
 n\int_S\int_1^2(q_y-p_y)\,\frac{dL}{L}\,d\mu
 \le C\sqrt n\log^2(n+2)M+\tfrac12D                       \tag{2}
\]
for every original input and every principal pair, with universal $C$. It is **not proved**. If proved, the integrated anchor budget $a\le M$ in (1), not merely the strict pointwise anchor, would give
$D\le2[1+C\sqrt n\log^2(n+2)]M$. This implication is retained accounting and is not counted as new progress.

## 2. An actual radial probability transform

For a contact row $x$, let
\[
 m_x=\mu(Q(x,\tau_x))=\lambda\tau_x^n,\quad
 \nu_x=\frac{1_{Q(x,\tau_x)}\mu}{m_x},\quad
 d_x(y)=2\|x-y\|_\infty,
\]
\[
 R_x(r)=\frac{\mu(Q(x,r))}{m_x}\quad(0\le r\le\tau_x),
 \qquad U_x(y)=R_x(d_x(y)).                               \tag{3}
\]
Only captured $y$ are used in (3); extend $U_x$ arbitrarily outside the contact cube and define the coupling density there to be zero. The cube at side zero has zero $\mu$ mass. Every boundary of a cube has zero $\mu$ mass because $\mu\ll dy$. Consequently, under the actual posterior $\nu_x$, the radius $d_x(Y)$ has continuous distribution function $R_x$, with $R_x(0)=0$ and $R_x(\tau_x)=1$.

It follows that
\[
 (U_x)_\#\nu_x=du\big|_{[0,1]}.                           \tag{4}
\]
For completeness, continuity makes every level $u\in[0,1]$ attainable by $R_x$. A level interval on which $R_x$ is constant has zero probability under the radius law. Taking the endpoint of the level set $R_x=u$ therefore gives
$\nu_x\{R_x(d_x(Y))\le u\}=u$. This proves (4), including possible gaps in the radial support. No strict radial monotonicity, transversality, source-coordinate independence, or smooth density is required. The unrandomized formula (4) must not be applied to an atomic source proxy: its radial CDF can have jumps. The theorem here uses the actual absolutely continuous source.

The function $(x,y)\mapsto U_x(y)$ is measurable: the map $(x,r)\mapsto\mu(Q(x,r))$ is continuous for $r>0$ and continuous at zero for each fixed $x$, and the integral description also gives joint Borel measurability at zero. Restriction to any measurable row set is therefore legitimate.

Earliest contact supplies, for $1\le d_x(y)<\tau_x$,
\[
 U_x(y)\le\left(\frac{d_x(y)}{\tau_x}\right)^n.             \tag{5}
\]
Indeed every old earlier hard average is at most $\lambda$. For $d_x(y)<1$, the anchor instead gives
$U_x(y)<1/(2\tau_x^n)$. These are rowwise constraints. Equation (4) does **not** say that the ranks seen from one fixed source $y$ across different receiver rows are uniform or independent.

## 3. Rank reweighting is a genuine feasible coupling

Let $\psi:[0,1]\to[0,\infty]$ be Borel with
$\int_0^1\psi(u)du=1$. Define
\[
 d\Gamma_\psi(x,y)=1_A(x)\tau_x^{-n}1_{Q(x,\tau_x)}(y)
                       \psi(U_x(y))\,dx\,d\mu(y).          \tag{6}
\]
Then $\Gamma_\psi$ is a finite positive capture-supported coupling with receiver marginal exactly $\lambda1_A dx$. Its source marginal is $b_\psi\mu$, where
\[
 b_\psi(y)=\int_A\tau_x^{-n}1_{Q(x,\tau_x)}(y)
                         \psi(U_x(y))\,dx,\qquad
 \int b_\psi\,d\mu=D.                                    \tag{7}
\]
**Proof.** By (4), integrating (6) in $y$ gives
$\lambda\int\psi\,du=\lambda$ for each contact row. Tonelli then proves finiteness and (7). In particular $b_\psi$ is finite $\mu$ almost everywhere, even when no finite essential bound for it has been proved. Modifying $\psi$ on a Lebesgue-null rank set changes neither coupling nor column almost everywhere, by (4) and Tonelli.

For any measurable receiver subcut, let $N$ be its essential source neighborhood. For almost every row of that subcut, $\mu(Q(x,\tau_x)\setminus N)=0$. Every smaller cube is contained in this contact cube. Thus restricting the source to $N$ preserves **all numerators in (3)** as well as their denominator, simultaneously in radius. The same rank coupling can be used on the restricted input with no new selector. This is a positive-coupling fact, not a statement that the restricted input inherits all gates.

For a Borel rank set $E\subset[0,1]$, define the unnormalized rank-bin column
\[
 b_E(y)=\int_A\tau_x^{-n}1_Q(y)1_{\{U_x(y)\in E\}}\,dx.
\]
The exact global balance is
\[
 \int b_E(y)\,d\mu(y)=|E|D.                              \tag{8}
\]
It is a source-integrated identity. Replacing it by $b_E(y)=|E|b(y)$ at fixed $y$ is an unjustified new hypothesis. It is precisely this unproved cross-row rank information that the attempted allocation needs.

## 4. Sharp obstruction to the proposed scalar-prefix envelope

Let $c=\operatorname*{ess\,sup}_{0<u<1}\psi(u)$, possibly infinite. For $1\le d<2$, consider the relaxation that retains only $d<\tau\le2$ and the scalar prefix inequality (5):
\[
 \mathcal K_\psi(d)=
 \sup_{d<\tau\le2}\tau^{-n}
       \operatorname*{ess\,sup}_{0<u<(d/\tau)^n}\psi(u).
                                                                    \tag{9}
\]
Then exactly
\[
 \mathcal K_\psi(d)=c\,d^{-n}.                            \tag{10}
\]
**Proof.** The upper bound is immediate. For any finite $c'<c$, there is a positive-measure rank set on which $\psi>c'$. Some portion of that set lies below a number $u_0<1$. For $\tau>d$ sufficiently close to $d$, $(d/\tau)^n>u_0$, so the inner essential supremum in (9) is at least $c'$. Letting $\tau\downarrow d$ and then $c'\uparrow c$ proves (10), including $c=\infty$.

At fixed physical source $y$, the full-side radius $d=2\|x-y\|_\infty$ has volume element $n d^{n-1}dd$. Hence the outer-shell cost of this envelope is
\[
 \int_{1<2\|x-y\|_\infty<2}\mathcal K_\psi(2\|x-y\|_\infty)\,dx
 =c\,n\log2.                                            \tag{11}
\]
Every normalized nonnegative $\psi$ has $c\ge1$, with equality only for $\psi=1$ almost everywhere. Thus
\[
 \inf_{\psi\ge0,\,\int\psi=1}\{\hbox{outer cost in (11)}\}
 =n\log2.                                               \tag{12}
\]
For bounded $\psi$ a representative can be chosen with $\psi\le c$ everywhere; the trivial full source-column bound is then $b_\psi\le c(1+n\log2)$ almost everywhere. Unbounded $\psi$ can still define the finite coupling (6), but gives no finite bound through (9).

This is a sharp **proof-method obstruction**. It does not assert that the relaxed triples $(d,\tau,u)$ used in (9) are simultaneously realized by actual rows of one input. At the exact boundary $d=\tau$, a true radial CDF forces $U=1$; the proof uses the strict limit $\tau>d$ in a relaxation with no uniform CDF modulus. It does not claim a full-gated counterexample, does not show that actual rank-flow optimization is useless, and does not disprove (2). The failed step is discarding the actual shared-source joint geometry and then expecting a rank weight to improve its scalar envelope.

## 5. A coupled physical observable and its qualification budget

For a positive-mass actual principal source closure $S$, define a reference sampling law $P$ as follows. Draw $Y\sim\mu|_S/M$, draw $L$ with density $1/(L\log2)$ on $[1,2]$, choose $I$ uniformly in $\{1,\ldots,n\}$ and a sign $\Sigma$ uniformly, and choose the remaining $n-1$ coordinates $Z_{-I}$ and one coordinate $R$ independently uniformly in $[-1/2,1/2]$. All these auxiliary kernel variables are independent of $Y$ by construction. Set
\[
 X_f=Y+L(Z_{-I},\Sigma/2),\quad
 X_b=Y+L(Z_{-I},R),\quad
 \Delta=\chi_A(X_f,L)-\chi_A(X_b,L).                      \tag{13}
\]
The coordinate positions in these vectors are assigned using the sampled $I$. Both endpoints use the same physical source, same side and same original selector. The two marginals are exactly the face and cube laws, so
\[
 D-a=n\log2\,M\,\mathbb E_P\Delta,\qquad
 \Delta\in\{-1,0,1\},\qquad
 \mathbb E_P\Delta^2=P\{\chi_A(X_f,L)\ne\chi_A(X_b,L)\}.   \tag{14}
\]
The construction assumes no independence in the physical input. If no principal closure has been certified, the same identity is available with the whole original source and its mass for a genuine receiver set; it must not then be called a principal-cut experiment.

Let $Q$ be an importance proposal with $P\ll Q$ and $w=dP/dQ$. For a defensive proposal
$Q=\varepsilon P+(1-\varepsilon)Q_{\rm tilt}$, $0<\varepsilon\le1$, one has
\[
 0\le w\le\varepsilon^{-1},\qquad
 \mathbb E_Q[(w\Delta)^2]
 \le\varepsilon^{-1}P\{\chi_A(X_f,L)\ne\chi_A(X_b,L)\}.    \tag{15}
\]
This follows from $Q\ge\varepsilon P$ and
$\mathbb E_Q[w^2\Delta^2]=\mathbb E_P[w\Delta^2]$.

Suppose a frozen deterministic classifier certifies both endpoint values outside an event $U$ and declares UNKNOWN on $U$. Put $\widehat\Delta=\Delta$ off $U$ and $\widehat\Delta=0$ on $U$. Then
\[
 |\mathbb E_Q[w\widehat\Delta]-\mathbb E_P\Delta|
 \le\eta:=\mathbb E_Q[w1_U]=P(U),                        \tag{16}
\]
and the resulting absolute flux bias is at most
\[
 n\log2\,M\eta.                                         \tag{17}
\]
A randomized classifier must either be frozen or included as an additional coordinate of the common probability space. Misclassified floating predicates do not count as certified values; their target mass needs a separate error term. The raw proposal proportion of UNKNOWN is not $\eta$ unless the weights justify it.

Thus root-order evidence requires target-law unknown mass of order at most $\operatorname{polylog}(n)/\sqrt n$, or a separate proved payment of that mass. Coupling the face and bulk evaluations may reduce sampling variance but cannot remove the bias in (17). Training a proposal or rank weight must finish before its independent holdout. Query-point weights cannot be substituted for positive receiver-cell volume or actual principal capacity.

## 5.1 A bounded source-sampled estimator of actual demand

Extend the law $P$ in §5 by an independent uniform $Z_0\in[-1/2,1/2]^n$, and put
\[
 A_0=1_A(Y+Z_0),\qquad X=A_0+n\log2\,\Delta.               \tag{18}
\]
Then exactly
\[
 \mathbb E_P X=D/M,\qquad
 -n\log2\le X\le1+n\log2.                               \tag{19}
\]
Indeed normalized cube Fubini gives
\[
 \mathbb E_P A_0=\frac1M\int_S\int_{[-1/2,1/2]^n}
       1_A(y+z)\,dz\,d\mu(y)=a/M;
\]
combine this with (14). The anchor indicator is $1_A$, not the stopped indicator at side one, which would vanish. Variables inside one trial share the same physical source; no within-trial independence beyond the explicitly constructed kernel variables is required for (19).

For $N$ independent repetitions of this entire law, with **every event predicate evaluated correctly**, write $\overline X_N=N^{-1}\sum_{j=1}^N X_j$. For any $e>0$,
\[
 P\{|\overline X_N-D/M|\ge e\}
 \le2\exp\left[-\frac{2Ne^2}{(1+2n\log2)^2}\right].       \tag{20}
\]
To verify the constant directly, a variable supported on an interval of width $R$ has tilted variance at most $R^2/4$. The logarithmic moment generating function of its centered version therefore has second derivative at most $R^2/4$ and initial value and derivative zero. Integration gives the bound $t^2R^2/8$. Independence between trials and Markov's inequality, optimized at $t=4e/R^2$, give each one-sided exponent $-2Ne^2/R^2$. Apply this to both signs with $R=1+2n\log2$.

Thus confidence $1-\delta$ and additive error $e$ are guaranteed by
\[
 N\ge\frac{(1+2n\log2)^2}{2e^2}\log\frac2\delta.          \tag{21}
\]
At $e=c\sqrt n$ with fixed $c>0$, this is $O(n\log(1/\delta))$. This is a bound on the number of independent trials, not on the computational cost of evaluating one original selector and all its gates. It assumes an exact source sampler, which need not be algorithmically available for an arbitrary abstract $L^1$ input.

There is also a useful coverage implication of the same identity:
\[
 P\{\chi_A(X_f,L)=1\}
 \ge\frac{D/M-1}{n\log2}.                               \tag{22}
\]
The bound is trivial if its right side is negative. It follows by dropping the nonnegative bulk occupancy and using $a/M\le1$. Consequently a genuinely high-burden event cannot have exponentially small face-occupancy probability under this exact source-based reference law. This does not say that an arbitrary receiver Haar proposal sees the same probability, nor that source-conditional sampling and gate evaluation are cheap.

If anchor membership is certified outside an UNKNOWN event $U_0$ and the two stopped endpoints are certified outside $U$, set both unavailable contributions to zero. With target masses $\eta_0=P(U_0)$ and $\eta=P(U)$, the resulting estimator $\widehat X$ satisfies
\[
 |\mathbb E\widehat X-D/M|\le\eta_0+n\log2\,\eta.          \tag{23}
\]
For direct iid $P$ draws, $\widehat X$ has the same range as $X$. Therefore (20) remains a confidence statement around $\mathbb E\widehat X$, and a confidence interval for $D/M$ must be enlarged by the proved allowance in (23). Unknown masses themselves need certified bounds; they are not set to zero because a solver returned no witness. With importance sampling, (23) uses the weighted target masses from (16), and a concentration statement must use the actual range or variance of the weighted estimator. Formula (20) is not silently reused for a differently weighted law.

For the principal formulation, one must be able to sample **exactly** from $\mu|_S/M$ and evaluate genuine membership in $A_s$, with the original selector and all original gates. These oracles are not presently provided by the numerical work. With the whole original source sampler $Y\sim\mu/W$, the same construction measures the genuine whole-set burden $\lambda|A|/W$ for a specified measurable receiver event. It is not an optimized Hall-capacity or unknown-principal-cut certificate. This is a useful measurement repair with explicit qualification requirements, not a theorem improving (2). It has not been presented as an executed, fully certified physical experiment in this component.

## 6. What remains and what would be a meaningful repair

The exact positive rank couplings (6) preserve actual demand, source support and all retained capture relations. Their scalar first-prefix upper bound nevertheless loses the same linear outer-shell fee as the canonical flow. To make this route quantitative one needs a bound on the **actual joint rank-resolved columns** in (8), or a demonstrated input-dependent allocation that controls their source peaks. Rowwise uniform ranks alone, a formal independent-rank model, and arbitrary finer source labels do not supply that bound.

The numerical observable (13) keeps the original signed face/interior correlation and reports its unknown mass in the correct law. It is a concrete weaker measurement target, not a new hypothesis claimed to solve (2). Neither a universal rank weight nor a paid subdivision of every principal cut has been obtained here. The component therefore does not meet the round's general-geometric-gain success criterion; the root-order Hall target remains open.

## 7. Verification record

Both independent auditors received the exact target, allowed retained tools, original-input quantifiers and known strong failures before proof drafting. They separately blind-checked the radial probability transform, actual rank coupling, sharp scalar-envelope obstruction, coupled-observable error budget and bounded estimator. Both then completed formal full mathematical reads of this MD file and the matching TeX, including §5.1: PASS. The independent Sol guard completed 210 coverage-specific assertions: 189 rank/envelope assertions and 21 paired-observable assertions. These are generic algebra checks, not actual input or gate certificates; the bounded-estimator addendum was independently proved and reviewed, not presented as an executed physical sampling experiment.

Pressure stages are: pilot normalized rank weights and exact same-law face/bulk marginals; concentrated rank weights and null-set representatives as a known-obstruction test; arbitrary $L^1$ radial CDFs with gaps, unbounded rank weights, source-closed subcuts, expanded dimensions and defensive proposals. The analytic proofs cover these stated ranges. Any generic arithmetic guard is separate from physical gate certification, and no unrun numerical experiment is claimed.

Both numerical owners received (13) and its original-gate, principal-source and likelihood conditions before an order choice. The fixed-source owner reported that no shared qualified captured incidences were yet available when the observable was assigned, and did not add a separate rank-bin scan. Final numerical results belong to their separate reports; this note uses none as a theorem premise.

The current D01 and G03 skill, method and cube-interface files were read. We use an explicit static positive coupling, not vector transport, a source martingale or an undefined directional tree. The H05 skill, method and cube interface were read for the direct bounded-mgf proof, with independence imposed only between actual trials. The F01 skill and cube interface were checked when considering a two-sample rank representation; no unnamed winner theorem or external geometric-mean bound is imported. No Git or PDF compilation was performed.

## 1. Scope and the actual recursion

This note proves a new geometric restriction on the actual high-burden recursion. It does not prove a root-order weak estimate. The results are (i) an exact annular identity, (ii) automatic compact support of every filtered source and necessary coordinate atoms in any persistent high-burden weak limit, and (iii) a finite-epoch fee and terminal bound under an explicit normalized marginal anti-concentration modulus. No new homogeneous mass potential is used.

Let n≥2, H=1+n log 2, theta=log⁻²(n+2), alpha=epsilon=1/[10 log(n+2)], c=1−alpha−epsilon, delta=1/2, and beta=c/2. Thus c>0.85. All cubes Q(x,L) are centered, closed, and have full side L∈[1,2]. Their boundary has zero mass for each current positive L1 source.

At stage i the source is mu_i=f_i dy, with finite positive mass W_i, and lambda_i=beta^i lambda_0. Recompute every original gate and earliest selector for this input and threshold: the anchor, the entire original smooth upper window, the middle lower gate, a strict later hard witness, and any separately retained original kappa layer. Remove the paid coarse-high branch at theta, the dominant-packet branch, and the once-paid physical collision/entropy union. The resulting WHOLE event is

    Fnew_i = Fdiff_i ∩ {C_h*<3/4, Hbar_h*>sqrt(n)}.

Here Fdiff_i is the original coarse-low middle event after dominant-packet deletion. It uses the unchanged current original selector. The packet grid is h0=1/(16n²), a=n^(−p) for fixed p>0, and rho_packet=n^(−1/2); h*=1/(16n^(3/2)). Every source restriction changes the packet masses, posterior, collision and mean shifted-grid entropy, which must all be recomputed. No gate is inherited merely by restricting a source. The current receiver subset B_i⊂Fnew_i is measurable; B_{i+1}⊂B_i. The whole events Fnew_i need not be nested.

Write L_i(x) for the actual first contact and Q_i(x)=Q(x,L_i(x)). Thus mu_i(Q_i(x))=lambda_i L_i(x)^n. The captured-stop kernel satisfies

    0≤k_i(x,y)≤L_i(x)^(−n) 1_Qi(x)(y),
    c lambda_i < d_i(x):=∫k_i(x,y)dmu_i(y)≤(1−epsilon)lambda_i.

Set q_i(y)=∫_Bi k_i(x,y)dx, fix K>0, let S_i={q_i>K}, and set mu_{i+1}=mu_i|S_i. Only rows whose stopped mass fraction in S_i exceeds delta proceed to the next input; after fresh branch classification they form B_{i+1}. In particular their old cube is a strict witness at lambda_{i+1}=beta lambda_i. The new anchor and first-contact property imply

    L_{i+1}(x)<L_i(x),   Q_{i+1}(x)⊂Q_i(x),   x∈B_{i+1}.       (1)

This nesting is specific to this actual bad-source recursion.

Define

    b_i(y)=∫_Bi L_i(x)^(−n)1_Qi(x)(y)dx,   0≤q_i≤b_i≤H,
    D_i=lambda_i |B_i|=∫b_i dmu_i,   R_i=D_i/W_i,
    t_i=beta^(−i),   rho_i=W_{i+1}/W_i,   s_i=|B_{i+1}|/|B_i|,
    C_i=∫_Bi L_i^(−n)mu_{i+1}(Q_i)dx,   p_i=C_i/D_i.

All claims involving ratios assume the corresponding masses are positive. A zero receiver or source ends that branch. We use V=|B_0| and D_0=lambda_0 V, not the same symbol for a receiver set and a scalar. Two elementary bounds will matter:

    R_i≤H,   R_i≤|B_i|,   p_i>c−(K/R_i)(1−rho_i).             (2)

The second follows from lambda_i=mu_i(Q_i)/L_i^n≤W_i. For the third, integrate q_i: cD_i<∫q_i≤C_i+K(W_i−W_{i+1}). In particular R_i≥8K/c implies p_i≥7c/8. These statements concern current B_i; no normalized variance is transferred from the whole event to a subset.

## 2. Exact annular mass and actual radius progress

For a positive child define

    A_i=∫_B(i+1) L_i^(−n)mu_{i+1}(Q_i\Q_{i+1})dx,
    J_i=∫_B(i+1) (L_{i+1}^(−n)−L_i^(−n))mu_{i+1}(Q_{i+1})dx,
    Drop_i=∫_(Bi\B(i+1)) L_i^(−n)mu_{i+1}(Q_i)dx.

Then J_i≥0, Drop_i≤(1−s_i)D_i, and

    C_i=Drop_i+D_{i+1}−J_i+A_i,
    A_i≥D_i[p_i−beta s_i−(1−s_i)].                           (3)

Indeed split the old cube into its child cube and the annulus on each surviving row. The old-kernel integral over the child cube equals D_{i+1}−J_i. On dropped rows mu_{i+1}≤mu_i gives the asserted bound by the old contact lambda_i. This proves (3) without replacing any selector.

Suppose at this stage

    R_i≥R_*≥8K/c,   s_i≥1−c/16,   rho_i≤3c/4.                (4)

Then

    A_i≥(5c/16)D_i,   A_i/W_{i+1}≥5R_i/12≥5R_*/12.         (5)

For the first inequality substitute p_i≥7c/8 and beta=c/2 in (3); the resulting bound is in fact 5c/16+c²/32. For the second divide by W_{i+1}=rho_i D_i/R_i.

For h>0 let E_i(h)={x∈B_{i+1}: log(L_i/L_{i+1})≥h}. Every annular row contributes at most lambda_i. Therefore (5) gives this genuine geometric alternative: either |E_i(h)|≥5c|B_i|/32, or the rows with log-radius drop less than h contribute at least 5cD_i/32 to A_i. In the latter case a definite source mass is captured in thin cube annuli.

For any finite set I of stages, nesting gives the exact demand-priced budget

    Σ_(i∈I) lambda_0 |E_i(h)| ≤ (log 2/h)D_0.               (6)

For a fixed original receiver x, its continuing logarithmic radius drops sum to at most log 2. Integrate their indicators with lambda_0 dx. Equation (6) is priced in D_0, not W_0; it is not a root-order source bound.

## 3. Automatic tightness and a necessary concentration theorem

The filtered sources are automatically supported in one bounded set, even if f_0 is not compactly supported. Indeed

    q_i(y)≤|B_0∩Q(y,2)|.                                    (7)

The kernel is at most one, the old side is at most two, and B_i⊂B_0. The right side tends uniformly to zero as |y|→∞: choose a bounded box outside which B_0 has volume less than K; sufficiently far translates of Q(0,2) lie outside that box. Thus every S_i lies in one bounded set depending only on B_0 and K. Since |B_0|≤HW_0/lambda_0<∞, this argument applies to all stages. The closure is compact, so the normalized child sources pi_{i+1}=mu_{i+1}/W_{i+1} have weakly convergent subsequences whenever they have positive mass.

**Necessary coordinate concentration.** Suppose the actual recursion has infinitely many positive stages and there exist indices i_k→∞ such that

    R_{i_k}≥R_*≥8K/c,   rho_{i_k}≤3c/4.                    (8)

Every weak subsequential limit nu of the normalized CHILD sources pi_{i_k+1} satisfies

    ∫ [∫_B∞ L_∞(x)^(−n)1_∂Q∞(x)(y)dx] dnu(y)≥5R_*/12,
    Σ_(j=1)^n atom(nu_j) ≥ 5R_*/(12 log 2).                 (9)

Here B_∞=∩_i B_i, L_∞ is the decreasing limit on B_∞, Q_∞=Q(x,L_∞), nu_j is the j-th coordinate marginal, and atom(nu_j) is the total mass of its atomic part. It is not the size of its largest atom.

Proof. Since R_i≤|B_i|, (8) and nesting imply |B_∞|≥R_*>0. Finite-measure continuity from above gives |B_i|→|B_∞| and hence s_i→1. Thus (4) holds at all sufficiently late i_k. On B_∞ the measurable radii decrease to a measurable limit in [1,2].

Put a_i(y)=∫_B(i+1) L_i^(−n)1_(Qi\Q(i+1))(y)dx. For fixed m define

    F_m(y)=∫_B∞ L_∞(x)^(−n)
                   1_(Q_m(x)\int Q_∞(x))(y)dx.

For every fixed x the set in the indicator is closed. The integrand is bounded by one and |B_∞|<∞. Reverse Fatou therefore proves that F_m is bounded and upper semicontinuous in y; no continuity of x↦L_i(x) is assumed. For i≥m, nesting and L_i^(−n)≤L_∞^(−n) give the pointwise bound

    a_i(y)≤|B_{m+1}\B_∞|+F_m(y).

Pass to a weakly convergent child-source subsequence and apply Portmanteau for this FIXED m. Together with (5),

    5R_*/12 ≤ |B_{m+1}\B_∞|+∫F_m dnu.

Only now send m→∞. The first term vanishes, and F_m decreases boundedly to the boundary column in (9), because Q_m decreases to Q_∞. This proves the first line. The order of these two limits is essential; weak source convergence and pointwise selector convergence are never multiplied directly.

For the second line let F_j(y) be the column of the two j-coordinate faces of Q_∞. Fix y. On a j-face, L_∞(x)=2|x_j−y_j|, with 1/2≤|x_j−y_j|≤1. Ignoring all restrictions on x except the other n−1 cube coordinates yields

    F_j(y)≤2∫_(1/2)^1 (2r)^(−n)(2r)^(n−1)dr=log 2.

This estimate is valid for an arbitrary measurable selector. Let T_j be the countable atom set of nu_j. The restriction of nu to {y:y_j∉T_j} gives zero mass to either j-face of every fixed receiver cube. Tonelli eliminates that contribution. On {y:y_j∈T_j}, use F_j≤log 2; hence ∫F_j dnu≤(log 2)atom(nu_j). The cube boundary is covered by these n face pairs, proving (9).

This is a necessary concentration result, not a contradiction. Coordinate-atomic weak limits can occur even though each pi_i has an L1 density. A single source point can lie on boundaries of many selected cubes. The theorem does not preserve the original smooth/middle/coarse/physical gates in the limit, nor assert that the limiting source has an L1 density. The unnormalized mu_i may converge to zero. If all normalized child-source cluster points have atomless coordinate marginals, then (8) cannot occur; this qualitative corollary alone gives no uniform stopping time or fee bound.

## 4. A quantitative finite-epoch correction with its terminal paid

Here is a primitive additional regularity condition that converts thin-annulus concentration into a finite geometric budget. It is not assumed for arbitrary input.

Let I be any finite set of stages satisfying (4), V=|B_0|>0, and 0<h≤log 2. Define the normalized child-source marginal modulus

    Omega_I(h)=sup_(i∈I) Σ_(j=1)^n sup_(z∈R)
                    pi_{i+1}{y:|y_j−z|≤h}.

If

    Omega_I(h)≤5R_*/(48V),                                 (10)

then

    Σ_(i∈I)t_iD_i≤32(log 2)D_0/(5c h).                     (11)

Proof. On a row with log(L_i/L_{i+1})<h, each removed half-side width is
(L_i−L_{i+1})/2≤1−e^(−h)≤h. The annulus lies in two coordinate slabs per coordinate, each contained in a slab of radius h. Its pi_{i+1} mass is at most 2Omega_I(h). Since L_i^(−n)≤1, all such rows contribute at most 2V Omega_I(h)W_{i+1} to A_i. By (10), rho_i≤3c/4 and R_i≥R_*, this is at most 5cD_i/32. Equation (5) leaves at least 5cD_i/32 on E_i(h). Each row contributes at most lambda_i, so |E_i(h)|≥5c|B_i|/32. Now (6) proves (11).

For explicit fees, suppose every stage i of a complete epoch 0,…,m−1, m≥1, satisfies (4) and (10). Let A_max bound the current paid-branch coefficient, and G_max bound the good-row coefficient. Then

    Σ_(i<m)t_i[A_i^fee W_i+G_i^fee(W_i−W_{i+1})]
      ≤32(A_max+G_max)(log 2)D_0/(5c h R_*),
    Ht_mW_m≤3H D_0/(2R_*).                                (12)

The first follows from t_iW_i=t_iD_i/R_i. For the terminal, rho_{m−1}/beta≤3/2 and t_{m−1}D_{m−1}=lambda_0|B_{m−1}|≤D_0. Thus t_mW_m≤(3/2)D_0/R_*. This terminal is actually included, not discarded. Moreover each term t_iD_i≥lambda_0R_*; (11) bounds the epoch length by 32V log 2/(5c h R_*).

If I is only a subset of stages, (11) pays only those stages. All omitted stages and the final Ht_mW_m must remain in the ledger. For m=0 the original terminal is HW_0. Since D_0≤HW_0, (12) is a finite source-mass bound with explicit dependence on h and R_*. It is generally worse than the retained general baseline and does not establish root order.

Condition (10) has genuine geometric content: it concerns normalized one-coordinate source concentration on a physical length scale. Individual absolute continuity gives Omega_i(h)→0 at each fixed stage, but f_i≤f_0 does not give a uniform normalized modulus when W_i shrinks. Equation (9) identifies a necessary way that such uniform control can fail along the actual high-burden band. An estimate that pays this concentration, or quantitatively exits that band, is still missing.

## 5. Whole-event fee ledger and remaining scope

For clarity the retained coefficients at every newly classified input are

    B_base=4+2(log 2)sqrt(7n/3),   B_ext=2H/sqrt(n+2),
    T_soft=1+(log 2)min(2n,sqrt(n[theta^(−1)+4theta/3])),
    P_dom=[5+3log(1/a)]/rho_packet,
    E_*=exp(nh*),   B_*=1+E_*[1+(2n²+n)h*],
    P_phys=2[E_*+B_*+2(1+E_*)sqrt(n)],
    A_i^fee=B_base+B_ext+T_soft/alpha+P_dom+P_phys,
    G_i^fee=K/[c(1−delta)]=2K/c.

Add any separately used deletion fee; none is introduced here. P_phys pays the physical collision/entropy UNION once, not once per component. For fixed p, A_i^fee=O_p(sqrt(n)log²(n+2)). If E_init is the preclassification receiver event, the actual finite recursion retains

    lambda_0|E_init|≤Σ_(i<m)t_i[A_i^fee W_i
                  +G_i^fee(W_i−W_{i+1})]+Ht_mW_m.          (13)

Repeated branch charges use the current W_i, including repeated source mass. This is a weak receiver fee statement; no original Hall allocation is asserted by adding freshly reselected paid rows. The initial B_0 in (3)–(12) is the residual after stage-zero classification. Positive complete epochs in (12) pay the right side of (13) explicitly; the zero-residual case is already paid by the stage-zero branches. Return to the all-scale theorem still costs the retained C_loc log(n+2); proofs summed separately over original kappa layers also pay the number of layers O(log n).

Neither (9) nor (10) bounds the whole-Fnew radial forcing from previous rounds. The present proof never invokes variance subset monotonicity or replaces whole Fnew by B_i in a full-event hypothesis. It yields an actual geometric concentration necessity and a regularity-qualified finite fee bound. A uniform root-order payment for coordinate concentration, intervening stages and the final terminal is not proved. The general retained bound remains O(n log n).

## 6. Three-stage validation and qualification

Pilot: the actual contact split (3), the constants (5), and the original-demand radius budget (6) were independently checked before either auditor read this proof.

Obstruction pressure: narrowing annuli do not contradict positive mass; normalized sources may converge to singular measures. The proof therefore uses a common bounded support, persistent receiver set, fixed-m upper semicontinuity and then Portmanteau, and records coordinate-atomic concentration instead of falsely inheriting gates or absolute continuity. No artificial repeated chain is claimed to be a physical high-load example.

Expansion: the proofs cover arbitrary measurable original selectors, noncompact initial L1 sources, all finite subsets of an actual chain, complete finite epochs with explicit terminal, and every weak child-source cluster point under (8). This is analytic parameter expansion, not a numerical experiment. Numerical authors were given the actual annular A_i, J_i, Drop_i, log-radius distribution and normalized marginal concentration observables. At writing they had no certified high-q child in a qualified physical input; no numerical confirmation of (8) or general capacity is claimed. Actual construction recipes are absent from this public text.

The general cube weak bound of order $\sqrt n\,n^{o(1)}$ remains **UNPROVED**. This note constructs one genuine positive convolution semigroup, with a single generator for every cube scale, and compares cubes to its ergodic averages. The elementary comparison costs $O(n\log n)$. A stronger whole-law corner estimate, proved below rather than inferred from the elementary certificate, rules out root-order pointwise cube majorization by any positive time mixture of this particular semigroup family. This is a kernel-comparison obstruction, not a lower bound for the cube maximal operator or for every Markov approach.

## 1. A single positive family and its clock

Use cube radius $r$, not full side: $U_r(x)=(2r)^{-n}1_{[-r,r]^n}(x)$. Fix $n\ge1$ and $0<\alpha<1$. On time, radius and uniform marks take a Poisson random measure with intensity
\[
 dt\,\alpha R^{-1-\alpha}dR\,dv,
 \qquad R>0,\quad v\in[-1,1]^n,
\]
where $dv$ is normalized uniform probability on the unit-radius cube. A mark contributes the vector $Rv$. For each finite time interval, the sum of radii at most one has finite expectation $t\alpha/(1-\alpha)$, hence is finite almost surely. There are finitely many radii greater than one almost surely; their expectation need not be finite, and no finite expectation for their total size is used. Thus the sum of all jump vectors is absolutely convergent almost surely. Denote it by $Z_t$ and its probability law by $p_t$.

Independent stationary Poisson increments give a single convolution semigroup. For $f\in L^1$, set $P_tf=p_t*f$. These are positive contractions on $L^1$ and $L^\infty$, preserve constants and Lebesgue integrals, and are symmetric. They are strongly continuous on $L^1$: truncating jumps above a fixed small radius gives a finite-rate process, while the expected sum below that cutoff controls its small-jump displacement; this proves $Z_t\to0$ in probability as $t\downarrow0$, and $L^1$ translation continuity finishes the argument.

For bounded Lipschitz test functions, the generator is
\[
 \mathcal Gg(x)=\int_0^\infty\alpha R^{-1-\alpha}
                         (U_R*g(x)-g(x))\,dR.
 \tag{1}
\]
The small-radius integral converges by the Lipschitz bound and $\alpha<1$, while the large-radius integral converges by boundedness and $\alpha>0$. This generator depends on $n,\alpha$, not on the cube radius being compared. Scaling Poisson radii gives $Z_t\stackrel{\rm law}=t^{1/\alpha}Z_1$. With Fourier convention $e^{-ix\cdot\xi}$,
\[
 \widehat p_t(\xi)=e^{-t\psi(\xi)},\qquad
 \psi(\xi)=\int_0^\infty\alpha R^{-1-\alpha}
       \left(1-\prod_{i=1}^n\operatorname{sinc}(R\xi_i)\right)dR\ge0.
 \tag{2}
\]
Here $\operatorname{sinc}(0)=1$. The integrand is nonnegative; near zero it is $O(R^2|\xi|^2)$, and at infinity it is bounded. Thus this family has a legitimate nonnegative Fourier multiplier and does not make the R88 negative-multiplier substitution for $\Psi$.

The weak endpoint used here concerns the **ergodic averages**
\[
 \mathcal A_Tf=\frac1T\int_0^T P_tf\,dt,
 \qquad \left|\left\{x:\sup_{T>0}\mathcal A_Tf(x)>a\right\}\right|
                  \le\frac{\|f\|_1}{a},\quad f\ge0.
 \tag{3}
\]
Equation (3) follows from the complete independent proof in this round's sources, Proposition E1: finite-measure Hopf recursion, exact positive periodization, strong-$L^1$ limits at finite rational-time lists, and a common almost-everywhere locally time-integrable version. The semigroup constructed above satisfies every premise. This proof has been read directly; the endpoint is not inferred merely from a theorem name. No weak endpoint for $\sup_tP_tf$ is asserted. The pointwise kernel comparisons and the obstruction below do not require (3).

## 2. An all-scale one-large-jump comparison

Fix $r>0$, $\delta>0$ and
\[
 0<\kappa\le\frac{1-\alpha}{2\alpha},\qquad
 T=\kappa\delta^\alpha r^\alpha.
 \tag{4}
\]
Split the process into radii at most $\delta r$ and radii above that cutoff. At time $0<t\le T$, the expected sum of the smaller radii is
\[
 \frac{t\alpha}{1-\alpha}(\delta r)^{1-\alpha}.
\]
Markov's inequality shows that their total displacement in the infinity norm is at most $\delta r$ with probability at least $1/2$. Independently, exactly one jump above $\delta r$ has radius intensity
\[
       t e^{-t(\delta r)^{-\alpha}}\alpha R^{-1-\alpha}dR.
\]
For every $x\in[-r,r]^n$ and every smaller-jump displacement of infinity norm at most $\delta r$, a single uniform jump of radius $R\ge(1+\delta)r$ contributes density $(2R)^{-n}$ at $x$. Retaining this event yields, as positive measures,
\[
 p_t\ge\frac t2e^{-\kappa}
       \frac{\alpha}{2^n(n+\alpha)((1+\delta)r)^{n+\alpha}}
       1_{[-r,r]^n}dx.
\]
Averaging $t$ from zero to $T$ gives
\[
 U_r\le C_{n,\alpha,\delta,\kappa}\,a_T,
 \qquad a_T=\frac1T\int_0^T p_tdt,
 \qquad
 C_{n,\alpha,\delta,\kappa}
 =\frac{4e^\kappa(n+\alpha)(1+\delta)^{n+\alpha}}
           {\kappa\alpha\delta^\alpha}.
 \tag{5}
\]
The clock (4) ranges over every $T>0$ as $r$ ranges over every positive radius. Consequently (3) gives the all-scale cube weak bound with this same coefficient. No scale discretization, extra union bound or scale-dependent generator is hidden in (5).

The expression in (5) is minimized in $\delta$ at $\delta=\alpha/n$. Since $e^\kappa/\kappa\ge e$ and
\[
 \frac{(1+\alpha/n)^{n+\alpha}}{(\alpha/n)^\alpha}
                 \ge n^\alpha,
\]
its cost satisfies, for $n\ge2$,
\[
 C_{n,\alpha,\delta,\kappa}
       \ge4en\frac{e^{\alpha\log n}}\alpha
       \ge4e^2n\log n.
 \tag{6}
\]
The second inequality follows by minimizing $e^{a\log n}/a$ over all $a>0$; allowing that larger parameter range only lowers the minimum. Conversely, choose $\alpha=(3+\log n)^{-1}$, $\kappa=1$ and $\delta=\alpha/n$. These parameters satisfy (4) for every $n\ge1$, and the exact expression (5) is at most $8e^{4+1/e}n(3+\log n)$. Indeed $(1+\alpha/n)^{n+\alpha}\le e^2$, $n^\alpha\le e$, $\alpha^{-\alpha}\le e^{1/e}$ and $n+\alpha\le2n$. Thus this certificate reproduces linear-logarithmic order. Equation (6) is a lower bound for the displayed certificate cost, not for the true optimal comparison with the complete law.

## 3. Quantitative stability for sums of uniform variables

The following elementary stability lemma is proved here; no unverified general near-extremizer theorem is used. Let $(R_j)$ be a nonempty finite or countable sequence of positive radii with $\sum_jR_j<\infty$. Let $X=\sum_jX_j$, where the $X_j$ are independent and uniform on $[-R_j,R_j]$. Write $M=\max_jR_j$, and let $g$ be the canonical symmetric nonincreasing density of $X$. If $r>0$, $0<\epsilon\le e^{-20}$ and $2rg(r)\ge1-\epsilon$, then
\[
 1-3000\epsilon\log^2(1/\epsilon)
       \le\frac Mr\le1+2\epsilon.
 \tag{7}
\]

We first specify the density and all countable limits. Summability implies that the positive maximum radius is attained. Separate a largest summand and call the remaining sum $Y$. Then
\[
 g(x)=\frac1{2M}\Pr\{Y\in[x-M,x+M]\}.
 \tag{8}
\]
If there is only one summand, use the closed-interval representative of its uniform density. If there is another summand, $Y$ has an atomless law, since it contains an independent uniform summand. In that case (8) is continuous and gives the convolution density everywhere. Finite convolutions of centered uniform densities are symmetric and nonincreasing on the positive axis: a symmetric nonincreasing density is a positive mixture of centered uniform densities by its level sets, and the convolution of two centered uniform densities has this same property. For countably many summands, finite remaining sums converge almost surely, and the atomless boundary condition in (8) passes their interval probabilities to the limit. Thus the canonical $g$ has the claimed symmetry and monotonicity, including $g\le(2M)^{-1}$. Also $|X|\le\sum_jR_j$ deterministically, so finite-sum moments and moment-generating functions pass to the limit by dominated convergence.

By scaling it is enough to prove (7) for $r=1$. Set $L=\log(1/\epsilon)\ge20$. The hypothesis and monotonicity give
\[
 \Pr\{|X|>1\}\le\epsilon,
 \qquad \|g-U_1^{(1)}\|_1\le2\epsilon,
 \qquad M\le(1-\epsilon)^{-1}\le1+2\epsilon,
 \tag{9}
\]
where $U_1^{(1)}=\tfrac12 1_{[-1,1]}$. Indeed the density on $[-1,1]$ is at least $(1-\epsilon)/2$, so the negative part of $g-U_1^{(1)}$ has integral at most $\epsilon$; equality of total masses gives the displayed $L^1$ bound.

Put $v=\mathbb E X^2$, $A=\sum_jR_j^2$ and $B=\sum_jR_j^4$. Independence and symmetry give
\[
 A=3v,\qquad
 \mathbb EX^4=\frac{A^2}{3}-\frac{2B}{15}\le3v^2.
 \tag{10}
\]
If $v\ge2$, then $\mathbb E[X^2 1_{|X|>1}]\ge v-1$. Cauchy--Schwarz and (10) imply
\[
 \Pr\{|X|>1\}\ge\frac{(v-1)^2}{\mathbb EX^4}
                         \ge\frac1{12},
\]
contradicting (9). Hence $v<2$ and $A<6$.

For real $z$, the coefficient inequality $(2k+1)!\ge6^k k!$ gives $\sinh(z)/z\le e^{z^2/6}$. It follows first for finite sums and then for the countable sum that
\[
 \mathbb E e^{sX}\le e^{s^2 A/6}=e^{s^2v/2},
 \qquad \Pr\{|X|>u\}\le2e^{-u^2/4}.
 \tag{11}
\]
The factorial inequality follows by induction, since $(2k+3)(2k+2)\ge6(k+1)$. Optimizing the exponential Markov inequality yields the tail bound, using $v<2$.

Truncate the second and fourth moments at $R=2\sqrt L$. The truncated moment difference from $U_1^{(1)}$ is bounded by $2\epsilon R^k$ for $k=2,4$, by (9). The uniform reference has no tail beyond $R$. For the other tail use
\[
 \mathbb E[|X|^k1_{|X|>R}]
 =R^k\Pr\{|X|>R\}+\int_R^\infty k u^{k-1}\Pr\{|X|>u\}\,du.
\]
With (11), the second moment tail is at most $8\epsilon L+8\epsilon$, and the fourth moment tail is at most $32\epsilon L^2+64\epsilon(L+1)$. Therefore
\[
 |v-\tfrac13|\le24\epsilon L,
 \qquad |\mathbb EX^4-\tfrac15|\le192\epsilon L^2,
 \qquad |A-1|\le72\epsilon L.
 \tag{12}
\]
Since $A<6$, we have $|A^2-1|\le7|A-1|$. Solving (10) for $B$ now gives
\[
 |B-1|
 \le\tfrac52(504\epsilon L)+\tfrac{15}2(192\epsilon L^2)
 \le2700\epsilon L^2.
\]
The inequality $B\le M^2A$ yields
\[
 M^2\ge\frac{1-2700\epsilon L^2}{1+72\epsilon L}
                  \ge1-2772\epsilon L^2.
\]
All displayed numerators are positive: $\epsilon L^2\le400e^{-20}$ on this range, and $3000\cdot400e^{-20}<1/2$. For example $e^{20}>20^{10}/10!>2400000$ proves the latter strictly without a decimal approximation. Finally $\sqrt{1-d}\ge1-d$ for $0\le d\le1$ proves the lower bound in (7).

## 4. A whole-law obstruction for this entire semigroup family

At every $t>0$, condition on the full collection of Poisson radii. Their sum is finite almost surely, as already established. Conditional on those radii, the coordinates of the jump marks are independent, so the coordinates of $Z_t$ are independent copies of the one-dimensional sum in Section 3. This conditional independence belongs to the constructed averaging kernel; no independence of coordinates of an input function or physical captured source is being assumed. By Tonelli a canonical density of $p_t$ is
\[
 p_t(x)=\mathbb E\!\left[\prod_{i=1}^n g_{\mathcal R}(x_i)\right].
 \tag{13}
\]
The Poisson collection has infinitely many small radii almost surely. Thus the countable density convention above applies, and all conditional moment and density limits have already been justified.

The largest Poisson radius $M_t$ has distribution
\[
 \Pr\{M_t\le u\}=e^{-t u^{-\alpha}},\qquad u>0.
\]
The density of $\log M_t$ is $\alpha t u^{-\alpha}e^{-t u^{-\alpha}}\le\alpha/e$, uniformly in $t$ and $u$. For a fixed $r>0$, write $q=2r g_{\mathcal R}(r)$. Symmetric monotonicity and mass one give $0\le q\le1$. By (7), for $0<\epsilon\le\epsilon_0:=e^{-20}$ the event $q\ge1-\epsilon$ forces
\[
 M_t/r\in[1-\eta,1+2\epsilon],\qquad
 \eta=3000\epsilon\log^2(1/\epsilon)<\tfrac12.
\]
The logarithmic length of this interval is at most
$2\epsilon+2\eta\le6002\epsilon\log^2(1/\epsilon)$. Consequently
\[
 \Pr\{q\ge1-\epsilon\}
          \le10000\alpha\epsilon\log^2(1/\epsilon),
          \qquad 0<\epsilon\le\epsilon_0.
 \tag{14}
\]
The constants are deliberately loose. This estimate uses the complete jump law, including all configurations, rather than retaining only a one-large-jump event.

Layer cake and (14) give
\[
 \begin{split}
 (2r)^n p_t(r\mathbf1)=\mathbb E q^n
 &\le10000\alpha n\int_0^1
       \epsilon\log^2(1/\epsilon)(1-\epsilon)^{n-1}\,d\epsilon
       +(1-\epsilon_0)^n
 \end{split}
\]
Since $\mathbb E q^n\le1$, this implies
\[
\mathbb E q^n\le\theta_{n,\alpha}:=
 \min\!\left\{1,
 \frac{10000\alpha(\log^2(n+1)+1)}{n+1}
             +(1-e^{-20})^n\right\}.
 \tag{15}
\]
Here the exact beta integral is
\[
 n\int_0^1\epsilon\log^2(1/\epsilon)(1-\epsilon)^{n-1}\,d\epsilon
 =\frac{(H_{n+1}-1)^2+H_{n+1}^{(2)}-1}{n+1}.
 \tag{16}
\]
To verify it directly, differentiate twice at $a=2$ the identity
$\int_0^1 x^{a-1}(1-x)^{n-1}dx=(n-1)!/[a(a+1)\cdots(a+n-1)]$; logarithmic differentiation gives the two harmonic sums. The bounds $H_{n+1}-1\le\log(n+1)$ and $H_{n+1}^{(2)}-1\le1$ follow by integral comparison. The integral identity can alternatively be proved by expanding $(1-x)^{n-1}$, giving a finite rational sum.

Let $\rho$ be any probability measure on positive times, and let $h=\int p_t\,\rho(dt)$. The mixing law may depend arbitrarily on the radius being compared. If the measure majorization $U_r\,dx\le C h\,dx$ holds, then
\[
 C\ge\theta_{n,\alpha}^{-1}.
 \tag{17}
\]
There is no exceptional-corner inference in this conclusion. For any $0<a<r$ and every $x\in[a,r]^n$, the conditional monotonicity in (13) gives
$h(x)\le(2a)^{-n}\theta_{n,\alpha}$. Comparing the two measures on this positive-volume box gives $C\ge(a/r)^n\theta_{n,\alpha}^{-1}$; let $a\uparrow r$. This also avoids needing continuity of the unconditional or time-averaged density at the corner.

Uniformly for $0<\alpha<1$, including dimension-dependent choices of $\alpha$,
\[
 \theta_{n,\alpha}\le
 \frac{10000(\log^2(n+1)+1)}{n+1}+e^{-e^{-20}n}.
 \tag{18}
\]
Thus every such positive time-mixture pointwise comparison has cost $\Omega(n/\log^2 n)$ as $n\to\infty$. In particular it cannot have cost $O(\sqrt n\,n^{o(1)})$. The statement is asymptotic; the explicit constants and the small $e^{-20}$ cutoff make it intentionally ineffective in many moderate dimensions. It applies to the entire specified cube-jump family and all its clocks and probability time mixtures. It does not assert a weak maximal lower bound, does not rule out signed comparisons or paid error comparisons, and does not rule out other common Markov families. It does not prove any obstruction for the R88 $\Psi$ maximal operator.

## 5. What remains open

The elementary certificate (5) genuinely uses one generator and legal ergodic averages, but it only reproduces $O(n\log n)$. The stronger result (17)--(18) shows that optimizing the complete law or its positive time mixture within this family cannot reach root order. The obstruction is separate from the Fourier-sign obstruction for the R88 $\Psi$ kernel: the present semigroup has nonnegative Fourier transform, yet its cube-corner density has an insufficient uniform lower envelope.

A distinct next target is a paid error comparison or a direct weak estimate for the R88 $\Psi$ maximal family, allowing the corner mismatch to be charged in measure instead of requiring pointwise positive domination. Such an argument must supply an all-scale error budget and its own maximal endpoint; neither kernel positivity nor a separate clock for each scale supplies that budget. No such quantitative budget is proved here. The general desired weak bound therefore remains unproved.

## 6. Verification scope

Both independent auditors prechecked the exact one-jump and whole-law statements before reading their proofs. The author executed 255 exact rational/integer checks in 0.016205 seconds: pilot 84, known-obstruction pressure 154, and expanded parameters 17. The pilot used finite uniform convolutions with two through eight radii and rational perturbations $10^{-12},10^{-16},10^{-20},10^{-30}$, checking the exact near-flat plateau and moment ratios. Pressure checks included equal-radius convolutions, the moment-generating-function factorial coefficients through index 128, and the beta identity by independent alternating-binomial and harmonic-sum evaluations through $n=256$. The expanded stage used $n=2^k$ for $k=64,128,256,512,1024,2048$, so the claimed obstruction was tested where the bound is nonvacuous. Since $e<3$, the exact inequality $2^k\ge3^{20}(k+1)$ implies $e^{-e^{-20}n}\le1/(n+1)$. Also $\log(n+1)\le k+1$, giving the fully rational comparison-cost lower bound $(2^k+1)/[10000((k+1)^2+1)+1]$. This lower bound exceeds $\sqrt n\,(k+1)^2$ in every listed case with $k\ge128$. The independent portable guard and final proof receipts are recorded by the auditors; these author checks are a separate receipt. These tests concern public averaging kernels and exact finite algebra, not qualification of a physical lower-bound input or evidence for a cube maximal lower bound.

## S1. 本轮边界与真正新增接口

保留 R82 全部门、R87 付费分割和 R88 EXACT Fnew 账本；一般正 L1 立方体弱型的根阶目标仍未解决，已保留的一般界为 O(n log n)。本节不给 Hall 容量或跨层 U 新界。新增的是一个完整、维数无关、适用于真实共同概率卷积半群的 Cesàro 端点证明，以及冻结实际概率律之后的精确倾斜接口。二者不能凭半群或鞍点名称绕过立方体比较、事件等价、残余覆盖和全部原门。

阅读 updated64 的 H01、H02、F04 SKILL、method，H02 provenance，以及三个 cube-interface。H02 接口中的非格点局部极限定理是较广泛迁移路线的待证条件；不能强加给下述特定 Niu 缩小截止值定理，也不能从那一定理删除方差及截止值条件。F04 的自伴共同生成元、正谱参数与平方函数接口，不等于平均极大弱型接口。技能来源卡中此前的全文阅读不是本作者本轮全文阅读。

## S2. 概率卷积 Cesàro 平均：常数 1 的独立证明

**命题 E1（本轮独立推导）。** 固定 n。设 P_t 是 R^n 上同一个概率卷积半群，P_0=I、P_sP_t=P_{s+t}，且 t↦P_t 在 L1 强连续。对非负 f∈L1，令

\[
 A_T f=\frac1T\int_0^T P_t f\,dt,
 \qquad M_Af=\sup_{T>0}A_Tf.
\]

采用联合可测时间版本及下面的几乎处处连续平均版本，则对每个 λ>0，

\[
 \lambda\,|\{M_Af>\lambda\}|\le\|f\|_1. \tag{E1}
\]

常数恰为 1；无需对称性、自伴性或维数限制。这里控制的是时间平均，不是 sup_t P_t f。以下给出所需特殊情形的完整证明，不声称已阅读原始 HD-S 论文的证明。

**有限测度 Hopf 步骤。** 在有限测度空间，设 T 正且同时为 L1、L∞ 收缩，T1≤1。给定实 g∈L1，定义 s_k=∑_{j=0}^{k-1}T^jg，u_N=max(0,s_1,…,s_N)，u_0=0，E_N={u_N>0}。正性给出在 E_N 上 u_N≤g+Tu_{N-1}，且 u_N≥u_{N-1}。于是

\[
 \int_{E_N}g\ge\int u_N-\int_{E_N}Tu_{N-1}
 \ge\int u_N-\int Tu_{N-1}
 \ge\int u_N-\int u_{N-1}\ge0.
\]

取 g=f−λ。T^j1≤1，因此若某 k≤N 满足 k^{-1}∑_{j<k}T^jf>λ，则 s_k>0。故该有限平均极大事件包含于 E_N，并且 λ|E_N|≤∫_{E_N}f≤∥f∥1。有限测度步骤完成。对 Markov 算子 T1=1，也得到对应事件恰为 E_N；证明不需要此额外等式。

**σ-有限空间的正周期化，不丢质量。** 给定任一概率卷积算子 Q 及 R>0，在基本盒 C_R=[−R,R)^n 上令

\[
 F_R(x)=\sum_{k\in\mathbb Z^n}f(x+2Rk).
\]

Tonelli 给出 F_R≥0、∫_{C_R}F_R=∥f∥1。把 Q 投影到该环面，得到保均匀测度的 Markov 算子 T_R，且对所有整数 j≥0，几乎处处

\[
 T_R^jF_R(x)=\sum_k(Q^{*j}*f)(x+2Rk)
 \ge (Q^{*j}*f)(x).
\]

有限测度 Hopf 界因此直接控制原空间有限平均极大事件在 C_R 内的 Lebesgue 测度，右端仍为 ∥f∥1。令整数 R↑∞，再令 N↑∞，得到所有离散平均的常数 1 弱型界。正周期化支配足够；无需把原卷积与环面卷积误差估成相等，也无需 f 的紧支撑。

**连续时间与共同空集。** 对有限个正有理 T_1,…,T_m，选择 h_k↓0 使每个 T_j/h_k 为整数。所有离散平均使用同一个算子 P_{h_k}。强 L1 连续性给出 Bochner Riemann 和

\[
 A_{T_j}^{h_k}f=\frac{h_k}{T_j}
 \sum_{\ell=0}^{T_j/h_k-1}P_{\ell h_k}f
 \longrightarrow A_{T_j}f\quad\hbox{in }L^1.
\]

取对该有限列表共同的几乎处处收敛子列；严格 λ 水平事件与 Fatou 给出有限有理时间最大值的常数 1 界。再枚举所有有理 T、取递增有限列表，得到有理时间上确界。强可测性允许联合可测 L1 版本；对每个整数 M，Fubini 给出

\[
 \int\!\int_0^M P_tf(x)\,dt\,dx=M\|f\|_1<\infty.
\]

因而在一个共同的满测集上，t↦P_tf(x) 局部可积，T↦T^{-1}∫_0^T P_tf(x)dt 对 T>0 连续。有理时间上确界等于所有正时间上确界。不能将每个固定 T 的几乎处处结论直接对不可数 T 取并。复数 f 可由 A_T|f| 支配。取集中于零的平凡半群说明端点常数不能小于 1。

## S3. 立方体迁移只需要一个共同钟，但必须先有正测度比较

**命题 E2。** 令 U_r 为半边长 r 的归一化立方体概率测度。若对一个 E1 半群、每个正有理 r，有确定性 T(r)>0 和统一 C<∞ 使

\[
 U_r\le C\,\frac1{T(r)}\int_0^{T(r)}P_t\,dt
 \quad\hbox{as positive measures}, \tag{E2}
\]

则立方体极大算子的弱型常数≤C。证明：逐个有理 r 卷积非负 f，取共同满测集，使用 E1；对固定 x，r↦U_r*f(x) 在 r>0 连续（L1 积分的绝对连续性与立方体边界零 Lebesgue 测度），故有理 r 足够。无需额外时钟上确界费用。P_t 表示其卷积概率测度；时间积分是概率测度的平均。

每个 r 分别找到一个正密度或一个生成元，不给 E2 的共同族。算子相互交换也不自动给 P_sP_t=P_{s+t}。自伴半群需要非负生成元的适当谱指数，而单个立方体 Fourier 乘子可以为负；这不妨碍以立方体为跳跃标记构造另一个合法生成元。必须保留其真实共同生成元、归一化、尺度钟和比较常数。

Alternative 的本轮候选已明确采用一个固定 marked-Poisson 卷积半群与 Cesàro 比较，不是逐尺度冻结生成元；其构造和一跳测度比较由 alternative 负责。本源接口不重复它的证明、不把一跳 O(n log n) 证书称为根阶收益。作者另在 alternative §4 证明该特定整族任意正时间混合的点态比较费用 Ω(n/log²n)，已获独立 MD 审计；这是核比较障碍，不是弱型下界或所有共同 Markov 路线的否定。本源角色的独立证明范围仍为 E1–E5。

若必须用有限个不同的平均极大算子 M_j，各自弱型常数≤1，则安全的通用联合界为

\[
 \lambda|\{\sum_j a_jM_jf>\lambda\}|
 \le\Big(\sum_j\sqrt{a_j}\Big)^2\|f\|_1,
 \qquad a_j\ge0. \tag{E3}
\]

非零 a_j 取 θ_j=√a_j/∑√a，若每个 a_jM_jf≤θ_jλ 则总和≤λ；对事件并集逐项弱型相加即得。这个界不主张最优，也不排除额外结构改进；一般不能未经证明把费用写成 ∑a_j。同一个 M 的重复项则可直接合并为 ∑a_j。

## S4. 原始来源、实际阅读及端点边界

Taggart 作者预印本的 Definition 1.1、Theorems 1.2–1.3（印刷 pp.1–2）与 §4 Theorem 4.1（p.10）已直接浏览。后者对平均给 p>1 强型常数 2(p/(p−1))^{1/p}；前者涉及对称扩散半群的个别算子解析最大值，不能从其 p>1 陈述读出本轮 L1 端点。[Taggart, *Pointwise Convergence for Semigroups in Vector-valued Lp Spaces*, arXiv:0705.4510](https://arxiv.org/pdf/0705.4510)。

该作者版本的上述陈述和平均定义已读；未在本轮重读其全部证明或引用的 Dunford–Schwartz 专著。原始 Dunford–Schwartz 1955 PNAS 与 Stein 1961 PNAS 的在线 PDF 访问遇到 cookie/访问阻碍，未声称读取原始证明；端点常数 1 由 S2 的独立证明承担。此处只用已读作者原文定位平均与个别算子的准确区别，未引入其未读依赖中的端点常数。

## S5. 冻结概率律后的精确倾斜，不依赖尾渐近

**命题 E4（独立恒等式）。** 条件于训练/物理清单 σ-代数 T，冻结一个真实概率律 P、实值可测统计量 S、有限实参数 s，以及

\[
 0<Z=\int e^{sS}\,dP<\infty,
 \qquad \frac{dQ_s}{dP}=\frac{e^{sS}}Z.
\]

对任意可测实际事件 E，

\[
 P(E)=Z\int e^{-sS}\mathbf1_E\,dQ_s. \tag{E4}
\]

证明仅为 Radon–Nikodym 相消，不要求独立坐标、正态近似或鞍点存在。若再取 Q=γP+(1−γ)Q_s，0<γ≤1，则 P≪Q，

\[
 \frac{dP}{dQ}\le\gamma^{-1},
 \qquad P(E)=\int\mathbf1_E\frac{dP}{dQ}\,dQ. \tag{E5}
\]

若取 Q=γQ_0+(1−γ)Q_1 而 Q_0 是参考包络，真实被积量 k 满足 k≤Hq_0，则 k/q≤H/γ；不能把这一被积量包络误写成 k 已是概率密度。没有精确 Z 或精确可采样 Q_s 时，形式倾斜不是执行完成的估计器。

训练选择可以随机，但 holdout 抽样必须条件于 T 从冻结 Q 独立生成；不能用同一 holdout 重调 proposal 后沿用条件独立界。 receiver 基准必须是已指定有限窗口内的真实归一化 Lebesgue 律，转换绝对体积要乘窗口体积并支付窗口外残余。 source 基准必须是实际 fdy/W，或另行严格认证的主子源。提议分布的条件坐标独立不赋予物理 f 独立性。所有 receiver 分类必须共享原 λ；root/coarse/middle 不确定区的上下包络必须留在有界 RN 预算中。此处不重复主代理的三值分类有限样本统计推导，也没有声称本作者运行实际输入样本。

## S6. 一个真正读过的条件鞍点定理及其失败的物理桥

Niu–Choudhury–Katsevich v3 Theorem 1（印刷 p.6）：给定 F_N，W_iN 条件独立、条件均值零。要求固定 β>0 的条件尾 θ_N exp(−βt)、θ_N=O_P(1)，或 |W_iN|≤ν_iN 且 N^{-1}∑ν_iN^4=O_P(1)；另须 N^{-1}∑E(W_iN²|F_N)=Ω_P(1)、F_N 可测 w_N=o_P(1)。令 K_N=N^{-1}∑log E(e^{sW_iN}|F_N)。局部唯一有限鞍点 K_N'(ŝ_N)=w_N 高概率存在；定义 a_N=ŝ_N√(NK_N''(ŝ_N))、r_N=sgn(ŝ_N)√(2N(ŝ_Nw_N−K_N(ŝ_N)))，则条件和尾等于 [1−Φ(r_N)+φ(r_N)(a_N^{-1}−r_N^{-1})](1+o_P(1))，零截止值用文中约定。未给定量有限样本误差率；这个缩小截止值定理没有额外非格点假设。其 Corollary 1 允许条件 σ-代数平凡的确定性阵列。原文版本标题页日期 June 24, 2025，arXiv v3 标 June 22, 2025；本轮没有把较后合并稿当成已读版本。[作者原文 v3](https://arxiv.org/pdf/2407.08915v3)。

**我们对迁移的检查。** 用 N 而非 n 区分样本/阵列长度和物理维数。上述 o_P 环境控制不等于对每一个冻结输入给出有限样本区间。确定性冻结阵列若另行满足统一尾常数、非退化方差与 w_N→0，可以适用其无条件分支；不能笼统断言所有 quenched 应用都不合法。实际首触/粗尺度/中间门事件目前没有被证明等于这样的条件独立和尾。共同物理 λ 也没有自动变成 w_N→0。罕见 Bernoulli 参数 p_N→0 的居中阵列虽有统一有界支撑，平均方差仍趋零，是 NONPHYSICAL 的方差假设失败检查。该检查不否定适当归一化后可能成立的另一阵列，但那需要重算矩界、截止值和事件身份。

实际阅读为：§2 定义/假设/CGF/完整公式/Thm.1/Cor.1（pp.4–7）；§4 proof outline、鞍点存在与条件倾斜拼装（pp.10–19）；Appendix H.7 Lemma 8 的条件律、独立性和矩导数证明（pp.41–42），H.8 Lemma 9 条件 Berry–Esseen 的正则条件律步骤（pp.42–43），H.10 Lemma 11 倾斜回原律证明（p.45）。这些证明步骤实际浏览；没有声称重新独立核完所有 64 页、全部 CGF/比值误差引理或它们的数值常数。本轮的 E4–E5 不依赖未核完的尾误差率；也未使用简化的单一 saddlepoint prefactor 代替完整公式。

## S7. 三阶段压力、作者协调与保留缺口

**Pilot。** S2 的有限 Hopf 递推先送两位独立审计；真正共同的概率卷积半群满足 L1/L∞ 收缩，周期化保精确质量，连续时间对有限有理列表通过共同子列。这是证明，不是立方体比较的实验。S5 先核精确概率律、Z、RN 与冻结条件。

**已知障碍。** 个别算子最大值不能由 S2 推出。NONPHYSICAL m 点循环置换、f=m1_{一状态} 的每点个别幂最大值均为 m，因此在 λ=m/2 有弱型比例 m/2；平均仍由 S2 的有限步骤控制。它只是区分两个算子接口，不是立方体下界。多个不同家族保 E3 费用；未证明费用可线性相加。条件尾渐近保 S6 方差、缩小截止值及实际事件身份，而不是给不确定 root 免费认证。

**扩展。** 已执行纯 NONPHYSICAL exact-Fraction 检查：m=2,3,8,32，各 6 组，正循环懒链 T=(I+rotation)/2，N=1,2,5,16，总计 96 组 Hopf 非负积分及 Cesàro 弱型不等式通过；同样 24 个概率律与 γ=1/2,1/4,1/8，共 72 组 defensive proposal 归一化、RN≤1/γ 及指定事件加权恒等式通过。它们不含实际物理清单、Fnew 门、receiver 单元体积或鞍点近似置信区间。连续时间、任意维数/尺度扩展由 S2–S3 证明承担，不声称运行未执行的物理参数扩展。

Alternative 已给共同半群/钟/正测度比较的准确接口；比较常数的改善仍归作者并接受独立审计。Coverage 的新 per-row rank 均匀性没有给固定物理源跨 row 的条件秩控制，S2 的 Markov 性不能代替此几何缺口。Adaptive 的紧性/弱极限可用固定闭环带 USC 与先固定 m 的 Portmanteau，但不继承 L1 或原门，本源角色不重复其全部边界计数证明。Numeric 的实际输入、proposal、分类包络及残余由其作者冻结；本节只认证 S5 的通用概率合同。

尚缺的是：E2 比较成本的根阶改进或其他真实共同族；Coverage 的跨 row 几何；Adaptive 的阈值放大付费；所有物理 numeric 未认证区的完整覆盖。这些均不能由本轮原文或 exact finite 检查宣布完成。

# R89 parent: sampling with unresolved gates and a high-load variance threshold

These are finite-sample probability statements and deterministic algebraic enclosure statements. They are NOT a deterministic integral certificate, a proof of the fresh principal variance hypothesis, or a dimension-order improvement. Both independent auditors checked the precise statements before reading this proof. All inputs, thresholds, receiver cuts and proposals below are fixed in advance or measurable with respect to training data independent of the subsequent holdout. Random sampling independence is not independence of the coordinates of the physical source.

## 1. Pointwise enclosures must include unclassified samples

Let Q be a probability law and let 0<=a(z)<=g(z)<=b(z)<=M hold Q-almost everywhere, where 0<M<infinity. In an importance calculation, g includes the TRUE Radon–Nikodym weight and the TRUE event indicator. An unclassified point must have an upper enclosure for every possible event membership and numerical weight; it cannot be assigned zero as though certified outside.

For N independent Q samples, write bar a, bar b for sample means. Given 0<delta<1 set

    r=M sqrt(log(3/delta)/(2N)).

With probability at least1-delta, simultaneously

    E_Q g in [bar a-r,bar b+r] intersect [0,M],
    E_Q(b-a) <= bar(b-a)+r.                                  (P1)

Indeed apply one-sided Hoeffding to bar a-Ea, Eb-bar b, and E(b-a)-bar(b-a), with failure delta/3 each, and use Ea<=Eg<=Eb. These variables need not be mutually independent within a sample. For completeness the bounded-variable Hoeffding estimate follows from the convex secant bound for exp(sX) on [0,M]. The centered log moment-generating function is at most s²M²/8: after the secant reduction its second derivative is the variance of a tilted two-point variable and is at most M²/4; integrate twice from zero. Independence of N samples, exponential Markov and s=4r/M² give exp(-2Nr²/M²). The lower-tail version uses -X. This proves (P1), with no unverified empirical variance bound.

The second inequality measures outstanding classification and arithmetic uncertainty. Small Monte Carlo noise does not remove this width. Conditional on training the same proof applies, and averaging its failure bound gives the unconditional statement. For several moments, source points, or adaptively selected reporting times, one must supply a simultaneous failure budget or an appropriate separate sequential theorem; no optional stopping of this fixed-N interval is asserted. M=0 is the separate trivial case.

## 2. Event-specific importance bounds and their limit

Let P be a probability reference. For a finite set of labels let pi_j>0 sum to1, s_j>0, F_j be finite measurable scores and K_j=log E_P exp(s_j F_j)<infinity. The normalized mixture proposal has

    q=dQ/dP=sum_j pi_j exp(s_j F_j-K_j).

If a measurable target E has a PROVED P-almost-sure cover E subset union_j{F_j>=h_j}, then

    1_E/q <= max_j exp(K_j-s_j h_j)/pi_j.                     (P2)

For each point of E choose any covering label; its single positive summand bounds q below. The mixture is normalized by the actual K_j and weights, not by an approximate saddlepoint. The formula E_Q[1_E/q]=P(E) is the Radon–Nikodym identity. If extended scores are allowed one must separately ensure P(E intersect{q=0})=0, defining the payoff zero on irrelevant zero-density points.

The inverse-weight bound is only on E. It does not directly bound a raw upper classifier which is also positive on an unresolved region outside the proven cover. There is, however, a safe clipping operation: the TRUE payoff g=1_E/q is globally at most the event bound M_event in (P2), because g=0 off E. For any genuine raw upper b0>=g, min(b0,M_event) is still a global upper for g, whether or not the unresolved region has been proved to lie in the cover. Thus one may either certify the possible-event region's cover, clip to a proved global TRUE-payoff bound, or pay a larger valid global inverse-weight bound. These are distinct justifications. For Q_gamma=gamma P+(1-gamma)Q, 0<gamma<=1, one has dQ_gamma/dP>=gamma and hence the global inverse-weight bound1/gamma. The stated marginal-mixture estimator and its range bound require the summed density q. A different label-retaining estimator can legitimately use1/q_j for joint proposal pi_j Q_j and target pi_j P when every Q_j dominates P. That is a separate unbiased estimator; its range is not automatically the mixture or defensive bound above.

The updated H02 skill supplies the exact tilt identity and separates it from a saddlepoint approximation; no Lugannani–Rice relative error is invoked here. In particular this argument assumes no Gaussian limit, nonlattice estimate, coordinate independence, or rare-event prefactor. H05 is used only within its independent bounded-sample domain, and the preceding proof makes the normalization explicit.

## 3. Exact binomial inversion after auxiliary randomization

The following optional interval is useful when an upper payoff is rarely nonzero. It is not claimed uniformly superior to (P1). Take auxiliary U_i uniform on[0,1], mutually independent and independent of all holdout samples, and define the unobserved variables

    B_i=1{U_i<=g(Z_i)/M}.

They are independent Bernoulli variables with p=E_Q g/M. The SAME uniforms and the enclosures give observed counts

    Kminus=sum_i 1{U_i<=a(Z_i)/M}
       <=K=sum_i B_i<=
    Kplus=sum_i 1{U_i<=b(Z_i)/M}.                              (P3)

Set eta=delta/2. Define L(0)=0, U(N)=1. For 1<=k<=N let L(k) be the unique solution in(0,1) of

    Pr_Bin(N,L(k))(K>=k)=eta,

and for 0<=k<N let U(k) solve Pr_Bin(N,U(k))(K<=k)=eta. These tails are continuous and strictly monotone in the relevant direction; both endpoint functions are increasing in k. For any fixed p, the event L(K)>p is an upper count tail of probability at most eta; to see this, take its least possible integer k, and evaluate the upper tail at p<L(k). Similarly U(K)<p is a lower count tail of probability at most eta. Union and (P3) prove

    E_Q g/M in [L(Kminus),U(Kplus)] with probability>=1-delta. (P4)

Conservative rational endpoints are permitted. For k>=1 an Ltilde with Pr_Bin(N,Ltilde)(K>=k)<=eta lies below L(k); for k<N an Utilde with Pr_Bin(N,Utilde)(K<=k)<=eta lies above U(k). Keep the separate endpoint conventions. The code constructs monotone dyadic tables and checks these tail inequalities with integers. They widen (P4); there is no asymptotic normal approximation or numerical root sign assumption.

When Kplus=0 the exact upper endpoint is1-eta^(1/N), at most log(1/eta)/N. When all points are unresolved with a=0,b=M, the interval is[0,1]. Replacing those points by outside would give Kplus=0 and could be wrong with probability one. Auxiliary Bernoulli sampling adds randomness and may increase variance; its purpose is a rigorous option, not a claimed asymptotic efficiency theorem. If the pointwise enclosures themselves are only simultaneously valid with failure at most delta_env, the total failure is at most delta+delta_env. Such a simultaneous event cannot be replaced by an unbudgeted collection of pointwise claims.

## 4. Moment boxes for the actual high-load canonical variance

Fix a source y and the ORIGINAL whole receiver event or a fixed original principal cut. Let

    b=integral L(x)^(-n) 1_Qx(y) dx,
    m_j=integral L(x)^(-n) 1_Qx(y) u(x,y)^j dx, j=1,2,
    0<=u<=ell=log2.

All integrals use the same canonical law. Suppose a simultaneous valid box provides nonnegative finite intervals [bminus,bplus] and [m_jminus,m_jplus]. For a fixed T>0 put G=1{b>T}(m2/b-(m1/b)^2), with G=0 when b=0.

If bplus<=T set both G bounds to zero. Otherwise a valid upper bound is

    Gplus=max(0,min(ell²/4,
        m2plus/max(T,bminus)-(m1minus/bplus)^2)).              (P5)

Set Gminus=0 unless bminus>T. In that latter case set

    Gminus=max(0,m2minus/bplus-(m1plus/bminus)^2).              (P6)

On the active event b>T, max(T,bminus)<=b<=bplus. Thus the first ratio in (P5) bounds the true second moment above and its subtracted square bounds the true squared mean below. The variance is at most ell²/4: if a variable V lies in[0,ell], then EV²<=ell EV and Var V<=EV(ell-EV)<=ell²/4. This justifies the cap. The lower ratio directions in (P6) reverse correctly, and bminus>T ensures activity. If activity is ambiguous, zero is the safe lower bound; if it is absent G=0 and the nonnegative upper remains safe. There is no zero denominator in the indicated branches. Merely well-shaped intervals are not sufficient: they must contain the SAME true moments.

This explicitly avoids inserting estimated b into 1{b>T} and treating the resulting plug-in variance as unbiased. A confidence box is still probabilistic evidence. In particular, point samples in y alone give no integral over physical source mass.

## 5. The outer source integral and the full probability budget

Let W=mu(R^n)>0 and choose a frozen outer source probability Qsrc with exact density v=d(mu/W)/dQsrc bounded by Bsrc<infinity. For independent Y_1,...,Y_m drawn from Qsrc the unobserved true variables

    Z_j=v(Y_j)G(Y_j) in[0,Bsrc ell²/4]

are iid and E Z_j=I_T/W. Suppose all inner moment boxes at these sampled points are simultaneously valid with failure at most delta_inner. This may be arranged by assigning conditional-on-Y failure budgets whose sum is at most delta_inner; inner proposals may depend on Y, but subsequent samples must have the stipulated laws. Multiplication of (P5)-(P6) by the exact v gives pathwise brackets for Z_j on that joint event.

Apply the two-sided bounded mean estimate to the unobserved true Z_j with failure delta_outer, then substitute their brackets. Alternatively apply (P4) with fresh independent outer uniforms and replace the unobserved count by bracket counts. In either case

    probability of coverage for I_T/W >=1-delta_inner-delta_outer. (P7)

The computed inner brackets need not be iid: the outer concentration is applied to the fixed true function G(Y), and replacement is pathwise on the simultaneous box event. If v is evaluated numerically it requires its own genuine enclosing arithmetic, incorporated before using the range Bsrc ell²/4. Fitting the physical source, threshold, cut or proposal after seeing these holdout samples invalidates this fixed-function argument unless a separate simultaneous selection theorem is supplied.

The elementary Hoeffding width here is proportional to Bsrc/sqrt(m). Testing a quantity of order1/n by that width alone can require order n² samples. Binomial inversion may improve sparse-payoff diagnostics but does not waive unresolved gate mass, weight bounds or inner computation. No sample complexity sufficient for the research target is asserted.

## 6. Verification plan and exact scope

The new public arithmetic probe actually passed2,846 assertions. Pilot uses binomial sample sizes1,2,4,8 and12-bit dyadic endpoints. Pressure changes the one-sided error from1/20 to1/100 with16-bit endpoints and checks the unresolved-event and event-only-weight failure mechanisms. Expansion uses N=16,32,64,128 and24-bit endpoints. Ten full endpoint tables have exact tail and monotonicity checks; seven rational true probabilities per table have directly enumerated one-sided failure probabilities. Eighteen finite randomized-envelope models enumerate the joint lower/true/upper counts, including all-unknown cases. Separately216 moment boxes cover b=0, b=T, ambiguous and certified-active loads, endpoint and interior means, and zero/small/large enclosure widths. These N values are sample sizes, not physical dimensions.

All calculations use integers and Fraction. The exact finite model is NONPHYSICAL, with no actual cube gates or radial geometry. It verifies the new arithmetic, not a general confidence theorem by finite testing; the proofs above establish that theorem. Actual physical classifiers, rare proposals and receiver/source sampling belong to the two numerical tasks and remain separately qualified. These tools make their uncertainty explicit; they do not prove the missing geometric estimates. Independent proof and guard receipts are recorded separately from this author execution.


本轮改为真实接收 Haar 测度的稀尾重要抽样，尚未得到完整新残余集的高负载证书、实际主割容量或径向方差预算。实际输入和提议参数保留在私有文件中。三个阶段使用同一冻结输入和同一提议，样本数分别为 8、24、64；有限尺度硬事件有 6、20、51 个区间认证的严格正样本。它们提供实际硬事件的正体积见证，不能代替尚未认证的原整窗上门、新粗门及其余残余门槛。同一来源的部分标量下界由固定来源报告另行提供，接收抽样程序本身没有使用它们作完整事件分类。

公开标准库程序只检查一般换测算术。三个阶段共枚举 84 个**非物理**有限状态，精确核对混合提议的归一化、完整 RN 权重、事件覆盖与三值上下支付。没有实际来源配方、连续最早接触或 Hall 结论。

对参考乘积概率测度上的正函数上界 \(U_j\)，令
\[
 Z_j=\mathbb E U_j^2,\qquad
 q(x)=\gamma+\frac{1-\gamma}{3}\sum_{j=1}^3
          \prod_{i=1}^n\frac{U_j(x_i)^2}{Z_j}.
\]
每个分量和混合密度都精确积分为 1。RN 权重是 \(1/q(x)\)，必须使用整个混合密度；抽到哪个隐藏分量不改变权重公式。防御分量给出全域界 \(1/q\le1/\gamma\)。

若实际有限节点事件 \(E\) 已证被 \(\bigcup_j\{\prod_i U_j\ge\lambda\}\) 覆盖，则其真实支付 \(1_E/q\) 在全域满足
\[
 0\le\frac{1_E}{q}\le
 M:=\min\left\{\frac1\gamma,
      \max_j\frac{3Z_j^n}{(1-\gamma)\lambda^2}\right\}.
\]
未知点的原始 RN 上支付不能直接套用事件界。合法的办法是证明上支付的支撑落在覆盖中，或者把一个已经有效的上支付截到这个**已证明的真实支付全域界** \(M\)。公开程序和私有有限节点实验均保存这个区别。未覆盖的完整残余集仍需防御全域界，不能借用有限节点的较小 \(M\)。

三值账使用 \(0\le a\le g\le b\le M\)。冻结提议后，理想独立样本的半径
\[
 r=M\sqrt{\frac{\log(3/\delta)}{2N}}
\]
同时控制真实均值区间和未知支付均值。这里的概率解释有明确前提：实际支付区间正确、独立提议固定，以及真实连续坐标的分类对潜在区间内每个点都有效。仅评估浮点代表点不满足这些前提。本轮每个实际阶段使用 \(\delta=0.05\)；没有把三个阶段的区间称为共同 95% 结论，直接并集界只能给出至少 85%。

公开重放：`python3 hall_probe.py`，输出 `hall_results.json`。所有 84 个有理状态通过。其内容是换测接口的精确检查，不是一般平方根弱型界的数值证据。

The fixed-source numerical role verified normalization and bounded likelihood for a defensive importance interface, with exact three-valued kernel envelopes that retain unresolved gates. One finite positive source has partial original and posterior scalar certificates; continuous first contact, the original full-window upper gate and the new coarse gate remain unresolved. No canonical variance, high-load, principal-capacity or dimension-order improvement is certified.

## R89 independent Astra audit

The complete author Markdown and matching TeX proofs, parent sampling proof, and final intro/ledger have passed independent mathematical and scope review. Statements were pressure-tested before author proofs were read. This receipt does not turn author finite checks into this auditor's executions or claim new reading of every cited primary proof.

- Coverage: actual posterior radial ranks yield valid same-source row couplings. The rank-bin identity is source-integrated; it is not pointwise source independence. The scalar-prefix-only envelope still costs n log 2 and does not refute all physical rank reallocations. The paired face/bulk identity and anchor extension give an exact bounded demand estimator, with explicit weighted unknown-classification bias and qualified iid confidence bounds. Exact principal-source sampling, true membership and all original selector/gate predicates remain prerequisites; no full-gate physical estimator was executed here.
- Adaptive: actual nested-cube recursion gives the stated annular mass and logarithmic scale-drop budgets. Persistent high burden without sufficiently rapid source contraction forces coordinate atoms in normalized child-source weak limits. The proof uses fixed closed-annulus columns before the decreasing limit; no original gates or absolute continuity are inherited by the limit. A separate uniform normalized marginal-modulus hypothesis yields the explicit finite-stage repeated-fee and terminal budget. That hypothesis and a general source-mass-priced root-order expense remain unproved.
- Alternative and Sources: one legitimate marked-Poisson convolution semigroup has the proved constant-one Cesaro weak endpoint. Its explicit one-jump cube comparison costs O(n log n). A separate full-law rigidity argument proves that every positive probability time mixture from this specified family requires pointwise comparison cost Omega(n/log^2 n), uniformly over the jump exponent. Interior boxes justify the corner passage. This is not a weak maximal lower bound and does not rule out other semigroups or paid-error comparisons. The independent Hopf/periodization/common-time proof supplies the needed endpoint without relying on inaccessible original proofs.
- Sampling: frozen-law RN identities, simultaneous bounded-envelope intervals, auxiliary exact binomial inversion, canonical moment boxes and outer-source failure accounting are valid under their stated sampling and classification premises. An upper classifier may be clipped to a proved global bound for the true payoff; its unclipped inverse-weight value does not automatically inherit an event-specific range. Labels may be retained in a different unbiased estimator, but that estimator has its own likelihood and range. Confidence intervals are probabilistic statements, not deterministic integral certificates.
- Numeric scope: exact generic envelope arithmetic and partial finite-input scalar certificates are kept separate from physical full-event certification. The fixed-source role retains the whole unresolved event in deterministic upper envelopes and does not claim sampled canonical variance or a source-integrated high-load bound. Receiver finite-node hard evidence does not establish continuous first contact, all remaining gates, whole Fnew, or optimized Hall capacity. Independent replay receipts are attributed to their actual executor.

The final ledger retains the original anchor, whole-window smoothing, strict later witness, first-contact and original middle conditions; recomputes gates after reselection; and distinguishes canonical from optimized laws. The fixed-grid fee and physical collision/entropy union fee are retained, the latter once. The R88 fresh principal-cut radial hypothesis and its all-cut/Lusin conditional return remain conditional. Full-scale and any layer fees, repeated source costs and final terminal terms have not been dropped.

The general positive-L1 target C_n <= sqrt(n) n^{o(1)} remains open; the retained general bound is O(n log n). The remaining gaps are actual cross-row signed geometry, a paid normalized source-concentration mechanism, or another valid common-kernel comparison with a sufficiently small total expense. No private physical construction or parameter recipe is contained in this public audit.

## R89 independent Sol audit — frozen

The general arbitrary-positive-L1 centered-cube weak bound of order sqrt(n)n^{o(1)} remains **UNPROVED**. The retained general bound is O(nlogn). R88 is a frozen dependency; its tests are not counted as new R89 evidence.

Sol independently checked exact new statements before reading their proofs, then read the complete matching coverage, adaptive, alternative, sources and parent-sampling Markdown/TeX proofs, plus intro and ledger. All pass within the scopes stated here. Source-localized anchor<=mu(S) validates the proposed absorption coefficient, but the required uniform root-order flux bound is not proved. Actual radial-rank couplings are valid; retaining only scalar prefix information still costs nlog2. Actual annular loss and weak-limit coordinate concentration are proved; the finite repeated-fee result assumes an additional uniform normalized marginal modulus. This premise and the general repeated-fee/terminal root budget remain open. The common jump semigroup and Cesaro weak1 endpoint are valid; its full-family Omega(n/log^2n) obstruction concerns pointwise cube comparison by positive time mixtures, not a general cube weak lower bound.

Original gates and selectors, same mu=fdy, actual lambda dx, all positive principal cuts, fresh canonical I_T hypotheses, once-paid branch unions, all-scale and binary-layer costs remain explicit. Principal source closure does not inherit original lower/later gates. Retained Gamma mixture uses Gamma(n+1), while its radial law uses Gamma(n); the negative Fourier value -1/780 and direct variation cost c_n+2nlog2 still preclude the naive semigroup shortcut. The required Gamma/Psi maximal and terminal budgets remain open.

The statistical interfaces correctly retain frozen proposals, full marginal RN weights, simultaneous same-fibre moment boxes, weighted UNKNOWN allowances and independent artificial trials. A genuine raw upper may be clipped to a proved global true-payoff bound, including an event-derived bound; its unknown region need not itself have that cover. Confidence intervals are probability statements, not deterministic integral proofs. No estimated-load plug-in or physical-coordinate independence is asserted.

Private review and a nonwriting fixed-source scalar replay certify only bounded numerical interfaces and partial original/posterior scalars. They do not certify earliest contact, the complete original smooth-window upper gate, the new coarse gate, whole residual coverage, canonical high-load variance or principal capacity. Sol checked saved receiver-record consistency but did not execute the physical receiver sampler. Its separate stage intervals are not a joint95% statement. Actual input recipes, parameters and private program paths are excluded from this summary.

The independently written, standard-library-only guard derives new exact arithmetic and reconstructs both saved public JSON files without importing producer programs. Standalone PASS:6205 assertions (new strategy stages430/534/1030); it checks ten binomial tables, eighteen joint-count models,216 moment boxes and84 NONPHYSICAL Hall states. Coverage-specific210, alternative-specific81, adaptive27 and finite Hopf110 assertions are generic arithmetic evidence, separate from full analytic proof review and author counts. Fresh Taylor-integral and global-clipping checks are included.

A temporary seven-member public-only mock archive passed sole-fence extraction and execution:6209 assertions,0.774371083 seconds internally,0.800565125 seconds wall time, exit0, empty stderr. This packaging receipt is Sol's own; the parent must separately execute the final assembled archive. No private definitions are loaded.

Frozen SHA256 bindings:

- hall_probe.py: d4f4d42c167811f4e25acb3ed90ada56699a4b256742f68d7ccc79d2e7e84571
- hall_results.json: dbed912f5743ce468393c45c42ea2c682b17e2a8d9775104ba6d2f73a87e058a
- parent_sampling_probe.py: 8a204e0952321751b3f6c6e001fbf79fc786fab29894599b2c67c1f29592d640
- parent_sampling_results.json: 37b1604283d3f3bf9b0dca47402e263949c6ff50424e56a04c6b525fc070fa0c
- audit_guard.py: 604c3bfc4a87c33af82853c97f48983dc9fb90b50dae7d582e064a68e579ae56

No Git action or PDF compilation was performed by this auditor. Only audit.md and audit_guard.py were edited.

## 独立公开审核程序

```python
#!/usr/bin/env python3
"""R89 independent exact arithmetic guard: NONPHYSICAL finite probability laws.
Tests new defensive importance/unknown envelopes and finite-binomial inversion.
No physical recipe, original gate, continuum theorem or general cube bound is
certified. Standard library only; no author program is imported.
"""
from fractions import Fraction as F
from math import comb, factorial
from itertools import product
from pathlib import Path
import hashlib
import json
import re
import time

COUNT = 0
STAGES = {}
EXPECTED = {
    'parent_sampling_probe.py': '8a204e0952321751b3f6c6e001fbf79fc786fab29894599b2c67c1f29592d640',
    'parent_sampling_results.json': '37b1604283d3f3bf9b0dca47402e263949c6ff50424e56a04c6b525fc070fa0c',
    'hall_probe.py': 'd4f4d42c167811f4e25acb3ed90ada56699a4b256742f68d7ccc79d2e7e84571',
    'hall_results.json': 'dbed912f5743ce468393c45c42ea2c682b17e2a8d9775104ba6d2f73a87e058a',
}


def ck(condition):
    global COUNT
    assert condition
    COUNT += 1


def expectation(probabilities, values):
    return sum((p * v for p, v in zip(probabilities, values)), F(0))


def finite_rn(size, scale):
    # Positive normalized target and normalized component RN densities.
    nums = [1 + i for i in range(size - 1)] + [2 ** scale]
    P = [F(v, sum(nums)) for v in nums]
    mixtures = []
    for j in range(3):
        raw = [F(2 ** scale) if i % 3 == j else F(1, i + 1)
               for i in range(size)]
        Z = expectation(P, raw)
        ell = [v / Z for v in raw]
        ck(expectation(P, ell) == 1)
        mixtures.append(ell)
    pi = [F(1, 7), F(2, 7), F(4, 7)]
    q = [sum((pi[j] * mixtures[j][i] for j in range(3)), F(0))
         for i in range(size)]
    Q = [p * density for p, density in zip(P, q)]
    ck(sum(Q) == 1 and all(density > 0 for density in q))
    E = {i for i in range(size) if i % 2 == 0}
    cover = [E.intersection(i for i in range(size) if i % 3 == j)
             for j in range(3)]
    thresholds = [min((mixtures[j][i] for i in cover[j]), default=F(1))
                  for j in range(3)]
    M = max(1 / (pi[j] * thresholds[j]) for j in range(3))
    ck(set().union(*cover) == E)
    for j in range(3):
        for i in cover[j]:
            ck(q[i] >= pi[j] * thresholds[j])
    ck(all(1 / q[i] <= M for i in E))
    g = [1 / q[i] if i in E else F(0) for i in range(size)]
    ck(expectation(Q, g) == sum((P[i] for i in E), F(0)))

    gamma = F(1, 11)
    defensive = [gamma + (1 - gamma) * v for v in q]
    defensive_Q = [p * v for p, v in zip(P, defensive)]
    ck(sum(defensive_Q) == 1)
    ck(all(v >= gamma and 1 / v <= 1 / gamma for v in defensive))
    lower = {min(E)}
    upper = E.union({size - 2})
    a = [1 / defensive[i] if i in lower else F(0)
         for i in range(size)]
    true = [1 / defensive[i] if i in E else F(0)
            for i in range(size)]
    b = [1 / defensive[i] if i in upper else F(0)
         for i in range(size)]
    ck(all(0 <= x <= y <= z <= 1 / gamma for x, y, z in zip(a, true, b)))
    ck(expectation(defensive_Q, a) <= expectation(defensive_Q, true)
       <= expectation(defensive_Q, b))
    gap = expectation(defensive_Q, [z - x for x, z in zip(a, b)])
    ck(gap == sum((P[i] for i in upper - lower), F(0)))
    ck(expectation(defensive_Q, true) == sum((P[i] for i in E), F(0)))


def event_only_pressure():
    # A correct target-only inverse bound fails on a larger unknown upper set.
    P = [F(1, 2), F(1, 2)]
    q = [F(3, 2), F(1, 2)]
    Q = [p * v for p, v in zip(P, q)]
    event_M = F(2, 3)
    ck(sum(Q) == 1 and 1 / q[0] == event_M)
    ck(1 / q[1] > event_M)
    ck(expectation(Q, [1 / q[0], F(0)]) == P[0])
    ck(expectation(Q, [1 / q[0], 1 / q[1]]) == 1)
    ck(Q[1] != P[1])  # Raw proposal unknown mass is not target unknown mass.
    raw_upper = [1 / v for v in q]
    clipped = [min(v, event_M) for v in raw_upper]
    ck(all(g <= b <= event_M for g, b in zip([event_M, F(0)], clipped)))
    ck(expectation(Q, clipped) >= P[0])

    # Zero-density convention is legitimate only off the target event.
    zero_q = [F(2), F(0)]
    zero_Q = [p * v for p, v in zip(P, zero_q)]
    payoff = [F(1, 2), F(0)]
    ck(expectation(zero_Q, payoff) == P[0])
    ck(P[1] > 0 and zero_Q[1] == 0)


def binomial_mass(N, p, k):
    return F(comb(N, k)) * p ** k * (1 - p) ** (N - k)


def upper_tail(N, p, k):
    return sum((binomial_mass(N, p, j) for j in range(k, N + 1)), F(0))


def lower_tail(N, p, k):
    return sum((binomial_mass(N, p, j) for j in range(k + 1)), F(0))


def inversion_table(N, eta):
    # Conservative dyadic rational bounds; no floating quantile library.
    lowers = [F(0)]
    for k in range(1, N + 1):
        lo, hi = F(0), F(1)
        for unused in range(10):
            mid = (lo + hi) / 2
            if upper_tail(N, mid, k) <= eta:
                lo = mid
            else:
                hi = mid
        lowers.append(lo)
        ck(upper_tail(N, lo, k) <= eta)
    uppers = []
    for k in range(N):
        lo, hi = F(0), F(1)
        for unused in range(10):
            mid = (lo + hi) / 2
            if lower_tail(N, mid, k) <= eta:
                hi = mid
            else:
                lo = mid
        uppers.append(hi)
        ck(lower_tail(N, hi, k) <= eta)
    uppers.append(F(1))
    ck(lowers[0] == 0 and uppers[N] == 1)
    ck(all(lowers[k] <= lowers[k + 1] for k in range(N)))
    ck(all(uppers[k] <= uppers[k + 1] for k in range(N)))
    ck(all(lowers[k] <= uppers[k] for k in range(N + 1)))
    return lowers, uppers


def binomial_checks(N, eta):
    lower, upper = inversion_table(N, eta)
    for p in (F(1, 1000), F(1, 10), F(1, 2), F(9, 10), F(999, 1000)):
        masses = [binomial_mass(N, p, k) for k in range(N + 1)]
        ck(sum(masses) == 1)
        covered = sum((masses[k] for k in range(N + 1)
                       if lower[k] <= p <= upper[k]), F(0))
        ck(covered >= 1 - 2 * eta)
    # For every pathwise bracket count, its interval contains the true interval.
    for k in range(N + 1):
        for kminus in range(k + 1):
            ck(lower[kminus] <= lower[k])
        for kplus in range(k, N + 1):
            ck(upper[k] <= upper[kplus])
    ck(lower[0] == 0 and upper[N] == 1)  # Entirely unknown means [0,1].
    ck((1 - upper[0]) ** N <= eta)  # Exact zero-detection upper certificate.


def finite_hoeffding(N, r, delta, Q):
    # Exact count-law benchmark; this is not a proof of general Hoeffding.
    M = F(1)
    a = [F(0), F(1, 4), F(3, 4)]
    g = [F(0), F(1, 2), F(1)]
    b = [F(1, 4), F(3, 4), F(1)]
    ck(sum(Q) == 1 and all(0 <= x <= y <= z <= M for x, y, z in zip(a, g, b)))
    Eg = expectation(Q, g)
    gap = expectation(Q, [z - x for x, z in zip(a, b)])
    bad = F(0)
    total = F(0)
    for i in range(N + 1):
        for j in range(N - i + 1):
            k = N - i - j
            counts = (i, j, k)
            coefficient = F(factorial(N), factorial(i) * factorial(j) * factorial(k))
            probability = coefficient * Q[0] ** i * Q[1] ** j * Q[2] ** k
            abar = sum((F(c, N) * x for c, x in zip(counts, a)), F(0))
            bbar = sum((F(c, N) * x for c, x in zip(counts, b)), F(0))
            total += probability
            if not (max(0, abar - r) <= Eg <= min(M, bbar + r)
                    and gap <= bbar - abar + r):
                bad += probability
    ck(total == 1)
    # exp(x)>=its positive Taylor partial sum, so 3 exp(-x)<=delta exactly.
    x = 2 * N * r * r / (M * M)
    exp_lower = sum((x ** k / factorial(k) for k in range(20)), F(0))
    ck(exp_lower >= 3 / delta)
    ck(bad <= delta)


def moment_boxes(scale):
    # Normalize log-range to l=1; every moment belongs to the SAME finite fibre.
    for b in (F(0), F(1, 2), F(1), F(3)):
        for weights, ages in (
            ([F(1)], [F(0)]),
            ([F(1, 2)] * 2, [F(0), F(1)]),
            ([F(1, 4), F(1, 2), F(1, 4)], [F(0), F(1, 3), F(1)])):
            m1 = b * expectation(weights, ages)
            m2 = b * expectation(weights, [u * u for u in ages])
            variance = m2 / b - (m1 / b) ** 2 if b else F(0)
            ck(0 <= variance <= F(1, 4))
            for T in (F(1, 2), F(1), F(2)):
                for error in (F(0), F(1, scale), F(1)):
                    blo, bhi = max(F(0), b - error), b + error
                    m1lo, m1hi = max(F(0), m1 - error), m1 + error
                    m2lo, m2hi = max(F(0), m2 - error), m2 + error
                    true = variance if b > T else F(0)
                    if bhi <= T:
                        lo = hi = F(0)
                    else:
                        hi = max(F(0), min(F(1, 4),
                            m2hi / max(T, blo) - (m1lo / bhi) ** 2))
                        lo = (max(F(0), m2lo / bhi - (m1hi / blo) ** 2)
                              if blo > T else F(0))
                    ck(lo <= true <= hi <= F(1, 4))
                    if error == 0:
                        ck(lo == true == hi)


def rank_envelope(dimensions, bins):
    # Piecewise-constant normalized rank tilts, not actual gated input fixtures.
    laws = [[F(1)] * bins,
            [F(bins)] + [F(0)] * (bins - 1),
            [F(0)] * (bins - 1) + [F(bins)]]
    for values in laws:
        ck(sum(values) / bins == 1)
        c = max(values)
        ck(c >= 1)
        j = values.index(c)
        u = F(2 * j + 1, 2 * bins)
        ck(0 < u < 1)
        for n in dimensions:
            for d in (F(1), F(3, 2), F(7, 4)):
                # Strict tau>d witness approaching the scalar envelope.
                epsilon = min((1 - u) / (4 * n), (2 / d - 1) / 2)
                tau = d * (1 + epsilon)
                v = (d / tau) ** n
                ck(d < tau <= 2 and u < v <= 1)
                achieved = tau ** (-n) * c
                relaxed = d ** (-n) * c
                ck((1 - n * epsilon) * relaxed <= achieved <= relaxed)


def coupled_observable():
    # Finite joint endpoint law: (face,bulk) is coupled, not independent.
    P = [F(1, 10), F(2, 10), F(3, 10), F(4, 10)]
    face, bulk = [0, 0, 1, 1], [0, 1, 0, 1]
    delta = [a - b for a, b in zip(face, bulk)]
    ck(expectation(P, delta) == expectation(P, face) - expectation(P, bulk))
    ck(expectation(P, [v * v for v in delta]) == P[1] + P[2])
    gamma = F(1, 4)
    Q = [gamma * P[j] + (1 - gamma) * (j == 2) for j in range(4)]
    weights = [p / q for p, q in zip(P, Q)]
    ck(max(weights) <= 1 / gamma)
    ck(expectation(Q, [w * d for w, d in zip(weights, delta)]) == expectation(P, delta))
    ck(expectation(Q, [(w * d) ** 2 for w, d in zip(weights, delta)])
       <= expectation(P, [d * d for d in delta]) / gamma)
    unknown = [0, 0, 1, 0]
    estimated = [d * (1 - u) for d, u in zip(delta, unknown)]
    bias = abs(expectation(Q, [w * d for w, d in zip(weights, estimated)])
               - expectation(P, delta))
    weighted_unknown = expectation(Q, [w * u for w, u in zip(weights, unknown)])
    ck(bias <= weighted_unknown == P[2])
    ck(expectation(Q, unknown) != weighted_unknown)


def uniform_moments(radii):
    # Exact independent uniform moments; finite radius arrays are NONPHYSICAL.
    variance = sum((r * r / 3 for r in radii), F(0))
    fourth = sum((r ** 4 / 5 for r in radii), F(0))
    fourth += 6 * sum((radii[i] ** 2 * radii[j] ** 2 / 9
                      for i in range(len(radii)) for j in range(i)), F(0))
    ck(3 * variance ** 2 - fourth == F(2, 15) * sum(r ** 4 for r in radii))
    ck(fourth <= 3 * variance ** 2)
    ck(max(radii) ** 2 * sum(r ** 2 for r in radii) >= sum(r ** 4 for r in radii))


def beta_harmonic(n):
    # Integral log^2 epsilon moments via exact binomial expansion.
    integral = n * sum((F((-1) ** j * comb(n - 1, j) * 2, (j + 2) ** 3)
                        for j in range(n)), F(0))
    H = sum((F(1, j) for j in range(2, n + 2)), F(0))
    H2 = sum((F(1, j * j) for j in range(2, n + 2)), F(0))
    ck(integral == (H * H + H2) / (n + 1))
    ck(H2 < 1)


def enormous_dimension(k):
    # Uses the analytically proved e<3 and log2<1; no sampling in dimension n.
    n = 2 ** k
    ck(n >= 3 ** 20 * (k + 1))
    numerator = 10000 * ((k + 1) ** 2 + 1) + 1
    theta_upper = F(numerator, n + 1)
    ck(0 < theta_upper < 1)
    ck(n + 1 > numerator * 2 ** (k // 2) * (k + 1) ** 2)


def uniform_density(radii, x):
    # Independent truncated-power convolution formula for >=2 uniforms.
    total = sum(radii)
    m = len(radii)
    result = F(0)
    for mask in range(1 << m):
        shift = sum((radii[j] for j in range(m) if mask >> j & 1), F(0))
        result += (-1) ** mask.bit_count() * max(x + total - 2 * shift, 0) ** (m - 1)
    denominator = F(2 ** m * factorial(m - 1))
    for radius in radii:
        denominator *= radius
    return result / denominator


def kernel_pressure(scale):
    epsilon = F(1, 10 ** scale)
    M = 1 + epsilon / 2
    radii = [M, epsilon / 4, epsilon / 8]
    ck(uniform_density(radii, F(1)) == 1 / (2 * M))
    ck(2 * uniform_density(radii, F(1)) >= 1 - epsilon)
    for radii in ([F(1, 2), F(1, 2)], [F(1)] * 3, [F(1, 3)] * 5):
        total = sum(radii)
        xs = [total * F(j, 8) for j in range(9)]
        values = [uniform_density(radii, x) for x in xs]
        ck(all(v >= 0 for v in values))
        ck(all(values[j] >= values[j + 1] for j in range(8)))
        ck(values[-1] == 0)
        ck(all(uniform_density(radii, -x) == v for x, v in zip(xs, values)))


def annular_constants():
    # Premise-conditioned scalar calculations, not physical recursion fixtures.
    for c in (F(43, 50), F(9, 10), F(99, 100)):
        beta, p = c / 2, 7 * c / 8
        for s in (1 - c / 16, 1 - c / 32, F(1)):
            annular_lower = p - beta * s - (1 - s)
            ck(annular_lower >= 5 * c / 16)
        rho = 3 * c / 4
        ck((5 * c / 16) / rho == F(5, 12))
        ck(rho / beta == F(3, 2))
        for V, Rstar in ((F(1), F(1, 2)), (F(7), F(3))):
            omega = 5 * Rstar / (48 * V)
            ck(2 * V * omega * rho / Rstar == 5 * c / 32)
            ck(F(32, 5) / c * (5 * c / 32) == 1)


def hopf(n):
    # A common finite Markov operator; no claimed physical-coordinate law.
    def transition(v):
        return [(v[j] + v[(j + 1) % n]) / 2 for j in range(n)]
    for f in ([F(n)] + [F(0)] * (n - 1),
              [F(j + 1, n) for j in range(n)]):
        for threshold in (F(1, 3), F(1), F(3, 2)):
            g = [v - threshold for v in f]
            u = [F(0)] * n
            partial = [F(0)] * n
            iterate = list(g)
            total_f = [F(0)] * n
            iterate_f = list(f)
            max_average = [F(0)] * n
            for horizon in range(1, 20):
                partial = [a + b for a, b in zip(partial, iterate)]
                u = [max(a, b) for a, b in zip(u, partial)]
                total_f = [a + b for a, b in zip(total_f, iterate_f)]
                max_average = [max(a, b / horizon) for a, b in zip(max_average, total_f)]
                if horizon in (2, 7, 19):
                    ck(sum(g[j] for j in range(n) if u[j] > 0) >= 0)
                    ck(threshold * sum(v > threshold for v in max_average) <= sum(f))
                iterate, iterate_f = transition(iterate), transition(iterate_f)
    if n > 2:
        ck(F(n, 2) > 1)  # Cyclic individual-power max has weak ratio n/2.


def saved_parent(root):
    # Independent exact reconstruction from JSON; the producer is never imported.
    for name, digest in EXPECTED.items():
        ck(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest)
    saved = json.loads((root / 'parent_sampling_results.json').read_text())
    ck('NONPHYSICAL' in saved['scope'])
    tables = saved['tables']
    models = saved['envelope_models']
    boxes = saved['moment_boxes']
    ck(len(tables) == 10 and len(models) == 18 and len(boxes) == 216)
    ck(saved['counts']['tables'] == len(tables)
       and saved['counts']['envelope_models'] == len(models)
       and saved['counts']['moment_boxes'] == len(boxes))
    model_index = 0
    for row in tables:
        N, eta = row['n'], F(row['eta'])
        step = F(1, 2 ** row['bits'])
        low = list(map(F, row['lower']))
        high = list(map(F, row['upper']))
        ck(len(low) == len(high) == N + 1)
        ck(low[0] == 0 and high[N] == 1)
        for k in range(1, N + 1):
            ck(upper_tail(N, low[k], k) <= eta)
            ck(upper_tail(N, low[k] + step, k) > eta)
        for k in range(N):
            ck(lower_tail(N, high[k], k) <= eta)
            ck(low[k] <= low[k + 1] and high[k] <= high[k + 1])
        ck(all(low[k] <= high[k] for k in range(N + 1)))
        ck(high == [1 - low[N - k] for k in range(N + 1)])
        for record in row['calibration']:
            p = F(record['p'])
            masses = [binomial_mass(N, p, k) for k in range(N + 1)]
            lf = sum((masses[k] for k in range(N + 1) if p < low[k]), F(0))
            uf = sum((masses[k] for k in range(N + 1) if p > high[k]), F(0))
            ck(lf == F(record['lower_failure']) <= eta)
            ck(uf == F(record['upper_failure']) <= eta)
            ck(lf + uf <= 2 * eta and sum(masses) == 1)
        if N > 8:
            continue
        for unknown in (set(), {2}, {0, 1, 2}):
            record = models[model_index]
            model_index += 1
            ck(record['n'] == N and record['unknown_states'] == sorted(unknown))
            reference = [F(2, 5), F(2, 5), F(1, 5)]
            payoff = [F(1, 14), F(1, 7), F(1)]
            a = [F(0) if j in unknown else payoff[j] for j in range(3)]
            b = [F(1) if j in unknown else payoff[j] for j in range(3)]
            p = expectation(reference, payoff)
            # One uniform produces four nested indicator outcomes. Enumerate
            # multinomial counts rather than the author's sequential DP.
            probabilities = [
                expectation(reference, [1 - v for v in b]),
                expectation(reference, [b[j] - payoff[j] for j in range(3)]),
                expectation(reference, [payoff[j] - a[j] for j in range(3)]),
                expectation(reference, a)]
            ck(sum(probabilities) == 1 and min(probabilities) >= 0)
            bad = total = F(0)
            states = 0
            for c0 in range(N + 1):
                for c1 in range(N - c0 + 1):
                    for c2 in range(N - c0 - c1 + 1):
                        c3 = N - c0 - c1 - c2
                        counts = (c0, c1, c2, c3)
                        pr = F(factorial(N))
                        for count, probability in zip(counts, probabilities):
                            pr *= probability ** count / factorial(count)
                        kminus, k, kplus = c3, c2 + c3, c1 + c2 + c3
                        ck(kminus <= k <= kplus)
                        total += pr
                        states += 1
                        if p < low[kminus] or p > high[kplus]:
                            bad += pr
            ck(total == 1 and states == record['joint_states'])
            ck(p == F(record['true_normalized_mean']))
            ck(bad == F(record['failure_probability']) <= 2 * eta)
    ck(model_index == len(models))
    for record in boxes:
        T, b = F(record['T']), F(record['b'])
        blo, bhi, m1lo, m1hi, m2lo, m2hi = map(F, record['box'])
        ck(T > 0 and 0 <= blo <= b <= bhi)
        ck(0 <= m1lo <= m1hi and 0 <= m2lo <= m2hi)
        if bhi <= T:
            lower = upper = F(0)
        else:
            upper = max(F(0), min(F(1, 4),
                m2hi / max(T, blo) - (m1lo / bhi) ** 2))
            lower = (max(F(0), m2lo / bhi - (m1hi / blo) ** 2)
                     if blo > T else F(0))
        ck(lower == F(record['lower']) and upper == F(record['upper']))
        ck(lower <= F(record['true']) <= upper <= F(1, 4))
        if b <= T:
            ck(F(record['true']) == 0)
    tilt = saved['tilt']
    P, q, qdef = [list(map(F, tilt[key]))
                 for key in ('reference', 'density', 'defensive_density')]
    ck(expectation(P, q) == expectation(P, qdef) == 1)
    ck(1 / q[0] == F(tilt['event_bound']))
    ck(1 / q[1] == F(tilt['unknown_inverse_weight']) > F(tilt['event_bound']))
    ck(max(1 / v for v in qdef) <= F(tilt['defensive_bound']))
    counter = saved['unknown_countercheck']
    ck(counter['correct_unknown_interval'] == ['0', '1'])
    ck(F(counter['naive_unknown_as_outside_upper']) < 1
       and F(counter['naive_coverage_probability']) == 0)
    return {'tables': len(tables), 'joint_count_models': len(models),
            'moment_boxes': len(boxes)}


def atanh_log_interval(x, terms):
    z = (x - 1) / (x + 1)
    partial = 2 * sum((z ** (2 * j + 1) / (2 * j + 1)
                       for j in range(terms)), F(0))
    tail = 2 * abs(z) ** (2 * terms + 1) / ((2 * terms + 1) * (1 - z * z))
    return partial - tail, partial + tail


def fresh_integral():
    # Generic Taylor integral: no private source parameter or program dependency.
    lo, hi = atanh_log_interval(F(2), 64)
    ck(F(11, 16) < lo <= hi < 1)
    # Integral_[1/4,1] [t-1/2+1/(8t)-1/(48t^2)] dt:
    polynomial = F(1, 2) * (1 - F(1, 16)) - F(1, 2) * (1 - F(1, 4))
    reciprocal = F(1, 48) * (1 - 4)
    ck(polynomial + reciprocal == F(1, 32))
    I_lower = polynomial + reciprocal + lo / 4
    ck(2 * I_lower == F(1, 16) + lo / 2)
    ck(1 - 2 * I_lower < F(19, 32))


def saved_hall(root):
    saved = json.loads((root / 'hall_results.json').read_text())
    ck(saved['schema'] == 'R89-public-neutral-mixture-v1')
    ck('cap a valid upper' in saved['identities']['unknown'])
    ck(len(saved['stages']) == 3)
    states = 0
    stage_counts = {}
    for stage in saved['stages']:
        begin = COUNT
        n, gamma, pad = stage['dimension'], F(stage['gamma']), F(stage['pad'])
        Y = [[F(3, 4), F(5, 4)], [F(5, 4), F(3, 4)], [F(1), F(1)]]
        U = [[v + pad for v in row] for row in Y]
        Z = [sum(v * v for v in row) / 2 for row in U]
        threshold = F(6, 5) ** n
        M = min(1 / gamma, max(3 * z ** n / ((1 - gamma) * threshold ** 2) for z in Z))
        ck(list(map(F, stage['Z'])) == Z and F(stage['lambda']) == threshold)
        ck(F(stage['global_bound']) == 1 / gamma and F(stage['event_cover_bound']) == M)
        totals = [F(0)] * 6
        ck(len(stage['records']) == 2 ** n)
        for bits, record in zip(product((0, 1), repeat=n), stage['records']):
            def multiply(values):
                result = F(1)
                for v in values:
                    result *= v
                return result
            ys = [multiply(Y[j][b] for b in bits) for j in range(3)]
            us = [multiply(U[j][b] for b in bits) for j in range(3)]
            qs = [multiply(U[j][b] ** 2 / Z[j] for b in bits) for j in range(3)]
            q = gamma + (1 - gamma) * sum(qs) / 3
            w = 1 / q
            event, cover = max(ys) > threshold, max(us) >= threshold
            unknown = cover and sum(bits) % 3 == 1
            a = w if event and not unknown else F(0)
            b = w if (event or unknown) and cover else F(0)
            ck(record['bits'] == list(bits) and F(record['q']) == q and F(record['rn']) == w)
            ck((record['event'], record['cover'], record['unknown']) == (event, cover, unknown))
            ck(F(record['a']) == a and F(record['b']) == b)
            ck(0 <= a <= w * event <= b <= M and q >= gamma)
            ck(not event or cover)
            ck(not cover or w <= M)
            # Full marginal mixture, never the sampled latent component.
            p = F(1, 2 ** n)
            for j, value in enumerate((q, q * w, event, cover, q * a, q * b)):
                totals[j] += p * value
            states += 1
        keys = ('normalization_exact', 'rn_integral_exact', 'event_probability_exact',
                'cover_probability_exact', 'expected_lower', 'expected_upper')
        ck(totals == [F(stage[key]) for key in keys])
        ck(totals[0] == totals[1] == 1 and totals[4] <= totals[2] <= totals[5])
        ck(F(stage['unknown_weight_exact']) == totals[5] - totals[4])
        # A separately truncated exact log enclosure, not producer's sqrt routine.
        base_lo, base_hi = atanh_log_interval(F(15, 16), 110)
        two_lo, two_hi = atanh_log_interval(F(2), 110)
        log_lo, log_hi = base_lo + 6 * two_lo, base_hi + 6 * two_hi
        ck(F(stage['delta']) == F(1, 20))
        radius = F(stage['radius_upper_exact'])
        N = stage['hypothetical_iid_holdout_N']
        ck(N > 0 and radius >= 0 and radius * radius >= M * M * log_hi / (2 * N))
        ck(radius * radius <= M * M * log_lo / (2 * N) + F(1, 2 ** 85))
        stage_counts[str(n)] = COUNT - begin
    ck(states == 84)
    return {'finite_states': states, 'stage_assertions_by_dimension': stage_counts}


def main():
    started = time.perf_counter()
    for name, size, scale, N, eta, r, delta, Q in (
        ('pilot', 4, 5, 8, F(1, 32), F(1, 2), F(1, 16), [F(1, 3)] * 3),
        ('pressure', 9, 20, 12, F(1, 100), F(1, 3), F(1, 4),
         [F(1, 1000), F(998, 1000), F(1, 1000)]),
        ('expanded', 17, 60, 24, F(1, 1000), F(1, 4), F(1, 4),
         [F(1, 7), F(2, 7), F(4, 7)])):
        begin = COUNT
        finite_rn(size, scale)
        binomial_checks(N, eta)
        finite_hoeffding(N, r, delta, Q)
        moment_boxes(scale)
        rank_envelope((1, N, 2 * N), size)
        coupled_observable()
        uniform_moments([F(1), F(1, size), F(1, scale)])
        uniform_moments([F(1, size)] * size)
        for n in (N, N + 1):
            beta_harmonic(n)
        enormous_dimension({'pilot': 128, 'pressure': 256, 'expanded': 1024}[name])
        kernel_pressure({'pilot': 12, 'pressure': 20, 'expanded': 30}[name])
        hopf({'pilot': 2, 'pressure': 5, 'expanded': 11}[name])
        STAGES[name] = COUNT - begin
    event_only_pressure()
    annular_constants()
    fresh_integral()
    root = Path(__file__).resolve().parent
    data = saved_parent(root)
    data['hall'] = saved_hall(root)
    if (root / 'proof.md').exists():
        proof = (root / 'proof.md').read_text()
        fences = re.findall(r'^```python\n(.*?)^```\s*$', proof, re.M | re.S)
        ck(len(fences) == 1)
        ck(fences[0].encode() == Path(__file__).read_bytes())
        tex = (root / 'proof.tex.txt').read_text()
        for text in (proof, tex):
            ck(not any(ord(c) < 32 and c not in '\n\t' for c in text))
        data['archive_fence_identity'] = 'PASS'
    print(json.dumps({'status': 'PASS', 'assertions': COUNT, 'stages': STAGES,
                      'saved_data': data,
                      'scope': 'NONPHYSICAL RN/unknown, probability interval, fixed-fibre moment-box, rank/coupled observable, annular/Hopf and Levy-certificate arithmetic only; no original gate, physical input or general cube certificate.',
                      'elapsed_seconds': time.perf_counter() - started}, sort_keys=True))


if __name__ == '__main__':
    main()
```
