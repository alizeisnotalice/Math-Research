from fractions import Fraction as F
from itertools import product
from math import factorial
counts={'source_divergence':0,'moment_identity':0,'spatial_screen':0}
positive=0
m=[F(1),F(2),F(4),F(8)]
q=[F(3,4),F(1),F(3,4),F(1)]
alpha=F(1,10); beta=F(4,5)
for weights,mode,phi in product(product((1,2,3),repeat=4),range(3),((F(0),F(1),F(2),F(3)),(F(3),F(1),F(0),F(2)))):
    rho=[F(w,7) for w in weights]
    ranks=[sum(rho[j] for j in range(4) if m[j]<=m[i]) for i in range(4)]
    edges={}
    for u,v in product(range(4),repeat=2):
        mark=F((u+v+mode)%3,2)
        if m[u]>2*m[v] and alpha<ranks[v]/ranks[u]<beta:
            edges[u,v]=rho[u]*rho[v]*q[u]*mark/ranks[u]
    r=[sum(g for (a,b),g in edges.items() if a==u)/rho[u] for u in range(4)]
    c=[sum(g for (a,b),g in edges.items() if b==u)/rho[u] for u in range(4)]
    G=sum(edges.values(),F(0))
    assert sum(r[u]*rho[u] for u in range(4))==G==sum(c[u]*rho[u] for u in range(4))
    energy=sum(g*(phi[u]-phi[v]) for (u,v),g in edges.items())
    assert energy==sum(phi[u]*(r[u]-c[u])*rho[u] for u in range(4))
    injection=sum(max(r[u]-c[u],F(0))*rho[u] for u in range(4))
    assert injection<=G<=beta*sum(rho)
    assert all(x<=beta for x in r)
    positive+=bool(G)
    counts['source_divergence']+=1

# One bounded screen of a pointwise quadratic-potential assertion.
# Actual cubes and shared source; not a historical/core flow realization.
n=16; Ru=F(2); Rv=F(3,2); b=F(2); a=F(1)
u=[F(0)]*n; v=[F(6,5)]+[F(1,2)]*(n-1)
y=[v[i]-Rv/2+F(1,100) for i in range(n)]
assert all(abs(y[i]-u[i])<Ru/2 and abs(y[i]-v[i])<Rv/2 for i in range(n))
def integral_second(center,R,y):
    return sum(((center[i]+R/2-y[i])**3-(center[i]-R/2-y[i])**3)/(3*R) for i in range(n))
M_u=integral_second(u,Ru,y); M_v=integral_second(v,Rv,y)
center=sum((u[i]-y[i])**2-(v[i]-y[i])**2 for i in range(n))
radial=n*(Ru**2-Rv**2)/12
assert M_u-M_v==center+radial
assert (M_u-M_v)/b**2<0
counts['moment_identity']+=1
# exp(1)<11/4 via a rational Taylor remainder, hence exp(4)<(11/4)^4.
N=10
e_upper=sum((F(1,factorial(j)) for j in range(N+1)),F(0))+F(1,factorial(N+1))/(1-F(1,N+2))
assert e_upper<F(11,4)
assert (Ru/Rv)**n>(F(11,4))**4
counts['spatial_screen']+=1
# Original outside alpha=(1+sqrt(n))^(1/n)=5^(1/16).
assert (2*max(abs(v[i]-u[i]) for i in range(n))/Ru)**n>5
counts['spatial_screen']+=1
r=Rv/Ru
trunc=[max(F(0),(abs(v[i]-u[i])/Ru-(1-r)/2)/r) for i in range(n)]
assert sum(t>0 for t in trunc)>F(n,8)
assert sum(trunc)>F(n,20)
counts['spatial_screen']+=2
beta_bin=1+F(1,n); seff=max(a,Rv/beta_bin)
excess=sum(max(2*abs(v[i]-u[i])-(Ru-Rv),F(0)) for i in range(n))
Bplus=n*((1+beta_bin)*seff-Ru)**2/(4*beta_bin*seff)
assert excess>Bplus
counts['spatial_screen']+=1
print('PASS',counts,'total',sum(counts.values()),'positive_source_rank_cases',positive)
print('quadratic_screen',{'normalized_increment':(M_u-M_v)/b**2,'center':center,'radial':radial})
