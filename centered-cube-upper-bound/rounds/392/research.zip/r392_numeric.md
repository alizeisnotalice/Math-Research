# R392: actual posterior overlap versus shared-source net turnover

Eight bounded n=16 fields provide constructive evidence for joint settlement across a mass-decreasing chain. Receiver centers occupy actual positive-volume boxes. Matching and posterior integrations use one complete compact L1 source. Middle cancellation is enforced through the same **actual middle receiver marginal**, not by replacing a varying receiver field with its center value.

Important limitations: the joint edge kernels are diagnostic, not the original filtered/core/history gamma. Although every edge has the strict original exp(sqrt(16)) mass gap, no original J/h/clock qualification is asserted. In fact f=q=1 on all actual capture cubes, so the source-surplus template is zero: these are **not positive original-G witnesses**. Full W=6^16=2821109907456 is retained. No net-TV estimate is promoted to a G/W or root-budget conclusion.

## Actual source, receivers and direction

Set f=1_Q6 in R^16, lambda=q=1, and radii

R_big=1, R_mid=3/4, R_small=11/20.

Every selected cube and the support of its averaged posterior lie in Q6. Thus actual m=R^16 and actual hard response q=m/R^16=1, with same-full-f cap. A rational Taylor certificate gives 54<exp(4)<55, while both adjacent mass ratios exceed 55. All arrows are **big mass → middle mass → small mass**, consistent with mu>Kmv.

Each full receiver box has side eta=.001, except the partial-corner case eta=.002. Standard centers are big=0, middle=(.03,0,...,0), small=(.05,0,...,0). These are disjoint positive-volume sets and every smaller cube is nested in every corresponding larger cube. Actual receiver volume V=eta^16 is never freely reset. A diagnostic edge has density g/(|E_u||E_v|) on the complete pair rectangle E_u times E_v. The endpoint marginals are checked against actual q du, including the sum of both incident directions.

For balanced chains both integrated edge weights are g=V/2. For a second/first weight ratio r, use g1=V/(1+r), g2=r*g1, keeping total edge mass V and the combined middle marginal bounded by q du. The single-edge baseline uses g=V/2. Full actual Xq is the sum of the true receiver volumes (2V for one edge, 3V for full chains).

## Exact per-edge source overlap with real center integration

For an actual receiver center x,

pi_x(z)=1_Q_R(x)(z)/R^16.

Since mu>mv, the common identical source mass on an edge is

j(u,v)=integral f min(pi_u,pi_v)=|Q_Ru(u) intersect Q_Rv(v)|/mu.

The exact mean of j under the real product center boxes is computed by tensorization. In one dimension, the difference of two uniform center coordinates has density ell(width_u,width_v;t)/(width_u width_v), and the source interval overlap is ell(Ru,Rv;center_difference+t). Their product is piecewise quadratic. The script partitions at every plateau/support breakpoint and integrates it by exact Simpson identities. This is exact polynomial integration over true center intervals, not numerical Simpson sampling or center-value quadrature. The 16-dimensional mean is the product of the one-dimensional integrals, divided by the actual larger mass.

Per-edge turnover is gamma_e*(1-mean j_e). In the standard nested chain,

mean j_big,mid=(3/4)^16=.0100225957576,
mean j_mid,small=(11/15)^16=.00699556534478.

Thus the two edge turnovers sum to 1.98298183890*g. Containment has not removed the density-renormalization turnover: min of the two normalized posteriors uses the larger denominator.

## Matched actual middle marginal, not only matched mass

Let bar_pi_i denote the posterior averaged over its actual receiver box. For the balanced product-edge chain, the target-middle receiver marginal of the first edge is exactly the same measure g*du/|E_mid| as the source-middle marginal of the second. Therefore the **full continuum source field** cancels pointwise:

D_source(z)=g bar_pi_big(z)-g bar_pi_mid(z)
            +g bar_pi_mid(z)-g bar_pi_small(z)
          =g[bar_pi_big(z)-bar_pi_small(z)].

This cancellation can be disintegrated using the same actual middle receiver and then its true pi_v, not just a nominal center. It supplies an explicit common middle source mass g in a shared-source settlement. With unequal weights, min(g1,g2) of that same middle marginal can cancel, while coefficient g2-g1 remains. The exact signed coefficients are recorded.

The reported net turnover is integral f(D_source)_+, equivalently half the L1 norm because the signed source field has zero total mass. It is the unmatched mass after maximal common-source settlement of the **aggregated source marginals**. A diagonal common-density coupling plus a product coupling of the residuals constructs such a source settlement. This is not a claim that arbitrary re-coupling preserves the original edge/history/source labels or supplies an admissible original marked flow transition.

## Rigorous full-source bounds without an exponential source grid

An averaged posterior of a receiver box with coordinate widths w_i equals 1/m on the source core box of widths R-w_i, vanishes off the support box of widths R+w_i, and is bounded between 0 and 1/m in its ramps. These are actual tensor convolution bounds.

The complete Q6 source is partitioned by membership in every group core/support box. Tensor coordinates are integrated by a signature DP: a box contains a source point iff every coordinate interval contains it, so coordinate signatures combine by bitwise AND. There are at most 2^(2*groups) states, and the exact state volumes sum to 6^16. All source outside the receiver posterior supports is retained in the zero signature, not discarded. The examples use only 5–19 nonzero signatures.

For signed coefficients a_i, source lower/upper densities use the core/support lower/upper for positive coefficients and reverse them for negative coefficients. Integrating their positive parts gives valid net-turnover bounds. An additional normalized-marginal certificate sharpens them: positive and negative mixtures each have the exact same total Mplus; their common-source overlap is bounded by the min of their density envelopes. Hence net turnover equals Mplus minus that common mass. The independent triangle bound from the exact per-edge turnovers is also retained. These are Fraction **enclosures**, not assertions that a stepped envelope is the true averaged posterior.

## Quantitative results and the balance decision

All quantities in this table are divided by the first edge mass g1; for unequal weights this normalization changes, and the actual weights/total are retained in the JSON.

| field | sum of per-edge turnovers/g1 | net source turnover/g1 | shared settlement gain/g1 |
|---|---:|---:|---:|
| single big→mid | .9899774042 | [.9897614374,.9899774042] | [0,.000215967] |
| balanced standard chain | 1.9829818389 | [.9999278186,.9999318984] | [.9830499405,.9830540203] |
| second edge half weight | 1.4864796216 | [.9897614374,.9901890947] | [.4962905269,.4967181842] |
| second edge 3/2 weight | 2.4794840562 | [1.4963268828,1.4965344935] | [.9829495627,.9831571734] |
| equal weights, different middle marginals | 1.9829818389 | [.9992611519,1.0005985650] | [.9823832739,.9837206870] |
| nested corner shift | 1.9829818389 | [.9999278186,.9999318984] | [.9830499405,.9830540203] |
| partial corner overlap | 1.9888781380 | [.9999739475,.9999769921] | [.9889011459,.9889041904] |
| far corner | 1.9999999993 | exactly 1 | exactly .9999999993 |

The single-edge interval shows that averaging real receiver locations alone could explain at most .000216g of improvement here. The balanced two-edge improvement is about .98305g, so it is a genuine shared middle-source cancellation effect, not an artifact of center sampling. Relative to total edge mass 2g, the standard net is about one half while separate edge turnover is about .99149 of that total. Unequal weights retain an actual middle imbalance, and the exact source coefficient must remain in the ledger.

For the middle-marginal mismatch case the first edge ends uniformly on the left half of the actual middle receiver box, whereas the second starts uniformly on its right half. Both edge totals are g, but their receiver distributions differ. This still respects q du capacity: each half carries its own corresponding marginal. The averaged middle source posteriors are shifted trapezoids with exact TV

TV(bar_pi_mid_left,bar_pi_mid_right)=eta/(2Rmid)=1/1500>0.

An independent exact piecewise-linear integral verifies this identity. Thus the middle term is not zero. Reverse triangle gives its effect on the net turnover at most g/1500, used to sharpen the displayed enclosure. The intervals do not prove the actual net necessarily increases; the point is that equality of totals alone cannot justify erasing the middle posterior.

Corner variants keep real cube intersections. Nested-corner centers are .08 and .14 in every coordinate, partial-corner centers .14 and .26, and far-corner centers .65 and 1.10. In the far case both edges satisfy the tested original outside inequality over their full pair boxes, each adjacent posterior overlap is still strictly positive (about 4.31e-11 and 6.54e-10), and endpoint averaged source supports are disjoint. The balanced middle cancellation then gives net turnover **exactly g**, versus almost 2g separately. All such spatial facts remain diagnostic because the uniform source makes the original surplus-template cost zero and no original history/core is implemented.

This does not change the per-edge common density j_uv or contradict the auxiliary cut identity: j remains small on every far-mass edge. Nor does small net endpoint TV pay the logarithmically integrated mass-cut boundary term. In a balanced chain the mass-ratio logarithms telescope to the full endpoint logarithmic span, so removing the intermediate source divergence does not remove that cut/coarea price. A proof may use global cancellation only with a justified common joint settlement and its remaining labels/budget, not by replacing original per-edge turnover with this different quantity.

## Reproduction and scope

Run `python3 r392_numeric.py`. Only the Python standard library is required. The script is self-contained, uses no old /tmp imports, optimizer, Monte Carlo, receiver quadrature or source point sampling, and writes `r392_numeric.result.json` beside itself. Stages are one initial single-edge field, four balance/imbalance/marginal fields, and three expanded offsets. No extra dimensions, optimizer or fitted exponent are used.

**665 exact Fraction assertions** passed: 466 actual geometry, 27 exact edge-overlap integrations/checks, 118 source-envelope checks, 54 joint-balance/capacity checks. Cached repeated 1D formulas are counted as executed checks, not distinct theorems. A second fresh process reproduced result bytes. Table decimals display rational certificates, not additional float evidence. Full source W, real Xq, actual direction and all diagnostic restrictions are in the result. Only owned R392 files changed; no repository/Git edits.
