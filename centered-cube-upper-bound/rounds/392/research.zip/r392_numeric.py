"""R392 real posterior geometry and diagnostic mass-decreasing joint chains.
Exact Fraction source-cut enclosures, no old imports or receiver point sampling.
"""
from fractions import Fraction as F
from pathlib import Path
from math import factorial
from functools import lru_cache
import json,hashlib
N=16
COUNTS={'actual_geometry':0,'edge_overlap':0,'source_envelope':0,'joint_balance':0}
def ck(v,k):
 assert v,k
 COUNTS[k]+=1

def prod(xs):
 out=F(1)
 for x in xs:out*=x
 return out

def trap(a,b,x):return max(F(0),min(a,b,(a+b)/2-abs(x)))
@lru_cache(None)
def mean_overlap_1d(ca,wa,ra,cb,wb,rb):
 # Integral over two actual center intervals, via their exact difference law.
 d=ca-cb;U=(wa+wb)/2;u=abs(wa-wb)/2
 V=(ra+rb)/2;v=abs(ra-rb)/2
 cuts=sorted(set([-U,-u,u,U]+[x-d for x in [-V,-v,v,V] if -U<=x-d<=U]))
 fun=lambda x:trap(wa,wb,x)*trap(ra,rb,d+x)
 total=sum(((b-a)*(fun(a)+4*fun((a+b)/2)+fun(b))/6 for a,b in zip(cuts,cuts[1:])),F(0))/(wa*wb)
 ck(0<=total<=min(ra,rb),'edge_overlap')
 return total

def group(name,R,center,widths):
 ck(len(center)==N and len(widths)==N and all(0<w<R for w in widths),'actual_geometry')
 for c,w in zip(center,widths):ck(abs(c)+(R+w)/2<3,'actual_geometry')
 return {'name':name,'R':R,'center':center,'widths':widths,'volume':prod(widths),'mass':R**N}

def overlapavg(A,B):
 value=prod(mean_overlap_1d(ca,wa,A['R'],cb,wb,B['R']) for ca,wa,cb,wb in zip(A['center'],A['widths'],B['center'],B['widths']))/max(A['mass'],B['mass'])
 ck(0<value<=1,'edge_overlap')
 return value

def source_profiles(groups):
 # Complete Q6 partition compressed by AND of coordinate membership signatures.
 # Each group contributes core/support boxes bounding its true averaged posterior.
 bits=2*len(groups);allmask=(1<<bits)-1;states={allmask:F(1)}
 for axis in range(N):
  boxes=[]
  for G in groups:
   for sign in [-1,1]:
    side=G['R']+sign*G['widths'][axis];c=G['center'][axis]
    boxes.append((c-side/2,c+side/2))
  cuts=sorted(set([F(-3),F(3)]+[x for box in boxes for x in box]))
  patterns={}
  for a,b in zip(cuts,cuts[1:]):
   mid=(a+b)/2;mask=sum((1<<j for j,(l,r) in enumerate(boxes) if l<mid<r),0)
   patterns[mask]=patterns.get(mask,F(0))+(b-a)
  nxt={}
  for old,vold in states.items():
   for mask,width in patterns.items():
    key=old&mask;nxt[key]=nxt.get(key,F(0))+vold*width
  states=nxt
 ck(sum(states.values(),F(0))==6**N,'source_envelope')
 return states

def net_bounds(groups,coeff,edge_turn):
 states=source_profiles(groups);lo=hi=F(0);commonlo=commonhi=F(0)
 for mask,vol in states.items():
  low=high=F(0);pl=pu=nl=nu=F(0)
  for i,G in enumerate(groups):
   L=F(1,G['mass']) if mask&(1<<(2*i)) else F(0)
   U=F(1,G['mass']) if mask&(1<<(2*i+1)) else F(0)
   a=coeff[i]
   low+=a*(L if a>=0 else U);high+=a*(U if a>=0 else L)
   if a>=0:pl+=a*L;pu+=a*U
   else:nl+=(-a)*L;nu+=(-a)*U
  ck(low<=high,'source_envelope')
  lo+=vol*max(F(0),low);hi+=vol*max(F(0),high)
  commonlo+=vol*min(pl,nl);commonhi+=vol*min(pu,nu)
 # Source posterior normalization gives integral actual signed density zero.
 ck(sum(coeff,F(0))==0,'joint_balance')
 Mpos=sum((a for a in coeff if a>0),F(0))
 ck(0<=commonlo<=commonhi and commonlo<=Mpos,'source_envelope')
 lo=max(lo,Mpos-commonhi,F(0));hi=min(hi,Mpos-commonlo,Mpos,edge_turn) # exact marginal mass normalization + triangle
 ck(0<=lo<=hi<=edge_turn,'source_envelope')
 return lo,hi,len(states)

def middle_mismatch_tv(eta,R):
 # Left/right half-center boxes: only first-coordinate center law differs.
 # Averaged posterior is a translated trapezoid, shift eta/2, width eta/2.
 width=eta/2;left=-eta/4;right=eta/4
 edges=[]
 for c in [left,right]:
  edges +=[c-(R+width)/2,c-(R-width)/2,c+(R-width)/2,c+(R+width)/2]
 cuts=sorted(set(edges+[F(0)]))
 fun=lambda z:trap(width,R,z-left)/(width*R)-trap(width,R,z-right)/(width*R)
 ans=F(0)
 for a,b in zip(cuts,cuts[1:]):
  va,vb=fun(a),fun(b)
  if va>=0 and vb>=0:ans+=(b-a)*(va+vb)/2
  elif va<=0 and vb<=0:pass
  else:
   root=a+(b-a)*(-va)/(vb-va)
   if va>0:ans+=(root-a)*va/2
   else:ans+=(b-root)*vb/2
 ck(ans==eta/(2*R)>0,'source_envelope')
 return ans

explo=sum((F(4**j,factorial(j)) for j in range(41)),F(0))
exphi=explo+F(4**41,factorial(41))/(1-F(4,42))
ck(54<explo<exphi<55,'actual_geometry')

def case(name,style,eta=F(1,1000),ratio=F(1),single=False,mismatch=False):
 Rsmall=F(11,20);Rmid=F(3,4);Rbig=F(1);V=eta**N
 ck((Rbig/Rmid)**N>55 and (Rmid/Rsmall)**N>55,'actual_geometry')
 if style=='standard':cb=[F(0)]*N;cm=[F(3,100)]+[F(0)]*(N-1);cs=[F(1,20)]+[F(0)]*(N-1)
 elif style=='corner_nested':cb=[F(0)]*N;cm=[F(2,25)]*N;cs=[F(7,50)]*N
 elif style=='corner_partial':cb=[F(0)]*N;cm=[F(7,50)]*N;cs=[F(13,50)]*N
 elif style=='corner_far':cb=[F(0)]*N;cm=[F(13,20)]*N;cs=[F(11,10)]*N
 else:raise ValueError(style)
 B=group('big',Rbig,cb,[eta]*N)
 M=group('middle',Rmid,cm,[eta]*N)
 S=group('small',Rsmall,cs,[eta]*N)
 if single:
  groups=[B,M];g=V/2;edges=[(0,1,g)];middle_balanced=False;g1=g;g2=F(0);middleTV=F(0)
 elif mismatch:
  ck(ratio==1,'joint_balance')
  cl=list(cm);cr=list(cm);cl[0]-=eta/4;cr[0]+=eta/4;ww=[eta/2]+[eta]*(N-1)
  ML=group('middle_left',Rmid,cl,ww);MR=group('middle_right',Rmid,cr,ww)
  groups=[B,ML,MR,S];g1=g2=V/2;edges=[(0,1,g1),(2,3,g2)];middle_balanced=False
  middleTV=middle_mismatch_tv(eta,Rmid)
 else:
  groups=[B,M,S];g1=V/(1+ratio);g2=ratio*g1;edges=[(0,1,g1),(1,2,g2)];middle_balanced=ratio==1;middleTV=F(0)
 coeff=[F(0)]*len(groups);edge_turn=F(0);records=[]
 for u,v,g in edges:
  A,C=groups[u],groups[v]
  ck(A['mass']>55*C['mass'],'actual_geometry')
  coeff[u]+=g;coeff[v]-=g
  ov=overlapavg(A,C);tv=g*(1-ov);edge_turn+=tv
  distmin=max(max(F(0),abs(x-y)-(wx+wy)/2) for x,y,wx,wy in zip(A['center'],C['center'],A['widths'],C['widths']))
  outside=(2*distmin/A['R'])**N>5
  records.append({'from':A['name'],'to':C['name'],'gamma':str(g),'true_pair_mean_posterior_overlap':str(ov),'edge_turnover':str(tv),'outside_gate_all_pairs':outside})
 for i,G in enumerate(groups):
  marginal=sum((g for u,v,g in edges if i in [u,v]),F(0))
  ck(marginal<=G['volume'],'joint_balance') # actual q=1, both-endpoint bound
 if middle_balanced:
  ck(coeff[1]==0 and edges[0][1]==edges[1][0],'joint_balance')
  full_middle_cancel=g1
 else:full_middle_cancel=F(0)
 netlo,nethi,npatterns=net_bounds(groups,coeff,edge_turn)
 mismatch_allowance=F(0)
 if mismatch:
  endcoeff=[F(0)]*len(groups);endcoeff[0]=g1;endcoeff[-1]=-g1
  elo,ehi,_=net_bounds(groups,endcoeff,g1)
  mismatch_allowance=g1*middleTV
  netlo=max(netlo,elo-mismatch_allowance,F(0));nethi=min(nethi,ehi+mismatch_allowance)
  ck(netlo<=nethi<=edge_turn,'source_envelope')
 total=sum((g for _,_,g in edges),F(0))
 gainlo=edge_turn-nethi;gainhi=edge_turn-netlo
 ck(0<=gainlo<=gainhi and nethi<=total,'joint_balance')
 X=sum((G['volume'] for G in groups),F(0))
 ck(2*total<=X,'joint_balance')
 out={'name':name,'n':N,'style':style,'eta':str(eta),'weight_ratio_second_over_first':str(ratio),
  'actual_direction':'big mass -> middle mass -> small mass' if not single else 'big mass -> middle mass',
  'full_source_f':'1_Q6','full_W':str(6**N),'actual_Xq':str(X),'all_q':'1',
  'source_surplus_template_on_actual_cubes':'0 (f=q=1); no positive original G claim',
  'edges':records,'sum_edge_turnovers':str(edge_turn),'net_source_turnover_bounds':[str(netlo),str(nethi)],
  'shared_settlement_gain_bounds':[str(gainlo),str(gainhi)],
  'common_source_mass_bounds':[str(total-nethi),str(total-netlo)],
  'middle_receiver_marginals_match_completely':middle_balanced,
  'full_middle_posterior_mass_cancelled':str(full_middle_cancel),
  'matched_middle_mass_can_cancel_exactly':str(min(g1,g2)) if not mismatch and not single else '0',
  'unmatched_middle_mass':str(abs(g2-g1)) if not mismatch and not single else 'not determined by totalmass alone',
  'middle_mass_imbalance':str(g2-g1) if not mismatch and not single else 'not the balance criterion for split-marginal case',
  'middle_equal_total_but_marginal_mismatch':mismatch,
  'middle_posterior_mismatch_TV':str(middleTV),'middle_mismatch_triangle_allowance':str(mismatch_allowance),
  'signed_source_coefficients':{G['name']:str(a) for G,a in zip(groups,coeff)},
  'complete_core_support_source_signatures':npatterns,
  'normalization_gamma_first':str(g1),
  'edge_turnover_over_gamma_first':str(edge_turn/g1),
  'net_turnover_over_gamma_first_bounds':[str(netlo/g1),str(nethi/g1)],
  'gain_over_gamma_first_bounds':[str(gainlo/g1),str(gainhi/g1)]}
 return out

def main():
 stages={'single_edge':[case('single_big_mid','standard',single=True)],
 'balanced_and_imbalance':[case('balanced_chain','standard'),case('second_half_weight','standard',ratio=F(1,2)),case('second_3over2_weight','standard',ratio=F(3,2)),case('same_total_different_middle_marginals','standard',mismatch=True)],
 'expanded_offsets':[case('nested_corner','corner_nested'),case('partial_corner','corner_partial',F(1,500)),case('far_corner','corner_far')]}
 result={'scope':'Actual positive-volume receiver boxes and full uniform compact L1 source with q=1,m=R^16. Diagnostic fixed joint edge measures on pair rectangles satisfy combined endpoint marginal<=qdu but are not original filtered/core/history traffic. Each edge is mass-decreasing with exact strict exp4 gap. Whole-source posterior net turnover is rigorously enclosed via tensor core/support bounds, not point samples. Full W retained; f=q makes original surplus-template cost zero. No generic G/W/root conclusion.',
 'fraction_assertions':COUNTS,'total_assertions':sum(COUNTS.values()),'stages':stages}
 Path(__file__).with_suffix('.result.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',COUNTS,'total',sum(COUNTS.values()))
 for cs in stages.values():
  for c in cs:print(c['name'],'source signatures',c['complete_core_support_source_signatures'])
if __name__=='__main__':main()
