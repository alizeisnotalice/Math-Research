# R329 — common-source quadratic optimization interface; no new root receipt

**Status.** No general estimate of the small-atom/continuous remainder at root dimension is proved here. The useful checkpoint is an overlap-preserving concave upper optimization for the *original full* hard-matched quantity, with an explicit sufficient dual certificate. Its geometric certificate remains unproved. This interface is not counted as a newly paid sub-integral.

## 1. Freeze the actual hard-matched slot

Assume exactly the R328 hard slot: `β=f dx`, `0≤ν≤f dx`, `α=1,s=0,L=R`, `f≥0` in `L¹`, finite actual receiver set `E`, `0<a≤R(u)≤b≤2a`, and

\[
 c_u(y)=1_{Q_{R(u)}(u)}(y),\qquad
 q(u)=R(u)^{-n}\int c_u(y)f(y)dy\in[q_-,\lambda],\quad q_-=3\lambda/4.
\]

Set `X=λ|E|`, `A_n=1+n log(b/a)`, `H>0`, and retain

\[
 U_y(u)=\frac{1_E(u)c_u(y)}{q(u)R(u)^n},\quad
 J_y(r)=\int_{R(u)\le r}U_y(u)du,\quad
 A_{yz}(r)=\int_{R(u)\le r}U_y(u)c_u(z)du,
\]
\[
 \ell(dr)=b^{-n}\delta_b(dr)+nr^{-n-1}1_{[a,b]}(r)dr,
 \qquad Y_r=\{y:J_y(r)\ge H\}.
\]

All physical atoms, the inclusive terminal atom, and every previously paid receiver block stay in these prefixes. No reset of `α`, source history, or receiver selector occurs.

Freeze `E,R,q`. Define the *same actual* operator

\[
 Tg(u)=R(u)^{-n}\int c_u(y)g(y)dy,\qquad u\in E,
 \quad \mathcal G=\{g\in L^1:g\ge0,\ Tg=q\text{ a.e. on }E\}.       \tag{1}
\]

Then `f∈G`; `U,J,A,Y_r` and the original crossing/small-atom masks do not vary with `g∈G`. This is a variational relaxation of the fixed hard slot. It asserts no realization of an additional historical source contract by every competing `g`.

The R328 remaining innovation is linear with a nonnegative coefficient in `ν`. Thus

\[
 I_{\rm rem}(f,\nu)\le I_{\rm rem}(f,f)\le B_H(f,f),\qquad
 B_H(g,g)=\int\ell(dr)\int_{Y_r}g(y)dy\int g(z)
       \left(A_{yz}(r)-\frac{A_{yz}(r)^2}{J_y(r)}\right)dz.       \tag{2}
\]

This route bounds the full original `B_H`. A successful receipt would replace that full slot; it must not be added to its already-paid crossing and large-atom pieces.

## 2. Exact common-source square and its two discarded credits

The constraint `Tg=q` gives, for every `g∈G`,

\[
 \int g(z)A_{yz}(r)dz=V_y(r):=\int_{E\cap\{R\le r\}}c_u(y)du.
\]

Consequently define the fixed linear coefficient and fixed symmetric kernel

\[
 a(y)=\int\ell(dr)1_{Y_r}(y)V_y(r),
\]
\[
 K(y,z)=\int\ell(dr)\frac{1_{Y_r}(y)1_{Y_r}(z)A_{yz}(r)^2}
                              {\sqrt{J_y(r)J_z(r)}},\qquad
 Q(g)=\iint g(y)K(y,z)g(z)dydz.                              \tag{3}
\]

Integrands outside `Y_r×Y_r` are defined as zero. Symmetry `A_yz=A_zy` yields the exact identity

\[
 B_H(g,g)=\int a g-Q(g)-R_{\rm cross}(g)-R_{\rm clock}(g),       \tag{4}
\]

where

\[
 R_{\rm cross}=\int\ell(dr)\int_{Y_r}dy\int_{Y_r^c}dz\,
                 g(y)g(z)\frac{A_{yz}(r)^2}{J_y(r)},
\]
\[
 R_{\rm clock}=\frac12\int\ell(dr)\int_{Y_r\times Y_r}
 g(y)g(z)A_{yz}(r)^2
 \left(\frac1{\sqrt{J_y(r)}}-\frac1{\sqrt{J_z(r)}}\right)^2dydz.
\]

Both credits are nonnegative. Equation (4) follows by averaging `1/J_y` with `1/J_z` on `Y_r×Y_r`; the difference from `1/√(J_yJ_z)` is exactly the displayed square. It neither enlarges the original negative square nor charges it twice.

Moreover `K` is positive semidefinite. Indeed, with

\[
 d\mu(u)=\frac{1_E(u)du}{q(u)R(u)^n},\qquad
 \varphi_{r,u,v}(y)=\frac{1_{Y_r}(y)c_u(y)c_v(y)}{\sqrt{J_y(r)}},
\]

`K` is the Gram kernel of these features under
`ell(dr) 1_{R(u),R(v)≤r} dμ(u)dμ(v)`. This follows by expanding `A_yz(r)²` with its two actual receiver integrations. Therefore

\[
 B_H(g,g)\le\int ag-Q(g)                                    \tag{5}
\]

is a concave quadratic upper problem on the common-source affine cone (1). All terms are finite: `0≤a(y)≤|E|/a^n`, and the hard envelope gives `0≤K(y,z)≤A_n/(q_- a^n)`, where the denominator uses the fixed minimum radius. In particular every `L¹` reference below has finite Gram energy. The bound (5) may lose substantial information through the two explicit credits; usefulness is not automatic.

## 3. A sufficient dual certificate, and exactly what is missing

For `ψ∈L¹(E)` (signed values allowed), the adjoint is

\[
 T^*\psi(y)=\int_E\frac{\psi(u)c_u(y)}{R(u)^n}du.
\]

Let `g_0≥0` belong to `L¹`, not necessarily to `G`, and let `c≥0`. Suppose the following two inequalities hold:

\[
 a(y)-2(Kg_0)(y)\le c+T^*\psi(y)\quad\text{for Lebesgue-a.e. }y,       \tag{6}
\]
\[
 Q(g_0)+\int_E\psi(u)q(u)du\le\varepsilon X.                         \tag{7}
\]

Then every `g∈G` satisfies

\[
 B_H(g,g)\le\varepsilon X+c\|g\|_1.                               \tag{8}
\]

Proof: positivity gives `Q(g−g_0)≥0`, hence
`−Q(g)≤−2⟨Kg_0,g⟩+Q(g_0)`. Apply (6) and `⟨T*ψ,g⟩=⟨ψ,q⟩`, then (7). Absolute Fubini is justified by
`∫g T*|ψ|=∫E |ψ|q≤λ||ψ||₁`; the bounded kernel handles the other pairings.

A root receipt requires a certificate with
`c≤C_ε √A_n log^p(n+2)`. **No such general certificate is constructed here.** The available trivial certificate `g_0=0,ψ=1_E,c=0` only proves `B_H≤∫E q≤X`, because

\[
 a(y)\le\int\ell(dr)V_y(r)
       =\int_E c_u(y)R(u)^{-n}du=T^*1_E(y).
\]

It does not meet (7) for a prescribed small `ε`. Positive semidefiniteness alone supplies the tangent inequality, not a small receiver dual bill. The unresolved geometric step is to construct a reference source and actual-receiver potential satisfying (6)–(7), or to exploit the exact credits in (4) if this concave relaxation is too loose. No effective-rank or overlap lower bound has been inferred from a Schur upper bound.

## 4. Concrete next computation and its certification boundary

The existing full-`ν` Gram integration module can supply an actual-incidence discretization of (3). Freeze a verified cube fixture and its exact `q`; form source-cell masses `m≥0` with the same local mean constraints `Cm=d`. Solve the convex quadratic minimization

\[
 \min_{m\ge0,\ Cm=d}\bigl[m^T K m-a^Tm+c\,\mathbf1^Tm\bigr].
\]

Extract its source reference and receiver dual potentials, and test (6)–(7). This directly tests source mass versus overlap, rather than maximizing a central row independently. A finite solver result is only diagnostic: an actual receipt needs pointwise inequality (6) throughout every source cell and outside any represented source support, with rigorous error bounds for real receiver integration. A sampled matrix or the central-row shell values cannot certify that inequality. If the relaxation loses too much, compare its gap with the two explicitly retained original credits before pursuing it further.

A local Python `Fraction` run checked 24 exact finite-incidence symmetrization identities and 24 exact Schur-square Gram identities. These are algebra checks only, not literal-cube or dimension-budget evidence. No one-dimensional special case is used as progress toward the general target.

Only `/tmp/r329_core.md` is authored. The general root estimate for `I_rem=D_ordered−Z_old−C_small` remains open in this checkpoint.
