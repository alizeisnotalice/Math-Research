# R392 — Screened source-potential candidate and the two unpriced terms

**Outcome:** no new bound for the actual R391 G_core is proved in this note. The existing coefficient 2 on G_core, and the entrance coefficient 4Λ, remain unchanged. No new X_q absorption, W receipt, deletion, or negative-square credit is entered. This bounded screen identifies the specific joint geometric estimates still needed by the candidate below.

## 1. The exact original-source flow and its injection price

Use the actual R391 core, with every original mark fixed. Its exact R389 mass-prefix representation has a measurable mark 0≤χ_core(y,u,v)≤1 containing the old clock average, loss, target/source gates, R385–390 retentions and both final core endpoint indicators. Write

 ρ_y(du)=c_u(y)μ(du),
 dγ_y(u,v)=[q_u χ_core(y,u,v)/T_y(m_u)]ρ_y(du)ρ_y(dv),
 G_core=∫f(y)γ_y(E²)dy.                                   (1)

This uses the same original transported source y. Neither an external witness z nor a uniform cube source is substituted into the original flow.

Define its sourcewise outgoing and incoming densities relative to ρ_y:

 r_y(u)=q_u/T_y(m_u) ∫χ_core(y,u,v)ρ_y(dv),
 c_y(v)=∫q_u χ_core(y,u,v)ρ_y(du)/T_y(m_u).                 (2)

They satisfy ∫r_y dρ_y=∫c_y dρ_y. For any bounded measurable potential Φ_y(u), the exact identity is

 ∫[Φ_y(u)−Φ_y(v)]dγ_y
                  =∫Φ_y(u)[r_y(u)−c_y(u)]ρ_y(du).        (3)

Thus a source potential requires the **positive sourcewise divergence**

                     I(y)=∫(r_y−c_y)_+dρ_y.              (4)

The certified middle-rank row bound gives

 r_y≤λβ,   I(y)≤γ_y(E²)≤λβJ_b(y),
 ∫f(y)I(y)dy≤λβ|E|≤(λβ/q_-)X_q.                          (5)

The last line is an actual receiver-volume price, not a W price. The global receiver column bound C_col does not replace J_b(y) by 1 in (5). The self-supported endpoint occupancy D_core is a sum of the two full-posterior marginals; it does not itself bound their sourcewise signed difference (4). Equation (3) is bookkeeping, not a new theorem paying G_core.

## 2. An accurately normalized spatial candidate

For the original source y and the actual cube Q_u, consider the dimensionless quadratic potential

 Φ_y(u)=b^(−2)[|u−y|²+nR_u²/12].                           (6)

The bracket is exactly the second moment of the uniform cube Q_u about y. It is used only as an explicitly computed test function; it is not a replacement of the actual π_u source law.

For every original edge,

 Φ_y(u)−Φ_y(v)
 =b^(−2)[|u−y|²−|v−y|²+n(R_u²−R_v²)/12].                 (7)

Let r_q=λ/q_- and K=exp(√n). Strict far mass and the true q-band imply

 R_v/R_u<(r_q/K)^(1/n).

Together with R_u≥a and b≤2a, the positive radius term in (7) is strictly larger than

            g_n=n[1−(r_q/K)^(2/n)]/48>0.                 (8)

Hence the exact retained traffic satisfies

 g_n G_core≤D_Φ+C_-,
 D_Φ=∫f(y)dy∫[Φ_y(u)−Φ_y(v)]dγ_y,
 C_-=∫f(y)dy∫[|v−y|²−|u−y|²]_+ b^(−2)dγ_y.              (9)

The positive-part term in (9) is necessary; it has not been paid. All spatial gates remain in χ_core. In particular a proof controlling C_- must use the same original source y, not transfer those gates to the external source of R390's witness lift.

Since c_u(y)=1 on ρ_y, one has 0≤Φ_y(u)≤n/3 there. Applying (3) yields only

 D_Φ≤(n/3)∫f(y)I(y)dy≤(nλβ/3)|E|.                        (10)

Dividing this receiver-volume bound by g_n does not give the desired source budget. A dimension-free or polylogarithmic source price for the relevant injection in (4), together with a compatible joint estimate of C_-, would make (9) useful. Neither estimate has been established. A finite far-chain height or an L^p contraction does not supply either missing price.

## 3. Bounded pointwise screening, not a core counterexample

A single exact geometric screen shows why the center term cannot simply be discarded from this candidate. In dimension n=16 take cube side lengths R_u=2, R_v=3/2, a=1, b=2,

 u=(0,...,0),
 v=(6/5,1/2,...,1/2),
 y_i=v_i−3/4+1/100.

The source y lies strictly in both cubes. Direct rational integration gives

 |u−y|²−|v−y|²=−3843/500,
 n(R_u²−R_v²)/12=7/3,
                    Φ_y(u)−Φ_y(v)=−8029/6000.             (11)

This pair satisfies the original geometric outside condition, all 16 coordinates are truncated, the total normalized truncation exceeds n/20, and it is outside Bplus with the actual β_bin=1+1/n and minimum-radius floor. With constant matched q, its volume/mass ratio exceeds exp(√n). These checks use the same y.

This is not a counterexample to a budget for G_core. The diagnostic has not realized the synchronized high-past, rank, high-density and R391 self-supported core conditions; for instance uniform f realizing constant q does not realize the required surplus source traffic. It only rejects a pointwise nonnegative-increment claim based on the listed geometric cuts alone. A genuinely joint weighted inequality using all the missing conditions is still possible and unproved here.

## 4. Exact scope of the remaining task

The R391 actual γ_core still satisfies its two-endpoint self-support condition with D_core and its half-mass high-density source set. The R390 external three-cube identity and all original mass/rank/spatial marks also remain available. This note neither weakens nor newly pays them.

For the screened candidate, the required advance is a joint geometric estimate of the right side of (9) at the appropriate scale: the sourcewise positive injection must be priced against W, and the negative center displacement must be controlled without moving to a different source law or spending old square credit. Merely defining a new potential, rewriting (3), or repeating the R391 deletion does not establish that estimate. The ledger is left exactly as it was entering this round.

## 5. Executed checks

Executed locally:

    python3 /tmp/r392_geometry_check.py

    PASS {'source_divergence': 486, 'moment_identity': 1,
          'spatial_screen': 5} total 492
    positive_source_rank_cases 486
    normalized_increment −8029/6000

All arithmetic uses Fraction. The first stage verifies the actual ordered-source algebra (2)–(5) for finite atomic rank measures, variable q and nonconstant retained marks; these are conditional-rank diagnostics rather than native full fields. The second stage independently integrates each cube coordinate's second moment and certifies the listed geometric inequalities by rational comparisons. The needed exponential comparison is certified by a rational Taylor upper bound for exp(1), not a floating-point sample. No numerical result is presented as a source budget or as a realization of the complete historical/core contract.
