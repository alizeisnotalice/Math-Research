# R392 — Exact common-source mass-cut balance of the actual core

**Scope.** The result is an atom-safe cut/coarea identity and a quantitative diagnosis of its unpaid term. In the strict far-mass regime, almost all integrated mass-cut flux is carried by source turnover, not by the part of the source density that the two endpoints retain identically. No root source payment is claimed. All statements use the current R391 core; its coefficient 2 in the BH ledger remains unchanged.

## 1. Original edge measure and actual endpoint posteriors

Let γ=γ_core be the positive projection of the fully marked original traffic onto its actual receiver endpoints (u,v). Keep its source, physical-time, fractional and history labels in the underlying measure; the following integrands depend only on their existing endpoint labels. Put G=γ(E×E). On γ-almost every edge,

m_u=f(Q_u)>K m_v, K=exp(√n), m_v=f(Q_v),
m_w=q_wR_w^n, q_-≤q_w≤λ, a≤R_w≤b≤2a.

Write c_w(z)=1_{Q_w}(z), π_w(dz)=f(z)c_w(z)dz/m_w. The new variable z is a full-f endpoint-witness source; it does not replace the original transported source label. Actual receiver integration remains the one in γ, ultimately real du,dv. Define

A_z(u,v)=c_u(z)/m_u, B_z(u,v)=c_v(z)/m_v,
D(z)=∫(A_z+B_z)dγ.

This is precisely the dynamic core occupancy D_core=T_R^*s_core, with s_core≤S and ∫fD=2G. No receiver field or source mass is recomputed.

The R391 core supplies the measurable source set

S_*= {D≥s, f>2T}

with π_w(S_*)≥1/2 for both endpoints of γ-almost every retained edge. Its closed/non-strict endpoint conventions are retained.

## 2. The exact common and turnover densities

For each actual edge set

C_z=c_u(z)c_v(z)/m_u,
P_z=A_z−C_z=c_u(z)(1−c_v(z))/m_u,
R_z=B_z−C_z
   =c_v(z)(1−c_u(z))/m_v
      +c_u(z)c_v(z)(1/m_v−1/m_u).                           (1)

All three densities are nonnegative. In fact C_z=min(A_z,B_z): it is the maximum identical source density that can be retained at both ends. Put I_uv=∫f c_u c_v and j_uv=I_uv/m_u. Full-f matching gives exactly

∫f C_z dz=j_uv≤m_v/m_u<1/K,
∫f P_z dz=∫f R_z dz=1−j_uv.                                (2)

P is actual source export from Q_u\Q_v. R contains both import from Q_v\Q_u and an essential density-renormalization term on Q_u∩Q_v. The latter is nonzero even if Q_v⊂Q_u. Thus geometric containment alone does not eliminate source turnover. No boundary-volume estimate has been applied to f.

## 3. Exact mass-cut balance, including endpoint atoms

For t>0 define the signed endpoint cut and common crossing flux

H_z(t)=∫[A_z1_{m_u>t}−B_z1_{m_v>t}]dγ,
C_z^cut(t)=∫C_z1_{m_v≤t<m_u}dγ,
B_z^cut(t)=∫[P_z1_{m_u>t}−R_z1_{m_v>t}]dγ.

Then pointwise wherever the integrals are finite,

H_z(t)=C_z^cut(t)+B_z^cut(t).                               (3)

This is the exact cut-conservation law with the actual endpoint captures. The strict upper-cut convention gives the crossing interval [m_v,m_u), so it includes mass atoms without splitting or dropping an atom. It follows by substituting A=C+P, B=C+R and using m_u>m_v. The signed boundary term is not generally nonnegative for a fixed source z.

Let E_t={ (u,v):m_v≤t<m_u }. Full-f matching and (2) imply the sharper integrated identities

∫fH_z(t)dz=γ(E_t),
∫fC_z^cut(t)dz=∫_{E_t}j_uv dγ≤γ(E_t)/K,
∫fB_z^cut(t)dz=∫_{E_t}(1−j_uv)dγ
                              ≥(1−1/K)γ(E_t).              (4)

Internal edges with both endpoint masses above t have zero integrated boundary contribution because ∫fP=∫fR. That cancellation is only after integrating the same full f. It cannot be imposed sourcewise, nor does it imply that the main positive term in the last line is paid. In particular the far-mass condition forces the boundary/renormalization term to carry nearly all of the cut flux.

## 4. Coarea and the precise remaining source cost

Put m_0=q_-a^n and m_1=λb^n. All actual masses lie in [m_0,m_1]. Integrating (3) against dt/t on this interval is legitimate: the absolute integrals against f are bounded by 2G log(m_1/m_0). One obtains

∫_{m_0}^{m_1}H_z(t)dt/t
 =∫[A_z log(m_u/m_0)−B_z log(m_v/m_0)]dγ,

and the integrated cut decomposition

∫log(m_u/m_v)dγ
 =∫j_uv log(m_u/m_v)dγ
   +∫f(z)∫_{m_0}^{m_1}B_z^cut(t)dt/t dz.                  (5)

Consequently the exact turnover coarea cost is

L_turn := ∫f(z)∫ B_z^cut(t)dt/t dz
        =∫(1−j_uv)log(m_u/m_v)dγ
        ≥(1−1/K)log K ·G.                                  (6)

Thus an upper bound L_turn≤C n polylog(n)W would indeed give a root-polylog price for G when log K=√n. No such upper bound is proved here. The elementary finite-range estimate is only

L_turn≤log(m_1/m_0)G
       =[log(λ/q_-)+n log(b/a)]G,                           (7)

which is circular as a G budget and gives no W payment. Using total variation of the signed cut does not solve this: it replaces L_turn by a larger quantity and discards internal-edge cancellation. The exact missing term is the signed coarea integral in (6), not a sum of independent n mass-band prices.

## 5. What the actual core posterior adds

Let C(z)=∫C_z dγ, P(z)=∫P_z dγ, R(z)=∫R_z dγ. Then

D(z)=2C(z)+P(z)+R(z),
∫f C≤G/K,  ∫fP=∫fR=G−∫fC.                                (8)

Since each retained endpoint captures at least half its mass in S_*,

∫_{S_*}fD≥G.

Combining with (8) gives the genuine joint source concentration statement

∫_{S_*}f(P+R)≥(1−2/K)G.                                   (9)

When K≤2 the stated lower bound is merely nonpositive; no positive gain is claimed in that case. Formula (9) locates the unpaid traffic in actual turnover on the very same high-D, high-f set that supports the surviving core. It is not an upper bound and therefore is not a receipt. The known bounds D≤T_R^*S and ∫D^4≤constant·G are Lebesgue bounds; they do not bound ∫_{S_*}f(P+R) for arbitrary full f. The R391 truncation mechanism already charged weak endpoints and cannot be reused to assume the surviving source concentration is small.

There is also an exact distinction between turnover and net source divergence. Write the actual outgoing/incoming receiver marginals as o(w)σ(dw), i(w)σ(dw), σ=qdw. Then, as signed source measures,

f(z)[P(z)−R(z)]dz = ∫π_w(dz)[o(w)−i(w)]σ(dw).              (10)

Its total variation is at most ∫|o−i|dσ. Thus large edgewise turnover in (2) or (9) does not force large net source divergence: intermediate receivers with exactly balanced incoming and outgoing marginals cancel after their identical actual posterior π_w is applied. Merely having comparable incoming and outgoing totals is insufficient for this exact cancellation.

If two actual edge subflows u→v and v→w have exactly the same v marginal η, disintegrating and gluing over η gives a legitimate auxiliary triple measure. For its witness source z the normalized incidence telescopes pointwise as (c_u/m_u−c_v/m_v)+(c_v/m_v−c_w/m_w)=c_u/m_u−c_w/m_w. This is an endpoint-measure identity, not an assertion that original transported-source/history labels can be concatenated. The genuinely common triple-source portion has density min(c_u/m_u,c_v/m_v,c_w/m_w)=c_uc_vc_w/m_u when m_u>m_v>m_w, whose full-f integral is the actual triple intersection mass divided by m_u. Under two strict K gaps it is at most K^−2. No assumption of triple capture or automatic matching of the intermediate marginal is made. Establishing enough actual balanced subflow with a payable boundary remainder is still missing; (10) alone supplies no W price.

The core's prior coefficient 2 remains: any later independent bound G≤cost must enter BH as 2cost, with the old fees and original entrance multiplier unchanged. No previous capture-square credit has been subtracted in (3)–(9), and no new history transition has been asserted.

## 6. Verification scope

The accompanying standard-library Fraction script checks the pointwise cut identity at strict cut endpoints, full-source cut integration, the common-density bound, and the actual S_* posterior implication (with an explicit test set S in place of a dynamically generated core). It uses actual four-dimensional cubes with f=1 on a containing cube, exact intersections and source-cell volumes, q=1, radius ratio 2, mass ratio 16 and rational gap K=8. Receiver edges are finite positive quadrature, not a continuum realization of the entire original marked flow. The proof, not those diagnostics, covers real du and all original marks. No numerical model is used to assert that the final core is empty or paid.

Actual run: `PASS {'point_cut': 4992, 'integrated_cut': 24, 'source_mass': 4, 'posterior': 4} total 5024`. All computations used exact Fraction arithmetic. Equation (10) and the conditional gluing paragraph are analytic identities, not separately counted numeric checks.
