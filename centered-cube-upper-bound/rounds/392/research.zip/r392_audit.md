# R392 independent audit — FINAL PASS

FINAL PASS for this round's exact identities, explicit unpaid terms, numerical scope and unchanged ledger. No new W payment or general root bound is certified. The actual core retains coefficient 2 in BH and 4Λ at the entrance. Only this audit file was modified; no repository or author files were edited.

The independent prefilter below was written before the R392 author proofs; the subsequent sections record the completed proof, code and final-file review.

## What the core really is

Let gamma be the exact original R390 cold edge cost, with all original hidden source/target/clock/history labels retained. The R391 core is its positive restriction gamma_core=1_{A_infinity x A_infinity}gamma, NOT a rebuilt kernel or process. Its endpoint projection has

    out(gamma_core)<=beta qdu,
    in(gamma_core)<=C_col qdu,
    s_core=d(out+in)/d(qdu)<=S=beta+C_col,
    integral s_core qdu=2G_core.

These are upper capacities; they give neither a positive outgoing density at every retained endpoint nor qdu subinvariance. A receiver may be supported only by incoming edges, and may not have a next eligible actual edge. Isolated retained receivers need not carry core cost. No first-crossing or history qualification is created by A_infinity.

D_core(z)=integral gamma_core[c_u(z)/m_u+c_v(z)/m_v]=T_R^*s_core(z) is supplied by the actual remaining edge weights. Its exact full-f identity is integral fD_core=2G_core. The original f,m,q, original receiver set E, J/T/Z, selected scales and physical clock are NOT recomputed on A_infinity.

## Inherited gates and their correct quantifiers

Every source/clock-labeled retained edge keeps all its OLD strict far mass, middle rank, strict past, high-J, source-surplus, fractional, target, outside/dense/deep and history masks. Geometry depending only on (u,v,R_u,R_v) is a genuine pair restriction of the projected core. Geometry/rank/clock depending on the old transported source y holds only gamma_core's original labeled-flow-a.e; it is NOT asserted for all z captured by u/v or a fresh posterior draw.

The old large-end R388 failure condition uses pre-payment a_mid, not the smaller K_actual1 or core row. R385 near-full-union support applies on the original LARGE-end row with positive retained cost, not automatically to v as a new large endpoint. R390 cold F_v<t_cold is a true full-posterior condition on the small endpoint; it does not give its outgoing alpha/Y/history qualification. The mass-far, two-sided strict past and middle-rank conditions stay tied to the same old source on that edge, not to subsequent source resampling.

## The new endpoint source fact, including the limit boundary

Set B_core={z:D_core(z)>=s, f(z)>2T}. For sigma-a.e surviving endpoint w,

    pi_w[1_{D_core>=s}(1-T/f)_+]>=1-theta,
    pi_w(B_core)>=1-2theta=1/2.

These are CLOSED occupancy and NONSTRICT posterior conditions. The strict finite-stage gate may converge to D_core=s; no strict fixed point or >half conclusion is justified by that limit alone. The same global source set B_core works at both endpoints, but the two endpoint posterior distributions differ. Neither their actual current source y nor a current target necessarily belongs to B_core; half posterior mass does not identify actual flow marks with that source mass.

One immediate usable same-field consequence for any actual far pair is

    f(Q_u intersect B_core outside Q_v)
       >=m_u/2-f(Q_u intersect Q_v)
       >=m_u/2-m_v
       >(1/2-1/K)m_u.

K=exp(sqrt(n))>2 makes this positive. This is an available full-source external-mass statement, independent of the current y. It supplies no bound on how many old edges reuse those external sources, no new history transition and no W payment. Source expansion must price that real multiplicity rather than calling the posterior mass free. It also does not say that the smaller receiver capturing a chosen external source is an admissible successor.

## Complete fee and testing obligations for a forthcoming candidate

The current hard ledger is BH<=2G_core+E387 X_q+[S390+8(1+sqrt(n))]W. Thus a future bound G_core<=epsilon X_q+C W enters with coefficient TWO in BH and FOUR Lambda at the original entrance. Old E387/source/H terms remain once, not doubled. The discarded R391 terminal potential cannot be reused as a new negative credit.

A valid new geometric or mass-cut construction must use the actual q-weighted edge measure and full matching, preserve the original labeled masks/clock ratio, and identify every new source/edge marginal and any flux imbalance. A source-normalized kernel being row-one or finite-depth does not control its aggregate incoming density. A mass cut may create an exact telescoping identity but must retain unmatched entrance/exit/overhang terms; it does not inherit flow conservation from sigma capacities alone. A moment bound on D_core is not a density upper bound for f.

Reviewer actually ran 54 Python Fraction scalar checks of the external-source mass consequence with strict mass gaps and posterior fractions>=half. This is bounded arithmetic only, not native core realization, a general geometric proof or new evidence about coverage. No parent pipeline or counterexample search was repeated.

Prefilter result: the frozen core contract is coherent. The core's general root source budget and all original H/soft/history/scale/limit slots remain open. The final author-proof review is recorded below.


## Author geometric-potential candidate: reviewed, no new receipt

Read r392_geometry.md and its entire script. The original-source disintegration dgamma_y=q_u chi_core rho_y(du)rho_y(dv)/T_u and its outgoing/incoming densities are correct. For each y the signed-potential identity uses actual r_y-c_y. The positive injection I(y)<=gamma_y(E^2)<=lambda beta J_b(y) gives a receiver-volume bound after full-f integration, not a source-W price. No global column budget replaces J_b(y) by one.

The dimensionless potential b^-2[|u-y|^2+nR_u^2/12] is exactly the uniform-cube SECOND MOMENT test function, not an actual posterior source replacement. Strict far mass gives R_v/R_u<(lambda/(q_-K))^(1/n), and R_u/b>=1/2, hence the radius contribution is >g_n=n[1-(lambda/(q_-K))^(2/n)]/48>0. Positivity uses the original K>lambda/q_-; it is not inferred from a floating sample. The center displacement can have either sign, so g_nG_core<=D_Phi+C_minus is valid and C_minus cannot be removed.

The n=16 pointwise screen exactly has center difference -3843/500, radius term 7/3 and normalized increment -8029/6000. Its same original y is in both cubes, the listed outside/truncation/not-Bplus geometry is certified, and a rational exp upper gives the stated far ratio. The diagnostic is not a self-supported/high-past/current-history core and is not a counterexample to a general budget. It only rules out discarding the negative center increment on those pairwise cuts alone. The remaining positive injection and negative center terms both lack the requested source price.

## Author mass-cut/turnover audit: reviewed, no new receipt

Read r392_aux.md and its entire script. For m_u>m_v the maximum identical endpoint-posterior density is c_uc_v/m_u. The export P is u-only, while import R includes BOTH v-only and common-capture renormalization. Their full-f masses are equal to 1-I_uv/m_u even under containment; dropping the common renormalization would be wrong.

The exact cut identity uses crossing interval [m_v,m_u): t=m_v is included and t=m_u excluded. Internal above-cut edges cancel only after the same full f is integrated. The coarea identities and absolute-Fubini bound are correct. L_turn=integral(1-I/m_u)log(m_u/m_v)dgamma is >=(1-1/K)logK G_core; the elementary upper proportional to the entire mass-range log times G_core is circular and not a W budget. Total variation is a larger quantity and cannot replace signed cancellation for free.

The core concentration gives integral_(S*) f(P+R)>=(1-2/K)G_core by combining integral_(S*)fD>=G_core with integral fC<=G_core/K. This is a genuine lower-location statement, not a payment. Signed endpoint-source projection equals the full-posterior image of the exact receiver divergence (o-i)sigma, whose total variation contracts; edgewise large turnover does not imply equally large NET source divergence. Exact equal intermediate marginals allow an auxiliary gluing identity, but matching totals alone does not, and historical/source labels are not automatically composable. The triple identical source fraction bound K^-2 is correct under two strict gaps.

A crucial law distinction: geometry's I(y) concerns the ORIGINAL transported-source-conditioned gamma_y with actual chi_core. Aux's equation (10) concerns the projected gamma followed by a NEW full endpoint-posterior witness z. These signed source laws are generally different. The latter's vertex cancellation must not be substituted directly for the former's injection price without an explicit proved comparison. Both notes preserve this original-y versus new-z distinction.

## Actual independent reruns and current status

At the parent's explicit request, reviewer ACTUALLY executed both scripts once in the local environment:

- r392_geometry_check.py: exit 0, 492 Fraction checks; normalized_increment=-8029/6000.
- r392_aux_check.py: exit 0, 5024 Fraction checks with the stated four subcounts.

The first finite-rank stage is not a native full cube field; its pointwise screen uses actual cube second moments but omits the full core qualifications. The second uses actual 4D cube/source-cell geometry with RECEIVER quadrature, q=1 and rational K=8; it is not the continuous historical/core flow. Scripts do not claim their diagnostics prove a W budget. These reviewer reruns are not additional independent cases to add to parent counts. The earlier 54 scalar prefilter checks remain separate.

Post-author result: PASS for the stated exact identities, necessary unpriced terms and honest negative outcome. Neither candidate supplies a new W receipt, X absorption, deletion or negative-square credit. Current core coefficient 2 and entrance coefficient 4Lambda remain. The final numerical and main/ledger binding review is recorded below. This is not approval of the unproved general root theorem.


## Final actual-du numerical review

Read the complete r392_numeric.py, result JSON and numeric note. Reviewer actually reran the script locally: exit 0, 665 Fraction assertions, split as 466 actual-geometry, 27 edge-overlap, 118 source-envelope and 54 joint-balance checks. The eight fields use actual positive-volume 16-dimensional receiver boxes, one full compact f=1_Q6 and exact q=1, m=R^16. A rational exponential certificate gives 54<exp(4)<55, while adjacent mass ratios exceed 55. These are genuine strict far-mass pairs, not merely arrows assigned in a finite matrix.

The difference-law trapezoid formula and breakpoints make the Simpson expressions exact integrals of piecewise quadratic polynomials over actual center intervals. Tensorization integrates real product receiver boxes; it does not assert coordinate independence of a general source. Core/support posterior envelopes and bitwise-AND coordinate signatures cover the ENTIRE Q6 and sum to 6^16. Positive/negative normalization bounds and the triangle bound enclose the true aggregated-source net TV; the step envelopes are not mistaken for the actual trapezoid posterior.

The two balanced product edges share precisely the same actual middle receiver marginal g du/|E_mid|, so their entire averaged middle posterior cancels. Unequal weights retain the difference. In the split-left/right case equal edge totals do not match receiver marginals: the exact posterior mismatch TV=eta/(2R_mid)>0 remains. The normalized end-source cancellation is a legitimate auxiliary common-source settlement, but it does not concatenate the original transported-source or history labels. In particular no bound for the logarithmically weighted mass-cut turnover is inferred from this smaller net TV.

All selected cubes lie in Q6. Combined incident receiver marginals respect actual q du and actual X_q/volumes are retained. The far-corner pair-box outside test is valid throughout those boxes; other missing original J, high-past, density, rank and self-supported-core qualifications are not asserted. Crucially f=q=1 on every capture cube makes the original surplus-template zero. The examples are therefore NOT positive original-G witnesses and cannot be used to conclude that a general fixed fraction of the original core is settled. Full W=6^16 stays in the report. Display decimals summarize exact rational enclosures rather than new floating certification.

## Final integration, history and evidence accounting

Read final main, ledger, tools, readme, bounded history extraction and MATLAB source. Main preserves the original-y versus new-z source-law distinction and explicitly retains both unpriced terms of the quadratic potential. The analytic g_n/sqrt(n) limit is 1/24; MATLAB's expm1 computation is a floating cross-check, not its proof or an interval certificate. Reviewer did not rerun MATLAB; its parent-reported execution is kept separate from reviewer Python reruns.

The history extraction is bounded to the cited quadratic/slot and current-core interfaces; this audit does not re-audit the entire historical reduction or certify novelty. Its whole-slot replacement direction is correct: a future direct BH estimate replaces that whole internal slot, whereas a future G_core estimate replaces only 2G_core. Internal E387/S390/cascade fees cannot be added a second time to a replaced whole slot. External entrance, H, soft, scale, history and limit obligations remain.

Parent execution total 6181=492+5024+665 Fraction assertions is consistent with the three actual scripts. Reviewer reruns verify the same cases and are not additional independent evidence; the earlier reviewer 54 scalar prefilter cases are separate. MATLAB seven dimensions/one spatial calculation remain floating diagnostics. No new X absorption, source fee, deletion or reusable negative square is booked. Final result: PASS within exactly this limited R392 scope; the actual general core/W budget remains unproved.

## Frozen byte bindings

These SHA256 values bind the files reviewed at finalization. Dependencies are inherited contracts, not a claim that their complete historical proofs were re-audited this round.

- `r392_main.md`: `325718ecaae7d11a50026dd6cfd120a00d7d8be482273e8c8a1bdaa87a633d6e`
- `r392_ledger.md`: `4031079b6dcb0660da0460e316c19e4d71ff2dff055ba616aa41a4d376cc79f1`
- `r392_readme.md`: `2bce541589c7def0c17d019475e80229c01d7e3a5d09be52b944891c19253f91`
- `r392_tools.md`: `631b7377f4d9b7606f92a9a3dadeab3555ee29133a37d4c4568031b882fb67f0`
- `r392_history.md`: `2a2460e9a5c2b7f535ade681063b3a6997f8b0f2cd797b2daa5fd480800c8be9`
- `r392_geometry.md`: `cc3044b3ec3815eb64e74db7e306c2d80bacd4e5d1377830f1c5de83f5b918ad`
- `r392_aux.md`: `ba002bb067e439077487391ac08e9e2c27ecbdf511dff034d41793e6adeb4f7b`
- `r392_numeric.md`: `12b3fd644077158e5fb89ac968fa0913e2e74a70e94d3681bfd948c04047e155`
- `r392_geometry_check.py`: `5e57c7007ef954587a481405c923a927bfd397a20952f35b27d7c90dff745e35`
- `r392_aux_check.py`: `874f5ed96d73d86bb6343030963c22ffe28dd6b1bc514f5f2bab708bc4ce732e`
- `r392_numeric.py`: `cd31817f6347ca3bf478675731971256b1359d71d178f9ea7b8118ce69fedfc8`
- `r392_numeric.result.json`: `12cd4ac81b34f17fe7c9a730771876372170251b255736a9e43eaff0e19341cc`
- `r392_matlab_crosscheck.m`: `972036e6f4e535dfd8a298bb14a58f206cdaaaf7434106867c57e002081b8130`
- `r391_geometry.md`: `1ccdc3446df5d157fcf6700f32d3790d65c98c48127318a5acd951a110290c23`
- `r391_ledger.md`: `80bc308daa41ce6792dd9a3fe01664c747071607218e8c5866cb4efd1c2842d5`
- `r390_aux.md`: `9b32a470d47ca8c874bb7e1aed1a62dc6b56a31a0e296f6e1de7e9337270dd36`
