# R392 bounded history extraction — original quadratic and spent credit

## Frozen original hard slot

The exact hard-matched input is `f≥0`, `ν≤f dx`, real receiver measure `du` on finite `E`, `a≤R_u≤b≤2a`, `m_u=f(Q_u)=q_uR_u^n`, `q_-≤q_u≤λ` (`q_-=3λ/4`), with `dμ(u)=du/m_u`. Its source row uses

`c_u(y)=1_{Q_u}(y)`, `U_y(u)=c_u(y)/(q_uR_u^n)`,
`J_y(r)=∫_{R_u≤r}U_y(u)du`,
`A_yz(r)=∫_{R_u≤r}U_y(u)c_u(z)du`,
`ell(dr)=b^{-n}δ_b+n r^{-n-1}1_[a,b]dr`, and `Y_r={J_y(r)≥H}`.

These are quoted from `/tmp/r329_core.md` lines 9–26. The full-f matching constraint is `Tg(u)=R_u^{-n}∫c_u(y)g(y)dy=q_u` on the same fixed actual selector and receiver field (lines 28–35). Positivity in `ν` gives `B_H(f,ν)≤B_H(f,f)`; the source-row quadratic is exactly

`B_H(g,g)=∫ell(dr)∫_{Y_r}g(y)dy∫g(z)[A_yz(r)−A_yz(r)^2/J_y(r)]dz`

for `g=f` (R329 lines 37–45). The positive capture row is not free: the matching constraint gives `∫g(z)A_yz(r)dz=V_y(r)=∫_{R_u≤r}c_u(y)du` (lines 49–58).

R329 writes its exact common-source square decomposition as `B_H=∫a g−Q(g)−R_cross(g)−R_clock(g)` (lines 66–75 onward). `Q` is a positive-semidefinite Gram energy; `R_cross` and `R_clock` are additional nonnegative credits. Dropping them gives an upper bound, but the note warns they can contain substantial information (lines 66–70 and 83–95); no replacement theorem is proved there. This is the original quadratic/capture credit available to a *whole-slot* argument, not a separately available additive payment.

## Current core and source-cut status

R392’s actual projected edge measure is `γ=γ_core`, the positive projection of the fully marked original traffic onto actual receiver endpoints `(u,v)`. Its source, physical-time, fractional and history labels remain in the underlying measure; ultimately receiver integration is real `du,dv` (`/tmp/r392_aux.md` lines 5–17). For the retained strict far-mass edges, `m_u=f(Q_u)>K m_v`, `K=e^{√n}`, and the full-f endpoint witness posteriors are `π_w(dz)=f(z)1_{Q_w}(z)dz/m_w` (lines 7–17).

The R392 decomposition already shows why gross turnover cannot be counted as a free credit: `∫f P=∫f R=1−j_uv` per edge with `j_uv=f(Q_u∩Q_v)/m_u<1/K` (lines 27–40). After the exact atom-safe cut balance, the integrated turnover term is at least `(1−1/K)γ(E_t)` (lines 44–63); its coarea total obeys `L_turn≥(1−1/K)log K·G` and has only the circular upper bound `log(m_1/m_0)G` (lines 65–90). R392 claims no root source payment (header/§4). These are identity and obstruction statements, not a newly certified geometric estimate.

## Previously paid pieces and safe ledger substitution

The earlier R338 whole-slot decomposition had already paid `B_near+2B_fav` and the high-past center-dilation piece; its exact reported bound leaves `G_out` unpaid (`/tmp/r338_main.md` lines 49–64). A new upper bound on that remainder must preserve its original mass, source, J, history and physical-clock masks. It may replace the remaining `G_out` term; it cannot be added again to the same `B_near`/`B_fav` terms.

For the current R391 core, `/tmp/r392_audit.md` lines 7–22 specify that `γ_core` is a positive restriction of the exact original labeled traffic, not a rebuilt kernel; original `f,m,q,E,J/T/Z`, selected scales and physical clock are unchanged. The current hard ledger is explicitly `B_H≤2G_core+E387 X_q+[S390+8(1+√n)]W` (audit lines 42–46). Therefore a valid bound `G_core≤εX_q+C W`, if established with these same edges and labels, would replace just the `2G_core` contribution and enter with coefficient 2 in `B_H` (and coefficient `4Λ` at the original entrance); `E387` and `S390` remain once. It must not be stacked with the R391 terminal potential as an extra negative credit (same audit lines 44–46).

For a route based instead on the entire original quadratic, the safe interface is R329’s full `B_H` slot: prove a bound on that whole expression and substitute it for `B_H` in the entrance. This replacement consumes the entire internal `B_H` decomposition: no `E387`, `S390`, crossing/large-atom, or other fee that is itself a part of the same `B_H` may be added on top. Only fees outside the `B_H` slot remain. R329 explicitly says a successful receipt replaces the whole slot and must not be added to crossing/large-atom pieces (lines 37–45). R333’s entrance is `T_*≤8λHW_β+2d_eff A_n H^{-1}W_ν+2B_H` (`/tmp/r333_ledger.md` lines 18–24); thus any full-slot bound is multiplied by 2 there, followed by the existing `Λ=128/119`. The previously paid terms remain in their existing ledger locations; do not bill them again inside a new same-slot decomposition.

**Boundary of this extraction:** no new estimate of `Q`, `R_cross`, `R_clock`, the R392 turnover term, or the candidate direct-geometry term is derived or certified here.
