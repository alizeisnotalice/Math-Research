from fractions import Fraction as F
from itertools import product

counts={'point_cut':0,'integrated_cut':0,'source_mass':0,'posterior':0}
n=4; K=F(8)
for shift in (F(0),F(1,2),F(1),F(3,2)):
    u=[(F(-1),F(1)) for _ in range(n)]
    v=[(shift-F(1,2),shift+F(1,2))]+[(F(-1,2),F(1,2)) for _ in range(n-1)]
    mu=F(16); mv=F(1)
    grids=[sorted(set(u[i]+v[i]+(F(0),))) for i in range(n)]
    cells=[]
    for ix in product(*[range(len(g)-1) for g in grids]):
        x=[(grids[i][j]+grids[i][j+1])/2 for i,j in enumerate(ix)]
        vol=F(1)
        for i,j in enumerate(ix): vol*=grids[i][j+1]-grids[i][j]
        cu=F(all(lo<x[i]<hi for i,(lo,hi) in enumerate(u)))
        cv=F(all(lo<x[i]<hi for i,(lo,hi) in enumerate(v)))
        aa=cu/mu; bb=cv/mv; cc=cu*cv/mu
        pp=aa-cc; rr=bb-cc
        assert min(cc,pp,rr)>=0
        cells.append((vol,aa,bb,cc,pp,rr,x[0]>=0))
    totals=[sum((row[0]*row[i] for row in cells),F(0)) for i in range(1,6)]
    a,b,c,p,r=totals
    assert a==b==1 and p==r==1-c and c<=1/K
    counts['source_mass']+=1
    for t in (F(0),mv,mv+F(1,2),mu-F(1,2),mu,mu+1):
        H=C=B=F(0)
        for vol,aa,bb,cc,pp,rr,_ in cells:
            left=aa*(mu>t)-bb*(mv>t)
            shared=cc*(mv<=t<mu)
            bound=pp*(mu>t)-rr*(mv>t)
            assert left==shared+bound
            counts['point_cut']+=1
            H+=vol*left; C+=vol*shared; B+=vol*bound
        crossing=F(mv<=t<mu)
        assert H==crossing and C==c*crossing and B==(1-c)*crossing
        counts['integrated_cut']+=1
    SA=sum((vol*aa for vol,aa,bb,cc,pp,rr,s in cells if s),F(0))
    SB=sum((vol*bb for vol,aa,bb,cc,pp,rr,s in cells if s),F(0))
    ST=sum((vol*(pp+rr) for vol,aa,bb,cc,pp,rr,s in cells if s),F(0))
    assert SA>=F(1,2) and SB>=F(1,2)
    assert ST>=1-2/K
    counts['posterior']+=1
print('PASS',counts,'total',sum(counts.values()))
