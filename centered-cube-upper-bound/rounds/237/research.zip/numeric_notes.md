# R237 bounded numerical plan

Six actual n=1 L1 kernel integrals and six independent rational local-mass configurations are planned, separately counted. The physical models have beta=nu as density1 on disjoint intervals of length1/5, f=2beta, q=2 globally. Clusters are40 units apart. D(z)=[z-17,z+17] retains only the same cluster for source y; the target posterior/capacity integral remains over the full original nu including remote clusters. Initial:2 clusters,s=.5,theta=.5/.1. Pressure:3 clusters,s=.99,theta=.01/.1. Expanded:5 clusters,s=.05,theta=.01/.25. Actual integration uses hard-column averaging over z, then x and y quadrature, with hard boundaries split. GL8/16 and mpmath25/50 kernel values provide ordinary refinement, not interval certificates. Six exact rational cases separately test critical distances, partial D overlap, extra beta mass and nu<=beta. No claimed original gate inheritance, history/FULL or large-n qualification; this tests the source-gated tool conditional on imposing D.

## Actual executed object and scope

All twelve proposed configurations actually ran: six spatial kernel integrals and six rational localmass cases, not twelve spatial integrals. The source-gated physical object is

    integral nu(dz) integral_R h_1(x-z)/q
      * [q^-1 integral_fullnu P_s(x-v)nu(dv)]^theta
      * integral_{|y-z|<=17} P_s(x-y)^(1-theta) beta(dy) dx.

C=1 and the target set is relaxed to the full source support. The full original nu in the target capacity is never restricted to D. This is an actual common-x kernel computation and a unit normalized fixed-hard column, rather than an arbitrary matrix. No time history, capture or original mother-gate inheritance is implemented. The latter is a separate analytic/source-chain obligation. The n=1 examples are low-dimensional tools and do not qualify the original main dimension range.

Each physical model has beta=nu=sum_j 1_[40j-.1,40j+.1] with density1 and f=2beta. Since f<=2 and every P_s is a normalized density, q=2 works for every x and every soft parameter; it is not refitted per point or per cluster. D(z) retains precisely the same beta cluster for every z in each source interval, so m_D(z)=1/5. The hard-z integral may therefore be performed exactly first: its density is H_j(x)=length([40j-.1,40j+.1] intersect [x-.5,x+.5]). All x with nonzero hard column are integrated, namely the union [40j-.6,40j+.6]; outside this union the integrand is zero. There are no omitted infinite spatial integration tails. Full target capacities are independently computed by stable E4 endpoint formulas for the actual phi=h*w, including remote clusters, not by the y quadrature or by a local posterior replacement.

Raw local source budget is nu_mass*(.2/2)^theta, global source budget is nu_mass*(nu_mass/2)^theta. Their ratio is exactly clusters^(-theta) in this separated model. At final GL16 order, actual fee/local budget ranges .0504946 to .0911320. Local/global budget ratios range .6687403 to .9890740, with the smallest ratio at five clusters and theta=.25. This is a genuine finite geometric gain, but for small theta the gain is weak in precisely the recorded way; no order is inferred. Full remote target capacities, separately accumulated before adding them to the near capacity, have integrated magnitudes approximately1.08e-20 to1.07e-19. Their addition to the near capacity can fall below float64 rounding resolution; this is numerical precision, not a source-set truncation.

The physical computations use numpy float64 GL8 and GL16, hard-boundary splitting, and independently evaluated mpmath25/50dps phi/E4 values. The maximum absolute GL8-to-GL16 fee change was1.5099412e-9. These changes are empirical refinement differences, not certified interval errors or fifty-digit integrals.

The six other cases use beta density1 on [0,1] and [d,d+1], with d=40,17,16.9,17.1,100,1000. The final two add another beta interval [2d,2d+1] and an additional nu density1/2 on [d,d+1]; the first four take nu=1_[0,1]. Thus nu<=beta throughout. All m_D(z) breakpoints and affine-piece endpoints are exact Fractions, and integral m_D dnu is exact Fraction arithmetic. The critical d=16.9,17,17.1 values are319/200,3/2,281/200 respectively. The theta=1/2 source-budget integral uses the independent elementary primitive of the square root of each affine piece, evaluated at70dps; it is distinguished from the exact rational mass identities. Local/global source-budget ratios are .7071068 at40, .8619288 at17, .8894788 at16.9, .8339001 at17.1 and .5773503 for both expanded cases100/1000. These source-mass diagnostics are not counts of additional actual-kernel integrals.

## Runtime and reproduction

Existing local runtime only: Python3.12.14 at `/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`; NumPy2.3.5 from that runtime's `lib/python3.12/site-packages`; mpmath1.3.0 from the vendor below. No installation.

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/237/work/numeric_checks.py \
--output /tmp/r237_numeric_replay.json
```

The script is relocatable with its adjacent task_contract.md; runtime and output path are excluded from JSON. Source and contract SHA256 bind the computation. Only these owned numerical files were edited.

## Frozen final replay

Complete separate-output JSON replay was byte-identical:16,714bytes; actual wall3.13s,user3.10s,system.02s. Actual counts:6 true L1 integrals and6 rational localmass configurations. SHA256 source `fea68cc208cf411209e93aaaf901b0ebc7638529fa6720a0be8f361fdcd41d40`; JSON `16f720a234929d9d6a6c23a07f4fd78bacc472da43279ece98f6b2a4e29fc1ef`; contract `5737db822bb7f60ceb426bb811cf0839f6fd03de980e96f31a139fd952db87d0`. Theta=.5 is an auxiliary local Holder tool example; it does not instantiate any later primary all-scale theta selection or theta<=1/4 restriction of the alternate grid route.
