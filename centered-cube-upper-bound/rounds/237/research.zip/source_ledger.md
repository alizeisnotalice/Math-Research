# R237: original terminal-source ledger and retained local mass

This note owns only this file. It narrowly checks the original Markdown
definitions and the R226/R236 frozen interfaces; no JSON or numerical
search is used to infer a historical qualification. The assigned
`task_contract.md` was not yet present at the first two checks; the
parent's explicit bounded assignment supplies the scope. A general
root-order input budget is not proved.

## SL1. Definitions and source ancestry, with original line numbers

All line numbers below refer to the indicated frozen local files, not to
their subsequently assembled `proof.md` files.

| Frozen original file and lines | Exact qualification |
|---|---|
| [R107 integration.md:9–20](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/integration.md:9) | Actual n>=512, real dx, common q in [3lambda/4,lambda], a<=L,R<=b<=2a; sigma_omega<=mu_hi,omega<=f dx. W_tree=E||sigma||<=W_mu; W_hi=E||mu_hi||. |
| [R107:75–106](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/integration.md:75) | Original near is ||x-y||_1<=16na. An additional independent seed xi gives finest full side 256na, Lambda=(1-18/256)^-1=128/119. The tree tests sigma, first by mass M*=lambda a^n exp(sqrt n), then by density. Every surviving terminal V has full side 256na and M*<sigma_V(V)<K256 lambda |V|/sqrt n, K256=4exp(1/128). |
| [R107:109–120](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/integration.md:109) | Each positive actual row has Q_R(x) wholly in a unique V, and its original y in that V; the new good-leaf gate is retained in the actual joint kernel. |
| [R107:180–222](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/integration.md:180) | On the common maxflow residual, delete the top k original spatial pieces before the receiver is chosen. nu is the remaining hard tail. Low true tail rows cost delta X and light-tail leaves cost A_tail(delta) W_light; after this step hard nu is not changed by further hard-column peeling. |
| [R107:226–254,347–370](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/integration.md:226) | alpha_V=mu_hi|V, M_V=alpha_V(V), m_V=nu_V(V). Relative-small tails m_V<=M_V/sqrt n were paid. On the remaining outer leaf collection, M*<m_V<=M_V<sqrt n m_V. Hard rank is the original piece rank of this same nu, not a soft or posterior rank. |
| [R109 integration_main.md:51–58,103–109](/Users/zhengzhihao/Desktop/T/output/centered_cube_round109_20261013/integration_main.md:51) | After the enlarged hard network, rebuild top-k tail, low rows, light leaves, soft/hard mass comparison and square-column branches on that same new residual. The remainder retains these original mass comparisons, deep rank and joint gates. |
| [R112 astra_joint.md:9–31,65–72](/Users/zhengzhihao/Desktop/T/output/centered_cube_round112_20261014/astra_joint.md:9) | alpha_V is still the original mu_hi|V, sigma_V<=alpha_V, hard nu is unchanged by the subsequent soft network. All original FULL/FIRST/CP/GP/deep and previous gates remain in the positive subkernel. Soft input does not have the hard low-mean or rank qualification. |
| [R112:293–304,336–352](/Users/zhengzhihao/Desktop/T/output/centered_cube_round112_20261014/astra_joint.md:293) | Independent soft residual is carried by S_alpha, with saturated cut target N_alpha, and low actual receiver occupation |N_alpha intersect Q_R(x)|<R^n/ell_n after payment. The soft neighborhood estimate is |N_alpha|<=alpha_V(V)/tau_r, not the hard sigma estimate. |
| [R113 coupled_transport.md:51–84](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/coupled_transport.md:51) | The coupled replacement selects soft flow so that nu<=zeta_sigma*<=beta^c=alpha-eta_alpha^c<=alpha. It retains the original hard nu and its rank, both cut conditions and the soft low-N gate, with the old soft extraction/high-N prices. It does not retain R112 J27 positive extraction at every alpha source point. |
| [R113 joint_budget.md:300–351](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/joint_budget.md:300) | Extraction and off-block low-degree payment have complementary soft source masses; they can be combined only through alpha=eta_alpha+beta. All prior hard and soft prices remain in the global ledger. The later coupled replacement uses these same prices; it is not the early independent beta. |

The later mapping was separately audited in [R226 source_geometry.md:9–28]
(/Users/zhengzhihao/Desktop/T/output/centered_cube_round226_20261016_final_checkpoint/source_geometry.md:9):
R113 coupled I1–3 -> R114 actual remainder -> R116 same beta/nu -> R117
actual posterior construction -> R215–225. Its lines 59–76 explicitly
retain M_V<sqrt n m_V for the current nonzero outer leaf. R236 uses that
same original source collection. This checks the inherited outer gates;
it does not regrant a gate on an enlarged receiver set after its RN
indicator has been removed.

## SL2. What “low density terminal leaf” actually means

Write b_beta,V=beta_V(V), b_nu,V=m_V. On the retained outer leaf collection,

    |V|=(256na)^n,
    lambda a^n exp(sqrt n) < m_V <= sigma_V(V)
      < (K256 lambda/sqrt n)|V|,
    m_V <= b_beta,V <= M_V < sqrt n m_V.                 (SL1)

The low mean lambda/sqrt n belongs to sigma, the measure used to stop
the tree. Beta can overlap the removed parts of sigma's complement and
has no such low mean. Combining the *separate* inherited mass-comparison
gate with SL1 nevertheless gives the valid weaker bound

    b_beta,V < K256 lambda |V|,
    rho_beta,V := b_beta,V/(q a^n)
      < (4K256/3)(256n)^n.                              (SL2)

This is a leaf-total bound, not a pointwise beta density bound or a local
source-center cap. The mass comparison is an outer-source gate: leaves
with m_V<=M_V/sqrt n were removed as whole leaves, before the later
receiver/pair restrictions. Hence it is valid simultaneously for the
same nu_V in every later row of that retained leaf. It is not inferred
from a single receiver's capture inequality. Positive restrictions of
rows do not require reselecting the sources or the leaf mass tests.

In particular R236's

    R_V=1+log_+rho_beta,V+log_+K
          +log(e ceil(pi sqrt n))

is at most

    H_n=1+log(4K256/3)+n log(256n)+log_+K
          +log(e ceil(pi sqrt n)).                     (SL3)

Here K is R236's good-threshold parameter, distinct from K256. Thus
the original qualifications do make the moment finite and give
E sum_V m_V R_V^3 <= H_n^3 W_nu. This is not a root-order estimate:
H_n already has order n log n. The old linear-in-n source bound can be
smaller. No new root payment is claimed by substituting SL3.

## SL3. Mass budget and seed/recovery charges

For each fixed full seed, the retained V are disjoint. Therefore

    sum_V b_beta,V <= ||mu_hi,omega||,
    sum_V m_V <= sum_V b_beta,V <= ||mu_hi,omega||,
    W_nu:=E sum_V m_V <= W_beta <= W_hi <= ||f||_1.       (SL4)

The extra seed xi is averaged as a probability seed, not summed over
its possible values. This is why it introduces no extra leaf count or
source-mass factor in SL4. It did introduce a genuine row recovery
charge: near pairs miss the common leaf with probability <=9/128,
and the resulting original terminal and later tree terms carry Lambda
=128/119. R107:90 explicitly prohibits reusing this independence on a
later xi-dependent remainder. Far-soft terms were stripped before this
recovery and do not carry Lambda; see R107:94–100 and 308–330.
The later mother-interface value is also explicit in
[R128 proof.md:630](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:630),
RT2: `2Lambda {P_I^rem-N_I,Zc-N_I,del}`, Lambda=128/119.
The distinct ell=1+log n occurs at its line 664. Thus identifying the
current 2Lambda with this recovery does not rely on ambiguous notation.

The hard partition is still

    W_stop+W_eta*+W_top+W_light+W_heavy=W_tree<=W_mu,

as in [R107:294–302](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/integration.md:294)
and R113 joint_budget:351. Top removal already cost k kappa_n X with
kappa_n=e^2 exp(-sqrt n)/sqrt n. It cannot be repeated for a new rank at
zero cost. The soft extraction and high-N row charges are

    epsilon_s/theta_split * X
      + [K_s(n,epsilon_s)/theta_split
          +4 C2^2 ell_n sqrt n] W_eta_alpha^c,

before the outer Lambda recovery; theta_split is the old row split,
not R236's fractional exponent. This is R112:356–390 and R113 coupled:76–84.
The later low off-block degree charge is 2 C_n ell_n W_beta^c (R113
joint_budget:306–320); it can be combined with extraction only by the
actual complementary soft masses. Neither soft charge can be absorbed
into the five-term hard mass partition. R236's displayed estimate
already restores its own 2Lambda and other stated leg/physical factors;
one must not multiply that displayed bound by Lambda a second time.

Consequently SL4 pays an *unweighted* hard mass sum, not a log moment.
It is legitimate to charge a proved bounded source price to W_nu, but
not to replace m_V R_V^3 by m_V just because both are on the same leaf.

## SL4. Original-scale rank gives an actual local mass cap

Let d_f=a/n and P_i=C_i intersect V be the original birth pieces. Set
m_before,V to the hard maxflow residual mass before top-k. The exact
rank from R107:362–370 is

    nu_V(P_i) <= m_before,V/(k+1),
    gamma_V:=sup_i nu_V(P_i)/m_V
      <= m_before,V/[(k+1)m_V] < sqrt n/(k+1).           (SL5)

For any measurable B contained in a union of N original pieces,

    nu_V(B) <= min{m_V, N m_before,V/(k+1)}
             <= m_V min{1,N gamma_V}.                  (SL6)

Proof: sum the actual piece masses; these pieces partition nu_V.
This holds for the pre-frozen measure at every center, not merely at
eligible receivers. For an arbitrary axis-parallel cube of full side r,
one may take N<=(ceil(nr/a)+1)^n, disregarding spatial boundaries since
nu<=f dx. This is an authentic local source mass bound with its full
cell-count cost. It is not a beta cap or a posterior cap.

For the larger source-pair set

    Dplus_V(z)=V intersect {y: ||y-z||_1<=17na},

all full birth cells intersecting it lie in the l1 ball of radius
(17n+1)a around z (the l1 diameter of a birth cell is a). Disjoint full
cells each have volume (a/n)^n, so the safe sharper count is

    N_D <= [2(17n+1)n]^n/n!.                            (SL7)

The volume formula is 2^n R^n/n!: split into orthants, then integrate
the simplex {u_i>=0,sum u_i<=R}. SL7 and SL6 are valid also for pieces
cut by a leaf boundary, because counting uses their original full
cells. Already for r>=a the cube count is exponential in n log n;
no physical-scale gain follows without an adequate k. The original k
is the one already paid for; this lemma does not choose a new k or
infer a density bound within a cell. Since beta=nu+(beta-nu), the same
calculation only gives

    beta_V(B)<=nu_V(B)+(b_beta,V-m_V),

and the excess can be as large as (sqrt n-1)m_V under the retained
mass comparison. Thus SL5 alone does not bound local beta congestion.

## SL5. A genuine local-source refinement of R236 mass exchange

One can retain a more informative original geometry instead of throwing
it out before source exchange. R107:75 gives ||x-y||_1<=16na on the
original near branch, while hard z in Q_R(x) gives ||x-z||_1<=nR/2<=na.
Consequently each actual hard/source pair has y in Dplus_V(z). The exact
original set is smaller: [R113 joint_budget.md:25–45]
(/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/joint_budget.md:25)
defines the actual hard-z mother integral in B3 and then states in B5
that its **actual source pairs** are carried by

    Dorig_V(y)=V intersect {z: ||z-y||_1<=17na}
                  intersect {z: ||z-y||_infty<=b(5 log n+1/2)}. (SL7a)

Both Dorig and Dplus are symmetric in the two points of V. Original
hard z is explicitly in Dorig_V(y) intersect (T0(y) minus A_g(y)) in
R113:272–279, B30. The later coupled change preserves hard nu, original
FULL and history (coupled_transport:68–84). R117 joint_geometry.md:47–54,
JG5, still integrates h_R(x-z)nu(dz) with a_omega(x,y,z) containing all
original gates; its line 23 explicitly distinguishes the auxiliary z'
from this original hard z. Finally R229 adaptive_geometry.md:174–181,
206 keeps the original no-hardcap 2Lambda q^-1 p_y h_R route and the
four original source slots, with all original gates in chi. Thus one may
write a=1_Dorig a and only then bound a by one, retaining this source-pair
gate. This is not an inference from auxiliary v in Z_t. Below D can mean
Dorig or the legitimate positive enlargement Dplus, but must be chosen
and retained from this original mother expression.

Fix one physical hard node R* and legal soft node L* as in R236. Preserve
the pair gate and define

    d_{R,D}(x,y)=(C0q)^-1 integral h_R*(x-z)
                        1_{D_V(z)}(y) nu_V(dz),
    S_D(y)=a^{-n theta} integral_Omega d_{R,D}(x,y)
                  P_{s(x),L*}(x-y)^{1-theta}
                  zeta_act(x,y)^theta dx.

Here h_R*(x-z) means the hard density at the **fixed physical scale**
R*, not convolution with a selected R(x); C0=16/3. The actual target
occupation zeta_act remains in [0,1] by the original actual-soft FIRST.
All other original gates can stay inside zeta or the positive kernel.
Then the following refinement is rigorous:

    integral S_D(y) beta_V(dy)
       <= (1/C0) integral [beta_V(D_V(z))/(q a^n)]^theta
                            nu_V(dz).                 (SL8)

Proof: Tonelli first exposes the original hard z. At each fixed x,z,
Holder on beta restricted to D_V(z) and source FIRST give

    integral_{D_V(z)} P_{s(x),L*}^{1-theta}
                      zeta_act^theta beta
       <= q^{1-theta} beta_V(D_V(z))^theta.

Now integrate h_R*(x-z) over the real receiver set and use its full-space
column integral one. The factors a^{-n theta}/(C0q) give precisely SL8.
No source-independent receiver volume, beta density cap or free repeated
KL is used. The sources retain their same original histories.

This is a strict refinement whenever these retained local beta masses
are smaller than beta(V), and it is valid for the actual original
distance-qualified subkernel. It is **not** permission to restore a gate
after it was discarded in an upper bound: to use SL8 one must retain
the y,z distance indicator from the original mother expression before
forming the source exchange. It changes that exchange line only; the
same fractional-good, heavy, physical node and j costs still apply.
If node coverage replaces hard R by an upward R*, the original distance
gate must explicitly be carried along, rather than recomputed from an
expanded cube.

SL8 is the useful surviving local geometry. It does not by itself
justify replacing the already established global R236 moment by a
local log moment after all node sums; that requires doing those sums
with the retained source price, rather than changing the exponent in
a bound that has already integrated hard z. The original no-hardcap
form does admit the following separately stated anchorwise use.

Fix the original hard z before all receiver, soft y, auxiliary v/u, j,
physical node and time variables. Any measurable theta_z in (0,1/2]
can then be used in this one-anchor exchange:

    [a^{-n theta_z}/q] integral_Omega h_R*(x-z)
       integral_{D_V(z)} P_{s(x),L*}(x-y)^{1-theta_z}
                         zeta_act(x,y)^theta_z beta(dy) dx
        <= [beta(D_V(z))/(q a^n)]^{theta_z}.            (SL9)

Its proof is exactly the preceding fixed-x,z Holder inequality followed
by the fixed hard column; it does not use a hard-source cap C0q at all.
Measurability of beta(D_V(z)) follows directly by Tonelli for these
Borel distance sets. If beta(D_V(z))=0 the anchor contributes zero and
theta_z may be assigned 1/2. This does not reselect a source measure or
history. A clock/physical-node estimate proved uniformly for every
fixed theta may accordingly be applied separately at each such z and
then integrated against the original nu(dz), with all of its prefactors
and history gates. What is not allowed is inserting theta_z into a
prior bound that already integrated hard z and fixed a leafwise theta.

## SL6. Remaining budget and small arithmetic check

The original ancestor data provide SL1–SL7 and the local exchanges SL8–9.
They give neither a pointwise beta local mass cap on D_V(z), nor a
decay bound for the nu-weighted tail of beta_V(D_V(z))/(qa^n). Soft
cut support and low receiver occupation are therefore still pertinent:
H_{r_n,a,V}(S_alpha) is inside N_alpha, and actual receiver cubes have
|N_alpha intersect Q_R(x)|<R^n/ell_n. Their neighborhood moves only
r_n=max{1,floor(log n/log729)} coordinates, not all n coordinates;
see R109:91–109 and R112:347–352. Neither that volume statement nor
SL5 bounds soft mass on the source-centered sets in SL8.

Thus the narrow audit finds a genuine finite local-source exchange and
an explicit global dimension-dependent cap, but does not derive a new
general root-order input budget from the ancestor ledger. Any such
budget must use the remaining joint local geometry, or supply a paid
source-density-tail estimate; domination and source disjointness alone
pay only SL4. No new counterexample family is asserted.

For a reproducible local arithmetic check, this exact code was actually
run with Python and mpmath 1.3.0 at 50 digits (existing vendor runtime):

```python
import mpmath as m
m.mp.dps=50
for n in (512,4096,1000000):
    k=4*m.exp(m.mpf(1)/128)
    logrho=m.log(4*k/3)+n*m.log(256*n)
    logN=n*m.log(2*(17*n+1)*n)-m.loggamma(n+1)
    print(n,m.nstr(logrho,18),m.nstr(logN,18))
    assert logrho>m.sqrt(n) and logN>m.sqrt(n)
```

Returned pairs (global log-rho upper bound, local-D cell-count log bound):
512: (6034.83484852733564, 5507.53935316814378);
4096: (56784.2988204042914, 52604.5239088556397);
1000000: (19360689.6842327702, 18341863.3147100677).
All three comparisons passed. These only check arithmetic in the
displayed conservative prices; they are not evidence that these upper
bounds are attained, a FULL instance, or a proof of a new asymptotic law.
