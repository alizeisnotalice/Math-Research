# R237 independent audit — statement-first checkpoint

The exact parent candidate was screened before reading any R237 author draft. The requested task_contract.md was not yet present at the first read; this checkpoint uses the stated candidate and frozen R236 interfaces, and will be reconciled with the contract when available. Only this audit file is changed.

## Valid frozen partition interface

Fix an original outer leaf, its true receiver Omega, full sources beta,nu, common q,a,b and original process. Let beta=sum_i beta_i and nu=sum_k nu_k be finite/countable positive measure partitions frozen before receiver x, physical node j,M, auxiliary time and all source integrations. Fractional partitions by nonnegative RN weights summing to one are equally valid. The beta_i partition applies only to the anchor y slot; nu_k here applies only to the hard source z. Both posterior slots, Z_t, w_t, e_t and the heavy floor still use the original full nu. A piecewise posterior or a new heavy denominator is not licensed.

A theta_i in (0,1/2] may be chosen from frozen leaf/piece data before x,y within that piece, v,u,z,j,M,t. The good inequality is pointwise in theta_i on its anchor piece; the full current/future FIRST at the actual receiver transfers positively to beta_i. For a fixed physical node R*, put

    d_Rk(x)=(h_R*nu_k)(x)/(C0 q),
    zeta_i(x,y)=q^-1 integral_Ztau(y) C(x,y,v)^(1/theta_i) Q_actual(x,v) nu(dv).

The source in zeta_i is full nu. On the original receiver, d_Rk<=1 and zeta_i<=1, and fixed hard normalization gives integral_Omega d_Rk<=nu_k_mass/(C0 q). The R236 same-posterior heavy-clock argument therefore applies separately to each piece without changing its floor or time process. In particular

    integral_beta_i S_i,k <= (nu_k_mass/C0) [beta_i_mass/(q a^n)]^theta_i.

The independent menu/QG/Gini alternative likewise contains beta_i_mass times nu_k_mass, with the full original posterior score normalization. Neither beta_i FIRST nor the small hard mass gives a smaller posterior or a piece-specific q/heavy floor.

The labels must not be receiver/time-adaptive partitions when this fixed-hard normalization or static clock column is invoked. All original hardband/FIRST receiver qualifications remain explicit on Omega; dropping a history indicator does not grant them at new points. The actual-soft source and target kernels share the original s(x), static in auxiliary time. The original good factor, physical e^4, nearest-angle e N alternative, three legs/two orientations and all j/M prices remain as in R236. A piece-varying theta remains inside the corresponding sums.

## A genuine spatial coupling weight that may be retained

For each fixed node and piece, define the same-point quantities

    b_i(x)=integral P_actual(x-y) beta_i(dy) <= q,
    z_i(x)=integral zeta_i(x,y) beta_i(dy) <= m_i,
    m_i=beta_i_mass.

Holder in beta_i gives the stronger, genuinely spatial bound

    integral_beta_i S_i,k <= a^(-n theta_i)
       integral_Omega d_Rk(x) b_i(x)^(1-theta_i) z_i(x)^theta_i dx.

For positive m_i and n_k=nu_k_mass, this equals the scalar price
(n_k/C0)[m_i/(q a^n)]^theta_i times the explicit coupling factor

    omega_i,k=(C0 q/n_k) integral_Omega d_Rk
                 (b_i/q)^(1-theta_i) (z_i/m_i)^theta_i dx,
    0<=omega_i,k<=1.

Zero-mass pairs contribute zero before any division. This weight is a legitimate retained receiver/source quantity. It depends on the physical node and theta_i, so a claimed all-node estimate needs to sum its actual weighted clock prices. It cannot be discarded in the mass exchange and restored after receiver integration. Nor is omega_i,k automatically available in the independent Gini alternative; that alternative needs its own spatial column estimate if such a weight is claimed there.

For common theta and one underlying retained capture, summing the actual pieces before using Holder is legal: sum_i b_i^(1-theta) z_i^theta <= (sum_i b_i)^(1-theta)(sum_i z_i)^theta, and sum_k d_Rk=d_R. This recovers the original joint R236 bound. Different theta_i require keeping the piece sum or proving an additional mixed-exponent estimate; the common-exponent Holder collapse cannot simply be reused.

## Earliest unpaid step

The per-pair scalar bounds are valid but need not localize the total charge. Summing n_k R_i^3 independently over every pair gives (sum_k n_k)(sum_i R_i^3), repeating the hard mass for every anchor piece; arbitrarily fine positive partitions can make that bound useless even when the exact original integral stays finite. No partition, spatial overlap estimate or packing budget has yet been constructed. The next sufficient interface is an actual bound on the joint node/time sum containing omega_i,k (or a sharper uncollapsed column) and the full beta_i/nu_k geometry. A mere disjointness statement in source space does not provide this receiver overlap budget. No source-to-input or general root payment is certified by this checkpoint.

## Local mathematical tool check

A local mpmath 60-dps computation actually passed 33 checks: 18 common-exponent piece/hard-pair inequalities, nine same-point coupled Holder inequalities, and six distinct-exponent pair inequalities. It used the same full target source in every posterior-capacity surrogate, three Lebesgue receiver cells and a fixed normalized two-column hard kernel. This is a bounded abstract finite-cell diagnostic, not a physical FULL instance, interval certificate or general proof. Its temporary standalone code is not archived and it is not counted as a formal replayable package experiment. The analytic proof above is Holder/Tonelli and fixed-kernel normalization.

Status: the stated conditional partition bridge passes; the spatially coupled total budget remains a separate required proposition. Awaiting the actual contract and author candidate before final proof audit.

## Contract received; new receiver-cell proposition screened independently

The contract subsequently appeared and was read. It identifies a receiver-cell localization rather than merely the initial anchor/hard pair partition. No R237 author proof has been read at this stage.

For a fixed grid cell C and a<=L<=b, phi(u)<=exp(-(|u|-1/2)_+) follows from w(u)<=exp(-|u|) and integration over the unit core. Consequently every actual-soft P_s,L(x-y), x in C, is at most a^-n W_C(y), where W_C is the contract's distance envelope. Let V_C=min(1,(b/a)^(n/2)sqrt(W_C)). Then W_C<=V_C^2 and mu_C=integral V_C dbeta is finite. For theta<=1/4, with the full original zeta<=1,

    integral_beta P^(1-theta) zeta^theta
       <= a^(-n theta) integral_beta P^(1-2theta) V_C^(2theta)
       <= q^(1-2theta) a^(-n theta) mu_C^(2theta).

This uses the original same-point FIRST and does not grant it to a newly restricted posterior.

For the independent tail, first fix the soft menu value. On the same fixed node, H_theta=(H_(2theta) h_R P)^(1/2); 2theta<=1/2 permits the already proved fractional QG for the first factor. The second factor's cell integral is <=a^-n W_C(y), and the ordinary theta-QG also gives M^-n. Thus its cell column is at most M^-n min(1,(M/a)^(n/2)sqrt(W_C))<=M^-n V_C. Fixed parameters and the same cell/capture domain are essential; adaptive s(x) is covered only through the separately paid e N menu.

Every hard source contributing at x in C lies in E_C=C+Q_b; this geometric restriction is compatible with full original nu in both posterior slots and the heavy denominator. For boxes E_C is measurable (boundary null sets are harmless for the inherited absolutely continuous sources). The two valid beta-integrated node prices are therefore nu(E_C) times

    (2theta)^-1 ell^-theta rho_C^(2theta) c^(3theta n/2)
       exp(theta x_M)(1-exp(-2theta z)),
    (e N rho_C/4)c^(2n)exp(-x_M)z,
    rho_C=mu_C/(q a^n), z=(x_M-U)_+.

These are bounds on the same cell's actual node traffic. With R_C=1+log_+rho_C+log_+K+log(e N), theta_C=1/(4R_C), T_C=2log_+(e N rho_C), a safe all-node/all-j constant per leg/orientation is 30e+2 exp(1/4): small-node count <=3R_C, j sum <=5R_C, inverse-theta prefactor 2R_C, exponent <=e; the tail costs <=2 exp(1/4)R_C. This is an independent safe bound, not a claim the author's eventual constant must be this one.

The theta_C choice is legitimate after a disjoint measurable receiver-cell partition: each cell is fixed before its receiver integration and uses one exponent throughout that integration, all sources, nodes and times. A finite/countable positive cell sum and then an independent shift average are Tonelli operations. No common-exponent integration across different cells is asserted. This extension differs from allowing theta to change freely inside one static column.

For cells of side n b with uniform independent shift, the expected number of E_C containing any fixed z is exactly (1+1/n)^n<=e. Hence E_shift sum_C nu(E_C)<=e nu_mass. This pays unweighted hard-source duplication only. The actual local source-log moment E_shift sum_C nu(E_C)R_C^3 remains charged; the overlap identity alone does not bound it by a global input budget. A separated-cluster gain must be shown using the actual distance envelope mu_C, not merely asserted from the cell labels.

An additional local mathematical-tool run passed 72 high-precision scalar checks: 36 n=2 actual kernel-point envelope tests and 36 weighted-Holder tests at theta=.01,.125,.25. These temporary bounded diagnostics use finite source points and are not physical FULL inputs, archived replay experiments or a substitute for the above proof. Awaiting the precise author inequality and source ledger for final audit; no author draft read yet.

## Further exact candidate: condition on the original hard source

Before reading author derivations, a shorter conditional bridge was independently checked. Suppose the actual original mother has a measurable anchor/hard-source gate y in D_V(z), independent of j,node,time, or is contained in such a fixed measurable gate. This must be proved for y,z themselves; a target-v gate is insufficient. Define m_D(z)=beta(D_V(z)). One may first fix the original hard source z and choose theta_z from these frozen outer/z data before x,y,v,u,j,M,t. The pointwise fractional-good inequality and uniform physical e^4 cover still apply; all its exponent-dependent factors remain within the original nu(dz) integral. Both posterior slots and heavy floor continue to use full nu.

At fixed z, beta restricted to D_V(z) inherits the original same-point FIRST. With a certified static C(x,y,v,z)<=1 and full-nu target occupation zeta_z<=1, its source-Holder price is q^(1-theta_z)m_D(z)^theta_z. Now the fixed hard kernel, rather than the hard source mass, has integral_Omega h_R(x-z)dx<=1. Combining q^-1 in the original mother and the original heavy floor yields exactly

    (2theta_z)^-1 [rho_D(z)/ell]^theta_z
    c^(3theta_z n/2) exp(theta_z x_M)(1-exp(-2theta_z z_clock)),
    rho_D(z)=m_D(z)/(q a^n).

No C0 hard cap is needed in this route. The independent fixed-z QG/menu alternative is B rho_D(z)c^(2n)exp(-x_M)z_clock/4. Thus the R236 complete grid/j sum, including its constants, applies pointwise in z, followed by the original nu(dz) integral; it does not require the hard-source distribution to be an independent input or a restricted posterior. Zero m_D gives zero anchor traffic at that z before defining logarithms. A Borel graph D gives measurable m_D by Tonelli.

This conditional bridge would yield the explicit local moment integral nu(dz) [1+log_+rho_D(z)+log_+K+log(e N)]^3 with the original exterior 12 Lambda exp(4)(9 exp(3/2)+2 sqrt(e)). Its application remains pending exact verification of the original y-hard-z gate and its inherited radius/scales. The proposed radius 17 n a has not yet been authenticated in this statement-first review. Even with that gate, no general input/root bound for the local moment is supplied by the bridge alone.

## Original y/hard-z gate authenticated independently

The requested original passages were read directly, with one additional narrow check of the continuous-traffic formula:

- R113 joint_budget.md B3–B5: the actual hard source is the z integrated against nu_V in h_R(x-z), and the actual anchor/hard pairs are carried by D_V(y)=V intersect {||z-y||_1<=17 n a} intersect {||z-y||_infinity<=b(5 log n+1/2)}. B30 explicitly repeats z in D_V(y) for the new remainder; this is not only a statement about an auxiliary posterior source.
- R117 joint_geometry.md JG1 and its accompanying text distinguish auxiliary z-prime from original hard z. JG5 puts all inherited FULL/FIRST/CP/GP/deep, seed, failure and deletion gates in a_omega(x,y,z), without granting hard-z gates to the third source.
- R128 proof.md RT1 retains this same a_omega in the complete original row measure. RT2's continuous terminal-good positive remainder multiplies that unchanged row measure by the actual two-posterior traffic. Thus passing to the continuous-good term does not remove the anchor/hard source gate. RT4 confirms the two actual posterior processes are independent of hard z at fixed original j,y,t.
- R229 adaptive_geometry.md AG7 is explicitly before the hard cap, retains all original gates in chi and keeps the four sources beta(dy)nu(dz)nu(dv)nu(du).

Accordingly the original positive mother may retain a_omega<=1_Dorig(y,z) while positively relaxing other factors. On the inherited V supports Dorig is symmetric; after fixing z the anchor may be restricted to Dorig(z), or enlarged to the Borel l1 ball Dplus(z) of radius 17 n a. The gate and radius are frozen from the same original outer block and independent of the physical node and clock. This authenticates the actual applicability of the fixed-hard-source interface above, rather than merely the abstract conditional lemma. The source predicate is not transferred to either auxiliary posterior slot, and no part of full nu in e_t is removed.

Status after this source audit: the precise local fixed-hard-z interface is applicable to the original continuous-good far mother. The quantitative all-node inequality, final local-moment statement and any claimed source-input consequence still await author-proof review. No general root payment follows from this source authentication alone.

## Final author-proof and numerical audit

The complete parent proof (1)–(9), local_geometry.md LG1–LG9, source_ledger.md SL1–SL6, report and reproduction driver were read. The final primary route is the authenticated original hard-z source gate, not the preliminary receiver grid or an independently priced anchor/hard partition. All theta_z-dependent factors stay inside nu(dz) until the fixed-z node sum is finished. Physical covering is uniform in theta_z, the QG alternative has fixed hard z and its full e N menu cost, and both prices bound the same actual adaptive-soft node traffic. The R236 positive-grid sum applies pointwise in z, giving the stated 12 Lambda exp(4)(9 exp(3/2)+2 sqrt(e)) constant. The hard density cap C0 is not used or charged in this route.

A material presentation error was repaired in LG5: e_t=e_t(y) cannot remain a common denominator after beta integration. The corrected text first applies the original uniform floor E_floor(t) separately on each y's actual heavy times, then positively relaxes that mask and integrates beta. The parent proof already used this correct order. LG6 was also made explicit about retaining the certified C_z/capture qualification for its QG invocation. Both final repairs were read and passed. The local-source log price is pointwise no larger than the R236 leaf-total price, and it can be strictly smaller; log_+ saturation need not yield strict decrease for every data set.

Narrow original-ledger checks additionally confirmed R107's terminal side 256na, sigma-only low mean, retained M_alpha<sqrt(n)m_nu gate, original a/n birth pieces, fixed top-k rank and Lambda=128/119; R113 coupled C7–C9 preserves nu<=beta<=alpha and the original hard history. Thus the displayed coarse beta total cap and hard rank cell-count costs have the stated directions. They do not grant beta a hard-source density/rank cap or a root budget. Disjoint leaves of one full probability seed give E sum||nu_V||<=W_beta<=W_hi<=||f||_1 without repeating Lambda. No new history recovery or already-paid soft/hard budget is claimed from this source summary.

Both numeric source and notes were read completely. The six spatial models preserve the full target nu capacity, restrict only the anchor beta by D(z), and analytically integrate the fixed hard-z average within each separated cluster before real x/y quadrature. Their common q=2 follows from normalized kernels and f<=2. The E4 target antiderivatives include all remote source intervals. The finite remote target contributions can disappear when added to a larger float64 number, as disclosed; no source was removed from the definition. Compact support of the hard column accounts for the full spatial domain. GL8/16 refinement is an empirical floating diagnostic, not an interval bound or a 50-digit spatial integral. The other six cases retain exact Fraction breakpoints and local masses; only the elementary square-root budget values use ordinary high precision. All are conditional n=1 tools, not original FULL/large-n histories or a substitute for gate inheritance.

Independent complete numeric replay passed: 6 actual L1 integrals plus 6 rational local-mass configurations, entire 16714-byte JSON exactly equal to the frozen original, SHA256 16f720a234929d9d6a6c23a07f4fd78bacc472da43279ece98f6b2a4e29fc1ef. The source-ledger embedded three-case arithmetic was independently extracted/executed; all printed values and assertions matched. The earlier 33+72 temporary diagnostic checks remain separate, unarchived bounded checks, not additional formal replay configurations. The final driver copies the contract and numeric source outside the frozen package, compares the entire JSON, executes the ledger's embedded arithmetic and verifies the manifest before/after. Final manifest-driver execution belongs to the parent's later external receipt and is not claimed here.

**Final conclusion: pass for the stated original positive far remainder.** The new result is a genuine local-source moment estimate from an existing y/hard-z gate, including all node/soft/j/clock fees, with no new grid/source duplication fee. The nu-averaged local cubed logarithmic moment and the complementary branches remain unpaid toward the general arbitrary-positive-L1 root theorem. The source rank, terminal mass bounds and unweighted source budget do not close that gap. Negative/deletion credit is unused. This final conclusion supersedes the provisional awaiting-author statuses above.

The frozen hashes below exclude this audit itself. After the hash table, this file is released for parent freezing and no further audit writes are planned.

| File | SHA256 |
| --- | --- |
| task_contract.md | `5737db822bb7f60ceb426bb811cf0839f6fd03de980e96f31a139fd952db87d0` |
| proof.tex.txt | `044ffac0f4c382ed72b892ce3597b06493a945c0f31f7e602e535687ec600e7c` |
| local_geometry.md | `abacb8ef0fc24fc36ece8aa40d28315775d81c8e2b9d05ab647e53dcd9fbbc2b` |
| source_ledger.md | `2d9479dba286ffff9fa253b3b6008ba1f8f18813de55bd315d493f3b914b6a21` |
| report.md | `e0346dd6362437ee5ac81e170d66872cf90c6e280d08ad818110df022213bdd0` |
| numeric_checks.py | `fea68cc208cf411209e93aaaf901b0ebc7638529fa6720a0be8f361fdcd41d40` |
| numeric_checks.json | `16f720a234929d9d6a6c23a07f4fd78bacc472da43279ece98f6b2a4e29fc1ef` |
| numeric_notes.md | `a4d8bfdbad701e1c46a4e2cf922032eb599728ffa94edcfffc0bf127189566f3` |
| reproduce.py | `473810cdb12419cf6c2bbd5fd2dda0bccdbfd11be909a7e6c8a0f0b8f3913d56` |
