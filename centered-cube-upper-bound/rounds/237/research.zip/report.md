# 第237轮：原来源对几何与硬来源锚定局部预算

一般任意正L1输入的n^(1/2+o(1))一致弱型上界仍未闭合。本轮不是新的反例排除，也不以条件source模型替代全类任务。

## 新估计及实质变化

第236轮已支付真实receiver积分及全物理尺度，但用整叶beta(V)估来源拥挤。本轮回到保hard-z的原母式，准确恢复此前正上界中放掉的**原已有**来源对门：

    D_V(z)=V intersect {||y-z||_1<=17na}
                  intersect {||y-z||_infinity<=b(5log n+1/2)}.

这确实约束原soft y和原hard z；不是辅助posterior target v的资格。来源账作者与独审分别读取R113 B3/B5/B30、R117 JG5、R128 continuous母式和R229四来源表达核实了继承。只从原母式保留该门，不在已放大的R236最终右侧插门。

先固定实际hard z，再用m_D(z)=beta(D_V(z))选择theta_z。所有theta_z因子在nu(dz)积分内保留至该z的节点和结算。真实receiver源行界由beta|D-FIRST给出；hard列固定尺度归一。全部full-nu posterior及e_t(y)保留，先逐y用原heavy统一floor，再作beta积分，绝不把e_t(y)当共同分母。

同一actual-column的另一价格仍用R234固定soft菜单/QG/Gini，保原有效capture、eN菜单价；R236有限节点求和均匀于theta。最终获得（Lambda=128/119）

    P_far(U) <= 12 Lambda e^4 (9 e^(3/2)+2 sqrt(e))
        E sum_V integral_nuV [1+log_+(beta_V(D_V(z))/(qa^n))
                             +log_+K+log(e ceil(pi sqrt(n)))]^3.

零局部质量的原交通为零。无新seed、网格恢复或hard来源重复费用，所有j/M和原clock deficit已在该far余项中结算。

这对原source价格逐点不劣，并可严格改进：D(z)外的远处beta质量不再收费；对同一原数据，新右侧不大于第236轮同常数右侧。几何分离簇的费用按每簇局部质量而非全部簇总质量计算。这是一般局部公式的可验证后果，不是假称任意分离模型满足FULL。

## 原账确认与剩余瓶颈

原Lambda=128/119已包含在主式，不重复乘。固定full seed的终端V不交，nu<=beta<=mu_hi|V，所以 E sum||nu||<=W_beta<=W_hi<=||f||1；概率seed平均没有额外叶数费。此结论只支付无权质量，不支付局部log³矩。

原终端叶全边长256na；低均值属于hard sigma，不属于beta。结合已付相对小尾分支后的M_alpha<sqrt(n)m_nu，只能得全叶beta质量帽rho_beta<(4K256/3)(256n)^n，log帽O(nlogn)，不足根阶。hard rank只在原a/n细pieces成立，不能无代价升为physical-scale或beta rank。source_ledger.md逐项保存准确条件、来源、已花费用与界的方向。

因此当前剩余关键是：原D(z)内、真实共同来源的局部高质量尾，能否以根阶代价对nu平均支付；还须在原总账中组合其它分支。没有把主定理所列局部矩直接等同输入质量，没有宣称一般闭合。

## 调整过程与数值证据

初始receiver网格路径虽可证明局部加权质量估计，却需额外随机重叠费且几何较弱；发现原D门后，主线改为直接hard-z锚定。网格仅留简短辅助记录，不另计一个主账成果或重复付款。

本机现有Python3.12.14、NumPy2.3.5和mpmath1.3.0实际运行6个真实n1 L1来源门积分、6个精确Fraction localmass配置。三阶段初探/压力/扩展；fulltarget nu保持完整，q=2为全来源统一帽，不按簇重选。真实积分GL8/16加密，最大绝对变化约1.51e-9，非区间误差证书。真实费用/局部预算约.0505.. .0911；局部/全局预算约.6687.. .9891。另6项精确质量几何包含门边界部分相交与额外beta质量。n1模型不满足原large-n/FULL，继承靠原文与证明，不靠数值。

所有核心新数值均有脚本、输入、结果和合同绑定；独审已独立完整重算JSON逐字节一致。最终冻结驱动还将包外重放并前后核验manifest。附source_ledger内3项算术代码可重现保守源帽；主作者/独审其它临时诊断仅作实际运行记录，不冒称本驱动全部重放。

使用F05审查原核行列测度、E03审查真实source质量流和恢复常数；没有仅凭技能名称调用外部强定理。无可可靠归属本轮的额度扣减数据。每轮独立提交/推送，最终只新增README与ZIP，保LaTeX文本，不编译PDF。
