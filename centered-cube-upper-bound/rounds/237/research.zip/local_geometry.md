# R237：保原 hard–soft 来源对的局部三次对数预算

本轮把 R236 的整叶 `β(V)` 换成原 hard 来源 `z` 附近的真实局部质量 `β(D_V(z))`。原来源对门在物理 cover 前保留；固定 `z` 后选分数指数，再支付该 `z` 的全部 receiver、soft、physical、j 和 clock 费用。全程的辅助 posterior 仍由完整原 `ν` 定义。

主界见 LG8。它是原正 far 交通的无条件局部来源估计；并未证明任意输入的根阶总预算，因为最后仍有明确的局部来源对数矩。没有把任意新切割当成实际来源门。

## LG1. 原来源门的真实资格

固定原有限截断及外资料 `(ω,V)`，保 `0≤ν_V≤β_V≤f dx`、`0<a≤b≤2a`、`q,K>0` 及原全部 ancestry/remaining 资格。原同一 `a,b,q,β,ν` 在 `j` 间不变。`θ` 以下可以依原 hard 来源 `z`，但在 receiver `x`、soft 来源 `y`、auxiliary 来源 `v,u`、`j,M,t` 之前冻结。

原源门为对称 Borel 集

\[
 D_V(z)=V\cap\{y:\|y-z\|_1\le17na\}
 \cap\{y:\|y-z\|_\infty\le b(5\log n+1/2)\}. \tag{LG1}
\]

它确实承载 **原 soft 来源 y 与原 hard 来源 z**：

- R113 `joint_budget.md` B3–B5（原文件第 25–45 行）先给 `∫ν(dz)h_R(x−z)∫Γ_{x,z}(dy)`，再给 `Γ≤q^−1P_s,L β`，并明确 B5 的来源对承载性。
- 同文 B30（第 272–279 行）在实际 hard 积分中再保 `z∈D_V(y)`。
- R117 `joint_geometry.md` JG5（第 47–54 行）的原 RN 因子 `a_ω∈[0,1]` 保留全部这些原门。后续 R229 未 hard-cap 母式仍有原 `β(dy)ν(dz)ν(dv)ν(du)` 及门。

因此可在该母式先写 `a_ω=1_{D_V(z)}(y)a_ω`，再对其它正门作合法上放。不是在 R236 已经消去 hard 核的最终右侧重新插门，也没有给辅助 good 来源 `v` 或 bad 来源 `u` 添加 `D_V(z)` 资格。物理尺度向上取节点后，仍携带原 `D`，不由放大的 hard cube 重新计算这个集合。

这些原文的完整定位与来源继承由本轮 `source_ledger.md` 独立核验；作者亦实际窄读了 R113 B3–B5 和 R117 JG5。可把 `D` 换成任意预冻结可测上集，例如仅保 `l1` 半径 `17na`；主式使用较强的 LG1 交集。

## LG2. 原 full FIRST、静态性及零行

沿用 R236 已证的原 receiver 集 `Ω`。实际 softness `s(x)` 独立辅助时间及来源变量；原 full FIRST 对每个 `x∈Ω`、`A∈[a,b]`、`r≥s(x)` 给

\[
 \int P_{r,A}(x-w)f(w)dw\le q. \tag{LG2.1}
\]

特别可分别用于 `β` 和完整 `ν`，也可正限制来源槽到 `D_V(z)`。这不是对裁剪来源重选 FIRST。

`Π_t(y,dv)=e_t(y)^{-1}1_{Z_t(y)}(v)w_t(y,v)ν(dv)`、`e_t`、`Z_t`、`k_t` 均保持原定义；固定 `(ω,V,j,y,t)` 后不依 receiver `x` 或 hard 来源 `z`。`Z_t` 递减，`w_t=∏min(1,A_i/t)`，`0≤k_t≤n`，`δ_t(v,u)=(k_t(v)−k_t(u))_+`。两个槽用同一个完整原 `Π_t`。从不把 `ν` 改为 `ν|D(z)`，不重新归一化 posterior。

原 large-n/soft-margin/scale ancestry 沿 R236 保留，尤其 `s≤1−d_n`、`L≤b−2a/n`、`n>4·10^6 log(n+2)`。低维工具检查不构成 FULL 实例。原无效行、空时间窗、`e_t=0` 行按原规则置零。

定义

\[
 m_D(z)=\beta(D_V(z)),\qquad\rho_D(z)=\frac{m_D(z)}{qa^n}.
\]

它是预冻结原来源的可测函数。`m_D(z)=0` 时，该 `z` 的原 soft 来源积分为零，可以整行跳过，无需定义其优化指数。`ν=0` 亦为零。本文不使用 `m_D` 作为重建 posterior 的分母。

## LG3. 固定 hard z 的同一物理列

固定 `z` 及一个 `0<θ≤1/2`。原 good 的分数估计和物理 cover 完全逐点，对这个 `θ` 同样成立。原外系数是 `2Λ e^4(K/3)^θ`，有三个腿及两个物理朝向。

令 `γ=1+1/n`、`c=γ^−j`、`M0=a/c²`，节点 `M` 从 `M0` 按 `γ` 增长，末点截 `b` 且不重复。`M0>b` 时为空。两朝向为 `(L*,R*)=(M,c²M)` 或 `(c²M,M)`，`g*=cM`。三腿目标尺度为 `L*`、`min(b,γL*)`、固定 J 的 `b`。全部在 `[a,b]`，物理费用 `≤e^4`，不依 `θ,z`。

保原 `s(x)`，记

\[
 P_y(x)=P_{s(x),L^*}(x-y),\qquad
 Q(x,v)=P_{s(x),A^*}(x-v)
\]

用于前两腿；第三腿用 `Q=J=P_{1,b}`。令 `w_*=w_{g*}(y,v)`。选已认证的静态 capture `C_z(x,y,v)∈[0,1]`，可依当前固定 hard `z`，但独立辅助 `t,u`。其它 `z/t/u` 耦合门留在原左侧或正放；不把不静态的门放进该函数。原 R228/229 的 upper/lower-clamp 捕获区分仍保留，lower-clamp 不授全 core 排除。

定义 exact actual-soft 列

\[
 F_z(y,v)=q^{-1}\int_\Omega h_{R^*}(x-z)
 C_z(x,y,v)P_y(x)^{1-\theta}Q(x,v)^\theta
 w_*(y,v)^{-\theta}dx. \tag{LG3}
\]

原交通只在 `y∈D_V(z)` 积分。注意 hard 核现在没有积分掉，亦没有先取 `16/3` 帽。`P_y` 与 `Q` 允许随真实 receiver 改变 softness；不假设它们作为 `x` 的函数全空间归一。

## LG4. 两来源槽与固定 hard 核归一

设 `τ=a/c`，定义实际静态目标占用

\[
 \zeta_z(x,y)=q^{-1}\int_{Z_\tau(y)}
 C_z(x,y,v)^{1/\theta}Q(x,v)\nu(dv)\le1. \tag{LG4.1}
\]

此处仍是完整原 `ν`；最后一界由原 actual-soft target FIRST。对每个固定 `x,z`，原 source FIRST 和 Hölder 给

\[
 \begin{aligned}
 \int_{D_V(z)}P_y(x)^{1-\theta}\zeta_z(x,y)^\theta\beta(dy)
 &\le\left(\int_{D_V(z)}P_y(x)\beta(dy)\right)^{1-\theta}
 \left(\int_{D_V(z)}\zeta_z(x,y)\beta(dy)\right)^\theta\\
 &\le q^{1-\theta}m_D(z)^\theta.
 \end{aligned} \tag{LG4.2}
\]

`ζ_z` 可依 `y,z` 及其原 history，不需要将这些依赖独立化。现在只用真实 hard 核的全空间积分一：

\[
 \boxed{q^{-1}\int_\Omega h_{R^*}(x-z)
 \int_{D_V(z)}P_y^{1-\theta}\zeta_z^\theta\,d\beta\,dx
 \le(m_D(z)/q)^\theta.} \tag{LG4.3}
\]

这直接支付 receiver 积分，不留下 `|Ω|`，没有 hard-source 质量重复，也无需对固定 `z` 宣称某个 hardband 概率。`C0=16/3` 未被使用。

## LG5. 同一完整 posterior 的 heavy clock

记 `ξ=n log(M/M0)`、`u_M=ξ−U`、`h=g*e^−U/n`，其中 `U≥0`。只在 `u_M>0` 有效。实际 heavy 时钟满足

\[
 e_t>\ell qa^n c^{-3n/2}(t/\tau)^n,\qquad
 \ell=1+\log n,
\]

且原有效时间包含于 `[τ,h]`。对这个区间，`w_t≤(g*/t)^n w_*`。和 R236 一样，用 `δ≤k_v≤n`，另一原 posterior 槽总质量一及 Hölder 得

\[
 \iint C_zQ(x,v)^\theta w_*^{-\theta}\delta_t\,d\Pi_t^2
 \le n(g*/t)^{\theta n}(q\zeta_z/e_t)^\theta.
\]

这里 `e_t=e_t(y)` 依 soft 来源 anchor，不能先积分 `β(dy)` 再把它当成共同分母。正确顺序是：在每个 `y` 的**原实际 heavy 门内**，先以共同正下界

\[
 E_{\rm floor}(t)=\ell qa^n c^{-3n/2}(t/\tau)^n
\]

替代分母 `e_t(y)`。然后才正放这个门、乘 `(1/q)h_{R*}P_y^(1−θ)`，在原 `β|D(z)` 与 receiver 上积分并使用 LG4.2–3。所得每时刻上界为

\[
 n(g*/t)^{\theta n}\big(m_D(z)/E_{\rm floor}(t)\big)^\theta.
\]

**只有实际 heavy 时间** 使用 floor，再把正 majorant 积到整个节点区间，得到该固定 `z`、已积 soft 来源的交通

\[
 \boxed{\mathcal T_{jM,z}\le A_{D,\theta}:=
 \frac1{2\theta}(\rho_D(z)/\ell)^\theta
 c^{3\theta n/2}e^{\theta\xi}
 (1-e^{-2\theta u_M}).} \tag{LG5}
\]

积分是 `n∫_τ^h(t/τ)^−2θn dt/t=(1−e^−2θu_M)/(2θ)`。原 `2Λe^4(K/3)^θ` 尚未乘入。全部来源删除由原 `Z_t` 保留或正放，不使用其负信用，不用 `e_t` 导数。所有 deficit 及 `U≥0` 均覆盖。

## LG6. 固定 hard z 的独立 QG 尾备选

actual-soft 列不得直接调用 fixed-soft QG。和 R236 完全相同，使用最近 posterior 角公共菜单 `N=ceil(πsqrt n)`，点态价格 `e`，记 `B=eN`。移动两腿的 affine 总权为 `n`，J 腿为 `n(1−θ)`，同一菜单适用。

每个固定 soft 菜单点，R220/224 fractional QG 对当前 **固定 z** 给

\[
 \int h_{R^*}(x-z)C_z(x,y,v)P_r(x-y)^{1-\theta}
 Q_r(x,v)^\theta w_*^{-\theta}dx\le M^{-n}.
\]

此列并不含 hard 来源总质量。这里保留已证 QG 所需的 capture 支持；只在原证明允许的范围扩大 receiver 域或放松其它正门，不声明可以删除 QG 必需的捕获资格。因而 LG3 的同一实际列 `≤B/(qM^n)`。同一原 `Π_t` 的两个 iid score 满足 Gini 界

\[
 \iint(k_v-k_u)_+d\Pi_t^2
 =\int_0^n\Pi_t\{k>r\}(1-\Pi_t\{k>r\})dr\le n/4.
\]

积分原 clock，再积 **同一个** `β|D_V(z)`，得到

\[
 \boxed{\mathcal T_{jM,z}\le G_D:=
 \frac{B\rho_D(z)}4 c^{2n}e^{-\xi}u_M.} \tag{LG6}
\]

故可取 `min{A_D,θ,G_D}`；是同一 original actual-soft 节点交通的两种上界，不是将 `Psharp` 的上界误当成 QG。`B` 仅在尾备选里，不在容量支外。

## LG7. 每个 hard z 的指数选择与完整节点和

若 `m_D(z)>0`，设

\[
 R_D(z)=1+\log_+\rho_D(z)+\log_+K+\log B,
 \quad\theta_z=\frac1{2R_D(z)},\quad
 T_z=2\log_+(B\rho_D(z)). \tag{LG7.1}
\]

这是可测、预冻结的 hard-source 参数选择。原正积分先 Tonelli 暴露 `ν(dz)`，然后对每个 `z` 用统一成立的 LG3–6。没有将依 `z` 的指数移出 `ν` 积分；也没有修改原 posterior。辅助 `Π_t` 虽依 `y`，以上证明对每个 `y` 都沿其原定义进行，因此不要求 `Π_t` 与 `y` 独立。

为完整列出常数，令 `h0=n log γ∈[log2,1]`，`log2≥2/3`。对每个 `j`，正规 `ξ` 点为 `kh0`，至多另有一个不重复的截尾点。

在 `ξ≤T_z`，节点数 `≤T_z/h0+2≤3R_D`；

\[
 \sum_{j\ge0}c^{3\theta_z n/2}
 \le1+\frac2{3\theta_z h0}\le3R_D,
\]

且 `(K/3)^θ ρ_D^θ exp(θT_z)≤e^(3/2)`。用第一价、`ell^−θ≤1` 和 `1/(2θ)=R_D`，小节点和至多 `9e^(3/2)R_D³`。

正规尾的几何级数与额外截尾点分别给

\[
 \sum_{M:\xi>T_z}\xi e^{-\xi}
 \le3(T_z+1)e^{-T_z},\qquad
 \sum_{j\ge0}c^{2n}\le4/3.
\]

例如正规尾从 `T_z+s` 开始，`0<s≤h0`，其和为
`e^(−T_z−s)[(T_z+s)/(1−e^−h0)+h0e^−h0/(1−e^−h0)^2]≤2(T_z+1)e^−T_z`；额外点至多 `(T_z+1)e^−T_z`。使用 `u_M≤ξ`、`(K/3)^θ≤sqrt e`、`Bρ_D e^−T_z≤1`、`T_z+1≤2R_D`，大节点和至多 `2sqrt e R_D≤2sqrt e R_D³`。

因此每个固定 `z`、每条腿、每个朝向，在已经乘 `(K/3)^θ_z` 后有

\[
 \sum_{j,M}(K/3)^{\theta_z}\mathcal T_{jM,z}
 \le\widetilde D R_D(z)^3,\qquad
 \widetilde D=9e^{3/2}+2\sqrt e. \tag{LG7.2}
\]

这个和已结清所有 `j` 与物理节点，使用原 `a,q,β,ν,D` 共同跨 `j` 的资格。若换了来源、窗口或源门，必须分别列账，不能应用此一次求和。

## LG8. 新局部来源主定理与真实支付范围

恢复原 `2Λe^4`、三个腿及两个朝向，得到

\[
 \boxed{P_{\rm far}(U)\le
 12\Lambda e^4\widetilde D\,
 \mathbb E\sum_V\int_V
 \left[1+\log_+\frac{\beta_V(D_V(z))}{q_Va_V^n}
       +\log_+K+\log\big(e\lceil\pi\sqrt n\rceil\big)\right]^3
 \nu_V(dz).} \tag{LG8}
\]

`m_D=0` 的被积贡献实际可取零。上式保守写法亦合法。无 `C0`、新网格恢复费、外乘 `N` 或 `sqrt n`。这覆盖原实际的全部 softness、物理尺度、deficit 和该 far 分支的所有有效 clock；`U=0` 不包含别的 near/此前分配分支，`U≥n log(b/a)` 时节点全空。

由于 `D_V(z)⊂V`，LG8 的右侧逐 `z` 不大于 R236 同常数的全叶右侧。改进是可计算的真实空间切断：对给定 `z`，任何位于 LG1 集之外的原 `β` 质量对当前局部价格贡献恰为零；不是用一个新名字记录同一个总质量。它来自原母账的承载性，不是重新删掉原正交通。

更定量地，若原来源有预冻结分区 `β=Σ_iβ_i`、`ν=Σ_iν_i`，且 `ν_i` 支撑上的每个 `D(z)` 不遇到其它 `β_j`（例如这些支撑间的 `l∞` 距离大于 `b(5log n+1/2)`），则 LG8 的来源价至多

\[
 \sum_i\|\nu_i\|
 \left[1+\log_+\frac{\|\beta_i\|}{qa^n}
 +\log_+K+\log(eN)\right]^3.
\]

这是对任何满足该几何关系的原资料的推论，不假称任意构造的分离模型已满足全部 FULL 条件。远处其它分区的质量不进入该价格，且每份 hard 来源只付一次。

在原 hard 来源子集 `E_H={z:R_D(z)≤H_n}` 上，整个上述 far 子交通已付
`12Λe^4 Dtilde H_n³ EΣν(E_H)`。取 `H_n=n^(1/6)L_n` 即为明确根阶 `sqrt n L_n³` 分支。其补集的真实价就是 LG8 中对应局部三次对数矩；没有假设它免费由 `Wν` 控制。

原祖链的质量/秩/低占比资格可用于以后估计这个局部矩，但本稿没有授 `β` 点态密度帽、没有重删 top-k、也没有消费任何已用的负信用。一般任意输入的 `sqrt n n^o(1)` 目标仍未闭合。

## LG9. 未采用的网格路径与本机检查范围

本轮先筛过一个不使用原 D 门的较弱空间方案：receiver 立方胞边长 `nb`，
`W_C(y)=exp[−Σ(dist(y_i,C_i)/b−1/2)_+]`，
`V_C=min(1,(b/a)^(n/2)sqrt W_C)`。
对所有原 soft/scale，`P(x−y)≤a^−nW_C(y)`。`θ≤1/4` 时，固定-soft 插值
`H_θ=(H_{2θ} h_RP)^(1/2)` 结合 QG 给限制胞列 `≤M^−nV_C(y)`；来源 Hölder 给 `q^(1−2θ)a^−nθ(∫V_Cβ)^(2θ)`。随机平移可把 hard 来源胞重复费限于 `(1+1/n)^n≤e`。这条链经预筛成立，但不及保原 D 的 LG8，故不将其展开为第二套主账或重复领取预算。

作者本机实际运行了两组有限检查（Python/mpmath；原 vendor 运行时）：

1. 50 位精度、随机种子 `237`，`n=2,4,8` 各 20 例，共 60 个原 `h/φ` cell-envelope 与 anchored-weight 检查。`a=1,b=2`，胞为 `[0,2n]^n`，`x_i` 均匀于胞，`z_i` 均匀于 `[−1,2n+1]`，`y_i` 均匀于 `[−6n,8n]`，`L` 均匀于 `[1,2]`，`s` 从 `{0,.01,.5,1}` 抽取。原 `φ` 用 R236 的 `expint(3,·)` 精确解析式，核验 `P≤a^−nW_C` 及 `V_C≤min(1,(b/a)^(n/2)exp[−Σ(|y_i−z_i|/b−n−1)_+/2])`。全部通过，最大第一比值 `0.0019618189712740102`。
2. `n∈{2,16,64}`、`ρ∈{10^−8,.1,1,10^4,10^12}`、`K∈{1,100}`、`U∈{0,.5,2}`，共 90 个实际截 b 节点求和。检查上述较弱网格费用的 `θ=1/(4R)`、常数 `30e+2e^(1/4)` 三次对数界，全部通过，最大比值 `0.0013475790120583498`。

这些作者运行只核实辅助几何/有限算术，没有作为原 D 来源继承证据，也不构成 FULL 实例或维数拟合。主 LG8 使用 R236 已证节点和及 LG1 的原文资格；本轮 numeric/audit 的独立运行按各自文件记录。本文不声称替其它工作者执行过检查。

本稿只占有 `local_geometry.md`，不改变原来源、posterior、FIRST 或其它工作者文件。所有对历史原门的恢复均从未 hard-cap 的母式开始。
