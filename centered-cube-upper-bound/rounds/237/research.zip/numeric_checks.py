#!/usr/bin/env python3
"""Finite source-gated L1 tools, full target nu preserved. Not FULL."""
import argparse,hashlib,json,math
from pathlib import Path
from fractions import Fraction as F
import numpy as np
import mpmath as mp
ROOT=Path(__file__).resolve().parent

def phi(x):
 x=abs(mp.mpf(x));h=mp.mpf('.5')
 def E3(t):return h if not t else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
 return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def phiintegral(lo,hi):
 lo=mp.mpf(lo);hi=mp.mpf(hi);half=mp.mpf('.5')
 if hi<=-half:return phiintegral(-hi,-lo)
 if lo>=half:return mp.expint(4,lo-half)-mp.expint(4,lo+half)-mp.expint(4,hi-half)+mp.expint(4,hi+half)
 if lo<-half:return phiintegral(lo,-half)+phiintegral(-half,hi)
 if hi>half:return phiintegral(lo,half)+phiintegral(half,hi)
 def primitive(t):return t-mp.expint(4,half-t)+mp.expint(4,half+t)
 return primitive(hi)-primitive(lo)
def nodes(lo,hi,order,breaks=()):
 zs,ws=np.polynomial.legendre.leggauss(order);p=sorted(set([lo,hi]+[t for t in breaks if lo<t<hi]));xx=[];ww=[]
 for a,b in zip(p,p[1:]):xx.extend((a+b)/2+(b-a)*zs/2);ww.extend((b-a)*ws/2)
 return np.array(xx),np.array(ww)
def physical(c,order,dps):
 count=c['clusters'];s=c['s'];theta=c['theta'];h=.1;q=2.;centers=[40*j for j in range(count)];fee=0.;remote=0.;maxcap=0.;maxrow=0.;mass=.2*count
 with mp.workdps(dps):
  for center in centers:
   xs,xw=nodes(-.6,.6,order,(-.4,.4))
   for xr,wx in zip(xs,xw):
    x=center+xr;H=max(0.,min(h,xr+.5)-max(-h,xr-.5));cap=0.;owncap=0.;remotecap=0.
    for v in centers:
     lo=mp.mpf(str(x))-mp.mpf(str(v))-mp.mpf('0.1');hi=lo+mp.mpf('.2');hard=max(mp.mpf(0),min(hi,mp.mpf('.5'))-max(lo,-mp.mpf('.5')));term=(1-s)*hard+s*phiintegral(lo,hi);cap+=float(term)
     if v==center:owncap=float(term)
     else:remotecap+=float(term)
    ys,yw=nodes(-h,h,order,(xr-.5,xr+.5));dens=np.array([(1-s if abs(xr-y)<=.5 else 0)+s*float(phi(str(xr-y))) for y in ys]);row=float(np.sum(yw*dens**(1-theta)));fee+=wx*H/q*(cap/q)**theta*row
    remote+=wx*remotecap;maxcap=max(maxcap,cap);maxrow=max(maxrow,row)
 local=mass*(.2/q)**theta;globalfee=mass*(mass/q)**theta
 assert maxcap<=1+1e-12 and fee<=local*(1+1e-12)
 return {k:format(v,'.17g') for k,v in dict(actual_beta_fee=fee,local_budget=local,global_budget=globalfee,actual_over_local=fee/local,local_over_global=local/globalfee,full_nu_mass=mass,beta_mass=mass,q=q,max_full_target_capacity=maxcap,max_local_receiver_power_row=maxrow,integrated_remote_target_capacity=remote).items()}

def local_mass(z,beta):return sum(d*max(F(0),min(hi,z+17)-max(lo,z-17)) for lo,hi,d in beta)
def rational_case(c):
 beta=[tuple(map(F,v)) for v in c['beta']];nu=[tuple(map(F,v)) for v in c['nu']];bm=sum((b-a)*d for a,b,d in beta);nm=sum((b-a)*d for a,b,d in nu);assert all(any(A<=a and b<=B and d<=D for A,B,D in beta) for a,b,d in nu);pieces=[];integral_mass=F(0);localroot=mp.mpf(0);q=F(2)
 for lo,hi,d in nu:
  knots=sorted(set([lo,hi]+[t for a,b,_ in beta for t in (a-17,a+17,b-17,b+17) if lo<t<hi]))
  for a,b in zip(knots,knots[1:]):
   ma=local_mass(a,beta);mb=local_mass(b,beta);assert 0<=ma<=bm and 0<=mb<=bm
   integral_mass+=d*(b-a)*(ma+mb)/2;pieces.append({'z_lo':str(a),'z_hi':str(b),'nu_density':str(d),'mD_lo':str(ma),'mD_hi':str(mb)})
   # theta=1/2 exact elementary integral of square root of affine mass.
   aa=mp.mpf(ma.numerator)/ma.denominator;bb=mp.mpf(mb.numerator)/mb.denominator;width=mp.mpf((d*(b-a)).numerator)/(d*(b-a)).denominator
   localroot+=width*mp.sqrt(aa/2) if ma==mb else width*2*(bb**mp.mpf('1.5')-aa**mp.mpf('1.5'))/(3*(bb-aa)*mp.sqrt(2))
 globalroot=mp.mpf(nm.numerator)/nm.denominator*mp.sqrt(mp.mpf(bm.numerator)/bm.denominator/2)
 assert integral_mass<=nm*bm and localroot<=globalroot*(1+mp.mpf('1e-50'))
 return dict(configuration=c,beta_mass_exact=str(bm),nu_mass_exact=str(nm),nu_integral_mD_exact=str(integral_mass),nu_beta_mass_product_exact=str(nm*bm),segments=pieces,theta='1/2',local_source_budget=mp.nstr(localroot,32),global_source_budget=mp.nstr(globalroot,32),local_over_global=mp.nstr(localroot/globalroot,32),scope='Fraction exact interval localmass and its affine pieces; budget square-root evaluation ordinary high precision; no actual spatial kernel integral.')
def main(output):
 menu=[dict(stage=stage,clusters=count,s=s,theta=t) for stage,count,s,ts in [('initial',2,.5,[.5,.1]),('stress',3,.99,[.01,.1]),('expanded',5,.05,[.01,.25])] for t in ts];rows=[]
 for c in menu:
  a=physical(c,8,25);b=physical(c,16,50);rows.append(dict(configuration=c,GL8_mp25=a,GL16_mp50=b,absolute_fee_refinement_difference=format(abs(float(a['actual_beta_fee'])-float(b['actual_beta_fee'])),'.8g')))
 exact=[]
 for stage,dist in [('initial','40'),('initial','17'),('stress','169/10'),('stress','171/10'),('expanded','100'),('expanded','1000')]:
  D=F(dist);beta=[('0','1','1'),(str(D),str(D+1),'1')];nu=[('0','1','1')]
  if stage=='expanded':beta.append((str(2*D),str(2*D+1),'1'));nu.append((str(D),str(D+1),'1/2'))
  with mp.workdps(70):exact.append(rational_case(dict(stage=stage,distance=dist,beta=beta,nu=nu)))
 payload=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),contract_sha256=hashlib.sha256((ROOT/'task_contract.md').read_bytes()).hexdigest(),scope='Conditional source-gated true n1 L1 tools plus rational localmass diagnostics; not original mother inheritance/FULL.',definitions=dict(D='|y-z|<=17, fixed actual hard source z',physical_fee='integral nu(dz) integral h_1(x-z)/q [q^-1 integral_fullnu P_s(x-v)dnu(v)]^theta integral_{D(z)} P_s(x-y)^(1-theta)dbeta(y) dx',local_budget='integral_nu (beta(D(z))/q)^theta dz',global_budget='nu_mass*(beta_mass/q)^theta',q='2, all-source and all-receiver fixed: disjoint beta density1, f2beta has Linfinity2, normalized P gives FIRST<=2',posterior='Full nu source capacity preserved; D restricts y beta only; C1 relaxed all sources.',physical_sources='beta=nu=sum density1 indicator intervals [40j-1/10,40j+1/10], j=0..clusters-1; f=2beta; all x in union hard supports [40j-.6,40j+.6] integrated, outside hard column zero' ,numerics='numpyfloat64 GL8/16 hard splitting, mp25/50 truephi evaluations; E4 target interval integrals independent of target quadrature, no missing compact-domain integration tails.'),physical_rows=rows,rational_localmass_rows=exact,counts=dict(actual_L1_integrals=len(rows),rational_localmass_cases=len(exact)))
 Path(output).write_text(json.dumps(payload,indent=2,sort_keys=True,allow_nan=False)+'\n');print(payload['counts'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',default=str(ROOT/'numeric_checks.json'));main(p.parse_args().output)
