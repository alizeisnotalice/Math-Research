#!/usr/bin/env python3
"""Frozen-package verification and relocated full numerical replay; no PDF."""
import argparse,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    hashes=json.loads((ROOT/'manifest.json').read_text())
    for name,h in hashes.items():assert digest(ROOT/name)==h,name
    return len(hashes)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--output-dir',type=Path);args=ap.parse_args();count=verify()
    if args.verify_only:print('verified',count,'manifest hashes');return
    if args.output_dir is None:ap.error('--output-dir required')
    out=args.output_dir.resolve()
    if out==ROOT or ROOT in out.parents:ap.error('output must be outside package')
    env=os.environ.copy()
    out.mkdir(parents=True,exist_ok=False);runs=[]
    shutil.copyfile(ROOT/'task_contract.md',out/'task_contract.md')
    for stem in ('numeric_checks',):
        shutil.copyfile(ROOT/(stem+'.py'),out/(stem+'.py'))
        start=time.monotonic();subprocess.run([sys.executable,str(out/(stem+'.py')),'--output',str(out/(stem+'.json'))],env=env,check=True)
        assert (out/(stem+'.json')).read_bytes()==(ROOT/(stem+'.json')).read_bytes(),stem+' entire JSON differs'
        runs.append({'driver':stem+'.py','entire_json_byte_identical':True,'json_sha256':digest(out/(stem+'.json')),'elapsed_seconds':time.monotonic()-start})
    code=(ROOT/'source_ledger.md').read_text().split('```python\n',1)[1].split('```',1)[0]
    path=out/'source_ledger_checks.py';path.write_text(code)
    r=subprocess.run([sys.executable,str(path)],env=env,check=True,capture_output=True,text=True)
    runs.append({'driver':'source_ledger.md embedded arithmetic','checks':3,'stdout':r.stdout.strip(),'exit_code':r.returncode})
    assert verify()==count
    receipt={'complete_replay':True,'manifest_hashes_before_and_after':count,'runs':runs,'python':sys.executable,'scope':'Six true one-dimensional L1 integrals and six rational local-mass cases; not FULL histories or a general input-moment budget. Requires the recorded local math-library versions for byte-identical replay.'}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
