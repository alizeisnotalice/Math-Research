"""R759 guard geometry, marked reversible kernel and predictable regions."""

import argparse
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from math import comb, factorial, prod
from pathlib import Path
from platform import python_version


def cube(y,r):
    return tuple((x-r,x+r) for x in y)


def length(I):
    return max(Q(0),I[1]-I[0])


def intersect(*intervals):
    return max(a for a,_ in intervals),min(b for _,b in intervals)


def point_in_box(x,A):
    return all(a<=y<=b for y,(a,b) in zip(x,A))


def norm_inf(x,y):
    return max(abs(a-b) for a,b in zip(x,y))


def geometry_certificate():
    cases = [
        # name, s_t, entry x, redraw z, child center, s_k, passes, hit fraction
        ("small_pass",1,(0,),(Q(5,16),),(Q(11,32),),Q(1,32),True,Q(1)),
        ("medium_exact",1,(0,),(Q(31,64),),(Q(63,64),),Q(1,2),True,Q(1)),
        ("medium_fail_but_full_hit",1,(0,),(Q(1,2),),(Q(1,2),),Q(1,2),False,Q(1)),
        ("medium_fail_partial",1,(0,),(Q(1,2),),(1,),Q(1,2),False,Q(1,2)),
        ("medium_fail_no_hit",1,(0,),(Q(3,4),),(Q(9,8),),Q(1,2),False,Q(0)),
        ("large_pass",1,(0,),(0,),(Q(31,32),),Q(31,32),True,Q(1)),
        ("large_impossible_guard_but_full_hit",1,(0,),(0,),(Q(1,8),),Q(63,64),False,Q(1)),
        ("two_dimensional_exact",1,(0,0),(Q(61,256),0),(Q(253,256),Q(3,8)),Q(3,4),True,Q(1)),
        ("two_dimensional_partial",1,(0,0),(Q(3,4),Q(3,4)),(1,1),Q(1,2),False,Q(1,4)),
        ("translated_scaled_exact",2,(Q(5,4),),(Q(71,32),),(Q(103,32),),Q(1),True,Q(1)),
        ("two_active_excess_axes_sharp",1,(0,0,0,0),(Q(7,8),Q(13,16),Q(1,8),Q(1,16)),
         (Q(9,8),Q(17,16),Q(1,8),Q(1,16)),Q(1,4),False,Q(0)),
        ("two_active_excess_axes_slack",1,(0,0,0,0),(Q(7,8),Q(13,16),Q(1,8),Q(1,16)),
         (Q(7,8),Q(13,16),Q(1,8),Q(1,16)),Q(1,4),False,Q(1)),
    ]
    result = []
    for name,s_t,x,z,y,s_k,passes,fraction in cases:
        n = len(x)
        s_t = Q(s_t)
        x,z,y = (tuple(map(Q,point)) for point in (x,z,y))
        a = 32*n
        h = 1+Q(1,a)
        assert 0 < s_k < s_t
        A_t,A_k = cube(x,s_t),cube(y,s_k)
        E_t,E_k = cube(x,Q(s_t,a)),cube(y,s_k/a)
        assert point_in_box(x,A_t) and point_in_box(z,A_t) and point_in_box(z,A_k)
        assert not prod(length(intersect(I,J)) for I,J in zip(E_t,E_k))
        closed_guard = norm_inf(z,x)+h*s_k
        corners = tuple(product(*E_k))
        farthest = max(norm_inf(e,x) for e in corners)
        assert farthest <= closed_guard
        b_terms = [max(Q(0),abs(z_l-x_l)/s_t+h*s_k/s_t-1) for z_l,x_l in zip(z,x)]
        b = sum(b_terms)
        owner_drift = max(sum(max(Q(0),abs(e_l-x_l)/s_t-1) for e_l,x_l in zip(e,x))
                          for e in corners)
        assert (b==0) == passes and owner_drift<=b
        if name.startswith("two_active"):
            assert b_terms == [Q(65,512),Q(33,512),Q(0),Q(0)]
            assert owner_drift == (b if name.endswith("sharp") else 0)
        hit = prod(length(intersect(I,J)) for I,J in zip(E_k,cube(x,s_t)))
        v_k = prod(map(length,E_k))
        assert v_k > 0 and hit/v_k == fraction
        assert (closed_guard <= s_t) == passes
        if passes:
            assert all(point_in_box(e,cube(x,s_t)) for e in corners)
        boundary_corners = sum(norm_inf(e,x)==s_t for e in corners)
        if closed_guard == s_t:
            assert hit==v_k and boundary_corners>0
        result.append({
            "case":name,"n":n,"a":a,"x":list(map(str,x)),"z":list(map(str,z)),
            "child_center":list(map(str,y)),"scale_ratio":str(s_k/s_t),
            "parent_half_side":str(s_t),"guard_left_side":str(closed_guard),
            "guard_passes":passes,"actual_farthest_corner":str(farthest),
            "owner_boundary_corners":boundary_corners,"owner_inside_fraction":str(hit/v_k),
            "active_drift_terms":list(map(str,b_terms)),"drift_upper_b":str(b),
            "actual_max_owner_drift":str(owner_drift),
        })
    return result


def measure_of(U,interval):
    # Each U used here is a disjoint finite interval union up to endpoints.
    return sum((length(intersect(I,interval)) for I in U),Q(0))


def kernel_certificate():
    a = 32
    G_upper,K = Q(65,32),Q(1)
    beta = K/G_upper
    t,left,right = "t","h_left","h_right"
    children = tuple(f"k{i}" for i in range(4))
    st = {t:(Q(0),Q(1)),left:(Q(-3,8),Q(3,2)),right:(Q(3,8),Q(7,4))}
    st.update({k:(Q(2*i-3,4),Q(1,4)) for i,k in enumerate(children)})
    labels = tuple(st)
    support = (Q(-3),Q(3))
    A = {j:cube((x,),s)[0] for j,(x,s) in st.items()}
    E = {j:cube((x,),s/a)[0] for j,(x,s) in st.items()}
    d = {j:length(A[j]) for j in labels}
    v = {j:length(E[j]) for j in labels}
    m = {j:2*length(intersect(A[j],support)) for j in labels}
    assert all(m[j]==2*d[j] and v[j]>0 for j in labels)
    assert all(length(intersect(E[j],E[k]))==0 for j,k in combinations(labels,2))
    g0 = {j:v[j]/m[j] for j in labels}
    lam = {j:beta*g0[j] for j in labels}
    admit = {frozenset((j,t)):A[j] for j in children}
    admit[frozenset((left,t))] = A[children[0]]
    admit[frozenset((right,t))] = (Q(3,4),Q(1))

    xs = sorted({x for I in (support,*A.values(),*admit.values()) for x in I})
    by_pair = {(j,k):[] for j,k in product(labels,labels)}
    for lo,hi in zip(xs,xs[1:]):
        cut = lo,hi
        z = (lo+hi)/2
        if not support[0] < z < support[1]:
            continue
        present = [j for j in labels if A[j][0] < z < A[j][1]]
        F = sum(lam[j] for j in present)
        W = sum(g0[j] for j in present)
        if not W:
            continue
        assert 0 < F <= 1 and F/W == beta
        for j,k in product(present,present):
            gate = admit.get(frozenset((j,k)))
            if gate is not None and gate[0] < z < gate[1]:
                # 2/m_j is the actual price density on A_j.
                row_density = Q(2)/m[j]*F*g0[k]/W
                by_pair[j,k].append((cut,row_density))

    def flow(j,k,T):
        return sum((dens*measure_of(T,I) for I,dens in by_pair[j,k]),Q(0))

    whole = (support,)
    C = {(j,k):flow(j,k,whole) for j,k in by_pair}
    D = {(j,k):C[j,k] if d[k]<d[j] else Q(0) for j,k in C}
    assert all(sum(C[j,k] for k in labels)<=1 for j in labels)
    assert all(v[j]*C[j,k]==v[k]*C[k,j] for j,k in C)
    assert all(sum(v[j]*D[j,k] for j in labels)<=v[k] for k in labels)
    assert all(D[t,k]==Q(1,520) for k in children)
    row_mass = sum(D[t,k] for k in children)
    owner_density = beta/m[t]
    assert row_mass == Q(1,130) and owner_density == Q(8,65)
    assert all(D[t,k]/v[k]==owner_density for k in children)

    history_cases = []
    for prev,k in ((left,children[0]),(right,children[-1])):
        weight = v[prev]*D[prev,t]
        assert weight>0 and D[prev,t] == flow(prev,t,(A[k],))
        # The predictable rule is the leftmost cell if x<0 and rightmost if x>0.
        k_in = children[0] if A[k][1]<0 else children[-1]
        assert k == k_in
        pre_price_hit = sum(flow(t,j,(A[k],)) for j in children)
        peek_price_hit = sum(flow(t,j,(A[j],)) for j in children)
        pre_owner_hit = sum(D[t,j]*length(intersect(E[j],E[k]))/v[j] for j in children)
        peek_owner_hit = sum(flow(t,j,(A[j],))*length(E[j])/v[j] for j in children)
        assert pre_price_hit == pre_owner_hit == row_mass/4
        assert peek_price_hit == peek_owner_hit == row_mass
        history_cases.append({
            "previous_label":prev,"previous_price_support":list(map(str,admit[frozenset((prev,t))])),
            "raw_arrival_mass":str(weight),"predictable_cell":k,
            "each_selected_price_volume":str(length(A[k])),"each_selected_owner_volume":str(v[k]),
            "predictable_hit_given_next_survival":str(pre_price_hit/row_mass),
            "peek_hit_given_next_survival":str(peek_price_hit/row_mass),
            "predictable_owner_hit_mass":str(pre_owner_hit),"peek_owner_hit_mass":str(peek_owner_hit),
        })
    assert Q(history_cases[0]["raw_arrival_mass"]) == 2*Q(history_cases[1]["raw_arrival_mass"])

    price_tests = (
        whole,
        ((Q(-7,8),Q(-5,8)),(Q(1,16),Q(11,16))),
        ((Q(-5,2),Q(-2)),(Q(1),Q(5,2))),
    )
    owner_tests = (
        whole, (E[children[0]],),
        ((Q(-3,4),Q(-1,4)),(Q(1,4),Q(3,4))),
    )
    tested_sets = []
    for T,S in product(price_tests,owner_tests):
        lhs = sum(flow(t,k,T)*measure_of(S,E[k])/v[k] for k in children)
        restricted_density = {
            k:owner_density*2*measure_of(T,intersect(A[t],A[k]))/m[k]
            for k in children
        }
        rhs = sum(restricted_density[k]*measure_of(S,E[k]) for k in children)
        assert lhs == rhs <= owner_density*sum(map(length,S))
        tested_sets.append({
            "common_price_T":[list(map(str,I)) for I in T],
            "common_owner_S":[list(map(str,I)) for I in S],
            "owner_density_on_each_child":[str(restricted_density[k]) for k in children],
            "accepted_hits":str(lhs),
        })
    return {
        "mu":"2 times Lebesgue on [-3,3]","m":{j:str(m[j]) for j in labels},
        "d":{j:str(d[j]) for j in labels},"v":{j:str(v[j]) for j in labels},
        "parents":{j:list(map(str,A[j])) for j in labels},
        "owners":{j:list(map(str,E[j])) for j in labels},
        "beta":str(beta),"G_upper":str(G_upper),"K":str(K),"active_D":{f"{j}->{k}":str(w) for (j,k),w in D.items() if w},
        "one_step_row_mass":str(row_mass),"exact_unconditional_owner_density":str(owner_density),
        "current_parent_d_instead_of_m_gives":str(beta/d[t]),
        "predictability_check":history_cases,"common_sets_density_check":tested_sets,
    }


def shape_certificate():
    # In the positive orthant the last coordinate is either <=1 (no
    # excess) or 1+w with 0<w<=s. This gives a separate coefficient recursion.
    coeff = [Q(1)]
    shapes = []
    for n in range(1,65):
        prior = coeff
        coeff = [(prior[j] if j<n else 0)+(prior[j-1]/j if j else 0) for j in range(n+1)]
        if n in (2,8,64):
            assert coeff == [Q(comb(n,j),factorial(j)) for j in range(n+1)]
            shapes.append({"n":n,"tested_s_and_Lambda_n": [
                [str(s),str(sum(c*s**j for j,c in enumerate(coeff)))]
                for s in (Q(0),Q(1,64),Q(1,4),Q(1))
            ]})
    # With w=1+log u the positive-tail integral is integral w^(-2) dw.
    # Cut at u=exp(t); the tail there is 1/(1+t), which tends to zero.
    finite = []
    for t in (0,1,4,32):
        tail = Q(1,1+t)
        partial = Q(t,1+t)
        assert partial+tail==1 and 1+partial+tail==2
        finite.append({"log_upper_cut": t,"partial_integral":str(partial),"tail_integral":str(tail)})
    return {"normalized_cube_excess_volumes":shapes,"Phi_integral": "1",
            "baseline_plus_Phi_integral":"2","Phi_exact_cuts":finite}


def report():
    return {
        "scope":(
            "Actual intervals and boxes with disjoint positive-volume full owners. "
            "The marked reversible kernel is a finite preterminal symmetric gate with actual price masses. "
            "The guard uses a closed target; its open-target volume agrees at the tested boundary."
        ),
        "python":python_version(),"source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "geometry":geometry_certificate(),"marked_kernel":kernel_certificate(),
        "shape_and_Phi":shape_certificate(),
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out",type=Path)
    group.add_argument("--check",type=Path)
    args = parser.parse_args()
    result = report()
    data = (json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data, "certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    print(f"{len(result['geometry'])} spatial cases, two histories and "
          f"{len(result['marked_kernel']['common_sets_density_check'])} common-set tests")


if __name__ == "__main__":
    main()

