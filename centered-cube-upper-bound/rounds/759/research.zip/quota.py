"""Check the simultaneous volume allocation in the relative radius bins."""
from fractions import Fraction
from math import isqrt
from flint import arb, ctx

ctx.prec = 256
for n in (16, 256, 4096, 65536):
    root = isqrt(n)
    assert root**2 == n
    h = 1 + arb(1) / (32*n)
    L = arb(root)
    for j in (0, n//2, n, 4*n):
        radius = (-((L + j*arb(2).log())/n)).exp()
        cover = (1-h*radius)/2
        enlarged = cover+h*radius
        log_capacity = (L/(2*(j+1)**2)).log() - n*enlarged.log()
        assert cover > 0 and enlarged < 1
        assert log_capacity > 0
        size_log_angle = log_capacity + n*enlarged.log()
        assert (size_log_angle - (L/(2*(j+1)**2)).log()).contains(0)
        if n >= 4096:
            assert log_capacity > L/8 + arb(2).log()
        print(n, j, 'cover radius/s_t', cover.str(8), 'log pre-floor quota', log_capacity.str(8))
# A rational finite example also counts overlaps shared by different size bins.
def union_length(intervals):
    pieces = []
    for left, right in sorted(intervals):
        if pieces and left <= pieces[-1][1]:
            pieces[-1] = (pieces[-1][0], max(right,pieces[-1][1]))
        else:
            pieces.append((left, right))
    return sum((right-left for left,right in pieces), Fraction(0))

candidates = [(Fraction(-1,4),Fraction(1,4)),
              (Fraction(1,4),Fraction(1,4)),
              (Fraction(1,4),Fraction(1,8))]
bounds = []
for center, radius in candidates:
    allowance = (1-radius)/2
    expanded = allowance+radius
    bounds.append((center-expanded,center+expanded))
    for price in (center-allowance,center,center+allowance):
        assert price-radius >= center-expanded and price+radius <= center+expanded
length = union_length(bounds)
total = sum((y-x for x,y in bounds), Fraction(0))
assert length==Fraction(7,4) and total==Fraction(29,8)
partial = sum((Fraction(1,2*(j+1)**2) for j in range(256)), Fraction(0))
assert partial < 1
print('three enlarged intervals, union',length,'separate sum',total)
