"""Independent marked-point cube volumes for the R759 quadratic scale charge."""

from collections import Counter
from fractions import Fraction as Q
from math import isqrt, prod

from flint import arb, ctx, fmpq, __version__ as flint_version


ctx.prec = 256
LOG2 = arb(2).log()
ERROR = arb(2)**-200


def ball(x):
    q = Q(x)
    return arb(fmpq(q.numerator,q.denominator))


def scaled_product(n,gammas,h,R_star,last):
    """Sum the full finite set of bins, with exact cutoff decisions."""
    counts = sorted(Counter(gammas).items())
    cutoff = {g: ((g.denominator-g.numerator)**n,g.denominator**n) for g,_ in counts}
    offsets = {g: Q(1,2)*(1+g) for g,_ in counts}
    assert last >= 0 and all((lhs<<last)>=rhs for lhs,rhs in cutoff.values())
    total = arb(0)
    active_bins = 0
    for j in range(last+1):
        exponent = LOG2*j/n
        dilation = exponent.exp()
        half_side = ball(h)*ball(R_star)*(-exponent).exp()
        keep_formula = arb(1)
        keep_geometry = arb(1)
        anything_active = False
        for g,count in counts:
            lhs,rhs = cutoff[g]
            active = (lhs<<j)<rhs
            p = (1-ball(1-g)*dilation)/2 if active else arb(0)
            if active:
                assert p>0
                anything_active = True
            keep_formula *= (1-p)**count

            z = ball(offsets[g])
            lo = (z-half_side).max(arb(-1))
            hi = (z+half_side).min(arb(1))
            keep_geometry *= ((hi-lo).max(arb(0))/(2*half_side))**count
        eta = 1-keep_formula
        assert (1-keep_geometry).overlaps(eta)
        assert abs(keep_geometry-keep_formula)<ERROR
        if j%n==0:
            r = Q(1,2**(1+j//n))
            exact = 1-prod(
                (max(Q(0),min(1,offsets[g]+r)-max(-1,offsets[g]-r))/(2*r))**m
                for g,m in counts
            )
            assert eta.overlaps(ball(exact))
        total += eta
        active_bins += anything_active
    return total,active_bins


def report_case(n,name,levels,budget,valid=True):
    gammas = tuple(g for g,m in levels for _ in range(m))
    assert len(gammas)<=n
    gammas += (Q(0),)*(n-len(gammas))
    h = 1+Q(1,32*n)
    R_star = 1/(2*h)  # s_t=1.  The largest reference half-side is h R_star=1/2.
    z = [Q(1,2)*(1+g) for g in gammas]
    assert all(0<value<1 for value in z)
    assert gammas == tuple((value+h*R_star-1)/(h*R_star) for value in z)
    guard = max(z)+h*R_star
    old_excess = sum(max(Q(0),value+h*R_star-1) for value in z)
    quadratic_score = n*sum(g*g for g in gammas)
    first_moment = sum(gammas)
    assert first_moment**2<=quadratic_score and old_excess==first_moment/2
    assert max(z)>Q(1,n) and ball(max(z))>arb(n+2).log()/(64*n)
    assert (guard<=1)==(quadratic_score==0)
    if valid:
        assert 1<=budget<=Q(n,4) and quadratic_score<=budget and max(gammas)<=Q(1,2)
    missed,bins = scaled_product(n,gammas,h,R_star,n if valid else 3*n)
    quadratic = ball(first_moment)/2+ball(quadratic_score)/(2*LOG2)

    # One flat charge freezes the top-bin union bound in every active bin.
    # The coarser flat charge also replaces all positive axes by gamma_max.
    flat = bins*min(Q(1),first_moment/2)
    top = bins*min(Q(1),max(gammas)*sum(g>0 for g in gammas)/2)
    if quadratic_score==0:
        assert missed==0 and quadratic==0 and flat==0
    elif valid:
        geometric_sum_bound = ball(first_moment)/2 + n/(2*LOG2)*sum(
            m*(-ball(1-g).log()-ball(g)) for g,m in levels
        )
        assert missed<geometric_sum_bound<quadratic
        assert quadratic<ball(budget)
        if name=="mixed_equal_budget":
            assert quadratic_score==budget and flat>budget and top>=flat
    else:
        assert missed>quadratic  # Tests why a uniform cap on gamma is needed.
    shown_levels = ",".join(f"{m}x{g}" for g,m in levels) or "zero"
    print(f"n={n} {name} levels={shown_levels} score={quadratic_score} budget={budget}")
    print(f"  R*/s_t={R_star} half_price_distance={max(z)/2} "
          f"guard_LHS={guard} old_linear_excess={old_excess}")
    print(f"  active_bins={bins} missed={missed.str(14)} quadratic={quadratic.str(14)} "
          f"flat_top_vector={flat} flat_max_axis={top}")


def examples(n):
    L = isqrt(n)
    assert L*L==n
    # Choose rational amplitudes with identical quadratic score L.
    sparse_count = 1 if isqrt(L)**2==L else 2
    sparse_denominator = isqrt(sparse_count*L)
    assert sparse_denominator**2==sparse_count*L
    dense_count = n if isqrt(n*L)**2==n*L else n//2
    dense_denominator = isqrt(dense_count*L)
    assert dense_denominator**2==dense_count*L
    report_case(n,"no_excess",(),1)
    report_case(n,"sparse_large",((Q(1,sparse_denominator),sparse_count),),L)
    report_case(n,"many_small",((Q(1,dense_denominator),dense_count),),L)
    report_case(n,"mixed_equal_budget",
                ((Q(1,2*sparse_denominator),sparse_count),(Q(1,2*L),3*L)),L)


def main():
    print(f"python-flint {flint_version}; Arb {ctx.prec} bits; independent volume error < 2^-200")
    print("Conditional Lebesgue volume of reference boxes at a fixed price pair.")
    for n in (16,64,256):
        examples(n)
    report_case(64,"outside_gamma_scope",((Q(7,8),1),),"out_of_scope",valid=False)


if __name__=="__main__":
    main()

