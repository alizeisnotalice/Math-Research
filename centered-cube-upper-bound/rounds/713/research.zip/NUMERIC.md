# 第713轮证书与复现

HISTORY.tex 给出完整历史及任意固定 B 的渐近证明。hall.py 在同一历史上以真实 V_T、完整 D 计算原高损失质量、η_H=1/4 时的归一化超额、完整菜单的空间缺额和逐来源费用。近角点和全部正体积 owner 都在逐点几何下界内。初测 b=16,24,32，压力测试 b=48,64,80，扩大复核 b=96,112,128；维度 n=2^b，空间容量固定取 n^1024。早期部分末层、触发以及后续接收更新都计入 D。每种极端面来源的总质量和可能遗漏量逐组核验。最小测试维度中，(1−Δ/V_T) 的十进对数至多为 −211743.04，原高损失在每个接收点的权重至少为 0.49997282；联合分配的缺额为零。

实际运行命令为
```sh
PYTHONPATH=/Volumes/data/CodexTemp/cache/uv/archive-v0/C-cIC_VTqeqO2X1K /Users/zzh/.venvs/main/bin/python -B /Volumes/data/CodexTemp/centered-cube-r713-20261118/hall.py
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r713-20261118/cutcheck.py
```
数值证书用本机 Arb 的 256/384 位交叉区间及唯一取整验证。MacBook 通过 SSH 用 Decimal 110 位复算；舍弃项、实际机器、命令与结果见 hall.json。两机均退出码0。cutcheck.py 另用种子713生成192个整数网络，对每个网络穷举所有行割并用 SciPy 整数最大流比对。4、7、10 行各64例，正缺额数分别为51、64、64，最大缺额为20、49、65。三档共用同一份来源标签容量。网络比对只检验组合公式，数学证明在 REPORT.tex。
