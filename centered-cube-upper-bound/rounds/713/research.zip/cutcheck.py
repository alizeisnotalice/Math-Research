"""Cross-bin shared-source mincut versus integral maxflow; finite algebra check."""
from itertools import chain
from random import Random
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import maximum_flow

def one_case(rng, count):
    volumes=[rng.randint(1,12) for j in range(count)]
    colors=[rng.randrange(3) for j in volumes]
    spaces=[rng.randint(0,5) for _ in range(9)]
    sources=[rng.randint(0,9) for _ in range(4)]
    spatial=[{3*k+v for v in range(3) if rng.random()<.42} for k in colors]
    donors=[{v for v in range(4) if rng.random()<.36} for _ in volumes]
    capacities=spaces+sources
    adjacency=[s|{len(spaces)+i for i in d} for s,d in zip(spatial,donors)]
    sink=1+count+len(capacities)
    graph=[[0]*(sink+1) for _ in range(sink+1)]
    for j,edges in enumerate(adjacency):
        graph[0][j+1]=volumes[j]
        for v in edges: graph[j+1][count+1+v]=1+sum(volumes)
    for i,c in enumerate(capacities): graph[count+1+i][sink]=c
    mf=maximum_flow(csr_matrix(graph),0,sink).flow_value
    deficit=0
    for mask in range(1<<count):
        chosen=[j for j in range(count) if mask>>j&1]
        dest=set(chain.from_iterable(adjacency[j] for j in chosen))
        deficit=max(deficit,sum(volumes[j] for j in chosen)-sum(capacities[v] for v in dest))
    assert sum(volumes)-mf==deficit
    return int(deficit>0),int(deficit)
rng=Random(713)
for rows in (4,7,10):
    values=[one_case(rng,rows) for _ in range(64)]
    print(rows,len(values),sum(v[0] for v in values),max(v[1] for v in values))
