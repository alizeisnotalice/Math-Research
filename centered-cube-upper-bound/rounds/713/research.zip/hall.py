"""R713 full-menu Hall obstruction and direct one-origin source payment.

Standalone compressed finite-history certificate. Only hall.json is written.
Local rigorous arithmetic: Arb256/384. Optional remote Decimal110 through stdin.
"""
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys
from flint import arb,ctx


def st(x):return x.str(38)


def floor_unique(x):
    value=x.floor().unique_fmpz();assert value is not None
    return int(value)


def calculate(b,bits):
    ctx.prec=bits;A=arb
    n=1<<b;a=32*n;clock=1<<(b//2);Bhall=1024
    l2=A(2).log();L=b*l2;t=A(clock)/l2;h=1+A(1)/a
    beta=(-n*A(a).log()).exp();g=(-A(2)/a).log1p()
    W=-(n*g).expm1();J=floor_unique((clock-beta)/W)
    e=clock-beta-J*W
    assert e>0 and e<W
    logR=l2-(J+1)*g;R=logR.exp();logP=n*g-W/t
    early=(n*logR).exp()*((-(-W/t).expm1())*(-(J*logP).expm1())/(-logP.expm1())+(J*logP).exp()*(-(-e/t).expm1()))
    trigger=(n*l2-(clock-beta)/t).exp()*(-(-beta/t).expm1())
    receive_clock=(-2*n*l2).exp() # (a/4)^n*a^-n=4^-n exactly
    receiving=A('0.5')*(-(-receive_clock/t).expm1())
    Dnorm=early+trigger+receiving
    logVT=-n*l2;logD=n*l2+Dnorm.log();logratio=logD-logVT
    missing=(beta+receive_clock)/t
    fullmass=-(-J*W/t).expm1()
    edge_minimum=fullmass*(-W/t).exp()/(a*W)
    assert edge_minimum>missing
    box_radius=R*(A(4)/n+A(1)/a)
    log_defect=Bhall*L+n*(4*box_radius).log()
    assert log_defect<0
    delta_ratio_lower=1-log_defect.exp()
    assert delta_ratio_lower>A('.999')
    # Every true receiver point has n/2 coordinates >=1/4 and n/2<=-1/4.
    # Count donor digits giving normalized exterior depth>0.05 in those axes.
    q0=3*b//16+1
    favorable=max(0,floor_unique(A(a)/2*(A('.25')/R-A('.05'))-1))
    p=A(favorable)/a;count=n//2
    mass=(count*(-p).log1p()).exp();tail=mass
    for j in range(1,q0):
        mass*=A(count+1-j)/j*p/(1-p);tail+=mass
    failure=2*tail/W
    bad_full=fullmass*(W/t).exp()*failure
    high_lower=fullmass-bad_full-missing
    assert high_lower>A('.49') and high_lower<A('.5')
    assert 2*q0*l2>A('.375')*L
    assert A('.05')>A(6)/n
    assert R<2*h*n/L
    assert R>2 and R*(J*g).exp()>2
    assert (R*((J+1)*g).exp()-2).contains(0)
    assert A('.25')>3/a # receiving owners do not meet trigger tiny core
    # Original origin pool contains all initial donors and has total theta=1/2.
    # Each initial source has d_i>=(2*2)^n, giving per-source factor 8^-n.
    log_source_payment=-3*n*l2
    log_actual_direct_ratio=-l2-logratio
    assert log_actual_direct_ratio<=log_source_payment
    norm_upper=(-logratio-A(4*clock).log())/A(10).log()
    norm_lower=((high_lower-A('.25')).log()-A(clock).log()-logratio)/A(10).log()
    return {'range':{16:'preliminary',24:'preliminary',32:'preliminary',48:'stress',64:'stress',80:'stress',96:'expanded',112:'expanded',128:'expanded'}[b],
            'b':b,'n':f'2^{b}','a':str(a),'clock':str(clock),'J':str(J),'R':st(R),
            'receiver_count':f'({a}/4)^{n}','VT_exact':f'2^(-{n})','VT':st(logVT.exp()),'D':st(logD.exp()),
            'edge_type_actual_weight_lower':st(edge_minimum),'later_omitted_early_weight_upper':st(missing),
            'all_qualified_pools_retain_all_2n_edge_types':True,
            'full_menu_Wj_box_radius_upper':st(box_radius),
            'Hall_capacity_B':Bhall,'log10_Hall_relative_defect_upper':st(log_defect/A(10).log()),
            'Delta_nB_over_VT_lower':st(delta_ratio_lower),'Delta_nB_over_VT_upper':'1',
            'high_conflict_q0':q0,'favorable_digit_count':str(favorable),'mean_opposite_sign_count':st(count*p),
            'log_failure_conditional_upper':st(failure.log()),
            'original_high_weight_lower_every_point_every_qualified_pool':st(high_lower),
            'original_high_weight_upper_for_origin':'1/2',
            'log_D_over_VT':st(logratio),'log10_VT_over_4sqrt_n_D':st(norm_upper),
            'log10_original_positive_excess_over_sqrt_n_D_lower':st(norm_lower),
            'direct_origin_integral_upper_exact':f'2^(-{n+1})',
            'log10_per_source_payment_coefficient_8_minus_n':st(log_source_payment/A(10).log()),
            'log10_actual_origin_mass_over_D':st(log_actual_direct_ratio/A(10).log()),
            'center_bag_size':1,'same_selected_origin_all_receivers':True,'precision_bits':bits,
            '_values':(log_defect,high_lower,logratio,norm_upper,edge_minimum),
            '_remote_values':[float(log_defect),float(high_lower),float(logratio),float(norm_upper)]}


REMOTE=r'''
from decimal import Decimal as D,localcontext
import json,socket,sys
with localcontext() as c:
 c.prec=110
 rows=[]
 for b in [16,24,32,48,64,80,96,112,128]:
  n=1<<b;a=32*n;clock=1<<(b//2);l2=D(2).ln();L=D(b)*l2;t=D(clock)/l2
  g=(1-D(2)/a).ln();W=1-(D(n)*g).exp();J=int(D(clock)/W);e=D(clock)-J*W
  logR=l2-D(J+1)*g;R=logR.exp();box=R*(D(4)/n+D(1)/a)
  logdef=D(1024)*L+D(n)*(4*box).ln()
  nf=max(0,int(D(a)/2*(D('.25')/R-D('.05'))-1));p=D(nf)/a;B=n//2;q0=3*b//16+1
  # Log lower-tail sum avoids Decimal exponent overflow in enormous dimensions.
  relative=D(1);summed=D(1)
  for j in range(1,q0):
   relative*=D(B+1-j)/j*p/(1-p);summed+=relative
  logfail=D(2).ln()-W.ln()+D(B)*(1-p).ln()+summed.ln()
  assert logfail<-1000
  full=1-(-D(J)*W/t).exp();high=full # conditional failure and late clock are negligible
  logP=D(n)*g-W/t
  assert D(J)*logP<-100
  # b16 has a still representable finite geometric tail; keep it explicitly.
  PJ=(D(J)*logP).exp() if D(J)*logP>-1000 else D(0)
  aggregate=(1-(-W/t).exp())*(1-PJ)/(1-logP.exp())+PJ*(1-(-e/t).exp())
  logearly=D(n)*logR+aggregate.ln()
  logratio=logearly+2*D(n)*l2
  norm=(-logratio-D(4*clock).ln())/D(10).ln()
  rows.append({'b':b,'J':str(J),'favorable_digit_count':str(nf),'values':[str(logdef),str(high),str(logratio),str(norm)]})
 print(json.dumps({'host':socket.gethostname(),'python':sys.version,'backend':'Decimal110 approximate; beta0,4^-n and negligible binomial failure omitted','rows':rows}))
'''


def main():
    rows=[]
    for b in [16,24,32,48,64,80,96,112,128]:
        lower=calculate(b,256);higher=calculate(b,384)
        assert lower['J']==higher['J'] and lower['favorable_digit_count']==higher['favorable_digit_count']
        for x,y in zip(lower['_values'],higher['_values']):assert x.overlaps(y)
        del higher['_values'];rows.append(higher)
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B -']
    run=subprocess.run(command,input=REMOTE,text=True,capture_output=True,timeout=30)
    remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
    if run.returncode==0:
        remote['result']=json.loads(run.stdout)
        for local,other in zip(rows,remote['result']['rows']):
            assert local['b']==other['b'] and local['J']==other['J'] and local['favorable_digit_count']==other['favorable_digit_count']
            for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        remote['crosscheck_passed']=True
    else:remote['stdout']=run.stdout
    for row in rows:del row['_remote_values']
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'remote':remote,
            'real_history':['Unfolded boundary-word grid: a=32n,rho=1-2/a,W=1-rho^n. Each full shell has raw owner clock W. No passive sign restriction.',
                            'N=sqrt(n)*a^n is an integer. Early count is N-1; J=floor((sqrt(n)-a^-n)/W), final raw clock e. Radii R*rho^l with R=2*rho^(-(J+1)) have inner cavity radius2.',
                            'Trigger is Q(0,2) with full tiny core. Receivers have radius1 and full tiny cores tiling [1/4,3/4]^(n/2) times[-3/4,-1/4]^(n/2), using midpoint spacing2/a. Thus Nr=(a/4)^n and VT=2^-n exactly.',
                            'Every parent contains a common positive origin cell. Early radii>2, trigger2, receiver1 imply actual greedy history. Trigger is Nth and first hits1/2; all receivers and only receivers are bad.',
                            'All tiny cores are disjoint: early shells outside radius2, trigger at0 with radius2/a, receiving coordinates have absolute value>=1/4. Subsequent receiver capacities share the common origin maximum.',
                            'All D terms are included: full and partial early layers, trigger, and the full receiver clock4^-n.'],
            'all_menu_Hall_argument':['In every full shell, fixing one coordinate to digit0 or digit a-1 has uniform conditional fraction1/(aW). Actual theta weighting retains at least exp(-W/t) times this fraction.',
                                      'Each edge-type actual weight is at least full_mass*exp(-W/t)/(aW). It exceeds (beta0+4^-n)/t, an upper bound for all trigger-plus-later weights.',
                                      'Any qualified pool has weight>=1/2 but total early weight<1/2. It can omit no more early weight than trigger-plus-later total. Therefore every qualified pool retains a donor of each of the2n extreme coordinate edge types.',
                                      'The opposite extreme parents after dilation1+4/n force every coordinate of every entire near intersection into[-R(4/n+1/a),R(4/n+1/a)]. Every such early source is in the original near window.',
                                      'Taking union over the FULL eligible witness menu changes nothing: each W_j is in this same box. All receivers have the same volume bin.',
                                      'The all-row Hall cut gives Delta_n^1024/VT>=1-n^1024*(4R(4/n+1/a))^n. Its logarithmic defect and lower bound are certified above; Delta/VT<=1 trivially.'],
            'high_and_direct_payment':['For every actual receiver point there are n/2 positive and n/2 negative coordinates with magnitude>=1/4. Favorable extreme digits force exterior distance>0.05*s_i; at least q0 on each side implies original strict high loss.',
                                       'Two binomial lower tails and division by W bound failure under full boundary conditioning. Actual within-layer weight variation costs exp(W/t). Removing all possible late-source missing mass gives the every-qualified-pool high lower.',
                                       'Choose the genuine origin first-hit witness for every receiver. Its common original pool is precisely all early donors plus trigger, and has total coefficient1/2. The source-localized center bag is the same singleton{0} for all rows.',
                                       'For each initial source, its receiver charge is theta_i*VT (or a smaller high-mask charge). Its s_i>=2 gives d_i>=4^n, hence theta_i*VT<=8^-n*d_i*theta_i.',
                                       'Summing sources once gives R_high<=VT/2<=8^-n D. This directly pays the actual clustered receiving volume even though the FULL-menu Hall deficiency approaches VT.'],
            'scope':['All local calculations are Arb256/384 interval bounds with crosschecked unique floors. Full tiny owners and all-menu arguments are analytic, not sampled.',
                     'The Hall box is an upper bound for the full menu union, not a restriction to one witness or a sub-menu.',
                     'The direct payment uses the same actual origin selection for every row and the complete source budget exactly once.',
                     'This finite obstruction does not refute a general source-budget inequality; the normalized receiver charge is extremely small.',
                     'MacBook Decimal110 is an approximate independent check, and creates no remote files. Only this script and hall.json are written locally.']}
    output=Path(__file__).with_name('hall.json');output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'remote_exit':run.returncode,'remote_crosscheck':remote.get('crosscheck_passed',False),
                      'rows':[{k:r[k] for k in ['b','log10_Hall_relative_defect_upper','original_high_weight_lower_every_point_every_qualified_pool','log10_VT_over_4sqrt_n_D']} for r in rows]},indent=2))


if __name__=='__main__':main()
