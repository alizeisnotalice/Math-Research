#!/usr/bin/env python3
"""Round 48. Exact rational root enclosures and exposed-face derivative guards.
Finite-difference checks concern listed finite inputs only. No exponent fitting,
global weight optimization claim, external packages, or randomized sampling.
"""
from fractions import Fraction as F
from itertools import combinations, product
from functools import lru_cache
from pathlib import Path
import json
from math import isqrt

class I:
    def __init__(self, lo, hi=None):
        self.lo=F(lo); self.hi=F(lo if hi is None else hi); assert self.lo<=self.hi
    def __add__(self,o):
        if not isinstance(o,I): o=I(o)
        return I(self.lo+o.lo,self.hi+o.hi)
    __radd__=__add__
    def __neg__(self): return I(-self.hi,-self.lo)
    def __sub__(self,o): return self+-o if isinstance(o,I) else self+I(-o)
    def __mul__(self,o):
        if not isinstance(o,I): o=I(o)
        vals=[x*y for x in (self.lo,self.hi) for y in (o.lo,o.hi)]
        return I(min(vals),max(vals))
    __rmul__=__mul__
    def __truediv__(self,q):
        q=F(q); assert q!=0
        return self*I(1/q)
    def data(self): return [str(self.lo),str(self.hi)]
    def contains_zero(self): return self.lo<=0<=self.hi

@lru_cache(None)
def root(q,n,bits):
    q=F(q); assert q>0
    if n==1: return I(q)
    h=F(1)
    while h**n<q: h*=2
    if h**n==q: return I(h)
    l=F(0) if h==1 else h/2
    for _ in range(bits):
        mid=(l+h)/2
        if mid**n==q:return I(mid)
        if mid**n<q:l=mid
        else:h=mid
    assert l**n<=q<=h**n
    return I(l,h)

def family(points,weights):
    n=len(points[0]); out=[]
    for mask in range(1,1<<len(points)):
        ids=[j for j in range(len(points)) if mask>>j&1]
        m=sum((weights[j] for j in ids),F(0))
        lo=tuple(min(points[j][i] for j in ids) for i in range(n))
        hi=tuple(max(points[j][i] for j in ids) for i in range(n))
        out.append((mask,m,lo,hi))
    return out

class Geometry:
    def __init__(self,points,weights,lam,bits):
        self.n=len(points[0]); self.N=len(points);self.lam=lam
        self.items={}; self.vals=[{} for _ in range(self.n)]
        boxes=[]; self.birth_ties=[]
        for mask,m,lo,hi in family(points,weights):
            gap=m-lam*max(h-l for l,h in zip(lo,hi))**self.n
            if gap==0:self.birth_ties.append(mask)
            if gap<=0:continue
            rr=root(m/lam,self.n,bits); self.items[mask]=(m,rr)
            for i in range(self.n):
                self.vals[i][(mask,-1)]=I(hi[i])-rr/2
                self.vals[i][(mask,1)]=I(lo[i])+rr/2
            boxes.append(tuple(((mask,-1),(mask,1)) for _ in range(self.n)))
        self.ranks=[];self.order=[]
        for axis in range(self.n):
            vv=self.vals[axis]; order=sorted(vv,key=lambda k:vv[k].lo+vv[k].hi)
            # Certify parallel endpoints of nonempty boxes; births are guarded separately.
            for a,b in zip(order,order[1:]):
                assert vv[a].hi<vv[b].lo, ('not certified generic',axis,a,b)
            self.order.append(tuple(order)); self.ranks.append({k:j for j,k in enumerate(order)})
        self.boxes=tuple(boxes)
        self.signature=(tuple(sorted(self.items)),tuple(self.order))
        self._cache={}
    def volume(self, boxes, axes):
        boxes=tuple(sorted(set(boxes))); key=(boxes,axes)
        if key in self._cache:return self._cache[key]
        if not boxes:return I(0)
        if not axes:return I(1)
        a=axes[0];rank=self.ranks[a]; cuts=sorted({p for b in boxes for p in b[0]},key=rank.get)
        total=I(0)
        for l,h in zip(cuts,cuts[1:]):
            active=tuple(b[1:] for b in boxes if rank[b[0][0]]<=rank[l] and rank[h]<=rank[b[0][1]])
            if active: total+=(self.vals[a][h]-self.vals[a][l])*self.volume(active,axes[1:])
        self._cache[key]=total
        return total
    def cost(self):return self.volume(self.boxes,tuple(range(self.n)))*self.lam
    def derivatives(self):
        assert not self.birth_ties, ('birth equality: use one-sided directional formula',self.birth_ties)
        V=self.volume(self.boxes,tuple(range(self.n)))
        omega=I(0); ga=[I(0) for _ in range(self.N)]; faces=[]
        for b in self.boxes:
            mask=b[0][0][0]; m,rr=self.items[mask]
            for axis in range(self.n):
                axes=tuple(i for i in range(self.n) if i!=axis)
                rect=tuple(b[i] for i in axes)
                for side in (0,1):
                    plane=b[axis][side]; rank=self.ranks[axis]; blockers=[]
                    for other in self.boxes:
                        if not rank[other[axis][0]]<rank[plane]<rank[other[axis][1]]:continue
                        clipped=[]; good=True
                        for i in axes:
                            r=self.ranks[i]
                            l=max((b[i][0],other[i][0]),key=r.get)
                            h=min((b[i][1],other[i][1]),key=r.get)
                            if r[l]>=r[h]:good=False;break
                            clipped.append((l,h))
                        if good:blockers.append(tuple(clipped))
                    full=self.volume((rect,),axes); covered=self.volume(tuple(blockers),axes)
                    diff=full-covered;assert diff.hi>=0
                    area=I(max(F(0),diff.lo),max(F(0),diff.hi))
                    w=area*rr*(self.lam/F(2*self.n));omega+=w
                    for j in range(self.N):
                        if mask>>j&1:ga[j]+=w/m
                    faces.append((mask,axis,side,area,w))
        gl=V-omega/self.lam
        return ga,gl,omega,faces

def one_dim(points,weights,lam,with_faces=False):
    # Scaled intervals lambda*B_S have linear endpoints in (weights,lambda).
    intervals=[];N=len(points)
    for mask,m,lo,hi in family(tuple((x,) for x in points),weights):
        l=lam*hi[0]-m/2; h=lam*lo[0]+m/2
        if l<h: intervals.append((l,h,mask))
    intervals.sort(); unions=[]
    for l,h,mask in intervals:
        if not unions or l>unions[-1][1]:unions.append([l,h,mask,mask])
        elif h>unions[-1][1]:unions[-1][1]=h;unions[-1][3]=mask
    cost=sum((h-l for l,h,_,_ in unions),F(0))
    if not with_faces:return cost
    grad=[F(0)]*(N+1);faces=[]
    for l,h,lmask,hmask in unions:
        for mask,side in ((lmask,-1),(hmask,1)):
            ids=[j for j in range(N) if mask>>j&1]
            for j in ids:grad[j]+=F(1,2)
            grad[-1]+=min(points[j] for j in ids) if side==1 else -max(points[j] for j in ids)
            faces.append((mask,side))
    return cost,tuple(grad),faces

def exact_direction(points,weights,lam,va,vl):
    n=len(points[0]); boxes=[]
    for mask,m,lo,hi in family(points,weights):
        q=m/lam
        if n==1:rr=q
        else:
            assert n==2
            num=isqrt(q.numerator);den=isqrt(q.denominator)
            assert num*num==q.numerator and den*den==q.denominator
            rr=F(num,den)
        dm=sum((va[j] for j in range(len(weights)) if mask>>j&1),F(0))
        dr=rr/F(n)*(dm/m-vl/lam)
        boxes.append(tuple((hi[i]-rr/2,lo[i]+rr/2,-dr/2,dr/2) for i in range(n)))
    volume=F(0);dv=F(0)
    for size in range(1,len(boxes)+1):
        for group in combinations(boxes,size):
            widths=[];derivs=[]
            for i in range(n):
                upper=min(b[i][1] for b in group);lower=max(b[i][0] for b in group)
                du=min(b[i][3] for b in group if b[i][1]==upper)
                dl=max(b[i][2] for b in group if b[i][0]==lower)
                w=upper-lower;dw=du-dl
                widths.append(max(F(0),w));derivs.append(dw if w>0 else max(F(0),dw) if w==0 else F(0))
            v=F(1)
            for w in widths:v*=w
            dd=F(0)
            for i in range(n):
                term=derivs[i]
                for k in range(n):
                    if k!=i:term*=widths[k]
                dd+=term
            sign=1 if size%2 else -1
            volume+=sign*v;dv+=sign*dd
    return lam*volume,vl*volume+lam*dv


def directional_guards(records):
    for du,dv in product((-1,0,1),repeat=2):
        if du==dv==0:continue
        va=(F(du),F(-du));vl=F(dv)
        value,derivative=exact_direction(((F(0),),(F(1),)),(F(1,2),F(1,2)),F(3,4),va,vl)
        assert value==F(5,4) and derivative==-max(abs(vl),abs(va[0])/2)
        for h in (F(1,10000),F(1,1000000)):
            got=(one_dim((F(0),F(1)),(F(1,2)+h*va[0],F(1,2)+h*va[1]),F(3,4)+h*vl)-value)/h
            assert got==derivative
            records.append(dict(stage='tied_direction',n=1,direction=list(map(str,va+(vl,))),h=str(h),derivative=str(derivative),difference=str(got)))
    directions=[(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1),(1,-1,0),(-1,1,0)]
    for diagonal in (False,True):
        pts=((F(0),F(0)),(F(1),F(int(diagonal))));ws=(F(9,25),F(16,25));lam=F(1)
        for d in directions:
            va=tuple(map(F,d[:2]));vl=F(d[2]);value,derivative=exact_direction(pts,ws,lam,va,vl)
            assert value==1
            for h in (F(1,10000),F(1,1000000)):
                g=Geometry(pts,tuple(ws[j]+h*va[j] for j in range(2)),lam+h*vl,64)
                fd=(g.cost()-I(value))/h;error=fd-I(derivative)
                assert max(abs(error.lo),abs(error.hi))<F(1,1000)
                records.append(dict(stage='tied_direction',n=2,diagonal=diagonal,direction=list(map(str,d)),h=str(h),
                                    derivative=str(derivative),difference=fd.data(),error=error.data()))


def one_dim_full_profile(points,weights):
    endpoints=[]
    for _,m,lo,hi in family(tuple((x,) for x in points),weights):
        endpoints.extend(((hi[0],-m/2),(lo[0],m/2)))
    cuts=set()
    for (a,b),(c,d) in combinations(endpoints,2):
        if a!=c:
            lam=(d-b)/(a-c)
            if lam>0:cuts.add(lam)
    costs=[(one_dim(points,weights,lam),lam) for lam in cuts]
    value,where=max(costs+[(F(1),F(1))])
    return value,where,len(cuts)


def main():
    records=[]
    for n in (1,2,3,4):
        for N in (2,3,4):
            weights=tuple(F(2**j,2**N-1) for j in range(N))
            for kind in ('axis','correlated','bent'):
                raw=tuple(tuple(F(j*(i+1)) if kind=='correlated' else
                    (F(j) if i==0 else F(0)) if kind=='axis' else
                    F(j*(i+1)+(j>=2)*(j-1)*(i+1)**2*(-1)**i) for i in range(n)) for j in range(N))
                D=max(max(p[i] for p in raw)-min(p[i] for p in raw) for i in range(n))
                points=tuple(tuple(z*F(2,3)/D for z in p) for p in raw)
                for lam in (F(5,7),F(17,13),F(31,11)):
                    last=None
                    for bits in (48,64):
                        g=Geometry(points,weights,lam,bits);cost=g.cost();ga,gl,omega,faces=g.derivatives()
                        assert all(x.lo>=0 for x in ga)
                        euler=sum((ga[j]*weights[j] for j in range(N)),I(0))+gl*lam-cost
                        assert euler.contains_zero()
                        if last:assert last[0]<=cost.lo<=cost.hi<=last[1]
                        last=(cost.lo,cost.hi)
                        records.append(dict(stage='exposed_face',n=n,N=N,kind=kind,lam=str(lam),bits=bits,
                          cost=cost.data(),source_gradient=[x.data() for x in ga],threshold_gradient=gl.data(),
                          flux=omega.data(),face_candidates=len(faces),euler_residual=euler.data()))
                    # Two actual finite-difference resolutions; no derivative-limit claim from these checks.
                    for h in (F(1,10000),F(1,1000000)):
                        for j in range(N+1):
                            wp=list(weights);wm=list(weights);lp=lm=lam
                            if j<N:wp[j]+=h;wm[j]-=h
                            else:lp+=h;lm-=h
                            gp=Geometry(points,tuple(wp),lp,64);gm=Geometry(points,tuple(wm),lm,64)
                            assert gp.signature==g.signature==gm.signature
                            fd=(gp.cost()-gm.cost())/(2*h);target=(ga+[gl])[j]
                            err=fd-target
                            assert max(abs(err.lo),abs(err.hi))<F(1,1000)
                            records.append(dict(stage='finite_difference',n=n,N=N,kind=kind,lam=str(lam),coordinate=j,h=str(h),
                                difference=fd.data(),analytic_gradient=target.data(),error=err.data()))
    # Exact joint kink, with analytic optimum known independently for two atoms.
    points=(F(0),F(1));base=(F(1,2),F(1,2));lam=F(3,4);K=F(5,4)
    for scale in (F(1,64),F(1,256),F(1,1024)):
        for du,dv in product(range(-3,4),repeat=2):
            u=du*scale;v=dv*scale
            got=one_dim(points,(base[0]+u,base[1]-u),lam+v)
            expected=K-max(abs(v),abs(u)/2)
            assert got==expected
            records.append(dict(stage='joint_kink',u=str(u),v=str(v),cost=str(got)))
    samples=[(F(0),F(-1,128)),(F(0),F(1,128)),(F(-1,128),F(0)),(F(1,128),F(0))]
    expected=[(F(1,2),F(1,2),F(1)),(F(2),F(2),F(-1)),(F(3,2),F(1),F(0)),(F(1),F(3,2),F(0))]
    branches=[]
    for (u,v),wanted in zip(samples,expected):
        _,grad,faces=one_dim(points,(base[0]+u,base[1]-u),lam+v,True)
        assert grad==wanted
        assert grad!=(K,K,F(0))
        flux=[]
        for mask,side in faces:
            mass=sum(base[j] for j in range(2) if mask>>j&1)
            # Limiting H^0 exposed-face area = 1, R_S = mass/base_lambda.
            flux.append((mask,mass/2))
        assert sum(w for _,w in flux)==K-lam*grad[-1]
        branches.append((grad,flux))
        records.append(dict(stage='incident_branch',u=str(u),v=str(v),gradient=list(map(str,grad)),
                            limiting_faces=[dict(mask=mask,weight=str(w)) for mask,w in flux]))
    alpha=(F(1,2),F(1,2),F(0),F(0))
    mixture=tuple(sum(alpha[r]*branches[r][0][j] for r in range(4)) for j in range(3))
    assert mixture==(K,K,F(0))
    total=sum(alpha[r]*sum(w for _,w in branches[r][1]) for r in range(4)); assert total==K
    marginals=[]
    for j in range(2):
        marginal=F(0)
        for r in range(4):
            for mask,w in branches[r][1]:
                mass=sum(base[k] for k in range(2) if mask>>k&1)
                if mask>>j&1:marginal+=alpha[r]*w/K*base[j]/mass
        assert marginal==base[j];marginals.append(marginal)
    records.append(dict(stage='common_mixture',alpha=list(map(str,alpha)),gradient=list(map(str,mixture)),
                        total_flux=str(total),source_marginal=list(map(str,marginals))))
    directional_guards(records)
    pts=((F(0),F(0)),(F(1),F(0))); ws=(F(9,25),F(16,25))
    birth=Geometry(pts,ws,F(1),64)
    value,derivative=exact_direction(pts,ws,F(1),(F(1),F(0)),F(0))
    assert value==1 and derivative==F(3,2)
    assert birth.cost().lo<=value<=birth.cost().hi and birth.birth_ties==[3]
    try:birth.derivatives()
    except AssertionError as exc:
        assert 'birth equality' in str(exc)
    else:raise AssertionError('smooth derivative accepted a birth equality')
    records.append(dict(stage='birth_guard_regression',cost=str(value),directional_derivative=str(derivative),
                        birth_masks=birth.birth_ties,smooth_derivative='rejected as required'))
    for points in ((F(0),F(1),F(3)),(F(0),F(1),F(8))):
        for eps in (F(0),F(1,2),F(1,4),F(1,16),F(1,64),F(1,256)):
            weights=(eps,(1-eps)/2,(1-eps)/2)
            value,where,cuts=one_dim_full_profile(points,weights)
            assert value>=1 and one_dim(points,weights,where)==value
            if eps==0:assert value==F(5,4)
            records.append(dict(stage='weight_boundary_profile',points=list(map(str,points)),weights=list(map(str,weights)),
                                full_weak_ratio=str(value),attaining_lambda=str(where),endpoint_breaks=cuts,
                                scope='exact all-threshold optimum for this fixed weight vector, not optimization over weights'))
    # Uniform tails do not depend on a minimum positive weight. Include zero weights.
    for n in (1,2,3,4,8,16):
        for power in (2,4,8,16):
            t=F(1,2**power);D=F(3)
            lower=max(F(0),1-D*t)**n;upper=(1+D*t)**n
            assert lower<=1<=upper
            records.append(dict(stage='uniform_tail',n=n,lambda_root=str(t),diameter='3',lower=str(lower),upper=str(upper),
                                note='symbolic all-simplex enclosure; not a full global optimizer computation'))
    counts={}
    for r in records:counts[r['stage']]=counts.get(r['stage'],0)+1
    result=dict(round=48,status='PASS',cases=len(records),counts=counts,records=records,
        proof_status='finite-support optimizer and shared boundary mixture proved; dimension-uniform flux bound unproved',
        arithmetic='exact Fraction and directed rational root enclosures; finite differences are finite checks',
        random_seed=None)
    Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(dict(status='PASS',cases=len(records),counts=counts),sort_keys=True))
if __name__=='__main__':main()
