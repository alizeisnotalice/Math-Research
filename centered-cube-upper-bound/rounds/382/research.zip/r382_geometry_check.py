from fractions import Fraction as F
counts={'clock_marked_plan':0,'center_envelope':0,'two_end_identity':0,'radial_price':0}
positive=0
# Stage 1: source-exact, target-correlated plans; true full-f m/q;
# original-shape strict past, reciprocal J, physical clock atom.
# Finite quadrature, not a native dense-deep Lebesgue field.
for peak in (F(5,2),F(3),F(7,2)):
 for qu in (F(9,10),F(19,20),F(1)):
  low=(F(18,5)-peak)/3
  bg=(8*qu-peak-low)/6
  f=[low,low,peak,low]+[bg]*6+[F(1),F(1)]
  dy=[F(1,8)]*12
  c=[[int(0<=y<4) for y in range(12)],[int(2<=y<10) for y in range(12)]]
  R=[F(1,2),F(1)]
  m=[sum(f[y]*dy[y]*c[v][y] for y in range(12)) for v in range(2)]
  q=[m[v]/R[v] for v in range(2)]
  assert q==[F(9,10),qu] and all(F(3,4)<=z<=1 for z in q)
  for dv0 in (F(1,10),F(1,5),F(2,5)):
   for dv1 in (F(1,10),F(1,5),F(2,5)):
    dv=[dv0,dv1]
    plans=[]
    for v in range(2):
     U=[dy[z]*c[v][z]/R[v] for z in range(12)]
     src=[dy[y]*c[v][y]*max(f[y]-q[v],F(0))*int(f[y]>2*q[v])/m[v] for y in range(12)]
     d=sum(src)
     rbar=sum(U[z]*c[1][z] for z in range(12))
     pi=[[src[y]*U[z]*(1+F(y%3,2)*(c[1][z]-rbar)) for z in range(12)] for y in range(12)]
     assert all(sum(pi[y])==src[y] for y in range(12))
     assert all(sum(pi[y][z] for y in range(12))<=2*d*U[z] for z in range(12))
     plans.append(pi)
    for h in (F(1,10),F(1,2)):
     raw=F(0); large=F(0); win=F(0); tail=F(0); wintail=F(0)
     small_piece=F(0); large_piece=F(0); residual=F(0)
     for y in range(12):
      s=F(3+y,10)
      Ju=[sum(dv[w]*c[w][y]/m[w] for w in range(2) if R[w]<=r) for r in R]
      for u in range(2):
       zu=min(m[u]/s,s/m[u])
       iu=int(s/2<=m[u]<=2*s)
       tail+=f[y]*dy[y]*dv[u]*c[u][y]*zu/R[u]
       wintail+=f[y]*dy[y]*dv[u]*c[u][y]*iu/R[u]
       Z=sum(dv[w]*c[w][y]/m[w] for w in range(2) if m[w]<m[u]/F(3,2))
       if Z<=h:continue
       clock=sum(F(1)/Ju[k] for k,r in enumerate(R)
                 if r>=R[u] and Ju[k]>=F(1,10) and Ju[k]>0)
       for v in range(2):
        if m[v]>=m[u]/F(3,2):continue
        A=1-m[v]/m[u]
        zv=min(m[v]/s,s/m[v])
        term=dv[u]*dv[v]*A*c[u][y]*clock*sum(plans[v][y][z]*(1-c[u][z]) for z in range(12))
        raw+=term;large+=zu*term;win+=iu*term
        small_piece+=zv*term
        large_piece+=(1-zv)*zu*term
        residual+=(1-zv)*(1-zu)*term
     assert raw==small_piece+large_piece+residual
     assert 0<=large_piece<=large<=tail
     assert 0<=win<=wintail
     counts['clock_marked_plan']+=1
     counts['two_end_identity']+=1
     positive+=int(raw>0)
# Stage 2: pointwise actual mass/center envelopes, closed windows.
qm=F(3,4)
for n in range(1,6):
 for rr in (F(1,4),F(1,2),F(1),F(3,2)):
  for q in (qm,F(7,8),F(1)):
   for R in (rr,2*rr,3*rr):
    m=q*R**n
    for M in (F(1,3),F(1),F(3)):
     chi=min(m/M,M/m)
     rho_mass=qm*rr**n
     assert chi/m<=min(1/M,M/rho_mass**2)
     L=M/2;U=2*M
     lhs=F(int(L<=m<=U),1)/m
     rhs=(1/max(L,rho_mass) if rho_mass<=U else F(0))
     assert lhs<=rhs
     counts['center_envelope']+=1
# Stage 3: exact radial antiderivative constants and algebraic partitions.
for theta in (F(1,4),F(1,2),F(1),F(3,2),F(2),F(4)):
 inner=1/theta if theta<=1 else F(1)
 outer=1/theta
 ctheta=2/theta if theta<=1 else 1+1/theta
 assert inner+outer==ctheta
 counts['radial_price']+=1
for a in (F(0),F(1,4),F(1,2),F(3,4),F(1)):
 for b in (F(0),F(1,3),F(2,3),F(1)):
  assert a+(1-a)*b+(1-a)*(1-b)==1
  counts['two_end_identity']+=1
print('PASS',counts,'total',sum(counts.values()),'positive clock-plan cases',positive)
