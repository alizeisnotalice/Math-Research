# R382 independent audit — FINAL PASS

Final bounded proof, full-code, numeric-model/scope and complete-ledger review is finished. The new original-clock large-endpoint anchor/window receipt and its finite two-endpoint selection pass. No substantive issue remains. The general double-outside residual and original outer/soft/history/scale obligations remain unproved. Only this audit was modified; inherited interfaces were used as specified, not comprehensively re-audited.

Initial screens below are retained as chronology. Their pending status is superseded by the completed final review and byte bindings.

## 1. Original unpaid object and valid baseline

Fix ONE full-f matched hard field with actual receiver Lebesgue du,dv, m_u=f(Q_u)=q_u R_u^n, q_-<=q_u<=lambda, a<=R<=b<=2a, mu(du)=du/m_u, original J_y(r), H, strict global mass-past and the inclusive physical clock ell. All original outside/not-Bplus, dense/deep and high-source marks remain those of this field. The high-source law is mu_v^H(dy)=1_{f>Tq_v}(f-q_v)_+c_v(y)dy/m_v; it is not a field from which matching may be recalculated. Let tau_v be one source-exact completed plan with this first marginal and the actual allowed target capacity.

Write the same original cost C_v(y,z)=L_v(y)-K_v(y,z)>=0, with L the complete original clock integral and K its target-capture part. The exact plan cost G(tau)=integral dv integral C_v d tau_v remains unpaid except for explicitly settled positive source/pair restrictions. In particular a small overlap volume, a source-window receipt, an optimized finite anchor or a named joint kernel does not by itself pay its complementary source-marked cost.

The baseline G(tau)<=integral dv integral L_v d mu_v^H<=X_q is already proved for every source-exact plan, not only product. Its proof must keep the common source and original denominators until cancellation. At fixed(u,y,r), original small-mass v has R_v<R_u<=r because K>lambda/q_-. Source exactness bounds its inner v sum by f(y)Z_y(m_u/K-)<=f(y)J_y(r). Only on the retained nonzero gate may J cancel; then inclusive ell([R_u,b])=R_u^-n and integral f c_u=m_u give integral_E q_u du. This is an order-one receiver bound, not the desired arbitrarily small absorption. It is a single baseline upper bound, not an extra credit to add to previously paid branches.

## 2. What the symmetric common-source kernel actually means

At fixed physical r set E_r={u:R_u<=r}. For a source-only nonnegative gate a_r(y)<=1 define

    S_r^a(u,v)=integral f(y)a_r(y)c_u(y)c_v(y)/J_y(r) dy,

with zero contribution where J=0 and u,v in E_r. This kernel is symmetric and nonnegative. Its actual row identity is

    integral_(E_r) S_r^a(u,v) mu(dv)
      = integral f(y)a_r(y)c_u(y)1_{J_y(r)>0}dy <= m_u

for mu-a.e. u. The full a=1 row equals m_u for mu-a.e. active u. The possible zero-J set is null under the actual joint measure c_u(y)mu(du)f(y)dy by positive Tonelli; it is not discarded separately for each chosen receiver. A high-J gate depending only on y,r preserves symmetry and gives the corresponding killed row.

Thus P_r(u,dv)=S_r^a(u,v)mu(dv)/m_u is a row-subprobability kernel. Its detailed-balance reference is actual du, since its density relative to dv is S_r^a(u,v)/(m_u m_v). The symmetric integral bilinear form uses mu(du)mu(dv), whereas the normalized Markov kernel is reversible with respect to du. One must not call S itself a row-probability kernel relative to mu, replace du by m_u du, or obtain an unproved contraction from the wrong reference measure.

Receiver/source marks such as 1_{Z_y(m_u/K-)>h}, a private lost-row beta_v(y), 1_{f>Tq_v}, and the conditional target law of tau_v depend on endpoint roles. They do not automatically preserve this symmetry. Keeping them in the original positive integral is valid; replacing them by a symmetric source-only gate or unmarked I_uv=f(Q_u intersect Q_v) is not an exact identity without its explicit averaging/inequality.

## 3. Ordered far-pair reordering and the target-plan distinction

For the full-f common-source ordered mass-difference integral, the far orientation m_u>K m_v uniquely identifies the big endpoint. At fixed r the original domain requires both endpoints active; far mass and matching imply the smaller one is active whenever r>=R_u. Any original pair/source mask can be mirrored as a symmetric mask defined from the BIG endpoint (including its strict mass-past), provided every actual condition is retained after interchange. Then

    integral_(m_u>K m_v) (m_u-m_v) chi_y(u,v) mu(du)mu(dv)
      = (1/2) integral |m_u-m_v| chi_y^sym(u,v) mu(du)mu(dv).

The same f(y)dy, 1/J_y(r), original high/source gates if symmetric, and ell(dr) must occur on both sides. The factor 1/2 accounts for the two orientations; it is not an additional saving. Multiplying by m_u or changing from mu to du must be done explicitly using m_u mu(du)=du. Radius order follows from mass order only with K>lambda/q_-; it is not a free replacement of the mass masks. Strict past uses the full global field and must not be recomputed from the current prefix or remaining source.

This exact full-f symmetrization is DISTINCT from the current completed-plan cost. Disintegrating the actual plan as

    tau_v(dy,dz)=g_v(y)c_v(y)dy/m_v * kappa_(v,y)(dz),
    g_v=1_{f>Tq_v}(f-q_v)_+,

its ordered integrand contains g_v(y) and the true conditional capture loss 1-c_u(z). These are endpoint-asymmetric. One may dominate g_v<=f and 1-c_u(z)<=1 to get a first-moment upper relaxation, but then that is not an equality for G(tau). A source exchange, symmetric heatbath, target reset, or independent resampling must separately prove the correct original marginal and target capacity. The cost of the abandoned source/target marks cannot be recovered later as an unchanged negative capture credit.

The physical clock can be reordered with nonnegative Tonelli, including its b atom. Signed capture/difference identities require finite positive parts: G and its L/capture pieces are finite under the established baseline, so subtracting those pieces for the SAME plan is legitimate. A differently relaxed positive upper bound does not supply a new negative term.

## 4. Joint Hardy is available with exact actual loss weights

For any actual measurable source-row mark beta_v(y) in[0,1], including the high-source restriction, define

    C_beta(y)=integral beta_v(y)1_{f>Tq_v}(1-q_v/f(y))_+ c_v(y) mu(dv),
    Xi_beta=integral f(y)C_beta(y)dy <= |E|,
    T_y=J_y(b).

Set all zero-f terms to zero. The proved R377 original-clock theorem is

    B_beta:=integral dv integral beta_v L_v d mu_v^H
       <=lambda integral f(y) Phi_h(T_y,C_beta(y))dy,

where Phi=0 for T<=h and otherwise integral_0^C log_+(T/max(h,s))ds. In particular for any 0<theta<1,

    B_beta <= (lambda/q_-)theta X_q
              +lambda log(1/theta) Xi_beta.

Equivalently choose theta=epsilon q_-/lambda to obtain epsilon X_q+lambda log(lambda/(epsilon q_-))Xi_beta when that theta lies in(0,1). These formulas preserve the original strict-left radius gate. Radius atoms, including the first crossing atom, are handled by the rank theorem; ordinary differentiation or a continuous-radius approximation cannot replace it.

For a target-dependent actual mark b(v,y,z) in[0,1], average b under the SAME conditional kappa_(v,y) to define beta. Then the marked bad cost is EXACTLY

    Bad_b(tau)=B_beta - Capture_b(tau),
    Capture_b=integral b(v,y,z) K_v(y,z)d tau_v dv >=0.

This is a lawful way to retain its actual capture return. It is not an extra old-square rebate. Xi_beta must be the actual integrated first-source loss/mark, not a count of deficient rows or an unnormalized Hall cut. A bound on Xi_beta, or on the smaller signed balance after Capture_b, is still needed for a root source budget. If the plan is changed, both beta and capture must be recomputed along with target-cap/source exactness. The simple G<=X and joint-Hardy relaxations are alternative bounds on their stated quantities; their order-one positive pieces are not separately absorbed.

## 5. Quantifiers that a new geometric payment must supply

A usable theorem must specify its ONE frozen full-f field, one complete original plan or explicit reconstructed one, the actual first-source marks and target capacity, whether the estimate is per source y or integrated f(y)dy, every physical clock/prefix atom and strict past condition, and the exact positive restriction paid. A source-adaptive window may depend on all receivers through the same y, but not be privately recentered for each v. A true source-centered map must preserve the source weights or prove its actual incoming capacity; source-row reversibility of an unmarked kernel does not establish that capacity for the marked plan.

Any new simultaneous concentration, target-union/Hall or source-return claim must bound the actual cost-weighted spectrum/loss, rather than a model with endpoint marks or capture correlations removed. All established window/anchor/tree receipts remain complete alternative decompositions. The original entrance factor 2Lambda, H/source terms, and all soft/history/scale/threshold/limit interfaces are still payable. No new M2 sufficient-condition reduction is used in this screen.

## 6. Multi-mass positive-volume numeric design: required scope checks

At the initial independent-screen stage no R382 numeric design had been provided yet. A pressure diagnostic should keep one complete positive-volume full-f source and recompute every q=m/R^n from it. Receiver quadrature must be called quadrature; it cannot be relabeled actual du. Its positive original cost must genuinely involve several separated receiver masses at the SAME old source cells, with both actual receiver weights and all declared original marks/clock inside the cost. Merely listing many radii, or placing different masses on disjoint source supports, does not pressure the shared-source adaptive-window bottleneck.

Before treating any example as native hard traffic, verify all actual q-band, strict far mass order, global strict past, J>=H, high source, outside/not-Bplus, sparse/dense/deep and physical clock gates with positive actual measures. Finite low-dimensional multi-mass incidences may still be valid algebra/selection pressure tests, but must be marked as diagnostic when those native gates are absent. If the full tested receiver mass range fits inside the chosen window width, full source-window coverage is automatic and is not concentration evidence. In particular the entire original n=1 octave allowed range has log(m_+/m_-)<=log(8/3)<1, so a log-width sqrt(n)=1 window already covers it before any geometry or optimization. This is a scope guard, not a counterexample search.

A finite experiment can check complete source-first plan feasibility, common target capacity, original aggregate cost/strictness, source-common finite-anchor/window optimization and actual remaining tails. It cannot certify arbitrary-field root alignment by observing a small finite residual or computing an optimum in a relaxed cone. Their subsequent exact design is reviewed in the final numeric section below.

## 7. Actual bounded local checks and screen decision

Reviewer actually ran 185 standard-library Fraction assertions on 2026-10-18: 56 row/detailed-balance checks on positive-length actual 1D interval-source cells with finite receiver quadrature; 108 ordered-versus-symmetric far-pair equalities with big-endpoint strict-past marks; and 21 scalar same-plan capture decompositions. The source in the kernel checks is fixed full f=1 on a compact containing interval, so q=1 and all interval masses are matched. These tests do not realize the current high-density/dense-deep/native hard traffic and are not the analytic proof. They will remain separate from future parent counts; no prior large pipeline was repeated.

Initial decision: the precise baseline, common-source kernel and joint-Hardy interfaces above are usable. No new root payment, actual spectrum concentration or general source-plan interchange has been certified. The subsequent author claims and final integrated ledger are reviewed below.

## 8. New independent screen: large-endpoint source anchors/windows

PASS. In the SAME actual completed-plan bad integral, mark the large receiver u by chi_theta(m_u/s(y)), with one positive measurable source-only s(y). Source exactness and target-loss<=1 bound the inner small-v source integral by f(y)Z_y(m_u/K-)<=f(y)J_y(r), just as in the baseline. The new mark is independent of v,z,r at fixed u,y and can remain outside this cancellation. Keeping the original nonzero clock gate until J cancels and then using the inclusive physical tail gives

    G_large,chi <= integral f(y) integral_E c_u(y)chi_theta(m_u/s(y)) du/R_u^n dy
                 <= lambda integral f(y) integral_E c_u(y)chi_theta(m_u/s(y)) mu(du)dy
                 <= (lambda c_theta/q_-) W.

Unlike the old small-v anchor receipt this proof does not first bound the integrated clock by B_star. It uses original q_u<=lambda only after exact source/J cancellation. A source-only probability kernel of anchors is equally permitted by nonnegative Tonelli. The same fixed-window envelope yields the actual u-window price

    G_large,[L,U] <= (lambda/q_-) integral f(y)[1+log(U(y)/L(y))]dy.

Thus log-width<=sqrt(n) pays the whole original large-window subbranch at (lambda/q_-)(1+sqrt(n))W, without a new receiver error, B_star factor or target-capacity term. This is a real weighted/window branch statement, not a uniform share or full concentration result. The original J, global strict past, high source and actual matching must stay fixed; an anchor/window private to u,v or a changed clock would not be this proof.

A small-v window branch and then a large-u window on its complement can be settled in that exact order. The latter only reduces the same positive original integrand, so the large receipt remains valid. Their distinct actual subflows may be added with their respective explicit source prices, leaving the original double-outside-window cost. There is no permission to subtract either positive payment from an old Hall upper bill, reuse target capture/square credit, or identify different completed plans. Same-plan target capacity is unchanged. Finite sourcewise selection, if invoked, must aggregate the actual cost by the LARGE mass m_u, not silently reuse a small-v cost spectrum.

## 9. Independent algebraic screen for the forthcoming clock attachment

For an actual large/small far pair with I_uv=f(Q_u intersect Q_v), its symmetric-difference factor is

    m_u+m_v-2I_uv = (m_u-m_v)+2(m_v-I_uv).

For any one positive common-source/clock pair measure retaining the original marks, this is an exact positive decomposition. Because I_uv<=m_v and m_u>K m_v, the square fraction relative to the positive first-moment factor satisfies 2I_uv/(m_u+m_v)<=2/(K+1). This is conditional on using the same pair measure/factors and the same orientation normalization; it does not identify the mass-difference term with the entire far variance loss or pay the positive overhang. An author attachment claiming only this precise identity will be checked against its actual definitions and source/clock weights. The old square cannot subsequently be added to an unrelated plan's target-capture return.

## 10. Bounded author clock review: PASS, wording clarification resolved

After the preceding independent algebraic screen, read r382_clock.md and its complete standalone script. The author fixes the genuinely matched hard slot beta=nu=f and expands the original A-square into the symmetric-difference kernel with the correct factor1/2. The positive portion selected by a far-oriented theta is B_theta (not half of it), since the transposed orientation contributes its equal counterpart. Strict far orientations are disjoint, so theta+transpose<=1 and this is a true positive restriction of the original full-f variance expression. Original source/window/past marks are inside dLambda, not turned into an unmarked independent marginal.

The identity B_theta=G_theta+2 integral(m_v-I_uv)dLambda and the first-moment/square ratio 2/(K+1) have the correct direction. They are lower descriptions of a positive original piece, not an upper fee or a general cancellation. Exact mass-threshold layer cake preserves atoms at receiver masses because its integration variable is Lebesgue dt. The unmarked factorization F(t)(J-F(t))/J is explicitly limited to the unrestricted pair product; the actual far/source/window marks use the unreduced marked formula. The plan reward comparison correctly distinguishes the original full-f square from a new plan's actual joint conditional target. No payment or square credit is silently inserted into the ledger.

One wording clarification was sent to the parent: the ungated complete first moment equals X_q, but retaining 1_{J>=H} generally gives only <=X_q. The author's sentence 'Its full first-moment integral is X_q' should expressly refer to the UNGATED full first moment, rather than imply equality for the selected high-J portion. The proof only needs the upper bound. This is not a defect in the positive identities, script, or main candidate receipt; its corrected final wording is confirmed in the final byte review below.

The standalone 9072 Fraction assertions are author-reported at this stage: 8532 scalar,54 actual cube/pair and486 marked-clock tests. Actual compact uniform source cubes produce q=1, and source integration is exact by positive-volume face cells. Receiver weights are finite quadrature. Rational K and h choices are diagnostic of the universal identities, not original root/high-density native traffic. Omission of source regions where every receiver indicator is zero does not affect these integrals. This reviewer read the entire code and did not repeat it; parent fresh-run confirmation and final byte binding are recorded below.

## 11. Geometry author proof/code review: PASS

Read the frozen r382_geometry.md and complete r382_geometry_check.py after the independent candidate screen. The exact pair cost measure has the correct du dv/(h R_u^n), original A_uv omega_u c_u(y) and actual target loss 1-c_u(z). Substituting the full original omega first restores the entire inclusive physical clock and cancels its h R_u^n algebraically. The proof never assumes target/source independence or bounds omega prematurely. Source exactness after loss<=1 gives f Z, and strict far mass plus full matching makes Z<=J on every retained r. This proves the stated general a(u,y) inequality, including extended nonnegative integrals, and the large-end lambda/q_- receipts follow with the correct factors. The source-only anchor/window specialization must remain distinct from the general mark a(u,y); a private anchor indexed by u is not covered by the center receipt.

The soft and closed-window envelopes agree with the independent derivation, including theta=1, theta<1's integrable center singularity and L=U. The exact two-ended partition has no repeated paid part. If one closed window of width at most log K is used at both ends, strict m_u>K m_v prevents simultaneous membership, including the equality-width endpoint case. This statement would not hold as a disjointness assertion for soft weights; the author correctly limits it to window indicators.

The optional R378 residual construction in §5 is valid on FIXED source windows/anchors. The new kernel is obtained by multiplying the original finite nonnegative u coefficient by (1-b(v,y))(1-a(u,y)). This multiplier depends on u,v,y but not the transported target z, is bounded by one and is jointly measurable. Thus it remains an original capture-omission kernel, its row bound is no larger than B<=Bbar, and its dyadic box omission measure is dominated by the old one. For original-source-a.e y, the same interior/Fubini shrinking-box proof applies. The original high-source marginal is unchanged; residual weight is in the cost kernel, not a fictitious recomputed input. The finite relation/Hall and layered construction therefore keep the same levels, approximation accuracy and source-exact t-cap target. The paid large/small branches have valid upper prices for ANY such source-exact plan, including the newly constructed one.

If the windows were optimized from an earlier fixed plan, they must be frozen before constructing a different residual-kernel plan. The new plan may use those windows but is not thereby guaranteed to realize the old plan's optimal coverage. The optional new Hall bill must be recomputed and no old bound is reduced by subtracting a payment. The main/ledger integration will be checked for that exact distinction.

Parent confirms an actual fresh run of all890 grouped Fraction tests. Their 162 clock-plan cases include target-correlated cap2 plans and108 positive costs; actual m/q and the physical terminal atom are checked. The remaining540 center inequalities,182 total two-end identities and6 radial constants are finite rational diagnostics. The diagnostic K=3/2>lambda/q_- and finite quadrature are openly distinct from native dense-deep/root hard traffic. Reviewer read but did not duplicate the run.

The clock author's §1 wording correction has been received: the UNGATED full first moment equals X_q; the retained high-gate portion is <=X_q. Parent also confirms a fresh9072 clock-script run. No arithmetic or proof formula was changed. That earlier wording issue is resolved, with the final byte binding below. All new original large-endpoint receipt statements pass; final integration is completed below.

## 12. Finite two-endpoint selection author proof/code: PASS

Independently screened the joint objective before reading r382_selection.md, then read that whole file and r382_selection_check.py. The cost pushforward in (y,log m_u,log m_v) is a finite positive measure because total actual cost<=X_q; its original-source exact marginal implies its y edge is absolutely continuous. A finite jointly measurable conditional cost kernel Gamma_y can therefore be chosen outside one common null set. Finite sourcewise scores are measurable and the first lexicographic maximizing pair supplies a single source-only window pair. The actual two-endpoint receipt then applies uniformly; there is no multiplication by candidate count and no sup moved inside an individual pair integral.

For fixed-ratio finite-spectrum hard windows, shifting the left endpoint to the smallest currently covered mass preserves all already covered endpoint masses and cannot reduce the nonnegative union objective. Empty selections can be replaced by any available candidate without reducing a nonnegative objective; a completely zero spectrum can use a fixed default. This establishes finite candidate sufficiency for each side and their product list.

For the soft objective a+b-ab, fixing one endpoint leaves a nonnegative weighted mass spectrum for the other. Its score is convex between log-mass knots and monotone toward the knots on the tails. Starting from any anchor pair, replace the large anchor by a knot without decreasing the score, then the small anchor by a knot without decreasing it. Thus enumeration of the finite product of knot sets attains the full two-anchor supremum. This is not a claim that arbitrary coordinate ascent reaches a global optimum, nor that every pair may select a private anchor. The source-only tariff is exactly q_-^{-1} integral f(c_theta_v b_h+lambda c_theta_u).

For one common closed window of width<=log K, strict far order excludes simultaneous inclusion and the three unpaid regions are exactly both below, strict straddle, and both above. Endpoints are in paid closed windows, so no missing equality case exists. These are locations of the original residual, not new fees. The author explicitly freezes optimized windows before any rebuilt residual-kernel plan, and does not transfer old-plan optimal coverage to that new plan.

Parent reports an actual fresh28044 Fraction run. The whole script tests finite theta=1 joint soft/hard candidate grids, closed-window far disjointness and positive conservation on its finite chosen spectrum. It does not certify native receiver Lebesgue traffic or general cost concentration. Reviewer read but did not repeat this pipeline. Author-block PASS; final numeric and integrated byte freeze are completed below.

## 13. Provisional current main/complete ledger review: PASS

Read the current r382_main.md and complete inherited-plus-increment r382_ledger.md. Their preferred exact same-plan residual is R2=integral(1-b)(1-a)dG. The combined uniform source coefficient is correctly F2=[B_star(1+D_v)+lambda(1+D_u)]/q_-, and the hard bound has only (eta+sigma_n)X_q because it retains actual residual cost instead of a Hall upper approximation. The large-only variant omits the small-end fee and its unnecessary mark. For width sqrt(n), only-large has a genuine O(sqrt(n))W source price at fixed lambda/q_-=4/3; the combined option retains the small-end logarithmic B_star factor. Neither is asserted to cover all traffic.

The entrance keeps 8lambda H W,2d_eff A_n W_nu/H,2R2, twice the receiver coefficient and twice the whole source fee, then multiplies by Lambda. Existing parameter definitions, sigma_n and target template (T+t)Gamma remain synchronized. No physical atom, history fee or contract-external soft/scale/threshold/limit obligation is declared paid by the local receipt. There is no new X coefficient or repeated original-square subtraction.

For the optional new residual-kernel construction, windows are explicitly frozen first, the original z dependence is retained, its nonnegative u coefficient is smaller, and R378's same t and accuracy apply. D2 is a new actual Hall bill, with its epsilon+epsilon-prime approximation receiver fees; it is not old D minus a payment. Choosing windows using an earlier plan does not transfer that plan's optimum coverage to this newly constructed plan. The current main/ledger also explicitly isolate numerical relaxed geometry gates or fixed h diagnostics from the synchronized theoretical hard bound. Final numeric review and all byte bindings are completed below.

## 14. Final true-dx numeric model, code and saved results: PASS within scope

Read the complete final numeric.md, numeric.py and saved result JSON, including all three stage summaries, endpoint spectra/window indices, matrix digests, precision comparison, gate scan and dependency metadata. The background-plus-packet construction is a genuine compact positive-volume L1 source, and receiver shells are actual Lebesgue sets rather than quadrature. With s=1/(4n), every receiver cube contains Q_s and lies in Q4; hence m_j=(3/4)r_j^n+1/4 and q_j in[3/4,1] use the SAME full f. Shell volumes are exact differences of n-dimensional box volumes. Every packet source y has all receiver captures, so J and strict past are constant there. Outside the packet f=3/4<=q_v and the surplus vanishes. The computed d_v=(1/4)[1-(s/r_v)^n]/m_v is therefore the complete actual surplus source mass, not a point probe or a reset input. Full W=(3/4)4^n+1/4 remains in every W normalization.

The target overlap average integrates both receiver center shells and the uniform target in Q_v. The one-dimensional interval-difference density times interval-overlap trapezoid is integrated by the four exact tent products; tensorization and four signed shell terms implement the actual multi-dimensional pair integration. The independent Simpson expression is exact for each piecewise quadratic segment and includes the symmetry factor2; it is not sampled quadrature evidence. The special positive-part cubic check is used on valid outer-side/radius configurations. The retained pair coefficient w_i w_j d_j(1-m_j/m_i) clock_i(1-pbar_ij) has both actual receiver volumes, source normalization, original reciprocal J and terminal physical clock atom. No mass denominator or source density has disappeared without the stated matching/source integral.

The actual hard ratio K=exp(sqrt(n)) is classified by rigorous positive rational Taylor lower/upper bounds for the three cost dimensions4,16,64, whose square roots are exactly the tested integers. These are certified finite far-classification comparisons. Window optimization is a finite original endpoint-mass enumeration shared by the complete packet source, with small-v first and large-u only on its complement. It does not choose a different window for each pair. n4 cost has an independent exact Fraction evaluation. n16/64 tensor costs, target overlap arithmetic and selected window scores are ordinary mpmath computations, with50/80-digit agreement rather than interval certification. Saved maximum relative disagreement is below3e-49, as the note states; the code's tolerance is correctly disclosed as an ordinary numerical check.

These true-dx costs are nevertheless GEOMETRY-RELAXED diagnostics: outside/not-Bplus/dense/deep/history and other remaining-pair masks are omitted, and the low-dimensional cost stages select H=h=J_b/64. That is not the synchronized R379 ledger threshold nor an original-history budget certificate. The many distinct masses pressure a shared-source mass spectrum, but do not realize the full currently unpaid hard branch. At n64 a root-width double-window leaves about0.310855 of the relaxed cost, yet this is only about8.73516e-20 X_q and4.17841e-39 W. The main correctly uses these absolute costs to reject complete spectrum coverage as an extra necessary target; no general concentration or root bound follows numerically.

The separate Decimal65 scan computes the actual packet-central maximal strict past for each shell field. Other source points capture subsets of the same receivers, so that central value is an upper envelope for this field's past. The fixed epsilon0 shape gate is first positive at4356 among the tested dimensions only, not a certified minimum or synchronized absorption result. The eta=epsilon=epsilon-prime=0.1 scan rebuilds A_n,T,t,Gamma,epsilon0,h in the correct R379 order and remains empty through all tested dimensions up to6400. Both scans are ordinary high-precision diagnostics, not rational interval proofs or all-dimensional statements. The code's ceil(log2(n+2)) expression and physical terminal weight are consistent with the stated parameters.

The requested FIRST terminology correction is now present in final note, code and saved result: they certify actual q<=lambda and same-full-f matching/cap only, and expressly do not certify historical first-crossing or old-selector qualification. No original contract is inferred from that ambiguous name. The only other requested wording clarification, in clock.md, now explicitly distinguishes ungated first moment=X_q from retained high-gate first moment<=X_q. Neither correction changed arithmetic or proof identities.

Final numeric counts are5050 exact Fraction assertions (537 geometry,49 independent overlap integrals,4462 far classifications,2 small-cost checks),6087 ordinary MP assertions and9 ordinary Decimal assertions. The two precision runs count executions, not new independent mathematical claims. mpmath1.3.0 is an explicit dependency, with the actual local vendor fallback and Python version recorded. This is not a standard-library-only program, no interval arithmetic is claimed for MP/Decimal, and no MATLAB/optimizer run or fitted exponent is reported. Reproduction under another Python version may change metadata; that is not a mathematical difference.

## 15. Final complete ledger and decision

The current final main/ledger/readme retain the new large-endpoint payment at lambda(1+D_u)W/q_- without B_star; small-end window costs B_star(1+D_v)W/q_-. The combined F2, exact same-plan double-outside R2, two-ended positive order, finite sourcewise joint selection, and optional rebuilt residual kernel all pass for the original full-f fields. Source windows may be chosen from a fixed plan, but their old-plan optimal coverage is not transferred to a new plan. The optional rebuilt Hall bill D2 is recomputed and keeps epsilon+epsilon-prime errors. No original square or different-plan capture return is spent again.

The complete entrance preserves8lambda H W,2d_eff A_n W_nu/H,2R2 or2D2, the appropriate receiver coefficient, twice the complete source fee and outer Lambda. No new X coefficient is introduced by the anchor/window receipt, and the original target template is unchanged. Original parameter synchronization is not replaced by the fixed-epsilon0 numeric shape test. All double-outside, H-selection, soft/crossing/entry, historical/deleted-source atoms, extreme-scale/threshold-complement, source/scale aggregation and limit obligations remain explicit. The slot-specific kappa allocation is not a global absorption certificate.

Parent confirms actual fresh runs of geometry890, selection28044 and clock9072 Fraction scripts, plus the numeric5050 Fraction/6087 MP/9 Decimal script. Thus exact parent assertions total43056; ordinary diagnostics remain separately6087+9. This reviewer read proofs/full code/saved results and did not duplicate those pipelines. Reviewer-only185 bounded Fraction checks are separate, with their limited scope already stated. Final editorial scope corrections are bound below; archive extraction/re-execution, LaTeX typesetting and Git actions are outside this audit. No PDF compilation is certified.

Final decision: FINAL PASS for the bounded new payment, explicit selection and complete ledger as stated. General n^(1/2+o(1)) closure and the actual double-outside/source/outer/history/scale budgets remain unresolved.

## 16. Final SHA256 byte bindings

Exact reviewed current files follow. The audit hash is reported separately after saving.

- `/tmp/r382_main.md` — `70cb814a0c322e71f63eb30976b6d5e7163749711a365e1015e8f255f5de6baa`
- `/tmp/r382_ledger.md` — `5039bc2e99f5e8d9783fb42aae1d34bb36ad55d385acd7e5444a2e0c55ab3938`
- `/tmp/r382_readme.md` — `1b0ed32d5984b541b303546cf21e86fba05fb40371f5cf9016e7df8b320b0687`
- `/tmp/r382_geometry.md` — `e596a311e4eca9be309c10aafe75db0e1938aa815dd258538461bdf0d47f2944`
- `/tmp/r382_geometry_check.py` — `6bf9d2d358ce12ce06f1cc49062a6cda621e02c33b694ca243675aca2859aa85`
- `/tmp/r382_selection.md` — `d0bd157001bcec7a3836a3bf757d3a7cf8f902eb9496dc1b40e9ada9fc301f79`
- `/tmp/r382_selection_check.py` — `1386a76254ec35c3e3ab6b2819ee3b46e6702f2491016206dd99c5ef774d0ee5`
- `/tmp/r382_clock.md` — `e58f537148f6abaddf6f6f8668dd55a600edcb1cf2b3824cab429a94c7a4b901`
- `/tmp/r382_clock_check.py` — `6ff445426c8b46a993693e0b062524dda2bcc56005c01ce8d1dcc15f6aad3ce9`
- `/tmp/r382_numeric.md` — `b87ae3848b3a4654fa9780595374ba5a908c56c22eeabe9cc88e3a075e28e545`
- `/tmp/r382_numeric.py` — `0a10d55a4802aecfd9b580e3b0c5d887b56c7ef82c5152682a15c5f50d3ac876`
- `/tmp/r382_numeric.result.json` — `5ae7412e3d7a426a079cc4ee11de401df84ef1fd71892a71a543b1a5e484857a`

Necessary inherited interfaces, used only at their specified boundaries rather than comprehensively re-audited:

- `/tmp/r381_anchor.md` — `71c2a1c6e0b3281668e2d290839195bcf8c25883b0a2945454bbfd15b4aa4e3e`
- `/tmp/r381_geometry.md` — `df86a325407457678613cc00fb4de37023ff29fb5d6ce4b039238c148a2f071f`
- `/tmp/r381_ledger.md` — `085b468bf2920f39e4c980b6f913b75e8574a4159df1ad81967acaf2c9bb7b6a`
- `/tmp/r381_audit.md` — `75cc1fc7204a1aaed34f3c0a5af9094e3f33ed5263860f304f1b409e81844062`
- `/tmp/r379_ledger.md` — `5f577d1d01cfe9ac3d992853c9e92cbe85e1fe5fc4e6758591b1858a8dcdc063`
- `/tmp/r378_layered.md` — `8d7f0361b15108b014b9fb7ddc8c124e17f268a2ba98ff7bb8ab2489b188e24d`
- `/tmp/r377_geometry.md` — `16b083e57cd84fe7d3b8b9a077d2211941e7efd340d3bf3bc7fdb0fcaa85a29d`
- `/tmp/r376_geometry.md` — `16c68acce633ca7df17e8f2506fbc31c4aa00495b89200c84b745289e5b3caa7`
- `/tmp/r370_geometry.md` — `fac02a43e18ed5dc3d5be7ef67a8ac9e34cbd4dd1e69912d6e29dffda597d81a`

FINAL PASS. Audit stopped without author/repository changes or a general-closure claim.
