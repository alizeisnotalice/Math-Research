# R382 — Original-clock payment at the large receiver, without B*

## 1. Exact pair cost and new receipt

Freeze the entire R379/R381 field: full f, actual receiver Lebesgue measures, m_u=q_uR_u^n, q_-≤q_u≤λ, original strict mass past and source-dependent J, H, h, physical clock, and all remaining far-mass/outside/not-Bplus/dense-deep gates. The actual far ratio satisfies K>λ/q_-.

Let τ_v^H have exactly the original high-source marginal
\[
 \mu_v^H(dy)=1_{\{f(y)>Tq_v\}}
 {(f(y)-q_v)_+c_v(y)\over m_v}\,dy.
\]
Its target may depend on the source and may be correlated with all original kernels. The argument also applies to the complete surplus source or any source marginal dominated by it.

Write A_uv for the unchanged remaining pair mask times 1−m_v/m_u, so
0≤A_uv≤1_{m_v<m_u/K}. Define the nonnegative exact pair-cost measure
\[
 d\mathcal G(u,v,y,z)=
 {du\,dv\over hR_u^n}
 A_{uv}\omega_u(y)c_u(y)(1-c_u(z))\,\tau_v^H(dy,dz). \tag{1}
\]
The total is the actual remaining high-source bad cost. None of the following weights replaces this measure or its source law.

For any measurable source anchor s(y)∈(0,∞) and θ>0, put
\[
 \chi_u(y)=\min\{m_u/s(y),s(y)/m_u\}^{\theta},
 \quad
 c_\theta=\begin{cases}2/\theta,&0<\theta\le1,\\
                       1+1/\theta,&\theta\ge1.\end{cases}
\]
Then
\[
 \boxed{\int\chi_u(y)\,d\mathcal G
 \le{\lambda c_\theta\over q_-}W.} \tag{2}
\]
Unlike the small-v source-anchor price, this contains NO B* factor.

More generally, any measurable finite positive closed source window
0<L_u(y)≤U_u(y)<∞ satisfies
\[
 \boxed{\int1_{\{L_u(y)\le m_u\le U_u(y)\}}\,d\mathcal G
 \le{\lambda\over q_-}\int f(y)
       [1+\log(U_u(y)/L_u(y))]\,dy.} \tag{3}
\]
If the logarithmic width is at most D, its price is λ(1+D)W/q_-.
For D=√n this is a genuine root-order source price for the full marked branch. Likewise θ=1/√n in (2) gives 2λ√n W/q_- for the soft large-end weight. The complementary pair cost remains unpaid; these statements do not assert complete coverage.

The anchors/windows may depend measurably on the frozen full field or a fixed chosen plan. They must be functions of y, not private choices indexed by v or the transported target z.

## 2. Original-clock cancellation, before any pointwise L relaxation

We prove a more general inequality. For any nonnegative measurable mark a(u,y) independent of v,z,
\[
 \boxed{\int a(u,y)\,d\mathcal G
 \le\int f(y)\int_E {c_u(y)\over R_u^n}a(u,y)\,du\,dy.} \tag{4}
\]
Extended nonnegative integrals are permitted; bounded marks will be used.

Substitute the EXACT original weight
\[
 \omega_u(y)=hR_u^n\int_{[R_u,b]}\ell(dr)
 {1_{J_y(r)\ge H}1_{Z_y(m_u/K-)>h}\over J_y(r)}.
\]
The hR_u^n factors cancel algebraically in (1). Now use
1−c_u(z)≤1 and the actual source marginal of τ_v^H. After positive Tonelli, the v contribution at fixed u,y,r is
\[
 \int_E A_{uv}\,
 {1_{\{f(y)>Tq_v\}}(f(y)-q_v)_+c_v(y)\over m_v}\,dv
 \le f(y)Z_y(m_u/K-). \tag{5}
\]
This is where arbitrary target/source dependence is handled: it is removed only by a positive inequality followed by source exactness. The mark a(u,y) remains outside the v integral.

Full matching and K>λ/q_- imply
m_v<m_u/K⇒R_v<R_u. Thus for every r≥R_u,
\[
 Z_y(m_u/K-)\le J_y(r). \tag{6}
\]
On the retained strict-past gate the denominator is positive. Equations (5)–(6) cancel the ORIGINAL reciprocal J; zero-denominator rows are zero by convention. Remove the remaining indicators only after this cancellation. Finally the full inclusive physical tail, including its terminal atom, is
\[
 \int_{[R_u,b]}\ell(dr)=R_u^{-n}.
\]
This yields (4). In particular the proof does not use ω≤1 or L≤B* before cancellation, and does not convert a Lebesgue du integral into an assumed reversible mdu measure.

## 3. Actual-center envelopes at the large end

Since R_u^{-n}=q_u/m_u≤λ/m_u, (4) gives
\[
 \int a\,d\mathcal G\le
 \lambda\int f(y)\int_E{c_u(y)\over m_u}a(u,y)\,du\,dy. \tag{7}
\]
For fixed y and M=s(y), the R380 joint mass/radius calculation applies to the actual u field. For completeness, put ρ=2||u−y||∞. Capture gives m_u≥q_-ρ^n. Therefore
\[
 {c_u(y)\over m_u}\min(m_u/M,M/m_u)^\theta
 \le M^{-1}g_\theta(q_-\rho^n/M),
\]
where
\[
 g_\theta(x)=
 \begin{cases}
 x^{\theta-1},&x≤1,\ \theta≤1,\\
 1,&x≤1,\ \theta≥1,\\
 x^{-\theta-1},&x≥1.
 \end{cases}
\]
Because |{ρ≤r}|=r^n, the radial integral is
q_-^{-1}∫_0^\infty g_\theta(x)dx=c_\theta/q_-.
The single possible singular center when θ<1 has zero Lebesgue measure and the envelope is integrable. Insert this bound in (7) to prove (2), pointwise in the arbitrary measurable anchor.

For the closed window [L,U], let z_0=q_-ρ^n. If capture holds and m_u∈[L,U], then
\[
 {1\over m_u}\le
 {1_{\{z_0\le U\}}\over\max(L,z_0)}.
\]
The exact radial upper integral is
\[
 {1\over q_-}\int_0^U {dz_0\over\max(L,z_0)}
 ={1+\log(U/L)\over q_-}. \tag{8}
\]
This includes L=U: a field with mass exactly M can occupy a positive-volume center set, so the constant 1 must not be removed. No claim of zero cost for a zero-width closed window is made. Equations (7)–(8) prove (3).

Both envelopes concern the actual selected centers. No independent radius integration, source density cap, or coordinate independence of f is invoked.

## 4. Two-ended coverage without repeated credit

The small-end source-adaptive receipt from R380/R381 is valid on the SAME fields and plan. For a small-end mark b(v,y) of either soft-anchor or source-window form,
\[
 \int b(v,y)\,d\mathcal G
 \le P_v,
\]
where the corresponding bounds are
\[
 P_v={c_{\theta_v}\over q_-}\int f(y)b_h(y)dy
 \le{c_{\theta_v}B_*\over q_-}W
\]
for a soft anchor, and
\[
 P_v={1\over q_-}\int f(y)b_h(y)
       [1+\log(U_v(y)/L_v(y))]dy
\]
for a small-end window. Here b_h(y) is the original R376 sourcewise clock envelope, not the new mark b, and all old normalizations remain.

Let a(u,y) be a large-end soft mark or window indicator, with price P_u from (2) or (3). Since a,b∈[0,1], the exact pointwise identity
\[
 1=b+(1-b)a+(1-b)(1-a) \tag{9}
\]
partitions the original pair cost. Therefore
\[
 \boxed{G_H(\tau)\le P_v+P_u+
       \int(1-b(v,y))(1-a(u,y))\,d\mathcal G.} \tag{10}
\]
The second charged piece is bounded by the large-end receipt only after dropping 1−b≤1. It is not charged again in the small-end piece. For closed windows the exact remaining pair has BOTH m_v outside its source window and m_u outside its source window, along with all original gates. For soft marks the product residual is retained exactly.

If the SAME closed source window is used at both ends and log(U(y)/L(y))≤log K, the two window events cannot both occur on a retained far pair: membership would give m_u/m_v≤U/L≤K, contradicting the strict m_u>K m_v. Thus these two paid window pieces are already disjoint, including the equality-width case. This observation concerns closed-window indicators, not the soft marks.

For equal width bounds D_v,D_u, a convenient uniform source price is
\[
 P_v+P_u\le {B_*(1+D_v)+\lambda(1+D_u)\over q_-}W. \tag{11}
\]
One may use just the large-end receipt; the small-end price is not compulsory. No old capture-square, return, or variance credit is added to these positive cost partitions.

## 5. Complete same-field ledger

For any complete plan with the original low-source identity part and the high-source target bound t d_v^HU_v, the R379 sparse and shallow payments and original template give the exact-cost form
\[
 B_H\le G_H^{\rm deep}(\tau)
       +(\eta+\sigma_n)X_q+C_{338}W. \tag{12}
\]
The target tariff remains (T+t)Γ_n. Applying (10) yields
\[
 B_H\le G_{\rm residual}(\tau)+(\eta+\sigma_n)X_q
        +C_{338}W+P_v+P_u. \tag{13}
\]
For large-end coverage alone omit P_v and use residual weight 1−a. No original h, H, q, f, J or clock is rebuilt merely to choose these windows.

If desired, construct the certified R378 layered high-source plan directly for the residual row kernel in (10). It is the original nonnegative u measure multiplied by
(1-b(v,y))(1-a(u,y)); the source marginal is unchanged, the dyadic near-capture construction still applies, and its row bound is no larger than the original B≤Bbar. The same levels, t, finite-depth error, and source-exact target cap therefore remain valid. Calling its ACTUAL deficiency bill D_res gives
\[
 B_H\le D_{\rm res}
 +(\eta+\sigma_n+\varepsilon+\varepsilon')X_q
 +C_{338}W+P_v+P_u. \tag{14}
\]
This is an optional complete plan using the residual kernel. Its Hall bill is not asserted to be smaller by a general theorem; the unproved budget for it is retained. The original pair cost on the paid pieces is bounded for any source-exact plan, including this one, so the reconstruction does not invalidate their prices.

All original entrance terms and outer factors remain. In the full entrance, the additional source price is exactly 2Λ(P_v+P_u). There is no new receiver coefficient from (2)–(3), no target-cap surcharge, and no additional W factor hidden in a product of source integrals. Changes to η or other field-defining parameters would still require the usual synchronized rebuilding; this note does not make them.

## 6. Remaining scope

The new result is a stronger large-receiver original-clock receipt, not a proof that all remaining traffic is covered by narrow windows. A window of logarithmic width √n at the large end is now paid at λ(1+√n)W/q_-, rather than B_*(1+√n)W/q_-.

The exact residual in (10) or (14) may still include high-source, dense-deep pairs with exponentially small geometric overlap and large mass growth. This note does not turn small p into small f mass, or claim that the remaining two-ended mass spectrum is concentrated. The new payment uses the actual common-source small-receiver count to cancel J, followed by an actual-center mass/radius envelope; it does not reuse the old external-source load change of variables.

## 7. Actual three-stage exact verification

Executed locally:
python3 /tmp/r382_geometry_check.py

Output:
PASS {'clock_marked_plan': 162, 'center_envelope': 540, 'two_end_identity': 182, 'radial_price': 6} total 890 positive clock-plan cases 108

Stage 1 uses the same full f to obtain q/m, source-exact target-correlated cap-2 plans, source-dependent anchors/windows, strict mass past, reciprocal J, and the physical terminal atom. It checks the marked large-end cancellation and exact two-end cost partition. The diagnostic far ratio is 3/2>λ/q_- to obtain nonzero low-dimensional test traffic; the proof applies to the frozen actual ratio as well.

Stage 2 checks the pointwise joint mass/center envelopes and closed-window inequalities by Fraction arithmetic. Stage 3 checks the exact radial coefficients and soft two-end algebra. The finite receiver quadrature is not claimed to be a native dense-deep high-past Lebesgue field. The universal assertions are proved in §§2–3. No floating-point fit or new counterexample search is used.
