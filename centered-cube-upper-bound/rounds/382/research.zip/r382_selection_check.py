from fractions import Fraction as F
from itertools import product
from collections import Counter
C=Counter()
def ck(k,b):
 C[k]+=1
 assert b,k
for seed in range(60):
 U=[F(2),F(4),F(8)];V=[F(1,2),F(1),F(2)];W=[[F((seed+3*i+7*j)%9) if u>2*v else F(0) for j,v in enumerate(V)] for i,u in enumerate(U)]
 total=sum(map(sum,W))
 def hard(a,b,ku=F(2),kv=F(2)):
  return sum(W[i][j] for i,u in enumerate(U) for j,v in enumerate(V) if a<=u<=ku*a or b<=v<=kv*b)
 best=max(hard(a,b) for a in U for b in V)
 for a,b in product([F(k,2) for k in range(1,18)],[F(k,4) for k in range(1,14)]):ck('hard_finite_knots',hard(a,b)<=best)
 def soft(a,b):
  return sum(W[i][j]*(min(u/a,a/u)+min(v/b,b/v)-min(u/a,a/u)*min(v/b,b/v)) for i,u in enumerate(U) for j,v in enumerate(V))
 sbest=max(soft(a,b) for a in U for b in V)
 for a,b in product([F(k,2) for k in range(1,18)],[F(k,4) for k in range(1,14)]):ck('soft_joint_finite_knots',soft(a,b)<=sbest)
 for lo in (F(1,2),F(1),F(2),F(4)):
  hi=2*lo;parts=[F(0)]*5
  for i,u in enumerate(U):
   for j,v in enumerate(V):
    if W[i][j]==0:continue
    pu=lo<=u<=hi;pv=lo<=v<=hi
    ck('strict_far_closed_disjoint',not(pu and pv))
    if pv:parts[0]+=W[i][j]
    elif pu:parts[1]+=W[i][j]
    elif u<lo:parts[2]+=W[i][j]
    elif v<lo and u>hi:parts[3]+=W[i][j]
    elif v>hi:parts[4]+=W[i][j]
    else:raise AssertionError('lost edge')
  ck('five_disjoint_parts',sum(parts)==total)
print('PASS',dict(C),'total',sum(C.values()))
print('Finite rational selection and coverage identities; not general spectrum concentration.')
