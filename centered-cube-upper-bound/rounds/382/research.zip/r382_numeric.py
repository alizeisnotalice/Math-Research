#!/usr/bin/env python3
"""R382 true-dx shell diagnostic. Stdlib exact geometry + ordinary MP evidence.
No old /tmp imports. mpmath 1.3.0 required; known local vendor fallback below.
"""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from pathlib import Path
from functools import lru_cache
import hashlib, json, sys
try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0, '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
    import mpmath as mp
BASE=Path(__file__).resolve().parent
COUNTS={'exact_geometry':0,'exact_independent_integral':0,'exact_far_classifications':0,'exact_small_cost':0,'mp_diagnostics':0,'decimal_gate_diagnostics':0}
def ck(v, category):
    assert v, category
    COUNTS[category]+=1

def fm(x): return mp.mpf(x.numerator)/x.denominator

def exp_bounds(k, terms=160):
    s=F(1); term=F(1)
    for j in range(1,terms+1):
        term*=F(k,j); s+=term
    nxt=term*F(k,terms+1)
    return s,s+nxt/(1-F(k,terms+2))

def tent(a,b):
    x,y=sorted((a,b)); return x*x*y-x*x*x/3
@lru_cache(None)
def overlap(a,b,r,s):
    U,u=(a+b)/2,abs(a-b)/2
    V,v=(r+s)/2,abs(r-s)/2
    return tent(U,V)-tent(U,v)-tent(u,V)+tent(u,v)
def trap(a,b,x): return max(F(0),min(a,b,(a+b)/2-abs(x)))
def independent(a,b,r,s):
    cuts=sorted(set((F(0),abs(a-b)/2,(a+b)/2,abs(r-s)/2,(r+s)/2)))
    total=F(0)
    for x,y in zip(cuts,cuts[1:]):
        fun=lambda z:trap(a,b,z)*trap(r,s,z)
        total+=(y-x)*(fun(x)+4*fun((x+y)/2)+fun(y))/3
    return total

def geometry(n,M):
    s=F(1,4*n); r=[1+F(j,M) for j in range(M+1)]
    sides=[x-s for x in r]; prev=[F(0)]+sides[:-1]
    w=[x**n-y**n for x,y in zip(sides,prev)]
    mass=[F(3,4)*x**n+F(1,4) for x in r]
    q=[m/x**n for m,x in zip(mass,r)]
    for x,y,z,v,m,qq in zip(r,sides,prev,w,mass,q):
        ck(v>0 and y+s==x and z<=y,'exact_geometry')
        # For all u in shell Q_side, Q_R(u) contains Q_s and is in Q4.
        ck(y/2+s/2==x/2 and y/2+x/2<2,'exact_geometry')
        ck(F(3,4)<=qq<=1 and m==F(3,4)*x**n+F(1,4),'exact_geometry')
    Klo,Khi=exp_bounds(int(n**.5))
    far=[[False]*(M+1) for _ in r]
    for i in range(M+1):
        for j in range(i):
            ratio=mass[i]/mass[j]
            ck(ratio>Khi or ratio<Klo,'exact_far_classifications')
            far[i][j]=ratio>Khi
    for i,j in [(0,0),(M,0),(M,M),(M//2,M)]:
        a,b,rr,ss=sides[i],sides[j],r[i],r[j]
        ck(overlap(a,b,rr,ss)==independent(a,b,rr,ss),'exact_independent_integral')
        if rr>=ss:
            tt=(rr-ss)/2
            cube=((a+b)/2-tt)
            S=max(F(0),cube)**3-max(F(0),(a-b)/2-tt)**3-max(F(0),(-a+b)/2-tt)**3
            ck(overlap(a,b,rr,ss)/ss==a*b-S/(3*ss),'exact_independent_integral')
    return s,r,sides,prev,w,mass,q,far

def best_window(weights,mass,ratio=None,far=None):
    best=(mp.mpf(0),0,0)
    for l in range(len(mass)):
        inds=[j for j in range(l,len(mass)) if (not far[j][l] if far is not None else mass[j]<=ratio*mass[l])]
        u=inds[-1]
        val=sum(weights[l:u+1],mp.mpf(0))
        if val>best[0]:best=(val,l,u)
    return best

def run_cost(n,M,dps):
    mp.mp.dps=dps
    s,rs,ss,prev,ww,mm,qq,far=geometry(n,M)
    r=list(map(fm,rs)); w=list(map(fm,ww)); mass=list(map(fm,mm))
    h=sum((x/y for x,y in zip(w,mass)),mp.mpf(0))/64; H=h
    J=[]; acc=mp.mpf(0)
    for x,y in zip(w,mass):acc+=x/y; J.append(acc)
    ell=[r[i]**(-n)-r[i+1]**(-n) for i in range(M)]+[r[-1]**(-n)]
    ck(abs(sum(ell)-1)<mp.mpf(10)**(-dps+10),'mp_diagnostics')
    past=[sum((w[j]/mass[j] for j in range(i) if far[i][j]),mp.mpf(0)) for i in range(M+1)]
    clock=[sum((ell[k]/J[k] for k in range(i,M+1) if J[k]>=H),mp.mpf(0)) if past[i]>h else mp.mpf(0) for i in range(M+1)]
    d=[fm(F(1,4)*(1-(s/rs[i])**n)/mm[i]) for i in range(M+1)]
    B=[[mp.mpf(0) for _ in r] for _ in r]; pvalues=[]
    for i in range(M+1):
        if not clock[i]:continue
        ck(0<h*r[i]**n*clock[i]<=1,'mp_diagnostics')
        for j in range(i):
            if not far[i][j]:continue
            num=(fm(overlap(ss[i],ss[j],rs[i],rs[j]))**n
                 -fm(overlap(prev[i],ss[j],rs[i],rs[j]))**n
                 -fm(overlap(ss[i],prev[j],rs[i],rs[j]))**n
                 +fm(overlap(prev[i],prev[j],rs[i],rs[j]))**n)
            p=num/(w[i]*w[j]*r[j]**n)
            ck(0<=p<=1,'mp_diagnostics');pvalues.append(p)
            B[i][j]=w[i]*w[j]*d[j]*(1-mass[j]/mass[i])*clock[i]*(1-p)
            ck(B[i][j]>=0,'mp_diagnostics')
    total=sum(map(sum,B),mp.mpf(0)); ck(total>0,'mp_diagnostics')
    cols=[sum(B[i][j] for i in range(M+1)) for j in range(M+1)]
    rows=[sum(B[i]) for i in range(M+1)]
    windows={}
    for label,ratio,ff in [('1',F(1),None),('2',F(2),None),('16',F(16),None),('exp_sqrt_n',None,far)]:
        v=best_window(cols,mm,ratio,ff); u=best_window(rows,mm,ratio,ff)
        two=(mp.mpf(0),0,0,0,0,mp.mpf(0),mp.mpf(0))
        for l in range(M+1):
            inds=[j for j in range(l,M+1) if (not far[j][l] if ff is not None else mm[j]<=ratio*mm[l])];end=inds[-1]
            first=sum(cols[l:end+1],mp.mpf(0))
            remain=[sum(B[i][:l])+sum(B[i][end+1:]) for i in range(M+1)]
            ex=best_window(remain,mm,ratio,ff)
            if first+ex[0]>two[0]:two=(first+ex[0],l,end,ex[1],ex[2],first,ex[0])
        ck(two[0]>=max(v[0],u[0])-mp.mpf(10)**(-dps+10) and two[0]<=total+mp.mpf(10)**(-dps+10),'mp_diagnostics')
        windows[label]={'small_v_fraction':v[0]/total,'large_u_fraction':u[0]/total,'two_end_fraction':two[0]/total,'remaining_fraction':sum((B[i][j] for i in range(M+1) for j in range(M+1) if not (two[1]<=j<=two[2] or two[3]<=i<=two[4])),mp.mpf(0))/total,'v_window_indices':list(two[1:3]),'u_window_indices':list(two[3:5]),'first_v_fraction':two[5]/total,'additional_u_fraction':two[6]/total}
    W=F(3,4)*4**n+F(1,4)
    X=sum(x*y for x,y in zip(ww,qq))
    for rec in windows.values():
        rec['double_outside_over_Xq']=rec['remaining_fraction']*total/fm(X)
        rec['double_outside_over_W']=rec['remaining_fraction']*total/fm(W)
    return {'n':n,'menu_count':M+1,'source_width':str(s),'source_surplus_support_volume':str(s**n),'full_source_mass':str(W),'receiver_volume':str(ss[-1]**n),'Xq':fm(X),'B_relaxed_product':total,'B_over_Xq':total/fm(X),'B_over_W':total/fm(W),'Jcentral':J[-1],'h_H_diagnostic':h,'max_past_over_h':max(past)/h,'nonzero_pairs':len(pvalues),'min_p':min(pvalues),'max_p':max(pvalues),'mass_min':mass[0],'mass_max':mass[-1],'log10_mass_range':mp.log10(mass[-1]/mass[0]),'windows':windows,'matrix':B}

def exact_small_cost():
    n=4; M=4
    s,r,ss,prev,w,m,q,far=geometry(n,M)
    J=[]; v=F(0)
    for wi,mi in zip(w,m):v+=wi/mi;J.append(v)
    h=J[-1]/64
    ell=[r[i]**(-n)-r[i+1]**(-n) for i in range(M)]+[r[-1]**(-n)]
    total=F(0)
    for i in range(M+1):
        past=sum((w[j]/m[j] for j in range(i) if far[i][j]),F(0))
        if past<=h:continue
        clock=sum((ell[k]/J[k] for k in range(i,M+1) if J[k]>=h),F(0))
        for j in range(i):
            if not far[i][j]:continue
            num=(overlap(ss[i],ss[j],r[i],r[j])**n-overlap(prev[i],ss[j],r[i],r[j])**n-overlap(ss[i],prev[j],r[i],r[j])**n+overlap(prev[i],prev[j],r[i],r[j])**n)
            p=num/(w[i]*w[j]*r[j]**n)
            d=F(1,4)*(1-(s/r[j])**n)/m[j]
            ck(0<=p<=1 and clock>0,'exact_small_cost')
            total+=w[i]*w[j]*d*(1-m[j]/m[i])*clock*(1-p)
    ck(total>0,'exact_small_cost')
    return total

def dec(x):return Decimal(x.numerator)/Decimal(x.denominator) if isinstance(x,F) else Decimal(x)
def gate_scan(n):
    with localcontext() as ctx:
        ctx.prec=65
        rt=Decimal(n).sqrt(); s=Decimal(1)/(4*n); K=rt.exp(); base=Decimal(1)-s
        J=Decimal(0); vals=[]; last=Decimal(0)
        for j in range(n+1):
            r=Decimal(1)+Decimal(j)/n; vol=(r-s)**n; m=Decimal(3)/4*r**n+Decimal(1)/4
            inc=(vol-last)/m;last=vol;J+=inc;vals.append((m,inc))
        past=sum((inc for m,inc in vals if vals[-1][0]>K*m),Decimal(0))
        epsfixed=Decimal(119)/3072; hf=(1+rt)/(epsfixed*Decimal(3)/4)
        An=1+n*Decimal(2).ln(); eta=Decimal('0.1');eps=eta
        T=1+(n+1).bit_length() # ceil(log2(n+2)), correct also powers of two
        Bbar=An*eta*Decimal(3)/4/(2*(1+rt))
        val=Bbar/(eps*Decimal(3)/4); ceillog=int((val.ln()/Decimal(2).ln()).to_integral_value(rounding='ROUND_CEILING'))
        t=1+max(0,ceillog)
        Gamma=1+Decimal(n)/(4*(rt+1))+2*rt*(Decimal(1)/4+(1+rt).ln()/2).sqrt()*(1-1/Decimal(2).sqrt())
        L=2+(72+(T+t)*Gamma)/(1+rt);eps0=eta/L;hs=(1+rt)/(eps0*Decimal(3)/4)
        ck(J>0 and past>=0 and eps0<=eta/2,'decimal_gate_diagnostics')
        return {'n':n,'menu_count':n+1,'Jcentral':str(J),'max_strict_past':str(past),'fixed_epsilon0':str(epsfixed),'fixed_h':str(hf),'fixed_past_over_h':str(past/hf),'fixed_shape_gate_reachable':past>hf,'synchronized_eta_epsilon_epsilonprime':'0.1','T':T,'t':t,'Gamma':str(Gamma),'epsilon0':str(eps0),'synchronized_h_H_selected':str(hs),'synchronized_past_over_h':str(past/hs),'synchronized_shape_gate_reachable':past>hs,'source_log10_mass':str((Decimal(3)/4*Decimal(4)**n+Decimal(1)/4).log10())}

def stringify(obj):
    if isinstance(obj,dict):return {k:stringify(v) for k,v in obj.items()}
    if isinstance(obj,list):return [stringify(v) for v in obj]
    if isinstance(obj,mp.mpf):return mp.nstr(obj,32)
    return obj

def main():
    reports=[]
    for stage,n in [('initial',4),('stress',16),('expanded',64)]:
        low=run_cost(n,n,50); high=run_cost(n,n,80)
        errors={k:abs(low[k]-high[k])/max(abs(high[k]),mp.mpf('1e-200')) for k in ['B_relaxed_product','Jcentral','max_p','min_p']}
        for er in errors.values():ck(er<mp.mpf('1e-40'),'mp_diagnostics')
        matrix=high.pop('matrix'); digest=hashlib.sha256(json.dumps(stringify(matrix),separators=(',',':')).encode()).hexdigest()
        if n==4:
            exact=exact_small_cost()
            ck(abs(fm(exact)-high['B_relaxed_product'])<mp.mpf('1e-70'),'mp_diagnostics')
            high['exact_B_fraction']=str(exact)
        high['small_v_spectrum']=[sum(matrix[i][j] for i in range(n+1)) for j in range(n+1)]
        high['large_u_spectrum']=[sum(row) for row in matrix]
        high.update(stage=stage,mp_precision_comparison='50/80 decimal digits; ordinary, not intervals',max_relative_precision_difference=max(errors.values()),matrix_sha256_32digits=digest)
        reports.append(high)
        print(stage,n,'B/X=',mp.nstr(high['B_over_Xq'],8),'root_two_end=',mp.nstr(high['windows']['exp_sqrt_n']['two_end_fraction'],8),flush=True)
    scans=[gate_scan(n) for n in [4,16,64,256,1024,4096,4356,4624,6400]]
    result={'scope':'True positive-L1 f, real Lebesgue receiver shells, actual q<=lambda and same-full-f matching/cap; historical first-crossing and old-selector qualification are not certified. Full surplus y support Q_s is integrated, and receiver-pair target overlap uses exact tensor geometry. Pair cost retains physical clock/J/massfar but omits outside/deep/history and remaining masks. It is a relaxed diagnostic, not the native remaining branch or synchronized absorption certificate. Gate scan is ordinary Decimal65, not interval certification. H=h is explicitly selected for each diagnostic; its global budget is unproved.', 'check_counts':COUNTS,'stages':reports,'gate_scan':scans,'dependencies':{'python':sys.version.split()[0],'mpmath':mp.__version__}}
    out=BASE/'r382_numeric.result.json';out.write_text(json.dumps(stringify(result),indent=2)+'\n')
    print(json.dumps(COUNTS),flush=True)
if __name__=='__main__': main()
