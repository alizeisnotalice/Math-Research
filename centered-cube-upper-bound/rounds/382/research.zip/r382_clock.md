# R382 — Ordered mass variation after the original square: bounded audit

**Outcome.** No new general source fee is proved. The exact algebra below identifies the positive ordered-mass term that survives the original capture square, with all original source, clock and window-complement marks retained. It also identifies why that square cannot be subtracted again from the R381 plan remainder. This is a checkpoint, not an additional receipt in the ledger.

## 1. Exact original scope

Work in the matched hard full-source slot α=1, s=0, L=R, β=ν=f. All fields are frozen:

m_u=∫f c_u=q_uR_u^n,  q_-≤q_u≤λ,  a≤R_u≤b≤2a,

μ(du)=du/m_u,  E_r={u:R_u≤r},  J_r(y)=∫_{E_r}c_u(y)μ(du),

A_r(y,z)=∫_{E_r}c_u(y)c_u(z)μ(du),  I_uv=∫f(z)c_u(z)c_v(z)dz.

The physical clock is ell(dr)=n r^(−n−1)1_(a,b)dr+b^(−n)δ_b. Set a_r(y)=1_{J_r(y)≥H}/J_r(y), zero on zero rows, H>0. The original hard quantity is

B_H=∫ell(dr)∫f(y)1_{J_r(y)≥H}[M_r(y)−∫f(z)A_r(y,z)^2dz/J_r(y)]dy,

where M_r(y)=∫f(z)A_r(y,z)dz. No J, mass or source measure is recomputed after any restriction. The identity below is not asserted for an unmatched soft/two-source slot.

Expanding the original square gives

B_H=(1/2)∫ell(dr)∫f(y)a_r(y)∫_{E_r²}c_u(y)c_v(y)
                  [m_u+m_v−2I_uv] μ(du)μ(dv)dy.                 (1)

The bracket is f(Q_u Δ Q_v)≥0. Positive Tonelli is valid; alternatively finiteness follows by bounding the bracket by m_u+m_v. The ungated full first-moment integral is exactly X_q=∫q_u du, with the same terminal clock atom; the retained high-gate first-moment part is at most X_q. Thus restricting the nonnegative expression (1) is legitimate, whereas retaining an unchanged positive first moment and independently reusing its square is not.

## 2. Arbitrary original marked far pairs

Let K>max(1,λ/q_-). Let θ(r,y,u,v) be any jointly measurable number in [0,1], supported on m_u>K m_v. It can include the original strict-past event Z_y(m_u/K−)>h, dense/deep gates, a source-dependent R381 window complement in m_v, and an original high-density/surplus factor. Source-dependent markers remain inside the integrals. Define the oriented positive measure

dΛ_θ=ell(dr) f(y)a_r(y)θ(r,y,u,v)c_u(y)c_v(y)dy μ(du)μ(dv),

with u,v∈E_r. Far mass implies R_u>R_v for the actual selector, so this is consistent with original prefixes; it is not permission to select a different radius for a pair.

The corresponding positive portion of (1), taking its transpose as well, is

B_θ=∫(m_u+m_v−2I_uv)dΛ_θ.

Indeed θ(u,v)+θ(v,u)≤1 because the strict far orientations are disjoint. Hence B_θ≤B_H. Equal-mass and other excluded pairs remain in the complementary positive portion of (1).

Full-f matching gives the exact identity

B_θ=G_θ+O_θ,
G_θ=∫(m_u−m_v)dΛ_θ,
O_θ=2∫[m_v−I_uv]dΛ_θ=2∫f(Q_v\Q_u)dΛ_θ≥0.                    (2)

Thus the square has already changed m_u+m_v into the strictly positive mass difference plus an actual outside-source term. There is no remaining negative sign in (2). This remains true for every original θ, not just after a global B_* relaxation.

A quantitative check of the same fact is obtained by retaining the positive term and the exact square contribution separately:

P_θ=∫(m_u+m_v)dΛ_θ,   S_θ=2∫I_uv dΛ_θ.

Since I_uv≤m_v and m_u>K m_v,

0≤S_θ≤[2/(K+1)]P_θ,
B_θ=P_θ−S_θ≥[(K−1)/(K+1)]P_θ.                                 (3)

These are lower bounds on an original positive portion, not a new upper-budget claim or a counterexample to a global estimate. They say exactly which part of this algebra cannot cancel the ordered mass variation. The outside-source term O_θ could itself vanish without eliminating G_θ. No source boundary mass is replaced by volume.

## 3. The ordered spectrum retains the source-conditioned cross-threshold load

For the same original θ, ordinary layer cake in the mass variable yields

G_θ=∫_0^∞dt ∫1_{m_v<t<m_u}dΛ_θ.                               (4)

Both receiver masses in (4) are actual masses. The strict endpoints are immaterial to Lebesgue dt, even when the receiver mass distribution has atoms. This does not remove the original strict-past condition from θ, nor replace the inclusive J denominator by a mass-tail occupation.

For comparison, only when the extra pair gate is absent can the full unordered variation at a fixed (r,y) factor. Put ρ_y(du)=1_{E_r}c_u(y)μ(du), J=ρ_y(E), F_y(t)=ρ_y{m≤t}. For J>0,

(1/(2J))∫∫|m_u−m_v|ρ_y(du)ρ_y(dv)
=(1/J)∫_0^∞F_y(t)[J−F_y(t)]dt.                                (5)

This is a nonnegative mixed-occupation term. The far condition m_u>K m_v and the original source/window marks generally prevent the factorization in (5); their exact formula is (4). Even (5) requires source integration with f(y)1_high and the complete ell. Replacing J by a source-independent maximum or discarding the marks would lose the association requested in this task. No second-moment assumption is introduced here.

The unweighted joint kernel I_uv/(m_um_v) is symmetric. The actual marked kernel in (2) additionally contains ∫f(y)a_r(y)θ(r,y,u,v)c_u(y)c_v(y)dy. The original conditionally symmetric pair representation is obtained by transposing all its marks, not by treating this marked integral as the unmarked intersection I_uv. In particular, a source-dependent window complement is not a new independent receiver marginal.

## 4. Where a plan credit is legitimate, and where it is not

In the R381 source-exact transport formulation the already constructed original cost is

C_v(y,z)=L_v(y)−K_v(y,z)≥0.

For any positive source restriction η_v(y)∈[0,1] and the same plan τ_v,

∫η_v C_v dτ_v=∫η_v L_v dμ_v−∫η_v K_v dτ_v.                    (6)

The second term is a legitimate retained plan reward. It is not equal in general to S_θ, nor to the original ∫f(z)A_r(y,z)^2/J_r(y)dz. Its target marginal is the actual plan target (usually bounded by a multiple of uniform measure on Q_v), rather than the original full-f z measure in (1). Even a matching target marginal would not alone justify substituting one conditional coupling for another; the full joint source law matters.

Consequently the R381 complement may be split positively using its original plan, or a new feasible common plan may be chosen with its full target-cap/template bill. It may retain its own reward in (6). It may not subtract the original square a second time after the prior reduction has already produced the G mass-difference term in (2). An original signed identity with every removed positive term restored would be required to reopen that square.

This audit does not forbid a new geometric bound on the actual plan reward. It identifies the missing comparison: one must bound the exact marked cross-threshold load (4), or lower-bound the **same** plan reward in (6) sufficiently relative to its own remaining linear load. Neither follows from the symmetry of I_uv/(m_um_v), from source exactness alone, or from the currently paid source-window receipt. No new fee is inserted into the original ledger, and all R381 terminal/window complements remain.

## 5. Local exact verification

`/tmp/r382_clock_check.py` was actually run with Python Fraction arithmetic:

`PASS {'scalar': 8532, 'matched_cube': 54, 'marked_clock': 486} total 9072`.

The scalar tests verify (2)–(3). The geometric tests use actual axis-parallel cubes of sides 1, 3/2 and 2 in dimensions 2, 3 and 4, with full source f=1 on [-4,4]^n, and compute exact intersections and masses q=1 by source-cell integration. Receiver integration is positive finite quadrature, explicitly not a native real-du field. The tests verify the original A-square identity independently of the pair formula, then source-marked strict mass gates, source-window complements, (2), (4), and the inclusive terminal-clock/continuous-interval coefficients. Different rational K are algebra diagnostics of the universally quantified K>1 identity, not numerical realizations of every original parameter choice. The continuum assertions follow from the proofs above, not from extrapolating those tests.
