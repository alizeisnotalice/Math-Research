from fractions import Fraction as F
from itertools import product
from math import prod
counts={'scalar':0,'matched_cube':0,'marked_clock':0}
# Scalar decomposition and its exact far-mass credit fraction.
for small in range(1,9):
 for big in range(small+1,19):
  for k in (F(1),F(3,2),F(2),F(4),F(8)):
   if not big>k*small:continue
   for j in range(9):
    I=F(j,8)*small
    assert big+small-2*I==(big-small)+2*(small-I)
    assert 2*I<=F(2,1)/(k+1)*(big+small)
    assert big+small-2*I>=(k-1)/(k+1)*(big+small)
    counts['scalar']+=3
# Actual cubes with uniform positive L1 source on [-4,4]^n;
# receiver integration is finite positive quadrature, not native real du.
for n in (2,3,4):
 radii=[F(1),F(3,2),F(2)]
 centers=[[F((u*(i+1))%5,4)-F(1,2) for i in range(n)] for u in range(3)]
 cubes=[[(centers[u][i]-radii[u]/2,centers[u][i]+radii[u]/2) for i in range(n)] for u in range(3)]
 axes=[]
 for i in range(n):
  bounds=sorted({x for Q in cubes for x in Q[i]})
  axes.append([(a,b) for a,b in zip(bounds,bounds[1:])])
 cells=[]
 for box in product(*axes):
  mid=[(a+b)/2 for a,b in box]
  c=[int(all(a<mid[i]<b for i,(a,b) in enumerate(Q))) for Q in cubes]
  if any(c):cells.append((prod(b-a for a,b in box),c,mid))
 mass=[sum(vol*c[u] for vol,c,y in cells) for u in range(3)]
 assert mass==[r**n for r in radii]
 I=[[sum(vol*c[u]*c[v] for vol,c,y in cells) for v in range(3)] for u in range(3)]
 for u in range(3):
  for v in range(3):
   exact=prod(max(F(0),min(cubes[u][i][1],cubes[v][i][1])-max(cubes[u][i][0],cubes[v][i][0])) for i in range(n))
   assert I[u][v]==exact
   counts['matched_cube']+=1
 du=[F(1,2),F(2,3),F(3,4)];mu=[du[u]/mass[u] for u in range(3)]
 for end in range(1,4):
  J=[sum(mu[u]*c[u] for u in range(end)) for vol,c,y in cells]
  A=[[sum(mu[u]*c[u]*cz[u] for u in range(end)) for vz,cz,z in cells] for vol,c,y in cells]
  for H in (F(1,100),F(1,5),F(1)):
   direct=pair=F(0)
   for yi,(vol,c,y) in enumerate(cells):
    if J[yi]<H:continue
    direct+=vol*sum(vz*(A[yi][zi]-A[yi][zi]**2/J[yi]) for zi,(vz,cz,z) in enumerate(cells))
    pair+=vol*sum(mu[u]*mu[v]*c[u]*c[v]*(mass[u]+mass[v]-2*I[u][v]) for u in range(end) for v in range(end))/(2*J[yi])
   assert direct==pair
   counts['matched_cube']+=1
   for k in (F(1),F(2),F(8)):
    for h in (F(0),F(1,100)):
     B=G=O=pos=credit=layer=F(0)
     for yi,(vol,c,y) in enumerate(cells):
      if J[yi]<H:continue
      for u in range(end):
       for v in range(end):
        if not mass[u]>k*mass[v]:continue
        past=sum(mu[w]*c[w] for w in range(3) if mass[w]<mass[u]/k)
        # A source-dependent window-complement mark; no J is recomputed.
        L=F(1,2) if y[0]<0 else F(2);U=2*L
        mark=F(int(past>h and not L<=mass[v]<=U))
        z=vol*mu[u]*mu[v]*c[u]*c[v]*mark/J[yi]
        B+=z*(mass[u]+mass[v]-2*I[u][v])
        G+=z*(mass[u]-mass[v]);O+=z*2*(mass[v]-I[u][v])
        pos+=z*(mass[u]+mass[v]);credit+=z*2*I[u][v]
        # Exact Lebesgue mass-threshold layer length; all equal-mass atoms excluded.
        cuts=sorted(set([mass[v],mass[u]]+[m for m in mass if mass[v]<m<mass[u]]))
        layer+=z*sum(b-a for a,b in zip(cuts,cuts[1:]))
     assert B==G+O==pos-credit and G==layer
     assert O>=0 and credit<=2*pos/(k+1)
     # Inclusive terminal clock and continuous intervals; no endpoint radius reset.
     R=radii[end-1];nextR=radii[end] if end<3 else None
     ell=R**(-n)-(nextR**(-n) if nextR is not None else 0)
     assert ell>=0 and ell*B==ell*G+ell*O
     counts['marked_clock']+=3
print('PASS',counts,'total',sum(counts.values()))
