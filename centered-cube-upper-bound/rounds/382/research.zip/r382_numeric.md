# R382: true-dx many-mass shell diagnostic

Frozen scope: a genuine positive-volume L1 source, actual hard shared kernel, actual matching q, and Lebesgue receiver shells. The computed product-surplus bad cost retains its physical clock, source J, strict mass-far and high-past conditions. It **omits outside/dense/deep/history and other remaining-pair masks**. It is a geometry-relaxed diagnostic, not the remaining-deep quantity and not a complete original-history input/absorption certificate. No fitted dimension exponent is reported.

## Model and exact geometry

For n=4,16,64, set s=1/(4n), a=lambda=1, b=2,

f=(3/4)1_Q4+(1/4)s^(-n)1_Qs,  W=(3/4)4^n+1/4.

Use r_j=1+j/n, j=0,...,n, outer side a_j=r_j-s, a_(-1)=0, and actual receiver shells E_j=Q_(a_j) minus Q_(a_(j-1)). Assign R=L=r_j and hard softness 0 throughout E_j. Every Q_R(u) contains Q_s and is contained in Q4; boundaries have zero Lebesgue measure. Therefore

m_j=(3/4)r_j^n+1/4, q_j=m_j/r_j^n in [3/4,1].

This verifies actual q<=lambda and same-full-f matching/cap: the actual same-R hard response is <=lambda<4lambda, without resetting f or q. It does not certify historical first-crossing or old-selector qualification. Shell volumes w_j=a_j^n-a_(j-1)^n are actual dx. J_k=sum_(j<=k)w_j/m_j is common to every source y in Q_s. The full positive surplus (f-q_v)+ is supported on that packet and has normalized mass d_v=(1/4)[1-(s/r_v)^n]/m_v. Thus the calculation integrates the complete surplus branch, not source point probes. Nevertheless the packet mass is tiny relative to the complete W, which is retained in every normalization.

For these three cost stages H=h=J_final/64 is a **diagnostic choice**, with its global entrance budget unproved. K=exp(sqrt(n)) is classified by exact rational Taylor lower/upper bounds. Let past_i=sum_(m_j<m_i/K)w_j/m_j and

clock_i=1_(past_i>h) sum_(k>=i) ell_k 1_(J_k>=H)/J_k.

Here ell_k=r_k^(-n)-r_(k+1)^(-n), and ell_n=2^(-n) is the genuine terminal b atom. Effective earlier weights represent continuous clock intervals, not invented initial atoms.

The actual average target capture pbar_ij is computed by four shell inclusion-exclusion terms. Its one-dimensional integral is the exact product of two interval-overlap trapezoids. The closed Ktent formula is independently checked by exact piecewise Simpson integration and by the positive-part cubic formula; neither uses quadrature sampling. Tensor powers then integrate all receiver coordinates. The retained pair matrix is

B_ij=w_i w_j d_j (1-m_j/m_i) clock_i (1-pbar_ij),  m_i>K m_j.

The executable computes this full matrix and records both endpoint spectra and a matrix digest. It does not independently select a partition/window for each receiver: all positive surplus source points share the same selected endpoint windows. Two-end coverage first assigns the small-v window, then assigns the large-u window only on its complement, preventing double counting.

## Results that affect the next decision

The initial/stress/expanded stages use 5/17/65 distinct actual masses. Their mass ranges in decades are 1.08814, 4.69154 and 19.14098. Ordinary mpmath 50/80-digit calculations agree to relative error below 3e-49; these are not interval proofs. The n=4 full cost also agrees with an independent exact Fraction total.

| n | relaxed B/Xq | relaxed B/W | best root-width small-v | best root-width large-u | best two-end coverage | double-outside/Xq |
|---|---:|---:|---:|---:|---:|---:|
| 4 | 1.24363e-3 | 7.24181e-5 | 1 | 1 | 1 | 0 |
| 16 | 1.11636e-5 | 1.50260e-10 | .819018 | .771152 | 1 | 0 |
| 64 | 2.81005e-19 | 1.34417e-38 | .442278 | .321541 | .689145 | 8.73516e-20 |

Root width means a closed mass interval [m,exp(sqrt(n))m]; each anchor is a member of the actual mass menu. For n=64, narrow width 2 covers .073306 at the small endpoint, .040855 at the large endpoint, and .112605 jointly. Width 16 covers .229616, .121416 and .338394 respectively. These are real broad endpoint spectra, but **not hard cases for an epsilon Xq + root W objective**: the root-width uncovered fraction .310855 has absolute cost only 8.73516e-20 Xq and 4.17841e-39 W. Maximizing coverage fraction alone would hide this decisive smallness. There is no evidence here that every cost spectrum must be entirely covered.

## Fixed shape gate versus synchronized ledger

A separate, inexpensive Decimal65 scan uses the same true-dx construction with n+1 shells, up to n=6400. It computes J and maximum strict past, without a high-dimensional pair matrix. With the **fixed** epsilon0=119/3072 and h=(1+sqrt(n))/(epsilon0 q_-), maxpast/h is:

| n | fixed shape past/h | synchronized past/h |
|---|---:|---:|
| 4 | .00748085 | .000644419 |
| 16 | .0320849 | .00358092 |
| 64 | .0916838 | .0118066 |
| 256 | .217335 | .0278803 |
| 1024 | .472771 | .0546220 |
| 4096 | .985977 | .0982820 |
| 4356 | 1.01808 | .101374 |
| 4624 | 1.05018 | .104460 |
| 6400 | 1.24283 | .122858 |

4356 is the first **tested** dimension passing the fixed-shape strict-past gate, not a proved minimum. This only demonstrates shape-gate reachability in an actual field; fixed epsilon0 is not the current synchronized absorption budget.

The last column uses eta=epsilon=epsilon'=0.1 and the R379 ordering exactly: A_n=1+n log 2; Bbar=A_n eta q_-/(2(1+sqrt(n))); T=1+ceil(log2(n+2)); t=1+max(0,ceil(log2(Bbar/(epsilon q_-)))); Gamma as in that ledger; epsilon0=eta/[2+(72+(T+t)Gamma)/(1+sqrt(n))]. It then rebuilds h and selects H=h. **All tested synchronized shape gates are empty.** H's original global entrance budget is not established. These Decimal calculations are finite ordinary high-precision diagnostics, not rational interval certifications or a complete synchronized proof. Other omitted geometry/history gates remain untested even where fixed shape gates pass.

## Reproduction and counts

Run the self-contained script in a fresh process:

`/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r382_numeric.py`

It writes `r382_numeric.result.json` beside itself. Standard library plus mpmath 1.3.0; the script first imports an installed mpmath, then supports the known existing local vendor fallback. This is not a dependency-free standard-library-only program. On another host install mpmath with that host's Python environment, for example `python3 -m pip install mpmath==1.3.0`, or supply an existing mpmath on PYTHONPATH. The bundled Python on this machine lacks a default mpmath import; these runs used the already installed vendor directory `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor`. An archive copied to another local directory will still use that local fallback; no third-party vendor tree needs to be archived. No old /tmp script/data imports. All cases are deterministic. A second fresh run reproduced the result byte for byte.

Final checks: **5,050 exact Fraction assertions** (537 geometry, 49 independent overlap integrals, 4,462 exact far classifications, 2 exact small-cost checks); **6,087 ordinary MP assertions**, and **9 ordinary Decimal gate assertions**. Repeated checks at both precisions are counted as executions, not distinct mathematical claims. No full BH over all beta was substituted by a sample; this is specifically the fully integrated surplus product-bad diagnostic defined above. Full source mass, sourcepacket volume, Xq and endpoint spectra are in the result. No source density cap, receiver point quadrature, Monte Carlo, optimizer, asymptotic fit, repository edit or Git action is used.
