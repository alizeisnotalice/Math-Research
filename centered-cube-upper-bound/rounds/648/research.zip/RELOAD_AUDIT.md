# Independent audit of E-priority actual-alpha reload payment

Verdict: R1-R3 pass for the stated chosen actual E-priority ownership. The own-row-radius refinement gives exactly the requested Z_gamma bound below. The earlier worst-row-radius formulation gives P_mu instead, and these two source moments must not be interchanged. This is a payment of one reload term, not the complete R647 target or a closed recursion.

I first derived the elimination from alpha_j m_j=eps p_j/u'_j and checked the old-high scalar coefficient, then read SOURCE_CLUSTERS.md's latest R1-R3 and its own-row refinement. No other file is changed.

## Ownership permission and its limits

R645 REPORT.tex's complete finite entrance allows a new genuine measurable receiver partition, followed by deletion of genuine zero owners and actual reoptimization. It does not prescribe an immutable new ownership rule. Thus the following rule is admissible on each actual finite action: on U_E=union_j E_j assign each point to a covering E_j by a fixed measurable priority; on U_B\U_E assign each point to a covering B'_j. Since E_j subset B'_j, every assigned point belongs to its receiver. The resulting disjoint I'_j cover the full receiver union a.e.

Let p_j=|I'_j|. Then

  p_j=d_j^own+f_j^own,
  d_j^own=|I'_j intersect E_j|<=ell_j,
  f_j^own=|I'_j\E_j|,
  sum_j f_j^own=|U_B\U_E|=fill.

The last equality is specific to E-priority: points of U_E never go to a label whose E_j misses them. Delete exactly those rows with p_j=0 and recompute alpha on the positive-owner retained set J. All alpha-dependent objects, including Q', kappa', w, J_far and Pplus, must use THIS same optimizer. The old frozen gamma and half-action law do not change, since the ownership choice is made after their geometric action.

If a different actual ownership and alpha have already been fixed, changing only this proof's volume estimate is invalid. With that fixed ownership the argument instead charges F_foreign=sum_j|I'_j\E_j|, which can exceed fill and has not been paid by this lemma.

R645's contact bridge accepts a chosen positive actual successor partition on retained rows and can transfer its weights continuously to nearby receivers. This establishes that the E-priority successor is an admissible actual finite successor. It does not assert that the transferred partition is again the E-priority selector of arbitrarily varying old ownership sets. No such selector continuity is needed for the pointwise finite inequality audited here. If a later tagged-limit proof requires R1-R3 at every recovered approximation using that same selector, it must keep genuine E-priority ownership there or separately verify the required continuity. There is no license to mix the limit optimizer with the approximation's foreign-owner payment.

## Pathwise elimination and scalar coefficients

Use notation E'_j=alpha_j m_j(u'_j-kappa')^2/eps on retained rows. Here

  u'_j=eps p_j/(alpha_j m_j)>0,
  kappa'=eps W/Q'>0,
  B_j=[1-(1+u_j)^(-2/n)]/4 in [0,1/4].

Let f_j(Z) be either r_j(X_j)^2 or r_mu(X_j)^2; both lie in [0,1] on the actual old anchor support. Define L_Z=sum_J B_j alpha_j m_j f_j. For retained next-low rows u'_j<kappa'/2,

  R' B_j alpha_j m_j f_j
    <=kappa' alpha_j m_j/(4eps)
    <=E'_j/kappa'.

For retained next-high rows u'_j>=kappa'/2, exact substitution gives

  R' B_j alpha_j m_j f_j
    =B_j kappa' p_j f_j/u'_j
    <=2B_j p_j f_j
    <=2B_j ell_j f_j+f_j^own/2.

Summing both branches gives the claimed E'_grow/kappa'+fill/2 charge and the diagonal old-anchor term. No alpha or random next-low indicator is frozen independently of the actual action: after this pointwise bound the diagonal term can simply be enlarged to all old labels.

For any U>kappa and old u_j>U,

  u_j a_j/eps = [u_j(1+u_j)/(u_j-kappa)^2] e_j,
  e_j=v_j(u_j-kappa)^2/u_j.

The bracket has derivative -[(2kappa+1)u+kappa]/(u-kappa)^3<0 on u>kappa. Therefore it is at most C_U=U(1+U)/(U-kappa)^2. With 2B_j f_j<=1/2, that branch costs at most (C_U/2)e_j. Thus, for every actual action,

  R'L_Z <= (2/eps) sum_(old u_j<=U) B_j u_j a_j f_j
           +(C_U/2) E_old,{u>U}
           +E'_grow/kappa'+fill/2.                       [R1]

The first sum can include every old label; this only increases it. For a deleted label alpha_j=0, the left contribution is zero, while its old image/old growth account remains present. Expressions u'_j=0/0 and E'_j are NOT defined on deleted rows. The proof never needs such definitions.

At U=4kappa,

  C_(4kappa)/2 = 8/9+2/(9kappa) <=20/21

for kappa>=7/2. The high old set u>4kappa lies inside the old high-incoming set u>1/2; no already-paid low old growth is reused. The coefficient can leave at least 1/21 of each such e_j only if a later unified ledger has not also charged that growth elsewhere.

## Genuine expectation: Z_gamma versus P_mu

For the OWN-ROW reload requested in this audit,

  r_j(x)=||x-y_j||_infinity/s_j on A_j,
  L_Z^own=sum_J B_j alpha_j m_j r_j(X_j)^2,
  Z_gamma=sum_(all old j) integral_Aj r_j(x)^2 dgamma_j(x).

The original old marginals are X_j~gamma_j/a_j. Once [R1] has removed alpha and the next-low/high selector from the first term, ordinary marginal Fubini gives

  E[a_j r_j(X_j)^2]=integral r_j(x)^2 dgamma_j(x).

There is no substitution of a ghost-source conditional law for the realized X_j. The old coefficients B_j,u_j,a_j are fixed before the product draw; the bound applies to the true adaptive alpha_Z pathwise. Since B(u) is nondecreasing,

  E[R'L_Z^own]
    <=[2U B(U)/eps] Z_gamma
      +(C_U/2) E_old,{u>U}
      +E[E'_grow/kappa'+fill/2].                        [R2-own]

At U=4kappa this proves exactly the user-specified uniform bound

  E[R'L_Z^own]
    <=[8kappa B(4kappa)/eps] Z_gamma
      +(20/21) E_old,{u>4kappa}
      +E[E'_grow/kappa'+fill/2].                        [R3-own]

One may retain the stronger coefficient 8/9+2/(9kappa) instead of 20/21.

For the author's EARLIER worst-row reload, where the summand uses r_mu(X_j)^2 and r_mu(x)=max_(k:x in A_k) r_k(x), the corresponding expectation is instead

  E sum_j a_j r_mu(X_j)^2
    =integral r_mu(x)^2 sum_j dgamma_j(x)
    =P_mu.

Thus R1-R3 as originally written with worst-row radii correctly use P_mu. They cannot replace that P_mu by Z_gamma. The final own-row refinement correctly changes BOTH the left reload and the source moment. Although Z_gamma<=P_mu, the reverse comparison is unproved.

Also distinguish the old KKT-weighted moment

  Z_lambda=sum_j lambda_j integral_Aj r_j(x)^2 dmu(x).

No comparison between Z_gamma and Z_lambda follows from equal row masses/shared source alone. The valid bound gamma_j<=mu is insufficient for gamma_j<=C lambda_j mu. This unresolved moment transfer is not paid by the reload estimate.

Finally B(4kappa)<=log(1+4kappa)/(2n), using 1-exp(-z)<=z. Hence the source coefficient is at most 4kappa log(1+4kappa)/(n eps), exactly as stated. This small coefficient does not itself establish a contracting potential: its potential moment must match the one used by the terminal/propagation argument.

## Random kappa', finite measures, and the single ledger

The proof needs only kappa'>0, which holds because eps>0, W>0, and the retained actual entropy optimum has Q'>0. It never assumes kappa' is in [7/2,4], or replaces kappa' by old kappa inside E'_grow/kappa'. The next-low selection is allowed to depend on the full action, including this random kappa'. Expectations keep that positive random denominator. For each fixed finite input these quantities are well-defined; no dimension/source-uniform lower bound on kappa' is asserted.

The same actual-action Pplus bound includes fill as a nonnegative credit, so allocating fill/2 to this reload is consistent if it is recorded once, leaving at least fill/2 of that particular reserve. The old-high payment similarly consumes at most 20/21 of its stated old-growth subset. The remaining next-growth charge E[E'_grow/kappa'] is a genuine NEW-stage debit and cannot be treated as free extra first-stage credit. If geometry/source normalization is used, then Etilde_grow=E'_grow/(1+kappa'), so converting this charge to the normalized next ledger requires its corresponding factor; it cannot be silently renamed as the normalized growth.

None of this proves a bound for K_H-Pplus, the receiver-overlap/return remainder, a nonzero-error propagation inequality, or a summable recursion. To use the estimate one still needs a correctly scaled potential inequality with this reload on its left side, a transfer/control of its Z_gamma moment, and a complete ledger accounting for the genuine next growth and every other use of fill/old growth. This is a newly justified payment of one adaptive reload term under the specified actual ownership rule.

## Local computation evidence

Ran the user's installed Python math environment with SymPy 1.14.0. It returned derivative

  -[(2kappa+1)u+kappa]/(u-kappa)^3,

the exact coefficient C_(4kappa)/2=2(4kappa+1)/(9kappa), and endpoint value 20/21 at kappa=7/2. These checks confirm scalar algebra. The measurable partition, pathwise adaptive elimination, source-marginal identities, and ledger scope are justified by the arguments above, not a numerical scan.
