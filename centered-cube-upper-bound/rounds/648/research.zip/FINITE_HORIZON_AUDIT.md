# Independent finite-horizon audit: exact balanced platform

Status: the stated exact-platform termination mechanism passes, conditional on the genuine per-step hypotheses below. The uniform bound is at most 3n balanced transitions after the first balanced state, hence at most 3n+1 plateau actions counted from an arbitrary initial state whose first action has S=D=E'_grow=0. If the initial state is already balanced, 3n actions suffice. This is not a quantitative near-platform or root-order budget.

I derived the source normalization, centrality recurrence, and horizon before reading the final extension of GLOBAL_FILL.md. The terminal laminarity argument there was then checked independently as recorded below. This audit changes only this file.

## Precise hypotheses and first balanced state

A state consists of an actual finite positive-owner entropy problem at the same fixed epsilon, cubes A_j=Q(y_j,s_j), disjoint actual owners I_j inside Q(y_j,s_j/a), positive v_j, actual optimizer lambda, and a genuine AC KKT source mu. Here a=32n, kappa=epsilon R lies in [7/2,4], and h=1+kappa. Every transition is the genuine simultaneous half-action from the original optimal allocation gamma_j, with gamma_j<=mu, followed by actual new ownership, deletion only of genuine zero owners, and actual entropy reoptimization alpha. Assume at each transition

  S=M-Q'=0,   D=W-RQ'=0,   E'_grow=0.

Then Q'=M, R'=R, kappa'=kappa, and on every retained new label u'_j=kappa. The latter follows from E'_grow being a sum of nonnegative terms with positive retained owner volumes. Thus one such transition from an arbitrary initial state produces a balanced successor. It does not prove that the original u_j were already equal to kappa.

There is no need to assume the entropy dual is unique. The following particular successor dual can be actively chosen at every exact transition:

  mu'=h mu.

Indeed S=0 gives L_alpha^A=1 mu-a.e. Since A_j subset C_j, new packing holds mu-a.e. by old mu being AC, and alpha_j>0 on retained labels,

  L_alpha^A<=L_alpha^C<=1,
  mu(C_j\A_j)=0 for every retained j,
  L_alpha^C=1 mu-a.e.

Now E'_grow=0 and D=0 give m'_j=h m_j. Consequently mu'(C_j)=h mu(C_j)=h m_j=m'_j, mu' is saturated on the actual new packing, and its mass hM=hQ'=M' is correct. Thus it is a valid actual new AC KKT dual, not merely a covering source.

Normalize all new geometry about one common fixed origin by T(x)=p x, p=h^(-1/n), and divide the pushed source mass by h. The normalized source is then exactly

  mu_next=T_pushforward(mu).

The actual optimizer alpha is unchanged, epsilon is unchanged, all receiver/owner volumes and cube volumes are divided by h, and the source mass remains M because S=0. The ratio R and kappa remain unchanged. Normalization is part of a legitimate scaled successor problem; it is not a legal motion of the old cubes or an assertion that the old physical source was stationary.

## Actual-anchor centrality recurrence

Here 'r A_j' means the CONCENTRIC core Q(y_j,r s_j), not the common-origin scaling T(A_j). Assume at a balanced state u_j=kappa for every current row and

  mu(A_j\Q(y_j,r s_j))=0 for all current j.            (C_r)

At r=1 this is automatic. Since gamma_j is supported in A_j and gamma_j<=mu, all actually drawn anchors satisfy

  |X_j-y_j|_infinity<=r s_j

on a common probability-one event for the finitely many rows. Put t=h^(1/n)=1/p, b=(t-1)/2, sigma=(t+1)/2. The genuine half-action has

  C_j=Q(c_j,t s_j),  c_j=sigma y_j-b X_j.

For a retained next row, no-invasion gives mu(C_j\A_j)=0. Thus for mu-almost every old source point x in C_j, condition C_r applies to x in A_j, and

  |x-c_j|_infinity
    <=|x-y_j|_infinity+b|X_j-y_j|_infinity
    <=sigma r s_j.

After common-origin normalization by p, the next cube has halfside s_j and center

  y_(next,j)=p c_j=q y_j-beta X_j,
  q=(1+p)/2, beta=(1-p)/2.

Its source is p_pushforward(mu). Equivalently the exact displacement identity is

  p x-y_(next,j)=p(x-y_j)+beta(X_j-y_j),

whose upper bound is (p+beta)r s_j=q r s_j. Hence the genuine normalized successor satisfies C_(qr) on every retained row.

The first transition from a possibly unbalanced state is used only to produce a balanced state; its normalized halfsides may differ rowwise from the original ones. Starting at that first successor, the recurrence is valid with r_0=1. Thereafter common u=kappa makes all current halfsides unchanged from one normalized state to the next on surviving labels. Deleted labels need no next centrality assertion.

## Uniform 3n balanced-transition bound

For p=h^(-1/n) in (0,1), h>=9/2, the geometric-series identity gives

  1-p^n=(1-p)(1+p+...+p^(n-1))<=n(1-p),
  n(1-p)>=1-1/h>=7/9.

Therefore q=1-(1-p)/2<=1-7/(18n), and for every positive integer n,

  q^(3n)<exp(-7/6)<1/3.

The final strict inequality has a short rational certificate:

  exp(7/6)>1+7/6+(7/6)^2/2+(7/6)^3/6
          =4033/1296>3.

Thus by the end of at most 3n balanced transitions, r<=1/3 (in fact strictly less). Number the original input state 0. A first exact-platform action gives balanced state 1, and 3n further balanced exact-platform actions would give state 3n+1 with terminal centrality. Accordingly a run of 3n+1 actions satisfying all exact hypotheses cannot persist from an arbitrary state 0 with R>1. A run of 3n such actions is already impossible when state 0 is balanced. The horizon ceiling ceil(log(3)/(-log q)) can be smaller; the claim audited here is the uniform integer bound, not an optimal horizon.

## Independent terminal laminarity and full-family volume bound

Assume a current balanced finite state with C_r and r<=1/3. Denote source sets by S_j=A_j modulo mu-null sets. If mu(A_j intersect A_k)>0 and s_j>=s_k, choose a point in their two central cores outside the finitely many exceptional null sets. Then

  |y_j-y_k|_infinity<=r(s_j+s_k).

For mu-almost every z in A_k, centrality gives

  |z-y_j|_infinity
    <=r s_k+r(s_j+s_k)
    =r s_j+2r s_k<=3r s_j<=s_j.

Hence S_k subset S_j modulo mu-null sets. In particular the finite source-set family is laminar: any positive-measure intersection forces one set to contain the other.

Identify equal source sets and choose distinct maximal roots p. Their source sets are pairwise mu-disjoint and cover mu, because the current actual KKT saturation puts all mu mass in the current cube union. For any row k below root p,

  mu(A_k)<=mu(A_p),  mu(A_j)=h(2s_j)^n,

so s_k<=s_p. Since mu(A_k)>0 and its source set is contained in the root's, their source intersection has positive mass and the central-point estimate yields

  |y_k-y_p|_infinity<=r(s_k+s_p)<=2r s_p.

Therefore the ENTIRE actual receiver B_k=Q(y_k,s_k/a), not just its source, is contained in

  Q(y_p,(2r+1/a)s_p).

The current actual ownership covers the complete current receiver union; hence

  V<=sum_p (2r+1/a)^n d_p.

The disjoint root source masses give h sum_p d_p=M=h Q, and consequently

  V<=(2r+1/a)^n Q,
  R<=(2r+1/a)^n<1.

The strict inequality uses 2r+1/a<=2/3+1/32=67/96<1 for n>=1. It contradicts the same R>1 preserved by every exact D=0 transition. This argument is global in label count, source concentration, scales, and spatial diameter. It uses positive source sets and actual receiver coverage, without a lower density bound or a minimum label weight.

## Deletion, null sets, adaptivity, and recovery scope

Only actual zero-owner rows may be deleted at a transition. At S=0, retained old A_j still cover all old source mass because L_alpha^A=1 mu-a.e.; deleting an old row does not silently discard source. Retained new receiver owners cover the complete new union, so successor R=R' is the true complete-union ratio. The terminal lemma uses the current retained family, not all historical rows. Historical overlap/return costs have not been paid by deleting labels in this argument.

All conclusions use finitely many labels and at most 3n+1 steps. At each stage, the old AC source makes current cube boundaries null; the genuine assignments gamma_j<=mu make core membership valid for all actually drawn anchors simultaneously. Uniform nonzero homotheties preserve AC, packing incidences, contact/null-boundary status, and positive owner volumes. The explicitly chosen next dual remains AC and its moments/saturation were verified above.

The source/optimizer may depend on earlier outcomes. For any admissible measurable finite execution, conditional on the current state the anchor-core event has probability one. Finite induction therefore gives one common probability-one event through this horizon. On that event the conclusions hold for every realized sequence satisfying the exact equalities. No assertion of a positive-probability plateau event is needed. If measurable selection for a broader stochastic recursion has not been established, the deterministic per-trajectory implication still holds for any finite execution meeting these conditional full-measure events; this audit does not supply a new selection theorem.

There is no ghost-source adaptivity substitution here. Anchor centrality is inherited from each pre-step actual source and assignment. The S=0 no-invasion identity is derived for the actual outcome alpha_Z, and the next source is chosen explicitly as h mu. Thus the known positive-S signed-Fubini gap is not being used as if solved.

The construction stays within actual finite entropy problems with the SAME epsilon and at most the original number of labels. It assumes the original legal half-action and inherited actual ownership/recovery permissions; it does not internalize arbitrary boundary actions or equate tagged-limit moments with physical moments. Passing to an attained extremizer or a nonzero-error compactness limit would still need the inherited recovery work. No such passage is part of this exact finite implication.

## Scope of the conclusion and local computation evidence

The exact zero platform cannot persist through the stated O(n) horizon. This does not prove a uniform positive source drop, a quantitative lower bound for the accumulated forcing, or a budget of order sqrt(n). Paying O(M) at each of O(n) steps still costs O(n M); nonzero source tails and square-root TV errors have no proved summable propagation here. This audit does not certify the general joint target.

Local verification used the installed math Python environment with SymPy 1.14.0, without a dimension/label scan. The actual normalized displacement identity had exact residual zero. The exponential comparison was checked as the exact rational lower bound 4033/1296, exceeding 3 by 145/1296. The terminal base upper bound was 67/96. These are algebra/arithmetic checks supporting the displayed analytic proof, not numerical evidence for a nonzero-error recursion.
