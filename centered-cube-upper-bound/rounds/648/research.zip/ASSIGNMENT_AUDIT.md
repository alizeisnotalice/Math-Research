# R648 independent audit: replacing the source-assignment objective

## Decisive conclusion

**The proposed new assignment is legitimate on every genuine finite state under the inherited contract.** Replacing the R646–647 maximization of the physical quadratic `F_j` by minimization of normalized squared `L_infinity` distance does not invalidate the complete `D` ledger, signed return/merge score, low incoming payment, or actual-alpha far-source hinge. Those results are pathwise consequences of a legal half action and the unchanged old source/optimizer. They do not use `F`-optimality.

The old pairwise `Delta >= 0` and its nonnegative Euclidean coercivity conclusion must cease to be invoked. The new assignment provides a different variational inequality; it does not inherit that sign. The complete global sufficient target remains the R647 target, with expectation now taken under the **newly fixed product law**. No proof of that target or of a root-order bound is supplied here.

Two updates are required in the R648 text read for this audit:

1. Replace the statement that the optimization objective is inherited from R646–647 by the explicit new minimization and feasibility conditions below.
2. For the **normalized** cost used here, common geometric normalization and source-mass normalization multiply the assignment objective by `g^{-1}`, not `g^{-1-2/n}`. The latter was appropriate to the old unnormalized physical quadratic. Optimality is preserved in either case, but the factor must match the chosen objective.

This audit owns only `/tmp/ccu_r648/ASSIGNMENT_AUDIT.md`. Other workers are active; no other file, Git state, or PDF was modified. Source snapshots read were:

- R645 REPORT: 19627 bytes, SHA-256 `34268b57bf0258a86eee68231f6f8924ba4766487b032376d19f4b76b1667aae`.
- R647 REPORT: 26912 bytes, SHA-256 `a3d7aa053f960175a6675cf7e376ad3ec9af2f9064a408da6f865f6a1e6d4910`.
- R648 REPORT at audit time: 15732 bytes, SHA-256 `dc6b82ae826a88c65f02b61afb9910aa90b5f8aefa976274648744490bfdd2f7`.

The proof below audits the proposed new contract, rather than treating an unchanged old-objective sentence in this R648 snapshot as if it already stated the new contract.

## 1. Exact assignment and existence

For a fixed genuine finite old state, define
\[
\psi_j(x)=\frac{\|x-y_j\|_\infty^2}{s_j^2}\quad (x\in A_j),
\]
and choose one minimizer of
\[
Z_\gamma:=\sum_j\int_{A_j}\psi_j\,d\gamma_j
\]
over
\[
\gamma_j\ge0,\qquad \sum_j\gamma_j=\mu,\qquad
\gamma_j(A_j^c)=0,\qquad \|\gamma_j\|=a_j=\lambda_jm_j.
\tag{A}
\]
The `A_j` in the integral is its integration domain, not an extra multiplier. `mu`, `lambda`, `a_j`, and all ownership volumes are frozen before this optimization. The original input `f dx` is not substituted for `mu`.

The benchmark
\[
\gamma_j^0=\lambda_j1_{A_j}\mu
\]
is feasible: its total source is `L_lambda mu=mu`, it is supported on `A_j`, and its mass is `lambda_j mu(A_j)=a_j`. Hence the feasible class is nonempty. Also `gamma_j <= mu` for every feasible assignment, so each is AC when `mu` is AC.

For an existence proof, write `gamma_j=theta_j mu`. The feasible conditions become
\[
0\le\theta_j\le1,\quad \sum_j\theta_j=1\ \mu\text{-a.e.},\quad
\theta_j1_{A_j^c}=0,\quad\int\theta_jd\mu=a_j.
\]
These are weak-star closed constraints in a finite product of unit balls of `L_infinity(mu)`: each equality is tested against `L^1(mu)` functions. That product is weak-star compact. Extend `psi_j 1_Aj` by zero; it is a bounded `L^1(mu)` test function, since `0<=psi_j<=1` on `A_j` and `mu` is finite. Thus the objective is weak-star continuous and attains a minimum. Finite bounded old cubes provide the inherited compact-support setting; no minimizing geometry, convexity of the outer problem, or minimax exchange is needed.

The exact benchmark inequality is
\[
0\le Z_\gamma\le Z_\lambda
:=\sum_j\lambda_j\int_{A_j}\psi_j\,d\mu\le M.
\tag{B}
\]
The last inequality uses `psi_j<=1` and `L_lambda=1` on the actual source. It is a legal source-center budget, not a payment for the adaptive receiver reload or for `D`.

Choose the minimizer once, before drawing anchors; independent draws `X_j ~ gamma_j/a_j` define one fixed product law. Per-state existence is enough for the one-step finite statement. A claim about a globally measurable policy across arbitrary states would require a measurable selection argument or an explicit selection rule; one must not silently substitute that stronger claim for fixed-state existence.

## 2. The resulting half action remains strictly legal

The same formulas give
\[
z_j=(y_j-X_j)/(2s_j),\quad \|z_j\|_\infty\le1/2<1,
\]
\[
c_j=y_j+(\rho_j-s_j)z_j=\sigma_jy_j-b_jX_j,
\quad\rho_j=t_js_j.
\]
Consequently `A_j subset C_j`, and the image of every old piece is
\[
E_j=c_j+t_j(I_j-y_j)=t_jI_j-b_j(y_j+X_j)\subset B'_j,
\quad |E_j|=(1+u_j)v_j.
\]
This uses only `X_j in A_j`; the optimizing objective does not enter. New ownership, zero-owner deletion, actual `alpha`, and all complete old transport labels must then be computed for this same realized action. Changing the sampling law changes their realized values; it does not allow values from an old `F`-optimal realization to be retained.

## 3. Complete ledger and signed score require no F-optimality

The old harmonic identity, `RM=(1+kappa)V`, and physical image volumes give, for each legal realization,
\[
E=\sum_j(1+u_j)v_j-(1+\kappa)V,
\quad W=\sum_j(1+u_j)v_j-O+F.
\]
Hence exactly
\[
D=W-RQ'=E-O+F+R(M-Q').
\tag{C}
\]
Neither `gamma` nor its objective occurs in this derivation.

Retain the unchanged all-old definitions
\[
q_K=z_K\sum_{j\in K}\lambda_j1_{E_j}/\ell_j,
\quad D_k=\sum_{K\ni k}q_K,
\quad s=\max_{k:y\in C_k}D_k,
\]
and the original integrated return maxima `r_K`. They satisfy `int q_K=z_K`, `int D_k=m_k`, and `Q'<=B_*=min(B,M)`. The complete source construction uses old `mu` and old `lambda`; it does not use the partition `gamma` as a replacement transport source.

Selecting the same integrated return maximizer and pointwise supply maximizer yields the exact signed `B-M` identity from R647. In particular,
\[
\mathcal K=2O+R(B-M)_+
=\epsilon^{-1}\sum_ja_j\Xi_j,
\quad \Xi_j=2u_jf_j+\kappa\eta\bar s_j.
\]
Every incoming summand stays signed and `eta=1_{B>M}` remains common to the action. No exchange inequality enters. Fubini under the new fixed product law is valid for these finite bounded scores; when `gamma_j=theta_j mu`, its conditional integral has the same `theta_j` structure, now with the new assignment. Adaptive ownership, return choices, and `alpha` remain inside the same integrand.

The low estimate only uses `Xi_j<=2u_j+kappa` and the scalar certificate
\[
(u-\kappa)^2-(1+u)(2u+\kappa+3/2)
=(\kappa-7/2)(\kappa+5/2-3u)+(1/2-u)(u+29/2)\ge0.
\]
Therefore, still pathwise,
\[
\mathcal K_L\le E_L-3A_L/(2\epsilon).
\tag{D}
\]
All low target rows remain in the transport and geometry. The argument concerns original incoming labels, with no assumption on how often the new assignment chooses particular anchors.

## 4. Actual-alpha hinge survives unchanged

On each `E_j`, the unchanged old packet relations imply
\[
D_j\ge\lambda_jm_j/\ell_j=\epsilon/u_j.
\]
Since `E_j subset C_j`, this proves `s>=h/R` directly from the continuous part, regardless of the assignment objective. The inherited bound `H_Z>=Lambda V-O` is also a physical weighted-overlap inequality, independent of the sampling law.

Actual retained `alpha`, extended by zero, obeys new a.e. packing. Each positive actual AC old packet has a positive-volume common old intersection contained in the corresponding common new intersection. Thus `sum_{k in K} alpha_k<=1` and `U_ret>=0`. With `w=sum alpha_k 1_B'k` and the genuine receiver maximum `s_rx`, one has `0<=w<=L_alpha<=1` and `0<=s_rx<=s`. Exactly as in R647,
\[
B-Q'=\int\left(s-\sum_k\alpha_kD_k1_{C_k}\right)+U_{\rm ret},
\]
\[
s-\sum_k\alpha_kD_k1_{C_k}
\ge(h/R)(1-L_\alpha)+w(s-s_{\rm rx}).
\]
It follows that
\[
R(B_*-Q')\ge A_Z
:={R\over R-1}[H_Z-B_*-R\delta_B+RJ]_+.
\tag{E}
\]
Every step uses a legal action, actual packing, and the unchanged old source. `F`-optimality is absent. The complete credit
\[
P^+=F+RT+A_Z-(\Lambda V-O-M-R\delta_B)
\]
remains nonnegative and may be used once. The absence of a uniform lower bound for `w` is unaffected by the new objective, so a general unweighted cut is still not automatically paid.

Combining (C)–(E) gives the same pathwise ledger
\[
D\ge E_H+\Lambda V-M-\mathcal K_H+{3A_L\over2\epsilon}+P^+.
\tag{F}
\]

## 5. What is lost, and what auxiliary results remain

The new minimizer does **not** generally maximize the old `sum int F_j dgamma_j`. Therefore the old cross-eligible inequality
\[
F_j(X_j)+F_k(X_k)-F_j(X_k)-F_k(X_j)\ge0
\]
is unavailable. The old expanded identity for `|c_j-c_k|_2^2` is still an algebraic identity, but its `Delta` term need not be nonnegative. One cannot drop it to obtain separate bounds on `|A_jk|_2^2` or `|X_j-X_k|_2^2`. Likewise the old `F`-cost-gap equality remains an equality for a feasible average exchange, but its claimed nonnegative sign cannot be carried over.

Minimization would instead give the local cross-eligible inequality with the **opposite minimizing sign for the new costs**:
\[
\psi_j(X_j)+\psi_k(X_k)-\psi_j(X_k)-\psi_k(X_j)\le0
\]
a.e. by the same equal-mass exchange argument. This has no automatic equivalence to the old Euclidean coercivity. It is not needed to justify (C)–(F).

The measurable physical matching construction itself, its row capacities, and the feasibility of its averaged exchanged assignment need no old cost sign. The oriented product child-price budget likewise only uses support, old saturation at anchors (`gamma_k<=mu`), radius order, and disjoint old owned pieces; it can remain as an auxiliary statement. Its unproved bridge to physical endpoint prices remains unproved. These observations do not restore the lost old energy conclusion.

## 6. R645 finite entrance and recovery allow the choice, with the same limits

I read the R645 complete-object/goal section, its explicit cutoff and ownership-continuity limits, and its strict-interior tagged-recovery theorem rather than inferring an entrance permission from later summaries.

The R645 target is uniform over legal complete canonical actions and actual successors. Its strict-interior recovery theorem assumes a selected canonical action with every `|z_ji|<1`, then a strictly positive actual distribution on the final retained labels. It does **not** require `F`-optimality, a particular source-assignment objective, continuity of a minimizing assignment across old input states, or preservation of an entire product sampling law.

The new half action satisfies the strict interior requirement with the fixed margin `|z_ji|<=1/2`. Thus on genuine finite states this assignment is an admissible way to choose the action. If the eventual expectation estimate supplies an action with a strict favorable margin, that chosen action can be frozen, generically perturbed, and recovered using the original R645 permissions and costs. The perturbation need not remain the exact anchor image of the minimizing assignment; the R645 bridge transfers its actual geometric output and strict margin.

The limitations are essential:

- R645 does not certify arbitrary old tagged-limit sources as genuine AC sources satisfying the actual old moments and saturation. Its own proof explicitly warns that atomic tag packets may be counted by extra contact rows. One cannot run this new assignment on a fictitious AC old source obtained merely by forgetting that warning.
- Recovery of a chosen strict-margin action does not prove that optimal `gamma` or its product law converges along approximating inputs, nor that exact zero-margin equalities recover with no loss.
- No new nondegenerate compactness, attained outer maximum, critical-endpoint restoration, or jump payment is obtained by changing the assignment objective.
- Initial, contact, cutoff/deletion, scale, and terminal obligations remain exactly the inherited ones. The final root bound is not certified by the assignment's legality.

## 7. Full global objective after the replacement

Let `L_n=sqrt(n) log^A(n+2)` with fixed exponent and uniform constants `c>0,C<infinity`. Under the newly chosen minimizing assignment, the unproved sufficient global one-step target is still
\[
\mathbb E_{\prod_j\gamma_j/a_j}[\mathcal K_H-P^+]
\le E_H+(\Lambda-c)V+{3A_L\over2\epsilon}+(CL_n-1)M.
\tag{G}
\]
All realized terms must come from the same new action. By (F), (G) implies `E D>=cV-CL_n M`, hence at least one legal action attains that bound. The inherited general-input restoration remains an additional obligation. Reusing an expectation computed under the old `F`-optimal law would be invalid.

With the exact low slack
\[
S_L=E_L-3A_L/(2\epsilon)-\mathcal K_L\ge0,
\]
(G) is exactly equivalent to
\[
\mathbb E[W+RT+A_Z-S_L]
\ge(1+\kappa+c)V-CL_nM.
\tag{H}
\]
The deduction uses `O-F-E=(1+kappa)V-W`, not a positivity assumption on that signed quantity. This equivalence is algebraic and does not depend on the assignment objective. Thus the new center budget (B) is not an additional term on the right side of (F); any future use must prove its connection to (G) or (H).

## 8. Correct normalization and actual local check

For a common scaling `T_g(x)=g^{-1/n}x` and source scaling `g^{-1}(T_g)_#mu`, transport each feasible assignment to `g^{-1}(T_g)_#gamma_j`. The scaled center and half side are `g^{-1/n}y_j` and `g^{-1/n}s_j`, so
\[
\frac{\|T_gx-T_gy_j\|_\infty^2}{(g^{-1/n}s_j)^2}
=\frac{\|x-y_j\|_\infty^2}{s_j^2}.
\]
Only the mass scales. Consequently `Z_next=g^{-1} Z`, and the bijection of feasible assignments preserves minimizers. This is the needed correction to the old `g^{-1-2/n}` sentence.

I actually ran the installed math Python at `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` (Python 3.12.14, SymPy 1.14.0) on three exact symbolic residuals: the full `D` ledger, the equivalence (G)/(H), and cancellation of the common geometric factor in the normalized squared price. All three residuals were zero and the process reported `PASS 3 exact symbolic identities`. No new numerical evidence for (G), an adaptive reload bound, or the general root bound was produced. Existence, action legality, packet provenance, and recovery limits were checked by the arguments above.

**Stop point:** the new assignment is a valid replacement for the source-selection rule, with the complete target retained and the old pair-coercivity removed. The new global budget (G)/(H), adaptive alpha reload, and all inherited general-input costs remain open.
