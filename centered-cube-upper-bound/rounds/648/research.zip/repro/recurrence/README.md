# Plateau recurrence: proof and Arb checks

For n≥1 and 9/2≤g≤5 set x=log(g)/n, q=(1+e^(−x))/2=e^(−x/2)cosh(x/2). Let a=log(9/2), b=log 5, and c=a/[2(1+b)]. As e^x≥1+x, x/(1+x)≤1−e^(−x)≤x. Therefore

    c ≤ n(1−q) ≤ b/2,
    c ≤ n(1−q²) ≤ b,
    c ≤ n(−log q) ≤ b.

For the last line use 1−q≤−log q≤(1−q)/q≤2(1−q), since q≥1/2. Thus relaxation time 1/(−log q) is Θ(n), and the infinite impulse ℓ² norm 1/√(1−q²) is Θ(√n), uniformly throughout the full parameter range. Indeed the stronger n→∞ limits are n(1−q)→(log g)/2, n(1−q²)→log g and n(−log q)→(log g)/2, uniformly in g by the same Taylor expansions with bounded log g.

For a finite horizon H, the exact squared impulse norm is Σ_{j=0}^{H−1}q^{2j}=(1−q^{2H})/(1−q²). Write y=2H(−log q); from the preceding inequalities and y/(1+y)≤1−e^(−y)≤min(y,1), the norm is Θ(√min(H,n)) uniformly for H≥1. In the recurrence z_{t+1}≤qz_t+b_t, iteration gives z_H≤q^H z_0+Σ_{j=0}^{H−1}q^j b_{H−1−j}. If z_0>0, reducing the homogeneous term below a specified threshold η>0 takes H=max(0,ceil(log(z_0/η)/(−log q))); the input-to-threshold ratio and finite horizon must remain explicit. This kernel bound alone assumes neither quadratic summability of b nor a bound on its convolution.

# Computation

Commands (actual interpreter and three separate stages):

    /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r648/recurrence_numeric/check.py initial
    /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r648/recurrence_numeric/check.py boundary
    /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r648/recurrence_numeric/check.py expanded

The captured outward ball results are in initial.jsonl, boundary.jsonl, and expanded.jsonl. They cover all seven requested n values, both endpoints and the ball [4.5,5]. CPython 3.12.14, python-flint 0.9.0, Arb precision 256 bits; the JSONL records print balls using `arb.str(30, more=True)`. Arb documentation describes midpoint-radius containment, with outward rounding; no claim is made beyond the actual installed library and operations run. The cancellation-safe expression t=−expm1(−x)/2 computes 1−q directly, and log1p(−t) computes log q. Endpoint decimal output is also a ball, not an exact decimal. Elapsed computation seconds: initial 0.004651, boundary 0.000334, expanded 0.000360; taken 2026-10-29 05:17 UTC. Results support normalization only, not the preceding global proof.

SHA-256: PLAN.md `723f4b5fb8929ff8d3bba8dc93cf42becc2a3f9b6114a6792d5230d32af0e2ba`; check.py `aeeaa4736289d6ff42d30d297cd3f0a6d06c7aeb6e4b0bc4e3a69521e8e33b0c`; initial.jsonl `cc3e058d5f0a766154de7988e8f92cbb5f132cff609a4844e109a96e677ad9fa`; boundary.jsonl `c9d722b12c6e0d7e9e88d649217f54e293666fa9f86f5973f542993a23146d5e`; expanded.jsonl `255870a50b0289b18b71b7bf1598af676a3593437123908ca8a8ee90645a4ad7`.
