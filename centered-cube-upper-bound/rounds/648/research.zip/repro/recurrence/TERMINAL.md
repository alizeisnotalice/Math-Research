# Robust terminal inequalities

For κ>0, u>0, ζ≥0, put f=(u−κ)²/u. Symbolic differentiation gives f′=(u−κ)(u+κ)/u², so f decreases on (0,κ] and increases on [κ,∞). For 0≤ζ<1 the two boundary values are κζ²/(1−ζ) and κζ²/(1+ζ), whose difference is 2κζ³/(1−ζ²)≥0. Hence outside [κ(1−ζ),κ(1+ζ)], f≥κζ²/(1+ζ). For ζ≥1 the lower branch is empty for u>0 and the upper boundary gives the same result. The result is valid also at either boundary.

For n≥1, κ∈[7/2,4], let g=1+κ and t=1/n. Convexity of t↦g^(−t) and the secant on [0,1] give g^(−1/n)≤1−(1−1/g)/n≤1−7/(9n). Thus q≤1−7/(18n). Since log(1−v)<−v for 0<v<1, q^(3n)≤(1−7/(18n))^(3n)<e^(−7/6)<1/3. The last strict inequality follows from e^(7/6)>Σ_{j=0}³(7/6)^j/j!=4033/1296>3. These are general proofs, independent of the finite numerical checks.

# Reproducibility

Run the following using the exact requested interpreter:

    /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r648/recurrence_numeric/terminal_check.py initial
    /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r648/recurrence_numeric/terminal_check.py boundary
    /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r648/recurrence_numeric/terminal_check.py expanded

Initial stage: n=1,2,7, κ endpoints, ζ=1/2 (6 cases). Boundary: same n, both κ endpoints, ζ=10⁻¹² and 1−10⁻¹² (12). Expanded: n=10³,10⁶,10¹² with both κ endpoints and both ζ values (12). JSONL contains all outward balls, including the q-bound gap, q^(3n), terminal bound and both boundary differences. Equality at n=1, κ=7/2 is proved algebraically, and its computed gap ball contains zero. Upper-boundary equality is proven symbolically; subtraction of overlapping balls encloses zero. All other tested q gaps and q^(3n) margins were strictly positive as intervals.

Actual environment: CPython 3.12.14, SymPy 1.14.0, python-flint 0.9.0, Arb precision 256 bits; `expm1` and `log1p` avoid cancellation. Captured on 2026-10-29 05:29 UTC. Script-reported stage times were 0.004466, 0.001294 and 0.001162 seconds, respectively. Finite interval evidence does not establish the general inequalities.

SHA-256: terminal_check.py `7f4f1e4c5ba3bfee29577a79c91922bf87a895937d945232dabde33aff3fcbf8`; terminal_initial.jsonl `34184442394e06acbd2288cca800ffda5b0b78fe920b2bc3fd83a4e1c0e2d0d2`; terminal_boundary.jsonl `ff71f7dfbdf2eacd7597bc1086045a79206eb25589ace2de275f35b5ed6b4160`; terminal_expanded.jsonl `1dfeb8ec2da378c58b94c0ecf034526bacada81b09d20869395808dd34d838b2`.
