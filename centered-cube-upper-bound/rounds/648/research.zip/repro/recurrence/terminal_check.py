import sys, time, json, platform
from flint import arb, ctx
import flint, sympy as sp
ctx.prec=256
stages={'initial':[1,2,7], 'boundary':[1,2,7], 'expanded':[1000,10**6,10**12]}
u,k,z=sp.symbols('u k z', positive=True)
f=(u-k)**2/u
fp=sp.factor(sp.diff(f,u))
lo=sp.factor(f.subs(u,k*(1-z)))
hi=sp.factor(f.subs(u,k*(1+z)))
assert fp==(u-k)*(u+k)/u**2
assert sp.simplify(lo-hi-2*k*z**3/(1-z**2))==0
assert sp.simplify(hi-k*z**2/(1+z))==0
assert sum(sp.Rational(7,6)**j/sp.factorial(j) for j in range(4))>3

def ball(v): return v.str(24,more=True)
def show(n, ks, zs):
    K=arb(ks); Z=arb(zs); N=arb(n)
    x=(1+K).log()/N
    t=-(-x).expm1()/2
    q=1-t
    gap=t-arb(7)/(18*N)
    power=(3*N*(-t).log1p()).exp()
    target=K*Z**2/(1+Z)
    low=K*Z**2/(1-Z)
    high=K*Z**2/(1+Z)
    lowgap=low-target
    # Equality at n=1, κ=7/2 is proven exactly; all others strictly positive.
    if n==1 and ks=='7/2': assert gap.contains(0)
    else: assert gap>0
    assert arb(1)/3-power>0 and lowgap>0 and high.contains(target)
    return {'n':n,'kappa':ks,'zeta':zs,'q':ball(q),'q_gap':ball(gap),'q_to_3n':ball(power),'terminal_bound':ball(target),'lower_boundary_excess':ball(lowgap),'upper_boundary_difference':ball(high-target)}

if __name__=='__main__':
 stage=sys.argv[1]; start=time.perf_counter()
 print(json.dumps({'stage':stage,'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec,'f_prime':str(fp),'lower_minus_upper':str(sp.factor(lo-hi)),'exp_series_order3':str(sum(sp.Rational(7,6)**j/sp.factorial(j) for j in range(4)))}))
 kappas=['7/2','4']; zetas=['1/2'] if stage=='initial' else ['1/1000000000000','999999999999/1000000000000']
 for n in stages[stage]:
  for ks in kappas:
   for zs in zetas: print(json.dumps(show(n,ks,zs)))
 print(json.dumps({'cases':len(stages[stage])*len(kappas)*len(zetas),'elapsed_seconds':time.perf_counter()-start}))
