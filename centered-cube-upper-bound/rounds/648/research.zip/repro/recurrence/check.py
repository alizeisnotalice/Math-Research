import sys, time, json, platform
from flint import arb, ctx
import flint
ctx.prec=256
stages={'initial':[1,2,7], 'boundary':[32,1000], 'expanded':[10**6,10**12]}
def calc(n, gs):
    g=arb(gs); x=g.log()/n
    t=-(-x).expm1()/2  # 1-q without cancellation
    q=1-t
    a=n*t; b=n*t*(2-t)
    c=b.rsqrt(); d=1/(n*(-(-t).log1p()))
    assert t>0 and b>0 and d>0
    return {k:v.str(30,more=True) for k,v in {'q':q,'n(1-q)':a,'n(1-q^2)':b,'1/sqrt(n(1-q^2))':c,'1/(n(-log q))':d}.items()}
if __name__=='__main__':
    stage=sys.argv[1]; started=time.perf_counter()
    print(json.dumps({'stage':stage,'python':platform.python_version(),'python_flint':flint.__version__,'arb_precision_bits':ctx.prec}))
    for n in stages[stage]:
        for label,g in [('9/2','9/2'),('5','5'),('[9/2,5]','4.75 +/- 0.25')]:
            print(json.dumps({'n':n,'g':label,**calc(n,g)}))
    print(json.dumps({'elapsed_seconds':time.perf_counter()-started}))
