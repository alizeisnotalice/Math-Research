"""Exact identities and bounded interval checks; no assertion of full recurrence."""
import json, platform
import sympy as s
import flint
from flint import arb, ctx
ctx.prec=256
k,u,t,e,a,v,M,Q,W,O,F,R,EH,EL,KL,T,AZ,Lam,V,c,C=s.symbols('k u t e a v M Q W O F R EH EL KL T AZ Lam V c C', positive=True)
delta=s.symbols('delta', nonnegative=True)
Pplus=F+R*T+AZ-(Lam*V-O-M-R*delta)
KH=2*O+R*delta-KL
SL=EL-3*a/(2*e)-KL
left=KH-Pplus-(EH+(Lam-c)*V+3*a/(2*e)+(C-1)*M)
cap=(1+k+c)*V-C*M-(W+R*T+AZ-SL)
residuals={
 'target_capacity':s.expand((left-cap).subs(W,EH+EL+(1+k)*V-O+F)),
 'variance_price':s.simplify(v*(u-k)**2/u-(u*(1+u)*v/((u-k)**2))*(u-k)**4/(u*u*(1+u))),
 'AplusB':s.simplify((t+1)/(2*t*t)+(1-t**-2)/4-((t+1)/(2*t))**2),
 'reload_high_coefficient':s.simplify((4*k)*(1+4*k)/(2*(4*k-k)**2)-(s.Rational(8,9)+s.Rational(2,9)/k)),
 'reload_endpoint':s.Rational(8,9)+s.Rational(2,9)/(s.Rational(7,2))-s.Rational(20,21),
}
A,B=s.symbols('A B',positive=True)
eta=s.sqrt(A)/(s.sqrt(A)+s.sqrt(B))
residuals['eta_optimization']=s.simplify(A/eta+B/(1-eta)-(s.sqrt(A)+s.sqrt(B))**2)
assert all(s.simplify(x)==0 for x in residuals.values()),residuals
constant=arb(7)/9*(1-arb(5).sqrt()/4)**2/4096
assert constant>arb('0.00003692659718833376')
assert constant<arb('0.00003692659718833378')
print(json.dumps({'python':platform.python_version(),'sympy':s.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec,'zero_residuals':list(residuals),'terminal_constant':constant.str(35,more=True),'scope':'Exact algebra and displayed scalar interval only; no general upper bound or error summability certified.'},ensure_ascii=False))
