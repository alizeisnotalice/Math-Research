# R648 实际计算与复现

指定解释器：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。
实际环境 Python 3.12.14、SymPy 1.14.0、python-flint 0.9.0；Arb精度256位。

在解压归档根目录使用该解释器运行：

```
python -B repro/check_algebra.py
python -B repro/recurrence/check.py initial
python -B repro/recurrence/check.py boundary
python -B repro/recurrence/check.py expanded
python -B repro/recurrence/terminal_check.py initial
python -B repro/recurrence/terminal_check.py boundary
python -B repro/recurrence/terminal_check.py expanded
```

这里的 `python` 应替换为上述完整解释器路径。`verify_archive.py` 会核对清单、LaTeX结构并运行这七条有界命令；不编译PDF。

- `check_algebra.py`：六项精确符号恒等式，及硬分支中心矩阈值的Arb区间。实际输出在 `algebra_result.json`。
- `recurrence/check.py`：初探、端点压力与扩大维数三阶段，共七个维数、每维两个参数端点和整个参数球，共21条结果。对象是标量递推系数，不是原连续方体模型。
- `recurrence/terminal_check.py`：初探6、边界12、扩大范围12，共30个样例；包含精确等号和接近零/一的分层参数。解析证明与实际输出见同目录 `TERMINAL.md` 及JSONL。
- Arb输出为外包球，非精确小数；时间字段允许复现时不同。

一般的O(n)时间和平方响应核的Theta(sqrt n)阶来自REPORT及数值README中的解析证明。有限参数通过不证明真实强迫平方可和，不证明一般弱型上界。没有新有限凸优化或MATLAB结果，本轮不以空转计算填满CPU。
