# R648 final ledger and probability audit

**Result: PASS within the assigned scope. No unresolved ledger/probability issue was found in the bound report snapshot.** The full global target remains unproved, as the report states.

Bound source: `/tmp/ccu_r648_final/REPORT.tex`

SHA-256: `52f4642140f03d62ee242aac3e8623eba5030229d2ba35e0a70e22e7ba0e75e4`

Scope: sections 1, 2, 5, 7 and the final gap list; cross-check of their connection to the newly selected center-cost assignment. Assignment existence/legality is independently covered by `/tmp/ccu_r648/ASSIGNMENT_AUDIT.md`. This audit does not recertify the geometry section or the saved Arb computation record. Earlier passed symbolic computations were not rerun.

Two clarity issues were reported before completion and corrected by the author in this bound snapshot: the three defining properties of the genuine next center-cost assignment gamma'_k are now explicit; old scalar growth is denoted e_j and defined, avoiding the image-set symbol E_j. The exact-platform theorem and abstract now state the almost-sure quantifier. No audit-owned changes were made to REPORT.tex or other workers' files.

## 1. Complete target and low-input debit

The contract permits merely disjoint positive old pieces I_j subset B_j. The audited ledger uses V=sum_j v_j and does not require them to cover the old receiver union. New ownership does cover the complete new receiver union. All old image labels remain in O and F even if their next owner is deleted.

The identity

  D=E-O+F+R(M-Q')

uses sum_j ell_j=E+(1+kappa)V and RM=(1+kappa)V. These remain valid with the report's weaker old-owner contract.

The full-target equivalence is exact. Substituting the definitions gives

  K_H-Pplus=O-F-RT-A_Z+Lambda V-M-K_L
           =E_H+(1+kappa+Lambda)V-M+3A_L/(2eps)
             +S_L-W-RT-A_Z.

Consequently target <= its stated right side is equivalent to

  E[W+RT+A_Z-S_L]>=(1+kappa+c)V-C L_n M.

The sign of the low-input slack S_L is correct: it is a debit in the capacity form. The old low growth has not become a second budget. J appears only inside the original actual-alpha positive-part A_Z; no second copy is added as fresh source credit. The identity D=RS-[(1+kappa)V-W] does not bound old or new growth from small D,S, and the report explicitly preserves that gap.

## 2. One fixed new assignment law and one actual ownership optimizer

The report now selects the center-moment minimizing feasible gamma before the independent product draw. It explicitly abandons the old physical F_j maximizing property, its Delta>=0 sign and the resulting Euclidean coercivity. Those lost conclusions are not invoked in the audited sections.

As checked independently in ASSIGNMENT_AUDIT.md, the complete D/return ledger, low-input payment and actual-alpha hinge require feasibility/support of gamma and legality of the half action, rather than old F-optimality. Thus the full sufficient target can be retained with expectation under the newly fixed product law. It would be invalid to import an expectation from the old F-optimal law, and the report does not do so.

Section 7 specifies E-priority actual ownership, deletes exactly genuine zero owners, and reoptimizes alpha. All earlier alpha-dependent quantities are understood for this same ownership/outcome. The report explicitly excludes mixing old and new optimizers. E-priority gives p_j<=ell_j+f_j^own and sum_j f_j^own=F, since union E points are assigned only to an E-covering label. This is an admissible actual finite successor. No E-priority selector continuity through arbitrary tagged-limit ownership sets is asserted; inherited strict-margin recovery remains a separate obligation.

## 3. Source coupling, total variation and adaptive quantifiers

For the retained positive-owner labels, the source coupling has old marginal L_alpha^A mu<=mu, because A_k subset C_k and actual new packing holds mu-a.e. by old-source AC. Its mass is sum alpha_k m_k=Q', leaving old source mass S.

The labeled output and bar-nu have equal total mass Q'. Using mu'(C_k)=m_k(1+u'_k), their half-L1 distance is exactly

  sum_k alpha_k m_k |u'_k-kappa'|/[2(1+kappa')].

Weighted Cauchy with E'=sum alpha m(u'-kappa')^2/eps gives the displayed TV upper bound. The factor of two convention is explicit. The report correctly distinguishes nonnegative bounded price error G TV from signed bounded error 2G TV, and does not use it to pay unbounded/inverse-alpha/spatial displacement prices.

The gamma-refined coupling now explicitly uses a genuine next center-cost assignment with total mu', support C_k and mass alpha_k m'_k. Its stated marginals and the same labeled TV formula follow. The frozen-Z x integration is correctly identified as a ghost source point, not the conditional law of the realized old anchor. The report does not replace alpha_(x,X_-j) by frozen alpha_Z in the original signed-Fubini score and does not infer a new independent product law from these finite-measure marginals.

Every next denominator is used only on retained positive owners. Deleted labels are extended by alpha=0 in valid old-label sums, without assigning a fictitious u'=0/0.

## 4. Whole-geometry normalization and center-cost scaling

With g=1+kappa', all cubes, centers, receiver owners and source are jointly scaled. The actual entropy objective and source mass scale by 1/g, so alpha stays the actual optimizer at the same eps. The identities

  M_next=Q'=M-S, Q_next=Q'/g, V_next=W/g,
  R_next=W/Q', u_next=u'

are consistent. They prove nonincrease, not a positive uniform mass drop. The report retains the same-class near-supremum bound R'<=Rhat_N and D<=eta Q', without an attained-extremum assumption or the false replacement R'<=R.

The normalized squared relative-radius assignment integrand is invariant under common spatial scaling, so its objective scales only by source mass 1/g. The report correctly distinguishes this from the abandoned unnormalized physical quadratic factor g^(-1-2/n). The bound Z_gamma<=Z_lambda therefore legitimately applies to the selected center-cost assignment and persists under common normalization.

The newly explicit E_next=E'/g is correct. The reload charge E'/kappa' cannot be renamed as E_next/kappa' without its factor g, and the report warns about this.

## 5. Nonaveraged forcing and reload payment

The squared infinity-norm convexity bound in section 5 uses the actual realized anchor, with A_j^0=sigma_j/t_j^2, B_j^0=(1-t_j^(-2))/4 and A_j^0+B_j^0=(sigma_j/t_j)^2. Its two positive measures have the stated total mass cap. The adaptive density formula for E omega contains E_-j alpha_j(x,X_-j) and the correct m_j/a_j=1/lambda_j. No independence of alpha is inserted.

Section 7 pays the OWN-ROW reload L_Z, not the worst-row r_mu reload. On next-low u'<kappa'/2, the E'_j/kappa' bound is correct. On next-high, alpha_j m_j=eps p_j/u'_j removes adaptation pathwise and yields 2B_j p_j r_j(X_j)^2. E-priority then costs at most F/2 plus the diagonal old price. For u>U, monotonicity of u(1+u)/(u-kappa)^2 gives C_U/2 times the old growth summand. At U=4kappa this is 8/9+2/(9kappa)<=20/21.

After this elimination, the remaining first term uses only fixed old coefficients and r_j(X_j), so its expectation is Z_gamma by the genuine old marginals. Replacing it by the larger Z_lambda is now legal because the report has changed the assignment objective and proved Z_gamma<=Z_lambda. It would not have been legal for an arbitrary old F-maximizer. The worst-row source test P_mu is not silently replaced by Z_gamma.

Random kappa'>0 remains inside E[E'/kappa']; no critical-band bound on kappa' or independence from alpha/anchors is assumed. The first term in the original forcing inequality remains an old-source actual-alpha moment, and the report explicitly does not identify it with Z_lambda or the true next-source moment Z_next.

## 6. No double payment or closure claim

The report permits spending F/2 from the same action's Pplus reserve, but explicitly marks it consumed. It charges only old u>4kappa growth, which is disjoint from the already-paid low incoming branch. It does not then declare that high growth or fill fully available for another payment.

The new-growth charge remains an unpaid genuine cross-generation obligation. No sum of source masses, no square-root TV error sum, and no forcing-energy sum is asserted bounded. The final gap list correctly separates new-source spatial transfer, the old-alpha/old-lambda moment comparison, a single nonduplicated cross-round fee ledger, the failure of small S,D to force small growth, and the still-unproved complete target/capacity inequality.

Thus the final combination establishes legal center-cost selection plus one reload estimate and terminal structure. It does not establish the R647 full target, a uniformly contracting potential, or a general root-order weak bound. All inherited initial/contact/deletion/scale/history/general-input recovery costs remain explicitly outstanding as applicable.
