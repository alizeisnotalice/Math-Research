"""Verify packaging and seven bounded mathematical replays, never compile PDF."""
from pathlib import Path
import ast, hashlib, json, re, subprocess, sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST.json'}
assert actual==set(manifest['files'])
for name,digest in manifest['files'].items():
 p=root/name
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
 if p.suffix=='.py':ast.parse(p.read_text(),filename=name)
s=(root/'REPORT.tex').read_text();stack=[]
for kind,env in re.findall(r'\\(begin|end)\{([^}]+)\}',s):
 if kind=='begin':stack.append(env)
 else:assert stack and stack.pop()==env,(kind,env)
assert not stack
labels=re.findall(r'\\label\{([^}]+)\}',s)
refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',s)
assert len(labels)==len(set(labels)) and set(refs)<=set(labels)
assert all(ord(c)>=32 or c in '\n\t' for c in s)
report_hash=hashlib.sha256((root/'REPORT.tex').read_bytes()).hexdigest()
for name in ['FINAL_GEOMETRY_AUDIT.md','FINAL_LEDGER_AUDIT.md']:
 assert report_hash in (root/name).read_text(),name
checks=[('repro/check_algebra.py',[])]+[(f'repro/recurrence/{script}',[stage]) for script in ['check.py','terminal_check.py'] for stage in ['initial','boundary','expanded']]
counts=[]
for name,args in checks:
 out=subprocess.run([sys.executable,'-B',str(root/name),*args],cwd=root,capture_output=True,text=True,check=True)
 rows=[json.loads(line) for line in out.stdout.splitlines() if line.strip()]
 counts.append({'script':name,'args':args,'json_records':len(rows)})
print(json.dumps({'manifest_files':len(actual),'latex_labels':len(labels),'report_sha256':report_hash,'replays':counts,'scope':'No PDF compiled; no general theorem or nonzero-error recurrence certified.'},ensure_ascii=False,indent=2))
