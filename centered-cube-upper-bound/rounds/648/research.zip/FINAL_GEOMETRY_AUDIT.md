# Final geometry audit of REPORT.tex

Audited file: /tmp/ccu_r648_final/REPORT.tex
Final audited SHA256: 52f4642140f03d62ee242aac3e8623eba5030229d2ba35e0a70e22e7ba0e75e4

Scope: sections 3, 4, and 6 terminal geometry, robust inequality, exact-platform finite horizon, weighted-core covering, and the opening/concluding claims. Section 6's substitution of a new allocation objective into inherited nongeometric full ledgers is outside this geometry audit and belongs to the actual-alpha/ledger audit. No author file was modified and no previously passed computation was rerun.

Method: I first read the theorem statements without their proofs and independently checked the required implications. I then read the reported proofs and compared them to /tmp/ccu_r648/CENTRALITY_AUDIT.md and /tmp/ccu_r648/FINITE_HORIZON_AUDIT.md. The earlier input-dependent global-center argument in PLATEAU_AUDIT.md is superseded, for this exact finite setting, by the independently audited relative-centrality finite-horizon proof.

Final verdict at this SHA: PASS for all scoped mathematical inequalities, horizon counts, and claim boundaries. Both issues identified during review were corrected by the author: the original old-state ownership contract no longer assumes full receiver-union coverage, and the opening/theorem now explicitly say the finite-horizon impossibility holds almost surely. No unresolved geometry correction remains. The fixed finite-path implication is on the explicitly described full-measure anchor events.

## Section 3: exact full-family source terminal

P_r=0 simultaneously centralizes all finitely many old source restrictions outside a common mu-null set. Positive source intersection, radius ordering, and r<=1/3 imply source-set inclusion by the 3r estimate. The physical cubes need not be laminar, and the report explicitly distinguishes this.

For distinct maximal source classes, choosing the largest-radius representative of each equal class ensures that every subordinate physical radius is at most its root radius. Maximal source roots are pairwise mu-disjoint and cover mu because the old packing saturates mu. Thus sum_root m_p=M. The actual receiver cover B_k subset Q(y_p,(2r+1/a)s_p) follows from a separate common-central-source point argument. Consequently the full receiver union is at most (2r+1/a)^n M, with no owner-cover assumption. If u_j=kappa throughout, sum_root d_p=M/(1+kappa)=Q, and V<=the full receiver union gives R<1. The strict inequality is uniform since 2r+1/a<=2/3+1/32<1.

All masses, source sets, roots, and physical receivers are used in their correct roles. No density cap, source-coordinate independence, minimum entropy weight, or label-count factor enters.

## Section 3: robust varying-growth bound

The outlier owner volume is paid by [(1+zeta)/(kappa zeta^2)]E, using the correct endpoint maximum of u/(u-kappa)^2. On the balanced complement, rows with bad-source mass >eta m_j have total a_j<=P_r/eta by the actual old packing; v_j<=a_j/eps pays their OWNERS. No exceptional row disappears for free.

On G=B_r^c the remaining positive source sets are laminar by the same 3r argument. Root source masses are at least (1-eta)[1+kappa(1-zeta)]d_p, and roots' good source sets are pairwise disjoint. This yields the displayed third term. The three analysis branches account for disjoint subsets of original actual owners.

The balanced sharpening correctly retains v_j=Ra_j/(1+kappa), giving R<=C_r/[(1-eta)(1-delta_r/eta)] when delta_r<eta. The choice eta=sqrt(delta_r) is admissible only for 0<delta_r<1; the report correctly specifies a limit for zero tail. It also correctly warns that dividing any rearranged varying-growth ratio inequality requires a positive coefficient.

The report's newly restored original contract requires only disjoint I_j subset B_j, not full old receiver coverage. The robust bound is stated for V=sum v_j and explicitly qualifies claims about the complete union. This fixes the previously identified scope mismatch without altering the valid proof.

## Section 4: exact dual selection and uniform horizon

At each exact step S=0, the identity comparing L_alpha^A and L_alpha^C is valid for the actual outcome-dependent alpha, using A_k subset C_k and mu AC. Nonnegativity gives no new old-source mass in C_k\A_k for every retained positive-alpha row, together with alpha saturation on mu. With D=0, kappa'=kappa; with E'=0, every retained u'_k=kappa. Hence mu'=(1+kappa)mu is indeed a valid actual next AC KKT dual.

The report explicitly requires choosing this dual at the time of recursion and warns against retrofitting it onto an arbitrary pre-existing trajectory. Whole-geometry normalization preserves eps, R, kappa and M in this exact case and takes the next source to the common-origin pushforward of old mu. A first exact step from an arbitrary old-u state produces balanced next u; it does not claim old growth was already balanced.

From a balanced state, genuine anchors are in their individual r-cores on a simultaneous full-measure event, since gamma_j<=mu. The no-invasion equality applies to retained new rows for the actual adaptive alpha. The displacement bound is sigma r s_j with new halfside t s_j, giving the exact relative-centrality recurrence r_next=q r, q=(1+t^(-1))/2. The common spatial scaling preserves this ratio. Deleted rows are absent only from the next state, and retained source coverage follows from saturation.

For p=t^(-1), (1-p^n)<=n(1-p) and p^n<=2/9 imply q<=1-7/(18n). Therefore q^(3n)<=exp(-7/6)<1/3. Starting with the automatic r_0=1, 3n balanced exact transitions would give the Section 3 terminal contradiction with invariant R>1. From arbitrary old growth, one initial balancing step gives the correct 3n+1 action count. This is independent of label count, source diameter and minimum radius and needs no infinite limit.

The proof properly uses finite conditional-probability induction and common full-measure events; no new stochastic measurable-selection theorem is asserted. The final theorem and opening now explicitly say “几乎必然”, matching this probability quantifier. The report correctly states that this result gives neither a quantitative first-error lower bound nor stability of near-platform trajectories, and that O(M) per step over O(n) steps remains O(nM).

## Section 6: weighted tail and one global core cover

For 0<r<=1, T_r^lambda is formed with the actual old entropy weights. Bad rows satisfy tail_j>eta m_j, so sum_bad a_j<=T_r^lambda/eta and their actual owner cost is <=T_r^lambda/(eps eta). Good cores K_j have mass >=(1-eta)m_j >=(1-eta)d_j.

Processing good rows in decreasing radius and blocking only on positive SOURCE intersection gives pairwise mu-disjoint selected root cores. Every blocked row goes directly to a selected root of at least its radius. A shared core point gives center distance <=2r s_root and hence the actual receiver containment in the displayed root dilation. Root masses imply sum_root d_p<=M/(1-eta). This is one cover for all scales; neither source laminarity nor a common good-source set is used, and physical cover overlaps only improve the upper sum.

The first displayed weighted bound and the optimized square-root bound follow. The minimizing eta is interior when tail>0; the report explicitly handles zero tail by a limit. Markov uses the same lambda weights and normalized row distances, so T_r^lambda<=Z_lambda/r^2. Also 0<=Z_lambda<=M follows from r_j<=1 on A_j and old saturation. No growth energy is consumed.

At r=1/64 and a=32n, C_r<=1/16. In the stated hard branch R>=1 and kappa in [7/2,4], V/M>=1/5 and eps V/M=kappa/(1+kappa)>=7/9. The reported positive moment threshold is exactly [(1/4096)(7/9)(1-sqrt(5)/4)^2], matching the independent previously executed arithmetic evidence. Its force is terminal only. The balanced further sharpening with weighted tail fraction <1 is also valid.

The next-generation moment formula uses actual alpha, actual next mu', and denominator t_k^2 s_k^2. The prefactor (1+kappa')^(-1) is precisely the normalized source-mass factor; row-distance ratios are spatially scale invariant. Thus the theorem applies to the full actual successor ownership without a lower bound on alpha or a convenient replacement source. This terminal application does not require kappa' to stay critical. The numerical hard-branch threshold requires the successor's own hard-branch assumptions if it is used there; no automatic inheritance is established.

The source allocation existence argument in Section 6 has a valid geometric baseline gamma_j^0=lambda_j 1_Aj mu, correct row masses a_j, and source sum mu. On the supported feasible class the normalized objective is bounded and weak-star continuous, with a finite-product weak-star compact feasible set; hence Z_gamma<=Z_lambda is a valid allocation choice. This certifies that local comparison and not any inherited ledger that might require the former exchange objective.

## Opening and conclusion: claim scope

The opening and conclusion explicitly leave the general n^(1/2+o(1)) weak bound and full target unproved, retain spatial propagation and total forcing/debit gaps, and explain that finite exact-platform termination does not supply a root-order budget. The final update now records the weighted terminal and one actual reload control rather than hiding those achievements, while retaining the unproved source/weight contraction and cumulative payment requirements.

No unsupported claim of near-extremizer compactness, positive-probability exact plateaus, arbitrary-dual stationarity, zero-gap exchange, source-density domination, or automatic root-order improvement appears in the scoped sections. The exact-horizon probability wording has been corrected in the final bound SHA; no pending standalone geometry quantifier issue remains.

## Final rebinding check

Read the final source and confirmed SHA256 52f4642140f03d62ee242aac3e8623eba5030229d2ba35e0a70e22e7ba0e75e4. The last source changes add the explicit next allocation constraints and rename an old-growth summand to e_j; neither changes the scoped geometric theorems. This audit certifies only this exact source hash. No calculations were rerun for this final audit.
