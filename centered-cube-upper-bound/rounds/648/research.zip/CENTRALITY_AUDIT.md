# Centrality terminal bound — independent audit checkpoint

Task scope: finite actual cube family only; investigate the stated exact and approximate centrality terminal bounds, with actual disjoint receiver owners. No global closure claim.

Independent first check (before reading author): P_r=0 implies, simultaneously for all labels outside one mu-null set, that any source point in A_j lies in Q(y_j,r s_j). If two cubes A_i,A_j share positive source mass and s_i<=s_j, choose one common source point. Then ||y_i-y_j||_infinity<=r(s_i+s_j). If 3r<=1, each source point of A_i is within r s_i+r(s_i+s_j)<=3r s_j<=s_j of y_j. Thus A_i's source support is included in A_j modulo mu-null sets. This is source-support laminarity, not physical cube laminarity.

Further root and approximate-good-family audit in progress.

## Verdict and precise quantifiers

The exact claims and the proposed nonzero-tail bound are TRUE for the frozen actual ownership quantity V=sum_j v_j, with 0<r<=1/3, 0<eta<1, 0<zeta<1, eps>0 and kappa=eps V/Q>0. The frozen range kappa in [7/2,4] is more than sufficient. Require finite positive-radius labels with v_j,lambda_j>0, actual moments m_j=(1+u_j)d_j, u_j>0, a_j=lambda_j m_j, and old packing load <=1 mu-a.e. plus saturation =1 mu-a.e. The original actual state has these properties since mu is AC and the a.e. packing holds Lebesgue-a.e. No independence, density bound, action selection, new entropy optimizer, or next growth assumption is required.

The variable r must be nonnegative for the central cube to be defined; the natural nondegenerate statement is 0<r<=1/3. For r=0 with the actual AC positive source the good source vanishes, making the zero-tail case impossible and the approximate good family empty. No result relies on treating negative r as a cube radius.

Define

    B_r=union_j [A_j\Q(y_j,r s_j)],
    P_r=mu(B_r)=delta M,  G=B_r^c,  nu=mu|_G,
    C_r=(2r+1/a)^n,  a=32n.

The symbol C_r here is a scalar, unrelated to the new cubes C_j. All complements and unions are measurable. Tail mass is a UNION mass; it is never replaced by an unweighted sum of individual tails.

## Independent geometric proof

For every label j, nu(A_j\Q(y_j,r s_j))=0 (in fact the corresponding subset of G is empty for the displayed literal definition). If nu(A_i∩A_j)>0 and s_i<=s_j, select a point z of this positive-measure intersection outside the finite union of any centrality exceptional null sets. Then

    ||y_i-y_j||_infinity<=r(s_i+s_j).

For nu-a.e. x in A_i,

    ||x-y_j||_infinity
      <=r s_i+r(s_i+s_j)<=3r s_j<=s_j.

Thus nu(A_i\A_j)=0. Every pair of positive nu-source sets is either disjoint modulo nu-null sets or nested modulo nu-null sets. This is laminarity of the measured source sets; the physical cubes themselves need not be nested.

For any finite subfamily with nu(A_j)>0, take its distinct maximal source-set classes modulo nu-null equality. Within each class choose the label of largest physical radius. Every row k belongs below some maximal root p. If s_k>s_p, their positive source intersection and the preceding argument imply nu(A_p\A_k)=0. Maximality then forces source-set equality, contradicting the representative's largest radius. Consequently s_k<=s_p, and selecting a common central source point gives

    ||y_k-y_p||_infinity<=r(s_k+s_p)<=2r s_p.

Its full physical old receiver obeys

    Q(y_k,s_k/a) subset Q(y_p,(2r+1/a)s_p).

Maximal root source sets are pairwise nu-disjoint. Therefore the full physical receiver union of this subfamily has volume at most

    C_r sum_roots d_p.

Source-set inclusion is used only to select and compare roots. Physical receiver containment is a separate geometric conclusion, explicitly proved above. No cube volume or source mass is interchanged.

## Exact zero-tail case

If P_r=0, use nu=mu and the full old family. Every root has positive source mass. Saturation implies that the old cubes cover the source modulo mu-null sets, so their maximal source roots also cover it. Thus

    sum_roots m_p=M.

Because m_p=(1+u_p)d_p>=d_p,

    |union_j Q(y_j,s_j/a)|<=C_r sum_roots d_p<=C_r M.

This bounds V as well, since the actual disjoint I_j lie inside these receivers. If all u_j=kappa, then sum_roots d_p=M/(1+kappa)=Q, yielding the stronger full-union bound C_r Q and hence V<=C_r Q. Equality of the root masses' sum with M uses full old-source saturation, not an unproved disjoint decomposition of physical cubes.

## Nonzero-tail proof and exact ownership charges

Let J_bal={j:kappa(1-zeta)<=u_j<=kappa(1+zeta)}. For u outside this interval,

    u/(u-kappa)^2 <=(1+zeta)/(kappa zeta^2).

Indeed the function is increasing below kappa and decreasing above kappa, with endpoint values (1-zeta)/(kappa zeta^2) and (1+zeta)/(kappa zeta^2). Hence

    sum_{j not in J_bal}v_j
       <=(1+zeta)E_grow/(kappa zeta^2).

For j in J_bal put b_j=mu(A_j∩B_r), and discard those with b_j>eta m_j. Packing and finite additivity give

    eta sum_discarded a_j
       <sum_discarded lambda_j b_j
       <=integral_{B_r} sum_j lambda_j 1_Aj dmu
       <=P_r.

With saturation the final full-family weighted integral equals P_r, but only the upper bound is needed. The exact old owner identity is

    v_j=a_j u_j/[eps(1+u_j)]<=a_j/eps.

Thus the additional discarded OWNER volume is at most P_r/(eps eta). This does not presume that gamma_j<=lambda_j mu, does not introduce lambda_min, and does not charge tail mass once per label.

Every remaining good label satisfies

    nu(A_j)=m_j-b_j >=(1-eta)m_j
       >=(1-eta)[1+kappa(1-zeta)]d_j>0.

Apply the root proof to this good subfamily with source nu. Its roots are disjoint modulo nu-null sets, so

    sum_good_roots d_p
       <=nu(union_good_roots A_p)/((1-eta)[1+kappa(1-zeta)])
       <=M/((1-eta)[1+kappa(1-zeta)]).

The disjoint good ownership pieces have total volume bounded by the union of the good receivers. Splitting the OWNERS into unbalanced, balanced-tail-discarded, and good rows proves

    V <= (1+zeta)E_grow/(kappa zeta^2)
         +delta M/(eps eta)
         +C_r M/((1-eta)[1+kappa(1-zeta)]).

All charges are explicit and each discarded row is counted at most once. These are actual old E_grow and old ownership volumes. Reusing this E_grow later as an untouched second budget would require a separate account; this terminal inequality does not authorize that.

One harmless strengthening is available without changing the argument: replace M in the last numerator by nu(union_good_roots A_p), or by M-P_r. The stated coarser bound is valid as written.

## Actual receiver volume versus owner volume

The exact P_r=0 proof directly bounds the full physical receiver union. The robust proof bounds V=sum_j|I_j| through the explicit discarded OWNER costs. It bounds the full receiver union with the same formula only when the actual ownership pieces cover that union a.e. The frozen general old-state contract requires disjoint I_j subset old receivers and defines V=sum v_j; it does not need full coverage for the robust inequality. Successor actual full ownership does have the coverage property. Author wording that refers to V as full receiver-union volume should include this qualification. No arbitrary zero-owner deletion is used in this old-state terminal argument.

There is no ambiguity from boundaries: the finite centrality null-set union is null, and positive intersections provide a common point outside it. Physical closed-cube boundary contacts alone create no positive-source intersection under the actual AC source. Source classes are defined modulo nu-null sets, while all covering volume inequalities concern the actual physical receiver cubes.

## Comparison after independent derivation with GLOBAL_FILL.md

After recording the independent geometric checkpoint, I read the latest centrality sections of GLOBAL_FILL.md. Equations (6)--(8) match the proof above. The largest-radius representative repair in the robust root argument is necessary and correctly supplied by the author. In the balanced exact case, the common-u mass formula already orders radii within source inclusions; the representative convention remains a clean way to handle equal source sets.

The displayed ratio formula (9) is algebraically correct using M=(1+kappa)Q, V=RQ, and eps R=kappa. Its left coefficient may be zero or negative; extracting an upper bound on R by division requires that coefficient to be positive. The undivided inequality remains valid without this extra assumption.

For exactly balanced rows, the sharper bad-owner relation is v_j=R a_j/(1+kappa). It gives discarded ownership <=(delta/eta)V and good receiver volume <=C_r Q/(1-eta). Thus for 0<=delta<eta<1,

    R<=C_r/[(1-eta)(1-delta/eta)].

For 0<delta<1 the choice eta=sqrt(delta) is allowed and gives the stated denominator (1-sqrt(delta))^2. For delta=0 use the exact proof or an eta-down-to-zero limit; eta=0 itself is not a permitted discard parameter.

The terminal estimates do not propagate P_r through a nonzero-error action, do not price an alpha-unweighted annular union by a weighted average, and do not establish the remaining global target. No new quantitative recursion or research extension is asserted by this audit.

## Executed local mathematical-tool evidence

Ran the installed math Python /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python with SymPy. It returned derivative -(kappa+u)/(u-kappa)^3 and the two growth endpoint coefficients above. Exact symbolic residuals for v_j=a_j u_j/[eps(1+u_j)] and the ratio fee substitution after eps=kappa/R were zero. These runs verify algebra; laminarity, root covering and fee accounting are the independent proofs above.

# Independent weighted-terminal audit — checkpoint before reading W1–W4

For any 0<r<=1 define the literal central core K_j=Q(y_j,r s_j), t_j=mu(A_j\K_j), and T_r=sum_j lambda_j t_j. Split rows at t_j>eta m_j. The bad ownership cost is <=sum_bad a_j/eps<=T_r/(eps eta). Every good core has mass >=(1-eta)m_j>0. Process good rows by decreasing radius, selecting a row as root exactly when its core has zero mu-measure intersection with all earlier roots; otherwise assign it to one blocking root. Root cores are pairwise mu-disjoint. A blocked child's radius is at most its assigned root's, and a common core point gives center distance <=2r s_root. Its receiver is therefore inside the root cube of halfside (2r+1/a)s_root. Root core masses >=(1-eta)d_root imply sum d_root<=M/(1-eta). Consequently V<=T_r/(eps eta)+(2r+1/a)^n M/(1-eta). No laminarity of source sets is needed, and no common good-source restriction is taken. This proof is valid for every r in (0,1], rather than only r<=1/3.

The bound optimizes in eta as inf_{0<eta<1}(A/eta+B/(1-eta))=(sqrt(A)+sqrt(B))^2, where A=T_r/eps, B=(2r+1/a)^n M. If A>0, eta=sqrt(A)/(sqrt(A)+sqrt(B)); if A=0 take eta down to zero, obtaining the same inequality by a limit. Thus sqrt(V)<=sqrt(T_r/eps)+sqrt((2r+1/a)^n M).

## Weighted terminal W1–W4: full independent certification

Verdict: the new terminal theorem is TRUE with the exact packing weights lambda. It resolves the terminal ownership comparison without needing to control the larger unweighted UNION tail P_r. The proof below was derived before reading W1–W4, as recorded in the checkpoint above; subsequent comparison with the author's proof found the same root construction and no unpaid terminal fee.

Use the same finite actual state and define, for 0<r<=1,

    K_j=Q(y_j,r s_j),
    t_j=mu(A_j\K_j),
    T_r=sum_j lambda_j t_j,
    C_r=(2r+1/a)^n.

These t_j are tail masses, unrelated to the half-action dilation factors also denoted t_j elsewhere. All lambda_j are the actual positive old optimizer coordinates. Packing and saturation give

    0<=T_r<=sum_j lambda_j mu(A_j)=M.

Fix any 0<eta<1. Bad rows satisfy t_j>eta m_j. Their true ownership cost is

    sum_bad v_j <=(1/eps)sum_bad a_j
       <=T_r/(eps eta),

because a_j=lambda_j m_j and v_j=a_j u_j/[eps(1+u_j)]. This uses precisely the same lambda weights as T_r, with no change to supply weights or alpha. It retains every bad old owner in the charge.

Every remaining good core has mu(K_j)>= (1-eta)m_j >=(1-eta)d_j>0. Sort good labels by nonincreasing s_j, resolving ties by a fixed label order. Select j as a root if mu(K_j∩K_p)=0 for all previously selected roots p; otherwise assign j directly to one previously selected root whose intersection with K_j has positive mu-mass. There is no recursive chain assignment and no physical-intersection-only blocking. Distinct root cores have pairwise mu-null intersection, so their total masses sum to at most M and

    sum_roots d_p<=M/(1-eta).

Each nonroot child k has s_k<=s_p for its assigned root p and a common core point z. Thus

    ||y_k-y_p||_infinity<=r(s_k+s_p)<=2r s_p,
    Q(y_k,s_k/a) subset Q(y_p,(2r+1/a)s_p).

Roots themselves satisfy this cover as well. Sum of the good disjoint owner volumes is bounded by the union of good receivers and then by the sum of root cover volumes, namely C_r M/(1-eta). Adding the bad-owner bill gives

    V<=T_r/(eps eta)+C_r M/(1-eta).                    [certified W1]

Root covers may overlap physically; this only decreases the covered union relative to the upper sum. Source mass is counted only in the pairwise mu-disjoint cores. Finite overlapping core boundaries are harmless: for actual AC mu they carry no mass; more generally the selection rule is expressly based on positive mu-mass. The proof needs neither source-set laminarity nor a common restricted good-source measure, and no growth energy is spent. Good versus bad is an accounting partition, not permission to delete actual old labels.

The same proof works for arbitrary r>1 using mu(K_j)>=mu(A_j∩K_j)>= (1-eta)m_j, as the author's broader wording states; the requested range (0,1] suffices here.

## Optimization, zero tail, and quadratic moment

Set A=T_r/eps>=0 and B=C_r M>0. For A>0 the minimizing parameter is

    eta_*=sqrt(A)/(sqrt(A)+sqrt(B)) in (0,1).

The optimized value is (sqrt(A)+sqrt(B))^2. For A=0 the infimum is B, approached as eta down to zero; one must not insert eta=0 into W1. The finite quantity V satisfies all the inequalities, hence also the limit. Therefore

    sqrt(V)<=sqrt(T_r/eps)+sqrt(C_r M),                [certified W2]
    T_r>=eps (sqrt(V)-sqrt(C_r M))_+^2.               [certified W3]

With all retained old weights positive, T_r=0 also forces every individual t_j=0, but the optimization proof needs only A=0. No singular inverse weight occurs.

Define the actual weighted row moment

    Z_lambda=sum_j lambda_j int_Aj
                    (||x-y_j||_infinity/s_j)^2 dmu(x).

Its integrand lies in [0,1] on A_j; hence 0<=Z_lambda<=M. On A_j\K_j the normalized distance is greater than r, so rowwise Markov followed by summation with the same lambda gives T_r<=Z_lambda/r^2. Consequently

    sqrt(V)<=sqrt(Z_lambda/(eps r^2))+sqrt(C_r M).      [certified W4]

This is a nonaveraged row moment, with units of source mass. It is not the moment of an average center, an unweighted annular union, or a product source law.

## Uniform hard-branch terminal constant

For r=1/64 and a=32n,

    C_r=[(1+1/n)/32]^n<=1/16,

since its base is <=1/16 for every integer n>=1. Assume additionally R=V/Q>=1 and kappa=eps R in [7/2,4]. From M=(1+kappa)Q,

    V/M=R/(1+kappa)>=1/5,
    sqrt(C_r M/V)<=sqrt(5)/4<1,
    eps V/M=kappa/(1+kappa)>=7/9.

Certified W3 thus gives

    T_r/M >=(7/9)(1-sqrt(5)/4)^2,
    Z_lambda/M >=(1/64)^2 (7/9)(1-sqrt(5)/4)^2.

The second constant is approximately 0.00003692659718833377. This is strictly positive and uniform in dimension, label count, radius ratios, source concentration and eps within the specified hard branch. It certifies that any actual state below this moment threshold is outside that hard branch. It does not show that a legal evolution ever reaches the threshold.

## Applying the theorem to the actual normalized next generation

Let J be the actual retained next labels, alpha their actual entropy optimizer, C_k=Q(c_k,rho_k) their cubes before normalization, mu' any valid actual AC next KKT dual, and h=1+kappa'>1. Scale the entire next geometry by h^(-1/n) and use source (T_#mu')/h, retaining the same eps. Then the old-state hypotheses for this theorem hold with

    lambda_next=alpha,
    d_next,k=m_old,k/h,
    v_next,k=v'_k/h,
    m_next,k=mu'(C_k)/h=m'_k/h,
    M_next=M'/h=Q',
    V_next=W/h.

The packing/saturation and entropy demand identities are the actual next ones, not inherited old-source identities. Positive retained owners and the full receiver cover are preserved by this scaling. The moment is exactly

    Z_next=(1/h)sum_{k in J}alpha_k int_Ck
                    ||y-c_k||_infinity^2/rho_k^2 dmu'(y).

Scale invariance of the row distance ratios proves this formula. W1–W4 apply to this state for every such actual dual, including genuinely varying next u'_k, without a lower bound on alpha or an old-to-new source coupling. No choice mu'=h mu is needed for this terminal application.

Applying the NUMERICAL hard-branch lower constant to the next generation additionally requires its own R_next>=1 and kappa_next in [7/2,4]. The general terminal inequality itself does not require this critical range; old hard-branch hypotheses do not automatically transfer it to the successor.

The ownership-versus-union distinction remains essential: W1–W4 bound V=sum actual owner volumes for a general old state. In the genuine normalized successor the actual retained owners cover the whole receiver union, so there the theorem indeed bounds that full physical receiver-union volume. Full old receiver coverage is unnecessary for the mathematical statement about V; it should be explicitly assumed whenever the author's phrase “FULL actual receiver volume” denotes an old union rather than its defined V.

## Scope and remaining gap

This audit certifies the terminal inequalities only. It gives no bound on the new-source moment by an old-source moment, no control of adaptive anchor reload or source displacement, and no summable forcing/debit. The actual weights and actual KKT source at the next generation cannot be replaced with a convenient old source merely to obtain propagation. No root-order global bound or remaining high-incoming target follows from W1–W4 alone.

For completeness, the author's balanced sharpening W5 also follows from the same proof: if all u_j=kappa then bad-owner cost is kappa T_r/[eps(1+kappa)eta] and good root cost is C_r Q/(1-eta). With delta=T_r/M<1 optimization yields R<=C_r/(1-sqrt(delta))^2. This consumes no E_grow. The delta=0 case is read as the exact limit.

Executed local tool check: SymPy in the installed math Python returned zero for the eta-optimization residual and the scaled entropy demand residual. It evaluated the hard tail constant as 0.151251342083415118063099 and the moment constant as 0.0000369265971883337690583738, agreeing with the author. The geometric and source-counting arguments above are proofs, not numerical inference.
