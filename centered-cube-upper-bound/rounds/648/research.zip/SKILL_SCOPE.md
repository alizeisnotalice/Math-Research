# R648 skill scope and provenance check

## E03: usable workflow, wrong smoke-test target

The E03 instructions give a sound conditional workflow: define tree masses and transition probabilities, distinguish averaged from pathwise budgets, telescope only after checking mass consistency, retain terminal terms, and stop when the tree or boundary hypotheses are missing. The source claim is explicitly attached to P-ee5e7f1d2f3397ce.

There is a concrete example-target mismatch. The Skill's registry resolver example calls `--evidence-id E1485`. In [provenance.md](/Users/zhengzhihao/.codex/skills/math-e03-tree-bellman-cross-layer-budget/references/provenance.md), E1485 is Pham's mean-field Bellman paper, paper ID P-9506844b14c261db, marked pending. By contrast, E1502 is “Bellman function sitting on a tree,” paper ID P-ee5e7f1d2f3397ce, marked direct and identified as the fully read source for the tree Bellman claim. The evidence index maps E1485 to `papers/P-9506844b14c261db/paper.pdf` (333,370 bytes, SHA-256 `9506844b…eb59f625`) and E1502 to `papers/P-ee5e7f1d2f3397ce/paper.pdf` (518,456 bytes, SHA-256 `ee5e7f1d…530a032`). Thus E1485 can smoke-test resolver mechanics, but it is the wrong evidence target for the E03 anchor; an anchor-resolution example should use E1502.

The index rows for both IDs say `full_read=unspecified; identity=pending`, including E1502, while E03's provenance prose says E1502 is direct/full-read and the Skill header binds the review to it. This is a status synchronization discrepancy in the handoff index. Resolver `--verify-sha256` checks artifact presence/current bytes; it does not settle this review-status conflict or certify theorem content. I read only the installed Skill and metadata here, not the external PDF, so make no independent PDF-reading claim.

## N04 and relevance to R647

N04's conditional telescoping recipe is usable as a bookkeeping method when a potential has a fixed finite lower bound, each decrement is nonnegative, and cumulative errors have a uniform upper bound (or are nonnegative and summable). Its provenance distinguishes irrelevant/pending entries from adjacent candidates such as E1826 and E1833; E1833 is explicitly only an algebraic-neighbor method and does not supply the entropy-descent theorem. No external N04 paper claim is needed for the R647 work.

R647 did not use the sourced E03 constants 4 or 32. There is no defined correspondence from its quantities to a tree's `m(v)`, `p(w|v)`, Bellman potential/increment, or terminal term. Nor is there an instantiated N04 potential/decrement/error sequence with the required lower bound and cumulative error budget. Treat both Skills as workflow guidance only for this project; they do not strengthen its theorem claims. This note reports metadata and scope only; it certifies no mathematics.
