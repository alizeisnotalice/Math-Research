# R443 independent final audit

FINAL PASS（仅限实际接受权累计的精确差额、同流bulk取消比较、双终端正上放及数值包络决策；不认证全R433预算或新母账付款）。2026-10-21。独立PRE先于新作者稿，冻结后后审全部14件输入；三脚本隔离复现一致。原始历史标签已按权威归档核对。范围内无剩余实质阻断，外层联合几何预算仍未付。

## 1. 实际RN累计与三差额

R442的同一正支配允许取实际推前密度0≤θ≤1。它不需随t单调；c_C(t)=∫_0^t∫1_{f>r}c_Ac_vwθ是非负AC累计，且c_C≤X_C,Y_C。外ν保原σ、π_A(y)a_0^e、真实dv/m_v及1/(hm_A)，R=∫u dν，u=Σc_C(∞)≤I≤m_v<m_A/K²。θ不是新接收质量或重算history。

逐原正记录上的分拆
 log[m_t(A)Y_C/(m_vX_C)]
 =log[m_Ap_C/c_C]−log[m_A/m_t(A)]−log[X_C/c_C]−log[Y_C(∞)/Y_C]
代数正确；后三项均非负。AC链式及cell求和严格给

 J=∫g_mA(u)dν−∫uD(p̂||p)dν−Ebulk−Eparent−Eterminal，
 g_M(x)=x[1+log(M/x)]，p_C=f(Q_v∩C)/m_v。

零格/零u不取对数。原有限field有统一正下/有限上质量，ν有限且g_mA(u)≤m_A，因此主正项可积。实际支持上的m_A>m_v及c_C≤m_v p_C使第一积分原函数合法；有限cell、非负差额和R441的J绝对可积确保KL及三个E分别有限，不作∞−∞。声明无限场时另取原有限截断，未免费外推。

删除信用g(I)−g(u)=∫_u^Ilog(m_A/x)dx≥(I−u)log(m_A/I)，严格质量门在I>u时给>2√n(I−u)；I=u按0处理。只用这个粗系数会与质量差左项相消，不能单独产生收缩，未过滤g(I)没有被忽略。

## 2. 精确同流回代没有SX损失

已独立核准最终mainproof(5a)：必须返回同一P的原质量恒等式
 ∫log(m_A/m_v)dP=Ebulk+J+∫log(B_AC/B_vC)dP，
而不是从已经把bulk放成SX的单边不等式反向减去SX。代入上节J，有限的同一Ebulk精确取消。R441实际capture收据给

 2(√n−log_+M*)R
 ≤∫g_mA(u)dν−∫uD(p̂||p)dν−Eparent−Eterminal+4rC_dA_nW。

没有额外SX项，也没有bulk再次退款。作者明确此未付组合是Ebulk+J；若用旧Q记号则等于Q+∫L_parent dP，不是Q本身。所有原记录/来源/阶段保持同一测度。新比较不支付其右侧的联合积分，原16/32/64母账、旧初始/删除/终端费用及全部吸收条件未修改。

## 3. p优化、incidence及终端历史范围

对有限正测度V、L=∫x及0≤x≤u，凹性给sharp上界V^pL^(1−p)，下界Lu^−p；常值与0/u二点分布分别达到。此为标量放松的sharpness，非原cube/history实现。

实际Jensen上界归一后为D+[A0−log(1−p)]/p，D=log(V/L)、A0=log(L/(hR))≥0（由R≤L/h）。A0>0的最优为D+w，w>1满足w−1−logw=A0、p=1−1/w；A0=0的下确界D+1在p↓0。质量帽只推出D≥2√n，因此限制的是这一可用上界机制的最佳价格，不是J的下界，也不证明原目标不可能。A0<0的3条诊断输入已标归一不相容，未求虚假收益。更粗linear指数价与实际Jensen优化明确分开。

独立PRE的Mellin身份与作者scope一致：K_p=(1−p)∫u^−p𝒩(u)du，一阶容量不能替代分数矩，p趋0仍须保1/p费用。low-common仅控制带c_v(y)的incidence一阶量≤h；与native总容量合并可给所列incident分数矩。整个终端交叠并无这个附加指标，不能插入或把初始exclusive传给后继。

本审计实际读取R427 research.zip的geometry:7–25、88–98、120–145及main:61–66。旧来源y的终端w捕获y，新来源z的终端v（旧文记t）捕获z；终端父外指中心，互中心门为α=e^(2/√n)，仍有a≤R_w,R_v≤b≤2a。门文本没有固定交叉c_v(y)，也未认证全历史分别实现0/1。尺度可比不能遗漏；高维即使等边长，互中心分离仍可允许cube相交。双whole-terminal帽乘积仅在上界删除未来正权后使用，不声称过滤law独立，不刷新history。

## 4. 实际复现及证据边界

在独立目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r443_audit_isolated_7pe48pum`，使用指定 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 实际运行geometry、mainproof、numeric三脚本，均exit0。三stdout与冻结输入逐字一致，再生numeric_certificate.json亦逐字一致。Python3.12.14、SymPy1.14.0、flint0.9.0/Arb256bit与记录一致；未运行MATLAB、solver或额外扫描。

geometry为n16/36/64的3个固定边长匹配连续child-center模型、测试父A=0的15项有理尾身份。其small receiver占用<辅助cutoff1，故也小于原q=1、ε_0≤1/2的h；不是把原h设置为1。模型不满足/不认证原高rank或完整history，也不是预算反例。mainproof为3张有限clipping/接受表的精确SymPy身份，retained9/2、3、41/30；40位符号诊断不是区间证书，也未认证原质量门。一般非负性和可积性依解析证明。

numeric保21个sharp标量见证、12个实际Jensen配置（9个有理根区间、3个不兼容）、A0=0边界；4个linear选择/24条更粗系数及额外volume诊断明确另列。非整数幂和根括号用Arb，Fraction见证保输入归一，未从抽象达到态推原几何最坏态。资源/共享索引只记录工作与复现，不能代替证明；复跑与PRE临时算术不增加正式覆盖。

最终限定：核准精确接口与上界机制决策，尚无交叠—拟合的原全流来源价。当前完整R433、ε总吸收和全尺度结算仍未证明；本PASS不得用于认证这些目标。交付后停止扩展。

## 冻结字节 SHA-256（14输入）

- `r443_main.md`: `aa4b06a13a8328f3f4ea7a2b778f6ad7409662483103e78e7f3daa88be70cca8`
- `r443_geometry.md`: `9df47b5515b7b0f9e28178543176beb5e33cd6a19fbc42473967ca9492107afe`
- `r443_geometry_check.py`: `4eb204aa3f4bb15f919bc998a1a29d2e338b325bf4186e519c386b0225c11a1d`
- `r443_geometry.result.txt`: `30fecb60666def1f8a630d29e8d27e56ef8e4dab4b6f421bf44d0180a433834d`
- `r443_mainproof.md`: `8af72b813cf2b6eca269e7b8ddc7782ec89ab3c918736012fc1b287992ddc0ae`
- `r443_mainproof_check.py`: `4c168cad2db79068376f64b1c562a2f8543dd6caedf9d311ce013909ee64b8bb`
- `r443_mainproof.result.txt`: `3aff8b24b9df48d6ee534b205816742c61a59a9e0d805fb4ad72eb3b2db5329e`
- `r443_numeric.md`: `884070339f50846442d7138aaa89674c7d47b97c2f3d56a644f8b7d2c94e6e80`
- `r443_numeric.py`: `35acf5a1e7cdb2bc1dfb46dc0f487736eae5357588973d33ed7cddc3a5f78262`
- `r443_numeric_certificate.json`: `736f65c87b476baf970483e935b8febe4f9f10f57f6da8861ad8c6730b93652f`
- `r443_numeric_run.txt`: `eafc092075cca6ae7f28cf2a7685f9ddcaf01f438b8ad2e9e2411bfdad2602e1`
- `r443_numeric_resources.txt`: `67f3f84aaf905df8f78802aa27c05e9984a4e475e5d270a85ed3bd7a61f76b68`
- `r443_compute_index.md`: `4bbd82e965f45df579a57de894573a5ebafbe593ece5c3595ef6e26c2af5f144`
- `r443_history.md`: `09c8abf28e960a93513f484529a489f8d4094d41e6a743d538ab65797d5bdc6d`
