# R443：保留当前接受权的交叠积分；未得到新的母账付款

本稿只沿一个方向检查：在 R442 终端正支配之后，保留**实际原流的 Radon–Nikodym 权**，直接积分 clipping level，而不取接收中心的分数幂体积。结果是下面的精确差额公式。它改善未过滤交叠的上界，但最粗的删除信用与原质量差下界抵消；没有证明一般根阶预算。

## 1. 实际测度与累计交叠

全部字段、原场与母账沿用 R443 合同及 R442 `geometry` §3 式 (6)。写 \(q=q_-\)，\(K=e^{\sqrt n}\)。把同一完整原流 \(\mathcal P\) 推前到 \((e,A,y,v,z,t)\)：\(y\) 是原旧来源，\(v\) 是原新来源终端，其他原 history、clock、early、路径记录只在推前时积分，原费用与门没有被重新生成。

取 R442 已允许的静态必要门 \(G(A,v)\)、\(w_{A,v}(y,z)\)。原流受其式 (6) 支配，所以存在一个实际可测密度 \(0\le\vartheta\le1\)，使
\[
 d\mathcal P
 =d\nu(e,A,y,v)\,
 c_A(z)c_v(z)w(y,z)1_{\{f(z)>t\}}
 \vartheta(e,A,y,v,z,t)\,dz\,dt,
\tag{1}
\]
\[
 d\nu=\frac{\sigma(dA)\pi_A(dy)a_0^e(A,y)G(A,v)}
                  {h\,m_A}\frac{dv}{m_v}.
\]
\(\vartheta\) 是原测度相对已证正支配的密度，含当前 \(a_i\)、低共同捕获和全部保留权的实际影响；不假定它随 \(t\) 单调，也不把它换成 1。零 \(a_0\) 或其他零基测度处任取 0。这里没有声称终端新获原初始资格。

固定 \((e,A,y,v)\)。对微格 \(C\) 定义
\[
 c_C(t)=\int_0^t\!\int_{C\cap Q_A\cap Q_v}
 1_{\{f(z)>r\}}w(y,z)\vartheta(z,r)\,dz\,dr,\quad
 u_C=c_C(\infty),\quad u=\sum_Cu_C.
\]
另记 \(X_C(t)=B_{AC}(t)\)、\(Y_C(t)=B_{vC}(t)\)，
\[
 I=\int_{Q_A\cap Q_v}f(z)w(y,z)\,dz,\qquad
 p_C=B_{vC}(\infty)/m_v.
\]
于是 \(c_C(t)\le X_C(t),Y_C(t)\)，\(0\le u\le I\le m_v<m_A/K^2\)，
\(\sum_Cp_C=1\)，以及原流总量严格为 \(R=\int u\,d\nu\)。
所有格的定义固定不依赖来源；空格不参与除法。

## 2. 同一 signed integrand 的精确差额

令 \(g_M(x)=x[1+\log(M/x)]\)，约定 \(g_M(0)=0\)。在 \(c_C'(t)dt\) 的支持上，
\[
 \log\frac{m_t(A)Y_C(t)}{m_vX_C(t)}
 =\log\frac{m_Ap_C}{c_C(t)}
 -\log\frac{m_A}{m_t(A)}
 -\log\frac{X_C(t)}{c_C(t)}
 -\log\frac{Y_C(\infty)}{Y_C(t)}.
\tag{2}
\]
后三项均非负。绝对连续链式给
\[
 \int_0^\infty c_C'(t)\log\frac{m_Ap_C}{c_C(t)}dt
 =u_C\left[1+\log\frac{m_Ap_C}{u_C}\right].
\]
因此，令 \(\widehat p_C=u_C/u\)（\(u=0\) 的整个纤维贡献 0），得到
\[
 \boxed{J=\int g_{m_A}(u)\,d\nu
       -\int uD(\widehat p\Vert p)\,d\nu
       -E_{\rm bulk}-E_{\rm parent}-E_{\rm terminal}.}
\tag{3}
\]
三个 \(E\) 分别是 (2) 后三项对原 \(c_C'dt\,d\nu\) 的积分。
特别 \(E_{\rm bulk}\) 就是同一原 \(\mathcal P\) 的父 bulk；**不能再把它或格拟合项当作额外原 BH 平方信用扣第二次**。

证明只用 (1) 与绝对连续累积，不需虚假的 stage 单调性。先在有限格及正质量截断上计算，再用 \(x\log x\) 在零处连续及非负项的单调收敛处理边界。原有限接收场下 \(m_A,m_v\) 有正下界和有限上界，\(\nu\) 有限，\(g_{m_A}(u)\le m_A\)；结合 R441 的 \(J\) 和 bulk 可积性，(3) 各非负减项均有限，不是无穷减无穷。若采用无限接收场，先保原有限截断；不能仅凭形式 (3) 宣称其各项可积。

## 3. 删除信用有多大，以及为何尚不足

R442 未过滤线性交叠界对应 \(g_{m_A}(I)\)。本稿保实际接受权后，
\[
 g_{m_A}(I)-g_{m_A}(u)
 =\int_u^I\log(m_A/x)\,dx
 \ge (I-u)\log(m_A/I)>2\sqrt n\,(I-u)
\tag{4}
\]
在 \(I>u\) 时严格；\(I=u\) 时取等号 0。因此确有定量删除信用，非仅把 \(I\) 改名成 \(u\)。
但未过滤版本本身是 R442 幂原函数在 \(p\downarrow0\) 的后果，本稿不把它另计为新一般付款。

**先保精确 bulk 的同流回代。** R441 放宽 bulk 之前，逐记录恒等式为
\[
 \log(m_A/m_v)=\log(m_A/m_t(A))
 +\log\frac{m_t(A)B_{vC}(t)}{m_vB_{AC}(t)}
 +\log\frac{B_{AC}(t)}{B_{vC}(t)}.
\]
最后一项不超过已付的终端捕获损失
\(L_v=\log(M_C(t)/B_{vC}(t))\)。因此原严格质量门及 R441 capture 收据直接给
\[
 2(\sqrt n-\log_+M_*)R
 \le E_{\rm bulk}+J+4rC_dA_nW.
\]
将 (3) **在同一原流上**代入，bulk 精确抵消：
\[
 \boxed{
 2(\sqrt n-\log_+M_*)R
 \le \int g_{m_A}(u)d\nu-\int uD(\widehat p\Vert p)d\nu
       -E_{\rm parent}-E_{\rm terminal}+4rC_dA_nW.}
\tag{5a}
\]
这里没有 \(SX_q\) 粗 bulk 价格。它保留原精确账，避免一次可免的正放松；并非新增来源 \(W\) 付款。其右侧未付组合就是同流的 \(E_{\rm bulk}+J\) 的精确表示。若采用旧记号
\(Q=\int[\log(m_A/M_C(t))-\Phi_t(v,z)]d\mathcal P\)，则
\(E_{\rm bulk}+J=Q+\int\log(M_C(t)/B_{AC}(t))d\mathcal P\)，
不是单独的 \(Q\)。它属于同一 signed 端点/捕获母恒等式，不是独立信用或全局闭合。若在 (5a) 中再用 (4) 的最粗 \(2\sqrt n\) 删除信用，该系数仍与左侧相消。

为对照之前已经放宽 bulk 的版本，写
\[
 \mathcal E_0=\int g_{m_A}(I)d\nu,\qquad R_{\rm cap}=\int I\,d\nu.
\]
忽略 (3) 的非负减项，仅保 (4) 的最粗价格，得
\[
 J\le\mathcal E_0-2\sqrt n(R_{\rm cap}-R).
\tag{5}
\]
代入 R441 同流母比较时，两侧的 \(2\sqrt nR\) 正好抵消：
\[
 -2\log_+M_*R
 \le SX_q+\mathcal E_0-2\sqrt nR_{\rm cap}
             +4rC_dA_nW.
\tag{6}
\]
所以 (4) 的粗质量差系数不能单独给 \(R\) 的收缩。也不能只说过滤很强，便把未过滤 \(\mathcal E_0\) 忽略。

保全部差额时，具体还需要估计 (3) 的实际加权外层积分
\[
 \int g_{m_A}(u)d\nu-\int uD(\widehat p\Vert p)d\nu
              -E_{\rm parent}-E_{\rm terminal},
\tag{7}
\]
或直接利用更尖锐的 (4) 与其一起结算。这里 \(u\) 确含当前阶段、旧来源及原 low-common 信息；现有容量只控制其线性总量，没有给 (7) 的来源 \(W\) 价格。尤其 low-common 控制
\(\int c_v(y)c_v(z)\,dv/m_v\)，而 (7) 中终端捕获 \(z\) 时未必捕获 \(y\)。
不得无证把缺失的 \(c_v(y)\) 添回，也不得用边界体积代替 \(f\)-质量。

这是一条准确的比较边界，不是一般预算。新增核验内容仅是：把原 current/history 接受权保在累计量中后，三项差额的符号仍确切成立，且删除信用无法单独带来收缩；这不证明 R442 之外的可支付全局估计。因此本稿定位为接口与费用核验，不将无门终端帽作为下一步唯一主攻。母账、原 \(R433\) 和旧费用均不修改；停止此方向，不新增局部门。

## 4. 本机检查范围

同前缀 Python 脚本对一个两格、四来源胞的分段常数密度模型，以三个不同的 stage/terminal 接受表做精确符号积分。它保 clipping、实际父/终端来源质量、当前接受率和零权段，验证 (2)–(3) 及非负差额。源胞模型只检积分代数，不认证原几何选择器、octave、严格 \(K^2\) 或完整历史。检查结果与实际运行范围另存同前缀输出。

实际使用指定数学环境运行三表，retained mass 分别为 \(9/2,3,41/30\)。三条 (3) 的符号积分差精确化简为 0；拟合与三个差额的 40 位数值符号诊断均非负。非负性的一般结论来自正文证明，数值诊断不充当区间证书。输出为 `/tmp/r443_mainproof.result.txt`。
