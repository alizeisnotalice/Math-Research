# R443 sharp overlap envelope与实际Jensen价格

实际用指定独立解释器运行`r443_numeric.py`：Python3.12.14、SymPy1.14.0、flint0.9.0、Arb256bit；.22秒、RSS74,203,136字节。无solver、cube样本或history实例。所有输出在脚本同目录，索引为`r443_compute_index.md`。

## 1. prescribed V,L,u的sharp envelope

给有限正测度ν，ν(1)=V，0≤x≤u，∫x dν=L≤uV，0<p<1。严格有

`L u^(−p) ≤ ∫x^(1−p)dν ≤ V^p L^(1−p)`。

上界是凹函数Jensen（或Holder），由常数x=L/V达到。下界来自x^(1−p)≥x u^(−p)，由质量L/u置于u、其余V−L/u置于0达到。零V、零L、零u分别合法处理，不求0/0。这说明在固定V,L,u下，两个界均不能仅靠标量信息改进。

实际核7个小模型×3个p，共21组精确有理attaining witnesses，含moderate、10^−12 tiny mean、10^6 volume、cap saturation和三种zero；Arb核非整数幂，p1/2另保存有理平方端点VL、L²/u。原strict gate实际是x<u；本闭cap试验只描述其放松和可逼近边界，不声称饱和模型满足原strict路径。

## 2. 主决策：实际Jensen，而非linear指数价格

将外层父／oldsource权也合并到同一有限ν后，仍令K_p≤V^pL^(1−p)。原使用式为

`J/R ≤ (1/p) log[K_p/(h(1−p)R)]`
`     ≤ D+[A0−log(1−p)]/p`，

其中D=log(V/L)，A0=log(L/(hR))。p→0的reference mass支配要求L≥hR，即A0≥0；不能在A0<0时把优化算出−∞当好价格。

关键是**D完全不随p改变**。A0>0时令w>1为唯一根

`w−1−logw=A0`。

则最优p=1−1/w，最优第二项恰为w。A0=0时仅p→0取得下确界1。SymPy严格核stationarity和value残差均0、边界limit=1；Arb以60步有理括号核9个非零根及选定有理p。

由massgate x≤u=exp(−2√n)，L≤uV，故D≥2√n。于是仅用sharp envelope所得最佳Jensen价格至少

`Jensen upper coefficient ≥ 2√n+1`。

这是此标量上界机制的价格下限，不是原J的下界。它无法靠p优化给出小于原massgap的可吸收系数。额外实际几何／历史信息仍必须进入L的parent加权总量或更精确的同流比较。

## 3. 三阶段显式常数计算

初步为上述moderate witnesses，压力为zero/tiny/large-volume边界，扩大仅取n=16,64,256,1024。显式输入S=3、eps0=1/4、q=2、r=2、b/a=2、epsilon=.1、R/X=.1；An=1+nlog2，s=1+√n。诊断配置令每父qL=ell，外权上放S X，从而

`Ltotal/(hR)=S eps0 ell/[s(R/X)]`。

这些是抽象sharp finite-measure配置，不声明能由原cube全场同时达到。下表取ell=An、V/L=exp(2√n)。

|n|Ltotal/(hR)|实际Jensen最优p约|J/R价格约|减epsilon√nX后，按X/W=rAn折成nW价格|
|--|--|--|--|--|
|16|18.1355|.822226|13.6251|1.45464|
|64|37.8012|.846270|22.5049|2.05613|
|256|78.7260|.864174|39.3624|3.25696|
|1024|161.5415|.877860|72.1874|5.57900|

另核ell=√n和ell=1，共12条实际Jensen记录。ell=1、n≥64时给定R/X=.1违反p0归一支配；脚本将3条标作不兼容而不求虚假最优。条件正向解释是：若实际能证明ell≤1，则R/X≤S eps0/s=.75/s，n≥43即≤.1。该first-moment改善尚未证明，不能从本试验取得。

所有q在h与qL归一中相消；r保留在粗X/W≤rAn，尺度比保留在An。单靠既有ell≤An没有上述小mass价格。incident旧源可能给另一L界，但不能把其c_v(y)标签免费放到exclusive重叠。

## 4. 仅作旁证的更粗linear价格

脚本还明确保留粗路线`J≤K_p/[p h(1−p)]`的24条系数记录，不把它当实际Jensen价。其p因子为exp(Dp)/[p(1−p)]，唯一最优

`p=2/[D+2+sqrt(D²+4)]`。

在D=2√n、上述四维数，p约.109612,.058609,.030274,.015381，cost/L约24.626,46.294,89.745,176.709；p1/2的指数代价远大。它的p→0趋势与**实际Jensen最优p**不同，不能混写。另仅核一个V/L额外乘1000的诊断；无参数搜索。

## 缺桥与停止

sharp witness证明仅V,L,maxx不足以期待更小普适moment envelope。对当前whole target，至少需要实际parent加权first moment减少／小R质量情形，或保oldsource／current gate得到标量包络之外的同流补偿。上述抽象最坏配置不是原history反例，有限数值不是一般维数阶数证明。脚本、证书保全部输入、误差与标签；交付停止。
