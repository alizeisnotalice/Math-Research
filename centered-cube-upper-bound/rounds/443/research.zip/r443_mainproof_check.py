"""Exact finite clipping algebra; not a native-history realization."""
from fractions import Fraction
import sympy as s

Q = s.Rational
t = s.Symbol("t", positive=True)
# volume, density, in parent, in terminal, cell
atoms = [(Q(1), Q(2), 1, 1, 0),
         (Q(1, 2), Q(5), 1, 1, 1),
         (Q(1, 3), Q(1), 1, 0, 0),
         (Q(2, 3), Q(3), 0, 1, 1)]
breaks = [Q(0), Q(1), Q(2), Q(3), Q(5)]
M = sum(vol*f for vol, f, a, v, c in atoms if a)
mv = sum(vol*f for vol, f, a, v, c in atoms if v)
p = [sum(vol*f for vol, f, a, v, c in atoms if v and c == C)/mv
     for C in range(2)]

def log_integral(expr, lo, hi):
    expr = s.expand(expr)
    b = expr.subs(t, 0)
    a = s.diff(expr, t)
    if a == 0:
        assert b > 0
        return (hi-lo)*s.log(b)
    def primitive(x):
        y = s.simplify(a*x+b)
        return Q(0) if y == 0 else (y*s.log(y)-y)/a
    return s.expand(primitive(hi)-primitive(lo))

def mass(C, side, lo):
    return s.expand(sum(vol*(f if f <= lo else t)
                        for vol, f, a, v, c in atoms
                        if (side == "A" and a or side == "V" and v)
                        and (C is None or C == c)))

patterns = [
    [[1, 1], [1, 1], [1, 1], [1, 1]],
    [[1, 1], [Q(1,2), 1], [Q(1,2), Q(1,3)], [0, Q(1,3)]],
    [[0, Q(1,4)], [Q(2,3), 0], [0, Q(3,4)], [0, Q(1,5)]],
]
for number, pattern in enumerate(patterns, 1):
    current = [Q(0), Q(0)]
    direct = Q(0)
    bulk = Q(0)
    parent = Q(0)
    terminal = Q(0)
    for j, (lo, hi) in enumerate(zip(breaks, breaks[1:])):
        A = mass(None, "A", lo)
        for C in range(2):
            rate = sum(vol*pattern[j][C] for vol, f, a, v, c in atoms
                       if a and v and c == C and f > lo)
            if rate == 0:
                continue
            X, Y = mass(C, "A", lo), mass(C, "V", lo)
            retained = s.expand(current[C]+rate*(t-lo))
            iA, iX, iY, iC = [log_integral(x, lo, hi)
                              for x in [A, X, Y, retained]]
            length = hi-lo
            direct += rate*(iA+iY-iX-length*s.log(mv))
            bulk += rate*(length*s.log(M)-iA)
            parent += rate*(iX-iC)
            terminal += rate*(length*s.log(mv*p[C])-iY)
            current[C] += rate*length
    u = sum(current)
    entropy = u*(1+s.log(M/u))
    fit = sum(x*s.log(x/(u*p[C])) for C, x in enumerate(current) if x)
    difference = s.expand_log(s.expand(
        direct-(entropy-fit-bulk-parent-terminal)), force=True)
    assert s.simplify(difference) == 0
    # These sign evaluations are diagnostics; identity above is symbolic exact.
    evaluated = [s.N(x, 40) for x in [fit, bulk, parent, terminal]]
    assert all(x >= 0 for x in evaluated)
    values = [str(x) for x in evaluated]
    I = sum(vol*f for vol, f, a, v, c in atoms if a and v)
    gap = I*(1+s.log(M/I))-entropy-(I-u)*s.log(M/I)
    assert s.N(gap, 40) >= 0
    print(f"PASS model {number}: retained mass={u}; exact identity; "
          f"diagnostic nonnegative [fit,bulk,parent,terminal]={values}")
print("Scope: 3 finite clipping/acceptance models; exact symbolic identity,")
print("40-digit sign diagnostics; not native selector or original-history certification.")
