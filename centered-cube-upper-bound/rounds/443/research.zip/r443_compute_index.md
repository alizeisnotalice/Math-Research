# R443 bounded计算索引

责任：numeric；只写本前缀，不改作者、repo或新agent。输入只读`r443_contract.md`及root/Astra冻结的实际Jensen、V/L定义与可用占用界。

实际命令：
`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r443_numeric.py`

环境Python3.12.14/SymPy1.14.0/flint0.9.0，Arb256bit。实际.22秒、RSS约74.2MB；无solver或geometry扫描。

计数：
- 7组prescribed measure ×3个p=21组sharp有理witness（含zero/tiny/large-volume）。
- SymPy实际Jensen stationarity/value/zero-A0 limit，以及单独linear粗价optimizer。
- 4个n×3个ell=12条actual Jensen配置，9个Arb有理根括号、3个p0归一不兼容标签；1个A0=0边界点。
- 仅旁证：4个linear p选择、24条linear系数记录，1个额外volume ratio诊断。无宽范围扫参。

归档：`r443_numeric.py`、`r443_numeric_certificate.json`、`r443_numeric_run.txt`、`r443_numeric_resources.txt`、`r443_numeric.md`、本索引，均在`/tmp`。脚本输出自身目录，无作者脚本依赖。

范围：有限measure最优包络、一般标量代数及显式输入价格；非真实cube/history、非全R433认证。主价格为实际Jensen，linear仅更粗旁证。完成停止。

作者接口分工：geometry_check.py以Fraction核3个有限中心模型15项尾身份；mainproof_check.py以SymPy核3组clipping/接受表。两者均实际使用指定独立解释器，stdout分别保存geometry.result.txt和mainproof.result.txt。其40位值只作浮点诊断，不作为严格区间证书。最终隔离复跑不增加覆盖数。
