"""Sharp finite overlap-moment envelopes and bounded p-cost certificates.
No cube realization, original history, LP, or broad parameter scan.
"""
from fractions import Fraction as F
from pathlib import Path
import json,sys,platform
import sympy as sp
from flint import arb,ctx
import flint
ROOT=Path(__file__).resolve().parent;ctx.prec=256

def A(x):
 x=F(x);return arb(str(x.numerator))/arb(str(x.denominator))
def moment(atoms,p):
 return sum((A(v)*A(x)**(1-A(p)) for v,x in atoms if v and x),arb(0))

# Unique minimizer of exp(D p)/(p(1-p)); endpoints diverge.
d,p=sp.symbols('D p',positive=True)
pp=2/(d+2+sp.sqrt(d*d+4))
opt_res=sp.simplify(d-1/pp+1/(1-pp));assert opt_res==0
curvature=sp.diff(d-1/p+1/(1-p),p)
assert sp.simplify(curvature-(1/p**2+1/(1-p)**2))==0

# Actual Jensen optimizer: A0=log(L/(hR)), w=1/(1-p)>1.
w=sp.symbols('w',positive=True);A0=sp.symbols('A0',nonnegative=True)
gexpr=(A0-sp.log(1-p))/p
jstationary=sp.simplify(sp.diff(gexpr,p).subs(A0,w-1-sp.log(w)).subs(p,1-1/w))
jvalue=sp.simplify(gexpr.subs(A0,w-1-sp.log(w)).subs(p,1-1/w)-w)
assert jstationary==0 and jvalue==0
jboundary=sp.limit(-sp.log(1-p)/p,p,0,dir='+');assert jboundary==1

# Stage 1 moderate, Stage 2 zeros/tiny mean/large volume/saturation.
specs=[('moderate',F(4),F(1),F(1,2)),
 ('tiny_mean',F(1),F(1,10**12),F(1,2)),
 ('large_volume',F(10**6),F(1),F(1,10)),
 ('cap_saturation',F(8),F(1),F(1,8)),
 ('zero_moment_positive_volume',F(5),F(0),F(1,2)),
 ('zero_measure',F(0),F(0),F(1,2)),
 ('zero_cap',F(5),F(0),F(0))]
witness=[]
for label,V,L,u in specs:
 assert 0<=L<=u*V
 for p0 in [F(1,4),F(1,2),F(3,4)]:
  if not L:
   upper=lower=arb(0);upatoms=[(V,F(0))];loatoms=upatoms
  else:
   upatoms=[(V,L/V)];loatoms=[(L/u,u),(V-L/u,F(0))]
   assert all(v>=0 and 0<=x<=u for v,x in upatoms+loatoms)
   for atoms in [upatoms,loatoms]:
    assert sum((v for v,x in atoms),F(0))==V
    assert sum((v*x for v,x in atoms),F(0))==L
   upper=A(V)**A(p0)*A(L)**(1-A(p0))
   lower=A(L)*A(u)**(-A(p0))
   assert (moment(upatoms,p0)-upper).contains(0)
   assert (moment(loatoms,p0)-lower).contains(0)
   if L<u*V:assert upper-lower>0
   else:assert (upper-lower).contains(0)
   if p0==F(1,2):
    # Exact rational squared endpoints, independent of Arb powers.
    assert (L/u)**2*u==L*L/u
  witness.append({'label':label,'V':str(V),'L':str(L),'max_x':str(u),'p':str(p0),
   'sharp_upper_Arb':str(upper),'sharp_lower_Arb':str(lower),
   'upper_attaining_atoms':[[str(v),str(x)] for v,x in upatoms],
   'lower_attaining_atoms':[[str(v),str(x)] for v,x in loatoms],
   'exact_half_squared_upper':str(V*L) if p0==F(1,2) else None,
   'exact_half_squared_lower':str(L*L/u) if p0==F(1,2) and u else '0' if not L else None})
 print(label,'V',V,'L',L,'u',u)

# Stage 3: static-gate minimum possible D and linear-moment route cost.
# Normalized v=qV, ell=qL; h=s/(eps0*q), X/W=chi.
# Kp/h(1-p)/p <= S eps0 X/s * ell exp(Dp)/(p(1-p)).
S=F(3);eps0=F(1,4);r=F(2);q=F(2);epsilon=F(1,10)
expansion=[];pchoices=[]
for n in [16,64,256,1024]:
 sn=A(n).sqrt();s=1+sn;An=1+A(n)*A(2).log();D=2*sn;u=(-D).exp()
 popt=2/(D+2+(D*D+4).sqrt())
 selected=F(round(float(popt.mid())*10**12),10**12)
 pa=A(selected);cost=(D*pa).exp()/(pa*(1-pa));optcost=(D*popt).exp()/(popt*(1-popt))
 assert cost-optcost>0
 halfcost=4*(D/2).exp();assert halfcost-cost>0
 pchoices.append({'n':n,'D':'2sqrt(n)','u_Arb':str(u),'analytic_opt_p_Arb':str(popt),
  'selected_rational_p':str(selected),'normalized_cost_per_ell_Arb':str(cost),
  'analytic_optimum_cost_per_ell_Arb':str(optcost),
  'half_cost_per_ell_Arb':str(halfcost),'strict_saving_vs_half_Arb':str(halfcost-cost)})
 for ellname,ell in [('occupancy_An',An),('root_scale',sn),('unit_first_moment',arb(1))]:
  # Saturated gate mean u: v=ell/u. This is an abstract sharp witness,
  # not an assertion that actual cube geometry attains these V,L together.
  for chiname,chi in [('X_over_W_1',arb(1)),('crude_X_over_W_rAn',A(r)*An)]:
   coeffX=A(S)*A(eps0)/s*ell*cost
   coeff_root=coeffX/sn
   ratio_nW=coeffX*chi/A(n)
   residual_nW=(coeffX-A(epsilon)*sn)*chi/A(n)
   expansion.append({'n':n,'S_input':str(S),'eps0_input':str(eps0),'r_input':str(r),
    'q_input':str(q),'epsilon_input':str(epsilon),'scale_ratio_input':'2',
    'ell_qL_profile':ellname,'ell_qL_Arb':str(ell),
    'v_qV_Arb':str(ell/u),'X_over_W_profile':chiname,'X_over_W_Arb':str(chi),
    'selected_p':str(selected),'linear_moment_J_upper_coefficient_X_Arb':str(coeffX),
    'linear_moment_J_upper_over_sqrt_n_X_Arb':str(coeff_root),
    'linear_moment_J_upper_over_nW_Arb':str(ratio_nW),
    'price_after_epsilon_sqrt_n_X_over_nW_Arb':str(residual_nW)})
 print('n',n,'p*~',popt,'selected',selected,'opt cost/ell',cost,
       'half cost/ell',halfcost)
# An excess-volume diagnostic uses same n, with prescribed V/L larger by 1000.
n=256;D=2*A(n).sqrt()+A(1000).log();pa=2/(D+2+(D*D+4).sqrt())
extra={'n':n,'v_over_ell_input':'1000 exp(2sqrt(n))','D_Arb':str(D),
 'optimal_p_Arb':str(pa),'optimal_cost_per_ell_Arb':str((D*pa).exp()/(pa*(1-pa)))}
# Main decision: actual Jensen price, not the rough linear exponential price.
# A0=log(Ltotal/(h R))=log(C0). For C0>=1, D is independent of p.
jensen=[];rho=F(1,10)
for n in [16,64,256,1024]:
 sn=A(n).sqrt();s=1+sn;An=1+A(n)*A(2).log();D=2*sn
 for ellname,ell in [('occupancy_An',An),('root_scale',sn),('unit_first_moment',arb(1))]:
  C0=A(S)*A(eps0)*ell/(s*A(rho))
  mass_ref=A(S)*A(eps0)*ell/s
  row={'n':n,'ell_profile':ellname,'R_over_X_input':str(rho),
       'S_input':str(S),'eps0_input':str(eps0),'q_input':str(q),'r_input':str(r),
       'C0_Ltotal_over_hR_Arb':str(C0),
       'p0_mass_bound_R_over_X_Arb':str(mass_ref),'D_Arb':str(D)}
  if C0<1:
   row.update({'normalization_compatible':False,
    'reason':'Assumed R/X exceeds p->0 reference-mass upper bound. Do not optimize to a spurious minus infinity.'})
   jensen.append(row);continue
  assert C0>1
  aa=C0.log();left,right=F(1),F(100)
  fun=lambda w:A(w)-1-A(w).log()-aa
  assert fun(left)<0 and fun(right)>0
  for _ in range(60):
   mid=(left+right)/2;val=fun(mid)
   if val<0:left=mid
   elif val>0:right=mid
   else:raise AssertionError('insufficient root precision')
  wm=(left+right)/2
  chosen=F(round(float(1-1/A(wm).mid())*10**12),10**12)
  pp=A(chosen);g=(aa-(1-pp).log())/pp
  assert g-A(left)>0 and A(right)+A(F(1,10**8))-g>0
  assert 2*(C0*2).log()-g>0
  J_R=D+g;chi=A(r)*An
  row.update({'normalization_compatible':True,'w_root_left_exact':str(left),
    'w_root_right_exact':str(right),'selected_p':str(chosen),
    'J_over_R_at_selected_p_Arb':str(J_R),
    'optimal_J_over_R_bracket_Arb':[str(D+A(left)),str(D+A(right))],
    'J_over_R_at_half_Arb':str(D+2*(C0*2).log()),
    'strict_massgate_absorption_margin_2sqrt_n_minus_price_Arb':str(2*sn-J_R),
    'X_over_W_profile':'r A_n (explicit crude sourcewise bound)',
    'Jensen_J_over_nW_at_rAn_Arb':str(A(rho)*chi*J_R/A(n)),
    'after_epsilon_sqrt_n_X_over_nW_at_rAn_Arb':str(chi*(A(rho)*J_R-A(epsilon)*sn)/A(n))})
  assert 2*sn-J_R<0
  jensen.append(row)
 print('actual Jensen n',n,[(z['ell_profile'],z['normalization_compatible'],z.get('selected_p')) for z in jensen if z['n']==n])
# Boundary C0=1: infimum g=1 at p->0, not a zero or free price.
ptest=F(1,10**6);boundary_g=-(1-A(ptest)).log()/A(ptest)
assert boundary_g>1
boundary={'C0':'1','infimum_g':'1','attainment':'p->0 only','tested_p':str(ptest),
          'tested_g_Arb':str(boundary_g)}
report={'environment':{'executable':sys.executable,'python':platform.python_version(),
 'sympy':sp.__version__,'flint':flint.__version__,'Arb_bits':ctx.prec},
 'sharp_envelope':'L u^(-p) <= integral x^(1-p) dnu <= V^p L^(1-p), 0<p<1, 0<=L<=uV',
 'symbolic_p_stationarity_residual':str(opt_res),'actual_Jensen_stationarity_residual':str(jstationary),'actual_Jensen_optimal_value_residual':str(jvalue),'actual_Jensen_A0_zero_limit':str(jboundary),'log_cost_curvature':str(curvature),
 'finite_witnesses':witness,'p_choices':pchoices,'expanded_cost_records':expansion,
 'one_excess_volume_diagnostic':extra,'actual_Jensen_cases':jensen,'Jensen_C0_one_boundary':boundary,
 'scope':'Sharp finite envelopes, actual Jensen route, and a separately labelled rough linear route. No original cube/history attainment or global-order inference.'}
(ROOT/'r443_numeric_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print('Actual Jensen cases:',len(jensen),'symbolic stationarity/value residuals:',jstationary,jvalue,'C0=1 limit:',jboundary)
print('PASS:',len(witness),'sharp witnesses,',len(pchoices),'dimension choices,',len(expansion),'explicit coefficient records; one excess-volume diagnostic.')
