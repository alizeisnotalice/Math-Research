# R443 — the two-terminal test and the unresolved joint center sum

**Outcome.** No new original-flow payment is proved. The bounded attempt keeps both actual terminal centers and the old source, rather than replacing the old-source law by S at the outset. It identifies exactly where terminal separation fails to provide the needed summable source budget. The original J and mother ledger remain unchanged.

## 1. The joint candidate

Use the same complete original lifted measure P as in the R443 contract. Denote its old-source terminal by w and new-source terminal by v. These are the two actual fixed-source paths, not refreshed receiver posteriors. Put

\[
 F=\log\frac{m_t(A)B_{v,C(z)}(t)}{m_vB_{A,C(z)}(t)}.
\]

For the attempted exponential estimate, retain a fixed, jointly measurable static indicator G(A,w,v) which equals one on the projected original records. It may retain the true parent-terminal mass gaps, terminal centers outside the parent, and mutual terminal-center separation. A generation-dependent condition must retain its generation label; it is omitted here rather than silently made a function of A,w,v. Let \(\omega_{A,w,v}(y,z)\) similarly retain necessary static source restrictions, including original low-common and terminal own-low conditions. Neither indicator contains the current stage, early factor or current occupancy.

Define
\[
 I_{Av}^{w,y}=\int f(z)c_A(z)c_v(z)\omega_{A,w,v}(y,z)\,dz,
 \qquad \rho_y(dw)=c_w(y)\frac{dw}{m_w},
\]
\[
 \mathcal B_p=
 \sum_e\int\sigma(dA)\pi_A(dy)a_0^e(A,y)
 \int\rho_y(dw)\int G(A,w,v)
       \left(\frac{I_{Av}^{w,y}}{m_A}\right)^{1-p}\frac{dv}{m_v},
 \quad 0<p<1.
 \tag{1}
\]
The valid bound is
\[
 \int e^{pF}\,dP\le\frac{\mathcal B_p}{h^2(1-p)}.
 \tag{2}
\]
This is only a positive upper relaxation; there is no assertion that it is an easier or necessary formulation of the original target.

To prove (2), condition first on the complete original starting record. The unfiltered two generated chains are independent conditional on that record. Each starts own-high and has whole-terminal law bounded by its fixed-source own-low measure divided by h. Delete future restrictions only in a positive upper bound, then use the product of these two bounds. It is not legitimate to declare the future-filtered terminal laws independent. Retain the static G and omega supports in the dominating product measure. At each clipping level t only one stage contributes; original nestedness gives \(a_i^e\le a_0^e\). The resulting projected bound has density
\[
 \frac1{h^2}\sigma(dA)\pi_A(dy)a_0^e(A,y)\rho_y(dw)
 \frac{dv}{m_v}G(A,w,v)
 \frac{c_A(z)c_v(z)}{m_A}1_{f(z)>t}
 \omega_{A,w,v}(y,z)\,dz\,dt.
 \tag{3}
\]
Both own-low indicators can be retained in omega. Apply the R442 mixed primitive separately for each fixed A,y,w,v and sum cells. Its endpoint is \(m_A^p(I_{Av}^{w,y})^{1-p}/(1-p)\); the parent factor \(1/m_A\) in (3) gives (1). The displayed sum already contains the two original endpoint directions. No further factor two or stage count occurs. All quantities are finite under the finite E and positive minimum mass contract.

## 2. The attempted geometric gain and its precise limit

The intended gain was to integrate the two captured source masses jointly, using the mutual separation of the actual terminal centers. The critical issue is that center separation does not imply disjoint f-capture. The source-overlap restriction on the **initial** double witnesses cannot be passed to their descendants. Thus neither

\[
 f(Q_A\cap Q_w)+f(Q_A\cap Q_v)\le m_A
 \quad\text{nor}\quad f(Q_w\cap Q_v)\ll\min(m_w,m_v)
\]

is available for the two terminal cubes merely from the retained geometric separation. No such inequality is used in (1)–(3).

Even if one separately retains an actually certified cross-source-exclusion event, its two captured masses are
\[
 I_- = f(Q_A\cap Q_w\setminus Q_v),\qquad
 I_+ = f(Q_A\cap Q_v\setminus Q_w),\qquad I_-+I_+\le m_A.
\]
After the additional relaxation of the old-source density by S, its pair integrand is bounded by
\[
 S\frac{I_-}{m_A}\left(\frac{I_+}{m_A}\right)^{1-p}
       \frac{dw\,dv}{m_wm_v}.
 \tag{4}
\]
The pointwise mass-sum constraint does not bound the sum of (4) over actual receiver pairs: different pairs may reuse the same source subsets. Such an event is not asserted to exhaust the original flow. Equation (4) records the attempted matching mechanism, not an additional payment or a transferred history condition.

The one missing step for this route is a joint actual-center summability estimate for (1), retaining enough of the original old-source/current weighting to control this repeated capture. A scalar bound for either overlap, a per-path frame bound, or a product of single-source occupancy bounds does not supply that estimate. In particular the second terminal cap does not remove the starting-record multiplicity; it introduces a second actual receiver integral and a factor h^{-1}. We have not shown that this trade improves the original fee. Consequently no new named remainder is introduced.

## 3. Why the low-common column cannot simply replace that sum

This subsidiary calculation is a scope test, not a paid original-flow branch. For fixed A,y, write x_v=I^omega_Av(y)/m_A, and restrict to receivers with c_v(y)=1 and the true mass gate. If omega retains C_A(y,z)<h, Tonelli gives
\[
 \int c_v(y)x_v\frac{dv}{m_v}\le h,
 \qquad \int c_v(y)\frac{dv}{m_v}\le J(y)\le A_n/q.
\]
Thus the incident fractional moment is at most
\[
 J(y)^p\min\{h,J(y)/K^2\}^{1-p},
 \tag{5}
\]
where the second term uses x_v≤m_v/m_A<K^{-2}. The same proof is invalid on c_v(y)=0: inserting c_v(y) would delete exactly those receivers. If the complete original path labels already force this exclusion, the incident part is empty on that flow; (5) is still only a test of the low-common mechanism. No conclusion about that historical cross-incidence is guessed here.

A proposed transfer of excluding receivers to y-capturing receivers would have to preserve actual center measure and the true masses f(Q_v), with a proved integrated multiplicity bound. Translating or enlarging a cube need not produce an actual receiver or preserve its matching mass. No such transfer was constructed in this attempt.

## 4. Executed native scope check

`/tmp/r443_geometry_check.py` was run using the local math-research-tools Python; stdout is `/tmp/r443_geometry.result.txt`. Three fixed dimensions n=16,36,64 were checked exactly with Fraction arithmetic, including 15 strict superlevel-tail identities.

The native model has f=1 on [-3,3]^n, parent centers in [-1/100,1/100]^n with side 2, and two child center blocks
\[
 \pm[6/5,5/4]\times[-1/100,1/100]^{n-1}
\]
with side 1. Matching is exact with q=1. The tested parent is A=0 and old source is y=(-3/4,0,...,0). Both child center blocks are outside Q_A; the left block captures y and the right block does not. Both have identical distributions of the actual parent-overlap ratio
\[
 \frac{f(Q_A\cap Q_v)}{m_A}
 =\frac{3/2-|v_1|}{2^n}.
\]
The strict mass gap 2^n>K^2 is certified using e<3 at these square dimensions. Total small-receiver occupancy is below the auxiliary cutoff 1, hence also below the original h=s/(eps0 q)>1 at q=1 and 0<eps0≤1/2. The fixture does not set the original h equal to 1; this verifies only the low-common upper inequality. The receivers are genuine positive-volume center sets; side lengths are fixed on each block.

This check confirms that the capture-incidence label must be retained separately from the parent-overlap distribution. It is **not** a counterexample to the desired budget. The original high-rank/history qualification is not satisfied or claimed. No conclusion about the complete original flow follows from this fixture. The analytic claim proved in this attachment is (2); its missing global price remains explicit in Section 2.
