from fractions import Fraction as F
from math import isqrt
import json
# A native fixed-side receiver model. f=1 on [-3,3]^n, zero elsewhere.
# Parent centers: [-1/100,1/100]^n, side 2.
# Child centers: +/-[6/5,5/4] x [-1/100,1/100]^(n-1), side 1.
# Row tested: A=0, y=(-3/4,0,...,0). No original rank/history claim.
rows=[]
for n in (16,36,64):
    assert isqrt(n)**2==n
    # e<3 proves the strict K^2 mass gap without numerical exponentials.
    assert 2**n>3**(2*isqrt(n))
    tr=F(1,50)**(n-1)
    lo,hi=F(6,5),F(5,4)
    mass=2**n
    capacity=(hi-lo)*tr
    assert 2*capacity<1 # low-common < h=1 for every source pair
    # Left children contain y; right children exclude it. Both lie outside QA.
    assert hi-F(3,4)<=F(1,2)
    assert lo+F(3,4)>F(1,2)
    assert lo>1
    threshold_checks=[]
    for c in (F(6,25),F(1,4),F(11,40),F(3,10),F(31,100)):
        cut=F(3,2)-c
        exact_length=max(F(0),min(hi,cut)-lo)
        # Independent exact cell partition and midpoint evaluation; boundaries null.
        ends=sorted({lo,hi,*([cut] if lo<cut<hi else [])})
        partition_length=sum((b-a for a,b in zip(ends,ends[1:])
                              if F(3,2)-(a+b)/2>c),F(0))
        assert exact_length==partition_length
        threshold_checks.append({'scaled_threshold':str(c),'each_tail':str(tr*exact_length)})
    first=tr*(F(3,2)*(hi-lo)-(hi*hi-lo*lo)/2)/mass
    midpoint=capacity*(F(3,2)-(hi+lo)/2)/mass
    assert first==midpoint>0
    rows.append({'n':n,'each_capacity':str(capacity),'each_first_moment':str(first),
                 'incident_and_exclusive_tails_equal':True,'tails':threshold_checks,
                 'full_history_certified':False})
print(json.dumps({'models':rows,'status':'PASS',
 'scope':'Three exact native matched-center row models; 15 tail identities. Not original high-rank/history models; not a budget counterexample.'},indent=2))
