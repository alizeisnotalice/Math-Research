from fractions import Fraction as F
from itertools import product
ct=0
for lo,hi,s in product([F(1),F(3,2)],[F(2),F(5,2)],
                       [F(5,4),F(3,2),F(2)]):
 for good,bad in product([F(k,16) for k in range(1,65)],repeat=2):
  if good<hi and bad>=lo and bad<s*good:
   assert lo/s<good<s*hi and lo/s<bad<s*hi
   ct+=1
print('PASS forest_window_cases',ct)  # actual: 5194
