#!/usr/bin/env python3
"""R306 exact binary scale-split and forest-window diagnostics on real L1 cells and shells."""
import json,random,sys,hashlib
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
from math import lcm,isqrt
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
R=random.Random(30120261018);COUNTS={};FAIL=[]
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'data':data})
def cellvol(h,n):return F(2*h,32)**n
def make(name,n,kind):
 if kind=='disjoint':
  X=[(0,0),(128,0),(256,0)];eh=[1,2,1];ls=[32]*3;rs=[32]*3
  Y=[(v,4) for v in [4,132,260,452]];Z=list(Y)
 elif kind=='chain':
  X=[(-16,0),(0,0),(16,0)];eh=[1,2,1];ls=[32,48,64];rs=[32,32,48]
  Y=[(v,4) for v in [-28,-12,4,20,36,100]];Z=list(Y)
 else:
  X=[(0,0),(16,0),(0,16),(16,16)];eh=[1,2,2,1] if n>=8 else [1,2,1,2]
  ls=[32,48,64,32];rs=[48,32,64,48]
  if kind=='tied':ls=rs=[32]*4
  Y=[(x,y) for x in [-12,4,20,36] for y in [-12,4,20,36]]
  Z=[(-12,-12),(4,4),(20,4),(4,20),(20,20),(36,20),(100,100)]
 if n==1:X=[[x] for x,y in X];Y=[[x] for x,y in Y];Z=[[x] for x,y in Z]
 else:X=[list(v)+[0]*(n-2) for v in X];Y=[list(v)+[4]*(n-2) for v in Y];Z=[list(v)+[4]*(n-2) for v in Z]
 def incidence(points,sides,label):
  A=[]
  for i,(x,s,h) in enumerate(zip(X,sides,eh)):
   row=[]
   for j,z in enumerate(points):
    inside=all(2*(abs(a-b)+h+1)<=s for a,b in zip(x,z));outside=any(2*(abs(a-b)-h-1)>s for a,b in zip(x,z))
    ck(inside or outside,label,{'case':name,'receiver':i,'source_cell':j});row.append(int(inside))
   A.append(row)
  return A
 soft=incidence(Y,ls,'exact_soft_pair_whole_inside_or_outside');hard=incidence(Z,rs,'exact_hard_pair_whole_inside_or_outside')
 for tag,points,hs in [('E',X,eh),('Y',Y,[1]*len(Y)),('Z',Z,[1]*len(Z))]:
  ck(all(any(abs(z[k]-w[k])>=hs[j]+hs[l] for k in range(n)) for j,z in enumerate(points) for l,w in enumerate(points[:j])),'positive_cells_disjoint_'+tag,{'case':name})
 vol=[cellvol(h,n) for h in eh];L=[F(s,32) for s in ls];rr=[F(s,32) for s in rs]
 br=[F(R.randint(1,10),R.randint(1,10)) for _ in Y];vr=[F(R.randint(1,10),R.randint(1,10)) for _ in Z]
 bresp=[sum(v*a for v,a in zip(br,row))/l**n for row,l in zip(soft,L)];bscale=1/max(bresp);beta=[bscale*v for v in br]
 vresp=[sum(v*a for v,a in zip(vr,row))/r**n for row,r in zip(hard,rr)];vscale=4/max(vresp);nu=[vscale*v for v in vr]
 first=[sum(v*a for v,a in zip(beta,row))/l**n for row,l in zip(soft,L)];hardresp=[sum(v*a for v,a in zip(nu,row))/r**n for row,r in zip(hard,rr)]
 for i,(f,h) in enumerate(zip(first,hardresp)):
  ck(f<=1,'actual_FIRST_q1',{'case':name,'receiver':i,'response':str(f)})
  ck(h<=4,'actual_same_radius_hardcap_lambda1',{'case':name,'receiver':i,'response':str(h)})
 I=[sum(vol[i]*soft[i][j]/L[i]**n for i in range(len(X))) for j in range(len(Y))]
 pi=[[vol[i]*soft[i][j]/L[i]**n/ij if ij else F(0) for i in range(len(X))] for j,ij in enumerate(I)]
 ck(sum(b*ij for b,ij in zip(beta,I))==sum(v*f for v,f in zip(vol,first))<=sum(vol),'FIRST_integrated_rowI_identity',{'case':name})
 return {'name':name,'n':n,'X':X,'Ehalf':eh,'Y':Y,'Z':Z,'L':L,'R':rr,'soft':soft,'hard':hard,'vol':vol,'beta':beta,'nu':nu,'first':first,'hardresp':hardresp,'I':I,'pi':pi}
def shell(n):
 delta=F(1,100*n);m=min(4*n,16);rr=[1+F(i,m) for i in range(m+1)];vol=[];prev=F(0)
 for r in rr:
  v=(r-2*delta)**n;vol.append(v-prev);prev=v
 ck(all((r-2*delta)/2+delta==r/2 for r in rr),'shell_actual_full_source_inclusion',{'n':n})
 return {'name':'concentric_shell_n'+str(n),'n':n,'vol':vol,'L':rr,'R':rr,'soft':[[1] for r in rr],'hard':[[1] for r in rr],'beta':[F(1)],'nu':[F(4)],'first':[r**(-n) for r in rr],'hardresp':[4*r**(-n) for r in rr],'geometry':{'type':'centered_disjoint_shells','delta':delta,'m':m,'source_side':2*delta,'source_center':0,'receiver_shell_sides':'E0=Q_(1-2delta); Ei=Q_(Li-2delta) minus Q_(L_(i-1)-2delta); Li=Ri=1+i/m'}}
SVALUES=[F(5,4),F(3,2),F(33,32)]
def real_split(c,mode):
 n=c['n'];name=c['name']+'_'+mode;nu=c['nu'];radii=sorted(set(c['R']+[F(2)]));weights=[r**(-n)-(radii[k+1]**(-n) if k+1<len(radii) else 0) for k,r in enumerate(radii)];layers=[];T=F(0)
 for j,beta in enumerate(c['beta']):
  u=[v*c['soft'][i][j]/c['L'][i]**n for i,v in enumerate(c['vol'])];den=lcm(*(a.denominator for a in u));ints=[a.numerator*(den//a.denominator) for a in u]
  chi=[[c['hard'][i][z]*(1 if mode=='allone' else int((i+2*j+3*z)%3!=0)) for z in range(len(nu))] for i in range(len(u))]
  T+=beta*sum(u[i]*sum(v*chi[i][z] for z,v in enumerate(nu))/c['R'][i]**n for i in range(len(u)))
  for r,w in zip(radii,weights):
   ids=[i for i,ri in enumerate(c['R']) if ri<=r];J=sum((u[i] for i in ids),F(0));A=[sum((u[i]*chi[i][z] for i in ids),F(0)) for z in range(len(nu))];M=sum(v*a for v,a in zip(nu,A));Q=J*M-sum(v*a*a for v,a in zip(nu,A));splits={s:[F(0),F(0),F(0)] for s in SVALUES}
   for s in SVALUES:
    for z,v in enumerate(nu):
     nums=[0,0,0]
     for i in ids:
      if not chi[i][z]:continue
      for k in ids:
       if chi[k][z]:continue
       loss=c['R'][k]>=s*c['R'][i];gain=c['R'][i]>=s*c['R'][k];bucket=0 if loss else 1 if gain else 2
       ck(not(loss and gain),'real_scale_far_categories_disjoint',{'case':name})
       if c['R'][i]==c['R'][k]:ck(bucket==2,'actual_same_radius_ties_are_near',{'case':name})
       nums[bucket]+=ints[i]*ints[k]
     for p,num in enumerate(nums):splits[s][p]+=v*F(num,den**2)
    ck(sum(splits[s])==Q,'exact_ordered_binary_Q_scale_partition',{'case':name,'row':j,'r':str(r),'s':str(s)})
   layers.append({'j':j,'beta':beta,'r':r,'w':w,'J':J,'M':M,'Q':Q,'splits':splits})
 directT=sum(l['beta']*l['w']*l['M'] for l in layers);ck(T==directT,'actual_marked_fullmoment_equals_radial_layer_integral',{'case':name})
 js=sorted(set(l['J'] for l in layers if l['J']));Hs=sorted(set([js[0],js[len(js)//2]]));records=[]
 for H in Hs:
  for s in SVALUES:
   loss=gain=near=F(0);B=F(0)
   for l in layers:
    if l['J']<H:continue
    p=l['beta']*l['w']/l['J'];loss+=p*l['splits'][s][0];gain+=p*l['splits'][s][1];near+=p*l['splits'][s][2];B+=p*l['Q']
   ck(loss+gain+near==B,'exact_global_binary_BH_scale_decomposition',{'case':name,'H':str(H),'s':str(s)})
   ck(loss<=s**(-n)*T,'exact_real_far_loss_le_s_minus_n_actual_fullmoment',{'case':name,'H':str(H),'s':str(s)})
   records.append({'H':H,'s':s,'BH':B,'far_loss':loss,'far_gain':gain,'near':near,'actual_T':T,'far_loss_bound':s**(-n)*T})
 geometry=c['geometry'] if 'geometry' in c else {'coordinate_denominator':32,'receiver_centers_num':c['X'],'receiver_halfwidth_num':c['Ehalf'],'beta_centers_num':c['Y'],'nu_centers_num':c['Z'],'source_halfwidth_num':1}
 return {'name':name,'n':n,'receiver_count':len(c['vol']),'beta_rows':len(c['beta']),'nu_cells':len(nu),'geometry':geometry,'L':c['L'],'R':c['R'],'receiver_volumes':c['vol'],'beta_masses':c['beta'],'nu_masses':nu,'soft_incidence':c['soft'],'hard_incidence':c['hard'],'records':records}
def forest_windows(n):
 sq=isqrt(n);assert sq*sq==n;gamma=1+F(1,n);qminus=F(3,4);b=F(2);cases=[];reverse=endpoint=pairchecks=opposite_unpaid=0
 def tau2n(h,q):return min((h/q)**2,b**n*h/(q*sq))
 for kmin in [F(3,4),F(1),F(5,4)]:
  kmax=gamma*kmin;configs=[]
  for k in sorted(set([kmin,(kmin+kmax)/2,kmax])):
   for r in [F(1),F(5,4),F(3,2),F(7,4),F(2)]:
    L=k*k*r
    if not 1<=L<=2:continue
    for q in [qminus,F(7,8),F(1)]:
     g=k*r;threshold=q*max(g**n,sq*(g*g/b)**n);configs.append({'k':k,'R':r,'L':L,'q':q,'g':g,'threshold':threshold})
  hs=sorted(set([F(1,4),F(1),F(4),F(16),F(64)]+[x['threshold'] for x in configs[::max(1,len(configs)//5)]]))
  for h in hs:
   minus=tau2n(h,F(1))/kmax**(2*n);plus=tau2n(h,qminus)/kmin**(2*n)
   ck(plus/minus<=gamma**(2*n)*F(4,3)**2,'exact_forest_window_power_width',{'n':n,'kmin':str(kmin),'h':str(h)})
   good=[];bad=[]
   for item in configs:
    e=int(h>item['threshold']);rpow=item['R']**(2*n);gpow=item['g']**(2*n)
    ck(bool(e)==(gpow<tau2n(h,item['q'])),'exact_forest_gate_equals_power_root_cut',{'n':n})
    ck((e and rpow<plus) or (not e and rpow>=minus),'exact_forest_good_upper_bad_lower_window',{'n':n})
    ck((e==0)==(h<=item['threshold']),'forest_else_is_full_complement',{'n':n})
    if h==item['threshold']:
     endpoint+=1;ck(not e and gpow==tau2n(h,item['q']),'strict_forest_gate_equality_is_bad',{'n':n})
    (good if e else bad).append(item)
   for s in SVALUES:
    # Deterministic bounded subcollection of actual retained (L,R,k,q) pairs.
    opposite_unpaid+=sum((x['k']>=1)!=(y['k']>=1) for x in good for y in bad)
    pairs=[(x,y) for x in good for y in bad if (x['k']>=1)==(y['k']>=1)];stride=max(1,len(pairs)//32)
    for x,y in pairs[::stride][:40]:
     rg=x['R'];rb=y['R']
     if rb<s*rg:
      pairchecks+=1;reverse+=int(rb<rg)
      ck(all(minus/s**(2*n)<=r**(2*n)<=s**(2*n)*plus for r in [rg,rb]),'exact_good_bad_near_pair_common_window',{'n':n,'s':str(s),'Rgood':str(rg),'Rbad':str(rb)})
     else:ck(rb>=s*rg,'forest_far_loss_else_complement',{'n':n})
   cases.append({'kmin':kmin,'kmax':kmax,'h':h,'tau_minus_power2n':minus,'tau_plus_power2n':plus,'good_configs':len(good),'bad_configs':len(bad),'retained_configs':len(configs)})
 return {'n':n,'gamma':gamma,'sqrt_n':sq,'configuration_recipe':'k in{kmin,(kmin+kmax)/2,kmax}; R in{1,5/4,3/2,7/4,2}; retainL=k^2R in[1,2]; each q=3/4,7/8,1. h menu contains1/4,1,4,16,64 and evenly indexed actual gate thresholds.','root_power':'tau_q^(2n)=min((h/q)^2,2^n*h/(q*sqrt n))','gate_cases':cases,'near_pair_window_checks':pairchecks,'opposite_orientation_pair_configurations_unpaid':opposite_unpaid,'reverse_ordered_near_pairs':reverse,'strict_threshold_equality_tests':endpoint}
def encode(x):
 if isinstance(x,F):
  if x.numerator.bit_length()+x.denominator.bit_length()<=1250:return str(x)
  num=abs(x.numerator).to_bytes(max(1,(abs(x.numerator).bit_length()+7)//8),'big');den=x.denominator.to_bytes(max(1,(x.denominator.bit_length()+7)//8),'big')
  with localcontext() as ctx:ctx.prec=60;val=str(Decimal(x.numerator)/Decimal(x.denominator))
  return {'decimal60':val,'exact_binary_rational_sha256':hashlib.sha256(bytes([x.numerator<0])+len(num).to_bytes(8,'big')+num+den).hexdigest()}
 raise TypeError(type(x).__name__)
settings=[('initial',[('disjoint_n1',1,'disjoint'),('overlap_chain_n1',1,'chain')]),('same_radius_and_boundary',[('cross_n4',4,'cross'),('tied_n4',4,'tied')]),('expanded_short_menu',[('cross_n8',8,'cross'),('cross_n16',16,'cross')])];stages=[]
for stage,specs in settings:
 models=[make(name,n,kind) for name,n,kind in specs]
 if stage=='expanded_short_menu':models += [shell(n) for n in [16,32]]
 stages.append({'name':stage,'real_cases':[real_split(c,mode) for c in models for mode in ['binary_varying','allone']]})
forest=[forest_windows(n) for n in [1,4,16,64]]
out={'status':'PASS' if not FAIL else 'FAIL','real_geometry_scope':'Actual s=0 positive-L1 cell/shell models, FIRST<=1 and same-radius hardcap<=4. Shell menus m=min(4n,16); not original full low/e/m/history or full maximal-hardcap. Binary masks are frozen geometry-index diagnostics, not claimed original forest history.','scale_split':'Ordered pairs good u captured, bad w not captured. farloss Rw>=sRu; fargain Ru>=sRw; else near. Ties are near. BH=sum_(J>=H) beta layerweight/J sum_(u,w) Uu Uw nu chi_u(1-chi_w). Farloss<=s^-n actual full marked moment T. H retains min/median positive original J atoms.','forest_scope':'Separate exact scalar forest-cut algebra; no full forest is constructed and no arbitrary incidence matrix is called real geometry. Actual retained rational L=k^2R,R in[1,2],k=g/R in[kmin,gamma*kmin],q in{3/4,7/8,1}.','forest_gate':'Hq(g)=q max(g^n,sqrt n(g^2/2)^n),e=1{h>Hq(g)}. tau_minus=tau_lambda/kmax,tau_plus=tau_(3/4)/kmin; all comparisons in power2n. Good R<tau_plus,bad R>=tau_minus; only same-band same-orientation good/bad pair Rbad<s Rgood is tested to imply both in[tau_minus/s,s tau_plus]. Else complement exact. Crossband and opposite-orientation pairs remain unpaid by the narrow-window argument. Equal aspect k=1 is assigned to L>=R.','serialization':'Small Fraction exact strings; long fractions60digit display+canonicalbinary SHA256, sign byte+8byte numerator-length+absolute numerator bytes+denominator bytes. Checks use full Fractions.','check_counts':COUNTS,'failures':FAIL,'stages':stages,'abstract_forest_cut_cases':forest}
base=Path(__file__);base.with_suffix('.json').write_text(json.dumps(out,default=encode,sort_keys=True,indent=2)+'\n')
lines=['# R306 binary scale split and forest window','',out['real_geometry_scope'],'',out['scale_split'],'',out['forest_scope'],'',out['forest_gate'],'','|real model|n|tested H/s combinations|','|---|---:|---:|']
for st in stages:
 for c in st['real_cases']:lines.append(f"|{c['name']}|{c['n']}|{len(c['records'])}|")
lines+=['','|abstract cut n|near-pair windows|reverse ordering|strict gate equalities|','|---:|---:|---:|---:|']
for f in forest:lines.append(f"|{f['n']}|{f['near_pair_window_checks']}|{f['reverse_ordered_near_pairs']}|{f['strict_threshold_equality_tests']}|")
lines+=['','All checks use exact Fraction; no root evaluations or floating point decisions are needed. Retained scalar configurations and real model recipes are in JSON. Pair-window sampling uses only same-band and same-orientation retained scalar pairs. Opposite-orientation and crossband interactions remain unpaid; far-loss checks have no such restriction. This is finite evidence, not a full forest/source certificate.']
base.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':out['status'],'check_counts':COUNTS,'failures':FAIL,'real_cases':sum(len(s['real_cases']) for s in stages),'forest_summary':[{k:f[k] for k in ['n','near_pair_window_checks','reverse_ordered_near_pairs','strict_threshold_equality_tests']} for f in forest]},indent=2));assert not FAIL,FAIL
