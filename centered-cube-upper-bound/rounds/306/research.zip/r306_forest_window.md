# R306 — actual forest eligibility: a bounded log-volume window after a paid loss

This addresses a genuine inherited joint gate, not an assumed source-only factorization of the entire target. Scope is one fixed original seed/tree and source-pair domain D consisting of pairs in the same original top cell with a distinct-child LCA P and positive original h(P). All complementary pairs and other original gates remain in the traffic and incidence ledger. Source restriction never changes h(P), e_g,m,q or original selectors.

## 1. Exact original threshold and its variable-q bracket

R113 proof.md B8-B10 (lines75-92) defines original h(A)=mu_hi(A intersect Bcal) and

 H_q(t)=q max{t^n,sqrt(n)(t^2/b)^n}.

The coarsest light block A_t(y) includes equality h(A)<=H_q(t). On D, z belongs to A_t(y) iff h(P)<=H_q(t). Thus the original exclusion factor is

 e(x,y,z)=1{h(P)>H_(q(x))(g(x))}, g=sqrt(LR).

This is the forest factor only; full original qualification chi satisfies chi<=e where this exclusion is retained. No converse is asserted. For fixed q the block grows with t. Since actual q=q(x) varies, no receiverwise monotonicity of e is asserted.

For h=h(P)>0 define the UNCLIPPED positive threshold

 tau_q(h)=min{(h/q)^(1/n), sqrt(b)(h/(q sqrt(n)))^(1/(2n)}.

The second factor is sqrt(b), not b: H's second term is q sqrt(n)t^(2n)/b^n. At tau_q the equality is already light. Thus e=1 iff g<tau_(q(x))(h), on the stated LCA domain.

For a fixed original ratio band, gamma=1+1/n and c_j=gamma^(-j), write k_min<=g/R<=k_max. In the L>=R orientation, k_min=1/c_j,k_max=1/c_(j+1); in L<=R, k_min=c_(j+1),k_max=c_j. Boundary conventions may be retained from the unique original band; both positive bounding constants are safe. In both cases k_max/k_min=gamma. No new independent band copies are created. Statements F1-F2 use this band for a single receiver. The two-receiver window F6 applies only when BOTH receivers lie in the same stated ratio band and orientation. With full U and J unchanged, partition forest pairs into those shared-band pairs and the cross-band/orientation complement. The latter is retained; no sum of separate whole-source payments is authorized.

With q_-=3lambda/4<=q(x)<=lambda put

 tau_minus=tau_lambda(h)/k_max,
 tau_plus=tau_q-(h)/k_min.

Then

 e(x,y,z)=1 implies R(x)<tau_plus,
 e(x,y,z)=0 implies R(x)>=tau_minus.                 (F1)

Indeed tau_lambda<=tau_q(x)<=tau_q-. Use g>=k_min R in the first implication and g<=k_max R in the second. The two different power branches of tau may exchange their minimum; nevertheless each branch expands by at most (lambda/q_-)^(1/n) when q is decreased. Consequently

 tau_plus/tau_minus <= gamma(4/3)^(1/n).             (F2)

These are UNCLIPPED thresholds. If they fall outside the original scale window, the corresponding eligible or excluded sets may be empty; do not clip before taking their ratio. Same-finest fallback, different-top pairs, zero h and pairs not carrying this actual gate are not assigned invented thresholds. They remain in the original complement.

## 2. Exact separation of physical and forest qualification differences

Work at one positive common threshold theta from R305. Write chi_u=1{b_y(u,z)>=theta}, c_u=1{z in Q_R(u)(u)}, and e_u=e(u,y,z). On D the original support implies chi_u<=e_u. Then

 |c_u chi_u-c_w chi_w|
 =c_u(1-c_w)chi_u+c_w(1-c_u)chi_w
    +c_uc_w[e_u e_w|chi_u-chi_w|
              +e_u(1-e_w)chi_u+e_w(1-e_u)chi_w].       (F3)

This is an exact disjoint decomposition. The first two terms are physical cube differences; the next term retains all other original qualification variation while both forest gates accept; the final two terms are the forest-crossing fee. No product expansion of the bundled remaining a_omega is needed, only its actual implication chi<=e on D.

After the half in the symmetric pair integral, the forest-crossing fee is the ordered accepted/excluded integral

 D_forest=integral beta(dy)nu(dz)ell_n(dr)1_D 1{J_y(r)>=H}/J_y(r)
      integral_(Ru,Rw<=r)U_y(u)U_y(w)c_u c_w chi_u(1-e_w)du dw. (F4)

chi_u already implies e_u=1. Outside D retain the complete original incidence. Formula F4 is part of B, not another independent source charge.

## 3. Paid far loss and localized remaining forest crossings

Fix s>1. Split F4 into R(w)>=s R(u) and its strict complement. The far part is bounded by the general lost-capture estimate in r306_geometry.md:

 D_forest,far<=s^(-n)T_theta,D<=s^(-n)T_theta.        (F5)

For completeness, interchange the nonnegative u,w,r integrals; drop c_w and 1-e_w and bound the w prefix mass by J(r), cancelling its denominator. The r integral begins at sR(u), and ell_n([sR(u),b])<=s^(-n)R(u)^(-n). What remains is precisely the original captured qualified T_theta,D. No nu mass is copied across scales.

For every pair in the surviving near-forest part whose TWO receivers share the same stated band and orientation, F1 and R(w)<sR(u) give

 R(u)>tau_minus/s, R(u)<tau_plus,
 R(w)>=tau_minus, R(w)<s tau_plus.

Thus BOTH radii belong to the common source-pair window

 [tau_minus/s,s tau_plus],
 n log[(s tau_plus)/(tau_minus/s)]
       <=2n log s+n log gamma+log(4/3).              (F6)

Reverse ordering R(w)<R(u) is included: no step assumed the accepted receiver has the smaller radius. Equality R(w)=sR(u) goes to the paid far part. Equality in the light forest threshold is excluded as required by F1. Original radius atoms and endpoints of [a,b] remain unchanged.

Taking s^n=8 gives width in log-volume at most 2log8+1+log(4/3), because n log(1+1/n)<=1. This constant-width localization does NOT give a constant or root source budget for the near term: its center depends on the original pair (y,z), and the FIRST integral over y cannot be replaced by one common short scale window. Arbitrarily concentrated sources are retained. The general missing task is to combine these actual LCA windows and their overlap with the row/column source capacities.

## 4. Complete budget and no double use of the paid loss

The primary loss/gain split in r306_geometry.md pays the ENTIRE far lost-capture part, including F5. Do not add F5 as a second independent epsilon receipt if that global far loss was already absorbed. F6 describes the same-band, same-orientation forest-crossing portion of its remaining terms. Cross-band and opposite-orientation pairs remain outside that localized assertion; original J is not recomputed for the restriction. The physical gained-capture part, the same-forest other qualification variation, the near forest fee, all cross-band/opposite-orientation forest pairs, all non-D source pairs, and low capture probabilities are still retained.

For the R305 high-capture partition p_theta=A_theta/J, the same far loss estimate remains valid after the extra positive multiplier 1{p_theta<1-eta}; dropping it only enlarges the paid part. Combining the imported original finite-T bridge and the two distinct receipts gives

 (1-2d/H-2eta-2s^(-n))T
    <=8lambda H W_beta+2 integral_0^1 B_rem(H,theta,eta,s)dtheta. (F7)

B_rem includes ALL p_theta<1-eta pair differences except the ordered far losses; equivalently the near-scale differences plus the far gained-capture differences with that same p gate. It is nonnegative and exact as a retained fee. Choose H=8d,eta=1/8,s^n=8. The left coefficient is 1/4, hence

 T<=256lambda d W_beta+8 integral_0^1 B_rem(8d,theta,1/8,8^(1/n))dtheta. (F8)

This uses one finite T internally; it is not a global epsilon X receipt. The original low-pe slot carries its original Lambda once. Different original aspect bands/outer fields keep their weights and source budget. No original wide-distance, extreme-aspect, initial-time, deletion-jump, future-deleted-source or full-entry obligation is settled by F8. F8 is not itself a root bound, and the cost lambda d retains 1/v0.

Proof status: F1-F8 are derived above; the independent source and finite-T bridge checks are recorded separately in r306_audit.md. The remaining root-order geometry is explicit. Thin source-pair windows alone do not establish it.
