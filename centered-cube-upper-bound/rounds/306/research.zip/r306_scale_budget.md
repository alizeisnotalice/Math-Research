# R306 — failed adaptive scale pricing; conditional exit-window accounting

## 1. What the row/source scale split actually gives

Keep the exact qualified binary target of R305, actual U_y,A_yz,J_y,p=A/J, original sources, selected common s,L,R,q, low-pe,m>M, aspect v>=v0, and all history/source masks. Let ell_n=b^(-n)delta_b+n r^(-n-1)dr on [a,b]. For the COMPLETE low/middle fee

    B_C=integral beta(dy)nu_*(dz)ell_n(dr)
             1{J_y(r)>=H,p_yz(r)<7/8}A_yz(r)(1-p_yz(r)),

positive Tonelli gives an exact weighted-original-traffic representation. Namely

    zeta(x,y,z)=R(x)^n integral_[R(x),b] ell_n(dr)
                    1{J_y(r)>=H,p_yz(r)<7/8}(1-p_yz(r))

satisfies 0<=zeta<=1, and

    B_C=integral U_y(x)b_y(x,z)h_(R(x))(x-z)zeta
                                             dx beta(dy)nu_*(dz). (1)

Here b_y is the exact original qualification, not the physical endpoint b. No gate or source is recomputed. Formula (1) licenses actual FIRST/point-height use on this weighted traffic; it is not a payment or a certification that the auxiliary fee is an original global ledger remainder.

For a frozen source-pair allocation omega dominating the target, put b_omega(z)=integral omega(y,z)beta(dy). On its original positive support the low/high height and aspect give p_y<=kappa0 R^(-n)/v0, kappa0=2K/(ell M). A measurable source-dependent cutoff t(z) in [a,b] splits ACTUAL R<t and R>=t. FIRST pays the former, and the actual height before receiver extension pays the latter, with total fee

    integral nu_*(dz){1+n log(t(z)/a)
       +kappa0 b_omega(z)/(q_-v0)[2t(z)^(-n)-b^(-n)]}. (2)

The hard-height integral is exactly integral sup_(t<=R<=b) R^(-2n)1_QR dx=2t^(-n)-b^(-n). The all-FIRST alternative A_nW_(nu_*), A_n=1+n log(b/a), and the all-high alternative at t=a can also be selected per z, charging that source once.

Writing u=(t/a)^n, B=(b/a)^n and x=kappa0 b_omega/(q_-v0a^n), the integrand is 1+log u+x(2/u-1/B). Its interior optimum is u=2x, clipped to [1,B]. This is the known R296-style local-mass logarithmic expense. No root budget for arbitrary heavy columns follows. Repeating the split on rows/windows would require their actual summed source fees and cannot turn (2) into a root bound. This attempt provides NO new payment and is recorded only to prevent a free scale-copy claim. The full low-p complement remains.

## 2. Conditional monotone-exit application of the main far-loss lemma

The main binary far-loss lemma is independently authored; it is not repeated or claimed as a new lemma here. The following specifies its scope for one separable original exit factor. Suppose an actual factor is VERIFIED to be

    e_y(x,z)=1{R(x)<=t(y,z)}, t(y,z) in [a,b],           (3)

with t measurable and frozen in (y,z). All remaining original qualification is b_rest,y(x,z) in [0,1]. Put c_u(z)=1{z in Q_(R(u))(u)}. The exact common-cube exit-disagreement term is

    D_exit=integral beta(dy)nu_*(dz)ell_n(dr)1{J_y(r)>=H}/J_y(r)
       integral_(R(u)<=t<R(w); R(u),R(w)<=r)
           U_y(u)U_y(w)c_u(z)c_w(z)b_rest,y(u,z)du dw. (4)

The two receiver orientations cancel the symmetric difference factor 1/2. It is the BEFORE receiver's actual remaining qualification that appears; it is not transferred to the after receiver. Other gate variation and physical-boundary terms are not erased.

Applying the main far-loss statement to the part R(w)>=s t, s>1, gives

    D_far<=s^(-n)T_exit,
    T_exit=integral_(R(u)<=t) U_y(u)b_rest,y(u,z)
                         c_u(z)R(u)^(-n)du beta(dy)nu_*(dz). (5)

This application is valid with the original cumulative J and every H>0. Its coefficient comes from ell_n([s t,b])<=(s t)^(-n) and R(u)<=t, not a source density estimate. At original incidence coefficient C_B Lambda, choosing s=(C_B/epsilon)^(1/n)>1 costs at most epsilon Lambda T_exit. It is internally absorbable only when this is the same finite target being bounded; otherwise it is a displayed expense against that larger target. All original q units remain in U. No source copy is charged per exit threshold.

The exact unpriced part of (4) has t<R(w)<s t. Its pair-dependent narrow window cannot be assigned one constant-width FIRST fee: for a fixed z, its union across y can fill the original octave. All nonexit physical/rest-mask terms still remain. Multiple gates need a true telescoping/disjoint decomposition or the actual sum of their costs, not repeated free applications. Common binary qualification levels can be averaged only with the original weights of total mass one.

No original historical A_g gate has been certified here to have form (3). Monotonicity in g alone is insufficient when the actual g/R varies inside its unique band. An application needs the original definition and either a valid exit radius in R or a separately retained uncertainty strip.

## 3. Conditional forest blur window: exact endpoints and reverse ordering

Here is a checked scalar consequence of the candidate forest cutoff communicated by the main author. It does NOT independently certify its original-gate provenance. For positive original h,q,b and n>=1 define

    tau_q=min((h/q)^(1/n),
              sqrt(b)*(h/(q sqrt(n)))^(1/(2n))).

The sqrt(b) factor is essential; it has not been replaced by b. Suppose q in [q_-,lambda], q_-=3lambda/4, and a ratio factor k in [k_min,k_max] with k_max/k_min<=gamma=1+1/n. Define

    tau_minus=tau_lambda/k_max,
    tau_plus=tau_(q_-)/k_min.

Each branch in tau_q increases by a factor at most (lambda/q_-)^(1/n) as q decreases from lambda to q_-. Taking their minimum preserves this inequality even when the minimizing branch changes. Therefore

    tau_plus/tau_minus<=gamma(4/3)^(1/n).               (6)

Assume the ACTUAL original gate has been proved to obey accepted R_good<tau_plus and rejected R_bad>=tau_minus. Remove the main far-loss part R_bad>=s R_good, including equality. Every surviving disagreement then satisfies

    tau_minus/s<R_good<s tau_plus,
    tau_minus/s<R_bad<s tau_plus.                     (7)

Proof: R_bad<s R_good and R_bad>=tau_minus give R_good>tau_minus/s. Also R_good<tau_plus gives R_bad<s tau_plus. The other bounds follow from s>1 and tau_minus<=tau_plus. This does NOT assume R_good<=R_bad, so reverse ordering is covered. Equality at tau_minus for the rejected radius is allowed; equality at s R_good was removed; the accepted upper endpoint remains strict.

The physical window is the intersection of this open interval with [a,b]. Its logarithmic-volume width is at most

    2n log s+n log gamma+log(4/3)
                         <=2n log s+1+log(4/3).        (8)

This is a localization statement, not a source payment. h,k and hence the window can depend on original row/source/history data. Original FIRST alone does not turn that family of windows into a constant W_nu fee. Physical-boundary terms and all other qualifications remain exactly as in the main incidence. The original forest definition and the accepted/rejected implications used before (7) still require the main author's source verification.

## 4. Actual minimal endpoint diagnostic

The following standard-library exact-Fraction code was actually run and passed 5194 surviving configurations, including reverse ordering and rejection at the lower endpoint. It tests (7), not the unverified original forest implication or the main far-loss theorem.

```python
from fractions import Fraction as F
from itertools import product
ct=0
for lo,hi,s in product([F(1),F(3,2)],[F(2),F(5,2)],
                       [F(5,4),F(3,2),F(2)]):
 for good,bad in product([F(k,16) for k in range(1,65)],repeat=2):
  if good<hi and bad>=lo and bad<s*good:
   assert lo/s<good<s*hi and lo/s<bad<s*hi
   ct+=1
print('PASS forest_window_cases',ct)  # actual: 5194
```

Only /tmp/r306_scale_budget.md was written. No other author's file or Git state was changed. There is no new universal low/middle capture payment in this auxiliary note.
