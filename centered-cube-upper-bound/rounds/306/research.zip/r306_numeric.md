# R306 binary scale split and forest window

Actual s=0 positive-L1 cell/shell models, FIRST<=1 and same-radius hardcap<=4. Shell menus m=min(4n,16); not original full low/e/m/history or full maximal-hardcap. Binary masks are frozen geometry-index diagnostics, not claimed original forest history.

Ordered pairs good u captured, bad w not captured. farloss Rw>=sRu; fargain Ru>=sRw; else near. Ties are near. BH=sum_(J>=H) beta layerweight/J sum_(u,w) Uu Uw nu chi_u(1-chi_w). Farloss<=s^-n actual full marked moment T. H retains min/median positive original J atoms.

Separate exact scalar forest-cut algebra; no full forest is constructed and no arbitrary incidence matrix is called real geometry. Actual retained rational L=k^2R,R in[1,2],k=g/R in[kmin,gamma*kmin],q in{3/4,7/8,1}.

Hq(g)=q max(g^n,sqrt n(g^2/2)^n),e=1{h>Hq(g)}. tau_minus=tau_lambda/kmax,tau_plus=tau_(3/4)/kmin; all comparisons in power2n. Good R<tau_plus,bad R>=tau_minus; only same-band same-orientation good/bad pair Rbad<s Rgood is tested to imply both in[tau_minus/s,s tau_plus]. Else complement exact. Crossband and opposite-orientation pairs remain unpaid by the narrow-window argument. Equal aspect k=1 is assigned to L>=R.

|real model|n|tested H/s combinations|
|---|---:|---:|
|disjoint_n1_binary_varying|1|6|
|disjoint_n1_allone|1|6|
|overlap_chain_n1_binary_varying|1|6|
|overlap_chain_n1_allone|1|6|
|cross_n4_binary_varying|4|6|
|cross_n4_allone|4|6|
|tied_n4_binary_varying|4|6|
|tied_n4_allone|4|6|
|cross_n8_binary_varying|8|6|
|cross_n8_allone|8|6|
|cross_n16_binary_varying|16|6|
|cross_n16_allone|16|6|
|concentric_shell_n16_binary_varying|16|6|
|concentric_shell_n16_allone|16|6|
|concentric_shell_n32_binary_varying|32|6|
|concentric_shell_n32_allone|32|6|

|abstract cut n|near-pair windows|reverse ordering|strict gate equalities|
|---:|---:|---:|---:|
|1|291|12|21|
|4|746|15|22|
|16|902|0|18|
|64|749|0|18|

All checks use exact Fraction; no root evaluations or floating point decisions are needed. Retained scalar configurations and real model recipes are in JSON. Pair-window sampling uses only same-band and same-orientation retained scalar pairs. Opposite-orientation and crossband interactions remain unpaid; far-loss checks have no such restriction. This is finite evidence, not a full forest/source certificate.
