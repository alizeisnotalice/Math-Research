# R306 independent preauthor audit

Status: PASS for the two screened propositions, subject to the exact qualifications below. This independent derivation was saved before reading any new R306 author proof; the preexisting dependency extraction and original R113 ZIP were read as requested.

## 1. Oriented far-radius loss

Fix U,J,H and an original binary qualification chi, and write a_u(z)=1_{Q_Ru(u)}(z) chi_y(u,z). The normalized symmetric incidence has prefactor 1/2. Fold the two strict radius orderings into Ru<Rw with coefficient ONE, and retain the equal-radius half-double integral separately. The oriented loss integrand is a_u(1-a_w); gain is a_w(1-a_u). Any extra nonnegative prefix gate, such as the remaining p<7/8 gate, is bounded by one for this payment only.

On Rw>=s Ru, s>1, exchange the ell_n layer and large receiver integral. For each r the eligible bad-receiver mass is at most J(r), cancelling its denominator. The remaining layer begins no earlier than s Ru. Since ell_n([t,b])=t^-n for a<=t<=b, and the contribution vanishes if t>b, the loss is bounded by s^-n integral U_u a_u Ru^-n = s^-n T_chi. There is no factor two. Inclusive radius atoms and H crossings remain covered by the original gate; dropping that gate is positive domination only. The exact complement consists of all near-radius differences, equal-radius ties, and all far gains. None of them is paid by this lemma.

The same argument applies at each positive common threshold theta, using the same U,J and total threshold weight one. Unique-band partitioning, if used for the forest analysis, must partition the original traffic rather than duplicate T or a full source charge per band. At the R305 alternative H=8d entry, the resulting internal absorption is (1-4 s^-n) Lambda T <=128 Lambda lambda d W_beta+4 Lambda(the complete remaining fee), requiring 4 s^-n<1. No original-X absorption follows.

## 2. Exact original forest gate

Directly inspected R113 research.zip::proof.md lines 75-92,154-186,280-290. B9 is exactly H_q(t)=q max(t^n,sqrt(n)(t^2/b)^n). The node mass is the ORIGINAL h(P)=mu_hi(P intersect Bcal), not a newly restricted source mass. The second root is sqrt(b)*(h/(q sqrt(n)))^(1/(2n)), not b times that root. For fixed positive h, define the UNCLIPPED tau_q=min((h/q)^(1/n),sqrt(b)*(h/(q sqrt(n)))^(1/(2n)). Then the strict gate e=1{h>H_q(g)} is exactly g<tau_q; equality is rejected/light.

For q_-<=q<=lambda and k_min<=g/R<=k_max with k_max/k_min=gamma, set tau_minus=tau_lambda/k_max and tau_plus=tau_qminus/k_min. They imply e=1 => R<tau_plus and e=0 => R>=tau_minus. Moreover tau_plus/tau_minus<=gamma*(lambda/q_-)^(1/n)=gamma*(4/3)^(1/n). This proof bounds q variations by endpoints and does NOT assert receiverwise monotonicity of q(x) or e(x).

The LCA equivalence holds only in the SAME original top tree and for a distinct-child LCA P: the coarsest light-node rule gives z in A_g(y) iff h(P)<=H_q(g). B18/B19 imply that original accepted pairs satisfy the strict heavy gate. Different tops and same finest/fallback pairs require their original support convention; no artificial h(P) or threshold may be assigned. Original additional D_V(y), rank, cut and history qualifications remain separate.

## 3. Exact forest split and bounded window

On common cubes, assume original binary chi<=e. Then |chi_u-chi_w| splits exactly into e_u(1-e_w)chi_u + e_w(1-e_u)chi_w + e_u e_w |chi_u-chi_w|. Together with the physical cube-boundary terms, this is an exact nonnegative partition; both-forest-accepted rest variation remains intact. In a cross pair call the accepted endpoint good and the forest-rejected endpoint bad. Its far case R_bad>=s R_good is a subset of the far-loss term above. In the complement R_bad<s R_good, the endpoint gate bounds give R_good>=tau_minus/s, R_good<tau_plus, R_bad>=tau_minus, and R_bad<s tau_plus. Hence both radii are in [tau_minus/s,s tau_plus], with endpoint inequalities retained as above.

This is a localization only. It pays neither that window nor the remaining gain/physical/rest qualifications. A ratio-band condition must hold simultaneously at both receivers for the same window; cross-band pairs need explicit retention or separate treatment, not an uncharged per-band source copy. All e,m, sources and parent identities remain original after restrictions.

## Actual bounded diagnostics

Executed 432 exact Fraction far-loss cases (binary captures, three dimensions, three s and H choices) and 972 60-digit root/q/band endpoint cases; all PASS. These finite diagnostics do not replace the exchange-integral or forest proof. Original ZIP proof.md SHA256 `99d483cadc9ca1064a56739f419367414df33d348a4191205e9dde5bc7e6966c`.

Remaining gap: no general root-order payment for near-window, far-gain, physical boundary, or both-accepted rest incidence; full original ledger and outer source integration remain separately required.

## Author comparison: auxiliary scale/window accounting

Read `/tmp/r306_scale_budget.md`, SHA256 `3d8360d9bf68ab24c16ce50e0b2474138463664a63fbf1fded3e54556669a9b5`. PASS within its stated conditional scope. The zeta identity retains the complete original fee as weighted target traffic; its source-dependent physical-scale split pays an explicit local-mass logarithmic expense, not a new root bound. The exact hard-height envelope is 2 t^-n-b^-n and the clipped optimizer u=2x is correct. The conditional monotone-exit component has coefficient one and leaves its near-window plus all nonexit terms intact. The forest root and q endpoint comparison use sqrt(b), allow reverse ordering, and correctly leave the window unpaid. This auxiliary explicitly does not certify original forest provenance; that provenance was independently checked above against B9/B18/B30, only on the indicated same-top/distinct-LCA scope.

Actually executed the embedded Fraction endpoint code: 5194 surviving forest-window configurations PASS. No new theorem of general low/middle payment follows from that finite check.

## Author comparison: oriented binary incidence

Read `/tmp/r306_geometry.md`, SHA256 `b85fdfa08a8014c446ab29275b9d4978e2bec56b5ff7e6eb069721acbab6c09f`. PASS for equations (1)-(16), with original row gate understood to satisfy 0<=I0<=alpha<=1 as required by the imported FIRST interface. Exact strict radius ordering removes the half only off the radius diagonal; the full equal-radius term is retained, including k=1. The original p_theta<7/8 and J>=H gates remain in K. Tonelli gives (10), the eligible bad mass cancels J, and the endpoint atom gives (11), including k Ru=b and the empty k Ru>b case. The all-threshold source weight is one. The alternative source receipt and internal-T absorption are not charged twice. The remaining near/tie and far-gain integrals are exact, positive, and unpaid at root order.

Actually executed the embedded Fraction diagnostic: 300 decompositions, 300 far-loss budgets, 300 exact exchanged-prefix identities, 300 nonzero-tie cases, 180 common-threshold averages; all PASS.

## Main forest-note comparison and scope correction

Read corrected `/tmp/r306_forest_window.md`, SHA256 `ecb18597c9928ba382d488f8921ab5952d2a72ff30df2c35472833c4cb6cc8e9`. PASS. An initial two-receiver ambiguity was reported and corrected: F6 now explicitly requires both receivers in the SAME original ratio band and orientation, while cross-band/opposite-orientation pairs remain in the full remainder with U/J unchanged. Original h, q endpoint brackets, strict-light equality, same-top/distinct-child-LCA scope, fallback exceptions and sqrt(b) agree with the direct original ZIP check above. F3 is an exact nonnegative decomposition; F5 is a subpart of the already paid full far loss and may not be charged again. F7 and F8 coefficients are correct: H=8d, eta=1/8, s^n=8 yield coefficient 1/4, hence 256 lambda d W_beta plus eight times the complete retained fee. This is internal finite-T algebra only. No thin-window or cross-band payment is certified.

### Final row-gate clarification

The geometry first section now explicitly states 0<=I0<=alpha<=1; current SHA256 `387be5358e359c76b5af1a7c5e925555dc198ded149670ebdf6cd494e7d9c090` supersedes the earlier component hash. This matches the original FIRST interface and changes no formula or diagnostic code. The diagnostic atoms=300 field counts observed positive ties, not 300 extra independent assertions; the explicit asserted groups are 300 decomposition, 300 far loss, 300 exchanged-prefix and 180 threshold-average cases.

## Component / completed finite-evidence bindings

- `/tmp/r306_mask_dependencies.md`: SHA256 `fbbb489e094dcefb5510b6a0379ac0518ee40574821e547f476c7b8c3c43c8b4`.
- `/tmp/r306_geometry.md`: SHA256 `387be5358e359c76b5af1a7c5e925555dc198ded149670ebdf6cd494e7d9c090`.
- `/tmp/r306_forest_window.md`: SHA256 `ecb18597c9928ba382d488f8921ab5952d2a72ff30df2c35472833c4cb6cc8e9`.
- `/tmp/r306_scale_budget.md`: SHA256 `3d8360d9bf68ab24c16ce50e0b2474138463664a63fbf1fded3e54556669a9b5`.
- `/tmp/r306_numeric.py`: SHA256 `498eb26766c7386972e0abdf5f838324ab119720b679876eb10a975c2de1ab1a`.
- `/tmp/r306_numeric.json`: SHA256 `1a8f362a5d4b3f27e8525219b098a87ebc8d49fc73555f2424f41fcdeb0eea3a`.
- `/tmp/r306_numeric.md`: SHA256 `db0a38a027ce0e32cd70f74905010eaa91ba40018982b0d10c530cba104f825e`.

Inspected the completed numeric JSON: PASS with empty failures and 33334 exact checks. Positive-volume s=0 L1 models and abstract forest-cut scalar checks are separately scoped. Cross-band and opposite-orientation forest pairs are explicitly excluded from the narrow-window test and retained as unpaid; far-loss diagnostics impose no such restriction. The scalar cut models do not implement the original full forest, low/e/m/history or full maximal hard cap. Parent reports an independent-directory rerun byte-identical to this frozen JSON; do not relabel earlier rounds as current executions.

## Final integration verdict — frozen

PASS. Read final `/tmp/r306_README.md` and detailed TeX source without compiling. The main budget retains H=8d, p_theta<7/8, s^n=8 and yields 256 Lambda lambda d W_beta plus eight times the COMPLETE near/tie and far-gain fee. The forest section explicitly limits the common narrow window to two receivers sharing a ratio band and orientation; full U/J stay fixed and cross-band/opposite-orientation costs remain. Strict forest equality, sqrt(b), original h, same-top/distinct-LCA exceptions, q variation and unclipped thresholds agree with the source audit. The source alternative and internal absorption are not double charged. The TeX explicitly gives 0<=I0<=alpha<=1 and preserves the original outer multiplier once.

The final forest-note status text records independent audit rather than proposing an unchecked claim; this editorial change does not alter F1-F8. Final bindings below supersede any earlier component hashes.

- `/tmp/r306_geometry.md`: SHA256 `387be5358e359c76b5af1a7c5e925555dc198ded149670ebdf6cd494e7d9c090`.
- `/tmp/r306_forest_window.md`: SHA256 `c5312498db2cb6bca14bd2f2dc821d6c90d62f7123c5784456401404d5e63a07`.
- `/tmp/r306_mask_dependencies.md`: SHA256 `fbbb489e094dcefb5510b6a0379ac0518ee40574821e547f476c7b8c3c43c8b4`.
- `/tmp/r306_scale_budget.md`: SHA256 `3d8360d9bf68ab24c16ce50e0b2474138463664a63fbf1fded3e54556669a9b5`.
- `/tmp/r306_README.md`: SHA256 `8fa914a7bb7993d90d14e1d942b5f5466c25c145668367210ad176e96063a3ae`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round306_20261018_final_checkpoint/r306_research.tex`: SHA256 `c1a916c5d139ea49e2983017a161f324a0373950b3af43dd6111f6375a0c84e2`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round306_20261018_final_checkpoint/r306_geometry_checks.py`: SHA256 `59e867108d27577b8ef501387adfde3e887450edc2225f99c7a76859405d3afd`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round306_20261018_final_checkpoint/r306_numeric.py`: SHA256 `498eb26766c7386972e0abdf5f838324ab119720b679876eb10a975c2de1ab1a`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round306_20261018_final_checkpoint/r306_scale_budget_checks.py`: SHA256 `274fb00748d34f834122fd7268a161d9ff40550b487b9d16137f079a962d6c6b`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round306_20261018_final_checkpoint/r306_numeric.json`: SHA256 `1a8f362a5d4b3f27e8525219b098a87ebc8d49fc73555f2424f41fcdeb0eea3a`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round306_20261018_final_checkpoint/r306_geometry_checks.log`: SHA256 `3947d7bcfcc88a9b5d59bfbdebf64209219bbd9d0f04bc1fe3afb051a39b58d3`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round306_20261018_final_checkpoint/r306_numeric.log`: SHA256 `032358345908c68b4616285e83096f6d513b7a0978153c8861e939df94be0aad`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round306_20261018_final_checkpoint/r306_scale_budget_checks.log`: SHA256 `9be232e698e15088f01fb3e8218fb0962b67ac709d5774ceeff9cb509f37cf1c`.

Inspected completed staging output/logs and byte identity of staged numeric script/JSON with frozen originals: 33334 exact PASS, empty failures; 300 ordered decompositions, 300 far-loss inequalities, 300 prefix identities and 180 common-threshold averages; 5194 auxiliary endpoint cases. The 300 positive-tie cases are observed metadata, not extra asserted tests. This audit independently ran the geometry and scale embedded reproductions plus 432 Fraction loss and 972 mp60 root cases recorded above. Numeric source geometries and abstract forest tests remain explicitly separate; no complete original history or full maximal hard cap is certified by those finite models.

Exact remaining gap: all near/tie disagreements and far capture gains require a general original-source root budget; physical boundaries, both-forest-accepted residual qualification differences, cross-band/opposite-orientation and non-LCA support complements remain. Constant log-volume forest windows are localization, not source payment. Independent original ledger slots, extreme aspect, and the original-X entry connector remain unclosed. No new global epsilon X absorption or overall weak-type theorem is asserted. Only this audit file was modified; no author, repository, TeX or PDF files were changed. This receipt is frozen.
