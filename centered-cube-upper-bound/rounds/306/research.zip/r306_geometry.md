# R306 — an absorbable multiscale binary loss budget, with exact gain and radius-atom complements

## 1. Precise statement and original entry

This note addresses the genuine binary incidence remaining in R305, rather than making another fractional replacement. It proves a source-conserving payment for ONE direction of separated-scale disagreement on the entire original target. It does not bound the opposite direction or all near-scale disagreement at root order.

Keep the original positive target

    T = integral I0(x,y,z) p_y(x) h_R(x)(x-z)/q(x)
                                      dx beta(dy) nu_*(dz),

with original actual selectors s(x),L(x),R(x), a<=L,R<=b<=2a, q_-=3lambda/4<=q<=lambda, original FIRST, SAME-R hard cap, original full-source low-pe and m>M gates, and aspect v(L,R)>=v0>0. The frozen restriction nu_*<=nu does not recompute e_g, m, the tree, or any history qualification. Let alpha(x,y) be the fixed z-independent original row gate with 0<=I0<=alpha<=1 and put

    U_y(x)=1_E(x)alpha(x,y)p_y(x)/q(x),
    b_y(x,z)=I0/alpha when alpha>0, and zero otherwise,
    J_y(r)=integral_{R(x)<=r} U_y(x)dx,
    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)(r)dr,
    kappa0=2K/(ell M), gamma=1+1/n,
    psi_inf=3-2/(3gamma^n), d=kappa0 psi_inf/(q_-v0),
    H=8d, A_n=1+n log(b/a).

The notation b_y for qualification is distinct from the physical upper scale b. For a SINGLE common theta in (0,1], define the binary qualified capture

    sigma_theta(x,y,z)
      =1{z in Q_R(x)(x)} 1{b_y(x,z)>=theta},
    A_theta(y,z;r)=integral_{R(x)<=r}U_y(x)sigma_theta(x,y,z)dx,
    p_theta(y,z;r)=A_theta/J_y(r) when J_y(r)>0, zero otherwise.

All U,J,d,H and sources remain unchanged as theta varies. Positive theta inherits the original height and aspect qualifications because its support is contained in {I0>0}; no witness qualification is substituted for a target qualification. At alpha=0 set b_y=0. The theta=0 endpoint can be defined to be the zero target. Let T_theta be the original traffic with I0 replaced by alpha 1{b_y>=theta}. Exact Tonelli gives

    T_theta=integral beta(dy)nu_*(dz)ell_n(dr) A_theta(y,z;r),
    T=integral_0^1 T_theta dtheta.                       (1)

Original FIRST and the hard-scale envelope ensure T_theta<=A_n W_nu*. Thus all subsequent self-absorption acts on finite targets. The imported R305 equation (16) is

    Lambda T <=128 Lambda lambda d W_beta
                      +4 Lambda integral_0^1 B_theta dtheta, (2)

where

    B_theta=integral beta(dy)nu_*(dz)ell_n(dr)
      1{J_y(r)>=H, p_theta(y,z;r)<7/8}
            [A_theta-A_theta^2/J_y(r)].                 (3)

Lambda is the original once-only outer multiplier; at the quoted low-pe ledger slot it is 128/119. Keep all actual outer integration and source qualifications. This note does not establish a missing global entry inequality.

For every k>=1, (3) admits an EXACT positive decomposition

    B_theta = B_theta^near(k)+G_theta^far(k)+L_theta^far(k),
    L_theta^far(k) <= k^(-n) T_theta.                    (4)

Here L is loss of qualified capture from a smaller-radius receiver to a receiver at least k times larger. G is gain of capture in the opposite direction. The near term includes ALL equal-radius atoms and all disagreements with radius ratio strictly below k. These definitions retain the original p<7/8 gate; they are given below. In particular, choosing k=exp(h/n) pays the far-loss incidence by exp(-h) times the EXACT original target, uniformly over all spatial configurations, softnesses and original binary qualifications.

Consequently, when 4 exp(-h)<1,

    (1-4 exp(-h)) Lambda T
       <=128 Lambda lambda d W_beta
            +4 Lambda integral_0^1
                    [B_theta^near(exp(h/n))+G_theta^far(exp(h/n))]dtheta. (5)

This is a strict new payment in the old binary budget: an entire positive all-scale incidence component is absorbed, without a repeated hard-source price per scale or an unqualified first moment. The unproved part is stated explicitly in section 5.

## 2. Exact ordered-pair decomposition, including radius atoms

Fix theta,y,z for this section. Write sigma(u)=sigma_theta(u,y,z), R_u=R(u), U(u)=U_y(u), and define the nonnegative measurable kernel

    K_yz,theta(s)=integral_{[s,b]} ell_n(dr)
       1{J_y(r)>=H, p_theta(y,z;r)<7/8}/J_y(r),          (6)

with value zero for s>b. The gate makes K<=a^(-n)/H. It includes the entire original low-capture restriction; it is not a new receiver selector. The binary variance identity and Tonelli give

    B_theta=(1/2)integral beta nu_* integral du dw
        U(u)U(w)|sigma(u)-sigma(w)| K_yz,theta(max(R_u,R_w)). (7)

The factor 1/2 disappears on the strictly ordered region R_u<R_w, by symmetry. Equal-radius pairs instead contribute the explicit term

    B_theta^tie=(1/2)integral beta nu_* integral_{R_u=R_w}
        U(u)U(w)|sigma(u)-sigma(w)| K_yz,theta(R_u)du dw. (8)

This term need not vanish: R is an arbitrary actual measurable selector, and its pushforward may have atoms even though receiver integration is true dx. It is not legitimate to discard the set R_u=R_w or silently order it by a continuous-radius density.

On R_u<R_w the binary identity is

    |sigma(u)-sigma(w)|
       =sigma(u)[1-sigma(w)]+sigma(w)[1-sigma(u)].      (9)

Define L_theta^far(k) as the integral of the first summand in (9), with measure beta nu_* U(u)U(w) K(R_w)du dw and restrictions

    R_u<R_w, R_w>=k R_u.

Define G_theta^far(k) with the second summand and the SAME restrictions. Define B_theta^near(k) as (8) plus the integral of |sigma(u)-sigma(w)| on

    R_u<R_w<k R_u.

These three sets exactly partition (7), including k=1: then the strict near part is empty and the tie term remains. No original source/history mask is dropped in this identity. For k>1, the strict condition R_u<R_w is automatic on the far part. At the boundary R_w=kR_u the pair belongs to far, so there is no missing endpoint.

## 3. Far-loss theorem: direct payment by original qualified traffic

Keep the original gate in (6) during Tonelli. For a fixed earlier qualified receiver u, exchanging the w and r integrals yields exactly

    integral_{R_w>R_u, R_w>=kR_u}
            U(w)[1-sigma(w)] K(R_w)dw
      =integral_{r>=kR_u} ell_n(dr)
          1{J_y(r)>=H,p_theta(r)<7/8}/J_y(r)
          integral_{R_u<R_w, kR_u<=R_w<=r}
                         U(w)[1-sigma(w)]dw.          (10)

When k=1 the inner strict condition R_w>R_u is retained, correctly excluding radius ties. The numerator in (10) is bounded by J_y(r), because it is an actual subset of the SAME original row prefix. Hence (10) is at most

    integral_{[kR_u,b]} ell_n(dr)
      = (kR_u)^(-n) if kR_u<=b, and 0 otherwise.       (11)

The equality uses the endpoint atom b^(-n)delta_b. It also holds at kR_u=b, where only that atom contributes. There is no fictitious continuation beyond the legal physical interval.

Multiplying by U(u)sigma(u), integrating the ORIGINAL beta and nu_*, and using the hard-kernel representation in (1), gives

    L_theta^far(k)
      <=k^(-n) integral beta nu_* du
                         U_y(u)sigma_theta(u,y,z) R(u)^(-n)
       =k^(-n)T_theta.                                (12)

This proof uses the captured source mass at u only through its actual qualified target. It does not replace sigma by mere geometric capture, does not use a density bound at z, and does not multiply W_nu by the number of bands. The original SAME-R cap and full-soft point heights remain the input to the imported witness price d in (2); the new payment (12) needs no stronger cap. The original full-soft U can be completely arbitrary within the accepted hypotheses.

There is also an unconditional source receipt for precisely the same positive component:

    L_theta^far(exp(h/n)) <= exp(-h) A_n W_nu*.        (13)

For example h=(1/2)log A_n gives sqrt(A_n) W_nu* (k=1 when A_n=1, with ties still excluded). This is a root source payment for the far LOSS component alone. For the stronger internal absorption choose h=log(4/epsilon), 0<epsilon<1; then (5) has left coefficient 1-epsilon. The source coefficient remaining on the right is exactly

    128 Lambda lambda d/(1-epsilon)
       =(512/3) Lambda kappa0 psi_inf/[(1-epsilon)v0]. (14)

All aspect and low-m fees are visible. If k>b/a, no separated-scale pair exists, and the loss and gain terms are both zero; the theorem does not pretend a nonempty gain in that case.

A sharper, retained form of (10) is available without a new estimate: its numerator is the actual noncapturing row mass on [kR_u,r], with the lower endpoint included and R_u itself excluded when k=1. It can be computed from left limits of J-A. Replacing this numerator by J is the sole inequality in the far-loss proof before the final endpoint extension.

## 4. Common threshold and source/selection bookkeeping

Equations (4),(12) hold for EVERY fixed theta>0, with exactly the same U,J,H and physical scale interval. Integrating theta gives

    integral_0^1 L_theta^far(k)dtheta <=k^(-n)T.        (15)

The total theta measure is one; there are no theta copies of W_beta or W_nu. No favorable threshold or witness is selected separately for a source pair. Finite theta coarea reductions have the same statement after multiplication by their original weights summing to one, plus only their already proved rounding error if the full T is reconstructed.

This proof uses ordered actual receiver PAIRS only as a positive decomposition of the existing incidence fee. It does not change the sampling law, original selectors, source allocation, tree or original target. Its pair-dependent K retains the old gate and is not passed to an own-scale lemma as a freely selectable source mask. Thus it incurs no hidden selection or source fee.

Combining (15) with (2) proves (5). For h=log 8 this reads

    Lambda T <=256 Lambda lambda d W_beta
          +8 Lambda integral_0^1
                    [B_theta^near(8^(1/n))+G_theta^far(8^(1/n))]dtheta. (16)

This absorption is legitimate because T is finite by ORIGINAL FIRST. It is not an assertion that an epsilon lambda|E| term has already been absorbed in the full global ledger. If beta or nu_* has zero mass, all displayed traffic and incidence vanish; J=0 contributes zero and is excluded by H>0.

## 5. Exact unpaid complement and what the new receipt changes

After (5), two concrete positive components remain:

1. Near-scale disagreements, including ALL radius atoms, with both actual radii within a multiplicative exp(h/n). Spatially the two receiver centers may still be far apart, and their original binary qualifications may differ on a common cube. No thin-boundary or source density conclusion follows from close radii.
2. Far-scale capture GAINS: sigma(u)=0, sigma(w)=1 at R_w>=exp(h/n)R_u. Their hard-kernel price is R_w^(-n), and the previous proof cannot extract exp(-h) relative to their own actual target contribution. One must not charge them to a nonexistent captured source at u.

The original p<7/8 mask is retained in both components through (6). In particular this result neither replaces binary qualification by an arbitrary smooth mask nor removes history variation. It pays the direction where scale separation gives a genuine favorable kernel ratio. The opposite direction is now isolated as an actual increasing-capture incidence, while ties are explicitly separate. A true monotone decreasing binary capture process would have no gains, but actual centered receiver cubes and full qualifications have NOT been shown to have that property. No such monotonicity assumption is made.

The all-scale far-loss bound applies without FIRST beyond the legitimate original target entry; therefore it is compatible with, but does not itself exploit, any additional cross-row soft overlap. The precise remaining geometric task is to bound the sum in (5) by a source-linear root budget, possibly together with a further absorbable multiple of T, using the actual common soft kernel, FIRST and original forest qualifications. The old estimate still bounds it by A_nW_nu*, so no overall root theorem is claimed. A conditional one-cut forest interpretation and its finite exit window are being audited separately by the main author; they are not silently assumed here.

All statements remain conditional on the original outer data. Multiply every term, including (13) if that receipt is chosen, by its original positive outer weight inside the existing ledger. Do not spend both the internal-absorption receipt and the alternative source receipt for the same component as if they paid two disjoint traffic pieces.

## 6. Actual exact local diagnostics

A standard-library Fraction run used true finite cube-capture patterns in n=1,2,4,8, four receiver sites with radii 1,3/2,3/2,2, three hard-source sites, and all-one, receiver-varying binary and fractional-coarea qualifications. It tested five separation factors k=1,6/5,3/2,2,3 and three prefix thresholds, retaining p<7/8 exactly. It passed 300 full ordered decompositions, 300 far-loss budgets, 300 exact exchanged-prefix identities, 300 cases with a nonzero equal-radius tie term, and 180 common-threshold averaged identities/budgets. Checks include separation equality, kR=b, kR>b and the k=1 strict-pair convention. These finite geometry checks verify algebra and endpoints; they do not certify realization by every original low/e_g/forest field or the unpaid global root estimate. The complete reproduction below writes no files.

```python
from fractions import Fraction as F
from itertools import product
ct=dict(decomposition=0,far_loss=0,exact_cdf=0,atoms=0,threshold_average=0)
for n in (1,2,4,8):
 R=[F(1),F(3,2),F(3,2),F(2)]
 u=[F(1,7),F(2,7),F(1,7),F(3,7)]
 centers=[(F(0),)*n,(F(1,3),)*n,(F(-1,2),)*n,(F(1),)*n]
 zs=[(F(0),)*n,(F(1,2),)*n,(F(3,2),)*n]
 nu=[F(1,3),F(2,5),F(1,7)]
 cap=[[int(all(abs(x-z)<=rr/2 for x,z in zip(cc,zz))) for zz in zs] for cc,rr in zip(centers,R)]
 scales=sorted(set(R)); weights=[r**(-n)-(scales[i+1]**(-n) if i+1<len(scales) else 0) for i,r in enumerate(scales)]
 for mode,H,k in product(range(3),(F(1,10),F(3,7),F(6,7)),(F(1),F(6,5),F(3,2),F(2),F(3))):
  qual=[[F(1) if mode==0 else (F((i+j)%2) if mode==1 else F((2*i+j)%4,3)) for j in range(3)] for i in range(4)]
  cuts=sorted(set([F(0),F(1)]+[q for row in qual for q in row])); avgB=avgParts=avgLoss=avgT=F(0)
  for lo,hi in zip(cuts,cuts[1:]):
   th=(lo+hi)/2
   sig=[[cap[i][j]*int(qual[i][j]>=th) for j in range(3)] for i in range(4)]
   J=[sum(u[i] for i in range(4) if R[i]<=r) for r in scales]
   A=[[sum(u[i]*sig[i][j] for i in range(4) if R[i]<=r) for j in range(3)] for r in scales]
   gate=[[int(jj>=H and aa/jj<F(7,8)) for aa in row] for jj,row in zip(J,A)]
   K=[[sum(weights[t]*gate[t][j]/J[t] for t in range(len(scales)) if scales[t]>=r) for j in range(3)] for r in R]
   B=sum(weights[t]*gate[t][j]*nu[j]*A[t][j]*(1-A[t][j]/J[t]) for t in range(len(scales)) for j in range(3))
   T=sum(u[i]*nu[j]*sig[i][j]*R[i]**(-n) for i in range(4) for j in range(3))
   near=gain=loss=tie=F(0)
   for i,l,j in product(range(4),range(4),range(3)):
    if R[i]==R[l]:
     tie+=u[i]*u[l]*nu[j]*abs(sig[i][j]-sig[l][j])*K[i][j]/2
    elif R[i]<R[l]:
     v=u[i]*u[l]*nu[j]*K[l][j]
     if R[l]>=k*R[i]:
      loss+=v*sig[i][j]*(1-sig[l][j]);gain+=v*sig[l][j]*(1-sig[i][j])
     else: near+=v*abs(sig[i][j]-sig[l][j])
   assert B==tie+near+gain+loss;ct['decomposition']+=1
   assert loss<=k**(-n)*T;ct['far_loss']+=1
   exact=F(0)
   for i,j in product(range(4),range(3)):
    for t,r in enumerate(scales):
     if r<k*R[i]:continue
     later=sum(u[l]*(1-sig[l][j]) for l in range(4) if R[i]<R[l] and k*R[i]<=R[l]<=r)
     exact+=u[i]*nu[j]*sig[i][j]*weights[t]*gate[t][j]*later/J[t]
   assert exact==loss;ct['exact_cdf']+=1
   if tie>0:ct['atoms']+=1
   avgB+=(hi-lo)*B;avgParts+=(hi-lo)*(tie+near+gain+loss);avgLoss+=(hi-lo)*loss;avgT+=(hi-lo)*T
  assert avgB==avgParts and avgLoss<=k**(-n)*avgT;ct['threshold_average']+=1
print('PASS',ct)
```

Only /tmp/r306_geometry.md was written. Other authors' files, prior frozen proofs and Git were not modified.
