from fractions import Fraction as F
from itertools import product
ct=dict(decomposition=0,far_loss=0,exact_cdf=0,atoms=0,threshold_average=0)
for n in (1,2,4,8):
 R=[F(1),F(3,2),F(3,2),F(2)]
 u=[F(1,7),F(2,7),F(1,7),F(3,7)]
 centers=[(F(0),)*n,(F(1,3),)*n,(F(-1,2),)*n,(F(1),)*n]
 zs=[(F(0),)*n,(F(1,2),)*n,(F(3,2),)*n]
 nu=[F(1,3),F(2,5),F(1,7)]
 cap=[[int(all(abs(x-z)<=rr/2 for x,z in zip(cc,zz))) for zz in zs] for cc,rr in zip(centers,R)]
 scales=sorted(set(R)); weights=[r**(-n)-(scales[i+1]**(-n) if i+1<len(scales) else 0) for i,r in enumerate(scales)]
 for mode,H,k in product(range(3),(F(1,10),F(3,7),F(6,7)),(F(1),F(6,5),F(3,2),F(2),F(3))):
  qual=[[F(1) if mode==0 else (F((i+j)%2) if mode==1 else F((2*i+j)%4,3)) for j in range(3)] for i in range(4)]
  cuts=sorted(set([F(0),F(1)]+[q for row in qual for q in row])); avgB=avgParts=avgLoss=avgT=F(0)
  for lo,hi in zip(cuts,cuts[1:]):
   th=(lo+hi)/2
   sig=[[cap[i][j]*int(qual[i][j]>=th) for j in range(3)] for i in range(4)]
   J=[sum(u[i] for i in range(4) if R[i]<=r) for r in scales]
   A=[[sum(u[i]*sig[i][j] for i in range(4) if R[i]<=r) for j in range(3)] for r in scales]
   gate=[[int(jj>=H and aa/jj<F(7,8)) for aa in row] for jj,row in zip(J,A)]
   K=[[sum(weights[t]*gate[t][j]/J[t] for t in range(len(scales)) if scales[t]>=r) for j in range(3)] for r in R]
   B=sum(weights[t]*gate[t][j]*nu[j]*A[t][j]*(1-A[t][j]/J[t]) for t in range(len(scales)) for j in range(3))
   T=sum(u[i]*nu[j]*sig[i][j]*R[i]**(-n) for i in range(4) for j in range(3))
   near=gain=loss=tie=F(0)
   for i,l,j in product(range(4),range(4),range(3)):
    if R[i]==R[l]:
     tie+=u[i]*u[l]*nu[j]*abs(sig[i][j]-sig[l][j])*K[i][j]/2
    elif R[i]<R[l]:
     v=u[i]*u[l]*nu[j]*K[l][j]
     if R[l]>=k*R[i]:
      loss+=v*sig[i][j]*(1-sig[l][j]);gain+=v*sig[l][j]*(1-sig[i][j])
     else: near+=v*abs(sig[i][j]-sig[l][j])
   assert B==tie+near+gain+loss;ct['decomposition']+=1
   assert loss<=k**(-n)*T;ct['far_loss']+=1
   exact=F(0)
   for i,j in product(range(4),range(3)):
    for t,r in enumerate(scales):
     if r<k*R[i]:continue
     later=sum(u[l]*(1-sig[l][j]) for l in range(4) if R[i]<R[l] and k*R[i]<=R[l]<=r)
     exact+=u[i]*nu[j]*sig[i][j]*weights[t]*gate[t][j]*later/J[t]
   assert exact==loss;ct['exact_cdf']+=1
   if tie>0:ct['atoms']+=1
   avgB+=(hi-lo)*B;avgParts+=(hi-lo)*(tie+near+gain+loss);avgLoss+=(hi-lo)*loss;avgT+=(hi-lo)*T
  assert avgB==avgParts and avgLoss<=k**(-n)*avgT;ct['threshold_average']+=1
print('PASS',ct)
