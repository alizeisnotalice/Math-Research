# R460：同一接受流的双端软最小 channel 比较

沿用 R459_information 的实际 \(P=\Xi_{\rm can,out}\)、质量 \(R\)、\(N\) 个有效分位核及墓地约定。所有条件化分母、bin 权和旧历史仍在 \(P\) 中。本文不重配来源或终端，也不证明完整根阶预算。

## 命题

在原完整记录上定义两端实际费用
\[
G_y=\log\frac{m_Aw_{y,j}(m_u)}{I^\beta_{Auj}},\qquad
G_z=\log\frac{m_Aw_{z,k}(m_v)}{I^\beta_{Avk}}.
\]
零参考处原流为零；两项按 R459 的绝对可积结论处理。令
\[
C_y=\int G_y\,dP,\quad C_z=\int G_z\,dP,\quad
C_{\min}=\int\min(G_y,G_z)\,dP,\quad
V=\int|G_y-G_z|\,dP.
\]
则同一实际流满足
\[
\boxed{(2\sqrt n-\log(2N))R
 \le C_{\min}+SX/e,}
\tag{1}
\]
且
\[
C_{\min}=\frac{C_y+C_z-V}{2}. \tag{2}
\]
这是有一位选择费用的真实交叉信用，不是免费删除任一 channel。

## 证明及 soft 账

给原记录附标签 \(e=0\) 当 \(G_y\le G_z\)，否则 \(e=1\)，保平局规则。推前只记录所选端 \((A,x,w,j,e)\)，质量仍为 \(R\)，没有生成新历史。

R459(3) 对两端分别成立：未选择的单端投影各被 \(N\mathcal B_1\) 支配。理由是先积掉另一端的真实条件质量，再用单份 \(b\kappa^{safe}\le\kappa\)。因此选择后的每端也是该投影的正限制。取共同参考
\[
\mathcal B_{\rm sel}=\tfrac12(\mathcal B_1\otimes\delta_0+
                                   \mathcal B_1\otimes\delta_1),
\quad |\mathcal B_{\rm sel}|=SX.
\]
有 \(P_{\rm sel}\le2N\mathcal B_{\rm sel}\)。这里没有双端乘积参考，故不新增 \(1/b\) 或 \(1/\zeta\)；选择依赖另一端并不影响正限制支配。

条件于 \((A,w,j,e)\)，参考来源后验仍为 R459 的
\(k^0\propto\pi_Ac_ww_{x,j}(m_w)\)。实际来源后验 \(k\) 支持 \(Q_A\cap Q_w\)，并保 \(m_A>K^2m_w\)，所以总 KL 至少 \(2\sqrt nR\)。同流链式分解给
\[
\int{\rm KL}(k\Vert\pi_A)
 =H_{\rm sel}+C_{\min},\qquad
H_{\rm sel}\le R\log(2N)+R\log(SX/R)
 \le R\log(2N)+SX/e.
\]
这证明(1)。\(R=0\) 或 \(SX=0\) 用零流约定。选择后可积性由
\(|\min(G_y,G_z)|\le|G_y|+|G_z|\) 保证，无无穷相减。

直接改用完整双端 KL 不会免费多得交叉耗散：在同一实际联合后验上，附加的条件互信息同时进入“原后验信息”和“相对 product-reference 的 retention 信息”，在 channel 链式差中抵消。(1)没有把这项再扣一次。

## 更强的软选择：不硬付一位

固定 \(0<p<1\)，取任意可测 \(r_0+r_1=1\)，依赖同一完整记录；只是给原票据作正拆分。第 \(e\) 端原投影为 \(P_e\)，所选投影是 \(a_eP_e\)，其中
\(a_e=E_P[r_e\mid\text{第 }e\text{ 端记录}]\)。
参考改为
\(\mathcal B_p=p\mathcal B_1\oplus(1-p)\mathcal B_1\)，总量仍 \(SX\)，条件来源后验仍为原 \(k^0\)。

由 \(P_e\le N\mathcal B_1\) 与凸函数 \(x\log x\) 的条件 Jensen，
\[
\begin{aligned}
\int\log\frac{dP_{\rm sel}}{d\mathcal B_p}\,dP_{\rm sel}
&\le R\log N+\sum_e\int a_e\log(a_e/p_e)\,dP_e\\
&\le R\log N+\int\sum_e r_e\log(r_e/p_e)\,dP .
\end{aligned}
\tag{3}
\]
不等号方向是“条件平均后的熵较小”。再减去所选外层投影的未归一 KL；其下界为 \(R\log(R/SX)\)。同一实际支持给来源 KL 至少 \(2\sqrt nR\)，所以
\[
(2\sqrt n-\log N)R
\le\int\left[\sum_e r_eG_e+{\rm KL}(r\Vert(p,1-p))\right]dP+SX/e.
\]
逐记录选择 \(r_e=p_e e^{-G_e}/\sum_d p_d e^{-G_d}\)，得到本稿主比较
\[
\boxed{(2\sqrt n-\log N)R
\le\int -\log\!\left(pe^{-G_y}+(1-p)e^{-G_z}\right)dP+SX/e.}
\tag{4}
\]
这没有改变实际耦合；额外选择位按真实熵收费。\(p=0,1\) 直接取原固定端。软最小值位于两费用之间，故绝对可积；零流沿用原约定。

取 \(p=1/2\)，软最小值不超过 \(\min(G_y,G_z)+\log2\)，所以(4)至少包含硬式(1)。它也不超过 \(pG_y+(1-p)G_z\)；允许选全局常数 \(p\) 并保两个端点，便不会比最好固定端更差。这里“选 \(p\)”是比较这些已证同流不等式，不把不同记录重新分配给新历史。

## 实际获益及尚缺比较

以下仅比较硬选择式(1)。与两端中较好的固定选择比较，精确节省为
\[
\min(C_y,C_z)-C_{\min}
 =\frac{V-|C_y-C_z|}{2}.
\]
只有此节省大于 \(R\log2\) 时，该硬选择比较才严格改善固定端信息账。若两端费用一致，则多付一位反而无益，故可保原单端式择优；不能保证固定改善比例。软选择式(4)不受这一必要条件限制；两端费用一致时它直接恢复固定端费用。

在实际正密度记录上还有精确几何表达
\[
\min(G_y,G_z)=\log\frac{m_A}
 {\max(I^\beta_{Auj}/w_{y,j}(m_u),\,I^\beta_{Avk}/w_{z,k}(m_v))}
 \le\log\frac{2m_A}{I^\beta_{Auj}+I^\beta_{Avk}}.
\]
它选择较有利的真实加权交叠；但 \(I^\beta_{Auj}+I^\beta_{Avk}\le m_u+m_v\) 是分母的上界，不能据此上界该对数或得到 \(W\) 价。

当 \(\log(2N)\le\sqrt n\)，retention 项仍只花
\(SA_nW/(e\sqrt n)\)。要闭合，尚须证明同一 \(P\) 上
\[
C_{\min}\le\eta\sqrt nX+C_\eta n\,\mathrm{polylog}(n+2)W,
\]
或给足够的实际振荡信用 \(V-|C_y-C_z|\)。互相排斥和质量门目前没有提供该上界。(4)可将此待估量换为实际软最小费用，但其几何上界仍未证明；母账无新增已付分支。

## 本机核验

本机 Python 实跑18项 Fraction断言，并另跑27项200位 Arb区间检查，核验 Gibbs 恒等式、软硬比较及条件 Jensen 方向。取三组有限费用 profiles，令 \(m_A=2^{16}\)、\(I_y=2^{k_y}\)、\(I_z=2^{k_z}\)、\(w=1\)，费用以 \(\log2\) 为单位。结果：

| profile | \(C_y,C_z\) | \(C_{\min}\) | 扣一位后的净节省 |
|---|---:|---:|---:|
| 同端 \((0,0)\) | \(16,16\) | 16 | −1 |
| 各半 \((0,4),(4,0)\) | \(14,14\) | 12 | 1 |
| 比例 \(7/10,3/10\) | \(74/5,66/5\) | 12 | \(1/5\) |

仅为同流代数/选择核验，不是 native cube 或原历史实现。实际运行代码如下：

~~~python
from fractions import Fraction as F
cases=[("same",[(F(1),0,0)]),
       ("balanced",[(F(1,2),0,4),(F(1,2),4,0)]),
       ("unbalanced",[(F(7,10),0,4),(F(3,10),4,0)])]
count=0
for name,rows in cases:
 R=sum(r for r,_,_ in rows)
 cy=sum(r*(16-a) for r,a,_ in rows)
 cz=sum(r*(16-b) for r,_,b in rows)
 low=sum(r*min(16-a,16-b) for r,a,b in rows)
 osc=sum(r*abs(a-b) for r,a,b in rows)
 selected=[sum(r for r,a,b in rows
               if (0 if 16-a<=16-b else 1)==e) for e in [0,1]]
 checks=[2*low==cy+cz-osc,low<=min(cy,cz),
         min(cy,cz)-low==(osc-abs(cy-cz))/2,
         sum(selected)==R,all(0<=x<=R for x in selected),
         ((min(cy,cz)-low-R)>0)==(name!="same")]
 assert all(checks)
 count+=len(checks)
print("PASS",count)
~~~


新增 Arb 检查的实际代码：

~~~python
from fractions import Fraction as F
from flint import arb,ctx
ctx.prec=200
def ar(x):
 x=F(x);return arb(x.numerator)/x.denominator
count=0
for p in [F(1,2),F(1,3)]:
 for gy,gz in [(0,4),(4,0),(2,2),(0,8)]:
  Z=p*F(1,2)**gy+(1-p)*F(1,2)**gz
  r=p*F(1,2)**gy/Z
  H=ar(r)*ar(r/p).log()+ar(1-r)*ar((1-r)/(1-p)).log()
  mean=(ar(r)*gy+ar(1-r)*gz)*arb(2).log()
  soft=-ar(Z).log()
  assert (H+mean-soft).contains(0);count+=1
  hard=arb(min(gy,gz))*arb(2).log()-ar(min(p,1-p)).log()
  assert (hard-soft).lower()>0;count+=1
  avg=(ar(p)*gy+ar(1-p)*gz)*arb(2).log()
  assert (avg-soft).contains(0) if gy==gz else (avg-soft).lower()>0
  count+=1
for r1,r2,t in [(F(1,5),F(4,5),F(1,2)),
                (F(1,10),F(3,5),F(1,3)),
                (F(1,100),F(9,10),F(7,10))]:
 def fun(r):return ar(r)*ar(r).log()+ar(1-r)*ar(1-r).log()
 a=t*r1+(1-t)*r2
 gap=ar(t)*fun(r1)+ar(1-t)*fun(r2)-fun(a)
 assert gap.lower()>0;count+=1
print("PASS",count)
~~~
