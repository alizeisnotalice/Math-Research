# R460：双终端排斥块与实际 channel 的有界核验

**结论：未得到新的整体付款。** 本附件只筛一个机制：用两父外终端的互排斥来源块，联合结算实际 channel；下述等式保留同一实际 \(P=\Xi_{\rm can,out}\)，不以参考均值替换它。无新 \(X\) 或 \(W\) 费用进入母账。

## 1. 精确几何候选及筛查

固定实际记录 \((A,y,z,u,v,j,k)\)。记 \(m=m_A\)、\(w_y=w_{y,j}(m_u)\)、\(w_z=w_{z,k}(m_v)\)，并定义
\[
 I_u=\int f(x)c_A(x)c_u(x)w_{x,j}(m_u)\,dx,
 \quad E_u=\int f(x)c_A(x)c_u(x)(1-c_v(x))w_{x,j}(m_u)\,dx,
\]
另一端交换 \((u,j)\) 与 \((v,k)\)。实际路径保证 \(y\in Q_u\setminus Q_v\)、\(z\in Q_v\setminus Q_u\)。因权重介于零与一，完整匹配严格给出
\[
 E_u+E_v\le m,\qquad I_u\le m_u,\quad I_v\le m_v.
\tag{1}
\]
这使用真实来源质量，不使用交叠体积替代它。所有量仍由实际 Lebesgue 接收场定义。实际非零纤维上 \(I_u,I_v,E_u,E_v>0\) 几乎处处；零纤维不定义对数。

候选是利用双排斥得到的交叠信用支付两端信息。直接核算：
\[
 \gamma_y+\gamma_z
 =\log\frac{m^2w_yw_z}{E_uE_v}
  -\log\frac{I_uI_v}{E_uE_v},
 \qquad \gamma_y=\log\frac{mw_y}{I_u}.
\tag{2}
\]
第二项是真实非负信用，但第一项的归一代价同时增加。令 \(E=E_u+E_v\)，则
\[
 \log\frac{m^2}{E_uE_v}
 =2\log\frac{2m}{E}
   -\log\frac{4E_uE_v}{E^2}.
\tag{3}
\]
末项非负。因此仅以不交性将两个来源合成一个质量，并不产生有方向的上界节省。原接受权、当前阶段和双 avoid 权均未消去；不能把 (2) 两项分别外放，再宣称保留净信用。若分项可积性未另证，仅把 (2) 当逐记录等式，不写无穷相减。

## 2. 与同流选择较便宜端的接口

主证明另有合法选择端收据
\[
 (2\sqrt n-\log(2N))R
 \le\int\min(\gamma_y,\gamma_z)\,dP+SX/e.
\tag{4}
\]
此处引用该收据，不重复认证其参考测度。对实际正权点，定义有效交叠
\[
 M_{\rm eff}=\max(I_u/w_y,I_v/w_z).
\]
严格有
\[
 \min(\gamma_y,\gamma_z)=\log(m/M_{\rm eff})
 \le\log\frac{2m}{I_u+I_v}.
\tag{5}
\]
所以选择端确实避免支付两端失衡的全部代价；这是比用 channel 和更合适的比较。然而原严格门只给
\(I_u+I_v\le m_u+m_v<2m/K^2\)，它是分母的**上界**，不能支付 (5) 的上界。也不能由此推出实际 \(\min\gamma\ge2\sqrt n\)：分数原子权 \(w_y,w_z\) 仍须保留。

唯一尚缺步骤是：利用实际共同父中心与全部原门，控制同一 \(P\) 下有效交叠过小的加权对数成本；不能把 \(P\) 换成独立 canonical 参考。这一步若能给
\(\int\log(m/M_{\rm eff})dP\le\eta\sqrt nX+C_\eta n\operatorname{polylog}(n)W\)，即可由 (4) 计价。当前计算没有证明该比较，也不把它另命名为成果。已有 \(SX/e\le SA_nW/e\) 除以 \(\sqrt n\) 的费用照旧；没有新增可扣信用。

## 3. 实际本机核验与范围

指定 Python 已运行以下三个有理来源分割模型，**18 个断言通过，其中 6 个精确对数恒等式**。它们只验证 (1)–(5) 的方向、权重与归一，不是原生立方体/完整历史实例，也不反驳原目标。首次两次断言因 SymPy 保留 `log(1)` 或未完全化简而失败；添加 `simplify(logcombine(...))` 后精确为零，没有改变公式或参数。

```python
from fractions import Fraction as F
import sympy as s
cases=[([1,2,3,4],[1,F(1,2),0,0],[0,F(1,3),1,0]),
       ([3,1,2,5],[F(1,4),1,0,0],[0,F(1,2),F(2,3),0]),
       ([1,7,2,1],[F(1,5),F(1,7),0,0],[0,F(1,3),F(1,2),0])]
checks=0
for masses,wu,wv in cases:
 M=sum(map(F,masses))
 Iu=sum(F(m)*F(w) for m,w in zip(masses,wu))
 Iv=sum(F(m)*F(w) for m,w in zip(masses,wv))
 Eu=F(masses[0])*F(wu[0]); Ev=F(masses[2])*F(wv[2]); U=Eu+Ev
 assert 0<Eu<=Iu<=M and 0<Ev<=Iv<=M and U<=M; checks+=1
 Q=lambda x:s.Rational(x.numerator,x.denominator)
 lu=s.log(Q(M*F(wu[0])/Iu)); lv=s.log(Q(M*F(wv[2])/Iv))
 lex=s.log(Q(M*M*F(wu[0])*F(wv[2])/(Eu*Ev)))
 credit=s.log(Q(Iu*Iv/(Eu*Ev)))
 assert s.simplify(s.logcombine(lu+lv-lex+credit,force=True))==0; checks+=1
 comp=2*s.log(Q(2*M/U))-s.log(Q(4*Eu*Ev/(U*U)))
 assert s.simplify(s.logcombine(s.log(Q(M*M/(Eu*Ev)))-comp,force=True))==0; checks+=1
 assert Iu*Iv>=Eu*Ev and 4*Eu*Ev<=U*U; checks+=1
 eff=max(Iu/F(wu[0]),Iv/F(wv[2]))
 assert eff>=(Iu+Iv)/2; checks+=1
 assert min(M*F(wu[0])/Iu,M*F(wv[2])/Iv)==M/eff; checks+=1
print('PASS:',checks)
```

本轮至此停止；没有从双排斥推出全来源预算，不追加局部支或参考替换。
