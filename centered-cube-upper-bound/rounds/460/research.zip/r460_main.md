# 第460轮：同一实际联合流的软端点选择及有效交叠几何

## 目标与状态

本轮仍针对原R433经R458保留下来的完整实际联合流P=Xi_can,out，质量R。新结果是无双端条件化损失的软端点选择比较；尚未取得一般n^(1/2+o(1))弱型上界，也未支付中间段硬层整体费用。研究方向保留全局极值几何，不以有限模型通过或新增接口数量代替闭合。

必要定义沿用R459：每个记录保原父A、来源y,z、终端u,v、分位标签j,k和全部旧history；G0=log(m_A w_yj/I_Auj^beta)，G1=log(m_A w_zk/I_Avk^beta)。两端单独投影各满足mu_e<=N B1、B1总量SX，且两端实际终端都保strict m_A>K^2 m_terminal。N=1+ceil(eps0/delta)，K=exp(sqrt(n))；零点及墓地规则不变。

## 新比较：用软选择保留真实不对称收益

固定p=(p0,p1)，p_e>0，p0+p1=1。只给原P附一个条件随机标签e，不改变P或两端关联。标签概率r_e可以依完整记录。所选端测度的密度为a_e=E_P[r_e|side_e]相对于原单端mu_e；使用参考B_p=p0 B1⊕p1 B1，总量仍SX。

由mu_e<=N B1和x log x的凸性，未归一相对熵满足
\[
\int\log\frac{dP_{sel}}{dB_p}\,dP_{sel}
\le R\log N+\int\sum_e r_e\log(r_e/p_e)\,dP.
\]
关键是用同一P的条件平均a_e，不是假定两端独立，也不把两单端密度帽乘起来。条件化到所选父/终端/bin/e后，参考旧源后验仍为原k0；真实旧源的质量差信息不少于2sqrt(n)。与上式及质量归一成本合并得
\[
(2\sqrt n-\log N)R
\le\int\left[\sum_e r_eG_e+\operatorname{KL}(r\Vert p)\right]dP
       +R\log(SX/R).
\]
令r_e=p_e exp(-G_e)/sum_l p_l exp(-G_l)，括号精确变为
\[
G_p=-\log(p_0e^{-G_0}+p_1e^{-G_1}).
\]
因此
\[
\boxed{(2\sqrt n-\log N)R\le C_p+SX/e,\qquad C_p=\int G_p\,dP.}
\]
不是把Gibbs公式从不同后验拼接：两个G都定义在同一个原联合记录。p趋端点给原固定端式。对任意固定p，G_p<=p0 G0+p1 G1，且在min G与max G之间，故绝对可积。公平p给G_p<=min G+log2，包含本轮先得到的硬argmin比较，且不机械支付一整位标签熵。新式不含1/b、1/zeta或第二次stage因子。 公平先验还有精确式G_p=(G0+G1)/2-log cosh((G0-G1)/2)，故实际可用的对称差收益是其log cosh积分；非负不代表它已有所需的几何下界。

## 几何内容与明确未付的价格

实际正密度记录满足
\[
G_p=\log\frac{m_A}{p_0 I^\beta_{Auj}/w_{y,j}(m_u)+p_1 I^\beta_{Avk}/w_{z,k}(m_v)}.
\]
这把目标直接放在两端有效交叠的加权和上；小的单端交叠不再独自决定费用。它仍保真实接受权。需要的新几何上界依然是
\[
C_p\le\eta\sqrt n X+C_\eta n\log^A(n+2)W
\]
（某个合法固定p即可），或具有相同费用的真实递推。该不等式本轮未证明。质量门只给Iu+Iv<=mu+mv，是分母上界；不能据此支付log费用。双端排斥块提供的正交叠信用同时伴随归一代价，未得到可结算的净源价。

后续重点是上述有效交叠的小尾在实际接受流上的积分预算。删除bin可简化参考，但无权channel自身已大于质量差，不能据此新增付款；本轮不将该旁支重复归档。

## 完整费用与适用边界

原比较保持
\[
R_{433}\le[S\zeta+2S\varepsilon_0/s+2S\delta]X+R.
\]
不因删除标签、选择端点或使用软选择退还旧rounding费用。若logN<=sqrt(n)，新信息式的SX/e项除sqrt(n)后，用X<=A_nW给S A_n/(e sqrt(n))W。N、S、母入口64 Lambda0 Fhat以及G0/BH的16/32倍率均按原合同保留；参数随维度变化时不能视N固定。总吸收及其他未付项未获认证。

## 工具、独审与可复现材料

使用64项D04熵链式技能核同一联合律、真实条件核、零点与有限性；未调用未经核对的新外部文献定理。指定独立Python环境用于Fraction、SymPy和Arb；验证范围及实际次数由numeric与complement、geometry附件给出，均不认证原连续立方体及history。审计先独立形成接受质量极值命题，随后审作者。软选择由主代理提出、Sol独立推导和独审另核。未编译PDF。

本轮启用1 Astra high、2 Sol high、1 Sol medium；没有独立必要任务的Luna保持空闲。无实际扣额数据，不估计成本比例。归档只保本报告、必要证明和复现；一般目标保持未完成。

主代理隔离复现了3个内嵌脚本（geometry 18、complement 18及27项断言）与numeric脚本（566项断言，含支持/归一化/log正性等常规检查；独立输入为7张联合概率表及3个后验选择例）。所有stdout一致，numeric JSON除运行秒数外逐字段一致，详见replay。初步链式核验后，以不同条件化及零参考压力表检查，再扩至不对称、交叉与相同费用的后验参数；此三阶段仅覆盖有限接口，不含维数阶数验证。交叉权例soft选择比最好固定端节省(1/2)log(5/4)，而不对称例不改善；其作用是区分软硬选择决策，不是证明原几何价格。
