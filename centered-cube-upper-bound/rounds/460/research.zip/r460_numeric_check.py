#!/usr/bin/env python3
"""Same-full-joint chain rules and posterior-generated orientation selectors."""
from fractions import Fraction as F
from pathlib import Path
from itertools import product
from math import lcm,ceil
import json,sys,platform,time
import sympy as s
ROOT=Path(__file__).resolve().parent
checks=0;starttime=time.perf_counter()
def ck(x):
 global checks
 assert x
 checks+=1
def add(*terms):
 z={}
 for t in terms:
  for p,c in t.items():z[p]=z.get(p,F(0))+c
 return {p:c for p,c in z.items() if c}
def mul(a,t):return {p:a*c for p,c in t.items() if a*c}
def logf(x):
 ck(x>0);z={}
 for a,sign in ((x.numerator,1),(x.denominator,-1)):
  for p,n in s.factorint(a).items():z[int(p)]=z.get(int(p),F(0))+sign*int(n)
 return {p:F(c) for p,c in z.items() if c}
def expr(t):return s.Add(*(s.Rational(c.numerator,c.denominator)*s.log(p) for p,c in sorted(t.items())))
def textlog(t):return str(expr(t))
def nonnegative(t):
 if not t:return True
 d=lcm(*(c.denominator for c in t.values()));r=F(1)
 for p,c in t.items():r*=F(p)**int(c*d)
 return r>=1

def marginal(P,axes):
 z={}
 for key,p in P.items():
  k=tuple(key[i] for i in axes);z[k]=z.get(k,F(0))+p
 return {k:p for k,p in z.items() if p}
def KL(P,Q):
 z={}
 for k,p in P.items():
  if p:ck(Q.get(k,0)>0);z=add(z,mul(p,logf(p/Q[k])))
 return z
def MI(P,X,Y,C=()):
 D=marginal(P,tuple(X)+tuple(Y)+tuple(C));XC=marginal(P,tuple(X)+tuple(C));YC=marginal(P,tuple(Y)+tuple(C));CC=marginal(P,C)
 z={};nx,ny=len(X),len(Y)
 for key,p in D.items():
  context=key[nx+ny:];a=key[:nx]+context;b=key[nx:nx+ny]+context
  z=add(z,mul(p,logf(p*CC[context]/(XC[a]*YC[b]))))
 return z
def residual(*terms):
 z=add(*terms);ck(not z);ck(s.simplify(expr(z))==0)

Qfull={t:F(1,8) for t in product(range(2),repeat=3)}
Pmodels=[('shared_parent_only',{(0,y,z):F(1,4) for y,z in product(range(2),repeat=2)}),
 ('conditional_source_correlation',{(a,y,y):F(1,4) for a,y in product(range(2),repeat=2)}),
 ('shared_parent_and_source_correlation',{(0,y,y):F(1,2) for y in range(2)})]
parent_cases=[]
for name,P in Pmodels:
 ck(sum(P.values())==1)
 joint=KL(P,Qfull);shared=KL(marginal(P,(0,)),marginal(Qfull,(0,)))
 d1=KL(marginal(P,(0,1)),marginal(Qfull,(0,1)));d2=KL(marginal(P,(0,2)),marginal(Qfull,(0,2)))
 info=MI(P,(1,),(2,),(0,))
 residual(joint,mul(-1,d1),mul(-1,d2),mul(-1,info),shared)
 parent_cases.append(dict(name=name,P=[dict(state=k,p=p) for k,p in P.items()],joint_KL=textlog(joint),single_KL_sum=textlog(add(d1,d2)),
  shared_parent_KL=textlog(shared),conditional_source_MI=textlog(info),joint_minus_single_sum=textlog(add(joint,mul(-1,d1),mul(-1,d2)))))

qcor={(0,0):F(3,8),(0,1):F(1,8),(1,0):F(1,8),(1,1):F(3,8)}
source_models=[('negative_reference_coupling',{k:F(1,4) for k in product(range(2),repeat=2)},qcor),
 ('positive_reference_coupling',qcor,qcor),
 ('zero_reference_off_support',{(0,0):F(3,4),(1,1):F(1,4)},{(0,0):F(1,2),(1,1):F(1,2)})]
source_cases=[];prior={(i,j):F(1,4) for i,j in product(range(2),repeat=2)};one_prior={(i,):F(1,2) for i in range(2)}
for name,P,Q0 in source_models:
 ck(sum(P.values())==sum(Q0.values())==1)
 py,pz=marginal(P,(0,)),marginal(P,(1,));qy,qz=marginal(Q0,(0,)),marginal(Q0,(1,))
 fit=KL(P,prior);f1=KL(py,one_prior);f2=KL(pz,one_prior);info=MI(P,(0,),(1,))
 h=KL(P,Q0);h1=KL(py,qy);h2=KL(pz,qz)
 delta={};channel={}
 for (y,z),p in P.items():
  delta=add(delta,mul(p,logf(Q0[(y,z)]/(qy[(y,)]*qz[(z,)]))))
  channel=add(channel,mul(p,logf(Q0[(y,z)]/prior[(y,z)])))
 c1=add(f1,mul(-1,h1));c2=add(f2,mul(-1,h2))
 residual(fit,mul(-1,f1),mul(-1,f2),mul(-1,info))
 residual(h,mul(-1,h1),mul(-1,h2),mul(-1,info),delta)
 residual(channel,mul(-1,c1),mul(-1,c2),mul(-1,delta))
 residual(fit,mul(-1,h),mul(-1,channel))
 source_cases.append(dict(name=name,P=[dict(state=k,p=p) for k,p in P.items()],Q0=[dict(state=k,p=p) for k,p in Q0.items()],
  joint_fit=textlog(fit),joint_retention=textlog(h),source_MI=textlog(info),coupling_delta=textlog(delta),
  single_channel_sum=textlog(add(c1,c2)),joint_channel=textlog(channel),reference_RN_cap=max(p/Q0[k] for k,p in P.items())))

# Exact mismatch-of-conditioning stress: same full P(U=Z,V=Y,Y,Z).
PC={(z,y,y,z):F(1,4) for y,z in product(range(2),repeat=2)}
puv=marginal(PC,(0,1));quv={(u,v,y,z):p*F(1,4) for (u,v),p in puv.items() for y,z in product(range(2),repeat=2)}
fullfit=KL(PC,quv)
puy=marginal(PC,(0,2));pvz=marginal(PC,(1,3));pu=marginal(PC,(0,));pv=marginal(PC,(1,))
f1=KL(puy,{(u,y):p/2 for (u,),p in pu.items() for y in range(2)})
f2=KL(pvz,{(v,z):p/2 for (v,),p in pv.items() for z in range(2)})
i1=MI(PC,(2,),(1,),(0,));i2=MI(PC,(3,),(0,),(1,));i12=MI(PC,(2,),(3,),(0,1))
residual(fullfit,mul(-1,f1),mul(-1,f2),mul(-1,i1),mul(-1,i2),mul(-1,i12))
context_case=dict(P=[dict(state=k,p=p) for k,p in PC.items()],joint_full_context_fit=textlog(fullfit),single_own_context_fit_sum=textlog(add(f1,f2)),
 extra_context_MI_1=textlog(i1),extra_context_MI_2=textlog(i2),residual_conditional_source_MI=textlog(i12))

# All orientation gamma are genuine posterior log(k0/pi_A), on the SAME full joint P.
P={(y,z):F(1,4) for y,z in product(range(2),repeat=2)}
f=[F(1),F(1),F(8)];mA=sum(f);pi=[x/mA for x in f]
orient_specs=[('unequal_skew',[F(1,4),F(1),F(0)],[F(2,3),F(1),F(0)]),
 ('crossed_weights',[F(1,4),F(1),F(0)],[F(1),F(1,4),F(0)]),
 ('equal_channels',[F(1),F(1),F(0)],[F(1),F(1),F(0)])]
orientation=[]
for name,w1,w2 in orient_specs:
 weights=[w1,w2];I=[sum(x*y for x,y in zip(f,w)) for w in weights];q0=[[x*y/a for x,y in zip(f,w)] for w,a in zip(weights,I)]
 gamma_ratios=[[mA*w[i]/a if w[i] else F(0) for i in range(3)] for w,a in zip(weights,I)]
 marg=[marginal(P,(0,)),marginal(P,(1,))];single_cap=max(p/q0[e][i] for e in range(2) for (i,),p in marg[e].items());N=ceil(single_cap)
 C=[{},{}];Cmin={};V={};Csoft={};selectionKL={};free={};records=[]
 hard={(e,i):F(0) for e in range(2) for i in range(3)};soft=hard.copy();ae_num=hard.copy()
 for (y,z),p in P.items():
  a,b=gamma_ratios[0][y],gamma_ratios[1][z];gam=[logf(a),logf(b)];e=0 if a<=b else 1
  r=[b/(a+b),a/(a+b)];ck(sum(r)==1)
  C[0]=add(C[0],mul(p,gam[0]));C[1]=add(C[1],mul(p,gam[1]));Cmin=add(Cmin,mul(p,logf(min(a,b))))
  V=add(V,mul(p,logf(max(a,b)/min(a,b))))
  kler=add(mul(r[0],logf(2*r[0])),mul(r[1],logf(2*r[1])))
  energy=add(mul(r[0],gam[0]),mul(r[1],gam[1]));pointfree=logf(2*a*b/(a+b))
  residual(energy,kler,mul(-1,pointfree))
  selectionKL=add(selectionKL,mul(p,kler));Csoft=add(Csoft,mul(p,energy));free=add(free,mul(p,pointfree))
  hard[(e,(y,z)[e])]+=p
  for end,source in enumerate((y,z)):soft[(end,source)]+=p*r[end]
  records.append(dict(Y=y,Z=z,P=p,gamma_exp=[a,b],hard_orientation=e,soft_r=r))
 residual(Cmin,mul(F(-1,2),add(*C)),mul(F(1,2),V))
 residual(free,mul(-1,Csoft),mul(-1,selectionKL))
 if name=='unequal_skew':best=C[0];ck(nonnegative(add(C[1],mul(-1,C[0]))))
 else:residual(C[0],mul(-1,C[1]));best=C[0]
 fair={(e,i):q0[e][i]/2 for e in range(2) for i in range(3)}
 softKL=KL({k:p for k,p in soft.items() if p},fair);hardKL=KL({k:p for k,p in hard.items() if p},fair)
 rhs=add(logf(F(N)),selectionKL)
 ck(nonnegative(add(rhs,mul(-1,softKL))))
 capgap={};jensen_side={}
 for e in range(2):
  for (i,),mu_i in marg[e].items():
   selected=soft[(e,i)];ae=selected/mu_i
   ck(0<=ae<=1)
   capgap=add(capgap,mul(selected,logf(mu_i/q0[e][i])))
   if selected:jensen_side=add(jensen_side,mul(selected,logf(2*ae)))
 jensengap=add(selectionKL,mul(-1,jensen_side));cap_gap=add(logf(F(N)),mul(-1,capgap))
 ck(nonnegative(jensengap) and nonnegative(cap_gap))
 residual(rhs,mul(-1,softKL),mul(-1,jensengap),mul(-1,cap_gap))
 hardcap=max(p/fair[k] for k,p in hard.items() if p);softcap=max(p/fair[k] for k,p in soft.items() if p)
 ck(hardcap<=2*N and softcap<=2*N)
 # Selected conditional posterior identity, not a replacement of P by independent endpoints.
 selected_F={};selected_H={}
 for e in range(2):
  lm=sum(soft[(e,i)] for i in range(3));ck(lm>0)
  kp={(i,):soft[(e,i)]/lm for i in range(3) if soft[(e,i)]}
  selected_F=add(selected_F,mul(lm,KL(kp,{(i,):pi[i] for i in range(3)})))
  selected_H=add(selected_H,mul(lm,KL(kp,{(i,):q0[e][i] for i in range(3)})))
 residual(selected_F,mul(-1,selected_H),mul(-1,Csoft))
 ck(nonnegative(add(softKL,mul(-1,selected_H))))
 orientation.append(dict(name=name,same_joint_P=[dict(state=k,p=p) for k,p in P.items()],f=f,mA=mA,terminal_capture=[1,1,0],
  cutoff_weights=weights,I_beta=I,k0=q0,piA=pi,single_cap=single_cap,N=N,records=records,
  C1=textlog(C[0]),C2=textlog(C[1]),Cmin=textlog(Cmin),absolute_difference_V=textlog(V),
  hard_gain_over_best=textlog(add(best,mul(-1,Cmin))),hard_gain_after_one_bit=textlog(add(best,mul(-1,Cmin),mul(-1,logf(F(2))))),
  hard_selected=[dict(e=k[0],source=k[1],mass=p) for k,p in hard.items() if p],hard_RN_cap=hardcap,
  soft_selected=[dict(e=k[0],source=k[1],mass=p) for k,p in soft.items() if p],
  soft_selection_factor_ae=[dict(e=e,source=i,mu_e=mass,ae=soft[(e,i)]/mass) for e in range(2) for (i,),mass in marg[e].items()],
  soft_RN_cap=softcap,
  selection_KL=textlog(selectionKL),soft_channel=textlog(Csoft),soft_free_energy=textlog(free),
  soft_gain_over_best=textlog(add(best,mul(-1,free))),soft_gain_nonnegative=nonnegative(add(best,mul(-1,free))),
  selected_joint_KL=textlog(softKL),soft_selector_budget=textlog(rhs),budget_gap=textlog(add(rhs,mul(-1,softKL))),
  marginal_Jensen_gap=textlog(jensengap),single_cap_gap=textlog(cap_gap),
  selected_source_fit=textlog(selected_F),selected_conditional_retention=textlog(selected_H)))
# Exact decision checks in the three posterior-generated selector fixtures.
ck(orientation[0]['soft_gain_nonnegative'] is False)
ck(orientation[1]['soft_gain_nonnegative'] is True)
ck(orientation[1]['soft_gain_over_best']==str(-s.log(2)+s.log(5)/2))
ck(orientation[2]['soft_gain_over_best']=='0' and orientation[2]['selection_KL']=='0')
out=dict(scope='same-full-joint finite probability/posterior identities, not original cube/history or a channel root budget',
 executable=sys.executable,python=platform.python_version(),sympy=s.__version__,checks=checks,
 parent_shared_cost_cases=parent_cases,coupled_reference_cases=source_cases,conditioning_context_case=context_case,posterior_orientation_cases=orientation,
 compute_index=dict(status='complete and frozen',input='three shared-parent tables, three source-coupling tables, one context table, three posterior orientation fixtures',
 command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r460_numeric_check.py',
 arithmetic='Fraction + exact prime-log SymPy; diagnostic runtime only floating',seconds=time.perf_counter()-starttime))
def enc(x):
 if isinstance(x,F):return str(x)
 raise TypeError(type(x).__name__)
(ROOT/'r460_numeric_check.json').write_text(json.dumps(out,default=enc,indent=2)+'\n')
print('executable:',sys.executable,'Python:',platform.python_version(),'SymPy:',s.__version__)
for x in parent_cases:print('joint-parent',x['name'],'joint=',x['joint_KL'],'two single=',x['single_KL_sum'],'difference=',x['joint_minus_single_sum'])
for x in source_cases:print('source coupling',x['name'],'delta=',x['coupling_delta'],'channel=',x['joint_channel'])
print('context:',context_case)
for x in orientation:print('posterior selector',x['name'],'Cmin=',x['Cmin'],'freeenergy=',x['soft_free_energy'],'gain-best=',x['soft_gain_over_best'],'cap=',x['soft_RN_cap'],'2N=',2*x['N'])
print('PASS',checks,'exact checks; 7 joint tables plus 3 same-family selector fixtures, no scan')
