# R460 最终独立审计

**FINAL PASS（限定同一实际联合流的软/硬端点选择、几何接口及列明有限证据）。** 实际soft free energy的全局根阶源价格与原一般弱型目标仍未证明；不认证这些整体目标。本轮两处文字范围已修正，当前无待修数学阻断项。2026-10-21。

## 独立过程及原测度

先读取R459 information与R435合同独立形成PRE（/tmp/r460_pre_audit.md，非归档输入），再独立核查主代理soft-selector命题，随后阅读作者证明。PRE中的接受质量重排与删bin旁支不列为本轮主要成果，不替代当前真正几何目标。

全文使用同一实际P=Xi_can,out，R=P(1)，两费用G_y/G_z定义于同一完整记录。实际另一来源、旧path、history、条件化分母及bin权通过真实P保留。R459各单端投影mu_e<=N B1可用于本轮选择；没有原联合流被替换成独立来源或参考均值。orientation是新增分析位，不等同原物理方向e；阶段帽S仍只收一次。

## 核准的soft-selector证明

固定先验p_e>0、sum p_e=1。给P附加可测概率r_e，原完整记录边缘仍为P。所选端投影Q_e=a_e mu_e，其中a_e=E_P[r_e|side_e]，不是把完整record上的r_e直接当单端密度。参考B_p=直和p_e B1总质量SX，其条件来源后验仍为R459的真实k0；p是固定标量先验，不扩展成任意source/record依赖参考。

由单端帽及凸函数xlogx条件Jensen，准确方向是

\[
\begin{split}
\int\log(dQ/dB_p)dQ
&\le R\log N+\sum_e\int a_e\log(a_e/p_e)d\mu_e\\
&\le R\log N+\int\mathrm{KL}(r\Vert p)dP.
\end{split}
\]

再用所选外层边缘的非归一熵下界Rlog(R/SX)，及同一实际支持的来源KL>=2sqrt(n)R，得到

\[
(2\sqrt n-\log N)R
\le\int[\sum_e r_eG_e+\mathrm{KL}(r\Vert p)]dP+R\log(SX/R).
\]

选择依赖另一端不损害这个正限制/条件Jensen论证；不需要双端联合密度帽、不增加1/b或1/zeta，也没有另乘两个阶段S。

Gibbs r_e=p_e exp(-G_e)/sum p_d exp(-G_d)可测，逐记录精确给

\[
G_p=-\log\sum_e p_e e^{-G_e},\qquad
\boxed{(2\sqrt n-\log N)R\le\int G_pdP+SX/e.}
\]

两个G在实际P下绝对可积，G_p位于minG与maxG之间；不需exp(-G_e)整体可积。固定p_min>0使选择KL<=log(1/p_min)，r或a为0按0log0处理；R=0/SX=0按零流。P<<各投影参考以及有限密度帽足以处理条件后验和有限熵负部，不需要对全部连续history假设产品绝对连续。p=0/1另取原固定端证明，或用可积支配取极限，不在log0上运算。

## 硬选择、联合KL与几何方向

- hard argmin附一位，参考公平orientation给帽2N、总质量仍SX，故(2sqrt(n)-log(2N))R<=C_min+SX/e。C_min=(C_y+C_z−∫|G_y−G_z|dP)/2精确。原文“节省必须大于Rlog2才改善固定端”的判断仅适用于这条硬式，最终已明确；不能限制主soft式。公平soft的精确收益为logcosh((G_y−G_z)/2)，同费用时直接恢复固定端，没有机械的一位损失。
- 对每个固定p有G_p<=pG_y+(1−p)G_z，但固定公平p不保证优于最好固定端；只有允许比较全局固定p及端点时才不劣于最好固定端。数值中公平p的不对称例确实不改善，正文未偷换该量词。
- 同一完整上下文的product-reference中，联合来源互信息同时进入fit和retention并相消；不能扣两次当新channel信用。不同contexts比较需补交叉条件信息项，见下述已修范围。
- 实际互排斥块给E_u+E_v<=m_A、I_u<=m_u等完整f质量界。geometry(2)–(3)的正交叠信用伴随归一代价，分项未证明可积时只作逐记录恒等式，不分别外放后宣称净付款。实际正纤维外的零点不定义对数。
- 有效交叠公式G_p=log[m_A/(p I_u/w_y+(1−p)I_v/w_z)]及hard max版本均正确；w必须保留。I_u+I_v<=m_u+m_v是分母上界，不能据此支付对数的上界，也不能推出实际minG>=2sqrt(n)。本轮未证明这些有效交叠的接受权加权小尾预算。

## 数值报告的已修量词

独审要求一般own-contexts身份明确同一父/同一prior。最终numeric_plan已写：固定同一A，或A同时包含于T1、T2；所有fit用同一pi_A^Y⊗pi_A^Z及其边缘，不能随所选context更换prior。按该定义

\[
F_{12}=F_1+F_2+I(Y;T_2|T_1)+I(Z;T_1|T_2)
       +I(Y;Z|T_1,T_2)
\]

正确；有限U=Z,V=Y压力表是固定父情形。没有把特殊均匀prior的有限身份扩大到任意变化的参考。零参考只在实际质量零处出现，未有限化一个真正无限KL。

## 母账与未付项

R458原soft、return、rounding比较仍保；端点投影/选择不退还旧付款。若logN<=sqrt(n)，本信息比较中SX/e除以sqrt(n)后可用X<=A_nW计为S A_n/(e sqrt(n))W；若delta经入口回代依n，N依赖与该条件都须原样保留。G0（原母账标量，与channel标签G_0区分）、BH、入口各自16Fhat/32Fhat/64Lambda0Fhat倍率分别整乘，不相加或重复扣同一信息项。

仍缺同一实际P上的

\[
\int G_p\,dP\le\eta\sqrt nX+C_\eta n\log^A(n+2)W
\]

或同价真实递推。soft选择只改善合法同流比较，不付其几何价格；未新增已证whole余项W收据、固定改善比例或general closure。

## 实际独立复现与证据范围

指定数学Python，独审新隔离目录：
`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r460_audit_isolated_36trhw50`。

已实际执行geometry内嵌1块（18 Fraction/SymPy断言）、complement内嵌2块（18 Fraction、27 Arb200位断言）；stdout均逐字节匹配replay。最终确认代码内容未改，未无故重复运行。随后只补一次numeric_check：566个精确检查stdout匹配，JSON仅compute_index.seconds为本次实测诊断值，其余字段完全相同。

566不是独立样本数：输入为7张有限joint表及同一有限来源族的3个后验selector fixture。主数值使用Fraction和prime-log/SymPy精确符号与符号比较，不用浮点或Arb判定；Arb仅属于complement的小接口检查。量度比5等fixture没有原strict-K、高rank或native cube/history资格。交叉权例soft优于最好固定端的(1/2)log(5/4)为精确有限概率结果；不对称例不改善、相同费用例无收益，均不拟合维数阶数。资源耗时只为实际运行元数据，非证明证据。无MATLAB、repo修改、新代理或PDF。

## 最终7输入SHA256

审计自身不自绑定。PRE/unlabelled不在最终包，不作为本轮主要成果。全部最终白名单如下。

- `r460_main.md`: `b5deaffc0ac7abc41b993cb3ea7e76e8265df746c605ce0bfbdc7a797bc3cc88`
- `r460_complement.md`: `523948e491a39bc2547d39f67600e46bd5a9a4f1adb9b56cd227757ac6eac405`
- `r460_geometry.md`: `f5496b6d54811a498b808469016dec3c10f32d06f4414924f3d4ac43429fdb16`
- `r460_numeric_plan.md`: `325216f4c4820b2268f61d0031d5bdc5be8eae594c0039ae328af91bcb6141c0`
- `r460_numeric_check.py`: `bcd92d2d20acad318d38bb1b57e9e750a37658b5fa66ec96c5f9cc542cf11642`
- `r460_numeric_check.json`: `e4ef389e1d50c60703536857589f6ab024977c00584c95945451333bb902fb6a`
- `r460_replay.json`: `06c508e22e6d1f43509c4a633a662e08a7fc6ca61ea699be7893347966a2580e`
