# R460 同一联合律与 selector：已执行的有界证书

结果：共同联合律本身没有免费 channel 节省；product reference 下互信息在 fit 与 retention 中精确抵消。soft selector 在一个真实后验生成的有限概率例中严格改善最佳固定方向，而另一个例中不改善。因此下一步应控制实际同一 P 上的 soft free energy，不能用任意双端联合 KL 的名称代替该预算。本报告仅为有限概率/后验接口，未构造或认证原 cube、strict mass gate 或完整 history。

## 1. 同一 P 的 chain rule

令 Q 为给定 A 后 Y、Z 条件独立的参考律，P 为同一完整联合律。精确核验

D(P||Q)−D(P_AY||Q_AY)−D(P_AZ||Q_AZ)
=I_P(Y;Z|A)−D(P_A||Q_A)。

三表分别只改变共同父、只增加条件来源相关、同时改变两者；joint 减两个 single 的费用依次为 −log2、+log2、0。第一种减少来自重复计算父费用，不能解释成条件来源 channel 的节省。

在同一完整上下文，令 k 为实际两来源后验，q0 为耦合参考，πYπZ 为父参考；q01、q02 和 k1、k2 为相应边缘。记 fit 为 F、retention 为 H、channel 为 C，Δ0=E_k log[q0/(q01q02)]。核验

F12=F1+F2+I_k；
H12=H1+H2+I_k−Δ0；
C12=C1+C2+Δ0。

因此 product q0 的 Δ0=0，互信息不降低 channel。三个非 product/含零参考的支持合法例得到 Δ0=(log3)/2−log2、(3log3)/4−log2、log2；零参考只在实际质量为零处出现，未计算无限 KL。任意改动耦合参考而产生负 Δ0，仍须支付该参考的 retention/support 成本，不能据此认定原几何有收益。

另有一个不同 conditioning 的独立压力表：同一 P 取 U=Z、V=Y，Y、Z 独立公平。完整上下文来源 fit 为 2log2，own-end fits 均为零，缺项为 I(Y;V|U)=log2、I(Z;U|V)=log2。一般 own contexts T1、T2 比较限于固定同一父A，或A同时包含于T1、T2；所有fit均使用同一父参考π_A^Y⊗π_A^Z及其边缘。具体F1、F2是给定各自T1、T2的来源后验对该父边缘的期望KL，F12是给定(T1,T2)的联合来源后验对该父乘积参考的期望KL。参考不得随所选上下文另外更换。在这些条件下必须保留

F12=F1+F2+I(Y;T2|T1)+I(Z;T1|T2)+I(Y;Z|T1,T2)。

## 2. 同一 P 上的实际后验 selector

三个例均固定同一完整 P(Y,Z)=1/4（Y,Z∈{0,1}），选择后再推前到各端，未另行替换 P。有限源质量 f=(1,1,8)，mA=10，πA=(1/10,1/10,4/5)；两 terminal 支持前两个源，mu=mv=2。质量比为5，但本例没有真实 cube 或原 strict-K/history 资格。

用 cutoff 权 w_e，I_e=Σf_i w_e(i)，k0e=f w_e/I_e，γ_e(i)=log[mA w_e(i)/I_e]=log[k0e(i)/πA(i)]。所以本节 γ 由实际有限后验生成，不是任意指定的成本表。

三个参数为：

| 例 | w1 | w2 | 公共整数单端帽 N |
|---|---|---|---|
| unequal_skew | (1/4,1,0) | (2/3,1,0) | 3 |
| crossed_weights | (1/4,1,0) | (1,1/4,0) | 3 |
| equal_channels | (1,1,0) | (1,1,0) | 1 |

实际单端边缘 μ_e=(1/2,1/2,0)，逐项核 μ_e≤N B_e，其中 B_e=k0e。hard selector 用 argmin γ（tie 选0），逐状态核 min=(均值)−|差|/2，且对公平 disjoint orientation reference Bp(e,i)=B_e(i)/2 的选后密度帽≤2N。

soft selector 取 p=(1/2,1/2)，r_e=p_e exp(−γ_e)/Σp exp(−γ)。因 expγ 都是有理数，所有 r、选后边缘和 a_e=E_P[r_e|side e] 均用 Fraction 精确计算。JSON 记录每个状态的 r 及每个端点的实际 a_e。逐状态和整体精确核验

Σrγ+KL(r||p)=−logΣp exp(−γ)，

KL(Pselected||Bp)≤log N+E_P KL(r||p)。

后一个不等式没有假设 joint cap。其差精确分解为非负 Jensen gap 与单端 cap gap：

E KL(r||p)−Σ_e∫μ_e a_e log(a_e/p_e)，
logN−Σ_e∫selected log(μ_e/B_e)。

同时核 selected source fit=selected conditional retention+selected channel，以及 conditional retention≤KL(Pselected||Bp)。

| 例 | soft free energy | 相对最佳固定端的节省 | 选后 RN 最大值 |
|---|---|---|---|
| unequal_skew | (11log2−log7)/4 | (log7−3log2)/4<0 | 85/24<6 |
| crossed_weights | 3log2−(log5)/2 | (log5)/2−log2=(log(5/4))/2>0 | 13/4<6 |
| equal_channels | log5 | 0 | 1<2 |

交叉权例中 hard selector 的 channel 节省为 (log2)/2，但扣公平方向的一 bit 后为 −(log2)/2；soft selector 则有上述严格正节省。等 γ 时 r=p，selection KL=0，无改善。这区分了选择机制，却没有给任意原流的根阶预算。

## 3. 对下一步的意义与缺口

可继续研究的实际量是同一原 P 上

F(P)=−∫log[(exp(−γy)+exp(−γz))/2]dP。

现有单端密度帽加 selector entropy 可支付选后 retention；本证书没有支付 F(P)。仍需原模型真实 P、两端原后验/质量门、合法字段与历史保持，以及 F(P) 的几何预算。不同 conditioning 的遗漏项、任意耦合参考和有限 source-only 例均不能替代这些条件。此处不拟合维数阶数，也不作一般混合或几何结论。

## 4. 实际执行与冻结

共7个小型 joint 表及3个同族 posterior-selector fixture；没有扫描。脚本实际完成 **566 个精确 checks**，其中包括支持合法性、质量/归一化断言、log 正性与符号断言；566不是独立样本数，独立输入为上述7表及3个selector fixture。输入、全部正质量表、cutoff、r、真实 a_e、费用及差额都在紧凑 JSON 中。Fraction 保质量与选择有理量；SymPy 将 log 表成有理系数的 prime-log，符号等式及符号比较通过共同分母后化为精确有理数与1的比较。未用浮点近似作数学判定，只有运行秒数为浮点元数据；无需 Arb。

解释器 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`，Python 3.12.14，SymPy 1.14.0。实际命令：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r460_numeric_check.py
```

最后运行约0.17秒 wall，最大 RSS 71,483,392 bytes。输出为脚本自身目录下 r460_numeric_check.json，无跨轮数据依赖。该报告完成后不再改脚本或 JSON，供主代理独立复现。

归档白名单：

- r460_numeric_plan.md（本报告，原计划已合并为实际结果）
- r460_numeric_check.py（自含复现）
- r460_numeric_check.json（566 checks 与计算索引）
