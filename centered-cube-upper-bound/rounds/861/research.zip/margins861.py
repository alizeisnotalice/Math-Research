"""R861 finite certificates for the good-owner and clipped-hit estimates.

Assume independent near-face trials with success probabilities at most p.
For K formed from both owners and m=k0+1, the union bound over m distinct
trials gives (2 n p)^m/m!. An axis is double-near with probability at most
p^2, so the union bound over three axes gives n^3 p^6/6.
The computation is conditional on the stated p bound and source geometry.
"""
from fractions import Fraction as F
from math import prod
import sys

from flint import arb, ctx, __version__ as flint_version

BITS = (192,384)
ORIGINAL = (12,32,512,2048,4096,8192,16384,131072)
EXPERIMENTS = {
    18: ORIGINAL+(2**48,),
    48: ORIGINAL+(2**28,2**34,2**36,2**48),
}


def positive(value):
    if value>0:
        return True
    assert value<0
    return False


def cap_log(value):
    if value>0:
        return arb(0)
    assert value<=0
    return value


def logadd(first,second):
    if first>second:
        return first+(second-first).exp().log1p()
    assert first<=second
    return second+(first-second).exp().log1p()


def calculate(exponent,cb_power,prec):
    ctx.prec=prec
    b=arb(1)/4
    cb=arb(1)/(1<<cb_power)
    log2=arb(2).log()
    log3=arb(3).log()
    log_n=exponent*log2
    ell=log_n+(log2-log_n).exp().log1p()
    a=cb*ell
    proxy=5+3*a
    assert proxy.log()<log_n
    x=b*ell/(2*log3)
    k=x.floor().unique_fmpz()
    assert k is not None
    k=int(k)
    assert k<x<k+1
    m=k+1
    assert m==int(x.ceil().unique_fmpz())
    ln_mean=(2*proxy).log()
    # Use m! = Gamma(m+1) in the log domain. No binomial arrays, n,
    # or factorial(m) are materialized for the largest test dimensions.
    ln_tail=cap_log(m*ln_mean-arb(m+1).lgamma())
    ln_chernoff=cap_log(m*(ln_mean+1-arb(m).log()))
    ln_double=6*proxy.log()-arb(6).log()-3*log_n
    ln_bad=cap_log(logadd(ln_tail,ln_double))
    ln_bad_chernoff=cap_log(logadd(ln_chernoff,ln_double))
    assert (ln_tail<=ln_chernoff or ln_tail.overlaps(ln_chernoff))

    ln_a=a.log()
    ln_owner_double=cap_log(-log3-ln_a)
    ln_weak_double=cap_log(-ln_a)-log3
    ln_owner=-k*log3+2*ln_owner_double
    ln_weak=-k*log3+2*ln_weak_double
    clip_threshold=(arb(5)/4).log()-b*log_n
    alpha=b/(2*log3)
    tail_rate=alpha*((alpha/(6*cb)).log()-1)
    whole_rate=arb(3) if tail_rate>3 else tail_rate

    return {
        "k":k, "a":a,
        "bad_rate":-ln_bad/log_n,
        "chernoff_bad_rate":-ln_bad_chernoff/log_n,
        "double_rate":-ln_double/log_n,
        "owner_good_log2_ratio":(ln_owner+b*log_n)/log2,
        "weak_good_log2_ratio":(ln_weak+b*log_n)/log2,
        "bad_le_3_2":positive(-ln_bad-3*log_n/2),
        "bad_le_2":positive(-ln_bad-2*log_n),
        "chernoff_bad_le_2":positive(-ln_bad_chernoff-2*log_n),
        "owner_good":positive(ln_owner-clip_threshold),
        "weak_good":positive(ln_weak-clip_threshold),
        "limit_tail_rate":tail_rate,
        "limit_bad_rate":whole_rate,
        "log2_M_over_B":arb(2)+b*exponent,
    }


def fmt(x):
    return x.str(10,radius=True)


def numerical():
    print("p upper=(5+3a)/n, a=nw/R=c_b ln(n+2), b=1/4, c=1.")
    print("Bad bound = min(1, min(1,(2np)^m/m!) + n^3 p^6/6), m=k0+1.")
    print("Chernoff replaces m! by (m/e)^m. Bad owner probability has a separate payment.")
    print("Good owner lower H=3^(-k0) min(1,1/(3a))^2; weaker H uses (min(1,1/a)/3)^2.")
    print("Good conditions compare H with (5/4)n^(-b), hence H-n^(-b)/4 >= n^(-b).")
    print("All logs for hit/mass ratios are base 2; rates are -ln(probability bound)/ln(n).")
    print("Arb 192/384-bit runs agree, including exact floor and ceiling.")
    for cb_power,exponents in EXPERIMENTS.items():
        header=calculate(exponents[0],cb_power,BITS[-1])
        print(" c_b=2^(-%d): limiting factorial/Chernoff tail rate" % cb_power,
              fmt(header["limit_tail_rate"]), "; limiting bad union rate",fmt(header["limit_bad_rate"]))
        both_counts=[0,0]
        for e in exponents:
            first,second=(calculate(e,cb_power,bits) for bits in BITS)
            for key,value in second.items():
                if isinstance(value,arb):
                    assert value.overlaps(first[key])
                else:
                    assert first[key]==value
            print("  n=2^%d" % e,"k0",second["k"],"a",fmt(second["a"]),
                  "; exact-cap bad, Chernoff bad, double-axis rates:",
                  *(fmt(second[k]) for k in ("bad_rate","chernoff_bad_rate","double_rate")))
            print("    bad <= n^(-3/2), <= n^(-2), Chernoff <= n^(-2):",
                  *(second[k] for k in ("bad_le_3_2","bad_le_2","chernoff_bad_le_2")),
                  "; good (owner, weaker):",second["owner_good"],second["weak_good"],
                  "; good log2 ratios:",fmt(second["owner_good_log2_ratio"]),
                  fmt(second["weak_good_log2_ratio"]),"; log2(M/B)",fmt(second["log2_M_over_B"]))
            both_counts[0]+=second["bad_le_3_2"] and second["owner_good"]
            both_counts[1]+=second["bad_le_2"] and second["owner_good"]
        if cb_power==18:
            assert header["limit_tail_rate"]<arb(3)/2
        else:
            assert header["limit_tail_rate"]>3 and both_counts[1]>=3
        print("    Joint finite certifications, stronger good bound and bad <= n^(-3/2), n^(-2):",*both_counts)


def length(*intervals):
    return max(F(0),min(b for a,b in intervals)-max(a for a,b in intervals))


def geometric():
    n=4
    R=F(1)
    depth=R/(2*n)
    print("Exact geometry with edge-2R centered cubes in four dimensions, R=1.")
    print("Q is centered at true common source 0, with one single-close and two double-close axes.")
    print("These widths isolate box geometry, independently of the large-dimension choice w.")
    for width in (F(1,16),F(1,4),F(1,2)):
        one=(-width/16,2*R-width/16)
        A=((-R,R),one,(-depth,2*R-depth),(-depth,2*R-depth))
        B=((-R,R),(-R,R),(-2*R+depth,depth),(-2*R+depth,depth))
        for cube in (A,B):
            assert all(e-d==2*R for d,e in cube)
            assert all(d<0<e for d,e in cube)
        Q=(-width/2,width/2)
        neighborhood=(-3*width/2,3*width/2)
        # A positive-volume source cell stays inside Q and both true receivers.
        eps=min(width/16,depth)/2
        assert volume(((-eps,eps),)*n)>0
        assert all(a<-eps<eps<b for a,b in A+B+(Q,))
        each=[length(a,b,neighborhood)/(3*width) for a,b in zip(A,B)]
        hit=prod(each)
        a=n*width/R
        lower=F(1,3)*min(F(1),1/(3*a))**2
        assert each[0]==1 and each[1]>=F(1,3)
        assert each[2]==each[3]==min(F(1),1/(3*a))
        assert hit>=lower
        # If the last single-close axis is strengthened to a third double,
        # compute rather than reuse the two-double bound.
        third=(min(F(1),1/(3*a)))**3
        print(" w=",width," a=",a," positive source volume",(2*eps)**n,
              "; actual axis hit shares",tuple(str(x) for x in each),
              "; exact product",hit," lower",lower,"; 3-double variant",third)


def volume(box):
    return prod(b-a for a,b in box)


if __name__=="__main__":
    print("Run: /Users/zzh/.local/share/math-research-tools/venv/bin/python -B -s margins861.py")
    print("Python",sys.version.split()[0],"python-flint",flint_version,
          "Arb precision",BITS,"bits plus exact integer floor/ceiling verification.")
    numerical()
    geometric()
    print("All assertions passed. Finite arithmetic and geometric checks under the stated model.")

