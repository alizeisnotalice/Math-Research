"""R861. Exact continuous R814 comb geometry for a fixed public 3Q kernel."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from math import prod
from pathlib import Path
from zipfile import ZipFile
import json
import sys

PINS={
    814:"891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    860:"2b530fd04c0f05f81e7c52cf4c644b07ce25103d96967927820f011c27c9ae39",
}
TAU=F(13140211)
WIDTHS=(F(1,16384),F(1,2048),F(1,256))


def member(rounds,edition,name):
    path=rounds/str(edition)/"research.zip"
    assert sha256(path.read_bytes()).hexdigest()==PINS[edition]
    with ZipFile(path) as z:
        code=z.read(name)
        manifest=json.loads(z.read("MANIFEST.json"))
    assert sha256(code).hexdigest()==manifest["sha256" if edition==860 else "members"][name]
    scope={"__name__":"r861_archive","__file__":name}
    exec(compile(code,name,"exec"),scope)
    return scope


def intersect(a,b):
    return tuple((max(x,u),min(y,v)) for (x,y),(u,v) in zip(a,b))


def length(a,b):
    return max(F(0),min(a[1],b[1])-max(a[0],b[0]))


def mul_cells(axis_data,start):
    out={start:F(1)}
    for row in axis_data:
        temp=defaultdict(F)
        for (a,x),(b,y) in product(out.items(),row.items()):
            if x and y:
                temp[a&b]+=x*y
        out=temp
    return dict(out)


def gather_segments(comb,parents,stage):
    density=stage["density"]
    support,period,phase,bump=(density[k] for k in
        ("support","period","bump_center_mod_period","bump_half_width"))
    lo,hi=support
    face_axes=zip(*(p["box"] for p in parents.values()))
    common={lo,hi}
    for i in range(lo//period,hi//period):
        center=i*period+phase
        common.update((center-bump,center+bump))
    segments=[]
    for axes in face_axes:
        bp=sorted(common|{x for ab in axes for x in ab})
        local=[]
        for a,b in zip(bp,bp[1:]):
            x=(a+b)/2
            mask=sum(p["bit"] for p,(l,r) in zip(parents.values(),axes) if l<x<r)
            ct=comb["interval_mass"](a,b,bump)/(b-a)
            assert ct in (density["density_floor_one_axis"],density["density_peak_one_axis"])
            local.append((a,b,mask,ct))
        segments.append(local)
    return segments


def integral_axis(a,b,target,w):
    """Exact integral of |3Q(y) intersect target|/(3w) over [a,b]."""
    start,end=a//w,b//w
    A,B=target
    def fn(j):
        return length(((j-1)*w,(j+2)*w),target)/(3*w)
    if start==end:
        return (b-a)*fn(start)
    result=((start+1)*w-a)*fn(start)+(b-end*w)*fn(end)
    x,y=start+1,end
    splits={x,y}
    for coord in (A/w-2,B/w-2,A/w+1,B/w+1):
        lo=coord//1
        splits.update(q for q in (lo-1,lo,lo+1,lo+2) if x<q<y)
    breaks=sorted(splits)
    for lo,hi in zip(breaks,breaks[1:]):
        n=hi-lo
        assert n>=1
        u,v=fn(lo),fn(hi-1)
        middle=(lo+hi-1)//2
        assert (fn(middle)-u)*(n-1)==(middle-lo)*(v-u)
        result+=w*n*(u+v)/2
    assert 0<=result<=b-a
    if end-start<=20:
        direct=sum(length((a,b),(j*w,(j+1)*w))*fn(j) for j in range(start,end+1))
        assert direct==result
    return result


def hit_and_support(segments,gates,width,src,records,bits):
    output={}
    ids={i:set() for i in gates}
    for t,l,r in records:
        for i,z,k in (l,r):
            ids[t,i].add(z)
    for (t,i),target in gates.items():
        gate=bits[t]|bits[i]
        by_axis=[]
        for segment,interval in zip(segments,target):
            axis=defaultdict(F)
            for a,b,mask,ct in segment:
                if mask&gate==gate:
                    axis[mask]+=ct*integral_axis(a,b,interval,width)
            by_axis.append(axis)
        combined=mul_cells(by_axis,sum(bits.values()))
        for mask in ids[t,i]:
            assert mask&gate==gate
            probability=combined.get(mask,F(0))/src[mask]
            assert 0<=probability<=1
            output[t,i,mask]=probability
    return output


def all_mass_cells(segments,m):
    data=[]
    for intervals in segments:
        axis=defaultdict(F)
        for lo,hi,mask,ct in intervals:
            axis[mask]+=(hi-lo)*ct
        data.append(axis)
    return mul_cells(data,m)


def box_input_mass(segments,coords,active,full):
    data=[]
    for intervals,window in zip(segments,coords):
        axis=defaultdict(F)
        for lo,hi,s,ct in intervals:
            hit=length((lo,hi),window)
            if hit:
                axis[s]+=ct*hit
        data.append(axis)
    hits=mul_cells(data,full)
    return sum(v for c,v in hits.items() if c in active)


def components(boxes,w):
    groups=[]
    for box in boxes:
        adjacent=[i for i,arr in enumerate(groups)
                  if any(all(max(a,d)-min(b,e)<3*w for (a,b),(d,e) in zip(box,s))
                         for s in arr)]
        new=[box]
        for j in reversed(adjacent):
            new.extend(groups.pop(j))
        groups.append(new)
    return groups


def output_caps(segments,gates,active,w,stage,comb,full):
    density=stage["density"]
    bump=density["bump_half_width"]
    baseline=density["density_floor_one_axis"]
    height=density["density_peak_one_axis"]
    W=3*w
    assert W+2*bump<density["period"]
    maxaxis=W*baseline+min(W,2*bump)*(height-baseline)
    # At x in one base output cell Q, exactly the sources in 3Q can
    # contribute. A 3Q meets positive source membership in at most one
    # component, since intercomponent pairs have an axis gap at least W.
    groups=components(gates.values(),w)
    envelope=[]
    outputs=set()
    for group in groups:
        hull=tuple((min(ab[0] for ab in axis),max(ab[1] for ab in axis))
                   for axis in zip(*group))
        envelope.append(prod(min(maxaxis,comb["interval_mass"](a,b,bump))/W
                             for a,b in hull))
        for box in group:
            choices=[]
            for lo,hi in box:
                mid=(lo+hi)/2
                phase,period=density["bump_center_mod_period"],density["period"]
                # Candidate exact output voxels: midpoint and closest peak.
                center=(mid-phase)/period+F(1,2)
                closest=phase+period*(center//1)
                choices.append(sorted({mid//w,closest//w}))
            outputs.update(product(*choices))
    upper=max(envelope)
    lower=F(0)
    for index in outputs:
        coords=tuple(((j-1)*w,(j+2)*w) for j in index)
        lower=max(lower,box_input_mass(segments,coords,active,full)/W**len(coords))
    assert 0<lower<=upper
    return lower,upper,len(groups)


def record_mass(data,hits,parents,mass,scale):
    sums={name:F(0) for name in ("L","R","both","either")}
    mp=[defaultdict(F),defaultdict(F)]
    base=[defaultdict(F),defaultdict(F)]
    for (t,l,r),raw in sorted(data.items()):
        x,y=(scale*hits[t,arm[0],arm[1]] for arm in (l,r))
        both=x*y
        either=x+y-both
        assert 0<=both<=either<=1
        sums["L"]+=raw*x
        sums["R"]+=raw*y
        sums["both"]+=raw*both
        sums["either"]+=raw*either
        for j,(i,z,k) in enumerate((l,r)):
            mp[j][i,k]+=raw*both
            base[j][i,k]+=raw
    assert sum(mp[0].values())==sum(mp[1].values())==sums["both"]
    peak=[]
    for marginal,old in zip(mp,base):
        assert all(v<=old[i,k]<=parents[i]["owner_volume"]/2
                   for (i,k),v in marginal.items())
        peak.append(max(2*v/parents[i]["owner_volume"] for (i,k),v in marginal.items()))
    return sums,peak


def main(rounds):
    p860=member(rounds,860,"public860.py")
    comb=member(rounds,814,"comb811.py")
    stage=comb["fixture"](*comb["FIXTURES"][-1])
    parents,src,records,hard,fmt,pin,hard_cut=p860["load"](rounds)
    assert pin==PINS[814] and len(records)==920 and len(hard)==848
    assert tuple(parents)==tuple(stage["parent_order"])
    bits={i:p["bit"] for i,p in parents.items()}
    full=sum(bits.values())
    segments=gather_segments(comb,parents,stage)
    assert all_mass_cells(segments,full)==src
    active={arm[1] for _,l,r in records for arm in (l,r)}
    arms=sorted({(t,arm[0]) for t,l,r in records for arm in (l,r)})
    gates={(t,i):intersect(parents[t]["box"],parents[i]["box"]) for t,i in arms}
    mass=sum(records.values())
    assert sum(hard.values())==hard_cut[2]
    print("Python",sys.version.split()[0],"; exact Fraction integration; no optimization called.")
    print("Pinned R814 and R860",PINS[814],PINS[860])
    print("True full source cell masses recovered from the archived product comb.")
    print("Positive records, hard-cut records, used true price masks, real arm boxes:",
          len(records),len(hard),len(active),len(arms))
    print("Original F, hard F(A,B)/F, R859 contract deficit/F:",
          fmt(mass),fmt(sum(hard.values())/mass),fmt((hard_cut[2]-hard_cut[3])/mass))
    print("Common zero-origin grid with base side w. Every live physical price y sends uniformly to 3Q(y).")
    print("Actual outputs are zero outside the ten active price-input cells. Scale min(1,tau/upper) is a certified uniform thinning.")
    print("Fixed output density cap tau =",TAU,"; all displayed weighted capture scores normalized by full original F.")
    print("L,R,both,either use independent transport draws of the actual two original prices.")
    print("Uniform density thinning is a feasible lower certificate for these scores; no pointwise clipping score is evaluated.")
    print("The outputs certify geometric marked original mass and the original U/W marginals.")
    print("F(A,B) has the same global fixed plan; its capacities do not reset.")
    for w in WIDTHS:
        hits=hit_and_support(segments,gates,w,src,records,bits)
        lower,upper,groups=output_caps(segments,gates,active,w,stage,comb,full)
        scale=min(F(1),TAU/upper)
        print(" w =",w,"; max actual output density lower/upper",fmt(lower,upper),
              "; separated corner components",groups,"; certified thinning",fmt(scale))
        print("  individual true-price-cell/arm expected hit interval:",fmt(min(hits.values()),max(hits.values())))
        for data_name,data in (("all",records),("hard",hard)):
            uncut,marg=record_mass(data,hits,parents,mass,F(1))
            retained,post_marg=record_mass(data,hits,parents,mass,scale)
            assert retained["both"]==uncut["both"]*scale**2
            assert retained["L"]==uncut["L"]*scale and retained["R"]==uncut["R"]*scale
            print("  ",data_name,"raw L,R,both,either:",*(fmt(uncut[k]/mass) for k in ("L","R","both","either")))
            print("  ",data_name,"density-certified both,either:",
                  fmt(retained["both"]/mass),fmt(retained["either"]/mass),
                  "; max raw and certified both per actual U/W half Leb:",
                  tuple(fmt(v) for v in marg),tuple(fmt(v) for v in post_marg))
    print("All assertions passed. No identification of geometric capture with old contract payment.")


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--rounds",type=Path,required=True)
    main(parser.parse_args().rounds)

