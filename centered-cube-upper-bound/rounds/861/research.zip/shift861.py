"""Exact common dyadic shifts, threefold refill, and all-generation truncation."""

from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
from math import prod
from sys import version

DENSITY = F(3, 2)
M = 1


@dataclass(frozen=True)
class Stop:
    level: int
    box: tuple
    packet: tuple
    mass: F


def cube(center, radius):
    return tuple((x-radius, x+radius) for x in center)


def volume(box):
    return prod(hi-lo for lo, hi in box)


def overlap(a, b):
    return prod(max(F(0), min(hi, hi2)-max(lo, lo2))
                for (lo, hi), (lo2, hi2) in zip(a,b))


def stop_family(n, levels, branch):
    stops = []
    for j in range(levels+1):
        h = F(1, 2**j)
        origins = [F(0)]
        if branch and j >= 2:
            origins.append(F(1, 2))
        if branch and j >= 3:
            origins.extend((F(1, 4), F(3, 4)))
        for y in origins:
            anchor = (h, y) + (F(0),)*(n-2)
            box = tuple((x, x+h) for x in anchor)
            packet = tuple((x + 3*h/8, x + 5*h/8) for x in anchor)
            stops.append(Stop(j, box, packet, DENSITY*h**n))
    assert all(overlap(a.box, b.box) == 0 for a,b in combinations(stops,2))
    return stops


def audit_cyclic_tree(stops, n):
    """Strict ancestors in the actual cyclic binary dyadic tree of [0,2]^n."""
    ancestors = defaultdict(F)
    for stop in stops:
        mid = tuple((lo+hi)/2 for lo,hi in stop.box)
        depth = n*(stop.level+1)
        assert volume(stop.box)*2**depth == 2**n
        assert overlap(stop.box, ((F(0),F(2)),)*n) == volume(stop.box)
        for d in range(depth):
            q,r = divmod(d,n)
            scales = tuple(F(2,2**(q+(i<r))) for i in range(n))
            key = d, tuple(x//s for x,s in zip(mid,scales))
            ancestors[key] += stop.mass
    # Every other tree node is either disjoint from the pieces or in a stopped Q.
    parent_peak = max(mass*2**d/2**n for (d,_),mass in ancestors.items())
    assert parent_peak <= 1
    assert all(F(1) < stop.mass/volume(stop.box) <= 2 for stop in stops)
    return parent_peak


def translate(box, shift):
    return tuple((lo + m*(hi-lo), hi + m*(hi-lo))
                 for (lo,hi),m in zip(box,shift))


def triple(box):
    return tuple((2*lo-hi,2*hi-lo) for lo,hi in box)


def axis_partition(intervals):
    """A signature retains one bit per actual output box plus the gate bit."""
    events = defaultdict(int)
    for index,(lo,hi) in enumerate(intervals):
        assert lo < hi
        events[lo] ^= 1<<index
        events[hi] ^= 1<<index
    mask = 0
    result = defaultdict(F)
    limit = (1<<(len(intervals)-1))-1
    last = min(events)
    for edge in sorted(events):
        if mask & limit:
            result[mask] += edge-last
        mask ^= events[edge]
        last = edge
    assert mask == 0
    return result


def multiply_partitions(left, right, limit):
    result = defaultdict(F)
    for s,a in left.items():
        for t,b in right.items():
            mask = s&t
            if mask & limit:
                result[mask] += a*b
    return result


def arrangement(boxes, gate):
    gate_bit = 1<<len(boxes)
    limit = gate_bit-1
    cells = {2*gate_bit-1:F(1)}
    partitions = {}
    for axis in zip(*boxes, gate):
        if axis not in partitions:
            partitions[axis] = axis_partition(axis)
        cells = multiply_partitions(cells, partitions[axis], limit)
    return cells, gate_bit


def bit_indices(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length()-1
        mask ^= bit


def analyze(stops, boxes, gate, m, coefficient, aligned):
    if aligned:
        for index,a in enumerate(boxes):
            for b in boxes[index+1:]:
                assert overlap(a,b) in {0, min(volume(a),volume(b))}
    cells, gate_bit = arrangement(boxes,gate)
    removed = [F(0) for _ in stops]
    hit = [F(0) for _ in stops]
    integrals = [F(0) for _ in stops]
    peak_before = peak_after = F(0)
    max_level_count = 0
    for mask,cell_volume in cells.items():
        levels = defaultdict(list)
        for index in bit_indices(mask & (gate_bit-1)):
            levels[stops[index].level].append(index)
        fine = 0
        retain = 0
        for level in sorted(levels,reverse=True):
            indices = levels[level]
            max_level_count = max(max_level_count,len(indices))
            assert len(indices)*coefficient <= 1
            for index in indices:
                integrals[index] += fine*coefficient*cell_volume
            if fine*coefficient > m:
                for index in indices:
                    removed[index] += cell_volume
            else:
                retain += len(indices)
                if mask & gate_bit:
                    for index in indices:
                        hit[index] += cell_volume
            fine += len(indices)
        peak_before = max(peak_before,DENSITY*coefficient*fine)
        peak_after = max(peak_after,DENSITY*coefficient*retain)
        assert coefficient*retain <= m+1
        assert DENSITY*coefficient*retain <= 2*(m+1)

    first_excluded = ((m//coefficient)+1)*coefficient
    assert first_excluded == m+coefficient
    probabilities = []
    means = []
    for i,out in enumerate(boxes):
        size = volume(out)
        # Independent calculation of the volume mean of the strict finer count.
        direct = sum((overlap(out, other) for j,other in enumerate(boxes)
                      if stops[j].level > stops[i].level),F(0))*coefficient
        assert direct == integrals[i]
        means.append(direct/size)
        probabilities.append(removed[i]/size)
        assert 0 <= probabilities[-1] <= means[-1]/first_excluded
        if not aligned:
            assert probabilities[-1] <= means[-1]/m

    recovered = sum((h*DENSITY*coefficient for h in hit),F(0))
    captured_raw = sum((overlap(b,gate)*DENSITY*coefficient for b in boxes),F(0))
    discarded = sum(removed)*DENSITY*coefficient
    source_mass = sum(stop.mass for stop in stops)
    assert sum(map(volume,boxes))*DENSITY*coefficient == source_mass
    assert 0 <= recovered <= captured_raw <= source_mass
    assert 0 <= discarded < source_mass
    assert captured_raw-recovered <= discarded
    return (peak_before,peak_after,max_level_count,max(means),max(probabilities),
            discarded,recovered,captured_raw,hit[0]*DENSITY*coefficient)


def audit_average(stops, triples, gate, n):
    for stop,out in zip(stops,triples):
        sides = []
        for (a,b),(lo,hi),test in zip(stop.box,out,gate):
            h = b-a
            neighbors = ((a-h,b-h),(a,b),(a+h,b+h))
            assert neighbors[0][0] == lo and neighbors[-1][1] == hi
            assert all(first[1] == second[0] for first,second in zip(neighbors,neighbors[1:]))
            sides.append(sum(overlap((piece,),(test,)) for piece in neighbors))
        assert prod(sides) == overlap(out,gate)
    if n == 2:
        common = list(product((-1,0,1),repeat=n))
        discrete = sum((overlap(translate(stop.box,m),gate)*DENSITY
                        for m in common for stop in stops),F(0))/3**n
        expanded = sum((overlap(out,gate)*DENSITY for out in triples),F(0))/3**n
        assert discrete == expanded


def exercise(label,n,levels,branch):
    stops = stop_family(n,levels,branch)
    parent_peak = audit_cyclic_tree(stops,n)
    total = sum(stop.mass for stop in stops)
    # Fixed genuine cubes of sides 1 and 3/2. Their centers have disjoint positive cores.
    u = (F(0),)+(F(1,2),)*(n-1)
    t = (F(1),)+(F(1,2),)*(n-1)
    a_u,a_t = cube(u,F(1,2)),cube(t,F(3,4))
    gate = tuple((max(a,c),min(b,d)) for (a,b),(c,d) in zip(a_u,a_t))
    assert gate == ((F(1,4),F(1,2)),)+((F(0),F(1)),)*(n-1)
    assert overlap(stops[0].packet,a_t) == volume(stops[0].packet)
    assert overlap(stops[0].packet,a_u) == 0
    for center in (u,t):
        core = cube(center,F(1,64))
        assert all(lo-1 >= -3 and hi+1 <= 3 for lo,hi in core)
    assert overlap(cube(u,F(1,64)),cube(t,F(1,64))) == 0
    # Ambient density 4 off the support of mu_B, with actual source f_B on its support.
    assert all(stop.mass/volume(stop.packet) >= 4 for stop in stops)
    assert total < 3
    assert F(7,2) < 4 and 4+total <= 7
    true_hit = sum((stop.mass*overlap(stop.packet,gate)/volume(stop.packet)
                    for stop in stops),F(0))

    shifted = [translate(stop.box,(-1,)+(0,)*(n-1)) for stop in stops]
    original = [stop.box for stop in stops]
    triples = [triple(stop.box) for stop in stops]
    for b in shifted:
        h = b[0][1]-b[0][0]
        assert all(hi-lo == h and lo%h == 0 for lo,hi in b)
    audit_average(stops,triples,gate,n)
    basic = analyze(stops,original,gate,M,F(1),True)
    moved = analyze(stops,shifted,gate,M,F(1),True)
    deterministic = analyze(stops,triples,gate,M,F(1,3**n),False)
    assert basic[5] == 0 and basic[6] == true_hit
    assert basic[-1] == 0 and moved[-1]/stops[0].mass == F(1,4)
    assert deterministic[-1]/stops[0].mass == F(1,4*3**n)
    assert moved[6] > true_hit

    print(f"{label} n={n}, depth spread={levels}, stops={len(stops)}, M={M}, "
          f"max strict-ancestor average={parent_peak}")
    print(f"  true source mass={total}, original physical source hit={true_hit}")
    print(f"  coarsest retained output hit per its original mass, identity / left public shift / 3Q = "
          f"0 / {moved[-1]/stops[0].mass} / {deterministic[-1]/stops[0].mass}")
    for name,stats in (("common -e1",moved),("uniform 3Q",deterministic)):
        before,after,count,mean,drop,lost,hit,raw,_ = stats
        print(f"  {name}: peak before={before}, after={after}, max same-generation count={count}")
        print(f"    max exact finer mean={mean}, max exact deleted fraction={drop}, "
              f"total actual discarded={lost}")
        print(f"    true gate payment before={raw}, after={hit}, retained/true original={hit/true_hit}")
    if label == "PRESSURE":
        # A second actual pair puts its overlap in the trimmed near-origin zone.
        narrow = F(1, 2**12)
        with_left = cube((narrow-F(1,2), F(1,2)), F(1,2))
        with_right = cube((F(3,4), F(1,2)), F(3,4))
        tight_gate = tuple((max(a,c),min(b,d)) for (a,b),(c,d) in zip(with_left,with_right))
        assert tight_gate == ((F(0),narrow),(F(0),F(1)))
        print("  second real cube overlap, horizontal gate [0,2^-12]")
        for name, boxes, coefficient in (("common -e1", shifted, F(1)),
                                           ("uniform 3Q", triples, F(1,3**n))):
            stats = analyze(stops, boxes, tight_gate, M, coefficient, coefficient == 1)
            rec, raw = stats[6:8]
            assert 0 < rec < raw
            print(f"    {name} true gate before={raw}, after={rec}, discarded fraction={(raw-rec)/raw}")
    return moved,deterministic


if __name__ == "__main__":
    print(f"Python {version.split()[0]}, exact Fraction. Boundaries have zero source and receiver mass.")
    print("Original stopped cubes are disjoint in the actual axis-cyclic binary dyadic tree.")
    print("A single shift -e1 acts on every cube at its own side length. Identity is the bad offset.")
    print("Both witness cores share the same height band, lambda=7/2, and the gate is the true cube intersection.")
    print("In 3Q the finer count is weighted by 3^-n. The untrimmed map is exactly the mean of all 3^n public shifts.")
    print("Trimming keeps finer count <=M, with no renormalization. The exact maximum allowed density is bounded by 2(M+1).")
    print("For each box, deleted fraction <= finer mean/(M+1) on a fixed shift and <= finer mean/M for 3Q.")
    print("The calculation uses a finite geometric subflow.")
    exercise("INITIAL",2,4,False)
    shifted,three = exercise("PRESSURE",2,16,True)
    assert shifted[5] > 0 and three[5] > 0
    exercise("EXPANDED",6,12,True)
