#!/usr/bin/env python3
"""Round55: true finite-source receiver energy, exact M and finite-box probes.

Distances and equal-distance batches use Fraction. Decimal event integrals,
Gram checks, arrival identities and precision comparisons are numerical guards,
not outward-rounded certificates. Finite-box receiver sampling reports sample
standard errors; it is not an all-space bound, confidence certificate, or fit.
All sources in the principal experiment are positive finite atomic measures.
"""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from pathlib import Path
import json
import math
import random
import time
from itertools import combinations


def fs(x):
    x=F(x)
    return str(x.numerator) if x.denominator==1 else f'{x.numerator}/{x.denominator}'


def dec(x):
    x=F(x)
    return Decimal(x.numerator)/Decimal(x.denominator)


def ds(x):
    return format(x,'.24E') if x else '0'


def volumes(source,x,n):
    return [((2*max(abs(x[i]-y[i]) for i in range(n)))**n,p) for y,p in source]


def exact_max(vp):
    if any(v==0 for v,p in vp):
        return None
    batches={}
    for v,p in vp:
        batches[v]=batches.get(v,F(0))+p
    mass=F(0); answer=F(0)
    for v in sorted(batches):
        mass+=batches[v]
        answer=max(answer,mass/v)
    return answer


def evaluate(vp,lam,precision=60,arrival=False):
    """Fullscale event integrals using z=e^-u and independently built Gram."""
    with localcontext() as ctx:
        ctx.prec=precision
        q=(-Decimal(1)).exp(); c=1-q; level=dec(lam)
        data=[(dec(v),dec(p)) for v,p in vp]
        assert all(v>0 and p>0 for v,p in data)
        events={}
        for i,(v,p) in enumerate(data):
            events.setdefault(1/(q*v),[]).append((i,True))
            events.setdefault(1/v,[]).append((i,False))
        zs=sorted(events,reverse=True)
        rising=set(); past=set(); full=band=Decimal(0)
        pieces=[]
        for index,zhi in enumerate(zs):
            for i,start in events[zhi]:
                if start: rising.add(i)
                else: rising.remove(i); past.add(i)
            A=sum((data[i][1]/data[i][0] for i in rising),Decimal(0))
            C=c*sum((data[i][1] for i in past),Decimal(0))-q*sum((data[i][1] for i in rising),Decimal(0))
            zlo=zs[index+1] if index+1<len(zs) else Decimal(0)
            value=C*C*(zhi*zhi-zlo*zlo)/2
            full+=value
            restricted=Decimal(0)
            if C:
                roots=sorted(((level-A)/C,(2*level-A)/C))
                low=max(zlo,roots[0]); high=min(zhi,roots[1])
                if high>low:
                    restricted=C*C*(high*high-low*low)/2
                    band+=restricted
            pieces.append((zhi,zlo,A,C,restricted))
        gram=Decimal(0)
        for i,(vi,pi) in enumerate(data):
            for j,(vj,pj) in enumerate(data):
                small,big=sorted((vi,vj)); ratio=big/small
                if ratio<=1/q:
                    kernel=(2-q-q*ratio*ratio)/(2*big*big)
                else:
                    kernel=-c*c/(2*q*big*big)
                gram+=pi*pj*kernel
        scale=max(full,Decimal('1e-200'))
        gram_relative=abs(gram-full)/scale
        assert gram_relative<Decimal(10)**(-precision+12)
        assert full>=0 and 0<=band<=full
        out={'full':full,'band':band,'gram_relative':gram_relative,'pieces':pieces}
        if arrival:
            def B(z):
                value=Decimal(0)
                for v,p in data:
                    if z>1/(q*v): continue
                    if z>1/v: value+=p/v-q*p*z
                    else: value+=c*p*z
                return value
            def psi(b): return min(level,max(Decimal(0),b-level))
            terms=[]
            for v,p in data:
                start,end=B(1/(q*v)),B(1/v)
                terms.append(p/v*(psi(end)-psi(start)))
            identity=sum(terms,Decimal(0))
            error=abs(identity-band)/max(band,Decimal('1e-100'))
            assert error<Decimal(10)**(-precision+15)
            out.update(arrival_terms=terms,arrival_error=error)
        return out


def independent_time_quadrature(vp,lam):
    """Direct derivative sums at time midpoints, split at actual band roots."""
    q=math.exp(-1); c=1-q
    data=[(float(v),float(p)) for v,p in vp]
    events=sorted({math.log(v)-1 for v,p in data}|{math.log(v) for v,p in data})
    def derivative(u):
        return sum((q*p*math.exp(-u) if math.log(v)-1<u<math.log(v)
                    else -c*p*math.exp(-u) if u>math.log(v) else 0.) for v,p in data)
    def B(u):
        return sum((p/v-q*p*math.exp(-u) if math.log(v)-1<u<math.log(v)
                    else c*p*math.exp(-u) if u>=math.log(v) else 0.) for v,p in data)
    full=band=0.
    for left,right in zip(events,events[1:]):
        middle=(left+right)/2
        A=sum(p/v for v,p in data if math.log(v)-1<middle<math.log(v))
        C=c*sum(p for v,p in data if middle>math.log(v))-q*sum(p for v,p in data if math.log(v)-1<middle<math.log(v))
        edges=[left,right]
        if C:
            for target in (float(lam),2*float(lam)):
                z=(target-A)/C
                if z>0:
                    root=-math.log(z)
                    if left<root<right: edges.append(root)
        edges.sort()
        for a,b in zip(edges,edges[1:]):
            steps=256; h=(b-a)/steps
            subtotal=sum(derivative(a+(i+.5)*h)**2 for i in range(steps))*h
            full+=subtotal
            if float(lam)<B((a+b)/2)<2*float(lam): band+=subtotal
    # Independent analytic end tail after every atom is past. Include the
    # band crossing roots on this exponential tail separately.
    last=events[-1]; C=c*sum(p for v,p in data)
    z=math.exp(-last)
    full+=C*C*z*z/2
    low=max(0.,float(lam)/C); high=min(z,2*float(lam)/C)
    if high>low: band+=C*C*(high*high-low*low)/2
    return full,band


def build_source(n,pattern,N,seed):
    rng=random.Random(seed)
    if pattern=='fixed_occupancy_atomic_variant':
        points=[tuple(F(1 if i in subset else -1,4) for i in range(n))
                for subset in combinations(range(n),n//2)]
        return [(y,F(1,len(points))) for y in points]
    if pattern=='block_XOR_atomic_variant':
        points=[tuple(F(1 if ((mask>>(i//2))&1) else -1,4) for i in range(n))
                for mask in range(2**(n//2))]
        return [(y,F(1,len(points))) for y in points]
    if pattern=='asymmetric_double_peak_atomic_variant':
        return [(tuple(F(-1,4) for _ in range(n)),F(1,4)),
                (tuple(F(-1,4)+F(3,4*2**i) for i in range(n)),F(3,4))]
    points=[]
    for j in range(N):
        if pattern=='nested':
            points.append(tuple(F((-1)**(j+i),2**(j+2)) for i in range(n)))
        elif pattern=='lattice':
            points.append(tuple(F(2*j-(N-1),2*(N-1)) if i==0 else F(0) for i in range(n)))
        elif pattern=='correlated':
            points.append(tuple(F((-1)**i*(2*j-(N-1)),2*(N-1)) for i in range(n)))
        elif pattern=='two_positive_peaks':
            points.append(tuple(F(-1 if j<N//2 else 1,3)+F((j%3)-1,48) if i==0 else F((j%3)-1,64) for i in range(n)))
        else:
            points.append(tuple(F(rng.randrange(-32,33),64) for _ in range(n)))
    if pattern in ('nested','correlated'): weights=[F(1,2**(j+1)) for j in range(N)]
    elif pattern=='random': weights=[F(rng.randrange(1,33)) for _ in range(N)]
    else: weights=[F(1) for _ in range(N)]
    total=sum(weights,F(0)); merged={}
    for y,p in zip(points,weights): merged[y]=merged.get(y,F(0))+p/total
    source=list(merged.items())
    assert sum(p for y,p in source)==1 and all(p>0 for y,p in source)
    return source


def mean_se(values,volume):
    mean=sum(values)/len(values)
    variance=sum((x-mean)**2 for x in values)/(len(values)-1)
    return {'estimate':format(volume*mean,'.17g'),
            'sample_standard_error':format(volume*math.sqrt(variance/len(values)),'.17g')}


def source_probes():
    summaries=[]; point_checks=[]
    recipes=(('nested',4),('nested',12),('lattice',12),('correlated',8),('two_positive_peaks',6),('random',8))
    jobs=[(n,rindex,pattern,N) for n in (1,2,4,8,16) for rindex,(pattern,N) in enumerate(recipes)]
    for n in (2,4,6,8):
        jobs.extend((n,rindex,pattern,N) for rindex,pattern,N in
                    ((6,'fixed_occupancy_atomic_variant',math.comb(n,n//2)),
                     (7,'block_XOR_atomic_variant',2**(n//2)),
                     (8,'asymmetric_double_peak_atomic_variant',2)))
    for n,rindex,pattern,N in jobs:
            seed=550000+1000*n+10*rindex
            source=build_source(n,pattern,N,seed)
            rng=random.Random(seed+1)
            low=tuple(min(y[i] for y,p in source)-F(3,4) for i in range(n))
            high=tuple(max(y[i] for y,p in source)+F(3,4) for i in range(n))
            box_volume=math.prod(float(high[i]-low[i]) for i in range(n))
            lam=F(1,4); caps=(2,4,16); collected={K:([],[]) for K in caps}
            gram_max=Decimal(0)
            for trial in range(64):
                x=tuple(low[i]+(high[i]-low[i])*F(rng.randrange(1,2**30),2**30) for i in range(n))
                vp=volumes(source,x,n); M=exact_max(vp)
                assert M is not None
                value=evaluate(vp,lam,60,arrival=trial==0)
                gram_max=max(gram_max,value['gram_relative'])
                for K in caps:
                    keep=M<=K*lam
                    collected[K][0].append(float(value['full']) if keep else 0.)
                    collected[K][1].append(float(value['band']) if keep else 0.)
                if trial==0:
                    fine=evaluate(vp,lam,100,arrival=True)
                    assert abs(value['full']-fine['full'])<=abs(fine['full'])*Decimal('1e-45')
                    assert abs(value['band']-fine['band'])<=max(abs(fine['band']),Decimal('1e-100'))*Decimal('1e-40')
                    direct=independent_time_quadrature(vp,lam)
                    errors=[abs(Decimal.from_float(direct[i])-fine[name])/max(fine[name],Decimal('1e-100')) for i,name in enumerate(('full','band'))]
                    assert errors[0]<Decimal('1e-4')
                    if fine['band']: assert errors[1]<Decimal('1e-4')
                    point_checks.append({'n':n,'pattern':pattern,'N':len(source),'receiver':[fs(z) for z in x],
                                         'M_exact':fs(M),'full_energy':ds(fine['full']),'band_energy':ds(fine['band']),
                                         'Gram_relative_error':ds(fine['gram_relative']),
                                         'arrival_identity_relative_error':ds(fine['arrival_error']),
                                         'arrival_terms':[ds(t) for t in fine['arrival_terms']],
                                         'positive_arrival_sum':ds(sum((t for t in fine['arrival_terms'] if t>0),Decimal(0))),
                                         'negative_arrival_sum':ds(sum((t for t in fine['arrival_terms'] if t<0),Decimal(0))),
                                         'direct_time_quadrature_relative_errors':[ds(z) for z in errors],
                                         'precision_digits':[60,100]})
            entropy=sum((-dec(p)*dec(p).ln() for y,p in source),Decimal(0))
            cap_summary=[]
            c=1-(-Decimal(1)).exp()
            for K in caps:
                full,band=collected[K]
                H=K*lam
                fullstats=mean_se([z/float(H) for z in full],box_volume)
                bandstats=mean_se([z/float(lam) for z in band],box_volume)
                cap_summary.append({'K':K,'H_exact':fs(H),'Ecap_over_H_mass':fullstats,
                                    'Ebandcap_over_lambda_mass':bandstats,
                                    'accepted_receiver_count':sum(v>0 for v in full),
                                    'fullspace_entropy_upper_for_Ecap_over_H_mass':ds(2*c*(1+entropy)),
                                    'fullspace_entropy_upper_for_band_over_lambda_mass':ds(sum((dec(p)*max(Decimal(0),(c*K/dec(p)).ln()) for y,p in source),Decimal(0)))})
            summaries.append({'n':n,'pattern':pattern,'requested_N':N,'actual_N':len(source),
                              'source_seed':seed,'receiver_seed':seed+1,'source_mass':'1',
                              'source':[{'position':[fs(t) for t in y],'weight':fs(p)} for y,p in source],
                              'depth':N if pattern=='nested' else None,'source_entropy_decimal':ds(entropy),
                              'lower_catalog_relation':'Small finite positive atomic pressure variant inspired by the catalog; not its positive-width lower-bound theorem.' if 'atomic_variant' in pattern else None,
                              'receiver_box_low':[fs(z) for z in low],'receiver_box_high':[fs(z) for z in high],
                              'receiver_samples':64,'receiver_sampling':'independent rational points from a 2^30-grid in the finite box',
                              'Gram_max_relative_error':ds(gram_max),'caps':cap_summary})
    return summaries,point_checks


def negative_arrival_guards():
    out=[]
    with localcontext() as ctx:
        ctx.prec=100
        far=Decimal(2).exp()/2
        for x in (Decimal(0),Decimal('0.0001'),Decimal('-0.0001')):
            # The transcendental geometry is explicitly Decimal-defined;
            # these are stability guards, not rational certificates.
            vp=[(F(2*abs(x-Decimal('.5'))),F(1)),(F(2*abs(x-far)),F(1,4))]
            M=exact_max(vp); assert M<=2
            value=evaluate(vp,F(1,8),100,arrival=True)
            assert value['arrival_terms'][1]<0
            out.append({'x_decimal':ds(x),'far_position_definition':'exp(2)/2',
                        'M_exact_for_decimal_geometry':fs(M),'lambda':'1/8','H':'2',
                        'arrival_terms':[ds(t) for t in value['arrival_terms']],
                        'band_energy':ds(value['band']),
                        'status':'true positive two-atom source with a negative second arrival term; not a weak-type counterexample'})
    return out


def skill_metadata():
    # Fixed record of this round's current installed files, read before coding.
    # No skill installation or absolute path is needed to rerun the experiment.
    hashes={
        'math-l01-lower-bound-test-parameters':(
            '780eefeb65f87067a273799b40900e4e0129d183ab1c5faa6dd0be520d43f917',
            'd8faaa3dedf23fdab8b1cce846c771861cf4d5d1060b2b0d667af6f78df030d6',
            'a319a2163fb6f570232e83a926e0481eff12d9df078c1c67951d0477d2924cf7',
            'a0326ffd5338e1dd05317ebed129d28b42dcc933c6c2c4828876efdfd95179e5'),
        'math-l02-adversarial-input-search':(
            'a4a7afc38da948ea8677142d694bbb31960e9791be9ed58d34ef49557157a343',
            '95c22cf63cefb84ae9be33dea381917a04ad0a7c76c1702441929db6165e3790',
            '1a4b8e5bc7d3851616b2e6be8b0fb7afcb230cb842f482b911f6a056e4f8df6a',
            '9c431b92a20f5269883ff240402d1a25459bb05c337cf48764b78b36a2cd8068'),
        'math-l03-rational-and-interval-certificates':(
            '0e2d41f62f831a87047487abb1bbcd7c74243cfa8e16cd6d702fe829124f5a9c',
            'ced0d588ce52a592b3142a8b5d4f09e37d3ebb9f6a922e1fc76e8e089b9ad5ab',
            '9a76bd1959a2b623dbe7951684ce55428bbd9e9ddaa4a3516688ca785b31508c',
            '764b98f99801a38b35ebeab5b3a934d5f8b31842ad3f94ff68da3b4844fe64a6')}
    relatives=('SKILL.md','references/provenance.md','references/method.md','references/cube-interface.md')
    items=[{'skill':name,'relative_path':rel,'sha256':h} for name,values in hashes.items() for rel,h in zip(relatives,values)]
    return {'current_read_files':items,
            'application':'Workflow only: actual common positive sources, strict thresholds, exact rational distance batches, separate numerical evidence and proof.',
            'limitations':'No general discrete-to-L1 migration or validated interval API imported. Decimal multi-precision is not outward-rounded certification.'}


def tie_boundary_guards():
    records=[]
    for n in (1,2,4,8):
        source=[(tuple(F(-1,2) if i==0 else F(0) for i in range(n)),F(1,2)),
                (tuple(F(1,2) if i==0 else F(0) for i in range(n)),F(1,2))]
        vp=volumes(source,tuple(F(0) for i in range(n)),n)
        M=exact_max(vp); assert M==1 and M<=4*F(1,4)
        value=evaluate(vp,F(1,4),100,arrival=True)
        assert abs(value['band']-Decimal('0.25'))<Decimal('1e-90')
        records.append({'n':n,'equal_distance_volume':'1','M_exact':'1','H_exact':'1',
                        'cap_equality_accepted':True,'band_energy_decimal':ds(value['band']),
                        'arrival_terms':[ds(t) for t in value['arrival_terms']],
                        'status':'Exact rational same-distance batch and cap equality guard'})
    return records


def main():
    start=time.monotonic()
    with localcontext() as ctx:
        ctx.prec=70
        sources,points=source_probes()
        negative=negative_arrival_guards()
        ties=tie_boundary_guards()
        counts={'finite_source_box_probes':len(sources),'independent_receiver_crosschecks':len(points),
                'negative_arrival_examples':len(negative),'tie_and_cap_boundary_guards':len(ties)}
        result={'round':55,'status':'PASS','standard_library_only':True,'counts':counts,
                'total_parameter_cases':sum(counts.values()),'receiver_event_Gram_checks':sum(s['receiver_samples'] for s in sources),
                'cap_summary_rows':3*len(sources),'skill_workflow':skill_metadata(),
                'scope':{'space':'Finite boxes only; sampling uses a 2^30 rational grid. Sample standard errors describe sampling variation on that finite grid; they do not bound spatial discretization bias or omitted box tails, and are not confidence intervals or full-space certificates.',
                         'source':'All main sources are true positive atomic measures of mass one; dimensions, counts, nesting depth and weights are separately recorded.',
                         'time':'Fullscale analytic event integration, no time grid for main energy. Direct midpoint time sums are independent auxiliary checks.',
                         'threshold':'M exact by rational equal-distance cumulative batches; cap uses M<=H, band uses lambda<B<2lambda.',
                         'arithmetic':'Fraction geometry and M; Decimal energy with precision checks. No outward rounding claimed.',
                         'entropy':'General entropy-dependent upper formulas are separately proved; no source-independent capped-energy conclusion inferred.',
                         'stages':[[1,2],[4,8],[16]],'stage_note':'Parameter groups in one reproducible execution, not independent-run claims.',
                         'fitting':'No dimension/order fit or arbitrary-source counterexample inferred from these probes.'},
                'source_box_probes':sources,'receiver_crosschecks':points,'negative_arrival':negative,
                'tie_and_cap_boundaries':ties}
        out=Path(__file__).with_name('results.json')
        out.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
        print('PASS',sum(counts.values()),counts,'receiver checks',result['receiver_event_Gram_checks'])
        print('Runtime seconds:',round(time.monotonic()-start,3))


if __name__=='__main__': main()
