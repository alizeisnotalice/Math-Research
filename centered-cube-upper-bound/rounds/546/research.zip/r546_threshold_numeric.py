import sys,time,platform,json,functools
from pathlib import Path
import sympy as sp,flint
from flint import arb,ctx
ctx.prec=256;START=time.monotonic();COMPARISONS=0
# Exact algebraic primitives copied from R545; no experiments imported.
def ev(e):
    e = sp.sympify(e)
    if e.is_Rational:
        return arb(int(e.p)) / int(e.q)
    if e.is_Add:
        return sum((ev(t) for t in e.args), arb(0))
    if e.is_Mul:
        a = arb(1)
        for t in e.args:
            a *= ev(t)
        return a
    if e.is_Pow:
        a, p = e.args
        if p.is_Rational:
            return ev(a).root(int(p.q)) ** int(p.p)
    raise ValueError(str(e))

def cmp(a, b):
    global COMPARISONS
    COMPARISONS += 1
    v = ev(a) - ev(b)
    if v > 0:
        return 1
    if v < 0:
        return -1
    if sp.simplify(a - b) == 0:
        return 0
    raise ArithmeticError(str(a - b))

def unique(v):
    a = sorted(v, key=functools.cmp_to_key(cmp))
    out = []
    for x in a:
        if not out or cmp(x, out[-1]) != 0:
            out.append(x)
    return out

def cert(v):
    v = sp.expand(v)
    return dict(exact=str(v), arb256=str(ev(v)), float=float(v))

def receiver_boxes(x,w,s):
 boxes=[];mass={}
 for S in range(1,1<<len(w)):
  ids=[i for i in range(len(w)) if S>>i&1];mass[S]=sum(w[i] for i in ids);half=sp.sqrt(mass[S]/s)/2
  lo=[max([x[i][j] for i in ids],key=functools.cmp_to_key(cmp))-half for j in range(2)];hi=[min([x[i][j] for i in ids],key=functools.cmp_to_key(cmp))+half for j in range(2)]
  if all(cmp(hi[j],lo[j])>0 for j in range(2)):boxes.append((S,lo,hi))
 return boxes,mass

def integrate_fixed_entry(x,w,s,base):
 layer,mass=receiver_boxes(x,w,s);allboxes=base+layer;edges=[unique([b[k][j] for b in allboxes for k in (1,2)]) for j in range(2)]
 def rank(v,j):return next(k for k,e in enumerate(edges[j]) if cmp(v,e)==0)
 def ranked(bs):return [(S,[rank(lo[j],j) for j in range(2)],[rank(hi[j],j) for j in range(2)]) for S,lo,hi in bs]
 old=ranked(base);new=ranked(layer);weights={};count=0;outside_count=0
 for ix in range(len(edges[0])-1):
  for iy in range(len(edges[1])-1):
   if not any(lo[0]<=ix<hi[0] and lo[1]<=iy<hi[1] for S,lo,hi in old):outside_count+=1;continue
   active=[S for S,lo,hi in new if lo[0]<=ix<hi[0] and lo[1]<=iy<hi[1]];assert active
   mm=max(mass[S] for S in active);best=[S for S in active if mass[S]==mm];assert len(best)==1;S=best[0]
   weights[S]=weights.get(S,0)+(edges[0][ix+1]-edges[0][ix])*(edges[1][iy+1]-edges[1][iy]);count+=1
 weights={S:sp.expand(v) for S,v in weights.items()};X=sp.expand(sum(weights.values()));D=[sp.expand(sum(s*v/mass[S] for S,v in weights.items() if S>>i&1)) for i in range(len(w))];energy=sp.expand(sum(w[i]*D[i]**2 for i in range(len(w))));normal=sp.expand(sum(w[i]*D[i] for i in range(len(w)))-s*X);assert normal==0
 return dict(s=s,X=X,D=D,energy=energy,weights=weights,grid_shape=[len(e)-1 for e in edges],entry_cells=count,excluded_nonentry_cells=outside_count)

def solve(name,x,w):
 x=[[sp.sympify(v) for v in p] for p in x];w=list(map(sp.Rational,w));base,mass=receiver_boxes(x,w,sp.Integer(1));original=integrate_fixed_entry(x,w,sp.Integer(1),base);X=original['X'];cache={};models=[]
 for J in [2,4,8]:
  ss=[sp.Rational(1,2)+sp.Rational(2*j+1,4*J) for j in range(J)];assert sum(ss)/J==sp.Rational(3,4)
  rows=[]
  for s in ss:
   if s not in cache:cache[s]=integrate_fixed_entry(x,w,s,base)
   a=cache[s];assert sp.expand(a['X']-X)==0;rows.append(a)
  Dbar=[sp.expand(sum(a['D'][i] for a in rows)/J) for i in range(len(w))];Dt=[sp.expand(sp.Rational(4,3)*v) for v in Dbar];normal=sp.expand(sum(w[i]*Dt[i] for i in range(len(w)))-X);assert normal==0
  A=sp.expand(sum(w[i]*Dt[i]**2 for i in range(len(w))));diagonal=sp.expand(sp.Rational(16,9)*sum(a['energy'] for a in rows)/(J*J));average_energy=sp.expand(diagonal*J);cross=sp.Integer(0)
  for j in range(J):
   for k in range(j):cross+=sp.Rational(32,9*J*J)*sum(w[i]*rows[j]['D'][i]*rows[k]['D'][i] for i in range(len(w)))
  cross=sp.expand(cross);assert sp.expand(A-diagonal-cross)==0
  gap=sp.expand(average_energy-A);assert cmp(gap,0)>=0
  models.append(dict(J=J,thresholds_exact=[str(s) for s in ss],average_threshold_exact=str(sum(ss)/J),Dbar=[cert(v) for v in Dbar],Dtilde=[cert(v) for v in Dt],entrance_normalization_residual=str(normal),Atilde=cert(A),Atilde_minus_original_A1=cert(sp.expand(A-original['energy'])),normalized_mean_single_threshold_energy=cert(average_energy),actual_j_equals_k_double_sum_contribution=cert(diagonal),actual_j_not_equals_k_double_sum_contribution=cert(cross),cross_threshold_ordered_pair_count=J*(J-1),full_cross_reconstruction_residual=str(sp.expand(A-diagonal-cross)),Jensen_gap_mean_energy_minus_Atilde=cert(gap),scope='Exact deterministic finite midpoint-threshold model. Atilde includes all cross-threshold terms; this is not a certified continuous-threshold quadrature error bound.'))
 return dict(name=name,N=len(w),positions=[[str(v) for v in p] for p in x],masses=[str(v) for v in w],fixed_entry_X1=cert(X),original_threshold_A1=cert(original['energy']),original_D1=[cert(v) for v in original['D']],unique_threshold_layer_count=len(cache),layers=[dict(s=str(s),fixed_entry_area=cert(a['X']),joint_grid_shape=a['grid_shape'],fixed_entry_open_cells=a['entry_cells'],excluded_nonentry_cells=a['excluded_nonentry_cells'],root_center_areas_on_E1=[dict(mask=S,mass=str(mass[S]),R_s_squared=str(mass[S]/s),area=cert(v)) for S,v in sorted(a['weights'].items())],D_s=[cert(v) for v in a['D']],single_threshold_energy=cert(a['energy']),mass_weighted_Ds_equals_s_X1_exact=True) for s,a in sorted(cache.items())],models=models)
b=(1+sp.sqrt(sp.Rational(1,2)))/2
inputs=[('one_source',[[0,0]],[1]),('R540_two_source_contact',[[0,0],[b,0]],[sp.Rational(1,2)]*2),('asymmetric_three_source',[[0,0],[sp.Rational(2,5),sp.Rational(1,50)],[sp.Rational(9,20),sp.Rational(7,100)]],[sp.Rational(2,5),sp.Rational(3,10),sp.Rational(3,10)])]
results=[]
for args in inputs:
 st=time.monotonic();r=solve(*args);r['elapsed_seconds']=time.monotonic()-st;results.append(r);print(r['name'],[(a['J'],a['Atilde']['float'],a['normalized_mean_single_threshold_energy']['float'],a['actual_j_not_equals_k_double_sum_contribution']['float']) for a in r['models']],flush=True)
out=dict(command=sys.executable+' '+str(Path(__file__).resolve()),versions=dict(python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__),precision_bits=256,seed=None,scope='Three existing mass-one two-dimensional finite inputs, exactly J=2,4,8 midpoint threshold models. Original E1 fixed, never replaced by Es. Complete algebraic receiving-rectangle partition at every threshold. No N6 extension, scanning, optimization, continuous-threshold error certificate, or general energy-improvement claim.',threshold_rule='s_j=1/2+(j+1/2)/(2J), j=0,...,J-1; E1-fixed Ds_i=sum_S s*wS(E1,s)/mS; Dtilde=(4/3)*mean_j Ds_j.',diagonal_conventions='Normalized mean single-threshold energy=(16/9J)*sum_j sum_i mi Ds_j_i^2; actual diagonal term in Atilde double sum is 1/J times that mean. All j!=k cross terms retained and reconstructed exactly.',capture_label_justification='Largest mass witness on each joint-grid open cell gives outer radius sqrt(mS/s), complete capture label, and unique maximum by the positive-mass union-of-witnesses argument. Joint grid contains all E1-box and Es-box endpoints; only cells covered by an E1 box contribute.',algebraic_comparisons=COMPARISONS,elapsed_seconds=time.monotonic()-START,results=results)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
