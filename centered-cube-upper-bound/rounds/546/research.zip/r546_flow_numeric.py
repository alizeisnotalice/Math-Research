import sys,time,platform,json,functools
from pathlib import Path
import sympy as sp,flint
from flint import arb,ctx
ctx.prec=256;START=time.monotonic();COMPARISONS=0;DEADLINE=START+35
# Exact receiving-grid routines copied from R545, no top-level experiments imported.
def ev(e):
    e = sp.sympify(e)
    if e.is_Rational:
        return arb(int(e.p)) / int(e.q)
    if e.is_Add:
        return sum((ev(t) for t in e.args), arb(0))
    if e.is_Mul:
        a = arb(1)
        for t in e.args:
            a *= ev(t)
        return a
    if e.is_Pow:
        a, p = e.args
        if p.is_Rational:
            return ev(a).root(int(p.q)) ** int(p.p)
    raise ValueError(str(e))

def cmp(a, b):
    global COMPARISONS
    COMPARISONS += 1
    if time.monotonic()>DEADLINE: raise TimeoutError("35 second finite exact-work budget")
    v = ev(a) - ev(b)
    if v > 0:
        return 1
    if v < 0:
        return -1
    if sp.simplify(a - b) == 0:
        return 0
    raise ArithmeticError(str(a - b))

def unique(v):
    a = sorted(v, key=functools.cmp_to_key(cmp))
    out = []
    for x in a:
        if not out or cmp(x, out[-1]) != 0:
            out.append(x)
    return out

def cert(v):
    v = sp.expand(v)
    return dict(exact=str(v), arb256=str(ev(v)), float=float(v))

def solve(name, x, w):
    x = [[sp.sympify(v) for v in p] for p in x]
    w = list(map(sp.Rational, w))
    N = len(w)
    rect = []
    mass = {}
    for S in range(1, 1 << N):
        ids = [i for i in range(N) if S >> i & 1]
        ms = sum((w[i] for i in ids))
        mass[S] = ms
        half = sp.sqrt(ms) / 2
        low = [max((x[i][j] for i in ids), key=functools.cmp_to_key(cmp)) - half for j in range(2)]
        high = [min((x[i][j] for i in ids), key=functools.cmp_to_key(cmp)) + half for j in range(2)]
        if all((cmp(high[j], low[j]) > 0 for j in range(2))):
            rect.append((S, low, high))
    edges = [unique([r[k][j] for r in rect for k in (1, 2)]) for j in range(2)]

    def rank(v, j):
        return next((i for i, e in enumerate(edges[j]) if cmp(e, v) == 0))
    ranks = [(S, [rank(low[j], j) for j in range(2)], [rank(high[j], j) for j in range(2)]) for S, low, high in rect]
    weights = {}
    cells = []
    capture_exclusion_checks = 0
    equal_root_ties = 0
    for ix in range(len(edges[0]) - 1):
        for iy in range(len(edges[1]) - 1):
            covering = [S for S, lo, hi in ranks if lo[0] <= ix < hi[0] and lo[1] <= iy < hi[1]]
            if not covering:
                continue
            mmax = max((mass[S] for S in covering))
            best = [S for S in covering if mass[S] == mmax]
            equal_root_ties += int(len(best) > 1)
            assert len(best) == 1
            S = best[0]
            half = sp.sqrt(mass[S]) / 2
            lo = [edges[0][ix], edges[1][iy]]
            hi = [edges[0][ix + 1], edges[1][iy + 1]]
            outside = []
            for i in range(N):
                if S >> i & 1:
                    assert all((cmp(lo[j], x[i][j] - half) >= 0 and cmp(x[i][j] + half, hi[j]) >= 0 for j in range(2)))
                else:
                    widths = [min([hi[j], x[i][j] + half], key=functools.cmp_to_key(cmp)) - max([lo[j], x[i][j] - half], key=functools.cmp_to_key(cmp)) for j in range(2)]
                    signs = [cmp(v, 0) for v in widths]
                    assert min(signs) <= 0
                    capture_exclusion_checks += 1
                    outside.append(dict(source=i, intersection_width_signs=signs))
            cellarea = (hi[0] - lo[0]) * (hi[1] - lo[1])
            assert cmp(cellarea, 0) > 0
            weights[S] = weights.get(S, 0) + cellarea
            cells.append(dict(x_interval=[str(lo[0]), str(hi[0])], y_interval=[str(lo[1]), str(hi[1])], all_covering_witness_masks=covering, outermost_capture_mask=S, extra_source_exclusion=outside))
    weights = {S: sp.expand(v) for S, v in weights.items()}
    X = sp.expand(sum(weights.values()))
    Di = [sp.expand(sum((v / mass[S] for S, v in weights.items() if S >> i & 1))) for i in range(N)]
    A = sp.expand(sum((w[i] * Di[i] ** 2 for i in range(N))))
    Apair = 0
    for S, ws in weights.items():
        for T, wt in weights.items():
            Apair += ws * wt * sum((w[i] for i in range(N) if S >> i & 1 and T >> i & 1)) / (mass[S] * mass[T])
    assert sp.simplify(A - Apair) == 0
    h = (arb(1) / (4 * arb(2).sqrt())).exp()
    q = (-arb(2).sqrt() / 4).exp()
    pairs = []
    Asep = R = 0
    ratio_checks = []
    for S, ws in sorted(weights.items()):
        for T, wt in sorted(weights.items()):
            if mass[T] <= mass[S]:
                continue
            margin = ev(sp.sqrt(mass[T] / mass[S])) - h
            separated = bool(margin > 0)
            assert separated or margin < 0
            ratio_checks.append(dict(S=S, T=T, ratio_minus_h_arb256=str(margin), separated=separated))
            if not separated:
                continue
            overlap = sum((w[i] for i in range(N) if S >> i & 1 and T >> i & 1))
            aa = 2 * ws * wt * overlap / (mass[S] * mass[T])
            rr = 2 * ws * wt * overlap ** 2 / (mass[S] * mass[T] ** 2)
            Asep += aa
            R += rr
            pairs.append(dict(S=S, T=T, intersection_mass=str(overlap), Asep_term=cert(aa), R_term=cert(rr)))
    Asep = sp.expand(Asep)
    R = sp.expand(R)
    L = sp.expand(Asep - R)
    bound = 2 * q * ev(X)
    gap = bound - ev(R)
    assert gap > 0
    return dict(name=name, N=N, positions=[[str(v) for v in p] for p in x], masses=[str(v) for v in w], positive_receiving_rectangles=len(rect), grid_shape=[len(e) - 1 for e in edges], occupied_open_cells=len(cells), unique_maximum_witness_each_cell=equal_root_ties == 0, extra_source_exclusion_check_count=capture_exclusion_checks, roots=[dict(mask=S, mass=str(mass[S]), radius=str(sp.sqrt(mass[S])), center_area=cert(v)) for S, v in sorted(weights.items())], X=cert(X), D_i=[cert(v) for v in Di], A=cert(A), A_pair_identity_residual=str(sp.simplify(A - Apair)), Asep=cert(Asep), R=cert(R), L=cert(L), separated_pair_count=len(pairs), separated_pairs=pairs, radius_ratio_classification=ratio_checks, R_bound=dict(two_q_X_arb256=str(bound), two_q_X_minus_R_arb256=str(gap), strictly_positive_gap=bool(gap > 0)), exact_grid_cells=cells)

def expanded(v):return sp.expand(v)
def positive(v):return cmp(v,0)>0

def flow(geo):
 N=geo['N'];m=[sp.Rational(v) for v in geo['masses']];weights={r['mask']:sp.sympify(r['center_area']['exact']) for r in geo['roots']};mass={S:sum(m[i] for i in range(N) if S>>i&1) for S in weights};states=[(S,i) for S in sorted(weights,key=lambda S:(mass[S],S)) for i in range(N) if S>>i&1];sigma={a:expanded(m[a[1]]*weights[a[0]]/mass[a[0]]) for a in states};incoming={a:sp.Integer(0) for a in states};outgoing=incoming.copy();edges=[];outidx={a:[] for a in states}
 h=(arb(1)/(4*arb(2).sqrt())).exp()
 for S in weights:
  for T in weights:
   if mass[T]<=mass[S]:continue
   z=ev(sp.sqrt(mass[T]/mass[S]))-h
   if z<0:continue
   assert z>0
   for i in range(N):
    if not (S>>i&1 and T>>i&1):continue
    for j in range(N):
     if not (T>>j&1 and not S>>j&1):continue
     a,b=(S,i),(T,j);v=expanded(2*weights[S]*weights[T]*m[i]*m[j]/(mass[S]*mass[T]**2));assert positive(v)
     e=len(edges);edges.append(dict(source=a,target=b,mass=v));outidx[a].append(e);outgoing[a]+=v;incoming[b]+=v
 incoming={a:expanded(v) for a,v in incoming.items()};outgoing={a:expanded(v) for a,v in outgoing.items()};starts={};sinks={}
 for a in states:
  delta=expanded(outgoing[a]-incoming[a]);sg=cmp(delta,0);starts[a]=delta if sg>0 else sp.Integer(0);sinks[a]=-delta if sg<0 else sp.Integer(0)
 B=expanded(sum(starts.values()));sinktotal=expanded(sum(sinks.values()));L=expanded(sum(e['mass'] for e in edges));X=sp.sympify(geo['X']['exact']);assert expanded(B-sinktotal)==0;assert expanded(sum(sigma.values())-X)==0;assert expanded(L-sp.sympify(geo['L']['exact']))==0
 # Exact augmented DAG path decomposition; no source/carrier label is discarded.
 erem=[e['mass'] for e in edges];srem=starts.copy();trem=sinks.copy();paths=[]
 for start in states:
  while positive(srem[start]):
   node=start;route=[start];eids=[]
   while not positive(trem[node]):
    opts=[k for k in outidx[node] if positive(erem[k])];assert opts
    k=opts[0];eids.append(k);node=edges[k]['target'];route.append(node);assert len(route)<=len(states)
   candidates=[srem[start],trem[node]]+[erem[k] for k in eids];amount=min(candidates,key=functools.cmp_to_key(cmp));assert positive(amount)
   srem[start]=expanded(srem[start]-amount);trem[node]=expanded(trem[node]-amount)
   for k in eids:erem[k]=expanded(erem[k]-amount)
   paths.append(dict(states=route,edge_indices=eids,mass=amount,length=len(eids)))
 assert all(expanded(v)==0 for v in erem+list(srem.values())+list(trem.values()))
 for k,e in enumerate(edges):assert expanded(sum(p['mass'] for p in paths if k in p['edge_indices'])-e['mass'])==0
 for a in states:
  assert expanded(sum(p['mass'] for p in paths if p['states'][0]==a)-starts[a])==0
  assert expanded(sum(p['mass'] for p in paths if p['states'][-1]==a)-sinks[a])==0
 pathmass=expanded(sum(p['mass'] for p in paths));pathcost=expanded(sum(p['mass']*p['length'] for p in paths));assert expanded(pathmass-B)==0 and expanded(pathcost-L)==0
 maxstate=max(states,key=functools.cmp_to_key(lambda a,b:cmp(expanded(starts[a]/sigma[a]),expanded(starts[b]/sigma[b]))))
 maxratio=expanded(starts[maxstate]/sigma[maxstate]);maxdiff=expanded(starts[maxstate]-sigma[maxstate])
 return dict(state_count=len(states),edge_count=len(edges),state_records=[dict(state=list(a),sigma=cert(sigma[a]),outgoing=cert(outgoing[a]),incoming=cert(incoming[a]),positive_imbalance_b=cert(starts[a]),sink=cert(sinks[a])) for a in states],edge_records=[dict(index=k,source=list(e['source']),target=list(e['target']),mass=cert(e['mass'])) for k,e in enumerate(edges)],B=cert(B),sink_total=cert(sinktotal),total_edge_Lsep=cert(L),B_over_X=cert(expanded(B/X)),L_over_B=cert(expanded(L/B)) if positive(B) else None,max_state_b_over_sigma=cert(maxratio),max_b_over_sigma_state=list(maxstate),same_state_b_minus_sigma=cert(maxdiff),same_state_b_exceeds_sigma=cmp(maxdiff,0)>0,path_count=len(paths),max_path_length=max((p['length'] for p in paths),default=0),paths=[dict(states=[list(a) for a in p['states']],edge_indices=p['edge_indices'],mass=cert(p['mass']),length=p['length']) for p in paths],exact_verification=dict(sum_sigma_equals_X=True,sum_sources_equals_sum_sinks=True,edge_total_equals_R545_L=True,every_edge_reconstructed=True,all_start_and_end_marginals_reconstructed=True,path_total_mass_equals_B=True,path_mass_times_length_equals_total_edge=True),path_total_mass=cert(pathmass),path_mass_times_length=cert(pathcost))

b=(1+sp.sqrt(sp.Rational(1,2)))/2
cases=[('R540_two_source_contact',[[0,0],[b,0]],[sp.Rational(1,2)]*2),('asymmetric_three_source',[[0,0],[sp.Rational(2,5),sp.Rational(1,50)],[sp.Rational(9,20),sp.Rational(7,100)]],[sp.Rational(2,5),sp.Rational(3,10),sp.Rational(3,10)]),('four_source_multiscale',[[0,0],[sp.Rational(13,20),sp.Rational(1,20)],[sp.Rational(3,4),sp.Rational(2,5)],[-sp.Rational(1,5),sp.Rational(1,2)]],[sp.Rational(1,2),sp.Rational(1,4),sp.Rational(1,8),sp.Rational(1,8)]),('six_source_multiscale',[[0,0],[sp.Rational(3,5),0],[sp.Rational(4,5),sp.Rational(1,10)],[sp.Rational(1,10),sp.Rational(3,5)],[sp.Rational(13,20),sp.Rational(2,5)],[sp.Rational(9,10),sp.Rational(3,5)]],[sp.Rational(1,2),sp.Rational(1,4),sp.Rational(1,8),sp.Rational(1,16),sp.Rational(1,32),sp.Rational(1,32)])]
results=[];stop_note=None
for name,x,m in cases:
 if len(m)==6 and time.monotonic()-START>12:
  stop_note='Six-source extension skipped after prior exact work exceeded 12 seconds; no partial configuration result used.';break
 st=time.monotonic()
 try:
  geo=solve(name,x,m);fl=flow(geo)
 except TimeoutError as e:
  stop_note='Stopped finite extension: '+str(e)+'. No partial configuration result used.';break
 row=dict(name=name,N=len(m),positions=geo['positions'],masses=geo['masses'],continuous_grid=dict(grid_shape=geo['grid_shape'],occupied_open_cells=geo['occupied_open_cells'],extra_source_exclusion_checks=geo['extra_source_exclusion_check_count'],root_center_areas=geo['roots'],X=geo['X'],capture_label_unique=geo['unique_maximum_witness_each_cell']),flow=fl,elapsed_seconds=time.monotonic()-st);results.append(row)
 print(name,'N',len(m),'cells',geo['occupied_open_cells'],'states',fl['state_count'],'edges',fl['edge_count'],'paths',fl['path_count'],'B/X',fl['B_over_X']['float'],'L/B',None if fl['L_over_B'] is None else fl['L_over_B']['float'],flush=True)
out=dict(command=sys.executable+' '+str(Path(__file__).resolve()),versions=dict(python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__),precision_bits=256,seed=None,scope='Full source-and-carrier DAG on exact continuous Lebesgue receiving-center areas, U exclusion set empty, all scale-separated positive envelope edges; no low-overlap filter and no label-only aggregation. Four explicitly bounded inputs maximum, no scan/optimization.',definition='state(S,i), sigma=mi*wS/mS. Edge(S,i)->(T,j) iff i in S intersect T, j in T minus S, rT>exp(1/(4sqrt2))*rS; mass 2*wS*wT*mi*mj/(mS*mT^2). b=(out-in)+; sink=(in-out)+.',elapsed_seconds=time.monotonic()-START,algebraic_comparisons=COMPARISONS,stop_note=stop_note,results=results)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
