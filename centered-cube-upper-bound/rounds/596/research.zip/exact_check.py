#!/usr/bin/env python3
"""Four frozen atomic microhalo tilings, exact all-scale 1D receiver unions."""
import argparse,hashlib,json,platform,resource,shlex,signal,sys,time
from fractions import Fraction as F
from pathlib import Path

NS=[1,4,16,64]

def canonical_union(intervals):
 vals=sorted((a,b) for a,b in intervals if a<b)
 merged=[]
 for a,b in vals:
  if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(merged[-1][1],b))
  else:merged.append((a,b))
 return merged

def length(intervals):return sum((b-a for a,b in intervals),F(0))
def output(intervals):return [[str(a),str(b)] for a,b in intervals]

def subtract(A,B):
 B=canonical_union(B);result=[]
 for a,b in canonical_union(A):
  cursor=a
  for c,d in B:
   if d<=cursor:continue
   if c>=b:break
   if c>cursor:result.append((cursor,min(c,b)))
   cursor=max(cursor,d)
   if cursor>=b:break
  if cursor<b:result.append((cursor,b))
 return result

def receiver(sources):
 sources=sorted(sources,key=lambda x:(x[0],x[2]));prefix=[F(0)]
 for x,m,label in sources:assert m>0;prefix.append(prefix[-1]+m)
 intervals=[];positive=zero=negative=0;digest=hashlib.sha256()
 for i in range(len(sources)):
  for j in range(i,len(sources)):
   M=prefix[j+1]-prefix[i];a=sources[j][0]-M/2;b=sources[i][0]+M/2
   digest.update((str(i)+','+str(j)+','+str(a)+','+str(b)+'\n').encode())
   if a<b:positive+=1;intervals.append((a,b))
   elif a==b:zero+=1
   else:negative+=1
 return canonical_union(intervals),{'labels':len(sources),'all_contiguous_index_subsets':len(sources)*(len(sources)+1)//2,'positive_width_carriers':positive,'zero_width_carriers':zero,'negative_width_carriers':negative,'all_contiguous_carriers_sha256':digest.hexdigest()}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r596_results.json'));args=ap.parse_args();start=time.perf_counter()
 def timeout(*_):raise TimeoutError('120s guard, no family truncation')
 signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
 original=[(F(0),F(1),'macro0'),(F(3,2),F(1),'macro1')];E0,basecount=receiver(original);assert E0==[(F(-1,2),F(2))]
 O=[(F(9,4),F(11,4))];Olength=length(O);density=F(4,5);cases=[]
 for N in NS:
  h=F(1,5*N);micro=[];tile_records=[]
  for k in range(N):
   left=F(9,4)+F(k,2*N);right=F(9,4)+F(k+1,2*N);p=left+h/2
   tile_sources=[(p,h,'micro'+str(2*k)),(p+F(3,2)*h,h,'micro'+str(2*k+1))]
   halo,count=receiver(tile_sources);assert halo==[(left,right)] and length(halo)==F(1,2*N)
   tile_records.append({'tile':k,'left':str(left),'right':str(right),'h':str(h),'p':str(p),'two_actual_sources':[[str(x),str(m),label] for x,m,label in tile_sources],'actual_two_source_receiver':output(halo),'checked_all_three_source_subsets':count['all_contiguous_index_subsets']==3})
   micro+=tile_sources
  microMass=sum(m for x,m,label in micro);assert microMass==F(2,5) and microMass==density*Olength
  microhalo,microcount=receiver(micro);assert microhalo==O
  sources=original+micro;E,count=receiver(sources);mass=sum(m for x,m,label in sources);assert mass==F(12,5)
  assert subtract(E0,E)==[] and subtract(O,E)==[]
  macroextra=subtract(E,E0+O);microoutside=subtract(microhalo,O)
  total=length(E);extra=length(macroextra)
  assert total==length(E0)+Olength+extra
  # No expected full-union formula is used by receiver(); output observed values.
  cases.append({'N':N,'h':str(h),'all_actual_sources':[[str(x),str(m),label] for x,m,label in sorted(sources)],'tiles':tile_records,
   'micro_mass_exact':str(microMass),'micro_mass_per_O_length_exact':str(microMass/Olength),'total_mass_exact':str(mass),
   'actual_full_micro_receiver_union':output(microhalo),'micro_receiver_outside_O':output(microoutside),'micro_receiver_enumeration':microcount,
   'actual_full_receiver_union':output(E),'original_receiver':output(E0),'O':output(O),'macroextra_outside_original_E_and_O':output(macroextra),
   'macroextra_volume_exact':str(extra),'total_receiver_volume_exact':str(total),'total_receiver_to_mass_ratio_exact':str(total/mass),'total_mass_to_receiver_ratio_exact':str(mass/total),
   'full_receiver_enumeration':count,'microhalo_preserved_exactly':subtract(O,E)==[],'volume_accounting_residual_exact':'0'})
  if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>128*1024**2:raise MemoryError('128MiB guard')
 # Optional exact continuum gap witness; not a substitute for atomic halos.
 x0=F(2);join=F(17,8);end=F(11,5)
 # For r=2(x-3/2), captured continuous mass minus r is affine:
 # first regime 1-2x/5, second regime 22/5-2x.
 assert F(1)-F(2,5)*x0>0 and F(1)-F(2,5)*join>0
 assert F(22,5)-2*join==F(1)-F(2,5)*join and F(22,5)-2*end==0
 signal.alarm(0)
 result={'scope':'Four frozen finite atomic n1 inputs. Actual complete receiver unions, no weak halo substitution or dimensional inference.',
 'input':{'n':1,'lambda':1,'original_sources':[['0','1'],['3/2','1']],'original_W':'2','original_V':'5/2','q':'5/4','O':['9/4','11/4'],'O_length':'1/2','target_O_density':'4/5','N':NS,'cube_convention':'r=mS is SIDE length; interval halfwidth mS/2'},
 'contiguous_subset_dominance_proof':'Sort all original positive labels by position (retain coincident labels in any fixed order). For any nonempty subset S let i,j be its least/greatest sorted indices. Its consecutive envelope T={i,...,j} has the same coordinate minimum and maximum and mT>=mS. Thus C_S=[zj-mS/2,zi+mS/2] is contained in C_T=[zj-mT/2,zi+mT/2]. Every consecutive T is itself an actual subset, so union over all consecutive index subsets equals the ALL-subset receiver exactly up to null interval endpoints. Empty/negative-width carriers are kept in counts and contribute zero.',
 'cases':cases,
 'continuum_gap_certificate':{'measure':'delta0+delta_(3/2)+(4/5)1_O dx','witness_side':'r=2(x-3/2), including macro atom at3/2','first_range':['2','17/8'],'captured_mass':'8x/5-2','mass_minus_side':'1-2x/5 >0','second_range':['17/8','11/5'],'captured_mass':'7/5','mass_minus_side':'22/5-2x >0 before11/5','conclusion':'Every x in (2,11/5) is received; this is a genuine positive subinterval of gap (2,9/4), not the entire gap.',
  'remaining_gap':'For x in (11/5,9/4), any actual witness including atom3/2 requires side>7/5 but cannot capture more than7/5 unless it includes atom0. Including atom0 needs side>=2x>total mass12/5, impossible. A source-only continuous-density witness has density<=4/5<1. Therefore this remaining gap is not received.',
  'boundary':'Null endpoints not used to infer strict maximal levels. The continuous source model does not retain the fine atomic microhalos; only its macro gap witness is asserted.'},
 'interval_output_convention':'Receiver intervals and set differences are recorded modulo endpoint-null boundaries; all reported Lebesgue volumes are exact.','arithmetic_error':'0: all atomic inputs, prefix masses, carrier endpoints, union differences and volumes are Fraction rational exact; no floating comparison.',
 'execution':{'interpreter':sys.executable,'python':platform.python_version(),'processes':1,'guard_seconds':120,'guard_bytes':128*1024**2,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]])},'all_assertions_passed':True}
 args.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'cases':[{'N':c['N'],'full_union':c['actual_full_receiver_union'],'micro_union':c['actual_full_micro_receiver_union'],'macroextra':c['macroextra_outside_original_E_and_O'],'V':c['total_receiver_volume_exact'],'mass_ratio':c['total_receiver_to_mass_ratio_exact'],'contiguous_carriers':c['full_receiver_enumeration']['all_contiguous_index_subsets']} for c in cases],'execution':result['execution']}))
if __name__=='__main__':main()
