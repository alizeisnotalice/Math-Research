#!/usr/bin/env python3
"""Independent ALL-subset and endpoint-cell replay for frozen N=1,4 only."""
import argparse,hashlib,json,platform,resource,shlex,sys,time
from fractions import Fraction as F
from pathlib import Path

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,default=Path(__file__).with_name('ccu_r596_results.json'));ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r596_independent_results.json'));args=ap.parse_args();start=time.perf_counter()
 raw=args.input.read_bytes();reference=json.loads(raw)
 assert reference['input']['N']==[1,4,16,64]
 assert reference['execution']['script_sha256']=='761fdc14a7de86498b8631115d8b7829ba9eaccb596181134d9e1d241f3418a0'
 checks=[]
 for N in (1,4):
  ref=next(c for c in reference['cases'] if c['N']==N)
  sources=[(F(x),F(m),label) for x,m,label in ref['all_actual_sources']];d=len(sources);assert d==2+2*N and d in (4,10)
  assert all(m>0 for x,m,label in sources) and sum(m for x,m,label in sources)==F(12,5)
  carriers=[];endpoints=set();positive=[];counts={'positive':0,'zero':0,'negative':0}
  # Direct arbitrary subsets: no consecutive-envelope logic, source sorting,
  # prefix masses or producer receiver() function is used.
  for mask in range(1,1<<d):
   chosen=[sources[i] for i in range(d) if mask>>i&1];mass=sum(m for x,m,label in chosen);lo=max(x for x,m,label in chosen)-mass/2;hi=min(x for x,m,label in chosen)+mass/2
   endpoints.update((lo,hi));status='positive' if lo<hi else 'zero' if lo==hi else 'negative';counts[status]+=1
   if lo<hi:positive.append((lo,hi))
   carriers.append({'mask':mask,'mass':str(mass),'lower':str(lo),'upper':str(hi),'width_status':status})
  original=[tuple(map(F,p)) for p in ref['original_receiver']];O=[tuple(map(F,p)) for p in ref['O']]
  assert original==[(F(-1,2),F(2))] and O==[(F(9,4),F(11,4))]
  for lo,hi in original+O:endpoints.update((lo,hi))
  ends=sorted(endpoints);Esegments=[];extra_segments=[];measure=F(0);extrameasure=F(0);cells=[]
  for lo,hi in zip(ends,ends[1:]):
   assert lo<hi
   multiplicity=sum(a<=lo and hi<=b for a,b in positive)
   old=any(a<=lo and hi<=b for a,b in original);inO=any(a<=lo and hi<=b for a,b in O)
   received=multiplicity>0;extra=received and not old and not inO
   if received:measure+=hi-lo;Esegments.append((lo,hi))
   if extra:extrameasure+=hi-lo;extra_segments.append((lo,hi))
   cells.append({'left':str(lo),'right':str(hi),'actual_carrier_multiplicity':multiplicity,'in_original_E':old,'in_O':inO,'macroextra':extra})
  # This only reassembles adjacent already-classified endpoint cells; it never
  # merges carrier intervals to determine receipt.
  def assemble(segments):
   result=[]
   for lo,hi in segments:
    if result and result[-1][1]==lo:result[-1]=(result[-1][0],hi)
    else:result.append((lo,hi))
   return result
  E=assemble(Esegments);extra=assemble(extra_segments)
  assert E==[tuple(map(F,p)) for p in ref['actual_full_receiver_union']]
  assert extra==[tuple(map(F,p)) for p in ref['macroextra_outside_original_E_and_O']]
  assert measure==F(ref['total_receiver_volume_exact']) and extrameasure==F(ref['macroextra_volume_exact'])
  checks.append({'N':N,'actual_labels':d,'all_nonempty_subsets':(1<<d)-1,'carrier_counts':counts,'all_carriers':carriers,'distinct_endpoints':len(ends),'endpoint_cells':cells,
   'actual_full_union':[[str(a),str(b)] for a,b in E],'macroextra':[[str(a),str(b)] for a,b in extra],'total_volume_exact':str(measure),'macroextra_volume_exact':str(extrameasure),'matches_reference_intervals_and_volumes_exactly':True})
 result={'scope':'Independent finite ALL-subset endpoint-partition audit for N1 and N4 only; does not independently certify N16/N64, the contiguous-envelope theorem, or any dimensional asymptotic.',
 'input_provenance':{'path':str(args.input),'actual_raw_sha256':hashlib.sha256(raw).hexdigest(),'producer_script_sha256':reference['execution']['script_sha256'],'usage':'Input source coordinates/masses and final answer comparison only. Original script not imported, executed or read; receiver() not called.'},
 'algorithm':'Enumerate every arbitrary nonempty label subset. Build all actual carrier endpoints, including empty/zero-width cases. Split at every endpoint and original/O boundary; classify each whole interval cell by exact endpoint containment in a positive carrier. Sum cell lengths; separately exclude original E and O to determine macroextra.',
 'cases':checks,'total_arbitrary_subsets_evaluated':sum(c['all_nonempty_subsets'] for c in checks),'all_exact_checks_passed':True,'arithmetic_error':'0, Fraction exact; no floating arithmetic or midpoint test; interval output modulo endpoint-null boundaries',
 'execution':{'interpreter':sys.executable,'python':platform.python_version(),'processes':1,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]])}}
 args.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'cases':[(c['N'],c['all_nonempty_subsets'],c['distinct_endpoints'],c['actual_full_union'],c['macroextra'],c['total_volume_exact']) for c in checks],'all_exact_matches':True,'execution':result['execution']}))
if __name__=='__main__':main()
