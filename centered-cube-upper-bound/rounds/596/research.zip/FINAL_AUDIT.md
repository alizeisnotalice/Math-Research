# R596 最终独立审核

**结论：PASS，无必须修复项，可按本报告声明范围归档。有限填充、完整外部 defect 不等式与穿孔壳层上界成立；一般根阶下界/弱型改善仍未证明。**

最终报告：`/tmp/ccu_r596_REPORT.tex`。

SHA256：`fd312853460cf957fda12a43963e35a64aa11d4e7a454d33e1edd8068eed2b8f`。

本审核先独立检查候选量词和预算，再审 packing 作者稿，继而先核壳层命题再读报告证明。已完成检查记录在 `/tmp/ccu_r596_pre_audit.md`、`/tmp/ccu_r596_packing_audit.md`；此最终文件合并其必要结论并绑定最终报告，不重新认证历史全部结论。

## 1. 有限填充与完整 defect 总账

原 E 取全部正体积实际 carrier 的有限闭并，删退化 carrier 仅为体积意义；每个来源仍位于自己的正体积 singleton carrier 内。副本来源不删，真实完整 halo 与 hE+p 仅模零测相等。报告没有把退化伸出部分的点态包含或相交误当成正体积费用。

有限网格填充证明成立：用固定包围盒获得正填充比例 gamma；每轮在开放剩余中取有限 dyadic cells，填去至少 gamma/2 的比例，继续有限轮使未填体积小于 1/j，并同时把副本直径限制到 1/j。副本在 cell 内严格紧含，同轮及跨轮不交，剩余仍开。O 无须边界零测。gamma 很小只增加有限标签数，不变成未计的来源质量；上价必须用全来源数统一的 C_n。

每列实际微源质量精确为 kappa|U_j|，只趋近 kappa|O|，没有强设每步质量恰等。来源与等质量 halo 密度支撑于同一小集合，测试函数连续模给弱收敛。来源弱收敛与 halo 覆盖各有独立证明，没有声称极限输入仍接收整个 O。

固定 cube 上，极限微源绝对连续，故微源质量收敛；原 nu 在边界上的原子质量原样不变。每个宏观严格见证在同一列中最终保留，不需要所有 cubes 一致收敛，也不按 receiver 重建近似。使用 strict >lambda 必不可少；不能把弥散输入可能存在的等号平台纳入。

有限层面同时保留 E、U_j 与完整宏观 extra，实际费用为

`lambda(v+|U_j|+|H_(nu+sigma_j) intersect G|)<=C_n(W+kappa|U_j|)`。

同列严格恢复和 Fatou 后，得到报告 defect 式

`lambda|G|<=(C_n-q)W(1+|O|/v)`。

所有质量项、O 的体积商和原子数增长均已保留。扣除 O 来自预极限的实际微 halo，不来自对极限 halo 的不合法推断。O 边界上的 extra 也没有被删。

## 2. 完整穿孔壳层：独立核验

本节 q>=1、q>=C_n/2 是明确假设，不是对所有输入偷用的结论。theta=1/4、c=2^(-n-2)。Atomic 上价给 `|L|/v<=C_n/(cq)<=2^(n+3)`，L 是有界开集，因为严格 maximal 集开、E 闭。

任一 A_theta 见证的原输入平均严格超过 `1-theta/q>=3/4`。对整个 Q(x,r) 中每个 y，Q(y,2r) 确实包含 Q(x,r)，故其原输入平均严格超过 `3lambda/(4*2^n)=3c lambda`。所以是**整个** Q(x,r)\E 包含于同一个 L，而非只把中心放入 L；这是替换无限 exterior 背景为有限 shell 的关键。

因此 A_theta 可精确识别为

`H_(nu+kappa theta 1_L dx)\E`。

正向由 whole-Q 包含，反向由 L subset E^c；由此得到可测性、开放性与有界性，不需另用未经证明的选择定理。

共同周期条带 P_m 与 O_m=L intersect P_m 均不依赖父或尺度。周期平均对任意 L1 测试收敛，乘 1_L 后得到 `1_Om weak-star -> theta 1_L`；特别适用于固定 cube、1_L 与 1_A_theta。所有严格见证都在同一 m 序列上最终接收，原 nu 边界原子仍固定。A_theta 有界，故其未接收部分体积趋零；又 `|A_theta intersect O_m|->theta|A_theta|`，留下 `(1-theta)|A_theta|` 的完整 extra 下界。

对每个 O_m 分别应用已证 defect 定理，再令 m 趋无穷，确得

`(1-theta)lambda|A_theta| <= (C_n-q)W(1+theta|L|/v)`

`<= (C_n-q)W(1+theta 2^(n+3))`。

这里没有以弱收敛替代微 halo 覆盖，也不要求一个 receiver 私有的孔洞或微源列。对每个 m 的 finite filling 内部极限已由 defect 定理完整支付，周期极限再用于同一个宏观 shell。

## 3. nearmax 极限、条件反馈与未证范围

报告明确展示指数因子，未称其为根阶费用。若未来对同一个完整 A_theta 证明输入/source-count 一致的

`lambda|A_theta|>=eta_n qW-L_nW`，

则有限 nearmax 比较实际为

`(1-theta)(eta_n q-L_n)<=(C_n-q)(1+theta 2^(n+3))`。

先固定 n，再取 q 趋 C_n；右端才因有限的 n-常数乘趋零 deficit 而消失。非平凡的 C_n>1 情形下该序列最终满足 q>=1 和 q>=C_n/2；C_n<=1 时一般目标本已平凡。eta_n、L_n 须对 nearmax 序列的来源数、位置和阈值一致，最终仍保留 L_n/eta_n。此过程没有获得 uniform-n 的 deficit 收敛率，也没有在 finite deficit 时抹去指数因子。

缺少的正是该完整下界。报告关于坐标退出的失败说明保留了实际暴露见证半径、hole 体积、gap 截断和方向重叠，未把原父半径、密度假设或逐父费用当作已证替代。Packing、周期穿孔及 R595 的输入依赖正面片都没有提供所需的全族数量收入。一般 L1 恢复仍以未来取得全有限源统一上界为前提，本轮没有该上界。

## 4. 有限代码与证据范围

已审主脚本 `/tmp/ccu_r596_exact_check.py`，SHA256 `761fdc14a7de86498b8631115d8b7829ba9eaccb596181134d9e1d241f3418a0`。一维排序连续 index envelope 的 ALL-subset 支配证明正确；固定同位置 tie 不影响同极值、增质量的 carrier 包含。它不是高维 reduction，也不是采样下界。

读取主结果 `/tmp/ccu_r596_results.json`，SHA256 `acb9f114a7ce43a196e3c582462110d358549b1ce00aae941915905ef7cacf6d`。四组 N=1,4,16,64 的实际连续 index 父数为 10、55、595、8515；完整并均为 `[-1/2,11/5] union [9/4,11/4]`，体积 16/5、总质量 12/5、比值 4/3、extra 体积 1/5，均与报告一致。模型的 tile halo 端点相触只按零测边界处理，不冒称一般 open-interior packing 的逐点实现。

另核 `/tmp/ccu_r596_independent_check.py`，SHA256 `72b46a5a2d993a596915c2f6b7df4e9b9da6469357e33e3d652e5bd11ef0ee02`。它从冻结结果中读取实际来源坐标/质量，另枚举 N=1、4 的全部 15、1023 个非空标签子集，计算实际质量和极值端点，并在所有端点 cell 上按完整包含判定接收、求和；不调用 producer receiver、不用连续 index reduction 或原 carrier 并算法。原 E/O 边界也加入分割，故 extra 的判定完整。输入和最终答案比较仍共享冻结参考，独立性是几何计算算法的独立，非来源生成的独立。

独立结果 `/tmp/ccu_r596_independent_results.json` SHA256 `8703ad4d1747217b2d304c7a39b4e8b3e0285c3086efe5ba77ed721df3248d0f` 的两例均有相同完整并、体积和 extra。它不独立认证 N=16/64、整个连续 index 定理或高维结论；报告准确限定于两例。

本次实际用本机 Python 分别比对主结果与 `ccu_r596_root_replay.json`、独立结果与 `ccu_r596_independent_root_replay.json`，去除各自 execution 后全部字段相等。报告准确区分主脚本同码复跑和另一个全部子集端点算法。审核者没有重新执行这两个计算脚本；实际执行的是哈希/JSON 字段核对及小型符号验证。

连续模型的 gap witness 与剩余 gap 排除也已核验：固定宏观原子在见证 cube 面上的质量被保留，两个严格 margin 分别为 `1-2x/5`、`22/5-2x`，只得 (2,11/5) 的接收，不声称极限保留 micro-halo。所有计算均限所列固定 n=1 模型，不证明 all-N、完整壳层下界或一般维数阶。

## 5. 实际工具与停止

除全文审读与哈希核对外，本次实际调用本机 Python/SymPy 核验 continuum 第一段捕获代数、shell 阈值比为 3，以及有限 nearmax 反馈系数恒等式，残差为零。此前独立预审也实际核验 defect 总账因式。严格结论依据正文的有限构造、真实测度和 Fatou，而非这些符号输出或低维实验外推。

没有重新进行几何扫描、昂贵枚举、优化、repo/git 操作、spawn 或 PDF 编译；未审的历史新颖性或外部 skill 理论不被本文件默认为已核。最终报告 fd312... 版本可按上述严格成果与明确缺口归档。完成最终绑定后停止。
