#!/usr/bin/env python3
"""R600 complete 4-source pair geometry, exact rational power guards + Arb512 roots."""
import argparse,functools,hashlib,itertools,json,platform,resource,shlex,sys,time
from fractions import Fraction as F
from pathlib import Path
import flint
from flint import arb,ctx

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args();start=time.perf_counter();ctx.prec=512
 def ab(f):return arb(f.numerator)/f.denominator
 results=[]
 for n in (2,4,8,16,64):
  for c in (F(1,4),F(1,64)):
   for ratio in (F(1,2),F(63,64)):
    g=c/n;delta=g*ratio;A=(1+g)**n;B=(1-delta)**n;lower=1-B;upper=min(F(1),A-1);eps=(lower+upper)/2
    assert 0<g<1-delta and 0<eps<1 and lower<eps<A-1 and A+B>2
    a=(1+g)/2;b=(1-delta)/2;z=[(-a,F(0)),(a,F(0)),(F(0),-b),(F(0),b)];ms=[eps,eps,(1-eps)/2,(1-eps)/2]
    @functools.lru_cache(None)
    def root(m):return ab(m).root(n)
    # Endpoint is offset + coefficient*mass^(1/n), canonical mass=1 simplified.
    def ep(offset,coeff,m):return (offset+coeff,F(0),F(1)) if m==1 else (offset,coeff,m)
    def ev(p):return ab(p[0])+ab(p[1])*root(p[2])
    def cmp(p,q):
     if p==q:return 0
     d=ev(p)-ev(q)
     if d>0:return 1
     if d<0:return -1
     raise ArithmeticError('Unresolved endpoint order; no float fallback')
    def eo(p):return {'offset':str(p[0]),'coefficient':str(p[1]),'root_mass':str(p[2]),'root_degree':n,'Arb512':ev(p).str(50)}
    boxes=[];line=[]
    for mask in range(1,16):
     ids=[i for i in range(4) if mask>>i&1];m=sum((ms[i] for i in ids),F(0));bbox=[(min(z[i][j] for i in ids),max(z[i][j] for i in ids)) for j in range(2)];widths=[hi-lo for lo,hi in bbox]
     signs=[(m>w**n)-(m<w**n) for w in widths];positive=min(signs)>0
     on_axis=positive and m>=(2*max(abs(bbox[1][0]),abs(bbox[1][1])))**n
     rec={'mask':mask,'mass':str(m),'bbox_first_two':[[str(lo),str(hi)] for lo,hi in bbox],'extra_coordinate_source_spans':'0, repeated n-2 times','width_signs_first_two':signs,'positive_full_carrier':positive,'axis_intersection_positive':on_axis}
     if on_axis:
      interval=(ep(bbox[0][1],F(-1,2),m),ep(bbox[0][0],F(1,2),m));assert cmp(interval[0],interval[1])<0
      line.append(interval);rec['axis_interval']=[eo(v) for v in interval]
      # Complete interval must avoid the open target gap; no midpoint substitution.
      assert cmp(interval[1],ep(-g/2,F(0),F(1)))<=0 or cmp(interval[0],ep(g/2,F(0),F(1)))>=0
     boxes.append(rec)
    line.sort(key=functools.cmp_to_key(lambda p,q:cmp(p[0],q[0])));union=[]
    for lo,hi in line:
     if union and cmp(lo,union[-1][1])<=0:
      if cmp(hi,union[-1][1])>0:union[-1][1]=hi
     else:union.append([lo,hi])
    assert len(union)==2
    assert union[0][1]==ep(-g/2,F(0),F(1)) and union[1][0]==ep(g/2,F(0),F(1))
    # All source entry events for every x in the whole open gap.
    # shared first r=1-delta; nearer outer r=1+g-2|x| in (1,1+g);
    # farther outer r=1+g+2|x| in (1+g,1+2g); at x=0 outers enter together.
    assert (1-eps)<B and (1+eps)<A
    for x in (-g/2,F(0),g/2):
     events=sorted(set(2*max(abs(x-p[0]),abs(p[1])) for p in z))
     for r in events:
      captured=sum((m for p,m in zip(z,ms) if 2*max(abs(x-p[0]),abs(p[1]))<=r),F(0));assert captured<=r**n
      if x==0:assert captured<r**n
    # Exactly the left/right mass1 triples realize endpoint regular faces.
    L=boxes[12] # mask13 = left outer+shareds
    R=boxes[13] # mask14 = right outer+shareds
    assert L['mass']==R['mass']=='1' and L['positive_full_carrier'] and R['positive_full_carrier']
    assert root(eps)<1 and root((1+eps)/2)<1
    assert root(1-eps)<ab(1-delta) and root(1+eps)<ab(1+g)
    assert ab(2*eps)<ab(A)
    results.append({'stage':'initial' if n in (2,4) else ('tie_guards' if n in (8,16) else 'expanded'),'n':n,'c':str(c),'g':str(g),'delta':str(delta),'delta_over_g':str(ratio),'epsilon':str(eps),'epsilon_bounds_exact':[str(lower),str(upper)],'epsilon_bound_width':str(upper-lower),'r_convention':'cube side length','sources_first_two':[[str(v) for v in p] for p in z],'source_masses':list(map(str,ms)),'all15_subsets':boxes,'axis_full_union':[[eo(v) for v in pair] for pair in union],'open_gap_exact':[str(-g/2),str(g/2)],'shared_event_density_Arb512':(ab(1-eps)/ab(B)).str(50),'central_all_event_density_Arb512':(ab(1+eps)/ab(A)).str(50),'endpoint_event_density_exact':'1 (mass1 at side1); strict halo excludes endpoint','regular_parent_masks':[13,14],'regular_parent_transverse_widths':['delta']+['1']*(n-2),'all_checks_passed':True})
 longitudinal=[]
 for n in (2,4,8,16,64):
  g=F(1,20*n);d=F(n-1,4)*g*g;A=(1+g)**n;B=(1-g-d)**n;lower=1-B;upper=min(F(1),A-1);eps=(lower+upper)/2
  assert 0<d and g+d<1 and lower<eps<upper
  assert eps==(A-B)/2
  assert A+(1-g)**n>=2+n*(n-1)*g*g
  assert B>=(1-g)**n-n*d
  assert A+B>=2+F(3,4)*n*(n-1)*g*g
  assert A<=F(20,19)
  assert 2*(1-2*g-d)**n>=2*(1-n*(2*g+d))>1>1-eps
  a=(1+g)/2;b=(1-g-d)/2;z=[-a,a,-b,b];ms=[eps,eps,(1-eps)/2,(1-eps)/2]
  # These are indispensable additional full-family guards, not consequences of shared-pair emptiness alone.
  assert (1-eps)/2 < (1-2*g-d)**n
  assert (1+eps)/2 < (1-d/2)**n
  def root2(m):return ab(m).root(n)
  def ep2(v,c,m):return (v+c,F(0),F(1)) if m==1 else (v,c,m)
  def val2(p):return ab(p[0])+ab(p[1])*root2(p[2])
  def cmp2(p,q):
   if p==q:return 0
   v=val2(p)-val2(q)
   if v>0:return 1
   if v<0:return -1
   raise ArithmeticError('Longitudinal endpoint order unresolved')
  def eo2(p):return {'offset':str(p[0]),'coefficient':str(p[1]),'root_mass':str(p[2]),'root_degree':n,'Arb512':val2(p).str(50)}
  recs=[];ints=[]
  for mask in range(1,16):
   ids=[i for i in range(4) if mask>>i&1];m=sum((ms[i] for i in ids),F(0));lo=min(z[i] for i in ids);hi=max(z[i] for i in ids);width=hi-lo;sg=(m>width**n)-(m<width**n)
   rec={'mask':mask,'mass':str(m),'source_span':str(width),'width_sign':sg,'positive_full_carrier':sg>0}
   if sg>0:
    I=(ep2(hi,F(-1,2),m),ep2(lo,F(1,2),m));ints.append(I);rec['axis_interval']=[eo2(v) for v in I]
    assert cmp2(I[1],ep2(-g/2,F(0),F(1)))<=0 or cmp2(I[0],ep2(g/2,F(0),F(1)))>=0
   recs.append(rec)
  ints.sort(key=functools.cmp_to_key(lambda p,q:cmp2(p[0],q[0])));union=[]
  for lo,hi in ints:
   if union and cmp2(lo,union[-1][1])<=0:
    if cmp2(hi,union[-1][1])>0:union[-1][1]=hi
   else:union.append([lo,hi])
  assert any(I[1]==ep2(-g/2,F(0),F(1)) for I in union) and any(I[0]==ep2(g/2,F(0),F(1)) for I in union)
  # Mass1 triples: endpoints from actual extrema, not a proposed carrier.
  for mask,want in ((13,(-(g+d)/2,-g/2)),(14,(g/2,(g+d)/2))):
   ids=[i for i in range(4) if mask>>i&1];assert sum((ms[i] for i in ids),F(0))==1
   assert (max(z[i] for i in ids)-F(1,2),min(z[i] for i in ids)+F(1,2))==want
  longitudinal.append({'n':n,'g':str(g),'d':str(d),'epsilon':str(eps),'epsilon_bounds':[str(lower),str(upper)],'threshold_width':str(upper-lower),'all15_subsets':recs,'axis_full_union':[[eo2(v) for v in I] for I in union],'actual_parent_axis_width':str(d/2),'actual_parent_other_coordinate_widths':'1 repeated n-1 times','extra_shared_single_guard':True,'extra_opposite_mixed_pair_guard':True,'all_checks_passed':True})
 proof={'epsilon_range':'1-(1-delta)^n < epsilon < min(1,(1+g)^n-1). Nonempty iff (1+g)^n+(1-delta)^n>2; under 0<delta<g this follows from Bernoulli, strictly for n>=2. The supplied weaker g<1-delta alone does not imply nonempty epsilon range; this script chooses delta<g.','full_geometry':'shared pair mass1-eps has negative y2-width; all containing both outers and at least one shared have mass<=1+eps<(1+g)^n, negative x1-width. Outer pair empty as 2eps<(1+g)^n, using eps<min(1,A-1). Singleton shared cannot reach y2=0. Outer singleton and mixed outer/shared pair have side<1; their inner axial endpoints lie strictly beyond the target endpoint. Only mask13/14 reach ±g/2 with sides1.','regular_faces':'C13=[-1/2,-g/2] x [-delta/2,delta/2] x [-1/2,1/2]^(n-2); C14=[g/2,1/2] with same transverse box. Their endpoint interiors are regular local halo boundary faces: every other axis-reaching carrier is strictly axially separated; axis-nonreaching boxes are strictly transversely separated. Finite family therefore admits a local neighborhood where only the indicated parent determines boundary.','all_gap_events':'For every |x|<g/2, shared radius=1-delta captures1-eps with density<1. For x!=0 nearer outer radius=1+g-2|x|>1 captures mass1, density<1; farther outer radius=1+g+2|x|>1+g captures1+eps with density<1. At x=0 both outers enter simultaneously at1+g and density<1. Between entries average decreases. Endpoints nearer outer event has side1,mass1: equality only, not strict reception. This checks entire gap, not just sample points.'}
 d={'scope':'25 frozen cases:20 transverse and5 longitudinal, four sources, all15 actual subset carriers, exact complete axis union. No high-dimensional volume integration or scans.','proof':proof,'results':results,'longitudinal_results':longitudinal,'longitudinal_proof':'Specified g=1/(20n),d=(n-1)g²/4 and midpoint epsilon pass full15-subset enumeration. Additional guards shared-single mass<(1-2g-d)^n and opposite outer/shared pair mass<(1-d/2)^n are checked; shared-pair emptiness alone is insufficient. C13=[-(g+d)/2,-g/2] times [-1/2,1/2]^(n-1), C14 symmetric. Thus the thin coordinate may be longitudinal: no transverse narrowing is forced by a short gap.', 'qualification':'No q>=2, global receiver price or dimensional sharp-growth conclusion. Model demonstrates one transverse width delta while n-2 widths stay1; deletion shared between parents remains epsilon and can be small by choosing small c.','execution':{'interpreter':sys.executable,'python':platform.python_version(),'python_flint':flint.__version__,'precision_bits':512,'processes':1,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,*sys.argv])}}
 args.output.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n');print(json.dumps({'cases':len(results)+len(longitudinal),'all_checks_passed':True,'execution':d['execution']}))
if __name__=='__main__':main()
