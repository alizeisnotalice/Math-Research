import sys,time,platform,json,math,hashlib
from pathlib import Path
import numpy as np
START=time.monotonic();TOL=1e-10
SOURCE_STABLE_SCRIPT_SHA256='d139985d6019d498c48b259720fcdd0530b5a9a297b1fb862b153bd39c380e65'
# Root and finite incidence routines retained from the checked exploration.
def density_input(d):
    centers = np.array([[-d, 0.0], [0.0, 0.0], [d, d / 3]])
    peak_mass = [0.5, 1 / 3, 1 / 6]
    core = [1 / 32, 1 / 16, 1 / 8]
    halo = [1 / 4, 1 / 2, 1.0]
    components = []
    for k in range(3):
        for kind, side in [('core', core[k]), ('halo', halo[k])]:
            components.append(dict(peak=k, kind=kind, center=centers[k].tolist(), side=side, mass=peak_mass[k] / 2, density=peak_mass[k] / 2 / side ** 2))
    return (centers, components)

def mass_cube(B, r, components):
    ans = 0.0
    for c in components:
        center = np.asarray(c['center'])
        half = c['side'] / 2
        length = np.maximum(0, np.minimum(B + r / 2, center + half) - np.maximum(B - r / 2, center - half))
        ans += c['density'] * length[0] * length[1]
    return float(ans)

def quadratic(B, mid, components):
    A = -1.0
    BB = C = 0.0
    for c in components:
        slopes = []
        intercepts = []
        for j in range(2):
            low = c['center'][j] - c['side'] / 2
            high = c['center'][j] + c['side'] / 2
            us, ui = (0.5, B[j]) if B[j] + mid / 2 < high else (0.0, high)
            ls, li = (-0.5, B[j]) if B[j] - mid / 2 > low else (0.0, low)
            aa, bb = (us - ls, ui - li)
            if aa * mid + bb <= 0:
                aa = bb = 0.0
            slopes.append(aa)
            intercepts.append(bb)
        rho = c['density']
        A += rho * slopes[0] * slopes[1]
        BB += rho * (slopes[0] * intercepts[1] + slopes[1] * intercepts[0])
        C += rho * intercepts[0] * intercepts[1]
    return (A, BB, C)

def real_roots(A, B, C):
    scale = max(1.0, abs(A), abs(B), abs(C))
    eps = 2e-13 * scale
    if abs(A) <= eps:
        return [] if abs(B) <= eps else [-C / B]
    disc = B * B - 4 * A * C
    if disc < -2e-13 * max(1.0, B * B, abs(4 * A * C)):
        return []
    disc = max(0.0, disc)
    sq = math.sqrt(disc)
    q = -0.5 * (B + math.copysign(sq, B))
    if q == 0:
        return [-B / (2 * A)]
    return [q / A, C / q]

def outer_root(B, components):
    breaks = [0.0, 1.0]
    for c in components:
        for j in range(2):
            for edge in (c['center'][j] - c['side'] / 2, c['center'][j] + c['side'] / 2):
                r = 2 * abs(B[j] - edge)
                if 0 < r < 1:
                    breaks.append(float(r))
    breaks = sorted(set(breaks))
    roots = []
    max_delta = -1.0
    max_probe = 0.0
    segments = 0
    flat_segments = 0
    zero_coefficient_cleanup = 0.0
    for lo, hi in zip(breaks[:-1], breaks[1:]):
        if hi - lo < 1e-14:
            continue
        segments += 1
        mid = (lo + hi) / 2
        A, b, c = quadratic(B, mid, components)
        if lo == 0:
            zero_coefficient_cleanup = max(zero_coefficient_cleanup, abs(b), abs(c))
            b = c = 0.0
        tests = [hi, mid]
        if lo > 0:
            tests.append(lo)
        if abs(b) > 1e-15:
            stationary = -2 * c / b
            if lo < stationary < hi:
                tests.append(stationary)
        for rr in tests:
            dd = ((A * rr + b) * rr + c) / (rr * rr)
            if dd > max_delta:
                max_delta = dd
                max_probe = rr
        if abs(A) + abs(b) + abs(c) < 1e-13:
            roots.append(hi)
            flat_segments += 1
        for rr in real_roots(A, b, c):
            if rr > 1e-12 and lo - 1e-09 <= rr <= hi + 1e-09:
                rr = min(1.0, max(0.0, rr))
                if abs(mass_cube(B, rr, components) - rr * rr) <= 1e-07:
                    roots.append(rr)
        for rr in (lo, hi):
            if rr > 1e-12 and abs(((A * rr + b) * rr + c) / (rr * rr)) < 1e-09:
                roots.append(rr)
    if max_delta <= TOL:
        return (None, dict(segments=segments, max_average_minus_one=max_delta, near_entry_threshold=abs(max_delta) <= 1e-08, zero_coefficient_cleanup=zero_coefficient_cleanup, flat_segments=flat_segments))
    if not roots:
        raise ArithmeticError('Positive level without outer root at ' + str(B))
    r = max(roots)
    mc = mass_cube(B, r, components)
    res = mc - r * r
    if abs(res) > 1e-07:
        raise ArithmeticError('Root residual too large')
    return (r, dict(segments=segments, max_average_minus_one=max_delta, near_entry_threshold=abs(max_delta) <= 1e-08, zero_coefficient_cleanup=zero_coefficient_cleanup, flat_segments=flat_segments, root_mass=mc, root_equation_absolute_residual=abs(res), root_equation_relative_residual=abs(res) / max(r * r, 1e-15), best_superlevel_probe_radius=max_probe))

def field_values(shape, rects, weights, dtype):
    diff = np.zeros((shape[0] + 1, shape[1] + 1), dtype=dtype)
    if len(rects):
        rects = np.asarray(rects, int)
        w = np.asarray(weights, dtype=dtype)
        lx, ly, hx, hy = rects.T
        np.add.at(diff, (lx, ly), w)
        np.add.at(diff, (hx + 1, ly), -w)
        np.add.at(diff, (lx, hy + 1), -w)
        np.add.at(diff, (hx + 1, hy + 1), w)
    np.cumsum(diff, axis=0, dtype=dtype, out=diff)
    np.cumsum(diff, axis=1, dtype=dtype, out=diff)
    return diff[:-1, :-1]

def mode_point(endpoints, mode):
    return float(endpoints[mode // 2] if mode % 2 == 0 else (endpoints[mode // 2] + endpoints[mode // 2 + 1]) / 2)

def experiment(d, n):
    st = time.monotonic()
    deadline = st + 30
    peaks, components = density_input(d)
    lower = np.min([np.array(c['center']) - c['side'] / 2 for c in components], axis=0) - 0.5
    upper = np.max([np.array(c['center']) + c['side'] / 2 for c in components], axis=0) + 0.5
    step = (upper - lower) / n
    tilearea = float(np.prod(step))
    cubes = []
    outside = 0
    near = 0
    segments = 0
    cleanup = 0.0
    maxabs = maxrel = 0.0
    flats = 0
    for i in range(n):
        for j in range(n):
            if time.monotonic() > deadline:
                raise TimeoutError('30 second per-configuration budget reached during root evaluation')
            B = lower + (np.array([i, j]) + 0.5) * step
            r, info = outer_root(B, components)
            segments += info['segments']
            near += info['near_entry_threshold']
            cleanup = max(cleanup, info['zero_coefficient_cleanup'])
            flats += info['flat_segments']
            if r is None:
                outside += 1
                continue
            owner = int(np.argmin(np.sum((peaks - B) ** 2, axis=1)))
            maxabs = max(maxabs, info['root_equation_absolute_residual'])
            maxrel = max(maxrel, info['root_equation_relative_residual'])
            cubes.append(dict(grid_index=[i, j], center=B.tolist(), root_radius=r, volume=r * r, owner_peak=owner, lo=(B - r / 2).tolist(), hi=(B + r / 2).tolist(), root_mass=info['root_mass'], root_absolute_residual=info['root_equation_absolute_residual'], root_relative_residual=info['root_equation_relative_residual']))
    if not cubes:
        raise ArithmeticError('No sampled entry cubes')
    lo = np.array([c['lo'] for c in cubes])
    hi = np.array([c['hi'] for c in cubes])
    endpoints = [np.unique(np.r_[lo[:, a], hi[:, a]]) for a in range(2)]
    shape = tuple((2 * len(e) - 1 for e in endpoints))
    ranks = []
    for c in cubes:
        lx, ly = [int(2 * np.searchsorted(endpoints[a], c['lo'][a])) for a in range(2)]
        hx, hy = [int(2 * np.searchsorted(endpoints[a], c['hi'][a])) for a in range(2)]
        ranks.append((lx, ly, hx, hy))
    counts = field_values(shape, ranks, np.ones(len(cubes), int), np.int32)
    S = []
    for k, (lx, ly, hx, hy) in enumerate(ranks):
        if time.monotonic() > deadline:
            raise TimeoutError('30 seconds during finite maximum evaluation')
        S.append(int(np.max(counts[lx:hx + 1, ly:hy + 1])))
    cmax = int(counts.max())
    del counts
    S = np.array(S, int)
    assert np.min(S) >= 1
    Sk = np.zeros(len(cubes), int)
    peak_counts = []
    for owner in range(3):
        ids = [k for k, c in enumerate(cubes) if c['owner_peak'] == owner]
        peak_counts.append(len(ids))
        fc = field_values(shape, [ranks[k] for k in ids], np.ones(len(ids), int), np.int32)
        for k in ids:
            if time.monotonic() > deadline:
                raise TimeoutError('30 seconds during local maximum evaluation')
            lx, ly, hx, hy = ranks[k]
            Sk[k] = int(np.max(fc[lx:hx + 1, ly:hy + 1]))
        del fc
    assert np.min(Sk) >= 1
    caps = field_values(shape, ranks, 1 / S.astype(float), np.float64)
    arg = np.unravel_index(np.argmax(caps), shape)
    cap = float(caps[arg])
    capwhere = [mode_point(endpoints[a], arg[a]) for a in range(2)]
    del caps
    caps_local = field_values(shape, ranks, 1 / Sk.astype(float), np.float64)
    arg = np.unravel_index(np.argmax(caps_local), shape)
    caplocal = float(caps_local[arg])
    localwhere = [mode_point(endpoints[a], arg[a]) for a in range(2)]
    del caps_local
    volumes = np.array([c['volume'] for c in cubes])
    G = float(np.sum(volumes / S))
    Gl = float(np.sum(volumes / Sk))
    X = len(cubes) * tilearea
    for k, c in enumerate(cubes):
        c.update(center_area_weight=tilearea, S_count=int(S[k]), S=tilearea * int(S[k]), local_S_count=int(Sk[k]), local_S=tilearea * int(Sk[k]))
    return dict(d=d, midpoint_grid_n=n, configuration_seconds=time.monotonic() - st, domain_lower=lower.tolist(), domain_upper=upper.tolist(), domain_area=float(np.prod(upper - lower)), tile_area=tilearea, sampled_inside_E_count=len(cubes), sampled_outside_E_count=outside, estimated_E_area=X, owner_peak_sample_counts=peak_counts, root_audit=dict(quadratic_segments_enumerated=segments, maximum_absolute_mass_minus_radius_squared=maxabs, maximum_relative_root_residual=maxrel, near_entry_threshold_sample_count=near, first_segment_exact_zero_coefficient_roundoff_removed=cleanup, flat_quadratic_segments=flats, entry_tolerance=TOL), finite_field=dict(axis_distinct_float_endpoint_counts=[len(e) for e in endpoints], closed_endpoint_and_open_interval_mode_shape=list(shape), mode_count=int(np.prod(shape)), maximum_C=tilearea * cmax, geometry_note='No fuzzy endpoint merging: numpy.unique on computed floating endpoints. Product modes include endpoints/faces/open intervals; integer rectangle difference arrays enumerate the entire finite floating geometry field, not a spatial evaluation grid.'), global_candidate=dict(G=G, G_over_estimated_E=G / X, maximum_load=cap, capacity_maximizer=capwhere, maximum_load_minus_one=cap - 1, finite_feasibility_identity='For x in Qj, S_j_count >= C_count(x); therefore sum_j 1_Qj/S_j_count <= 1 in the finite incidence model, with floating evaluation roundoff recorded.'), local_peak_candidate=dict(G_local=Gl, G_local_divided_by_3=Gl / 3, maximum_unscaled_load=caplocal, capacity_maximizer=localwhere, maximum_load_after_uniform_division_3=caplocal / 3, G_local_divided_by_actual_maxload=Gl / caplocal, global_G_over_coarse_local_G_divided_3=G / (Gl / 3), scope='Owner partition is Euclidean nearest peak center of the same full-density roots. Local weights are not automatically jointly feasible; division by3 is only the coarse analytic sum-of-three-capacities repair.'), actual_continuous_density_components=components, sampled_cubes=cubes, scope='Floating midpoint-center quadrature model only. C, S and capacities refer to this finite area-weighted family. Endpoint enumeration is complete only for computed floating cubes, not certified continuous E; unresolved center-boundary/root variation and continuous G tails remain unbounded.')

def graph_summary(adj,owners):
 N=len(owners);remaining=set(range(N));components=[]
 while remaining:
  start=min(remaining);remaining.remove(start);stack=[start];group=[]
  while stack:
   u=stack.pop();group.append(u);new=[int(v) for v in np.flatnonzero(adj[u]) if int(v) in remaining]
   for v in new:remaining.remove(v)
   stack.extend(new)
  components.append(dict(size=len(group),owner_peak_labels=sorted(set(int(owners[i]) for i in group))))
 upper=np.triu(adj,k=1);different=owners[:,None]!=owners[None,:]
 return dict(component_count=len(components),connected=len(components)==1,components=components,undirected_edge_count=int(upper.sum()),cross_owner_edge_count=int((upper&different).sum()))

def diagnose(r):
 cubes=r['sampled_cubes'];K=len(cubes);lo=np.array([c['lo'] for c in cubes]);hi=np.array([c['hi'] for c in cubes]);owner=np.array([c['owner_peak'] for c in cubes]);counts=[int(c['S_count']) for c in cubes];localcounts=[int(c['local_S_count']) for c in cubes];unique,count=np.unique(counts,return_counts=True);Cmaxcount=max(counts);commonlo=lo.max(0);commonhi=hi.min(0);closed=(lo[:,None,:]<=hi[None,:,:]).all(2)&(hi[:,None,:]>=lo[None,:,:]).all(2);interior=(lo[:,None,:]<hi[None,:,:]).all(2)&(hi[:,None,:]>lo[None,:,:]).all(2)
 closed_summary=graph_summary(closed,owner);interior_summary=graph_summary(interior,owner);common=bool(np.all(commonlo<=commonhi));partial=bool(not common and Cmaxcount<K and closed_summary['connected'] and closed_summary['cross_owner_edge_count']>0)
 r['partial_sharing_diagnostic']=dict(S_count_distinct_values=int(len(unique)),S_count_distribution=[dict(value=int(a),number_of_root_cubes=int(b)) for a,b in zip(unique,count)],Cmax_count=int(Cmaxcount),entry_root_count=K,Cmax_divided_by_total_entry_area=float(Cmaxcount/K),common_root_cube_intersection=dict(lo=commonlo.tolist(),hi=commonhi.tolist(),nonempty_closed=common,positive_area=bool(np.all(commonlo<commonhi))),closed_root_intersection_graph=closed_summary,positive_area_root_intersection_graph=interior_summary,finite_partial_cross_peak_sharing_confirmed=partial,definition='Partial flag requires empty common closed intersection, Cmax<K, connected closed intersection graph, and at least one cross-owner edge. This diagnoses only the finite floating cube family.')
 g=r['global_candidate']['G'];loc=r['local_peak_candidate'];r['loss_comparison']=dict(global_G=g,coarse_three_share_repaired_G=loc['G_local_divided_by_3'],actual_maxload_repaired_local_G=loc['G_local_divided_by_actual_maxload'],global_over_coarse_repair=g/loc['G_local_divided_by_3'],global_over_actual_maxload_repair=g/loc['G_local_divided_by_actual_maxload'],local_unrepaired_maxload=loc['maximum_unscaled_load'])
 return r

results=[]
for d,n in [(2.,16),(2.,32),(.125,16),(.125,32),(.5,32),(.5,64)]:
 r=diagnose(experiment(d,n))
 # Full root tables are deterministically reproducible; archive only necessary summaries.
 del r['sampled_cubes']
 results.append(r)
 print(d,n,r['global_candidate']['G'],r['local_peak_candidate']['maximum_unscaled_load'],flush=True)
out=dict(command=sys.executable+' '+str(Path(__file__).resolve()),versions=dict(python=platform.python_version(),numpy=np.__version__),scope='Six fixed floating midpoint-center models, not continuous integral certificates or dimension asymptotics. All r and root_radius variables denote cube SIDE LENGTH.',results=results)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2,default=lambda v: v.item()))
