# R551：外根差额、共享薄壳扣除与明确阻点

术语约定：B,C均为接收中心，其集合按Lebesgue测度dB计量；实际输入质量为mu=f dx。文中的删除、保留和排序只作用于接收中心及其dB权重，不表示删除或保留mu质量。

状态：未获得一般维数的 C sqrt(n) polylog(n) 全局估计。本报告给出合法积分合同、一个真正使用外根非负差额的具体场、该场在正质量处的严格障碍，以及继续这条路线必须补上的几何步骤。没有修改仓库，没有开启子代理。

本次按 math-a02-outer-relaxation-budget 技能核对了不等式方向与所有费用；未调用或援引未读外部定理。

## 1. 带符号积分方向成立，所需可积性可显式封闭

记 M=mu(R^n)，Q_B=Q(B,R_B)，V_B=R_B^n。假设选取可测，w>=0，且 a(B,dr) 为支撑于 r>=R_B 的可测非负核。足够条件为

W = ∫_E w(B)V_B dB < infinity,
A = ∫_E ∫_[R_B,infinity) r^n a(B,dr)dB < infinity.

定义 P(x)=∫_E w(B)1_QB(x)dB、N(x)=∫_E∫a(B,dr)1_Q(B,r)(x)dB、L=P-N。Tonelli 给

∫P dmu = lambda W,
∫N dmu <= lambda A.

因而 P,N 都分别属于 L1(mu)，没有 infinity-infinity；且 P,N 分别属于 L1(dx)，积分为 W,A。于是

lambda J = lambda(W-A) <= ∫L dmu.

若 L<=1 mu-a.e.，则 ∫L dmu<=M。只要求 mu-a.e.；对 dx-a.e. 的容量上界在本题 mu=f dx 时也足够。为避免在截断后误判符号，应逐次确保上述两个正部积分有限，或先截断再证明共同的一致可积性。单独说“L 可积”不能补救 w/a 两边均无限的差。

## 2. 真正可用的是壳差额，不必支付整个扩张 cube 的体积

外根合同与根等式逐点相减，给每个 r>=R_B：

mu(Q(B,r)\Q_B) <= lambda(r^n-V_B).

这里是从累计外根约束得到的壳累计质量界；没有推出边界密度帽，也没有推出任意壳内子集的体积帽。

取任意非负基权 g(B) 和壳系数核 b(B,dr)。设

P_g(x)=∫g(B)1_QB(x)dB,
H_b(x)=∫∫b(B,dr)[1_Q(B,r)(x)-1_QB(x)]dB.

则 L=P_g-H_b 的合法收益为

J=∫g V - ∫∫b(r^n-V).

它属于原指定形式：令 w=g+∫b、a=b，但必须显式继承第1节的完整正矩条件：W=∫gV+∫∫bV<infinity，A=∫∫br^n<infinity。仅有∫gV及壳差矩∫∫b(r^n−V)有限，并不自动保证W,A分别有限，不能据此直接调用第1节的正负分离Tonelli合同。薄壳只扣一次，能同时降低许多其他接收中心在同一处产生的重叠；这是真正的跨中心共享扣除，而非逐来源位置另选一份证书。

所有费用仍必须保留。例如 r=(1+delta)R_B 的壳费用是 kappa_delta V_B，kappa_delta=(1+delta)^n-1。若 r=R_B+2d，费用正好是 [(1+2d/R_B)^n-1]V_B；没有可略的膨胀因子。

## 3. 最直接的共同场及它为何失败

具体尝试：保留所有真实接收中心及所有尺度，取 g=1/V_B，统一 delta>0，定义

P(x)=∫_E 1_QB(x)/V_B dB,
H_delta(x)=∫_E 1_((1+delta)QB\QB)(x)/V_B dB,
F_delta=P-H_delta/(2 kappa_delta).

精确地有 ∫P dx=|E|，∫H_delta dx=kappa_delta |E|，所以该共同证书的 J=|E|/2。原形式的 W,A 也有限，分别为 (1+1/(2kappa_delta))|E| 与 (1+kappa_delta)/(2kappa_delta)|E|。

如果能证 F_delta<=K_n mu-a.e.，便可将整个场除以 K_n，并得到 lambda|E|<=2K_n M。这个条件并不成立，即使 n=1、delta=1；也不能仅以“端点是 mu 零集”消除它。

### 一维准确障碍

先作易计算的原子极限 mu_0=sum_{j=0}^{N-1} delta_j、lambda=1。忽略有限个中心端点，E_0=(-1/2,N-1/2)。最外根侧长如下：

* 左支 I_k=[(k-2)/2,(k-1)/2)，k=1,...,N-1：R(B)=k；每段长度 1/2。
* 中央 I_N=[(N-2)/2,N/2]：R(B)=N；长度 1。
* 右支为上述左支关于 (N-1)/2 的反射。

这些确是最外根：根 cube 包含 k 个相邻单位质量，且超过该根后的第 m 个新原子，首次可被触及的半径不小于其累计质量所需侧长；故之后不会重新超过水平 1。也可直接从全部有限连续原子块逐一列举验证。

在 x=0，左支和中央的根 cube 都包含 x，右支都不包含。因此

P_0(0) = (1/2) sum_{k=1}^{N-1} 1/k + 1/N.

右支 k 的源段是 [N-(k+1)/2,N-k/2)。它只有在 B<=(1+delta)k/2 时才能贡献 H_delta。因此，对固定 delta>0，

H_delta,0(0) <= (1/2) sum_{k >= ceil((2N-1)/(2+delta))}^{N-1} 1/k
               <= (1/2) log(1+delta/2)+O_delta(1/N).

n=1 时 kappa_delta=delta，因而

F_delta,0(0) >= (1/2) log N - O_delta(1).

统一 delta=delta(n) 不能给维数单独控制的点态上界：固定 n=1 后，delta 是固定常数，N 可任意大。

为回到题设 L1(dx)，取

f_(N,epsilon)(x)=(1/(2epsilon))sum_{j=0}^{N-1}1_[j-epsilon,j+epsilon](x), 0<epsilon<1/8.

对每个固定 N，除有限个接收中心分界外，原子最外根有严格的入射/排除余量；这些根在 epsilon→0 下稳定，R_epsilon(B)→R_0(B)，E_epsilon→E_0。接收中心始终在一个固定紧区间，最外根在 E_epsilon 上有统一正下界（可取 1-2epsilon）；因此支配收敛适用。对第一质量块上任意 x_epsilon∈[-epsilon,epsilon]，P_epsilon(x_epsilon)→P_0(0)、H_delta,epsilon(x_epsilon)→H_delta,0(0)。若不一致，则取一列 x_epsilon→0 后使用同一个支配收敛即矛盾。

故给定 N，可取充分小 epsilon，使整个第一质量块上的 F_delta 与上述原子值任意接近。该块 mu 质量恰为 1，而总质量为 N。因此 log N 高场位于正 mu 质量处，但只占总质量 1/N。这正说明：该反例推翻统一点态封顶，不推翻一种按真实 mu 尾质量付款的全局方案。

### 实际运行的数值校验（仅证据，不替代证明）

Python/NumPy 实际枚举了全部连续原子块的候选根，按真实一维接收中心网格积分。delta=1，N=10,30,100,300 时，网格上 max(P-H/2) 分别为

1.4183194，1.9105045，2.4965681，3.0431605。

对应高点均在端点附近；H 保持约 0.20。这与上面准确调和累积式一致。没有把有限枚举当作连续 n 维证明。

## 4. 跨中心共享的可验证局部规则，以及尚缺的一步

一个具体、合法的共享规则是：选一个真实接收中心 C 与 r>=R_C，令 U=Q(C,r)\Q_C。若当前超额 h(x) 被 U 覆盖，且 h<=t on U，则一次扣除 t1_U 可同时支付所有产生 h 的接收中心；它的精确收益损失是 t(r^n-V_C)。这是一条可加到积分证书上的单独标量根不等式；若坚持原先以 dB 为中心测度的参数化，单个 C 是零测集，不能把该操作直接写成 w(B)dB 或 a(B,dr)dB。合法实现须另行允许有限或可数的中心原子测度，并要求其根费用与外费用分别可求和，届时按同样 Tonelli 证明；或构造具有相应覆盖和费用控制的正 Lebesgue 测度中心包。本轮没有证明这样的包稳定化，也没有把单中心规则作为原密度参数化中已实现的全局构造。

此规则本身没有根阶收益。若用到的接收根 C 距热区较远，单次代价中仍有 [(1+2d/R_C)^n-1]；n 维可控薄壳只允许 d/R_C=O(log n/n)。在上述一维例子中，端点热场深处于许多根 cube 内，同一统一小壳几乎找不到接收中心；需要先按尺度/接收中心重新分配或合并，而非直接增加统一壳系数。

本轮没有证明能解决这个缺口的共同选择机制。准确缺项是：构造单一、可测的接收中心排序/合并规则，使跨中心壳转移在所有尺度上同时合法，并以整个接收中心集合的Lebesgue测度为预算控制累计转移费用，同时将正 mu 高场的剩余贡献控制到 O(sqrt(n) polylog(n))M。端点例子要求允许以其 1/N 的真实 mu 尾比例付款；任何无尾预算的统一点态版本已经失败。

仅写“优化 w,a”或把这一要求改写成 ∫F_+dmu 的目标，均没有给出缺失的几何估计。本报告不将它们登记为新成果，也不从特定统一薄壳候选失败推断一般 signed packing 不可能。


## 5. 对上述障碍的一个真正全局付款机制：仅在一维测试族中闭合

统一薄壳失败后，仍可检验一个真实的共同接收中心排序，而非只讨论点态坏例。对该等距原子族，按根侧长排序，保留 R(B)>=k0 的整个接收中心包，k0=ceil(N/2)，并在保留接收中心上取 w=1/R，其他接收中心取 0。没有逐原子另选权。

保留接收中心集合的Lebesgue测度恰为 N-k0+1>=N/2，而对整个实轴共同成立

P_retained(x) <= ∫_[R>=k0] dB/R(B)
              = sum_{k=k0}^{N-1}1/k+1/N
              <= log 2+O(1/N).

因此删除至多一半接收中心集合的Lebesgue测度就一次支付了端点的全部 log N 尺度累积，留下半数以上真实接收中心，且无需任何负项。这个机制也在固定 N 的窄块 L1 稳定化下保留（边界接收中心只带 o(1) 费用）。它说明本例的点态障碍确实可由共同接收中心排序付款，不能据此否定一般 signed 目标。

但这里的关键是根侧长 >=N/2 的接收中心本身占正比例，且所有接收中心是一个连续端点簇。一般高维、多簇几何没有已证的相应包分解。若照搬一个全局根中位数，彼此远离的许多小簇就会使 ∫dB/V_B 随簇数增长；必须先通过空间局部簇共享容量，并控制簇合并及膨胀。尚未构造能兼顾这两项、又给出 sqrt(n) polylog(n) 总费用的规则。

另一个直接可验的全局事实是本族所有质量点上的完整根场均值恰为 1。记 H_j=sum_{k=1}^j1/k，H_0=0，则

P_0(j)=H_(N-1)-(H_j+H_(N-1-j))/2+1/N,
(1/N)sum_{j=0}^{N-1}P_0(j)=1.

所以端点 log N 高值和全局 O(1) 付款在同一个真实测度上同时发生。这个均值恒等式只核验此测试族，没有作为一般尾估计或一般维数结论。

## 6. 数值复现记录

运行环境：本机 `python3 --version` 实际输出 Python 3.15.0。只运行内存计算，没有生成或改动仓库脚本。为满足仅写本报告的文件职责，以下完整内联脚本就是可复现版本；没有虚构单独脚本路径。命令为 `python3 - <<'PY' ... PY`。

第一段实际执行的根枚举脚本：

```python
import numpy as np
for N in [10,30,100,300]:
    atoms=np.arange(N,dtype=float); lam=1.0
    bs=np.linspace(-1,N,30001); db=bs[1]-bs[0]
    root=np.zeros_like(bs)
    for k in range(1,N+1):
        R=k/lam
        lo=atoms[:N-k+1]+(k-1)-R/2
        hi=atoms[:N-k+1]+R/2
        for l,h in zip(lo,hi):
            mask=(bs>=l)&(bs<=h)
            root[mask]=np.maximum(root[mask],R)
    mask=root>0; b=bs[mask]; R=root[mask]
    best=(-1,None,None,None)
    for x in np.linspace(-1,N,601):
        d=np.abs(b-x)
        P=np.sum((d<=R/2)/R)*db
        H=np.sum(((d<=R)&(d>R/2))/R)*db
        D=P-H/2
        if D>best[0]: best=(D,x,P,H)
    print(N,best)
```

第二段实际执行的准确公式和接收中心排序校验：

```python
import numpy as np
for N in (10,30,100,300):
    harmonic=np.r_[0,np.cumsum(1/np.arange(1,N))]
    P=harmonic[-1]-(harmonic+harmonic[::-1])/2+1/N
    cutoff=(N+1)//2
    cap=np.sum(1/np.arange(cutoff,N))+1/N
    retained=N-cutoff+1
    print(N,'mean P=',P.mean(),'max P=',P.max(),
          'retained source length=',retained,'pruned cap bound=',cap)
```

第二段实际输出：

* N=10：mean P=1.0；max P=1.514484126984127；retained=6；cap=0.8456349206349206。
* N=30：mean P=0.9999999999999997；max P=2.014160232126862；retained=16；cap=0.7434248043580644。
* N=100：mean P=1.000000000000001；max P=2.59868875881981；retained=51；cap=0.7081721793101952。
* N=300：mean P=0.9999999999999984；max P=3.142998606816418；retained=151；cap=0.6981499583222913。

本轮终态：外根壳扣除的合法合同已封闭；最直接共同点态场被明确排除；一维端点障碍在本族中可由真实共同接收中心排序支付。一般维数的空间分簇加接收中心排序，以及其 sqrt(n) polylog(n) 费用界，仍未证明。本报告不把这个尚缺步骤包装成新全局估计。
