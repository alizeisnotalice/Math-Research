from fractions import Fraction as F
from itertools import product
cases=[('balanced', [F(1,2)]*2,[F(1,2)]*2,F(1)),
       ('imbalanced',[F(1,2),F(1,4)],[F(1,4),F(1,2)],F(1)),
       ('capacity-limited',[F(1,2)]*2,[F(1,2)]*2,F(1,2))]
for name,a,b,C in cases:
    # Actual reference domination; actual pair is entirely off the near diagonal.
    original=[[F(0),a[0]*b[1]],[a[1]*b[0],F(0)]]
    eta=[sum(row) for row in original]
    zeta=[sum(original[i][j] for i in range(2)) for j in range(2)]
    r=sum(eta)
    cap=[C*a[i]*b[i] for i in range(2)]
    h=[min(eta[i],zeta[i],cap[i]) for i in range(2)]
    matched=sum(h); deficit=r-matched
    hall=F(0)
    for B in product((0,1),repeat=2):
        for T in product((0,1),repeat=2):
            cut=sum(eta[i]*B[i]+zeta[i]*T[i] for i in range(2))-r
            cut-=sum(cap[i]*B[i]*T[i] for i in range(2))
            hall=max(hall,cut)
    assert hall==deficit
    er=[eta[i]-h[i] for i in range(2)]
    zr=[zeta[i]-h[i] for i in range(2)]
    fill=[[er[i]*zr[j]/deficit if deficit else F(0) for j in range(2)] for i in range(2)]
    comparison=[[fill[i][j]+(h[i] if i==j else 0) for j in range(2)] for i in range(2)]
    assert [sum(row) for row in comparison]==eta
    assert [sum(comparison[i][j] for i in range(2)) for j in range(2)]==zeta
    keep=[h[j]/zeta[j] if zeta[j] else F(0) for j in range(2)]
    pulled=[[original[i][j]*keep[j] for j in range(2)] for i in range(2)]
    assert sum(map(sum,pulled))==matched
    cost=[F(-1),F(3)]
    oldcost=sum(original[i][j]*cost[j] for i in range(2) for j in range(2))
    newcost=sum(comparison[i][j]*cost[j] for i in range(2) for j in range(2))
    assert oldcost==newcost
    assert sum(pulled[i][j]*cost[j] for i in range(2) for j in range(2))==sum(h[j]*cost[j] for j in range(2))
    print(name,'mass',r,'matched',matched,'Hall deficit',deficit,'new-terminal cost',oldcost,'PASS')
print('Scope: three finite exact coupling/cut/pullback checks. No native cube or original-history realization is asserted.')
