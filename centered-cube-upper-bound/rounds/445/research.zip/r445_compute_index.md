# R445 计算索引（完成）

责任numeric；不独占workspace，不改他人/repo，无agent。

只读输入`r445_contract.md`，root/Astra冻结partial capped-near Hall接口、raw μ/ν与actual η/ζ区分、second-column pullback定义。任务中途从ordinaryOT转为capacity LP，故未另跑ordinaryOT。

三阶段：2×2基础，3×3 zero/unequal pressure，4×5 expanded centers（C=√4=2）。同完整uniform f、actual variable cubes、positive center blocks/source packets；whole-block near由Arb判定。3 HiGHS LP→Fraction primal→完整有限Hall cut/0-1 dual最优证书；核cap/marginal/残余completion以及original-far second-column pullback。

实际命令：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r445_numeric.py`
Python3.12.14，SciPy1.18.1，flint0.9.0，Arb256bit；.24秒、RSS约84.2MB。

输出：`r445_numeric.py`、`r445_numeric_certificate.json`、`r445_numeric_run.txt`、`r445_numeric_resources.txt`、`r445_numeric.md`及本索引，全部`/tmp/`。脚本输出自身目录、无外部输入依赖。

范围：真实cube marginal接口，明确原strict massgap失败/high-history未实现。Hall deficit未付，同marginal U不变；不认证全R433或transport通用预算。完成停止。

作者辅助验证：geometry_check.py核三组Fraction有限耦合的Hall等式、补全和原flow拉回；mainproof_check.py核3保留表×4容量×16 cuts共192项，来源为非均匀f和真实一维中心块，但不满足原高维合同。解释器均指定独立Python。隔离复跑用于复现，不增加样本覆盖。
