"""Three genuine continuous cube/source interface fixtures; capped near matching.
SciPy finds a candidate, Fraction flow and Hall/mincut certify it exactly.
No original-history or high-rank realization. Output beside this script.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json,sys,platform
import numpy as np
from scipy.optimize import linprog
import scipy
from flint import arb,ctx
import flint
ROOT=Path(__file__).resolve().parent;ctx.prec=256

def A(x):
 x=F(x);return arb(str(x.numerator))/arb(str(x.denominator))
n=4;h=F(12);kappa=F(1,10000)*F(1,1000)**(n-1);rawscale=kappa/h
source_half=F(1,2000);other_width=F(1,1000);alpha0=arb(1).exp()

specs=[
 ('initial_two_by_two',[F(-4,5),F(-11,10)],[F(6,5),F(11,10)],[F(1,2),F(1,2)],
  [F(4,5),F(11,10)],[F(6,5),F(11,10)],[F(1,2),F(1,2)],F(1)),
 ('zero_and_unequal_marginals',[F(-4,5),F(-11,10),F(-3)],[F(6,5),F(11,10),F(11,10)],
  [F(1,4),F(3,4),F(0)],
  [F(4,5),F(11,10),F(3)],[F(6,5),F(11,10),F(11,10)],
  [F(1,3),F(2,3),F(0)],F(1)),
 ('expanded_centers_C_equals_sqrt_n',list(map(F,['-0.77','-0.8','-0.83','-1.1'])),
  list(map(F,['1.2','1.15','1.2','1.1'])),[F(1,5),F(3,10),F(1,5),F(3,10)],
  list(map(F,['0.77','0.8','0.83','1.1','1.2'])),
  list(map(F,['1.2','1.15','1.2','1.1','1.2'])),[F(1,4),F(1,5),F(1,4),F(1,10),F(1,5)],F(2))]

def receivers(centers,sides,weights,source):
 assert sum(weights,F(0))==1
 out=[]
 for x,R,prob in zip(centers,sides,weights):
  mass=R**n # one complete f=1 on [-4,4]^4, zero outside
  design=prob if prob else F(1)
  width=mass*design/F(10000)
  assert abs(x)+width/2+R/2<4 and other_width/2+R/2<4
  inside=abs(x-source)+width/2+source_half<R/2
  outside=abs(x-source)-width/2-source_half>R/2
  assert inside if prob else outside
  # Exact positive Lebesgue block volume, not a point-center declaration.
  volume=width*other_width**(n-1)
  assert volume>0
  rho=volume/mass if inside else F(0)
  assert rho==kappa*prob
  out.append({'center_x1':x,'side':R,'mass':mass,'first_width':width,
              'other_width':other_width,'volume':volume,'rho_own_source':rho})
 return out

reports=[]
for name,lc,lR,aa,rc,rR,bb,C in specs:
 left=receivers(lc,lR,aa,F(-7,10));right=receivers(rc,rR,bb,F(7,10))
 m=len(aa);k=len(bb);near=[];distance=[]
 for i,w in enumerate(left):
  nr=[];dr=[]
  for j,v in enumerate(right):
   half=(w['first_width']+v['first_width'])/2
   d=abs(w['center_x1']-v['center_x1']);assert d-half>other_width
   dlo=2*(d-half)/max(w['side'],v['side']);dhi=2*(d+half)/max(w['side'],v['side'])
   if A(dhi)<alpha0:isnear=True
   else:assert A(dlo)>alpha0;isnear=False
   nr.append(isnear);dr.append([str(dlo),str(dhi)])
  near.append(nr);distance.append(dr)
 # An explicit actual retained reference: all raw far pairs retained.
 raw=[[a*b for b in bb] for a in aa]
 gamma=[[raw[i][j] if not near[i][j] else F(0) for j in range(k)] for i in range(m)]
 eta=[sum(row,F(0)) for row in gamma]
 zeta=[sum((gamma[i][j] for i in range(m)),F(0)) for j in range(k)]
 total=sum(eta,F(0));assert total==sum(zeta,F(0))>0
 caps=[[C*raw[i][j] if near[i][j] else F(0) for j in range(k)] for i in range(m)]
 # Partial matching H: row<=actual eta, column<=actual zeta, edge<=C raw.
 mat=np.zeros((m+k,m*k))
 for i in range(m):
  for j in range(k):mat[i,i*k+j]=1;mat[m+j,i*k+j]=1
 sol=linprog(-np.ones(m*k),A_ub=mat,b_ub=np.array(list(map(float,eta+zeta))),
       bounds=[(0,float(caps[i][j])) for i in range(m) for j in range(k)],method='highs')
 assert sol.success
 H=[[F(float(sol.x[i*k+j])).limit_denominator(10**8) for j in range(k)] for i in range(m)]
 hr=[sum(row,F(0)) for row in H];hc=[sum((H[i][j] for i in range(m)),F(0)) for j in range(k)]
 assert all(x<=y for x,y in zip(hr,eta)) and all(x<=y for x,y in zip(hc,zeta))
 assert all(0<=H[i][j]<=caps[i][j] for i in range(m) for j in range(k))
 value=sum(hr,F(0))
 # Exhaust the finite 2^(m+k) Hall cuts, not a geometry/parameter scan.
 best=None;bestcut=None
 for ibits in product([False,True],repeat=m):
  for jbits in product([False,True],repeat=k):
   deficit=sum((eta[i] for i in range(m) if ibits[i]),F(0))+sum((zeta[j] for j in range(k) if jbits[j]),F(0))-total-sum((caps[i][j] for i in range(m) for j in range(k) if ibits[i] and jbits[j]),F(0))
   if best is None or deficit>best:best,bestcut=deficit,(ibits,jbits)
 D=max(F(0),best);assert value==total-D
 I,J=bestcut
 du=[F(not b) for b in I];dv=[F(not b) for b in J]
 de=[[F(I[i] and J[j]) for j in range(k)] for i in range(m)]
 assert all(du[i]+dv[j]+de[i][j]>=1 for i in range(m) for j in range(k) if near[i][j])
 dual=sum((du[i]*eta[i] for i in range(m)),F(0))+sum((dv[j]*zeta[j] for j in range(k)),F(0))+sum((de[i][j]*caps[i][j] for i in range(m) for j in range(k)),F(0))
 assert dual==value
 # Full residual completion preserves marginals, but loses the raw C cap.
 er=[x-y for x,y in zip(eta,hr)];zr=[x-y for x,y in zip(zeta,hc)]
 fill=[[H[i][j]+(er[i]*zr[j]/D if D else F(0)) for j in range(k)] for i in range(m)]
 assert all(sum(fill[i],F(0))==eta[i] for i in range(m))
 assert all(sum((fill[i][j] for i in range(m)),F(0))==zeta[j] for j in range(k))
 ratios=[fill[i][j]/raw[i][j] for i in range(m) for j in range(k) if raw[i][j]]
 # Pull H's second marginal back to the actual far-supported Gamma.
 retention=[hc[j]/zeta[j] if zeta[j] else F(0) for j in range(k)]
 assert all(0<=x<=1 for x in retention)
 pull=[[gamma[i][j]*retention[j] for j in range(k)] for i in range(m)]
 assert sum((sum(row,F(0)) for row in pull),F(0))==value
 assert all(sum((pull[i][j] for i in range(m)),F(0))==hc[j] for j in range(k))
 assert sum((pull[i][j] for i in range(m) for j in range(k) if near[i][j]),F(0))==0
 assert all(H[i][j]==0 for i in range(m) for j in range(k) if not near[i][j])
 # Actual geometric cell C around new-source .7 is inside parent side1.5 and
 # every right terminal, so the finite U(v) probe is log(mA/mv).
 parent_mass=F(3,2)**n
 assert F(7,10)+F(1,200)+F(1,2000)<F(3,4)
 for v,prob in zip(right,bb):
  if prob:assert abs(v['center_x1']-F(7,10))+v['first_width']/2+F(1,200)<v['side']/2
 Ucost=[(A(parent_mass)/A(v['mass'])).log() if prob else arb(0) for v,prob in zip(right,bb)]
 hu=sum((A(hc[j])*Ucost[j] for j in range(k)),arb(0))
 pu=sum((A(sum((pull[i][j] for i in range(m)),F(0)))*Ucost[j] for j in range(k)),arb(0))
 assert (hu-pu).contains(0)
 actual_u=sum((A(zeta[j])*Ucost[j] for j in range(k)),arb(0))
 fill_u=sum((A(sum((fill[i][j] for i in range(m)),F(0)))*Ucost[j] for j in range(k)),arb(0))
 assert (actual_u-fill_u).contains(0)
 def table(x):return [[str(v) for v in row] for row in x]
 report={'name':name,'n':n,'C_input':str(C),'near_threshold':'exp(2/sqrt(n))=exp(1)',
 'source_packets_centers':[['-7/10','0','0','0'],['7/10','0','0','0']],
 'source_packet_side':'1/1000','f':'1 on [-4,4]^4, zero outside; W=4096; q=1',
 'parent':'positive block about 0, selected side3/2; source cell near+.7 contained',
 'left_receivers':[{z:str(v) for z,v in row.items()} for row in left],
 'right_receivers':[{z:str(v) for z,v in row.items()} for row in right],
 'raw_normalized_a':list(map(str,aa)),'raw_normalized_b':list(map(str,bb)),
 'raw_sourcewise_scale_rho_over_h':str(rawscale),'all_pair_masses_scale':str(rawscale**2),
 'raw_a_actual':list(map(str,[rawscale*x for x in aa])),
 'raw_b_actual':list(map(str,[rawscale*x for x in bb])),
 'whole_block_distance_bounds':distance,'near_matrix':near,'actual_Gamma_scaled':table(gamma),
 'actual_row_scaled':list(map(str,eta)),'actual_column_scaled':list(map(str,zeta)),
 'actual_mass_scaled':str(total),'partial_H_scaled':table(H),'optimal_near_mass_scaled':str(value),
 'Hall_deficit_scaled':str(D),'Hall_cut_rows':list(I),'Hall_cut_columns':list(J),
 'dual_row':list(map(str,du)),'dual_column':list(map(str,dv)),'dual_edge':table(de),
 'dual_value_scaled':str(dual),'primal_dual_exact':True,
 'complete_same_marginal_fill_scaled':table(fill),'complete_fill_max_raw_density':str(max(ratios)),
 'complete_fill_obeys_C_raw_cap':max(ratios)<=C,
 'pullback_b_by_terminal':list(map(str,retention)),'pullback_Gamma_scaled':table(pull),
 'matched_near_mass_scaled':str(value),'pullback_actual_near_mass_scaled':'0',
 'terminal_only_U_probe_actual_Gamma_Arb':str(actual_u),'terminal_only_U_probe_complete_fill_Arb':str(fill_u),
 'terminal_only_U_probe_H_Arb':str(hu),'terminal_only_U_probe_pullback_Arb':str(pu),
 'LP_float_optimum':float(-sol.fun),'LP_equality_certificate':'exact primal equals Hall/mincut dual',
 'scope':'Native continuous sourcewise terminal-marginal interface; original strict massgap/high-rank/history fail or are not implemented; matching witnesses not actual near original flow.'}
 reports.append(report)
 print(name,'size',m,k,'C',C,'actual mass',total,'max near H',value,'Hall deficit',D,
       'full-fill max raw density',max(ratios),'pullback actual near mass=0')
(ROOT/'r445_numeric_certificate.json').write_text(json.dumps({'environment':{'executable':sys.executable,'python':platform.python_version(),'scipy':scipy.__version__,'flint':flint.__version__,'Arb_bits':ctx.prec},'cases':reports,
 'scope':'Three small structured true-cube marginal interfaces, not original history or full U budget.'},indent=2)+'\n')
print('PASS: 3 LPs; rational primal/caps/marginals/Hall dual; actual far pullback and same-terminal U identity.')
