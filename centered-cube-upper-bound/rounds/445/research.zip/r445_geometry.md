# R445 — capacity-limited terminal matching and a paid fraction of the original flow

**Result.** A near partial matching of the two actual terminal marginals can be pulled back to a positive fraction of the original flow. That fraction keeps every original history label and has a root-dimensional source price. The complement is exactly an integrated capacitated Hall deficiency, whose general geometric budget is **not** proved here. A cheap auxiliary coupling is never used as an upper bound for the cost of the original coupling.

Use all original R445 fields and gates, and let P denote the complete original lifted remaining measure, of mass R. Set
\[
 s=1+\sqrt n,\quad h=s/(\varepsilon_0q),\quad
 K=e^{\sqrt n},\quad r=\lambda/q,\quad A_n=1+n\log(b/a),
 \quad\alpha_0=K^{2/n}.
\]
The source mass W and X_q=∫σ are unchanged. The new matching capacity multiplier is \(\mathfrak c>0\); the principal choice below is \(\mathfrak c=\sqrt n\).

## 1. Same sources and actual subprobability marginals

Fix the base record \(\xi=(e,A,y,z,t)\), retaining the original parent, old and new sources, direction and clipping level. Define the finite reference measure
\[
 d\Lambda(\xi)=\sigma(dA)\pi_A(dy)a_0^e(A,y)
       \frac{c_A(z)}{m_A}1_{\{f(z)>t\}}\,dz\,dt,
 \qquad \Lambda(1)\le SX_q.
 \tag{1}
\]
At a fixed t only its original clipping stage contributes. Original current densities are bounded by a_0; all remaining early, clock, rank, deletion and future factors stay in the actual measure. They are not replaced by newly generated histories.

Let the real receiver reference measures be
\[
 \mu_\xi(dw)=1_{\{Z_w(y)\le h,\,m_w<m_A/K^2\}}
                     c_w(y)\frac{dw}{h m_w},
\]
\[
 \nu_\xi(dv)=1_{\{Z_v(z)\le h,\,m_v<m_A/K^2\}}
                     c_v(z)\frac{dv}{h m_v}.
 \tag{2}
\]
These are finite measures on the actual E, not probability laws assigned to refreshed sources. Additional certified single-terminal necessary gates may be retained. No pair-dependent history is inserted into (2).

Push the same P to \((\xi,w,v)\). The original own-high starts, the whole-terminal bound, and conditional independence of the two **unfiltered** generated paths give a kernel \(\Gamma_\xi\) such that
\[
 dP_{\xi,w,v}=d\Lambda(\xi)\,d\Gamma_\xi(w,v),\qquad
 0\le\Gamma_\xi\le\mu_\xi\otimes\nu_\xi.
 \tag{3}
\]
This is a positive domination after removing future restrictions on the right, not an assertion that the actual filtered paths are independent. The density in (3) retains their effect on the left. Write
\[
 \eta_\xi=(\Gamma_\xi)_1,\quad\zeta_\xi=(\Gamma_\xi)_2,
 \quad r_\xi=\eta_\xi(E)=\zeta_\xi(E).
\]
No division by r_ξ is made. In particular the raw measures μ,ν must not be confused with the actual retained marginals η,ζ.

For fixed ξ the signed integrand
\[
 \ell_\xi(v)=\log\frac{m_A B_{v,C(z)}(t)}{m_v B_{A,C(z)}(t)}
 \tag{4}
\]
only depends on the new terminal v. Any auxiliary coupling preserving ζ preserves its integral, including its absolute integrability. This observation does not transfer history to the auxiliary coupling.

## 2. Near partial flow and its exact deficiency

Let
\[
 N_\alpha=\{(w,v):2\|w-v\|_\infty/
                    \max(R_w,R_v)\le\alpha_0\}.
\]
\[
a_\xi(dw,dv)=\mathfrak c\,1_{N_\alpha}
                         \mu_\xi(dw)\nu_\xi(dv).
 \tag{5}
\]
A feasible partial matching is a measurable family H_ξ satisfying
\[
 0\le H_\xi\le a_\xi,\qquad (H_\xi)_1\le\eta_\xi,
                         \quad(H_\xi)_2\le\zeta_\xi.
 \tag{6}
\]
Thus it uses only actual receivers which capture their respective fixed sources. The original remaining coupling is far, but H is an analysis plan and is allowed to be near. It is not asserted to have the old pair history.

The maximum partial mass is \(r_\xi-d_\xi\), where
\[
 d_\xi=\sup_{B,T\subset E\,\text{measurable}}
 \left[\eta_\xi(B)+\zeta_\xi(T)-r_\xi
              -a_\xi(B\times T)\right]_+.
 \tag{7}
\]
The inequality \(|H_\xi|\le r_\xi-d_\xi\) follows directly: every full pair of marginals must send at least η(B)+ζ(T)−r through B×T; a partial plan loses at most r−|H| of that demand. The reverse inequality and measurable realization require the argument below; the cut inequality alone is not enough.

**Continuous realization without geometric boundary assumptions.** Choose increasing finite partitions of E whose union generates its Borel sigma field. For each ξ, use exact near-capacity integrals on partition rectangles and the exact actual marginal masses. The finite max-flow/min-cut theorem gives maximum value r_ξ−d_{ξ,N}. The cut maxima increase under refinement. Approximation of arbitrary measurable sets in the finite measure consisting of η,ζ and the two capacity marginals proves d_{ξ,N}↑d_ξ. This approximation is in measure; it does not require null cube boundaries or continuous radius selectors. In particular d_ξ is measurable, since each finite cut maximum is measurable.

Finite optimal flows can be selected measurably, for example by enumerating finite LP bases and breaking ties in a fixed order. Lift a block flow to the actual capacity in that block by its constant ratio to the block capacity (zero on a zero-capacity block). The lifted H_N obeys the capacity bound, but initially only aggregate marginal bounds on the partition cells.

Now use the global finite measure
\[
 d\mathfrak A(\xi,w,v)=d\Lambda(\xi)\,da_\xi(w,v).
\]
It is finite by the native estimate in Section 3. The densities dH_N/d𝔄 lie in [0,1]. Since the underlying spaces are standard Borel and the measure is finite, L¹(𝔄) is separable; weak-* compactness supplies a subsequential limit H. For every fixed generating cell and every bounded nonnegative measurable test function of ξ, the required marginal inequality holds at all sufficiently fine N and passes to the limit. The generating-algebra and monotone-class argument gives the true marginal inequalities in (6), not merely coarse ones.

Moreover
\[
 |H_N|=\int(r_\xi-d_{\xi,N})\,d\Lambda
 \longrightarrow\int(r_\xi-d_\xi)\,d\Lambda,
\]
by dominated convergence, since 0≤d_{ξ,N}≤r_ξ and ∫r_ξdΛ=R<∞. Weak-* convergence preserves the total mass. The cut bound holds for the limit on each fiber, so equality of the integrated values forces fiberwise optimality almost everywhere. This proves a measurable optimal partial family satisfying (6)–(7). Zero fibers have H=d=0.

## 3. Native price of the matched mass

The two-capture matching estimate proved in R444 applies before any history is added. At fixed A, with \(I_{Au}=f(Q_A\cap Q_u)\),
\[
 \int_{N_\alpha,\,m_w,m_v<m_A/K^2}
 \frac{I_{Aw}I_{Av}}{m_A^2m_wm_v}\,dw\,dv
 \le\frac{2\alpha_0^n}{K^2q^2}=\frac2{q^2}.
 \tag{8}
\]
Briefly, on w∈αQ_v, use I_Aw≤m_w and the actual w-center volume≤α^nR_v^n. Then R_v^n/m_v≤1/q and Tonelli gives ∫_{m_v<M}I_Av dv≤m_AM/q, M=m_A/K². Exchange w,v for the other event. This is full matching with actual center measure; it is not a bound on source mass from a boundary volume.

Integrate (6) against Λ, first integrating the clipping variable once and then using Σ_ea_0^e(A,y)≤S. The two measures (2) contribute exactly h^{-2}. Hence
\[
 \int |H_\xi|\,d\Lambda
 \le\frac{2\mathfrak c S}{q^2h^2}X_q
 =\frac{2\mathfrak c S\varepsilon_0^2}{s^2}X_q.
 \tag{9}
\]
The true identity q_A=m_A/R_A^n gives the sharper direct estimate
\[
 X_q=\int f(x)\int_E c_A(x)R_A^{-n}\,dA\,dx\le A_nW.
\]
Indeed, use R_A^{-n}=b^{-n}+\int_{R_A}^b nt^{-n-1}dt. Capturing centers have volume at most b^n in the base term; with R_A≤t they have volume at most t^n. Thus the inner integral is at most 1+n\log(b/a). This uses the actual selector, not an independently integrated radius.
Thus the same matched mass has the source price
\[
 \int |H_\xi|\,d\Lambda
 \le\Omega(\mathfrak c)W,
 \quad\Omega(\mathfrak c)=
 \frac{2\mathfrak c S\varepsilon_0^2 A_n}{s^2}.
 \tag{10}
\]
For \(\mathfrak c=\sqrt n\), octave b/a≤2 implies A_n≤1+n≤s², and therefore
\[
 \boxed{\int |H_\xi|\,d\Lambda
             \le2S\varepsilon_0^2\sqrt n\,W.} \tag{11}
\]
Equations (9) and (10) are alternative prices for the same mass, not two charges. Neither uses a terminal count, a source density cap, or a new source law. Finiteness needed in the preceding compactness argument already follows from (9) applied to the capacity itself.

## 4. Pulling this price back to original histories

Let ζ_H=(H_ξ)_2 and define
\[
 b_\xi(v)=\frac{d\zeta_H}{d\zeta_\xi}(v)\in[0,1],
 \qquad dP_{\rm match}=b_\xi(v)\,dP.
 \tag{12}
\]
Zero ζ fibers use b=0. These are actual absolutely continuous receiver measures, so the derivative may be chosen measurably by ratios of their joint densities. The measure P_match is a positive fraction of the original complete flow. Every original source, stage, acceptance, clock, deletion and path restriction remains true on it. Its mass is exactly ∫|H_ξ|dΛ. Its original terminal pair may remain entirely far; only the analysis matching H is near.

Consequently (11) is a genuine source price for an actual original fraction, not a second payment for the old actual-near event. The remaining original measure \(P-P_{\rm match}\) has mass
\[
 \mathcal D(\mathfrak c)=\int d_\xi\,d\Lambda,
 \qquad
 \boxed{R\le\Omega(\mathfrak c)W+\mathcal D(\mathfrak c).} \tag{13}
\]
For the chosen optimal H the exact mass identity is R=∫|H_ξ|dΛ+𝒟. No lower bound for the matched fraction or general budget for 𝒟 is claimed. In particular (13) is not the full root theorem.

For clarity, a complete comparison coupling with the same two marginals can also be formed. Put η_res=η−H₁, ζ_res=ζ−H₂. On d_ξ>0 use
\[
 \widetilde\Gamma_\xi=H_\xi+
                   \eta_{\rm res}\otimes\zeta_{\rm res}/d_\xi;
\]
on d_ξ=0 use H. This preserves R and the signed U integrand (4). The completion has no asserted raw-product capacity bound; its entire mass d_ξ remains unpaid. The pullback (12), rather than the completion, is what keeps the original histories.

## 5. The remaining geometric obligation

The global goal would follow from a suitable estimate for 𝒟(√n), for example tX_q+C_t s polylog(n)W with the intended constants. No such estimate is proved here. It is a concrete actual-marginal obligation: for every source-dependent measurable cut B,T, the deficit in (7) compares true retained endpoint masses with an actual near-center capacity.

In particular, if T is outside the actual near-neighborhood of B, the capacity term vanishes. The corresponding necessary deficit is the positive part of the old marginal on B minus the new marginal in that neighborhood. Existing low-common and matching estimates are principally upper bounds and do not automatically provide this neighborhood balance. The sets may depend on all of ξ, including t and the actual current acceptance. One cannot remove that dependence, replace the marginals by refreshed posteriors, or propagate initial source exclusions to terminal receivers.

Thus the proved progress is the actual pullback price (11) and the exact, attainable deficiency (7). The missing step is geometric control of its integrated value, not existence of a cheap unqualified transport plan. Only the R slot in any later ledger may be replaced according to (13); old source fees and earlier near payments are not added again or refunded.

## 6. Local verification and evidence scope

The local specified Python ran `/tmp/r445_geometry_check.py`; output is `/tmp/r445_geometry.result.txt`. Three exact Fraction 2×2 models check: all-subsets Hall equality, primal partial mass, zero-deficit handling, residual completion, full marginal preservation, original-flow pullback mass, and invariance of a signed new-terminal-only test cost. They give (original mass,matched mass,deficit)=(1/2,1/2,0), (5/16,1/8,3/16), and (1/2,1/4,1/4). Their original couplings are supported off the analysis-near diagonal; the pulled-back records remain there.

These are finite coupling identities, not native cube/history examples. Independent native-center marginal fixtures are recorded by the numeric author under `/tmp/r445_numeric*`; their narrower geometric qualifications must be read separately. Their uniform-source n=4 fields fail the original K² mass-gap gate, so no complete original-history nonemptiness is inferred from them. The continuous proof and coefficient (11) are analytic. This bounded attachment stops without asserting a general Hall-deficiency price.
