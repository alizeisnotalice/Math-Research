# R445 真cube marginal接口：capped near匹配与pullback

实际运行指定newenv的`r445_numeric.py`，3个小型SciPy HiGHS LP。每个浮点解均重建为Fraction，并以完整Hall/mincut对偶严格认证最优。最终.24秒、RSS84,180,992字节；无ordinary OT扩展、扫描或原history模拟。

## 1. 真实连续数据与单位

同一完整f=1于[-4,4]^4，外部为0，W=4096。source为中心±.7e1、边长.001的正体积包。固定parent为0附近正中心块、side1.5。terminal均为实际axis-aligned cube，side∈{1.1,1.15,1.2}，完整质量m=R^4、q=1。

每个receiver中心块为正体积长方体：第一坐标宽`m_i a_i/10000`，其余坐标宽.001。于是volume/m_i=κa_i，κ=10^−13；新端对应b_j。零marginal采用真实不捕获该source的额外正体积receiver，并非零中心体积。所有捕获／排斥对整个source包和center块以严格边距核验。

取eps0=1/4、s=3、h=12，raw sourcewise terminal weights为`μ_i=θa_i, ν_j=θb_j`，θ=κ/h=1/120000000000000。下表和JSON中的pair量统一除θ²求解，再精确还原；不能把归一概率a,b混作原raw权。

near按`Δ=2||w−v||∞/max(Rw,Rv)≤exp(2/√4)=e`。Arb256bit用整center块的距离上下界严格判别，不是只查点center。actual retained reference为Γ=raw·1_far，因此全支持far，Γ≤μ⊗ν。

这些场只验证terminal marginal接口。原strict质量门明确失败：mA/min mv=(15/11)^4<13<e^4=K²；high-rank及原path/history未实现。不能称原Π fixture。

## 2. capped partial near LP与精确dual

actual行列边缘η_i=ΣΓij、ζ_j=ΣΓij，质量r相同。对near N求

`max H(1), Hrow≤η, Hcol≤ζ, 0≤Hij≤C μ_iν_j 1_N`。

严格Hall缺额为

`D=max_{B,T}[η(B)+ζ(T)−r−CΣ_(B×T∩N) μ_iν_j]_+`，

最优H质量=r−D。脚本枚举最多2^(4+5)=512个有限网络cuts；这是验证固定LP证书，不是几何参数扫描。cut给row/column/edge的0/1对偶势，逐near edge核u_i+v_j+tij≥1，精确dual值与Fraction primal一致。

|阶段|矩阵|C|actual r/θ²|max H/θ²|D/θ²|
|--|--|--|--|--|--|
|基础|2×2|1|3/4|1/4|1/2|
|零marginal／不等权|3×3|1|11/12|1/12|5/6|
|扩大真实centers|4×5|2=√n|31/50|8/25|3/10|

每个H均逐项核row/column/cap，完整receiver、原始raw权、near矩阵、所有H及Hall cut、dual整数势保存于JSON。数值表没有省略θ²尺度。

## 3. 同marginal不付U；partial pullback是不同接口

标准余量填补

`H + η_res⊗ζ_res/D`

确实保持原完整row/column，但这一次completion相对raw product的最大density依次为2、6/5、10/3，均超过相应输入C。仅断言此completion的实际数值；未宣称所有completion均如此。D所代表质量仍需付款。

在固定parent/source/t下，U的记录值只依terminal v。同完整column的recoupling因此精确保持U；便宜pair-distance coupling不能降低这个U。本例取t=.5及z附近side.01微cell，cell包含在parent和全部正marginal新terminal内，于是实际几何U_j=log(mA/mvj)。Fraction先核column相等，再用Arb核actual Γ与上述完整fill的U相等。

按Astra指定构造`b(v)=ζ_H(v)/ζ(v)`，ζ=0处取0；则0≤b≤1，pullback Γ_match=b(v)Γ≤Γ，质量=H(1)，新terminal column恰为ζ_H。

三例均严格核：H全near且质量>0，而pullback Γ_match仍全far、actual near质量为0；两者的terminal-only U精确相同。这展示分析near witness没有重复支付原near事件。它在真正原P上是否保全部history由b(v)≤1的同measure限制保证；本实验没有构造原history，仅验证这一概率接口。

## 决策与停止

有限结果给出正确方向：mincut dual是near可匹配质量的**上界**，精确primal使其成为等式；不是自动控制actual U的transport上界。partial匹配可经second-marginal pullback保持原flow资格，但正Hall缺额及其整体价格未解决。

复现／归档：`r445_numeric.py`、`r445_numeric_certificate.json`、`r445_numeric_run.txt`、`r445_numeric_resources.txt`、本稿和`r445_compute_index.md`，均向脚本自身目录读写。实际仅3 LP，无作者代码依赖。交付停止。
