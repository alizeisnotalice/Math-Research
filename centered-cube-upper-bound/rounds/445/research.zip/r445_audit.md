# R445 independent final audit

FINAL PASS（限定范围）：通过连续容量 partial matching 的可测实现、原流 second-marginal 拉回、matched 质量的根阶来源价及本轮精确缺额分解。不认证 integrated Hall deficiency 的 W 预算、固定匹配比例、完整 U 上界或一般根阶弱型闭合。无实质修复项；以下绑定当前冻结字节。

## 1. 分析证明与原历史

独立 PRE 先于作者阅读形成。后审确认标准 Borel、有限可测进入量和联合有限容量下，递增有限生成分割的 cut 值单调趋向全 cut 值；所用逼近是相对于每 fiber 的实际边缘和容量边缘的有限测度逼近，不假设 selector 连续或几何边界零测。有限最优 LP 可固定规则可测选取。分块提升尚仅满足粗边缘约束，作者明确保留这一点；联合有限容量上的 [0,1] 密度弱*子列，以固定生成格及所有 ξ 测试恢复真实边缘支配。总质量极限及逐 fiber 弱 cut 界共同给几乎处处最优性。此为本稿证明，不靠有限算例代替连续 max-flow 等式。

Γ 是同一原完整记录的推前，raw μ、ν 是带 own-low/strict masscut 的 ρ/h 帽测度，非概率。原 initial-active 条件及 whole-terminal 核、未过滤双路径条件独立仅用于正上放；保留后的联合律未被重新独立化。容量的联合有限性由真实匹配 estimate (8) 直接给出，非循环调用最优 H。

H₂≤ζ，故 b(ξ,v)=dH₂/dζ 可在联合标准 Borel 测度上取可测版本。bP 是原 P 的正限制，全部 history/源/阶段/时钟仍在；辅助近 pair 不转授给原 old terminal。固定 ξ 后 signed U integrand 仅依 new-v，H₂ 的支配保证其绝对可积性及拉回相应积分相等。残余产品 completion 仅保边缘，未声称 raw cap 或原联合历史。

## 2. 常数与完整母账

near 事件包含于 w∈α₀Q_v 或 v∈α₀Q_w，α₀ⁿ=K²。真实双捕获 Tonelli 和 m=f(Q) 给 raw union 矩 ≤2/q²；ρ/h 两帽精确带入 h⁻²，原 stage/source 帽 S 只收一次。因此 matched≤2CSε₀²X/s²。核 X=σ(E)=∫q_A dA，非常阈值 q|E|；完整匹配及含 b 基底的真实边长 layercake 给 X≤A_nW，无 r 损失。C=√n、A_n≤s² 得 matched≤2Sε₀²√nW。

弱 cut 方向为原 unmatched≥每个 cut deficit；连续极限另外证明最优等式，未反向套用弱 cut。R=matched+∫dξdΛ 精确；集成缺额保原 ξ 依赖，未获全局上界。原母账中的 64Λ₀Fhat R433 只能替为 128Λ₀Fhat Sε₀²√nW+64Λ₀Fhat∫dξdΛ；其余槽不动、旧 near 不重复收费。主稿表述与此一致。

## 3. 实际复现与范围

指定独立环境 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 在新目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r445_audit_isolated_n6ogb64e` 实际运行白名单三个 Python 脚本，三份 stdout 逐字节匹配，numeric JSON 逐字节匹配。未改作者代码或输出。

geometry：3 Fraction coupling/cut/pullback 模型；mainproof：3 retention 表×4 capacity×16 cut=192 比较，非均匀 full-f 一维真实中心块；numeric：3 小 HiGHS 候选分别经 Fraction primal/cap/marginal 与全部有限 cut/整数 dual 验证，Arb256 whole-block near 判别及 terminal-only U 比较。numeric 真实 pair 量保 θ²，不混 raw 帽与概率。其 n=4 原 K² mass-gap 明确失败，未实现原 high-rank/history；辅助一维 near 参数亦仅接口诊断。原模型不能作为完整 P 非空证书。资源文件记录原实际运行，本次复现不添加模型覆盖或改写资源耗用。PRE 临时算术仅审查辅助，不计正式样本。

## 4. SHA256 byte bindings

- `r445_main.md`: `358282a55bf2aabb9a42363ce6b989aa7cdaa4316331879da40f03430c0cddb7`
- `r445_geometry.md`: `989eb60949985ab6d3e9192a3b9ab92ce31d0411d845f3b505c318b0f84e23db`
- `r445_geometry_check.py`: `599086d2f2de9de22f3b67d5b597091c696dc03962a5ce1006c3c200859bbcb7`
- `r445_geometry.result.txt`: `0f9f058150c1f525fbd27346b9bd987758a788333e7678503a74c701ab32c1d4`
- `r445_mainproof.md`: `be0a97b14e1f8f0171a3e849d4fd2214155c362055e71bcc08cfe73bab764718`
- `r445_mainproof_check.py`: `e7c7aa18c6f75c08dfd6dc274908019c39594a5dce8b6e70ce0f6abb85703357`
- `r445_mainproof.result.txt`: `35b09e795c4c2717988b0bddb4adca7e972d2f75e51886c28bde57153e4611a8`
- `r445_numeric.md`: `3c98bbb6d620b7e5e17990ee0e98f9df941d5a32a832af30bf96e8363785307f`
- `r445_numeric.py`: `5c106897e71d5da4bebb830864cf022bb533c7a285b0ae664af53a870112bf7a`
- `r445_numeric_certificate.json`: `b70adce29c7968d7f4ba9c8d417e2784c9a21263c95b866dfd68fa94e87a9c5c`
- `r445_numeric_run.txt`: `80c8fd2f2001dd5ffc8f801ea4ab468f850a899620c176de1ef40eb7c1eed9bd`
- `r445_numeric_resources.txt`: `401ccf934440a1af7999b34df4b4abdc3c09f57c4df0a594b77fea204e40b6ae`
- `r445_compute_index.md`: `8386c59d6e6fe020bb746e6f07a67c02e9940df9075f494a8b08ea6baf6d6739`

## 5. 独立 PRE 留档

# R445 independent audit — PRE

先于读取本轮新作者证明的独立预审，非FINAL。只据R445合同、已核R443–444同一原U，核正耦合、费用方向及conditional entropy；收到root明确partial-near候选后再独立核其cut方向。只写本文件，无repo/他人编辑、无新agent，不认证尚未证明的deficiency来源预算。

使用D01技能的模型/方向守卫，已读SKILL.md及provenance、cube-interface。未调用其中向量KR、过程存在性、一般强对偶或达值定理；下面弱对偶/测度推导均直接展开。

## 1. 正耦合的最低合同与费用方向

将原完整记录边缘记b(dξ)，保父、旧新来源、clip t及必要clock/stage标签；原实际路径子核Pξ不归一，其进入质量mξ≤1，R=∫mξ db。任何辅助正coupling须声明：

- 第一投影是哪一份真实原测度（含进入量），第二投影具体受哪一个真实receiver测度控制；总质量匹配。丢失质量送墓地并另记原费用，不把subprob重新归一。
- 所有receiver均为原E中同一选定cube，m=f(Q)、q-band及真source capture逐原记录有效。平移/扩大几何集合不产生新actual receiver。
- 新receiver若只作analysis变量，不授予旧路径history；若声称生成新的原流，必须另证完整路径、因果与全部current/future门可实现。保一维边缘不保完整history。
- σ(dv)π_v(dx)=q_v f(x)ρ_x(dv)dx，ρ_x=c_v(x)dv/m_v。更换du、σ或ρ参考时保q因子，不能凭名字互换可逆测度。

对原正成本的OT最小化，便宜可行plan给最小值的上界、通常是actual-plan成本的下界方向。φ+ψ≤cost也给下界；不能拿它上界actual P。上界可来自显式recoupling第一投影为P、已付转移差，或在actual support上的cost≤φ+ψ及有价边缘势。若调用强对偶/optimizer存在性须另证其条件。

对改变新终端v→v′的analysis耦合，原U的逐记录差精确是

 F(A,v,z,t)−F(A,v′,z,t)
 =log[(B_vC(t)/m_v)/(B_v′C(t)/m_v′)]。

所以便宜的新terminal成本只有在该正差及aux成本分别可积且有价时才给原U上界。任意f可在边界集中，不可只凭中心距离替代真实clipped capture比。杀死小概率也不自动付其U成本；U没有仅由该概率给出的统一上界。若转为直接付原R质量，则须明确记相应母账费用。

## 2. 一个保U且不刷新history的合法特例

收到root的partial-near候选后，先固定ξ=(e,A,y,z,t)（及需要的原进入标签）。此时U integrand只依新终端v，不依旧终端w。原条件终端joint γξ(dw,dv)是质量mξ的子概率；两边缘μξ、ζξ总质量相同mξ。

任何新正coupling具有同样new-v边缘ζξ时，可在原完整P上附其对ζξ的旧辅助terminal kernel；原w与全部history仍留在记录中，辅助ŵ不获原路径资格。新v没有改变，故R和U均精确保留。这个特例不需要支付v→v′转移差，但也不能声称新pair保全部旧joint事件。

若只取partial Hξ，row≤μξ、col≤ζξ，令φξ(v)=d(Hξ)_2/dζξ∈[0,1]，则
 P_match=φξ(v)P
是真实原P的正分数，质量等于∫Hξ(1)db，所有原history保留。辅助near pair只是分析证书，不能说原far pair变成near。其补集仍是原P上的1−φ，未丢进入量。

要由Hξ≤C aξ⊗bξ·1_near得匹配质量来源价，须另外核aξ、bξ来自同记录、保初始own-active的原unfiltered法或另明示的finite参考，且各自≤ρ_source/h；初始inactive Dirac不受此帽。共同父、真实source π_A、两个masscut<K^−2和原stage一次S也必须保留。原终端marginal支持给partial H同样masscut。

在这些已证合同下，R427真实matching的near raw价给
 ∫Hξ(1)db≤2CS ε0²X/s²。
核原R444§1及R413§1，X始终为σ(E)=∫q_A dA，不是常阈值q|E|。完整匹配给X=∫f(z)∫c_A(z)R_A^{-n}dA dz。真实selector层饼R_A^{-n}=b^{-n}+∫_{R_A}^b n t^{-n-1}dt，固定z的捕获且R_A≤t中心域体积≤t^n，故内积分≤1+nlog(b/a)=A_n；即X≤A_nW，无r。取C=√n及A_n≤s²，matched价收紧为≤2Sε0²√nW。此价仅证明matched原质量有上界；不保证匹配正比例、非空或补集有根阶价，也不支付U_match的未控log值。真正全R结论仍须控制unmatched deficiency。

## 3. Partial-near cut的正确方向与连续极限条件

设capacity测度cξ=C aξ⊗bξ 1_near。任意可行Hξ≤cξ、两边缘≤μξ、ζξ，对任意可测E,F有

 mξ−Hξ(1)≥[μξ(E)+ζξ(F)−mξ−cξ(E×F)]_+。

证明只把H拆为E×F、E×F^c和E^c×全域三块。因此weak cut是deficiency的下界，不能单凭它上界原unmatched。有限bipartite max-flow/min-cut可给等式；连续情形须明列条件及极限，不能只写formal Hall。

一个可审核的连续实现方案是：ξ、E取标准Borel版本，b有限，cξ可测finite kernel且∫cξ(1)db<∞，μξ、ζξ可测等质量finite kernel。选固定递增countable生成分割，各有限aggregate LP值F_N(ξ)可测并递减。最优表用cellwise density0≤f_N≤1写在cξ上；它只满足coarse marginals，不是已合法的连续flow。

在联合finite measure b(dξ)cξ(dw,dv)的L∞单位球取weak-*极限（标准Borel finite measure的L1可分）。用生成cell及ξ侧可测测试保所有row/col约束，得到实际可测H≤c。有限值单调极限和总质量的连续性给Hξ(1)=lim_N F_N(ξ)于b-a.e。结合weak cut及有限cut值，才可推出

 dξ:=mξ−Fmax,ξ
 =sup_{E,F}[μξ(E)+ζξ(F)−mξ−cξ(E×F)]_+。

这是条件化measure lemma的证明路线，不是几何deficiency预算。若只保finite approximations，其d_N↑d，单个小d_N不构成d的上界；还须有统一all-cut估计或定量误差。若不提供上述joint-kernel紧性/选择证明，可先只使用显式可测可行H，不能宣称其为最大或用cut等式代替构造。C及reference kernel若不uniform finite，要额外核∫c db有限或另作有价截断。

## 4. 允许的conditional entropy改变

保持同一真实进入边缘m(dr)，若P_r≪Q_r且两者为概率，对实际cost有条件Gibbs

 ∫cost dP≤τ∫m(dr)D(P_r||Q_r)+τ∫m(dr)log E_Qr exp(cost/τ)。

进入量不能丢；指数矩必须在明确Q上证明。若用finite不同总质量参考，可用相应非归一Ent公式，但归一常数不能省略。

R442的retention价格仅对已证明P=F原base、0≤F≤1成立。任意新的便宜recoupled参考Q未必支配P；AC失败可使KL=∞。完整clock/history含来源确定函数时也不能自动断言对“source×history”产品AC。若另证P_r≤L_r Q_r，可得KL≤logL_r，但原加权logL费用仍须结算。不能把新Q的后验取成clippedmass/静态Bayes而沿用旧hist价格。

partial recoupling若保new-v边缘，根本不需改变原source/path law或承担一个虚构entropy折扣；KL只可用于实际声明的共同reference。其auxiliary pair事件不向原路径转授near/history。

## 5. 实际工具与停止范围

指定math-research-tools Python实际核：Fraction两态同边缘plan，actual antidiagonal成本1、cheap diagonal成本0，只示弱对偶方向，不是本题几何反例；SymPy核同记录terminal转移差残差0。另3个quarter-unit有限partial-flow配置枚举全部可行流与cuts，deficiency分别0、3/4、0，与finite cut等式一致。均仅审查辅助，不纳正式原生/history覆盖；未做扫描或优化器试验。

PRE结论：同ξ保new-v边缘的partial recoupling是合法建设性接口，可把一个near容量证书转成原far流的正质量分数并保history；其cut方向、可测极限及真实reference帽必须独立证明。matched根价不等于完整R或U预算，unmatched deficiency的真实W价当前仍未证。至此停止，等待冻结作者证明和root整合后再FINAL。
