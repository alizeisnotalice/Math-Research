# R445：共同重配的真实邻域切割；未得全缺额付款

本稿只核一条互补机制。共同重配可以保持同一原流的新终端边缘，从而保持 \(U\) 和 \(R\)；但缺额需要实际的终端邻域下覆盖，现有上容量不能代替它。未证明一般缺额的来源预算，未新增母账费用。

## 1. 原边缘与合法分析计划

固定原标签 \(\xi=(e,A,y,z,t)\)，并保该标签下原完整记录推前后的终端二元次测度 \(\Gamma_\xi\)。原其他 history、current、early、future 权仍在此测度中，不重新生成。记两实际边缘
\[
 \eta_\xi=(\Gamma_\xi)_w,\qquad \zeta_\xi=(\Gamma_\xi)_v,\qquad
 r_\xi=\eta_\xi(E)=\zeta_\xi(E).
\]
已证 whole-terminal 支配提供真实参考测度
\[
 \mu_\xi(dw)=1_{\rm ownlow}(w,y)c_w(y)\frac{dw}{h\,m_w},
 \quad
 \nu_\xi(dv)=1_{\rm ownlow}(v,z)c_v(z)\frac{dv}{h\,m_v},
 \quad \Gamma_\xi\le\mu_\xi\otimes\nu_\xi.
\tag{1}
\]
可保原已确认的单端质量与几何支持。这里的 \(\mu_\xi,\nu_\xi\) 是帽测度，**不冒称概率**，也不把过滤后的两边缘说成独立。

令 \(N_\alpha\) 为真实中心关系
\[
 N_\alpha=\{(w,v):2\|w-v\|_\infty
                         \le\alpha\max(R_w,R_v)\}.
\]
对一个实际可测 partial plan
\[
 H_\xi\le C\,1_{N_\alpha}\mu_\xi\otimes\nu_\xi,\quad
 (H_\xi)_w\le\eta_\xi,\quad(H_\xi)_v\le\zeta_\xi,
\tag{2}
\]
记 \(D_\xi=r_\xi-H_\xi(E^2)\)。当 \(D_\xi>0\)，用
\[
 \frac{[\eta_\xi-(H_\xi)_w]\otimes
        [\zeta_\xi-(H_\xi)_v]}{D_\xi}
\tag{3}
\]
补全，零缺额时不补。得到的分析计划保持两个实际边缘、质量 \(r_\xi\)，故在同一原标签基测度上保持 \(R\) 及只依赖 \((\xi,v)\) 的原 \(U\)。
这不表示重配后的 pair 有原联合历史资格，也不表示 (3) 有 \(C\mu_\xi\otimes\nu_\xi\) 帽。可支付的是 (2)；(3) 的全部 \(D_\xi\) 必须保留。可测最大流的存在与正式 matched 收据由本轮主几何稿独立处理，本稿不重复宣称连续强对偶。

## 2. 一个必要的真实 center-neighborhood 比较

对任意可测接收集合 \(B,T\)，每个 (2) 都满足
\[
 \boxed{D_\xi\ge
 [\,\eta_\xi(B)+\zeta_\xi(T)-r_\xi
 -C(\mu_\xi\otimes\nu_\xi)(N_\alpha\cap B\times T)\,]_+.}
\tag{4}
\]
证明：\(H_\xi(B,T)\ge(H_\xi)_w(B)+(H_\xi)_v(T)-|H_\xi|\)；
两边缘删去的质量各不超过 \(D_\xi\)，且 \(|H_\xi|=r_\xi-D_\xi\)。
再用 (2) 上界交叉块即得 (4)。这只是弱切割约束，不依赖任何强对偶。

特别，令 \(\mathcal N_\alpha(B)\) 是 \(B\) 的真实中心邻域，取
\(T=E\setminus\mathcal N_\alpha(B)\)，则容量项为零：
\[
 \boxed{D_\xi\ge
 [\,\eta_\xi(B)-\zeta_\xi(\mathcal N_\alpha(B))\,]_+.}
\tag{5}
\]
可用 Borel 集及其普遍可测邻域，或先用有限中心块；所有结论均在相应完成测度下使用。若不采用投影可测性，也可直接对任意满足
\((\mu_\xi\otimes\nu_\xi)(N_\alpha\cap B\times T)=0\)
的可测 \(B,T\) 使用 (4)，无需定义投影集合。

因此，一般 \(W\) 级缺额预算至少需要控制**实际保留边缘**在邻域切割上的失衡。它不是单纯原始几何体积小：
matching、low-common、原帽 (1) 主要给上界，不能由这些上界反向推出
\(\zeta_\xi(\mathcal N_\alpha(B))\) 足够大。
也不能因为 \(\Gamma_\xi\) 存在，就断言它在 \(N_\alpha\) 上有足够质量。

问题尤其在于 \(B=B_\xi\) 可以依赖原父、双来源、level 及实际保留边缘。
固定源无关集合 \(B\) 的真匹配恒等式
\[
 \int f(x)\!\left[\int_B c_w(x)\frac{dw}{m_w}\right]dx=|B|
\tag{6}
\]
不能用于删除这样的依来源切割。在依来源版本中，正确右侧是
\[
 \int\frac{dw}{m_w}\int_{Q_w}f(x)1_{\{w\in B_x\}}dx,
\]
而 \(B_\xi\) 还带父、另一来源及其他权。原 low-common 亦必须保留
\(c_b(y)c_b(z)\) 与严格质量门，不能补造未捕获旧来源的因子。
本稿没有给这些实际切割的全局平均预算；故不把 (5) 本身称为新付款或充分条件。

Pair 常数的另一限制沿用 R444：\(\log\psi(A,w,v)\) 在 cell Gibbs 测试的期望与 log-normalizer 中精确相消，不能用它直接支付缺额或移除距离权。这里需要的是新邻域边缘比较，而非调整这个常数测试。

## 3. 独立 source-cell 候选的短结论

用同一完整 \(f\) 定义 terminal 在父外、但仍处于格 \(C\) 的实际质量
\[
 d_C(t)=\int_{C\cap(Q_v\setminus Q_A)}\min(f,t),\qquad D_C=d_C(\infty).
\]
有 \(Y_C\le X_C+d_C\)，所以 R444 的真实量满足
\[
 p_Cr_C=\frac1{m_v}\int c'_C c_CY_C/X_C
 \le\frac1{m_v}\left(\frac{u_C^2}{2}+\int c'_Cd_C\right)
 \le\frac{u_C^2/2+u_CD_C}{m_v}.
\]
只求 \(u_C>0\) 的格，Cauchy 给
\[
 Q\le\frac{u(u/2+D_{\rm hit})}{m_v},
 \qquad D_{\rm hit}=\sum_{u_C>0}D_C.
\tag{7}
\]
这是实际来源质量余量，不是边界体积帽。它保留真实
\(\ell=\log(m_A/m_v)\)：
\[
 m_AQ/u^2\le e^\ell(1/2+D_{\rm hit}/u).
\]
即使 \(D_{\rm hit}=0\)，质量比项仍然完整存在；未建立 (7) 到全缺额或完整 \(U\) 的新预算。因此不继续扩展这条局部比较，不把它计入母账。

## 4. 本机检查及证据级别

`/tmp/r445_mainproof_check.py` 使用完整非均匀来源
\(f=1_{[-4,4]}+1_{[-1/10,1/10]}\)，真实正长度 center 块、真实边长和由来源交集计算的匹配质量。两端各用两个块，其中一个为相同的实际接收块；共有三个不同的终端块（边长 1）。父 center 块 \([9/20,23/50]\)（边长 2）与它们不交，因而是同一个单值边长选择器。块内 near 关系恒定，原二元次测度用三种保留表构造。对四个容量参数逐个枚举有限切割，核 (4) 的方向、(5)、可行 partial plan 和剩余边缘补全；没有用来源体积代替质量。

这仅为切割/重配接口诊断：维数 1，未满足或声称原高维 \(K^2\)、高秩、双路径及完整历史资格；不是全局目标的反例。一般结论是 §§1–2 的测度论计算。未得全缺额来源付款，交付后停止。

实际 Fraction 运行：两端帽质量分别为 \((1/24,1/24)\)、\((1/24,1/20)\)，三张保留表的总质量为 \(11/1440,31/5760,11/2880\)。三表、四个容量、每个 16 种切割共 192 个精确比较全部通过，partial plan 与补全边缘也逐个相等。输出 `/tmp/r445_mainproof.result.txt`；计数只说明这组有限接口核验，不表示原合同覆盖。
