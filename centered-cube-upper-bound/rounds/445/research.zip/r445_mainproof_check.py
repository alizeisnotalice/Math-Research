"""Actual continuous center blocks; bounded cut/recoupling diagnostics only."""
from fractions import Fraction as F
from itertools import product


def overlap(a, b, c, d):
    return max(F(0), min(b, d)-max(a, c))


def mass(center, side):
    lo, hi = center-side/2, center+side/2
    return overlap(lo, hi, F(-4), F(4)) + overlap(lo, hi, -F(1,10), F(1,10))


# Centers are genuine intervals; f-mass is constant across each block.
old = [(-F(2,5), -F(7,20)), (F(7,20), F(2,5))]
new = [(F(7,20), F(2,5)), (F(23,20), F(6,5))]
side = F(1)
y, z = F(0), F(4,5)
for blocks, source in [(old, y), (new, z)]:
    for lo, hi in blocks:
        assert abs(source-lo) <= side/2 and abs(source-hi) <= side/2
        assert lo-side/2 >= -4 and hi+side/2 <= 4
        full_spike = hi-side/2 <= -F(1,10) and lo+side/2 >= F(1,10)
        no_spike = lo-side/2 >= F(1,10) or hi+side/2 <= -F(1,10)
        assert full_spike or no_spike  # constant mass throughout the block
        assert mass(lo, side) == mass(hi, side)
        assert F(1) <= mass(lo, side)/side <= F(6,5)
# Parent also has positive center interval, side 2, matched q=11/10.
for center in [F(9,20), F(23,50)]:
    assert mass(center, F(2)) == F(11,5)
    assert abs(center-y) <= 1 and abs(center-z) <= 1
assert F(9,20) > max(b for a, b in old)
assert F(23,50) < new[1][0]  # parent-side-2 selector block is disjoint

mu = [(hi-lo)/mass(lo, side) for lo, hi in old]
nu = [(hi-lo)/mass(lo, side) for lo, hi in new]
near = [[False, False], [True, False]]
for i, (a, b) in enumerate(old):
    for j, (c, d) in enumerate(new):
        maxdist = max(abs(x-v) for x, v in product([a,b], [c,d]))
        mindist = max(F(0), c-b, a-d)
        if near[i][j]:
            assert 2*maxdist <= 1
        else:
            assert 2*mindist > 1
print("PASS native matching and near relation:", mu, nu)

tables = [
    [[F(1), F(1)], [F(1), F(1)]],
    [[F(1), F(1,3)], [F(1,2), F(1)]],
    [[F(0), F(1)], [F(1), F(0)]],
]
subsets = [(), (0,), (1,), (0,1)]
checked = 0
for number, retention in enumerate(tables, 1):
    gamma = [[mu[i]*nu[j]*retention[i][j] for j in range(2)] for i in range(2)]
    eta = [sum(row) for row in gamma]
    zeta = [sum(gamma[i][j] for i in range(2)) for j in range(2)]
    total = sum(eta)
    for cap in [F(1,2), F(1), F(2), F(4)]:
        # Only near block is (old right,new left). Its feasible maximum is explicit.
        kept = min(eta[1], zeta[0], cap*mu[1]*nu[0])
        deficiency = total-kept
        maximum_cut = F(0)
        for B, T in product(subsets, repeat=2):
            cross = cap*sum(mu[i]*nu[j] for i in B for j in T if near[i][j])
            cut = max(F(0), sum(eta[i] for i in B)+sum(zeta[j] for j in T)-total-cross)
            assert cut <= deficiency
            maximum_cut = max(maximum_cut, cut)
            checked += 1
        assert maximum_cut == deficiency
        # B=old-left has empty true new-center neighborhood.
        assert deficiency >= eta[0]
        er = [eta[0], eta[1]-kept]
        zr = [zeta[0]-kept, zeta[1]]
        if deficiency:
            refill = [[er[i]*zr[j]/deficiency for j in range(2)] for i in range(2)]
            assert [sum(row) for row in refill] == er
            assert [sum(refill[i][j] for i in range(2)) for j in range(2)] == zr
        else:
            assert er == zr == [0,0]
    print(f"PASS retention table {number}: original mass={total}; all four capacities")
print(f"PASS {checked} exact finite cut comparisons; partial-flow and refill marginals exact.")
print("Scope: continuous nonuniform-f center blocks, not high-dimensional mass-gap/history.")
