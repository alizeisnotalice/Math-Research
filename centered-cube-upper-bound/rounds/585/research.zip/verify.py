#!/usr/bin/env python3
"""Self-contained R585 algebra checks; no geometry, transport, or LP solver."""
import argparse
from fractions import Fraction as F
import hashlib
import itertools
import json
from pathlib import Path
import platform
import shlex
import sys
import sympy as s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path, default=Path(__file__).with_suffix('.json'))
    args = ap.parse_args()
    W, a, b = s.symbols('W a b', real=True)
    matrices = {
        'a_le_b': s.Matrix([[a, 0], [b-a, W-b]]),
        'b_le_a': s.Matrix([[b, a-b], [0, W-a]])}
    coupling = {}
    for branch, mat in matrices.items():
        residuals = [s.expand(sum(mat.row(i))-v) for i,v in enumerate([a,W-a])]
        residuals += [s.expand(sum(mat.col(i))-v) for i,v in enumerate([b,W-b])]
        residuals += [s.expand(sum(mat)-W), s.expand(mat[0,0]-(a if branch=='a_le_b' else b))]
        assert all(x == 0 for x in residuals)
        coupling[branch] = {'matrix': [[str(mat[i,j]) for j in range(2)] for i in range(2)],
                            'six_symbolic_residuals': list(map(str,residuals))}
    finite_couplings = 0
    for w in range(1,9):
        for aa in [F(i,2) for i in range(2*w+1)]:
            for bb in [F(i,2) for i in range(2*w+1)]:
                q = min(aa,bb)
                mat = [[q,aa-q],[bb-q,F(w)-aa-bb+q]]
                assert all(t >= 0 for row in mat for t in row)
                assert [sum(row) for row in mat] == [aa,w-aa]
                assert [sum(mat[i][j] for i in range(2)) for j in range(2)] == [bb,w-bb]
                finite_couplings += 1

    x,y = s.symbols('x y', real=True)
    induction = s.expand((1-x)*(1-y)-(1-x-y))
    assert induction == x*y
    t = s.symbols('t', integer=True, nonnegative=True)
    eps_infinite = s.summation(s.Rational(1,4)*s.Rational(1,2)**t,(t,0,s.oo))
    assert eps_infinite == s.Rational(1,2)
    product, epssum = F(1), F(0)
    recursion = []
    for d in range(65):
        assert epssum == F(1,2)*(1-F(1,2**d))
        assert product >= 1-epssum >= F(1,2)
        recursion.append({'depth':d,'product':str(product),'eps_sum':str(epssum),
                          'product_minus_one_minus_sum':str(product-(1-epssum))})
        eps=F(1,2**(d+2))
        product *= 1-eps
        epssum += eps

    # Positions index (x,xprime,z,zprime); symbolic positive gaps certify
    # every strict order, not merely equally spaced endpoint examples.
    gaps=s.symbols('g0:3', positive=True)
    ranks=[s.Integer(0),gaps[0],gaps[0]+gaps[1],sum(gaps)]
    strict_orders=[]
    for perm in itertools.permutations(range(4)):
        pos={label:rank for rank,label in enumerate(perm)}
        def dist(i,j):
            return ranks[max(pos[i],pos[j])]-ranks[min(pos[i],pos[j])]
        lhs=dist(0,3)+dist(1,2)-dist(0,2)-dist(1,3)
        left=max(min(pos[0],pos[1]),min(pos[2],pos[3]))
        right=min(max(pos[0],pos[1]),max(pos[2],pos[3]))
        overlap=ranks[right]-ranks[left] if right>left else s.Integer(0)
        sign=1 if (pos[1]-pos[0])*(pos[3]-pos[2])>0 else -1
        residual=s.expand(lhs-2*sign*overlap)
        assert residual == 0
        strict_orders.append({'labels_left_to_right':list(perm),'residual':str(residual)})
    def sg(v): return int(v>0)-int(v<0)
    rational_count=0
    for xx,xp,zz,zp in itertools.product([F(-1),F(-1,2),F(0),F(1,2),F(1)],repeat=4):
        lhs=abs(xx-zp)+abs(xp-zz)-abs(xx-zz)-abs(xp-zp)
        overlap=max(F(0), min(max(xx,xp),max(zz,zp))-max(min(xx,xp),min(zz,zp)))
        assert lhs == 2*sg((xp-xx)*(zp-zz))*overlap
        rational_count+=1
    cancellation_terms=[]
    for xx,xp,zz,zp in [(F(0),F(3),F(1),F(4)),(F(0),F(3),F(4),F(1))]:
        cancellation_terms.append(abs(xx-zp)+abs(xp-zz)-abs(xx-zz)-abs(xp-zp))
    assert cancellation_terms == [F(4),F(-4)]

    # Three arbitrary disjoint receiver pieces: pK+p(S\K)+p(outside S)=1.
    # Symbols represent their integrated masses, so no constant density or
    # cell-constant optimal allocation assumption is introduced.
    lam,H,out=s.symbols('lambda H outside_volume', positive=True)
    ik=s.symbols('inside_core0:3', nonnegative=True)
    ip=s.symbols('inside_parent_noncore0:3', nonnegative=True)
    io=s.symbols('inside_outside_parent0:3', nonnegative=True)
    v=lam*(out+sum(ik)+sum(ip)+sum(io))
    Q=lam/H*sum(ik)
    remainder=lam*out+lam*sum(ip)+lam*sum(io)
    remainder_residual=s.expand(v-H*Q-remainder)
    assert remainder_residual == 0
    Hh,mm,rr=s.symbols('H m r', positive=True)
    leakage_residual=s.expand(Hh*(mm-rr/Hh)-(Hh*mm-rr))
    assert leakage_residual == 0
    outdata={
      'scope':'Symbolic identities and explicitly finite exact rational checks only; no geometric return, OT optimality, LP, or general budget certificate.',
      'evidence_levels':{'coupling':'symbolic marginal identities; nonnegativity also checked on stated finite rational grid; general branch nonnegativity follows from 0<=a,b<=W and branch ordering',
                         'product':'symbolic induction remainder and infinite geometric sum, plus finite Fraction recursion',
                         'L1':'all 24 strict endpoint orders symbolically with arbitrary positive gaps; 625 rational four-tuples including ties; sign >=0 requires cost optimality and is NOT asserted for arbitrary inputs',
                         'remainder':'formal coefficient identity after partitioning actual source labels into K, S minus K, and outside S; no estimate for any term'},
      'coupling':coupling,
      'finite_coupling_grid':{'W_integers':[1,8],'a_b_step':'1/2','range':'0<=a,b<=W','checks':finite_couplings},
      'density_recursion':{'induction_remainder':str(induction),'infinite_eps_sum':str(eps_infinite),'depths':recursion},
      'L1':{'strict_orders':strict_orders,'rational_endpoint_grid':['-1','-1/2','0','1/2','1'],'rational_checks':rational_count,
            'two_coordinate_cancellation':list(map(str,cancellation_terms)),'cancellation_sum':str(sum(cancellation_terms))},
      'full_remainder':{'receiver_piece_count':3,'residual':str(remainder_residual),'leakage_residual':str(leakage_residual),
                        'terms':['lambda * |A minus R|','lambda integral_(A intersect R) p_(S minus K)','lambda integral_(A intersect R) p_(outside S)'],
                        'coefficients_after_v_minus_HQ':{'outside_volume':'lambda','inside_core':'0','inside_parent_noncore':'lambda','inside_outside_parent':'lambda'}},
      'execution':{'interpreter':sys.executable,'python':platform.python_version(),'sympy':s.__version__,
                   'command':shlex.join([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]]),
                   'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
      'all_assertions_passed':True,'arithmetic_error':'0 (exact SymPy/Fraction); no floating computation'}
    args.output.write_text(json.dumps(outdata,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'output':str(args.output),'finite_couplings':finite_couplings,'strict_L1_orders':len(strict_orders),'rational_L1_checks':rational_count,'recursion_depths':len(recursion),'all_assertions_passed':True}))

if __name__=='__main__':
    main()
