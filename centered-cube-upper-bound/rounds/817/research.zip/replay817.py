"""Replay the scope checks for round 817; requires python-flint and the round 814 archive."""
import argparse
import hashlib
import json
import zipfile
import math
from fractions import Fraction
from pathlib import Path
import subprocess
import sys

import flint
from flint import arb, ctx

HERE = Path(__file__).resolve().parent
DIMS = (10, 16, 20, 32, 50, 80, 160)
DISTANCES = (1, 8, 24)
HISTORICAL = (1, 2, 4, 160)
EXPECTED_ROOTS = (
    "g= 25/16 eligible original weighted mass= 49/4 no-qualified-small-root weighted mass= 39/4",
    "g= 25/16 eligible original weighted mass= 27/4 no-qualified-small-root weighted mass= 39/2",
)


def sign(interval):
    if interval > 0:
        return 1
    if interval < 0:
        return -1
    raise ArithmeticError("undetermined sign")


def cover_checks(bits):
    """Use an explicit upper bound for log M; do not round a ball to a float."""
    ctx.prec = bits
    rows = []
    for j in DIMS:
        n = 2**j
        z = arb(n)
        w = arb(n + 2).log()
        for d in DISTANCES:
            rho = arb(d + 1).sqrt() * w / z.sqrt()
            k_upper = d * z.sqrt() / arb(d + 1).sqrt()
            logs = k_upper * (z.log() + (1 + 1 / (2 * rho)).log())
            h = 16 * z * rho + 4 * logs + 16 * w
            signs = [sign(1 - 8 * rho), sign(1 - h / z)]
            eligible = signs == [1, 1]
            if eligible:
                assert sign(1 - ((-h / z).exp() + 4 * rho)) > 0
                assert sign(-4 * w - (logs - h / 2 + 4 * z * rho)) > 0
            # D=24, R=2, A=4 used on the actual far pairs in the proof.
            u = 12 * w
            assert sign(-4 * w - (1 - u + (1 + z / u).log())) > 0
            rows.append((j, d, signs, eligible))
    history = []
    for j in HISTORICAL:
        n = 2**j
        w = arb(n + 2).log()
        original_gate = arb(n).sqrt() * w**8
        history.append((j, sign(arb(n) * arb(2).log() - original_gate)))
    return rows, history


def compare_exact_examples():
    n = 2**18
    assert 648 * n**2 < 2 ** (n // 4096)
    lost = Fraction(99 * n, 250) - 4 * math.isqrt(n) - 5
    assert lost > 0
    assert n // 1024 == 256 and n > 256 and 100 * n > 2
    assert (1 << 255) > 100
    return n, lost


def owner_menu_check(archive):
    """Bracket actual records using their two owner boxes; no independence assumption."""
    with zipfile.ZipFile(archive) as z:
        stage = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    parents = {row["id"]: row for row in stage["parents"]}
    records = []
    for row in stage["roots_cross"]:
        left = parents[row["u"]]
        right = parents[row["g"]]
        radius = max(Fraction(left["radius"]), Fraction(right["radius"]))
        axes = [tuple(map(Fraction, a + b)) for a, b in zip(left["owner"], right["owner"])]
        min_dist = max(max(Fraction(0), lo - hi2, lo2 - hi) for lo, hi, lo2, hi2 in axes)
        max_dist = max(max(hi - lo2, hi2 - lo) for lo, hi, lo2, hi2 in axes)
        assert 0 <= min_dist <= max_dist
        records.append((min_dist / radius, max_dist / radius, Fraction(row["root_mass"])))
    total = sum(mass for _, _, mass in records)
    assert len(records) == 34 and total > 0
    print("finite diagnostic for two true receivers (4D rebuilt), original cross mass:", total)
    for threshold in map(Fraction, ("1", "9/8", "3", "4", "17/4", "5")):
        certain = [mass for _, hi, mass in records if hi <= threshold]
        possible = [mass for lo, _, mass in records if lo <= threshold]
        lower, upper = sum(certain), sum(possible)
        assert 0 <= lower <= upper <= total
        if threshold <= 3:
            assert len(certain) == len(possible) == 14 and lower == upper
        if threshold == 4:
            assert (len(certain), len(possible)) == (14, 26) and lower < upper
        if threshold == 5:
            assert lower == upper == total
        print("receiver distance/radius <=", threshold, "certain, possible=",
              len(certain), len(possible), "actual weighted share in",
              str(lower / total), str(upper / total))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--r814", type=Path, required=True,
                   help="path to centered-cube-upper-bound/rounds/814/research.zip")
    args = p.parse_args()
    path = args.r814.resolve(strict=True)
    for name, options in (("future817.py", []), ("capacity817.py", ["--archive", str(path)])):
        proc = subprocess.run([sys.executable, "-B", str(HERE / name), *options],
                              check=True, capture_output=True, text=True)
        print(proc.stdout, end="")
        if name == "future817.py":
            assert all(fragment in proc.stdout for fragment in EXPECTED_ROOTS)
    owner_menu_check(path)
    result, history = cover_checks(256)
    repeat, history_repeat = cover_checks(384)
    assert (result, history) == (repeat, history_repeat)
    for d in DISTANCES:
        print(f"cover D={d}, certified eligible dimension exponents:",
              [j for j, distance, _, ok in result if d == distance and ok])
    assert history == [(1, -1), (2, -1), (4, -1), (160, 1)]
    assert all(any(ok for j, v, _, ok in result if v == d) for d in DISTANCES)
    print("huge original R813 volume gap possible by octave length, n=2^j:", history)
    n, lost = compare_exact_examples()
    print("positive L1 hole example, n=", n, "surviving rank lower bound=", lost,
          "all actual pair overlap fractions < 2^-255")
    print("ranges:", len(DIMS) * len(DISTANCES), "cover checks at each of 256 and 384 bits")
    print("upstream round 814 SHA256:", hashlib.sha256(path.read_bytes()).hexdigest())
    print("runtime:", sys.version.split()[0], "python-flint", flint.__version__,
          "FLINT", flint.__FLINT_VERSION__)
    print("PASS")


if __name__ == "__main__":
    main()
