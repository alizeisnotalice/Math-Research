"""Exact 2D atomic final-root and same-source checks; no sampling.

At each open rectangle, capture sets at all rational candidate roots are
constant. Source-root allocations retain true area, t^2 denominator and atom
weights. End-point rank loss is computed on the same allocation rows.
"""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product

LAM = F(100)
ROOTS = (F(3, 10), F(2, 5), F(1, 2))
G = F(25, 16)
T = F(1, 100)
LCUT = 2 * T + 2


def mass(atoms, center, t):
    return sum(
        w
        for x, y, w in atoms
        if abs(x - center[0]) < t / 2 and abs(y - center[1]) < t / 2
    )


def build_rows(atoms):
    cuts = [set(), set()]
    for t in ROOTS:
        for x, y, _ in atoms:
            for i, coord in enumerate((x, y)):
                cuts[i].update((coord - t / 2, coord + t / 2))
    xs, ys = (sorted(c) for c in cuts)
    rows = []
    for (x0, x1), (y0, y1) in product(zip(xs, xs[1:]), zip(ys, ys[1:])):
        center = ((x0 + x1) / 2, (y0 + y1) / 2)
        roots = [t for t in ROOTS if mass(atoms, center, t) == LAM * t * t]
        if not roots:
            continue
        t = max(roots)
        captured = tuple(
            i
            for i, (x, y, _) in enumerate(atoms)
            if abs(x - center[0]) < t / 2 and abs(y - center[1]) < t / 2
        )
        assert sum(atoms[i][2] for i in captured) == LAM * t * t
        assert mass(atoms, center, F(1)) < LAM
        rows.append(
            {
                "bounds": (x0, x1, y0, y1),
                "area": (x1 - x0) * (y1 - y0),
                "t": t,
                "captured": captured,
            }
        )
    return rows


def run(name, atoms):
    rows = build_rows(atoms)
    by_source = defaultdict(list)
    for row in rows:
        for p in row["captured"]:
            by_source[p].append(row)
    physical_area = sum(row["area"] for row in rows)
    allocation = sum(
        atoms[p][2] * row["area"] / row["t"] ** 2
        for p in by_source
        for row in by_source[p]
    )
    assert allocation == LAM * physical_area
    print(
        "\nCASE",
        name,
        "F_area=",
        physical_area,
        "source_allocation=",
        allocation,
        "rows=",
        len(rows),
    )
    same_price_pairs = sum(
        1
        for p, source_rows in by_source.items()
        for i, a in enumerate(source_rows)
        for b in source_rows[i + 1 :]
        if a["t"] == b["t"]
    )
    print("same-source same-price distinct receiver-cell pairs=", same_price_pairs)
    print(
        "overlap receivers captured by >1 atoms=",
        sum(len(row["captured"]) > 1 for row in rows),
    )
    assert same_price_pairs > 0
    assert any(len(row["captured"]) > 1 for row in rows)
    all_source_claims = 0
    real_eligible_mass = F(0)
    no_small_mass = F(0)
    for p, source_rows in by_source.items():
        roots = sorted(set(row["t"] for row in source_rows))
        rank_length = sum(row["area"] / row["t"] ** 2 for row in source_rows)
        retained_rank = max(F(0), rank_length - 2 * LCUT)
        lost_rank = rank_length - retained_rank
        print(
            "SOURCE",
            p,
            "weight=",
            atoms[p][2],
            "roots=",
            ",".join(map(str, roots)),
            "rank L=",
            rank_length,
            "end_cut=",
            LCUT,
            "lost=",
            lost_rank,
            "retained=",
            retained_rank,
        )
        for b in roots:
            b_rows = [row for row in source_rows if row["t"] == b]
            eligible = [a for a in roots if a < b and a * a * G <= b * b]
            b_mass = sum(atoms[p][2] * row["area"] / b**2 for row in b_rows)
            if not eligible:
                no_small_mass += b_mass
                continue
            real_eligible_mass += b_mass
            for a in eligible:
                u = (b - a) / 2
                assert a + u < 1
                pxy = atoms[p][:2]
                # For every u>=0 with a+u<1, the atom mass changes only at
                # these finitely many exact side lengths. The RHS increases.
                critical = sorted(
                    {2 * max(abs(x - pxy[0]), abs(y - pxy[1])) for x, y, _ in atoms}
                )
                for step in critical:
                    if a + step >= 1:
                        continue
                    closed_mass = sum(
                        w
                        for x, y, w in atoms
                        if abs(x - pxy[0]) <= step / 2 and abs(y - pxy[1]) <= step / 2
                    )
                    assert closed_mass <= LAM * (a + step) ** 2
                local_mass = mass(atoms, pxy, u)
                bound = LAM * (a + u) ** 2
                assert local_mass <= bound
                row_mass = sum(row["area"] / b**2 for row in b_rows)
                weighted_near = F(0)
                weighted_same_pair = F(0)
                for row in b_rows:
                    captured = row["captured"]
                    near = sum(
                        atoms[i][2]
                        for i in captured
                        if abs(atoms[i][0] - pxy[0]) < u / 2
                        and abs(atoms[i][1] - pxy[1]) < u / 2
                    )
                    assert near <= local_mass
                    probability = near / (LAM * b**2)
                    assert probability <= ((a + u) / b) ** 2
                    weighted_near += row["area"] / b**2 * probability
                    # Two independently sampled actual sources within Q_u of each other.
                    paired = sum(
                        atoms[i][2] * atoms[j][2]
                        for i in captured
                        for j in captured
                        if abs(atoms[i][0] - atoms[j][0]) < u / 2
                        and abs(atoms[i][1] - atoms[j][1]) < u / 2
                    )
                    weighted_same_pair += (
                        row["area"] / b**2 * paired / (LAM * b**2) ** 2
                    )
                    all_source_claims += 1
                print(
                    "  a,b,u=",
                    a,
                    b,
                    u,
                    "near/b=",
                    weighted_near / row_mass,
                    "future_bound=",
                    ((a + u) / b) ** 2,
                    "independent_near_pair=",
                    weighted_same_pair / row_mass,
                    "L_p^<(b)=",
                    sum(
                        row["area"] / row["t"] ** 2
                        for row in source_rows
                        if row["t"] < b
                    ),
                    "true_mu_Qu=",
                    local_mass,
                    "future_mu_bound=",
                    bound,
                )
    print(
        "g=",
        G,
        "eligible original weighted mass=",
        real_eligible_mass,
        "no-qualified-small-root weighted mass=",
        no_small_mass,
        "checked source-b-cell claims=",
        all_source_claims,
    )
    assert all_source_claims > 0
    assert real_eligible_mass + no_small_mass == allocation


cases = [
    ("overlap", [(F(0), F(0), F(9)), (F(3, 20), F(3, 20), F(16))]),
    ("distinct-root", [(F(0), F(0), F(9)), (F(7, 20), F(1, 20), F(16))]),
]
for name, atoms in cases:
    run(name, atoms)
print(
    "\nPASS: exact rational checks on specified 2D inputs; no high-dimensional inference"
)
