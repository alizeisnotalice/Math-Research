"""R817 exact rational identity, binomial bound and R814 fixture inventory.

Only Fraction and integer arithmetic are used. The R814 material is read from
its existing archive and the reported comparison retains its original scope.
"""

import argparse
import hashlib

from fractions import Fraction as F
from math import comb
from pathlib import Path
import json
import sys
import zipfile

NS = (1, 2, 3, 8, 16, 64, 128, 512)
DELTAS = (F(0), F(1, 1000), F(1, 4), F(1, 2), F(9, 10), F(999, 1000), F(1))
count = 0
for n in NS:
    for delta in DELTAS:
        p = 1 - delta
        # Exact integral of the finite polynomial after cancellation of s.
        integral = n * sum(
            (F(comb(n, k), k) * delta ** (n - k) * p**k for k in range(1, n + 1)), F(0)
        )
        # Independently form the binomial PMF and its reciprocal expectation.
        expectation = F(0)
        for k in range(1, n + 1):
            prob = F(comb(n, k)) * p**k * delta ** (n - k)
            expectation += prob / k
        expectation *= n
        assert integral == expectation
        if p:
            # 1/k <= 2/(k+1), plus the binomial integral identity.
            stronger = 2 * n * ((1 - delta ** (n + 1)) / ((n + 1) * p) - delta**n)
            assert expectation <= stronger
            assert stronger <= 2 / p
        else:
            assert expectation == 0  # 2/p is undefined at delta=1.
        count += 1
print("Python:", sys.version.split()[0])
print(
    "identity exact Fraction cases:",
    count,
    "n=",
    NS,
    "delta=",
    ",".join(map(str, DELTAS)),
)
for n, delta in [
    (1, F(0)),
    (2, F(1, 2)),
    (8, F(1, 2)),
    (512, F(1, 1000)),
    (512, F(999, 1000)),
    (512, F(1)),
]:
    p = 1 - delta
    value = n * sum(
        (F(comb(n, k), k) * delta ** (n - k) * p**k for k in range(1, n + 1)), F(0)
    )
    print(
        "example n=",
        n,
        "delta=",
        delta,
        "value~=",
        float(value),
        "bound~=",
        float(2 / p) if p else "undefined",
    )

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument(
    "--archive", type=Path, required=True, help="Path to R814 research.zip"
)
archive = parser.parse_args().archive
with zipfile.ZipFile(archive) as z:
    manifest = json.loads(z.read("MANIFEST.json"))["members"]
    for filename in (
        "mu814-original-1.json",
        "mu814-rebuilt-1.json",
        "comb814-rebuilt.json",
        "trade813.py",
    ):
        assert hashlib.sha256(z.read(filename)).hexdigest() == manifest[filename]
    fixture_reports = []
    for filename in ("mu814-original-1.json", "mu814-rebuilt-1.json"):
        report = json.loads(z.read(filename))
        assert (
            report["trade813_sha256"]
            == hashlib.sha256(z.read("trade813.py")).hexdigest()
        )
        if filename == "mu814-rebuilt-1.json":
            assert (
                report["input_sha256"]
                == hashlib.sha256(z.read("comb814-rebuilt.json")).hexdigest()
            )
        assert report["events"] == 357 and report["columns"] == 1041
        assert report["D"] == 512
        assert F(report["receiver_capacity_multiplier"]) == 1
        source_mass = F(report["original_mass"])
        print(
            "\nR814 history",
            filename,
            "one original right arm, left mark summed; M=",
            source_mass,
        )
        print(
            "Rates are saved-certificate bounds, not newly solved or a bilateral-original-arm theorem."
        )
        for result in report["results"]:
            mode = result["mode"]
            assert mode in (0, 1, 2)
            lower, upper = F(result["lower"]), F(result["upper"])
            assert 0 <= lower <= upper <= 1
            cells = result["by_right_cell"].values()
            assert sum(F(row["mass"]) for row in cells) == source_mass
            assert all(0 <= F(row["paid"]) <= F(row["mass"]) for row in cells)
            assert sum(F(row["paid"]) for row in cells) == lower * source_mass
            assert all(
                F(x) >= 0
                for x in result["dual_delta"]
                + result["dual_source"]
                + result["dual_target"]
            )
            assert (
                1
                - sum(map(F, result["dual_delta"]))
                + sum(map(F, result["dual_source"]))
                + sum(map(F, result["dual_target"]))
                == upper
            )
            label = (
                "(z,q,j) separate source budgets",
                "(q,j) shared right-source budget",
                "(q,j) shared source + two receiver slots",
            )[mode]
            print("mode", mode, label, "fraction_bounds=[", lower, ",", upper, "]")
            print(
                "paid_original_mass_bounds=[",
                lower * source_mass,
                ",",
                upper * source_mass,
                "]",
            )
            print(
                "approx fraction bounds=",
                float(lower),
                float(upper),
                "paid mass=",
                float(lower * source_mass),
                float(upper * source_mass),
            )
            print(
                "saturated source constraints=",
                result["saturated_sources"],
                "saturated receiver slots=",
                result["saturated_owner_rows"] if mode == 2 else "not imposed",
            )
            if mode == 2:
                aggregate = result["aggregated_global"]
                assert all(
                    0 <= F(value) <= 1 for value in aggregate["source_ratios"].values()
                )
                assert all(
                    0 <= F(value) <= 1
                    for side in aggregate["owner_ratios"]
                    for value in side.values()
                )
                saturated = [
                    f"{i}:{owner}"
                    for i, side in enumerate(aggregate["owner_ratios"])
                    for owner, value in side.items()
                    if F(value) == 1
                ]
                assert sorted(saturated) == sorted(result["saturated_owner_rows"])
            fixture_reports.append((filename, mode))
    assert len(fixture_reports) == 6
    print(
        "Certificate audit: member hashes, by-cell primal totals, dual objective sum and aggregate capacities checked; full columnwise dual feasibility not replayed here."
    )
    print(
        "R813 gate: J > n log(2) for n=2,4; an octave cannot have a positive long-jump sample in these dimensions."
    )
    fixture = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    cell = json.loads(z.read("cell814.json"))["rebuilt"]
    common = json.loads(z.read("common814.json"))["stages"][0]
    assert fixture["dimension"] == 4 and common["dimension"] == 2
    assert all(
        "m" in parent and "box" in parent and "volume_bin" in parent
        for parent in fixture["parents"]
    )
    assert all(
        "mass" in cell_row and "mask" in cell_row for cell_row in fixture["cells"]
    )
    assert all(
        "z_masks" in root and "q_masks" in root for root in fixture["roots_cross"]
    )
    assert sum(F(row["weight"]) for row in cell["rows"]) == F(
        cell["subflow_original_mass"]
    )
    assert len(cell["rows"]) == 58
    receivers = common["capacities"]["receivers"]
    for receiver in receivers:
        for arm in ("left", "right"):
            assert F(receiver[arm + "_after"]) <= F(receiver["Lebesgue_capacity"])
            assert receiver[arm + "_saturated"] == (
                F(receiver[arm + "_after"]) == F(receiver["Lebesgue_capacity"])
            )
    payoff = common["haloes"]["R813_gamma_zero_hn"]["payoff"]
    model = "formula_without_extra_degree"
    left = payoff["fixed_actual_q"][model]["1"]
    right = payoff["independent_true_right_fibre"][model]["1"]
    assert left["paid_original_mass"] == right["paid_original_mass"]
    assert F(left["paid_original_mass"]) == F(common["original_cross_bin_mass"]) * F(
        left["fraction"]
    )
    print(
        "R814 4D rebuilt: parents=",
        len(fixture["parents"]),
        "cells=",
        len(fixture["cells"]),
        "cross records=",
        len(fixture["roots_cross"]),
        "q=95 subflow rows=",
        len(cell["rows"]),
    )
    print(
        "R814 original 2D comparison, h_n, D=1, without extra degree, fixed-q and independent true right fibre:"
    )
    print("original cross-bin mass=", common["original_cross_bin_mass"])
    print(
        "paid original mass=",
        left["paid_original_mass"],
        "paid fraction=",
        left["fraction"],
    )
    for receiver in receivers:
        print(
            "receiver",
            receiver["owner"],
            "capacity=",
            receiver["Lebesgue_capacity"],
            "left_after=",
            receiver["left_after"],
            "right_after=",
            receiver["right_after"],
            "saturated=",
            receiver["left_saturated"],
            receiver["right_saturated"],
        )
    print(
        "Fixture has parent masses, source cells and bilateral receiver owners; it does not record R817 F as true maximal-root receiver cells and per-receiver physical final-root scales. Therefore its saved marked-parent/owner model is not silently promoted into an R817 true menu."
    )
print(
    "PASS: exact finite checks and read-only archive inventory; no R817 menu inferred from missing fields"
)
