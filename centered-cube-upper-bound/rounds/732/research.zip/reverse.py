"""R732 exact upper constants and positive-loss reverse-incidence controls."""
from fractions import Fraction as F
from flint import arb,ctx,__version__
from math import isqrt
import json,sys
ctx.prec=256
def check(n,k):
    a=32*n
    lam=arb(2)**(arb(1)/n)
    T=(1+arb(1)/a)*lam
    rho=1+arb(1)/64+lam/a
    out=4+lam/a
    # Normalized by the root side 2. For n>=256 the small interval exceeds T.
    assert rho>T and out>rho+2*T
    i0=rho-T/3
    cross=rho-i0
    oo=out-T/3
    sq=oo-2*rho+i0
    moment=i0+cross/4+sq/64
    taxed=moment*arb(8)**(2*arb(k)/n)
    centers=[(1 if l%2==0 else -1)*(-1 if l<k else 1)*F(9,4) for l in range(n)]
    bad=0
    for l,c in enumerate(centers):
        sign=(-1)**l
        x=sign*F(3,50); h=-sign*F(63,64)
        q=F(1,16*a)+F(1,a)
        diff=abs(x-c/3-h)
        if diff-q>1+F(1,64):bad+=1
        else:assert diff+q<1+F(1,64)
        assert abs(c)<3 and abs(x-c)+F(1,16*a)<3
    assert bad==k
    K=4096*isqrt(n)*a**n
    ell=arb(2).log()/K; vt=arb(1)/(8*a)**n; high=vt*ell.expm1()/2
    lg=n*arb(32*n).log()+(K-5)*n*arb(4).log()+(-(-ell).expm1()).log()
    assert 0<high<vt/4 and lg>(4*arb(6)**n+1).log()
    return dict(n=n,k=k,price_per_axis=str(taxed),weighted_second_moment=str(moment),bad=bad,
        high=str(high),V_T=str(vt),log_D_over_K_bounds=[str(lg/K),str((lg+arb(3).log())/K)],excess='0')
print(json.dumps(dict(python=sys.executable,flint=__version__,precision=256,cases=[check(n,k) for n in (256,1024,4096) for k in (0,n//24,n//8)]),indent=2))
