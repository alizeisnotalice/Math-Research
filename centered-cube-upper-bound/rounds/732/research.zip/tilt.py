#!/usr/bin/env python3
"""Finite tilted-root integral, shell and genuine-coordinate geometry audit."""
from fractions import Fraction as F
from decimal import Decimal as D,localcontext,ROUND_FLOOR
from math import comb,isqrt
from pathlib import Path
import hashlib,json,math,platform,socket,subprocess,sys
sys.set_int_max_str_digits(1000000)
BASE=Path(__file__).resolve().parent
DIMS=(64,256,1024,4096,16384)
EPS_KINDS=('inverse_log','inverse_sqrt_log','quarter')

def conv(A,T,x):return max(F(0),min(A,x+T)-max(-A,x-T))/(2*T)
def rational_integral(A,O,T,z,p):
    knots=sorted({F(0),abs(A-T),A+T,abs(O-T),O+T});ans=F(0);pieces=[]
    for l,r in zip(knots,knots[1:]):
        u=(1-z)*conv(A,T,l)+z*conv(O,T,l);v=(1-z)*conv(A,T,r)+z*conv(O,T,r)
        val=(r-l)*u**p if u==v else (r-l)*(v**(p+1)-u**(p+1))/((p+1)*(v-u))
        ans+=2*val;pieces.append({'left':str(l),'right':str(r),'f_left':str(u),'f_right':str(v),'two_sided_integral':str(2*val)})
    return ans,pieces

def int_one(A,T,p):
    m=min(A,T);return 2*(m/T)**p*(abs(A-T)+2*m/F(p+1))
def exact_spots():
    rows=[]
    for name,A,O,T,z,p in [
        ('separated',F(1),F(3),F(1,4),F(1,512),2),
        ('overlapping_ramps',F(1),F(5,4),F(1,4),F(1,8),3),
        ('inner_T_gt_A',F(1,4),F(2),F(1),F(1,8),2),
        ('both_T_gt_A',F(1,4),F(1,2),F(1),F(1,3),2),
        ('z_zero',F(1),F(3),F(1,4),F(0),2),
        ('z_one',F(1),F(3),F(1,4),F(1),2),
        ('z_two_outside_convex_domain',F(1),F(3),F(1,4),F(2),2)]:
        I,pieces=rational_integral(A,O,T,z,p);envelope=(1-z)*int_one(A,T,p)+z*int_one(O,T,p)
        if 0<=z<=1:assert I<=envelope
        else:assert I>envelope
        rows.append({'name':name,'inner_radius':str(A),'outer_radius':str(O),'T':str(T),'z':str(z),'p':p,
                     'true_integral_exact':str(I),'Jensen_integral_exact':str(envelope),
                     'Jensen_valid_domain':bool(0<=z<=1),'pieces':pieces})
    return rows

def private_geometry():
    # One actual rational source-shell geometry with shared epsilon1/4.
    n0=64;lam=F(65,64);h0=1+F(1,2048);T=F(1,8);s=T/(h0*lam);z=F(1,512);A=1+(z+lam/2048)*s;O=1+4*lam*s
    eta=F(1,1024);shift=T/4
    sites=[F(0),(A+O)/2,O+T/2]
    assert sites[0]+eta<A-T and sites[1]-eta>A+T and sites[1]+eta<O-T
    assert sites[2]-eta>O and sites[2]+eta<O+T
    rows=[]
    for n,k in ((4,1),(8,2),(32,3)):
        count=sum(comb(n,j) for j in range(k+1));total=3**n
        soft=sum((F(comb(n,j))*z**j for j in range(k+1)),F(0))
        corevolume=(2*eta)**n;event=count*corevolume;soft_integral=soft*corevolume
        assert soft_integral>=z**k*event
        rows.append({'dimension':n,'max_private_coordinates':k,'total_disjoint_owner_core_count':str(total),
                     'genuine_event_core_count':str(count),'event_volume_exact':str(event),
                     'total_receiver_core_volume_exact':str(total*corevolume),
                     'integrated_shared_softweight_on_events_exact':str(soft_integral),
                     'event_soft_lower_bound_exact':str(z**k),'false_ghost_containing_core_count':str(3**n-2**n)})
    return {'template_dimension':n0,'lambda_rational_upper':str(lam),'h0':str(h0),'s':str(s),'T':str(T),
            'epsilon_shared':'1/4','z_shared':str(z),'inner_radius':str(A),'outer_radius':str(O),
            'actual_transformed_sites':[str(v) for v in sites],
            'original_owner_sites_before_transform':[str(v-shift) for v in sites],
            'coordinate_transform_translation':str(shift),'owner_core_halfwidth':str(eta),
            'physical_common_translation_to_nonnegative':'2',
            'site_status':['true_inner_deep_g1','true_outer_only_deep_d1','outside_true_outer_but_positive_convolution_NOT_EVENT'],
            'site_softweights':[str((1-z)*conv(A,T,v)+z*conv(O,T,v)) for v in sites],
            'counts':rows,'scope':'Exact positive-volume disjoint owner cores, with a fixed volume-preserving coordinate translation. Only genuinely inner or outer-strip transformed cores count as events; the ghost cores are explicitly excluded. This is geometry, not a greedy history.'}

def decimal_e1(x):
    # Independently computed Euler constant via Euler-Maclaurin, error below1e-30.
    M=D(1024);gamma=sum((D(1)/j for j in range(1,1025)),D(0))-M.ln()-1/(2*M)+1/(12*M**2)-1/(120*M**4)+1/(252*M**6)-1/(240*M**8)
    total=-gamma-x.ln();term=D(1)
    for k in range(1,42):term*=x/k;total+=(1 if k%2 else -1)*term/k
    return total

def dec_coeff(n,kind):
    N=D(n);ell=N.ln();eps=1/ell if kind=='inverse_log' else (1/ell).sqrt() if kind=='inverse_sqrt_log' else D(1)/4
    p=1+eps;z=eps/128;b=z;lam=(D(2).ln()/N).exp();a=32*n;h0=1+D(1)/a;t=h0*lam
    alpha=b+lam/a;delta=4*lam-alpha
    def c_of(zz):
        Fp=(1-zz**(p+1))/((p+1)*(1-zz))
        K=alpha-t+2*t*Fp+(delta-2*t)*zz**p+2*t*zz**p/(p+1)
        return -K
    c=c_of(z);cv=(p-1)/(p+1)*t-alpha-z*delta
    L=ell/(2*lam*lam*h0*N);J=int((-L.ln()/(D(2).ln()/N)).to_integral_value(rounding=ROUND_FLOOR))
    x=N*c*L/(p*lam);bound=t**n/D(2).ln()*decimal_e1(x)
    sums=None
    if n<=1024:
        s=D(1);a1=D(0);a2=D(0)
        for j in range(1,J+1):
            s/=lam;a1+=(1-c*s)**(N/p);a2+=(1-cv*s)**(N/p)
        sums=[str(t**n*a1/n),str(t**n*a2/n)]
    return {'n':n,'kind':kind,'J':J,'c_true':str(c),'c_convex':str(cv),'upper_sum_over_n':str(bound),'finite_sums_per_n':sums}

def decimal_quadrature():
    cases=[]
    for n,kind in ((64,'inverse_log'),(64,'quarter'),(1024,'inverse_sqrt_log'),(16384,'inverse_log')):
        N=D(n);ell=N.ln();eps=1/ell if kind=='inverse_log' else (1/ell).sqrt() if kind=='inverse_sqrt_log' else D(1)/4
        p=1+eps;z=eps/128;lam=(D(2).ln()/N).exp();a=32*n;h0=1+D(1)/a;s=1/lam
        cases.append((str(n)+'_'+kind,1+(z+lam/a)*s,1+4*lam*s,h0,p,z))
    cases.append(('T_gt_inner_overlapping',D(1)/4,D(1)/2,D(1),D('1.5'),D(1)/8))
    out=[]
    def f(A,O,T,z,x):
        def g(R):return max(D(0),min(R,x+T)-max(-R,x-T))/(2*T)
        return (1-z)*g(A)+z*g(O)
    for name,A,O,T,p,z in cases:
        knots=sorted({D(0),abs(A-T),A+T,abs(O-T),O+T});true=D(0);results=[]
        for l,r in zip(knots,knots[1:]):
            u=f(A,O,T,z,l);v=f(A,O,T,z,r)
            true+=2*((r-l)*u**p if u==v else (r-l)*(v**(p+1)-u**(p+1))/((p+1)*(v-u)))
        for panels in (128,256,512):
            q=D(0)
            for l,r in zip(knots,knots[1:]):
                accum=f(A,O,T,z,l)**p+f(A,O,T,z,r)**p
                for j in range(1,panels):accum+=(4 if j%2 else 2)*f(A,O,T,z,l+(r-l)*D(j)/panels)**p
                q+=2*(r-l)*accum/(3*panels)
            results.append({'panels_each_piece':panels,'integral':str(q),'error_vs_antiderivative':str(q-true)})
        assert abs(D(results[-1]['error_vs_antiderivative']))<D('1e-5')
        out.append({'name':name,'exact_piecewise_antiderivative_decimal':str(true),'quadrature':results})
    return out

if '--remote' in sys.argv:
    with localcontext() as cc:
        cc.prec=100
        exact={'spots':exact_spots(),'private':private_geometry()}
        print(json.dumps({'host':socket.gethostname(),'python':platform.python_version(),
                          'exact_digest':hashlib.sha256(json.dumps(exact,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
                          'coefficients':[dec_coeff(n,k) for n in DIMS for k in EPS_KINDS],
                          'quadrature':decimal_quadrature()}));sys.exit(0)

from flint import arb,ctx

def st(x):return x.str(36)
def fa(q):return arb(q.numerator)/q.denominator
def floorarb(x):
    q=x.floor().unique_fmpz();assert q is not None;return int(q)
def e1upper(x):
    assert 0<x<1
    value=-arb.const_euler()-x.log();term=arb(1)
    for k in range(1,22):term*=x/k;value+=(1 if k%2 else -1)*term/k
    return value

def coeff(n,kind,bits):
    ctx.prec=bits;N=arb(n);ell=N.log();eps=1/ell if kind=='inverse_log' else (1/ell).sqrt() if kind=='inverse_sqrt_log' else arb(1)/4
    p=1+eps;z=eps/128;b=z;lam=(arb(2).log()/n).exp();a=32*n;h0=1+arb(1)/a;t=h0*lam
    alpha=b+lam/a;delta=4*lam-alpha
    assert delta>2*t # outer plateau covers the entire inner ramp
    def c_of(zz):
        Fp=(1-(zz.log()*(p+1)).exp())/((p+1)*(1-zz));zp=(zz.log()*p).exp()
        return -(alpha-t+2*t*Fp+(delta-2*t)*zp+2*t*zp/(p+1))
    c=c_of(z);cv=(p-1)/(p+1)*t-alpha-z*delta;assert c>=cv and cv>0
    L=ell/(2*lam*lam*h0*N);J=floorarb(-L.log()/(arb(2).log()/n));x=n*c*L/(p*lam)
    bound=t**n/arb(2).log()*e1upper(x);convex_bound=t**n/arb(2).log()*e1upper(n*cv*L/(p*lam))
    sums=None;sum_values=None
    if n<=1024:
        s=arb(1);a1=arb(0);a2=arb(0)
        for j in range(1,J+1):
            s/=lam;a1+=((1-c*s).log()*(n/p)).exp();a2+=((1-cv*s).log()*(n/p)).exp()
        sum_values=[t**n*a1/n,t**n*a2/n];assert sum_values[0]<bound and sum_values[1]<convex_bound
        sums=[st(v) for v in sum_values]
    controls=[]
    for name,zz in [('strong_z_epsilon_over8',eps/8),('overlarge_z_one_half',arb(1)/2)]:
        cc=c_of(zz);first_s=1/lam;logfirst=n*t.log()+(n/p)*(1-cc*first_s).log()
        if name=='overlarge_z_one_half':assert cc<0
        controls.append({'name':name,'z':st(zz),'decay_c':st(cc),'decay_survives':bool(cc>0),
                         'log_first_shell_normalized_Lp':st(logfirst),'b_kept_at_original_epsilon_over128':True})
    # True piecewise expression at sample shells; validate it against generic affine antiderivatives using explicit separated shape.
    spots=[]
    for s in (1/lam,1/N,L):
        A=1+alpha*s;O=1+4*lam*s;T=t*s;zzp=(z.log()*p).exp()
        plateau1=2*(A-T);ramp1=4*T*(1-(z.log()*(p+1)).exp())/((p+1)*(1-z))
        plateauz=2*(O-A-2*T)*zzp;rampz=4*T*zzp/(p+1)
        I=plateau1+ramp1+plateauz+rampz;assert (I/2).overlaps(1-c*s)
        Jensen=2*((1-z)*A+z*O-(p-1)/(p+1)*T);assert I<Jensen
        spots.append({'s':st(s),'inner_radius':st(A),'outer_radius':st(O),'T':st(T),
                      'true_integral':st(I),'convex_upper':st(Jensen),'outer_plateau_covers_inner_ramp':True})
    return {'n':n,'epsilon_kind':kind,'epsilon':st(eps),'p':st(p),'b_and_z':st(z),'J':J,
            'c_true':st(c),'c_convex':st(cv),'analytic_sum_over_n_upper':st(bound),
            'convex_analytic_sum_over_n_upper':st(convex_bound),'finite_true_and_convex_sums_divided_by_n':sums,
            'without_t_power_prefactor_finite_sums_per_n':[st(v/t**n) for v in sum_values] if sum_values else None,
            'E1_cutoff':st(x),'negative_controls':controls,'piecewise_spots':spots,
            '_values':[c,cv,bound]+(sum_values or [])}

def sparse_penalties():
    ctx.prec=384;out=[]
    for ell in (16,64,256,1024,65536):
        for name,k in [('one',1),('sqrt_log',isqrt(ell)),('log_over_loglog',max(1,int(ell/math.log(ell)))),('linear_log_negative',ell//4)]:
            eps=arb(max(1,k))/ell;p=1+eps;z=eps/128
            logcost=eps*ell+k*p*(128/eps).log()
            out.append({'log_n_parameter':ell,'k':k,'family':name,'epsilon':st(eps),
                        'log_Holder_extra_cost':st(logcost),'extra_power_of_n':st(logcost/ell),
                        'formula':'epsilon*logn+k*(1+epsilon)*log(128/epsilon); conditional on actualk-private softweight lowerz^k and anO(n)Lp envelope.'})
    return out

def main():
    exact={'spots':exact_spots(),'private':private_geometry()};digest=hashlib.sha256(json.dumps(exact,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    rows=[];raw=[]
    for n in DIMS:
        for kind in EPS_KINDS:
            lo=coeff(n,kind,256);hi=coeff(n,kind,384);assert lo['J']==hi['J']
            assert all(a.overlaps(b) for a,b in zip(lo['_values'],hi['_values']))
            raw.append([float(v) for v in hi.pop('_values')]);rows.append(hi)
    cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    try:
        run=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=45)
        remote={'command':cmd,'exit_code':run.returncode,'stderr':run.stderr}
        if run.returncode==0:
            other=json.loads(run.stdout);remote['result']=other;assert other['exact_digest']==digest
            assert len(other['coefficients'])==len(rows)
            for a,b,values in zip(rows,other['coefficients'],raw):
                assert (a['n'],a['epsilon_kind'],a['J'])==(b['n'],b['kind'],b['J'])
                compare=[b['c_true'],b['c_convex'],b['upper_sum_over_n']]+(b['finite_sums_per_n'] or [])
                for x,y in zip(values,compare):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
            remote['all_exact_arb_decimal_checks_passed']=True
    except subprocess.TimeoutExpired:remote={'command':cmd,'timeout_seconds':45}
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'exact_digest':digest,
            'exact_integer_p_spots':exact['spots'],'actual_parameter_tests':rows,'private_geometry':exact['private'],
            'sparse_threshold_penalty_tests':sparse_penalties(),'remote':remote,
            'definitions':['R=1,lambda=2^(1/n),a=32n,h0=1+1/a,t=h0lambda,p=1+epsilon,b=z=epsilon/128. Inner radiusA=1+(b+lambda/a)s,outer radiusO=1+4lambda*s,T=t*s.',
                           'g=1_inner*U_T,o=g+d=1_outer*U_T. True targetf=g+z*d=(1-z)g+z*o,with0<=z<=1. All stated scalar integrals use the actualf^p,not a product of separately optimized envelopes.',
                           'The root tensor budget includes prefactort^n fromR731. ForIp=integral f^p,the normalizedLp term ist^n(Ip/2)^(n/p). The version without this prefactor is explicitly recorded for finite sums.',
                           'Actual parameter shapes satisfyA>=T andO-A>2T. Their positive half-axis pieces are plateau1,affine1-to-z,plateauz,affinez-to0. Exact antiderivatives giveIp/2=1-c_true*s. Jensen givesIp<=2[(1-z)A+zO-etaT]=2(1-c_convex*s).',
                           'Legitimate shellsj1..J have_s=lambda^(-j),lower endpointL=logn/(2lambda²h0n). True and convex finite sums are fully evaluated throughn1024. Higher dimensions use explicitE1geometric-shell upper bounds,with all coefficients and actual-point scalar spots interval checked.',
                           'Sparse conditionalHolder cost beyondn isexp[epsilon logn+k(1+epsilon)log(128/epsilon)]. Optimizedepsilon=max(1,k)/logn is tested. Thek=o(logn)limit is an asymptotic interpretation of this explicit scalar expression; finite records do not substitute for a full geometry/history reduction.'],
            'scope':['Main dimensions64,256,1024,4096,16384;epsilon1/logn,sqrt(1/logn),1/4. Local Arb256/384 is independently compared with MacBook Decimal100. Remote piecewise Simpson quadrature is a numerical cross-check; the antiderivative and interval evaluations are primary.',
                     'Exact rational integerp spots include overlapping ramps,T>A,bothT>A,zzero/one,andz2 where the convex-mixture envelope is deliberately invalid. Main z stays in[0,1].',
                     'Private-coordinate tests use a single shared fixedepsilon1/4 and actual transformed positive-volume disjoint owner cores. A core outside the true outer interval is excluded even when its convolution weight is positive. They are geometric examples,not greedy histories.',
                     'Strongz=epsilon/8 and overlargez1/2 controls keep the inner geometricb at its original value. Their actual decay signs are retained rather than assumed.',
                     'Onlytilt.py/json are written; no Git,remote files,GPU use or remaining background jobs.']}
    (BASE/'tilt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'remote_exit':remote.get('exit_code'),'crosscheck':remote.get('all_exact_arb_decimal_checks_passed'),
                      'main_cases':len(rows),'coefficients_and_bounds':[{k:r[k] for k in ('n','epsilon_kind','c_true','c_convex','analytic_sum_over_n_upper','finite_true_and_convex_sums_divided_by_n')} for r in rows]},indent=2))
if __name__=='__main__':main()
