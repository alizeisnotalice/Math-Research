# 第235轮：熵补偿软度覆盖与真实接收占用量

## 本轮决策和结果边界

上一轮状态是已推送的实质进展：R234给全亏损三次对数来源价，但没有支付共同历史下的该矩。本轮不再尝试直接假定对数矩有界。先筛的两条FIRST桥只把来源质量换成未付接收体积，并可能弱于旧界，因此未作为主要成果，也没有据此宣称新已付分支。

实际推进来自保留R234的负相对熵增益。得到一份可与原目标来源FIRST容量同时使用的单soft网格；继而把节点价中的总来源质量替换为真实接收、hard密度与capture联合占用量。新价与旧A_rho及Gini取min，未抛弃旧工具。一般n^(1/2+o(1))弱型上界仍未闭合。

## 准确命题与费用

必要定义和详细LaTeX见proof.tex.txt。正仿射乘积H_s的总指数m=n时，posterior参数p给出H_s/H_r≤exp(nD(p||r)−nD(p||s))。取N=ceil(pi sqrt n)角中点网格，选择posterior角向上的第一个节点，超过末节点则取末节点；nD(p||r)≤9。原s≤1−d且d≥sin²(pi/(4N))时，任何后向r<s均满足p≤r<s。

原完整FIRST授目标node上限q chi_r(s)，chi=1（r≥s），否则chi=[(1−r)/(1−s)]^n。令a=theta/(1−s)，Btheta(s)=as+log(1−s+s exp(−a))。Bernoulli相对熵的直接变分恒等式与log(1+u)≤u给
H_s≤exp(9+nBtheta(s))Σr chi_r(s)^(−theta)H_r。
当theta≤1−s，Btheta(s)≤e theta²s/[2(1−s)]。它是可证的上界，不冒称对原非线性目标的精确最优值。前两原腿m=n；固定J目标第三腿不用后向目标价，m<n不误用m=n公式。

源依赖的单选r只用于证明点态覆盖，最终必须正和全部N个节点。归一目标Qhat=Q_r/chi_r(x)确实满足intQhat dnu≤q，但不是平移不变归一概率核。后续仅用其真实容量，和Qhat≤Q保障旧QG静态列仍可调用。没有把这一份熵增益再用于免费支付beta来源槽。

定义原hard密度d_R=(h_R*nu)/(C0q)≤1，capture目标容量zeta_C=q^(-1)int_Ztau C_*^(1/theta)Qhat dnu≤1，C0=16/3。保同一真实Lebesgue接收集Omega，定义
S_C(y)=a^(-n theta)int_Omega d_R(x) P_r,L*(x−y)^(1−theta) zeta_C(x,y)^theta dx。
它依真实receiver位置、hard来源及合法静态捕获限制，不是一个重新命名的总nu质量。theta固定于原外层标签，C_*不依辅助time、另一posterior点或hard点。

令ell=1+logn,c=gamma^(-j),M0=a/c²,x0=nlog(M/M0),z=x0−U>0。原同两posterior与真实heavy分母给新node价
A_SC=C0/(2theta) ell^(−theta)c^(3theta n/2)exp(theta x0)(1−exp(−2theta z))S_C(y)。
旧A_rho把S_C换成rho^theta，旧G=(rho/4)c^(2n)exp(−x0)z。对同一个归一目标列可取三者min，不把容量信用相乘。空clock为零。所有原源、期望和节点费用保留。

完整前缀2Lambda(K/3)^theta exp(13+e n theta²/(2d))；此外显式求和三腿、两朝向、N个soft节点和实际j/M。若取统一最坏值才额外乘6N。原祖链余量d_n=1000sqrt(log(n+2)/n)、L≤b−2a/n及n>4e6log(n+2)保留；低维有限工具测试不是该FULL支实例。此新价没有覆盖或取消其它原分支。

## 独审、技能和数值范围

审查者先独筛准确命题及量词，再读作者稿；核m=n限制、上posterior节点、非线性标量上界方向、一次目标容量、真实hard/receiver测度、static capture及最终min/外费。模型职责不重叠，作者交付后停止，不以任务数作进展。

应用D04熵链式技能核对同一联合律与条件参考；本轮数学只使用自给证明的有限Bernoulli变分恒等式，不冒用外部一般无限历史熵链式结论。skill来源状态已读取，不以“全文已读”替代当前接口核验。本机数值用已有Python/mpmath/numpy；实际范围和误差在numeric_notes.md/JSON及audit.md记录；冻结包外完整重放回执由最终README记录。

## 仍未解决

S_C的全j/M/soft/来源历史总账尚未支付；源依赖选theta不得在receiver内免费重选；beta槽的后向价格仍需保留，不能凭target容量重复领信用。新的几何占用价能与原总源价逐点比较，但不保证对每个输入都更优。需要用实际共同来源/receiver结构给总和的根阶预算，以及剩余分支、来源到输入桥与最终回代，才可宣布一般闭合。

不编译PDF，最终两新增跟踪文件（README和ZIP）保存LaTeX、证明、独审和必要复现。没有可归属本轮的实际额度扣减数据，不猜模型成本比例。

## 主结果强化：联合菜单容量与先聚合再clock

保留源依赖的唯一selected-r标签及全部残余KL，移动目标腿定义T_r=1_selected exp[−n(D(p||s)+B*)/theta]Q_r，B*=e theta²(1−d)/(2d)。不仅逐r有capacity q，全部节点的共同目标容量实际满足Σr intT_r dnu≤14q；固定J腿≤q。证明用后向节点的Bernoulli倾斜中心s_a和前向节点的s两个中心、KL的角距离平方下界与网格cell高斯尾，每中心<7。没有给不同节点重复分配q再默认为免费。

唯一标签使Σr P_r^(1−theta)T_r^theta≤Psharp^(1−theta)(ΣrT_r)^theta，Psharp=maxrP_r。这一步依赖互斥；一般非负和不能这样交换凹次幂。于是先聚合菜单、再完整posterior Holder，得到S_joint=a^(−n theta)int_Omega d_R Psharp^(1−theta)zeta_sum^theta dx，zeta_sum=q^(-1)int_Ztau Σr C_r^(1/theta)T_r dnu≤14（J≤1）。新clock A_Sjoint没有额外N因子；旧列备选在同aggregate列上必须为N A_rho、N G，不能漏N。最后取三价min、保三个腿两个朝向、全部j/M与原beta。

这是真正新增的全局几何工具：原先逐节点各付容量的做法，被共同来源标签和熵局部化的总容量控制替代。尚未支付的量是实际Psharp与zeta_sum同位置耦合的接收占用总和，而不是已证明它维数无关。无显式N的clock也不意味着软包络免费；Psharp仍在真实积分中。详见主稿(10)–(14)及独审。

## 主代理实际补充诊断（不与主JSON混计）

本机Python3.14及既有mpmath：60位1515个标量比较通过，原非线性目标/变分上界的最大已查比约0.99699996085051017728；50位72个角cell总和通过，最大单中心和约3.5931247762477216939，小于已证粗界3+2sqrt(pi)≈6.5449077018110320546。这些不是FULL输入、不是区间证书；一般结论由正文承担。完整生成规则如下，可单独运行，不把它们冒称主driver重跑的一部分。

```python
import mpmath as m
m.mp.dps=60
count=0; maxratio=m.mpf(0)
for s in map(m.mpf,['.01','.2','.5','.9','.99']):
 for theta in [(1-s)*z for z in map(m.mpf,['.001','.1','1'])]:
  a=theta/(1-s);B=a*s+m.log(1-s+s*m.exp(-a))
  assert 0<=B<=m.e*theta**2*s/(2*(1-s))
  for j in range(101):
   p=s*j/100
   D=(p*m.log(p/s) if p else 0)+(1-p)*m.log((1-p)/(1-s))
   L=theta*m.log((1-p)/(1-s))-D
   assert L<=B+m.mpf('1e-50');count+=1
   if B:maxratio=max(maxratio,L/B)
print(count,m.nstr(maxratio,20))
m.mp.dps=50;count=0;worst=m.mpf(0)
for n in (2,16,512,1000000):
 N=int(m.ceil(m.pi*m.sqrt(n)));D=m.pi/(2*N)
 cells=[(m.mpf(0) if i==0 else (i-m.mpf('.5'))*D,
         m.pi/2 if i==N-1 else (i+m.mpf('.5'))*D) for i in range(N)]
 for t in map(m.mpf,['.5','.1','.001']):
  for center in [m.mpf(0),D/2,D,m.pi/4,m.pi/2-D/3,m.pi/2]:
   val=sum(m.exp(-n*max(lo-center,center-hi,0)**2/t) for lo,hi in cells)
   assert val<=3+2*m.sqrt(m.pi);worst=max(worst,val);count+=1
print(count,m.nstr(worst,20))
```

## 最终账目强化：取消人工全局归一因子

移动腿T_B=exp(−nB*/theta)T0，T0=1_selected exp(−nD/theta)Q。精确aggregate列F_B=exp(−nB*)F0，S_B=exp(−nB*)S0；F0≤ΣF_old，所以旧备选也可保exp(−nB*)N A_rho及exp(−nB*)N G。与覆盖外exp(nB*)相消后，最终主式(15)只付2Lambda(K/3)^theta e13，保min{A S0,N A_rho,N G}及腿/朝向/j/M/来源和。

这里T0的目标容量绝不是14q：其逐receiver界是14q exp[nBtheta(s(x))/theta]（每移动腿）；J仍≤q。准确局部响应zeta0和Psharp、hard密度/capture共同保在S0中。这个精确缩放避免了先取全局最坏B再多付一遍费用，未把真实局部熵费用删去。归一14q定理和最终未归一S0必须区分，不能交叉套用数值或常数。

最终raw主式可直接由AMGM与互斥Holder证明，适用全0<theta≤1/2；theta≤d只属于统一二次B版本。exact局部B的倾斜恒等式不要求theta≤d，故不以受限版本的形式相消冒称扩大适用域。原s≤最后gridnode的margin继续保留。

主稿显示式(15)使用一个共同固定theta；逐原叶选theta_V也合法，但(K/3)^theta_V和所有theta_V依赖量必须留在EΣV内（峰SB20给出该版本），不从随机叶费用外提。

主脚本实际完成182个配置：70 affine覆盖、24标量KL、9旧mixed-L1容量行、27 basic S积分、9原qζ后验clock、32 Gaussian cells、2新单移动腿L1 joint行、9 joint disjoint clocks。40/70dps复核，真实L1 joint行另GL16/32；数值是normalized Bmax版本，raw最终代数结论由证明承担。单中心角cell最大约3.07844、两中心实际分区最大约4.69346；joint clock最大已查pair/bound约0.030789967。所有资格和误差限制保在notes；不能把这些有限最大值当锐常数或FULL实例。
