# R235 待命题的紧凑数值设计

已读本轮合同。本文件是运行前方案，不含未执行结果。等待作者给出准确左侧、右侧、全部适用门及独审筛选；此时不启动大网格、不重复R234全空间裸affinity费用，也不凭FIRST另造可自由使用的source moment。

候选到位后优先用真实有限L1来源：一维少量正区间密度（必要时二维有限矩形乘积），明确f、nu、beta与nu,beta<=f，固定同一q/a/b/soft/尺度。选择真实Lebesgue接收集合Omega，由同一输入的FIRST筛门决定；q不能逐接收点重设。来源若仅为原子诊断会单列而不当L1资格。计算作者所给真实alpha_theta、容量或共同两receiver积分，保其原orientation/实际capture；不把两receiver变量替成对角线。

三阶段建议，每阶段先2–4个配置：

1. initial：单区间与两个分离区间的有限f，宽receiver区间，theta取作者命题的代表值；用可解析hard卷积作独立控制。核同一接收点的实际FIRST与新容量量，记录边界余量与全部源质量。
2. stress：窄receiver、软度端点/原soft之后范围、来源靠hard边界及稀有较重source分量。直接核共同门，不用裸kernel失败排除路线。原full-FIRST在s变量上线性，固定A时可由s_actual和1两端控制；尺度A连续资格若无严格包络，只标有限scale核查，不能假称全FIRST成立。 backward-soft必须单独付chi费用。
3. expanded：只扩大最有决定意义的一项，或在确切命题需要时转二维真实矩形receiver/source；保共同q及历史/门依赖。精度、范围或分片扩大，而非大规模参数搜索；不得据有限结果拟合n阶或原input预算。

工具/精度：使用本机已装numpy和vendor mpmath，不安装新包。有限区间密度的hard卷积用精确交长，phi卷积用E3/E4原函数或解析内层；alpha/共同receiver积分沿hard与source边界分片。先快速固定grid/FFT，再选最危险点mpmath25/40或40/70独立复核，分开记录截尾、离散误差和实际严格门余量。若来源与Omega有限支撑可消去无限source尾；kernel无穷尾另保解析模板，普通求积不叫区间证书。

待命题必须明确：新估计具体左侧/付费右侧、alpha_theta定义与cost指数、Omega/capture范围、原FIRST可调用soft/尺度方向、theta选取是否在receiver之前固定、所有history/菜单/尺度/源桥费用。收到后才实现numeric_checks.py/json；最终--output可迁移、合同/源码hash绑定、全JSON逐字节复跑。只改本轮拥有三文件，不碰他人、Git、PDF，不认证FULL。

## 准确候选到位后的实现方案

父级/compare已确认Cgrid9与Btheta(s)=a s+log(1−s+s exp(−a)),a=theta/(1−s)。此B是线性化后Bernoulli变分的精确上界，不误称原非线性theta log((1−p)/(1−s))−D(p||s)的最优值。核标量原式≤B≤e theta² s/[2(1−s)]，同时保negative KL。

主cover逐例总lambda=n，采用first midpoint angle≥posterior angle（无则last），不沿用最近cell或原s角度。实际chi_r(s)=1若r≥s，否则((1−r)/(1−s))^n；检查logHs−logHr+theta logchi≤9+nB，且独立核logHs−logHr≤n[D(p||r)−D(p||s)]。三阶段小n/高soft压力/百万维扩大均只有限系数族，含零coeff、零lambda、Fs0与端点，不作FULL。

补核真实有限product-cube密度来源的容量行，a=b=L1；每来源homogeneous单坐标平均kernel对soft是正affine，其n次幂凸，因此原s及1端点可控制所有future soft。f=2nu、beta=nu，q固定留严格余量；不以目标点q重设每source。Q_r=(2P_r+P_1)/3，分别记录r<s时除chi的真实费、r≥s时future资格及共同q。此仅有限receiver行/工具，不认证历史。

另27个真实1D S_y=∫Omega P_r(x−y)^(1−theta)dx，Omega=[−.25,.25]，a=L1，y0/2/8，theta.5/.1/.01，r取实际midnodes；对rho1/1e6/1e100只比较S_y/rho^theta价格。audit通过的新qzeta clock另只用9个实际productclock有限原子：staticC∈[0,1]，真正posterior双source正score差、完整et、实际heavy、normalizedtarget T容量q、zeta及hard占用d_R均保原定义，不能误归一或改成mass bound。未来原input/history资格仍未建。

## 初探、压力、扩大范围的实际结果

本机mpmath初探70dps：n512,s.9,theta.1的pure posterior linear-opt族，log(Hs/Hr)≈−37.443475、theta logchi≈40.881903，合后≈3.438428，grid nD(p||r)≈.139495、nB≈29.985320，所提9+nB余量≈35.5469。n1e6,s.999,theta.001对应backward fee≈983.942被negative entropy主项抵消，合后≈−12.5916；但nB≈716.807必须保留，不能把剩余费用称为维度无关常数。

最终70个affine cover包含独立原非线性标量最优posterior压力与generic real coefficients；24个scalar例另保原非线性值、线性化variational B及e/2上界。所有40/70dps复核通过。grid nD(p||r)有限最大约.522932<9；一般系数百万维s.75、theta.1的合并log比约7215.44，仍低于9+nB≈15973.65，直接说明residual nB可能很大。有限最大值不证明Cgrid9或常数最优，作者/独审负责一般证明。Fs0、s0、零coeff/零lambda及first-upward-last fallback均显式处理。

## 真实有限L1容量行与basicS

9个旧mixed-FIRST行确为有限uniform product-cube密度f=2nu、beta=nu；共同q固定为2.5倍nu的soft-s/soft1端点最大值。固定A=1、a=b=1时每source贡献为同一个正affine soft平均的n次幂，故凸性给所有future-soft容量；r<s必须真实除chi，不能调用backward node FIRST。这些旧Q_r=(2P_r+J)/3行只检查旧mixed帽，不算新entropy 14q证据。

27个basic S_y实际有限Omega=[−.25,.25]积分，在y0/2/8、实际n16 midnodes、theta.5/.1/.01下值约从7.767e−8到.499585。保存S_y/rho^theta的rho1/1e6/1e100价格比，只是新旧node价比较；basic S未加capture，也未把这些不同y/r的积分拼成同一历史/FULL或无条件原input付款。

9个最初qzeta工具clock使用真正完整posterior与正双source score差，staticC=(1,.5,0,.75)与actual targethat kernels固定不依t/u/hardz。q同时保明确target帽、hard占用d_R和actualheavy A=ell q tau^n。全部40/70dps通过，pair/bound有限最大约.0343583；d_R约.107853（n2）或.8（n16/512）。这不是原FIRST全尺度/history资格证书，尤其有限原子clock不当正L1/FULL。

## Entropy cells与逐movingleg joint容量

32个finite cell预算覆盖n2/16/512/1e6、s0/.5/.9/.999和相应theta≤1−s。对每个center用angle投影到闭cell给精确KL infimum，保最后加宽cell。future-center sum最大≈3.0555354、tilted-center≈3.0784425，均<7；按实际r<s/r≥s分区取相应center的sum最大≈4.6934571<14。s0时两个center重合，但actual direction partition仅计对应future一次。有限检查不把常数改小。

新14q容量逐single movingleg Q_r=P_r,A测试，与旧mixture区分。2个n2真实L1 joint density行，theta.1/.01，用同一3个有限product cubes、source-dependent唯一上选r(v)、实际posterior与KL residual；GL16/32独立加密。单leg sum_r∫T_rnu/q分别≈.103815020、3.36765717e−7。两复制movinglegs（a=b=A=1故尺度相同）加固定J的总/q≈.344768462、.137139096；只按一般28q+q=29q核，不把两腿误授14q。targety选择x−y=.49仅用于工具测试，未认证beta在该y或原history流量。

同两密度行的disjoint source sum与Psharp majorant比≈.801251784、.792395723；每source仅一个selected r，故可用Psharp^(1−theta)(sumT)^theta，不是对非disjoint正和错误丢N。GL16/32的32有效位容量输出一致只作普通求积交叉检查，不是interval FIRST证书。真实L1 future资格由前述固定scale凸性给出，source积分本身不假装history合法。

## 完整joint disjoint posterior clock与最终版本口径

在既有n2/16/512×theta.5/.1/.01的9工具模型上追加joint clock，没有增加模型族。每atom的T_r使用单leg原kernel、唯一source-dependent selectedr、static negative-KL residual；当前e_t保全部活source，删除按原分片，计算真正Pi_v Pi_u正score差。P_selected^(1−theta)由实际target kernel保留，以同菜单真实Psharp做disjoint上界；qzeta=sum nu C^(1/theta)T与hard d_R保原义，未重设错误概率。

9例全部40/70dps通过；joint pair/bound最大≈.030789967（n2 theta.5），n512三theta分别约8.91e−113/3.46e−45/1.55e−28，不能据此拟合n阶。d_R仍约.107853或.8；perleg target容量比按14q而非强加q测试，保真实值。staticC不依时间、bad source或hard来源。所有有限clock都只是工具/同列资格，不认证FULL。

重要最终代数口径：本文件的joint数值明确是归一化Bmax版T_B=1_selected exp[−n(D(p||s)+Bmax)/theta] Q_r。它们可核14q，不可当raw T0=1_selected exp[−nD/theta]Q_r容量14q的证据。主稿另有纯代数T_B=exp(−nB/theta)T0缩放，outer exp(nB)、S_B及备选price必须同步相消；rawT0容量仍需14exp(nBtheta(s)/theta)等实际费用。此代数修订不新增数值范围，本脚本不把normalized实验偷偷改名成raw结果。相应aggregate min{A_Sjoint,N A_rho,N G}的旧A/G费用仍保N，Psharp本身不套旧QG。原global source期望、其余分支与history费用仍未付，不宣称弱界闭合。

实际最终counts：70affinecover、24scalar、9旧mixed-L1容量行、27basicS、9原qzeta clocks、32Gaussian cells、2新single-leg真实L1 joint rows、9joint disjoint clocks。所有运行结果为普通高精数值，精确输入/Fraction与解析定义明确；不以有限结果替代一般证明。

## Final replay and freeze

The final full replay completed successfully in 7.34 seconds wall time (7.29 user, 0.04 system), with output directed to a separate temporary file. Its complete JSON was byte-for-byte identical to numeric_checks.json. Runtime and output path are not JSON fields. The executed counts were affine cover 70; scalar KL 24; old mixed L1 capacity rows 9; basic S integrals 27; q-zeta full-posterior clocks 9; Gaussian cells 32; genuine joint single-leg L1 rows 2; joint disjoint clocks 9.

The scalar Gaussian-cell menu includes n=2, s=.999, which does not satisfy the last-midpoint soft margin. That case tests only KL/cell budgets, and does not certify normalized-kernel original qualification. The actual joint density examples use s=1/3 and satisfy that margin.

Frozen SHA256: numeric_checks.py `6301c16f434bdfe6011cadeed33ccb84f0fa09f3d6d04f3de44ad5533142f0a9`; numeric_checks.json `ad5088ceec544480c795bf2b355193fca2ea6307c2857554ad7b853fea5dca79`; bound contract `868cacfeb371edd26c8be2a8cf1eb572bbb52f4d233e112203046862794df208`.
