# R235：容量兼容的 soft 覆盖与真实 receiver 占用价格

本稿完成本轮 scalar entropy 菜单到原正交通的接回。新目标核在同一个真实 receiver 上满足 FIRST 容量 q；保留菜单选择标签后，每条移动腿各自的合计容量≤14q，J 腿≤q，因此可先合菜单再做原后验 Hölder，新的容量 clock 分支不支付显式 N 因子。共同 hard 来源占用、capture、源端 backward-soft 及剩余 receiver/source 费用均显式保留。该新价可与旧两价对同一交通取 min，但没有证明其全尺度和被输入质量控制，不宣布一般根阶付款。

§SB7b 进一步精确消去人工全局 B* 外费；对应目标的局部容量费用留在原 receiver 占用量中，不再声称它有免费14q容量。

## SB1 原范围、静态参数与 scalar 输入

固定原 `(ω,V)`，`0≤ν_V≤β_V^c≤α_V≤f`，共同 `q,a,b` 满足 `0<a≤b≤2a`，原 K>0。实际 receiver 集的静态上集 Ω 保原 hardband 和 FIRST 条件。它不是另造的独立 receiver 分布。固定 `(j,y,t)` 后，原 `Π_t,e_t,k_t,Z_t` 不依 x 或 hard 来源 z。

原未付祖链保 `s=s_actual(x)≤1-d_n`，其中
`d_n=1000√(log(n+2)/n)`；仅讨论该原链非空且 `0<d_n<1` 的维数。下文写 d=d_n。使用统一二次 B* 的归一化路径先取整条 V 共同的 `0<θ≤min(1/2,d)`；最终 §SB7b 的 raw 结论只需 `0<θ≤1/2`。θ 均不依 x、y、v、j、节点或 t 另选。抽象数值测试不自动满足这个 FULL 祖链。

对前两条移动腿，固定物理节点后
`H_s=P_{s,L*}(x-y)^(1−θ)P_{s,A*}(x-v)^θ`，总 affine 权为 n。令 p 为这一加权乘积在 s 的 Bernoulli posterior 平均。采用 `N=ceil(π√n)` 个 arcsine 中点，选 p 的角度上方第一个中点；若 p 高于末中点，使用末中点。原 d 保证末中点≥1−d，故 backward 节点 `r<s` 必有 `p≤r<s`。本轮 `joint_capacity.md` 独立证明

\[
nD(p\Vert r)\le9,\quad
\chi_r(s)=\begin{cases}1,&r\ge s,\\((1-r)/(1-s))^n,&r<s,\end{cases}
\]

以及

\[
H_s\le \exp(9+nB_\theta(s))\,
\frac{H_r}{\chi_r(s)^\theta},\qquad
B_\theta(s)=\frac{\theta s}{1-s}
 +\log(1-s+s e^{-\theta/(1-s)}).
\tag{SB1}
\]

统一 `B_θ(s)≤B_*=eθ²/(2d)`，记 `E_θ=exp(9+nB_*)`。第三条固定 J 腿不需 backward target 归一化，使用原 AM–GM 菜单后也由同一较宽 Eθ 上控。零核纤维无需定义 posterior，可将其所有保留标签目标 T_ent 置零；端点 s=0 的相对熵按连续约定。这里是一份共同菜单，不是两份 N 的乘积。p 依 x、y、v；选中项只能用一个非负有限和代替，不可把所选 r 先当共同常数。

## SB2 归一化目标核与剩余源端费用

固定一条腿、节点及菜单 r，定义

\[
\widehat Q_r(x,v)=
\begin{cases}
P_{r,A^*}(x-v)/\chi_r(s_actual(x)),&i=1,2,\\
J_b(x-v),&i=3.
\end{cases}\tag{SB2}
\]

原 FIRST 对所有 `A*∈[a,b]`、所有 `r≥s_actual(x)` 有容量 q；在 backward 情况，逐坐标的 affine 比较给
`P_{r,A*}≤χ_r(s_actual)P_{s_actual,A*}`。所以

\[
\boxed{\int\widehat Q_r(x,v)\nu(dv)\le q
\quad(x\in\Omega),\qquad 0\le\widehat Q_r\le Q_r.}\tag{SB3}
\]

这是**真实 receiver 逐点**的容量，不是在删掉 Ω 后授予全空间容量。`χ_r(s_actual(x))` 依 x，必须留在真实 Lebesgue receiver 积分内。虽然目标端已归一化，源端仍是 `P_{r,L*}(x-y)`：一般只有
`∫P_{r,L*}(x-y)β(dy)≤qχ_r(s_actual(x))`。不能用同一 entropy 增益再免费消掉这一源端费用。

## SB3 物理覆盖、原 good 及同一真实列

原终端 good 的分数幂比较不变：

\[
p_y1_{good}\le(K/3)^\theta
\sum_{i=1}^3p_y^{1-\theta}Q_i(v)^\theta/w_g(y,v)^\theta.
\tag{SB4}
\]

R229 物理节点仍从 `M_0=a/c²` 按 γ 向上，末点截 b，`c=γ^{-j},γ=1+1/n`；两朝向为 `(L*,R*)=(M,c²M)` 或 `(c²M,M)`，`g*=cM,w*=w_g*=\bar w_{c²M}`。三腿 `A*=L*,min(b,γL*),b` 均合法。θ≤1/2 时物理覆盖费用仍≤e4，不增加第三尺度菜单。

记 `C_*(x,v)∈[0,1]` 为保留的**静态** capture/support 权：它不能依 t、另一后验源 u 或 hard 来源 z。可用 R229 已继承的固定节点排除：实际 `R≤L` 的排除尺度为 `max(a,R*/γ³)`；实际 `R>L` 仅原 upper-clamp 才保 Qa 排除。lower-clamp 不获完整 core 排除。原依 hard z、u 或时钟的 RN/history 门只能保在左边母量，或为正上界去掉；不能声称它们已经分解进下面两个来源因子。

定义

\[
\begin{aligned}
H_{R^*}\nu(x)&=\int h_{R^*}(x-z)\nu(dz),\\
\widehat F_\theta(y,v)&=\frac1q\int_\Omega
H_{R^*}\nu(x)\,C_*(x,v)
\frac{P_{r,L^*}(x-y)^{1-\theta}\widehat Q_r(x,v)^\theta}
     {w_*(y,v)^\theta}\,dx.
\end{aligned}\tag{SB5}
\]

这是同一原 hard 来源 ν(z) 的真实积分列。`Qhat≤Q`，故原未归一化 QG 列和 R234 局部帽仍是其上界：

\[
\widehat F_\theta\le
\min\{C_0/w_*^\theta,\ B_M E_*^{2\theta}\},
\quad C_0=16/3,\quad B_M=\|\nu\|/(qM^n).
\tag{SB6}
\]

SB6 的两项估同一列，不能先删 hard 核后再次应用 QG。固定节点归一化后的半密度积分还给旧的 `mhat_θ=∫αhat_θ^(1/θ)ν` 精化；本稿下一步直接用 SB3，避免先将其粗化为全来源质量。

## SB4 新的真实 occupancy 功能量

令 `τ=a/c`。定义两个来自**同一个原 ν 与历史**的静态因子

\[
d_R(x)=\frac{H_{R^*}\nu(x)}{C_0q}\le1,
\qquad
\zeta_C(x,y)=\frac1q\int_{Z_\tau(y)}
C_*(x,v)^{1/\theta}\widehat Q_r(x,v)\nu(dv)\le1.
\tag{SB7}
\]

第一项用 Ω 内合法 R* 的 hard 帽，第二项用 SB3。capture 为指示时其 `1/θ` 次幂仍是自身。这两项不被当作独立随机量。

保全部真实 receiver 变量，定义无量纲量

\[
\boxed{S_C(y)=a^{-n\theta}\int_\Omega
d_R(x)P_{r,L^*}(x-y)^{1-\theta}\zeta_C(x,y)^\theta\,dx.}\tag{SB8}
\]

它是可由原来源与实际 receiver 计算的占用量；不是把整个交通改名成一个未定义算子范数。特别

\[
S_C(y)\le a^{-n\theta}\int_\Omega P_{r,L^*}(x-y)^{1-\theta}dx.
\tag{SB9}
\]

不同腿、朝向和 r 的 S_C 不同，后面保有限和，不取免费共同上确界。

## SB5 容量 clock 定理及完整证明

固定节点 `h=g*e^{-U/n}`, `U≥0`。原 heavy 仅在实际有效时间给
`e_t>A_f(t/τ)^n`，`A_f=ell q a^n c^{-3n/2}`, `ell=1+log n`。原 carrier 递减，`Π_t=1_Zt w_tν/e_t`，另一 Π 仍是同一原后验，`δ=(k_v−k_u)_+≤k_v≤n`。没有 subset endpoint 下界。

对固定 x，真实乘积权给 `w_t≤(g*/t)^n w*`。Hölder 于是给

\[
\begin{aligned}
\iint C_*(x,v)\frac{\widehat Q_r(x,v)^\theta}{w_*(y,v)^\theta}
\delta_t(v,u)\,d\Pi_t(v)d\Pi_t(u)
&\le\frac{n(g*/t)^{\theta n}}{e_t}
\int_{Z_t}C_*\widehat Q_r^\theta w_t^{1-\theta}\,d\nu\\
&\le n(g*/t)^{\theta n}
\left(\frac{q\zeta_C(x,y)}{e_t}\right)^\theta.
\end{aligned}\tag{SB10}
\]

在末步 `Z_t⊂Z_τ`，并且 Hölder 的另一因子正是原 e_t；没有对来源重新归一化。先乘 `H_Rν(x)P_y(x)^(1−θ)/q` 再对真实 x 积分，SB8 得

\[
\iint\widehat F_\theta(y,v)\delta_t(v,u)d\Pi_t^2
\le n C_0(g*/t)^{\theta n}(qa^n/e_t)^\theta S_C(y).
\]

只在原 heavy 时间使用分母下界，随后把非负解析 majorant 积分到整个 `[τ,h]`。由
`n∫_τ^h(t/τ)^(-2θn)dt/t=[1-(τ/h)^(2θn)]/(2θ)`，得到

\[
\boxed{\mathcal K_{jM,\theta}(y)
\le\frac{C_0}{2\theta}\ell^{-\theta}c^{3\theta n/2}
e^{\theta x_M}(1-e^{-2\theta z_M})S_C(y),}
\quad x_M=n\log(M/M_0),\quad z_M=x_M-U>0.
\tag{SB11}
\]

`z_M≤0`、无 heavy 行或零来源直接为零。该定理涵盖全部 terminal deficit，不需 persistent S、late-clock 价、e_t 导数或旧删除负信用。原时钟外门仍可保在左边，只有按正方向上放才得到上述上界。

## SB6 原量的完整三价 minimum

记 `ρ=||ν||/(qa^n)`，

\[
A_{jM,\theta}=\frac{C_0}{2\theta}\ell^{-\theta}c^{3\theta n/2}
e^{\theta x_M}(1-e^{-2\theta z_M}),\qquad
G_{jM}=\frac\rho4c^{2n}e^{-x_M}(x_M-U)_+.
\]

对同一归一化列，R234 原质量价、同后验 Gini/QG 价、SB11 新容量价可取

\[
\boxed{\mathcal K_{jM,\theta}(y)\le
\min\{A_{jM,\theta}\rho^\theta,\ G_{jM},\
A_{jM,\theta}S_C(y)\}.}\tag{SB12}
\]

所以包含全部原 measure/history 门的 far 正量满足

\[
\boxed{\mathcal P_{far}(U)\le
2\Lambda e^4\,\mathbb E\sum_V(K/3)^{\theta_V}E_{\theta_V}
\sum_{j,M}\sum_{\substack{i=1,2,3;\ \text{两朝向}\\r\in\mathcal S_n}}
\int\beta_V(dy)
\min\{A_{jM,\theta_V}\rho_V^{\theta_V},G_{jM},
A_{jM,\theta_V}S_{C,i,r}(y)\}.}\tag{SB13}
\]

所有物理尺度、soft 参数、原两 Π、唯一叶来源与真实 dx 均有去向。`Eθ=exp(9+e nθ²/(2d))` 是实际外费，不省略其维数；同时有三腿、两朝向、N 个 soft 项，但 S_C 不共同，不能先提出 `6N` 又声称其来源价相同。若粗化所有列可按显式上确界提出；那不是免费改进。

SB13 是新的可比较几何价：它将原 `ρ^θ` 替换成同来源的 receiver/capture 占用 S_C，且 backward 目标端真正有容量 q。仍可对同一母量保 R234 已证全和界，在新外费较大时用旧界。不能因为 SB12 内有一个较小项就忽略新外费，并宣称原全和必然改善。

## SB7 可保的负 entropy 余量与合法插槽

在 backward 被选节点，令 `d_s=1-s,a_s=θ/d_s`，
`p_*=s exp(-a_s)/(d_s+s exp(-a_s))`。scalar 恒等式为

\[
\theta\log\frac{1-r}{1-s}-D(p\Vert s)
=B_\theta(s)-\mathcal R_{s,r}(p),
\]

\[
\mathcal R_{s,r}(p)=D(p\Vert p_*)
 +\theta\left[\frac{s-p}{1-s}-\log\frac{1-p}{1-s}\right]
 +\theta\log\frac{1-p}{1-r}\ge0.
\tag{SB14}
\]

因此在统一外费 Eθ 后，选中 backward 节点还可保
`1_selected exp(n(Bθ(s)-B*)-n R_{s,r}(p))≤1`；forward 节点保相应 `exp(-mD(p||s)-nB*)` 与选择指示，J 腿 m=`n(1−θ)`。这些依 x、y、v，不能先当共同常数提出源积分。

它们在物理节点固定后不依辅助 t、hard z 或 u，故可乘入 SB3 的静态 C_*，以其 `1/θ` 次幂进入 ζ_C。由此 SB11–13 原样成立且不丢负 KL 几何信息。若不证明这种静态性或把涉及其它来源的历史门混入该因子，则不能使用 SB10 的分解。

## SB7a 保选择标签的合计容量：容量分支不另乘 N

本轮 `joint_capacity.md` 的 Gaussian cell 结算已由独审独立筛过：在 SB1 的全部原范围内，定义移动两腿的精确目标

\[
T_{{ent},r}(x,y,v)
=1_{\{r\text{被选中}\}}
\exp\left\{-\frac n\theta[D(p\Vert s_actual(x))+B_*]\right\}
P_{r,A^*}(x-v).
\tag{SB15}
\]

它等于 SB7 的剩余增益 `A_r^{1/θ}` 乘 `Q_r/χ_r`，故 `0≤T_ent,r≤Q_r/χ_r≤Q_r`。这里 B* 取本稿稍宽的 `eθ²/(2d)`；scalar 结算允许更小的 `eθ²(1−d)/(2d)`，增大 B* 只减小目标，故14q仍成立。本稿所有 Eθ、T_ent、ζjoint 与 Sjoint 始终使用同一较宽 B*；不能与使用较小 B* 的另一份占用数值混同。对 J 腿，改用
`T_ent,r=1_selected exp{-[n(1−θ)D(p||s)+nB*]/θ}J_b(x-v)`，其中 p 只来自 source 腿；不能套移动腿 m=n 的 gain。J 腿的选择不依 v。

对每个固定 x、y、物理节点和腿，移动两腿有
`Σ_r∫T_ent,r(x,y,v)ν(dv)≤14q`；J 腿有≤q。该结算是同一原 ν 上的合计容量，不是 N 份独立 FIRST 付款。其证明保 backward 倾斜中心和 forward 原中心，两组 KL-angle Gaussian cell 和各小于7。本稿引用该独立 scalar 结论，不以两端容量独立化取代它。

允许固定 capture `C_{*,r}(x,v)∈[0,1]` 随菜单改变；通常使用 R229 的共同节点排除。定义

\[
\begin{aligned}
\mathcal T_C(x,y,v)&=\sum_r C_{*,r}(x,v)^{1/\theta}
T_{{ent},r}(x,y,v),\\
\zeta_{joint}(x,y)&=q^{-1}\int_{Z_\tau(y)}\mathcal T_C(x,y,v)\nu(dv),\\
P^\sharp(x-y)&=\max_{r\in\mathcal S_n}P_{r,L^*}(x-y),\\
S_{joint}(y)&=a^{-n\theta}\int_\Omega
d_R(x)P^\sharp(x-y)^{1-\theta}\zeta_{joint}(x,y)^\theta\,dx.
\end{aligned}\tag{SB16}
\]

移动两腿 `0≤ζ_joint≤14`，J 腿≤1。所有对象仍依真实来源和 receiver；Psharp 与 ζjoint 不被当作独立。唯一选择标签给**逐 v**的点态上界

\[
\sum_r C_{*,r}P_{r,L^*}^{1-\theta}T_{{ent},r}^{\theta}
\le(P^\sharp)^{1-\theta}(\mathcal T_C)^\theta.
\]

这里依赖最多一个 `T_ent,r` 非零；对任意无标签正和，此方向不能直接使用。先合菜单后，对右边用 SB10 的同后验 Hölder，目标积分为 `qζ_joint`，随后沿原 heavy clock 积分，得到 exact aggregate 交通的 `A_{jM,θ}S_joint(y)` 上界，没有 N。

为准确比较旧价，令 exact aggregate 列为
`F_ent=q^-1∫ΩH_Rν(x) Σ_r C_{*,r}P_{r,L*}^{1−θ}T_ent,r^θ /w*^θ dx`。
有 `F_ent≤Σ_r F_old,r`；故它的旧备选价是 `N A_{jM,θ}ρ^θ` 和 `N G_{jM}`。Psharp-majorant 本身未必小于该旧列和，不能把这两个上界的对象混同。三价都估计 exact aggregate 交通，因此合法结论是

\[
\boxed{\mathcal K_{ent,jM,\theta}(y)\le
\min\{A_{jM,\theta}S_{joint}(y),\
N A_{jM,\theta}\rho^\theta,\ N G_{jM}\}.}\tag{SB17}
\]

完整原量回代的较强版本为

\[
\boxed{\mathcal P_{far}(U)\le
2\Lambda e^4\,\mathbb E\sum_V(K/3)^{\theta_V}E_{\theta_V}
\sum_{j,M}\sum_{i=1,2,3;\ \text{两朝向}}
\int\beta_V(dy)\,
\min\{A_{jM,\theta_V}S_{joint,i}(y),
N A_{jM,\theta_V}\rho_V^{\theta_V},N G_{jM}\}.}\tag{SB18}
\]

N 仅保在旧的粗备选价，容量分支没有显式 N。三腿、两朝向、物理 e4、entropy 外费 Eθ 和 `(K/3)^θ` 均未删除。Ω、capture 和来源 posterior 在合计目标中保留。虽然不再逐菜单付 N，源端出现真实 Psharp；既没有断言其 FIRST 容量为 q，也没有声称它的 receiver/source 积分是单位质量。

## SB7b 精确重标度：消去人工全局 B* 外费

移动腿改记 `T_{0,r}=1_selected exp(-nD(p||s)/θ)Q_r`；J 腿改记
`T_{0,r}=1_selected exp(-n(1−θ)D(p||s)/θ)J_b`。这些目标仍逐 v 互斥，且 `T_{0,r}≤Q_r`。SB15 中各腿均有精确关系

\[
T_{{ent},r}=e^{-nB_*/\theta}T_{0,r},\quad
F_{ent}=e^{-nB_*}F_0,\quad
\zeta_{joint}=e^{-nB_*/\theta}\zeta_0,\quad
S_{joint}=e^{-nB_*}S_0.\tag{SB19}
\]

这里 F0、ζ0、S0 分别以 T0 替换 SB7a 的 T_ent 定义，保同一 capture、Psharp、d_R、Zτ 与实际 dx。因为 `F_0≤Σ_rF_old,r`，旧备选也可强化为 `e^{-nB*}N Aρ^θ`、`e^{-nB*}N G`。因此 SB18 的三项都含同一个 `e^{-nB*}`，与外 `Eθ=e^{9+nB*}` 抵消，得到更准确的原量式

\[
\boxed{\mathcal P_{far}(U)\le
2\Lambda e^{13}\,\mathbb E\sum_V(K/3)^{\theta_V}
\sum_{j,M}\sum_{i=1,2,3;\ \text{两朝向}}
\int\beta_V(dy)\,
\min\{A_{jM,\theta_V}S_{0,i}(y),
N A_{jM,\theta_V}\rho_V^{\theta_V},N G_{jM}\}.}\tag{SB20}
\]

J 腿也可直接从无 B* 的 AM–GM 覆盖得到该式。这个消去对三项同时进行，不是只取消外费而忘记改占用量。

T0 **不具有**免费14q容量。固定实际 x、y，每条移动腿的正确局部界是
`Σ_r∫T_{0,r}ν≤14q exp(nB_θ(s_actual(x))/θ)`，而 J 腿≤q。其理由是 SB14 将 backward cell 的上界分成 `exp(nB_θ(s)/θ)` 与倾斜中心的 KL Gaussian，和仍小于7；forward cell 和小于7，并用 `B_θ(s)≥0` 合并。这个费用依真实 receiver 的 s，保在 ζ0 及 S0 内。若把它换成全局 B* 上界，人工全局费就会重新出现。因此 SB20 没有取消实际局部 soft 容量费用，也没有证明 S0 的来源积分已付。

**最终 raw 范围。** SB20 及上述局部容量界只需 `0<θ≤1/2`，不需 θ≤d：可以直接从保负 KL 的 AM–GM 覆盖得到 `e9 Σ_r P_r^(1−θ)T0,r^θ`；SG 型 good、物理/QG 插值和 growing-heavy Hölder 在此范围全成立。精确 Bθ(s) 的变分公式也对全部 θ>0 成立，Gaussian cell 求和在 θ≤1/2 保持原常数。θ≤d 仅用于前面的二次统一估计 `B*≤eθ²/(2d)`。原 `s≤1−d`、末中点≥1−d 及全部祖链条件仍必须保留，不能随 raw 重标度删去。

## SB8 费用边界与最早尚缺的一步

一般 S_C 或 Sjoint 并非已付输入预算。一个可证明但昂贵的核帽是 `S_C≤100^{nθ}`：原 `φ=h*∫_0^1exp(-|·|/r)dr` 满足 core 上 φ≤1、尾部 `φ(x)≤exp(1/2−|x|)`，故 `∫√φ≤5`；插值得 `∫φ^{1−θ}≤25^θ`，混合次可加性给 `∫f_r^{1−θ}≤50^θ`，再用 `L*/a≤2`。同理粗化 Psharp 为有限和给 `S_joint≤14^θ N100^{nθ}`。这些帽说明量是显式有限的，同时显示为何不能把它们视为维数一致常数或据此宣称菜单费已在最终输入价中消失。

本轮尚缺的具体步骤是：对原共同 β 源、真实 Ω、每个节点同一 ν 所形成的 `d_R(x)ζ_0(x,y)^θ`，证明 SB20 全有限和有足够平均衰减，支付实际局部 soft 容量费、物理节点与 `(K/3)^θ`，或控制其一个明确大分支。源端 Psharp 的实际费用、β 槽和真实 receiver dx 都仍在该步骤中。仅归一化 target 合计容量14q、唯一叶、ν≤β 或 scalar 负 KL 不能独自推出此平均衰减。

先前保 hard-z 的双 FIRST 推导虽可把全来源质量换成 Ω 体积，但没有新的体积预算，故不登记为本轮付款。本稿正成果限定为容量兼容的实际列、归一化合计目标14q、以及 SB20 不逐菜单付款且消去人工全局 B* 外费的三价比较；没有宣称一般 `εX+C√n polylog(n)Wβ` 闭合。

## SB9 实际本机检查

作者使用已有 mpmath 60位实际运行30项检查：对 `s∈{.2,.5,.9,.99}`、每个 s 的 `θ∈{min(.01,1−s),min(.2,1−s)}`、`p∈{0,s/4,s/2}`、`r=(p+s)/2`，检查 SB14 非负余量及恒等式24次，最大恒等式误差 `6.22301527786e−61`；对 θ=.1,.25,.5 和来源权 `(1,2,3)`、`(1000,1,1)`，固定 `T=(.1,.3,.7),C=(0,.2,1),w=(.9,.2,.01)`，设置 `e=Σνw,q=ΣνT,ζ=q^-1Σν C^(1/θ)T`，检查 `Σν C T^θw^(1−θ)≤(qζ)^θe^(1−θ)` 六次。容差均为 `10^-50`，返回30项 PASS。

这些是有限 scalar/共同测度 Hölder 诊断，不是 FULL 输入或一般几何证明；独立数值作者的实际核和时钟检查另行记数。交付到此停止，不扩大到新的反例或参数菜单。

最终重标度另实际运行6项60位算术检查：`(n,θ,B*)=(16,.25,.03),(512,.01,.0002),(10^6,.0001,10^-8)`，T0=.37，核对 `(exp(-nB*/θ)T0)^θ=exp(-nB*)T0^θ`，以及三价 `.2,7,100` 的共同缩放与 min 交换；绝对容差 `10^-50`，全部 PASS。它们只核重标度算术，不替代局部容量的一般证明。
