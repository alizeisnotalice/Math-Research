# R235：保负 KL 的共同 soft 容量核

**结果。** 对原每条移动腿，保 AM–GM 比较中此前舍去的负 KL，按 posterior 角度向上选 soft 节点，可以用显式 `exp[9+O(nθ²/d)]` 覆盖费构造新的目标核。全部菜单目标核的总容量≤14q，且每个 (x,y,v) 只选一个菜单节点；每个核也逐点不超过原节点核。因此原 QG、capture 和 heavy mean-fee 上界仍可使用。这只取消 ν 目标槽的 backward-soft 价格；不同 source `P_r` 的权仍须保留，不能据总容量直接删除整个菜单或后续 β source 价格。本文不宣称一般 root 付款。

## JC1 输入、原 margin 与准确命题

使用本轮合同、R234 `first_capacity.md` FC1–11 与 `spatial_geometry.md` SG1–5。原真实 receiver 集 Ω 上完整 FIRST 为

\[
 \int P_{u,A}(x-v)\nu(dv)\le P_{u,A}f(x)\le q
 \quad(u\ge s(x),\ a\le A\le b),\qquad \beta,\nu\le f\,dx.
 \tag{JC1}
\]

来源均有限，q>0，所有数据来自同一原构造，不重启 FIRST。真实当前 soft 为 s(x)。[R117 joint_geometry.md:5](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:5) 明确当前余支保 `s≤1-d_n`，其中

\[
 d_n=1000\sqrt{\log(n+2)/n},\qquad n>4\cdot10^6\log(n+2).
 \tag{JC2}
\]

故非空原余支有 `0<d_n<1/2`。这不是对输入新增特殊族。下面先对一般固定 margin `d∈(0,1]`、`s≤1-d` 证明；实际可取原 d_n。若 margin 资格在某个扩大域已被删除，须显式保 `1_{s≤1-d}`，不能向新点授予它。

定理另要求 margin 与 JC2 网格相容：`d≥sin²(Δ/2)=1-r_last`，充分条件为 `d≥1/(16n)`；原 d_n 自动满足。固定 R229 物理节点、`0<θ≤min(1/2,d)`，以及来源 y,v。对移动腿令

\[
 H_s(x;y,v)=P_{s,L^*}(x-y)^{1-\theta}P_{s,A^*}(x-v)^\theta,
 \quad A^*=L^*\ \hbox{或}\ \min(b,\gamma L^*).
\]

下面构造确定性 N 个节点与实际 source-dependent 核 `T_{r}^{ent}(x;y,v)`，使

\[
 \boxed{H_{s(x)}\le C_{n,\theta,d}\sum_r
    P_{r,L^*}(x-y)^{1-\theta}T_r^{ent}(x;y,v)^\theta,\quad
 C_{n,\theta,d}=\exp\left[9+\frac e2n\theta^2\frac{1-d}{d}\right],}
 \tag{JC3}
\]

\[
 0\le T_r^{ent}(x;y,v)\le P_{r,A^*}(x-v),\qquad
 \int T_r^{ent}(x;y,v)\nu(dv)\le q
 \quad(x\in\Omega,\ \hbox{每个固定 }y). \tag{JC4}
\]

它保留 source y 与 target v 的共同责任权，不以独立后验或 source 平均替换真实权。J 腿也有同一菜单和费用，见 JC6。

## JC2 向上 posterior 角菜单

令

\[
 N=\lceil\pi\sqrt n\rceil,\quad\Delta=\pi/(2N),\quad
 \beta_i=(i+1/2)\Delta,\quad r_i=\sin^2\beta_i\quad(0\le i<N).
\]

考虑有限非负 affine 系数与权
`F_s=∏[(1-s)a_i+s b_i]^{λ_i}`，总权重 m≤n。零指数忽略；全族零时不需估计。对 `0<s<1,F_s>0`，定义其 **soft 责任比例**

\[
 \varpi=\frac1m\sum_i\lambda_i
       \frac{s b_i}{(1-s)a_i+s b_i}\in[0,1].
\]

它是这些 affine 因子的代数责任参数，不是原 clock 后验 Π，也不是原输入 soft selector。m=0 时恒定族单独处理。

设 α=arcsin√varpi，选择首个 `β_i≥α`；若不存在则选最后节点。此选取由显式有限阈值给出可测规则。于是 `|α-β_i|≤Δ`。Taylor 与 `sinβ_i cosβ_i≥Δ/π` 给

\[
 \frac{|\varpi-r_i|}{\sqrt{r_i(1-r_i)}}
 \le2|\alpha-\beta_i|+\pi|\alpha-\beta_i|^2/\Delta
 \le(2+\pi)\Delta<6\Delta.
\]

由 `D(p||r)≤(p-r)^2/[r(1-r)]` 及 `nΔ²≤1/4`，

\[
 mD(\varpi\Vert r_i)\le9. \tag{JC5}
\]

加权 AM–GM 的原精确增益为

\[
 \frac{F_{r_i}}{F_s}\ge
 \exp\{m[D(\varpi\Vert s)-D(\varpi\Vert r_i)]\},\qquad
 F_s\le e^9e^{-mD(\varpi\Vert s)}F_{r_i}. \tag{JC6}
\]

所有系数有限，0<s<1 时非零 affine 因子正，故无 `0×∞`。s=0 且 F_0>0 时责任比例连续取0，端点公式按极限成立；实际原余支本身还有 strictsoft 下界。

重要的单向性质是：若 `varpi≤r_last`，选取给 `r_i≥varpi`；若 `varpi>r_last`，选取给 `r_i=r_last`。因

\[
 1-r_{last}=\sin^2(\Delta/2)\le1/(16n),
\]

只要 `d≥1/(16n)`，实际 s≤1-d 就确保 `s≤r_last`。原 d_n 显然满足这个充分条件。因此 **r_i<s 只可能发生在 `varpi≤r_i<s`**；没有 rounding 引起的额外 `θ√n` backward 费用。

## JC3 负 KL 支付 backward-FIRST 的精确标量价

记 q_s=1-s（区别原共同 q），并定义

\[
 t=\theta/q_s,\qquad
 B_\theta(s)=ts+\log(q_s+s e^{-t})\ge0.
 \tag{JC7}
\]

当 `varpi≤r<s` 时，`log((1-r)/q_s)≤log((1-varpi)/q_s)≤(s-varpi)/q_s`。Bernoulli 熵的精确倾斜公式给

\[
 \boxed{\theta\log\frac{1-r}{1-s}-D(\varpi\Vert s)
 \le B_\theta(s).} \tag{JC8}
\]

证明：令 `p_*=s e^{-t}/(q_s+s e^{-t})`，则
`ts-tvarpi-D(varpi||s)=B_θ(s)-D(varpi||p_*)≤B_θ(s)`。这是同一 varpi 的增益与同一 backward r 的费用，没有分别取两个 sup。

若 `θ≤1-s`，令 `K(u)=us+log(q_s+s e^{-u})`。`K(0)=K'(0)=0`，且 `0≤u≤t≤1` 上

\[
 K''(u)=\frac{s q_s e^{-u}}{(q_s+s e^{-u})^2}
 \le e\,s q_s.
\]

因此

\[
 \boxed{B_\theta(s)\le\frac e2\frac{\theta^2s}{1-s}
 \le B_{max}:=\frac e2\theta^2\frac{1-d}{d}.} \tag{JC9}
\]

JC7–8 的精确式不要求 θ≤1-s；只是统一二次价 JC9 需要 θ≤d。没有在更大 θ 上免费使用该二次界。

还可保 backward 支的**非负真实余量**

\[
 R=D(\varpi\Vert p_*)
 +\theta\left[\frac{s-\varpi}{q_s}-\log\frac{1-\varpi}{q_s}\right]
 +\theta\log\frac{1-\varpi}{1-r}\ge0,
\]

并有精确等式 `θlog((1-r)/q_s)-D(varpi||s)=B_θ(s)-R`。三项分别来自原同一责任参数的倾斜、log≤线性与向上节点，均可保在真实联合权中。

## JC4 有容量的真实目标核及覆盖证明

对每个节点 r，原有价 future-FIRST 权为

\[
 \chi_r(s)=\begin{cases}1,&r\ge s,\\
 ((1-r)/(1-s))^n,&r<s.
 \end{cases}
 \qquad\int P_{r,A^*}(x-v)\nu(dv)\le q\chi_r(s(x)). \tag{JC10}
\]

后者使用完整 FIRST 和逐坐标 `f_r≤[(1-r)/(1-s)]f_s`，不是给 backward 节点新授 FIRST。它只在原实际 Ω 上使用，A*仍是合法物理尺度。

移动两腿的 affine 总权重 **恰为 n**。令 `I_r` 为 JC2 的实际选中节点指示，保

\[
 A_r=I_r\exp\left\{n\left[
 \theta\log_+\frac{1-r}{1-s}-D(\varpi\Vert s)-B_{max}\right]\right\}.
 \tag{JC11}
\]

由 JC8–9，`0≤A_r≤1`。forward 支 exponent 为 `-nD-nBmax≤0`；backward 支可精确保为 `n[B_θ(s)-Bmax-R]`。定义

\[
 \boxed{T_r^{ent}(x;y,v)=A_r(x;y,v)^{1/\theta}
                 \frac{P_{r,A^*}(x-v)}{\chi_r(s(x))}.} \tag{JC12}
\]

由于 χ≥1、A_r≤1，JC4 的点态支配成立；固定 x,y 后，JC10 又给 `∫T_r^{ent}ν≤q`。这保 source-dependent A_r 在其原来的 ν 积分中，不把它独立化。JC6 代入 JC11–12，先估唯一选中节点，再上放有限和，恰得 JC3。因 1/θ>0，A_r=0 时目标核取0，无除零。

## JC5 QG、hard cap 与 actual mean fee 的合法接口

在固定物理节点上，`T_r^{ent}≤P_{r,A^*}`，所以 R234 的共同 hard-window QG、capture 插值上界依然作为正上界成立；不要求新目标核本身是 normalized φ 密度。对同一个原 hard 来源 z、原 Ω 和已认证 capture 支持 G，定义

\[
 \alpha_r^{ent}(y,v)=\int_\Omega G(x;y,v)
 P_{r,L^*}(x-y)^{1-\theta}T_r^{ent}(x;y,v)^\theta dx,
 \quad m_r^{ent}(y)=\int(\alpha_r^{ent})^{1/\theta}\nu(dv).
\]

由于目标核逐点减小，`α_r^{ent}≤α_r^{old}≤1`、`m_r^{ent}≤m_r^{old}`。相同原 Ω 的一次 hard cap 与未用 hard cap 的 QG 是替代上界，不能乘收益。modified 列仍是 static：原 selector s(x)、责任分配、capture 支持、A_r 与 χ 不依辅助 clock t。因此可以合法放进 R234 general-θ growing-floor mean fee，不扩大过程有效域，也不改后验 Π。

更细地，保实际容量响应

\[
 \zeta_r(x,y)=q^{-1}\int T_r^{ent}(x;y,v)\nu(dv)\in[0,1].
\]

Minkowski 直接给一个有价 joint 改进：

\[
 \boxed{m_r^{ent}(y)^\theta
 \le q^\theta\int_\Omega P_{r,L^*}(x-y)^{1-\theta}
                                      \zeta_r(x,y)^\theta dx.} \tag{JC13}
\]

再对真实有限 β 用 Hölder，若使用 source-node 的 FC8 容量，只能得

\[
 \int m_r^{ent}(y)^\theta\beta(dy)
 \le q\int_\Omega\chi_r(s(x))^{1-\theta}
                 \left[\int\zeta_r(x,y)\beta(dy)\right]^\theta dx.
 \tag{JC14}
\]

**source 槽的 backward χ 仍在。** 同一负 KL 已支付目标 ν 槽的 χ^θ，不能再用一次来删去 source β 槽的 χ^{1-θ}。JC13 及 ζ 保留精确 y,v 共选；JC14 是可选正放松，不保证是最优付款。共同 Ω 上所有非负积分允许∞，由有限截断单调极限证明；β=0 时原含 β 量直接取零，不写 `0×∞`。

## JC5a 全菜单目标容量的高斯格点预算

更强的结论是：对每个固定实际 x、原来源 y、物理节点及**一条固定移动腿**，

\[
 \boxed{\sum_r\int T_r^{ent}(x;y,v)\nu(dv)\le14q.} \tag{JC15}
\]

先看 soft 责任角的选中格。取闭包不改变下面 inf 上界：首格为 `[0,β_0]`，中间格为 `[β_{i-1},β_i]`，末格为 `[β_{N-2},π/2]`；它们的长度分别是 `Δ/2,Δ,3Δ/2`。边界实际归属仍按 JC2 的确定规则。记其在责任概率轴上的像为 I_r。

由 JC11–12，目标核也可精确写为

\[
 T_r^{ent}=1_{\{selected\ r\}}
 \exp\{-n[D(\varpi\Vert s)+B_{max}]/\theta\}\,P_{r,A^*}.
\]

若 r≥s，直接用合法 future FIRST 得
`∫T_r^{ent}ν≤q exp[-n inf_{p∈I_r}D(p||s)/θ]`。若 r<s，由上选格与 margin，整个选中格都满足 p≤r<s。JC3 中未丢弃 KL 的线性倾斜式给

\[
 \theta\log\frac{1-r}{1-s}-D(p\Vert s)
 \le B_\theta(s)-D(p\Vert s_*)\le B_{max}-D(p\Vert s_*),
 \quad s_* =\frac{s e^{-\theta/(1-s)}}{1-s+s e^{-\theta/(1-s)}}.
\]

因此 backward 部分有 `∫T_r^{ent}ν≤q exp[-n inf_{p∈I_r}D(p||s_*)/θ]`。按 r≥s 或 r<s 分的两个格子族不需要各自对称，也不把跨过 s 的某个格换归另一中心；分别扩大到全部格子即可。

对任意中心 u∈[0,1]，写其角为 α_u。Jensen 给 Bernoulli

\[
 D(p\Vert u)\ge-2\log\left(\sqrt{pu}+\sqrt{(1-p)(1-u)}\right)
 =-2\log\cos(\alpha_p-\alpha_u)\ge(\alpha_p-\alpha_u)^2.
\]

最后一步由 `tan t≥t` 积分得出。对包含 α_u 的格及其至多两个相邻格各收1；其后每侧第 k 个格到 α_u 的距离至少 kΔ。所以

\[
 \sum_r e^{-(n/\theta)\operatorname{dist}(\alpha_u,I_r^{angle})^2}
 \le3+2\sum_{k\ge1}e^{-(n\Delta^2/\theta)k^2}
 \le3+2\sqrt\pi<7. \tag{JC16}
\]

这里 `nΔ²≥1/8`：`N≤π√n+1≤(5/4)π√n` 对 n≥2 成立，甚至给4/25；θ≤1/2 故 `nΔ²/θ≥1/4`。单调高斯尾满足 `Σ_{k≥1}e^{-a k²}≤∫_0^∞e^{-a t²}dt≤√π`。首格/末格的特殊长度不影响“中心格及邻格收3、其后距离≥kΔ”的计数。对 s 与 s_* 两中心相加得到 JC15，含端点的∞ KL 按 `e^{-∞}=0` 处理。

JC15 是每条 moving leg 的独立界；两条 moving legs 一起只能据此授28q。实际 J 腿的责任参数只来自 `P_{s,L^*}(x-y)`，固定 x,y 后不依 v，因此只有一个 soft 节点被选中，全部 J 菜单目标核总容量≤q。三腿直接相加是≤29q，不能误写为14q。

原 capture/history 的静态权若在目标核中再乘 `C(x;y,v)^{1/θ}`、`0≤C≤1`，容量只缩小。这是保同一 source y 的真实联合预算；不需要 ν 后验或独立参考源。尽管目标总容量已由 Nq 降到14q，source 因子 `P_{r,L^*}(x-y)` 随 r 不同；没有进一步共同控制它们，不能从 JC15 直接删去整个菜单 N。

## JC6 J 腿、全部尺度和明确费用

第三腿 `H_s=P_{s,L^*}^{1-θ}J^θ` 的 affine 总权重为 `m=n(1-θ)`，target J 的 FIRST 容量直接≤q，没有 backward χ 费用。用同一 posterior 角菜单，JC5–6 仍给 rounding≤9；可取 `A_r=I_r exp[-mD(varpi||s)-nBmax]`、`T_r^{ent}=A_r^{1/θ}J`，得到同一 JC3–4。**不**把移动腿 m=n 的 scalar 指数证明原样用于任意 m；J 腿是因为 target χ=1 才直接成立。

原物理覆盖仍由 R234 FC2–3 给 e^4，原 good 仍为外 `2Λ(K/3)^θ`；三腿、两朝向和 N 个共同节点照实保留。新 soft 覆盖费由 R234 的 e 改成 `C_{n,θ,d}`，没有 N²。原实际 s≤1-d、hardband、high、good/bad、capture、suffix/history 与已付支补集只能按原资格保留或正上放；不在新节点重算它们。G 必须是已认证 static 支持，不能把依 t 的原历史伪装成 static 系数。

当 `nθ²/d` 有界时，新增覆盖常数有明确界，目标核却获得逐点实际 FIRST 容量 q，并保 QG 支配；这量化消除了过粗的 target-node χ。θ 若依原叶预先选取，所有因子仍须与该选择一起进入主线节点求和。这里没有无价赋予新的 θ 选择，不声称对所有 θ 的常数仍同 R234。

**未付步骤。** 要获一般 `εX+C√n n^{o(1)}W`，仍须估 JC13 的真实 joint receiver/source 费用，或证明 JC14 中剩余 source χ 与实际 ζ 的共同付款；仅 ζ≤1、普通 β-FIRST 或旧 `P≤4X` 都没有给小 ε。本文不把 ζ 或 m 改名为免费预算，不宣布来源 log moment 已付。原 mean-fee 还保 `C_0/(2θ)`、heavyfloor、真实 clock/node/j 和全部外因子，主作者稿负责其完整回代。本有界辅助结果止于 JC3–16。

## JC7 实际有限验证

本机已有 mpmath 60位实际验证 n=2,16,512、41个责任比例、3个实际 s、4个 θ 的向上菜单 rounding、精确 JC8 与满足条件时的 JC9，共2829项断言全部 PASS；最大 `nD(varpi||r)` 约0.5229314836，最大 `B/二次界` 约0.4045070513。又对 n=2,16,512,10^6 实际核对 cell KL 单中心和及按 backward/future 两中心划分的和，100项全部 PASS，最大单中心和约3.0784425269，最大混合和约4.6934571190。合并脚本共2929项。仅为有限 scalar/grid/cell 诊断，不是向外舍入证书或 FULL 输入。一般结论由以上证明承担。

复现代码（本机使用已有 vendor `PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor`）：

```python
import mpmath as mp
mp.mp.dps=60
checks=0; max_round=mp.mpf(0); max_scalar=mp.mpf(0)
def KL(p,q):
    return (p*mp.log(p/q) if p else 0)+((1-p)*mp.log((1-p)/(1-q)) if p!=1 else 0)
for n in (2,16,512):
    N=int(mp.ceil(mp.pi*mp.sqrt(n))); D=mp.pi/(2*N)
    angles=[(i+mp.mpf('.5'))*D for i in range(N)]
    nodes=[mp.sin(a)**2 for a in angles]
    for p in [mp.mpf(j)/40 for j in range(41)]:
        al=mp.asin(mp.sqrt(p))
        idx=next((i for i,a in enumerate(angles) if a>=al),N-1); r=nodes[idx]
        val=n*KL(p,r); max_round=max(max_round,val)
        assert val<=9+mp.mpf('1e-50'); checks+=1
        for s in (mp.mpf('.1'),mp.mpf('.5'),mp.mpf('.8')):
            assert s<=nodes[-1]
            for th in (mp.mpf('.01'),mp.mpf('.1'),mp.mpf('.25'),mp.mpf('.5')):
                q=1-s; a=th/q; B=a*s+mp.log(q+s*mp.exp(-a))
                penalty=th*max(mp.mpf(0),mp.log((1-r)/q))-KL(p,s)
                assert penalty<=B+mp.mpf('1e-50'); checks+=1
                if th<=q:
                    upper=mp.e/2*th**2*s/q
                    assert B<=upper+mp.mpf('1e-50'); checks+=1
                    max_scalar=max(max_scalar,B/upper)
largest_one=mp.mpf(0); largest_partition=mp.mpf(0)
for n in (2,16,512,1000000):
    N=int(mp.ceil(mp.pi*mp.sqrt(n))); delta=mp.pi/(2*N)
    betas=[(i+mp.mpf('.5'))*delta for i in range(N)]
    nodes=[mp.sin(a)**2 for a in betas]
    cells=[(mp.mpf(0) if i==0 else betas[i-1],
            mp.pi/2 if i==N-1 else betas[i]) for i in range(N)]
    assert n*delta**2>=mp.mpf(1)/8; checks+=1
    for theta in (mp.mpf('.01'),mp.mpf('.1'),mp.mpf('.5')):
      for s in (mp.mpf('.1'),mp.mpf('.5'),mp.mpf('.8')):
        if s>nodes[-1] or theta>1-s: continue
        tilt=s*mp.exp(-theta/(1-s))/(1-s+s*mp.exp(-theta/(1-s)))
        values=[]
        for center in (s,tilt):
          angle=mp.asin(mp.sqrt(center)); vals=[]
          for lo,hi in cells:
            p=mp.sin(min(hi,max(lo,angle)))**2
            vals.append(mp.exp(-n*max(mp.mpf(0),KL(p,center))/theta))
          assert sum(vals)<7; checks+=1
          largest_one=max(largest_one,sum(vals)); values.append(vals)
        part=sum(values[0][i] if nodes[i]>=s else values[1][i] for i in range(N))
        assert part<14; checks+=1
        largest_partition=max(largest_partition,part)
print({'mpmath_dps':mp.mp.dps,'assertions':checks,
       'max_nKL_round':mp.nstr(max_round,18),
       'max_B_over_quadratic':mp.nstr(max_scalar,18),
       'max_one_center':mp.nstr(largest_one,18),
       'max_partition':mp.nstr(largest_partition,18),'result':'PASS',
       'scope':'finite scalar/grid/cell diagnostics, not interval or FULL'})
```

实际返回 `assertions=2929,result=PASS`。独立数值作者另做主稿要求的候选压力检查，本文不预报其结果。
