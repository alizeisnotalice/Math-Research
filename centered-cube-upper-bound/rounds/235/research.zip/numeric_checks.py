#!/usr/bin/env python3
"""R235 bounded entropy/backward-fee, original-shaped capacity, and static-capture clocks."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent

def m(x):
 x=F(x);return mp.mpf(x.numerator)/x.denominator

def KL(p,q):
 if q==0:return mp.mpf(0) if p==0 else mp.inf
 if q==1:return mp.mpf(0) if p==1 else mp.inf
 if p==0:return -mp.log1p(-q)
 if p==1:return -mp.log(q)
 return p*mp.log(p/q)+(1-p)*mp.log((1-p)/(1-q))

def Btheta(s,theta):
 if not s:return mp.mpf(0)
 a=theta/(1-s);return a*s+mp.log1p(s*mp.expm1(-a))

def grid(n,p):
 N=int(mp.ceil(mp.pi*mp.sqrt(n)));step=mp.pi/(2*N);last=mp.sin((N-mp.mpf('.5'))*step)**2;angle=mp.asin(mp.sqrt(p));j=max(0,min(N-1,int(mp.ceil(angle/step-mp.mpf('.5')))));r=mp.sin((j+mp.mpf('.5'))*step)**2
 return N,j,r,last

def nonlinear_opt(s,theta,dps):
 if not s:return mp.mpf(0)
 lo,hi=mp.mpf(0),s
 for _ in range(4*dps):
  p=(lo+hi)/2
  if p==lo or p==hi:break
  deriv=-theta/(1-p)-mp.log(p/(1-p))+mp.log(s/(1-s))
  if deriv>0:lo=p
  else:hi=p
 return (lo+hi)/2

def cover_menu():
 rows=[]
 for n in (2,16):
  for s in ('0','3/4'):
   for p in ('0','1/5','4/5','1'):rows.append({'stage':'initial','n':n,'s':s,'d':'1/4','theta':'1/8','p':p,'family':'pure'})
 for n in (512,4096):
  for theta in ('1/10','1/100'):
   for p in ('0','9/10','1','p_linear_opt','p_nonlinear_opt'):rows.append({'stage':'stress','n':n,'s':'9/10','d':'1/10','theta':theta,'p':p,'family':'pure'})
 for theta in ('1/1000','1/10000'):
  for p in ('0','999/1000','1','p_linear_opt','p_nonlinear_opt'):rows.append({'stage':'expanded','n':1000000,'s':'999/1000','d':'1/1000','theta':theta,'p':p,'family':'pure'})
 for n in (2,512,1000000):
  for s in ('1/2','3/4'):
   for family in ('mixed','zero_lambda','constant','zero_family'):rows.append({'stage':'general_coefficients','n':n,'s':s,'d':'1/4','theta':'1/10','family':family})
 return rows

def cover(c,dps):
 with mp.workdps(dps):
  n=c['n'];s=m(c['s']);theta=m(c['theta']);d=m(c['d']);assert 0<=s<=1-d and 0<theta<=d
  if c['family']=='pure':
   p=(s*mp.exp(-theta/(1-s))/(1-s+s*mp.exp(-theta/(1-s)))) if c['p']=='p_linear_opt' else nonlinear_opt(s,theta,dps) if c['p']=='p_nonlinear_opt' else m(c['p']);aa=[mp.mpf(0),mp.mpf(1)];bb=[mp.mpf(1),mp.mpf(0)];lam=[n*p,n*(1-p)]
  elif c['family']=='mixed':aa=list(map(m,('1/100','3','0','2')));bb=list(map(m,('4','0','1/7','2')));lam=[mp.mpf(n)/9]*3+[mp.mpf(2*n)/3]
  elif c['family']=='zero_lambda':aa=list(map(m,('1','0','3')));bb=list(map(m,('0','0','2')));lam=[mp.mpf(n)/3,mp.mpf(0),mp.mpf(2*n)/3]
  elif c['family']=='constant':aa=list(map(m,('2','0','1')));bb=aa.copy();lam=[mp.mpf(n)/4,mp.mpf(0),mp.mpf(3*n)/4]
  else:aa=[mp.mpf(0),mp.mpf(1)];bb=[mp.mpf(0),mp.mpf(2)];lam=[mp.mpf(n)/2]*2
  vals=[(1-s)*a+s*b for a,b in zip(aa,bb)];zero=any(l>0 and v==0 for l,v in zip(lam,vals));N,_,_,last=grid(n,mp.mpf(0));assert last>=1-d
  if zero:return {'configuration':c,'N':N,'Fs_zero_trivial_branch':True,'bound_holds':True}
  p=sum(l*s*b/v for l,b,v in zip(lam,bb,vals) if l>0)/n;N,j,r,last=grid(n,p)
  logHs=sum(l*mp.log(v) for l,v in zip(lam,vals) if l>0);logHr=sum(l*mp.log((1-r)*a+r*b) for l,a,b in zip(lam,aa,bb) if l>0);logratio=logHs-logHr;logchi=n*mp.log((1-r)/(1-s)) if r<s else mp.mpf(0)
  assert r>=s or r>=p-mp.mpf(10)**(-dps+8)
  Dpr=KL(p,r);Dps=KL(p,s) if s>0 else mp.mpf(0);gain=n*(Dpr-Dps);B=Btheta(s,theta);coarse=mp.e*theta*theta*s/(2*(1-s));combined=logratio+theta*logchi;tol=mp.mpf(10)**(-dps+9)*max(1,n,abs(combined),abs(gain));assert logratio<=gain+tol and n*Dpr<=9+tol and combined<=9+n*B+tol and B<=coarse+tol
  return {'configuration':c,'N':N,'chosen_upward_index':j,'r':mp.nstr(r,32),'posterior_p':mp.nstr(p,32),'last_midnode':mp.nstr(last,32),'Fs_zero_trivial_branch':False,'log_Hs_over_Hr':mp.nstr(logratio,32),'log_chi':mp.nstr(logchi,32),'theta_log_chi':mp.nstr(theta*logchi,32),'negative_KL_gain_nDps':mp.nstr(n*Dps,32),'grid_nDpr':mp.nstr(n*Dpr,32),'AMGM_entropy_upper_for_log_ratio':mp.nstr(gain,32),'Btheta':mp.nstr(B,32),'n_Btheta':mp.nstr(n*B,32),'combined_log_ratio_after_chi':mp.nstr(combined,32),'bound_9_plus_nB':mp.nstr(9+n*B,32),'margin':mp.nstr(9+n*B-combined,32),'coarse_B_bound':mp.nstr(coarse,32),'backward_node':r<s,'scope':'Finite general-affine family, m=n; exact scalar/Bernoulli formulas evaluated by ordinary highprecision, not FULL or interval proof.'}

def scalar_menu():
 return [{'s':s,'theta':theta,'p_kind':p} for s,theta in (('0','1/2'),('1/100','1/100'),('1/2','1/10'),('9/10','1/10'),('999/1000','1/1000'),('999/1000','1/10000')) for p in ('zero','same','linear_opt','nonlinear_opt')]

def scalar(c,dps):
 with mp.workdps(dps):
  s=m(c['s']);theta=m(c['theta']);assert theta<=1-s
  if not s:p=mp.mpf(0)
  elif c['p_kind']=='zero':p=mp.mpf(0)
  elif c['p_kind']=='same':p=s
  elif c['p_kind']=='linear_opt':p=s*mp.exp(-theta/(1-s))/(1-s+s*mp.exp(-theta/(1-s)))
  else:
   lo,hi=mp.mpf(0),s
   for _ in range(4*dps):
    p=(lo+hi)/2
    if p==lo or p==hi:break
    deriv=-theta/(1-p)-mp.log(p/(1-p))+mp.log(s/(1-s))
    if deriv>0:lo=p
    else:hi=p
   p=(lo+hi)/2
  value=theta*mp.log((1-p)/(1-s))-(KL(p,s) if s else 0);B=Btheta(s,theta);coarse=mp.e*theta*theta*s/(2*(1-s));tol=mp.mpf(10)**(-dps+8);assert value<=B+tol and B<=coarse+tol
  return {'configuration':c,'p':mp.nstr(p,32),'nonlinear_scalar_value':mp.nstr(value,32),'exact_linearized_variational_B':mp.nstr(B,32),'coarse_e_half_bound':mp.nstr(coarse,32),'margin_B_minus_nonlinear':mp.nstr(B-value,32)}

def phi(x):
 x=abs(x);h=mp.mpf('.5')
 def E3(t):return h if not t else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
 return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def psoft(x,s):return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi(x)
def phi_primitive(x):
 h=mp.mpf('.5');sg=mp.sign(x);t=abs(x)
 return x-mp.expint(4,h-x)+mp.expint(4,h+x) if t<=h else sg*(h-mp.expint(4,t-h)+mp.expint(4,t+h))

def capacity_row(n,index,dps):
 with mp.workdps(dps):
  s=mp.mpf(1)/3;N=int(mp.ceil(mp.pi*mp.sqrt(n)));j=(0 if index=='first' else N//2 if index=='middle' else N-1);r=mp.sin((j+mp.mpf('.5'))*mp.pi/(2*N))**2;eps=mp.mpf(1)/20;x=mp.mpf(1)/5;masses=list(map(m,('1','2','1/7')));centers=list(map(m,('0','3/5','7/5')));hard=[];soft=[]
  for v in centers:
   lo=x-v-eps;hi=x-v+eps;hard.append(max(mp.mpf(0),min(hi,mp.mpf('.5'))-max(lo,-mp.mpf('.5')))/(2*eps));soft.append((phi_primitive(hi)-phi_primitive(lo))/(2*eps))
  def cap(t):return sum(nu*((1-t)*h+t*f)**n for nu,h,f in zip(masses,hard,soft))
  cs,c1,cr=cap(s),cap(mp.mpf(1)),cap(r);q=mp.mpf(5)/2*max(cs,c1);logchi=n*mp.log((1-r)/(1-s)) if r<s else mp.mpf(0);Qr=(2*cr+c1)/3;normalized=Qr*mp.exp(-logchi);assert normalized<=q and 2*max(cs,c1)<q
  return {'n':n,'source':'nu=sum masses times uniform cubes with halfside1/20 and homogeneous centers; f=2nu,beta=nu','masses_exact':['1','2','1/7'],'homogeneous_centers_exact':['0','3/5','7/5'],'receiver_all_x':'1/5','a_b_L':'1','s_actual':'1/3','N':N,'chosen_index':j,'r':mp.nstr(r,32),'Q_r_definition':'(2P_r,1+P_1,1)/3','q_fixed':mp.nstr(q,32),'original_f_soft_s_capacity':mp.nstr(2*cs,32),'original_f_soft_1_capacity':mp.nstr(2*c1,32),'Q_r_nu_raw':mp.nstr(Qr,32),'log_chi':mp.nstr(logchi,32),'normalized_target_capacity':mp.nstr(normalized,32),'normalized_capacity_over_q':mp.nstr(normalized/q,32),'original_FIRST_margin':mp.nstr(q-2*max(cs,c1),32),'backward_branch':r<s,'future_qualification':'At fixed A=1 all source cube contributions are mass*(positive affine soft average)^n, hence convex; soft s and1 endpoints control all future. a=b=1 only.','scope':'True finite L1 source density and single receiver row, original/future soft capacity explicit; no global Omega/history/FULL qualification.'}

def S_integral(y,theta_text,index,dps):
 with mp.workdps(dps):
  n=16;N=int(mp.ceil(mp.pi*mp.sqrt(n)));j=(0 if index=='first' else N//2 if index=='middle' else N-1);r=mp.sin((j+mp.mpf('.5'))*mp.pi/(2*N))**2;theta=m(theta_text);yy=m(y)
  value=mp.quad(lambda x:psoft(x-yy,r)**(1-theta),[-mp.mpf('.25'),mp.mpf('.25')]);ratios={rho:mp.nstr(value/m(rho)**theta,32) for rho in ('1','1e6','1e100')}
  assert value<=mp.mpf('.5')**theta
  return {'y':y,'theta_exact':theta_text,'a_L':'1','Omega':'[-1/4,1/4]','grid_n':n,'N':N,'chosen_index':j,'r':mp.nstr(r,32),'S_y':mp.nstr(value,32),'S_over_rho_to_theta':ratios,'holder_volume_bound':mp.nstr(mp.mpf('.5')**theta,32),'scope':'Actual 1D finite receiver integral, ordinary quadrature; ratios only compare old/new prices, not FULL or same-input realization of all other gates.'}

def zeta_clock(n,theta_text,dps,joint=False):
 with mp.workdps(dps):
  theta=m(theta_text);C0=mp.mpf(16)/3;s=mp.mpf(1)/3;N=int(mp.ceil(mp.pi*mp.sqrt(n)));j=N//3;r=mp.sin((j+mp.mpf('.5'))*mp.pi/(2*N))**2;logchi=n*mp.log((1-r)/(1-s)) if r<s else mp.mpf(0);masses=list(map(m,('1','2','3','1/7')));alphas=list(map(m,('3/5','4/5','11/20','19/20')));distances=list(map(m,('0','2/5','4/5','3/2')));captures=list(map(m,('1','1/2','0','3/4')));deletes=[None,None,F(3,4),F(17,20)]
  selected=[r]*4;Pselected=[mp.mpf(1)]*4;Psharp=mp.mpf(1);Bmax=mp.mpf(0)
  if joint:
   qt=s*phi(mp.mpf('.49'))/psoft(mp.mpf('.49'),s);Bmax=mp.e*theta*theta*s/(2*(1-s));target=[]
   for i,distance in enumerate(distances):
    qs=s*phi(distance)/psoft(distance,s);posterior=(1-theta)*qt+theta*qs;_,_,rr,_=grid(n,posterior);selected[i]=rr;target.append(mp.exp(-n*(KL(posterior,s)+Bmax)/theta)*psoft(distance,rr)**n);Pselected[i]=psoft(mp.mpf('.49'),rr)**n
   Psharp=max(psoft(mp.mpf('.49'),mp.sin((k+mp.mpf('.5'))*mp.pi/(2*N))**2)**n for k in range(N))
  else:target=[psoft(d,r)**n*mp.exp(-logchi) for d in distances]
  cap=sum(nu*T for nu,T in zip(masses,target));original=max(2*sum(nu*psoft(d,t)**n for nu,d in zip(masses,distances)) for t in (s,mp.mpf(1)));hard=sum(nu for nu,d in zip(masses,distances) if d<=mp.mpf('.5'));q=mp.mpf(5)/4*max(original,hard/C0);zeta=sum(nu*C**(1/theta)*T for nu,C,T in zip(masses,captures,target))/q;dR=hard/(C0*q);assert cap<=(14 if joint else 1)*q and dR<=1
  ell=1+mp.log(n);tau=mp.mpf('.5');A=ell*q*tau**n;wstar=[a**n for a in alphas];Fcost=[P**(1-theta)*C*T**theta/w**theta for P,C,T,w in zip(Pselected,captures,target,wstar)];knots=sorted(set([tau,mp.mpf(1)]+alphas+[m(d) for d in deletes if d]));pair=mp.mpf(0);score=mp.mpf(0)
  for lo,hi in zip(knots,knots[1:]):
   mid=(lo+hi)/2;alive=[i for i in range(4) if deletes[i] is None or mid<m(deletes[i])];ks={i:n if alphas[i]<mid else 0 for i in alive}
   def weights(t):return {i:masses[i]*min(1,alphas[i]/t)**n for i in alive}
   def gap(t):return sum(weights(t).values())-A*(t/tau)**n
   stop=lo
   if gap(lo)>0:
    if gap(hi)>=0:stop=hi
    else:
     a,b=lo,hi
     for _ in range(4*dps):
      z=(a+b)/2
      if z==a or z==b:break
      if gap(z)>0:a=z
      else:b=z
     stop=(a+b)/2
   if stop>lo:
    def fun(u,pair_mode):
     ws=weights(mp.exp(u));e=sum(ws.values());Pi={i:w/e for i,w in ws.items()}
     if pair_mode:return sum(Pi[i]*Pi[k]*Fcost[i]*max(ks[i]-ks[k],0) for i in alive for k in alive)
     return sum(Pi[i]*Fcost[i]*ks[i] for i in alive)
    pair+=mp.quad(lambda u:fun(u,True),[mp.log(lo),mp.log(stop)]);score+=mp.quad(lambda u:fun(u,False),[mp.log(lo),mp.log(stop)])
  z=n*mp.log(2);bound=Psharp**(1-theta)*(q*zeta/A)**theta*2**(theta*n)*(-mp.expm1(-2*theta*z))/(2*theta);tol=mp.mpf(10)**(-dps+9)*max(1,abs(bound));assert pair<=score+tol and score<=bound+tol
  return {'joint_entropy_disjoint_case':joint,'selected_soft_by_source':[mp.nstr(v,32) for v in selected],'Psharp':mp.nstr(Psharp,32),'Bmax':mp.nstr(Bmax,32),'capacity_multiplier_allowed':14 if joint else 1,'n':n,'theta_exact':theta_text,'actual_target_soft_r':None if joint else mp.nstr(r,32),'actual_soft_s':'1/3','log_chi':None if joint else mp.nstr(logchi,32),'target_hat_values':[mp.nstr(v,32) for v in target],'source_masses_exact':['1','2','3','1/7'],'static_capture_exact':['1','1/2','0','3/4'],'q':mp.nstr(q,32),'target_capacity_over_q':mp.nstr(cap/q,32),'zeta':mp.nstr(zeta,32),'q_times_zeta':mp.nstr(q*zeta,32),'d_R_hard_over_C0q':mp.nstr(dR,32),'heavy_A':mp.nstr(A,32),'actual_pair_heavy_integral':mp.nstr(pair,32),'score_majorant_integral':mp.nstr(score,32),'capacity_zeta_bound':mp.nstr(bound,32),'pair_over_bound':mp.nstr(pair/bound,32),'scope':'Real kernel target-hat row but finite source atoms/static capture; full current posteriors and actual heavy floor. q,zeta and d_R are explicit. Tests the tool, not original FIRST/history/FULL.'}

def prec(a,b,key):
 with mp.workdps(70):
  err=abs(mp.mpf(a[key])-mp.mpf(b[key]))/max(1,abs(mp.mpf(b[key])));assert err<mp.mpf('1e-25');return mp.nstr(err,16)

def cells_menu():
 return [{'n':n,'s':s,'theta':theta} for n in (2,16,512,1000000) for s,theta in (('0','1/2'),('0','1/10'),('1/2','1/2'),('1/2','1/10'),('9/10','1/10'),('9/10','1/100'),('999/1000','1/1000'),('999/1000','1/10000'))]

def cells(c,dps):
 with mp.workdps(dps):
  n=c['n'];s=m(c['s']);theta=m(c['theta']);N=int(mp.ceil(mp.pi*mp.sqrt(n)));Delta=mp.pi/(2*N);a=theta/(1-s);sa=s*mp.exp(-a)/(1-s+s*mp.exp(-a));totals=[];partition=mp.mpf(0)
  for center_index,center in enumerate((s,sa)):
   ca=mp.asin(mp.sqrt(center));total=mp.mpf(0)
   for j in range(N):
    lo=mp.mpf(0) if j==0 else (j-mp.mpf('.5'))*Delta;hi=mp.pi/2 if j==N-1 else (j+mp.mpf('.5'))*Delta;projected=mp.sin(min(hi,max(lo,ca)))**2;D=KL(projected,center);w=mp.exp(-n*D/theta) if mp.isfinite(D) else mp.mpf(0);total+=w;r=mp.sin((j+mp.mpf('.5'))*Delta)**2
    if (center_index==1 and r<s) or (center_index==0 and r>=s):partition+=w
   totals.append(total)
  assert all(t<7 for t in totals) and partition<14 and n*Delta*Delta>=mp.mpf(1)/8
  return {'configuration':c,'N':N,'n_Delta_squared':mp.nstr(n*Delta*Delta,32),'future_center_s_sum':mp.nstr(totals[0],32),'backward_center_sa_sum':mp.nstr(totals[1],32),'actual_direction_partition_sum':mp.nstr(partition,32),'per_center_bound':7,'per_moving_leg_bound':14,'two_moving_plus_J_bound':29,'scope':'One-sided cells including enlarged last cell; exact KL infimum by angle projection. Ordinary highprecision finite sum, no source-history claim.'}

def joint_density(theta_text,order,dps):
 with mp.workdps(dps):
  n=2;s=mp.mpf(1)/3;theta=m(theta_text);eps=mp.mpf(1)/20;x=mp.mpf(1)/5;targetdist=mp.mpf('.49');masses=list(map(m,('1','2','1/7')));centers=list(map(m,('0','3/5','7/5')));N=int(mp.ceil(mp.pi*mp.sqrt(n)));rs=[mp.sin((j+mp.mpf('.5'))*mp.pi/(2*N))**2 for j in range(N)];targetpost=s*phi(targetdist)/psoft(targetdist,s);Psharp=max(psoft(targetdist,r)**n for r in rs);Bmax=mp.e*theta*theta*s/(2*(1-s))
  hard=[];soft=[]
  for v in centers:
   lo=x-v-eps;hi=x-v+eps;hard.append(max(mp.mpf(0),min(hi,mp.mpf('.5'))-max(lo,-mp.mpf('.5')))/(2*eps));soft.append((phi_primitive(hi)-phi_primitive(lo))/(2*eps))
  def cap(t):return sum(mu*((1-t)*hh+t*ff)**n for mu,hh,ff in zip(masses,hard,soft))
  cap_s=cap(s);cap_J=cap(mp.mpf(1));q=mp.mpf(5)/2*max(cap_s,cap_J);nodes,weights=mp.gauss_quadrature(order,'legendre');bins=[mp.mpf(0)]*N;left=mp.mpf(0);right=mp.mpf(0);used=set()
  for mass,v in zip(masses,centers):
   ds=[x-v-eps*t for t in nodes];ph=[phi(t) for t in ds];fs=[psoft(t,s) for t in ds];posts=[s*f/g for f,g in zip(ph,fs)];pr=[[psoft(t,r) for t in ds] for r in rs]
   for i in range(order):
    for k in range(order):
     posterior=(1-theta)*targetpost+theta*(posts[i]+posts[k])/2;_,j,r,_=grid(n,posterior);T=mp.exp(-n*(KL(posterior,s)+Bmax)/theta)*pr[j][i]*pr[j][k];w=mass*weights[i]*weights[k]/4;bins[j]+=w*T;used.add(j);P=psoft(targetdist,r)**n;left+=w*P**(1-theta)*T**theta;right+=w*Psharp**(1-theta)*T**theta
  total=sum(bins);assert total<=14*q and left<=right*(1+mp.mpf(10)**(-dps+8));combined=2*total+cap_J;assert combined<=29*q
  return {'n':n,'theta_exact':theta_text,'source':'Same true uniform product cubes as capacity_row; f=2nu,beta=nu. Target y chosen so x-y=.49, no beta/history qualification asserted.','s':'1/3','A_moving_legs':'1 for both, because a=b=1','GL_order':order,'N':N,'used_selected_cells':sorted(used),'q_fixed':mp.nstr(q,32),'per_single_moving_leg_sum_T':mp.nstr(total,32),'per_leg_sum_T_over_q':mp.nstr(total/q,32),'per_node_T_integrals':[mp.nstr(v,32) for v in bins],'fixed_J_capacity_over_q':mp.nstr(cap_J/q,32),'two_moving_plus_J_over_q':mp.nstr(combined/q,32),'per_leg_bound':14,'aggregate_bound':29,'disjoint_receiver_source_integral':mp.nstr(left,32),'Psharp_disjoint_majorant':mp.nstr(right,32),'disjoint_ratio':mp.nstr(left/right,32),'scope':'Actual finite L1 source density, real kernel single moving leg before aggregation. Ordinary tensor quadrature and explicit future soft convexity, not FULL input/history.'}

def main(output):
 covers=[];scalars=[];capacities=[];spatials=[];clocks=[]
 for c in cover_menu():
  lo=cover(c,40);hi=cover(c,70);err=prec(lo,hi,'combined_log_ratio_after_chi') if not hi['Fs_zero_trivial_branch'] else '0';covers.append({'at_40dps':lo,'at_70dps':hi,'relative_precision_difference':err})
 for c in scalar_menu():
  lo=scalar(c,40);hi=scalar(c,70);scalars.append({'at_40dps':lo,'at_70dps':hi,'precision_difference':prec(lo,hi,'nonlinear_scalar_value')})
 for n in (2,16,512):
  for index in ('first','middle','last'):
   lo=capacity_row(n,index,40);hi=capacity_row(n,index,70);capacities.append({'at_40dps':lo,'at_70dps':hi,'precision_difference':prec(lo,hi,'normalized_capacity_over_q')})
 for y in ('0','2','8'):
  for theta in ('1/2','1/10','1/100'):
   for index in ('first','middle','last'):
    lo=S_integral(y,theta,index,40);hi=S_integral(y,theta,index,70);spatials.append({'at_40dps':lo,'at_70dps':hi,'precision_difference':prec(lo,hi,'S_y')})
 for n in (2,16,512):
  for theta in ('1/2','1/10','1/100'):
   lo=zeta_clock(n,theta,40);hi=zeta_clock(n,theta,70);clocks.append({'at_40dps':lo,'at_70dps':hi,'precision_difference':prec(lo,hi,'pair_over_bound')})
 cellrows=[];jointrows=[];jointclocks=[]
 for c in cells_menu():
  lo=cells(c,40);hi=cells(c,70);cellrows.append({'at_40dps':lo,'at_70dps':hi,'precision_difference':prec(lo,hi,'actual_direction_partition_sum')})
 for theta in ('1/10','1/100'):
  lo=joint_density(theta,16,40);hi=joint_density(theta,32,70);jointrows.append({'coarse':lo,'refined':hi,'capacity_refinement_difference':mp.nstr(abs(mp.mpf(lo['per_leg_sum_T_over_q'])-mp.mpf(hi['per_leg_sum_T_over_q'])),16)})
 for n in (2,16,512):
  for theta in ('1/2','1/10','1/100'):
   lo=zeta_clock(n,theta,40,True);hi=zeta_clock(n,theta,70,True);jointclocks.append({'at_40dps':lo,'at_70dps':hi,'precision_difference':prec(lo,hi,'pair_over_bound')})
 result={'entropy_cell_cases':cellrows,'actual_joint_single_leg_density_rows':jointrows,'joint_disjoint_posterior_clocks':jointclocks,'joint_capacity_aggregation':'14q per moving leg, two moving legs 28q plus fixed J q =29q. Never treat old mixed Qstar rows as entropy 14q evidence.','schema':'R235_normalized_soft_entropy_capacity_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'contract_sha256':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'counts':{'affine_cover':len(covers),'scalar_KL':len(scalars),'actual_L1_capacity_rows':len(capacities),'actual_1D_S_integrals':len(spatials),'q_zeta_full_posterior_clocks':len(clocks),'Gaussian_cells':len(cellrows),'joint_actual_L1_single_leg_rows':len(jointrows),'joint_disjoint_clocks':len(jointclocks)},'affine_cover_cases':covers,'scalar_KL_cases':scalars,'actual_L1_capacity_rows':capacities,'actual_S_integrals':spatials,'q_zeta_capacity_clock_cases':clocks,'scope':['Ordinary highprecision finite checks, not interval certificates or general theorem proofs.','One-sided posterior-angle grid, actual backward fee and negative KL preserved; remaining nB price not free.','L1 capacity rows use a=b=L=1 and explicit original/future soft convexity; no backward node FIRST claim.','Static C does not depend on time, bad source or hard-source label; qzeta and d_R retained literally.','No original input/history qualification, paid global source expectation, or FULL closure claimed.']}
 output.write_text(json.dumps(result,indent=2)+'\n');print(result['counts'],flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'numeric_checks.json');main(ap.parse_args().output)
