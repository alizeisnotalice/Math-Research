# R235 independent audit — statement-first requirements

Status: FINAL PASS for the stated original positive-traffic estimates, integration and recorded numerical implementation. Earlier sections preserve chronological independent proposition screens, written before their corresponding author drafts/addenda. Only this file is auditor-owned. The arbitrary-positive-L1 root bound and its expected source/receiver payment remain unproved.

## Exact source/receiver quantity

Fix the original outer history \((\omega,V)\), its common \(\beta_V,\nu_V,q,a,b,K\), and then one certified \(j,M\), orientation, physical leg and shared-soft menu value. The static spatial column remains
\[
F_\theta(y,v)=q^{-1}\int\nu(dz)\int_\Omega
C_*(x;y,v)h_{R^*}(x-z)
P_{r,L^*}(x-y)^{1-\theta}T_v(x)^\theta w_*(y,v)^{-\theta}dx.
\]
It has the actual hard source \(z\), true receiver \(dx\), and original source labels. The clock subsequently uses the two identical original posteriors \(\Pi_{j,V,y,t}\), not \(\beta\), \(\nu/\|\nu\|\), \(\Pi_g\), or a new posterior selected by the spatial cost. The two posteriors already contain their two factors of \(e_t^{-1}\).

If a new argument keeps a receiver gate that depends on \(t\) or the other posterior source, the exact column also depends on those variables. It must stay inside their actual integrals; it cannot be declared the static \(F_\theta(y,v)\) required by the existing growing-floor inequality. Positive enlargement to a certified static capture column is legal, but its loss must be accounted for. The original upper/lower clamp restrictions, hardband \(\Omega\), and permitted physical nodes are not recomputed after restriction.

The existing static refinement is
\[
\alpha_\theta(y,v)=\int_\Omega C_*P_{r,L^*}(x-y)^{1-\theta}T_v(x)^\theta dx,
\quad m_\theta(y)=\int_{Z_\tau(y)}\alpha_\theta(y,v)^{1/\theta}\nu(dv).
\]
It enters, term by term, the genuine mean fee
\[
\frac{C_0}{2\theta}(g^*/\tau)^{n\theta}A_f^{-\theta}
(1-e^{-2\theta s})\int m_\theta(y)^\theta\beta(dy),
\quad A_f=\ell qa^nc^{-3n/2},\quad s=n\log(M/M_0)-U>0.
\]
All three physical legs, orientations, shared soft menu, original \(2\Lambda(K/3)^\theta\), physical loss, outer expectation and leaf/node sums remain. A theorem about this actual sum, or about a specified earlier unrelaxed original positive quantity, would be a valid payment. Merely replacing the name of \(\mathbb E\sum_V\|\beta_V\|[1+\log_+\rho_V+\log_+K]^3\) is not a payment.

## Positive universal joint-capacity bound available now

For a **common measurable receiver set** \(\Omega\) on which the inherited complete-input FIRST bounds hold, write the actual pointwise node prices as
\[
\int P_{r,L^*}(x-y)\beta(dy)\le q\chi_P(x),\qquad
\int T_v(x)\nu(dv)\le q\chi_T(x).
\]
The price is 1 on the appropriate future-soft domain; backward-soft nodes carry the explicit R234 price. Sources are only restricted by positivity under the same original complete input; FIRST is not restarted on a cut. If a receiver domain depends on source labels, retain its indicators inside the integrand or explicitly enlarge to a legitimate common domain.

For fixed \(\theta\), Minkowski on \(L^{1/\theta}(\nu)\), followed by Hölder on the **different** source \(\beta\), yields the valid universal bound
\[
\int m_\theta(y)^\theta\beta(dy)
\le q\|\beta\|^\theta\int_\Omega
\chi_P(x)^{1-\theta}\chi_T(x)^\theta dx.
\]
Using full \(\nu\) instead of \(1_{Z_\tau(y)}\nu\) only enlarges the moment. On a common future domain for both kernels this reduces to \(q\|\beta\|^\theta|\Omega|\); it is an explicit receiver fee, not an input-mass bound or an automatic small absorption term. The growing-floor prefactors, node/menu count, and any receiver multiplicity across outer histories/leaves still multiply it. A claim that it pays the original event must identify the exact original receiving functional and prove the requisite coefficient/multiplicity bound. It cannot replace the remaining receiver integral by 1 or assume disjointness not supplied by the original construction.

The \(\theta=1/2\) double-receiver identity uses two genuine \(dx\) variables and the same conditional \(\nu\), with both capture factors. Joint FIRST supplies row capacities, not a free diagonal collapse or a scale-square-sum theorem. A two-measure Schur argument must explicitly verify both weighted row and column inequalities and then pay its resulting constant in the original outer measure.

## Parameter and history order

- A fixed \(\theta_V\) chosen from measurable original outer-leaf data common over \(j\) is allowed: R234's fractional inequalities and one arcsine menu are uniform in \(\theta\). This is parameter optimization of a universal inequality, not a new physical selector.
- A value \(\theta(y)\) fixed before receiver/time integration could be used row by row if all corresponding costs remain inside \(\beta(dy)\). It does **not** permit the constant-exponent Hölder/FC11 formula, a common \(\|\beta\|^\theta\), or a common all-j sum to be taken outside that integral without a fresh bound. Dependence on node/j similarly requires the actual node/j expenses to remain.
- A choice depending on \(v\), the other posterior source, receiver \(x\), or clock \(t\) does not satisfy the existing fixed-exponent spatial/clock interpolation. The pointwise good inequality may remain true, but the subsequent fixed-node integral and Hölder proof no longer follow. A new uniform domination, measurable selection argument and quantitative expense would be required. No independent theta mesh may be silently collapsed into the shared soft menu.
- If \(\theta\) is selected by an implicit quantity \(m_\theta\), establish joint measurability and specify the actual quantified inequality being minimized. An infimum of separately estimated terms cannot be distributed over a source/history sum when they bound different positive quantities.
- Original \(\beta_V,\nu_V\), receiver sets and process carriers are conditional on the same history. Tonelli for nonnegative integrands is legal. Replacing their joint history law by independent copies, or multiplying separately averaged capacities, is not. An expected product or logarithmic moment remains a charged object until explicitly bounded.

## Minimal obligations for the authors' exact candidate

1. Specify whether the bound is before the hard-source integration, for an exact time/source-dependent column, for the static spatial moment, or for the full original mean fee. State every receiver/source/expectation measure and all outer labels.
2. Give a new quantitative bound on that object with explicit \(n,q,a,\ell,K,\theta\), physical/soft menu and history dependence. Its right side must be a proved original budget or a clearly stated smaller remaining geometric expense.
3. Retain genuine heavy/valid times until the floor is used; do not put a heavy floor on a subset endpoint. Preserve the same two posteriors and use the hard cap only once. Any new capture cut has its certified static domain and measurable source-tail qualification.
4. Show how beta/nu/source roles, unique-j or receiver multiplicity, all three fractional legs and zero/empty cases survive assembly. Bound actual source/history averages rather than assuming a global density or logarithmic-moment cap.
5. Mark any still-unproved joint inequality and complementary original branches. This positive route grants no new signed/deletion credit or repeat payment of previously paid traffic.

## Actual bounded computation

Independent local Python/mpmath 60-dps run, exit 0: 18 finite simple-function capacity checks using two distinct finite source measures, a common Lebesgue receiver domain, \(\theta=.1,.25,.5\), and both full/capture masks. They verify the retained-receiver universal inequality above. This is a finite diagnostic, not physical cube/FIRST/FULL realization or proof of a new source budget. No broad counterexample search, Git, PDF or spawned agent was used.

Statement-first screen complete. No R235 author proof has been read; await the exact candidate before long review.

## Subsequent exact candidate screens, still before author drafts

### Actual-Q* receiver price, without node FIRST

The auxiliary author supplied a valid stronger use of the actual FIRST. Fix an actual receiver \(x\), anchor \(y\), the unique original \(j(x)\), and its actual \(g\); set \(h=g e^{-U/n}\), \(\tau=a/c\). For fixed \(\theta\), the original good comparison can retain the whole \(Q_x^*\):
\[
p1_{\rm good}\le K^\theta p^{1-\theta}(Q_x^*)^\theta/w_g^\theta.
\]
There is no three-leg expansion in this version. Since \(\int Q_x^*d\nu\le q\), direct Hölder on the original carrier and genuine heavy times gives
\[
\int_{\tau}^{h}\iint
\frac{(Q_x^*(v))^\theta}{w_g(v)^\theta}\delta_t\,d\Pi_t^2\,d\log t
\le\frac1{2\theta}(g/\tau)^{n\theta}(q/A_f)^\theta
\bigl[1-(\tau/h)^{2n\theta}\bigr].
\]
Here actual \(Q_x^*,g\) may depend on \(x\), but are fixed before auxiliary time; this is a pointwise receiver argument followed by the actual receiver integral, not a static-node column argument. The original \(\beta\)-FIRST \(\int p(x,y)\beta(dy)\le q\), Hölder in \(\beta\), and one actual hard cap then give the exact receiver fee
\[
2\Lambda C_0\frac{K^\theta}{2\theta}
\mathbb E\sum_V\int_{\Omega_V}
q(\|\beta_V\|/A_f)^{\theta}(g/\tau)^{n\theta}
\bigl[1-(\tau/h)^{2n\theta}\bigr]dx,
\]
with the original unique-j/empty-window indicators retained. This needs no soft/physical menu and no backward-node FIRST. It removes the crude \(\nu\)-mass factor, but retains a joint receiver/\(\beta\)-mass price. As \(\theta\downarrow0\), its scalar factor tends to \(n\log(h/\tau)\), not to a free small absorption coefficient. The exact original receiving functional and multiplicity still need to be paid.

### Hard-source-preserving forward-node price

The primary author supplied another valid positive bridge. Fix a forward-soft node \(T_v\) with \(\int T_v(x)\nu(dv)\le q\) on a common \(\Omega\). For each retained hard source \(z\), let
\[
H_{yz}=\int_\Omega h_R(x-z)P_y(x)dx,\quad
b_z=\int_\Omega h_R(x-z)dx,\quad
A_z(v)=q^{-1}\int_\Omega h_R(x-z)P_y(x)^{1-\theta}T_v(x)^\theta dx.
\]
Minkowski and Hölder imply
\[
\int A_z(v)^{1/\theta}\nu(dv)
\le q^{1-1/\theta}H_{yz}^{(1-\theta)/\theta}b_z.
\]
After the growing-floor bound is applied separately for that hard source, Hölder in the **same original** \(\nu(dz)\) and the original hard cap on \(\Omega\) give
\[
\int\left(\int A_z^{1/\theta}d\nu\right)^\theta\nu(dz)
\le C_0q^\theta|\Omega|^\theta
\left(\int_\Omega P_y(x)dx\right)^{1-\theta}.
\]
Consequently the node clock cost is at most
\[
\frac{C_0}{2\theta}(g^*/\tau)^{n\theta}
(q|\Omega|/A_f)^\theta
\left(\int_\Omega P_y\right)^{1-\theta}
\bigl[1-(\tau/h)^{2n\theta}\bigr].
\]
This is dimensionally and measure-theoretically valid, including zero columns by direct interpretation. Its use requires genuine forward-node FIRST and the common receiver set; a backward node must keep its capacity price. The intermediate \(A_z\) need not be \(\le1\). The direct Hölder growing-floor proof remains valid for such nonnegative coefficients with the displayed finite moment, but it must not be cited as satisfying an older lemma's extra \(\alpha\le1\) hypothesis. Both hard-cap uses in the last Hölder expression combine to one total \(C_0\), not two independent hard-cap credits.

The resulting \(\Omega\)-volume and target response are explicit actual geometry, not a certified input budget. Neither candidate permits free summation over nodes, leaves or overlapping receivers, and neither pays the original global source moment without a further quantitative joint estimate. They are now precise propositions ready for author proof review; no broad counterexample search was undertaken.

## One-sided menu gain and normalized capacity: new independent screens

These propositions were supplied after the preceding checkpoint, still before reading either author draft.

### Exact gain and backward-capacity price

For an affine weighted product with total exponent \(m\), the exact R234 AM–GM argument yields
\(\log(H_r/H_s)\ge m[D(p\Vert s)-D(p\Vert r)]\).
Take the same arcsine midpoint grid, but choose the first midpoint angle at least \(\arcsin\sqrt p\), using the last midpoint when no such point exists. The distance is at most \(\Delta\), so the previous Taylor/chi-square argument now gives
\[
mD(p\Vert r)\le(2+\pi)^2n\Delta^2<9.
\]
Suppose \(s\le r_{\rm last}\). If the chosen r is backward, then necessarily \(p\le r<s\), including the exceptional last-midpoint case by exclusion. Hence
\(\chi_r(s)^\theta\le[(1-p)/(1-s)]^{n\theta}\).

For \(0<\theta\le1-s\), put \(a=\theta/(1-s)\le1\). The scalar bound is valid:
\[
\theta\log\frac{1-p}{1-s}-D(p\Vert s)
\le B_\theta(s):=as+\log(1-s+se^{-a})
\le\frac e2\frac{\theta^2s}{1-s},\quad p\le s.
\]
Indeed \(\log(1+(s-p)/(1-s))\le(s-p)/(1-s)\), and the Bernoulli variational identity gives the first bound. For the second, the centered variable \(\xi=s-\mathrm{Bernoulli}(s)\) has mean zero, variance \(s(1-s)\), and \(|\xi|\le1\); the elementary bound \(e^{a\xi}\le1+a\xi+(e/2)a^2\xi^2\) suffices.

For the two moving-soft legs \(m=n\), this proves the **pointwise** one-menu inequality
\[
H_s\le\exp\!\left(9+\frac{en\theta^2}{2d}\right)
\sum_r\chi_r(s)^{-\theta}H_r,
\quad s\le1-d\le r_{\rm last},\quad\theta\le d.
\]
The selected midpoint depends on source v through p. Therefore the single selected kernel cannot be extracted from its source integral and assigned FIRST. Summation over the full fixed menu is essential. After that summation, \(\chi_r(s(x))\) depends only on the actual receiver selector and fixed menu r, so its inverse power may legitimately remain as a source-independent receiver weight.

The price absorption just proved is for **one source slot of exponent \(\theta\)**. It is not simultaneous cancellation of both FC11 prices: a later target-\(\beta\) FIRST step still costs \(\chi_r^{1-\theta}\). For arbitrary \(m<n\), the scalar parameter would be \(n\theta/m\), not \(\theta\); the displayed coupled bound is not an unqualified lemma for every weighted family. The J leg has source softness 1 and source price 1, so it needs no such cancellation and the one-sided covering constant 9 suffices.

Narrow original-source check: R117 `joint_geometry.md`, opening status paragraph, really retains \(s\le1-d_n\), \(d_n=1000\sqrt{\log(n+2)/n}\), and the associated actual high-row dimension/ancestry restriction \(n>4\cdot10^6\log(n+2)\). Thus the last-midpoint condition follows on that original subtraffic since \(1-r_{\rm last}\le1/(16n)\ll d_n\). This does not create low-dimensional FULL inputs or authorize the margin on an unrelated branch. The exact penalty, its theta restriction and inherited domain must accompany any application.

### Static normalized target and posterior/receiver occupancy

For a fixed moving-soft node set \(\widehat Q_r(x,v)=Q_r(x,v)/\chi_r(s_{\rm actual}(x))\); for J use \(\chi=1\). On the inherited FIRST receiver domain,
\(\int\widehat Q_r(x,v)\nu(dv)\le q\) and \(0\le\widehat Q_r\le Q_r\). Dependence on the actual receiver x does not prevent the integrated column from being static in auxiliary time. The normalized column is a positive upper-bridge resulting from the gain-weighted menu; it is not a normalized probability density in x.

After using the normalized menu inequality, the exact static column is
\[
\widehat F_\theta(y,v)=q^{-1}\int_\Omega
(h_{R^*}*\nu)(x)C_*(x;y,v)
P_{r,L^*}(x-y)^{1-\theta}\widehat Q_r(x,v)^\theta
w_*(y,v)^{-\theta}dx.
\]
It is no larger than the old unnormalized column, so the old mass-based growing-floor and QG/Gini bounds remain valid alternatives for this **same normalized node cost**. Their min is legitimate. They are not directly bounds on a differently normalized or differently gated quantity.

Define the original joint occupancy factors
\[
d_R(x)=\frac{(h_{R^*}*\nu)(x)}{C_0q}\le1,\qquad
\zeta_C(x,y)=q^{-1}\int_{Z_\tau(y)}
C_*(x;y,v)^{1/\theta}\widehat Q_r(x,v)\nu(dv)\le1,
\]
\[
S_C(y)=a^{-n\theta}\int_\Omega d_R(x)
P_{r,L^*}(x-y)^{1-\theta}\zeta_C(x,y)^\theta dx.
\]
These are coupled through the same original conditional \(\nu\), not independent reference histories. C must be static in t/u and independent of hard z for this factorization; any z-dependent RN/history gate must first be positively dropped or uniformly dominated, not falsely declared retained in \(d_R\zeta_C\).

At each fixed receiver x, \(Z_t\subset Z_\tau\), \(w_t\le(g^*/t)^nw_*\) and Hölder give
\[
\int\frac{C_*\widehat Q_r^\theta}{w_*^\theta}
k_t\,d\Pi_t
\le n(g^*/t)^{n\theta}(q\zeta_C/e_t)^\theta.
\]
The same posterior's other marginal has mass at most one. With the true heavy floor, this gives the new valid normalized-node clock price
\[
\frac{C_0}{2\theta}\ell^{-\theta}c^{3n\theta/2}e^{\theta x}
(1-e^{-2\theta(x-U)})S_C(y),\qquad x=n\log(M/M_0)>U.
\]
The coarser form sets \(d_R,\zeta_C\le1\) and uses
\(S_y=a^{-n\theta}\int_\Omega P_{r,L^*}(x-y)^{1-\theta}dx\).
The power of a makes either S dimensionless. Hard cap and normalized-target FIRST each occur in their actual slots, with only one total \(C_0\). All outer physical, menu, good, source and expectation fees remain; in particular the new one-sided menu charges \(\exp(9+en\theta^2/(2d))\), not the old constant e.

This is a genuine valid alternative to the total-\(\nu\)-mass node price. It does not yet pay \(\int S_C(y)\beta(dy)\), its node/history sum, or a uniform input budget. The target-\(\beta\) capacity remains a charged receiver quantity. No hidden cancellation of its backward-soft price, no free source selection, and no general root conclusion has been established.

Additional actual local run: 386 scalar checks at 70 dps of the Bernoulli variational/quadratic bound and one-sided midpoint endpoints, exit 0; maximum tested \(nD(p\Vert r)\) was `0.37963679935259853256`. These are finite scalar diagnostics, not interval certification or a physical source-budget example. The independent general arguments above precede author-proof review.

## Retained entropy targets: independent 14q and aggregate screen

The parent supplied a stronger retained-gain construction before the relevant author addendum. For the moving legs \(m=n\), retain the unique selected-label indicators \(I_r(p)\), and put
\[
B_*=(e/2)\theta^2(1-d)/d,\qquad
T_r(x,y,v)=I_r(p)\exp\!\left\{\frac n\theta
[\theta\log\chi_r(s)/n-D(p\Vert s)-B_*]\right\}
\frac{Q_r(x,v)}{\chi_r(s)}.
\]
Assume \(s\le1-d\le r_{\rm last}\), \(0<\theta\le\min(d,1/2)\), with the actual original margin qualification. The previous scalar bound makes the extra multiplier at most one, so \(T_r\le Q_r/\chi_r\le Q_r\). The source-dependent label has not been extracted from its integral.

For a backward label, write \(a=\theta/(1-s)\), \(s_a=se^{-a}/(1-s+se^{-a})\). The exact variational identity is
\[
a(s-p)-D(p\Vert s)=B_\theta(s)-D(p\Vert s_a).
\]
The multiplier is therefore bounded by \(\exp[-nD(p\Vert s_a)/\theta]\). For future labels the corresponding bound has center s. Taking the infimum of relative entropy on each selected-p cell makes these weights source-independent; the normalized source kernel for each label still has capacity q.

The Bernoulli inequality \(D(p\Vert q)\ge-2\log\cos(\arcsin\sqrt p-\arcsin\sqrt q)\ge|\arcsin\sqrt p-\arcsin\sqrt q|^2\) follows from Jensen/Hellinger and \(-\log\cos z\ge z^2/2\). The one-sided cells have first width \(\Delta/2\), interior width \(\Delta\), and last width \(3\Delta/2\). For any center, its cell and the nearest cells on each side contribute at most 3; farther cells have distance at least \(k\Delta\) on either side. Hence each center costs at most
\[
3+2\sum_{k\ge1}e^{-n\Delta^2k^2/\theta}
\le3+2\sqrt\pi<7,
\]
because \(n\Delta^2\ge1/8\) and \(\theta\le1/2\). The two centers give the valid **summed target capacity**
\[
\sum_r\int T_r(x,y,v)\nu(dv)\le14q.
\]
Cells crossing the actual s cause no gap: the split is by whether their label r is future or backward; only backward selected p require \(p\le r<s\). Endpoint source products that vanish can be assigned zero targets; actual s=0 uses the direct endpoint convention. The J leg must use its own \(m=n(1-\theta)\) gain or its source-independent single selected label, not the front-leg n-gain formula. Its selected target capacity is at most q.

For each fixed \((x,y,v)\), the \(T_r\) have mutually exclusive support in the label. This special fact, rather than concavity of a general sum, proves
\[
\sum_rP_{r,L^*}(x-y)^{1-\theta}T_r(x,y,v)^\theta
\le P_\sharp(x-y)^{1-\theta}\Bigl(\sum_rT_r(x,y,v)\Bigr)^\theta,
\quad P_\sharp=\max_rP_{r,L^*}.
\]
The exact aggregate entropy column has, by the old termwise comparison, bounds \(N A_\rho\) and \(N G\). The P-sharp majorant itself need not have those bounds; they are alternative estimates of the exact aggregate, not claims about the inflated majorant.

Define
\[
\zeta_{\rm sum}(x,y)=q^{-1}\int_{Z_\tau}
C_*^{1/\theta}\sum_rT_r\,d\nu\le14,
\quad S_{\rm joint}(y)=a^{-n\theta}\int_\Omega
d_RP_\sharp^{1-\theta}\zeta_{\rm sum}^\theta dx.
\]
The same original-posterior Hölder and heavy integration then give the aggregate clock bound with \(S_{\rm joint}\), **without a separate outer N**. The exact aggregate node cost may therefore take
\(\min\{A_{S_{\rm joint}},N A_\rho,N G\}\).
The old alternatives cannot lose their N, and all three legs/two orientations, physical \(e^4\), entropy-cover factor \(e^{9+nB_*}\), good factor and original sources remain. P-sharp is an actual receiver envelope, not a normalized density granted integral 1. Its joint geometry with \(d_R,\zeta_{\rm sum}\), the \(\beta\)-average and node/history sum are still uncharged; no input/root payment follows solely from capacity 14q.

Actual bounded local run: 36 checks at 60 dps of the one-sided arc-cell Gaussian envelope for \(n=2,16,512,10^6\), exit 0. Maximum tested cell sum `3.5931247762477216939` is below the proved safe bound `6.5449077018110320546`. Finite diagnostics are not a directed interval or FULL-source certificate. This addendum is an independent proposition screen; the authors' retained-target/aggregate proofs have not yet been read.

## Exact unscaled retained-gain screen

After the aggregate author draft was read, the parent supplied a further exact-scaling proposition. This paragraph records the independent deduction before reading its author addendum. For moving legs put
\(T_{0,r}=I_r e^{-nD(p\Vert s)/\theta}Q_r\). For a fixed normalization B independent of receiver/source/time, \(T_{B,r}=e^{-nB/\theta}T_{0,r}\). Thus, with the same static capture and node,
\[
F_B=e^{-nB}F_0,\quad
\zeta_B=e^{-nB/\theta}\zeta_0,\quad
S_B=e^{-nB}S_0.
\]
All old backup estimates scale by that same factor: \(F_B\le e^{-nB}\sum_rF_{{old},r}\), so the clock backups are \(e^{-nB}N A_\rho\), \(e^{-nB}N G\). The outer \(e^{9+nB}\) cancels the B factor in **every** entry of the min. The valid final coefficient is therefore \(e^{13}\), with exact-aggregate bound
\[
\min\{A_{S_0},N A_\rho,N G\}.
\]
This is also obtained directly from \(H_s\le e^9\sum_rP_r^{1-\theta}T_{0,r}^\theta\), so it does not depend on extending a restricted quadratic-normalization theorem. For J use its own \(T_{0,r}=I_r e^{-mD(p\Vert s)/\theta}J\), \(m=n(1-\theta)\), and the direct e9 cover.

The raw joint capacity is **not** 14q. At a fixed receiver x one may normalize with the exact \(B_\theta(s(x))\); the two-center proof then gives
\[
\zeta_0(x,y)\le14\exp[nB_\theta(s(x))/\theta]
\]
for each moving leg, and J has bound 1. This retains a true local cost inside \(S_0\), rather than charging its global worst case externally. The raw-AMGM/aggregate/clock result and this exact-local-B capacity need only \(0<\theta\le1/2\), together with the inherited margin/last-node qualification for the stated capacity proof. The condition \(\theta\le d\) is needed only to replace exact B by its quadratic bound. The old R234 measurable outer-leaf choice of theta is therefore available for the raw version; the genuine \(\beta\)-weighted \(S_0\) and its source/receiver correlation remain unpaid. No nonlinear-rescaling error or free local-capacity claim is present in this independently screened proposition.

## Final author/integration review

Read complete `joint_capacity.md` JC1–16, `spatial_budget.md` through SB20, parent `proof.tex.txt` (1)–(16), updated contract, report and driver. The final general proofs pass within their stated original branch and inherited qualifications. In particular, the actual d_n/large-n/L-margin is preserved, the source-dependent selected label remains inside its source law, and 14q is per moving leg (28q for both, plus J q), never a free three-leg 14q. Certified static capture is independent of auxiliary time, the other posterior source and hard z at the point it is factored. Other original gates are retained on the mother quantity or positively dropped; no signed/deletion credit is reused.

The entropy-cell proof, mutually exclusive aggregate, original-posterior Holder step, exact-column versus P-sharp-majorant distinction, all old backup N factors, full physical/leg/orientation fees, and exact global-B rescaling agree with the independent screens above. The raw final theorem is proved directly for all \(0<\theta\le1/2\); it is not an illicit extension of the theta≤d quadratic theorem. The final displayed parent formula uses one common fixed theta. If theta is chosen by outer leaf, all theta-dependent factors remain inside the original expectation/leaf sum, as explicitly clarified in the final proof and report. The main sharp-B and author's slightly wider-B intermediate occupancies are each internally consistent; their final raw construction is not mixed with a normalized-capacity claim.

Reviewed scope repairs are incorporated: per-leg versus combined target capacity, zero kernel fibres and endpoint convention, exact aggregate rather than its inflated P-sharp majorant for old QG comparisons, simultaneous rescaling of all min entries, and the fixed/global versus leaf-dependent theta placement. The report correctly marks the early double-FIRST volume bridge as a nonpayment and the actual \(\beta\)-weighted occupancy/node/history sum as the remaining gap. Neither an average input budget nor the general root endpoint has been proved.

## Final computational evidence

The complete numerical source was read, including scalar optimizers, actual-kernel E3/E4 primitives, finite-L1 row construction, source-dependent joint labels, exact current posteriors, threshold/deletion/heavy splits, capture powers, cell endpoints and normalized versus raw metadata. The L1 rows prove stated capacity upper tools at one scale/receiver, not interior FIRST equality or original FULL selection/history. The low-dimensional cell case without the last-node margin is correctly limited to the scalar cell diagnostic. The joint numerical models use normalized Bmax targets; they are not relabelled as raw T0 capacity-14 examples.

Actual independent executions:

- Statement-first local computations: 18 finite receiver/capacity checks, 386 scalar/one-sided-grid checks, and 36 Gaussian-cell checks, each separately documented above.
- Extracted `joint_capacity.md` embedded source and executed it locally: **2929 assertions, PASS, exit 0** (maximum tested two-center partition `4.69345711902098063`). Parent's 1515+72 and primary author's 30 checks remain their separately reported executions; they are not counted as auditor runs or main-driver cases.
- Executed the final standalone source with the bundled Python runtime, existing vendor mpmath 1.3.0 and `--output /tmp/r235_independent_audit_numeric_checks.json`: **182 configurations, exit 0**. Session 34471 is complete. The independently generated **385,522-byte JSON is byte-identical** to the frozen file, SHA256 `ad5088ceec544480c795bf2b355193fca2ea6307c2857554ad7b853fea5dca79`.

The standalone counts are 70 affine covers, 24 scalar KL cases, 9 old mixed-L1 capacity rows, 27 basic S integrals, 9 original q-zeta clocks, 32 cell budgets, 2 genuine single-moving-leg L1 joint rows, and 9 joint disjoint clocks. Their ordinary 40/70-dps and GL16/32 checks are finite evidence, not outward interval certification or a FULL source/history instance. The source/contract hashes stored in JSON match the actual files; both Python scripts parse. The final driver is statically correct for package-external source+contract copy, complete-JSON comparison and manifest verification before/after; the parent's subsequent package replay has its own external receipt and is not pre-certified here.

## Frozen decision and SHA256

**Pass; no remaining blocking repair within the stated scope.** The final positive result is the exact retained-entropy aggregate/occupancy comparison with all explicit old alternatives. The true local soft-capacity response, P-sharp/source correlation, expected occupancy sum, complementary branches and final source/input bridge remain charged. No global root payment is certified.

| File | SHA256 |
|---|---|
| `task_contract.md` | `868cacfeb371edd26c8be2a8cf1eb572bbb52f4d233e112203046862794df208` |
| `proof.tex.txt` | `ede825847afed0963c6c8def5c3851aeca4aba72613b76837ac53bc98172c88b` |
| `spatial_budget.md` | `05c70fb3c6d70c59fd19d40e66daf92ac47f484ceb63b8fe4c8cc9aa92e3ec36` |
| `joint_capacity.md` | `affea31cdc52c146610814764dab1bd448b21791bf8d8bfce1fb2900e798b506` |
| `numeric_checks.py` | `6301c16f434bdfe6011cadeed33ccb84f0fa09f3d6d04f3de44ad5533142f0a9` |
| `numeric_checks.json` | `ad5088ceec544480c795bf2b355193fca2ea6307c2857554ad7b853fea5dca79` |
| `numeric_notes.md` | `40c23ac9d86d469b67d1318b1d2deef2d7b928a6634f3d0b6541c6ef21225bf1` |
| `report.md` | `48c0c013635bdb133d981229aff294eb9550d4be1fae2406c87e76939dc4a37e` |
| `reproduce.py` | `a388bb0c3fcfb2b7f440240f946d6bfb54aff5f763690fefbf456aa44ec5e1ea` |

Audit itself is intentionally excluded from this table. Audit frozen; writing has stopped. No Git, PDF or spawned agent was used.
