# R206：原非线性面跳的分数矩几何

基线131f034568793947f4ac99d8b7c00b2842c1f455已推送并远端核验，起始干净。R205完成全s双密度面核、尖锐cap跳及共同alpha恢复，是已审实质进展；一般n^(1/2+o(1))目标未完成。本轮不以新的辅助核代替原非线性面费。

原正cap跳包络 G_B(P,delta)=BP h(Bdelta/P)，h(t)=1−(1+t)^(-2)，P=原outer P_s,L，delta=target P_s,gammaL真实单面硬跳，B=B0/Wg是固定source帽。P0时置0。R205给实际共同迹上的denominator绝对跳<=G_B，负补偿仍保实际值，capture/gates变化另在JF。

准确主对象是 N_B=sum_faces integral |(v−y)·normal| G_B(P_s,L,delta_i P_s,gammaL) dH，不再是P*delta的双密度核。gamma>=1且gammaL<=b（clamp另外保速度），s∈[0,1]，任意source pair；原beta Pi²/门/窗口/time/selector全部保留。

父候选逐点弱majorant h(t)<=C_theta t^theta (0<theta<1)，最佳点 t_theta=(sqrt(1+8/theta)−3)/2，Ctheta=h(t_theta)/t_theta^theta；theta1端点常数2,theta0常数1。用A_theta(d,gamma)=gamma^-theta integral f_s(u)^(1-theta) f_s((u-d)/gamma)^theta du，实际概率亲和<=1。候选面价为 Ctheta B^(1+theta) sum_i c_i prod_{j!=i} A_j，其中 c_i=(1-s)^theta gamma^-theta |d_i|[f_s(d_i−gamma/2)^(1-theta)+f_s(d_i+gamma/2)^(1-theta)]，d_i=(v_i-y_i)/L。必须自证每个因子与尺度归一，不假原source独立。

主要方向：原非线性价可否由这种共同乘积缺损或直接共同capture符号，获得可用于一般预算的费用。不得预先猜n阶。辅助方向只证明真实一维亲和缺损/face之间的可量化关系，保s→1、theta→0/1与gamma代价；不能仅给s0或等尺度结论代替原域。审查先独筛候选，后全文审。数值先验证标量与真实一维tensor，再用有限低维实际非线性积分探路及扩大参数；有限结果不当证明或拟合渐近阶。

允许R205 OF/PG/JF与R201 ST/TI已审工具、初等Tonelli/Hölder及自证一元不等式。B03只使用已读的逐点majorant弱对偶纪律，不引入未核强对偶；F01私有GP映射未定义不调用。禁止静态容量当重入TV、变source独立性、免费receiver尺度sup、Bcap权消失或核sqrt(n)配n能量冒充根阶。

文件责任：Astra nonlinear_joint_budget.md；辅助Sol affinity_deficit_geometry.md；独审Sol audit.md；数值Sol fractional_face_checks.py/json及numeric_notes.md；父parent_fractional_geometry.md、report.md、proof.tex.txt、reproduce.py。均非唯一编辑者，只改自己文件，不git/spawn，完成停止。精确任务之后再启用，不凑满员。最终完整核验单轮紧凑归档、独立提交推送，不编译PDF。
