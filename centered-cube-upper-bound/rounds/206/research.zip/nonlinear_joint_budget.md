# R206：真实帽与共同捕获恢复的联合非线性净增量

状态：证明一个同时保留 current 分母下降、原平方帽和同 alpha 恢复的尖锐有限增量包络。与先付绝对非线性面价 G_B 再补捕获恢复不同，此包络随真实 target 跳幅增大而下降。它可用于原共同迹上的持续 target 净面项；新 capture/资格入口、连续恢复、实际几何交换及 receiver 选择仍有未付费用。没有证明一般原 raw 根阶预算。

## NJ1　必须共同的原状态

沿用 R204/205 的实际对象。固定原 `(omega,V,j,y,t)`、receiver x 和一个合法共同参数比较，nu、Pi=eta nu/e 为同一原来源与后验，e>0。令
\[
 P=p_y,\quad J=J_v>0,\quad
 S=p_v+p_v^++J\ge J,\quad
 F={\min(P^2,B^2J^2)\over J},
\]
\[
 a=T\Delta_v>0,\quad k=DK_{0v}\ge0,\quad
 d=1-k/a,\quad \rho(\alpha)=(d-\alpha J/a)_+,
 \quad W={FJ^2\over S^2}\rho(\alpha)^2. \tag{NJ1}
\]
帽 B 是所用原 source 帽；若取 B=B0/Wg，该费用保留。a=0 的实际 target 先零，不使用 k/a。Pi 只在固定原 j,y,t 下独立 receiver/current 参数，实际 high/history/terminal/capture 门不因此冻结。

本节比较的两个状态保持 P,B,J,a,k 共同，target current 使
\[
 S_+=S_-+\delta,\qquad \delta\ge0,
 \qquad \alpha_+=r\alpha_-,\quad 0\le r\le1. \tag{NJ2}
\]
delta 是实际分母增量，可包含同一事件同时发生的 current 面跳总量；不把一个实际有限跳任意拆小后重复领取 alpha 恢复。两个状态都须在实际 capture 内，或先用虚拟 rho 比较，再保全实际资格门交换。

若 alpha_-=0，则 alpha_+=0，rho 不变且分母只增，正净增量为零。以下 alpha_->0；若 d_+=0，结论也先零。若 alpha 增大而不是减小，持续 target 的正净增量同样为零。

## NJ2　分母与共同恢复同时优化

令 c=S_-/S_+∈(0,1]、g=1-r。则
\[
 \boxed{[W_+-W_-]_+
 \le {FJ^2\over S_-^2}\,d_+^2
       {g^2\over(1+\delta/S_-)^2-r^2}.} \tag{NJ3}
\]
r=1、delta=0 的 0/0 位置按实际零增量取零。对于 r<1，此界在相应标量类上尖锐。

证明：取 z=alpha_-J/(a d_+)≥0，除以 FJ²d_+²/S_-²，原差是
\[
 c^2(1-rz)_+^2-(1-z)_+^2.
\]
在 0≤z≤1 上为凹二次式，其极大点和值分别为
\[
 z_*={1-c^2r\over1-c^2r^2}\in[0,1],\qquad
 {c^2(1-r)^2\over1-c^2r^2}. \tag{NJ4}
\]
在 z≥1 上，表达式最大不超过 z=1 的值，因而不超过 NJ4。r=0 时 z_*=1，直接公式仍成立；c=r=1 单独为零。代回即得 NJ3。

写 q_delta=delta/S_-，NJ3 的恢复因子为
\[
 {g^2\over(q_\delta+g)(2+q_\delta-g)}.
 \tag{NJ5}
\]
delta=0 时回到 R205 的 g/(2-g)。当 q_delta 比 g 大时，真实正净恢复是平方 g 的量，而不是先丢分母负项得到的线性恢复。这里没有选新 alpha；r 对同一行所有 target 必须来自同一对实际 alpha。

## NJ3　保原平方帽再优化 J：直接净帽包络

设 P,B>0、r<1，并令
\[
 v_r=1-r^2,\quad t={B\delta\over P},\qquad
 \Gamma_r(t)=
 \begin{cases}
 \displaystyle{(1-r)^2\over v_r+2t+t^2},&0\le t\le\sqrt{v_r},\\[4pt]
 \displaystyle{(1-r)^2\over2t(1+\sqrt{v_r})},&t\ge\sqrt{v_r}.
 \end{cases} \tag{NJ6}
\]
则进一步有
\[
 \boxed{[W_+-W_-]_+\le d_+^2 BP\,\Gamma_r(B\delta/P).} \tag{NJ7}
\]
P=0 或 B=0 时 F=0，原项先零。r=1 或双 alpha=0 按 NJ1 的零支处理，不用 NJ6 的 0/0。该包络在放松类 `S≥J>0` 上尖锐，不宣称原 physical current 或共同 capture 数据实现等号。

证明：NJ3 的右边可写为
\[
 d_+^2g^2{\min(P^2J,B^2J^3)\over
                 (S+\delta)^2-r^2S^2}.
\]
分母对 S>0 单调增加，所以正放松 S≥J 为 S=J。令 x=BJ/P，除以 BP d_+²g² 后成为
\[
 \begin{cases}
 x^3/(v_rx^2+2tx+t^2),&x\le1,\\
 x/(v_rx^2+2tx+t^2),&x\ge1.
 \end{cases} \tag{NJ8}
\]
前支单调增加；后支导数符号为 t²-v_rx²。因此赢家是 x=max(1,t/sqrt(v_r))，即 J=max(P/B,delta/sqrt(v_r))。代入得到 NJ6，两支在 t=sqrt(v_r) 接合。

Gamma_r(t) 非增，并保留以下全部实际费用：
\[
 \Gamma_r(t)\le{1-r\over1+r},\qquad
 BP\Gamma_r(B\delta/P)
 \le {P^2(1-r)^2\over2\delta(1+\sqrt{1-r^2})}
 \quad(\delta>0). \tag{NJ9}
\]
后一式在 t>=sqrt(1-r²)、delta>0 的大跳幅支上就是 NJ7 的准确包络；其它 delta>0 处仍为正上界。它消去显式帽 B，却换成真实 inverse-delta 费用，不能将其称作已付来源价。delta=0 必须保另一支，不能用倒 delta 公式。原 absolute denominator 面包络 G_B 随 delta 增大，而 NJ7 是同时恢复后的 positive net 上界，两者对象不同；不得把 NJ7 用于没有共同 alpha 比较的任意绝对面项。

## NJ4　共同 capture 给出的真实 r

若同一 nu、Q=∫Jnu、Dq、a、k 下原 capture 迹确实嵌套 E_- subset E_+，令
\[
 U_\pm=1_{E_\pm}\min(a,k),\quad
 H_\pm=Dq-\int U_\pm\,d\nu=\alpha_\pm Q,
 \quad G=\int(U_+-U_-)\,d\nu.
\]
在 H_->0 时，
\[
 r={H_+\over H_-},\quad g={G\over H_-},\qquad 0\le g\le1. \tag{NJ10}
\]
因此 NJ3–7 联合的是实际来源积分 G 与 actual target 分母跳 delta，不是两个可自由选择的标量。若 Q、Dq 或 a/k 几何改变，实际 alpha 比仍可代入纯有限比较，但 NJ10 不再是无交换项的捕获增益公式。

在共同有限面测度以及 beta(dy)Pi_y(dv)Pi_y(du) 下，应先聚合同一 L 的 signed 增量再取正部。若只需正上界，可以得到
\[
 \left[\int h(W_+-W_-)\,d\mathfrak m\right]_+
 \le\int h d_+^2 BP\Gamma_{r_y}(B\delta/P)\,d\mathfrak m,
 \tag{NJ11}
\]
其中 h 为两端共同实际门，r_y 是原 row 的共同值。进一步逐 target 选 r 或按各个面重复领取相同 G 都不合法。尤其该 common event 上没有自身 current 跳的其它 target 仍有 delta_v=0，必须保留 Gamma_r(0)=(1-r)/(1+r) 的恢复项；不能只积 delta_v>0 的 target 面，再声称已包含整行共同 alpha 恢复。

捕获增益路径上 NJ9 仍可接 R205 的
\[
 \sum_i{1-r_i\over1+r_i}
 \le\tfrac12\log(H_0/H_N) \tag{NJ12}
\]
（H 正且只减）。有 recharge 时须加其 log 正变差；到零端点使用有限费用而不是有限对数。NJ7 比 NJ12 的逐步正价小，但不会自动支付每步的 BP 或其实际来源配重。

## NJ5　原面、真实交换与入口不可省略

在当前 joint 面上的实际 scalar cap 是 P=p_y、J=J_v、B=B0/Wg，delta 是 p_v 或 p_v^+ 的真实硬跳。NJ7 是逐点有限比较，不要求等尺度；gamma L≤b 或 clamp 状态只影响真实 delta 与实际面速度。若把它积分为面通量，仍必须保留该面的真实速度、同一面测度与状态迹。对 target current 面取绝对值后再套 NJ7 不合法，因为它已经使用了分母增量的负号。

原 scalar alpha 通常是全来源积分。nu 绝对连续不意味着可以给每个来源硬面独立指定一个非零 alpha 跳；若 actual alpha 在该面连续，r=1，持续 target 的本项正净增量为零。集体来源壳、阈值层和连续恢复应保留其原实际测度，不能借 NJ11 把体积恢复随意搬到某个 target 面上。

对于同时变化的真实几何，先取 pre geometry g0=(a0,k0,J0,F0,S0)，构造仅用于差分的共同状态
\[
 W_*={F_0J_0^2\over(S_0+\delta)^2}
       (1-k_0/a_0-\alpha_+J_0/a_0)_+^2.
\]
则
\[
 W_+-W_-=(W_*-W_-)+(W_+-W_*). \tag{NJ13}
\]
第一项符合 NJ3；第二项保留 actual a、k、J、帽、outer P 与分母差异。用 R204 势写，它精确等于
\[
 W_+-W_*=
 \mathcal B_+(d_{+,post})^2-\mathcal B_*(d_{+,0})^2
 -(\mathcal P_+-\mathcal P_*),\qquad
 \mathcal P=\mathcal B\Psi. \tag{NJ14}
\]
不在 a=0 状态形成虚拟比值，直接使用实际端值。该有限分解不要求自动 BV，也不授予其全路径变差预算。

全部原门使用
\[
 H_+W_+-H_-W_-=h(W_+-W_-)
 +(H_+-H_-)_+W_+-(H_--H_+)_+W_-,
 \quad h=\min(H_-,H_+). \tag{NJ15}
\]
新 capture、high、history、time、selector 及 receiver 域入口完整保留。特别地，target 由 strict bad 进入 good 时，仅在共同背景下有窄带
\[
 S_-<3P w_g/K\le S_+; \tag{NJ16}
\]
等号层须用原实际单侧迹，不能按闭背景阈值替换。新 active capture 满足 U_+=k，但这不能支付 W_+，因为 k=DK0 可以很小。其真实费用仍是同来源加权的 W_+/k（k>0）或直接 W_+，不得以 current 核替换实际 Hhat 的 K0。

## NJ6　真实回代、收益与第一处未付积分

原共同积分保留
\[
 \mathbb E\sum_{V,j}\int_{I_j}{dt\over t}
 \int_E dx\int\beta_V(dy)\int\Pi_{y,t}(dv)\Pi_{y,t}(du), \tag{NJ17}
\]
并在 H 中保原唯一 j、定义域、所有资格和 actual score。若要把 NJ11 用于某个面事件，须在同一事件的实际 face/coarea 测度上使用，不能用 dx 的来源概率归一直接替换面迹预算。fixed-(j,y,t) 的 Pi 独立 x 不使 alpha、r、cap 或 H 独立 x。

NJ7 可直接替代符合共同状态资格的持续 target 正净面上界，既无 inverse J，也不必先交父稿 absolute G_B 的 B^(1+theta) 分数矩费用。它保留更具体的实际 joint 核
\[
 d_+^2 BP\Gamma_{r_y}(B\delta_v/P). \tag{NJ18}
\]
这是一份已证定量改进，不是原面费的改名：其尖锐表达、两种 optimizer、delta 的反向单调性和平方 capture-gain 抑制均由 NJ2–3 推出。它仍不是独立的全局来源预算。

要从这里到原一般估计，最早尚缺的是：在实际 common-source face 与 recovery 体积测度上，对 NJ18 加 NJ15 的真实新入口和 NJ13 的实际 geometry 交换，得到不重复领取 G 的统一积分控制。R205 的 bilinear O(1) 面价不能直接处理此 source-dependent r、B 和 nonlinear delta/P；父本轮 fractional absolute 包络可支付其已证明的部分，但不能被当作 NJ18 的负补偿。特别不能把 inverse-delta 的 NJ9 当成已归一核。

目前可安全使用的粗回代是 Gamma<=g/(2-g)<=1，再保实际 BP 的来源/面费用；若再用固定来源全 selector 核界，必须保完整尺度、soft、j/time 和帽费用，而非假设固定 L。B=B0/Wg 的来源尾、actual r 的 x 依赖、entry 的低 K0 及 recharge 都未被本稿消去。一般 raw 根阶结论尚未成立；核级根阶也不能直接配 n 的 energy 费用冒称 raw 根阶。

## NJ7　有限尖锐校准接口

取 r=0 或 3/5，P=B=1，delta∈{0,2/5,4/5,8/5}。当 r=3/5 时 sqrt(1-r²)=4/5，有理赢家 J=max(1,5delta/4)。取放松类 S=J、a=2、k=1、d=1/2，并按 NJ4 取 alpha_-=z_*/J、alpha_+=r alpha_-，则 NJ3 和 NJ7 同时取等。此处 S=J 是 scalar 放松边界，不是原 strictsoft 物理数据；有限核验只能证明公式与 sharp constant，不认证原共同来源/森林/FIRST 可达。零 r、零 delta、alpha 双零及 alpha 不减的非正端点须分别核验。
