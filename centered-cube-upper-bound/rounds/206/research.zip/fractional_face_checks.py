#!/usr/bin/env python3
"""Finite fractional majorant and physical 1D affinity diagnostics; noninterval."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import mpmath as mp
HERE=Path(__file__).resolve().parent

def fmt(x,p):return mp.nstr(x,p)
def h(t):return t*(t+2)/(1+t)**2

def phi(x):
    r=abs(x);half=mp.mpf('.5')
    if r>=half:return mp.expint(3,r-half)-mp.expint(3,r+half)
    return 1-mp.expint(3,half-r)-mp.expint(3,half+r)

def fs(x,s):return (1-s)*int(abs(x)<=mp.mpf('.5'))+s*phi(x)

def scalar_checks():
    rows=[]
    for theta_text in ['.25','.5','.75','.999']:
        runs=[]
        for p in (25,40):
            with mp.workdps(p):
                theta=mp.mpf(theta_text);star=(mp.sqrt(1+8/theta)-3)/2;C=h(star)/star**theta
                stationary=2/((1+star)*(2+star));assert abs(stationary-theta)<mp.mpf(10)**(-p+3)
                tests=[]
                for label,t in [('zero',mp.mpf(0)),('small',star/100),('below',star*mp.mpf('.9')),('maximum',star),('above',star*mp.mpf('1.1')),('far',star+100)]:
                    actual=h(t);bound=C*t**theta
                    assert actual<=bound+mp.mpf(10)**(-p+3)
                    tests.append(dict(label=label,t=fmt(t,p),h=fmt(actual,p),majorant=fmt(bound,p)))
                runs.append(dict(dps=p,t_star=fmt(star,p),C_theta=fmt(C,p),stationarity_theta=fmt(stationary,p),tests=tests))
        rows.append(dict(stage=('initial' if theta_text=='.25' else 'stress' if theta_text in ('.5','.75') else 'expanded'),theta=theta_text,runs=runs))
    endpoints=[]
    with mp.workdps(40):
        for t in map(mp.mpf,['0','.000001','1','1000000']):
            assert h(t)<=2*t
            if t>0:assert h(t)<2*t
            endpoints.append(dict(t=fmt(t,40),h=fmt(h(t),40),theta1_bound=fmt(2*t,40)))
    return dict(cases=rows,theta1_endpoint=dict(C_theta='2',positive_finite_t_never_attains=True,tests=endpoints),scope='Finite scalar evaluations and stationary equation; no uniform proof from this menu.',status='PASS_NUMERICAL_NONINTERVAL')

@lru_cache(maxsize=None)
def physical_factors(tt,ss,gg,dd,p,target_text):
    with mp.workdps(p):
        theta,s,g,d=map(mp.mpf,[tt,ss,gg,dd]);target=mp.mpf(target_text)
        rate=1-theta+theta/g
        logpref=mp.log(2*s)-theta*mp.log(g)+mp.mpf('.5')+theta*abs(d)/g-mp.log(rate)
        X=max(abs(d)+g/2+1,mp.mpf('1.5'),(logpref-mp.log(target))/rate+1)
        seams=sorted(set([-X,-mp.mpf('.5'),mp.mpf('.5'),d-g/2,d+g/2,X]))
        integral=sum(mp.quad(lambda u:fs(u,s)**(1-theta)*fs((u-d)/g,s)**theta,[lo,hi]) for lo,hi in zip(seams,seams[1:]))
        A=g**(-theta)*integral;tail=mp.exp(logpref-rate*X)
        assert tail<=target and 0<A<=A+tail<=1+mp.mpf('1e-15')
        face=(1-s)**theta*g**(-theta)*abs(d)*(fs(d-g/2,s)**(1-theta)+fs(d+g/2,s)**(1-theta))
        tstar=(mp.sqrt(1+8/theta)-3)/2;C=h(tstar)/tstar**theta
        return dict(dps=p,cutoff=fmt(X,p),seams=[fmt(v,p) for v in seams],A_truncated=fmt(A,p),A_tail_upper=fmt(tail,p),A_plus_analytic_tail=fmt(A+tail,p),face_c_theta=fmt(face,p),scalar_C_theta=fmt(C,p),C_times_face_c=fmt(C*face,p),tail_rate=fmt(rate,p),tail_target=target_text)


def affinity_checks():
    table=[('.25','.25','1','0'),('.5','.25','1','.25'),('.75','.75','1.2','.5'),('.999','.99','1','.1'),('.5','.99','1.005','.1'),('.25','.75','1.2','2')]
    rows=[]
    for index,(tt,ss,gg,dd) in enumerate(table):
        runs=[physical_factors(tt,ss,gg,dd,p,target) for p,target in [(25,'1e-18'),(40,'1e-28')]]
        with mp.workdps(45):
            diff=abs(mp.mpf(runs[0]['A_truncated'])-mp.mpf(runs[1]['A_truncated']))
            allowance=mp.mpf(runs[0]['A_tail_upper'])+mp.mpf(runs[1]['A_tail_upper'])+mp.mpf('1e-20')
            assert diff<=allowance
        rows.append(dict(stage=('initial' if index<2 else 'stress' if index<4 else 'expanded'),theta=tt,s=ss,gamma=gg,d=dd,L='1',source_center='0',target_center=dd,runs=runs,crossprecision_A_difference=fmt(diff,40),status='PASS_NUMERICAL_NONINTERVAL'))
    return dict(cases=rows,scope='Actual fixed-source, fixed-scale one-dimensional physical affinities and face factors; these factors are not themselves a payment of the original adaptive source/selector budget.',tail_formula='2 s gamma^(-theta) exp(1/2+theta |d|/gamma) exp(-[(1-theta)+theta/gamma]X)/[(1-theta)+theta/gamma]',trace='Hard interval is closed for the displayed controlled point trace. Coincident original jumps are not separately certified.',status='PASS_NUMERICAL_NONINTERVAL')


def positive(x):return max(F(0),x)
def joint_scalar_checks():
    table=[]
    for stage,r,root,multipliers in [('initial',F(0),F(1),[F(0),F(1,2),F(1),F(2)]),('stress',F(3,5),F(4,5),[F(1,2),F(1),F(2)]),('expanded',F(5,13),F(12,13),[F(1,2),F(1),F(2)]),('expanded',F(99,101),F(20,101),[F(1,2),F(1),F(2)])]:
        assert root*root==1-r*r
        for multiplier in multipliers:table.append((stage,r,root,root*multiplier))
    table.extend([('stress',F(1),F(0),F(0)),('stress',F(1),F(0),F(1))])
    rows=[]
    for stage,r,root,delta in table:
        P=B=F(1);v=1-r*r;g=1-r;d=F(1,2);a=F(2);k=F(1)
        if r==1:Gamma=F(0);winner=F(1)
        else:
            Gamma=g*g/(v+2*delta+delta*delta) if delta<=root else g*g/(2*delta*(1+root))
            winner=max(P/B,delta/root)
        experiments=[]
        for J in sorted({winner/2,winner,2*winner}):
            for S in (J,2*J):
                cap=min(P*P/J,B*B*J);c=S/(S+delta)
                z=F(0) if r==1 else (1-c*c*r)/(1-c*c*r*r)
                alpha_minus=z*a*d/J;alpha_plus=r*alpha_minus
                rm=positive(d-alpha_minus*J/a);rp=positive(d-alpha_plus*J/a)
                Bminus=cap*J*J/(S*S);Bplus=cap*J*J/(S+delta)**2
                net=Bplus*rp*rp-Bminus*rm*rm
                independent=Bminus*d*d*(c*c*positive(1-r*z)**2-positive(1-z)**2)
                layer1=F(0) if r==1 else Bminus*d*d*g*g/((1+delta/S)**2-r*r)
                layer2=B*P*d*d*Gamma
                assert net==independent and net<=layer1<=layer2
                if r<1:assert net==layer1
                if r<1 and J==winner and S==J:assert net==layer2
                # A nonoptimal large alpha can make the actual net negative;
                # retain that sign rather than silently replacing it by a positive part.
                zoff=F(0) if r==1 else F(1,4)
                offnet=Bminus*d*d*(c*c*positive(1-r*zoff)**2-positive(1-zoff)**2)
                assert offnet<=layer1
                experiments.append(dict(J=J,S=S,alpha_minus=alpha_minus,alpha_plus=alpha_plus,z=z,rho_minus=rm,rho_plus=rp,Bminus=Bminus,Bplus=Bplus,actual_signed_net=net,independent_signed_net=independent,first_layer_bound=layer1,second_layer_bound=layer2,z_off_optimum=zoff,off_optimum_signed_net=offnet))
        rows.append(dict(stage=stage,r=r,sqrt_v=root,delta=delta,t=delta,P=P,B=B,d=d,a=a,k=k,Gamma=Gamma,winner_J=winner,experiments=experiments))
    assert any(x['off_optimum_signed_net']<0 for row in rows for x in row['experiments'])
    return dict(cases=rows,scope='Conditional finite scalar algebra, not original physical/same-source-capacity realizability. Alpha-plus=r alpha-minus and the signed two-coefficient net are retained. All square roots here are exact rational Pythagorean choices.',status='PASS_FINITE_EXACT')


def nonlinear_face_checks():
    table=[(1,'.5','1','.25','1','.5'),(2,'.25','1','.25','1','.5'),(2,'.5','1.2','.5','2','.5'),(2,'.99','1','.1','16','.75'),(2,'.01','2','.75','64','.25'),(2,'.999','1.005','2','.0625','.999')]
    rows=[]
    for index,(n,ss,gg,dd,BB,tt) in enumerate(table):
        runs=[]
        for p,target in [(25,'1e-18'),(40,'1e-28')]:
            factors=physical_factors(tt,ss,gg,dd,p,target)
            with mp.workdps(p):
                s,g,d,B,theta=map(mp.mpf,[ss,gg,dd,BB,tt]);X=mp.mpf(40)
                seams=sorted(set([-X,-mp.mpf('.5'),mp.mpf('.5'),d-g/2,d+g/2,X]))
                faces=[fs(d-g/2,s),fs(d+g/2,s)];face_integrals=[]
                for face in faces:
                    if n==1:
                        P=face;delta=(1-s)*g**(-n);value=B*P*h(B*delta/P)
                    else:
                        def integrand(u):
                            P=face*fs(u,s);delta=(1-s)*g**(-n)*fs((u-d)/g,s)
                            return B*P*h(B*delta/P)
                        value=sum(mp.quad(integrand,[lo,hi]) for lo,hi in zip(seams,seams[1:]))
                    face_integrals.append(value)
                NB=n*abs(d)*sum(face_integrals)
                tail=mp.mpf(0) if n==1 else n*abs(d)*B*sum(faces)*2*s*mp.exp(mp.mpf('.5')-X)
                A=mp.mpf(factors['A_truncated']);Atail=mp.mpf(factors['A_tail_upper']);facec=mp.mpf(factors['face_c_theta']);C=mp.mpf(factors['scalar_C_theta'])
                majorant=C*B**(1+theta)*n*facec*A**(n-1)
                majorant_tail=C*B**(1+theta)*n*facec*(A+Atail)**(n-1)
                assert 0<=NB<=NB+tail<=majorant_tail
                runs.append(dict(dps=p,cutoff='40',seams=[fmt(z,p) for z in seams],face_source_values=[fmt(z,p) for z in faces],individual_face_integrals=[fmt(z,p) for z in face_integrals],N_B_truncated=fmt(NB,p),N_B_tail_upper=fmt(tail,p),N_B_plus_analytic_tail=fmt(NB+tail,p),matching_affinity_factors=factors,tensor_majorant_truncated_A=fmt(majorant,p),tensor_majorant_A_plus_tail=fmt(majorant_tail,p),ratio_NB_to_tensor=fmt(NB/majorant_tail,p)))
        with mp.workdps(45):
            difference=abs(mp.mpf(runs[0]['N_B_truncated'])-mp.mpf(runs[1]['N_B_truncated']))
            assert difference<mp.mpf('1e-18')*max(1,abs(mp.mpf(runs[1]['N_B_truncated'])))
        rows.append(dict(stage=('initial' if index<2 else 'stress' if index<4 else 'expanded'),n=n,s=ss,gamma=gg,d=dd,B=BB,theta=tt,L='1',runs=runs,crossprecision_NB_difference=fmt(difference,40),status='PASS_NUMERICAL_NONINTERVAL'))
    return dict(cases=rows,scope='Original nonlinear G_B evaluated on actual repeated-coordinate physical faces, only n=1/2 and fixed L=1. No high-dimensional original flux, adaptive selector, capture/history/FIRST/FULL realization.',tail_formula='n |d| B sum_sign fs(d+sign gamma/2) * 2s exp(.5-40) for n=2; n=1 has no integration tail.',status='PASS_NUMERICAL_NONINTERVAL')


def enc(value):
    if isinstance(value,F):return str(value)
    if isinstance(value,dict):return {k:enc(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [enc(v) for v in value]
    return value

def run():
    return dict(schema='r206_fractional_face_checks_v2',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},dependency=dict(name='mpmath',version=mp.__version__,entry_sha256=hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()),scalar=scalar_checks(),affinity=affinity_checks(),joint_scalar=joint_scalar_checks(),nonlinear_faces=nonlinear_face_checks(),status='PASS_FINITE_EXACT_AND_NONINTERVAL_CHECKS',limitations=['25/40dps comparisons are numerical diagnostics, not directed interval or quadrature-rounding certificates.','Analytic tail truncation bounds are separate from finite quadrature rounding.','No uniform theorem, dimension fit, high-dimensional scan or original FIRST/FULL realization is inferred.','Original B^(1+theta), L scaling, joint source mass and selector/capture costs are not declared paid by these one-dimensional factors.'])

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=HERE/'fractional_face_checks.json');args=parser.parse_args()
    result=run();args.output.write_text(json.dumps(enc(result),sort_keys=True,indent=2)+'\n');print(result['status'])
