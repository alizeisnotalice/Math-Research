# R206：直接作用于原非线性面跳的最优幂包络

## PF1 原对象、零分支和目标

沿用R205真实有限分母跳。固定原source pair、soft度s、尺度L、target尺度gamma L、源帽B=B0/Wg>0（不随receiver变化）。记P=P_s,L(x−y)，delta_i为target第i硬面的真实密度跳，G_B(P,delta)=BP h(Bdelta/P)，h(t)=1−(1+t)^(-2)。P=0或delta=0时G取0。目标是

    N_B=sum_faces ∫ |(v−y)·normal| G_B(P,delta_i) dH^(n−1)。

这是原cap有限跳的正包络面费，不是R205的P*delta双密度面核。若真实同事件有两个current项一起跳，应先用总delta的R205精确界；以两份N_B为正上界时明确最多两current核费用，不能重复借负补偿。原rho、gates及source变化由原共同有限式保留。

## PF2 每个固定theta的最佳逐点支配

任取0<theta<1。定义

    t_theta=(sqrt(1+8/theta)−3)/2>0，
    C_theta=h(t_theta)/t_theta^theta。

则全部t≥0有

    h(t)≤C_theta t^theta，                              (PF1)

t=t_theta精确达到，故常数最佳。证明：t>0时对log(h(t)/t^theta)取log t导数，得到

    t h'(t)/h(t)−theta=2/[(1+t)(2+t)]−theta。

右侧严格递减，由1−theta降至−theta，唯一零点为t_theta。比值在t↓0与t→∞均趋0，所以该驻点为全局最大；t=0两侧零。不用任何强对偶或有限原子原理。

端点只能另用h≤1及h≤2t：theta=0最佳常数1在∞极限，theta=1最佳常数2在0极限，正有限t均不达到。尤其s=0的hard支持有零区域时，不把theta端点的支持极限误认为全域概率亲和恒为1。

由(PF1)得原变量的全域点态界

    G_B(P,delta)≤C_theta B^(1+theta) P^(1−theta) delta^theta。 (PF2)

零P/delta先按正幂为零，不造0/0。最佳标量t不保证可由同一物理来源实现，但点态上界对真实配置成立。这里执行64项数学工具B03的逐点majorant弱对偶纪律，证明完全自洽；F01私有赢家接口未定义，不调用它。

## PF3 真实产品核与完整尺度归一

令d_i=(v_i−y_i)/L，f=f_s，定义真正概率亲和

    A_theta(d,gamma)=gamma^(-theta) ∫ f(u)^(1−theta) f((u−d)/gamma)^theta du。

这等于两概率密度f(u)和gamma^(-1)f((u−d)/gamma)的幂亲和。Hölder严格给0≤A≤1；不是把未归一的overlap当成概率。

令

    c_theta(d,gamma)=(1−s)^theta gamma^(-theta)|d|
       [f(d−gamma/2)^(1−theta)+f(d+gamma/2)^(1−theta)]。

正Tonelli以及真实单面delta_i=(1−s)(gamma L)^(-n)prod_(j!=i) f((x_j−v_j)/(gamma L))，给精确式

    sum_faces ∫ |(v−y)·normal| P^(1−theta) delta_i^theta dH
       =sum_i c_theta(d_i,gamma) prod_(j!=i) A_theta(d_j,gamma)。 (PF3)

密度次数总计1，面面积L^(n−1)和速度L使L全部消去；这里没有额外L^(-n)。每个other坐标必须保gamma^(-theta)。来源的坐标不被假设独立，产品仅来自已知receiver核。

因此原非线性面费满足

    N_B≤C_theta B^(1+theta) sum_i c_i prod_(j!=i) A_j。 (PF4)

theta必须在一次应用中共同用于h的乘积比值和所有坐标因子。可在固定source/scale参数下对这整条上界取inf_theta，不允许对一个乘积的各A因子独立取最优theta然后拼回。面逐项另选theta只给各面单独合法上界之和，不自动享有同一个共同缺损恒等式。receiver原选择器与theta这种分析参数的优化不混淆；固定参数的全空间界仍不能免费上放为receiver-dependent L(x)。

## PF4 利用真实亲和缺损得到平方根维数

辅助稿 affinity_deficit_geometry.md 证明，全部s∈[0,1]、gamma∈[1,2]、d∈R及0<theta<1，m_theta=min(theta,1−theta)：

    1−A_theta(d,gamma)≥(6m_theta/71)min(d²,1)，
    c_theta(d,gamma)≤[4/(1−theta)](1−s)^theta min(|d|,1)。

这些常数保留theta端点损失；s=1先按hard跳0处理。该稿完整证明真实方差sigma_s²=1/12+s、均值Hellinger缺损及face尾界；不使用source矩或source独立性。

记e_i=1−A_i，由上述两式

    c_i≤K_theta(1−s)^theta sqrt(e_i)，
    K_theta=4/(1−theta) sqrt(71/(6m_theta))。

有限产品恒等式给sum_i e_i prod_(j!=i)A_j≤1。直接Cauchy与0≤A≤1得

    [sum_i sqrt(e_i)prod_(j!=i)A_j]²
      ≤n sum_i e_i prod_(j!=i)A_j²≤n。

零A亦合法，没有除以A。因此

    N_B≤C_theta K_theta B^(1+theta)(1−s)^theta sqrt(n)。 (PF5)

这已经是原非线性cap面正包络的全s、全source-pair估计，而不是仅双密度面乘一个未受控K_B。B^(1+theta)来源价明确留下，clamp不同速度与资格新入口还未包含。

特别theta=1/2时可直接用C_(1/2)≤1：

    (1+t)^4−t(2+t)^2=1+2t²+3t³+t^4≥0

等价于h(t)≤sqrt(t)。因8sqrt(71/3)<40，得到易回代的明确界

    N_B≤40 B^(3/2) sqrt(n(1−s))。                    (PF6)

s=1左侧0，s=0/零位移按原面定义处理。此处sqrt(n)是解析证明给出，不从有限数值拟合猜测。

## PF5 原费用及未闭合范围

(PF4)可保原H≤1与rho²≤1后作正扩大。先固定参数和source pair，再按原beta(dy)Pi_y(dv)Pi_y(du)正Fubini，只得到同一实际测度下Bcap^(1+theta)等源权的积分。不能把它当成线性原来源质量；没有nu≤beta或免费度数界。

真实Bcap在R201固定source版本不依receiver，故本稿可提出。若改用receiver-dependent或另选terminal帽，必须保其原权，不能调用同一个固定B结论。原单一current和Lplus分别有各自gamma；clamp的速度d_i±(ell−dotell)/2必须另计，连续部分也不由硬面式支付。

R205共同alpha恢复及本轮联合net估计仍用整个同source事件。alpha的变化作用到delta_v=0的target，不能只计算那些target自己的current面。新资格入口、recharge和a/k/J/帽的实际几何交换还在原全有限式里。

即使(PF6)的B价另获控制，把它直接当companion配原n阶能量仍可能仅给raw n^(3/4)，不能称一般根阶闭合。下一步要保本轮共同恢复与实际负分母的联合估计，而不先把所有正cap面独立相加。一般原n^(1/2+o(1))目标仍未完成。

## PF6 本机探索记录

父实际使用本机mpmath40位，theta=.01,.25,.5,.75,.999，核各驻点及其.001,.1,1,10,1000倍处的标量比值。相应C约为.9697101518,.7597553769,.7872003236,1.0218356842,1.9834432493，有限比较全部通过，非区间证书。

数值代理按初探、压力、扩展运行真实A/c及低维原N_B比较；具体实际最终范围以numeric_notes.md及JSON为准。不把尚未完成的执行预报为已通过，不把一维产品公式下的有限例称为任意原输入证明。全文一般论证在PF2–4及辅助稿，最终独审和driver执行另记录。
