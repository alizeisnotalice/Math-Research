# R206：真实概率亲和缺损与共同乘积面预算

状态：辅助证明。对所有s∈[0,1]、γ∈[1,2]、实位移与共同0<θ<1，证明原物理核的亲和缺损与面系数之间的显式不等式，继而给共同乘积面的√n核价。保留θ端点、真实source帽、receiver selector及current/capture交换，不宣称一般原raw根阶。本文不重复父稿的标量majorant优化或Astra的原capture主预算。

## AD1　真实概率对象与面系数

原一维概率核是
\[
 h=1_{[-1/2,1/2]},\quad w(r)=\int_0^1 e^{-|r|/a}da,
 \quad\phi=h*w,\quad f_s=(1-s)h+s\phi.
\]
φ偶、正、积分1且递减于正半轴；原已证φ(r)≤exp(1/2−|r|)在|r|≥1/2，且0≤fs≤1。固定γ∈[1,2]、d∈R，令
\[
 p(u)=f_s(u),\qquad q(u)=\gamma^{-1}f_s((u-d)/\gamma).
\]
这是两个实际概率密度，不是把C/F或原ν/e当成概率。
\[
 A_\theta(d,\gamma)=\int p^{1-\theta}q^\theta du
 =\gamma^{-\theta}\int f_s(u)^{1-\theta}
                      f_s((u-d)/\gamma)^\theta du,\quad0<\theta<1, \tag{AD1}
\]
\[
 c_\theta(d,\gamma)=(1-s)^\theta\gamma^{-\theta}|d|
 [f_s(d-\gamma/2)^{1-\theta}+f_s(d+\gamma/2)^{1-\theta}]. \tag{AD2}
\]
由Hölder，0≤Aθ≤1。fs有hard面时，AD2使用实际source迹或其正最大迹；共面整体finite jump另保，不由该点值补造资格。0<θ<1时0的正幂取0，无0^0。s1的真实target hard jump先零，故cθ=0。

## AD2　物理矩：无需来源位置矩

记σs²=∫u²fs(u)du、μ4,s=∫u⁴fs(u)du，则
\[
 \sigma_s^2={1\over12}+s\le{13\over12},\qquad
 \mu_{4,s}={1\over80}+{17\over2}s={1+680s\over80}. \tag{AD3}
\]
自洽计算：uniform H的二/四阶矩为1/12、1/80。w是Laplace_a以密度2a da混合；其二阶矩∫0¹2a·2a²da=1，四阶矩∫0¹2a·24a⁴da=8。独立H+W的四阶矩为1/80+6(1/12)·1+8=681/80、二阶为13/12；再按(1−s),s混合即得AD3。这里只用已知单核的概率表示，不假原来源坐标独立或fullν有矩。

p均值0、方差σs²；q均值d、方差γ²σs²。其四阶矩为γ⁴μ4,s+6γ²d²σs²+d⁴。

## AD3　全尺度Hellinger缺损：中心位移与尺度变化

记A=A1/2=∫√pq、δH=1−A=(1/2)∫(√p−√q)²。
用中心d/2及Cauchy，
\[
 d^2=\left[\int(u-d/2)(q-p)du\right]^2
 \le 2\delta_H\int(u-d/2)^2(\sqrt p+\sqrt q)^2du.
\]
后因(√p+√q)²≤2(p+q)而至多2(1+γ²)σs²+d²，因此
\[
 \boxed{1-A_{1/2}\ge
 {d^2\over4(1+\gamma^2)\sigma_s^2+2d^2}.} \tag{AD4}
\]
特别γ1恢复d²/[2(4σs²+d²)]。γ≤2、σs²≤13/12给
\[
 \boxed{1-A_{1/2}\ge{3\over71}\min(d^2,1).} \tag{AD5}
\]
证明：分母≤65/3+2d²；|d|≤1时≤71/3，|d|≥1时d²/(65/3+2d²)随d²增加，最小在1。d0时AD4–5只给0，不假尺度相同。

为显式保留d0的尺度缺损，还可对统计量u²使用同一Cauchy。均值差为(γ²−1)σs²+d²，四阶控制给
\[
 \boxed{1-A_{1/2}\ge
 {[(\gamma^2-1)\sigma_s^2+d^2]^2\over
 4[(1+\gamma^4)\mu_{4,s}+6\gamma^2d^2\sigma_s^2+d^4]}.} \tag{AD6}
\]
证明：将q−p写成(√q−√p)(√q+√p)，再用∫u⁴(√p+√q)²≤2∫u⁴(p+q)。AD6在γ>1,d0时仍严格为正；它与AD4可取最大，不将两个非负下界相加。所用矩全为物理noise矩，不是full来源位置矩。

## AD4　任意共同分数指数与端点纪律

令mθ=min(θ,1−θ)∈(0,1/2]。当θ≤1/2，Hölder直接给
\[
 A_\theta\le A_{1/2}^{2\theta};
\]
θ≥1/2时交换p/q得Aθ≤A1/2^{2(1−θ)}。对0≤x≤1、0<r≤1，1−x^r≥r(1−x)，故
\[
 \boxed{1-A_\theta\ge2m_\theta(1-A_{1/2})
 \ge{6m_\theta\over71}\min(d^2,1).} \tag{AD7}
\]
也可将AD6或下节hard缺损乘2mθ。Hölder证明不要求p/q处处正，覆盖s0的hard支持交叠与零亲和。

若直接采用概率端点的弱包络，可定义A0=A1=1，但这不是s0时θ趋端点的支持极限。例如s0且γ≥1时，开放区间0<θ<1的精确亲和是γ^-θ qγ(|d|)，qγ为一维cube overlap长度，θ↓0通常趋qγ而非1。θ↑1通常趋qγ/γ而非1。端点弱包络必须独立由原标量majorant证明，不作非法连续延拓。

## AD5　实际hard跳可保证的额外缺损

本节自证一个不假定soft差总与hard差同号的全γ版本。由偶性令d≥0，设
\[
 q_\gamma(d)=\min\{1,((1+\gamma)/2-d)_+\},\quad
 \phi_h=\phi(1/2),\quad
 b_{s,\gamma}=[(1-s)-s(\gamma-1)\phi_h]_+.
\]
source-only区间（source core而非target core）长度1−qγ；target-only长度γ−qγ，二者不交。在source-only上，|u|≤1/2且|(u−d)/γ|≥1/2，φ(u)≥φh≥φ((u−d)/γ)，γ≥1。因此p−q≥1−s。

在target-only上，归一化造成的确切下界仅为
\[
 q-p\ge{(1-s)-s(\gamma-1)\phi_h\over\gamma}.
\]
若右侧负，不能断言q≥p；只使用平方差≥0。若右侧正，则q−p至少该值。两密度均≤1，(√p+√q)²≤4，所以
\[
 \boxed{1-A_{1/2}\ge{1\over8}\left[
 (1-q_\gamma)(1-s)^2+
 {\gamma-q_\gamma\over\gamma^2}b_{s,\gamma}^2\right].} \tag{AD8}
\]
集合边界不影响Lebesgue积分。γ1时b=1−s，两长度均min(d,1)，恢复
\[
 1-A_{1/2}(d,1)\ge(1-s)^2\min(|d|,1)/4. \tag{AD9}
\]
γ>1时保留真实normalization与正部；不能未经此分支证明就声称相同hard长度公式。s→1时该补强退化为0，AD4/6仍可用。s0时开放θ的精确cube亲和如AD4末段所述。

## AD6　面系数由同一亲和缺损控制

令β=1−θ∈(0,1)，下文只限原γ∈[1,2]。先证明
\[
 \boxed{c_\theta(d,\gamma)\le
 {4\over1-\theta}(1-s)^\theta\min(|d|,1).} \tag{AD10}
\]
|d|≤1时fs≤1给cθ≤2(1−s)^θ|d|；1≤|d|≤2时给≤4(1−s)^θ。|d|≥2时，两face位置均离source core，且|d±γ/2|≥|d|−1，故
\[
 f_s(d\pm\gamma/2)\le\exp(3/2-|d|),
\]
\[
 c_\theta\le2(1-s)^\theta|d|e^{\beta(3/2-|d|)}
 \le{2e^{3\beta/2-1}\over\beta}(1-s)^\theta
 \le{4\over\beta}(1-s)^\theta.
\]
使用maxr≥0 r e^−βr=1/(eβ)、e^(1/2)<2；γ^-θ≤1已保其正确方向。结合三段得AD10，不需要原source距离帽。

将AD7开平方并代入，得到主一维命题
\[
 \boxed{c_\theta(d,\gamma)\le
 C_\theta^{\rm face}(1-s)^\theta\sqrt{1-A_\theta(d,\gamma)},
 \qquad C_\theta^{\rm face}={4\over1-\theta}
 \sqrt{71\over6m_\theta}.} \tag{AD11}
\]
常数不声称sharp，但对全部s∈[0,1]、γ∈[1,2]、d实数一致。s1先取真实c=0；d0同样c0，亲和即使因γ>1而小于1也不冲突。全soft极限没有倒(1−s)代价；hard面振幅本来随(1−s)^θ消失。

θ端点不能丢：Cface随θ↓0发散；θ↑1至少本证明含1/(1−θ)及mθ代价。直接θ0弱majorant可只给c0≤4min(|d|,1)、A0=1，从而n费用，不能套AD11的0分母。直接θ1弱majorant给c1=2(1−s)γ^-1|d|、A1=1的正上放，无位移uniform帽；不称其为θ1根阶界。s0的source零支持在端点被这类弱上放丢弃，未伪装成真正支持极限。s1无hard跳，所有端点均先零，避免0^0。

## AD7　共同乘积面：不逐坐标领n份容量

固定共同θ∈(0,1)、s、γ∈[1,2]，任意位移向量d∈Rn。设Ai=Aθ(di,γ)、ci=cθ(di,γ)、wi=Πj≠i Aj。每个Ai∈[0,1]，所以有限乘积展开给
\[
 \sum_i(1-A_i)w_i\le1,\qquad\sum_iw_i\le n.
\]
不除Ai，故零亲和、多个零亲和与n1都合法。Cauchy使
\[
 \left(\sum_i\sqrt{1-A_i}\,w_i\right)^2
 \le\left(\sum_i(1-A_i)w_i\right)\left(\sum_iw_i\right)\le n.
\]
于是
\[
 \boxed{\sum_i c_i\prod_{j\ne i}A_j
 \le C_\theta^{\rm face}(1-s)^\theta\sqrt n.} \tag{AD12}
\]
所有坐标使用同一θ；若在当前积分变量上逐坐标/逐receiver随意重选指数，就不再是AD12的既定乘积。该证明不涉及来源概率独立，只涉及物理receiver核的明确乘积。

## AD8　与原非线性面费的精确尺度接口

固定source pair y,v、L>0、ℓ=γL、common s，令di=(vi−yi)/L。原target第i面hard跳为(1−s)ℓ^−nΠj≠i fs((xj−vj)/ℓ)。非负Fubini给精确式
\[
 \mathcal K_\theta:=\sum_{i,\varepsilon}\int_{x_i=v_i+\varepsilon\ell/2}
 |v_i-y_i|\,P_{s,L}(x-y)^{1-\theta}
 [\delta_i P_{s,\ell}(x-v)]^\theta\,dH^{n-1}
 =\sum_i c_\theta(d_i,\gamma)\prod_{j\ne i}A_\theta(d_j,\gamma). \tag{AD13}
\]
量纲必须正确：两密度分数幂合成L^−n，face面积L^(n−1)与速度L恰相消；无额外L^−n。每个Aj含γ^-θ，总共γ^-nθ，未遗失target尺度因子。0<θ<1时target零跳区域自动由正幂保持；共面source迹仍须实际finitejump处理。

父稿逐点majorant若已证明h(t)=1−(1+t)^−2≤Cθ^maj tθ，则固定共同source帽B≥0时
\[
 G_B(P,\delta)\le C_\theta^{\rm maj}B^{1+\theta}P^{1-\theta}\delta^\theta,
\]
与AD12–13准确相接，给
\[
 \mathcal N_B\le C_\theta^{\rm maj}C_\theta^{\rm face}
 B^{1+\theta}(1-s)^\theta\sqrt n. \tag{AD14}
\]
这里只引用父稿标量majorant接口，不重复其最优常数证明。P0/δ0先取原G=0，不造比例0/0。该式是固定source/current参数与真实单面正费的实际核估计，并非仅纯hard或等尺度特例。

若真实Bcap随receiver x变，不能把Bcap^(1+θ)提出face积分；若固定pair可在核积分后选择一个共同θ以优化所给上界，但不授权先选自由θ(x)再无费交换。固定参数价不能免费取原L(x)/s(x)的sup，clamp的真实相对速度亦不只vi−yi，应另外保R205 OF16–17。

## AD9　原测度与尚未付款范围

AD13–14保持真实dx/面测度，之后可以在原β(dy)Π_y(dv)Π_y(du)和共同gate下正Tonelli；所得仍带实际source帽B^(1+θ)、全部j/time/window、selector正包络及source reuse费用。common parent不自动支付此高幂帽。没有假ν≤β、来源密度帽、fullν位置矩或输入特殊形式。

本稿不删原sameα/capture、分母真实negative、new eligibility入口或recharge。AD14为正上界，不能充当所需negative信用的下界。核级√n配原EJ≤nWν/(2K)也可能仍给raw n^(3/4)，不登记一般根阶闭合。原strong预算由父/Astra保真实相关权继续结算。

## AD10　数值接口与停止

现有真实A/c有限配置可直接核AD4/6/7/8/10/11的方向，无需新增全域搜索。特别d0,γ>1用于AD6的scale守卫；γ1时AD9供hardjump校准；s1先零、θ0/1不代开放区间常数。所有φtail和物理矩已有解析证明，数值只作有限非interval诊断，不能由接近1的A浮点差当严格缺损证书。本文未执行数值，也不把建议记作实际证据。

准确成果是全原soft域/非等尺度的概率亲和缺损、face控制和共同乘积√n界，以及明确量纲的原分数面接口。没有借此消除真实帽、选择器或共同capture费用。至此停止，送全文审。
