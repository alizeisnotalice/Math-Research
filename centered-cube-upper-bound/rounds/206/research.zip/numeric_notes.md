# R206 finite fractional face checks

This checker evaluates the scalar majorant, six actual one-dimensional physical affinity/face factors, two layers of exact joint scalar bounds, and six actual low-dimensional nonlinear N_B configurations. All requested configurations were run successfully. The original B^(1+theta), scale, source and selector/capture costs are retained in the stated contract and are not declared paid by these factors.

The scalar function is evaluated stably as h(t)=t(t+2)/(1+t)^2. Four theta values, 1/4,1/2,3/4,999/1000, use the claimed optimum tstar=(sqrt(1+8/theta)-3)/2. At 25/40dps, the independent stationary equation theta=2/[(1+tstar)(2+tstar)] is checked. Each theta has zero, small, below-peak, peak, above-peak and far-tail points. The theta=1 endpoint has constant 2, strictly unattained at finite positive t. Finite scalar comparisons do not prove a uniform supremum.

The actual density is fs(x)=(1-s)1_{|x|<=1/2}+s phi(x), with phi from its E3 inner/outer formula. Each case records L=1, source center 0, target center d and target/source scale ratio gamma. The displayed normalized affinity is gamma^(-theta) integral fs(u)^(1-theta)fs((u-d)/gamma)^theta du; gamma^(-theta) is not omitted. The separate one-coordinate face factor is (1-s)^theta gamma^(-theta)|d| times the sum of fs(d+-gamma/2)^(1-theta). The code distinguishes scalar C_theta from this face c_theta.

The six configurations (theta,s,gamma,d) are (1/4,.25,1,0), (1/2,.25,1,.25), (3/4,.75,1.2,.5), (.999,.99,1,.1), (1/2,.99,1.005,.1), and (1/4,.75,1.2,2). There are two configurations per stage. No high-dimensional Cartesian search or dimension fitting is performed. Closed hard point traces are used for the displayed face factor; coincident original common jumps are not independently assigned a free jump.

At 25/40dps, finite integration splits at +/-.5 and d+-gamma/2. Its cutoff X exceeds all hard seams and is chosen from the explicit tail bound

2s gamma^(-theta) exp(1/2+theta|d|/gamma) exp(-rate X)/rate, rate=1-theta+theta/gamma.

This follows by fs(u)<=s exp(.5-|u|) outside the source hard interval and the analogous target estimate. Tail targets are 1e-18 and 1e-28. The analytic omitted-tail bound is separate from uncertified quadrature rounding; A plus the tail is therefore not an interval enclosure. The cross-precision comparison allows the two omitted-tail bounds plus an empirical 1e-20 numerical tolerance, because cutoffs differ. Numerical A<=1 and the finite majorant checks are diagnostics, not uniform proofs or FULL/history/FIRST certificates.

## Observed initial checkpoint

The actual run returned PASS_FINITE_NONINTERVAL_CHECKPOINT. C_theta values in the listed theta order are approximately .7597554, .7872003, 1.0218357, 1.9834432. The six A_theta values in case order are approximately 1, .8914526, .9437900, .9999916841, .9979274, .6493713. C_theta times the displayed face c_theta is approximately 0, .2021694, .2321337, .00398138, .00974998, .1795231. All cross-precision A differences are below 5.2e-21; they include different omitted tails and are not a certified quadrature error. The first case is the known equal-density normalization, whose true full affinity is one.

Near theta=1 this menu exhibits a very small affinity deficit together with a small hard-face factor. The two must remain coupled in any next budget calculation. Neither their separate displayed values nor this observation establishes a uniform exponent or an original nonlinear face payment. The original low-dimensional N_B checks below keep matching affinity factors and all B powers explicit.

## Joint scalar bounds: two exact layers

Fifteen finite r/delta configurations in three stages use r=0,3/5,5/13,99/101,1, with sqrt(1-r^2)=1,4/5,12/13,20/101,0 respectively. The delta choices lie below, at and above the winner threshold delta/sqrt(1-r^2)=P/B; the r=1 branch is handled before zero denominators. Each has P=B=1,d=1/2,a=2,k=1 and six experiments, using J equal to half, the exact winner, or twice the winner, with S=J or 2J. There are 90 experiments total.

For each experiment Bminus=F J^2/S^2, Bplus=F J^2/(S+delta)^2, F=min(P^2/J,B^2J). The retained signed net is Bplus*rho_plus^2-Bminus*rho_minus^2; it is independently recomputed using c=S/(S+delta), rho_minus=d(1-z)_+,rho_plus=d(1-rz)_+. Alpha-minus=z*a*d/J and alpha-plus=r*alpha-minus are linked, rather than independently assigned. They are conditional scalar parameters here, not a claimed original shared-source alpha realization.

The first bound is Bminus*d^2*(1-r)^2/[(1+delta/S)^2-r^2]. For r<1, z=(1-c^2r)/(1-c^2r^2) attains it exactly. The second bound is BP*d^2*Gamma_r(Bdelta/P), with Gamma=(1-r)^2/[v+2t+t^2] for t<=sqrt(v), otherwise (1-r)^2/[2t(1+sqrt(v))], v=1-r^2. With J=max(P/B,delta/sqrt(v)) and S=J, both layers attain equality exactly. Nonoptimal z=1/4 tests retain their signed values, including negative nets; r=1 likewise retains actual negative coefficient losses rather than turning them into free positive credits. All arithmetic in this group is Fraction. The finite rational examples test formulas and branches, not their general proof, physical kernel qualification, original capture capacity or FULL history.

## Actual nonlinear N_B: n=1/2 only

The six (n,s,gamma,d,B,theta) configurations are (1,.5,1,.25,1,.5), (2,.25,1,.25,1,.5), (2,.5,1.2,.5,2,.5), (2,.99,1,.1,16,.75), (2,.01,2,.75,64,.25), and (2,.999,1.005,2,1/16,.999), with two per stage. L=1 is fixed, and gamma>=1 is explicit; a window containing the target scale would need b>=gamma. No high-dimensional original flux is calculated.

At each face, P=fs(d+-gamma/2) times the remaining-coordinate fs product, delta=(1-s)gamma^(-n) times the target remaining-coordinate fs product. The code directly evaluates G_B=BP*h(Bdelta/P) and sums n|d| times the two face integrals. The n=1 cases have no remaining-coordinate integral. Each n=2 case integrates over [-40,40], splitting at +/-.5 and d+-gamma/2; no hard discontinuity is numerically smoothed. Since G_B<=BP, the omitted contribution is analytically at most n|d|B sum_sign fs(d+sign gamma/2)*2s exp(.5-40). This is a truncation estimate, not a quadrature-rounding enclosure.

For each same configuration and precision, A_theta and c_theta are actually recomputed (or reused only for an identical cache key). The tensor comparison is C_theta B^(1+theta) n c_theta A_theta^(n-1), with the affinity's analytic tail also explicitly added in the reported comparison. Every N_B plus its analytic tail passes this finite numerical comparison. Its reported ratio uses the tail-enlarged tensor expression. Both sides still have uncertified numerical rounding and are not interval bounds.

In table order, N_B is approximately .1504621, .2875248, 1.0716700, 1.2248722, 74.0085990, .0000604117. The ratios to the corresponding tensor majorant are approximately .884272, .797685, .745767, .941272, .620248, .975000. All absolute 25/40dps N_B differences are below 2.47e-24. These differences are empirical finite-precision sensitivity only, not certified errors. The large B case explicitly shows that source-cap powers have not disappeared; the close near-theta-one ratio is only this finite example, not an all-parameter sharpness or dimension assertion.

## Execution

Use normal mpmath import, with the existing local vendor if necessary; no installation or hardcoded runtime path appears in the source:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
 /opt/homebrew/opt/python@3.14/bin/python3.14 fractional_face_checks.py --output fractional_face_checks.json
```

Relocation requires the script and task_contract.md, whose portable filename/hash is bound in JSON. The dependency version and mpmath entry SHA are also recorded. JSON excludes runtime and absolute execution paths. The final full JSON was independently regenerated in a fresh temporary directory and matched byte-for-byte (subprocess exit 0). The measured isolated replay took 13.453 seconds on this machine; timing is kept in notes only, not JSON. Its temporary directory was /var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r206_fractional_replay_zndayu3f. This is finite exact/numerical evidence, not a claim that the original nonlinear face budget is closed.
