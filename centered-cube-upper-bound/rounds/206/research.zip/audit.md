# R206 independent premise audit

## 1. Review order and scope

Read only `task_contract.md` before this independent screen, not the new author proofs. The auditor owns only this file and performs no Git, spawning, numerical execution or PDF compilation. The original cap, beta Pi^2, common alpha, qualification traces, time/window and receiver selector remain in the target problem. This checkpoint is a premise screen, not final proof certification.

## 2. Optimal positive-power scalar envelope

For h(t)=1-(1+t)^(-2), t>=0, and 0<theta<1, the ratio h(t)/t^theta tends to zero at both positive-domain ends. Its logarithmic derivative vanishes exactly when

    t h'(t)/h(t)=2/[(1+t)(2+t)]=theta.

The left side strictly decreases from one to zero, so the unique maximum occurs at t_theta=(sqrt(1+8/theta)-3)/2>0. The proposed C_theta=h(t_theta)/t_theta^theta is the sharp constant. At theta=0 the optimal constant is one, attained only as t tends to infinity; at theta=1 it is two, attained only as t decreases to zero. These endpoint majorants are h<=1 and h<=2t, not substitutions into the interior formula at a finite optimizer.

On P>0 and delta>=0, the original positive cap-jump envelope therefore satisfies

    G_B(P,delta)<=C_theta B^(1+theta) P^(1-theta) delta^theta.

P=0 and delta=0 are zero first for 0<theta<1. The cap B must be the same fixed source cap in this inequality; a receiver- or state-dependent cap needs its true weight and finite exchange. No upper bound on this positive loss is a lower bound for a compensating negative term.

## 3. Exact tensor normalization and affinity

Write d_i=(v_i-y_i)/L and target side ell=gamma L. On its i-th hard face, delta_i=(1-s)(gamma L)^(-n) product_(j!=i) f_s((x_j-v_j)/(gamma L)). Combining the two density powers gives L^(-n) gamma^(-n theta). Multiplying by face area L^(n-1) and normal mismatch L|d_i| cancels every remaining L power. Thus there is no L^(-n) in the resulting fractional face bound. This differs essentially from the bilinear face measure of R205.

The exact one-dimensional factors in the proposed upper bound are

    A_theta(d,gamma)=gamma^(-theta) integral f_s(u)^(1-theta) f_s((u-d)/gamma)^theta du,
    c_i=(1-s)^theta gamma^(-theta)|d_i|
        [f_s(d_i-gamma/2)^(1-theta)+f_s(d_i+gamma/2)^(1-theta)].

Hence the stated sum C_theta B^(1+theta) sum_i c_i product_(j!=i) A_theta(d_j,gamma) has the correct constants, powers and dimensions for the specified nonnegative face functional. A_theta is the affinity of the probability densities f_s(u) and gamma^(-1)f_s((u-d)/gamma), so Holder gives 0<=A_theta<=1. Its factor is gamma^(-theta), not gamma^(-1), and the source density factors cannot be normalized a second time.

Receiver coordinates factor because the physical kernel is a product at fixed s,L,gamma,y,v. This does not assume that source coordinates or beta/nu are independent. Only nonnegative Tonelli is needed to keep a genuine fixed joint source measure outside the calculation. A second Pi slot and its actual masks remain, rather than being replaced by an independent source law.

## 4. Endpoint, trace and original-measure qualifications

At s=1 there is no target hard jump, so the original face functional is zero before any endpoint power convention. For s=0 and 0<theta<1, affinities retain exact hard support intersections, with their contact convention. At theta=0 or theta=1 the direct endpoint majorants are safe, but replacing zero powers by one enlarges support. In particular, for pure hard kernels the limit of an interior affinity as theta tends to an endpoint need not equal one: it retains the other kernel's support indicator. This support issue must not be presented as an endpoint identity. For 0<s<=1 both densities are positive, which removes that specific support ambiguity. Empty products at n=1 equal one.

The target hard-face amplitude is exact only for fixed physical parameters. Any common outer/current face, changed cap/J, capture/alpha and gate entry requires the whole finite product using the actual side traces. Closed hard values alone do not select those traces. The material normal coefficient |v_i-y_i| applies to homothetic target side gamma L; clamp has its separate velocity term. Fixed-slice receiver area bounds are not bounds along a receiver-dependent selector without a paid exchange or envelope. The remaining B^(1+theta)=(B0/Wg)^(1+theta), source occupation, j/time/window and original energy remain unpriced by this tensor formula. A freely source-pair-varying theta may give pointwise bounds only with measurable conventions and its actual coefficients retained; it does not grant a free global moment or selector price.

## 5. Additional joint finite-recovery candidate screen

After the initial contract screen, an accurate scalar candidate was supplied: common a,k,J,F, Splus=Sminus+delta, alpha_plus=r alpha_minus with r in [0,1], and c=Sminus/Splus in (0,1]. For d_+>0 and alpha_minus>0, normalize z=alpha_minus J/(a d_+). Then

    sup_(z>=0) [c^2(1-rz)_+^2-(1-z)_+^2]
      =c^2(1-r)^2/(1-c^2r^2).

For c=r=1 the difference is zero first. Otherwise its concave quadratic on [0,1] has vertex (1-c^2 r)/(1-c^2 r^2) in that interval. On z>=1 the maximum is at z=1 and is no larger. Thus the proposed positive net increment bound

    [Wplus-Wminus]_+
      <=mathcalB_minus d_+^2 (1-r)^2/[(1+delta/Sminus)^2-r^2]

is correct within these shared-state assumptions. The branches d_+=0 and alpha_minus=0 must precede normalization: in the latter case both alphas vanish and denominator increase makes the positive net change zero, so r must not be formed as 0/0. New qualification entries and simultaneous a,k,J,F/cap or outer changes are not part of this scalar comparison.

## 6. Initial decision

The optimal scalar power majorant, its interior tensor formula and the accurate shared-state scalar recovery candidate pass this independent premise screen. No general original raw budget, source payment or selector bound is certified. Awaiting complete author statements/proofs and final integration before any final audit or hash binding.

## 7. Further accurate candidates screened before proofs

The author supplied a second optimization of the joint recovery/denominator envelope over J. For fixed P,B>0, r<1, set t=B delta/P, v=1-r^2, g=1-r. Dropping the nonjump background by S>=J is valid because v S^2+2delta S+delta^2 increases with S. With x=BJ/P the remaining normalized envelope is g^2 x^3/(v x^2+2tx+t^2) on x<=1 and g^2 x/(v x^2+2tx+t^2) on x>=1. The first branch increases; the second derivative has the sign of t^2-vx^2. Therefore the optimum is x=max(1,t/sqrt(v)), and the proposed sharp relaxation

    Gamma_r(t)=g^2/(v+2t+t^2),                  t<=sqrt(v);
    Gamma_r(t)=g^2/[2t(1+sqrt(v))],             t>=sqrt(v)

is correct. The actual d_+^2 factor may be retained, or positively relaxed to one. At delta=0 this reduces to the R205 recovery coefficient. r=1, alpha_minus=0, P=0 or B=0 are treated before those ratios. Matching abstract J and z does not establish physical realizability or a global price.

The auxiliary author's affinity/face candidate was also independently checked from its stated formulas, without reading its proof. For gamma in [1,2], f_s has variance sigma_s^2=1/12+s<=13/12. For p=f_s and q=gamma^(-1)f_s((u-d)/gamma), center the mean-Cauchy argument at d/2. The inequality (sqrt p+sqrt q)^2<=2(p+q) gives

    1-A_(1/2)>=d^2/[4(1+gamma^2)sigma_s^2+2d^2]
                 >=(3/71)min(d^2,1).

Holder yields A_theta<=A_(1/2)^(2 min(theta,1-theta)); concavity of the power then gives 1-A_theta>=(6 min(theta,1-theta)/71)min(d^2,1). For |d|<=2, the stated face coefficient is at most 4(1-s)^theta min(|d|,1). For |d|>=2, both face points lie outside the core, f_s<=exp(3/2-|d|), and sup_(r>=0) r exp(-(1-theta)r)=1/[e(1-theta)]. Hence the safe coefficient 4(1-s)^theta/(1-theta) is valid. These imply

    c_theta(d)<= [4/(1-theta)]sqrt[71/(6 min(theta,1-theta))]
                 (1-s)^theta sqrt(1-A_theta).

Finally Cauchy applied without division by A_i gives sum_i sqrt(1-A_i)product_(j!=i)A_j<=sqrt(n), using the exactly-one-defect product identity and sum_i product_(j!=i)A_j<=n. This is valid even when affinities vanish. The gamma<=2 restriction, nonuniform theta-endpoint constants and s=1 zero hard jump are essential. Endpoint affinities defined as one for a direct weak majorant are not asserted to be the pure-hard interior limits. The resulting kernel-level square-root face estimate retains C_theta B^(1+theta), all source/selector costs and the original energy limitation; it does not certify a raw square-root budget.

## 8. Full mathematical manuscript reviews

Read complete `nonlinear_joint_budget.md`, version `f95395d9b3cef1d9897eddb06447abbb5d4e2062ee25d26b1a79a03305773bff`. NJ1–18 pass without a necessary revision. The shared-state and zero-alpha assumptions, first concave-quadratic optimization and second J/S relaxation agree with the independent screens. The universal inverse-delta weak bound follows from v+t^2>=2t sqrt(v); it must not be used at delta=0. The actual d_+^2 factor is retained. The optimizer is a sharp scalar relaxation and is not claimed attainable by strictsoft/FIRST data. NJ10 uses one actual source-integrated gain, and NJ11 explicitly retains targets with delta_v=0 that still feel the shared alpha recovery. Source absolute continuity is not used to create fictitious independent alpha jumps on each target face. The true face/coarea versus recovery-volume measures, all finite geometry/gate exchanges and the inverse-delta/source/selector/window costs remain. The sign of the denominator contribution is used only in the net bound, not converted into an arbitrary absolute face estimate.

Read complete `parent_fractional_geometry.md` PF1–6. The sharp scalar proof, exact fractional face Fubini and theta optimization qualifications are correct. The affinity factors retain gamma^(-theta) in every coordinate and the L powers cancel. The product Cauchy bound is valid with zero affinities. At theta=1/2, the identity (1+t)^4-t(2+t)^2=1+2t^2+3t^3+t^4 proves C_(1/2)<=1, and 8sqrt(71/3)<40 gives the stated bound N_B<=40 B^(3/2)sqrt(n(1-s)) on gamma in [1,2]. This is an original positive cap-envelope face-kernel estimate, not merely the earlier bilinear face measure. The retained cap power and original selector/source/energy account prevent reading it as a general raw root-order budget. No necessary revision was found.

Read complete 188-line `affinity_deficit_geometry.md`, version `7fe7922439862351e2030ddc331937a01c1fd38633d946d243e0d8354f6ed095`. AD1–14 pass. In addition to the independently screened main chain, the fourth physical moment is 1/80+(17/2)s, and the u^2 Cauchy statistic gives the stated scale-sensitive deficit without full-source moments. The source-only hard region has p-q>=1-s for gamma>=1. On the target-only region its lower threshold can be negative, and the manuscript correctly uses the positive-part branch before squaring. These two regions are disjoint, giving the 1/8 coefficient and the equal-scale 1/4 specialization. The extra nonnegative deficits are maximized rather than added. All theta endpoints, pure-hard support, gamma range, common exponent and actual trace limitations are correctly retained. No necessary revision was found.

## 9. Numerical static review checkpoint

Read complete `fractional_face_checks.py` and `numeric_notes.md`, without running them. Four scalar theta menus retain the independent stationarity equation and endpoint tests. Six actual physical affinities use the original E3 phi, all hard seams and the correct tail rate (1-theta)+theta/gamma. Their two-tail prefactor is 2s gamma^(-theta)exp(1/2+theta|d|/gamma)/rate, consistent with the code and notes. Different cutoffs and noninterval quadrature sensitivity are not labeled rigorous error bounds.

The 15 rational joint configurations give 90 J/S experiments with exact Pythagorean sqrt(1-r^2), the linked two alphas, actual signed net and two independently evaluated expressions. The relaxed optimizer attains both layers as claimed; off-optimum negative nets and r=1 remain signed. No actual shared-source capacity realization is claimed for these abstract scalar fixtures.

The six low-dimensional N_B menus directly integrate G_B on n=1/2 physical faces, with gamma^(-n) in the actual jump. Their B power, face factors and gamma^(-theta) affinities match the same configuration. The cached factor key includes the whole physical parameter/precision/tail-target tuple. The direct omitted N_B tail correctly uses G_B<=BP, while the tensor comparison separately keeps the affinity tail. All seams lie within the fixed integration interval for this finite menu. n=1 has no remaining-coordinate tail. These finite comparisons do not certify quadrature rounding, a uniform theorem, adaptive selectors or the original source/capture budget. Final notes distinguish exact Fraction evidence, high-precision diagnostics and reported independent replay; this auditor has not executed them. Awaiting final JSON/hash and full TeX/report integration before freeze.

## 10. Final finite evidence, report and driver review

Read the frozen JSON and confirmed its `PASS_FINITE_EXACT_AND_NONINTERVAL_CHECKS` status and actual counts: four scalar menus, six affinity menus, fifteen joint cases with ninety experiments, and six direct nonlinear face menus. The final numeric script, JSON and notes byte hashes equal the authors' reported `8a74de7395d2b03ff805b5a8d153fbca608696c014ea836a5ee75f6a28bd6863`, `0cc51150159e2aca2c657eadd9392f9bba929ae501d90b778c9210e502cbefe5` and `7a490e7e431de933ccd2fcba08406188741c3627bb372ef45b0a2ac837b22952`. The recorded author-side final temporary-directory replay is reported evidence; no numerical script was executed by this auditor.

Read complete current `report.md` and `reproduce.py`. The report accurately distinguishes the new nonlinear positive-face estimate from the old bilinear tool and from an original all-source budget. The joint sharp relaxation, inverse-delta price, delta-zero shared recovery, actual entry/recharge/geometry, fixed cap and original energy restrictions are retained. The listed six N_B values, finite ratios and cross-precision statements agree with the notes. Future parent-driver execution is not pre-reported.

The driver validates the manifest structure and required entries, hashes and confined file paths, resolves the numerical interpreter, refuses an existing or protected output path, executes a temporary relocated copy of the actual script with its contract and inherited environment, compares the complete JSON byte-for-byte and rechecks all bound files after execution. Its actual --output interface matches the script. Static review does not certify a later execution. No necessary revision was found. Awaiting only final full TeX consistency review and frozen bindings.

## 11. Full final TeX review and stopping scope

Read the complete 729-line `proof.tex.txt`. The optimal scalar proof and exact tensor normalization, all physical noise moments and Hellinger deficit proofs, hard-region positive-part guard, endpoint support distinction, face-deficit/product chain and the explicit constant 40 match the three reviewed manuscripts. The two sharp joint optimizations and their shared-state assumptions, zero branches, retained d_+^2, actual r/G return, delta_v=0 targets, inverse-delta price and face-versus-volume qualification are present. Source and gate/geometry exchange, capture entries, selector and original energy restrictions are not discarded. Its finite evidence and author-side replay claims match the frozen notes and JSON, without pre-reporting parent-driver success.

One local transcription repair was required in the post-geometry potential display: its first amplitude must be mathcalB_plus rather than the scalar cap B_plus; the adjacent literal `quad` also needs its command backslash. The repaired display is reread before the final hashes below. These changes restore the already-reviewed NJ14 identity and introduce no mathematical extension.

Accepted results are the stated fixed-source nonlinear cap-face estimate and sharp actual-shared-state scalar/net comparisons with all their hypotheses. They are not a general source payment or original raw square-root bound. The Bcap high powers, shared r(x), zero-jump recovery, inverse delta, low-K0 entry, recharge and actual geometry, receiver selectors, continuous/clamp and all beta Pi^2/j/time/window/energy costs remain at the stated prices. No necessary mathematical revision remains. This auditor did not run numerical scripts, execute the parent driver or compile a PDF. Final package execution/archive status belongs to the parent after this audit freeze.

The final report-only structural-check paragraph was also reread: it reports the parent's actual text checks and its corrected display-command parser, expressly not compilation or a substitute for mathematical review.

## 12. Final SHA-256 bindings

Actual byte hashes of the ten reviewed files, excluding this audit and the future manifest:

| File | SHA-256 |
| --- | --- |
| `affinity_deficit_geometry.md` | `7fe7922439862351e2030ddc331937a01c1fd38633d946d243e0d8354f6ed095` |
| `fractional_face_checks.json` | `0cc51150159e2aca2c657eadd9392f9bba929ae501d90b778c9210e502cbefe5` |
| `fractional_face_checks.py` | `8a74de7395d2b03ff805b5a8d153fbca608696c014ea836a5ee75f6a28bd6863` |
| `nonlinear_joint_budget.md` | `f95395d9b3cef1d9897eddb06447abbb5d4e2062ee25d26b1a79a03305773bff` |
| `numeric_notes.md` | `7a490e7e431de933ccd2fcba08406188741c3627bb372ef45b0a2ac837b22952` |
| `parent_fractional_geometry.md` | `9e06fd6a1cf4f623166c1c07948b47d47f747e5e6f4d6da39eae7e69b692efdf` |
| `proof.tex.txt` | `3d34eb61dc6d8864d290161fa9d04050927bbe4b963482dc5514dd82288c2596` |
| `report.md` | `36e8d4fadf761166b316273434e6030966b514f85e78d72d21fe33241d7900c8` |
| `reproduce.py` | `bdd42247ea20d2a5e7807baac06514ec5bdbbcfd6d8628dc134d1cf5d59f1775` |
| `task_contract.md` | `41ae413757a1f0ebec69161285c905cee60223e0fb3e9c81fcee017f179bc04e` |

Final status: accepted within the stated qualifications; both final local TeX repairs were actually reread. No necessary revision remains. Audit frozen before the parent's final manifest/driver execution.
