# R199 同一捕获容量对硬面跳跃的联合补偿

状态：有界证明检查点。本文证明原参数硬面两侧的捕获域嵌套、同一 α 的精确跳响应及其对截帽平方通量的负补偿。没有证明全部面通量的来源根阶预算；没有登记新的原 raw 整支付款。只处理本文件，未修改历史冻结稿。

## 1. 原定义与允许比较的两侧

固定同一原窗口、ω,V,j,x,y，来源 ν=ν_V、β_V、q、a,b、R、合法软度 s，以及原 RC 常数 D。q 是共同阈值，不假设当前卷积等于 q。比较 L 向上穿越外来源 y 的一个 current 硬面，两个单侧迹记 −、+。本节不跨越 j、窗口、s 或 R 的选择切换。共同合法比例带须满足 c_{j+1}g≤min(L,R)≤c_jg、τ_j=a/c_j≤g≤bc_j，且 a≤L,R≤b≤2a。比例带端点若只有一侧属于该 j，不能补出另一侧原资格。

所用原文定位：

- R128 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:637` 给 g=√(LR)、h=g exp(−u₀/n)、τ=a/c_j 及原 far 窗；同文件 RT4（644–650）给固定 j,V,y,t 的 Z_t、w_t、e_t、Π_t 不依 x。
- 同文件 RT5–6（652–667）给 Q=(P_{s,L}+P_{s,L⁺}+J)/3，L⁺=min(b,γL)，J=P_{1,b}，Hhat 是 g 的连续截断函数，K₀=P_{s,Hhat}，T=c_j^{n/2}/(gⁿ√ℓ)，以及 E=S_g∩{B_hard=0,Δ>0}。
- R127 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round127_20261014/proof.md:264`–294 给 S_g=Z_g\D_g、终端 good/bad、U=1_E min(TΔ,DK₀) 和 E 上 b_rec=min(1,(U+αJ)/(TΔ))。
- R125 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round125_20261014/proof.md:457`–458 明确 B_hard=1_{R≤L}1_{Q_R(x)}。它不是另一个未说明的历史门。

为避原 A 的记号重名，写
\[
 a_z=T\Delta_z,\quad \Delta_z=w_\tau(y,z)-w_h(y,z),\quad
 k_z=DK_{0,z},\quad S_z=3Q_z=p_z+p_z^++J_z,
\]
\[
 E_L=Z_g\cap\{p_yw_g(z)\le KQ_z\}\cap\{B_{\rm hard}(z)=0,a_z>0\},
 \quad U_L=1_{E_L}\min(a_z,k_z),
 \quad \alpha_LQ_J=Dq-\int U_Ld\nu,\quad Q_J=\int Jd\nu. \tag{FS1}
\]
这里 p_z^+ 表示 L⁺ 核，不是跨面右迹。只在 Q_J>0 的非零行使用 α。原 target 余权与 J-share 为
\[
 \rho_L(z)=\left[1-\frac{k_z+\alpha_LJ_z}{a_z}\right]_+,
 \qquad A_L(z)=1_{E_L}(z)\rho_L(z)\frac{J_z}{S_z}; \tag{FS2}
\]
E 外及 a_z=0 时 A=0。FS2 仅描述指定原 RC 正余项；额外删减仍放在 H 中，不能继承为新的单调性。

比较的两侧都须具有原容量资格 \(\int K_0d\nu\le q\)，故 α±≥0。若只有一侧合法，则该点属于资格进入/离开项，不能用本节共同状态补偿。固定 s 仅取原许可值；本文没有用全软度辅助族替换真实原选择。

## 2. 物理硬面与 capture 迹嵌套

**命题 FS-A。** 在上述共同参数、共同合法容量的两侧，若 L 穿过一个 p_y 的正 current 硬面，且没有额外参数重选，则有 ν-a.e. 的共同 a_z,k_z,Q_z,w_g(z) 连续背景值。在两侧 capture 测度迹存在的面上，
\[
 U_+(z)\le U_-(z),\qquad
 (\alpha_+-\alpha_-)Q_J=\int(U_--U_+)d\nu\ge0. \tag{FS3}
\]
可把失去捕获的来源集记为 \(\mathcal L=E_-\setminus E_+\)，在 a_z=0 的共同值处不计质量，则
\[
 \delta\alpha=\frac{\int_{\mathcal L}\min(a_z,k_z)d\nu(z)}{Q_J}. \tag{FS4}
\]
这里 E± 指物理单侧集合迹，允许 Z_g 在同刻删除；不把两个任意不同实际行强行视为这些迹。

证明。g 随 L 连续递增，原删除支持 Z_g 因而只缩小。B_hard 随 L 只增加；L=R 时也只会移走 capture 来源。h、T、Hhat 连续，w_t 是连续的物理权，故 a_z 连续。Q_z 与 K₀,z 仅可能在 z 的相关核硬面上有跳，这些集合对原 ν≪Leb 为零。J 不变。于是除了外 p_y 的跳，good 测试两侧的其他量具有共同值。

p_y^+>p_y^-，w_g>0，所以后侧 good 必为前侧严格 good。Z_g 的删除及 B_hard 的增加只能进一步缩 E。a_z 的正域若在共同值 a_z=0 处改变，min(a_z,k_z) 的迹为零，故对 U 和其积分没有进入质量。由此 U_+≤U_-。局部尺度有正下界，核及 T 有有限公共上界，ν 有限，故支配收敛可交换单侧迹与 U 积分。代回原同一 α 定义得到 FS3–4。证毕。

这是关于已存在的测度迹的断言，不要求 good 等号集合本身 ν 零，也不假设整个资格族具有 BV。更一般地，令 L₀ 为该正跳点，直接由严格的 p 跳差得到 ν-a.e.
\[
 \limsup_{L\downarrow L_0}U_L(z)\le
 \liminf_{L\uparrow L_0}U_L(z). \tag{FS3a}
\]
因为任何右侧 good 子列迫使左侧严格 good；左侧阈值等号来源则在右侧恒为 bad。Z 只缩、B 只增，a=0 处两边 U 趋零。由统一可积包络及 Fatou 的两侧版本，右积分的 limsup 不超过左积分的 liminf，因此任何左右 α 聚点也有 α_+≥α_-。此稳健次序不需要声明阈值层 ν 零。

FS4、FS7 作为精确迹等式只在迹存在部分使用；没有单侧迹或整体 BV 证明的资格族不能直接套尺度 Stieltjes 预算。FS3a 不自动补齐这一全局正则性义务。

### 对真实面测度的零集说明

外 y 面按 \(x_i=y_i\pm L/2\) 参数化，坐标为 (L,x_{-i},y)。对固定这些变量，任一 target/source 核面都具有形如 \(z_l=x_l\pm L/2\)、\(z_l=x_l\pm L^+/2\) 或 \(z_l=x_l\pm\widehat H/2\) 的超平面形式，因此 ν 质量零。ν_V 在固定 ω,V 后不依 x；正 Tonelli 将此零结论提升到 β(dy) 乘外面 coarea 测度。既不要求 β 与 ν 独立，也不以“Lebesgue dx 零”删除外 y 面本身。

相交的两个外 y 面在固定 s,R,j 的辅助面参数中具有余维一，故对单面面积零。若参数选择本身造成切换或没有这些单侧迹，本文不把它归入该零集，而将它留在资格/状态交换项。Z_g 的同刻删除不必是零集，FS-A 已允许并利用其向下方向。

## 3. 截帽通量的同 α 负补偿

令 B_cap≥0 对本次尺度跳固定，可以依固定来源 y,v、窗口与 x，但不能在两侧重新取值。R198 可用的来源固定帽是 \(B_{cap}=B_0/W_g(y,v)\)，其中 \(W_g=\prod_iC(|y_i-v_i|/b)\)；这里不是接收点自适应终端 w_g。

对固定 target v 令
\[
 F_\pm=\frac{\min((p_y^\pm)^2,(B_{cap}J_v)^2)}{J_v},\quad
 \Delta F=F_+-F_-\ge0. \tag{FS5}
\]
因为 S_v、J_v、a_v,k_v 在本面有共同迹，FS-A 给 A_+≤A_-。若 A_+>0，则两侧都在 capture 活跃区，且
\[
 A_--A_+=\delta\alpha\frac{J_v^2}{a_vS_v},\qquad
 A_-^2-A_+^2
 =\delta\alpha\frac{J_v^2}{a_vS_v}(A_-+A_+)
 \ge2A_+\delta\alpha\frac{J_v^2}{a_vS_v}. \tag{FS6}
\]
若 A_+=0，净平方跳不正，不使用除 a_v 的表达。

于是有精确恒等式与上界
\[
 \boxed{A_+^2F_+-A_-^2F_-
 =A_+^2\Delta F-F_-(A_-^2-A_+^2)} \tag{FS7}
\]
\[
 \le A_+^2\Delta F-
 \frac{2F_-A_+J_v^2}{a_vS_vQ_J}
 \int_{\mathcal L}\min(a_z,k_z)d\nu(z),\qquad A_+>0. \tag{FS8}
\]
FS8 是同一 α、同一原来源上的实际 lost-capture/target 联合项，不是两个独立 sup 相乘。截帽以后负项是 F_-，不能始终写成 (p_y^-)²/J_v。

若 F_+>0 且 A_+>0，令 \(r_F=\sqrt{F_-/F_+}\in[0,1]\)。则
\[
 A_+^2F_+\le A_-^2F_-
 \quad\Longleftrightarrow\quad
 \frac{J_v}{a_vQ_J}\int_{\mathcal L}\min(a_z,k_z)d\nu(z)
 \ge\rho_-\,(1-r_F). \tag{FS9}
\]
这给出可直接核验的非正净面通量条件，包含帽已经饱和时 r_F=1 的自动消失。它不等于该来源对的原 raw 交通为零，也不单独构成原 raw 根阶付款。

## 4. 原资格交换必须保留

令 H±∈[0,1] 为其余原资格的两侧值。只在双方公式都有合法定义的共同状态上，有
\[
 H_+A_+^2F_+-H_-A_-^2F_-
 =H_+(A_+^2F_+-A_-^2F_-)
 +(H_+-H_-)A_-^2F_-. \tag{FS10}
\]
因此共同状态的可用补偿为 H_+ 乘 FS8，而正交换费不超过
\[
 (H_+-H_-)_+A_-^2F_-. \tag{FS11}
\]
若 H 含一侧不合法的状态，先在共同合法部分应用 FS10；进入部分完整支付 \(H_+A_+^2F_+\)，离开部分为非正。没有前侧合法状态时，不定义虚假的 α_- 来借负项。

特别地：

1. p_y 增加可能使 high 从 0 变 1；原 p_y e_g≥2Kq 进入项须完整保留。Z_g 同刻删除还会改变 e_g，不能从 p_y 单调直接推 high 单调。
2. 改变 L 不自动保持原 FIRST、FULL、history、receiver 选择及唯一 j。它们的进入/切换不能由 FS3 支付。
3. reciprocal bad-u 门可能新进入；不能把其变化并入 target A 的下降。
4. 若 B_cap、s、R、q、来源或窗口被重选，也属于额外状态交换，不在 FS5 固定帽证明内。

这些交换不是原存活负交通或删除负信用。本文不消耗原负项，只保留同一正函数在辅助尺度方向的精确差分。

## 5. 真实 coarea、来源与时间账

单面 current 跳为
\[
 \delta p=(1-s)L^{-n}\prod_{l\ne i}f_s((x_l-y_l)/L),
 \qquad p_y^+=p_y^-+\delta p. \tag{FS12}
\]
若以 dlogL 积分，面 measure 为
\[
 \sum_{i,\pm}\frac L2\,d\mathcal H^{n-1}(x)\,d\log L. \tag{FS13}
\]
以 dL 写则系数 1/2；这不是可丢的常数。端点闭面按原核右侧取值，端点贡献仍在尺度包络中保留。

固定 (ω,V,j,y,t) 的原 Π_t 与 x 无关，故可以将 FS7–11 乘同一个非负原来源/时间权，按正项和补偿项分别在有限截断上 Tonelli。保留 ν、β、两个 1_Zt、w_t/e_t、原 score、原接收域 E_receiver；若面上的函数不可积，只能使用截断不等式，不能用 ∞−∞。j 仍是原唯一比例带：若先放大为所有 j 的固定时间窗，就必须支付完整 \(\mathcal T_*\) 或逐窗总和，不因 FS3 取消。若共同软度再用 R198 Jeffreys 上界，其 \(2\sqrt{2n}\) 费仍存在；本文没有把该混合自动施于 α/H。

要改进原平方伴随的全尺度估计，必须在上述同一面测度及实际 βΠ_t² 配重下控制
\[
 \int \left[
 H_+A_+^2\Delta F-
 \frac{2H_+F_-A_+J_v^2}{a_vS_vQ_J}
 \int_{\mathcal L}\min(a_z,k_z)d\nu(z)
 \right]_+
 +\int \text{资格进入正通量}. \tag{FS14}
\]
这是实际两项的来源耦合位置，未被独立上确界替换。a_v>0 的活跃支才写 FS14 中分式；其他支按 FS7 直接处理。

现有 reserve \(\int k(\mu-\chi)\le\alpha Q_J\) 控制当行未捕获的 k-质量上界；FS14 需要跨同一硬面 **新失去 capture 的** min(a,k)-质量相对于 target 的下界或净积分补偿。前者不能直接给后者。某个目标满足 FS9 时共同状态的该面净增量确已消失；未满足 FS9 的面以及所有新进入资格仍须付款。这是最早未完成的实际积分步骤。

## 6. 有限精确检查接口与结论范围

数值只核同一来源计算 α± 的代数身份，不声称 FULL 物理输入。示例：ν 两点各质量 1，a=(4,1)、k=(1,1/2)、J=(1,1)、Q=(1,41/100)、w_g=(1/4,2/5)，K=1，Dq=3/2，p_-=1、p_+=21/20。E_- 为两点、E_+ 仅第一点，α_-=0、α_+=1/4。第一点 ρ 从 3/4 降到 11/16，A 从 1/4 降到 11/48。取 B_cap≥2，其目标净平方跳严格为负。所有值由同一 E(p) 和容量计算，未自由挑选两 α。

本轮新证的是物理共同状态上的捕获嵌套、同 α 的精确负平方补偿，以及 FS9 的净面增量消失判据。没有证明 FS14 的一般来源根阶界，没有减少全部窗口/软度选择费用，也没有把该判据当作原 raw 整支已付。下一步必须联合估计 FS14 的 lost-capture 面质量及真实资格进入项，不能退回裸线性尺度包络后声称补偿仍在。
