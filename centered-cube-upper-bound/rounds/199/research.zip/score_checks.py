#!/usr/bin/env python3
"""Finite physical one-dimensional continuous scale-score diagnostics."""
import argparse,hashlib,json,time
from pathlib import Path
from functools import lru_cache
import mpmath as mp
HERE=Path(__file__).resolve().parent


def evaluate(dps,expr):
    mp.mp.dps=dps
    s=1-1/mp.sqrt(128) if expr=='1-1/sqrt(128)' else mp.mpf(expr)
    half=mp.mpf('.5');X=mp.mpf(120 if dps==25 else 180)
    def out(x):return mp.nstr(x,dps+5)
    @lru_cache(maxsize=65536)
    def phi(r):
        r=abs(r)
        return 1-mp.expint(3,half+r)-mp.expint(3,half-r) if r<=half else mp.expint(3,r-half)-mp.expint(3,r+half)
    @lru_cache(maxsize=65536)
    def phip(r):return mp.expint(2,r+half)-mp.expint(2,abs(r-half))
    if s==0:
        return {'dps':dps,'s':out(s),'mean':out(0),'exponential_moment':out(1),
            'exact_zero_softness':True,'cutoff_X':None,'mean_tail_upper':out(0),'exponential_tail_upper':out(0),
            'absolute_mean_boundary_formula_difference':out(0),'score_zero_roots':[], 'status':'PASS'}
    def density(r,hard):return (1-s)*hard+s*phi(r)
    def psi(r,hard):return -s-r*s*phip(r)/density(r,hard)
    # Split absolute-score exponent at a numerically found sign change in each
    # smooth side. Roots are numerical quadrature seams, not certified intervals.
    roots=[]
    def cuts_for(lo,hi,hard,extra):
        a,b=psi(lo,hard),psi(hi,hard)
        found=[]
        if a*b<0:
            left,right=lo,hi
            for _ in range(4*dps+32):
                middle=(left+right)/2
                if psi(left,hard)*psi(middle,hard)<=0:right=middle
                else:left=middle
            root=(left+right)/2
            assert abs(psi(root,hard))<mp.mpf(10)**(-dps+5)
            roots.append(root);found=[root]
        return sorted(set([lo,hi]+found+[r for r in extra if lo<r<hi]))
    inner=cuts_for(mp.mpf(0),half,1,[])
    outer=cuts_for(half,X,0,list(map(mp.mpf,(1,2,4,8,16,32,64,128))))
    mean=2*(mp.quad(lambda r:density(r,1)*psi(r,1),inner)+mp.quad(lambda r:density(r,0)*psi(r,0),outer))
    em=2*(mp.quad(lambda r:density(r,1)*mp.exp(abs(psi(r,1))/16),inner)+mp.quad(lambda r:density(r,0)*mp.exp(abs(psi(r,0))/16),outer))
    phi_mass=2*mp.quad(phi,[mp.mpf(0),half,1,2,4,8,16,32,64,X])
    mean_boundary=s*(1-s)*(phi_mass-1)-2*s*X*phi(X)
    residual=abs(mean-mean_boundary)
    mean_tail=2*s*mp.exp(half-X)*(9+8*X)
    exp_tail=4*s*mp.exp(mp.mpf(9)/16-X/2)
    assert abs(mean)<mp.mpf('1e-18') and residual<mp.mpf('1e-18')
    assert em+exp_tail<4
    return {'dps':dps,'s':out(s),'mean':out(mean),'exponential_moment':out(em),
        'exact_zero_softness':False,'cutoff_X':out(X),'mean_tail_upper':out(mean_tail),'exponential_tail_upper':out(exp_tail),
        'finite_mean_boundary_formula':out(mean_boundary),'absolute_mean_boundary_formula_difference':out(residual),
        'score_zero_roots':[out(x) for x in roots],'inner_seams':[out(x) for x in inner],'outer_seams':[out(x) for x in outer],
        'status':'PASS'}


def derivative_checks(dps):
    mp.mp.dps=dps;half=mp.mpf('.5');rows=[]
    for expr in ('0','.25','.5','.5001','1','4','16'):
        r=mp.mpf(expr)
        phi=1-mp.expint(3,half+r)-mp.expint(3,half-r) if r<=half else mp.expint(3,r-half)-mp.expint(3,r+half)
        derivative=mp.expint(2,r+half)-mp.expint(2,abs(r-half))
        ratio=abs(derivative)/phi
        assert phi>0 and ratio<=8
        rows.append({'r':expr,'phi':mp.nstr(phi,dps+5),'phi_prime':mp.nstr(derivative,dps+5),'absolute_log_derivative':mp.nstr(ratio,dps+5),'status':'PASS'})
    return {'dps':dps,'points':rows}


def run():
    specs=[('initial','.25'),('initial','.5'),('stress','.0001'),('stress','.9999'),
        ('expanded','0'),('expanded','1'),('expanded','1-1/sqrt(128)')]
    rows=[]
    for stage,expr in specs:
        runs=[evaluate(dps,expr) for dps in (25,40)]
        differences={k:abs(mp.mpf(runs[0][k])-mp.mpf(runs[1][k])) for k in ('mean','exponential_moment')}
        assert all(v<mp.mpf('1e-16') for v in differences.values())
        rows.append({'stage':stage,'s_expression':expr,'runs':runs,'absolute_precision_differences':{k:mp.nstr(v,12) for k,v in differences.items()}})
    return {'schema':'r199_continuous_score_v1','inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'dependencies':{'mpmath_version':mp.__version__,'mpmath_entry_sha256':hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()},
        'score_formula':'psi_s(r)=-s-r s phi_prime(r)/f_s(r), smooth side only',
        'targets':['E_fs psi_s=0','E_fs exp(abs(psi_s)/16)<=4','abs(phi_prime/phi)<=8 at selected points'],
        'tail_formula':{'assumptions':'X>1/2, abs(psi)<=1+8r and phi(r)<=exp(1/2-r)',
            'mean_absolute_tail':'2s exp(1/2-X)(9+8X)',
            'exponential_tail':'4s exp(9/16-X/2)'},
        'case_count':len(rows),'stage_counts':{'initial':2,'stress':2,'expanded':3},'precision_dps':[25,40],
        'score_cases':rows,'derivative_runs':[derivative_checks(25),derivative_checks(40)],'status':'PASS',
        'limitations':['Finite real one-dimensional kernel diagnostics, not original qualification/history or FULL.',
            'Explicit analytic truncation bounds do not certify mpmath quadrature, roots or floating rounding.',
            's=0 is an exact support-only zero score branch; no density division is performed outside that support.',
            'The irrational s expression is recomputed at each precision, not treated as an exact decimal input.',
            'No multidimensional score simulation, uniform proof or dimension-order fit is claimed.']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'score_checks.json');args=ap.parse_args()
    t=time.monotonic();r=run();args.output.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
    print('PASS: 7 score cases and 7 derivative points at 25/40 dps; seconds='+str(round(time.monotonic()-t,3)))
