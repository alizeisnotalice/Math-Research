# R199：截帽硬面进入通量、coarea 与资格交换

本稿证明一个全维度、全原尺度的固定软度面核估计。它保留真实进入前 p− 和固定帽 BJ，将硬跳幅度与一个 log 面积恰为 2 的 likelihood 函数分开，再用 R197 已证反集中压缩通量。原资格 G 的跳跃不被当作核跳；需要的 scale trace/BV 条件及其额外费用另列。固定 s 的面核费用确实改善，但不宣称原总尺度费或来源余项已付。

## FG1. 物理核、帽及准确进入前后值

固定原来源 y,v，一个窗口 0<a≤L≤b≤2a，及共同 s∈[0,1]。令

\[
 f_s=(1-s)h+s\phi,\quad h=1_{[-1/2,1/2]},\quad
 p_L(x)=L^{-n}\prod_l f_s((x_l-y_l)/L),\quad
 J(x)=P_{1,b}(x-v)>0.
\]

B≥0 不依正在积分的尺度 L；原应用取 B=B0/Wg，B0=K/[3(1−η)]、Wg=∏C((y_l−v_l)/b)，0<η<1。该帽来自 R198 MA1 的原 good/high-A 安全正扩大，原 α/capture/来源不重选。

记

\[
 F_L(x)={\min(p_L(x)^2,(BJ(x))^2)\over J(x)}.
\]

在进入面 Σ_i,ε(L)={x:x_i=y_i+εL/2}，ε=±1，令

\[
 R_{-i,L}(x_{-i})=\prod_{l\ne i}L^{-1}f_s((x_l-y_l)/L),\quad
 m_s=1-s+s\phi(1/2).
\]

除去多个坐标同时进入的 Lebesgue 零测集合，尺度方向的左右极限为

\[
 p^-={s\phi(1/2)\over L}R_{-i,L},\quad
 \delta p={1-s\over L}R_{-i,L},\quad
 p^+={m_s\over L}R_{-i,L}.
 \tag{FG1}
\]

闭硬面取进入后的值。cap 的实际核跳为

\[
 \Delta F={\min((p^+)^2,(BJ)^2)-\min((p^-)^2,(BJ)^2)\over J}\ge0.
 \tag{FG2}
\]

这里只除一次 J。B=0 或 δp=0 时跳为零；s=1 的全部硬面项先取零。若 R_-i=0，同样先零，不定义下面的 ratio。

## FG2. 保留 p− 与帽的精确压缩函数

对 s<1、p+>0、B>0，定义

\[
 \sigma_s={p^-\over p^+}={s\phi(1/2)\over m_s}\in[0,1),
 \qquad r={p^+\over BJ}>0.
\]

则

\[
 \boxed{\Delta F=B\,\delta p\,g_\sigma(r),\qquad
 g_\sigma(r)={\min(r^2,1)-\min(\sigma^2r^2,1)\over(1-\sigma)r}.}
 \tag{FG3}
\]

分段式为

\[
 g_\sigma(r)=
 \begin{cases}
 (1+\sigma)r,&0<r\le1,\\
 (r^{-1}-\sigma^2r)/(1-\sigma),&1<r<1/\sigma,\\
 0,&r\ge1/\sigma.
 \end{cases}
 \tag{FG4}
\]

σ=0 时第二段为 1/r、上端为∞；不使用 1/0。特别 g0(r)=exp(−|logr|)。若进入前 p−≥BJ，真实跳已为零，不能仍给每个硬面领取一个满帽价格。

函数 t↦gσ(e^t) 连续、先增后减，最大值 1+σ，且

\[
 \boxed{\int_{\mathbb R}g_\sigma(e^t)dt=2,
 \qquad\operatorname{TV}_{\mathbb R}(g_\sigma(e^t))=2(1+\sigma).}
 \tag{FG5}
\]

证明：r≤1 的 log 积分为 ∫0^1(1+σ)dr=1+σ；其余部分为

\[
 {1\over1-\sigma}\int_1^{1/\sigma}(r^{-2}-\sigma^2)dr=1-\sigma.
\]

σ=0 时后半积分为1，结论仍成立。两端极限均为零，故总变差为两倍峰值。另有直接但较粗的保留 pre-value 上界

\[
 \Delta F\le(1-\sigma^2)F^+,
 \qquad F^+=\min((p^+)^2,(BJ)^2)/J.
 \tag{FG6}
\]

它逐段可核；若 p+≤BJ 等号，跨帽时一般严格。下面主估计使用更准确的 FG3–5，而不是只用 FG6。

## FG3. 剩余 receiver 坐标的反集中与实际通量压缩

令原 source displacement count 为

\[
 m=\#\{l:|y_l-v_l|\ge3b/4\},\quad
 m_i=m-1_{\{|y_i-v_i|\ge3b/4\}},\quad
 h_0=1/16,\quad q_j=\min(1,\sqrt{128/(j+1)}).
\]

在固定 i,ε,L 面上，R_-i,L 是其余 n−1 个 receiver 坐标的概率密度。J 分成第 i 坐标值与 J_-i。因此

\[
 \log r=\log{R_{-i,L}\over J_{-i}}
             +\log{m_s\over LBJ_i(y_i+\varepsilon L/2)}.
 \tag{FG7}
\]

后项固定于这些 receiver 坐标。R197 已独审有限位移定理在 n−1 个坐标上给

\[
 \sup_t\Pr_{R_{-i,L}}\{\log r\in[t,t+h_0]\}\le q_{m_i}.
 \tag{FG8}
\]

它对所有 s∈[0,1]、L/b∈[1/2,1] 一致。这里只引用已证反集中，不假设来源坐标独立。n=1 时其余空间为零维、m_i=0、q0=1，使用平凡概率上界即可。

若非负可积 BV 函数 f 在 log 轴上按长度 h0 的网格分段，则

\[
 \sum_k\sup_{[kh_0,(k+1)h_0)}f
 \le {1\over h_0}\int f+\operatorname{TV}(f).
\]

理由是每段 sup 与该段平均值之差不超过该段变差；有限区间先证明再单调扩展。将 f(t)=gσ(e^t) 代入 FG5、再用 FG8，得到

\[
 \mathbb E_{R_{-i,L}}g_\sigma(r)
 \le\mathfrak a_{i,s}:=
 \min\left(1+\sigma,
 q_{m_i}\{2/h_0+2(1+\sigma)\}\right)
 \le\min(2,36q_{m_i}).
 \tag{FG9}
\]

该估计保留帽的低值与高值两侧，也保留了 p−/p+；J_i 的可能小值只改变 FG7 的 log 位移，不产生另一个 1/J_i 因子。

## FG4. 精确 coarea 与全尺度 fixed-s 面核价

对任意指定的、面上可测的权 0≤G_face≤1，定义核进入通量

\[
 \Phi_{s,B}[G_{\rm face}]
 =\sum_{i,\varepsilon}\int_a^b{dL\over L}{L\over2}
 \int_{\Sigma_{i,\varepsilon}(L)}
              G_{\rm face}(x,L)\Delta F(x,L)\,d\mathcal H^{n-1}(x).
 \tag{FG10}
\]

L/2 是 dlogL 的准确 coarea 系数，不是1。对固定 x 的 entry 时刻 L_i(x)=2|x_i−y_i|，换元 x_i=y_i+εL/2、dx_i=dL/2 给

\[
 \int dx\sum_{i:\ a<L_i(x)\le b}
 G_{\rm face}(x,L_i(x))\Delta_{L_i(x)}F(x)
 =\Phi_{s,B}[G_{\rm face}].
 \tag{FG11}
\]

多个坐标同时 entry 的 x 零测，不产生额外 corner 项。a 处的 kernel 值归初始项，只在(a,b]计后续跳；b 的闭面约定包含在右极限。

由 δp=(1−s)R_-i,L/L，单面的 L/2×FG3 积分为

\[
 {B(1-s)\over2}\int R_{-i,L}G_{\rm face}g_\sigma(r)dx_{-i}
 \le {B(1-s)\over2}\mathfrak a_{i,s}.
\]

两个面合并，积分全部尺度得

\[
 \boxed{\Phi_{s,B}[G_{\rm face}]
 \le B(1-s)\log(b/a)\sum_{i=1}^n\mathfrak a_{i,s}
 \le n(1-s)B\log(b/a)\min(2,36q_{(m-1)_+}).}
 \tag{FG12}
\]

这是全维度、全部原尺度的实际固定 s 核进入通量上界。s=1 时为零；s=0 时 σ0、FG3–9 都合法，R_-i 为硬核概率。若 a=b，通量为零。m=0 或小 m 时反集中可能只给平凡项，不能把超过 n 的阈值当作非空改善。

相比把所有尺度变化统一作为 2n 整核径向费，FG12 在硬面部分保留 1−s 及实际 likelihood 压缩。它不是连续尺度项的估计，也不是原资格交换项的估计，故不据此宣称总尺度阶数下降。

## FG5. 资格 G 的准确交换与 trace 条件

合同中的原权为 G=A²H∈[0,1]。FG10 仅需要一个指定的可测 face representative；普通 Lebesgue 可测函数的等价类并不确定其在 face 上的值，不能据此自动识别原 GP 的真实跳。

若对几乎每个 x，G(x,L) 在每个 kernel entry L_i(x) 有左右尺度极限 G−、G+，并且这些 pullback traces 可测，则准确有

\[
 \boxed{\Delta(GF)=G^+\Delta F+F^-\Delta G
                  =G^-\Delta F+F^+\Delta G,\qquad
             \Delta G=G^+-G^-.}
 \tag{FG13}
\]

这里是固定 x、沿 L 变化的 scale traces，不自动等于固定 L 的空间法向 traces。其正部满足

\[
 [\Delta(GF)]_+\le G^+\Delta F+F^-\,[\Delta G]_+.
 \tag{FG14}
\]

因此 FG12 可用于第一项。其余资格交换费必须原样保留为

\[
 \sum_{i,\varepsilon}\int_a^b{dL\over L}{L\over2}
 \int_{\Sigma_{i,\varepsilon}(L)}
 {\min((p^-)^2,(BJ)^2)\over J}(G^+-G^-)_+
                 d\mathcal H^{n-1}.
 \tag{FG15}
\]

它仍保留 p− 与帽，不能免费改成零或当作合法 future 容量。若另证 ΔG≤0，则局部没有正资格交换费；本稿没有对原 same-alpha G 证明该符号，留给本轮来源路线。

仅为有限个 kernel entry 写 FG13，不必假设 G 整条路径 BV；需要的只是上述 traces。若要进一步把整个尺度上包络分解为连续项、面项及资格变化，足够条件是：G 是 jointly measurable 的右连续尺度 BV 族，0≤G≤1，且所用带 F 权的变差积分有限（或先有限限制、后非负极限）。此时 product-BV 规则给

\[
 d(GF)=G^+\,dF+F^-\,dG.
 \tag{FG16}
\]

cap F 的连续导数为

\[
 \partial_{\log L}^{\rm ac}F
 ={2p_L^2\over J}1_{\{p_L<BJ\}}\sum_l\kappa_s((x_l-y_l)/L),
\quad\kappa_s(r)=-1-rs\phi'(r)/f_s(r),
\]

而其硬跳是 FG2 的非负跳。故 sup_L GF 由初始 G_aF_a、该连续导数的 G 加权正部、FG10 的 G+ 面项、以及完整

\[
 \int_{(a,b]}F^-\,(dG)_+
 \tag{FG17}
\]

控制。FG17 还包含不与 kernel entry 重合的 G 跳、其连续和奇异连续变化；不能只留下 FG15。若 G 仅可测，没有上述 trace/BV 资格，就不能宣称 FG13–17 已构成原完整 path 的预算，虽然 sup GF≤sup F 的旧粗正界仍可用。

原 G 目前只在 actual selector/history 下已有资格；改变 L 不保证 FIRST、terminal/capture/history 仍合法。要沿所有 L 使用 FG16，必须给出一个与原值一致、具有上述性质的实际资格族，或明确另作正上放。原 same-alpha 不允许在每个 L 独立重选。本稿未补造这种资格。

## FG6. 原来源/时钟的算子形态与软度费用

对固定 s，若只估计 FG10 的 kernel-entry 部分、使用指定可测0≤G_face≤1，R198 的 fixed-time 后验资格可保持：固定(ω,V,j,y,t)时Π_t独立receiver。正去掉其他 masks 与 bad-source 后验质量后，B=B0/Wg 的面核部分至多

\[
 (1-s)B_0\log(b/a)\,
 \mathbb E\sum_V\sum_j\int_{I_j}{dt\over t}
 \int\beta_V(dy)\int\Pi_{y,j,t}(dv)
       {\sum_i\mathfrak a_{i,s}(y,v)\over W_g(y,v)}.
 \tag{FG18}
\]

I_j 是原 x-independent 辅助时间窗，空窗/e_t0先零。固定-time wt 已在Π中，不可再乘一次；若先用含wt的kernel界，则应对ν/e_t积分，得到同式。此式只是原核进入通量的显式来源上界，仍有1/Wg、j/time以及原ν/e归一，不是已经支付的W_A价；资格交换FG15/17与连续项另留。

FG18 按同一共同固定窗口显示。若 a、b 随 ω、V 变化，log(b_V/a_V) 必须留在各 V 项内，或统一正上放为 log2；不能从 EΣV 提出某个单窗常数。其余可能随窗变化的 B0、s 及来源费也按原窗口账保留。下面 FG19 同样是一个固定窗口的 prior 平均。

本稿的改进固定于共同 s。Jeffreys prior 平均可直接Tonelli：

\[
 \int\Phi_{s,B}[G_s]d\pi(s)
 \le B\log(b/a)\sum_i\int(1-s)\mathfrak a_{i,s}\,d\pi(s)
 \le nB\log(b/a)\min(1,18q_{(m-1)_+}).
 \tag{FG19}
\]

这里用了∫(1−s)dπ=1/2及FG9。它是平均，不是任意receiver自适应s的免费界。对于预先固定的有限soft菜单，朴素正上放可求和各固定s价格，真实菜单费仍在。连续soft selector若要套R198平方根混合，必须另证该face difference的共同混合资格；不能从两个cap分别成立的upper bounds相减推出ΔF的upper bound。旧整核Jeffreys+径向尺度界仍可用，但不允许把FG12的1−s压缩免费附在其sup_s之后。

## FG7. 检查点与未付范围

本稿已证FG3–5的准确cap jump、FG10–11的全维coarea、FG12的likelihood压缩通量，以及FG13–17在明确trace/BV条件下的资格交换。核通量保留真实p−，反集中只对剩余receiver产品核使用，所有尺度和硬面单位完整。

实际原G尚未获得本文要求的path/BV/trace或正交换费总账，FG18的来源权重也未支付。固定s核进入费的改进不等于总体尺度与来源降阶，不以新符号把这些余项称为已付。本稿不重做Astra的同α来源补偿，不写额外TeX、不编译PDF，完成后停止。
