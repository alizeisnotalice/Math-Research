#!/usr/bin/env python3
"""Verify artifact hashes and replay finite numerical evidence, not a proof checker."""
import argparse,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=Path);a=p.parse_args()
manifest=json.loads((ROOT/'manifest.json').read_text())
for name,digest in manifest.items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
print('Verified',len(manifest),'file hashes',flush=True)
if not a.verify_only:
 if a.output_dir is None:p.error('--output-dir required')
 a.output_dir.mkdir(parents=True,exist_ok=True)
 for stem in ['face_checks','score_checks']:
  out=a.output_dir/(stem+'.json')
  if out.exists():p.error('Use a fresh result output directory')
  subprocess.run([sys.executable,str(ROOT/(stem+'.py')),'--output',str(out)],check=True,env=os.environ.copy())
  assert out.read_bytes()==(ROOT/(stem+'.json')).read_bytes()
  print(stem+': complete JSON byte-identical',flush=True)
