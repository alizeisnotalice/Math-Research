# R199 capped-face jump: exact phase

Nine rational fixtures passed the direct capped-square jump comparison using Fraction arithmetic. Initial cases cover zero total density, zero left trace and zero increment. Threshold cases put c exactly at a, exactly at a+delta_p, and strictly between them. Expanded cases cover a tiny left trace, a large trace with a tiny increment at an already reached cap, and a large fully uncapped jump. The three-stage counts are 3/3/3.

For total T=a+delta_p>0, the code computes D=min(T^2,c^2)-min(a^2,c^2) directly. An independent branch calculation checks D and the residual from the proposed upper bound. If c<=a, the jump is zero. If a<c<T, the residual is a^2(1-c^2/T^2). If c>=T, the bound is equality. At T=0 the jump is zero and no quotient a/T is formed. Each fixture is also scaled by 1/1024, 7 and 10^6 to check the exact degree-two homogeneity and invariant dimensionless factor, giving 27 further checks without introducing additional parameter fixtures.

These are finite abstract nonnegative scalar inputs, not physical kernel examples. The physical mapping a/delta_p=s phi(1/2)/(1-s) is not used to relabel rational data as original faces. No coarea integral, qualification exchange term, same-alpha capture or FULL/history instance is evaluated. The authored profile and coupled-alpha interfaces were subsequently supplied; their bounded exact extensions are described below. No physical face/coarea scan was run.

L03 was applied to keep exact rational residual signs distinct from uncertified floating diagnostics. No interval API or external theorem is invoked. The script uses only Python's standard library and supports --output PATH; relocation needs its local task_contract.md, hashed with a filename key in JSON. This note records exact finite algebra and separate physical scalar-score diagnostics, not a completed physical-budget result.

## Additional physical continuous-score diagnostics

The separately assigned score_checks.py evaluates seven softness values at 25 and 40 decimal digits: initial s=.25,.5; stress s=.0001,.9999; expanded s=0,1,1-1/sqrt(128). The last expression is recomputed at each precision, not treated as an exact decimal. It uses the actual E3 kernel and E2 derivative, with E2(0)=1 and E3(0)=1/2. The even score is psi=-s-r s phi'/f_s on each smooth side. Its mean-zero target is different from the uncentered ac scale score mean; the centering is retained.

The hard part and exterior are integrated separately. At s=0 the score is defined as zero only on the hard support, and its mean/exponential moment are exactly 0/1 without dividing by a zero exterior density. At s>0, endpoint sign changes on each smooth side are bisected to add numerical zero seams for exp(abs(psi)/16). This is not a proof that all roots were located or that the score is monotone. Such seams and two-precision comparisons are numerical quadrature controls only.

Finite cuts X=120 and 180 are used. From the supplied bounds abs(psi)<=1+8r and phi(r)<=exp(1/2-r), the omitted absolute-mean contribution is at most 2s exp(1/2-X)(9+8X), and the omitted exponential-moment contribution is at most 4s exp(9/16-X/2). These analytic truncation expressions are recorded independently of finite quadrature accuracy. The finite mean is also compared against the independently integrated boundary identity s(1-s)(phi_mass-1)-2sXphi(X). All mean and boundary residual checks pass 1e-18. The means round to zero in the reported precision; this is not an exact interval enclosure of zero.

The exponential moments range from 1 through approximately 1.05144234 and pass the target bound 4 even after adding the displayed truncation allowance. Their largest observed 25/40 difference is below 1.78e-26. Seven selected radii 0,.25,.5,.5001,1,4,16 check abs(phi'/phi)<=8; their largest numerical value is about 2.181622. These finite points and softness values do not certify the uniform analytic estimates. No multidimensional score simulation or dimension-order fit is performed.

Reproduce the physical score module with the existing mpmath 1.3.0 vendor, without installation:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 score_checks.py --output score_checks.json
```

The module uses standard import mpmath and records version/entry SHA. Its only local hashed input is task_contract.md. The runtime was about 4.1 seconds. A temporary-directory copy of this script and contract was independently run and complete JSON byte equality passed. The face module remains unchanged by this added physical score task. The score task itself does not certify actual coarea, eligibility exchange or original FULL source/history structure. The separately added finite common-source alpha checks below remain abstract algebra.


## Authored profile and coupled-alpha additions

Without adding generic fixtures, the face script now maps each positive-increment case to sigma=a/(a+delta_p) and r=(a+delta_p)/c. It compares the direct g_sigma expression with its three-branch formula and checks D=c delta_p g_sigma(r) and the peak bound 1+sigma. Its log-area is checked by evaluating the exact antiderivative contributions 1+sigma and 1-sigma (or 1 and 1 when sigma=0), whose sum is 2. This is algebraic antiderivative evaluation, not a numerical physical coarea integral. Zero increment is skipped before division.

Three additional finite common-source fixtures use the author's two-atom arrays: a=(4,1), k=(1,1/2), J=(1,1), Q=(1,41/100), wg=(1/4,2/5), nu=(1,1), K=1 and Dq=3/2. Other gates are fixed true and E(p) is computed with p wg<=KQ. At both p endpoints the same total scalar QJ=sum J nu and capture formula alpha=(Dq-sum_E min(a,k)nu)/QJ are recomputed. No two alphas are chosen freely. The source capacity sum k nu<=Dq is checked exactly.

The initial case p=.9 to .95 loses no source, leaves both alphas zero, and has positive target square jump 37/6400; the FS9 nonpositive criterion is false. The stress case p=1 to 21/20 loses the second source, gives alpha 0 to 1/4, target A 1/4 to 11/48, and net square jump -471/102400. Its exact FS9 left/right sides are 1/16 and 1/28, so the criterion correctly predicts a nonpositive jump. All tested caps are Bcap=2 and uncapped at these p endpoints, making sqrt(Fminus/Fplus)=pminus/pplus exactly rational; no floating square-root sign comparison is used. The expanded case scales nu and Dq together by 7/3, preserving the recomputed alphas, net jump and FS9 sides.

Each case checks lost_mass=(alpha_plus-alpha_minus)QJ, the active target A decrease, the exact signed-square identity and its lower negative-compensation bound. This supplies three small finite scalar coupled examples, not original physical kernel or qualification realizability. It does not pay arbitrary gate-entry terms or a general face budget. All face and score scripts were finally rerun and then independently copied with their contract to a temporary directory; both complete JSON files matched byte-for-byte. No other files were edited.
