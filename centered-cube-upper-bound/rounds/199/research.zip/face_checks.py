#!/usr/bin/env python3
"""Finite exact capped-square face jumps; no physical coarea claim."""
import argparse
from fractions import Fraction as F
import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent


def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [encode(v) for v in x]
    return x


def jump(a,d,c):
    assert a>=0 and d>=0 and c>0
    T=a+d
    D=min(T*T,c*c)-min(a*a,c*c)
    if T==0:
        assert D==0
        return {'total':T,'D':D,'factor':None,'upper':F(0),'residual':F(0),'branch':'zero-total'}
    factor=1-(a/T)**2
    upper=factor*min(T*T,c*c)
    if c<=a:
        direct=F(0);residual=upper;branch='already-capped'
    elif c<T:
        direct=c*c-a*a;residual=a*a*(1-(c/T)**2);branch='crosses-cap'
    else:
        direct=T*T-a*a;residual=F(0);branch='uncapped-or-upper-tie'
    assert D==direct and upper-D==residual and 0<=D<=upper
    return {'total':T,'D':D,'factor':factor,'upper':upper,'residual':residual,'branch':branch}


def profile_check(a,d,c,D):
    if d==0:return {'skipped_zero_jump':True}
    sigma=a/(a+d);r=(a+d)/c
    direct=(min(r*r,F(1))-min(sigma*sigma*r*r,F(1)))/((1-sigma)*r)
    if r<=1:piece=(1+sigma)*r
    elif sigma and r>=1/sigma:piece=F(0)
    else:piece=(1/r-sigma*sigma*r)/(1-sigma)
    assert direct==piece and D==c*d*direct and 0<=direct<=1+sigma
    first_area=1+sigma
    second_area=((1-sigma)-sigma*sigma*(1/sigma-1))/(1-sigma) if sigma else F(1)
    assert first_area+second_area==2
    return {'sigma':sigma,'r':r,'g_direct':direct,'g_piecewise':piece,
        'log_area_first':first_area,'log_area_second':second_area,'log_area_total':first_area+second_area,'status':'PASS'}


def coupled(stage,pminus,pplus,mass_scale):
    pminus,pplus,mass_scale=map(F,(pminus,pplus,mass_scale))
    nu=[mass_scale,mass_scale];aa=[F(4),F(1)];kk=[F(1),F(1,2)]
    JJ=[F(1),F(1)];QQ=[F(1),F(41,100)];wg=[F(1,4),F(2,5)]
    K=F(1);Dq=F(3,2)*mass_scale;QJ=sum(j*m for j,m in zip(JJ,nu))
    assert sum(k*m for k,m in zip(kk,nu))<=Dq and pplus>=pminus
    def state(p):
        E=[p*wg[i]<=K*QQ[i] and aa[i]>0 for i in range(2)]
        alpha=(Dq-sum(min(aa[i],kk[i])*nu[i] for i in range(2) if E[i]))/QJ
        assert alpha>=0
        rho=[max(F(0),1-(kk[i]+alpha*JJ[i])/aa[i]) for i in range(2)]
        A=[rho[i]*JJ[i]/(3*QQ[i]) if E[i] else F(0) for i in range(2)]
        return E,alpha,rho,A
    Em,am,rm,Am=state(pminus);Ep,ap,rp,Ap=state(pplus)
    assert all(not Ep[i] or Em[i] for i in range(2))
    lost=[i for i in range(2) if Em[i] and not Ep[i]]
    lost_mass=sum((min(aa[i],kk[i])*nu[i] for i in lost),F(0))
    assert (ap-am)*QJ==lost_mass
    target=0;J=JJ[target];S=3*QQ[target];a=aa[target]
    Bcap=F(2);Fm=min(pminus*pminus,(Bcap*J)**2)/J;Fp=min(pplus*pplus,(Bcap*J)**2)/J
    assert Ap[target]>0 and Em[target] and Ep[target]
    decrease=(ap-am)*J*J/(a*S)
    assert Am[target]-Ap[target]==decrease
    negative=Fm*(Am[target]**2-Ap[target]**2)
    compensation_lower=2*Fm*Ap[target]*decrease
    net=Ap[target]**2*Fp-Am[target]**2*Fm
    assert negative>=compensation_lower
    assert net==Ap[target]**2*(Fp-Fm)-negative
    assert net<=Ap[target]**2*(Fp-Fm)-compensation_lower
    # All these approved fixtures are uncapped, so the FS9 square root is exact.
    assert Fm==pminus*pminus/J and Fp==pplus*pplus/J
    rF=pminus/pplus
    lhs=J*lost_mass/(a*QJ);rhs=rm[target]*(1-rF)
    assert (net<=0)==(lhs>=rhs)
    return {'stage':stage,'p_minus':pminus,'p_plus':pplus,'mass_scale':mass_scale,
        'inputs':{'nu':nu,'a':aa,'k':kk,'J':JJ,'Q':QQ,'wg':wg,'K':K,'Dq':Dq,'QJ_original_scalar':QJ,'fixed_other_gates':'all true'},
        'E_minus':Em,'E_plus':Ep,'lost_indices':lost,'lost_capture_mass':lost_mass,
        'alpha_minus':am,'alpha_plus':ap,'rho_target_minus':rm[0],'rho_target_plus':rp[0],
        'A_target_minus':Am[0],'A_target_plus':Ap[0],'F_minus':Fm,'F_plus':Fp,'Bcap':Bcap,
        'net_square_jump':net,'negative_compensation':negative,'compensation_lower':compensation_lower,
        'FS9_left':lhs,'FS9_right':rhs,'FS9_holds':lhs>=rhs,'status':'PASS'}


def run():
    fixtures=[
        ('initial','zero_total',0,0,1),
        ('initial','zero_left_crossing',0,1,'1/2'),
        ('initial','zero_increment',1,0,1),
        ('threshold','cap_at_left',1,1,1),
        ('threshold','cap_at_right',1,1,2),
        ('threshold','strict_crossing',1,1,'3/2'),
        ('expanded','tiny_left','1/1000000000',1,'1/10'),
        ('expanded','large_left_tiny_increment',1000000,'1/1000000',1000000),
        ('expanded','large_uncapped',1000000,1000000,3000000),
    ]
    rows=[]
    for stage,name,a,d,c in fixtures:
        a,d,c=map(F,(a,d,c));base=jump(a,d,c);scales=[]
        for scale in (F(1,1024),F(7),F(1000000)):
            scaled=jump(scale*a,scale*d,scale*c)
            assert scaled['D']==scale**2*base['D']
            assert scaled['upper']==scale**2*base['upper']
            assert scaled['residual']==scale**2*base['residual']
            assert scaled['factor']==base['factor']
            scales.append({'scale':scale,'D':scaled['D'],'upper':scaled['upper'],'status':'PASS'})
        rows.append({'stage':stage,'name':name,'a':a,'delta_p':d,'cap_c':c,'check':base,'profile_check':profile_check(a,d,c,base['D']),'homogeneity_checks':scales,'status':'PASS'})
    coupled_rows=[coupled('initial','9/10','19/20',1),coupled('stress',1,'21/20',1),coupled('expanded',1,'21/20','7/3')]
    assert coupled_rows[0]['net_square_jump']>0 and coupled_rows[1]['net_square_jump']<0
    assert all(coupled_rows[1][key]==coupled_rows[2][key] for key in ('alpha_minus','alpha_plus','net_square_jump','FS9_left','FS9_right'))
    return {'schema':'r199_face_jump_v2','arithmetic':'stdlib Fraction only',
        'inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'formula':'D=min((a+delta_p)^2,c^2)-min(a^2,c^2)',
        'upper':'[1-(a/(a+delta_p))^2]min((a+delta_p)^2,c^2), for a+delta_p>0',
        'case_count':len(rows),'stage_counts':{'initial':3,'threshold':3,'expanded':3},
        'cases':rows,'coupled_same_alpha_cases':coupled_rows,'coupled_same_alpha_case_count':3,'status':'PASS','physical_validation':'no physical face/coarea integral performed',
        'limitations':['Finite exact nonnegative scalar inputs; not actual physical face/FIRST/history examples.',
            'The zero-total branch has D=0 and does not evaluate a/(a+delta_p).',
            'At a physical face a/delta_p=s phi(1/2)/(1-s) is a mapping only; these rational fixtures do not prove it or a geometric budget.',
            'Three coupled-alpha checks are finite scalar common-source arrays, not physical eligibility or a coarea integral; no full original source/history construction.']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'face_checks.json');args=ap.parse_args()
    r=run();args.output.write_text(json.dumps(encode(r),indent=2,sort_keys=True)+'\n')
    print('PASS: 9 Fraction jump fixtures and 27 exact homogeneity checks; 3 coupled-alpha fixtures; no physical face integral')
