# R199：原资格下截帽硬面通量与共同来源容量

基线R198：5cdb4402187db6c992e8ace296d85ffd3d2db0a5，已推送。一般任意正L1根阶上界目标不变。

本轮直接攻全局几何联合预算，不以重复归约或反例排除计成果。物理核h=1[-1/2,1/2]，φ=h*w，w(r)=∫0^1exp(-|r|/t)dt，f_s=(1-s)h+sφ，p=P_s,L(x-y)，J=P_1,b(x-v)。原a≤L≤b≤2a。来源β、ν分别由共同父控制，不设ν≤β；Π_t=1_Zt wtν/e_t。原A=1good ρJ/(pv+pplus+J)，ρ=[1-(DK0+αJ)/(TΔ)]+，同一α及capture不重选。

R198已证明：共同软度sup的Jeffreys平方截帽费2√(2n)；m个来源目标位移≥3b/4给固定参数截帽Ba_m；全尺度粗界多付1+2nlog2，原来源仍有a_m/Wg和全部j/time未付。一般密度尺度score工具不能直接套inverse-J帽。

准确研究对象：固定s的面xi=yi±L/2，p^-为进入前、δp=(1-s)L^-n∏_{l≠i}f_s((xl-yl)/L)，固定帽BJ。硬面增量Δcap=[min((p^-+δp)^2,(BJ)^2)-min((p^-)²,(BJ)^2)]/J。dlogL的coarea系数L/2。真实资格权G=A²H∈[0,1]（H含原high/reciprocal/history/capture/唯一j），比较G+F+−G-F-须保留资格交换项，不能假设G单调/BV或在改变L时仍合法FIRST。

主成功标准：证明一个新且实际有界的联合通量/来源估计，减少现有尺度与来源损失；若只能得到正确恒等式而没有付款，不称完成。优先保留same-alpha reserve ∫k(μ−χ)≤αQJ与实际target预算。允许阶段性检查点但不以新符号命名缺口代替进展。

Astra负责原来源联合攻坚 flux_source_budget.md；Sol high辅助准确jump/coarea/资格交换及可用压缩 face_geometry.md；Sol high先独筛再独审audit.md；Sol medium在准确公式确定后做本机多阶段数值与精确证书。父统一整合和主要推导。各自独占文件，不git、不spawn、不覆盖其他Agent；交付后停止。只提交完成独审的每轮，详细LaTeX不编译PDF，精简文件。来源与window费用完整保留。
