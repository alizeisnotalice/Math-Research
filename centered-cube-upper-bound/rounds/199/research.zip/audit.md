# R199 独立审计

仅维护本文件；其他作者并行，无Git/spawn/他人文件修改。先读task_contract.md，未读本轮作者稿即作以下独立筛查。当前为预审检查点，不是全局付款认证。

## 1. 准确物理硬面跳与固定帽

先固定原window的b、共同s、来源y/v以及B；J=P_(1,b)(x-v)>0不随dummy尺度L改变。单坐标在L0=2|xi-yi|从outside进入闭hard core。避开同时entry的零测集合，记q=p^-，

δp=(1-s)L^(-n) product_(l!=i) f_s((xl-yl)/L)，p^+=q+δp，c=BJ。

F_L=min(p_L²,c²)/J的真实entry增量为

ΔF=[min((q+δp)²,c²)-min(q²,c²)]/J。

q>=c时为0；q<c<=q+δp时为(c²-q²)/J；q+δp<c时为(2qδp+δp²)/J。三段连续兼容，且

0<=ΔF<=min(2Bδp,B²J,(2qδp+δp²)/J)。

其中2Bδp来自平方帽对p的斜率上界2c。若想保相对entry强度，q/p^+=r_s=s phi(.5)/(1-s+s phi(.5))，则ΔF<= (1-r_s²)F^+；这只是同一固定帽的代数压缩，不是来源预算。

原真实likelihood截断p²/J·1{p<=BJ}不是单调帽；一旦跨过cap它可向下跳，因此不能直接把上述正entry公式称为它的准确跳。原cut到帽的额外部分仍须像R198那样支付。B若随L/terminal或receiver-selector改变，则还需帽交换项；本节固定B可取原source-fixed B0/Wg，不可暗中抽出actual adaptive wg。

## 2. coarea与真实尺度量纲

逐x的entry位于L=2|xi-yi|。对任意非负可测跳权，xi=yi±L/2的换元为

dx_i=dL/2=(L/2)dlogL。

因此积分所有entry跳，必须用(L/2) sum_(i,±) integral_(face) ΔF_i dx_hat dlogL，不能丢L或重复计两个面。固定L的坐标交面，以及不同坐标同时entry的receiver集合，在相应Lebesgue/coarea积分中零测；这不等于actual selector锁定的face可以免费删除。初始L=a的闭面值先在F_a计入，之后仅积(a,b]entry。

单个δp在face上的x_hat积分为(1-s)/L；乘coarea并加两侧，给每坐标(1-s)dlogL。故完整物理密度entry积分恰n(1-s)log(b/a)。只用G<=1、ΔF<=2Bδp，得到帽face粗界2Bn(1-s)log(b/a)。它保B/Wg和线性硬费，不登记为新的root/共同source付款；B若依receiver则不能从face积分提出。

## 3. 原资格G=A²H的尺度交换

若一个确有定义的尺度族G_L∈[0,1]具有左右traces，记ΔG=G^+-G^-。精确有

G^+F^+-G^-F^-
=min(G^+,G^-)ΔF+F^+(ΔG)_+-F^-(-ΔG)_+。

因此上界须保F^+(ΔG)_+，或用等价的另一trace分解；不能只留下GΔF。仅G有界并不保证这些交换项的总变差有限。连续分部积分还需G沿L的BV/AC资格、相应traces及可积分的F dG；原alpha/capture/high/history/unique-j并未免费给出这些假设。

原输入只给每个receiver一个actual selector L(x)，不自动给所有dummy L一族同样合法FIRST/capture/history对象。若沿L重新计算A、rho、alpha、Hhat、T/D、terminal g、alive集合、high或bad，则须逐项保留原共同来源及合法future资格；不能只改p就沿用另一个尺度的good/high门。特别same-alpha不是预先可微性或单调性结论。

可以合法冻结所有原actual G(x)在dummy L中，再对纯kernel取包络；这时没有dummy资格交换，但good/high关系只在actual L成立，不能自动拿到每个dummy face上收费。反过来若要在face使用重新计算的good/capture，就必须给出上述family资格及交换费。两条方案不能各取有利部分拼接。

## 4. 当前预审结论

物理固定帽jump、L/2 coarea和资格交换精确式通过独筛。它们仅是合法机制/范围，不构成原source交通的新全局价。后续审稿将检查是否真的控制weighted face与资格交换，而非将BV形式归约或未知source量改名为付款。保原Lebesgue dx、beta/nu共同父但无互相排序、原posterior/e、same-alpha和全部window/j/time账。等待两作者准确命题及全文后审，不重复攻坚或扩反例搜索。


## 5. 同alpha孤立outer-face准确候选：条件独筛

收到父准确命题后，未读作者稿先独推。固定该face的两trace，若Dq、QJ、a_z=TDelta_z、k_z=DK0_z、wg及S_z=p_z+pplus_z+J_z均无跳，且capture E的其余资格不变，E只由py wg<=KQ_z因py上跳而改变，则E^+ subset E^-。此时

δα QJ=integral_(E^-\E^+) min(a,k)nu>=0。

这需要原E完整定义定位；当前不把该嵌套作为无条件原事实。若E含原high或其他上扩门，则不能直接成立。nu为L1可以帮助消除某些固定物理坐标hardface的同时原子，但不自动排除good/high/threshold资格的正质量交换，也不证明整个actual尺度family可用。

在仍有效的共同good target A^+>0上，rho^+>0且rho^->=rho^+，从同一原reserve精确得到

A^- - A^+ = δα J²/(a_v S_v)。

因此uncapped正companion单槽跳为

(p^+)²(A^+)²/J-(p^-)²(A^-)²/J
=(A^+)²[(p^+)²-(p^-)²]/J-(p^-)²[(A^-)²-(A^+)²]/J，

第二项的被减量>=2(p^-)² A^+ δα J/(a_v S_v)。共同target且A^+>0的资格不能省略；rho被截为0或target掉出good的部分须按实际正部/指标另列。

若研究的是固定帽F而非uncapped p²/J，准确负项是F^-[(A^-)²-(A^+)²]，下界为2F^- A^+ δαJ²/(a_vS_v)。只有F^-=(p^-)²/J时才恢复父所写的系数。两侧都在原good/highA给定的固定cap内可用该简式，不能对任意帽trace免费沿用。

即使E嵌套成立，若e的trace固定，原high py e>=2Kq会因py上跳而扩张；允许Zg同时删除时e还可能下跳，故high一般也可改变两个方向。无论何种情况，H^+新增行不能借用H^-未存在交通的负补偿。须在共同H槽计算上述有限跳，再完整保留资格新增项；history、unique-j等若变亦同。此候选给正确的same-alpha补偿机制，但尚非全局来源通量付款。


## 6. 精确硬面profile与remaining-coordinate反集中：候选独筛

收到Sol准确式后先独推，尚未读作者全文。固定s<1，sigma=s phi(.5)/(1-s+s phi(.5))，r=p^+/(BJ)。合同的DeltaF只除一次J，精确为

DeltaF=B delta p g_sigma(r)，
g_sigma(r)=[min(r²,1)-min(sigma²r²,1)]/[(1-sigma)r]。

g=(1+sigma)r于r<=1；中段为(r^-1-sigma²r)/(1-sigma)；r>=1/sigma时0。sigma=0时后段1/r。该log-profile单峰，峰1+sigma，integral g_sigma(exp t)dt=2。以h0=1/16分箱，上Darboux和<=2/h0+TV=32+2(1+sigma)<=36。

固定face坐标后，remaining receiver坐标确按归一化产品R_-i分布。log r是该n-1维likelihood和加一个fixed face常数；R197有限位移反集中仍给q_(m_i)，m_i=m-1{|di|>=3/4}。故期望profile<=min(1+sigma,[32+2(1+sigma)]q_(m_i))。任何已指定可测0<=G_face<=1可正上放，不需将来源坐标独立化。

coarea L/2乘delta p=(1-s)R_-i/L，两面相加给(1-s)B；全尺度face核因此<= (1-s)B log(b/a) sum_i min(1+sigma,[32+2(1+sigma)]q_(m_i))。它为实际fixed-s面核的显式改进；m可比n时有反集中节省，但source帽B=B0/Wg和原资格交换尚未支付。s=1原跳零不定义sigma=1的商；n=1或m=0的remaining空维按q0=1处理，s=0 profile仍合法。

仅指定measurable G_face并不证明它等于actual尺度族G的trace，更不给该族BV。完整path仍须保§3的资格交换及非kernel的G跳。等待全文后核验其是否准确区分这些范围。


## 7. 连续score与likelihood反集中的联合候选：独筛

父发送准确式后先独推，未读其证明。若原phi的log-Lipschitz常数用保守8，则|psi_s(X)|<=1+8|X|。X按f_s分布，phi=h*w且w是权2t的Laplace_t混合，故E exp(|X|/2)<=2exp(1/4)，从而E exp(|psi|/16)<=2exp(5/16)<4。psi中心化，展开指数矩可得

log E exp(lambda psi)<=1024lambda²/(1-16|lambda|)，|lambda|<1/16。

原物理receiver乘积下S=sum psi_i遂为双侧subgamma(v=2048n,c=16)，P{|S|>=sqrt(2vt)+ct}<=2exp(-t)。这是receiver独立，不是source独立。

对任意事件概率<=q，q>0，Lq=log(2/q)，layercake和变量替换给

E|S|1_event <= T(q)
=q{sqrt(2v)[sqrt(Lq)+1/(2sqrt(Lq))]+c(Lq+1)}。

q=0先取零，q=1时Lq=log2非奇异。以Y=log(p/(BJ))的双侧h0箱调用R197反集中，每箱概率<=q_m，因此

E|S|exp(-|Y|)<=2T(q_m)/(1-exp(-h0))。

固定帽的尺度ac正导只在p<BJ时为2p²/J·(S-n(1-s))_+；丢负平均后可正放为2B p |S|exp(-|Y|)。因此ac正变差积分<=4B T(q_m)/(1-exp(-h0))。帽水平的链法则按a.e.尺度使用，level等号处不免费加入正原子；真实hard entry由§6另计。

该联合式可改进fixeds平方帽全尺度核工具，全部profile/coarea及softmix/source费用仍须保留。它没有同时控制原资格G或复制same-alpha负项，待全文审核。


## 8. 作者后读：face与连续score完整稿

完成§6独筛后全文核验 face_geometry.md FG1–19通过：精确profile、log面积与TV、remaining-coordinate概率、L/2 coarea、固定s全尺度face价均正确。FG13/16的product-BV左右值、全部非kernel dG变化和trace而非任意face代表元的区别准确；未假原G已具BV。最终窄修已实读：B不依正在积分的L；FG18仅逐共同固定窗，变窗log(b/a)留各V内或用统一log2，FG19同固定窗范围。无未处理修项。

完成§7独筛后全文核验 score_anticoncentration.md SC1–5通过。原phi log-Lip8、exp矩、双尾Chernoff、事件rearrangement与两个likelihood半轴的正求和均正确。实际帽ac导数保负平均与level链法资格，初始Ba_m来自R198，非kernel资格费没有被删去。SC5可使用已审FG12合成完整fixeds尺度界。

全soft接缝须先对完整F应用R198 Jeffreys平方帽，再把L上确界正放入同一prior积分，再使用每s完整BV界；此顺序合法。不能把FG12的face差作为两个已知soft上界之差去混合。所得全soft硬面成本仍可为n级，1/Wg及原source/time账保留，未称一般root。


## 9. 原physical trace的cluster补充：独筛

收到Astra准确补充后独推。窄读原R128 proof.md RT4–6与R125 proof.md457–458，确认fixed-j的Z_t先于receiver且nested，B=1{R<=L}1_QR不减；R117 joint_geometry.md JG1–4亦直接给原Z_t结构及单调性。完整S_g/E定位由作者责任稿列出后再核。

不预设good等号面nu零。若固定合法s,R,j支上p_y有正hard跳，a_z/k_z/Q_z/wg有共同trace，Zg只缩、B只增，则对nu-a.e.z，有

limsup_(L down L0) U_L(z) <= liminf_(L up L0) U_L(z)。

理由是右侧任一正capture cluster给右good极限，而p+>p−及wg>0使左good严格；左最终同样在carrier且B0。右U不超过共同min(a,k)，左趋该值。a0或k0时U以min包络趋0。nu有限且局部T有界给统一可积包络，reverseFatou和Fatou可得积分同序，因此QJ>0及Dq共同trace下任意右alpha cluster>=任意左alpha cluster。

该cluster序不自动给U/alpha/A/G存在单侧trace，也不证明完整尺度BV。有限跳补偿仍仅在实际所需traces存在处使用；原H、high、history等交换照旧保留。若允许Zg同刻删除，e_g也可下跳，不能只看p正跳而预判high单向。


## 10. 作者后读：原capture/同alpha有限跳完整稿

全文核验 flux_source_budget.md 通过。实际窄读原R127 proof.md264–294确认S_g=Z_g\D_g、E与原RC定义；R125457–458确认B，R128RT4–6及R117JG1–4确认固定source/删除/物理共同参数。FS-A仅在共同合法比例带、同s/R/j/window且所需trace存在处给精确跳；FS3a给更稳健cluster序，未假good等号来源nu零、未补造整个family的BV。

FS6共同活跃target的A差系数、FS7固定帽的负补偿，以及FS9等价条件均正确；FS9由rho^+<=rho^- sqrt(F^-/F^+)直接推出，饱和帽r_F=1时非正净增量自动成立。它不是原raw交通为零，也不将实际有限jump推广给任意另选alpha。

FS10–11完整保留H变化及共同合法状态以外的进入部分；新high、reciprocal/history、unique-j或time窗口入口不能领共同状态的负项。FS13的coarea、有限截断/正项与补偿项分别积分、避免无穷减无穷均正确。FS14明确仍需同一面测度和真实beta Pi²配重下的lost-capture联合下界/净积分控制；当行reserve仅给上界，不能冒充该下界。未认证一般source根阶付款。


## 11. 数值静态核验与报告/driver窄审

逐行静核face_checks.py：9项通用Fraction jump及27次二次齐次缩放、profile三段/峰值/log面积2的反导式、3个同来源capture数组重算alpha均正确。FS9用uncapped的r_F=p-/p+有理值比较，负补偿、初始alpha0/零增量/零总量先分及共同source质量缩放准确。未将抽象数组标签充作physical face/FIRST输入。

逐行静核score_checks.py：原E3/E2两侧公式、中心psi、有限均值边界恒等s(1-s)(phi_mass-1)-2sXphi(X)、绝对mean尾2s exp(.5-X)(9+8X)和exp尾4s exp(9/16-X/2)方向/系数均正确。s0只在支持上定义零score，irrational s逐精度重算；7个s的25/40位与7导数点为非interval诊断，root只是数值求积seam不认证全部根。notes的有限/非FULL、解析截断与浮点求积区别准确。本审计未重复运行。

report.md对fixeds合成O(B[sqrt(log n)+sqrt n(1-s)])、完整soft平均n级费用、FS14首个真实联合积分缺口和所有资格进入费表述正确。reproduce.py先核未来manifest，再运行face/score至新输出JSON并传递非零退出、比较完整字节；不充作一般证明checker。父报告已有score实际完整JSON一致，数值作者报告两脚本隔离一致；最终总driver留待父归档阶段执行，不提前记为已通过。等待详细tex一次整合核后冻结。


## 12. 最终整合结论与冻结

详细proof.tex.txt的715行已全文核验，与face/score/flux三稿一致；初始帽、连续尺度score、全部hard entry、fixeds到全soft的完整帽混合顺序、原trace/cluster资格及同alpha负补偿均保留正确系数。没有把外面自身删为dx零，也没有把nu的physical面零结论推广到good等号面或actual selector变化。没有编译PDF，当前无必须修项。

报告与最终两脚本/notes范围一致。父报告已有实际score完整JSON重放、数值作者报告两脚本完整隔离一致；本独审仅静态核验，不另运行。reproducer总入口需待manifest生成后由父执行，当前不提前认证该执行已完成。manifest/归档复核由父后续完成，不循环绑定。

最终通过范围：固定参数帽核的连续score联合反集中和精确面profile/coarea估计；明确trace或cluster条件下的原capture嵌套与同alpha有限跳补偿。原G完整path/BV/资格交换、tiny-Wg source列、完整j/time/window及FS14净来源积分仍未付，未认证一般root弱型目标或新增原raw整支付款。到此冻结停止，仅维护了本文件。

以下实算绑定当前12个其他work文件；排除本文件自身及未来manifest。

| 文件 | SHA256 |
|---|---|
| face_checks.json | `ef113bdc3d57410d2ec4671017b7822e74b584dda18f36b84eef8566a05b0564` |
| face_checks.py | `2d7b75986b97724251d168a47dfd1e64d292e2774247f9b840ae6f072d347834` |
| face_geometry.md | `eb5acde36285e88f151adc1de364ac938f9ece481dbd200b5ef6a078a4217cd1` |
| flux_source_budget.md | `8e564f5993671c70729227f0eb1135a963b37fac68b9795bd65a6e44d0fc1443` |
| numerical_review.md | `24d592021d803121df9879270c4e51e4a4cd73db4da812f2ca1ffd7d437fddf3` |
| proof.tex.txt | `16758fc75caab425d7272299aeffa2037f6d8c13643ee6f675e16083e7240168` |
| report.md | `4387f9762ef5e4283b60979b588b3c903429e15aaa9b7a7b88ec382e00323fd9` |
| reproduce.py | `3c01eab36f81884a7cdacaf46fb885605f7de4f4d617cf172025124446ebca3b` |
| score_anticoncentration.md | `b24a955cc93622ec736a7ba810d01e3f110b722005fef8427d4ca928e6e4c1ea` |
| score_checks.json | `b6d69c93f3bd93f582342bbabd7cbd9975f7cd5da67fceef3c87ed4dfd11a661` |
| score_checks.py | `249bc0b28f7b9fbbf58c784203cfbdb9ebddf8ccea98e8c3f348d8854a97e677` |
| task_contract.md | `552cb473de0b8813e7d3a6ba7f4bc0a7eea3b81057bbe3939774ed116e060a47` |
