"""Exact checks of R342 mass cuts. Finite rows are algebra diagnostics only."""
from fractions import Fraction as F
from itertools import product
counts={"rows":0,"cut_coefficients":0,"full_entropy_identity":0,"gated_identities":0,"far_comparisons":0}
masses=[2**i for i in range(5)]
for raw in product(range(3),repeat=5):
    if not any(raw): continue
    w=list(map(F,raw)); J=sum(w); V=sum(wi*mi for wi,mi in zip(w,masses))
    cuts=[]
    for k in range(4):
        lowerJ=sum(w[:k+1]); lowerM=sum(w[i]*masses[i] for i in range(k+1))
        cut=V*lowerJ/J-lowerM
        pair=sum(w[i]*w[j]*(masses[i]-masses[j])/J for i in range(5) for j in range(5) if j<=k<i)
        assert cut==pair and cut>=0
        cuts.append(cut); counts["cut_coefficients"]+=1
    # Each consecutive log mass interval has width log 2. Compare its exact coefficient.
    covariance=sum(w[i]*masses[i]*i for i in range(5))-V/J*sum(w[i]*i for i in range(5))
    assert sum(cuts)==covariance
    counts["full_entropy_identity"]+=1
    for d in (1,2,3):
        for mask in (0,1):
            def admitted(i,j):
                return i-j>d and (mask==0 or (i+j)%2==0)
            g=sum(w[i]*w[j]*(masses[i]-masses[j])/J for i in range(5) for j in range(5) if admitted(i,j))
            entropy=sum(w[i]*w[j]*(masses[i]-masses[j])*(i-j)/J for i in range(5) for j in range(5) if admitted(i,j))
            gated_cuts=sum(w[i]*w[j]*(masses[i]-masses[j])/J for k in range(4) for i in range(5) for j in range(5) if admitted(i,j) and j<=k<i)
            assert entropy==gated_cuts
            counts["gated_identities"]+=1
            assert d*g<=entropy<=covariance
            counts["far_comparisons"]+=1
    counts["rows"]+=1
print("PASS",counts)
print("All logarithms are represented exactly as integer multiples of log 2.")
print("No original continuum feasibility or source-flow embedding is asserted.")
