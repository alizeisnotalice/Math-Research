#!/usr/bin/env python3
"""Exact full intersecting-cell ledger checks for the multigrid source split."""
from fractions import Fraction as F
from pathlib import Path
from math import isqrt,floor,ceil
from collections import Counter
import json,hashlib
BASE=Path(__file__).resolve().parent
CHECK=Counter()
def ck(k,v):CHECK[k]+=1;assert v,k
def brief(x):
 if max(abs(x.numerator).bit_length(),x.denominator.bit_length())<1800:return str(x)
 a=abs(x.numerator);raw=(str(x<0)+':'+str(a.bit_length())+':').encode()+a.to_bytes((a.bit_length()+7)//8,'big')+b'/'+x.denominator.to_bytes((x.denominator.bit_length()+7)//8,'big')
 return dict(decimal=float(x),sha256=hashlib.sha256(raw).hexdigest(),encoding='negative:numerator_bitlength:unsigned_numerator_bytes/unsigned_denominator_bytes')
def count_cells(x,R,L,phase):
 lo=x-R/2;hi=x+R/2
 return list(range(floor((lo-phase)/L),ceil((hi-phase)/L)))
def exact_mean_count(x,R,L):
 # Counts positive-length intersections. Endpoint coincidences have shift measure zero.
 points=sorted(set([F(0),L,(x-R/2)%L,(x+R/2)%L]));ans=F(0);pieces=[]
 for a,b in zip(points,points[1:]):
  phase=(a+b)/2;N=len(count_cells(x,R,L,phase));ans+=(b-a)*N;pieces.append((a,b,N))
 return ans/L,pieces

def log_upper(z,N=32):
 t=(z-1)/(z+1)
 return 2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0))+2*t**(2*N+1)/(F(2*N+1)*(1-t*t))

# True compact positive-L1 piecewise constant source; zero-density piece retained.
SOURCE=[(F(-3),F(-1),F(1,4)),(F(-1),F(-1,4),F(3)),(F(-1,4),F(1,2),F(1)),(F(1,2),F(2),F(5,2)),(F(2),F(3),F(0))]
def source_mass(lo,hi):return sum((max(F(0),min(hi,b)-max(lo,a))*d for a,b,d in SOURCE),F(0))

def grid_integrals():
 before=sum(CHECK.values());rows=[]
 for x in [F(-2),F(-1,3),F(0),F(2,3)]:
  for R in [F(1,4),F(1),F(3,2),F(2)]:
   for L in [F(1,4),F(1,2),F(1),F(3,2),F(2)]:
    mean,pieces=exact_mean_count(x,R,L)
    ck('complete_shift_interval_mean_count',mean==1+R/L)
    ck('shift_partition_complete',sum(b-a for a,b,N in pieces)==L and all(N>=1 for a,b,N in pieces))
    rows.append(dict(center=str(x),R=str(R),L=str(L),L_less_than_R=L<R,mean_count=str(mean),pieces=[dict(start=str(a),stop=str(b),intersecting_cells=N) for a,b,N in pieces]))
 return dict(exact_checks=sum(CHECK.values())-before,cases=rows)

def source_cells():
 before=sum(CHECK.values());summary=Counter();certificates=[];b=F(2)
 for L in [F(1,4),F(1,2),F(1),F(2)]:
  for phase in [F(0),L/3,L/2,2*L/3]:
   all_ids=count_cells(F(0),F(6),L,phase)
   ck('full_source_grid_accounted_once',sum(source_mass(phase+j*L,phase+(j+1)*L) for j in all_ids)==source_mass(F(-3),F(3)))
 for x in [F(-5,2),F(-1),F(0),F(1,3),F(5,2),F(5)]:
  for R in [F(1,4),F(1),F(3,2),F(2)]:
   for L in [F(1,4),F(1,2),F(1),F(2)]:
    for phase in [F(0),L/3,L/2,2*L/3]:
     ids=count_cells(x,R,L,phase);m=source_mass(x-R/2,x+R/2);M=source_mass(x-L-b/2,x+L+b/2);captures=[];W=[]
     for j in ids:
      lo=phase+j*L;hi=lo+L;cap=source_mass(max(lo,x-R/2),min(hi,x+R/2));mass=source_mass(lo,hi);captures.append(cap);W.append(mass)
      ck('every_intersecting_cell_local_containment',x-L-b/2<=lo<hi<=x+L+b/2)
      ck('every_cell_full_source_local_budget',0<=cap<=mass<=M)
      summary['noncenter_cells']+=not(lo<=x<hi)
     ck('capture_partition_no_source_loss',sum(captures)==m)
     summary['zero_capture_cases']+=m==0;summary['cases']+=1
     for beta in [F(1,16),F(1,4),F(1,2)]:
      low=[j for j,w in enumerate(W) if w<beta*m];high=[j for j in range(len(W)) if j not in low];lowmass=sum(captures[j] for j in low)
      ck('low_high_exact_complement',set(low).isdisjoint(high) and len(low)+len(high)==len(ids))
      ck('each_low_cell_original_normalized_budget',all(captures[j]/R<beta*(m/R) for j in low))
      if any(w==beta*m for w in W):ck('threshold_equality_stays_high',all(j in high for j,w in enumerate(W) if w==beta*m))
      ck('low_mass_total_all_intersecting_cells',lowmass<=beta*m*len(low)<=beta*m*len(ids))
      ck('unchanged_q_normalization',lowmass/R<=beta*(m/R)*len(ids))
      summary['positive_low_capture_cases']+=lowmass>0;summary['multiple_cell_cases']+=len(ids)>1
      if len(certificates)<6 and lowmass>0 and len(ids)>1:
       certificates.append(dict(center=str(x),R=str(R),L=str(L),phase=str(phase),beta=str(beta),m_original=str(m),q_original=str(m/R),local_M=str(M),cell_ids=ids,cell_full_masses=list(map(str,W)),cell_captured_masses=list(map(str,captures)),low_indices=low,high_indices=high,low_capture=str(lowmass),upper=str(beta*m*len(ids))))
 return dict(exact_checks=sum(CHECK.values())-before,counts=dict(summary),selected=certificates,source=[list(map(str,p)) for p in SOURCE])

def tensor_stage(ns):
 before=sum(CHECK.values());rows=[]
 for n in ns:
  k=isqrt(n);ck('sqrt_n_exact',k*k==n);b=F(2);L=k*b/2;worst=(1+F(2,k))**n;logupper=n*log_upper(1+F(2,k))
  ck('log_source_increment_at_most_2sqrt_n',logupper<=2*k)
  for delta in [F(1,128),F(1,16),F(1,2)]:
   beta=delta/worst
   for R in [F(1),F(3,2),F(2)]:
    direct,pieces=exact_mean_count(F(1,3),R,L);mean=direct**n
    ck('tensor_expected_count_exact',mean==(1+R/L)**n)
    ck('beta_expected_count_absorption',beta*mean<=delta)
    if R==b:ck('worst_radius_exact_delta',beta*mean==delta)
    rows.append(dict(n=n,R=str(R),b=str(b),L=str(L),delta=str(delta),beta_exact=brief(beta),beta_decimal=float(beta),expected_intersecting_cells_exact=brief(mean),expected_intersecting_cells_decimal=float(mean),beta_times_mean_exact=brief(beta*mean),log_source_increment_upper=str(logupper),log_source_increment_upper_decimal=float(logupper),analytic_increment_limit=2*k))
 return dict(dimensions=ns,exact_checks=sum(CHECK.values())-before,rows=rows)

def main():
 shift=grid_integrals();source=source_cells();stages=[]
 for name,ns in [('initial',[1,4,9]),('stress',[16,64,256]),('expanded',[1024,4096])]:
  stage=tensor_stage(ns);stage['name']=name;stages.append(stage)
 out=dict(status='PASS',total_exact_checks=sum(CHECK.values()),check_counts=dict(CHECK),one_dimensional_shift=shift,actual_step_source=source,tensor_stages=stages,scope='Exact complete cell-count and compact positive-L1 source ledgers. Includes L<R, noncenter intersecting cells, zero capture, unchanged m/q, and terminal high/low complement. Not a simulation/certificate of complete original Gout or the global source-window payment.')
 (BASE/'r342_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(status='PASS',total_exact_checks=sum(CHECK.values()),shift_checks=shift['exact_checks'],actual_source_checks=source['exact_checks'],tensor_stages=[{k:s[k] for k in ['name','dimensions','exact_checks']} for s in stages]),sort_keys=True))
if __name__=='__main__':main()
