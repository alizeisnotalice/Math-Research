"""Exact checks for the common-source-cell occupancy receipt in R342."""
from fractions import Fraction as F
from itertools import product


def floor_q(x):
    return x.numerator//x.denominator


def expected_intersecting_cells(u,R,L):
    lo=u-R/2; hi=u+R/2
    cuts=sorted({F(0),L,lo-L*floor_q(lo/L),hi-L*floor_q(hi/L)})
    total=F(0)
    for left,right in zip(cuts,cuts[1:]):
        shift=(left+right)/2
        number=floor_q((hi-shift)/L)-floor_q((lo-shift)/L)+1
        total+=(right-left)*number
    return total/L

counts={'exact_one_dimensional_shift_integrals':0,'tensor_occupancy':0,'receiver_fee_tuning':0,'source_cell_split_and_low_mass':0}
for u,R,L in product([F(-7,3),F(0),F(5,4)],[F(1,4),F(1),F(3),F(7,2)],[F(1,2),F(1),F(2)]):
    assert expected_intersecting_cells(u,R,L)==1+R/L
    counts['exact_one_dimensional_shift_integrals']+=1
for n in range(1,9):
    R=F(3,2); L=F(2,3)
    tensor=F(1)
    for i in range(n):
        tensor*=expected_intersecting_cells(F(i,3),R,L)
    assert tensor==(1+R/L)**n
    counts['tensor_occupancy']+=1
for n,L,delta in product(range(1,33),[F(1,4),F(1,2),F(1),F(2),F(4)],[F(1,4),F(1,16),F(119,3072)]):
    b=F(1); beta=delta/(1+b/L)**n
    assert beta*(1+b/L)**n==delta
    counts['receiver_fee_tuning']+=1
# Actual cell source masses W_i, with captured fractions inside a receiver cube.
# This checks the algebraic mass split and the low-cell estimate, not a G fixture.
source=[F(1),F(2),F(3),F(4)]
for fractions in product([F(0),F(1,2),F(1)],repeat=4):
    capture=[w*t for w,t in zip(source,fractions)]
    m=sum(capture)
    if not m:
        continue
    N=sum(t>0 for t in fractions)
    for beta in [F(1,4),F(1,2)]:
        low=sum(c for w,c in zip(source,capture) if w<beta*m)
        good=sum(c for w,c in zip(source,capture) if w>=beta*m)
        assert low+good==m and low<=beta*m*N
        counts['source_cell_split_and_low_mass']+=1
epsilon=F(119,3072); outer=F(128,119)
assert 4*outer*epsilon==F(1,6)
assert 4*outer*epsilon+F(1,256)==F(131,768)
counts['updated_ledger']=2
print({'exact_assertions':sum(counts.values()),'counts':counts,'status':'passed'})
