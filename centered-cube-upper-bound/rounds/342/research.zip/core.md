# R342 — Ordered mass-cut entropy: exact account and missing source flow

**Status.** No new payment for the general localbad branch is proved here. This note records an atom-compatible cumulative identity and its actual coarse cost. It distinguishes that receiver-row entropy from the bounded entropy of a shared source partition. Equating those two accounts would be an unproved geometric step.

## Original field and row energy

Use the exact hard contract and G_out of R340 core, with the original actual du, m_u=q_uR_u^n, q_-≤q_u≤λ, a≤R_u≤b≤2a, source f, full J_y(r), H, ell, strict far gate m_u>K m_v, high-past and outside-center gates. Any fixed measurable large-endpoint set A, including the current localbad set, can be imposed without change below.

Fix (y,r) and write ρ(du)=1_{E_r}(u)c_u(y)μ(du), J=∫ρ, V=∫mρ. When J=0 everything is zero. Otherwise J,V are finite and positive. Put m_0=q_-a^n and M_r=λr^n. Define the full row entropy dissipation

    L(y,r)=(1/(2J))∬(m_u−m_v)log(m_u/m_v)ρ(du)ρ(dv)
      =∫m log(m/m_0)ρ−(V/J)∫log(m/m_0)ρ.            (1)

All masses belong to [m_0,M_r]. This is a nonnegative finite quantity. Logs only occur as dimensionless ratios.

Let χ(y,r,u,v) be the exact original high-past and outside-center gates, together with 1_A(u). Let g_A be the corresponding row of G_out before the outer f1_{J≥H}ell integral. Define

    L_A=(1/J)∬_{m_u>K m_v}χ(m_u−m_v)log(m_u/m_v)dρu dρv.

Then, with no original gate removed,

    (log K)g_A≤L_A≤L.                                (2)

The first inequality uses the actual far ratio. The second follows because (1) equals the same nonnegative ordered integral over all m_u>m_v. This is an entropy comparison, not yet an entropy budget.

## Exact cumulative identity, including mass atoms

For t∈[m_0,M_r], put

    F(t)=∫1_{m≤t}ρ,       M(t)=∫m1_{m≤t}ρ.

The full-J cut flux is

    B(t)=[VF(t)−JM(t)]/J
        =(1/J)∬_{m_u>t≥m_v}(m_u−m_v)dρu dρv≥0.     (3)

Direct expansion proves the second expression: (V−M)F−(J−F)M=VF−JM. Tonelli and log(m_u/m_v)=∫_{m_v}^{m_u}dt/t yield

    L=∫_{m_0}^{M_r}B(t)dt/t.                         (4)

The exact gated version holds with

    B_A(t)=(1/J)∬1_{m_u>K m_v}χ1_{m_v≤t<m_u}
                          (m_u−m_v)dρu dρv,
    L_A=∫B_A(t)dt/t.                                 (5)

Every original oriented pair traverses its actual interval of mass thresholds, with the same original denominator and gates at every threshold. There is no independent re-sampling of the source. Values at threshold atoms do not affect the Lebesgue dt/t integral; the displayed inclusive/exclusive convention also treats those atoms unambiguously. These identities do not require a strictly increasing enumeration of masses.

Equivalently, P=ρ/J and Q=mρ/V are two probabilities on the same actual receivers, and

    L=V[KL(Q||P)+KL(P||Q)].                           (6)

Indeed dQ/dP=m/(V/J); substitution gives (1). This identity does not convert receiver entropy into source entropy.

## The available elementary budget remains too large

Since log(m/m_0) lies between 0 and ℓ_r=log(λ/q_-)+n log(r/a), (1) gives

    0≤L≤Vℓ_r≤r^nℓ_r.                                (7)

The last inequality is the genuine receiver-center volume bound V=|{u∈E_r:y∈Q_u}|≤r^n. It puts no density bound on f. Write c=log(λ/q_-), T=log(b/a). The original complete physical tail, including its b atom, therefore gives

    ∫ell(dr)∫f(y)1_{J≥H}L_A(y,r)dy
       ≤W[c+(1+c)nT+(n²/2)T²].                      (8)

To verify the cost, the terminal atom contributes c+nT; the continuous part is n∫_0^T(c+ns)ds. Thus this particular entropy estimate gives

    G_out(A)≤W[c+(1+c)nT+(n²/2)T²]/log K.             (9)

For K=e^{√n} and a general octave, this is O(n^(3/2))W, worse than the available O(n)W bound obtained by dropping the mass-gap entropy. Consequently (9) is not added to the payment ledger and is not counted as progress toward a root receipt. The far gate may make low physical radii empty, but deleting that initial segment alone does not remove the quadratic n² term of (8).

## A distinct bounded source resource, and the precise missing construction

For a countable source partition into parent cells S_j, with each parent measurably subdivided into at most N children S_jk, set W_j=∫S_j f and W_jk=∫S_jk f. The actual conditional source entropy satisfies

    Σ_jΣ_k W_jk log(W_j/W_jk)≤W log N.               (10)

Use zero for zero-mass terms. This follows by normalizing the masses inside each parent and the entropy bound for a probability vector with at most N entries. It does not assume bounded f. Nested Cartesian grids with a fixed integer side ratio M have N=M^n, so their one-step source entropy budget is n log M times W.

The factors in (2) and (10) suggest a root scale, but they belong to different measures and cannot be canceled against each other. To use (10), a valid construction would have to send the *actual gated pair flux* in (5) to transitions of a single nested source partition, with a proved uniform bound on how much flux charges each conditional-entropy contribution. It must retain the full J, the physical ell tails, and a priced complement for pairs not represented by that flow. No such source-flow domination is proved here.

The specific geometric difficulty is that two actual cubes containing the common source y need not be nested; the outside-center condition does not supply nesting. Replacing them by canonical containing cells can increase their actual f-masses by an uncontrolled factor. A bound on the volume of that enlargement does not control those source masses. The earlier full-J block identity also leaves real cross-block energy beyond the between-block mean variance, so assigning fractions J_j/J cannot supply the missing flow credit.

Thus (3)–(5) give an exact ordered account with all atoms, while (8) states its honest available cost. The unresolved step is a geometric, multiplicity-controlled embedding of that actual account into a shared source entropy resource (or another independently bounded resource), not the mass layer-cake identity itself. The main R342 source-grid payment is separate and is not duplicated here.

## Local verification

The saved check script uses exact Fraction arithmetic on finite positive row measures. Its scope is cumulative-cut identities and the far logarithmic comparison only; it does not assert that arbitrary finite rows are realizable cube fields and does not verify a source-flow embedding. Actual results are recorded after execution.

`/tmp/r342_core_checks.py` was actually executed. It exhausts 242 nonzero weight vectors in {0,1,2}⁵ on masses 1,2,4,8,16, and passed 968 exact cut-coefficient comparisons, 242 full entropy identities, 1,452 gated layer-cake identities, and 1,452 far-comparison checks. The gates use K=2,4,8 and two different deterministic pair masks. Every logarithm is represented symbolically as an integer multiple of log 2, so all comparisons use exact rational arithmetic. The source entropy lifting remains unproved. Only this note and its check script were authored; bounded delivery ends here.
