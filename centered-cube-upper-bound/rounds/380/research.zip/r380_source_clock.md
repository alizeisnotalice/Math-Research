# R380 — Bounded source-clock checkpoint: no new general payment

## 1. Exact scope and the screened conclusion

The R377 full-f matched hard field is retained: actual receiver du, m_u=f(Q_u)=q_uR_u^n, q_-≤q_u≤λ, a≤R_u≤b≤2a, μ(du)=du/m_u, the original J_y(r), H, strict mass-past gate and complete physical clock including its terminal atom. No field is recomputed on the deep, dense, or high-density source restriction.

For any actual lost-row weight 0≤β_v(y)≤1, including its product with the restriction f(y)>Tq_v, use the R377 definition

\[
 T_y=J_y(b),\qquad
 C_y=\int_E\beta_v(y)(1-q_v/f(y))_+c_v(y)\mu(dv),\quad0\le C_y\le T_y.
\]

Zero f rows contribute zero. The existing original-clock theorem gives

\[
 \mathcal B_\beta:=\int_Edv\int\mu_v^+(dy)\,\beta_v(y)L_v(y)
 \le\lambda\int f(y)\Phi_h(T_y,C_y)dy. \tag{1}
\]

This statement already includes the full strict-left radius/atom argument; no new claim is made for a truncated or reset J. Further positive pair restrictions only decrease the left side. The original negative capture or refill credit is not added to (1).

I did not obtain a source-weighted geometric estimate that improves the general root budget. In particular, neither high pointwise f nor the already known external-mass identity produces a summable source increment without a common allocation of the repeated external mass. The following short calculation identifies a concrete stronger geometric inequality that would suffice, and why it remains substantive rather than an already available clock estimate.

## 2. The actual matched second occupation moment

Define

\[
 \mathcal M_2=\int f(y)J_y(b)^2dy.
\]

Positive Tonelli and the **same** full-f matching give the exact identities

\[
 \boxed{\int fJ_b=|E|,\qquad
 \mathcal M_2=\iint_{E\times E}
 \frac{f(Q_u\cap Q_v)}{m_um_v}\,du\,dv.} \tag{2}
\]

There is no independent choice of radii for the two sources: the actual R selector and the two actual cubes remain inside the intersection. The source measure is f(y)dy, not Lebesgue volume. The known actual-center envelope J_b≤A_n/q_- gives only

\[
 q_-\mathcal M_2\le A_n|E|,\qquad A_n=1+n\log(b/a). \tag{3}
\]

On the other hand Φ_h(T,C) is increasing in C and Φ_h(T,T)=(T−h)_+. The exact elementary inequality (T−h)_+≤T²/(4h), h>0, yields the valid but not newly paid bound

\[
 \boxed{\mathcal B_\beta\le\frac\lambda{4h}\mathcal M_2.} \tag{4}
\]

For T≥h the scalar inequality is equivalent to (T−2h)²≥0; T≤h is immediate. Thus it has no atom or differentiability assumption. It is being applied after the existing full-clock theorem, not substituted for its strict-past proof.

A sufficient missing geometric estimate would be

\[
 \tag{M}
 q_-\mathcal M_2\le D_n|E|,
 \qquad D_n\lesssim\sqrt n\log^A(n+2).
\]

If (M) were proved, (4) and q_-|E|≤X_q would give

\[
 \mathcal B_\beta\le
 \frac{\lambda D_n}{4q_-^2h}X_q.
\]

Choosing the original h at least λD_n/(4εq_-²) would therefore pay this by εX_q, with the corresponding enlarged original source fee. If D_n is root-polylogarithmic, that source-fee scaling is compatible with the objective. This is conditional only: (M) has not been proved here.

Indeed Cauchy–Schwarz and (2) show

\[
 |E|^2\le W\mathcal M_2.
\]

Consequently (M) itself already implies q_-|E|≤D_nW. It carries a genuine global matched-source weak budget, and is not an inexpensive auxiliary fact one may infer from the first moment. The baseline (3) instead returns a linear A_n dependence after the same calculation.

## 3. Why the available local mechanisms do not prove (M)

For one fixed logarithmic mass window, the old sourcewise real-center capacity bound does control its within-window part of (2) at the familiar root scale. That is the earlier near-mass mechanism and is not counted again. The still-uncontrolled terms of (2) are the cross-window actual intersections weighted by both receiver measures. The inequalities f(Q_u∩Q_v)≤min(m_u,m_v) and the q band alone do not give a summable root bound for those actual center pairs.

The high-density source condition f(y)>Tq_v is a pointwise condition at the original marked source. It does not give a positive uniform mass for any fixed neighborhood of y. Even when a given far-mass receiver has substantial source mass outside another cube, the outside mass can be reused by many nonnested receivers. A proof through increments would require an explicitly defined common arrival measure, conservative child flows and a separately controlled terminal measure. No such flow with the required source capacity has been constructed in this task. In particular different-center cubes are not treated as a nested source tree, and no abstract Bellman constant is imported.

The deep overlap condition controls a Lebesgue overlap template. It cannot replace f(Q_u∩Q_v) in (2) by that volume. Applying a bounded-density truncation would recover the earlier paid low-density branch and leave the same high-density source; it would not supply (M). Thus no new payment is claimed for the deep/dense/high-density complement.

This identifies the precise next question for this route: can the actual shared intersection moment, or a strictly smaller version retaining the original cross-window clock gates, be bounded at root scale by a source-consistent allocation? Until such an inequality is proved, (4) is only a diagnostic upper bound, not progress on the global fee.

## 4. Exact local verification and its limits

Script: `/tmp/r380_source_clock_check.py`.

Stage 1 checks the rational scalar inequality and the inclusive atomic-rank sums with the strict left gate. Stages 2–3 check (2), Cauchy–Schwarz and the integrated excess inequality using actual interval incidences, positive piecewise-constant L1 source profiles, exact interval averages in the q band, and finite quadrature receiver weights. The intervals have side lengths in [1,2]; all cell boundaries are aligned. These are exact matching-identity checks, not native Lebesgue-receiver realizations or evidence for (M).

Actual Fraction execution: **PASS [861,40,984], total 1885 grouped assertions.** No new root estimate or externally assigned source flow was validated by these computations. Work stops at this bounded negative result.
