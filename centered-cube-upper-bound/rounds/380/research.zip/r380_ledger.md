# R379 全局总账：三个pair分支与两类原来源

所有量由同一完整f与原接收选择器定义。W=||f||_1，X_q=∫q_u du，q_-=3λ/4，A_n=1+nlog(b/a)，Λ=128/119，b≤2a。不同参数场的标记与不同计划信用不得拼接。

## 参数先后与实际计划

先固定η,ε,ε'>0及T=1+ceil(log_2(n+2))，置
\[
 \bar B=\frac{A_n\eta q_-}{2(1+\sqrt n)},\quad
 t=1+\max\{0,\lceil\log_2(\bar B/(\varepsilon q_-))\rceil\},
\]
\[
 \mathcal L=2+\frac{72+(T+t)\Gamma_n}{1+\sqrt n},\quad
 \varepsilon_0=\eta/\mathcal L,\quad h=\frac{1+\sqrt n}{\varepsilon_0q_-}.
\]
ε0≤η/2给原核B=A_n/h≤Bbar，故t没有循环定义。用该h同步重建所有原门、J/ω及clock；不能把它们改成截断f的场。

低来源μ_v^lo=1_{f≤Tq_v}μ_v^+走identity，成本逐点零，target≤(T−1)U。高来源μ_v^H=1_{f>Tq_v}μ_v^+=d_v^HP_v^H接R378针对remaining pair核的t层共同计划，target≤td_v^HU。dH=0时省略，不除零。

remaining pair核同时保留j>n/8、Σd_i>n/20和所有原门。其真实高来源dyadic部分运输缺额δ^H_{v,τ,∞}按R378有限关系定义，
\[
 \mathcal D_{H,deep}=\int_Ed_v^H\sum_{j=0}^{t-2}(\tau_{j+1}-\tau_j)
 \delta^H_{v,\tau_j,\infty}\,dv.
\]
阈值从εq_-倍增至Bbar，有限深度逼近误差≤ε'X_q。若t=1，直接product补高来源，D=0且成本≤εX_q。

## 完整付款与原始入口

同一全来源精确计划τ=τlo+τH，full bad按sparse、dense-shallow、dense-deep不交叠分解。前两支的合计费用≤σ_nX_q，其中
\[
 \sigma_n=\frac{\varepsilon_0}{1+\sqrt n}
 [\widehat b_n+(753/800)^n],
 \quad b_n=2^{-n}\sum_{j≤\lfloor n/8\rfloor}{n\choose j}4^j,
\]
并沿用n<8时bhat=0，其他维度bhat=b_n。两个界都只需来源精确，所以允许本轮混合了identity与密度计划的τ。低来源在第三支亦零；高来源成本≤(ε+ε')X_q+D_H,deep。

全计划floor+good≤(T+t)p，所以
\[
 B_H(f,\nu)\le \mathcal D_{H,deep}
 +(\eta+\sigma_n+\varepsilon+\varepsilon')X_q+C_{338}W,
\]
\[
 C_{338}=\frac\lambda{q_-}
 \left[\frac{2+3\sqrt n+2e^{-\sqrt n}}{\varepsilon_0}+1+\sqrt n\right],
\]
\[
 \Gamma_n=1+\frac{n}{4(\sqrt n+1)}
 +2\sqrt n\sqrt{1/4+\tfrac12\log(1+\sqrt n)}(1-1/\sqrt2).
\]
T+t=O_{η,ε}(log(n+2))，因此上述C338W=O_{η,ε}(sqrt(n)log^(3/2)(n+2))W。D_H,deep没有被此式支付。

原入口完整保留：
\[
 T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H
 +2\mathcal D_{H,deep}
 +2(\eta+\sigma_n+\varepsilon+\varepsilon')X_q+2C_{338}W.
\]
整式乘Λ。bhat≤1、(753/800)^n≤1，n≥1、ε0≤η/2，所以σ_n≤η/2。仅为此槽分配κ时可取η=ε=ε'=κ/(7Λ)，则2Λ(η+σ_n+ε+ε')≤κ。这不是其他槽的总吸收认证。

## 仍未支付

D_H,deep的一般根阶来源预算；原H入口与H选择；一般soft/crossing/entry；合同外重尾、宽距离、低pe与极端尺度比及全部阈值补集；初始、删除跳跃和未来被删来源历史原子；全尺度/来源聚合、外积分、截断与极限。物理末端原子不代替历史预算。

小几何p不等于小I_uv/m_v，高来源f>Tq_v也不自动有维数一致小L1尾。低来源identity的费用已计入(T+t)Γ，不能再把直接low-p界列成独立节省。若选用旧cap2/M1计划，必须同场比较完整成本，不能在本计划上额外扣旧Capture或旧振荡收益。

# 第380轮增量：同场来源簇付款，完整替代账单

以上第379轮参数、原入口、分支与所有未付接口原样保留。令τH为该轮高来源计划，G为其实际dense-deep成本，χ_v(y)=Σ_j(f_j/f)(y)χ_jv，Fθ=cθB*/q_-。B*=min(A_n/h,λlog_+(A_n/(q_-h)))；若B*=0则G=0，不作不必要除法。

## 选项A：同一个原计划，精确成本分解

令Rχ=∫dv∫(1−χ_v(y))C_v(y,z)dτH。则G≤FθW+Rχ，故
\[
 B_H\le R_\chi+(\eta+\sigma_n)X_q+(C_{338}+F_\theta)W,
\]
\[
 T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H
 +2R_\chi+2(\eta+\sigma_n)X_q+2(C_{338}+F_\theta)W.
\]
整式乘Λ=128/119。这里没有再支付ε、ε'，因为没有把实际G替换成Hall上界；旧的G≤D_H,deep+(ε+ε')X_q仍是另一个可选完整上界。绝不能写Rχ≤D−Gχ。

θ=1/√n时Fθ=2√nB*/q_-；固定η、ε且λ/q_-=4/3时B*/q_-=O(log(n+2))。于是新增来源费用为O(√n log(n+2))W，原C338仍为O(√n log^(3/2)(n+2))。相同分解的质量窗|log(m/M)|≤√n可直接支付2e√nB*/q_-乘W，窗外实际成本保留；这与χ付款是二选一，不重复结算。

## 选项B：重新构造完整计划，保持目标容量

按χ切分原高来源，已付部分用product，余下部分按R378层构造。目标密度≤(dpaid+t drem)U≤t dHU，低来源identity不变，模板仍(T+t)Γ，无新增容量项。新剩余Hall账单Drem按残余归一化来源重算，不能声称小于旧D。完整账为
\[
 B_H\le D_{rem}+(\eta+\sigma_n+\varepsilon+\varepsilon')X_q
 +(C_{338}+F_\theta)W.
\]
入口中D_H,deep替换成Drem，C338替换成C338+Fθ，其他项原样保留，全式仍乘Λ。此槽η=ε=ε'=κ/(7Λ)仍保证总吸收≤κ，不构成其他槽认证。

## 未闭合部分

选项A的真实Rχ或选项B的Drem仍未获一般根阶预算；全局簇选择与质量失配联合几何是下一证明瓶颈。以上原H入口、soft/crossing/entry、重尾宽距离低pe极端尺度比、初始删除跳跃未来被删来源、全尺度聚合及极限全部继续列为未付，不能以本轮局部付款宣称全局闭合。
