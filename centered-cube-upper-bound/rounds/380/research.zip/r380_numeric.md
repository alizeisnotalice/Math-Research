# R380 — global source partitions and original bad-cost alignment

## Result and decision

Global spatial grouping substantially changes the source-mass alignment of the **same** original uniform-product bad cost. A single all-source cluster qualifies none of that cost for the narrow band [1/2,2]; fixed dyadic depth 1 or 2 qualifies all of it in all three samples. Refinement is not monotone: singleton/depth-3 partitions lose part of the narrow-band share.

This gives finite evidence that the global partition matters. It does not show that a suitable global partition always exists, or pay the general original hard branch. No source, receiver mass, plan, or diagnostic mark is optimized or refitted.

| Field | Global partition | Bad share with m_v/M_j∈[1/2,2] | χ-weighted bad / baseline bad, χ=min(m_v/M_j,M_j/m_v) |
|---|---|---:|---:|
| Equal 1D | Singleton | 909/1129 | 3167/6774 |
| Equal 1D | All source | 0 | 1239/4516 |
| Equal 1D | Dyadic depth 1 | 1 | 1239/2258 |
| Equal 1D | Dyadic depth 2 | 1 | 3167/3387 |
| Equal 1D | Dyadic depth 3 | 909/1129 | 3167/6774 |
| Weighted 1D | Singleton | 1105623/1310023 | 3725669/7860138 |
| Weighted 1D | All source | 0 | 1412223/5240092 |
| Weighted 1D | Dyadic depth 1 | 1 | 1412223/2620046 |
| Weighted 1D | Dyadic depth 2 | 1 | 3725669/3930069 |
| Weighted 1D | Dyadic depth 3 | 1105623/1310023 | 3725669/7860138 |
| 2D | Singleton | 1444/1903 | 9056/17127 |
| 2D | All source | 0 | 3/11 |
| 2D | Dyadic depth 1 | 1 | 92133/104665 |
| 2D | Dyadic depth 2 | 1 | 1699/1903 |
| 2D | Dyadic depth 3 | 1444/1903 | 9056/17127 |

For every displayed partition in these inputs, the wider closed bands [1/4,4] and [1/16,16] qualify all of the baseline bad cost. These are exact rational comparisons, including equality at endpoints. The statistics are window-qualified traffic shares for the proposed source-cluster receipt, not an independently certified general fee.

## Frozen actual source and explicit baseline

R379's minimal input has no old cap2 transport plans. The baseline here is explicitly the **uniform product** μ_v^+⊗U_v, not the cap2 optimum or a newly optimized plan. Its exact original G_joint costs are

    equal 1D: 1129/304128,
    weighted 1D: 1310023/267079680,
    2D: 66605/23814144.

The full original common cost C_v(y,z)=L_v(y)−K_v(y,z), every physical clock weight including the terminal atom, original source-dependent ω/J/strict-past marks, receiver cubes and both receiver weights remain unchanged. The code rederives those fields before evaluating statistics. Actual matching is q_u=1 and m_u=R_u^n. Source masses remain 4,4,33/4, on the same 16,16,208 complete source cells. Receiver weights are finite quadrature, not dx; the gates are the declared finite diagnostic gates, not native high-dimensional hard history.

On old-source row i in original source cell y_i, the cost attributed to that row is exactly

    b_vi = w_v μ_v^+(cell_i) Σ_j U_v(cell_j) C_v(i,j).

This retains original outer w_v. The w_u, original mass ratios, J, past and clock are already inside the fully aggregated C. No cost is selected separately for different u. The statistics weight original bad cost, not just counts or receiver coverage.

## Five genuinely global partitions

Each candidate partition is fixed for the entire source and used unchanged for every v:

1. Singleton: one cluster for each positive-f-mass original source cell.
2. All source: a single cluster containing the full source.
3. Dyadic depth 1, 2, 3: the fixed domain [−2,2]^n is split into 2^depth intervals per coordinate, with phase −2. These are side lengths 2,1,1/2, respectively.

A source cell crossing a dyadic boundary is split by exact coordinate intersections. Its full-f mass and row cost are divided by the exact volume fraction. Original f, marks and cost are constant on an original cell, so this is exact integration, not a centre assignment. Half-open boundary conventions are immaterial for L1 volume integrals.

Cluster mass is always the **full** M_j=∫_{S_j}f, not surplus mass, captured mass, or a quantity redefined for v. Zero-f-mass clusters are omitted; every old surplus row belongs to a nonzero global cluster. For each candidate, Σ_jM_j=W is verified once. A comparison of different partitions does not sum their source budgets or select a partition separately for each receiver.

Positive-mass cluster counts are 8,1,2,4,8 in both 1D cases, and 11,1,4,6,10 in 2D. In 1D their masses are singleton/depth3: eight copies of 1/2; all-source:4; depth1:2,2; depth2:1,1,1,1. The corresponding 2D masses are saved with actual box definitions and exact original-cell piece assignments.

## Concrete geometry behind the change

In 2D only v=1 and v=7 carry positive product bad cost, and both have matched receiver mass m_v=9/4. Under singleton grouping their relevant full source-cell masses are 1 and 5/4, yielding ratios 9/4 and 9/5. The first lies outside [1/2,2]. Under all-source grouping both ratios are (9/4)/(33/4)=3/11, also outside that band.

The same fixed spatial depth-1 partition instead assigns the relevant rows to clusters of full masses 11/4 and 5/2, giving ratios 9/11 and 9/10. Depth 2 gives masses 5/4 and 9/4, hence ratios 9/5 and 1. Both global spatial partitions qualify all original positive bad rows. The remaining clusters also stay in the partition and in W; none is dropped because it is inconvenient for v.

The θ=1 weight χ is computed exactly as min(m_v/M_j,M_j/m_v), without exponentiation or a fitted rate. Depth 2 gives large χ-weighted shares 3167/3387, 3725669/3930069,1699/1903 in the three fields. These are not optimization claims: only the five declared global partitions were evaluated.

## Exact accounting and execution

All partitions retain exactly the same baseline cost. For each band the output saves its qualified cost, fraction of baseline and unqualified remainder. It also saves every positive cluster's mass/geometry, global original-cell splits, and per-(v,cluster) matched m_v/M_j and cost. This makes the prohibition on per-v partitions directly inspectable.

The local standard-library Python script actually ran and then reran in a fresh process, passing **898 exact grouped assertions**. They cover unchanged original fields, exact positive-cell partitions, ΣM_j=W for all fifteen candidate evaluations, assignment of all surplus rows, invariant total product cost and nested-band/χ bounds. No float, optimizer or MATLAB LP is involved; there is no new search over f or plans.

Standalone reproduction uses `r380_numeric.py` and `r380_numeric.input.json`:

    /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r380_numeric.py

`r380_numeric.result.json` stores exact summaries and all global-partition detail. Optional prepare snapshots frozen R379 input/result and records SHA256 provenance. Verify reads no older temporary scripts/data. Only R380-owned files are written.

Scope: actual compact positive-volume L1 source cells and complete original finite diagnostic cost, with uniform-product baseline and finite receiver quadrature. The result is decision evidence for global source grouping; it neither constructs a general alignment partition nor certifies the main hard-slot/root fee.
