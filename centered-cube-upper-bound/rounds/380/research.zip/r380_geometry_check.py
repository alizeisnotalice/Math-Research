from fractions import Fraction as F
from math import factorial
counts={'source_windows':0,'fractional_matching':0,'joint_envelope':0,'radial_constants':0,'clock_bound':0}
def exp_lower(x,N=12):
 return sum((x**j/factorial(j) for j in range(N+1)),F(0))
def certify_log_ge(value,r):
 if value<=0:return
 assert r>1
 x=(r-1)/(r+1);xp=x;lo=F(0)
 for k in range(1024):
  lo+=2*xp/(2*k+1);xp*=x*x
  if value<=lo:return
 raise AssertionError('log certificate did not separate')
# Stage 1: full-f countable-partition model (finite here) and source windows.
for seed in range(40):
 f=[F(1+(3*y+seed)%11,4) for y in range(10)]
 dy=[F(1+(y+seed)%3,5) for y in range(10)]
 # A fractional partition with three components; sums exactly to f.
 a=[]
 for y in range(10):
  w=[F(1+(y+j*2+seed)%5) for j in range(3)]
  a.append([z/sum(w) for z in w])
 fj=[[f[y]*a[y][j] for y in range(10)] for j in range(3)]
 M=[sum(fj[j][y]*dy[y] for y in range(10)) for j in range(3)]
 assert sum(M)==sum(f[y]*dy[y] for y in range(10))
 intervals=[(0,3),(2,7),(0,8),(1,10)]
 c=[[int(lo<=y<hi) for y in range(10)] for lo,hi in intervals]
 R=[sum(dy[y]*c[v][y] for y in range(10)) for v in range(4)]
 m=[sum(f[y]*dy[y]*c[v][y] for y in range(10)) for v in range(4)]
 q=[m[v]/R[v] for v in range(4)]; qm=min(q); lm=max(q)
 for j in range(3):
  for v in range(4):
   I=sum(fj[j][y]*dy[y]*c[v][y] for y in range(10))
   w=I*I/(M[j]*m[v])
   chi=min(M[j]/m[v],m[v]/M[j])
   assert 0<=w<=chi<=1
   for alpha,beta in ((F(1,4),F(1,4)),(F(1,2),F(1,3)),(F(3,4),F(1,2))):
    if I>=alpha*M[j] and I>=beta*m[v]:
     assert alpha*M[j]<=m[v]<=M[j]/beta
     assert alpha*M[j]/lm<=R[v]<=M[j]/(beta*qm)
    counts['source_windows']+=1
  counts['fractional_matching']+=1
# Stage 2: exact supremum envelope and its analytic radial antiderivatives.
# Integer theta and theta=1/2 checked using perfect-square t and x.
for theta in (F(1),F(2),F(3),F(4)):
 for ix in range(1,25):
  x=F(ix,8)
  for it in range(ix,33):
   t=F(it,8)
   F_t=min(t,1/t)**int(theta)/t
   g=(F(1) if x<=1 else x**(-int(theta)-1))
   assert F_t<=g
   counts['joint_envelope']+=1
for ix in range(1,13):
 x=F(ix,6)**2
 for it in range(ix,17):
  t=F(it,6)**2
  F_t=min(F(it,6),F(6,it))/t
  g=(F(6,ix) if x<=1 else F(6,ix)**3)
  assert F_t<=g
  counts['joint_envelope']+=1
for theta in (F(1,4),F(1,2),F(3,4),F(1),F(3,2),F(2),F(3),F(4)):
 # Exact integrals from the primitive x^theta/theta or x.
 inner=1/theta if theta<=1 else F(1)
 outer=1/theta
 expected=2/theta if theta<=1 else 1+1/theta
 assert inner+outer==expected
 counts['radial_constants']+=1
# Stage 3: original-shape clock L with mass/radius matching and atoms.
for dim in (2,3,4):
 for seed in range(24):
  R=[F(1),F(5,4),F(3,2),F(3,2),F(2)]
  q=[F(3+(i+seed)%2,4) for i in range(5)]
  m=[q[i]*R[i]**dim for i in range(5)]
  mu=[F(1+(i*2+seed)%5,4) for i in range(5)]
  cap=[int((i+seed)%4!=0) for i in range(5)]
  T=sum(mu[i]*cap[i] for i in range(5))
  grid=sorted(set(R)); K=F(3,2)
  J=[sum(mu[i]*cap[i] for i in range(5) if R[i]<=r) for r in grid]
  clock=[r**(-dim)-(grid[k+1]**(-dim) if k+1<len(grid) else 0)
         for k,r in enumerate(grid)]
  for hr in (F(1,4),F(1,2),F(3,4)):
   h=T*hr
   for v in range(5):
    L=F(0)
    for u in range(5):
     if m[v]>=m[u]/K:continue
     zp=sum(mu[w]*cap[w] for w in range(5) if m[w]<m[u]/K)
     if zp<=h:continue
     inner=sum(clock[k]/J[k] for k,r in enumerate(grid)
               if r>=R[u] and J[k]>=T/2 and J[k]>0)
     A=1-m[v]/m[u]
     L+=mu[u]*m[u]*cap[u]*A*inner
    if T<=h:assert L==0
    else:certify_log_ge(L,T/h) # lambda=1; true sourcewise clock log.
    counts['clock_bound']+=1
print('PASS',counts,'total',sum(counts.values()))
print('EXACT radial coefficient theta=1:',F(2))
