from fractions import Fraction as F
from itertools import product
counts=[0,0,0]
# Stage 1: rational scalar and complete atomic-left-clock inequalities.
for h in (F(1,4),F(1,2),F(1),F(2)):
    for T in (F(i,8) for i in range(33)):
        assert max(T-h,F(0))<=T*T/(4*h)
        counts[0]+=1
for weights in product((F(1,4),F(1,2),F(1)),repeat=4):
    for marks in ((F(1),)*4,(F(0),F(1),F(0),F(1)),(F(1,3),F(2,3),F(1),F(0))):
        for h in (F(1,4),F(1,2),F(1)):
            left=marked=joint=F(0)
            for w,a in zip(weights,marks):
                right=left+w
                if left>h:joint+=w*marked/right
                left=right;marked+=a*w
            assert joint<=max(left-h,F(0))<=left*left/(4*h)
            counts[0]+=1

# Exact spatial-cell matching identities; actual interval incidence, quadrature du.
xs=[F(-2)+F(2*i+1,8) for i in range(16)]
vol=[F(1,4)]*16
cubes=[(F(-1,2),F(1)),(F(0),F(1)),(F(0),F(3,2)),
       (F(1,2),F(3,2)),(F(0),F(2)),(F(1,2),F(2))]
cap=[[F(int(abs(x-c)<R/2)) for x in xs] for c,R in cubes]

def matching(seed,du,stage):
    f=[1+F((seed*(i+1)+i*i)%5,16) for i in range(16)]
    m=[sum(vol[i]*f[i]*cap[j][i] for i in range(16)) for j in range(6)]
    q=[m[j]/cubes[j][1] for j in range(6)]
    lam=max(q)
    assert min(q)>=F(3,4)*lam
    J=[sum(du[j]*cap[j][i]/m[j] for j in range(6)) for i in range(16)]
    first=sum(vol[i]*f[i]*J[i] for i in range(16))
    second=sum(vol[i]*f[i]*J[i]**2 for i in range(16))
    joint=F(0)
    for j,k in product(range(6),repeat=2):
        inter=sum(vol[i]*f[i]*cap[j][i]*cap[k][i] for i in range(16))
        joint+=du[j]*du[k]*inter/(m[j]*m[k])
    assert first==sum(du)
    assert second==joint
    W=sum(vol[i]*f[i] for i in range(16))
    assert first*first<=W*second
    counts[stage]+=4
    for h in (F(1,8),F(1,4),F(1,2),F(1)):
        excess=sum(vol[i]*f[i]*max(J[i]-h,F(0)) for i in range(16))
        assert excess<=second/(4*h)
        counts[stage]+=1
for seed in range(5):matching(seed,[F(1,6)]*6,1)
for seed in range(41):
    for du in ([F(1,6)]*6,[F(j+1,21) for j in range(6)],
               [F(1,2),F(0),F(1,4),F(0),F(1,8),F(1,8)]):
        matching(seed,du,2)
print('PASS stages',counts,'total',sum(counts))
