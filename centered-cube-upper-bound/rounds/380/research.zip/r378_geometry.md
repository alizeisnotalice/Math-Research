# R378 — Paying the sparse-protrusion part of the actual remainder

## 1. Precise new branch and receipt

Keep every frozen R377 field: the actual finite-measure Lebesgue receiver set E; the full f; a≤R_u≤b≤2a; m_u=f(Q_u)=q_uR_u^n with q_-≤q_u≤λ; the original strict mass past, source-dependent J, H, and physical clock; and the actual outside/not-Bplus far-pair mask. Put
\[
 j(u,v)=\#\{i:2|u_i-v_i|>R_u-R_v\},\qquad k_n=\lfloor n/8\rfloor.
\]
A counted coordinate is exactly one in which the small cube protrudes beyond a face of the large cube. The far-mass gate gives R_v<R_u, so each coordinate intersection Q_u∩Q_v has at most one truncated side. Equality in the displayed test is not counted.

The new branch is the SAME actual remainder with j(u,v)≤k_n. Its exact complement has
\[
 j(u,v)>k_n,\quad\hbox{equivalently }j(u,v)>n/8, \tag{1}
\]
and retains every old gate. Define
\[
 b_n=2^{-n}\sum_{j=0}^{k_n}{n\choose j}4^j,\qquad
 \widehat b_n=\begin{cases}0,&n<8,\\b_n,&n\ge8.\end{cases}
\]
For ANY original-source-exact plan τ_v, not merely one particular proposal,
\[
 \boxed{G_{\rm sparse}(\tau)
 \le{\widehat b_n\over h}|E|
 \le{\varepsilon_0\widehat b_n\over1+\sqrt n}X_q.} \tag{2}
\]
Here h=(1+√n)/(ε₀q_-) is the unchanged original high-past threshold. No W fee is added. A target cap of 2 remains 2; in fact the estimate itself requires only source exactness, not the target-cap bound.

This is a plain-center dv estimate. It does NOT assert that the corresponding integral against μ(dv)=dv/m_v is exponentially small. The distinction and the cancellation of m_v are explicit in §3.

## 2. Selector-uniform center volume and exact exponential rate

Fix u and consider actual v with R_v<R_u, I_uv=f(Q_u∩Q_v)>0, and j(u,v)≤k_n. Since the cubes share a source point, in every coordinate
\[
 |v_i-u_i|\le(R_u+R_v)/2<R_u.
\]
For any coordinate not counted by j,
\[
 |v_i-u_i|\le(R_u-R_v)/2
 \le(R_u-a)/2\le R_u/4. \tag{3}
\]
The last inequality uses the original octave R_u≤b≤2a.

Thus the center belongs to a union, indexed by subsets S⊂{1,…,n} with |S|≤k_n, of boxes having side 2R_u in coordinates S and side R_u/2 in the other coordinates. Consequently
\[
 \boxed{\big|\{v\in E:I_{uv}>0,\ R_v<R_u,\ j(u,v)\le k_n\}\big|
 \le R_u^n b_n.} \tag{4}
\]
This is a union bound for actual center locations. The selected R_v can be an arbitrary measurable function, and is eliminated only through the valid inequalities (3). There is no independent dR integration, disjoint-source assertion, or product assumption about f.

For t=1/28, because j≤k_n and t<1,
\[
 b_n\le2^{-n}t^{-k_n}(1+4t)^n
 \le\left[{4\over7}28^{1/8}\right]^n=:\rho^n,
 \qquad
 \rho^8={1835008\over5764801}<1. \tag{5}
\]
This is an exact all-dimensional bound, without a fitted asymptotic rate or polynomial loss. The floor k_n is retained throughout.

If n<8 then k_n=0. But j=0 gives Q_v⊂Q_u and hence |u−v|∞<R_u/2, incompatible with the original outside gate
2|u−v|∞>αR_u, α=(1+√n)^(1/n)>1.
Therefore the ACTUAL sparse outside branch is empty in those dimensions. This explains the zero in \widehat b_n; the geometric union bound (4) itself is still valid.

## 3. Original-plan formula: why the measure really is plain dv

Write
\[
 \mu_v^+(dy)={(f(y)-q_v)_+c_v(y)\over m_v}\,dy
             =d_vP_v(dy).
\]
For every v, let τ_v have exactly this source marginal. Use the unchanged pair factor
A_uv=S_uv(1−m_v/m_u), where S_uv includes far mass, outside, and not-Bplus. Thus 0≤A_uv≤1 and any retained pair has R_v<R_u.

For the original full clock and source gates,
\[
 \omega_u(y)=hR_u^n\int_{[R_u,b]}\ell(dr)
 {1_{J_y(r)\ge H}1_{Z_y(m_u/K-)>h}\over J_y(r)}.
\]
The original strict-past inclusion gives J_y(r)>h on the retained integrand, and the complete physical clock, including its b atom, has tail R_u^{-n}. Hence 0≤ω_u≤1. This fact is used only after the exact source-integrated branch formula below:
\[
 G_{\rm sparse}(\tau)=
 \int_E{du\over hR_u^n}\int_Edv\,A_{uv}1_{\{j\le k_n\}}
 \int \omega_u(y)c_u(y)(1-c_u(z))\,\tau_v(dy,dz). \tag{6}
\]
This is the actual bad cost restricted by a pair mask; no coupling variables, gates, or normalization have been changed.

For each retained pair, source exactness and full-f matching yield
\[
\begin{aligned}
 \int \omega_uc_u(y)(1-c_u(z))\,d\tau_v
 &\le\int c_u(y)\,\mu_v^+(dy)\\
 &\le {I_{uv}\over m_v}\le1,\qquad I_{uv}\le m_v=f(Q_v).
\end{aligned} \tag{7}
\]
The expression vanishes when I_uv=0. It is precisely (7) that consumes the normalization 1/m_v in μ_v^+. What remains in (6) is the original outer dv, not dv/m_v. Therefore
\[
 G_{\rm sparse}(\tau)
 \le\int_E {du\over hR_u^n}
       |\{v:I_{uv}>0,\ R_v<R_u,\ j\le k_n\}|
 \le b_n|E|/h. \tag{8}
\]
Use the empty-branch observation for n<8, |E|≤X_q/q_-, and the original h to obtain (2).

This is the R338 center-cap interface proved directly for the current arbitrary source-exact plan. There is no density cap, no bound on a source layer by its Lebesgue volume, and no μ-center capacity claim. The only volume estimate concerns actual receiver centers v after (7).

## 4. Same-field ledger and exact dense complement

Keep the existing complete cap-2 plan, including its retained subflow k and actual refill γ. Splitting the u,v pair mask partitions its exact cost:
\[
 G_{\rm refill}=G_{\rm sparse}+G_{\rm dense}, \tag{9}
\]
where dense means j>n/8 together with ALL original gates. The fields f,q,m,J,H,h,ω and clock do not change. There is no need to rebuild the plan to use (9).

Thus the current hard ledger becomes
\[
 B_H\le G_{\rm dense}
 +\varepsilon_0\!\left[
 2+{C_n^++3\Gamma_n+\widehat b_n\over1+\sqrt n}\right]X_q
 +C_{338}W. \tag{10}
\]
The source fee C338W and target-template fee 3Γ_n are unchanged. All original outer entrance terms and the multiplier Λ remain as in R377; the new receiver coefficient in the full entrance is exactly
2Λε₀\widehat b_n/(1+√n).

One may apply the existing R377 Hardy estimate to this restricted kernel. Define L_dense,K_dense by inserting 1_{j>n/8} into the original u,v integral, and use the SAME actual subflows. Let S_dense be the retained true cost; let A_dense={L_dense−E_UK_dense>0}; and let Ξ_A,dense and Cap_A,dense be the actual lost source mass and refill capture restricted to this active set. The source-exact density plan gives
\[
 G_{\rm dense}\le
 S_{\rm dense}+\varepsilon X_q+
 \lambda\log{\lambda\over\varepsilon q_-}\Xi_{A,\rm dense}
 -\operatorname{Cap}_{A,\rm dense}. \tag{11}
\]
No old sparse capture or return credit is subtracted again. Zero-mean-cost rows have zero cost for the existing U-absolutely-continuous plans, exactly as in R377. Also S_dense≤S≤ξX_q when the existing near-capture construction has that property; no free change of ξ is made.

A future plan with a larger allowed target cap would still obey (2); only its separately certified template tariff would change. This note does not construct or charge such a plan.

## 5. Scope: a new paid coordinate family, not closure

The criterion controls the number of genuinely protruding coordinates, not the sum of protrusion depths. A small number of coordinates may protrude far beyond the old low-excess allowance. The proof does not alter any old low-excess threshold or seek a stronger μ-capacity estimate.

For clarity, the geometric masks themselves do leave room for this branch. At a=R_v=1, R_u=2, u=0, v=(5/4,0,…,0), the common-source overlap has positive volume and j=1. For n≥8 the point lies outside αQ_u because α<5/4. With the frozen Bplus definitions β=1+1/n and s_eff=max(a,R_v/β)=1, its permitted total excess is 1/[4(n+1)], whereas this pair has total excess 3/2; hence it is outside Bplus. This is a geometric noncontainment illustration, not a claimed full native high-past witness. No test example is used to prove (2).
The inequality α<5/4 for n≥8 follows, for example, from
1+√8<(5/4)^8 and the fact that (5/4)^n/(1+√n) increases for n≥8.

The precise unpaid complement is now the actual j>n/8 branch in (11). Many protruding coordinates do NOT imply that each truncated face is deep. In particular, no exponential bound for p_uv=|Q_u∩Q_v|/|Q_v| follows merely from (1). The proof supplies no general root-order budget for its shared loss Ξ_A,dense or signed M1 balance.

## 6. Actual exact checks and reproducibility

Executed locally on 2026-10-18:
python3 /tmp/r378_geometry_check.py

Output:
PASS {'binomial_rate': 256, 'selector_center_union': 27, 'plan_capacity_payment': 60} total 343

1. Fraction/integer calculations for n=1,…,256 verify the exact binomial sums and b_n^8≤(1835008/5764801)^n, including small n and the floor.
2. Exact rational cell integration in dimensions 1–3 computes unions of sparse-protrusion center regions over finite selected-radius menus. Those unions dominate every selector from the menus. The volume bound is checked without sampling or fitted rates.
3. Sixty exact finite source/cube-incidence computations verify full-f masses, source marginals, target cap 2, and the crucial conversion (7) to the plain-center payment (8). These are finite quadrature diagnostics, not native high-past Lebesgue fields; the general-field proof is §§2–3.

No floating-point computation or counterexample search is used. The new paid branch is (2); the unresolved dense original integral is explicitly retained.
