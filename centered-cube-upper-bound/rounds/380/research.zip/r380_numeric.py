#!/usr/bin/env python3
"""Global fixed source partitions and actual product bad-cost alignment."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter,defaultdict
from itertools import product
import json,sys,hashlib
BASE=Path(__file__).resolve().parent;COUNTS=Counter()
def ck(k,v):
 COUNTS[k]+=1
 assert v,k
def dot(a,b):return sum((F(x)*y for x,y in zip(a,b)),F(0))
def read(p):return json.loads((BASE/p).read_text())
def sha(p):return hashlib.sha256((BASE/p).read_bytes()).hexdigest()
def prepare():
 old=read('r379_numeric_input.json');data=dict(cases=old['cases'],provenance={p:sha(p) for p in ['r379_numeric_input.json','r379_numeric_result.json']},baseline='Uniform product coupling for the original surplus μplus and U. Not the cap2-optimal plans; no source or receiver mass is altered.',scope='Global source partitions independent of v, true full-f cluster masses and complete positive-volume cells, frozen original diagnostic cost; finite receiver quadrature, not native hard gates or a general alignment theorem.')
 (BASE/'r380_numeric.input.json').write_text(json.dumps(data,sort_keys=True,indent=2)+'\n');print('PREPARED uniform product baseline; five global source partitions for three frozen fields')
def fullmarks(c):
 n=c['n'];N=len(c['receivers']);A=c['A'];vol=list(map(F,c['volumes']));x=list(map(F,c['source_mass']));f=[a/b for a,b in zip(x,vol)];R=[F(r['R']) for r in c['receivers']];w=[F(r['weight']) for r in c['receivers']];centers=[list(map(F,r['center'])) for r in c['receivers']];m=[r**n for r in R];mu=[a/b for a,b in zip(w,m)];radii=sorted(set(R));h=F(c['h']);H=F(c['H']);kap=F(c['kappa']);omega=[list(map(F,row)) for row in c['omega']]
 ck('stage2_full_source_same_all_actual_matching',all(dot(row,x)==mass for row,mass in zip(A,m)) and sum(x)==F(c['actual_W']))
 expected=[[F(0)]*len(x) for _ in range(N)]
 for u in range(N):
  for y in range(len(x)):
   past=sum(mu[t]*A[t][y] for t in range(N) if m[t]<m[u]/kap)
   if past<=h:continue
   for l,r in enumerate(radii):
    if r<R[u]:continue
    J=sum(mu[t]*A[t][y] for t in range(N) if R[t]<=r)
    if J>=H:
     ell=r**(-n)-(radii[l+1]**(-n) if l+1<len(radii) else 0)
     expected[u][y]+=h*m[u]*ell/J
 ck('stage2_reconstructed_full_omega_J_past_clock',expected==omega)
 for p in c['plans']:
  v=p['v'];src=p['source_cells'];tgt=p['target_cells'];d=F(p['d']);rows=list(map(F,p['row']));cols=[d*F(u) for u in p['U']];K=[list(map(F,row)) for row in p['K']];L=list(map(F,p['L']));C=[list(map(F,row)) for row in p['cost']]
  ck('stage2_original_source_and_uniform_target_marginals',rows==[vol[y]*(f[y]-1)/m[v] for y in src] and cols==[d*vol[z]/m[v] for z in tgt] and sum(rows)==sum(cols)==d)
  Lv=[];Kv=[]
  for y in src:
   aa=[]
   for u in range(N):
    S=m[u]>kap*m[v] and 2*max(abs(a-b) for a,b in zip(centers[u],centers[v]))>R[u]
    aa.append(mu[u]*(1-m[v]/m[u])/h*omega[u][y]*A[u][y] if S else F(0))
   Lv.append(sum(aa));Kv.append([sum(aa[u]*A[u][z] for u in range(N)) for z in tgt])
  ck('stage2_one_common_objective_all_u_and_original_marks',Lv==L and Kv==K and C==[[L[i]-a for a in row] for i,row in enumerate(K)])
 return True

def partition(c,kind,depth=None):
 cells=[[(F(a),F(b)) for a,b in cell] for cell in c['cells']];x=list(map(F,c['source_mass']));vol=list(map(F,c['volumes']));n=c['n'];pieces={};labels={};domain=[(min(cell[i][0] for cell in cells),max(cell[i][1] for cell in cells)) for i in range(n)]
 for j,(cell,mass) in enumerate(zip(cells,x)):
  if not mass:continue
  if kind=='singleton':parts=[(('cell',j),F(1))];labels[('cell',j)]=dict(original_cell=j,bounds=[[str(a),str(b)] for a,b in cell])
  elif kind=='all':parts=[(('all',),F(1))];labels[('all',)]=dict(domain=[[str(a),str(b)] for a,b in domain])
  else:
   M=2**depth;axis=[]
   for i,(a,b) in enumerate(cell):
    lo,hi=domain[i];w=(hi-lo)/M;axis.append([(k,max(a,lo+k*w),min(b,lo+(k+1)*w)) for k in range(M) if max(a,lo+k*w)<min(b,lo+(k+1)*w)])
   parts=[]
   for tup in product(*axis):
    key=('dyadic',depth)+tuple(z[0] for z in tup);v=F(1)
    for k,a,b in tup:v*=b-a
    parts.append((key,v/vol[j]));bounds=[]
    for i,(k,a,b) in enumerate(tup):
     lo,hi=domain[i];w=(hi-lo)/M;bounds.append([str(lo+k*w),str(lo+(k+1)*w)])
    labels[key]=dict(dyadic_indices=[z[0] for z in tup],bounds=bounds)
  ck('positive_source_cell_exact_partition_no_overlap_mass_loss',sum(a for key,a in parts)==1 and all(a>0 for key,a in parts));pieces[j]=parts
 masses=defaultdict(F)
 for j,parts in pieces.items():
  for key,frac in parts:masses[key]+=x[j]*frac
 ck('global_full_f_cluster_masses_sum_W_once',sum(masses.values())==sum(x)==F(c['actual_W']) and all(m>0 for m in masses.values()))
 keys=sorted(masses,key=repr);ids={key:i for i,key in enumerate(keys)}
 return {j:[(ids[key],frac) for key,frac in parts] for j,parts in pieces.items()},[dict(cluster=i,mass=str(masses[key]),geometry=labels[key]) for i,key in enumerate(keys)]
def verify():
 data=read('r380_numeric.input.json');summary=[];details=[]
 for c in data['cases']:
  fullmarks(c);baseline=F(0);rowcost=[]
  for p in c['plans']:
   U=list(map(F,p['U']));r=list(map(F,p['row']));w=F(p['weight']);m=F(c['receivers'][p['v']]['R'])**c['n'];C=[list(map(F,row)) for row in p['cost']]
   for i,(src,mass) in enumerate(zip(p['source_cells'],r)):
    bad=w*mass*dot(U,C[i]);rowcost.append((p['v'],src,m,bad));baseline+=bad
  ck('product_bad_and_original_positive_account',0<=baseline<=F(c['surplus_diagonal']) and F(c['original_diagonal'])==F(c['floor'])+(F(c['surplus_diagonal'])-baseline)+baseline)
  parts=[]
  for kind,depth in [('singleton',None),('all',None),('dyadic',1),('dyadic',2),('dyadic',3)]:
   pieces,clusters=partition(c,kind,depth);masses=[F(z['mass']) for z in clusters];bands={b:F(0) for b in [2,4,16]};chi=F(0);seen=F(0);stats=defaultdict(F)
   for v,src,m,bad in rowcost:
    ck('every_old_surplus_source_has_global_nonzero_cluster',src in pieces)
    for cluster,frac in pieces[src]:
     M=masses[cluster];ratio=m/M;cost=bad*frac;seen+=cost;chi+=cost*min(ratio,1/ratio);stats[(v,cluster)]+=cost
     for b in bands:
      if F(1,b)<=ratio<=b:bands[b]+=cost
   ck('same_product_bad_all_global_partitions',seen==baseline)
   ck('nested_bands_and_weighted_chi_bounds',0<=bands[2]<=bands[4]<=bands[16]<=baseline and 0<=chi<=baseline)
   name=kind if depth is None else 'dyadic_depth_'+str(depth)
   rows=[]
   for (v,j),bad in sorted(stats.items()):
    m=F(c['receivers'][v]['R'])**c['n'];ratio=m/masses[j];rows.append(dict(v=v,cluster=j,matched_receiver_mass=str(m),cluster_mass=str(masses[j]),matched_ratio=str(ratio),original_product_bad=str(bad),chi_theta1=str(min(ratio,1/ratio))))
   psummary=dict(partition=name,positive_mass_clusters=len(clusters),cluster_masses=[z['mass'] for z in clusters],W_counted_once=str(sum(masses)),band_covered_bad={str(b):str(z) for b,z in bands.items()},band_covered_fraction={str(b):str(z/baseline) if baseline else None for b,z in bands.items()},band_uncovered_bad={str(b):str(baseline-z) for b,z in bands.items()},chi_theta1_weighted_bad=str(chi),chi_theta1_fraction=str(chi/baseline) if baseline else None)
   parts.append(psummary);details.append(dict(name=c['name'],partition=name,clusters=clusters,source_cell_pieces={str(j):[[k,str(frac)] for k,frac in values] for j,values in pieces.items()},row_statistics=rows))
  summary.append(dict(stage=c['stage'],name=c['name'],n=c['n'],actual_W=c['actual_W'],original_diagnostic_G=c['original_diagonal'],uniform_product_Gjoint=str(baseline),partitions=parts))
 out=dict(status='PASS',exact_grouped_checks=sum(COUNTS.values()),check_counts=dict(COUNTS),summary=summary,partition_details=details,baseline=data['baseline'],scope=data['scope'],provenance=data['provenance'])
 (BASE/'r380_numeric.result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['partition_details','summary']}|{'summary':[dict(name=z['name'],uniform_product_Gjoint=z['uniform_product_Gjoint'],partitions=[{k:v for k,v in p.items() if k in ['partition','positive_mass_clusters','band_covered_fraction','chi_theta1_fraction']} for p in z['partitions']]) for z in summary]},sort_keys=True,indent=2))
if __name__=='__main__':prepare() if len(sys.argv)>1 and sys.argv[1]=='prepare' else verify()
