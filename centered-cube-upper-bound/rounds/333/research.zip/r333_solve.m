r333_base=fileparts(mfilename('fullpath'));
% R333 finite signed-potential LP candidates. No path/global changes.
r333_data=jsondecode(fileread(fullfile(r333_base,'r333_data.json')));
r333_cases=r333_data.cases;
r333_candidates=struct('id',{},'exitflag',{},'c',{},'zeta',{},'message',{});
r333_options=optimoptions('linprog','Display','none');
for r333_k=1:numel(r333_cases)
    r333_result=struct();
    r333_case=r333_cases(r333_k);
    r333_N=numel(r333_case.weights);
    r333_rows=numel(r333_case.source);
    r333_A=zeros(r333_rows+1,r333_N+1);
    r333_b=zeros(r333_rows+1,1);
    r333_A(1:r333_rows,1)=-1;
    r333_A(1:r333_rows,2:end)=-r333_case.solver_T;
    r333_b(1:r333_rows)=-r333_case.solver_d(:);
    r333_A(end,2:end)=r333_case.solver_weights(:)';
    r333_b(end)=r333_case.solver_credit;
    r333_f=[1;zeros(r333_N,1)];
    [r333_sol,~,r333_exit,r333_output]=linprog(r333_f,r333_A,r333_b,[],[],[0;-inf(r333_N,1)],[],r333_options);
    r333_result.id=r333_case.id;r333_result.exitflag=r333_exit;r333_result.message=r333_output.message;
    if isempty(r333_sol)
        r333_result.c=NaN;r333_result.zeta=zeros(1,r333_N);
    else
        r333_result.c=r333_sol(1);r333_result.zeta=r333_sol(2:end)';
    end
    r333_candidates(end+1)=r333_result;
end
r333_json=jsonencode(struct('candidates',r333_candidates));
r333_file=fopen(fullfile(r333_base,'r333_solve_results.json'),'w');fwrite(r333_file,r333_json,'char');fclose(r333_file);
disp(struct('status','CANDIDATES_WRITTEN','cases',numel(r333_candidates),'path',fullfile(r333_base,'r333_solve_results.json')));
