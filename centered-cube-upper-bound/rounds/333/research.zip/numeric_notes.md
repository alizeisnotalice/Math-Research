# R333 — shared signed-potential LP, rational certificate pipeline

## Reproduction

Place the source files in one directory. Python resolves files relative to `__file__`; MATLAB resolves them relative to `mfilename('fullpath')`. No hard-coded `/tmp` dependency remains in the code.

1. `python r333_numeric.py`; MATLAB `run('r333_solve.m')`; Python `r333_numeric.py --verify`.
2. Python `r333_numeric.py --prepare-qp`; MATLAB `run('r333_solve_qp.m')`.
3. Python `r333_numeric.py --prepare-qp-lp`; MATLAB `run('r333_solve_qp_lp.m')`; Python `r333_numeric.py --verify-qp-lp`.
4. Python `r333_numeric.py --summary` produces the small final comparison JSON.

The actual bundled interpreter is `/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`. Run MATLAB scripts by their full location when their directory is not the current working directory.

Python uses only the standard library. MATLAB uses `linprog`; its floating-point output is a candidate, not a certificate or a certified optimum. No global path or environment changes are made. Separate finite double fields are supplied to MATLAB: exact fractions can have more than300 digits, so their numerator/denominator strings are not separately converted to doubles by MATLAB.

## Complete physical source partition; finite receiver scope

Reuse the three R332 actual-cube geometries in dimensions1/2/3, with actual mixed radii1,3/2,2 and positive rational receiver quadrature weights. Full f=β=ν=1_Q4. Actual captured masses m_i=R_i^n imply q=λ=1. Each kernel cube lies inside Q4. The receiver weights are explicitly finite quadrature, not Lebesgue dx or a complete original selector. This restriction applies to the whole certificate.

All source space inside Q4 is cut at every actual cube face. Every resulting positive-volume source box has a constant COMPLETE incidence signature, J and every prefix feature. No source box, including zero-J boxes, is omitted. There are5,64,900 cells in the three stages. Outside Q4 all kernel indicators vanish; hence d=T*ζ=0 there and c≥0 covers the complement. Source integration over each box is its exact volume, not a point approximation.

The twelve cases are these three geometries, H=0 or1/8, and two nonnegative rational references: h=G_lower or h=(5/4)G_lower. G_lower approximates the full-source Hilbert reference Φ_f downward using exact integer-square-root intervals at80 binary bits. The second is explicitly named scaled_G in the data. It is NOT the rank-one Splus reference; no theta-capacity property is claimed or needed. Its exact norm is charged explicitly.

## Rational source upper and common potential

Every original physical prefix and the terminal ell atom is retained. Original J,A and β=f are unchanged. For each source cell j, the preparer computes the exact a_H(j), T*1(j), original full one-sided square Eall and actual B_H. It defines the rational upper

d_j=a_H(j)+T*1(j)−2Σell μ_iμ_k c_i(j)c_k(j)h_ik / sqrt_upper(J_j).

Since h≥0 and sqrt_upper(J)≥sqrt(J), this is an UPPER bound on the true source defect, including at zero-J rows by the zero convention. Norm=Σell μ_iμ_k h_ik² and credit=Xq−norm are exact rationals; Xq=Σ receiver weights because q=1.

For fixed reference the finite LP is

minimize c≥0,
 d_j≤c+Σ_i [w_i/R_i^n]c_i(j) ζ_i for EVERY source cell,
 Σ_i w_i ζ_i≤credit,

with a single signed ζ_i per receiver, shared across all prefixes and sources. No sign restriction is placed on ζ. The solver therefore searches a real common receiver potential rather than separately pricing source rows. This is a candidate upper-bound search; there is no claim of LP optimality or a general continuum theorem.

## Exact post-solver repair and original-square checks

Python converts each floating ζ_i to a rational with denominator at most10^8. If its exact weighted budget exceeds credit, it subtracts the SAME rational δ=(budget−credit)/Σw from every ζ_i. It then sets

c=max(0,max_j[d_j−T*ζ(j)]).

Thus both the signed budget and all source inequalities are exactly feasible. This repair does not assume solver residuals are trustworthy. Exact integration of the shared potential uses the actual identity ∫f T*ζ=Σw_iζ_i. It checks

B_H≤Σ_j f(cell_j)d_j−credit+H W_f≤(c+H)W_f.

Separately it checks the original full-square completion

B_H≤∫f a_H−Eall+H W_f.

All these post-repair statements use exact fractions and the complete source partition. A nonzero repair or loose c is retained honestly; it is not described as an optimal dual or general root estimate. The completion λH term is present also for the positive-H cases; H=0 cases are all-row diagnostics.

## Execution status

The primary agent actually ran MATLAB `linprog` for all twelve cases. Python exact repair then passed **3,924 exact checks** over every source cell, every common budget and the original square/completion account. For H0 and h=G_lower, the final bounds cW are approximately.112904,.704145,1.522071 in n1/2/3, versus actual B_all.04,.0826354,.1008400. At H1/8 several repaired c values are0, but the completion H W equals.5,2,8 and dominates; no gain is inferred from c0 alone. The scaled_G reference generally gives larger bounds. Full rational potentials and repair deltas are retained in `/tmp/r333_numeric_verified.json`.

Every MATLAB loop resets only its task-local result struct. It does not clear the user workspace, and LP/QP scripts are safe to run in sequence after the stale-struct bug discovered in the first QP attempt was corrected.

## Bounded source-QP follow-up

The source cells can be merged EXACTLY by their complete receiver incidence signature: Jprefix, aH and all features agree on a signature. Keeping also the zero signature yields4,10,19 groups for n1/2/3. `/tmp/r333_numeric.py --prepare-qp` writes `/tmp/r333_data_qp.json`. Run MATLAB `/tmp/r333_solve_qp.m` for the six H0/1/8 cases. It solves the finite concave-source candidate objective aH·x−xᵀKx under x≥0,Cx=m,Σx=W. K is supplied as a numerical positive-semidefinite Gram construction. Neither solver success nor its objective is an exact optimality certificate.

Python `--prepare-qp-lp` will rationalize the candidate x, restore the affine equalities by exact elimination, and mix minimally with the original positive source-group masses if needed to restore nonnegativity. It verifies Cx=m,Σx=W exactly. It then constructs a nonnegative rational h approximating Φ_x from below, computes exact norm/credit and complete-source defect uppers, and writes a separate shared-potential LP. The subsequent certificate is valid regardless of QP optimality: only the exactly reconstructed h and common-zeta inequalities enter it. The primary agent actually ran the six QPs and all six subsequent reference LPs. The exact source repair succeeded with no mixing needed in any case; affine equalities and nonnegativity hold exactly after rationalization/projection. A source-group mass is distributed proportionally across the original positive-volume cells with that signature. This gives an actual compact L1 source, with the selected receivers still satisfying their exact original mass constraints Cx=m and q=1. It is not a claim about other receiver cubes or complete original history.

The exact original B_H(g,g) of each repaired source is additionally evaluated using the same original J/A/ell and the one-sided square A²/J, not merely the QP relaxed objective. Square-root interval enclosures also give rational bounds for the candidate fixed-W relaxed objective. QP optimality is not certified.

The extra six shared-potential candidates passed **90 exact post-repair checks**. Together with the fixed-reference3924 this is **4014 exact post-repair assertions**. Source preparation and exact feasibility assertions are additional uncounted checks; no earlier round's algebra/Decimal counts or the primary agent's separate directed-credit checks are included.

## Comparisons that affect the next decision

H0 all-row values:

|n|original f actual B|repaired QP source actual B|original-reference shared-zeta bound|QP-reference before zeta|QP-reference after zeta|
|---|---:|---:|---:|---:|---:|
|1|.0400000|.0416638|.112904|.316239|.132866|
|2|.0826354|.1044443|.704145|2.345185|.488162|
|3|.1008400|.1141367|1.522071|8.720767|1.121499|

The before-zeta bound uses the SAME rational h and ζ=0; its credit is nonnegative in these cases, so it is a valid comparison. Shared potentials materially reduce that bound. Replacing the original-source reference by the repaired QP-source reference helps in n2/3 but worsens n1. None approaches the actual original-f traffic. The repaired QP source modestly increases actual original traffic; this is a finite geometric source reallocation, not a dimension-rate finding.

For H1/8, original-f B_H is approximately.04,.0635806,.0569112; repaired-source B_H is.0416638,.0872890,.0704322. The completed QP-reference certificate is approximately.632866,2,8. Its mandatory H W completion charge alone is.5,2,8; the near-zero c in n2/3 is not evidence of a small whole bill. The fixed-W QP relaxed objectives there are approximately−.0735674 and−.1196492, while the true B_H remains positive: dropping the completion account would misstate this experiment.

The fixed-W source QP optimizes aH·x−xᵀKx, not the constrained zero-X-budget c and not F/W over the entire mean cone. Pattern0 carries substantial unused source mass and is retained. Therefore its candidate is used only to select a reference h. This round does not claim a best ratio reference or a least shared-potential certificate; it adds no parametric optimization or new source geometry. A future improvement would have to target the actual zero-X-budget/source-ratio obligation, rather than equating this QP objective with it.

## Minimal replay and archive material

The complete regenerating source consists of **four small files**: `r333_numeric.py`, `r333_solve.m`, `r333_solve_qp.m`, and this note. `r333_solve_qp_lp.m` is generated by Python. All large data JSON files are deterministic products and need not be archived. To preserve the actually run MATLAB candidates, retain the three small outputs `r333_solve_results.json`, `r333_solve_qp_results.json`, `r333_solve_qp_lp_results.json`; the two verified certificate outputs and `r333_numeric_summary.json` are useful audit records. Source data and exact source-repair details can be regenerated from the source and candidate records. No multi-megabyte reconstructed data is necessary in the final archive.

The primary agent completed the ENTIRE portable pipeline in `/Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint`: twelve LPs, six QPs, six final LPs, both exact verifiers (3924+90=4014 PASS), and summary generation. This independently reproduces the n1 deterioration and n2/3 improvements in the table. It supports changing the next optimization objective toward the actual ratio/zero-X-budget constraint rather than continuing to optimize the fixed-W surrogate. Code and notes are now frozen. There is no claim of a general root estimate or continuum receiver proof.
