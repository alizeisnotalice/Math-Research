r333_base=fileparts(mfilename('fullpath'));
% R333 finite worst-source concave quadratic candidates, original frozen features.
r333_qpdata=jsondecode(fileread(fullfile(r333_base,'r333_data_qp.json')));
r333_qpcandidates=struct('id',{},'exitflag',{},'x',{},'objective',{},'equality_residual',{},'message',{});
r333_qpoptions=optimoptions('quadprog','Display','none');
for r333_k=1:numel(r333_qpdata.cases)
    r333_result=struct();
    r333_qpcase=r333_qpdata.cases(r333_k);
    r333_K=(r333_qpcase.K+r333_qpcase.K')/2;
    [r333_x,r333_fval,r333_exit,r333_output]=quadprog(2*r333_K,-r333_qpcase.a(:),[],[],r333_qpcase.Aeq,r333_qpcase.beq(:),zeros(numel(r333_qpcase.a),1),[],r333_qpcase.x0(:),r333_qpoptions);
    r333_result.id=r333_qpcase.id;r333_result.exitflag=r333_exit;r333_result.message=r333_output.message;
    if isempty(r333_x)
        r333_result.x=zeros(1,numel(r333_qpcase.a));r333_result.objective=NaN;r333_result.equality_residual=NaN;
    else
        r333_result.x=r333_x';r333_result.objective=-r333_fval;
        r333_result.equality_residual=max(abs(r333_qpcase.Aeq*r333_x-r333_qpcase.beq(:)));
    end
    r333_qpcandidates(end+1)=r333_result;
end
r333_file=fopen(fullfile(r333_base,'r333_solve_qp_results.json'),'w');fwrite(r333_file,jsonencode(struct('candidates',r333_qpcandidates)),'char');fclose(r333_file);
disp(struct('status','QP_CANDIDATES_WRITTEN','cases',numel(r333_qpcandidates),'path',fullfile(r333_base,'r333_solve_qp_results.json')));
