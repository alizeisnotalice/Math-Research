from fractions import Fraction as F
import json
checks=0
for case in range(1,61):
 roots=[F(i+1) for i in range(4)];m=[x*x for x in roots]
 mu=[F(1+(case+i)%7,9) for i in range(4)]
 alpha=F(1+case%4,4); common=F(1);J=sum(mu)
 S=[[alpha*(common/J+(m[i]-common)/mu[i] if i==j else common/J) for j in range(4)] for i in range(4)]
 row=[sum(S[i][j]*mu[j] for j in range(4)) for i in range(4)]
 w=[[min(F(1),((roots[j]/roots[i])-1)**2/2) if m[j]>m[i] else F(0) for j in range(4)] for i in range(4)]
 zeta=[sum(w[i][j]*S[i][j]*mu[j] for j in range(4))/m[i] for i in range(4)]
 P=sum(mu[i]*m[i]**2*zeta[i] for i in range(4))
 D=sum(mu[i]*mu[j]*S[i][j]*(roots[i]-roots[j])**2/4 for i in range(4) for j in range(4))
 L=sum(mu[i]*m[i]*(m[i]-row[i]) for i in range(4))
 norm=sum(mu[i]*mu[j]*S[i][j]*(roots[i]+roots[j])**2/4 for i in range(4) for j in range(4))
 X=sum(mu[i]*m[i]**2 for i in range(4))
 assert 0<=P<=D; checks+=1
 assert norm-X+P==-L-D+P<=0; checks+=1
 for z in zeta: assert 0<=z<=1; checks+=1
 # Every possible source capture pattern; not just input support.
 for mask in range(16):
  c=[(mask>>i)&1 for i in range(4)]
  T=sum(mu[i]*m[i]*zeta[i]*c[i] for i in range(4))
  cut=sum(mu[i]*mu[j]*w[i][j]*S[i][j]*c[i]*(1-c[j]) for i in range(4) for j in range(4))
  overlap=sum(mu[i]*mu[j]*w[i][j]*S[i][j]*c[i]*c[j] for i in range(4) for j in range(4))
  assert T==cut+overlap and cut>=0 and overlap>=0;checks+=1
print(json.dumps({'status':'PASS','exact_checks':checks,'scope':'finite incidence algebra all capture patterns; no continuum/root conclusion'}))
