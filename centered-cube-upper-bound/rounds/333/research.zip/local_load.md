# R333 — one receiver potential from local coupling loads

**Conditional geometric receipt.** A feasible actual receiver coupling can be certified by two local tests: cube-membership escape and compatibility with actual source-prefix masses. They construct one common receiver potential, including its signed part, and give the full-source estimate (9) below. The tests do not restate the original variance/source defect. Their heterogeneous weighted bill remains a genuine condition; neither existence of a uniformly good coupling nor general root coverage is proved.

## 1. Frozen contract and raw local tests

Use the original hard-matched R331 contract, with the SAME actual `f,E,R,q,U,J,A,ell` and no prefix reset. Let `ν≤f dz`, `W=∫f`, `X_q=∫_E q≤X=λ|E|`, `m_u=q(u)R(u)^n`, `dμ=1_Edu/m_u`, `E_r={u∈E:R(u)≤r}`, `Y_r={J_y(r)≥H}`. Freeze a jointly measurable symmetric row-subcapacity kernel

\[
 S_r(u,v)\ge0,\qquad a_r(u)=\int_{E_r}S_r(u,v)d\mu(v)\le m_u. \tag{1}
\]

All assertions below include `ell`'s `b` atom and the actual physical-radius atoms. Use `θ≡1`, independent of `r`, in R331:

\[
 h(r,u,v)=\tfrac12\sqrt{S_r(u,v)}(\sqrt{m_u}+\sqrt{m_v}),
\]
\[
 L_1=\int\ell\int_{E_r}m_u(m_u-a_r(u))d\mu(u),\quad
 D_1=\tfrac14\int d\xi\,S_r(u,v)(\sqrt{m_u}-\sqrt{m_v})^2,
\]

where `dξ=ell(dr)1_(u,v∈E_r)dμ(u)dμ(v)`. The exact old budget identity is `||h||²−X_q=−L_1−D_1`.

Choose measurable nonnegative local bounds `η_u(r)` and `δ_u(r)`. Require, for `ell(dr)dμ(u)f(y)dy`-almost every tuple with `u∈E_r`, `y∈Q_u∩Y_r`,

\[
 \int_{E_r}S_r(u,v)[1-c_v(y)]d\mu(v)\le\eta_u(r)m_u.           \tag{2}
\]

For almost every further captured `v∈E_r` with `c_v(y)=1`, require

\[
 \left|1-\sqrt{\frac{J_y(r)S_r(u,v)}{m_u}}\right|
                  \le\delta_u(r).                            \tag{3}
\]

These tests apply to ALL captured pairs, including pairs with `S=0`; those pairs force the corresponding bound in (3) to be at least one. Deleting them would invalidate the test. Low-`J` sources are not required to satisfy (2)–(3).

The target here is the ACTUAL source `f`. If these tests hold only `f dy`-almost everywhere, no assertion for another feasible source is made. If they hold Lebesgue-almost everywhere, the same certificate works on the full frozen common-source cone. No source-density bound is assumed.

## 2. Explicit common potential and its actual heterogeneous bill

Put `w_u(r)=η_u(r)+δ_u(r)²`. Define ONE receiver function by integrating prefixes before billing:

\[
 \zeta_{\rm slack}(u)=\frac{R(u)^n}{m_u}
           \int_{[R(u),b]}[m_u-a_r(u)]\ell(dr),
\]
\[
 \zeta_{\rm load}(u)=R(u)^n\int_{[R(u),b]}w_u(r)\ell(dr),\quad
 \zeta=\zeta_{\rm slack}+\zeta_{\rm load},\quad\psi=-1+\zeta.  \tag{4}
\]

Thus `0≤ζ_slack≤1`. The exact extra load is

\[
 \mathfrak B=\int\ell(dr)\int_{E_r}m_u w_u(r)du
             =\int_E q(u)\zeta_{\rm load}(u)du.                \tag{5}
\]

Assume this actual nonnegative integral is finite. Then `ζ,ψ∈L¹(E)`, because `q≥q_->0` and `E` is finite. Positive Fubini is used only separately for the nonnegative terms in (4), and gives

\[
 \int_Eq\zeta=L_1+\mathfrak B,\qquad
 \|h\|^2+\int_Eq\psi=\mathfrak B-D_1.                        \tag{6}
\]

The signed potential is handled by absolute Fubini: `∫f T*|ψ|=∫_E|ψ|q<∞`. There is no positive-Fubini manipulation of a conditionally integrable signed expression.

## 3. Source inequality and full-slot price

Write the R331 positive decomposition as `e_S=slack+cut` and its square-fit term as `R_S,1`. At a high source, (2) bounds the cut by `∫c_u m_uη_u dμ(u)`. For the fit term, (3) gives

\[
 \int c_u(y)c_v(y)
 [\sqrt{m_u/J_y}-\sqrt{S_r(u,v)}]^2d\mu(v)
 \le c_u(y)\frac{m_u\delta_u^2}{J_y}\int c_v(y)d\mu(v)
 =c_u(y)m_u\delta_u^2.
\]

Consequently the high-source integral of `e_S+R_S,1` is bounded pointwise by `T*ζ`. At a low positive row, the exact expansion for `θ=1` gives

\[
 0\le e_S(y,r)+R_{S,1}(y,r)
 =2V_y(r)-\frac{2}{\sqrt{J_y(r)}}
    \iint c_u(y)c_v(y)\sqrt{m_uS_r(u,v)}d\mu(u)d\mu(v)
 \le2V_y(r).                                                 \tag{7}
\]

Zero rows contribute zero. With the original `l_H(y)=∫ell1_(J<H)V_y≤λH`, the R331 source-risk identity therefore proves, on the actual source,

\[
 d(y):=\int\ell(e_S+R_{S,1})-l_H(y)
              \le T^*\zeta(y)+l_H(y).                        \tag{8}
\]

Combining (6), the Hilbert tangent inequality, and the original all-row completion yields the more precise receipt

\[
 B_H(f,\nu)\le B_H(f,f)
 \le\mathfrak B-D_1+2\int f(y)l_H(y)dy
 \le\boxed{\mathfrak B-D_1+2\lambda H W}.                    \tag{9}
\]

One can retain the additional nonnegative reciprocal-clock credit and the difference between `∫fl_H` and the actual low-row square in this derivation; they have only been discarded in (9). No paid chronological-history terms or separate innovations are added to this full-slot estimate.

The main sufficient budget is genuinely heterogeneous:

\[
 \mathfrak B-D_1\le\varepsilon X_q+C\sqrt{A_n}\log^p(n+2)W.   \tag{10}
\]

It concerns explicit receiver loads and edge energy, not the desired source variance itself. If it is certified and `λH≤C_H√A_n log^p(n+2)`, then (9) gives the stated receiver-small plus root-source branch, with coefficient `C+2C_H`. It is not asserted that all actual fields satisfy (10).

## 4. Geometric ways to certify the tests and load

The cut test has a direct source-overlap interpretation. For each `(r,u)`, call a neighbor `v` sure-covering if

`∫f(y)c_u(y)1_(J_y(r)≥H)[1−c_v(y)]dy=0`.

If the total `S_r(u,v)dμ(v)` mass of all OTHER neighbors is at most `η_u m_u`, then (2) holds. This uses real source mass and actual cube containment on the high-source region; thin volume alone does not certify it.

For (3), take certified essential lower and upper values `j^-_(ruv),j^+_(ruv)` of the ORIGINAL `J_y(r)` on `Q_u∩Q_v∩Y_r`, with respect to `f(y)dy`. Empty intersections impose no test. Since `j≥H>0`, it suffices that

\[
 \max\{|1-\sqrt{j^-S_r(u,v)/m_u}|,
         |1-\sqrt{j^+S_r(u,v)/m_u}|\}\le\delta_u(r).           \tag{11}
\]

The endpoint check is valid because `|1−√(jS/m_u)|` attains its maximum over an interval at an endpoint. Source-cell lower/upper enclosures can certify (11); an average `J` cannot replace either enclosure. These cut and reciprocal-range tests can be checked without evaluating the original integrated variance or the source-risk `d`.

For bookkeeping, define the tail-averaged actual receiver load

\[
 \bar w(u)=R(u)^n\int_{[R(u),b]}w_u(r)\ell(dr).
\]

Then `Bload=∫q barw`. Large loads on a small receiver set are charged, not omitted. For example, if a SINGLE measurable partition `E=E_good⊔E_bad` satisfies `barw≤ε/2` on good receivers, `barw≤L` on bad receivers, and `∫_(Ebad)q≤εX_q/(2L)` with `L>0`, then `Bload≤εX_q`; (9) is paid, retaining `−D_1`. More generally use the actual integral (5) and the credit in (10). This is a q-weighted receiver condition, not a source-density or small-source-volume assumption.

The uniform condition `η_u(r)+δ_u(r)²≤ε` is only a strong corollary: the inclusive tail gives `barw≤ε` and hence `Bload≤εX_q`, with NO `A_n` or number-of-prefixes multiplier. Existence of such a coupling/test for arbitrary original geometry is unproved. The nontrivial remaining work is to construct `S` whose simultaneous cut and reciprocal-range loads have the budget (10); feasibility of a coupling alone does not ensure this.

## 5. Local computation and finite scope

A built-in Python `decimal` run at 70 digits passed **150** finite-incidence algebra diagnostics: exact-budget identities, construction of the common potential, and (9), for 30 cumulative fields with a scaled feasible Gibbs coupling. It used the true worst source-site bounds in (2)–(3), including zero coupling edges. Tolerance was `10^-57`. These are not interval certificates, literal-cube fixtures, or evidence that (10) holds generally. The analytic result is independent of them. Reproduction:

```python
from decimal import Decimal as D,getcontext
getcontext().prec=70; tol=D('1e-57'); checks=0
for case in range(1,31):
    r=[D(1),D(5)/4,D(3)/2,D(2)]
    g=[D(1+(case+y)%4)/7 for y in range(4)]
    c=[[1,int((case+u)%2==0),int((case+2*u)%3!=0),1] for u in range(4)]
    mu=[D(1+(case+u)%5)/9 for u in range(4)]
    m=[sum(g[y]*c[u][y] for y in range(4)) for u in range(4)]
    H=D(2+case%5)/8; alpha=D(1+case%3)/3
    X=sum(mu[u]*m[u]**2/r[u] for u in range(4))
    BH=LH=load=slack=edge=hnorm=D(0); zs=[D(0)]*4; zl=[D(0)]*4
    for k in range(4):
        ell=1/r[k]-(1/r[k+1] if k<3 else 0)
        J=[sum(mu[u]*c[u][y] for u in range(k+1)) for y in range(4)]
        A=[[sum(mu[u]*c[u][y]*c[u][z] for u in range(k+1))
            for z in range(4)] for y in range(4)]
        S=[[alpha*sum(g[y]*c[u][y]*c[v][y]/J[y]
                     for y in range(4) if J[y])
            for v in range(k+1)] for u in range(k+1)]
        for y in range(4):
            V=sum(mu[u]*m[u]*c[u][y] for u in range(k+1))
            if J[y]>=H:
                BH+=ell*g[y]*sum(g[z]*(A[y][z]-A[y][z]**2/J[y])
                                for z in range(4))
            else: LH+=ell*g[y]*V
        for u in range(k+1):
            au=sum(mu[v]*S[u][v] for v in range(k+1))
            eta=delta2=D(0)
            for y in range(4):
                if not c[u][y] or J[y]<H: continue
                eta=max(eta,sum(mu[v]*S[u][v]*(1-c[v][y])
                                for v in range(k+1))/m[u])
                for v in range(k+1):
                    if c[v][y]:
                        delta2=max(delta2,(1-(J[y]*S[u][v]/m[u]).sqrt())**2)
            load+=ell*mu[u]*m[u]**2*(eta+delta2)
            slack+=ell*mu[u]*m[u]*(m[u]-au)
            zs[u]+=r[u]/m[u]*ell*(m[u]-au)
            zl[u]+=r[u]*ell*(eta+delta2)
            for v in range(k+1):
                edge+=ell*mu[u]*mu[v]*S[u][v]*(m[u].sqrt()-m[v].sqrt())**2/4
                hnorm+=ell*mu[u]*mu[v]*S[u][v]*(m[u].sqrt()+m[v].sqrt())**2/4
    assert abs(hnorm-X+slack+edge)<=tol; checks+=1
    charge=sum(mu[u]*m[u]**2/r[u]*(zs[u]+zl[u]) for u in range(4))
    assert abs(charge-slack-load)<=tol; checks+=1
    signed=sum(mu[u]*m[u]**2/r[u]*(-1+zs[u]+zl[u]) for u in range(4))
    assert abs(hnorm+signed-load+edge)<=tol; checks+=1
    assert BH<=load-edge+2*LH+tol; checks+=1
    assert BH>=-tol; checks+=1
print('PASS',checks)
```

Only `/tmp/r333_aux.md` is authored; no other research file or Git state is changed.
