# R333 — a common receiver potential pays an oriented true-source cut

**Proved paid branch; general root estimate remains open.** For every symmetric actual-receiver row-subcapacity kernel in R331, an explicit common receiver potential pays a dimension-free fraction of one orientation of its cube-membership cut. The fraction is one once the actual captured-mass ratio is at least `(1+√2)²`. Payment uses that kernel's existing Dirichlet credit, preserves an additional common-capture credit, and adds no new `X` or source-mass fee. The opposite orientation, the remaining near-equal-mass cut, and the fit error are not paid here. This is a branch of the rigorous full-square source-defect receipt, not a general root bound on the original `B_H`.

## 1. Original contract and credit available

Keep the original hard-matched `β=f dx`, `ν≤f dx`, `Tf=q`, `q∈[3λ/4,λ]`, `a≤R≤b≤2a`, and finite actual receiver set `E`. Write

\[
 m_u=q(u)R(u)^n,\quad d\mu(u)=1_E(u)du/m_u,\quad
 E_r=E\cap\{R\le r\},\quad c_u(y)=1_{Q_{R(u)}(u)}(y).
\]

All original prefixes `J_y(r),A_yz(r)` and the full Stieltjes measure
`ell=b^{-n}δ_b+nr^{-n-1}1_[a,b]dr` remain intact. In particular, this construction does not remove previously paid blocks. Let

\[
 d\xi=\ell(dr)1_{u,v\in E_r}d\mu(u)d\mu(v),\qquad
 S_r(u,v)=S_r(v,u)\ge0,
 \quad a_r(u):=\int_{E_r}S_r(u,v)d\mu(v)\le m_u.                \tag{1}
\]

This includes the explicit R332 recoupling `S⁺`, for which the capacity is saturated. Use `θ=1` and the associated reference

\[
 h(r,u,v)=\frac{\sqrt{S_r(u,v)}}2(\sqrt{m_u}+\sqrt{m_v}).
\]

R331's exact identity supplies

\[
 \|h\|_2^2-\int_Eq=-L-D,\quad
 L=\int\ell(dr)\int_{E_r}m_u[m_u-a_r(u)]d\mu(u)\ge0,
\]
\[
 D=\frac14\int d\xi\,S_r(u,v)(\sqrt{m_u}-\sqrt{m_v})^2\ge0.    \tag{2}
\]

These are existing credits, not new positive error allowances. For `S⁺`, `L=0` and `D=D⁺`.

## 2. Explicit common potential and its exact bill

Orient each unequal-mass pair from the smaller actual cube mass to the larger one. Put

\[
 \Omega=\{(u,v):m_v>m_u\},\quad \rho_{uv}=m_v/m_u,\qquad
 w(\rho)=\min\{1,(\sqrt\rho-1)^2/2\}\quad(\rho>1).
\]

Define a single measurable potential on the original receivers by

\[
 \boxed{\quad
 \zeta_w(u)=\frac1{q(u)}\int_{[R(u),b]}\ell(dr)
       \int_{\substack{v\in E_r\\m_v>m_u}}
                 w(m_v/m_u)S_r(u,v)d\mu(v).
 \quad}                                                        \tag{3}
\]

No source point is chosen in (3). The same potential serves all source positions and every prefix. Positivity, the actual row capacity, and the inclusive original tail give

\[
 0\le\zeta_w(u)\le\frac{m_u}{q(u)}\ell([R(u),b])=1.            \tag{4}
\]

In particular, `ζ_w∈L¹(E)`. Its exact receiver bill is

\[
 P_w:=\int_E\zeta_w(u)q(u)du
     =\int_{\Omega}d\xi\,S_r(u,v)m_u w(\rho_{uv}).             \tag{5}
\]

Symmetry, with equal-mass pairs contributing zero, also gives

\[
 D=\frac12\int_{\Omega}d\xi\,S_r(u,v)m_u(\sqrt{\rho_{uv}}-1)^2.
\]

Therefore

\[
 \boxed{\quad P_w\le D,\qquad
 D-P_w=\int_{\Omega}d\xi\,S_r(u,v)m_u
          \left[\frac{(\sqrt\rho-1)^2}{2}-w(\rho)\right]\ge0.
 \quad}                                                        \tag{6}
\]

The JOINT signed potential is now `ψ=−1_E+ζ_w`, so `−1≤ψ≤0` and

\[
 \boxed{\quad\|h\|_2^2+\int_E\psi q=-L-(D-P_w)\le0.\quad}     \tag{7}
\]

Thus this is a genuine common-receiver construction within the requested budget, not an average source deficit renamed as a receiver function. All integrals are justified by positive Fubini and (4)–(6); no regularity of the selector or source-density cap is used.

## 3. What is paid pointwise, and the extra overlap credit

Define the actual oriented cut and common-capture profiles

\[
 \Gamma_w(y)=\int_{\Omega}d\xi\,w(\rho)S_r(u,v)c_u(y)[1-c_v(y)],
\]
\[
 O_w(y)=\int_{\Omega}d\xi\,w(\rho)S_r(u,v)c_u(y)c_v(y)\ge0.
\]

Direct Fubini in (3), using `q(u)R(u)^n=m_u`, proves the exact identity

\[
 \boxed{\qquad T^*\zeta_w(y)=\Gamma_w(y)+O_w(y).\qquad}         \tag{8}
\]

Consequently the common potential pays `Γ_w` pointwise and retains `O_w` as an additional favorable term. The paid orientation is: the smaller-`m` actual cube captures the source, while the larger-`m` cube misses it. It is not a symmetric pair payment.

Let the complete cut profile of `S` be

\[
 C_S(y)=\frac12\int d\xi\,S_r(u,v)[c_u(y)-c_v(y)]^2.
\]

Then `0≤Γ_w≤C_S`, and its precise unpaid complement is

\[
 C_S-\Gamma_w
 =\int_{\Omega}d\xi\,S_r(u,v)
   \bigl[(1-w)c_u(y)(1-c_v(y))+c_v(y)(1-c_u(y))\bigr]
 +\frac12\int_{m_u=m_v}d\xi\,S_r(u,v)[c_u(y)-c_v(y)]^2.         \tag{9}
\]

This retains the full reverse orientation and the equal-mass pairs.

The entire favorable orientation is paid when

\[
 \rho\ge(1+\sqrt2)^2.
\]

For any `K≥(1+√2)²`, write `D_K` for the portion of the COMPLETE Dirichlet credit on the unordered pairs with mass ratio at least `K`. The part of (5) on those pairs obeys

\[
 P_{w,K}\le\frac{2}{(\sqrt K-1)^2}D_K.                        \tag{10}
\]

In particular, mass ratio at least `9` is fully covered in the stated orientation while spending at most half of those edges' credit. This is part of the single allocation (3), not an additional receipt to add a second time.

All dimension dependence remains explicit in `m=qR^n` and `ell`. Under the original `q` band,

\[
 \frac34(R(v)/R(u))^n\le m_v/m_u\le\frac43(R(v)/R(u))^n.
\]

Thus a paid mass ratio `K` implies the actual radius ratio is at least `(3K/4)^{1/n}`, while radius ratio at least `(4K/3)^{1/n}` suffices. No replacement of the actual ratio or original prefixes by this comparison is made. A branch may be empty for some dimensions or inputs.

## 4. Full-square ledger and exact remaining task

Use R331's notation, with

\[
 L_S(y)=\int\ell(dr)\int_{E_r}c_u(y)[m_u-a_r(u)]d\mu(u),
\]

and `R_fit(y)=∫ell R_(S,1)(y,r)`, where the latter is the genuine nonnegative square-fit term in R331 (6). Its exact source defect before (3) was

\[
 d_S(y)=a_H(y)+T^*1_E(y)-2\langle h,\varphi_y\rangle
       =L_S(y)+C_S(y)+R_{\rm fit}(y)-l_H(y).
\]

After the common potential, it is exactly

\[
 \boxed{\quad
 d_S(y)-T^*\zeta_w(y)
 =L_S(y)+(C_S(y)-\Gamma_w(y))+R_{\rm fit}(y)-l_H(y)-O_w(y).
 \quad}                                                        \tag{11}
\]

For `S=S⁺`, the row-slack term `L_S` vanishes. Nothing in (11) discards the reverse cut, the fit error, or the common-capture credit. The remaining scalar credit is `L+D−P_w`, not the old `L+D` again.

More explicitly, if the right side of (11) is bounded by `c+T*η` pointwise for a further signed `η∈L¹(E)`, with

\[
 \int_E\eta q\le L+D-P_w+\varepsilon X,                       \tag{12}
\]

then the single final potential `ψ=−1_E+ζ_w+η` proves

\[
 B_H(f,\nu)\le B_H(f,f)\le\varepsilon X+(c+\lambda H)W_f.       \tag{13}
\]

No general root `c` or `η` satisfying (11)–(12) is proved here. The source price `λH W_f` is exactly the preexisting all-row completion fee; this allocation adds zero new source fee and zero new `εX` loss. If an outer ledger multiplies this full `B_H` slot by a factor, it must multiply the complete residual and credits as well. Previously paid crossing or large-atom receipts must not be added to this alternative full-slot bound.

This is a generally valid paid oriented sub-integral of the full-square defect. It does not establish a uniform positive fraction of the entire defect: the mass distribution may be nearly balanced, the opposite orientation may dominate, or the fit error may remain large. Those are the specific unpaid components, not an inferred failure of the full target.

## 5. Verification and bounded delivery

A local exact `Fraction` run passed 228 assertions for the common-potential identity, `0≤ζ≤1`, the credit bill, and the cut/overlap decomposition across finite prefix fields. The test used all 16 binary source-incidence patterns on four receivers. It is an algebra verification, not a literal-cube realization or root evidence; the proof above is analytical.

Only `/tmp/r333_core.md` is authored. No Git or other agent's file is changed. The bounded delivery is the explicit potential (3), the payment (6)–(8), and the complete unpaid ledger (9), (11)–(12); the general root target remains open.
