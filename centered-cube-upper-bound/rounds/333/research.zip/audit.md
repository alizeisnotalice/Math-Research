# R333 independent preauthor screen — a certified common receiver potential

Ownership only /tmp/r333_audit.md; no Git/other-author edits. No R333 author proof/code has been read. Freeze the actual HARD shared field and same feasible common-source class Tg=q, U,J,A,H and all physical clocks. Use the completed full-feature map Phi_all, finite E, q_->0 and q<=lambda. Original nu<=f only permits the positive upper bound BH(f,nu)<=BH(f,f), not arbitrary unequal-source symmetry.

## 1. Exact conditional continuum certificate

Let h>=0 be one FIXED finite-L2 real feature reference; it may be constructed from actual f but is not recomputed independently for each competing source. Set X_q=integral_E q, credit=X_q-||h||², and

 d_h(y)=a_H(y)+T*1_E(y)-2<h,phi_all,y>.

If ONE common signed zeta in L1(E) and c>=0 satisfy d_h<=c+T*zeta on a common Lebesgue-full source set, with integral zeta q<=credit+epsilon X, then psi=-1_E+zeta is integrable and

 ||h||²+integral psi q<=epsilon X.

Absolute Fubini follows from integral g T*|psi|=integral_E |psi|q<=lambda||psi||1 for every feasible g. The full-completion Hilbert tangent gives BH(g,g)<=epsilon X+(c+lambda H)||g||1. The lambda H COMPLETION SOURCE BILL occurs once; it cannot be dropped by citing a different high-only certificate or added again to crossing/large-atom alternatives on the same slot. H is unchanged. Finite credit may be negative; zeta is signed and the displayed budget remains the relevant condition. A pointwise bound only on sampled sources is insufficient. No certificate/LP optimality, strong duality or root c is supplied by this algebra alone.

## 2. Finite actual-cube receiver quadrature and source-face cells

For finite receivers with actual radii R_i, positive receiver quadrature weights w_i and actual q_i, the potential is T*zeta(y)=sum_i w_i R_i^(-n)zeta_i c_i(y), while its receiver bill is sum_i w_i q_i zeta_i. These two coefficient systems are DIFFERENT; no missing q or volume factor is allowed. The feature measure uses mu_i=w_i/(q_iR_i^n) and all original grouped physical prefixes/ell tails. The model is finite receiver quadrature, not Lebesgue dx or an automatic original history/lowpe entrance.

An axis partition at ALL cube faces makes every incidence, prefix J and a_H constant on each positive-volume source cell. It must include ALL capture-pattern cells, even where actual f vanishes, to certify the statement for every feasible L1 source g; certifying only f-positive cells would justify only that fixed f. Outside the union of ALL receiver cubes, c_i=0, J=A=a_H=T*1=feature0, so d_h0 and c>=0 certifies the infinite complement. If cubes extend beyond a displayed source support box, the missing face cells must be added. No source mass sampling substitutes for these cellwise constraints.

For nonnegative EXACT selected h, a rational LOWER bound on1/sqrt(J) produces an UPPER d_h: all feature coefficients and incidence factors are nonnegative and are subtracted. Zero-J feature terms are assigned0, never divided. h and its norm/credit must refer to the SAME selected reference. Mixing a lower approximation for coverage with an unrelated favorable norm/credit is invalid unless all intervals are certified in the needed directions. h>=0 is essential for this one-sided simple bound; signed h requires sign-specific interval treatment.

## 3. Rational common-potential repair

Let a floating LP candidate be converted to finite rational zeta_i. With target B=credit+epsilon X and X_q=sum w_iq_i>0, compute exact bill Z=sum w_iq_i zeta_i and delta=max(0,(Z-B)/X_q). Replace EVERY receiver value by zeta_i'=zeta_i-delta. This signed uniform shift gives bill<=B exactly. It changes source potential by- delta T*1, so the ORIGINAL c must not be reused without checking the new residual.

Set c'=max(0,max_ALL_facecells[d_h^upper-T*zeta']). Then d_h<=c'+T*zeta' on every cell and the infinite no-capture complement. Finite cells with very small/zero actual f remain required for the common-source certificate. This is an exact FEASIBILITY upper certificate, not a proof the floating LP is optimal or the repaired value equals its objective. The repair can substantially increase c. In the degenerate X_q0 case, q_->0 forces all receiver weights0; choose the zero field/h/potential/c directly instead of dividing by0. Finite positive-weight models have X_q>0.

## 4. Actual independent bounded algebra checks

Reviewer executed1020 exact Fraction assertions: {'budget': 60, 'cell_cover': 480, 'uniform_shift': 480}. Sixty signed rational potential/budget fixtures include all eight binary capture patterns, including the zero pattern, and positive receiver weights/q. These validate repair algebra only, not actual cubes/continuous selectors, pointwise irrational feature enclosures, LP optimality or a root certificate. No author proof/code was read before this screen.

Initial verdict PASS under the fixed-common-field, all-source-cell, one-sided-reference consistency and degenerate-case qualifications above. Await authors.

## 5. Independent screen of mass-directed cut settlement

Freeze the R331 symmetric nonnegative row-subcapacity S_r on actual prefix pairs, theta=1, m_u=qR^n, original dmu=du/m_u and full ell. On the ordered region m_v>m_u define rho=m_v/m_u and w=min(1,(sqrt(rho)-1)^2/2), and set w0 on ties/other orientation. Define the COMMON receiver potential

 zeta_w(u)=q(u)^(-1) integral_[R(u),b] ell(dr) integral_(v in E_r,m_v>m_u) w S_r(u,v)dmu(v).

It is measurable and0<=zeta_w<=1: row subcapacity bounds its inner integral by m_u, and the inclusive ell tail gives m_u R(u)^(-n)/q(u)=1. Finite E then supplies L1 integrability. No new receiver or enlarged-radius cap is evaluated.

The actual potential bill is P=integral zeta_w q=integral ell integral_(m_v>m_u)m_u w S dmu_udmu_v. By symmetry, the original edge-energy credit is D=1/2 integral ell integral_(m_v>m_u)m_u(sqrt(rho)-1)^2 S dmu_udmu_v; equal-mass pairs contribute0. Hence P<=D with EXACTLY this factor1/2. A missing symmetry factor would invalidate the settlement.

The actual adjoint potential is T*zeta_w(y)=integral ell ordered wS c_u(y)=Gamma_w(y)+O_w(y), where Gamma_w has c_u(1-c_v) and O_w has c_uc_v. The orientation is SMALL-mass u CAPTURED, large-mass v MISSED, not the reverse. Gamma_w is a positive subcomponent of the full symmetric membership cut Gamma=1/2 integral ell S(c_u-c_v)^2; strict mass ties and the opposite direction remain. For rho>=(1+sqrt(2))², w1 and that entire directed cut is settled; near-mass ratios have a fractional settlement.

With psi=-1+zeta_w the original bill becomes-L-D+P<=0. The corresponding pointwise source defect is EXACTLY sourceSlack+(Gamma-Gamma_w)+fit-l_H-O_w. This is a legal settlement of a positive cut component of the AUXILIARY source-defect functional by its SAME edge-energy credit, not an independently disjoint allocation of all original traffic. The residual available credit is L+(D-P), not the whole old L+D. No second price/gain may reuse P or O_w. Full-feature application still carries the completion source fee lambda H W once; high-only alternatives need their own proof. Fit, reverse/tie cuts and the remaining pointwise/source/entry obligations are unpriced. Original nu<=f, hard symmetry and full J/A/physical atoms remain required; no general-soft migration or total root certificate follows.

Reviewer additionally executed60 exact rational directed-cut assertions: {'potential_bound': 10, 'edge_budget': 10, 'directed_decomposition': 40}. Fourth-power masses from rational physical radii give explicit rational square roots; all source-incidence directions are checked algebraically. These are finite budget/identity diagnostics, not a literal original history or a quantitative fit/root estimate.

## 6. Auxiliary local-test common-potential proof

Read /tmp/r333_aux.md in full. PASS for its conditional actual-source theorem. The raw high-source escape test and reciprocal-fit test are simultaneous under the stated ell*dmu*fdy and captured-pair measures; ZERO S edges are included, requiring delta>=1 there. These tests only fdy-a.e. yield a theorem for actual f, not every competing feasible g; the text correctly requires Lebesgue-a.e. versions for the full common-source cone. The test is not a variance restatement, but its heterogeneous receiver-load budget remains unproved in general.

At high sources the membership cut is bounded by integral captured eta m dmu. The full fit square equals m_u/J times the tested squared mismatch, so its captured v integral cancels the ORIGINAL J and yields delta_u²m_u. At low sources the exact theta1 expansion gives0<=e+R<=2V, without assuming a small low subset. The potential coefficients R^n/m and R^n are correct: q-bill of slack isL1, and q-bill of the load is Bload=integral ell m_u(eta+delta²)du. Finite actual Bload plus q_->0 gives integrable signed psi.

Norm+psi bill=Bload-D1; the defect bound is d<=T*zeta+l_H. Applying the FULL completion then gives BH(f,nu)<=Bload-D1+2integral f l_H, hence2lambda H W. Both low contributions are accounted, not an accidental double charge: one is the generic completion bound and the other the explicitly bounded remaining low-clock defect. This differs from the particular high-only reference that avoids completion and must not be conflated with it. Endpoint/zero rows, original full prefixes and exact clock tail are retained. The source domination nu<=f only enlarges the positive full slot.

Sure-cover neighbors are certified by actual f high-source mass, not thin volume; reciprocal tests use essential J endpoint enclosures, including their actual high region. Tail-averaged receiver loads may be large on small sets only with actual q-weighted budget. Uniform eta+delta²<=epsilon gives Bload<=epsilon X_q with no extraAn; its existence for arbitrary original geometry is not asserted. The general conditional load inequality(10) is not already proved globally.

Author150 Decimal70/tolerance1e-57 cases are finite-incidence algebra diagnostics; no exact/interval/cube/root status is attached. The reviewer read code but did not replay the full run.

Auxiliary SHA256: 7582f2f7633a6dea5c5f56317a236bf7e5fbf3402285f98fe76399a5376e23b4

## 7. Final mass-directed core comparison

Read /tmp/r333_core.md in full after independent section5 screen. PASS. The potential is common on original receivers, integrates the SAME prefix-dependent S before billing, and has0<=zeta<=1 from actual row subcapacity and the inclusive R^-n tail. Ordered-mass P_w and the factor1/2 in D are exact; ties spend no edge credit. The nonnegative remaining D-P_w is displayed explicitly. psi=-1+zeta has bill-L-(D-P_w)<=0, with no extra source or positive-X loss beyond the preexisting full completion.

The source adjoint is exactly Gamma_w+O_w. The paid orientation is SMALL actual m captured and LARGE m missed, with no interchange to radius order or reverse orientation. Formula(9) retains reverse and equal-mass cut in full. w1 above(1+sqrt2)^2 pays that favorable orientation only. The high-ratio refinement P_w,K<=2D_K/(sqrtK-1)^2, including ratio9 half-credit use, is correct for the COMPLETE unordered edge-credit portion. It is one allocation, not a second payment. The q-band implications for actual radius ratios follow in the stated directions and do not change original mass/prefix gates.

Defect formula(11) agrees with the original slack+cut+fit-l_H identity after subtracting the exact adjoint potential. The final signed further-potential budget is L+D-P_w+epsilon X, not full old L+D. The extra overlap credit is retained but cannot be spent twice. Whole-slot application(13) preserves original nu<=f positive domination and the one lambda H Wf completion source fee. S+ saturation removes source slack only, not fit/reverse/tie components. No uniform defect coverage fraction or root c/furtherpotential is proved. This is correctly a paid positive component of the AUXILIARY rigorous full-square defect, not a separate all-traffic bound or a claim that other slots are settled.

Author228 Fraction cases are finite-incidence algebra diagnostics, not cube/history/root evidence. They are distinct from reviewer60 directed-cut tests and1020 repair tests. No complete author replay by reviewer.

Core SHA256: 081a3af5c583daebef758a799d81052dc483de8075b57feda25a9de863c4d817

Pending final numeric pipeline review: fixed-W reference QP may supply an h candidate but cannot by itself certify optimal source coefficient c or weak-type ratio. Common zeta LP and exact repaired all-cell feasibility must be audited after freeze. No current general root certificate is claimed.

## 8. Final frozen numeric pipeline and result review — PASS

Read complete /tmp/r333_numeric.py, r333_solve.m, r333_solve_qp.m, numeric.md and all relevant checkpoint result records; did NOT rerun the pipeline. PASS within the finite receiver-quadrature scope. Every actual receiver cube is inside Q4, q=lambda1 and captured massR^n. All source face cells (5/64/900, including zero-incidence/J cells) are retained, with true positive volumes rather than source samples. Outside Q4 all incidences and source defects/potentials are0; c>=0 certifies the infinite complement. Boundaries are source-null. Equal physical radii are grouped and the final prefix tail through b is included even when the last selected radius<b.

The exact selected nonnegative h is a rational LOWER reference to Phi_f (or its explicit5/4 multiple), not the rank-one Splus coupling. Arbitrary finite h is allowed by the weak dual, so no false capacity claim is needed. Norm of THAT h and credit X_q-norm are exact. Coverage uses the SAME h divided by upper sqrt(J), hence a rigorous lower feature pairing and upper defect. The isqrt rational enclosure directions are correct; positive J in these specific models is at least1/80, so all lower sqrt denominators used for objective upper-norm bounds are strictly positive. H0 is an all-row diagnostic with zero completion fee; positiveH keeps its actual mandatoryH W fee. No sqrt/solver float decides final feasibility.

MATLAB LP signs and coefficients are correct: -c-Tzeta<=-d, signed zeta, c>=0, budget sum w zeta<=credit because actualq1. Its floating outputs are only candidates. Python rationalizes each zeta, uniformly subtracts any budget excess divided by sumw, and recomputes c as the maximum over EVERY source cell after that shift. Exact postrepair checks enforce the common budget, all pointwise upper-defect constraints, integrated source identity and original one-sided square/completion. Negative credit is handled with signed zeta. Nothing assumes the floating LP objective or residuals are exact/optimal. The staged MATLAB scripts reset only their task-local result structs and preserve the user workspace.

The fixed-W QP uses the FULL normalized Gram feature matrix (not a high-only square) and high-linear aH. quadprog(2K,-aH) supplies a source REFERENCE candidate for maximizing aH*x-xKx with x>=0,Cx=m,sumx=W. This is neither optimal weak ratio nor minimal zero-X-budget c; no continuum/global/solver optimum is inferred. Signature merging is exact because all original prefixes/features are constant on a complete incidence signature; the zero signature remains. QP matrix is a floating Gram, with no claim of exact optimization.

Source repair is mathematically correct: rationalize/clamp the candidate, perform full exact RREF on A*delta=b-A*x with all receiver means AND total-mass row, choose pivot corrections with free corrections0, then mix with the strictly positive ORIGINAL group-mass vector just enough to remove negatives. Both affine constraints survive exact mixing. The baseline is feasible; all grouped original masses are positive. Source distributions proportional to original cell volumes produce actual compact nonnegative L1 functions, keeping selected receiver means/q exactly. Zero new group masses are allowed; strict pointwise positivity is not claimed. Reading the six saved source receipts confirms minx>=0, all exact mean and mass errors0, and mix0 in every case. This check of recorded results was not a repeat optimization/pipeline run.

For these repaired sources, original BH(g,g) is computed EXACTLY using new source intersection masses, original fixed J/A/ell, and the one-sided A²/J square, not the QP relaxed objective. The same mean constraints justify the linear V term. The additional rational h=lowerPhi_x has exact chosen norm/credit; an UPPERPhi_x norm provides a LOWER relaxed-source objective, while the chosen lower norm provides its UPPER objective. Those objective enclosures are not substituted as a favorable unrelated credit. The subsequent six LPs again certify the ORIGINAL full source-space pointwise inequalities, independently of QP optimality. They retain original f source masses when validating the original-f target; the new-source actual costs are separately computed/reported.

Checkpoint outputs contain12 initialLP+6QP+6 furtherLP successful candidates (all recorded exitflag1); solver flags themselves are not proof. Two exact verifiers record3924+90=4014 counted postrepair checks. Source preparation/RREF feasibility assertions are additional uncounted checks, not falsely added to the declared total. Primary1320 exact directed-cut algebra checks were also read: all16 incidence patterns, true factor/orientation and budget identities, finite algebra scope only. Thus declared primary5334=4014+1320 is correct. Reviewer1080=1020 repair+60 directed tests and author228 Fraction/150 ordinary Decimal diagnostics stay separate.

The result table faithfully retains n1 deterioration versus the original reference, n2/3 candidate improvements, actual new-source BH values and positive-H completion0.5/2/8. A near-zero c does not imply a small completed bound. Fixed-W QP objective can be negative while actualBH is positive; completion accounts for this. All comparisons are finite n1/2/3 geometry with receiver QUADRATURE, not continuous dx/history, dimension exponent, new root bound or certified optimizer.

## 9. Final ledger review, verdict and hashes

Read complete /tmp/r333_ledger.md. PASS. It identifies the paid branch as one orientation of the rigorous AUXILIARY full-square source-defect cut, spends P_w from the sameD, keeps common-capture credit and remaining L+D-P_w, and retains reverse/tie/fit components. The auxiliary heterogeneous-load theorem is an alternative whole-slot receipt and cannot reuse the sameD alongside the directed settlement. Source lambda H completion is counted once in its applicable whole-slot bound; the auxiliary2L_H has its two distinct derivation terms. Whole-slot alternatives do not add R327/R328 crossing/large-atom fees again. All target/recovery/outer factors and original missing epsilon/entry/time/general-soft/aspect/lowpe/global obligations remain. No general source certificate or root closure is asserted.

Final bounded verdict: PASS for the source proofs, exact repaired finite certificate pipeline, actual saved results and stated total-ledger scope. No correction remains. No new full run or research expansion was made. Later parent TeX/archive packaging is outside this proof/code receipt.

Frozen SHA256 bindings:

- /tmp/r333_aux.md — 7582f2f7633a6dea5c5f56317a236bf7e5fbf3402285f98fe76399a5376e23b4
- /tmp/r333_core.md — 081a3af5c583daebef758a799d81052dc483de8075b57feda25a9de863c4d817
- /tmp/r333_ledger.md — 6fd9bfa8089d2acb89a6e8bd5f9a67ff8444dc5714a1e5f19cc0722f1f249d02
- /tmp/r333_numeric.py — d46cc61b9f656b9337fbaf28a92fc18a0ef1ddcdfb62cb726cbc59708f74392d
- /tmp/r333_solve.m — 224570911c7c3d394e3ffa9616a242553c83bcc911001a6b52f92ac6acb9dddc
- /tmp/r333_solve_qp.m — 7970cd6829c6a639fce1d72b6062de47073cd9ff5fd6c4990663b22807626e7e
- /tmp/r333_numeric.md — 608db634c7e69904d2251d18fd87ee81e9c360be2b1c89d5b301ed710e8187b9
- /tmp/r333_checks.py — fc5ba8dfd10dc62d937d9e72f33d82f8ffd8b157088d75180b417cdb1a5f42ab
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint/r333_data.json — c239de7cefe0ddcede2a44477c7d1704427d1ebce60f8e2701215fa798f1b40a
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint/r333_data_qp.json — 82b86a3d02fdb82747bfb04432c352044d7a021457b239a2d798ef489b60abb8
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint/r333_data_qp_lp.json — 5fb03dd5fde2344d96ee2607ab504e72ab8763d28e68734d704533a83420d9a2
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint/r333_numeric.py — d46cc61b9f656b9337fbaf28a92fc18a0ef1ddcdfb62cb726cbc59708f74392d
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint/r333_numeric_qp_verified.json — dde517b6eae99b405972fb6daf1fbc55f053ca30cdd3ae52f4a4f7abddda3fbb
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint/r333_numeric_summary.json — 0161a358e220d4a1e7e58fbad3343c4eece95bd5b78532acaf8e5709d325cd0c
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint/r333_numeric_verified.json — 387abbaf46e3d10551f7db9a7907d502f95279c170bd754f481c16d9914aef58
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint/r333_solve.m — 224570911c7c3d394e3ffa9616a242553c83bcc911001a6b52f92ac6acb9dddc
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint/r333_solve_qp.m — 7970cd6829c6a639fce1d72b6062de47073cd9ff5fd6c4990663b22807626e7e
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint/r333_solve_qp_lp.m — 381573f3ec59b4d6cd11ab1cf173446ca3bddab32afe75e9e1bc2995b9245d9c
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint/r333_solve_qp_lp_results.json — 800bdabb43a5686b1e9b9ef4bc016f934b9461fded1bfb3998e494bd59ced14c
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint/r333_solve_qp_results.json — 5261036eb6d1402692ffb369d197a04b47f4ff58995bebe0e7dfad0d082094a8
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round333_20261018_final_checkpoint/r333_solve_results.json — f6163a51be90d2a49f7630e7886d3c0ff005e8be9117136a2fa004dddaf43c46

Final freeze. Only /tmp/r333_audit.md was edited. No Git, other-author changes, complete pipeline rerun or TeX/PDF compilation. Large data/result hashes bind evidence metadata; their regeneration is governed by the reviewed portable scripts.
