#!/usr/bin/env python3
"""Prepare rational all-source LPs; verify MATLAB candidates after exact repair."""
from fractions import Fraction as F
from itertools import product
from math import isqrt
from pathlib import Path
import json,sys,hashlib,math
BASE=Path(__file__).resolve().parent
DATA=BASE/'r333_data.json';CAND=BASE/'r333_solve_results.json'
def sqrtbox(x,bits=80):
 scale=1<<bits;q=isqrt((x.numerator*scale*scale)//x.denominator);return F(q,scale),F(q+1,scale)
def enc(x):return str(x)
def cells(n,receivers):
 axes=[sorted(set([F(-2),F(2)]+[x[a]+sign*r/2 for x,r,w in receivers for sign in [-1,1]])) for a in range(n)];out=[]
 for ids in product(*[range(len(p)-1) for p in axes]):
  box=[(axes[a][i],axes[a][i+1]) for a,i in enumerate(ids)];mass=F(1)
  for lo,hi in box:mass*=hi-lo
  c=tuple(int(all(lo>=x[a]-r/2 and hi<=x[a]+r/2 for a,(lo,hi) in enumerate(box))) for x,r,w in receivers)
  for v,(x,r,w) in zip(c,receivers):assert v or any(hi<=x[a]-r/2 or lo>=x[a]+r/2 for a,(lo,hi) in enumerate(box))
  out.append((mass,c))
 assert sum(m for m,c in out)==4**n
 return out

def fixture(n,receivers,name):
 source=cells(n,receivers);N=len(receivers);mi=[r**n for x,r,w in receivers];mu=[w/m for (x,r,w),m in zip(receivers,mi)];weights=[w for x,r,w in receivers];X=sum(weights);W=F(4**n)
 for i in range(N):assert sum(m*c[i] for m,c in source)==mi[i]
 radii=sorted(set(r for x,r,w in receivers));ell=[r**(-n)-(radii[k+1]**(-n) if k+1<len(radii) else 0) for k,r in enumerate(radii)]
 prefixes=[];Eall=F(0)
 for radius,weight in zip(radii,ell):
  active=[i for i,(x,r,w) in enumerate(receivers) if r<=radius];J=[sum(mu[i]*c[i] for i in active) for mass,c in source];V=[sum(weights[i]*c[i] for i in active) for mass,c in source];I={(i,j):sum(m*c[i]*c[j] for m,c in source) for i in active for j in active};Glo={(i,j):sum((m*c[i]*c[j]/sqrtbox(jy)[1] for (m,c),jy in zip(source,J) if jy),F(0)) for i in active for j in active};SG={(i,j):sum((m*c[i]*c[j]/jy for (m,c),jy in zip(source,J) if jy),F(0)) for i in active for j in active}
  row_square=[sum(mu[i]*mu[j]*c[i]*c[j]*I[i,j] for i in active for j in active)/jy if jy else F(0) for (m,c),jy in zip(source,J)]
  Eall+=weight*sum(m*s for (m,c),s in zip(source,row_square))
  prefixes.append((weight,active,J,V,Glo,row_square))
 cases=[]
 for H in [F(0),F(1,8)]:
  aH=[sum(weight*v for weight,active,J,V,Glo,squares in prefixes if (jy:=J[k])>=H for v in [V[k]]) for k in range(len(source))]
  T1=[sum(mu[i]*c[i] for i in range(N)) for mass,c in source]
  BH=sum(weight*sum(m*(v-s) for (m,c),jy,v,s in zip(source,J,V,squares) if jy>=H) for weight,active,J,V,Glo,squares in prefixes)
  assert all(T-a<=H for T,a in zip(T1,aH))
  for factor in [F(1),F(5,4)]:
   # Explicit rational h >=0: lower approximation to Phi_f, or its 5/4 multiple.
   norm=F(0);coverage=[F(0)]*len(source)
   for weight,active,J,V,Glo,squares in prefixes:
    h={ij:factor*g for ij,g in Glo.items()}
    norm+=weight*sum(mu[i]*mu[j]*h[i,j]**2 for i in active for j in active)
    for k,((mass,c),jy) in enumerate(zip(source,J)):
     if jy:coverage[k]+=weight*2*sum(mu[i]*mu[j]*c[i]*c[j]*h[i,j]/sqrtbox(jy)[1] for i in active for j in active)
   credit=X-norm;d=[a+t-cov for a,t,cov in zip(aH,T1,coverage)]
   # The exact original one-sided square and all-row completion are retained.
   assert BH<=sum(m*a for (m,c),a in zip(source,aH))-Eall+H*W
   assert BH<=sum(m*v for (m,c),v in zip(source,d))-credit+H*W
   case=dict(id=f'{name}_H{H}_h{factor}',n=n,H=enc(H),reference='G_lower' if factor==1 else 'scaled_G_5over4_lower',W=enc(W),X=enc(X),norm_exact=enc(norm),credit=enc(credit),original_BH=enc(BH),original_Eall=enc(Eall),completion_first=enc(sum(m*a for (m,c),a in zip(source,aH))),weights=list(map(enc,weights)),source=[dict(mass=enc(m),signature=list(c),d_upper=enc(d[k]),T_coeff=[enc(mu[i]*c[i]) for i in range(N)],J_final=enc(T1[k])) for k,(m,c) in enumerate(source)],receiver_scope='actual cubes with finite positive receiver quadrature, not dx/history',receivers=[dict(center=list(map(enc,x)),radius=enc(r),weight=enc(w)) for x,r,w in receivers])
   case['solver_weights']=[float(v) for v in weights];case['solver_credit']=float(credit);case['solver_d']=[float(v) for v in d];case['solver_T']=[[float(mu[i]*c[i]) for i in range(N)] for mass,c in source]
   cases.append(case)
 return cases

def prepare():
 fixtures=[('initial',1,[((F(-1,4),),F(1),F(1,5)),((F(1,4),),F(3,2),F(1,5))]),('stress',2,[((F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(-1,2)),F(1),F(1,10)),((F(1,2),F(1,2)),F(3,2),F(1,5)),((F(0),F(0)),F(2),F(1,10))]),('expanded',3,[((F(-1,2),F(0),F(0)),F(1),F(1,10)),((F(0),F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(0),F(1,2)),F(3,2),F(1,10)),((F(1,2),F(1,2),F(0)),F(3,2),F(1,10)),((F(0),F(0),F(0)),F(2),F(1,10))])]
 cases=[]
 for name,n,recv in fixtures:cases.extend(fixture(n,recv,name))
 DATA.write_text(json.dumps(dict(status='PREPARED',cases=cases,scope='Complete compact-source face cells. Rational d upper, rational h norm and credit. MATLAB candidates require exact Python repair; no LP optimality claim.'),sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(status='PREPARED',cases=len(cases),source_cells_by_stage=[5,64,900],data=str(DATA))))

def verify(data_path=DATA,candidate_path=CAND,output_path=(BASE/'r333_numeric_verified.json')):
 data=json.loads(data_path.read_text());raw=json.loads(candidate_path.read_text());byid={v['id']:v for v in raw['candidates']};results=[];checks=0
 for case in data['cases']:
  candidate=byid[case['id']]
  if candidate.get('exitflag',0)<=0:raise AssertionError(('solver_not_successful',case['id'],candidate))
  z=[F(str(float(x))).limit_denominator(10**8) for x in candidate['zeta']];w=list(map(F,case['weights']));credit=F(case['credit']);budget=sum(a*b for a,b in zip(w,z));delta=max(F(0),(budget-credit)/sum(w));z=[a-delta for a in z]
  budget=sum(a*b for a,b in zip(w,z));assert budget<=credit;checks+=1
  c=max([F(0)]+[F(s['d_upper'])-sum(F(t)*a for t,a in zip(s['T_coeff'],z)) for s in case['source']])
  for s in case['source']:assert F(s['d_upper'])<=c+sum(F(t)*a for t,a in zip(s['T_coeff'],z));checks+=1
  integrated=sum(F(s['mass'])*F(s['d_upper']) for s in case['source']);W=F(case['W']);H=F(case['H']);BH=F(case['original_BH']);assert integrated<=c*W+budget;checks+=1
  assert BH<=integrated-credit+H*W<=c*W+H*W;checks+=1
  # Original exact square completion, separate from the reference relaxation.
  assert BH<=F(case['completion_first'])-F(case['original_Eall'])+H*W;checks+=1
  results.append(dict(id=case['id'],zero_zeta_feasible=credit>=0,no_zeta_c_exact=str(max([F(0)]+[F(v['d_upper']) for v in case['source']])),no_zeta_certificate_bound_exact=str((max([F(0)]+[F(v['d_upper']) for v in case['source']])+H)*W) if credit>=0 else None,c_exact=str(c),zeta_exact=list(map(str,z)),budget_exact=str(budget),credit_exact=str(credit),repair_delta=str(delta),BH_exact=str(BH),certificate_bound_exact=str((c+H)*W),c_decimal=float(c),original_BH_decimal=float(BH),bound_decimal=float((c+H)*W),solver_c=float(candidate['c']),solver_optimality='NOT CERTIFIED; exact feasible upper only'))
 out=dict(status='PASS',exact_checks=checks,cases=results,data_sha256=hashlib.sha256(data_path.read_bytes()).hexdigest(),scope='All source cells and signed budget exact after repair; finite receiver quadrature only. Outside Q4 has d=T=0 and c>=0. No LP optimum/general root/history claim.')
 output_path.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',exact_checks=checks,cases=len(results))))
def prepare_qp():
 data=json.loads(DATA.read_text());cases=[]
 for old in data['cases']:
  if old['reference']!='G_lower':continue
  recv=old['receivers'];n=old['n'];N=len(recv);weights=list(map(F,old['weights']));mi=[F(r['radius'])**n for r in recv];mu=[w/m for w,m in zip(weights,mi)]
  groups={}
  for cell in old['source']:
   sig=tuple(cell['signature']);groups[sig]=groups.get(sig,F(0))+F(cell['mass'])
  sigs=sorted(groups);masses=[groups[c] for c in sigs];radii=sorted(set(F(r['radius']) for r in recv));H=F(old['H']);a=[F(0)]*len(sigs);features=[[] for c in sigs]
  for kk,radius in enumerate(radii):
   ell=radius**(-n)-(radii[kk+1]**(-n) if kk+1<len(radii) else 0);active=[i for i,r in enumerate(recv) if F(r['radius'])<=radius];J=[sum(mu[i]*c[i] for i in active) for c in sigs]
   for k,c in enumerate(sigs):
    if J[k]>=H:a[k]+=ell*sum(weights[i]*c[i] for i in active)
    features[k].extend([math.sqrt(float(ell*mu[i]*mu[j]))*c[i]*c[j]/math.sqrt(float(J[k])) if J[k] else 0.0 for i in active for j in active])
  K=[[sum(x*y for x,y in zip(row,col)) for col in features] for row in features]
  Aeq=[[float(c[i]) for c in sigs] for i in range(N)]+[[1.0]*len(sigs)];beq=list(map(float,mi))+[float(F(old['W']))]
  assert all(sum(m*c[i] for m,c in zip(masses,sigs))==mi[i] for i in range(N));assert sum(masses)==F(old['W'])
  cases.append(dict(id=old['id'].replace('_h1','_qp'),original_case_id=old['id'],n=n,H=old['H'],source_signatures=[list(c) for c in sigs],source_original_masses=list(map(str,masses)),K=K,a=list(map(float,a)),a_exact=list(map(str,a)),Aeq=Aeq,beq=beq,x0=list(map(float,masses)),W=old['W'],m_i=list(map(str,mi)),note='Numerical PSD Gram matrix; QP candidate optimality/feasibility not exactly certified. A subsequent rational h/common-zeta LP is certified independently.'))
 (BASE/'r333_data_qp.json').write_text(json.dumps(dict(cases=cases,scope='Merged COMPLETE source incidence signatures, including signature zero; same actual finite receiver quadrature.'),sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(status='QP_PREPARED',cases=len(cases),patterns=[len(c['source_signatures']) for c in cases])))

def repair_source(xraw,sigs,masses,b):
 x=[F(str(max(0.0,float(v)))).limit_denominator(10**7) for v in xraw];N=len(sigs[0]);A=[[F(c[i]) for c in sigs] for i in range(N)]+[[F(1)]*len(sigs)];rhs=[bb-sum(a*v for a,v in zip(row,x)) for row,bb in zip(A,b)];aug=[row+[v] for row,v in zip(A,rhs)];rr=0;piv=[]
 for col in range(len(x)):
  found=next((i for i in range(rr,len(aug)) if aug[i][col]),None)
  if found is None:continue
  aug[rr],aug[found]=aug[found],aug[rr];factor=aug[rr][col];aug[rr]=[v/factor for v in aug[rr]]
  for i in range(len(aug)):
   if i!=rr:
    factor=aug[i][col];aug[i]=[u-factor*v for u,v in zip(aug[i],aug[rr])]
  piv.append(col);rr+=1
  if rr==len(aug):break
 for row in aug[rr:]:assert row[-1]==0
 for i,col in enumerate(piv):x[col]+=aug[i][-1]
 mix=max([F(0)]+[-v/(orig-v) for v,orig in zip(x,masses) if v<0]);mix=min(F(1),mix+F(1,2**40)) if mix else F(0)
 x=[(1-mix)*v+mix*orig for v,orig in zip(x,masses)]
 assert all(v>=0 for v in x)
 for row,bb in zip(A,b):assert sum(a*v for a,v in zip(row,x))==bb
 return x,mix

def prepare_qp_lp():
 olddata=json.loads(DATA.read_text());qpdata=json.loads((BASE/'r333_data_qp.json').read_text());raw=json.loads((BASE/'r333_solve_qp_results.json').read_text());byid={r['id']:r for r in raw['candidates']};oldby={r['id']:r for r in olddata['cases']};cases=[];sourcecert=[]
 for qp in qpdata['cases']:
  cand=byid[qp['id']];assert cand['exitflag']>0
  old=oldby[qp['original_case_id']];sigs=[tuple(c) for c in qp['source_signatures']];masses=list(map(F,qp['source_original_masses']));recv=old['receivers'];n=old['n'];N=len(recv);weights=list(map(F,old['weights']));mi=[F(r['radius'])**n for r in recv];mu=[w/m for w,m in zip(weights,mi)];x,mix=repair_source(cand['x'],sigs,masses,mi+[F(old['W'])]);radii=sorted(set(F(r['radius']) for r in recv));H=F(old['H']);aH=[F(0)]*len(sigs);T1=[sum(mu[i]*c[i] for i in range(N)) for c in sigs];coverage=[F(0)]*len(sigs);norm=F(0);norm_upper=F(0);BH_source=F(0)
  for kk,radius in enumerate(radii):
   ell=radius**(-n)-(radii[kk+1]**(-n) if kk+1<len(radii) else 0);active=[i for i,r in enumerate(recv) if F(r['radius'])<=radius];J=[sum(mu[i]*c[i] for i in active) for c in sigs];I_source={(i,j):sum(v*c[i]*c[j] for v,c in zip(x,sigs)) for i in active for j in active};BH_source+=ell*sum(v*(sum(weights[i]*c[i] for i in active)-sum(mu[i]*mu[j]*c[i]*c[j]*I_source[i,j] for i in active for j in active)/jy) for v,c,jy in zip(x,sigs,J) if jy and jy>=H);h={(i,j):sum((v*c[i]*c[j]/sqrtbox(jy)[1] for v,c,jy in zip(x,sigs,J) if jy),F(0)) for i in active for j in active};norm+=ell*sum(mu[i]*mu[j]*h[i,j]**2 for i in active for j in active)
   hu={(i,j):sum((v*c[i]*c[j]/sqrtbox(jy)[0] for v,c,jy in zip(x,sigs,J) if jy),F(0)) for i in active for j in active};norm_upper+=ell*sum(mu[i]*mu[j]*hu[i,j]**2 for i in active for j in active)
   for k,(c,jy) in enumerate(zip(sigs,J)):
    if jy>=H:aH[k]+=ell*sum(weights[i]*c[i] for i in active)
    if jy:coverage[k]+=ell*2*sum(mu[i]*mu[j]*c[i]*c[j]*h[i,j]/sqrtbox(jy)[1] for i in active for j in active)
  d=[a+t-v for a,t,v in zip(aH,T1,coverage)];credit=F(old['X'])-norm
  case=dict(old);case['id']=qp['id']+'_hPhi_repaired_x';case['reference']='rational_lower_Phi_exact_feasible_QP_source';case['norm_exact']=str(norm);case['credit']=str(credit);case['source']=[dict(mass=str(mass),signature=list(c),d_upper=str(v),T_coeff=[str(mu[i]*c[i]) for i in range(N)],J_final=str(jy)) for mass,c,v,jy in zip(masses,sigs,d,T1)];case['solver_credit']=float(credit);case['solver_d']=list(map(float,d));case['solver_T']=[[float(mu[i]*c[i]) for i in range(N)] for c in sigs]
  cases.append(case);sourcecert.append(dict(id=qp['id'],x_exact=list(map(str,x)),original_masses=list(map(str,masses)),source_signatures=[list(c) for c in sigs],mi=list(map(str,mi)),W=old['W'],mix_with_original=str(mix),QP_objective_candidate=float(cand['objective']),original_BH_repaired_source_exact=str(BH_source),primal_objective_lower_exact=str(sum(v*a for v,a in zip(x,aH))-norm_upper),primal_objective_upper_exact=str(sum(v*a for v,a in zip(x,aH))-norm),scope='Nonnegative and Cx=m, sumx=W exactly repaired. QP optimality not certified; reference h and subsequent LP independent certificate.'))
 (BASE/'r333_data_qp_lp.json').write_text(json.dumps(dict(cases=cases,source_certificates=sourcecert),sort_keys=True,indent=2)+'\n')
 script=(BASE/'r333_solve.m').read_text().replace('r333_data.json','r333_data_qp_lp.json').replace('r333_solve_results.json','r333_solve_qp_lp_results.json');(BASE/'r333_solve_qp_lp.m').write_text(script)
 print(json.dumps(dict(status='QP_REFERENCE_LP_PREPARED',cases=len(cases),source_primal_exact_repaired=True)))

def summarize():
 fixed=json.loads((BASE/'r333_numeric_verified.json').read_text());qp=json.loads((BASE/'r333_numeric_qp_verified.json').read_text());data=json.loads((BASE/'r333_data_qp_lp.json').read_text());by={c['id']:c for c in qp['cases']};comparison=[]
 for source in data['source_certificates']:
  key=source['id']+'_hPhi_repaired_x';v=by[key];fixedid=source['id'].replace('_qp','_h1');f=next(c for c in fixed['cases'] if c['id']==fixedid)
  comparison.append(dict(id=source['id'],original_target_BH=f['original_BH_decimal'],repaired_source_original_BH=float(F(source['original_BH_repaired_source_exact'])),fixed_original_reference_bound=f['bound_decimal'],QP_reference_before_shared_zeta_bound=float(F(v['no_zeta_certificate_bound_exact'])),QP_reference_after_shared_zeta_bound=v['bound_decimal'],QP_fixed_W_objective_lower=float(F(source['primal_objective_lower_exact'])),completion_H_W=float(F(v['certificate_bound_exact'])-F(v['c_exact'])*F(source['W'])),source_repair_mix=source['mix_with_original']))
 out=dict(status='PASS',fixed_h_exact_postrepair_checks=fixed['exact_checks'],QP_h_exact_postrepair_checks=qp['exact_checks'],total_exact_postrepair_checks=fixed['exact_checks']+qp['exact_checks'],comparison=comparison,scope='Finite actual-cube receiver quadrature. QP is fixed-W h-candidate only, not zero-Xbudget c optimum or ratio optimum; candidate source feasibility exact; no general root/history claim.')
 (BASE/'r333_numeric_summary.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True))

if __name__=='__main__':
 if '--prepare-qp' in sys.argv:prepare_qp()
 elif '--prepare-qp-lp' in sys.argv:prepare_qp_lp()
 elif '--verify-qp-lp' in sys.argv:verify((BASE/'r333_data_qp_lp.json'),(BASE/'r333_solve_qp_lp_results.json'),(BASE/'r333_numeric_qp_verified.json'))
 elif '--verify' in sys.argv:verify()
 elif '--summary' in sys.argv:summarize()
 else:prepare()
