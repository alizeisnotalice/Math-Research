from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from fractions import Fraction as F
from itertools import combinations, product
from math import prod
from pathlib import Path

import flint
from flint import arb, ctx, fmpq


PRECISION = 256


def fsum(vals):
    return sum(vals,F(0))


def ball(x):
    x=F(x)
    return arb(fmpq(x.numerator,x.denominator))


def interval(x):
    return x.str(23)


def cube(y,s):
    return tuple((x-s,x+s) for x in y)


def volume(A):
    return prod(max(F(0),r-l) for l,r in A)


def intersect(*boxes):
    return tuple((max(l for l,_ in axis),min(r for _,r in axis))
                 for axis in zip(*boxes))


def overlap(A,B):
    return volume(intersect(A,B))


def translate(x,y):
    return tuple(a+b for a,b in zip(x,y))


def real_price(A,patches):
    return fsum(w*overlap(A,P)/volume(P) for P,w,_,_ in patches)


def real_cubes(n,mode):
    a=32*n
    center=(F(1,8),)+(F(0),)*(n-1)
    d=n-1
    s,S=F(1),F(5,4)
    shifts=(F(1),F(5,4)) if mode=="coherent" else (F(1),F(-1))
    owners_centers=[center]+[translate(center,(u,)*d+(F(0),)) for u in shifts]
    parents=[cube(y,r) for y,r in zip(owners_centers,(s,S,S))]
    owners=[cube(y,r/a) for y,r in zip(owners_centers,(s,S,S))]
    assert all(not overlap(A,B) for A,B in combinations(owners,2))
    sizes=[volume(A) for A in parents]
    v=[volume(A) for A in owners]
    M=10*sizes[1]
    if mode=="coherent":
        head=(F(1,2),F(-1,8),F(-1,2))
        fractions=((F(1,4),F(1,10),F(1,20)),(F(1,4),F(1,10),F(1,4)))
    else:
        head=(F(1,2),F(-1,2),F(0))
        fractions=((F(1,4),F(1,20),F(1,10)),(F(1,4),F(1,5),F(3,20)))
    patches=[]
    for g,y in enumerate((F(-1,4),F(1,4))):
        for j,h in enumerate(head):
            R=cube(translate(center,(h,)*d+(y,)),F(1,32))
            patches.append((R,fractions[g][j]*M,g,j))
    if mode=="coherent":
        outside=cube(translate(center,(F(5,4),)+(F(1,2),)*(d-1)+(F(0),)),F(1,32))
        patches.append((outside,M/10,None,3))
    assert all(not overlap(a,b) for (a,_,_,_),(b,_,_,_) in combinations(patches,2))
    m=[real_price(A,patches) for A in parents]
    assert all(x>=y for x,y in zip(m,sizes)) and m[0]==M>sizes[0]
    I=[intersect(parents[0],A) for A in parents[1:]]
    shared=[real_price(A,patches) for A in I]
    p=[price/m[0] for price in shared]
    assert all(0<x<1 for x in p)
    common=real_price(intersect(*I),patches)/m[0]
    assert 0<common<=min(p)
    eta=(F(3,4),F(1,2),F(3,4) if mode=="coherent" else F(1,2))
    G=F(2)
    lam=[e*vi/(G*mi) for e,vi,mi in zip(eta,v,m)]
    assert sum(lam)<1 and all(x*y<=z/G for x,y,z in zip(lam,m,v))
    flows={"large_to_small":(v[0]/G,[G*x for x in lam[1:]]),
           "small_to_large":(lam[0]*m[0],[v[i]/m[i] for i in (1,2)])}
    for i in range(2):
        assert flows["large_to_small"][0]*flows["large_to_small"][1][i]*p[i]==lam[i+1]*v[0]*shared[i]/m[0]
        assert flows["small_to_large"][0]*flows["small_to_large"][1][i]*p[i]==lam[0]*v[i+1]*shared[i]/m[i+1]
    return dict(n=n,center=center,s=s,S=S,parents=parents,I=I,v=v,m=m,sizes=sizes,
                p=p,patches=patches,shared=common,flows=flows)


def integral_quadratic(f):
    return (f(F(-1))+4*f(F(0))+f(F(1)))/6


def tilt_moments(data,theta):
    n,center,s=data["n"],data["center"],data["s"]
    assert len(theta)==n and all(abs(x)<=F(1,2) for x in theta)
    sq=fsum(x*x for x in theta)
    assert ball(sq)<arb(n).log()
    assert prod(integral_quadratic(lambda t:1+x*t) for x in theta)==1
    second=prod(1+x*x/3 for x in theta)
    assert prod(integral_quadratic(lambda t:(1+x*t)**2) for x in theta)==second
    assert ball(second)<(arb(n).log()/3).exp()
    values=[]
    for A in data["I"]:
        q=volume(A)/data["sizes"][0]
        mid=tuple(((r+l)/2-c)/s for (l,r),c in zip(A,center))
        scaled=tuple(((l-c)/s,(r-c)/s) for (l,r),c in zip(A,center))
        tilted=q*prod(1+x*y for x,y in zip(theta,mid))
        exact=prod(((r-l)+x*(r*r-l*l)/2)/2 for (l,r),x in zip(scaled,theta))
        assert tilted==exact
        values.append((q,mid,tilted))
    return second,values


def grouped_jensen(data,p,theta,expected):
    second,values=tilt_moments(data,theta)
    directions=[]
    for name,(base,a) in data["flows"].items():
        original=[base*x*y for x,y in zip(a,p)]
        total=sum(original)
        pi=[x/total for x in original]
        assert sum(pi)==1
        gain=sum(ball(w)*ball(sigma/q).log() for w,(q,_,sigma) in zip(pi,values))
        log_l2=ball(second).log()
        ratios=[sigma/r for r,(_,_,sigma) in zip(p,values)]
        baseline=[q/r for r,(q,_,_) in zip(p,values)]
        arithmetic=fsum(w*x for w,x in zip(pi,ratios))
        geometric=sum(ball(w)*ball(x).log() for w,x in zip(pi,ratios))
        g0=sum(ball(w)*ball(x).log() for w,x in zip(pi,baseline))
        assert (geometric-g0).overlaps(gain)
        if ratios[0]!=ratios[1]:
            assert ball(arithmetic).log()>geometric
        else:
            assert ball(arithmetic).log().overlaps(geometric)
        if expected=="cancel":
            assert pi==[F(1,2)]*2
            formula=sum(ball(1-(q*m)**2).log()/2 for q,m in zip(theta,values[0][1]))
            assert gain.overlaps(formula) and gain<0<log_l2
        else:
            assert 0<log_l2<gain
        directions.append({
            "direction":name,"normalized_true_c_e_p_e":list(map(str,pi)),
            "total_true_c_e_p_e":interval(ball(total)),
            "log_geometric_overlap_gain":interval(gain),
            "log_gain_after_full_squared_L2_cost":interval(gain-log_l2),
            "arithmetic_sigma_over_p":interval(ball(arithmetic)),
            "geometric_sigma_over_p":interval(geometric.exp()),
            "untilted_arithmetic_q_over_p":interval(ball(fsum(w*x for w,x in zip(pi,baseline)))),
            "untilted_geometric_q_over_p":interval(g0.exp()),
        })
    decode=str if data["n"]<=16 else (lambda x:interval(ball(x)))
    return {
        "theta_first_and_last":list(map(str,(theta[0],theta[-1]))),
        "theta_vector_if_small":list(map(str,theta)) if data["n"]<=5 else None,
        "sum_theta_squared":str(fsum(x*x for x in theta)),
        "squared_L2":interval(ball(second)),
        "sigma_intersection_masses": [decode(q) for _,_,q in values],
        "untilted_masses": [decode(q) for q,_,_ in values],
        "active_normalized_midpoints": [str(m[0]) for _,m,_ in values],
        "directions":directions,
    }


def dyadic_tilt(n):
    x=F(1,2)
    while ball((n-1)*x*x)>arb(n).log():
        x/=2
    assert ball((n-1)*x*x)<arb(n).log()
    if x<F(1,2):
        assert ball(4*(n-1)*x*x)>arb(n).log()
    return (x,)*(n-1)+(F(0),)


def block_partition(data,theta,mode):
    prices = data["m"][0]
    p=data["p"]
    probabilities=[]
    conditional=[]
    for g in (0,1):
        components=[row for row in data["patches"] if row[-2]==g]
        tail=data["center"][-1]
        assert all((R[-1][1]<tail if g==0 else R[-1][0]>tail) for R,_,_,_ in components)
        price=real_price(data["parents"][0],components)
        probabilities.append(price/prices)
        conditional.append([real_price(I,components)/price for I in data["I"]])
    assert probabilities==[F(2,5),F(3,5)]
    assert conditional[0]!=p and conditional[1]!=p
    for e in range(2):
        assert sum(probabilities[g]*conditional[g][e] for g in (0,1))==p[e]
        for base,a in data["flows"].values():
            c=base*a[e]
            assert sum(c*probabilities[g]*conditional[g][e] for g in (0,1))==c*p[e]
    output=[]
    for g in (0,1):
        if mode=="coherent":
            local_theta=theta if g==0 else tuple(t/2 for t in theta)
        else:
            local_theta=tuple((1 if g==0 else -1)*t/8 for t in theta)
        output.append({
            "block": "last_coordinate_negative" if g==0 else "last_coordinate_positive",
            "exact_original_block_probability":str(probabilities[g]),
            "conditional_p":list(map(str,conditional[g])),
            "base_mass_times_block_probability":{
               key:interval(ball(base*probabilities[g])) for key,(base,_) in data["flows"].items()
            },
            "separately_chosen_theta_within_L2_budget":grouped_jensen(data,conditional[g],local_theta,"gain"),
        })
    return output


def anatomy(parent,subboxes):
    axes=[]
    for i,(u,v) in enumerate(parent):
        cuts=sorted({u,v,*(x for I in subboxes for x in I[i] if u<=x<=v)})
        axes.append(list(zip(cuts,cuts[1:])))
    totals={}
    count=0
    for ranges in product(*axes):
        x=tuple((l+r)/2 for l,r in ranges)
        group=tuple(j for j,I in enumerate(subboxes)
                    if all(l<z<r for (l,r),z in zip(I,x)))
        totals[group]=totals.get(group,F(0))+volume(ranges)/volume(parent)
        count+=1
    assert sum(totals.values())==1
    return totals,count


def replacement(data):
    n=data["n"]
    assert n==5
    cap=n
    I=data["I"]
    d=data["sizes"][0]
    q=[volume(A)/d for A in I]
    masks,count=anatomy(data["parents"][0],I)
    H=[[overlap(A,R)/volume(R) for R in I] for A in I]
    for e,j in product(range(2),repeat=2):
        assert H[e][j]==fsum(v for M,v in masks.items() if e in M and j in M)/q[j]
    assert H[0][1]==1 and H[1][0]<1

    source_groups=[]
    for support,price,group,site in data["patches"]:
        if group is None:
            continue
        unchanged=(F(1,2) if site==1 else F(1),F(3,4))
        keep=tuple(int(overlap(A,support)==volume(support)) for A in I)
        assert all(overlap(A,support) in (0,volume(support)) for A in I)
        source_groups.append((price/data["m"][0],tuple(x*y for x,y in zip(unchanged,keep))))
    assert sum(x for x,_ in source_groups)==1
    p=[fsum(w*b[i] for w,b in source_groups) for i in range(2)]
    h=[min(F(1),cap*q[i]/p[i]) for i in range(2)]
    assert h[0]==1 and 0<h[1]<1
    responses=[]
    for direction,(source_weight,a) in data["flows"].items():
        for u0 in (F(1),a[0]+a[1]/2):
            direct=F(0)
            transformed=F(0)
            wrong_H=F(0)
            wrong_first=F(0)
            density_under_U={M:F(0) for M in masks}
            for probability,b in source_groups:
                u=[a[j]*b[j] for j in range(2)]
                U=sum(u)
                denom=max(u0,U)
                assert sum(x/denom for x in u)<=1
                hits=fsum(u[e]*u[j]/denom*h[j]*H[e][j] for e,j in product(range(2),repeat=2))
                direct+=probability*hits
                wrong_H+=probability*fsum(u[e]*u[j]/denom*h[j]*H[j][e]
                                           for e,j in product(range(2),repeat=2))
                if U:
                    wrong_first+=probability*hits/U
                for M,cell in masks.items():
                    density=fsum(u[j]/denom*h[j]/q[j] for j in M)
                    density_under_U[M]+=probability*density
                    transformed+=probability*cell*fsum(u[e] for e in M)*density
            assert direct==transformed>0 and wrong_H!=direct and wrong_first!=direct
            for M,density in density_under_U.items():
                assert density<=cap*fsum(a[j] for j in M)/u0
            responses.append({
                "direction":direction,"u0":str(u0),
                "conditional_double_label_and_changed_reference":str(direct),
                "source_weight":str(source_weight),
                "true_joint_flow":str(source_weight*direct),
                "incorrect_orientation_H":str(wrong_H),
                "incorrect_extra_normalization_of_first_label":str(wrong_first),
                "output_density_relative_to_uniform_by_positive_cell_mask":{
                    str(M):str(value) for M,value in density_under_U.items()
                },
            })
    return {
        "dimension":n,"positive_volume_y_cells":count,
        "H_e_eprime":[list(map(str,row)) for row in H],
        "p_in_original_small_price_after_taper":list(map(str,p)),
        "thinning_h":list(map(str,h)),
        "directions":responses,
    }


def audit_mode(n,mode,include_blocks):
    data=real_cubes(n,mode)
    theta=(F(1,2),F(1,4),F(0)) if n==3 else dyadic_tilt(n)
    out={
        "dimension":n,"mode":mode,
        "p_in_full_small_parent":list(map(str,data["p"])),
        "shared_price_probability_in_both_intersections":str(data["shared"]),
        "small_center_first_axis":str(data["center"][0]),
        "small_and_large_radii":[str(data["s"]),str(data["S"])],
        "relative_price_m_over_d":[str(x/y) for x,y in zip(data["m"],data["sizes"])],
        "global_group":grouped_jensen(data,data["p"],theta,"gain" if mode=="coherent" else "cancel"),
    }
    if include_blocks:
        out["true_small_price_measurable_partition"]=block_partition(data,theta,mode)
    return out


def selection_and_history():
    from fractions import Fraction as F
    from itertools import product
    from math import prod
    from flint import arb, fmpq
    def enclose(x):
        return arb(fmpq(x.numerator, x.denominator))
    def down(x):
        q = F(1)
        while q > x:
            q /= 2
        return q
    # Three actual hard intersections with [-1,1], all containing 0.
    intervals = ((F(-1), F(1,4)), (F(-1,4), F(1)), (F(-1), F(1)))
    pi = (F(1,6), F(1,3), F(1,2))
    h = (F(1,4), F(3,4), F(1,2))
    zeros = 0
    coverage = []
    for j, (lo, hi) in enumerate(intervals):
        coverage.append(sum(pi[i]*max(0,min(hi,b)-max(lo,a))/(hi-lo)
                            for i,(a,b) in enumerate(intervals)))
    scores = [F(0)] + [a*b for a,b in zip(h,coverage)]
    rounded = [F(0)] + [down(a)*b for a,b in zip(h,coverage)]
    order = sorted(range(4),key=lambda i:(scores[i],i))
    selected = []
    for actual_degree in (F(1,32), F(1), F(3,2)):
        used = min(F(1),actual_degree)
        probs = [1-used] + [used*x for x in pi]
        for draws in (1,2,4,16,128):
            previous = F(0)
            win = [F(0)]*4
            for i in order:
                current = previous+probs[i]
                win[i] = current**draws-previous**draws
                assert win[i] <= draws*probs[i]
                previous = current
            assert sum(win) == 1
            score = sum(a*b for a,b in zip(win,scores))
            if draws<=4:
                wr = [F(0)]*4
                objective_round = F(0)
                for a in product(range(4),repeat=draws):
                    mass = prod(probs[i] for i in a)
                    winner = max(a,key=lambda i:(scores[i],i))
                    wr[winner] += mass
                    objective_round += mass*max(rounded[i] for i in a)
                    zeros += (mass==0)
                assert win==wr and score/2 <= objective_round <= score
            selected.append([str(actual_degree),draws,float(score)])
    history = []
    for d in (2,8,24,48):
        A=F(1,2**d)
        levels=[F(1,2**j) for j in range(d+1)]+[F(0)]
        bill=sum((x-y)*min(F(1),A/x) for x,y in zip(levels,levels[1:]))
        assert bill == A*(1+F(d,2)) and bill>A
        assert enclose(bill) < enclose(A)*(1-enclose(A).log())
        history.append([d,str(bill/A)])
    shifted=0
    for d in range(1,18):
        for j in range(1,48):
            v=min(F(1),F(1,2**d)/F(j,49))
            w=down(v)
            assert w<=v<2*w
            shifted+=1
    return {"method":"Exact rational order statistics; expected scores printed to floating display only. History integral checked using Arb.",
            "lens_intervals":[list(map(str,x)) for x in intervals],
            "true_label_probabilities":list(map(str,pi)),"trial_thinning":list(map(str,h)),
            "scope":"Weight/selection tests include abstract degree regimes. They do not certify a high-dimensional worst-case input.",
            "expected_score_by_degree_and_draws":selected,
            "excluded_zero_mass_sequences":zeros,
            "moving_denominator_cost_over_A":history,
            "dyadic_rounding_checks":shifted}



def report():
    ctx.prec=PRECISION
    script=Path(__file__)
    return {
        "schema":"r754-shared-receivers-and-price-partition-v1",
        "runtime":{
            "python":platform.python_version(),"python_executable":sys.executable,
            "python_flint":flint.__version__,"arb_precision_bits":PRECISION,
            "script_sha256":hashlib.sha256(script.read_bytes()).hexdigest(),
            "working_directory_for_commands":"directory containing verify.py and verify.json",
            "write_command":[sys.executable,"-B",script.name,"--out","verify.json"],
            "rerun_command":[sys.executable,"-B",script.name,"--check","verify.json"],
        },
        "tilt":{
            "finite_geometry":[audit_mode(3,mode,True) for mode in ("coherent","opposite")],
            "larger_exact_coordinate_products":[audit_mode(n,mode,n==16)
                                               for n,mode in product((16,64,256),("coherent","opposite"))],
        },
        "prethinned_double_label_reweighted_reference":replacement(real_cubes(5,"coherent")),
        "multiple_candidates_and_history":selection_and_history(),
        "scope":[
            "Genuine parent cubes have absolutely continuous nonuniform rational box prices and disjoint complete shrunken owners.",
            "The common tilt uses the squared-L2 budget. The density of the separate transformed reference is bounded pointwise relative to uniform.",
            "Original mass caps use K=1 and G=2 only as explicit test parameters. The extremal G is not estimated.",
            "Source blocks are disjoint half-spaces of the actual small parent conditional price. Each p is recomputed.",
            "Large-dimensional examples use exact products rather than ambient cell enumeration. Output bounds concern these families.",
        ],
    }


def main():
    parser=argparse.ArgumentParser()
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--out",type=Path)
    mode.add_argument("--check",type=Path)
    args=parser.parse_args()
    raw=json.dumps(report(),indent=2,sort_keys=True)+"\n"
    if args.out:
        args.out.write_text(raw,encoding="utf-8")
        print(f"wrote {args.out} ({len(raw)} bytes)")
    else:
        if args.check.read_text(encoding="utf-8")!=raw:
            raise SystemExit("rerun differs from saved JSON")
        print(f"identical rerun of {args.check} ({len(raw)} bytes)")


if __name__=="__main__":
    main()
