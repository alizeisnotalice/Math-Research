from fractions import Fraction as F
from decimal import Decimal as D,localcontext
from itertools import product
from collections import deque
from pathlib import Path
import json,math

def dc(x):return D(x.numerator)/D(x.denominator) if isinstance(x,F) else D(x)
def lower(q,k):
 term=(-q).exp();total=term
 for j in range(1,k):term*=q/j;total+=term
 return total

def tail(q,k):
 if not q:return D(0)
 if q>D(k):return 1-lower(q,k)
 term=(-q).exp()
 for j in range(1,k+1):term*=q/j
 total=term;j=k
 while term>max(total,D('1e-1000'))*D(10)**(-__import__('decimal').getcontext().prec+8):
  j+=1;term*=q/j;total+=term
 return total

def flow(b,mass,K):
 # Finite support demand -> allowed actual source labels -> K*source mass.
 N=len(mass); supports=[s for s,v in b.items() if v]; total=sum(b.values(),F(0))
 size=2+len(supports)+N;s=0;t=size-1;cap={};adj=[[] for _ in range(size)]
 def add(i,j,v):
  adj[i].append(j);adj[j].append(i);cap[i,j]=v;cap[j,i]=F(0)
 for j,A in enumerate(supports,1):
  add(s,j,b[A])
  for i in range(N):
   if A>>i&1:add(j,1+len(supports)+i,total)
 for i,w in enumerate(mass):add(1+len(supports)+i,t,K*w)
 value=F(0)
 while True:
  prev={s:None};q=deque([s])
  while q and t not in prev:
   u=q.popleft()
   for v in adj[u]:
    if v not in prev and cap[u,v]>0:prev[v]=u;q.append(v)
  if t not in prev:break
  v=t;path=[]
  while v!=s:path.append((prev[v],v));v=prev[v]
  delta=min(cap[e] for e in path)
  for u,v in path:cap[u,v]-=delta;cap[v,u]+=delta
  value+=delta
 assert value==total
 loads=[K*w-cap[1+len(supports)+i,t] for i,w in enumerate(mass)]
 assert sum(loads)==total and all(v<=K*w for v,w in zip(loads,mass))
 return loads

def hall(rows,mass,k):
 N=len(mass);Dcut={0:F(0)};b={};full=(1<<N)-1
 for A in range(1,1<<N):
  Dcut[A]=sum(c*sum((p[i] for i in range(N) if A>>i&1),F(0))**k for c,p in rows)
  b[A]=Dcut[A]-sum(v for S,v in b.items() if S&A==S)
  assert b[A]>=0
 K,A=max((v/sum((mass[i] for i in range(N) if A>>i&1),F(0)),A) for A,v in Dcut.items() if A)
 loads=flow(b,mass,K)
 uniform=[sum(c*p[i] for c,p in rows) for i in range(N)]
 assert max(v/w for v,w in zip(uniform,mass))>=K
 # Verify all Hall cuts, total receiver demand, and the dual witness A.
 assert Dcut[full]==sum(c for c,p in rows)
 assert Dcut[A]==K*sum((mass[i] for i in range(N) if A>>i&1),F(0))
 return dict(K=float(K),uniform_max=float(max(v/w for v,w in zip(uniform,mass))),total_over_mass=float(Dcut[full]/sum(mass)),critical_cut=A,nonzero_supports=sum(v>0 for v in b.values()),loads=[float(v) for v in loads])

def stable_cells(points,a,b):
 original_n=len(points[0])
 varying=[j for j in range(original_n) if len(set(y[j] for y in points))>1]
 factor=a**(original_n-len(varying))
 points=[tuple(y[j] for j in varying) for y in points]
 n=len(varying);cuts=[]
 for j in range(n):cuts.append(sorted(set(y[j]+sign*L/2 for y in points for sign in (-1,1) for L in (a,b))))
 volumes={}
 for ids in product(*[range(len(v)-1) for v in cuts]):
  x=tuple((cuts[j][i]+cuts[j][i+1])/2 for j,i in enumerate(ids))
  A=tuple(i for i,y in enumerate(points) if max(abs(u-v) for u,v in zip(x,y))<=a/2)
  B=tuple(i for i,y in enumerate(points) if max(abs(u-v) for u,v in zip(x,y))<=b/2)
  if not A or A!=B:continue
  vol=factor
  for j,i in enumerate(ids):vol*=cuts[j][i+1]-cuts[j][i]
  volumes[A]=volumes.get(A,F(0))+vol
 return volumes

def run(prec):
 with localcontext() as ctx:
  ctx.prec=prec;out=[];subguards=[]
  models=[('line_cluster',[(F(0),),(F(1,3),),(F(2,3),)], [F(1,100),F(1),F(3)]),
   ('line_nested',[(F(0),),(F(1,8),),(F(1,2),),(F(1),),(F(2),)],[F(1),F(2),F(1,3),F(4),F(2)]),
   ('axis',[(F(0),F(0)),(F(1,2),F(0)),(F(1),F(0)),(F(0),F(1,2)),(F(0),F(1))],[F(1,100),F(1),F(4),F(1),F(4)]),
   ('diagonal',[(F(0),F(0)),(F(1,4),F(1,4)),(F(3,4),F(3,4)),(F(1),F(1))],[F(1),F(2),F(3),F(1)])]
  for dim in (8,128):
   models.append(('embedded_line_'+str(dim),[tuple([v]+[F(0)]*(dim-1)) for v in (F(0),F(1,8),F(1,2),F(1),F(2))],[F(1),F(2),F(1,3),F(4),F(2)]))
  for name,pts,mass in models:
   n=len(pts[0]);a=F(1);b=F(5,4);volumes=stable_cells(pts,a,b)
   for lam in (F(1,2),F(2)):
    actual=int((64*(2+D(n)*(dc(b/a)).ln()).ln()).to_integral_value(rounding='ROUND_CEILING'))
    for m in (1,3,actual):
     rows=[];guard_rows=[]
     for I,V in volumes.items():
      M=sum(mass[i] for i in I);q0=dc(m*M/lam);qT=q0/dc(b**n);k=m+1
      # Stable receiver cells have no future entries: hit iff initial >=k.
      # Include both terminal and last-exit mass; their sum is tail(q0,k).
      terminal=tail(qT,k)
      flux=tail(q0,k)-terminal if q0<=D(k) else lower(qT,k)-lower(q0,k)
      assert flux>=0
      c=dc(lam*V)*(terminal+flux)
      if not c:continue
      # Exact flow checks operate on this explicitly rounded rational instance.
      cq=F(format(c,'.16g'))
      p=[mass[i]/M if i in I else F(0) for i in range(len(mass))]
      rows.append((cq,p))
      for A in range(1,1<<len(mass)):
       z=sum((p[i] for i in range(len(mass)) if A>>i&1),F(0));qA=q0*dc(z)
       tol=D(10)**(-prec+12)
       assert tail(q0,k)*dc(z)**k<=tail(qA,k)+tol
      guard_rows.append(dict(source_subset=list(I),volume=str(V),initial_mean=format(q0,'.16g'),terminal=format(terminal,'.16g'),flux=format(flux,'.16g')))
     if rows:
      out.append(dict(model=name,n=n,lambda_value=str(lam),m=m,actual_log_trigger=m==actual,rows=guard_rows,**hall(rows,mass,m+1)))
  # All-subsource Poisson density identity, with outside suppression.
  for m in (1,3,16,64):
   for qa in (D('0.1'),D(1),D(m)):
    for qo in (D(0),D('0.25'),D(4)):
     q=qa+qo;k=m+1
     lhs=(-q).exp()*q**k/D(math.factorial(k))*(qa/q)**k
     rhs=(-qo).exp()*(-qa).exp()*qa**k/D(math.factorial(k))
     assert abs(lhs-rhs)<D(10)**(-prec+12)
     subguards.append(dict(m=m,qa=str(qa),qo=str(qo),value=format(rhs,'.16g')))
  return dict(cases=out,poisson_subsource_identity=subguards)

if __name__=='__main__':
 a=run(60);b=run(90);assert a==b
 result=dict(status='PASS; mass-average square-root estimate remains unproved',**a,notes=['Receiver cells are genuine Lebesgue cells with no entries throughout [1,5/4]; omitted moving-boundary cells are not estimated.','Maxflow/mincut checks are Fraction-exact for explicitly 16-digit-rounded row demands; underlying Poisson probabilities use Decimal60/90 repeated agreement, not interval certification.','No sample or fitted growth law is used. Atom locations and weights, threshold and dimension are preserved in the source code.'])
 Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',len(a['cases']),'actual-source restricted-receiver flow cases;',len(a['poisson_subsource_identity']),'subsource identities')

# Exact tie-sensitive latest-capture selection tests.
def latest_tests():
 from itertools import product
 out=[]
 for p in ([F(1,4)]*4,[F(1,10),F(2,10),F(3,10),F(4,10)]):
  for ranks in ((0,1,2,3),(0,1,1,2),(0,0,0,0)):
   for k in (2,3,5,8):
    vals=[]
    for i in range(4):
     lo=sum((p[j] for j in range(4) if ranks[j]<ranks[i]),F(0))
     eq=sum((p[j] for j in range(4) if ranks[j]==ranks[i]),F(0))
     formula=((lo+eq)**k-lo**k)/(k*eq)
     direct=F(0)
     for others in product(range(4),repeat=k-1):
      if any(ranks[j]>ranks[i] for j in others):continue
      weight=F(1)
      for j in others:weight*=p[j]
      direct+=weight/F(1+sum(ranks[j]==ranks[i] for j in others))
     assert formula==direct and formula<=(lo+eq)**(k-1)
     vals.append(formula)
    assert sum(p[i]*vals[i] for i in range(4))==F(1,k)
    out.append(dict(probabilities=list(map(str,p)),ranks=ranks,k=k,selected_conditional=list(map(str,vals))))
 return out

def axial_latest(prec):
 with localcontext() as ctx:
  ctx.prec=prec;ctx.Emin=-999999999;out=[]
  for n in (1024,4096,16384,65536,1048576):
   T=D(n)*D(2).ln();m=int((64*(2+T).ln()).to_integral_value(rounding='ROUND_CEILING'));d0=D('0.01')/(n*m)
   d=d0/2;vlo=d**n;other_sum=D('.02');atom=D('.01')*(-T/2).exp()
   h=(1-atom)/2;vd=h+1/(200*D(m).sqrt())-other_sum-vlo
   po=(other_sum/(n-2))**(1/D(n));pd=vd**(1/D(n))
   assert d<=min(pd,1-pd,po,1-po)
   S=vlo+other_sum+vd;q=D(m)*(2*S+atom)
   num=2*((pd-d)**n+D(n-2)*(po-d)**n)+atom
   Fcdf=num/(2*S+atom)
   assert Fcdf>=1-D('.012')/m
   factor=Fcdf**m
   assert factor>=D('.5')
   beta=pd**(n-1)+D(n-2)*po**(n-1)+d**(n-1)
   assert beta<D('.6') and D(m)<=q<=m+D(m).sqrt()/50
   ell=4*m//5;psi=D('.25')-D('.6')*m*T*(D('.75')**(m-ell))
   assert psi>=D('.125')
   out.append(dict(n=n,m=m,current_q=format(q,'.16g'),radial_cdf=format(Fcdf,'.16g'),k_times_selection_lower=format(factor,'.16g'),birth_over_m=format(beta,'.16g'),survival_lower=format(psi,'.16g')))
  return out

if __name__=='__main__':
 ties=latest_tests();ax=axial_latest(70);assert ax==axial_latest(110)
 result['latest_tie_checks']=ties;result['axial_latest_guards']=ax
 result['notes'].append('Latest-capture guards use genuine finite-measure axial source; no claim of a mass-average counterexample. Two-precision agreement is not interval certification.')
 Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',len(ties),'tie-sensitive exact laws;',len(ax),'enlarged axial latest-source guards')

if __name__=='__main__':
 paid=[]
 with localcontext() as ctx:
  ctx.prec=80
  for st in ('0','.001','.1','1','10','1000','1000000','1e16'):
   T=D(st);s=2+T;m=int((64*s.ln()).to_integral_value(rounding='ROUND_CEILING'));k=m+1
   cut=D(m)*T/s**8;latest=D(m*k)*T/s**16
   assert cut<1 and latest<1
   paid.append(dict(T=st,m=m,cut_cost_over_mass=format(cut,'.16g'),latest_cost_over_mass=format(latest,'.16g')))
 result['paid_branch_guards']=paid
 Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',len(paid),'paid-branch parameter guards')
