"""R95 neutral multiscale correlated-source adaptation and common-cap certificates.
Only declared finite probability laws; no original Fnew qualification.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import inf, log, sqrt
import argparse
import json
import time

BITS = 44
DEN = 1 << BITS

def floorq(x):
    return x.numerator // x.denominator

def ceilq(x):
    return -floorq(-x)

def series_log(q):
    assert 1 <= q <= 2
    t = (q - 1) / (q + 1)
    s = F(0)
    p = t
    for j in range(40):
        s += 2 * p / (2*j + 1)
        p *= t*t
    tail = 2*p / (81*(1-t*t))
    return s, s+tail

LOG2 = series_log(F(2))

@lru_cache(None)
def log_bounds(q):
    assert q > 0
    k = 0
    z = q
    while z >= 2:
        z /= 2
        k += 1
    while z < 1:
        z *= 2
        k -= 1
    d56 = 1 << 56
    zl = F(floorq(z*d56), d56)
    zh = F(ceilq(z*d56), d56)
    lo = series_log(zl)[0]
    hi = series_log(zh)[1]
    if k >= 0:
        lo, hi = lo+k*LOG2[0], hi+k*LOG2[1]
    else:
        lo, hi = lo+k*LOG2[1], hi+k*LOG2[0]
    return F(floorq(lo*DEN), DEN), F(ceilq(hi*DEN), DEN)

@lru_cache(None)
def energy(n, arrivals):
    """Integral (sum mass 1_{L>=r}/L**n - 1)_+**2 dL/L.
    arrivals is sorted tuple (full-side distance, mass), mass sums to one.
    Returns rigorous fixed-dyadic bounds or None for +infinity.
    """
    grouped = {}
    for r, m in arrivals:
        grouped[r] = grouped.get(r, F(0)) + m
    points = sorted(grouped)
    if points[0] == 0:
        return None
    total = F(0)
    elo = ehi = F(0)
    for i, r in enumerate(points):
        total += grouped[r]
        u0 = r**n
        u1 = min(total, points[i+1]**n) if i+1 < len(points) else total
        if u0 >= u1:
            continue
        rational = total*total*(1/u0**2-1/u1**2)/(2*n) - 2*total*(1/u0-1/u1)/n
        l0, h0 = log_bounds(u0)
        l1, h1 = log_bounds(u1)
        elo += rational+(l1-h0)/n
        ehi += rational+(h1-l0)/n
    return max(F(0), F(floorq(elo*DEN), DEN)), max(F(0), F(ceilq(ehi*DEN), DEN))


from pathlib import Path
import hashlib
import base64
import zlib

def rational(x):
    return str(x)

def interval(lo, hi):
    assert 0 <= lo <= hi
    return {'lower':str(lo),'upper':str(hi),
            'display_only':[float(lo),float(hi)]}

def trim_bound(cells,budget,key):
    """Fractional density sorting is exact for the piecewise constant envelope."""
    assert budget>=0
    ordered=sorted(cells,key=lambda c:(c[key] is None,
                   F(0) if c[key] is None else c[key],str(c['id'])),reverse=True)
    remaining=budget; deleted=F(0); value=F(0); singular_remaining=False
    full=[];partial=None
    for c in ordered:
        take=min(remaining,c['volume'])
        remaining-=take;deleted+=take
        if take==c['volume']:full.append(c['id'])
        elif take>0:
            assert partial is None
            partial={'cell':c['id'],'deleted_volume':str(take),
                     'first_coordinate_slice_fraction':str(take/c['volume'])}
        kept=c['volume']-take
        if kept and c[key] is None:singular_remaining=True
        elif kept:value+=kept*c[key]
    assert deleted<=budget
    payload=json.dumps(full,separators=(',',':')).encode()
    return None if singular_remaining else value,{
        'actual_cap_volume':str(deleted),
        'fully_deleted_cells_zlib_base85':base64.b85encode(zlib.compress(payload,9)).decode(),
        'fully_deleted_cell_count':len(full),
        'fully_deleted_cell_ids_sha256':hashlib.sha256(payload).hexdigest(),
        'witness_codec':'base85(zlib(UTF8 compact JSON list of exact histogram/direct-cell IDs))',
        'partial_cell':partial,'single_cap_independent_of_scale':True,
        'partial_realization':'same left first-coordinate slice fraction in each disjoint Cartesian component of the histogram orbit',
        'singular_upper_cells_remaining':singular_remaining}

from math import prod
BUDGETS=(F(1,8),F(1,4),F(1,2),F(1))

def vol(box):return prod((hi-lo for lo,hi in box),start=F(1))
def in_box(x,box):return all(lo<=z<=hi for z,(lo,hi) in zip(x,box))
def intersection(a,b):
    out=tuple((max(x,u),min(y,v)) for (x,y),(u,v) in zip(a,b))
    return None if any(lo>=hi for lo,hi in out) else out

def canonical_sources(sources):
    sums={}
    for c,e,m in sources:sums[(c,e)]=sums.get((c,e),F(0))+m
    return tuple(sorted((c,e,m) for (c,e),m in sums.items()))

def source_payload(sources):
    return [{'center':[str(z) for z in c],'halfwidth':str(e),'mass':str(m)} for c,e,m in sources]

def source_digest(sources):
    return hashlib.sha256(json.dumps(source_payload(canonical_sources(sources)),sort_keys=True,separators=(',',':')).encode()).hexdigest()

def energy_arrivals(box,sources):
    near=[];far=[]
    for c,e,m in sources:
        near.append((2*max(max(lo-c[j]-e,c[j]-e-hi,F(0)) for j,(lo,hi) in enumerate(box)),m))
        far.append((2*max(max(abs(lo-c[j]-e),abs(hi-c[j]+e)) for j,(lo,hi) in enumerate(box)),m))
    return tuple(sorted(near)),tuple(sorted(far))

def raw_step(n,arrivals):
    total=F(0);value=F(0)
    for r,m in arrivals:
        if r==0:return None
        value+=((total+m)**2-total**2)/(2*n*r**(2*n));total+=m
    assert total==1
    return value

@lru_cache(None)
def envelope(box,sources):
    n=len(box);near,far=energy_arrivals(box,sources)
    el=energy(n,far);eu=energy(n,near)
    assert el is not None
    return (el[0],None if eu is None else eu[1],raw_step(n,far),raw_step(n,near))

def grid_cells(sources,mesh):
    n=len(sources[0][0]);assert sum(m for c,e,m in sources)==1
    assert all(e>0 and m>0 for c,e,m in sources)
    b=max(max(abs(z)+e for z in c) for c,e,m in sources)
    R=F(ceilq((b+F(1,2))*mesh),mesh);h=F(1,mesh);K=int(R/h)
    cells=[]
    for index in product(range(-K,K),repeat=n):
        box=tuple((i*h,(i+1)*h) for i in index)
        el,eu,rl,ru=envelope(box,sources)
        cells.append({'id':list(index),'box':box,'volume':h**n,'energy_lower':el,'energy_upper':eu,'raw_lower':rl,'raw_upper':ru})
    assert sum(c['volume'] for c in cells)==(2*R)**n
    return cells,b,R

def root_radius(m,A,n,bits=20):
    lo=0;hi=1<<bits
    while hi-lo>1:
        mid=(lo+hi)//2
        if F(2*mid,1<<bits)**n<=A*m:lo=mid
        else:hi=mid
    r=F(lo,1<<bits)
    assert (2*r)**n<=A*m<F(2*(lo+1),1<<bits)**n
    return r

def cap_cubes(sources,parts,A):
    n=len(sources[0][0]);flat=[i for P,c in parts for i in P]
    assert sorted(flat)==list(range(len(sources)))
    cubes=[];payload=[]
    for P,center in parts:
        assert len(center)==n
        mass=sum((sources[i][2] for i in P),F(0));r=root_radius(mass,A,n)
        box=tuple((z-r,z+r) for z in center)
        contains=all(all(abs(sources[i][0][j]-center[j])+sources[i][1]<r for j in range(n)) for i in P)
        cubes.append(box)
        payload.append({'source_labels':list(P),'center':[str(z) for z in center],
            'mass':str(mass),'halfside':str(r),'volume':str(vol(box)),
            'strictly_contains_assigned_source_support':contains})
    assert sum(vol(c) for c in cubes)<=A
    return tuple(sorted(set(cubes))),payload

def union_atoms(cubes):
    n=len(cubes[0]);edges=[sorted({x for c in cubes for x in c[j]}) for j in range(n)]
    atoms=[]
    for inds in product(*(range(len(e)-1) for e in edges)):
        box=tuple((edges[j][i],edges[j][i+1]) for j,i in enumerate(inds))
        mid=tuple((a+b)/2 for a,b in box)
        if any(in_box(mid,c) for c in cubes):atoms.append(box)
    return atoms

def grid_cap_intersections(atoms,mesh,n):
    h=F(1,mesh);values={}
    for atom in atoms:
        ranges=[range(floorq(lo*mesh),ceilq(hi*mesh)) for lo,hi in atom]
        for ids in product(*ranges):
            cell=tuple((i*h,(i+1)*h) for i in ids);meet=intersection(atom,cell)
            if meet:values[ids]=values.get(ids,F(0))+vol(meet)
    assert sum(values.values(),F(0))==sum((vol(a) for a in atoms),F(0))
    assert all(v<=h**n for v in values.values())
    return values

def retained_fragments(box,cubes):
    edges=[sorted({lo,hi}|{z for c in cubes for z in c[j] if lo<z<hi}) for j,(lo,hi) in enumerate(box)]
    kept=[]
    for inds in product(*(range(len(e)-1) for e in edges)):
        sub=tuple((edges[j][i],edges[j][i+1]) for j,i in enumerate(inds))
        mid=tuple((a+b)/2 for a,b in sub)
        if not any(in_box(mid,c) for c in cubes):kept.append(sub)
    return kept

def raw_outside_tail(n,b,R):
    from math import comb
    return sum((F(comb(n-1,k))*b**k/((n+k)*(R-b)**(n+k)) for k in range(n)),F(0))/2**(n+1)

def sum_round(x,bits=52,upper=False):
    d=1<<bits
    return F(ceilq(x*d) if upper else floorq(x*d),d)

def adaptive_cap_result(cells,sources,parts,A,mesh,b,R,name):
    cubes,packet=cap_cubes(sources,parts,A)
    return evaluate_cap(cells,sources,cubes,packet,A,mesh,b,R,name)

def evaluate_cap(cells,sources,cubes,packet,A,mesh,b,R,name):
    n=len(sources[0][0])
    atoms=union_atoms(cubes);actualvol=sum((vol(x) for x in atoms),F(0));assert actualvol<=A
    intersections=grid_cap_intersections(atoms,mesh,n)
    el=eu=rl=ru=F(0);unknown=False;fragment_count=0;singular_cells_refined=0
    digest=[];cap_in_domain=F(0)
    for c in cells:
        removed=intersections.get(tuple(c['id']),F(0));assert removed<=c['volume']
        cap_in_domain+=removed;retained=c['volume']-removed
        el+=sum_round(retained*c['energy_lower']);rl+=sum_round(retained*c['raw_lower'])
        if not retained:continue
        if c['energy_upper'] is not None:
            eu+=sum_round(retained*c['energy_upper'],upper=True)
            ru+=sum_round(retained*c['raw_upper'],upper=True)
        else:
            subs=retained_fragments(c['box'],cubes)
            assert sum((vol(x) for x in subs),F(0))==retained
            singular_cells_refined+=1
            for sub in subs:
                fragment_count+=1;lel,ue,lrl,ur=envelope(sub,sources)
                digest.append([[str(a),str(b)] for a,b in sub])
                if ue is None:unknown=True
                else:
                    eu+=sum_round(vol(sub)*ue,upper=True)
                    ru+=sum_round(vol(sub)*ur,upper=True)
    assert cap_in_domain<=actualvol
    tail=raw_outside_tail(n,b,R)
    out={'name':name,'budget':str(A),'packets':packet,'unique_cap_cubes':len(cubes),
         'actual_global_union_volume':str(actualvol),'cap_volume_inside_receiver_domain':str(cap_in_domain),
         'sum_individual_cube_volumes':str(sum(F(p['volume']) for p in packet)),
         'overlap_volume_charged_once':str(sum(F(p['volume']) for p in packet)-actualvol),
         'union_disjoint_face_atoms':len(atoms),
         'strict_all_assigned_source_containment':all(p.get('strictly_contains_assigned_source_support',False) for p in packet),
         'same_source_digest':source_digest(sources),
         'same_cap_excess_lower':str(el),'same_cap_excess_upper':None if unknown else str(eu),
         'same_cap_raw_lower':str(rl),'same_cap_raw_upper_including_outside_receiver_tail':None if unknown else str(ru+tail),
         'raw_outside_receiver_tail_upper':str(tail),'singular_grid_cells_refined':singular_cells_refined,
         'retained_face_fragments':fragment_count,
         'retained_fragment_geometry_sha256':hashlib.sha256(json.dumps(digest,separators=(',',':')).encode()).hexdigest(),
         'status':'UNKNOWN_RETAINED_INFINITE_ENVELOPE' if unknown else 'FINITE_ONE_CAP_ALL_SCALE_CERTIFICATE',
         'display_only_excess':[float(el),None if unknown else float(eu)],
         'chosen_before_cost_comparison':True,'cap_independent_of_L':True,'cost_rounding_bits':52}
    return out

def box_source_mass(box,sources):
    total=F(0)
    for c,e,m in sources:
        source=tuple((z-e,z+e) for z in c)
        meet=intersection(box,source)
        if meet:total+=m*vol(meet)/(2*e)**len(c)
    return total

def stopping_reference(cells,sources,mesh,b,R):
    n=len(sources[0][0]);rootR=F(1)
    while rootR<b or (2*rootR)**n<4:rootR*=2
    root=tuple((-rootR,rootR) for j in range(n))
    assert box_source_mass(root,sources)==1 and 1/vol(root)<=F(1,4)
    # Actual source faces are dyadic. At this depth every leaf is a region
    # of constant source density; all positive density in these fixtures >1.
    face_denominator=max((z-e).denominator for c,e,m in sources for z in c)
    face_denominator=max(face_denominator,max((z+e).denominator for c,e,m in sources for z in c))
    assert face_denominator&(face_denominator-1)==0
    per_coordinate_depth=int(2*rootR).bit_length()-1+face_denominator.bit_length()-1
    maxdepth=n*per_coordinate_depth
    assert all(m/(2*e)**n>1 for c,e,m in sources)
    stack=[(root,0)];bad=[];good_mass=F(0);visited=0
    while stack:
        box,depth=stack.pop();visited+=1;mass=box_source_mass(box,sources)
        if not mass:continue
        avg=mass/vol(box)
        if avg>F(1,4):
            assert avg<=F(1,2)
            bad.append((box,mass,depth));continue
        if depth==maxdepth:
            # This branch should have constant low density. Its true mass
            # is retained as good, rather than silently discarded.
            assert avg<=F(1,4)
            good_mass+=mass;continue
        j=depth%n;mid=sum(box[j])/2
        left=list(box);right=list(box);left[j]=(box[j][0],mid);right[j]=(mid,box[j][1])
        stack.extend([(tuple(right),depth+1),(tuple(left),depth+1)])
    Wbad=sum((m for box,m,depth in bad),F(0));assert Wbad+good_mass==1
    assert Wbad==1 and good_mass==0
    delta=F(1,n);expanded=[];packets=[];widths={}
    for box,mass,depth in bad:
        ell=max(hi-lo for lo,hi in box)
        assert ell<=2*min(hi-lo for lo,hi in box)
        widths[ell]=widths.get(ell,F(0))+mass
        cap=tuple(((lo+hi)/2-(1+delta)*(hi-lo)/2,(lo+hi)/2+(1+delta)*(hi-lo)/2) for lo,hi in box)
        expanded.append(cap)
        packets.append({'bad_cell':[[str(lo),str(hi)] for lo,hi in box],
            'mass':str(mass),'average_density':str(mass/vol(box)),
            'max_side_ell':str(ell),'depth':depth,'volume':str(vol(cap)),
            'assigned_source':'actual restriction nu|bad_cell',
            'strictly_contains_assigned_source_support':all(cap[j][0]<box[j][0] and box[j][1]<cap[j][1] for j in range(n))})
    budget=4*(1+delta)**n*Wbad
    result=evaluate_cap(cells,sources,tuple(expanded),packets,budget,mesh,b,R,'cyclic_stopping_enlarged_cap')
    assert sum(vol(x) for x in expanded)<=budget
    # sigma is constant average on each disjoint bad rectangle; good=0.
    # The separate coverage lemma is quoted as a bound, not an experiment.
    llog,hlog=log_bounds(F(16*n*n));theorem_upper=Wbad*hlog
    result.update({'root_box':[[str(lo),str(hi)] for lo,hi in root],
        'cyclic_grid_origin':'translated by the root lower corner; this root and its cyclic ancestors are compatible grid cells; source outside root is zero',
        'root_average':str(1/vol(root)),'visited_binary_cells':visited,
        'maximum_allowed_depth':maxdepth,'bad_cell_count':len(bad),
        'bad_source_mass':str(Wbad),'retained_good_source_mass':str(good_mass),
        'bad_density_min':str(min(m/vol(box) for box,m,d in bad)),
        'reference_density_max':str(max(m/vol(box) for box,m,d in bad)),
        'reference_mass':'1','enlargement_delta':str(delta),
        'bad_source_mass_by_max_side':[[str(ell),str(m)] for ell,m in sorted(widths.items())],
        'source_mass_weighted_max_side_squared':str(sum((m*ell*ell for ell,m in widths.items()),F(0))),
        'reference_displacement_upper':str(max(widths)),
        'coarse_transport_tail_cutoff':str(2*n*max(widths)),
        'mass_cutoff_R_kappa':'1',
        'coverage_near_occupation_theorem_domain_n_ge_2':n>=2,
        'near_occupation_theorem_upper_not_measurement':str(theorem_upper) if n>=2 else None,
        'near_occupation_theorem':'Wbad*log(16n^2), cyclic rectangle aspect<=2, delta=1/n',
        'near_high_energy_via_total_RAW_upper':result['same_cap_raw_upper_including_outside_receiver_tail'],
        'near_high_upper_reason':'0<=N_L<=T_Lnu, so (N_L-1/3)_+^2<=T_Lnu^2; this is not a computed N profile',
        'separate_budget_not_A_le_1_menu':True})
    return result

def grid_reference(sources):
    n=len(sources[0][0]);rows=[]
    for j in range(7):
        h=F(1,64)*2**j;mass={}
        for c,e,m in sources:
            for ids in product(*(range(floorq((z-e)/h),ceilq((z+e)/h)) for z in c)):
                v=F(1)
                for z,i in zip(c,ids):v*=max(F(0),min(z+e,(i+1)*h)-max(z-e,i*h))/(2*e)
                if v:mass[ids]=mass.get(ids,F(0))+m*v
        assert sum(mass.values(),F(0))==1
        maximum=max(mass.values());valid=maximum<=h**n
        rows.append({'h':str(h),'occupied_physical_cells':len(mass),
            'largest_cell_mass':str(maximum),'largest_reference_density':str(maximum/h**n),
            'certified_reference_density_at_most_kappa':valid})
        if valid:
            return {'fixed_origin_grid':True,'tested_scales':rows,'displacement_upper':str(h),
                'near_tail_cutoff_R':str(2*n*h),'mass_cutoff_R_kappa':'1',
                'R_over_mass_cutoff':str(2*n*h),
                'tail_estimate_budget_at_cutoff':'1',
                'certified_tail_starts_after_all_possible_positive_excess':2*n*h>=1,
                'transport':'source restriction on each physical grid cell product-coupled to same-cell uniform reference; exact cell mass is preserved; every displacement <= h',
                'not_optimized_displacement':True}
    raise AssertionError('h=1 must admit density<=1 for a probability source')

def source_case(name,sources,parts,mesh):
    sources=tuple(sources);cells,b,R=grid_cells(canonical_sources(sources),mesh)
    assert source_digest(sources)==source_digest(canonical_sources(sources))
    curves=[]
    for A in BUDGETS:
        lower,_=trim_bound(cells,A,'energy_lower')
        caprows=[adaptive_cap_result(cells,sources,P,A,mesh,b,R,key) for key,P in parts]
        for row in caprows:
            if row['same_cap_excess_upper'] is not None:assert lower<=F(row['same_cap_excess_upper'])
        comparisons={}
        for i in range(len(caprows)):
            for j in range(len(caprows)):
                if i!=j and caprows[j]['same_cap_excess_upper'] is not None:
                    gap=F(caprows[i]['same_cap_excess_lower'])-F(caprows[j]['same_cap_excess_upper'])
                    comparisons[f'cap{i}_lower_minus_cap{j}_upper']={'gap':str(gap),'strict_actual_cost_order_certified':gap>0}
        curves.append({'budget':str(A),'arbitrary_measurable_cap_optimum_lower':str(lower),
                       'source_adapted_caps':caprows,'same_source_same_budget_selected_cap_comparisons':comparisons})
    encoded=[[c['id'],str(c['volume']),str(c['energy_lower']),None if c['energy_upper'] is None else str(c['energy_upper'])] for c in cells]
    return {'name':name,'n':len(sources[0][0]),'actual_uniform_box_mixture':source_payload(sources),
        'physical_source_digest':source_digest(sources),'mesh':mesh,'receiver_R':str(R),'source_radius_b':str(b),
        'true_full_receiver_volume':str((2*R)**len(sources[0][0])),'native_receiver_grid_cells':len(cells),
        'energy_envelope_sha256':hashlib.sha256(json.dumps(encoded,separators=(',',':')).encode()).hexdigest(),
        'actual_source_label_count':len(sources),'distinct_physical_components':len(canonical_sources(sources)),
        'all_scale_excess_complement':'L>=1 zero; outside [-R,R]^n zero; all smaller scales integrated analytically',
        'curves':curves,'coarse_bounded_density_reference':grid_reference(sources),
        'cyclic_stopping_cap':stopping_reference(cells,sources,mesh,b,R)}


def run(stage_limit='expanded'):
    s1=(((F(0),),F(1,4096),F(1,2)),((F(1,32),),F(1,512),F(1,4)),
        ((F(3,4),),F(1,128),F(1,8)),((F(2),),F(1,256),F(1,8)))
    single1=[((i,),c) for i,(c,e,m) in enumerate(s1)]
    merged1=[((0,1),(F(1,64),)),((2,),s1[2][0]),((3,),s1[3][0])]
    s2=(((F(-1,8),F(-1,8)),F(1,1024),F(3,8)),
        ((F(-1,16),F(1,16)),F(1,512),F(1,8)),
        ((F(1,16),F(-1,16)),F(1,256),F(1,8)),
        ((F(1,2),F(1,2)),F(1,128),F(1,8)),
        ((F(3,4),F(1,4)),F(1,64),F(1,8)),
        ((F(3,4),F(3,4)),F(1,32),F(1,8)))
    single2=[((i,),c) for i,(c,e,m) in enumerate(s2)]
    merged2=[((0,1,2),(F(-1,32),F(-1,32)))]+[((i,),s2[i][0]) for i in range(3,6)]
    s3=(((F(0),F(0),F(0)),F(1,512),F(1,2)),
        ((F(1,4),F(0),F(0)),F(1,128),F(1,8)),
        ((F(0),F(1,4),F(0)),F(1,64),F(1,8)),
        ((F(0),F(0),F(1,4)),F(1,64),F(1,8)),
        ((F(1,2),F(1,2),F(1,2)),F(1,32),F(1,8)))
    single3=[((i,),c) for i,(c,e,m) in enumerate(s3)]
    merged3=[((0,1,2,3),(F(1,8),)*3),((4,),s3[4][0])]
    out=[]
    for stage,sources,parts,mesh in [('pilot',s1,[('singleton_components',single1),('predeclared_near_cluster',merged1)],64),
         ('stress',s2,[('singleton_components',single2),('predeclared_correlated_cluster',merged2)],16),
         ('expanded',s3,[('singleton_components',single3),('predeclared_3D_cluster',merged3)],8)]:
        case=source_case(stage+'_multiscale_actual_L1',sources,parts,mesh)
        record={'stage':stage,'physical_case':case}
        if stage=='stress':
            split=tuple([(s2[0][0],s2[0][1],s2[0][2]/8)]*8+list(s2[1:]))
            singleton=[((i,),c) for i,(c,e,m) in enumerate(split)]
            merged=[(tuple(range(8)),s2[0][0])]+[((i,),split[i][0]) for i in range(8,len(split))]
            # Same physical law and same grid envelopes are deliberately reused.
            basecells,b,R=grid_cells(canonical_sources(s2),mesh)
            assert canonical_sources(split)==canonical_sources(s2)
            checks=[]
            for A in BUDGETS:
                simple=adaptive_cap_result(basecells,split,singleton,A,mesh,b,R,'coincident_label_singletons')
                fixed=adaptive_cap_result(basecells,split,merged,A,mesh,b,R,'coincident_labels_merged')
                old=next(x for x in case['curves'] if F(x['budget'])==A)['source_adapted_caps'][0]
                assert fixed['actual_global_union_volume']==old['actual_global_union_volume']
                assert fixed['same_cap_excess_upper']==old['same_cap_excess_upper']
                assert fixed['same_cap_raw_upper_including_outside_receiver_tail']==old['same_cap_raw_upper_including_outside_receiver_tail']
                checks.append({'budget':str(A),'split_component_singleton_cap':simple,'coincident_merge_cap':fixed,
                    'exact_merge_restores_original_singleton_cap':True,
                    'split_minus_original_union_volume':str(F(simple['actual_global_union_volume'])-F(old['actual_global_union_volume'])),
                    'split_lower_minus_original_upper':None if old['same_cap_excess_upper'] is None else str(F(simple['same_cap_excess_lower'])-F(old['same_cap_excess_upper']))})
            record['same_physical_input_label_pressure']={'not_a_new_physical_input':True,
                'split_actual_source_labels':source_payload(split),'physical_source_digest':source_digest(split),
                'source_equality':'coalescing exactly equal center+halfwidth labels recovers the identical density',
                'curves':checks}
        out.append(record)
        print(json.dumps({'stage':stage,'new_actual_grid_cells':case['native_receiver_grid_cells'],'cap_records':sum(len(c['source_adapted_caps']) for c in case['curves'])}),flush=True)
        if stage==stage_limit:break
    return {'schema':'R95-continuum-multiscale-source-adapted-onecap-v1','mass':'1','kappa':'1',
        'all_sources_actual_positive_L1':True,'public_neutral_strategy_tests':True,
        'original_Fnew_claimed':False,'partitions_and_sources_fixed_before_comparison':True,
        'stages':out,'general_uniform_cap_energy_bound':'UNPROVED; deterministic finite strategies and envelopes do not imply a fitted exponent',
        'volume_units':'original n-dimensional Lebesgue measure; overlaps charged once; global cap volume includes any part beyond receiver domain',
        'raw_tail':'outside receiver domain retained as an explicit all-scale upper; never set zero'}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',default=str(Path(__file__).with_name('energy_results.json')))
    parser.add_argument('--stage-limit',choices=['pilot','stress','expanded'],default='expanded')
    args=parser.parse_args();start=time.perf_counter();result=run(args.stage_limit)
    Path(args.output).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'output':args.output,'seconds_diagnostic':time.perf_counter()-start}),flush=True)
