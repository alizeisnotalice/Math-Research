# 中心立方体第95轮：共同删集的全尺度预算与薄环路线审计

2026-10-12。一般正L1输入上的 n^(1/2+o(1)) 一致弱型上界仍未证明。本轮直接处理任意输入，保留真实勒贝格接收测度、全部尺度与原分层费用；没有把固定来源检验当成一般证明。

新的循环二分矩形分解为任意来源给出同一删集、同一有界密度参考与实际共同运输。删集体积系数至多4e，近来源全部尺度的一阶占用只有对数费用。再加入由实际占用势选择的一个删集，可付清全部高负载和尺度持续长度，得到A≤4e+1、B≤n log(32n²)log(16n²)/(1−2^(−n))。这是真正一般的共同删集能量估计，但回代只给O(n log n)基准，未达到所需子幂能量系数。

自适应递推的新增长势证明本身正确，且保留全部子分类、源退出和终项；最终结果却被更强的直接单输入分解支配。剩余初始边界量的根阶预算与原余集目标等价，因此本轮将此路线记为局限已经查明的尝试，不把改写余项算作新增几何收益。

另保留两项一般或条件工具：同一运输的完整位移尾分布归约；真实有限能量势残差 b=−Δu 的维数无关远尺度平方能量常数20。它们均未支付一般近尺度高负载。原粗门的两档全窗口检验仍UNKNOWN，已严格识别所用线性上界方法的局限，不能据此判实际粗门失败；第94轮硬见证与原P1上门交集的既有资格仍有效。

八个职责保持三名Astra high路线、Astra high与Sol high独审、两名Sol high数值、一名Sol high原文与更新技能。覆盖角色连接中断后由同模型恢复角色接续已保存证明，不重复路线。所有重要新命题先独立审量词和反例，再读完整MD/TeX。公开能量、私人粗门和主代理运输程序由作者、两审及主代理分别实际执行；替代路线程序另由Sol和主代理重放，自适应程序有主代理重放回执，原文组46/600项检查是作者执行范围。详细LaTeX仅保存文本和静态核验，不编译PDF。私人构造和量化下界结论留本地。


## 第95轮保留主账与剩余量（第94轮及更早结论按历史节保留）

令 `mu=f dy`，`Q(x,L)=x+[-L/2,L/2]^n`，`L in [1,2]`，需求为真实 `lambda dx`。保持原锚点 `A_1 f < lambda/2`、原平滑核的全窗口上界、严格后见证、原最早硬接触 `A_L* f=lambda` 及原中间下限 `exp(-s_n)/2`。每次实际删源并重选时重新检查全部门；来源主闭包保旧接触及旧前缀，不自动保原中间下限或严格后见证。

设 `H=1+n log 2`，`theta=log^-2(n+2)`，`alpha=epsilon=1/[10log(n+2)]`，`c=1-alpha-epsilon`，`beta=c/2`。已付费用完整保留：

- `B_base=4+2log2 sqrt(7n/3)`，`B_ext=2H/sqrt(n+2)`。
- `T_soft=1+log2 min(2n,sqrt[n(theta^-1+4theta/3)])`，粗平滑付 `T_soft/alpha`。
- 原包网格 `h0=1/(16n^2)`，`a=n^-p`、`rho=n^-1/2`，`p>0` 为原先固定值；`P_dom=(5+3log(1/a))/rho`。
- `h*=1/(16n^(3/2))`，`E=exp(nh*)`，`B_h=1+E[1+(2n^2+n)h*]`。后验物理碰撞至少 `3/4` 或平均网格熵至多 `sqrt n` 的并集一次支付 `P_phys=2[E+B_h+2(1+E)sqrt n]`。
- 完整未付余集 `Fnew=Fdiff ∩ {C_h*<3/4, Hbar_h*>sqrt n}`；`Fdiff` 为原粗平滑低中间分支删除原 dominant-packet 事件后的集合。

只有支付整个 `Fnew` 的 `D_new` 才能代入

`C_n^square <= C_loc log(n+2)[B_base+B_ext+T_soft/alpha+P_dom+P_phys+D_new]`。

若逐原 `kappa=1+log[lambda/(2P_1,L*)]` 二进层证明，则另付 `J_n=O(log n)`；第90轮薄片分支及本轮有限浓缩轮廓均未证明覆盖并支付整个 Fnew，原主账尚未因此得到一般新收益；这些层或全尺度费用均保留。私人诊断使用的某个 `p` 值只认证其对应分支，不能把该值替换原账上任意指定的 `p`。

### 保留的容量、规范方差与通量接口

对每个正规紧致 `B subset Fnew`、连续原尺度和每个正主割 `(A_s,S_s)`，真实源邻域等于 `S_s`（模 mu），`D_s=lambda|A_s|=integral_Ss b* dmu`。规范列 `b_A<=H`。第88轮已证明：若对每个这样的主割重新计算均有 `I_T(A_s)<=R_n mu(S_s)/n`，`T=sqrt(24nR_n+96)`，则所有割比至多 `2T`，经 Lusin、内正则性与 Borel Hall 得完整条件回代。所需 `R_n=n^{o(1)}` 尚未证明。

一般可测停止图保精确通量 `D-a=B_face-V_bulk`，且整体锚点 `a<=mu(S)`。故 `B_face-V_bulk<=C_root mu(S)+D/2` 足以推出 `D<=2(1+C_root)mu(S)`；仅凭逐点锚点小于半接触不能替代整体锚点预算。两项的逐正部分估计仍各为线性维数。第89轮配对抽样保留了该有符号差；第90轮有限厚度只支付其中一部分，完整差尚无统一根阶上界。

### 第90轮保留工具及其互补项

有限厚度 δ 的真实面替代项具有精确费用 a_n(δ)log2·M，a_n(δ)=E(Bin(n,δ)−nδ)_+/δ≤(1/2)sqrt[n(1−δ)/δ]。固定 δ=1/2 确实是根阶。完整余项仍为同一来源的平移差与两个接收行停止函数差的乘积积分；它没有消失。仅以来源 L1 平移模量支付时，允许 δ 依赖输入也存在至少 nM/2 的证书费用障碍。这不是对实际有符号余项或主割容量的反例。

部分坐标薄片分支的已证单包费用为 [1+(n−k)log2]prod_j(1+h_j)。一组共同来源包保留真实捕获份额，得到其分支的全子割支付；有限包覆盖的遗漏源还按 H_n W_bad/τ 显式支付。任意来源尚无满足根阶费用的此类覆盖；总坐标原子质量不足以推出接近全坐标的少包覆盖。若将这一分支加入原递推，每一步新费用与全部旧费用、阈值权重 t_i 及最终 H_n t_ell W_ell 必须保留；主账没有把该分支虚加为一般收益。原第89轮持续高负担逼出的坐标原子约束仍是必要条件，不是矛盾。

精确奇异平面模型中，sup_L L^(-k)A_L 的正核包络具有 1+m/k 型系数，但正常接收纤维的需求是 λ∫T^k。逐纤维层蛋糕回代恢复 1+(m+k)log2；直接已证费为 1+m log2。更强的真实弱型费尚未证明，也没有被该记账障碍否定。

Gamma 平滑的新增一般转移定理要求一个真实共同阈值事件并集、统一上下有界周期密度，以及完整维数/截断费用。它为任何共同 Cesàro 主项加全尺度误差的比较给出必要误差费用 (sqrt(B)−sqrt(A))_+²；没有构造该误差的上界。真实目录应用与新下界结论留在私人区，不在公开包中。直接假设 Gamma 极大族的 subpower 弱型界不再作为可用工具。

原 P1 与 coarse 的 Fourier 乘子、连续相位/尺度包络、级数尾及正有限截断方向已从定义证明。实际物理证书及其失败范围见数值节。连续首次接触和全窗口软上界均不能单独代替完整 Fnew；单元检验不涵盖未被选择的接收集或主来源割。一般规范高列方差、共同有符号差、来源集中跨层费用和完整回代均继续开放。

### 第93轮新递推替代及剩余几何费用

旧全需求方案的beta^(-i)加权占用依旧不能假定可付；第93轮改用部分需求运输，不再依赖该假设。每个继续接收行只先付(1−beta)lambda_i，其余lambda_(i+1)留给子状态。子分类异常必须按父阈值足额支付A_old W_(i+1)/beta。真实删源只退出一次，真实嵌套环对每对(x,y)只出现一次。

令u=1−epsilon，a_part=2/c−1，b_part=2/c，K=2 A_old u/[beta(1−beta)]，psi(z)=max(1,2||z||inf)^(-n)1_{||z||inf<=1}，其积分H_n=1+nlog2。真实势Psi_i=∫mu_i(dy)∫B_i psi(x−y)1_Qi(y)dx，P_i=b_part K W_i+a_part Psi_i。严格证明 .5(D_i−D_(i+1))<=P_i−P_(i+1)，在无限活跃链上D_m、P_m都趋零；若有限步接收集为空，则D_terminal=0，可能非零的P_terminal以正确符号丢弃，故D_0<=2(b_part K+a_part H_n)W_0。A_old为原全部已付分类费用，原全尺度和分层返回另行保留。

这真正支付了原来源质量下的阈值漂移、源退出、子分类和终项，不再把D_0占用账当作W_0预算。但其几何项仍为线性H_n。精确恒等式Psi_i=D_i+n∫B_i∫1^L_i T_s mu_i ds/s dx说明Psi_i本身包含需求；把初始Psi替换为根阶上界仍需新的几何证明，不能视作现成弱于目标的条件。只有改善真实累积环流容量或构造有已付缺陷的新势，才能得到目标收益。

### 第93轮一般能量路线的精确接口

原全尺度共同删集条件不变：对每个来源nu及kappa，有一个独立于L的Omega，体积<=A W/kappa、外部正超额平方能量<=B kappa W，则弱常数<=4A+2sqrt(2nAB)。对子阈值输入、弱极限及任意L1的合法传递只用已证条件，不能由有限证书推出A、B子幂。

真实共同接收交叠核K_n(d)=∫_{||d||inf}^∞ L^(-2n−1)∏(L−|d_j|)dL给出全部尺度交叉能量。其逐点界为||d||inf^(-n)/[n(n+1)]，多坐标最大位移有beta积分折扣；但其完整环域积分恰为log(b/a)，不因n变小。不得把逐点折扣直接称作一般来源对总量的降维费用。

若nu=Σnu_j且每个真实簇支持在Q(c_j,epsilon(W_j/kappa)^(1/n))，同一Omega=∪Q(c_j,(W_j/kappa)^(1/n))体积<=W/kappa，外部能量<=kappa W b_n(epsilon)/n+2Σ_{i<j}∬K_n(y−z)dnu_i dnu_j。所有自身项已付；交互项和任意输入的合法分解尚未统一。有限原子可取单原子分解，但交互费用可能很大；一般有界密度还受C epsilon^n>=1的必要条件约束，不能假定浓缩分解总存在。来源中心的小簇上界可改进自身项，不消去任意来源交互。

Phi_a(e)=inf_|Omega|<=a∫Omega^c e 的精确阈值对偶、扩展无穷情形和尺度预算分配已直接证明。带尺度标签空间会重复计接收体积；其最优预算分配只给原空间上界，不等于原空间最优费用。没有作未合法的sup/inf交换或由凸矩极点替代非线性能量目标。

实际方体尺度差分S_L=A_L−A_(2L)具有L2(dx dL/L)平方范数上界18+2logn。但标准抵消平方函数端点包含2^n与R^n费用，原正超额与抵消能量之间尚无共同删集支配。文献定理和此新L2工具不能自动填补这一缺口。

### 第93轮数值资格范围

新中性有限原子测试保留7520连续区域的真实体积、32共同删集预算，31有限上界及1网格UNKNOWN；20项分离族闭式校准不代表一般高维输入。完整周期Haar检验保留有限乘积似然和全部n个区间宽度，证得正体积固定节点硬见证及每坐标完整投影；原全窗平滑上门、粗门仍UNKNOWN，不能声称Fnew体积、主割负担、完整覆盖或根阶上界。私人来源和新构造反例只留本地。总目标继续开放。


### 第94轮：部分需求递推的根阶已付部分与精确薄环缺口

第93轮全体环流由线性 H_n 势支付。第94轮构造 Xi_i=Psi_i−D_i 的非负、随实际限制和嵌套而递减的真实前缀势；这不是从旧下降式免费减去需求。对深环对 psi>=M L_i^(-n)，势损失至少(M−1)倍真实旧硬核，故全部阶段深环累计<=H_n W_0/(M−1)。同时对旧尺度L_i<=M^(1/n)的环流，截断包络U_i的根预算为(1+logM)W_0。

低尺度、其余深环和其余薄环按次序分成不交三类。最后一类满足 L_i>M^(1/n) 且 L_i/M^(1/n)<2||x−y||inf<=L_i，外层相对厚度小于logM/n。令 C_M=bK+a(1+logM)+aH_n/(M−1)，修正势 P_i^M=bKW_i+aU_i+aXi_i/(M−1)。按真实运输重新推导得

(D_i−D_(i+1))/2 <= P_i^M−P_(i+1)^M+aJ_i^thin。

K、父阈值子分类、源退出等沿用完整第93轮费用。无限活跃链终项趋零；有限接收空集停止只丢弃非负终项；未完成有限前缀保留D_m−2P_m^M。于是完整初始局部事件<= (A_old+2C_M)W_0+2aΣJ_i^thin。取M=1+sqrt(n)，所有显式系数为根阶乘对数；ΣJ_i^thin尚只有线性包络。它须在真实完整原条件的递推上支付，不能用未通过原接触/门条件的几何压力模型否定或证明。全尺度与原kappa分层费用仍在。

### 第94轮：取消平方函数与正超额的实际连接

实际立方体 S_L=A_L−A_(2L) 的全尺度L2平方范数可改进为 C_*=1645/144<12，维数无关；证明直接从sinc乘子给出，不假定尺度增量正交。对0<=g<=Mκ，整个取消能量<=C_* MκW。其弱型端点的2^n好函数密度、R^n共同膨胀等几何费用没有消失。

对任意非负L1输入，以同一Omega={f>κ}和R=(W/κ)^(1/n)，已证明实际正超额能量<=4∫Omega^c∫_0^(R/2)log_2(R/L)^2 |S_L f|² dL/L dx。两个端点的基线已付：小尺度用微分定理和实际密度删集，大尺度用总质量。细尺度log²权重保持，不能由不加权L2界丢掉。固定对数带可支付，全部细尺度尾及改良共同删集仍需来源质量预算。变差文献仅p>1、r>2，有限跨越数量不支付尺度持续长度。

### 第94轮：证据与覆盖资格更新

本轮私人交互压力直接构造真正正L1来源，无能量弱极限交换；只排除指定的过强交互证书，不能称作弱型下界或最佳删集障碍。原子的7项价格/19项上包络与新增21项弥散配置/57项上包络分开记录。包络积分下端点不是实际能量下界。

本轮公开数值合计9个不同物理来源律。2923个连续单元对应28项网格删集预算（26有限、2粗包络UNKNOWN）；另24项固定方体删集预算（23有限、1该删集UNKNOWN），最高维同帽加密不计新输入。守卫独立重建全部单元和删集体积，以及2项固定帽全尺度RAW能量；不声称独立重建全部网格能量。全周期软门新增资格详见下节。未知门和覆盖补集不置零，没有有限检验被用来推断一般指数，主目标继续未证明。

### 第94轮：真实运输支付长尺度与共同删集近交互

对任意正来源ν，若同质量参考测度σ=s dz满足0<=s<=κ，并有同一个真实耦合支持于||y−z||inf<=d，则对任何同一接收删集Ω及R>=2nd>0，全部L>=R的正超额能量<=κW(2nd/R)^2。d0时来源本身密度<=κ，超额全为零。证明使用实际扩大捕获cube、质量恒等式∫T_Lν=W和阈值保留；不是未扣阈值的原始平方比较。

令q_j=T_Lν_j，q=Σq_j，Dκ(t)=t²−(t−κ)+²。精确相互作用Cκ=(q−κ)+²−Σ(q_j−κ)+²非负，并至多[1−(κ/q)²]+·2Σi<j q_iq_j（q0另定义0）。这一扣除先在同一(x,L)执行，再积分；不能作∞−∞。屏蔽后的共同域核依赖总来源与κ，其长尺度交互也可付<=3κW·2nd/R。

因此浓缩来源簇若另满足质量尺度cap内点互不交，可将远相互作用全部替换成κW费用，剩余只在L<R、同一Ω外且总平均越阈的交互。cap不交、合法分解及足够小的运输位移都不是任意输入自动满足的条件。粗网格确能给密度参考，但R可能超过总质量的零超额截断，因而没有收益。一般细尺度耦合和共同近交互仍缺。

### 第94轮：原全周期验证的新增资格

保持第93轮同一来源、阈值、硬带和完整周期提议测度，新增事件明确定义为原硬带与全窗口原P1平滑上门的交集。定心Fourier矩和全n尾在提议测度下支付失败概率，再用同一硬带的完整似然转换回Haar体积。初探截断不足而UNKNOWN；预先指定的加密版本得到正体积下界。没有将提议测度失败概率直接从Haar下界相减，没有推出新交集仍有各坐标全投影。原粗门、完整Fnew、首触精确位置和高负载均未获认证。原中门及包指数0<p<=n的保留域没有因此扩大，域外仍未知。


### 第95轮：所有输入的共同删集与完整预算

循环二分矩形每次体积减半，最大坏矩形的均值落在(κ/4,κ/2]；坏矩形互不交，余源密度≤κ/4。逐坏矩形均匀化与余源恒等给同一个参考密度≤κ/2和实际共同耦合。对δ=1/n，单一扩大矩形并集Ωδ的体积≤4e Wbad/κ。短位移标签在每个尺度共用参考密度，一次吸收至2κ/3；剩余近场N在同一Ωδ外全尺度一阶占用≤Wbad log(16n²)。低高度正超额能量已付，高高度二阶不能由一阶自动支付。

扩大标签截止由8nℓ改16nℓ，令h(x)=∫Nhat(x,L)dL/L。实际正性延续给N≤c_n h，c_n=n/(1−2^-n)。再删h>Tκ部分，体积系数Aδ,T≤4(1+δ)^n+log(32n/δ)/T，能量系数Bδ,T≤c_nTlog(16n/δ)。取δ1/n、Tlog(32n²)，对全部正L1输入得到A≤4e+1、B≤nlog(32n²)log(16n²)/(1−2^-n)。这已付清所有尺度与高层费用，但原能量回代只给O(nlogn)，未改进一般基准。

T=1/n时B为对数，所需额外低阈值帽体积子幂条件只是尚待压力验证的充分条件；h包含低于阈值的背景，不能默认此更强体积界可成立。下一步必须先检验来源稀疏却在粗尺度持续的真实背景，保留阈值后再设计更弱容量命题。

### 第95轮：自适应增长势的有效证明与支配诊断

新算法明确改β=c/4、a=(1−β)/(c−β)、b=1/(c−β)、K=4A_nu/[β(1−β)]，重新运行全部实际门。非单调边界势V_i=∫(L_i^-n−ψ/M)+1_Qi1_{Li>M^(1/n)} dμ_i dx的增长由真实子接触I_i≤Dchild控制。子分类费用吃ΔD/4，aI_i吃ΔD/3，得(5/12)ΔD≤ΔF，所有出口与终项有合法支付。

但直接单输入分解早已给D0≤Bdirect W0+V0，Bdirect=1+logM+Hn/M，严格支配该递推最终界。初始密度截断后D0≤2Bdirect W0+2Q0，且0≤Q0≤D0。因此Q0根阶预算与原余集目标等价，不是更弱的已付前提。本轮把这一正确递推记为未增加几何预算的尝试，防止重复工作。第94轮低/深分支估计照保留；完整薄环/初始高密度余项仍无新根阶支付。

### 第95轮：运输尾、势残差和门资格

同一真实π:ν→s dz≤κdz的位移尾m(t)给每个L的sqrt(F_L)≤sqrt[κ(W−m(t))h((1+2t/L)^n)]+m(t)L^-n/2，h(C)=C+C^-1−2。可对有理t取可测inf并积分到质量截止；异常质量和交叉项不可丢弃。平均位移强替换只作为受压力约束的未可用工具，不据有限矩给一般近能量。

若实际有限签名测度b=−Δu且∇u∈L2，则∫R∞||A_Lb||2²dL/L≤20R^-2||∇u||2²。实际紧支撑obstacle结构m=κ1Ωdx+ν|Ωc≤κdx、ν−m=−Δu给|Ω|≤W/κ，并合法传到共同Ω外正超额。存在性原文范围、有限能量假设、Dirichlet总预算及近尺度剩余均保留；势截断≤hW会新增签名拉普拉斯余项，不是免费正源删除。

原粗门本轮两档完整含根窗口证书均UNKNOWN；精确诊断否定所用全窗周期线性均值上界方法的正余量，未否定实际log或首次根处粗门。第94轮已证硬加P1交集继续有效，完整Fnew与高负载资格仍未证明。原κ分层和全尺度返回全部保留，最终一般n^(1/2+o(1))目标继续开放。


## 1. New all-input reduction and its remaining cost

Let \(n\ge2\), \(f\ge0\) belong to \(L^1(\mathbb R^n)\), \(W=\int f<\infty\), and \(\kappa>0\). Set
\[
 Q(x,L)=x+[-L/2,L/2]^n,\qquad
 T_Lf(x)=L^{-n}\int_{Q(x,L)}f(y)\,dy.
\]
The receiver variable always has its actual Lebesgue measure, and every scale \(L>0\) is retained.

For every such input, this note constructs one source-dependent measurable set \(\Omega_\delta\), a single mass-preserving transport to a density at most \(\kappa/2\), and a jointly measurable near-source field \(N(x,L)\). For \(0<\delta<16n\), the construction satisfies
\[
 |\Omega_\delta|\le4(1+\delta)^n\,\frac{W_{\rm bad}}{\kappa},\qquad
 (T_Lf-\kappa)_+^2\le(N-\kappa/3)_+^2, \tag{1}
\]
and
\[
 \int_{\Omega_\delta^c}\int_0^\infty N(x,L)\,\frac{dL}{L}\,dx
 \le W_{\rm bad}\log(16n/\delta),\qquad W_{\rm bad}\le W. \tag{2}
\]
The same source mass is not charged anew at each scale. Its total logarithmic scale interval is bounded explicitly.

In particular, \(\delta=1/n\) gives a cap of volume at most \(4eW/\kappa\) and the first-moment bound \(W_{\rm bad}\log(16n^2)\). This is an all-input construction, not a hypothesized fine transport. It pays the scale duration and the low-height part of the near field. It does **not** turn a first moment into a second moment: a precise high-height energy remains unpaid. Thus the desired subpower common-cap energy, and the general root-order weak bound, remain open.

## 2. The fixed cyclic binary filtration

Use the following single grid on all of \(\mathbb R^n\). For each integer generation \(k=qn+r\), where \(q\in\mathbb Z\) and \(0\le r<n\), partition space into half-open axis-parallel rectangles whose side lengths are
\[
 a_i(k)=
 \begin{cases}2^{-q-1},&1\le i\le r,\\2^{-q},&r<i\le n.\end{cases} \tag{3}
\]
Their endpoints lie in \(a_i(k)\mathbb Z\). Each refinement splits one coordinate into two equal intervals. Thus every child has half the volume of its parent, all rectangles in all generations form a nested filtration, and their aspect ratios are at most two. Write \(\ell_Q=\max_i a_i(Q)\), so \(\min_i a_i(Q)\ge\ell_Q/2\).

Declare a rectangle bad if
\[
 \frac1{|Q|}\int_Qf>\kappa/4,
\]
and take the maximal bad rectangles under inclusion; denote this countable disjoint family by \(\mathcal B\). This family is well-defined without a compact-support assumption. Along the ancestors of any rectangle the volume tends to infinity, and every ancestor average is at most \(W/|Q_{\rm ancestor}|\), which tends to zero. Therefore each bad rectangle has a maximal bad ancestor. Distinct maximal members are disjoint because any intersecting grid rectangles are nested.

The immediate parent of a maximal bad rectangle is not bad. Its volume is \(2|Q|\), so
\[
 \frac{\kappa}{4}<\frac{W_Q}{|Q|}\le\frac{\kappa}{2},
 \qquad W_Q=\int_Q f. \tag{4}
\]
Let \(U=\bigcup_{Q\in\mathcal B}Q\), \(W_{\rm bad}=\int_Uf=\sum_QW_Q\), and \(f_{\rm good}=f1_{U^c}\). Then
\[
 |U|\le4W_{\rm bad}/\kappa,\qquad
 0\le f_{\rm good}\le\kappa/4\quad\hbox{almost everywhere}. \tag{5}
\]
To justify the last assertion, at almost every point the fine-generation averages converge to \(f(x)\). This follows directly from Lebesgue differentiation: the grid rectangle containing \(x\) shrinks to \(x\), is contained in a centered cube of side \(2\ell_Q\), and has volume at least \((\ell_Q/2)^n\). For fixed \(n\), the resulting volume ratio is finite, so the mean deviation from \(f(x)\) tends to zero. At a point outside \(U\), every grid average is at most \(\kappa/4\), proving (5). The countable grid boundaries have Lebesgue and \(f\,dx\) measure zero; their half-open convention is unambiguous.

If \(W_{\rm bad}=0\), then \(f\le\kappa/4\) almost everywhere and the desired energy is zero with an empty cap. All subsequent sums can then be read as empty.

## 3. One reference density and one common coupling

Define
\[
 s(z)=f_{\rm good}(z)+
 \sum_{Q\in\mathcal B}\frac{W_Q}{|Q|}1_Q(z). \tag{6}
\]
The terms have disjoint supports up to null boundaries. Equations (4)–(5) show that \(0\le s\le\kappa/2\) almost everywhere and \(\int s=W\).

There is an explicit common coupling of \(f(y)\,dy\) and \(s(z)\,dz\):
\[
 \pi=
 (y\mapsto(y,y))_\#(f_{\rm good}(y)\,dy)
 +\sum_{Q\in\mathcal B}
 \left(f(y)1_Q(y)\,dy\right)
 \otimes\frac{1_Q(z)\,dz}{|Q|}. \tag{7}
\]
Every source point is in exactly one term, apart from null boundaries. The target marginal of the \(Q\)-term is \(W_Q|Q|^{-1}1_Q\,dz\), and its displacement satisfies
\(\|y-z\|_\infty\le\ell_Q\). The good part has displacement zero. This is one finite measure of mass \(W\), not a different transport for each scale. Its displacement need not have a finite uniform bound; no such assertion is needed.

At scale \(L\), restrict the already constructed coupling to the good part and to those source labels \(Q\) with \(\ell_Q\le L/(8n)\). The target of this restriction is a submeasure of \(s\,dz\), hence still has density at most \(\kappa/2\). Its displacement is at most \(L/(8n)\). Its source is
\[
 \nu_L^{\rm short}=f_{\rm good}\,dy+
 \sum_{\ell_Q\le L/(8n)} f1_Q\,dy.
\]
The same cube inclusion used in the R94 transport estimate now gives, simultaneously for every \(x,L\),
\[
 T_L\nu_L^{\rm short}(x)
 \le\frac{\kappa}{2}\left(1+\frac1{4n}\right)^n
 \le\frac{\kappa}{2}e^{1/4}<\frac{2\kappa}{3}. \tag{8}
\]
For example \(e^{1/4}<4/3\) follows from \(-\log(1-t)>t\) at \(t=1/4\). The target density is shared by all short pieces, so (8) reserves threshold simultaneously. It does not allocate a full threshold independently to each piece.

Define the complementary actual near field
\[
 N(x,L)=\sum_{\substack{Q\in\mathcal B\\\ell_Q>L/(8n)}}
 T_L(f1_Q)(x). \tag{9}
\]
It is jointly measurable as a countable sum of nonnegative measurable functions and is at most \(T_Lf(x)\le WL^{-n}\). The exact source partition gives \(T_Lf=T_L\nu_L^{\rm short}+N\). Therefore
\[
 (T_Lf(x)-\kappa)_+^2
 \le (N(x,L)-\kappa/3)_+^2. \tag{10}
\]
Only the label selection in a fixed coupling changes with \(L\). There is no repeated source-mass payment in (8).

## 4. One padded cap and a finite scale window per source

For \(\delta>0\), let \((1+\delta)Q\) be the closed rectangle with the same center and side lengths \((1+\delta)a_i(Q)\), and set
\[
 \Omega_\delta=\bigcup_{Q\in\mathcal B}(1+\delta)Q. \tag{11}
\]
This is a single measurable subset of receiver space, independent of \(L\). Overlaps are deleted once, and
\[
 |\Omega_\delta|\le\sum_Q(1+\delta)^n|Q|
 \le4(1+\delta)^nW_{\rm bad}/\kappa. \tag{12}
\]
The upper bound by a sum is only a cap-volume upper bound, not a claim that the enlarged rectangles are disjoint.

Fix \(x\notin\Omega_\delta\) and a rectangle \(Q\). In some coordinate \(i\), the point \(x_i\) is outside the padded interval. For every \(y\in Q\),
\[
 |x_i-y_i|>\delta a_i(Q)/2\ge\delta\ell_Q/4.
\]
If \(Q(x,L)\) captures any point of \(Q\), its radius \(L/2\) must be at least this distance. Thus
\[
 T_L(f1_Q)(x)>0,\quad x\notin\Omega_\delta
 \quad\Longrightarrow\quad L\ge\delta\ell_Q/2. \tag{13}
\]
The distinction between distance \(\delta\ell_Q/4\) and full cube side \(\delta\ell_Q/2\) is essential.

The same source label occurs in (9) only when \(L<8n\ell_Q\). Consequently it can contribute outside the cap only in the scale window
\[
 \delta\ell_Q/2\le L<8n\ell_Q. \tag{14}
\]
Using Tonelli and the exact normalization
\(\int_{\mathbb R^n}T_L(f1_Q)(x)\,dx=W_Q\), we obtain
\[
 \begin{aligned}
 \int_{\Omega_\delta^c}\int_0^\infty N\,\frac{dL}{L}\,dx
 &\le\sum_Q\int_{\delta\ell_Q/2}^{8n\ell_Q}W_Q\,\frac{dL}{L}\\
 &=W_{\rm bad}\log(16n/\delta),\qquad0<\delta<16n.
 \end{aligned} \tag{15}
\]
For \(\delta\ge16n\) the window is empty, so the left side is zero. The uniform formula uses \(\log_+(16n/\delta)\).

This is the new all-input occupation budget. It includes all scales, all source labels, all receiver positions outside the one cap, and the original source masses. It does not integrate \(W\) over infinitely many separately charged generations. Each \(W_Q\) is charged once for a logarithmic interval of bounded ratio.

## 5. Paid low heights and the exact high-height remainder

Write \(J_\delta=\log_+(16n/\delta)\), and for \(K>0\) define
\[
 F(K)=\frac{(K-1/3)_+^2}{K},\qquad
 \mathcal H_K=
 \int_{\Omega_\delta^c}\int_0^\infty
 1_{\{N>K\kappa\}}(N-\kappa/3)_+^2\,\frac{dL}{L}\,dx. \tag{16}
\]
The function \(t\mapsto(t-1/3)_+^2/t\), with value zero at \(t=0\), is increasing. Therefore (10) and (15) imply
\[
 \mathcal E_\kappa(f;\Omega_\delta)
 \le F(K)\kappa W_{\rm bad}J_\delta+\mathcal H_K. \tag{17}
\]
In particular, at \(\delta=1/n\) and \(K=1\),
\[
 |\Omega_{1/n}|\le4eW/\kappa,\qquad
 \mathcal E_\kappa(f;\Omega_{1/n})
 \le\frac49\kappa W_{\rm bad}\log(16n^2)+\mathcal H_1. \tag{18}
\]
The first term is fully paid for every positive \(L^1\) source. The high-height second moment \(\mathcal H_1\) is not controlled by the first moment (15). Markov's inequality alone does not pay it.

There is a complete but exponentially expensive bound, useful for specifying the current limit of the construction. If \(x\notin\Omega_\delta\) and \(Q(x,L)\) meets \(Q\), (13) gives \(\ell_Q\le2L/\delta\). Choosing a captured point \(y\in Q\), every \(z\in Q\) then satisfies
\[
 \|z-x\|_\infty\le\ell_Q+L/2\le2L/\delta+L/2.
\]
Thus every such \(Q\) lies inside \(Q(x,L+4L/\delta)\). The original bad rectangles are disjoint, and their averages are at most \(\kappa/2\). Summing their entire masses, which only enlarges the captured mass, proves
\[
 N(x,L)\le C_{n,\delta}\kappa,\qquad
 C_{n,\delta}=\frac12(1+4/\delta)^n
 \quad(x\notin\Omega_\delta). \tag{19}
\]
Combining with (15) gives the finite all-input estimate
\[
 \mathcal E_\kappa(f;\Omega_\delta)
 \le F(C_{n,\delta})\,J_\delta\,\kappa W_{\rm bad}. \tag{20}
\]
For \(\delta=1/n\), the cap coefficient is bounded but \(C_{n,\delta}=\tfrac12(1+4n)^n\). This is not a subpower energy coefficient. Equation (20) records rather than conceals the remaining geometric overcharge.

## 6. Interpretation and next exact quantity

The construction supplies the adaptive common cap and the actual multiscale partial transport for every input. It improves the scale-accounting issue: near-source occupation has only a logarithmic coefficient, while short transport is simultaneously absorbed into the common threshold. It does not rely on a coarse uniform displacement whose tail starts beyond the global mass cutoff.

The remaining precise task is to improve the high-height quantity in (16), using the actual stopped rectangles, the source density within them, and the receiver location outside their common padding. A sufficient bound at \(\delta=1/n\), for example, is
\[
 \mathcal H_1\le B_n\kappa W,\qquad B_n=n^{o(1)}. \tag{21}
\]
This has not been proved. Equation (21) is a remaining target, not a new theorem or a consequence of a source-independent tail law.

All rectangle selection and transports use the original \(f\). If a different restricted source is later used, the construction may be applied anew to that source; no original smooth, coarse, or first-contact gate is claimed to survive. The present all-scale energy reduction has no hidden background-layer fee. Any later return through the retained weak/Hall framework must retain its stated quantifiers and fees.

The E03 skill was used to check source and terminal accounting: the argument relies on an explicit disjoint source partition and nonnegative Tonelli, not on an unverified tree Carleson theorem or a free Bellman telescoping step. The global reference capacity in (6) is verified directly.

## 7. Verification status

Both independent auditors completed the full Markdown and matching TeX proof review of (1)–(21) and returned PASS with no required mathematical correction. Their checks include the all-integer filtration, maximal bad rectangles for noncompact integrable sources, the common coupling and threshold, the exact outside-cap scale window, logarithmic occupation, the low/high split, and the exponential fallback. These are proof-review receipts; they do not claim independent numerical execution.

The public numerical role has completed and frozen the three-stage calculation in `energy_probe.py`, `energy_results.json`, and `energy_numeric.md`. The final reported execution time was 1.765418375 seconds. The stages use genuine unequal multiscale uniform-box mixtures, with correlation in the two higher-dimensional stages. Each stage applies the stopped cyclic binary rectangles and their one padded union cap to the same physical input already used by that stage; no replacement source is introduced. The numerical grid is a translated fixed cyclic grid, so the construction is the coordinate translate of §§2–4. The one-dimensional pilot is an auxiliary computation; the stated theorem and its near-occupation application here retain \(n\ge2\).

| Executed stage | Dimension | Reported grid cells | Maximal bad rectangles |
|---|---:|---:|---:|
| Pilot | 1 | 322 | 3 |
| Correlated stress | 2 | 1764 | 4 |
| Expanded correlated input | 3 | 5832 | 8 |

The normalized inputs have \(W=\kappa=1\), bad mass one, good mass zero, and reference-density maximum \(1/2\). All stopped averages satisfy \(1/4< W_Q/|Q|\le1/2\). At \(\delta=1/n\), the global union-cap volumes in increasing dimension are \(4\), \(145/32\), and \(2009/432\), below their respective theoretical cap budgets \(8\), \(9\), and \(256/27\). The union volumes count overlaps once.

The reported raw-square energy upper bounds over the full complement of the same cap and all scales are, rounded upward for display, \(0.540561\), \(0.468391\), and \(0.364654\), in the native energy units \(\kappa W\). Here raw-square energy means \(\int_{\Omega_\delta^c}\int_0^\infty (T_Lf)^2\,dL/L\,dx\), with the same cyclic-rectangle cap used throughout. The implementation uses rational arithmetic, analytic near/far scale integrals, and outward logarithm bounds, rather than floating-point quadrature. For positive-excess energy the omitted receiver complement and scales \(L\ge1\) contribute zero on these inputs; inside the finite receiver domain the raw-square calculation uses whole-cell and retained-face enclosures on the cap complement, then adds an explicit radial tail outside that domain and integrates all scales. These scope and tail statements are the numerical role's execution receipt, not a fresh independent replay by this note's author.

Since \(0\le N\le T_Lf\), the raw-square bounds also upper-bound \(\mathcal H_1\) for these particular sources and caps. They are **not** measurements of the near-field height distribution or of the actual near-occupation integral. For \(n=2,3\), the near-occupation coefficient \(\log(16n^2)\) is supplied by (15), not measured by the program. A finite raw-square bound on these sources neither proves the general estimate (21) nor resolves its dimensional growth.

The maximum-displacement cutoffs \(2n\ell_{\max}\) on the three inputs are \(4,4,6\), while their original mass cutoff \((W/\kappa)^{1/n}\) is one. Thus a tail beginning at that coarse cutoff does not pay their near-scale positive-excess energy. This is the intended strategy distinction between the coarse uniform displacement and the source-labeled common construction.

## 1. General result and remaining initial quantity

The controlled-growth strategy below is valid but its final initial-remainder bound is dominated by a simpler direct bound. It does not reduce the geometric difficulty of the root-order target. A changed actual partial-demand algorithm pays every future thin-annulus charge, its kernel-growth defect, source exits, child reclassification and terminal. It leaves one quantity on the ORIGINAL input and ORIGINAL earliest selector: a high-density positive-excess boundary integral V_0^hi. No root-order bound for that quantity is proved. The general weak theorem remains OPEN. Section 7 proves that the resulting initial functional is quantitatively equivalent to the original residual weak problem, so its simpler form is not a smaller geometric task.

The verified bookkeeping step is a nonmonotone boundary bank whose positive growth is bounded by actual child contact. Choosing beta=c/4 makes that growth absorbable. Treating this bank as decreasing would be false; its exact growth and its payment are part of the theorem. The final source-root coefficient is O_p(sqrt(n)log^2(n+2)), plus an explicit multiple of V_0^hi. The result applies in the high-count regime without any low-profile branch.

## 2. Changed actual algorithm and retained R94 payment

Let n>=2, alpha=epsilon0=1/[10log(n+2)], c=1-alpha-epsilon0, u=1-epsilon0, H_n=1+nlog2. This round changes the algorithm to

    beta=c/4, lambda_i=beta^i lambda_0,
    b=1/(c-beta), a=(1-beta)/(c-beta),
    M=1+sqrt(n), L_*=M^(1/n).                              (1)

All statements below concern this newly run algorithm, not a relabelling of the old beta=c/2 chain. The source mu_i=mu_0|Z_i=f_0 1_Zi dy has mass W_i. B_i lies in the freshly recomputed whole original Fnew for this source/threshold. Its original earliest cube Q_i(x)=Q(x,L_i(x)), 1<=L_i<=2, has contact mu_i(Q_i)=lambda_i L_i^n. Let D_i=lambda_i|B_i|. The retained captured-stop kernel satisfies

    0<=k_i<=L_i^(-n)1_Qi,
    c lambda_i<d_i(x):=∫k_i dmu_i<=u lambda_i,
    q_i(y)=∫_Bi k_i(x,y)dx.                                (2)

The source restriction is S_i={q_i>K}, mu_{i+1}=mu_i|S_i. Write e_i=∫_(S_i^c)k_i dmu_i and use the NEW good-row cutoff

    G_i={e_i>=(1-beta/c)d_i}={e_i>=3d_i/4}.                 (3)

Every other row has retained stop mass greater than beta lambda_i, so its old cube is a strict hard witness for the child. Apply all original classification branches, at threshold lambda_{i+1}, to these rows. If E_i is the paid portion and B_{i+1} the final residual, then B_i=G_i ⊔ E_i ⊔ B_{i+1}, and

    lambda_i|E_i|<=(A_n/beta)W_{i+1}.                     (4)

The factor 1/beta pays FULL parent demand. For final continuing rows the child anchor and old strict witness force L_{i+1}<L_i. No child cube is assigned to E_i. Source and receiver sets are nested.

Good rows use the source-exit kernel lambda_i k_i1_(S_i^c)/e_i, with multiplier <=b, since e_i>(c-beta)lambda_i. Continuing rows use k_i[1_(S_i^c)+1_Si1_(Qi\Qchild)], whose row mass exceeds (c-beta)lambda_i. Multiplying by (1-beta)lambda_i divided by that mass pays exactly the threshold loss, with multiplier <=a<b. The two source-exit row sets are disjoint, so combined exit columns are <=bq_i<=bK. Thus

    ΔD_i:=D_i-D_{i+1}
       =lambda_i|G_i|+lambda_i|E_i|+(1-beta)lambda_i|B_{i+1}|,
    ΔD_i<=bK(W_i-W_{i+1})+aJ_i+(A_n/beta)W_{i+1},         (5)

where J_i is the actual old-hard-kernel annular integral against B_{i+1} and mu_{i+1}. No beta^(-i) weight is introduced.

Retain R94's proved low/deep payment. Define psi(z)=max(1,2||z||inf)^(-n)1_{2||z||inf<=2}, with integral H_n, and

    Psi_i=∫dmu_i(y)∫_Bi psi(x-y)1_Qi(y)dx,
    Xi_i=Psi_i-D_i,
    U_i=∫dmu_i(y)∫_Bi psi(x-y)1_{2||x-y||inf<=L_*}1_Qi(y)dx,
    P_i=bK W_i+aU_i+aXi_i/(M-1),
    C_M=bK+a(1+log M)+aH_n/(M-1).                         (6)

The nonnegative monotone reservoirs obey 0<=P_i<=C_MW_i and pay low annuli (old L_i<=L_*) and deep annuli (old L_i>L_*, psi>=M L_i^(-n)). Remaining thin pairs satisfy

    L_i>L_*, 1<L_i/M^(1/n)<2||x-y||inf<=L_i,
    y∈Q_i\Q_{i+1}, x∈B_{i+1}, y∈Z_{i+1}.                (7)

Use J_i^thin for their actual old-hard-kernel integral. This classification uses the same actual inputs, not a substituted fixed-scale flow. Since KW_{i+1}<=uD_i and D_{i+1}<=beta D_i, choosing

    K=4A_nu/[beta(1-beta)]                                (8)

pays the full child error by ΔD_i/4. Equation (5) and the retained low/deep payment give

    (3/4)ΔD_i<=P_i-P_{i+1}+aJ_i^thin.                     (9)

## 3. New boundary bank and exact controlled growth

For L∈[1,2] define

    v_L(x,y)=(L^(-n)-psi(x-y)/M)_+
                   1_Q(x,L)(y)1_{L>L_*},
    V_i=∫dmu_i(y)∫_Bi v_Li(x)(x,y)dx.                    (10)

This bank is nonnegative and V_i<=D_i. It is supported in the high-side thin shell. It need not decrease under cube shrinkage. On a captured child pair, however,

    v_Lchild-v_Lold<=L_child^(-n)-L_old^(-n).              (11)

If both sides exceed L_*, this follows from the 1-Lipschitz positive-part map. If the child crosses below L_*, its bank becomes zero and the same upper bound still holds. Both below the cutoff give zero; the reversed crossing is impossible by actual nesting.

All source/receiver deletions have nonnegative old bank. On a removed thin pair one has the exact identity psi/M+v_Lold=L_old^(-n). On a captured child pair the psi part does not change, and (11) pays its possible bank increase. Consequently

    J_i^thin <= Δ(Psi_i/M+V_i)+I_i,
    I_i=∫_(B_{i+1})[L_{i+1}^(-n)-L_i^(-n)]
                            mu_{i+1}(Q_{i+1})dx
       =lambda_{i+1}∫_(B_{i+1})[1-(L_{i+1}/L_i)^n]dx
       <=D_{i+1}.                                        (12)

To verify the direction, split the two physical integrals into deleted source/receiver pairs, removed annular pairs, and common captured pairs. The first group is nonnegative, thin annular pairs pay their old hard kernel exactly, other annular pairs remain nonnegative, and only common captured pairs can contribute negatively. Their total negative part is at most I_i by (11). This proves (12) without assuming monotonicity of V.

This is a genuine general geometric estimate on the actual recursion. Unlike a bare source-mass inequality, its error is identified with actual child contact and has the correct threshold scale to be absorbed.

## 4. Pay all future thin flow, classification, exits and terminal

Set

    F_i=P_i+aPsi_i/M+aV_i,
    C_*=C_M+aH_n/M,
    0<=F_i<=C_*W_i+aD_i.                                 (13)

Combining (9) and (12) gives (3/4)ΔD_i<=F_i-F_{i+1}+aI_i. By actual nested receiver sets,

    I_i<=D_{i+1}<=[beta/(1-beta)]ΔD_i,
    aI_i<=[beta/(c-beta)]ΔD_i=ΔD_i/3.

Therefore, with sigma=5/12,

    sigma ΔD_i<=F_i-F_{i+1},
    sigma(D_0-D_m)<=F_0-F_m.                              (14)

The earlier beta=c/2 choice would make beta/(c-beta)=1, so this same argument would not pay the growth. The smaller child threshold is essential, and its increased A_n/beta fee is already in (4), (8).

For every m>=1,

    D_m<=beta^mD_0,
    W_m<=u beta^(m-1)D_0/K,
    F_m<=C_*u beta^(m-1)D_0/K+a beta^mD_0.                (15)

Thus both terminal quantities vanish on an infinite active chain. At a finite receiver-empty stop D_m=0, F_m can remain positive and is discarded only with its favorable sign. At an unfinished horizon (14) keeps sigma D_m-F_m on the right. Source-empty contact forces empty demand. The old full-window estimate D_0<=H_nW_0 is used only to ensure finiteness and terminal control, not as a root payment.

At completion, all future thin flow is eliminated from the bound:

    sigma D_0<=C_*W_0+aV_0.                               (16)

The original initial event before paid classification adds A_nW_0. Its local bound is A_nW_0+(C_*W_0+aV_0)/sigma. In (16), C_*=O_p(sqrt(n)log^2(n+2)) and V_0 is on the original source/selector alone. The estimate V_0<=D_0 does NOT close (16), because a>sigma. This demand-priced initial term is explicitly unpaid.

## 5. Exact mass of the excess kernel and a single high-density remainder

There is a further initial-input absorption. For every fixed x and L>L_*, direct radial cube-shell integration gives

    ∫v_L(x,y)dy=h(M):=1-(1+log M)/M>0.                    (17)

Indeed, the support has arrival side s=2||x-y|| between L/M^(1/n) and L; its inner arrival side is >1. The integral of L^(-n) over this shell is 1-1/M. The integral of psi/M is (n/M)∫_(L/M^(1/n))^L ds/s=(log M)/M. For L<=L_* the kernel is zero.

Let tau_amp=sigma/[2a h(M)], a dimensionless density-screen parameter distinct from the original kappa layer. Decompose only the initial charge into densities min(f_0,tau_amp lambda_0) and (f_0-tau_amp lambda_0)_+. Define

    V_0^hi=∫(f_0(y)-tau_amp lambda_0)_+dy
                         ∫_B0 v_L0(x)(x,y)dx.

No input or gate is replaced by the clipped source. Equation (17) yields

    V_0<=tau_amp h(M)D_0+V_0^hi
        =[sigma/(2a)]D_0+V_0^hi.

Hence the completed general reduction is

    (sigma/2)D_0<=C_*W_0+aV_0^hi,
    lambda_0|E_init| <= [A_n+2C_*/sigma]W_0
                                      +(2a/sigma)V_0^hi. (18)

At a finite unfinished horizon the first line has the additional term sigma D_m-F_m on its right. If B_0 is empty, only A_nW_0 is charged. All future source restrictions, threshold changes, receiver exits, low/deep/thin annuli and the terminal are paid. The only missing estimate is a root-order upper bound on this SINGLE initial same-selector high-density positive-excess boundary functional. No such bound is established here; the original full gates must supply any further gain.

The earlier per-stage clipping idea is not added to this algorithm. Its amplitude lift would have births, so an entry mass bound alone would not justify a monotone potential. The final theorem avoids that issue by screening only the initial charge after the future geometric growth has been paid.

## 6. Original gates, scales and tools retained

At every actual child recompute anchor, all-L original P1 upper gate, strict later witness, earliest contact, original exp(-s_n)/2 middle lower, noise theta=log^(-2)(n+2), dominant-packet and physical collision/entropy branches, and any original kappa layer used. Whole Fnew=Fdiff∩{C_h*<3/4,Hbar_h*>sqrt(n)}; B_i is its current subset. The changed good-row cutoff and beta do not grant any inherited gate to a modified source.

Use the complete retained classification coefficient, for fixed p>0,

    h*=1/(16n^(3/2)), a0=n^(-p), rho0=n^(-1/2),
    B_base=4+2(log2)sqrt(7n/3), B_ext=2H_n/sqrt(n+2),
    T_soft=1+(log2)min(2n,sqrt(n[theta^(-1)+4theta/3])),
    P_dom=[5+3log(1/a0)]/rho0,
    E_*=exp(nh*), B_*=1+E_*[1+(2n²+n)h*],
    P_phys=2[E_*+B_*+2(1+E_*)sqrt(n)],
    A_n=B_base+B_ext+T_soft/alpha+P_dom+P_phys.              (19)

The physical union is paid once. Additional original-layer charges enter A_n or remain separate. All-scale return retains C_loc log(n+2) and separate J_n=O(log n) if that kappa route is used. The coefficients in (18) are local; no scale aggregation is free.

Updated N04 is used only for its verified finite telescope with explicit nonnegative lower bound. Its hypotheses are now supplied by (13)–(15); the positive growth defect is paid, not called summable without proof. Updated D01 distinguishes a feasible positive coupling from a mere dual value, and G01 requires actual all-node/common-source packing. Neither tool provides an unverified root bound for V_0^hi. The proof imports no external transport, Carleson or entropy theorem.

Three-stage validation checks the changed child fee and growth absorption, then an actual positive-L1/positive-volume realization in which V grows under shrinking cubes, then enlarged dimensions with exact continuum integration. The pressure lacks child contact and original gates and is not a qualified obstruction to the goal. Its concrete source, coordinates and quantified conclusions remain private. Independent proof audits and finite numerical validation are recorded separately.

## 7. Decisive direct dominance: this strategy does not reduce the target

The final interpretation must account for a stronger single-input inequality. Set

    B_direct=1+log M+H_n/M.

For every old capture kernel h_L=L^(-n)1_Q(x,L), if L<=L_* then h_L<=psi_*1_Q, where psi_*=psi1_{2||x-y||<=L_*}. If L>L_*, then

    h_L <= (psi/M)1_Q + v_L.

This is simply t<=s+(t-s)_+ on the captured cube. Integrating against the ORIGINAL mu_0 and receiver B_0, and using the physical envelope integrals, gives without any recursion

    D_0<=B_direct W_0+V_0.                                (20)

No stop kernel, source restriction or child gate was needed for this estimate. The initial contact is the only demand identification. Equation (20) has strictly better coefficients than (16): C_*>=a B_direct and a/sigma>1, so both its source and initial-V coefficients are smaller. The controlled-growth proof has not improved this direct positive decomposition.

The stronger direct density screen is tau_dir=1/[2h(M)]. Define Q_0 by the same original-selector boundary kernel v, with density (f_0-tau_dir lambda_0)_+. Equation (17) gives

    D_0<=2B_direct W_0+2Q_0,
    lambda_0|E_init|<=(A_n+2B_direct)W_0+2Q_0.             (21)

Here tau_dir>tau_amp because a>sigma, hence Q_0<=V_0^hi. Also 2C_*/sigma>2B_direct and 2a/sigma>2. Thus (21) dominates the screened recursive estimate (18) both in coefficients and in the remaining functional.

Finally,

    0<=Q_0<=V_0<=D_0.                                   (22)

A root-order residual weak bound therefore bounds Q_0 immediately. Conversely, a root-order bound for Q_0 would imply that weak bound by (21), because B_direct=O(sqrt(n)+log(n+2)). Thus the proposed initial root-budget premise is quantitatively equivalent to the residual weak target up to already root-priced constants. It cannot be advertised as an independent geometric advance or assumed in order to close the proof.

This is the rigorous outcome of the strategy test: its adaptive bookkeeping, growth payment, source budget and terminals are correct, but the final claim is dominated by (20)–(21). A real next gain must exploit the original full gates or a genuinely smaller common redistribution capacity to bound Q_0, rather than repeat this positive decomposition. The present text proves no new root thin-flow bound and no qualified counterexample to one. The private growth example tests one false intermediate monotonicity assertion only.

## 1. A complete general occupation-cap estimate

Let $n\ge2$, $f\ge0$ belong to $L^1(\mathbb R^n)$, $W=\int f$, and $\kappa>0$. Use full-side centered cubes and actual Lebesgue receivers:
\[
 A_Lf(x)=L^{-n}\int_{x+[-L/2,L/2]^n}f(y)\,dy,\qquad
 \mathcal E_\kappa(f;\Omega)=\int_{\Omega^c}\int_0^\infty(A_Lf(x)-\kappa)_+^2\,\frac{dL}{L}\,dx.
\]
For every such source there is one measurable source-dependent cap $\Omega_*$ satisfying
\[
 |\Omega_*|\le(4e+1)\frac W\kappa,\qquad
 \mathcal E_\kappa(f;\Omega_*)\le
 \frac{n\log(32n^2)\log(16n^2)}{1-2^{-n}}\,\kappa W.
 \tag{1}
\]
This pays the full scale duration, including the former high-height near-field remainder. It uses neither an $L^2$ assumption on $f$ nor a scale-dependent receiver cap. The price is $B_n=O(n\log^2(n+2))$, not the desired subpower coefficient. In particular this argument does not prove the root-order weak bound; the retained energy-to-weak implication gives only order $n\log(n+2)$ here. The input-dependent cap is allowed to have spatially varying effective scales.

This theorem combines the R95 coverage role's cyclic binary source partition with a new spatial occupation potential and an extra cap. The necessary partition facts are derived below so the interface and all mass budgets are explicit. No new primary-source theorem is used. G01 and E03 were used to check that actual source capacity and nonnegative infinite-layer accounting are present; no abstract Carleson or Bellman assertion substitutes for them.

## 2. The fixed source partition and the near field

For each integer $k=qn+r$, $q\in\mathbb Z$, $0\le r<n$, partition space into half-open grid rectangles with side lengths $2^{-q-1}$ in the first $r$ coordinates and $2^{-q}$ in the others. Endpoints are integer multiples of the corresponding side. Each child has half the parent's volume. The rectangles are nested across generations and have aspect ratio at most two.

Select maximal rectangles $Q$ whose average of $f$ is greater than $\kappa/4$. Ancestor averages tend to zero because their volumes tend to infinity and $W<\infty$, so maximal bad ancestors exist. The selected family $\mathcal B$ is countable and disjoint. Its members satisfy
\[
 \frac\kappa4<\frac{W_Q}{|Q|}\le\frac\kappa2,
 \quad W_Q=\int_Qf,\quad
 W_b=\sum_{Q\in\mathcal B}W_Q\le W,
 \quad \sum_Q|Q|\le\frac{4W_b}\kappa.
 \tag{2}
\]
The upper average follows from the nonbad parent and its factor-two volume. Let $\ell_Q$ be the largest side of $Q$. The smallest side is at least $\ell_Q/2$. The remaining density $f_g=f1_{(\cup_QQ)^c}$ is at most $\kappa/4$ almost everywhere. Indeed fine grid rectangles have bounded eccentricity and shrink to their point, so Lebesgue differentiation applies; outside the selected union every grid average is at most $\kappa/4$. Null grid boundaries cause no source-mass issue.

Replace each $f1_Q\,dy$ by the uniform density $W_Q|Q|^{-1}1_Q\,dz$. The resulting common reference
\[
 s=f_g+\sum_Q\frac{W_Q}{|Q|}1_Q
 \quad\hbox{satisfies}\quad 0\le s\le\kappa/2,\quad\int s=W.
\]
Use the product coupling $f1_Q\,dy\otimes 1_Q\,dz/|Q|$ within each $Q$, and the diagonal coupling on $f_g$. This is one mass-preserving coupling; its $Q$-displacement in the maximum norm is at most $\ell_Q$.

At a scale $L$, retain the good source and the labels with $\ell_Q\le L/(8n)$. Their target is a submeasure of $s\,dz$, and their displacement is at most $L/(8n)$. A source point captured by $Q(x,L)$ therefore has its entire target distribution inside $Q(x,L+L/(4n))$. Consequently their combined average is at most
\[
 \frac\kappa2\left(1+\frac1{4n}\right)^n
 \le\frac\kappa2e^{1/4}<\frac{2\kappa}3.
\]
Define the actual complementary near field and its enlarged-window version by
\[
 N(x,L)=\sum_{\ell_Q>L/(8n)}A_L(f1_Q)(x),\qquad
 \widehat N(x,L)=\sum_{\ell_Q>L/(16n)}A_L(f1_Q)(x).
 \tag{3}
\]
These are jointly measurable nonnegative fields bounded above by $A_Lf\le WL^{-n}$. The source partition is exact, so
\[
 (A_Lf-\kappa)_+^2\le(N-\kappa/3)_+^2\le N^2.
 \tag{4}
\]
The label cutoffs reserve the threshold jointly through the same reference density; a separate threshold is not given to each source piece.

## 3. Logarithmic occupation and a spatial potential

Fix $0<\delta\le1$. Let $\Omega_\delta$ be the union of the closed concentric dilations $(1+\delta)Q$. This is one cap, with
\[
 |\Omega_\delta|\le4(1+\delta)^nW_b/\kappa.
\]
If $x\notin\Omega_\delta$, some coordinate of $x$ is outside the padded interval of each given $Q$. Its distance from any point of that $Q$ is greater than $\delta\ell_Q/4$ in that coordinate. Hence capture is impossible unless $L\ge\delta\ell_Q/2$. The original near label ends at $8n\ell_Q$, and the enlarged one ends at $16n\ell_Q$. Tonelli and $\int A_L(f1_Q)\,dx=W_Q$ therefore give
\[
 \int_{\Omega_\delta^c}\int_0^\infty N\,\frac{dL}{L}\,dx\le W_bJ_0,
 \qquad
 \int_{\Omega_\delta^c}\int_0^\infty\widehat N\,\frac{dL}{L}\,dx\le W_bJ_1,
 \quad J_0=\log\frac{16n}{\delta},\quad J_1=\log\frac{32n}{\delta}.
 \tag{5}
\]
In each estimate a source label pays a single finite scale interval, not one mass charge per generation. No compact-support or finite-label assumption is needed.

The new spatial occupation potential is
\[
 h(x)=\int_0^\infty\widehat N(x,L)\,\frac{dL}{L}
 =\frac1n\sum_Q\int_Q f(y)
 \left[(2\|x-y\|_\infty)^{-n}-(16n\ell_Q)^{-n}\right]_+\,dy.
 \tag{6}
\]
The extended value at $x=y$ is interpreted as positive infinity. The equality follows by nonnegative Tonelli and integrating $L^{-n-1}$ between $2\|x-y\|_\infty$ and $16n\ell_Q$. The potential is determined by the actual source locations inside their stopped rectangles, not only by the labels' masses. It can be infinite on the original cap. Equation (5) shows that it is integrable and finite almost everywhere on that cap's complement.

There is a pointwise peak-to-occupation estimate
\[
 N(x,L)\le c_n h(x),\qquad c_n=\frac{n}{1-2^{-n}},\quad L>0.
 \tag{7}
\]
For a proof, fix $L$ and $u\in[L,2L]$. Every label with $\ell_Q>L/(8n)$ also has $\ell_Q>u/(16n)$, including the endpoint $u=2L$. Centered cubes are nested and the source is positive, so $A_u(f1_Q)(x)\ge(L/u)^nA_L(f1_Q)(x)$. Sum the old labels and integrate:
\[
 h(x)\ge\int_L^{2L}\widehat N(x,u)\,\frac{du}{u}
 \ge N(x,L)\int_1^2v^{-n-1}\,dv
 =\frac{1-2^{-n}}nN(x,L).
\]
This remains valid for countable source labels and infinite $h$. It is a physical cube-containment inequality, not a crossing-count estimate or a martingale model.

## 4. One additional cap pays the full energy

For any $T>0$, set
\[
 \Omega_{\delta,T}=\Omega_\delta\cup
 \{x\notin\Omega_\delta:h(x)>T\kappa\}.
 \tag{8}
\]
This is a single source-adapted set, independent of scale. Points with $h=\infty$ are included; their exterior-base measure is zero by (5). Markov's inequality is used only for its volume, giving
\[
 |\Omega_{\delta,T}|
 \le\left[4(1+\delta)^n+\frac{J_1}{T}\right]\frac{W_b}{\kappa}.
 \tag{9}
\]
Outside this cap $h\le T\kappa$, including equality points, so (7) gives $N(x,L)\le c_nT\kappa$ for every $L$. Equations (4) and (5) now imply
\[
 \begin{aligned}
 \mathcal E_\kappa(f;\Omega_{\delta,T})
 &\le\int_{\Omega_{\delta,T}^c}\int_0^\infty N^2\,\frac{dL}{L}\,dx\\
 &\le c_nT\kappa\int_{\Omega_\delta^c}\int_0^\infty N\,\frac{dL}{L}\,dx
 \le c_nT J_0\,\kappa W_b.
 \end{aligned}
 \tag{10}
\]
The first moment alone has not been treated as a second moment. The extra cap creates the uniform pointwise height bound that licenses the second line. Its volume was paid once in (9). These inequalities already integrate all positive scales, with no omitted fine or coarse tail.

Take $\delta=1/n$ and $T=J_1=\log(32n^2)$. Then $(1+1/n)^n\le e$, and (9)–(10) give (1) with $\Omega_*=\Omega_{1/n,J_1}$. If $W_b=0$, then $f\le\kappa/4$ almost everywhere and the empty cap gives zero energy; if $W=0$ the same conclusion holds. All remaining claims thus cover arbitrary nonnegative $L^1$ input directly, without an atomic-to-diffuse limit or a source $L^2$ approximation.

## 5. Paid costs and the unresolved dimensional loss

The two cap payments are $4(1+\delta)^nW_b/\kappa$ and $J_1W_b/(T\kappa)$. The energy payment is $c_nTJ_0\kappa W_b$. Increasing $T$ reduces the extra cap volume but increases the height payment. For this family of estimates their coefficients obey
\[
 \left[4(1+\delta)^n+\frac{J_1}{T}\right]c_nTJ_0
 =c_nJ_0\left[4(1+\delta)^nT+J_1\right].
 \tag{11}
\]
Thus adjusting $T$ alone does not remove the factor $c_nJ_0J_1$ from this proof's product budget. This algebra concerns the displayed bounds, not a lower bound on the optimal energy or cap. A better proof can use the threshold in (4), the actual source partition, and the locations removed by (8), rather than the uniform peak bound (7). No claim that a linear dimensional fee is necessary for the original problem is made.

There is a concrete sufficient capacity estimate for improving this particular construction. Keep the same stopped rectangles and the same potential $h$, set $\delta=1/n$, and choose $T=1/n$. If, uniformly for every input with $W_b>0$, one could prove
\[
 \left|\{x\notin\Omega_{1/n}:h(x)>\kappa/n\}\right|
 \le A'_n\,\frac{W_b}{\kappa},
\]
then (7)–(10) would give $A_n\le4e+A'_n$ and $B_n\le\log(16n^2)/(1-2^{-n})$. A subpower $A'_n$ would suffice through the retained energy-to-weak implication. This displayed capacity estimate with subpower $A'_n$ is UNPROVED. The current argument only gives $A'_n\le n\log(32n^2)$ by Markov. For $W_b=0$ the set is empty. Thus the missing condition concerns one specified spatial level set of the actual source potential, not a freely chosen scale-by-scale exception or a consequence of the occupation first moment.

The new construction replaces the old unbounded high-height remainder by a complete polynomial payment. It does not achieve $A_nB_n=n^{o(1)}$. The remaining research target is a quantitatively sharper source-sensitive high-height settlement after one common cap, not the formal elimination of a logarithmic tail or a count of scale crossings. Original smooth, coarse, and first-contact restrictions have not been changed or claimed by this all-input energy theorem.

## 6. Verification status

The precise cap, all-input quantifiers, enlarged cutoff, peak constant, and complete volume/energy budgets were sent to both auditors before this proof. Both independent blind checks and subsequent full mathematical Markdown/TeX proof reviews passed. Newly executed pilot, high-concentration stress, and expanded checks use 15 actual box-density models with 37 verified maximal bad rectangles and 181 ancestor checks. Across 296 exterior receiver profiles they integrate the near field over all scales using 4,538 exact polynomial intervals and outward logarithm bounds, and check 9,076 actual cube-scale nodes. The additional cap classifies 32 profiles inside and 264 outside, with no undecided interval comparison. These are native units, not assertion totals or sampled continuum receiver-volume certificates; the global volume and all-input energy bounds are proved analytically above. Reproduction code and detailed records are retained privately.

The new useful result here is conditional cube energy, not a general endpoint: a real common potential with finite Dirichlet energy pays the entire large-scale tail with constant **20**, independent of dimension. The primary partial-balayage sources supply a genuine source-adapted cap in their stated settings; they supply no uniform cube near-energy or actual thin-annulus capacity bound. The general target remains open.

## S1. Exact new primary reading and the transfer boundary

[Kow–Shahgholian–Sjödin, *Multiphase quadrature domains (existence and uniqueness)*, Analysis and Mathematical Physics 16:88 (2026)](https://link.springer.com/article/10.1007/s13324-026-01232-4), §2, (2.3), (2.6)–(2.8), was actually read, including the completed-square minimization argument. For \(n\ge2\), positive compactly supported source \(\nu\) and constant density \(\kappa>0\), the recalled Euclidean partial balayage has bounded noncontact set \(\Omega=\{u>0\}\), and
\[
 m=\kappa1_\Omega dx+\nu|_{\Omega^c}\le\kappa dx,
 \qquad \nu-m=-\Delta u. \tag{1}
\]
This is not the stronger assertion that \(\operatorname{supp}\nu\subset\Omega\). Its existence and structural facts are recalled from earlier potential theory, not proved there from scratch. The bounded-density variational branch uses \(\nu\in L^\infty\), \(u\in H^1\), and the nonnegative obstacle class. Introductory Theorem 1.4's strong-domain hypothesis is concentration greater than \(2^n\) at every support point, with extra separation for multiple phases. It is not an all-input cube theorem. Reading stopped at §3.2; no later multiphase proof is certified.

The original [Gustafsson–Roos, *Partial Balayage on Riemannian Manifolds*, arXiv:1605.03102v1](https://arxiv.org/pdf/1605.03102) was read selectively: printed pp.12–18 (Definitions 3.1–3.2, complementarity, Theorems 4.1 and 5.1 and their proofs), pp.23–25 (Lemma 6.1, Theorem 6.3 and displayed proof), and pp.40–42 (boundary/mass conventions). On a closed compact manifold, Theorem 5.1 assumes negative total signed charge and finite-energy negative part; its minimizer is the auxiliary majorant \(v\), not automatically the difference potential \(u\). Theorem 6.3 gives \(\operatorname{Bal}(\sigma,\lambda)=\lambda|_\Omega+\sigma|_{\Omega^c}\) for positive measures, assuming existence, continuous \(G\lambda\), and absolutely continuous \(\lambda\). Its proof uses external reduction/harmonic-measure results [20,48], not independently reread here. These are exact qualification boundaries; a compact-manifold statement is not directly a Euclidean all-scale estimate. Section 11 explicitly retains boundary mass for Dirichlet exhaustion. No dimension-uniform cube energy constant occurs in these results.

J03 evidence E2913 was resolved with the explicitly authorized package-root override and SHA verification: `P-e151c15e14d258ac`, SHA `e151c15e14d258accc9ca8b9f882289d76dfc56fc23234c800e4ac45153db334`. The [Roos primary](https://arxiv.org/pdf/1605.03095), printed pp.6–9, was then read: the bounded Dirichlet construction recalls its proof from Gustafsson–Sakai; unrestricted signed-measure Theorem 2.7 is planar and requires compact support, negative total mass, and continuous negative-part potential. Its normalization is \(-\Delta U=2n\sigma\), so its odometer must be divided by \(2n\) before (1). Its bounded-domain cap includes boundary settlement. No sandpile scaling-limit proof was read or imported. Byte verification alone was not counted as reading.

The 2026 source's full-space cap is therefore a credible obstacle route for compact sources, with its recalled-existence provenance retained. Our rigorous cube result below is **conditional on the actual pair (1)**. We have not proved approximation to arbitrary noncompact \(L^1\) sources with all required energy and mass limits.

## S2. What the common cap itself really pays

Assume (1), finite positive \(\nu,m\), \(\nu(\mathbb R^n)=W\), bounded \(\Omega\), and compactly supported distribution \(u\), zero off \(\Omega\). Then the total distributional Laplacian vanishes: test against a smooth function equal to one near its support. Hence \(m(\mathbb R^n)=W\), and (1) gives
\[
 \kappa|\Omega|\le W. \tag{2}
\]
This is one common deletion with volume coefficient one, including original low-density source outside \(\Omega\). Neither repeated scale-wise deletion nor support inclusion is needed. If \(W=0\), positivity forces \(\nu=m=0\), and the energy is zero; \(\kappa>0\) is always required.

For the actual full-side cube averages \(A_L\), positivity and \(m\le\kappa dx\) give, pointwise almost everywhere,
\[
 (A_L\nu-\kappa)_+\le (A_L(\nu-m))_+
 \le |A_L(\nu-m)|. \tag{3}
\]
This assertion preserves the original receiver measure \(dx\), but it is not preservation of any first-contact selector or original gate after replacing the source by \(m\). Those gates must not be assigned to \(m\).

## S3. New dimension-free source-potential tail theorem

Let \(n\ge1\), \(R>0\), and \(u\) be a tempered distribution modulo additive constants, with distributional gradient \(g=\nabla u\in L^2(\mathbb R^n;\mathbb R^n)\). Suppose \(b=-\Delta u\) is a finite signed measure. Then the actual cube convolution satisfies
\[
 \int_R^\infty\|A_Lb\|_2^2\,\frac{dL}{L}
 \le \frac{20}{R^2}\|\nabla u\|_2^2. \tag{4}
\]
No \(u\in L^2\) hypothesis is imposed. A finite signed measure ensures the convolution has its ordinary measurable meaning and is in \(L^1\) for each \(L>0\).

**Proof.** Use Fourier transform \(\widehat f(\xi)=\int e^{-2\pi i x\cdot\xi}f(x)dx\) and full-side multiplier
\(m_L(\xi)=\prod_j\operatorname{sinc}(\pi L\xi_j)\).
The global scalar inequality proved in R94 gives
\[
 |m_L(\xi)|^2\le\left(1+\frac{\pi^2L^2|\xi|_2^2}{10}\right)^{-1}
 \le\frac{10}{\pi^2L^2|\xi|_2^2}\quad(\xi\ne0).
\]
Since \(b=-\operatorname{div}g\), distributional Fourier differentiation gives
\(\widehat b=-2\pi i\,\xi\cdot\widehat g\).
Thus \(|\widehat b|^2\le4\pi^2|\xi|_2^2|\widehat g|_2^2\) almost everywhere. Zero frequency is a Lebesgue-null set and no division of \(\widehat u\) is used. The product \(m_L\widehat b\) belongs to \(L^2\) with squared norm at most \(40L^{-2}\|g\|_2^2\). Its inverse Fourier transform equals the actual \(L^1\) cube convolution in distributions, hence almost everywhere, so Plancherel is justified. Integrating \(40L^{-2}dL/L\) gives \(20R^{-2}\), proving (4). Joint measurability follows from the finite-measure cube convolution, and Tonelli applies to its squared absolute value. The same argument integrates over any measurable exterior receiver set without changing the constant.

Combining (3) and (4) yields the actual one-cap tail
\[
 \int_{\Omega^c}\int_R^\infty (A_L\nu-\kappa)_+^2\frac{dL}{L}dx
 \le20R^{-2}\|\nabla u\|_2^2. \tag{5}
\]
The units are correct: \(\|\nabla u\|_2^2/R^2\) has density-squared times spatial-volume units. To pay \(B\kappa W\), one must establish the actual source-dependent budget \(\|\nabla u\|_2^2\le B\kappa WR^2/20\). Choosing \(R\) from this quantity leaves the entire interval \((0,R)\) unpaid. It does not constitute a cap near-energy theorem.

## S4. Potential truncation has a real budget and a real remainder

In the bounded compact-density obstacle branch, assume \(u\in H^1\) has compact support, \(b=\nu-m\in L^2\), and \(u\ge0\). For \(h>0\), \(T_hu=\min(u,h)\) is an admissible Sobolev test, giving
\[
 \int |\nabla T_hu|^2
 =\int T_hu\,(\nu-m)\le hW. \tag{6}
\]
This follows from the chain rule \(\nabla T_hu=1_{u<h}\nabla u\) almost everywhere and weak integration by parts. For bounded \(u\), taking \(h\ge\|u\|_\infty\) gives \(\|\nabla u\|_2^2\le\|u\|_\infty W\), hence tail cost \(20\|u\|_\infty W/R^2\). For small \(h\), truncation changes the residual by the explicit signed distribution \(-\Delta(u-T_hu)\). It is not a positive source deletion and cannot be dropped from (5). No uniform potential height or remainder payment was supplied by the primary theorems.

For smooth \(u\), the actual cube comparison also displays the missing geometry:
\[
 A_L(\nu-m)(x)=-L^{-n}\sum_{i=1}^n\int_{[-L/2,L/2]^{n-1}}
 [\partial_i u(x+z+\tfrac L2e_i)-\partial_i u(x+z-\tfrac L2e_i)]\,dz. \tag{7}
\]
Here \(z_i=0\). This is signed face flux; \(u=0\) at the receiver outside \(\Omega\) does not bound the translated face values. Newtonian potential agreement does not prove the positive cube occupation bound. Formula (7) is a diagnostic, not a new endpoint.

## S5. Updated skill applicability, without a renamed Hall gap

This round read the E03/G01/G02/J03/D01 entries and, specifically, G01 and J03 method/interface and J03 provenance/portable resolver instructions. Entry and provenance data are not independent paper proofs. The explicit readonly root was
`/Users/zhengzhihao/Desktop/T/数学工具64项_最终交付验收_20261011/f-zip/fresh-extraction/zip-root/数学工具64项_完整验收提升_20261007`.
The stale registry was not changed or claimed operational.

| Route | Required real input | Exact missing bridge for R95 |
|---|---|---|
| G01 finite tree | common bottom measure, actual tree, every-node packing | root source mass does not prove all subfamily thin-annulus capacity |
| G01 harmonic energy | actual harmonic function/domain and quantitative geometry | cube first-contact source occupation is not the harmonic measure in that theorem |
| G02 outer embedding | specified size/kernel, measurable deletion, theorem exponents | no verified embedding of the actual annular incidences, and no new \(L^1\) endpoint |
| J03 exits | the real generator, exit law, killing/overshoot and conservation | Newtonian obstacle balayage is not the cube jump process's exit measure |
| E03 budget | state update, nonnegative local increments and every-node Carleson control | survival \(W_i/W_0\) does not pay compensated mass \(t_iW_i\) when \(\rho_i>\beta\) |
| D01 transport | feasible actual marginals/capacities, measure qualifications | existence/equivalence of all-cut Hall cannot generate the missing geometric inequalities |

The sparse/Carleson allocation candidates were screened but their proofs were not newly read: they require all-subfamily capacity inequalities already equivalent to retained Hall feasibility. They are not counted as R95 progress. No new primary theorem found here produces the required uniform all-family annular budget. The genuine obstacle cap instead gives (1)–(2), with the useful conditional transfer (4)–(6). This negative transfer conclusion does not deny that a sharper cube obstacle-energy theorem might exist.

## S6. Three-stage executed checks, native units, and reading receipt

These checks were executed in an ephemeral Python heredoc; no other-owned or extra files were created. Exact arithmetic uses `fractions.Fraction`. They verify this round's new formula, not general cap feasibility.

1. **Pilot:** exact integration coefficient \(40/(2R^2)=20/R^2\) for \(R\in\{1/8,1/2,1,3,16\}\), energies \(\{0,1/7,3,25\}\); zero-energy cases included.
2. **Qualified-model and missing-assumption check:** let \(\phi(t)=(1-t^2)_+^3\), \(u(x)=\prod\phi(x_i)\), \(\Omega=(-1,1)^n\), \(\kappa=5n\), \(m=\kappa1_\Omega dx\), \(\nu=m-\Delta u\). This is a neutral bounded positive \(L^1\) realization of (1), not a lower-bound family. Since \(\phi''\le24/5\), \(\nu\ge0\); its mass is \(W=5n2^n\). Completed squares plus \(\kappa\int_{\Omega^c}v\ge0\) show this \(u\) is the corresponding nonnegative obstacle minimizer. Exact integration gives \(\int\phi^2=2048/3003\), \(\int(\phi')^2=1024/385\), and \(\|\nabla u\|^2=n(1024/385)(2048/3003)^{n-1}\). The units and tail price agree. In contrast, neither mere positive \(L^1\) nor generalized obstacle existence is a finite \(\dot H^{-1}\) assumption; (4) cannot be applied by label alone. No new private pressure recipe is published.
3. **Expansion:** the qualified model was checked at \(n=1,2,4,8,32,64\), \(R=1/4,1,4\); the cap source calculation has no selector/gate claim. Six hundred FLOAT product-radial comparisons used these dimensions and deterministic vectors \(v_i=(((i+3)(j+7)\bmod71)-35)/9\), \(i=0,\ldots,n-1\), \(j=1,\ldots,100\). Tolerance \(2\times10^{-14}\) is explicitly floating diagnostic, not an interval certificate. Total **46 EXACT assertions and 600 FLOAT diagnostics**. They do not numerically integrate the all-scale energy.

The decisive proof is S3; numerical algebra is supplementary. Primary statements and selected proof reading above are the author's reading receipt, distinct from independent auditors' own-transfer checks. R93 BCP, R94 variation and R94 cancelled-square reading are retained, not recounted as new. General noncompact \(L^1\) cap construction with controlled limits, source-uniform Dirichlet/near-scale budgets, and actual thin-annulus all-subfamily capacities remain unpaid.

## 同一耦合的位移尾归约

令ν为有限非负Borel来源，质量W>0，κ>0。设π是ν与σ=s dz之间的同质量真实耦合，0≤s≤κ。只要求实际存在该耦合，不假设其位移小。记d(y,z)=||y−z||∞，m(t)=π{d>t}，t≥0。Ω为任意可测的、独立于尺度的共同删集，允许空集。令

F_L(ν;Ω)=∫Ωᶜ(T_Lν−κ)₊² dx，h(C)=C+C⁻¹−2，C_L(t)=(1+2t/L)^n。

对每个L>0及t≥0，严格有

√F_L(ν;Ω) ≤ √[κ(W−m(t))h(C_L(t))]+m(t)L^(−n/2).        (PT1)

因此若R₀=(W/κ)^(1/n)，任意0<a<b≤∞满足

Eκ^[a,b](ν;Ω) ≤ ∫_[a,min(b,R₀)] inf_(t≥0) {√[κ(W−m(t))h(C_L(t))]+m(t)L^(−n/2)}² dL/L.   (PT2)

若a≥R₀则右侧按0理解。可取非负有理t的下确界；没有可测选择或极限交换缺口。整个右侧是同一π的位移尾分布，不按尺度替换来源或假设各尺度各自的参考密度能共同实现。右侧可以很大；取a↓0所得扩展实数上界可以为无穷。

证明。把同一π限制到{d≤t}和{d>t}，分别获得实际来源ν_g、ν_b及参考来源σ_g、σ_b。其质量为W−m、m，且σ_g≤σ≤κ dz。若y∈Q(x,L)且d≤t，则z∈Q(x,L+2t)，故q_g=T_Lν_g≤κ C_L(t)。实际卷积质量守恒∫q_g dx=W−m。

对0≤q≤κC，标量函数(q−κ)₊²/q在q>κ时为q−2κ+κ²/q且递增；q=0时其贡献为0。于是(q−κ)₊²≤κh(C)q，从而∫(q_g−κ)₊²≤κ(W−m)h(C)。另一方面实际方体两点交叠至多L^n，Tonelli给∫(T_Lν_b)² dx≤m²L^(−n)，适用于有限测度，无需来源有L2密度。由(q_g+q_b−κ)₊≤(q_g−κ)₊+q_b和真实dx上的Minkowski，得到PT1，包括Ω外的限制。

m(t)右连续，C_L(t)连续，因此PT1右侧可由t的右侧有理序列逼近。对非负有理t取可数下确界是可测函数，等于全部t的下确界。最后T_Lν≤W/L^n；L≥R₀时真实正超额恒为0。积分给PT2，没有把未扣阈值的RAW平方也置零。

若位移统一≤d，则t=d时m=0，PT1恢复R94所用单尺度界；R≥2nd时其积分恢复Eκ^[R,∞)≤κW(2nd/R)²。新形式允许对同一耦合按实际位移尾作可验证选择，仍须支付异常来源质量项m(t)²L^(−n)及其与好项的交叉项。不得只保留一个平均位移而丢弃该项。缺少几何条件时，一般平均位移替换不能作为已证工具。

这里没有假定ν任意小质量分量对能量影响小。原始平方包含二次密度放大；弱型终目标仍可能通过适应来源的共同Ω支付这种分量。针对任一固定删集的强估计失败不能推成最优删集或弱型反例。一般覆盖路线仍需构造同一删集并支付近尺度高负载。

## 实际三阶段探路的范围

主代理以真正正L1来源及同一密度参考进行初探、压力和扩大范围，全部使用Fraction。160个一维实际超额积分以分段仿射捕获函数的精确积分验证PT1；320项多维实际异常来源L2积分以张量交叠精确算出，核对m²L^(−n)；另2560项实际多维点捕获验证好、坏分量的界。不同单位不合并成断言数。阶段分别为32/64/64个一维积分、64/128/128个多维L2积分和512/1024/1024个点捕获。

另12项私人集中压力只检验一种过强运输简化，详细来源、参数、公式和导出下界留在私人材料中。它们不具备原Fnew全部门条件，也不是一般弱型或最优删集证据。生产程序实际运行0.556884417秒，独立重放与审计回执另记。没有FLOAT、Monte Carlo或从有限参数拟合维数指数。

# R95：连续多尺度来源、来源适应帽与近能量策略判别

本轮对三个新的正 L1 来源实际执行初探、压力和扩展计算。它们是不同宽度、不同质量的均匀盒混合，维数分别为 1、2、3；没有重复 R94 的张量来源或维数扫描。接收者使用原 n 维 Lebesgue 体积，帽与尺度无关。一般共同帽能量目标仍未证明。

两个比较得到严格有限输入证书。在一维来源、同预算 1 下，预定合并帽的真实成本低于逐分量帽的真实成本；在二维同一个物理来源、同预算 1 下，仅拆分重合标签便使逐标签帽的真实成本高于原逐分量帽。其余许多区间重叠，只能保留比较未决。Cyclic 删集的真实并集体积和来源参考也已计算，但粗运输尾在这三个来源中不能支付近尺度能量。

这些是所选具体构造的判别，不是一般指数、原 Fnew 门资格或算子弱型下界。所有来源及簇划分在费用比较前固定，没有看结果后挑选获胜划分。

## 1. 来源、阶段与原单位

质量和阈值均为 W = kappa = 1。定义：

```text
T_L(x) = nu(x+[-L/2,L/2]^n)/L^n
e(x) = integral_0^infinity (T_L(x)-1)_+^2 dL/L
E*(A) = inf_{measurable Omega, |Omega|<=A} integral_Omega^c e(x) dx
RAW(Omega) = integral_Omega^c integral_0^infinity T_L(x)^2 dL/L dx
```

每个来源分量都是实际均匀盒。下表给出中心、半宽、质量；它们完全指定密度，不是用中心原子替换弥散来源。

| 阶段 | 来源分量：中心；半宽；质量 | 新接收单元 |
|---|---|---:|
| 初探，n=1 | 0;1/4096;1/2。1/32;1/512;1/4。3/4;1/128;1/8。2;1/256;1/8 | 322 |
| 压力，n=2 | (-1/8,-1/8);1/1024;3/8。(-1/16,1/16);1/512;1/8。(1/16,-1/16);1/256;1/8。(1/2,1/2);1/128;1/8。(3/4,1/4);1/64;1/8。(3/4,3/4);1/32;1/8 | 1764 |
| 扩展，n=3 | (0,0,0);1/512;1/2。(1/4,0,0);1/128;1/8。(0,1/4,0);1/64;1/8。(0,0,1/4);1/64;1/8。(1/2,1/2,1/2);1/32;1/8 | 5832 |

合计 7918 个真实接收网格单元。二维压力阶段把第一分量分为八个完全重合、每个质量为原分量八分之一的标签；这不是新来源，也不重计新单元。按相同中心与半宽合并标签后，来源密度及其哈希严格不变。

原菜单预算 A = 1/8、1/4、1/2、1。每个阶段比较两种帽，共 24 项记录；其中 22 项有限、2 项 UNKNOWN。重合标签压力另有 8 项同物理来源记录，均有限。三个 cyclic 删集另有各自真实较大预算，全部有限。合计 35 个固定帽费用记录，33 项有限、2 项 UNKNOWN，不把重复来源或较大预算当作新低预算成功。

## 2. 预定来源适应帽与真实并集体积

第一种构造逐分量分配帽。第二种构造先合并预定簇：一维合并前两个分量、帽中心 1/64；二维合并前三个分量、中心 (-1/32,-1/32)；三维合并前四个分量、中心 (1/8,1/8,1/8)。其他分量单独成簇。

对每个分组 P，质量为 m_P，选择半边长 r_P：

```text
r_P = 向下 dyadic20 舍入的 (A*m_P)^(1/n)/2
Omega = union_P [center_P-r_P, center_P+r_P]^n
sum_P (2r_P)^n <= A
```

r_P 用整数二分及有理幂比较确定，保存准确来源标签、质量、中心、半边长和体积。并集体积不是各体积之和：程序由全部帽面形成互不重叠的真实矩形原子，逐原子判断成员关系，准确算并集及与每个接收单元的交集。重叠只收一次。全局帽体积包括接收计算域外的帽部分。

帽包住来源并不自动使粗网格上包络有限。粗网格中只要有未删除的零到达单元，就按帽面的真实分割对该局部继续计算；保留部分的体积之和准确等于未删体积。若局部仍有无限上包络，则保留 UNKNOWN。一维 A=1/8 的两个候选即属这种情形：没有以有限截断、代表点或“帽包含来源”的口号给有限上界，也没有声称其真实能量必为无限。

## 3. 全尺度能量包络与任意帽下界

对接收矩形与一个实际来源盒，近到达半径由各坐标间隙的最大值给出；远到达半径由所有端点距离的最大值给出。近阶跃过早计入整分量，支配真实部分捕获；远阶跃直到所有来源点均被所有接收点捕获才计入，受真实捕获支配。累积质量 M(L) 用实际混合权重求和。

这些全单元上下包络在所有尺度上积分。对某段固定累积质量 M，令 u=L^n，仅在 u0<u1 时积分：

```text
u1 = min(M, 下一到达尺度^n)
energy segment = M^2/(2n)*(u0^-2-u1^-2)
                 -2M/n*(u0^-1-u1^-1)
                 +(log(u1)-log(u0))/n.
```

它不是尺度求积或离散尺度最大值。对数用准确二进制范围归约、40 项 atanh 有理级数及几何余项，归一化实参向外 dyadic56，结果向外 dyadic44。各费用贡献再向外 dyadic52 后累加，包含全部舍入。

对下包络按密度排序允许任意单元内删除任意体积，给任意可测帽最优费用的下界。每个所选实际帽的上下界则使用它与每个真实接收单元的准确未删体积。两者量词不同：任意帽下界与具体帽上界没有互换。

来源在 [-b,b]^n，接收域取 [-R,R]^n，其中 R>=b+1/2。W=1 确保 L>=1 的 excess 为零；域外的 excess 也精确为零。这里不是有限盒代理模型：这些空间和尺度补集确已覆盖。

RAW 的阶跃积分使用累积平方增量：

```text
RAW segment sum = sum_j (M_j^2-M_(j-1)^2)/(2n*arrival_j^(2n)).
```

它不是各质量增量的平方和。RAW 在域外及大尺度不为零；每个同帽 RAW 上界额外包含

```text
RAW outside [-R,R]^n
 <= 2^(-n-1) sum_{k=0}^{n-1}
    binom(n-1,k)b^k / [(n+k)(R-b)^(n+k)].
```

这是实际径向 Lebesgue 壳积分上界。帽若在域外删去部分接收者，忽略该删去只会放大这个尾上界；其帽体积仍完整收费。

## 4. 两个严格的策略判别

一维 A=1 时，逐分量帽真实并集体积为 3/4，预定合并帽体积为 1。两个都符合预算 1。前者的能量下界约 0.000697837，后者的上界约 0.000041358。准确差距为

```text
singleton lower - merged upper
= 739129682861 / 1125899906842624 > 0.
```

所以此处合并帽实际更便宜。这只比较这两个所选帽；逐分量帽没有重新利用因重叠而节省的剩余预算。

二维 A=1 时，原逐分量帽上界约 0.02726306。只将第一来源分量拆成八个重合标签，逐标签帽的能量下界便约为 0.05197544。准确差距为

```text
split-label cap lower - original cap upper
= 55647342848527 / 2251799813685248 > 0.
```

物理来源、阈值和预算完全相同；标签拆分改变了半边长分配，使共同帽的真实并集体积变小，并留下未用预算。合并这些重合标签后，原帽的体积、excess 上界及全尾 RAW 上界都逐分数完全恢复。这证明本逐标签规则有表示依赖；不否定可选帽，也不否定其他来源适应构造。

其他候选比较的证书大多重叠。某个上界较小不等于证明其真实费用较小；JSON 只有在一个候选下界严格超过另一个候选上界时才标记严格成本次序。

## 5. 实际 cyclic 分解与来源参考

对同三个来源，再执行一个来源适应分解。选择包含全部来源、平均密度<=1/4 的 dyadic 根立方体，以其下角平移整个固定网格；按坐标循环逐次二分。首次平均密度>1/4 的矩形停止。父矩形平均密度<=1/4，故每个停止矩形的平均密度<=1/2。其最大边长 ell 不超过最小边长的二倍。

来源面均为 dyadic，程序选择能把全部来源面分开的有限最大深度。终层若有低密度的真实来源质量，会作为 good 保留，而非丢弃。在这三个输入中，每个正密度区域至少有一个密度>1 的分量，终层不可能有正的低密度来源质量。实际准确输出 Wbad=1、Wgood=0。

令 delta=1/n，把每个停止矩形按中心扩为 (1+delta)Q，组成同一个帽。真实并集仍由全部物理面分割计算，不能各尺度重收。同质量参考把来源限制 nu|Q 均匀化在原 Q 内；参考密度<=1/2，每个来源点位移不超过 ell。Cyclic 记录的 assigned source 是真实 nu|Q，不是原混合分量；扩大后的帽严格包住它。

下表十进制只是显示，分数在 JSON。

| n | 停止矩形数 | 帽真实全局并集体积 | 各扩大矩形体积和 | 同帽 excess 上界 | 同帽全空间全尺度 RAW 上界 |
|---:|---:|---:|---:|---:|---:|
| 1 | 3 | 4 | 21/4 | 0 | 0.540561 |
| 2 | 4 | 145/32 | 45/8 | 0 | 0.468391 |
| 3 | 8 | 2009/432 | 56/9 | 0.000011640 | 0.364654 |

这些帽使用自己的预算 4(1+1/n)^n Wbad，分别为 8、9、256/27；不能把它们硬塞入原菜单的 A<=1 比较。一维计算是辅助几何检查，coverage 的近占用定理域保留 n>=2。

实际来源质量按最大边长分布为：

```text
n=1: ell=1/8 mass=1/16; ell=1/2 mass=1/4; ell=2 mass=11/16
n=2: ell=1/2 mass=1/4; ell=1 mass=3/4
n=3: ell=1/2 mass=1/16; ell=1 mass=15/16
```

JSON 同时保留最大位移、质量加权 ell^2、全部停止矩形、质量、平均密度、深度、并集与域内交集体积。n=1 和 n=3 的帽确有部分位于接收计算域之外，其全局体积没有被域内交集替换。

Coverage 的近场定义为

```text
N_L = sum_{bad Q: ell_Q > L/(8n)} T_L(nu|Q).
```

程序没有把 N 的真实高负载剖面算出来。它给一个明确较粗的同帽上界：0<=N_L<=T_Lnu，因此 (N_L-1/3)_+^2<=T_Lnu^2，表中的同帽 RAW 上界也上界近场高能量。这不能证明该上界随维数具有所需阶。n>=2 的近场一阶占用数 Wbad*log(16n^2) 只是已证引理的准确对数包络，不是物理积分测量；n=1 不套用该定理。

## 6. 粗位移尾为何不能解决这里的近能量

另一个预定参考使用原点固定 dyadic 网格。从 h=1/64 逐次加倍，准确算实际来源与各网格格子的重叠质量，直到每格质量<=h^n。把同格质量均匀化即给参考密度<=1、位移<=h。没有声称这给最优运输位移。

三个输入第一次通过的粗尾起点 2nh 分别为 1、4、6。质量截止 (W/kappa)^(1/n) 恒为 1。实际 cyclic 参考的最大位移尾起点分别为 4、4、6。因所有正 excess 在 L>=1 已为零，这两种最粗尾估计不能支付本例在 L<1 的近能量。结果不是“尾检验成功所以一般支付”，而是粗截断在这些来源上的无收益判别。

最大位移不能代替完整质量分层；记录 ell 分布给后续细加权策略留下真实数据。没有假定各矩形的平方能量可免费独立相加，也没有把参考密度预算按尺度重复使用。

## 7. 执行、误差与范围

程序标准库、自包含、确定性，旧轮只读且不导入旧程序。运行：

```text
python3 energy_probe.py
```

初探、压力和扩展均实际执行。生产运行约 1.8 秒，stdout 给执行时间诊断，JSON 不含运行时，便于逐字重放。严格算术全部为 Fraction 和有理级数包络；表格小数均为显示近似，不作为向外舍入证书。没有浮点求积、Monte Carlo、有限尺度代理或一般指数拟合。

两个 UNKNOWN 仅是当前有限包络未获上界。实际全域、全尺度 excess 补集精确为零，RAW 补集尾完整保留。具体构造的比较与 arbitrary-cap 最优下界分别存储。结果说明来源适应和合并规则确会影响一个共同帽的费用；一般来源的近能量及细加权尾仍需支付，目标未完成。

The same full-period receiver law was tested against the original coarse gate with its unchanged threshold and a complete root-containing scale window. The bounded calculation remains unresolved and identifies a limitation of the chosen linear majorant; it does not prove actual gate failure. The previously certified hard-plus-smooth subset remains valid, while complete residual qualification and general weak-bound conclusions remain open.

Independent Astra audit: exact statements and counterpressure were checked before opening the corresponding author proofs. Complete matching Markdown and TeX proofs were then read. The general root-order weak bound remains OPEN.

- Coverage constructs one source partition, one bounded-density reference and one cap for every nonnegative L1 input. The near field has a paid logarithmic first-moment scale occupation. This alone does not pay its high-height second moment at the target order.
- Alternative adds one spatial occupation cap and pays the full all-scale energy with A <= 4e+1 and B = n log(32n^2) log(16n^2)/(1-2^(-n)). This is a complete O(n log^2 n) energy bound, yielding only O(n log n) through the retained weak-return formula. It is not the desired subpower energy coefficient.
- Adaptive's changed actual threshold and nonmonotone-bank growth are correctly paid, including child reclassification, exits and finite/infinite terminals. Its final initial-remainder estimate is dominated by a stronger direct positive decomposition. The remaining initial functional is quantitatively equivalent to the residual weak target; this strategy supplies no new root-order geometric budget. Original classification, localization and any separate kappa-layer fees remain.
- The source-potential tail has conditional constant 20/R^2 times the actual Dirichlet energy. Neither the Dirichlet budget nor near energy is supplied for general input. Primary reading statements belong to the source author's selected-reading provenance; this receipt covers the independent own-transfer proofs and does not claim rereading every primary dependency.
- The parent's common-coupling tail-profile bound and measurable infimum pass. Its full producer was independently replayed with exact mathematical JSON agreement, excluding only its top-level runtime field. The statement is a reduction, not an integrated subpower bound.
- The public energy producer/report pass full review and a final isolated byte-exact JSON replay. Native scope: three new actual L1 laws, 7918 true receiver cells, 35 fixed-cap records, 33 finite and two UNKNOWN. Split labels are the same physical law, not extra inputs. The selected-cap comparisons, arbitrary-cap lower bounds, full global volumes, and raw tails have distinct correct directions. The near-field profile was not numerically measured.
- The private original-coarse producer/report and isolated replay pass. Both new sufficient budgets remain UNKNOWN. A failure of its linear-majorant certification method is not an actual coarse failure; no new fully qualified residual volume or general capacity is certified. The prior original-P1 joint event retains its prior scope.

Author finite checks, independent producer replays, and the separate Sol guard are different evidence. Private recipes and quantitative restricted-rule lower conclusions remain outside this public summary. No Git or PDF compilation was performed by this audit.

## Independent audit: completed R95 checks

The arbitrary-positive-L1 all-scale centered-cube root-order weak target remains unproved. Sol read the complete round contract and independently checked the three route targets before authors' proofs. Review requires actual gated recursion, one globally paid common cap, no repeated source/volume billing, true scale duration and correctly paid joint-event likelihoods. Precise statements were independently checked before proof reads. Full dual-format review has accepted the common-coupling tail-profile reduction, logarithmic near-source occupation, conditional potential-tail theorem, and all-L1 occupation cap. The controlled-growth adaptive bank is correct, but its initial remainder is already obtained by direct selector domination and supplies no new geometric budget. Private coarse replay exactly matches its unresolved outcome and method limitation. The occupation-superlevel cap pays all scale duration with energy coefficient O(nlog²n), which falls short of the root target. Frozen public numeric replay is byte-exact; reviewed private and parent programs replay exactly within their stated timing exclusions. The independent portable guard rebuilds two new actual-source occupation profiles and 35 global cap geometries, with zero producer energy reconstructions. Two stored cost-gap arithmetic checks are separate. Author tests, actual certificate units and producer replays are distinguished, and prior-round tests are not new evidence. One RAW domain typo was caught and repaired in both coverage formats. No unresolved mathematical defect is identified within these scopes; the root target remains open.

## 第95轮实际验证与复现边界

三条路线、来源条件工具与主代理运输命题均在证明前提交精确命题，由Astra和Sol两名审核者先独立检查。其后两审完整读取对应MD及TeX；主代理完整审读新证明和关键程序。自适应路线的直接支配诊断、coverage数值节RAW必须限制同一Ω补集的修订均经双审。一般根阶目标未被认证。

公开程序最终实际运行1.765418375秒；主代理隔离重放1.658080708秒，两审最终独立重放外部墙钟1.583002791与1.571577042秒，全部数学JSON精确相同且无字段排除，两审结果文件逐字相同。早期cyclic来源包含字段的元数据修订未改费用分数，旧版本回执只作历史，不作为最终冻结验证或新实验。

公开数值有3个不同实际正L1来源，7918个真实接收单元；24项预定帽记录22有限、2UNKNOWN，同物理来源的标签拆分另8项均有限，3项cyclic帽均有限，共35项33有限、2UNKNOWN。各预算分别记录，不把cyclic较大预算当成原A≤1成功。两项严格差距仅比较所选具体规则，不是最优删集或弱型下界。空间和尺度的excess零补集已证；同帽RAW空间无穷尾完整保留。近场N本身未在此程序积分，其一阶占用上界引用一般定理，高能量只用同帽RAW上界。一维cyclic仅辅助几何，不扩展声明为n≥2的定理域。

替代路线作者最终执行2.884918167秒。三阶段15个真实盒密度模型、37个实际最大坏矩形、181项祖先检查；296个接收剖面的全尺度近场积分包含4538段多项式区间和9076个实际尺度节点。新增帽分类32内部、264外部、0未决。这些是指定接收点的完整尺度剖面，不是数值证明总体积。主代理从最终文本提取同一程序并隔离执行，精确复核三条JSON记录；最终时间见清单。低阈值T=1/n的帽体积条件只是待验证充分条件，尚须低高度背景压力测试，不能将其当作新已证容量。

自适应新程序450项精确检查分90/180/180，主代理从最终冻结文本提取隔离执行0.022184708秒。实际连续来源与接收体积完整保留，但私人压力没有实际子接触及原全部门条件。增长势的正确性不等于最终几何收益，直接支配与目标等价性已单列。

主代理完整位移尾程序实际生产0.556884417秒，独立临时复制重放0.613238500秒，两审外部墙钟0.602497208和0.712074417秒；全部数学JSON精确一致，仅删除顶层runtime_seconds。160项一维真实超额积分、320项多维实际异常来源L2积分、2560项点捕获分开计，另12项私人压力不公开配方和导出下界。分段Simpson在这里精确积分二次多项式，并有实际阈值切分；没有浮点求积替代证书。

原粗门只使用第94轮同一来源、阈值、提议法和原硬带，两个预定截断分别覆盖64/128个无间隙尺度单元。全n尾、实际均值、方差、严格门等号事件和联合Q失败预算均保留，之后才允许用同一似然转回Haar。两档均UNKNOWN；一个正的有理均值差距说明全窗线性均值加非负波动包络的方法无法给正半径，不能推成实际log、原首次接触或粗门失败。原已证硬加P1交集不被置零。生产51.388526秒，主代理隔离54.392008秒，Astra外部54.906182秒，Sol内部51.024923秒；数学JSON仅递归删除两个运行时间字段后完全一致，八项前轮依赖哈希全部保留。无新物理抽样、换源、改阈值、MC或CLT代证。

来源组46项EXACT与600项FLOAT诊断分开；它们没有数值积分全尺度能量。常数20由实际Fourier梯度证明承担。主代理阅读完整迁移证明；Astra审核自己的推导而未重读原文，Sol另读2026论文§2及1605.03102的相关定理条件，并未替代作者所述全部选择性原文阅读。紧支撑、有界密度、势有限能量、边界质量和外引存在性依赖均保留，一般非紧L1的合法极限尚缺。

独立公开守卫只依赖自身和energy_results.json：重新构造两条真实停止来源的全尺度占用剖面、35项全局帽几何/来源分割/预算见证，其中2帽确实超出接收计算域；另核两项已存差距的精确算术。它没有重建7918项生产能量，producer_energy_reconstructions明确为0。Sol独立运行外部0.073215375秒，主代理与最终归档提取的实测回执见清单及README；不同检查单位与重复执行不相加为新实验。

本轮实际使用更新64技能的E03、N04、D01、G01/G02/J03与L02边界；母技能入口和必要方法/接口按角色实际读取，不把当前64入口字节快照说成全库数学重验收。获授权只读证据根用于J03原文定位，未修改失效注册表。只有真实来源/收据范围内的文献作为工具，不以技能名补造定理。

归档仅公开报告、详细TeX文本、必要能量程序及结果、清单；私人程序、输入配方、量化下界和原论文PDF不公开。唯一公开Python代码块为独立守卫。LaTeX只作环境、括号、标签引用和控制字符静态核验，未编译。剩余一般目标是将共同删集高近场预算的维数系数降至子幂，或以原全门产生真正的新共同来源容量；并非省略现有费用即可达成。


## 独立公开审核程序

```python
"""Independent R95 public checks. No producer imports or private recipes.
Geometry and direct actual-source occupation profiles, not 7918 energy rebuilds.
"""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import json
import sys
import time


def volume(box):
    v = Q(1)
    for a, b in box:
        assert a < b
        v *= b-a
    return v


def overlap(a, b):
    v = Q(1)
    for (lo, hi), (left, right) in zip(a, b):
        v *= max(Q(0), min(hi, right)-max(lo, left))
    return v


def union_volume(boxes, domain=None):
    # Disjoint physical face atoms; the cap is global unless explicitly clipped.
    boxes = list(set(boxes))
    n = len(boxes[0])
    edges = [sorted({v for b in boxes for v in b[j]} |
                    (set(domain[j]) if domain else set())) for j in range(n)]
    total = Q(0)
    for indices in product(*(range(len(e)-1) for e in edges)):
        atom = tuple((edges[j][i], edges[j][i+1]) for j, i in enumerate(indices))
        midpoint = tuple((a+b)/2 for a, b in atom)
        if domain and not all(a <= x <= b for x, (a, b) in zip(midpoint, domain)):
            continue
        if any(all(a <= x <= b for x, (a, b) in zip(midpoint, box)) for box in boxes):
            total += volume(atom)
    return total


def source_boxes(payload):
    out = []
    for p in payload:
        e, m = Q(p['halfwidth']), Q(p['mass'])
        box = tuple((Q(c)-e, Q(c)+e) for c in p['center'])
        assert e > 0 and m > 0
        out.append((box, m))
    assert sum(m for _, m in out) == 1
    return out


def source_mass(box, sources):
    return sum((m*overlap(box, support)/volume(support) for support, m in sources), Q(0))


def check_cap(row, sources, domain, cyclic=False):
    packet = row['packets']
    if cyclic:
        bad = [tuple((Q(a), Q(b)) for a, b in p['bad_cell']) for p in packet]
        delta = Q(row['enlargement_delta'])
        cubes = [tuple(((a+b)/2-(1+delta)*(b-a)/2,
                        (a+b)/2+(1+delta)*(b-a)/2) for a, b in box) for box in bad]
        assert sum(source_mass(box, sources) for box in bad) == Q(row['bad_source_mass']) == 1
        assert Q(row['retained_good_source_mass']) == 0
        for i, (box, p) in enumerate(zip(bad, packet)):
            mass = source_mass(box, sources)
            assert mass == Q(p['mass'])
            assert Q(1, 4) < mass/volume(box) <= Q(1, 2)
            assert mass/volume(box) == Q(p['average_density'])
            assert max(b-a for a, b in box) <= 2*min(b-a for a, b in box)
            assert all(overlap(box, other) == 0 for other in bad[:i])
            assert p['assigned_source'] == 'actual restriction nu|bad_cell'
    else:
        labels = [i for p in packet for i in p['source_labels']]
        assert sorted(labels) == list(range(len(sources)))
        cubes = []
        for p in packet:
            r = Q(p['halfside'])
            center = tuple(Q(c) for c in p['center'])
            box = tuple((c-r, c+r) for c in center)
            mass = sum(sources[i][1] for i in p['source_labels'])
            assert mass == Q(p['mass'])
            assert volume(box) <= Q(row['budget'])*mass
            # Exact dyadic20 floor radius, independent integer-power comparison.
            assert volume(box) <= Q(row['budget'])*mass < (2*(r+Q(1, 2**20)))**len(center)
            cubes.append(box)
    assert sum(volume(c) for c in cubes) == Q(row['sum_individual_cube_volumes'])
    global_volume = union_volume(cubes)
    inside = union_volume(cubes, domain)
    assert global_volume == Q(row['actual_global_union_volume']) <= Q(row['budget'])
    assert inside == Q(row['cap_volume_inside_receiver_domain']) <= global_volume
    assert sum(volume(c) for c in cubes)-global_volume == Q(row['overlap_volume_charged_once'])
    if row['same_cap_excess_upper'] is not None:
        assert Q(row['same_cap_excess_lower']) <= Q(row['same_cap_excess_upper'])
        assert Q(row['same_cap_raw_lower']) <= Q(row['same_cap_raw_upper_including_outside_receiver_tail'])
    return global_volume > inside


def power_integral(exponent, a, b):
    assert exponent != -1  # These direct physical profiles need no logarithms.
    return (b**(exponent+1)-a**(exponent+1))/Q(exponent+1)


def occupation_profiles():
    # Q=[0,1]^2, mass1/3, kappa1: Q is truly maximal bad, parent average1/6.
    # Sources: uniform on Q; uniform on its corner [3/4,1]^2.
    # x=(2,1/2) for uniform, x=(2,7/8) for corner, both outside 1.5Q.
    # Actual capture is a*L+b on [2,end], totalmass1/3 afterwards.
    records = []
    for a, b, end, expected in [(Q(1,6), Q(-1,3), Q(4), Q(1,48)),
                                (Q(2,3), Q(-4,3), Q(5,2), Q(1,30))]:
        mass = Q(1,3)
        def first(cutoff):
            return (a*power_integral(-2,Q(2),end) +
                    b*power_integral(-3,Q(2),end) +
                    mass*power_integral(-3,end,cutoff))
        j, h = first(Q(16)), first(Q(32))
        # Independently integrate the exact spatial kernel from eq(6) over source.
        assert h == expected-Q(1,6*32**2)
        squared = (a*a*power_integral(-3,Q(2),end) +
                   2*a*b*power_integral(-4,Q(2),end) +
                   b*b*power_integral(-5,Q(2),end) +
                   mass*mass*power_integral(-5,end,Q(16)))
        critical = min(end, max(Q(2), -2*b/a))
        peak = max((a*L+b)/L**2 for L in [Q(2),end,critical])
        cn = Q(8,3)
        assert peak <= cn*h and squared <= cn*h*j
        for L in [Q(2),end,Q(8),Q(16),Q(32)]:
            capture = max(Q(0), min(mass,a*L+b))
            near = capture/L**2 if L < 16 else Q(0)
            for u in [L,3*L/2,2*L]:
                wider = max(Q(0),min(mass,a*u+b))/u**2 if u < 32 else Q(0)
                assert wider >= (L/u)**2*near
        records.append({'h':str(h),'N_first_moment':str(j),'N_square':str(squared)})
    return records


def main(path):
    start = time.perf_counter()
    data = json.loads(Path(path).read_text())
    profiles = occupation_profiles()
    cap_count = outside_count = 0
    for st in data['stages']:
        c = st['physical_case']; n = c['n']; R = Q(c['receiver_R'])
        sources = source_boxes(c['actual_uniform_box_mixture'])
        domain = tuple((-R,R) for _ in range(n))
        assert Q(c['true_full_receiver_volume']) == (2*R)**n
        for curve in c['curves']:
            rows = curve['source_adapted_caps']
            for row in rows:
                outside_count += check_cap(row,sources,domain); cap_count += 1
            for key, receipt in curve['same_source_same_budget_selected_cap_comparisons'].items():
                left, right = [int(x) for x in key.replace('cap','').replace('_lower_minus_', ' ').replace('_upper','').split()]
                gap = Q(rows[left]['same_cap_excess_lower'])-Q(rows[right]['same_cap_excess_upper'])
                assert gap == Q(receipt['gap'])
                assert receipt['strict_actual_cost_order_certified'] == (gap>0)
        row = c['cyclic_stopping_cap']
        outside_count += check_cap(row,sources,domain,True); cap_count += 1
        if n == 1:
            receipt = c['curves'][-1]['same_source_same_budget_selected_cap_comparisons']['cap0_lower_minus_cap1_upper']
            assert Q(receipt['gap']) == Q(739129682861,1125899906842624) > 0
        if 'same_physical_input_label_pressure' in st:
            pressure = st['same_physical_input_label_pressure']
            split_sources = source_boxes(pressure['split_actual_source_labels'])
            for curve, base in zip(pressure['curves'],c['curves']):
                for key in ['split_component_singleton_cap','coincident_merge_cap']:
                    outside_count += check_cap(curve[key],split_sources,domain); cap_count += 1
                restored = curve['coincident_merge_cap']; original = base['source_adapted_caps'][0]
                for key in ['actual_global_union_volume','same_cap_excess_upper','same_cap_raw_upper_including_outside_receiver_tail']:
                    assert restored[key] == original[key]
            last = pressure['curves'][-1]
            gap = Q(last['split_component_singleton_cap']['same_cap_excess_lower'])-Q(c['curves'][-1]['source_adapted_caps'][0]['same_cap_excess_upper'])
            assert gap == Q(last['split_lower_minus_original_upper']) == Q(55647342848527,2251799813685248) > 0
    print(json.dumps({'independent_actual_stopped_source_profiles':profiles,
        'global_cap_geometry_witnesses':cap_count,'caps_extending_outside_receiver_domain':outside_count,
        'cost_gap_arithmetic_only':2,'producer_energy_reconstructions':0,
        'seconds_diagnostic':time.perf_counter()-start},sort_keys=True))

if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv)>1 else Path(__file__).with_name('energy_results.json'))
```
