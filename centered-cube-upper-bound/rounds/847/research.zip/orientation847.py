"""R847. Same-source two-receiver geometry; exact volumes, certified parameter thresholds."""
from decimal import Decimal, localcontext
from fractions import Fraction as Q
from itertools import product
from math import comb
import sys

import flint
from flint import arb, ctx


def decimal_text(q):
    with localcontext() as c:
        c.prec = 18
        return f"{Decimal(q.numerator) / Decimal(q.denominator):.10E}"


def rational_ball(x):
    return arb(x.numerator) / x.denominator


def bounds(x):
    left, right = Q(0), Q(1, 2)
    if x >= rational_ball(right):
        return right, right
    assert 0 < x < rational_ball(right)
    for _ in range(26):
        middle = (left + right) / 2
        a = rational_ball(middle)
        if a < x:
            left = middle
        else:
            assert x < a
            right = middle
    return left, right


def small_axis_count(n, H):
    bound = (H / 16).exp()
    total, d = 1, 0
    while d < n:
        enlarged = total + comb(n, d + 1)
        if arb(enlarged) > bound:
            break
        assert arb(enlarged) < bound
        total, d = enlarged, d + 1
    assert arb(total) <= bound
    return d


def binomial_low(n, prob, d):
    if prob == 0:
        return Q(1)
    if prob == 1:
        return Q(d >= n)
    p, q = prob.numerator, prob.denominator - prob.numerator
    atom, numerator = q**n, q**n
    for i in range(min(d, n)):
        top, bottom = atom * (n-i) * p, (i+1)*q
        assert top % bottom == 0
        atom = top // bottom
        numerator += atom
    return Q(numerator, prob.denominator**n)


def sparse_volume(n, d, kappa):
    # L=1. Unrestricted outer cube has side 2, inner cube side 1+kappa.
    return sum(comb(n, q) * (1 + kappa)**(n - q) * (1 - kappa)**q
               for q in range(d + 1))


def same_source_case(n):
    N = n + 2
    ell = arb(N).log()
    H = ell**2 + 8 * ell
    kappa_low, kappa_high = bounds(H / (32 * n))
    d = small_axis_count(n, H)
    c = Q(1, 100 * (n + 1))
    s, t = Q(2), Q(1)
    xs, ys = s - 2 * c, t - 2 * c
    # R has common packet [-c,c]^n. Entire packet is in every admissible source box.
    # In axis 1 centers use disjoint intervals [1/8,1/4], [-1/4,-1/8].
    assert c + Q(1, 4) < t / 2
    assert Q(1, 2) < s / 2
    def crossed(kappa):
        threshold = (1 + kappa) * s / 2
        assert threshold >= abs(xs - ys) / 2
        length = max(Q(0), (xs + ys) / 2 - threshold)
        return length**2 / (xs * ys)
    lower = binomial_low(n - 1, crossed(kappa_low), d)
    upper = binomial_low(n - 1, crossed(kappa_high), d)
    assert 0 <= lower <= upper <= 1
    # For the proved linear threshold, also test the untrimmed independent reference
    # and the actual positive receiver packet (axis 1 has no crossing).
    pmin = Q(9,128)
    linear = binomial_low(n, pmin, n//32)
    actual = binomial_low(n-1, crossed(Q(1,8)), n//32)
    # Lin/binomial tail evaluated with a shared denominator, exactly as below.
    assert arb(linear.numerator)/linear.denominator < (-arb(9*n)/1024).exp()
    print("linear threshold n", n, "max sparse axes", n//32,
          "reference worst sparse probability", decimal_text(linear),
          "actual restricted sparse probability", decimal_text(actual))
    # R847's geometric covering volume and conservative combinatorial bound.
    for kappa in (kappa_low, kappa_high):
        assert sparse_volume(n, d, kappa) <= (1 + kappa)**n * sum(comb(n,q) for q in range(d+1))
    print("n", n, "d", d, "kappa in", str(kappa_low), str(kappa_high),
          "conditional old/new sparse probability endpoints (rounded)",
          decimal_text(lower), decimal_text(upper))


def prefix_check():
    # Actual bins have t<=4. Check the pure scalar first-passage inequality independently.
    pairs = ((0, 0), (1, 0), (2, 1), (4, 4))
    total = 0
    for rows in product(pairs, repeat=5):
        kept = [b for a, b in rows]
        loss = sum(a-b for a,b in rows)
        for lag in (0, 1, 2):
            for T in (1, 3, 5):
                raw = sum(a for k,(a,_) in enumerate(rows) if sum(kept[:max(0,k-lag)]) < T)
                # j<k-lag means j=0,...,k-lag-1.
                assert raw <= T + 4*(lag+1) + loss
                total += 1
    print("exact prefix tests", total)



def density_identity():
    # sigma=(5/4)background + a spike of mass 1/4 on [-c,c]^n; eta is this cut.
    # Every center in either small receiver core has height between 5/4 and 3/2.
    for n in (2, 8, 32):
        c = Q(1, 100*(n + 1))
        packet = (2*c)**n
        m = Q(1,4) + Q(5,4)*packet
        vx, vy = Q(2)**n, Q(1)
        wx, wy = Q(3,4), Q(1,3)
        # Core centers x=(1-2c,...), y=(-1/2+2c,...), each halfwidth c/4.
        assert 1 - 2*c + c/4 + c < 1 and Q(1,2) - 2*c + c/4 + c < Q(1,2)
        hx_sqrt, hy_sqrt = m/vx, m/vy
        direct = wx*wy*m**3 / (vx*vy)**2
        for g in (Q(7,2), Q(4), Q(9,2)):
            inter = (g*c)**n
            ratio, phi = wx*wy*m/inter, inter/(vx*vy)
            assert direct == ratio*hx_sqrt*hy_sqrt*phi
        print("concentrated positive source n", n, "minimum joint density factor over receiver cores",
              decimal_text(wx*wy*m/(Q(9,2)*c)**n))

def passive_identity():
    for s, t in product((Q(1), Q(9,8), Q(7,4), Q(2)), repeat=2):
        L, m = max(s,t), min(s,t)
        exact = ((L-m)*m**2 + 2*m**3/3) / (s*t)**2
        formula = (1-m/(3*L))/L
        assert exact == formula <= Q(5,6)/s
    print("exact two-receiver trapezoid square integrals", 16)


if __name__ == "__main__":
    ctx.prec = 192
    print("Python", sys.version.split()[0], "python-flint", flint.__version__, "Arb precision", ctx.prec)
    print("Common source packet and two disjoint positive-volume receiver boxes; given old/new slots.")
    print("Conditional receivers uniform on their own boxes; both other sources keep original integral.")
    print("These source-receiver tests do not impose a large source load.")
    prefix_check()
    passive_identity()
    density_identity()
    for dimension in (2, 16, 64, 256, 1024, 4096):
        same_source_case(dimension)
