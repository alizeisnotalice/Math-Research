"""Exact two-receiver integrals on finite positive-width source and receiver boxes."""
from collections import namedtuple
from decimal import Decimal, localcontext
from fractions import Fraction as F
import sys

RHO = F(3, 2)
LAM = F(1)
SOURCES = {"q": (F(-1, 16), F(1, 16)),
           "L": (F(-5, 8), F(-1, 2)),
           "R": (F(1, 2), F(5, 8)),
           "f": (F(13, 16), F(15, 16))}
WIDTHS = {key: hi - lo for key, (lo, hi) in SOURCES.items()}
Receiver = namedtuple("Receiver", "name center width side")
Old = namedtuple("Old", "receiver partner fraction")


def receiver(name, center, side, width=F(1, 16)):
    return Receiver(name, F(center), F(width), F(side))


def labels(r):
    stable = set()
    for key, (lo, hi) in SOURCES.items():
        extent = r.side / 2
        shift = r.width / 2
        if r.center + shift - extent < lo and hi < r.center - shift + extent:
            stable.add(key)
        else:
            assert hi < r.center - shift - extent or r.center + shift + extent < lo
    return stable


def bin_index(side, n):
    volume = side ** n
    j = 0
    while 2 ** j < volume:
        j += 1
    assert j == 0 or 2 ** (j - 1) < volume
    return j


def volume(r, n):
    return r.width * r.side ** (n - 1)


def tau_density(r):
    return (RHO * sum(WIDTHS[key] for key in labels(r)) / r.side) ** 2 / LAM


def old_density(row):
    assert 0 < row.fraction <= 1
    assert {"q", row.partner} <= labels(row.receiver)
    value = row.fraction * RHO ** 2 * WIDTHS["q"] * WIDTHS[row.partner]
    value /= LAM * row.receiver.side ** 2
    assert value <= tau_density(row.receiver)
    return value


def intersect(s, t, distance):
    return max(F(0), min(s, t, (s + t) / 2 - distance))


def moment(s, t, stop, exponent):
    """Compute twice the integral of the raw overlap^exponent from 0 to stop."""
    breaks = {F(0), stop}
    for cut in (abs(s - t) / 2, (s + t) / 2):
        if 0 < cut < stop:
            breaks.add(cut)
    ends = sorted(breaks)
    return sum((hi - lo) * (intersect(s, t, lo) ** exponent
                            + 4 * intersect(s, t, (lo + hi) / 2) ** exponent
                            + intersect(s, t, hi) ** exponent) / 3
               for lo, hi in zip(ends, ends[1:]))


def paired_second(s, t):
    # The law of receiver displacement has density equal to the raw overlap.
    integral = moment(s, t, (s + t) / 2, 3)
    a = min(s, t)
    assert integral == abs(s - t) * a ** 3 + a ** 4 / 2
    return integral / t ** 2


def profile(n, current, inputs):
    """Exact O, B, and support volume for the transverse center of current."""
    first = second = support = F(0)
    for old, density in inputs:
        if not density:
            continue
        one = moment(current.side, old.side, old.side / 2, 1) / old.side
        two = moment(current.side, old.side, old.side / 2, 2) / old.side ** 2
        first += density * old.width * one ** (n - 1)
        second += density ** 2 * old.width * two ** (n - 1)
        support += volume(old, n)
    if not second:
        return F(0), F(0), F(0)
    effective = first ** 2 / second
    assert 0 < effective <= support
    return first, effective, support


def generate(case):
    n, b, plus_side = ((2, 1, "3/2"), (4, 2, "7/4"), (32, 16, "2"))[case]
    thin = case == 1
    x = (receiver("X+", "9/16", plus_side), receiver("X-", "-9/16", "7/4"))
    old = (
        Old(receiver("Y_L1", "-1/4", 1, "1/4096" if thin else "1/16"),
            "L", F(1) if thin else F(3, 4)),
        Old(receiver("Y_L2", "-3/8", 1), "L", F(1, 65536) if thin else F(1, 4)),
        Old(receiver("Y_R1", "1/4", 1), "R", F(1, 65536) if thin else F(1, 2)),
        Old(receiver("Y_L3", "-1/8", "9/8"), "L", F(1, 16) if thin else F(5, 8)),
        Old(receiver("Y_R2", "3/8", "5/4"), "R", F(1, 16) if thin else F(1, 2)),
    )
    rows = sorted((*x, *(z.receiver for z in old)), key=lambda r: r.center)
    for row in rows:
        assert abs(row.center) + row.width / 2 + 1 < 4
        assert 1 <= row.side <= 2
        assert labels(row)
    assert all(t.center - t.width / 2 > s.center + s.width / 2
               for s, t in zip(rows, rows[1:]))
    return n, b, x, old


def costs(n, b, current, old):
    mass_old = sum(old_density(row) * volume(row.receiver, n) for row in old)
    mass_current = sum(tau_density(r) * volume(r, n) for r in current)
    lhs = F(0)
    eligible = []
    for x in current:
        k = bin_index(x.side, n)
        js = []
        for row in old:
            y = row.receiver
            j = bin_index(y.side, n)
            if j > k - b:
                continue
            js.append(j)
            assert "q" in labels(x)
            # tau^X[x]/s_x^2 = dx/(lambda*v_x^2). O^2/B = integral u^2 dy.
            raw = x.width * y.width * old_density(row) ** 2
            raw *= paired_second(x.side, y.side) ** (n - 1)
            lhs += 2 ** j * raw / (LAM * x.side ** (2 * n))
        eligible.append((x.name, k, sorted(js)))
    baseline = F(2) ** (-b) * mass_old
    assert 0 < lhs <= 32 * baseline
    return mass_current, mass_old, lhs, baseline, eligible


def fmt(value):
    with localcontext() as context:
        context.prec = 14
        return f"{Decimal(value.numerator) / Decimal(value.denominator):.8E}"


def do_case(case):
    n, b, current, old = generate(case)
    current_mass, old_mass, lhs, baseline, eligible = costs(n, b, current, old)
    print(f"stage={case + 1} n={n} b={b}; eligible (X,k,old bins)={eligible}")
    print("  |tau^X|, |R|, LHS, 2^(-b)|R|, ratio", *(fmt(a) for a in
          (current_mass, old_mass, lhs, baseline, lhs / baseline)))
    x = current[0]
    y = old[0].receiver
    in_bin = [(row.receiver, old_density(row), row.partner) for row in old
              if bin_index(row.receiver.side, n) == 0]
    forward = profile(n, x, [(r, d) for r, d, _ in in_bin])
    switched = profile(n, x, [(r, d) for r, d, partner in in_bin if partner in labels(x)])
    reverse_inputs = []
    for r in current:
        shared_length = sum(WIDTHS[key] for key in labels(y) & labels(r))
        local_length = sum(WIDTHS[key] for key in labels(r))
        reverse_inputs.append((r, tau_density(r) * shared_length / local_length))
    reverse = profile(n, y, reverse_inputs)
    print("  center X+ j=0 keeping q: O, B, support, B/support", *(fmt(z) for z in
          (*forward, forward[1] / forward[2])))
    print("  center X+ j=0 keeping partner: O, B, support", *(fmt(z) for z in switched))
    print("  reverse center Y_L1 against raw current tau^X: O, B, support",
          *(fmt(z) for z in reverse))
    if case == 0:
        print("  exact LHS, baseline, forward B:", lhs, baseline, forward[1])
    if case == 1:
        assert forward[1] < forward[2] / 100
        thin_parent = profile(n, x, [(y, old_density(old[0]))])
        mass_share = thin_parent[0] / forward[0]
        volume_share = thin_parent[2] / forward[2]
        assert (mass_share, volume_share) == (F(128, 129), F(1, 513))
        print("  Y_L1 shares of forward O and support:", mass_share, volume_share)


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "Fraction exact; display scientific rounded.")
    print("sigma=3/2 on [-4,4]^n; all used receiver centers have M_[1,2]=3/2.")
    print("Only listed current boxes and old ordered subflow R are integrated, not the full band.")
    print("B profiles use the actual central receiver position; LHS integrates all box positions.")
    for index in range(3):
        do_case(index)
