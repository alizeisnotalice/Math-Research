# R252：固定尺度精确Gram、真实max诊断及共享阈值小例

最终实际完成9个fixed-scale盒模型（初探3、压力3、扩大3），1251个Gram entries、83个source cells、237个缓存的一维精确内积。9组指定非负mass Rayleigh、9组rounded Perron mass Rayleigh、83个对角归一化及9个有限row-sum operator证书全部通过。MATLAB eig实际运行，仅作谱候选，不当通用常数证明。

**这9例不是9个新的coarse-low门实例。** 它们验证有限胞内来源的固定尺度量；d=a/(8sqrt(n))与质量门下的任意全域low来源证明在main S3。这里高维只有3个门槛标量比较，没有高维L1来源或receiver。主代理另跑的tensor谱/原来源masscut检查不并入本文件模型数。

另有同一来源的3组多尺度max²积分夹逼（7196 receiver cells），1个compare双源/三receivercell阈值证书，以及3个高维质量门标量。辅助阈值例包含更强direct-cell基线，不能把新共享尾价说成实际最优或优于全部已知cell geometry。

## 固定尺度输入和精确积分

原规则cell为product_j[i_j d,(i_j+1)d)，每cell内放一个正体积小均匀盒，box side=l，center按菜单移动，逐坐标核box仍在其原cell内。mass总和为1；非均匀菜单的mass按确定正整数weights归一。没有用cell均匀化替换实际source。

|阶段/模型|n|grid size|d,R|胞内box|
|---|---:|---:|---|---|
|初探centers_n1|1|3|1/2,1|center，side=d/2|
|初探centers_n2|2|2²|1/2,1|center，side=d/2|
|初探centers_n3|3|2³|1/3,1|center，side=d/2|
|压力paired_n1|1|4|1/4,1|side=d/16，成对向共边jitter|
|压力vertex_n2|2|2²|1,1|side=d/32，均向共同vertex|
|压力vertex_n3|3|2³|1,1|side=d/32，均向共同vertex|
|扩大fine_grid_n1|1|16|1/16,1|side=d/16，成对jitter|
|扩大jitter_grid_n2|2|3²|1/2,3/2|side=d/8或d/16、非均匀mass|
|扩大jitter_grid_n3|3|3³|1/2,1|side=d/8或d/16、非均匀mass|

对一维单位质量box，硬核卷积为g(x)=overlap([z-l/2,z+l/2],[x-R/2,x+R/2])/(Rl)。其knots是z±(R+l)/2、z±|R-l|/2。两条梯形在每共同子段都线性，端点值为p0,p1,q0,q1时，内积是

segment_length*(2p0q0+p0q1+p1q0+2p1q1)/6。

全部Fraction积分，再将各坐标内积相乘，得G_ij=integral(h_R*normalized_box_i)(h_R*normalized_box_j)。83个对角另核[1/R-l/(3R²)]^n（本菜单l<=R）。Gram来自真实L2内积，PSD不是由浮点eig断言。

相对原cell L2 baseline sum m_i²/d^n，scaled matrix为d^n G。指定非负m的能量m^TGm精确；MATLAB算scaled matrix最大eigenvalue与Perron向量，向量取abs、最近1e-12 Fraction、再精确归一mass后，独立核其Rayleigh。所有原始G、box、mass与rounded Perron mass保存JSON。

此外G逐项非负且对称，2|x_i x_j|<=x_i²+x_j²给有限operator bound<=max row sum。9例scaled最大row sum均精确不超过(1+32d²/R²)^n，故各自有限box-profile family确有operator证书；这只允许同一已冻结box profiles上的mass变化，绝不认证所有胞内任意L1来源或通用C=32。

## 主要固定尺度数值

|模型|MATLAB max eigenvalue|exact scaled max row sum|候选界|
|---|---:|---:|---:|
|centers_n1|0.822456809299|0.958333333333|9|
|centers_n2|0.501736111111|0.501736111111|81|
|centers_n3|0.154886196210|0.154886196210|94.5418381344|
|paired_n1|0.744812225308|0.748697916667|3|
|vertex_n2|3.83506944444|3.83506944444|1089|
|vertex_n3|7.51034432870|7.51034432870|35937|
|fine_grid_n1|0.679707865023|0.749918619792|1.125|
|jitter_grid_n2|0.520315941810|0.599285193759|20.7530864198|
|jitter_grid_n3|0.908223961013|0.969074390553|729|

共顶点两例的指定uniform mass精确Rayleigh也分别为3.83506944444、7.51034432870，所以固定尺度不能在这些来源上把因子直接置1。但候选32价在这些例中很宽，不据这些数值估计最佳通用常数或高维规律；有限grid的边缘效应也不可当一般谱衰减。

## 固定尺度到sup的真实receiver诊断

仅选centers_n1、vertex_n2、vertex_n3三种原来同一mu，未生成新source模型。R grid={1,5/4,3/2,7/4,2}。receiver boxes覆盖实际source support加Q_2的全部可能正响应区域；cell sides分别1/64、1/16、1/8，counts为208、1156、5832。

每整receivercell，以各source盒交的下/上界正相加；finite-grid max lower Lcell是实际sup的下界。连续R上界Ucell由mass单调得到upper_mass(Rj+1)/Rj^n。积分Lcell²、Ucell²乘真实cell体积，得到实际sup L2²的Fraction夹逼，不把grid max当sup等价。

|来源|sup L2²/fixed_R L2²严格夹逼|
|---|---|
|centers_n1|[1.14751843568,1.58507733010]|
|vertex_n2|[1.28907311065,2.20906986108]|
|vertex_n3|[0.79560531020,2.78969130820]|

前两例下界已大于1，证明这些有限实际输入的adaptive费用确超过所选固定尺度；这不是新的通用sup bound。三维粗receivercell的下界不足以判断增加，区间跨1，故不作增加结论、也不为它继续细扫。完整固定R能量在Gram中独立精确积分，非从receivergrid估算。

## 双源/三胞共享尾证书与更强基线

采用compare准确例：n1,a1,b101/100，source density15/2，intervals[-1/4,-3/20]及[3/20,1/4]，mass3/4各。receiver按本JSON顺序(L,R,M)为[-3/5,-1/2]、[1/2,3/5]、[-1/1000,1/1000]，体积1/10、1/10、1/500。

Fraction逐receiver核所有R窗完整包含活跃source、在最大R仍排除另一侧source；缩小几何support盒也作端点核验。因归一化随R递减，individual sup cap恰为

U1=(3/4,0,3/4)，U2=(0,3/4,3/4)。

每source共享weak常数a_i=(11/10)(3/4)=33/40；对0<t<3/4，a_i/t>1，而全部活跃cell体积仅51/500。故共享ai/t不绑定，但从未给每cell复制一份ai/t。

u=1，old kappa1/2、whole-E active阈1/4，精确总价153/500。new kappa3/4，threshold matrix (columns L,R,M)

[[3/4,0,3/8],[0,3/4,3/8]]

逐cell资源均正好用满3/4；cap equality的outer tails为0。按不同atomic阈值各自付费并池化各source尾容量，middle atomic和integral各每source3/4000，完整new价3/250。kappa0、所有阈0的whole-E static价153/1000；compare已证明这也是整个指定whole-E静态族的最小值。

**这不是实际最优cell价。** 本例U等于真实constant fi，因此直接Qcell(1)=1/500，比3/250更小；真实integral_E Mmu=153/1000，也比以下全层新价更好。代码从U与receiver体积精确计算这些量，保全两个sources，不只比较某一簇的log。

在同epsilon1/4、X=101/500，允许保旧价于其它levels、用新计划于[1,3/2)，完整layer价格由compare LG11–12给

Cold=(153/1000)[1+log(101/51)]≈0.257544117269891，
Cnew=Cold-(141/1000)log(3/2)≈0.200373537026640。

这说明相对于指定whole-E static-threshold族的严格全层下降，不能说优于所有已知receiver geometry、direct baseline或general root价。以上最终log以mp40/70各求值，非directed interval；阈值、atomic/integral常数与资源为Fraction。

如需原硬band，f=mu1+mu2+(3/2)1[-2,2]是真实有限L1 ambient source；所有相关windows仍在[-2,2]内，故原full response在outer cells为9/4、middle为3，2<G0<=4且mu<=f。这仅认证此kernel/cell geometry，不认证FULL/history、原FIRST或双后验桥。

## 新粗门与旧细门的高维标量比较

仅n=256,1024,4096，sqrt(n)为16,32,64。固定a=lambda1，新d=1/(8sqrt(n))、mass threshold=d^n/sqrt(n)，旧d0=1/n、sigma_old=sqrt(n)给旧threshold=sqrt(n)d0^n。因此精确比为(sqrt(n)/8)^n/n，分别等于

2^248，2^2038，2^12276。

代码只用有理base与整数幂指数核验，避免构造巨大source或高维receiver。它表明门槛参数变化，不是3个高维coarse-low实际例，也不能由比值推断剩余high source已付。通用low强L2价3 exp(5/2)lambda sqrt(n)W及其原来源masscut由main S3证明，未借本低维模型替代。

## 工具版本、实际运行与迁移复现

实际MATLAB 26.1.0.3312084 (R2026a) Update4；只用基本eig，未用Optimization Toolbox或QP。Python3.12.14、vendor mpmath1.3.0；无需numpy/scipy。Gram、finite row-sum、指定mass能量和cell界为Fraction；MATLAB eigenvalues是普通double，rounded Perron只是另一个严格有理mass witness，不是高精度eigen enclosure。展示Fraction小数用mp70，不称Gram作40/70浮点验证。

实际完成pre-freeze主运行、辅助Fraction函数核验及冻结合同后的正式完整主运行；没有扩展9+3菜单，没有额外timing replay。root随后从包外作唯一完整独立重放（含MATLAB）。在解压同目录保numeric_checks.py、gram_spectrum.m、task_contract.md，运行：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 numeric_checks.py --contract task_contract.md --output replay.json --matlab /Applications/MATLAB_R2026a.app/bin/matlab
cmp numeric_checks.json replay.json
```

CLI支持--output/--contract/--matlab，默认相邻JSON/合同和已知MATLAB executable。仅在临时目录产生MATLAB输入/输出，退出清理；不reset path，只添加同目录helper。JSON不含runtime/时间戳/绝对路径，绑定Python/MATLAB源码和冻结合同SHA。counts明列9 fixedscale、3 adaptive、1 cellthreshold、3高维门槛；没有混入主代理另套tensor谱/masscut计算。

冻结Python SHA256：54985253d3faff0b98e2efb96a8d496fd2509ea57031a536b30be68e6146a9d6；MATLAB SHA256：5a4a3760045d9f43f89dc2d49cbd9d4c4643a986b0a897346a69973ad28ac33f；JSON69913字节，SHA256：f46aa7951f659fe99852ca811f52577135200c6ca9b58ec4303636227e1ae435；合同SHA256：f8ec576aef21eeb2ad6ecb9be6981f80a46f2d63804a4e4ded48bb260fe85187。
