# R252 独立审计

## 命题先行筛查（未读作者稿）

目录尚空时独立检查。对象为同一规则d网格、任意有限非负L1来源µ，每胞质量m_C；R>0必须是全来源共同的固定半径。候选为

`||h_R*µ||_2² ≤ (1+32d²/R²)^n Σ_C m_C²/d^n`。

**初筛PASS，可由dual cell-sup采样与精确tensor谱界证明，不需均匀化µ。** 下面记录独立证明机制，之后再对作者稿逐项核验。

### 1. 实际来源与dual采样

对Schwartz测试g，令F=h_R*g。正µ及胞mass给

`|∫F dµ| ≤ (Σm_C²/d^n)^(1/2) [Σd^n sup_C|F|²]^(1/2)`。

这里只对真实µ积分，未替换胞内分布。有限µ保证Σm_C²<∞。一维区间G的sup≤其均值+∫|G'|，逐坐标作用于G=|F|²，再对所有网格胞积分求和，得

`Σd^n sup_C|F|² ≤ Σ_{A∩B=∅} d^(|A|+|B|) ||∂_A F||_2 ||∂_B F||_2`。

每坐标只取一次导数；复值F使用conjugate的Leibniz式取绝对值即可。该全subset和不能改成逐阶Minkowski再漏组合数。

### 2. tensor谱证书与标量32

令M=[[1,d],[d,0]], D=diag(1+η,d²/η)，η>0。N=D^(−1/2) M D^(−1/2)的特征值恰为1及−η/(1+η)，所以||N||op=1，进而N的n-fold tensor所有特征值≤1；即使M不正定仍有M^tensor n≤D^tensor n。这一步不能仅从M≤D直接假定tensor保序。对向量a_A=||∂_A F||_2，得到权平方和

`Σ_A(1+η)^(n−|A|)(d²/η)^|A| ||∂_A F||_2²`。

采用Fourier e^(−ixξ)，h_R乘子为∏sinc(Rξ_i/2)。标量所需为

`(Rξ)² sinc²(Rξ/2) ≤32[1−sinc²(Rξ/2)]`。

置u=Rξ/2：|u|≤2时Taylor的交错余项给1−sinc²u≥u²/3−2u⁴/45≥7u²/45≥u²/8，而sin²u≤u²；|u|≥2时sinc²u≤1/4，所以sin²u≤1≤8(1−sinc²u)。故标量32对全实频率成立，u0按连续值。

选η(1+η)=32d²/R²，Fourier每坐标因子

`(1+η)sinc² +(d²/η)ξ²sinc² ≤1+η`。

Plancherel给采样平方和≤(1+η)^n||g||²，且η≤32d²/R²。因此dual推出候选，保全部组合数和体积单位。Schwartz测试稠密即可取得L2响应；无需对真实µ作平坦替换，也无需边界trace值。

### 3. 端点与回代限制

R,d均正，无d/R小量假设。µ0全零；网格平移不改论证。R≥a、d=a/√n给因子≤(1+32/n)^n≤e32，确为dimension-free fixed-scale工具。它不允许将R改为x-dependent选择器、把sup移过L2或用球面/面导数R来免费升级；该升级仍须单独预算。原soft、双Π、共同来源和网格coupling均未由本式自动支付。

本机实际独立执行6个有理η上的18项谱特征多项式/η算术恒等式及7/45>1/8系数核验，全PASS。这只是独立代数诊断，连续证明如上；非数值证明或FULL实例。等待作者精确稿、主整合和数值版本。

## 新增原尺度桥独立筛查

已读task_contract，仍未读作者证明。ratio exp(1/n)从a向上且末点截b的网格，对任一R都有R≤R'≤exp(1/n)R，正来源给h_R*µ≤e h_R'*µ。节点数N≤nlog2+2≤3n（退化a=b亦覆盖）。因此global maximal L2²≤e²Σ_nodes||h_R'*µ||²≤3e²n exp(32nd²/a²)Σm_C²/d^n；这个n没有遗漏，也没有从固定R结果直接免费取sup。

取d=a/(8√n)，32nd²/a²=1/2。按同一粗网格原限制µlow=Σ_{m_C≤λd^n/√n}µ|C，有Σm_C²/d^n≤λWlow/√n。故

`||M_[a,b]µlow||²≤3e^(5/2)λ√n Wlow`。

逐点F≤ελ+F²/(4ελ)对全部F≥0成立，积分实际E得εX+3e^(5/2)√nWlow/(4ε)，不用额外receiver cap或FIRST。µhigh原样保留，不能把这个低粗胞来源支当一般闭合。每胞选择在actual x和尺度前由原来源质量冻结，不改变原Π。

新粗质量门与旧d=a/n、密度λ√n的门不是相互包含的一般class；单胞阈值比为(√n/8)^n/n，n256确为2^248（本机Fraction实际核验）。这只说明可构造新被低粗胞条件覆盖的L1来源，不能据此认证原FULL history或说每个原source获付更少；旧细胞价格仍可保留。新增尺度桥在固定尺度定理成立后PASS。

## 作者稿与主整合后审

**capture_geometry CG1–7及主proof S1–S4 PASS。** 全subset胞采样不等式、归一不定矩阵的完整谱、tensor opnorm、Fourier 32、L2对偶及原来源质量单位均与独筛吻合。作者CG4采用|u|≤1及外部sinc包络的另一路径，数值常数19/120、6/7、104/49方向正确。Schwartz逼近/卷积均匀收敛与Fatou不需要胞内密度帽。CG5上取整完整支付e²和N≤3n，实际原选择器同时被支配，粗low门与high原限制分解准确。CG7对实际h_R*µhigh施4λ帽，不对Σ_i Mµ_i误施；高残余有限胞及完整邻接熵保留。CG8仅给未证dyadic block条件，没有由固定尺度直接免费获得对数max；辅助技能名不构成假设。

**level_geometry LG1–7 PASS（辅助可算证书）。** 每个原来源的weak ai/t在同一t先合并eligible receivercells再付一次；distinct正阈值atoms逐项付，ell0从0积分且|E|控制近0。每cellΣell≤κu是实际低响应资源，粗cell不能免费借support-membership refinement的可行性。严格height端点、countable Tonelli、同ε完整层积分和有限可测菜单取min均正确。例µ≤f的真正2<G0≤4带可由常背景逐点验证，不授FULL history。

已核并接受重要比较限定：该例U_il恰为fi常值，simple Qcell在u1为1/500，优于新sharedtail3/250；同ε1/4完整direct价153/1000也优于sharedtail约.200374。新sharedtail仅严格改善whole-E静态阈值族（约.257544），不是胜过所有receiver几何法或最优证书。最终稿已明确此限制。

本独审实际从capture_geometry提取内嵌4个Fraction tensor检查运行PASS，亦从level_geometry提取内嵌脚本运行`PASS 27 exact geometry/resource/price checks`，得到Cold=.257544117269890852923631、Cnew=.2003735370266396750647312及decrease=.05717058024325117785889985。这是有限辅助方法核算/普通mp50，不是一般预算证明。原始18项谱算术和n256精确阈值比为独立screen诊断，不重复当正式数值模型。

当前numeric_checks.py/gram_spectrum.m已静审：实际盒卷积profile乘积积分为Fraction Gram；同胞diagonal公式仅在本菜单side≤R范围使用。有限row-sum仅认证该有限盒basis Gram，不认证任意胞内operator；MATLAB eig是普通double。adaptive部分wholecell lower采用有限R，upper采用质量单调全R包络，保真实receiver体积。正式9个fixedscale模型不自动符合新增low粗胞门，3个max诊断也不构造原FULL；高维仅阈值标量。待最终notes/report/driver和SHA绑定。

## 最终结论、证据归属及复现

**PASS，可按明确范围冻结；无待修数学阻断。** 新成果是任意胞内来源的二阶固定尺度L2工具、明确支付3e²n的连续尺度桥，以及原来源精确分解后low粗胞支的根阶正硬响应费用。该支不需要额外FIRST或接收帽；原母账回代仍须同一个已授权正硬响应槽。high粗胞邻接熵、集中soft、跨父节点/尺度来源总和与原双后验桥仍未闭合。

最终report与JSON数字已直接核对：9 fixedscale模型、83源胞/diagonal核、1251 Fraction Gram条目、9指定mass和9舍入Perron Rayleigh、9有限rowsum operator证书；3max诊断用7196整receivercells，前两例lower/fixed严格>1，第三不足1不能判断。高维3项只是质量门标量；9个固定尺度例不冒充9个新coarse-low实例。row-sum证书只对冻结的有限盒profile basis有效；通用任意L1结论依解析证明，不依MATLAB eigenvalue或有限Rayleigh。实际MATLAB为作者运行的普通double谱诊断，不是区间。

辅助例的所有费用/实际输入硬带、same-epsilon层积分、强direct-cell基线已在最终notes与report明确保留。shared-tail方法没有被说成实际最优。log40/70或mp50是普通多精度值，非向外舍入证书；精确几何/阈值与普通谱值分开。

本独审实际执行：①独筛18项Fraction谱/eta算术及n256阈值比（临时诊断，无独立归档脚本，不并入正式数值模型数）；②从最终作者稿提取的4个Fraction tensor与27项geometry/resource/price代码，全PASS；③最终Python/MATLAB/合同三项JSON自绑定校验PASS；④直接读取JSON核全部报告计数及adaptive ratios。未启动MATLAB或重跑正式9+3套件，不冒称作者或主代理检查为本人执行。主代理accounting15+7及最终含MATLAB的包外重放由主代理记录receipt；本审计不等待receipt后再改manifest。

reproduce.py静审PASS：先验flat manifest，再实际重算accounting与numeric两完整JSON，后者调用同包MATLAB helper，并逐字节比较；最后再验manifest。需在包外副本用所列同环境执行，版本不同的浮点字段差异应区分于精确有理字段失败，report已注明。该driver没有免费假定PSD/一般source资格，也未声称复算尚未执行的QP。

## 冻结受审SHA256

不绑定audit自身；以下数学/数值文件之后如变更须重新核对。

|文件|SHA256|
|---|---|
|task_contract.md|`f8ec576aef21eeb2ad6ecb9be6981f80a46f2d63804a4e4ded48bb260fe85187`|
|proof.tex.txt|`329531062e9f6b5f3351cebd45eef2cfbda26475056cbd26826b3846e4fba178`|
|capture_geometry.md|`07b08d3180bd67ff3a35dcbf0c39be85e89baac0029c3872088145565f1b388f`|
|level_geometry.md|`aaf8dccd3ebadbdc1b7c34b075f0fa418556518da8f34f1c7832532f65d56e14`|
|report.md|`09d9c04a4f8dcae9e51f8ca3fb142a3039871431aa1d70bf1fe0e3be2c18e8b5`|
|reproduce.py|`2e9f0e4e22f50177c257f0ab52704c438df86d5554b49b757dea68c24fd3273b`|
|numeric_checks.py|`54985253d3faff0b98e2efb96a8d496fd2509ea57031a536b30be68e6146a9d6`|
|gram_spectrum.m|`5a4a3760045d9f43f89dc2d49cbd9d4c4643a986b0a897346a69973ad28ac33f`|
|numeric_checks.json|`f46aa7951f659fe99852ca811f52577135200c6ca9b58ec4303636227e1ae435`|
|numeric_notes.md|`b27afe5d5969795be366c9ff034919bf73e54c2fd297c95a7f5925ff3924abf1`|
|accounting_checks.py|`9e2289df8387e35f77ef26c24c12d611bc27aaf07f605780bdcb60f2923dfbe2`|
|accounting_checks.json|`696947873a77610bdfa9b94a90b9d16208332e32a77d69f42e1c23b013a93072`|

R252审核完成，audit.md至此冻结并停止写入。
