#!/usr/bin/env python3
"""R252 exact fixed-scale L1 Gram, MATLAB spectral diagnostics and cell bounds."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import prod,isqrt,ceil,floor
import argparse,hashlib,json,tempfile,subprocess
import mpmath as mp

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dec(q):
    with mp.workdps(70):return mp.nstr(mp.mpf(q.numerator)/q.denominator,40)
def fm(q):return mp.mpf(q.numerator)/q.denominator
def length(z,l,x,R):return max(F(),min(z+l/2,x+R/2)-max(z-l/2,x-R/2))
def profile(z,l,x,R):return length(z,l,x,R)/(l*R)
def inner(z,l,w,s,R):
    knots=sorted({p+sign*(R+t)/2 for p,t in [(z,l),(w,s)] for sign in [-1,1]}|{p+sign*abs(R-t)/2 for p,t in [(z,l),(w,s)] for sign in [-1,1]})
    val=F()
    for a,b in zip(knots,knots[1:]):
        x0,x1=profile(z,l,a,R),profile(z,l,b,R);y0,y1=profile(w,s,a,R),profile(w,s,b,R)
        val+=(b-a)*(2*x0*y0+x0*y1+x1*y0+2*x1*y1)/6
    return val

def specs():
    return [('initial','centers_n1',1,3,F(1,2),F(1),'center'),('initial','centers_n2',2,2,F(1,2),F(1),'center'),('initial','centers_n3',3,2,F(1,3),F(1),'center'),('pressure','paired_n1',1,4,F(1,4),F(1),'pair'),('pressure','vertex_n2',2,2,F(1),F(1),'vertex'),('pressure','vertex_n3',3,2,F(1),F(1),'vertex'),('expanded','fine_grid_n1',1,16,F(1,16),F(1),'pair'),('expanded','jitter_grid_n2',2,3,F(1,2),F(3,2),'heterogeneous'),('expanded','jitter_grid_n3',3,3,F(1,2),F(1),'heterogeneous')]

def build(spec):
    phase,name,n,size,d,R,kind=spec;boxes=[];coords=list(product(range(size),repeat=n));raw=[]
    for idx in coords:
        l=d/2 if kind=='center' else (d/32 if kind=='vertex' else (d/16 if kind=='pair' else d/(8 if sum(idx)%2 else 16)))
        z=[]
        for j,i in enumerate(idx):
            c=(F(i)+F(1,2))*d
            if kind!='center':c+=(1 if i%2==0 else -1)*(d-l)/2
            z.append(c)
            assert i*d<=c-l/2 and c+l/2<=(i+1)*d
        boxes.append({'cell_index':idx,'center':tuple(z),'side':l});raw.append(1 if kind!='heterogeneous' else 1+sum((j+1)*v for j,v in enumerate(idx))%5)
    masses=[F(v,sum(raw)) for v in raw];N=len(boxes);G=[[F() for _ in boxes] for _ in boxes];cache={};axis_count=0
    for i,p in enumerate(boxes):
        for j,q in enumerate(boxes[i:],i):
            factors=[]
            for z,w in zip(p['center'],q['center']):
                key=(z,p['side'],w,q['side'],R)
                if key not in cache:cache[key]=inner(*key);axis_count+=1
                factors.append(cache[key])
            G[i][j]=G[j][i]=prod(factors)
        expected=(1/R-boxes[i]['side']/(3*R**2))**n
        assert G[i][i]==expected
    bound=(1+32*d*d/R**2)**n;rowmax=max(sum(row,F())*d**n for row in G)
    energy=sum((masses[i]*G[i][j]*masses[j] for i in range(N) for j in range(N)),F());baseline=sum((m*m for m in masses),F())/d**n;rayleigh=energy/baseline
    assert rayleigh<=bound
    return {'phase':phase,'name':name,'n':n,'d':d,'R':R,'boxes':boxes,'masses':masses,'G':G,'bound':bound,'rowmax':rowmax,'energy':energy,'baseline':baseline,'rayleigh':rayleigh,'axis_count':axis_count}

def serialize(g,raw):
    pf=[F(round(float(x)*10**12),10**12) for x in raw['Perron_mass']];pf=[abs(x) for x in pf];pf=[x/sum(pf,F()) for x in pf]
    E=sum((pf[i]*g['G'][i][j]*pf[j] for i in range(len(pf)) for j in range(len(pf))),F());base=sum((x*x for x in pf),F())/g['d']**g['n'];rr=E/base;assert rr<=g['bound']
    return {'phase':g['phase'],'name':g['name'],'n':g['n'],'d_exact':str(g['d']),'R_exact':str(g['R']),'sources':[{'cell_index':p['cell_index'],'center':[str(z) for z in p['center']],'side':str(p['side']),'mass':str(m)} for p,m in zip(g['boxes'],g['masses'])],'Gram_exact':[[str(x) for x in row] for row in g['G']],'prescribed_mass_energy_exact':str(g['energy']),'mass_grid_L2_baseline_exact':str(g['baseline']),'prescribed_Rayleigh_exact':str(g['rayleigh']),'candidate_bound_exact':str(g['bound']),'candidate_bound_decimal':dec(g['bound']),'scaled_max_row_sum_exact':str(g['rowmax']),'finite_row_sum_certificate':g['rowmax']<=g['bound'],'row_sum_scope':'Only this finite nonnegative symmetric Gram: 2|xi*xj|<=xi^2+xj^2 gives operator bound if rowmax<=candidate. Not a universal C certificate.','MATLAB':{'lambda_max_significant12':format(raw['lambda_max'],'.12g'),'lambda_min_significant8':format(raw['lambda_min'],'.8g'),'scope':'ordinary double eigenvalue, not interval/operator certificate'},'rounded_Perron_mass_exact':[str(x) for x in pf],'rounded_Perron_Rayleigh_exact':str(rr),'rounded_Perron_Rayleigh_decimal':dec(rr),'counts':{'source_cells':len(pf),'one_dimensional_inner_integrals':g['axis_count'],'Gram_entries':len(pf)**2}}

def adaptive(g):
    n=g['n'];boxes=g['boxes'];masses=g['masses'];Rs=[F(1),F(5,4),F(3,2),F(7,4),F(2)];h={1:F(1,64),2:F(1,16),3:F(1,8)}[n]
    grids=[]
    for j in range(n):
        lo=min(p['center'][j]-p['side']/2 for p in boxes)-1;hi=max(p['center'][j]+p['side']/2 for p in boxes)+1
        left=floor(lo/h)*h;right=ceil(hi/h)*h
        grids.append([left+(F(i)+F(1,2))*h for i in range(int((right-left)/h))])
    cache={}
    for j in range(n):
        for z,l in {(p['center'][j],p['side']) for p in boxes}:
            for i,x in enumerate(grids[j]):
                for k,R in enumerate(Rs):
                    ends=[length(z,l,x-h/2,R),length(z,l,x+h/2,R)];cache[(j,z,l,i,k)]=(min(ends),max(*ends,length(z,l,min(x+h/2,max(x-h/2,z)),R)))
    lower=upper=F();count=0
    for idx in product(*(range(len(xs)) for xs in grids)):
        lows=[];ups=[]
        for k,R in enumerate(Rs):
            lm=um=F()
            for p,m in zip(boxes,masses):
                vals=[cache[(j,z,p['side'],i,k)] for j,(z,i) in enumerate(zip(p['center'],idx))];density=m/p['side']**n
                lm+=density*prod(x[0] for x in vals);um+=density*prod(x[1] for x in vals)
            lows.append(lm/R**n);ups.append(um)
        L=max(lows);U=max(ups[k+1]/Rs[k]**n for k in range(4));assert L<=U
        lower+=L*L*h**n;upper+=U*U*h**n;count+=1
    return {'source_model':g['name'],'n':n,'same_source_mass':'1','receiver_cell_side':str(h),'receiver_cells':count,'R_grid':[str(R) for R in Rs],'pointwise_max_L2_squared_lower_exact':str(lower),'pointwise_sup_L2_squared_upper_exact':str(upper),'fixed_R_L2_squared_exact':str(g['energy']),'lower_over_fixed_exact':str(lower/g['energy']),'upper_over_fixed_exact':str(upper/g['energy']),'lower_over_fixed_decimal':dec(lower/g['energy']),'upper_over_fixed_decimal':dec(upper/g['energy']),'scope':'Whole receiver cells cover all positive responses. Finite-R max lower; full [1,2] upper from monotone mass. No grid=sup identification.'}

def threshold_example():
    masses=[F(3,4)]*2;vol=[F(1,10),F(1,10),F(1,500)];U=[[F(3,4),F(),F(3,4)],[F(),F(3,4),F(3,4)]];ai=[F(33,40)]*2;u=F(1)
    def fee(kappa,ell):
        assert 0<=kappa<1 and all(sum((ell[i][l] for i in range(2)),F())<=kappa*u for l in range(3))
        assert all(0<=ell[i][l]<=min(u,U[i][l]) for i in range(2) for l in range(3))
        total=F();atomic=integral=F()
        for i in range(2):
            for beta in sorted(set(x for x in ell[i] if x>0)):
                v=sum((vol[l] for l in range(3) if ell[i][l]==beta and beta<U[i][l]),F());atomic+=beta*min(ai[i]/beta,v)
            knots=sorted({F(),u}|set(ell[i])|set(U[i]))
            for a,b in zip(knots,knots[1:]):
                if b>u:continue
                mid=(a+b)/2;v=sum((vol[l] for l in range(3) if ell[i][l]<=mid<U[i][l]),F())
                # For this exact example the shared ai/t budget is never binding.
                assert v==0 or ai[i]/b>=v
                integral+=(b-a)*v
        total=(atomic+integral)/(1-kappa)
        return total,atomic,integral
    old,oa,oi=fee(F(1,2),[[F(1,4),F(),F(1,4)],[F(),F(1,4),F(1,4)]])
    new,na,ni=fee(F(3,4),[[F(3,4),F(),F(3,8)],[F(),F(3,4),F(3,8)]])
    best,_,_=fee(F(),[[F(),F(),F()],[F(),F(),F()]])
    assert old==F(153,500) and new==F(3,250) and best==F(153,1000)
    # Direct original interval captures for all R: own source fully contained,
    # opposite outer cell disjoint even at b; both fully contained in middle.
    intervals=[(F(-1,4),F(-3,20)),(F(3,20),F(1,4))];receivers=[(F(-3,5),F(-1,2)),(F(1,2),F(3,5)),(F(-1,1000),F(1,1000))]
    for i,(a,b) in enumerate(intervals):
        for l,(left,right) in enumerate(receivers):
            z=(a+b)/2
            if U[i][l]:
                assert left+F(1,2)>=b and right-F(1,2)<=a
                assert left>=z-F(11,20) and right<=z+F(11,20)
            else:
                assert right+F(101,200)<=a or left-F(101,200)>=b
                assert right<=z-F(111,200) or left>=z+F(111,200)
    assert all(left-F(101,200)>=-2 and right+F(101,200)<=2 for left,right in receivers)
    assert all(ai[i]/F(3,4)>sum((vol[l] for l in range(3) if U[i][l]),F()) for i in range(2))
    actual_integral=sum((vol[l]*sum((U[i][l] for i in range(2)),F()) for l in range(3)),F());assert actual_integral==F(153,1000)
    truelevel=sum((vol[l] for l in range(3) if sum((U[i][l] for i in range(2)),F())>u),F());assert truelevel==F(1,500)
    logs={}
    for prec in [40,70]:
        with mp.workdps(prec):
            cold=fm(F(153,1000))*(1+mp.log(fm(F(101,51))));gain=fm(F(141,1000))*mp.log(fm(F(3,2)));cnew=cold-gain
            assert fm(actual_integral)<cnew<cold
            logs[f'mp{prec}']={'full_level_old':mp.nstr(cold,50),'full_level_new':mp.nstr(cnew,50),'decrease':mp.nstr(gain,50)}
    return {'n':1,'a':'1','b':'101/100','lambda':'1','u':'1','source_intervals':[[str(x) for x in pair] for pair in intervals],'source_density':'15/2','source_masses':[str(x) for x in masses],'receiver_intervals':[[str(x) for x in pair] for pair in receivers],'receiver_volumes':[str(x) for x in vol],'individual_max_caps_exact':[[str(x) for x in row] for row in U],'shared_weak_constants_exact':[str(x) for x in ai],'old_static_kappa_half_price':str(old),'old_price_atomic':str(oa),'old_price_integral':str(oi),'cell_adaptive_kappa_three_quarters_price':str(new),'new_price_atomic':str(na),'new_price_integral':str(ni),'any_global_static_infimum':str(best),'best_static_kappa_zero_price':str(best),'big_term_at_u1':'0','adaptive_thresholds_exact':[['3/4','0','3/8'],['0','3/4','3/8']],'adaptive_resource_slacks_exact':['0','0','0'],'pooled_weak_tail_scope':'single ai/t across all active cells, not one ai/t per cell; inactive and cap-equality tails zero','direct_cell_tail_price_u1':str(u*truelevel),'actual_receiver_integral_exact':str(actual_integral),'same_epsilon_full_level_comparison':logs,'epsilon':'1/4','stronger_cell_baseline_scope':'U_il equals actual constant fi here; direct Qcell and its full integral improve the shared-tail family, so shared-tail is not actual optimal' ,'actual_u_level_volume':str(F(1,500)),'actual_E_volume':str(sum(vol)),'price_ratio_new_over_best_static':str(new/F(153,1000)),'full_input_band_extension':'f=mu1+mu2+(3/2)1[-2,2], on E M f=9/4 or3; original kernel-only qualification, not FULL/history','scope':'Exact finite shared weak-tail formula: ai/t pooled across all receiver cells; thresholds equal caps erase those tails, not original sources.'}

def coarse_thresholds():
    rows=[]
    for n in [256,1024,4096]:
        sq=isqrt(n);assert sq*sq==n;base=F(sq,8);j=(sq//8).bit_length()-1;assert F(2)**j==base
        power=n*j-(n.bit_length()-1);assert 2**(n.bit_length()-1)==n
        rows.append({'n':n,'sqrt_n':sq,'new_d_a1':str(F(1,8*sq)),'old_fine_d_a1':str(F(1,n)),'threshold_ratio_formula':'(sqrt(n)/8)^n/n','threshold_ratio_exact_power_of_two':power,'scope':'Only exact threshold comparison; no high-dimensional L1 source/receiver or FULL input generated.'})
    return rows

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));ap.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md'));ap.add_argument('--matlab',default='/Applications/MATLAB_R2026a.app/bin/matlab');args=ap.parse_args();models=[build(s) for s in specs()];helper=Path(__file__).with_name('gram_spectrum.m')
    data={'cases':[{'name':g['name'],'scaled_Gram':[[float(x*g['d']**g['n']) for x in row] for row in g['G']]} for g in models]}
    with tempfile.TemporaryDirectory(prefix='r252_gram_') as temp:
        ip,op=Path(temp)/'input.json',Path(temp)/'output.json';ip.write_text(json.dumps(data));quote=lambda p:str(p).replace("'","''")
        subprocess.run([args.matlab,'-batch',f"addpath('{quote(helper.parent)}'); gram_spectrum('{quote(ip)}','{quote(op)}');"],check=True);raw=json.loads(op.read_text())
    rows=[serialize(g,r) for g,r in zip(models,raw['results'])];ad=[adaptive(g) for g in models if g['name'] in ['centers_n1','vertex_n2','vertex_n3']]
    out={'source_sha256':sha(__file__),'matlab_source_sha256':sha(helper),'contract_sha256':sha(args.contract),'scope':'Finite positive-Lebesgue regular-cell sources with irregular interior boxes. Exact Gram/Rayleigh and finite row-sum checks, ordinary MATLAB eig diagnostics; no universal C proof, FULL or dimension-order inference.','dependencies':{'python':'3.12.14','mpmath':mp.__version__,'MATLAB':raw['MATLAB_version'],'release':raw['release']},'fixed_scale_cases':rows,'adaptive_cases':ad,'receiver_threshold_example':threshold_example(),'coarse_threshold_comparisons':coarse_thresholds(),'counts':{'fixed_scale_models':9,'initial':3,'pressure':3,'expanded':3,'Gram_entries':sum(r['counts']['Gram_entries'] for r in rows),'source_cells':sum(r['counts']['source_cells'] for r in rows),'adaptive_max_models':3,'adaptive_receiver_cells':sum(a['receiver_cells'] for a in ad),'cell_threshold_examples':1,'high_dimensional_threshold_comparisons':3,'exact_prescribed_mass_Rayleigh_checks':9,'exact_rounded_Perron_Rayleigh_checks':9,'finite_row_sum_operator_certificates':sum(r['finite_row_sum_certificate'] for r in rows),'diagonal_normalization_checks':sum(r['counts']['source_cells'] for r in rows)}}
    args.output.write_text(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    for r in rows:print(r['name'],r['MATLAB']['lambda_max_significant12'],r['rounded_Perron_Rayleigh_decimal'],r['finite_row_sum_certificate'],flush=True)
    for a in ad:print('adaptive',a['source_model'],a['lower_over_fixed_decimal'],a['upper_over_fixed_decimal'],flush=True)
    print(out['counts'])
if __name__=='__main__':main()
