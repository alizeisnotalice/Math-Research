from pathlib import Path
import argparse,hashlib,json,subprocess,sys
ap=argparse.ArgumentParser();ap.add_argument('--matlab',default='/Applications/MATLAB_R2026a.app/bin/matlab');args=ap.parse_args()
w=Path(__file__).resolve().parent
manifest=json.loads((w/'manifest.json').read_text())
def verify():
 for name,digest in manifest.items():assert hashlib.sha256((w/name).read_bytes()).hexdigest()==digest,name
verify()
for script,output in [('accounting_checks.py','accounting_checks.json'),('numeric_checks.py','numeric_checks.json')]:
 before=(w/output).read_bytes();cmd=[sys.executable,str(w/script)]
 if script=='numeric_checks.py':cmd+=['--matlab',args.matlab]
 subprocess.run(cmd,check=True,cwd=w)
 assert before==(w/output).read_bytes(),output+' differs; inspect exact vs floating fields and runtime version'
verify()
print(json.dumps({'manifest_files':len(manifest),'exact_replay_outputs':2,'status':'PASS'},sort_keys=True))
