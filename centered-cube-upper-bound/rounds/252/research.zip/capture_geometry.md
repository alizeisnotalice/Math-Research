# R252：共同硬尺度的二阶采样与原来源粗胞付款

## CG1　准确结论及付款范围

令 (n\ge1\)，(0<a\le b\le2a\)，(Q_R(x)) 为完整边长 (R) 的中心立方体，(h_R=R^{-n}1_{Q_R(0)})。令非负有限 (L^1) 来源 (\mu\le f\)，不改变其在胞内的分布。固定半开轴平行网格，胞边长为 (d>0)，记
\[
 m_C=\mu(C),\qquad \mathcal E_d(\mu)=\sum_Cm_C^2/d^n.
\]
本轮证明：
\[
 \boxed{\|h_R*\mu\|_2^2\le
 (1+32d^2/R^2)^n\mathcal E_d(\mu).}\tag{CG1.1}
\]
更准确的常数是 ((1+\eta_R)^n)，其中
\(\eta_R(1+\eta_R)=32d^2/R^2\)。此处允许胞内任意 (L^1) 浓缩。

通过合法的有限尺度网格，得到全连续 octave：
\[
 \boxed{\|M_{[a,b]}\mu\|_2^2
 \le3e^2n\exp(32nd^2/a^2)\mathcal E_d(\mu).}\tag{CG1.2}
\]
这里没有声称尺度最大值只有对数费用；显式保留 (n)。

取
\[
 d=\frac a{8\sqrt n},\quad
 \mathcal L=\{C:m_C\le\lambda d^n/\sqrt n\},\quad
 \mu_\ell=1_{\cup\mathcal L}\mu,\quad W_\ell=\|\mu_\ell\|_1.
\]
则对任何有限可测原接收域 (E)、任何原可测选择器 (R(x)\in[a,b])，以及 (\varepsilon>0)，
\[
 \boxed{\int_Eh_{R(x)}*\mu_\ell(x)\,dx
 \le\varepsilon X+
 \frac{3e^{5/2}}{4\varepsilon}\sqrt n\,W_\ell,
 \qquad X=\lambda|E|.}\tag{CG1.3}
\]
这是一个真实原来源限制的、任意块数的根阶付款分支。证明不需要给 \(\mu_\ell\) 添均匀密度、不修改原后验或原 cut。对于整个 \(\mu\)，余下粗胞来源仍需支付；CG7 给出完整旧熵费用，未宣称全局目标闭合。

## CG2　任意胞内来源的 dual sampling

先取 Schwartz 测试函数 \(\varphi\)，置 \(F=h_R*\varphi\)。对任意非负光滑函数 \(G\) 及边长 \(d\) 的网格胞 \(C\)，多变量微积分基本公式给
\[
 d^n\sup_CG\le\sum_{S\subseteq[n]}d^{|S|}\int_C|\partial_SG|.\tag{CG2.1}
\]
具体地，从任意锚点 \(y\in C\) 到 \(x\in C\) 逐坐标展开：每一项含对 \(S\) 中坐标的一次积分及 \(\partial_SG(t_S,y_{S^c})\)。把积分区间扩为对应全胞边，随后对锚点 \(y\) 平均；未使用对绝对值的再次求导。所得右边与 \(x\) 无关，故可取 supremum。

对 \(G=|F|^2\)，Leibniz 公式及全空间 Cauchy 给
\[
 \sum_Cd^n\sup_C|F|^2
 \le\sum_{A\cap B=\varnothing}
 d^{|A|+|B|}\|\partial_AF\|_2\|\partial_BF\|_2.\tag{CG2.2}
\]
\(\partial_A\) 表示每个 \(i\in A\) 恰求一次导数。网格胞边界在原 \(L^1\) 来源下质量为零；supremum 可取胞闭包。

另一方面，正来源的原质量逐胞满足
\[
 |\langle h_R*\mu,\varphi\rangle|
 \le\sum_Cm_C\sup_C|h_R*\varphi|
 \le\mathcal E_d(\mu)^{1/2}
       \left(\sum_Cd^n\sup_C|h_R*\varphi|^2\right)^{1/2}.\tag{CG2.3}
\]
这一步没有把 \(\mu|_C\) 换成均匀来源。\(\mathcal E_d\) 只是原质量的账目。

## CG3　张量二次型：避免不合法的 indefinite Loewner 张量化

写 \(a_A=\|\partial_AF\|_2\)，并令
\[
 M=\begin{pmatrix}1&d\\d&0\end{pmatrix},\qquad
 D=\operatorname{diag}(1+\eta,d^2/\eta),\quad\eta>0.
\]
CG2.2 右边恰为 \(a^TM^{\otimes n}a\)。矩阵
\[
 D^{-1/2}MD^{-1/2}=
 \begin{pmatrix}
 (1+\eta)^{-1}&\sqrt{\eta/(1+\eta)}\\
 \sqrt{\eta/(1+\eta)}&0
 \end{pmatrix}
\]
的两个特征值为 \(1\) 与 \(-\eta/(1+\eta)\)。所以其任意张量幂的算子范数为 \(1\)，进而
\[
 a^TM^{\otimes n}a\le a^TD^{\otimes n}a
 =\sum_A(1+\eta)^{n-|A|}(d^2/\eta)^{|A|}
             \|\partial_AF\|_2^2.\tag{CG3.1}
\]
这里依靠归一化后的完整谱；没有把含负特征值矩阵的 Loewner 不等式直接逐项张量化。

## CG4　绝对常数 32 与固定尺度证明

采用 Fourier 因子 \(e^{-ix\cdot\xi}\)，令 \(s(u)=\sin u/u\)，\(s(0)=1\)。有全实轴初等不等式
\[
 \sin^2u\le8(1-s(u)^2).\tag{CG4.1}
\]
证明：当 \(|u|\le1\)，交错级数给
\(0\le s(u)\le1-19u^2/120\)，故
\(1-s(u)^2\ge19u^2/120\)，而 \(\sin^2u\le u^2\)。当 \(|u|\ge1\)，\(s\) 在 \([1,\pi]\) 递减，且其绝对值在 \([\pi,\infty)\) 不超过 \(1/\pi\)；因此 \(|s(u)|\le\sin1<6/7\)。于是 \(8(1-s(u)^2)\ge104/49>1\)，也足够。

由此
\[
 \xi^2s(R\xi/2)^2\le\frac{32}{R^2}
             [1-s(R\xi/2)^2].\tag{CG4.2}
\]
Plancherel 把 CG3.1 右边化为（采用同一 Parseval 归一化）
\[
 \int|\widehat\varphi(\xi)|^2\prod_{i=1}^n
 \left[(1+\eta)s(R\xi_i/2)^2+
       \frac{d^2}{\eta}\xi_i^2s(R\xi_i/2)^2\right]d\xi.
\]
选择 \(\eta(1+\eta)=32d^2/R^2\)，每个方括号均不超过 \(1+\eta\)。因此
\[
 \sum_Cd^n\sup_C|h_R*\varphi|^2
 \le(1+\eta)^n\|\varphi\|_2^2
 \le(1+32d^2/R^2)^n\|\varphi\|_2^2.
\]
结合 CG2.3 及 \(L^2\) 对偶得到 CG1.1。一般 \(L^2\) 测试可由 Schwartz 逼近；\(h_R\in L^2\) 使其卷积在测试函数的 \(L^2\) 逼近下均匀收敛，胞 sup 和用 Fatou。对有限 \(\mu\)，\(\sum_Cm_C^2\le\|\mu\|_1^2\)，所以右边有限。零来源情形平凡。

## CG5　合法的全尺度桥及原积分付款

取尺度节点
\[
 R_k=\min\{b,a e^{k/n}\},\quad
 0\le k\le K=\lceil n\log(b/a)\rceil,
\]
删去重复末节点。节点总数不超过 \(n\log2+2\le3n\)；\(b=a\) 时仅一个节点。任意 \(R\in[a,b]\) 向上取最近节点 \(R_k\)，由原来源非负性，
\[
 h_R*\mu\le(R_k/R)^n h_{R_k}*\mu\le e\,h_{R_k}*\mu.
\]
因此
\[
 \|M_{[a,b]}\mu\|_2^2\le e^2\sum_k\|h_{R_k}*\mu\|_2^2
 \le3e^2n e^{32nd^2/a^2}\mathcal E_d(\mu).
\]
这是正向离散化，物理膨胀费仅 \(e\)，并非 \(e^{\sqrt n}\)。所有连续选择器 \(R(x)\) 同时被覆盖；没有用固定尺度结论直接代入依赖 \(x\) 的尺度。

对 CG1 中定义的低粗胞来源，
\[
 \mathcal E_d(\mu_\ell)\le\frac\lambda{\sqrt n}W_\ell,
 \qquad32nd^2/a^2=\frac12,
\]
所以
\(\|M\mu_\ell\|_2^2\le3e^{5/2}\lambda\sqrt n W_\ell\)。
使用对 \(t\ge0\) 成立的
\(t\le\varepsilon\lambda+t^2/(4\varepsilon\lambda)\)，在真实 \(E\) 上积分即得 CG1.3。此付款不需要接收硬帽；它可与原硬帽同时保留。任何原正门 \(0\le\chi\le1\) 也可保留在左边。

## CG6　与旧微胞分支的准确比较

旧正膨胀平滑使用边长 \(a/n\) 及质量阈值
\(\lambda\sqrt n(a/n)^n\)。本轮边长 \(a/(8\sqrt n)\) 的阈值是
\(\lambda(a/(8\sqrt n))^n/\sqrt n\)，两阈值之比为
\[
 \frac1n\left(\frac{\sqrt n}{8}\right)^n.\tag{CG6.1}
\]
当 \(n\ge256\) 时至少 \(2^n/n\)。因此新工具允许某个粗胞的全部质量集中在极小子集而仍按该较大的粗胞质量阈值付款。它没有依赖胞内密度帽，且来源只收费一次。

此比较不是逐输入支配：平坦来源可能通过旧微胞分支却不能通过新阈值。可以保留两个合法分支，按原来源限制无重复地分配。这里不声称已证明某个特定 FULL 中间行在新旧分支差集中非空，更不把阈值比较当作整个余来源已付。

## CG7　完整余来源费用：不能免费弱型相加

设 \(\mu_h=\mu-\mu_\ell\)。其非零粗胞质量均大于固定正阈值，故只有有限多个；写 \(\mu_h=\sum_{i\in\mathcal H}\mu_i\)，\(m_i=\|\mu_i\|_1\)，胞中心 \(z_i\)。R251 单簇定理给
\[
 u|\{M\mu_i>u\}|\le c_dm_i,
 \qquad c_d=2+n\log(1+d/a)\le2+\sqrt n/8.
\]
对 \(f_i=1_E M\mu_i\)，其支持在 \(S_i=E\cap Q_{b+d}(z_i)\)。使用包含全部支持相交对及自身的确定邻接图，令
\(M_i=\sum_{j\sim i}m_j\)。R249 已证局部弱和给
\[
 u|\{\textstyle\sum_i f_i>u\}|\le
 c_d\sum_i m_i[3+2\log2+2\log(M_i/m_i)] =:\mathcal B_h.
\]
若原 \(E\) 保持 \(M_{[a,b]}f\le4\lambda\)，则实际共同尺度响应
\(g_h(x)=h_{R(x)}*\mu_h(x)\) 在 \(E\) 上不超过 \(4\lambda\)，并且 \(g_h\le\sum_i f_i\)。因此
\[
 \int_Eg_h\le\varepsilon_hX+4\mathcal B_h/\varepsilon_h.
\]
**只给实际 \(g_h\) 使用硬帽；没有给 \(\sum_i M\mu_i\) 使用该帽。** 合并后，对于 \(\varepsilon_\ell,\varepsilon_h>0\)，
\[
 \boxed{\int_Eh_{R(x)}*\mu\le
 (\varepsilon_\ell+\varepsilon_h)X+
 \frac{3e^{5/2}}{4\varepsilon_\ell}\sqrt nW_\ell+
 \frac{4c_d}{\varepsilon_h}\sum_i m_i
 [3+2\log2+2\log(M_i/m_i)].}\tag{CG7.1}
\]
尾部邻接熵仍为真实费用。共同尺度和原硬帽尚未在此证明中消掉它；故未得到任意来源的全局根阶结论。若原任务是更复杂的正交通而非这里指定的硬响应，CG7.1 不能自动替换其所有后验或其它来源槽。

## CG8　对数最大值提升的准确条件与当前停止点

本轮读取并核对了 F06 技能的有限 Rademacher–Menshov 机制：它需要正交性或可替代的 dyadic block 能量界，而固定尺度界本身不授此条件。这里给出所需的明确不等式，不将其视为已证。

令 \(f_0=h_a*\mu\)，\(f_k=(h_{R_k}-h_{R_{k-1}})*\mu\)，并将长度补零为 \(2^m\)。如果能够对每个 dyadic 层 \(\mathcal D_\ell\) 证明
\[
 \sum_{I\in\mathcal D_\ell}
 \left\|\sum_{k\in I}f_k\right\|_2^2
 \le A\mathcal E_d(\mu),\qquad0\le\ell\le m,\tag{CG8.1}
\]
则每个 prefix 分解为至多 \(m+1\) 个互不交的 dyadic block，逐点 Cauchy 后积分给
\[
 \|M_{[a,b]}\mu\|_2^2
 \le e^2(m+1)^2 A\mathcal E_d(\mu).\tag{CG8.2}
\]
强一些的充分条件是任意增量符号和具有同一 \(L^2\) 来源能量界；随机给每个 block 一个符号可推出 CG8.1。原增量不已知正交，不能套用正交定理。

CG3 的方法对一般卷积 multiplier \(m_\star(\xi)\) 只给一个可检验但较强的充分条件：
\[
 \sup_\xi |m_\star(\xi)|^2
 \prod_i[(1+\eta)+(d^2/\eta)\xi_i^2]<\infty.
\]
对单个 cube multiplier，CG4 的 sinc 缺口确实支付此条件；对所有带符号的尺度增量，不能从单尺度结论推出同样常数。混合导数权会抵消某坐标的 sinc 高频衰减，使尺度振荡必须另付。直接对 \(R\) 求导还产生面核，原任意胞内 \(L^1\) 来源不授面密度帽。本轮未证明 CG8.1，故实际付款严格使用 CG5 的线性节点数，并由粗胞质量阈值降低来获得 CG1.3；不把未证提升条件作为成果。

## CG9　实际本机检查及依赖

本轮以 Python 标准库实际运行：

- 4 个 Fraction 精确张量二次型检查：\(n=1,2,3,4\)，\(d=1/5\)，\(\eta=2/7\)，按 bitmask 排序 \(a_A=(\operatorname{index}(A)+1)/2^n\)，检验 CG3.1，均通过。
- 7 个尺度节点数检查：\(n\in\{1,2,4,16,64,256,1024\}\)，\(b/a=2\)，节点数依次为 \(2,3,4,13,46,179,711\)，均不超过 \(3n\)。
- 浮点报告 \(3e^{5/2}=36.54748188211042\)；仅便于读常数，证明使用精确表达式。

有限检查不替代上述一般证明。可复现的核心精确循环为：

```python
from fractions import Fraction as Q
for n in range(1, 5):
    d, eta = Q(1, 5), Q(2, 7)
    a = [Q(i + 1, 2**n) for i in range(2**n)]
    lhs = sum(d**(i.bit_count()+j.bit_count())*a[i]*a[j]
              for i in range(2**n) for j in range(2**n) if not i & j)
    rhs = sum((1+eta)**(n-i.bit_count())*(d*d/eta)**i.bit_count()*a[i]**2
              for i in range(2**n))
    assert lhs <= rhs
```

依赖：R251 冻结单簇弱型与 R249 局部支持弱和仅用于 CG7；CG1–5 是本轮独立证明。F06 技能及其 cube-interface 仅用于核对 CG8 的必要假设，没有授予原尺度增量正交性。所有来源限制保持原 \(\mu\le f\)，没有增加 \(\beta/\nu\) 的 cut、rank 或 posterior 资格。
