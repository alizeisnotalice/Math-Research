from fractions import Fraction as F
from pathlib import Path
import json

def run():
 count=0
 for eta in [F(1,128),F(1,16),F(1,4),F(1),F(4)]:
  for d in [F(1,8),F(1,2),F(2)]:
   # D-M determinant zero and D+M determinant positive.
   D0=1+eta;D1=d*d/eta
   assert (D0-1)*D1-d*d==0
   assert (D0+1)*D1-d*d>0
   trace=1/(1+eta);det=-eta/(1+eta)
   for root in [F(1),-eta/(1+eta)]:assert root*root-trace*root+det==0
   delta2=eta*(1+eta)/32
   assert eta<=32*delta2
   count+=1
 rows=[]
 for q in [1,2,4,8,16,32,64]:
  n=q*q;d=F(1,8*q);lam=F(3,2);cap=lam*d**n/q
  masses=[cap*x for x in [F(1,8),F(1,2),F(1),F(3,2),F(4)]]
  low=[m for m in masses if m<=cap];high=[m for m in masses if m>cap]
  assert sum(low)+sum(high)==sum(masses)
  assert sum(m*m for m in low)/d**n<=lam/q*sum(low)
  assert 32*n*d*d==F(1,2)
  rows.append({'n':n,'low_cells':len(low),'high_cells':len(high),'coarse_mass_inequality':'PASS','source_partition':'exact original mass preservation'})
 return {'exact_tensor_spectral_checks':count,'coarse_source_checks':rows,'scope':'Finite rational algebra and source-accounting checks; no universal theorem or FULL numerical certification.'}
if __name__=='__main__':
 p=Path(__file__).with_suffix('.json');p.write_text(json.dumps(run(),sort_keys=True,indent=2)+'\n');print(p.read_text())
