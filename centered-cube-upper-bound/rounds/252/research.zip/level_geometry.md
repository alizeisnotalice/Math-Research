# R252: receiver-cell height resources with shared source-tail capacities

This is a hard-response theorem. It retains each original source and
the true receiver Lebesgue measure. It gives a finite computable price,
and an actual L1 example with strict full-level improvement. It does
not prove that the resulting source price is generally root bounded.
The use of the simultaneous active mass in the old LG1 proof is not
new; the refinement is to keep the receiver-cell resource constraints,
cell height cutoffs, and the same source-tail capacity across cells.

## LG1. Inputs and certified geometric tails

Let mu_i be finite nonnegative L1 sources supported in Q_di(z_i),
with masses m_i>0. Write mu=sum_i mu_i, a<=b<=2a, and

    H_i,R=h_R*mu_i, f_i=1_E sup_{a<=R<=b}H_i,R,
    F=1_E sup_{a<=R<=b}h_R*mu, h_i=m_i/a^n.

The finite-measure original receiver E satisfies F<=4lambda, lambda>0.
Thus f_i<=min(h_i,4lambda), F<=sum_i f_i; no bound
sum_i f_i<=4lambda is used. Take any proved weak constants

    t |{f_i>t}|<=a_i, a_i=c_i m_i.

For example one may take the minimum of the old support-volume price,
the R251 single-package price, and the old octave column price:

    c_i=min((1+d_i/a)^n,
            2+n log(1+d_i/a), 1+n log(b/a)),

where each chosen coefficient must have its stated support qualification.
In particular the R251 statement applies for 0<d_i<=a. The theorem
below only uses the certified weak constants, not a new node FIRST.

Partition E into finitely many disjoint measurable receiver cells E_l.
For each i,l certify a constant U_il such that

    f_i<=U_il on E_l a.e., 0<=U_il<=min(h_i,4lambda).

These are genuine upper bounds, not point evaluations. Inactive cells
have U_il=0. For t>0 put r_i(t)=min(b,(m_i/t)^(1/n)) and

    V_il(t)=1_{t<U_il}
               |E_l intersect Q_{r_i(t)+d_i}(z_i)|.       (LG1)

Then eta_il(t):=|E_l intersect {f_i>t}|<=V_il(t), while

    sum_l eta_il(t)<=a_i/t.                              (LG2)

The height endpoint is strict: at t=U_il the tail is zero, even if
f_i equals its upper height on a positive-volume plateau. LG1 uses
the same original density, since a response >t implies m_i>tR^n
and intersection with the original support cube. For rectangular
receivers all displayed geometric volumes are explicit intersections
of boxes. Other measurable cells are allowed when these volumes are
known or replaced by proved upper bounds.

## LG2. Finite threshold-resource certificate

Fix u>0, 0<=kappa<1, and thresholds ell_il satisfying

    0<=ell_il<=min(u,U_il),
    sum_i ell_il<=kappa u for every receiver cell l.       (LG3)

The thresholds are fixed before integrating their cell in x. They
may depend on the given sources, u, E and its cell geometry. This is
a finite list of linear resource constraints; no source, receiver or
posterior is independently reselected.

For each source i let B_i be the set of its distinct positive threshold
values ell_il. Define

    P_big(u)=u sum_i min(a_i/u,sum_l V_il(u)),

    A_i(u)=sum_{beta in B_i} beta min(a_i/beta,
                              sum_{l:ell_il=beta}V_il(beta)),

    I_i(u)=integral_0^u min(a_i/t,
                              sum_{l:ell_il<=t}V_il(t))dt,

    P_cell(u)=P_big(u)+(sum_i[A_i(u)+I_i(u)])/(1-kappa).
                                                               (LG4)

The asserted bound is

    u |{x in E:F(x)>u}|<=P_cell(u).                       (LG5)

The weak tail a_i/t is shared across the selected cells at each t.
It is not charged afresh in every receiver cell. Distinct atomic
thresholds beta are explicitly paid separately in A_i; their number
is not hidden. Threshold zero has no atomic charge and uses the
ordinary integral from zero. Since E has finite measure, the integrand
is bounded near zero by |E|, so no 0 times infinity convention occurs.

Proof. First remove the union of {f_i>u}. Its measure costs at most
P_big(u)/u, by LG2 and the geometric volumes. Outside this union,
f_i<=u. On E_l, the terms with f_i<=ell_il sum to at most kappa u.
Thus if F>u the remaining terms have sum >(1-kappa)u. Markov gives

    u |{F>u}| <=P_big(u)
       +(1/(1-kappa))sum_il
               integral_E_l f_i 1_{ell_il<f_i<=u}dx.

For each term, truncated layer cake bounds the last integral by

    ell_il eta_il(ell_il)+integral_ell_il^u eta_il(t)dt.

Group the atomic terms having the same beta before applying LG2.
For the integrals use Tonelli first, collecting all cells with
ell_il<=t, and only then use LG2. This proves exactly LG4--5.

The theorem extends to countably many sources whenever the threshold
constraints hold with their full nonnegative sums. All costs are then
extended nonnegative sums, and Tonelli proves the same statement.
The finite formulation is the directly computable certificate used here.

## LG3. Explicit feasible choices and comparison with the old price

The resources are verifiable, not an unnamed optimized norm. Given
the receiver membership patterns, LG3 is a finite matrix inequality.
One explicit choice is the old support-graph plan

    ell_il=min(U_il,u a_i/(2A_i^graph)), kappa=1/2,
    A_i^graph=sum_{j adjacent i}a_j.                     (LG6)

For this comparison take cells of constant membership in the graph's
support sets, with U_il=0 off the support of source i. For a finite
source family this is a finite refinement. The graph includes every
pair of simultaneous memberships; the explicit potential support boxes
can be used if their full intersection graph is retained. On each such
cell the old active-clique argument proves feasibility. On an arbitrary
coarser cell, LG3 must instead be checked directly and is not automatic.
For fixed i, all nonzero costs in LG4 then occur at the same old
threshold: cells clipped to U_il have zero tail there and at all
higher t. Hence LG4 reproduces the R250 static price, with the same
certified cell heights if they were already used in that comparison.

More useful explicit plans can set ell_il=U_il for selected source/cell
pairs, provided their height sum and the remaining chosen thresholds
fit LG3. Such a pair has zero middle charge, including its atomic
term: when it enters the integral at t=ell_il its geometric tail is
already zero. A whole low-height source bundle in one receiver cell
can therefore be exempted without exempting that source elsewhere.
This exemption need not be achievable by any threshold fixed over E.

It is also legitimate to certify sum_i U_il<=u and discard that whole
cell from the strict superlevel problem. This is a pointwise height
test, not a claim that the original full posterior or source may be
cropped. The formula LG4 remains available without that extra step.

Actual same-receiver active mass was present in LG1's old proof.
Merely renaming its maximum as A_i^* is not a new result here. The new
usable ingredient is a concrete threshold matrix that satisfies LG3,
with the globally shared tail capacities in LG4; the example below
strictly improves even the best whole-E fixed-threshold choice.

## LG4. All levels and the actual receiver error

Suppose kappa(u),ell_il(u) are measurable choices satisfying LG3 for
the levels used. For any 0<epsilon<4, X=lambda|E|, true layer cake gives

    integral_E F dx<=epsilon X
              +integral_{epsilon lambda}^{4lambda}P_cell(u)du/u.
                                                               (LG7)

Thus all output levels and all lower thresholds have an explicit cost.
Any finite or countable menu of measurable certified plans can be
replaced by their pointwise minimum in LG7. The minimum is measurable,
and no multiplicative menu fee is required: each plan upper-bounds the
same scalar tail at that level. One may also take the minimum with
u|E|, any already paid old price, and a separately proved height cutoff.
In particular the very same certified cell heights give the simple
baseline

    Q_cell(u)=u sum_l |E_l|1_{sum_i U_il>u},

because F<=sum_i U_il on E_l. This baseline must be included when
comparing the shared-tail price with already available cell geometry.
No measurability assertion about an unrestricted uncountable optimizer
is needed. A sampled list of levels alone does not prove LG7.

This is a positive hard-response comparison. Its application to an
original traffic still requires that traffic's legitimate domination
by the same hard response. It does not infer that domination or spend
old negative credit, and it does not assert that beta has hard rank.

## LG5. A true L1, positive-volume, nonempty-response example

All intervals below are genuine Lebesgue-density sources/receivers.
Take n=1, a=1, b=101/100, lambda=u=1, d_1=d_2=1/10, and

    mu_1=(15/2)1_[-1/4,-3/20]dy,
    mu_2=(15/2)1_[3/20,1/4]dy,
    m_1=m_2=h_1=h_2=3/4.

Let the three disjoint receiver cells be

    E_L=[-3/5,-1/2], E_R=[1/2,3/5],
    E_M=[-1/1000,1/1000],
    |E_L|=|E_R|=1/10, |E_M|=1/500, |E|=101/500.

Every R in [a,b] fully captures the appropriate source on its own
outer cell and both sources on the middle cell; it never touches the
opposite source on an outer cell. Because normalization decreases in
R, the exact supremum heights, in column order (L,M,R), are

    (U_1l)_l=(3/4,3/4,0),
    (U_2l)_l=(0,3/4,3/4),
    F|E_L=F|E_R=3/4, F|E_M=3/2.                       (LG8)

In particular the strict u=1 response has measure 1/500 and is nonempty.
If the original lower hard band is required as well, choose the finite
ambient L1 density f=mu_1+mu_2+(3/2)1_[-2,2]. Every relevant window
lies in [-2,2], so its full maximal average on E is 9/4 on the outer
cells and 3 on the middle cell. Thus 2<G0<=4, and mu<=f. This certifies
the actual hard-band condition, not a FULL construction history.

Each active source's shrinking geometric box contains the whole
corresponding receiver cells for 0<t<3/4. Opposite outer cells are
outside even Q_{b+d_i}(z_i). Thus LG1 is simply its active cell volume
for t<3/4, and zero otherwise. All allowed c_i are >=1, so a_i/t>1
on this range, while |E|<1; none of LG4's shared weak capacities binds.

Choose kappa=3/4. On the outer cells set the active threshold to 3/4
and the inactive one to zero; on E_M set both thresholds to 3/8.
LG3 is verified cell by cell. The outer-cell middle charges vanish.
For each source the middle-cell atomic and integral charges are both
3/4000, so

    P_cell(1)=4*2*(3/4000+3/4000)=3/250.               (LG9)

By contrast the old graph has both sources adjacent and equal a_i,
so R250's kappa=1/2 thresholds are both 1/4 over E. Its complete
geometric-tail price is 153/500. Even after clipping by u|E|, it is
101/500, much larger than LG9. This comparison includes both sources
and every receiver cell, not one center's log improvement.

In fact any thresholds fixed over the whole E, with any 0<=kappa<1,
cost at least 153/1000 at u=1. A source whose threshold is below 3/4
has atomic-plus-integral charge (3/4)(51/500)=153/2000, independent
of that threshold. If neither is exempted, division by 1-kappa costs
at least 153/1000. Exempting one source needs kappa>=3/4 and leaves
the other charged at least 153/500. Exempting both is infeasible on
the middle cell. The price 153/1000 is attained by kappa=0 and both
thresholds zero. Thus the cell refinement has a strict effect beyond
choosing a better scalar kappa or inserting c_i into an old formula.

The example is a certificate diagnostic, not an assertion of optimal
receiver cost. Here U_il equals the actual constant f_i on every cell,
so the simple baseline Q_cell is the exact tail. At u=1 it gives
Q_cell(1)=1/500, strictly better than LG9's 3/250. Thus LG9 improves
the whole-E fixed-threshold family, not all already available receiver
geometry or the best actual fee.

## LG6. Full-level comparison at the same epsilon

There is no hidden adverse cost at other levels. At every 1<=u<3/2,
use the same outer thresholds 3/4 and middle thresholds 3u/8, still
with kappa=3/4. They satisfy LG3 and give the same price 3/250.

For a strong old comparison, optimize *all* whole-E fixed thresholds
and kappa, also allowing the receiver-volume cap u|E| and the global
height cutoff F<=3/2. Its exact price is

    Q_old(u)=min((101/500)u,153/1000), 0<u<3/2,
    Q_old(u)=0, u>=3/2.                               (LG10)

For u<3/4 the volume cap is exact because every receiver responds.
For 3/4<=u<3/2, no exempted source costs at least 153/1000, attained
at kappa=0. One exempted source costs at least
(153/2000)/(1-(3/4)/u)>=153/1000. This proves LG10, with the volume
cap taken as stated. The two branches cross at u*=153/202.

Set epsilon=1/4 and X=101/500. The complete old layer-cake cost,
including the receiver error and the interval through 4lambda, is

    C_old=epsilon X+integral_epsilon^4 Q_old(u)du/u
          =(153/1000)[1+log(101/51)].                 (LG11)

Use Q_old outside [1,3/2), and the new cell plan on that interval.
All levels have thus been certified, with the same epsilon X, and

    C_new=C_old-(141/1000)log(3/2)<C_old.              (LG12)

This strict decrease is not a finite-grid extrapolation. It holds
on an entire output-level interval of positive logarithmic length.
The actual receiver integral in this example is 153/1000. Indeed, the
complete cell baseline at the same epsilon=1/4 is exactly

    epsilon X+integral_epsilon^4 Q_cell(u)du/u
        =(3/4)(1/10+1/10)+(3/2)(1/500)=153/1000.

It is therefore better than both LG11 and LG12. The strict comparison
LG12 is only with the specified whole-E static-threshold family; it
does not establish an improvement over every known receiver-geometry
bound or a new general root price. For general
sources, the surviving geometric volumes, atom counts, resource
constraints, and complete level integral in LG4/LG7 remain payable
quantities; this note does not declare their general root budget paid.

## LG7. Actual finite verification and replay code

The following local Python run used exact Fraction arithmetic for the
source masses, full-window capture/exclusion on every receiver cell,
shrinking-box membership, threshold resources and price expressions.
It returned `PASS 27 exact geometry/resource/price checks`. The final
logarithms were evaluated separately with local mpmath 1.3.0 at 50
decimal digits:

    C_old =0.257544117269890852923631,
    C_new =0.2003735370266396750647312,
    decrease=0.05717058024325117785889985.

The strict decrease and formulas LG11--12 are analytic. These decimal
values are ordinary numerical evidence, not directed intervals, and
the finite example is not a FULL-history or asymptotic certificate.

```python
from fractions import Fraction as F
import mpmath as mp
mp.mp.dps=50
a,b,d=F(1),F(101,100),F(1,10)
src=[(F(-1,4),F(-3,20)),(F(3,20),F(1,4))]
cells=[(F(-3,5),F(-1,2)),(F(-1,1000),F(1,1000)),
       (F(1,2),F(3,5))]
active=[[1,1,0],[0,1,1]]
v=[r-l for l,r in cells]; hi=F(3,4); checks=0
for i,(l,r) in enumerate(src):
 assert (r-l)*F(15,2)==hi; checks+=1
 z=(l+r)/2
 for j,(L,R) in enumerate(cells):
  if active[i][j]:
   assert R-a/2<=l and L+a/2>=r
   assert max(abs(L-z),abs(R-z))<=(a+d)/2
  else:
   assert R+b/2<l or L-b/2>r
   assert min(abs(L-z),abs(R-z))>(b+d)/2
  checks+=1
for L,R in cells:
 assert L-b/2>=-2 and R+b/2<=2; checks+=1
assert [F(3,2)+hi*sum(active[i][j] for i in range(2))
        for j in range(3)]==[F(9,4),F(3),F(9,4)]
checks+=1

def price(u,k,ell):
 assert all(sum(ell[i][j] for i in range(2))<=k*u
            for j in range(3))
 assert all(0<=ell[i][j]<=min(u,hi*active[i][j])
            for i in range(2) for j in range(3))
 big=(sum(u*sum(v[j]*active[i][j] for j in range(3))
          for i in range(2)) if u<hi else F(0))
 middle=F(0)
 for i in range(2):
  atomic=sum(beta*sum(v[j] for j in range(3)
             if active[i][j] and ell[i][j]==beta)
             for beta in set(ell[i]) if 0<beta<hi)
  cuts=sorted({F(0),u}|{x for x in [hi]+ell[i] if 0<x<u})
  integral=F(0)
  for l,r in zip(cuts,cuts[1:]):
   t=(l+r)/2
   if t<hi:
    volume=sum(v[j] for j in range(3)
               if active[i][j] and ell[i][j]<=t)
    # Every allowed a_i>=m_i=hi; the weak constraint is nonbinding.
    assert volume<F(1)<=hi/t
    integral+=(r-l)*volume
  middle+=atomic+integral
 return big+middle/(1-k)

for u in [F(1),F(5,4),F(149,100)]:
 ell=[[hi,3*u/8,F(0)],[F(0),3*u/8,hi]]
 assert price(u,F(3,4),ell)==F(3,250); checks+=1
oldell=[[F(1,4),F(1,4),F(0)],[F(0),F(1,4),F(1,4)]]
assert price(F(1),F(1,2),oldell)==F(153,500); checks+=1
assert price(F(1),F(0),[[F(0)]*3 for _ in range(2)])==F(153,1000)
checks+=1
for u in [F(1,4),F(1,2),F(3,4),F(4,5),F(1),F(5,4),
          F(149,100),F(3,2),F(2),F(4)]:
 true=u*sum(v[j] for j in range(3)
             if hi*sum(active[i][j] for i in range(2))>u)
 old=(min(F(101,500)*u,F(153,1000)) if u<F(3,2) else F(0))
 new=F(3,250) if F(1)<=u<F(3,2) else old
 assert old>=true and new>=true; checks+=1
q=lambda x:mp.mpf(x.numerator)/x.denominator
Cold=q(F(153,1000))*(1+mp.log(q(F(101,51))))
Cnew=Cold-q(F(141,1000))*mp.log(q(F(3,2)))
print('PASS',checks,'exact geometry/resource/price checks')
print('C_old',mp.nstr(Cold,25),'C_new',mp.nstr(Cnew,25),
      'decrease',mp.nstr(Cold-Cnew,25))
```
