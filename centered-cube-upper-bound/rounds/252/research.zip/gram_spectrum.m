function gram_spectrum(input_path,output_path)
s=jsondecode(fileread(input_path));r=cell(numel(s.cases),1);
for j=1:numel(s.cases)
    H=double(s.cases(j).scaled_Gram); H=(H+H')/2;
    [V,D]=eig(H,'vector');[value,idx]=max(real(D));v=abs(real(V(:,idx)));v=v/sum(v);
    r{j}=struct('name',s.cases(j).name,'lambda_max',value,'lambda_min',min(real(D)),'Perron_mass',v);
end
out=struct('MATLAB_version',version,'release',version('-release'),'results',{r});
fid=fopen(output_path,'w');assert(fid>=0);cleanup=onCleanup(@()fclose(fid));fwrite(fid,jsonencode(out),'char');
end
