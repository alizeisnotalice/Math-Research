"""Exact native-grid tests. Large-n checks evaluate scalar inequalities only."""
from bisect import bisect_left, bisect_right
from fractions import Fraction as F
import json
import math
import platform
import sys

import flint
from flint import arb, ctx, fmpz_poly

ctx.prec = 256


def ceil(x):
    return -((-x.numerator) // x.denominator)


def head_count(a, s, delta):
    width = 2*s/a
    k = max(0, ceil(delta/width)-1)
    centers = [-s + (i+F(1,2))*width for i in range(a)]
    count = sum(abs(p)-s/a > s-delta for p in centers)
    assert count == 2*k
    assert all(abs(p)+s/a <= s for p in centers)
    return k


def enumerate_law(a, s):
    # Center probabilities for W~Unif[-1,1] and a uniform choice among
    # the a centers of open parents covering W.
    width = 2*s/a
    mids, law = [], []
    for i in range(-2*a, 3*a):
        p = -s + (i+F(1,2))*width
        length = min(F(1),p+s) - max(F(-1),p-s)
        if length > 0:
            mids.append(p)
            law.append(length/(2*a))
    assert sum(law) == 1
    return mids, law


def second_law(a, s):
    centers, first = enumerate_law(a,s)
    # Directly partition the continuum of W at the open-parent boundaries.
    ends = sorted({F(-1),F(1)} | {p + sign*s for p in centers for sign in (-1,1)
                                  if -1 < p + sign*s < 1})
    counts = [F(0) for p in centers]
    max_shift = F(0)
    for l,r in zip(ends,ends[1:]):
        w = (l+r)/2
        left, right = bisect_right(centers,w-s), bisect_left(centers,w+s)
        assert right-left == a
        width = 2*s/a
        for j in range(a):
            p = centers[left+j]
            counts[left+j] += (r-l)/(2*a)
            max_shift = max(max_shift,abs(p-(w-s+j*width)),abs(p-(w-s+(j+1)*width)))
    assert counts == first and max_shift <= 2*s/a
    return len(ends)-1


def true_tail_bound(mids, law, power, a, s, precision):
    # Effective farthest point of the closed native cell on each tail axis.
    squares = [(abs(p)+s/a)**2 for p in mids]
    common = math.lcm(*(w.denominator for w in law))
    numerators = [int(w*common) for w in law]
    assert sum(numerators) == common
    threshold = (F(81,100)*power*precision).__floor__()
    den = common**power

    def cdf(round_up):
        bins = [(ceil(v*precision) if round_up else (v*precision).__floor__())
                for v in squares]
        hist = [0]*(max(bins)+1)
        for j, num in zip(bins,numerators):
            hist[j] += num
        coeffs = (fmpz_poly(hist)**power).coeffs()
        mass = sum(int(k) for k in coeffs[:threshold+1])
        return F(mass,den)

    lo, hi = cdf(True), cdf(False)
    assert 0 <= lo <= hi <= 1
    return lo,hi


def row_load_case(n, N, ell):
    m,a = n//16,32*n
    d = n-m
    delta = F(1,10*N)
    s = F(21,20)+ell*delta
    k = head_count(a,s,delta)
    head = 1-(1-F(2*k,a))**m
    mids,law = enumerate_law(a,s)
    low,high = F(0),F(1)
    output = []
    for precision in (8,32):
        l,h = true_tail_bound(mids,law,d,a,s,precision)
        assert low <= l <= h <= high
        low,high = l,h
        output.append(dict(bins_per_unit=precision,
                           certified_floor_million=(head*l*10**6).__floor__(),
                           certified_ceil_million=ceil(head*h*10**6)))
    return dict(n=n, levels=N, level=ell, head_inclusive_outer_cells_per_side=k,
                head_fraction=str(head), tail_coordinate_outcomes=len(law),
                native_mean_open_load_brackets_millionths=output)


def scalar_case(k, c):
    n=2**(3*k)
    a,m,N=32*n,n//16,2**(2*k)
    d=n-m
    s=arb(23)/20
    delta=arb(1)/(10*N)
    t=arb(c)*arb(n).sqrt()
    priority=arb(n)*(delta/s).log1p()-arb(N)/t
    head_error=(-arb(m)*delta/(2*s)).exp()
    tail_gap=(arb(89)/100)**2-arb(929)/1200
    tail_error=(-2*arb(d)*tail_gap**2/(arb(43)/20)**4).exp()
    vol=(arb(m)*(arb(23)/20).log()
         +arb(d)*((arb(9)/10)*(2*arb.pi()*arb(1).exp()).sqrt()/4).log()).exp()
    # w_i=b for all labels, t>=1 and b/t <= 2^-n.
    bill = t*(head_error+tail_error+vol+(-arb(N)/t).exp()
              +(-arb(n)*arb(2).log()).exp())+1
    prerequisites=bool(priority>0 and arb(n)*(arb(21)/20).log()>arb(N)/t
                       and 3*s/a<delta/2 and 3*s/a<arb(1)/100 and t>=1)
    return dict(n_power_of_two=3*k,c=c,structural_bounds_certified=prerequisites,
                conditional_upper_t_squared_D_over_X=bill.str(10),
                upper_less_than_two_certified=bool(prerequisites and bill < 2))


def main():
    aligned=0
    for a in (16,32,64):
        for ratio in (F(1),F(2),F(3),F(7,2),F(9,4)):
            s=F(23,20)
            delta=ratio*(2*s/a)
            head_count(a,s,delta)
            aligned += ratio.denominator==1
    cases=[]
    for n,N in ((16,6),(32,10),(64,16)):
        for ell in (1,N):
            cases.append(row_load_case(n,N,ell))
    small=[second_law(a,F(21+i,20)) for a in (16,32,64)
                                      for i in (0,1,2)]
    large=[scalar_case(k,c) for k in (4,8,16,32,48,64) for c in (1,524288)]
    print(json.dumps(dict(runtime=dict(executable=sys.executable,
                                       python=platform.python_version(),
                                       flint=flint.__version__,arb_precision_bits=ctx.prec),
                          strict_inner_boundary_cases=15,aligned_cases=aligned,
                          independent_coordinate_laws=len(small),
                          partition_intervals_in_small_laws=sum(small),
                          true_native_grid_cases=cases,scalar_checks=large),
                     sort_keys=True,indent=2))


if __name__=="__main__":
    main()
