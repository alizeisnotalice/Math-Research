import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as m
m.mp.dps=50
F=m.mpf; L=m.log(2); k=2; n=3; eps=F(1)/16
nu=[F(1),F(1),eps]; scores=[F(n),F(k),F(0)]
wg=[F(1)/8,F(1)/4,F(1)]; eg=sum(x*w for x,w in zip(nu,wg))
checks=0
for Q in [[F(1),F('.01'),F('.01')],[F('.01'),F(1),F('.01')]]:
    q=sum(x*z for x,z in zip(nu,Q)); p=F('2.5')*q/eg
    b=[min(L,max(F(0),m.log(p*w/z))) for w,z in zip(wg,Q)]
    for t in map(F,['1','1.125','1.25','1.5','1.75','1.875','2']):
        w=[t**(-n),t**(-k),F(1)]; e=sum(x*z for x,z in zip(nu,w))
        pi=[x*z/e for x,z in zip(nu,w)]
        def E(fun):return sum(pi[i]*pi[j]*fun(i,j) for i in range(3) for j in range(3))
        P=E(lambda i,j:max(scores[i]-scores[j],0)*max(b[j]-b[i],0))
        R=E(lambda i,j:max(scores[i]-scores[j],0)*max(b[i]-b[j],0))
        mk=sum(pi[i]*scores[i] for i in range(3)); mb=sum(pi[i]*b[i] for i in range(3))
        cov=sum(pi[i]*(scores[i]-mk)*(b[i]-mb) for i in range(3))
        vk=sum(pi[i]*(scores[i]-mk)**2 for i in range(3))
        vb=sum(pi[i]*(b[i]-mb)**2 for i in range(3))
        assert abs(P-R+cov)<F('1e-45'); checks+=1
        assert P<=(m.sqrt(vk*vb)-cov)/2+F('1e-45'); checks+=1
        cuts=sorted(set([F(0),L]+b)); lc=F(0)
        for lo,hi in zip(cuts[:-1],cuts[1:]):
            r=(lo+hi)/2
            lc+=(hi-lo)*E(lambda i,j:max(scores[i]-scores[j],0)*int(b[i]<=r<b[j]))
        assert abs(P-lc)<F('1e-45'); checks+=1
        weighted=sum(nu[i]*Q[i]*w[i]/wg[i] for i in range(3))
        assert vb<=L**2/(p*e)*weighted+F('1e-45'); checks+=1
    pig=[nu[i]*wg[i]/eg for i in range(3)]; c=q/(p*eg)
    d1=sum(pig[i]*(L-b[i]) for i in range(3))
    d2=sum(pig[i]*(L-b[i])**2 for i in range(3))
    assert d1<=c*(m.exp(L)-1)+F('1e-45'); checks+=1
    assert d2<=2*c*(m.exp(L)-1-L)+F('1e-45'); checks+=1
print('PASS',checks)
