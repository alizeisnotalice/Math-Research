#!/usr/bin/env python3
"""R275 finite threshold averaging and actual continuous classifier checks."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp

def enc(x):return mp.nstr(x,100)
def mm(x):
 x=F(x);return mp.mpf(x.numerator)/x.denominator
def phi(x):
 x=abs(x)
 if x<=mp.mpf('.5'):return 1-mp.expint(3,mp.mpf('.5')-x)-mp.expint(3,mp.mpf('.5')+x)
 return mp.expint(3,x-mp.mpf('.5'))-mp.expint(3,x+mp.mpf('.5'))
def phip(x):
 sign=1 if x>=0 else -1;x=abs(x)
 return sign*(mp.expint(2,x+mp.mpf('.5'))-mp.expint(2,abs(x-mp.mpf('.5'))))
def models():
 out=[]
 for phase,ns,S,pi,kpattern,hs in [('initial',[2,2,8,8],[F(1,4),F(1,2),F(3,2),F(3)],[F(1,10),F(2,10),F(3,10),F(4,10)],None,[F(1),F(3,2),F(2),F(0)]),('stress',[8,32,32,64],[F(1)-F(1,10**12),F(1),F(1)+F(1,10**12),F(2)],[F(1,4)]*4,None,[F(1)+F(1,10**12),F(1)-F(1,10**12),F(0),F(3)]),('expanded',[128,512,512,512],[F(1,10),F(499999,1000000),F(1,2),F(999999,1000000),F(3,2),F(5,2)],[F(32,63),F(16,63),F(8,63),F(4,63),F(2,63),F(1,63)],None,[F(1),F(2),F(3),F(1,2)])]:
  for n,h in zip(ns,hs):
   k=[n,n//2,0,0] if len(S)==4 else [n,n//2,n//4,n,0,n//8]
   out.append((phase,n,S,pi,k,h))
 return out

def band(l,r,S,pi,k,h,lift=False,dps=40):
 pts=sorted({l,r}|{x for x in S+[h] if l<x<r});formal=[];exactchecks=0
 for v in range(len(S)):
  for u in range(len(S)):
   selected=not lift or (S[v]<=1 and S[u]>1)
   product=F(1)
   for a,b in zip(pts,pts[1:]):
    mid=(a+b)/2
    if selected and S[v]<=mid<S[u] and mid<=h:product*=b/a
   lo=max(l,S[v]);hi=min(r,S[u],h)
   expected=hi/lo if selected and hi>lo else F(1);assert product==expected;exactchecks+=1
   coeff=pi[v]*pi[u]*max(k[v]-k[u],0)
   if coeff and product!=1:formal.append((coeff,product,v,u))
 with mp.workdps(dps):
  direct=mp.mpf(0)
  for a,b in zip(pts,pts[1:]):
   mid=(a+b)/2;coeff=sum(pi[v]*pi[u]*max(k[v]-k[u],0) for v in range(len(S)) for u in range(len(S)) if (not lift or (S[v]<=1 and S[u]>1)) and S[v]<=mid<S[u] and mid<=h)
   direct+=mm(coeff)*mp.log(mm(b/a))/mp.log(2)
  closed=sum(mm(c)*mp.log(mm(q))/mp.log(2) for c,q,v,u in formal);assert abs(direct-closed)<mp.mpf('1e-32')
  deep=sum(mm(c)*mp.log(mm(q))/mp.log(2) for c,q,v,u in formal if S[v]<=F(1,2));boundary=closed-deep
  return {'direct_partition_average':enc(direct),'closed_cut_average':enc(closed),'absolute_residual':enc(abs(direct-closed)),'deep_good_contribution':enc(deep),'boundary_good_contribution':enc(boundary),'partition_breakpoints_exact':list(map(str,pts)),'exact_pair_partition_checks':exactchecks,'formal_log_terms':[{'coefficient_exact':str(c),'log_ratio_exact':str(q),'v':v,'u':u} for c,q,v,u in formal]}

def threshold(dps):
 rows=[]
 for phase,n,S,pi,k,h in models():
  assert sum(pi)==1 and all(s>0 for s in S) and all(0<=x<=n for x in k)
  upper=band(F(1),F(2),S,pi,k,h,False,dps);lower=band(F(1,2),F(1),S,pi,k,h,True,dps) if h>=1 else None
  weights=[]
  with mp.workdps(dps):
   for s in S:
    w=mp.log(mm(F(1)/max(F(1,2),s)))/mp.log(2) if s<1 else mp.mpf(0)
    assert 0<=w<=1
    weights.append(enc(w))
  rows.append({'stage':phase,'n':n,'scores':k,'posterior_exact':list(map(str,pi)),'S_exact':list(map(str,S)),'high_h_exact':str(h),'upper_band':upper,'lifted_lower_band':lower,'lifted_high_qualification':h>=1,'lifted_good_weight_by_S':weights})
 return rows

def classifier(dps):
 base={F(0),F(1,8),F(1,4),F(49,100),F(1,2),F(51,100),F(3,4),F(1),F(2),F(4),F(8),F(16),F(32),F(64)}
 points=base|{-x for x in base};pairs=set(zip(sorted(points),sorted(points)[1:]))
 for sign in [-1,1]:
  for power in [1,4,8,12,20,30]:
   a=sign*F(1,2)-F(1,10**power);b=sign*F(1,2)+F(1,10**power);points|={a,b};pairs.add((a,b))
 soft=[F(1),F(1,2),F(1,100),F(1,10**8),F(1,10**50),F(1,10**200)]
 with mp.workdps(dps):
  derivatives=[]
  for x in sorted(points):
   ratio=abs(phip(mm(x))/phi(mm(x)));assert ratio<=3
   derivatives.append({'x_exact':str(x),'abs_log_phi_derivative':enc(ratio)})
  independent=[]
  def w(z):
   z=abs(z);return mp.mpf(1) if z==0 else mp.exp(-z)-z*mp.expint(1,z)
  for x in map(mp.mpf,['0','.5','1','4','64']):
   a=x-mp.mpf('.5');b=x+mp.mpf('.5');pts=[a,mp.mpf(0),b] if a<0<b else [a,b];actual=sum(mp.quad(w,[u,v]) for u,v in zip(pts,pts[1:]));e3=phi(x);assert abs(actual-e3)<mp.mpf('1e-32');independent.append({'x':enc(x),'phi_E3':enc(e3),'phi_integrated_w':enc(actual),'absolute_residual':enc(abs(actual-e3))})
  pairsout=[];jumps=[];tensors=[]
  # Extra precision is used solely for cancellation in close boundary pairs and
  # large log(1/s) offsets. It is explicitly not interval arithmetic.
  with mp.workdps(dps+60):
   pcache={x:phi(mm(x)) for x in points};phib=phi(mp.mpf('.5'))
   def fs(s,x):
    p=pcache[x];inside=abs(x)<=F(1,2);j=mp.log((1-s+s*phib)/(s*phib));return mp.log((1-s if inside else 0)+s*p)-(j if inside else 0)
   logratios=[]
   for a,b in sorted(pairs):
    rr=abs(mp.log(pcache[b])-mp.log(pcache[a]))/mm(b-a);assert rr<=3;logratios.append(rr)
   for ss in soft:
    s=mm(ss);j=mp.log((1-s+s*phib)/(s*phib));inside=mp.log(1-s+s*phib)-j;outside=mp.log(s*phib);rawjump=mp.log(1-s+s*phib)-mp.log(s*phib);assert abs(inside-outside)<mp.mpf('1e-60');assert abs(rawjump-j)<mp.mpf('1e-60')
    jumps.append({'s_exact':str(ss),'j_s':enc(j),'raw_core_jump':enc(rawjump),'corrected_boundary_residual':enc(abs(inside-outside))})
    best=mp.mpf(0);at=None
    for a,b in sorted(pairs):
     rr=abs(fs(s,b)-fs(s,a))/mm(b-a);assert rr<=3
     if rr>best:best=rr;at=[str(a),str(b)]
    pairsout.append({'s_exact':str(ss),'tested_pairs':len(pairs),'max_F_s_pair_Lipschitz_ratio':enc(best),'max_pair_exact':at})
    for n in [2,8,32]:
     pa=sorted(pairs);chosen=[pa[i%len(pa)] for i in range(n)];diff=abs(sum(fs(s,b)-fs(s,a) for a,b in chosen));distance=sum(mm(b-a) for a,b in chosen);assert diff<=3*distance
     tensors.append({'n':n,'s_exact':str(ss),'actual_sum_F_difference':enc(diff),'l1_distance':enc(distance),'bound_3_l1':enc(3*distance)})
  return {'tested_global_Lipschitz_constant':3,'phi_half':enc(phi(mp.mpf('.5'))),'boundary_absolute_log_slope':enc(abs(phip(mp.mpf('.5'))/phi(mp.mpf('.5')))),'elementary_phi_half_lower_bound':enc(mp.mpf('.5')-1/(3*mp.e)),'elementary_boundary_slope_upper':enc(1/(mp.mpf('.5')-1/(3*mp.e))),'derivative_checks':derivatives,'max_log_phi_derivative':max(derivatives,key=lambda r:mp.mpf(r['abs_log_phi_derivative'])),'max_log_phi_pair_ratio':enc(max(logratios)),'independent_phi_checks':independent,'F_s_pair_checks':pairsout,'jump_checks':jumps,'tensor_sum_checks':tensors,'base_working_dps':dps,'boundary_pair_guard_digits':60,'s_zero':'Excluded: j_s and log f_s outside the hard core are undefined at s=0. Only positive s tending to0 are tested.'}

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and not k.endswith('_exact') and k not in ['stage','s_zero']:
    try:
     z=mp.mpf(v)
     if mp.isfinite(z):out[path+k]=z
    except ValueError:pass
   elif isinstance(v,(dict,list)) and k not in ['formal_log_terms']:out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=p.parse_args();lo={'threshold':threshold(40),'classifier':classifier(40)};hi={'threshold':threshold(70),'classifier':classifier(70)}
 with mp.workdps(150):
  a=fields(lo);b=fields(hi);assert a.keys()==b.keys();diff={k:abs(a[k]-b[k])/max(1,abs(b[k])) for k in a};worst=max(diff,key=diff.get);md=enc(diff[worst]);assert diff[worst]<mp.mpf('1e-30')
 rows=hi['threshold'];exactchecks=sum(r['upper_band']['exact_pair_partition_checks']+(r['lifted_lower_band']['exact_pair_partition_checks'] if r['lifted_lower_band'] else 0) for r in rows)
 out={'schema':'R275-threshold-classifier-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'threshold_laws':12,'threshold_stages':{'initial':4,'stress':4,'expanded':4},'exact_pair_partition_product_checks':exactchecks,'lifted_qualified_laws':sum(r['lifted_high_qualification'] for r in rows),'phi_derivative_points_per_precision':len(hi['classifier']['derivative_checks']),'independent_phi_integrals_per_precision':5,'positive_soft_parameters':6,'F_s_pair_checks_per_precision':sum(r['tested_pairs'] for r in hi['classifier']['F_s_pair_checks']),'boundary_jump_checks_per_precision':6,'tensor_sum_checks_per_precision':18,'precision_fields_compared':len(diff)},'mp40':lo,'mp70':hi,'precision_max_relative_difference':md,'precision_worst_field':worst,'scope':['Threshold source laws are fixed finite posteriors/scores, not original geometric FIRST/high/history FULL inputs. Rational K breakpoints partition the whole band; for every pair, exact product of active interval ratios equals the closed ratio, certifying logarithmic telescoping algebraically. Numerical logs remain ordinary arithmetic.','Lifted band[.5,1] is evaluated only if h>=1 and uses G1={S<=1},B1={S>1}; weights1 for S<=.5 and decaying weights as S approaches1 are displayed. This finite boundary/deep comparison is not a universal density order.','Actual phi= h*w is computed by E3 and independently by integrating w=exp(-abs z)-abs z E1(abs z), with continuous w(0)=1. Derivatives use E2.','Classifier F_s=log((1-s)h+s phi)-j_s h uses corrected continuous boundary convention. 60 internal guard digits for close boundary differences and tiny s offsets are disclosed; no outward intervals or general3-Lipschitz proof is inferred.','Conditional fixed-cut localization requires both stated threshold-transfer signs and an actual classifier crossing; this numerical suite does not independently certify that original branch.','No activation-clock model was added after priority changed. Original FULL/root/order conclusions are not certified by this numerical suite.']}
 args.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst,'max_phi_log_derivative':hi['classifier']['max_log_phi_derivative']}))
if __name__=='__main__':main()
