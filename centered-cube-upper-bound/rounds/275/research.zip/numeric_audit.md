# R275 independent numerical formula and three-leg integration audit

## N1. Reviewed files and replay binding

Reviewed the complete `/tmp/r275_numeric.py`, `/tmp/r275_numeric.json` and `/tmp/r275_numeric.md`. No author file was changed. The supplied parent replay `/tmp/r275_parent_replay.json` is byte-for-byte identical to the author JSON.

- Python SHA256: `b8b17e227d9864ac99b0b303fd308d5a4a45eaa4a33fe67ce9ccc0b957ee4101`.
- JSON/replay SHA256: `9ba83e0c7e8649a813f322ff88b4d36ee8c56cd63da7ed03bd53f0b41e761aa4`.
- Notes SHA256: `797831fab5a2eee6ba17720f95d22d1d2c1e194a1869906f54a3f728f20799a9`.

This audit does not independently rerun all twelve threshold laws or the complete author's quadrature suite. It statically checks their definitions and independently executes the actual three-leg tests in N4.

## N2. Formula/code checks

The author's phi is exactly h*w, with h=1_[−1/2,1/2] and w(x)=integral_0^1 exp(−|x|/r)dr. Integrating r exp(−c/r) gives E3(c), which yields both branches in `phi`. Differentiating gives the stated E2 difference in `phip`, with the correct odd sign; at zero it is zero. The independent author integral of w uses the continuous w(0)=1 convention.

For positive s,
\[
 j_s=\log[(1-s+s\phi(1/2))/(s\phi(1/2))],\qquad
 F_s(r)=\log f_s(r)-j_sh(r).
\]
At either hard boundary the inside value after subtraction is log(s phi(1/2)), the outside limit. The author's signed correction is therefore correct. Its derivative checks sample actual phi; the actual global log-Lipschitz proof is separate from this finite numerical evidence. In particular, testing ratios <=3 on 51 points does not by itself establish the theorem.

The threshold code partitions rational K bands at all S values and at the high cutoff h. For each ordered pair, the product of active subinterval endpoint ratios telescopes exactly to max(l,S_v) through min(r,S_u,h), with the empty interval encoded by ratio 1. All endpoints are included correctly up to zero log-K measure. Multiplying rational coefficients by the logarithms gives the same threshold average. The lifted lower band is evaluated only for h>=1 and retains the fixed G_1/B_1 selector; it is not silently replaced by a newly classified posterior.

The counts are consistent with the source loops and JSON:

- 12 threshold laws, 4 in each stage; 460 exact ordered-pair partition-product checks; 8 lower-band-qualified laws.
- 51 phi derivative points, 5 independent phi integrals, 6 positive s parameters, 38 corrected-log pairs per s (=228), 6 boundary-jump checks, and 18 tensor checks per base precision.
- 255 finite reported numeric fields are compared at base 40/70 digits. Exact rational strings and formal log terms are excluded from that numeric-field comparison.

The source's `fields` parser checks scaled differences |x40−x70|/max(1,|x70|); for tiny quantities this is an absolute comparison, not a relative-error guarantee. The close boundary/tiny-soft subtraction uses an explicitly disclosed extra 60 working digits. This is adequate numerical cancellation guarding for the stated menu, not outward interval certification. s=0 is correctly excluded from finite j_s/F_s statements. The JSON does not claim a proof of a classifier anti-concentration or FULL branch.

Coverage boundary: the author's tensor tests sum corrected one-dimensional F_s values. They do not themselves evaluate a mixture of the three actual targets. N4 supplies that additional finite check.

## N3. Actual three-leg formula checked independently

For a fixed actual receiver x, let A=(L,Lplus,b), Lplus=min(b,(1+1/n)L), target softs (s,s,1), and
\[
 K_i(v)=P_{s_i,A_i}(x-v),\quad \omega_i(u)=K_i(u)/\sum_jK_j(u).
\]
Set Delta_i=corecount_Ai(x,v)−corecount_Ai(x,u) for i=1,2 and Delta_3=0. The actual weighted upper ratio is
\[
 \frac{Q(v)}{Q(u)}\le\sum_i\omega_i(u)
        \exp\{3\|v-u\|_1/A_i+j_s\Delta_i\}.             \tag{N3}
\]
The corresponding negative-distance expression is a lower bound. The upper bound is also at most
\(\exp(3\|v-u\|_1/a)\sum_i\omega_i(u)e^{j_s\Delta_i}\),
and hence at most exp(3||v−u||_1/a+j_s max(0,Delta_1,Delta_2)). The signs of the two moving-leg Delta values are retained **inside** the weighted sum.

The independent code below uses a direct positive r-integral for phi rather than the author's E3 formula. It constructs all three physical kernels, including their A_i^-n normalization, and evaluates their sum. It covers n=2,8; s=1,1/100,10^-12; L=1 and 19/10 with a=1,b=2; both unclipped and clipped Lplus; mixed signed core changes, their reverse, and a close hard-core crossing. The receiver x is nonzero and u/v coordinates have both signs. Its statements concern actual fixed-parameter kernels, not original source/history/FIRST data.

## N4. Executable independent diagnostic

```python
import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
from fractions import Fraction as F
import mpmath as mp

def run(dps):
    mp.mp.dps=dps
    def mm(q):return mp.mpf(q.numerator)/q.denominator
    cache={}
    def phi(q):
        q=abs(q)
        if q not in cache:
            x=mm(q)
            def inner(r):
                if not r:return mp.mpf(0)
                if q<=F(1,2):
                    return r*(2-mp.exp(-(mp.mpf('.5')-x)/r)
                                -mp.exp(-(mp.mpf('.5')+x)/r))
                return r*(mp.exp(-(x-mp.mpf('.5'))/r)
                           -mp.exp(-(x+mp.mpf('.5'))/r))
            cache[q]=mp.quad(inner,[0,mp.mpf('.25'),mp.mpf('.5'),1])
        return cache[q]
    def logP(ss,A,offset):
        s=mm(ss)
        return -len(offset)*mp.log(mm(A))+sum(
            mp.log((1-s if abs(z/A)<=F(1,2) else 0)+s*phi(z/A))
            for z in offset)
    def core(A,offset):return sum(abs(z)<=A/2 for z in offset)
    def lse(xs):
        mx=max(xs);return mx+mp.log(sum(mp.exp(z-mx) for z in xs))
    checks=0; rows=[]; signatures=set(); maxrat=mp.mpf(0)
    for n in [2,8]:
      for ss in [F(1),F(1,100),F(1,10**12)]:
       for L in [F(1),F(19,10)]:
        b=F(2); Lp=min(b,(1+F(1,n))*L); scales=[L,Lp,b]
        j=mp.log((1-mm(ss)+mm(ss)*phi(F(1,2)))/(mm(ss)*phi(F(1,2))))
        middle=(L+Lp)/4; outside=Lp/2+F(1,1000)
        inside=L/2-F(1,1000)
        mixed_u=[middle,middle]; mixed_v=[inside,outside]
        patterns=[(mixed_u,mixed_v),(mixed_v,mixed_u),
                  ([L/2+F(1,10**12)]*2,[L/2-F(1,10**12)]*2)]
        for uu,vv in patterns:
            # x is a physical receiver; u=x+offset_u and v=x+offset_v.
            x=[F(1,8) if i%2==0 else -F(1,10) for i in range(n)]
            ou=[(-1 if i%2 else 1)*uu[i%2] for i in range(n)]
            ov=[(-1 if i%2 else 1)*vv[i%2] for i in range(n)]
            u=[x[i]+ou[i] for i in range(n)];v=[x[i]+ov[i] for i in range(n)]
            dist=sum(abs(u[i]-v[i]) for i in range(n))
            U=[logP(s,A,ou) for s,A in zip([ss,ss,F(1)],scales)]
            V=[logP(s,A,ov) for s,A in zip([ss,ss,F(1)],scales)]
            dk=[core(scales[i],ov)-core(scales[i],ou) for i in range(2)]+[0]
            signatures.add(tuple(dk[:2])); logomega=[z-lse(U) for z in U]
            actual=lse(V)-lse(U)
            radius=[3*mm(dist/A) for A in scales]
            for i in range(3):
                err=abs((V[i]-U[i])-j*dk[i])
                assert err<=radius[i]+mp.mpf('1e-35');checks+=1
                if radius[i]:maxrat=max(maxrat,err/radius[i])
            upper=lse([logomega[i]+radius[i]+j*dk[i] for i in range(3)])
            lower=lse([logomega[i]-radius[i]+j*dk[i] for i in range(3)])
            assert actual<=upper+mp.mpf('1e-35');checks+=1
            assert lower<=actual+mp.mpf('1e-35');checks+=1
            coarse=3*mm(dist)+lse([logomega[i]+j*dk[i] for i in range(3)])
            assert upper<=coarse+mp.mpf('1e-35');checks+=1
            assert actual<=3*mm(dist)+j*max(dk)+mp.mpf('1e-35');checks+=1
            identity=lse([logomega[i]+V[i]-U[i] for i in range(3)])
            assert abs(identity-actual)<mp.mpf('1e-35');checks+=1
            rows.append((actual,upper,lower))
    return rows,checks,signatures,maxrat,len(cache)

lo,nlo,sig,rat,nphi=run(50)
hi,nhi,sig2,rat2,nphi2=run(80)
mp.mp.dps=100
err=max(abs(a-b)/max(1,abs(b)) for x,y in zip(lo,hi) for a,b in zip(x,y))
assert err<mp.mpf('1e-35')
assert nlo==nhi==288 and len(lo)==len(hi)==36 and sig==sig2
print('PASS',nlo+nhi,'inequalities; configurations',len(hi),'per precision')
print('core signatures',sorted(sig))
print('phi arguments per precision',nphi,nphi2)
print('max corrected-leg ratio / (3 distance)',mp.nstr(rat2,20))
print('max scaled 50/80 difference',mp.nstr(err,12))
```

## N5. Actual independent output and conclusion

The N4 code was extracted from this Markdown and executed locally. It returned:

```text
PASS 576 inequalities; configurations 36 per precision
core signatures [(-4, 4), (-1, 1), (1, -1), (2, 0), (4, -4), (8, 0)]
phi arguments per precision 35 35
max corrected-leg ratio / (3 distance) 0.72720724970562989452
max scaled 50/80 difference 1.76750620687e-49
```

The signed signatures explicitly test a moving leg entering the core while the other leaves it, and the reverse. All three physical target normalizations and the actual mixture weights are included, so this goes beyond testing sums of F_s alone. The smallest s and small n are kernel stress parameters; they are not asserted to satisfy every original soft-margin gate.

Audit conclusion: PASS for the author's stated finite formula/count/precision scope and for the additional independent fixed-parameter actual three-leg weighted-ratio tests. The author's full replay is only claimed as the parent execution whose saved JSON matches, not as this reviewer's independent rerun. The diagnostics are ordinary arbitrary-precision calculations, not interval bounds, a proof of global log-Lipschitz continuity, an averaged original-traffic payment, a source/FIRST/history certificate, or a FULL input. No additional original negative credit or free threshold/scale menu is inferred.
