# R275 actual execution notes

Executed with Python3.12.14 at `/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`, mpmath1.3.0 from `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor`. Replay: `PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r275_numeric.py --output /tmp/r275_numeric.json`. No repo files or old menus changed.

Three threshold stages have4 laws each, reaching n512, with fixed correlated finite posterior and rational scores/S/high. All460 exact pair partition-product checks passed; these are algebraic logarithm telescoping certificates. Eight laws qualify for the lifted band high>=1. The ordinary40/70 logarithm averages agree. Deepgood S<=.5 receives full lifted weight1, whereas S=1−10^−12 receives only approximately1.442695e−12. This measures a real boundary loading loss within the fixed-posterior tool, not an asymptotic claim or an actual original classifier family.

The priority actual-kernel suite has51 phi derivative locations including ±.5 neighborhoods and tails to64, five independent phi=integral w evaluations per precision,228 F_s pair checks, six exact-form signed-jump cancellation evaluations, and18 finite tensor-sum checks per precision. Positive s are1,.5,.01,10^−8,10^−50,10^−200. s=0 is excluded because log f_s outside the core and j_s are undefined.

Maximum sampled absolute log-phi derivative is2.1816217491365743 at±.5, below tested3. Every tested corrected F_s pair is below3. The raw boundary jump equals j_s; subtracting j_s h makes either endpoint h convention give the same continuous value to working accuracy. Very close pairs down to2·10^−30 and large log(1/s) offsets are evaluated using60 guard digits beyond the40/70 base precision. This is disclosed cancellation control, not interval arithmetic and not a proof of global3-Lipschitz continuity.

Across255 reported numeric fields the maximum scaled40/70 difference is 2.176019806091529561625435015454318729978981941460974733643668848213271864904223501161704675840737976e-40. No activation model was added after the priority switch. The evidence supports retaining the classifier normalization as a plausible tool; it does not certify FULL, physical FIRST/high/history qualifications, an averaged-traffic payoff, or any universal dimension order.

Independent computed constants: phi(.5)=0.390308032802239863161418112269939175484476353296545896211010693463215652748492572853029456655487143; boundary |log phi| slope=2.18162174913657431109268332260628062332567937539427404463224684271897624172995464813153633303695852; elementary phi(.5) lower bound=.5−1/(3e)=0.3773735196095192261348254099461797108513962896560773884973877327675128332151002552507140859404235727; its reciprocal=2.649894462745379804268876532834423414588260627448530355134519825088802624668053452875084114823687556. These ordinary values support the parent’s tighter3 screen; the general proof is separate.

Fixed-cut localization remains conditional on Delta_kappa_L,Delta_kappa_Lplus<=0, d<=r, and an actual classifier cut. The numerical suite does not certify those original conditions or promote a level-averaged decision to fixed K.

Source SHA256: b8b17e227d9864ac99b0b303fd308d5a4a45eaa4a33fe67ce9ccc0b957ee4101

JSON SHA256: 9ba83e0c7e8649a813f322ff88b4d36ee8c56cd63da7ed03bd53f0b41e761aa4
