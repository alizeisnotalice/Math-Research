# R275 independent threshold-averaging screen

**Verdict:** the log-uniform pair multiplier is exact under the stated fixed pre-threshold data. It does **not** justify replacing the already chosen current P_(K0) by its threshold average. A valid upstream average must start from the same pre-K T_small inequality for every K and retain all K-dependent costs/gates. This screen preceded author-proof reading.

## 1. Original definitions actually checked

Read R117 `joint_geometry.md` JG1–JG6, especially lines 9–62. The original ν, tree Z_t, w_t,e_t,Π_t and actual physical selectors are fixed before the scalar classifier K. At the actual receiver, the three tests are the same current/future tests, and integral Q_x*ν≤q. Its JG4–JG5 give

    B_K={u in Z_g:p_y w_g(u)>K Q_x*(u)},
    G_K=Z_g minus B_K,
    high_K={p_y e_g≥2Kq},
    H_K=E sum_V integral 1_high,K q^(-1)p_y h_R a_omega
                                      Π_g(B_K) dx β(dy)ν(dz),
    T_small≤T_low,K+2H_K.                                (T1)

Current terminal G/B are static in t for each fixed K, though they depend on actual x,y,g. All original sources/physical scales and gates in (T1) must refer to that same upstream problem. The current positive remainder uses the good-upper-score slot G_K(v)B_K(u)(k_t(v)−k_t(u))_+, with the two original complete Π_t copies. Future-deleted sources are not silently added to G_K.

## 2. Exact log-uniform pair multiplier

Fix 0<K0<infinity and one **global** threshold K distributed by dK/[K log2] on [K0,2K0]. At a fixed original row let

    S(v)=p_y w_g(v)/Q_x*(v),  S=+infinity when Q_x*=0,
    h0=p_y e_g/(2q).

Original terminal membership is retained separately. At fixed K, good means S_v≤K, bad means K<S_u, and high means K≤h0. Thus put

    L=max(K0,S_v), U=min(2K0,S_u,h0).

If U>L (necessarily L finite and positive), the exact averaged bare multiplier is

    Mbar(v,u)=log(U/L)/log2;                             (T2)

otherwise it is zero. Multiply this by the original terminal indicator 1_(Z_g)(v)1_(Z_g)(u). The score, Π_t product and actual dx/source coefficients are unchanged. Good's lower endpoint and high's upper endpoint are inclusive; bad's upper endpoint is strict. Individual endpoints have zero log-uniform measure, so they do not change (T2), but fixed-K formulas must retain their original conventions.

Consequences/zero cases:

- Q_v=0 gives S_v=infinity and multiplier zero for every finite threshold.
- Q_u=0 gives S_u=infinity; 2K0 and high still cap U.
- S_v=0 (if an extended-infinite Q is allowed) uses L=K0. For actual finite target kernels and positive p,w_g this does not arise except null/extended conventions.
- S_v≥S_u or U≤L gives zero; one never evaluates log0 or an undefined infinity/infinity.
- Invalid/zero-degree actual rows are zero before posterior division; e_g=0 implies no positive finite-K high row.
- S_v=2K0 can be good at only the terminal grid endpoint, giving zero log average. S_u=2K0 excludes one endpoint only and has its stated continuous average.

For any K-independent nonnegative original extra gate Gamma, the multiplier is Gamma times (T2). If an actual gate, source density, suffix classifier, capture allocation or other history depends on K, the exact averaged coefficient is instead

    (1/log2) integral_(K0)^(2K0)
        Gamma_K 1_{S_v≤K<S_u}1_{K≤h0} dK/K.             (T3)

It can be bounded above by Mbar only when 0≤Gamma_K≤1; it is not equal to a frozen Gamma_(K0) times Mbar without proof. No dependence of the original sources or normalizers may be discarded. Tonelli applies to the nonnegative original positive integrals; signed identities first require their original common finite truncation and their full K-dependent terms.

If a later upper bound introduces K^r explicitly, its exact fixed-pair averaging factor is

    (U^r−L^r)/(r log2),   r not zero, U>L,

and is (T2) for r=0. Such coefficients cannot just be replaced by K0^r. This formula alone does not remove other K dependence.

## 3. What the average can and cannot control

There is no general bound P_(K0)≤C average_K P_K from the threshold algebra. For example the abstract threshold pair S_v=K0, S_u=(1+epsilon)K0 and h0≥2K0 is included at K0, but its averaged multiplier is log(1+epsilon)/log2, tending to zero. This is a single algebraic qualification example, not a FULL geometric counterexample. Conversely some pairs absent at K0 can appear later in the interval. The classifier changes the problem; an existing current remainder after K0-specific reductions is not the averaged remainder by identity or domination.

The average is an exact description of a **newly averaged family** of the original positive integrals, assuming its entire K-dependent construction is provided. It discounts only pairs separated by a narrow exposed log-threshold interval. It can be one on pairs spanning the full window, so no universal small factor/root source payment follows from averaging alone. It is one global K averaged linearly, not independently optimized K(x), K(y), K(v,u), or K(t).

## 4. Legitimate upstream restart and its costs

With one same T_small and all pre-K sources/selectors/gates fixed, (T1) holds for every deterministic K. Consequently

    T_small≤average_K T_low,K +2 average_K H_K.          (T4)

The low indicator is 1_{K>h0}; its exact average is one minus

    min(1,max(0,log(h0/K0)/log2)),

with high-average zero when h0≤K0 and one when h0≥2K0. The averaged high-bad terminal factor in H_K is

    max(0,log[min(2K0,h0,S_u)/K0])/log2,

under the same safe U>K0 convention. These are original terminal tests, not two-score substitutes for H_K itself.

A proved low-branch price C_low(K) must be averaged with its actual K dependence, or bounded uniformly over the window. The branch sets are monotone, so T_low,K≤T_low,2K0, but the K0 price cannot be retained without a uniform theorem. JG1–6 does not itself specify an input-budget formula for this low term, so no such price is invented here.

More generally a fixed uniform source cost C K^r has mean C K0^r(2^r−1)/(r log2) (or C for r=0). Such an assertion requires the rest of that cost to be truly uniform in K. Every later positive payment, source selection and signed reserve affected by K must be rebuilt or retained as a full indexed family, including finite-endpoint qualifications. Negative credit from the old K0 ledger cannot be subtracted again from this new averaged positive family. One may instead work directly with (T4) or select one global threshold from a properly bounded full family; neither operation grants a receiver/sourcewise threshold menu.

This is a valid possible upstream strategy, not an already completed estimate for the current P_(K0), its source total or the general weak-type goal.

## 5. Actual bounded numerical check

Executed 28 ordinary mpmath40 integrals: 14 threshold configurations, each with coefficient 1 and sqrt(K), including endpoint, zero-high and infinite-S cases. Direct piecewise integration matched the exact formulas within 1e-35. These are finite non-interval calculus checks, not FIRST/tree/FULL evidence. Code:

```python
import mpmath as mp
mp.mp.dps=40
I=mp.inf
cases=[(0,I,I),(1,mp.mpf('1.01'),I),(1,1,I),(2,I,I),(I,I,I),
       (0,1,I),(0,I,0),(0,I,1),(0,I,mp.mpf('1.5')),
       (mp.mpf('1.2'),2,mp.mpf('1.6')),
       (mp.mpf('1.5'),mp.mpf('1.2'),I),(0,2,2),
       (mp.mpf('1.5'),I,mp.mpf('.9')),(mp.mpf('1.5'),I,I)]
count=0
for v,u,h in cases:
    cuts=sorted(set([mp.mpf(1),mp.mpf(2)]+
                    [x for x in (v,u,h) if mp.isfinite(x) and 1<x<2]))
    L=max(mp.mpf(1),v);U=min(mp.mpf(2),u,h)
    for power in (mp.mpf(0),mp.mpf('.5')):
        direct=mp.fsum(mp.quad(lambda K:K**(power-1),[lo,hi])
                      for lo,hi in zip(cuts,cuts[1:])
                      if v<=(lo+hi)/2<u and (lo+hi)/2<=h)/mp.log(2)
        closed=((mp.log(U/L)/mp.log(2) if power==0 else
                 (U**power-L**power)/(power*mp.log(2)))
                if U>L else mp.mpf(0))
        assert abs(direct-closed)<mp.mpf('1e-35')
        count+=1
print('PASS',count,'ordinary mp40 threshold-window integrals')
```

# Independent addendum: removing the hard/soft log jump and the actual three-target ratio

**Verdict: PASS; constant 3 suffices in place of the proposed 5.** This kernel statement was independently checked after the threshold screen above was saved, before reading an author proof. It supplies a geometric inequality, not the missing global source budget.

## A. One-dimensional boundary-corrected logarithm

Use the original h=1_[-1/2,1/2], w(r)=integral_0^1 exp(−|r|/u)du, φ=h*w and f_s=(1−s)h+sφ. For 0<s≤1 put

    j_s=log[(1−s+sφ(1/2))/(sφ(1/2))]≥0,
    F_s(r)=log f_s(r)−j_s h(r).

At r=±1/2, the specified closed hard indicator gives

    F_s(±1/2)=log[sφ(1/2)],

which equals the exterior limit and the corrected interior limit. Thus the jumps are exactly removed, including both boundary points, not merely almost everywhere.

A self-contained global bound is as follows. The even radial φ decreases on [0,infinity), and

    φ(1/2)=1/2−integral_0^1 u exp(−1/u)du
       ≥1/2−1/(3e)>1/3,

because exp(−1/u)≤u/e for 0<u≤1. On |r|≤1/2, φ(r)≥φ(1/2) and |φ'(r)|≤1 from the sliding-window derivative w(r+1/2)−w(r−1/2). Consequently |(logφ)'|<3 there.

On r=1/2+d, d≥0,

    φ(1/2+d)=integral_0^1 u(1−exp(−1/u)) exp(−d/u)du.

This positive Laplace mixture is log-convex, so its logarithmic hazard is nonincreasing in d and its initial value is at most 1/φ(1/2)<3. The same bound holds on the negative side by evenness. This argument may be made first at d>0 and then by the finite initial first-moment limit; no finite second moment at d=0 is assumed.

Inside the hard core,

    |F_s'|=|sφ'/(1−s+sφ)|≤|φ'/φ|<3;

outside it F_s'=φ'/φ. The continuous gluing at both boundaries proves **global 3-Lipschitz continuity** of F_s. In particular the candidate global 5 bound is valid but weaker. For s=1, j_s=0 and this is simply logφ.

## B. Tensor product, oriented core count and weighted mixture

Fix an actual receiver x and one physical scale A. Let

    kappa_A(x,v)=sum_i 1_{|x_i−v_i|≤A/2}.

The exact decomposition is

    log P_(s,A)(x−v)=−nlog A
       +sum_i F_s((x_i−v_i)/A)+j_s kappa_A(x,v).

Thus for finite centers u,v and s>0,

    log[K_A(v)/K_A(u)]
       ≤3||v−u||_1/A
          +j_s[kappa_A(x,v)−kappa_A(x,u)].              (K1)

The physical density normalization cancels because the comparison is at the same A within each component. The core-count difference is oriented and signed; an unsigned count of coordinate crossings is neither needed nor substituted.

For the actual three components A_1=L, A_2=Lplus=min(b,γL), A_3=b, with common s on components 1,2 and full-soft component 3, put

    delta_kappa_j=kappa_(A_j)(x,v)−kappa_(A_j)(x,u), j=1,2,
    delta_kappa_3=0,
    omega_j=K_j(x,u)/K_Sigma(x,u).

For s>0 these weights are defined, nonnegative and sum to one; the J component has j_1=0. Componentwise (K1) and positive summation give the sharper actual mixture inequality

    Q_x*(v)/Q_x*(u)
       ≤sum_(j=1)^3 omega_j
          exp[3||v−u||_1/A_j+j_s delta_kappa_j].        (K2)

The common normalization 1/3 cancels; there is no factor three or parameter-menu price. This is only a component responsibility at the fixed source point u, not an actual Π law, a new source FIRST, or a free threshold choice.

In particular, with

    Mplus=max(0,delta_kappa_1,delta_kappa_2),

    log[Q_x*(v)/Q_x*(u)]
       ≤3||v−u||_1/a+j_s Mplus.                        (K3)

The zero in this maximum is necessary because fixed J has no hard jump. If both moving counts decrease, their negative jump benefit cannot automatically be assigned to J.

## C. Exact zero-soft scope and original terminal weight

The stated finite F_s and j_s formulas require **s>0**. At s=0, f_0 vanishes outside the hard core, j_s diverges and there is no finite global log f_0−j_0h identity. No undefined zero times infinity is to be inserted into (K2).

For the actual three-target sum, however, J=P_(1,b)>0 at every finite center, so Q_x* at s=0 is positive and is the continuous limit of Q_x* for positive s. If Mplus=0, (K3) has no j_s term for every positive s and passes to a finite bound at s=0. If Mplus>0, its direct limit is the trivial infinite upper bound. A weighted zero-soft formula must instead take the limit of the entire positive-s expression, including omega_j, or work from the original components; components that vanish at u cannot be assigned an arbitrary 0 times infinity value. The original actual soft-margin qualification is not removed by this auxiliary limiting observation. Actual rows with p_y=0 contribute zero before defining S.

For the original pure terminal weight anchored at y, logLip6 of C and the clamp give

    |log w_g(y,v)−log w_g(y,u)|≤6||v−u||_1/b.

Thus for positive finite actual S=p_y w_g/Q_x*,

    log[S(u)/S(v)]
       ≤(6/b+3/a)||v−u||_1+j_s Mplus.                  (K4)

This has the direction needed for a good-v/bad-u threshold crossing. It can be combined with the exact exposed log interval in (T2), but neither the distance between the two auxiliary terminal sources nor their oriented core counts are made small by the unrelated original near condition on hard z and soft y. No general root-order integrated bound follows merely from (K4).

## D. Actually executed bounded kernel checks

Executed ordinary mpmath at 50 dps: 40 one-dimensional corrected-log checks including both sides and the exact hard boundaries, and 27 true tensor three-target weighted-ratio/max-count checks at n=1,2,3. They passed with tolerance 1e-42. These finite non-interval tests do not prove the global Lipschitz theorem or certify FIRST/FULL instances; the proof is above. Exact executed code:

```python
import mpmath as m
m.mp.dps=50
E=lambda k,x:m.expint(k,x)
def phi(x):
    x=abs(x)
    return (E(3,x-m.mpf('.5'))-E(3,x+m.mpf('.5')) if x>=m.mpf('.5')
            else 1-E(3,m.mpf('.5')-x)-E(3,m.mpf('.5')+x))
def fs(x,s):
    return (1-s)*int(abs(x)<=m.mpf('.5'))+s*phi(x)
x=[m.mpf(t) for t in ('-2','-.500001','-.5','-.499999','0',
                      '.499999','.5','.500001','2')]
scalar=0
for s in (m.mpf('1e-20'),m.mpf('.001'),m.mpf('.1'),m.mpf('.5'),m.mpf(1)):
    j=m.log((1-s+s*phi(m.mpf('.5')))/(s*phi(m.mpf('.5'))))
    vals=[m.log(fs(t,s))-j*int(abs(t)<=m.mpf('.5')) for t in x]
    for a,b,fa,fb in zip(x,x[1:],vals,vals[1:]):
        assert abs(fa-fb)<=3*(b-a)+m.mpf('1e-42')
        scalar+=1
tensor=0
for n in (1,2,3):
    scales=[m.mpf(1),min(m.mpf(2),1+m.mpf(1)/n),m.mpf(2)]
    pairs=[([m.mpf('.5') if i%2==0 else m.mpf('1.5') for i in range(n)],
            [m.mpf('.50001') if i%2==0 else m.mpf('.25') for i in range(n)]),
           ([m.mpf('.2')]*n,[m.mpf('2.1')]*n),
           ([m.mpf('1.2')]*n,[m.mpf('.8')]*n)]
    for s in (m.mpf('.01'),m.mpf('.5'),m.mpf(1)):
        j=m.log((1-s+s*phi(m.mpf('.5')))/(s*phi(m.mpf('.5'))))
        for v,u in pairs:
            d=sum(abs(a-b) for a,b in zip(v,u));sig=[s,s,m.mpf(1)]
            P=lambda z,A,ss:A**(-n)*m.fprod(fs(t/A,ss) for t in z)
            V=[P(v,A,ss) for A,ss in zip(scales,sig)]
            U=[P(u,A,ss) for A,ss in zip(scales,sig)]
            dk=[sum(abs(t)<=A/2 for t in v)-sum(abs(t)<=A/2 for t in u)
                if k<2 else 0 for k,A in enumerate(scales)]
            weighted=sum(U[k]/sum(U)*m.exp(3*d/scales[k]+j*dk[k])
                         for k in range(3))
            assert sum(V)/sum(U)<=weighted*(1+m.mpf('1e-42'))
            assert m.log(sum(V)/sum(U))<=3*d+j*max(0,*dk)+m.mpf('1e-42')
            tensor+=1
print('PASS',scalar,'ordinary mp50 boundary/Lip3 checks and',tensor,
      'true tensor weighted-ratio checks')
```
