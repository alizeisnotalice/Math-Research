from pathlib import Path
import json,hashlib,importlib.util
from fractions import Fraction as Q
b=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('numeric_fixed',b/'numeric.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
d=json.loads((b/'numeric_original.json').read_text());old=next(x for x in d['results'] if x['n']==32 and x['c']==.5)
r=m.task(32,.5)
assert r['status']=='complete' and r['quadrature']['inner_failures']==0
assert all(a['gate']==c['gate'] for a,c in zip(r['gates'],old['gates']))
cert=json.loads((b/'certificate_original.json').read_text());rep=json.loads((b/'certificate_replay.json').read_text())
for k in ('alpha','log2_lower','log2_upper','rational_upper_bound','pair_tests'):
 assert cert[k]==rep[k],k
q=Q(*map(int,cert['rational_upper_bound']));assert 4*q<Q(1,16)
loghi=Q(*map(int,cert['log2_upper']));loglo=Q(*map(int,cert['log2_lower']))
assert 4*loghi+Q(1,16)+Q(1,2**24)<3
assert 36*loglo>24
out={'single_case_n32_c05':'all gates equal; zero inner failures','certificate_exact_fields':'identical','fourfold_tail_lt_1_16':True,'active_mass_lt_3n':True,'log_n_gt_24_at_2pow36':True,'scope':'No full production rerun or finite-history numerical construction.'}
(b/'verification_receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
