# R628 独立审计：全壳平均与静态row资格

日期：2026-10-28。先独立核准确命题，未读其它作者稿；只写本文件，不改repo、不启动Agent或实例扫描。两次本机SymPy/Fraction仅核尾项指数及split常数；所有概率/几何结论如下解析证明。

## 1. 结论与量词

给定n≥3、t≥2、ν(dz)=2^(−n)max(1,||z||∞)^(−n)1{||z||∞<t}dz，总质量S=1+nlog t，κ≤1+1/t。非平凡情形取κ>0；κ≤0时capture为空。对

R_ν(w)=∫1{||z−w||∞<κ max(1,||z||∞)}dν(z)，

题给signed-face平均及Markov界成立。split16版本更强：c∈[1/2,1]可随n变化，t=n/(c log n)，任意τ≥1时，ν{R_ν>τ}=O(n)统一成立。它覆盖此参数区间内的全部阈值选择，不仅旧固定τ尺度。

静态证书上界及大质量低row见证也成立。后续§§11–13另独审并通过了固定n、足够大a下的真实finite greedy history生成桥：单点uncaptured load可为Ω(nlog n)。该结论只限制任意supplied-family的这一点态load方法，不能否定自适应witness选择、其它packing或保留bad-star slack的母目标。

## 2. Shell法则及pin坐标

ν在unit cube内质量1，条件分布为完整unit cube均匀分布；其余半径ρ∈[1,t)的径向质量为n dρ/ρ。固定ρ的条件分布是2n个signed faces的均匀混合：某坐标固定为±ρ，其余n−1坐标独立uniform [−ρ,ρ]。这是cube体积导数n2^nρ^(n−1)乘density 2^(−n)ρ^(−n)的结果；多face交界在此条件surface measure下零测。

固定target半径r∈[2,t]及任一signed face，target另有一个pin坐标。source与target条件独立；忽略source pin及target pin，最多忽略两个坐标。其余至少n−2对坐标均为相互独立的uniform pair。两个pins相同则实际有n−1对，忽略一对仍给所需上界。core source没有pin，实际n−1对也可放松到n−2对。不能把pins本身误当independent uniforms，但本证明完全不使用其capture概率。

## 3. 单坐标概率：单调与精确常数

先用κ≤κ_max=1+1/t，把capture半径放大到κ_maxρ。写source自由坐标Z=ρU、U uniform [−1,1]，target自由坐标W uniform [−r,r]。对每个U，capture条件W∈ρ(U−κ_max,U+κ_max)；因κ_max>1，该区间包含0且随ρ增加嵌套。因此自由pair捕获概率随ρ非减，可统一用ρ=t上界。

在ρ=t时capture半径为t+1。对r∈[2,t]，矩形[−t,t]×[−r,r]中两块未捕获三角形的总面积为(r−1)^2，故精确概率为

p_t(r)=1−(r−1)^2/(4rt)。

同一κ_max下core的ρ=1自由概率也不大于此值。对free coordinates相乘并对全部source components积分，得到每个固定target signed face的均匀平均

Avg_face R_ν ≤ S[p_t(r)]^(n−2)。                 (F)

严格开边界不改变自由pair的二维面积；被忽略的pin即使碰到等号，也只使真实capture更小。

## 4. 一般split及旧阈值尺度

对任意固定R∈[2,t]，(r−1)^2/r随r≥R递增，(F)给

ν{R_ν>τ} ≤ 1+nlog R
 +[nS log(t/R)/τ] exp[−(n−2)(R−1)^2/(4Rt)]，τ>0。  (M_R)

第一项是全部inner target质量；outer target用n dr/r和facewise Markov，再用1−a≤e^(−a)。R=2时失配系数为1/8，恰给题设

1+nlog2+[nS log(t/2)/τ]exp[−(n−2)/(8t)]。

当t=n/(c log n)、c>4/5固定，τ≥a_0 n^((1+c)/2)sqrt(log n)、a_0>0固定时，S=O(nlog n)，此尾项为

O(n^(3/2−5c/8)(log n)^(3/2))=o(n)。

本机SymPy实际核验指数3/2−5c/8及其减1为1/2−5c/8；c>4/5是这个粗split2推法的严格条件。c=4/5不由此得到o(n)。此旧条件不是最终所有root选参的限制，因为可以换split。

## 5. Split16：c与τ统一的更强结论

若t>16，(M_R)取R=16，得到

ν{R_ν>τ} ≤ 1+nlog16
 +[nS log(t/16)/τ]exp[−225(n−2)/(64t)]。          (M_16)

现在令c=c_n∈[1/2,1]任意、t=n/(c log n)、τ=τ_n≥1任意。统一有S=O(nlog n)、log(t/16)=O(log n)，且

exp[−225(n−2)/(64t)]
 =n^(−225c/64)exp[O(log n/n)]
 ≤(1+o(1))n^(−225/128)。

因此尾项统一为O(n^(31/128)(log n)^2)=o(n)，除以n后的指数是−97/128。本机Fraction实际核验了225/64、225/128、31/128及−97/128。这里o(n)对全部c∈[1/2,1]、τ≥1统一，不需要c固定或τ满足旧幂次下界。

t≤16时直接用ν总量S≤1+nlog16，不使用负的log(t/16)。所以在整个所述参数族内，高row质量O(n)；若t>16随n增长，更具体为1+nlog16+o(n)。这阻止只通过调整这些τ参数逃离全壳静态上界，但不涉及真实history约束。

## 6. 正kernel证书上界

设K为非负kernel，确有R_K≤R_ν，且同一个有限常数D_max>0满足R_K≤D_max于相关ν-a.e.位置。对任意可测A，

(∫_A(R_K−τ)dν)_+/D_max
 ≤∫_A(R_K−τ)_+dν/D_max
 ≤ν(A∩{R_K>τ})≤ν{R_ν>τ}。                    (C)

因此题给证书在split16参数族内统一O(n)。不需要A有任何独立性或shell均匀性。如果D_max=0，应将无正增益情形明确记为0，不能直接写0/0。若D_max只控制某个平均而不控制R_K，则(C)不适用。核因子0≤b≤1必须与同一capture方向相乘，或另证所述R_K≤R_ν；不可改变半径方向后仍沿用此支配。

## 7. 任意corner限制下的大质量静态见证

令λ=ν|D，D为原corner的任意可测子域，B=λ(R^n)。在完整ν上估计高row集合，定义

G={w:R_ν(w)≤τ}，μ=λ|G。

则μ≤λ≤ν，且μ(R^n)≥B−ν{R_ν>τ}≥B−O(n)，统一于上述c、τ与D。没有把D条件化后再假设shell/free坐标独立；shell平均只对完整ν使用。D=全域时即μ质量≥S−O(n)。B本身若只有O(n)，该下界可无实质；B≫n时才是大比例保留。

对fixed z，capture是w的开集，故R_ν关于w下半连续，G为闭集。μ集中于G，甚至其拓扑support也包含于G。因此每个w∈supp μ上，同方向capture满足

∫1{||z−w||∞<κ max(1,||z||∞)}dμ(z)
 ≤R_ν(w)≤τ。

这使“支持上”说法严格成立，而不止μ-a.e.。但半径仍由积分变量z决定；不能换成κ max(1,||w||∞)而声称同一row资格。若要所有κ≤1+1/t共同成立，可直接用κ_max构造G，一次保留即可。

## 8. 精确限制与最终结论

本节保留生成桥到达前的独立阶段记录；最终判决见§§12–14，已另核实际histories，不能把本节读成最终仍仅静态。

上述给的是静态row-eligible relaxation的真实可行测度见证及该类positive证书的上限。全壳独立free坐标、μ≤λ及低capture没有编码actual r_i与||z_i||的关系，也没有构造真实增量的体积/不交分配、共同selection次序或同history缺失测度。这些额外几何条件是否排除本见证，必须在实际合同中另证。

所以不能把全壳多环带静态优化的失败升格为母weaktype/root目标的反例，也不能将保留角域D后的source分布假装仍有原shell条件独立。通过范围是(F)、一般Markov split、两种参数尺度、uniform split16、证书(C)及同方向静态见证；没有一般新上界或真实history闭合。审查完成，停止。

## 9. 显式n阈值与算术证书：解析前提也独立核清

现只读`/tmp/ccu_r628_certificate.py/.json/.md`，并独立只读重放其有理基点算术；未运行会写共享JSON的原脚本。当前脚本SHA与JSON记录一致。有理界约0.0029278795984734735，精确小于1/16；本次未另运行其Arb或63个有限pair检查，这些也不是一般壳层证明的替代。

证书明示的解析前提可由本审计(M_16)独立推出。n≥2^24、c∈[1/2,1]、τ≥1时，t>16且t≤n，故S≤2nlog n、log(t/16)≤log n；同时(n−2)/n≥63/64。因此若E为(M_16)的尾项，

E/n≤2(log n)^2 exp[−α log n]，
α=(225/128)(63/64)−1=5983/8192。

令L=log n，2L²e^(−αL)在αL>2时递减。证书以log2的正atanh级数给有理上下界、以61项正exp级数给分母下界；方向正确。本次Fraction独立重建该分数并与JSON精确相等，且核验α·24log2_lower>2。所以对全部n≥2^24，确有E/n<1/16，不只是有限维采样。

同次Fraction核验4log2_upper<3−1/16−2^(−24)。结合1/n≤2^(−24)，得到统一严格界

ν{R_ν>τ}<3n，n≥2^24、c∈[1/2,1]、τ≥1。        (H3)

此结论仍对全部κ≤1+1/t成立；不是以D的条件分布替代完整ν得到。

## 10. 原corner的Ω(nlog n)静态质量

取题给具体corner

D={||z||∞<t:存在i，z_i<1−(1+1/t)max(1,||z||∞)}，
λ=ν|D，B=λ(R^n)。

对任意ρ∈(1,t)的每个negative maximal face，某坐标z_i=−ρ，且

−ρ<1−(1+1/t)ρ ⇔ ρ<t。

所以该face全部在D。negative signed faces占全部shell条件质量的一半，径向积分严格给

B≥(n/2)log t。

c≤1给t≥n/log n。令L=log n，L/2−log L的最小值为1−log2>0，故loglog n≤(1/2)log n，进而

B≥(n/4)log n。

用同一个(H3)定义μ=λ|{R_ν≤τ}，得到

μ(R^n)≥(n/4)log n−3n≥(n/8)log n，n≥2^36。    (W)

本次有理重放也核验36log2_lower>24，所以最后的维数阈值充分。实际因高row严格<3n且log n>24，还可取严格大于；弱不等式已够。

这给出一个量级明确的静态见证：可直接在τ=1就有Ω(nlog n)质量、同方向support-row capture≤1；对所有τ≥1也成立。所述模型约束本身因此不能强迫此总capbudget只有O(√n log^A n)，A固定，或把正kernel证书(C)提升到能消除该剩余质量的更强结论。这是对**该静态模型的后果**的限制；若另有τ相关不同目标函数或额外history约束，必须重新列合同，不能由(W)作超范围否定。

截至本节完成时，尚未收到实际finite-history或同一原f的finite bad-witness实现证明；这属于阶段性记录，后续§§12–13已独立通过此生成桥。尤其(W)不能被表述成原cube maximal算子的Ω(nlog n)弱型下界，也不是R559母账的反例。新增算术/质量审查完成，无决定性错误；actual-history可实现性不能从静态见证自动继承，故后续另行审核。

## 11. τ/4与strict低row区域的四倍尾费

按根代理新任务只读重放JSON中的有理bound，精确检查4·bound<1/16；其近似值为0.011711518393893894。Markov证明同样适用于{R_ν≥q}，故strict低row区域的补集不需要假设level-set零测。

当n≥2^24、τ≥1、c∈[1/2,1]时，外壳||w||>16上的{R_ν≥τ/4}质量至多4E<n/16。于是

ν(D∩{||w||>16}∩{R_ν<τ/4})
 ≥B−1−nlog16−4E>B−3n。                       (Kmass)

这里inner质量只扣一次，不能再把包含inner的完整高row界额外扣一次。渐近式为B−1−nlog16−o(n)。这补足了生成候选所需的低row阈值，而非错误沿用τ时的尾费。

## 12. 实际history生成：独立核对原合同后通过

现独审`/tmp/ccu_r628_global.md`§3。已读取根代理指定的原规范`/Users/zhengzhihao/Math-Research-centered-cube-work/cube-dim-7-bounds/upper/round028/cap_candidate/sources/author.md`§§2–4：I_i=B_i\∪_(h<i)B_h，w_i=|I_i|/(2aR_i)^n，选择最大半径的remaining eligible cube，累计center资格≤τ。该规范只要求给定supplied finite family，不要求同时处理同一f的全部bad cubes。

固定n,t,K后，ε=a^(−1/2)、α=a/(a+1)，R(w)=(1+ε)m(w)/α，scaled J(w)=Q(w,R(w)/(a+1))，a足够大且a>2t。紧K⊂D、||w||>16给正边界裕量，故全部R(w)<t、J(w)⊂D∩{||z||>1}，且R(w)>16。每个原a-star含0严格。J(w)为K的open cover，有限subcover之后可按R_i非增排列；cover数量可依a变化，不需固定family随a收敛。

scaled真实increments E_i=J_i\∪_(h<i)J_h确是原increment经(a+1)缩放所得，密度

dμ_a/dz=α^(−n)(2R_i)^(−n)，
dμ_a/dν=[m(z)/((1+ε)m(w_i))]^n。

利用m的1-Lipschitz，精确上下界为[1/(1+ε)±1/a]^n。ε≥1/(a−1)在大a成立，使上界≤1，故μ_a≤ν；下界→1且不含cover数量或index。union J覆盖K，因而μ_a总量≥ν(K)−η可达；R_i/m(z)也在所有increment pieces上一致趋1。有限a的λ_a=α^(−n)ν|D给密度(m(z)/R_i)^n，与原tag合同一致。这是实际increment密度控制，不是原f密度帽。

捕获source center w_i的b-star若含candidate center w_j，则每个z∈E_i都在target w_j的κ_eff m(z)范围内，

κ_eff=(1+ε)(aβ+1)/(a−1−ε)→β。

代数正确。κ>1时capture边界在m的有限affine pieces上为非退化超平面，ν零测，故R_ν^κ(w)联合连续。紧K上的R_ν^β<τ/4遂给大a下统一R_ν^(κ_eff)<τ/2。由于任意prefix的实际increment measure都≤ν且pieces不交，**完整累计**资格和≤这一ambient row bound；没有逐pair累加或提前使用future冻结权重。故全部remaining cover cubes一直eligible，原max-radius算法确按所述排序选完，零increment项可保留。

末witness半径1、scaled center w_*=α(1−ε)1，a-star严格含0。K的corner gap ||w−1||−βm(w)>0在紧集上有统一正下界，故大a时||w_i−w_*||>αβR_i，最后center对全部此前b-stars uncaptured，所有prefix下亦eligible。由aβR_i>R_i+1，该间距还大于两small-cube scaled半径之和，末small cube与此前union不交、自增量正。它是唯一最小正贡献radius1 witness，其self weight=a^(−n)。以前各star均在0贡献，且全为该witness的uncaptured previous terms。

因此作者生成命题在所读原算法下成立：实际历史的此前uncaptured load等于μ_a总量，可任意接近ν(K)。结合(Kmass)及corner B下界，得到该大a、固定n构造的Ω(nlog n)实际单点load。a的选取依赖n,t,K及裕量；没有维数统一a阈值、固定family极限或所有参数的最优性结论。

## 13. 同一真实f与最终量词边界

有限全部a-stars严格含0，其交含正体积邻域U。取mass F>P max_i|aB_i|的非负L1 bump在U内，则所有supplied a-stars真实平均>1，甚至全部supplied small cubes以radius(a+1)R_i检验都在{M_nf>1}。所以真实f的有限bad-witness family可实现性也通过；无需原f density cap。但f与μ_a不同，F可极大。

这里证明的是：**对任意supplied finite family都要求成立的该greedy单点load上界**，不能仅凭现有center资格、近最小actual-radius tag及真实increment生成规则改成root。它不排除给定同一f后自适应选择另一套更有利的witness family，也不排除对完整finite family寻找另一packing，而非使用此greedy权。不可把“存在坏的supplied family”换成“所有适应f的family都坏”。

原f的真实slack须保留。对上述共同星交输入，h_i=F/|aB_i|，W(0)=Σw_i，V_tot=Σv_i，有

∫fW=F W(0)，
D_f=Σv_i(h_i−1)=F W(0)−V_tot，
V_tot=∫fW−D_f。

所以大W(0)可伴随同量级甚至几乎全部抵消的bad-star slack，不能推出V_tot/F大，不能称weaklower，更不能否定一般root finitepacking/weaktype目标或R559完整母账。作者当前稿保留了这些界限。

终审判断：新增实际history生成桥、所有prefix资格、末corner与同f有限bad-family实现通过，无决定性数学错误。新增严格结论限于该supplied-family、大a单点load方法的障碍；一般root目标仍开放。本次仅做指定可实现性审查和一次四倍有理检查，无实例扫描或新Agent，停止。

归档措辞补充：作者§2(5)若写作K(w,z)≤g(w)capture及excess R_K−τg，应显式要求g≥0、Dmax>0（或零增益时作零约定）。在此自然的正row-normalization条件下，同§6的正excess证明完整成立；不宜省略这些条件后声称适用于任意signed g。

## 14. 最终整合REPORT的定点连接核验

只读核对`/tmp/ccu_r628_bundle/REPORT.tex`的最终scope及式(5)–(8)、(14)–(15)，未重复全证。归档版已明确g≥0、Dmax>0及零收益零约定，解决§13的措辞条件。

q=τ/4≥1/4给外壳尾费≤4E，certificate四倍有理界严格<1/16，故inner加outer高row总费<3n；用于strict低row开区域时正确使用其≥补集。负faces质量、内正则性和真实生成定理串接后，式(14)的sup W_uncaptured(0)≥B−3n≥nlogn/8成立。sup包含允许充分大a及相应finite families；准确量词是每个误差η>0可选择a及一个有限族，而不是某一固定family自身再取极限，也不是对每个fixed a均已证明同一结论。报告文字“每个有限族可任意逼近”宜读/改为“可用一列有限族任意逼近”，不能作∀固定family的断言。

式(15)对任意有限selected history严格来自∫fW=Σv_i h_i，故Σv_i=∫fW−Σv_i(h_i−1)。共同星交输入确有∫fW=F W(0)、Df=F W(0)−Σv_i，且每个hi>1。此正slack可抵消高单点load；报告没有据此声称弱型下界，也没有把任意supplied-family的坏history升级为“同一f的所有可选witness families都坏”。其它packing、合法输入依赖选择及保留slack/覆盖重复的共同估计仍开放。

**最终审查状态：已核并通过实际finite greedy histories的近满载生成，不再仅是静态见证。** 限制的是所述t、τ范围及固定n后足够大a下、对全部supplied finite families统一的单点load付款方法。一般root weaktype/finitepacking、R559母账及R626 receiver lower均未闭合。§8、§10先静态后history的过程已保留并标明阶段性。最终归档连接核验完成，停止。
