import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,ctypes,hashlib,json,math,platform,shlex,sys,time,warnings,resource
from pathlib import Path
import numpy as np,scipy
from scipy.integrate import quad,quad_vec,IntegrationWarning
ABS=1e-9;REL=2e-7

def free(rho,r,kappa):
 L=kappa*rho;aa=max(0.,rho+r-L);bb=max(0.,abs(rho-r)-L);tail=(aa-bb)*(aa+bb)/(4*rho*r);return min(1.,max(0.,1-tail))
def pinned(rho,r,kappa):
 L=kappa*rho
 # The intersection length of [-1,1] with the corresponding linear condition.
 g=max(0.,min(1.,(rho+L)/r)-max(-1.,(rho-L)/r))/2
 h=max(0.,min(1.,(r+L)/rho)-max(-1.,(r-L)/rho))/2
 j=.5*(int(abs(rho-r)<L)+int(rho+r<L));return g,h,j

def calculate_m(n,t,r,stats):
 k=1+1/t
 def power(p,exponent):
  if p<=0:return 0.
  z=exponent*math.log(p)
  if z<math.log(np.finfo(float).tiny):stats['underflow_terms']+=1
  return math.exp(z) if z>-745 else 0.
 p=free(1.,r,k);g,h,j=pinned(1.,r,k);inner=h*power(p,n-1)
 def f(v):
  rho=math.exp(v);p=free(rho,r,k);g,h,j=pinned(rho,r,k)
  return (j/n)*power(p,n-1)+(1-1/n)*g*h*power(p,n-2)
 pts=[];q=r/(k+1)
 if 1<q<t:pts=[math.log(q)]
 result,err,info=quad(f,0,math.log(t),points=pts,epsabs=ABS/max(1,n),epsrel=REL,limit=250,full_output=1)[:3]
 stats['source_quad_evals']+=info['neval'];stats['max_source_estimated_error']=max(stats['max_source_estimated_error'],n*err);stats['m_evaluations']+=1
 return inner+n*result,inner,n*err

def task(n,c):
 start=time.monotonic();cpu=time.process_time();t=n/(c*math.log(n));tau0=n**((1+c)/2)*math.sqrt(math.log(n));S=1+n*math.log(t)
 if t<2:return {'n':n,'c':c,'t':t,'status':'skipped_t_lt_2'}
 thresholds=np.array([1.,math.sqrt(n),tau0]);stats={'source_quad_evals':0,'m_evaluations':0,'max_source_estimated_error':0.,'underflow_terms':0}
 def f(v):
  r=math.exp(v);m,_,_=calculate_m(n,t,r,stats);g=np.minimum(1.,m/thresholds);return np.r_[g,g if r>=16 else np.zeros(3)]
 left=math.log(2);right=math.log(t);pts=[left+v/n for v in (1,4,16,64,256,1024) if left+v/n<right]
 if 2<16<t:pts.append(math.log(16))
 pts=sorted(set(pts))
 q,err,info=quad_vec(f,left,right,points=pts,epsabs=ABS/max(n,1),epsrel=REL,limit=300,norm='max',full_output=True)
 gate=n*q[:3];tail=n*q[3:];rows=[]
 for k,tau in enumerate(thresholds):
  coarse=n*(right-left)*min(1.,S/tau);tailbound=0. if t<=16 else n*S*math.log(t/16)*math.exp(-(n-2)*225/(64*t))/tau
  rows.append({'label':('one','sqrt_n','tau0')[k],'tau':float(tau),'gate':float(gate[k]),'gate_over_n':float(gate[k]/n),'gate_over_S':float(gate[k]/S),'coarse_gate':float(coarse),'tail16':float(tail[k]),'middle_2_to_16':float(gate[k]-tail[k]),'high_row_numerical_full':float(min(S,1+n*math.log(2)+gate[k])),'high_row_safe_bound':float(min(S,1+n*math.log(min(t,16))+tailbound)),'candidate_analytic_tail16':tailbound})
 probes=[]
 for r in (2.,math.sqrt(2*t),t):
  m,inn,e=calculate_m(n,t,r,stats);ratio=((r-1)**2)/(4*r*t);upper=S*math.exp((n-2)*math.log1p(-ratio));probes.append({'r':r,'m':m,'inner':inn,'m_error_estimate':e,'candidate_upper':upper,'relative_upper_gap':(upper-m)/upper if upper else None})
 return {'n':n,'c':c,'t':t,'tau0':tau0,'S':S,'status':'complete','gates':rows,'outer_quad_estimated_max_abs_error':n*float(err),'outer_quad_evals':info.neval,'outer_quad_success':bool(info.success),'outer_quad_status':info.status,'quadrature':stats,'probes':probes,'elapsed_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def pilot(n,c):
 t=n/(c*math.log(n));k=1+1/t;stats={'source_quad_evals':0,'m_evaluations':0,'max_source_estimated_error':0.,'underflow_terms':0};out=[]
 for r in (2.,math.sqrt(2*t),t):
  for rho in (1.,(1+t)/2,t):
   p=free(rho,r,k);L=k*rho
   def slice_prob(u):return max(0.,min(1.,(rho*u+L)/r)-max(-1.,(rho*u-L)/r))/2
   # Independent 1-D integration over U of the exact V interval.
   pts=sorted(set(v for v in [(-r-L)/rho,(-r+L)/rho,(r-L)/rho,(r+L)/rho] if -1<v<1));q,e=quad(slice_prob,-1,1,points=pts,epsabs=1e-12,epsrel=1e-12,limit=200);q/=2
   out.append({'r':r,'rho':rho,'p_formula':p,'p_quad':q,'abs_difference':abs(p-q),'quad_error':e/2})
  m,inn,e=calculate_m(n,t,r,stats);upper=(1+n*math.log(t))*math.exp((n-2)*math.log1p(-(r-1)**2/(4*r*t)));out[-1]['m']=m;out[-1]['candidate_upper']=upper
 return {'n':n,'c':c,'t':t,'checks':out,'stats':stats}

def ticks():
 lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib');v=(ctypes.c_uint32*4)();c=ctypes.c_uint32(4);return list(v) if lib.host_statistics(lib.mach_host_self(),3,v,ctypes.byref(c))==0 else None

def main():
 p=argparse.ArgumentParser();p.add_argument('--phase',choices=('pilot','full'),required=True);p.add_argument('--workers',type=int,default=14);p.add_argument('--output-dir',type=Path,default=Path('/tmp'));a=p.parse_args();assert 1<=a.workers<=14;a.output_dir.mkdir(parents=True,exist_ok=True);path=a.output_dir/'ccu_r628_numeric.json';md=a.output_dir/'ccu_r628_numeric.md';start=time.monotonic()
 if a.phase=='pilot':out={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'commands':[shlex.join([sys.executable]+sys.argv)],'quad_tolerances':{'epsabs':ABS,'epsrel':REL},'pilot':[pilot(n,.93) for n in (7,32)],'results':[],'resource_samples':[]};path.write_text(json.dumps(out));print('pilot max p difference',max(q['abs_difference'] for v in out['pilot'] for q in v['checks']));print('probe upper violations',sum(q.get('m',0)>q.get('candidate_upper',float('inf')) for v in out['pilot'] for q in v['checks']));return
 out=json.loads(path.read_text());out['commands'].append(shlex.join([sys.executable]+sys.argv));tasks=[(n,c) for n in (32,128,512,2048,8192,65536) for c in (.5,.75,.97)];prev=ticks();last=time.monotonic()
 def save():
  path.write_text(json.dumps(out));L=['# R628 full-shell high-row gate','', 'The source shell integrates rho in [1,t], including the inner-cube term; the receiver gate covers r in [2,t]. Three model thresholds share each m(r) evaluation. τ0 is a prescribed model scale, not a certified covering parameter. Quadrature errors are floating estimates; underflowed terms are not claims of exact zero.','','| n | c | t | threshold | τ | gate | gate/n | tail r≥16 | middle 2–16 | coarse gate | S |','|---:|---:|---:|:---|---:|---:|---:|---:|---:|---:|---:|']
  for r in sorted(out['results'],key=lambda q:(q['n'],q['c'])):
   if r['status']=='complete':
    for q in r['gates']:L.append('| %d | %.2f | %.7g | %s | %.7g | %.8g | %.8g | %.8g | %.8g | %.8g | %.8g |'%(r['n'],r['c'],r['t'],q['label'],q['tau'],q['gate'],q['gate_over_n'],q['tail16'],q['middle_2_to_16'],q['coarse_gate'],r['S']))
   else:L.append(f"\nSkipped: {r}")
  L+=['','When the analytic tail is defined as r≥16, the complete crude high-row volume is at most 1+n log min(t,16)+tail, truncated by S. Omitting the 2–16 middle shell would be invalid. Inner and outer adaptive error estimates, function evaluations, underflow counts and resource samples are in JSON. No rigorous bound or asymptotic theorem is asserted from floating quadrature.'];md.write_text('\n'.join(L)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=min(a.workers,len(tasks))) as pool:
  pending={pool.submit(task,n,c) for n,c in tasks}
  while pending:
   done,pending=concurrent.futures.wait(pending,timeout=1,return_when=concurrent.futures.FIRST_COMPLETED)
   for f in done:
    r=f.result();out['results'].append(r);save();print('done',r['n'],r['c'],r['status'],flush=True)
   now=time.monotonic()
   if now-last>=1:
    tk=ticks();d=[(tk[i]-prev[i])%(1<<32) for i in range(4)];out['resource_samples'].append({'elapsed_seconds':now-start,'live_workers':sum(p.is_alive() for p in pool._processes.values()),'host_cpu_percent':100*(sum(d)-d[2])/sum(d) if sum(d) else None});prev=tk;last=now
 out['wall_seconds']=time.monotonic()-start;out['worker_cpu_sum_seconds']=sum(q.get('cpu_seconds',0) for q in out['results']);out['max_worker_rss_bytes']=max(q.get('peak_rss_bytes_macos',0) for q in out['results']);save()
if __name__=='__main__':main()
