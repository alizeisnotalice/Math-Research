# R628：全壳缺额证书的范围，以及近满载实际历史的生成桥

## 1. 原定义已核对；结论范围

原定义来源：

- `/tmp/ccu_r616_final/REPORT.tex` §1，第38–44行及其 witness 小节；
- `/Users/zhengzhihao/Desktop/T/Math-Research-cube-dim-7/cube-dim-7-bounds/upper/round028/cap_candidate/sources/author.md` §§2–4；
- 同仓库 `upper/round056/refined_inverse/PROOF.md` §§4–8。

真实算法从有限 open cubes B_i=Q(y_i,R_i) 中，反复选最大半径的 remaining eligible cube。实际增量、权重、资格准确为

  I_i=B_i\∪_{h<i}B_h， v_i=|I_i|，
  w_i=v_i/(2aR_i)^n，
  ∑_{i已选}w_i 1_{bB_i}(y_j)≤τ， b=aβ， β=1+1/t。        (1)

因此增量减的是先前已选 small cubes 的完整 union；资格使用已冻结的真实增量权重及实际 centers。零增量允许。本文不将静态 μ 代为原输入 f。

本轮结论不是一般弱型改进。下文首先独立核定全壳 positive capture certificate 仍只能支付 O(n)；继而给出一个实际生成命题：低 ambient row 的近满载静态区域，在固定 n,t 后可以由真实有限 greedy 历史近似实现，且实际 R_i/m(z)一致趋1。该命题限于上述已核算法；不声称产生弱型下界。它将下一步的必要对象定位为“同一原 f 与实际 receiver/坏星松弛的联合预算”，而不仅是增量密度、实际 radius tag 或全壳权重。

## 2. 全壳 row 集仍只有 O(n)

令 ν(dz)=2^(-n)m(z)^(-n)1{||z||∞<t}dz，m=max(1,||z||∞)，S=1+n logt。令

  D={||z||∞<t:∃i,z_i<1−βm(z)}， λ=ν|D， B=λ(D)，
  Rν^κ(w)=∫1{||z−w||∞<κm(z)}dν(z)。                       (2)

对任意 κ≤β、target 壳半径 r∈[1,t]，source/target 各 pin 一个 face coordinate，其余至少 n−2 个 free pairs 独立。固定 free target W~U[-r,r]，source coordinate ρZ、Z~U[-1,1]：capture 概率随 ρ≤t 增加，故取 ρ=t、κ=β 得到

  p(r)=1−(r−1)²/(4rt)。                                    (3)

source core 的自由坐标数更多，同样被此界控制。于是每个 full target face 上 E Rν^κ≤S p(r)^(n−2)。D restriction 只会减少质量。对 t>16、任意 threshold q>0，Markov 给出

  λ{Rν^β>q}≤1+n log16
       +[n S log(t/16)/q] exp[−225(n−2)/(64t)]。             (4)

特别 t=n/(c logn)、c∈[1/2,1]、τ≥1 时，对 q=τ 或 τ/4 都一致为 O(n)，外壳项 o(n)。这是全壳界，不冻结旧 τ0。主代理另有 `/tmp/ccu_r628_certificate.md` 的实际算术认证；本稿不重算其有限端点。

若 K≥0 是由资格支付的 position-only capture 核，K(w,z)≤g(w)1{||z−w||<βm(z)}，资格上界为 τg(w)，令 Dmax 至少为其最大 ambient row 与 column degree，则

  [∫(Rλ,K(w)−τg(w))dλ(w)]_+/Dmax
       ≤λ{Rν^β>τ}=O(n)。                                  (5)

证明：正 excess 只能来自 Rν^β>τ；其每点 row≤Dmax。把所有环带的 K、g 先相加并共用列容量，仍是同一个论证，不能把每带 O(n) 独立相加。静态测度 λ1{Rν^β≤τ} 同时满足密度及所有此类资格，质量 B−O(n)。尚不能仅凭这个静态见证声称有实际历史；下面补生成条件。

## 3. 实际历史生成命题及证明

**命题。** 固定 n,t>16、τ>0、β=1+1/t。给定紧集

  K⊂D∩{||w||∞>16}∩{Rν^β(w)<τ/4}，                         (6)

对任意 η>0，存在足够大的 a>2t 及有限 supplied family，使原算法选取该全部 family；存在唯一最后、最小正贡献 radius1 的 corner witness；所有此前正贡献项在该 witness 处均 uncaptured、同时在 load point0 贡献；其真实 uncaptured-increment measure μ_a 满足

  μ_a(R^n)≥ν(K)−η。                                      (7)

此外实际 R_i/m(z)在所有此前 increment pieces 上一致趋1。这里 n,t,K 固定后才令 a→∞；不主张一个固定 family 的极限。

**构造与密度。** 设 α=a/(a+1)、ε=a^(-1/2)。对每个 w∈K 赋真实半径

  R(w)=(1+ε)m(w)/α， J(w)=Q(w,R(w)/(a+1))。                (8)

原 small cube 是 (a+1)J(w)，原 center 为 (a+1)w。其 a-star 含0，因为 αR(w)=(1+ε)m(w)>||w||。K 的 D 及径向边界有正裕量；a 大时 R(w)<t，全部 J(w)⊂D∩{||z||>1}。由开放覆盖取有限 subcover K⊂∪J_i，再按 R_i 非增排列。scaled 实际 increments 为 E_i=J_i\∪_{h<i}J_h，准确对应 (1)。

在 E_i 上，真实 measure 密度为 α^(-n)(2R_i)^(-n)，因此相对 ν 的密度准确是

  dμ_a/dν(z)=[m(z)/((1+ε)m(w_i))]^n。

m 为1-Lipschitz，所以这个比值介于

  [1/(1+ε)−1/a]^n 与 [1/(1+ε)+1/a]^n。                   (9)

a 大时 ε≥1/(a−1)，上界≤1；下界趋1，且不依赖 cover 的 cardinality、边界增量或排列。故 μ_a≤ν 且 μ_a(∪J_i)≥[1/(1+ε)−1/a]^nν(K)，证明质量近似。有限 a 的 R056 envelope λ_a=α^(-n)λ 在这些 increment pieces 上适用，并准确有

  dμ_a/dλ_a=(m(z)/R_i)^n。                               (10)

(9) 同时给 R_i/m(z)一致趋1。这里的 density cap 是实际增量的，绝不是原 f 的。

**全部累计资格，而非逐对检查。** 若已选 source center w_i 的 b-star 捕获 candidate center w_j，则 ||w_i−w_j||<αβR_i。对其任一 increment 点 z，

  ||z−w_j||<(αβ+1/(a+1))R_i≤κ_eff m(z)，
  κ_eff=(1+ε)(aβ+1)/(a−1−ε)→β。                          (11)

Rν^κ(w) 在 κ>1 联合连续：其边界在 m 的有限 affine pieces 上是非退化超平面，ν 零测，故可用 dominated convergence。紧 K 上因而 Rν^{κ_eff}<τ/2，当 a 足够大。由 μ_previous≤ν，任意 prefix 的**完整累计**资格和≤Rν^{κ_eff}(w_j)<τ/2。这个论证对任何 radius-nonincreasing 排列均有效，且没有依赖尚未选取的权重来代替已冻结权重；全 prefix 的统一上界来自相同的点态密度控制。因此每个 remaining cube 始终 eligible，原算法确实逐一选择所有最大 remaining radii。零 increment 项可保留；删除它们也不改变后续 union。

**最后 corner witness。** 在上述 family 后加入 radius R_*=1、scaled center

  w_*=α(1−ε)·1。

其 a-star 严格含0，radius 小于全部此前 R_i，且 small cube 与此前 union 分离，故自增量正。D 的紧裕量意味着在 K 上 ||w−1||>βm(w) 有一致正裕量。由 w_*→1、αβR_i=β(1+ε)m(w_i)，a 大时

  ||w_i−w_*||>αβR_i，                                     (12)

所以最后 center 不被任何此前 b-star 捕获，实际 eligibility sum=0。全部此前项仍在0贡献。算法没有拒选分支；最后 cube 是最后选取的唯一最小正贡献 witness。其 self weight=a^(-n)。此前 uncaptured measure 正是已经构造的 μ_a，(7) 成立。

**同一真实输入的可实现性。** 有限全部 a-stars 都严格含0，故其交含一个0邻域 U。取 f=F|U|^(-1)1_U，F>P max_i|aB_i|、P=((a+1)/a)^n，则每个 a-star 的真实平均>1，甚至全部 supplied small cubes 都落入 {M_nf>1}（以 radius(a+1)R_i 的包含立方体检验）。因此该 family 可作为同一真实 L1 输入的有限 bad-witness family。该 f 与 μ_a 完全不同；其质量 F 可以很大。此构造没有假定 f 密度帽，更没有得到 weak lower。

## 4. 近满载推论、真正缺失的信息与停止

由 (4)，在 t=n/(c logn)、c∈[1/2,1]、τ≥1 的范围，(6) 的区域质量至少

  B−1−n log16−o(n)=B−O(n)。                               (13)

ν 为有限 Radon measure，该区域开放，可先取紧 K 使损失任意小，再应用生成命题。负 maximal faces 全属 D，故 B≥(n/2)logt=Ω(nlogn)。于是这些**实际有限 greedy 历史**的 uncaptured load 也可为 Ω(nlogn)，实际 radius tags 却一致近1。

因此，单靠固定 τ 的局部缺额、多环带共同 position-only 核，乃至只加入 near-minimal actual-radius tag 和 small-cube increment 产生规则，都不能强制全部历史的单点 load 为根阶。范围仅限既有 t~n/logn、τ≥1 的 load 方法；不是对原 maximal 目标的反例，也不是一般参数最优性定理。

同一原 f 的信息必须以真实 receiver 费用保留。上述共同星交输入尤其说明为何：写 h_i=A_{aB_i}f=F/|aB_i|、Vtot=∑v_i，则

  D_f=∑v_i(h_i−1)=F W(0)−Vtot，
  Vtot=∫fW−D_f。

高 load 可伴随同样大的 bad-star slack；丢掉 D_f 才把本来容易的输入变成 nlogn 的单点付款。尚未证明的是把这些真实 slack、receiver 覆盖收益和全尺度历史共同转成根阶预算。本文没有支付 R559 原能量/时钟母账，也没有构造新的完整弱型界。

本轮的实质是全局模型范围判断及实际生成桥，非新维数改进。未作计算或扫描，未启动 agent，未改其他文件。若原算法另有未列入(1)的额外供应约束，则须重新核对该约束；在上述已实读的原定义下，构造的全部分支与累计资格已给出。
