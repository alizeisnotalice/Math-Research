import math,json,sys,time,platform,resource,hashlib
from pathlib import Path
from fractions import Fraction as Q
from flint import arb,fmpq,ctx
import flint
start=time.perf_counter();cpu=time.process_time();ctx.prec=256
# log 2 = 2 atanh(1/3), positive tail bounded by a geometric envelope.
z=Q(1,3);N=40;L2lo=2*sum((z**(2*j+1)/Q(2*j+1) for j in range(N)),Q());err=2*z**(2*N+1)/(Q(2*N+1)*(1-z*z));L2hi=L2lo+err
alpha=Q(5983,8192);Llo=24*L2lo;Lhi=24*L2hi;assert alpha*Llo>2
x=alpha*Llo;exp_lower=sum((x**k/Q(math.factorial(k)) for k in range(61)),Q());bound=2*Lhi**2/exp_lower;assert bound<Q(1,16)
# Independent Arb ball evaluation verifies the same sufficient expression.
def A(q):return arb(fmpq(q.numerator,q.denominator))
log2=arb(2).log();assert log2>=A(L2lo) and log2<=A(L2hi)
L=24*log2;ab=A(alpha);arb_bound=2*L**2*(-ab*L).exp();assert arb_bound<arb(fmpq(1,16))
# Closed form vs integral in y of the clipped x-overlap length, piecewise linear.
def integ(rho,r,k):
 d=k*rho;cuts=sorted({-r,r,*[v for v in (-rho-d,-rho+d,rho-d,rho+d) if -r<v<r]})
 def f(y):return max(Q(),min(rho,y+d)-max(-rho,y-d))
 integral=sum(((f(a)+f(b))*(b-a)/2 for a,b in zip(cuts,cuts[1:])),Q())
 return integral/(4*r*rho)
def formula(rho,r,k):
 d=k*rho;return 1-(max(Q(),rho+r-d)**2-max(Q(),abs(rho-r)-d)**2)/(4*r*rho)
rows=[]
for n in (3,7,32):
 for ratio in (Q(1,4),Q(1,2),Q(3,4),Q(1),Q(5,4),Q(2),Q(4)):
  for k in (Q(1),Q(5,4),Q(3,2)):
   p=integ(Q(1),ratio,k);v=formula(Q(1),ratio,k);assert p==v and 0<=p<=1
   rows.append({'n':n,'rho':'1','r':str(ratio),'kappa':str(k),'p':str(p)})
f=lambda q:[str(q.numerator),str(q.denominator)]
def ep(x):
 l=x.lower().man_exp();u=x.upper().man_exp();return {'lower':[str(l[0]),int(l[1])],'upper':[str(u[0]),int(u[1])],'display':x.str(35)}
out={'scope':'given analytic E/n inequality for n>=2^24 and 63 finite independent 1D checks; no weak-type conclusion','alpha':f(alpha),'log2_lower':f(L2lo),'log2_upper':f(L2hi),'log_series_terms':N,'exp_series_terms':61,'exp_input_lower':f(x),'rational_upper_bound':f(bound),'rational_lt_1_16':bound<Q(1,16),'arb_log2':ep(log2),'arb_exact_expression':ep(arb_bound),'arb_precision_bits':ctx.prec,'pair_tests':rows,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'runtime':{'python':sys.version,'flint':flint.__version__,'sys_executable':sys.executable,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
Path(__file__).with_name('certificate_replay.json').write_text(json.dumps(out,indent=2)+'\n');print('rational bound',float(bound),'arb',out['arb_exact_expression']['display'],'pair tests',len(rows),'sha',out['script_sha256'])
