# 第628轮复现及证据范围

解释器：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。实际Python 3.12.14、NumPy 2.5.4、SciPy 1.18.1、python-flint 0.9.0；高精度复算的mpmath版本见 numeric_audit_original.json。

## 已实际执行的便携核验

在解压目录执行（python替换为上述解释器）：

```sh
python certificate.py
python verify.py
```

主代理确已执行。前者重放全部有理基点证书、Arb256及63个参数标签的一维分段积分（21个不同一维组合）；后者只重放修复后n32,c=.5一案，比较三项gate，并准确核验四倍尾费、3n常数与2^36门槛。不会重扫18案。

## 其他重放入口与来源

`numeric_original.py`是历史成功18案实际运行代码，SHA与历史metadata一致；它遗失内层quad失败消息，保留是为了审核原结果，不能据outer success补称inner success。`numeric.py`为修复版，只实跑一个修复复核案；不能把历史结果重新署为修复版产物。

`numeric_original.json`、`numeric_audit_original.json`、`repair_original.json`保留原结果不追改。numeric_provenance.json载原pilot/full不同代码身份、失败旧批次和修复范围。pilot实际旧版本仅留hash，其最终代码形态不冒称与full相同。

可选 `python numeric_audit.py` 为六探针35/60位独立复算入口；便携化仅更改输入/输出路径，指向归档的原生产代码。原绝对路径版已实跑六探针；主代理未再运行这个便携包装的整组六探针。其高精度误差只是收敛诊断，不是区间证书。

若需要重跑生产，应显式把输出定向到新的目录，先运行pilot再full，例如 `python numeric.py --phase pilot --output-dir replay` 和 `python numeric.py --phase full --workers 14 --output-dir replay`。这些修复版全批命令本轮未运行，不得当作已经通过。

## 数值与证明的边界

一般全壳概率界、Markov界、实际历史生成均靠解析证明和独审；有限积分仅决定是否继续对静态多环带参数做昂贵扫描。全局门槛的一般范围还使用解析单调性，不能由有限分数证书自行推出。

历史18案outer均success，inner失败消息未保存；最大记录inner误差估计约2.10e-4。六探针高精度显示最小正值约6.06e-8187，而binary64下溢为0；它不是严格零。全部浮点结果仅作证据，不参与证明常数。

原批次请求14进程，成功批次wall约0.642秒、worker任务CPU和约2.734秒，最大单worker RSS约72.6MiB；结束快于1秒采样间隔，未测到即时系统CPU或忙碌进程数。没有声称持续满载。失败旧批次缺失resource导入，无已保存成功案；不把失败工作算作已验证结果。

本轮归档包含详细LaTeX、原作者稿与独审以绑定证明来源；不编译PDF。一般根阶目标未闭合。近满载历史不等于原算子弱型下界；不能排除更优输入依赖见证选择，不能丢掉真实坏星松弛。
