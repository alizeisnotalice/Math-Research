"""R628 bounded independent precision probes; no full gate scan."""
import json,math,hashlib,time,sys,importlib.util
from pathlib import Path
import mpmath as mp
import scipy.integrate as si
import numpy as np
base=Path(__file__).resolve().parent;source=base/'numeric_original.py';data=base/'numeric_original.json';OUTPUT=base/'numeric_audit_replay.json';report=OUTPUT.with_suffix('.md')
spec=importlib.util.spec_from_file_location('r628_prod',source);prod=importlib.util.module_from_spec(spec);spec.loader.exec_module(prod)
d=json.loads(data.read_text());tstart=time.monotonic()
def calc(n,t0,r0,dps):
 with mp.workdps(dps):
  t=mp.mpf(t0);r=mp.mpf(r0);k=1+1/t
  def pval(rho):
   aa=max(mp.mpf('0'),rho+r-k*rho);bb=max(mp.mpf('0'),abs(rho-r)-k*rho)
   return min(mp.mpf(1),max(mp.mpf(0),1-(aa-bb)*(aa+bb)/(4*rho*r)))
  def lens(rho):
   g=max(mp.mpf(0),min(mp.mpf(1),(rho+k*rho)/r)-max(mp.mpf(-1),(rho-k*rho)/r))/2
   h=max(mp.mpf(0),min(mp.mpf(1),(r+k*rho)/rho)-max(mp.mpf(-1),(r-k*rho)/rho))/2
   j=(int(abs(rho-r)<k*rho)+int(rho+r<k*rho))/2
   return g,h,mp.mpf(j)
  p=pval(1);g,h,j=lens(1);inner=h*p**(n-1)
  def fun(v):
   rho=mp.exp(v);p=pval(rho);g,h,j=lens(rho)
   return j*p**(n-1)/n+(1-mp.mpf(1)/n)*g*h*p**(n-2)
  end=mp.log(t);cuts=[end*i/24 for i in range(25)];q=r/(1+k)
  if 1<q<t:cuts.append(mp.log(q))
  cuts=sorted(set(cuts)); val=inner+n*mp.fsum(mp.quad(fun,[a,b]) for a,b in zip(cuts,cuts[1:]))
  return mp.nstr(val,45),mp.nstr(inner,45)
def prod_probe(n,t,r):
 stats={'source_quad_evals':0,'m_evaluations':0,'max_source_estimated_error':0.,'underflow_terms':0}
 value,inner,error=prod.calculate_m(n,t,r,stats)
 k=1+1/t
 def f(v):
  rho=math.exp(v);p=prod.free(rho,r,k);g,h,j=prod.pinned(rho,r,k)
  return j/n*p**(n-1)+(1-1/n)*g*h*p**(n-2)
 q=r/(k+1);pts=[math.log(q)] if 1<q<t else []
 full=si.quad(f,0,math.log(t),points=pts,epsabs=prod.ABS/n,epsrel=prod.REL,limit=250,full_output=1)
 return {'m':value,'inner':inner,'error_estimate':error,'quad_output_length':len(full),'message':str(full[3]) if len(full)>3 else None,'events':full[2]['neval'],'underflow_terms':stats['underflow_terms']}
rows=[]
for n in (32,65536):
 saved=next(z for z in d['results'] if z['n']==n and z['c']==.5);t=saved['t']
 for name,r in [('2',2.),('16',16.),('t',t)]:
  if r>t:continue
  p=prod_probe(n,t,r); low,il=calc(n,t,r,35);hi,ih=calc(n,t,r,60)
  with mp.workdps(80):
   A=mp.mpf(hi);B=mp.mpf(low);diff=abs(A-B);p_err=abs(mp.mpf(p['m'])-A)
   row={'n':n,'c':.5,'t_binary64':t,'probe':name,'r_binary64':r,'mp_dps_35':low,'mp_dps_60':hi,'mp_inner_60':ih,'precision_difference':mp.nstr(diff,12),'production_difference':mp.nstr(p_err,12),'production':p,'diagnostic_relative_difference':mp.nstr(p_err/abs(A),12) if A else None}
  rows.append(row);print(n,name,'m',hi,'prod_diff',row['production_difference'],'precision_diff',row['precision_difference'],flush=True)
max_inner=max((z['quadrature']['max_source_estimated_error'],z['n'],z['c']) for z in d['results'] if z['status']=='complete')
output={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'production_script_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(data.read_bytes()).hexdigest(),'saved_script_sha256':d['script_sha256'],'metadata_hash_matches':hashlib.sha256(source.read_bytes()).hexdigest()==d['script_sha256'],'production_commands':d['commands'],'results_count':len(d['results']),'complete_count':sum(z['status']=='complete' for z in d['results']),'outer_success_count':sum(z.get('outer_quad_success') is True for z in d['results']),'outer_statuses':sorted(set(z.get('outer_quad_status') for z in d['results'])),'max_inner_reported_estimate':{'value':max_inner[0],'n':max_inner[1],'c':max_inner[2]},'historical_inner_failure_status_recorded':False,'warning':'Source code slices scipy quad full_output to three outputs, discarding a possible fourth failure message; historical error estimates are not success certificates.','method':'mpmath 35/60 dps, 24 log-rho subintervals plus kink, comparing direct shell formula against production probes; binary64 t/r preserved exactly','probes':rows,'elapsed_seconds':time.monotonic()-tstart,'python':sys.version,'mpmath':mp.__version__}
OUTPUT.write_text(json.dumps(output,indent=2));
with report.open('w') as f:
 f.write('# R628 数值独立核验\n\n18/18 原始 outer 状态为 success=True、status=0；最大历史 inner 估计误差为 %.12g（n=%s，c=%s）。inner quad 的返回结果被 [:3] 截断，潜在第四项失败信息未记录，因此不能从既有数据确认全部 inner 求积成功。生产脚本 SHA 与结果元数据%s；本次探针单独保留了 full_output 长度和失败消息。\n\n'%(max_inner[0],max_inner[1],max_inner[2],'一致' if output['metadata_hash_matches'] else '不一致'))
 f.write('独立计算使用 mpmath、log ρ 上 24 段及几何折点，分别计算 35/60 位精度；所用 t 和 r 是生产 binary64 值的精确输入。高精度之间差异和生产差异为诊断，非严格误差界；相对误差在极小值处须特别谨慎。全部探针固定 c=.5。\n\n')
 f.write('| n | r | m（60位，显示） | 与生产的绝对差 | 35/60位之差 | 生产估计误差 | inner 消息 |\n|---:|---|---:|---:|---:|---:|---|\n')
 for x in rows:
  f.write(f"| {x['n']} | {x['probe']} | {mp.nstr(mp.mpf(x['mp_dps_60']),9)} | {x['production_difference']} | {x['precision_difference']} | {x['production']['error_estimate']:.3g} | {'无' if x['production']['message'] is None else '有'} |\n")
 f.write('\n维度检查：归一化内立方项为 h p^(n−1)；壳面积为 n dρ/ρ，概率项为 j p^(n−1)/n + (1−1/n)gh p^(n−2)，故外乘 n；对数变量 dρ/ρ=d(log ρ)。上述仅核验指定数值表达式和探针，不认证模型源推导或全域不等式。\n')
