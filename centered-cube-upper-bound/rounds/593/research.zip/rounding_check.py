#!/usr/bin/env python3
"""Exact exhaustive implementation check of the frozen common spatial rounding law."""
import argparse,hashlib,json,platform,resource,shlex,signal,sys,time
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
import sympy as sp

CASES=[
 {'name':'initial_two_equal_distinct','positions':[['0'],['1']],'masses':['1','1']},
 {'name':'pressure_unequal_asymmetric_duplicate_labels','positions':[['-1','0'],['-1','0'],['2','1/3'],['1/4','-3/2'],['3/2','2']],'masses':['1/3','1/6','2/3','5/6','1/4']},
 {'name':'expanded_six_two_dimensional_positions','positions':[['-2','0'],['-1','3/2'],['0','-1'],['1/3','2'],['2','1/4'],['3','-2']],'masses':['1/2','2/3','3/4','4/5','5/6','6/7']}]

CASES.append({'name':'terminal_regression_three_coincident_unequal_labels','positions':[['2/7','-3/5']]*3,'masses':['1/7','2/5','3/8']})

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r593_rounding_results.json'));args=ap.parse_args();start=time.perf_counter()
 def timeout(*_):raise TimeoutError('120s guard; no truncated tree')
 signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
 def entropy_vector(p,m):
  out=defaultdict(F)
  for x,w in zip(p,m):
   if 0<x<1:out[min(x,1-x)]+=w
  return {k:v for k,v in out.items() if v}
 def vecadd(target,source,scale=F(1)):
  for k,v in source.items():target[k]+=scale*v
 def rational_input(pos,masses):
  z=list(map(lambda row:tuple(map(F,row)),pos));m=list(map(F,masses));assert all(w>0 for w in m);assert len(z)==len(m)
  return z,m
 def enumerate_tree(pos,masses):
  labels,wm=rational_input(pos,masses);groupmap=defaultdict(list)
  for i,z in enumerate(labels):groupmap[z].append(i)
  z=sorted(groupmap);labelgroups=[groupmap[p] for p in z];m=[sum(wm[i] for i in ids) for ids in labelgroups];D=len(z);W=sum(m);ndim=len(z[0]);assert all(len(p)==ndim for p in z)
  law=defaultdict(F);leaves=[];nodes=[];qv=F(0);perblockqv=[F(0)]*D;entropydrop=defaultdict(F);maxdepth=0;spatial_edges=0;terminal_edges=0;localchecks=0
  def walk(p,prob,path,depth):
   nonlocal qv,maxdepth,spatial_edges,terminal_edges,localchecks
   assert prob>0 and all(0<=v<=1 for v in p);maxdepth=max(maxdepth,depth)
   floating=[i for i,v in enumerate(p) if 0<v<1]
   if not floating:
    mask=sum(1<<i for i,v in enumerate(p) if v==1);law[mask]+=prob
    leaves.append({'path':path,'probability':str(prob),'physical_position_mask':mask,'mass_exact':str(sum(m[i] for i in range(D) if mask>>i&1))});return
   assert depth<D
   assert sum(mi*pi for mi,pi in zip(m,p))==W/2,'Every preterminal state must retain half original mass'
   info={'path':path,'reach_probability':str(prob),'p':list(map(str,p)),'floating_positions':floating,'retained_mass_exact':str(W/2)}
   if len(floating)==1:
    i=floating[0];plus=list(p);minus=list(p);plus[i]=F(1);minus[i]=F(0);children=[(tuple(plus),p[i],'+'),(tuple(minus),1-p[i],'-')];info['type']='terminal_single_position_Bernoulli';info['position']=i
   else:
    M=sum(m[i] for i in floating);means=[sum(m[i]*z[i][j] for i in floating)/M for j in range(ndim)];variances=[sum(m[i]*(z[i][j]-means[j])**2 for i in floating)/M for j in range(ndim)];axis=max(range(ndim),key=lambda j:(variances[j],-j));assert variances[axis]>0
    v=tuple(z[i][axis]-means[axis] if i in floating else F(0) for i in range(D));assert sum(mi*vi for mi,vi in zip(m,v))==0
    plus_bounds=[];minus_bounds=[]
    for pi,vi in zip(p,v):
     if vi>0:plus_bounds.append((1-pi)/vi);minus_bounds.append(pi/vi)
     elif vi<0:plus_bounds.append(pi/(-vi));minus_bounds.append((1-pi)/(-vi))
    tp=min(plus_bounds);tm=min(minus_bounds);assert tp>0 and tm>0
    wp=tm/(tp+tm);wn=tp/(tp+tm);plus=tuple(pi+tp*vi for pi,vi in zip(p,v));minus=tuple(pi-tm*vi for pi,vi in zip(p,v));children=[(plus,wp,'+'),(minus,wn,'-')]
    for child,_,_ in children:
     assert all(0<=v<=1 for v in child)
     assert sum(mi*pi for mi,pi in zip(m,child))==W/2
     assert sum(0<pi<1 for pi in child)<len(floating)
    conditional_qv=sum(w*sum(mi*(b-a)**2 for mi,a,b in zip(m,p,child)) for child,w,_ in children)
    assert conditional_qv==tp*tm*sum(mi*vi**2 for mi,vi in zip(m,v))
    info.update({'type':'spatial_two_endpoint','axis':axis,'means':list(map(str,means)),'weighted_variances':list(map(str,variances)),'direction':list(map(str,v)),'tau_plus':str(tp),'tau_minus':str(tm),'formula17_quadratic_cost_exact':str(conditional_qv)})
   assert sum(w for _,w,_ in children)==1
   for i in range(D):assert sum(w*child[i] for child,w,_ in children)==p[i]
   localchecks+=1
   localH=defaultdict(F);vecadd(localH,entropy_vector(p,m))
   info['children']=[]
   for child,w,suffix in children:
    inc=[(b-a)**2 for a,b in zip(p,child)]
    for i,iv in enumerate(inc):perblockqv[i]+=prob*w*m[i]*iv
    qv+=prob*w*sum(mi*iv for mi,iv in zip(m,inc));vecadd(localH,entropy_vector(child,m),-w)
    if info['type']=='spatial_two_endpoint':spatial_edges+=1
    else:terminal_edges+=1
    info['children'].append({'branch':suffix,'conditional_probability':str(w),'p':list(map(str,child)),'retained_mass_exact':str(sum(mi*pi for mi,pi in zip(m,child)))})
   vecadd(entropydrop,localH,prob);nodes.append(info)
   for child,w,suffix in children:walk(child,prob*w,path+suffix,depth+1)
  walk(tuple(F(1,2) for _ in range(D)),F(1),'',0)
  law={k:v for k,v in sorted(law.items()) if v};assert sum(law.values())==1 and len(leaves)<=2**D and maxdepth<=D
  marginals=[sum(prob for mask,prob in law.items() if mask>>i&1) for i in range(D)];assert all(v==F(1,2) for v in marginals)
  expectedmass=sum(prob*sum(m[i] for i in range(D) if mask>>i&1) for mask,prob in law.items());assert expectedmass==W/2
  for mask,prob in law.items():assert law.get(((1<<D)-1)^mask,F(0))==prob
  assert qv==W/4 and perblockqv==[mi/4 for mi in m]
  formalH={k:v for k,v in entropydrop.items() if v};assert formalH=={F(1,2):W}
  labelmarginals=[marginals[next(j for j,ids in enumerate(labelgroups) if i in ids)] for i in range(len(labels))];assert all(v==F(1,2) for v in labelmarginals)
  return {'physical_positions':[[str(a) for a in p] for p in z],'physical_masses':list(map(str,m)),'original_label_groups':labelgroups,'W':str(W),'physical_position_count':D,'original_label_count':len(labels),'law':[{'physical_mask':mask,'probability':str(prob)} for mask,prob in law.items()],'position_marginals':list(map(str,marginals)),'original_label_marginals':list(map(str,labelmarginals)),'expected_mass_exact':str(expectedmass),'complement_invariant_exact':True,'expected_weighted_quadratic_variation':str(qv),'expected_per_position_weighted_quadratic_variation':list(map(str,perblockqv)),'formal_expected_entropy_drop':{'h(1/2)_coefficient':str(W),'all_other_h(rational)_coefficients':'0','equals':'W*log(2); symbolic h(1/2)=log2, no floating entropy evaluated'},'raw_leaf_count':len(leaves),'distinct_terminal_masks':len(law),'maximum_depth':maxdepth,'nonterminal_local_martingale_checks':localchecks,'spatial_edges_preserve_half_mass':spatial_edges,'terminal_Bernoulli_edges_not_required_half_mass':terminal_edges,'all_preterminal_states_half_mass':True,'nodes':nodes,'leaves':leaves}
 results=[]
 for case in CASES:
  original=enumerate_tree(case['positions'],case['masses'])
  splitpos=[];splitmass=[]
  for p,m in zip(case['positions'],case['masses']):
   mass=F(m)
   for fraction in (F(1,3),F(2,3)):splitpos.append(p);splitmass.append(str(mass*fraction))
  split=enumerate_tree(splitpos,splitmass)
  for key in ('physical_positions','physical_masses','law','expected_mass_exact','expected_weighted_quadratic_variation','formal_expected_entropy_drop','nodes','leaves'):assert split[key]==original[key],key
  results.append({'input':case,'rounding':original,'same_position_label_split_check':{'split_rule':'each original label split into masses m/3 and 2m/3 at the identical original position','split_label_count':len(splitmass),'all_physical_states_and_branch_probabilities_identical':True,'terminal_law_exactly_identical':True}})
 # Only symbolic entropy curvature and a general two-level tree telescope.
 t=sp.symbols('t',positive=True);h=-t*sp.log(t)-(1-t)*sp.log(1-t);curvature=sp.simplify(sp.diff(h,t,2)+1/(t*(1-t)));assert curvature==0
 strong=sp.simplify(-sp.diff(h,t,2)-4-(2*t-1)**2/(t*(1-t)));assert strong==0
 hh=sp.simplify(h.subs(t,sp.Rational(1,2))-sp.log(2));assert hh==0
 H0,Hp,Hm,Hpp,Hpm,Hmp,Hmm,w,wp,wm=sp.symbols('H0 Hp Hm Hpp Hpm Hmp Hmm w wp wm')
 drops=(H0-w*Hp-(1-w)*Hm)+w*(Hp-wp*Hpp-(1-wp)*Hpm)+(1-w)*(Hm-wm*Hmp-(1-wm)*Hmm)
 leaves=w*(wp*Hpp+(1-wp)*Hpm)+(1-w)*(wm*Hmp+(1-wm)*Hmm);tel=sp.expand(drops-(H0-leaves));assert tel==0
 signal.alarm(0)
 result={'scope':'Four frozen finite source-law trees only, including the required immediate-terminal coincident-label regression. No receiver geometry, reception gain, entropy-to-receiver-loss rate, or general-dimensional weak bound is tested.',
 'algorithm':'Sol equations (3)(4): aggregate physical positions, largest original-mass weighted floating coordinate variance with smallest-axis tie, mean-centered direction, maximal feasible endpoints and zero-mean probabilities; one final common Bernoulli if one physical position remains.',
 'half_mass_scope':'Every spatial branch and every preterminal state has mass W/2. A terminal single-position Bernoulli may change path mass; its expectation is preserved. No false claim that every final mask has half mass.',
 'cases':results,'symbolic_entropy':{'h_second':'-1/[t(1-t)]','curvature_residual':str(curvature),'strong_concavity_residual':str(strong),'domain_for_h_second_le_minus4':'0<t<1, since (2t-1)^2/[t(1-t)]>=0','h_half_minus_log2':str(hh),'two_level_telescope_residual':str(tel),'general_telescope':'Every internal-node potential appears with its reach probability once positively and once negatively; leaves have H=0, root H=W log2. The exhaustive formal coefficient check verifies this cancellation on every complete tested tree.','no_floating_entropy':True},
 'execution':{'interpreter':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'processes':1,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]])},'all_assertions_passed':True}
 args.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'trees':[(r['input']['name'],r['rounding']['raw_leaf_count'],r['rounding']['distinct_terminal_masks'],r['rounding']['maximum_depth'],r['rounding']['W'],r['rounding']['expected_weighted_quadratic_variation']) for r in results],'all_assertions_passed':True,'execution':result['execution']}))
if __name__=='__main__':main()
