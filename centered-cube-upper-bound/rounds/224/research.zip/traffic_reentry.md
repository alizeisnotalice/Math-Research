# R224：QG时钟回代与全实际尺度的固定J联合结算

**范围。** 本稿不重证标量 QG。除一个使用已审核 QG 的完整 `Oκ(log n)` 时钟引理外，给两条**不依赖 QG、覆盖全部实际 L/R/s 和 R=b 的原正量接口**：

1. 终端时钟带 `g e^(−d/n)≤t≤g` 内，三腿上放的固定 J 半密度分量实际付为
   `εX+[128Λ²/(27ε)]d²e^d Wν`；取 `d=(log n)/2` 得 `εX+[32Λ²/(27ε)]√n log²n Wν`。
2. 当前浮动带补域中，若 `w_t(y,v)/w_g(y,v)≤√n`，J 可由实际 good 门直接吸收，只需两条同 soft 腿，系数由 `√(K/3)` 改为 `√(K/2)`。

第一条先控制原三腿**上界中的 J 分量**，再以TR1a的可测分配绑定实际原正子交通；不是整个原正项已付。第二条只是准确减少第三腿，并非整个正项付款。没有预选单patch/微带，没有为 QG 的固定参数积分免费授予自适应 receiver 包络。原负账和已付浮动带均不领取。

## TR1 原量、唯一叶/比例带和可用列

读本轮合同、R220已证共同核、R222 `source_occupancy.md`、R223 `negative_contract.md`，只窄读 R170 的 terminal-ratio 工具比较资格。记原固定接收域 E，`X=λ|E|`，`3λ/4≤q≤λ`，`Λ=128/119`，`Wν=EΣV||νV||`。

原完整正母量保 `2Λ`、真实 `dx βV(dy)νV(dz)Π_t(dv)Π_t(du)dt/t`、`aω/q`、当前 high/good×bad/mixed/FA/suffix/捕获和浮动补域。aω为原无量纲RN，0≤aω≤1。使用原 hard 帽**一次**并保 R222 的真实条件平均后，可先不作几何尺度比较，写成

\[
 P\le\mathcal U_1+\mathcal U_2+\mathcal U_J,\qquad
 \mathcal U_a=C_0\,\mathbb E\sum_{V,j}\int_E dx\int\beta_V(dy)
 \int_{J_{far}}\iint\eta\delta_t
 \frac{\sqrt{p_y(x)K_{a,x}(v)}}{\sqrt{w_g(y,v)}}
 d\Pi_t(v)d\Pi_t(u)\frac{dt}{t},\quad
 C_0=\frac{32\Lambda}{3}\sqrt{\frac K3}. \tag{TR1}
\]

为使该费用对应实际原正子交通，定义可测分配

\[
 \lambda_J(x,v)=\frac{\sqrt{J_v(x)}}{\sqrt{K_{1v}(x)}+\sqrt{K_{2v}(x)}+\sqrt{J_v(x)}},\qquad
 \lambda_a=\frac{\sqrt{K_{av}}}{\sqrt{K_1}+\sqrt{K_2}+\sqrt J}\quad(a=1,2). \tag{TR1a}
\]

零总和处原good正量为零，各权置零；其余处三权和为1。原good半密度不等式乘λJ恰得 `λJ p_y≤√(K/3)√(p_yJ_v)/√w_g`。因此把原完整正母式乘 `λJ 1_{T_d}` 所得真实子交通 `P_J^alloc(T_d)` 满足 `P_J^alloc(T_d)≤U_J(T_d)`。原余量准确乘补权 `1−λJ1_{T_d}`，不重建FIRST/来源/history；所有负项原位只留一次。这是正量分配，不给每腿再复制一份负信用。

`K_{J,x}(v)=J_v(x)=P_{1,b}(x−v)` 固定尺度/固定soft；其余两个目标依实际 x。η仍保原 high、唯一 j、实际 clock、全部原正门与ρ0，不在核节点重算；仅当要估计一个非负项时才把这些门上放。TR1是 R222 在比较 `w_g` 到 `wbar_L` **以前**的合法式，所以这里没有另乘γ^(n/2)，也不会在后文再领硬帽16/3。

来源/空间求和使用的原事实有准确出处：

* [R112 proof.tex.txt:528](/Users/zhengzhihao/Desktop/T/output/centered_cube_round112_20261014/proof.tex.txt:528)给每个正行唯一叶且整个 Q_R(x)⊂V；[R107 proof.md:1005](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/proof.md:1005)同样给实际 Q_x、y共同落入唯一终端叶。V彼此不交且x∈Q_R(x)，故可保实际 `E_{ω,V}⊂E∩V`，从而逐种子 `ΣV |E_{ω,V}|≤|E|`。删除 a/η时仍显式保 E_{ω,V}，不对扩域后的新点授 hardband。
* 原 `j(x)` 在同一 x 唯一；[R170 soft_threshold_energy.md:174](/Users/zhengzhihao/Desktop/T/output/centered_cube_round170_20261016_final_checkpoint/soft_threshold_energy.md:174)明确须保此指示至右边独立 j 才求和。下文按实际 `j(x)` 做每个 x 的估计，不领取 n+2 份列。
* 同一 x 的 FIRST：`∫p_y(x)βV(dy)≤q`。原 high 为 `p_y e_g(y)≥2Kq`，在合法 t≤g 上 e_t≥e_g，因此
\[
 \int 1_{high,valid}\frac{\beta_V(dy)}{e_t(y)}\le\frac1{2Kq}\int p_y\beta_V(dy)\le\frac1{2K}. \tag{TR2}
\]
  每个 e_t 只在原合法正行除法；无效行置零。Π_t依y，下一节保其完整密度，不拆成独立来源。
* 固定 J 列是 `∫_{R^n}(J*νV)(x)dx=||νV||`。这里是 Wν，不换成Wβ，不使用ν≤β。 原支持还给可选的全输入比较：同一ω的终端叶V两两不交，`νV≤σω|V≤1V f dx`（[R107 proof.md:913–919](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/proof.md:913)、[998行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/proof.md:998)、[1079行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/proof.md:1079)；[R112:508](/Users/zhengzhihao/Desktop/T/output/centered_cube_round112_20261014/proof.tex.txt:508)明确继承不交终端叶和νV≤σV≤αV）。所以逐ω有 `ΣVνV≤f dx`，从而 `Wν≤||f||_1`。这里求和仅取这组终端叶，不取整棵树的重叠祖先、macroblocks或重复j；主不等式仍保Wν，不混为Wβ。

## TR2 一个保两来源分母的全实际参数Cauchy估计

固定真实 x、其实际 j、合法 t≤g(x) 与 V。令 H_t(x,y)是原 high 和有效时钟资格的指示（还可保任何仅使左边减小的原正门），无效y行置零。则

\[
 \mathcal I(x,t)=\int H_t(x,y)\beta_V(dy)
 \int\Pi_{y,t}(dv)\sqrt{\frac{p_y(x)J_v(x)}{w_t(y,v)}}
 \le\sqrt{\frac q{2K}(J*\nu_V)(x)}. \tag{TR3}
\]

**证明。** 展开一份原Π，保持原 e_t：左边是

\[
 \iint H_t1_{Z_t}(v)
 \sqrt{\frac{p_y(x)w_t(y,v)}{e_t(y)}}
 \sqrt{\frac{J_v(x)}{e_t(y)}}\,\beta_V(dy)\nu_V(dv).
\]

对该同一β⊗ν底测度用Cauchy；并非假设原后验独立。两个平方积分分别为

\[
 A=\int H_t p_y\beta_V(dy)\int\Pi_{y,t}(dv)\le q,
\]

\[
 B=\int J_v(x)\nu_V(dv)
       \int H_t1_{Z_t}(v)\frac{\beta_V(dy)}{e_t(y)}
 \le\frac1{2K}(J*\nu_V)(x).
\]

A保原概率归一与FIRST；B用TR2。`I²≤AB`即得结论。全部实际 L(x)、s(x)留在同一 x 的 p 与 FIRST 内，没有把其当成关于x归一的固定密度，没有物理或soft网格成本。证毕。

TR3对任意同一x下不依y的非负目标核 `K_x(v)` 也成立，只须右边改成 `(K_x*νV)(x)`；固定J的独特好处是其随后关于真实x的列已经有原来源价。对K1/K2，这一步一般是移动参数列，不能按固定J归一。

## TR3 终端时钟带的J分量实际付款

取任何预先固定 d>0，保原所有资格后再加

\[
 \mathcal T_d(x)=\{t:g(x)e^{-d/n}\le t\le g(x)\}\cap J_{far}(x,y).
\]

若与原far无交则该项为零。逐坐标权比给 `w_t(y,v)/w_g(y,v)≤(g/t)^n≤e^d`，故

\[
 \frac{\sqrt{p_yJ_v}}{\sqrt{w_g}}
 \le e^{d/2}\sqrt{\frac{p_yJ_v}{w_t}}. \tag{TR4}
\]

在这个指定宽度的带内，最后才用 `δ_t≤n` 并对 u 的完整Π归一。它的 n 由真实对数时间长度 `≤d/n` 支付，不对整个far预先丢掉score。TR3得到每个实际 x 的J分量上界

\[
 n\frac dn e^{d/2}\sqrt{\frac q{2K}(J*\nu_V)(x)}.
\]

若各y合法区间不同，先在原有效Π上置零，再上放到同一个T_d；没有在原heavy过程外新造后验。g(x)与d不依辅助y/v/u；在整个计算中实际j指示保留。因此

\[
 \mathcal U_J(\mathcal T_d)
 \le\frac{32\Lambda}{3\sqrt6}\,d e^{d/2}
 \mathbb E\sum_V\int_{E_{\omega,V}}\sqrt{q(J*\nu_V)(x)}\,dx. \tag{TR5}
\]

**注意：** TR5中的系数只把TR1的 `C0/√(2K)` 合并；右边没有额外source质量或hard帽。对不交E_{ω,V}、真实x、种子期望同时作Cauchy，利用固定J列与q≤λ：

\[
 \mathbb E\sum_V\int_{E_{\omega,V}}\sqrt{q(J*\nu_V)(x)}\,dx
 \le\sqrt{q|E|\,\mathbb E\sum_V\|\nu_V\|}
 \le\sqrt{XW_\nu}. \tag{TR6}
\]

由此得到可直接代回原正上界的**全域终端带J分量定理**

\[
 \boxed{\mathcal U_J(\mathcal T_d)
 \le\frac{32\Lambda}{3\sqrt6}\,d e^{d/2}\sqrt{XW_\nu}
 \le\varepsilon X+\frac{128\Lambda^2}{27\varepsilon}d^2e^dW_\nu.} \tag{TR7}
\]

它覆盖全部实际x依赖的L/R/s、比例带、全部hard来源和原R=b端点；不需要QG，不需要预选microstate或patch。取 `d=(log n)/2`，

\[
 \mathcal U_J(\mathcal T_{(\log n)/2})
 \le\varepsilon X+\frac{32\Lambda^2}{27\varepsilon}\sqrt n\log^2n\,W_\nu
 \le\varepsilon X+\frac{32\Lambda^2}{27\varepsilon}\sqrt n\log^2n\,\|f\|_1. \tag{TR8}
\]

结合TR1a，这同时支付真实原子交通 `P_J^alloc(T_d)`。剩余原量乘精确补权 `1−λJ1_{T_d}`，U1/U2及更早clock的UJ照原测度保留。它不是仅因固定θ积分小而声称P已付款，也不是把R222已经消去的hard来源再用一次。

## TR4 当前浮动补域可以直接减少第三腿

在当前未付正支，有

\[
 p_y\rho_0(v)[w_t(y,v)-h_0(v)]>K\sqrt n\,J_v,\qquad h_0\ge0,\quad0\le\rho_0\le1.
\]

因此在每个原非零正行上

\[
 \frac{KJ_v}{p_yw_g(y,v)}
 <\frac{\rho_0(v)}{\sqrt n}\frac{w_t(y,v)}{w_g(y,v)}.
\]

若实际 `(x,y,v,t)` 满足

\[
 \mathcal A=\{w_t(y,v)/w_g(y,v)\le\sqrt n\}, \tag{TR9}
\]

则KJ_v<p_yw_g。原good `p_yw_g≤(K/3)(K1v+K2v+Jv)` 立即给

\[
 \boxed{p_yw_g\le\frac K2(K_{1v}+K_{2v}),\qquad
 p_y\le\sqrt{K/2}\frac{\sqrt{p_yK_{1v}}+\sqrt{p_yK_{2v}}}{\sqrt{w_g}}.} \tag{TR10}
\]

这是实际正门与浮动补域共同给出的点态结论，负项不补此门。若capture/history依hard z，先在每个非零原z行证明；由于ρ≤1，结论不依z，故原η平均亦保留。TR9含整个TR8终端带，还可包含较早clock的部分source；不把全source变成terminal good，也不重领R218已付带。

TR10的作用是：在这个**原全尺度联合资格**下，第三腿无需出现，两个同soft腿的QG系数不退化。它只减腿；其余两腿的receiver/source/clock仍要结算。TR7/8是另一种对正J分量的真实付款，两种方式不能对同一个J分量重复登记。

## TR5 QG的完整时钟收益：含上端薄层

以下使用本轮已审核QG：对固定全部物理参数和来源位置，有
`D_m²≤1−κ(1−ω_m)`，κ>0。本节不重复标量证明。若只得弱双soft版本，必须使用该腿实际κ；不能把J腿的退化s因子丢掉。本轮独审已核全域κ=25/2^68，按其固定参数积分范围引用。

固定 θ=(L,R,s,A,σ,j)，`m=min(L,R)`、`M=max(L,R)`，`ζ=c_jg/m∈[1,γ]`。原D与D_m满足逐坐标

\[
 D_i=\zeta^{-1}D_{m,i}\sqrt{\omega_{m,i}/\omega_{\zeta m,i}}
 \le\zeta^{-1/2}D_{m,i}\le D_{m,i}.
\]

因此带原h_R的固定参数receiver积分（也可保原B扣除）给

\[
 \int\frac{h_R(x-z)\sqrt{P_{s,L}(x-y)P_{\sigma,A}(x-v)}}{\sqrt{w_g(y,v)}}dx
 \le(c_j/g)^n\exp\!\left[-\frac\kappa2\sum_i(1-\omega_{m,i})\right]. \tag{TR11}
\]

这是积分界，不是逐点x界。若 `c_jt<m`，每个原 `α_i<t` 坐标满足 `1−ω_m,i≥1−c_jt/m`，故指数至少控制 `k_t(v)(1−c_jt/m)`。令r=c_jt/m，原clock满足

\[
 a/m\le r\le c_jg/m=\zeta\le\gamma,\qquad a/m\ge1/2.
\]

不假设score各坐标独立，不假设Π_t单调；对任意合法时变原Π_t，先在每个t用其概率归一，再用δ≤k_t(v)和整数0≤k≤n，得到完整clock上界

\[
 \boxed{\int_{a/c_j}^{g}\iint\delta_t
 e^{-(\kappa/2)k_t(v)(1-c_jt/m)_+}\,d\Pi_t(v)d\Pi_t(u)\frac{dt}{t}
 \le G_\kappa(n):=1+\frac4{\kappa e}\left[1+\log_+\left(\frac{\kappa e n}{4}\right)\right].} \tag{TR12}
\]

积分仅在原合法Π上取值，其他时刻置零。证明：r<1时
`k exp[−κk(1−r)/2]≤min(n,2/[κe(1−r)])`，且dr/r≤2dr。令u=1−r，积分≤`2∫_0^(1/2)min(n,2/(κeu))du`，在u=2/(κen)分割恰得右边第二项；该点≥1/2时用n≤4/(κe)。上端1≤r≤γ没有指数收益，其费用是 `n logγ≤1`，恰为TR12第一项，没有漏掉该薄层。因而固定状态中的n log2时钟费可降为Oκ(1+logn)。

TR11之后才可用TR12；不能把TR11塞回原被积函数而进行逐点clock计算。若物理参数随x变化，固定状态的receiver积分尚需合法共同包络；本稿未由TR12消掉它。也不能删掉原hard h_R后再调用TR11。

## TR6 历史比较与剩余实际范围

窄读 [R170 soft_threshold_energy.md:123–181](/Users/zhengzhihao/Desktop/T/output/centered_cube_round170_20261016_final_checkpoint/soft_threshold_energy.md:123)：旧terminal-ratio工具使用冻结测试A≤χ_J、时间独立筛选，以及其GG/GE/suffix/reverse的完整signed资格，将边界与删除合并成e^M Jν/e_g来源价。TR3/4不采用该测试或任何signed抵消，不要求排序、suffix零费或GG/GE有符号，直接处理当前原正半密度分量/实际good门。因此它不把旧R170条件分支重新登记为无条件分支；反向、删除、suffix及边界负账均未消费。

本轮已实际推进的是TR7/8与TR1a绑定的全参数原正子交通费用及TR10的原浮动补域两腿化；不是QG标量的重复证明。仍未结算：

* U1/U2的目标核随原x选择。TR3同样给其同x Cauchy上界，但最后出现实际移动列 `(K_{a,x}*ν_V)(x)`，固定J的列归一不能移交；QG积分缺口不直接控制其参数上确界或硬边界变差。
* 更早clock与TR9补集的原J分量；已审主QG的全κ可用TR12降低固定参数clock费，但不能免费把全部自适应状态变固定。
* 全部剩余仍须保唯一V/j、实际接收域、同一y的两Π、η承载的clock/history、current浮动补域。不能在三腿正上放以后给每腿各分配一份原负信用，不能再次使用已领hard帽或R218旧价。

因此尚未宣称一般弱型或全部原正量闭合。本文停止于全实际尺度的上述J分量付款、两腿化及完整QG时钟接口，不以微带/胞数条件桥替代下一步联合占用。

本机实际Fraction核对8组有限共同源矩阵下TR3的完整分母Cauchy两平方因子、high列方向、TR7/8的Young系数以及64组可测分配代数；这些只作代数核验，一般测度证明为上述显式Cauchy/FIRST/固定J列，未把有限样本当FULL或QG证书。
