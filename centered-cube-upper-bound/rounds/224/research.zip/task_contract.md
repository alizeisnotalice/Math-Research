# R224：共同重叠的阈值缺口与原交通回代

起始HEAD feaa6d0d52764bf2112bb62e8017e97089d235cb，工作区干净。原一般根阶目标未闭合。本轮避免将强高斯尾猜想当必要工具；只筛选有实际几何来源的定量缺口，同时保留其原交通费用。

候选QG：b>0，L,R∈[b/2,b]，A∈[L,b]，m=min(L,R)，M=max(L,R)，独立s,σ∈[0,1]，y,v,z∈R。C、f为原核，ω_m=min(1,bC(|v−y|/b)/m)。I=R^−1∫_{z−R/2}^{z+R/2}sqrt(L^−1 f_s((x−y)/L) A^−1 f_σ((x−v)/A))dx。R220已证 D_m=M I/sqrt(ω_m)≤1。待筛：存在绝对κ>0使 D_m²≤1−κ(1−ω_m)。这仅是候选，不将采样支持当证明。若该精确弱线性形式不合适，按真实几何修改，禁止先强加高斯尾。

实际时钟 α_i=b C_i/c_j，k_t(v)=Σ1_{α_i<t}。在c_j t<m上，Σ(1−ω_m,i)≥k_t(v)(1−c_j t/m)。若QG成立，张量给 exp(−κ k_t(v)(1−c_jt/m)/2) 缺口；δ≤k_t(v)。可能的时钟收益必须连同固定状态积分、自适应L/R/s、全硬来源、原β及两Π、唯一j和真实dx一起回代。严禁将固定状态x积分的缺口视为逐点x界，严禁删全νz后再借hard核，严禁重复R222硬帽。

可用已证工具：R220全部尺度D≤1、SG4/6/13各明确上界和V(t)≤23/25(1+t)^−2证书；R222实际H_R/q≤16/3、0≤aω≤1及条件平均；R223准确原signed账（本轮不重做）。来源：/Users/zhengzhihao/Desktop/T/output/centered_cube_round220_20261016_final_checkpoint/scaled_geometry.md；R222 source_occupancy.md；R223 negative_contract.md，均同父output目录。无ν≤β、无来源独立、无任意单行根阶variance，未知来源/selector预算不得假定。

任务：peak负责threshold_gap.md准确标量几何与原量关联；compare负责traffic_reentry.md从原母式直接检查可能的时钟结算和来源/selector费用，不重复标量证明；audit先独立筛命题再读作者；numeric负责真实C/f核的三阶段数值、实现与复现。全部非独占目录、不得改别人文件/Git/spawn/PDF；有限交付后停止。成功必须给独审通过的新估计并明确实际原预算用途；仅固定核结果不能宣称一般闭合。失败只记录必要原因，不无限反例搜索。
