#!/usr/bin/env python3
"""R224 finite physical QG exploration, not a proof or global optimizer."""
import argparse,hashlib,json
from decimal import Decimal
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent
NODES={};CACHE={}
SOURCE_FINGERPRINTS={'task_contract.md': '6493c8f5d547f0370e23d9e7f52a1684004469fdeb38466b306d29a1c420d8d1', 'R220_frozen_scaled_probe.py': '8a8af32fa89d4871fd765708ebd67734a41c86d188e06e6837bcaea42606df0e'}
def phi(x):
    x=abs(x);h=mp.mpf('.5')
    def E3(t):return mp.mpf('.5') if not t else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
    return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def fs(x,s):return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi(x)
def primitiveF(x):
    sg=mp.sign(x);t=abs(x);h=mp.mpf('.5')
    return x if t<=h else sg*(h-mp.expint(4,t-h)+mp.expint(4,t+h)+mp.mpf(1)/3-mp.expint(4,1))
def C(d):return primitiveF(mp.mpf('.5')-abs(d))-primitiveF(-mp.mpf('.5')-abs(d))
def text(x):return mp.nstr(x,55)
def probe(cfg,dps=25,degree=48):
    key=tuple(cfg)+(dps,degree)
    if key in CACHE:return CACHE[key]
    with mp.workdps(dps):
      L,R,A,s,sigma,d,z=map(mp.mpf,cfg);m=min(L,R);M=max(L,R);cv=C(d);omega=min(1,cv/m)
      assert mp.mpf('.5')<=L<=1 and mp.mpf('.5')<=R<=1 and L<=A<=1 and 0<=s<=1 and 0<=sigma<=1
      if (dps,degree) not in NODES:NODES[dps,degree]=mp.gauss_quadrature(degree,'legendre')
      nodes,weights=NODES[dps,degree];lo=z-R/2;hi=z+R/2;cuts=sorted(set([lo,hi]+[x for x in (-L/2,L/2,d-A/2,d+A/2,mp.mpf(0),d) if lo<x<hi]));I=mp.mpf(0)
      for a,b in zip(cuts,cuts[1:]):
        mid=(a+b)/2;half=(b-a)/2
        I+=half*sum(w*mp.sqrt(fs((mid+half*q)/L,s)*fs((mid+half*q-d)/A,sigma)/(L*A)) for q,w in zip(nodes,weights))/R
      D2=M*M*I*I/omega;ratio=(1-D2)/(1-omega) if omega<1 else None
      out={'parameters':dict(zip(('L','R','A','s','sigma','v','z'),cfg)),'b':'1','y':'0','dps':dps,'degree':degree,'m':mp.nstr(m,dps),'M':mp.nstr(M,dps),'C':mp.nstr(cv,dps),'omega_m':mp.nstr(omega,dps),'I':mp.nstr(I,dps),'D_m_squared':mp.nstr(D2,dps),'one_minus_D_m_squared':mp.nstr(1-D2,dps),'one_minus_omega_m':mp.nstr(1-omega,dps),'gap_ratio_if_nonsaturated':mp.nstr(ratio,dps) if ratio is not None else None,'D_m_squared_le_one_numerical':D2<=1,'cuts':[mp.nstr(x,dps) for x in cuts]}
    CACHE[key]=out;return out

def ratio_key(row):return Decimal(row['gap_ratio_if_nonsaturated']) if row['gap_ratio_if_nonsaturated'] is not None else Decimal('Infinity')
def boundary(m0):
    with mp.workdps(70):
      m=mp.mpf(m0)
      if m==1:return '0',mp.nstr(C(0)-m,60)
      lo=mp.mpf(0);hi=mp.mpf(2)
      for _ in range(200):
        mid=(lo+hi)/2
        if C(mid)>m:lo=mid
        else:hi=mid
      root=(lo+hi)/2;return text(root),mp.nstr(C(root)-m,60)
def contexts(scales,softs,ds):return [(L,R,A,s,sigma,d) for L,R,A in scales for s,sigma in softs for d in ds]
def positions(d,kind):
    with mp.workdps(60):
      d=mp.mpf(d)
      return [text(x) for x in ([0,d/2,d] if kind=='three' else [-mp.mpf('.5'),0,d/2,d,d+mp.mpf('.5')])]
def cfg_from_row(row):
    with mp.workdps(60):return tuple(text(mp.mpf(row['parameters'][name])) for name in ('L','R','A','s','sigma','v','z'))

def main(output):
    general_scales=[('1','1','1'),('.5','1','.5'),('.5','1','1'),('1','.5','1'),('.75','1','1'),('1','.75','1')]
    stages=[];general=[]
    for ctx in contexts(general_scales,[('.02','.9'),('.9','.02'),('1','1')],['1.25']):
      general.extend(probe(ctx+(z,)) for z in positions(ctx[-1],'three'))
    stages.append({'stage':'general_independent_soft','cases':general});print('general',len(general),flush=True)
    boundary_meta=[];edge=[]
    for L,R,A in general_scales[:5]:
      with mp.workdps(70):m0=text(min(mp.mpf(L),mp.mpf(R)))
      root,residual=boundary(m0)
      with mp.workdps(60):d=text(mp.mpf(root)+mp.mpf('1e-5'))
      boundary_meta.append({'L':L,'R':R,'A':A,'m':m0,'root_C_equals_m_approx':root,'C_minus_m_at_root_approx':residual,'v_used_root_plus_1e_minus5':d})
      for s,sigma in [('0','0'),('.000001','1'),('1','.000001'),('1','1')]:
        edge.extend(probe((L,R,A,s,sigma,d,z)) for z in positions(d,'three'))
    stages.append({'stage':'near_C_equals_m_degenerate_soft','boundary_roots':boundary_meta,'cases':edge});print('edge',len(edge),flush=True)
    tail=[]
    tail_scales=[('1','1','1'),('.5','1','1'),('1','.5','1'),('.75','1','1')]
    for ctx in contexts(tail_scales,[('1','1'),('.000001','1')],['4','8']):tail.extend(probe(ctx+(z,)) for z in positions(ctx[-1],'five'))
    stages.append({'stage':'tail_and_z_nested_search','initial_cases':tail,'local_searches':[]});print('tail',len(tail),flush=True)
    unique_contexts=[];seen=set()
    for row in sorted(tail,key=ratio_key):
      ctx=cfg_from_row(row)[:-1]
      if ctx not in seen:unique_contexts.append(row);seen.add(ctx)
      if len(unique_contexts)==2:break
    localrows=[]
    for seed in unique_contexts:
      ctx=cfg_from_row(seed)[:-1];best=seed;rounds=[]
      for radius in ('.5','.125'):
        with mp.workdps(60):zs=[text(mp.mpf(best['parameters']['z'])+mp.mpf(radius)*mp.mpf(i)/4) for i in range(-4,5)]
        samples=[probe(ctx+(z,)) for z in zs];best=min(samples+[best],key=ratio_key);rounds.append({'radius':radius,'cases':samples,'best':best});localrows.extend(samples)
      stages[-1]['local_searches'].append({'seed':seed,'rounds':rounds,'best_local':best,'scope':'Finite 9+9 point local search, not certified global optimization.'})
    allrows=general+edge+tail+localrows;unique={cfg_from_row(row):row for row in allrows}
    dangerous=sorted(unique.values(),key=ratio_key)[:6];refinements=[]
    for idx,low in enumerate(dangerous):
      cfg=cfg_from_row(low);runs=[low,probe(cfg,40,96)]
      if idx<2:runs.append(probe(cfg,60,192))
      with mp.workdps(70):differences=[{'dps':r['dps'],'D2_absolute_difference_from_final':text(abs(mp.mpf(r['D_m_squared'])-mp.mpf(runs[-1]['D_m_squared']))),'ratio_absolute_difference_from_final':text(abs(mp.mpf(r['gap_ratio_if_nonsaturated'])-mp.mpf(runs[-1]['gap_ratio_if_nonsaturated'])))} for r in runs[:-1]]
      refinements.append({'runs':runs,'differences_from_final':differences})
    finalbest=min((row['runs'][-1] for row in refinements),key=ratio_key)
    result={'schema':'R224_physical_gap_probe_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'source_fingerprints':SOURCE_FINGERPRINTS,'stages':stages,'unique_low_precision_config_count':len(unique),'refinement_cases':refinements,'minimum_observed_refined_gap_ratio':finalbest['gap_ratio_if_nonsaturated'],'minimum_observed_refined_parameters':finalbest['parameters'],'any_D2_greater_than_one_observed':any(not r['D_m_squared_le_one_numerical'] for r in allrows+[run for ref in refinements for run in ref['runs']]),'scope':['Ordinary quadrature probe, no directed interval bounds or universal kappa certification.','Ratio reported only for omega_m<1; finite observed minimum is not a lower bound over the full parameter domain.','Independent softs and actual C,phi,f kernels retained; source integration uses normalized hard_R and all endpoints are split.','Nested z search is finite, local and not a global optimizer.','No original traffic reentry, source/selector budget, dimension-order fit, or FULL claim.','All integration domains are finite; no infinite tails omitted.']}
    output.write_text(json.dumps(result,indent=2)+'\n');print('minimum refined ratio',result['minimum_observed_refined_gap_ratio'],result['minimum_observed_refined_parameters'],flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'gap_probe.json');args=ap.parse_args();main(args.output)
