#!/usr/bin/env python3
"""R224 finite exact J-band algebra and two Cauchy factors, not FULL."""
import argparse,hashlib,json
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
HERE=Path(__file__).resolve().parent
PROOF_SOURCE_SHA256='cb23489cbf78736d8379c26daf062737171b9f100946fc7bb8573a9cd71c7cde'
def rat(x):return f'{x.numerator}/{x.denominator}'
def summary(x,small):
    out={'sha256_hex_fraction':hashlib.sha256((format(x.numerator,'x')+'/'+format(x.denominator,'x')).encode()).hexdigest(),'sign':(x>0)-(x<0),'numerator_bits':abs(x.numerator).bit_length(),'denominator_bits':x.denominator.bit_length()}
    if small:out['exact']=rat(x)
    return out
def ceil_root(x):
    q=isqrt(x.numerator//x.denominator)
    return q if F(q*q)>=x else q+1

def model(n,troot,q,mode):
    t=troot*troot;g=F(1);K=F(3);nu=[F(1),F(1,4),F(4,9),F(1,16)];Jroot=[F(1,2),F(3,4),F(1),F(1,3)];J=[x*x for x in Jroot];clock=[]
    for y in range(3):
      ks=[0,max(0,n//2-y),n,max(1,n//3)];qs=[F(1),F(1,2),F(2,3),F(1,3)];wtr=[qs[v]**ks[v] for v in range(4)];wgr=[(troot*qs[v])**ks[v] for v in range(4)];wt=[x*x for x in wtr];wg=[x*x for x in wgr];et=sum((nu[v]*wt[v] for v in range(4)),F(0));eg=sum((nu[v]*wg[v] for v in range(3)),F(0))
      rootp=F(1,100) if mode=='high_zero' or (mode=='mixed' and y==2) else F(ceil_root(2*K*q/eg)*(y+1));p=rootp*rootp;high=p*eg>=2*K*q
      clock.append({'y':y,'ks':ks,'qs':qs,'wtr':wtr,'wgr':wgr,'wt':wt,'wg':wg,'et':et,'eg':eg,'rootp':rootp,'p':p,'high':high})
    shares=[F(1,2),F(1,3),F(1,6)];betas=[F(0) if mode=='beta_zero' else q*shares[y]/clock[y]['p'] for y in range(3)];FIRST=sum((clock[y]['p']*betas[y] for y in range(3)),F(0));QJ=sum((nu[v]*J[v] for v in range(4)),F(0));A=F(0);factor1=F(0);factor2=F(0);highbeta_et=F(0);records=[];allocation=[]
    rootK1=F(ceil_root(3*max(row['p'] for row in clock)/K)+1);K1=rootK1*rootK1
    for row,beta in zip(clock,betas):
      y=row['y'];et=row['et'];eg=row['eg'];p=row['p'];Pi=[nu[v]*row['wt'][v]/et for v in range(4)];assert sum(Pi,F(0))==1 and et>=eg
      contributions=[]
      for v in range(4):
        ratio=row['wt'][v]/row['wg'][v];assert ratio<=(g/t)**n
        # Each active alpha=t*qs^2; remaining alpha=1. Product min weights have exact rational roots.
        checkwt=(min(1,t*row['qs'][v]**2/t))**row['ks'][v];checkwg=(min(1,t*row['qs'][v]**2))**row['ks'][v]
        assert checkwt==row['wt'][v] and checkwg==row['wg'][v]
        rootK2=F(v+1);den=rootK1+rootK2+Jroot[v];weights=[rootK1/den,rootK2/den,Jroot[v]/den];positive=row['rootp']*row['wgr'][v]
        assert sum(weights,F(0))==1 and sum((a*positive for a in weights),F(0))==positive and p*row['wg'][v]<=K/3*(K1+rootK2**2+J[v])
        assert (weights[2]*positive)**2<=K/3*J[v]
        allocation.append({'y':y,'v':v,'weights':[rat(a) for a in weights],'sum_one':True,'positive_allocation_identity':True,'good_condition':True,'allocated_J_single_leg_squared_bound':True})
        if row['high']:A+=beta*Pi[v]*row['rootp']*Jroot[v]/row['wtr'][v]
        contributions.append({'v':v,'nu':rat(nu[v]),'J':rat(J[v]),'active_alpha':rat(t*row['qs'][v]**2),'active_count':row['ks'][v],'remaining_alpha':'1/1','remaining_count':n-row['ks'][v],'in_Z_t':True,'in_Z_g':v<3,'wt':summary(row['wt'][v],n<=16),'wg':summary(row['wg'][v],n<=16),'Pi_t':summary(Pi[v],n<=16),'wt_over_wg_le_g_over_t_power_n':True})
      if row['high']:
        highbeta_et+=beta/et;factor1+=p*beta;factor2+=beta/et*QJ
        assert beta/et<=p*beta/(2*K*q)
      records.append({'y':y,'p':rat(p),'beta':rat(beta),'high':row['high'],'p_eg_ge_2Kq':row['high'],'et':summary(et,n<=16),'eg':summary(eg,n<=16),'et_ge_eg':et>=eg,'bad_subset_probability':summary(Pi[1],n<=16),'bad_probability_le_one':Pi[1]<=1,'sources':contributions})
    checks={'FIRST_sum_p_beta_le_q':FIRST<=q,'high_beta_over_et_le_one_over_2K':highbeta_et<=1/(2*K),'first_Cauchy_exact_square':A*A<=factor1*factor2,'first_factor_le_q':factor1<=q,'second_factor_le_QJ_over_2K':factor2<=QJ/(2*K),'A_squared_le_q_QJ_over_2K':A*A<=q*QJ/(2*K),'all_allocation_rows':all(r['allocated_J_single_leg_squared_bound'] for r in allocation)};assert all(checks.values())
    vals={'t':t,'g':g,'q':q,'K':K,'FIRST_sum_p_beta':FIRST,'high_beta_over_et':highbeta_et,'A':A,'A_squared':A*A,'Cauchy_factor1':factor1,'Cauchy_factor2':factor2,'factor_product':factor1*factor2,'QJ_same_x_full_Z_t':QJ,'q_QJ_over_2K':q*QJ/(2*K)}
    return {'n':n,'mode':mode,'values':{k:summary(v,n<=16) for k,v in vals.items()},'t_exact':rat(t),'q_exact':rat(q),'K_exact':rat(K),'receiver_rows':records,'allocation_rows':allocation,'checks':checks,'scope':'Finite y/v data; common J_v,nu_v and full et retained; arbitrary thresholds and assigned high/FIRST data are not actual full-input/posterior qualifications.'}

def receiver_union(mode):
    mu=[F(1,2),F(2,3),F(3,4)] if mode!='zero_measure' else [F(0)]*3;rootsJ=[F(1),F(2),F(3)] if mode!='zero_column' else [F(0)]*3;rootsq=[F(1,2),F(1),F(3,2)];lam=F(9,4);measure=sum(mu,F(0));column=sum((mu[i]*rootsJ[i]**2 for i in range(3)),F(0));W=column+1;S=sum((mu[i]*rootsJ[i] for i in range(3)),F(0));weighted=sum((mu[i]*rootsq[i]*rootsJ[i] for i in range(3)),F(0))
    checks={'disjoint_union_Cauchy':S*S<=measure*column,'column_integral_le_Wnu':column<=W,'q_le_lambda':all(x*x<=lam for x in rootsq),'weighted_squared_le_lambda_measure_Wnu':weighted**2<=lam*measure*W};assert all(checks.values())
    return {'mode':mode,'disjoint_receiver_labels':['E_V1j1','E_V1j2','E_V2j1'],'mu':[rat(x) for x in mu],'sqrt_Jnu':[rat(x) for x in rootsJ],'sqrt_q':[rat(x) for x in rootsq],'lambda':rat(lam),'measure_E':rat(measure),'column_integral':rat(column),'Wnu':rat(W),'sum_mu_sqrt_Jnu':rat(S),'weighted_sum':rat(weighted),'X_lambda_measure':rat(lam*measure),'checks':checks,'scope':'Finite disjoint receiver-sum analogue; not an actual adaptive receiver partition or normalized kernel input.'}
def constant_checks():
    rows=[]
    for Lam in (F(1),F(3,2),F(2)):
      c_squared=F(32,3)**2*Lam*Lam/6;young=c_squared/4;assert young==F(128,27)*Lam*Lam
      for eps in (F(1,4),F(1)):
        for X,Y in ((F(0),F(1)),(F(1),F(0)),(F(1),F(1,4)),(F(4),F(9))):
          rhs=eps*X+young/eps*Y;assert c_squared*X*Y<=rhs*rhs
          rows.append({'Lambda':rat(Lam),'epsilon':rat(eps),'X':rat(X),'Y_d_squared_exp_d_W_symbolic':rat(Y),'single_leg_constant_squared':rat(c_squared),'Young_coefficient_before_1_over_epsilon':rat(young),'equals_128_Lambda_squared_over_27':True,'Young_squared_check':True})
    return rows

def absorption(n):
    assert isqrt(n)**2==n
    rootn=F(isqrt(n));troot=1-F(1,8*n);t=troot*troot;B=t**(-n);K=F(3);P=F(1);J=B/(2*K*rootn);S=1-J;E=B/rootn
    assert E<3 and S>0;assert B>K*rootn*J and P<=K/3*(S+J) and K*J<E*P and P<=K/(3-E)*S
    return {'n':n,'t':rat(t),'g':'1/1','rho':'1/1','h0':'0/1','K':'3/1','p_wg':'1/1','B_g_over_t_power_n':summary(B,n<=16),'J':summary(J,n<=16),'K1_plus_K2':summary(S,n<=16),'E_B_over_sqrt_n':summary(E,n<=16),'checks':{'floating_complement_strict':True,'good_condition':True,'E_lt_three':True,'KJ_lt_E_pwg':True,'pwg_le_K_over_three_minus_E_times_K1K2':True},'scope':'Exact scalar absorption data; no actual spatial/kernel-history realization.'}
def soft_coefficient_and_constants():
    count=0;checksum=hashlib.sha256();min_slack=None;max_slack=F(0)
    for i in range(65):
      for j in range(65):
        s=F(i,64);sigma=F(j,64);a=(1-s)*(1-sigma);tau=s*sigma;b1=(1-s)*sigma;b2=s*(1-sigma);t0=a+tau
        assert b1*b2==a*tau and 4*a*tau<=t0*t0 and a+b1+b2+tau==1
        assert b1+b2==1-t0 and t0>=0
        slack=t0*t0-4*a*tau;min_slack=slack if min_slack is None else min(min_slack,slack);max_slack=max(max_slack,slack)
        checksum.update(('|'.join([str(i),str(j)]+[rat(x) for x in (a,tau,b1,b2,slack)])+'\n').encode());count+=1
    k0=F(25,2**19);eps=F(1,2**22);kappa=F(25,2**68);cutoff=eps*eps/32
    checks={'kappa0_exact':k0==F(25,2**19),'epsilon_c_exact':eps==F(1,2**22),'kappa_exact':kappa==F(25,2**68),'kappa0_epsilon_c_squared_over_32_equals_kappa':k0*cutoff==kappa,'kappa_le_epsilon_c_over_4':kappa<=eps/4,'one_over_8_times_513_squared_gt_epsilon_c':F(1,8*513**2)>eps,'25_over_23_gt_41_over_40':F(25,23)>F(41,40),'11_over_4_power4_lt_64':F(11,4)**4<64,'11_over_4_power3_lt_32':F(11,4)**3<32,'small_t0_sqrt_bound_squared':2*cutoff<=eps*eps/16,'sqrt_one_minus_epsilon_le_one_minus_half_epsilon_squared':1-eps<=(1-eps/2)**2}
    assert count==4225 and all(checks.values())
    return {'grid_count':count,'s_sigma_recipe':'independent i/64,j/64 for i,j=0,...,64','a':'(1-s)*(1-sigma)','tau':'s*sigma','b1':'(1-s)*sigma','b2':'s*(1-sigma)','identities_checked':['b1*b2=a*tau','4*a*tau<=(a+tau)^2','a+b1+b2+tau=1','sqrt(b1)+sqrt(b2)<=1 via nonnegative squaring'],'grid_summary_sha256':checksum.hexdigest(),'minimum_t0_squared_minus_4a_tau':rat(min_slack),'maximum_t0_squared_minus_4a_tau':rat(max_slack),'constants':{'kappa0':rat(k0),'epsilon_c':rat(eps),'kappa':rat(kappa),'t0_cutoff_epsilon_c_squared_over_32':rat(cutoff),'one_over_8_times_513_squared':rat(F(1,8*513**2))},'constant_checks':checks,'scope':'Pure Fraction coefficient/constant implementation checks; no physical geometry or general proof certified by this grid.'}

def main(output):
    menus=[('initial',[(1,F(1,2),F(1),'all_high'),(1,F(3,4),F(1),'mixed'),(4,F(1,2),F(1),'all_high'),(4,F(3,4),F(1),'mixed')]),('zero_gate_pressure',[(n,F(7,8),F(2,3),mode) for n in (16,64) for mode in ('high_zero','beta_zero','mixed')]),('expanded',[(n,1-F(1,8*n),F(3,2),'mixed') for n in (1000,10000)])];stages=[]
    for name,configs in menus:
      rows=[model(*cfg) for cfg in configs];stages.append({'stage':name,'cases':rows});print(name,len(rows),'exact cases passed',flush=True)
    result={'schema':'R224_J_band_finite_exact_checks_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'proof_source_sha256':PROOF_SOURCE_SHA256,'arithmetic':'Fraction and integers; all square roots in first Cauchy chosen exact rational','menu':'4 initial, 6 high/beta-zero pressure, 2 expanded n1000/10000 models','clock_models':stages,'second_Cauchy_receiver_union':[receiver_union(mode) for mode in ('ordinary','zero_measure','zero_column')],'rational_constant_and_Young_checks':constant_checks(),'soft_coefficient_grid_and_constants':soft_coefficient_and_constants(),'terminal_absorption_checks':[absorption(n) for n in (1,4,16,10000)],'allocation_zero_denominator_branch':{'K1':'0/1','K2':'0/1','J':'0/1','original_positive_integrand':'0/1','allocation_weights':['0/1','0/1','0/1'],'no_positive_copy_created':True},'scope':['Finite algebra checks only, not a proof of arbitrary legal-input payment or FULL closure.','All common y/v models preserve full Pi_t,et and future-deleted E source; high and FIRST constraints checked at the same point.','No arbitrary thresholds, gates or scalar absorption data are certified actual geometry/history/posterior input.','Terminal log-band relation (g/t)^n<=exp(d) and d/n cancellation are analytic interfaces; no numerical exp approximation used.','Large Fractions use canonical hex numerator/denominator hashes and bit lengths.','Original gap-probe files remain unchanged.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'j_band_checks.json');args=ap.parse_args();main(args.output)
