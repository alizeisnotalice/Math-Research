# R224：全部实际尺度、独立软度的共同重叠阈值缺口

**本轮独审已核验解析主链：合同 QG 成立，可取显式绝对常数 κ=25/2^68。** 证明使用 R220 已审核的全尺度常数一定理及标量证书，另证明 soft–soft 与 hard–soft 的严格余量。常数刻意粗取。固定参数张量化给实际 score 阈值缺口；这尚不支付原自适应接收、全部来源或双后验预算。

## 1. 定理与归一化

对任意 b>0，L,R∈[b/2,b]、A∈[L,b]、独立 s,σ∈[0,1] 及 y,v,z∈R，记 m=min(L,R)、M=max(L,R)，

\[
\omega_m=\min\{1,bC(|v-y|/b)/m\},\qquad
I=\frac1R\int_{z-R/2}^{z+R/2}
\sqrt{L^{-1}f_s((x-y)/L)A^{-1}f_\sigma((x-v)/A)}\,dx,
\quad D_m=\frac M{\sqrt{\omega_m}}I.
\]

则

\[
\boxed{D_m^2\le1-\kappa(1-\omega_m),\qquad \kappa=25/2^{68}.}
\tag{QG1}
\]

原核为 h=1_[−1/2,1/2]、φ_r=h*exp(−|·|/r)、φ=∫_0^1φ_r dr、f_s=(1−s)h+sφ；V=h*φ、C=h*max(h,φ)、A_0(d)=(1−|d|)_+。所有结论先固定全部参数。以 b 缩放并平移 y 后可取 b=1、y=0，d=|v|、α=A、r=R。D_m 无量纲，不损任何尺度因子。

使用 R220 SG6、SG13、SG18–22，并将其 c_j 取 θ=m/√(LR)。这只是核定理的合法参数，不改变原离散比例标签。R220 给 D_m≤1，并给：在 ω_m<1 时，

\[
\begin{array}{ll}
R\le L\text{ 或 }A\ge R:&
D_m^2\le\dfrac{M/A}{C(d)}[aA_0(d)+(\chi+R\tau)V(d)],\quad M/A\le1;\\[2mm]
R>L,\ A<R:&
D_m^2\le\dfrac R{C(d)}[aA_0(d/A)+(\chi+(R/A)\tau)V(d/A)].
\end{array}
\tag{QG2}
\]

其中 a=(1−s)(1−σ)、χ=(1−s)σ+s(1−σ)、τ=sσ。第二行所需的

\[
V(d/A)\le A C(d)
\tag{QG3}
\]

在当前非饱和域 C(d)<L≤A 全部成立：d≥A 用 R220 SG10，d<A 用其 SG18。同一证书还给 V(t)≤(23/25)(1+t)^−2，0≤t≤1。

## 2. soft–soft 的统一严格余量

对全部 x∈R、0<r≤1，

\[
\phi_{r/2}(x)\le\frac{27}{32}\phi_r(x).
\tag{QG4}
\]

证明可用偶性取 x≥0。若 x≤1/2，设 a_r=e^{-(1/2-x)/r}、b_r=e^{-(1/2+x)/r}，S=a_r+b_r，则

\[
\frac{\phi_{r/2}(x)}{\phi_r(x)}
=\frac{2-a_r^2-b_r^2}{2(2-a_r-b_r)}
\le\frac{2+S}{4}\le\frac{27}{32}.
\]

第一步使用 a_r²+b_r²≥S²/2；第二步由 (1−a_r)(1−b_r)≥0 得 S≤1+a_rb_r≤1+e^−1≤11/8。这里 e>8/3。若 x≥1/2，比值为 cosh(1/(2r))e^−x/r≤(1+e^−1/r)/2≤11/16。边界一致。

令 F(r)=φ_r(x)、G(r)=φ_r(y)，它们随 r 非减。由 covariance 精确恒等式，限制到 q≤r/2，得到

\[
\begin{aligned}
\int_0^1FG-\int_0^1F\int_0^1G
&=\int_{q<r}(F(r)-F(q))(G(r)-G(q))\,dq\,dr\\
&\ge\frac{(1-27/32)^2}{2}\int_0^1rF(r)G(r)\,dr\\
&\ge\frac{25}{4096}\int_0^1F(r)G(r)\,dr.
\end{aligned}
\]

最后一步是 r 与 FG 的单调 Chebyshev 不等式。逐 r 的三角不等式给 φ_r(x)φ_r(y)≤(h*h*exp(−|·|/r))(x+y)。非负积分后，设 ε_s=25/4096，有

\[
\boxed{\phi(x)\phi(y)\le(1-\varepsilon_s)V(x+y).}
\tag{QG5}
\]

因此 QG2 的 soft–soft 项 τ 可替为 (1−ε_s)τ，其他项不变。这在原单窗口 Cauchy 之前逐点使用，未把混合软度函数的凹性错当凸性。

## 3. 全尺度弱缺口：保留 a+τ

原 C≤1；d≤1 时 C−A_0=∫_(1/2)^(d+1/2)φ≥dφ(3/2)，且 1−C≤d。因此在非饱和域，ω_m=C(d)/m≥C(d)，有

\[
\frac{A_0(d)}{C(d)}\le1-\phi(3/2)(1-\omega_m).
\tag{QG6}
\]

d≥1 时 A_0=0，式子同样成立。另因 V 非增，d≤1 时 V(d)/C(d)≥V(1)，d≥1 时 V/C=1。限制混合 r∈[1/2,1] 及 h 的核心变量，所有相关距离≤2，故

\[
\phi(3/2),\ V(1)\ge\tfrac12e^{-4}>1/128.
\tag{QG7}
\]

最后使用 e<11/4、e^4<64。

在 QG2 第一支，应用 QG5，并放掉 M/A≤1、R≤1，得到

\[
D_m^2\le a\frac{A_0}{C}+\chi\frac VC+(1-\varepsilon_s)\tau\frac VC
\le1-a\phi(3/2)(1-\omega_m)-\varepsilon_s\tau V(1).
\]

第二支使用 QG3、R,A≤1 及 A_0(d/A)≤A_0(d)，得到

\[
D_m^2\le a\frac{A_0(d)}{C(d)}+\chi+(1-\varepsilon_s)\tau.
\]

饱和域右侧目标等于一，直接用 R220。因此全部尺度、独立软度满足

\[
\boxed{D_m^2\le1-\kappa_0(a+\tau)(1-\omega_m),
\qquad\kappa_0=25/2^{19}.}
\tag{QG8}
\]

此式已使共同软度 σ=s 的两条实际腿得到 κ_0/2 的 QG，但 J 腿 σ=1 在 s→0 时退化。下一节严格处理这两个 pure cross 端点，不遗漏第三腿。

## 4. hard–soft 端点的统一严格常数

本节证明，对 (s,σ)=(0,1) 或 (1,0)，所有尺度与位移均有

\[
\boxed{D_m^2\le1-\varepsilon_c,\qquad\varepsilon_c=2^{-22}.}
\tag{QG9}
\]

### 4.1 两个核的初等严格界

φ(0)≤9/10。事实上 r≤1 时，h 核心上 |u|≥1/4 的集合长1/2，且 1−e^−|u|/r≥1−e^−1/4≥1/5；故 1−φ_r(0)≥1/10，再对 r 积分。

此外

\[
-\frac{\phi'(x)}{\phi(x)}\ge1/16\qquad(x\ge1/4).
\tag{QG10}
\]

若 x∈[1/4,1/2]，只积 r∈[1/2,1]，

\[
-\phi_r'(x)=e^{-(1/2-x)/r}(1-e^{-2x/r})
\ge e^{-1/2}(1-e^{-1/2})\ge1/8.
\]

于是 −φ′≥1/16，且 φ≤1。若 x≥1/2，每个 φ_r 的尾 log 斜率为1/r≥1，积分后同样至少1。偶性给左尾版本。

### 4.2 保留窗口的严格 Cauchy

设 J 是长度 q≥1/2 的区间，H 是长度1的 hard 核心，I=J∩H 的长度为 ℓ。设 d_*≥3/4；在 H 上，与另一核心的距离至少 d_*−1/2≥1/4。因此 F=√φ(·−d_*) 在 I 上单调，且其 log 的绝对斜率至少1/32。

若 ℓ≤q/2，普通 Cauchy 已给 (∫_I F)²≤(q/2)∫_I F²。若 ℓ>q/2，则 ℓ≥1/4。将方向取为 F 递增，利用

\[
\ell\int_I F^2-\left(\int_I F\right)^2
=\int_{u<v}(F(v)-F(u))^2\,du\,dv,
\]

只取 v 在右半段、u≤v−ℓ/4。u 区间长至少ℓ/4，F(u)≤e^−ℓ/128 F(v)，而右半段至少含一半的 F² 质量。因此

\[
\left(\int_I F\right)^2
\le\left[1-\frac{(1-e^{-1/512})^2}{8}\right]\ell\int_I F^2
\le(1-\varepsilon_c)q\int_I F^2.
\tag{QG11}
\]

使用 e^x≥1+x 得 (1−e^−1/512)≥1/513，且 1/(8·513²)>2^−22。两种 ℓ 分支合并，QG11 对任意位置的 J 成立；无需居中最坏假设。交换 hard/soft 两端或反射不改变此式。

### 4.3 非饱和、R≤L 或 A≥R

若 d≤3/4，C−V=∫共同核心(1−φ)≥(1−φ(0))A_0(d)≥1/40。C≤1，故 V/C≤39/40。QG2 的 pure cross 系数给 D_m²≤39/40。

若 d≥3/4，重走 R220 SG6：先把两核径向放大到 b=1，再在长度 q=R≥1/2 的原窗口内使用 QG11，而非普通 Cauchy。pure cross 项的上界因此成为

\[
D_m^2\le(1-\varepsilon_c)\frac MA\frac{V(d)}{C(d)}\le1-\varepsilon_c.
\]

### 4.4 非饱和、R>L 且 A<R

设 t=d/A。若 t≥3/4，重走 R220 SG13，在尺度 A 上的窗口长 q=R/A∈(1,2]，QG11 同样适用。因此利用 QG3，

\[
D_m^2\le(1-\varepsilon_c)\frac{R V(t)}{C(d)}
\le(1-\varepsilon_c)RA\le1-\varepsilon_c.
\]

若 t≤3/4，由非饱和 C(d)<L≤A 以及 C(d)≥1−d，得 A>α_0=1/(1+t)。t=0 与非饱和矛盾。R220 证明 F_t(q)=qC(qt) 在 [α_0,1] 凹。在左端，严格证书给

\[
F_t(\alpha_0)\ge(1+t)^{-2}\ge\frac{25}{23}V(t)\ge\frac{41}{40}V(t).
\]

右端因 t≤3/4，有 C(t)−V(t)≥1/40，且 V(t)≤1，所以 F_t(1)≥(41/40)V(t)。凹函数不低于端点最小值，故

\[
\frac{V(d/A)}{A C(d)}\le40/41,
\quad D_m^2\le\frac{R V(t)}{C(d)}\le\frac{40}{41}RA\le40/41.
\tag{QG12}
\]

至此所有非饱和尺度均覆盖。

### 4.5 饱和域

对任意 soft 尺度 B∈[1/2,1]，其与 hard 窗口的平均满足

\[
\frac1R\int_{Q_R(z)}P_{1,B}(x-y)dx
\le\frac{1-1/64}{\max(B,R)}.
\tag{QG13}
\]

R≤B 时用 φ(0)≤9/10。R>B 时，区间在 B 归一化后长度≤2，其质量最多 ∫_[−1,1]φ。因 φ=h*w、h 归一，|w 的变量|≥3/2 必使卷积位置绝对值≥1；因此

\[
1-\int_{-1}^1\phi\ge\int_{|u|\ge3/2}w(u)du
=\int_0^1 2r e^{-3/(2r)}dr\ge\tfrac12e^{-3}>1/64.
\]

最后由 e³<(11/4)³<32。另一 hard 列仍用 R220 SG3 的 1/max。ω_m=1 时普通两列 Cauchy 给

\[
D_m^2\le(1-1/64)\frac{M}{\max(A,R)}\le1-1/64.
\]

这同时适用于 hard–soft 两种方向。结合4.3–4.4，QG9得证。

## 5. 独立混合软度的闭合

写四个非负系数

\[
a=(1-s)(1-\sigma),\quad b_1=(1-s)\sigma,\quad
b_2=s(1-\sigma),\quad\tau=s\sigma,
\quad t_0=a+\tau.
\]

它们和为一，且 b_1b_2=aτ。因此

\[
(\sqrt{b_1}+\sqrt{b_2})^2=1-t_0+2\sqrt{a\tau}\le1.
\tag{QG14}
\]

在原被积函数中直接使用 √(Σc_iF_i)≤Σ√c_i√F_i，然后积分。四个端点使用同一归一化 ω_m；hard–hard、soft–soft 端点由 R220≤1，两个 cross 端点由 QG9≤√(1−ε_c)。故

\[
D_m\le\sqrt a+\sqrt\tau+
\sqrt{1-\varepsilon_c}(\sqrt{b_1}+\sqrt{b_2})
\le\sqrt{2t_0}+\sqrt{1-\varepsilon_c}.
\tag{QG15}
\]

若 t_0≤ε_c²/32，右边≤ε_c/4+1−ε_c/2=1−ε_c/4。因此 D_m²≤1−ε_c/4。

若 t_0≥ε_c²/32，使用 QG8，得到

\[
D_m^2\le1-\frac{\kappa_0\varepsilon_c^2}{32}(1-\omega_m).
\]

由于 κ_0 ε_c²/32=25/2^68≤ε_c/4，两个分支共同证明 QG1。这里没有假定 D² 对混合系数凸；QG15 是逐点平方根三角上界，所有系数和归一化都显式保留。

## 6. 与原中间层及辅助时钟的准确关系

回到 b>0 及固定 n 维实际参数。令

\[
\omega_{m,i}=\min(1,bC(|y_i-v_i|/b)/m),\quad
\bar w_m(y,v)=\prod_i\omega_{m,i}.
\]

固定状态的张量乘积给

\[
\int h_R(x-z)\sqrt{P_{s,L}(x-y)P_{\sigma,A}(x-v)}dx
\le M^{-n}\sqrt{\bar w_m(y,v)}
\exp\left[-\frac\kappa2\sum_i(1-\omega_{m,i})\right].
\tag{QG16}
\]

原 c_j√(LR)=c_jg∈[m,γm]，原 w_g=\bar w_(c_jg)。归一化核 K_c=(g/c_j)^n h_R√(P_s,L P_σ,A)/√w_g 与 exact-min 核 K_m=M^n h_R√(P_s,L P_σ,A)/√\bar w_m 之比为

\[
\zeta^{-n}\sqrt{\bar w_m/\bar w_{\zeta m}}\le\zeta^{-n/2}\le1,
\qquad \zeta=c_jg/m\in[1,\gamma].
\]

因此 QG16 的指数缺口也控制原归一化共同核，没有额外指数菜单常数。原未归一核仍须保其 (c_j/g)^n 物理因子，不能据此免费删硬来源。

原 α_i=bC_i/c_j。如果 c_jt<m，每个被 k_t(v) 计数的坐标满足 ω_m,i<c_jt/m，因而

\[
\sum_i(1-\omega_{m,i})\ge k_t(v)(1-c_jt/m),\qquad
\delta_t=(k_t(v)-k_t(u))_+\le k_t(v).
\tag{QG17}
\]

所以固定状态在原阈值内侧获得 exp[−κ k_t(v)(1−c_jt/m)/2]。靠近 c_jt=m 的层不具有固定正缺口；c_jt≥m 的实际窄层不能遗漏。全部独立软度 QG 已包括第三条 J 腿 σ=1，尤其没有 s≈1/n 的系数退化。

QG16是对固定 L,R,A,s,σ 的 **x 积分**，不是逐点 x 上界。实际参数随 x 选择时，必须另有合法共同包络或保原共同来源的回代。原 β、两Π、bad端、capture/history、唯一j、全部hard来源及实际dx没有被 QG16 或 QG17支付。不能在 R222 已移除 h_R 的正式中再套一次本核定理，也不能另领16/3。时钟估计和回代费用由本轮 traffic_reentry.md 单独检查；本稿不宣称一般根阶或新原正子支已经结算。

## 7. 实际验证与范围

本轮实际使用本机 Python fractions.Fraction 核对：1/(8·513²)>2^−22、25/23>41/40、(11/4)^4<64、(11/4)^3<32、κ_0 ε_c²/32=25/2^68≤ε_c/4。对 s,σ∈{0,1/64,…,1} 的4,225组有理软度，精确验证四系数和为一、b_1b_2=aτ及4aτ≤(a+τ)²。全部通过。这仅是常数和系数代数核验；连续参数定理由上述解析证明与 R220 已独审严格证书支持，不以采样代替证明。

交付：全尺度、全独立软度 QG1 的作者证明及明确 κ；原中间层获得固定参数共同重叠的新阈值缺口，原完整交通付款仍须完成真实来源与自适应接收回代。
