# R497：闭质量窗给出的显式线性 log-mass 上解

保合同中同一真实父核 \(K_0\)、来源 \(\mu\)、中心测度 \(\nu=t\sigma|_{E_\tau}\)、uniform mark、原质量 \(m_A\) 与全窗 \([m_-,m_+]\)。令
\[
 c=rS,\qquad \beta=c/T,\qquad L=\log(m_+/m_-),\qquad K=\kappa T.
\]
本稿构造一个不含未知 Green 函数的显式上解。它确实控制整个原 scalar rank 目标，而非一个新局部分支；但其可计算头部 log-mass 费用尚不能付成根阶。没有宣布完整预算闭合。

## 1. 唯一候选及真实闭窗约束

候选为
\[
 \boxed{\Phi(\widehat B)=e^\beta
 \left[1+\beta\log\frac{m_+}{m_B}\right].} \tag{1}
\]
它只依实际父质量，可测、有界、\(\Phi\ge1\)，没有选取待定拟合常数。

固定来源 \(x\)，写
\(G_x(u)=\int_{m_A\le u}t(A)c_A(x)\sigma(dA)\le cu\)。真实 Lebesgue 中心 CDF 的证明同 R495，不是任意矩阵假设。含左端原子的 Stieltjes 公式给任意 \(m\le M\)
\[
 \rho_x\{m\le m_A\le M\}
 =\frac{G_x(M)}M-\frac{G_x(m-)}m
   +\int_m^M\frac{G_x(u)}{u^2}du
 \le c\left(1+\log\frac M m\right). \tag{2}
\]
因此，固定捕获 \(x\) 的输出 \(\widehat B\)，若输入祖先 \(\widehat A\succ\widehat B\)，令
\(a=v_x(\widehat A)-v_x(\widehat B)\)。所有中间 rank 属于闭质量窗 \([m_B,m_A]\)，所以
\[
 \log(m_A/m_B)\ge(a/c-1)_+,
 \qquad U_x-v_x(\widehat B)\le c(1+\ell_B),
 \quad\ell_B=\log(m_+/m_B). \tag{3}
\]
同质量 mark 的 rank 差可正，已由(2)的常数1支付；未误称严格质量下降。条件 rank 均值不要求父由 rank 唯一确定，(3)对每个实际祖先均成立。

## 2. 完整上解证明

用 R496 Palm adjoint 公式，对 \(K_0^*\Phi\) 保来源平均。删除输入 rank 门只增加正积分。固定 \((\widehat B,x)\)，令 \(D=c(1+\ell_B)\)。由(1)、(3)，
\[
 \Phi(\widehat A)\le
 \begin{cases}
 \Phi(\widehat B),&0\le a\le c,\\
 \Phi(\widehat B)-e^\beta(a-c)/T,&c<a\le D.
 \end{cases}
\]
右侧在整个扩张区间均非负，末端等于 \(e^\beta\)，故可将实际祖先 rank 域扩至 \([0,D]\)。准确积分为
\[
 \begin{aligned}
 (K_0^*\Phi)(\widehat B)
 &\le\int_0^c\Phi(\widehat B)e^{-a/T}\frac{da}{T}\\
 &\quad+\int_c^{c(1+\ell_B)}
 [\Phi(\widehat B)-e^\beta(a-c)/T]e^{-a/T}\frac{da}{T}\\
 &=\Phi(\widehat B)-1. \tag{4}
 \end{aligned}
\]
该上界不依来源，故对真实 \(\pi_B\) 平均后不变。\(\ell_B=0\) 时第二个积分为零，第一项仍给等式 \(e^\beta-1\)。所有质量原子和零来源行均合法。

于是 \(\Phi\ge1+K_0^*\Phi\)。正性迭代给每个有限 \(N\)
\[
 \Phi\ge\sum_{j=0}^{N-1}(K_0^*)^j1+(K_0^*)^N\Phi
 \ge\sum_{j=0}^{N-1}(K_0^*)^j1.
\]
取单调极限得到 \(G\le\Phi\)，没有省去符号不明的终端。特别得到整体显式帽
\[
 G(\widehat B)\le e^{rS/T}
 \left[1+\frac{rS}{T}\log\frac{m_+}{m_B}\right]. \tag{5}
\]
这是实际质量窗给出的 Volterra 上解，不是将 \(G\) 重新定义为某势；但仅改善 Green 帽常数与父质量依赖，并不自动给来源费用。

## 3. 同一原 head 目标的精确代价

沿原 \(b_R(\widehat A)=\pi_A\{v_x(\widehat A)<K\}\)，记
\[
 H_{\log}=\int\mu(dx)\int1_{\{v_x(\widehat A)<K\}}
 \log\frac{m_+}{m_A}\,\rho_x(d\widehat A).
\]
全部积分来自原场、无新后验或新历史。由(5)，完整 scalar rank 目标满足
\[
 \boxed{I\le e^\beta\bigl[KW+\beta H_{\log}\bigr].} \tag{6}
\]
结合 R496 已付 raw 空样本价，还严格有
\[
 R_\tau\le e^\beta\bigl[KW+\beta H_{\log}\bigr]
             +C_{\rm empty}W. \tag{7}
\]
(6)未丢原 head 来源门，不能以无门 receiver log 矩代替并称同价。

这一剩余费用是直接可计算的原质量分布积分，且有精确原子安全表达。令
\[
 F_x(u)=\rho_x\{m_A\le u\},\qquad
 C_K(u)=\int\min\{K,F_x(u)\}\,\mu(dx).
\]
因为 head 是同一增广 mass-rank 的初段，\(\{v<K\}\) 与质量前缀交的长度恰为 \(\min(K,F_x(u))\)。由正 layer-cake，
\[
 H_{\log}=\int_{m_-}^{m_+}\frac{C_K(u)}u\,du,
 \qquad
 C_K(u)\le\min\{KW,\nu(m_A\le u)\}. \tag{8}
\]
第二项用真实 \(\int c_A(x)\,d\mu=m_A\) 消掉分母，未将来源质量换成体积。式(8)保实际质量原子；在外层 Lebesgue \(du/u\) 中端点选择无影响。

现有合同仅给 \(H_{\log}\le KLW\)，代入(6)仍为
\(e^\beta K(1+\beta L)W\)。当 \(T\asymp\sqrt{L+1}\)、\(K=\kappa T\) 时，额外项约 \(rS\kappa LW\)，不是根阶。\(C_K(u)\) 单调非减，但不能无证明假设它在 log-mass 轴只占 \(O(T/(rS))\) 长度。原始高 rank/低共同捕获历史尚未给出对(8)的这种整体压缩；本上解中这些门只在允许的正上放处被删去。

因此本候选的准确决定是：**可保留显式上解(1)–(5)，但当前不据此追加付款。** 若沿此路线，所需新几何比较必须在原固定场上控制(8)的真实 head 质量谱，例如其足以使 \(e^\beta\beta H_{\log}\) 被可吸收 \(R_\tau\) 与根阶来源价共同覆盖；证明该比较之前，不能将(7)称为完整目标的改进。这里没有再开局部门或更换来源。

## 4. 本机精确核验

第一项符号计算验证(4)的缺口恰为1；其余核验含原子的 head 截断与(8)积分等式。有限质量表只验证 Stieltjes/rank 代数，不认证 native 中心场或完整原历史。

```python
import sympy as s
from fractions import Fraction as F
a,c,T,ell=s.symbols('a c T ell', positive=True)
beta=c/T
Phi=s.exp(beta)*(1+beta*ell)
upper=s.integrate(Phi*s.exp(-a/T)/T,(a,0,c))
upper+=s.integrate((Phi-s.exp(beta)*(a-c)/T)*s.exp(-a/T)/T,
                   (a,c,c*(1+ell)))
assert s.simplify(Phi-upper-1)==0
checks=1
for masses,jumps in [([1,2,5],[F(1),F(1),F(3)]),
                     ([1,4,8],[F(1,2),F(3,2),F(4)]),
                     ([2,3,7],[F(1),F(1),F(3)])]:
    cum=F(0)
    for m,g in zip(masses,jumps):
        cum+=g
        assert cum<=m
        checks+=1
    rho=[g/m for m,g in zip(masses,jumps)]
    for K in [F(1,3),F(1),F(5,2)]:
        direct=s.Integer(0); integral=s.Integer(0); rank=F(0)
        for i,(m,w) in enumerate(zip(masses,rho)):
            take=max(F(0),min(w,K-rank))
            direct+=s.Rational(take)*s.log(s.Rational(masses[-1],m))
            rank+=w
            if i+1<len(masses):
                integral+=s.Rational(min(K,rank))*s.log(s.Rational(masses[i+1],m))
        assert s.simplify(s.expand_log(direct-integral,force=True))==0
        checks+=1
print(f'{checks} symbolic/Fraction assertions PASS; supersolution and atomic head profile only.')
```

实际运行 stdout：`19 symbolic/Fraction assertions PASS; supersolution and atomic head profile only.`。一般上解由解析证明成立，不依靠有限探路。
