# R497：真实中心径向壳尝试的范围检查

准确输入为 R496 的 max-only 标量核 \(K_0\)、实际祖先势 \(G\)、mark 保留的低秩权 \(b_R\)，目标仍是
\[
 I=\int G(\widehat A)b_R(\widehat A)\,\widehat\nu(d\widehat A)
 \le a_0R_\tau+\epsilon X+C_\epsilon\sqrt n
 \operatorname{polylog}(n)W.
\]
本稿只尝试将高来源 rank 的真实中心边界占用，与同父低秩来源共同结算。没有证明新的整体费用；以下给出合法几何计算和失败发生的确切一步，不提出新局部门作为进展。

## 1. 共同 selector 下可严格执行的径向计算

固定真实来源 \(x\)，令 \(r_x(A)=2\|A-x\|_\infty\)。原捕获等价于 \(r_x(A)\le R_A\)，但每中心仅有原来一个选定边长 \(R_A\)；不得逐来源重选它。

对任意 \(0<\gamma\le1\)，实际 selector 满足
\[
 \frac{1_{r_x(A)\le\gamma R_A}}{R_A^n}
 \le \frac{1_{r_x(A)\le\gamma b}}{b^n}
 +\int_a^b\frac{n}{u^{n+1}}
           1_{r_x(A)\le\gamma u}\,du.
 \tag{1}
\]
这是固定 \(x,A\) 的单调包络，不是改变 \(R_A\)。积分真实 Lebesgue 中心后，闭端点基项也保留，得到
\[
 \int_E\frac{1_{r_x(A)\le\gamma R_A}}{R_A^n}\,dA
 \le\gamma^n A_n,\qquad A_n=1+n\log(b/a).
 \tag{2}
\]
故深内部 rank 贡献至多 \(S\gamma^nA_n\)。高来源 rank 的其余贡献确在各自实际 cube 的中心边界壳上。这没有使用 \(f\) 密度帽，也没有把来源质量换成薄层体积。

由于 \(\nu(dA)\pi_A(dx)=t(A)f(x)R_A^{-n}dA\,dx\)，(2) 可对完整来源积分。但对本轮真实停止量，准确式是
\[
 I=\int\mu(dx)\int_E\int_0^1
 \frac{t(A)}{R_A^n}c_A(x)
 1_{v_x(A,s)<\kappa T}G(A,s)\,ds\,dA.       \tag{3}
\]
\(G\) 是同一真实父和 mark 的累计到达势，不是可在中心包络外免费删去的概率。

## 2. 唯一尝试为什么尚不能结算全部积分

若在 (3) 的深内部仅使用已有 \(G\le\mathcal D\)，(2) 给
\[
 I_{\rm deep}(\gamma)\le
 S\mathcal D\gamma^nA_nW,
 \qquad \mathcal D=3+8rSL/T.                 \tag{4}
\]
选择 \(\gamma^n=(1+\mathcal D A_n)^{-1}\) 可使该部分不超过 \(SW\)。然而其补集仍是原实际低秩停止量的近边界来源部分，保全部 \(G\)、原 selector 和 mark。它不是小来源质量事件。再对它使用来源 rank 的一维初始段容量，仍只能得到
\[
 I\le\mathcal D\kappa TW
   =\kappa(3T+8rSL)W.                         \tag{5}
\]
因此 (4) 只是已知中心包络的局部应用，不作为本轮新增付款、不把补集改名后宣称取得几何改进。

失败的具体步骤是：对同一 \(x\)，rank 头部只控制
\(\int1_{v_x<\kappa T}t(A)c_A(x)R_A^{-n}dA\,ds\le\kappa T\)；
而大 \(G(A,s)\) 由 **其他真实来源** 在该父的后验混合后送入，头部条件并不控制这一权。在 (1) 的中心层饼中，去掉 \(G\) 会改变被积量；用 \(\sup G\) 又产生 (5)。同父后验不是中心壳上的均匀来源律，不能以 product 体积或“多数来源远离边界”补这一步。

具体尚缺的比较必须把两个事实同时用于同一个积分：低秩来源 \(x\) 的原初始段容量，以及给其父输入 \(G\) 的高祖先来源的真实中心覆盖。R496 已给其精确形式为
\[
 I=H_{\rm head}+(e^\kappa-1)E_{\rm empty}
       +\mathcal C_{\rm source}.
\]
径向壳计算没有控制最后两项的共同有符号价格；它也不允许分别删除它们。小空点停止费用仍带 \(e^\kappa\) 放大，不能作为这里缺失的祖先来源补偿。

本次没有得到该联合比较，因此维持 R497 完整目标和 R495 的原费用，不新增辅助分支、阈值或分析链。下一决策仍需保实际同父来源交换；继续单独细化中心壳厚度不会从上述推导中消去累计因子 \(\mathcal D\)。

## 3. 实际符号检查

指定本机 Python/SymPy 实际运行下列自含代码，核 (2) 的端点与尺度积分以及12个参数恒等式。它不检验 rank Green 根价，更不是原生历史模拟。

```python
import sympy as s
u,n,a,b,g=s.symbols('u n a b g', positive=True)
expr=(g*b)**n/b**n+s.integrate(n*(g*u)**n/u**(n+1),(u,a,b))
assert s.simplify(expr-g**n*(1+n*s.log(b/a)))==0
for N in (1,2,9,64):
 for ratio in (s.Rational(1),s.Rational(3,2),s.Rational(2)):
  A=1+N*s.log(ratio)
  gamma=s.exp(-s.log(1+A)/N)
  assert s.simplify(gamma**N*A-A/(1+A))==0
print('PASS source-fixed selector envelope identity and 12 scaling '
      'identities; no rank Green price certified')
```
