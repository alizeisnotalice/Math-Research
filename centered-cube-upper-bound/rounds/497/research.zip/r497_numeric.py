from pathlib import Path
from fractions import Fraction as F
import sys,platform,json,time
import sympy as sp
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=384;start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator

def zero(v):ck(v.is_finite());ck(v.contains(0))
def ceilq(v):return (v.numerator+v.denominator-1)//v.denominator
def ceilball(v):
 ck(v.is_finite());z=v.ceil().unique_fmpz();ck(z is not None);z=int(z);ck(v<z);ck(v>z-1);return z
# General center-volume radial envelope, independent of any source density.
n=sp.symbols('n',positive=True,integer=True);rr,a,b,zeta=sp.symbols('rr a b zeta',positive=True)
inner=sp.integrate(n*2**n*rr**(n-1)/a**n,(rr,0,zeta*a/2))
outer=n*zeta**n*sp.log(b/a)
ck(sp.simplify(inner-zeta**n)==0)
ck(sp.simplify(sp.diff(n*zeta**n*sp.log(rr),rr)-n*zeta**n/rr)==0)
ck(sp.simplify(sp.expand_log(n*zeta**n*(sp.log(zeta*b/2)-sp.log(zeta*a/2)),force=True)-outer)==0)
t,k=sp.symbols('t k',positive=True)
ck(sp.simplify(sp.diff(t**k*sp.exp(-t),t)-t**(k-1)*(k-t)*sp.exp(-t))==0)
u=sp.symbols('u',positive=True)
ck(sp.simplify(sp.diff(sp.log(1-u)+u,u)+u/(1-u))==0)
ck(sp.limit((1-1/n)**(n/2),n,sp.oo)==sp.exp(-sp.Rational(1,2)))
profiles=[(1,1,F(1),F(1,4)),(3,1,F(1,4),F(1,16)),(1,2,F(2),F(1,16)),(3,2,F(1,2),F(1,4))]
records=[];uniform=[]
for profile,(r,S,tau,eps) in enumerate(profiles):
 P=F(r*S);H=F(S)/tau;Cg=512*P*H+4*P+S;A=8*P
 B1=4096*P*H;B2=6*Cg/eps;C3=2*A*Cg/eps
 ck(max(B1,B2)**2>=C3)
 CT=max(B1,B2)+1
 cr=arb(2).log()+(1+ar(r).log())/2;c0=arb(2).log()+ar(F(1,2))
 d=8*ar(P)*cr.sqrt()/ar(C3).sqrt()
 k0=8*ar(CT/(256*P*H)).log()+4*cr.log();ck(k0>0)
 # Uniform all-n>=2 scalar certificate via max t^j exp(-t)=j^j exp(-j).
 unif=S*c0*(3*k0*4*(-arb(2)).exp()+(24+d*k0)*27*(-arb(3)).exp()+8*d*256*(-arb(4)).exp())
 ceiling=ceilball(unif)
 dnew=d/8
 unew=S*c0*ar(F(1,4096)/H).exp()*(k0*4*(-arb(2)).exp()+(8+dnew*k0)*27*(-arb(3)).exp()+8*dnew*256*(-arb(4)).exp())
 newceiling=ceilball(unew)
 uniform.append(dict(profile=profile,C_T=str(CT),c_r=str(cr),d=str(d),k0=str(k0),uniform_zeta1_coefficient_upper=str(unif),conservative_integer_upper=ceiling,uniform_Phi_coefficient_upper=str(unew),Phi_conservative_integer_upper=newceiling,scope='Analytic scalar all-n>=2 upper using log t<=t and t^j exp(-t) maxima, not inferred from sampled dimensions. Parameter-dependent constant.'))
 for nn in (2,16,256,10**4,10**8,10**12):
  LL=ar(r).log()+nn*arb(2).log()
  qroot=(ar(C3)*(LL+1)).sqrt();cq=ceilball(qroot)
  T=max(ceilq(B1),ceilq(B2),cq)
  ck(T>=B1);ck(T>=B2);ck(ar(T*T)>ar(C3)*(LL+1))
  delta=1024*P*H/T;kappa=8*ar(4/delta).log();D=3+8*ar(P)*LL/T
  Dlog=3+4*ar(P)*LL/(T*arb(2).log())
  Dnew=(ar(P)/T).exp()*(1+ar(P)*LL/T)
  ck(Dnew<D)
  ck(Dlog<=D)
  common=dict(profile=profile,n=nn,r=r,S=S,tau=str(tau),eps=str(eps),P=str(P),H=str(H),L=str(LL),T=T,kappa=str(kappa),D=str(D),Dlog_full_mass_width=str(Dlog),Dlog_upper_mass_endpoint='3',Phi_max=str(Dnew),Phi_upper_mass_endpoint=str((ar(P)/T).exp()))
  outputs=[]
  for name,zz in [('one_minus_inverse_root',1-1/arb(nn).sqrt())]:
   logvol=nn*zz.log();vol=logvol.exp();ck(zz>0);ck(zz<1);ck(vol>0)
   factor=S*kappa*vol*(1+nn*arb(2).log())
   coeff=D*factor;coefflog=Dlog*factor;coeffupper=3*factor;coeffnew=Dnew*factor
   ck(coeffnew<coeff);ck(coeffnew<newceiling)
   ck(coeff.is_finite());ck(coefflog<=coeff);ck(coeffupper<=coefflog)
   if name=='one_minus_inverse_root':
    ck(logvol<=-arb(nn).sqrt());ck(coeff<ceiling)
   outputs.append(dict(zeta=name,zeta_value=str(zz),zeta_power_n=str(vol),log_zeta_power_n=str(logvol),deep_coefficient_D=str(coeff),deep_coefficient_Phi=str(coeffnew),Phi_to_D_coefficient_ratio=str(Dnew/D),deep_coefficient_Phi_over_sqrt_n=str(coeffnew/arb(nn).sqrt()),deep_coefficient_over_sqrt_n=str(coeff/arb(nn).sqrt()),deep_coefficient_parent_log_full_width=str(coefflog),deep_coefficient_parent_upper_mass_endpoint=str(coeffupper),log_deep_coefficient=str(D.log()+kappa.log()+ar(S).log()+logvol+(1+nn*arb(2).log()).log())))
  records.append(dict(**common,outputs=outputs))
result=dict(scope='General center-selector radial-envelope coefficient certificate only; no finite native hardcore experiment, source-density cap, original history or successful-flow gate certification.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r497_numeric.py',seconds=time.perf_counter()-start),checks=checks,parameter_dimension_cases=24,zeta_coefficient_cases=24,old_Phi_coefficient_pairs=24,formula=dict(lemma='U_zeta(x)<=S*zeta^n*(1+n log(b/a)) for all x; layer envelope min(a^-n,(zeta/(2dist))^n) on dist<=zeta*b/2',deep='D*kappa*S*zeta^n*(1+n log2)*W',Phi='Proven R497 explicit supersolution exp(P/T)*(1+P*ell/T); global maximum uses ell=L. Distinct from Dlog arrival-sum bound.',Dlog='Parent-specific proven depth envelope3+4P log(m_plus/m_parent)/(T log2); full-width value uses log ratio=L, endpoint value3 is not a global replacement.',uniform='zeta1^n<=exp(-sqrt n). With t=sqrt n, L+1<=c_r t^2, D<=3+d t, kappa<=k0+8logt<=k0+8t; polynomial-times-exp gives parameter-dependent uniform O(1) coefficient.',zeta2='zeta2=sqrt(1-1/n), power tends exp(-1/2). For selected T~sqrt n, D~sqrt n, kappa~log n, coefficient grows n^(3/2)log n; even D=3 only reduces to n log n.'),uniform_scalar_bounds=uniform,records=records,decision='For fixed displayed parameters the zeta=1-1/sqrt n deep part has an analytic uniform O(W) scalar bound; finite checks confirm implementation across6 dimensions. The sqrt(1-1/n) choice lacks exponential-in-sqrt-n decay and cannot furnish O(sqrt n W) from this coefficient. Actual remainder/shallow geometry is unpaid.',errors='Symbolic radial primitive exact.384-bit Arb for logs, powers and coefficient values; integer T uniquely enclosed and checked. No grid, Monte Carlo, unrun low-rank native toy, or empirical extrapolation of a theorem.')
(ROOT/'r497_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact/Arb assertions;24 parameter-dimension cases,old/Phi deep coefficients;radial scalar certificate only')
