# 第497轮：显式全父上解与真实中心深度费用

## 目标、假设与实际进展

基线是已推送的第496轮。仍要求任意正L1来源、真实勒贝格接收中心及全部原入口费用下的 n^(1/2+o(1)) 一致弱型上界。本轮没有闭合该目标。

保R495原截断ντ=tq_A dA|t≥τ，0<τ≤S、q≤q_A≤λ、r=λ/q、a≤R_A≤b≤2a，m_A=μ(Q_A)=q_AR_A^n。μ=f dx，W=μ(全空间)，X为原接收测度总量，Rτ=ντ(全空间)。uniform mark保质量原子；原截断一次损失≤τX，不归一原t。所有参考、原历史及母账限定沿R495–496。

本轮可保留两项一般结论：显式、非Green定义的质量上解控制整个父累计势；真实中心深度包络使完整祖先量的深内部部分有参数依赖的O(W)费用。第一项尚留未付头部质量谱，第二项尚留全部近边界祖先，二者均不宣称整体根阶付款。数值只核解析系数，不以大量通过项衡量证明进展。

## 1. 完整父势的显式上解

K0为R496同域max-only正支配父核，G=Σ_j(K0*)^j1，伴随相对νhat=ντ ds。置c=rS、β=c/T、L=log(m+/m−)、m−=qa^n、m+=λb^n、K=κT。闭质量窗的真实来源rank容量为
\[
 \rho_x\{m\le m_A\le M\}\le c(1+\log(M/m)),
 \quad\rho_x(d\widehat A)=t(A)1_{Q_A}(x)R_A^{-n}dA\,ds_A.
\]
式中常数1保同质量mark区间，不能丢左端原子。它使祖先rankgap u满足log(m_A/m_B)≥(u/c−1)_+。由原max-Palm指数核的分段积分，
\[
 \Phi(\widehat B)=e^\beta(1+\beta\log(m_+/m_B)),\qquad
 K_0^*\Phi\le\Phi-1.
\]
右侧缺口准确为1，非拟合常数。有限正迭代保非负终端后取单调极限得G≤Φ。完整推导、原子处理及自含符号检查见proof。

令b_R(Â)=π_A{v_x(Â)<K}。原实际rank累计量≤I=∫b_RG dνhat，且Rτ=I+E_empty，E_empty≤C_empty W已由R496支付。因此
\[
 I\le e^\beta[KW+\beta H_{\log}],\qquad
 R_\tau\le e^\beta[KW+\beta H_{\log}]+C_{\rm empty}W,
\]
\[
 H_{\log}=\int\mu(dx)\int_{v_x(\widehat A)<K}
 \log(m_+/m_A)\rho_x(d\widehat A)
 =\int_{m_-}^{m_+}\frac{C_K(u)}u\,du,
\quad C_K(u)=\int\min\{K,\rho_x(m_A\le u)\}\,d\mu.
\]
C_K(u)≤min(KW,ντ{m_A≤u})合法，但现有粗价Hlog≤KLW仍使费用达到κLW，未达根阶。不能假设头部质量谱仅占一个窄log窗口。该上解控制整个I，不以局部分支替代它；仍需实际几何压缩上述真实质量谱或使用更细的联合势。

## 2. 真实中心深度的完整祖先付款

固定0<ζ<1。对于同一个原半径selector R_A而非逐来源重选，真实中心变量的径向体积包络给
\[
 U_\zeta(x):=\int_{2\|A-x\|_\infty\le\zeta R_A}
 \frac{t(A)}{R_A^n}\,dA
 \le S\zeta^n[1+n\log(b/a)].
\]
证明只积分接收中心A的Lebesgue体积：积分核由min(a^(−n),(ζ/(2d))^n)在d≤ζb/2处支配，core与shell端点均保留。没有估计薄层来源质量，也没有假设f有密度帽。

准确应用位置必须是完整祖先K0*G：由G=1+K0*G，写
\[
 I=H_{\rm head}+I_{\rm anc,deep}+I_{\rm anc,boundary},
 \quad H_{\rm head}=\int b_Rd\widehat\nu\le KW.
\]
I_anc,deep中保νhat(dB)b_R(B)、π_B(dx)、原祖先Â≻B、输入rank门、void指数、G(A)及质量分母，仅再插入2||A−x||∞≤ζR_A；I_anc,boundary为其正补集。它不是geometry附件中“终止父自身深内部”的那个积分，两者不可混名。

删去正上界中的祖先次序、rank门和void，保同一x和原selector，并用
\(\Phi_{\max}=e^{c/T}(1+cL/T)\)，得到
\[
 I_{\rm anc,deep}\le
 \frac{\Phi_{\max}}T S\zeta^n[1+n\log(b/a)]
 \int b_Rd\widehat\nu
 \le C_{\rm deep}W,
\]
\[
 C_{\rm deep}=S\kappa\Phi_{\max}\zeta^n(1+n\log2).
\]
这支付同一完整祖先量中的一个真实部分，不支付补集，也不丢原低秩新来源。

本深度系数的统一常数明确使用实际选择T=ceil max{4096cH0,6Cg/ε_g,sqrt[16cCg(L+1)/ε_g]}，其中H0=S/τ、Cg=512cH0+4c+S、0<ε_g<1；不是任意无上界增大T。第1节上解不需要这一额外上界。取n≥2、ζ=1−1/√n，则ζ^n≤exp(−√n)。沿此完整选参，T≥sqrt[16cCg(L+1)/ε_g]且T≤C_T sqrt(L+1)，κ=O(log(L+2))、Φ_max=O(1+sqrt(L+1))，所以Cdeep有维数无关的参数依赖上界。numeric给出无渐近猜测的显式多项式乘exp(−sqrt n)界及安全常数；仅使用t^j exp(−t)≤j^j exp(−j)。n=1可直接用完整I≤Φ_max KW，把固定参数常数并入，未以ζ=0作除法。

因此另一条保价完整接口为
\[
 R_\tau\le(K+C_{\rm deep}+C_{\rm empty})W
              +I_{\rm anc,boundary}.
\]
K=κT已是根阶乘对数，但尚未控制I_anc,boundary。不能把边界接收中心关系变成来源薄层体积价格；可变半径使“薄壳中心数等于厚度乘总中心数”也不自动成立。这个接口与第1节的头部谱上界是备选，不能把两者各自的收益重复抵扣。

## 3. 探路决策、验证与局限

原计划构造有限不交source小盒的正L1函数及真实receiver中心格，并保持连续mark。资格预审发现所提小例Umax仅1/30，而R495阈值远大于它；因此没有执行或归档该全低rank模型，更没有将其当hardcore证据。独立预审同时确认：同cell的捕获签名可聚合，但连续mark一般不能直接平均成有限cell矩阵。

计算转向已明确的一般深度积分系数，使用本机独立Python、SymPy、python-flint/Arb384位。geometry核1个符号径向积分与12个尺度恒等式；proof核19项显式上解及原子头部谱；numeric核502项exact/Arb断言。共534项报告核验单位，不是534个模型或一般证明。四组参数、n=2,16,256,10^4,10^8,10^12，分别初探、参数/尺度压力与扩大复核；零残差先核有限性，不将极小区间underflow成0。

指定四参数下Cdeep解析全n≥2的安全整数上界为34、42、82、70。这些是参数依赖常数，不是有限样本最大值或全参数普适常数。曾考虑的ζ=sqrt(1−1/n)只保解析极限exp(−1/2)，不用于声称指数节省。无实际连续hardcore/history仿真被宣称通过。

复现见r497_replay.json及各内嵌代码，numeric.py输出自身目录。规范结果比较仅排除动态秒数。详细LaTeX与必要证书保留，不编译PDF。独审先检查命题、再阅读作者，并复核最终绑定材料。

## 4. 总账和下一步

原τX、R495全部非rank累计收据、R496 empty收据继续保留。入口倍率64(128/119)/(1−32δ_old−16η_old)以及原初始、删除跳跃、未来被删来源、宽距离、低强度、极端比例、全尺度未付项不变。δ_succ不是δ_old，所有吸收额度须按完整母账分配。

当前没有新的整体根阶预算。值得继续的准确几何任务是：对同一近边界祖先与低秩后来源联合积分给可吸收aRτ加根阶来源价，或直接对真实Hlog头部谱取得足够压缩。显式上解、局部深度付款和有限验证均不代替这一任务；继续单独优化深内部常数不会完成目标。
