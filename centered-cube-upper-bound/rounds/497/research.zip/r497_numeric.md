# R497：中心深度包络及显式 Φ 的系数证书

已运行 502 项 exact/Arb 断言：四组 R495 参数、六个指定维数，共 24 个参数维数例；每例比较旧 D 与已证明的显式 Φ_max。只计算 ζ=1−1/√n 的 deep 系数；另一 ζ 仅保解析极限说明。未运行、归档或包装此前全低 rank 的 native 小例。

结论：deep 部分有参数依赖的统一 O(W) 标量价。用作者已证 Φ_max 替 D 进一步改善常数；本四参数的保守整数界由 (105,127,249,212) 降为 (34,42,82,70)。没有据此付款剩余 shallow 部分或宣布原 hardcore/history 已认证。

## 任意 selector 的中心深度引理

令 d=||A−x||∞，a≤R(A)≤b，0≤t(A)≤S，0<ζ<1。deep 条件 2d≤ζR(A) 蕴含 d≤ζb/2、R(A)≥max(a,2d/ζ)。因此

Uζ(x)≤S∫_(d≤ζb/2)min(a^(−n),(ζ/(2d))^n)dA。

∞-径向体积微分为 n2^n d^(n−1)dd。以 d=ζa/2 分界，积分精确为

S[ζ^n+nζ^n log(b/a)]=Sζ^n[1+nlog(b/a)]。

SymPy 实际核 core 积分、shell 原函数及端点差。该引理是任意真实中心 selector 的点态体积外包络，不假设来源 f 的密度帽或薄来源体积；μ 没进入这个中心积分。

给定作者祖先估计及头部质量 ∫νb≤κTW，旧系数为

C_old=DκSζ^n(1+nlog2)，即 deep contribution≤C_old W。

这只是 deep ancestor 分支，不是全 I 的价格。

## 参数与已证显式上解

四 profile (r,S,τ,eps)：

(1,1,1,1/4)、(3,1,1/4,1/16)、(1,2,2,1/16)、(3,2,1/2,1/4)。

P=rS、H=S/τ、Cg=512PH+4P+S、A=8P。取 L=log r+nlog2、

T=ceil max(4096PH,6Cg/eps,√[2ACg(L+1)/eps])，

κ=8log[T/(256PH)]，D=3+8PL/T。全部原 R495 常数保留，T 的 ceil 由 Arb 唯一整数及相邻严格不等式认证。

使用作者在 [r497_proof.md](/tmp/r497_proof.md) 已证的实际 scalar supersolution，β=P/T、ℓ_B=log(m_plus/m_B)：

Φ(B)=exp(β)(1+βℓ_B)，Φ_max=exp(P/T)(1+PL/T)。

本轮主要新比较为

C_new=κS Φ_max ζ^n(1+nlog2)。

这不是猜测拟合势，也不是原 Dlog 的改名。脚本另保此前已证 arrival-sum 界 Dlog(B)=3+4Pℓ_B/(Tlog2) 的全宽值作为旁证；Dlog 与 Φ 是不同公式。旧 D 和 Φ_max 都用同一个全宽 L，没有把某个最高质量父的端点值拿来全局替代。

维数仅 n=2,16,256,10^4,10^8,10^12。ζ=1−1/√n 在此全为 (0,1)，未错误使用 n=1 的零 ζ。

## 一般统一标量界，不从六点猜阶数

log(1−u)≤−u 给 ζ^n≤exp(−√n)。SymPy 核其导数 −u/(1−u)，各指定维数也实际区间比较。

令 C3=2ACg/eps、C_T=max(4096PH,6Cg/eps,√C3)+1，c_r=log2+(1+log r)/2。n≥2，t=√n，有

L+1≤c_r t²，T≤C_T√(L+1)，T≥√[C3(L+1)]。

定义 d=8P√c_r/√C3、k0=8log[C_T/(256PH)]+4log c_r，则

D≤3+dt，κ≤k0+8logt≤k0+8t。

所以旧 deep 系数≤

S(log2+1/2)[3k0 t²+(24+dk0)t³+8dt⁴]e^(−t)。

对新 Φ，T≥4096PH 给 exp(P/T)≤exp[1/(4096H)]，且 Φ_max≤exp[1/(4096H)](1+dt/8)。故新 deep 系数≤

S exp[1/(4096H)](log2+1/2)[k0t²+(8+dk0/8)t³+dt⁴]e^(−t)。

由 max_(t≥0)t^j e^(−t)=j^j e^(−j) 得到显式、参数依赖的统一常数。SymPy 核该导数恒等式；Arb 计算这两个常数并取安全整数上界：

| profile | 旧 D 全 n≥2 上界 | Φ_max 全 n≥2 上界 |
|---|---:|---:|
| 0 | 105 | 34 |
| 1 | 127 | 42 |
| 2 | 249 | 82 |
| 3 | 212 | 70 |

这些是解析 scalar all-n≥2 证书的常数，不是样本最大值，也不是全参数绝对常数。JSON 保留未上取整 Arb 值、C_T、d、k0。只有对应 deep 部分可据此称 O(W)；原头部和 shallow ancestor 仍需另外结算。

## 实际系数比较

profile 0 的便读摘要（严格区间见 JSON）：

| n | 旧 D 的 C_old | Φ 的 C_new | C_new/C_old |
|---|---:|---:|---:|
| 2 | 19.072950 | 6.356979 | .333298 |
| 16 | 11.313553 | 3.765883 | .332865 |
| 256 | .001152266 | .000375301 | .325706 |
| 10^4 | 3.38974×10^(−38) | 7.41819×10^(−39) | .218842 |
| 10^8 | 1.22443×10^(−4331) | 1.55127×10^(−4332) | .126693 |
| 10^12 | 5.39648×10^(−434277) | 6.74652×10^(−434278) | .125017 |

所有 24 参数维数例都严格有 C_new<C_old。Arb 保这些极小值，不用浮点 underflow 零代替。

## 未采用的 ζ 与父头部范围

若 ζ=√(1−1/n)，则 ζ^n=(1−1/n)^(n/2)→e^(−1/2)，SymPy 已核该极限；它没有 exp(−√n) 节省，不再做该无用分支的数值扫描。对选定 T~√n，Φ_max~√n、κ~logn，所以该系数仍为 n^(3/2)logn；即使条件父端点 Φ≈1，也仍有 nlogn，而不是 O(√n)。这来自显式函数，不是六点外推。

使用父头部真实 ℓ_B<L 只会进一步降低 Φ；但本轮没有真实父质量分布可据此把 ℓ_B=0 的值 exp(P/T) 当全局值。已证 Φ 改善 deep 常数，未单独改善尚缺的全局 head log-mass 付款。

## 复现与资格

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r497_numeric.py`

实际 Python 3.12.14、SymPy 1.14.0、python-flint 0.9.0，Arb 384 bits。符号积分精确，日志/根/指数严格区间；零残差先核有限性。无网格、MC、有限离散来源或 receiver toy 被称作 native hardcore 实测。

固定 stdout：`PASS 502 exact/Arb assertions;24 parameter-dimension cases,old/Phi deep coefficients;radial scalar certificate only`。

compute_index 含解释器、版本、命令、动态耗时，输出在脚本自身目录。白名单仅 `/tmp/r497_numeric.py`、`/tmp/r497_numeric.json`、`/tmp/r497_numeric.md`。完成限定任务后停止。
