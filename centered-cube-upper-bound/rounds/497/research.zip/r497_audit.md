# R497 独立终审

FINAL PASS（限定范围）。真实闭质量窗导出的显式 Φ 是整个 max-only 父核的严格上解；完整 rank 费用的 head 质量谱回代准确。主稿完整祖先 deep 部分有参数依赖的维数一致 O(W) 价格，且与附件的终止父 deep 分支清楚分开。尚未支付 H_log 或近边界祖先全量，完整根阶目标与原母账未闭合。

独立 PRE 先核命题与量词、再读最终作者稿；本报告已审白名单全部七件，未发现必要修补项。

1. **完整上解。** 真实 G_x(u)≤rSu 给含左端原子的闭窗 ρ_x[m,M]≤rS[1+log(M/m)]；G_x(m−)、同质量 mark 部分均保留。它对每个真实祖先强制 rankgap 与 log-mass 增长，并界祖先总 rank 长度。扩张积分的上界函数保持非负，分段指数积分准确给 Φ−K₀*Φ≥1。对 π_B 的真实来源平均合法；有限正迭代保非负终端再取单调极限得 G≤Φ，无未知 Green 重命名或源密度帽。
2. **实际 head 费用。** I≤exp(β)[KW+βH_log] 保原 b_R、父质量与 mark。增广秩使 head∩闭质量 prefix 的长度为 min(K,F_x(u))，从而 H_log=∫C_K(u)du/u 精确；C_K≤min(KW,ν_τ{m_A≤u}) 的分母消去使用完整 μ(Q_A)=m_A。当前粗 H_log≤KLW 仍有质量窗损失，不能宣布该上解已给根价。R_τ=I+E_empty 及既有 C_empty 来源费使用范围准确。
3. **真实中心付款。** 对固定原半径 selector，含 base 的径向中心包络给 U_ζ(x)≤Sζⁿ[1+nlog(b/a)]。主稿插入 deep 门的位置是完整 K₀*G 的祖先 A，不是输出终止父 B。先逐父控制祖先来源积分，再乘原 b_R 总量≤KW，严格得到 C_deep W。b_R 是另一来源平均，未偷换成共享来源 x 的 head 指示；未把中心薄层体积当成 μ 薄层质量。附件 geometry(4) 的终止父 deep 正限制是不同积分，不与主稿收据叠加。
4. **全维常数与费用。** 固定参数下采用实际 T=ceil(max完整R495三项)，既有下界也有 T≤C_T√(L+1)，于是 Φ_max、κ 的显式多项式界与 ζⁿ≤exp(−√n) 合法。n≥2 的四组安全整数 34/42/82/70 来自正系数多项式乘指数的解析全域上界及 Arb 包围；不是样本最大值或全参数绝对常数。n=1 用完整 I 的固定参数帽单列，不对 ζ=0 作除法。上解本身不要求 T 的额外上界。原 τX、非 rank 收据、empty、入口倍率及其余未付槽均保留，两个备选接口不重复吸收。

**实际独立复现。** 指定 Python `-I` 在临时目录重放 geometry 的1项径向符号身份与12项尺度身份、proof 19项符号/Fraction、numeric 502项 exact/Arb，共534项报告核验单位；stdout 全部与冻结 replay 一致。numeric JSON 仅移除 compute_index.seconds 后逐字段一致，规范 SHA256 为 `699c2489d177f9b59496dad98b3419128b0e537d2b5465b17dd0681d85405de4`。Arb 384 bits 保小正数、有限零残差和唯一 ceil。24个参数维数例及解析常数证书仅核系数；未运行的全低秩 native 小例不计证据，亦未认证原连续 hardcore/history 或一般阶数。

真正未付的是同一真实父核的 H_log 全谱或近边界祖先联合预算。本报告不认证整体根阶付款。

## 最终输入绑定

- `r497_main.md`: `2898e86f350d75140982aa7a3c5b16e999ff28bbd248a4e8de19b95a8c2e5647`
- `r497_geometry.md`: `4ee070308b21913cfb10437e4616abe2569d4694f7321b35e4e35bb5324520c2`
- `r497_proof.md`: `b01646b0b917c85ed9049756a3144149ffca3091159839d493fc1118aea34759`
- `r497_numeric.md`: `aea9884a61ad2aebea6c805c066777d7ba611bff970656790438e78ddb0a682a`
- `r497_numeric.py`: `f1b2e2bae5fca736c4db6fc2ce5d18c41c54a2e1e7c6d43b6562b8e267a4228d`
- `r497_numeric.json`: `f19bb2c677a71afbd35e0ba99d76bec7368e1071b398dc3d875c5fd914220466`
- `r497_replay.json`: `31c9606b7bafea4afba73aba80eff1a7c466944490829645f80aabf2d1afe4cc`
