"""Exact rational stress tests for the proposed dynamic bad-injection envelope.
Finite checks only. The uniform proof is separate. No spatial/n-dimensional claim.
"""
from fractions import Fraction as F
from pathlib import Path
import json

def h(b,k):
 return max(b*b-k,F(0))**2/(4*b*(b+1)*(b+k)**3)
def f(x,b,k):
 return max(x*(b*b-k*(x+1)),F(0))/((b+k)**2*(x+b+1)**2)
stages=[('initial',[F(1,2),F(1),F(2),F(4),F(16)],[1,2,4,16]),('threshold_stress',[F(j)+e for j in [1,2,4,16] for e in [F(-1,1000),F(0),F(1,1000)]],[1,2,3,4,15,16,17,255,256,257]),('expanded',[F(1,1024),F(1,16),F(3,2),F(32),F(256),F(1024)],[1,8,64,256,1024])]
results=[]
for name,bs,ns in stages:
 checks=0
 for b in bs:
  for k in sorted(set(ns+[max(1,int(b*b)),max(1,int(b*b)+1)])):
   d=b*b-k
   xs=[F(0),F(1,100),F(1),b,b*b,F(10000)]
   if d>0:
    xstar=d*(b+1)/(d+2*k*(b+1));assert f(xstar,b,k)==h(b,k);checks+=1
    xs += [xstar/F(1000),xstar*F(999,1000),xstar,xstar*F(1001,1000),xstar*1000]
   for x in xs:assert f(x,b,k)<=h(b,k);checks+=1
  for n in ns:
   total=sum((h(b,k) for k in range(1,n+1)),F(0))
   assert total<=b/(8*(b+1));checks+=1
 results.append({'stage':name,'checks':checks,'b_values':[str(b) for b in bs],'n_values':ns,'failures':0})
cubic_checks=0
for j in range(401):
 b=F(1000+j,1000)
 assert b*b<2
 assert h(b,1)<=(b-1)**2/16
 assert h(b,2)==0
 cubic_checks+=2
results.append({'stage':'cubic_boundary','checks':cubic_checks,'b_range':'1 to 7/5 step 1/1000','failures':0})
out={'status':'PASS_FINITE_RATIONAL','scope':'scalar envelope and finite k-sum only; not general proof or spatial quadrature','stages':results,'total_checks':sum(r['checks'] for r in results)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
