"""Reproduce R153 from archived inputs. No new kernel or receiver evaluations."""
import argparse,json,shutil,subprocess,sys,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--rounds',type=Path,required=True);p.add_argument('--detail',type=Path,required=True);p.add_argument('--destination',type=Path,required=True);a=p.parse_args()
d=a.destination.resolve();d.mkdir(parents=True,exist_ok=False);w=d/'work';w.mkdir();old=d/'r152';old.mkdir()
with zipfile.ZipFile(a.rounds/'152/research.zip') as z:
 for f in ['cut_probe.py','cut_probe.json','cut_numeric_plan.md']:(old/f).write_bytes(z.read(f))
for n,f in [(139,'active_traffic_v2.json'),(142,'numeric_receiver.json')]:
 with zipfile.ZipFile(a.rounds/str(n)/'research.zip') as z:(d/f).write_bytes(z.read(f))
for f in ['dynamic_probe.py','dynamic_verify.py','dynamic_numeric_plan.md','scalar_check.py']:shutil.copy2(HERE/f,w/f)
cmd=[sys.executable,str(w/'dynamic_probe.py'),'--r151-zip',str((a.rounds/'151/research.zip').resolve()),'--r152-dir',str(old),'--detail',str(a.detail.resolve()),'--r136',str(d/'active_traffic_v2.json'),'--r142',str(d/'numeric_receiver.json'),'--out',str(w/'dynamic_probe.json')]
subprocess.run(cmd,check=True)
new=json.loads((w/'dynamic_probe.json').read_text());old=json.loads((HERE/'dynamic_probe.json').read_text())
for key in ['pressure_stages','receiver_controls','receiver_aggregates_32']:
 assert new[key]==old[key],f'Mathematical output changed: {key}'
cmd=[sys.executable,str(w/'dynamic_verify.py'),'--r151-zip',str((a.rounds/'151/research.zip').resolve()),'--r152-zip',str((a.rounds/'152/research.zip').resolve()),'--detail',str(a.detail.resolve()),'--r136',str(d/'active_traffic_v2.json'),'--producer',str(w/'dynamic_probe.json')]
r=subprocess.run(cmd,check=True,text=True,capture_output=True);(d/'verification.json').write_text(r.stdout);assert json.loads(r.stdout)['status']=='PASS','Independent reference mismatch'
subprocess.run([sys.executable,str(w/'scalar_check.py')],check=True)
assert json.loads((w/'scalar_check.json').read_text())==json.loads((HERE/'scalar_check.json').read_text())
print('PASS: identical dynamic results and scalar checks; independent reference comparison completed. No spatial quadrature/FULL certificate.')
