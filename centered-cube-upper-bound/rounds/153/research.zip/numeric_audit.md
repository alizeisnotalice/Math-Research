# R153 动态切口势：独立reference检查点

状态：独立reference及已落地producer比较均PASS。52压力模型、六个Fraction控制的7034个精确字段检查无不一致，8376既存点重建的32组A/B聚合无不一致。全点聚合是binary64数值一致性，不是核或dx误差认证。

## 独立性和实际执行

先按dynamic_numeric_plan.md自行实现 `dynamic_verify.py` 的新Psi、端点、联合signed跳及bad-first路径，再第一次运行reference；此前没有读取Luna dynamic_probe.py或其动态结果。第一次reference通过后才读实现代码查合同问题。旧输入读取允许复用R151归档cut_check.py的**输入生成器**，不调用其动态势（旧件亦无新Psi）；新动态计算未import producer。

参考脚本只用Python标准库Fraction/Decimal/zipfile。实际解释器 `/opt/homebrew/opt/python@3.14/bin/python3.14`，PYTHONPATH未设置。运行：

    python3 dynamic_verify.py > /tmp/r153_independent_reference_complete.json

可显式传`--r151-zip`、`--r152-zip`、`--detail`、`--r136`。脚本只读既存输入，不生成新核/receiver/质量模型。报告可由脚本重建；原第一次reference及后续包含全32聚合报告都已实际exit0。后续新增producer比较adapter不改新Psi算法。

固定输入包括R151 compact SHA `6bfc604946efcb7461b354e1d1f5347319b519548e1c4448a35643b5f911b731`、外部detail SHA `6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9`、R136 SHA `1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de`；压力生成器member SHA `7615f5ed67171bad6a21f5625f363277fa695fddccd10fbbb0b3de83413ff477`，seed151015。

## 精确reference实测结果

52压力模型、849cut、1560联合阈值事件，完全复用旧人口，全部端点/跳用Fraction。精确新旧比较：

| 对象 | Hdyn<Hold | 相等 | Hdyn>Hold |
|---|---:|---:|---:|
| 849个cut | 452 | 301 | 96 |
| 52模型的cut总和 | 42 | 5 | 5 |

所以不能登记一般Hdyn<=Hold。已有expanded_00,r=11为明确反向cut：Hdyn约.2728933810，Hold约.0909698160；脚本输出其40位有理向外区间和差。r=0及所有连续段K_B=0的条件上界逐cut精确核验，无违例。

联合正跳事件580、联合负跳事件316；初始B=0的cut有50。bad-first路径净正事件为168，**不是联合正跳580**。good-after路径正贡献的cut有384；它不同于旧原始IG>0的542行，因为当前B为0时good虽进入，Psi仍为0。压力人口有good/ties实质覆盖，不能用R151 good=0样本代替它。

六个receiver Fraction控制为x0、m4/m8各原最高weighted-B贡献点×eg/2C，Tcut均按完整六源0/4原函数精确计算并验证Tcut<=4Hdyn。x0 eg下Hdyn≈.2303771297、Hold≈.7924500731、Tcut≈.08733319052；2C下Hdyn≈.2395260406、Hold≈.8485595877。同一连续w和冻结rho/good/nu保留。

## 全8376点、32聚合的独立数值reference

为避免再做巨大Fraction全点扫描，控制保持精确，网格行采用从canonical Fraction profile缓存转换的binary64，重新计算32域聚合。原核未重新评价，接收求积误差未认证。

m8 corrected、门后A口径：

| c | 4Hold | 4Hdyn | Tcut |
|---|---:|---:|---:|
| eg | .0142296185 | .0041584932 | .0003992734 |
| 2C | .0173271319 | .0046495423 | .0003992734 |

对应新势A账：eg初端.0018770137、末端0、正联合跳0、负跳绝对值.0008373904，Hdyn≈.0010396233；2C初端.0021055955、末端0、正联合跳0、负跳绝对值.0009432100，Hdyn≈.0011623856。负联合跳是新势自身的完整账，未转移为原删除负预算。

B口径4Hdyn分别≈.0012933825/.0014461708，旧4Hold≈.0044257246/.0053895317。A=Σw p费用，B=Σw p hardmass/q费用，未混同条件p均值。当前receiver中bad-first净正部分为0；这不表示一般bad正注入为0，压力中已有168正事件。

## F(beta)、small-beta及合同边界

reference严格使用共同beta_raw=Σ全部D mass*w_tau/c，先每个同刻事件固定A_minus移除bad，计算 `bad_net=Psi(A_minus,B_plus)-Psi(A_minus,B_minus)`，再累加max(bad_net,0)。good随后加入的路径项另存，二者和恢复完整联合差。没有用max(联合DeltaPsi,0)去比较bad帽。

F(beta)的log仅90位Decimal数值比较，不包装为精确超越数证书；beta<=1时bad净正总量=0精确核验。小beta条件beta<=1或beta^2<=2时，cubic为Fraction `(beta−1)_+^3/48`，可精确比较。既有52压力模型此次small-beta覆盖数为0，故不能声称该人口实测了cubic分支；父另作scalar检查与本人口区分。

一般压力T未给假有理原函数，只核精确端点身份和点态代数输入链；新增参考不独自证明一般BV结论、外价、FULL或接收维数阶。一般数学证明由独审负责。

## 最终实现比较及实际运行

独立reference通过后读初版实现发现rho有理化、共同beta、summary字段和聚合分项合同问题，已通知实现方；最终产物不靠宽容差隐藏精确控制差异。六控制的Hdyn/Hold/T和各cut费用与本reference精确有理值的保存向外区间逐项匹配。压力849cut端点、正负/有符号联合跳、bad-first正部和52模型共同beta及总bad正部匹配。F(beta)仅以数值容差比较，与精确字段检查分开。

实际执行（不调用producer，不重新评价核）：

    /opt/homebrew/opt/python@3.14/bin/python3.14 dynamic_verify.py --producer dynamic_probe.json > /tmp/r153_producer_comparison.json

结果JSON `status=PASS`，`exact_checks=7034`、`exact_mismatch_count=0`、`aggregate_mismatch_count=0`。32组均核count，A/B每个保存费用字段按同一口径独立重建比较。此7034为精确字段数，并非独立模型数、事件数或新实验次数。保存区间由Fraction严格检查包围，未把浮点近似视为有理等式。

只对adapter修了控制行的label/grid/row_index定位和聚合字段别名；新Psi/事件方法保持第一次独立reference的实现。没有读写producer源码以修复其输出，也没有终止或重启producer。producer历史运行次数无法核实，输出保持null/unknown；实际完成和父级fresh replay需由各自执行日志记录。

冻结adapter SHA256：`c4c4e8bdeb288a307fd37e7b7810ba6f1e88af7fb2f562a93e8b216007719e31`。
已比较producer JSON SHA256：`15e86cf3f7d814823d619fd40a2cd246d009fd7a4264a8b724f27d66abc25f25`。
当前producer源码SHA256：`abacc458db3a4633975d7260240b2c1b56c7044f66ff670fd51373bb7ef232df`；该版本在已运行版本后只补摘要/元数据并修maxreverse命名，父级正作fresh replay，不能将尚未返回的重现写为本代理已执行。

## 为什么本I1的“bad费用消失”不能单独登记为整帽节省

R151/R152所存I1在人口内good阈值势注入为0；对本动态参考，bad-first净正部分也为0。原Phi在bad质量移除时会正跳，因为A/(A+B+c)随B下降而增大；Psi还乘当前B/(B+(r+1)c)，bad降为0时Psi变为0，因此同一个事件成为**负Psi跳**。这是所选新势的完整有符号账，不是原负项预算的返还，也不是把原bad正Phi费用独立付掉。新旧边界和漂移也随势改变，所以必须比较完整Hdyn与Hold，不能只对比两个“bad正部分”。

本I1所有低端score均为0，故连续K_B=0的条件经reference核验，使该人口Hdyn<=Hold；一般压力r>0、K_B>0时无此顺序。96个反向cut、5个反向模型及expanded_21约10.82倍反向已经明确保留。

父另报告其标量有限有理检查共2532项通过，其中新增802项位于cubic支b=1至1.4、步长.001；这是父的独立scalar检查，不冒记为本52模型对small-beta的实测覆盖。52模型small-beta覆盖仍严格记0；一般cubic与付款结论依数学独审，不由标量网格自行证明。next_joint_budget.md属于下轮候选，不计本次数值已证事项。


## 主级最终复现验收（2026-10-15）
主级独立新目录r153_parent_replay_20261015_a实际运行reproduce.py，session55445退出码0。冻结源码abacc458db3a4633975d7260240b2c1b56c7044f66ff670fd51373bb7ef232df生成最终JSON a2f834c5d714a726862e63d3bd8f19f08df9a524ae0306123c49f28a394e1cbb（2,455,946字节）。pressure_stages、六controls、32聚合与08af运行的数学输出逐值一致；最终摘要与源码绑定已经重新运行，未用旧运行冒充新代码。独立verifier再次PASS，7034精确字段/32聚合零不一致；2532标量有限检查输出一致。最终JSON已替换工作区旧检查点。

主级元数据核验一度误在inputs内找producer_sha256而KeyError，实际字段在顶层；改正读取位置后绑定验证通过，未更改数据或重复数学计算。proof/FULL及求积误差的原有限性说明不变。
