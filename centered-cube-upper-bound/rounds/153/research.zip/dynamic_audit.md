# R153 Sol 独立审计：动态切口势与有符号阈值输运

状态：已先读contract.md与prior_score_transport.md必要定义并独立推导；尚未读取本轮作者dynamic_geometry.md。仅写本文件，不Git、不改其他文件。接受下述精确BV命题及其边界，不将其登记为一般空间外价闭合。

## 1. 精确量词与regular漂移独立重推

固定原合法非零有限行。E_*⊂E₊与D₀为原互斥terminal存活组，E_*整窗固定、包含待估余部good来源；ρ∈[0,1]、c∈(0,e_g]沿时间固定。沿原同一ν定义A_r、B_r、K_A、K_B。不得按当前score、接收x的最优势或外hard来源重新选组/核/归一量。原ST6给
\[
 dA=-K_A\,du+dI_G,\qquad dB=-K_B\,du-dI_D,\quad
 K_A\ge(r+1)A,\quad K_B\le rB,\quad u=\log t.
\tag{DA1}
\]
阈值推前I_G、I_D包括绝对连续、奇异连续和原子部分。

对固定cut r，置a=(r+1)c>0、S=A+B+c、
\[
 d(B)=\frac B{B+a},\quad \Phi=\frac A S,\quad
 \Psi(A,B)=d(B)\Phi=\frac{AB}{(B+a)(A+B+c)}.
\tag{DA2}
\]
c与a固定，d(B)沿时间改变。原Φ负regular漂移为
\[
 D_\Phi=\frac{(B+c)K_A-AK_B}{S^2}
 \ge\frac{A(B+a)}{S^2}\ge0.
\]
准确动态负regular漂移为
\[
 \boxed{G_\Psi=d(B)D_\Phi+
       \frac{a}{(B+a)^2}\Phi K_B.}
\tag{DA3}
\]
第二项不能遗漏。它来自B的regular下降导致d(B)下降。两项均非负，且
\[
 G_\Psi\ge d(B)D_\Phi\ge\frac{AB}{S^2}
 \ge\frac{AB}{4e_t^2},
\tag{DA4}
\]
因为原两组互斥、ρ≤1且存活，A+B≤e_t；另c≤e_t，故S≤2e_t。此处既没有对e_t求导，也没有冻结d(B)为d(Bτ)。

Ψ的偏导为
\[
 \Psi_A=\frac{B(B+c)}{(B+a)S^2}\ge0,\qquad
 \boxed{\Psi_B=
 \frac{A\{a(A+c)-B^2\}}{(B+a)^2S^2}.}
\tag{DA5}
\]
与DA3直接核对，有GΨ=Ψ_AK_A+Ψ_BK_B。Ψ_B可负，但score分离保证这一regular总和仍非负；不能只从单个偏导符号判断regular漂移。

A=0或B=0时实际K_A或K_B相应为零，DA3–DA5按原零值成立；B=0后Ψ、GΨ和该cut裸交通均零。c>0保障所有势分母正。无限原行只能沿原既有合同处理；本证书在有限原数据下成立，截断仅作用固定原量的非负积分，不截断ν重算势后声称单调。

## 2. 完整BV身份：阈值增量有符号

在去原子部分（包括奇异连续），阈值注入为
\[
 dJ_\Psi^{cont}=\Psi_A\,dI_G^{cont}
                  -\Psi_B\,dI_D^{cont}.
\tag{DA6}
\]
bad项不再总为非负。绝对连续阈值注入即使与du同支撑，也必须保留在DA6，不能把全部AC变化都误命名为regular漂移。

同一时刻good进入g≥0、bad离开b∈[0,B_-]时，唯一顺序无关的完整原子为
\[
 \boxed{\Delta J_\Psi=
 \Psi(A_-+g,B_--b)-\Psi(A_-,B_-).}
\tag{DA7}
\]
它可以有符号。可选任意明确路径作证明性分解，但完整原子只收一次；不能把不同路径的有利分项拼接。特别同时跳应保留对d(B)与Φ的乘积交叉项，不能只加d_-ΔΦ+Φ_-Δd。

固定有限原行上A/B有界变差，Ψ在相应非负区域为C¹，c>0，因此一般BV链式法则合法。令JΨ为DA6积分与DA7所有原子的完整有符号和，则
\[
 d\Psi=-G_\Psi\,du+dJ_\Psi,\qquad
 H_{\Psi,r}:=\Psi_\tau-\Psi_{\mathrm{end}}+J_\Psi
           =\int_\tau^hG_\Psi\,du\ge0.
\tag{DA8}
\]
由ST3与DA4，
\[
 \boxed{\mathcal T_*\le4\sum_{r=0}^{n-1}H_{\Psi,r}.}
\tag{DA9}
\]
没有额外冻结dτ乘子；它已进入动态势及其完整变化。JΨ本身不是非负预算，HΨ也不能按三个独立非负项拆账。

原严格score k=#\{a_i<t\}可统一改取右态端点而不改变dt/t积分。若τ右态、h右态，则J取(τ,h]；若在总身份中准确消去h处联合原子，则J取(τ,h)、势终点改为Ψ(h−)。不能仅删除h的一种注入，或只改B端点但不改A/Ψ。h=τ原交通为零，应直接按空窗处理。

## 3. bad正注入区域、跨界有限跳与同刻跳

由DA5，连续bad注入−Ψ_BdI_D为正只可能在
\[
 \boxed{B^2>a(A+c)}
\tag{DA10}
\]
且A>0的区域。等号处一阶bad注入为零；A=0无此交通。该区域是当前实际A/B，不是原来源质量或另一时刻的值。

对纯bad有限移除，A固定，B从B₀降到B₁=B₀−b。准确净原子为
\[
 \Delta J_\Psi^D=\int_{B_1}^{B_0}[-\Psi_B(A,B)]\,dB.
\]
其正变化上界为
\[
 \Delta J_\Psi^D\le
 \int_{B_1}^{B_0}[-\Psi_B(A,B)]_+\,dB.
\tag{DA11}
\]
若跨过B_*=√(a(A+c))，必须沿整个移除区间计正变化，不能只看B₀或B₁一端的偏导符号。即使净原子为负，也可能有中间正变化。比如A=c=a=1，B从4降到1/10，净Ψ下降，但路径先升到B=√2的峰再降；只看净差会漏掉若要单独估计的路径正变化。

同刻good g与bad b可沿直线路径A_s=A_-+sg、B_s=B_--sb写
\[
 \Delta J_\Psi=\int_0^1
 \{g\Psi_A(A_s,B_s)-b\Psi_B(A_s,B_s)\}\,ds.
\tag{DA12}
\]
若放大到正注入上帽，可将bad部分替成b(−Ψ_B)_+，但区域应沿同一s路径判断。只根据事件前/后某个A与某个B组合判定整个同刻原子，不成立。此正部放松会抛弃有利负注入；它是新的上帽，尚须付款，不能据此宣称原signed负项已支付。

## 4. 固定A势峰值独立核验

固定A≥0，记b₀=A+c>0，则
\[
 \Psi(A,B)=\frac{AB}{(B+a)(B+b_0)}.
\]
B导数分子为A(ab₀−B²)，故A>0时唯一最大点为
\(B_*=√{a(A+c)}\)，且
\[
 \boxed{\sup_{B\ge0}\Psi(A,B)
 =\frac{A}{(\sqrt a+\sqrt{A+c})^2}.}
\tag{DA13}
\]
A=0时两边为零；B→0或∞时势趋零。该最大值是准确代数包络，既未免费选择实际B，也不支付原来源/接收费用。若将实际势替成此峰值，必须分清放大哪一边界项；不能将−Ψ(h)替成一个更负的−supΨ(h)来求上界。

动态HΨ与旧冻结dτ∫DΦ没有未经证明的统一大小关系：
\[
 G_\Psi-d_\tau D_\Phi
 =(d(B)-d_\tau)D_\Phi+d'(B)\Phi K_B.
\]
第一项≤0，第二项≥0。故新定理合法不等于每个输入的最终帽均改进；r≥1且初端K_B>0时甚至可有当前GΨ大于旧当前漂移。任何普遍改进声明须另证，不能由B=0时动态势消失推出。

## 5. 真实接收外价与删除合同

DA9的4倍系数与原hard16/3及2Λ合成
\[
 \boxed{
 2\Lambda P_{rem}\le\frac{128\Lambda}{3}
 \mathbb E\sum_{V,j}\int
 p(x-y)\sum_rH_{\Psi,r}(\omega,V,j,x,y)\,
 dx\,d\beta_V(y).}
\tag{DA14}
\]
原aω/history必须在hard聚合时保留；hard帽仅用一次。来源和时间已在HΨ处理，不另乘log2，不把β换成ν，也不提前免费合并实际j。c=e_g或c=2Kq/p均需沿原同行固定。

原删除未消失：E_*与D₀⊂Z_g保证这两组分子不被删，因此Ψ无额外删除跳；共同e_t、Π_t和实际交通仍受其他来源删除影响。证明只用A+B≤e_t及c≤e_t。若把futurebad或会删来源加入组，DA1和DA8须加其删除变化，不能照抄。

尚欠的是DA14完整原接收均值的根阶多对数预算。阈值Ψ增量的几何符号、势峰值和同刻BV身份本身均不构成该付款。保留有利负阈值增量可以增强实际帽，但不得将它复制成原signed负交通的一笔新预算；抛掉负注入仍只是更松的正上界。

先审完成；等待dynamic_geometry.md后作对应公式与范围审查，不扩大历史或数值范围。


## 6. 追加独立先审：bad正注入的跨cut维数无关质量帽

以下仍未读dynamic_geometry.md，独立审主代理新提案。归一化
\[
 x=A/c,\quad b=B/c,\quad k=r+1,\qquad
 \psi_k(x,b)=\frac{xb}{(b+k)(x+b+1)}.
\]
于是
\[
 (-\partial_b\psi_k)_+
 =\frac{x[(b^2-k)-kx]_+}{(b+k)^2(x+b+1)^2}.
\]
当b²≤k时该值对所有x≥0均零；当b²>k时，令d=b²−k、L=b+1，优化x(d−kx)/(x+L)²。导数分子为dL−(d+2kL)x，故唯一最大点
\[
 x_*=\frac{(b^2-k)(b+1)}{b^2-k+2k(b+1)}
\]
且
\[
 \boxed{h_k(b):=\sup_{x\ge0}(-\partial_b\psi_k)_+
 =\frac{(b^2-k)_+^2}{4b(b+1)(b+k)^3}.}
\tag{DA15}
\]
b=0时直接定义h_k=0，不使用含1/b公式。该上确界只用于代数上帽，不重新选择实际A或共同ν。

对任何b>0，
\[
 \sum_{k=1}^{n}h_k(b)
 \le\frac{b^4}{4b(b+1)}
      \sum_{k=1}^\infty(b+k)^{-3}
 \le\frac{b^4}{4b(b+1)}
      \int_0^\infty(b+s)^{-3}ds
 =\frac b{8(b+1)}.
\tag{DA16}
\]
b≤1时所有k≥1都满足b²≤k，故和实际为零。这里舍去分子−k以及用递减函数积分比较，均是一般证明，不依赖有限数值检查。

每cut B_r非增。连续（包括奇异连续）bad正注入由
\(h_{r+1}(b_r)dI_D/c\)上界；因
\(-db_r=K_Bdu/c+dI_D/c\)，可放大到B_r的整段下降。对同刻有限跳，采用仅为证明使用的路径：先固定原A_-移除bad，再固定B_+加入good。总signed原子保持DA7；good段非负，bad段的正变化至多
\[
 \int_{b_+}^{b_-}h_{r+1}(b)\,db.
\]
跨界时已沿整个区间积分，而非只看端点符号。不同事件的B_r下降区间互不重叠，且都包含于[0,β₀]，其中
\[
 \beta_0=c^{-1}\int_{D_0}w_\tau\,d\nu,\qquad
 B_r(\tau)/c\le\beta_0.
\]
故将该证明性分解中的全部bad正阈值费用记为J_{bad,+}^{path}，非负Tonelli与DA16给
\[
 \boxed{\sum_{r=0}^{n-1}J_{bad,+,r}^{path}
 \le F(\beta_0):=
 \begin{cases}
 0,&0\le\beta_0\le1,\\[2mm]
 \displaystyle\frac{(\beta_0-1)
       -\log((\beta_0+1)/2)}8,&\beta_0>1.
 \end{cases}}
\tag{DA17}
\]
该F从积分∫₁^β b/[8(b+1)]db得到，常数1/8准确。不另乘cut数，也不乘冻结d_r；动态势中已有当前系数。

DA17所称bad正费用是明确“bad先移、good后进”路径中的正变及连续bad正部；不声称同刻signed原子具有唯一bad/good分账，也不把此路径分项混同别轮另一种分子归属。完整signedBV身份DA8始终不改。若用该帽替换J的某正分量，应同时保留对应good路径费用和其余边界/负注入，或明确作合法正放松；不能只领取有利部分。

这是实质的跨cut容量简化：其上帽不显含n，β₀≤1时bad不会造成正势注入。它仍可能随β₀线性增长；原high不提供β₀一般绝对帽。c=e_g时原粗β₀≤2ⁿ也不使它成为根阶空间费用，因此DA17不支付good注入、初末边界或真实接收外价。1730项有理有限检查若通过，只是实现一致性证据；DA15–DA17的一般证明是上述独立代数与单调测度论证。


## 7. 追加独立核验：小bad容量域的一项真实根阶付款

当1<β₀≤√2时，只有k=1可能有h_k非零；k=2在等号处仍为零。准确化简为
\[
 h_1(b)=\frac{(b-1)^2}{4b(b+1)^2}
       \le\frac{(b-1)^2}{16}\quad(b\ge1).
\]
因此DA17可在此域改进为
\[
 H_{bad,+}^{path}\le\frac{(\beta_0-1)_+^3}{48}.
\tag{DA18}
\]
令
\[
 \eta_n=\min\{\sqrt2-1,(2n+3)^{-1/3}\}.
\]
对原实际行资格β₀≤1+η_n，得到共同数值帽
\[
 1_{\{\beta_0\le1+\eta_n\}}H_{bad,+}^{path}
 \le\frac1{48(2n+3)}.
\tag{DA19}
\]
β₀≤1时左侧零，空窗也按零，不需要负的三次项。

已为该项付款实际核验旧工具，而非只信常数：

- 实读R148 research.zip内capacity.md第4节的原三来源/整时间消尽后保留aω、用hard16/3、再合并唯一j及真实dx包络合同。
- 为核准JT13的全soft包络，实读R140 research.zip内joint_transport.md的JT13–JT14。工具对原固定绝对尺度带[a,b]、b/a≤2与固定y成立：
\[
 \int\sup_{s\in[0,1],\,L\in[a,b]}P_{s,L}(x-y)\,dx
 \le3(2n+3)D_n,\quad D_n=1+\frac\pi2\sqrt n\le3\sqrt n.
\]
实际p的所选(s,L)须属于该原带，β保持原外测度。原aω/history不能删除。唯一j在来源和整窗尚存时不能合并；DA19给出与实际x,j,y,V无关的共同帽后，才用Σj1_{j(x)=j}≤1并上界所选p。
- 本项的时间已累计在Hbad+，不使用JT14中逐时帽所需的额外log2；也不重复乘hard16/3，因其已在DA14系数128Λ/3内。

准确已付对象是动态输运上帽中的正bad分量：
\[
\begin{aligned}
 \frac{128\Lambda}{3}\mathbb E\sum_{V,j}\int&
 p(x-y)1_{\{\beta_0\le1+\eta_n\}}
 H_{bad,+}^{path}(\xi)\,dx\,d\beta_V(y)\\
 &\le\frac{128\Lambda}{3}
 \frac{3(2n+3)D_n}{48(2n+3)}W_\beta\\
 &=\frac{8\Lambda}{3}D_nW_\beta
 \le\boxed{8\Lambda\sqrt n\,W_\beta}.
\end{aligned}
\tag{DA20}
\]
β₀资格、c、terminal组与原参数在外hard来源积分前固定；若外hard依赖它们则不得直接使用同一hard帽。c对全部cut相同且时间固定，才能使用DA17–DA19的共同区间论证。

DA20是一项可登记的真实根阶分项付款。它并不支付β₀≤1+η_n域上的完整原交通：good注入、初末边界和其他账仍在。不能把这一正上帽分量的预算称为原正支全覆盖，亦不能据此声称完整一般目标闭合。β₀较大域的bad注入空间价仍未取得。


## 8. 实际作者稿后审与独立检查点冻结

已先完成DA1–DA20，再实际通读dynamic_geometry.md全稿DG1–DG11。当前绑定作者稿SHA256：
\[
 \texttt{dfe0151b22a3802bb0cc98aa17d0db557fd3f2235abaa86fba8f9d7756105ac5}.
\]

核对如下：

- DG1–DG5含d'(B)项，阈值测度完整有符号，同刻原子保留准确势差，右态或h左态一致，未假称新帽小于旧H_cut。
- DG7的非归一优化D=B²−ac、s=B+c给A*=Ds/(D+2as)，与DA15归一公式一致。
- DG8用H_k'=h_k对各自非增B_r作BV链式求和，减去regular衰减后恰剩阈值区间；非原子部分包括奇异连续。作者J_D^+在原子处取“bad先移”净差的正部，不要求等于该段路径正变化；它由DA17使用的更大路径正变上界支配，故所得常数合法。
- DG9新增第二支n/4 log((β₀+1)/2)由h_k≤1/[4(b+1)]积分得到，正确；与维数无关支取min合法。不能据此宣称O(logβ₀)的维数无关帽，正文没有这样声称。
- DG10与DG11由DA18–DA20独立核算通过；付款对象仅bad正上帽分项。原剩余中good、初末边界、较大β₀域都保留。
- c=e_g时β₀≤2ⁿ配合DG9第二支至多给O(n²)行费用，外包络后O(Λn^{7/2}Wβ)，与正文范围一致；c=2C不能照搬该β上帽。

为复核DG11实际只读取下列必要旧条目，无免费引用作者结论：

1. /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/148/research.zip 内 capacity.md §1固定绝对尺度带及§4完整外账：原aω保留，三来源及整窗先消尽，hard16/3只用一次，之后唯一j，最后真实dx包络与原β归集。
2. /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/140/research.zip 内 joint_transport.md JT13：固定[a,b]、b/a≤2、任意固定y的全s∈[0,1]及L∈[a,b]连续选择包络≤3(2n+3)D_n；D_n=1+(π/2)√n≤3√n。
3. 同一文件JT14的唯一j规则：必须先有消来源后的共同数值帽；β_V在接收前构造、不依j(x)，所选p仍受同一全参数包络支配。本轮已有整时间帽，所以只沿用唯一j及dx步骤，不再乘其逐时间版的log2。

本节冻结独立数学检查点。作者主稿未发现需修公式；LaTeX若随后指定，仅核提炼一致性，不重审历史、不新增样本。至此只修改dynamic_audit.md。


## 9. LaTeX机械转写一致性与最终双稿绑定

已实际通读research.tex并用只读脚本逐块比较全部display数学块：两稿均有15块，内容与顺序逐字相同。正文/原样块的ST6、原子bad先移后good进分解、完整外账、DG8链式扣regular项、DG9两支、DG10三次界与DG11常数也人工核对一致。机械escape没有改变本次数学范围；不在本审计中编译PDF或授予排版验收。

最终绑定：

- dynamic_geometry.md：\(\texttt{dfe0151b22a3802bb0cc98aa17d0db557fd3f2235abaa86fba8f9d7756105ac5}\)。
- research.tex：\(\texttt{141e69e1c1616aed249cafdbcd026228a83767838946180e95d8a5f0aa2109bc}\)。

双稿独立数学及对应审查通过。DG11的已付对象仅为实际β₀≤1+η_n资格下的bad正注入分项，完整外价至多8Λ√nWβ；并非该资格下整份正交通已付。一般全剩余仍未闭合。无作者公式修改请求；仅修改dynamic_audit.md，未重跑数值菜单、未Git、未编译PDF，指定审查完成并停止。





