# R153：当前切口势与坏侧正注入的维数无关容量

状态：DG1–DG9 已给完整 BV 输运和新的坏侧费用上界；DG11 给一个真实接收测度中的根阶坏侧子费用。它不是完整正交通的根阶付款。没有断言新势费用小于旧冻结系数费用；起始、good 注入与大起始坏质量的接收补集仍保留。仅采用 contract.md 与 prior_score_transport.md 中的 ST3、ST6–ST10 及既有 JT13 接收包络。

## 1. 原合同与完整有符号势身份

固定原合法行、整窗常数 0<c≤e_g、切口 r，置 k=r+1、a=kc、S=A+B+c，沿 ST2 保持实际 A=A_r、B=B_r、原 ρ、ν、terminal 两组和所有接收选择参数。E_* 与 D0 不交且均存活于 Z_g。使用 ST6 的

    dA=−K_A dt/t+dI_G，dB=−K_B dt/t−dI_D，
    K_A≥kA，0≤K_B≤(k−1)B。

注入允许连续、奇异连续和同刻原子。右态初始化排除 θ=τ、包含 θ=h；若消去终端原子，全部身份同时改为 h−。定义

\[
 d(B)=\frac{B}{B+a},\quad \Phi=\frac A S,
 \quad \Psi=d(B)\Phi=\frac{AB}{(B+a)S}.
 \tag{DG1}
\]

准确导数为

\[
 \Psi_A=\frac{B(B+c)}{(B+a)S^2}\ge0,\qquad
 \Psi_B=\frac{A\{a(A+c)-B^2\}}{(B+a)^2S^2}.
 \tag{DG2}
\]

regular 漂移不是仅取其中正部分，而是

\[
 D_\Psi:=\Psi_AK_A+\Psi_BK_B
 =d(B)D_\Phi+\frac{a\Phi K_B}{(B+a)^2}
 \ge\frac{AB}{S^2}\ge0.
 \tag{DG3}
\]

其中使用 ST7 的 D_Φ≥A(B+a)/S²。由 A+B≤e_t、c≤e_t 得 S≤2e_t。

连续阈值注入定义为有符号测度 Ψ_A dI_G−Ψ_B dI_D。若同刻 good 进入 u≥0、bad 离开 v∈[0,B_-]，完整原子必须保留为

\[
 \Delta J_\Psi=
 \Psi(A_-+u,B_--v)-\Psi(A_-,B_-).
 \tag{DG4}
\]

该差可有任意符号，不把其负部分认作原负账。BV 链式法则给

\[
 \boxed{\int_\tau^h\frac{AB}{e_t^2}\frac{dt}{t}
 \le4\int_\tau^hD_\Psi\frac{dt}{t}
 =4\{\Psi_\tau-\Psi_h+J_\Psi\}.}
 \tag{DG5}
\]

右端括号非负。B=0 后势和 regular 漂移为零。与旧 H_cut 的比较不能只看 d(B)≤d(Bτ)：DG3 的第二项是新增漂移，故本稿不主张 H_dyn≤H_cut。

## 2. 坏侧正注入的准确支持与优化

为估价而非改变 DG4，在每个联合原子约定精确拆分

    J_D(atom)=Ψ(A_-,B_-−v)−Ψ(A_-,B_-)，
    J_G(atom)=Ψ(A_-+u,B_-−v)−Ψ(A_-,B_-−v)≥0。

连续部分沿 DG4 前的导数分项。于是 J_Ψ=J_G+J_D，J_D 可有符号，J_D^+ 表示其正变差总量。此拆分是本稿估价约定，原联合差仍是 DG4；没有假称它等于 R152 的联合 Φ 分项。

在非原子部分，bad 正注入只在

\[
 B^2>a(A+c)
 \tag{DG6}
\]

发生。有限跳必须沿 [B_-−v,B_-] 积分导数正部，不能只检验端点。特别 DG6 蕴含 B>c√k。

固定 B，精确最大化 A≥0 得

\[
 \boxed{(-\Psi_B)_+\le \frac1c h_k(B/c),\quad
 h_k(b):=\frac{(b^2-k)_+^2}{4b(b+1)(b+k)^3}.}
 \tag{DG7}
\]

b=0 定义 h_k(0)=0。证明：令 D=B²−ac、s=B+c。D≤0 时为零；D>0 时要最大化 A(D−aA)/(A+s)²，其最大点为 A=Ds/(D+2as)，最大值 D²/[4s(D+as)]。再除以 (B+a)²，并用 D+as=B(B+a)，得到 DG7。此最大化保留支持 B>c√k，但舍弃了实际 good 质量 A 的进一步共同 α 信息；这一损失不能被称为已经利用储备支付。

## 3. 全阈值与跨切口累计，不能把各 B_r 当同一过程

令 H_k(b)=∫_0^b h_k(z)dz。由各 B_r 分别单调、BV 链式法则及 DG7，对每个切口有

\[
 \boxed{J_{D,r}^+\le
 H_k(B_r(\tau)/c)-H_k(B_r(h)/c)
 -\int_\tau^h h_k(B_r/c)\frac{K_r^B}{c}\frac{dt}{t}.}
 \tag{DG8}
\]

右侧非负，准确等于以 h_k 计量的阈值下降：其非原子部分为 ∫h_k(B/c)dI_D/c，原子部分为 ∫_{B_+/c}^{B_-/c}h_k(b)db。对原 J_D 的原子正部用同一区间导数正部支配，故同刻 good 进入、连续和奇异注入均合法。DG8 所减 regular 衰减来自这个新比较身份，不消费旧负项。

置 β0=(∫D0 wτ dν)/c，故每个 B_r(τ)/c≤β0。先各自应用 DG8，再放松其质量区间并求和，得到

\[
 \mathcal J_D^+:=\sum_{r=0}^{n-1}J_{D,r}^+
 \le\sum_{k=1}^n H_k(\beta_0).
\]

没有假设 B_r(t) 为共同 B，也没有给各切口重复分配共同来源容量。对于 b>0，

\[
 h_k(b)\le\frac{b^3}{4(b+1)(b+k)^3},\qquad
 \sum_{k\ge1}(b+k)^{-3}\le\int_0^\infty(b+x)^{-3}dx=\frac1{2b^2}.
\]

另有 h_k(b)≤1/[4(b+1)]；所有 h_k 在 b≤1 均为零。因此

\[
 \boxed{\mathcal J_D^+\le F_n(\beta_0):=
 \begin{cases}
 0,&\beta_0\le1,\\
 \displaystyle\min\left\{
 \frac{\beta_0-1-\log((\beta_0+1)/2)}8,
 \frac n4\log\frac{\beta_0+1}{2}\right\},&\beta_0>1.
 \end{cases}}
 \tag{DG9}
\]

第一支为维数无关 O(β0)，不是 O(log β0)。在 β0 有界时，它去掉旧冻结系数估价中的调和切口因子。不同势的完整端点和 good 费用不同，因此只比较这一明确坏侧正费用，不能据此比较完整 H_dyn/H_cut。

还有在几何阈值附近更强的三次小量。若 1≤β0≤√2，只有 k=1 可能贡献，且

\[
 h_1(b)=\frac{(b-1)^2}{4b(b+1)^2}\le\frac{(b-1)^2}{16}
 \quad(1\le b\le\sqrt2).
\]

故

\[
 \boxed{\mathcal J_D^+\le(\beta_0-1)^3/48
 \quad(1\le\beta_0\le\sqrt2).}
 \tag{DG10}
\]

这不是新的逐行裸交通小量要求：它只支付实际坏侧正注入，正交通可能仍由初始势、good 注入或其端点抵消主导。

## 4. 原接收费用与一个真根阶坏侧子费用

定义 H_dyn=Σ_r(Ψτ−Ψh+JΨ)=Σ_r∫DΨdt/t≥0。ST3、DG5 和原 hard 16/3 给

    2ΛP_rem≤(128Λ/3) EΣ_{V,j}∫p(x−y)H_dyn dx dβ_V(y)。

这里 β 为原外测度，不是 ν；原三核 Q*、ρ、α、窗口、history 与未付补集均保持，额外正门只在原允许范围放松。没有再乘时间 log2，没有提前删除 j。对单独坏侧正注入，DG9 给真实外账

    (128Λ/3) EΣ∫p J_D^+ ≤(128Λ/3) EΣ∫p F_n(β0)。

一般右侧尚未支付。原 high 只控制 e_g，不给 β0 绝对帽。

不过 DG10 给一个可核验、有正宽度的实际行条件。取

\[
 \eta_n=\min\{\sqrt2-1,(2n+3)^{-1/3}\},\qquad
 \mathcal B_n=\{\int_{D_0}w_\tau d\nu\le(1+\eta_n)c\}.
\]

在 B_n 上 J_D^+≤1/[48(2n+3)]。这时才可使用共同帽、唯一 j 与 JT13 的 ∫sup p≤3(2n+3)D_n、D_n≤3√n，得到

\[
 \boxed{\frac{128\Lambda}{3}\mathbb E\sum_{V,j}
 \int p\,1_{\mathcal B_n}\mathcal J_D^+\,dx\,d\beta_V
 \le\frac83\Lambda D_nW_\beta
 \le8\Lambda\sqrt n\,W_\beta.}
 \tag{DG11}
\]

可合法选 c=e_g，条件即原终端坏来源在起始时刻的质量不超过 (1+η_n)e_g。条件不要求 bad 原 ν 质量小，也不拿 high 推导它；它由真实 wτ、原 ν 和 eg 直接核验。β0≤1 的部分费用为零，1<β0<1+η_n 是新三次帽的正宽度条件。此处不声称已构造 FULL 反例或核验旧数值行落入该带。

DG11 只是 H_dyn 中一项的完整一般来源、全时间、实际 dx/β 接收付款。其余费用仍为：完整起始/终端与 good 项，以及 B_n 外的坏正注入；可保留 signed 精确式，或用正上界 Σ_r(Ψτ+J_G)+1_{B_n^c}J_D^+，均尚未付款。因而不能据 DG11 宣布 P_rem 已有根阶预算。

若只用 c=e_g 和旧尺度比 wτ≤2^n wg，则 β0≤2^n，DG9 至多给 F_n(2^n)=O(n²)，全参数包络后仍 O(Λ n^{7/2}Wβ)，并不完成主目标。对于 c=2Kq/p，该 β0 上帽也不能照搬。

## 5. 精确剩余缺口与停止点

本轮新增的可核验费用节省是 DG7–DG10：实际双组条件 B²>kc(A+c) 将高切口正 bad 注入排除，再通过各自单调质量区间和可求和系数得到维数无关 O(β0) 与近阈值三次帽；DG11 已把一个明确子费用回代为真根阶外价。完整有符号 DG5 仅为这些估计的起点。

尚缺的是 B_n 外的实际接收平均与起始/good 的联合预算。要利用原 α 余额和相反 Q*/wg 接收检验，必须在 DG2 或 DG6 保留实际 A_r 与 B_r 的联合分布；DG7 对 A 最大化后没有留下足以支付大 β0 的接收衰减。既无由 high 推得的小 β0，也无由 ∫Q*ν≤q 直接得到的 pF_n(β0) 帽。本稿不把这一积分重命名为已付能量，不扩大反例或历史搜索。

所有极限固定原 ν、e、ρ、A/B、c 和原资格，仅截断非负积分；不截断 ν 后重算归一声称单调。只写本文件，不改其他作者或 Git，完成后停止。
