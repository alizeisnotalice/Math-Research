# R153 动态切口势同点数值合同（仅方案；未运行）

本文件独占；不改contract.md、prior_score_transport.md或他人文件。目标是把父尚待独审的动态Ψ候选变成可执行、可否证的有限协议，比较旧Hold与Hdyn、完整有符号跳及实际裸cut交通。不新增核、receiver、质量或网格，不从R152 good注入为0的样本推一般结论。待父确认合同后再实施；本次不运行全轮。

## 1. 数学对象和固定输入

沿R152同一canonical模型：六源nu固定，w_i(t)=∏min(1,threshold_ij/t)由原threshold十进制精确Fraction定义；rho/good/p/q/hardmass及接收资格取R151冻结记录，E*=全E+、D=全部terminalbad，完整e保留六源。c版本仍canonical eg，以及只在原high且精确2Kq/p<=canonical eg的域取c=2Kq/p。各组不重新归一化，不因跳号删source。

读R152 research.zip中的冻结cut_probe.py/json、cut_verify.py作旧结果对照，按archive/member SHA核验，不从当前工作区临时文件继承。读R151 compact与外部detail SHA `6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9`，原8376行、m4/m8、original/corrected权及原32组聚合域保持。固定3个控制位置×2个合法c：x0、m4/m8原max_weighted_B_contribution位置。R136/R142输入SHA保持R152合同。R152 canonical与旧profile舍入差继续披露，旧saved I仅并列；x0已有Q缓存可以精确canonicalFA，不新算核。

压力输入严格复用R152 pressure_check.py重建的52模型：R151 cut_check.py的3个固定case、tie/zero-mass case及seed151015的expanded_00至expanded_47。沿原tau=1/4、h=3/2、g=2及原c，不调质量、阈值或seed。预期切口数849、阈值事件行1560作为旧输入人口校验；若新程序因端点约定得到不同数，先解释而非补case凑数。压力模型可有其它X来源删除，G/D仍terminal；e必须保留所有当时存活的X来源，Ψ自身没有X删除跳，不能据此删e中的X。

## 2. 新旧量、端点与完整有符号跳

每cut r令 a_r=(r+1)c（与good原子进入量a_G不同），

    S=A+B+c，Phi=A/S，d(B)=B/(B+a_r)，Psi=d(B)Phi。

d_tau=d(B_tau,right)仅用于旧Hold，新Ψ在每端/每侧用其当前B，不把d_tau移进Ψ。统一tau右态、h左态，仅计tau<theta<h事件；如另用h右态，必须同时纳入h的完整ΔΨ并核其与末端抵消。两种端点约定对总H应严格相同；theta=tau只初始化不再收费。本轮不混用旧R152说明中的右态字眼。

同刻全部good进入a_G>=0与bad离开b_D>=0一次合并：

    A+=A-+a_G，B+=B--b_D；
    ΔPsi=Psi(A+,B+)−Psi(A-,B-)。

这是唯一主收费对象，可以正、负、零；不得只留正部、不得把负跳挪入原N_Z/N_del或其它负账。事件内所有source及跨多个cut的重数保持；不做“先good后bad”顺序分摊后冒称联合跳。若为诊断展示顺序路径，另标路径依赖，不用于总价。

旧Hold仍按ST8完整正ΔPhi：

    Hold=Σr d_tau,r [Phi_tau−Phi_h+Σevent ΔPhi]。

新量：

    Hdyn=Σr [Psi_tau−Psi_h+Σevent ΔPsi]；
    Hdyn=initial−terminal+Jplus−Jminus，
    Jplus=Σmax(ΔPsi,0)，Jminus=Σmax(−ΔPsi,0)。

正负拆在**联合事件/cut**差上，不按来源单个跳任意拆。分别报告四项和gross/net占比，Hdyn=0时百分比undefined；正负项可能强烈抵消，不能把Jplus单独当原总价。

## 3. 连续积分完全可精确代数化

每两个不同阈值事件之间无注入。A、B是有限monomial和，端点由同一连续w构成，故

    G=-dPsi/dlogt
     =d(B) D_Phi + a_r Phi K_B/(B+a_r)^2；
    ∫segment G dt/t=Psi(left+)−Psi(right−)。

端点A/B/c皆Fraction，所以上式以及**整个Hdyn和Hold都能精确有理求和**，不需要log/atan、数值微分或时间网格。独立核每段drop>=0及

    Hdyn=Σsegments/cuts [Psi_left+−Psi_right−]>=0。

删除X使共同e跳，但不改变A/B/Psi；为计算T或作点态检查时仍分割这些e删除时刻。连续/奇异阈值注入不在有限原子数据里，不把本协议的有限和冒称已验证一般BV链式法则。

不假定Hdyn<=Hold。每row/cut都记录精确sign(Hdyn−Hold)、比值（分母0另分支），分别计less/equal/greater，最大相对改善与最大反向放大，不能只保“改进”记录。也不在聚合前取min(Hdyn,Hold)后称一份预算。

额外压力条件：r=0必有K_B=0，故连续G=d(B)D_Phi<=d_tau D_Phi，逐段积分给Hdyn<=Hold；对r=0可作条件定理精确核验。更一般K_B整段为0时同样检查该条件结论。R151 I1各source score仅0/4，所有r<4的cut低端均score0，故本receiver人口可能全部K_B=0；应从profile逐段验证后才能使用该条件，不能用它覆盖一般压力模型。r>0且K_B>0时，尤其A远大于B，额外a_r Phi K_B/(B+a_r)^2可能使新势多收费，必须保留这些反向记录。

## 4. Tcut<=4Hdyn的验证口径

沿父候选的点态链（仍待一般独审）：

    D_Phi>=A[B+(r+1)c]/S²，
    G>=d(B)D_Phi>=AB/S²>=AB/(4e²)，

所需合法性为0<c<=eg<=e、A+B<=e、K_A>=(r+1)A、K_B<=rB及terminal两组固定。有限压力数据须检查这些输入条件，不将其它删除来源放入G/D。

R151六控制及全8376 I1的Tcut可按原0/4两scoreprimitive精确/数值重算：z=t^-4、e=Az+B，positive pair积分为rho nu_v nu_u c_v c_u(z_start−z_end)/(e_start e_end)，完整六源e，bad端必须真D。六控制以Fraction精确核Tcut<=4Hdyn；全点binary64诊断须分开标注容差、最大负残差与失败数，不称全点有理认证。旧saved I不能替代canonical T。

一般52压力模型的T数值本身未必是有理数：e有更多score层，直接积分会有log/atan；不要把精确Hdyn误写成精确T。有两种合法结果分开登记：

1. 结构验证：逐段精确核score/生存/正性等合同及上述点态代数链，Hdyn由端点精确算出，因此取得该有限输入的结构积分上帽；不声称计算了T数值。
2. 若需要T数值，使用每个阈值/删除分段上的g(t)=Σcut AB/(e² t)，在有理t子盒以monomial正系数上下界作range×盒长，得到有理T积分上下界。具体对子盒[u,v]，每cut A/B/e各由正monomial和精确求端点，故下界A(v)B(v)/(e(u)^2 v)、上界A(u)B(u)/(e(v)^2 u)；乘(v−u)再求cut和即可。只用dt矩形，不需未认证log库；按固定预算自适应细分（每model总4096叶盒、最大深度20，先最大误差盒，平局按时间左端）。若上界<=4Hdyn可数值认证；若下界>4Hdyn为阻断；跨界仍未决。不能用中点值/高精度相合冒充认证。此可选数值积分不阻止先完成全部精确势身份。

## 5. 三阶段冻结执行顺序与对抗人口

阶段1——初探与端点：六receiver Fraction控制；同时4个既有fixed/tie压力case。精确旧/新连续drop、联合ΔPsi、正负跳、tau初始化、h左/右抵消、B=0分支、r=0条件上帽。先通过再扩大；无新核。

阶段2——对抗压力：只取既有expanded_00至expanded_07八模型，含R152已知expanded_00,r=0,theta=1/3的同时a_G,b_D正且旧JG/JD都正事件。逐事件保留A/B左右态及

    F_B(A,B)=a_r(A+c)−B²，sign ∂BΨ=sign F_B。

记录bad-only正跳、负跳、零跳、有限跳跨F_B符号边界、good与bad同刻及h/tau事件。**有限跳符号用完整ΔPsi**，不只看B-或B+的导数符号；若要比较bad路径正变差，须单独对A固定、在B²=a_r(A+c)处切段并给代数根包围，不能拿该正变差替换联合有符号总跳。记录r>0/K_B>0及A/B大（可展示精确比，不增设筛选阈值改人口）时Hdyn相对Hold是否反向放大。既定八模型若未命中特定分支，写未覆盖，不创造参数补齐。

阶段3——扩大复核：剩余expanded_08至expanded_47四十压力模型；再对R151原8376点作新旧同点纯后处理。最终压力人口仍52模型、849cuts/1560events。若某符号/极端分支未在全部52内出现，只列证据缺口，不扩seed/质量/维数；任何搜索建议留后续父审。

## 6. 原32组A/B聚合及输出

对m4/m8×original/corrected权×c=eg/2C×pre/post/pre_high_legal/post_high_legal，保持R15232个域。A_X=Σw p X，B_X=Σw p hardmass/q X，来源和receiver选择器不变。每组报Hold、Hdyn、4倍上帽、Tcut、initial、−terminal、Jplus、−Jminus及完整signed jump总和，Hdyn/Hold、反向行数/最大反向、分项gross/net；聚合分项后求比，不平均逐row比例。两c只在同一合法域对比，m4若分母0标undefined。不能把接收数值求和当认证dx积分，继承R151未收敛/跳面误差限制。

输出最小实现脚本、紧凑JSON、六receiver详细有理控制和压力角色/事件统计，逐点大重复字段不归档；代码必须独立AST检查后再SHA绑定，说明与源码写不同文件，防止R152覆盖事故重演。Fraction输出用整数divmod向外格点包围；任何log/根数值若另用明确非有理证书。执行次数有日志才填，否则unknown，列确认失败与采用版本。原旧H聚合须对R152冻结结果回归；动态候选是否新增一般证明由Astra/Sol独审，数值不自授付款。

## 7. 验收与停止

本次成功标准是：协议精确可实施，Hdyn全有符号身份可精确核验；三阶段人口固定且含good/ties压力；清楚区分精确Hdyn、两score精确T、一般压力T的结构/区间证据；明确不假设新旧H顺序。当前仅交该方案，没有实施全轮或新增样本。父确认后再分派实现与独立核验，交付本文件后停止。
