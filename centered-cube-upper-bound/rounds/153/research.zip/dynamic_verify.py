#!/usr/bin/env python3
"""Independent R153 dynamic-cut reference. No producer import or kernel evaluation.
Fraction endpoints and signed jumps; Decimal only for the F(beta) log check.
"""
from fractions import Fraction as F
from decimal import Decimal,localcontext
from pathlib import Path
import argparse,hashlib,json,math,random,sys,zipfile
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()
def fr(x):return x if isinstance(x,F) else F(str(x))
def w(src,t):return math.prod((min(F(1),z/t) for z in src['thresholds']),start=F(1))
def enclose(x,digits=40):
    scale=10**digits;n=x.numerator*scale;d=x.denominator
    return [str(F(n//d,scale)),str(F(-((-n)//d),scale))]
def sign(x):return 'less' if x<0 else 'greater' if x>0 else 'equal'
def enclosed(saved,x):
    if isinstance(saved,dict) and 'lo' in saved:assert fr(saved['lo'])<=x<=fr(saved['hi'])
    elif isinstance(saved,list) and len(saved)==2:assert fr(saved[0])<=x<=fr(saved[1])
    else:assert fr(saved)==x

def cut_reference(src,tau,h,c,r):
    kappa=(r+1)*c
    def snapshot(t,right):
        A=B=KA=KB=e=F(0)
        for s in src:
            z=s['mass']*w(s,t);k=sum(a<=t if right else a<t for a in s['thresholds'])
            if s.get('delete_time') is None or t<s['delete_time']:e+=z
            if s['kind']=='G' and k>r:A+=s['rho']*z;KA+=k*s['rho']*z
            if s['kind']=='D' and k<=r:B+=z;KB+=k*z
        S=A+B+c;phi=A/S;psi=A*B/((B+kappa)*S)
        return A,B,KA,KB,e,phi,psi
    def psi(A,B):return A*B/((B+kappa)*(A+B+c))
    start=snapshot(tau,True);end=snapshot(h,False);dtau=start[1]/(start[1]+kappa)
    events=sorted({sorted(s['thresholds'])[r] for s in src if s['kind'] in ('G','D') and tau<sorted(s['thresholds'])[r]<h})
    J=JP=JM=oldJ=badplus=badminus=goodafter=F(0);event_rows=[]
    for t in events:
        pre=snapshot(t,False);post=snapshot(t,True);A,B=pre[:2];Ap,Bp=post[:2];a,b=Ap-A,B-Bp
        assert a>=0 and 0<=b<=B
        jump=post[6]-pre[6];bad=psi(A,Bp)-psi(A,B);good=psi(Ap,Bp)-psi(A,Bp)
        assert good>=0 and jump==bad+good
        J+=jump;JP+=max(jump,F(0));JM+=max(-jump,F(0));oldJ+=post[5]-pre[5]
        badplus+=max(bad,F(0));badminus+=max(-bad,F(0));goodafter+=good
        event_rows.append(dict(t=t,jump=jump,badfirst_signed=bad,badfirst_positive=max(bad,F(0)),goodafter=good,Aminus=A,Bminus=B,Aplus=Ap,Bplus=Bp,a_good=a,b_bad=b))
    # A cut's event list suffices: other cuts' crossings do not change its membership.
    times=[tau,*events,h];drift=old_drift=F(0);KB_zero=True
    for l,rr in zip(times,times[1:]):
        left=snapshot(l,True);right=snapshot(rr,False);drop=left[6]-right[6];odrop=left[5]-right[5]
        assert drop>=0 and odrop>=0;drift+=drop;old_drift+=dtau*odrop
        # Test algebraic input constraints at every profile subinterval, including X deletions.
        subdiv=sorted({l,rr}|{a for s in src for a in s['thresholds'] if l<a<rr}|{s['delete_time'] for s in src if s.get('delete_time') is not None and l<s['delete_time']<rr})
        for u,v in zip(subdiv,subdiv[1:]):
            A,B,KA,KB,e,phi,ps=snapshot((u+v)/2,True);KB_zero &= KB==0
            assert KA>=(r+1)*A and KB<=r*B and A+B<=e and c<=e
            Dphi=((B+c)*KA-A*KB)/(A+B+c)**2
            G=B/(B+kappa)*Dphi+kappa*phi*KB/(B+kappa)**2
            assert G>=B/(B+kappa)*Dphi>=A*B/(A+B+c)**2>=A*B/(4*e**2)
    Hdyn=start[6]-end[6]+J;Hold=dtau*(start[5]-end[5]+oldJ)
    assert Hdyn==drift>=0 and Hold==old_drift>=0 and J==JP-JM
    if r==0 or KB_zero:assert Hdyn<=Hold
    if start[1]==0:assert Hdyn==0 and badplus==0
    return dict(r=r,initial=start[6],negative_terminal=-end[6],jump_plus=JP,jump_minus=JM,jump_signed=J,Hdyn=Hdyn,Hold=Hold,difference=Hdyn-Hold,KB_zero=KB_zero,zero_initial_B=start[1]==0,badfirst_positive=badplus,badfirst_negative=badminus,goodafter=goodafter,events=event_rows)

def model_reference(src,tau,h,c):
    assert c>0 and all(s['kind'] not in ('G','D') or s.get('delete_time') is None or s['delete_time']>h for s in src)
    rows=[cut_reference(src,tau,h,c,r) for r in range(len(src[0]['thresholds']))]
    totals={key:sum((r[key] for r in rows),F(0)) for key in ['initial','negative_terminal','jump_plus','jump_minus','jump_signed','Hdyn','Hold','badfirst_positive','badfirst_negative','goodafter']}
    totals['difference']=totals['Hdyn']-totals['Hold'];beta=sum((s['mass']*w(s,tau) for s in src if s['kind']=='D'),F(0))/c
    bad=totals['badfirst_positive']
    if beta<=1:assert bad==0
    small=beta<=1 or beta*beta<=2
    cubic=F(0) if beta<=1 else (beta-1)**3/48
    if small:assert bad<=cubic
    with localcontext() as ctx:
        ctx.prec=90;dec=lambda x:Decimal(x.numerator)/x.denominator
        Fbeta=Decimal(0) if beta<=1 else (dec(beta-1)-dec((beta+1)/2).ln())/8
        assert dec(bad)<=Fbeta+Decimal('1e-75')
    return dict(rows=rows,totals=totals,beta=beta,Fbeta=str(Fbeta),small_beta=small,cubic=cubic if small else None)

def pressure_models(archive):
    with zipfile.ZipFile(archive) as z:code=z.read('cut_check.py')
    assert sha(code)=='7615f5ed67171bad6a21f5625f363277fa695fddccd10fbbb0b3de83413ff477'
    ns={'__name__':'archived_input_generator_only','__file__':str(archive)+':cut_check.py'};exec(compile(code,ns['__file__'],'exec'),ns)
    def eg(src):return sum((s['mass']*w(s,F(2)) for s in src if s.get('delete_time') is None or F(2)<s['delete_time']),F(0))
    out=[]
    for name,src,_t,c in ns['fixed_cases']():out.append((name,src,min(c,eg(src))))
    atom=ns['atom'];t=F(1);src=[atom([F(1,2),t,t],'G',2,F(1,2)),atom([F(1,3),t,t],'D',F(3,2)),atom([F(1,4),F(3,4),t],'X',1),ns['make_source']('X',[F(1,2),t,t],F(0),F(0),t)]
    out.append(('ties_and_zero_mass',src,min(F(1,3),eg(src))))
    rng=ns['random'].Random(151015)
    for i in range(48):
        n,src=ns['random_case'](rng,i);c=eg(src)*F(rng.randint(1,4),4);out.append((f'expanded_{i:02d}',src,c))
    return out

def receiver_sources(row,source,nu):
    return [dict(kind='G' if row['good'][i] else 'D',rho=fr(row['rho'][i]) if row['good'][i] else F(0),mass=nu[i],thresholds=list(map(fr,a['thresholds'])),delete_time=None) for i,a in enumerate(source['atoms'])]

def two_score_T(src,tau,h):
    times=sorted({tau,h}|{a for s in src for a in s['thresholds'] if tau<a<h});T=F(0)
    for l,rr in zip(times,times[1:]):
        mid=(l+rr)/2;k=[sum(a<mid for a in s['thresholds']) for s in src];cs=[math.prod((a for a in s['thresholds'] if a<mid),start=F(1)) for s in src];assert set(k)<={0,4};A=sum(src[i]['mass']*cs[i] for i in range(len(src)) if k[i]==4);B=sum(src[i]['mass'] for i in range(len(src)) if k[i]==0);zl=l**-4;zr=rr**-4
        for v,s in enumerate(src):
            for u,q in enumerate(src):
                if s['kind']=='G' and q['kind']=='D' and k[v]-k[u]==4:T+=s['rho']*s['mass']*q['mass']*cs[v]*cs[u]*(zl-zr)/((A*zl+B)*(A*zr+B))
    return T

def receiver_numeric_reference(rows_by_mesh,nu,source,tau,h,eg):
    th=[list(map(fr,a['thresholds'])) for a in source['atoms']];nuN=list(map(float,nu));times=sorted({tau,h}|{a for tt in th for a in tt if tau<a<h});cache={}
    for t in times:
        for right in [False,True]:cache[t,right]=([float(w(dict(thresholds=tt),t)) for tt in th],[sum(a<=t if right else a<t for a in tt) for tt in th])
    factors=[]
    for l,rr in zip(times,times[1:]):
        mid=(l+rr)/2;k=[sum(a<mid for a in tt) for tt in th];cs=[float(math.prod((a for a in tt if a<mid),start=F(1))) for tt in th];A=sum(nuN[i]*cs[i] for i in range(6) if k[i]==4);B=sum(nuN[i] for i in range(6) if k[i]==0);zl=float(l**-4);zr=float(rr**-4);factors.append((k,cs,(zl-zr)/((A*zl+B)*(A*zr+B))))
    records=[]
    for m,rows in rows_by_mesh.items():
        for row in rows:
            rho=row['rho'];good=row['good'];c2=2*fr(row['q'])/fr(row['p']);legal=row['gates']['high'] and c2<=eg;versions={}
            for cv,cf in [('eg',eg),('2C',c2)]:
                if cv=='2C' and not legal:continue
                c=float(cf)
                def st(t,right):
                    weights,ks=cache[t,right];A=[sum(rho[i]*nuN[i]*weights[i] for i in range(6) if good[i] and ks[i]>r) for r in range(4)];B=[sum(nuN[i]*weights[i] for i in range(6) if not good[i] and ks[i]<=r) for r in range(4)];phi=[A[r]/(A[r]+B[r]+c) for r in range(4)];psi=[B[r]*phi[r]/(B[r]+(r+1)*c) for r in range(4)];return A,B,phi,psi
                a0,b0,p0,q0=st(tau,True);ah,bh,ph,qh=st(h,False);dtau=[b0[r]/(b0[r]+(r+1)*c) for r in range(4)];ini=sum(q0);terminal=-sum(qh);JP=JM=Js=badpos=badneg=ga=0.;hd=ho=0.
                for l,rr in zip(times,times[1:]):
                    left=st(l,True);right=st(rr,False);hd+=sum(left[3][r]-right[3][r] for r in range(4));ho+=sum(dtau[r]*(left[2][r]-right[2][r]) for r in range(4))
                for t in times[1:-1]:
                    pre=st(t,False);post=st(t,True)
                    for r in range(4):
                        jump=post[3][r]-pre[3][r];JP+=max(jump,0.);JM+=max(-jump,0.);Js+=jump
                        A=pre[0][r];Bp=post[1][r];between=A*Bp/((Bp+(r+1)*c)*(A+Bp+c));bad=between-pre[3][r];badpos+=max(bad,0.);badneg+=max(-bad,0.);ga+=post[3][r]-between
                T=sum(rho[v]*nuN[v]*nuN[u]*cs[v]*cs[u]*fac for ks,cs,fac in factors for v in range(6) for u in range(6) if good[v] and not good[u] and ks[v]-ks[u]==4)
                assert T<=4*hd+1e-12
                versions[cv]=dict(initial=ini,negative_terminal=terminal,jump_plus=JP,jump_minus=JM,jump_signed=Js,Hdyn=hd,Hold=ho,Tcut=T,badfirst_positive=badpos,badfirst_negative=badneg,goodafter=ga,**{'4Hdyn':4*hd,'4Hold':4*ho})
            records.append((m,row,legal,versions))
    aggregates={}
    for m in ['4','8']:
        for wt in ['original','corrected']:
            for cv in ['eg','2C']:
                for domain in ['pre','post','pre_high_legal','post_high_legal']:
                    A={};B={};count=0;mass=vol=0.
                    for mm,row,legal,vs in records:
                        if mm!=m or cv not in vs or (domain.startswith('pre') and not row['before']) or (domain.startswith('post') and not row['after']) or (domain.endswith('high_legal') and not legal):continue
                        ww=float(fr(row['dx_weight'] if wt=='original' else row['dx_weight_corrected']));af=ww*row['p'];bf=af*float(fr(row['hardmass']))/row['q'];count+=1;mass+=af;vol+=ww
                        for key,value in vs[cv].items():A[key]=A.get(key,0.)+af*value;B[key]=B.get(key,0.)+bf*value
                    aggregates['/'.join([m,wt,cv,domain])]=dict(count=count,sum_p_weight=mass,dx_volume=vol,A=A,B=B)
    return aggregates

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--r151-zip',default=str(ROOT.parents[1]/'151/research.zip'));ap.add_argument('--r152-zip',default=str(ROOT.parents[1]/'152/research.zip'));ap.add_argument('--detail',default='/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json');ap.add_argument('--r136',default='/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/active_traffic_v2.json');ap.add_argument('--producer',help='Optional comparison; omitted for independent reference construction');args=ap.parse_args()
    with zipfile.ZipFile(args.r151_zip) as z:cb=z.read('receiver_probe.json')
    assert sha(cb)=='6bfc604946efcb7461b354e1d1f5347319b519548e1c4448a35643b5f911b731';compact=json.loads(cb);db=Path(args.detail).read_bytes();assert sha(db)=='6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9';dd=json.loads(db)['point_records'];sb=Path(args.r136).read_bytes();assert sha(sb)=='1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de';source=next(s for s in json.loads(sb)['cases'] if s['id']=='I1');nu=list(map(fr,compact['constants']['nu_exact']));tau=fr(source['derived']['tau']);h=fr(source['derived']['h']);g=fr(source['derived']['g']);eg=sum(nu[i]*w(dict(thresholds=list(map(fr,a['thresholds']))),g) for i,a in enumerate(source['atoms']))
    controls=[];chosen=[('x0',compact['x0_control'])]
    for m in ['4','8']:
        target=compact['summaries'][m]['extrema']['max_weighted_B_contribution']['xq'];chosen.append(('m'+m,next(r for r in dd[m] if r['xq']==target)))
    for name,row in chosen:
        src=receiver_sources(row,source,nu)
        for cv,c in [('eg',eg),('2C',2*fr(row['q'])/fr(row['p']))]:
            assert c<=eg
            ref=model_reference(src,tau,h,c);T=two_score_T(src,tau,h);assert T<=4*ref['totals']['Hdyn'];controls.append(dict(label=name,c_version=cv,reference=ref,T=T))
    pressure=[];counts=dict(models=0,cuts=0,events=0,Hdyn_less_Hold=0,Hdyn_equal_Hold=0,Hdyn_greater_Hold=0,positive_joint_jumps=0,negative_joint_jumps=0,zero_initial_B_cuts=0,positive_badfirst_events=0,small_beta_models=0,model_Hdyn_less_Hold=0,model_Hdyn_equal_Hold=0,model_Hdyn_greater_Hold=0,positive_goodafter_cuts=0);counterexamples=[];model_reverse_examples=[]
    for name,src,c in pressure_models(Path(args.r151_zip)):
        ref=model_reference(src,F(1,4),F(3,2),c);pressure.append((name,ref));
        if ref['totals']['difference']>0:model_reverse_examples.append(dict(model=name,Hdyn=enclose(ref['totals']['Hdyn']),Hold=enclose(ref['totals']['Hold']),difference=enclose(ref['totals']['difference'])))
        counts['models']+=1;counts['small_beta_models']+=ref['small_beta'];counts['model_Hdyn_'+sign(ref['totals']['difference'])+'_Hold']+=1
        for rr in ref['rows']:
            counts['cuts']+=1;counts['events']+=len(rr['events']);counts['Hdyn_'+sign(rr['difference'])+'_Hold']+=1;counts['zero_initial_B_cuts']+=rr['zero_initial_B'];counts['positive_goodafter_cuts']+=rr['goodafter']>0
            for ev in rr['events']:
                counts['positive_joint_jumps']+=ev['jump']>0;counts['negative_joint_jumps']+=ev['jump']<0;counts['positive_badfirst_events']+=ev['badfirst_signed']>0
            if rr['difference']>0 and len(counterexamples)<4:counterexamples.append(dict(model=name,r=rr['r'],Hdyn=enclose(rr['Hdyn']),Hold=enclose(rr['Hold']),difference=enclose(rr['difference'])))
    assert (counts['models'],counts['cuts'],counts['events'])==(52,849,1560)
    summary=dict(status='REFERENCE_PASS',scope='Independent exact finite endpoint and signed-jump reference; general-pressure T is a structural bound, not an exact numeric integral; no new kernels or FULL claim',pressure_counts=counts,Hdyn_greater_examples=counterexamples,model_Hdyn_greater_examples=model_reverse_examples,receiver_controls=[dict(label=x['label'],c_version=x['c_version'],Hdyn=enclose(x['reference']['totals']['Hdyn']),Hold=enclose(x['reference']['totals']['Hold']),Tcut=enclose(x['T']),badfirst_positive=enclose(x['reference']['totals']['badfirst_positive'])) for x in controls],reference_sha256=sha(Path(__file__).read_bytes()))
    aggregates=receiver_numeric_reference(dd,nu,source,tau,h,eg)
    summary['receiver_aggregate_reference']=aggregates
    if args.producer:
        pb=Path(args.producer).read_bytes();prod=json.loads(pb);errors=[];checks=0
        def compare(saved,exact,label):
            nonlocal checks
            try:enclosed(saved,exact);checks+=1
            except (AssertionError,ValueError,KeyError):errors.append(label)
        models={m['id']:m for group in prod['pressure_stages'].values() for m in group}
        assert set(models)=={name for name,_ref in pressure}
        for name,ref in pressure:
            saved=models[name];assert len(saved['cuts'])==len(ref['rows'])
            if 'badfirst_positive_sum' in saved:compare(saved['badfirst_positive_sum'],ref['totals']['badfirst_positive'],name+':badfirst_positive_total')
            if 'beta_raw' in saved:compare(saved['beta_raw'],ref['beta'],name+':beta_raw')
            if 'F_beta_numeric' in saved:assert math.isclose(float(saved['F_beta_numeric']),float(ref['Fbeta']),rel_tol=2e-11,abs_tol=2e-13)
            for rr in ref['rows']:
                cc=saved['cuts'][rr['r']]
                for key,skey,mult in [('Hdyn','Hdyn',1),('Hold','Hold',1),('initial','initial',1),('negative_terminal','negative_terminal',1),('jump_plus','Jplus',1),('jump_minus','negative_Jminus',-1),('jump_signed','signed_jump',1),('badfirst_positive','bad_path_positive_jumps',1)]:compare(cc[skey],mult*rr[key],name+':r'+str(rr['r'])+':'+key)
        cmap={}
        for xx in prod['receiver_controls']:
            xq=xx.get('xq') or (compact['x0_control']['xq'] if xx['grid'] is None else dd[str(xx['grid'])][xx['row_index']]['xq'])
            cmap[tuple(xq),xx['c_version']]=xx
        for cc in controls:
            row=next(row for label,row in chosen if label==cc['label']);key=(tuple(row['xq']),cc['c_version']);saved=cmap[key];ref=cc['reference']
            for field in ['Hdyn','Hold']:compare(saved[field],ref['totals'][field],cc['label']+':'+cc['c_version']+':'+field)
            compare(saved['Tcut'],cc['T'],cc['label']+':'+cc['c_version']+':Tcut')
            for rr in ref['rows']:
                ss=saved['cuts'][rr['r']]
                for k,sk,mul in [('Hdyn','Hdyn',1),('Hold','Hold',1),('jump_plus','Jplus',1),('jump_minus','negative_Jminus',-1),('badfirst_positive','bad_path_positive_jumps',1)]:compare(ss[sk],mul*rr[k],cc['label']+':'+cc['c_version']+':r'+str(rr['r'])+':'+k)
        agg_errors=[]
        for key,ag in prod['receiver_aggregates_32'].items():
            ref=aggregates[key];assert ag['count']==ref['count']
            for measure in ['A','B']:
                for field,value in ag[measure].items():
                    aliases={'signed_jump':('jump_signed',1),'Jplus':('jump_plus',1),'negative_Jminus':('jump_minus',-1),'good_after_bad':('goodafter',1)}
                    rf,mult=aliases.get(field,(field,1))
                    if rf not in ref[measure]:agg_errors.append(key+':unsupported_metric:'+field)
                    elif not math.isclose(float(value),mult*ref[measure][rf],rel_tol=2e-11,abs_tol=2e-13):agg_errors.append(key+':'+measure+':'+field)
        summary['producer_comparison']=dict(producer_sha256=sha(pb),exact_checks=checks,exact_mismatch_count=len(errors),exact_mismatches=errors,aggregate_mismatch_count=len(agg_errors),aggregate_mismatches=agg_errors)
        summary['status']='PASS' if not errors and not agg_errors else 'PRODUCER_MISMATCH'

    print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
