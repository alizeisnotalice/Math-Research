# R153 动态势数值实现记录

状态：producer 源码已冻结；主级对冻结源码的干净复现正在运行。本说明区分已完成的 08af 运行与事后更新的 abacc 源码，最终 JSON 哈希待主级复现确认后填入。仅有 frozen R151 的 8,376 receiver 点及既有 52 个压力模型；没有新核、receiver 点或质量模型。

## 输入、源码与运行账

实现位于 `dynamic_probe.py`。源代码用 `Fraction(str(value))` 将保存的十进制 rho 转成有理数；R151 detail 中 rho 在 JSON 解码后是 Python float，直接 `Fraction(float)` 会保留二进制浮点精确值，改变原数值合同。最终冻结代码已改为十进制字符串转换，并按 `(t, side)` 缓存 profile。代码调用冻结 R152 `cut_probe.py` 的 `exact_cut` 两分数原函数计算 I1 的 Tcut，属于显式、SHA 记录的代码依赖；压力势本身由本文件的 Fraction 端点式计算。

最终源码及目录外备份 SHA256 均为 `abacc458db3a4633975d7260240b2c1b56c7044f66ff670fd51373bb7ef232df`。源码已通过 AST 解析与 `py_compile`。备份路径为 `/Users/zhengzhihao/Desktop/T/output/dynamic_probe_R153_source_backup_20261015.py`。该冻结源码加入 producer SHA、自我依赖字段、压力阶段的最大反向比摘要以及更清楚的 receiver 反向比命名；这些是 08af 运行完成后加入的输出 metadata/摘要，不改变势、事件、Hdyn、Hold、Tcut 或 receiver 32 组聚合的公式。

运行顺序与已知失败如实记录：最早三次脚本启动分别因 R151 归档路径错误、执行归档生成器缺 `__file__`、动态加载 R152 源码缺 `__file__` 失败；第四次完整运算因 rho 被 `Fraction(float)` 解释而在约七分钟后主动中断，未写结果 JSON；最终第五次使用 08af 源码完整运行并写出 JSON。其执行打印包含 8,376 rows 和完整压力阶段摘要，随后进程退出，未捕获到明确的数值 exit code。该运行的源码 SHA 是 `08af86caeaa57f583e577ea0fb23bae84af57182d4044c1fcbda164f7eb8d038`，JSON SHA 为 `15e86cf3f7d814823d619fd40a2cd246d009fd7a4264a8b724f27d66abc25f25`（2,454,549 bytes）。它是历史检查点，不是最终 abacc 源码对应的交付 JSON。主级已在 `/Users/zhengzhihao/Desktop/T/output/r153_parent_replay_20261015_a` 对冻结 abacc 源码启动 fresh replay；复现结果与最终 JSON SHA 待该运行结束后确认。

## 菜单与计算结果

三阶段按既有菜单运行：initial 4 pressure models、pressure expanded_00–07 八模型、expanded_08–47 四十模型，合计 52 models / 849 cuts / 1,560 threshold event rows。分阶段切口 Hdyn 相对 Hold 的 less/equal/greater 数量分别为：initial `6/3/0`，pressure `74/52/21`，expanded `372/246/75`；全压力人群为 `452/301/96`。regular 条件检查失败为零；共同 raw beta 下的 bad-first jump 数值上帽检查失败为零。压力 Tcut 没有伪造有理原函数；按协议报告精确势身份和有限结构条件，不声称数值积分证书。

先行六个 receiver 控制（x0、m4 与 m8 的最大加权 B 行，各计算 eg 和合法 2C）逐项以精确 Fraction 核验，均满足 `Tcut ≤ 4 Hdyn` 和 `Hdyn ≤ Hold`。在最终 08af 网格运行中，8,376 个点的四个 cut 共 33,504 个 Fraction cut 计算；eg 与合法 2C 合计 8,619 个 c 版本。`Tcut ≤ 4 Hdyn` 失败数为 0，Hdyn 大于 Hold 的 cut 数为 0，小于 Hold 为 5,140，其余相等。所有有定义的行级 Hdyn/Hold 比值最大约 `0.9012255431`，未见 receiver 行级反向放大。这里是有限离散人口诊断，不是空间积分误差证书。

保持 R152 的 32 个聚合键：m4/m8 × original/corrected overlap 权 × eg/2C × pre/post/pre_high_legal/post_high_legal；每组同时报 A 口径 `Σ w p X` 与 B 口径 `Σ w p hardmass/q X` 的 Hdyn、Hold、4倍帽、Tcut、端点、signed jump、正负联合跳和 bad-first/good-after 诊断。权重及这些聚合是 binary64 加权统计，不宣称有理 dx 积分。一个对照值：m8/corrected/eg/post 的 A 口径 `4Hdyn≈0.0041584931858`，与独立 reference 提供的约值一致。I1 数据中 bad-first 正部为零且事件 signed jumps 全为负；这与 expanded 压力中 Hdyn 大于 Hold 的 96 个切口共同说明，不能把 receiver 上的改善外推为一般新旧顺序定理。

事件主账始终使用同刻完整 `ΔPsi`，保留正、负、零跳。`badfirst_positive_part` 是单独明确的证明性路径诊断：固定 `A_-` 先移除 bad，取这段净差的正部；它不是联合 signed `ΔPsi` 的正部，也没有替换主账。标量 cap 使用共同 `beta_raw = c^{-1} Σ_D ν w_tau`；数值实现仅比较有限跳路径的 bad-first 正费用与 `F(beta_raw)`。F 中对数以 binary64 计算，不能称为超越函数严格证书；一般 cap 的代数论证见同目录 `dynamic_audit.md` §6。

## 限制与待确认

- Hdyn、Hold、压力同刻跳和端点身份均以 Fraction 精确求和；pressure T 只作结构条件检查，不伪称算出其数值积分。
- I1 Tcut 使用 R152 冻结两分数原函数；每行/c 版本重算，不沿用 R152 的旧 Hold 代替 Hdyn。
- `4Hdyn` 是候选帽，Hdyn 与 Hold 不预设大小顺序；压力中确有反向行。good/bad 分账采用先 bad 后 good 的明确路径，只用于 bad 正费用上帽。
- R136、R142、R151/R152 输入 SHA、plan SHA 和 R152 producer SHA 已写入 JSON inputs；最终 abacc producer SHA 由 fresh replay 的 JSON 自绑定。最终 JSON SHA 与独立核验状态待主级 replay/audit。


## 主级最终复现验收（2026-10-15）
主级独立新目录r153_parent_replay_20261015_a实际运行reproduce.py，session55445退出码0。冻结源码abacc458db3a4633975d7260240b2c1b56c7044f66ff670fd51373bb7ef232df生成最终JSON a2f834c5d714a726862e63d3bd8f19f08df9a524ae0306123c49f28a394e1cbb（2,455,946字节）。pressure_stages、六controls、32聚合与08af运行的数学输出逐值一致；最终摘要与源码绑定已经重新运行，未用旧运行冒充新代码。独立verifier再次PASS，7034精确字段/32聚合零不一致；2532标量有限检查输出一致。最终JSON已替换工作区旧检查点。

主级元数据核验一度误在inputs内找producer_sha256而KeyError，实际字段在顶层；改正读取位置后绑定验证通过，未更改数据或重复数学计算。proof/FULL及求积误差的原有限性说明不变。
