#!/usr/bin/env python3
"""R153 exact dynamic-potential postprocess of frozen R151 points/models."""
from fractions import Fraction as F
from pathlib import Path
import argparse, hashlib, json, math, random, zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
R151ZIP = ROOT / 'rounds' / '151' / 'research.zip'
R152DIR = Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round152_20261015_final_checkpoint/work')
DETAIL = Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json')
R136 = Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/active_traffic_v2.json')
R142 = Path('/Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015/centered_cube_round142_20261015/numeric_receiver.json')
OUT = HERE / 'dynamic_probe.json'
TAU, H, G = F(1,4), F(3,2), F(2)

def sha(b): return hashlib.sha256(b).hexdigest()
def frac(v): return v if isinstance(v,F) else F(str(v))
def fs(v): return f'{v.numerator}/{v.denominator}'
def weight(th,t):
    z=F(1)
    for a in th: z*=min(F(1),a/t)
    return z
def kcount(th,t,right=False): return sum(a<=t if right else a<t for a in th)
def alive(src,t): return src['delete_time'] is None or t<src['delete_time']
def mass(src,t): return src['mass']*weight(src['thresholds'],t) if alive(src,t) else F(0)

def profile(srcs,t,r,right=False):
    A=B=KA=KB=e=F(0)
    for s in srcs:
        m=mass(s,t); e+=m
        k=kcount(s['thresholds'],t,right)
        if s['kind']=='G' and k>r:
            z=s['rho']*m; A+=z; KA+=k*z
        elif s['kind']=='D' and k<=r:
            B+=m; KB+=k*m
    return A,B,KA,KB,e

def phi(A,B,c): return A/(A+B+c)
def psi(A,B,c,r): return A*B/((B+(r+1)*c)*(A+B+c))

def model_cut(srcs,r,c,tau=TAU,h=H,beta_raw=None):
    # H uses actual G/D events. X deletion is retained in e, but cannot jump A/B.
    events=sorted({sorted(s['thresholds'])[r] for s in srcs if s['kind'] in ('G','D') and r<len(s['thresholds']) and tau<sorted(s['thresholds'])[r]<h})
    times=[tau,*events,h]
    cache={}
    def state(t,right):
        key=(t,right)
        if key not in cache: cache[key]=profile(srcs,t,r,right)
        return cache[key]
    at=state(tau,True); end=state(h,False)
    d0=at[1]/(at[1]+(r+1)*c) if at[1]+(r+1)*c else F(0)
    initial=psi(at[0],at[1],c,r); terminal=-psi(end[0],end[1],c,r)
    hold_init=d0*phi(at[0],at[1],c); hold_term=-d0*phi(end[0],end[1],c)
    jplus=jminus=hold_jump=jump_sum=F(0); event_rows=[]
    for t in events:
        lm=state(t,False); rp=state(t,True)
        dj=psi(rp[0],rp[1],c,r)-psi(lm[0],lm[1],c,r)
        dphi=phi(rp[0],rp[1],c)-phi(lm[0],lm[1],c)
        badfirst=psi(lm[0],rp[1],c,r)-psi(lm[0],lm[1],c,r)
        goodafter=psi(rp[0],rp[1],c,r)-psi(lm[0],rp[1],c,r)
        jplus+=max(dj,F(0)); jminus+=max(-dj,F(0)); jump_sum+=dj; hold_jump+=d0*dphi
        event_rows.append({'t':fs(t),'dA':fs(rp[0]-lm[0]),'dB_removed':fs(lm[1]-rp[1]),'delta_Psi':fs(dj),'delta_Phi':fs(dphi),'badfirst_net':fs(badfirst),'badfirst_positive_part':fs(max(badfirst,F(0))),'good_after_bad':fs(goodafter),'sign':'pos' if dj>0 else ('neg' if dj<0 else 'zero'),'simultaneous':rp[0]>lm[0] and rp[1]<lm[1]})
    dyn=hold=F(0)
    for l,rr in zip(times,times[1:]):
        pl=state(l,True);pr=state(rr,False)
        dyn+=psi(pl[0],pl[1],c,r)-psi(pr[0],pr[1],c,r)
        hold+=d0*(phi(pl[0],pl[1],c)-phi(pr[0],pr[1],c))
    hd=initial+terminal+jump_sum
    hh=hold_init+hold_term+hold_jump
    assert hd==dyn and hh==hold and hd>=0 and hold>=0
    # Verify pointwise regular drift formula and lower-bound hypotheses on every open interval.
    regular_ok=True; max_ratio=None; kb_positive=False; r0_bound=True; conditions=True
    for l,rr in zip(times,times[1:]):
        mid=(l+rr)/2; A,B,KA,KB,e=state(mid,False); S=A+B+c; a=(r+1)*c
        if KB>0: kb_positive=True
        conditions &= c<=e and A+B<=e and KA>=(r+1)*A and KB<=r*B
        dp=((B+c)*KA-A*KB)/(S*S)
        dynG=(B/(B+a))*dp + a*phi(A,B,c)*KB/(B+a)**2
        assert dynG>=0
        if r==0: assert KB==0 and dynG<= (at[1]/(at[1]+c))*dp
    # An explicitly path-ordered bad-only finite-jump diagnostic; not the signed atom.
    bad_path_pos=F(0)
    for t in events:
        lm=state(t,False);rp=state(t,True)
        bad_only=psi(lm[0],rp[1],c,r)-psi(lm[0],lm[1],c,r)
        bad_path_pos+=max(bad_only,F(0))
    beta=beta_raw if beta_raw is not None else at[1]/c if c else F(0)
    fbeta=0.0 if beta<=1 else (float(beta-1)-math.log((float(beta)+1)/2))/8
    scalar_ok=float(bad_path_pos)<=fbeta+1e-14
    return {'r':r,'c':c,'initial':initial,'negative_terminal':terminal,'signed_jump':jump_sum,'Jplus':jplus,'negative_Jminus':-jminus,'Hdyn':hd,'Hold':hold,'Hdyn_le_Hold':hd<=hold,'dyn_vs_old_sign':'less' if hd<hold else ('greater' if hd>hold else 'equal'),'Hdyn_over_Hold':hd/hold if hold else None,'events':event_rows,'event_count':len(events),'regular_condition_pass':bool(conditions),'KB_positive_on_segment':kb_positive,'r0_bound_pass':r!=0 or hd<=hold,'bad_path_positive_jumps':bad_path_pos,'beta_raw':beta,'F_beta_numeric':fbeta,'bad_path_positive_jumps_le_F_beta_numeric':scalar_ok}

def encode(obj):
    if isinstance(obj,F): return fs(obj)
    if isinstance(obj,dict): return {k:encode(v) for k,v in obj.items()}
    if isinstance(obj,(list,tuple)): return [encode(v) for v in obj]
    return obj

def archived_generator(z):
    raw=z.read('cut_check.py'); ns={'__name__':'r151_generator','__file__':'research.zip:cut_check.py'}
    exec(compile(raw,'research.zip:cut_check.py','exec'),ns)
    return ns,sha(raw)

def pressure_cases(gen):
    atom=gen['atom'];fixed=gen['fixed_cases']();cases=[]
    for name,srcs,_t,c in fixed:
        eg=gen['profile'](srcs,G,0,'strict')[4];cases.append((name,srcs,min(c,eg),'initial'))
    t=F(1);ties=[atom([F(1,2),t,t],'G',2,F(1,2)),atom([F(1,3),t,t],'D',F(3,2)),atom([F(1,4),F(3,4),t],'X',1),gen['make_source']('X',[F(1,2),t,t],F(0),F(0),t)]
    eg=gen['profile'](ties,F(2),0,'strict')[4];cases.append(('ties_and_zero_mass',ties,min(F(1,3),eg),'initial'))
    rng=gen['random'].Random(151015)
    for i in range(48):
        n,srcs=gen['random_case'](rng,i);eg=gen['profile'](srcs,F(2),0,'strict')[4];c=eg*F(rng.randint(1,4),4);cases.append((f'expanded_{i:02d}',srcs,c,'expanded'))
    return cases

def run_pressure(cases,stage):
    chosen=[]
    for name,srcs,c,kind in cases:
        include=(stage=='initial' and kind=='initial') or (stage=='pressure' and kind=='expanded' and int(name[-2:])<8) or (stage=='expanded' and kind=='expanded' and int(name[-2:])>=8)
        if not include: continue
        beta_raw=sum((mass(s,TAU) for s in srcs if s['kind']=='D'),F(0))/c if c else F(0)
        cuts=[]
        for r in range(len(srcs[0]['thresholds'])):
            cuts.append(model_cut(srcs,r,c,beta_raw=beta_raw))
        ev=sum(x['event_count'] for x in cuts)
        bpos=sum((x['bad_path_positive_jumps'] for x in cuts),F(0));fbound=cuts[0]['F_beta_numeric'] if cuts else 0.
        chosen.append({'id':name,'kind':kind,'source_count':len(srcs),'n':len(srcs[0]['thresholds']),'c':c,'cuts':cuts,'cut_count':len(cuts),'event_rows':ev,'badfirst_positive_sum':bpos,'beta_raw':beta_raw,'F_beta_numeric':fbound,'badfirst_sum_le_F_beta':float(bpos)<=fbound+1e-14})
    return chosen

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--r151-zip',type=Path,default=R151ZIP);ap.add_argument('--r152-dir',type=Path,default=R152DIR);ap.add_argument('--detail',type=Path,default=DETAIL);ap.add_argument('--r136',type=Path,default=R136);ap.add_argument('--r142',type=Path,default=R142);ap.add_argument('--out',type=Path,default=OUT);a=ap.parse_args()
    z=zipfile.ZipFile(a.r151_zip);gen,gsha=archived_generator(z);pcases=pressure_cases(gen)
    stages={s:run_pressure(pcases,s) for s in ('initial','pressure','expanded')}
    # Main frozen I1 grid; import the pinned R152 producer for canonical two-score T and exact ST8 fields.
    oldj=json.loads((a.r152_dir/'cut_probe.json').read_text()); oldzip=zipfile.ZipFile(a.r151_zip); old= json.loads(oldzip.read('receiver_probe.json')); detail=json.loads(a.detail.read_text())
    r136=json.loads(a.r136.read_text()); src=next(x for x in r136['cases'] if x['id']=='I1'); th=[[F(str(v)) for v in x['thresholds']] for x in src['atoms']];nu=list(map(F,old['constants']['nu_exact']));tau=F(str(src['derived']['tau']));h=F(str(src['derived']['h']));eg=sum((nu[i]*weight(th[i],F(str(src['derived']['g']))) for i in range(6)),F(0))
    # R152 producer dependency is explicit and SHA-pinned.
    r152raw=(a.r152_dir/'cut_probe.py').read_bytes(); ns={'__name__':'r152_cut_reference','__file__':str(a.r152_dir/'cut_probe.py')};exec(compile(r152raw,'R152/cut_probe.py','exec'),ns)
    mainrows=[]
    for m in ('4','8'):
      for idx,row in enumerate(detail['point_records'][m]):
        rho=[F(str(x)) for x in row['rho']];c2=2*F(str(row['q']))/F(str(row['p']));legal=row['gates']['high'] and c2<=eg
        choices={'eg':eg}
        if legal: choices['2C']=c2
        candidates={}
        fake=[{'kind':'G' if row['good'][i] else 'D','thresholds':th[i],'mass':nu[i],'rho':rho[i] if row['good'][i] else F(0),'delete_time':None} for i in range(6)]
        for cv,c in choices.items():
          beta_raw=sum((nu[i]*weight(th[i],tau) for i in range(6) if not row['good'][i]),F(0))/c
          cuts=[model_cut(fake,r,c,tau,h,beta_raw=beta_raw) for r in range(4)]
          tc=ns['exact_cut'](th,nu,rho,row['good'],tau,h,c)[0]['Tcut']
          hd=sum((x['Hdyn'] for x in cuts),F(0));ho=sum((x['Hold'] for x in cuts),F(0))
          badfirst=sum((F(ev['badfirst_positive_part']) for cut in cuts for ev in cut['events']),F(0))
          goodafter=sum((F(ev['good_after_bad']) for cut in cuts for ev in cut['events']),F(0))
          candidates[cv]={'c':c,'cuts':cuts,'Hdyn':hd,'Hold':ho,'Tcut':tc,'Tcut_le_4Hdyn':tc<=4*hd,'Hdyn_gt_Hold_cuts':sum(x['Hdyn']>x['Hold'] for x in cuts),'badfirst_positive':badfirst,'good_after_bad':goodafter,'badfirst_sum_le_F_beta_numeric':float(badfirst)<=float(cuts[0]['F_beta_numeric'])+1e-14}
        mainrows.append({'m':m,'i':idx,'source':row,'legal2C':legal,'candidates':candidates})
    # Preserve the R152 32 aggregation keys and A/B weight conventions.
    agg={}
    for m in ('4','8'):
      for wt in ('original','corrected'):
       for cv in ('eg','2C'):
        for domain in ('pre','post','pre_high_legal','post_high_legal'):
         keys=('Hdyn','Hold','Tcut','4Hdyn','4Hold','initial','negative_terminal','signed_jump','Jplus','negative_Jminus','badfirst_positive','good_after_bad')
         SA={k:0. for k in keys};SB=SA.copy();count=0; massA=massB=volume=0.
         for z in mainrows:
          if z['m']!=m:continue
          r=z['source']
          if cv not in z['candidates']:continue
          if domain.startswith('pre') and not r['before']:continue
          if domain.startswith('post') and not r['after']:continue
          if domain.endswith('high_legal') and not z['legal2C']:continue
          w=float(F(str(r['dx_weight' if wt=='original' else 'dx_weight_corrected'])));p=r['p'];hard=float(F(str(r['hardmass'])));q=r['q'];aw=w*p;bw=aw*hard/q if q else 0.;volume+=w;massA+=aw;massB+=bw;count+=1
          cand=z['candidates'][cv]
          vals={'Hdyn':float(cand['Hdyn']),'Hold':float(cand['Hold']),'4Hdyn':4*float(cand['Hdyn']),'4Hold':4*float(cand['Hold']),'Tcut':float(cand['Tcut']),'initial':sum(float(x['initial']) for x in cand['cuts']),'negative_terminal':sum(float(x['negative_terminal']) for x in cand['cuts']),'signed_jump':sum(float(x['signed_jump']) for x in cand['cuts']),'Jplus':sum(float(x['Jplus']) for x in cand['cuts']),'negative_Jminus':sum(float(x['negative_Jminus']) for x in cand['cuts']),'badfirst_positive':float(cand['badfirst_positive']),'good_after_bad':float(cand['good_after_bad'])}
          for key,val in vals.items():SA[key]+=aw*val;SB[key]+=bw*val
         agg[f'{m}/{wt}/{cv}/{domain}']={'count':count,'sum_p_weight':massA,'sum_p_hard_over_q_weight':massB,'dx_volume':volume,'A':SA,'B':SB}
    # Summaries and compact per-pressure records; exact Fractions are serialized as reduced strings.
    flat=[x for v in stages.values() for x in v]
    pressure_summary={}
    for stage,rows in stages.items():
        cuts=[c for model in rows for c in model['cuts']]
        ratios=[c['Hdyn']/c['Hold'] for c in cuts if c['Hold']>0]
        rev=[x for x in ratios if x>1]
        pressure_summary[stage]={'models':len(rows),'cuts':sum(x['cut_count'] for x in rows),'event_rows':sum(x['event_rows'] for x in rows),'Hdyn_greater_cuts':sum(c['Hdyn']>c['Hold'] for c in cuts),'Hdyn_equal_cuts':sum(c['Hdyn']==c['Hold'] for c in cuts),'Hdyn_less_cuts':sum(c['Hdyn']<c['Hold'] for c in cuts),'max_reverse_factor':max(rev,default=None),'max_reverse_excess':max((x-1 for x in rev),default=None),'max_positive_absolute_reverse_excess':max((c['Hdyn']-c['Hold'] for c in cuts),default=F(0)),'regular_condition_failures':sum(not c['regular_condition_pass'] for c in cuts),'bad_path_scalar_model_failures':sum(not x['badfirst_sum_le_F_beta'] for x in rows),'bad_path_scalar_cut_subset_failures':sum(not c['bad_path_positive_jumps_le_F_beta_numeric'] for c in cuts)}
    allc=[cand for z in mainrows for cand in z['candidates'].values()]
    # Frozen six exact receiver controls: x0 and both archived B-contribution extrema.
    controls=[]
    picks=[('x0_control',None,None,old['x0_control'])]
    for m in ('4','8'):
        xq=old['summaries'][m]['extrema']['max_weighted_B_contribution']['xq']
        rr=next(z['source'] for z in mainrows if z['m']==m and z['source']['xq']==xq)
        picks.append((f'm{m}_max_weighted_B',m,next(z['i'] for z in mainrows if z['m']==m and z['source']['xq']==xq),rr))
    for label,m,idx,r in picks:
        rho=[F(str(x)) for x in r['rho']];c2=2*F(str(r['q']))/F(str(r['p'])) if r.get('p') else eg
        ok2=bool(r.get('gates',{}).get('high',False)) and c2<=eg; variants={'eg':eg}
        if ok2: variants['2C']=c2
        fake=[{'kind':'G' if r['good'][i] else 'D','thresholds':th[i],'mass':nu[i],'rho':rho[i] if r['good'][i] else F(0),'delete_time':None} for i in range(6)]
        for cv,c in variants.items():
            beta_raw=sum((nu[i]*weight(th[i],tau) for i in range(6) if not r['good'][i]),F(0))/c
            cc=[model_cut(fake,j,c,tau,h,beta_raw=beta_raw) for j in range(4)];tc=ns['exact_cut'](th,nu,rho,r['good'],tau,h,c)[0]['Tcut'];hd=sum((v['Hdyn'] for v in cc),F(0))
            controls.append({'label':label,'grid':m,'row_index':idx,'c_version':cv,'c':c,'cuts':cc,'Hdyn':hd,'Hold':sum((v['Hold'] for v in cc),F(0)),'Tcut':tc,'Tcut_le_4Hdyn':tc<=4*hd})
    ratio_exact=[c['Hdyn']/c['Hold'] for c in allc if c['Hold']>0]
    ratios=[float(x) for x in ratio_exact];reverse=[x for x in ratio_exact if x>1]
    out={'status':'complete_diagnostic','scope':'fixed frozen R151 points and archived 52 pressure models; no new kernel/receiver/model; not FULL or quadrature certification','producer_sha256':sha(Path(__file__).read_bytes()),'code_dependency':{'R152_source':'cut_probe.py exact two-score T primitive, dynamically loaded; SHA256 in inputs'},'inputs':{'r151_archive_sha256':sha(a.r151_zip.read_bytes()),'cut_check_member_sha256':gsha,'r152_checkpoint_script_sha256':sha(r152raw),'r152_checkpoint_json_sha256':sha((a.r152_dir/'cut_probe.json').read_bytes()),'r151_detail_sha256':sha(a.detail.read_bytes()),'r136_sha256':sha(a.r136.read_bytes()),'r142_sha256':sha(a.r142.read_bytes()),'plan_sha256':sha((HERE/'dynamic_numeric_plan.md').read_bytes())},'execution':{'new_kernels':0,'new_receiver_points':0,'frozen_receiver_rows':len(mainrows),'pressure_models':52,'pressure_cuts':sum(x['cut_count'] for x in flat),'pressure_event_rows':sum(x['event_rows'] for x in flat),'producer_attempts':None,'failed_attempts':None,'completed_attempts':None},'stage_summary':pressure_summary,'pressure_stages':stages,'receiver_controls':controls,'receiver_aggregates_32':agg,'receiver_row_diagnostics':{'row_count':len(mainrows),'cut_count':len(mainrows)*4,'Hdyn_vs_Hold_greater_cut_count':sum(c['Hdyn_gt_Hold_cuts'] for c in allc),'Hdyn_vs_Hold_less_cut_count':sum(sum(cut['Hdyn']<cut['Hold'] for cut in c['cuts']) for c in allc),'Hdyn_over_Hold_max_factor':max(ratios,default=None),'Hdyn_over_Hold_max_reverse_factor':float(max(reverse)) if reverse else None,'Hdyn_over_Hold_max_reverse_excess':float(max((x-1 for x in reverse),default=F(0))),'Hdyn_over_Hold_factor_gt_1_count':len(reverse),'Tcut_le_4Hdyn_failures':sum(not c['Tcut_le_4Hdyn'] for c in allc),'badfirst_crosscut_cap_failures':sum(not c['badfirst_sum_le_F_beta_numeric'] for c in allc),'eligible_c_versions':len(allc)},'scalar_bad_cap':{'formula':'F(beta)=0 if beta<=1 else ((beta-1)-log((beta+1)/2))/8','finite_pressure_check':'path-ordered bad-only event jumps only; not continuous/total path certificate','general_bound_source':'dynamic_audit.md §6'},'limitations':['pressure Hdyn and Hold are exact finite Fraction endpoint identities','I1 Tcut uses the pinned R152 exact two-score primitive; every frozen row/c version is recomputed by exact Fraction arithmetic','receiver weighted sums are binary64 diagnostics','pressure T is not assigned a rational primitive','scalar F(beta) uses floating log for finite path-jump comparison, not an exact transcendental certificate']}
    a.out.write_text(json.dumps(encode(out),separators=(',',':'))+'\n');print('rows',len(mainrows),'pressure',pressure_summary,'bytes',a.out.stat().st_size,'sha',sha(a.out.read_bytes()))

if __name__=='__main__':main()
