#!/usr/bin/env python3
import hashlib,json,subprocess,sys,tempfile
from pathlib import Path
p=Path(__file__).resolve().parent
manifest=json.loads((p/'manifest.json').read_text())
def check():
    for name,h in manifest.items():
        assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h,name
check()
with tempfile.TemporaryDirectory() as t:
    out=Path(t)/'result.json'
    subprocess.run([sys.executable,str(p/'numeric_checks.py'),'--output',str(out)],check=True)
    assert out.read_bytes()==(p/'numeric_checks.json').read_bytes(),'JSON mismatch'
check()
print('PASS: numeric JSON byte-identical; manifest pre/post verified; no general/FULL certificate claimed.')
