# R264 独立审核：有理低soft网格与实际hard窗平方几何

结论：最终截断有理网格、固定窗口与共同窗口平方缺口、monotone-profile Abel以及两条same-soft腿的联合尺度/时钟核界均通过；没有原FIRST/完整来源总账或一般root付款结论。本文件只写指定/tmp路径，不改项目、不Git/PDF。先独立核命题，未借作者证明。

## 1. 最终采用的有理网格

固定整数n≥1、0≤s0<1，令q_n=n/(n+1)，J最小使q_n^J≤1−s0，节点r<J取s_r=1−q_n^r，最后取s_J=s0（s0=0时J=0、单节点0）。r是aux soft索引，不是原比例j。对s≤s0，取r(s)最小使s_r≥s，则

\[
 s\le s_r,\qquad \frac{1-s}{1-s_r}\le q_n^{-1}.
\]

s=0取r=0。任意非负有限a,b满足

\[
 (1-s)a+sb\le\frac{1-s}{1-s_r}[(1-s_r)a+s_rb],
\]

因为hard系数相等，soft系数差为(s_r−s)/(1−s_r)≥0。乘n坐标得

\[
 P_{s,L}\le c_nP_{s_r,L},\qquad c_n=q_n^{-n}=(1+1/n)^n<e.
\]

物理L,R,g、原比例j和C/w均不重算。对

\[
 Q_s^*=(P_{s,L}+P_{s,L^+}+P_{1,b})/3,
 \quad L^+=\min(b,(1+1/n)L),
\]

两个moving腿用同一个r，固定J腿也≤c_nJ。因此

\[
 \frac{\sqrt{P_{s,L}(x-y)Q_s^*(x,v)}}{\sqrt w}
 \le c_n\max_{r\le J}
 \frac{\sqrt{P_{s_r,L}(x-y)Q_{s_r}^*(x,v)}}{\sqrt w}.
\]

只有M=J+1个节点，不是M²。原有效w>0；零交通纤维先置零。

log(1+1/n)≥1/(n+1)，所以

\[
 J\le(n+1)[-\log(1-s_0)]+1,
 \quad M\le2(n+1)s_0+2\quad(s_0\le1/2).
\]

当s0=2log n/(cn)≤1/2、c>0为共同绝对常数时，M≤8log n/c+2。s0=0实际M=1；s0≥1不在有限网格定理内。项目其余小维数不能凭此新增结算，沿原已授分支处理。

最后节点精确截到s0，相邻survival之比仍至少q_n，故同一c_n成立且所有节点≤s0。网格只是aux核包络，不授classifier或共同E上全部节点的FIRST。实际s(x)可测时r(s(x))可测，逐点正项可用这个receiver-dependent选择；原Π、good/bad、负信用不重建。

## 2. 新实际hard窗：allsoft、无维数平方损失

使用原物理C=h_1*max(h_1,φ)，φ=h_1*w、w=∫_0¹exp(−|·|/r)dr，f_s=(1−s)h_1+sφ。0≤f_s≤1，且f_s、max(h_1,φ)径向非增。固定y,v,z，L≤A≤b，s,σ∈[0,1]。定义

\[
 \bar w_L(y,v)=\prod_i\min\{1,bC(|y_i-v_i|/b)/L\},\quad
 F_L(x)^2=\frac{P_{s,L}(x-y)P_{\sigma,A}(x-v)}{\bar w_L(y,v)}.
\]

逐坐标的target窗口质量同时满足

\[
 m_i=\int_{z_i-b/2}^{z_i+b/2}A^{-1}f_\sigma((x-v_i)/A)dx\le1,
 \quad m_i\le(b/A)C(|z_i-v_i|/b).
\]

第一界来自概率核，第二界由A≤b及f_σ≤max(h,φ)后径向放到b。故乘积质量≤barw_A(z,v)≤barw_L(z,v)。又P_s,L≤L^-n，因此R260原C的log-Lipschitz12给

\[
 \boxed{L^n\int_{Q_b(z)}F_L^2dx
 \le\bar w_L(z,v)/\bar w_L(y,v)
 \le e^{\delta_z},\quad \delta_z=12\|y-z\|_1/b.}
\]

此处原C不重算、三来源槽不识别，不需节点FIRST。原near条件||y−z||1≤a/(16sqrt n)、a≤b给δ_z≤3/(4sqrt n)。原实际hard支撑Q_R(z)⊂Q_b(z)，所以确是可保留的同一hard-source窗口，而不是改中心的虚构receiver。

## 3. all-L monotone-profile平方包络

固定s,σ，令A(L)为L、min(γL,b)或常数b（γ≥1）。它非减且A(L')/A(L)≤L'/L。写F_L²=a(L)²B_L²，其中

\[
 a(L)^2=(LA(L))^{-n}/\bar w_L(y,v),\quad
 B_L(x)^2=\prod_i f_s((x_i-y_i)/L)f_\sigma((x_i-v_i)/A(L)).
\]

B_L²逐点非减。a²非增，因为L^-n/barw_L=∏max(1/L,1/[bC_i])非增，A(L)^-n亦非增。且

\[
 a(L')^2/a(L)^2\ge(L/L')^{2n}.
\]

对任意有限allowed尺度L1<...<Lm，正增量给

\[
 \sup_j a_j^2B_j^2\le\sum_j a_j^2(B_j^2-B_{j-1}^2),\quad B_0^2=0.
\]

积分于同一个固定Q_b(z)，用固定尺度a_j²∫B_j²≤D L_j^-n，再Abel求和，得

\[
 \int_{Q_b(z)}\sup_jF_{L_j}^2
 \le D\left[2L_1^{-n}-L_m^{-n}\right]\le2a^{-n}D.
\]

这是R263的有限求和证明用于非负monotone profile，非nested indicator等式；不以未证的sup积分交换代替。取D=e^δ_z即得all-L包络。一般allowed集通过从右稠密可数子集加right-isolated端点、单调极限处理；A(L)连续、hard边界采用一致约定。源参数变化时须保联合可测性，不能只授逐纤维可测。

## 4. 加强：保同来源的hard-overlap缺口

定义A0(u)=(1−u)+，V=h_1*φ，Ω_i=min(1,bC(|z_i−v_i|/b)/L)，ω_i=min(1,bC(|y_i−v_i|/b)/L)，Δ_L(y,v)=Σ(1−ω_i)，c0=φ(3/2)>0。target窗口质量还满足

\[
 m_i\le\min\{1,(b/A)[(1-\sigma)A_0(|z_i-v_i|/b)+\sigma V(|z_i-v_i|/b)]\}.
\]

这仍由逐项径向放大得到，不是新核。若Ω_i<1，除Ω_i得

\[
 m_i/\Omega_i\le(L/A)[(1-\sigma)A_0/C+\sigma V/C]
 \le1-c_0(1-\sigma)(1-\Omega_i).
\]

最后一步用R224 QG6的真实方向A0/C≤1−c0(1−Ω_i)，及V≤C、L/A≤1。Ω_i=1时只用m_i≤1。令α=c0(1−σ)，则

\[
 \prod_i m_i/\bar w_L(y,v)
 \le e^{\delta_z-\alpha\Delta_L(z,v)}
 \le e^{(1+\alpha)\delta_z-\alpha\Delta_L(y,v)}.
\]

第二步因为log-clamp给|logΩ_i−logω_i|≤12|y_i−z_i|/b，exp在负半轴1-Lipschitz，故Σ|Ω_i−ω_i|≤δ_z。因而第3节可用

\[
 D=e^{(1+\alpha)\delta_z-\alpha\inf_{L\in\mathcal A}\Delta_L(y,v)}.
\]

固定实际s≤s0<1/2的两条same-soft腿σ=s有α≥c0/2；第三J腿σ=1有α=0，**没有这个缺口**，不能由另两腿免费消去。单有raw活跃数并不保证Δ大；若保原score interior门c_jt≤q0 L、0<q0<1，才有Δ_L≥(1−q0)k_t(y,v)。门的补集仍需另计。

组合最终截断有理网格时，所有节点≤s0，故固定z的same-soft两腿统一可取α_min=c0(1−s0)≥c0/2（s0≤1/2）。正的δ系数可上放为1+c0。

## 5. 网格与平方的合法组合、边界

第1节正包络可平方，再用max≤sum，将第3节分别用于每个固定节点。对含1/3平均的Q*，

\[
 \int_{Q_b(z)}\sup_{s\le s_0,L}
 \frac{P_{s,L}(x-y)Q_s^*(x,v)}{\bar w_L(y,v)}dx
 \le2c_n^2M a^{-n}e^{\delta_z}.
\]

每node的三腿先按1/3平均，各腿平方价相同，所以该aggregate写法没有多出的3；若原证明使用三半腿之和，则须按其Cauchy步骤另记对应常数。增强缺口只适用于两same-soft腿，J项保无缺口价。

若从barw_L回原w_g=barw_(c_jg)，原比例带只给c_jg≤γ min(L,R)≤γL，故w_g≥γ^-n barw_L。半核转换另有γ^(n/2)≤sqrt e、square转换≤e；只在此前未付此R222转换时收一次，不重复收取。

以上不授网格节点FIRST，也没有支付原h_R幅度、hard来源积分、Π来源质量或signed负账；下面第8节仅支付固定来源核的score/clock费用。只有固定且独立receiver/尺度的来源测度才能接Minkowski；裸Π固定seed,V,j,t后可独立x，但actual j(x)、窗口、good/high/history、归一化与三腿组合不能直接当同一个固定来源测度。完整soft-to-traffic结算仍未闭合。

## 6. 实际计算等级

本人实际重新运行16个标准库Fraction最终截断有理网格same-node配置（n1/2/8/32×四个s），核两个affine槽及含固定J的Q*、平方消根后的半乘积c_n界；另核n512的精确c_n<3。3个actual-C低维固定窗用mp40分段普通quad核第2节square上界，全部通过。此前exp网格12项mp70仅为旧候选实现诊断，不作为本最终有理证书。所有有限检查均非FULL、非interval、非新来源预算证明；一般结论由上述解析论证支持。


## 7. 已消hard来源后的共同窗口缺口

固定W_y=Q_(b+d)(y)、δ_geo=d/b，仍用第2节原物理核与barw_L。逐坐标clamp ω_i<1时，把两个无量纲profile尺度径向放大到b，展开四项。硬硬全积分≤A0，两个硬软全积分各≤V，软软在长度1+δ_geo的窗口内≤(1+δ_geo)V（用原φ(t)φ(t−D)≤V(D)）。因此除以ω_i并用L/A≤1、V≤C及硬硬缺口，得到

\[
 L\int_{W_{y,i}}P_{s,L}P_{\sigma,A}/\omega_i
 \le 1+\delta_{\rm geo}s\sigma-c_0(1-s)(1-\sigma)(1-\omega_i).
\]

这里一维P表示对应一维因子。ω_i=1时直接用∫PP≤1/A≤1/L；其缺口为零也满足右侧指数界。相乘及1+x≤e^x给

\[
 \boxed{L^n\int_{W_y}F_L^2\le
 \exp\{n\delta_{\rm geo}s\sigma-c_0(1-s)(1-\sigma)\Delta_L(y,v)\}.}
\]

两moving腿σ=s≤s0≤1/2统一α≥c0/4，prefactor指数≤nδ_geo s0²；J腿σ=1仍无缺口。最后节点截断使这些率直接对全部网格成立。

这只可在合法保留near支持后，把已积分hard来源所得的接收门正上放为1_Wy：x∈Q_R(z)、R≤b、||y−z||∞≤d/2确实蕴含x∈W_y。此前若已用hardcap消掉hard来源，不能重新插入h_R或再花一次hardcap。此前已经破坏同权的signed负项不能使用此正上界。

## 8. 两moving腿：联合全尺度/时钟核界与常数

统一假设固定窗口下

\[
 L^n\int F_L^2\le e^{\mathcal E-\alpha\Delta_L},\qquad\alpha>0.
\]

固定z取α=c0(1−s)、mathcal E=(1+α)δ_z；共同窗口取α=c0(1−s)²、mathcal E=nδ_geo s²。令c_i=bC(|y_i−v_i|/b)，N_l=#\{i:c_i<l\}。对固定u∈[1/2,1]，N_(γuL)随L非减，因此第3节的profile可替换为N_(γuL)²B_L²，幅度仍相同。若γu<1，每个激活坐标有ω_i<γu，故

\[
 \Delta_L\ge(1-\gamma u)N_{\gamma uL}.
\]

第3节取固定列常数为e^mathcal E sup_(0≤k≤n) k²e^(−α(1−γu)k)，得到

\[
 \left\|\sup_{L\in\mathcal A}N_{\gamma uL}F_L\right\|_2
 \le\sqrt2a^{-n/2}e^{\mathcal E/2}
 \begin{cases}\min\{n,2/[e\alpha(1-\gamma u)]\},&\gamma u<1,\\ n,&\gamma u\ge1.\end{cases}
\]

无需对阈值点求导，严格不等号定义的N仍单调。允许尺度集及sup须联合可测；有限尺度耗尽与右稠密可数化按第3节执行。

原比例带c_jg(x)≤γmin(L(x),R(x))≤γL(x)给k_t≤N_(γuL(x))，u=t/g(x)。原有效窗满足τ=a/c_j≤t≤g≤bc_j，故u≥a/(bc_j²)≥1/2、u≤1，且dt/t=du/u。这是整段原有效clock的核上界，不是只保interior而遗留terminal strip。

设A=2/(eα)。末端u≥1/γ的费用≤nlogγ≤1。内段q=γu≥1/2、v=1−q，用dq/q≤2dq得

\[
 I_n(\alpha)\le 1+2\int_0^1\min(n,A/v)dv
 \le1+\frac4{e\alpha}\left[1+\log_+\left(\frac{e\alpha n}{2}\right)\right]
 =:\mathcal C_\alpha(n).
\]

n=1内段为空。若n≤A，积分为n≤A；否则直接分v=A/n积分，所以该式包含全部端点。于是

\[
 \int_{1/2}^1\left\|\sup_LN_{\gamma uL}F_L\right\|_2\frac{du}{u}
 \le\sqrt2a^{-n/2}e^{\mathcal E/2}\mathcal C_\alpha(n).
\]

Minkowski也控制把clock积分放在L2范数内部的同一表达。0<α≤1时可粗化mathcal Cα(n)≤4α^-1 log(n+2)。最终软网格逐u用max≤平方和，统一α_*与mathcal E_*后，右侧只增c_n√M（可保守写e√M），不是M或M²。固定z α_*≥c0/2；共同窗口α_*≥c0/4。J腿α=0只保nlog2，不授以上logclock改善。

关键剩余：u=t/g(x)使实际完整Π_(y,ug(x))依赖x；保原t时u则不是共同参数。不能把该Π及receiver-dependent high、good、history当静态σ移出L2。裸Π在固定seed,V,j,t可独立x，与整个actual selector组合依赖x不矛盾。这项核定理没有支付逆度数、完整source质量、J腿或signed连续恢复费用。

## 9. 最后窄审与有限证据

独立重新执行最终截断Fraction网格16配置（每配置四个内部s）、n512 c_n<3，全部PASS。另实际mp50分段积分检查20组clock常数（n=1,2,16,512,2^20；α=.01,.08,.5,1），mathcal C上界及4α^-1log(n+2)均PASS。普通mp积分不是区间证书，未新增physical/FULL模型。一般定理由第8节解析证明支持。

最后只核读作者/tmp/r264_main.md新增§7及与其相连的§4a：weighted Abel、mathcal C常数、terminal strip、两moving腿/J区别与Π_(y,ug(x))限制均一致。作者§5旧exp上网格仍是合法备选，但已通知其同步父最终截断有理网格；最终截断版本可直接授α≥c0/4；旧未截断版本则须另核其s_top≤1/2。此文字/版本同步不影响本文件最终证明。


## 10. 主整合稿末读（R264）

已逐项窄读主稿proof.tex.txt，受审SHA256 `2a54cb648cfcdfc1d1e111028ae8a11139658855db4fa26e1ee249cf3a6e85da`。结论PASS：最终末节点截断有理网格、共同窗口(5)的α=c0(1−s)(1−σ)、两moving腿(8)完整clock与c_n√M、实际far映射t/g≥1/2、a^(-n/2)量纲与O(log^(3/2)n)范围均准确。原wg比较至多sqrt(e)且只付一次；R222第二分母的正放方向与near共同窗口保留正确；未重新插hardcap。主稿准确保留Π_(y,j,ug(x))依x的来源耦合、J无gap、signed恢复/删除净额未付，不宣称一般root或全局闭合。此次没有重跑已通过计算，也未改任何项目文件。
