# R264 auxiliary: a genuine hard-source window square column

Status: proved fixed-window kernel geometry, plus an explicit original-posterior bridge. No general traffic payment or weak-(1,1) closure is claimed. Only this `/tmp` file is owned. No source is changed and no negative credit is spent.

## A1. Definitions and exact statement

Write Q_R(z)=z+[-R/2,R/2]^n and

h=1_{[-1/2,1/2]}, w(u)=∫_0^1 exp(-|u|/r)dr, φ=h*w,
f_s=(1-s)h+sφ, P_{s,L}(u)=L^{-n}∏_i f_s(u_i/L).

The densities h,φ,f_s have integral one; φ is even, radially nonincreasing, and 0≤φ≤φ(0)<1. Put F=max(h,φ) and C(d)=∫_{-1/2}^{1/2}F(u-d)du. For r>0 define the **original** window weight

barw_r(y,v)=∏_i min(1,b C(|y_i-v_i|/b)/r).

For all n≥1, 0<L≤A≤b, θ>0, s,σ∈[0,1], and arbitrary y,z,v∈R^n, let d_1=||y-z||_1 and c(s)=1-s+sφ(0). Then

(1)  ∫_{Q_b(z)} P_{s,L}(x-y)P_{σ,A}(x-v)/barw_{θL}(y,v) dx
     ≤ c(s)^n L^{-n} exp(12d_1/b) max(1,θL/A)^n.

In particular θ=1 has no aspect or dimension fee beyond the physical L^{-n}. The statement is uniform in both independent soft parameters. Replacing the integration window by any measurable subset, including the actual Q_{R(x)}(z) pointwise restriction R(x)≤b, is legitimate. It does not remove the hard-kernel normalization R(x)^{-n}.

## A2. Proof with an explicit global constant

The source bound is P_{s,L}≤c(s)^n L^{-n}. For a target coordinate, f_σ≤F and A≤b give

∫_{z_i-b/2}^{z_i+b/2} A^{-1}f_σ((x-v_i)/A)dx
 ≤ min(1,(b/A)C(|z_i-v_i|/b)).

Here the bound by one uses the normalized target density. The other bound uses radial decrease: F((x-v_i)/A)≤F((x-v_i)/b). Multiplication gives target window mass ≤barw_A(z,v).

We now prove |log C(u)-log C(v)|≤12|u-v|. C is even and decreasing on the positive half-line. For 0≤d≤1, |C'(d)|≤1 almost everywhere: differentiation of its interval integral gives C'=F(d+1/2)-F(d-1/2), and 0≤F≤1. Furthermore

C(1)=∫_0^1 r²(1-e^{-1/r})²dr >1/12,

because e>2 implies 1-e^{-1/r}>1/2 for 0<r≤1. Thus on [0,1], |(log C)'|≤1/C(1)<12. For d≥1 the exact formula is

C(d)=∫_0^1 r²(1-e^{-1/r})²e^{-(d-1)/r}dr.

Cauchy-Schwarz gives CC''-(C')²≥0 on (1,∞), so log C is convex there. Consequently -(log C)' is nonincreasing and its bound at 1 is at most 1/C(1)<12. Continuity/absolute continuity across 0 and 1 establishes the global assertion. These arguments concern Lebesgue integrals; closed hard-core boundary conventions do not change them.

The map log C↦log min(1,bC/r) is 1-Lipschitz. Therefore

barw_A(z,v)≤exp(12d_1/b)barw_A(y,v),
barw_A(y,v)/barw_{θL}(y,v)≤max(1,θL/A)^n.

Combining the source height and target window mass proves (1). The calculation preserves the same C and denominator used by the original clock; no component-dependent weight has been substituted.

For the original near gate d_1≤a/(16√n), the exponential is at most exp(3a/(4b√n))≤exp(3/(4√n)).

## A3. The actual three physical legs and denominator

Let γ=1+1/n. The original legs are

K_1=P_{s,L}(x-v), K_2=P_{s,L^+}(x-v), J=P_{1,b}(x-v),
L^+=min(b,γL),   p_y=P_{s,L}(x-y).

The original ratio-band relation is m=min(L,R)≤c_jg≤γm≤γL. Since barw is decreasing in its radius,

w_g=barw_{c_jg}(y,v)≥barw_{γL}(y,v).

Applying (1) to each fixed physical leg costs at most γ^n≤e (and its fixed-soft c(s)^n can be retained). This holds independently of the orientation R≤L or R>L. No already-used hardcap is called again.

For reference the exact good inequality itself permits a single positive square:

p_y w_g≤(K/3)(K_1+K_2+J)
 ⇒ p_y≤√(K/3)√[p_y(K_1+K_2+J)/w_g].

Thus one need not expand the square of a sum of three half-densities. This is an upper bound for the original good positive term; the source, history and classifier are unchanged.

## A4. The original far-clock range and what stays fixed

This is an audit of original definitions, not a new clock estimate. R128 frozen `proof.md:637` defines

τ_j=a/c_j,   g≤b c_j,   h=g exp(-u_0/n),
J_far=I_{j,V,y}∩[τ_j,h],   c_j=γ^{-j}≤1.

The fixed cutoff u_0>0 is selected before all sources. Every actual far time obeys

1/2≤a/b≤a/(b c_j²)≤τ_j/g≤t/g≤h/g≤1.

Thus the full actual J_far lies in [g/2,g]; it need not fill this window. R257 frozen `actual_bridge.md:162–169` independently records the same chain as loglength(J_far)≤log(b c_j²/a)≤log2. Empty windows contribute zero.

Call the normalized variable r=t/g(x) to distinguish it from u_0 and from an auxiliary bad source. At fixed original t, Π_{y,j,t} is independent of x (R128 `proof.md:650`). After t=r g(x), the law becomes Π_{y,j,r g(x)}, which generally depends on x. The Jacobian dt/t=dr/r at each fixed x does not make this a source law fixed before the receiver integral. All selectors and time/history indicators must remain when performing that change of variable.

## A5. The hard-source account and the precise legal bridge

Before the R222 hardcap the original positive mother has factor

(2Λ/q) p_y(x)h_{R(x)}(x-z)a_ω(x,y,z)
 dx β(dy)ν(dz) Π_{y,j,t}(dv)Π_{y,j,t}(du) dt/t,

with all original positive gates, ρ_0 and δ_t. The good replacement of A3 contributes √(K/3). The fixed-window result applies while this original hard z is retained: the actual hard support is a subset of Q_b(z), and the original w_g may be compared directly to barw_{γL} with its square fee γ^n≤e. Equivalently one can first compare w_g≥γ^{-n}barw_L and then use (1) with θ=1. These are two versions of the same comparison; they must not both be charged. Keeping h_R in a square integral still retains its factor R^{-n}; the bound h_R≤a^{-n}1_{Q_b(z)} explicitly costs a^{-n} if used.

For an x-independent finite positive source law σ(dy,dv,dz), supported on the near gate, a uniform bound ∫_{Q_b(z)}F_{y,v}(x)²dx≤D(y,z) legitimately gives the corresponding Minkowski square-column bound before source integration. A bare Π_{y,j,t} at fixed y,j,t is such a probability source kernel. A receiver-selected effective law is not. This distinction is not removed by the uniformity of (1).

After R222 SOCC4, the exact near contribution is instead encoded by

H_R(x)=∫h_R(x-z)ν(dz),
η_near(x,y,v,u,t)=H_R(x)^{-1}∫h_R(x-z)a_ω M ρ_0
                         1_{||y-z||_1≤a/(16√n)}ν(dz),

on E∩{H_R>0}, and zero elsewhere. Here M is the full original indicator product; if ρ_0 depends on z it stays inside the integral. Hence

q^{-1}∫h_R a_ω Mρ_0 1_near F_{y,v}ν(dz)
   =(H_R/q)η_near F_{y,v}≤(16/3)η_near F_{y,v}.

The already-paid R222 SOCC11 outside coefficient is

(32Λ/3)√(K/3) γ^{n/2},

if its barw_L version is used. It contains the one γ^{n/2} half-density comparison above. It must not receive another √e from the same ratio band. SOCC11's two orientation masks keep the stronger R≤L capture comparison when used; the coarser barw_L bound is available in both orientations.

The exact near η remains a **conditional hard-source average**, with 0≤η_near≤1 and the near support retained. If it is positive, then for at least ν-supported permitted hard sources, x∈Q_{R(x)}(z) and ||y-z||_1≤a/(16√n). Consequently its receiver support is contained, modulo null sets, in Q_b(y)+B_1(a/(16√n)). This is a union of windows, not one freely fixed Q_b(z). Applying (1) after hard-source elimination requires a valid joint bound for this conditional average (or retaining the original raw hard source throughout); selecting a different z for each x and then using a fixed-z column estimate would be invalid. Reintroducing ν(dz), h_R or q^{-1} on top of SOCC11 would likewise spend/recreate its source slot twice.

The result supplied here is therefore the exact fixed-hard-source kernel input, its unique original w_g price, and the confirmed original normalized clock range. The new common-window/weighted-score argument of the main R264 proof may use this input, but its source/receiver integration is not silently supplied by this auxiliary file. In particular no original two-Π score, full j sum, β mass, history or signed credit has been declared paid here.

## A6. Actual local tool diagnostic, distinct from proof

Python 3 with local mpmath 1.3.0, 35 decimal digits, ran six true one-dimensional window integrals. The input has b=1,y=0,z=.01 and (L,A,s,σ,v,θ) as below. φ and C are evaluated by their positive-integral equivalent E_k formulas; quadrature is split at both hard-core boundaries. This ordinary high precision check is not directed interval certification and is not a FULL input/history.

|case|parameters|mass|bound (1), c(s) replaced by 1|ratio|
|---|---|---:|---:|---:|
|1|(.5,1,0,0,.2,1)|1|2.25499370315875134|.443460218358578758|
|2|(.5,1,.5,.5,2,1)|.211493816494238716|2.25499370315875134|.093789094044024287|
|3|(1,1,1,1,4,1)|.507533846316449169|1.12749685157937567|.450142140623723803|
|4|(.5,.5,.5,1,1,2)|.442366933529547481|4.50998740631750269|.098086068468814010|
|5|(.75,1,1,.5,3,2)|.460779516097054983|2.25499370315875134|.204337384823560258|
|6|(1,1,0,1,0,1)|.501513674445218585|1.12749685157937567|.444802727158579626|

Returned C(1)=.1862311918978721786683853, φ(0)=.5567912714496430852614012, maximum ratio .4501421406237238027944286, exit 0. Endpoints s=0,1 are kernel diagnostics, not a claim that the original strictsoft inputs include their endpoints.

Complete replay code (the vendor path is the existing local mpmath installation):

```python
import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as m
m.mp.dps=35
E=lambda k,x:m.expint(k,x)
def phi(x):
    x=abs(x)
    return E(3,x-m.mpf('.5'))-E(3,x+m.mpf('.5')) if x>=m.mpf('.5') else 1-E(3,m.mpf('.5')-x)-E(3,m.mpf('.5')+x)
def C(x):
    x=abs(x)
    return 1-x+m.mpf(1)/3-E(4,x)-E(4,1)+E(4,x+1) if x<=1 else E(4,x-1)-2*E(4,x)+E(4,x+1)
def f(s,x): return (1-s)*int(abs(x)<=m.mpf('.5'))+s*phi(x)
y=m.mpf(0);z=m.mpf('.01');b=m.mpf(1)
cases=[('.5','1','0','0','.2','1'),('.5','1','.5','.5','2','1'),('1','1','1','1','4','1'),('.5','.5','.5','1','1','2'),('.75','1','1','.5','3','2'),('1','1','0','1','0','1')]
rat=[]
for L,A,s,t,v,th in cases:
    L,A,s,t,v,th=map(m.mpf,(L,A,s,t,v,th))
    w=min(1,b*C(y-v)/(th*L));lo=z-b/2;hi=z+b/2
    pts=sorted(set([lo,hi]+[q for q in [y-L/2,y+L/2,v-A/2,v+A/2] if lo<q<hi]))
    val=sum(m.quad(lambda x:f(s,(x-y)/L)*f(t,(x-v)/A)/(L*A*w),[q,r]) for q,r in zip(pts,pts[1:]))
    bound=L**-1*m.exp(12*abs(y-z)/b)*max(1,th*L/A)
    rat.append(val/bound)
    print('case',len(rat),'mass',m.nstr(val,18),'bound',m.nstr(bound,18),'ratio',m.nstr(rat[-1],18))
print('C1',m.nstr(C(1),25),'phi0',m.nstr(phi(0),25),'max_ratio',m.nstr(max(rat),25))
assert all(q<=1 for q in rat)
```
