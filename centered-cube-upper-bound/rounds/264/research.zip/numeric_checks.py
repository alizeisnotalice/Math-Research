#!/usr/bin/env python3
"""R264 actual one-coordinate square-window integrals; ordinary mpmath evidence."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp

def enc(v):return mp.nstr(v,60)
def phi(u):
 u=abs(u)
 if u<=mp.mpf('.5'):return 1-mp.expint(3,mp.mpf('.5')-u)-mp.expint(3,mp.mpf('.5')+u)
 return mp.expint(3,u-mp.mpf('.5'))-mp.expint(3,u+mp.mpf('.5'))
def C(d):
 d=abs(d)
 if d<=1:return 1-d+mp.mpf(1)/3-mp.expint(4,d)-mp.expint(4,1)+mp.expint(4,d+1)
 return mp.expint(4,d-1)-2*mp.expint(4,d)+mp.expint(4,d+1)
def P(s,L,x):return ((1-s)*(1 if abs(x)<L/2 else 0)+s*phi(x/L))/L

def splitquad(fn,lo,hi,knots):
 pts=sorted(set([lo,hi]+[p for p in knots if lo<p<hi]))
 return sum(mp.quad(fn,[a,b]) for a,b in zip(pts,pts[1:])),pts

def menu():
 rows=[]
 def add(stage,L,A,v,s,sigma,shift=False):
  key=f'c{len(rows):02d}';rows.append(dict(key=key,stage=stage,L=L,A=A,v=v,s=s,sigma=sigma,z='1/4096' if shift else '0'))
 add('initial','1','1','0','0','0')
 for z in [False,True]:add('initial','1/2','1/2','3/5','1/100','1/5',z)
 for z in [False,True]:add('initial','3/4','3/4','11/10','1/5','1/5',z)
 for z in [False,True]:add('stress','1/2','3/4','2','1','1/100',z)
 for z in [False,True]:add('stress','3/4','1','4','1/5','1',z)
 add('stress','1','1','3/5','1','0')
 for z in [False,True]:add('expanded','1/2','1/2','4','1','1',z)
 for z in [False,True]:add('expanded','3/4','27/32','3/5','1/5','1/100',z)
 add('expanded','1','1','11/10','1/100','1')
 return rows

def mm(v):
 f=F(v);return mp.mpf(f.numerator)/f.denominator

def run(dps):
 with mp.workdps(dps):
  rows=[];raw={};alpha0=phi(mp.mpf('1.5'))
  for spec in menu():
   L,A,v,s,sig,z=[mm(spec[k]) for k in ['L','A','v','s','sigma','z']]
   assert mp.mpf('.5')<=L<=A<=1
   omega=min(mp.mpf(1),C(v)/L)
   val,knots=splitquad(lambda x:P(s,L,x)*P(sig,A,x-v),z-mp.mpf('.5'),z+mp.mpf('.5'),[-L/2,L/2,v-A/2,v+A/2])
   D=L*val/omega;delta=12*abs(z);gap=1-omega;alpha=alpha0*(1-sig)
   logD=mp.log(D) if D else mp.ninf;basic=delta;enhanced=(1+alpha)*delta-alpha*gap
   assert logD<=basic+mp.mpf('1e-25') and logD<=enhanced+mp.mpf('1e-25')
   raw[spec['key']]=(logD,delta,alpha,gap,abs(z))
   rows.append(dict(spec,Omega=enc(omega),integral=enc(val),D=enc(D),log_D=enc(logD),delta=enc(delta),alpha=enc(alpha),gap=enc(gap),basic_log_margin=enc(basic-logD),enhanced_log_margin=enc(enhanced-logD),split_points=[enc(x) for x in knots]))
  tensors=[]
  # Each shifted coordinate is used once, so its l1 displacement remains
  # <= a/(16sqrt(n)) even at n128, a=.5. All other coordinates have z=y.
  pairs=[('c01','c02'),('c03','c04'),('c05','c06'),('c07','c08'),('c10','c11'),('c12','c13')]
  for n in [1,2,8,32,128]:
   for base,shift in pairs:
    for mode in ['repeated_unshifted','one_shifted']:
     keys=[base]*n
     if mode=='one_shifted':keys[0]=shift
     ld=sum(raw[k][0] for k in keys);delta=sum(raw[k][1] for k in keys);near=sum(raw[k][4] for k in keys)
     erhs=sum((1+raw[k][2])*raw[k][1]-raw[k][2]*raw[k][3] for k in keys)
     assert near<=mp.mpf('.5')/(16*mp.sqrt(n));assert ld<=delta+mp.mpf('1e-24') and ld<=erhs+mp.mpf('1e-24')
     tensors.append({'n':n,'mode':mode,'base':base,'shift':shift if mode=='one_shifted' else None,'l1_near_shift':enc(near),'near_limit':enc(mp.mpf('.5')/(16*mp.sqrt(n))),'log_D_product':enc(ld),'delta':enc(delta),'basic_log_margin':enc(delta-ld),'enhanced_log_rhs':enc(erhs),'enhanced_log_margin':enc(erhs-ld)})
  # Independent actual-phi r integrals at four points, no nested spatial quad.
  checks=[]
  for u in map(mp.mpf,['0','.5','1.5','4']):
   if u<=mp.mpf('.5'):
    q=mp.quad(lambda r:r*(2-mp.exp(-(.5-u)/r)-mp.exp(-(.5+u)/r)),[0,1])
   else:q=mp.quad(lambda r:r*(1-mp.exp(-1/r))*mp.exp(-(u-.5)/r),[0,1])
   checks.append({'u':enc(u),'E3_value':enc(phi(u)),'direct_r_integral':enc(q),'absolute_residual':enc(abs(q-phi(u)))})
  return {'scalars':rows,'tensors':tensors,'phi_independent_checks':checks,'phi_1_5':enc(alpha0)}

def clock(dps):
 with mp.workdps(dps):
  c0=phi(mp.mpf('1.5'));rows=[];checks=0;maxratio=mp.mpf(0)
  for n in [1,2,8,32,128,1024,10000,1000000]:
   stage='initial' if n<=8 else 'stress' if n<=1024 else 'expanded'
   gamma=1+mp.mpf(1)/n
   for divisor in [2,4]:
    alpha=c0/divisor;cut=2/(mp.e*alpha*n)
    knots=[1/gamma,(1-cut)/gamma]
    def env(u):
     v=max(mp.mpf(0),1-gamma*u)
     return mp.mpf(n) if v==0 else min(mp.mpf(n),2/(mp.e*alpha*v))
    val,pts=splitquad(lambda u:env(u)/u,mp.mpf('.5'),mp.mpf(1),knots)
    # Independent closed primitive on each selected branch.
    closed=mp.mpf(0)
    for a,b in zip(pts,pts[1:]):
     mid=(a+b)/2;v=1-gamma*mid
     if v<=cut:closed+=n*mp.log(b/a)
     else:closed+=2/(mp.e*alpha)*(mp.log(b/a)-mp.log((1-gamma*b)/(1-gamma*a)))
    bound=1+4/(mp.e*alpha)*(1+max(mp.mpf(0),mp.log(mp.e*alpha*n/2)))
    assert abs(val-closed)<mp.mpf('1e-23') and val<=bound
    local=mp.mpf(0)
    if n<=1024:
     for j in range(17):
      u=mp.mpf('.5')+mp.mpf(j)/32;v=max(mp.mpf(0),1-gamma*u)
      actual=max(mp.mpf(k)*mp.exp(-alpha*v*k/2) for k in range(n+1))
      assert actual<=env(u)*(1+mp.mpf('1e-27'))
      ratio=actual/env(u);local=max(local,ratio);maxratio=max(maxratio,ratio);checks+=1
    rows.append({'stage':stage,'n':n,'alpha_divisor':divisor,'alpha':enc(alpha),'transition_defect':enc(cut),'log_regime_nonempty':cut<max(mp.mpf(0),1-gamma/2),'split_points':[enc(u) for u in pts],'upper_envelope_integral':enc(val),'independent_closed_integral':enc(closed),'closed_residual':enc(abs(val-closed)),'proposed_bound':enc(bound),'bound_margin':enc(bound-val),'ratio_to_bound':enc(val/bound),'integer_grid_max_ratio':enc(local) if n<=1024 else None})
  return {'cases':rows,'integer_grid_checks':checks,'integer_grid_max_ratio':enc(maxratio),'definition':'Integral_.5^1 min(n,2/(e alpha max(0,1-gamma u))) du/u; zero defect uses n. This bounds the true integer-score max, and is not the actual kernel integral or a FULL budget.'}

def common_window(dps):
 with mp.workdps(dps):
  menu=[(1,'1/2','1/2','3/5','1/100','1/100'),(1,'3/4','1','11/10','1/5','1'),(8,'3/4','27/32','3/5','1/5','1/5'),(8,'1','1','2','1/100','1'),(128,'1/2','129/256','11/10','1/100','1/100'),(128,'1','1','2','1/5','1')]
  rows=[];c0=phi(mp.mpf('1.5'))
  for n,l,aa,vv,ss,sg in menu:
   L,A,v,s,sigma=map(mm,[l,aa,vv,ss,sg]);d=mp.mpf('.5')/(8*mp.sqrt(n));half=(1+d)/2
   omega=min(mp.mpf(1),C(v)/L);val,pts=splitquad(lambda x:P(s,L,x)*P(sigma,A,x-v),-half,half,[-L/2,L/2,v-A/2,v+A/2])
   normalized=L*val/omega;logprod=n*mp.log(normalized);Delta=n*(1-omega)
   rhs=n*d*s*sigma-c0*(1-s)*(1-sigma)*Delta
   assert logprod<=rhs+mp.mpf('1e-23')
   rows.append({'stage':'initial' if n==1 else 'stress' if n==8 else 'expanded','n':n,'L':l,'A':aa,'v':vv,'s':ss,'sigma':sg,'a':'1/2','b':'1','d':enc(d),'common_window_1D_endpoints':[enc(-half),enc(half)],'hard_split_points':[enc(x) for x in pts],'Omega':enc(omega),'scalar_integral':enc(val),'scalar_normalized_D':enc(normalized),'Delta':enc(Delta),'log_D_product':enc(logprod),'bound_log_rhs':enc(rhs),'log_margin':enc(rhs-logprod),'J_leg':sigma==1})
  return rows

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and k not in ['key','stage','mode','base','shift']:
    try:
     x=mp.mpf(v)
     if mp.isfinite(x):out[path+k]=x
    except ValueError:pass
   elif isinstance(v,(dict,list)):out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args()
 lo=run(30);hi=run(50)
 lo['clock_envelope']=clock(30);hi['clock_envelope']=clock(50)
 lo['common_window']=common_window(30);hi['common_window']=common_window(50)
 with mp.workdps(100):
  x=fields(lo);y=fields(hi);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);assert diff[worst]<mp.mpf('1e-24')
 out={'schema':'R264-actual-square-window-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'scalar_integrals_per_precision':15,'scalar_stages':{s:sum(r['stage']==s for r in hi['scalars']) for s in ['initial','stress','expanded']},'tensor_products_per_precision':60,'independent_phi_checks_per_precision':4,'common_window_cases_per_precision':6,'common_window_stages':{'initial':2,'stress':2,'expanded':2},'clock_envelope_cases_per_precision':16,'integer_score_grid_checks_per_precision':hi['clock_envelope']['integer_grid_checks'],'precision_fields_compared':len(diff)},'mp30':lo,'mp50':hi,'precision_max_relative_difference':md,'precision_worst_field':worst,'definitions':{'b':'1','y':'0','Omega':'min(1,b*C(abs(y-v)/b)/L)','D':'L integral_Qb(z) P_s,L(x-y) P_sigma,A(x-v) dx / Omega','delta':'12*abs(y-z)/b, summed across tensor coordinates','alpha':'phi(1.5)*(1-sigma)','enhanced_log_bound':'(1+alpha)*delta-alpha*(1-Omega), summed per coordinate'},'scope':['Six appended common-window cases use W_y=[-(1+d)/2,(1+d)/2]^n, d=.5/(8sqrt(n)), and repeated-coordinate tensor products. They test n log(L integral/Omega)<=n d s sigma-phi(1.5)(1-s)(1-sigma)Delta, including J legs with zero gap payment. These are finite tools, not general proof.','Actual one-dimensional continuous kernel integrals with explicit hard-boundary splitting, ordinary 30/50-digit mpmath arithmetic, not outward intervals or a proof of the claimed bound.','Tensor results factorize these actual scalar integrals; repeated and one-shifted profiles use the same physical receiver center in each coordinate. n=1,2,8,32,128 are finite tools, not original FULL qualifications.','A=27/32 is clipped gamma*L with gamma=9/8, L=3/4. Other A legs are L or b=1. sigma=1 supplies fixed J examples. No source-budget, history, high/good, root or dimension-order conclusions.','The added clock-envelope scalar integration is split at both threshold transitions and independently compared with closed primitives; integer max checks use fixed u grids only for n<=1024. No general lemma is inferred from passing numbers. No soft-grid/Abel test was added. Mixtures with receiver-dependent posterior coefficients cannot be treated as fixed source mixtures.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'min_scalar_enhanced_margin':min(float(r['enhanced_log_margin']) for r in hi['scalars'])}))
if __name__=='__main__':main()
