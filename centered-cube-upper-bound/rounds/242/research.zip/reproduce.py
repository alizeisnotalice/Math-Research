#!/usr/bin/env python3
"""R242 full relocated numerical replay and manifest check."""
import argparse,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    m=json.loads((ROOT/'manifest.json').read_text())
    for name,h in m.items():assert digest(ROOT/name)==h,name
    return len(m)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--output-dir',type=Path);a=ap.parse_args();count=verify()
    if a.verify_only:print('verified',count,'manifest hashes');return
    if a.output_dir is None:ap.error('--output-dir required')
    out=a.output_dir.resolve()
    if out==ROOT or ROOT in out.parents:ap.error('output must be outside package')
    out.mkdir(parents=True,exist_ok=False)
    for name in ['numeric_checks.py','task_contract.md']:shutil.copyfile(ROOT/name,out/name)
    start=time.monotonic()
    cmd=[sys.executable,str(out/'numeric_checks.py'),'--output',str(out/'numeric_checks.json'),'--contract',str(out/'task_contract.md')]
    r=subprocess.run(cmd,env=os.environ.copy(),check=True,capture_output=True,text=True)
    assert (out/'numeric_checks.json').read_bytes()==(ROOT/'numeric_checks.json').read_bytes(),'entire JSON differs'
    j=json.loads((out/'numeric_checks.json').read_text())
    runs=[{'script':'numeric_checks.py','counts':j['counts'],'entire_json_byte_identical':True,'sha256':digest(out/'numeric_checks.json'),'stdout':r.stdout.strip(),'elapsed_seconds':time.monotonic()-start}]
    code=(ROOT/'fractional_budget.md').read_text().split('```python\n',1)[1].split('```',1)[0]
    p=out/'fractional_checks.py';p.write_text(code)
    r=subprocess.run([sys.executable,str(p)],env=os.environ.copy(),check=True,capture_output=True,text=True)
    assert 'checks 136' in r.stdout and 'PASS' in r.stdout
    runs.append({'script':'fractional_budget.md embedded','checks':136,'stdout':r.stdout.strip()})
    assert verify()==count
    receipt={'complete_replay':True,'manifest_hashes_before_and_after':count,'runs':runs,'python':sys.executable,'scope':'Finite legal physical kernels, common-source Holder arrays and scale sums. Ordinary high precision, not interval/FULL certification or a general root bound.'}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
