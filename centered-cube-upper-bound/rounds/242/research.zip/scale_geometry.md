# R242：保比例带费用、去除窗口 plateau 的来源几何

本稿证明原物理节点上的比例带可以支付 source–hard 窗口的 plateau 损失。新增缺口依完整截断位移和 S，而不是 R241 中扣除全局 (b−a)/2 后的位移。全部原 j/M/soft/clock 费用均求和；单一来源门因而扩大，辅助 posterior 和来源测度不变。一般剩余近来源仍未闭合。

## SG1. 原范围与节点资格

沿 R238–241 的原有限截断及外资料 (ω,V)，0<a≤b≤2a，q,K>0，ν≤β≤f。原 source-pair 集 D(z)、receiver Ω、actual s(x)、history、capture、large-n 和 FIRST 资格不变。β,ν,a,b,q,D 在 j 间共同。原 hard z 不是 posterior 槽；两个辅助槽始终使用完整原 ν 定义的 Π_t、e_t、Z_t。

记 γ=1+1/n，h=nlogγ∈[log2,1]，c=γ^−j，M0=a/c²。R229 AG2 的原节点从 M0 按 γ 倍增，末点截在 b，M0>b 时没有节点。两朝向分别是

\[
 (L^*,R^*)=(M,c^2M)\quad\hbox{或}\quad(c^2M,M),\qquad M\in\mathcal M_j.
\]

截在 b 的末点同样具有这一精确比例；不能将实际纤维上的 L,R 直接当作精确比例。AG2–3 已证每个实际尺度被对应向上节点覆盖、所有节点仍在 [a,b]，且三腿

\[
 (A_1^*,\sigma_1)=(L^*,s),\quad
 (A_2^*,\sigma_2)=(\min(b,\gamma L^*),s),\quad
 (A_3^*,\sigma_3)=(b,1)
\]

保原物理覆盖总价 e⁴。以下新 source–hard 窗口只涉及 L*,R*；第三测试腿不另取节点，也未变成自由独立尺度。原半阶 QG 的 capture 支持依旧保留。

令 B=e⌈π√n⌉，ε0=(1/2)e^−3。定义原 m_D(z)=β(D(z))、ρ_D=m_D/(qa^n)。F_z⊂D(z) 是固定 hard z 后、x/y/v/u/j/M/t 之前冻结的可测子集。仅限制原正母式的 β 来源积分，不裁剪原 posterior。

可用任一已证明的共同 receiver 上界 O_R*(z)=∫Ωh_R*(x−z)dx≤Δ(z)≤1，包括 Δ=1。Δ=0 行先置零，余下 Δ>0。

## SG2. 真实比例带消除全局 plateau

记 d_i=y_i−z_i、r_i=min(|d_i|/b,1)，定义

\[
 S_z(y)=\sum_i r_i,\qquad T_z(y)=\min\{S_z(y),\varepsilon_0n\}.
\]

原节点 hard-hard 单坐标归一化响应的精确 deficit 为

\[
 g_i^j=\min\left\{1,
 \frac{(|d_i|/M-(1-c^2)/2)_+}{c^2}\right\}.
\]

因为 M≤b、0<c²≤1、r_i≤1，直接分 r_i≤(1−c²)/2 与其补集，得

\[
 g_i^j\ge r_i-(1-c^2)/2.
\]

再由 1−c²=1−exp(−2jh/n)≤2jh/n，

\[
 \sum_i g_i^j\ge S_z(y)-jh,
 \qquad\min\{\sum_i g_i^j,\varepsilon_0n\}\ge T_z(y)-jh. \tag{SG2}
\]

右侧可以为负，这不影响上界方向。这里保留原 j，而不按所有尺度的最坏 (b−a)/2 一次性丢掉位移信息。

## SG3. 固定共同 soft 与实际自适应 soft

R241 JG2 已证：对所有 L,R∈[a,b]、所有位移，soft-hard 归一化单坐标响应≤1−ε0；hard-hard 响应在当前节点恰为 1−g_i^j。因此对每个固定共同 s∈[0,1]，

\[
 \begin{aligned}
 M^n\int h_{R^*}(x-z)P_{s,L^*}(x-y)dx
 &\le\prod_i[1-(1-s)g_i^j-s\varepsilon_0]\
 &\le\exp[-(1-s)\sum_i g_i^j-s\varepsilon_0n]\
 &\le e^{jh}e^{-T_z(y)}.
 \end{aligned} \tag{SG3.1}
\]

所有坐标保持同一个 s；两朝向的 deficit 及 soft 缺口均相同。对于实际 s(x)，先使用已经认证的公共菜单点态支配 P_s,L*≤e∑_rP_r,L*，再积分。于是

\[
 I_0(y,z):=\int_\Omega h_{R^*}(x-z)P_{s(x),L^*}(x-y)dx
 \le BM^{-n}e^{jh}e^{-T_z(y)}. \tag{SG3.2}
\]

不是把固定参数列直接用于 θ(x)，也没有给菜单节点授 FIRST。FIRST 始终在实际 s(x) 和原 Ω 上使用：

\[
 \int_{F_z} I_0(y,z)\beta(dy)\le q O_{R^*}(z). \tag{SG3.3}
\]

## SG4. 单独 T 门的原完整交通回代

记 m_T(F,z)=∫_F exp(−T_z(y)/2)β(dy)、ρ_T=m_T/(qa^n)。对 0<θ≤1/4，按 R240/241 的同一来源 Hölder，

\[
 \int_F I_0^{1-2\theta}d\beta
 \le(BM^{-n}e^{jh})^{2\theta}
 (qO_{R^*})^{1-4\theta}m_T^{4\theta}. \tag{SG4.1}
\]

原半阶列插值再乘 (BM^−n)^(2θ)，原同一 Π_t⊗Π_t 的 Gini 界给 ∫δ_t dΠ_t²≤n/4。记 ξ=nlog(M/M0)、Z=(ξ−U)_+，原 clock 长度≤Z/n、原列外分母为 q。得到

\[
 \boxed{\mathcal T^{F,T}_{jM,z}\le\frac Z4
 (B\rho_T)^{4\theta}\Delta^{1-4\theta}
 e^{-6\theta jh}e^{-4\theta\xi}.} \tag{SG4.2}
\]

比例带费用 e^(2θjh) 与原 (a/M)^(4nθ)=e^−8θjh e^−4θξ 相乘后仍留下 e^−6θjh。这是实际付款，不是把新增 j 损失隐藏在菜单常数中。

R241 的 ξ 求和（含独立 capped endpoint）给 ∑Mξe^−4θξ≤1/(8θ²)。又 h≥2/3、θ≤1/4 时

\[
 \sum_{j\ge0}e^{-6\theta jh}
 \le1+\frac1{6\theta h}\le\frac1{2\theta}.
\]

故含原 good 因子 (K/3)^θ 的每腿/朝向全和≤

\[
 \frac1{64\theta^3}\Delta(K/3)^\theta
 (B\rho_T)^{4\theta}\Delta^{-4\theta}.
\]

令 H_T=1+log_+ρ_T+log B+log_+K+log(1/Δ)，θ_z=1/(4H_T)。指数乘子≤e，恢复原 2Λe⁴、三腿、两朝向，

\[
 \boxed{P_{\rm farclock}^{F}(U)\le12\Lambda e^5
 \mathbb E\sum_V\int_V\Delta H_T(F,z)^3\nu_V(dz).} \tag{SG4.3}
\]

θ 在原 hard z 的来源数据上冻结，早于节点、receiver、辅助槽和 clock。全范围 U≥0；U=0 仅指当前原 far-clock 分支。

## SG5. 与旧 E、Gsharp 合并时保留更精确的 M^−n

R240 的距离量 E_z(y)=∑(|d_i|/b−1)_+；R241 的精确共同 soft 缺口记为 A_z(y)=Gsharp_z(y)。令

\[
 J_z(y)=\max\{E_z(y),A_z(y),T_z(y)\}.
\]

原 E 的逐点证明实际上保有源核尺度：

\[
 P_{s(x),L^*}(x-y)\le(L^*)^{-n}e^{-E_z(y)}
 \quad(x\in Q_{R^*}(z)).
\]

由于 L* 为 M 或 c²M，所以

\[
 I_0\le M^{-n}e^{2jh}e^{-E_z(y)}O_{R^*}(z).
\]

R241 则给 I0≤BM^−n e^−A；SG3.2 给 I0≤BM^−n e^jh e^−T。三式共同蕴含

\[
 \boxed{I_0(y,z)\le BM^{-n}e^{2jh}e^{-J_z(y)}.} \tag{SG5.1}
\]

这是同一 I0 的三个上界取最小，未把三个来源分支分别相加。关键是保持 M^−n，不能先把它全部上放为 a^−n 再丢掉相应 j 衰减。

供对照，题设较粗但合法的包络 I0≤Ba^−n e^jh e^−J 也成立：E 包络用 L*≥a，A 包络用 M≥a，T 包络保 e^jh。该式给可和的 e^−2θjh，但本文以下使用更强 SG5.1。

## SG6. 合并门全尺度付款：常数 21Λe⁵

记

\[
 m_J(F,z)=\int_{F_z}e^{-J_z(y)/2}\beta(dy),\quad
 \rho_J=m_J/(qa^n).
\]

在 SG4.1 中用 SG5.1 替换，得到同一原交通的节点界

\[
 \boxed{\mathcal T^{F,J}_{jM,z}\le\frac Z4
 (B\rho_J)^{4\theta}\Delta^{1-4\theta}
 e^{-4\theta jh}e^{-4\theta\xi}.} \tag{SG6.1}
\]

量纲与原同底测度列完全相同；新增 e^(4θjh) 恰将 e^−8θjh 改成 e^−4θjh。对于 θ≤1/4，安全界

\[
 \sum_j e^{-4\theta jh}\le1+\frac1{4\theta h}
 \le\frac7{8\theta}
\]

与 ∑M ξe^−4θξ≤1/(8θ²) 给全和 7/(256θ³)。令

\[
 H_J(F,z)=1+\log_+\rho_J+\log B+\log_+K+\log(1/\Delta),
 \quad\theta_z=1/(4H_J),
\]

恢复同样的原外费，得到

\[
 \boxed{P_{\rm farclock}^{F}(U)\le21\Lambda e^5
 \mathbb E\sum_V\int_V\Delta H_J(F,z)^3\nu_V(dz).} \tag{SG6.2}
\]

m_J=0 或 O=0 的行先置零；不将零质量带入对数。可与原 R240 更尖的 Δ 对数系数之界取较小者，不能宣称本式同时继承其 1/2 系数。

若只用 SG5 所述 a^−n 包络，ξ和为1/(2θ²)、j和≤1/θ，全和1/(8θ³)，同一优化给96Λe⁵。这是题设损失直接可付的中间估计；SG6.2 保 M^−n 后将其严格改善，无额外几何假设。

## SG7. 明确扩大且只收费一次的来源门

设 t(z)=2log_+ρ_D(z)，定义一次原来源分割

\[
 F_z^{\rm new}=\{y\in D(z):J_z(y)\ge t(z)\},\qquad
 N_z^{\rm new}=D(z)\setminus F_z^{\rm new}.
\]

各距离量是连续/可测的显式输入函数，A 的可测性已由 R241 的紧参数一维 supremum 证明。m_D 可测，故两个门可测，且都早于 x/t/辅助槽/节点冻结。

由定义 ρ_J(Fnew,z)≤e^−t/2ρ_D≤1，取 Δ=1 得

\[
 \boxed{P_{\rm farclock}^{F^{\rm new}}(U)\le
 21\Lambda e^5[1+\log_+K+\log(e\lceil\pi\sqrt n\rceil)]^3W_\nu.} \tag{SG7}
\]

将括号提出期望要求 K 在 outer data 间共同；否则括号保在原 E∑∫ν 内。若按已认证原 K 自由参数族预固定绝对 K，则这支为 O(log³(n+1))Wν。不能据此宣布其余原分支同价。

这个门包含 R241 的 max(E,A) 门，并在几何参数层面可扩大。新增部分是 max(E,A)<t≤T，特别不再忽略所有 |d_i|≤(b−a)/2 的位移。本文没有证明实际新增正交通占正比例或非空的 FULL 实例。

没有分别给 E、A、T 三个门各领一份 Wν；SG7 只限制一次原 β 积分并使用一次共同 FIRST/Hölder。原 ν 与 source-pair 历史不变，hard z 不作 posterior 化。

## SG8. 剩余低 T 域的精确空间收缩及缺口

对所有位移恒有

\[
 S_z(y)+E_z(y)=\|y-z\|_1/b. \tag{SG8.1}
\]

更一般地，对任意预冻结阈值 t>0，集合 J<t 上，若 t≤ε0n，则 T<t 迫 S<t，故

\[
 \boxed{\|y-z\|_1<2bt.} \tag{SG8.2}
\]

对于同轮 general-p 门阈值 t_p=log_+ρ_D/p（0<p<1），这给 l1 距离严格小于 2b log_+ρ_D/p；本文 SG7 的 p=1/2 情形恰为4b log_+ρ_D。本句仅是对阈值的几何代入，general-p 的 Holder 与费用由同轮相应证明承担，不在本文重复或免费授权。

t=0 时 J≥t，来源全在该门；t>ε0n 时 T 饱和，不能推出 SG8.2。这一收缩严格保留两参数分支，不能把它用于高质量饱和区。它将部分剩余的原17na距离域缩小为logρ尺度，但不是接收占用预算。

最早尚未证明的步骤是：对 SG8.2 的实际共同来源，或 t>ε0n 的饱和行，给出与原 receiver 排斥同时有效的全局 ν 积分控制。原 hardband 不能仅凭 l1 半径2b logρ/p就推出足够小的 Δ；该半径通常不在 R239 的小平均位移证书范围内。因此本稿没有闭合一般根阶目标，也不将这条定位或新的 m_J 名称当成付款。已付内容是 SG7 的明确扩张子交通及完整常数。

## SG9. 本机数学检查与有限交付

实际使用本机 Python Fraction 完成189项精确有理数检查：n∈{8,32,512}，jmax=floor(log2/(2log(1+1/n)))，j∈{0,floor(jmax/2),jmax}，a=1,b=2，M∈{M0,(M0+b)/2,b}，|d|/b∈{0,.01,.1,.5,1,2,4}。所有 g_i^j≥min(|d|/b,1)−(1−c²)/2 均精确通过。

另以本机 mpmath40 位对上述3个 n、θ∈{.01,.1,.25}共9组计算正规ξ和加最大cap，检查≤1/(8θ²)，并核 pure j和≤1/(2θ)、merged j和≤7/(8θ)。全通过，ξ和与所用上界的最大比为0.6769987623247790806889919。

这是原节点代数与几何级数的工具检查，不是FULL/history或渐近阶的数值证据。严格证明由 SG2–6 的逐点式、原合法列接口与显式求和给出。本文仅修改 scale_geometry.md，不变更来源、posterior 或他人文件，不提交仓库。
