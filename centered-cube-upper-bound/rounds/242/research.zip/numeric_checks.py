#!/usr/bin/env python3
"""Legal physical-scale kernels and common-beta general Holder tools."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp
ROOT=Path(__file__).resolve().parent

def mf(v):return mp.mpf(v.numerator)/v.denominator if isinstance(v,F) else mp.mpf(v)
def enc(v):return mp.nstr(v,32)
def phi(x):
 x=abs(x);h=mp.mpf('.5')
 def E3(t):return h if not t else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
 return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def psoft(x,s):return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi(x)
def node(c):
 n=c['n'];j=c['j'];gamma=F(n+1,n);c2=gamma**(-2*j);a=F(1);b=F(c['b']);M=a/c2 if c['endpoint']=='lower' else b;small=c2*M;assert a<=small<=M<=b<=2*a and M>=a/c2
 L,R=(M,small) if c['orientation']=='largeL' else (small,M)
 d=(M-small)/4 if c['displacement']=='plateau' else b*F(c['displacement']);g=min(F(1),max(F(0),d-(M-small)/2)/small);sone=min(d/b,F(1));loss=(1-c2)/2;assert g>=sone-loss
 return gamma,c2,L,R,M,d,g,sone,loss

def physical(c,dps):
 gamma,c2,LF,RF,MF,dF,gF,sF,lossF=node(c)
 with mp.workdps(dps):
  n=c['n'];j=c['j'];L,R,M,d=map(mf,(LF,RF,MF,dF));loggamma=mp.log(mf(gamma));h=n*loggamma;eps=mp.exp(-3)/2;S=n*mf(sF);T=min(S,eps*n);jh=j*h;assert n*mf(lossF)<=jh+mp.mpf(10)**(-dps+5) and n*mf(gF)>=T-jh-mp.mpf(10)**(-dps+5)
  cuts=sorted(set([-R/2,R/2]+[v for v in (mp.mpf(0),d-L/2,d+L/2) if -R/2<v<R/2]));I=mp.mpf(0);adaptive=c['s']=='adaptive'
  if adaptive:
   for u,v in zip(cuts,cuts[1:]):I+=mp.quad(lambda x:psoft((x-d)/L,mp.mpf('.2') if x<0 else mp.mpf('.8'))/(L*R),[u,v])
  else:
   s=mf(c['s']);overlap=max(mp.mpf(0),min(R/2,d+L/2)-max(-R/2,d-L/2));I=(1-s)*overlap/(L*R)
   if s:
    for u,v in zip(cuts,cuts[1:]):I+=s*mp.quad(lambda x:phi((x-d)/L)/(L*R),[u,v])
  norm=M*I;Tone=min(mf(sF),eps);B1=mp.e*int(mp.ceil(mp.pi));scalarbound=(B1 if adaptive else 1)*mp.exp(j*loggamma-Tone);assert norm<=scalarbound*(1+mp.mpf(10)**(-dps+5));lognorm=n*mp.log(norm) if norm else mp.ninf;logbound=jh-T
  if not adaptive:assert lognorm<=logbound+mp.mpf(10)**(-dps+3)
  out=dict(a='1',b=c['b'],gamma_exact=str(gamma),c2_exact=str(c2),L_exact=str(LF),R_exact=str(RF),M_exact=str(MF),d_exact=str(dF),g_exact=str(gF),S_percoordinate_exact=str(sF),loss_percoordinate_exact=str(lossF),n=n,j=j,last_legal_j_for_band=bool(gamma**(2*(j+1))>F(c['b'])),scalar_I=enc(I),scalar_M_I=enc(norm),scalar_bound=enc(scalarbound),S=enc(S),T=enc(T),jh=enc(jh),old_hard_deficit_zero=gF==0,positive_S=sF>0,drop_j_shift_would_fail=bool(not adaptive and lognorm>-T),adaptive_scalar_only=adaptive)
  if not adaptive:out.update(log_true_homogeneous_product=enc(lognorm),log_product_bound=enc(logbound),log_ratio=enc(lognorm-logbound))
  else:out.update(B1=enc(B1),scope='Scalar component menu only; do not raise independently adaptive component integral to n or claim true common-soft n-dimensional menu.')
  return out

def getp(c):return max(mp.mpf('.5'),1-1/mp.log(c['n']+2)) if c['p']=='pn' else mf(c['p'])
def power0(x,e):return mp.mpf(1) if e==0 else x**e

def holder(c,dps):
 with mp.workdps(dps):
  p=getp(c);r=mf(c['r']);eta=p*r;theta=(r-eta)/2;O=mf(c['O']);C=mp.mpf(2);weights=list(map(mf,['1','.5','2','.125']));Js=list(map(mf,['0','1','8','40']));damps=list(map(mf,['.8','.3','.9','.1']));base=[C*mp.exp(-J)*d for J,d in zip(Js,damps)];q=sum(w*i for w,i in zip(weights,base))+mp.mpf('.01');Is=[O*i if not c.get('zero_I') else mp.mpf(0) for i in base];row=sum(w*i for w,i in zip(weights,Is));weighted=sum(w*mp.exp(-p*J) for w,J in zip(weights,Js));lhs=sum(w*i**(1-2*theta) for w,i in zip(weights,Is));formal=power0(C,eta)*power0(q*O,1-r)*weighted**r;rhs=mp.mpf(0) if O==0 else formal
  rho_D=sum(weights)/q;gate=max(mp.mpf(0),mp.log(rho_D))/p;far_weight=sum(w*mp.exp(-p*J) for w,J in zip(weights,Js) if J>=gate)/q;assert far_weight<=1+mp.mpf(10)**(-dps+5)
  assert 0<p<1 and r<=1 and row<=q*O and all(i<=C*mp.exp(-J) for i,J in zip(Is,Js)) and lhs<=rhs*(1+mp.mpf(10)**(-dps+5))
  return {k:enc(v) for k,v in dict(p=p,r=r,eta=eta,theta=theta,C=C,q=q,O=O,row=row,rowcap=q*O,m_p=weighted,lhs=lhs,formal_Holder_rhs=formal,traffic_bound_after_zero_O=rhs,ratio=lhs/rhs if rhs else mp.mpf(0),rho_D=rho_D,far_gate_J=gate,far_weighted_rho=far_weight,p_penalty=1/(1-p)).items()}

def series(c,dps):
 with mp.workdps(dps):
  n=c['n'];p=getp(c);r=mf(c['r']);theta=(1-p)*r/2;h=n*mp.log1p(mp.mpf(1)/n);qM=mp.exp(-r*h);qj=mp.exp(-4*theta*h);regular=h*qM/(1-qM)**2;cap=1/(mp.e*r);Msum=regular+cap;jsum=1/(1-qj);total=Msum*jsum/4;bound=7/(16*theta*r*r);assert Msum<=2/r**2 and jsum<=7/(8*theta) and total<=bound
  fj=sum(qj**j for j in range(5));fk=sum(k*h*qM**k for k in range(9));finite=fj*(fk+cap)/4;tailj=(jsum-fj)*Msum/4;tailk=fj*(regular-fk)/4;assert tailj>=0 and tailk>=0 and abs(total-finite-tailj-tailk)<mp.mpf(10)**(-dps+10)
  return {k:enc(v) for k,v in dict(p=p,r=r,theta=theta,h=h,regular_M_infinite=regular,independent_extra_cap_x=1/r,extra_cap_value=cap,M_sum=Msum,M_bound=2/r**2,j_infinite=jsum,j_bound=7/(8*theta),normalized_total=total,total_bound=bound,total_over_bound=total/bound,finite_j0to4_k0to8=finite,positive_tail_j=tailj,positive_tail_k=tailk,final_analytic_price_coefficient=21*(mp.mpf(128)/119)*mp.e**5/(2*(1-p))).items()}

def main(output,contract):
 menu=[]
 for s,d in [('0','0'),('.2','3/4'),('1','2')]:menu.append(dict(stage='initial',n=3,j=0,b='1',endpoint='cap',orientation='largeL',s=s,displacement=d))
 for o in ('largeL','largeR'):
  for s in ('0','.2','1'):menu.append(dict(stage='positive_j_plateau',n=3,j=1,b='2',endpoint='lower',orientation=o,s=s,displacement='plateau'))
  for s,d in [('0','plateau'),('1','1')]:menu.append(dict(stage='cap_pressure',n=16,j=5,b='2',endpoint='cap',orientation=o,s=s,displacement=d))
  for s,d in [('.2','3/4'),('1','2')]:menu.append(dict(stage='expanded',n=512,j=1,b='2',endpoint='cap',orientation=o,s=s,displacement=d))
  menu.append(dict(stage='expanded_large_n',n=1000000,j=1,b='2',endpoint='cap',orientation=o,s='.2',displacement='3/4'))
  menu.append(dict(stage='adaptive_component',n=3,j=1,b='2',endpoint='lower',orientation=o,s='adaptive',displacement='plateau'))
 menu.append(dict(stage='expanded_max_legal_j',n=512,j=177,b='2',endpoint='cap',orientation='largeL',s='0',displacement='plateau'))
 rows=[]
 for c in menu:
  a=physical(c,30);b=physical(c,50)
  with mp.workdps(70):diff=abs(mf(a['scalar_I'])-mf(b['scalar_I']));assert diff<mp.mpf('1e-25');diff=enc(diff)
  rows.append(dict(configuration=c,mp30=a,mp50=b,scalar_precision_difference=diff))
 hm=[dict(n=n,p=p,r=r,O='.01' if n==1000 else '1') for n,ps in [(2,('.5','.9')),(1000,('.5','.9','pn')),(1000000,('.5','.9','pn'))] for p in ps for r in ('.5','1')];hm.extend([dict(n=2,p='.9',r='1',O='0'),dict(n=2,p='.5',r='.5',O='0'),dict(n=2,p='.5',r='1',O='1',zero_I=True)]);holders=[dict(configuration=c,mp40=holder(c,40),mp70=holder(c,70)) for c in hm]
 sm=[dict(n=n,p=p,r=r) for n in (2,1000,1000000) for p,r in [('.5','1'),('pn','.5')]];srows=[dict(configuration=c,mp40=series(c,40),mp70=series(c,70)) for c in sm]
 payload=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),contract_sha256=hashlib.sha256(Path(contract).read_bytes()).hexdigest(),scope='Finite legal-scale actual-kernel buildingblocks/fixed-common-soft products and common-beta algebra; not FULL or general root closure.',physical_rows=rows,general_Holder_rows=holders,geometric_series_rows=srows,series_scope="Normalized perleg perorientation; excludes delta(K/3)^theta(B rho/delta)^r; regular infinite nodes plus one independent worst cap, may deliberately double-count cap; final price coefficient is analytic, not a new geometric source check.",Holder_fixed_arrays=dict(beta_weights=['1','1/2','2','1/8'],J=['0','1','8','40'],damping=['.8','.3','.9','.1'],C='2 independentO',q='sum beta C exp(-J)damping+.01 independentO',I='O C exp(-J)damping, orzero',zero_O_guard='FIRST row forces I=0; traffic bound placed zero before exponent optimization. Formal r1 Holder RHS may positive and is separately retained.'),precision_scope='Real scalar mp30/50 ordinary split quadrature, no interval certificate. Fixed products use same raw mp scalar inside each precision context and one common L,R,s for all coordinates, logarithms prevent underflow. Adaptive rows are scalar-component checks only.',counts=dict(physical_cases=len(rows),general_Holder_cases=len(holders),geometric_series_cases=len(srows)))
 Path(output).write_text(json.dumps(payload,indent=2,sort_keys=True)+'\n');print(payload['counts'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',default=str(ROOT/'numeric_checks.json'));p.add_argument('--contract',default=str(ROOT/'task_contract.md'));a=p.parse_args();main(a.output,a.contract)
