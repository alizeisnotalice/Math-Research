# R242: source-weight exponent approaching one, with its exact fee

Only this file is owned by this task. Read inputs are the R242 contract
and the R241 frozen `proof.tex.txt` / `joint_geometry.md` at
`/Users/zhengzhihao/Desktop/T/output/centered_cube_round241_20261017_final_checkpoint/`.
The general root weak bound remains unproved. This note pays a larger
single original source gate; its complement and all other mother-ledger
branches are retained. The spatial-scale author's proof is separate.

## FB1. Original objects and parameter domain

Keep the original finite truncation, outer sources nu<=beta<=f dx,
actual common s(x), q>0, 0<a<=b<=2a, receiver Omega, actual FIRST,
capture, FULL and all original history/large-n qualifications. The
original source-pair set D_V(z) and all original sources are unchanged.
In particular posterior Pi_t(y) is always built from the full nu,
not from the soft source subset F_z used below.

Fix original hard z before receiver x, soft y, auxiliary v/u, j,M,t.
Let F_z subset D_V(z) be a measurable source subset frozen at that
level. The parameters in this note are also frozen there, never chosen
from a receiver or posterior sample. They may vary with z when the
displayed fee stays inside the final original nu(dz) integral.

Write gamma=1+1/n, h=n log gamma, c=gamma^-j,
M0=a/c^2, X=n log(M/M0), and Z=(X-U)_+ with U>=0. Legal fixed physical
nodes have (L*,R*)=(M,c^2M) or the reverse, and the same three actual
target legs as R241. All their physical scales are in [a,b]. There is
one regular X-grid with spacing h, plus at most one nonduplicated
capped endpoint for each j. Set B=e ceil(pi sqrt n).

The following is the full interpolation parameter range:

    theta>0, eta>=0, r=2theta+eta<=1,
    p=eta/r in [0,1),
    theta=(1-p)r/2, eta=pr.                            (FB1)

Thus 0<theta<=1/2 as required by the already proved fractional-good
and half-column interpolation. Conversely every 0<r<=1 and 0<=p<1
gives an allowed triple. The endpoint r=1 is allowed; p=1 is not.

## FB2. Verification that the combined kernel envelope is sufficient

For d=y-z let

    E(d)=sum_i (|d_i|/b-1)_+,
    t_i(d)=min(|d_i|/b,1),
    T(d)=min(sum_i t_i(d), epsilon_0 n),
    epsilon_0=(1/2)e^-3,
    J(d)=max{E(d),G_sharp(d),T(d)}.                    (FB2)

Here G_sharp is exactly the common-soft extremal window exponent
proved in R241, not a coordinatewise soft optimization. The source
score J is independent of x,j,M,t and the auxiliary source variables.

For completeness, the new T envelope needs only a short scale-gap
check. If Delta=|L*-R*|, m=min(L*,R*), the normalized hard overlap's
deficit is

    a_i=min(1,(|d_i|-Delta/2)_+/m)
       >=t_i-Delta/(2b).

This follows from m<=b and the 1-Lipschitz clipped ramp. The normalized
soft overlap is <=1-epsilon_0 by R241's two-orientation kernel lemma.
For one fixed common s the product of normalized window factors is
therefore at most

    exp[n Delta/(2b)]
      exp[-(1-s)sum_i t_i-s epsilon_0 n]
       <=exp[n Delta/(2b)-T].

At a physical node Delta=M(1-c^2), M<=b, so
n Delta/(2b)<=n(1-c^2)/2<=n log(1/c)=jh. Applying the already paid
common-soft menu before integration thus gives the actual-soft bound
I0<=B M^-n exp(jh-T). It uses one common menu, not separate coordinate
choices. It has no freely inserted receiver occupation factor.

The old pointwise distance bound also gives
I0<=L*^-n e^-E O_R*(z)<=M^-n exp(2jh-E), while R241 gives
I0<=B M^-n e^-G_sharp. Here (M/L*)^n is at most c^-2n=exp(2jh).
Taking the minimum of these three valid whole-kernel bounds gives

    I0(y,z):=integral_Omega h_R*(x-z)P_{s(x),L*}(x-y)dx
       <=B M^-n exp(2jh) exp[-J(y-z)].                 (FB3)

The pointwise distance estimate and the T estimate are valid up to
receiver-null boundary hyperplanes, which does not affect I0.
No independent menu or recovery coefficient is added when taking a
minimum. All original QG capture requirements remain on the half-column;
they are not discarded because I0 itself was positively enlarged.

## FB3. Same-source FIRST with arbitrary weight exponent p

Actual-soft FIRST and the fixed hard column, on the original receiver
domain, give

    integral_{F_z} I0(y,z)beta(dy)<=q O_R*(z),
    O_R*(z)=integral_Omega h_R*(x-z)dx<=1.

Let delta(z) in [0,1] be any already proved common bound O_R*(z)<=delta(z)
for all legal physical nodes. Delta=1 is always allowed. Define

    m_p(z)=integral_{F_z} exp[-pJ(y-z)]beta(dy),
    rho_p(z)=m_p(z)/(q a^n).                            (FB4)

For FB1, Holder on this same beta measure gives

    integral_F I0^{1-2theta}beta
       <=[B M^-n exp(2jh)]^eta
             [q O_R*(z)]^{1-r} m_p(z)^r.              (FB5)

Indeed split I0^{1-2theta}=I0^{1-r}I0^eta. Use FB3 on the second
factor, then Holder with exponents 1/(1-r),1/r; the second source
integrand is exp[-(eta/r)J]=exp(-pJ). At r=1 this is the direct
pointwise-envelope integral, so there is no singular Holder step.
At eta=0, p=0 and m_0=beta(F_z), giving the original unweighted bound.
It is not legitimate to preserve m_p^r while silently replacing its
exponent by the old 2theta or 4theta.

If m_p=0, then beta(F_z)=0 because J is finite on the original finite
source set, and the source row vanishes. If delta=0, all relevant hard
receiver columns vanish. These are actual zero contributions handled
before normalizing or taking logarithms; no 0^0 convention creates
an extra contribution at r=1.

## FB4. Full-posterior order and the exact node price

The R238/241 actual half-menu/capture bound gives, for every allowed
theta and each original target leg,

    J_theta,act(y,z,v)
       <=(B M^-n)^{2theta} I0(y,z)^{1-2theta}.          (FB6)

This right side is independent of the auxiliary v. Apply it first,
then use the two original Pi_t(y) at this same y. They contain their
complete e_t(y)^-2 normalizer, original Z_t, and full nu; they are not
changed by F_z. The normalized iid-score Gini bound is

    integral integral (k_t(v)-k_t(u))_+ dPi_t(v)dPi_t(u)<=n/4.

Only after that step integrate beta and use FB5. It would be invalid
to integrate beta first and subsequently treat its y-dependent Pi_t
as a common posterior. Original invalid/zero-degree rows are masked
to zero; on active rows Pi_t has total mass one. No derivative of
e_t, heavy-floor extension, source envelope or signed credit is used.

The original log-clock interval is at most Z/n, so before restoring
the original 2Lambda e^4(K/3)^theta, the node traffic satisfies

    T^F_{jM,z} <= (Z/4) B^r rho_p(z)^r delta(z)^{1-r}
                        exp(-4theta jh) exp(-rX).     (FB7)

Check all powers directly: FB5 and FB6 supply M^-nr exp(2eta jh),
q^-r m_p^r and O^{1-r}. Since M=a c^-2 exp(X/n), the spatial factor
(a/M)^{nr} is exp(-2r jh-rX). Its product with exp(2eta jh) is exactly
exp(-4theta jh-rX). This is the cost of the scale-gap envelope; it
has not vanished in a renamed constant. The source mass has its
original units and the node price is dimensionless.

## FB5. Two separate finite sums, including the cap node

For 0<r<=1, h in [log2,1], the regular grid and the independently
bounded possible capped endpoint give

    sum_M X exp(-rX)
       <=h exp(-rh)/(1-exp(-rh))^2+1/(er)
       <=1/(r^2 h)+1/(er)<=2/r^2.                    (FB8)

The regular identity is h/[4sinh^2(rh/2)]. Use 2sinh(rh/2)>=rh,
1/log2<=3/2 and 1/e<1/2 for the last step. An already duplicated cap
may conservatively be counted once more; this is an upper bound,
not a missing multiplicity. Legal finite node families are positive
subsets of this enlarged sum. Independently,

    sum_{j>=0} exp(-4theta jh)
       <=1+1/(4theta h)<=7/(8theta),                  (FB9)

using theta<=1/2 and h>=2/3. Thus the precise combined fee is

    sum_{j,M}(K/3)^theta T^F_{jM,z}
       <=[7/(16theta r^2)] delta(z)
             (K/3)^theta [B rho_p(z)/delta(z)]^r.      (FB10)

The j price is 1/theta; the physical-node price is 1/r^2. It is not
legitimate to replace both by 1/r^3 uniformly as p approaches one.
The candidate p=1 would set theta=0 and lose this summable j decay;
no endpoint estimate at p=1 is asserted.

## FB6. Optimized exponent, all external coefficients, and zero anchors

For positive rho_p,delta and any fixed 0<=p<1 put

    H_p(z)=1+log_+rho_p(z)+log B+log_+K+log(1/delta(z)),
    r_z=1/H_p(z), theta_z=(1-p)/(2H_p(z)), eta_z=p/H_p(z).

These satisfy the full FB1 domain and are chosen before all receiver,
source-anchor y, auxiliary, node and clock variables. Moreover

    (K/3)^theta_z [B rho_p/delta]^r_z <=e,

because its logarithm is at most
r_z[log B+log_+rho_p+log(1/delta)+(1-p)log_+K/2]<1.
Substituting into FB10 proves, per original target leg and orientation,

    sum_{j,M}(K/3)^theta_z T^F_{jM,z}
       <=[7e/(8(1-p))] delta(z) H_p(z)^3.             (FB11)

Restore physical comparison e^4, three legs, two orientations and
the original factor 2Lambda, Lambda=128/119, exactly once:

    P_far^F(U) <= [21Lambda e^5/(2(1-p))]
         E sum_V integral delta(z) H_p(z)^3 nu_V(dz). (FB12)

Zero-anchor rows are zero before H_p is defined. The same parameter p
may depend on frozen outer data or hard z, but then its 1/(1-p) must
remain inside the corresponding original source integral. For the
next corollary p is a deterministic function of n, common to all data.
All three target legs retain their actual parameters; no new scale
or target-soft menu has been introduced.

## FB7. A single enlarged paid source gate, approaching log rho_D

For 0<p<1 and rho_D(z)=beta(D_V(z))/(qa^n)>0 define

    F_{p,z}={y in D_V(z):J(y-z)>=log_+rho_D(z)/p}.      (FB13)

This is one pre-frozen measurable cut of the original soft source.
It does not cut the source defining Pi_t. On this gate,
rho_p<=exp(-p*log_+rho_D/p)rho_D<=1. Hence with delta=1,

    P_far^{F_p}(U) <=[21Lambda e^5/(2(1-p))]
         [1+log B+log_+K]^3 ||f||_1.                 (FB14)

This uses the already established original disjoint-seed mass budget
E sum_V nu_V(V)<=||f||_1 once. The inequality applies to the actual
source-defined far-clock subset; it does not claim the subset is
nonempty or has an input-independent positive proportion.

For all n>=2 put

    L_n=max{2,log(n+2)},
    p_n=1-1/L_n=max{1/2,1-1/log(n+2)}.

Then p_n in [1/2,1), 1/(1-p_n)=L_n and FB14 gives

    P_far^{F_pn}(U) <=(21/2)Lambda e^5 L_n
           [1+log B+log_+K]^3 ||f||_1.               (FB15)

For the legal original choice K=1 from R241, this is
O(log^4(n+2))||f||_1, with the complete displayed constant. More
explicitly B<=e(pi+1)sqrt n, so the bracket is at most
2+log(pi+1)+(1/2)log n. A predetermined K=n^C gives the same order
with its explicit fixed-C constant. The current K must be used in
all original high/low and good/bad descendants; choosing it does not
delete low-pe, initial/jump, or any other unpaid mother-ledger branch.

For n>=6, p_n>1/2 and the threshold is

    log_+rho_D/p_n
       = [1+1/(log(n+2)-1)] log_+rho_D <2log_+rho_D

when rho_D>1. It approaches log_+rho_D as n grows and enlarges the
old single half-weight gate. For 2<=n<=5 it is precisely the old
factor two. If rho_D<=1 the gate includes all D, since J>=0. If the
threshold exceeds possible J on D the gate is empty. Either case is
handled without pretending an additional source payment. The gate
uses the maximum J, so its E/G_sharp/T union is charged once, not once
per component or once per distance layer. No conclusion about the
complement's source moment or a general root weak theorem follows.

## FB8. Bounded local arithmetic diagnostic

Python/mpmath 1.3.0 at 70 decimal digits was actually run on 16 finite
same-measure Holder cases, 48 infinite-geometric-series/cap cases and
72 optimized-exponent cases. The following code returned
`checks 136 max_holder_ratio 1.0 max_sum_ratio 0.5467478468323490772618 PASS`.
This checks constants and endpoints numerically, not FULL qualification
or a theorem derived by fitting a dimension order.

```python
import mpmath as m
m.mp.dps=70
Js=list(map(m.mpf,['0','.2','3','10']))
ws=list(map(m.mpf,['1','2','.5','3']))
att=list(map(m.mpf,['.1','.7','1','.3']))
I=[a*m.exp(-j) for a,j in zip(att,Js)]
cap=sum(w*x for w,x in zip(ws,I));tests=0
maxholder=m.mpf(0);maxsum=m.mpf(0)
for r in map(m.mpf,['.05','.2','.8','1']):
    for p in map(m.mpf,['0','.5','.9','.99']):
        th=(1-p)*r/2;eta=p*r
        lhs=sum(w*x**(1-2*th) for w,x in zip(ws,I))
        mp=sum(w*m.exp(-p*j) for w,j in zip(ws,Js))
        rhs=cap**(1-r)*mp**r
        assert lhs<=rhs*(1+m.mpf('1e-60'))
        maxholder=max(maxholder,lhs/rhs);tests+=1
        for n in [2,512,1000000]:
            h=n*m.log(1+m.mpf(1)/n);z=m.exp(-r*h)
            left=(h*z/(1-z)**2+1/(m.e*r))/(4*(1-m.exp(-4*th*h)))
            bound=m.mpf(7)/(16*th*r*r)
            assert left<=bound
            maxsum=max(maxsum,left/bound);tests+=1
for rho in [m.mpf('.01'),m.mpf(1),m.exp(20)]:
    for delta in [m.mpf(1),m.mpf('.01'),m.exp(-50)]:
        for K in map(m.mpf,['1','64']):
            B=m.e*m.ceil(m.pi*m.sqrt(512))
            H=1+max(0,m.log(rho))+m.log(B)+m.log(1/delta)+max(0,m.log(K))
            for p in map(m.mpf,['0','.5','.9','.99']):
                r=1/H;th=(1-p)/(2*H)
                factor=(K/3)**th*(B*rho/delta)**r
                assert factor<=m.e;tests+=1
print('checks',tests,'max_holder_ratio',m.nstr(maxholder,22),'max_sum_ratio',m.nstr(maxsum,22),'PASS')
```

The kernel/history proofs and finite positive-sum inequalities above
are the analytic basis. No other file, PDF, source construction or
Git operation is modified by this auxiliary delivery.
