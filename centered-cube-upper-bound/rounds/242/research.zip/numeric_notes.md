# R242 bounded design

Initial: genuine physical j0 and positive-j scalar kernels from legal gamma nodes, both orientations. Pressure: containment plateau with oldg0 but S>0, b=a/b2a and independent cap M=b. Expanded: n512/10^6 fixed-common-soft homogeneous products, no independently adaptive coordinates. General Holder uses one finite beta basis with fixed C,q across O and checks r=.5/1,p=.5/.9/p_n<1. O0 traffic is placed zero from the FIRST row before evaluating any optimization. The final geometric-series checks below use the normalization supplied by compare after its derivation. Tool models do not certify original FULL/history.

## Final executed menu:47 cases

Actually executed22 physical scalar/component and fixed-product cases,19 common-beta general-Holder arrays, and6 confirmed normalized geometric-series cases. These are three distinct finite evidence classes, not47 FULL instances. No R241 slab menu was repeated.

### Physical legality and three stages

For every physical row gamma=1+1/n and c^2=gamma^(-2j) are exact Fractions. The script verifies a=1<=c^2 M<=M<=b<=2a and M>=a/c^2, with M chosen at the lower endpoint or the independent upper capb. L,R are(M,c^2 M) or the reverse. At n in {1,2} no positive j is legal under b<=2a, so positivej true1D integrals are explicitly scalar building blocks for the declared n>=3 physical node, followed by fixed-common-soft homogeneous products where appropriate. The original FULL/history dimension/source qualification is not inferred from a building block.

Initial has n3,j0,b=a1 and three distinct(s,displacement/b) pairs(0,0),(.2,.75),(1,2). Positive-j containment plateau has n3,j1,b2,M=a/c^2 and both orientations, each s0/.2/1. Pressure has n16,j5,b2,M=b and both orientations, with hard s0 plateau or soft s1 displacement=b. Expanded has n512,j1,b2,capM, both orientations and(s,d/b)=(.2,.75),(1,2); n10^6,j1,capM,both orientations,s.2,d/b=.75; and n512,j177,capM,hard s0 plateau. Exact next-j legality is recorded: j177 is the final legal n512 index, j5 final for n16. Two adaptive rows use n3,j1 lower endpoints, two orientations and the same plateau displacement, but check ONLY the scalar component menu, not an independently adaptive n-product.

Plateau displacement is(M-c^2 M)/4; its exact hard deficit g=clip((d-M(1-c^2)/2)/(c^2 M),0,1)=0 while min(d/b,1)>0. At every row, the geometric inequality g>=min(d/b,1)-(1-c^2)/2 is verified with Fraction arithmetic. The log inequality n(1-c^2)/2<=jh and resulting sumgap>=T-jh are independently highprecision evaluated, h=nloggamma, T=min(S,.5exp(-3)n). The universal logarithm bound supporting that scale payment is analytic, not established by finitely many rows.

### Actual kernel and scale penalty

phi=h*integral_0^1 exp(-|u|/r)dr is the true normalized soft kernel, evaluated by its E3 formula. P_s,L=L^-1[(1-s)h+sphi] and h_R=R^-1 indicatorQ_R. Hard overlap is integrated analytically; soft quadrature is split at receiver endpoints, target hard endpoints and x0. Fixeds rows compute the TRUE one-coordinate integral then the homogeneous n-dimensional product with the same scalar L,R,d and common fixeds in every coordinate. The product logarithm is computed from the raw integral inside the30/50dps context BEFORE output serialization, improving the specific precision bottleneck noted in R241. There is no independent coordinate scale/soft optimization, no omitted infinite hard-receiver tail and no fitted dimension order. Maximum30/50 saved scalar difference is5e-32; this remains ordinary noninterval quadrature rather than a certificate.

Fixeds scalar check is M I1<=exp(jloggamma-min(S/n,epsilon)); the homogeneous product check is log(M^n I_n)<=jh-T. At the n3j1,n16j5,n512j177 hard plateaus, normalizedMI1=1 exactly while T is respectively.0746806,.3982965,12.7454895. The corresponding jh values are.8630462,4.8499697,176.8273732. Thus deleting the scale penalty really would falsely predict suppression exp(-T)<1. This is an intended boundary diagnostic of the corrected formula, not a counterexample to that formula or an original FULL input. The remaining e^(-4theta jh) node factor is what later pays this retained scale cost.

Actual scalar s(x)=.2 forx<0,.8 otherwise is checked only with B1=eceil(pi)=4e multiplying the scalar building-block bound. The script does NOT raise these adaptive component integrals to n and does not claim the original common-soft n-dimensional adaptive menu has been numerically integrated.

### General Holder on one common beta basis

All nineteen arrays have beta weights(1,1/2,2,1/8), J=(0,1,8,40), C=2 independentO, damping(.8,.3,.9,.1), and I=O C exp(-J)damping (or identically0 in one endpoint row). The fixed q=sum beta C exp(-J)damping+.01 is independentO. Thus these arrays genuinely obey both I<=C exp(-J) and integralI beta<=qO on the SAME measure. They do not use unrelated extrema for the pointwise cap and row cap.

p=.5/.9 at n2 and p=.5/.9/p_n at n1000/10^6, r=.5/1. p_n=max(.5,1-1/log(n+2))<1, eta=pr and theta=(r-eta)/2. The final three endpoint rows have O0 with r1 or.5, or zeroI with O1,r1. Each row checks

    integral I^(1-2theta) beta
    <= C^eta (qO)^(1-r) [integral exp(-pJ)beta]^r.

For O0 the original FIRST row itself forces I=0; traffic is placed0 BEFORE optimization. The formal r1 Holder expression can be positive because(qO)^0=1; the JSON retains that formal expression separately instead of incorrectly declaring0^0=0. Nonzero lhs/rhs ratios range.0116843 to.8810643. All calculations run independently at40/70dps. The arrays are algebra tools, not a claim that the finite basis meets original FULL geometric/source/history conditions.

Each same array also partitions its original source weights once at J>=log_+rho_D/p, rho_D=beta_mass/q (unit a^n), and checks rho_p,F<=1. It records1/(1-p) explicitly, never p1 or a free limiting exponent. No separate FIRST resources are assigned to different distance layers, and no conclusion is drawn that a useful far part must occur for every original input. The actual J=max(E,Gsharp,T) source qualification is the parent proof's task; these arrays test the stated conditional algebra only.

### Confirmed infinite-series and fee diagnostics

Six rows n2/1000/10^6, p=.5 withr1 or p_n withr.5, evaluate the compare-confirmed normalized perleg/perorientation sum

    [h exp(-rh)/(1-exp(-rh))^2 +1/(e r)]
      / [4(1-exp(-4theta h))] <=7/(16theta r^2).

The regular M block and independent worst cap are checked against2/r^2; the j block against7/(8theta). Independent cap position is1/r, even if it happens to duplicate a regular slot; this intentional extra positive slot is conservative. All regular and j tails are included in closed form. For transparency, the JSON also gives partial j0..4,k0..8 and the separate nonnegative j/k omitted tails, whose sum matches the full-minus-partial value. Thus no finite truncation is misused as an infinite upper bound. Total/bound ratios range.1722824 to.3948734, at40/70dps.

This normalized series excludes delta(K/3)^theta(B rho/delta)^r, as explicitly stated in JSON. The final analytic price coefficient21Lambda exp(5)/(2(1-p)) is retained with Lambda128/119; it is a derived coefficient supplied by the proof, not an additional original source-budget simulation. Under r=1/H,theta=(1-p)/(2H), the analytic normalized bound7H^3/[8(1-p)] and exponential factor lead to the parent's stated fee. All hidden source/node/menu qualifications remain with that proof. K is not independently optimized here.

## Reproduction and scope

Existing bundled Python3.12.14 plus vendor mpmath1.3.0; no installation, NumPy or Git action. Script supports --output and --contract, can be relocated with the contract, and excludes runtime/path strings from JSON.

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/242/work/numeric_checks.py \
--output /tmp/r242_numeric_replay.json \
--contract /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/242/work/task_contract.md
```

No adaptive variable-scale kernel is normalized, no beta rank is borrowed, no posterior is clipped and no general root-order closure is inferred. The geometric endpoint stress records why the restored scale cost matters while leaving all actual FULL qualifications explicit.

## Frozen final replay

Complete separate-output replay is byte-identical: 119700 bytes. Actual counts22 physical cases,19 commonHolder arrays,6 geometric-series diagnostics. Timed wall.53s,user.51s,system.00s. SHA256 source `6505a0acaa73322b6259103fc19b2f34f92e30a8cf5ede54326f9a8d34d92420`; JSON `467c3ce6d67d7fb997646b929235626d7d392ac0369eaf72ad91593ac79e01b1`; contract `2ddac71f1c254708354dbb242282626c3ef63b60a175cfe541f488bd6768bd91`. No further menu expansion.
