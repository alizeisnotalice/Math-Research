# R242 — 用原尺度衰减支付窗口差，优化来源权指数
日期2026-10-17。开工main/HEAD c6667e053fdd1ec648285137ec8e1cc882f846a9；工作区干净，R241已推送，属于实际进展。保持原一般n^(1/2+o(1))目标，不将分支付款替代闭合。

## 准确候选及来源
原物理节点(L*,R*)=(M,c²M)或反，γ=1+1/n,c=γ^-j,h=nlogγ,M0=a/c²，X=nlog(M/M0),Z=(X−U)+。原a≤b≤2a及所有FULL/FIRST/capture/actual-soft/fullΠ资格保留。B=e ceil(π√n)，ε=(1/2)exp(-3)。允许R238–241已审主链；K按原∀K族一致取1，不删除low-pe等母账补项。

令S=Σmin(|dy_i|/b,1),T=min(S,εn)。实际hard deficit g_i^j≥min(|dy_i|/b,1)−(1−c²)/2，n(1−c²)/2≤jh，因此fixed-common-soft归一窗口≤exp(jh−T)。实际s(x)通过B菜单付费，不交换sup积分。旧E点帽可精化为L*^-n exp(-E)O≤M^-n exp(2jh−E)；R241Gsharp点帽为BM^-n exp(-Gsharp)。取J=max(E,Gsharp,T)得到统一I0≤BM^-n exp(2jh−J)。这保留尺度费用而去掉统一(b−a)/2造成的假plateau。

一般插值：r=2θ+η≤1,p=η/r<1，m_p=∫F exp(-pJ)β，ρp=m_p/(qa^n)。同β Holder/FIRST给∫I0^(1−2θ)β≤(BM^-n exp2jh)^η(qO)^(1−r)m_p^r。接原half列/Gini/clock后node≤Z/4 B^rρp^rδ^(1−r)exp(-4θjh)exp(-rX)。须完整证明j/M和及外费用；选r1/H、θ=(1−p)/(2H)可望C/(1−p)δH³，其中H=1+log+ρp+logB+log+K+log1δ。

候选单门J≥log+ρD/p使ρp≤1；p接近1时门比旧2logρD更宽，但全部p费用须保留，不能取p=1。p_n=max(1/2,1−1/log(n+2))作为候选允许O(log⁴n)子支付款；不是一般root闭合。所有source选择早于receiver、auxiliaryslots和nodes，fullΠ始终不裁剪。

## 分工、核验与交付
peak:scale_geometry.md，仅物理尺度和新几何、固定p=.5回代与明确补域。
compare:fractional_budget.md，仅一般p/θ/η预算及合法门，不重复历史审计。
audit:audit.md，先独筛命题量词，再审作者，核原节点/端点/真实测度/常数及最终回代。
numeric:numeric_checks.py/json、numeric_notes.md，实际本机三阶段真实kernel/合法节点/共同Holder数组检查，--output和--contract支持异地重放。
主代理：主要推导、contract、LaTeX、报告、重放、精简归档和独立提交推送。各人只写责任文件，不覆盖其他人，不自行提交，交付后停止。

N04技能仅用于多尺度费用与有限和先行的审查流程，本轮不借未验证的熵递减定理。数值初探/端点压力/扩大参数须实际运行，有限工具例不能证明FULL非空或一般阶。不得βrank、免费菜单FIRST、变量尺度归一、复制Wν及负信用。成功为独审新估计或真实扩大且费用已清的来源门；全部余支未证则目标保持active。只新增README+ZIP，详细LaTeX不编译PDF。
