#!/usr/bin/env python3
"""R776 exact first-trigger versus fixed-price certificate, with price-cube thickening."""

from fractions import Fraction as F
from functools import lru_cache
from itertools import product
import json
import sys


N=4
A=32*N
H=1+F(1,A)
R=F(1)
D=2**(N-1)
WIDTH=2*H*R
T=F(7,2)
EPS=F(1,4096)
MARKS = tuple((z,)*N for z in map(F,("0","-7/8","7/16","31/32","1")))
MARK_NAMES = ("anchor","left","right","fast","outside")
MASS = (F(1,5),)*len(MARKS)
ANCHOR=0


def cube(center,radius):
    return tuple((z-radius,z+radius) for z in center)


def meet(*boxes):
    return tuple((max(axis[0] for axis in axes),min(axis[1] for axis in axes))
                 for axes in zip(*boxes))


def contains(outer,inner):
    return all(a<=c<=d<=b for (a,b),(c,d) in zip(outer,inner))


def volume(box):
    out=F(1)
    for a,b in box:
        out*=max(F(0),b-a)
    return out


def mul(values):
    out=F(1)
    for v in values:
        out*=v
    return out


def ceil_log2_recip(p):
    assert 0<p<=1
    k=0
    while (1<<k)*p<1:
        k+=1
    return k


def score(p):
    return p*(2+ceil_log2_recip(p))**2


def certify():
    source_radius=F(127,128)
    small_radius=F(63,64)
    S_E=cube((F(1,16),)*N,source_radius)
    S_G=cube((F(0),)*N,small_radius)
    E_e=cube((F(1,16),)*N,source_radius/A)
    E_g=cube((F(0),)*N,small_radius/A)
    assert contains(S_E,E_e) and contains(S_G,E_g) and volume(meet(E_e,E_g))==0
    assert D<=volume(S_G)<volume(S_E)<2*D and (2*R)**N==2*D
    C=(S_E,meet(S_E,cube((F(0),)*N,F(29,32))))
    mark_boxes = tuple(cube(z,EPS) for z in MARKS)
    assert all(not volume(meet(a,b)) for i,a in enumerate(mark_boxes) for b in mark_boxes[:i])
    common = tuple(meet(c,S_G) for c in C)
    atoms = tuple(tuple(i for i,z in enumerate(MARKS) if contains(mark,cube(z,0)))
                  for mark in common)
    assert atoms==((0,1,2,3),(0,1,2))
    for eligible,mark in zip(atoms,common):
        assert all(contains(mark,box) if i in eligible else not volume(meet(mark,box))
                   for i,box in enumerate(mark_boxes))
        assert ANCHOR in eligible
        for i in eligible:
            # All thickened original and supplementary prices contain the true owner after dilation.
            certain=tuple((b-H*R,a+H*R) for a,b in mark_boxes[i])
            assert contains(certain,E_g)
    extra_small_only=cube((F(-31,32),)*N,EPS)
    assert all(contains(S_E,box) for box in mark_boxes)
    assert not volume(meet(S_G,mark_boxes[-1]))
    assert contains(S_G,extra_small_only) and not volume(meet(S_E,extra_small_only))
    m_e,m_g=volume(S_E),volume(S_G)
    extra_mass=m_g-F(4,5)*m_e
    assert extra_mass>0
    raw_price_boxes=tuple((box,m_e/5) for box in mark_boxes)+((extra_small_only,extra_mass),)

    def mu(box):
        return sum(weight*volume(meet(box,price_box))/volume(price_box)
                   for price_box,weight in raw_price_boxes)

    assert (mu(S_E),mu(S_G))==(m_e,m_g)
    assert all(mu(meet(S_E,box))/m_e==MASS[i] for i,box in enumerate(mark_boxes))
    assert mu(meet(S_E,extra_small_only))==0
    owner_e,owner_g=volume(E_e),volume(E_g)
    I_e=(owner_e/2,owner_e/2)
    I_g=owner_g
    shared=tuple(mu(mark) for mark in common)
    true_K=tuple(m/(m_e*m_g) for m in shared)
    d_e=tuple(I_g*k for k in true_K)
    d_g=sum(i*k for i,k in zip(I_e,true_K))
    actual_old_peaks=tuple(i*I_g**2*k*k/de for i,k,de in zip(I_e,true_K,d_e))
    assert all((I_g*k)/de==1 for k,de in zip(true_K,d_e))
    anchor_mass=mu(mark_boxes[ANCHOR])
    actual_anchor_peaks=tuple(raw*anchor_mass/m for raw,m in zip(actual_old_peaks,shared))
    assert actual_anchor_peaks==tuple(i*I_g*anchor_mass/(m_e*m_g) for i in I_e)

    @lru_cache(None)
    def volumes(mark_set):
        marks=tuple(sorted({ANCHOR,*mark_set}))
        actual=meet(*(cube(MARKS[i],H*R) for i in marks))
        assert contains(actual,E_g)
        p=volume(actual)/WIDTH**N
        ref=[]; ext_low=[]; ext_high=[]
        for j in range(N):
            coords=[MARKS[i][j] for i in marks]
            ref.append(1-(max(coords)-min(coords))/WIDTH)
            r_min=max(F(0),max(coords)-min(coords)-2*EPS)
            r_max=max(coords)-min(coords)+2*EPS
            ext_low.append(1-r_max/WIDTH)
            ext_high.append(1-r_min/WIDTH)
        assert p==mul(ref) and 0<mul(ext_low)<=p<=mul(ext_high)<=1
        return p,mul(ext_low),mul(ext_high)

    reports=[]
    for index,allowed in enumerate(atoms):
        a=sum(MASS[i] for i in allowed)
        assert shared[index]/m_e==a
        gaps={}
        @lru_cache(None)
        def passes(mark_set,k):
            p,pl,ph=volumes(mark_set)
            cap=T*a**k
            okay=score(p)<=cap
            # The rounded score is bounded even if endpoints meet different binary bins.
            low=pl*(2+ceil_log2_recip(ph))**2
            high=ph*(2+ceil_log2_recip(pl))**2
            margin=cap-high if okay else low-cap
            assert margin>0
            gaps[mark_set,k]=margin
            return okay

        def first(path):
            mark_set=frozenset()
            before=F(1)
            for k,i in enumerate(path,1):
                mark_set=mark_set|{i}
                now=volumes(mark_set)[0]
                assert now<=before
                if passes(mark_set,k):
                    return k,now
                before=now
            return 0,before

        for horizon in (1,2,5):
            # Actual conditional sampling: all length-horizon paths in the restricted price law.
            direct=dict.fromkeys(range(horizon+1),F(0))
            actual_volume=dict.fromkeys(direct,F(0))
            thick_low=dict.fromkeys(direct,F(0))
            thick_high=dict.fromkeys(direct,F(0))
            for word in product(allowed,repeat=horizon):
                k,p=first(word)
                weight=mul(MASS[i]/a for i in word)
                direct[k]+=weight
                actual_volume[k]+=weight*p*WIDTH**N
                _,lo,hi=volumes(frozenset(word[:k or horizon]))
                thick_low[k]+=weight*lo*WIDTH**N
                thick_high[k]+=weight*hi*WIDTH**N

            # Change of measure: use all common-source prefixes, with the original a^(-k).
            reference=dict.fromkeys(direct,F(0))
            reference_volume=dict.fromkeys(direct,F(0))
            seen_raw=dict.fromkeys(direct,F(0))
            allowed_set=set(allowed)
            for k in range(1,horizon+1):
                for word in product(range(len(MARKS)),repeat=k):
                    if not set(word)<=allowed_set:
                        continue
                    s,p=first(word)
                    group=k if s==k else 0 if s==0 and k==horizon else None
                    if group is None:
                        continue
                    raw=mul(MASS[i] for i in word)
                    seen_raw[group]+=raw
                    reference[group]+=raw/a**k
                    reference_volume[group]+=raw/a**k*p*WIDTH**N
            assert direct==reference and actual_volume==reference_volume and sum(direct.values())==1
            for k,val in direct.items():
                assert volume(E_g)*val<=actual_volume[k]<=WIDTH**N*val
                assert thick_low[k]<=actual_volume[k]<=thick_high[k]
            original={k:actual_anchor_peaks[index]*w for k,w in direct.items()}
            assert sum(original.values())==actual_anchor_peaks[index]
            reports.append({"history":index,"a":a,"horizon":horizon,
                            "true_anchor_raw_original_peak_mass_by_stop_layer":original,
                            "true_anchor_raw_success_mass":sum(v for k,v in original.items() if k),
                            "true_anchor_raw_no_stop_mass":original[0],
                            "true_stop_law_zero_means_no_stop":direct,"pre_correction_common_source_prefix_mass":seen_raw,
                            "expected_unconditional_volume_by_stop_layer":actual_volume,
                            "thickened_expected_volume_enclosure_by_stop_layer":
                                {k:[thick_low[k],thick_high[k]] for k in direct},
                            "old_fixed_one_supplement_success":direct[1],
                            "extra_success_due_to_first_trigger":sum(direct[k] for k in direct if k>=2),
                            "mistaken_single_power_normalizer_total":sum(seen_raw.values())/a,
                            "strict_margin_over_thickened_boxes":min(gaps.values())})

    lessons = {(r["history"],r["horizon"]):r for r in reports}
    assert 0<lessons[0,1]["old_fixed_one_supplement_success"]<1
    assert lessons[1,1]["old_fixed_one_supplement_success"]==0
    assert all(0<lessons[i,5]["extra_success_due_to_first_trigger"]<1
               and lessons[i,5]["true_stop_law_zero_means_no_stop"][0]>0 for i in (0,1))
    assert lessons[0,5]["mistaken_single_power_normalizer_total"]<1
    # The very same allowed word can fire at k=3 under one history and never fire under the other.
    trace = (ANCHOR,1,2)
    record=[]
    for allowed in atoms:
        a=sum(MASS[i] for i in allowed)
        assert set(trace)<=set(allowed)
        decision=[]
        for k in range(1,len(trace)+1):
            p=volumes(frozenset(trace[:k]))[0]
            decision.append({"k":k,"p":p,"rounded_score":score(p),"rhs":T*a**k,"fires":score(p)<=T*a**k})
        record.append(decision)
    assert not any(r["fires"] for r in record[0][:2]) and record[0][-1]["fires"]
    assert not any(r["fires"] for r in record[1])
    assert score(F(1))>T
    raw_summaries={}
    for horizon in (1,2,5):
        raw=tuple(lessons[i,horizon] for i in range(len(atoms)))
        success=sum(r["true_anchor_raw_success_mass"] for r in raw)
        residual=sum(r["true_anchor_raw_no_stop_mass"] for r in raw)
        assert success+residual==sum(actual_anchor_peaks)
        raw_summaries[horizon]={"success":success,"remaining":residual}
    return {"dimension":N,"D":D,"R_D":R,"h":H,"T":T,
            "real_parent_boxes":{"e":S_E,"g":S_G},
            "real_disjoint_uniform_owners":{"e":E_e,"g":E_g},
            "known_original_price_y":MARKS[ANCHOR],"marks":dict(zip(MARK_NAMES,MARKS)),
            "actual_reference_weights":MASS,"actual_reference_cube_thickening_half_side":EPS,
            "true_mu_parents_and_reference":{"m_e":m_e,"m_g":m_g,"mu_anchor_price":anchor_mass,
                                            "g_only_box":extra_small_only,"g_only_mu":extra_mass,
                                            "reference":"rho_e = mu restricted to A_e divided by m_e"},
            "true_graph_and_original_peak":{"I_e":I_e,"I_g":I_g,"K_eg":true_K,"d_e":d_e,"d_g":d_g,
                                            "all_raw_old_peak_by_history":actual_old_peaks,
                                            "anchor_raw_old_peak_by_history":actual_anchor_peaks,
                                            "anchor_raw_success_residual_both_histories":raw_summaries},
            "actual_reference_original_anchor_mass":MASS[ANCHOR],
            "genuine_marked_intersections":common,
            "true_eligible_marks":[[MARK_NAMES[i] for i in row] for row in atoms],
            "score":"p*(2+ceil(log2(1/p)))^2; testing begins with the first new price",
            "common_source_change_of_measure":"actual iid price law is nu restricted to the given history intersection divided by a; length-k prefix has factor a^(-k)",
            "first_stop_by_horizon":reports,
            "same_true_word_differs_between_histories":{"word":[MARK_NAMES[i] for i in trace],"comparison":record},
            "scope":"common source is the genuine parent reference rho_e from continuous uniform price cubes; mark centers enumerate stopping classes, with exact thickened volume enclosures",}


if __name__=="__main__":
    print(json.dumps({"python":sys.version.split()[0],"command":"python -B stop776.py",
                      "arithmetic":"Fraction","certificate":certify()},indent=2,sort_keys=True,default=str))
