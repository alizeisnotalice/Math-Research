#!/usr/bin/env python3
"""Actual two-price masses, adaptive source-cell covers and the three-hop bound."""

import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path

from cells776 import load, MODEL_HASH


def calculate(ns, width, shift, limit):
    (dpar, centers, octaves, parents, owners, volumes, histories, labels, I, blocks,
     keys, overlaps, K, mass, degree, down, p, breaks, anchors, Y, heat, Q,
     shared, deleted) = ns["make_model"]()
    measure, meet = ns["density_integral"], ns["meet"]
    zero = F(0)
    small = {e: [g for g in keys if K[e, g] and mass(g) < mass(e)] for e in keys}
    private = [(shift+k*width, shift+(k+1)*width)
               for k in range((F(-12)-shift)//width, (F(12)-shift)//width+1)]
    # P_-(e,{u}, true price in J) with the original, untruncated degree.
    arms = {(e, u, b): I[u]*measure(meet(overlaps[e,u], cell))
            /(degree[e]*mass(e)*mass(u))
            for e in keys for u in small[e] for b, cell in enumerate(private)}
    marginal = {(e,b): sum((arms[e,u,b] for u in small[e]), zero)
                for e in keys for b in range(len(private))}
    for e in keys:
        assert sum(marginal[e,b] for b in range(len(private))) == p[e]

    Z = selected = original = energy = energy_hard = energy_soft = zero
    hard_probed = nonhard_all = max_ratio = zero
    num = 0
    seen = set()
    for low, high in anchors:
        y = (low+high)/2
        dy = measure((low,high))
        for octv in sorted(set(octaves)):
            hy = {e:I[e]/mass(e) for e in keys if octaves[labels[e]] == octv
                  and blocks[e][0]<y<blocks[e][1]}
            H = sum(hy.values(), zero)
            if not H:
                continue
            Z += dy*H**2
            t = {e:sum((hy[g] for g in small[e] if g in hy),zero) for e in hy}
            active = [e for e in hy if t[e] and p[e]]
            if not active:
                continue
            num += 1
            rows = {}
            for e in active:
                nonempty = [b for b in range(len(private)) if marginal[e,b]]
                rows[e] = {b:hy[e]*t[e]*marginal[e,b] for b in nonempty}
                # Direct old peak at fixed first genuine source, separate its two old ends.
                for b in nonempty:
                    old = sum((hy[e]*hy[g]*arms[e,u,b]
                               for g in small[e] if g in hy for u in small[e]), zero)
                    assert old == rows[e][b]
            fields = [sum((row.get(b,zero) for row in rows.values()),zero)
                      for b in range(len(private))]
            r = sum(fields, zero)
            original += dy*r
            pick = sorted(range(len(private)), key=lambda b:(-fields[b],b))[:limit]
            seen.add(tuple(pick))
            selection = sum(fields[b] for b in pick)
            selected += dy*selection
            all_energy = sum(v*v for v in fields)/H**2
            energy += dy*all_energy
            assert selection**2 <= limit*all_energy*H**2

            pair_sum = zero
            for e,v in product(active,repeat=2):
                matched = set(rows[e]).intersection(rows[v])
                value = sum((rows[e][b]*rows[v][b] for b in matched),zero)/H**2
                pair_sum += value
                if K[e,v]:
                    # Independent actual private arms on u--e--v--u' in a common small source cell.
                    chain = hy[e]*hy[v]*sum((marginal[e,b]*marginal[v,b] for b in matched),zero)
                    assert value == chain*t[e]*t[v]/H**2 <= chain
                    energy_hard += dy*value
                    hard_probed += dy*chain
                    if chain:
                        max_ratio = max(max_ratio,value/chain)
                else:
                    energy_soft += dy*value
                    nonhard_all += dy*hy[e]*hy[v]*t[e]*t[v]*p[e]*p[v]/H**2
            assert pair_sum == all_energy
    assert original==Q and energy_hard+energy_soft==energy
    assert 0<selected<original and 0<energy_hard<=hard_probed
    assert energy_soft<=nonhard_all and selected**2<=limit*Z*energy
    return {"width":width, "origin":shift, "max_private_cells_per_source":limit,
            "shared_source_octave_cells":num, "different_selected_cell_lists":len(seen),
            "whole_peak":original, "actual_selected":selected, "actual_remaining":original-selected,
            "Z":Z,"all_diagonal_cell_energy":energy,"true_hard_part":energy_hard,
            "nonhard_part":energy_soft,"three_hop_same_private_cell_upper":hard_probed,
            "all_nonhard_root_pair_upper":nonhard_all,"max_hard_density_ratio":max_ratio,
            "cauchy_squared_ratio":selected**2/(limit*Z*energy)}


def rate_cases(ns):
    """Upper and lower rational bounds for the rate gate on the actual old volume cells."""
    from functools import lru_cache
    (dpar, centers, octaves, parents, owners, volumes, histories, labels, I, blocks,
     keys, intersections, K, mass, degree, down, p, breaks, anchors, Y, heat, Q,
     shared, deleted) = ns["make_model"]()
    mu, meet, size = (ns[k] for k in ("density_integral", "meet", "size"))
    edges = {e:[g for g in keys if K[e,g] and mass(g)<mass(e)] for e in keys}
    theta = {(e,g):mu(intersections[e,g])/mass(g) for e in keys for g in edges[e]}
    eta = max(theta.values())
    h, cutoff = F(33,32),F(1,8)
    @lru_cache(None)
    def unit_log(u):
        assert 1<=u<=2
        x=(u-1)/(u+1)
        n=12
        value=2*sum(x**(2*i+1)/(2*i+1) for i in range(n))
        tail=2*x**(2*n+1)/((2*n+1)*(1-x*x))
        return value,value+tail
    @lru_cache(None)
    def rate(t):
        z,k=eta/t,0
        while z>=2:
            z/=2
            k+=1
        a,b=unit_log(z)
        c,d=unit_log(F(2))
        return t*(1+a+k*c), t*(1+b+k*d)
    out=[]
    for width,shift,T in [(F(1,4),F(0),F(24)),(F(1,2),F(0),F(12)),(F(1,4),F(1,16),F(24))]:
        cells=[(shift+k*width,shift+(k+1)*width)
               for k in range((F(-12)-shift)//width,(F(12)-shift)//width+1)]
        plain=adaptive=rate_only=tiny=F(0)
        distinct_checks=0
        for e in keys:
            tiny_from_cells=F(0)
            for b in cells:
                M=mu(meet(parents[labels[e]],b))
                hit={}
                for g in edges[e]:
                    shared_mu=mu(meet(b,intersections[e,g]))
                    if not shared_mu:
                        continue
                    t=theta[e,g]
                    Bvol=width+h*mass(g)
                    w=I[e]*p[e]*I[g]*shared_mu/(mass(e)*mass(g))
                    low,high=rate(t)
                    threshold=T*M
                    accepted=high*Bvol<=threshold
                    assert accepted or low*Bvol>threshold
                    a0=eta*Bvol<=threshold
                    if a0:
                        assert accepted
                        plain+=w
                    if accepted:
                        adaptive+=w
                        if not a0:
                            rate_only+=w
                        if t>=cutoff:
                            hit[g]=t
                    if t<cutoff:
                        tiny_from_cells+=w
                for t in sorted(set(hit.values())):
                    good=[g for g,u in hit.items() if u>=t]
                    radius=max(mass(g) for g in good)/2
                    expanded=(b[0]-h*radius,b[1]+h*radius)
                    lab={labels[g] for g in good}
                    assert all(meet(expanded,owners[i])==owners[i] for i in lab)
                    owners_vol=sum(volumes[i] for i in lab)
                    assert sum(I[g] for g in good)<=owners_vol<=size(expanded)
                    assert rate(t)[1]*size(expanded)<=T*M
                    distinct_checks+=1
            all_tiny=sum((I[e]*p[e]*I[g]*theta[e,g]/mass(e) for g in edges[e]
                          if theta[e,g]<cutoff),F(0))
            assert all_tiny==tiny_from_cells
            assert all_tiny<=I[e]*cutoff*(1+h)
            tiny+=all_tiny
        assert adaptive==plain+rate_only and 0<rate_only and adaptive<Q
        out.append({"width":width,"shift":shift,"T":T,"eta":eta,
                    "constant_rate_gate":plain,"actual_rate_gate":adaptive,"actual_rate_only":rate_only,
                    "tiny_rate_whole_source_mass":tiny,"receiver_capacity_thresholds":distinct_checks,
                    "undecided_comparisons":0})
    return out


def common_probes(ns):
    """Pay only when the entire two genuine price cells certify the first-step test."""
    (dpar, centers, octaves, A, E, volumes, histories, labels, I, C,
     keys, inter, K, mass, degree, down, p, breaks, anchors, Y, heat, Q,
     shared, deleted) = ns["make_model"]()
    mu, meet, size = (ns[k] for k in ("density_integral","meet","size"))
    h=F(33,32)
    small={e:[g for g in keys if K[e,g] and mass(g)<mass(e)] for e in keys}
    results=[]
    for step,tau in [(F(1,2),F(3,4)),(F(1,4),F(2,3)),(F(1,8),F(1,2))]:
        points=sorted({F(-12)+i*step for i in range(int(24/step)+1)}
                      | {v for box in (*A,*C) for v in box})
        cells=[(a,b) for a,b in zip(points,points[1:]) if a<b]
        mc={box:mu(box) for box in cells}
        total=actual=distinct=outside_block=F(0)
        cap_checks=0
        for e in keys:
            D=F(octaves[labels[e]])
            if not small[e]:
                continue
            # Every possible smaller history for this one-dimensional physical octave lies in D..2D.
            assert all(D<=mass(g)<2*D for g in small[e])
            eligible=[b for b in cells if meet(b,C[e])==b]
            for b in eligible:
                available={g:I[g]/mass(g) for g in small[e] if meet(b,C[g])==b}
                W=sum(available.values(),F(0))
                if not W:
                    continue
                row=I[e]*p[e]*mc[b]/mass(e)
                total+=row*W
                rates={g:mu(inter[e,g]) for g in available}
                raw={g:sum((I[e]*I[g]*I[u]*K[e,g]*K[e,u]/degree[e]
                            for u in small[e]),F(0))*mc[b]/rates[g] for g in available}
                assert all(raw[g]==row*w for g,w in available.items())
                via_receivers=via_histories=F(0)
                for q in eligible:
                    gap=max(F(0),b[0]-q[1],q[0]-b[1])
                    if gap<2*h*D*(1-tau):
                        continue
                    other=[v for v in available if meet(q,C[v])==q]
                    targets=[g for g in available if meet(A[labels[g]],q)==q]
                    if not other or not targets:
                        continue
                    cap=(max(b[1],q[1])-h*D,min(b[0],q[0])+h*D)
                    lab={labels[g] for g in targets}
                    assert all(meet(E[i],cap)==E[i] for i in lab)
                    cap_checks+=1
                    all_target=sum(available[g] for g in targets)
                    assert all_target<=sum(volumes[i] for i in lab)/D<=size(cap)/D<=2*h*tau
                    qprob=sum(available[v]*mc[q]/(W*rates[v]) for v in other)
                    via_receivers+=row*qprob*all_target
                    for g in targets:
                        for v in other:
                            m=raw[g]*available[v]*mc[q]/(W*rates[v])
                            via_histories+=m
                            if labels[g]!=labels[v]:
                                distinct+=m
                            if meet(q,C[g])!=q:
                                outside_block+=m
                assert via_receivers==via_histories
                actual+=via_histories
        assert total==Q and 0<actual<Q and 0<distinct<=actual and outside_block<=distinct
        assert actual<=2*h*tau*Y
        results.append({"price_mesh":step,"threshold":tau,"tested_price_and_owner_events":cap_checks,
                        "actual_original_paid":actual,"unpaid_original":Q-actual,
                        "different_actual_small_parents":distinct,
                        "probe_inside_physical_parent_outside_original_true_block":outside_block,
                        "fixed_single_octave_bin_budget":2*h*tau*Y})
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model",required=True,type=Path)
    args=parser.parse_args()
    ns=load(args.model)
    inputs=[(F(1,2),F(0),1),(F(1,4),F(1,16),2),(F(1,8),F(0),5)]
    print(json.dumps({"model_hash":MODEL_HASH,"arithmetic":"Fraction",
                      "cases":[calculate(ns,*data) for data in inputs],"actual_rate_cases":rate_cases(ns),"common_probes":common_probes(ns)},
                     indent=2,sort_keys=True,default=str))
