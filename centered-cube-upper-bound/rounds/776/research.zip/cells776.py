#!/usr/bin/env python3
"""R776 exact shared-price cell payment and root collision on the frozen R774 model."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
import hashlib
from itertools import product
import json
from pathlib import Path
import sys


MODEL_HASH = "8fdd6ddf88d8b2b8a8be4bac44199ba8cff67aa153cca624420bff0d641d78d2"
DEFAULT_MODEL = (Path(__file__).resolve().parents[2] /
                 "centered-cube-r774-20261119" / "number" / "verify.py")


def load(path):
    source = path.read_bytes()
    assert hashlib.sha256(source).hexdigest() == MODEL_HASH
    ns = {"__name__":"frozen_cell_geometry"}
    exec(compile(source,str(path),"exec"),ns)
    return ns


def check(ns):
    (m_parent,centres,octaves,A,E,v_owner,histories,labels,I,C,keys,overlap,K,
     volume,degree,down,p,breaks,prices,Y,int_H,Q,common_rows,deleted) = ns["make_model"]()
    mu,meet,size,ss = (ns[key] for key in ("density_integral","meet","size","summation"))
    m = tuple(map(volume,keys))
    O = tuple(octaves[labels[e]] for e in keys)
    OCT = sorted(set(O))
    arm = {e:tuple(g for g in keys if m[g]<m[e] and K[e,g]>0) for e in keys}
    s = {(e,g):mu(overlap[e,g]) for e in keys for g in arm[e]}
    assert all(K[e,g]==value/(m[e]*m[g]) for (e,g),value in s.items())
    eta_e = {e:max((s[e,g]/m[g] for g in arm[e]),default=F(0)) for e in keys}
    eta_test = max(eta_e.values())
    h = F(33,32)
    radius_min = {o:min(size(A[i])/2 for i in range(len(A)) if octaves[i]==o) for o in OCT}

    def group(g):
        return int(4*m[g]>=5*O[g])+int(2*m[g]>=3*O[g])

    def grid(width,shift):
        lo = (F(-12)-shift)//width
        hi = (F(12)-shift)//width+1
        return [(shift+k*width,shift+(k+1)*width) for k in range(lo,hi)]

    def peak_path_table(cells):
        table = defaultdict(lambda:defaultdict(F))
        for e in keys:
            for u,g in product(arm[e],repeat=2):
                raw = I[e]*I[u]*I[g]*K[e,u]*K[e,g]/degree[e]
                for B in cells:
                    restriction = mu(meet(B,overlap[e,g]))
                    if restriction:
                        table[e,B][g] += raw*restriction/s[e,g]
        return table

    def owner_cell_table(cells):
        table = defaultdict(lambda:defaultdict(F))
        for e in keys:
            if not arm[e]:
                continue
            for B in cells:
                for g in arm[e]:
                    actual = mu(meet(C[e],C[g],B))
                    if actual:
                        owner = E[labels[g]]
                        owner_charge_density = I[g]/size(owner)
                        amount = (I[e]*p[e]/m[e])*actual*(owner_charge_density/m[g])*size(owner)
                        table[e,B][g] += amount
        return table

    def cell_case(width,shift,T):
        cells = grid(width,shift)
        for e in keys:
            assert ss(mu(meet(A[labels[e]],B))/m[e] for B in cells)==1
        path = peak_path_table(cells)
        by_owner = owner_cell_table(cells)
        assert path==by_owner
        assert ss(v for row in path.values() for v in row.values())==Q
        C_o = {o:h+(width/2)/radius_min[o] for o in OCT}
        totals = defaultdict(F)
        diagnostics = defaultdict(int)
        witness = None

        def owners_inside(eligible,B,cap,o):
            if not eligible:
                return F(0)
            assert cap>=max(m[g] for g in eligible)
            a,b = B[0]-h*cap/2,B[1]+h*cap/2
            unique = sorted({labels[g] for g in eligible})
            assert all(a<=E[i][0]<=E[i][1]<=b for i in unique)
            owner_mass = ss(size(E[i]) for i in unique)
            assert ss(I[g] for g in eligible)<=owner_mass<=b-a<=C_o[o]*cap
            diagnostics["positive_actual_owner_capacity_checks"]+=1
            return owner_mass

        for (e,B),path_row in path.items():
            row = by_owner[e,B]
            o = O[e]
            mu_parent_cell = mu(meet(A[labels[e]],B))
            a_e = mu_parent_cell/m[e]
            assert 0<a_e<=1
            prospective = T*mu_parent_cell
            path_b = {b:ss(w for g,w in path_row.items() if group(g)==b) for b in range(3)}
            cell_b = {b:ss(I[g]*mu(meet(C[e],C[g],B))/m[g]
                           for g in row if group(g)==b) for b in range(3)}
            path_weights = {b:w/ss(path_b.values()) for b,w in path_b.items()}
            cell_weights = {b:w/ss(cell_b.values()) for b,w in cell_b.items()}
            assert path_weights==cell_weights and ss(cell_weights.values())==1

            regular = [g for g in row if m[g]<=prospective]
            owners_inside(regular,B,prospective,o)
            paid_regular = ss(row[g] for g in regular)
            rows_paid_regular = ss(path_row[g] for g in path_row if m[g]/m[e]<=T*a_e)
            assert paid_regular==rows_paid_regular
            cap_regular = C_o[o]*eta_e[e]*T*I[e]*p[e]*a_e
            assert paid_regular<=cap_regular
            totals["unweighted_row_caps"] += cap_regular

            weighted = [g for g in row if s[e,g]<=prospective*cell_weights[group(g)]]
            paid_weighted = ss(row[g] for g in weighted)
            rows_paid_weighted = ss(path_row[g] for g in path_row
                                    if s[e,g]/m[e]<=T*a_e*path_weights[group(g)])
            assert paid_weighted==rows_paid_weighted
            for b in range(3):
                bin_eligible = [g for g in weighted if group(g)==b]
                if not bin_eligible:
                    continue
                minimum,maximum = min(m[g] for g in bin_eligible),max(m[g] for g in bin_eligible)
                assert maximum<=2*minimum
                owners_inside(bin_eligible,B,maximum,o)
                assert ss(I[g]/m[g] for g in bin_eligible)<=2*C_o[o]
                part = ss(row[g] for g in bin_eligible)
                assert part<=2*C_o[o]*T*cell_weights[b]*I[e]*p[e]*a_e
            cap_weighted = 2*C_o[o]*T*I[e]*p[e]*a_e
            assert paid_weighted<=cap_weighted
            totals["weighted_row_caps"] += cap_weighted
            totals["regular_paid"] += paid_regular
            totals["weighted_paid"] += paid_weighted
            regular_set,weighted_set = set(regular),set(weighted)
            totals["weighted_only"] += ss(row[g] for g in weighted_set-regular_set)
            totals["regular_only"] += ss(row[g] for g in regular_set-weighted_set)
            diagnostics["positive_price_parent_rows"] += 1
            split_weight_routes = [g for g in weighted_set-regular_set if cell_weights[group(g)]<1]
            if split_weight_routes and witness is None:
                g = max(split_weight_routes,key=row.get)
                witness = {"e":e,"g":g,"actual_price_cell":B,"e_octave":o,"g_subbin":group(g),
                           "a_e":a_e,"mu_Ae_intersect_B":mu_parent_cell,
                           "true_marked_edge_mu":s[e,g],"theta_eg":s[e,g]/m[g],
                           "g_physical_volume":m[g],"mass":row[g],"T":T,"weight":cell_weights[group(g)],
                           "actual_owner_E_g":E[labels[g]],
                           "strict_unweighted_cap":prospective,"weighted_overlap_cap":prospective*cell_weights[group(g)]}
        totals["regular_residual"] = Q-totals["regular_paid"]
        totals["weighted_residual"] = Q-totals["weighted_paid"]
        assert all(totals[k]>0 for k in ("regular_paid","regular_residual","weighted_paid","weighted_residual"))
        cap_regular_global = ss(C_o[O[e]]*eta_e[e]*T*I[e]*p[e] for e in keys)
        cap_weighted_global = ss(2*C_o[O[e]]*T*I[e]*p[e] for e in keys)
        assert totals["regular_paid"]<=totals["unweighted_row_caps"]<=cap_regular_global
        assert totals["weighted_paid"]<=totals["weighted_row_caps"]<=cap_weighted_global
        assert cap_regular_global<=max(C_o.values())*eta_test*T*Y
        assert cap_weighted_global<=2*max(C_o.values())*T*Y
        return {"width":width,"shift":shift,"T":T,"volume_capacity_constants":C_o,
                "eta_test":eta_test,"Y":Y,"totals":totals,"counts":diagnostics,
                "regular_global_cap":cap_regular_global,"weighted_global_cap":cap_weighted_global,
                "weighted_only_actual_route_witness":witness}

    def root_collision():
        totals = defaultdict(F)
        private_probes = ((F(-3),F(-1,2)),(F(1,4),F(5,2)))
        probabilities = {}
        for e in keys:
            if not p[e]:
                continue
            for slot,probe in enumerate(private_probes):
                conditional = {u:I[u]*mu(meet(overlap[e,u],probe))/(m[e]*m[u]*degree[e]*p[e])
                               for u in arm[e]}
                assert 0<=ss(conditional.values())<=1
                probabilities[e,slot] = conditional
        common_price_cells = 0
        hard_witness = None
        max_ratio = F(0)
        for a,b in prices:
            x = (a+b)/2
            weight = mu((a,b))
            refined = [mu((a,x)),mu((x,b))]
            assert sum(refined)==weight
            for octave in OCT:
                H_e = {e:I[e]/m[e] for e in keys if O[e]==octave and C[e][0]<x<C[e][1]}
                H = ss(H_e.values())
                if not H:
                    continue
                t_e = {e:ss(H_e[g] for g in arm[e] if g in H_e) for e in H_e}
                roots = {(e,g):p[e]*H_e[e]*H_e[g] for e in H_e
                         for g in arm[e] if g in H_e}
                if not roots:
                    continue
                common_price_cells += 1
                totals["true_single_peak_mass"] += weight*ss(roots.values())
                path = defaultdict(F)
                for (e,g),(j,k) in product(roots,repeat=2):
                    value = roots[e,g]*roots[j,k]/H**2
                    path[e,j] += value
                    totals["all_root_pairs"]+=weight*value
                    if K[e,j]>0:
                        totals["hard_root_pairs"]+=weight*value
                        if labels[g]!=labels[k]:
                            totals["hard_with_distinct_physical_old_small_ends"]+=weight*value
                        else:
                            totals["hard_with_same_physical_old_small_end"]+=weight*value
                for e,j in path:
                    correct = p[e]*p[j]*H_e[e]*H_e[j]*t_e[e]*t_e[j]/H**2
                    assert path[e,j]==correct
                    totals["measure_refined"]+=sum(refined)*correct
                    totals["incorrect_square_shared_price_weight"]+=weight**2*correct
                    totals["incorrect_square_after_refinement"]+=ss(w**2 for w in refined)*correct
                    if not K[e,j]:
                        continue
                    reference = p[e]*p[j]*H_e[e]*H_e[j]
                    ratio = t_e[e]*t_e[j]/H**2
                    assert 0<ratio<=1 and correct==reference*ratio
                    max_ratio=max(max_ratio,ratio)
                    totals["three_jump_reference"]+=weight*reference
                    # Sample each original other end and its private price independently.
                    left,right = probabilities[e,0],probabilities[j,1]
                    expanded = ss(correct*a*b for a,b in product(left.values(),right.values()))
                    assert expanded==correct*ss(left.values())*ss(right.values())
                    reference_probed = reference*ss(left.values())*ss(right.values())
                    actual_chain = F(0)
                    for u,vv in product(arm[e],arm[j]):
                        unmarked = (I[u]*I[e]*K[u,e])*(I[j]*K[e,j]/degree[e])*(I[vv]*K[j,vv]/degree[j])
                        x_factor = mu(meet(overlap[e,u],private_probes[0]))/s[e,u]
                        y_factor = weight/mu(overlap[e,j])
                        x_prime_factor = mu(meet(overlap[j,vv],private_probes[1]))/s[j,vv]
                        actual_chain += unmarked*x_factor*y_factor*x_prime_factor
                    assert weight*expanded<=actual_chain==weight*reference_probed
                    if hard_witness is None and expanded:
                        fresh = next(((g,k) for z,g in roots if z==e for z2,k in roots
                                      if z2==j and labels[g]!=labels[k]),None)
                        if fresh:
                            g,k = fresh
                            u = next(u for u,v in left.items() if v)
                            vv = next(u for u,v in right.items() if v)
                            atom = weight*roots[e,g]*roots[j,k]/H**2*left[u]*right[vv]
                            assert atom>0
                            hard_witness = {"octave_left":octave,"shared_true_price_atom":(a,b),
                                "shared_mu":weight,"middle_histories":[e,j],
                                "independently_reused_old_small_histories":[g,k],
                                "private_end_histories":[u,vv],
                                "private_true_price_intervals":[meet(overlap[e,u],private_probes[0]),
                                                               meet(overlap[j,vv],private_probes[1])],
                                "joint_atom_and_private_probes_mass":atom,
                                "all_old_small_ends_middle_domination_ratio":ratio}
                    totals["private_probes_true_root_pair"]+=weight*expanded
                    totals["private_probes_three_jump"]+=weight*reference_probed
        assert totals["true_single_peak_mass"]==Q
        assert hard_witness is not None
        assert 0<totals["hard_with_same_physical_old_small_end"]<totals["hard_root_pairs"]
        assert totals["hard_with_distinct_physical_old_small_ends"]+totals["hard_with_same_physical_old_small_end"]==totals["hard_root_pairs"]
        assert totals["measure_refined"]==totals["all_root_pairs"]
        assert totals["incorrect_square_after_refinement"]<totals["incorrect_square_shared_price_weight"]
        assert 0<totals["private_probes_true_root_pair"]<=totals["private_probes_three_jump"]
        return {"scope":"original true hard graph with only its peak restriction; fixed common price retains an octave and no common small label",
                "common_price_octave_atoms":common_price_cells,"independent_true_private_price_probes":private_probes,
                "factors":"r_y(e,g)=p(e)h_y(e)h_y(g) on old lower hard edges; divide each draw by the same H_y",
                "max_hard_middle_ratio":max_ratio,"true_distinct_old_ends_path_witness":hard_witness,
                "totals":totals}

    tests=[cell_case(width,shift,T) for width,shift,T in
           [(F(1,4),F(0),F(24)),(F(1,2),F(0),F(12)),(F(1,4),F(1,16),F(24))]]
    assert all(r["weighted_only_actual_route_witness"] is not None for r in tests)
    return {"old_original_true_peak_mass":Q,"cells":tests,"shared_price_root_collision":root_collision(),
            "scope":"frozen 12-parent 14-history actual 1D R774 price and owner model; no high-dimensional terminal masks",
            "relative_receiver_volume_subbins":"split each octave at 5D/4 and 3D/2",
            "diagnostic_parameters":"T selected so width times T equals 6; no asymptotic implication"}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model",type=Path,default=DEFAULT_MODEL)
    args=parser.parse_args()
    print(json.dumps({"python":sys.version.split()[0],"arithmetic":"Fraction","input_sha256":MODEL_HASH,
                      "command":"python -B cells776.py","certificate":check(load(args.model))},
                     sort_keys=True,indent=2,default=str))
