# R219：原来源权比联合正变差的接收几何

R218已核验并推送f0f0f27fb3f5f5e63aeda0af01594442511fbc5f。唯一主目标仍为任意正L1输入的一般n^(1/2+o(1))一致弱型上界。本轮不再优化尚未接入的weighted hardface核。R218外部完整冻结：/Users/zhengzhihao/Desktop/T/output/centered_cube_round218_20261016_final_checkpoint。

原行r=(ω,V,j,x,y,z,history)，外测度为1I1j Q^−1 p_y(x)h_R(x−z)aω dx β_V(dy)ν_V(dz)，保high及外2Λ。正交通内为∫Mρ0(v)(kv−ku)+Π_t(dv)Π_t(du)dt/t，Π_t=1Zt wtν/e_t；两份分母已包含不再除e²。M保原good×bad/mixed/FA/Ψ及当前未付正集。来源α_i=(b/cj)C(|yi−vi|/b)，C(r)=∫core max(h,φ)(a−r)da，wt=∏min(1,α_i/t)，kt=#α_i<t。原p、L、g、ρ0固定辅助t。tb4精确为δwvwu=wu²[−∂logt(wv/wu)]_+，不能改作physical L导数。

取预定L0=K√n、κ为既定mixed吸收参数，h0=L0J/p+K0/(κT)。R218已经以一份16ΛL0/(3K)WA支付0<ρ0(wt−h0)≤L0J/p，并包含R217旧PG支；本轮保持剩余ρ0(wt−h0)>L0J/p及原两端mixed，未消费负信用。求该实际剩余的εX+Cε√n polylog(n)WA预算或一个确实扩大已付覆盖、能以原真实dx回代的量化新不等式。不得用固定尺度/抽象row假设取代一般结论。

已证可用：common high/FIRST∫pβ≤Q，e_t≥e_g，one hard cap16/3，fixed J列∫Jνdx=||ν||，Q*=(K1+K2+J)/3来源容量≤Q；不可假设单独K1ν/K2ν≤Q。不可ν≤β，不可将ν坐标独立化或把自适应p对x当固定核归一。R170 signed identities可读但所有GG/反向/删除/suffix成本必须完整保留，负信用只一次。R218SE只控sqrtweighted物理面，其与原t无直接连接；TB保source-shell换元，Jacobian实际窗有界，但source-shell不等receiver面。

任务先筛准确量词后证明，不主要搜反例。Astra负责真实接收几何预算/direct_geometry.md；Sol辅助负责原sourcepair可用signed/source积分结构及有价回代/joint_variation.md，不重复Astra路线；Sol独审先核原目标与可能遗漏/audit.md，待主作者稿再读。数值Sol仅在明确待检命题后启动。主代理统一并写proof/report。所有人共享工作区，不改他人、无Git/无自增agent；只读所需原片段，完成交付停等。不编译PDF。

成功标准是新估计通过独审并给真实来源/接收付款；若只有条件结论，显式全部条件且不冒称一般闭合。不把已知恒等式重新命名算新结果。每个数值方案先写初探/原模型压力/扩大范围，实际本机运行方为证据。结束后独立归档commit/push。
