# R219 独立审查

## 作者稿前：准确目标、真实可用结构与问题清单

先读R219 task_contract.md，再读R218冻结traffic_bridge.md；窄读原R128 RT1–6、R170 soft_threshold_energy式2–8及source_pair_tool_contract仅SP3的冻结/能量接口。未读本轮direct_geometry或joint_variation作者新稿，不预认作者结论。旧文件中其它历史假设（尤其ν≤β）不移入本轮。

### 1. 唯一目标与准确未付量

目标仍是任意正L1输入的一般n^(1/2+o(1))一致弱型预算；本轮应取得原剩余的εX+Cε√n polylog(n)WA价，或确能扩大已付原覆盖、按真实dx回代的新定量不等式。固定尺度、有限clock表或额外抽象row条件只能登记条件结论。

原外行r=(ω,V,j,x,y,z,history)保

    1I 1_j Q^−1 p_y(x) h_R(x−z) aω dx β_V(dy) ν_V(dz)

及high、EΣV,j、外2Λ。内部是Mρ0(v)(kv−ku)+ Π_t(dv)Π_t(du) dlogt；两份Π已含两份e_t^−1，不再除e_t²。M包含原target good×bad、mixed两端、FA、Ψ和当前未付支，ρ0为R211合法替换后的原baseline，不重算依原ρ产生的门/history。

预定L0=K√n与既定κ不事后自由更改。h0=L0J/p+K0/(κT)，HJ=L0J/p。R218已按一份16ΛL0/(3K)WA支付0<ρ0(wt−h0)≤HJ并包含R217旧PG；当前正剩余准确为

    ρ0(v)(wt(v)−h0(v))>HJ(v),

且仍有两端wt>h0、原全部门。ρ0=0先零。等号属于已付支，不能在剩余中重复收价；负余额原位一次。

### 2. 两种冻结方向不能混同

固定完整r后，当前s,L,R,g,T、K1/K2/J/K0、Δ=wτ−wh、α0、ρ0固定辅助t；w_t、Z_t、e_t、Π_t、k_t与部分实际gate随t变化。固定(ω,V,j,y,t)时原ν、Z_t、w_t、e_t、Π_t独立x与hard z，但terminal g(x)、good/bad、ρ0、capture、p和当前selector不因此独立x。任何交换积分须按此准确方向用Tonelli，不能把Π_g当固定Π_t。

原target与bad是terminal支持的一部分；future-deleted源仍留在相应时刻e_t内。删除不改变单来源w_t，但改变Z_t/e_t并造成归一化跳。source坐标不可替换成receiver x；换y、v或u会改变α_i、Z/e、capture及good/bad，不存在免费对称转置。

### 3. source-pair的精确结构与不可免费删除的费用

原α_i=(b/cj)C(|yi−vi|/b)、wt=∏min(1,α_i/t)、kt=#α_i<t，C来自F=max(h,φ)的core积分，F不归一。wt连续、局部绝对连续，−∂logt wt=ktwt a.e.；故

    δwvwu=wu²[−∂logt(wv/wu)]+.

代回原正量时仍有Mρ0·1Zv1Zu·wu²/e_t²，不能因ratio是BV就直接丢成端点差。kv−ku可随阈值排序改号，完整参数必须来自同一y与两实际来源；不先假定共同source排序或免费GG单调性。

本机Python/Fraction对kv,ku=(5,2),(2,5),(3,3)、wv=2/7、wu=3/5实核该身份，正值18/35与两组0均准确；只核代数符号，不认证物理输入或一般价格。

无删除段Π概率漂移为∂logt(dΠ/dν)=−(k−EΠk)dΠ/dν，pair漂移为2EΠk−kv−ku，均不是差的正部。若引入方差/能量，原R135/SP3只给含阈值注入及删除通量的row预算；没有免费e_g/||ν||下界，log(eτ/e_g)与累计删除须付。逐行根阶或O(n)能量乘原体积槽并不自动成为εX+根阶WA。

### 4. 直接接收几何可用的正结构

同一good给p wg(v)≤K(K1+K2+J)/3；bad给严格反向门。原两mixed与capture支持必须联合，不能只保一个source的必要条件后声称整个pair稀少。深层slack给更强的真实低J条件

    p wt > L0J(1+1/ρ0)+pK0/(κT),

但它是对J/p的上界，不能反向得到需要的sqrt(J/p)支配或小后验占用。α0=DQ/QJ、QJ=∫Jν以及Δ、wg、K0都来自同一实际行；不能分别极值化、给每个v另选α0或丢掉QJ分母。

固定block J=P1,b有∫Jν dx=||ν||，是现成可积receiver核。若用χJ=J/(K1+K2+J)，同good确有p wg χJ≤KJ/3；但χJ可小，整份交通不能免费当J-share。R170 filtered边界身份能保这样的固定终端测试，完整GG/GE、反向、suffix与删除成本仍须原样回代。

R218 source-shell变换在真实窗ξ=cjt/b∈[a/b,cj²]⊂[1/2,1]有界Jacobian，是可用实际几何；它只表达两来源相对y的位置占用，不把x放到physical L面。R218SE的weighted hardface工具尚无该原交通映射，本轮不能再借名称相近跳步。

### 5. signed路线的准确账本

可用R170式8的终端测试F_t=Π_tA及完整covariance身份，但它包含：原端点、全部删除上跳、GG与future-deleted源GE项、已消费suffix补项、反向capture储备及正门亏损。负项本来不带正项FA或ρ0门，不能跟随新正域随意剪裁。若把剩余slack域作为新的t依赖测试或gate，需要其导数/跳/入口退出费用；若分多个不连通时间段，必须列每段端点。不能以“正门≤1”在signed负项上同向上放。

同参数α0提供的反向储备可在原剩余signed泛函内使用，但只能消费一次。R211修复槽已付，不再用于整baseline。此前已付suffix或删除负信用不能回加后又视作免费负量；所有无穷极限先在合法有限截断上完成，不能写∞−∞。

### 6. 真正的来源/receiver回代要求

现有共同high/FIRST接口是固定同一x,V,j先用

    1_high/e_g(y)≤p_y/(2KQ),  ∫p_yβ(dy)≤Q,

从而∫1_high β/e_g≤1/(2K)。它只能在其余核已与y无关或有真实联合列证明后使用；若正核仍依y，不能把该帽逐行复制。Q*=(K1+K2+J)/3源容量给∫(K1+K2)ν≤3Q−QJ≤3Q；不假设单独K1ν、K2ν≤Q，更不能把Q dx体积价当固定J的WA价。

固定参数p对x归一，不授予自适应s(x),L(x)的同一归一；source fixedpair衰减不授予ν的坐标独立或来源列帽。凡新核需明确输入/输出测度、两侧source边缘、真实dx以及全部依x参数的费用。只能用Wν≤WA，不用ν≤β或Wν≤Wβ。

先固定hard来源z作所有仍依z的capture/history推导，取得独立上界后才用一次16/3；外2Λ一次。uniquej保至右端独立j才合并；不同独立窗口按各自真实WA父账，不多窗复制一份总预算。若删uniquej或取time/scale菜单，须显式支付相应真实计数/长度。

## 待作者准确命题

当前独审已列真实可用结构和费用问题，未读本轮作者新稿。后续只对direct_geometry与joint_variation给出的准确新估计核其量词、原门、源权/接收回代及是否真改善原已付覆盖；不以恢复旧恒等式、条件改名或重复长反例计新成果。

## 附加旧工具量词窄核：R135信道与双侧核预算

已窄读R135冻结source_channel.md SC1–4。其根阶结论严格使用来源中心y的Lebesgue信道测度e_t(y)dy/z_t^n；proof中固定v后w(y,v)dy/z_t^n的乘积结构合法，但不是原β(dy)或receiver dx。SC4本身明确未连接RT1。故即使本轮复用该旧几何能量，仍须在原p、β、hard源、high/history、真实x积分下证明测度转移与全部密度比/总量预算。不能把“删源任意且坐标product”误读为原Π来源独立或β信道已经付费。

若本轮构造F05型正核，基础双侧Schur/Cauchy充分方向可直接核验，但必须给原input/output底测度、两个原source边缘及真实x/time/j/selector列预算。row归一或固定尺度overlap仅是其中一边；不能将依y的α0、e、capture、history抽出转置积分，再把假对称核的column赋给原核。保留hard z作为第三来源标签可以是合法路线，仍须说明其边缘和一次hard帽的位置，不能以三源名称替代实际双侧证书。

## 原strictsoft方向的即时资格核验

针对主代理提出的可能符号误读，已实际回读master GENERAL_CURRENT_REDUCTION.md §1、R117 TASK_CONTEXT.md第5行及R128后续继承审查。原门一致为

    s>1−2^(−1/n)>log2/(2n)，

它是s的O(1/n)下界，允许s很小；不是s≥2^(−1/n)，不能推出n(1−s)≤log2。R128明确该门属于原完整history，不能通过后续capture或删source重选。

若额外交近1支s≥2^(−1/n)，令ε0=1−2^(−1/n)、s*=1/(1+ε0)，则确有

    f_s≤φ+ε0h=(1+ε0)f_s*, (1+ε0)^n≤exp(nε0)≤2。

这提供该额外软条带的固定soft核包络，不赋其余soft补域免费资格。fixed s*的hard尺度面总质量n(1−s*)≤log2，smooth尺度BV可在核验φ的有限scale Fisher后估计；但kernel/端点包络不自动支付原δ双Π、删除、signed/suffix或多段端点/uniquej费用。是否已有历史软条带工具也须窄核，不将该候选直接登记为新增一般覆盖。当前仅核准确适用方向，不预认作者新稿或整条带原交通付款。

## 作者稿后：direct_geometry与joint_variation独审

已完整通读两稿，按先前检查点核验。

DG1原硬门已实际窄核R128 proof.md第16485行及第1542行附近：B=1_{R≤L}1_{Q_R(x)}(v)，闭边界；ρ0>0只在R≤L时排Q_R(v)，R>L无排除，不能扩大成排Q_L或Q_Lplus。DG2–4通过：两密度各自归一及L∞给1/max(A,R)，F径向包络与硬区间扩至b给bC/(AR)；A≥L再用原min(L,R)≤cjg是上向关系，得到(cj/g)ω_g，确不需γ^n。第三目标腿J取σ=1、A=b，非同s。张量化和同一hard cube内Cauchy保(cj/g)^n密度单位，w_g(v,z)不能当以y为中心的原后验。

DG5–6精确三来源表达通过：B扣除对应hard z-cube与v-cube同R交集，是两个坐标乘积之差，非逐坐标差乘积。b^−n、1/[r√(λa)]及D_i归一后(cj/g)^n的尺度单位正确；R≤L且z=v时扣除全体，确为0。未预认D_i≤1或一般归一H≤1。

DG7–9通过：good先给p≤√[K/(3wg)]√p√(K1+K2+J)，再以根和上放；其余δ、两个e分母、capture/mask与history完整保。只有所有物理参数独立x固定才可积分使用DG5/6/9；自适应行不能免费套固定包络。DG10的fullsource bar e_g(a)=∫wg(a,z)ν(dz)仅满足e_g(y)≤bar e_g(y)，不是可反向上控的相同量；原hard z不能无依据限制到Z_g，也无以v为中心的后验归一。来源列、u端收益、receiver选择器及原δ均明确未付，两稿没有新登记原付款。

JV1–2通过：A=1_G必须取全部terminal G，不能收缩成capture eligible子集。完整signed行保正门η与ρ0，反向负项不附这些正门；GG因测试1−1恒为0，GE无免费符号。−F′=Cov(1G,k)，逐对展开及suffix补项给JV2各项准确符号；删除仅在Z_g外，ΔF≥0但不可省掉。新t依赖slack门留在R_loss，未以变测试产生无账端点。JV3保终端比R、原fullSv与y依赖列，未拿无门包络支付边界；ρ0到ΓχJ的最小费用esssupρ0Sv/J是该点态接口的准确损失，不被夸作所有signed势的必要障碍。

JV4适用域和硬费用通过：s_n=1−4^(−1/n)严格大于原1−2^(−1/n)，hard质量=(1−s_n)^n=1/4。∫sup_{L∈[a,b]}h_L=1+nlog(b/a)精确，故合法soft内的无门尺度包络确有线性下界；它不否定有原gate/capture的预算，也非FULL反例。该稿明确是旧一般test机制的准确选择，未将GG消失登记为新付款。

## triple_probe源码静审与证据边界

已读triple_probe.py/json说明与numeric_notes：b=L=R=cj=g=1、同soft双腿的单坐标有限hard区间重叠，正是D型候选的特殊边界探路。E3φ分段、F的E4原函数与core连续拼接正确；C独立GL及原函数双算，按hard/φ端点和中心切片，所有积分域有限，无漏无限尾。三阶段36配置两精度，JSON无runtime/output路径。H≤1只是有限菜单观察，不被声明为定理；同soft特例不覆盖J的σ=1第三腿或不同尺度。已有条款明确不认证原比例带/FULL/一般n阶。独审已启动完整移位复跑，待完成后绑定字节与摘要。

## triple_probe实际复跑与扩尺度数值静审

独审已实际完整重跑triple_probe.py至/tmp/r219_audit_triple_probe.json，36配置、72精度运行全部完成，完整JSON与作者当前文件逐字节一致，script_sha256匹配源码。最大H=0.9950545831598250604352256974875009358727，最大低高H差2.673802203588977e−11，高阶C独立双算差最大2.56268423042469e−14，与notes一致。此有限结果不证明候选H≤1。

已静审triple_scale_probe.py/json及notes新增节。I准确含hard_R的1/R和p/K_A两密度的尺度，H=(g/cj)I/√wg匹配DG6；三腿分别K_L同s、K_Lplus同s、J的soft1，原界中无漏第三腿。Fraction平方比较给当前比例索引；所用非平凡比例没有半开端点歧义，L=R对应j=0。s=原下门+.01或.8在菜单中严格合法，但只是核参数，未认证原n/history或非空far窗/FULL。B0保R≤L时的两个n乘积差，R>L无扣除；z=v同区间复用积分给精确零，不误把cap差写成I^n。积分在真实hard源有限区间内，按两核hard/φ端点和中心切片，不漏无限尾。普通25/40dps GL仍非有向区间证明，144运行未发现H>1不授予D_i≤1。独审已启动完整移位复跑，待结果绑定。

## 扩尺度完整实际重放与新标量命题先筛

独审已完成triple_scale_probe.py全部72配置、144精度运行，输出/tmp/r219_audit_triple_scale_probe.json与当前作者JSON逐字节一致，script_sha256匹配，三个阶段各24配置且无candidate failure。最大H=0.8537651670825726540380770257467752060371与notes一致。这里只核有限物理kernel候选，不把它升级为全DG6定理。

随后收到主代理给出的准确新命题：对同尺度、同soft f_s及任意d,z，(∫_{z−.5}^{z+.5}√[f_s(x)f_s(x−d)]dx)^2≤C(d)。在读新scalar作者稿之前先独立筛查：它确需任意窗口，不限居中；s=0由三个interval交长及C≥(1−|d|)+可证。s=1可先用w(a)w(b)≤w(a+b)（同指数混合率的正相关）和三角不等式，得到φ(x)φ(x−d)≤(h*φ)(d)≤C(d)，再用窗口长1给结论。0<s<1不能由两端线性插值得出，因为局部affinity对混合参数凹；也不能用全线f_s*f_s替代局部窗口。一般s的实际作者证明尚待读取，不提前认证。即使该命题成立，其量词仍仅同尺度同soft，不自动授A≠L或J的第三腿、三来源列或原δ/selector付款。

## scalar_overlap解析引理与独立soft扩展审核

已完整读scalar_overlap.md原稿并核最终独立soft修订。SO3共同指数率的Chebyshev方向准确：r→φ_r(x)、φ_r(y)单调，双积分差乘积非负；SO4在同r下用三角不等式，u,v卷积给h*h*e_r(x+y)。Tonelli于是φ(x)φ(y)≤V(x+y)，取y=d−x并用偶性给φ(x)φ(x−d)≤V(d)。单窗口长1的Cauchy产生N²≤∫I fs fσ，再对hh、hφ、φh、φφ分别上界A、V、V、V，得到

    N_sσ²≤aA+(1−a)V≤C,  a=(1−s)(1−σ).

所有窗口位置均覆盖，不使用midpoint最大假设或对s的错误端点插值。C>0、系数非负且和1，SO2除法和SO8的gap合法。独立soft扩展只需该四项展开，确包含同尺度σ=1的J腿；已用数值仍为σ=s子域，不伪报新积分。SO9是固定同尺度的真正逐坐标常数1张量界，无C0^n损失；B=0进一步减小值或保DG乘积差，但不授异尺度/selector/原source付款。

## 全位移定量gap的准确命题预审

收到父级新gap候选后独立核验。令M=φ(0)<1（φ偶递减且0处积分严格小于1）、c=1−M。C−V=∫core∩(d+core)(1−φ(u−d))du≥cA；T=C−A≥0。因此

    2C−A−V = T+(C−V)≥T+cA=cC+M T≥cC。

SO的G=a(C−A)+(1−a)(C−V)≥min(a,1−a)(2C−A−V)，故G/C≥c min(a,1−a)。准确推出N/√C≤√[1−c min(a,1−a)]及固定同soft参数n维tensor≤exp[−nc min(a,1−a)/2]。当|d|≥1，A=0且C=V（端点交集零长度），更强N/√C≤√(1−a)。a=0或1时uniform-gap退化，特别J腿σ=1给a=0，不能由此虚构正gap；常数1界仍合法。未拓尺度或原来源价格。待父级将此命题纳入最终作者稿后再核绑定。

## scalar_bound与迁移driver审核

scalar_bound_checks.py静审通过：E4的φ原函数ψ、V=h*φ、A硬交长以及C=V+core交集上(1−φ)修正准确。36个N仅复用相邻triple_probe.json最高精度值，在80dps核SO同soft强式；10个解析端点不做新积分。它明确非独立N积分证书、不据浮点比较证明定理。独审已实际复跑至/tmp/r219_audit_scalar_bound_checks.json，与当前作者JSON逐字节一致，script_sha256及input_sha256均匹配，36输入+10端点计数正确。

reproduce.py静审通过：最终manifest前后验证、三脚本迁移、包外新输出目录、完整JSON字节比较后才写成功回执。相邻输入triple_probe.json确复制到临时脚本目录；第一个完整重放已验证字节一致，再由scalar脚本读取同字节参考输入，链条合法。运行时间仅回执不入需相同的证据JSON。当前report还是新增解析引理整合状态，既有范围叙述准确；待最终SO/gap及proof/report完整绑定，不预报整包driver或Git动作通过。

## 最终SO量化gap、1260 Fraction与report更新

已实际完整核scalar_overlap最终SO10–14：φ_r导数、最大值M=φ0及c的正积分正确；C=A+T和C−V的交集精确分解保所有位移，继而uniform min系数gap与k个远位移的乘积式正确。它们明确a端点退化，σ=1的J腿不虚构正衰减；只覆盖固定同尺度。report更新准确登记该解析工具，并继续保原来源、自适应与score/negative缺口，不将数值候选代作异尺度定理。

scalar_bound_checks最终新增1260 Fraction网格已静审并重新实际重放：5个M×4个A×3个T×3个core_phi×7个a，逐格精确保留（值重合也保留）。core_phi∈[0,MA]、C=A+T、V=T+core_phi，检C−V≥(1−M)A及gap下界；C=0行没有作非法比值，全部是抽象代数而非物理数据。最终JSON SHA256为c64a62b1d7b1e0359dea50e7b228ac8e26786d3a073f7af731d1734b221a1aab，独审新输出与其逐字节一致，script_sha256及相邻triple_probe input_sha256均匹配。该状态替代先前未含1260网格的scalar JSON绑定；36复用积分与10解析端点仍保，不伪报新增物理积分。

## 详细proof终审与最终冻结

已按三段通读最终proof.tex.txt全部726行，实际SHA256为35a83e532cdb866fb7c22f46acc31058e396b542eebe86eba90105b6cbcfa0b4，与主代理冻结值一致。43个label无重复、无未定义引用，begin/end环境计数平衡；eq:exacttriple与归一式均为正确的\ind，未检出裸ind。未编译PDF。

最终整合已准确保eligible分段及QJ零支，α0不在零分母行定义；B=1_{R≤L}1_QR闭门与其乘积差、b^−n/(cj/g)^n尺度单位、K_L/K_Lplus/J独立soft取值、原outerQ和两份posterior分母完整。SO独立双soft的全位移常数M/c、端点/J腿gap退化、k个远位移分支及仅L=R=A=b,cj=1处接DG6均与经审证明一致，未把它扩成一般异尺度D_i≤1。完整good上放确逐点可用于x自适应参数；固定receiver积分不免费授selector包络。fullsource bar e_g与删除后e_g方向准确，硬来源不能移至Z_g。JV保全部terminal G、GE/suffix/删除/边界/反向费用，原负信用一次。

report新增SO与gap结论、剩余来源/尺度费用及数值用途准确；reproduce.py相邻输入迁移和前后manifest/完整JSON比较流程静审通过。三套当前最终JSON均再次确认源码SHA绑定正确，并与独审完整实际移位重放结果逐字节一致；scalar最终含1260 Fraction网格的绑定以本文件上节c64a62b1…输出为准，不沿用此前无网格版本。普通多精度求积、给定参数索引或抽象代数网格均不被当作区间、FULL、一般来源或维数阶证明。

本轮独审未留数学阻断项。认证的新解析内容是固定物理参数三来源公式、同尺度独立soft任意窗口的常数一及定量gap；尚未认证新的原正交通付款。一般任意正L1根阶弱型目标仍未闭合，实际δ双来源、bad端收益、自适应receiver、fullsource列与全部时窗/history费用仍需共同预算，R218已付带及负账不重领。

本audit在最终manifest生成前冻结。后续主代理的整包迁移driver、manifest前后核验、外部备份及commit/push状态只由轮次README/包外回执记录；本文件不提前宣称这些尚未执行的动作通过，也不再为回执改写而破坏最终清单。
