#!/usr/bin/env python3
"""Actual proportional scale index and three physical kernel legs; not FULL."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent
NODES={}
REFINE_FAILURE=False

def phi(x):
    x=abs(x);h=mp.mpf('.5')
    def E3(t):return mp.mpf('.5') if not t else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
    return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def fs(x,s):return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi(x)
def primitiveF(x):
    sg=mp.sign(x);t=abs(x);h=mp.mpf('.5')
    return x if t<=h else sg*(h-mp.expint(4,t-h)+mp.expint(4,t+h)+mp.mpf(1)/3-mp.expint(4,1))
def rat(x):return f'{x.numerator}/{x.denominator}'
def index(n,L,R):
    gamma=F(n+1,n);q=min(L,R)**2;j=0
    while gamma**(-2*(j+1))*L*R>q:j+=1
    lower=gamma**(-2*(j+1))*L*R;upper=gamma**(-2*j)*L*R
    assert lower<=q<=upper
    return j,gamma**(-j),{'gamma':rat(gamma),'j':j,'cj':rat(gamma**(-j)),'min_L_R_squared':rat(q),'lower_squared_bound':rat(lower),'upper_squared_bound':rat(upper),'lower_le_min_squared_le_upper':True}
def calc(cfg,dps,degree):
  with mp.workdps(dps):
    n,Lstr,Rstr,schoice,vstr,zstr,leg=cfg;Lf,Rf=F(Lstr),F(Rstr);j,cjf,cert=index(n,Lf,Rf);m=lambda f:mp.mpf(f.numerator)/f.denominator
    L,R,cj=map(m,(Lf,Rf,cjf));g=mp.sqrt(L*R);gamma=mp.mpf(n+1)/n;gate=1-mp.power(2,-mp.mpf(1)/n);s=gate+mp.mpf('.01') if schoice=='lower_gate_plus_.01' else mp.mpf('.8');v,z=map(mp.mpf,(vstr,zstr));A=L if leg=='K_L' else min(1,gamma*L) if leg=='K_Lplus' else mp.mpf(1);soft=s if leg!='J' else mp.mpf(1)
    assert gate<s<1
    if (dps,degree) not in NODES:NODES[dps,degree]=mp.gauss_quadrature(degree,'legendre')
    nodes,weights=NODES[dps,degree];lo=z-R/2;hi=z+R/2;boundaries=[-L/2,L/2,v-A/2,v+A/2,mp.mpf(0),v]
    def integ(lower,upper):
      if upper<=lower:return mp.mpf(0),[]
      cuts=sorted(set([lower,upper]+[x for x in boundaries if lower<x<upper]));total=mp.mpf(0)
      for a,b in zip(cuts,cuts[1:]):
        mid=(a+b)/2;half=(b-a)/2;total+=half*sum(w*mp.sqrt(fs((mid+half*q)/L,s)/L*fs((mid+half*q-v)/A,soft)/A) for q,w in zip(nodes,weights))
      return total/R,cuts
    I,cuts=integ(lo,hi);caplo=max(lo,v-R/2);caphi=min(hi,v+R/2)
    if caplo==lo and caphi==hi:Icap,capcuts=I,cuts
    else:Icap,capcuts=integ(caplo,caphi)
    C=primitiveF(mp.mpf('.5')-abs(v))-primitiveF(-mp.mpf('.5')-abs(v));wg=min(1,C/(cj*g));H=g/cj*I/mp.sqrt(wg);removed=R<=L;product=I**n;capproduct=Icap**n;B0=product-capproduct if removed else product
    assert B0>=0
    vals={'L':L,'R':R,'g':g,'s_lower_gate':gate,'s':s,'v':v,'z':z,'A':A,'leg_soft':soft,'C_abs_v':C,'w_g':wg,'g_over_cj':g/cj,'I_normalized_hard_R':I,'Icap_normalized_intersection':Icap,'H':H,'I_power_n':product,'Icap_power_n':capproduct,'B0_same_coordinate_product_difference':B0}
    return {'n':n,'s_choice':schoice,'leg':leg,'dps':dps,'degree':degree,'actual_index_certificate':cert,'values':{k:mp.nstr(x,dps) for k,x in vals.items()},'H_le_one_numerical':H<=1,'B0_exclusion_active_R_le_L':removed,'I_cuts':[mp.nstr(x,dps) for x in cuts],'Icap_cuts':[mp.nstr(x,dps) for x in capcuts]}
def main(output):
    stages=[];firstfailure=None
    for name,scales in [('initial',[(8,'1','.5'),(8,'.5','1')]),('stress',[(32,'.75','1'),(32,'1','.75')]),('expanded',[(128,'.5','.5'),(128,'1','1')])]:
      rows=[]
      for n,L,R in scales:
       for s in ('lower_gate_plus_.01','.8'):
        for v,z in [('.5','.25'),('2','2')]:
         for leg in ('K_L','K_Lplus','J'):
          cfg=(n,L,R,s,v,z,leg);vals=[calc(cfg,p,deg) for p,deg in ((25,48),(40,96))]
          with mp.workdps(50):diff=mp.nstr(abs(mp.mpf(vals[0]['values']['H'])-mp.mpf(vals[1]['values']['H'])),30)
          row={'config':list(cfg),'precision_runs':vals,'H_low_high_abs_difference':diff};rows.append(row)
          if firstfailure is None and any(not x['H_le_one_numerical'] for x in vals):firstfailure=list(cfg);break
         if firstfailure:break
        if firstfailure:break
       if firstfailure:break
      stages.append({'stage':name,'cases':rows});print(name,len(rows),'firstfailure',firstfailure,flush=True)
      if firstfailure:break
    refinements=[calc(tuple(firstfailure),p,deg) for p,deg in ((60,192),(80,384))] if firstfailure and REFINE_FAILURE else []
    rows=[r for st in stages for r in st['cases']]
    with mp.workdps(50):maxrow=max(rows,key=lambda r:mp.mpf(r['precision_runs'][-1]['values']['H']))
    result={'schema':'R219_triple_scale_kernel_probe_v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'complete_planned_grid':firstfailure is None,'config_count':len(rows),'first_failure_config':firstfailure,'failure_refinements':refinements,'stages':stages,'maximum_H_config':maxrow['config'],'maximum_H':maxrow['precision_runs'][-1]['values']['H'],'scope':['Only kernel candidate; actual j/minratio interval is certified by rational squared bounds.','hard_R source is normalized dx/R. Three legs are K_L,K_min(1,gamma L) at same s and J at soft1.','B0 exact tensor product expression is a finite numerical diagnostic, not a source/full budget or actual arbitrary L1 input.','Ordinary quadrature without directed interval rounding; no FULL counterexample or general dimension-order fit.','All integration domains are bounded hard-source intervals; no infinite tails omitted.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'triple_scale_probe.json');args=ap.parse_args();main(args.output)
