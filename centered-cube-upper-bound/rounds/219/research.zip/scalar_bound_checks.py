#!/usr/bin/env python3
"""Self-contained E4 scalar U implementation, bound to neighboring triple_probe.json."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent

def psi(x):
    sg=mp.sign(x);t=abs(x);h=mp.mpf('.5')
    val=t-mp.expint(4,h-t)+mp.expint(4,h+t) if t<=h else h-mp.expint(4,t-h)+mp.expint(4,t+h)
    return sg*val

def values(s,d):
    h=mp.mpf('.5');V=psi(h-d)-psi(-h-d);overlap=max(1-abs(d),mp.mpf(0));lo=max(-h,d-h);hi=min(h,d+h)
    correction=(hi-lo)-(psi(hi-d)-psi(lo-d)) if hi>lo else mp.mpf(0)
    C=V+correction;U=(1-s)**2*overlap+(2*s-s*s)*V
    return V,overlap,correction,U,C

def abstract_fraction_checks():
    def rat(x):return f'{x.numerator}/{x.denominator}'
    rows=[]
    for M in (F(0),F(1,4),F(1,2),F(3,4),F(99,100)):
     for A in (F(0),F(1,4),F(1,2),F(1)):
      for T in (F(0),F(1,10),F(1)):
       for core_phi in (F(0),M*A/2,M*A):
        for a in (F(0),F(1,100),F(1,4),F(1,2),F(3,4),F(99,100),F(1)):
         C=A+T;V=T+core_phi;gap=a*(C-A)+(1-a)*(C-V);lower=min(a,1-a)*(1-M)*C
         checks={'M_lt_one':M<1,'T_nonnegative':T>=0,'core_phi_between_zero_and_MA':0<=core_phi<=M*A,'C_minus_V_ge_one_minus_M_times_A':C-V>=(1-M)*A,'gap_ge_lower':gap>=lower}
         assert all(checks.values())
         values={'M':M,'A':A,'T':T,'core_phi':core_phi,'a':a,'C':C,'V':V,'gap_G':gap,'lower_min_a_one_minus_a_times_one_minus_M_C':lower,'slack':gap-lower}
         rows.append({'values':{k:rat(v) for k,v in values.items()},'checks':checks})
    assert len(rows)==1260
    return {'case_count':len(rows),'arithmetic':'exact fractions, grid entries retained even if values coincide','cases':rows,'scope':'Abstract algebra implementation only; not physical kernel data or a general original budget certificate.'}

def main(output):
    inp=HERE/'triple_probe.json';raw=inp.read_bytes();data=json.loads(raw);rows=[];endpoints=[]
    with mp.workdps(80):
      for stage in data['stages']:
       for case in stage['cases']:
        source=max(case['precision_runs'],key=lambda r:r['dps']);s,d=map(mp.mpf,(source['s'],source['d']));N=mp.mpf(source['numerator']);V,overlap,corr,U,C=values(s,d);N2=N*N
        checks={'N_squared_le_U_numerical':N2<=U,'U_le_C_numerical':U<=C,'V_nonnegative':V>=0,'hard_core_correction_nonnegative':corr>=0}
        assert all(checks.values()),(case['config'],checks)
        vals={'N_from_input':N,'N_squared':N2,'V_E4':V,'hard_overlap_length':overlap,'hard_core_correction':corr,'U':U,'C_recomputed':C,'U_minus_N_squared':U-N2,'C_minus_U':C-U,'C_recomputed_minus_input_abs':abs(C-mp.mpf(source['C_E4_primitive']))}
        rows.append({'input_stage':stage['stage'],'config':case['config'],'source_dps':source['dps'],'analytic_dps':80,'values':{k:mp.nstr(v,80) for k,v in vals.items()},'checks':checks})
      for s0 in ('0','1'):
       for d0 in ('0','.5','1','4','8'):
        s,d=map(mp.mpf,(s0,d0));V,overlap,corr,U,C=values(s,d);assert U<=C
        endpoints.append({'s':s0,'d':d0,'dps':80,'V_E4':mp.nstr(V,80),'U':mp.nstr(U,80),'C':mp.nstr(C,80),'C_minus_U':mp.nstr(C-U,80),'U_le_C_numerical':True,'exact_structural_equality':(s0=='0' and d0=='0') or (s0=='1' and d>=1)})
    result={'schema':'R219_scalar_U_bound_checks_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(raw).hexdigest(),'input_filename':'triple_probe.json','input_schema':data['schema'],'mpmath_version':mp.__version__,'input_high_precision_config_count':len(rows),'input_integrals_reused_not_rerun':True,'checks':rows,'endpoint_analytic_checks':endpoints,'abstract_fraction_gap_checks':abstract_fraction_checks(),'scope':['Formula implementation verification using neighboring triple_probe.json; migrate that input beside this script.','All U,V,C computations self-contained via E4; no new numerical integration.','N is an existing ordinary quadrature value, not a directed interval enclosure; checks do not independently prove N^2<=U.','No general-n order fit, actual arbitrary L1 input, original traffic, or FULL assertion.','1260 new Fraction cases check abstract gap algebra only, not a physical kernel or general original budget.']}
    output.write_text(json.dumps(result,indent=2)+'\n');print('complete',len(rows),'input cases,',len(endpoints),'analytic endpoint cases, and 1260 exact Fraction gap cases')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'scalar_bound_checks.json');args=ap.parse_args();main(args.output)
