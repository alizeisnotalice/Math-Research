#!/usr/bin/env python3
"""One-coordinate three-source physical overlap candidate probe, not FULL."""
import argparse,hashlib,json
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent

def phi(x):
    x=abs(x);h=mp.mpf('.5')
    def E3(t):return mp.mpf('.5') if not t else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
    return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def fs(x,s):return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi(x)
def primitiveF(x):
    sign=mp.sign(x);t=abs(x);h=mp.mpf('.5')
    if t<=h:return x
    psi=h-mp.expint(4,t-h)+mp.expint(4,t+h)
    return sign*(psi+mp.mpf(1)/3-mp.expint(4,1))
def calc(cfg,dps,degree):
  with mp.workdps(dps):
    s,d,e=map(mp.mpf,cfg);half=mp.mpf('.5');lo=e-half;hi=e+half;nodes,weights=mp.gauss_quadrature(degree,'legendre')
    def integrate(fun,lower,upper,cuts):
      cuts=sorted(set([lower,upper]+[x for x in cuts if lower<x<upper]));total=mp.mpf(0)
      for a,b in zip(cuts,cuts[1:]):
        mid=(a+b)/2;hw=(b-a)/2;total+=hw*sum(w*fun(mid+hw*z) for z,w in zip(nodes,weights))
      return total,cuts
    num,cuts=integrate(lambda x:mp.sqrt(fs(x,s)*fs(x-d,s)),lo,hi,[-half,half,d-half,d+half,mp.mpf(0),d])
    Cquad,Ccuts=integrate(lambda u:1 if abs(u-d)<=half else phi(u-d),-half,half,[d-half,d+half,d,mp.mpf(0)])
    Cexact=primitiveF(half-d)-primitiveF(-half-d);H=num/mp.sqrt(Cexact);assert Cexact>0 and num>=0
    return {'s':cfg[0],'d':cfg[1],'e':cfg[2],'dps':dps,'degree':degree,'numerator':mp.nstr(num,dps),'C_direct_quad':mp.nstr(Cquad,dps),'C_E4_primitive':mp.nstr(Cexact,dps),'C_independent_abs_difference':mp.nstr(abs(Cquad-Cexact),dps),'H_using_E4_C':mp.nstr(H,dps),'H_using_quad_C':mp.nstr(num/mp.sqrt(Cquad),dps),'one_minus_H':mp.nstr(1-H,dps),'H_le_one_numerical':H<=1,'numerator_cuts':[mp.nstr(x,dps) for x in cuts],'C_cuts':[mp.nstr(x,dps) for x in Ccuts]}

def main(output):
    initial=[(s,d,str(mp.mpf(d)/2)) for s in ('.01','.5','1') for d in ('0','.25','.75')]
    stress=[(s,d,e) for s in ('.0001','.99') for d in ('.5','1','2') for e in ('0',str(mp.mpf(d)/2),d)]
    expanded=[(s,d,str(mp.mpf(d)/2)) for s in ('.001','.2','.8','1') for d in ('4','8')]+[('.8','4','3')]
    stages=[];failed=False
    for name,configs,degrees in [('initial',initial,(48,96)),('stress',stress,(48,96)),('expanded',expanded,(96,192))]:
      rows=[]
      for cfg in configs:
        vals=[calc(cfg,dps,deg) for dps,deg in zip((25,40),degrees)]
        with mp.workdps(50):diff=mp.nstr(abs(mp.mpf(vals[0]['H_using_E4_C'])-mp.mpf(vals[1]['H_using_E4_C'])),30)
        rows.append({'config':list(cfg),'precision_runs':vals,'H_low_high_absolute_difference':diff})
        if any(not v['H_le_one_numerical'] for v in vals):failed=True;break
      stages.append({'stage':name,'cases':rows})
      print(name,'completed',len(rows),'failed',failed,flush=True)
      if failed:break
    allrows=[r for st in stages for r in st['cases']]
    with mp.workdps(50):maxrow=max(allrows,key=lambda r:mp.mpf(r['precision_runs'][-1]['H_using_E4_C']))
    result={'schema':'R219_triple_overlap_candidate_probe_v1','complete_planned_grid':not failed,'simple_candidate_failure_found':failed,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'config_count':len(allrows),'stages':stages,'maximum_H_config':maxrow['config'],'maximum_H':maxrow['precision_runs'][-1]['H_using_E4_C'],'scope':['b=L=R=c_j=g=1,y=0,v=d,hard_source=e; target uses same soft kernel.','All integrations are over finite hard-source or core intervals; no infinite tail omitted.','Ordinary arbitrary-precision quadrature, not a directed interval certificate or proof of H<=1.','Candidate coordinate kernel only; no actual arbitrary L1 input or strict original current-ratio/FULL eligibility claimed.','No general-n order fit or original-theory counterexample claim.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'triple_probe.json');args=ap.parse_args();main(args.output)
