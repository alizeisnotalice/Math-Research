# R219 辅助：完整 capture 的测试选择与准确未付项

**结论：没有取得新的原来源付款。** 本稿只保留一个准确选择：以全部 terminal good 的指标 A=1G 作测试，将真实 ρ0 及其余正门保在有利损失项，可恒等消掉 GG；但 GE、已消费 suffix 的回加、删除/边界及终端权比仍须原预算。无门全 soft 核包络无法免费支付这些项。旧 R170/R135 机制、近1特殊支或未付积分改名均不登记进展。

已读本轮 task_contract，窄读 R170 research.zip::soft_threshold_energy §1–5、bridge_energy_audit §8、source_pair_tool_contract SP3；父级已核 R135 SIA1–5 的 Cov/阈值 incidence/删除能量不重复。R218 浮动带价只保一次。本稿仅改责任文件，无 Git/新 agent。

## JV1 原完整测度与母账

固定实际行 r=(ω,V,j,x,y,z_hard,history)，外测度保
\[
 d\mathcal T=1_I1_{\{j(x)=j\}}Q_F^{-1}p_yh_R(x-z_{hard})a_\omega
 \,dx\,\beta_V(dy)\nu_V(dz_{hard}),
\]
外有 high、2Λ。Πt=1Zt wtν/et，两份Π已含两份et分母，不再除et²。固定r后p、L、g、T、核及
\[
 \rho_0(v)=\left(1-\frac{DK_{0v}+\alpha_0J_v}{T\Delta_v}\right)_+,
 \quad\Delta_v=w_\tau(v)-w_h(v),\quad\alpha_0=DQ_F/Q_J
\]
均固定辅助t；零/非eligible行按原约定先零。R211恢复差价不重领。

令全部原terminal good为G、bad为B，Zg=G⊔B，Et=Zt\Zg；D_t(v,u)=kt(v)−kt(u)。G不能缩成仅ρ0>0或eligible集。Ψ是原剩余suffix配对门；ηt∈[0,1]收集原mixed/FA/其余未付正门，包括R218浮动带的补集。完整剩余signed行是
\[
 \mathcal R=\int\!\iint_{G\times B}\Psi
 [\rho_0(v)\eta_tD_t^+-D_t^-]d\Pi_t^2\frac{dt}{t}
 -N_{del}^{row}.\tag{JV1}
\]
Ndel是原Et×B未加Ψ/capture/FA的反向负项。任何新行分区须辅助t独立，并同时切正项和原未消费负项；不能按t/pair筛正项后再取全行负账。

## JV2 A=1G准确消GG，但没有消掉其它费用

取Ft=Πt(G)。R170一般测试身份直接给
\[
 \mathcal R=F_{\ell+}-F_{r-}+\sum_{\ell<t<r}\Delta F_t
 -\int(C_{GE}+H_Z+R_{loss})\frac{dt}{t}-N_{del}^{row},\tag{JV2}
\]
\[
 C_{GE}=\iint_{G\times E_t}(k_t(v)-k_t(u))d\Pi_t^2,
 \quad H_Z=\iint_{G\times B}(1-\Psi)(k_t(v)-k_t(u))d\Pi_t^2,
\]
\[
 R_{loss}=\iint_{G\times B}\Psi[1-\rho_0(v)\eta_t]D_t^+d\Pi_t^2\ge0.
\]
理由：无删除段−∂logt Ft=CovΠt(1G,kt)，G×G的系数1−1恒为零；逐对用ρ0ηD+−D−=D−(1−ρ0η)D+，再保留suffix补集即可。真实删除仅发生在Zg外，ΔFt=Fpre(epre−epost)/epost≥0。阈值处wt连续，不加physical hard原子。全部恒等式在有限截断上使用，另截时间段须另列端点。

这是**旧一般test身份的特例，不是新时间流定理**。它不要求ρ0与kt在G内同序，但CGE无自动符号；HZ的负部是已消费suffix信用，不能删除。Rloss只由原正项削减与原反向项产生一次，不可再从capture容量扣同份。Ndel、末端F及每个删除跳均保准确符号，不向补集返回本支负账。

旧联合边界仍要求统一真实R：wℓ(v)≤Rwg(v)于全部G，才能以CG=∫Gwgν写F初+ΣΔF≤R CG/eg。若R随行变化须保权；仅有R≤(g/ℓ)^n≤2^n不够。令Sv=K1v+K2v+Jv=3Qv*，同一good只给
\[
 pC_G\le(K/3)\int_GS_v\nu(dv).\tag{JV3}
\]
先固定hard z得到无z上界后才硬帽；high/FIRST、唯一j回代后，待付边界依旧含真实联合列R∫Svνdx。没有用无门核包络或近1子支把它宣布根阶，也没有删掉GE/suffix。两份Π与原来源全程未换。

若改回A=ρ0，可保capture权，但GG恢复。旧R170直接J边界使用A≤χJ=J/Sv；当前ρ0不能免费代入。具体非负点态J-majorant接口若要求ρ0≤Â≤ΓχJ，其最小费用就是esssupG ρ0Sv/J。这是该接口的准确损失，不断言所有signed势都必须如此，更不将它命名为已付容量。capture、高行和共同α0均未自动给该上帽。原∫Q*ν≤QF只给∫Svν≤3QF，不能假设单独K1ν、K2ν各≤QF；体积QF dx价也不是fixed-J来源价。

## JV3 全原soft的无门尺度包络不能是根阶

原strictsoft由R128 RT0/§0及其回读R117指定为s>1−2^(−1/n)>log2/(2n)，而不是近1条件s≥2^(−1/n)。本轮不把近1特殊包络作为成果。

取严格合法s_n=1−4^(−1/n)。物理乘积核的全hard项给P_{s_n,L}≥(1−s_n)^n h_L=h_L/4。真实cube尺度包络精确为
\[
 \int\sup_{L\in[a,b]}h_L(x)dx=1+n\log(b/a),\quad
 h_L=L^{-n}1_{\{\|x\|_\infty\le L/2\}}.\tag{JV4}
\]
证明：r=2||x||∞≤a的核心贡献1，a<r≤b时最优L=r，壳体积微分n r^(n−1)dr给n∫a^b dr/r。所以b/a=2时，全原soft的无门物理包络至少[1+nlog2]/4。

JV4只定位无原gate/无capture权包络的线性hard费用，不否定原联合预算，也不是FULL反例。将ρ0 flatten为1虽消GG，也可能丢掉恰需保的hard/capture抑制；下一步必须保原gate的接收几何，不能再把一般核包络当替代。

## JV4 停止点与账

剩余要实际付的是同一原测度中的边界/终端比值与GE/suffix/删除/反向补偿，不是再证明score变差身份。R218已付0<ρ0(wt−h0)≤L0J/p保一份16ΛL0/(3K)WA，余域ρ0(wt−h0)>L0J/p、两端mixed及所有原good/bad/capture/history保持；所有负信用只一份。

本机仅用Fraction核常数：(2Λ)(16/3)(1/6)=16Λ/9、(2Λ)(16/3)(1/2)=16Λ/3；Λ=128/119时为2048/1071、2048/357。这是准确算术，不是新实验或物理证书。没有新source付款、没有FULL或一般闭合声明。完成停止，等待主代理的原gate接收几何；不继续改写已知工具。
