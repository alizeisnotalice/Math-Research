# R219 三来源overlap候选：运行前方案

只筛选一坐标物理核候选，不认证原FULL或当前比例带严格资格。b=L=R=c_j=g=1,y=0,v=d,z=e，target同soft。h=1_[−.5,.5]，f_s=(1−s)h+s phi，F=max(h,phi)。计算H=∫_[e−.5,e+.5]sqrt[f_s(x)f_s(x−d)]dx / sqrt(C(d))，C(d)=∫_[−.5,.5]F(u−d)du，探索H≤1是否值得证明。

三阶段：initial s=.01,.5,1 × d=0,.25,.75，e=d/2（9配置）；stress s=.0001,.99 × d=.5,1,2 × e=0,d/2,d（18配置）；expanded s=.001,.2,.8,1 × d=4,8,e=d/2（8配置），并加offcenter s=.8,d=4,e=3（1配置）。共36配置；每项25/40dps与GL48/96阶，expanded用GL96/192阶。积分按hard与phi端点±.5,d±.5、0,d和真实hard来源区间端点分片。所有积分域有界，不存在被省略的无限尾。

C(d)独立双算：GL直接积分F，以及由E4原函数解析求值。对x≥0，phi原函数Psi(x)=x−E4(.5−x)+E4(.5+x)（x≤.5），或.5−E4(x−.5)+E4(x+.5)（x≥.5），奇延拓；F原函数在核心为x，外部为Psi(x)+sgn(x)[1/3−E4(1)]。对端点相减得到C。求积非区间，数值比较只作探路。若发现H>1，先报告明确参数/两精度再停止扩参或按父级指示继续；不把失败称原理论反例，不拟合一般n。

脚本支持--output，JSON无runtime或输出路径。完成后显式输出路径复跑，核完整JSON逐字节一致。

## 实际运行结果

三阶段36配置全部完成，均未发现H>1；每配置两精度，总72次有限积分运行。最大H=0.9950545831598250604352256974875009358727，参数(s,d,e)=['.01', '0', '0.0']。这仅支持该候选继续作解析审查，不证明H≤1。

|阶段|配置数|阶段最大H|参数(s,d,e)|最大低高精度H差|
|---|---|---|---|---|
|initial|9|0.99505458315983|['.01', '0', '0.0']|3.1322e-12|
|stress|18|0.82156049427588|['.99', '1', '0.5']|2.6738e-11|
|expanded|9|0.67739163304888|['1', '4', '2.0']|1.6899e-13|

C直接GL积分与独立E4原函数求值的最大绝对差为 1.5917e-12；40dps/高GL阶的最大C绝对差为 2.5627e-14。全部分片端点与原始积分结果保存在JSON。有限区间求积不涉及无限尾，非有向区间验证。

expanded远距离与offcenter结果：

|s|d|e|H高精度|
|---|---|---|---|
|.001|4|2.0|0.00067739163304888|
|.001|8|4.0|0.00055283096031791|
|.2|4|2.0|0.13547832660978|
|.2|8|4.0|0.11056619206358|
|.8|4|2.0|0.54191330643911|
|.8|8|4.0|0.44226476825433|
|1|4|2.0|0.67739163304888|
|1|8|4.0|0.55283096031791|
|.8|4|3|0.5838777804031|

结论范围：这批有限参数没有简单失败；下一步值得尝试证明一坐标H≤1或分析真正极值位置。不能将tensor形式当已构造的一般L1输入，不认证b=L=R=c_j=g=1在原当前比例带的严格资格，不宣称原FULL或一般维数阶结论。

以显式--output原路径完整复跑，JSON前后逐字节相同。SHA256=9ad84aba40ffe6ce20441eafdba3c93b74515ae2927adab2fa08dfb679fbdfc5。JSON没有runtime或输出路径字段。

复现命令：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/219/work/triple_probe.py
```

## R219扩尺度：运行前方案

只新增triple_scale_probe.py/json，不覆盖既有三来源文件。三阶段(n,L,R)=(8,1,.5),(8,.5,1)/(32,.75,1),(32,1,.75)/(128,.5,.5),(128,1,1)。每尺度取s=1−2^(−1/n)+.01及.8；取v=.5,z=v/2和v=2,z=v；三条腿A=L（soft s）、A=min(1,gamma L)（soft s）、A=1（soft1）。共72配置。hard_R来源已归一：I=(1/R)∫_[z−R/2,z+R/2]sqrt[p_s,L(x)K_A(x−v)]dx；H=(g/c_j) I/sqrt(w_g)。g=sqrt(LR)，gamma=1+1/n。

j以正有理数精确平方比较定位：gamma^(−2(j+1))LR≤min(L,R)^2≤gamma^(−2j)LR。w_g=min(1,C(|v|)/(c_j g))，C用上一候选的E4原函数。每配置25/40dps，GL48/96阶，按两个尺度hard/phi端点±L/2,v±A/2以及来源区间端点分片。若H>1，先报告明确参数，再对首例扩大精度；失败只反对该核候选，不称原FULL反例。

B0几何同时记录：Icap为相同被积函数在来源区间与[v−R/2,v+R/2]交集的归一积分；R≤L时n同坐标B0积分=I^n−Icap^n，R>L则I^n。用mp高精直接乘方和减法，不猜一般source/full预算。脚本--output，无runtime/输出路径，最终完整JSON重复核字节一致。

## 扩尺度实际运行结果

三阶段各24配置，共72配置、144次双精度有限积分全部完成，没有H>1，因此未触发首例失败扩大精度分支。全体最大H=0.8537651670825726540380770257467752060371，配置(n,L,R,s选择,v,z,leg)=[8, '1', '.5', 'lower_gate_plus_.01', '.5', '.25', 'K_L']。此结果只支持继续审查候选，不证明H≤1。

|阶段|最大H|配置|
|---|---|---|
|initial|0.85376516708257|[8, '1', '.5', 'lower_gate_plus_.01', '.5', '.25', 'K_L']|
|stress|0.74707066876663|[32, '1', '.75', 'lower_gate_plus_.01', '.5', '.25', 'K_L']|
|expanded|0.68229175331233|[128, '1', '1', '.8', '2', '2', 'K_L']|

25/40dps（同时GL48/96）H的最大绝对差为 2.9729e-12。每个actualj均由Fraction平方不等式核验；所有source及target hard/phi端点已分片，全部积分域有限，无尾项省略。

各尺度索引（不依s/来源/腿）为：

|n|L|R|j|cj|
|---|---|---|---|---|
|8|1|.5|2|64/81|
|8|.5|1|2|64/81|
|32|.75|1|4|1048576/1185921|
|32|1|.75|4|1048576/1185921|
|128|.5|.5|0|1/1|
|128|1|1|0|1/1|

JSON逐项记录I、Icap、I^n、Icap^n及原B0域乘积差。R≤L时保I^n−Icap^n，R>L时保I^n；source中心z=v的排除情形准确返回零（同区间复用积分），没有将B0差粗写为I^n。这里只是固定同坐标有限例的乘积数值，不是一般source或FULL预算。原H仍用未删B的I，未因B排除修改候选。

显式--output完整复跑后JSON逐字节一致。SHA256=634db4713a08f3540ba6949d9777a6fbea47667487eb37fea984a3e7e2c2a5b9。无runtime/输出路径，未修改既有triple_probe.py/json。

复现：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/219/work/triple_scale_probe.py
```

## Scalar U界实现：运行前方案

只新增scalar_bound_checks.py/json并追加笔记。读取相邻triple_probe.json的36个40dps高精配置与已有分子N，不新增物理积分；解析部分自包含，以E4奇原函数Psi计算V(d)=Psi(.5−d)−Psi(−.5−d)。U=(1−s)^2 max(1−|d|,0)+(2s−s²)V(d)。以80dps核N²≤U≤C(d)，同时独立重算C，并与输入C双校；不将未定向舍入的输入N当严格区间值。

另增s=0,1及d=0,.5,1,4,8的10个端点解析检查，只查U≤C，无新增积分。C由V加硬核心交集上的(1−phi)积分计算；无核心交集时直接C=V，保持s=1处解析等号。输入JSON按原始字节SHA256绑定，输出含脚本SHA256，最终输出SHA256记笔记；脚本默认读取相邻triple_probe.json，driver迁移时须一并提供该相邻文件。显式--output，JSON不含路径/耗时，完成后完整字节复跑。不拟合维数或扩展原FULL结论。

## Scalar U界实际实现核验

36个既有高精度分子N全部通过80dps实现检查N²≤U≤C；新增10个端点解析检查全部通过，没有新增物理积分。最小U−N²约 7.55206e-08，配置['.001', '8', '4.0']。C重算与原输入40dps值最大绝对差 4.2716e-41，符合输入截断精度范围。

s=0,d=0处U=C=1；s=1且d≥1处无hard核心交集，U=V=C按同一解析表达保持等号，未靠容差接受等号。U≤C与N²≤U的判断均无额外数值容差；然而N来自普通求积，仍不构成严格区间证明。

输入绑定SHA256=9ad84aba40ffe6ce20441eafdba3c93b74515ae2927adab2fa08dfb679fbdfc5；输出scalar_bound_checks.json SHA256=92b5636b73e82ae919218cd0164c5e297c0c6a50783508fb791491c34462e1ca。脚本含自身SHA256，显式--output再次运行后JSON逐字节相同。driver迁移时必须把原始triple_probe.json与本脚本放在同一目录；脚本无需导入triple_probe.py。

结果仅验证新解析证明公式的实现与既有有限数据一致，不拟合一般阶或认证原FULL。

复现：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/219/work/scalar_bound_checks.py
```

## 抽象gap代数：追加方案

同一scalar脚本新增1260个Fraction精确网格行：M=0,1/4,1/2,3/4,99/100；A=0,1/4,1/2,1；T=0,1/10,1；core_phi=0,MA/2,MA；a=0,1/100,1/4,1/2,3/4,99/100,1。令C=A+T,V=T+core_phi，精确核G=a(C−A)+(1−a)(C−V)≥min(a,1−a)(1−M)C，保留数值相同但网格标签不同的行。这是抽象代数实现检查，不是physical核或一般预算。

抽象gap实际结果：1260个精确Fraction网格行全部通过，包括退化端点与零slack；原36个U界及10个解析端点仍全部通过。修改后两次完整运行（第二次显式--output）JSON逐字节一致。更新scalar_bound_checks.json SHA256=c64a62b1d7b1e0359dea50e7b228ac8e26786d3a073f7af731d1734b221a1aab；输入仍绑定9ad84aba40ffe6ce20441eafdba3c93b74515ae2927adab2fa08dfb679fbdfc5。该抽象网格不声称物理核或一般预算。
