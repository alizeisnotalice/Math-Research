# R219 原正交通的三来源共同重叠：精确保留式与未付接口

本稿未取得原剩余的根阶付款。得到的是保留硬来源 (z)、目标 (v)、接收来源 (y) 的精确共同重叠式，以及其逐坐标上包络。原 ((k_t(v)-k_t(u))_+)、两个 (e_t)、历史选择器和实际捕获门没有被宣称免费。本稿不重复领取 R217–218 的时钟帽或浮动带费用。

## 1. 原对象、量词与硬捕获门

按本轮合同，固定 ((\omega,V,j,y,t)) 后，(\nu,Z_t,w_t,e_t,\Pi_t) 与接收点 (x)、硬来源 (z) 无关；当前 (L,R,s,g)、终端门、捕获及历史仍可依赖 (x)。因此只能先移出前一组量，不能把 (w_g) 或自适应核随意移出 (x) 积分。记

\[
\delta_t(v,u)=(k_t(v)-k_t(u))_+,
\qquad \Pi_t(dv)=1_{Z_t}(v)w_t(y,v)\nu(dv)/e_t.
\]

所有以下回代均针对原 mixed 剩余

\[
\rho_0(v)(w_t(y,v)-h_0(v))>L_0J_v/p_y,
\quad h_0=L_0J_v/p_y+K_0(v)/(\kappa T),
\]

并保留原 high、good×bad、FA、后缀及唯一比例带。辅助 (t) 不是物理尺度 (L)。

**硬门的准确定位。** R128 `proof.md:16485`，章节“作者已确认的原定义”，明确

\[
B_{\rm hard}(v)=1_{\{R\le L\}}1_{Q_R(x)}(v),
\quad Q_R(x)=x+[-R/2,R/2]^n.
\tag{DG1}
\]

同文件 `:16246` 的认证实现保留闭边界；`:1542` 明言 (R>L) 时为零。原 RC 与 baseline 使用同一 (E=S_g\cap\{B=0,A>0\})，故 (\rho_0>0\Rightarrow B=0)。因此 (R\le L) 时确实排除 (x\in Q_R(v))，但一般不排除更大的 (Q_L(v)) 或 (Q_{L^+}(v))；(R>L) 时没有这个排除。仅 (R=L) 时，它直接排除 (K_1) 的全硬核心。不能据此删除一般尺度包络的全部硬部分。

## 2. 固定物理参数下的无额外维数常数 overlap

本节先冻结 (s,L,R,b,j)，(L,R\le b)，(g=\sqrt{LR})，且原比例带给

\[
\min(L,R)\le c_jg.
\]

令 (h=1_{[-1/2,1/2]})，(f_s=(1-s)h+s\phi)，(F=\max(h,\phi))，(C(d)=\int_{-1/2}^{1/2}F(r-d)\,dr)。原核满足 (0\le f_s\le F\le1)，(F) 偶且径向不增，(f_s) 积分为一。写

\[
\omega_g(d)=\min\{1,bC(|d|/b)/(c_jg)\},
\qquad w_g(a,z)=\prod_i\omega_g(a_i-z_i).
\]

对任意 (A\in[L,b])、任意 (\sigma\in[0,1])，一维卷积

\[
O_{\sigma,A,R}(a,z)=\int A^{-1}f_\sigma((x-a)/A)R^{-1}h((x-z)/R)\,dx
\]

满足

\[
O_{\sigma,A,R}(a,z)
\le\min\{1/\max(A,R),\ bC(|a-z|/b)/(AR)\}
\le(c_j/g)\omega_g(a-z).
\tag{DG2}
\]

证明：两核分别积分一、上界 (A^{-1},R^{-1})，给第一项。由于 (A\le b)，有 (f_\sigma((x-a)/A)\le F((x-a)/b))；把硬积分区间从长度 (R\) 扩至同中心长度 (b\)，得到第二项。再用 (A\ge L)，两个上界分别不大于对应 (A=L) 的上界；而 (1/\max(L,R)=\min(L,R)/g^2\le c_j/g)，另一项为 (bC/g^2)。取最小值即结论。张量化得到

\[
\int P_{\sigma,A}(x-a)h_R(x-z)\,dx
\le(c_j/g)^n w_g(a,z).
\tag{DG3}
\]

这覆盖三个实际目标核 (K_1=P_{s,L})、(K_2=P_{s,L^+})、(K_3=J=P_{1,b})，没有调用单个 (K_1\nu,K_2\nu\le Q)。

在同一硬立方体内作 Cauchy，得到

\[
\int\sqrt{p_y(x)K_a(x-v)}h_R(x-z)\,dx
\le(c_j/g)^n\sqrt{w_g(y,z)w_g(v,z)}.
\tag{DG4}
\]

注意右侧 (w_g(v,z)) 是同一几何核以 (v) 为中心的值，绝不是原行以 (y) 为中心的后验权。式中 ((c_j/g)^n) 有密度单位，不能抛掉。

## 3. 保留 (B=0) 的精确共同 half-overlap

DG4 把同一硬立方体内的两核分开，可能损失恰需的共同几何。下面给不分开的精确表达；此处不猜任何逐坐标常数。

归一化 (b=1) 的无量纲参数为

\[
\lambda=L/b,\quad r=R/b,\quad a=A/b,\quad
d_i=(v_i-y_i)/b,\quad e_i=(z_i-y_i)/b.
\]

对目标核参数 ((\sigma,a))，定义

\[
I_i=\frac1{r\sqrt{\lambda a}}
\int_{e_i-r/2}^{e_i+r/2}
\sqrt{f_s(q/\lambda)f_\sigma((q-d_i)/a)}\,dq,
\]

\[
I_i^{\cap}=\frac1{r\sqrt{\lambda a}}
\int_{[e_i-r/2,e_i+r/2]\cap[d_i-r/2,d_i+r/2]}
\sqrt{f_s(q/\lambda)f_\sigma((q-d_i)/a)}\,dq.
\]

空交集积分为零。直接 Tonelli 和立方体乘积结构给出精确式

\[
\int 1_{\{B(v)=0\}}\sqrt{p_yK_a(v)}h_R(x-z)\,dx
=b^{-n}\left(\prod_i I_i-1_{\{R\le L\}}\prod_iI_i^{\cap}\right).
\tag{DG5}
\]

闭边界不改变 (dx) 积分。特别地 (R\le L,z=v) 时右侧严格为零。这是原硬捕获门与同一硬来源的真实共同消减，不能用“排除 (Q_L(v))”代替。它也不是各坐标差的乘积：必须是两个乘积之差。

为了准确记录 good 所需的除数，令

\[
\omega_i=\min\{1,C(|d_i|)/(c_j\sqrt{\lambda r})\},\quad
D_i=\frac{\sqrt{\lambda r}}{c_j}\frac{I_i}{\sqrt{\omega_i}},\quad
D_i^{\cap}=\frac{\sqrt{\lambda r}}{c_j}\frac{I_i^{\cap}}{\sqrt{\omega_i}}.
\]

原有效来源 (w_g(y,v)>0)，于是 DG5 除以 (\sqrt{w_g(y,v)}\) 等于

\[
(c_j/g)^n\left(\prod_iD_i-1_{\{R\le L\}}\prod_iD_i^{\cap}\right).
\tag{DG6}
\]

DG6 可作为严格一维共同重叠分析的输入；本稿未证明 (D_i\le1)，也未证明乘积差具有根阶来源价格。它保留了 DG4 的分离 Cauchy 丢掉的信息。

## 4. 原交通中确实成立的 half-density 转写

原 good 是

\[
p_yw_g(y,v)\le\frac K3(K_1(v)+K_2(v)+J_v).
\]

所以 good 上逐点有

\[
p_y\le\sqrt{\frac K{3w_g(y,v)}}\sum_{a=1}^3\sqrt{p_yK_a(v)}.
\tag{DG7}
\]

令 (M) 包含合同的完整剩余、原 good×bad、FA 与后缀门。原正量记为

\[
\mathcal P=2\Lambda\int\frac{a_\omega}{Q}1_I1_j1_{\rm high}
p_yh_R(x-z)M\rho_0(v)\delta_t(v,u)
\frac{1_{Z_t}(v)1_{Z_t}(u)w_t(y,v)w_t(y,u)}{e_t^2}
\,dx\,\beta_V(dy)\nu_V(dz)\nu_V(dv)\nu_V(du)\frac{dt}{t},
\]

另按原约定对外部标签求和/积分。则 DG7 给出合法单向估计：将此式中的 (p_y\) 精确替换上界

\[
\sqrt{K/3}\sum_{a=1}^3\sqrt{p_yK_a(v)}/\sqrt{w_g(y,v)}.
\tag{DG8}
\]

其余每一个因子均保留。这不消耗 signed 负信用，也未用 (\delta\le k_v\) 或 (\delta\le n\)。(\rho_0\le1_{B=0}) 可以用于上放松，但捕获实际小量没有另行假设。

**固定参数的条件接收积分。** 只有在 (s,L,R,g,j) 已经独立于 (x) 固定时，才可从 DG8 删除非负门、用 DG5/DG6 积掉接收点。若连 (B) 门也删除，DG4 给

\[
\int p_yh_R(x-z)1_{\rm good}\,dx
\le\sqrt{3K}(c_j/g)^n
\sqrt{\frac{w_g(y,z)w_g(v,z)}{w_g(y,v)}}.
\tag{DG9}
\]

原自适应行没有上述固定参数资格。对所有 (x) 删门后随意使用 DG9，会把自适应接收核误当一个固定核归一；本稿不作此步。任何尺度/softness 网格或包络必须另证明并支付其完整成本。

## 5. 尚未付的具体来源列与抵消

即使暂时给予固定参数资格，DG9 的硬来源积分仍是

\[
\mathcal T_g(y,v)=\frac1{\sqrt{w_g(y,v)}}
\int\sqrt{w_g(y,z)w_g(v,z)}\,\nu_V(dz).
\tag{DG10}
\]

Cauchy 仅给

\[
\mathcal T_g(y,v)\le
\sqrt{\bar e_g(y)\bar e_g(v)/w_g(y,v)},\qquad
\bar e_g(a)=\int w_g(a,z)\nu_V(dz).
\]

原 (e_g(y)=\int_{Z_g}w_g(y,z)\nu_V(dz)\le\bar e_g(y))，方向不能用来上控 DG10；既没有 (\bar e_g=e_g) 的接口，也没有以 (v) 为中心的 (\bar e_g(v)) 后验归一。原硬来源 (z) 不能无依据限制到 (Z_g\)。三角比 (w_g(y,z)w_g(v,z)/w_g(y,v)) 也未获统一常数上界。

故目前未付项具体为：

1. DG6 在原自适应 (s,L,R,g\) 和历史门下的完整接收包络。
2. 保留全来源 (\nu(dz)\)、原 (\beta(dy)\)、(\nu(dv)\nu(du)/e_t^2\) 的共同列预算，不能交换 (\beta,\nu\)，不能使用 (\nu\le\beta\)。
3. 原 (\delta_t(v,u)\) 的正变差及 bad (u\) 的联合收益。DG5–DG10 只表达 (y,v,z\) 几何，尚未把 (u\) 端的共同坐标抵消转化为可积价格。
4. 若使用 high/FIRST，则必须处理同一 (x\) 的来源容量及 (a_\omega\)；(Q^*\) 的容量不授权逐个 (K_1,K_2\) 取得 (Q\) 预算。

DG5 的硬交集扣除和不分离的 (I_i\) 是精确可继续研究的对象，但不是新登记付款。不能将 DG10 政名为 (W_A\)，也不能以恢复旧 HH/硬 (16/3\) 包络宣布闭合。已付浮动带、one-hard cap 以及未消费负信用都保持原账。

## 6. 本机验证与证据级别

实际运行本机 Python `fractions.Fraction`，对 (L=l^2,R=r^2,g=lr,c_j=\min(l,r)/\max(l,r)\)，(1\le l,r\le8\)，(A\in\{L,b\}\)、(C\in\{0,1/8,1/2,1\}\) 的 512 个有理组合核验 DG2 最后一步的代数上界，全部通过。这个检查只验证代数实现，不是原尺度窗、原历史、来源预算或维数一致命题的数值证据；严格证明是第二节逐步不等式。

结论：本轮该路线交付准确原 (B\) 门与 DG5/DG6 的共同三来源表达，尚未扩大已付款区域；完整原目标仍未闭合。
