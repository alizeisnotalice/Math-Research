# R219：同尺度三来源 half-overlap 的常数一解析界

状态：本稿证明任意独立双软度与任意窗口位置的严格一维核定理，可按固定参数张量化。它不是原正交通的来源预算；不改变 `direct_geometry.md` 中列出的历史、选择器、归一化与 bad 端费用。

## 1. 准确命题与更强形式

取原一维核

\[
h=1_{[-1/2,1/2]},\qquad
w(x)=\int_0^1e^{-|x|/r}\,dr,\qquad
\phi=h*w,\qquad f_s=(1-s)h+s\phi.
\]

令 (F=\max(h,\phi))，并定义偶函数

\[
C(d)=(h*F)(d),\qquad V(d)=(h*\phi)(d),\qquad A(d)=(h*h)(d)=(1-|d|)_+.
\]

对任意 $s,\sigma\in[0,1]$、任意 $d,z\in\mathbb R$，令 $a=(1-s)(1-\sigma)$，并记

\[
N_{s,\sigma}(d,z)=\int_{z-1/2}^{z+1/2}\sqrt{f_s(x)f_\sigma(x-d)}\,dx.
\]

则有统一强形式

\[
\boxed{\quad N_{s,\sigma}(d,z)^2
\le aA(d)+(1-a)V(d)
\le C(d).\quad}
\tag{SO1}
\]

特别地原候选成立：

\[
\boxed{N_{s,\sigma}(d,z)/\sqrt{C(|d|)}\le1.}
\tag{SO2}
\]

量词包括全部离中心窗口以及独立的 $s,\sigma$，没有假设 $z=d/2$。共同软度是 $\sigma=s$ 的特例。$\sigma=1$ 包含同尺度 $J$ 腿。本命题仍仅针对 $b=L=R=1$ 的上述核。

## 2. 原核的乘积支配

对 (0<r\le1) 记

\[
e_r(x)=e^{-|x|/r},\qquad
\phi_r(x)=(h*e_r)(x)=\int_{-1/2}^{1/2}e^{-|x-u|/r}\,du.
\]

设 (\phi_0(x)=0)。这与 (r\downarrow0) 的积分极限一致，单个端点也不影响任何 (dr) 积分。由非负 Tonelli，

\[
\phi(x)=\int_0^1\phi_r(x)\,dr.
\]

对固定 (x)，函数 (r\mapsto\phi_r(x)) 单调不减，并有 (0\le\phi_r(x)\le1)。因此所有以下积分有限，且 (0\le\phi\le1)。此外

\[
\int_{\mathbb R}w(x)\,dx=\int_0^1 2r\,dr=1,
\]

所以 (w,\phi\) 均为概率密度。它们是偶函数，故 (V\) 偶。

**同参数正相关。** 任意固定 (x,y\in\mathbb R)，两函数 (\phi_r(x),\phi_r(y)) 都随 (r\) 不减。Chebyshev 积分不等式在总质量一的 (dr\) 上给

\[
\phi(x)\phi(y)
\le\int_0^1\phi_r(x)\phi_r(y)\,dr.
\tag{SO3}
\]

其方向可直接由恒等式核对：右侧减左侧等于

\[
\frac12\int_0^1\int_0^1
[\phi_r(x)-\phi_q(x)][\phi_r(y)-\phi_q(y)]\,dr\,dq\ge0.
\]

**同 (r) 三角支配。** 对所有 (u,v\in[-1/2,1/2])，三角不等式给

\[
e^{-|x-u|/r}e^{-|y-v|/r}
\le e^{-|x+y-u-v|/r}.
\]

对 (u,v\) 积分，得到

\[
\phi_r(x)\phi_r(y)\le(h*h*e_r)(x+y).
\tag{SO4}
\]

把 SO3、SO4 合并，再用 Tonelli，得到本证明的关键逐点工具：

\[
\boxed{\quad\phi(x)\phi(y)\le(h*h*w)(x+y)=V(x+y).\quad}
\tag{SO5}
\]

取 (y=d-x)，利用 (\phi\) 偶性，便有

\[
\phi(x)\phi(x-d)\le V(d)
\quad\text{对全部 }x,d\in\mathbb R.
\tag{SO6}
\]

这里没有先将同一窗口中的两个 overlap 作分离 Cauchy；SO6 来自原 Laplace 混合的共同参数正相关与三角不等式。

## 3. 独立双软度展开与任意窗口

记 (I=[z-1/2,z+1/2])，其长度恰为一。仅对单一乘积函数作窗口 Cauchy：

\[
N_{s,\sigma}(d,z)^2\le |I|\int_I f_s(x)f_\sigma(x-d)\,dx
=\int_I f_s(x)f_\sigma(x-d)\,dx.
\tag{SO7}
\]

展开独立的 $s,\sigma$ 后，四个乘积积分分别有如下上界：

\[
\int_I h(x)h(x-d)\,dx\le A(d),
\]

\[
\int_I h(x)\phi(x-d)\,dx\le V(d),\qquad
\int_I\phi(x)h(x-d)\,dx\le V(d),
\]

以及由 SO6 和 (|I|=1\)，

\[
\int_I\phi(x)\phi(x-d)\,dx\le V(d).
\]

前两类仅将非负积分扩到整个实线；偶性保证卷积的符号一致。因此

\[
N_{s,\sigma}(d,z)^2
\le(1-s)(1-\sigma)A(d)
+[(1-s)\sigma+s(1-\sigma)+s\sigma]V(d)
=aA(d)+(1-a)V(d).
\]

即 SO1 第一式。又 (F\ge h\) 且 (F\ge\phi\)，所以 (C\ge A,V\)。两个系数 $a=(1-s)(1-\sigma)$ 和 $1-a=s+\sigma-s\sigma$ 非负、和为一，得到 SO1 第二式。对有限 (d\)，原正尾使 (C(d)>0\)，因此 SO2 中除法合法。

## 4. 缺口与可张量化范围

SO1 给出明确保留软度与位移的余量：

\[
N_{s,\sigma}(d,z)^2\le C(d)-G_{s,\sigma}(d),
\]

\[
G_{s,\sigma}(d)=a[C(d)-A(d)]
+(1-a)[C(d)-V(d)]\ge0.
\tag{SO8}
\]

所以在固定同尺度参数下，归一化 (n\) 维共同 hard-cube half-overlap 满足

\[
\frac{\int_{Q_1(z)}\sqrt{P_{s,1}(x-y)P_{\sigma,1}(x-v)}\,dx}
{\sqrt{\prod_i C(v_i-y_i)}}
\le\prod_i\sqrt{1-G_{s,\sigma}(v_i-y_i)/C(v_i-y_i)}\le1.
\tag{SO9}
\]

这是真正逐坐标常数一，未产生 (C_0^n\) 损失。进一步加原 (B=0\) 排除只会减小左侧；若需精确保留该排除，仍应使用 `direct_geometry.md` 的两个乘积之差。SO9 包含同尺度目标 $J=P_{1,1}$（取 $\sigma=1$）；它不授权不同尺度的两个目标核，不授权自适应 (L,R\) 接收积分，也不支付 (\beta(dy)\nu(dz)\nu(dv)\nu(du)/e_t^2\) 的原来源费用。

## 5. 可量化的全位移缺口与远位移分支

记 $M=\phi(0)$、$c=1-M$。首先 $0<M<1$，并且 $\phi(x)\le M$：对每个 $r>0$，

\[
\frac{d}{dx}\phi_r(x)=e^{-|x+1/2|/r}-e^{-|x-1/2|/r}\le0\qquad(x\ge0),
\]

结合偶性与 $dr$ 积分得到最大值在零点。直接积分还给出

\[
M=\int_0^1 2r(1-e^{-1/(2r)})\,dr
=1-2\int_0^1r e^{-1/(2r)}\,dr,
\qquad
c=2\int_0^1r e^{-1/(2r)}\,dr>0.
\]

$M>0$ 来自原正核；$M<1$ 由右侧严格正的缺口得到。因此 $c\in(0,1)$ 是与维数、软度、位移、窗口无关的确定常数。

令 $E=[-1/2,1/2]$。由于 $\phi\le M<1$，$F$ 在 $E$ 内等于一、在 $E^c$ 上等于 $\phi$。因此对每个 $d$，有准确分解

\[
C(d)=A(d)+T(d),\qquad
T(d)=\int_{E\cap(d-E)^c}\phi(d-u)\,du\ge0,
\]

\[
C(d)-A(d)=T(d),\qquad
C(d)-V(d)=\int_{E\cap(d-E)}[1-\phi(d-u)]\,du
\ge cA(d).
\tag{SO10}
\]

边界集合对这些 Lebesgue 积分为零。进而

\[
[C-A]+[C-V]\ge T+cA\ge c(T+A)=cC.
\]

取 $a=(1-s)(1-\sigma)$、$m_a=\min\{a,1-a\}$，SO8 给出全位移缺口

\[
G_{s,\sigma}(d)
=a(C-A)+(1-a)(C-V)
\ge m_a\{(C-A)+(C-V)\}
\ge c m_a C(d).
\tag{SO11}
\]

故对全部 $s,\sigma\in[0,1]$、$d,z\in\mathbb R$，

\[
\boxed{\quad
\frac{N_{s,\sigma}(d,z)}{\sqrt{C(d)}}
\le\sqrt{1-c\min\{a,1-a\}}.
\quad}
\tag{SO12}
\]

特别地 SO9 中固定同尺度的 $n$ 维归一化 half-overlap 不超过

\[
(1-cm_a)^{n/2}\le\exp[-nc\min\{a,1-a\}/2].
\tag{SO13}
\]

这里使用 $\log(1-q)\le-q$；$q=cm_a<1$，故全参数合法。$a=0$ 或 $a=1$ 时这个全位移指数为零，不能声称端点也有统一严格缺口；例如 $s=\sigma=0,d=z=0$ 的原比值确实等于一。

**远位移的更强分支。** 若 $|d|\ge1$，则 $A(d)=0$，两个核心至多在一个边界点相交，因而 $C(d)=V(d)>0$。SO1 因此直接给

\[
\boxed{\quad |d|\ge1\ \Longrightarrow\quad
N_{s,\sigma}(d,z)/\sqrt{C(d)}\le\sqrt{1-a}.\quad}
\tag{SO14}
\]

这里“直接”指强形式上界的准确化简，不宣称每组参数取等。若 $n$ 个位移中恰有 $k$ 个满足 $|d_i|\ge1$，还可保留乘积上界

\[
(1-a)^{k/2}(1-cm_a)^{(n-k)/2},
\]

其中空乘积按一解释。这些缺口仍只适用于本稿固定同尺度核；不改变原来源、历史、尺度选择器与正交通尚未付款的状态。

## 6. 本机算术核对

实际调用本机 Python 与项目 vendor `mpmath`，以 25 位精度、在硬边界分段积分，核对如下 $\sigma=s$ 子域的 $(s,d,z)$ 的 SO1 强形式。记录的是普通高精度数值，不是区间证书；严格依据为上文证明。

| ((s,d,z)\) | (N_s^2\) | SO1 中间上界 | (C(d)\) |
|---|---:|---:|---:|
| ((.4,0,0)\) | 0.643498089142909 | 0.683493322228771 | 1 |
| ((.4,.75,.375)\) | 0.178903747732640 | 0.268485721827589 | 0.412375370713848 |
| ((.8,1,.5)\) | 0.120869980250854 | 0.178781944221957 | 0.186231191897872 |
| ((.8,4,3)\) | 0.00122770604801015 | 0.00345717792738545 | 0.00360122700769318 |

表中 $N_s$ 表示 $N_{s,s}$，该已有数值仅核对共同软度子域；独立软度扩展由上文解析展开证明，本次未新增积分。所有核对满足两段不等式。先前将单核心项再作平方根次可加放松的矩阵充分条件在 ((d,z)=(1,.5)\) 失效；该松弛没有用于本证明，也不影响 SO1。
