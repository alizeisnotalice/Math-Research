# R655 reproduction and evidence boundaries

The general centered-cube root-order weak bound is unproved. The analytic report proves a legal all-finite calibration/independent-clone selection and an arbitrarily small actual adaptive source-correlation fee. It does not prove the remaining joint coverage/actual-entropy budget.

After unpacking, use the installed independent mathematical environment:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py --replay
```

Integrity verification checks the exact file set, hashes, TeX references, and the two final report/next-target audit bindings. These checks alone do not establish mathematical correctness. Replay copies numeric materials into a temporary directory and runs only two exact certificate scripts:

- `clone_certificate.py` independently reconstructs all 22 finite atomic receiver/image geometries and the positive-width coupling bound. Its JSON must reproduce byte-for-byte. The actual AC packing/source argument, independently audited in NUMERIC_AUDIT, gives the full finite-model bound ED4 >= 23843/278528. The script also checks the successor-domain exclusion E kappa4' > 4.
- `explore_bounds.py` reconstructs all 12 rational interval bounds using integer fixed-point outward rounding. Its exact lower/upper fractions and parameters must agree; runtime timing fields need not. It reads only its sibling `explore_compute.py` definitions without running the latter's floating quadrature campaign.

The exact r2 atomic entropy/KKT diagnostic is proved in REPORT and ENTROPY_DIAGNOSTIC_AUDIT; it was independently checked with Fraction. The packaged replay does not claim to mechanize all of that proof. It separates exact geometry/KKT arguments from the primary solver's numerical outputs and uncertified secondary selection.

To reproduce optional floating diagnostics in a **scratch copy** of numeric/, use the same interpreter:

```sh
python numeric/clone_probe.py > /tmp/r655-clone-probe-replay.json
python numeric/explore_compute.py
```

Here `python` denotes the absolute interpreter above. The second command writes sibling explore_results.json; run it only in the scratch copy to preserve archived evidence. The primary optimization uses CVXPY/Clarabel and includes one r4 optimal_inaccurate status. It is not a strict optimizer certificate. The independent integer-bound script does not depend on those optimizer values. Floating and timing outputs need not be byte-identical.

Recorded tools: Python 3.12.14, Fraction/integer arithmetic, SymPy 1.14.0 for stated algebra checks, NumPy 2.5.4, CVXPY 1.9.3, Clarabel 0.11.1 and mpmath as recorded by the numeric output. Calculations use one process and OpenBLAS/OMP one; no artificial CPU load was added. No MATLAB job, API consultation or PDF compilation was performed this round. Per-native-agent monetary/token billing was not available and is not estimated.

All numeric examples here are one-dimensional and low-R. Their fixed epsilon is not the all-finite calibrated epsilon_*; some successors exceed kappa'=4. The r2 exact entropy contrast is an atomic finite diagnostic; the r4 positive whole gain is a genuine AC finite-model result. Neither is a near-score or general-dimensional budget certificate. The rare-exploration limits require fixing a positive mixture weight before increasing clone count; the two iterated limits do not commute in the certified fixture.

The archive omits intermediate notes, duplicated replay scripts, caches, failed API logs and credentials. The original solver output is retained as the minimal branch record needed by the geometric replay and to disclose its numerical scope.
