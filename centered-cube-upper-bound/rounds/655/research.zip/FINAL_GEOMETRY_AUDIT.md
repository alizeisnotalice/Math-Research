# R655 final independent geometry integration audit

**Verdict: PASS for the stated reductions, new geometric identities and their scope.** No blocking error was found. This does not certify a general reachable net budget, a positive near-score full gain or the root-order weak bound.

## Frozen file binding

The following SHA-256 values were actually computed and match the supplied freeze:

| File | SHA-256 |
|---|---|
| `/tmp/ccu_r655/REPORT.tex` | `5215755e3ff61901e879c27b2d487c89567a63db20b7fd5cb7a09a311d1a47e0` |
| `/tmp/ccu_r655/NEXT_TARGET.md` | `839b9a33275b24dc236da029acf5fb6114c96154ad7357d0e5787b76526ad320` |

The calibration/cloning/exploration portions were checked against this reviewer's already completed independent proofs in `CLASS_VARIATION_AUDIT.md` and `EXPLORE_AUDIT.md`. The new tag/core, face-motion, packing-staircase and zero-parameter benchmark deductions below were independently reconstructed from their definitions before accepting the report's conclusions. Numerical scope was checked without repeating passed computations.

The final sentence correction following the concentration bound was separately checked: Gamma is the expectation of the **signed** discrepancy, and its absolute value is bounded by the expected absolute discrepancy. This preserves the proved estimate without identifying Gamma with a nonnegative absolute-error expectation. The report was rebound to the new SHA above; the next-target SHA is unchanged.

## Calibration, finite cloning and exploration quantifiers: PASS

The report retains the parameter-independent full-owner geometry classes, the uniform single-instance and infimum 1-Lipschitz estimate, and the squeeze giving `A_infinity(epsilon_*)=epsilon_*/4>0`. All finite states and successors are then compared at that same global parameter. It does not enlarge N at an old finite-N calibration while retaining its cap.

Cloning splits real I and old lambda, preserves m/u/Q/V/M/H/score, and changes the actual independent anchor tuple and all successor outputs. The raw entropy additive constant is retained. The adaptive test aggregates clone alpha into the original packing polytope; concentration is on the original finite source algebra, not a claim that alpha itself converges or becomes stable. Original cell count determines a later finite r rather than a final bound constant. The stated conservative r choice indeed makes the whole correlation price no larger than the allocated zeta V.

Exploration uses only positive-volume feasible saturated cells, averages finitely many feasible moment witnesses, and preserves the genuine old KKT equations. The row domain remains `D_j=union{P_s: s feasible, j in K_s}` with its closure; arbitrary closed-boundary membership is excluded. Product approximation and exploration receive separate score tolerances. A positive exploration weight is fixed before the finite clone count and before anchors. The report limits convergence to the scalar receiver expectation and makes no infinite-label optimizer, alpha/Q'/D convergence, or exchange of exploration and clone limits. The next target preserves all these quantifiers.

## Independent tag rectangle/core and face-motion check: PASS

For a tag centered at z with halfwidths h and contained in A_j, anchor centers range independently over the rectangle centered at `sigma y-bz` with halfwidths b h. Minkowski addition by the receiver cube therefore gives swept halfwidths `t s/a+b h_i`; coordinatewise intersection of the expanded cubes gives core halfwidths `t s-b h_i`. The latter are positive because `h_i<=s`. The containment `|y_i-z_i|+h_i<=s` also gives `A_j subset K_jq` directly. Closed tags representing open uniform components add only source/receiver boundary faces; no positive measure or KKT atom is gained.

Every actual clone cube with that tag contains its core. Aggregating any actual packing by row/tag is consequently feasible for the core LP. Integrating its old-A load against the one old AC source proves its objective at most M. Thus the report's `Q'_r<=Q_box<=M` is an actual upper comparison, not identification of the core LP with the entropy optimizer.

On the proposed affine rectangle path, the outward receiver velocity on side e is `b[e(y_i-z_i)+2s/a+h_i]`, and the opposite core-face velocity is `b[-e(y_i-z_i)+2s-h_i]`. Their sum is exactly `2bs(1+1/a)`. Each core-face velocity is at least bs by tag containment, so each core expands monotonically. Receiver-side motion need not be outward, and neither file treats the identity as a lower bound for exterior union growth. Redundant contacts, overlap and source-packing rebalancing are not paid by merely summing these velocities.

## Packing staircase, initial and terminal contacts: PASS

At comparison time zero the tagged cores are repeated old A_j, with **fixed final coefficients** m_j. Their LP value is exactly M: distribute each old lambda_j among its tags to obtain a feasible packing of value `sum lambda_j m_j=M`, while the old AC source supplies the opposite inequality.

Each core face is affine in time. Whether a fixed subfamily has positive-volume intersection is determined by finitely many strict comparisons of affine endpoint functions. Hence only finitely many incidence thresholds occur, the a.e. packing polytope is constant between them, and its fixed-coefficient optimum is a nonincreasing staircase. Its total decrease to time one is exactly `M-Q_box`. If an initially null contact immediately develops positive volume, the time-zero LP and its right limit can differ; that initial right-hand jump must be included. A contact whose first intersection is still null at time one imposes no additional a.e. constraint there and supplies no hypothetical time-1-plus reward. The report and next target state both endpoint conventions correctly.

This is a comparison LP along anisotropic rectangles with fixed m costs. It is not a path of actual cube/KKT states, and near-score stationarity is correctly not invoked along it.

## Reachable linear volume benchmark and actual net target: PASS

For every actual reachable finite cube subfamily, the costs m_j are its true cube volumes and its receivers are exactly the concentric C/a. The defining zero-parameter full-class inequality therefore bounds that receiver union by T0 times its genuine linear packing value. Compact exhaustion of the bounded reachable open receiver domain by interiors of reachable receivers gives `W_reach<=T0 Pi`. Finite tag rectangles make the omitted closure faces Lebesgue-null. No attainment of Pi, dual atomic measure or limiting entropy optimizer is needed.

The complete comparison chain is valid: each realized finite clone family is a reachable subfamily, so `Q'_r<=Pi`; each reachable cube contains a tag core, so any finite reachable packing aggregates to a feasible core packing, giving `Pi<=Q_box`; the old-source bound gives `Q_box<=M`. Closure anchors are covered by closures of the feasible tag cells with the correct row membership, so that aggregation does not import outside-label boundary tags.

Consequently `W_reach-RPi<=(T0-R)Pi`. The report correctly uses this only as a strength/scope screen for replacing entropy by maximal linear packing. It neither constructs a high-R near-score obstruction nor claims the actual target fails. The next target does not replace actual alpha with Pi or Q_box.

With `Delta_r=Pi-EQ'_r`, `K=T0 Pi-W_reach` and `T_r=W_reach-EW_r`, all three quantities are nonnegative and the signed identity

`E D_r=R Delta_r-(R-T0)Pi-K-T_r`

is exact. Both frozen files retain K and finite T_r in the required net theorem. They explicitly reject the weaker condition obtained by dropping K as a sufficient full budget. The whole-law near-score cap using Q_box is also correctly an upper constraint: its coefficient is nonnegative because `H/M<=4`; it follows from finite actual successors and scalar W convergence alone.

## Numerical boundaries: PASS within reported evidence

The r=1,2,4 state remains a genuine low-R finite model at `epsilon=336/5`, with no global near-score or epsilon_* certificate. The report separates atomic optimizer diagnostics from the exact positive-width r4 whole-gain bound. It explicitly states `E kappa'_4>=333039/81920>4`; hence some successors violate the global calibrated cap. The exact r2 entropy separation is restricted to its atomic four-branch experiment, with mixed branches already satisfying `kappa'>=21/5>4`; it does not establish an AC/global example or negativity of `W_reach-RPi`. Finite expected receiver union and the larger reachable volume are kept distinct.

The rare-exploration grid is reported only as the specified twelve receiver integrals and their two noncommuting scalar limits. It does not certify a uniform rate, continuum parameter result, source/optimizer limit or calibrated near-score budget. Passed arithmetic jobs were not rerun for this audit.

## Verification and stop

One new bounded installed-Python/SymPy check returned exact zero residuals for the opposite-face velocity sum and the actual-deficit signed identity. The geometric containments, finite staircase and zero-parameter exhaustion were checked analytically. No new fixture, numerical scan, author-file edit, Git operation, API call, PDF compilation or subdelegation was performed.

Audit complete for the two hashes above. No blocking line is identified within the assigned scope. The full actual net entropy-deficit/coverage estimate remains unproved, as both frozen files state.
