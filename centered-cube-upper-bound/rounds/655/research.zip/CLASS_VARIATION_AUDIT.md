# R655 independent class, calibration and cloning audit

**Decision.** Arbitrary finite cloning is a legal score-preserving selection at one **globally calibrated** fixed epsilon, after establishing the all-N calibration below. It is not automatically legal inside a previously fixed finite-N near-score problem. Independent clones preserve the old data and each row's prescribed Euler marginal, but change the joint action, receiver union, actual successor optimizer and generally `E D`. A full-gain proof must use that changed actual experiment. Synchronized clones preserve a different experiment and cannot provide independent-sampling savings.

Read the frozen R654 `NEXT_TARGET.md`, its report's complete near-score/calibration domain, and the cited finite-class definition: at most N labeled genuine cubes, positive **full** real ownership, all genuine AC KKT sources, one fixed epsilon, and successors remaining in the same class. No original-input restoration was re-proved here.

## 1. Closing the all-N calibration gap

Let `G_N` be the epsilon-independent full-owner geometry/volume projection of this class. Set

`A_N(e)=inf_(g in G_N) Q_e(g)/V(g)=1/T_N(e)`.

The inherited finite entropy comparison gives, on every fixed geometry, `Q_e/V` nonincreasing and 1-Lipschitz in e. Thus A_N is also nonincreasing and 1-Lipschitz, uniformly in N. Because the classes are nested, A_N decreases with N. This argument uses the same full-owner geometry class for every parameter; it would not apply to an epsilon-dependent restricted source/action subclass.

Write `epsilon_N=4 A_N(epsilon_N)` for the unique finite calibration. Nested classes imply `epsilon_N` is nonincreasing. With the known finite classical baseline `T_infinity(0)=sup_N T_N(0)<infinity` and the inherited calibrated comparison,

`4/[5 T_infinity(0)] <= epsilon_N`,

so `epsilon_N` decreases to a strictly positive epsilon_*. The uniform Lipschitz estimate gives the needed limit without exchanging a supremum and continuity:

`|A_N(epsilon_*)-epsilon_N/4| <= epsilon_N-epsilon_* -> 0`.

Since `A_infinity(epsilon_*)=inf_N A_N(epsilon_*)`, it follows that

`A_infinity(epsilon_*)=epsilon_*/4>0`,
`T_infinity(epsilon_*)=sup_N T_N(epsilon_*)=4/epsilon_*`.

In particular `T_infinity(0)<=T_infinity(epsilon_*)<=5 T_infinity(0)`. No unproved continuity of `sup_N T_N` is being assumed.

Now take the class `C_fin` of **all finite** genuine full-owner states at this single epsilon_*. It is successor-closed: a finite action, deletion of zero new owners, and normalization still produce a finite state at the same epsilon_*. Every actual old state and every actual successor has `kappa=epsilon_*R<=4`. Its score supremum

`Sigma_fin=sup_(C_fin and all AC sources)[R-LH/M]`

is finite and satisfies `T_infinity(epsilon_*)-4L<=Sigma_fin<=T_infinity(epsilon_*)`. An eta-near-score state obeys `R>T_infinity(epsilon_*)-4L-eta` and `kappa>4-epsilon_*(4L+eta)`. The supremum must be taken over all genuine states/sources, not just this resulting critical band. This supplies a lawful all-finite near-score domain for the proposed cloning selection.

In contrast, enlarging N at the old `epsilon_N` need not keep `epsilon_N T_(Nnew)(epsilon_N)<=4` or preserve proximity to the enlarged score supremum. Recalibrating to `epsilon_(Nnew)` changes the actual optimizer, moments and u. Keeping old mu, lambda and v after such a parameter change generally violates `m=d+epsilon v/lambda`. Uniform spatial dilation does not change epsilon. These are not harmless finite-N substitutions.

## 2. Exact cloning/splitting theorem at fixed epsilon

For each original row j choose finitely many positive fractions `theta_(j,l)` summing to one, and partition the actual nonatomic old I_j into measurable pieces `I_(j,l)` of volumes `v_(j,l)=theta_(j,l)v_j`. Give every piece a labeled copy of the **same** A_j and B_j. These are legitimate repeated labels with positive disjoint full owners; the old receiver union and its full ownership are unchanged.

For any trial clone packing put `Lambda_j=sum_l lambda_(j,l)`. Its packing feasibility is exactly original aggregate packing feasibility. At fixed Lambda_j, the logarithmic term is maximized uniquely at `lambda_(j,l)=theta_(j,l)Lambda_j`. The cloned objective reduces to the original objective plus the constant

`epsilon sum_j v_j sum_l theta_(j,l)log(theta_(j,l))`.

Therefore the **actual** cloned optimum has

`lambda_(j,l)=theta_(j,l)lambda_j`,
`m_(j,l)=d_j+epsilon v_(j,l)/lambda_(j,l)=m_j`,
`u_(j,l)=u_j`, `a_(j,l)=theta_(j,l)a_j`.

The old source mu itself remains a genuine AC KKT witness: every repeated row has moment m_j and the aggregate old load is unchanged. Consequently

`Q_cl=Q`, `V_cl=V`, `M_cl=M`, `R_cl=R`, `kappa_cl=kappa`,
`H_cl=H`, `Fscore_cl=Fscore`, `E_old,cl=E_old`.

The raw entropy optimum value has the displayed additive constant; it is not literally unchanged. The minset cost coefficients split as `w_(j,l)=theta_(j,l)w_j`, so their **sum**, the old cost, source LP and its complete minsets are unchanged. Tiny individual lambda does not create a new aggregate contact coercivity or source budget.

For equal r-way splitting the entropy constant is `-epsilon V log r`. The construction retains all old geometry and score exactly for every finite r. In the all-finite calibrated class of §1, an eta-near-score state therefore stays eta-near-score for arbitrarily large finite r. This is an existential selection freedom before anchors, with no score-limit error. It can be combined with the already audited positive-width product-source selection. No infinitely labeled action or zero-width source is needed.

## 3. What the Euler law preserves, and what it changes

Every cloned row must draw its own independent anchor

`X_(j,l) ~ mu|_(A_j)/m_j`.

Thus its marginal is exactly the original row law; the new full joint law is the larger independent product, not the original tuple with repeated coordinates. Its actual images are

`E_(j,l)=t_j I_(j,l)-b_j(y_j+X_(j,l))`.

Total image volume remains `sum_l |E_(j,l)|=ell_j`. For any fixed physical x, linearity also preserves the expected **incoming multiplicity density** summed over that parent, because the pieces would partition I_j at each fixed anchor. This does not make the independently shifted images a pathwise partition or preserve lost volume/union size.

Each clone has the full receiver `B'_(j,l)=Q(sigma_j y_j-b_j X_(j,l),t_j s_j/a)`, regardless of its small I piece. If `q_j(x)=P(x in B'_j)`, equal r-way independent cloning gives exactly

`E W_r=int [1-product_j(1-q_j(x))^r] dx`.

This generally increases with r; it is not the original expected receiver union. Actual image eligibility, baseline, available labels, p, alpha, Q', S, O and F all require recomputation. No invariance or monotonicity of actual Q' or D follows from the old-data equalities.

The tagged single-row marginal is preserved in the useful precise sense: choose a clone tag with probability `a_(j,l)/M`, then q uniformly in its real I piece. After forgetting l, `(j,q,X_(j,l))` has the original tagged parent distribution. The **owner evaluated at that transported point** depends on the entire larger tuple and is different. Thus the tagged physical identity is valid on the clone experiment but is not a comparison theorem between the two expectations.

If all clones instead share X_j, the independent-row hypothesis is false. Their empirical weights then recombine to a_j and there is no independent sample-size gain. Treating their lambda as small while perturbing the shared anchor requires perturbing the whole group and summing its costs. Tied copies cannot simultaneously preserve the original action and claim r independent observations.

## 4. A genuine sampling-stability benefit, with its exact domain

Equal independent cloning does improve deterministic old-source tests. Let the original finite old arrangement have B positive-mu cells, ignoring its mu-null boundaries. With

`muhat_r=sum_j (a_j/r) sum_(l=1)^r delta_(X_(j,l))`,

old saturation gives `E muhat_r=mu`. For a deterministic bounded test g,

`Var(muhat_r(g))=sum_j (a_j^2/r)Var_(P_j)(g)`.

More strongly, every actual adaptive old packing probe in the cloned experiment has the form

`f_Z(z)=sum_j [sum_l alpha_(j,l)(Z)]1_(A_j)(z)`, `0<=f_Z<=1` mu-a.e.

It is constant on those same **original** cells. Actual packing, `A_j subset C_(j,l)`, and AC sampling make the bound hold also at all empirical probes almost surely. For each cell, independent sampling bounds its mass variance by the corresponding sum of `a_j^2/r`; Cauchy over cells therefore gives

`E sup_(cell-constant |g|<=1) |int g d(muhat_r-mu)| <= M sqrt(B/r)`.

In particular this controls the **actual adaptive** f_Z without freezing alpha. The high-only empirical measure has mean `w_H mu` and the same bound with total high-tag mass in place of M; hence `|Gamma_H|<=M sqrt(B/r)` also follows. This is a finite-old-algebra uniform estimate, not an incorrect assignment of a single cube's VC dimension to arbitrary packing sums.

The B dependence need not become a final theorem constant: in the globally calibrated all-finite class one may choose a finite r as large as required for the desired absolute error, while preserving the old score exactly. For example `R|Gamma_H|<=zeta M` follows from `r>=B R^2/zeta^2`. This selection is unavailable if one insists on a fixed exhausted N. It also gives no uniform physical lost-copy estimate: the larger receiver union, actual optimizer and loss/reserve must still enter the same full D ledger.

Similarly, a small-clone-lambda estimate can be used when derived on the actual cloned experiment, but cannot be transferred back to the uncloned optimizer. A source-replacement or duplicate-label shortcut that preserves neither law nor full score is not justified by these concentration formulas.

## 5. Other variations and the full-gain acceptance criterion

- Fixed-geometry source selection with all moments fixed is lawful at the same epsilon: R, kappa and old owners stay fixed, and lowering H improves the **full** score. Choosing a positive-width near-minimizer before sampling is allowed; replacing sources after sampling or projecting anchors to minsets requires a separate action comparison.
- At fixed geometry and lambda, a changed AC source with row moments changed is lawful only together with `vtilde_j=lambda_j(mtilde_j-d_j)/epsilon`, real disjoint owner realizability and full receiver-union volume. Thus `nu(total)=epsilon(Vtilde-V)=0`; there is no free positive mass/R variation in the full-owner class.
- Arbitrary owner reassignment or a genuine geometric deformation must recompute lambda, source moments and H. Common translation/dilation is homogeneous and preserves the ratios; it gives no new gain. A minus-row joint-program comparison is not automatically an old KKT state, a near-score state or a fresh calibrated source account.

A successful use of cloning can prove the complete `E D_r>=cV-CLM` on the legally selected finite cloned near-score state and then apply the genuine same-class score inequality `Q'_r(F_next-F_old)>=D_r-4LQ'_r`. In the all-finite class this is a valid score-contradiction route: F_old is exactly the original near-score value, and the successor is a finite state at epsilon_*. It need not reproduce the original uncloned ED. Conversely, a proof only of small empirical correlation, small lambda, a comparison packing objective, or large receiver union without the actual Q'/loss/reserve counterpart does not meet this criterion. One global CLM/potential account remains; cloning does not multiply it.

## Actual local verification and stop

Executed one bounded installed-Python/SymPy check: exact residuals were zero for the two-piece clone moment identity, the additive entropy constant and H preservation. Calibration, independent-product probabilities and the finite-cell variance bound above are analytic proofs, not numerical scans. No source fixture, restored-constant computation, Git operation, API call or subdelegation was performed. This audit establishes the lawful global-class selection and its precise experiment; it does not certify a root-order full-gain bound.
