import os
from pathlib import Path
HERE = Path(__file__).resolve().parent
os.environ['OPENBLAS_NUM_THREADS']='1'; os.environ['OMP_NUM_THREADS']='1'
from fractions import Fraction as F
import mpmath as mp
import json, platform, time
w=F(1,65536); L=F(1,64)
rows=[(F(-127,64),F(3,2),F(1,8),[-1]),(F(0),F(7,2),F(1,4),[-1,1]),(F(127,64),F(3,2),F(1,8),[1])]
def interval(sign,width): return (F(-1),F(-1)+width) if sign==-1 else (F(1)-width,F(1))
def m(x): return mp.mpf(x.numerator)/x.denominator

def pieces(delta):
    models=[]; cuts=set()
    for y,b,h,signs in rows:
        c=(1+b)*y; comps=[]
        for s in signs:
            for width,weight in [(w,1-delta),(L,delta)]:
                if not weight: continue
                a,z=interval(s,width); wt=weight/len(signs)
                comps.append((a,z,wt,width))
                for X in (a,z):
                    for e in (-h,h): cuts.add(c-b*X+e)
        models.append((c,b,h,comps))
    return models,sorted(cuts)

def run(delta,r,dps):
    mp.mp.dps=dps; models,cuts=pieces(delta)
    # Recover q's affine coefficients exactly on each rational breakpoint cell.
    def qval(model,x):
        c,b,h,comps=model; out=F(0)
        for a,z,weight,width in comps:
            lo=max(a,(c-x-h)/b); hi=min(z,(c-x+h)/b)
            out+=weight*max(F(0),hi-lo)/width
        return out
    total=mp.mpf(0)
    for a,z in zip(cuts,cuts[1:]):
        if a==z: continue
        qa=[qval(model,a) for model in models]; qz=[qval(model,z) for model in models]
        if all(v==0 for v in qa+qz): continue
        av=list(map(m,qa)); dv=[m(v-u) for u,v in zip(qa,qz)]
        def fn(t):
            prod=mp.mpf(1)
            for v,d in zip(av,dv): prod*=1-v-d*t
            return 1-prod**r
        total+=m(z-a)*mp.quad(fn,[0,1])
    return total
start=time.perf_counter(); results=[]
for d in [F(0),F(1,8),F(1,64)]:
 for r in [1,8,64,512]:
  lo=run(d,r,35); hi=run(d,r,55)
  results.append({'delta':str(d),'r':r,'value':mp.nstr(hi,32),'precision_difference':mp.nstr(abs(hi-lo),6)})
  print(results[-1],flush=True)
out={'task':'TASK_NUM_EXPLORE_2','python':platform.python_version(),'mpmath':mp.__version__,'elapsed_seconds':time.perf_counter()-start,'results':results}
with open(HERE / 'explore_results.json','w') as f: json.dump(out,f,indent=2)
