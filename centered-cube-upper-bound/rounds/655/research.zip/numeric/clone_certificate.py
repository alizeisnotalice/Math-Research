from fractions import Fraction as F
from itertools import product
import json, platform, hashlib
from pathlib import Path
p=Path(__file__).resolve().parent/'clone_probe.json'
d=json.loads(p.read_text()); w=F(1,65536); R=F(15,272); M=F(16)
base=[(-F(127,64),F(4),F(3,2),-1),(F(0),F(8),F(7,2),None),(F(127,64),F(4),F(3,2),1)]
def union(intervals):
    arr=sorted(intervals); out=[]
    for l,h in arr:
        if not out or l>out[-1][1]: out.append([l,h])
        else: out[-1][1]=max(out[-1][1],h)
    return sum((h-l for l,h in out),F())
def geometry(r, signs):
    out=[]; images=[]
    for y,t,b,fixed in base:
        for i in range(r):
            X=F(fixed if fixed is not None else signs[i]); c=(1+b)*y-b*X
            out.append((c-t/32,c+t/32))
            left=y-F(1,32)+F(i,16*r); right=y-F(1,32)+F(i+1,16*r)
            images.append((t*left-b*(y+X),t*right-b*(y+X)))
    return out,images
results={}
for r in (1,2,4):
    sums=F(); counts={}; comparisons=[]
    for signs in product((-1,1),repeat=r):
        rec,images=geometry(r,signs); actual=union(rec); expected=F(3,4) if len(set(signs))==1 else F(1)
        assert actual==expected
        row=next(x for x in d['r'][str(r)]['rows'] if x['tag']==list(signs)); assert actual==F(row['W'])
        intersections=[(max(a,c),min(b,e)) for a,b in rec for c,e in images if max(a,c)<min(b,e)]
        image=union(intersections) if intersections else F()
        assert image==F(row['image_union']) and actual-image==F(row['F']) and 1-image==F(row['O'])
        sums+=actual; counts[str(actual)]=counts.get(str(actual),0)+1; comparisons.append(str(actual))
    mean=sums/F(2**r); assert mean==1-F(1,2**(r+1))
    lower=mean-13*r*w; upper=mean+13*r*w
    results[str(r)]={'counts':counts,'branches_verified':len(comparisons),'mean_W':str(mean),'AC_W_enclosure':[str(lower),str(upper)],'expected_D_lower':str(lower-R*M),'statuses':{status:sum(x['solver_status']==status for x in d['r'][str(r)]['rows']) for status in sorted(set(x['solver_status'] for x in d['r'][str(r)]['rows']))},'max_residuals':{key:max(x[key] for x in d['r'][str(r)]['rows']) for key in ['alpha_stationarity_residual','price_residual','owner_conservation_residual','packing_residual','full_ledger_residual']}}
# All source anchors are in [-1,1], so all new C contain their old A.
# Old source support is in the intersection A_C with A_L or A_R.
assert w<F(1,64)
assert F(11,128)-5*w>0
assert F(7,2)*w+F(1,2)<7-F(7,2)*w # center swept ranges separated
# exact old KKT and split old KKT
lambdas=[F(7,10),F(3,10),F(7,10)]; ms=[8,16,8]; eps=F(336,5)
assert all(F(m)==2+eps*F(1,16)/lam for m,lam in zip(ms,lambdas))
assert sum(lambdas[i]*2 for i in range(3))==F(17,5)
assert F(3,16)/F(17,5)==R
out={'python':platform.python_version(),'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'r':results,'r4_expected_D_lower':str(F(31,32)-52*w-R*M),'r4_mixed_branch_D_lower':str(1-52*w-R*M),'r4_all_same_geometry_bound':str(F(3,4)-52*w-R*M),'infinite_W':str(1+7*w),'outer_containment_margin_lower':str(F(11,128)-5*w),'old_KKT_verified':True}
kappa_lower=eps*F(results['4']['AC_W_enclosure'][0])/M
assert kappa_lower == F(333039,81920)
assert kappa_lower-4 == F(5359,81920)
out['r4_expected_kappa_prime_lower']=str(kappa_lower)
out['r4_expected_kappa_prime_above_4']=str(kappa_lower-4)
out['r4_calibrated_domain_conclusion']='positive probability kappa_prime > 4; fixed epsilon example cannot certify successor-closed kappa_prime <= 4 domain'
print(json.dumps(out,indent=2))
