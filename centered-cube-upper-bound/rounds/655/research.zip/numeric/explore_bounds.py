from fractions import Fraction as F
from pathlib import Path
HERE = Path(__file__).resolve().parent
import json, hashlib, platform, time
exec((HERE / 'explore_compute.py').read_text().split('start=time.perf_counter()')[0])
Q=10**18; N=2048

def floorq(v): return v.numerator*Q//v.denominator
def ceilq(v): return -((-v.numerator*Q)//v.denominator)
def mullo(a,b): return a*b//Q
def mulhi(a,b): return -((-a*b)//Q)
def power(a,r,up):
    val=Q; mul=mulhi if up else mullo
    while r:
        if r&1: val=mul(val,a)
        r//=2
        if r: a=mul(a,a)
    return val

def qval(model,x):
    c,b,h,comps=model; out=F(0)
    for a,z,weight,width in comps:
        lo=max(a,(c-x-h)/b); hi=min(z,(c-x+h)/b)
        out+=weight*max(F(0),hi-lo)/width
    return out

def bounds(delta,r):
    models,cuts=pieces(delta); low=F(0); high=F(0)
    for a,z in zip(cuts,cuts[1:]):
        qa=[qval(md,a) for md in models]; qz=[qval(md,z) for md in models]
        if not any(qa+qz): continue
        # q is affine within each exact breakpoint interval. Endpoint floors and
        # ceilings are integer-exact. All fixed-point operations round outwards.
        qs=[]
        for A,Z in zip(qa,qz):
            vals=[(A*(N-i)+Z*i)/N for i in range(N+1)]
            qs.append([(floorq(v),ceilq(v)) for v in vals])
        sl=sh=0
        for i in range(N):
            pmin=pmax=Q
            for q in qs:
                qmin=min(q[i][0],q[i+1][0]); qmax=max(q[i][1],q[i+1][1])
                pmin=mullo(pmin,Q-qmax); pmax=mulhi(pmax,Q-qmin)
            sl+=Q-power(pmax,r,True); sh+=Q-power(pmin,r,False)
        low+=(z-a)*F(sl,N*Q); high+=(z-a)*F(sh,N*Q)
    return low,high
start=time.perf_counter(); arr=[]
for d in [F(0),F(1,8),F(1,64)]:
 for r in [1,8,64,512]:
  a,b=bounds(d,r)
  obj={'delta':str(d),'r':r,'lower':str(a),'upper':str(b),'lower_float':float(a),'upper_float':float(b),'width':float(b-a)}
  print(obj['delta'],r, obj['lower_float'],obj['upper_float'],obj['width'],flush=True); arr.append(obj)
with open(HERE / 'explore_bounds.json','w') as f: json.dump({'task':'TASK_NUM_EXPLORE_2','Q':Q,'N':N,'elapsed_seconds':time.perf_counter()-start,'results':arr},f,indent=2)
