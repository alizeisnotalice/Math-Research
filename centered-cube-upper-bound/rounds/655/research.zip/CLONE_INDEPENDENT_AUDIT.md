# R655 全局有限复制／经验相关项：独立候选审核

**结论：PASS，但必须先使用全有限族上的固定全局 epsilon_*。在该接口下，任意选定有限近-score 旧状态可合法复制，并将新实验的实际 high correlation 付至 `R|Gamma_H^(r)|<=eta V`。这是真正消除该相关费用的可用预算，不是给 r=1 的原实验重新命名；完整物理 loss／leading cV 仍未证明。**

未读本轮作者推导；以下从冻结 R654 合同和主代理给出的复制候选独立推导。仅有界核验候选，不扩大 VC 路线或数值扫描。

## 1. 最关键量词：有限-N epsilon_N 不能直接任意增 r

若保持旧“至多 N”类的 epsilon_N，复制后有 rN 标签，不能直接沿用 `kappa_next<=4`。原有限-N 校准没有认证该扩类。这是候选必须先修好的接口。

合法替代是：在**所有有限 full-owner 状态**的并类上预先固定 epsilon_*，使

`epsilon_* T_inf(epsilon_*)=4`，`T_inf(e)=sup_N T_N(e)`。

这个全局校准不要求待证 root-order 上界。已核有限优化 lemma 给 `A_N(e)=1/T_N(e)` 非增且 1-Lipschitz；其 N 极限 `A_inf=inf_N A_N` 仍具有这些性质。恢复桥及任意粗糙有限维 weak bound给 `A_inf(0)>0`：例如有限 greedy-disjoint cube covering 的三倍扩张直接给 `C_n<=3^n`，所以 `T_inf(0)<=P3^n<infinity`。这里完全不使用目标 root-order。

函数 `e-4A_inf(e)` 连续严格递增，零端负，在 `e=4A_inf(0)` 非负，因此有唯一 epsilon_*>0；其根满足 `A_inf(epsilon_*)=epsilon_*/4>0`。有限-N roots 递减至该 epsilon_*（对任意 e>epsilon_*，有限-N 的同一函数最终为正）。这确认 proposed `lim epsilon_N` 接口的逻辑可行性；完整档案定位／正式全局校准由协调中的专门审核负责。

于是所有有限复制和有限 normalized successors 都属于同一固定 epsilon_* 比较类，统一有 `kappa<=4`、`kappa_next<=4`。score supremum 有限；选定一个有限近-score 状态后，可以再按其有限数据选择任意有限 r。不是在固定有限-N 类内偷偷扩大 N，也没有复制后重校准。

## 2. 真实旧状态复制保留全部旧 score 数据

固定一个有限旧状态，原标签 j 的真实 I_j 均分成 r 个正体积可测片，副本 `(j,l)` 的旧 A/B 几何相同，并置

`v_jl=v_j/r`，`lambda_jl=lambda_j/r`，`m_jl=m_j`，`u_jl=u_j`，`a_jl=a_j/r`。

仍使用原 AC 源 mu。重复约束下 load 逐点不变，且

`d_j+epsilon_*(v_j/r)/(lambda_j/r)=m_j`。

故原 mu 精确认证复制后实际 entropy KKT；正权下严格凹性给真实唯一 optimizer，并非仅固定一个未必最优的拆分向量。等价地，在固定 group aggregate lambda 时，clone entropy maximum 将其按 v 等分，目标只多常数 `-epsilon_* V log r`。

因此 `Q,V,M,R,kappa,H`、旧 source gap 和旧 score `mathcal F` 均精确保留。所有副本共同 partition 原 receiver union，仍是真实 full ownership。这里保留的是**旧 score**，不是新动作的 fill F。

每个副本随后抽全新、独立的 Euler anchor `X_jl~mu|Aj/m_j`。由此改变新 C/E、availability、baseline、实际 p/alpha、O/F/S 和 D 的分布；这些量没有被宣称与 r=1 相同。该实验改变在全 finite-class score 反证中合法，因为复制旧状态仍同样近-score。

## 3. 实际 joint optimizer 的适应性被固定旧 cells 的 TV 同时控制

对复制后的真实 new-C/owner joint optimizer，令

`beta_j(Z)=sum_(l=1..r)alpha_jl(Z)`。

由每个 `Aj subset C_jl`，

`sum_j beta_j1_Aj=sum_jl alpha_jl1_Aj<=sum_jl alpha_jl1_Cjl<=1` dx-a.e.，

所以 group beta 属于**原旧** `K_A`；这里没有固定 beta 或绕过新优化。alpha 在各副本配置的 unavailable 标签上取零，但全部旧副本都仍被抽样并进入经验源。

取原始有限 A 家族的 membership cells `D_1,...,D_B`，只计正 mu 质量的 cells。它们可以不连通；这里只用 membership 恒定，不用其几何凸性。B 有限、由复制前状态决定；复制重复 A 不会增加 B。原 source 的 load saturation 排除了 union 外的源质量。所有 samples 避开固定 A 边界 a.s.。

实际 coverage `f_Z=sum beta_j(Z)1_Aj` 在每个 cell 恒定且在 [0,1]，因此对任何该经验样本、所有实际适应 choices 同时有 TV 支配。无需 single-row stability、单 cube VC、selector curvature 或 uniform-in-N empirical rate。

## 4. 高经验源的精确有限-cell 误差与 r 的选择

保留 old high 集 H，置

`hat_mu_H^(r)=sum_(j in H,l<=r)(a_j/r)delta_Xjl`，

`mu_H=(sum_(j in H)lambda_j1_Aj)mu`。

两者总质量都严格为 `A_H=sum_H a_j`，均值正确，low 行没有删除或重新归一。令 `p_jb=mu(Aj intersect D_b)/m_j`、`e_b=hat_mu_H^(r)(D_b)-mu_H(D_b)`。独立性给

`sum_b Var(e_b)=(1/r)sum_(j in H)a_j²[1-sum_b p_jb²]`

`<= (1/r)sum_(j in H)a_j² <= M²/r`。

由于 `sum_b e_b=0`，对任何 cell-constant f in [0,1]，

`|integral f d(hat_mu_H^(r)-mu_H)| <=(1/2)sum_b|e_b|`。

Cauchy/Jensen 故给新实验实际 correlation 的界

`|Gamma_H^(r)| <= E sup_(beta in K_A)|integral f_beta d(hat_mu_H^(r)-mu_H)|`

`<= (1/2)sqrt[(B/r)sum_H a_j²] <=(M/2)sqrt(B/r)`。

忽略有利的 1/2，保守选择整数

`r >= B(1+kappa)²/eta²`（校准域可用 `r>=25B/eta²`）

即得

**`R|Gamma_H^(r)|<=eta RQ=eta V`。**

这里 B 可以非常大；r 也允许依赖所选有限旧状态及误差 eta，但最后价格 eta V 不含 B、标签数、尺度或层数。r 在 anchors 之前确定，不依赖观察样本或 good/bad 事件。不同 r 不必共享一次随机实验，因每次只选择一个有限 r 即可。若还想在同一次证明另付 bad-alpha fee，必须认识上述 bound 已包含整个 high Gamma，不能再把两个估计领取为独立正信用。

## 5. 没有被该预算解决的部分

high-only ghost identity 在每个新复制实验中照常成立，且保留 `S_low^ghost>=0` 与全部 `11/12 E_low`。本方法不需要先假定全部行 high、相近 m 或 small lambda；low 副本完整保留，high 误差只关于 mu_H。单份 M 是同一个旧源，未逐 cell／group／path 重领。

消去 Gamma_H^(r) 后，仍需在这个**新合法 near-score 克隆旧状态及其独立动作**上控制真实 tagged physical loss／receiver coverage、source reserve 和 fill，并留下 leading cV（eta 可取小于拟议正 margin）。没有证明原 r=1 的 Gamma 变小，也没有证明克隆后 D 自动正，或 O/F 相抵自动有利。复制可能显著改变 new receiver fill 和 lost-copy geometry；这正是剩余几何问题，不是经验 TV 估计的隐含结论。

若未来只允许一个预设有限 N、要求旧 owners 必须来自特定先前动作、固定副本 anchors 相同，或禁止改变 r=1 实验，则此候选不能直接使用；现冻结 full finite-class 合同不含这些限制。实际依赖 r 的后续几何常数也不能冒充 uniform L。

## 6. 审核证据与范围结论

已实际运行安装数学 Python/SymPy：clone KKT demand、entropy 常数差、独立副本 cell variance 的 1/r 缩放均精确零残差；保守阈值 `(1+4)^2=25` 得到实际计算核实。Cauchy、TV 支配、global-class 量词与 a.s. membership 由上述解析证明承担；未重跑过去数值或进行反例扫描。

**最终判断：** 先合法固定全有限族 epsilon_* 后，经验相关费用确可通过选择有限复制数支付至任意 `eta V`，适应性不是剩余缺口。固定-N epsilon_N 下直接任意复制则不合法。当前可以把完整 high Gamma 相关项从主几何障碍中移除，但不能宣称完整 D／正 cV／一般上界已闭合。只写本文件及配套受限 `EMPIRICAL_SCREEN.md`，未使用 Git/API/PDF/子代理、未读取凭据；交付后停止。
