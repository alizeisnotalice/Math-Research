"""R655 integrity and bounded certificate replay, not a general-bound proof."""
import argparse
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--replay', action='store_true')
args = parser.parse_args()
manifest = json.loads((root / 'MANIFEST.json').read_text())
files = {p.relative_to(root).as_posix() for p in root.rglob('*')
         if p.is_file() and '__pycache__' not in p.parts}
assert files == set(manifest) | {'MANIFEST.json'}
for name, digest in manifest.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
tex = (root / 'REPORT.tex').read_text()
labels = re.findall(r'\\label\{([^}]+)\}', tex)
assert len(labels) == len(set(labels))
assert set(re.findall(r'\\(?:ref|eqref)\{([^}]+)\}', tex)) <= set(labels)
assert not [c for c in tex if ord(c) < 32 and c not in '\n\t']
for name in ['FINAL_GEOMETRY_AUDIT.md', 'FINAL_LEDGER_AUDIT.md']:
    audit = (root / name).read_text()
    assert manifest['REPORT.tex'] in audit
    assert manifest['NEXT_TARGET.md'] in audit
audit = (root / 'NUMERIC_AUDIT.md').read_text()
for name in ['clone_certificate.py', 'clone_certificate.json',
             'explore_bounds.py', 'explore_bounds.json']:
    assert manifest['numeric/' + name] in audit, name
result = {'manifest_files': len(manifest), 'latex_labels': len(labels),
          'tex_compiled': False, 'replay': []}
if args.replay:
    env = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    with tempfile.TemporaryDirectory(prefix='r655-certificate-') as tmp:
        numeric = Path(tmp) / 'numeric'
        shutil.copytree(root / 'numeric', numeric)
        def run(name):
            cp = subprocess.run([sys.executable, str(numeric / name)],
                                env=env, cwd=tmp, capture_output=True,
                                check=True, timeout=120)
            assert not cp.stderr, (name, cp.stderr.decode())
            return cp.stdout
        clone = run('clone_certificate.py')
        assert clone == (root / 'numeric/clone_certificate.json').read_bytes()
        data = json.loads(clone)
        assert sum(v['branches_verified'] for v in data['r'].values()) == 22
        assert Fraction(data['r4_expected_D_lower']) == Fraction(23843, 278528)
        assert Fraction(data['r4_expected_kappa_prime_lower']) > 4
        result['replay'].append('22 exact branch geometries and AC r4 bound: byte-identical certificate')
        run('explore_bounds.py')
        fresh = json.loads((numeric / 'explore_bounds.json').read_text())
        old = json.loads((root / 'numeric/explore_bounds.json').read_text())
        assert fresh['Q'] == old['Q'] == 10**18
        assert fresh['N'] == old['N'] == 2048
        assert len(fresh['results']) == len(old['results']) == 12
        for actual, archived in zip(fresh['results'], old['results']):
            for key in ['delta', 'r', 'lower', 'upper']:
                assert actual[key] == archived[key]
            assert Fraction(actual['lower']) <= Fraction(actual['upper'])
        result['replay'].append('12 support-exploration integrals: identical rational endpoints')
print(json.dumps(result, indent=2))
