# R655 n=1 atomic r=2：actual entropy 与 linear cap 的独立诊断

**结论：PASS。same-sign 的 available/capture/baseline 与 entropy group claims 均合法。只用精确 Fraction 几何和 KKT，不依赖作者浮点 optimizer，已证明**

`E W_2=7/8`, `E Q'_2<=74/5`, **`E D_2>=1/17>0`**，

而真实 linear max-packing 的静态下界为

`E W_2-R Pi=-1/136<0`, `Pi=M=16`。

这是该冻结原子有限实验中一个严格的 entropy-credit separation；不是 AC、global-epsilon_* 校准或近-score 临界状态定理，也不是一般维数结论。

## 1. 读取范围与实际计算

只读 `/tmp/ccu_r655/numeric/clone_probe.py` 的定义与对应 JSON 的 r=2 exact fields。未执行原脚本、未 import/run CVXPY，未使用浮点 alpha、Qprime、D 或 solver residual 作为证据，未扩展 r=4 或其他参数。

输入绑定：

- `clone_probe.py` SHA-256：`30dff4fadb5abadb8ce197bf348bb1eb1dcdd30b496bbb43c3a10207c1e340f4`
- `clone_probe.json` SHA-256：`1f76884f44e6bcb409f191debe9cf876c08896e8caec096f69f4887af453497a`

已独立运行 Python `Fraction`：由原半边长、anchor 标签和真实 I 的两个等长片重新构造六个 E/B'/C，在所有有理 endpoints 间逐 atom 判断 incoming、capture eligibility、receiver union；只检查授权的四个 central tag branches。随后精确计算 entropy gradients 与所需期望。重建的四个 W 与 JSON r2 的 exact W 字段一致；该比较不使用 JSON 浮点优化值。

## 2. 几何与真正的 packing polytope

固定 `a=32`, `epsilon=336/5`, `R=15/272`, `M=16`。原组为 L,C,R，中心 `(-127/64,0,127/64)`，旧 halfside=1，原 I=B 长 `1/16`。每个组按从左到右两个长 `1/32` 的实际片复制，记 L0,L1,C0,C1,R0,R1。

outer anchors 分别固定 -1,+1；两个 central anchors 独立取 -1,+1，各概率 1/2。四个 tag 分支均概率 1/4。outer 新中心为 `+-443/128`、新 halfside=4；central 新中心为 `-(7/2)tag`、新 halfside=8。

六个新 C 在所有分支都共同包含正长度 interval

`[-69/128,69/128]`, 长 `69/64`。

故真正 dx-a.e. packing 的约束**恰好**是 `sum alpha<=1`、alpha>=0：公共正测交集给必要性，总 coefficient<=1 给充分性。此处没有用原子 source 上的 null-contact load 偷换 dx-a.e. packing。

每个分支都有可用的 central label，且最大 cube 系数 m 为 16，所以即使线性 packing 限定在实际 available labels，

`Pi=max sum m_j beta_j=16`。

该上界来自精确几何 simplex；central weight=1 达到。它不是将含 log 的实际 optimizer误判成 linear optimizer。

## 3. Same-sign availability、capture 和 baseline — PASS

same central sign 时，两 central images 恰好铺成同一长 `1/2` receiver；每个 image 是其一个长 `1/4` 半片。每个 outer 组的两个 images 同样铺成该组长 `1/4` receiver，各片长 `1/8`。

当 tag=(1,1)，central receiver 在负侧，完整覆盖 L receiver；正侧 R receiver 与它分离。L 的 C 右端为 `69/128<1`，不能 capture 旧 central A=[-1,1]，而 central C 包含全部旧 A。因此 L0,L1 在与 central images 重叠的全部正测区域都不 eligible；它们没有别的 image 或 fill eligible 区域，故确实 unavailable。R0,R1 各仅在自己的 image 半片上 eligible。central 每个半片只有对应 central copy 能合法拥有（另一 central copy 的 image 内部不在此处）。

tag=(-1,-1) 为对侧同一结论：R0,R1 unavailable，L0,L1 retained。Fraction atom 重建给：

| tag | available labels | 单 label 的强制 p |
| --- | --- | --- |
| (-1,-1) | L0,L1,C0,C1 | L_i=1/8，C_i=1/4 |
| (1,1) | C0,C1,R0,R1 | C_i=1/4，R_i=1/8 |

所有正测 eligibility sets 都是 singleton，没有 fill，故 `P={p}`、`p0=p`、`P_delta={p}`。固定 delta=1/100 的 baseline 和 free allocation 不能改变这些体积。旧被删除 incoming loss 仍在 O 中，不能因为 unavailable 而抹去。

## 4. Same-sign 实际 entropy 聚合与严格 KKT — PASS

令 central group 总权 gamma、外侧 retained group 总权 omega。重复 C 几何的 packing 只约束 `gamma+omega<=1`；线性／log 目标递增，实际 optimum 饱和。固定 group 权时，两个等 p 的副本由严格凹性等分。因此 group 目标等于

`16 gamma+8 omega+epsilon[(1/2)log gamma+(1/4)log omega]`

减去固定常数 `epsilon(3/4)log2`。这正是 r1 两 retained groups 的实际 entropy 程序，而不是固定-alpha 重分 p。

取

`gamma=7/10`, `omega=3/10`，

即 `alpha_Ci=7/20`, `alpha_Oi=3/20`。Fraction 实算：

`16+epsilon(1/4)/(7/20)=64`，

`8+epsilon(1/8)/(3/20)=64`。

所有正 label gradients 都等于 positive simplex multiplier 64，且 `2(7/20)+2(3/20)=1`。这给完整严格 entropy KKT，故为唯一实际 optimum；joint 程序因 p 已 forced，也在此取最优。于是 same-sign 分支严格有

`Q'=2[16(7/20)+8(3/20)]=68/5`，

`D=3/4-R(68/5)=0`。

## 5. 完整四分支与保留 O/F 的期望界

独立 Fraction 逐 atom 计算如下；mixed 分支没有假定其 alpha、p 或 Q 相同，也没有求其浮点 optimum。

| tags (C0,C1) | W | image union | F | O | 用于结论的 Q' |
| --- | --- | --- | --- | --- | --- |
| (-1,-1) | 3/4 | 3/4 | 0 | 1/4 | 68/5，精确 |
| (-1,1) | 1 | 43/64 | 21/64 | 21/64 | <=16 |
| (1,-1) | 1 | 53/64 | 11/64 | 11/64 | <=16 |
| (1,1) | 3/4 | 3/4 | 0 | 1/4 | 68/5，精确 |

旧总增长为 `E=2/17`，复制不变。mixed 分支 O=F，故完整账 `D=E+RS>=2/17`，与 `W-RQ' >=1-16R=2/17` 一致；没有丢 fill、删除 loss 或旧 source slack。

四分支均匀平均给

`E W=(3/4+1+1+3/4)/4=7/8`，

`E Q' <=[2(68/5)+2(16)]/4=74/5`，

**`E D=E W-R E Q'>=7/8-(15/272)(74/5)=1/17`**。

相反，linear cap 一律取 Pi=16 给

`7/8-(15/272)16=-1/136`。

因此 actual entropy 至少保留

`R(Pi-E Q') >=(15/272)(16-74/5)=9/136`

的期望 gain，相比静态 cap 的负值严格改善至正值。作者浮点 mean_D 没有参与此认证；本下界可以比其浮点结果保守。

## 6. 决策范围

该诊断严格证明：在这个有限原子 r2 实验中，把实际 entropy Q' 换成 linear max-packing Pi 会丢掉足以改变净 gain 符号的收益。因此这种 relaxation 不能被当作“无损地保留 actual entropy benefit”。但它没有否定所有大 R 几何路线或其允许 CLM 余量的版本。

本模型 `R=15/272<1`，没有 near-score 证书，source 原子不是当前要求的 AC source。更强地，每个 mixed 分支 `W=1,Q'<=16`，所以

`kappa'=epsilon W/Q'>=epsilon/16=21/5>4`。

故整个 r2 law 也不能处于要求所有 successors `kappa'<=4` 的 global-epsilon_* calibrated class。same-sign exact KKT 不自动给正宽或 epsilon_* 域的推广；未进行该类连续性／接触稳定性证明。

**最终 PASS 于授权的 atomic r2 四分支诊断。** group claims 合法，`E D_2>=1/17` 是精确完整期望下界；物理全类正 cV 仍缺，不能据此宣布一般上界或 AC 预算已证。仅写本审计，未用 CVXPY/Git/API/PDF/子代理，未扩扫描；交付后停止。
