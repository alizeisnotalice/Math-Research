# R655 有界历史索引（只读）

## 检索范围与口径

- 仅查 `rounds/631`–`rounds/654/research.zip` 内 `REPORT*`、`NEXT_TARGET*` 成员；用 Python `zipfile` 读取并先按 duplicate/clone/splitting/synchronized/all-N、epsilon、锚/来源等词筛选，再看命中上下文。没有解压到目录。
- 以下是此范围内的命中与相邻直接相关结果；未命中仅表示这批轮次/这些文本中未找到，不代表全史没有。
- 文件行号为 zip 成员内原始行号；数学内容只按报告自述归纳，不在此认证。

## 轮次索引

| 轮次 | 直接相关记录 | 对当前问题的边界 |
|---|---|---|
| 632 | `REPORT.tex:268–270`：有限盒交叠模式按 incidence masks 枚举，并删除重复模式（duplicates removed）。 | 是模式去重，不是复制旧标签、克隆新动作或标签权重同步。 |
| 637 | `REPORT.tex:120–165`、`numeric/REPORT.md:9,11`：每个宏中心可放 K=1,2,4 个水平 clone；有真实 AC 来源饱和/矩、接收并集及有限证书。sigma=9/10 时用每宏组首个 clone 赋权；sigma=1 时验证器重建旧/候选 incidence patterns 并去重。 | 是有限几何 clone 家族及来源/并集记账；不能读成独立抽样旧标签方案或全 N 校准。报告明确这些有限控制不推出 hard-family 或维数阶定理。 |
| 651 | `REPORT.tex:318–360`：比较两个真实 AC 来源，分别重优化旧动作；明确称新中心为“actual independent anchors”，给出 A、B 两种来源下中心分离范围，并计算两锚乘积律。`REPORT.tex:399–407`：把接触拆成 2n channels 本身不足以省掉平方根；同一预算不能按 label/cell/scale 重新发放。 | 找到的是独立锚及逐来源重优化，不是同步锚。未检得将同步锚等同于独立锚的结论。 |
| 652 | `REPORT.tex:445–448`：source-channel budget 不得重复支出。 | 预算不重复的约束；未见把旧标签克隆独立化的合法性结论。 |
| 653 | `NEXT_TARGET.md:3,5`：固定 epsilon Eulerian 路线、真实独立 Euler 锚律，统一 label/scale 常数的完整目标。`:29` 提醒被侵入 owner 不自动是 KKT 状态，不应给它独立来源额度。`:33` 明确“true label duplication must split old I and its weights”。`REPORT.tex:642–648` 给窄支撑 AC 来源的实际旧 KKT witness；`:716–767` 有 k=2,3 的两分支锚动作/clone-center 计算，完整期望与更窄的 owner-only 条件记录有明确区分，且 k edges 收集不同真实 image regions，不表示同一点同时有 k copies。 | 明确要求真实标签重复时拆分旧 I 与权重；clone-center 案例是有限两分支/固定族，不是把标签简单复制后仍保留完整旧 owner。独立锚语境；未见同步锚。 |
| 654 | `NEXT_TARGET.md:3–5`：同一 full-owner surrogate 类、固定 calibrated epsilon、真实旧熵 lambda/AC KKT 来源、独立 Euler anchors；要求 uniform in label count and scale range。`:11–24`：合法来源自由是在采样前、固定几何与 I 后选旧 AC 来源；坐标仅在 source-cell tag 条件下分解，整体是 product-mixture，宽度可随 eta→0，不能假设统一密度/正宽度/共同接触坐标。`:71` 记载 full-class bridge 的固定校准 epsilon_N。 | 这是本范围内最直接的全标签数/尺度统一、固定校准 epsilon 与合法采样前来源选择记录；虽有独立锚，但没有“稀有来源探索之后克隆旧标签”的明示构造。不能据此声称同步锚或独立克隆已经证明。 |

## 对当前窄问题的去重结论

- **已涉及 duplicate/clone/splitting：** 632（模式去重）、637（几何 clone）、653（真实标签重复须拆分旧 I/权重；有限 clone-action 计算）。这些含义不同，不能合并成同一“克隆标签”结果。
- **锚类型：** 651、653、654 文本明确写 independent anchors / independent Euler anchor laws；在检索的 631–654 `REPORT/NEXT_TARGET` 成员中，没有找到相应的 synchronized-anchor 构造或定理。这里仅报告本范围未找到。
- **固定全 N epsilon 校准：** 654 明确固定 calibrated epsilon 并要求对 label count、scale range 一致；`:71` 讨论 `epsilon_N` 的 full-class bridge。653 提到固定 epsilon 但核心目标同样标为尚未证明。不要把这个参数校准桥接误记成克隆策略的证明。
- **稀有来源探索后克隆：** 631–654 指定文本中未找到这一完整顺序/术语。653 的窄支撑 AC 来源和小宽度 `w` 族属于真实来源/有限诊断，另有 clone-center 案例；报告未把二者表述为“先探索稀有来源、再合法克隆旧标签”的方法。
