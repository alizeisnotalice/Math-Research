# R655 independent audit of rare exploratory sources

**Verdict: the finite exploratory-source construction and the stated order of selection are legal.** They can provide full feasible-cell support at arbitrarily small positive score cost. This audit does not prove the separate geometric expansion/full-gain inequality. It neither constructs an infinite-clone optimizer nor asserts convergence of D, alpha or the joint objective.

## 1. Exact feasible support and construction

Fix one genuine finite old state, its actual full owners, epsilon, positive lambda, moments m, and the full coordinate arrangement. Let P_r range over its positive-volume **open** saturated coordinate cells, with interior membership K_r and `sum_(j in K_r)lambda_j=1`. Each such cell is bounded: K_r is nonempty and the cell lies in every A_j for j in K_r. Thus there are finitely many relevant bounded rectangles of finite positive volume.

Let

`T={tau>=0: sum_(r:j in K_r)tau_r=m_j for every j}`.

It is nonempty by the existing actual AC source. Saturation gives `sum tau_r=M`, so it is compact. Define the feasible support index set

`F={r: there exists tau in T with tau_r>0}`.

This is a nonempty finite set. For each r in F, select one witness `tau^(r) in T` with `tau^(r)_r>0`, and let `taubar=|F|^(-1)sum_(r in F)tau^(r)`. Convexity gives `taubar in T`; moreover `taubar_r>0` for every r in F and is zero outside F. These choices depend only on the deterministic old state, not sampled anchors. No uniform lower bound on taubar_r is required or supplied.

Define

`mu_explore=sum_(r in F) [taubar_r/|P_r|]1_(P_r) dx`.

It is a finite AC measure, has each exact old moment m_j and total mass M, and is saturated for the same lambda. Hence it preserves the true old entropy KKT equations, actual unique optimizer, v, Q, V, kappa and full ownership. The construction does not put atoms on any old contact face or treat a repeated coarse membership pattern as a single rectangle.

All admissible AC sources at these fixed moments give zero mass to cells outside F: their induced cell masses belong to T, so positive mass there would itself be a witness contradicting the definition of F. Boundaries have zero AC mass. Thus `D=union_(r in F)P_r` is precisely the maximal feasible **essential** source domain. The exploratory density is strictly positive everywhere on D; its topological support is closure(D).

The required row-specific domain is

`D_j=union_{r in F, j in K_r}P_r`.

It is nonempty because m_j>0. The support of `mu_explore|_(A_j)` is closure(D_j). In general one must not replace this by `support(mu_explore) intersect A_j`: a boundary point may belong to closed A_j although the adjacent supporting cell does not contain row j. The row law and all coordinate mixture formulas must keep interior cell tags. No ambient boundary memberships enter the moment constraints.

## 2. Mixing and the score cost

Let mu_near be any actual AC KKT source with the same moments and old data. For fixed `0<delta<1`, set

`mu_delta=(1-delta)mu_near+delta mu_explore`.

Both terms have the same exact row moments and mass, so the mixture is again a genuine old source for the same actual optimizer and owners. The potential is linear at these fixed data. For every such source, `0<=H<=kappa M` follows directly from `h_j<=1`. Therefore

`F(mu_delta)=F(mu_near)-delta L[H(mu_explore)-H(mu_near)]/M`
`             >=F(mu_near)-delta kappa L`.

Starting with an eta/2-near-score state and taking `delta<=min(1/2,eta/(2 kappa L))` yields an eta-near-score mixture. If a previous product-source approximation has its own positive tolerance, its score expense and this one must be assigned disjoint portions of eta. No exact source minimum, uniform source width or exact source-cost equality is needed.

If mu_near is the legally selected R654 product-box source, the mixture is a finite mixture of product components (inner boxes and full cells). A full cell may carry two components. Coordinate factorization is conditioned on both the cell/component tag; the unconditioned law remains a mixture of products. If mu_near is arbitrary, the source is still legal, but one cannot call its entire density a finite product mixture without an additional choice of mu_near.

## 3. Support reachability and finite cloning quantifiers

For each fixed delta>0, mu_delta has strictly positive density from its exploratory part throughout every feasible cell. Its row-specific support is closure(D_j), independently of how small delta is. A source-coordinate probability may be proportional to delta, but positivity of the full-receiver marginal need not shrink its reachable set.

Precisely, let `q_(j,delta)(x)=P_(mu_delta|Aj/mj)(x in B'_j)`. The action has b_j>0 and a receiver of positive radius. Its coordinate anchor window is a nondegenerate rectangle. Since D_j is a finite union of open rectangles with strictly positive exploratory density,

`q_(j,delta)(x)>0`

if and only if that anchor window meets D_j (equivalently, has positive-volume intersection with it). This is the union of B'_j(z) over z in D_j. It is a finite union of bounded open axis rectangles. Using closure(D_j) can add only their finite collection of boundary faces, irrelevant to receiver Lebesgue volume. Thus the Lebesgue measure

`W_reach=|{x: some j has q_(j,delta)(x)>0}|`

is independent of delta>0. This statement is about full receivers, not source-disjoint incoming images, and does not assert a lower bound on W_reach.

In the globally calibrated all-finite class established in `CLASS_VARIATION_AUDIT.md`, choose the mixture first, fixing a strictly positive delta, and then make an equal finite r-way split of every old I_j. Draw all cloned row anchors independently from that fixed mixture. The exact expected full-receiver union is

`E W_(r,delta)=int [1-product_j(1-q_(j,delta)(x))^r] dx`.

For that fixed delta, the integrands increase to the indicator defining W_reach. They are dominated by one bounded finite geometric receiver envelope because anchors remain in the bounded old cubes. Monotone/dominated convergence therefore yields convergence of **this scalar receiver expectation** to W_reach. Equivalently, for each desired positive receiver tolerance there exists a sufficiently large **finite** r. The necessary r may depend arbitrarily on delta, geometry, tiny feasible cell weights and the desired tolerance. No uniform rate is claimed; no final theorem constant may silently inherit those dependencies.

The lawful order is: select a genuine near-score old state; choose the deterministic exploratory witnesses and a positive delta within its score budget; then choose finite r, before any anchors; run the actual finite independent Euler experiment and recompute the full policy/alpha. The cloned old score is preserved exactly. One must not first set delta=0, interchange delta and r limits, use one infinite tuple as an optimizer input, or infer convergence of the actual packing/owners, Q', D or ED from convergence of W alone.

In particular the source may have rare exploration and receiver reachability independent of that rarity because many genuine independent trials are permitted. This is valid only with the previously proved all-finite fixed-epsilon calibration, or with enough capacity inside a genuinely fixed finite-N class. It does not authorize enlarging N at an unrelated old finite-N calibration.

## 4. Verification and precise stop

Executed one bounded installed-Python/SymPy check of the exact mixed-source score identity; its residual was zero. Feasible-cell positivity, KKT preservation and probability/limit statements above are analytic arguments. No source fixture, geometry-expansion calculation, numerical scan, Git operation, API call or subdelegation was performed. The remaining workers must still prove a complete finite-experiment geometric/full-gain inequality with actual adaptive alpha and all costs. This audit supplies the source/support/quantifier interface only.
