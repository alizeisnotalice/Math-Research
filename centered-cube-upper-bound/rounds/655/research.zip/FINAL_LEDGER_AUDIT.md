# R655 最终总账独立整合审核

**结论：PASS（限于下列已证 reduction、完整符号／量词和证据范围的正确整合）；无阻塞项。一般中心立方体 root-order 弱 `(1,1)` 上界、完整正 cV 余量和受控全状态递推仍未证明。**

## 冻结版本绑定

已实际读取、核对初稿相关各节，并在 signed/absolute 表述修正后补核该段和最终 SHA：

| 文件 | 最终 SHA-256 |
| --- | --- |
| `/tmp/ccu_r655/REPORT.tex` | `5215755e3ff61901e879c27b2d487c89567a63db20b7fd5cb7a09a311d1a47e0` |
| `/tmp/ccu_r655/NEXT_TARGET.md` | `839b9a33275b24dc236da029acf5fb6114c96154ad7357d0e5787b76526ad320` |

最初送审的 REPORT SHA `d84f4638c90f56885c501297cbf7f5c8f5acc2fca1b52d33b6f600a871367a6f` 已被上述修正版取代。本审计不绑定该旧版为最终交付。

本次为整合独审，沿用已经独立完成的 `CLONE_INDEPENDENT_AUDIT.md`、精确 Fraction `ENTROPY_DIAGNOSTIC_AUDIT.md` 和先前 restoration/correlation 审核，不重跑已通过数值。另从定义核对 reachable packing、净 deficit 恒等式及必要／充分方向。没有仅以作者的结论文字代替下述判断。

## 1. 全 N 校准与近-score／复制取序 — PASS

全族 `A_N(e)` 的共同 1-Lipschitz、非增性及有限 N roots 的定义整合正确。旧零参数粗维数界只用于固定 n 的 finiteness，不是使用待证 root-order 结论；有限 roots 的正下界和 Lipschitz squeeze 确保 `epsilon_N downarrow epsilon_*>0`，并给

`A_inf(epsilon_*)=epsilon_*/4`，`T_inf(epsilon_*)=sup_N T_N(epsilon_N)=4/epsilon_*`。

报告先固定该 global epsilon_*，再从所有有限实际状态取有限 near-score 旧状态。此时任意有限复制及有限 normalized successor 都仍在同一类中，故 kappa、kappa_next<=4。没有在旧有限-N epsilon_N 下暗增标签，也没有复制后重校准仍假称旧源数据不变。

真实 I 的等体积划分、lambda/r 和同一旧 AC 源精确保持实际旧 entropy KKT、Q/V/M/R/kappa/H/E 与旧 score；新 anchors 独立，实际新 eligibility、baseline、p/alpha、O/F/S/D 全部重算。保留的是旧 score，不是原 r=1 实验的结果。

源近似／正探索的 score 费用分配到互不重复的容差，固定 xi>0 后才选足够大有限 r。对固定正 xi，receiver scalar residual T_r→0 可用于选择这个有限 r；没有先令 xi=0、交换两个极限或使用无限-label optimizer。稀有 cell 质量只影响选择多大的有限 r，不进入最终 L/CLM 系数。

## 2. 实际适应性与整项 high correlation — PASS

实际 clone alpha 按原标签聚合后 `beta_j=sum_l alpha_jl` 属于原旧 K_A，由 `Aj subset Cjl` 和真实新 packing 直接推出。它是重新优化后才作的测试聚合，未被当作实际新 optimizer 的替代品。

旧有限 membership algebra 的 B 在复制时不增加。high empirical 源与 mu_H 的总质量完全相同；有限-cell variance 为 `r^(-1)sum_H a_k²(1-sum_b p_kb²)`，TV 同时支配所有 cell-constant [0,1] 测试，包括实际适应 coverage 与 unavailable 标签变化。因此

`E|hat_mu_H,r(f_r)-mu_H(f_r)| <=(M/2)sqrt(B/r)`。

修订段现在正确写明：**有符号 discrepancy 的期望才是 Gamma_H,r**，并使用 `|E discrepancy|<=E|discrepancy|`。没有将 absolute expectation 等同于 signed Gamma。

按旧状态数据、在 anchors 前选择 `r>=B(1+kappa)^2/zeta²`，可付 `R|Gamma_H,r|<=zeta V`。这是实际新实验整项 high correction 的预算，不再仅是 bad/good split。报告和 NEXT_TARGET 都禁止重复领取旧 bad-alpha 费用，且不再把 good-alpha stability 当作无法消除的独立核心缺口。low tags 未删除、未误归一，也没有另花可避免的 low covariance。

## 3. 全物理账本与单一势能 — PASS

报告保留全部有限-r 恒等式：

`D_r=E-O_r+F_r+R S_r=W_r-RQ'_r`，

`E D_r=A_r+R Gamma_H,r`。

A_r 中仍有实际 clone loss indicator、u/epsilon_* 物理价格、旧 low/high 增长、F、Delta_low 与匹配的 high/low ghost reserve。`Delta_low>=0` 只在原旧临界域 `kappa>=7/2` 使用。相关项被压小没有抹掉这些物理费用，更没有自动产生 cV。

每个真实有限 successor 的 score 只付一次 endpoint allowance `4LQ'<=4LM`。如果改走 multistep，真实质量权重、每步 next O/F/S、归一化增长、高 R/低 kappa 域和 terminal/summability 仍须保留；终稿没有宣布这条递推已闭合。

删除源质量在完整 D 中继续具有有利符号；辅助 B-value repair 的正 Qdel/epsilon 没有被重新记作物理 adverse loss。也没有把 grouped clone source mass 错降为 1/r。

## 4. Π 与 core LP：从定义核验 benchmark 的方向 — PASS

Π 定义在真实 reachable expanded **cubes**、其真实 volume costs m_j 和 genuine dx-a.e. packing 上。它是有限 subfamilies 的 linear optimum 上确界，不是 actual entropy optimum，也未假设 attainment。

每个 actual realized finite clone packing 是其中的可行 family，故 `Q'_r<=Pi`。对任意 finite reachable family，Aj 包含在对应 C 内；旧 mu 为 AC，所以其 packing 可积分得到 `sum beta m_j<=M`。这直接认证 Pi 有限及 Pi<=M。若使用 product tags/core aggregation，cores 包含 Aj、实际 C 包含各自 core，故 `Pi<=Qbox<=M` 的上界方向一致；Qbox 的 costs 仍是 m_j，不能误当作 core rectangles 的真实体积来套零参数 cube 定理。

对每个 finite reachable cube subfamily，receiver 恰为 C/a，真实 full-owner 零参数定义给其 union volume `<=T0` 乘该 finite linear optimum。以 finite receivers 穷尽 reachable union，即得

`Wreach<=T0 Pi`，`T0=T_inf(0)`。

这里没有对 arbitrary boundary membership 额外造 row law；域是 row-specific feasible-cell support closure。上述比较不把 Π、Qbox 或某个 comparison packing beta 等同于实际 joint entropy optimizer。

因此 `Wreach-RPi<=(T0-R)Pi` 及 `Wreach-RQbox<=(4L+eta)M` 是一致的条件强度 screen。`R>T0` 的条件、非 constructed high-R near-score 反例的范围和“静态路线只是较强充分路线”的地位均保留；没有由静态 comparison 失败反推 actual target 失败。

## 5. 精确净 deficit 恒等式、必要与充分 — PASS

独立从定义代入：

`Delta_r=Pi-E Q'_r>=0`，`K=T0 Pi-Wreach>=0`，

`T_r=Wreach-E W_r>=0`。

则

`E D_r=E W_r-R E Q'_r`

`=(Wreach-RPi)+R Delta_r-T_r`

**`=R Delta_r-(R-T0)Pi-K-T_r`**。

所有符号正确，尤其 K 和 T_r 均为负费用。若完整目标成立，则当然必须有较弱必要式

`R Delta_r >=(R-T0)Pi+cV-CLM`。

反之，仅证明该弱式不能恢复目标，因为还要扣 K+T_r。终稿与 NEXT_TARGET 均明确指出这个必要／充分区别，没有因 r 增大可消 T_r 就假称 K 也消失。也未宣称 Delta_r 的大小、单调性、收敛或与 core LP 相等。

真正未付问题因此是上述**净表达式**的统一 lower bound，或等价 A_r/full tagged-loss 证明，包含 actual entropy/availability deficit、static gap K 与所选有限 r 的 coverage error。actual maximum linear packing 不是 actual entropy optimizer；把前者替换后者会丢掉本轮明确要求保留的收益。

## 6. r2 atomic、r4 AC 及校准域 — PASS 于整合范围

此前已独立 Fraction 认证的 r2 四分支诊断按原范围整合：same-sign 的 singleton eligibility 强制 central p=1/4、outer p=1/8，梯度 64 认证 alpha=7/20、3/20 与 Q'=68/5；mixed 只需 Q'<=16。因此 `E D_2>=1/17`，而有限-r static bound `E W_2-RPi=-1/136`。至少 9/136 的 entropy advantage 没有被误写为浮点观察。

报告特别区分该 finite-receiver bound 与 Wreach 的无限-clone scalar 极限，未据 r2 断言 `Wreach-RPi<0`。r2 是 atomic、无 AC/epsilon_* 域证明，mixed successors `kappa'>=21/5>4`；此范围准确。

r4 的 positive-width AC 证书使用精确 receiver enclosures 与实际 `Q'<=M`，因而给完整 `E D_4>=23843/278528>0`，不是仅 W 增长或浮点 optimizer 的 strict sign。它又有 `E kappa'_4>=333039/81920>4`，所以某些 successors 超过校准 cap；旧 numeric critical band 不足以把它纳入 all-finite epsilon_* near-score 域。r1 AC 的 exact E D=0 与 r2 没有 strict AC optimizer 认证的区别均清楚。

此次未重算数值、未重认证 solver/JSON 或 rare-grid 全部 enclosure；认证的是已通过证据的结论与域没有在终稿越界。浮点 residual／tie-selector 限制和 rare-exploration 非交换极限亦未被隐去。

## 最终交付判断

**PASS，无剩余阻塞项。** 可以按“全局合法有限复制消除经验相关项、全 feasible-cell exploration、精确净 entropy-deficit/coverage 合同及有限证据”交付。不能按一般弱型改善、完整 physical gain 或闭合 recursion 已证交付。新的真正未付项是实际净 `R Delta_r-(R-T0)Pi-K-T_r`，而非重复的 good-alpha 稳定性标签或另一次 bad-alpha 费用。

仅写本审计；未修改作者文件，未用 Git/API/PDF/子代理，未读取凭据。交付后停止。
