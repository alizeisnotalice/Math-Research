# TASK_NUM_CLONE_1: actual cloned Euler action

Three-row R653 state, each old label split into r=1,2,4 identical cube labels. Partition each genuine old receiver I into r consecutive equal intervals and divide its old λ by r; keep the same AC μ, m, u, ε, and old KKT. Clone anchors are independent draws from the same conditional Euler law. For w=0 we enumerate all 2^r center-anchor sign tuples, each with weight 2^-r; the left/right anchor endpoints are fixed. Each full tuple recomputes images, receiver union, capture eligibility, δ=1/100 baseline, and the joint owner/entropy optimizer. This is a finite atomic-limit diagnostic for the optimizer, not itself a genuine AC state.

| r | complete atomic E W (exact) | atomic E Q′ (numerical) | atomic E S (numerical) | atomic E D (numerical) |
|---:|---:|---:|---:|---:|
| 1 | 3/4 | 13.599998324 | 2.400001676 | 0.0000000924 |
| 2 | 7/8 | 13.881659839 | 2.118340161 | 0.109467288 |
| 4 | 31/32 | 14.095919420 | 1.904080580 | 0.191401503 |

The r=1 exact baseline is Q′=68/5, S=12/5, D=0; the displayed small numerical deviation is solver error. On the mixed r=2 tuple (-1,+1), exact geometry gives W=1, image-union length=43/64, O=F=21/64, while the numerical actual joint solution has Q′≈14.75051421 and D≈0.18655253. Thus fill and the lost incoming images are both retained; fill is not silently omitted. The r=4 optimization has one `optimal_inaccurate` status among 16 tuples, so all Q′/D values are numerical diagnostics and no exact sign certificate is claimed for them. The numbers show that recomputed Q′ changes in this finite limiting model; they do not establish a strict Q′ change for a positive-width AC source.

## Exact W and actual positive-width separation

In the atomic limit the center receiver can occupy either interval of length 1/2 centered at −7/2 or +7/2. The outer receivers are contained in the corresponding center interval. If all r center anchors have the same sign, W=3/4; if both signs occur, W=1. Hence

`E W_r(0)=1−2^(−r−1)`, and `lim_(r→∞) E W_r(0)=1`.

This uses all 2^r branches, not a representative. The original actual AC source has r independent central anchors sampling the two inward source boxes with equal probabilities. For w=1/65536, couple every draw to its same-sign endpoint. Each cloned B′ translates by at most b_j w; the symmetric-difference length is at most 2b_j w. Since two outer rows have b=3/2 and the center has b=7/2, the union symmetric-difference bound is

`|E W_r(w)−E W_r(0)| <= 2r(3/2+7/2+3/2)w = 13 r w`.

This yields rigorous AC bounds [49139/65536,49165/65536] for r=1; [28659/32768,28685/32768] for r=2; and [15859/16384,15885/16384] for r=4. They are disjoint and hence prove strict changes of complete expected W for this one legal positive-width family. In fact the known R653 r=1 result is exactly 3/4 throughout its support.

Under an infinite iid coupling, center anchors become dense in both source intervals almost surely. The two disjoint swept center receiver intervals each have length `1/2+7w/2`; the outer receiver ranges are contained in them (the atomic margin is 11/128 and the possible relative displacement is at most 5w). Monotone convergence gives `lim_r E W_r(w)=1+7w=65543/65536` for this width. This is an infinite-clone receiver-union result; it does not supply an infinite-dimensional owner optimizer or an additional growth budget.

## Joint program and diagnostic precision

The script forms exact Fraction interval arrangements of actual E and B′, and for each image atom retains only incoming labels whose new C contains every incoming high old A. On fill it admits the receiver labels. All realized new C intervals share a positive intersection, so the packing is exactly `sum alpha <= 1`; exact common intersection length is 69/64. The script minimizes the actual convex relative-entropy objective on the finite eligible atom allocation polytope with δ=1/100. Baseline is equal sharing on eligible labels; α and p are solved together separately for each full anchor tuple. Clones with no eligible measure have zero α. Old rows, including deleted ones, are retained in O, and `D=E−O+F+RS=W−RQ′` is checked tuplewise.

Clarabel status was optimal for both r=1, all four r=2, and 15 of 16 r=4 branches, with the remaining r=4 branch optimal_inaccurate. Across the final run, maximal α stationarity residuals in objective units were approximately 1.10e−6, 5.92e−6, 9.86e−6 for r=1,2,4 respectively; maximum free price residual was 3.04e−7; maximum owner conservation residual 1.7e−12. The reported α and q are numerical optimizer outputs, not exact KKT or uniqueness certificates; where clones tie, the returned primary optimizer has no independently certified canonical secondary selector. The W bounds above use only exact interval geometry and do not depend on the optimizer.

## Reproduction and scope

Run:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r655/numeric/clone_probe.py > /tmp/ccu_r655/numeric/clone_probe.json
```

Actual run: Python 3.12.14, NumPy 2.5.4, CVXPY 1.9.3, Clarabel 0.11.1, process-internal elapsed 0.086 s; one process, OpenBLAS and OMP threads set to 1. Script and JSON preserve every branch, p, q, α, eligible atoms, status, and ledger. The frozen state has old R=15/272<1 and is not a general near-score or critical-hard-state result. The countably infinite W observation does not certify the global theorem, any general multiplicity payment, or a value of Q′ for positive w.

SHA-256: `clone_probe.py` `30dff4fadb5abadb8ce197bf348bb1eb1dcdd30b496bbb43c3a10207c1e340f4`; `clone_probe.json` `1f76884f44e6bcb409f191debe9cf876c08896e8caec096f69f4887af453497a`.

## Successor calibration scope

For the genuine positive-width r=4 action, actual packing and old source saturation imply `Q′<=M=16`. Together with the rigorous lower bound `E W_4>=15859/16384`, this gives

`E kappa′_4 = epsilon E(W_4/Q′) >= (epsilon/16) E W_4 >= 333039/81920 = 4+5359/81920`.

Thus `kappa′_4>4` with positive probability. This fixed-epsilon, low-R example cannot certify membership in the all-finite calibrated ε* domain or test a main geometric lemma that requires every successor to satisfy `kappa′<=4`.

The same bound `Q′<=16` and the exact physical ledger yield a strict actual positive-width lower bound, independent of numerical optimizer precision:

`E D_4=E(W_4−R Q′) >= 15859/16384−(15/272)*16 = 23843/278528 > 0`.

This is a finite-model result and does not establish the calibrated hard-state theorem.
