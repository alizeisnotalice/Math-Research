# TASK_NUM_EXPLORE_2 — support exploration, n=1

Inputs: old centers −127/64, 0, 127/64; old halfside 1; a=32; source masses 8 in each of the two signs; w=1/65536. Outer rows (m,t,b)=(8,4,3/2), center (16,8,7/2); B′ center (1+b)y−bX and halfside t/32. For each sign, conditional anchor law is (1−δ) uniform on the original width-w inward interval plus δ uniform on the whole inward width-1/64 cell. The center row draws each sign with probability 1/2. All clone draws are independent, and row m values are unchanged. We calculate only expected receiver union W.

For each row the conditional coverage probability is exactly a sum of rational-weighted source-window intersections, divided by the source interval widths. Its breakpoints are c−bX±h for source endpoints X, c=(1+b)y, h=t/32. Therefore q_j is rational piecewise affine and the exact desired integral is ∫[1−∏(1−q_j(x))^r] dx.

| δ | r | numerical value | rigorous lower | rigorous upper |
|---:|---:|---:|---:|---:|
| 0 | 1 | 0.75000000 | 0.74999996 | 0.75000004 |
| 0 | 8 | 0.99810686 | 0.99810681 | 0.99810692 |
| 0 | 64 | 1.00010024 | 1.00010018 | 1.00010030 |
| 0 | 512 | 1.00010598 | 1.00010592 | 1.00010603 |
| 1/8 | 1 | 0.75000000 | 0.74999520 | 0.75000480 |
| 1/8 | 8 | 1.02155725 | 1.02154626 | 1.02156824 |
| 1/8 | 64 | 1.08285558 | 1.08282929 | 1.08288185 |
| 1/8 | 512 | 1.10596322 | 1.10593644 | 1.10598986 |
| 1/64 | 1 | 0.75000000 | 0.74999936 | 0.75000064 |
| 1/64 | 8 | 1.00144103 | 1.00143933 | 1.00144272 |
| 1/64 | 64 | 1.02341225 | 1.02340168 | 1.02342281 |
| 1/64 | 512 | 1.08257426 | 1.08254802 | 1.08260048 |

The displayed interval endpoints are rounded outward. The exact rational bounds are in explore_bounds.json: subdivide each rational affine piece into N=2048 cells; bound each q_j using its endpoints, form outward-rounded fixed-point bounds for ∏(1−q_j) and its rth power using integer arithmetic with scale 10^18, and multiply by exact rational cell length. Thus the integral is enclosed independent of quadrature. Numerical estimates separately use 35- and 55-digit mpmath quadrature on the same exact pieces; precision agreement is diagnostic, while the rational bounds certify accuracy. The largest full enclosure width is 0.000053406.

These certified values exhibit a support-exploration effect: at r=512 the δ=1/64 lower bound already exceeds the δ=0 upper bound by more than 0.08244. Compare δ=1/8,r=64 with δ=1/64,r=512: both have δr=8 and W≈1.083. The transition is governed qualitatively by rare full-cell draws on the scale r≈1/δ; the grid does not establish a universal scaling law or a sharp threshold. At r=1, W=3/4 for all three mixtures.

For δ>0 the center-row anchor support consists of the two complete width-1/64 cells. Its two disjoint swept receiver intervals each have length 1/2+(7/2)/64=71/128; the outer-row sweeps lie inside them. For δ=0 replace 1/64 by w. For any x in the interior of a swept interval, at least one q_j(x)>0, so monotone convergence gives

lim_{r→∞} EW_r(δ)=71/64 for δ>0, whereas lim_{r→∞} EW_r(0)=1+7/65536.

For every fixed r, dominated convergence gives lim_{δ↓0} EW_r(δ)=EW_r(0). Hence the limits δ↓0 and r→∞ do not commute. These are one-dimensional receiver-union results only; they do not give α, Q′, D, or a general-dimensional result.

Reproduce from the directory containing the scripts, for example `python explore_compute.py` and `python explore_bounds.py`, using Python with mpmath installed. The scripts read and write beside themselves; the original run used `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`. A separate scratch-directory run reproduced all 12 exact rational endpoint pairs. Python 3.12.14; mpmath version and timing recorded in explore_results.json; fixed-point bound parameters and timing in explore_bounds.json. OPENBLAS_NUM_THREADS and OMP_NUM_THREADS are set to 1. No CVXPY was run.

SHA-256:
- explore_compute.py: cffb36910ac9fdbd5adf2419291a212395c167d7f10718e3727b50dd435eb210
- explore_bounds.py: 59ffbf2db022c5bf303340f4e2addfac2c29060f24e1fec6df2f92fe1dfe64b7
- explore_results.json: cba70288255bdaa923338112b6003eb20fcddea74a25b64ec8f8f382988df52c
- explore_bounds.json: 2a09c573e7a362767f40db19c67e31d2850d58220bb75e38e465f5abe5b48c8a
