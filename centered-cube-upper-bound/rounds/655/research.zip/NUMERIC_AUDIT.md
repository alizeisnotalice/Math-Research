# Independent clone geometry and packing audit

Scope: fixed R653 one-dimensional old AC KKT state, w=1/65536, r=1,2,4. This is a low-R example, not a critical-state or general theorem.

## Exact finite geometry

Independently reconstructing every clone receiver and every clone image using Fraction arithmetic, union/intersection arrangements agree with all 22 saved branches, including W, image union inside receiver union, F=W−image, and O=1−image. The W counts for r=1,2,4 are respectively 2, 2, 2 branches with W=3/4 and 0, 2, 14 branches with W=1. Therefore E W(0)=3/4, 7/8, 31/32. Clone center receivers of each sign coincide, and each outer receiver lies within the corresponding central receiver; all sign tuples are counted.

Couple each AC anchor with its same-sign endpoint. Each clone's receiver translates at most b_j w. The interval symmetric difference is at most 2b_j w, and a union is Lipschitz under the sum of these differences. Thus |E W(w)−E W(0)|≤2r(3/2+7/2+3/2)w=13rw. The claimed enclosures are correct: [49139/65536,49165/65536], [28659/32768,28685/32768], and [15859/16384,15885/16384]. They are pairwise disjoint. The r=1 value is exactly 3/4 on support by the R653 geometric argument.

For infinite independent central draws, each of the two source intervals is visited densely almost surely. Their swept central receivers each have length 1/2+7w/2 and remain disjoint. The outer swept intervals are contained in their corresponding central swept intervals: the atomic containment margin is 11/128 and a conservative worst relative displacement is 5w, leaving 5627/65536>0. Monotone convergence gives E W_r(w)→1+7w=65543/65536. This says nothing about an infinite-dimensional optimizer.

## Actual old state and new packing

R653 defines old halfsides 1, centers −127/64, 0, 127/64, full old receivers of length 1/16, ε=336/5, λ=(7/10,3/10,7/10), and μ with mass 8 and constant density 8/w on each of [−1,−1+w] and [1−w,1]. Because w<1/64, the left source interval belongs exactly to left and central old A, and the right exactly to central and right old A, apart from null endpoints. Thus m=(8,16,8), M=16, old packing density is λ_L+λ_C=λ_C+λ_R=1 μ-a.e., and m_j=2+ε(1/16)/λ_j. This supplies the actual AC KKT multiplier and strict concavity gives the stated optimizer. Splitting each receiver into r equal positive owners and each λ into λ_j/r leaves the summed old packing, stationarity, Q=17/5, V=3/16 and R=15/272 unchanged. Each clone's conditional anchor is independent with the appropriate original conditional μ law.

For every actual anchor tuple, X_j∈A_j, and t_j=1+2b_j implies old A_j⊂C_j. The new optimizer satisfies ∑α_j 1_Cj≤1 Lebesgue-a.e.; μ is AC, hence the same holds μ-a.e. Therefore Q′=∑α_j μ(A_j)≤∫∑α_j 1_Cj dμ≤μ(ℝ)=16=M, including clones and deleted rows extended by α=0. This argument uses the old AC μ, not a supposed new KKT source and not numerical solver output.

Using the full ledger D=W−RQ′, pointwise Q′≤16 and R=15/272, the proven AC enclosure implies

    E D_4 ≥ 15859/16384 − 15/17 = 23843/278528 > 0.

This is a rigorous positive expected full D for this specific positive-width low-R model, with arbitrary valid successor owner/packing optimizer. Moreover, every mixed-sign r=4 event has W≥1−52w, hence D≥32547/278528>0 pointwise. The elementary bound is negative on all-same-sign branches and does not prove D>0 on those individual branches. No floating optimizer calculation is needed for these assertions.

## Solver diagnostics and reproducibility

The pre-existing JSON reports 2/2 and 4/4 optimal statuses for r=1,2, and 15 optimal plus one optimal_inaccurate for r=4. Maximum reported α stationarity residuals are 1.0934e−6, 5.9166e−6, 9.8518e−6, respectively; maximum reported free-price residual 3.0384e−7, maximum owner-conservation residual 1.6242e−12. These are diagnostic only. No solver was rerun and no numerical optimizer is certified.

Executed the portable `clone_certificate.py` from an independent scratch directory containing its sibling `clone_probe.json` (Python 3.12.14, stdlib fractions); its stdout matched `clone_certificate.json` byte for byte. Checked source and result with `shasum -a 256`. Existing probe metadata records NumPy 2.5.4, CVXPY 1.9.3, Clarabel 0.11.1.

SHA-256:
- clone_probe.py: 30dff4fadb5abadb8ce197bf348bb1eb1dcdd30b496bbb43c3a10207c1e340f4
- clone_probe.json: 1f76884f44e6bcb409f191debe9cf876c08896e8caec096f69f4887af453497a
- clone_certificate.py: bb62375f29a8185363045b1d997b15853e3b133fde536262db01f2b266dde1a0
- clone_certificate.json: 72a6c0d661fc72d035d5d9e2331a5bbfe32e42ad80790c027e2dc57b338db8e5

## Independent audit of support-exploration bounds

The 12 integer/fraction bounds in `EXPLORE_COMPUTE.md` are valid for the listed discrete combinations δ∈{0,1/8,1/64}, r∈{1,8,64,512}. They do not certify an unlisted continuum of δ or r. The separate quadrature outputs remain numerical diagnostics. No CVXPY was run.

For a single component X uniform on [a,z], writing c=(1+b)y and h=t/32, x∈[c−bX−h,c−bX+h] is equivalent to (c−x−h)/b≤X≤(c−x+h)/b. The intersection formula in `qval` therefore gives the correct component probability, with widths and center-sign weights as specified. Its possible slope changes occur exactly among c−ba±h and c−bz±h; `pieces` includes these for every nonzero component in every row. Thus the sorted grid partitions the complete support and includes all breakpoints. In each resulting cell the three q functions are affine, so their extrema over every one of the 2048 subdivisions occur at endpoints. Outside the extreme cuts every q is zero.

With Q=10^18, integer floor/ceiling of q enclose each q. Subtraction reverses endpoints: Q−ceil(qQ) ≤ Q(1−q) ≤ Q−floor(qQ). Every factor is nonnegative and multiplication with `mullo`/`mulhi` rounds toward −∞/+∞. Induction through products and binary exponentiation yields lower/upper enclosures on P^r where P=∏(1−q_j); subtracting from one reverses endpoints again. Exact positive rational cell lengths preserve inequalities when summed. Independent clone draws give P^r exactly, so these are integral enclosures. The outward-decimal endpoints in the report are consistent with the exact fractions.

At r=1 the actual receiver union is pointwise 3/4 for all δ∈[0,1]: the outer corresponding to the central sign is contained in the center receiver even at full-cell width, because 11/128−5/64=1/128>0, while the opposite outer receiver stays disjoint. For δ>0 the central law has positive density throughout both width-1/64 cells. For each fixed x in the interiors of their swept receiver intervals, 1−P(x)^r tends to 1 as r→∞; outside both sweeps all three coverage probabilities vanish by outer containment. Dominated convergence proves the first limit 71/64 for every fixed δ>0 and 1+7/65536 at δ=0. For every fixed finite r, dominated convergence gives continuity as δ↓0; consequently lim_{δ↓0}lim_{r→∞} E W=71/64, while lim_{r→∞}lim_{δ↓0} E W=65543/65536. This does not assert joint convergence for arbitrary δ(r), a scaling law, or a general root/critical-state result.

Reproduction: copied the final portable `explore_bounds.py` and its sibling `explore_compute.py` into an independent scratch directory and ran the former with `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` (Python 3.12.14). The exact lower and upper fractions and parameters for all 12 entries matched the archived `explore_bounds.json`; elapsed times may differ. The exact lower bound for the δ=1/64 versus δ=0 gap at r=512 is 553258893969796583196187/6710886400000000000000000 > 2061/25000 = 0.08244. No CVXPY was run.

Final artifact SHA-256:
- `explore_compute.py`: cffb36910ac9fdbd5adf2419291a212395c167d7f10718e3727b50dd435eb210
- `explore_bounds.py`: 59ffbf2db022c5bf303340f4e2addfac2c29060f24e1fec6df2f92fe1dfe64b7
- `explore_results.json`: cba70288255bdaa923338112b6003eb20fcddea74a25b64ec8f8f382988df52c
- `explore_bounds.json`: 2a09c573e7a362767f40db19c67e31d2850d58220bb75e38e465f5abe5b48c8a
- `EXPLORE_COMPUTE.md`: 751dd62077ec56c87a998531db6c99c2333b34c15625826aed41ebee8b73c8d8
- `COMPUTE_REPORT.md`: 0174f37f1698280384f2ef5b1b2d3d91c351d13b2c3974ab40077f4708748297

## Successor calibration-domain correction

For each actual r=4 positive-width tuple, Q′>0 and Q′≤16, so κ′=εW/Q′≥(336/5)W/16. Taking expectations and using the exact enclosure above gives

    E κ′_4 ≥ (336/5)(15859/16384)/16
           = 333039/81920 = 4 + 5359/81920 > 4.

All operations are exact Fraction arithmetic. Therefore κ′_4>4 with positive probability; otherwise its expectation would be at most 4. The fixed-ε toy is not a successor-closed calibrated family with κ′≤4 almost surely, and cannot certify the main calibrated geometric budget. The previously proven positive-width AC bound E D_4≥23843/278528 remains valid independently of that calibration restriction. No CVXPY rerun was made.

Exact fields were added to `clone_certificate.py`/`.json`; prior clone results are preserved. Final hashes are listed above. The script reads its input relative to its own location.
