# Next target: the actual entropy-deficit/coverage net budget

The general centered-cube n^(1/2+o(1)) weak (1,1) bound remains UNPROVED. Continue the actual full-owner cube class with a=32n, arbitrary finite labelled families, actual old entropy/KKT AC sources, independent Euler anchors, and the fixed-delta=.01 joint capture/minimum-price owner program. Recompute actual eligibility, baseline, p and alpha from the whole tuple. All old/deleted incoming tags and physical loss/fill remain. The target is E D>=cV-C L M with L=C0 sqrt(n) polylog(n), uniform in labels/scales, where exactly

    D=E_growth-O+F+RS=W-RQ'=W-(1+kappa)V+RS.

There is one actual old source reserve and one final successor-potential allowance of at most 4LM. No source allowance can be renewed per clone, cell, layer, scale, coordinate, path or comparison configuration.

## The correlation issue has a legal resolution

On a fixed geometry/positive-owner vector, Q_e/V is globally nonincreasing and 1-Lipschitz for all e>=0, including packing-face changes and the linear endpoint. For the epsilon-independent full-family classes A_N(e)=inf Q_e/V, the finite calibration roots epsilon_N=4A_N(epsilon_N) decrease to epsilon_*>0. The inherited fixed-dimensional zero-parameter bound and the uniform Lipschitz squeeze prove

    A_infinity(epsilon_*)=epsilon_*/4,
    sup_N T_N(epsilon_N)=T_infinity(epsilon_*)=4/epsilon_*.

Use this ONE epsilon_* for ALL finite states and successors, hence kappa,kappa_next<=4. Arbitrarily increasing N at an old finite-N epsilon_N, or recalibrating after cloning while pretending old mu/lambda/u stay fixed, is invalid.

After selecting a finite near-score old state, split every actual I_j into r deterministic positive equal-volume pieces, and use labelled copies of the same A/B with v_j/r,lambda_j/r. The actual old clone entropy objective differs only by -epsilon_* V log r, so the same source/m/u and all Q,V,M,R,kappa,H,E and old score are preserved EXACTLY. The anchors are fresh independent draws for every clone. This changes the successor experiment; synchronized copies cannot supply sampling savings.

For the actual cloned alpha, beta_j=sum_l alpha_jl belongs to the ORIGINAL old packing polytope because Aj subset Cjl. The adaptive coverage f=sum beta_j 1_Aj lies in [0,1] on the fixed original finite source algebra. With B its positive-mu cell count, finite-cell total variation gives the entire high correction

    |Gamma_H^(r)| <= (M/2)sqrt(B/r).

Choosing finite r>=B(1+kappa)^2/zeta^2 (conservatively 25B/zeta^2) AFTER fixing that original state, but BEFORE anchors, gives R|Gamma_H^(r)|<=zeta V. B determines how many finite clones to choose; it is NOT a final theorem coefficient. This controls the ACTUAL adaptive optimizer and unavailable labels without a stability theorem. The entire Gamma is controlled, so do not continue to name Gamma_good as an ineliminable core gap or spend the old bad-alpha fee again as a separate credit.

Every finite cloned experiment still has its full tagged physical identity, with the actual lost indicator, u/epsilon_*, all high/low old growth, fill, Delta_low>=0 (only on its old critical domain), and the matching high/low ghost reserve. Small Gamma is not permission to delete the remaining physical terms. Equivalently use the exact D=W-RQ' form throughout.

## Full feasible-cell exploration and the correct order of limits

For fixed old row data, form the real saturated coordinate-arrangement cells P_s and compact feasible mass polytope tau>=0, sum_{s:j in K_s}tau_s=m_j. Let F contain cells capable of positive mass in SOME feasible tau. Averaging one witness for each feasible cell gives an actual AC source mu_explore uniformly positive on every such cell, with all moments and the actual old optimizer unchanged. Other admissible AC sources have zero mass outside these cells.

Mix mu_xi=(1-xi)mu_near+xi mu_explore with a fixed xi>0 chosen before anchors. The score drops by at most xi kappa L. If using the inherited product-box near-source approximation as well, give its L theta kappa error and this exploration error disjoint portions of the near-score tolerance. The row-specific support is closure of D_j=union_{s in F,j in K_s}P_s, not arbitrary boundary memberships in support(mu) intersect Aj. No uniform feasible mass, width, density or anti-concentration constant is needed.

For each fixed positive xi, the receiver-reachable volume Wreach is independent of the rarity xi. If q_j(x)=P_mu_xi|Aj/mj(x in B'_j), independent cloning gives

    E W_r=int[1-prod_j(1-q_j(x))^r]dx,
    T_r=Wreach-E W_r>=0, T_r→0.

The finite r required may depend arbitrarily on xi, tiny cell masses and geometry; it can simultaneously make T_r and R|Gamma_H| smaller than prescribed positive margins. The legal order is: global epsilon_*; finite near-score state/source; fixed positive exploration within score tolerance; sufficiently large FINITE r; then independent anchors and actual whole-tuple optimization. Do not set xi=0 first, exchange the two limits, posit a limiting owner/alpha, or use one infinite-label optimizer as a state.

## The exact remaining contract retains actual entropy advantage

Let T0=T_infinity(0), the original zero-parameter full-family ratio. Define Pi as the supremum of linear VOLUME packing mass over finite subfamilies of ACTUAL reachable expanded cubes C_j(z), z in the row's reachable support, with objective m_j=|C_j(z)| and genuine dx-a.e. packing. It is a benchmark, not a substitute for the joint entropy optimizer.

If product support tags J_q are used, their swept receiver rectangles P_jq and common cores K_jq satisfy actual Q'_r<=Pi<=Qbox<=M, where Qbox is the corresponding finite core-packing LP with fixed m_j costs. Applying the defining ZERO-parameter inequality to finite reachable cube subfamilies and exhausting the receiver union gives

    Wreach<=T0 Pi.

Thus Wreach-RPi <=(T0-R)Pi, and Wreach-RQbox is no larger. It is nonpositive for R>T0, and is at most (4L+eta)M on the inherited near-score class. This is a conditional strength screen: replacing actual entropy by maximum linear packing can erase exactly the advantage a full gain needs. It is NOT a constructed high-R near-score counterexample and does not disprove the actual target. A positive core/static-maxpacking certificate cannot be assumed equivalent to it or expected to hold merely from local complementary face motion.

Define the genuine nonnegative quantities

    Delta_r=Pi-E Q'_r,
    K=T0 Pi-Wreach,
    T_r=Wreach-E W_r.

The complete net identity is

    E D_r=(Wreach-RPi)+R Delta_r-T_r
         =R Delta_r-(R-T0)Pi-K-T_r.               [ACTUAL NET TARGET]

The next decisive theorem must lower-bound THIS expression by cV-C L M on legally selected finite cloned near-score states, or give an equivalent actual tagged-loss/coverage proof. It must keep K and the finite coverage error T_r. Proving only the necessary weaker inequality R Delta_r>=(R-T0)Pi+cV-C L M while dropping K is insufficient. One may use T_r→0 only after fixing positive exploration and choosing finite r; K does not vanish by that limit.

Delta_r retains the actual entropy/availability deficit relative to static linear packing. There is no theorem that it is small, large, monotone, or equal to a core LP quantity. The actual optimizer, positive baseline and image-priority support must be used if estimating it. Grouped clone weights can remain of order M; they have no favorable 1/r source-mass factor. Individual free-price optimality is not a minimum-price theorem for group averages. Deleted source mass keeps its favorable sign in full D; the Qdel/epsilon fee from an auxiliary B-value repair is not an adverse physical price.

The proved coordinate complement for product tags may be used as a local input: a receiver face velocity plus its opposite core-face velocity equals 2b_js_j(1+1/a), while each core face moves outward. A global argument must count only genuine exterior receiver growth and the NET change of one actual source/entropy objective; redundant contacts and packing rebalancing can cost no linear LP value. Initial right-hand positive-volume contact jumps cannot be omitted; terminal tau=1 zero-volume contacts receive no hypothetical 1+ packing credit. The comparison rectangle path is not a legitimate intermediate cube/KKT state, so near-score stationarity cannot be asserted along it. No coordinate/tag/scale source allowance is permitted.

## Evidence limits and what not to rerun

The r=1,2,4 toy is the real R653 AC source with epsilon=336/5, R=15/272<1. The 22 width-zero full-tuple joint-program branches are optimizer diagnostics (one r4 optimal_inaccurate status, residuals/uncertified tie selector retained). The independent positive-width certificate w=1/65536 uses exact union geometry plus actual Q'<=M to prove r1 exact E D=0 and r4 complete E D>=23843/278528>0; this is stronger than a W-only observation. It proves the changed independent experiment can change full gain despite identical old score, not a general theorem.

The separate exact r2 atomic diagnostic proves all four branches: same-sign owners are forced with central p=1/4, outer p=1/8; actual alpha=7/20 and 3/20 has gradients 64 and Q'=68/5. Mixed branches use only Q'<=16. Thus E D2>=1/17 while the FINITE receiver linear bound E W2-RPi=-1/136 with Pi=16. This proves a strict finite entropy-credit separation, not that Wreach-RPi is negative; it is atomic/non-AC and mixed successors have kappa'>=21/5>4. No new model is needed to rediscover this distinction.

This toy is NOT the all-finite calibrated interface: its E kappa'_4>=333039/81920>4, so some successors violate the calibrated cap. The strict finite-model D result survives, but it cannot validate a calibrated near-score budget.

The rare-exploration computations rigorously enclose 12 listed (xi,r) receiver integrals with fixed-point integer/Fraction arithmetic; mpmath quadrature is corroboration only. At this fixture, lim_r E W_r(xi)=71/64 for every xi>0, but at xi=0 it is 65543/65536; the limits do not commute. No universal xi r scaling law, continuum parameter certificate, Q'/optimizer limit or general-dimensional rate follows. Do not launch unrelated scalar/fixture scans in place of proving the actual net target.

If the direct net theorem fails, the alternative must still be a fully priced whole-state recursion at the same epsilon_*, with every future overlap/fill/slack, normalization factor, actual mass weight, high-R/low-kappa domain and terminal/summability cost. A new representation, core contact count, or renewed empirical bound is not a root-order proof. The inherited no-a^n original-input restoration remains conditional on completing the uniform actual budget.
