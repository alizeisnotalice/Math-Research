#!/usr/bin/env python3
"""R160 actual 1D normalized kernel overlaps; quadrature is exploratory."""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,math,sys,warnings
ROOT=Path(__file__).resolve().parent
COUNTS={'phi_float':0,'C_float':0,'quad_pieces':0,'phi_mp':0,'C_mp':0}
SP=MP=None
GL={}

def Cfun(d):
    COUNTS['C_float']+=1;d=abs(float(d))
    if d==0:return 1.
    E=lambda x:float(MP.expint(4,MP.mpf(x))) if x else 1/3
    return 1-d+1/3-E(1)-E(d)+E(d+1) if d<=1 else E(d-1)-2*E(d)+E(d+1)
def phi(x):
    COUNTS['phi_float']+=1;r=abs(float(x));E=lambda x:float(MP.expint(3,MP.mpf(x))) if x else .5
    return 1-E(.5-r)-E(.5+r) if r<=.5 else E(r-.5)-E(r+.5)
def mp_phi(x):
    COUNTS['phi_mp']+=1;r=abs(x);h=MP.mpf('.5');E=lambda k,x:MP.mpf(1)/(k-1) if not x else MP.expint(k,x)
    return 1-E(3,h-r)-E(3,h+r) if r<=h else E(3,r-h)-E(3,r+h)
def mp_C(d):
    COUNTS['C_mp']+=1;d=abs(d);E=lambda x:MP.mpf(1)/3 if not x else MP.expint(4,x)
    if not d:return MP.mpf(1)
    return 1-d+MP.mpf(1)/3-E(1)-E(d)+E(d+1) if d<=1 else E(d-1)-2*E(d)+E(d+1)
def root_upper(q,den=8,digits=80):
    scale=10**digits;lo=0;hi=max(scale,(q.numerator*scale**den//q.denominator)+1)
    while lo+1<hi:
        mid=(lo+hi)//2
        if mid**den*q.denominator<=q.numerator*scale**den:lo=mid
        else:hi=mid
    r=F(lo,scale);return r if r**den==q else F(lo+1,scale)
def exp_negative_upper(x,N=256):
    assert x>=0;t=a=F(1)
    for j in range(1,N+1):t*=x/j;a+=t
    return 1/a

def tail_bound(s,L,d,R,theta=F(1,8),remote=False):
    # Rigorous analytic majorant using C(d)>=1/4 exp[-4(d+1)/3].
    if not s:return F(0)
    a=1-theta;coeff=root_upper((s/L)**a.numerator,a.denominator)
    if not remote:
        rate=a/L+theta;X=rate*R-F(1,2)-theta*d-F(4,3)*theta*(d+1);assert X>0
        return 2*coeff*root_upper(F(4)**theta.numerator,theta.denominator)*exp_negative_upper(X)/rate
    # 2 sinh(1/2)>1, so its negative theta power <=1.
    rates=[a/L-theta,a/L+theta];assert min(rates)>0
    return coeff*sum(exp_negative_upper(r*R-a/2)/r for r in rates)

def integrate(s,L,d,theta=F(1,8),remote=False):
    sf,Lf,df,tf=map(float,[s,L,d,theta]);a=1-tf;c=Cfun(df);assert c>0
    if sf==0:R=L/2
    elif remote:R=F(80)/(1-theta)/L if False else F(48)/( (1-theta)/L-theta )
    else:R=max(d+F(1,2),L/2)+40
    rf=float(R);breaks=sorted({-rf,rf,0.,-Lf/2,Lf/2}|({df-.5,df+.5} if not remote else set()));breaks=[x for x in breaks if -rf<=x<=rf]
    def f(x):
        p=((1-sf)*(1 if abs(x)<=Lf/2 else 0)+sf*phi(x/Lf))/Lf
        if p<=0:return 0.
        ratio=math.exp(x)/(2*math.sinh(.5)) if remote else phi(x-df)/c
        return p**a*ratio**tf
    value=error=0.;warn=[]
    for l,r in zip(breaks,breaks[1:]):
        if l==r:continue
        estimates=[]
        for order in [48,96]:
            nodes,weights=GL[order]
            estimates.append((r-l)/2*sum(float(w)*f((l+r)/2+(r-l)/2*float(t)) for t,w in zip(nodes,weights)))
        COUNTS['quad_pieces']+=1;value+=estimates[1];error+=abs(estimates[1]-estimates[0])
    tail=tail_bound(s,L,d,R,theta,remote);tail=F(-(-tail.numerator*10**30//tail.denominator),10**30);out=dict(s=str(s),L=str(L),d=str(d),theta=str(theta),C_float=c,value=value,quad_error_estimate=error,analytic_tail_upper_rational=str(tail),analytic_tail_upper_float=float(tail),R=str(R),quad_warnings=warn,quad_is_interval_certified=False,remote_limit_integrand=remote)
    out['heuristic_total_lower']=value-error;out['heuristic_total_upper']=value+error+float(tail)
    if not remote:
        out['z_factors']={str(z):dict(active=c<float(z),normalized_active_factor=float(z)**tf*value,actual_piece_factor=(float(z)**tf if c<float(z) else c**tf)*value,target_active=63/64,target_uniform=1017/1024,domain_note='z>.5; original window/history not certified numerically') for z in [F(51,100),F(3,5),F(2,3)]}
    elif sf==0:out['closed_hard_limit']=float(L)**tf*(2*math.sinh(tf*Lf/2)/tf)/(2*math.sinh(.5))**tf/float(L)
    return out

def mp_control(row,dps=50):
    MP.mp.dps=dps;s,L,d,theta=[MP.mpf(str(F(row[k]).numerator))/F(row[k]).denominator for k in ['s','L','d','theta']];a=1-theta;c=mp_C(d);R=MP.mpf(str(F(row['R']).numerator))/F(row['R']).denominator
    def f(x):
        p=((1-s)*(1 if abs(x)<=L/2 else 0)+s*mp_phi(x/L))/L
        return p**a*(mp_phi(x-d)/c)**theta if p>0 else MP.mpf(0)
    cuts=sorted({-R,R,MP.mpf(0),-L/2,L/2,d-MP.mpf('.5'),d+MP.mpf('.5')});cuts=[x for x in cuts if -R<=x<=R]
    nodes,weights=GL[96]
    value=MP.fsum((r-l)/2*MP.fsum(MP.mpf(float(w))*f((l+r)/2+(r-l)/2*MP.mpf(float(t))) for t,w in zip(nodes,weights)) for l,r in zip(cuts,cuts[1:]) if l<r)
    return dict(dps=dps,value=MP.nstr(value,dps),C=MP.nstr(c,dps),absolute_difference_from_float=MP.nstr(abs(value-row['value']),20),certified_interval=False,note="50-digit integrand reevaluation on same 96-point binary64 Gauss nodes; not independent quadrature")

def log_upper(x,N=96):
    # x>=1: exact atanh series with a geometric positive remainder.
    assert x>=1
    z=(x-1)/(x+1);part=sum((2*z**(2*j+1)/F(2*j+1) for j in range(N)),F(0))
    return part+2*z**(2*N+1)/(F(2*N+1)*(1-z*z))
def scalar_certificates():
    def ln_large(n):
        k=n.numerator.bit_length()-n.denominator.bit_length()
        while F(2)**k>n:k-=1
        return k*log_upper(F(2))+log_upper(n/F(2)**k)
    x=F(7,4);N=32;t=total=F(1)
    for j in range(1,N+1):t*=x/j;total+=t
    expupper=total+t*x/F(N+1)/(1-x/F(N+2))
    active=3*21**8-2*22**8;inactive=16*127**8-15*128**8
    assert active>0 and inactive>0 and expupper<6 and log_upper(F(4,3))<F(1,3)
    margin=F(7,1024)*4096-F(5,2)*ln_large(F(4098))-log_upper(F(4,3))
    assert margin>0 and F(7,1024)>F(5,2)/4098
    assert F(1024,7)<147 and 147<13**2 and F(128,3)*147**2*13<2**24
    table=[]
    for n in [1,2,4,16,64,256,512,1024,4096,10000,1000000]:
        # q^n exact, all-n max is the analytic calculus reduction recorded below.
        bound=F(128,3)*n**3*F(1017,1024)**n if n<=10000 else None
        if n>=4096:assert F(7,1024)*n-F(5,2)*ln_large(F(n+2))-log_upper(F(4,3))>0
        table.append(dict(n=n,large_n_log_branch_checked=n>=4096,coarse_cost_squared_le_2pow48_n=(bound*bound<=2**48*n) if bound is not None else 'analytic all-n reduction'))
    assert all(r['coarse_cost_squared_le_2pow48_n'] is True or isinstance(r['coarse_cost_squared_le_2pow48_n'],str) for r in table)
    return dict(active_integer_gap=active,inactive_integer_gap=inactive,exp_7_over_4_upper=str(expupper),log_4_over_3_upper=str(log_upper(F(4,3))),n4096_margin=str(margin),all_n_majorant=11985792,target_constant=2**24,calculus_reduction='max x^(5/2)exp(-7x/1024) at x=2560/7; e>5/2 gives x/e<1024/7<147, sqrt147<13',large_n_reduction='c*n-2.5log(n+2)-log(4/3) positive at4096 and derivative positive thereafter; coarsecost<=32sqrt(n)',table=table,exact_rational_checks=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'numeric.json');ap.add_argument('--stage',choices=['initial','all'],default='all');ap.add_argument('--runtime',default='/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime');ap.add_argument('--vendor',default='/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor');args=ap.parse_args();sys.path.insert(0,args.runtime);sys.path.insert(0,args.vendor)
    global SP,MP
    import numpy as sp
    import mpmath as mp
    SP,MP=sp,mp
    MP.mp.dps=35
    for order in [48,96]:GL[order]=SP.polynomial.legendre.leggauss(order)
    # Rational value just below algebraic s0; exact gate s^7<=2^-80.
    D=2**80;low,high=0,D
    while low+1<high:
        mid=(low+high)//2
        if mid**7*2**80<=D**7:low=mid
        else:high=mid
    s0=F(low,D);assert s0**7<=F(1,2**80) and F(low+1,D)**7>F(1,2**80);assert 2*22**8<=3*21**8
    stages={};cache={}
    def run(s,L,d):
        key=(s,L,d)
        if key not in cache:cache[key]=integrate(s,L,d)
        return cache[key]
    stages['initial']=[run(s0,L,d) for L in [F(1,2),F(1)] for d in [F(0),F(1),F(4),F(16)]]
    print(json.dumps({'initial':[(r['L'],r['d'],r['value']) for r in stages['initial']]}),flush=True)
    if args.stage=='all':
        threshold=[]
        for z in [F(51,100),F(3,5),F(2,3)]:
            lo,hi=0.,4.
            for _ in range(48):
                mid=(lo+hi)/2
                if Cfun(mid)>float(z):lo=mid
                else:hi=mid
            root=(lo+hi)/2
            for sign in [-1,1]:
                d=F(str(root))+sign*F(1,10000);row=dict(run(s0,F(1),d));row['threshold_z']=str(z);row['threshold_root_float']=root;threshold.append(row)
        stages['threshold_pressure']=threshold
        stages['remote_soft_pressure']=[run(s,F(1),d) for s in [F(0),F(1,20),F(1,4)] for d in [F(8),F(32)]]
        stages['expanded']=[run(s,F(3,4),d) for s in [s0/2,s0] for d in [F(2),F(8),F(32)]]
        stages['Bsoft_proof_component']=[run(F(1),L,d) for L,d in [(F(1,2),F(1)),(F(1,2),F(16)),(F(1),F(1)),(F(1),F(4)),(F(1),F(16)),(F(1),F(32))]]
    controls=[]
    for L,d in [(F(1,2),F(16)),(F(1),F(1)),(F(1),F(16))]:
        row=run(s0,L,d);controls.append(dict(L=str(L),d=str(d),mp50=mp_control(row)))
    remote=[integrate(s0,L,F(0),remote=True) for L in [F(1,2),F(1)]] if args.stage=='all' else []
    author_files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'core_geometry.md']}
    out=dict(status='COMPLETED_EXPLORATORY_KERNEL_QUADRATURE',scope='Actual 1D phi/C normalized overlaps, finite selected cases only; no FULL or original-source/dx certification',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),authors_sha256=author_files,execution=dict(producer_invocations=3,successful_invocations=1,failed_invocations=2,failed_before_quadrature=1,failed_after_initial_before_json=1,stage=args.stage,new_high_dimensional_receiver_points=0,actual_1d_quadrature_objects=len(cache)+len(remote),function_counts=COUNTS),runtime=dict(python=sys.executable,numpy=SP.__version__,numpy_path=SP.__file__,scipy_unusable='special import failed corrupt local _spropack binary; no install attempted',mpmath=MP.__version__,mpmath_path=MP.__file__,runtime_path=args.runtime,vendor_path=args.vendor),scalar_certificates=scalar_certificates(),candidate=dict(theta='1/8',s0_algebraic='2^(-80/7)',s_used=str(s0),s_gate_exact=True,z_upper='2/3',active_target='63/64',uniform_target='1017/1024',scalar_integer_certificate=dict(lhs=2*22**8,rhs=3*21**8),old_z_le_half_branch='empty original-window boundary; withdrawn'),stages=stages,mp_controls=controls,remote_limits=remote,tail_certification='Rational analytic tail bounds; finite quad error estimates and mp comparisons are not outward quadrature certificates',limitations=['Finite selected displacements do not prove uniform d/source geometry','s=.05/.25 and Bsoft s1 rows are outside proposed small-soft band','No original nu/alpha/rho/Π/history or nonempty FULL instance reconstructed','No kernel installation performed'])
    args.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=out['status'],s0=float(s0),stage_sizes={k:len(v) for k,v in stages.items()},initial_max_active=max(v['normalized_active_factor'] for r in stages['initial'] for v in r['z_factors'].values() if v['active']),counts=COUNTS)))
if __name__=='__main__':main()
