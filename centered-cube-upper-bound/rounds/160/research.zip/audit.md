# R160 独立盲审检查点

范围：尚未读本轮作者稿。只写audit.md，不Git、不改他人。目标是从实际高权尾及同一原pair条件抽取必要几何，不把R(E)重新命名为付款。

## 1. 同一行、同一后验与高权尾

固定合法行、实际时间τ≤t≤h≤g、原共同ν及B₀，设M=ν(B₀)。M=0或原e_t=0回零交通支。以下只在原存活有效来源、w_t,w_g>0上计算，零权来源不作0/0。写
\[
 d_v=\int_{D_0}(k_t(v)-k_t(u))_+\mathcal M(v,u)d\Pi_t(u),\quad
 0\le\mathcal M\le1,\qquad
 \lambda_t(v)=\frac{M1_{Z_{j,t}}(v)w_t(v)}{e_t}.
\]
这里Π_t是原删除概率，λ_t是其对ν/M的密度，不能另归一化。原r=b_vρ_v准确满足
\[
 Mr_v=\rho_v\lambda_t(v)d_v/w_g(v).
\tag{S1}
\]
因此Mr_v>H（H>0）时ρ_v,λ_t,d_v,k_t(v)均正，令
\[
 h_v=\frac{Hw_g(v)}{\rho_v\lambda_t(v)}.
\]
则
\[
 d_v>h_v,\quad k_t(v)>h_v,\quad
 \Pi_t(D_0\cap\{k_t(u)<k_t(v)\})\ge d_v/k_t(v)>h_v/k_t(v).
\tag{S2}
\]
更细地，对0≤a<k_t(v)，
\[
 \Pi_t(D_0\cap\{k_t(u)<k_t(v)-a\})
 \ge\frac{[d_v-a\,\Pi_t(D_0)]_+}{k_t(v)-a}.
\tag{S3}
\]
证明是δ≤a在δ≤a部分、δ≤k_t(v)在其余部分，且mathcal M≤1。故高尾不只是一个小w_g陈述，还强迫实际bad低score质量；门保持同一原Π与接收行。

同Π已证∫∫δΠ²≤n/4给
\[
 H\int_{\{Mr>H\}}w_g(v)\frac{d\nu(v)}M
 \le\int_{\{Mr>H\}}r_vw_g(v)d\nu(v)\le n/4.
\tag{S4}
\]
这是w_g加权来源质量尾，不是J加权接收core预算，不能将左边的w_g换成J_v。

## 2. 原pair receiver kernel及good/bad必要水平集

原J责任pair密度准确保留为
\[
 p(x-y)\rho_v\delta(v,u)\mathcal M(v,u)\chi_J(v)
       d\Pi_t(v)d\Pi_t(u),\qquad
 \chi_J(v)=J_v/(3Q_v).
\tag{S5}
\]
把r重新展开后，w_g逆权在此式中已代数消去；其余Π、p、χ_J仍不能拆成独立概率。

每个实际good v、bad u的正pair满足同一接收点上的严格夹层
\[
 \frac{Q_u}{w_g(u)}<\frac pK\le\frac{Q_v}{w_g(v)}.
\tag{S6}
\]
正pair的p>0，原K固定。该式与S2–3共同给高权来源所需的receiver/source选择域。它不能由独立优化v、u的核或两个不同Π替代。相比仅看R(E)=∫rJ，S5–6保留了实际p和两源核竞争，才可能利用接收重叠/分离来支付。

逐源的现成上帽仍是
\[
 p\,\rho_v\chi_J(v)\frac{w_t(v)}{e_t}d_v
 \le\frac{w_t(v)}{e_t}d_v\,\rho_v
      \min\left\{p,\frac{KJ_v}{3w_g(v)}\right\}.
\tag{S7}
\]
这是同一原正量的两个合法上帽，不证明带逆权端本身可积。任何新pair几何若用于S5或S7，必须保留S6和原ρ支持，不能先把p删掉后宣称取消逆w_g。

## 3. 高权强迫的是terminal阈值几何

记原源坐标阈值为a_i(y,v)>0，w_s(v)=prod_i min(1,a_i/s)，k_s(v)=#{i:a_i<s}。对t<g，
\[
 \log\frac{w_t(v)}{w_g(v)}
 =k_t(v)\log(g/t)+\sum_{t\le a_i<g}\log(g/a_i)
 \le k_g(v)\log(g/t).
\tag{S8}
\]
端点a_i=t按实际严格score定义分入后一和，不漏项；a_i=g贡献零。由S1，
\[
 (g/t)^{k_g(v)}>
 \frac{He_t}{M\rho_vd_v}
 \ge\frac{He_t}{M\rho_vk_t(v)}.
\tag{S9}
\]
若右端>1，可取对数得定量terminal score下界；在原g/t≤b/a≤2下也可用log2给较粗必要条件。若右端≤1或t=g，这不强制大量坐标；t=g直接使用S1，不除以log(g/t)。

S8的未来阈值和不能丢掉。因此S9不能免费强化为当前k_t多数激活。可审候选是把current高score与[t,g)未来阈值贡献分别处理，并保留e_t/M的实际大小；单凭“高权”没有得到固定的current捕获比例。

## 4. ρ>0与共同α给出的定量高尾储备

在A_v=TΔ_v>0的原有效源上，令a_v=1−DK_{0,v}/A_v。ρ_v>0意味着a_v>0且
\[
 \rho_v=a_v-\alpha J_v/A_v,\qquad DK_{0,v}+\alpha J_v<A_v.
\]
定义
\[
 c_v=\frac{He_tw_g(v)}{Mw_t(v)d_v}.
\]
高尾Mr_v>H准确等价于ρ_v>c_v，即
\[
 DK_{0,v}+\alpha J_v<A_v(1-c_v).
\tag{S10}
\]
因此c_v≥a_v时该尾为空。α>0时还能不重选任何参数地用
\[
 \rho_vJ_v=\frac{A_v}{\alpha}\rho_v(a_v-\rho_v)
 \le\frac{A_v}{\alpha}\mathfrak m(a_v,c_v),
\quad
 \mathfrak m(a,c)=
 \begin{cases}
 a^2/4,&0\le c\le a/2,\\
 c(a-c),&a/2<c<a,\\
 0,&c\ge a\quad(\text{无高尾}).
 \end{cases}
\tag{S11}
\]
它在高尾迫使ρ接近a时比无条件a²/4强；c只是同一实际d_v等量派生的阈值，不能独立优化。α=0不套S11、不除α，仍保留S10中的DK₀约束。

例如S7的J端在α>0高尾上可进一步写为
\[
 \frac{Kw_t(v)d_v}{3e_t}
 \frac{T\Delta_v}{\alpha w_g(v)}\mathfrak m(a_v,c_v).
\tag{S12}
\]
它把逆w_g与真实Δ、同一共同储备联系起来，适合作为待付候选；但Δ/w_g、1/α及接收积分尚无根阶预算。所有a,c、源支持与α都可能依receiver/selector，不能冻结后分别最大化。

## 5. 有界结论及下一步验收条件

S2–3的bad低score质量、S6的两源核水平集夹层、S8–9的terminal阈值分解、S10–11的高ρ储备收缩均为可直接核验的必要几何/条件上帽。它们保留原α、Δ、ν、Π及p，没有把高尾简单改写为新范数就算付款。

后续作者若给接收估计，应明确：应用于S5的哪一实际pair域；是否保留同Π/存活分母；p与bad/good水平集是否一起保留；kernel比较是否逐点统一于实际soft/scale；未来阈值与current score是否区分；α=0/零核/Δ=0是否回原支；最后如何沿原唯一j/history聚合、只花一次hard与合法时间窗。尚未获得一般根阶或high-tail全付款。至此保存盲审检查点，等待精确作者候选。


## 6. 新弱幂核因子的独立盲核

本节先不读作者。固定θ=1/8、a=1−θ=7/8、Z=2/3、s₀=2^{-80/7}，于是s₀^a=1/1024。归一化b=1、y=0、L∈[1/2,1]。设F=max(h,φ)、C(d)=∫_{−1/2}^{1/2}F(u−d)du。φ≤1，故0<C(d)≤1，允许C(d)任意小，未设来源距离/坐标下限。

### 6.1 全局log-Lipschitz与不依d的soft矩

φ'(x)=w(x+1/2)−w(x−1/2)。|x|≤1/2时，φ(x)≥m*=φ(1/2)>1/4、|φ'|≤w(0)=1，故|logφ|'≤4。x≥1/2时
\[
 \phi(x)=\int_0^1 r(1-e^{-1/r})e^{-(x-1/2)/r}dr.
\]
对x>1/2，logφ的二阶导数是此正混合下1/r的方差，非负，故log斜率绝对值在该半轴非增；边界斜率为
\[
 \frac{\int_0^1(1-e^{-1/r})dr}{m_*}<4.
\]
边界一阶导数由支配收敛连续，负半轴由偶性处理。因此全局logφ为4-Lipschitz，不要求w自身有有界log导数。

另由w(u)≤e^{−|u|}，
\[
 \phi(x)\le e^{1/2}e^{-|x|},\quad
 C(d)\ge e^{-2}\phi(d),\quad
 \frac{\phi(x-d)}{C(d)}\le e^{2+4|x|}.
\tag{S13}
\]
由此
\[
 \begin{aligned}
 \int\phi_L(x)^a\left(\frac{\phi(x-d)}{C(d)}\right)^\theta dx
 &\le\frac{2e^{2\theta+a/2}L^\theta}{a-4\theta L}\\
 &\le\frac{16}{3}e^{11/16}<32.
 \end{aligned}
\tag{S14}
\]
分母至少3/8，涵盖全部d和L；没有将φ_L平移到不同source。

### 6.2 活跃与非活跃坐标的统一收缩

由Hölder及L≤1，
\[
 \int h_L^a(\phi(\cdot-d)/C(d))^\theta
 \le\left(\frac{\int_{-L/2}^{L/2}\phi(x-d)dx}{C(d)}\right)^\theta\le1.
\]
对C_i<Z，使用(p_s)^a≤(1−s)^ah^a+s^aφ^a，得到含w_Z^{-θ}的坐标因子
\[
 \le Z^\theta[(1-s)^a+32s^a]
 \le(2/3)^{1/8}(33/32)\le63/64.
\tag{S15}
\]
最后的精确整数条件为2·22^8≤3·21^8。

对C_i≥Z，w_Z坐标因子等于1。硬项的J质量≤β=∫coreφ≤15/16，故其弱幂矩≤β^θ≤127/128（在1处用凹函数切线）。soft项普通Hölder≤1。因此该坐标完整因子
\[
 \le127/128+s^a\le1017/1024=:q_*<1.
\tag{S16}
\]
C_i=Z归入此支，s=0/r=0均按乘积定义，无除零。S15更强于S16，故非负Fubini给全部位移统一的完整张量估计
\[
 \int_{\mathbb R^n}
 \frac{P_{s,L}(x-y)^aJ_v(x)^\theta}{w_Z(v)^\theta}dx
 \le q_*^n,\qquad0\le s\le s_0,\ b/2\le L\le b.
\tag{S17}
\]
这次归一化回任意b时，a+θ=1恰好抵消dx尺度。来源坐标不要求独立。

### 6.3 selector及实际来源替代的验收式

保s≤s₀的原soft分析网格与向上尺度网格给P_actual≤e²P_node、总节点≤n(n+1)。因此S17的完整接收sup价≤e^{2a}n(n+1)q_*^n，不能只登记固定参数q_*^n。分析节点不必满足原good；good已在以下原交通比较中先用完。

对S5同一原J责任，min不等式给
\[
 \min\{p,KJ_v/(3w_g(v))\}
 \le (K/3)^\theta p^a(J_v/w_g(v))^\theta.
\]
在实际z_g=c_jg/b≤Z上，w_g=w_{z_g}≥w_Z。先以δ≤n和bad后验质量≤1积掉u，再对剩下v的一份原Π作Π≤η₀^{-1}μ_z比较；只花一次η₀^{-1}，不把原删源集共同化。ρ≤1用于正上帽，原ρ及其负账没有改定义。之后μ_z才是与receiver selector和j无关的同一来源概率，可套S17和完整网格帽。

原g≥h>τ=a/c_j强制z_g>a/b；故Z≤a/b时该实际分支为空。否则先保原唯一j/history、逐j换z=c_jt/b，实际窗是[a/b,c_j²]再交z≤z_g≤Z，只能扩到[a/b,Z]，时间费≤log(Zb/a)≤log(4/3)。在同一旧hard资格与外标签合同下，完整条件价应为
\[
 2\Lambda P_{J,\mathrm{branch}}
 \le\frac{32\Lambda}{3}(K/3)^\theta\eta_0^{-1}
 n\,e^{2a}n(n+1)q_*^n\log(Zb/a)\,W_\beta.
\tag{S18}
\]
此式保留K和η。固定K、η₀>0时n²(n+1)q_*^n被某个显式常数乘sqrt n支配，所以是该严格条件分支的根阶价；不能由此删去不满足s≤s₀、z_g≤Z、η≥η₀的原补集。尚不登记全交通闭合。等待作者稿仅作对应审核。


## 7. core_geometry.md 实读后审及外价常数盲核

已在S13–18独立推导完成后实读作者全部(1)–(17)，绑定SHA256：
ab367aee4818fc16965d38634d0e9a758d4e3935cbf9ae7d0a655a60dd516a98。

具体核对：core内导数及外侧指数混合的log斜率单调，边界只需一阶可积、不假设二阶矩有限；φ_L≤4e^{−|x|}与log-Lipschitz合用给作者(7)软矩<32。可选(8)的e^{−|x|}/(1+|x|)两侧常数、C(d)下界与(9)全部0<θ<1/2的有限比较也正确；主常数仍使用θ=1/8的较强32，不混用可选较粗Bθ。活跃坐标精确整数差3716831011正确，非活跃127/128+1/1024正确，尺度抵消及selector倍率e^{7/4}n(n+1)完整。

原strict soft下门仍必须成立；作者给n>(log2)/S₀仅保证软参数区间可相交，不冒称完整合法交通实例。z_g>a/b与Z=2/3的域限制亦正确。源ν不作坐标独立假设，没有pull出实际posterior或共同α。

S18所需全维根阶常数可不用有限数值直接证明。令c=7/1024，q_*^n≤e^{−cn}。除去Λη₀^{-1}(K/3)^{1/8}sqrt n后，
\[
 \frac{32}{3}e^{7/4}\log(4/3)n^{3/2}(n+1)q_*^n
 \le\frac{64}{3}e^{7/4}\log(4/3)
       \left(\frac{5}{2ec}\right)^{5/2}
 =\frac{64}{3}\log(4/3)e^{-3/4}
       (2560/7)^{5/2}.
\]
用log(4/3)<1/3、e^{3/4}≥7/4、2560/7<384、sqrt(384)<20，该常数小于
\(5\cdot20\cdot384^2=14,745,600<2^{24}\)。
故全n的2^24条件价有效，保留η与原K因子。

n≥4096时x^{5/2}e^{−cx}已单调下降，在4096为2^{30}e^{−28}。由e>27/10且(27/10)^7>2^{10}，e^{28}>2^{40}。再用e^{7/4}<8、log(4/3)<1/3，上述系数甚至小于1/16，故作者拟用的32常数有充分余量。这是对完整外价系数的解析核对，不是由有限采样外推。实际时间窗更短只会改善，Z≤a/b时按空支处理。

等待原交通作者及主稿对应；本节尚不认证未读作者的具体记账版本或数值。


## 8. 实际接口作者与主稿数学后审检查点

已实读 core_tail.md CT1–CT12及互斥补集，最终作者SHA：
f8c8ddf797dc6786b7c2970bc0f8af2295b88a4473de08269af424a90a63979b。
CT2显式B₀/E_z/μ_z概率归一，CT3只在原合法窗口作原删源比较，η₀>1为空支；先积bad、只剩一η。CT4保留p的7/8幂并在p=0用非负幂，不除零。w_g≥w_Z后源后验变为真正共同μ_z，正ρ仍为原共同α生成值，仅以ρ≤1放松。CT6的unique-j-before-x次序完整，CT10全费与S18相同，无遗漏来源矩、selector、time或hard。CT11/12解析常数与§7一致。

作者最终使用的最弱时间合同为a/c_j≤t≤h≤g且原t≤bc_j；足以得z∈[a/b,z_g]再交z≤Z。为核查曾出现的g≤bc_j文字，本审计实际读R128 research.zip:proof.md第637行：原比例带min(L,R)≤c_jg、g=√LR、max(L,R)≤b确可推出g=(min/g)max≤bc_j，该上界亦在原行明写。不过最终稿已删除不必要的更强排序，本次付款不依赖它；不把单独t窗错误扩成g窗。

主稿最终数学对应检查点SHA：
3fc33c3e3b6080db70db54e5e4124117e68fa737e4ae438474373591203440da。
式(2)–(8)与core_geometry、独立S13–17一致；式(9)原good/min分数桥、式(10)共同接收包络、式(11)完整价、式(12)全n常数2^24、式(13)4096以后常数32均核通过。主稿已显式写1_{B₀}及E_z=∫_{B₀}w_zν，且说明逐j换共同z、保唯一指示、消j后才积分x；不能把逐j已积分帽相加后免费唯一化。

实际支付域仅原合法未付J交通再交s≤S₀、z_g≤2/3、η≥η₀。CT1写0<s，主稿核帽含s=0但同时保原strictsoft，未借辅助s=0生成合法行。可再交R159高权/core域，因为只是原正量子集；不宣称s=1/4旧压力点已覆盖。其余soft、terminal尺度、低η、其它责任与历史负账保留。四支按s、z_g、η顺序互斥，避免重复付款。一般闭合与FULL非空实例均未声明。

数学审查已齐；数值尚待最终文件，仅在收到后核其证据范围及最终SHA，不由本节认证运行中的积分。


## 9. 最终数值静态审查与冻结绑定

已实际读取numeric.py、numeric.json、numeric.md，本审计未重跑producer。范围是34个真实一维核积分对象：8初探、6阈值、6大soft/远位移压力、6扩展、6纯soft分量及2解析远极限。没有原高维receiver、ν/α/ρ/Π/history或非空FULL实例重建。大soft s=.05/.25和纯soft s=1明确在已付小soft带外，不将其样本结果计为本支覆盖。

解析身份与尾界方向核对：
- φ的E3公式和C的E4分段公式由真实卷积积分直接得到。d=0的C=1，远d采用E4二阶差而不是饱和原函数差；均是同一个真实核。
- 对d≥0，由u,v∈core且r∈[3/4,1]，C(d)≥(1/4)e^{-4(d+1)/3}。|x|>R时hard消失、p=(s/L)φ(x/L)，结合φ≤e^{1/2}e^{−|x|}，非remote尾积分准确为以
  X=(a/L+θ)R−1/2−θd−(4/3)θ(d+1)
  为指数的双侧上帽，rate=a/L+θ。代码相符，选定R确保X>0。
- remote极限φ(x−d)/C(d)→e^x/(2sinh(1/2))的两尾rate=a/L∓θ均正；用2sinh(1/2)>1给向上放松。remote行是解析极限integrand的有限积分，不冒称d=32外推。
- root_upper以整数幂向外包根，exp_negative_upper使用正Taylor部分和的倒数，因部分和≤exp(X)，方向确为e^{-X}上界；最终1e−30格取ceil仍向上。此认证只覆盖遗漏尾部，不覆盖有限区间Gauss积分。

48/96点Gauss-Legendre差是误差诊断，不能证明有限区间严格包络。mp50控制使用相同96点binary64节点，确实仅测算术精度；三控制差与JSON/notes相符。标量部分的整数幂、s^7阈值及相邻有理点、Taylor上余项、log的atanh正余项和全n微积分压缩方向正确，独立于非认证quad。表格有限n不是全n证明；一般界来自§7/作者解析最大值。JSON源码/作者hash实际匹配。

执行记录三次producer、两失败一成功及一次scalar后处理仅按保存日志/元数据列示，本审计不追认运行历史。saved JSON含历史scalar_postprocess_invocations字段，当前producer将同一标量计算内联，因此该provenance字段不要求新跑复现；数学字段应另比。主代理后续新目录复现结论属于其独立执行证据，本审计不冒充自己重跑。两类证据与原任意位移/来源交通定理分开。

最终实际读取SHA256绑定：

- core_geometry.md：ab367aee4818fc16965d38634d0e9a758d4e3935cbf9ae7d0a655a60dd516a98
- core_tail.md：f8c8ddf797dc6786b7c2970bc0f8af2295b88a4473de08269af424a90a63979b
- research.tex：3fc33c3e3b6080db70db54e5e4124117e68fa737e4ae438474373591203440da
- numeric.py：ef1440c544fa34782cb893399682e6c051185d0ffef8c4d73aa0d3800c4a090b
- numeric.json：96263d8dfafed8ec59e58b83ebf592fa73dbb9d9b25f2520b0cd7f93da891bb6
- numeric.md：2a44355d6635166c276b0c6d1e134c4ccec4554d9583dc07465a6fe8429a546d

最终结论：本轮几何核引理、全selector价及保留一次η的实际J分支付款通过，均为有限明确条件下的严格数学命题；数值有限积分仅作探索、尾/标量证书另列。一般其余soft、terminal尺度、低保留率、其它责任及原负账未闭合。仅修改audit.md，至此冻结并停止，不扩展。





