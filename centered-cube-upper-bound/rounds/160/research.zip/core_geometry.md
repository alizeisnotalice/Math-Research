# R160：逆 core 权重下的非对称接收矩缺口

本文件只证明一维真实核几何及其核层面的张量/selector 推论。结果覆盖一个严格正的 soft 带，并统一于全部源位移；不把原接收适应来源系数移出积分，不认证原来源/时间/共同 `alpha` 的付款接口。该接口由本轮另一文件负责。

## 1. 准确结论与显式常数

定义
\[
h=\mathbf1_{[-1/2,1/2]},\quad
w(u)=\int_0^1e^{-|u|/r}\,dr,\quad
\varphi=h*w,\quad p_s=(1-s)h+s\varphi,
\]
\[
F=\max(h,\varphi),\qquad
C(d)=\int_{-1/2}^{1/2}F(u-d)\,du,\qquad d\in\mathbb R.
\]
\(C\) is even and \(0<C\le1\). Indeed \(\int w=1\), \(\varphi\le1\), and the integrating interval has length 1. Put
\[
\theta=\frac18,\quad \alpha=1-\theta=\frac78,
\quad Z=\frac23,\quad S_0=2^{-80/7},\quad A_0=\frac{1017}{1024}<1.
\]
For every \(\lambda\in[1/2,1]\), \(d\in\mathbb R\), and \(0\le s\le S_0\), define
\[
p_{s,\lambda}(x)=\lambda^{-1}p_s(x/\lambda),\quad
j_d(x)=\varphi(x-d),\quad
\omega_Z(d)=\min\{1,C(d)/Z\}.
\]
Then the following is uniform in the actual source displacement, including arbitrarily remote sources:
\[
\boxed{\quad
\int_{\mathbb R}p_{s,\lambda}(x)^{7/8}
\left(\frac{j_d(x)}{\omega_Z(d)}\right)^{1/8}dx
\le\frac{1017}{1024}.
\quad} \tag{1}
\]
More precisely, the bound on \(C(d)<Z\) is \(63/64\); the larger number \(1017/1024\) pays the complementary coordinates. This is an asymmetric moment, not the false uniform soft-soft Hellinger bound normalized by \(\sqrt{C(d)}\).

For any actual \(0<z_g\le Z\),
\[
\omega_{z_g}(d)=\min(1,C(d)/z_g)\ge\omega_Z(d),
\]
so (1) remains valid with the actual \(\omega_{z_g}\) in the denominator. Using the fixed envelope \(\omega_Z\) avoids selecting the active-coordinate set as \(z_g\) varies below \(Z\).

## 2. Elementary bounds for the original \(\varphi\)

Write \(m_*:=\varphi(1/2)\). Direct convolution gives
\[
m_*=\int_0^1r(1-e^{-1/r})\,dr
\ge\frac{1-e^{-1}}2>\frac14.
\tag{2}
\]
The density \(\varphi\) is positive, even, and nonincreasing on the positive half-line. On \(0\le x\le1/2\),
\[
\varphi'(x)=w(x+1/2)-w(x-1/2),\quad
|\varphi'(x)|\le1,\quad\varphi(x)\ge m_*>1/4.
\]
For \(x\ge1/2\), putting \(t=x-1/2\),
\[
\varphi(x)=\int_0^1r(1-e^{-1/r})e^{-t/r}\,dr.
\tag{3}
\]
Its negative logarithmic derivative is the tilted mean of \(1/r\). That mean is nonincreasing in \(t>0\), because its derivative is minus the corresponding variance. Its limit at \(t=0\) is at most \(1/m_*<4\). The first moment at zero is finite, so this limit follows by dominated convergence; no second moment at zero is required. Thus globally
\[
\boxed{|\log\varphi(u)-\log\varphi(v)|\le4|u-v|.} \tag{4}
\]
Also, (3) and \(r\le1\), together with \(\varphi\le1\) inside the core, imply
\[
\varphi(x)\le e^{1/2}e^{-|x|},\qquad
\varphi_\lambda(x):=\lambda^{-1}\varphi(x/\lambda)
\le4e^{-|x|}\quad(1/2\le\lambda\le1).
\tag{5}
\]

Since \(F\ge\varphi\), (4) yields
\[
C(d)\ge\int_{-1/2}^{1/2}\varphi(u-d)\,du
\ge e^{-2}\varphi(d),
\]
and consequently
\[
\boxed{\quad\frac{\varphi(x-d)}{C(d)}\le e^2e^{4|x|}.\quad} \tag{6}
\]
This estimate is deliberately one-sided and retains receiver tail decay. It does not assert a bounded likelihood ratio or a bounded Hellinger ratio at remote displacement.

## 3. Uniform normalized soft moment, with its actual tail cost

Combining (5), (6), for \(\theta=1/8\),
\[
\begin{aligned}
\int\varphi_\lambda(x)^{7/8}
\left(\frac{\varphi(x-d)}{C(d)}\right)^{1/8}dx
&\le4^{7/8}e^{1/4}\int e^{-3|x|/8}\,dx\\
&=4^{7/8}e^{1/4}\frac{16}{3}<32.
\end{aligned}
\tag{7}
\]
For the last strict inequality, use \(4^{7/8}<4\) and \(e^{1/4}<3/2\). The positive exponent margin \(3/8\) is the reason the remote-source tail is controlled; replacing this step by the symmetric \(\theta=1/2\) expression would destroy the argument.

For completeness, a finite explicit bound is available for **every** \(0<\theta<1/2\), rather than only \(\theta<1/5\) from (6). One elementary comparison is
\[
\frac1{16}\frac{e^{-|x|}}{1+|x|}
\le\varphi(x)\le8\frac{e^{-|x|}}{1+|x|}. \tag{8}
\]
To check the lower bound for \(x\ge1/2\), use (3) on
\(r\in[1-1/(2(1+t)),1]\). On this interval \(r(1-e^{-1/r})\ge1/4\), its length is \(1/(2(1+t))\), and \(t/r\le t+1\). Thus \(\varphi(x)\ge e^{-t-1}/[8(1+t)]\), which implies (8). For \(x\le1/2\), (2) suffices. For the upper bound, \(1/r\ge1+(1-r)\) gives
\(\varphi(x)\le e^{-t}\min(1,1/t)\le2e^{-t}/(1+t)\) for \(t\ge0\), with the value at zero interpreted continuously; the inside-core bound is again trivial.

Integration of the lower bound in (8) over the core gives
\[
C(d)\ge\frac1{48}\frac{e^{-|d|}}{1+|d|}.
\]
By triangle inequalities,
\[
\frac{\varphi(x-d)}{C(d)}
\le384e^{|x|}(1+|x|).
\]
Therefore, if \(a_\theta=1-2\theta>0\),
\[
\int\varphi_\lambda^{1-\theta}
\left(\frac{\varphi(\cdot-d)}{C(d)}\right)^\theta
\le B_\theta,
\qquad
B_\theta:=2\,4^{1-\theta}384^\theta
\left(a_\theta^{-1}+a_\theta^{-2}\right).
\tag{9}
\]
Here \((1+u)^\theta\le1+u\) was used. The sharper \(B_{1/8}=32\) from (7), rather than (9), is used in all concrete constants below.

## 4. Active and inactive coordinates both have a strict gap

Let \(h_\lambda=\lambda^{-1}\mathbf1_{[-\lambda/2,\lambda/2]}\). Hölder on its support gives
\[
\int h_\lambda^{1-\theta}j_d^\theta
\le\left(\int_{-\lambda/2}^{\lambda/2}j_d\right)^\theta
\le C(d)^\theta.
\tag{10}
\]
Also, by even monotonicity of \(\varphi\), a shifted interval of length at most 1 has \(\varphi\)-mass at most
\(\beta:=\int_{-1/2}^{1/2}\varphi\). Thus the left side of (10) is at most \(\beta^\theta\), uniformly in \(d\).

There is an explicit \(\beta\le15/16\). Indeed \(U\sim h,W\sim w\) independent imply \(U+W\sim\varphi\); the event \(|W|>1\) forces \(|U+W|>1/2\). Hence
\[
1-\beta\ge\int_0^1 2r e^{-1/r}dr
\ge\tfrac12e^{-2}\ge\tfrac1{16}.
\tag{11}
\]

Use \((A+B)^{7/8}\le A^{7/8}+B^{7/8}\) to split the receiver density.

* **Active:** \(C(d)<Z\). Equations (7), (10) give
\[
\int p_{s,\lambda}^{7/8}(j_d/\omega_Z)^{1/8}
\le Z^{1/8}\bigl[(1-s)^{7/8}+32s^{7/8}\bigr].
\]
Since \(s\le S_0\) implies \(s^{7/8}\le2^{-10}\), and \(Z=2/3\), this is at most
\[
(2/3)^{1/8}\frac{33}{32}
\le\frac{21}{22}\frac{33}{32}=\frac{63}{64}.
\tag{12}
\]
The rational-power comparison has the exact integer certificate
\(3\cdot21^8-2\cdot22^8=3716831011>0\).

* **Inactive:** \(C(d)\ge Z\), so \(\omega_Z=1\). The hard part is at most \(\beta^{1/8}\); the soft part has unnormalized moment at most 1 by Hölder between two probability densities. Concavity at 1 gives
\[
\beta^{1/8}\le(15/16)^{1/8}\le127/128.
\]
Thus this coordinate's whole mixed moment is at most
\[
(1-s)^{7/8}\frac{127}{128}+s^{7/8}
\le\frac{127}{128}+\frac1{1024}
=\frac{1017}{1024}.
\tag{13}
\]

Since \(63/64=1008/1024<1017/1024\), (12), (13) prove (1) for **all** coordinates, not only coordinates carrying inverse core weights. There is no source-displacement floor.

More generally, for a fixed \(Z\in(0,1)\), a uniform upper bound at \(0\le s\le S\) is
\[
\max\left\{Z^\theta[1+B_\theta S^{1-\theta}],\quad
\beta^\theta+S^{1-\theta}\right\},
\tag{14}
\]
with any certified normalized soft-moment bound \(B_\theta\). Equation (14) is an explicit estimated factor, not a new unknown source norm.

## 5. Scaling, tensorization, and kernel selector price

For fixed \(b/2\le L\le b\), set \(\lambda=L/b\), \(d_i=(v_i-y_i)/b\), and
\[
w_Z(y,v)=\prod_i\min\{1,C(d_i)/Z\}.
\]
Changing each coordinate by \(x_i=y_i+b u_i\) and using Tonelli proves the kernel-level tensor estimate
\[
\boxed{\quad
\int_{\mathbb R^n}P_{s,L}(x-y)^{7/8}
\left(\frac{J_v(x)}{w_Z(y,v)}\right)^{1/8}dx
\le A_0^n\le e^{-7n/1024},\qquad0\le s\le S_0.
\quad} \tag{15}
\]
No independence of a source measure is involved: this holds separately for every fixed source \(v\).

Here is a fully paid kernel selector corollary; it is not an assertion about adaptive source coefficients. Let \(A,B\ge0\) be fixed constants. Since \(\min(u,v)\le u^{7/8}v^{1/8}\),
\[
\int\min\{B P_{s,L}(x-y),A J_v(x)/w_Z(y,v)\}\,dx
\le B^{7/8}A^{1/8}A_0^n.
\tag{16}
\]
To cover \(s\in[0,S_0]\) simultaneously, divide the interval into at most \(n\) pieces of length \(\delta\le1/n\), and use the point \(u=s_1/(1+\delta)\) for each piece \([s_0,s_1]\). Then \(P_{s,L}\le eP_{u,L}\), and \(u\le S_0\). The upward scale grid with ratio \(e^{1/n}\), including \(b\), has at most \(n+1\) points and gives another factor \(e\). Thus the \(7/8\) power contributes \(e^{7/4}\), and summing all grid terms gives
\[
\boxed{\quad
\int\sup_{\substack{0\le s\le S_0\\a\le L\le b}}
\min\{B P_{s,L}(x-y),A J_v(x)/w_Z(y,v)\}\,dx
\le e^{7/4}n(n+1)B^{7/8}A^{1/8}A_0^n.
\quad} \tag{17}
\]
This includes dependence of \(s,L\) on the receiver point. Actual \(z_g\le Z\) may replace \(Z\) in the original denominator, because the fixed envelope already dominates it. If \(A,B\) are also selected, (17) only applies after proving fixed upper bounds for them; their selection is not paid by this grid.

## 6. Original-domain and traffic restrictions

The useful cutoff is \(z_g\le2/3\), not the earlier tempting \(z_g\le1/2\). In the actual strict window \(\tau<h\le g\), one must retain \(z_g>a/b\ge1/2\); a cutoff at \(1/2\) would only give an empty/boundary branch. The interval \((1/2,2/3]\) can be nonempty when the original scale/time conditions allow it; this file does not certify those conditions for every original row.

Similarly, \(0<S_0=2^{-80/7}\approx0.00036279\) is a genuine positive soft strip, but the original lower soft gate still has to hold. For a lower gate \(s>1-2^{-1/n}\), a sufficient nonemptiness condition is \(n>(\log2)/S_0\), since \(1-e^{-u}\le u\). No illegal extension to \(s=0\) is used to declare an actual paid branch.

Equations (15)—(17) retain both the soft-tail receiver density and the inverse core weight. They improve on a source-blind core-count event and avoid the false symmetric soft cancellation at remote sources. They do **not** authorize pulling an \(x\)-dependent posterior, \(\delta\), \(b_v\rho_v\), or common-\(\alpha\) gate out of the receiver integral. A source mixture of fractional powers also cannot be interchanged by reversing concavity. To pay original traffic one must use its actual pointwise min/one-source bridge and establish the fixed-source/posterior/time interface separately. No new global moment budget is assumed or claimed here.

