#!/usr/bin/env python3
"""R160 replay. Use Python with numpy and mpmath already available; no installation."""
import argparse,ast,hashlib,json,pathlib,re,shutil,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--destination',type=pathlib.Path,required=True);ap.add_argument('--vendor');ap.add_argument('--runtime');ap.add_argument('--verify-existing',action='store_true');args=ap.parse_args()
manifest=json.loads((root/'manifest.json').read_text())
for name,digest in manifest['sha256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for p in root.glob('*.py'):ast.parse(p.read_text())
stack=[]
for kind,name in re.findall(r'\\(begin|end)\{([^}]+)\}',(root/'research.tex').read_text()):
    if kind=='begin':stack.append(name)
    else:assert stack and stack.pop()==name,(kind,name)
assert not stack
if not args.verify_existing:
    args.destination.mkdir(parents=True,exist_ok=False)
    for name in ['numeric.py','core_geometry.md']:shutil.copy2(root/name,args.destination/name)
else:
    for name in ['numeric.py','core_geometry.md']:assert (root/name).read_bytes()==(args.destination/name).read_bytes(),name
cmd=[sys.executable,str(args.destination/'numeric.py'),'--stage','all','--output',str(args.destination/'numeric.json')]
for key in ['vendor','runtime']:
    value=getattr(args,key)
    if value is not None:cmd += ['--'+key,value]
if not args.verify_existing:subprocess.run(cmd,check=True)
a=json.loads((root/'numeric.json').read_text());b=json.loads((args.destination/'numeric.json').read_text())
# The archived run added exact scalars in a separate historical postprocessing call.
# Ordinary replay computes them inline; this provenance counter is not a result.
for obj in [a,b]:obj['execution'].pop('scalar_postprocess_invocations',None)
assert a['scalar_certificates']==b['scalar_certificates'],'exact scalar certificate mismatch'
# Runtime paths/versions are metadata. The finite quadrature is exploratory.
maxdiff=0.
def compare(x,y,path=''):
    global maxdiff
    if isinstance(x,dict):
        assert x.keys()==y.keys(),path
        for k in x:compare(x[k],y[k],path+'/'+k)
    elif isinstance(x,list):
        assert len(x)==len(y),path
        for i,(u,v) in enumerate(zip(x,y)):compare(u,v,path+'/'+str(i))
    elif isinstance(x,float):
        err=abs(x-y)/max(1.,abs(x),abs(y));maxdiff=max(maxdiff,err)
        assert err<=1e-10,(path,x,y)
    else:assert x==y,(path,x,y)
for k in a:
    if k!='runtime':compare(a[k],b[k],k)
print(json.dumps({'status':'PASS','exact_scalars_equal':True,'nonruntime_fields_exact_equal':{k:v for k,v in a.items() if k!='runtime'}=={k:v for k,v in b.items() if k!='runtime'},'maximum_relative_float_difference':maxdiff,'replay_float_tolerance':1e-10,'not_a_quadrature_error_certificate':True,'pdf_compiled':False}))
