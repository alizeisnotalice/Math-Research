#!/usr/bin/env python3
"""R169 one fixed atomic completion: exact current equality and all futures.
Stdlib interval arithmetic from frozen R166/R168; no search or L1 claim.
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal
import importlib.util,json,hashlib,time
HERE=Path(__file__).resolve().parent
HISTORY=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round168_20261016_final_checkpoint')
TOOLS=HISTORY/'lp_candidate_certificate.py'
PRIOR=HISTORY/'lp_refined_certificate.json'
PRIOR_CODE=HISTORY/'lp_refined_certificate.py'
spec=importlib.util.spec_from_file_location('r169_interval_tools',TOOLS)
ct=importlib.util.module_from_spec(spec);spec.loader.exec_module(ct)
I=ct.I
NU=[F(3,25),F(2749,3125),F(1,3125)]
Q=F(9,2500);LAM=F(11,2500)
S=F(1,4);L=F(9,10);D=F(9,20)
X=[F(51,100)]+[F(2,5)]*3
POS=[[F(53,50)]+[F(19,20)]*3,[F(-3,5)]*4,X]
ADDED=[x+D for x in X]

def run(Na,Bnu_s,Bnu_1):
    delta=[[abs(x-z) for x,z in zip(X,row)] for row in POS]
    current_terms=[ct.kern(S,I(L),row,Na) for row in delta]
    current=sum((I(n)*k for n,k in zip(NU,current_terms)),I(0))
    peak=ct.kern(S,I(L),[D]*4,Na)
    assert peak.lo>0 and current.hi<I(Q).lo
    mass=(I(Q)-current)/peak
    assert mass.lo>0
    # L'<L: the added atom is outside all hard coordinates.
    left_s_upper=Bnu_s+mass*I(S**4)
    # u=1,left: phi(r)<=.5 exp(.5-r), max r exp(-r)=exp(-1).
    sigma_u1_left_kernel=ct.iv.exp_neg(F(2))/I(L**4)
    # u=1,right: phi(0)<3/5, L'>=L.
    phi0=ct.iv.phi(F(0),Na)
    assert phi0.hi<Decimal('.6')
    sigma_u1_right_kernel=I((F(3,5)/L)**4)
    u1_left_upper=Bnu_1+mass*sigma_u1_left_kernel
    u1_right_upper=Bnu_1+mass*sigma_u1_right_kernel
    # On [L,1], |phi'|<=1; added kernel derivative <= -135/128.
    weighted_far_distance=sum((NU[i]*sum(delta[i],F(0)) for i in (0,1)),F(0))
    positive_far_derivative=I(S**4*weighted_far_distance/(8*L**6))
    right_s_derivative_upper=positive_far_derivative-I(F(135,128))*mass
    hard_total=I(NU[2])+mass
    margins=dict(left_soft_s_gap=I(Q)-left_s_upper,u1_left_gap=I(Q)-u1_left_upper,
                 u1_right_gap=I(Q)-u1_right_upper,
                 right_s_negative_derivative=I(0)-right_s_derivative_upper,
                 hard_cap=I(4*LAM)-hard_total,
                 lambda_lower=I(Q-F(3,4)*LAM),lambda_upper=I(LAM-Q))
    assert all(z.lo>0 for z in margins.values())
    half_boundary=ct.iv.phi(F(1,2),Na)
    symmetric_coefficient=((I((1-S)/2)+I(S)*half_boundary)/I(L))**4
    symmetric_current_limit=current+mass*symmetric_coefficient
    symmetric_retuned_mass_limit=(I(Q)-current)/symmetric_coefficient
    symmetric_retuned_hard_limit=I(NU[2])+symmetric_retuned_mass_limit
    retuned_excess_max_hard=symmetric_retuned_hard_limit-I(F(16,3)*Q)
    assert symmetric_current_limit.hi<I(Q).lo and retuned_excess_max_hard.lo>0
    return dict(a_subdivisions=Na,current_nu=current.out(),boundary_atom_current_kernel=peak.out(),
        exact_added_mass_interval=mass.out(),phi0=phi0.out(),
        prior_nu_endpoint_bounds=dict(u_s=Bnu_s.out(),u_1=Bnu_1.out()),
        future_upper_bounds=dict(Lprime_less_than_L_u_s=left_s_upper.out(),
            all_u1_left=u1_left_upper.out(),all_u1_right=u1_right_upper.out()),
        right_u_s_derivative_upper=right_s_derivative_upper.out(),
        positive_far_derivative_bound=positive_far_derivative.out(),
        hard_F_total=hard_total.out(),strict_margins={k:z.out() for k,z in margins.items()},
        symmetric_product_box_smoothing_pressure=dict(
            limit_boundary_current_coefficient=symmetric_coefficient.out(),
            fixed_mass_limit_current_F=symmetric_current_limit.out(),
            retuned_mass_limit_at_same_x_s_L_q=symmetric_retuned_mass_limit.out(),
            retuned_hard_mass_limit=symmetric_retuned_hard_limit.out(),
            maximal_hard_cap_allowed_by_q_lambda_band=str(F(16,3)*Q),
            retuned_hard_excess_over_maximum_lambda_cap=retuned_excess_max_hard.out(),
            scope='Only symmetric independent product-box smoothing with mass retuning at the same x,s,L,q; not an impossibility theorem for all L1 completions.'))

def main():
    start=time.monotonic();data=json.loads(PRIOR.read_text())
    assert data['candidate']['nu']==list(map(str,NU))
    assert F(data['candidate']['q'])==Q and F(data['candidate']['lambda_value'])==LAM
    assert data['all_future_necessary_test']['all_boxes_strict_below_q']
    boxes=data['all_future_necessary_test']['boxes']
    def bound(ss):
        bb=max((Decimal(z['upper_nu_kernel']) for z in boxes if z['future_s']==ss))
        return I(F(bb))
    rows=[run(64,bound('1/4'),bound('1')),run(128,bound('1/4'),bound('1'))]
    inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (TOOLS,PRIOR,PRIOR_CODE,ct.DEP)}
    out=dict(scope='One positive atomic measure F=nu+M delta_r: exact P_current F=q and ALL future upper tests certified at this x. Atomic, not L1; no beta/history/Psi claim.',
        inputs=inputs,arithmetic='Frozen R166/R168 directed intervals with certified E3/E4/exp/log/sqrt. No float/mp arithmetic enters bounds.',
        geometry=dict(n=4,xq=list(map(str,X)),yq=['0']*4,positions=[list(map(str,z)) for z in POS],
            s=str(S),L=str(L),a='1/2',b='1',R='1',q=str(Q),lambda_value=str(LAM),nu=list(map(str,NU))),
        completion=dict(atom_position=list(map(str,ADDED)),displacement_from_x=[str(D)]*4,
            mass_definition='M=(q-P_(1/4,9/10)nu(x))/P_(1/4,9/10)(x-r), using true kernels; interval endpoints are NOT the chosen mass.',
            hard_boundary_convention='Closed indicator: |x_i-r_i|=L/2 is included at the current L; left branch is Lprime<L.',
            current_equality='Exact by this symbolic definition of M, not by rounded decimal tuning.'),
        refinements=rows,
        certified=dict(F_ge_nu=True,positive_finite_added_mass=True,current_equality=True,
            all_future_u_in_s_to_1_Lprime_in_a_to_b=True,hard_cap_F_le_4lambda=True,
            q_in_3lambda4_to_lambda=True,unique_future_maximizer_at_fixed_x='(u,Lprime)=(1/4,9/10)',
            L1_density=False,beta_y0_or_history_realization=False),
        limitations=['F contains atoms; this is a finite positive-measure FIRST completion only.',
            'Smoothing the boundary atom removes a hard jump and may move the maximizing scale and change the current equality; no fixed-parameter L1 transfer is certified.',
            'Existing nu is also atomic. No source domination by an L1 density, beta mass at y=0, original leaf/Psi/Z/history realization is constructed.',
            'Only the fixed receiver x and one current parameter pair are certified; no common-q receiver set of positive dx measure.'],
        wall_seconds=round(time.monotonic()-start,3))
    (HERE/'completion_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(seconds=out['wall_seconds'],finest=rows[-1],certified=out['certified']),indent=2))
if __name__=='__main__':main()
