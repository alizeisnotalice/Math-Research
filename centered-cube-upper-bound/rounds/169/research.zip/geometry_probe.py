#!/usr/bin/env python3
"""Finite pressure test of R169 N5; no general theorem/FULL certification.
Run with the bundled Python and -B; imports the frozen R165 kernel chain.
"""
from pathlib import Path
from fractions import Fraction as F
import importlib.util
import hashlib
import json
import math
import sys
import time

SOURCE_DIR = Path(__file__).resolve().parent
HERE = SOURCE_DIR
SOURCE = Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round165_20261015_final_checkpoint/hard_overlap_check.py')
spec = importlib.util.spec_from_file_location('r169_r165_kernel', SOURCE)
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)
mp, np = legacy.mp, legacy.np
mp.mp.dps = 200  # comparisons/summary selection must not round to default 15 digits
phi_mp, phi_np = legacy.old.phi_mp, legacy.old.phi_np
CACHE = {}

def mrat(v):
    return mp.mpf(v.numerator)/v.denominator

def w_mp(r):
    r = abs(r)
    return mp.mpf(1) if r == 0 else mp.expint(2, r)

def values(r, dps):
    key = (r, dps)
    if key not in CACHE:
        z = mrat(r)
        CACHE[key] = (phi_mp(z), w_mp(z+mp.mpf('.5'))-w_mp(z-mp.mpf('.5')))
    return CACHE[key]

def case(stage, name, s, q, groups):
    s, q = F(s), F(q)
    groups = [(int(c), F(r)) for c,r in groups if c]
    assert 0 < s <= 1 and q > 0 and all(c>0 and r>=0 for c,r in groups)
    # q=e^h is rational: every hard indicator and shell endpoint is exact.
    nh = sum(c for c,r in groups if ((F(1,2)<r<=q/2) if q>1 else (q/2<r<=F(1,2))))
    return dict(stage=stage, name=name, s=s, q=q, groups=groups, n=sum(c for c,r in groups), Nh=nh)

def cases():
    out=[]
    for s in ['1/100','1/4','3/4','1']:
        for q in ['4/5','9/10','11/10','5/4']:
            for r in ['0','1/10','3/10','7/10','1','3','20']:
                out.append(case(1, 'ordinary-single', s,q,[(1,r)]))
            for n in [4,32]:
                out.append(case(1,'ordinary-mixed',s,q,[(n//4,'1/10'),(n//4,'3/10'),(n//4,'7/10'),(n//4,'3')]))
    qs=[F(4,5),F(9,10),F(11,10),F(5,4),F(1000001,1000000),F(999999,1000000)]
    eps=F(1,10**12)
    for s in ['1','1/4','1/100000000','1/'+str(10**30)]:
        for q in qs:
            rs=[F(1,2)-eps,F(1,2),F(1,2)+eps,q/2-eps,q/2,q/2+eps]
            for j,r in enumerate(rs):
                out.append(case(2,f'shoulder-{j}',s,q,[(1,r)]))
            out.append(case(2,'mixed-shoulders',s,q,[(3,rs[0]),(5,rs[1]),(7,rs[2]),(11,rs[3]),(13,rs[4]),(17,rs[5])]))
    qs=[F(4,5),F(5,4)]+[1+sign*F(1,10**k) for k in [12,40] for sign in [-1,1]]
    for n in [1,8,128,4096,10**6]:
        for s in ['1','1/'+str(10**30),'1/'+str(10**100)]:
            for q in qs:
                for tag,r in [('tail-100','100'),('tail-million','1000000')]:
                    out.append(case(3,tag,s,q,[(n,r)]))
                counts=[n//4,n//4,n//4,n-3*(n//4)]
                out.append(case(3,'large-mixed',s,q,list(zip(counts,['0','1/2','3/4','1000000']))))
    return out

def evaluate(c, dps):
    with mp.workdps(dps):
        s,q=mrat(c['s']),mrat(c['q']);h=mp.log(q);n=c['n'];nh=c['Nh']
        assert 0 < abs(h) <= mp.mpf('.25')
        # L=1, a=3/4, b=3/2: both endpoint scales are in the same octave.
        assert mp.mpf('0.75') <= q <= mp.mpf('1.5')
        Lphi=2/(1-mp.exp(-1)); a1=values(F(1),dps)[0]
        C0=2/a1+1/a1**2; C1=Lphi+C0;cstar=Lphi*mp.exp(mp.mpf('.5'))
        phi_face=values(F(1,2),dps)[0]
        ell=mp.log((1-s+s*phi_face)/(s*phi_face))
        A=-mp.mpf(n);lhs=-n*h;tr=mp.mpf(0)
        for count,r in c['groups']:
            ph,dp=values(r,dps);ph_new,_=values(r/c['q'],dps)
            hard=(r<=F(1,2));hard_new=(r/c['q']<=F(1,2))
            f=(1-s)*int(hard)+s*ph;f_new=(1-s)*int(hard_new)+s*ph_new
            A-=count*mrat(r)*s*dp/f
            lhs+=count*(mp.log(f_new)-mp.log(f));tr+=count*mrat(r)
        Q=C1*n*h*h*mp.log(mp.e/abs(h))+(Lphi*mp.exp(mp.mpf('.25'))/2)*tr*h*h
        signed_jump=(1 if h>0 else -1)*ell*nh
        shell=cstar*abs(h)*nh;rhs=h*A-Q+signed_jump-shell
        slack=lhs-rhs;scale=Q+shell
        return {k:mp.nstr(v,65) for k,v in dict(h=h,A=A,T_over_L=tr,Q=Q,ell=ell,lhs=lhs,rhs=rhs,slack=slack,slack_over_error=slack/scale).items()}

def float_check(c, target):
    s=float(c['s']);q=float(c['q']);h=math.log1p(float(c['q']-1))
    if abs(h)<1e-7 or max(float(r) for _,r in c['groups'])>200:
        return dict(status='not_float_domain',reason='tiny-h cancellation or exponentially small phi; mp remains evaluated')
    phface=float(phi_np(np.array([.5]))[0]);a1=float(phi_np(np.array([1.]))[0]);lp=2/(1-math.exp(-1));c1=lp+2/a1+1/a1**2
    A=-float(c['n']);lhs=-c['n']*h;tr=0.
    for count,r in c['groups']:
        z=float(r);ph=float(phi_np(np.array([z]))[0]);phnew=float(phi_np(np.array([float(r/c['q'])]))[0])
        # w(0)=1 is explicit; E2 represents the original exponential mixture.
        w=lambda x:1. if x==0 else float(legacy.old.expn(2,abs(x)))
        dp=w(z+.5)-w(z-.5)
        f=(1-s)*int(r<=F(1,2))+s*ph;fn=(1-s)*int(r/c['q']<=F(1,2))+s*phnew
        A-=count*z*s*dp/f;lhs+=count*(math.log(fn)-math.log(f));tr+=count*z
    nh=c['Nh'];ell=math.log((1-s+s*phface)/(s*phface));Q=c1*c['n']*h*h*math.log(math.e/abs(h))+lp*math.exp(.25)/2*tr*h*h
    rhs=h*A-Q+(1 if h>0 else -1)*ell*nh-lp*math.exp(.5)*abs(h)*nh
    sl=lhs-rhs
    return dict(status='evaluated',slack=sl,max_abs_difference=max(abs(lhs-float(target['lhs'])),abs(rhs-float(target['rhs']))),normalized_slack_difference=abs(sl-float(target['slack']))/(Q+lp*math.exp(.5)*abs(h)*nh))

def serialize(c):
    return {**{k:v for k,v in c.items() if k not in ['s','q','groups']},'s':str(c['s']),'scale_ratio':str(c['q']),'groups':[[n,str(r)] for n,r in c['groups']]}

def main():
    started=time.time();menu=cases();records=[]
    endpoint_checks=[]
    for q in [F(4,5),F(5,4),F(999999,1000000),F(1000001,1000000)]:
        for name,r,expected in [('start-closed',F(1,2),int(q<1)),('end-closed',q/2,int(q>1))]:
            cc=case(0,name,'1/4',q,[(1,r)])
            assert cc['Nh']==expected
            endpoint_checks.append(dict(scale_ratio=str(q),r=str(r),name=name,Nh=cc['Nh'],expected=expected))
    assert w_mp(mp.mpf(0))==1
    for i,c in enumerate(menu):
        digits=max(0,len(str((c['q']-1).denominator))-1)
        dps=max(65,2*digits+45)
        ans=evaluate(c,dps)
        records.append(dict(id=i,input=serialize(c),dps=dps,result=ans,float_check=float_check(c,ans)))
    # Prespecified class representatives plus stage minima, endpoints, largest tails.
    selected=set()
    for stage in [1,2,3]:
        inds=[i for i,c in enumerate(menu) if c['stage']==stage]
        selected.update([inds[0],inds[-1],min(inds,key=lambda i:mp.mpf(records[i]['result']['slack'])),min(inds,key=lambda i:mp.mpf(records[i]['result']['slack_over_error']))])
        selected.update(inds[::max(1,len(inds)//12)])
    checks=[]
    for i in sorted(selected):
        dps=records[i]['dps'];hi=evaluate(menu[i],dps+50)
        with mp.workdps(dps+55):
            lo=records[i]['result'];err=abs(mp.mpf(lo['slack'])-mp.mpf(hi['slack']));norm=err/(abs(mp.mpf(hi['Q']))+abs(mp.mpf(hi['slack']))+mp.mpf('1e-1000'))
            checks.append(dict(id=i,low_dps=dps,high_dps=dps+50,high_slack=hi['slack'],slack_abs_difference=mp.nstr(err,20),scaled_difference=mp.nstr(norm,20),positive=mp.mpf(hi['slack'])>=0))
    stages=[]
    for stage in [1,2,3]:
        rr=[r for r in records if r['input']['stage']==stage]
        mn=min(rr,key=lambda r:mp.mpf(r['result']['slack']));nr=min(rr,key=lambda r:mp.mpf(r['result']['slack_over_error']))
        stages.append(dict(stage=stage,count=len(rr),negative_slack=sum(mp.mpf(r['result']['slack'])<0 for r in rr),min_slack=mn['result']['slack'],min_slack_id=mn['id'],min_slack_over_error=nr['result']['slack_over_error'],min_normalized_id=nr['id'],Nh_min=min(r['input']['Nh'] for r in rr),Nh_max=max(r['input']['Nh'] for r in rr)))
    fchecks=[r['float_check'] for r in records if r['float_check']['status']=='evaluated']
    lp=2/(1-mp.exp(-1));a1=phi_mp(mp.mpf(1));constants={k:mp.nstr(v,65) for k,v in dict(a1=a1,Lphi=lp,C0=2/a1+1/a1**2,C1=lp+2/a1+1/a1**2,cstar=lp*mp.exp(mp.mpf('.5'))).items()}
    out=dict(script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),constants=constants,scope='N5 finite deterministic pressure evidence only; not interval/FULL/general theorem or N6-N9 nearmax certification',source=str(SOURCE),source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),phi_source=str(legacy.PRODUCER),phi_source_sha256=hashlib.sha256(legacy.PRODUCER.read_bytes()).hexdigest(),author_source_sha256=hashlib.sha256((SOURCE_DIR/'near_extremal_geometry.md').read_bytes()).hexdigest(),python=sys.executable,python_version=sys.version,numpy_version=np.__version__,mpmath_version=mp.__version__,w0='exactly 1',endpoint_checks=endpoint_checks,L='1',a='3/4',b='3/2',stages=stages,records=records,high_precision_checks=checks,high_precision_all_positive=all(c['positive'] for c in checks),max_hp_scaled_difference=max((c['scaled_difference'] for c in checks),key=mp.mpf),float_count=len(fchecks),float_max_abs_difference=max(c['max_abs_difference'] for c in fchecks),float_max_normalized_slack_difference=max(c['normalized_slack_difference'] for c in fchecks),elapsed_seconds=time.time()-started)
    (HERE/'geometry_probe.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:out[k] for k in ['stages','high_precision_all_positive','max_hp_scaled_difference','float_count','float_max_abs_difference','float_max_normalized_slack_difference','elapsed_seconds']},indent=2))

if __name__=='__main__':main()
