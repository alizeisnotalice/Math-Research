# R169 N5：三阶段确定性压力检验

结论：582个预定参数行的N5 slack均为正；46行另升精50位复核均为正。未发现具体违反。这里只检验N5必要核估计，不认证一般定理、N6–N9的nearmax前提、FULL实例或原δ付款。最终引理仍由指定独立审查者核验。

## 命题先审与计算定义

N5只需0<s≤1、0<|h|≤1/4和同octave的L,Le^h合法，不需要假定近极大门。固定L=1、a=3/4、b=3/2；用有理 `scale_ratio=exp(h)` 构造h=log(scale_ratio)。代码内部局部变量q只是此尺度比，**不是原FIRST水平q**。

计算
\[
 \text{slack}=\log P_{s,e^h}(r)-\log P_{s,1}(r)
 -[hA-Q(h)+\operatorname{sgn}(h)\ell(s)N_h-c_*|h|N_h].
\]
所有乘积均在log域按相同坐标的multiplicity分组求和，无高维积下溢。T/L=Σcount·r；A采用作者N1的当前闭hard分母。归一化slack定义为slack/[Q(h)+c_*|h|N_h]。

肩点/跨界判断全部用 `Fraction`：当前r≤1/2和末态r/scale_ratio≤1/2独立精确判定。正h的N_h使用1/2<r≤scale_ratio/2；负h使用scale_ratio/2<r≤1/2。特别单设当前闭肩点r=1/2、末态闭肩点r=scale_ratio/2，并各构造±10^-12两侧；8个独立预期计数断言全部通过。缩尺度末态恰到肩点不丢hard，扩尺度末态恰到肩点已经得hard，未用浮点相等判断。

phi_mp/phi_np通过R165 `hard_overlap_check.py` 的原import链复用R151 producer函数。导数直接算
\[
 \phi'(r)=w(r+1/2)-w(r-1/2),\quad
 w(z)=E_2(|z|)\ (z\ne0),\quad w(0)=1\ \text{单独精确指定}.
\]
没有对phi二阶数值微分，也不把肩点的phi''当有界。

## 三阶段范围与结果

|阶段|行数|实际参数|最小slack|最小归一化slack|
|---|---:|---|---:|---:|
|初步普通坐标|144|n=1,4,32；s=1/100,1/4,3/4,1；r=0,.1,.3,.7,1,3,20及混合；scale_ratio=.8,.9,1.1,1.25|1.585356480167692|0.936668496617134|
|hard肩点与两侧压力|168|n=1或56；s=1,1/4,10^-8,10^-30；scale_ratio=.8,.9,1.1,1.25,1±10^-6；当前/末态闭肩点及两侧，含不同multiplicity混合|7.665470995779650×10^-10|0.790922671061562|
|扩大参数|270|n=1,8,128,4096,10^6；s=1,10^-30,10^-100；r=100或10^6及含0,.5,.75,10^6混合；scale_ratio=.8,1.25,1±10^-12,1±10^-40|5.002531042043394×10^-77|0.734491542890669|

所有阶段违反数均0。最大T/L=10^12，最大N_h=250000。|h|最大为|log(.8)|≈.2231436<1/4；最小量级10^-40。最小绝对slack出现在n=1、s=1、r=100、scale_ratio=1+10^-40（JSON id327）；它因h极小而极小，归一化slack仍约.9901022。最小归一化slack为n=1、s=1、r=10^6、scale_ratio=.8（id313），约.7344915。

## 精度、复核与局限

全部582行采用mpmath 65–125十进制位；小h自动提高精度，以免h²余项被log差分消去。参数/阈值的有理比较不受mp精度影响。46行按预定分段代表、各阶段slack/归一化slack极小者和端点代表，另用115–175位重算；最大升精差除以(|Q|+|slack|)为1.4938202921×10^-47，全部高精slack仍正。JSON逐行保留输入、精度、lhs、rhs、A、T/L、Q、ell、slack及复核记录。

342行另用phi_np/float64比较（只取|h|≥10^-7、r≤200的可表示域），最大lhs/rhs绝对差2.2352×10^-8，最大slack差除误差尺度约1.5130×10^-5。该差主要反映小h肩点的浮点消去；通过/违反结论始终用高精度结果。其余240行明确标记float域外，仍全部有mp结果，未删去。高精一致性不是向外舍入区间证书，亦不核验作者所有解析常数的最优性。

系统 `/opt/homebrew/bin/python3` 首次检查缺numpy；已改用本机bundled Python，无安装或环境改写。可重放命令：

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/169/work/geometry_probe.py
```

脚本只重写同目录geometry_probe.json；该MD为本次结果说明。JSON记录脚本、R165入口、R151核producer、作者N1–N9源文件SHA及Python/NumPy/mpmath版本。运行约0.9秒。只新增geometry_probe.py/json/md，未改作者证明、未Git、未spawn；完成停止。
