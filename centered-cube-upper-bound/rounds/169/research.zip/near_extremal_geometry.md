# R169：future 近极大行的尺度 score 与真实 hard 壳层

状态：新增一条可检验的必要几何估计，允许任意坐标组合，不假定来源乘积。它不是 R168 的 B_*<H 的改名：下面直接控制当前核的 logscale 导数，并保留跨 hard 边界的精确跳值。尚未证明该接收 score 能支付原来源 score 差 δ；本稿不登记新增根阶交通付款。

读取范围：R169 合同；R168 冻结 middle_joint_first.md/proof.tex.txt；R164 冻结 task_contract 中原 k_z、Π_t、good/bad 定义。证明自足，不调用外部文献。只写本责任文件。

## 1. 量词、候选与压力检查

固定一条原接收行和来源 y，0<s≤1，a≤L≤b≤2a，p=P_{s,L}(x−y)>0。令

\[
 f_s(r)=(1-s)1_{[-1/2,1/2]}(r)+s\phi(r),\quad
 r_i=|x_i-y_i|/L,\quad T=\sum_i|x_i-y_i|,
\]
\[
 \mathcal L(h)=\log P_{s,Le^h}(x-y),\qquad
 \mathcal R=\sup_{u\ge s,\,L'\in[a,b]}
 P_{u,L'}(x-y)/p.
\]

只研究原剩余门 \(\mathcal R<e^H\)。所有满足 \(Le^h\in[a,b]\) 的同 soft 测试均合法，故 \(\mathcal L(h)-\mathcal L(0)<H\)。未按来源 y 改选 FIRST 输入；本稿只从已定义的逐来源近极大门推必要条件。

定义当前**平滑分支尺度 score**

\[
 A=-n-\sum_i r_i\frac{s\phi'(r_i)}{f_s(r_i)}.                 \tag{N1}
\]

在 r_i=1/2 处按原闭 hard 核取内侧分支的分母；φ' 连续。A 不是跨跳点处的双侧导数。没有坐标落在肩点时，它就是 \(\mathcal L'(0)\)。原交通的 \(k_z(v)=\#\{i:C((y_i-v_i)/b)<z\}\) 与 A 不同，不能令 δ=A、δ=m 或 δ=|A|。

准确候选为：nearmax 加上足够双侧尺度空间，且真实 hard 壳层费用可控，推出 \(|A|\lesssim\sqrt{nH\log(n+2)}\)。必须保留三项压力：(i) L=a 或 b 只提供单侧信息；(ii) s<1 的 hard 跳损可能很大；(iii) T/L 若未另控，曲率成本不只有 n。以下公式显式保留三者。

## 2. 一维连续部分：无需假设离肩点有固定距离

沿原定义

\[
 w(r)=\int_0^1e^{-|r|/v}dv,\qquad
 \phi(r)=\int_{-1/2}^{1/2}w(r-t)dt.
\]

令 \(L_\phi=2/(1-e^{-1})\)、\(a_1=\phi(1)>0\)，并置

\[
 C_0=2/a_1+a_1^{-2},\qquad C_1=L_\phi+C_0,\qquad
 c_*=L_\phi e^{1/2}.
\]

这些是绝对常数；可以直接保留积分定义的 a_1，不依赖数值认证。

对 0<d≤1，有

\[
 |w(r+d)-w(r)|\le\int_0^1\min(1,d/v)dv
 =d\log(e/d).
\]

因为 \(\phi'(r)=w(r+1/2)-w(r-1/2)\)，得到

\[
 |\phi'(r')-\phi'(r)|\le2d\log(e/d),\quad
 |\phi'|\le1,\quad d=|r'-r|\le1.                         \tag{N2}
\]

在 [0,1] 内，对任一固定光滑分支 \(F=\phi\) 或 \(F=1-s+s\phi\)，有

\[
 |(\log F)'|\le L_\phi,\qquad
 |(\log F)'(r')-(\log F)'(r)|
 \le C_0d\log(e/d).                                      \tag{N3}
\]

第一式用已审 logφ Lipschitz 和 \(s\phi/F\le1\)。第二式把分式差拆成导数差与分母差，分别用 \(F\ge s a_1\)、(N2)、\(|\phi(r')-\phi(r)|\le d\)；F=φ 同理。sφ 的对数导数与 φ 相同。此论证处理肩点的对数奇性，不错误地假定 φ'' 全局有界。

对 r>1/2，φ 是速率≥1的正指数混合，故 logφ 凸。因此在全处于尾部的尺度路径上

\[
 {d^2\over dh^2}\log\phi(re^{-h})
 =re^{-h}(\log\phi)'(re^{-h})
 +(re^{-h})^2(\log\phi)''(re^{-h})
 \ge-L_\phi re^{-h}.                                    \tag{N4}
\]

只在严格尾部取导；不在肩点假定二阶导数有限。

## 3. 精确 hard 跳损与统一二阶余项

取 0<|h|≤1/4 且 Le^h∈[a,b]。真实跨界数定义为

\[
 N_h=\begin{cases}
 \#\{i:1/2<r_i\le e^h/2\},&h>0,\\
 \#\{i:e^h/2<r_i\le1/2\},&h<0.
 \end{cases}
\]

端点按原闭 hard 核处理：扩尺度落到肩点已经获得硬项，缩尺度恰落到肩点尚未丢硬项。记

\[
 \ell(s)=\log\frac{1-s+s\phi(1/2)}{s\phi(1/2)}\ge0,
\]
\[
 Q(h)=C_1 n h^2\log(e/|h|)
       +\frac{L_\phi e^{1/4}}2\frac TL h^2.
\]

则有全坐标、不要求同分布的确定性估计

\[
 \boxed{\mathcal L(h)-\mathcal L(0)
 \ge hA-Q(h)+\operatorname{sgn}(h)\ell(s)N_h
               -c_*|h|N_h.}                            \tag{N5}
\]

证明分三类，互不重叠。

* 未跨界且 r_i≤3/4：整条路径处于 [0,1]。任意路径位置与 r_i 的距离≤|h|，由 (N3)，\(-r(\log F)'(r)\) 的改变量≤C_1|h|log(e/|h|)。积分得到该坐标切线余项下界 \(-C_1 h^2\log(e/|h|)\)。实际使用的内/外分支在该路径上固定。
* r_i>3/4：因 |h|≤1/4，整条路径严格大于1/2，不可能跨界。(N4) 给余项下界 \(-L_\phi e^{1/4}r_i h^2/2\)。
* 跨界坐标：log f_s 的跳值准确为 sgn(h)ell(s)。去掉该跳后，每段尺度导数的绝对值≤L_φ r(路径)。当前与路径上的 r 均≤e^{1/2}/2，故相对当前切线的连续部分误差绝对值≤c_*|h|。求和即得 (N5)。

归一化的 −nh 已包含于 hA，不计入余项。最后把前两类分别上放为 n 和 T/L，得到所写 Q(h)。s=1 时跳值为零，(N5) 仍成立，但这时可以完全不分 hard 壳层而用光滑 φ 分支证明下文更强的无 N_h 版本。

## 4. nearmax 的新必要内容

由 (N5)，原近极大门强制每个合法 h 满足

\[
 hA+\operatorname{sgn}(h)\ell(s)N_h
 \le H+Q(h)+c_*|h|N_h.                                  \tag{N6}
\]

这是当前尺度 score、两向真实壳层和总距离的联合可检验条件，不能仅用 m_b 代替。

若 ±r 均合法，0<r≤1/4，写 N_+=N_r、N_-=N_{-r}，则

\[
 A\le H/r+Q(r)/r+(c_*-\ell(s)/r)N_+,                    \tag{N7+}
\]
\[
 -A\le H/r+Q(r)/r+(c_*+\ell(s)/r)N_-.                   \tag{N7-}
\]

扩尺度跨界的正跳益有助于约束 A；缩尺度丢失硬项必须支付 ell(s)N_-，不能用一项无费“曲率”吸收。

一个精确的 root-size 推论如下。令 H≥1、T/L≤Mn，并假设

\[
 r=\sqrt{H/[n\log(n+2)]}\le1/4,\quad
 Le^{-r},Le^r\in[a,b],\quad N_+=N_-=0.
\]

因为 log(e/r)≤2log(n+2)，(N7) 给

\[
 |A|\le\left[1+2C_1+\frac{L_\phi e^{1/4}}2M\right]
          \sqrt{nH\log(n+2)}.                            \tag{N8}
\]

这里 H≥1、r≤1/4 保证 n 足够大；也可直接由 r 定义检验所用对数不等式。若 s=1，则所有核均为光滑 φ，(N5) 的证明对全部 r_i≤3/4 使用同一光滑分支，因此 (N8) 无须 N_+=N_-=0。若存在壳层，(N7) 给相同根阶主项加其明写的实际壳层费用；若尺度端点挡住某一测试，只保留对应单侧式，不推绝对值结论。

还有一条不需控制 A 上端的壳层必要条件：A≥−n。对正 h=r，若 ell(s)>c_*r，则

\[
 N_+\le\frac{H+nr+Q(r)}{\ell(s)-c_*r}.                  \tag{N9}
\]

这是 nearmax 对扩尺度时新增 hard 坐标的数量限制；它不是该壳层在原接收积分中的价格。

## 5. 与原 δ/Π 的接口及真实未付费用

原实际时间仍记 t，z=c_jt/b；它与本稿 logscale 参数 h 无关。原

\[
 \delta_t(v,u)=(k_z(v)-k_z(u))_+,\quad
 k_z(v)=\#\{i:C((y_i-v_i)/b)<z\},
\]
\[
 {d\over d\log z}\log[w_z(v)/w_z(u)]
 =-k_z(v)+k_z(u)
\]

（避开有限阈值，或按 a.e. 导数理解）。(N1) 是同一接收位移 x−y 的物理尺度导数；上式是不同来源 y−v、y−u 的权重阈值导数。即使 (N8) 已知，也没有链式法则把 δ 改为 A。good/bad 只给同一终端的核值不等式，不能直接给上述两个不同导数的比较。一般 ν/Π 相关，不能把 δ 的条件方差按 n 个独立坐标求和。

因此本稿的准确下一接口是：在 (N6) 所刻画的近极大接收几何中，利用原 good/bad、high、同一 α 的 ρ 及 J_v，将原 Π_t² 加权的来源阈值差与上述可控尺度 score/真实壳层联系起来，并证明壳层项在原 dx、β、ν 上的占用费用。单有 (N8) 的 O(√n polylog n) 接收 score 不是这个接口的证明。

所有交通费用继续是原合同：

\[
 2\Lambda\,q^{-1}p\,h_R(x-z')a_\omega\,
 \rho_v\chi_{J,v}1_{\rm good}(v)1_{\rm bad}(u)\delta_t(v,u)
 \,d\Pi_t(v)d\Pi_t(u)\,{dt\over t}\,dx\,d\beta(y)d\nu(z').
\]

本文没有改变 α、Π、终端 g 或来源，未使用 hard 帽。若下一步先消去外 hard 来源，至多一次使用16/3，留下系数32Λ/3；安全时间费log2、列费n+2仍须支付，除非保留原唯一j到统一接收行帽。若再采用参数网格，其费另计；R168 正 Bernstein 混合仅对未取凹幂的 P 适用，不能免费搬到来源 score 或新凹幂上。

本稿未声称付清这些费，未证明 Wβ 或 q|E| 新预算。一般剩余中间域、尺度端点分支、大 T/L 分支、缩尺度跨界壳层及原来源 score 转移均保留。所得可复用内容仅为 (N5)–(N9) 的必要几何和其自足证明；没有固定模型认证，也没有邻近 m0 的常数优化。
