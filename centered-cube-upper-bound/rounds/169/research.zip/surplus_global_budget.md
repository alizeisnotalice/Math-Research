# R169：完整外 beta 的共同 reserve 门与不可免费求和处

状态：不登记人为折减权的“新增付款”。得到一个可严格核验的完整 beta 条件门：用共同 reserve q−K0nu 替代仅 sigma=beta−nu 的储备，无需截断r或支付eta层和。该门在K0(beta+nu)<q时可严格伸入R168旧门补集，但当前没有认证该交集的FULL/history正覆盖。一般middle预算未闭合。

## 1. 准确弱命题与符号条件

只用R169合同及本代理R168结果。固定原omega,V与实际(x,j)，原q是完整FIRST共同水平，K0=P_s,Hhat为同一合法future，nu≤beta≤f dx，U_y≤DK0。记

N=∫K0(x-u)dnu(u)， B=∫K0(x-y)dbeta(y)， R=q−N≥0，
QJ=∫J(x-u)dnu(u)， J=P1,b，
F_y(v)=TDelta_y(v)d_y(v)^2/[K0(x-y)wg(y,v)]，
d_y(v)=[1−DK0(x-v)/(TDelta_y(v))]+。                          (GB1)

F只在原positive的正商行使用。Delta=0、F=0而rho=0等零行不制造商。K0,B,N,R,QJ在固定(x,j)上不依外中心y或正在积分的v/u。它们不是逐来源重新选择的测试。

本稿的条件门为

    sqrt(n) B F_y(v)≤R。                                    (GB2)

B=0时beta=0而该叶零；R=0时GB2在原positive rho>0域为空，保留原交通到未付补集，不由R=0断言alpha=0。

准确候选是原完整beta正交通限制GB2（并可同时保留R169剩余middle全部资格）具有

    2Lambda P_beta,GB2
      ≤[8Lambda K log2/(9D)] sqrt(n) W_beta。                 (GB3)

这不是把F重新命名为未知范数：GB2是明确的实际核值和已知共同卷积N、B、q的条件。若没有该条件，目前没有GB3覆盖整个middle的证明。D沿原定义，不重新选择；K/D及门中d对D的依赖全部保留。

## 2. 与R168不同的储备入口及证明

R168只用了sigma的B_sigma=K0sigma。这里完整FIRST和原U给更强的、对全部y同时成立的

    alpha_y QJ=Dq−∫U_y dnu≥D(q−N)=DR。                      (GB4)

R可含同叶未计入sigma的完整输入储备，且在beta=nu时仍可为正。不能把R替换成独立可调参数，也不以截断来源重新计算q。

在R>0的原行，对既定R和实际alpha_y有

R rho_y(v)
 ≤R[d_y(v)−D R Jv/(QJ TDelta_y(v))]+
 ≤QJ TDelta_y(v)d_y(v)^2/(4D Jv)。                           (GB5)

它仅是原同alpha的数值上界，未重新选择alpha。定义固定行概率

    dM_x,j(y)=K0(x-y)dbeta(y)/B。                            (GB6)

M可依x,j，不能提出dx。与R168以sigma换测度不同，GB6直接用于完整外beta。

令I_j,t(x)为hard来源尚未计价的原行量，外beta、两份原Pi_y,t及全部good/bad、high、low-c、剩余middle、原时间和history资格均保留，并交GB2。由GB5、chiJ=Jv/(3Qv)以及原good p_y/Qv≤K/wg(y,v)，

I_j,t(x)
 ≤[KQJ/(12D)] (B/R)
   ∫dM_x,j(y)∫dPi_y,t(v)dPi_y,t(u)
         F_y(v) delta_y(v,u) 1_GB2
 ≤KQJ sqrt(n)/(12D)。                                       (GB7)

最后一步依次用(B/R)F≤1/sqrt(n)、原delta≤n和三份实际概率归一。没有用Pi_g替换Pi_t，也没有把nu总质量当成1。即使原终端门和alpha随x、y变，GB7仍是逐行不等式。

恢复raw只使用一次hard帽16/3和外2Lambda。每个j的原实际t窗包含于共同[a,b]；GB7右端只剩共同J=P1,b的QJ，不依j,t。因此先上放共同时间窗、在原x行内合并Σj1_{j(x)=j}≤1，再积分dx。时间价≤log2，∫QJ dx=||nu||，所以

2Lambda P_beta,GB2
 ≤(32Lambda/3)[K sqrt(n)/(12D)]log2 EΣV∫QJ,V dx
 ≤[8Lambda K log2/(9D)]sqrt(n)W_beta。                        (GB8)

这说明GB3的全部费用。接收自适应K0只出现在行概率和原条件中，未移出dx；归一接收核J的b是原块的固定b。不给另行重复块、history标签或j各领一次总价。负项仍按原账保留，本稿未调用负项。

## 3. 哪一部分确实越过旧门，哪一部分仍无覆盖证据

旧R168 surplus门是F≤1/sqrt(n)。GB2阈值是R/(B sqrt(n))，因此它伸入旧补集的准确必要区间为

    1<sqrt(n)F_y(v)≤(q−N)/B。                               (GB9)

该区间非空须有

    K0(beta+nu)=B+N<q。                                     (GB10)

特别地，beta=nu时只需2N<q便有阈值扩张的可能；此时旧sigma组件为空，而GB2仍是完整beta条件。GB10仅说明阈值有空间，不保证同时存在原positive rho、high、bad/score、middle和FULL/history。当前nu-only有限producer没有beta或完整输入f的实际构造，不能据它登记新增真实正覆盖。

另一个较弱但便于核验的推论：若N≤(1−gamma)q，gamma∈(0,1]，则B≤q、B/R≤1/gamma。因此保留旧F≤1/sqrt(n)即可支付完整beta，费用在GB3右端多gamma^(-1)。它不依r下门，但仍未越过旧F门。gamma若随n变小，逆费用不得隐藏。

GB2比这一gamma推论保留更多信息，因为它使用实际B/R而不是先以1/gamma统一上放。上述两个推论属于同一个reserve预算，不应对重叠原正项重复相加。

## 4. 不截断r的准确账目为何仍不能结清补集

令r=dnu/dbeta∈[0,1]、a=1−r，sigma=a beta。对sigma储备的原换测度Sigma=K0sigma/B_sigma，完整beta在{a>0}上的行估计会出现

    [KQJ/(12D)]
    ∫dSigma_x,j(y)∫dPi_y,t(v)dPi_y,t(u)
        [F_y(v)/a(y)] delta_y(v,u)。                         (GB11)

a=0部分是未被sigma覆盖的原nu组件，不能删除。GB11只展示实际费用，不登记其右端为新的已付范数。

若将a分为dyadic层E_k={2^(-k-1)<a≤2^(-k)}，各层应在同一个Sigma下相加。设B_k=∫E_k K0 dsigma，则真实层权为B_k/B_sigma；不能在每层重新领取完整∫QJ dx预算后再免费求和eta_k^(-1)。即使不含F，准确地

    ∫_{a>0} a^(-1)dSigma
      = [∫_{a>0}K0 dbeta]/B_sigma，                         (GB12)

也没有由nu≤beta得到的统一上界。F在旧门补集还可更大。使用GB4可把sigma储备增强到共同R，得到GB7的(B/R)F；但这仍需要GB2或实际同一测度下的进一步估计。

本稿没有将omega=min(1,a/(sqrt(n)F))等人为折减登记为实质新增分支。即便它可写出一个有限加权账，其余1−omega在a→0或F大时仍接近1，未产生一般middle吸收。迭代使用同一alpha储备也不是新预算。

## 5. 原nu能否提供互补reserve：精确恒等式与对角陷阱

原capture密度c_y(z)=U_y(z)/(DK0(x-z))∈[0,1]依外中心y。由完整输入F_input=f dx，准确有

alpha_yQJ/D
 =[q−K0F_input(x)]+K0(F_input−beta)(x)
  +∫K0(x-z)[1−r(z)c_y(z)]dbeta(z)。                        (GB13)

三项非负。GB13将外sigma与nu未捕获部分放在同一真实reserve中，比只保留sigma信息更完整；仍不授予多个独立容量。

在z=y处，原w_tau(y,y)=w_h(y,y)=1，故Delta_y(y)=0、U_y(y)=0，形式上1−r(y)c_y(y)=1。这个对角事实不能把GB13的z积分替换成外beta(dy)：L1连续模型的对角没有原子质量，且c_y(z)随外y改变。

若为每个y将最后一项归一成一个关于z的概率，它是以y为参数的另一个来源核，不是外beta(dy)的Radon--Nikodym换测度。尚须证明其真实列预算/接收比较，并保留实际支持、归一化、终端门与alpha_y；不能沿用R168的共同B_sigma或本稿共同R，把中心依赖的reserve当成一个共同标量概率。

因此nu的未捕获部分确在原reserve内，但本轮没有证明它能在GB2补集上形成可求和的互补捕获。

## 6. 三阶段核验、停止点与结果身份

初步：核GB4使用的是完整输入q与合法K0；GB5保留实际alpha，GB6为外完整beta的真实换测度；GB7归一和原delta顺序合法。R=0不等于alpha=0，不能误删其余正项。D或gamma随n变化时，门和费用一并保留。

已有压力：beta=nu使全部sigma方法失效，却不必使GB2为空；这是检查共同full reserve所需的边界。反方向，N趋q时R趋零，GB2缩小，源密度r的层数不能弥补该饱和。R169当前有限必要模型尚缺完整输入补全，故不从其q或nu-only数据推断GB9中的真实覆盖。

扩大范围：GB3是任意相关来源、原合法接收选择器及任意原middle子集上的条件估计，无产品来源或固定尺度假设。没有证明所有middle满足GB2，也没有认证其在旧门补集的新增FULL正覆盖。只把严格条件预算及其费用记录供审；不登记一般middle新结论。

最具体未证处是原剩余positive在

    sqrt(n) B(x,j) F_y(v)>q−N(x,j)

上的完整raw积分。若依靠r分层，需在同一个原测度下支付GB11/12的实际逆surplus因子；若依靠nu互补储备，需给GB13中心依赖核的真实列预算。两者均未证明。到此交付停止，不扩展人工权重路线。
