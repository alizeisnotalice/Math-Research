# R169 score/参数变分：决策工具表

**结论：没有定位到可把一般physical scale score或TV预算直接接成当前δ外价的已审64工具。** F04/F05可提供有明确输入的平方函数/Schur构件，N03当前没有匹配的振荡模型。真正包含hard面跳跃的已审参数变分在项目旧CS证明；真正涉及当前k_t的已审能量在R135。两者的score、底测度与当前raw费用不同，缺失的是连接及原外价，不能再以“已有平方函数”替代这一步。本轮只读以下技能及两个最相关历史最小段，无外网/新外文定理调用，无数值或新引理认证。

## ST1. 三种score必须区分

1. 当前来源阈值score：\(k_t(v)=\#\{\alpha_i(y,v)<t\}\)，\(\partial_{\log t}w_t=-k_tw_t\)；δ=(k_t(v)−k_t(u))_+，后验是原 \(\Pi_t=1_{Z_t}w_t\nu/e_t\)。t导数还遇到来源阈值注入与Z删除。
2. 原混合核的observed softness score：\(a_s(r)=(\phi(r)-h(r))/p_s(r)\)，固定真实概率密度p_s下均值0。它不是Π内的k_t。
3. physical dilation的regular observed score：旧CS记 \(S_s=\sum_i w_s\)、\(w_s(r)=\beta_s(r)|r|[-\log\phi]'(|r|)\)，regular log尺度导数为(S_s−n)P；另有hard面奇异测度。它既非a_s，亦非k_t，不能把其方差或尾帽直接贴给δ。

**不可遗漏的hard边界。** 对一维 \(h_L=L^{-1}1_{[-L/2,L/2]}\)，分布意义上
\[
 \partial_{\log L}h_L=-h_L+\tfrac12(\delta_{L/2}+\delta_{-L/2}).
\]
因此混合p_s,L的每个hard面带系数(1−s)/2；n维须乘其余n−1坐标概率核再求面和。只将regular导数除以p形成L2 score不会表示这些与dx奇异的face项。混合s/尺度再求导，还须微分face系数与其余切向概率因子。若直接在接受集合/history下做参数分部积分，接受门的变动也须单独说明；原核BV结论不让这些新门导数消失。

## ST2. 更新64项：准确支持范围与当前缺项

|实读工具|已支持的准确构件|hard边界、真实dx及当前迁移缺项|
|---|---|---|
|`/Users/zhengzhihao/.codex/skills/math-f04-poisson-gamma-abel-square-function/SKILL.md`，执行1–5及`references/cube-interface.md`|Hilbert空间非负自伴L，P_t=e^-t√L；正确平方函数为∫_0∞t||∂tP_tf||²dt=¼||(I−ΠkerL)f||²。Γ混合需shape/rate>0及实际Laplace域。|没有给当前带hard面跳跃的P_s,L一个该半群/谱表示，也没给与cube尺度族的支配或误差；其cube接口明确这些连接仍缺。去掉t权会换成L^(1/4)范数，不是同一恒等式。一般正L1输入也非自动L2。逐谱Abel极限不能控制sup或δ。不能对hard面作普通dx导数后称已得到全variation平方函数。|
|`/Users/zhengzhihao/.codex/skills/math-f05-l2-spectral-parameter-schur-test/SKILL.md`，执行1–4、6–8及cube-interface|给定两输入输出测度、可测核A_λ与正权p,q，同时有∫|A|q≤Rp及∫|A|p≤Cq，且R,C统一，Cauchy–Schwarz给L2算子范数≤√RC；有限LM*逐项乘子是另一独立有限矩阵构件。|当前原dx/ν/β、e_t与同源乘积、接收selector必须先定义为同一个算子及其两侧测度，实际统一row和column均未建立。TV/一侧行帽不能代替两侧Schur；固定λ范数不控制随x取sup。若把face测度纳入核，也须用适合的测度并重证两侧预算，不能默认为L2(dx) density。survey外引反向因子化仍citation-only，非当前δ工具。|
|`/Users/zhengzhihao/.codex/skills/math-n03-oscillation-and-geometric-remainder/SKILL.md`，当前边界、执行1–6及cube-interface|当前只绑定所列Jacobian恒等式/简单振荡例。vdC模型须明确I(λ)=∫e^(iλΦ)ψ、相位全支撑非退化导数、振幅正则、支撑与端点；k=1另需Φ′单调等源条件。|当前raw为正积分，没有已给振荡相位、导数下界或可付分片；引入Fourier不自动产生正交通的有利抵消。hard跳振幅须逐片含端点/face余项；N03不提供这一余项的原Wβ费用。半密度/GP私人名称需原定义和连接，不能按标题调用。|

三项均只按上述构件使用，没有为本题添加“scale score平方函数控制δ”的来源定理。一个可用的新Schur路线至少应交真实两侧核和统一预算；一个可用的新谱路线至少应交半群/尺度连接及face余项。这些数据未交时，继续泛查相似标题不能改善当前决策。

## ST3. 两条最相关已审历史，及其停止位置

**A. 已严审的hard参数BV与两参数包络（可用，但不是当前δ）。** 本机原文件
`/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/high_marked_cover/next_spatial_compensated_split.md:28–120`，独审同目录 `compensated_split_review.md:22–64`。

- 真一坐标p_s概率下，Ew_s=s、Ew_s²<28；s≥1/2时a_s均值0、|a_s|≤10。真实乘积核给坐标方差，未假设来源后验独立。
- 对0<t_tilt≤1/20，倾斜j_s,t=p_s exp[t_tilt(w_s−s)]质量m满足1≤m≤exp(3000t_tilt²)。完整dilation TV≤10000m，显式证书实际<35m；包括inside cusp、outside分部积分边界及hard face atom。该倾斜核**非射线递减**，原稿与独审明确禁止用ray-monotone公式替代BV。
- 固定s的真实dx尺度包络≤[1+10000n log2]m^n；s≥1/(4n)再付≤102n³软度网格及e倍率，得到联合selector包络。它没有对tilted核使用原FIRST免费上界。
- 在s∈[1−d,1]、d<1/2，完整混合s/尺度TV（含face系数和切向因子导数）经两参数FTC给CS10；代d=A/√n得O(√n(1+A+A²))的真实dx强包络。TOP/LOWTRACE原付款使用同一完整输入与W_full；不能无证替换为当前条件来源/Π，也不能重复登记已删除的近全soft条带。

**本轮决策：** 如要估计实际kernel selector，这是一条现成且保留hard项的项目合同，应引用原CS而非F04标题。若要从上述S_s变成当前k_t/δ，仍缺同一原输入、实际来源权/删除与外dx dβ的连接；只把两者都叫score没有作用。

**B. 当前δ的能量恒等式与真实外价（最近的直接合同）。** `rounds/135/research.zip:proof.md:47–100,123–152,186–229`（仓库绝对根同本任务）。

- 固定有限ν、0<τ<g、正坐标阈值，u=log t；用右态k̄_t=#{α_i≤t}处理Stieltjes端点。固定支持时dE_Π k̄=dC−Var_Π(k)du；dC准确按每个阈值的w_α/e_α加权注入，重复阈值按坐标次数计，不能只按“每源最多n次”丢掉后验分母。实际Z删除再加有符号dM_del，删除均值跳幅≤n r_u/e_{u−}；原同点先删除、再计穿越，端点按原右态约定。
- 两份同Π抽样有Eδ≤√(Var/2)。令S_r=C_r+n+nR_del,r，则完整行内score价≤√[(log2)S_r/2]。恢复原raw后，价格仍为 \(2\Lambda\sqrt{\log2/2}\int1_{high}\sqrt{S_r}\,d\mathcal T_I\)。即使逐行S_r=O(n polylog n)，只配Tsmall≤4X仍给O(√n polylog n)X，未付成εX+C√n polylog nWβ。
- 同稿SC1–4另证来源中心Lebesgue能量：\(\int e(y)Var_{\Pi_y}k\,dy\le z^n||\nu||n\theta(1-\theta)\)，并有正δ的√n伴随界。其底测度是e_t(y)dy/z_t^n，非当前dx dβ(y)。当前恢复的β≤f dx确给β绝对连续，但仍没有β密度被该信道权支配的价格；不能照旧稿“未假定AC”措辞否认已恢复合同，也不能由AC跳过密度比/et预算。

**本轮决策：** 当前缺口已经精确到阈值注入、删除变动及原外行平方根负载。一个新工具须实际支付其中一项或给同域联合几何控制，不能重报Var→δ的Cauchy、坐标穿越n次或kernel TV为新付款。共同FIRST只约束同一原输入的合法future核；改变到tilted核、删源posterior或面测度后均需重新核连接。hard帽一次、j/time、来源Wβ与真实dx依原合同保留。

交付停止：现有工具可支持核变分与明确算子检验；没有已证无费连接可把它们直接换成当前剩余δ的根阶外价。本文件不扩展为失败路线综述，不运行新实验或认证新引理。
