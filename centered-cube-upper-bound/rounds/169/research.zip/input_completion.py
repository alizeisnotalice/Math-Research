#!/usr/bin/env python3
"""R169 positive completion of a fixed finite nu; never re-optimize nu/alpha."""
from pathlib import Path
from fractions import Fraction as F
import importlib.util
import hashlib,json,math

SOURCE_DIR=Path(__file__).resolve().parent
HERE=SOURCE_DIR
DEP=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round168_20261016_final_checkpoint/middle_source_lp.py')
INPUT=DEP.with_name('middle_source_lp.json')
sp=importlib.util.spec_from_file_location('r168_completion_tools',DEP);prior=importlib.util.module_from_spec(sp);sp.loader.exec_module(prior)
old,np,mp,linprog=prior.old,prior.np,prior.mp,prior.linprog


def fs(v):return str(v.numerator) if v.denominator==1 else str(v)


def kernel(s,scale,xq,positions):
    """Exact rational hard-mask decisions, including L=.9 boundary atoms."""
    sq=F(scale);ss=float(s);out=[]
    for row in positions:
        d=[xq[i]-row[i] for i in range(len(xq))]
        hh=np.array([abs(z)<=sq/2 for z in d],dtype=float)
        phi=old.phi_np(np.array([float(z/sq) for z in d]))
        out.append(float(np.prod(((1-ss)*hh+ss*phi)/float(sq))))
    return np.array(out)


def future_nodes(xq,positions,sdense=17,ldense=81):
    us=[F(1,4)+F(3,4)*F(i,sdense-1) for i in range(sdense)]
    ls={F(1,2)+F(1,2)*F(i,ldense-1) for i in range(ldense)}
    thresholds=set()
    for row in positions:
        # Include each coordinate threshold: mixed hard masks need not wait
        # until all coordinates enter the hard cube simultaneously.
        thresholds.update(2*abs(xq[i]-row[i]) for i in range(len(xq)))
    legal=sorted(z for z in thresholds if F(1,2)<=z<=1)
    for z in legal:
        for e in (-F(1,10**8),F(0),F(1,10**8)):
            if F(1,2)<=z+e<=1:ls.add(z+e)
    return [(u,l) for u in us for l in sorted(ls)],legal


def solve_completion(xq,nu_pos,nu,q,lam,atoms,fixed=None):
    nodes,thresholds=future_nodes(xq,nu_pos+atoms)
    qf=float(q);cur=kernel(F(1,4),F(9,10),xq,nu_pos);avec=kernel(F(1,4),F(9,10),xq,atoms)
    gap=qf-float(cur@nu);au=[];bu=[]
    for u,l in nodes:
        au.append(kernel(u,l,xq,atoms)/qf);bu.append((qf-float(kernel(u,l,xq,nu_pos)@nu))/qf)
    hard=lambda row:all(abs(xq[j]-row[j])<=F(1,2) for j in range(4))
    hnu=sum(float(nu[i]) for i,row in enumerate(nu_pos) if hard(row))
    au.append(np.array([float(hard(row)) for row in atoms])/(4*float(lam)));bu.append((4*float(lam)-hnu)/(4*float(lam)))
    bounds=[(0,None)]*len(atoms)
    for index,mass in (fixed or {}).items():bounds[index]=(float(mass),float(mass))
    res=linprog(np.ones(len(atoms)),A_ub=np.array(au),b_ub=np.array(bu),A_eq=[avec/qf],b_eq=[gap/qf],bounds=bounds,
                method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    record=dict(atom_positions=[[fs(z) for z in row] for row in atoms],fixed_masses={str(k):fs(v) for k,v in (fixed or {}).items()},
                success=bool(res.success),message=res.message,current_gap=gap,current_atom_coefficients=avec.tolist(),
                future_node_count=len(nodes),legal_hard_thresholds_exact=[fs(v) for v in thresholds])
    if len(atoms)==1 and avec[0]>0:
        forced=float(gap/avec[0])
        ratios=[float(1-bu[k]+au[k][0]*forced) for k in range(len(nodes))]
        k=max(range(len(nodes)),key=lambda j:ratios[j]);u,l=nodes[k]
        forcedhard=hnu+float(hard(atoms[0]))*forced
        record['single_atom_current_equality_forces']=dict(mass=forced,hard_F=forcedhard,hard_cap=4*float(lam),
            future_worst=dict(u_exact=fs(u),L_exact=fs(l),over_q=ratios[k]),
            future_conflict=ratios[k]>1+1e-10,hard_conflict=forcedhard>4*float(lam)+1e-10)
    if res.success:
        masses=res.x;tests=[]
        for u,l in nodes:
            val=float(kernel(u,l,xq,nu_pos)@nu+kernel(u,l,xq,atoms)@masses)
            tests.append(dict(u_exact=fs(u),L_exact=fs(l),F_kernel=val,over_q=val/qf))
        htotal=hnu+sum(float(masses[i]) for i,row in enumerate(atoms) if hard(row))
        record.update(masses=masses.tolist(),current_F=float(cur@nu+avec@masses),current_equality_abs_error=abs(float(cur@nu+avec@masses)-qf),
                      future_worst=max(tests,key=lambda r:r['over_q']),future_exceedances_tolerance_1e_minus10=sum(t['over_q']>1+1e-10 for t in tests),
                      hard_F=htotal,hard_cap=4*float(lam),hard_slack=4*float(lam)-htotal,total_F_mass=1+float(sum(masses)),
                      minimum_scaled_LP_residual=float(min(np.array(bu)-np.array(au)@masses)))
        # Save one-sided current-scale pressure explicitly rather than only a
        # maximum attained at the prescribed equality node.
        record['current_scale_jump_checks']=[dict(L_exact=fs(l),F_kernel=float(kernel(F(1,4),l,xq,nu_pos)@nu+kernel(F(1,4),l,xq,atoms)@masses))
                                              for l in (F(9,10)-F(1,10**8),F(9,10),F(9,10)+F(1,10**8))]
    return record


def mp_base(xq,nu_pos,nuF,qF,lamF,r,slot=F(0)):
    mp.mp.dps=70;M=lambda z:mp.mpf(z.numerator)/z.denominator if isinstance(z,F) else mp.mpf(str(z))
    nu=list(map(M,nuF));q=M(qF)
    def pp(row):
        # Even mp subtraction can put a closed hard endpoint one ulp outside;
        # decide this discontinuous branch in Fraction, not rounded mp values.
        dd=[xq[j]-row[j] for j in range(4)];L=F(9,10);s=M(F(1,4))
        return mp.fprod(((1-s)*int(abs(d)<=L/2)+s*old.phi_mp(M(d)/M(L)))/M(L) for d in dd)
    current_nu=mp.fsum(nu[i]*pp(nu_pos[i]) for i in range(3));co=pp(r);at_y=pp([F(0)]*4)
    mass=(q-current_nu-M(slot)*at_y)/co
    hardF=M(nuF[2])+mass # y=0 is outside the R=1 hard cube at this receiver.
    return dict(sigma_boundary_mass=mp.nstr(mass,35),current_nu=mp.nstr(current_nu,35),current_boundary_coefficient=mp.nstr(co,35),
                current_slot_coefficient=mp.nstr(at_y,35),slot_mass_exact=fs(slot),
                exact_mass_formula='M=(q-Pcurrent(nu)-slot*Pcurrent(delta_y))/Pcurrent(delta_r)',
                exact_current_equality_by_definition=True,hard_F=mp.nstr(hardF,35),hard_slack=mp.nstr(4*M(lamF)-hardF,35))


def main():
    data=json.loads(INPUT.read_text());sel=data['selected_rational_candidate'];g=sel['geometry']
    assert g['n']==4 and g['s']==.25 and g['L']==.9 and g['R']==1 and g['a']==.5 and g['b']==1
    xq=list(map(F,g['xq']));nu_pos=[list(map(F,row)) for row in g['positions']];nuF=list(map(F,sel['nu_exact']));nu=np.array(list(map(float,nuF)))
    q=F(sel['q_exact']);lam=F(sel['lambda_exact']);r=[z+F(9,20) for z in xq]
    base=solve_completion(xq,nu_pos,nu,q,lam,[r])
    pressure=[]
    for d,signs in ((F(2,5),[1]*4),(F(49,100),[1]*4),(F(9,20),[-1]*4),(F(9,20),[1,-1,1,-1])):
        atom=[xq[i]+signs[i]*d for i in range(4)]
        pressure.append(dict(offset_exact=fs(d),signs=signs,result=solve_completion(xq,nu_pos,nu,q,lam,[atom])))
    y=[F(0)]*4;slot=F(1,10**8)
    beta_slot=solve_completion(xq,nu_pos,nu,q,lam,[r,y],{1:slot})
    refined_path=DEP.with_name('lp_refined_certificate.json')
    out=dict(scope='Fixed R168 refined nu/q geometry; seek nonnegative sigma only. Atomic F is not an L1 density or a FULL history realization.',
             inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (DEP,INPUT,refined_path,Path(old.__file__))},
             fixed_input=dict(nu_exact=sel['nu_exact'],q_exact=sel['q_exact'],lambda_exact=sel['lambda_exact'],xq=g['xq'],yq=g['yq'],
                              nu_positions=g['positions'],s=g['s'],L=g['L'],a=g['a'],b=g['b'],R=g['R'],
                              original_alpha=sel['mp70']['alpha'],original_rho=sel['mp70']['rho'],alpha_not_recomputed_from_F=True),
             linear_model=dict(variables='sigma atom masses >=0; original nu and q fixed',current='Pcurrent sigma=q-Pcurrent nu',
                               future='Pfuture sigma<=q-Pfuture nu at legal pressure nodes',hard='h_R sigma<=4lambda-h_R nu',
                               mass='No total-F normalization; F=nu+sigma',hard_endpoint='h=1 on the closed cube; all hard masks decided with exact rational positions/scales'),
             stages=dict(initial_boundary_atom=base,pressure_other_offsets_and_signs=pressure,optional_beta_slot=beta_slot),
             exact_formula_mp70=dict(base=mp_base(xq,nu_pos,nuF,q,lam,r),beta_slot=mp_base(xq,nu_pos,nuF,q,lam,r,slot)),
             summary=dict(base_success=base['success'],beta_slot_success=beta_slot['success'],
                          base_future_exceedances=base.get('future_exceedances_tolerance_1e_minus10'),
                          beta_slot_future_exceedances=beta_slot.get('future_exceedances_tolerance_1e_minus10'),
                          base_hard_slack=base.get('hard_slack'),beta_slot_hard_slack=beta_slot.get('hard_slack')),
             limitations=['Finite future pressure is not continuum FIRST certification; independent audit treats the analytic boundary-mass candidate.',
                          'The supplement is excluded from nu and therefore is not allowed to alter its alpha/rho/Pi.',
                          'The optional beta slot permits an atomic beta choice but does not construct original beta/history labels.',
                          'Boundary atoms are not an L1 density, and no smoothing or continuous receiver dx volume is asserted.',
                          'Independent audit reports fixed-mass symmetric product-box smoothing has current-value limit about .00063111<q; retuning that smoothing mass violates the hard cap. This does not rule out every other L1 construction.'])
    (HERE/'input_completion.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(summary=out['summary'],mp70=out['exact_formula_mp70']),indent=2))


if __name__=='__main__':main()
