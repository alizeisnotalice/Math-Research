# R169：真实 soft/scale score 的根阶部分、硬面线性项与原 δ 接口

状态：一般“真实 logscale 导数的 L1/L2 根阶预算”候选不成立；明确的分布导数分解显示线性硬面项。固定参数的 soft score 和去均值尺度 bulk 有根阶界，但没有据此取得原剩余 raw 的新付款。本稿的有效结果是排除遗漏硬面后的错误迁移，给出准确弱式、变化量及尚缺的联合接口。

仅读取 R169 task_contract、R168 共同 FIRST／R 增益补集定义，以及 R166 已审 log phi 控制。全为解析筛查，未作数值试验，不以有限模型当 FULL，不 Git、不 spawn，仅写本文件。

## 1. 命题筛查与准确对象

固定来源 y、soft s∈(0,1] 和尺度 L>0，令

\[
 h(t)=1_{[-1/2,1/2]}(t),\quad f_s=(1-s)h+s\phi,
 \quad p_{s,L}(x-y)=L^{-n}\prod_{i=1}^nf_s((x_i-y_i)/L).
 \tag{1}
\]

记 μ_s,L(dx)=p_s,L(x−y)dx，r=log L。这里 μ 是单位核测度，不是原来源 β、ν 或 Π 的概率化。

要筛查的三个命题分别是：

1. 固定参数 soft score U=∂s log p 的 L1/L2(dx p) 根阶界。
2. 真实尺度导数 ∂r μ 的总变差或二次均方 score 根阶界，必须包括硬面。
3. 以上核恒等式是否能支付原 R<e^H 中间域中的 δ=(kξ(v)−kξ(u))+。

结论：(1)成立并有显式 s 下门费用；(2)对一般 s<1不成立，只有去均值 bulk 根阶；(3)尚无合法迁移。原 δ、Π、same-alpha、接收门不是核 score，不能因都出现 n 个坐标就相互替换。

下文使用常数

\[
 a_\phi=\phi(1/2)>0,\quad
 C_{\rm soft}=a_\phi^{-1}-1,\quad
 L_\phi=\frac2{1-e^{-1}},\quad
 J_\phi=\int_\mathbb R\frac{t^2\phi'(t)^2}{\phi(t)}dt.
 \tag{2}
\]

R166 已审 |(log phi)'|≤Lphi，故

\[
 J_\phi\le L_\phi^2\int t^2\phi(t)dt
 =\frac{13}{12}L_\phi^2<\infty.
 \tag{3}
\]

最后一个矩恒等式自足核验：h 的二阶矩为1/12；
\(\int t^2w(t)dt=\int_0^14v^3dv=1\)；两者偶对称且质量1，所以卷积 phi=h*w 的二阶矩为13/12。所有积分可由正 Tonelli 计算。

## 2. 初步：固定参数的 soft score 根阶界

定义单坐标

\[
 u_s(t)=\frac{\phi(t)-h(t)}{f_s(t)},\qquad
 I_s=\int\frac{(\phi-h)^2}{f_s}dt.
 \tag{4}
\]

s>0 时 f_s>0，且

\[
 \int u_s f_s=0,
 \quad I_s\le\frac1s\int\frac{(\phi-h)^2}{\phi}
 =\frac1s\left(\int_{-1/2}^{1/2}\frac{dt}{\phi(t)}-1\right)
 \le\frac{C_{\rm soft}}s.
 \tag{5}
\]

这里使用 phi≥a_phi 于硬支撑内。该界在 s=1 仍有限；不需要人为引入 (1−s)^{-1}。

产品核给真正的 dx p 独立坐标积分（仅针对固定核，并非独立来源假设）：

\[
 U_{s,L}(x)=\partial_s\log p_{s,L}(x-y)
 =\sum_i u_s((x_i-y_i)/L),
\]
\[
 \int U_{s,L}p_{s,L}dx=0,\qquad
 \int U_{s,L}^2p_{s,L}dx=nI_s.
 \tag{6}
\]

因此

\[
 \boxed{\|\partial_s p_{s,L}\|_{L^1(dx)}
 \le\sqrt{nI_s}\le\sqrt{nC_{\rm soft}/s}.}
 \tag{7}
\]

在对数 soft 参数下，\(\|s\partial_s p\|_1\le\sqrt{nC_{\rm soft}s}\)。对 s∈[s0,1] 的固定 L 总变化量为

\[
 \int_{s_0}^1\|\partial_s p_{s,L}\|_1ds
 \le2\sqrt{nC_{\rm soft}}(1-\sqrt{s_0}).
 \tag{8}
\]

s0↓0 时积分界仍有限，但 s=0 点不具有本文相对于 p0 的有限 Fisher score：硬支撑外 p0=0 而 ∂s p产生新质量。不能将 (7) 的 s^{-1/2} 删除。

固定 L 的正选择器包络也可直接估计：

\[
 \sup_{s_0\le s\le1}p_{s,L}(x-y)
 \le p_{s_0,L}(x-y)+\int_{s_0}^1(\partial_s p_{s,L})_+(x-y)ds.
\]

由于每个 soft 导数的总质量为0，正部积分等于半个L1范数，得到

\[
 \boxed{\int\sup_{s_0\le s\le1}p_{s,L}(x-y)dx
 \le1+\sqrt{nC_{\rm soft}}(1-\sqrt{s_0}).}
 \tag{9}
\]

这是固定来源的 column 界。它不允许在任意源测度 dβ(y) 的 receiver 行中替换 R168 的 Bernstein future 平均，因为 (6) 的产品积分测度是 dx p，不是 dβ，也不是带原门的Π。

## 3. 已有压力：尺度导数的真实硬面项

### 3.1 分布导数的精确公式

一维分布导数为

\[
 \partial_{\log L}[L^{-1}f_s((x-y)/L)]
 =\left[-L^{-1}f_s(t)-sL^{-1}t\phi'(t)\right]dx
 +\frac{1-s}{2}(\delta_{y-L/2}+\delta_{y+L/2}),
 \quad t=(x-y)/L.
 \tag{10}
\]

右边第一项表示密度对应的测度；等式在测试函数弱意义下使用。每个边界系数是(1−s)/2，不能把边界当作dx零集丢掉。

在n维，令

\[
 g_s(t)=-\frac{s t\phi'(t)}{f_s(t)},\quad
 Z_{s,L}(x)=\sum_i[-1+g_s(t_i)],
 \quad t_i=(x_i-y_i)/L.
\]

则

\[
 \boxed{\partial_r\mu_{s,L}
 =Z_{s,L}(x)p_{s,L}(x-y)dx+\Sigma_{s,L},}
 \tag{11}
\]

\[
 \Sigma_{s,L}=
 \frac{1-s}{2}\sum_{i=1}^n\sum_{\epsilon=\pm1}
 \delta_{y_i+\epsilon L/2}(dx_i)
 \prod_{j\ne i}L^{-1}f_s((x_j-y_j)/L)dx_j.
 \tag{12}
\]

不同面的交线对各面测度为零，不改变总质量。由 \(\int-t\phi'(t)dt=1\)，

\[
 \Sigma_{s,L}(\mathbb R^n)=n(1-s),\qquad
 \int Z_{s,L}p_{s,L}dx=-n(1-s).
 \tag{13}
\]

分布导数总质量为0，正好由正硬面和负bulk均值抵消。

### 3.2 不能成立的根阶候选

总变差范数取整份 signed measure 的质量，即无额外1/2 convention。硬面奇异于dx，故

\[
 \boxed{\|\partial_r\mu_{s,L}\|_{\rm TV}
 =\int|Z_{s,L}|p_{s,L}dx+n(1-s)
 \ge2n(1-s).}
 \tag{14}
\]

例如固定 s=1/2，真实尺度导数TV至少n，不可能有维数无关的 C√n 帽。纯硬s=0时TV恰为2n。这直接筛掉“略掉面后把真实尺度score当中心化和”的候选。

更强地，对任意实数 A、B，因为 soft 导数完全绝对连续且总质量0，

\[
 \boxed{\|A\partial_s\mu+B\partial_r\mu\|_{\rm TV}
 \ge2|B|n(1-s).}
 \tag{15}
\]

联合soft变化不能取消尺度方向的奇异硬面；把soft和scale score混合并不会自动恢复一般根阶。

二次均方score同样遇到真实障碍。令

\[
 \Delta_s=\sqrt{1-s+s a_\phi}-\sqrt{s a_\phi}>0\quad(s<1).
\]

单坐标尺度L与Le^h之间，两端硬面扫过的总长度为L|h|+o(|h|)；由phi连续，光在这些窄条上就有

\[
 \liminf_{h\to0}\frac1{|h|}
 \int(\sqrt{p_{s,Le^h}^{(1)}}-\sqrt{p_{s,L}^{(1)}})^2dx
 \ge\Delta_s^2.
\]

产品Hellinger亲和度恰为单坐标亲和度的n次方，故固定n时

\[
 \liminf_{h\to0}\frac1{|h|}
 \int(\sqrt{p_{s,Le^h}}-\sqrt{p_{s,L}})^2dx
 \ge n\Delta_s^2>0.
 \tag{16}
\]

只需窄条下界和尺度核的L1连续性，无需声称完整渐近等式。若存在有限L2平方根尺度导数，该Hellinger平方应为O(h²)，与(16)矛盾。因此s<1的真实尺度族不是可直接赋予有限L2 logscale score的光滑族。单独bulk的有限二阶矩不能替代它。

## 4. 去均值bulk的根阶预算及变化量

g_s≥0（phi偶单峰），并且

\[
 \int g_s f_s=s,\qquad
 \int g_s^2f_s
 =s^2\int\frac{t^2\phi'^2}{f_s}
 \le sJ_\phi.
\]

设

\[
 V_s=\int(g_s-s)^2f_s\le sJ_\phi-s^2,
 \quad \widetilde Z_{s,L}=Z_{s,L}+n(1-s)
 =\sum_i(g_s(t_i)-s).
\]

由产品积分

\[
 \int\widetilde Zp\,dx=0,\quad
 \int\widetilde Z^2p\,dx=nV_s,\quad
 \int|\widetilde Z|p\,dx\le\sqrt{nV_s}.
 \tag{17}
\]

因此真实尺度变化的显式上下界是

\[
 \boxed{2n(1-s)\le\|\partial_r\mu\|_{\rm TV}
 \le2n(1-s)+\sqrt{nV_s}.}
 \tag{18}
\]

s=1时硬面消失，真实全软尺度score确实根阶，且V1=Jphi−1。若1−s=O(n^{-1/2})，(18)也允许根阶；这只是公式的范围说明，不是原一般中间域已经落入该范围的证明。

沿固定s的整个octave积分，总代价至多

\[
 \log(b/a)[2n(1-s)+\sqrt{nV_s}].
 \tag{19}
\]

还可把接收点所选尺度的**原核质量**作合法包络。对固定x，L↦p_s,L(x−y)是分段光滑且所有硬支撑进入跳跃非负；正变化由bulk正部和这些硬面跳跃组成。正Tonelli给

\[
 \int\sup_{a\le L\le b}p_{s,L}(x-y)dx
 \le1+\int_{\log a}^{\log b}
 [\int(Z_{s,L})_+p_{s,L}dx+n(1-s)]dr.
\]

由 \((Z)_+\le(\widetilde Z)_+\) 和中心化，

\[
 \boxed{\int\sup_{a\le L\le b}p_{s,L}(x-y)dx
 \le1+\log(b/a)[n(1-s)+\tfrac12\sqrt{nV_s}].}
 \tag{20}
\]

这里面项的积分可直接由每个x的跳跃位置L=2|x_i−y_i|换元核验，正好是(12)逐r积分。该式付清了原核的适应尺度费用，仍显示一般s的线性项。它不是 \(\int p_{s(x),L(x)}|Z_{s(x),L(x)}|dx\) 的根阶上界，也不使(17)在任意选择器下自动成立。

## 5. 优先核验的弱式：面项何时才能抵消

对任意固定光滑紧支撑测试ψ，尺度推前恒等式给

\[
 \frac d{dr}\int\psi(x)d\mu_{s,e^r}(x)
 =\int (x-y)\cdot\nabla\psi(x)\,p_{s,e^r}(x-y)dx.
 \tag{21}
\]

由(11)等价地写为

\[
 \frac d{dr}\int\psi d\mu
 =\int\psi\widetilde Zp\,dx
 +\int\psi d\Sigma-n(1-s)\int\psi p\,dx.
 \tag{22}
\]

(22)明确展示根阶部分及剩下的“硬面trace减bulk平均”。ψ≡1时后两项抵消；对于一般带门测试，二者没有相等合同。仅ψ∈[0,1]最多给线性n(1−s)费用，不能调用中心化免费消掉。

原资格、high/good/bad、rho、future增益不足指示和当前尺度选择未提供这里所需的光滑性、面trace或梯度预算。若ψ也依参数，(21)还要增加 \(\int\partial_r\psi\,d\mu\)；不得漏掉same-alpha、终端wg、允许时间域或选择器的变化。对仅按dx定义的粗糙门，直接把ψ乘到奇异面测度甚至需要先明确trace版本。

R168剩余 \(R(x,y)=\sup_{u\ge s,t\in[a,b]}P_{u,t}(x-y)/p<e^H\) 只给有限核比上帽，不给差商除以尺度步长后的统一variation界，也不给(22)的trace抵消。一个硬面跳跃的核比可为有限常数，但其分布导数仍是面原子。故不能从“future增益不足”直接推断真实尺度score在这里没有奇异部分。

## 6. 与原 δ 的合法恒等式及不能迁移的原因

固定原y,v,u和阈值ξ，令 \(C_i(v)=C((y_i-v_i)/b)\)，

\[
 w_\xi(v)=\prod_i\min(1,C_i(v)/\xi),\quad
 k_\xi(v)=\#\{i:C_i(v)<\xi\}.
\]

在有限个断点之外，有精确的一维阈值恒等式

\[
 \partial_{\log\xi}\log w_\xi(v)=-k_\xi(v),\quad
 k_\xi(v)-k_\xi(u)
 =-\partial_{\log\xi}\log\frac{w_\xi(v)}{w_\xi(u)}.
 \tag{23}
\]

权重连续、分段光滑，断点不产生w本身的额外原子。若在比值分子分母加入任何共同p_y(x)或共同kernel score，p都会抵消。例如

\[
 \partial_{\log\xi}\log\frac{p_y(x)w_\xi(u)}{p_y(x)w_\xi(v)}
 =k_\xi(v)-k_\xi(u).
 \tag{24}
\]

这是真实δ与核的最直接差分接口，但它说明：δ是**阈值方向、两个来源权重之差**，而不是p_y的soft或scale导数。固定ξ对p_y作soft/scale微分，两个来源槽中的共同p score相消，不能产生非零的kv−ku。

如果形式上在一段固定Zξ支持中对Πξ微分，归一化只会产生 \(-(k_\xi-E_{\Pi_\xi}k_\xi)\Pi_\xi\)。原Zξ随时间变化的导数、资格门以及正部δ还要另付；当前合同只给固定ξ时Π不依x，未给这些时间导数预算。因此本稿不把固定支持公式扩成原带动支持的积分分部。

即使无门的两份相同Π，也只有

\[
 \iint(k(v)-k(u))_+d\Pi(v)d\Pi(u)
 =\tfrac12\iint|k(v)-k(u)|d\Pi^2
 \le\sqrt{\operatorname{Var}_\Pi(k)/2}.
 \tag{25}
\]

Π的来源坐标一般相关，VarΠ(k)未必O(n)。具体代数压力：取ξ∈(1/2,1)，v0=y使每个Ci=1，另取v1使每个Ci<ξ；令ν两原子权重为wξ(v1)与1、Z含两点，则Π两点各1/2，k分别0,n，故(25)左端=n/4。此构造仅核验Π权重代数不支持免费根阶，不声称实现原完整FIRST、高门、good/bad或same-alpha。

完整Π固定时间后能移出dx，仍不使其k分布变为独立坐标，也不把(23)变成(6)或(17)。原χJ、rho及good/bad更会破坏(25)无门的交换对称，不能先做对称抵消再把门乘回。

## 7. 实际费用与本轮停止判据

已证明并可单独使用：

- 固定L的soft score：L2²=nI_s、L1≤√(nCsoft/s)；固定L的全soft变化及原核选择器包络为(8)–(9)。
- 固定s的真实尺度导数：精确(11)–(13)、TV下界2n(1−s)、中心化bulk根阶及(18)–(20)完整尺度变化费用。
- 有限L2尺度score对任何s<1被硬面Hellinger线性下界(16)排除；soft/scale组合也不能消去奇异面(15)。
- 原δ的准确阈值恒等式(23)，以及共同核score在两槽之差中消失的(24)。

没有取得原raw新付款。若先用一次hard帽16/3，再上放Π与原门，原δ仍只有n帽；把(7)或(17)的根阶数值直接替换n是不合法的。若改为用(20)包络自适应p，还额外带一般s的线性选择器费用；原时间log2、列数n+2、外2Λ及来源Wβ不能省略。q是共同FIRST水平，Π固定ξ不依x，这些已恢复合同不是本稿的阻碍来源；缺的是δ与核score的真实联合支配或(22)的带原门trace付款。

成功/失败判断明确：一般尺度score根阶候选已由(14)解析否定；soft和中心化bulk根阶候选成立但不能自动迁移。原future增益不足域没有已证机制同时支付trace、粗糙门变化、适应参数以及δ差，因此仍保留完整中间余项，不把这些缺口改名为新预算。

本轮三阶段为：初步(4)–(9)的解析矩筛查；压力(10)–(16)的真实硬面与均方反证；扩大(17)–(25)的全octave变化、弱式及原δ接口。无需有限数值替代这些精确恒等式。交付至此停止。
