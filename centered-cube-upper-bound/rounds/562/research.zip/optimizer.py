"""R562 one fixed full finite-parent cube recovery-probability QP.
All 64 source atoms, all observed bands/states, complete self Gram retained.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['OMP_NUM_THREADS']='2';os.environ['MKL_NUM_THREADS']='2'
import math,json,time,hashlib,platform,resource,argparse
from pathlib import Path
import numpy as np
import scipy
from scipy import sparse
from scipy.special import gammaln


def array_hash(a):
    a=np.asarray(a,dtype='<f8');return hashlib.sha256(json.dumps(list(a.shape),separators=(',',':')).encode()+a.tobytes()).hexdigest()

def ball_radius(n):return math.exp(float(gammaln(n/2+1))/n)/math.sqrt(math.pi)

def atoms_cloud(n):
    rng=np.random.default_rng(56100+n);return rng.uniform(-.5,.5,size=(64,1))+.02*rng.uniform(-.5,.5,size=(64,n))

def entries(B,atoms,shape):
    d=B[...,None,:]-atoms
    return 2*np.max(abs(d),axis=-1) if shape=='cube' else np.linalg.norm(d,axis=-1)/ball_radius(atoms.shape[1])

def sample_global(atoms,M,seed):
    rng=np.random.default_rng(seed);n=atoms.shape[1]
    src=rng.integers(0,len(atoms),size=M);sh=rng.integers(0,2,size=M);mode=rng.integers(0,2,size=M)
    R=np.where(mode==0,1.,np.exp(rng.uniform(math.log(.5),0.,size=M)))
    cube=rng.uniform(-.5,.5,size=(M,n))*R[:,None]
    norm=rng.standard_normal((M,n));norm/=np.linalg.norm(norm,axis=1)[:,None]
    ball=norm*(rng.uniform(size=M)**(1/n)*ball_radius(n)*R)[:,None]
    B=atoms[src]+np.where(sh[:,None]==0,cube,ball)
    def pk(e):return .5*np.mean(e<=1,axis=-1)+np.mean(np.maximum(np.maximum(.5,e)**(-n)-1,0),axis=-1)/(2*n*math.log(2))
    p=.5*(pk(entries(B,atoms,'cube'))+pk(entries(B,atoms,'ball')))
    return B,p

def read_inputs(path):
    data=json.load(open(path));row=next(r for r in data['expanded_once']['records'] if r['n']==16 and r['cloud']=='diagonal')
    atoms=np.asarray(row['atoms']) if 'atoms' in row else atoms_cloud(16)
    if 'atoms_rebuild' in row:assert array_hash(atoms)==row['atoms_rebuild']['sha256']
    samples=[]
    for i,role in enumerate(['training','evaluation1','evaluation2']):
        inp=next(x for x in row['frozen_center_inputs'] if x['role']==role)
        M=[2048,1024,1024][i];seed=[56141,56151,56161][i]+16
        if 'points' in inp:B=np.asarray(inp['points']);p=np.asarray(inp['proposal_density'])
        else:
            B,p=sample_global(atoms,M,seed)
            assert array_hash(B)==inp['points_rebuild']['sha256']
            assert array_hash(p)==inp['proposal_density_rebuild']['sha256']
        assert len(B)==M;samples.append((B,p))
    hashes=dict(atoms=array_hash(atoms),samples=[dict(role=role,points=array_hash(B),proposal_density=array_hash(p)) for role,(B,p) in zip(['training','evaluation1','evaluation2'],samples)])
    return atoms,samples,row,hashes

def parents(B,p,atoms,weightscale=1.):
    ent=entries(B,atoms,'cube');grid=.5+.5*np.arange(33)/32;vol=grid**16;out=[]
    for i,e in enumerate(ent):
        counts=np.sum(e[:,None]<=grid[None,:],axis=0);den=counts/64/vol;k=int(np.argmax(den));q0=float(den[k])
        if not q0:continue
        out.append(dict(idx=i,band=math.frexp(q0)[1]-1,R=float(grid[k]),count=int(counts[k]),q0=q0,weight=weightscale/(len(B)*p[i]),entries=e,mask=e<=grid[k],B=B[i]))
    return out

def old_fields(parents):
    out={}
    for r in parents:
        left=math.log2(r['count']/64);amp=r['weight']/r['R']**16
        for z in np.flatnonzero(r['mask']):out.setdefault((r['band'],int(z)),[]).append((left,left+1,amp))
    return out

def primitives(field):
    out={}
    for key,rr in field.items():
        events=sorted([(l,c) for l,u,c in rr]+[(u,-c) for l,u,c in rr]);v=area=0.;last=events[0][0];xs=[];aa=[];vv=[]
        for x,d in events:
            area+=v*(x-last);v+=d;last=x;xs.append(x);aa.append(area);vv.append(v)
        out[key]=(np.asarray(xs),np.asarray(aa),np.asarray(vv))
    return out

def window(prims,key,l):
    if key not in prims:return 0.
    xs,aa,vv=prims[key]
    def f(x):
        k=int(np.searchsorted(xs,x,side='right'))-1
        return 0. if k<0 else float(aa[k]+vv[k]*(x-xs[k]))
    return f(l+1)-f(l)

def phase(c,c0):
    A=int(c)**8;B=int(c0)**8;j=A.bit_length()-B.bit_length()
    return j-1 if A<(B<<j) else j

def plateaux(r):
    gs=(r['entries']/r['R'])**16;pts=np.unique(np.r_[1.,gs[(gs>1)&(gs<2)],2.]);out=[]
    for l,u in zip(pts[:-1],pts[1:]):out.append((float(l),float(u),gs<=math.sqrt(l*u)))
    return out,r['entries']<=r['R']*2**(1/16)

def classify(rr,prims):
    groups={k:[] for k in ['low','rapid','top','bulk']};C=1+math.log(4);An=1+16*math.log(2)
    for r in rr:
        s=math.log2(r['count']/64)
        alpha=sum(window(prims,(r['band'],int(z)),s) for z in np.flatnonzero(r['mask']))/(C*r['count'])
        seg,end=plateaux(r);kG=int(sum(end))/r['count'];K=max(2**.125,An*alpha)
        label='low' if alpha<=1/An else 'rapid' if kG>=K else 'top' if r['R']>=2**(-1/16) else 'bulk'
        r.update(alpha=alpha,segments=seg,endmask=end,kG=kG,K=K,label=label);groups[label].append(r)
    return groups

class Features:
    def __init__(self):
        self.edge_counts=sorted(set(range(1,65))|{2*c for c in range(1,65)})
        self.edge_index={c:i for i,c in enumerate(self.edge_counts)}
        self.lengths=np.log2(np.array(self.edge_counts[1:])/np.array(self.edge_counts[:-1]))
        self.keys=[];self.index={};self.rows=[];self.cols=[];self.vals=[]
    def components(self,r,mask,c):
        amp=r['weight']/r['R']**16;j=phase(c,r['count'])
        for z in np.flatnonzero(mask):
            for seg in range(self.edge_index[c],self.edge_index[2*c]):
                yield (int(z),r['band'],j,seg),amp*math.sqrt(self.lengths[seg]/64)
    def add(self,col,r,mask,c):
        for key,v in self.components(r,mask,c):
            if key not in self.index:self.index[key]=len(self.keys);self.keys.append(key)
            self.rows.append(self.index[key]);self.cols.append(col);self.vals.append(v)
    def matrix(self,ncols):return sparse.csc_matrix((self.vals,(self.rows,self.cols)),shape=(len(self.keys),ncols))
    def collapse(self,mode):
        idx={};rows=[]
        for key in self.keys:
            z,k,j,s=key
            new=(z,j,s) if mode=='bands' else (z,k,s) if mode=='phases' else (z,s)
            if new not in idx:idx[new]=len(idx)
            rows.append(idx[new])
        return sparse.csr_matrix((np.ones(len(rows)),(rows,np.arange(len(rows)))),shape=(len(idx),len(rows)))

def field_energy(field):
    E=0.
    for rr in field.values():
        ev=sorted([(l,c) for l,u,c in rr]+[(u,-c) for l,u,c in rr]);v=0.;last=ev[0][0]
        for x,d in ev:E+=v*v*(x-last)/64;v+=d;last=x
    return E

def build_problem(path):
    st=time.perf_counter();atoms,samples,reference,hashes=read_inputs(path)
    tr=parents(*samples[0],atoms);trainfield=old_fields(tr);prims=primitives(trainfield)
    groups=[];allparents=[];bulk=[]
    for batch,sample in enumerate(samples[1:]):
        rr=parents(*sample,atoms,.5)
        for r in rr:r['batch']=batch
        group=classify(rr,prims);groups.append(group);allparents.extend(rr);bulk.extend(group['bulk'])
    assert [len(g['bulk']) for g in groups]==[179,153]
    feat=Features();states=[];offsets=[0];baseline={k:[] for k in ['adaptive','common','two','delta1','deltaG']};parentmeta=[]
    for parentid,r in enumerate(bulk):
        c0=r['count'];cg=int(sum(r['endmask']));kG=cg/c0
        N=1+sum((u-l)*c0/sum(mask) for l,u,mask in r['segments'])+2/kG
        I=1+sum(math.log(u/l)*c0/sum(mask) for l,u,mask in r['segments'])+1/kG
        items=[('initial',1.,1.,1.,r['mask'])]+[('plateau',math.sqrt(l*u),l,u,mask) for l,u,mask in r['segments']]+[('terminal',2.,2.,2.,r['endmask'])]
        local={k:[] for k in baseline}
        for kind,g,l,u,mask in items:
            c=int(sum(mask));kap=c/c0;col=len(states);feat.add(col,r,mask,c)
            states.append(dict(parent=parentid,kind=kind,g=g,g_lower=l,g_upper=u,count=c,phase=phase(c,c0),receiver_atoms=np.flatnonzero(mask).tolist()))
            if kind=='initial':p=dict(adaptive=1/I,common=0.,two=.5,delta1=1.,deltaG=0.)
            elif kind=='terminal':p=dict(adaptive=1/(kap*I),common=.5,two=.25,delta1=0.,deltaG=1.)
            else:p=dict(adaptive=math.log(u/l)/(kap*I),common=1/l-1/u,two=.5*(1/l-1/u),delta1=0.,deltaG=0.)
            for law,value in p.items():local[law].append(value)
        for law,prob in local.items():assert abs(sum(prob)-1)<1e-12;baseline[law].extend(prob)
        offsets.append(len(states))
        parentmeta.append(dict(batch=r['batch'],center_index=r['idx'],B=r['B'].tolist(),band=r['band'],R=r['R'],old_count=c0,q0=r['q0'],alpha=r['alpha'],weight=r['weight'],kG=kG,N=N,I=I,baseline_Z=dict(adaptive=N/I,common=1+math.log(2),two=(2+math.log(2))/2,delta1=1.,deltaG=2.)))
    F=feat.matrix(len(states));S=sparse.csr_matrix((np.ones(len(states)),(np.repeat(np.arange(len(bulk)),np.diff(offsets)),np.arange(len(states)))),shape=(len(bulk),len(states)))
    A_band=feat.collapse('bands');A_phase=feat.collapse('phases');A_both=feat.collapse('both')
    arrays=dict(F=F,S=S,feature=feat,collapse_band=A_band,collapse_phase=A_phase,collapse_both=A_both,baselines={k:np.array(v) for k,v in baseline.items()},offsets=np.array(offsets),states=states,parents=parentmeta)
    ledger=[{label:dict(count=len(items),center_volume=sum(r['weight'] for r in items),q0_mass=sum(r['weight']*r['q0'] for r in items),old_training_price=sum((1+math.log(4))*r['weight']*r['q0']*r['alpha'] for r in items),byband={str(k):sum(r['band']==k for r in items) for k in sorted({r['band'] for r in items})}) for label,items in group.items()} for group in groups]
    summary=dict(frozen_branch_ledger=ledger,training_old_field_max=max(float(max(x[2])) for x in prims.values()),frozen_original_alpha_range=[min(r['alpha'] for r in allparents),max(r['alpha'] for r in allparents)],n=16,cloud='diagonal',body='cube',G=2,T=2048,evaluation_M_per_batch=1024,joint_weights='each original1/(1024 p_global) multiplied by1/2',source_count=64,source_mass=1.,a=.5,b=1.,C=1+math.log(4),An=1+16*math.log(2),input_hashes=hashes,parent_count=len(bulk),states=len(states),feature_rows=F.shape[0],feature_nnz=F.nnz,feature_storage_bytes=F.data.nbytes+F.indices.nbytes+F.indptr.nbytes,simplex_nnz=S.nnz,branch_counts=[{k:len(v) for k,v in g.items()} for g in groups],all_observed_bulk_bands=sorted({r['band'] for r in bulk}),frozen_parent_records=parentmeta,action_states=states,offsets=offsets,training_old_Q=field_energy(trainfield),joint_evaluation_old_Q_all=field_energy(old_fields(allparents)),joint_evaluation_old_Q_bulk=field_energy(old_fields(bulk)),training_price_of_joint_bulk=sum((1+math.log(4))*r['weight']*r['q0']*r['alpha'] for r in bulk),build_seconds=time.perf_counter()-st,maxrss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    return arrays,summary

def evaluate(prob,arrays,baseline_Z=None):
    F=arrays['F'];v=np.asarray(F@prob).ravel();E=float(v@v)
    bands=arrays['collapse_band']@v;phases=arrays['collapse_phase']@v;both=arrays['collapse_both']@v
    byphase={};bysource={}
    for x,key in zip(v,arrays['feature'].keys):
        byphase[str(key[2])]=byphase.get(str(key[2]),0.)+float(x*x)
        bysource[str(key[0])]=bysource.get(str(key[0]),0.)+float(x*x)
    moments=[];eta=[];pi_residual=0.
    rawprob=prob.copy()
    phaseweights={};kindweights={};totalparentweight=sum(r['weight'] for r in arrays['parents'])
    for b,parent in enumerate(arrays['parents']):
        l,u=arrays['offsets'][b:b+2];local=prob[l:u];ss=arrays['states'][l:u];g=np.array([s['g'] for s in ss])
        Z=float(local@g) if baseline_Z is None else baseline_Z[b]
        et=1/Z;eta.append(et);rawprob[l:u]*=et
        pi=local*g/Z if baseline_Z is None else None
        if pi is not None:pi_residual=max(pi_residual,abs(sum(pi)-1),abs(sum(pi/g)-et))
        moments.append(dict(Z=Z,eta=et,Z_state_lower=float(local@np.array([s['g_lower'] for s in ss])),Z_state_upper=float(local@np.array([s['g_upper'] for s in ss]))))
        for s,p in zip(ss,local):
            phaseweights[str(s['phase'])]=phaseweights.get(str(s['phase']),0.)+parent['weight']*p/totalparentweight
            kindweights[s['kind']]=kindweights.get(s['kind'],0.)+parent['weight']*p/totalparentweight
    raw=F@rawprob
    return dict(C_eta_band_diagonal=E,C_eta_all_band_complete=float(bands@bands),cross_band_fee=float(bands@bands)-E,phase_erased_same_field_energy=float(phases@phases),phase_cross_fee=float(phases@phases)-E,band_and_phase_erased_energy=float(both@both),raw_pi_energy=float(raw@raw),phase_energies=byphase,source_energies=bysource,rho_parent_volume_weighted_phase=phaseweights,rho_parent_volume_weighted_kind=kindweights,eta_range=[min(eta),max(eta)],Z_range=[min(x['Z'] for x in moments),max(x['Z'] for x in moments)],parent_moments=moments,restoration_probability_residual=pi_residual,simplex_residual=float(max(abs(arrays['S']@prob-1))),minimum_probability=float(min(prob)))

def solve_problem(arrays,objective='band_diagonal'):
    import clarabel
    st=time.perf_counter();F=arrays['F'] if objective=='band_diagonal' else (arrays['collapse_band']@arrays['F']).tocsc();S=arrays['S'];nv=F.shape[1]
    gram=(F.T@F).tocsc();P=sparse.triu(2*gram,format='csc');A=sparse.vstack([S,-sparse.eye(nv,format='csc')],format='csc');b=np.r_[np.ones(S.shape[0]),np.zeros(nv)]
    settings=clarabel.DefaultSettings();settings.verbose=False;settings.max_iter=200;settings.tol_gap_abs=1e-9;settings.tol_gap_rel=1e-9;settings.tol_feas=1e-10
    if hasattr(settings,'max_threads'):settings.max_threads=2
    solver=clarabel.DefaultSolver(P,np.zeros(nv),A,b,[clarabel.ZeroConeT(S.shape[0]),clarabel.NonnegativeConeT(nv)],settings);sol=solver.solve()
    x=np.array(sol.x);original=x.copy()
    for l,u in zip(arrays['offsets'][:-1],arrays['offsets'][1:]):
        x[l:u]=np.maximum(x[l:u],0);x[l:u]/=sum(x[l:u])
    v=F@x;E=float(v@v);grad=2*np.asarray(F.T@v).ravel();mins=[float(min(grad[l:u])) for l,u in zip(arrays['offsets'][:-1],arrays['offsets'][1:])]
    gap=float(grad@x-sum(mins));LB=float(sum(mins)-E)
    z=np.array(sol.z);stationarity=2*np.asarray(gram@original).ravel()+np.asarray(S.T@z[:S.shape[0]]).ravel()-z[S.shape[0]:]
    return x,dict(objective=objective,status=str(sol.status),iterations=sol.iterations,solve_seconds=sol.solve_time,total_solver_seconds=time.perf_counter()-st,solver_primal_objective=sol.obj_val,solver_dual_objective=sol.obj_val_dual,solver_gap=sol.obj_val-sol.obj_val_dual,solver_primal_residual=sol.r_prim,solver_dual_residual=sol.r_dual,original_simplex_residual=float(max(abs(S@original-1))),original_min_probability=float(min(original)),probability_projection_linf=float(max(abs(x-original))),projected_objective=E,floating_simplex_linearization_lower_bound=LB,floating_simplex_primal_dual_gap=gap,stationarity_linf=float(max(abs(stationarity))),complementarity_linf=float(max(abs(original*z[S.shape[0]:]))),gram_nnz=gram.nnz,gram_bytes=gram.data.nbytes+gram.indices.nbytes+gram.indptr.nbytes,maxrss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,certificate_status='Floating optimization and linearization audit only, not interval/rational certification')

def main():
    script_path=Path(__file__).resolve();parser=argparse.ArgumentParser();parser.add_argument('--input',default=str(script_path.with_name(script_path.stem+'_input.json')));parser.add_argument('--output',default=str(script_path.with_suffix('.json')));parser.add_argument('--verify-build',action='store_true',help='Rebuild only and compare all input hashes/feature arrays to existing output; do not overwrite output or solve');parser.add_argument('--solve',action='store_true',help='Solve the authorized band-diagonal objective');parser.add_argument('--solve-all-band',action='store_true',help='Solve complete band-collapsed self energy, preserving old band result if present');args=parser.parse_args()
    arrays,summary=build_problem(args.input)
    if args.verify_build:
        reference=json.load(open(args.output));new=(arrays['collapse_band']@arrays['F']).tocsc();payload=reference['all_band_feature_matrix_csc'];old=sparse.csc_matrix((payload['data'],payload['indices'],payload['indptr']),shape=payload['shape'])
        checks=dict(input_hashes_equal=summary['input_hashes']==reference['summary']['input_hashes'],shape_equal=new.shape==old.shape,data_bitwise_equal=np.array_equal(new.data,old.data),indices_equal=np.array_equal(new.indices,old.indices),indptr_equal=np.array_equal(new.indptr,old.indptr),action_states_equal=summary['action_states']==reference['summary']['action_states'],parent_count_equal=summary['parent_count']==reference['summary']['parent_count'])
        assert all(checks.values());print(json.dumps(dict(checks=checks,build_seconds=summary['build_seconds'],maxrss_bytes=summary['maxrss_bytes'],scope='No solve and no overwrite'),indent=2));return
    baselines={}
    for law,prob in arrays['baselines'].items():baselines[law]=evaluate(prob,arrays,[p['baseline_Z'][law] for p in arrays['parents']])
    assert abs(baselines['delta1']['C_eta_band_diagonal']-summary['joint_evaluation_old_Q_bulk'])<1e-10
    result=dict(summary=summary,baselines=baselines,versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),code_sha256=hashlib.sha256(open(__file__,'rb').read()).hexdigest(),scope='One fixed full finite cube family; empirical alpha and quadrature parents, no Lebesgue/general-dimension theorem')
    if args.solve_all_band and not args.solve and os.path.exists(args.output):
        old=json.load(open(args.output));assert old['summary']['input_hashes']==summary['input_hashes']
        for key in ['optimizer_audit','optimum','rho_optimum','band_diagonal_optimizer_audit','band_diagonal_optimum','rho_band_diagonal_optimum']:
            if key in old:result[key]=old[key]
    print(json.dumps({k:summary[k] for k in ['parent_count','states','feature_rows','feature_nnz','feature_storage_bytes','build_seconds','maxrss_bytes']},indent=2),flush=True)
    if args.solve:
        prob,audit=solve_problem(arrays);result['optimizer_audit']=audit;result['optimum']=evaluate(prob,arrays);result['rho_optimum']=prob.tolist()
        result['band_diagonal_optimizer_audit']=audit;result['band_diagonal_optimum']=result['optimum'];result['rho_band_diagonal_optimum']=prob.tolist()
        print(json.dumps(audit,indent=2),flush=True)
    if 'optimizer_audit' in result:
        result['band_diagonal_optimizer_audit']=result['optimizer_audit'];result['band_diagonal_optimum']=result['optimum'];result['rho_band_diagonal_optimum']=result['rho_optimum']
    if args.solve_all_band:
        prob,audit=solve_problem(arrays,'all_band_complete');result['all_band_optimizer_audit']=audit;result['all_band_optimum']=evaluate(prob,arrays);result['rho_all_band_optimum']=prob.tolist()
        FF=(arrays['collapse_band']@arrays['F']).tocsc();result['all_band_feature_matrix_csc']=dict(shape=list(FF.shape),data=FF.data.tolist(),indices=FF.indices.tolist(),indptr=FF.indptr.tolist());result['offsets']=arrays['offsets'].tolist()
        keys={}
        for z,k,j,segment in arrays['feature'].keys:
            new=(z,j,segment)
            if new not in keys:keys[new]=len(keys)
        result['all_band_feature_row_keys']=[list(k) for k in keys];result['sigma_edge_integer_counts']=arrays['feature'].edge_counts
        print(json.dumps(audit,indent=2),flush=True)
    result['objective_fields']=dict(band_diagonal='band_diagonal_optimizer_audit / band_diagonal_optimum / rho_band_diagonal_optimum',all_band_complete='all_band_optimizer_audit / all_band_optimum / rho_all_band_optimum')
    with open(args.output,'w') as f:json.dump(result,f,indent=2)
    print('Saved',args.output)

if __name__=='__main__':main()
