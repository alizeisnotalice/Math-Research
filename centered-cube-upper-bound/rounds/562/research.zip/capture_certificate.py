"""N2: independent exact capture of product vertices vs balanced Hamming slice.
Exhaustively validates every effective 3^n box state for n=4,6,8.
"""
from fractions import Fraction as F
from itertools import product
from math import comb,factorial
from collections import defaultdict
import sys,platform,json,time,hashlib,argparse
from pathlib import Path
NS=[4,6,8]
def formula(n,f,s):
    need=n//2-s
    return F(1,2**(n-f)),F(comb(f,need),comb(n,n//2)) if 0<=need<=f else F(0)
def audit_serialized_n1(path):
    audit_start=time.perf_counter()
    raw=json.load(open(path))
    if 'all_band_feature_matrix_csc' not in raw:return dict(status='pending_serialized_all_band_matrix')
    matrix=raw['all_band_feature_matrix_csc'];nr,nc=matrix['shape']
    data=[F(float(v)) for v in matrix['data']];indices=matrix['indices'];indptr=matrix['indptr']
    x=[F(float(v)) for v in raw['rho_all_band_optimum']]
    offsets=raw.get('offsets',raw['summary']['offsets'])
    assert len(x)==nc and len(data)==len(indices)==indptr[-1]
    assert offsets[0]==0 and offsets[-1]==nc and min(x)>=0
    max_residual=F(0);max_repair=F(0)
    for l,u in zip(offsets[:-1],offsets[1:]):
        delta=1-sum(x[l:u]);max_residual=max(max_residual,abs(delta))
        j=max(range(l,u),key=lambda j:x[j]);x[j]+=delta
        max_repair=max(max_repair,abs(delta))
        assert min(x[l:u])>=0 and sum(x[l:u])==1
    v=[F(0)]*nr
    for j in range(nc):
        for h in range(indptr[j],indptr[j+1]):v[indices[h]]+=data[h]*x[j]
    energy=sum((w*w for w in v),F(0));grad=[]
    for j in range(nc):grad.append(2*sum((data[h]*v[indices[h]] for h in range(indptr[j],indptr[j+1])),F(0)))
    assert sum((g*p for g,p in zip(grad,x)),F(0))==2*energy
    ymin=[min(grad[l:u]) for l,u in zip(offsets[:-1],offsets[1:])]
    lower=sum(ymin,F(0))-energy;gap=energy-lower
    complement=F(0)
    for b,(l,u) in enumerate(zip(offsets[:-1],offsets[1:])):
        assert all(grad[j]>=ymin[b] for j in range(l,u))
        complement+=sum((x[j]*(grad[j]-ymin[b]) for j in range(l,u)),F(0))
    assert complement==gap and gap>=0
    return dict(status='exact_rational_certificate_for_serialized_double_feature_matrix_only',matrix_shape=[nr,nc],nnz=len(data),simplex_blocks=len(offsets)-1,audit_seconds=time.perf_counter()-audit_start,optimizer_file_sha256=hashlib.sha256(open(path,'rb').read()).hexdigest(),rho_json_sha256=hashlib.sha256(json.dumps(raw['rho_all_band_optimum'],separators=(',',':')).encode()).hexdigest(),matrix_json_sha256=hashlib.sha256(json.dumps(matrix,sort_keys=True,separators=(',',':')).encode()).hexdigest(),original_probability_sum_residual_exact=str(max_residual),exact_simplex_repair_linf=str(max_repair),repaired_probabilities_nonnegative=True,repaired_simplex_residual_exact='0',primal_upper_exact=str(energy),dual_lower_exact=str(lower),primal_dual_gap_exact=str(gap),display_only=dict(primal_upper=float(energy),dual_lower=float(lower),gap=float(gap),relative_gap=float(gap/energy)),author_all_band_audit=raw.get('all_band_optimizer_audit'),scope='F entries are the serialized rounded doubles interpreted exactly as rationals. No interval error bound for ideal geometry/F, proposal density, original alpha, continuum quadrature or complete L1 objective.')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--optimizer',type=Path,default=Path(__file__).resolve().parent/'optimizer.json',help='Serialized optimizer JSON; default optimizer.json beside this script')
    args=parser.parse_args()
    start=time.perf_counter();dimensions=[];checks=0
    digest=hashlib.sha256()
    for n in NS:
        vertices=list(range(2**n));slice_vertices=[v for v in vertices if v.bit_count()==n//2]
        # Exact one-coordinate marginals, directly from supports.
        assert all(sum((v>>j)&1 for v in vertices)*2==len(vertices) for j in range(n))
        assert all(sum((v>>j)&1 for v in slice_vertices)*2==len(slice_vertices) for j in range(n))
        groups={};none_checks=0
        # 0=force0,1=force1,2=both. Tests actual support membership.
        for state in product(range(3),repeat=n):
            ones=sum(1<<j for j,x in enumerate(state) if x==1)
            zeros=sum(1<<j for j,x in enumerate(state) if x==0)
            f=state.count(2);s=state.count(1);z=n-f-s
            prodcount=sum((v&ones)==ones and (v&zeros)==0 for v in vertices)
            slicecount=sum((v&ones)==ones and (v&zeros)==0 for v in slice_vertices)
            direct=(F(prodcount,len(vertices)),F(slicecount,len(slice_vertices)))
            expected=formula(n,f,s);assert direct==expected
            # Coordinate captures, tested in the actual sources, not inferred.
            for j,x in enumerate(state):
                allowed=lambda v: x==2 or ((v>>j)&1)==x
                p=F(sum(allowed(v) for v in vertices),len(vertices))
                q=F(sum(allowed(v) for v in slice_vertices),len(slice_vertices))
                assert p==q==(1 if x==2 else F(1,2))
            key=(f,s)
            if key not in groups:groups[key]=dict(free=f,forced_one=s,forced_zero=z,states_checked=0,product_capture=str(direct[0]),slice_capture=str(direct[1]),slice_over_product=str(direct[1]/direct[0]))
            groups[key]['states_checked']+=1;checks+=1
            digest.update(bytes(state));digest.update(str((prodcount,slicecount)).encode())
        for (f,s),g in groups.items():
            z=n-f-s;assert g['states_checked']==factorial(n)//(factorial(f)*factorial(s)*factorial(z))
        # One-coordinate none, all other coordinates both: no source point passes.
        for j in range(n):
            assert sum(2<=((v>>j)&1)<=3 for v in vertices)==0
            assert sum(2<=((v>>j)&1)<=3 for v in slice_vertices)==0
            none_checks+=1
        dimensions.append(dict(n=n,product_support_size=len(vertices),slice_support_size=len(slice_vertices),all_states_checked=3**n,none_coordinate_checks=none_checks,same_coordinate_marginals_exact='1/2',groups=[v for _,v in sorted(groups.items())]))
    examples=[]
    for n,f,s,label in [(4,2,2,'two forced ones'),(4,2,1,'one forced one and one forced zero'),(4,0,2,'balanced complete vertex'),(4,0,4,'unbalanced complete vertex')]:
        p,q=formula(n,f,s);examples.append(dict(n=n,free=f,forced_one=s,label=label,product=str(p),slice=str(q),ratio=str(q/p)))
    scaling=[]
    for n in [4,6,8,16,32,64,128]:
        balanced=F(2**n,comb(n,n//2))
        rare=F(2**(n//2),comb(n,n//2))
        scaling.append(dict(n=n,balanced_single_vertex_ratio=str(balanced),balanced_ratio_display=float(balanced),all_half_forced_one_ratio=str(rare),all_half_forced_one_display=float(rare)))
    out=dict(python=sys.executable,python_version=platform.python_version(),script_sha256=hashlib.sha256(open(__file__,'rb').read()).hexdigest(),input=dict(n=NS,coordinate_states=['force0','force1','both'],source_product='uniform {0,1}^n',source_slice='uniform Hamming weight n/2'),total_states_checked=checks,state_count_sha256=digest.hexdigest(),dimensions=dimensions,examples=examples,analytic_scaling_displays=scaling,elapsed_seconds=time.perf_counter()-start,scope='Exact finite capture and marginal identities; no general root bound and no complete Gram budget.')
    out['N1_all_band_finite_qp_audit']=audit_serialized_n1(args.optimizer)
    out['total_elapsed_seconds']=time.perf_counter()-start
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
