# R562｜两个原始定理与当前加权联合预算的适用性

**决策结论：本次未找到可实际支付 \(C_\star\) 的既有机制。** Bourgain 的 cube乘积结构已经允许输入函数任意相关；真正缺失的是把 Lebesgue 估计移到实际 \(L^2(\mu\times d\sigma)\)、保留 source/center相关性和全部 action窗后的预算。两权测试定理允许任意权，但其 testing 常数恰须新增证明，不能重命名成已付费用。

已读冻结合同、R561报告§1–3的精确对象和当前 `joint_potential.tex` 的母式。应用 F07 技能：同一标量算子的 MZ 随机化既不改变底测度，也不自动处理不同动作算子。下面只列两个已打开原文并核到条件页的定理；未下载论文、未改仓库。

## 1. Bourgain：cube 的无权维数无关强型

Jean Bourgain, *On the Hardy–Littlewood maximal function for the cube*，原始 [arXiv:1212.2661v1](https://arxiv.org/pdf/1212.2661v1)。准确位置：PDF p.3 的未编号主 Theorem；(1.8)–(1.9)同页，Lemma1/(1.14)–(1.16)在p.4，Riesz双对偶/(1.21)–(1.25)在p.6。

条件／结论：连续 \(\mathbb R^n\)、Lebesgue 测度、中心 cube平均族；每个固定 \(1<p<\infty\)，
\[
 \|M_\square g\|_{L^p(dx)}\le C_p\|g\|_{L^p(dx)},
 \qquad C_p\text{ 不依赖 }n.
\]
主定理未给可直接使用的 \(p\downarrow1\) 数值增长率。关键结构是单位边长 cube 的 \(m(\xi)=\prod_j\sin(\pi\xi_j)/(\pi\xi_j)\)，加上 Lebesgue Fourier/Plancherel与乘子双对偶。**它没有要求 g 的坐标独立；不能把“任意相关输入已允许”误说成来源独立性假设。**

对本题的实际判定：当前 \(Z_\rho\) 的范数为 \(\int f(y)|Z_\rho(y,\sigma)|^2dy\,d\sigma\)，且 \(R_B,t_B,j_B(g)\) 和真实质量窗依赖全输入。Bourgain 定理既不控制这个输出权，也没有提供合法的同一 \(\rho_B\) 全receiver选择。不能用 \(g=f^{1/2}Z\) 修补：\(f^{1/2}\) 与平移平均不交换。若坚持该路线，必须另证实际 \(\mu\) 权下的共同动作平方界，并显式计入全部窗与旧层；这正是未付步骤，原文没有现成转移。

## 2. Lacey–Sawyer–Uriarte-Tuero：任意两权必须付双向 testing

Michael T. Lacey, Eric T. Sawyer, Ignacio Uriarte-Tuero, *Two Weight Inequalities for Discrete Positive Operators*，原始 [arXiv:0911.3437v4](https://arxiv.org/pdf/0911.3437v4)。准确位置：Theorem1.6、算子定义在PDF pp.2–3；Theorem1.11/(1.12)在p.4。**同页末明确不追踪 dimension、p、q 依赖；不可据此声称根阶或维数无关常数。**

设同一 dyadic格 \(\mathcal D\)，固定非负 \(\tau_Q\)，\(T_\tau h=\sum_{Q\in\mathcal D}\tau_Q|Q|^{-1}\int_Qh\,dx\,1_Q\)，\(\sigma,\omega\) 为非负局部可积权。p=q=2时定理给
\[
 \|T_\tau(\sigma\cdot)\|_{L^2(\sigma)\to L^2(\omega)}
 \asymp \mathfrak T_\sigma+\mathfrak T_\omega,
\quad
 \mathfrak T_\sigma^2=
 \sup_R\frac1{\sigma(R)}\int
 \left[\sum_{Q\subset R}\tau_Q\frac{\sigma(Q)}{|Q|}1_Q\right]^2d\omega,
\]
\(\mathfrak T_\omega\) 交换 \(\sigma,\omega\)。一般范围为 \(1<p\le q<\infty\) 的局部双向测试；此处没有 \(p=1\) 结论。

对本题的实际判定：这是相关权可用的**条件框架**，没有 source容量的数值上界。当前 action kernel 以连续父中心B、可变 \(R_B\)、质量窗和相位为索引，并不是上述同一 dyadic正算子。须先建立保留所有ordered cross项、原source cores和窗口的共同正算子表示／支配，追踪其维数损失；再证明两向testing常数的小系数加W预算。仅给单向捕获容量、逐action测试或每action各付W均不够。标准多格包络也不能不计指数维数费用。

## 对冻结母式的真实贡献与停止点

两条定理本次均没有带来新的 \(C_\star\) 系数或W付款。若走原固定自适应律，实际所需仍至少是
\[
 C_\star\le aQ_g+L(n)W,
 \qquad \frac{2aJ}{d^2}<1,
\]
再连同 \(C_\eta\le2K_wW+2C_\star\)、全部恢复费用收口。若改选新 \(\rho\)，则需直接证明 \(E_\chi\le\zeta Q_g+L(n)W\)、\(\zeta J/d^2<1\)，不能把它叫成原 \(C_\star\) 上界。

不能有一个无条件“把无权L²换成任意输入权L²”的通用转移。作边界说明而非冻结合同反例：一维 \(Th(x)=\tfrac12\int_{x-1}^{x+1}h\)，取 \(h=1_{[1,2]}\)、\(w_\varepsilon=1_{[0,1]}+\varepsilon1_{[1,2]}\)。则 \(\int |h|^2w_\varepsilon=\varepsilon\)，但 \(\int|Th|^2w_\varepsilon\ge\int_0^1(x/2)^2dx=1/12\)。因此任何同权范数转移都须含实际权／source兼容条件；此例不判断真实可行场的特殊结构。

轻量实跑仅核该积分：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`、SymPy1.14.0，`integrate((x/2)**2,(x,0,1))`实际返回`1/12`。严格理由是上面显示的区间交长计算；无优化或批量实验。

检索仅两个定向query：Bourgain准确题名；`Two weight inequalities for discrete positive operators theorem testing pdf Sawyer Uriarte Tuero`，随后打开上述原始arXiv版本的条件／常数页。未找到已付款的cube-specific加权端点，不增加旁支文献。
