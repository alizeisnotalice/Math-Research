"""Exact checks of half-line likelihood and matching, including ordered ties."""
import json,sys,socket,os,math
from multiprocessing import get_context
from fractions import Fraction as F
def check(word,k):
    ys=[(word>>i)&1 for i in range(k)]
    pre=[0]
    for y in ys:pre.append(pre[-1]+y)
    # Pool adjacent violators for increasing Bernoulli probabilities.
    blocks=[]
    for y in ys:
        blocks.append((y,1))
        while len(blocks)>1:
            a,n=blocks[-2];b,m=blocks[-1]
            if a*m<=b*n:break
            blocks[-2:]=[(a+b,n+m)]
    rates=[F(a,n) for a,n in blocks for _ in range(n)]
    # Independent exact min-max representation for isotonic fitted values.
    for i in range(k):
        p=max(min(F(pre[e+1]-pre[s],e+1-s) for e in range(i,k)) for s in range(i+1))
        assert p==rates[i]
    prod=F(1)
    for y,p in zip(ys,rates):prod*=p if y else 1-p
    deletions=min(pre[t]+(k-t)-(pre[k]-pre[t]) for t in range(k+1))
    unmatched=matched=0
    for y in ys:
        if y:unmatched+=1
        elif unmatched:unmatched-=1;matched+=1
    assert matched==deletions
    assert prod<=F(1,4)**matched
    assert prod>=F(k-matched,k)**(k-matched)*F(matched,2*k)**matched
    return matched
def run(input):
    k,first,stop,parity=input
    total=0; mx=0
    for word in range(first,stop):
        if word%2==parity:
            mx=max(mx,check(word,k));total+=1
    return total,mx,os.getpid()
if __name__=='__main__':
    parity,w,top=map(int,sys.argv[1:])
    jobs=[(k,s,min(s+32,1<<k),parity) for k in range(1,top+1) for s in range(0,1<<k,32)]
    with get_context('fork').Pool(w) as pool:out=pool.map(run,jobs,1)
    print(json.dumps(dict(host=socket.gethostname(),version=sys.version,workers=len(set(r[-1] for r in out)),words=sum(r[0] for r in out),maxmatching=max(r[1] for r in out),args=sys.argv[1:])))
