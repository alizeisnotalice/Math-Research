import json,sys,random
from fractions import Fraction as F
from flint import arb,ctx
import flint
ctx.prec=256
rng=random.Random(706);roundings=0;medians=0;shifts=0
for bits in (8,16,32,64,128,256,500):
    n=2**bits
    for delta in (F(1,5),F(1,11)):
        qd=arb(delta.numerator)/delta.denominator
        J=int((arb(bits).log()/qd.log1p()).ceil().unique_fmpz())
        b=(arb(bits).log()/J).exp()
        exps=[b**j for j in range(J+1)]
        for j in range(J):
            # Interior attainable probabilities; endpoints treated exactly in proof.
            for step in (1,2,3):
                E=exps[j]+(exps[j+1]-exps[j])*step/4
                q=(-E*arb(2).log()).exp(); p=(-exps[j+1]*arb(2).log()).exp()
                kl=q*(q/p).log()+(1-q)*((-q).log1p()-(-p).log1p())
                entropy=-q*q.log()-(1-q)*(-q).log1p()
                assert kl<qd*entropy
                roundings+=1
for n in (2,3,8,17,32):
    for _ in range(120):
        target=sorted(F(rng.randint(-20,20),20) for k in range(n))
        t0=target[n//2]
        atoms=[F(rng.randint(-20,20),20) for g in range(3)]
        weights=[F(1,8),F(3,8),F(1,2)]
        moment=sum(p*abs(v-y) for p,v in zip(weights,atoms) for y in target)
        assert all(n*p*abs(v-t0)<=2*moment for p,v in zip(weights,atoms))
        medians+=1
        c=[rng.randrange(3) for k in range(n)]
        for g in set(c):
            count=c.count(g);rad=F(1,count);length=F(4,3)
            y=F(rng.randint(-20,20),20)*length
            overlap=min(length+rad,y+rad)-max(-length-rad,y-rad)
            assert overlap/(2*(length+rad))>=1/(1+length*count)
            shifts+=1
print(json.dumps(dict(python=sys.version,flint=flint.__version__,precision=ctx.prec,kl=roundings,medians=medians,sweeps=shifts)))
