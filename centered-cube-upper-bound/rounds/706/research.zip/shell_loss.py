"""Weighted-shell approximation after sign restriction. See notes for total variation."""
import math,random,sys,socket,json,os
from multiprocessing import get_context
def trial(job):
    b,alpha,j=job;n=1<<b;a=32*n;t=math.sqrt(n);L=math.log(n)
    ell=int(.4*b);step=math.log1p(-2/a);W=-math.expm1(n*step)
    Wthin=math.ldexp(W,-ell)
    layers=math.ceil(t*math.log(2)/Wthin)
    rng=random.Random(731502+b*100000+1000*round(alpha*100)+j)
    v=-t*math.log1p(rng.random()*math.expm1(-(layers-1)*Wthin/t))
    l=int(v/Wthin);s=n/(alpha*L)*math.exp(l*step)
    first=min(n-1,int(math.log1p(-W*rng.random())/step)); edge=(a-1)*rng.randrange(2)
    obs=[[],[]]
    for k in range(n):
        digit=(rng.randrange(1,a-1) if k<first else edge if k==first else rng.randrange(a))
        if k<ell:digit=max(digit,a-1-digit)
        y=s*((2*digit+1)/a-1);half=(1+6/n)*s
        for z,x in enumerate((rng.uniform(-1,1),(1-2/a)*(1 if k%2 else -1))):
            lo,hi=y-half-x,y+half-x
            if hi<1:obs[z].append((hi,1))
            if lo>-1:obs[z].append((lo,0))
    res=[]
    for marks in obs:
        blocks=[]
        for _,bit in sorted(marks):
            blocks.append((bit,1))
            while len(blocks)>1:
                p,m=blocks[-2];q,k=blocks[-1]
                if p*k<=q*m:break
                blocks[-2:]=[(p+q,k+m)]
        loss=-sum(j*math.log(j/m) for p,m in blocks for j in (p,m-p) if j)
        res.append([len(marks),loss/L])
    return [b,alpha,j,res,os.getpid()]
if __name__=='__main__':
    parity,w=map(int,sys.argv[1:])
    jobs=[(b,v,j) for b in (10,14,18) for v in (.65,.85,.95) for j in range(parity,32,2)]
    with get_context('fork').Pool(w) as pool: rows=pool.map(trial,jobs,1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,workers=len(set(r[-1] for r in rows)),rows=[r[:-1] for r in rows])))
