# 第706轮双机检验

Mac mini 使用 /Users/zzh/.local/share/math-research-tools/venv/bin/python。MacBook 以 SSH 经 en5 使用 python3，将同一脚本从标准输入送入。版本和实际工作进程数见对应 JSON。

order.py 0 2 6 为试跑。两机分别运行 order.py 0 12 13 和 order.py 1 15 13，按奇偶分工。合计穷举长度1至13的16382个二元端点序列。用有理算术比较合并相邻块与独立极小极大公式，复核匹配、删除和损失上下界。checks.py 的 cert.json 记录 256 位 Arb 的1500个舍入检验、600个精确中位数检验及1513个精确扫掠概率检验。

shell_loss.py 0 12 和 shell_loss.py 1 15 分别生成 shell-mini.json 和 shell-remote.json。维数为 2 的 10、14、18 次幂。shell_extended.py 用相同参数分别生成 extended-mini.json 和 extended-remote.json，扩大至 2 的20次幂。两机按种子奇偶分开，每个维数、每个参数 α=0.65、0.85、0.95 各32个样本，四个维数合计384个。每次抽取同一个来源，再测均匀接收点和符号平衡的近角点；后者取最外接收格的内侧端点，并非均匀采样。抽层保留完整层的实际暴露权重，略去末层并均匀抽层内来源，与原权重的误差见 concentration.tex。使用浮点坐标，未对这些模拟作区间认证。

在 n=2^18，均匀接收点满足 B/log(n)≤0.45 的次数依参数依次为32、32、32；近角点为32、24、26。在 n=2^20 对应次数分别为32、32、32与32、25、29。所有分母均为32。有限维度差异不足以确定渐近指数。两种接收方式的理论范围见 concentration.tex。
