#!/usr/bin/env python3
"""Registered scalar time-kernel, merge weighting, and real disjoint-atom guard."""
from fractions import Fraction as F
from functools import lru_cache
import pathlib,json,hashlib,time
P=pathlib.Path(__file__).resolve().parent;PRE="profile_clock_kernel_guard_20261007"
T=100;S=1<<256
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,o):p.write_text(json.dumps(o,sort_keys=True,indent=2)+"\n")
def base(q):
    z=(q-1)/(q+1);term=z;s=F(0)
    for j in range(T):s+=2*term/(2*j+1);term*=z*z
    return s,s+2*term/(201*(1-z*z))
L2=base(F(2))
@lru_cache(None)
def logq(q):
    if q<=0:raise ValueError("log domain")
    if q==1:return F(0),F(0)
    m=q;k=0
    while m<1:m*=2;k-=1
    while m>=2:m/=2;k+=1
    l,h=base(m)
    if k>=0:l+=k*L2[0];h+=k*L2[1]
    else:l+=k*L2[1];h+=k*L2[0]
    l*=S;h*=S
    return F(l.numerator//l.denominator,S),F(-(-h.numerator//h.denominator),S)
def clean(cs):return {a:c for a,c in cs.items() if a!=1 and c}
def combine(*terms):
    out={}
    for cs,mult in terms:
        for a,c in cs.items():out[a]=out.get(a,F(0))+mult*c
    return clean(out)
def evaluate(cs,r=F(0)):
    l=h=r
    for q,c in cs.items():
        a,b=logq(q)
        if c<0:a,b=b,a
        l+=c*a;h+=c*b
    return l,h
def fmt(ab):return [str(x) for x in ab]
def coefficients(cs):return {str(q):str(c) for q,c in sorted(cs.items())}
def atomPsi(w):return combine(({w+2:w+2},F(1)),({w+1:-w},F(1)),({F(2):F(-2)},F(1)))
def g(v):
    l,h=logq(1+v);return l-v/(1+v),h-v/(1+v)
checks=0
def ck(x,label):
    global checks
    checks+=1
    if not x:raise AssertionError(label)
def main():
    start=time.monotonic();regp=P/(PRE+"_run_registration.json");reg=json.loads(regp.read_text())
    ck(sha(pathlib.Path(__file__))==reg["script_sha256"],"frozen code")
    time_rows=[];merge_rows=[];atom_rows=[];summaries=[]
    for rd in reg["rounds"]:
        before=checks;vs=list(map(F,rd["v"]));trows=[]
        for v in vs:
            # Exact symbolic -v*psi'(v)=ln(1+v)/v-1/(1+v)=r(v).
            d_coeff=F(1)/v;d_const=-F(1)/(1+v)
            ck(d_coeff==F(1)/v and d_const==(-v/(1+v))/v,"clock derivative log/constant coefficients")
            for cs in reg["c"]:
                c=F(cs);cv=c*v
                costcs=combine(({1+v:F(1)/v},F(1)),({1+cv:F(1)/cv},F(-1)))
                exact=evaluate(costcs)
                ck(exact[0]>0,"positive finite clock fee")
                steps=int(c).bit_length()-1
                ck(c==2**steps,"fixed geometric partition")
                nodes=[v*2**j for j in range(steps+1)]
                lo=hi=F(0);pieces=[]
                for a,b in zip(nodes,nodes[1:]):
                    ga=g(a);gb=g(b)
                    low=(b-a)*gb[0]/b**2;high=(b-a)*ga[1]/a**2
                    ck(low>0 and low<=high,"positive Darboux piece")
                    lo+=low;hi+=high
                    pieces.append({"left":str(a),"right":str(b),"kernel_left_interval":fmt((ga[0]/a**2,ga[1]/a**2)),
                                   "kernel_right_interval":fmt((gb[0]/b**2,gb[1]/b**2)),
                                   "integral_lower":str(low),"integral_upper":str(high)})
                ck(lo<exact[0] and exact[1]<hi,"exact potential difference inside independent Darboux bounds")
                row={"round":rd["name"],"v":str(v),"c":str(c),"cv":str(cv),
                     "psi_v_interval":fmt(evaluate({1+v:F(1)/v})),
                     "psi_cv_interval":fmt(evaluate({1+cv:F(1)/cv})),
                     "activity_cost_log_coefficients":coefficients(costcs),"activity_cost_interval":fmt(exact),
                     "Darboux_interval":fmt((lo,hi)),"Darboux_pieces":pieces,
                     "scope":"Finite scalar integral consistency, not a source/history time-uniform proof."}
                time_rows.append(row);trows.append(row)
        for x in vs:
            for y in vs:
                Ja=combine(({1+x:F(1)},F(1)),({1+y:F(1)},F(1)),({1+x+y:F(1)},F(-1)))
                Ji=evaluate(Ja);ratio=(1+x)*(1+y)/(1+x+y);direct=logq(ratio)
                ck(ratio==1+x*y/(1+x+y)>1,"exact subadd product ratio")
                ck(Ji[0]>0 and direct[0]>0,"certified positive log subadd gap")
                ck(Ji[0]<=direct[1] and direct[0]<=Ji[1],"independent log expressions consistent")
                # Formal observable-current-mass probabilities; no time-history construction.
                WA=x;WB=y;WD=F(1,3);WC=WA+WB;W=WC+WD
                probs=[WA/W,WB/W,WD/W]
                ck(sum(probs,F(0))==1,"hidden tag current mass posterior normalisation")
                # Coefficients of symbols PsiC, PsiA, PsiB, PsiD in expected jump.
                weighted=[(probs[0]+probs[1])/WC,-probs[0]/WA,-probs[1]/WB,F(0)]
                target=[F(1)/W,-F(1)/W,-F(1)/W,F(0)]
                ck(weighted==target,"E tag jump = -J/W exact formal coefficients")
                expected=(-Ji[1]/W,-Ji[0]/W)
                ck(expected[1]<0,"negative averaged scalar merge jump")
                merge_rows.append({"round":rd["name"],"x":str(x),"y":str(y),"J_log_coefficients":coefficients(Ja),
                                   "J_interval":fmt(Ji),"log_product_ratio":str(ratio),"direct_log_interval":fmt(direct),
                                   "current_masses":{"A":str(WA),"B":str(WB),"outside_D":str(WD),"C":str(WC),"W":str(W)},
                                   "current_hidden_tag_probabilities":[str(p) for p in probs],
                                   "expected_jump_symbol_coefficients":[str(q) for q in weighted],
                                   "minus_J_over_W_symbol_coefficients":[str(q) for q in target],"expected_jump_interval":fmt(expected),
                                   "scope":"Scalar log subadd and formal mass-weighting identity. No actual policy or spatial own-max profile certification for this scalar row."})
        # Original n1 complete disjoint atom packets: genuine packet profile, no max query.
        WA=max(vs);WB=min(vs);WD=F(1,3);WC=WA+WB;W=WC+WD
        pa=atomPsi(WA);pb=atomPsi(WB);pc=combine((pa,F(1)),(pb,F(1)))
        fa=combine((pa,F(1)/WA));fb=combine((pb,F(1)/WB));fc=combine((pc,F(1)/WC))
        da=combine((fc,F(1)),(fa,F(-1)));db=combine((fc,F(1)),(fb,F(-1)))
        dai=evaluate(da);dbi=evaluate(db);ck(dai[0]>0 and dbi[1]<0,"real heavy-tag up/light-tag down")
        weightedcs=combine((da,WA/W),(db,WB/W))
        ck(weightedcs=={} and evaluate(weightedcs)==(0,0),"real J0 weighted jump exact cancellation")
        ck(F(3)>2 and F(6)-F(3)>2,"actual same-window disjoint max footprints")
        ck(WA+WB+WD==W,"complete real source mass")
        ck(evaluate(fb)[0]>evaluate(fa)[1],"real concentrated vs sparse normalised profile order")
        atom_rows.append({"round":rd["name"],"n":1,"a":"1","b":"2","tau":"1",
                          "complete_source":{"atoms":[["0"],["3"],["6"]],"weights":[str(WA),str(WB),str(WD)],"W":str(W)},
                          "merge":["A","B"],"outside_tag":"D unchanged",
                          "atom_Psi_formula":"(w+2)ln(w+2)-w ln(w+1)-2ln2, original continuous window[1,2]",
                          "Psi_A_coefficients":coefficients(pa),"Psi_B_coefficients":coefficients(pb),"Psi_C_coefficients":coefficients(pc),
                          "normalised_A_interval":fmt(evaluate(fa)),"normalised_B_interval":fmt(evaluate(fb)),
                          "normalised_C_interval":fmt(evaluate(fc)),"tag_A_jump_interval":fmt(dai),"tag_B_jump_interval":fmt(dbi),
                          "tag_D_jump":"0","J_merge":"0","mass_weighted_jump_coefficients":coefficients(weightedcs),
                          "mass_weighted_jump":"0","scope":"Real complete finite atomic source with disjoint original cube footprints. Single-tag increase occurs; no nearmax/clock policy or actual geom certification."})
        summaries.append({"name":rd["name"],"time_rows":len(trows),"merge_rows":9,"real_disjoint_atom_pairs":1,"checks":checks-before})
    zeros=[{"v":"0","psi":"1 by continuous extension","r":"0","activity_fee":"0"}]
    zero_subadds=[]
    for x,y in [(F(0),F(0)),(F(0),F(1)),(F(1),F(0))]:
        cs=combine(({1+x:F(1)},F(1)),({1+y:F(1)},F(1)),({1+x+y:F(1)},F(-1)))
        ck(cs=={} and evaluate(cs)==(0,0),"subadd zero endpoints exact")
        zero_subadds.append({"x":str(x),"y":str(y),"J":"0"})
    ck(len(time_rows)==27 and len(merge_rows)==27 and len(atom_rows)==3,"registered counts")
    result={"status":"PASS","checks":checks,"rounds":summaries,"time_rows":time_rows,"scalar_merge_rows":merge_rows,
            "real_disjoint_atom_rows":atom_rows,"zero_time_endpoint":zeros,"zero_subadd_endpoints":zero_subadds,
            "script_sha256":sha(pathlib.Path(__file__)),"registration_sha256":sha(regp),
            "elapsed_seconds":time.monotonic()-start,"old_oracle_invocations":0,
            "log_method":"New100-term rational atanh with signed power2 reduction and outward dyadic256; exact symbol coefficient cancellation for equalities.",
            "scope":"Finite scalar kernel/merge weighting and genuine disjoint-atom profile arithmetic. No general process/global space proof, no nearmax or actual geom closure."}
    out=P/(PRE+"_results.json");dump(out,result)
    dump(P/(PRE+"_receipt.json"),{"status":"PASS","successful_execution_count":1,"failed_execution_count":0,
                                 "checks_successful_terminal_only":checks,"script_sha256":sha(pathlib.Path(__file__)),
                                 "registration_sha256":sha(regp),"results_sha256":sha(out),
                                 "elapsed_seconds":result["elapsed_seconds"],"old_oracle_invocations":0})
    print(json.dumps({"status":"PASS","checks":checks,"time_rows":len(time_rows),"scalar_merge_rows":len(merge_rows),
                      "real_atom_rows":len(atom_rows),"elapsed_seconds":result["elapsed_seconds"]}))
if __name__=="__main__":main()

