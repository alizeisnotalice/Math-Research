"""Exact compressed-lattice guards. One run, three preregistered rounds.

This does not evaluate a maximal operator or simulate a graph process.
All asserted comparisons are integer/Fraction comparisons. ln(2) is enclosed
by its positive atanh(1/3) series with an explicit rational remainder.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import sys
import time

BASE = Path(__file__).with_suffix("")
REG = Path(str(BASE) + "_registration.json")

def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")

def rat(x):
    x = F(x)
    return {"numerator": str(x.numerator), "denominator": str(x.denominator)}

def integer(x):
    s = str(x)
    return {"value": s, "bit_length": x.bit_length(), "decimal_sha256": hashlib.sha256(s.encode()).hexdigest()}

def log2_interval(terms):
    lo = sum((F(2, (2*k+1)*3**(2*k+1)) for k in range(terms)), F(0))
    tail = F(9, 4*(2*terms+1)*3**(2*terms+1))
    return lo, lo+tail

def interval(lo, hi):
    return {"lower": rat(lo), "upper": rat(hi), "display_lower": float(lo), "display_upper": float(hi)}

def run():
    registration = json.loads(REG.read_text())
    outputs = [Path(str(BASE)+f"_r{i}_n{n}.json") for i,n in enumerate(registration["dimensions"], 1)]
    outputs += [Path(str(BASE)+"_results.json"), Path(str(BASE)+"_receipt.json")]
    assert not any(p.exists() for p in outputs), "Refuse to overwrite existing numerical results"
    start = time.monotonic()
    rows = []
    previous = None
    for stage, (n, terms) in enumerate(zip(registration["dimensions"], registration["log2_terms"]), 1):
        M, L = 32*n+1, 16*n
        N, I, degree = M**n, (M-8)**n, 9**n-1
        source = {"dimension": n, "coordinate_set": f"all integers in [-{L},{L}]", "tensor_product": True,
                  "mass_per_distinct_atom": "1", "complete_source": True, "atom_count": str(N)}
        source_hash = hashlib.sha256(json.dumps(source, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        fraction, bernoulli = F(I,N), F(24*n+1,M)
        low_mass, high_mass = 2**(n+2), 2**(2*n-2)
        dp = F(degree, high_mass)
        tail = dp/(1+dp)
        per_axis = (M+4)//5
        packing = per_axis**n
        adaptive_tail = 1-F(packing*high_mass,N)
        lo, hi = log2_interval(terms)
        checks = {
            "complete_count_equals_W": N == (2*L+1)**n,
            "interior_count": I == (2*L-7)**n,
            "interior_bernoulli": fraction >= bernoulli > F(3,4),
            "internal_degree_offset_count": degree+1 == 9**n,
            "closed_cube_boundary_distance": 4 == 2*F(4,2),
            "positive_band": low_mass < high_mass and n > 4,
            "m_upper": F(high_mass,4**n) == F(1,4),
            "V_lower": F(low_mass,2**n) == 4,
            "r_lower_arithmetic": 1-F(1,8)-F(1,5) == F(27,40),
            "dp_lower": dp >= 1 and tail >= F(1,2),
            "packing_axis_bound": 4*per_axis <= M,
            "packing_fraction_bound": F(packing,N) <= F(1,4**n),
            "adaptive_tail_lower": adaptive_tail >= F(3,4),
            "ln2_interval_nested": previous is None or previous[0] <= lo <= hi <= previous[1],
        }
        assert all(checks.values()), checks
        fixed = F(81,320)*(n-4)
        adaptive = F(81,160)*(n-4)
        row = {
            "round": stage, "n": n, "L": L, "source": source,
            "compressed_source_descriptor_sha256": source_hash,
            "total_atom_count_and_W": integer(N), "interior_atom_count": integer(I),
            "interior_fraction": rat(fraction), "bernoulli_lower": rat(bernoulli),
            "interior_degree": integer(degree), "closed_graph_edge": "distinct z,z'; supnorm(z-z') <= 4",
            "band": {"lower_e_to_s": integer(low_mass), "upper_e_to_s": integer(high_mass),
                     "lower_s_ln2_coefficient": n+2, "upper_s_ln2_coefficient": 2*n-2,
                     "length_ln2_coefficient": n-4, "length": interval((n-4)*lo,(n-4)*hi)},
            "r_uniform_lower": rat(F(27,40)), "tail_law": "1-(1-exp(-s))^(9^n-1)",
            "minimum_dp_on_band": rat(dp), "fixed_graph_tail_uniform_lower": rat(tail),
            "fixed_graph_universal_lower_constant": rat(F(81,320)),
            "fixed_graph_normalized_fee_lower": interval(fixed*lo,fixed*hi),
            "terminal_block_axis_count": per_axis, "terminal_live_count_upper": integer(packing),
            "terminal_live_fraction_upper": rat(F(packing,N)),
            "adaptive_tail_uniform_lower": rat(adaptive_tail),
            "adaptive_universal_lower_constant": rat(F(81,160)),
            "adaptive_normalized_Gamma_work_lower": interval(adaptive*lo,adaptive*hi),
            "Z_upper_interval": interval(1+n*lo,1+n*hi),
            "ln2_terms": terms, "ln2_interval": interval(lo,hi), "checks": checks,
            "scope": "Exact guards for analytic strategy-cost lower bounds; no weak-type lower bound, maximal query, graph expansion, or simulation."
        }
        dump(outputs[stage-1],row)
        rows.append(row)
        previous = lo,hi
        print(f"round {stage}: n={n}; all {len(checks)} exact checks PASS; fixed lower={float(fixed*lo):.12g}; adaptive lower={float(adaptive*lo):.12g}", flush=True)
    dump(Path(str(BASE)+"_results.json"), {"registration_sha256": hashlib.sha256(REG.read_bytes()).hexdigest(), "rounds": rows})
    numerical = [p for p in outputs if p.exists()]
    receipt = {"status": "COMPLETE", "exit_status": 0, "python": sys.executable,
               "elapsed_seconds": time.monotonic()-start, "single_execution": True,
               "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "registration_sha256": hashlib.sha256(REG.read_bytes()).hexdigest(),
               "files": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in numerical},
               "error_control": "Exact integer/Fraction comparisons and analytic rational ln2 enclosure; float fields are display only."}
    dump(Path(str(BASE)+"_receipt.json"),receipt)

if __name__ == "__main__":
    run()
