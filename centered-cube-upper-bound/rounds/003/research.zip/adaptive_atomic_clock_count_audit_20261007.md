# 自适应原子时钟的计数障碍：独立解析审计

2026-10-07。父任务指定 gpt-6.1-sol high。只新增本审计，不改已冻结同质时钟稿、其他代理完整稿、主 TXT 或数值文件；不运行数值。本稿按已读 J01 的真实有限跳率／滤过／测试函数域流程，直接核有限路径似然、停止换测度与初等空间积分。

**判断。** root 提案在下述有限合法范围内成立。任意 tag-blind 自适应 rates、任意 \(Q\)-几乎处处有限的历史停时，只要终端存活数至多 \(k\)，就必须满足
\[
 \mathbb E_Qe^{-A_J(T)}\le k/N,\qquad
 Q(A_J(T)>s)\ge\max\{0,1-ke^s/N\}.
\]
具体完整原子格、原连续窗口 \([2,4]\)、\(\tau=1\) 的独立终端因此强制真实正 \(\Gamma\) 费用至少
\[
 \frac{81}{160}(n-4)\log2\qquad(n\ge4).
\]
正下界在 \(n>4\) 非平凡。这是该**无合并／无分裂／独立终端正帽路线**的一般自适应控制障碍，不否定 signed \(R\)、真实合并、合作终端或主弱型上界。

## 1. 有限合法 law 与均匀先验的准确含义

完整来源
\(\mu=\sum_{i=1}^N\delta_{y_i}\)，不同物理原子，初始单原子质量均为 \(1\)，\(W_0=N\)。每个尚存标签的实际接受死亡率
\(a_i(t)\in[0,1]\)，其来源幅度也以同一率增长。率为接收点无关、tag-blind 的已接受死亡历史函数；允许有限确定刷新及已接受死亡刷新，有限 horizon 上使用已经核验的有限刷新 law，不在此推广到未经构造的一般无限刷新政策。没有中途合并、重新分割或复活。

记死亡后 \(a_i=0\)，
\[
 A_i(t)=\int_0^ta_i(u)\mathbf1_{\{i\ {\rm alive\ at}\ u\}}du,\quad
 m_i(t)=e^{A_i(t)},\quad
 \nu_t=\sum_{i\ {\rm alive}}m_i(t)\delta_{y_i},\quad
 W_t=\sum_{i\ {\rm alive}}m_i(t).
\]
过程以死亡后的状态右连续。原滤过只观察已接受死亡和可观察来源／政策种子，不能预知未来寿命、拒绝 proposal 或隐藏 tag。

给定原 tag \(J=i\)，\(Q_i\) 保护它不死亡；其余标签执行同一历史政策，全部尚存标签仍按各自率增长。条件于共同政策种子，有限接受路径的死亡率因子在 \(Q_i/P\) 中相消，去掉 tag 的死亡 hazard 使无死亡指数比值为 \(e^{A_i(t)}\)，故
\[
 \frac{dQ_i}{dP}\Big|_{\mathcal F_t}
 =e^{A_i(t)}\mathbf1_{\{i\ {\rm alive\ at}\ t\}}.
\tag{AA1}
\]
即使另一历史上的率不同，同一观察路径上的政策值相同，正是此比较所需；政策若直接观察 tag，此理由不再成立。

初始均匀抽 tag，再执行 \(Q_i\)，给带标记法则 \(Q\)。
隐藏 tag 后
\[
 \frac{dQ}{dP}\Big|_{\mathcal F_t}=W_t/N,\qquad
 Q(J=i\mid\mathcal F_t)
   =\frac{e^{A_i(t)}\mathbf1_{\{i\ {\rm alive}\}}}{W_t}
   =q_i(t).
\tag{AA2}
\]
**均匀的是初始先验，不是后续存活标签的后验。** 非均匀增长不会使当前 posterior 保持 \(1/N_t\)；后续死亡率为 \(a_i(1-q_i)\)，总率也不等于 \(N_t-1\)。证明不使用这些错误替代。

## 2. 有限停止密度，不预设 P 终值 UI

对任何有界停时 \(S\le h\)，(AA1) 保持于 \(\mathcal F_S\)。可自含证明如下：简单网格停止时逐格使用有限时域路径密度；向上网格逼近 \(S\)，\(A_i\) 连续、存活指标右连续、密度有确定上界 \(e^h\)，所以支配收敛给停止时密度。这里也可直接对有限死亡路径在停止前截断似然；不需要无界可选抽样定理。

令 \(T\) 为同一可观察历史的任意停时，暂不要求 \(P(T<\infty)\)。取
\(S=T\wedge h\)，事件 \(F_h=\{T\le h\}\) 属于 \(\mathcal F_S\)。逐 tag 将有界停止密度与有界变量
\(e^{-A_i(S)}\mathbf1_{F_h}\) 配对。tag 在 \(Q_i\) 下存活，因此准确得到
\[
 \begin{aligned}
 \mathbb E_Q[e^{-A_J(T)}\mathbf1_{\{T\le h\}}]
 &=\frac1N\sum_i
   \mathbb E_{Q_i}[e^{-A_i(S)}\mathbf1_{F_h}]\\
 &=\frac1N\sum_iP(i\ {\rm alive\ at}\ T,\ T\le h)\\
 &=\frac1N\mathbb E_P[N_T\mathbf1_{\{T\le h\}}],
 \end{aligned}
\tag{AA3}
\]
其中 \(N_T\) 只在有限停止事件上解释即可。非等增长完全被逐 tag 的 \(e^{-A_i}\) 抵消；将 (AA3) 换成总质量公式则会丢掉这条计数结构。

若 \(Q(T<\infty)=1\)，两边对 \(h\uparrow\infty\) 使用非负单调收敛：
\[
 \mathbb E_Qe^{-A_J(T)}
 =\frac1N\mathbb E_P[N_T\mathbf1_{\{T<\infty\}}].
\tag{AA4}
\]
\(P(T=\infty)\) 上没有人为终端计数或终端来源，右边仅计真实有限停止路径。没有使用 \(P\) 下停止后的质量 UI、\(P(T<\infty)=1\) 或终值质量守恒。

## 3. 终端 count 资格能否从 Q 转给 P

若政策本身在每个有限停止路径满足 \(N_T\le k\)，(AA4) 立即给
\(\mathbb E_Qe^{-A_J(T)}\le k/N\)。
若只声明此资格在 \(Q\) 下几乎处处成立，也足够，但必须补出有限事件的绝对连续步骤。

令 \(B_h=\{T\le h,N_T>k\}\)。有界停止的混合密度给
\[
 0=Q(B_h)=N^{-1}\mathbb E_P[W_T\mathbf1_{B_h}].
\]
在 \(B_h\) 上 \(W_T\ge N_T>k\)，因为每个尚存原子幅度 \(e^{A_i}\ge1\)。故 \(P(B_h)=0\)。对整数 \(h\) 取可数并，得到 \(P\) 的有限停止路径也满足 count 资格；全灭路径 \(W_T=N_T=0\) 自然满足资格。
这补齐了从 Q 终端几何到 (AA4) 的 P count 上界，不可仅说 P/Q 全路径等价。

因此
\[
 \boxed{\mathbb E_Qe^{-A_J(T)}\le k/N.}
\tag{AA5}
\]
Markov 应用于非负 \(e^{-A_J(T)}\)，得每个 \(s\ge0\)
\[
 Q(A_J(T)\le s)\le (k/N)e^s,\qquad
 Q(A_J(T)>s)\ge\max\{0,1-(k/N)e^s\}.
\tag{AA6}
\]
允许 rates 为零和长冻结段，不改变此结论。

## 4. 原原子 profile 的完整空间积分

对原连续 hard 窗口 \([a,b]\)、\(\tau=1\)，完整单原子来源
\(\sigma=m\delta_y\) 的最大响应为
\[
 H(x)=\frac{m}{\max(a,2\|x-y\|_\infty)^n}
       \mathbf1_{\{2\|x-y\|_\infty\le b\}}.
\]
采用已核真实正 profile
\[
 G(v)=\log(1+v)-v/(1+v),\qquad
 \Gamma_1(\sigma)=\int G(H(x))\,dx .
\]
令 \(\alpha=a^n,\beta=b^n\)。core 体积为 \(\alpha\)，外围在变量
\(t=(2\|x-y\|_\infty)^n\) 下的 Lebesgue 径向体积为 \(dt\)，所以
\[
 \frac{\Gamma_1(m\delta_y)}m
 =\frac1m\left[\alpha G(m/\alpha)+
                    \int_\alpha^\beta G(m/t)\,dt\right].
\]
准确原函数为
\(\frac d{dt}[t\log(1+m/t)]=G(m/t)\)，因而
\[
 \boxed{\frac{\Gamma_1(m\delta_y)}m
       =\frac{\beta}{m}\log(1+m/\beta)
                    -\frac{\alpha}{\alpha+m}.}
\tag{AA7}
\]
这是全空间／全原窗口的精确公式，不是抽样壳、自由 posterior 或近似 profile。

取 \(a=2,b=4\)，令 \(m=e^s\)。即
\[
 r(s)=\frac{\log(1+e^s/4^n)}{e^s/4^n}
            -\frac1{1+e^s/2^n}\ge0.
\]
若
\[
 s_-= \log(4\cdot2^n)\le s\le
 s_+= \log(4^n/4),
\tag{AA8}
\]
则 \(m/\alpha\ge4\)、\(m/\beta\le1/4\)。由
\(\log(1+v)\ge v-v^2/2\) 给
\[
 r(s)\ge 7/8-1/5=27/40.
\tag{AA9}
\]
区间长度为 \((n-4)\log2\)，\(n=4\) 长度零；\(n>4\) 才给正线性障碍。

## 5. 真完整格来源与 independent terminal count

取原完整来源
\[
 \mu=\sum_{z\in[-16n,16n]^n\cap\mathbb Z^n}\delta_z,\qquad
 N=(32n+1)^n.
\]
来源 box 的有限边界全部保留，无 infinite-grid 替代。
终端要求每个真实边长 \(4\) 中心 cube 至多捕获一个存活原子。
将每条坐标的 \(32n+1\) 个整数分为连续至多 \(5\) 个整数的 blocks。
每个 Cartesian block 的坐标跨度至多 \(4\)，包含于一个原 \(Q(x,4)\)。
故每 block 至多一个尚存标签，严格推出
\[
 N_T\le k:=\left\lceil(32n+1)/5\right\rceil^n
       \le N/4^n.
\tag{AA10}
\]
最后一步由 \(d=32n+1\ge16\)、
\(\lceil d/5\rceil\le(d+4)/5\le d/4\)。
这是终端空间独立性给出的必要 count，不把总来源任意重分组，也不忽略边界。
对任意 \(s\) 属于 (AA8)，\(ke^s/N\le e^{s_+}/4^n=1/4\)，所以
\[
 Q(A_J(T)>s)\ge3/4.
\tag{AA11}
\]

## 6. 真正正 Γ 费用的内部时间换元

定义原控制的正费用
\[
 \mathcal C=
 \mathbb E_Q\int_0^T
   \sum_{i\ {\rm alive}}q_i(t)a_i(t)
       \frac{\Gamma_1(\nu_i(t))}{m_i(t)}\,dt.
\]
按 (AA2) 的真实当前 posterior 和非负 Fubini，
\[
 \mathcal C=
 \mathbb E_{Q\ {\rm with\ tag}}\int_0^T
       a_J(t)r(A_J(t))\,dt
 =\mathbb E_Q\int_0^{A_J(T)}r(s)\,ds.
\tag{AA12}
\]
第二步是非减绝对连续累计时钟换元，允许零速率、非均匀增长和任意适应 \(T\)；tag 在 Q 下不死，不需要普通物理时间的独立性。
再次非负 Fubini 给
\(\mathcal C=\int_0^\infty r(s)Q(A_J(T)>s)\,ds\)。
用 (AA9)、(AA11) 在 (AA8) 上截断，得到
\[
 \boxed{\mathcal C\ge
  \frac{27}{40}\frac34(s_+-s_-)
  =\frac{81}{160}(n-4)\log2.}
\tag{AA13}
\]
若正费用本来无穷，该下界仍成立。全过程不把 initial uniform tag 当作来源坐标产品分布，也不把当前 massprior 换成均匀存活 count。

## 7. 审计范围与未否定的路线

停时换测度、P 未停止路径、count 的有限事件资格、非等增长、真实 profile 与空间边界均已解析核对，没有发现提案漏洞。最重要的前提是：有限实际 law；政策不见 tag；无合并／无分裂；单原子物理 packets 始终固定；Q 下真实停止；独立终端；支付的是完整正 \(\Gamma_1\) 占用。

只要这些前提不变，自适应 rate 不能将该必要正占用压到 \(\sqrt n\,n^{o(1)}\)；障碍不仅针对统一时钟或静态邻接图。它不排除带 signed \(R\) 的取消、真实合并后的整组保护、允许多来源合作的终端或一般 weak 上界。本输入是有限正原子测度；若另一个论断只量化于 \(L^1\) 密度，还须单独核合法平滑迁移，不能由本审计自动声称其空间近似已验证。未作 nearmax 资格认证或实际 FIRST/fullfuture/CP--GP/LCA 资格认证；也没有把这个正帽费用下界说成原 geom 或 weak constant 的下界。

## 8. 同一计数身份的不等初始质量版本

再令完整来源为 \(\mu=\sum_iw_i\delta_{y_i}\)，\(w_i>0\)，\(W=\sum_iw_i\)，tag 初始先验为 \(w_i/W\)，其余无合并 law 与停止条件不变。当前单原子质量为
\(m_i(t)=w_i e^{A_i(t)}\)，tag 终值质量记 \(Z_J(T)=w_Je^{A_J(T)}\)，不是总质量 \(W_T\)。
有限停止的逐 tag 密度仍为 (AA1)，故
\[
 \begin{aligned}
 \mathbb E_Q[Z_J(T)^{-1}\mathbf1_{\{T\le h\}}]
 &=\sum_i\frac{w_i}{W}
     \mathbb E_{Q_i}[(w_ie^{A_i(T)})^{-1}
                                \mathbf1_{\{T\le h\}}]\\
 &=\frac1W\mathbb E_P[N_T\mathbf1_{\{T\le h\}}].
 \end{aligned}
\tag{AA14}
\]
有限 \(N\) 且 \(w_i>0\) 保证有界停止的逆质量变量有确定上界
\(1/\min_iw_i\)。若 \(Q(T<\infty)=1\)，非负 MCT 给
\[
 C_T:=\mathbb E_P[N_T\mathbf1_{\{T<\infty\}}],\qquad
 \mathbb E_QZ_J(T)^{-1}=C_T/W.
\]
所以对每个 \(m>0\)，准确方向为
\[
 Q(Z_J(T)>m)\ge[1-mC_T/W]_+.
\tag{AA15}
\]
这是对逆质量应用 Markov：先上界 \(Q(Z_J\le m)\)，再补集；若右侧未截断为负，非负概率允许取正部。严格 \(>\) 对应左边 \(Z_J\le m\)，没有假设终端质量分布无原子。

写 \(g(m)=\Gamma_1(m\delta_y)/m\ge0\)，其值平移不变，只依原质量 \(m\) 及固定窗口。
定义真实原 \(P\) 正费用
\[
 \mathcal B_\Gamma=
 \mathbb E_P\int_0^T\sum_{i\ {\rm alive}}
                         a_i(t)\Gamma_1(\nu_i(t))dt .
\]
非负时间换测度和真正当前 massprior 给
\[
 \frac{\mathcal B_\Gamma}{W}
 =\mathbb E_Q\int_0^T a_J(t)g(Z_J(t))dt
 =\mathbb E_Q\int_{w_J}^{Z_J(T)}g(m)\frac{dm}{m}.
\tag{AA16}
\]
若 \(0<m_{\rm lo}\le m_{\rm hi}\) 且
\(\max_iw_i\le m_{\rm lo}\)，保留内部固定质量区间，Tonelli 与 (AA15) 严格推出
\[
 \boxed{\frac{\mathcal B_\Gamma}{W}\ge
   \int_{m_{\rm lo}}^{m_{\rm hi}}
       g(m)[1-mC_T/W]_+\frac{dm}{m}.}
\tag{AA17}
\]
在每条路径上
\(\int_{w_J}^{Z_J(T)}g(m)dm/m\) 支配
\(\int_{m_{\rm lo}}^{m_{\rm hi}}g(m)\mathbf1_{\{Z_J(T)>m\}}dm/m\)。
上、下端点以及事件 \(Z_J(T)=m\) 的选择仅改变单点的质量积分，不要求无原子假设；逐固定 \(m\) 的 tail 下界本身也已使用准确的严格补集。

该控制／质量／终端 count 下界不依赖任何空间 packing；空间格的作用仅是另证 \(C_T\le k\)。等权格的 (AA13) 是其特例。这里没有新增数值维度、阶数猜测或批次：同一有限停止代数身份已经覆盖不等权情形。
