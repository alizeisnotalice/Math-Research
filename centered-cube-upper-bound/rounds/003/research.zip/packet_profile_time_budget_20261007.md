# 完整 packet 的 profile 时间预算、soft-log 势与合并账

2026-10-07。root 提出全时间轴积分、soft-log 势及固定图阈值敏感接口，本稿独立核验并补全有限控制与合并边界。只新增本稿及同前缀 LaTeX TXT，不改旧冻结文件、他人文件或主 TXT，不运行数值、不编译。使用已读 A02、E03 的正支配及保留终端望远镜流程；下面全部由初等积分、原完整来源和已证 finite-refresh LC/grouped law 推导，不借未核文献定理。

**状态。** 全轴 profile 积分确为来源 own maximal response 的强 \(L^1\) 费用，不是 own-logmax 费用。正轴费用有准确有限端项。固定 packet 图得到比 \(\kappa_B(1+H_{\deg B})\) 更细的真实阈值积分接口。合并后的望远镜必须扣除实际 soft-log 合并差；单条 tag 路径的 normalized profile 不必在合并时下降。以下没有给一般平方根上界，也不把原子 profile 的 \\(Z\) 当成一般弱型常数下界。

## 1. 原窗口、完整来源与两个 profile

固定完整有限正 Borel 来源 \(\sigma\)，质量 \(w>0\)，原连续尺度 \([a,b]\)，\(0<a<b<\infty\)，阈值 \(\tau>0\)。记
\[
 Q(x,r)=x+[-r/2,r/2]^n,\qquad
 H(x)=M_\sigma(x)=\max_{a\le r\le b}r^{-n}\sigma(Q(x,r)),
 \qquad Z=1+n\log(b/a).
\tag{1}
\]
接收端为全空间 Lebesgue，来源不要求坐标独立。沿用已证窗口包络 \(\int Hdx\le Zw\)。定义
\[
 \Phi_\tau(\sigma)=\tau\int\log_+(H/\tau)dx,\quad
 G(v)=\log(1+v)-\frac{v}{1+v},\quad
 \Gamma_\tau(\sigma)=\tau\int G(H/\tau)dx,
\]
\[
 \Psi_\tau(\sigma)=\tau\int\log(1+H/\tau)dx,
 \quad
 r_\sigma(s)=\frac{\Gamma_\tau(e^s\sigma)}{e^sw},\quad
 \psi_\sigma(s)=\frac{\Psi_\tau(e^s\sigma)}{e^sw},\quad
 k_\sigma(s)=\frac{\Phi_\tau(e^s\sigma)}{e^sw}.
\tag{2}
\]
这些积分有限，因为 \(0\le G(v)\le\log(1+v)\le v\)。它们只在原窗口里最大化；改变整体幅度或阈值不扩张允许尺度。令 \(K(\sigma)=\sup_{\lambda>0}\Phi_\lambda(\sigma)/w\)，则已证 sharp packet fee 给
\[
 0\le r_\sigma(s)\le K(\sigma)\le Z/e,
 \quad0\le k_\sigma(s)\le\psi_\sigma(s)\le\frac1w\int Hdx\le Z.
\tag{3}
\]

## 2. 全时间轴与准确正轴端项

非负 Tonelli 及代换 \(v=e^sH(x)/\tau\) 给
\[
 \int_{-\infty}^{\infty}r_\sigma(s)ds
 =\frac1w\int H(x)dx\int_0^\infty\frac{G(v)}{v^2}dv
 =\frac1w\int H(x)dx.
\tag{4}
\]
在 \(H(x)=0\) 点整项为 0，无需作除以 0 的代换。标量积分准确等于 1：
\[
 \int_0^V\frac{G(v)}{v^2}dv
 =1-\frac{\log(1+V)}V,
 \qquad\int_0^\infty\frac{G(v)}{v^2}dv=1.
\tag{5}
\]
第一式在 0 以连续极限解释；可由 \(G'(v)=v/(1+v)^2\) 分部积分证明，两端均有限。

逐点对幅度微分，并用 \(H\in L^1\) 在每个有限幅度区间支配，得到
\[
 \psi_\sigma'(s)=-r_\sigma(s),\qquad
 \lim_{s\to-\infty}\psi_\sigma(s)=\frac1w\int Hdx,
 \quad\lim_{s\to+\infty}\psi_\sigma(s)=0.
\tag{6}
\]
极限分别用 \(\log(1+v)/v\to1\) 和 \(\log(1+v)/v\to0\) 以及 \(H/w\) 支配，保留完整空间。特别任意 \(A\in[0,\infty]\) 有
\[
 \boxed{\quad
 \int_0^A r_\sigma(s)ds
 =\psi_\sigma(0)-\psi_\sigma(A),\qquad
 \int_0^\infty r_\sigma(s)ds=\frac{\Psi_\tau(\sigma)}w.
 \quad}
\tag{7}
\]
这里 \(\psi(\infty)=0\)。费用在正轴只使用初始固定阈值的 \(\Psi_\tau\)，不是全轴的 \(\int H\)，也不应把它误写成 \(K(\sigma)\)。

对实际单点来源 \(\sigma=w\delta_y\)，
\[
 H(x)=\frac{w}{\max(a,2\|x-y\|_\infty)^n}
 \mathbf1_{\{2\|x-y\|_\infty\le b\}},\qquad
 \frac1w\int Hdx=1+n\log(b/a)=Z.
\tag{8}
\]
核心体积 \(a^n\) 付 1，外围径向密度 \(nr^{n-1}dr\) 付 \(n\int_a^bdr/r\)。所以全轴预算无法在所有完整 packet 上换成一个平方根级强费用。它只诊断此 profile 正帽的成本，既不否定更精细 signed 控制，也不是一般弱型下界；特别没有 nearmax 资格声明。

## 3. 无合并 tag 的内部时间换元

在已证合法有限整组 law 中，原 tag 所在固定 packet 尚存且在该段不合并。若段首为完整当前来源 \(\sigma\)，其质量随累计活动时钟
\[
 A(t)=\int_{t_0}^t a_B(u)du,\qquad\nu_B(t)=e^{A(t)}\sigma
\tag{9}
\]
增长。保护 tag 的 \(Q\) law 下此 packet 不死亡。无须 \(a_B>0\)：绝对连续非减换元与 (6) 链式给，逐路径
\[
 \int_{t_0}^{T}a_B(t)\frac{\Gamma_\tau(\nu_B(t))}{W_B(t)}dt
 =\int_0^{A(T)}r_\sigma(s)ds
 =\psi_\sigma(0)-\psi_\sigma(A(T)).
\tag{10}
\]
对有界停止直接成立；无界延长可用非负单调收敛和 \(\psi(\infty)=0\)。普通日历时间、死亡次数和别的 packet 活动量不能代替这个内部时钟。不同幅度段拼接时要用真正段首的完整 profile。

## 4. Fixed packet 图：阈值敏感的准确积分接口

固定有限完整 Borel 分割 \(\mu=\sum_B\mu_B\)，质量 \(w_B>0\)、\(W=\sum_Bw_B\)。选有限无向图覆盖全部真实 \(Q(x,b)\) 共捕获边，运行已核图政策：有存活邻居的包 active，速率 1；孤立包永久冻结。整包同速率增长和删除；不在运行中合并。

原 \(P\) 下的图停止 \(T\) 至多 \(N-1\) 次删除，每个有边状态总删除率至少 2。因此
\[
 T\le\sum_{j=1}^{N-1}\operatorname{Exp}_j(2),\quad
 \mathbb E_Pe^{qT}<\infty\ (q<2),\quad
 W_{t\wedge T}\le We^T.
\tag{11}
\]
取 \(1<q<2\) 得停止质量和各包停止质量 UI；\(\Phi,\Psi\le ZW_t\) 的终值可支配收敛。质量倾斜的有限时域密度为 \(W_t/W\)，初始 tag 在包 \(B\) 中的概率为 \(q_B=w_B/W\)。给定 tag 包，每个初始邻居持续 active，寿命相互独立 Exp(1)。所以 tag 的累计活动时钟
\[
 A_B=\max_{1\le j\le d_B}L_j,\qquad d_B=\deg_G(B),\quad
 L_j\text{ 独立 Exp}(1),
\]
\[
 P(A_B>s)=T_{d_B}(s):=1-(1-e^{-s})^{d_B},\quad s\ge0,
 \qquad \mathbb EA_B=H_{d_B}.
\tag{12}
\]
\(d_B=0\) 时规定 \(A_B=0\)、\(T_0\equiv0\)、\(H_0=0\)，不是把零次数的密度公式硬套进去。\(d\ge1\) 时连续密度为
\[
 f_d(s)=d e^{-s}(1-e^{-s})^{d-1},\qquad s>0.
\tag{13}
\]
tag 先冻结后，其他远端分支仍可能继续运行；\(A_B\) 是局部活动量而非全局 \(T\)。\(Q(T<\infty)=1\) 由每个有边状态至少一个非 tag 可删除包和有限删除数证明。

写 \(r_B,\psi_B,k_B\) 为原完整 \(\mu_B\) 的 (2) profile。给定 tag 包的有限路径似然比是 \(e^{A_B(t)}\mathbf1_{B\text{ 尚存}}\)。停止 UI 及 \(Q\) 终止允许送至 \(T\)，给
\[
 \mathbb E_P\Phi_\tau(\nu_B(T))
 =w_B\mathbb E_{Q(\cdot\mid J\in B)}k_B(A_B),
\]
\[
 \mathbb E_P\int_0^T\sum_Ba_B\Gamma_\tau(\nu_B(t))dt
 =\sum_Bw_B\int_0^\infty T_{d_B}(s)r_B(s)ds.
\tag{14}
\]
第二式用当前 tag 后验 \(W_B(t)/W_t\)、非负 Tonelli 和 (10)。第一式可先限制 \(T\le h\) 使用有界停止密度，再由原 \(P\) UI 与 \(Q\) 有界比值送极限，不靠形式质量守恒。

终态每个原 cube 至多捕获一个包，故 \(\Phi_\tau(\nu_T)\le\sum_B\Phi_\tau(\nu_B(T))\)。结合已证 sharp \(\Gamma\) 预算，得到一般完整输入上的新精化
\[
 \boxed{\quad
 \frac{\Phi_\tau(\mu)}W\le\sum_Bq_B c_{d_B}(\mu_B;\tau),\qquad
 c_d(\sigma;\tau):=\mathbb E k_\sigma(A_d)
       +\int_0^\infty T_d(s)r_\sigma(s)ds.
 \quad}
\tag{15}
\]
这里期望只对明确的最大指数寿命分布，不是重新独立抽 receiver 或 source 坐标。用 (7) 与 Tonelli，准确等价形式为
\[
 c_d(\sigma;\tau)=\psi_\sigma(0)
 -\mathbb E\{\psi_\sigma(A_d)-k_\sigma(A_d)\}.
\tag{16}
\]
特别 \(c_0=k_\sigma(0)\)。若 \(\kappa\ge K(\sigma)\) 为已证 own cap，则
\[
 0\le c_d(\sigma;\tau)
 \le\min\left\{\kappa(1+H_d),\ \frac{\Psi_\tau(\sigma)}w\right\}
 \le\frac1w\int M_\sigma dx\le Z.
\tag{17}
\]
第一上帽来自 \(k\le\kappa\)、\(r\le\kappa\)、\(\int T_d=H_d\)，第二上帽来自 (16) 的非负端差。端差保留了 degree、阈值及完整包形状。此法改善该图路线的粗调和价目，却不改善已有一般 \(Z/e\) log-max 基线，也不宣称所有 degree 代价已消失。

\(d\to\infty\) 时，\(A_d\to\infty\) 依概率，且 \(0\le\psi(A_d)-k(A_d)\le\psi(A_d)\le Z\)、\(\psi(s)\to0\)，故
\[
 \lim_{d\to\infty}c_d(\sigma;\tau)=\psi_\sigma(0).
\tag{18}
\]
不能把这个饱和值统一改成平方根。另一方面，这里没有证明 \(c_d\) 对 \(d\) 单调；其端差随幅度可以上升或下降，应保留实际积分而不是猜单调性。

## 5. 合并时需要的真实空间账

使用已证 grouped-source law 的同范围控制：有限原始来源分割、有限个确定刷新及已接受死亡刷新；只 union 当前完整包、不分裂、不复活，非平凡合并至多 \(N-1\) 次。政策不观察未来辅助 marks 或隐藏 tag。零时刻合并计入初始组态；下列和只计 \(0<s\le T\) 的合并。

对当前完整 \(\nu\) 和分组 \(\mathcal B\)，定义真实包势
\[
 F(\nu,\mathcal B)=\sum_{B\in\mathcal B}\Psi_\tau(\nu_B),
 \qquad 0\le\Phi_\tau(\nu)\le F(\nu,\mathcal B)\le ZW(\nu).
\tag{19}
\]
中间支配成立，因为 \(M_\nu\le\sum_BM_{\nu_B}\) 且
\(\log_+(\sum v_B)\le\log(1+\sum v_B)\le\sum_B\log(1+v_B)\)。它允许所有合作和交叉捕获，不要求终态独立集。

沿整包增长 \(\nu_B(t)=e^{a_Bt}\nu_B(0)\)，准确微分给
\[
 \frac d{dt}\Psi_\tau(\nu_B(t))
 =a_B\{\Psi_\tau(\nu_B(t))-\Gamma_\tau(\nu_B(t))\}.
\tag{20}
\]
以速率 \(a_B\) 整包删除，\(F\) 的跳损失正好 \(\Psi_\tau(\nu_B)\)。所以其原 \(P\) 漂移准确为 \(-\sum_Ba_B\Gamma_\tau(\nu_B)\)，不是不确定真赢家切换的近似生成元。

合并完整 children \(B_1,\ldots,B_\ell\) 时，当前来源不变，定义实际空间下降
\[
 J_{\rm merge}=\sum_{j=1}^{\ell}\Psi_\tau(\nu_{B_j})
 -\Psi_\tau\left(\sum_{j=1}^{\ell}\nu_{B_j}\right)\ge0.
\tag{21}
\]
正性由 own max 次可加及上述 soft-log 次可加证明；不能用 coarse 标签熵替代 \(J_{\rm merge}\)。对任意有界 accepted-history 停时，有限 first-jump 补偿与显式有限合并增量得到准确恒等式
\[
 \boxed{\quad
 \mathbb E_P\int_0^T\sum_Ba_B\Gamma_\tau(\nu_B(t))dt
 =F(\mu,\mathcal B_0)-\mathbb E_PF(\nu_T,\mathcal B_T)
 -\mathbb E_P\sum_{0<s\le T}J_{\rm merge}(s).
 \quad}
\tag{22}
\]
\(\Psi\) 的 TV-Lipschitz 性由 \(\log(1+v)\) 的 Lipschitz 性及窗口包络得到。有限 horizon 下所有项由 \(Ze^hW\)、有限来源标签数及有限刷新控制，故补偿与停止均绝对可积。对于未经核尾条件的无界停止，不直接使用 (22)；固定图已有 (11) 的 UI，其他控制须另核终值或 \(Q\) 尾。

## 6. Tag 跨合并的符号：路径不能免费望远镜

在当前隐藏 tag 的 law 下令
\[
 f_J(t)=\frac{\Psi_\tau(\nu_{B_t(J)}(t))}{W_{B_t(J)}(t)}.
\tag{23}
\]
无合并段 (10) 给其微分为 \(-a_{B_t(J)}\Gamma_\tau(\nu_{B_t(J)})/W_{B_t(J)}\)。非 tag 组死亡不会改变 tag 包的完整 profile。合并时记 \(\Delta f_J=f_J(s)-f_J(s-)\)。于是有界停时逐路径准确
\[
 \int_0^T a_{B_t(J)}\frac{\Gamma_\tau(\nu_{B_t(J)})}{W_{B_t(J)}}dt
 =f_J(0)-f_J(T)+\sum_{0<s\le T}\Delta f_J(s).
\tag{24}
\]
单条路径的 \(\Delta f_J\) 不必非正。真实例：取两个相距超过 \(b\) 的不同原子 packets，捕获足迹互不相交，所以 \(\Psi(\sigma_A+\sigma_B)=\Psi(\sigma_A)+\Psi(\sigma_B)\)。用 (6) 对幅度的严格下降选不同质量，使 \(\Psi(\sigma_A)/w_A<\Psi(\sigma_B)/w_B\)。合并后的比值是二者质量加权平均：tag 在 \(A\) 中时上升，在 \(B\) 中时下降。这是实际完整来源、原正宽窗口例，无自由 posterior 或重合原子拆标签。

隐藏 tag 后，条件于当前可观察合并历史，children 后验是 \(W_{B_j}/W\)，故
\[
 \mathbb E_Q[\Delta f_J\mid\text{当前合并的可观察历史}]
 =-J_{\rm merge}/W\le0.
\tag{25}
\]
未参与合并的 tag 贡献 0。这个条件式也适用于先接受死亡、再按刷新历史决定合并；必须用死亡后的当前质量及 tag 后验，不能提前冻结旧概率。有限和的停止密度给 \(W_0\mathbb E_Q\sum J_{\rm merge}/W=\mathbb E_P\sum J_{\rm merge}\)。因此 (24) 的正确平均望远镜正是 (22)，不是逐 tag 免费重启 (7) 的新正轴预算。

## 7. 带符号修正及其不能免费闭合的原因

对原真赢家定义每包真实 \(D_B=\Phi(\nu)-\Phi(\nu-\nu_B)\)、增长下界 \(L_B=\tau\int_{\{M_\nu>\tau\}}p_Bdx\)。已证 sharp fee 使
\[
 \delta_B(\nu):=\Gamma_\tau(\nu_B)-(D_B-L_B)\ge0.
\tag{26}
\]
沿 finite-refresh grouped law，实际连续 \(\Phi\) 增长至少 \(\sum a_BL_B\)，因此比单纯正帽更强的有界停止合同为
\[
 \Phi_\tau(\mu)\le\mathbb E_P\Phi_\tau(\nu_T)
 +\mathbb E_P\int_0^T\sum_Ba_B\Gamma_\tau(\nu_B)dt
 -\mathbb E_P\int_0^T\sum_Ba_B\delta_B(\nu_t)dt.
\tag{27}
\]
把 (22) 代入，令 \(B_T=F(\nu_T,\mathcal B_T)-\Phi_\tau(\nu_T)\ge0\)，得到保留全部可核减项的普适弱接口
\[
 \boxed{\quad
 \Phi_\tau(\mu)\le F(\mu,\mathcal B_0)
 -\mathbb E_P B_T
 -\mathbb E_P\sum_{0<s\le T}J_{\rm merge}(s)
 -\mathbb E_P\int_0^T\sum_Ba_B\delta_B(\nu_t)dt.
 \quad}
\tag{28}
\]
原 \(P\) 下这些信用的总和受初始非负差 \(F_0-\Phi(\mu)\) 控制；不能凭“合并”或“熵降低”产生超出此预付空间差的奖励。合并成全来源并立刻停止时，式子返回准确 \(\Phi(\mu)\)，不是免费证明一个更小的全输入上界。初始正帽可达 \(\sum\int M_{\mu_B}\) 的 \(Z\) 量级；要对一般输入改进到目标，必须有真实几何下界捕获足够的端差、合并差或 signed slack，同时不能把路径上每个新输入都默认 nearmax。

这是对 \(\Gamma\) 占用的严格改进与完整端项审计：fixed 图可用 (15)–(17)，合并过程可用 (22)、(28)。没有证明三种信用总能达到所需量级，也没有否定合适空间尺度的分组策略。所有结果保留原完整来源和全部原尺度。可登记的数值对象为原 own profile 的 \(r,\psi,k\)、图度数分布、(16) 的独立积分区间、以及完整合并的 \(J\) 和 (25) 后验加权身份；本文没有运行这些数值。
