import json,hashlib
from pathlib import Path
from fractions import Fraction as F
p=Path(__file__).resolve().parent
def obj(n):return json.loads((p/n).read_text())
for e in obj('inventory.json')['files']:
 b=(p/e['path']).read_bytes();assert len(b)==e['bytes'];assert hashlib.sha256(b).hexdigest()==e['sha256']
for pref,suffix,status in [('homogeneous_clock_generator_guard_20261007','','complete'),('profile_clock_kernel_guard_20261007','_run','PASS')]:
 x=obj(pref+'_results.json');assert x['status']==status
 assert hashlib.sha256((p/(pref+suffix+'.py')).read_bytes()).hexdigest()==x['script_sha256']
 assert hashlib.sha256((p/(pref+suffix+'_registration.json')).read_bytes()).hexdigest()==x['registration_sha256']
x=obj('homogeneous_clock_generator_guard_20261007_results.json');count=0
for s in x['summaries']:
 assert F(s['probability_sum'])==1
 for k in ['left_identity_residual','right_identity_residual']:
  v=s[k];assert F(v['constant'])==0 and not v['signed_log_coefficients'] and v['interval']==['0','0'];count+=1
assert count==18
assert obj('profile_clock_kernel_guard_20261007_results.json')['checks']==380
x=obj('lattice_profile_clock_obstruction_20261007_results.json');checks=0
assert hashlib.sha256((p/'lattice_profile_clock_obstruction_20261007_registration.json').read_bytes()).hexdigest()==x['registration_sha256']
for s in x['rounds']:
 assert all(v is True for v in s['checks'].values());checks+=len(s['checks'])
 assert int(s['terminal_live_count_upper']['value'])*4**s['n']<=int(s['total_atom_count_and_W']['value'])
assert checks==42
print(json.dumps({'status':'PASS','round':3,'file_hashes':len(obj('inventory.json')['files']),'exact_generator_identities':count,'saved_kernel_check_count':380,'lattice_guards':checks,'original_experiments_rerun':False,'compiled':False},indent=2))
