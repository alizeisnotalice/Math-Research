# Profile-clock kernel 时间势：新三轮守卫终态

2026-10-07。只新增本 prefix，未改他人或主 TXT。已读并协调 packet_profile_time_budget_20261007.md §2/6；使用已读 L03 的有理区间/符号等号规则，J01 的真实 law 量词约束。下面是新有限算术与真实不交原子 profile 的守卫，不替代正文的全空间、任意合法控制或停时证明。

## 1. 精确时间势及积分外包

标量 v>0，G(v)=ln(1+v)−v/(1+v)，ψ(v)=ln(1+v)/v，r(v)=G(v)/v。直接微分给

−vψ'(v)=ln(1+v)/v−1/(1+v)=r(v)，
−d/ds ψ(e^s v)=r(e^s v)。

所以从 v 增幅到 cv 的累计内部时钟费用精确为

∫_v^{cv} G(z)/z² dz=ψ(v)−ψ(cv)。

这是内部活动量 s=ln幅度的换元，不是日历时间或删除次数。v0 时 ψ0=1、r0=0 按连续延拓，费用0；没有作除零。

三轮原 v 为 (1/64,1/4,1)、(2,8,32)、(1/1024,1024,65536)，每个 v 用 c2/8/256，共27个时间积分记录。每段固定 geometric mesh z_j=v2^j，j0..log2c，注册后从未按结果细化。全部 node、kernel endpoint 区间、Darboux piece 与总外包保存 results。

kernel f(z)=G(z)/z² 在 z>0 严格递减：G(z)=∫_0^z t/(1+t)²dt，故
2G(z)>z²/(1+z)²=zG'(z)，于是 f'(z)<0。每个 [a,b] 上，用 f(b) 下界付面积、f(a) 上界付面积，得到独立有限 Darboux 外包。27个准确 potential-difference 区间均严格位于该外包之内。外包可以较宽，不为取得漂亮结果调参。

另一个完全等价的自含检查是设 h(z)=zG'(z)−2G(z)。h(0)=0（连续延拓），h'(z)=−2z²/(1+z)³<0，所以 f'(z)=h(z)/z³<0。该解析单调证明支撑端点 Darboux 方向，不由有限区间计算猜测单调。

这个包含检查仅为数值一致性；时间积分恒等由上面的解析导数/换元证明，不能将区间相交或包含称为全域积分证明。

## 2. Scalar 合并与隐藏 tag 的准确含义

每轮的三个 v 作全部9个有序 (x,y) pair，包含强不均衡，例如 x1/1024、y65536；共27行。验证

ln(1+x)+ln(1+y)−ln(1+x+y)
=ln[(1+x)(1+y)/(1+x+y)]≥0。

正参数的 argument 精确为 1+xy/(1+x+y)>1；三log直接区间和独立单log区间都严格为正。两种区间相交只作一致性，解析 log 乘除恒等式承担相等性。另零参数 (0,0),(0,1),(1,0) 的 coefficient 字典精确消成零，不用 interval overlap 认证等号。

这里 **tag jump 指合并，不是删除 generator**。正式身份使用合并时可观察当前完整 source masses W_A,W_B、外部 W_D；W_C=W_A+W_B，W=W_C+W_D。隐藏tag概率为 W_A/W、W_B/W、W_D/W。参与合并的 tag ratio 从 Ψ_A/W_A 或 Ψ_B/W_B 变成 Ψ_C/W_C；未合并 tag不变。因此

E_Q Δf_J
=(W_A/W+W_B/W) Ψ_C/W_C
−(W_A/W)Ψ_A/W_A−(W_B/W)Ψ_B/W_B
=(Ψ_C−Ψ_A−Ψ_B)/W=−J_merge/W。

代码逐行核四个独立符号 Ψ_C,Ψ_A,Ψ_B,Ψ_D 的精确有理系数，不把 Ψ 值或 κ 数值先平均后冒充独立性。27个 scalar log 行取当前 masses W_A=x、W_B=y、W_D=1/3，保存全部当前后验、质量、coefficients 和负 averaged-jump 区间。

这27行的 scalar Ψ 是有限代数值，不含空间 source 坐标或实际时间 history，不宣称该 scalar 每行都实现实际 own-max；真实 law 与完整空间势的映射由正文证明。若合并跟在一次接受死亡后，必须采用死亡后的当前 masses/posterior，不能冻住旧概率。

## 3. 真实完整来源：单tag可以上升

每轮另保存一个原 n1、[a,b]=[1,2]、τ1 的完整来源：

ν=W_A δ0+W_B δ3+(1/3)δ6，
W_A=本轮v最大值，W_B=本轮v最小值。

全部原 source/mass 保留；第三个 packet 是未合并的外部 tag。每个 atom 的 own maximal 支撑是其中心加[-1,1]，相邻 atom距离3>b2，足迹不交，任何原 cube 无法同时捕获两个 atom。所以 A/B 合并的真正 own Ψ_C=Ψ_A+Ψ_B，准确 J_merge=0。

原完整连续窗口的 atom profile 可解析径向积分，不查询最大值：

Ψ_1(wδ_y)
=ln(1+w)+∫_1^2 ln(1+w/t)dt
=(w+2)ln(w+2)−wln(w+1)−2ln2。

其 normalized ratio Ψ/w 随 w 严格下降。因此浓 atom A 有较低 normalized ratio，合并之后变成 A/B 的质量加权平均：tagA上升、tagB下降、tagD不变。三轮严格 signed 区间与符号 log coefficient 均保存；全部质量加权 jump 精确抵消为0。

|轮|tagA jump诊断|tagB jump诊断|
|---|---:|---:|
|small|+0.0071560582573|−0.457987728467|
|moderate|+0.0455235562270|−0.728376899632|
|extreme|+0.0000000252140|−1.69208261330|

这些小数仅供阅读，符号由256-bit外包严格认证。该 witness 有完整正来源、原连续窗口、解析真实 atom own-profile；没有 nearmax、actual geom 或一般政策轨迹资格。它排除的是逐tag合并势总下降的说法，不排除正确条件平均的 −J/W≤0，也不制造一般弱型下界。

## 4. 预执行更正与冻结链

第一次准备的 profile_clock_kernel_guard_20261007.py 和 registration 已冻结，但**未执行**。静态检查发现 atom w1 时 formula 中 log(w+1)=log2，原 dictionary 会覆盖同 argument 的 coefficient。保留原冻结文件不改；新增 _run.py/_run_registration.json，使用 combine 相加相同 log argument。另删除一项无用的重复 interval evaluation，全部 parameters、mesh、预算不变。

final registration 保存原 code/registration hashes 与此次静态更正原因。它是预执行修正，不是运行失败，不计为数值 attempt。实际仅执行新的 _run.py 一次；原初版 从未执行。所有 atom equal-log cancellation 使用精确 symbols 后再作 interval，避免此类覆盖错误。

对数统一使用新代码中的100项 atanh 正级数、精确 power2 reduction、余项2z^201/[201(1−z²)]、向外256-bit dyadic。负系数交换端点，等号由 exact coefficients消零。没有复用或执行旧 oracle。

## 5. 终态及文件收据

**380 PASS**：三轮各125项，共375；final code hash1；scalar零端点3；总数量1。共27个时间积分、27个 scalar合并、3个真实不交atom完整来源 witness；一成功执行，失败0。elapsed0.05611129102180712秒，旧max/oracle0。

- 实际执行 code：profile_clock_kernel_guard_20261007_run.py
  SHA256 7c220b0c263b4a360246529963c77f28a88ebe4de0a6ba71ddaa0ec1129eec5d
- 实际冻结登记：profile_clock_kernel_guard_20261007_run_registration.json
  e060ee788bcb9a4c8f5baf53b1951556b2385c1f85da6788d9189047641695f4
- results：
  5f5f8bd92a6aa087c7e063e6bc33085ec89d3fbeadcabcfd46536c943d76e9c2
- receipt：
  494b7d241723125d75bfc92ef0713d6503d3ea726af1b3cf1bd1c386854552f0
- 原未执行 code：
  e5f6440b0a67af98634396b0d2ed727d2b7a84fe66f9a311d3ca50d418370875
- 原未执行 registration：
  988ac96e6302dedd674a0f4b38470ac02e9b5ed44ead3e721e1975ba4bdc348f

本批仅核准确时间kernel、有限Darboux、合并质量加权和真实单tag signed例。完整来源全空间/任意合法过程/停止望远镜由 packet_profile_time_budget 正文承担；没有因每段正轴费用有限就免费重启，也不宣称一般 geom 已闭合。
