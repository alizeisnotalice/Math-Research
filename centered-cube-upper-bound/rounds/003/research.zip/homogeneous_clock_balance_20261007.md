# 完整固定 packets 的统一时钟：精确有符号余额

2026-10-07。父任务指定 gpt-6.1-sol high。本稿及同名前缀 LaTeX 片段独立新增，不改主 TXT、冻结稿或他人文件；只做解析，不运行数值。

**结论。** 全体存活固定 packets 以速率 \(1\) 增长并以速率 \(1\) 整组死亡时，严格超阈体积 \(I_\tau\) 是沿无跳段的精确积分导数。因此
\[
 R(\nu)=\sum_{i\ {\rm alive}}D_i(\nu)-I_\tau(\nu)
\]
给精确的有符号停止余额，而非非均匀时钟中的冻结赢家下界。阈值平台处的点态右生成元须改用 \(I_{\tau,\ge}\)，不能删去此区别。恒等式保留真实终端项；它本身没有给出一般维数预算。

使用 [J01](/Users/zhengzhihao/.codex/skills/math-j01-inhomogeneous-jump-generator/SKILL.md)、[E03](/Users/zhengzhihao/.codex/skills/math-e03-tree-bellman-cross-layer-budget/SKILL.md) 及其 method、cube-interface、provenance。下面自证指数首死亡、有限停止与终端极限，不援引外部生成元／Bellman 定理。查重：grouped_source_clock 已给任意 rates 的 signed 下界及 own-packet 包络；stopped_source_thinning 已给统一小格的 \(16\)-预算与质量倾斜。本稿仅补统一任意 packet 的**精确等式**，不再把旧 own-packet 包络记为新费用。

## 1. 原完整来源与功能

固定 \(0<a\le b<\infty\)、\(\tau>0\)，完整有限正来源
\(\mu=\sum_{i=1}^N\mu_i\)，其中 \(\mu_i=\mu|_{E_i}\) 为预固定不交 Borel 来源分割，\(w_i=\mu_i(\mathbb R^n)>0\)，\(W_0=\sum_iw_i\)。不要求空间小格或来源产品结构；原物理原子不拆成重合独立标签。写
\[
 \begin{gathered}
 M_\nu(x)=\sup_{a\le r\le b}r^{-n}\nu(Q(x,r)),\quad
 I_\tau(\nu)=\tau|\{M_\nu>\tau\}|,\quad
 I_{\tau,\ge}(\nu)=\tau|\{M_\nu\ge\tau\}|,\\
 \Phi_\tau(\nu)=\tau\int\log_+(M_\nu/\tau)\,dx,\qquad
 Z=1+n\log(b/a).
 \end{gathered}
\]
全部空间积分为 Lebesgue 积分。完整 hard envelope
\(k_*(z)=\sup_{a\le r\le b}r^{-n}\mathbf1_{Q(0,r)}(z)\) 满足
\(\int k_*=Z\)，从而
\[
 \int M_\nu\le ZW(\nu),\quad I_\tau(\nu)\le ZW(\nu),\quad
 0\le\Phi_\tau(\nu)\le (Z/e)W(\nu).
\tag{HC1}
\]
另有 \(|\Phi_\tau(\nu)-\Phi_\tau(\nu')|\le Z\|\nu-\nu'\|_{\rm TV}\)：
\(\tau\log_+(u/\tau)\) 对 \(u\ge0\) 为 \(1\)-Lipschitz，而
\(|M_\nu-M_{\nu'}|\le M_{|\nu-\nu'|}\)。

在严格超阈集合取原完整共同真赢家 \(R(x)\)，其捕获 posterior
\(\pi_i=\nu_i(Q(x,R))/\nu(Q(x,R))\) 总和为 \(1\)。本稿精确增长不用对赢家求导：整体放大时所有原尺度响应同乘一个系数，故
\(M_{e^s\nu}=e^sM_\nu\) 恒等成立。删除也对完整剩余来源重新取原最大值：
\[
 D_i(\nu)=\Phi_\tau(\nu)-\Phi_\tau(\nu-\nu_i)\ge0.
\]
不能用 frozen winner 的删除帽替代此真实 \(D_i\) 后仍声称等式。

## 2. 精确积分导数与阈值平台

令 \(F(s)=\Phi_\tau(e^s\nu)\)。对有限 \(u<v\)，逐接收点的正部函数给
\[
 \boxed{F(v)-F(u)=\int_u^v I_\tau(e^s\nu)\,ds.}
\tag{HC2}
\]
理由是
\((v+\ell)_+-(u+\ell)_+=\int_u^v\mathbf1_{\{s+\ell>0\}}ds\)，
\(\ell=\log(M_\nu/\tau)\)；\(M_\nu=0\) 时该项为零。非负 Fubini 与 (HC1) 使该积分有限。因此 \(F\) 局部绝对连续，\(F'=I_\tau(e^s\nu)\) 对 \(ds\)-几乎处处成立。

在固定状态的右、左导数则准确为
\[
 F'_+(0)=I_{\tau,\ge}(\nu),\qquad F'_-(0)=I_\tau(\nu).
\tag{HC3}
\]
若平台 \(\{M_\nu=\tau\}\) 有正体积，两者不同。沿每段无跳增长只影响零时间测集：在有限 \(s\)-区间，每个正 \(M_\nu(x)\) 只命中阈值一次，Fubini 给
\(\int|\{e^sM_\nu=\tau\}|ds=0\)。所以 (HC2) 使用严格集合正确，但不能说严格 \(I_\tau\) 在每一状态都是右生成元。

## 3. 原 P：有限有界停止的等式

独立寿命 \(L_i\sim{\rm Exp}(1)\)，仅观察已经接受的死亡，取右连续状态
\[
 A_t=\{i:L_i>t\},\quad
 \nu_t=e^t\sum_{i\in A_t}\mu_i,\quad
 W_t=e^t\sum_{i\in A_t}w_i .
\tag{HC4}
\]
空状态保持空，\(R(0)=0\)。原始死亡滤过可加独立政策种子，不预见未来寿命。没有中途合并或重新分割。

当前 \(j\) 个存活 packets 的首死亡标签 \(i\)、延迟 \(s\) 的密度为
\(e^{-js}ds\)；无死亡至 \(s\) 的概率为 \(e^{-js}\)。
因此该段真实首删除损失期望是
\(\int e^{-js}\sum_iD_i(e^s\nu)ds\)，与存活段删除占用积分期望相同。删除后条件于已见历史，再用独立指数剩余寿命递归；至多 \(N\) 次死亡。这逐段证明实际删除损失的补偿，不以工具名称代替证明。结合 (HC2) 得条件积分等式。

有限 horizon \(h\) 内，
\[
 W_t\le e^hW_0,\qquad
 |R(\nu_t)|\le I_\tau(\nu_t)+N\Phi_\tau(\nu_t)
 \le Z(1+N/e)W_t .
\tag{HC5}
\]
此处含 \(N\) 的粗界只验证绝对可积，不作为几何费用。于是
\(\Phi_\tau(\nu_t)+\int_0^tR(\nu_s)ds\) 有准确条件均值合同。
对任意有界死亡历史停时 \(T\)，向上有限网格逼近：相邻网格增量条件均值为零，逐项乘 \(\mathbf1_{\{T>t_j\}}\) 后求和，再用右连续与确定包络取极限。得到
\[
 \boxed{\mathbb E_P\Phi_\tau(\nu_T)
       +\mathbb E_P\int_0^TR(\nu_s)ds=\Phi_\tau(\mu),\qquad
       \mathbb E_PW_T=W_0.}
\tag{HC6}
\]
其中质量等式由无跳增长 \(W\)、总删除补偿 \(\sum_iW_i=W\) 相消，同样用有限网格证明。

若只问固定状态小时间右生成元，小概率两次死亡为 \(O(h^2)\)，TV 稳定性控制死亡后增长误差，准确为
\[
 \mathcal L_P^+\Phi_\tau(\nu)=I_{\tau,\ge}(\nu)-\sum_iD_i(\nu).
\tag{HC7}
\]
故 \(-R\) 是沿真实路径 \(dt\)-几乎处处的精确生成元，平台状态不能省略 (HC7)。

## 4. Q：质量倾斜与归一化的精确余额

在允许无限寿命的规范路径空间，先按 \(w_i/W_0\) 抽原标签 \(J=i\)，令 \(L_J=\infty\)，其余寿命独立 \({\rm Exp}(1)\)。对任何有限时域观察事件 \(F\)，
\[
 Q(F)=\sum_i(w_i/W_0)e^tP(F\cap\{L_i>t\})
     =\mathbb E_P[\mathbf1_FW_t/W_0].
\tag{HC8}
\]
不能预先把整个无限时域的 \(P\)-零事件加入初始滤过。隐藏标签后的真实死亡率为 \(1-q_i\)，其中 \(q_i=W_i/W\)；总率为 \(|A|-1\)。\(Q\) 下永不全灭。

置 \(G_t=\Phi_\tau(\nu_t)/W_t\)，\(r_t=R(\nu_t)/W_t\)。无跳时
\[
 \dot G=(I_\tau-\Phi_\tau)/W\quad dt\text{-a.e.}
\]
删除 \(i\) 的新比值是 \((\Phi_\tau-D_i)/(W-W_i)\)，故其跳漂移总和为
\[
 \sum_i(1-q_i)(G_{\rm after\,i}-G)
    =(\Phi_\tau-\sum_iD_i)/W.
\]
若 \(q_i=1\)，其率为零，该项定义为零；右边该单项也因 \(D_i=\Phi_\tau\) 为零，不使用空来源的 \(0/0\)。合计准确漂移为 \(-r_t\)，平台处右漂移相应使用 \(I_{\tau,\ge}\)。

同一有限补偿／网格证明，或将 (HC6) 用有限停止质量密度与 signed Fubini 改写，给
\[
 \boxed{\frac{\Phi_\tau(\mu)}{W_0}
   =\mathbb E_QG_T+\mathbb E_Q\int_0^Tr_sds}
\tag{HC9}
\]
对每个有界适应 \(T\) 成立。这里
\(\mathbb E_P\int_0^T R\,ds=W_0\mathbb E_Q\int_0^T r\,ds\)，
终端 \(\mathbb E_P\Phi_T=W_0\mathbb E_QG_T\)。\(R\) 不预设非负。

## 5. 无界停止：充分条件和必须保留的尾

对任意停时 \(T\)，首先只有 \(T\wedge h\) 的 (HC6)、(HC9)。终值有限事件上的质量准确满足
\[
 \mathbb E_P[W_T\mathbf1_{\{T<\infty\}}]=W_0Q(T<\infty).
\tag{HC10}
\]
证明先在 \(\{T\le h\}\) 使用有界停止密度，再令 \(h\uparrow\infty\)。仅 \(P(T<\infty)=1\) 不能保证质量守恒。

以下明确充分条件允许无界等式：
\[
 Q(T<\infty)=1,\qquad
 \mathbb E_Q\int_0^T|r_s|ds<\infty .
\tag{HC11}
\]
例如有限 \(N\) 时 \(\mathbb E_QT<\infty\) 由 (HC5) 足以保证第二条，但不是必要条件。因 \(0\le G_t\le Z/e\)，截断终端尾
\(\mathbb E_Q[G_h\mathbf1_{\{T>h\}}]\le(Z/e)Q(T>h)\to0\)；
signed 积分用绝对可积收敛。故
\[
 \frac{\Phi_\tau(\mu)}{W_0}
 =\mathbb E_QG_T+\mathbb E_Q\int_0^Tr_sds,\quad
 \mathbb E_P[\Phi_T\mathbf1_{\{T<\infty\}}]
 =\Phi_\tau(\mu)-\mathbb E_P\int_0^T R\,ds.
\tag{HC12}
\]
后式的 signed P 积分以实际过程解释，其绝对可积性等于
\(W_0\mathbb E_Q\int|r|\)。若另有 \(P(T<\infty)=1\)，可以去掉有限事件限定。条件不成立时保留
\[
 G_0=\mathbb E_Q[G_T\mathbf1_{\{T\le h\}}]
      +\mathbb E_Q[G_h\mathbf1_{\{T>h\}}]
      +\mathbb E_Q\int_0^{T\wedge h}r_sds.
\tag{HC13}
\]
这条尾项不能仅凭 \(P\) 几乎处处终止删除，也不免费宣称全局 class-D。

本稿等式先限定有限 packets。可数 packets 若直接扩展，须另证完整真实删除和的可积补偿及 TV 极限；有限截断的赢家或 \(R\) 不自动逐项一致，不能仅用总质量有限替代这些检查。

## 6. 与 own-packet Γ 的关系；单 packet 诊断

定义固定 packet 的 all-threshold 自身常数
\(\Gamma_i=\sup_{\rho>0}\Phi_\rho(\mu_i)/w_i\)，
\(\overline\Gamma=\sum_iw_i\Gamma_i/W_0\)。
既有 grouped 稿的包络给
\[
 R(\nu_t)\le\sum_{i\in A_t}\Gamma_iW_i(t);
\]
整体补偿系数 \(e^t\) 不改变每个 \(\Gamma_i\)。这只是已证上帽，不替代 signed 等式。

停到一格的 \(T_1\) 满足
\(\mathbb E_Q[T_1\mid J=i]=H_{N-1}\)，因其余 \(N-1\) 个寿命独立指数。终端 \(G_{T_1}\le\Gamma_J\)。标签后验又给
\[
 \mathbb E_Q\int_0^{T_1}\sum_iq_i(s)\Gamma_i\,ds
 =\mathbb E_Q[\Gamma_JT_1]=H_{N-1}\overline\Gamma.
\]
由 (HC12) 仅得比较界
\[
 G_0\le(1+H_{N-1})\overline\Gamma .
\tag{HC14}
\]
输入标签复杂度、packet 自身常数均保留；它不是新的平方根维数界。

更直接地，\(N=1\) 时 \(Q\) 下永生来源 \(\nu_t=e^t\mu\)，准确
\[
 G_t=\Phi_{\tau e^{-t}}(\mu)/W_0,\quad
 r_t=G_t-I_{\tau e^{-t}}(\mu)/W_0 .
\]
令 \(J_\tau=\int\min(M_\mu(x),\tau)\,dx<\infty\)。初等非负积分给
\[
 \int_0^\infty G_tdt=(\Phi_\tau(\mu)+J_\tau)/W_0,\qquad
 \int_0^\infty I_{\tau e^{-t}}(\mu)dt/W_0=J_\tau/W_0.
\]
并且 \(G_t\to0\)：逐点 \(\rho\log_+(M/\rho)\to0\)，由 \(M/e\) 支配。因此有符号绝对可积，且
\[
 \boxed{\int_0^\infty r_tdt=G_0.}
\tag{HC15}
\]
这个完全真实完整来源例表明：即使不出现 \(\Gamma\)，全部未知功能仍可回到运行项。阈值 stationarity \(\Phi_\tau=I_\tau\) 只使 \(r_0=0\)，不使后续全部阈值的 \(r_t\) 为零。它不是弱端点反例，而是余额不自动付款的精确诊断。

## 7. 可验证的剩余接口

统一时钟真正去掉了增长方向的不等式松弛；它不能同时把真实删除差、终端功能和输入标签复杂度消掉。若要独立于 own \(\Gamma\) 获得目标，必须为合法一般分割与真实适应 \(T\) 证明
\[
 \mathbb E_QG_T+\mathbb E_Q\int_0^T r_sds
 \le \sqrt n\,n^{o(1)}
\]
的**另一个几何证书**；不能把 (HC9) 自身改名为证书。可用 Bellman 势，但须核实际死亡转移、signed 运行项与真实终端上帽，保留 E03 的终端余项。尚无这种一般证书。统一来源扰动也不自动继承原 FIRST/fullfuture/CP--GP/LCA/allhistory；本稿没有据此付原 geom 余项。主一般平方根上界仍未解。

## 8. Soft-log 包势与精确抵销缺口

与 nearflat agent 的 [packet_profile_time_budget](packet_profile_time_budget_20261007.md) §1、§5 对接，采用其已经自证的定义
\[
 \Psi_\tau(\sigma)=\tau\int\log(1+M_\sigma/\tau)\,dx,\qquad
 \Gamma_\tau(\sigma)=\tau\int\left[
 \log(1+v)-\frac{v}{1+v}\right]dx,\quad v=M_\sigma/\tau.
\]
这里 \(\Gamma_\tau(\sigma)\) 是真实阈值 profile 费用，**不是** §6 的 all-threshold 常数 \(\Gamma_i\)。
本节仅用已核两条：整包幅度导数为 \(\Psi_\tau-\Gamma_\tau\)，真实整包删除使 \(\Psi_\tau\) 全部消失。因此
\(F=\sum_B\Psi_\tau(\nu_B)\) 在无合并段的原 \(P\) 生成元准确为 \(-\sum_B\Gamma_\tau(\nu_B)\)。

允许有限初始细标签在有限确定刷新及已接受死亡刷新时合并，所有**存活完整组始终统一速率 \(1\)**，不按接收点选率、不复活或分裂；合并瞬间完整当前来源 \(\nu\) 不变。采用 grouped 稿的真实有限历史 law，死亡后再合并；\(D_B\)、\(R=\sum_BD_B-I_\tau\) 作用于当前完整组。每段仍整体增长，故 (HC2)、(HC6) 的等式保持，删除数和合并数均有限。

完整 max 次可加和 soft-log 次可加给
\[
 F\ge\Phi_\tau(\nu),\qquad
 J_{\rm merge}=\sum_{\rm children}\Psi_\tau(\nu_C)
                  -\Psi_\tau\Big(\sum_{\rm children}\nu_C\Big)\ge0.
\]
合并时 \(\Phi_\tau\) 不跳，\(F\) 准确下降 \(J_{\rm merge}\)。以初始组为零时刻预处理完成后的组，以下合并和只计 \(0<s\le T\)。

定义实际缺口与抵销量
\[
 U(\nu,\mathcal B)=F-\Phi_\tau(\nu)\ge0,\qquad
 S(\nu,\mathcal B)=\sum_B\Gamma_\tau(\nu_B)-R(\nu)\ge0.
\tag{HC16}
\]
第二个正性用已经独核的每包 sharp residual 上界
\(D_B-L_B\le\Gamma_\tau(\nu_B)\)，以及
\(\sum_BL_B=I_\tau\)；没有给任意 packet 免费空间小格常数。
两条精确漂移相减，得到
\[
 \mathcal L_P U=-S\quad dt\text{-a.e.},\qquad
 \Delta_{\rm merge}U=-J_{\rm merge}.
\]
平台状态的右生成元是 \(-S-(I_{\tau,\ge}-I_\tau)\)，故同样不能把 a.e. 等式当成所有状态的右导数。
有限 horizon 上 \(0\le F\le ZW\)、\(\Gamma_\tau(\nu_B)\le ZW_B\) 和 (HC5) 验证绝对可积。首死亡补偿及有限网格停止给任意有界 \(T\) 的准确差额恒等
\[
 \boxed{\mathbb E_P\int_0^TS_s\,ds
       +\mathbb E_P\sum_{0<s\le T}J_{\rm merge}(s)
       =U_0-\mathbb E_PU_T.}
\tag{HC17}
\]
这是等式，较非均匀 rates 下的增长下界没有遗漏的非负连续增益。

质量倾斜继续保护 tag 所在**当前整组**，不是合并后仍保留各细标签独立寿命。其密度仍为 \(W_t/W_0\)，当前组死亡率为 \(1-W_B/W\)。有限停止密度在每个合并时刻使用死亡后、合并后的当前 \(W_s\)（合并本身不改质量），准确把 (HC17) 化为
\[
 \boxed{\mathbb E_Q\int_0^T\frac{S_s}{W_s}\,ds
       +\mathbb E_Q\sum_{0<s\le T}
                    \frac{J_{\rm merge}(s)}{W_s}
       =\frac{U_0}{W_0}-\mathbb E_Q\frac{U_T}{W_T}.}
\tag{HC18}
\]
空状态对应项取零；在 \(Q\) 下不存在空状态。可观察有限合并时刻是有界停止时，故这里用其真正停止密度，不对死亡前 tag 后验作冻结。零时刻预处理的 soft-log 下降已包含初始 \(F_0,U_0\)，不再加入合并和。

精确式识别了正帽 \(\sum\Gamma_\tau\) 需要扣除的真实抵销：连续 \(S\)、物理合并 \(J\)、以及未耗尽的终端缺口 \(U_T\)。它没有给 \(U_0\) 一个平方根级上界，也没有证明这些减项与大的初始 \(F_0\) 之间所需的几何比例。把
\(\mathbb E_P\int\sum\Gamma_\tau+\mathbb E_P\sum J=F_0-\mathbb E_PF_T\)
和 (HC17) 相减，恰好返回 (HC6)，不能以此循环宣称付款。该新精确余额仍保留主目标所缺的 quantitative spatial cancellation。
