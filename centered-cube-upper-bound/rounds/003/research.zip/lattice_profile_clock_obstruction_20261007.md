# 有限整数格：单原子正 Γ 图与无合并时钟收费障碍

2026-10-07。结论为指定收费路线的解析障碍：固定真实共捕获图的正 profile 价目为 Θ(n)；进一步，合法无合并／无拆分原子控制若在标签测度 Q 下有限停止并达到空间独立终端，其正 Γ 占用也必为 Θ(n)。这不是主弱型定理的反例，不是原弱型输出量的 Ω(n) 下界，也不排除真实合并、signed slack 或合作终端。

使用 L01 的真实输入／参数归一核对、A02 的正外放松与原目标分离、E03 的终值与跨层费用审计。原下界表 A02–A04 的有限整数格仅提供来源模型参照；本文不复现或增强那些弱型下界。表的来源为 WeChat 暂存《中心立方体_阶段性下界构造总表_20261005 (3).txt》，其中整数格条目并不提供本策略收费结论。

本稿只新增同名前缀文件，未修改旧 tensor 数据、其他代理稿或主 TXT。固定图接口引用 [packet_profile_time_budget_20261007.md](packet_profile_time_budget_20261007.md) §4 (12)–(18)；任意合法自适应控制的独立解析审计见 [adaptive_atomic_clock_count_audit_20261007.md](adaptive_atomic_clock_count_audit_20261007.md) (AA1)–(AA11)。

## 1. 完整来源、闭 cube 图和边界

固定原连续窗口 a=2、b=4、τ=1。Q(x,R) 表示以 x 为中心、全边长 R 的闭 cube。对 n≥4 取

\[
 L=16n,\qquad \mu=\sum_{z\in[-L,L]^n\cap\mathbb Z^n}\delta_z,
 \qquad W=N=(32n+1)^n.
\]

这是所有坐标的完整有限张量积、每个不同原子质量为 1，不截掉边界，也不用无限格替代。两个不同格点被某个 Q(x,4) 同时捕获，当且仅当 \(\|z-z'\|_\infty\le4\)：必要性逐坐标成立，充分性取两点中点。距离恰为 4 的面保留；这一步需要闭 cube。

固定图采用这全部真实边。内层 \([-L+4,L-4]^n\cap\mathbb Z^n\) 有 \(I=(32n-7)^n\) 个原子，每个内层顶点的全部偏移 \(\{-4,\ldots,4\}^n\setminus\{0\}\) 均在完整来源里，故度数恰为 \(d=9^n-1\)。内层比例满足

\[
 \frac IN=\left(1-\frac8{32n+1}\right)^n
 \ge1-\frac{8n}{32n+1}
 =\frac{24n+1}{32n+1}>\frac34.
\tag{1}
\]

不需要计算边界顶点的精确度数；其正费用非负，丢弃它们仅降低下界。

## 2. 全空间单原子 profile 的准确公式

令 \(H=M_{[2,4]}(m\delta_z)\)，\(G(v)=\log(1+v)-v/(1+v)\)，\(\Gamma_1(m\delta_z)=\int G(H(x))dx\)。径向体积变量 \(t=(2\|x-z\|_\infty)^n\) 给 core 体积 \(2^n\)、shell 体积微分 dt。因此

\[
 \Gamma_1(m\delta_z)
 =2^nG(m/2^n)+\int_{2^n}^{4^n}G(m/t)dt.
\]

由 \(\frac d{dt}[t\log(1+m/t)]=G(m/t)\)，准确得到

\[
 r(s):=\frac{\Gamma_1(e^s\delta_z)}{e^s}
 =\frac{\log(1+e^s/4^n)}{e^s/4^n}
   -\frac1{1+e^s/2^n}\ge0.
\tag{2}
\]

平移不改变此式。非负性可由 \(\log(1+u)/u\ge1/(1+u)\) 以及 \(e^s/2^n\ge e^s/4^n\) 直接检查。

选择幅度 band

\[
 s_-=(n+2)\log2,\quad s_+=(2n-2)\log2,\quad
 s_+-s_-=(n-4)\log2.
\tag{3}
\]

在整个闭 band，\(u=e^s/4^n\le1/4\)、\(V=e^s/2^n\ge4\)。初等不等式 \(\log(1+u)\ge u-u^2/2\) 给

\[
 r(s)\ge 1-\tfrac18-\tfrac15=\tfrac{27}{40}.
\tag{4}
\]

n=4 时 band 长度为零；正的线性障碍用于 n>4。此处不是拟合数值 profile。

## 3. 固定图：真实局部标签 law 与 Θ(n) 价目

使用已核 fixed graph 政策：尚存且有尚存邻居的原子以速率 1 增长并同速率死亡；孤立原子永久冻结；不合并。原 P 过程与质量倾斜／保护标签的 Q 过程不同。Q 的初始标签 J 在 N 个原子中均匀；给定 J，每个初始邻居因 tag 尚存而持续 active 至自身死亡，独立寿命 Exp(1)。因此标签局部累计活动量为

\[
 A_J=\max_{1\le j\le d_J}E_j,
 \quad Q(A_J>s\mid J)=1-(1-e^{-s})^{d_J}=:T_{d_J}(s).
\tag{5}
\]

A_J 不是原 P 下原子寿命，也不是全局日历停止时 T。度数零时 A=0。该图政策的原 P 停止质量 UI 和 Q 终止已在引用稿 (11)–(14) 给出，不能从形式质量守恒直接推断。

记 \(k(s)=\Phi_1(e^s\delta)/e^s\)、\(\psi(s)=\Psi_1(e^s\delta)/e^s\)。引用稿定义的实际正价目为

\[
 C_{\mathrm{graph}}/W
 =\frac1N\sum_J\left\{E_Q[k(A_J)\mid J]
       +\int_0^\infty T_{d_J}(s)r(s)ds\right\}.
\tag{6}
\]

这是终值 own-profile 加正 Γ 占用的策略收费；它是原 \(\Phi_1(\mu)/W\) 的上帽，不等于原目标。

对于内层 d=9^n−1，令 p=e^{-s}。在 band，\(p\ge4/4^n\)、\(dp\ge1\)。由 \((1-p)^{-d}\ge1+dp\)（p=1 时以极限解释），

\[
 T_d(s)\ge\frac{dp}{1+dp}\ge\frac12.
\tag{7}
\]

全部项非负，结合 (1)、(3)、(4)，

\[
 \boxed{\quad C_{\mathrm{graph}}/W
 \ge\frac{81}{320}(n-4)\log2.\quad}
\tag{8}
\]

\(\psi'=-r\)、\(0\le k\le\psi\) 给
\(E k(A)+E\int_0^A r\le\psi(0)\)。原窗口的单原子 L¹ 包络准确为
\(\int M_{[2,4]}\delta=1+\log(4^n/2^n)=Z=1+n\log2\)，且 \(\Psi_1(\delta)\le Z\)。故

\[
 C_{\mathrm{graph}}/W\le Z=1+n\log2.
\tag{9}
\]

所以该固定单原子正图路线的完整价目为 Θ(n)。它无法在这个来源族上给出一致 \(\sqrt n\,n^{o(1)}\) 收费。

## 4. 更强解析扩展：合法自适应无合并控制

此节单独登记，不替换固定图模型。允许原子随已接受死亡历史及可观察政策种子自适应选率 \(a_i(t)\in[0,1]\)，幅度增长率和接受死亡率相同；只用已核有限时域、有限确定刷新及接受死亡刷新 law。不允许政策观察未来辅助 marks、拒绝 proposal 或隐藏 tag；不在此推广到未经构造的无限刷新控制。没有合并、拆分、复活或标签位置移动。

\(A_i(t)\) 为原子累计本地活动量，存活质量 \(m_i(t)=e^{A_i(t)}\)。对同一历史停时 T，假设 \(Q(T<\infty)=1\)，且每个有限终态的任一 Q(x,4) 至多含一个存活原子。若资格仅 Q-a.s. 给出，有限时域的 \(W_T/N\) 密度可把违反 count 的有限事件转回 P；全灭路径自动满足 count。

对给定保护 tag i 的有限停止密度
\(dQ_i/dP=e^{A_i(S)}\mathbf1_{i\mathrm{alive}}\)，取 \(S=T\wedge h\)，配对变量 \(e^{-A_i(S)}\mathbf1_{T\le h}\)，得到准确身份

\[
 E_Q[e^{-A_J(T)}\mathbf1_{T\le h}]
 =\frac1N E_P[N_T\mathbf1_{T\le h}].
\tag{10}
\]

初始 tag 均匀，当前存活 tag 后验为 \(m_i/W_t\)，一般不均匀。两边非负单调收敛及 Q 终止给

\[
 E_Qe^{-A_J(T)}=\frac1N E_P[N_T\mathbf1_{T<\infty}].
\tag{11}
\]

不假设 P(T<∞)=1，不使用 P 停止质量 UI；右侧只解释真实有限停止路径。

每条坐标的 M=32n+1 个整数按连续至多 5 点分块。每个乘积块的坐标跨度至多 4，容于一个真实闭 Q(x,4)，所以终态活点数至多

\[
 k=\lceil M/5\rceil^n\le (M/4)^n=N4^{-n}.
\tag{12}
\]

逐坐标界由 \(\lceil M/5\rceil\le(M+4)/5\le M/4\)（M≥16）给出，保留来源边界。由 (11) 和 Markov，

\[
 Q(A_J(T)>s)\ge[1-(k/N)e^s]_+\ge3/4
 \quad(s\in[s_-,s_+]).
\tag{13}
\]

原 P 下真正的正 Γ 占用满足有限时域密度及非负 Tonelli 身份

\[
 \mathcal G/W
 :=\frac1N E_P\int_0^T\sum_{i\ \mathrm{alive}}a_i(t)
            \Gamma_1(m_i(t)\delta_i)dt
 =E_Q\int_0^{A_J(T)}r(s)ds.
\tag{14}
\]

中间按真实当前后验换测度，再沿 tag 的累计活动量换元；长零速率段允许存在。由 (4)、(13)，

\[
 \boxed{\quad \frac{81}{160}(n-4)\log2
 \le\mathcal G/W
 \le\int_0^\infty r(s)ds=\Psi_1(\delta)\le1+n\log2.\quad}
\tag{15}
\]

上界不需要 P 终态 UI。这样在该来源和合法独立终端控制类中，正 Γ 占用本身必为 Θ(n)，不是只指出某个图上帽估计粗糙。真正 signed 费用可能减去 \(\delta_B=\Gamma_B-(D_B-L_B)\)；完整来源合并也会产生真实 \(J_{\rm merge}\)。这些空间信用不被 (15) 下界约束，见引用 profile 稿 (21)–(28)。

## 5. 一次执行的三轮精确守卫

预注册文件为 [lattice_profile_clock_obstruction_20261007_registration.json](lattice_profile_clock_obstruction_20261007_registration.json)，代码为 [lattice_profile_clock_obstruction_20261007.py](lattice_profile_clock_obstruction_20261007.py)。一次执行内按固定顺序 n=8、32、128，分别使用 16、32、64 项 \(\log2\) 有理区间。没有展开巨大格点、图、CDF 幂，没有 maxquery、输出抽样或随机模拟，也没有参数搜索。

令
\[
 \ell_K=2\sum_{j=0}^{K-1}\frac1{(2j+1)3^{2j+1}},\qquad
 0<\log2-\ell_K
 \le\frac9{4(2K+1)3^{2K+1}}.
\tag{16}
\]

这是 \(2\operatorname{atanh}(1/3)\) 正项展开；余项以首个剩余分母和比率 1/9 的几何级数控制。全部报告断言使用整数／Fraction，数值 display 字段只供阅读。每轮保存完整有限来源的压缩描述、精确 N= W、I、d、内层比例、band 幅度端点、tail 下界、terminal packing k、ln2 区间和全部检查。

| 轮次 | n | ln2 项数 | 固定图正价目下界（显示值） | 自适应正 Γ 占用下界（显示值） | 精确检查 |
|---|---:|---:|---:|---:|---:|
| 1 | 8 | 16 | 0.701811520317 | 1.40362304063 | 14/14 PASS |
| 2 | 32 | 32 | 4.91268064222 | 9.82536128444 | 14/14 PASS |
| 3 | 128 | 64 | 21.7561571298 | 43.5123142597 | 14/14 PASS |

显示值不是实际收费的点估计：每个值是解析统一下界常数乘 band 长度的区间显示。json 中 lower/upper 是该下界表达式的有理包络，不是对完整收费的双边求积。上帽 Z 另行保存。三轮只有维度扩展与预定 ln2 加密，不用于拟合阶数。

执行 exit 0，elapsed 0.001364 秒；Python 绝对路径及代码、注册、全部结果 SHA256 保存于 [lattice_profile_clock_obstruction_20261007_receipt.json](lattice_profile_clock_obstruction_20261007_receipt.json)。来源 descriptor SHA 指压缩完整模型的 canonical JSON，不冒充展开原子数组的 hash。所有精确计数由有限张量积公式给出。

## 6. 范围与保留问题

本结果否定的是以单原子为固定包、到空间独立终端并把 Γ 正费不带减项收取的 \(\sqrt n\,n^{o(1)}\) 一般路线。固定图给 (8)；更强自适应 no-merge 版本给 (15)。不涉及软 FIRST、nearmax、gate、原 tensor 样本，也不把当前有限格来源的实际弱输出声明为 residual。

目前没有证明所有空间分组或 signed 信用都失败。一般 cube 弱(1,1) 的目标尚未由本文解决；一般 O(n log n) baseline 不被这次策略收费审计改变。
