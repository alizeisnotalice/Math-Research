"""Frozen finite-J full-space homogeneous thinning generator audit.

New surviving-source maxima only; old oracle/main/MC are never executed.
"""
from fractions import Fraction as F
from pathlib import Path
from collections import defaultdict, Counter
from math import prod, lcm
import ast
import argparse
import datetime
import gzip
import hashlib
import json
import time

BASE = Path(__file__).resolve().parent
PREFIX = "homogeneous_clock_generator_guard_20261007"
OLD = "log_max_variation_probe_20261007"
PS = [F(1, 2), F(1, 4), F(1, 16)]
HELPER = BASE / "spatial_packet_collision_probe_20261007.py"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()


def save(path, obj):
    with Path(path).open("x") as handle:
        json.dump(obj, handle, indent=2, sort_keys=True)
        handle.write("\n")


names = ["outward", "atanh_log_interval", "log_interval", "log_plus_interval"]
selected = [node for node in ast.parse(HELPER.read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name in names]
assert [node.name for node in selected] == names
tree = ast.Module(body=selected, type_ignores=[])
AST_SHA = hashlib.sha256(ast.dump(tree, include_attributes=False).encode()).hexdigest()
namespace = {"F": F, "LOG_BITS": 192, "LOG_TERMS": 100, "UNIT": 2 ** 192}
exec(compile(tree, str(HELPER), "exec"), namespace)
namespace["LOG_TWO"] = namespace["atanh_log_interval"](F(2))
namespace["LOG_CACHE"] = {F(1): (F(0), F(0)), F(2): namespace["LOG_TWO"]}
log_interval = namespace["log_interval"]


def add(coefs, arg, coef):
    assert arg > 1
    if coef:
        coefs[arg] = coefs.get(arg, F(0)) + coef
        if not coefs[arg]:
            del coefs[arg]


def combine(target, source, factor=F(1)):
    for arg, coef in source.items():
        add(target, arg, factor * coef)


def expression(coefs, constant=F(0)):
    lo = hi = constant
    for arg, coef in sorted(coefs.items()):
        low, high = log_interval(arg)
        lo += coef * (low if coef > 0 else high)
        hi += coef * (high if coef > 0 else low)
    assert lo <= hi
    return {"constant": str(constant),
            "signed_log_coefficients": [{"argument": str(a), "coefficient": str(c)} for a, c in sorted(coefs.items())],
            "interval": [str(lo), str(hi)],
            "sign": "exact_zero" if lo == hi == 0 else "strict_negative" if hi < 0 else "strict_positive" if lo > 0 else "unresolved"}


def physical_packets(source):
    locations = defaultdict(list)
    for j, point in enumerate(source["atoms"]):
        locations[tuple(map(F, point))].append(j)
    weights = list(map(F, source["weights"]))
    return [{"index": i, "position": list(map(str, point)), "labels": labels,
             "weight": str(sum((weights[j] for j in labels), F(0)))}
            for i, (point, labels) in enumerate(sorted(locations.items()))]


def geometry(path):
    data = json.loads(gzip.decompress(Path(path).read_bytes()))
    source = {key: data["input"][key] for key in ["n", "atoms", "weights", "J", "tau"]}
    n, tau = source["n"], F(source["tau"])
    scales = list(map(F, source["J"]))
    atoms = [list(map(F, y)) for y in source["atoms"]]
    weights = list(map(F, source["weights"]))
    assert sum(weights) == 1 and all(w > 0 for w in weights)
    assert scales == sorted(set(scales)) and scales[0] == 1
    packets = physical_packets(source)
    cuts = [sorted({y[i] + sign * R / 2 for y in atoms for R in scales for sign in [-1, 1]}) for i in range(n)]
    maps = [{(axis[i], axis[i + 1]): i for i in range(len(axis) - 1)} for axis in cuts]
    expected = prod(len(axis) - 1 for axis in cuts)
    assert expected == len(data["cells"])
    signatures, patterns, cells, seen = {}, [], [], set()
    for idx, cell in enumerate(data["cells"]):
        bounds = [tuple(map(F, pair)) for pair in cell["cell_bounds"]]
        key = tuple(maps[i][pair] for i, pair in enumerate(bounds))
        assert key not in seen
        seen.add(key)
        volume = F(cell["volume"])
        assert volume == prod((right - left for left, right in bounds), start=F(1))
        assert all(left < F(x) < right for (left, right), x in zip(bounds, cell["midpoint"]))
        signature = tuple(tuple(js) for js in cell["full_capture_labels_by_scale"])
        if signature not in signatures:
            pid = len(patterns)
            signatures[signature] = pid
            masses = [sum((weights[j] for j in js), F(0)) for js in signature]
            response = [m / R ** n for m, R in zip(masses, scales)]
            M, R = F(cell["M"]), F(cell["winner_R"])
            win = scales.index(R)
            assert list(map(str, masses)) == cell["full_mass_by_scale"]
            assert list(map(str, response)) == cell["full_response_by_scale"]
            assert response[win] == M and all(v <= M for v in response)
            assert win == next(j for j, v in enumerate(response) if v == M)
            assert cell["E"] == (M > tau) and cell["threshold_plateau"] == (M == tau)
            masks = []
            for js in signature:
                captured = set(js)
                mask = 0
                for packet in packets:
                    group = set(packet["labels"])
                    assert not (group & captured) or group <= captured
                    if group <= captured:
                        mask |= 1 << packet["index"]
                masks.append(mask)
            patterns.append({"id": pid, "capture_labels_by_J": [list(js) for js in signature],
                             "captured_physical_packet_mask_by_J": masks,
                             "original_mass_by_J": list(map(str, masses)),
                             "original_response_by_J": list(map(str, response)),
                             "original_M": str(M), "original_winner_R": str(R),
                             "original_winner_tie_count": cell["maximum_tie_count"],
                             "Lebesgue_volume": F(0), "cell_count": 0})
        pid = signatures[signature]
        assert patterns[pid]["original_M"] == cell["M"] and patterns[pid]["original_winner_R"] == cell["winner_R"]
        patterns[pid]["Lebesgue_volume"] += volume
        patterns[pid]["cell_count"] += 1
        cells.append({"original_cell_index": idx, "bounds": cell["cell_bounds"], "volume": str(volume),
                      "midpoint": cell["midpoint"], "pattern_id": pid})
    assert len(seen) == expected
    volume = sum((row["Lebesgue_volume"] for row in patterns), F(0))
    assert volume == prod((axis[-1] - axis[0] for axis in cuts), start=F(1))
    for row in patterns:
        row["Lebesgue_volume"] = str(row["Lebesgue_volume"])
    return {"source": source, "physical_packets": packets, "J": source["J"],
            "coordinate_cuts": [list(map(str, axis)) for axis in cuts],
            "support_rectangle": [[str(axis[0]), str(axis[-1])] for axis in cuts],
            "support_rectangle_volume": str(volume), "patterns": patterns, "cells": cells,
            "coverage_complete": True,
            "state_response_rule": "For state mask A, retain these physical packets at full weight/p. State-pattern file stores unscaled masses and responses; divide by p for current nu_A. Winner/ties unchanged by this common positive scaling."}


def register():
    old_receipt = BASE / (OLD + "_receipt.json")
    receipt = json.loads(old_receipt.read_text())
    plans = []
    for n in [1, 2, 3]:
        path = BASE / f"{OLD}_n{n}_cell_profiles.json.gz"
        assert digest(path) == receipt["file_sha256"][path.name]
        geom = geometry(path)
        N = len(geom["physical_packets"])
        plans.append({"n": n, "N": N, "states": 1 << N,
                      "cells": len(geom["cells"]), "patterns": len(geom["patterns"]),
                      "input_profile": {"path": str(path), "sha256": digest(path)},
                      "source": geom["source"], "source_sha256": hashlib.sha256(canonical(geom["source"])).hexdigest(),
                      "physical_packets": geom["physical_packets"]})
    save(BASE / (PREFIX + "_registration.json"), {
        "status": "registered_before_new_subset_maxima", "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "script_sha256": digest(__file__), "plans": plans, "p": list(map(str, PS)),
        "old_receipt": {"path": str(old_receipt), "sha256": digest(old_receipt)},
        "helper": {"path": str(HELPER), "sha256": digest(HELPER), "selected_AST_sha256": AST_SHA,
                   "outward_bits": 192, "atanh_terms": 100},
        "source": "Coalesce coincident labels into physical packets; each current state nu_A=p^-1 sum_{i in A} mu_i, no renormalization; common original J and tau frozen.",
        "states": "Every surviving subset including empty; probability p^k(1-p)^(N-k), exactly normalized. No Monte Carlo or new seeds.",
        "winner": "All original finite J candidates, exact Fraction response, smallest-R ties. Cache unscaled winner per state-pattern; positive common 1/p scaling is exact.",
        "platform": "Along increasing t=-log p fixed-state amplitude grows. I_strict=tau|M>tau| is left drift derivative. Right drift derivative adds B=tau|M=tau|. Save plateau cells/volume and both sides. -E R_strict equals the formal left generator; true right generator and differentiated expectation both add E B.",
        "identity": "R_A=sum_{i in A}(Phi_A-Phi_{A-i})-I_A. Compare -sum Prob R_A with sum Prob [I_A+(Np-k)/(1-p)Phi_A] by exact signed-log coefficient/constant cancellation, separately add identical right plateau correction.",
        "storage": "Full source/packets/cells/patterns in geometry; every state-pattern unscaled J mass/response/max/winner/tie saved in streaming gzip JSONL; each p/state full Phi,I,B,D,R,probability saved in gzip JSON; both sides and differences saved in results.",
        "interval": "Audited positive atanh log with explicit tail; signed rational coefficients merged before interval evaluation, negative coefficient endpoints reversed; unresolved signs retained.",
        "budget": {"state_patterns": sum(x["states"] * x["patterns"] for x in plans),
                   "state_p_integrals": 3 * sum(x["states"] for x in plans),
                   "scale_responses": sum(x["states"] * x["patterns"] * len(x["source"]["J"]) for x in plans)},
        "stopping": "One complete fixed pass n1,n2,n3 and three p values; no data-dependent stop/tuning; no old oracle/main calls.",
        "scope": "Exact finite common-J full-space homogeneous clock generator components; not continuous window, general source/adaptive control theorem, nearmax, or dimension-order evidence."})
    print(json.dumps({"registration_sha256": digest(BASE / (PREFIX + "_registration.json")), "plans": [{k: x[k] for k in ['n','N','states','patterns']} for x in plans]}), flush=True)


def gzip_write(path, obj):
    with path.open("xb") as raw:
        with gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0) as out:
            out.write(canonical(obj))


def process(plan):
    geom = geometry(plan["input_profile"]["path"])
    source = geom["source"]
    assert hashlib.sha256(canonical(source)).hexdigest() == plan["source_sha256"]
    n, N, K = plan["n"], plan["N"], plan["states"]
    weights = list(map(lambda x: F(x['weight']), geom['physical_packets']))
    den = lcm(*(w.denominator for w in weights))
    units = [int(w * den) for w in weights]
    powers = [F(R) ** n for R in geom["J"]]
    tau = F(source["tau"])
    phi = [[{} for _ in range(K)] for _ in PS]
    I = [[F(0) for _ in range(K)] for _ in PS]
    B = [[F(0) for _ in range(K)] for _ in PS]
    ecells = [[0 for _ in range(K)] for _ in PS]
    plateaucells = [[0 for _ in range(K)] for _ in PS]
    stateweight = [F(0)] * K
    for mask in range(1, K):
        bit = mask & -mask
        stateweight[mask] = stateweight[mask ^ bit] + weights[bit.bit_length()-1]
    outcome_path = BASE / f"{PREFIX}_n{n}_state_patterns.jsonl.gz"
    with outcome_path.open("xb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as out:
            for pattern in geom["patterns"]:
                pid = pattern["id"]
                area, cellcount = F(pattern["Lebesgue_volume"]), pattern["cell_count"]
                cap = pattern["captured_physical_packet_mask_by_J"]
                allmass = [[0] * len(powers) for _ in range(K)]
                maximum = [F(0)] * K
                for mask in range(K):
                    if mask:
                        bit = mask & -mask
                        index = bit.bit_length() - 1
                        allmass[mask] = [v + (units[index] if cmask & bit else 0) for v, cmask in zip(allmass[mask ^ bit], cap)]
                    response = [F(v * power.denominator, den * power.numerator) for v, power in zip(allmass[mask], powers)]
                    M = max(response)
                    maximum[mask] = M
                    win = next(j for j, v in enumerate(response) if v == M)
                    if mask == K-1:
                        assert str(M) == pattern["original_M"] and geom["J"][win] == pattern["original_winner_R"]
                    for index in range(N):
                        if mask & (1 << index):
                            assert maximum[mask ^ (1 << index)] <= M
                    row = {"state_mask": mask, "pattern_id": pid,
                           "unscaled_mass_by_J": [str(F(v, den)) for v in allmass[mask]],
                           "unscaled_response_by_J": list(map(str, response)), "unscaled_M": str(M),
                           "winner_R": geom["J"][win], "winner_tie_count": sum(v == M for v in response),
                           "zero_response": M == 0}
                    out.write(canonical(row) + b"\n")
                    for ip, p in enumerate(PS):
                        Mp = M / p
                        if Mp > tau:
                            add(phi[ip][mask], Mp / tau, tau * area)
                            I[ip][mask] += tau * area
                            ecells[ip][mask] += cellcount
                        elif Mp == tau:
                            B[ip][mask] += tau * area
                            plateaucells[ip][mask] += cellcount
                print(json.dumps({"n":n,"pattern_done":pid+1,"total_patterns":len(geom['patterns'])}),flush=True) if (pid+1)%200==0 else None
    geometry_path = BASE / f"{PREFIX}_n{n}_geometry.json.gz"
    gzip_write(geometry_path, geom)
    state_tables, summaries = [], []
    for ip, p in enumerate(PS):
        prob = [p ** mask.bit_count() * (1-p) ** (N-mask.bit_count()) for mask in range(K)]
        assert sum(prob) == 1
        expected_source_mass = sum((prob[mask] * stateweight[mask] / p for mask in range(K)), F(0))
        assert expected_source_mass == 1
        generator, differentiate = {}, {}
        genconst = derconst = correction = F(0)
        positive, negative = {}, {}
        posconst = negconst = F(0)
        signs = Counter()
        records = []
        for mask in range(K):
            Rmap = {}
            Ds = []
            for index in range(N):
                if mask & (1 << index):
                    loss = dict(phi[ip][mask])
                    combine(loss, phi[ip][mask ^ (1 << index)], -F(1))
                    combine(Rmap, loss)
                    Ds.append({"removed_packet_index": index, "child_state_mask": mask ^ (1 << index), "D": expression(loss)})
            R = expression(Rmap, -I[ip][mask])
            signs[R['sign']] += 1
            if R['sign'] == 'strict_positive':
                combine(positive, Rmap, prob[mask]); posconst -= prob[mask]*I[ip][mask]
            elif R['sign'] == 'strict_negative':
                combine(negative, Rmap, prob[mask]); negconst -= prob[mask]*I[ip][mask]
            combine(generator, Rmap, -prob[mask]); genconst += prob[mask]*I[ip][mask]
            factor = (N*p-mask.bit_count())/(1-p)
            combine(differentiate, phi[ip][mask], prob[mask]*factor)
            derconst += prob[mask]*I[ip][mask]
            correction += prob[mask]*B[ip][mask]
            records.append({"state_mask":mask,"alive_packet_indices":[i for i in range(N) if mask&(1<<i)],
                            "alive_count":mask.bit_count(),"probability":str(prob[mask]),
                            "original_surviving_mass":str(stateweight[mask]),"current_source_mass":str(stateweight[mask]/p),
                            "Phi":expression(phi[ip][mask]),"I_strict_left_drift":str(I[ip][mask]),
                            "platform_B_right_correction":str(B[ip][mask]),
                            "E_cells":ecells[ip][mask],"plateau_cells":plateaucells[ip][mask],
                            "deletions":Ds,"R_strict":R,
                            "R_right":expression(Rmap,-I[ip][mask]-B[ip][mask])})
        residual = dict(generator); combine(residual,differentiate,-F(1))
        assert not residual and genconst == derconst
        leftres = expression(residual,genconst-derconst)
        rightres = expression(residual,genconst+correction-derconst-correction)
        summary={"n":n,"N":N,"p":str(p),"states":K,"probability_sum":"1",
                 "expected_current_source_mass":str(expected_source_mass),
                 "fee_state_sign_counts":dict(signs),"platform_states":sum(b>0 for b in B[ip]),
                 "platform_state_cell_pairs":sum(plateaucells[ip]),
                 "expected_platform_right_correction":str(correction),
                 "left_generator_minus_ER":expression(generator,genconst),
                 "left_Bernoulli_distribution_derivative":expression(differentiate,derconst),
                 "right_generator":expression(generator,genconst+correction),
                 "right_Bernoulli_distribution_derivative":expression(differentiate,derconst+correction),
                 "left_identity_residual":leftres,"right_identity_residual":rightres,
                 "exact_coefficient_identity_pass":True,
                 "expected_positive_R_contribution":expression(positive,posconst),
                 "expected_negative_R_contribution_signed":expression(negative,negconst),
                 "sign_unresolved_states":signs['unresolved']}
        state_tables.append({"p":str(p),"records":records,"summary":summary})
        summaries.append(summary)
        print(json.dumps({"done_n":n,"p":str(p),"states":K,"platform_states":summary['platform_states'],"sign_counts":dict(signs)}),flush=True)
    states_path = BASE / f"{PREFIX}_n{n}_states.json.gz"
    gzip_write(states_path,{"n":n,"source":source,"physical_packets":geom['physical_packets'],"states_by_p":state_tables})
    return summaries,[{"path":str(x),"sha256":digest(x)} for x in [geometry_path,outcome_path,states_path]]


def run():
    start=time.monotonic()
    regpath=BASE/(PREFIX+'_registration.json')
    reg=json.loads(regpath.read_text())
    assert reg['script_sha256']==digest(__file__)
    assert reg['helper']['sha256']==digest(HELPER) and reg['helper']['selected_AST_sha256']==AST_SHA
    summaries=[];files=[]
    for plan in reg['plans']:
        assert digest(plan['input_profile']['path'])==plan['input_profile']['sha256']
        s,f=process(plan);summaries.extend(s);files.extend(f)
    resultpath=BASE/(PREFIX+'_results.json')
    save(resultpath,{"status":"complete","summaries":summaries,"profiles":files,
                     "elapsed_seconds":time.monotonic()-start,"registration_sha256":digest(regpath),
                     "script_sha256":digest(__file__),"old_oracle_calls":0,"main_runs":1,
                     "scope":reg['scope'],"platform_convention":reg['platform'],"budget":reg['budget']})
    receiptpath=BASE/(PREFIX+'_receipt.json')
    save(receiptpath,{"status":"complete","exit_status":0,"main_runs":1,"old_oracle_calls":0,
                      "script":{"path":str(Path(__file__)),"sha256":digest(__file__)},
                      "registration":{"path":str(regpath),"sha256":digest(regpath)},
                      "results":{"path":str(resultpath),"sha256":digest(resultpath)},
                      "input_profiles":[x['input_profile'] for x in reg['plans']],"profiles":files,
                      "scope":reg['scope']})
    print(json.dumps({"results_sha256":digest(resultpath),"receipt_sha256":digest(receiptpath)}),flush=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['register','run'])
    register() if parser.parse_args().mode=='register' else run()
