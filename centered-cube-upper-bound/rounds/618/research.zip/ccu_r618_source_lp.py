import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,hashlib,json,platform,resource,shlex,sys,time
from fractions import Fraction as F
from math import lcm
from pathlib import Path
import numpy as np,scipy
from scipy.optimize import linprog

def jr(q):return [q.numerator,q.denominator]
def run(r):
 n=r['n']; sel=r['selected_records'];assert sel
 # Coordinates and radii are quarter units. Strict condition ensures [-1/4,1/4]^n is inside each a-star.
 assert all(max(map(abs,z[1:-1]))+1<8*z[0] for z in sel)
 den=lcm(*[(16*R)**n for R in (8,6,4)]);assert r['N']*den < (2**63)*(8**n)
 lo=np.array([[int(v)-8*z[0] for v in z[1:-1]] for z in sel],dtype=np.int16); hi=np.array([[int(v)+8*z[0] for v in z[1:-1]] for z in sel],dtype=np.int16)
 edges=[np.unique(np.concatenate((lo[:,k],hi[:,k]))) for k in range(n)];shape=tuple(len(e) for e in edges); diff=np.zeros(shape,dtype=np.int64)
 low=[np.searchsorted(edges[k],lo[:,k]) for k in range(n)]; high=[np.searchsorted(edges[k],hi[:,k]) for k in range(n)];weight=np.array([z[-1]*(den//(16*z[0])**n) for z in sel],dtype=np.int64)
 for mask in range(1<<n):
  coords=tuple(high[k] if mask&(1<<k) else low[k] for k in range(n)); np.add.at(diff,coords,(-1 if mask.bit_count()%2 else 1)*weight)
 for k in range(n):np.cumsum(diff,axis=k,out=diff)
 cells=diff[tuple(slice(None,-1) for _ in range(n))]; maxload=int(np.max(cells)); idx=np.unravel_index(int(np.argmax(cells)),cells.shape)
 witness=[[int(edges[k][idx[k]]),int(edges[k][idx[k]+1])] for k in range(n)]
 volumes=np.array([(4*z[0])**n for z in sel],dtype=float); maxvol=int(max(volumes)); lp=linprog([1.],A_ub=-np.ones((len(sel),1)),b_ub=-volumes,bounds=(0,None),method='highs')
 if not lp.success or abs(lp.fun-maxvol)>1e-7*maxvol:raise RuntimeError('LP verification failed: '+lp.message)
 small=F(sum(z[-1] for z in sel),4**n); total_weight=F(int(weight.sum()),den); maxW=F(maxload,den); C=1+F(35,24)**n/F(*r['tau'])
 return {'n':n,'tau':r['tau'],'N':r['N'],'seed':r['seed'],'selected_sha256':r['selected_sha256'],'selected_count':len(sel),'status':'complete','max_star_volume_exact':maxvol,'common_box':'[-1/4,1/4]^n contained strictly in every selected a-star','source_lp_fun':lp.fun,'source_lp_status':lp.status,'source_lp_message':lp.message,'small_union_exact':jr(small),'small_union_over_minmass':jr(small/maxvol),'Ccov_times_small_union_over_minmass':jr(C*small/maxvol),'W_at_x0_exact':jr(total_weight),'global_max_W_exact':jr(maxW),'global_max_W_witness_cell_quarter_units':witness,'star_face_grid_shape':shape,'star_face_cells':int(np.prod(np.array(shape)-1)),'note':'union is selected small cubes only; no supplied-cube coverage is inferred'}
def main():
 p=argparse.ArgumentParser();p.add_argument('--input',type=Path,default=Path('/tmp/ccu_r616_final/selection.json'));p.add_argument('--output-dir',type=Path,default=Path('/tmp'));a=p.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
 raw=a.input.read_bytes();obj=json.loads(raw); results=[]; start=time.monotonic()
 out={'input':str(a.input),'input_sha256':hashlib.sha256(raw).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'workers':1,'blas_threads':1,'estimated_peak_memory_bytes':650*1024**2,'lp_proof':'Any constraint gives mass >= volume; one nonnegative density on the common source box of total mass max_j volume satisfies all constraints. This is the exact all-incidence L1 LP, not a restricted-column bound.','max_W_proof':'all star face cells are enumerated implicitly by integer range-add arrays and prefix sums; open-star boundary values cannot exceed adjacent interior cell loads','results':results}
 def save():
  out['elapsed_seconds']=time.monotonic()-start;out['peak_rss_bytes_macos']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
  (a.output_dir/'ccu_r618_source_lp.json').write_text(json.dumps(out,indent=2))
  L=['# R618 actual-star source covering LP','',f"Input SHA256 `{out['input_sha256']}`; script SHA256 `{out['script_sha256']}`.",f"Command `{out['command']}`; Python {sys.version}; NumPy {np.__version__}; SciPy {scipy.__version__}; one process, BLAS1; elapsed {out['elapsed_seconds']:.3f}s; peak RSS {out['peak_rss_bytes_macos']/2**20:.2f} MiB.",'','Every selected a-star strictly contains the same open source box. The total source mass must be at least the largest star volume, and a density supported in the common box attains that bound. Thus the full L1 covering LP has min mass exactly max_j |aB_j|; no incidence columns are omitted. Each exact value was also checked with a one-variable HiGHS LP. This is a structural consequence of the given generated family, not a general result for arbitrary selections.','','W(0) and global max W use exact rational weights. The global maximum is found by evaluating all open face-cell loads via integer range-add and prefix sums. Small union is the union of selected small cubes, not all supplied cubes. Ccov=1+(35/24)^n/τ.','','| n | τ | N | seed | selected | min mass | selected-small union/min mass | Ccov × union/min mass | W(0) | max W |','|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
  def fmt(q):return '%.8g'%float(F(*q))
  for r in results:L.append('| %d | %d/%d | %d | %d | %d | %d | %s | %s | %s | %s |'%(r['n'],*r['tau'],r['N'],r['seed'],r['selected_count'],r['max_star_volume_exact'],fmt(r['small_union_over_minmass']),fmt(r['Ccov_times_small_union_over_minmass']),fmt(r['W_at_x0_exact']),fmt(r['global_max_W_exact'])))
  L+=['','These finite families all share a common point by construction, so the LP conclusion does not establish improvement for general star families or a dimension-dependent weak-type constant.']
  (a.output_dir/'ccu_r618_source_lp.md').write_text('\n'.join(L)+'\n')
 cases=sorted(obj['results'],key=lambda r:(r['N'],r['n'],r['seed'],r['tau']))
 for r in cases:
  try:results.append(run(r))
  except Exception as e:results.append({'status':'error','n':r['n'],'seed':r['seed'],'tau':r['tau'],'N':r['N'],'error':repr(e)}); save();break
  save();print('done',len(results),r['n'],r['tau'],r['N'],r['seed'],flush=True)
 save()
if __name__=='__main__':main()
