# R618：由坐标 incidence 和真实新增体积构造饱和冻结 packing

**结果。** 得到一个完全显式、有限可计算的 star packing 权机制。它逐项支配按全局点态帽缩放 `w_j` 的权，甚至逐项支配局部帽权；完整 source/receiver 比值可直接检验。没有证明一般根阶。该机制不先求解 source LP，也不对 f 加密度帽。

## 1. 实际对象与候选公式

令 `A_j=aB_j` 为同一次实际 selection 的 bad stars，`v_j=|I_j|` 为实际不交小 cube increments，`d_j=v_j/|A_j|=w_j`。只保留 `v_j>0` 的项。定义

`W(x)=Σ_j d_j 1_{A_j}(x)`, `M=ess sup W`,
`L_j=ess sup_{x∈A_j}W(x)`。

每个坐标按全部 stars 的端点分割，取所得全维开矩形 cells。其 incidence `M_hj=1_{cell h⊂A_j}` 固定；遗漏的面是 Lebesgue 零测。这里使用全部 receiver incidence，不只研究一个共同接收点。

构造共同 clock 的饱和冻结过程：初始 `λ_j=0`、活动集 F 为全部正增量 stars；活动 j 的增长速率为 d_j。当前 cell load 为 `ell_h=Σ_jM_hjλ_j`，活动速率为 `q_h=Σ_{j∈F}M_hj d_j`。下一阶段取

`Δ=min_{h:q_h>0}(1−ell_h)/q_h`，
`λ_j←λ_j+Δd_j` 对所有活动 j；冻结所有覆盖任一新饱和 cell (`ell_h=1`) 的活动 stars。冻结项此后不再增长，继续至活动集为空。

每一阶段至少冻结一项，故不超过正增量 star 数个阶段。所有输入坐标与 v_j 有理时，过程可全用精确有理数实现。维数高时 cell 数可以大；本结果不偷偷假设任意来源具有多项式复杂度。

## 2. 严格可行性与优于点态帽的下界

每阶段先到最紧的 cell，因此更新后全部 loads 仍≤1。一个 cell 饱和时，所有覆盖它的活动 stars 均被冻结，因此此后该 cell 不再增长。于是最终

`Σ_j λ_j 1_{A_j}(x) <=1` a.e.                         (P1)

令 t_j 为 j 冻结的 clock，则准确有 `λ_j=d_j t_j`。冻结时某个覆盖 j 的 cell h 满足

`1=Σ_{k:cell h⊂A_k}d_k min(t_j,t_k)`
` <=t_j Σ_{k:cell h⊂A_k}d_k <=t_j L_j`。

所以逐项得到

`λ_j>=d_j/L_j>=d_j/M`。                              (P2)

局部帽权本身可行，因为对 x∈A_j 有 L_j≥W(x)，故 `Σ_j(d_j/L_j)1_Aj(x)<=1`。冻结构造进一步自动利用相邻区域余下的容量，不再用最拥挤的 receiver 统一压低所有 stars。

完整 packing 目标为

`Q_freeze=Σ_j λ_j|A_j|=Σ_j v_j t_j`
` >=Σ_j v_j/L_j>=V/M`,  `V=Σ_jv_j`。                 (P3)

这不是另一个仅证明交集缩小的 witness 预算；(P1) 对整个 receiver/source 空间成立。它也不保证最优 packing，或固定比例接近最优。

## 3. 完整 source 与 cover 付款

设所有实际 selected stars 对同一个非负 L1 输入满足 `∫_{A_j}f>η|A_j|`。将各式乘固定的 λ_j 再相加，使用 (P1)，严格得到

`ηQ_freeze < ∫ f Σ_jλ_j1_Aj <=||f||_1`。             (P4)

λ_j 在整次 selection 上固定，不随接收点或来源另选。未把 increments 的体积当成 f 质量。

记 R 为全部 supplied 小 cubes 的 union 体积。若直接算出 R，有限几何比值是

`K_actual=R/Q_freeze`。

若仅使用 R616 已证 cover，则 `R<=C_cov V`，所以可直接使用

`K_cover=C_cov V/Q_freeze`,
`C_cov=1+A_a/τ`, `A_a=(1+1/t+1/a)^n`。              (P5)

τ 必须保留。证明一般根阶仍需统一估计 `Q_freeze>=R/(C sqrt(n)polylog(n))`，或更强的 `Q_freeze>=C_cov V/(C sqrt(n)polylog(n))`。当前没有此定量结论。局部帽改进本身不构成维数指数改进。

## 4. 已实际核验的机制与可继续测试的量

本机数学 venv Python `Fraction` 精确运行一个实际可选出的三 cube 例：n=1，a=8，t=3，τ=1/4；半径全为1，中心为0、1、100；按此顺序实际 increments 为2、1、2。精确检查每个入选中心的严格开捕获负载≤τ。全部正长度 receiver cells 上输出

`λ=(2/3,1/3,1)`, `Q_freeze=32`,

而全局点态帽仅给 `V/M=80/3`。这说明同一实际几何上存在严格收益；不是一般 n 估计。

已把候选公式与(P1)–(P5)分别发送独立 audit 与 general_terra。后者在已有12个非公共交实例的完整二维 cell incidence 上完成浮点诊断，见 `/tmp/ccu_r618_freeze_existing.md` 和同名 JSON：Q_freeze 与所列 selected-source LP 上端之比约0.692–0.9997，K_actual约0.146–0.499，保留正确 τ 的 K_cover约1.158–2.296。浮点权留了可行裕量，非有理证书；这12案没有拒选，不能代表困难 selection，更不能外推维数。

下一项有效检验是：在真正存在拒选和多尺度竞争的实际 supplied 家族上，固定所有 receiver incidence，计算 t_j、Q_freeze、完整(P5)，同时和已获其他 packing 比较。若多数体积在很早冻结的 stars 上，该机制可能仍停留在旧点态帽量级；必须量化实际 increments 能否限制这种早冻结体积，不能只报告最大 load≤1或一部分 λ 变大。

**停止结论。** 本次交付的是无额外来源假设、完整可收费、可直接测试的权机制及其局部/全局帽支配证明；没有新的 C_n 上界、根阶定理或参数扫描。
