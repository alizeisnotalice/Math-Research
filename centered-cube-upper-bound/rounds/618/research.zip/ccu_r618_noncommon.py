import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,math,platform,resource,shlex,sys,time,random
from fractions import Fraction as F
from pathlib import Path
import numpy as np,scipy
from scipy.optimize import linprog

CONFIGS=[{'clusters':[[-90,0],[90,0]],'spread':18,'tau':[1,4],'weights':[1,1,1]}, {'clusters':[[-110,0],[110,0]],'spread':36,'tau':[1,1],'weights':[1,2,3]}, {'clusters':[[-110,-55],[110,-55],[0,110]],'spread':24,'tau':[1,4],'weights':[3,2,1]}, {'clusters':[[-125,-60],[125,-60],[0,120]],'spread':36,'tau':[1,1],'weights':[1,1,2]}, {'clusters':[[-110,-110],[-110,110],[110,-110],[110,110]],'spread':18,'tau':[1,4],'weights':[1,2,1]}, {'clusters':[[-125,-100],[-125,100],[125,-100],[125,100]],'spread':34,'tau':[1,1],'weights':[2,3,1]}]
def fq(x):return str(F(x))
def sample(cfg,N,seed):
 rng=random.Random(seed);seen=set(); seq=[]
 while len(seq)<N:
  R=rng.choices([8,6,4],weights=cfg['weights'])[0]; c=rng.choice(cfg['clusters']);y=(c[0]+rng.randint(-cfg['spread'],cfg['spread']),c[1]+rng.randint(-cfg['spread'],cfg['spread']));z=(R,*y)
  if z not in seen:seq.append(z);seen.add(z)
 return [v for _,v in sorted(enumerate(seq),key=lambda p:(-p[1][0],p[0]))]
def selection(seq,tau):
 N=len(seq);C=np.array([z[1:] for z in seq],np.int16);den=147456 # lcm(128^2,96^2,64^2)
 assert den==math.lcm(128**2,96**2,64**2)
 lower=C.min(axis=0)-8;upper=C.max(axis=0)+8; shape=tuple((upper-lower).tolist());covered=np.zeros(shape,bool);allcover=np.zeros(shape,bool);load=np.zeros(N,np.int64);sel=[]
 for i,(R,x,y) in enumerate(seq):
  ix=slice(int(x-R-lower[0]),int(x+R-lower[0]));iy=slice(int(y-R-lower[1]),int(y+R-lower[1]));allcover[ix,iy]=True
  if int(load[i])*tau.denominator>tau.numerator*den:continue
  block=covered[ix,iy];cells=block.size-int(block.sum());block[:]=True;sel.append((R,x,y,cells));w=cells*(den//(16*R)**2)
  if w and i+1<N:
   ds=3*np.abs(C[i+1:].astype(np.int32)-C[i].astype(np.int32));load[i+1:]+=np.all(ds<32*R,axis=1)*w
 return sel,int(allcover.sum()),int(covered.sum())
def lp(seq,deadline):
 n=len(seq);arr=np.array(seq,dtype=np.int64);R=arr[:,0];XY=arr[:,1:3];lo=XY-8*R[:,None];hi=XY+8*R[:,None]
 edges=[np.unique(np.concatenate((lo[:,k],hi[:,k]))) for k in range(2)]; grid=(len(edges[0])-1,len(edges[1])-1)
 lows=np.stack([np.searchsorted(edges[k],lo[:,k]) for k in range(2)],axis=1);highs=np.stack([np.searchsorted(edges[k],hi[:,k]) for k in range(2)],axis=1)
 centers=np.stack([np.clip(np.searchsorted(edges[k],XY[:,k],side='right')-1,0,grid[k]-1) for k in range(2)],axis=1)
 # One guaranteed covering column per star, deduplicated while retaining mapping.
 points=[];pointmap={};own=[]
 for pt in centers:
  k=tuple(map(int,pt))
  if k not in pointmap:pointmap[k]=len(points);points.append(k)
  own.append(pointmap[k])
 def mat(points):
  pp=np.array(points,dtype=int);return ((lows[:,0,None]<=pp[None,:,0])&(pp[None,:,0]<highs[:,0,None])&(lows[:,1,None]<=pp[None,:,1])&(pp[None,:,1]<highs[:,1,None]))
 def pricing(w):
  diff=np.zeros((grid[0]+1,grid[1]+1),dtype=w.dtype);a,b=lows[:,0],lows[:,1];c,d=highs[:,0],highs[:,1]
  np.add.at(diff,(a,b),w);np.add.at(diff,(c,b),-w);np.add.at(diff,(a,d),-w);np.add.at(diff,(c,d),w)
  np.cumsum(diff,axis=0,out=diff);np.cumsum(diff,axis=1,out=diff);view=diff[:-1,:-1];idx=np.unravel_index(int(np.argmax(view)),view.shape);return view[idx],tuple(map(int,idx))
 volumes=(4*R)**2; solution=None; dual=None; iterations=0; reason=''
 while time.monotonic()<deadline:
  A=mat(points);sol=linprog(np.ones(len(points)),A_ub=-A.astype(float),b_ub=-volumes,bounds=(0,None),method='highs',options={'time_limit':max(0.1,deadline-time.monotonic())});iterations+=1
  if not sol.success:reason=sol.message;break
  solution=sol.x;dual=np.maximum(-sol.ineqlin.marginals,0);v,idx=pricing(dual)
  if v<=1+1e-8:reason='pricing tolerance reached';break
  if idx in pointmap:reason='numerical duplicate pricing column';break
  pointmap[idx]=len(points);points.append(idx)
 if solution is None: return {'status':'error','reason':reason,'star_count':n}
 # If final loop added a column without a fresh solve discard it before certification.
 points=points[:len(solution)];A=mat(points)
 scale=1<<30;pr=np.ceil(np.maximum(solution,0)*scale).astype(np.int64)
 covered=A.astype(np.int64)@pr
 for i in range(n):
  lack=int(volumes[i])*scale-int(covered[i])
  if lack>0:
   col=own[i];pr[col]+=lack;covered+=A[:,col].astype(np.int64)*lack
 assert np.all(covered>=volumes*scale)
 D=1<<40; dy=np.floor(dual*D).astype(np.int64);v,_=pricing(dy);denden=max(D,int(v));lower=F(int(dy@volumes),denden);upper=F(int(pr.sum()),scale)
 assert lower<=upper
 source=[]
 for j in np.flatnonzero(pr):
  ix,iy=points[int(j)];source.append([fq(F(int(edges[0][ix]),4)),fq(F(int(edges[0][ix+1]),4)),fq(F(int(edges[1][iy]),4)),fq(F(int(edges[1][iy+1]),4)),fq(F(int(pr[j]),scale))])
 stars=[[fq(F(int(lo[i,0]),4)),fq(F(int(hi[i,0]),4)),fq(F(int(lo[i,1]),4)),fq(F(int(hi[i,1]),4))] for i in range(n)]
 return {'status':'complete' if reason=='pricing tolerance reached' else 'bounded','reason':reason,'star_count':n,'face_grid_cells':int(grid[0]*grid[1]),'columns':len(points),'iterations':iterations,'dual_lower':fq(lower),'primal_upper':fq(upper),'relative_gap':float((upper-lower)/upper),'stars':stars,'cells':source,'dual_candidates':[fq(F(int(y),denden)) for y in dy],'pricing_integer_max':int(v),'pricing_denominator':denden,'max_star_volume':int(max(volumes))}
def task(pair):
 ci,N=pair;cfg=CONFIGS[ci];seed=61800+ci;start=time.monotonic();startcpu=time.process_time();deadline=start+110;seq=sample(cfg,N,seed);lo=np.array([[x-8*R,y-8*R] for R,x,y in seq]);hi=np.array([[x+8*R,y+8*R] for R,x,y in seq]);assert np.any(lo.max(axis=0)>=hi.min(axis=0))
 sel,allcells,selcells=selection(seq,F(*cfg['tau'])); all_lp=lp(seq,deadline);sel_lp=lp([z[:3] for z in sel],deadline)
 return {'case':ci,'N':N,'seed':seed,'config':cfg,'status':'complete','all_count':N,'selected_count':len(sel),'supplied_small_union':fq(F(allcells,16)),'selected_small_union':fq(F(selcells,16)),'V_sum':fq(F(sum(z[-1] for z in sel),16)),'Ccov_V':fq((1+F(35,24)**2/F(*cfg['tau']))*F(sum(z[-1] for z in sel),16)),'supplied_records':seq,'selected_records':sel,'all_source_lp':all_lp,'selected_source_lp':sel_lp,'elapsed_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-startcpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--skip-first',action='store_true');ap.add_argument('--case',type=int,default=-1);ap.add_argument('--N',type=int,choices=[256,1024],default=256);ap.add_argument('--workers',type=int,default=1);ap.add_argument('--output-dir',type=Path,default=Path('/tmp'));args=ap.parse_args();args.output_dir.mkdir(parents=True,exist_ok=True);assert 1<=args.workers<=12
 pairs=[(args.case,args.N)] if args.case>=0 else [(i,N) for N in (256,1024) for i in range(6)];pairs=[x for x in pairs if not(args.skip_first and x==(0,256))];start=time.monotonic();results=[]
 meta={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'workers':args.workers,'cases':results}
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
  for f in concurrent.futures.as_completed({pool.submit(task,pair):pair for pair in pairs}):
   try:r=f.result();results.append(r);print('complete',r['case'],r['N'],r['all_source_lp']['relative_gap'],flush=True)
   except Exception as e:results.append({'status':'error','error':repr(e)});print('error',repr(e),flush=True)
   meta['elapsed_seconds']=time.monotonic()-start;(args.output_dir/'ccu_r618_noncommon.json').write_text(json.dumps(meta))
if __name__=='__main__':main()
