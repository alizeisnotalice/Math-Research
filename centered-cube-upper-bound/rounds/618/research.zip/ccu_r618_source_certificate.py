import argparse,json,sys,time,hashlib,platform,resource
from pathlib import Path
from fractions import Fraction as Q
from bisect import bisect_left
start=time.perf_counter();cpu=time.process_time()
p=argparse.ArgumentParser();p.add_argument('--input',type=Path);p.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'ccu_r618_source_certificate.json');p.add_argument('--self-test',action='store_true');args=p.parse_args();assert args.self_test != bool(args.input)
if args.self_test:
 data={'stars':[[0,2,0,1],[1,3,0,1]],'source_cells':[[1,2,0,1,2]],'dual_candidates':['0.5','0.5']}
else:data=json.loads(args.input.read_text())
def rect(r):
 x0,x1,y0,y1=map(Q,r);assert x0<x1 and y0<y1;return x0,x1,y0,y1
stars=[rect(r) for r in data['stars']]; assert stars
cells=[(*rect(r[:4]),Q(r[4])) for r in (data['source_cells'] if 'source_cells' in data else data['cells'])];assert cells and all(c[4]>=0 for c in cells)
def area(r): return (r[1]-r[0])*(r[3]-r[2])
def intersect(r,s):return max(Q(0),min(r[1],s[1])-max(r[0],s[0]))*max(Q(0),min(r[3],s[3])-max(r[2],s[2]))
# Fixed decimal denominator, downward rounded positive candidate; candidates must be nonnegative.
D=10**9; candidates=[Q(str(x)) for x in data['dual_candidates']];assert len(candidates)==len(stars) and all(x>=0 for x in candidates)
nums=[v.numerator*D//v.denominator for v in candidates]
xs=sorted({z for r in stars for z in r[:2]});ys=sorted({z for r in stars for z in r[2:]}); nx=len(xs);ny=len(ys)
# A deliberately conservative cell limit controls peak memory on this machine.
assert nx*ny<=350000, 'grid exceeds conservative memory limit'
grid=[[0]*ny for _ in range(nx)]
for (x0,x1,y0,y1),v in zip(stars,nums):
 i=bisect_left(xs,x0);j=bisect_left(xs,x1);k=bisect_left(ys,y0);l=bisect_left(ys,y1)
 grid[i][k]+=v;grid[j][k]-=v;grid[i][l]-=v;grid[j][l]+=v
M=0
for i in range(nx):
 for j in range(ny):
  grid[i][j]+=(grid[i-1][j] if i else 0)+(grid[i][j-1] if j else 0)-(grid[i-1][j-1] if i and j else 0)
  if i<nx-1 and j<ny-1:M=max(M,grid[i][j])
scale=max(D,M);dual=[Q(v,scale) for v in nums];lower=sum((v*area(r) for v,r in zip(dual,stars)),Q())
cover=[sum((mass*intersect(r,c)/area(c) for c in cells for mass in [c[4]]),Q()) for r in stars]
assert all(v>0 for v in cover),'source misses a positive-area star'
source_scale=max([Q(1)]+[area(r)/v for r,v in zip(stars,cover)]);upper=source_scale*sum((c[4] for c in cells),Q())
assert all(source_scale*v>=area(r) for r,v in zip(stars,cover)) and lower<=upper
f=lambda x:[str(x.numerator),str(x.denominator)]
out={'input_sha256':None if args.self_test else hashlib.sha256(args.input.read_bytes()).hexdigest(),'self_test':args.self_test,'stars':len(stars),'source_cells':len(cells),'grid_shape':[nx-1,ny-1],'grid_points':nx*ny,'candidate_denominator':D,'candidate_numerators':[str(v) for v in nums],'max_integer_grid_load':str(M),'dual_denominator':str(scale),'dual_weights':[f(v) for v in dual],'dual_lower':f(lower),'source_coverage_before_scaling':[f(v) for v in cover],'source_scaling':f(source_scale),'source_upper':f(upper),'gap':f(upper-lower),'runtime':{'python':sys.version,'sys_executable':sys.executable,'platform':platform.platform(),'command_argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'finite stars, positive-volume endpoint cells, piecewise-uniform source rectangles; no solver optimality claim'}
if args.self_test:assert lower==upper==2
args.output.write_text(json.dumps(out,indent=2)+'\n')
print('stars',len(stars),'grid',nx-1,ny-1,'lower',lower,'upper',upper,'gap',upper-lower,'sha256',out['script_sha256'])
