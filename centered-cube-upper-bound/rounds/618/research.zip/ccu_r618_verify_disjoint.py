#!/usr/bin/env python3
"""Verify 12 finite source-LP disjoint-star certificates using exact fractions, no solver."""
import argparse,json,hashlib
from pathlib import Path
from fractions import Fraction as F

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify(noncommon,rejection,cert):
 refs={(r['case'],r['N']):r for r in noncommon['cases']};certs={(r['case'],tuple(r['tau'])):r for r in cert['cases']};out=[]
 assert len(rejection['results'])==12 and len(certs)==12
 for case in rejection['results']:
  k=(case['case'],tuple(case['config']['tau']));c=certs[k];ref=refs[(case['case'],1024)]
  supplied=[tuple(map(int,z)) for z in ref['supplied_records']];chosen=[tuple(map(int,z)) for z in c['selected_pairwise_disjoint_maximum_stars_quarter_units']]
  selected={tuple(map(int,z[:3])) for z in case['selected_records']}
  assert len(chosen)==len(set(chosen)) and set(chosen)<=selected and selected<=set(supplied)
  for j,(R,x,y) in enumerate(chosen):
   assert R==max(z[0] for z in supplied)
   for S,u,v in chosen[:j]:assert abs(x-u)>=8*(R+S) or abs(y-v)>=8*(R+S),('overlap',k)
  dual=sum((F((4*R)**2) for R,_,_ in chosen),F())
  cells=[[F(v) for v in z] for z in c['all_source_primal_cells']];assert all(a<b and c<d and m>=0 for a,b,c,d,m in cells)
  primal=sum((z[4] for z in cells),F())
  for R,x,y in supplied:
   xmin=F(x-8*R,4);xmax=F(x+8*R,4);ymin=F(y-8*R,4);ymax=F(y+8*R,4)
   mass=sum((m for a,b,c,d,m in cells if xmin<=a and b<=xmax and ymin<=c and d<=ymax),F())
   assert mass >= F((4*R)**2),('infeasible source',k,(R,x,y),mass)
  assert dual==primal==F(c['selected_dual_lower'])==F(c['all_source_primal_upper'])
  out.append({'case':k[0],'tau':list(k[1]),'all_count':len(supplied),'selected_count':len(selected),'disjoint_count':len(chosen),'exact_mass':str(primal)})
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--noncommon',type=Path,default=Path(__file__).parent/'ccu_r618_noncommon_combined.json');p.add_argument('--rejection',type=Path,default=Path(__file__).parent/'ccu_r618_rejection.json');p.add_argument('--certificate',type=Path,default=Path(__file__).parent/'ccu_r618_rejection_disjoint.json');p.add_argument('--output',type=Path);a=p.parse_args()
 files=(a.noncommon,a.rejection,a.certificate);data=[json.loads(f.read_text()) for f in files];out={'verified':verify(*data),'input_sha256':{str(f):digest(f) for f in files},'script_sha256':digest(Path(__file__)),'method':'exact Fraction validation; disjoint selected dual and source feasible for every supplied star; no solver'}
 if a.output:a.output.write_text(json.dumps(out,indent=2))
 print(json.dumps({'status':'verified','case_count':len(out['verified']),'exact_masses':[z['exact_mass'] for z in out['verified']],'input_sha256':out['input_sha256']},indent=2))
if __name__=='__main__':main()
