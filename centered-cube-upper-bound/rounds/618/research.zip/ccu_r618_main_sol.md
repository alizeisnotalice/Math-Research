# R618：全来源最小质量、精确 packing 对偶与共同来源分组机制

范围：只读 R617 指定文件，研究实际有限 greedy 家族。未读新的数值候选，未做反例或参数扫描，未修改其他文件。结论是精确量词与对偶、一个确实支付完整来源的定量几何机制，以及尚未获得根阶的新几何命题；没有一般维数新界。

## 1. 原问题必须先固定哪些 bad-star 约束

记实际 selected stars 为 A_j=aB_j，d_j=|A_j|，v_j=|I_j|，Vtot=Σ_jv_j=|∪selected B_j|。固定 η>0。研究

  m_sel(η)=inf{∫f:f≥0，f∈L¹，∫_{A_j}f≥ηd_j 对所有 selected j}。

原始 f 满足这些约束，故 ||f||₁≥m_sel。若加入全部 supplied stars 的约束，得到 m_all≥m_sel。selected-only 原问题是原始全供给 bad-star 约束的放松；其最小化输入未必使原来 rejected/supplied stars 仍为 bad。不能把 m_sel 与整个原超水平集的最佳输入直接等同。

令 U=∪全部 supplied小立方体、Ceff=|U|/Vtot。R616 给 Ceff≤1+A_a/τ。因此以下任一个几何下界都足够支付该有限接收账：

  m_sel≥η|U|/K_n，或等价地 m_sel≥ηCeff Vtot/K_n。    (1)

仅证明 m_sel≥ηVtot/K_n，还需支付 Ceff。通过全部 supplied 约束直接证明 m_all≥η|U|/K_n也是合法的另一条路径，可避免先把完整 receiver 简化成 Ceff Vtot。这里不把(1)本身重命名成新进展。

## 2. 连续 L¹、有限 cell 和 Borel 原子的精确等价

所有 A_j 是有限个、正体积、有界的开轴平行立方体。用它们各坐标的全部边界超平面切分；保留并集内的正体积 full-dimensional 开矩形 cells C。边界零测且每个 cell 上全部 membership 常数。令 M_jC=1_{C⊂A_j}，z_C=∫_C f。则

  m_sel=min_{z_C≥0}{Σ_C z_C:Σ_C M_jC z_C≥ηd_j ∀j}。  (2)

一方面任何 L¹ 来源给这样的 cell mass；另一方面任意有限可行 z 可由每个 cell 上密度 z_C/|C| 的函数实现。可行集非空，例如 f=η1_{∪A_j}；最优值有限且达到，因为可限制于一个紧的总质量次水平集。

其强 packing 对偶为

  m_sel=max_{λ_j≥0}{ηΣ_j λ_jd_j:Σ_jλ_j1_{A_j}(x)≤1 a.e.}。
                                                               (3)

这是有限 LP 的强对偶，最优亦达到；每个 A_j 含某个正体积 cell，故可行 λ_j≤1。

若原问题允许任意有限非负 Borel μ，最优值仍等于(2)，不会因来源集中到边界而降低。原因有两种等价表述：

- λ≥0且 A_j 开，所以 Σλ_j1_{A_j} 下半连续；若在某点>1，就在一个正测开邻域>1。因此 a.e. 对偶约束自动处处成立，亦可对原子 μ 积分。
- 任一点 x 的全部正 membership 的交是包含 x 的开集。将该点质量均匀摊入其中一个小球，保留所有原有正约束；额外进入其他 A_j 只会帮助原问题。有限 membership 模型足以实现同值。

这个结论依赖开 stars 与非负约束。不能对任意闭集合直接宣称“a.e. 对偶可约束原子”。

若要求严格 bad：∫_{A_j}f>ηd_j，则将(2)的最优函数乘1+ε即可。因此严格模型的 inf 与 m_sel相同；通常不再宣称这个 inf 在严格可行域达到。上述 equivalence 没有把一般来源限制为乘积输入。

## 3. 一个确实可支付来源的定量机制：共同交分组

### 3.1 单个共同来源簇的精确成本

取一组 selected indices G，假设其 stars 有共同点 z。令 R=max_{j∈G}r_j，并取达到 R 的代表 j_G。对所有 y∈B_j，

  ||y−z||∞≤||y−y_j||∞+||y_j−z||∞<(a+1)r_j≤(a+1)R。

所以真实 disjoint increments 直接给

  Σ_{j∈G}v_j≤[2(a+1)R]^n=P d_{j_G}，
  P=((a+1)/a)^n。                                  (4)

若全部约束属于一个共同交簇，则 m_sel=ηmax_jd_j：下界由最大 star 的单个约束给出，上界把质量 ηmax d_j 放入共同开交盒即可。因此(4)给 ηVtot≤P m_sel。即使 W 在共同来源处很大，真正最小来源成本仍由最大的 star 而不是点态 max W 决定。

### 3.2 全局分组与真实 packing 证书

若 selected indices 可分成上述共同交 groups G_ℓ，取各自最大 star 代表 j_ℓ，并且这些代表 stars 的全空间重数满足

  Σ_ℓ1_{A_{j_ℓ}}≤D  a.e.，                         (5)

则给每个代表 λ=1/D（重复代表时合并权）是(3)的真实可行解。由(4)，

  m_sel≥(η/D)Σ_ℓd_{j_ℓ}≥ηVtot/(PD)。              (6)

因此完整 R616 receiver 上界是 K_n=Ceff P D。这里 D 是代表 stars 的全来源重数，不能用选入时中心 priorload 代替，也不能在不同接收点分别选代表后免费合并。

若对全部 supplied stars 做这样的分组，则直接有 |U|≤PΣ_ℓd_{j_ℓ}，从而 m_all≥η|U|/(PD)，无需再付 Ceff。此处真实机制是共同来源簇的增量/receiver体积压缩，以及全局代表 packing；它不要求点态 W 根阶。

### 3.3 可无条件完成的粗版本，及根阶究竟缺哪一步

对任意有限 stars 家族，按半径从大到小选 pairwise-disjoint stars 为代表，并把每个未选 star 分配给一个与其相交、半径不小于它的代表。若代表半径 R、被分配项半径 r≤R，则

  B_j⊂B(y_rep,(2a+1)R)。

故该组小-cube receiver 并集体积≤(2+1/a)^n d_rep。代表 stars 不交，λ_rep=1 已对偶可行。于是对全部供给家族有真正无条件的来源下界

  m_all≥η|U|/(2+1/a)^n。                           (7)

对 selected-only 则是 m_sel≥ηVtot/(2+1/a)^n，完整 receiver还乘 Ceff。(7)只是粗的指数阶几何机制，不是新维数改善。

由(4)–(7)清楚定位新的强几何命题：需要把“与一个大 star 相交”的指数体积付费，替换成共同来源簇或更一般的分数分组，并同时保持代表 packing 的全局拥挤可控。一个具体、足够强但本轮未证明的命题是：实际 greedy 家族存在共同交分组，使 Ceff P D≤sqrt(n)polylog(n)；若使用全部供给约束，则需 PD≤sqrt(n)polylog(n)。该整数分组命题只是一个较强充分条件，并非根阶定理必需的唯一形式。

实际 eligibility 只控制 selected centers 的此前加权捕获，(5)控制任意来源位置的代表重数；两者目前没有已证的根阶联系。仅说代表平均重数小、或每个局部 suffix 的 cap 小，均不足以推出(5)。本轮没有跨过这个缺口。

## 4. 与 R617 γ 证书的准确关系

先令 R617 的几何 gap Qgap=0。定义

  B0=min_{γ_j≥0, Σγ_j=Vtot}
        ||Σ_jγ_j1_{A_j}/d_j||∞。

由(3)准确有

  B0=ηVtot/m_sel。                                 (8)

证明：γ 给出 λ_j=γ_j/(B0d_j)，是 packing 可行且其 objective=ηVtot/B0。反过来，对最优 λ，令 S=Σλ_jd_j=m_sel/η，取 γ_j=Vtot λ_jd_j/S，则总量Vtot，核重数≤Vtot/S。这说明 Qgap=0 的全局 γ 重分配和完整 source LP 是同一个有限几何优化的两种归一，不能把两者分别算作两项收益。

R617 实际证书含 Qgap=Ubound−W≥0，目标是

  Qgap+Σγ_j1_{A_j}/d_j≤B。

它在(8)的 packing 上多付一个 receiver gap；其最优 B≥B0。来源 LP 直接使用每个 bad-star 条件，不需要先引入 cap 外放松及其 Qgap，所以可比先估 W 再重分配更尖锐。但必须真的证明(3)有足够大的几何 objective，LP强对偶本身不提供根阶增长。

## 5. 最终 centered maximal 入口的 P 因子

若 f 仅满足 A_j 上平均≥η，则对任意 x∈B_j，

  A_j⊂Q(x,(a+1)r_j)，故 M_nf(x)≥η/P。              (9)

因此一个最小来源实验的 η|∪B_j|/m 值，若用于构造真正 weak-type 下界候选，必须除以 P；严格超水平可将来源或水平微调。全 supplied receiver 要求全 supplied bad-star 约束；selected-only 最小来源只保证 selected receiver 的(9)。不能直接把实验比值叫 weak constant。

R616 的上界入口没有额外 P 损失：最初 K 已属于 {M_nf>η}，每个供给中心有其真实 bad-star，小 cubes 仅用来有限覆盖 K。于是 K⊂U，而 ηΣv_j来自 selected stars 的原真实 η-bad 条件；证明更强的 η|U|≤K_n||f||₁即可控制η|K|。这里既没有声称 U⊂{Mf>η}，也没有将来源 LP 的下界实验偷换为上界。

共同交 profiles 的 m=ηmax d、maxW发生在共同来源处，均属其几何结构的必然结果。这类测试只能说明共同来源极限下 LP 不能省掉最大 star 的成本，不能显示多个非共同交来源簇的 packing 收益，更不能检验全 receiver 的根阶重分配。下一步全局设计应保留非共同交 source incidence、全 supplied 与 selected-only 的差别及实际 receiver 几何，不能再用共同交数据验证一个面向分散来源的主张。进一步，若所谓 noncommon profile 只是若干相互分离的共同交簇，LP仍逐块分解，准确有 m=ηΣ_簇 max_j d_j；拒选本身不改变这个来源结构事实。它不能充当复杂全局证据。

## 6. 证据与停止点

本机既有研究 venv 的 SymPy实际检查了 γ_j=Vtot λ_jd_j/Σλd 的总量归一与 B0·m_sel=ηVtot 的代数，残差为0。没有运行新source实例或数值扫描；LP等价、开集原子处理和(4)–(9)的严格证明均显示在上文。

本轮达到：精确量词、有限等价、真实 packing证书、共同交簇的 P 成本与完整全局分组收费机制。未达到：由真实 greedy eligibility 建立根阶的全来源分组/分数 packing 下界。停止继续分配或扩大局部帽。避免有限-family循环的下一决策应先固定一个可证伪的全局几何引理及其全部维数费用，例如由实际 eligibility 构造(5)的代表或分数替代并证明其拥挤界；有限LP只用于核这个具体引理的量词或发现缺项。没有这样的统一命题时，继续优化有限来源质量既不证明 exponent，也不构成下一轮主任务。真正非平凡的来源测试至少要有同一个连通 overlap 结构中的多个交叠cliques、整体没有共同交，而不能仅将互不相交的共同交块并排。此处不要求继续做测试；下一项有内容的证明必须在该全局几何缺口上推进。
