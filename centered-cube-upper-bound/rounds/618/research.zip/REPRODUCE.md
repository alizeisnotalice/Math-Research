# Reproduction and scope
Use the recorded math-research Python interpreter. No PDF compilation is needed.

Strict saved-instance replay (no optimizer, no resampling):

```
python ccu_r618_verify_disjoint.py --noncommon ccu_r618_noncommon_combined.json --rejection ccu_r618_rejection.json --certificate ccu_r618_rejection_disjoint.json --output replay.json
python ccu_r618_source_certificate.py --input ccu_r618_noncommon_case0_certificate.json --output first_replay.json
```

The first replay was actually run by both Terra and the main agent; all 12 cases passed. The second was run by the independent certificate agent. Main/bridge proof details are retained alongside REPORT.tex and the independent audit. Resource records describe actual runs, not a claim of continuous CPU saturation.

The initial 36-case script requires selection.json from round 616 research.zip; its SHA is recorded in source_lp.json. Do not duplicate or regenerate that selection. Running the saved numerical batches is optional: noncommon.py --case i --N 256/1024 --output-dir DIR; rejection.py --input ccu_r618_noncommon_combined.json --output-dir DIR --workers N. They preserve their original module names. Use a separate output directory to avoid overwriting archived evidence. Code was corrected after an omitted tau factor was found; saved original run hashes intentionally need not equal corrected code hashes. Corrections change derived cover costs, not solver inputs or source certificates.

Floating freeze diagnostics are distinct from exact source certificates. Original extensive freeze outputs are reduced to their necessary summary; the freeze implementation is in rejection.py. No dimension extrapolation is justified by these finite profiles. The generic weak-type target remains open in this work.
