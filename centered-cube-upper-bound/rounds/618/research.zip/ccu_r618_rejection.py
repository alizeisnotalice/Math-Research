import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,math,platform,resource,shlex,sys,time
from fractions import Fraction as F
from pathlib import Path
import numpy as np,scipy
import ccu_r618_noncommon as base

def freeze(r):
 sel=[z for z in r['selected_records'] if z[-1]>0]; a=np.array(sel,dtype=np.int64);R=a[:,0];xy=a[:,1:3];lo=xy-8*R[:,None];hi=xy+8*R[:,None]
 E=[np.unique(np.r_[lo[:,k],hi[:,k]]) for k in (0,1)];l=np.stack([np.searchsorted(E[k],lo[:,k]) for k in (0,1)],axis=1);h=np.stack([np.searchsorted(E[k],hi[:,k]) for k in (0,1)],axis=1);shape=(len(E[0]),len(E[1]));d=a[:,-1]/(16*(4*R)**2);active=np.ones(len(a),bool);lamb=np.zeros(len(a));loads=np.zeros(shape,dtype=float);steps=0
 def field(values):
  arr=np.zeros(shape);np.add.at(arr,(l[:,0],l[:,1]),values);np.add.at(arr,(h[:,0],l[:,1]),-values);np.add.at(arr,(l[:,0],h[:,1]),-values);np.add.at(arr,(h[:,0],h[:,1]),values);np.cumsum(arr,0,out=arr);np.cumsum(arr,1,out=arr);return arr
 while np.any(active):
  rate=field(d*active);v=rate[:-1,:-1];mask=v>1e-12;assert np.any(mask)
  slack=np.maximum(1-loads[:-1,:-1],0);step=float(np.min(slack[mask]/v[mask]));loads+=step*rate;lamb+=step*d*active
  tight=(loads[:-1,:-1]>=1-1e-10)&mask;ints=np.zeros(shape,np.int64);ints[1:,1:]=tight;np.cumsum(ints,0,out=ints);np.cumsum(ints,1,out=ints)
  hits=ints[h[:,0],h[:,1]]-ints[l[:,0],h[:,1]]-ints[h[:,0],l[:,1]]+ints[l[:,0],l[:,1]]
  remove=active&(hits>0);assert np.any(remove);active[remove]=False;steps+=1;assert steps<=len(a)
 loads=field(lamb);maximum=float(loads[:-1,:-1].max());lamb/=max(1.,maximum)*(1+1e-12)
 loads=field(lamb);maximum=float(loads[:-1,:-1].max());assert maximum<=1+1e-12
 Q=float(np.dot(lamb,(4*R)**2));whole=float(F(r['supplied_small_union']));VV=float(F(r['V_sum']));tau=F(*r['config']['tau']);cover=float(1+F(35,24)**2/tau)
 # L_j from the whole actual W field, and the simple global pointwise cap.
 allW=field(d);globalW=float(allW[:-1,:-1].max()); local=[]
 for i in range(len(a)): local.append(float(allW[l[i,0]:h[i,0],l[i,1]:h[i,1]].max()))
 violation=max([d[i]/local[i]-lamb[i] for i in range(len(a))]+[0.]);Qlp=float(F(r['selected_source_lp']['primal_upper']))
 return {'Qfreeze':Q,'Q_LP_upper':Qlp,'Qfreeze_over_Q_LP_upper':Q/Qlp,'Kactual':whole/Q,'Kcover':cover*VV/Q,'Ceff':whole/VV,'max_load':maximum,'max_localcap_violation':violation,'globalW':globalW,'rounds':steps,'positive_stars':len(a),'lambda_selected_positive':lamb.tolist(),'feasibility_note':'floating range-add; scaled by 1+1e-12, verified to tolerance; no rational certificate claimed'}
def task(pair,old):
 ci,tup=pair;start=time.monotonic();cpu=time.process_time();prior=next(r for r in old if r['case']==ci and r['N']==1024);seq=[tuple(z) for z in prior['supplied_records']];tau=F(*tup);sel,whole,selcells=base.selection(seq,tau);assert whole==int(F(prior['supplied_small_union'])*16)
 selected=base.lp([z[:3] for z in sel],time.monotonic()+90);alllp=prior['all_source_lp']; cfg=dict(prior['config']);cfg['tau']=tup
 r={'case':ci,'N':1024,'seed':prior['seed'],'config':cfg,'supplied_sha256':hashlib.sha256(json.dumps(seq,separators=(',',':')).encode()).hexdigest(),'selected_records':sel,'selected_count':len(sel),'rejected_count':len(seq)-len(sel),'supplied_small_union':prior['supplied_small_union'],'selected_small_union':str(F(selcells,16)),'V_sum':str(F(sum(z[-1] for z in sel),16)),'all_source_lp':alllp,'selected_source_lp':selected,'status':'complete'}
 r['Ccov_V']=str((1+F(35,24)**2/tau)*F(r['V_sum']));r['freeze']=freeze(r);r['elapsed_seconds']=time.monotonic()-start;r['cpu_seconds']=time.process_time()-cpu;r['peak_rss_bytes_macos']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss;return r
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,default=Path('/tmp/ccu_r618_noncommon_combined.json'));ap.add_argument('--output-dir',type=Path,default=Path('/tmp'));ap.add_argument('--workers',type=int,default=10);ap.add_argument('--freeze-only',action='store_true');a=ap.parse_args();assert 1<=a.workers<=10;a.output_dir.mkdir(parents=True,exist_ok=True)
 raw=a.input.read_bytes();inp=json.loads(raw);start=time.monotonic();results=[];meta={'input_sha256':hashlib.sha256(raw).hexdigest(),'base_script_sha256':hashlib.sha256(Path(base.__file__).read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'workers':a.workers,'results':results}
 suffix='freeze_existing' if a.freeze_only else 'rejection';outfile=a.output_dir/f'ccu_r618_{suffix}.json'; report=a.output_dir/f'ccu_r618_{suffix}.md'
 def save():
  meta['elapsed_seconds']=time.monotonic()-start;outfile.write_text(json.dumps(meta));lines=['# R618 saturation freeze and selection diagnostic','',f"Input SHA256 `{meta['input_sha256']}`; command `{meta['command']}`; elapsed {meta['elapsed_seconds']:.3f}s.",'','All source covering LPs are reused from the original same-supplied family; only selected-source LPs are newly solved. Saturation-frozen dual uses floating arithmetic and is numerically scaled to feasibility, so it is not a formal certificate. Ccov uses 1+(35/24)^2/τ.','','| case | τ | selected | rejected | all LP interval | selected LP interval | Qfreeze/Qlp | Kactual | Kcover | max load |','|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
  for r in sorted(results,key=lambda x:(x['case'],x['config']['tau'])):
   q=r['freeze'];al=r['all_source_lp']; sl=r['selected_source_lp'];lines.append('| %d | %d/%d | %d | %d | %s..%s | %s..%s | %.7g | %.7g | %.7g | %.9g |'%(r['case'],*r['config']['tau'],r['selected_count'],r['rejected_count'],al['dual_lower'],al['primal_upper'],sl['dual_lower'],sl['primal_upper'],q['Qfreeze_over_Q_LP_upper'],q['Kactual'],q['Kcover'],q['max_load']))
  lines+=['','Whole union means all supplied small cubes. LP intervals use feasible rational primal and dual, while freeze is a numerical feasible-packing candidate. Results concern these fixed finite families and do not establish a dimension-dependent bound.'];report.write_text('\n'.join(lines)+'\n')
 if a.freeze_only:
  for r in inp['cases']:
   q=dict(r);q['rejected_count']=q['N']-q['selected_count'];q['freeze']=freeze(q);results.append(q);save();print('freeze',len(results),flush=True)
 else:
  pairs=[(i,t) for t in ([1,64],[1,32]) for i in range(6)]
  with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
   for f in concurrent.futures.as_completed([pool.submit(task,p,inp['cases']) for p in pairs]):
    r=f.result();results.append(r);save();print('complete',len(results),r['case'],r['config']['tau'],'rejected',r['rejected_count'],flush=True)
 save()
if __name__=='__main__':main()
