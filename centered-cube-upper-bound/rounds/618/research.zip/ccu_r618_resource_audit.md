# R618 资源与阶段账目（最终记录）

- **Source LP：完成 36/36 cases。** 单 worker、BLAS 1；墙钟 1.0351 秒；峰值 RSS 1,158,610,944 bytes（约 1.08 GiB）。CPU 秒未记录。650 MiB 是事前估算，低于实测峰值，不能当实际占用。
- **Noncommon combined：完成 12/12 cases。** 6 个 batch workers，墙钟 0.4384 秒；逐案 CPU 字段缺失，因为原 `process_time` 是 worker 进程累计值，已标为不可逐案使用。最大单 worker 峰值 RSS 172,408,832 bytes（约164 MiB）。索引列出的 1,034,452,992 bytes 是 6×最大单 worker 峰值的保守聚合上界，不是同时采样到的总 RSS。
- **Rejection batch：完成 12/12 cases。** 10 workers，墙钟 0.37350 秒，逐案 CPU 秒合计 0.066955 秒。最大单 worker 峰值 RSS 90,587,136 bytes（约86.4 MiB）；10×该峰值的 905,871,360 bytes 是保守估计上界，不是测得的并发 RSS 总量。
- **Freeze-existing：完成 12/12 cases。** 1 worker，墙钟 0.06446 秒；CPU 秒不可逐案恢复（沿用原 noncommon 累计字段）。该阶段使用既有 source LP 并另做 selected-only LP；数值方法/证书限制见对应 Markdown。
- **当前未开始项：** 上述索引、合并结果、rejection 与 freeze-existing 记录均标成完成；本次材料中没有其他登记为运行中或未开始的 R618 阶段。

机器初检快照（15 核、24 GiB，CPU 87% idle、22 GiB used、6.8 GiB compressed）是环境状态，不是这些进程的资源使用量。短任务在约 0.37–1.04 秒内完成，不能据此声称持续满载；rejection 的 CPU 总和仅 0.067 秒，亦不支持满载说法。峰值 RSS 是单进程/单 worker峰值；把多个 worker 的峰值相加只能作保守界，不能当作同时内存测量。

**仍缺的资源记录：** source LP 与 freeze-existing 没有 CPU 秒；noncommon 没有可用的逐案/累计 CPU 计量；没有多 worker 同时 RSS 时间序列或系统级本批次 CPU 利用率记录。无需为补齐资源账重复运行。
