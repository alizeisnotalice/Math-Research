# R618 独立必要审查

日期：2026-10-28。先独立核验连续source LP与冻结候选，再读取 `/tmp/ccu_r618_main_sol.md`、`/tmp/ccu_r618_bridge_sol.md`，及指定证书/拒选脚本和保存结果。未改他人文件，未运行Git，未重跑LP或采样，未作反例扫描。

**结论：已核一般命题与收费方向通过，没有一般根阶闭合。** 精确LP等价、全局packing、共同交分组收费及饱和冻结可行性均成立。唯一固定实例的有理证书脚本可认证其2048成本；其余数值材料的独审范围限于下述来源、整数界及费用核对，不将有限easy-cluster结果冒称一般维数结论。

## 1. 连续LP、有限cell及边界

记selected stars为A_j=aB_j，d_j=|A_j|，V=Σv_j。有限星族所有坐标端点给正体积全维开cells；在每cell上membership常数。质量变量z_C=∫_C f满足

min Σ_C z_C，z_C≥0，Σ_(C⊂A_j)z_C≥ηd_j。

任何L1来源给可行cell质量；反向由f|C=z_C/|C|实现。因此这是连续非负L1问题的精确有限LP，而不是限制来源的离散近似。零体积面不可作为有独立L1质量的cell。可行函数η1_(∪A_j)给有限上界；限制在总质量次水平集后紧性给最优解。强对偶是

m_sel(η)=η max_{λ≥0, Σλ_j1_Aj≤1 a.e.}Σλ_jd_j。

每个star含正体积cell，故λ_j≤1，对偶最优也达到。严格bad条件的inf与其相同，由(1+ε)缩放逼近；不能把非严格最优函数直接称为严格bad最优解。

作者关于有限非负Borel测度也同值的补充正确：开stars与λ≥0使packing load下半连续，a.e.≤1自动处处≤1，故可对原子测度积分；L1最优已给反向不等式。此结论不能无条件移植到任意闭集合。允许原子不等于可以免费使用仅在零体积闭面出现的membership。

计算时cell变量若是density，目标与覆盖均须带cell体积；若是mass，才是上述单位目标。仅限制几个候选source cells得到的是primal上界，不能拿它当任意来源质量的下界。合法的下界必须来自全空间packing可行λ或其他独立证明。

## 2. 完整receiver及关键量词

原实际来源满足全部selected约束，故||f||1≥m_sel；加入全部supplied-star约束得到m_all≥m_sel。selected-only最优来源未必令rejected/supplied stars仍bad，不能反向把它说成整个原超水平集的最优输入。

令U为全部supplied小cubes的并，Qpack=Σλ_jd_j。合法完整账是

η|U|/||f||1≤|U|/Qpack≤C_cov V/Qpack，
C_cov=1+A_a/τ。

只报V/Qpack会漏完整cover费；n=2,a=8,t=3时须用1+(35/24)^2/τ。selected union体积恰是V，不能替代全部supplied union。λ必须是一套对全空间source位置成立的固定权；不同receiver处各做局部packing后不能免费相加。

用于构造实际弱型下界时还有另一方向限制：平均≥η只保证x∈B_j时M_nf(x)≥η/P，P=((a+1)/a)^n；原η|∪B_j|/m实验比值需除P并处理strict阈值。作者第5节已正确区分这一点与R616上界入口K⊂U，未对上界再次多付P。

全star有共同点时，其有限开交有正体积，源LP值准确为η max_j d_j。旧R616共同x的point-load profiles不能验证分散source packing收益；对它们冻结机制也在同一时刻退回global帽。有限簇例的表现不支付一般source/receiver量词。

## 3. 饱和冻结候选

只将w_j>0的stars作为活动项；w_j=0时取λ_j=0，不对0/0或0·∞作解释。按共同clock以速率w_j增长，下一步以所有正活动速率cells的最小slack/rate前进，并冻结覆盖任一同时饱和cell的全部活动项。

每步保持全部load≤1；旧饱和cell已无活动覆盖，故以后不增。只要仍有正活动star，它含某个正体积cell，有正速率及有限下一事件。每步至少冻结一项，至多正权项数步终止。所有同时事件必须取并集，不能只冻结一个star而继续穿过已饱和约束。

若j在绝对clock t_j冻结，则λ_j=w_jt_j。在其饱和cell h上

1=Σ_(k:h⊂A_k)w_k min(t_j,t_k)≤t_j W(h)≤t_j L_j，
L_j=esssup_(x∈A_j)W(x)>0。

因此λ_j≥w_j/L_j≥w_j/M，M=||W||∞；完整objective Qfreeze=Σv_jt_j≥Σv_j/L_j≥V/M。这里是弱支配，不能宣称每个实例都严格改进，也不保证packing最优或固定比例近似。局部帽权本身亦可行，因为在x∈A_j有L_j≥W(x)。

作者桥稿(P1)–(P5)及停止范围正确。source收费直接用同一个f的所有bad-star条件，ηQfreeze≤||f||1；无需把increment体积误当f质量。冻结可行性与局部下界不提供一般根阶的Qfreeze下界。

## 4. 作者新增分组及γ关系

共同交组G的实际increments均落在以共同点为中心、半径(a+1)max r_j的cube中，故Σ_(j∈G)v_j≤P d_rep。代表stars全空间重数≤D才给λ_rep=1/D的合法packing，进而m_sel≥ηV/(PD)，完整receiver还付Ceff。对全部supplied分组可直接界U，不重复付Ceff。这里的D不能替换成选入时加权priorload或局部平均重数。

按半径选两两不交star代表的粗版本，分配给相交且更大代表后小cube落在半径(2a+1)R包络中，成本(2+1/a)^n正确；它只是指数阶粗界。作者明确未证明根阶共同交分组/分数packing。

Qgap=0时γ归一与packing互为缩放，B0=ηV/m_sel正确；证明中取实现B0的最优γ（最优存在）即可。真正R617 γ证书还需支付非负gap，所以不是第二份可叠加收益。本文未将这些等价或充分命题称为新的维数估计。

## 5. 指定有理证书及数值费用核对

已读 `/tmp/ccu_r618_source_certificate.py`，并核对JSON、MD及输入来源。脚本限定二维正面积矩形和给定piecewise-uniform source矩形，不是任意维求解器。

* Dual候选先向下取10^-9有理网格；所有star端点诱导正面积cells，二维差分用Python整数累计，无int64溢出。M为全空间cell最大整数load，分母max(10^9,M)严格保证packing≤1。350000网格点限制是内存保护，不是数学近似。
* Primal逐star准确求Σ mass_C·|A_j∩C|/|C|，再统一乘非负有理source_scale以满足全部面积右端。即使输入source矩形相交，密度相加仍是合法L1函数且总质量为所给质量之和。所有关键比较均为Fraction，未用solver最优状态代替证书。
* 当前证书输入SHA匹配，256个stars和source cells准确对应noncommon case0、N=256的原始supplied LP记录。保存的lower=upper=2048、gap=0，故该固定实例最优质量严格为2048。证书代码SHA为 `2bdb021e1b8696a6a9dd93783ba0fb72859b8126a2a95bc1e5821bfb72448917`，与记录匹配。Terra另已复现；本审未再跑LP。

对12个rejection案例，仅核保存账与费用，不宣称已逐一独立重构所有greedy/LP运算。12案身份完整、selected+rejected=1024，拒选数1012–1020，V_sum=selected union；selected LP下端与同supplied族原LP下端逐案一致。freeze/LP约0.999999999999是浮点关系，不是由本审认证的12个最优等式。root后补的12案strict验证属于另份证据，本审未重审其新增脚本。

已按保存V、τ独立复算noncommon_combined及rejection的全部Ccov_V，并复算rejection Kactual/Kcover，均使用正确τ。rejection Kcover约2.427734–4.284722；freeze仅按浮点容差缩放，不能叫有理packing证书。保存LP的已见int64规模核对：source mass·2^30总和最大4398046511104，dual整数与面积点积最大4503599627370496，均低于2^63−1；这不是对任意扩展输入的溢出保证。

**运行版与修复版不得混归属。** 原noncommon运行SHA为 `0d1a6a706d90278c1f9702c1b8fab9cde5babd29a3ab486d139caeabb5615b35`；修正Ccov含τ后的当前源码SHA为 `e6b48f25dfa7bbb424167d6a13713489efd118c59194aeb99c0fbdaa718c1e5c`。combined明确保留executed与corrected哈希，并说明从保存V修复费用、未重跑LP；旧累计worker CPU字段也未伪称每例CPU。根目录旧noncommon.json仍有漏τ费用，不应采用该旧字段。rejection源码/运行SHA匹配，base_sha绑定修复版。不得把旧LP运行回执改成修复版曾运行全部原计算。

## 6. 冻结判断

已核理论与有限证书范围内没有决定性错误。通过的是：连续source LP的精确量词与packing对偶、完整收费、合法冻结权和局部/global帽弱支配、共同来源分组充分机制，以及上述固定实例/费用核对。

未通过也未被作者声称完成的目标仍是：从真实greedy几何普遍推出足够强的全source packing或非分离共同簇联合机制，支付全部supplied receiver并取得一般根阶。两批easy-cluster数值不能代替该定量定理。本审不认证尚未见的最终归档包，也不扩大扫描或重新分配局部帽。审查完成，停止。

## 最终整合稿补核

已读 `/tmp/ccu_r618_final/REPORT.tex`。其LP质量/对偶归一、开集a.e.到处处的理由、strict inf、selected/all-supplied区分、Ccov保留τ、冻结弱支配及共同交分组条件均与本审已核内容一致。报告正确将一般n^(1/2+o(1))目标、代表全source重数和交互source-clique机制列为未证明，没有用有限LP或冻结可行性替代该定量结论。

报告所述后补12案exact验证由root另行运行；本审没有再次审查 `verify_disjoint.py` 及其新绑定文件，故不将12案strict结果或该项复现归属本审。36份继承计算的性能细项也未重新核验。原理、指定first256证书脚本、已核保存费用与最终报告的证据层次无冲突。最终归档/commit不在本审认证范围。当前可提交已核范围；停止。
