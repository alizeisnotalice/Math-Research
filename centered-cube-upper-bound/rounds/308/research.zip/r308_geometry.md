# R308 — a globally coupled signed FIRST certificate retaining the exact capture square

## 1. Precise scope and candidate theorem

This note supplies a constructive global variational SOURCE CERTIFICATE for the remaining original binary incidence. It is an alternative to another scalar stop. The certificate uses the actual full-soft row profiles in all its constraints, retains the exact negative capture square, and shares one receiver potential across ALL source rows and scales. It has an executable finite LP and exact primal/dual verification. It does NOT prove that root-priced certificates exist for every original input.

Keep the complete original field from R305–R307: positive original sources beta,nu, frozen restriction nu_*<=nu with all original full-source e_g,m and history gates unchanged; actual common s(x),L(x),R(x),q(x); a<=L,R<=b<=2a; q_-=3lambda/4<=q<=lambda; FIRST and SAME-R hard caps on the original accepted E; original low-pe,m>M and aspect v>=v0. In particular

    U_y(x)=1_E(x)alpha(x,y)P_(s(x),L(x))(x-y)/q(x),
    0<=I0<=alpha<=1, alpha independent of z,
    f(x)=integral U_y(x)beta(dy)<=1_E(x).               (1)

The full sources in FIRST have not been replaced by the restricted target sources. Let b_y=I0/alpha on alpha>0 and zero otherwise. For the common theta in (0,1], set

    sigma_theta(x,y,z)=1{z in Q_R(x)(x)}1{b_y(x,z)>=theta},
    J_y(r)=integral_{R(x)<=r}U_y(x)dx,
    A_theta(y,z;r)=integral_{R(x)<=r}U_y(x)sigma_theta(x,y,z)dx,
    p_theta=A_theta/J_y when J_y>0,
    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)dr,
    d=kappa0 psi_inf/(q_-v0), H=8d,
    kappa0=2K/(ell M), psi_inf=3-2/(3gamma^n), gamma=1+1/n,
    chi_theta(y,z,r)=1{J_y(r)>=H,p_theta(y,z;r)<7/8}.

Every qualification is frozen from the ACTUAL input. In particular chi is not optimized after choosing a prediction or a certificate. At J=0 its contribution is zero. Put

    H_theta(y,x)=R(x)^(-n)integral sigma_theta(x,y,z)nu_*(dz),
    T_ytheta=integral U_y(x)H_theta(y,x)dx,
    B_ytheta=integral nu_*(dz)ell_n(dr)chi_theta
                               [A_theta-A_theta^2/J_y],
    T_y=integral_0^1 T_ytheta dtheta,
    B_y=integral_0^1 B_ytheta dtheta,
    T=integral T_y beta(dy), B=integral B_y beta(dy).    (2)

These are the EXACT original target and R305 remaining fee. The theta integral is performed AFTER computing the square at each theta; averaging p_theta first and then squaring would be a different expression. All U,J and sources are fixed as theta varies.

Choose 0<=epsilon<1 and let

    b_y^epsilon=B_y-epsilon T_y.                       (3)

This quantity may be negative and must not automatically be replaced by its positive part. Suppose a nonnegative measurable common receiver potential P(x), supported on E, and a finite number C_beta>=0 satisfy

    integral_E P(x)dx < infinity,
    b_y^epsilon-integral U_y(x)P(x)dx <= C_beta
                                           for beta-almost every y. (4)

Then the constructive source certificate is

    B <= epsilon T+C_beta W_beta+integral_E P(x)dx.    (5)

If W_nu*>0, set C_nu=(integral_E P)/W_nu*. Formula (5) is exactly

    B <= epsilon T+C_beta W_beta+C_nu W_nu*.           (6)

To obtain a root payment it is sufficient to exhibit (4) with

    C_beta W_beta+C_nu W_nu*
          <= C_epsilon sqrt(A_n) polylog(n+2)(W_beta+W_nu*),
    A_n=1+n log(b/a).                                  (7)

Existence of certificates with (7) for all original inputs remains unproved. Unlike merely naming an unpaid integral, (4) is a collection of LINEAR inequalities in a shared potential and a scalar, with an exact finite algorithm and lower-certificate test below. The actual full-soft geometry resides in the matrix/function U_y(x), not only in a total row mass.

## 2. The square is retained exactly, and signed budgets dominate positive-part budgets

For any measurable prefix prediction 0<=h_theta(y,z,r)<=1 define

    E_h,theta(x,y)=integral nu_*(dz)ell_n(dr)
       chi_theta(y,z,r)1{R(x)<=r}
                     [sigma_theta(x,y,z)-h_theta(y,z,r)]^2.

Because sigma is binary, expansion at each fixed y,z,r gives the exact identity

    integral U_y(x)E_h,theta(x,y)dx
       =B_ytheta+integral nu_*(dz)ell_n(dr)
                      chi_theta J_y(r)[h_theta-p_theta]^2. (8)

There is no Jensen loss, row average, or discarded negative term in (8). Choosing h_theta=p_theta minimizes EVERY row integral simultaneously, including after averaging theta. Hence the signed per-row condition

    integral U_y(x)[integral_0^1 E_h,theta(x,y)dtheta
                    -epsilon integral_0^1 H_theta(y,x)dtheta-P(x)]dx
         <= C_beta

is weakest, and exactly equals (4), when h=p. No quadratic optimization in h is needed.

An initially contemplated alternative was to put a positive part around the entire bracket before integrating. That alternative is valid but more restrictive. For any h and P its positive-part integral is at least its signed integral, which by (8) is at least the left side of (4). Thus every such positive-part certificate implies this signed LP certificate with the same P,C_beta. The converse is not asserted. In particular the later representation P=integral psi nu_* does NOT upgrade a signed certificate to a positive-part one.

All cancellations here occur inside a finite original row integral or a common finite approximation before passage to the limit. They do not use subtraction of two infinities. Indeed H_theta<=4lambda on E by the actual hard cap; T_ytheta<=4lambda I_y, I_y=integral U_y; and B_ytheta<=T_ytheta. The existing full-soft envelope supplies finite I_y (for instance I_y<=A_n Csoft_n/q_-). Also 0<=E_h,theta<=a^(-n)W_nu*. After integrating beta, integral U_yP beta=integral fP<=integral P<infinity. Consequently integral U_yP is finite for beta-almost every y, which is exactly the domain needed in (4). Zero-mass exceptional rows do not impose artificial constraints.

## 3. Proof of the global certificate and its exact slack ledger

Let

    s_y=C_beta+integral U_y(x)P(x)dx-b_y^epsilon>=0.

Multiply this identity by the ORIGINAL beta and integrate. Positive Tonelli on U_y P, followed by actual FIRST (1), gives

    B-epsilon T
       =C_beta W_beta+integral_E f(x)P(x)dx-integral s_y beta(dy)
       <=C_beta W_beta+integral_E P(x)dx.               (9)

More precisely the entire proof loss is visible:

    [C_beta W_beta+integral_E P]-(B-epsilon T)
       =integral_E [1-f(x)]P(x)dx+integral s_y beta(dy). (10)

Both terms are nonnegative. There is no free capacity at a source center. The pointwise capacity used in (10) is the SAME original receiver FIRST, and P is paid by true Lebesgue measure dx. Thus a useful certificate places its receiver potential where the original row congestion f is high, while allowing actual low-incidence rows to pay the common C_beta. Independent row bounds do not make that allocation.

The hard-source accounting in (6) can be made explicit without assuming a density. If 0<W_nu*<infinity, define

    psi(x,z)=P(x)/W_nu* for nu_*-almost every z.

Then P(x)=integral psi(x,z)nu_*(dz) and every hard-source column has the same finite charge integral_E psi(x,z)dx=C_nu. The total is C_nu W_nu*, exactly once. This is an accounting representation of the actual potential cost, not an extra geometric theorem or a claim that C_nu is root-sized. More structured column potentials are possible, but the proof does not require them. If W_nu*=0 or W_beta=0 then B=T=0 and no normalization is made.

One may instead first construct separate theta certificates and average their costs. However (4), with the fully averaged row b_y^epsilon, is at least as permissive: since U is theta-independent, averaging P_theta and C_beta,theta gives a feasible single certificate. Solving the single averaged constraint can additionally use legitimate same-row signed cancellation across theta. No artificial independent-mark variance is reintroduced, and no source mass is multiplied by the number of theta levels or physical scales.

## 4. Finite executable LP and independently checkable lower witnesses

Consider a verified finite receiver representation with cells i of positive Lebesgue masses m_i, actual row values U_yi, beta-positive rows y, hard-source masses nu_z, physical selected radii R_i, and binary qualifications sigma_yiz, separately for each common theta level if needed. Zero-volume cells and beta-zero rows are removed. For ordered distinct physical radii r_l, the exact prefix scale weights are

    w_l=r_l^(-n)-r_(l+1)^(-n), last weight=r_last^(-n).

The last formula includes the physical b endpoint: if the largest selected radius is below b, its remaining continuous tail plus the atom still have total r_last^(-n). Compute J,A,chi,B_y,T_y and the correctly weighted common-theta average from the original finite data. Do not optimize chi or ignore same-radius groups.

Let Z_i=m_i P_i. The certificate program is

    minimize       W_beta C + sum_i Z_i
    subject to     C + sum_i U_yi Z_i >= b_y^epsilon  for every retained y,
                   C>=0, Z_i>=0.                    (11)

All coefficients are supplied from the original finite input. The negative capture square has already been computed exactly in b_y^epsilon; replacing it by a positive first moment produces a different, weaker program. The original receiver FIRST is checked separately:

    sum_y beta_y U_yi<=1 for every i.                 (12)

Given any feasible (C,Z), rational or interval verification of (11),(12) certifies (5). Optimizer status alone is not used as a proof. This program couples all rows through the SAME Z; it does not buy an independent receiver potential for every row.

A nonnegative vector v_y provides an independent lower witness for the achievable price of THIS certificate class if

    sum_y v_y<=W_beta,
    sum_y v_y U_yi<=1 for every i.                    (13)

Indeed multiplying the row inequalities in (11) by v and summing gives

    sum_y v_y b_y^epsilon <= W_beta C+sum_i Z_i.       (14)

This elementary weak-duality proof does not assume a general minimax interchange or invoke strong duality. If a feasible primal and a feasible v have exactly equal objectives, their common value is proved optimal for that finite LP by the two inequalities alone. A v with price above a proposed source budget rules out that budget for this LP on that finite fixture. It does not construct a new physical input or disprove the original analytic theorem: v is only a certificate-class row reweighting, not a new original source satisfying every original gate.

## 5. Baseline domination and a strict mixed-source finite example

The certificate is always feasible on the original input at the known coarse scale. For 0<=epsilon<1, let

    H0(x)=h_(R(x))*nu_*(x), x in E,
    P(x)=(1-epsilon)H0(x), C_beta=0.

Since B_y<=T_y and H_theta<=H0, (4) holds. Thus the new variational price is at most

    (1-epsilon) integral_E H0 dx <=(1-epsilon)A_n W_nu*. (15)

The row-only choice P=0,C_beta=esssup_y (b_y^epsilon)_+ is another existing baseline. Both choices, and every genuine mixed choice, are included in one LP. There is no universal claim that its optimum beats every previously available column bound; one may retain the smaller of independently certified bounds. The following exact finite example demonstrates strict simultaneous improvement of the row-only, receiver-only and column-Jensen prices.

Take two beta rows with masses (1/10,9/10), one hard source of mass 1/2, four receiver cells with masses

    m=(1/20,1/20,4/5,1/5),
    U_1=(10,10,0,0), U_2=(0,0,1,1),

all selected hard radii equal to 1. The source is captured/qualified in cells 1 and 3 only. One may place those cells inside the unit source cube, and cells 2 and 4 outside it; this is only a finite FIRST-compatible occupation fixture, not a certified realization of the original full-soft, ungated FIRST, low-pe/e_g and history construction. In particular the abstract U values must not be mislabelled as automatically arising from a=q=1 kernels.

For any H<=1 the displayed original-style gate p<7/8 retains both rows. The exact numbers are

    J=(1,1), A=(1/2,4/5), B_y=(1/8,2/25), epsilon=0.

The receiver congestions in (12) are (1,1,9/10,9/10). A mixed certificate is

    C=2/25, Z=(9/2000,0,0,0),
    objective=169/2000=0.0845.                         (16)

Both row constraints are equalities. The vector v=beta satisfies (13) and has the same objective, so (16) is exactly optimal for this fixture, without appealing to strong duality. It also equals the actual B. The potential is positive only on the first cell, where FIRST is saturated; both slack terms in (10) vanish.

The row-only price is 1/8; the receiver-only price C=0 is 37/400. The sharper column Jensen bound retaining the column mean but discarding between-row variance is

    (1/2)[77/100-(77/100)^2]=1771/20000=0.08855,

also strictly larger than (16). The scalar G(E,Ccol) receipt from R305 is 1/8 here. In source form (16) has C_beta=2/25 and C_nu=9/1000, with BOTH contributions positive. Thus its improvement is genuinely a shared receiver/source allocation retaining row capture squares, rather than a single-row cap or charging all hard sources independently for each scale. This finite improvement is not a claim that original general inputs have a dimension-independent price.

## 6. Original entry, all retained complements, and the exact remaining proof obligation

Apply the signed certificate to the common-theta average of the WHOLE R305 remaining B, which includes R307 persistent gains, near-scale disagreement and radius ties. Thus none of those terms is dropped. The original entry is

    Lambda T<=128 Lambda lambda d W_beta+4 Lambda B.

For 0<=epsilon<1/4, (5) gives the complete certified implication

    (1-4epsilon)Lambda T
       <=Lambda[128lambda d+4C_beta]W_beta
                               +4Lambda C_nu W_nu*.  (17)

Here lambda d=(4/3)kappa0 psi_inf/v0, so small-aspect and low-m costs remain explicit. The original outer integration and positive multiplier Lambda must be retained around every coefficient and original source mass. This is an internal incidence payment, not certification of an otherwise missing global entry or coverage theorem. One can alternatively certify an exact remaining subfee after using R306/R307, but then its own entry coefficients and complements must be kept; (17) uses the unsplit R305 remaining B to avoid an unnoticed subtraction or double payment.

The decisive outstanding question is the existence, for the ORIGINAL full-soft field and complete qualifications, of shared nonnegative P satisfying the linear row inequalities (4) at the root price (7). FIRST alone makes the certificate valid but does not yet produce that small price. The generic feasible potential (15) remains order A_n. The finite example proves strict budget improvement on a legitimate finite occupation fixture, not an all-input root theorem.

This reformulation changes the next constructive action in a checkable way: use the actual row incidence B_y, actual full-soft U_y and actual source masses to propose a common receiver potential; certify every row inequality and the two source prices; if a finite candidate fails, an explicit vector (13) can distinguish a limitation of the proposed price from optimizer error. The remaining task is a spatial certificate construction, not further scalar optimization of a renamed positive remainder. No source density cap, nu<=beta assumption, free per-pair selector or repeated source copy has been added.

## 7. Actual exact diagnostic performed by this author

A fresh local standard-library Fraction calculation verified the example's J,A,B_y, FIRST, all primal and dual constraints, exact objective equality, and strict comparisons with both one-sided prices and column Jensen. It returned

    J=(1,1), A=(1/2,4/5), rowB=(1/8,2/25),
    mixed primal=dual=169/2000,
    column Jensen=1771/20000, row-only=1/8, receiver-only=37/400.

This is finite algebra/occupation evidence only. Broader independently owned diagnostics are separate and are not assumed here. Reproduction writes no files:

```python
from fractions import Fraction as F
beta=[F(1,10),F(9,10)];nu=F(1,2)
m=[F(1,20),F(1,20),F(4,5),F(1,5)]
U=[[10,10,0,0],[0,0,1,1]]
sig=[1,0,1,0]
J=[sum(m[i]*U[y][i] for i in range(4)) for y in range(2)]
A=[sum(m[i]*U[y][i]*sig[i] for i in range(4)) for y in range(2)]
B=[nu*(A[y]-A[y]**2/J[y]) for y in range(2)]
C=F(2,25);Z=[F(9,2000),F(0),F(0),F(0)]
assert all(C+sum(U[y][i]*Z[i] for i in range(4))>=B[y] for y in range(2))
assert all(sum(beta[y]*U[y][i] for y in range(2))<=1 for i in range(4))
primal=sum(beta)*C+sum(Z);dual=sum(beta[y]*B[y] for y in range(2))
assert primal==dual==F(169,2000)
E=sum(beta[y]*J[y] for y in range(2));L=sum(beta[y]*A[y] for y in range(2))
column=nu*(L-L**2/E)
assert column==F(1771,20000) and primal<column
rowonly=sum(beta)*max(B)
receiveronly=B[0]/10+B[1]
assert primal<rowonly and primal<receiveronly
print({'J':list(map(str,J)),'A':list(map(str,A)),'rowB':list(map(str,B)),
 'mixed_primal_dual':str(primal),'column_Jensen':str(column),
 'row_only':str(rowonly),'receiver_only':str(receiveronly)})
```

Only /tmp/r308_geometry.md was written. Other authors' files, earlier frozen proofs and Git were not modified.
