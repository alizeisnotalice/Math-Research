from fractions import Fraction as F
beta=[F(1,10),F(9,10)];nu=F(1,2)
m=[F(1,20),F(1,20),F(4,5),F(1,5)]
U=[[10,10,0,0],[0,0,1,1]]
sig=[1,0,1,0]
J=[sum(m[i]*U[y][i] for i in range(4)) for y in range(2)]
A=[sum(m[i]*U[y][i]*sig[i] for i in range(4)) for y in range(2)]
B=[nu*(A[y]-A[y]**2/J[y]) for y in range(2)]
C=F(2,25);Z=[F(9,2000),F(0),F(0),F(0)]
assert all(C+sum(U[y][i]*Z[i] for i in range(4))>=B[y] for y in range(2))
assert all(sum(beta[y]*U[y][i] for y in range(2))<=1 for i in range(4))
primal=sum(beta)*C+sum(Z);dual=sum(beta[y]*B[y] for y in range(2))
assert primal==dual==F(169,2000)
E=sum(beta[y]*J[y] for y in range(2));L=sum(beta[y]*A[y] for y in range(2))
column=nu*(L-L**2/E)
assert column==F(1771,20000) and primal<column
rowonly=sum(beta)*max(B)
receiveronly=B[0]/10+B[1]
assert primal<rowonly and primal<receiveronly
print({'J':list(map(str,J)),'A':list(map(str,A)),'rowB':list(map(str,B)),
 'mixed_primal_dual':str(primal),'column_Jensen':str(column),
 'row_only':str(rowonly),'receiver_only':str(receiveronly)})
