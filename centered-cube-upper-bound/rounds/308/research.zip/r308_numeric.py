#!/usr/bin/env python3
"""R308 signed-row/shared-FIRST LP: numerical candidates, exact rational certificates."""
import sys,json,random,itertools,hashlib
from fractions import Fraction as F
from pathlib import Path
import numpy as np
ENV={'numpy_version':np.__version__}
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime')
try:
 import scipy
 ENV['scipy_version']=scipy.__version__
 from scipy.optimize import linprog
 ENV['scipy_optimize']='available; not required by this bounded vertex solver'
except Exception as exc:ENV['scipy_optimize_error']=type(exc).__name__+': '+str(exc)
R=random.Random(30120261018);COUNTS={};FAIL=[]
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'data':data})
def cellvol(h,n):return F(2*h,32)**n
def make(name,n,kind):
 if kind=='disjoint':
  X=[(0,0),(128,0),(256,0)];eh=[1,2,1];ls=[32]*3;rs=[32]*3
  Y=[(v,4) for v in [4,132,260,452]];Z=list(Y)
 elif kind=='chain':
  X=[(-16,0),(0,0),(16,0)];eh=[1,2,1];ls=[32,48,64];rs=[32,32,48]
  Y=[(v,4) for v in [-28,-12,4,20,36,100]];Z=list(Y)
 else:
  X=[(0,0),(16,0),(0,16),(16,16)];eh=[1,2,2,1] if n>=8 else [1,2,1,2]
  ls=[32,48,64,32];rs=[48,32,64,48]
  if kind=='tied':ls=rs=[32]*4
  Y=[(x,y) for x in [-12,4,20,36] for y in [-12,4,20,36]]
  Z=[(-12,-12),(4,4),(20,4),(4,20),(20,20),(36,20),(100,100)]
 if n==1:X=[[x] for x,y in X];Y=[[x] for x,y in Y];Z=[[x] for x,y in Z]
 else:X=[list(v)+[0]*(n-2) for v in X];Y=[list(v)+[4]*(n-2) for v in Y];Z=[list(v)+[4]*(n-2) for v in Z]
 def incidence(points,sides,label):
  A=[]
  for i,(x,s,h) in enumerate(zip(X,sides,eh)):
   row=[]
   for j,z in enumerate(points):
    inside=all(2*(abs(a-b)+h+1)<=s for a,b in zip(x,z));outside=any(2*(abs(a-b)-h-1)>s for a,b in zip(x,z))
    ck(inside or outside,label,{'case':name,'receiver':i,'source_cell':j});row.append(int(inside))
   A.append(row)
  return A
 soft=incidence(Y,ls,'exact_soft_pair_whole_inside_or_outside');hard=incidence(Z,rs,'exact_hard_pair_whole_inside_or_outside')
 for tag,points,hs in [('E',X,eh),('Y',Y,[1]*len(Y)),('Z',Z,[1]*len(Z))]:
  ck(all(any(abs(z[k]-w[k])>=hs[j]+hs[l] for k in range(n)) for j,z in enumerate(points) for l,w in enumerate(points[:j])),'positive_cells_disjoint_'+tag,{'case':name})
 vol=[cellvol(h,n) for h in eh];L=[F(s,32) for s in ls];rr=[F(s,32) for s in rs]
 br=[F(R.randint(1,10),R.randint(1,10)) for _ in Y];vr=[F(R.randint(1,10),R.randint(1,10)) for _ in Z]
 bresp=[sum(v*a for v,a in zip(br,row))/l**n for row,l in zip(soft,L)];bscale=1/max(bresp);beta=[bscale*v for v in br]
 vresp=[sum(v*a for v,a in zip(vr,row))/r**n for row,r in zip(hard,rr)];vscale=4/max(vresp);nu=[vscale*v for v in vr]
 first=[sum(v*a for v,a in zip(beta,row))/l**n for row,l in zip(soft,L)];hardresp=[sum(v*a for v,a in zip(nu,row))/r**n for row,r in zip(hard,rr)]
 for i,(f,h) in enumerate(zip(first,hardresp)):
  ck(f<=1,'actual_FIRST_q1',{'case':name,'receiver':i,'response':str(f)})
  ck(h<=4,'actual_same_radius_hardcap_lambda1',{'case':name,'receiver':i,'response':str(h)})
 I=[sum(vol[i]*soft[i][j]/L[i]**n for i in range(len(X))) for j in range(len(Y))]
 pi=[[vol[i]*soft[i][j]/L[i]**n/ij if ij else F(0) for i in range(len(X))] for j,ij in enumerate(I)]
 ck(sum(b*ij for b,ij in zip(beta,I))==sum(v*f for v,f in zip(vol,first))<=sum(vol),'FIRST_integrated_rowI_identity',{'case':name})
 return {'name':name,'n':n,'X':X,'Ehalf':eh,'Y':Y,'Z':Z,'L':L,'R':rr,'soft':soft,'hard':hard,'vol':vol,'beta':beta,'nu':nu,'first':first,'hardresp':hardresp,'I':I,'pi':pi}

def solve_fraction(A,b):
 d=len(b);a=[list(row)+[rhs] for row,rhs in zip(A,b)]
 for k in range(d):
  pivot=next((i for i in range(k,d) if a[i][k]),None)
  if pivot is None:raise ValueError('singular exact basis')
  a[k],a[pivot]=a[pivot],a[k];q=a[k][k];a[k]=[x/q for x in a[k]]
  for i in range(d):
   if i!=k:
    q=a[i][k]
    if q:a[i]=[x-q*y for x,y in zip(a[i],a[k])]
 return [row[-1] for row in a]
def lp_certificate(U,beta,bvec,receiver_only=False):
 ny=len(U);nx=len(U[0]);W=sum(beta);positive_rows=[y for y in range(ny) if beta[y]>0];scales=[max((U[y][x] for y in positive_rows),default=F(0)) for x in range(nx)];active=[x for x in range(nx) if scales[x]]
 def finish(C,Z,v,candidates,method):
  primal=W*C+sum(Z);dual=sum(vy*by for vy,by in zip(v,bvec))
  ck(C>=0 and all(z>=0 for z in Z),'exact_primal_variables_nonnegative',{})
  ck(all(C+sum(a*z for a,z in zip(U[y],Z))>=bvec[y] for y in positive_rows),'exact_beta_ae_signed_row_constraints',{})
  ck(all(vy>=0 for vy in v) and (receiver_only or sum(v)<=W),'exact_dual_row_mass_constraints',{})
  ck(all(v[y]==0 for y in range(ny) if beta[y]==0),'exact_dual_zero_on_beta_null_rows',{})
  ck(all(sum(v[y]*U[y][x] for y in range(ny))<=1 for x in range(nx)),'exact_dual_all_shared_column_constraints',{})
  ck(primal==dual,'exact_zero_primal_dual_gap',{})
  return {'C':C,'Z_equals_mP':Z,'dual_row_v':v,'primal_value':primal,'dual_value':dual,'gap':primal-dual,'numerical_feasible_vertices':candidates,'rational_repair':method,'receiver_only_C_fixed_zero':receiver_only}
 if not positive_rows:return finish(F(0),[F(0)]*nx,[F(0)]*ny,0,'zero beta mass: no beta-a.e row constraints, exact zero primal/dual')
 if max(bvec[y] for y in positive_rows)<=0:return finish(F(0),[F(0)]*nx,[F(0)]*ny,0,'zero certificate after exact signed-row check')
 bs=max(abs(bvec[y]) for y in positive_rows);offset=0 if receiver_only else 1;d=len(active)+offset
 if not d:raise ValueError('positive budget without any available LP variable')
 cost=([W] if offset else [])+[1/scales[x] for x in active]
 unique={}
 for y,row in enumerate(U):
  if beta[y]==0 or bvec[y]<=0:continue
  g=tuple(([F(1)] if offset else [])+[row[x]/scales[x] for x in active])
  if g not in unique or bvec[y]>unique[g][0]:unique[g]=(bvec[y],y)
 rows=list(unique);rhs=[unique[g][0]/bs for g in rows];owners=[unique[g][1] for g in rows];nr=len(rows)
 G=rows+[tuple(F(int(i==j)) for j in range(d)) for i in range(d)];right=rhs+[F(0)]*d
 combinations=list(itertools.combinations(range(len(G)),d));gf=np.array([[float(x) for x in row] for row in G]);bf=np.array([float(x) for x in right]);cf=np.array([float(x) for x in cost]);idx=np.asarray(combinations,dtype=int);mat=gf[idx];det=np.linalg.det(mat);valid=np.flatnonzero(abs(det)>1e-10)
 solutions=np.linalg.solve(mat[valid],bf[idx[valid]][...,None])[...,0]
 feasible=np.all(solutions@gf.T>=bf-1e-8,axis=1);valid=valid[feasible];solutions=solutions[feasible];prices=solutions@cf
 if not len(valid):raise RuntimeError('no numerical feasible candidate vertex')
 order=np.argsort(prices,kind='stable');best=prices[order[0]];attempts=0
 for p in order:
  if prices[p]>best+1e-7*max(1,abs(best)):break
  basis=combinations[int(valid[p])];B=[G[i] for i in basis];br=[right[i] for i in basis]
  try:
   x=solve_fraction(B,br);lamb=solve_fraction([list(col) for col in zip(*B)],cost)
  except ValueError:continue
  attempts+=1
  if min(x)<0 or min(lamb)<0:continue
  if any(sum(a*z for a,z in zip(g,x))<r for g,r in zip(G,right)):continue
  v=[F(0)]*ny
  for k,lam in zip(basis,lamb):
   if k<nr:v[owners[k]]+=lam
  C=bs*x[0] if offset else F(0);Z=[F(0)]*nx
  for i,original in enumerate(active):Z[original]=bs*x[offset+i]/scales[original]
  out=finish(C,Z,v,len(valid),'NumPy candidate active basis rebuilt by Fraction Gaussian elimination; exact original and dual constraints, zero gap')
  out['rational_bases_attempted']=attempts;return out
 raise RuntimeError('numerical optimum candidates lacked an exact primal/dual witness')
def summarize_model(c,H,epsilon,mode,scope):
 n=c['n'];m=c['vol'];U=[[F(c['soft'][x][y])/c['L'][x]**n for x in range(len(m))] for y in range(len(c['beta']))] if 'U' not in c else c['U'];beta=c['beta'];nu=c['nu'];ny=len(U);nx=len(m)
 sigma=[[[c['hard'][x][z]*(1 if mode=='allone' else int((x+2*y+3*z)%3!=0)) for z in range(len(nu))] for x in range(nx)] for y in range(ny)] if 'sigma' not in c else c['sigma']
 FIRST=[sum(beta[y]*U[y][x] for y in range(ny)) for x in range(nx)];ck(all(f<=1 for f in FIRST),'exact_shared_FIRST_feasibility',{'model':c['name']})
 radii=sorted(set(c['R']+[F(2)]));weights=[r**(-n)-(radii[i+1]**(-n) if i+1<len(radii) else 0) for i,r in enumerate(radii)];By=[F(0)]*ny;Ty=[F(0)]*ny;jensen=capG=F(0);active_gates=0
 for y in range(ny):Ty[y]=sum(m[x]*U[y][x]/c['R'][x]**n*sum(nu[z]*sigma[y][x][z] for z in range(len(nu))) for x in range(nx))
 for r,w in zip(radii,weights):
  ids=[x for x in range(nx) if c['R'][x]<=r];J=[sum(m[x]*U[y][x] for x in ids) for y in range(ny)]
  for z,v in enumerate(nu):
   A=[sum(m[x]*U[y][x]*sigma[y][x][z] for x in ids) for y in range(ny)];chi=[int(J[y]>=H and J[y]>0 and 8*A[y]<7*J[y]) for y in range(ny)];E=L=F(0)
   for y in range(ny):
    if chi[y]:
     square=sum(m[x]*U[y][x]*(F(sigma[y][x][z])-A[y]/J[y])**2 for x in ids)
     ck(square==A[y]-A[y]*A[y]/J[y],'exact_original_square_loss_equals_row_variance',{'model':c['name'],'row':y,'z':z,'r':str(r)})
     By[y]+=v*w*square;E+=beta[y]*J[y];L+=beta[y]*A[y];active_gates+=1
   Cgeo=sum(m[x]*FIRST[x]*c['hard'][x][z] for x in ids)
   ck(L<=Cgeo and (not E or 0<=L<=E),'exact_frozen_column_moment_capacity',{'model':c['name']})
   if E:
    jensen+=v*w*(L-L*L/E);q=min(Cgeo,E/2);capG+=v*w*(q-q*q/E)
 B=sum(b*y for b,y in zip(beta,By));T=sum(b*y for b,y in zip(beta,Ty));bvec=[b-epsilon*t for b,t in zip(By,Ty)];cert=lp_certificate(U,beta,bvec);receiver=lp_certificate(U,beta,bvec,True);rowonly=sum(beta)*max(F(0),max((bvec[y] for y in range(ny) if beta[y]>0),default=F(0)));bound=epsilon*T+cert['primal_value'];receiver_bound=epsilon*T+receiver['primal_value'];row_bound=epsilon*T+rowonly
 ck(B<=bound,'exact_actual_B_below_repaired_certificate',{'model':c['name']})
 ck(cert['primal_value']<=rowonly and cert['primal_value']<=receiver['primal_value'],'exact_joint_LP_no_worse_than_separate_budgets',{'model':c['name']})
 ck(B<=jensen<=capG,'exact_column_Jensen_and_cap_only_comparators',{'model':c['name']})
 if c['name']=='author_strict_mixed' and not epsilon:
  ck(B==F(169,2000) and bound==B and jensen==F(1771,20000),'author_exact_mixed_example_prices',{})
  ck(bound<row_bound and bound<receiver_bound and bound<jensen,'author_strict_joint_constraint_improvement',{})
  ck(cert['C']>0 and any(z>0 for z in cert['Z_equals_mP']),'author_nontrivial_C_and_shared_P',{})
 if not sum(beta):ck(bound==0 and receiver_bound==0 and row_bound==0 and cert['C']==0 and all(z==0 for z in cert['Z_equals_mP']),'zero_beta_exact_zero_joint_and_receiver_only_optima',{})
 return {'name':c['name'],'scope':scope,'n':n,'H':H,'epsilon':epsilon,'qualification_mode':mode,'U':U,'receiver_volumes':m,'R':c['R'],'L':c['L'],'beta':beta,'nu':nu,'FIRST':FIRST,'sigma':sigma,'gate_rule':'original frozen chi=1{J>=H,A/J<7/8}; original J unchanged','active_gate_entries':active_gates,'row_B':By,'row_T':Ty,'signed_row_b':bvec,'actual_B':B,'actual_T':T,'certificate_bound_epsilonT_plus_LP':bound,'signed_joint_LP':cert,'row_only_bound':row_bound,'receiver_only_bound':receiver_bound,'receiver_only_certificate':receiver,'old_column_actual_first_moment_Jensen':jensen,'old_column_cap_only_G':capG,'certificate_strictly_better_than_column_Jensen':bound<jensen,'certificate_strictly_better_than_column_G':bound<capG,'geometry':c.get('geometry',{})}
def author_model():
 return {'name':'author_strict_mixed','n':1,'vol':[F(1,20),F(1,20),F(4,5),F(1,5)],'U':[[F(10),F(10),F(0),F(0)],[F(0),F(0),F(1),F(1)]],'L':[F(1)]*4,'R':[F(1)]*4,'beta':[F(1,10),F(9,10)],'nu':[F(1,2)],'hard':[[1],[0],[1],[0]],'sigma':[[[1],[0],[0],[0]],[[0],[0],[1],[0]]],'geometry':{'classification':'finite occupation/shared-FIRST transport matrix only; no coordinate realization of full original soft-FIRST/history is certified'}}
initial=[]
for epsilon in [F(0),F(1,8),F(1)]:initial.append(summarize_model(author_model(),F(1),epsilon,'allone','abstract finite transport FIRST+binarycapture; not actual full soft-FIRST cube realization'))
for key in ['zero_nu','zero_beta']:
 c=author_model();c['name']=key;c['nu']=[F(0)] if key=='zero_nu' else c['nu'];c['beta']=[F(0),F(0)] if key=='zero_beta' else c['beta'];initial.append(summarize_model(c,F(1),F(0),'allone','degenerate finite transport matrix only'))
stages=[{'name':'initial_exact_transport_and_degenerate','cases':initial}]
for stage,specs in [('positive_cell_boundary',[('disjoint_n1',1,'disjoint'),('overlap_chain_n1',1,'chain'),('cross_n4',4,'cross'),('tied_n4',4,'tied')]),('expanded_positive_cell_dimension',[('cross_n8',8,'cross'),('cross_n16',16,'cross')])]:
 cases=[]
 for name,n,kind in specs:
  c=make(name,n,kind);c['geometry']={'coordinate_denominator':32,'receiver_centers_num':c['X'],'receiver_halfwidth_num':c['Ehalf'],'beta_centers_num':c['Y'],'nu_centers_num':c['Z'],'source_halfwidth_num':1,'hard_incidence':c['hard'],'soft_incidence':c['soft']};positive=sorted(set(v for v in c['I'] if v));Hs=sorted(set([positive[0]/2,positive[len(positive)//2]]))
  for H in Hs:
   for epsilon in [F(0),F(1,8)]:cases.append(summarize_model(c,H,epsilon,'binary_varying','true positive-volume L1 cube source/receiver cells, actual s=0 FIRST<=1 and same-radius hardcap<=4; frozen binary qualification is diagnostic, not full original history'))
 stages.append({'name':stage,'cases':cases})
def encode(x):
 if isinstance(x,F):return str(x)
 raise TypeError(type(x).__name__)
out={'status':'PASS' if not FAIL else 'FAIL','scope':'Finite exact signed row/shared-FIRST certificate. Numerical optimizer candidates are never treated as proof; exact Fraction primal feasibility, dual feasibility and zero gap certify each finite LP. True positive-L1 cube-cell cases are separated from abstract transport matrices. No full original low/e/m/history or general dimension/root conclusion.','formulation':'Z_x=m_x P_x>=0,C>=0; C+sum_x U_yx Z_x>=b_y=B_y-epsilon T_y only beta-positive rows (beta-a.e). Beta-null dual rows are fixed0; Wbeta=0 gives exact zero certificate. Min Wbeta C+sum Z. Dualv>=0,sumv<=Wbeta,sum_yv_yU_yx<=1; maxsumv b. FIRST with actual beta implies B<=epsilon T+primal certificate.','candidate_method':'NumPy batch vertex enumeration after rational column and RHS scaling. Selected numerical active basis and transpose rebuilt by Fraction Gaussian elimination; all beta-positive original rows and all columns checked exactly; beta-null row constraints are omitted. Zero signed-budget corners use zero certificate. No general strong-duality theorem is needed once exact primal and dual objectives coincide.','comparators':'Row-only=P0,C=max(0,max_(beta>0)b), zero if no beta-positive rows; receiver-only=C0 with its own exact LP. Old actual-column Jensen=sum nu w(L-L²/E); cap-onlyG uses min(Cgeo,E/2)-min(Cgeo,E/2)²/E, E=sum frozenchi beta J,L=sum frozenchi beta A,Cgeo=sum prefix m FIRST geometriccapture. No between-row variance in old Jensen.','environment':ENV,'check_counts':COUNTS,'failures':FAIL,'stages':stages}
base=Path(__file__);base.with_suffix('.json').write_text(json.dumps(out,default=encode,sort_keys=True,indent=2)+'\n');lines=['# R308 exact finite joint budget certificates','',out['scope'],'',out['formulation'],'',out['candidate_method'],'','|model|n|epsilon|actual B|joint bound|old column Jensen|row-only|receiver-only|','|---|---:|---:|---:|---:|---:|---:|---:|']
for st in stages:
 for c in st['cases']:lines.append(f"|{c['name']}|{c['n']}|{c['epsilon']}|{float(c['actual_B']):.7g}|{float(c['certificate_bound_epsilonT_plus_LP']):.7g}|{float(c['old_column_actual_first_moment_Jensen']):.7g}|{float(c['row_only_bound']):.7g}|{float(c['receiver_only_bound']):.7g}|")
lines+=['','The author-supplied abstract transport example has exact B=joint certificate169/2000, versus old column Jensen1771/20000, row-only1/8, receiver-only37/400. Its optimal certificate has both C>0 and some P>0. It shows why coupling row budgets to the shared FIRST columns can matter in finite algebra. It is not claimed as an original full soft-FIRST cube construction. Beta-null row constraints are omitted: the zero_beta example has both joint and receiver-only optimum0.','',out['comparators'],'','The six actual positive-volume cube-cell geometries are independently constructed and retain their original beta/FIRST and hard caps. Their binary source qualification is frozen by indices. Dimension expansion is only n=1,4,8,16; no fitted exponent or general source-root claim.','', 'Runtime: NumPy '+ENV['numpy_version']+'. SciPy optimize import status: '+ENV.get('scipy_optimize_error',ENV.get('scipy_optimize','unknown'))]
base.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':out['status'],'check_counts':COUNTS,'failures':FAIL,'cases':sum(len(s['cases']) for s in stages),'strict_vs_column_Jensen':sum(c['certificate_strictly_better_than_column_Jensen'] for s in stages for c in s['cases']),'strict_vs_column_G':sum(c['certificate_strictly_better_than_column_G'] for s in stages for c in s['cases'])},indent=2));assert not FAIL,FAIL
