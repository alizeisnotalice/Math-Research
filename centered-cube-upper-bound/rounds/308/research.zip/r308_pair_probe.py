from fractions import Fraction as F
from itertools import product
import json
counts={'models':0,'eligible_layers':0,'split':0,'hi_bound':0,'nonzero_hi':0,'nonzero_remaining':0};examples=[]
for stage,ns in [('initial',(1,2)),('endpoint_pressure',(4,8)),('expanded',(32,64))]:
 for n,caps,profile,frac,sep in product(ns,product((0,1),repeat=4),range(2),range(3),(F(3,2),F(2))):
  radii=[F(1),F(3,2),F(3,2),F(2)];u=[F(1),F(2),F(1,4),F(7)] if profile==0 else [F(1,1000),F(1),F(1000),F(2)]
  eps=F(1,64);eta=F(1,16);H=F(1,2)
  fractions=[eps/2,eps,eps/4,eps] if frac==0 else ([eps,eps,1,eps] if frac==1 else [1,eps/2,eps/4,1])
  hi=[v*t for v,t in zip(u,fractions)];lo=[v-h for v,h in zip(u,hi)]
  for r in sorted(set(radii)):
   ids=[i for i in range(4) if radii[i]<=r];J=sum(u[i] for i in ids);A=sum(u[i]*caps[i] for i in ids);Ah=sum(hi[i]*caps[i] for i in ids)
   if not(J>=H and eta*J<=A<F(7,8)*J and Ah<=eps*A):continue
   counts['eligible_layers']+=1
   # Fixed original pair allocation, disjoint far-gain and near domains.
   def near(w,v):return max(radii[w],radii[v])<sep*min(radii[w],radii[v])
   def gain(w,v):return radii[w]>=sep*radii[v]
   # Frozen anchor masks stand for arbitrary surviving qualification conditions.
   def mask(w,v):return F(near(w,v))*F((w+v)%3!=0)+F(gain(w,v))*F((2*w+v)%3!=1)
   def cost(weights):return sum(weights[w]*caps[w]*u[v]*(1-caps[v])*mask(w,v) for w in ids for v in ids)/J
   R=cost(u);Rl=cost(lo);Rh=cost(hi)
   assert R==Rl+Rh;counts['split']+=1
   assert 0<=Rh<=Ah*(J-A)/J<=Ah<=eps*A;counts['hi_bound']+=1
   counts['nonzero_hi']+=int(Rh>0);counts['nonzero_remaining']+=int(Rl>0)
  counts['models']+=1
coeff=1-16*F(1,64)
assert F(512)/coeff==F(2048,3) and F(16)/coeff==F(64,3)
print(json.dumps({'status':'PASS','counts':counts,'combined_coefficients':['2048/3','64/3'],'scope':'Finite conditional oriented-pair algebra; high shares are not claimed to realize actual spectral components. Original J and noncapturing U remain fixed. Spectral premise is analytic, not inferred from these finite models.'},indent=2))
