# R308 — true-soft capture tails pay a positive part of the R307 residual

## 1. Exact original interface and common-soft components

Fix one original outer instance and one actual binary qualification level. Retain arbitrary finite positive L1 sources beta,nu_*, original actual receiver fields sigma(x) in [0,1], a<=L(x),R(x)<=b<=2a, q(x)>=q_-=3lambda/4>0, accepted set E, and its z-independent row gate alpha(x,y) in [0,1]. Every original e,m, low/high, aspect, source/history and forbidden qualification is still computed from the FULL original sources and fields.

Use the actual one-dimensional profile

    h=1_[-1/2,1/2], w(t)=integral_0^1 exp(-|t|/u)du,
    phi=h*w, f_sigma=(1-sigma)h+sigma phi.

Let Q_k be the average of the n-dimensional product profiles with phi on exactly k coordinates and h on the others; Q_(k,L)(u)=L^(-n)Q_k(u/L). Then EXACTLY

    P_(sigma,L)=sum_(k=0)^n b_k(sigma)Q_(k,L),
    b_k(sigma)=binom(n,k)sigma^k(1-sigma)^(n-k).

Put c_(n,k)=max_sigma b_k(sigma). Its endpoint values are c_(n,0)=c_(n,n)=1; the other values are b_k(k/n). This is a single common softness, not independent coordinate maximization.

Define the ACTUAL component row densities

    U_(y,k)(x)=1_E(x)alpha(x,y)b_k(sigma(x))
                                      Q_(k,L(x))(x-y)/q(x),
    U_y=sum_k U_(y,k),
    J_y(r)=integral_(R(x)<=r)U_y(x)dx.

Let F_y(x,z) be the FULL original binary capture, including its actual hard-cube support and all binary qualification:

    0<=F_y(x,z)<=1{z in Q_(R(x))(x)}.

No qualification is recomputed componentwise. Set

    A_(k,yz)(r)=integral_(R(x)<=r)U_(y,k)(x)F_y(x,z)dx,
    A_yz(r)=sum_k A_(k,yz)(r), p_yz(r)=A_yz(r)/J_y(r).

Set p=0 on zero rows. Original FIRST implies the collective response integral_beta sum_k U_(y,k)(x)<=1 at actual receivers. It does not supply unweighted component FIRST. All components share the original q and full original J.

## 2. A genuine one-scale true-soft geometric bound

Let rho be the strict contraction proved in /tmp/r303_soft_gap.md:

    rho=1-2 integral_0^1 u exp(-3/(2u))du<1.

For every actual component, y,z and physical prefix r in [a,b],

    A_(k,yz)(r)<= [c_(n,k)rho^k/q_-]
                                      [1+n log(r/a)]. (1)

In particular, if A_hi=sum_(k>K)A_k and

    S_(n,K)(rho)=sum_(k=K+1)^n c_(n,k)rho^k,

then

    A_hi,yz(r)<=[1+n log(r/a)]S_(n,K)(rho)/q_-.        (2)

These bounds are uniform in the original receiver selectors and sigma, all source locations and masses, and both scale orientations. No FIRST or hard cap is transferred to a component. The actual binomial weights remain in A_k; only their positive upper envelope is used in proving (1).

Proof. Each Q_k is ray-decreasing. The R302 positive scale-envelope inequality gives, at the ACTUAL selected L,

    Q_(k,L(x))(x-y)<=K_k(x-y),
    K_k=Q_(k,b)+n integral_a^b Q_(k,L)dL/L.

If R(x)<=r and F_y(x,z)>0, then x belongs to the genuine fixed cube Q_r(z). Thus, after retaining all original gates until this positive domination,

    A_(k,yz)(r)<=c_(n,k)/q_- integral_(Q_r(z))K_k(x-y)dx.

The true soft-coordinate contraction gives for every L,r in [a,b]

    (Q_(k,L)*h_r)(z-y)<=rho^k max(L,r)^(-n),

where h_r is the NORMALIZED hard cube. Consequently the last cube integral is at most

    rho^k r^n [b^(-n)+n integral_a^b max(L,r)^(-n)dL/L].

Splitting the integral at r evaluates the bracket EXACTLY:

    b^(-n)+n r^(-n)log(r/a)
          +n integral_r^b L^(-n)dL/L
       =r^(-n)[1+n log(r/a)].                          (3)

This proves (1) and then (2). There is ONLY a soft-scale envelope here: the hard prefix is contained in Q_r. No second scale-envelope amplitude or arbitrary receiver convolution substitution occurs. The actual phi and shared-soft coefficients are essential to the rho^k loss.

## 3. A uniform cutoff and paid middle-capture perturbation

Fix H>0, 0<eta<7/8 and 0<epsilon<1. Retain the ORIGINAL middle gate

    G_mid(y,z,r)=1{J_y(r)>=H, eta<=p_yz(r)<7/8}.

Let A_n=1+n log(b/a). A certified rational choice is rho_bar=19/20>=rho, established in R304 from the TRUE rho; any separately certified smaller upper bound may replace it. Choose the SINGLE cutoff

    k_*=min{K in {0,...,n}:
          S_(n,K)(rho_bar)<=epsilon eta q_- H/A_n}.    (4)

It exists because S_(n,n)=0. K=0 retains the hard component only; K=n has empty high tail. The SAME k_* works for every y,z,r and every binary qualification level using this outer instance. It is not a source-dependent favorable selector.

Keep actual component weights and define A_lo=sum_(k<=k_*)A_k, A_hi=A-A_lo. On the ORIGINAL middle gate, (2),(4) imply

    A_hi<=epsilon eta H<=epsilon eta J<=epsilon A.    (5)

The first inequality uses 1+n log(r/a)<=A_n. This is not a source-mass bound: no b_D(z), W_beta normalization, source density or source ordering occurs.

### 3A. Positive capturing-anchor split of the ACTUAL R307 residual

Use the exact R307 remaining positive sum R_theta=G_theta^res+B_theta^near,res from /tmp/r307_combined.md. Its oriented binary form is

    R_theta=integral beta(dy)nu_*(dz)ell_n(dr)chi_theta(y,z,r)/J_y(r)
      integral_(R(w),R(u)<=r) U_y(w)F_y(w,z)
             U_y(u)[1-F_y(u,z)]M_theta(y,z,r,w,u)dw du, (P1)

where chi_theta=1{J>=H,p_theta<7/8}. EVERY original R307 rho/quiet/persistent/rapid and history gate remains in M_theta. The gain support has R(w)>=s R(u), while strict-near support has max(R(w),R(u))<s min(R(w),R(u)); these two supports are disjoint. Their residual multipliers are in [0,1], so 0<=M_theta<=1, with no factor two. Equal-radius pairs are in the near component. All M,chi,J and the noncapturing density are fixed from the original field BEFORE the following split. The new lower capture threshold eta is independent of R307's earlier paid-branch parameters; their gates are not recomputed.

Partition (P1) by full p_theta<eta and eta<=p_theta<7/8. On the latter part split ONLY the capturing density U_y(w)=U_y,lo(w)+U_y,hi(w), using its actual shared-soft coefficients. This gives an EXACT POSITIVE decomposition

    R_theta=R_theta,lowp+R_theta,mid,lo+R_theta,mid,hi.  (P2)

The noncapturing factor U_y(u)[1-F_y(u,z)], full denominator J, original gate chi and M are unchanged. At every middle prefix,

    capturing_hi_pair_integral/J
        <=A_hi(r)[J(r)-A(r)]/J(r)
        <=A_hi(r)<=epsilon A(r).                     (P3)

The first inequality simply drops M<=1 and integrates the two ORIGINAL prefix marginals. Integrating proves the genuine positive payment

    0<=R_theta,mid,hi<=epsilon T_theta.               (P4)

No variance is subtracted here. The low term in (P2) retains every softness degree. The mid,lo term has bounded soft degree ONLY AT ITS CAPTURING ENDPOINT; the entire noncapturing endpoint still uses the full original U and original missed capture. It is not an independently normalized low-k binary problem.

The same uniform k_* works at all common binary qualification levels theta. Averaging their original weights of total mass one gives R=R_lowp+R_mid,lo+R_mid,hi and R_mid,hi<=epsilon T. Thus the already proved R307 entry

    Lambda T<=512Lambda lambda d W_beta+16Lambda R

is preserved, with no repeated R307 payment. Choosing epsilon=1/64 gives

    Lambda T<=(2048/3)Lambda lambda d W_beta
                       +(64/3)Lambda[R_lowp+R_mid,lo]. (P5)

This is finite internal absorption of 16epsilon Lambda T=Lambda T/4. It does not use or certify a global lambda|E| entry. The source coefficient and original d=kappa0 psi_inf/(q_-v0) retain their original scale/aspect costs. In that R307 application H=8d, hence q_- H=8kappa0 psi_inf/v0; this quantity has no unproved polynomial lower bound.

### 3B. A secondary absolute-stability corollary

Independently define the ORIGINAL middle fee and the reduced RESPONSE functional

    B_mid=integral beta(dy)nu_*(dz)ell_n(dr)G_mid
                                         [A-A^2/J],
    B_mid,lo=integral beta(dy)nu_*(dz)ell_n(dr)G_mid
                                     [A_lo-A_lo^2/J],
    ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr.

All denominators and gates are STILL the original J,p. In particular A_lo is not declared binary capture under a new row law; J is not recomputed and G_mid is not replaced by a gate on A_lo/J.

For 0<=A_lo<=A<=J,

    [A-A^2/J]-[A_lo-A_lo^2/J]
                   =A_hi[1-(A+A_lo)/J],
    absolute_value_of_this_difference<=A_hi.          (6)

The difference can be NEGATIVE. The absolute bound, together with (5), proves the genuine payment

    |B_mid-B_mid,lo|<=epsilon integral G_mid A d(beta nu_* ell_n)
                    <=epsilon T,                     (7)

where T=integral A d(beta nu_* ell_n) is the SAME finite exact binary target. Finiteness follows from original FIRST, T<=A_n W_(nu_*). Equation (7) retains the negative square in the low-component response instead of dropping the capture overlap.

At original incidence coefficient C_B Lambda the error costs at most C_B epsilon Lambda T. It is internally absorbable only within an already valid finite-target inequality for that same T; no global lambda|E| entry is certified. At common qualification thresholds apply (7) levelwise and average with the ORIGINAL weights of total mass one. This spends epsilon T once, not once per k or binary level. At a more general outer instance keep its original positive multiplier inside the outer integral.

## 4. Degree cost, exact limitations, and complete remaining branches

Since c_(n,k)<=1,

    S_(n,K)(rho_bar)<=rho_bar^(K+1)/(1-rho_bar).

Therefore the exact minimal cutoff in (4) satisfies

    k_*<=min(n,ceil(log_+[rho_bar A_n/
           ((1-rho_bar)epsilon eta q_- H)]/log(1/rho_bar))). (8)

Here log_+x=max(0,log x). q_- H is NOT assumed polylogarithmic. In a full octave A_n<=1+n log2; if, additionally, q_- H>=n^(-C) and epsilon eta>=n^(-C') with fixed constants, (8) gives O(log(n+2)). Without such a lower bound on q_- H, no uniform small-degree assertion is justified. Even for moderate n and acceptable parameters the conservative cutoff can equal n. Indeed the EXACT criterion k_*=n is

    rho_bar^n>epsilon eta q_- H/A_n,

because the last nonzero tail term is c_(n,n)rho_bar^n=rho_bar^n. Thus this is a conditional logarithmic-degree reduction, not a claim that numerical degree is always small.

The COMPLETE high-prefix fee splits into p<eta, eta<=p<7/8, and p>=7/8. This note replaces ONLY the middle functional up to (7). The low-capture fee

    B_low=integral beta(dy)nu_*(dz)ell_n(dr)
                      1{J>=H,p<eta}[A-A^2/J]          (9)

retains ALL original softness degrees and is UNPAID here. The high-capture contribution has the separate R305 receipt <=T/8. If these are used together at coefficient C_B Lambda, the accurate expense is C_B(1/8+epsilon)Lambda T, plus C_B Lambda[B_low+B_mid,lo]. One may not drop B_low or claim an absorptive coefficient without checking the surrounding finite-target inequality.

Neither the reduced B_mid,lo nor the positive R_mid,lo in (P5) is paid at root order. Each still has its actual weights, the original full-row denominator and original capture/history geometry. No application to independently normalized components, replaced sources or a low-k maximal theorem has been supplied. The primary payment is the POSITIVE high-degree capturing-anchor piece (P4), preserving all R307 progress; (7) is only an alternative absolute-stability corollary. This differs from R304's source-column-dependent tail cutoff and from R305 scalar re-columning. The old generic row/column variational algebra is not reproduced here; that is independently handled by the main author.

## 5. Actual bounded checks and minimal reproduction

Stock local Python lacked mpmath, so the successful checks used its standard-library exact Fractions and 60-digit Decimal arithmetic. The actual runs passed 16 one-scale endpoint-normalization checks, 60 EXACT minimal-tail-cutoff checks, 126 EXACT variance-perturbation checks, and 1536 EXACT positive capturing-anchor splitting checks. The cutoff tests use the rigorous upper A_n<=1+n for b/a<=2, including q_- H=10^(-6),1,10^6 and k_*=n cases. Decimal checks evaluate the explicit antiderivative (3), not a new quadrature proof. The positive-pair checker includes same-R distinct receivers, the full p<7/8 gate, and unmodified noncapturing mass. Its component masses enforce the already proved prefix cap abstractly; it is not a certificate of original-kernel realization. The analytic argument above proves the all-input theorem; finite tests diagnose constants, endpoints and signs.

```python
from fractions import Fraction as F
from math import comb
from decimal import Decimal as D,getcontext
from itertools import product
getcontext().prec=60
scale_count=0
for n in (1,2,16,128):
 for r in map(D,('1','1.25','1.75','2')):
  a=D(1);b=D(2)
  integral=b**(-n)+n*((r/a).ln()*r**(-n)
                         +(r**(-n)-b**(-n))/n)
  target=r**(-n)*(1+n*(r/a).ln())
  assert abs(integral-target)<=D('1e-55')*max(D(1),abs(target))
  scale_count+=1
cut_count=perturb_count=0;rho=F(19,20)
for n in (1,2,8,32,128):
 c=[F(1) if k in (0,n) else
    comb(n,k)*F(k,n)**k*F(n-k,n)**(n-k) for k in range(n+1)]
 tails=[sum((c[k]*rho**k for k in range(j+1,n+1)),F(0))
        for j in range(n+1)]
 Aupper=F(1+n)
 for eps,eta,qH in product([F(1,10),F(1,100)],
               [F(1,8),F(1,4)],[F(1,10**6),F(1),F(10**6)]):
  tau=eps*eta*qH/Aupper
  k=next(j for j in range(n+1) if tails[j]<=tau)
  assert Aupper*tails[k]<=eps*eta*qH
  if k: assert tails[k-1]>tau
  cut_count+=1
for J,eta,eps,p in product([F(1),F(2),F(10)],
 [F(1,8),F(1,4)],[F(1,10),F(1,100)],
 [F(1,8),F(1,4),F(1,2),F(3,4)]):
 if p<eta: continue
 A=p*J
 for hi in (F(0),eps*eta*J/2,eps*eta*J):
  lo=A-hi
  assert 0<=lo<=A<=J
  value=lambda x:x-x*x/J
  assert abs(value(A)-value(lo))<=hi<=eps*A
  perturb_count+=1
print('PASS',dict(scale_identity=scale_count,
 exact_tail_cutoff=cut_count,variance_perturbation=perturb_count))
# actual: 16, 60, 126
```

The positive-component reproduction is:

```python
from fractions import Fraction as F
from itertools import product
R=[F(1),F(3,2),F(3,2),F(2)]
U=[F(1,4),F(1,3),F(1,5),F(1,7)]
levels=sorted(set(R));Jb=sum(U);ct=0
for n,H,eta,eps,cap,kind in product(
 [1,2,8,32],[F(1,10),F(1,2)],[F(1,8),F(1,4)],
 [F(1,64),F(1,100)],product([0,1],repeat=4),range(3)):
 frac=eps*eta*H/Jb
 Uh=[frac*u for u in U];Ul=[u-v for u,v in zip(U,Uh)]
 T=sum(U[i]*cap[i]*R[i]**(-n) for i in range(4))
 total=low=midlo=midhi=F(0)
 for k,r in enumerate(levels):
  I=[i for i in range(4) if R[i]<=r]
  J=sum(U[i] for i in I);A=sum(U[i]*cap[i] for i in I)
  if J<H or A/J>=F(7,8): continue
  weight=r**(-n)-(levels[k+1]**(-n) if k+1<len(levels) else 0)
  def M(i,j):
   if kind==0: return F(1)
   if kind==1:
    return F(int(max(R[i],R[j])<F(3,2)*min(R[i],R[j])
                 or R[i]>=F(3,2)*R[j]))
   return F((i+j)%2)
  def pair(V):
   return sum(V[i]*cap[i]*U[j]*(1-cap[j])*M(i,j)
               for i in I for j in I)/J
  total+=weight*pair(U)
  if A/J<eta: low+=weight*pair(U)
  else:
   hi=weight*pair(Uh);lo=weight*pair(Ul)
   assert hi<=weight*sum(Uh[i]*cap[i] for i in I)*(J-A)/J
   midhi+=hi;midlo+=lo
 assert total==low+midlo+midhi and 0<=midhi<=eps*T
 ct+=1
print('PASS positive_capturing_anchor_split',ct)  # actual: 1536
```

Only /tmp/r308_joint_capacity.md was written. Other authors' files and Git were preserved.
