# R308：在原剩余积分中支付中捕获层的高次数捕获端

## 目标、原输入与本轮进展

仍以任意正L1输入的一般 n^(1/2+o(1)) 一致弱型界为目标，未闭合。本轮沿用R307的真实剩余积分，不重新计算来源、原资格、FIRST或前缀门。证明其中一个全输入正子项可支付：在原捕获比例p_theta>=eta_mid的层上，捕获端的高次数软分量费用<=epsilon T。阈值不依赖来源总质量或局部密度。未捕获端不截断；这不是把整个问题归约为低维或固定次数。

所有公式先在共同有限截断上，随后仅以正积分/支配收敛处理合法极限。固定原外层配置、nu的原冻结正限制，a<=L,R<=b<=2a，q>=q_->0。U=alpha 1_E P_(s,L)/q，0<=I0<=alpha<=1，alpha不依赖z；sigma_theta为R305共同阈值的原二值合资格捕获，J为原U的完整前缀，A为原U sigma的前缀。保留原源和历史；theta总权重1。

## 1. 真正的一重尺度捕获上界

原共同softness展开为P_s,L=Σ_(k=0)^n b_nk(s) q_k,L。q_k平均所有恰含k个真实软坐标的张量；b_nk(s)=binom(n,k)s^k(1-s)^(n-k)，c_nk=max_s b_nk(s)<=1。不得优化各坐标的独立s。

R303的真实重叠给q_k,L*h_r <=rho^k/max(L,r)^n，rho=1−2∫_0^1 u exp(−3/(2u))du。对原prefix尺度t，捕获且R<=t的接收器必在Q_t(z)中。保留actual系数后再用b_nk<=c_nk、原正软尺度包络q_k,b+n∫_a^b q_k,L dL/L：

A_k(y,z;t) <= c_nk rho^k [1+n log(t/a)]/q_-。

因为其在Q_t(z)上的积分是至多rho^k[(t/b)^n+n log(t/a)+1−(t/b)^n]，端点与尾段正好相加。本处只有一套软尺度包络，不能再重复支付硬尺度费用；硬捕获域已用真实Q_t(z)控制。这是接收积分，不是薄层体积乘来源密度。

写A_n=1+n log(b/a)，S_n,K(rho_bar)=Σ_(k>K)c_nk rho_bar^k。任何已证rho_bar>=rho, rho_bar<1都可用。取

K=min{j in {0,...,n}: A_n S_n,j(rho_bar)<=epsilon eta_mid q_-H}。

该集合非空，因为j=n尾为0。K与y,z及来源总质量无关，但依赖n,epsilon,eta_mid,q_-H。可用几何尾rho_bar^(K+1)/(1−rho_bar)给显式充分截断；在这些参数的倒数至多n的固定幂时，K=min(n,O(log n))。没有无条件宣称K很小。

## 2. 原R307余项正分裂，所有已付部分保留

R307令H=8d，分离比s^n=8，eta_gain=1/32。其余项R_theta=G_res+B_near,res可精确写为

R_theta =∫ beta(dy)nu(dz)ell_n(dt) chi_theta(y,z;t)/J_y(t)
  ×∫_(R(w),R(u)<=t) U_y(w)sigma(w) U_y(u)[1−sigma(u)] M_theta(y,z,w,u)dwdu。

chi保留J>=H、p_theta=A/J<7/8。M是R307未付far-gain与未付near的原分配指示：两个半径区域不交，因此0<=M<=1。M内的rho、小窗增长、quiet条件全按原U/J计算，不随下述分裂改变。近尺度保留等半径原子；far-gain包含分离等号。

定义实际加权高次数U_hi=alpha1_E/q Σ_(k>K)b_nk(s(x))q_k,L(x)，U_lo=U−U_hi。只在捕获端w拆U，未捕获端u仍是完整U。再把原prefix层按p<eta_mid和eta_mid<=p<7/8分开，得到精确正分裂

R_theta=R_low-p +R_mid,lo-capture +R_mid,hi-capture。

在原中捕获层A>=eta_mid J>=eta_mid H，而第一节给A_hi<=epsilon eta_mid H<=epsilon A。因此逐层

R_mid,hi层 <= A_hi(J−A)/J <=A_hi<=epsilon A。

积分与原层恒等式∫ell beta nu A=T_theta给R_mid,hi<=epsilon T_theta。theta积分只付一份epsilon T。既未把A_lo当成二值捕获重新应用R306，也未给予单个无权soft分量FIRST。原J和gate均未改变。

## 3. 原预算回代

R307的已审计入口是
Lambda T <=512 Lambda lambda d W_beta+16 Lambda ∫_0^1 R_theta dtheta。

取epsilon=1/64（与eta_gain不同；例如eta_mid=1/16），移项得

Lambda T <=(2048/3) Lambda lambda d W_beta
 +(64/3) Lambda ∫_0^1 [R_low-p+R_mid,lo-capture]dtheta。

这个新付款在原R307余项上生效，未重复使用远失捕、quiet或rapid收益。它仍是内部T吸收，全局原X误差系数新增0。d=kappa0 psi_inf/(q_-v0)的全部逆尺度比费用保留。未付低p和低次数捕获端仍有完整未捕获软端、原来源/历史与真实dx；一般根阶预算尚未得到。

## 4. 可执行来源容量证书，供剩余几何估计使用

另见r308_geometry.md。精确保留二次捕获后，可将共同theta先按原权重整合成每行b_y=B_y−epsilon T_y。若非负共享接收势P(x)和C满足b_y<=C+∫U_y P dx，则原FIRST一次给B<=epsilon T+C W_beta+∫P dx。有限模型以Z_x=m_xP_x化为线性规划：b_y<=C+Σ_x U_yx Z_x，目标W_beta C+Σ_x Z_x。非负对偶v满足Σv<=W_beta、ΣvU<=1；精确可行及零gap可认证有限最优。

主推导去掉了不必要的正部损失：有符号行预算中，平方拟合参数h=A/J逐行同时最优，故不需解更松的非线性问题。全过程只调用弱证书；没有假设无限维强对偶、一般根阶可行势或把对偶重新加权当成合法新输入。有限几何模型证书仅用于决定如何利用共享FIRST容量，不代表全输入证明。此处B指未拆的R305方差备选预算；若将LP用于第三节的新余项，必须以该余项的实际行费用重新定义b_y，并按64/3入口回代，不能自动保留h=A/J的平方消元恒等式。

## 5. 本机计算与未解决问题

主程序tail_probe用Fraction证明rho<=9/10：在u∈[j/16,(j+1)/16],j=8,...,15上以exp(−24/j)下界指数，exp(x)用18阶正Taylor和几何余项上界。对应2u积分权(2j+1)/256；有理下和>1/10，故rho<9/10。该常数改进只用于实际探路，不作为额外理论突破。

三阶段n=1,4,16；32,64,128；256,512,1024，epsilon/eta各两组，qH取n^-2、1、n²：2100项尾/阈值检查及456项方差Lipschitz检查通过。192例方差差为负，说明一般差值只能按绝对误差处理；本轮原pair正分裂避免了该符号问题。例epsilon1/32、eta1/16、qH=1时，n128的精确K=107，n1024的K=115；小维或很小qH仍可K=n。该表不是维数阶拟合；O(log n)来自解析几何尾，且有参数条件。

主pair_probe另跑1152个条件原子模型，444个满足原middle/tail前提的层中精确正分裂和high-bound均通过，372层实际高分量非零。模型仅检验pair代数，不声称任意给定高份额来自真实谱分量；真实谱前提由第一节解析证明提供。

继续保留R304完整原总账：原全事件入口、后续采用误差表、极小尺度比、宽距离连续、初始、真正删除时间原子、未来被删来源及负项一次结算。主攻剩余真实来源几何容量，未宣称闭合。使用64项技能B01/L04的弱证书与精确可行核验纪律；不编译PDF。未获得实际扣额数据，不猜测模型成本。
