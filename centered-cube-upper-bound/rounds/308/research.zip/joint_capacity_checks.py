from fractions import Fraction as F
from math import comb
from decimal import Decimal as D,getcontext
from itertools import product
getcontext().prec=60
scale_count=0
for n in (1,2,16,128):
 for r in map(D,('1','1.25','1.75','2')):
  a=D(1);b=D(2)
  integral=b**(-n)+n*((r/a).ln()*r**(-n)
                         +(r**(-n)-b**(-n))/n)
  target=r**(-n)*(1+n*(r/a).ln())
  assert abs(integral-target)<=D('1e-55')*max(D(1),abs(target))
  scale_count+=1
cut_count=perturb_count=0;rho=F(19,20)
for n in (1,2,8,32,128):
 c=[F(1) if k in (0,n) else
    comb(n,k)*F(k,n)**k*F(n-k,n)**(n-k) for k in range(n+1)]
 tails=[sum((c[k]*rho**k for k in range(j+1,n+1)),F(0))
        for j in range(n+1)]
 Aupper=F(1+n)
 for eps,eta,qH in product([F(1,10),F(1,100)],
               [F(1,8),F(1,4)],[F(1,10**6),F(1),F(10**6)]):
  tau=eps*eta*qH/Aupper
  k=next(j for j in range(n+1) if tails[j]<=tau)
  assert Aupper*tails[k]<=eps*eta*qH
  if k: assert tails[k-1]>tau
  cut_count+=1
for J,eta,eps,p in product([F(1),F(2),F(10)],
 [F(1,8),F(1,4)],[F(1,10),F(1,100)],
 [F(1,8),F(1,4),F(1,2),F(3,4)]):
 if p<eta: continue
 A=p*J
 for hi in (F(0),eps*eta*J/2,eps*eta*J):
  lo=A-hi
  assert 0<=lo<=A<=J
  value=lambda x:x-x*x/J
  assert abs(value(A)-value(lo))<=hi<=eps*A
  perturb_count+=1
print('PASS',dict(scale_identity=scale_count,
 exact_tail_cutoff=cut_count,variance_perturbation=perturb_count))
# actual: 16, 60, 126


from fractions import Fraction as F
from itertools import product
R=[F(1),F(3,2),F(3,2),F(2)]
U=[F(1,4),F(1,3),F(1,5),F(1,7)]
levels=sorted(set(R));Jb=sum(U);ct=0
for n,H,eta,eps,cap,kind in product(
 [1,2,8,32],[F(1,10),F(1,2)],[F(1,8),F(1,4)],
 [F(1,64),F(1,100)],product([0,1],repeat=4),range(3)):
 frac=eps*eta*H/Jb
 Uh=[frac*u for u in U];Ul=[u-v for u,v in zip(U,Uh)]
 T=sum(U[i]*cap[i]*R[i]**(-n) for i in range(4))
 total=low=midlo=midhi=F(0)
 for k,r in enumerate(levels):
  I=[i for i in range(4) if R[i]<=r]
  J=sum(U[i] for i in I);A=sum(U[i]*cap[i] for i in I)
  if J<H or A/J>=F(7,8): continue
  weight=r**(-n)-(levels[k+1]**(-n) if k+1<len(levels) else 0)
  def M(i,j):
   if kind==0: return F(1)
   if kind==1:
    return F(int(max(R[i],R[j])<F(3,2)*min(R[i],R[j])
                 or R[i]>=F(3,2)*R[j]))
   return F((i+j)%2)
  def pair(V):
   return sum(V[i]*cap[i]*U[j]*(1-cap[j])*M(i,j)
               for i in I for j in I)/J
  total+=weight*pair(U)
  if A/J<eta: low+=weight*pair(U)
  else:
   hi=weight*pair(Uh);lo=weight*pair(Ul)
   assert hi<=weight*sum(Uh[i]*cap[i] for i in I)*(J-A)/J
   midhi+=hi;midlo+=lo
 assert total==low+midlo+midhi and 0<=midhi<=eps*T
 ct+=1
print('PASS positive_capturing_anchor_split',ct)  # actual: 1536
