from fractions import Fraction as F
from math import comb, factorial
import json
# Exact lower Riemann sum for 2 integral_0^1 u exp(-3/(2u))du.
# On u in [j/16,(j+1)/16], exponential >=exp(-24/j).
# Positive Taylor series and geometric remainder give an upper bound on exp(x).
exp_tail_lower=F(0)
for j in range(8,16):
 x=F(24,j);N=18
 upper_exp=sum((x**k/F(factorial(k)) for k in range(N+1)),F(0))+x**(N+1)/F(factorial(N+1))/(1-x/F(N+2))
 exp_tail_lower+=F(2*j+1,256)/upper_exp
assert exp_tail_lower>F(1,10)
rho=F(9,10);rows=[];checks=0
for stage,ns in [('initial',(1,4,16)),('parameter_pressure',(32,64,128)),('expanded',(256,512,1024))]:
 for n in ns:
  c=[F(1) if k in (0,n) else comb(n,k)*F(k,n)**k*F(n-k,n)**(n-k) for k in range(n+1)]
  tail=[F(0)]*(n+1)
  for j in range(n-1,-1,-1):tail[j]=tail[j+1]+c[j+1]*rho**(j+1)
  for j in range(n+1):
   assert tail[j]<=rho**(j+1)/(1-rho);checks+=1
  for qH in (F(1,n*n),F(1),F(n*n)):
   for eps,eta in ((F(1,32),F(1,16)),(F(1,128),F(1,64))):
    # use rigorous An <=1+n for b/a<=2
    threshold=eps*eta*qH/F(1+n)
    K=next(j for j in range(n+1) if tail[j]<=threshold)
    Kgeo=next((j for j in range(n) if rho**(j+1)/(1-rho)<=threshold),n)
    assert K<=Kgeo<=n and F(1+n)*tail[K]<=eps*eta*qH;checks+=1
    rows.append(dict(stage=stage,n=n,qH=str(qH),epsilon=str(eps),eta=str(eta),K_exact=K,K_geometric=Kgeo,nonempty_low_core=K<n))
# Exact variance perturbation for arbitrary old gates: absolute, not monotonic.
variance_checks=negative=0
for J in (F(1,8),F(1),F(8)):
 for i in range(1,17):
  A=J*F(i,16)
  for j in range(i+1):
   hi=J*F(j,16);lo=A-hi
   diff=A-A*A/J-(lo-lo*lo/J)
   assert abs(diff)<=hi;variance_checks+=1;negative+=int(diff<0)
print(json.dumps(dict(status='PASS',certified_rho_upper=str(rho),exp_tail_lower=str(exp_tail_lower),tail_checks=checks,variance_checks=variance_checks,negative_difference_cases=negative,records=rows),indent=2))
