# R308 exact finite joint budget certificates

Finite exact signed row/shared-FIRST certificate. Numerical optimizer candidates are never treated as proof; exact Fraction primal feasibility, dual feasibility and zero gap certify each finite LP. True positive-L1 cube-cell cases are separated from abstract transport matrices. No full original low/e/m/history or general dimension/root conclusion.

Z_x=m_x P_x>=0,C>=0; C+sum_x U_yx Z_x>=b_y=B_y-epsilon T_y only beta-positive rows (beta-a.e). Beta-null dual rows are fixed0; Wbeta=0 gives exact zero certificate. Min Wbeta C+sum Z. Dualv>=0,sumv<=Wbeta,sum_yv_yU_yx<=1; maxsumv b. FIRST with actual beta implies B<=epsilon T+primal certificate.

NumPy batch vertex enumeration after rational column and RHS scaling. Selected numerical active basis and transpose rebuilt by Fraction Gaussian elimination; all beta-positive original rows and all columns checked exactly; beta-null row constraints are omitted. Zero signed-budget corners use zero certificate. No general strong-duality theorem is needed once exact primal and dual objectives coincide.

|model|n|epsilon|actual B|joint bound|old column Jensen|row-only|receiver-only|
|---|---:|---:|---:|---:|---:|---:|---:|
|author_strict_mixed|1|0|0.0845|0.0845|0.08855|0.125|0.0925|
|author_strict_mixed|1|1/8|0.0845|0.0845|0.08855|0.141875|0.0875|
|author_strict_mixed|1|1|0.0845|0.385|0.08855|0.385|0.385|
|zero_nu|1|0|0|0|0|0|0|
|zero_beta|1|0|0|0|0|0|0|
|disjoint_n1|1|0|0|0|0|0|0|
|disjoint_n1|1|1/8|0|0|0|0|0|
|disjoint_n1|1|0|0|0|0|0|0|
|disjoint_n1|1|1/8|0|0|0|0|0|
|overlap_chain_n1|1|0|0.1340025|0.2616669|0.1870073|0.6235851|0.2616669|
|overlap_chain_n1|1|1/8|0.1340025|0.2632178|0.1870073|0.5777389|0.2632178|
|overlap_chain_n1|1|0|0.1340025|0.2616669|0.1646415|0.6235851|0.2616669|
|overlap_chain_n1|1|1/8|0.1340025|0.2632178|0.1646415|0.5777389|0.2632178|
|cross_n4|4|0|3.74024e-05|0.000109193|9.266019e-05|0.0002320787|0.000109193|
|cross_n4|4|1/8|3.74024e-05|8.298277e-05|9.266019e-05|0.0001015379|8.298277e-05|
|cross_n4|4|0|3.728089e-05|0.000109193|8.632459e-05|0.0002320787|0.000109193|
|cross_n4|4|1/8|3.728089e-05|8.298277e-05|8.632459e-05|0.0001015379|8.298277e-05|
|tied_n4|4|0|4.757327e-05|0.0004349574|6.559596e-05|0.0007927528|0.0004358603|
|tied_n4|4|1/8|4.757327e-05|0.000411926|6.559596e-05|0.0006839133|0.000411926|
|tied_n4|4|0|4.733732e-05|0.0004301031|6.481577e-05|0.0007927528|0.0004301031|
|tied_n4|4|1/8|4.733732e-05|0.000411926|6.481577e-05|0.0006839133|0.000411926|
|cross_n8|8|0|8.425133e-11|2.480888e-10|9.178501e-11|5.2062e-10|2.480888e-10|
|cross_n8|8|1/8|8.425133e-11|1.400325e-09|9.178501e-11|1.570797e-09|1.400325e-09|
|cross_n8|8|0|8.113639e-11|2.480888e-10|8.483501e-11|5.2062e-10|2.480888e-10|
|cross_n8|8|1/8|8.113639e-11|1.400325e-09|8.483501e-11|1.570797e-09|1.400325e-09|
|cross_n16|16|0|4.880288e-22|1.216907e-21|4.927771e-22|2.057051e-21|1.216907e-21|
|cross_n16|16|1/8|4.880288e-22|3.04949e-18|4.927771e-22|3.050224e-18|3.04949e-18|
|cross_n16|16|0|4.878394e-22|1.216907e-21|4.893872e-22|2.057051e-21|1.216907e-21|
|cross_n16|16|1/8|4.878394e-22|3.04949e-18|4.893872e-22|3.050224e-18|3.04949e-18|

The author-supplied abstract transport example has exact B=joint certificate169/2000, versus old column Jensen1771/20000, row-only1/8, receiver-only37/400. Its optimal certificate has both C>0 and some P>0. It shows why coupling row budgets to the shared FIRST columns can matter in finite algebra. It is not claimed as an original full soft-FIRST cube construction. Beta-null row constraints are omitted: the zero_beta example has both joint and receiver-only optimum0.

Row-only=P0,C=max(0,max_(beta>0)b), zero if no beta-positive rows; receiver-only=C0 with its own exact LP. Old actual-column Jensen=sum nu w(L-L²/E); cap-onlyG uses min(Cgeo,E/2)-min(Cgeo,E/2)²/E, E=sum frozenchi beta J,L=sum frozenchi beta A,Cgeo=sum prefix m FIRST geometriccapture. No between-row variance in old Jensen.

The six actual positive-volume cube-cell geometries are independently constructed and retain their original beta/FIRST and hard caps. Their binary source qualification is frozen by indices. Dimension expansion is only n=1,4,8,16; no fitted exponent or general source-root claim.

Runtime: NumPy 2.3.5. SciPy optimize import status: ImportError: dlopen(/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime/scipy/sparse/linalg/_propack/_spropack.cpython-312-darwin.so, 0x0002): tried: '/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime/scipy/sparse/linalg/_propack/_spropack.cpython-312-darwin.so' (section '__DATA/__thread_bss' has a zero-fill section type, but offset field is not zero), '/System/Volumes/Preboot/Cryptexes/OS/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime/scipy/sparse/linalg/_propack/_spropack.cpython-312-darwin.so' (no such file), '/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime/scipy/sparse/linalg/_propack/_spropack.cpython-312-darwin.so' (section '__DATA/__thread_bss' has a zero-fill section type, but offset field is not zero)
