# R308 independent preauthor audit

Independent screen: PASS for the proposed sufficient certificate. This derivation was saved before reading any new R308 author proof. No existence of root-sized constants or generic strong duality is asserted.

## Variance identity, quantifiers and measurable minimizer

Fix the entire original field, original positive common binary threshold, actual sources beta and nu_* and actual radius selector; all full e/m/history and source qualifications remain unchanged. U_y(x)=1_E alpha p_y/q is the ORIGINAL row density, with 0<=I0<=alpha<=1, alpha independent of z, and original FIRST integral U_y beta<=1_E. Let sigma(x,y,z) be the actual binary qualified hard capture, J_y(r)=integral_{R<=r}U_y, A_yz(r)=integral_{R<=r}U_y sigma and chi(y,z,r)=1{J>=H,A/J<7/8}. The prefix gate is frozen from original A/J and is NOT recomputed from a trial certificate h.

For every measurable h(y,z,r) that is CONSTANT over all receiver points in that prefix,

integral_{R<=r} U_y(x)(sigma(x,y,z)-h(y,z,r))^2 dx = A-A^2/J + J(h-A/J)^2.

The J=0 value is zero. One may restrict h to [0,1] without increasing the square cost. The explicit measurable choice h*=A/J (zero at J=0) proves B=inf_h F(h) and ATTAINMENT directly. This does not invoke an exchange of infimum and integral or a strong-duality theorem. Allowing h to depend freely on the current receiver x instead would invalidate this identity as a certificate of B.

## Shared column witness and exact source accounting

For a trial measurable h in [0,1], Tonelli gives F(h)=integral beta(dy) U_y(x) C_h(x,y)dx, with

C_h(x,y)=integral nu_*(dz) integral_[R(x),b] ell_n(dr) chi(y,z,r)(sigma(x,y,z)-h(y,z,r))^2.

Set H_y(x)=R(x)^-n integral sigma(x,y,z)nu_*(dz); then integral beta U_y H_y dx is the EXACT original T, not an enlarged first moment. For finite a>0 and finite nu, bounded h gives C_h<=a^-n W_nu pointwise. H_y is finite at the actual accepted receivers by the same-radius hard cap. This bounded-h convention avoids undefined infinity differences in the positive part.

Assume epsilon>=0 and finite nonnegative constants C_beta,C_nu. Let psi(x,z)>=0 be jointly measurable and SHARED across every y: it may depend on fixed original data but cannot be replaced by separate psi_y without a new summed budget. If for nu_*-a.e. z, integral_E psi(x,z)dx<=C_nu, and for beta-a.e. y,

integral_E U_y(x)[C_h(x,y)-epsilon H_y(x)-Psi(x)]_+dx<=C_beta, Psi(x)=integral psi(x,z)nu_*(dz),

then B<=F(h)<=epsilon T+C_beta W_beta+C_nu W_nu. Proof uses C_h<=epsilon H_y+Psi+[C_h-epsilon H_y-Psi]_+, integrates the row positive part, and invokes ORIGINAL FIRST only on the shared Psi term: integral beta U_y Psi<=integral_E Psi<=C_nu W_nu. No source density or nu<=beta relation is used. Column finiteness implies Psi finite dx-a.e. on E; U is a density against this SAME dx, so exceptional receiver sets do not create a hidden cost.

If h/psi are chosen after observing fixed original data, this is an auxiliary analytic certificate, not a new receiver/kernel selector. In a common-theta or outer-field application, measurability in those parameters and actual integrated constants are required. Total theta weight is one only when uniform constants or the correct averaged source budgets are supplied. Lambda multiplies the chosen entire receipt once. Internal epsilon T absorption needs a valid finite-target entry and its coefficient; it is not epsilon X.

## Meaning of the certificate and remaining gap

The statement is a genuine sufficient, source-conserving separation certificate and may support verifiable finite constructions; it does NOT itself construct an all-input low-cost h/psi. Choosing the exact unknown mean h*=p only recovers the original variance object and does not pay it. Numerical feasible witnesses establish their displayed inequalities only in the tested finite model (and any rigorously justified continuous reconstruction). They do not imply general root existence, unknown original-history realizability, strong duality, or an optimal certificate. Any convex/conic dual or minimax claim needs its own finite/infinite-domain hypotheses and proof.

## Actual bounded diagnostics

Executed 972 exact Fraction sufficient-certificate cases with a shared column profile, original finite FIRST, actual prefix gates and several h/psi/epsilon choices, plus 27 exact h=p minimum identities; all PASS. These are finite incidence diagnostics, not full original low/e/m/history realizations.

Unpaid: construction of general original-source h/psi with root-sized constants, including the R307 persistent gain and near-growth incidence, and all independent original total-ledger/aspect/entry obligations.

## Additional independent screen: signed row certificate and finite LP

The signed variant is valid and weaker than the positive-part condition. Define the finite original row quantities B_y and T_y, b_y=B_y-epsilon T_y, which may be negative. For a nonnegative SHARED receiver potential P(x), finite integral_E P, and C>=0, the conditions b_y-integral U_y P<=C for beta-a.e. y imply

B<=epsilon T+C W_beta+integral_E P.

This is direct row integration and original FIRST; no new actual source or receiver selector is introduced. The row squared cost at any h is B_y plus integral nu ell chi J(h-p)^2. Since h=p is measurable and simultaneously minimizes EVERY row, it eliminates h exactly for this signed certificate. This is algebraic elimination, not a strong-duality claim for the continuum.

In a finite exact model with positive receiver-cell volumes m_x and beta-positive rows, put Z_x=m_x P_x. The primal is min W_beta C+sum Z_x with C,Z>=0 and b_y<=C+sum_x U_yx Z_x. Its stated dual is max sum v_y b_y with v>=0, sum v<=W_beta and sum_y v_y U_yx<=1. Weak duality follows by multiplying the row inequalities by v, summing, and applying the two dual constraints. ANY exactly feasible primal/dual pair with equal objective proves finite optimality without invoking a generic strong-duality theorem. Zero-volume receiver cells and beta-null rows must be omitted or treated under the original a.e. convention; they cannot be freely charged as actual positive-measure columns/rows.

The dual v reweights certificate constraints only. It is NOT a new original beta input: original gates, p/e/m/history and the data matrix remain frozen, so a dual value is not an operator lower bound on a newly rescaled source. Allowing row-dependent residual caps C_y with beta-weighted cost would be a DIFFERENT LP and would change the dual constraints; the stated sum-v bound is for one shared uniform C.

Actually executed 125 exact Fraction diagonal-column signed LP certificates with negative, zero and positive b. Explicit primal/dual pairs were feasible with equal objective, proving optimum for those finite examples. These are LP checks, not original kernel/history constructions. General root-sized feasible potentials or original-source geometric existence remain unproved.

## Additional independent screen: actual-soft high-degree middle-capture cutoff

Assume the audited common-soft positive expansion p_s,L=sum_k b_nk(s) q_k,L, with b_nk<=c_nk<=1 and the uniform R303 overlap q_k,L*h_r<=rho^k/max(L,r)^n for ALL a<=L,r<=b<=2a. Because actual qualified sigma implies geometric capture and actual R(x)<=r, the receiver integral is inside Q_r(z). Apply the positive soft SCALE ENVELOPE before replacing the actual L(x). Its overlap integrates to

rho^k[(r/b)^n+n log(r/a)+1-(r/b)^n] = rho^k[1+n log(r/a)].

Thus A_k(r)<=c_nk rho^k[1+n log(r/a)]/q_- and A_hi<=A_n S_tail(K)/q_-. No component FIRST is used, and the tail estimate contains no source mass or favorable receiver selector. Its precise cancellation of the b-tail is essential; an A_n squared charge is unnecessary for this pointwise estimate.

On the ORIGINAL gate J>=H and eta<=A/J<7/8, choose uniform K with A_n S_tail<=epsilon eta q_- H. Then A_hi<=epsilon A. At fixed original J, f_J(A)=A-A^2/J is 1-Lipschitz on [0,J]; original A_lo<=A<=J gives |f_J(A)-f_J(A_lo)|<=A_hi. Integrating the SAME original middle gate proves absolute incidence error<=epsilon T. The sign is not fixed, since f_J is not monotone above J/2. Low capture p<eta remains intact. Original J and the gate are not recomputed from low degree; the resulting low-degree object is NOT silently a new binary-prefix problem.

The geometric bound S_tail<=rho^(K+1)/(1-rho) gives a source-independent logarithmic cutoff in A_n/(epsilon eta q_-H), capped at n (where tail is zero). A cutoff formula must preserve K>=0 and handle the empty tail; it does not establish any root budget for the retained low-degree middle object. All degree sums use original positive weights, with no independent full source fee per k.

Actual exact diagnostics: 69 finite binomial-envelope tail bounds and 270 original-J Lipschitz/middle-error configurations PASS. These check scalar degree pricing and do not recreate the full actual kernel/history.

## Additional independent screen: degree truncation of the EXACT R307 residual

At each original theta, the persistent gain and nonquiet near terms can be expressed as one capturing-anchor / bad-receiver integral with original ell chi/J, U_w sigma_w U_u(1-sigma_u), and a fixed mask M. Their receiver-pair domains are disjoint (far gain has R_u<=R_w/s; near has R_w/s<R_u<sR_w), so their combined mask satisfies 0<=M<=1. The original rho/quiet/rapid predicates in M are NOT recomputed. Split ONLY the capturing density U_w into its actual positive soft-degree low/high components. The bad receiver density, J, sigma, original p gate and M remain full/original.

The original-middle high-degree subfee is nonnegative and bounded at each prefix by A_hi(J-A)/J<=A_hi<=epsilon A. Its total is <=epsilon T. This is a genuine positive subcomponent of the original R307 fee, not an application of the binary theorem to nonbinary A_lo. Low-p residual stays in full, and the retained middle low-degree anchor still interacts with the FULL bad receiver and original denominator. It is not a two-low-degree or binary-prefix reduction.

In Lambda T<=512 Lambda lambda d W_beta+16 Lambda R, choose epsilon=1/64. Subtracting 16epsilon T leaves 3/4, yielding coefficients 2048/3 and 64/3 on the source and retained incidence. This is internal finite-T absorption with total theta weight one and zero new original-X error. The middle threshold must be distinguished from the earlier gain-criterion eta if notation is shared.

## Exact rational rho certificate inspection

Read `/tmp/r308_tail_probe.py` after the independent truncation screen. Its j=8,...,15 cells are the upper half of a uniform 16-cell grid on [0,1]. On each cell exp(-3/(2u)) is at least its value at the left endpoint j/16. The factor 2u is integrated EXACTLY, giving (2j+1)/256. For x=24/j<=3, the positive Taylor sum through degree18 plus x^19/19! divided by (1-x/20) is an upper bound for exp(x), since all subsequent term ratios are at most x/20. Thus its reciprocal is a certified lower bound. The eight-cell sum exceeds 1/10, proving the overlap contraction rho<9/10.

Actually executed those eight rational Taylor/geometric checks and the exact final comparison; PASS. No floating-point root decision was used. The rest of the script correctly keeps finite-tail cutoff at n and uses An<=1+n, with absolute variance perturbation rather than a monotonicity assumption; parent-reported full tail/variance runs are separate evidence. This audit did not repeat the large-n tail sweep.

## Author comparison: true-soft middle-capture capacity

Read `/tmp/r308_joint_capacity.md`, SHA256 `2c97e845b482cbad5d3752910990533f90695cba950c5d5fafb1c474a0dc368f`. PASS for (1)-(9). The actual positive common-soft expansion, true overlap contraction and single soft-scale envelope give the exact cancellation in (3), with no extra hard-scale factor or component FIRST. The uniform cutoff always exists at K=n; the logarithmic bound (8), source independence, and exact K=n criterion have correct endpoint signs. Small degree is correctly conditional on a lower bound for q_-H and epsilon eta. Original gates/J and full-source qualifications remain fixed; the response-level perturbation is absolute, not monotone, and is NOT presented as a binary-prefix theorem on A_lo. Low capture and retained low degree remain unpaid.

The parent's stronger original-residual anchor truncation is independently screened above and differs from this response perturbation; their alternative errors must not be counted twice. Actually executed the embedded reproduction in a fresh namespace: 16 scale identities (60-digit Decimal explicit-antiderivative diagnostics), 60 exact cutoff tests, 126 exact variance perturbations, all PASS. No quadrature or full original-history realization is claimed by those finite tests.

## Author comparison: signed global certificate

Read `/tmp/r308_geometry.md`, SHA256 `9b0bf967762de77b9068491cf51a5a6ec1f2c3ab1c5b84673a788c2b0a3b86ee`. PASS for (1)-(17). Exact theta-level squares are averaged after evaluating them; h=p simultaneously minimizes all signed rows. The signed condition is correctly distinguished from the stronger positive-part certificate; P/W_nu only represents the column cost and does not imply a positive-part condition. Finiteness, beta-a.e. constraints, positive-volume cells, source-null cases and the weak-dual interpretation are explicit. Baseline (15) recovers the known coarse A_n price; no all-input root existence is inferred. The strict mixed 169/2000 fixture is now expressly FIRST-compatible finite occupation algebra, not an automatically realized full-soft original input. Original R305 entry in (17) and an alternative subfee entry must not be conflated.

Actually executed the fresh embedded exact toy certificate: J=(1,1), A=(1/2,4/5), mixed primal=dual=169/2000, column Jensen=1771/20000, row-only=1/8, receiver-only=37/400. All assertions PASS. This is evidence of a finite strict mixed improvement, not a generic theorem of root pricing or actual-history realization.

## Final actual-residual anchor extension

Read the updated `/tmp/r308_joint_capacity.md`, SHA256 `b3d4a27d74074003bbee41b2e1dceafad6dce07aa0fb5e9f1086e0a711bd0e59`, superseding the earlier component binding. New P1-P5 PASS against the independent anchor screen. In particular the gain/near masks have disjoint ordered supports, so their union M<=1; only the capturing density is split, retaining the full noncapture endpoint and original J/gates. P4 pays an actual positive subfee and P5 preserves all R307 progress with coefficients 2048/3 and 64/3. The lower-middle threshold is explicitly independent of prior R307 paid-branch parameters. Neither the retained low-degree capturing endpoint nor the low-p all-soft endpoint is paid here.

Actually executed ONLY the new second embedded reproduction (the earlier 16/60/126 block had already been executed): 1536 exact positive-anchor decomposition cases PASS. Those component masses abstractly enforce the proved prefix cap and do not realize the full actual kernel. No unnecessary repeat of the earlier checks was made.

## Numeric LP source-a.e. correction and scope review

Reviewed the full finite candidate/basis repair path in `/tmp/r308_numeric.py`. Numerical vertex enumeration only proposes a basis; the basis and transpose are rebuilt by Fraction elimination, every retained original primal row and every shared dual column is checked exactly, and equality of rational objectives certifies finite optimality by weak duality. Normalization scales map back correctly; nonpositive signed constraints may be omitted because all primal variables/U are nonnegative. True positive-volume s=0 L1 cube-cell models verify constant incidences, original FIRST and same-radius hard caps separately; the strict mixed transport fixture remains explicitly abstract. None implements all original low/e/m/history.

An actual source-a.e. defect was identified: the initial zero-beta receiver-only comparison constrained beta-null rows and reported 37/400. The numeric author corrected it to retain only beta-positive rows, force dual mass zero on null rows, and make the empty-beta joint AND receiver-only price zero. The full artifact now has 3558 exact checks and 58 primal/dual zero gaps. This audit independently ran the corrected function definitions (without rerunning the full artifact-writing sweep): zero-beta joint/receiver/row-only outputs all zero; two partial-null-row joint/receiver regressions ignore an arbitrary large null-row budget and give exact price 1/80. All fresh regression assertions PASS. The earlier 37/400 degenerate comparison is not treated as a valid original-source price.

- `/tmp/r308_numeric.py`: SHA256 `7005f5bd2000638e061e52d0695e6f23ccf293089dd0a00211e818bc8dfb2dc5`.

- `/tmp/r308_numeric.json`: SHA256 `2eed7a18a016c413974eab46bf0207135063f44dc0189d21f2ccce609da04449`.

- `/tmp/r308_numeric.md`: SHA256 `8c896207e14826ec62624e3d566ab23e598f2726a47d610689dae3e2f9193d1b`.

## Independent verification of the frozen finite LP witnesses

Read the final JSON data and independently checked 58 certificate pairs across 29 cases using exact Fraction arithmetic, without invoking the optimizer or its checker: all beta-positive primal row inequalities, nonnegative variables, null-row dual zeros, every shared column dual constraint, uniform-C dual mass bound (joint case), C=0 (receiver-only case), and exact equality of primal and dual objectives. Also checked original finite FIRST and actual B<=epsilon T+joint price per case. All PASS. The receiver-only program legitimately has no dual sum-v constraint because C is fixed to zero; it is distinguished from the joint class. This verifies finite optimality of these recorded witnesses by weak duality, not generic analytic strong duality.

## Final integration verdict — frozen

PASS. Final main combined note, README and static TeX match the two audited author proofs and the independent screens. The primary new payment is the POSITIVE high-degree CAPTURING-ENDPOINT subfee of the EXACT R307 residual; full bad-receiver U, missed capture, J, every original predicate and all theta/source weights remain fixed. Original middle p>=eta_mid and the uniform analytic tail bound pay this subfee by epsilon T. Epsilon=1/64 in the R307 coefficient-16 entry yields source coefficient 2048/3 and retained incidence coefficient 64/3. Low-p remains all-soft; retained middle low degree applies to ONE capturing endpoint only. No entire-operator low-degree reduction or uniform small cutoff is claimed.

The source-independent degree cutoff can equal n, and its logarithmic guarantee has explicit inverse-parameter conditions. The rho<9/10 rational certificate uses a valid exponential upper remainder and a true lower integral sum. The separate signed shared-potential certificate retains the full original variance object; explicit text now prevents applying its h=p square elimination to the restricted R307 pair remainder without redefining its actual row cost and entry coefficients. Original accepted-set/FIRST/SAME-R/q/low-m/aspect hypotheses and original constants have been added explicitly in TeX. Beta-null rows and zero-volume cells are correctly excluded from the finite analytic program.

All actual-source/aspect/outer costs and independent original ledger obligations remain, with Lambda once and ZERO new global-X error. A general root-priced potential or root budget for the retained low-p / one-low-degree-capturing / full noncapturing interaction remains unproved. Neither an original-X entry nor a general weak-type closure is certified.

Final SHA256 bindings (large numeric JSON are external reproducible results, not promised inside the ZIP):

- `/tmp/r308_geometry.md`: SHA256 `9b0bf967762de77b9068491cf51a5a6ec1f2c3ab1c5b84673a788c2b0a3b86ee`.
- `/tmp/r308_joint_capacity.md`: SHA256 `b3d4a27d74074003bbee41b2e1dceafad6dce07aa0fb5e9f1086e0a711bd0e59`.
- `/tmp/r308_combined.md`: SHA256 `f81ff0e5d1bfafc1711aa66accfceb04c3c98f1b56777cfb9492d3890c5a64bd`.
- `/tmp/r308_README.md`: SHA256 `ac5c3c43525218e3cd6b7e4d6aabe0d584d4ca04f167b98955fa19588b0f80cc`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round308_20261018_final_checkpoint/research.tex`: SHA256 `a8e347b007af8d670a81b879895a28258c907fb86566918f74e91b661016b3ba`.
- `/tmp/r308_numeric.md`: SHA256 `8c896207e14826ec62624e3d566ab23e598f2726a47d610689dae3e2f9193d1b`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round308_20261018_final_checkpoint/geometry_checks.py`: SHA256 `a15132a241eb043c7947c5e5a875d788981fc367fcb95e3b587f06826b61c4e4`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round308_20261018_final_checkpoint/joint_capacity_checks.py`: SHA256 `cb5de3dd21f19fa6acae4885a1fc7d911c5b015a7f6115cd411c9d623777c639`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round308_20261018_final_checkpoint/r308_numeric.py`: SHA256 `7005f5bd2000638e061e52d0695e6f23ccf293089dd0a00211e818bc8dfb2dc5`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round308_20261018_final_checkpoint/r308_pair_probe.py`: SHA256 `6a148318bcd2af2668efd064b57d0ac3b044f14d905cce108419cda98a6600db`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round308_20261018_final_checkpoint/r308_tail_probe.py`: SHA256 `b562e30d4773239732670cf2af5d2b42a77d4fac40c0826080a13240558395d5`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round308_20261018_final_checkpoint/r308_numeric.json`: SHA256 `2eed7a18a016c413974eab46bf0207135063f44dc0189d21f2ccce609da04449`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round308_20261018_final_checkpoint/r308_pair_probe.json`: SHA256 `5030e9b64742fffff15f55fe84645c95875ab661111d99deb35961b9c2f624fc`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round308_20261018_final_checkpoint/r308_tail_probe.json`: SHA256 `5eb262f66a5157ecf69e8baa37b8b3e5123fa1207670243e70ceca33f8d6bd82`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round308_20261018_final_checkpoint/geometry_checks.log`: SHA256 `ae248206faea2b688e9e3d464c69202c404866506527d8c0120782b008eff9fe`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round308_20261018_final_checkpoint/joint_capacity_checks.log`: SHA256 `a71b147cd92773d72b2bae9f7c936a868b1bc6b577386d6852cf3343938a45b0`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round308_20261018_final_checkpoint/numeric_checks.log`: SHA256 `2391785d68146a6f617fa57aa299e09e45ade6fb0431b12a4b4521dc44b07403`.

Inspected final parent staging outputs: numeric 3558 exact PASS with 58 zero-gap finite joint/receiver-only certificates; staged numeric/tail/pair scripts and JSON byte-identical to final frozen /tmp originals. Author embedded toy and auxiliary 16/60/126/1536 were actually executed in this audit, as recorded above. Parent reports fresh independent-process reruns; observed staging logs and data support the stated counts. Tail probe 2100/456 and conditional pair 1152 models/444 eligible layers/372 nonzero-high observations are scoped to their exact finite algebra, not a full original history or arbitrary spectral realization. The initially incorrect zero-beta receiver-only comparison was corrected and independently regression-tested before these final bindings. No earlier result is relabeled as final evidence.

Only `/tmp/r308_audit.md` was modified by this audit. No author, repository, TeX or PDF files were edited; no PDF was compiled. The receipt is frozen.
