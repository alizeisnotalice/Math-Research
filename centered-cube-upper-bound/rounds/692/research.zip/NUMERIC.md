# R692 real-core coefficient comparisons and fragmentation decision

## Decision

The adaptive rule ranked by immediate increment `d_j r_j(1−exp(−w_j/t))` does not have the desired uniform value guarantee at the prescribed t=sqrt(n), with the specified fixed real owner partition. The independently proved actual finite fragmentation family supplies an upper bound for `tD/V` tending to zero. The appended 512-bit Arb checks confirm its scale without enumerating the enormous family.

This does not rule out choosing t from the input or rebuilding the owners. On this common-intersection family, letting t tend to zero makes the first big-parent coefficient tend to one and can avoid the displayed failure.

Removing the alpha factor from the **ranking only**, while keeping the increment `r_j alpha_j`, repairs the stated fragmentation family: its big-core retention lower bound is already above0.9835 at n=4 and approaches one. This is a family-specific repair, not a proof of the general root bound.

The initial five finite inputs remain useful exact consistency checks. They show a strict improvement on one chain and demonstrate that high raw nested overlap need not force poor value. Their favorable outputs do not override the fragmentation obstruction.

All inputs are direct finite-cube entrances with genuine Lebesgue cores. No original high-tau admission/clipping history is simulated, and no tau is reduced.

## Fixed real ownership and five small inputs

For each input `a=32n`, `Ai=Q(yi,si)`, `Bi=Q(yi,si/a)`, `di=|Ai|`. The original listed descending-radius owner order is fixed once:

`Ei=Bi minus union_(i<j)Bi`, `vi=|Ei|`, `wi=vi/di`.

The program builds the joint parent/core endpoint arrangement and computes vi and V exactly using Fraction. Every owner cell is counted once. Candidate reordering never changes the owners. All original parent variables remain present.

The original three inputs are:

1. Nested1D: `(y,s)=(2,4),(1,2),(1/2,1),(1/4,1/2)`.
2. Two clusters2D: `((0,0),2),((1/32,0),1),((5,0),1),((5,1/64),1/2)`. The second and fourth tiny cores are half outside the earlier core of their respective cluster, so their real vi are half of their full core volumes.
3. Compass2D: `((0,0),1),((-5/4,0),3/4),((5/4,0),3/4),((0,5/4),1/2),((0,-5/4),1/2)`. Outer parents have disjoint interiors or null contacts, while positively meeting the central parent.

The additional frozen inputs are the1D chain `[-3,3],[2,6],[11/2,15/2]` and star `[-2,2],[-4,-1],[1,4]`, both with a=32. Their tiny cores are disjoint.

| input | n | exact union-core volume V | exact P0 |
|---|---:|---:|---:|
| nested1D | 1 | 15/32 | 8 |
| two clusters2D | 2 | 45/8192 | 20 |
| compass2D | 2 | 21/8192 | 13/2 |
| chain1D | 1 | 3/8 | 8 |
| star1D | 1 | 5/16 | 6 |

Each P0 has matching Fraction packing-primal and mask-dual certificates. HiGHS independently agrees. These optimum packings are benchmarks only; no candidate selects an unknown optimum. Positive parent cells implement a.e. packing, so boundary-only outer contacts are not counted as positive overlaps.

## Three common-coefficient algorithms

For one common t>0, put `alpha_j=1−exp(−w_j/t)`.

- Existing exponential formula in volume order: `L_j=esssup_Aj sum_(i<j)wi1_Ai`, `theta_j=exp(−L_j/t)alpha_j`. This is acknowledged as the existing PACKING_CORE construction.
- True remaining capacity in the same order: `r_j=1−esssup_Aj sum_(selected i)theta_i1_Ai`, `theta_j=r_j alpha_j`.
- Immediate-score adaptive order: recompute all r_j and choose a remaining label maximizing `d_j r_j alpha_j`, with exact ties broken by original ID; use the same increment `r_j alpha_j`.

The two parameters are exactly the frozen `t=sqrt(n)` and `t=wmax/log4`. Every input has `wi/wmax` equal to one or one half. In the second mode `z=exp(−wmax/(2t))=1/2`, so every coefficient, ordering comparison, load and objective is Fraction exact. The parameter t itself is not rational. In the root mode all coefficients are exact rational polynomials in z, evaluated with512-bit Arb; nonzero polynomial comparison signs certify the selected branch and polynomial identities certify exact ties.

Every candidate is checked against every positive parent incidence mask. The full joint cells, real owners, all intermediate r values, candidate orders, exact theta polynomials, objective/V, objective/P0 and root-normalized values are stored.

At `t=sqrt(n)`, the following are certified D/V values (displayed centers rounded):

| input | old exponential | true capacity, same order | immediate-score adaptive |
|---|---:|---:|---:|
| nested1D | 0.962632 | 0.962632 | 0.962632 |
| two clusters2D | 0.707036 | 0.707036 | 0.707036 |
| compass2D | 0.706970 | 0.706970 | 0.706970 |
| chain1D | 0.969391 | 0.969546 | 0.969546 |
| star1D | 0.966362 | 0.966362 | 0.966362 |

At `t=wmax/log4`, exact objectives are:

| input | old exponential | true capacity, same order | immediate-score adaptive |
|---|---:|---:|---:|
| nested1D | 1755/256 | 1755/256 | 1755/256 |
| two clusters2D | 125/8 | 125/8 | 125/8 |
| compass2D | 135/32 | 135/32 | 135/32 |
| chain1D | 45/8 | 207/32 | 27/4 |
| star1D | 33/8 | 33/8 | 33/8 |

On the chain, remaining capacity improves the true finite objective and adaptive order `(0,2,1)` improves it further. On the separated clusters, adaptive order `(0,2,1,3)` changes the schedule but not the value. The other three values are unchanged. These are scoped comparisons, not a uniform guarantee.

## Frozen long nested family: high raw load is not the value test

Let n=1,a=32,r=15/16 and `s_j=r^j`, `y_j=s_j`, j=0,...,N−1. Thus parents are `[0,2s_j]` and cores are `[(31/32)s_j,(33/32)s_j]`. The exact inequality `r<31/33` (495<496) makes all cores disjoint. Consequently

`w_j=1/32`, `V_N=1−r^N`, `P0=2`.

The P0 certificate is theta0=1 and a dual mass2 uniformly on the smallest parent. It covers every original parent-volume constraint.

For `x=exp(−1/(32t))`, all three algorithms choose descending radii and have

`theta_j=(1−x)x^j`,

`maxload=1−x^N`,

`D_N=2(1−x)(1−(rx)^N)/(1−rx)`.

Earlier selected parents contain every remaining parent, so their remaining capacities all equal x^j; adaptive scores then rank only by the decreasing di. This proves the shared formula without enumerating N parent coordinates. The program checks the two parameter values for N=64,256,4096 using these formulas.

| N | raw common-parent load N/32 | D_N/V_N at t=1 | D_N/V_N at t=(1/32)/log4 |
|---|---:|---:|---:|
| 64 | 2 | 0.683164 | 1.991193 |
| 256 | 8 | 0.673647 | 1.959184 |
| 4096 | 128 | 0.673647 | 1.959184 |

The raw load grows from2 to128 while the value ratio stays bounded away from zero on this family. At the tiny common parameter x=1/4 the limit is96/49; at t=1 it is `2(1−e^−1/32)/(1−(15/16)e^−1/32)`. These are properties of this frozen nested family, not evidence of a general root theorem.

For extremely tiny x^N the rounded load ball can contain one. Feasibility is then certified by the exact formula `0<x<1 =>1−x^N<1`, and the exact logarithmic margin N log x is stored. No false strict inequality is inferred from a rounded value.

## Decisive actual fragmentation family: scalar parameter append

The full finite geometry and its order properties are supplied independently by the coordinator/Astra's A1 proof. This calculation does not enumerate `K=ceil(n t a^n)` or its grid. It checks only the frozen analytic bounds at n=4,16,64,256, with

`a=32n`, `t=sqrt(n)`, `r=(a−2)/(a+2)`,

`Vbig>=1−(8/a)^n`,

`Vtiny<= (1/(2a²))^n/(1−r^n)`.

For the original immediate-score adaptive rule, the proved bound is

`tD/V <= [((2/a)^n+Vtiny)/(1−(8/a)^n)]+exp(−n)`.

This upper bound tends to zero: `r^n->exp(−1/8)`, both power terms vanish and exp(−n) vanishes. The family therefore rules out a uniform positive retention guarantee for that candidate. The four finite checks are sanity checks of the parameters, not a numerical construction or an all-n proof of the geometric family.

The minimal repair ranks by `d_j r_j` **without alpha** but still increments by `r_j alpha_j`. For the same family A1 proves all big labels come first. With

`x=Vbig/(2^n t)<=xmax=(1+2/a)^n/(2^n t)`,

the retained big-core ratio has the lower bound

`tD_big/Vbig >= (1−exp(−xmax))/xmax`.

It is evaluated as `−expm1(−xmax)/xmax` to avoid cancellation. The next table gives the original candidate's upper bound and the loss `1−lower_bound` for the repaired big-core retention:

| n | original tD/V upper | loss of repaired retention lower bound |
|---|---:|---:|
| 4 | 1.831570e-2 | 1.644196e-2 |
| 16 | 1.125352e-7 | 2.030112e-6 |
| 64 | 1.603811e-28 | 3.606538e-21 |
| 256 | 6.616261e-112 | 2.872839e-79 |

The repaired lower bound is about0.9835580421 at n=4 and0.9999979699 at n=16; its losses at n=64,256 are about3.60654e−21 and2.87284e−79. This repairs the stated family only. It is not a proof of the repaired rule's general value guarantee or of the original centered-cube root estimate.

## Reproducibility and preserved records

Executed first-stage command:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r692-20261116/NUMERIC.py
```

The later parameter certificate was appended without rerunning any of the30 small-input algorithm comparisons or six nested evaluations:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r692-20261116/NUMERIC.py --fragmentation-only
```

The append records and checks a canonical hash of those preserved results. All inputs are embedded, so default execution is standalone. The full scalar/geometry outputs, commands, Python/platform/NumPy/SciPy/python-flint versions,512-bit precision and error fields are stored in RESULT.json. HiGHS is secondary to the exact five P0 primal-dual certificates. No large coordinate list, grid or K is constructed.

The first run body took about0.036seconds and the append about0.009seconds. All exact owner/P0, ordering, candidate feasibility, nested-formula and scalar checks passed; errors are empty and both processes exited with code zero. Source SHA-256: `bc5bcfa7b5c9d2538f44762852a8ab16fe19a3ad6ab8881a456acf33f4a953bc`. Result SHA-256: `c14689f46d6edb2497c41cedd19eed22d3ef72b2da68ca4313774711efff6f3b`.

Only the three owned R692 files were written. No broad counterexample scan, high-tau simulation, MATLAB, package installation, Git, PDF or new agent was used. Computation is stopped.
