#!/usr/bin/env python3
"""R692 five frozen real-core finite entrances and three frozen nested sizes."""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import json,hashlib,sys,time,platform
import numpy as np
import scipy
from scipy.optimize import linprog
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;start=time.time();ctx.prec=512
FIXTURES=[
 {'id':'nested_1D','n':1,'a':32,'parents':[{'center':['2'],'radius':'4'},{'center':['1'],'radius':'2'},{'center':['1/2'],'radius':'1'},{'center':['1/4'],'radius':'1/2'}],'packing_theta':['1','0','0','0'],'dual_mask_prices':{'15':'8'}},
 {'id':'two_clusters_partial_core_2D','n':2,'a':64,'parents':[{'center':['0','0'],'radius':'2'},{'center':['1/32','0'],'radius':'1'},{'center':['5','0'],'radius':'1'},{'center':['5','1/64'],'radius':'1/2'}],'packing_theta':['1','0','1','0'],'dual_mask_prices':{'3':'16','12':'4'}},
 {'id':'multiscale_compass_2D','n':2,'a':64,'parents':[{'center':['0','0'],'radius':'1'},{'center':['-5/4','0'],'radius':'3/4'},{'center':['5/4','0'],'radius':'3/4'},{'center':['0','5/4'],'radius':'1/2'},{'center':['0','-5/4'],'radius':'1/2'}],'packing_theta':['0','1','1','1','1'],'dual_mask_prices':{'3':'9/4','5':'9/4','9':'1','17':'1'}},
 {'id':'Sol_chain_1D','n':1,'a':32,'parents':[{'center':['0'],'radius':'3'},{'center':['4'],'radius':'2'},{'center':['13/2'],'radius':'1'}],'packing_theta':['1','0','1'],'dual_mask_prices':{'3':'6','6':'2'}},
 {'id':'Sol_star_1D','n':1,'a':32,'parents':[{'center':['0'],'radius':'2'},{'center':['-5/2'],'radius':'3/2'},{'center':['5/2'],'radius':'3/2'}],'packing_theta':['0','1','1'],'dual_mask_prices':{'3':'3','5':'3'}}
]
def cube(y,s):return [(v-s,v+s) for v in y]
def inside(p,B):return all(lo<v<hi for v,(lo,hi) in zip(p,B))
def volume(B):
 out=Q(1)
 for lo,hi in B:out*=hi-lo
 return out
def serial(v):
 if isinstance(v,Q):return str(v)
 if isinstance(v,(list,tuple)):return [serial(x) for x in v]
 if isinstance(v,dict):return {k:serial(x) for k,x in v.items()}
 return v
def ab(v):
 v=Q(v);return arb(v.numerator)/v.denominator

def geometry(fixture):
 n=fixture['n'];a=Q(fixture['a']);ps=fixture['parents'];parents=[cube([Q(v) for v in p['center']],Q(p['radius'])) for p in ps];cores=[cube([Q(v) for v in p['center']],Q(p['radius'])/a) for p in ps]
 axes=[]
 for t in range(n):
  ep=sorted(set(v for B in parents+cores for v in B[t]));axes.append([((lo+hi)/2,hi-lo) for lo,hi in zip(ep,ep[1:])])
 cells=[];vi=[Q(0)]*len(ps);V=Q(0);patterns={}
 for xx in product(*axes):
  point=[v[0] for v in xx];mass=Q(1)
  for v in xx:mass*=v[1]
  pb=[int(inside(point,B)) for B in parents];cb=[int(inside(point,B)) for B in cores];owner=next((j for j,b in enumerate(cb) if b),None)
  if owner is not None:vi[owner]+=mass;V+=mass
  if any(pb):
   mask=sum(v<<i for i,v in enumerate(pb));cells.append({'point':point,'mass':mass,'parent_bits':pb,'parent_mask':mask,'core_bits':cb,'owner':owner});patterns.setdefault(mask,pb)
 di=[volume(B) for B in parents];wi=[vi[i]/di[i] for i in range(len(ps))]
 assert sum(vi,Q(0))==V and V>0 and all(Q(0)<=w<=a**(-n) for w in wi)
 masks=sorted(patterns);rows=[patterns[m] for m in masks]
 th=[Q(v) for v in fixture['packing_theta']];prices={int(k):Q(v) for k,v in fixture['dual_mask_prices'].items()}
 assert all(sum((th[i]*row[i] for i in range(len(ps))),Q(0))<=1 for row in rows)
 assert all(m in patterns for m in prices)
 assert all(sum((value*patterns[mask][i] for mask,value in prices.items()),Q(0))>=di[i] for i in range(len(ps)))
 P=sum((d*t for d,t in zip(di,th)),Q(0));assert P==sum(prices.values(),Q(0))
 lp=linprog(-np.array([float(v) for v in di]),A_ub=np.array(rows,dtype=float),b_ub=np.ones(len(rows)),bounds=(0,None),method='highs');assert lp.success and abs(-lp.fun-float(P))<1e-10
 return {'parents':parents,'cores':cores,'cells':cells,'parent_masks':masks,'parent_rows':rows,'v_i':vi,'d_i':di,'w_i':wi,'V':V,'P0':P,'exact_packing_primal':th,'exact_dual_mask_prices':[{'mask':k,'mass':v} for k,v in prices.items()],'HiGHS_P0':float(-lp.fun),'owner_rule':'listed descending-radius order;E_j=B_j minus earlier B_i up to null faces'}
# Exact rational polynomials in z=exp(-wmax/(2t)); degree stays small on the5 small inputs.
def trim(p):
 p=list(p)
 while len(p)>1 and p[-1]==0:p.pop()
 return tuple(p)
def add(p,q):return trim([(p[i] if i<len(p) else Q(0))+(q[i] if i<len(q) else Q(0)) for i in range(max(len(p),len(q)))])
def scale(p,c):return trim([Q(c)*v for v in p])
def sub(p,q):return add(p,scale(q,-1))
def mul(p,q):
 r=[Q(0)]*(len(p)+len(q)-1)
 for i,a in enumerate(p):
  for j,b in enumerate(q):r[i+j]+=a*b
 return trim(r)
def monomial(k):return (Q(0),)*k+(Q(1),)
ZERO=(Q(0),);ONE=(Q(1),)
def evaluate(p,z):
 r=Q(0) if isinstance(z,Q) else arb(0)
 for c in reversed(p):r=r*z+(c if isinstance(z,Q) else ab(c))
 return r
def compare(p,q,z):
 diff=sub(p,q)
 if diff==ZERO:return 0
 val=evaluate(diff,z)
 if val>0:return 1
 if val<0:return -1
 if isinstance(z,Q):return 0
 raise ArithmeticError('Unresolved Arb polynomial ordering; no uncertified adaptive branch is accepted')
def maximum(polys,z):
 best=ZERO
 for p in polys:
  if compare(p,best,z)>0:best=p
 return best

def algorithm(g,n,mode,kind):
 d=g['d_i'];w=g['w_i'];V=g['V'];m=len(d);rows=g['parent_rows'];wmax=max(w)
 assert all(v/wmax in (Q(0),Q(1,2),Q(1)) for v in w)
 if mode=='rational_decay':z=Q(1,2);tstr='wmax/log4';tball=ab(wmax)/arb(4).log()
 else:tball=arb(n).sqrt();z=(-ab(wmax)/(2*tball)).exp();tstr='sqrt(n)'
 alpha=[sub(ONE,monomial(int(2*v/wmax))) for v in w];theta=[ZERO]*m;selected=[];steps=[];remaining=list(range(m))
 while remaining:
  candidates=[]
  for j in remaining:
   if kind=='old_exp_volume_order':
    Lj=max(sum((w[i]*row[i] for i in range(j)),Q(0)) for row in rows if row[j]);power=2*Lj/wmax;assert power.denominator==1;rj=monomial(power.numerator)
   else:
    prefix=[sum_poly([theta[i] for i in selected if row[i]]) for row in rows if row[j]]
    rj=sub(ONE,maximum(prefix,z))
   assert evaluate(rj,z)>=0
   coeff=mul(rj,alpha[j]);score=scale(coeff,d[j]);candidates.append((j,rj,coeff,score))
  if kind=='remaining_adaptive':
   chosen=candidates[0]
   for c in candidates[1:]:
    cmp=compare(c[3],chosen[3],z)
    if cmp>0 or (cmp==0 and c[0]<chosen[0]):chosen=c
  else:chosen=next(c for c in candidates if c[0]==remaining[0])
  j,rj,coeff,score=chosen;theta[j]=coeff;selected.append(j);remaining.remove(j)
  steps.append({'chosen_label':j,'r_polynomial':rj,'theta_polynomial':coeff,'r_value':str(evaluate(rj,z)),'theta_value':str(evaluate(coeff,z)),'candidate_score_values':[{'label':c[0],'score':str(evaluate(c[3],z))} for c in candidates]})
 objective=sum_poly([scale(theta[i],d[i]) for i in range(m)]);D=evaluate(objective,z);loads=[]
 for mask,row in zip(g['parent_masks'],rows):
  pol=sum_poly([theta[i] for i in range(m) if row[i]]);value=evaluate(pol,z);margin=evaluate(sub(ONE,pol),z)
  assert margin>=0 if isinstance(z,Q) else margin>0
  loads.append({'mask':mask,'load_polynomial':pol,'load':str(value),'one_minus_load':str(margin)})
 root=arb(n).sqrt();Db=ab(D) if isinstance(D,Q) else D
 assert Db>0 and Db<=ab(g['P0'])
 return serial({'algorithm':kind,'parameter_mode':mode,'t':tstr,'t_Arb':str(tball),'z':'1/2 exact' if isinstance(z,Q) else str(z),'wmax':wmax,'order':selected,'steps':steps,'theta_polynomials':theta,'theta_values':[str(evaluate(p,z)) for p in theta],'objective_polynomial':objective,'objective':str(D),'exact_rational_objective':str(D) if isinstance(D,Q) else None,'objective_over_V':str(Db/ab(V)),'sqrt_n_times_objective_over_V':str(root*Db/ab(V)),'objective_over_P0':str(Db/ab(g['P0'])),'empirical_K_V_over_sqrt_n_D':str(ab(V)/(root*Db)),'all_parent_mask_loads':loads,'all_positive_cell_feasibility_passed':True,'ordering_certificate':'Fraction comparisons when z1/2; otherwise512-bit Arb signs of exact polynomial differences, with polynomial identities proving exact ties'})
def sum_poly(polys):
 out=ZERO
 for p in polys:out=add(out,p)
 return out

def append_fragmentation_certificate():
    tick=time.time();ctx.prec=512;dst=ROOT/'RESULT.json';old=json.loads(dst.read_text())
    assert len(old['small_fixtures'])==5 and sum(len(v['comparisons']) for v in old['small_fixtures'])==30 and len(old['nested_family'])==6
    preserved=hashlib.sha256(json.dumps({'small':old['small_fixtures'],'nested':old['nested_family']},sort_keys=True).encode()).hexdigest();checks=[]
    for n in (4,16,64,256):
        a=32*n;t=arb(n).sqrt();rr=arb(a-2)/(a+2)
        one_minus_rn=-(n*rr.log()).expm1()
        tiny=(n*(-arb(2).log()-2*arb(a).log())).exp()/one_minus_rn
        biglower=1-(arb(8)/a)**n
        original_upper=((arb(2)/a)**n+tiny)/biglower+(-arb(n)).exp()
        xmax=(n*(1+arb(2)/a).log()).exp()/(arb(2)**n*t)
        retention=-(-xmax).expm1()/xmax
        loss=1-retention
        assert biglower>0 and one_minus_rn>0 and tiny>0 and original_upper>0 and original_upper<arb(1)/50
        assert xmax>0 and retention>arb(98)/100 and retention<1 and loss>0
        checks.append({'n':n,'a':a,'t_sqrt_n':str(t),'r_exact':str(Q(a-2,a+2)),'Vbig_lower':str(biglower),'Vtiny_upper':str(tiny),'one_minus_r_to_n':str(one_minus_rn),'original_adaptive_tD_over_V_upper':str(original_upper),'xmax_for_rank_without_alpha':str(xmax),'rank_without_alpha_retention_lower':str(retention),'one_minus_retention_lower':str(loss),'upper_less_than_0p02':True,'repair_retention_greater_than_0p98':True})
    old['fragmentation_parameter_certificate']={'scope':'Scalar certificates for the independently proved finite geometric fragmentation family in A1. Geometry, grid, K and algorithm selection order are NOT enumerated here. The original immediate-score candidate fails on that family under the stated analytic bounds; the score repair is verified only for that family, not the general root goal.','precision_bits':ctx.prec,'python_flint_version':flint.__version__,'geometry_proof_source':'A1.md, independently supplied actual finite whole-input construction; not a high-tau history simulation','input_formulas':{'n':'n>=2','a':'32n','t':'sqrt(n)','r':'(a-2)/(a+2)','Vbig_lower':'1-(8/a)^n','Vtiny_upper':'(1/(2a^2))^n/(1-r^n)'},'original_candidate_upper':'tD/V <= [((2/a)^n+Vtiny)/(1-(8/a)^n)]+exp(-n)','repair':'Rank by d_j*r_j without alpha; still incrementtheta_j=r_j*alpha_j. A1 proves allbig labels precede tiny labels in this family.','repair_xmax':'x=Vbig/(2^n*t)<=xmax=(1+2/a)^n/(2^n*t)','repair_retention_lower':'tD_big/Vbig >= (1-exp(-xmax))/xmax, evaluated via -expm1(-xmax)/xmax','general_limit_note':'The original scalar upper tends0: r^n->exp(-1/8), the two power terms vanish andexp(-n)->0. Finite4-point checks are not an all-n proof; geometry and asymptotics are analytic inputs. The repaired lower approaches1 on this family only.','checks':checks,'no_K_or_grid_enumerated':True,'original_30_and_nested6_preserved_sha256':preserved,'command':[sys.executable,str(Path(__file__).resolve()),'--fragmentation-only'],'elapsed_seconds':time.time()-tick,'errors':[]}
    assert hashlib.sha256(json.dumps({'small':old['small_fixtures'],'nested':old['nested_family']},sort_keys=True).encode()).hexdigest()==preserved
    old['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();dst.write_text(json.dumps(old,indent=2)+'\n')
    print(json.dumps({'fragmentation_checks':checks,'old30_small_and6_nested_preserved':True,'elapsed_seconds':time.time()-tick,'source_sha256':old['script_sha256'],'RESULT_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()},indent=2))

if '--fragmentation-only' in sys.argv:
    append_fragmentation_certificate()
    raise SystemExit(0)

small=[]
for f in FIXTURES:
 g=geometry(f);evaluations=[]
 for mode in ('sqrt_dimension','rational_decay'):
  for kind in ('old_exp_volume_order','remaining_volume_order','remaining_adaptive'):evaluations.append(algorithm(g,f['n'],mode,kind))
 small.append({'input':f,'geometry':serial(g),'comparisons':evaluations})
print('stage1 five true-core inputs completed',flush=True)
# Frozen nested1D family, algebraic product formulas instead of large coordinate arrangements.
r=Q(15,16);assert r<Q(31,33)
nested=[]
for stage,Ns in ((2,(64,256)),(3,(4096,))):
 for N in Ns:
  rr=ab(r);V=1-rr**N
  for mode in ('sqrt_dimension','rational_decay'):
   if mode=='sqrt_dimension':t=arb(1);x=(-arb(1)/32).exp();logx=-arb(1)/32;xs='exp(-1/32)'
   else:t=arb(1)/(32*arb(4).log());x=arb(1)/4;logx=-arb(4).log();xs='1/4 exact'
   D=2*(1-x)*(1-(rr*x)**N)/(1-rr*x);load=1-(N*logx).exp();assert D>0 and D<=2 and V>0
   # For very tiny x^N, the rounded load ball may contain1; the exact formula proves load<1.
   assert x>0 and x<1
   nested.append({'stage':stage,'N':N,'r':'15/16','a':32,'source_radius_formula':'s_j=r^j,j0..N-1','center_formula':'y_j=s_j;A_j=[0,2s_j]','core_formula':'[(31/32)s_j,(33/32)s_j]','core_disjointness_exact':'r=15/16<31/33,495<496','w_j_exact':'1/32','raw_common_parent_load_exact':str(Q(N,32)),'V_exact_factorized':'1-(15/16)^'+str(N),'V_Arb':str(V),'P0_exact':'2','P0_exact_certificate':'primaltheta0=1;dual mass2 uniformly on smallest parent[0,2r^(N-1)] dominates everydi=2r^j','mode':mode,'t_Arb':str(t),'x_exact_or_factorized':xs,'load_exact_factorized':'1-x^N','log_load_margin_N_log_x':str(N*logx),'load_Arb':str(load),'load_less_than1_analytic':True,'D_exact_factorized':'2(1-x)(1-((15/16)x)^N)/(1-(15/16)x)','D_Arb':str(D),'D_over_V':str(D/V),'D_over_P0':str(D/2),'all_three_algorithms_equal':True,'algorithm_order_proof':'All earlier larger parents contain every remaining parent;all remaining capacities equalx^j. Equalw makes immediate score proportionalto d_j,so adaptive also selects descendingradius. The old raw prefix isj/32.','no_large_grid_or_parent_list_enumerated':True})
 print('stage',stage,'nested sizes completed',list(Ns),flush=True)
out={'scope':'Five frozen direct finite entrances with real Lebesgue core disjointification, plus exactlythree frozen nested sizes. This is not an original high-tau clipping/history simulation and no tau is lowered. Feasible constructed values do not prove a uniform all-scale sqrt(n) guarantee.','python':sys.version,'platform':platform.platform(),'numpy_version':np.__version__,'scipy_version':scipy.__version__,'python_flint_version':flint.__version__,'precision_bits':ctx.prec,'command':[sys.executable,str(Path(__file__).resolve())],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'formulas':{'old':'L_j=esssup_Aj sum_(i beforej)wi1Ai;theta_j=exp(-L_j/t)(1-exp(-w_j/t))','remaining':'r_j=1-esssup_Aj sum_(selectedi)theta_i1Ai;theta_j=r_j(1-exp(-w_j/t))','adaptive':'At every step maximize d_j*r_j*(1-exp(-w_j/t)), recomputing capacities overall unselectedj;ties byoriginalID','common_parameters':['t=sqrt(n)','t=wmax/log4'],'exact_decay_note':'With wi/wmax in{1,1/2},z=exp(-wmax/(2t))=1/2 in the secondmode,so allsmall coefficients/objectives are Fraction exact. t itself is not rational.','owner_rule':'Original listed descending-radius partition fixed once;candidate ordering never recomputes owners.'},'small_fixtures':small,'nested_family':nested,'summary':{'small_input_count':len(small),'small_algorithm_parameter_runs':sum(len(s['comparisons']) for s in small),'nested_sizes':[64,256,4096],'nested_parameter_runs':len(nested),'all_real_owner_partitions_and_exact_P0_checks_passed':True,'all_small_candidate_feasibility_checks_passed':True,'all_Arb_ordering_comparisons_certified':True,'all_nested_formula_checks_passed':True},'elapsed_seconds':time.time()-start,'errors':[]}
(ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'summary':out['summary'],'elapsed_seconds':out['elapsed_seconds'],'source_sha256':out['script_sha256'],'RESULT_sha256':hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest(),'small_rational_values':[{'id':s['input']['id'],'V':s['geometry']['V'],'P0':s['geometry']['P0'],'runs':[{'algorithm':r['algorithm'],'order':r['order'],'D':r['objective']} for r in s['comparisons'] if r['parameter_mode']=='rational_decay']} for s in small],'nested_values':[{'N':r['N'],'mode':r['mode'],'D/V':r['D_over_V'],'raw_load':r['raw_common_parent_load_exact']} for r in nested]},indent=2))

append_fragmentation_certificate()
