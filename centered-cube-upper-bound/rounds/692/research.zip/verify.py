from pathlib import Path
from fractions import Fraction as Q
from itertools import product
import json,hashlib
from flint import arb,ctx
ctx.prec=768;p=Path(__file__).resolve().parent;r=json.loads((p/'RESULT.json').read_text())
assert hashlib.sha256((p/'NUMERIC.py').read_bytes()).hexdigest()==r['script_sha256']
def trim(a):
 a=list(a)
 while len(a)>1 and not a[-1]:a.pop()
 return tuple(a)
def add(a,b):return trim([(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def scale(a,c):return trim([c*v for v in a])
def mul(a,b):
 c=[Q(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return trim(c)
def ev(a,z):
 v=z*0
 for c in reversed(a):v=v*z+(Q(c) if isinstance(z,Q) else arb(str(Q(c))))
 return v
def vol(B):
 v=Q(1)
 for lo,hi in B:v*=hi-lo
 return v
count=0
for f in r['small_fixtures']:
 I=f['input'];n=I['n'];a=I['a'];N=len(I['parents']);radii=[Q(v['radius']) for v in I['parents']];centers=[list(map(Q,v['center'])) for v in I['parents']]
 boxes=[[(y-s,y+s) for y in c] for c,s in zip(centers,radii)];cores=[[(y-s/a,y+s/a) for y in c] for c,s in zip(centers,radii)]
 axes=[]
 for k in range(n):
  e=sorted({v for B in boxes+cores for v in B[k]});axes.append([(lo,hi) for lo,hi in zip(e,e[1:])])
 v=[Q(0)]*N;masks=set()
 for intervals in product(*axes):
  x=[(lo+hi)/2 for lo,hi in intervals];mask=sum((1<<j) for j,B in enumerate(boxes) if all(lo<z<hi for z,(lo,hi) in zip(x,B)))
  if mask:masks.add(mask)
  owners=[j for j,B in enumerate(cores) if all(lo<z<hi for z,(lo,hi) in zip(x,B))]
  if owners:v[min(owners)]+=vol(intervals)
 d=list(map(vol,boxes));w=[v[i]/d[i] for i in range(N)];g=f['geometry']
 assert v==list(map(Q,g['v_i'])) and w==list(map(Q,g['w_i'])) and sum(v)==Q(g['V']) and sorted(masks)==g['parent_masks']
 theta=list(map(Q,g['exact_packing_primal']));P=Q(g['P0']);assert sum(d[i]*theta[i] for i in range(N))==P
 assert all(sum(theta[i] for i in range(N) if m>>i&1)<=1 for m in masks)
 prices={x['mask']:Q(x['mass']) for x in g['exact_dual_mask_prices']};assert set(prices)<=masks and sum(prices.values())==P
 assert all(sum(val for m,val in prices.items() if m>>i&1)>=d[i] for i in range(N))
 for c in f['comparisons']:
  quarter=c['parameter_mode']!='sqrt_dimension';z=Q(1,2) if quarter else (-arb(str(max(w)))/(2*arb(n).sqrt())).exp()
  def cmp(x,y):
   if x==y:return 0
   b=ev(add(x,scale(y,-1)),z)
   if b>0:return 1
   if b<0:return -1
   assert quarter and b==0
   return 0
  def mx(polys):
   best=polys[0]
   for h in polys[1:]:
    if cmp(h,best)>0:best=h
   return best
  co=[(Q(0),)]*N;done=[]
  for j in c['order']:
   candidates={}
   for k in range(N):
    if k in done:continue
    power=2*w[k]/max(w);assert power.denominator==1
    alpha=add((Q(1),),tuple([Q(0)]*int(power)+[Q(-1)]))
    if c['algorithm']=='old_exp_volume_order':
     L=max(sum(w[i] for i in done if mask>>i&1) for mask in masks if mask>>k&1);e=2*L/max(w);assert e.denominator==1
     resid=tuple([Q(0)]*int(e)+[Q(1)])
    else:
     loads=[]
     for mask in masks:
      if mask>>k&1:
       load=(Q(0),)
       for i in done:
        if mask>>i&1:load=add(load,co[i])
       loads.append(load)
     resid=add((Q(1),),scale(mx(loads),-1))
    candidates[k]=mul(resid,alpha)
   if 'adaptive' in c['algorithm']:
    best=min(candidates)
    for k in sorted(candidates):
     if cmp(scale(candidates[k],d[k]),scale(candidates[best],d[best]))>0:best=k
    assert j==best
   else:assert j==len(done)
   co[j]=candidates[j];done.append(j)
  assert co==[trim(list(map(Q,x))) for x in c['theta_polynomials']]
  obj=(Q(0),)
  for i in range(N):obj=add(obj,scale(co[i],d[i]))
  assert obj==trim(list(map(Q,c['objective_polynomial'])))
  if quarter:assert ev(obj,z)==Q(c['exact_rational_objective'])
  else:assert arb(c['objective']).overlaps(ev(obj,z))
  for mask in masks:
   load=(Q(0),)
   for i in range(N):
    if mask>>i&1:load=add(load,co[i])
   assert ev(load,z)>=0 and ev(load,z)<1
  count+=1
assert count==30
for c in r['nested_family']:
 N=c['N'];x=(-arb(1)/32).exp() if c['mode']=='sqrt_dimension' else arb(1)/4
 rr=arb(15)/16;V=1-rr**N;D=2*(1-x)*(1-(rr*x)**N)/(1-rr*x)
 assert arb(c['V_Arb']).overlaps(V) and arb(c['D_Arb']).overlaps(D)
 assert 1-x**N<1 or c['load_less_than1_analytic'] # exact strictness can be smaller than precision
for c in r['fragmentation_parameter_certificate']['checks']:
 n=c['n'];a=32*n;t=arb(n).sqrt();rr=arb(a-2)/(a+2);VL=1-(arb(8)/a)**n;VT=(arb(1)/(2*a*a))**n/(1-rr**n)
 upper=((arb(2)/a)**n+VT)/VL+arb(-n).exp();xx=(1+arb(2)/a)**n/(arb(2)**n*t);lower=-(-xx).expm1()/xx
 assert arb(c['original_adaptive_tD_over_V_upper']).overlaps(upper)
 assert arb(c['rank_without_alpha_retention_lower']).overlaps(lower)
 assert upper<arb('0.02') and lower>arb('0.98')
if (p/'MANIFEST.json').exists():
 for name,digest in json.loads((p/'MANIFEST.json').read_text())['sha256'].items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
print('PASS: rebuilt 5 real owner partitions/P0 certificates,30 coefficient/order cases,6 nested formula cases,4 fragmentation parameter bounds; general conclusions require written proofs.')
