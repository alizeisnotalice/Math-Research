# R692 continuation: direct actual-capacity selection

General arbitrary-L1/all-scale/Lebesgue pure C_n<=Ksqrt(n) remains OPEN. Direct finite entrance is original cubes Ai, real disjoint owners Ei partition unionBi, vi=|Ei|,wi=vi/di, a=32n, original all-label P0. Owner assignment fixed once before selection; reordering selection does not silently redistribute owners. No old high-tau history is assumed for this direct route.

New legitimate rule: current packing F, rj=essinf_Aj(1-F), alphaj=1-exp(-wj/t), add theta_j=rj alphaj once. All cells remain feasible. Actual residual after everyupdate >=previous residual exp(-wj/t), hence theta_j >= old exponential formula on the SAME realized order. This is a real all-family coefficient improvement, not a new root value theorem.

For t=sqrt(n), D lies between W/(t+a^-n) and W/t, W=sum vi r_i at selection. A uniform W>=cV would imply root bound, but is not established for a generally successful rule.

The immediate increment ranking dj*rj*alphaj FAILS that value guarantee at prescribed t=sqrt(n) for a genuine fixed-owner family (see A1/REPORT). All parents share a positive cell, P0=2^n. Large radius1 centers form fine connected shell mesh in unit cube; after first large core, real owner fragments arbitrarily tiny. Tiny disjoint cores in central hole have high total coefficient rate, outrank all large fragments and consume common residual. Witha32n,K=ceil(n sqrt(n) a^n), tD/V <=[((2/a)^n+Vtiny)/(1-(8/a)^n)]+e^-n ->0. No arbitrary incidence or reducedtau fixture. Source mass/weighted tail retained. This is a failure of this specific fixed-temperature/owner rule, NOT originalgoal.

Do not broaden that failure: changing owners or choosing t from input is allowed; on sameclique t->0 makesfirstbig coefficient->1 and avoids failure. Fixed sqrt(n) temperature is therefore a sufficient design choice, not a necessity.

Minimal surviving repair: rank positive-owner labels by dj*rj, keeping actual increments alphaj*rj. It removes owner-fragment size from priority. On the failurefamily it processes allbig beforetiny and D_big=2^n[1-exp(-Vbig/(2^n t))]; certified ratio tD_big/Vbig>0.9835 in testedn4 onward. General cross-scale value still unproved. No claim of arbitrary refinement invariance or superiority to allorders. This candidate, input-adaptive temperatures, and using alloriginal labels remain legitimate freedoms; do not impose oldq caps or require updates onlyonreceiver labels.

Next substantial task: prove a quantitative whole-input objective for a fragment-robust actual-capacity selection usingcube productgeometry. Do not reprove feasibility, sameorder dominance, or merely rewrite W. Tests must distinguish new candidate decisions, not runanother unrelatedcounter scan.

Computation:5real smallfamilies with exactcore disjointification/P0,30coefficient/order cases at sqrt(n) andwmax/log4;6compressed nestedcases N64/256/4096;4Arb512failure/repair parametercases n4/16/64/256. Main verifier independently reconstructs geometry/order polynomials at768bits, confirms allcases. Full finite counterfamily itself proved analytically, not enumerated. NoMATLAB/PDF/install. Modelcap1Astra+3Sol respected.
