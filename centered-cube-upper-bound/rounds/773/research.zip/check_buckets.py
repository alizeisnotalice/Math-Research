"""R773. Two different middle-volume buckets on the same real source pair.
No positive overload, maximum deficiency cut, or asymptotic gap is asserted.
All comparisons below are rational outward enclosures, not sampled tests.
"""
from fractions import Fraction as F
from math import isqrt, prod
import json

n, a, h = 2, 64, F(65,64)
s, eps = F(17,16), F(1,2048)
two = lambda z: (z,z)

def box(c,r):
    return tuple((t-r,t+r) for t in c)

def area(q):
    return prod(max(F(0),v-u) for u,v in q)

def common(q,q1):
    return tuple((max(l,k),min(r,t)) for (l,r),(k,t) in zip(q,q1))

def inside(q,q1):
    return all(k<=l<=r<=t for (l,r),(k,t) in zip(q,q1))

def width(D):
    # outward rational enclosure of 2hR_b = h sqrt(2D)
    scale=10**18
    v=isqrt(2*D*scale**2)
    hi=v if v*v==2*D*scale**2 else v+1
    return (h*v/scale,h*hi/scale)

def score(Q1,Q2,t):
    lower=[]; upper=[]
    for (l1,r1),(l2,r2) in zip(Q1,Q2):
        dmin=max(F(0),l1-r2,l2-r1); dmax=max(abs(l1-r2),abs(r1-l2))
        lower.append(max(F(0),1-dmax/t[0])); upper.append(max(F(0),1-dmin/t[1]))
    return prod(lower),prod(upper)

def add(x,y): return (x[0]+y[0],x[1]+y[1])
def inv_ratio(x,y): return (x/y[1],x/y[0])
def sign(I): return 'positive' if I[0]>0 else 'negative' if I[1]<0 else 'undecided'

def case(d,z):
    ys=[two(-d),two(d),two(F(0)),(F(1,4),F(-1,4))]
    rs=[s,s,F(5,4),F(7,4)]; A=[box(y,r) for y,r in zip(ys,rs)]
    E=[box(y,r/a) for y,r in zip(ys,rs)]; m=list(map(area,A)); v=list(map(area,E))
    source=box(two(F(0)),F(4)); assert all(inside(B,source) for B in A)
    assert all(area(common(E[i],E[j]))==0 for i in range(4) for j in range(i)); assert area(common(A[0],A[1]))==0
    X=box(two(-z),eps); X1=box(two(z),eps); U=box(ys[0],eps); W=box(ys[1],eps)
    assert inside(X,A[0]) and inside(X1,A[1]) and inside(U,E[0]) and inside(W,E[1]); assert all(1<=r<2 for r in rs)
    probs=[]; mass_kernel=[]; BB=[]; AA=[]; signed=[]
    for D,i in [(4,2),(8,3)]:
        assert D<=m[i]<2*D and m[0]<m[i] and m[1]<m[i] and inside(X,A[i]) and inside(X1,A[i]); lohi=width(D)
        At=score(X,X1,lohi); Bt=add(score(X,W,lohi),score(X1,U,lohi))
        AA.append(tuple(t/D for t in At)); BB.append(tuple(t/D for t in Bt)); signed.append((Bt[0]-At[1],Bt[1]-At[0]))
        # Dirac states at four parents with edge mask restricted to leaf--middle.
        # Every path weight and every price/owner probability is actual for this graph.
        ij=area(common(A[i],A[0])); ik=area(common(A[i],A[1])); K0=ij/(m[i]*m[0]); K1=ik/(m[i]*m[1]); degree=v[0]*K0+v[1]*K1
        via_path=(v[i]*v[0]*v[1]*K0*K1/degree)*(area(X)/ij)*(area(X1)/ik)*(area(U)/v[0])*(area(W)/v[1])
        via_prices=(v[i]/(degree*m[i]**2))*area(X)*area(X1)*area(U)*area(W)/(m[0]*m[1]); assert via_path==via_prices>0
        probs.append(via_path); mass_kernel.append(v[i]/m[i]**2)
    aggregate=(sum(t[0] for t in BB)-sum(t[1] for t in AA),sum(t[1] for t in BB)-sum(t[0] for t in AA))
    C0=2*h**n
    intervals=[inv_ratio(k,(C0*c[0],C0*c[1])) for k,c in zip(mass_kernel,BB)]
    commonratio=inv_ratio(sum(mass_kernel),(C0*sum(t[0] for t in BB),C0*sum(t[1] for t in BB)))
    return [sign(q) for q in [*signed,aggregate]],probs,intervals,commonratio

def rational_bucket_mass_budget():
    # Exhaust all arbitrary arrays on up to 3 bins with positive/zero occupation and unequal costs.
    from itertools import product
    cases=0
    for nbin in (1,2,3):
        for ks in product(range(4),repeat=nbin):
            for cs in product(range(4),repeat=nbin):
                for H in (F(1,3),F(1),F(7,3)):
                    S=H*sum(cs); total=sum(ks); common_gate=total<=S
                    charge=sum(k for k,c in zip(ks,cs) if common_gate or k<=H*c)
                    assert charge<=S
                    # Simultaneous fractional allocation, including zero and tied buckets.
                    ts=[min(F(k),H*c) for k,c in zip(ks,cs)]; t=sum(ts)
                    theta=(min(total,S)-t)/(total-t) if t<total else F(0)
                    amounts=[v+theta*(k-v) for k,v in zip(ks,ts)]
                    assert 0<=theta<=1 and all(0<=v<=k for v,k in zip(amounts,ks)) and sum(amounts)==min(total,S)
                    cases+=1
    return cases

def thinning_on_original_degrees():
    # Independent check on the 1-D fixture in the main certificate. Absolute
    # continuous mass, first-arm weights and all transition denominators fixed.
    from pathlib import Path
    model=json.loads(Path(__file__).with_name('verify.json').read_text())['finite_true_prices_and_owners']
    names=('L','R','M0','M1'); m=[F(model['m'][name]) for name in names]
    hist=[(i,F(j),tuple(map(F,interval))) for i,j,interval in model['histories']]
    cuts=sorted({F(k,4) for k in range(-32,33)} | {t for i,j,interval in hist for t in interval})
    cells=[((a+b)/2,(b-a)*F(1 if ((4*(a+b)/2).__floor__() % 2)==0 else 3,2)) for a,b in zip(cuts,cuts[1:])]
    ret=[]
    for threshold in (F(1,48),F(1,32),F(3,64)):
        orig=kept=direct=loss_bound=F(0)
        for e in (2,3,4):
            i,Ie,Ce=hist[e]; degree=down=after=leak=F(0); states=[]
            for x,mu in cells:
                if not Ce[0]<x<Ce[1]: continue
                valid=[(j,Iu) for j,Iu,Cu in hist if j!=i and Cu[0]<x<Cu[1]]
                degree+=mu/m[i]*sum(Iu/m[j] for j,Iu in valid)
                by_arm=[mu/m[i]*Iu/m[j] for j,Iu in valid if m[j]<m[i]]
                t=sum(Iu/m[j] for j,Iu in valid if m[j]<m[i]); arm=sum(by_arm); in_X=not (F(9,4)<x<F(5,2))
                weight=max(F(0),1-threshold/t) if in_X and t else F(0)
                down+=arm; after+=weight*arm; leak+=arm*(not in_X)
                states.extend(weight*v for v in by_arm)
            assert degree==F(next(rr['d'] for rr in model['rows'] if rr['center_history']==e)) and 0<down<=degree
            direct+=Ie/degree*sum(u*v for u in states for v in states)
            kept+=Ie*after**2/degree; orig+=Ie*down**2/degree
            loss_bound+=2*Ie*(down/degree)*(threshold+leak)
        assert orig==F(model['total_normalized']['all']) and direct==kept and 0<kept<orig and orig-kept<=loss_bound
        ret.append({'tau':str(threshold),'initial':str(orig),'retained_by_both_orders':str(kept),'true_loss':str(orig-kept),'proved_loss_bound':str(loss_bound)})
    return ret

def main():
    trials=[(F(35,32),F(7,16),['negative','positive','positive']),
            (F(35,32),F(1,4),['negative','positive','negative']),
            (F(25,16),F(5,8),['negative','negative','negative'])]
    rows=[]
    for d,z,expected in trials:
        signs,probs,R,agg=case(d,z); assert signs==expected
        if z==F(7,16):
            # A single rational H chosen for the whole positive four-mark cylinder.
            H=F(139,1000000)
            assert R[1][1]<H and agg[1]<H<R[0][0]
            robust=str(H)
        else: robust=None
        rows.append({'d':str(d),'z':str(z),'signs_mixed_minus_true_at_H1_bins_and_sum':signs,'positive_local_peak_cylinder_mass_per_middle':[str(p) for p in probs],'H_checked_actual_joint_gate_passes_and_low_bucket_fails':robust})
    print(json.dumps({'rational_allocation_cases':rational_bucket_mass_budget(),'two_bucket_experiments':rows,'two_price_thinning':thinning_on_original_degrees()},sort_keys=True,indent=2))

if __name__=='__main__': main()
