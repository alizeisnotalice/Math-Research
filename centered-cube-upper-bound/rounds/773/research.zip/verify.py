#!/usr/bin/env python3
"""Fraction certificate for the R773 price-pair and crossed receiver kernels."""

import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import platform
import sys


def interval(a, b):
    return F(a), F(b)


def meet(i, j):
    return max(i[0], j[0]), min(i[1], j[1])


def length(i):
    return max(F(0), i[1] - i[0])


def contains(i, j):
    return i[0] <= j[0] <= j[1] <= i[1]


def midpoint(i):
    return (i[0] + i[1]) / 2


def volume(box):
    v = F(1)
    for axis in box:
        v *= length(axis)
    return v


def kernel(delta, width):
    return max(F(0), 1 - abs(delta) / width)


def score_bounds(i, j, width):
    diff = j[0] - i[1], j[1] - i[0]
    near = F(0) if diff[0] <= 0 <= diff[1] else min(map(abs, diff))
    return kernel(max(map(abs, diff)), width), kernel(near, width)


def clip(poly, level, above):
    def offset(point):
        signed = point[1] - point[0] - level
        return signed if above else -signed

    out = []
    for a, b in zip(poly, poly[1:] + poly[:1]):
        fa, fb = offset(a), offset(b)
        if fa >= 0:
            out.append(a)
        if (fa >= 0) != (fb >= 0):
            t = fa / (fa - fb)
            out.append(tuple(a[k] + t * (b[k] - a[k]) for k in range(2)))
    return out


def direct_kernel_integral(i, j, width):
    """Clip the actual price-owner rectangle into affine pieces."""
    poly = [(i[0], j[0]), (i[1], j[0]), (i[1], j[1]), (i[0], j[1])]
    result = F(0)
    for segment in [(-width, F(0)), (F(0), width)]:
        piece = clip(clip(poly, segment[0], True), segment[1], False)
        for k in range(1, len(piece) - 1):
            a, b, c = piece[0], piece[k], piece[k + 1]
            twice = abs((b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0]))
            result += twice * sum(kernel(y-x, width) for x, y in [a, b, c]) / 6
    return result


def fubini_kernel_integral(i, j, width):
    """Independent truncated cubic antiderivative."""
    def primitive(t):
        return (max(0, t+width)**3 - 2*max(0,t)**3 + max(0,t-width)**3)/(6*width)

    a, b = i
    c, d = j
    return primitive(d-a) - primitive(c-a) - primitive(d-b) + primitive(c-b)


def rational_model():
    a, D, R, H = 32, F(4), F(4), F(2)
    h = 1 + F(1, a)
    width = 2*h*R
    names = ("L", "R", "M0", "M1")
    P = tuple(interval(*pair) for pair in [
        (-8, -2), ("9/4", "31/4"), ("-7/2", "7/2"), (-3, "7/2")
    ])
    s = tuple(length(i)/2 for i in P)
    y = tuple(map(midpoint, P))
    E = tuple((c-r/a, c+r/a) for c,r in zip(y,s))
    v = tuple(map(length, E))
    assert all(contains(p, e) for p,e in zip(P,E))
    assert all(not length(meet(E[i],E[j])) for i in range(4) for j in range(i))
    density = tuple(((F(k,4), F(k+1,4)), F(1 if k % 2 == 0 else 3, 2))
                    for k in range(-32,32))

    def pieces(i):
        return tuple((meet(i,u), w) for u,w in density if length(meet(i,u)))

    def mu(i):
        return sum(w*length(u) for u,w in pieces(i))

    m = tuple(map(mu,P))
    assert m == tuple(2*r for r in s)
    assert all(D <= mi < 2*D for mi in m)
    histories = [
        (0, v[0], interval("-31/4",-2)),
        (1, v[1], interval("9/4","15/2")),
        (2, 2*v[2]/3, P[2]),
        (2, v[2]/3, interval("-13/4","13/4")),
        (3, v[3], interval(-3,"27/8")),
    ]
    label, I, C = map(tuple,zip(*histories))
    keys = tuple(range(len(I)))
    assert all(contains(P[label[e]],C[e]) for e in keys)
    j = tuple(sum(I[e] for e in keys if label[e]==i) for i in range(4))
    assert j == v
    overlap = {(e,f): meet(C[e],C[f]) for e,f in product(keys,repeat=2)}
    K = {(e,f): mu(overlap[e,f])/(m[label[e]]*m[label[f]]) if label[e]!=label[f]
         else F(0) for e,f in product(keys,repeat=2)}
    d = tuple(sum(I[f]*K[e,f] for f in keys) for e in keys)
    assert all(d) and all(K[e,f] == K[f,e] for e,f in K)
    centers = (2,3,4)
    Y_mid = sum(I[e] for e in centers)

    def subdivision(cells):
        for (a,b), w in cells:
            step = (b-a)/4
            for k in range(4):
                yield (a+k*step,a+(k+1)*step), w

    def bracket(L, Q, left_owner, right_owner):
        pass_mass = fail_mass = unknown = F(0)
        for (i,wi),(l,wl) in product(subdivision(L),subdivision(Q)):
            al,ah = score_bounds(i,l,width)
            bl,bh = score_bounds(i,right_owner,width)
            cl,ch = score_bounds(l,left_owner,width)
            mass = wi*length(i)*wl*length(l)
            if al > H*(bh+ch):
                pass_mass += mass
            elif ah <= H*(bl+cl):
                fail_mass += mass
            else:
                unknown += mass
        return pass_mass,fail_mass,unknown

    totals = dict.fromkeys(("A","B1","B2","all","pass","fail","unknown"),F(0))
    rows = []
    raw_low = raw_high = F(0)
    for e in centers:
        neighbors = [f for f in keys if s[label[f]] < s[label[e]] and K[e,f]>0]
        price_cells = {f: pieces(overlap[e,f]) for f in neighbors}
        owners = {f: E[label[f]] for f in neighbors}
        arm = {f: I[f]*K[e,f] for f in neighbors}
        arm_score = sum(arm.values())
        row = dict.fromkeys(totals,F(0))
        asymmetric = 0
        for f,g in product(neighbors,repeat=2):
            L,Q = price_cells[f],price_cells[g]
            Jd, Kd = mu(overlap[e,f]), mu(overlap[e,g])
            cf = arm[f]*arm[g]
            am = sum(wi*wl*direct_kernel_integral(i,l,width)
                     for (i,wi),(l,wl) in product(L,Q))/(Jd*Kd)
            b1 = sum(w*direct_kernel_integral(i,owners[g],width) for i,w in L)/(Jd*v[label[g]])
            b2 = sum(w*direct_kernel_integral(i,owners[f],width) for i,w in Q)/(Kd*v[label[f]])
            passed,failed,unknown = bracket(L,Q,owners[f],owners[g])
            assert passed+failed+unknown == Jd*Kd
            for key,value in zip(row,(am,b1,b2,1,passed/(Jd*Kd),failed/(Jd*Kd),unknown/(Jd*Kd))):
                row[key] += cf*value
            asymmetric += b1 != b2

        # Reassemble the density of one whole descending arm in absolute price order.
        breaks = sorted({x for f in neighbors for i,w in price_cells[f] for x in i})
        cells = []
        for left,right in zip(breaks,breaks[1:]):
            u = (left,right)
            coeff = sum(I[f]/(m[label[e]]*m[label[f]]) for f in neighbors
                        if contains(overlap[e,f],u))
            if coeff:
                cells.append((u, coeff*mu(u)/length(u)))
        assert sum(length(u)*w for u,w in cells) == arm_score
        alt_a = sum(wi*wl*fubini_kernel_integral(i,l,width)
                    for (i,wi),(l,wl) in product(cells,repeat=2))
        alt_b = sum(w*arm[g]*fubini_kernel_integral(i,owners[g],width)/v[label[g]]
                    for (i,w),g in product(cells,neighbors))
        assert row["A"] == alt_a and row["B1"] == row["B2"] == alt_b
        assert row["all"] == arm_score**2 <= d[e]**2
        raw_low += I[e]*row["pass"]
        raw_high += I[e]*(row["all"]-row["fail"])
        for key in row:
            totals[key] += I[e]*row[key]/d[e]
        rows.append({"center_history": e, "parent": names[label[e]],
                     "d": d[e], "descending_arm_mass": arm_score,
                     "peaks": len(neighbors)**2, "asymmetric_ordered_peaks": asymmetric,
                     "M_before_degree_division": row})
    assert totals["all"] == totals["pass"] + totals["fail"] + totals["unknown"]
    q_lo, q_hi = totals["pass"], totals["all"]-totals["fail"]
    assert 0 < q_lo <= q_hi < totals["all"]
    assert q_hi**2 <= Y_mid*raw_low

    # Exhaust positive rectangular price strata, including all boundaries, for the bucket.
    points = sorted(set(x for i in P for x in i))
    atoms = list(zip(points,points[1:])) + [(p,p) for p in points]
    checked = 0
    largest_ratio = F(0)
    for u,w in product(atoms,repeat=2):
        eligible = [i for i,p in enumerate(P) if contains(p,u) and contains(p,w)]
        if not eligible:
            continue
        for i in eligible:
            assert E[i][0] >= max(u[1],w[1])-h*R and E[i][1] <= min(u[0],w[0])+h*R
        exact_min_A,_ = score_bounds(u,w,width)
        volume_cap = width*exact_min_A
        assert sum(v[i] for i in eligible) <= volume_cap
        lhs = sum(j[i]/m[i]**2 for i in eligible)
        rhs = 2*h*exact_min_A/D
        assert 0 < lhs <= rhs
        largest_ratio = max(largest_ratio,lhs/rhs)
        checked += 1

    normalizers = []
    for x in points:
        pieces_of_triangle = [(x-width,x), (x,x+width)]
        normalizer = sum(length(i)*sum(kernel(v-x,width) for v in i)/2
                         for i in pieces_of_triangle)
        assert normalizer == 2*h*D
        normalizers.append(normalizer)

    return {"n": 1, "D": D, "R": R, "a": a, "h": h, "H":H,
            "parents": dict(zip(names,P)), "owners": dict(zip(names,E)),
            "m": dict(zip(names,m)), "histories": histories,
            "mu": "on [-8,8], periodic of period 1/2, density 1/2 then 3/2 on quarter intervals",
            "mask": "strict physical descent from designated centers, original K retains all positive true intersections between distinct parent labels",
            "scope": "no endpoint-halo, entropy, high-density pair or other upstream terminal screens; H=2 is a finite diagnostic",
            "rows": rows, "peak_count": sum(row["peaks"] for row in rows),
            "total_normalized": totals, "Y_mid":Y_mid, "all_state_mass":sum(I),
            "decision_labels": {"pass":"certified A > H(B1+B2): unpaid by the geometric bucket test", "fail":"certified A <= H(B1+B2): paid by that test", "unknown":"whole-cell classification not decided"},
            "q_interval":[q_lo,q_hi],
            "raw_M_interval": [raw_low,raw_high],
            "Cauchy_including_uncertain_price_cells": [q_hi**2,Y_mid*raw_low],
            "bucket_check": {"positive_price_strata":checked,"max_lhs_over_certified_rhs":largest_ratio,
                             "fixed_price_receiver_normalizer":normalizers[0],
                             "receiver_anchors_checked":len(normalizers)},
            "joint_intersection_and_receiver_integrals": "exact direct polygon integration equals separately assembled price densities and independent cubic primitive"}


def kernel_geometry():
    out = []
    for n in (1,2,3):
        h = 1+F(1,32*n)
        R = F(1)
        D = F(2)**(n-1)
        a = h*R
        width = 2*a
        cube = ((-a,a),)*n
        for shifts in ((F(0),)*n, tuple((-1)**k*a/2 for k in range(n)),
                       (width,)+(F(0),)*(n-1),(width+1,)+(F(0),)*(n-1)):
            common = tuple(meet((-a,a),(t-a,t+a)) for t in shifts)
            prod = F(1)
            for t in shifts:
                prod *= kernel(t,width)
            assert prod == volume(common)/volume(cube)
        # Cellwise corner integration of the multilinear kernel on the whole support.
        whole = F(0)
        for cell in product([(-width,F(0)),(F(0),width)],repeat=n):
            values = []
            for corner in product(*cell):
                value = F(1)
                for t in corner:
                    value *= kernel(t,width)
                values.append(value)
            whole += volume(cell)*sum(values)/len(values)
        assert whole == 2*h**n*D
        out.append({"n":n,"R":R,"D":D,"normalizer":whole,"translations_checked":4})
    return out


def enclosure(x, decimals=14):
    if not x:
        return ["0", "0"]
    scale, exponent = 1, 0
    while x.numerator*scale < x.denominator:
        scale *= 10
        exponent -= 1
    unit = 10**decimals
    q,r = divmod(x.numerator*scale*unit,x.denominator)

    def format_scaled(z):
        return f"{z//unit}.{z%unit:0{decimals}d}e{exponent:+d}"

    return [format_scaled(q),format_scaled(q+bool(r))]


def enlarged_mismatch():
    out = []
    for n in (8,32,128,512):
        a, R, H = 32*n, F(1), F(2)
        h = 1+F(1,a)
        width = 2*h*R
        s0 = 1-F(1,4*n)
        assert F(1,2) <= s0**n < 1
        eta = F(1,256*n)
        p = F(1,64*n)
        cases = [
            ("both_crossed_values_small", F(1,2), F(3,4),
             -F(1,2)+8*p, F(3,4)-8*p, -p, p),
            ("opposite_control", F(5,8), F(3,4), F(1,4), -F(1,4), -F(1,4), F(1,4))
        ]
        for name,sj,sk,yj,yk,x,z in cases:
            assert max(sj,sk)<s0
            parentj,parentk = (yj-sj,yj+sj),(yk-sk,yk+sk)
            ownerj,ownerk = (yj-sj/a,yj+sj/a),(yk-sk/a,yk+sk/a)
            c0 = -s0,s0
            price1,price2 = (x-eta,x+eta),(z-eta,z+eta)
            assert contains(c0,price1) and contains(c0,price2)
            assert contains(parentj,price1) and contains(parentk,price2)
            assert not length(meet(ownerj,ownerk))
            assert all(not length(meet(e,(-s0/a,s0/a))) for e in (ownerj,ownerk))
            A = [v**n for v in score_bounds(price1,price2,width)]
            B1 = [v**n for v in score_bounds(price1,ownerk,width)]
            B2 = [v**n for v in score_bounds(price2,ownerj,width)]
            B = [u+v for u,v in zip(B1,B2)]
            if name == "both_crossed_values_small":
                assert A[0] > H*B[1]
            else:
                assert A[1] < H*B[0]
            out.append({"n":n,"case":name,"R":R,"H":H,"middle_radius":s0,
                        "radii":[sj,sk],"endpoint_centers":[yj,yk],"price_centers":[x,z],
                        "price_half_width":eta,"A":[enclosure(v) for v in A],
                        "cross_1":[enclosure(v) for v in B1],
                        "cross_2":[enclosure(v) for v in B2]})
    return {"scope":"actual product parent and owner boxes; positive price subboxes under uniform Lebesgue, no upstream terminal masks",
            "proof_method":"rational one-coordinate score extrema raised to dimension before comparing; decimal strings enclose exact endpoints",
            "cases":out}


def audit():
    return {"python": sys.version.split()[0], "interpreter": sys.executable,
            "platform":platform.machine(), "arithmetic":"exact Python fractions; outward decimal display only for high-dimensional extrema",
            "command":"python -B verify.py --check verify.json",
            "finite_true_prices_and_owners":rational_model(),
            "kernel_geometry":kernel_geometry(),
            "high_dimensional_mismatch":enlarged_mismatch()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--output", type=Path)
    mode.add_argument("--check", type=Path)
    args = parser.parse_args()
    result = audit()
    data = json.dumps(result, default=lambda x: str(x) if isinstance(x,F) else vars(x),
                      sort_keys=True, indent=2)+"\n"
    if args.output:
        args.output.write_text(data)
    else:
        assert args.check.read_text()==data, "certificate differs from fresh calculation"
    diag = result["finite_true_prices_and_owners"]
    print(f"R773: {diag['peak_count']} true finite peaks; q interval {diag['q_interval']}; "
          f"{len(result['high_dimensional_mismatch']['cases'])} tensor cases")


if __name__ == "__main__":
    main()
