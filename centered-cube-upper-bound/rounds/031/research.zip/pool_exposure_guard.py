from fractions import Fraction as F
from decimal import Decimal as D,localcontext
from pathlib import Path
from math import factorial
import json

def dc(x):return D(x.numerator)/D(x.denominator) if isinstance(x,F) else D(x)
def tail(q,k):
 if not q:return D(0)
 term=(-q).exp();low=term
 for j in range(1,k):term*=q/j;low+=term
 if q>k:return 1-low
 term*=q/k;total=term;j=k
 while term>max(total,D('1e-1000'))*D(10)**(-__import__('decimal').getcontext().prec+8):
  j+=1;term*=q/j;total+=term
 return total

def make_gate(entries,caps,threshold,B):
 cuts=sorted(set([F(1),B]+[v for v in entries+caps if 1<v<B]));out=[]
 for a,b in zip(cuts,cuts[1:]):
  mid=(a+b)/2
  if sum(e<=mid<c for e,c in zip(entries,caps))>=threshold:
   if out and out[-1][1]==a:out[-1]=(out[-1][0],b)
   else:out.append((a,b))
 return out

def exposure(intervals,outs):
 # Clock variable w=L^n=e^t, h=1/w (lambda=m).
 # outs contains (actual source capture w, physical mass).
 # Gates are half-open [a,b): an outside entry at b is not captured
 # on this gate. Right-end terms use q(b-), including at terminal B.
 direct=F(0)
 for e,mass in outs:
  starts=[max(a,e) for a,b in intervals if e<b]
  if starts:direct+=mass/min(starts)
 def q(w):return sum((mass/w for e,mass in outs if e<=w),F(0))
 def qleft(w):return sum((mass/w for e,mass in outs if e<w),F(0))
 occupation=F(0)
 for a,b in intervals:
  cuts=sorted(set([a,b]+[e for e,mass in outs if a<e<b]))
  for l,r in zip(cuts,cuts[1:]):
   mass=sum((mass for e,mass in outs if e<=(l+r)/2),F(0))
   occupation+=mass*(1/l-1/r)
 if not intervals:return dict(direct=F(0),occupation=F(0),gap=F(0),terminal=F(0),separated=F(0))
 gap=sum(((1-b/a2)*qleft(b) for (a,b),(a2,b2) in zip(intervals,intervals[1:])),F(0))
 terminal=qleft(intervals[-1][1]);assert direct==occupation+gap+terminal
 # Greedily retain a sequence with e^(time gap)>=2.
 selected=[]
 for a,b in intervals:
  if not selected or a>=2*selected[-1]:selected.append(a)
 assert direct>=F(1,2)*sum((q(w) for w in selected),F(0))
 assert all(direct>=q(a) and direct>=qleft(b) for a,b in intervals)
 return dict(direct=direct,occupation=occupation,gap=gap,terminal=terminal,separated=F(1,2)*sum((q(w) for w in selected),F(0)))

def geometry():
 out=[]
 for n in (1,2,4,16,128):
  for k in (2,3,5,17):
   for x in (F(-1,10),F(0),F(1,10)):
    # Actual axial atom positions, deterministic admissible mark caps.
    entries=[];caps=[]
    for y,cap in ((F(0),F(9,8)),(F(5,8),F(3,2)),(F(13,16),F(7,4)),(F(15,16),F(2))):
     for j in range(k):
      entries.append(max(F(1),2*abs(x-y))**n)
      caps.append(min(F(2),cap+F(j,100*k))**n)
    B=F(2)**n
    outs=[(max(F(1),2*abs(x-y))**n,F(j+1,7)) for j,y in enumerate((F(0),F(11,20),F(7,10),F(9,10),F(11,10)))]
    J=make_gate(entries,caps,k-1,B);H=make_gate(entries,caps,k,B)
    ej=exposure(J,outs);eh=exposure(H,outs)
    assert ej['direct']>=eh['direct']
    out.append(dict(n=n,k=k,x=str(x),nearhit_intervals=[list(map(str,z)) for z in J],hit_intervals=[list(map(str,z)) for z in H],nearhit={a:str(b) for a,b in ej.items()},hit_exposure=str(eh['direct'])))
 return out

def probability(precision):
 with localcontext() as ctx:
  ctx.prec=precision;pure=[];barriers=[];budgets=[]
  for k in (2,4,16,64):
   for qa in (D('.25'),D(k),D(2*k)):
    for qb in (D('.1'),D(k)/2,D(k)):
     q=qa+qb;pool=(-qb).exp()*tail(qa,k);last=tail(q,k)*(qa/q)**k
     assert pool<=last+D(10)**(-precision+12)
     pure.append(dict(k=k,qa=str(qa),qb=str(qb),pool=format(pool,'.16g'),last_tuple=format(last,'.16g')))
   # A has a real hit and dies before B's deterministic later source entry.
   # Near-hit outside exposure is zero, but the remaining barrier probability
   # equals P(Poi(qb)<=k-1), rather than one.
   for qb in (D('.25'),D(k),D(2*k)):
    failure=tail(qb,k);chi=1-failure
    assert 0<failure<1 and 0<chi<=1
    barriers.append(dict(k=k,qb=str(qb),nearhit_exposure='0',remaining_barrier=format(chi,'.16g'),failure_probability=format(failure,'.16g')))
  for T in (D(0),D('.01'),D(1),D(100),D('1e6'),D('1e16')):
   m=int((64*(2+T).ln()).to_integral_value(rounding='ROUND_CEILING'));coeff=(D(m)/D(m+1)+m*T)/(2+T)**8
   assert coeff<1
   budgets.append(dict(T=str(T),m=m,high_exposure_cost=format(coeff,'.16g'),tv_lipschitz=format(m*(1+T),'.16g')))
  return dict(pure_death_pool=pure,remaining_barrier=barriers,budgets=budgets)

def replication():
 out=[]
 for n in (1,2,8,64):
  for depth in (1,2,4,8,16):
   N=2**depth;W0=F(7,3);R0=F(5,4);W=N*W0;R=N*R0
   assert R/W==R0/W0
   level_total=sum((F(2**j)*F(N,2**j)*W0 for j in range(depth)),F(0));assert level_total==depth*W
   for eps in (F(1,10),F(1,1000),F(1,10**8)):
    assert R/(W*(1+eps))==(R0/W0)/(1+eps)
   out.append(dict(n=n,depth=depth,copies=N,ratio=str(R/W),per_level_mass_cost=str(level_total/W)))
 return out

if __name__=='__main__':
 g=geometry();p=probability(70);assert p==probability(110);r=replication()
 result=dict(status='PASS; general square-root bound remains unproved',geometry=g,**p,replication=r,notes=['Fraction geometry uses actual source capture scales and finite mark paths; it checks identities, not a spatial weak upper bound.','Poisson formulas repeated at Decimal70/110, not interval certificates.','Replication numeric ratios are symbolic algebra checks with illustrative W0,R0; the arbitrary-source replication theorem is proved separately.','Half-open active gates use e<b and right-end q(b-); simultaneous terminal entry/death is excluded exactly.','No random sampling or seeds.'])
 Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',len(g),'actual geometric paths;',len(p['pure_death_pool']),'pool comparisons;',len(p['remaining_barrier']),'barrier guards;',len(p['budgets']),'budgets;',len(r),'replication checks')
