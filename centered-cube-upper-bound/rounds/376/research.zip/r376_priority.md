# R376 — Measurable benefit-priority truncation with a fixed cap of two

## 1. Exact frozen contract

Use the actual full-f field and common kernel of R375. In particular all original receiver du, masses m_u=f(Q_u), q band, masks, original source-dependent J/H/strict past, and physical clock remain frozen. For each actual small receiver v, let U_v be uniform probability on its actual cube, μ_v^+=d_vP_v its normalized surplus source measure (0≤d_v≤1), and

\[
 0\le K_v(y,z)\le L_v(y)\le B,\quad
 r_v(y)=E_{U_v}K_v(y,\cdot),\quad
 C_v(y,z)=L_v(y)-K_v(y,z),\quad g_v(y)=L_v(y)-r_v(y).
\]

Here B=[1+n log(b/a)]/h>0 is the established actual-center bound. The common K is already aggregated over all actual large receivers u, with the original mark ω_u(y) at its original source y. Write

\[
 b_v(y,z)=g_v(y)-C_v(y,z)=K_v(y,z)-r_v(y).
\]

Assume a jointly measurable proposal density ρ_v^0 with E_Uρ^0(y,·)=1 for P_v-almost every y, and

\[
 \rho_v^0(y,z)>0\Longrightarrow 0\le C_v(y,z)\le\xi g_v(y),\qquad 0<\xi<1. \tag{1}
\]

The explicit countably selected near-box proposal in R375 geometry satisfies this. On g=0, its uniform fallback has C=0 U-almost everywhere. Thus b≥(1−ξ)g≥0 on proposal support, and b≤B there. All null sets below are kernel null sets; a positive-mass unsupported fallback with negative benefit is not permitted. If d_v=0 set the final plan to zero and omit every v contribution; no proposal is needed there.

The construction and exact gain actually need only proposal-supported b≥0, not the stronger bound (1).

## 2. The measurable water level

Suppress v temporarily and put H(z)=E_Pρ^0(y,z). Tonelli gives E_UH=1, so H<∞ U-almost everywhere. Set H=0 on its U-null infinite set and set ρ^0=0 there. This leaves the joint measure and P-almost every row integral unchanged.

There is a unique a∈(1,2] satisfying

\[
 \boxed{E_U\max(H,a)=a+E_U(H-a)_+=2.} \tag{2}
\]

Indeed this function is continuous and 1-Lipschitz in a. At a=1 it equals 2−E_Umin(H,1)<2, and at a=2 it is at least 2. It is strictly increasing on [1,2], since U{H≤1}>0: otherwise H>1 almost everywhere would contradict E_UH=1. Measurability in v follows, for example, by expressing the infimum of the superlevel set ≥2 with rational a and using continuity. Define

\[
 h_z=\min(H(z),a),\quad
 \delta=1-E_Uh_z=E_U(H-a)_+=2-a. \tag{3}
\]

In particular δ∈[0,1). This is a per-v water level, selected before the common plan; it is not separately chosen for each original large receiver u.

## 3. Explicit measurable benefit-priority retention

At each z, consider the finite proposal-source measure M_z(dy)=ρ^0(y,z)P(dy), of mass H(z). Retain mass h_z, prioritizing largest benefit b.

If H≤a retain everything: k(y,z)=ρ^0(y,z). If H>a, define

\[
 T_z(s)=\int 1_{\{b(y,z)>s\}}\,M_z(dy),\quad
 c_z=\inf\{s\in[0,B]:T_z(s)\le a\}.
\]

By continuity of measures from above/below,

\[
 T_z(c_z)\le a\le M_z\{b\ge c_z\}.
\]

Let e_z=M_z{b=c_z} and set θ_z=(a−T_z(c_z))/e_z when e_z>0, and θ_z=0 otherwise. In the latter case T_z(c_z)=a. Set

\[
 k(y,z)=\rho^0(y,z)
 [1_{\{b>c_z\}}+\theta_z1_{\{b=c_z\}}]\quad(H>a). \tag{4}
\]

Thus 0≤k≤ρ^0 and E_Pk=h_z exactly. In particular if the cutoff is c_z=0, sufficient zero-benefit mass is retained to fill h_z. Omitting that mass would change δ and invalidate (2) as the exact refill identity. The parameterized tail, rational quantile, threshold atom, and (4) are jointly measurable. Negative b values outside proposal support have zero M_z measure and play no role. The case H=0 is k=0.

For every measurable competitor 0≤k'≤ρ^0 with E_Pk'=h_z,

\[
 \int b k'\,dP\le\int_0^B\min\{h_z,T_z(s)\}\,ds
 =\int_0^B\min\{a,T_z(s)\}\,ds. \tag{5}
\]

This follows from layer cake: retained mass above level s is at most both h_z and T_z(s). Formula (4) attains these bounds for almost every s. The equality at the right uses T_z(s)≤H. This proves exact optimal retention within the stated column submeasure class by a direct positive construction; no infinite-dimensional strong duality is invoked. Strict/non-strict benefit tails differ only at countably many atom levels in (5), but the threshold atom must be fractionally allocated in (4).

### Optimality in the entire proposal-subflow plus uniform-refill class

The water level need not be prescribed in a competing plan. Take any jointly measurable 0≤k'≤ρ^0, let T=E_{PU}k'∈[0,1] and R(z)=E_Pk'(·,z), and refill each source row uniformly by 1−E_Uk'. Its target density is R(z)+1−T. If this is at most two, then R≤1+T and R≤H. Consequently

\[
 T\le E_U\min(H,1+T)=1-E_U(H-1-T)_+,
 \quad F(1+T):=1+T+E_U(H-1-T)_+\le2.
\]

The strict monotonicity from §2 implies 1+T≤a, and hence R≤a. Layer cake with b≥0 now bounds every such candidate's reward by the right side of (5), even if its retained column mass is smaller. Our construction attains that bound at every column, with retained total T=a−1. Thus it is **optimal within the entire fixed-proposal subflow plus uniform-refill class under aggregate cap two**, not merely for a preassigned water level. This is a direct attainable upper bound; it is not a claim of optimality among arbitrary common plans with target≤2dU. Positivity of benefit on the proposal is necessary for the monotone fill-to-cap argument.

## 4. Source refill, exact cost, and original template fee

Put

\[
 \beta(y)=1-E_Uk(y,\cdot)\in[0,1],\qquad
 \rho(y,z)=k(y,z)+\beta(y),\qquad
 \tau_v(dy,dz)=d_v\rho_v(y,z)P_v(dy)U_v(dz). \tag{6}
\]

Every row has integral one. Moreover E_Pβ=δ, so the target marginal is exactly

\[
 d_v[\min(H_v(z),a_v)+\delta_v]U_v(dz)\le2d_vU_v(dz). \tag{7}
\]

There is no row density cap on the retained part, and no loss of original source mass. Source labels, including their marks, stay at y. Write the exact gain

\[
 \boxed{\mathcal R=\int_Ed_v\,dv\int U_v(dz)\int_0^B
       \min\{a_v,T_{v,z}(s)\}\,ds.} \tag{8}
\]

The exact new bad cost is

\[
 \boxed{G_{\rm priority}=G_{\rm joint}-\mathcal R\ge0.} \tag{9}
\]

Indeed each row has cost E_U(kC)+βg=g−E_U[k(g−C)]. Thus (8) is an earned improvement, not an added old capture-square credit. The exact refill cost remains βg. Under (1), also

\[
 G_{\rm priority}\le\xi G_{\rm joint}
 +(1-\xi)\int_Ed_vE_{P_v}(\beta_vg_v)\,dv. \tag{10}
\]

For each original receiver pair, floor≤min(p,1−d_v) and good transport≤min(d_v,2d_vp). Therefore their sum is at most min(1,3p−2p²), hence at most 3p. R370's actual-overlap selector theorem pays the same 3Γ_n|E|/h, with the same frozen h and source fee as R374/R375. The original positive decomposition is rebuilt as floor+new good+G_priority. It is a replacement receipt; no floor or mark fee is added again.

Explicitly, in the matched hard slot with ν≤f,

\[
 B_H\le G_{\rm priority}
 +\epsilon_0\left[2+\frac{C_n^++3\Gamma_n}{1+\sqrt n}\right]X_q
 +\frac\lambda{q_-}\left[\frac{2+3\sqrt n+2e^{-\sqrt n}}{\epsilon_0}
                         +1+\sqrt n\right]W, \tag{11}
\]

where C_n^+<72, W=||f||_1, X_q=∫_E q_u du. The original entrance, hard-slot multiplier and outer multiplier remain unchanged. This construction may be compared with R375's row-optimal cap-two plan by choosing the entire plan per v with a finite measurable tie rule; rowwise mixing between the two plans is not licensed by the aggregate target cap.

## 5. Explicit same-price improvement over fixed-level proportional retention

The R375 shared-box cap-two plan retains k_1^prop=ρ^0min(1,1/H), with the factor taken as one at H=0. Its retained column mass is min(H,1). Denote its exact gain by R_prop (integrated with d_v dv as in (8)). Benefit nonnegativity is essential here: because a≥1, this old retained submeasure can be extended up to h_z without reducing reward. Priority optimality then proves R≥R_prop.

There is a stronger exact decomposition. Set

\[
 \mathcal S_1=\int_Ed_v\,dv\int U_v(dz)
 \left[\int_0^B\min\{1,T_{v,z}(s)\}ds
       -\int b_v(y,z)k_{1,v}^{prop}(y,z)P_v(dy)\right]\ge0,
\]

and

\[
 \mathcal S_{\rm water}=\int_Ed_v\,dv\int U_v(dz)\int_0^B
 \min\{a_v-1,(T_{v,z}(s)-1)_+\}\,ds\ge0.
\]

Then

\[
 \boxed{\mathcal R-R_{\rm prop}=\mathcal S_1+\mathcal S_{\rm water}.} \tag{12}
\]

The first term is priority ordering at the old level, the second uses the unused cap-two capacity after exact refill accounting. For example a positive d_vdvU_vdzds-measure set with T_{v,z}(s)>1 gives a strictly positive water gain (a_v>1 always). These are directly evaluable gains at identical template price. They do not provide a uniform lower fraction of the original joint remainder. In particular proposal congestion may involve zero-g rows, and no positivity is inferred merely from H>1.

No general root bound on (9), no free repeat of the construction, and no optimality over all aggregate-cap plans beyond the specified fixed-proposal/refill class is proved. The unresolved source geometry is a quantitative bound on the surviving weighted refill/retained cost, or an adequate lower bound for (8), from the actual matching constraints.

## 6. Three-stage exact local verification

The embedded standard-library script checks (i) water-level boundary and atom identities, (ii) full positive plans, threshold atoms, both marginals, exact reward and comparator credits, and (iii) an enlarged finite atomic family including nonzero proposal losses. Finite input kernels are algebraic checks, not realizations of the native high-past hard field. All counts below are actual grouped assertions, not counts of optimizations or proofs of the remaining global estimate.

```python
from fractions import Fraction as F
from itertools import product
counts = [0,0,0]
strict = [0,0,0]
feasible_competitors = [0,0,0]

def water(U,H):
    cuts=sorted(set([F(1),F(2)]+[x for x in H if 1<x<2]))
    for lo,hi in zip(cuts,cuts[1:]):
        low=sum(w for w,x in zip(U,H) if x<=lo)
        high=sum(w*x for w,x in zip(U,H) if x>lo)
        if low:
            a=(2-high)/low
            if lo<=a<=hi:
                return a
    if sum(w*max(x,F(2)) for w,x in zip(U,H))==2:
        return F(2)
    raise AssertionError('water root missing')

def retention(P,rho,benefit,a):
    H=sum(p*x for p,x in zip(P,rho))
    left=min(H,a)
    k=[F(0)]*len(P)
    for b in sorted(set(benefit),reverse=True):
        ids=[i for i,x in enumerate(benefit) if x==b]
        mass=sum(P[i]*rho[i] for i in ids)
        factor=min(F(1),left/mass) if mass else F(0)
        for i in ids:k[i]=rho[i]*factor
        left-=mass*factor
    assert left==0
    return k

def reward_tail(P,rho,benefit,a):
    cuts=sorted(set([F(0),F(1)]+[b for x,b in zip(rho,benefit) if x>0]))
    return sum((hi-lo)*min(a,sum(p*x for p,x,b in zip(P,rho,benefit) if b>lo))
               for lo,hi in zip(cuts,cuts[1:]))

def vertex_best(P,rho,benefit,target):
    vals=[]
    for free in range(len(P)):
        ids=[i for i in range(len(P)) if i!=free]
        for bits in product((0,1),repeat=len(ids)):
            k=[F(0)]*len(P)
            for i,bit in zip(ids,bits):k[i]=rho[i]*bit
            k[free]=(target-sum(P[i]*k[i] for i in ids))/P[free]
            if 0<=k[free]<=rho[free]:
                vals.append(sum(p*x*b for p,x,b in zip(P,k,benefit)))
    return max(vals)

U=[F(1,6),F(1,3),F(1,2)]
for raw in product(range(5),repeat=3):
    avg=sum(w*x for w,x in zip(U,raw))
    if not avg:continue
    H=[F(x)/avg for x in raw]
    a=water(U,H)
    delta=sum(w*max(x-a,F(0)) for w,x in zip(U,H))
    assert 1<a<=2 and a+delta==2
    assert sum(w*min(x,a) for w,x in zip(U,H))==1-delta
    counts[0]+=2


def check_plan(P,U,K,phase):
    nr,nc=len(P),len(U)
    L=[max(row) for row in K]
    r=[sum(w*x for w,x in zip(U,row)) for row in K]
    g=[x-y for x,y in zip(L,r)]
    C=[[L[i]-K[i][j] for j in range(nc)] for i in range(nr)]
    b=[[K[i][j]-r[i] for j in range(nc)] for i in range(nr)]
    rho=[]
    for i in range(nr):
        eligible=[C[i][j]<=g[i]/2 for j in range(nc)]
        mass=sum(U[j] for j in range(nc) if eligible[j])
        rho.append([F(int(e))/mass for e in eligible])
    H=[sum(P[i]*rho[i][j] for i in range(nr)) for j in range(nc)]
    a=water(U,H)
    delta=2-a
    k=[[F(0)]*nc for _ in range(nr)]
    gain=oldgain=tail1=F(0)
    for j in range(nc):
        rr=[rho[i][j] for i in range(nr)]
        bb=[b[i][j] for i in range(nr)]
        kk=retention(P,rr,bb,a)
        assert all(0<=x<=y for x,y in zip(kk,rr))
        assert sum(p*x for p,x in zip(P,kk))==min(H[j],a)
        rew=sum(p*x*z for p,x,z in zip(P,kk,bb))
        assert rew==reward_tail(P,rr,bb,a)
        assert rew==vertex_best(P,rr,bb,min(H[j],a))
        for i in range(nr):k[i][j]=kk[i]
        gain+=U[j]*rew
        oldgain+=U[j]*sum(P[i]*rho[i][j]*min(F(1),1/H[j])*b[i][j]
                          for i in range(nr)) if H[j] else F(0)
        tail1+=U[j]*reward_tail(P,rr,bb,F(1))
        counts[phase]+=4
    beta=[1-sum(U[j]*k[i][j] for j in range(nc)) for i in range(nr)]
    plan=[[k[i][j]+beta[i] for j in range(nc)] for i in range(nr)]
    assert all(0<=x<=1 for x in beta)
    assert all(sum(U[j]*plan[i][j] for j in range(nc))==1 for i in range(nr))
    assert sum(p*x for p,x in zip(P,beta))==delta
    assert all(sum(P[i]*plan[i][j] for i in range(nr))==min(H[j],a)+delta<=2
               for j in range(nc))
    G=sum(p*x for p,x in zip(P,g))
    bad=sum(P[i]*U[j]*plan[i][j]*C[i][j] for i in range(nr) for j in range(nc))
    assert bad==G-gain>=0
    assert bad<=G/2+sum(P[i]*beta[i]*g[i] for i in range(nr))/2
    assert gain>=tail1>=oldgain
    sw=F(0)
    for j in range(nc):
        cuts=sorted(set([F(0),F(1)]+[b[i][j] for i in range(nr) if rho[i][j]>0]))
        for lo,hi in zip(cuts,cuts[1:]):
            T=sum(P[i]*rho[i][j] for i in range(nr) if b[i][j]>lo)
            sw+=U[j]*(hi-lo)*min(a-1,max(T-1,F(0)))
    assert gain-tail1==sw
    counts[phase]+=8
    if gain>oldgain:strict[phase]+=1
    # Arbitrary proposal subflows with their own total/refill, not fixed a.
    patterns = product((F(0),F(1,2),F(1)),repeat=nr*nc) if phase==1 else (
        tuple(F((seed+2*i+3*j)%5,4) for i in range(nr) for j in range(nc))
        for seed in range(5))
    for pattern in patterns:
        kk=[[rho[i][j]*pattern[i*nc+j] for j in range(nc)] for i in range(nr)]
        R=[sum(P[i]*kk[i][j] for i in range(nr)) for j in range(nc)]
        total=sum(U[j]*R[j] for j in range(nc))
        if all(x+1-total<=2 for x in R):
            rew=sum(P[i]*U[j]*kk[i][j]*b[i][j] for i in range(nr) for j in range(nc))
            assert 1+total<=a and all(x<=a for x in R)
            assert rew<=gain
            feasible_competitors[phase]+=1
            counts[phase]+=2

P=[F(1,3),F(2,3)]
for raw in list(product((F(0),F(1,2),F(1)),repeat=6))[:36]:
    check_plan(P,U,[list(raw[:3]),list(raw[3:])],1)
for raw in product((F(0),F(1,2),F(1)),repeat=6):
    check_plan(P,U,[list(raw[:3]),list(raw[3:])],2)
P3=[F(1,6),F(1,3),F(1,2)]
U4=[F(1,10),F(1,5),F(3,10),F(2,5)]
for seed in range(97):
    K=[[F((seed*(i+1)+j*j+3*i*j+2*i)%9,8) for j in range(4)] for i in range(3)]
    check_plan(P3,U4,K,2)
print('PASS stage counts',counts,'total',sum(counts),'strict plan improvements',strict,
      'feasible subflow competitors',feasible_competitors)
```

Actual local execution of the exact embedded script: **PASS stage counts [248, 44352, 23216], total 67816 grouped assertions; strict plan improvements [0, 33, 802]; feasible subflow competitors [0, 21816, 3154].** Stage 1 includes all 124 nonzero three-cell water profiles specified in the code; stage 2 uses the first 36 two-by-three profiles and exhaustive three-level subflows; stage 3 uses all 729 such profiles plus 97 three-by-four profiles, with five subflow probes each. The earlier smaller run passed 17876 grouped assertions before the whole-class competitor checks were added; only the final embedded range supports the final count. These finite computations certify no missing native global geometry.
