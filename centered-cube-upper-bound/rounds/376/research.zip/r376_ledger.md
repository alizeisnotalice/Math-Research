# R376 完整账：原时钟对数包络与共享优先计划

冻结 R375 同一完整 f、真实 Lebesgue 接收集 E、原半径/边长选择器、m/q、原J、strictpast、far/outside/notBplus门及包含末端原子的物理时钟。所有原质量与标记由完整输入定义；没有重选来源或把旧标记转给新目标。

## 原核新包络不另收模板费

geometry证明
\[
0\le K_v(y,z)\le L_v(y)\le b_h(y)
:=\min\{A_n/h,\lambda\log_+(J_b(y)/h)\}
\le B_*:=\min\{A_n/h,\lambda\log_+(A_n/(q_-h))\}.
\]
log_+在J_b=0时取0。B_*=0时所有原kernel和剩余均为0，不作除零归一化。此为同一原核的上界，不新增扣减、不重用捕获平方。R375按真实M=max(r,L−r)的局部归一化本就满足M≤L≤b_h；不能将替换旧粗B再虚记为超过该M计划的新收益。

## 共享优先计划及真实剩余

采用R375可数近捕获盒，或任何满足proposal-supported C≤ξg的实际可测proposal，g=L−E_UK。priority给出水位a_v∈(1,2]、逐目标优先保留子流k以及源行失量β=1−E_Uk。完整目标密度min(H,a)+2−a≤2，来源μ_v^+原样保持。
\[
G_{priority}=G_{joint}-\mathcal R\ge0,\qquad
\mathcal R=\int_Ed_v\,dv\int U_v(dz)\int_0^{B}\min(a_v,T_{v,z}(s))ds,
\]
\[
G_{priority}\le\xi G_{joint}+(1-\xi)\int_Ed_v E_{P_v}(\beta_v g_v)dv.
\]
补流真实费用βg保留；其源依赖包络是βb_h(y)，进一步可用B_*∫d_vE_Pβdv。后两者只是上界，均未获根阶付款。ξ变小会改变实际盒、拥挤及β，不允许把β固定后免费令ξ→0。

可在每个v对priority与R375 row-optimal等有限合法cap2计划按完整费用择优，仍保持cap2。不能逐y混选。priority仅在固定proposal子流加均匀补流类中最优，并非所有cap2计划最优。

## 原始入口与全部价格

新floor+good仍≤min(1,3p−2p²)≤3p，故完整硬槽用新的真实剩余替换旧剩余：
\[
B_H(f,\nu)\le G_{priority}+\varepsilon_0[2+(C_n^++3\Gamma_n)/(1+\sqrt n)]X_q+C_{338}W,
\]
\[
C_{338}=\frac\lambda{q_-}\{(2+3\sqrt n+2e^{-\sqrt n})/\varepsilon_0+1+\sqrt n\},\quad C_n^+<72,
\]
\[
\Gamma_n=1+\frac{n}{4(\sqrt n+1)}+2\sqrt n\sqrt{1/4+\tfrac12\log(1+\sqrt n)}(1-1/\sqrt2),
\quad A_n=1+n\log(b/a),\quad q_-=3\lambda/4.
\]
给定本槽η，仍用原
\[
\mathcal L_n=2+(72+3\Gamma_n)/(1+\sqrt n),\quad
\varepsilon_0=\eta/\mathcal L_n,\quad h=(1+\sqrt n)\mathcal L_n/(\eta q_-).
\]
参数及门全部同步。来源费仍O_η(√(n log(n+2)))W。本轮不引入新的t倍费用。完整入口为
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H+2G_{priority}
+2\varepsilon_0[2+(C_n^++3\Gamma_n)/(1+\sqrt n)]X_q+2C_{338}W.
\]
整式乘Λ=128/119；新earned gain只扣2ΛR一次。该硬槽系数≤2Λη，未认证所有槽总和可吸收。

仍未支付：来源加权拥挤/余项Gpriority的一般根阶预算；原入口与soft/crossing接口；合同外重尾、宽距离/低pe/极端尺度比和阈值补集；历史初始/删除跳跃/未来被删来源；H选择、全尺度及来源聚合、外积分、截断与极限。物理末端原子不代替历史原子。有限诊断的类内最优不关闭任何这些槽。
