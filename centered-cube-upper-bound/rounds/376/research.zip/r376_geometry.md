# R376 — A logarithmic bound from the original clock and strict left prefix

## 1. New unconditional bound, with the original marks retained

Notation: b_h(y) below is an upper envelope, distinct from the priority note's actual row loss g_v(y)=L_v(y)−r_v(y).

Keep the frozen full-f contract, actual finite-measure Lebesgue receiver set E, a≤R_u≤b≤2a,
m_u=q_uR_u^n, q_-≤q_u≤λ, μ(du)=du/m_u, original physical clock
\[
 \ell=b^{-n}\delta_b+nr^{-n-1}1_{(a,b)}dr,
\]
and K=e^{√n}>λ/q_-. Write
\[
 J_y(R)=\int_{R_w\le R}c_w(y)\mu(dw),\qquad
 J_y(R-)=\int_{R_w<R}c_w(y)\mu(dw).
\]
The actual mass past is Z_y(m_u/K-), not a radius past substituted by definition. As before,
\[
 \omega_u(y)=hR_u^n\int_{[R_u,b]}\ell(dr)
 \frac{1_{J_y(r)\ge H}1_{Z_y(m_u/K-)>h}}{J_y(r)},
\quad
 L_v(y)=\frac1h\int_E\frac{du}{R_u^n}
 A_{uv}\omega_u(y)c_u(y).
\]
Every old pair mask and sourcewise gate remains in A and ω.

The new bound is
\[
 \boxed{0\le K_v(y,z)\le L_v(y)
 \le b_0(y)\le\lambda\log_+\!\frac{J_b(y)}h,} \tag{1}
\]
where the more precise actual-source bound is
\[
 b_0(y)=\int_E\frac{q_u c_u(y)}{J_y(R_u)}
     1_{\{J_y(R_u-)>h\}}\,\mu(du). \tag{2}
\]
A quotient with zero denominator is set to zero; on the retained indicator its denominator is strictly larger than h>0.

In particular set A_n=1+n log(b/a), B=A_n/h and
\[
 \boxed{b_h(y)=\min\left\{B,\lambda\log_+\frac{J_b(y)}h\right\}.} \tag{3}
\]
Then K≤L≤b_h. One may use the still sharper min(B,b_0(y)). The bound is genuinely source dependent and must remain inside any source-weighted integral.

## 2. Why strict mass past gives a strict LEFT radius prefix

If m_w<m_u/K, then
\[
 R_w^n=\frac{m_w}{q_w}
 <\frac{m_u}{Kq_-}
 \le\frac{\lambda}{Kq_-}R_u^n<R_u^n.
\]
Therefore every actual strict mass-past receiver has R_w<R_u, and
\[
 Z_y(m_u/K-)>h\quad\Longrightarrow\quad J_y(R_u-)>h. \tag{4}
\]
In particular no part of an atom at R_u is used to justify the left-prefix threshold. This is the reason no separate “first jump” term is needed.

Use monotonicity J_y(r)≥J_y(R_u) for r≥R_u, positive Tonelli, and the inclusive physical tail
\[
 \int_{[R_u,b]}\ell(dr)=R_u^{-n}.
\]
After cancelling the normalizations exactly,
\[
\begin{aligned}
 L_v(y)
 &=\int_E A_{uv}c_u(y)\,du
   \int_{[R_u,b]}\ell(dr)
   \frac{1_{J_y(r)\ge H}1_{Z_y(m_u/K-)>h}}{J_y(r)}\\
 &\le\int_E\frac{c_u(y)}{R_u^nJ_y(R_u)}
               1_{\{J_y(R_u-)>h\}}\,du=b_0(y).
\end{aligned} \tag{5}
\]
This is where the original reciprocal J is used. Replacing ω≤1 before this step would lose the logarithmic bound. The H indicator is only removed by positive domination; no claim is made that it is independent of y.

## 3. Stieltjes logarithm: atoms, singular parts and zero values

For any finite positive measure η on [a,b], put
F(R)=η([a,R]), F(R-)=η([a,R)), T=F(b). For h>0,
\[
 \boxed{\int\frac{1_{\{F(R-)>h\}}}{F(R)}\,\eta(dR)
 \le\log_+(T/h).} \tag{6}
\]
If T≤h the integrand is zero. Otherwise use the generalized inverse
Q(s)=inf{R:F(R)≥s}, 0<s<T. Lebesgue measure ds pushed by Q is η. For almost every s,
\[
 F(Q(s)-)\le s\le F(Q(s)).
\]
If the retained indicator F(Q(s)-)>h holds, then s>h and
1/F(Q(s))≤1/s. Thus the left side of (6) is at most ∫_h^T ds/s. This argument includes absolutely continuous, continuous singular and atomic measures; it requires no derivative of F.

For an atom its contribution is exactly
\[
 \frac{\Delta F}{F_{\rm right}}\,
 1_{\{F_{\rm left}>h\}}
 \le\log(F_{\rm right}/F_{\rm left})\,
 1_{\{F_{\rm left}>h\}}.
\]
The first atom crossing h is excluded unless its LEFT value already exceeds h. There is no undefined division at F=0, and the atom at b is treated in the same way. The physical-clock atom was independently retained in (5).

Apply (6) to the actual pushforward
η_y(dR)=∫E c_u(y)μ(du)δ_{R_u}(dR), and use q_u≤λ in (2). This proves (1).

## 4. The actual-center envelope and a uniform logarithmic bound

The arbitrary actual selector still obeys
\[
 J_b(y)\le\frac1{q_-}
 \int_{\mathbb R^n}
 \sup_{a\le R\le b}\frac{1_{\{2\|u-y\|_\infty\le R\}}}{R^n}\,du
 =\frac{1+n\log(b/a)}{q_-}. \tag{7}
\]
For ρ=2||u−y||∞, the supremum is a^{-n} on ρ≤a, ρ^{-n} on a<ρ≤b, and zero beyond b. Since |{ρ≤r}|=r^n, its integral is 1+n∫_a^b dr/r. This is domination of a real center integral; it does not integrate the selector radius as an independent variable.

Consequently
\[
 L_v(y)\le B_{\log}:=
 \lambda\log_+\frac{A_n}{q_-h}. \tag{8}
\]
If A_n/(q_-h)≤1, the original high-past remainder is zero. With the original
h=(1+√n)/(ε_0q_-), the bound is
λ log_+[ε_0 A_n/(1+√n)], at most logarithmic in n for fixed ε_0 and the octave ratio.

The sourcewise bound (3) is preferred for congestion. A uniform min(B,B_log) is valid only when a truly source-independent bound is required. No formula involving a double-centered coupling may silently replace its scalar normalizer by b_h(y).

## 5. Correct consequences for common plans and refill costs

For the R375 shared-box plan, retain its exact notation β_v(y) for the lost row mass and r_v(y)=E_U K_v(y,·). Its TRUE refill cost is
\[
 D_\xi=\int_E dv\,d_vE_{P_v}
       [\beta_v(y)(L_v(y)-r_v(y))].
\]
The new unconditional estimate is
\[
 \boxed{D_\xi\le
 \int_E dv\,d_vE_{P_v}[\beta_v(y)b_h(y)]} \tag{9}
\]
(and likewise with min(B,b_0)). The complete certified-box bound retains its already certified tight cost:
\[
 \operatorname{Bad}(\tau^\Box)
 \le\int_E dv\,d_vE_P[
    s_v(y)(1-\beta_v(y))+
    \beta_v(y)\min\{L_v(y)-r_v(y),b_h(y)\}]. \tag{10}
\]
Since L−r≤b_h, the minimum equals L−r: (10) gives no additional gain over the existing exact refill cost. The new receipt is an explicit original-clock envelope for that cost. In a coarser bound, replace the former B times lost mass by the actual integral (9); do not replace it by an unweighted spatial average.

A lawful row-normalized alternative is also explicit. On b_h(y)>0 put
\[
 \tau_v^{b_h}=d_v\left[1+\frac{K_v(y,z)-r_v(y)}{b_h(y)}\right]
          P_v(dy)U_v(dz).
\]
On b_h=0 use product density, since K=L=r=0 there. Every row factor lies in [0,2], its row mean is one, and hence the source is exactly μ_v^+ and target≤2d_vU_v. The exact captured reward gain is
\[
 \Delta_{b_h}=\int_E dv\,d_vE_{P_v}
 \left[\frac{\operatorname{Var}_{U_v}K_v(y,\cdot)}{b_h(y)}\right], \tag{11}
\]
with zero contribution where b_h=0. It is at least the R374 B-normalized row gain. This row construction is legitimate precisely because its centering is conditional on y. It does not assert the old double-centering identities with a variable denominator. In fact R375 already permits the true row normalizer M_v(y)=max{r_v(y),L_v(y)−r_v(y)}. Since M_v≤L_v≤b_h, its corresponding variance gain is at least (11). Thus (11) is an admissibility illustration for a source-dependent envelope, not an additional credit or an improvement over that plan; a row-optimal cap-2 plan also need not be improved.

All cap-2 candidates retain the SAME joint 3Γ_n template fee and source fee:
\[
 B_H(f,\nu)\le\operatorname{Bad}(\tau)+
 \varepsilon_0\left[2+\frac{C_n^++3\Gamma_n}{1+\sqrt n}\right]X_q
 +C_{338}W.
\]
Use only the actual bad cost of the selected complete v-plan, not several credits added together. The original h, H, entrance terms and outer Λ remain; changing ε_0 requires rebuilding h-dependent data and C338 as usual.

## 6. Precise remaining integral

Equations (1) and (9) are new unconditional bounds using the actual clock, high past and q matching. They do not establish the requested final root budget. The remaining requirement is an estimate, for a suitable common plan, of its small-box loss plus
\[
 \int_E dv\,d_vE_{P_v}
 \left[\beta_v(y)\min\!\left\{\frac{A_n}{h},
                    \lambda\log_+\frac{J_b(y)}h\right\}\right], \tag{12}
\]
or of the smaller exact Dξ. Reversibility, separate row capacity and f(Q_u)=m_u do not by themselves bound this joint source/receiver integral. No claim is made that the logarithmic factor can be pulled out to leave a known root-cost lost mass. No new source-density cap, reused capture square or omitted physical atom is involved.

## 7. Three-stage exact/rigorous local checks

The saved code below uses rational arithmetic throughout. Logarithms are certified by lower/upper rational sums of
log r=2Σ_{k≥0}x^{2k+1}/(2k+1), x=(r−1)/(r+1), with a geometric remainder bound. It checks the Stieltjes inequality on finite atomic measures, then the complete physical-clock algebra with radius ties, strict mass past and varying q, and finally finite atomic approximations to a Cantor distribution. The latter checks do not replace the proof for singular-continuous measures in §3.

These are algebra/interval certificates, not extra native hard-field examples. The finite clock diagnostics preserve m=qR^n and all displayed finite-prefix gates but are not claimed to realize the original receiver Lebesgue geometry.

~~~python
from fractions import Fraction as F
from itertools import product

checks={'atomic_log':0,'clock_bound':0,'strict_left':0,'cantor_log':0}
def harmonic(weights,h):
    pref=F(0);val=F(0)
    for w in weights:
        right=pref+w
        if pref>h:
            val+=w/right
        pref=right
    return val,pref

def certify_log_bound(value,total,h):
    if total<=h:
        assert value==0
        return
    r=total/h;x=(r-1)/(r+1)
    lo=F(0);xp=x
    for k in range(4096):
        lo+=2*xp/F(2*k+1)
        xp*=x*x
        hi=lo+2*xp/(F(2*k+3)*(1-x*x))
        assert lo<=hi
        if value<=lo:
            return
    raise AssertionError('rational log enclosure did not separate')

for length in range(1,7):
 for pattern in range(5):
  weights=[F(1+(j*3+pattern)%7,1+(j+pattern)%4) for j in range(length)]
  total=sum(weights)
  for ratio in (F(1,2),F(1),F(2),F(4),F(8)):
   h=total/ratio
   val,total2=harmonic(weights,h)
   assert total2==total
   certify_log_bound(val,total,h);checks['atomic_log']+=1

for n in (1,3,6):
 for pattern in range(4):
  radii=[F(1),F(1),F(5,4),F(3,2),F(3,2),F(2)]
  qs=[(F(3,4),F(7,8),F(1))[(j+pattern)%3] for j in range(6)]
  du=[F(1+(2*j+pattern)%5,7) for j in range(6)]
  cap=[F(int((j+pattern)%4!=0)) for j in range(6)]
  m=[qs[j]*radii[j]**n for j in range(6)]
  mu=[du[j]/m[j] for j in range(6)]
  lev=sorted(set(radii));kappa=F(3)
  J=[sum(mu[j]*cap[j] for j in range(6) if radii[j]<=r) for r in lev]
  left=[sum(mu[j]*cap[j] for j in range(6) if radii[j]<r) for r in lev]
  atom=[J[k]-left[k] for k in range(len(lev))]
  ell=[r**(-n)-(lev[k+1]**(-n) if k+1<len(lev) else F(0))
       for k,r in enumerate(lev)]
  total=J[-1]
  for ratio in (F(1,2),F(1),F(2),F(4),F(8)):
   h=total/ratio
   past=[sum(mu[j]*cap[j] for j in range(6) if m[j]<m[u]/kappa)
         for u in range(6)]
   I=sum(atom[k]/J[k] for k in range(len(lev)) if left[k]>h)
   raw=sum(qs[u]*mu[u]*cap[u]/J[lev.index(radii[u])]
           for u in range(6) if left[lev.index(radii[u])]>h)
   assert raw<=I
   certify_log_bound(I,total,h)
   for u in range(6):
    if past[u]>h:
     assert left[lev.index(radii[u])]>h
    checks['strict_left']+=1
   for H in (F(0),h,2*h):
    for v in range(6):
     Lv=F(0)
     for u in range(6):
      A=(1-m[v]/m[u]) if m[u]>kappa*m[v] else F(0)
      if not A or past[u]<=h:continue
      clock=sum(ell[k]/J[k] for k,r in enumerate(lev)
                if r>=radii[u] and J[k]>=H and J[k]>0)
      Lv+=du[u]*cap[u]*A*clock
     assert 0<=Lv<=raw<=I
     checks['clock_bound']+=1

for depth in range(1,10):
    # Equal masses at the usual finite Cantor locations; rank algebra
    # depends on masses while the measure's support approaches the Cantor set.
    pts=[sum(F(2*bit,3**(j+1)) for j,bit in enumerate(bits))
         for bits in product((0,1),repeat=depth)]
    assert len(set(pts))==2**depth
    weights=[F(1,2**depth)]*len(pts)
    for h in (F(1,8),F(1,4),F(1,2),F(1)):
        val,total=harmonic(weights,h)
        certify_log_bound(val,total,h)
        checks['cantor_log']+=1
print('PASS',checks,'total',sum(checks.values()))
~~~

Actual execution record (2026-10-18): the embedded code was executed locally and returned

`PASS {'atomic_log': 150, 'clock_bound': 1080, 'strict_left': 360, 'cantor_log': 36} total 1626`

No floating-point estimate is used in these certificates. The main receipt remains the analytic original-clock logarithmic envelope, not a new total root-budget closure.
