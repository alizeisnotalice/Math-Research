from fractions import Fraction as F
from itertools import product

checks={'atomic_log':0,'clock_bound':0,'strict_left':0,'cantor_log':0}
def harmonic(weights,h):
    pref=F(0);val=F(0)
    for w in weights:
        right=pref+w
        if pref>h:
            val+=w/right
        pref=right
    return val,pref

def certify_log_bound(value,total,h):
    if total<=h:
        assert value==0
        return
    r=total/h;x=(r-1)/(r+1)
    lo=F(0);xp=x
    for k in range(4096):
        lo+=2*xp/F(2*k+1)
        xp*=x*x
        hi=lo+2*xp/(F(2*k+3)*(1-x*x))
        assert lo<=hi
        if value<=lo:
            return
    raise AssertionError('rational log enclosure did not separate')

for length in range(1,7):
 for pattern in range(5):
  weights=[F(1+(j*3+pattern)%7,1+(j+pattern)%4) for j in range(length)]
  total=sum(weights)
  for ratio in (F(1,2),F(1),F(2),F(4),F(8)):
   h=total/ratio
   val,total2=harmonic(weights,h)
   assert total2==total
   certify_log_bound(val,total,h);checks['atomic_log']+=1

for n in (1,3,6):
 for pattern in range(4):
  radii=[F(1),F(1),F(5,4),F(3,2),F(3,2),F(2)]
  qs=[(F(3,4),F(7,8),F(1))[(j+pattern)%3] for j in range(6)]
  du=[F(1+(2*j+pattern)%5,7) for j in range(6)]
  cap=[F(int((j+pattern)%4!=0)) for j in range(6)]
  m=[qs[j]*radii[j]**n for j in range(6)]
  mu=[du[j]/m[j] for j in range(6)]
  lev=sorted(set(radii));kappa=F(3)
  J=[sum(mu[j]*cap[j] for j in range(6) if radii[j]<=r) for r in lev]
  left=[sum(mu[j]*cap[j] for j in range(6) if radii[j]<r) for r in lev]
  atom=[J[k]-left[k] for k in range(len(lev))]
  ell=[r**(-n)-(lev[k+1]**(-n) if k+1<len(lev) else F(0))
       for k,r in enumerate(lev)]
  total=J[-1]
  for ratio in (F(1,2),F(1),F(2),F(4),F(8)):
   h=total/ratio
   past=[sum(mu[j]*cap[j] for j in range(6) if m[j]<m[u]/kappa)
         for u in range(6)]
   I=sum(atom[k]/J[k] for k in range(len(lev)) if left[k]>h)
   raw=sum(qs[u]*mu[u]*cap[u]/J[lev.index(radii[u])]
           for u in range(6) if left[lev.index(radii[u])]>h)
   assert raw<=I
   certify_log_bound(I,total,h)
   for u in range(6):
    if past[u]>h:
     assert left[lev.index(radii[u])]>h
    checks['strict_left']+=1
   for H in (F(0),h,2*h):
    for v in range(6):
     Lv=F(0)
     for u in range(6):
      A=(1-m[v]/m[u]) if m[u]>kappa*m[v] else F(0)
      if not A or past[u]<=h:continue
      clock=sum(ell[k]/J[k] for k,r in enumerate(lev)
                if r>=radii[u] and J[k]>=H and J[k]>0)
      Lv+=du[u]*cap[u]*A*clock
     assert 0<=Lv<=raw<=I
     checks['clock_bound']+=1

for depth in range(1,10):
    # Equal masses at the usual finite Cantor locations; rank algebra
    # depends on masses while the measure's support approaches the Cantor set.
    pts=[sum(F(2*bit,3**(j+1)) for j,bit in enumerate(bits))
         for bits in product((0,1),repeat=depth)]
    assert len(set(pts))==2**depth
    weights=[F(1,2**depth)]*len(pts)
    for h in (F(1,8),F(1,4),F(1,2),F(1)):
        val,total=harmonic(weights,h)
        certify_log_bound(val,total,h)
        checks['cantor_log']+=1
print('PASS',checks,'total',sum(checks.values()))
