from fractions import Fraction as F
from itertools import product
counts = [0,0,0]
strict = [0,0,0]
feasible_competitors = [0,0,0]

def water(U,H):
    cuts=sorted(set([F(1),F(2)]+[x for x in H if 1<x<2]))
    for lo,hi in zip(cuts,cuts[1:]):
        low=sum(w for w,x in zip(U,H) if x<=lo)
        high=sum(w*x for w,x in zip(U,H) if x>lo)
        if low:
            a=(2-high)/low
            if lo<=a<=hi:
                return a
    if sum(w*max(x,F(2)) for w,x in zip(U,H))==2:
        return F(2)
    raise AssertionError('water root missing')

def retention(P,rho,benefit,a):
    H=sum(p*x for p,x in zip(P,rho))
    left=min(H,a)
    k=[F(0)]*len(P)
    for b in sorted(set(benefit),reverse=True):
        ids=[i for i,x in enumerate(benefit) if x==b]
        mass=sum(P[i]*rho[i] for i in ids)
        factor=min(F(1),left/mass) if mass else F(0)
        for i in ids:k[i]=rho[i]*factor
        left-=mass*factor
    assert left==0
    return k

def reward_tail(P,rho,benefit,a):
    cuts=sorted(set([F(0),F(1)]+[b for x,b in zip(rho,benefit) if x>0]))
    return sum((hi-lo)*min(a,sum(p*x for p,x,b in zip(P,rho,benefit) if b>lo))
               for lo,hi in zip(cuts,cuts[1:]))

def vertex_best(P,rho,benefit,target):
    vals=[]
    for free in range(len(P)):
        ids=[i for i in range(len(P)) if i!=free]
        for bits in product((0,1),repeat=len(ids)):
            k=[F(0)]*len(P)
            for i,bit in zip(ids,bits):k[i]=rho[i]*bit
            k[free]=(target-sum(P[i]*k[i] for i in ids))/P[free]
            if 0<=k[free]<=rho[free]:
                vals.append(sum(p*x*b for p,x,b in zip(P,k,benefit)))
    return max(vals)

U=[F(1,6),F(1,3),F(1,2)]
for raw in product(range(5),repeat=3):
    avg=sum(w*x for w,x in zip(U,raw))
    if not avg:continue
    H=[F(x)/avg for x in raw]
    a=water(U,H)
    delta=sum(w*max(x-a,F(0)) for w,x in zip(U,H))
    assert 1<a<=2 and a+delta==2
    assert sum(w*min(x,a) for w,x in zip(U,H))==1-delta
    counts[0]+=2


def check_plan(P,U,K,phase):
    nr,nc=len(P),len(U)
    L=[max(row) for row in K]
    r=[sum(w*x for w,x in zip(U,row)) for row in K]
    g=[x-y for x,y in zip(L,r)]
    C=[[L[i]-K[i][j] for j in range(nc)] for i in range(nr)]
    b=[[K[i][j]-r[i] for j in range(nc)] for i in range(nr)]
    rho=[]
    for i in range(nr):
        eligible=[C[i][j]<=g[i]/2 for j in range(nc)]
        mass=sum(U[j] for j in range(nc) if eligible[j])
        rho.append([F(int(e))/mass for e in eligible])
    H=[sum(P[i]*rho[i][j] for i in range(nr)) for j in range(nc)]
    a=water(U,H)
    delta=2-a
    k=[[F(0)]*nc for _ in range(nr)]
    gain=oldgain=tail1=F(0)
    for j in range(nc):
        rr=[rho[i][j] for i in range(nr)]
        bb=[b[i][j] for i in range(nr)]
        kk=retention(P,rr,bb,a)
        assert all(0<=x<=y for x,y in zip(kk,rr))
        assert sum(p*x for p,x in zip(P,kk))==min(H[j],a)
        rew=sum(p*x*z for p,x,z in zip(P,kk,bb))
        assert rew==reward_tail(P,rr,bb,a)
        assert rew==vertex_best(P,rr,bb,min(H[j],a))
        for i in range(nr):k[i][j]=kk[i]
        gain+=U[j]*rew
        oldgain+=U[j]*sum(P[i]*rho[i][j]*min(F(1),1/H[j])*b[i][j]
                          for i in range(nr)) if H[j] else F(0)
        tail1+=U[j]*reward_tail(P,rr,bb,F(1))
        counts[phase]+=4
    beta=[1-sum(U[j]*k[i][j] for j in range(nc)) for i in range(nr)]
    plan=[[k[i][j]+beta[i] for j in range(nc)] for i in range(nr)]
    assert all(0<=x<=1 for x in beta)
    assert all(sum(U[j]*plan[i][j] for j in range(nc))==1 for i in range(nr))
    assert sum(p*x for p,x in zip(P,beta))==delta
    assert all(sum(P[i]*plan[i][j] for i in range(nr))==min(H[j],a)+delta<=2
               for j in range(nc))
    G=sum(p*x for p,x in zip(P,g))
    bad=sum(P[i]*U[j]*plan[i][j]*C[i][j] for i in range(nr) for j in range(nc))
    assert bad==G-gain>=0
    assert bad<=G/2+sum(P[i]*beta[i]*g[i] for i in range(nr))/2
    assert gain>=tail1>=oldgain
    sw=F(0)
    for j in range(nc):
        cuts=sorted(set([F(0),F(1)]+[b[i][j] for i in range(nr) if rho[i][j]>0]))
        for lo,hi in zip(cuts,cuts[1:]):
            T=sum(P[i]*rho[i][j] for i in range(nr) if b[i][j]>lo)
            sw+=U[j]*(hi-lo)*min(a-1,max(T-1,F(0)))
    assert gain-tail1==sw
    counts[phase]+=8
    if gain>oldgain:strict[phase]+=1
    # Arbitrary proposal subflows with their own total/refill, not fixed a.
    patterns = product((F(0),F(1,2),F(1)),repeat=nr*nc) if phase==1 else (
        tuple(F((seed+2*i+3*j)%5,4) for i in range(nr) for j in range(nc))
        for seed in range(5))
    for pattern in patterns:
        kk=[[rho[i][j]*pattern[i*nc+j] for j in range(nc)] for i in range(nr)]
        R=[sum(P[i]*kk[i][j] for i in range(nr)) for j in range(nc)]
        total=sum(U[j]*R[j] for j in range(nc))
        if all(x+1-total<=2 for x in R):
            rew=sum(P[i]*U[j]*kk[i][j]*b[i][j] for i in range(nr) for j in range(nc))
            assert 1+total<=a and all(x<=a for x in R)
            assert rew<=gain
            feasible_competitors[phase]+=1
            counts[phase]+=2

P=[F(1,3),F(2,3)]
for raw in list(product((F(0),F(1,2),F(1)),repeat=6))[:36]:
    check_plan(P,U,[list(raw[:3]),list(raw[3:])],1)
for raw in product((F(0),F(1,2),F(1)),repeat=6):
    check_plan(P,U,[list(raw[:3]),list(raw[3:])],2)
P3=[F(1,6),F(1,3),F(1,2)]
U4=[F(1,10),F(1,5),F(3,10),F(2,5)]
for seed in range(97):
    K=[[F((seed*(i+1)+j*j+3*i*j+2*i)%9,8) for j in range(4)] for i in range(3)]
    check_plan(P3,U4,K,2)
print('PASS stage counts',counts,'total',sum(counts),'strict plan improvements',strict,
      'feasible subflow competitors',feasible_competitors)
