# R376 independent audit — FINAL PASS

Status: FINAL PASS for the bounded claims and final bytes bound below. Owner scope: only this audit file; no author/repository edits. The independent screens below preceded the relevant author proofs; full author and final integration review are completed in the concluding sections. No general root-budget closure, arbitrary-cap2 optimum or uniform contraction is certified.

## Frozen hypotheses and the retained benefit

Keep the R375 full-f fields, original source-dependent marks, all-u aggregated K,L, original m/q/J/past and complete physical clock fixed. For each actual v with d_v>0, P=P_v and U=U_v are probability kernels. Let a jointly measurable proposal rho0>=0 satisfy integral_U rho0(y,z)=1 for P-almost every y. Set g(y)=L(y)-E_U K(y,.) and C(y,z)=L(y)-K(y,z). Assume b(y,z)=g(y)-C(y,z)>=0 on the proposal support, and b<=B. The near-box hypothesis C<=xi*g,0<xi<1, supplies this condition. Outside that support b can harmlessly be set0 for threshold construction. This nonnegative-benefit condition is essential for the simple full-mass greedy optimality comparison. The ultimate transported cost C itself remains nonnegative everywhere.

H(z)=E_P rho0(y,z) is jointly measurable, integral_U H=1 and is finite U-almost everywhere by positive Tonelli. Null infinite-H targets can be assigned harmless versions; they carry zero proposal joint mass. d_v=0 means every d-weighted plan/cost/credit contribution0, without asserting that the underlying K,L vanish.

## A single measurable water level and target capacity

For each v define F_v(a)=E_U max(H,a), a in[1,2]. This is finite, jointly measurable in(v,a), continuous and nondecreasing in a. F(1)=1+E(H-1)+<=2 and F(2)>=2. In fact F(1)<2 because E min(H,1)>0. F is strictly increasing on(1,2] (mean H=1 implies positive U mass below any a>1). Thus there is a unique measurable a_v in(1,2] satisfying F_v(a_v)=2. Rational level tests give its measurability directly; no general measurable optimizer theorem is needed.

Let l(z)=min(H(z),a). Then

E_U(H-a)+=2-a=:delta,
E_U l=1-delta=a-1.

Select, at each target z, source proposal mass exactly l(z), with the greatest b first. Write retained density k(y,z) relative to P U, with0<=k<=rho0 and E_P k=min(H,a). Define beta(y)=1-E_U k(y,z), so0<=beta<=1 and E_P beta=delta. The final density k(y,z)+beta(y) has each source row mass1, and exact target density

min(H(z),a)+delta <= a+(2-a)=2.

Consequently d_v[k+beta]P U is one source-preserving aggregate-cap2 common plan for this v. a is a single water level for the whole v-plan, not a privately chosen level for each target/large receiver.

## Targetwise quantiles, atoms and exact gain

If H<=a retain the whole proposal. If H>a, let nu_z(dy)=rho0(y,z)P(dy), a finite measure of total H, and select its highest-benefit mass a. For example take a cutoff c in[0,B] with

nu_z{b>c}<=a<=nu_z{b>=c},

retain rho0 on b>c, retain the fraction (a-nu_z{b>c})/nu_z{b=c} on its threshold atom, and retain0 below. A zero tie mass means the strict tail already equals a. The c=0 case MUST fill the zero-benefit tie when needed; simply retaining b>0 could lose source mass or alter delta. Parameterized tail integrals, rational cutoff tests and the explicit tie fraction make k jointly measurable. This treats source atoms in benefit values without splitting any original physical-clock atom or changing source y marks.

For each z, the maximum retained reward under0<=k<=rho0,E_P k<=a is

integral_0^B min(a,E_P[rho0 1{b>s}]) ds.

The explicitly tie-filled plan attains this value and the requested mass min(H,a). A direct weak upper bound is a*c+E_P[rho0(b-c)+] for any c>=0; the cutoff attains it. This is only the finite-measure one-column bounded-fill problem, not an infinite-dimensional full transport strong-duality claim. Nonnegative b permits exact filling even when only zero benefits remain.

After uniform refill the exact original marked bad cost is

R_new=G_joint-integral_U integral_P k(y,z)b(y,z).

Hence the displayed gain in the proposal is exact, not an extra previously used square credit. It is nonnegative and cannot exceed G_joint, since the final plan has nonnegative cost C. At each target, the old R375 proportional retained density rho0*min(1,1/H) has mass min(H,1)<=min(H,a); nonnegative-benefit priority therefore has at least its reward. This gives no worse residual than that old shared-box plan at identical full fields and the SAME3Gamma cap2 template price. It does not compare reallocated h/masks across different complete estimates, and supplies no uniform positive gain or general root payment.

## Optimality in the subproposal plus uniform-refill class

The parent's added restricted-class statement also passes. Consider ANY measurable0<=k'<=rho0 and its uniform row refill beta'=1-E_U k'. Put T=E_PU k',R(z)=E_P k'. Assume its final target satisfies R(z)+1-T<=2. Then R<=H and R<=1+T, so

T=E_U R<=E_U min(H,1+T)=1-E_U(H-1-T)+.

Thus F(1+T)<=2, and the scalar water-level monotonicity gives1+T<=a. Therefore every competitor's retained column obeys R<=a. Its retained reward is bounded by the targetwise priority value above, which the constructed plan attains simultaneously. The proposed plan is consequently an exact minimizer of bad cost within THIS fixed-proposal, subproposal-plus-uniform-refill class. It is not necessarily optimal among all aggregate-cap2 transport plans, among all possible proposals, or among per-v geometric box choices. The proof is an elementary feasible construction plus scalar weak upper bound; no unverified transport attainment/strong duality is used.

## Genuine remaining requirements and evidence

A final theorem must retain joint measurability of rho0,b and the probability kernels, nonnegative proposal benefit, the d=0 and null-H conventions, fractional cutoff atoms, every source row/refill cost, and whole-v plan selection. If a different geometric proposal is used it must still be common to all actual large receivers after K is aggregated. Neither target occupancy H nor positivity of near-box volume proves a uniform weighted-congestion budget. Source independence, source density ceilings and selector availability are not supplied.

The M04 skill was read for its measurability checklist only. Its generally unverified measurable-selection interfaces are not invoked: this construction uses explicit continuous scalar roots and measurable quantiles.

Reviewer actually ran a local Python Fraction exercise: PASS256 grouped finite priority/refill cases. It checks the exact scalar water-level equation, fractional benefit ties (including benefit0), source row/refill identities, exact cap2 target, layer-cake reward and comparison with the old proportional cap1 retention. These are finite scalar arrays, not native hard-field realization, and are separate from any future author/parent execution totals. No R376 author proof had been read at that initial screen stage; completed author/final review follows.

## Additional independent screen: strict-past actual-J logarithmic kernel bound

This additional claim was screened before its author proof. PASS for the ORIGINAL all-u L, with the strict global mass-past gate and full field retained until each majorization. Let J_y(t)=integral_{R_u<=t} c_u(y)dmu_u, J_y(a-)=0 and J_y(b)<infinity. Original receiver density is dmu=du/m_u, m_u=q_u R_u^n, q_u<=lambda, q_u>=q_-. If m_w<m_u/K and K>lambda/q_-, then R_w<R_u strictly. Consequently Z_y(m_u/K-)>h implies

J_y(R_u-) >= Z_y(m_u/K-) > h.

This is a genuine left-prefix fact; replacing the strict mass past by a right mass cutoff without checking ties would not be licensed. The original source/high-J gate need not be changed. For an active u, monotonicity J_y(r)>=J_y(R_u) on r>=R_u and the INCLUSIVE physical tail integral_[R_u,b] ell=R_u^-n give

L_v(y) <= integral_E c_u(y) 1{J_y(R_u-)>h} du/[R_u^n J_y(R_u)]
<=lambda integral_[a,b] 1{J_y(t-)>h} dJ_y(t)/J_y(t).

A_uv<=1 was dropped only as a positive upper bound. At an atom the denominator here is the full RIGHT prefix J_y(t), not J_y(t-); this includes the terminal b atom. At a, the left prefix0 excludes the first radius atom regardless of its size. At any later jump crossing h with old value<=h, that whole jump is likewise excluded. If there is continuous or singular-continuous growth through h, no artificial crossing atom is introduced.

For any finite nondecreasing right-continuous J, define Phi(x)=log(max(x,h)). On its continuous part dPhi(J)=1{J>h}dJ/J, including the singular-continuous part by the BV chain rule. At an atom with J_->h,

Delta J/J <= log(J/J_-)=Delta Phi(J).

Atoms not satisfying that left gate contribute0 and their potential increments are nonnegative. Thus, with all endpoints and any countable jump set,

integral 1{J_->h}dJ/J <= Phi(J_b)-Phi(0)=log_+(J_b/h).

It can equivalently be established by finite-jump approximation or the monotone Stieltjes potential inequality; absolute continuity of J in radius is not assumed. If J_b<=h both sides vanish. The existing actual receiver envelope J_b<=A_clock/q_- therefore yields the valid UNIFORM kernel ceiling

0<=K_v<=L_v<=B_log := min(A_clock/h,lambda log_+(A_clock/(q_- h))),
A_clock=1+n log(b/a).

This improves a kernel ceiling without changing full f, m, q, J or clock; it does NOT by itself pay the general residual. If a later formula divides by B_log, its B_log=0 case must be separated: L=K=0 on that parameter field and all corresponding d-weighted costs/credits vanish. A new smaller B in a tilt must be used in a reconstructed feasible-plan proof, not combined by reusing an already-spent old credit.

Reviewer actually ran768 finite increasing-jump cases in Python Fraction. The strict-left/right-denominator sum was compared against a rational LOWER atanh-series enclosure for log(J_b/h), including zero jumps and first/last atoms. All passed. This is finite-jump evidence, not proof for singular-continuous components, which is covered by the analytic Stieltjes argument above. Together with the earlier256 priority/refill cases, reviewer-local counts are1024 grouped scalar checks, separate from author/parent totals. The independent screen preceded the log author proof; completed author/final review follows.

## Bounded author review: priority proof

After the independent screen, read /tmp/r376_priority.md in full, including its complete embedded Python code. PASS for the stated fixed-proposal subflow/refill class. Its water root, explicit retained-benefit quantile, fractional b=0 cutoff, exact source/target marginals, reward integral and restricted-class optimality agree with the independent proof. The full class competitor proof correctly uses R<=1+T and not a row-cap assumption. The proposition does not claim optimality among arbitrary aggregate-cap2 transports or among all proposals. Null infinite-H targets are removed only as a joint-kernel null modification; d=0 is an omitted d-weighted contribution, not a claim that K/L themselves vanish.

The exact cost identity G_priority=G_joint-R and the refined near-box bound with the ACTUAL beta*g refill are correct. The difference from old proportional retention splits into nonnegative same-level priority gain plus water gain, because min(a,T)-min(1,T)=min(a-1,(T-1)+). Their strictness condition is a positive d_v dv U_v dz ds-measure set, not H>1 alone. Every comparison here has identical full fields and h. The original positive decomposition is rebuilt floor+new-good+actual-priority-cost; SAME3Gamma replaces the prior cap2 template and no old square/credit is reused. Whole-v finite measurable candidate selection is legitimate, source-row mixing is not automatically legitimate.

The final embedded count67816 is a count of grouped finite Fraction assertions:248+44352+23216. The script includes zero-benefit threshold filling, exact row/refill and target checks, column vertex optimum checks, direct cost/gain identities, and finite feasible competitors having their own retained totals. These are finite algebraic kernels, not actual highpast geometry or a general congestion estimate. The earlier17876 run is explicitly superseded and must not be added to the final count. This reviewer inspected but did not duplicate that full pipeline.

Priority file SHA256 at review: 6e802aab24ab3c8334306a559dd176bae2bcc11567679fe5ab6feb3678baa8e0.

The completed logarithmic-kernel proof and final integration review appear below. No general root budget or unproved whole-transport optimum is certified.

## Bounded frozen numerical review

Read /tmp/r376_numeric.md and the full standalone Python, inspected frozen input/result structures and all saved summary accounts, and checked both recorded R375 provenance hashes against current dependency bytes. PASS within its finite scope. The code reconstructs actual full source matchings, q=1,m=R^n,W=4,4,33/4, complete J/strict global past and all physical prefix-clock weights including the last atom. Its one K/L per v aggregates every marked original large receiver u; no private per-u transport, reset source or invented omega is used. The source cells are actual positive-volume compact L1 cells; receiver integration is finite quadrature with deliberately diagnostic thresholds/outside masks, not the native high-dimensional hard contract.

The 125 proposal source rows use the ENTIRE exact C=0 layer, not an arbitrary favorable subset. The code independently reconstructs every actual participating cube intersection, verifies its positive volume, checks exact equality to zero-cost target cells and containment of the original source cell. Rows L=0 use Q_v. The saved 42 per-v plans retain zero-congestion columns and endpoint a=2 cases. Finite source partitioning makes the actual cellwise geometric containment checks valid here; this fact is not extrapolated to a universal positive-volume zero layer.

Water is solved exactly on all rational break intervals. Retention quantities in the numeric code are JOINT cell masses, so its column quota U_j min(H_j,a), source lost mass P_i-sum_j retained_ij, and final d*(retained+loss*U) have consistent units. Priority sorts the zero-loss proposal benefit g_i; this is precisely b=g-C on proposal support. The exact column upper certificate cap*theta+sum proposal*(g-theta)+ bounds every feasible subproposal and is attained by the greedy fractional selection, including ties/benefit0. All three constructions check every row equality, every nonnegative entry and every target<=2dU. Uniform refill cost is exactly d*sum loss_i*g_i. The full restricted-class optimality is analytic as proved above, not inferred just from the sampled competitors.

Ten inherited all-cap2 benchmarks are rechecked with primal exact row constraints/column caps, nonnegative entries, dual column prices<=0, every source-target cell inequality and exact zero gap. They are explicitly reused, not newly solved. Thus priority's positive gap to this broader optimum is a certified distinction of classes, not a general lower bound from the stronger row/proposal class. The saved priority gaps are 491/3649536,39691/400619520 and9863/119070720. Tables distinguish bad/G from absolute bad; the 2D shared benchmark ratio661/1884 and priority ratio22561/60288 use the same frozen original G. No new MATLAB call occurred this round's numeric comparison.

The script counts4003 grouped exact Fraction assertions,644 column certificates,125 actual zero-box rows and126 final plans. Its saved PASS/result summary is consistent with the note and code. Display decimals are rational approximations, not extra evidence. The reviewer did not duplicate the parent-reported full run and did not modify any numeric or author file. Standalone paths are relative to the script directory. No input/dimension-uniform contraction, native gate realization, shared-cap2 global theorem or general root payment follows.

Numerical SHA256 at review:
- numeric.md: 96b312d7e3764c0aba1270cfe31058ce21239e446500542ec8b7f3c7f0725b22
- numeric.py: 16ccc719f11d6451499e02a823f8753e18ecf5f22d13d94c68392690c3024ce4
- numeric_input.json: 78e33df37d94bad295934ec67a77572c50561952feff6f1067a10951b2ecf4b9
- numeric_result.json: 19bf51c1a877147e6241b1f11775a4ce0fdb57b07a38b65782c02cd2dd51de1f

Final geometry/log proof and main/ledger review are completed below.


## Final geometry proof and original-clock consequences

Read final /tmp/r376_geometry.md in full, including the complete rational-check code. PASS. The original strict mass-past inequality is converted to a strict LEFT radius prefix by actual m=qR^n and K>lambda/q_-, not by redefining the past. The normalization cancellation in (5) is exact. Dropping A<=1 and the high-J indicator is solely positive domination; reciprocal J is retained until the inclusive physical tail is integrated. This is essential and does not assume source/receiver independence. The whole a radius atom is excluded by J(a-)=0, while b's physical-clock atom and any allowed J jump at b remain correctly treated.

The author's generalized-inverse proof of (6) is valid for every finite pushforward radius measure: Q pushes rank Lebesgue to that measure and F(Q(s)-)<=s<=F(Q(s)) almost everywhere. On retained ranks s>h and1/F(Q(s))<=1/s. It therefore covers continuous singular prefixes directly, without a false absolute-continuity assumption. The atom formula uses Delta J/J_right and excludes a threshold-crossing jump whose left value has not exceeded h. Joint source measurability is inherited from the original parameterized kernels. The actual-center envelope J_b<=A_clock/q_- is correctly evaluated using center volume r^n and is not a source-density bound or independently selected radius integration.

Consequently the original kernel ceiling K<=L<=min(A_clock/h,lambda log_+(J_b/h)) and its uniform B_star are unconditional under this frozen hard contract. The zero-J and B_star=0 conventions are explicit. In the geometry proof's b_h-centered ROW tilt, centering conditional on y preserves the source row and cap2 target even with a variable denominator. Variance/b_h is integrable: Var(K)<=r(L-r), and the zero-envelope row has K=L=r=0. This construction is not an application of the old doubly-centered identities with a variable denominator. The true R375 M=max(r,L-r)<=L<=b_h already provides at least this gain; it must not be counted again as extra credit. Equation(10)'s minimum equals the original exact refill cost, as the author explicitly states. The new contribution is a better justified envelope, not free payment of the remaining weighted refill integral.

The geometry check uses rigorous rational atanh-series lower/upper enclosures, not float logs; finite clock cases preserve m=qR^n,strict mass past,radius ties and terminal-clock algebra. Its finite Cantor approximants do not prove the singular-continuous case, which is proved analytically. The1626 grouped checks split150 atomic-log,1080 clock,360 strict-left and36 Cantor-log. Both standalone priority and geometry scripts were verified to match their unique embedded code blocks after whitespace stripping. No author/check script was changed by this reviewer.

## Final main, ledger and evidence decision

Read the final main, ledger and readme and compared them with the proved constructions. PASS. The original full-f/source m/q/J/past/clock fields are frozen throughout. New priority plans are inserted by rebuilding floor+transported-good+actual-bad from the original positive decomposition; SAME3Gamma replaces the previous cap2 template rather than appending another floor or mark fee. The h/epsilon0 allocation and C338 source price stay synchronized. The original entrance factor2,outer Lambda=128/119,8lambda H W and2d_eff A_clock Wnu/H remain. If expressed from G_joint, earned reward is subtracted only once as2Lambda*R. No new extra absorption or source-price budget is claimed merely from the log envelope.

The source-dependent b_h must stay inside its actual source-weighted integral unless replaced by its valid uniform maximum. beta*g is retained and bounded above, not erased. Changing xi changes the proposal and its congestion/beta. A better source envelope does not improve beyond the already allowed true M plan automatically. Finite WHOLE-v candidate selection is licensed; arbitrary source-row mixing is not. Priority is exactly optimal in its fixed-proposal plus uniform-refill class and may still have a strict gap to general aggregate cap2. The finite examples demonstrate precisely that gap and do not certify native high-dimensional gates, dimension rates or a universal gain fraction.

Actual execution records are separate: parent reports actual fresh priority67816 grouped Fraction assertions, numeric4003 grouped Fraction assertions and geometry1626 rational/log-enclosure checks, all PASS. No old MATLAB LP was repeated; inherited exact primal/dual benchmarks were reverified. Reviewer actually ran1024 grouped scalar Fraction cases (256 priority/refill plus768 jump-log), separate from parent totals. This final audit inspected all code/results without duplicating those full parent pipelines. There is no inference about model billing or unavailable per-agent costs.

Unpaid obligations remain the source-weighted residual/congestion root budget, original hard entrance and soft/crossing interfaces, contract-external tails/scales/threshold complements, historical initial/deletion/future-source time atoms, H choice, scale/source aggregation, outer integrations and truncation/limits. Physical-clock terminal atoms do not substitute for historical atoms. The full arbitrary-input root upper bound is not closed. This audit did not re-audit every historical reduction or claim the complete sum of remaining slots is absorbable.

## Final SHA256 bindings

The following are final reviewed bytes. This audit does not bind later generated TeX/PDF layout or future changes.

```text
ee704b7df2428b2b7910b90e7f82805bebfba70947ac58101b9f6ab5ab6dea1e  /tmp/r376_main.md
28863cfe9c3636eeb4bea6003f90f30b15f2f3acb308aebf901aceaa0f564d02  /tmp/r376_ledger.md
5ff2a1af7e060dc029517fa4f100708721f9ef8afdf3f063ba38b4869612f505  /tmp/r376_readme.md
16c68acce633ca7df17e8f2506fbc31c4aa00495b89200c84b745289e5b3caa7  /tmp/r376_geometry.md
6e802aab24ab3c8334306a559dd176bae2bcc11567679fe5ab6feb3678baa8e0  /tmp/r376_priority.md
96b312d7e3764c0aba1270cfe31058ce21239e446500542ec8b7f3c7f0725b22  /tmp/r376_numeric.md
601a80be8db8939ac66847cfa33f51771cf7dda5f972a7ec15753c467783bef5  /tmp/r376_priority_check.py
23f29300cbdadee09dc3712acec3afe2aa7e0b4dae9714395c793ea3d0553259  /tmp/r376_geometry_check.py
16ccc719f11d6451499e02a823f8753e18ecf5f22d13d94c68392690c3024ce4  /tmp/r376_numeric.py
78e33df37d94bad295934ec67a77572c50561952feff6f1067a10951b2ecf4b9  /tmp/r376_numeric_input.json
19bf51c1a877147e6241b1f11775a4ce0fdb57b07a38b65782c02cd2dd51de1f  /tmp/r376_numeric_result.json
b703ec31eee5018d417b115ec7642b9768c91f72472077a0c23460ae27431502  /tmp/r375_geometry.md
3c432638efddd308e7f433ac079ebd539e587e7a899994aad8eb83ebd81df8c5  /tmp/r375_capacity.md
69c16a20ff8fb214cfedcd54307ae145ff0ffe859d581bf80ba544642b40773f  /tmp/r375_main.md
930aea90f1d8a991090a3d3a4d5c93b8f999e389e8f7d1ca9c2071995199044c  /tmp/r375_ledger.md
4111b2d3f87462a83e444fea35094cbd92831d95a918eb0fe2af3db5a9b41df2  /tmp/r375_audit.md
a389ed36d0ba113e1f0a146e824d9fab5dadfddfcc11df6191c6eba06eab6644  /tmp/r375_numeric_input.json
36817ecd7c06b902735ae58429e463090e43660fca82157a75155088fd0d43cc  /tmp/r375_numeric_result.json
384a4ae6f3a1c6611b3ddeb81cd7a4a6c4b5a9b24b0f0ce48d3a0bfd63b2406d  /tmp/r374_geometry.md
fac02a43e18ed5dc3d5be7ef67a8ac9e34cbd4dd1e69912d6e29dffda597d81a  /tmp/r370_geometry.md
```

Final decision: PASS for the original-clock logarithmic envelope, explicit measurable priority/refill construction, its restricted-class optimality, finite certificates and synchronized complete accounting. No unresolved correction in this bounded review. The explicit retained general residual and other slots remain unpaid.
