# R376 — zero-loss proposal, waterlevel, and common column priority

## Result and decision

The new explicit mechanisms improve the same frozen original finite diagnostic cost. The priority+waterlevel construction is stronger than proportional clipping at the same waterlevel, but still has a strictly positive gap to unrestricted shared target-cap2 transport in every sample.

| Frozen field | Clip at 1 bad/G | Water proportional bad/G | Water priority bad/G | R375 all-cap2 optimum bad/G |
|---|---:|---:|---:|---:|
| Equal 15 intervals | 1247/5904 ≈ .211213 | 25/492 ≈ .050813 | 491/35424 ≈ .013861 | 0 |
| Weighted 15 intervals | 6959623/34388880 ≈ .202380 | 21331/716435 ≈ .029774 | 39691/5158332 ≈ .007695 | 0 |
| Twelve 2D cubes | 17829875/31108608 ≈ .573149 | 1111105/2592384 ≈ .428604 | 22561/60288 ≈ .374220 | 661/1884 ≈ .350849 |

The priority bad costs exceed the all-cap2 optima by exactly 491/3649536, 39691/400619520, and 9863/119070720. Thus priority addresses a real allocation issue; the remaining gap is not eliminated merely by finding a better priority within the **subproposal+uniform-refill** class described below. It does not establish a dimension rate or a general receipt.

All decimals are display approximations of exact saved rationals. No new MATLAB LP is run. R375's cap2 plan and exact dual certificates are reused and rechecked; no old optimum is replaced by a heuristic benchmark.

## Same source and all original finite marks

The input snapshots the same three complete real-source fields as R374/375. These are genuine compact piecewise-constant L1 sources on complete positive-volume source cells; actual masses remain 4,4,33/4, and every receiver matching remains m_u=R_u^n, q_u=1. The first two have 15 receiver intervals/16 source cells; the third has 12 actual 2D cubes/208 source cells. Receiver weights are finite positive quadrature, not dx.

The current script independently reconstructs full original finite ω from original J, strict global past, all physical prefix clock weights including the terminal atom, then rederives the single common all-u cost K_v and L_v for every v. It retains R375's diagnostic κ=6/5 and H=h=1/16 in 1D, 1/64 in 2D, outside mask and original receiver weights. Nothing inserts arbitrary ω, resets q, alters source f, or chooses a separate plan for each u. These diagnostics do not realize the native high-dimensional hard gates/history.

For each v, source marginal μ_v^+=d_v P_v and uniform target U_v remain frozen. Let C_i(z)=L_i−K_i(z)≥0 on old-source row i. Every row's entire zero-loss layer is used:

    C0_i={z∈Q_v:K_i(z)=L_i},
    ρ0_i(z)=1_C0_i(z)/U_v(C0_i).

No arbitrary zero-loss subset is selected. There are 125 old-source rows in the 42 v plans. For each, the script independently forms the actual box intersection Q_v∩⋂Q_u over every positive original marked u contribution. It checks that this positive-volume intersection equals exactly the union of zero-cost target cells and contains the entire old-source cell. **No row has an empty zero layer.** Rows with L=0 use all Q_v, not a missing-row convention.

Existing boundary stress is substantial: there are 40,40,33 rows with L=0; 12,12,10 v have waterlevel 2; proposal target density is zero on two columns in each 1D case. These are included without deleting rows or zero-target columns.

## Three exact constructions

Work under normalized P_v×U_v; multiply plans by d_v and final costs by outer w_v. Let proposal density ℋ(z)=E_Pρ0_i(z), so E_Uℋ=1. Define the original refill benefit

    g_i=E_U C_i=L_i−E_U K_i≥0.

All retained proposal mass has cost zero. Hence every completed plan's bad cost is exactly d_v times the source-weighted lost mass times g_i.

**Clip at 1.** Retain proposal P_iU_jρ0_ij min(1,1/ℋ_j), treating ℋ=0 as zero proposal. Add each lost source row back against U. Source is exact and target≤2d_vU.

**Water proportional.** Solve the exact piecewise-linear equation

    a∈[1,2],    E_U max(ℋ,a)=2.

The endpoint bracket and positive growth slope are rationally certified. Retain the proposal proportionally to min(1,a/ℋ), then refill each source loss against U. Retained total is a−1, lost total is 2−a; completed target density is min(ℋ,a)+2−a≤2. The smallest waterlevels are 11/6,11/6,279/170 in the three fixtures; every maximum is 2.

**Water priority.** Use the same a. In each target column retain total U_j min(ℋ_j,a), preferentially from proposal source rows with largest g_i, splitting the final row if necessary. There is one common plan per v. This does not choose a different target marginal for each u. Every lost source row is refilled against U. The same total lost mass and target cap hold.

For each of 644 target columns the exact fractional-knapsack upper certificate is checked. With column capacity b and last retained benefit θ,

    retained_benefit ≤ b θ + Σ_i proposal_ij (g_i−θ)_+.

The greedy feasible selection attains equality. Its entries stay between zero and the original proposal entries, and exactly fill the column quota. The threshold and exact plan are saved. Priority strictly improves proportional-water cost for 3,3,2 v respectively; it never worsens it. All 126 constructed final plans have exact source marginal and target≤2d_vU.

## Optimality within the restricted class, not all target-cap2

The water reduction supplies the finite global class comparison in addition to column optimality. Consider ANY nonnegative retained subproposal k≤Pρ0, with lost old-source rows refilled uniformly. Let its total retained mass be T≤1 and retained column density be R(z). Feasibility of the completed target cap implies R(z)≤1+T, while the subproposal gives R(z)≤ℋ(z). Therefore

    T≤E_U min(ℋ,1+T)
      ⇒ E_U max(ℋ,1+T)≤2.

Since E_Uℋ=1, U{ℋ≤1}>0; thus F(x)=E_Umax(ℋ,x) is strictly increasing for x∈[1,2]. Its root F(a)=2 gives 1+T≤a, hence each column satisfies R≤min(ℋ,a). Nonnegative g then bounds every retained benefit by the sum of the certified column-priority maxima. Priority fills all these caps, has T=a−1, and is feasible. It is therefore optimal in this **retained-subproposal plus uniform-refill class**.

This elementary finite reduction is distinct from an unrestricted transport theorem. The R375 all-cap2 plans can alter source-to-target associations beyond this class and achieve the smaller benchmark values in the table. The strict exact gaps are consequently an actionable distinction between the two feasible classes, not solver failure.

## Actual floor/good accounts

For every construction the invariant floor is unchanged and

    G = floor + transported good + constructed bad.

The script computes the actual sample template floor+good=G−bad. No tΓ coarse fee is substituted. The floor values are 41/8448, 143287/22256640, 3731/19845120, and original G values are 41/4224, 143287/11128320, 1099/310080. Full exact good/template values for all three methods are saved in the summary.

The priority template floor+good values are exactly 34933/3649536, 5118641/400619520, 264089/119070720. All comparisons use the same full original finite marks and original source labels. Neither a new source nor a favorable receiver-only source surrogate is introduced.

## Execution, reproduction, and limitations

The local standard-library Python script actually ran, then reran in a fresh process, passing **4,003 exact grouped assertions**. These include 644 column threshold zero-gap certificates, 125 actual positive-volume zero-box checks, all source and cap constraints, and revalidation of ten inherited cap2 benchmarks. Grouped vector assertions count once; solver flags and decimal displays are not counted. No new optimizer or LP call is needed.

Standalone reproduction uses `r376_numeric.py` and `r376_numeric_input.json` in one directory:

    /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r376_numeric.py

`r376_numeric_result.json` stores all three actual plans per v, source losses, waterlevels, target densities, thresholds, exact accounts and benchmark gaps. Optional `prepare` mode reads only frozen `r375_numeric_input.json` and `r375_numeric_result.json`, snapshots all needed fields/certificates and records their SHA256. Verify itself reads no older temporary script/data. Existing files are never modified.

This is finite receiver quadrature with genuine positive-volume L1 source/target cells and complete original diagnostic marks. It does not certify native high-dimensional hard gates, general root fees, a universal contraction fraction, or optimality among all cap2 plans. The practical conclusion is narrower: priority and waterlevel materially improve explicit constructions here, but source-independent uniform refill leaves a measurable gap to the more flexible shared-cap optimum.
