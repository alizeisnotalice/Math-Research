#!/usr/bin/env python3
"""Frozen original marked fields: zero-loss proposals, clipping, water and priority."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json,sys,hashlib
BASE=Path(__file__).resolve().parent;COUNTS=Counter()
def ck(k,v):
 COUNTS[k]+=1
 assert v,k
def dot(a,b):return sum((F(x)*y for x,y in zip(a,b)),F(0))
def read(p):return json.loads((BASE/p).read_text())
def sha(p):return hashlib.sha256((BASE/p).read_bytes()).hexdigest()
def prepare():
 old=read('r375_numeric_input.json');data=dict(cases=old['cases'],inherited_cap2_certificates=[c for c in old['inherited_certificates'] if c['mode']=='cap2'],provenance={p:sha(p) for p in ['r375_numeric_input.json','r375_numeric_result.json']},scope='Frozen full-matching actual compact L1 sources and complete source/target cells, finite receiver quadrature/full diagnostic marks; not native hard traffic. No new LPs. Three explicit zero-layer proposal constructions, not general transport optima.')
 (BASE/'r376_numeric_input.json').write_text(json.dumps(data,sort_keys=True,indent=2)+'\n');print('PREPARED three frozen real-source fields; no new LP')
def fullmarks(c):
 n=c['n'];N=len(c['receivers']);A=c['A'];vol=list(map(F,c['volumes']));x=list(map(F,c['source_mass']));f=[a/b for a,b in zip(x,vol)];R=[F(r['R']) for r in c['receivers']];w=[F(r['weight']) for r in c['receivers']];centers=[list(map(F,r['center'])) for r in c['receivers']];m=[r**n for r in R];mu=[a/b for a,b in zip(w,m)];radii=sorted(set(R));h=F(c['h']);H=F(c['H']);kap=F(c['kappa']);omega=[list(map(F,row)) for row in c['omega']]
 ck('stage2_full_source_same_all_actual_matching',all(dot(row,x)==mass for row,mass in zip(A,m)) and sum(x)==F(c['actual_W']))
 expected=[[F(0)]*len(x) for _ in range(N)]
 for u in range(N):
  for y in range(len(x)):
   past=sum(mu[t]*A[t][y] for t in range(N) if m[t]<m[u]/kap)
   if past<=h:continue
   for l,r in enumerate(radii):
    if r<R[u]:continue
    J=sum(mu[t]*A[t][y] for t in range(N) if R[t]<=r)
    if J>=H:
     ell=r**(-n)-(radii[l+1]**(-n) if l+1<len(radii) else 0)
     expected[u][y]+=h*m[u]*ell/J
 ck('stage2_reconstructed_full_omega_J_past_clock',expected==omega)
 for p in c['plans']:
  v=p['v'];src=p['source_cells'];tgt=p['target_cells'];d=F(p['d']);rows=list(map(F,p['row']));cols=list(map(F,p['col']));K=[list(map(F,row)) for row in p['K']];L=list(map(F,p['L']));C=[list(map(F,row)) for row in p['cost']]
  ck('stage2_original_source_and_uniform_target_marginals',rows==[vol[y]*(f[y]-1)/m[v] for y in src] and cols==[d*vol[z]/m[v] for z in tgt] and sum(rows)==sum(cols)==d)
  Lv=[];Kv=[]
  for y in src:
   aa=[]
   for u in range(N):
    S=m[u]>kap*m[v] and 2*max(abs(a-b) for a,b in zip(centers[u],centers[v]))>R[u]
    aa.append(mu[u]*(1-m[v]/m[u])/h*omega[u][y]*A[u][y] if S else F(0))
   Lv.append(sum(aa));Kv.append([sum(aa[u]*A[u][z] for u in range(N)) for z in tgt])
  ck('stage2_one_common_objective_all_u_and_original_marks',Lv==L and Kv==K and C==[[L[i]-a for a in row] for i,row in enumerate(K)])
 return True

def zero_geometry(c,p,i,mask):
 n=c['n'];v=p['v'];y=p['source_cells'][i];rec=c['receivers'];A=c['A'];h=F(c['h']);kap=F(c['kappa']);R=[F(r['R']) for r in rec];m=[r**n for r in R];w=[F(r['weight']) for r in rec];center=[list(map(F,r['center'])) for r in rec];omega=[list(map(F,row)) for row in c['omega']];active=[]
 for u in range(len(rec)):
  if m[u]>kap*m[v] and 2*max(abs(a-b) for a,b in zip(center[u],center[v]))>R[u] and omega[u][y]*A[u][y]>0:active.append(u)
 boundlo=[max(center[u][d]-R[u]/2 for u in [v]+active) for d in range(n)];boundhi=[min(center[u][d]+R[u]/2 for u in [v]+active) for d in range(n)];volume=F(1)
 for a,b in zip(boundlo,boundhi):volume*=max(F(0),b-a)
 fromcells=sum(F(c['volumes'][z]) for keep,z in zip(mask,p['target_cells']) if keep)
 geometricmask=[]
 for z in p['target_cells']:
  cell=[[F(a),F(b)] for a,b in c['cells'][z]]
  geometricmask.append(all(boundlo[d]<=a and b<=boundhi[d] for d,(a,b) in enumerate(cell)))
 ck('actual_zero_loss_is_full_common_intersection_box',geometricmask==mask and volume==fromcells)
 ck('actual_zero_loss_positive_volume_contains_old_source_cell',volume>0 and all(boundlo[d]<=F(a) and F(b)<=boundhi[d] for d,(a,b) in enumerate(c['cells'][y])))
 return volume/m[v]
def waterlevel(U,H):
 def fun(a):return sum(u*max(h,a) for u,h in zip(U,H))
 ck('waterlevel_endpoint_bracket',fun(F(1))<=2<=fun(F(2)))
 ck('waterlevel_strict_growth_on_one_to_two',sum(u for u,h in zip(U,H) if h<=1)>0)
 cuts=sorted({F(1),F(2)}|{h for h in H if 1<h<2})
 for lo,hi in zip(cuts,cuts[1:]):
  if fun(lo)==2:return lo
  if fun(lo)<=2<=fun(hi):
   slope=sum(u for u,h in zip(U,H) if h<=lo);intercept=sum(u*h for u,h in zip(U,H) if h>lo);a=(2-intercept)/slope
   ck('waterlevel_exact_piecewise_linear_root',1<=a<=2 and fun(a)==2);return a
 assert False,'waterlevel root missing'
def cap2_lower(p,cert):
 C=[list(map(F,row)) for row in p['cost']];r=list(map(F,p['row']));s=list(map(F,p['col']));T=[list(map(F,row)) for row in cert['plan']];rp=list(map(F,cert['row_potential']));cp=list(map(F,cert['column_potential']));nr=len(r);nc=len(s)
 ck('reused_cap2_primal_feasible',all(a>=0 for row in T for a in row) and [sum(row) for row in T]==r and all(sum(T[i][j] for i in range(nr))<=2*s[j] for j in range(nc)))
 ck('reused_cap2_dual_feasible',all(b<=0 for b in cp) and all(rp[i]+cp[j]<=C[i][j] for i in range(nr) for j in range(nc)))
 val=sum(T[i][j]*C[i][j] for i in range(nr) for j in range(nc));ck('reused_cap2_exact_optimal_benchmark',val==dot(r,rp)+dot([2*a for a in s],cp)==F(cert['value']));return val

def construct(c,p):
 rows=list(map(F,p['row']));d=F(p['d']);P=[r/d for r in rows];U=list(map(F,p['U']));C=[list(map(F,row)) for row in p['cost']];L=list(map(F,p['L']));K=[list(map(F,row)) for row in p['K']];nr=len(P);nc=len(U);zero=[[a==0 for a in row] for row in C];u0=[]
 for i,mask in enumerate(zero):
  z=dot(U,mask);ck('row_zero_layer_positive_uniform_mass',z>0);ck('zero_layer_volume_matches_actual_intersection',z==zero_geometry(c,p,i,mask));u0.append(z)
 rho=[[F(1)/u0[i] if zero[i][j] else F(0) for j in range(nc)] for i in range(nr)];proposal=[[P[i]*U[j]*rho[i][j] for j in range(nc)] for i in range(nr)];H=[sum(P[i]*rho[i][j] for i in range(nr)) for j in range(nc)];g=[dot(U,row) for row in C]
 ck('zero_proposal_exact_rows_and_mean_target',all(dot(U,row)==1 for row in rho) and [sum(row) for row in proposal]==P and dot(U,H)==1)
 ck('proposal_all_zero_loss_and_g_original',all(proposal[i][j]*C[i][j]==0 for i in range(nr) for j in range(nc)) and all(g[i]==L[i]-dot(U,K[i]) for i in range(nr)))
 a=waterlevel(U,H);keeps={};cert=[]
 for name,cut in [('clip1',F(1)),('water_proportional',a)]:
  keeps[name]=[[proposal[i][j]*(min(F(1),cut/H[j]) if H[j]>0 else F(0)) for j in range(nc)] for i in range(nr)]
 # Independent exact column knapsack, benefit g_i retained from zero-loss proposal.
 priority=[[F(0)]*nc for i in range(nr)];thresholds=[]
 for j in range(nc):
  cap=U[j]*min(H[j],a);left=cap;theta=F(0)
  for i in sorted(range(nr),key=lambda i:(-g[i],i)):
   take=min(left,proposal[i][j]);priority[i][j]=take;left-=take
   if take:theta=g[i]
   if not left:break
  ck('priority_column_exact_target_and_proposal_caps',left==0 and sum(priority[i][j] for i in range(nr))==cap and all(0<=priority[i][j]<=proposal[i][j] for i in range(nr)))
  beta=[max(z-theta,F(0)) for z in g];ck('priority_column_threshold_dual_feasible',all(theta+b>=z and b>=0 for z,b in zip(g,beta)))
  val=sum(g[i]*priority[i][j] for i in range(nr));upper=cap*theta+sum(proposal[i][j]*beta[i] for i in range(nr));ck('priority_column_exact_primal_dual_equality',val==upper)
  propval=sum(g[i]*keeps['water_proportional'][i][j] for i in range(nr));ck('priority_column_benefit_at_least_proportional',val>=propval)
  thresholds.append(str(theta))
 keeps['water_priority']=priority;values={};plans={};losts={}
 for name,keep in keeps.items():
  loss=[P[i]-sum(keep[i]) for i in range(nr)];T=[[d*(keep[i][j]+loss[i]*U[j]) for j in range(nc)] for i in range(nr)]
  ck(name+'_retained_subproposal_and_source_loss_nonnegative',all(0<=keep[i][j]<=proposal[i][j] for i in range(nr) for j in range(nc)) and all(a>=0 for a in loss))
  ck(name+'_exact_source_and_target_cap2',all(v>=0 for row in T for v in row) and [sum(row) for row in T]==rows and all(sum(T[i][j] for i in range(nr))<=2*d*U[j] for j in range(nc)))
  val=sum(T[i][j]*C[i][j] for i in range(nr) for j in range(nc));ck(name+'_bad_exact_uniform_refill_only',val==d*dot(loss,g))
  if name!='clip1':ck(name+'_water_kept_and_lost_mass',sum(loss)==2-a and sum(sum(row) for row in keep)==a-1)
  values[name]=val;plans[name]=[list(map(str,row)) for row in T];losts[name]=list(map(str,loss))
 ck('priority_no_worse_same_waterlevel',values['water_priority']<=values['water_proportional'])
 ck('water_proportional_no_worse_clip1',values['water_proportional']<=values['clip1'])
 return values,dict(v=p['v'],waterlevel=str(a),H=list(map(str,H)),zero_uniform_masses=list(map(str,u0)),refill_benefits=list(map(str,g)),priority_column_thresholds=thresholds,bad={k:str(v) for k,v in values.items()},loss_by_source_row=losts,plans=plans)
def verify():
 data=read('r376_numeric_input.json');bench={(c['name'],c['v']):c for c in data['inherited_cap2_certificates']};summ=[];certs=[]
 for c in data['cases']:
  fullmarks(c);vals={k:F(0) for k in ['clip1','water_proportional','water_priority']};opt=F(0);strict=0;waterlevels=[]
  for p in c['plans']:
   values,cert=construct(c,p);cert['name']=c['name'];certs.append(cert);wv=F(p['weight']);waterlevels.append(F(cert['waterlevel']))
   ob=cap2_lower(p,bench[(c['name'],p['v'])]) if p['nonzero_cost'] else F(0)
   ck('all_constructed_plans_above_exact_shared_cap2_optimum',all(z>=ob for z in values.values()))
   for k,v in values.items():vals[k]+=wv*v
   opt+=wv*ob;strict+=values['water_priority']<values['water_proportional']
  G=F(c['original_diagonal']);floor=F(c['floor']);S=F(c['surplus_diagonal']);rows=[]
  for k,v in vals.items():
   ck('actual_template_and_bad_positive_account',G==floor+(S-v)+v and 0<=v<=S)
   rows.append(dict(method=k,bad=str(v),bad_fraction_of_G=str(v/G),actual_floor=str(floor),actual_good=str(S-v),actual_floor_plus_good=str(G-v),gap_over_shared_cap2=str(v-opt)))
  summ.append(dict(stage=c['stage'],name=c['name'],n=c['n'],actual_source_W=c['actual_W'],original_G=str(G),shared_cap2_optimal_bad=str(opt),shared_cap2_bad_fraction_of_G=str(opt/G),strict_priority_v_count=strict,priority_class_optimality='Exact per-column threshold duals plus waterlevel retained-mass bound; only subproposal plus uniform-refill class, not all cap2 plans.',waterlevel_min=str(min(waterlevels)),waterlevel_max=str(max(waterlevels)),methods=rows))
 out=dict(status='PASS',exact_grouped_checks=sum(COUNTS.values()),check_counts=dict(COUNTS),summary=summ,construction_certificates=certs,scope=data['scope'],provenance=data['provenance'])
 (BASE/'r376_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='construction_certificates'},sort_keys=True,indent=2))
if __name__=='__main__':prepare() if len(sys.argv)>1 and sys.argv[1]=='prepare' else verify()
