# R378 independent audit — FINAL PASS

Status: FINAL PASS for the clarified bounded claims and final bytes below. Owner scope: only this audit file, no repository/author edits. Independent screens preceded relevant author proofs; full author/code/numeric and final integration review are complete. No general root closure, uniform covered fraction, or infinite-dimensional Hall attainment is certified.

## Freeze the active source before choosing retention

For an actual v, omit its outer d_v for the moment. P=P_v,U=U_v are probabilities, C(y,z)=L(y)-K(y,z)>=0, g(y)=E_U C, A={g>0},F=A^c. Write alpha=P(A),P(F)=1-alpha. Free rows have C=0 U-almost everywhere; constructed completions must have conditional densities relative to U if that a.e statement is used to assert zero cost. d_v=0 means zero d-weighted contribution, not necessarily K=L=0.

Construct a measurable proposal rho0(y,z)>=0 ONLY for active rows, with E_U rho0=1 on A. Its aggregate occupancy is

H_A(z)=integral_A rho0(y,z)P(dy), E_U H_A=alpha.

A retained subflow satisfies0<=k<=1_A rho0, row retained mass<=1. Put R(z)=E_P k,T=E_U R and ell=alpha-T. The ACTUAL lost active source is (1_A-E_U k)P of mass ell; free source mass is1-alpha. Multiplication by d_v restores all physical source/target masses and costs once. A construction which simply drops lost active rows and refills only free rows is not source exact.

## Class I: uniform refill of lost ACTIVE rows, flexible zero-cost free fill

If lost active rows are refilled uniformly against U, their target density is ell. Hence the necessary pointwise condition BEFORE free fill is

R(z)+ell<=2.

It is also sufficient. Set r(z)=2-R(z)-ell>=0. Its total is2-T-ell=2-alpha. Complete the free source with

P|F(dy)*r(z)U(dz)/(2-alpha).

Its source is exactly P|F, and target is(1-alpha)r/(2-alpha)<=r. The full active retention+active uniform refill+free completion has source P and target<=2U. The denominator2-alpha>=1 never vanishes. Free cost is0 by conditional AC; lost active uniform cost and retained cost remain real charges.

For a prescribed lost mass ell in[0,alpha], retained column mass is bounded by both H_A and2-ell. A feasible subproposal retaining total alpha-ell exists if and only if

alpha-ell <= E_U min(H_A,2-ell),
OR equivalently ell >= E_U(H_A-2+ell)_+.

Necessity is immediate. Sufficiency follows by scaling/fractionally selecting a column submeasure of rho0 below the cap, with arbitrary measurable fractional tie filling to the required total. No individual active source may retain more than its proposal row, so source constraints are respected and the exact remaining rows can be refilled as above.

The MINIMAL uniform-active lost mass is the unique root ell_* in[0,alpha] of

ell_*=E_U(H_A-2+ell_*)_+.

Equivalently a_*=2-ell_* solves E_U max(H_A,a_*)=2 with a_* in[2-alpha,2]. For alpha>0 actually a_*>2-alpha; for alpha=0 use a_*=2,ell_*=0. Existence/uniqueness follow from continuous monotonic F(a)=Emax(H_A,a), its endpoint bracket and positive measure below any a>=2-alpha. A rational-root definition makes a_* jointly measurable. One attains the root by retaining exactly min(H_A,a_*) in every target column; then T=alpha-ell_* and uniform-active+free completion is feasible. The root is NOT the old R376 root for a normalized full-source proposal unless alpha=1. No free source proposal should be added into H_A to manufacture that older constraint.

This minimizes LOST PROPOSAL MASS in the specified class. A minimum-cost or priority assertion needs its additional benefit condition and explicit retained selection. In particular a signed benefit must not be filled blindly just to maximize mass. If proposal-supported g-C>=0, targetwise top-benefit selection at the valid active water level can be used, but its cost comparison is still for this fixed-proposal/uniform-active completion class, not arbitrary cap2 transports.

## Class II: allow nonuniform refill of lost active rows as well

If active losses may use arbitrary feasible density refills, the preceding ell-root is an EXTRA restriction, not a necessary minimum for the full conditional class. Retention need only satisfy R<=2; total retained mass cannot exceed E min(H_A,2). Thus the minimum possible loss FROM THE PROPOSAL is instead

ell_general=E_U(H_A-2)_+.

It is attained by the explicit retained density k=rho0*min(1,2/H_A) on A, with zero convention at H_A=0. Let nu_rest=P|F+(1_A-E_U k)P, mass1-T, and s(z)=2-R(z), total2-T. The common refill

nu_rest(dy)*s(z)U(dz)/(2-T)

has exact remaining source and target<=sU. Therefore it completes every such retained flow to cap2. Its free part has0 cost; its active part has an ACTUAL nonuniform refill cost which must be kept. Minimizing loss from the proposal does NOT minimize total retained-plus-refill cost, and does not prove a better complete bound than Class I. Both classes use the same final cap2/3Gamma template price when inserted by rebuilding the original positive decomposition. No construction may discard active source mass or silently replace its refill cost by0.

## Available original outside/not-Bplus geometry and exact missing fee

The allowed original gate supplies m_u>K m_v and R_v<R_u. Put I_uv=f(Q_u intersect Q_v). Then

I_uv<=m_v,
f(Q_u minus Q_v)=m_u-I_uv>=m_u-m_v>(1-1/K)m_u.

These are actual FULL-f mass statements, requiring no source-density cap. The outside-center gate also chooses a measurable maximum-coordinate direction (finite tie rule); every common source lies in the corresponding actual one-sided overlap slab. Uniform volume of that slab or the not-Bplus receiver-body condition cannot be substituted for its f-mass. A fixed-coordinate witness controls a real geometric region, but does not establish independent coordinates, source uniformity or disjoint source bills across different u,v,y.

A precise sufficient packing interface for R377's active loss is available without pretending it is already proved. For each active source row define the actual receiver measure

theta_(v,y)(du)=A_uv*omega_u(y)*c_u(y)du/(h R_u^n),
||theta_(v,y)||=L_v(y)>0.

For each contributing pair, external source probability is

e_uv(dz)=f(z)c_u(z)(1-c_v(z))dz/(m_u-I_uv).

Its denominator is positive by the original mass gap. Assign the active lost-source amount d_v beta_A(y)P_v(dy) to actual external sources by the probability mixture theta/L followed by e_uv. This is a genuine jointly measurable positive assignment, with source marginal total Xi_A. If its aggregate target is f(z)H_ext(z)dz, then EXACTLY

Xi_A=integral f(z)H_ext(z)dz.

Thus an independently proved bound H_ext<=M (f-a.e), or a smaller certified assigned subload with the same lost-source mass, would give Xi_A<=M W and turn the Hardy fee into lambda log(lambda/(epsilon q_-))*M W. A root/polylog source price requires an appropriate actual M, roughly root/polylog divided by lambda for fixed epsilon. The outside gate and external mass availability alone do NOT prove this multiplicity bound. The row normalization by L is legitimate only on active g>0,where L>0; zero contribution elsewhere has its own convention. This assignment is a conditional interface, not an added source payment or a new claimed root theorem.

Alternatively one may prove a quantitative bound directly for actual active proposal overload/loss integrated with d_vdv, or for the complete signed retained-plus-Hardy-minus-capture balance. The weights must be those of ONE common source-dependent plan. There is no permission to give each u a private proposal, apply an unweighted receiver volume bound to f, reuse old capture credit, or count the same external resource as disjoint. The source exactness and target-cap constraints above remain necessary regardless of any hoped-for geometry.

## Actual local arithmetic and status

Reviewer actually ran252 finite Fraction congestion cases. They check active water-level brackets/root, ell=E(H_A-2+ell)+, exact retained/lost masses, uniform-active+free target cap/source total, feasibility minimality against rational candidate losses and ell_general<=ell_uniform. These are scalar finite arrays, not native hard-field geometry or a source-packing estimate. No R378 author proof had been read at that initial screen. Completed author/final review follows; general lost-mass/capture, original entrance/soft/history/scale and limit obligations remain unpaid.

## Additional independent screen: layered partial common plans

The positive construction passes with explicit indexing and genuine finite feasible partial plans. Fix ONE original source probability P and uniform target U for each actual v, same common all-u cost0<=C<=B. Choose thresholds0<tau_0<...<tau_J=B. For j=0,...,J-1 let pi_j be a jointly measurable partial plan with source marginal a_j P,0<=a_j<=1, target<=U, supported on C<=tau_j, and mass1-delta_j. These must be actual constructed plans; delta_j is not merely a dual lower bound or an unproved infinite Hall deficiency.

Set r_-1=1, assign the positive measure r_(j-1)(y)pi_j at layer j, and update r_j=r_(j-1)(1-a_j). Its source is exactly(r_(j-1)-r_j)P; its target<=U since0<=r_prev<=1. Further

R_j:=integral r_j dP <= integral(1-a_j)dP=delta_j.

At FINAL level tau_J=B use the product r_(J-1)P U to complete every remaining source row. There are J partial layers plus ONE product completion, so the full target<=tU with t=J+1. The original joint template price is therefore(t+1)Gamma=(J+2)Gamma, not tGamma. If the indexing instead includes a partial plan at j=J and then another product completion, its count/cap must be increased accordingly. J=0 requires just product completion, cap1. If B<=tau_0 one may directly use product cost<=B<=tau_0 without manufacturing extra layers.

The cost telescopes with the ACTUAL residual masses:

cost<=tau_0+sum_{j=0}^{J-1}(tau_(j+1)-tau_j)R_j
<=tau_0+sum_{j=0}^{J-1}(tau_(j+1)-tau_j)delta_j.

No accumulation of source mass is lost: source contributions telescope exactly to P, while target caps accumulate once per actual layer. With tau_0=epsilon*q_- the first term integrated against d_vdv is at most epsilon*X_q since integral d_vdv<=|E|. The remaining scale-weighted actual Hall/partial-plan losses remain unpaid. A useful parameter count J does not itself budget that sum or the enlarged template fee.

Finite source Boolean atoms and finite dyadic target cells can give a genuine finite max-flow plan and an exact finite Hall deficit, provided every allowed edge is certified to lie in the ACTUAL near-cost relation for almost all source/target points of those atoms/cells. Finite graph feasibility does not assert availability of arbitrary selector cubes. A countable relation may be approximated by specifically constructed finite plans; its infinite optimum/deficiency equality is not supplied by invoking finite Hall alone. In a continuous theorem the whole family must remain jointly measurable in v. Source capacities, cost bounds and target capacities must be those of the same original fields, not different private per-u plans.

This builds a NEW complete common plan. If a previously retained subflow is kept as well, its source/target mass must first be removed and counted; the displayed full-P/full-U statement cannot just be appended to it. A later epsilon0/h allocation must synchronize the enlarged(t+1)Gamma price with all original h-dependent gates and C338. The proof does not fix a desired total eta through a circular unverified choice of J. No old priority, floor or square credit is added to this positive construction.

Reviewer actually ran4096 finite three-layer Fraction cases. They verify filtered source identities, residual mass<=each delta_j, final source exactness,target cap4 for three partial layers plus product, and the exact threshold-telescoping upper cost. These are scalar matrix diagnostics, not native geometry or finite-to-infinite Hall proof. Together with the preceding252 cases the reviewer-local finite count is4348, separate from author/parent execution.

## Initial normalization warning — resolved by the plain-center contract below

Before the author clarified the intended center measure, the initial screen examined an exponential claim against dmu_v=dv/m_v. That mu-capacity statement would be false for arbitrary actual smaller selector R_v in[a,R_u]. The actual AUTHOR theorem was then clarified as plain dv/R_u^n and passes below. The following bounded normalization check is retained to make the distinction explicit, not as a defect in the final theorem or a counterexample to the original hard-budget problem.

Take R_u=2a, actual R_v=a, u=0 and a common source y=(1-epsilon)a e_1 with0<epsilon small. Let v_1 lie in(alpha*a,(3/2-epsilon)a), where the original exterior dilation alpha<3/2-epsilon, and each other v_i lie in[-a/2,a/2]. Then c_u(y)c_v(y)=1, v is outside alpha*Q_u, and EXACTLY one coordinate has positive true protrusion e_i=(2|u_i-v_i|-(R_u-R_v))_+. The other n-1 coordinates have e_i=0. With uniform f on a sufficiently large compact cube the actual m_v=q*a^n, so this set has smaller-center mu-capacity

(3/2-epsilon-alpha)/q,

independently of n, not an exponentially small bound for k>=1. The statement can be made with positive-volume y and center sets. For sufficiently large n, the displayed proposed combinatorial bound with k<=n/8 tends to0 and cannot cover this example. This does NOT assert all original highpast/H/history gates of a complete witness, nor failure of any properly restricted new receipt.

The parent was notified immediately and the normalization was clarified as plain dv/R_u^n, which needs NO extra near-scale gate and is proved/reviewed below. The invalid mu-normalized variant is neither asserted by the final author proof nor entered into the accounting.

## Sparse-face clarification: the intended PLAIN center volume does pass

The parent/author clarified the intended normalized measure as plain dv/R_u^n, NOT dmu_v=dv/m_v. With that contract the sparse-outward receipt independently passes; the preceding warning/example concerns only the unsupported mu-capacity interpretation and is not a defect in the clarified theorem.

For ANY actual source-preserving complete transport tau_v with first marginal mu_v^+ and mass d_v<=1, its positive bad integrand on an actual pair is

(1/h R_u^n)*A_uv integral omega_u(y)c_u(y)(1-c_u(z))dtau_v(y,z).

The inner integral is at most mu_v^+(Q_u)<=I_uv/m_v<=1, independently of any target cap. If this source integral is positive then I_uv=f(Q_u intersect Q_v)>0. Since f is L1, this implies positive-volume cube intersection and each coordinate distance |u_i-v_i|<(R_u+R_v)/2<=R_u. In a NON-outward coordinate, |u_i-v_i|<=(R_u-R_v)/2<=R_u/4 because R_v>=a>=R_u/2. Thus the actual centers with exactly j outward coordinates lie in a union of binom(n,j) boxes with j side lengths2R_u and n-j side lengthsR_u/2. Taking the union over j<=k proves the exact upper capacity

plain_volume/R_u^n <= b_n=2^-n sum_{j=0}^k binom(n,j)4^j.

Accordingly G_sparse<=b_n|E|/h<=epsilon0*b_n*X_q/(1+sqrt(n)). No source density ceiling, per-coordinate independence of f, or small-radius denominator bound is used. This applies to the actual new plan as well as old plans. If a new dense-only common kernel is optimized after this split, the sparse branch must be bounded for THAT same completed plan and the remaining original positive pair restriction retained. It does not justify replacing one older plan's smaller remainder inside a different inequality.

The completed author proof and final full accounting are reviewed below.

## Layered author review

Read /tmp/r378_layered.md in full after the independent screen. PASS for its stated constructive bridge. Its actual dyadic relation uses jointly measurable omission costs, includes source atoms with no edges, and makes every certified rectangle genuinely satisfy C<=tau. Boolean source atoms and finite dyadic target cells give a finite graph with exact P/U capacities. Finite max-flow/min-cut is used only for that graph. A first-feasible-optimal basic-flow selection across finitely many graph patterns/bases is a measurable arithmetic construction; zero-mass cells carry0 flow. Countable depth approximation uses monotone finite relations and the first M with delta_M<=inf delta+rho. It does NOT identify the limiting inner dyadic deficiency with an unproved arbitrary-relation transport optimum, or assert an infinite-dimensional Hall optimizer exists.

The source filtering and cost telescoping agree exactly with the independent screen, including t=J+1 and template(t+1)Gamma. The final product level contributes cost<=barB, not an omitted free source. Its explicit PRE-field choice barB=A_clock*eta*q_-/(2(1+sqrt(n))) and t=1+max(0,ceil log2(barB/(epsilon*q_-))) is noncircular. Subsequent epsilon0=eta/L_(n,t)<=eta/2 indeed gives actual B<=barB. Exact powers of2 do not create duplicate final thresholds. If t=1 the product plan's cost<=epsilon*X is justified; otherwise the actual threshold list and finite per-level plans have the stated count.

The finite-approximation tolerance rho=epsilon'*q_-/barB contributes at most epsilon'*X_q after summing positive level increments and actual d_vdv. Values rho>=1 require no problematic limit. Source-dependent finite depths are measurable and do not add stages beyond t. The source price O_(eta,epsilon)(sqrt(n)log^(3/2)(n+2)) follows from the displayed preallocated t and known Gamma; this price is conditional on still paying the genuine deficiency integral D. The proof explicitly retains that unproved requirement and does not add R377 plan credits to this new complete-plan construction. All h-dependent fields must be regenerated if eta changes. No new primitive proof or arbitrary actual-cube availability is assumed.

## Bounded sparse-geometry author review

Read /tmp/r378_geometry.md and its complete343-check standalone code. PASS for the clarified plain-center receipt, including source matching in(6)-(7). The exact first marginal of tau and total d<=1 consume the1/m_v source normalization BEFORE center volume is used. The source integral vanishes at I_uv=0; no target density/cap is needed for this branch. Non-outward interval widths and possible-intersection outer widths are correct for arbitrary selected smaller radius. Strict equality e_i=0 is not counted; boundary null sets do not alter the plain-volume bound.

The exact exponential rate at parameter1/28 is rho^8=1835008/5764801<1. n<8 has k=0 and its actual original outside branch is empty; this zero improvement is not falsely asserted for the unrestricted geometric union bound. The geometric illustration n>=8 remains explicitly a pair-mask noncontainment check, not a full original highpast witness. Dense complement is exactly j>n/8 together with every old gate. Its high-J/clock/source matching is unchanged; the Hardy theorem applies to its positively restricted kernel with that actual plan's active set and capture. A future larger-cap layer plan still satisfies the source-only sparse receipt, but needs its separately certified template tariff.

The343 Fraction checks split256 exact binomial rates,27 selected-radius center union volumes and60 finite full-source/plan incidence bounds. The finite plan diagnostics do not realize native Lebesgue highpast fields. The reviewer read code without repeating the parent run. The earlier normalization warning is RESOLVED: no mu-center exponential capacity is used by the actual author theorem.

## Bounded active-plan checkpoint and final finite-Hall proof review

Read /tmp/r378_active_plan.md and its complete script. PASS. Its active-water root, source/free completion, fractional atoms and exact gain formula use the genuine active demand alpha. It correctly compares to old R376 at same fields and does not claim a dominance over R377's more flexible refill. Its narrower observation that the new plan can retain the old k is valid with the same priority tie convention: active benefits are strictly positive on near-box support; where old free retention is positive all active proposal has been retained and the active target plus old free retention still fits cap2. Any remaining free source can be completed absolutely continuously. This identifies the restricted route rather than proving a new root price.

The250-probe better/equal/worse record0/194/56 is expressly a bounded prior family, not a dominance theorem or adverse-input research. The3836 default checks use exact finite max-flow/Hall tests and source filtering. At the last full-cost threshold the script uses a full finite matching, rather than necessarily the literal product plan; this is also source exact,target<=U,cost<=B and so validly tests the same finishing lemma. Its count and scope do not pretend to demonstrate native geometry. BFS augmenting paths have finite Edmonds-Karp termination; the proof's independently added compact finite polytope/residual reachable cut argument also establishes the finite max-flow/min-cut identity for arbitrary real capacities without an unsupported augmenting-termination assumption. Both arguments keep source atoms having no edges.

Reread the current parent layered proof's added compactness/cut paragraph: row-target edge capacity2 exceeds total source1, so a reachable row has every graph neighbor reachable, and the residual cut has capacity1-p(I)+u(N(I)). This yields the claimed Hall deficiency exactly. No mathematical correction remains in that finite argument or measurable basis selection. The actual geometric weighted deficiency D remains unbounded in general.

## Bounded numerical geometry/Hall review

Read /tmp/r378_numeric.md and full numeric Python, inspected frozen input/result and critical saved boxes/defects, and compared both provenance hashes against actual R377 input/result bytes. PASS within finite scope. Source matching, full original finite J/past/physical clock and one common all-u C are rebuilt; W=4,4,33/4 and q=1 remain. Receiver integration is quadrature, not actual du. No new MATLAB/LP call is made.

The graph uses ALL complete original target cells, even f=0 cells; active means some positive cost and free means every cost0. Exact zero-cost edges equal the intersection boxes of every positively marked actual cube. Twelve active boxes are checked against120 target-cell incidences and their true positive volumes. There are at most2 active rows in each finite graph, not an assumed general restriction. Exact BFS flow yields feasible partial active transport. All56 source subsets give feasible max-mass upper duals with nonnegative cut prices and an attained42-case primal/cut zero gap. Partial max-zero transport is NOT passed off as a complete source-preserving plan or a cost optimizer.

The original active priority retention is checked as a feasible zero-edge subflow, so its additional zero-retention opportunity is a mass diagnostic, not an earned complete-cost credit. Hall leakage D times the smallest actual positive cost is a correct LOWER bound for every full cap2 plan, because at least D active mass must leave the zero relation. Its exact equality to old feasible/dual cap2 benchmarks in the sample is separately verified. In the2D one-active/two-cost-level cases, physical box volumes3/8,uniform fractions1/6,defects1/9 and23/108,cost levels63/3040 and21/272, and original outer weights3/32 and1/16 give exactly4627/3720960. This explains the entire SAVED2D optimum, not a new general cost-deficiency identity.

The627 grouped Fraction assertions,42 flow/cut certs,56 Hall cuts and10 inherited exact cap2 certs are consistent with saved results and code. Output comparisons preserve absolute costs versus costs/originalG. All old source cells and weights remain; solver status, sampling or floating fits are not used. The reviewer did not duplicate these parent pipelines. Final main/ledger/readme accounting and byte binding are completed below.


## Final integration and complete accounting

Read the frozen final main, ledger and readme and checked them against current layered/geometry/active-plan proofs and scripts. PASS. The new full-f h-dependent field is built only AFTER choosing barB and t; actual m/q/J/H/past and physical clock remain the original ones on that field. The dense kernel is a positive restriction of the original all-u cost. Its dyadic common plans have source EXACTLY d_vP_v and target<=t*d_vU_v. The same completed plan is then used for the full sparse+dense split. The sparse estimate uses source exactness only, so it continues to apply to that enlarged-cap plan. The original floor+good template is(t+1)Gamma, not a cap2 tariff or a saved old plan credit. No old R377 M1 capture/priority/variance credit is added to the new layered cost.

The preallocated barB,t,subsequent epsilon0=eta/L_(n,t) and h imply actual B<=barB. Finite-depth approximation adds at most epsilon'*X_q. Hence

B_H<=D_dense+(eta+sigma_n+epsilon+epsilon')X_q+C338*W,
sigma_n=epsilon0*bhat_n/(1+sqrt(n)),

is valid. The exact binomial bound gives bhat_n<=1, and epsilon0<=eta/2 implies sigma_n<=eta/2. Therefore the stated choice eta=epsilon=epsilon'=kappa/(7Lambda) makes2Lambda(eta+sigma_n+epsilon+epsilon')<=kappa. It budgets this slot only. Changing eta changes the entire h-dependent field and C338; fixed data from an earlier h cannot be reused as if unchanged. Source price O_(eta,epsilon)(sqrt(n)log^(3/2)(n+2))*W is proved for the explicitly stated tariff, NOT for the unpaid D_dense.

Original entrance terms8lambda H W,2d_eff A_clock Wnu/H,entrance factor2,outer Lambda=128/119 remain. The dense actual shared-union deficiency integral and all source weights/threshold increments remain explicit. The sourcewise sparse branch is genuinely paid without a new W fee; no fixed positive fraction of a general input is asserted. Dense protrusion count alone does not force deep faces or exponentially small overlap. No finite diagnostic is used as a general model upper bound.

Unpaid obligations are D_dense's general root-order source budget (or the alternative actual dense lost-source/capture balance), original H entrance/optimization and soft/crossing/entry interfaces, contract-external tails/scales/threshold complements, historical initial/deletion/future-source time atoms, full source/physical-scale aggregation, outer integration, truncation and limits. Physical terminal atoms do not substitute for historical atoms. This audit does not re-audit every historic reduction or prove all other receiver coefficients can be absorbed.

Execution scopes stay separate: parent reports fresh geometry343 Fraction checks; active/layered3836 grouped Fraction checks on137 finite inputs; numeric627 exact grouped checks; and replay of the PRE-EXISTING250 active-water cases giving0/194/56. No new MATLAB/LP call occurred. Reviewer actually ran4348 finite scalar Fraction cases (252 congestion plus4096 layered filters), separate from those parent counts; no complete parent pipeline was duplicated. Actual source-cell volumes, exact inherited cap2 primal/dual certs, and finite receiver quadrature are distinguished throughout. The finite Hall cost explanation is a proved statement about the three frozen diagnostics, not native high-dimensional hard-gate or asymptotic evidence.

Final decision: PASS for the intended plain-center sparse payment, explicit measurable finite-dyadic multilayer construction, exact finite Hall certificates, bounded active-route stopping report and synchronized complete accounting. The initial mu-normalization question is resolved and is NOT a final defect. No outstanding correction within this bounded review. General arbitrary-input root closure remains open in D_dense and the other retained original slots.

## Final SHA256 bindings

These hashes bind the reviewed final bytes and necessary dependencies. Later mathematical changes require re-audit. Later generated TeX/PDF layout is not certified by this binding.

```text
e8990006ae1607d464462c9403b931e725321ffa7099a613619af8484ac59c81  /tmp/r378_main.md
7430c541648750d8734765e3e2554da72786cb9be7107660aeb757cf24850ef3  /tmp/r378_ledger.md
b4f36cfcdabca12cd8ca4d1db93025bf0d312545e42beaf524461aeecf17d99d  /tmp/r378_readme.md
8d7f0361b15108b014b9fb7ddc8c124e17f268a2ba98ff7bb8ab2489b188e24d  /tmp/r378_layered.md
f7c5342956723a49374dc0e0f631e8c283cbb2ec59f5a26c5dec5e0d287276c3  /tmp/r378_geometry.md
332fc75ce7aff3270ea33df1c495e09c9d0f146382c81504aacf490152a30680  /tmp/r378_geometry_check.py
a92a0173ca2b88e3b3789a17a39c7af361551de24fd05f9ad7cb2ca1b09c3719  /tmp/r378_active_plan.md
12293ec19c0d15dd75a3f06d9a3e96dfad15a90bfb8649fc61b9eedaf7d2bfb3  /tmp/r378_active_plan_check.py
16effdd0e04ebb9e43dd7a6628b285682c4d50a1a3bd43095e48f0a9771c226e  /tmp/r378_numeric.md
e2f0777093471dd14bf67ca87de1db448cdb2d7b74c1f485c1a506a75a12197a  /tmp/r378_numeric.py
ed06de678d0842b1b133fdd4aafb3380e34d5e6d74705bf70cb3fbe1caa69055  /tmp/r378_numeric_input.json
9b219233d3f5409ae230e64e976c9905e90d1d9f2f6069f96186d28b09a1218c  /tmp/r378_numeric_result.json
c82863118784b72fc450100a4bcfedb8ed85432373f2f91fcf2431021ab9371e  /tmp/r377_main.md
3a4122195001d3a0587fff057dbc273ad25920ea71726688feb650b9c154e244  /tmp/r377_ledger.md
f1faeb18a1b89b9831838a046f3647bdd17303d148532071c61df51f66586e09  /tmp/r377_audit.md
169bf35d301375bd249c5b1015a6f6020ac11070f37ecdeedf273ef65288a838  /tmp/r377_refill.md
16b083e57cd84fe7d3b8b9a077d2211941e7efd340d3bf3bc7fdb0fcaa85a29d  /tmp/r377_geometry.md
09203e06b2352b8d096e9b7ffa0a5ebe8fa9626bb960456dda6e082e4305cd71  /tmp/r377_numeric_input.json
53ec523917036edf4f783bd60a65c32af65abd9bbcd08827c5e5d1c7e4feb9a0  /tmp/r377_numeric_result.json
16c68acce633ca7df17e8f2506fbc31c4aa00495b89200c84b745289e5b3caa7  /tmp/r376_geometry.md
28863cfe9c3636eeb4bea6003f90f30b15f2f3acb308aebf901aceaa0f564d02  /tmp/r376_ledger.md
b703ec31eee5018d417b115ec7642b9768c91f72472077a0c23460ae27431502  /tmp/r375_geometry.md
3c432638efddd308e7f433ac079ebd539e587e7a899994aad8eb83ebd81df8c5  /tmp/r375_capacity.md
fac02a43e18ed5dc3d5be7ef67a8ac9e34cbd4dd1e69912d6e29dffda597d81a  /tmp/r370_geometry.md
```
