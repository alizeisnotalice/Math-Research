from fractions import Fraction as F
from itertools import product
from collections import deque
import sys

# Replay of the already executed 250-profile active-water diagnostic.
def water(U,H,lower=F(1)):
    cuts=sorted(set([lower,F(2)]+[x for x in H if lower<x<2]))
    for lo,hi in zip(cuts,cuts[1:]):
        low=sum(w for w,x in zip(U,H) if x<=lo)
        high=sum(w*x for w,x in zip(U,H) if x>lo)
        if low:
            a=(2-high)/low
            if lo<=a<=hi:return a
    return F(2)

def take(weights,bounds,score,mass):
    left=mass;k=[F(0)]*len(weights)
    for val in sorted(set(score),reverse=True):
        ids=[i for i,x in enumerate(score) if x==val]
        cap=sum(weights[i]*bounds[i] for i in ids)
        fac=min(F(1),left/cap) if cap else F(0)
        for i in ids:k[i]=fac*bounds[i]
        left-=fac*cap
    assert left==0
    return k

def probe_costs(P,U,K):
    nr,nc=len(P),len(U)
    L=list(map(max,K));r=[sum(u*x for u,x in zip(U,row)) for row in K]
    g=[L[i]-r[i] for i in range(nr)]
    C=[[L[i]-x for x in K[i]] for i in range(nr)];active=[x>0 for x in g]
    prop=[]
    for i in range(nr):
        mask=[c<=g[i]/2 for c in C[i]]
        vol=sum(u for u,b in zip(U,mask) if b)
        prop.append([F(int(b))/vol for b in mask])
    def retain(H,a,activeonly):
        k=[[F(0)]*nc for _ in range(nr)]
        for j in range(nc):
            col=take(P,[prop[i][j] if active[i] or not activeonly else F(0) for i in range(nr)],
                     [K[i][j]-r[i] for i in range(nr)],min(H[j],a))
            for i in range(nr):k[i][j]=col[i]
        return k
    H=[sum(P[i]*prop[i][j] for i in range(nr)) for j in range(nc)]
    a=water(U,H);k=retain(H,a,False)
    beta=[1-sum(U[j]*k[i][j] for j in range(nc)) for i in range(nr)]
    delta=sum(P[i]*beta[i] for i in range(nr))
    slack=[2-sum(P[i]*k[i][j] for i in range(nr)) for j in range(nc)]
    old=sum(P[i]*U[j]*k[i][j]*C[i][j] for i in range(nr) for j in range(nc))
    da=sum(P[i]*beta[i] for i in range(nr) if active[i])
    if da:
        sig=[U[j]*slack[j]/(1+delta) for j in range(nc)]
        for i in range(nr):
            if active[i]:
                q=take(sig,[(1+delta)/da]*nc,K[i],F(1))
                old+=P[i]*beta[i]*sum(sig[j]*q[j]*C[i][j] for j in range(nc))
    alpha=sum(P[i] for i in range(nr) if active[i])
    HA=[sum(P[i]*prop[i][j] for i in range(nr) if active[i]) for j in range(nc)]
    aa=water(U,HA,2-alpha);ka=retain(HA,aa,True)
    new=sum(P[i]*(sum(U[j]*ka[i][j]*C[i][j] for j in range(nc))+
        (1-sum(U[j]*ka[i][j] for j in range(nc)))*g[i]) for i in range(nr) if active[i])
    return old,new

def replay_probe():
    counts=[0,0,0]
    P=[F(1,3)]*3;U=[F(1,10),F(1,5),F(3,10),F(2,5)]
    for seed in range(250):
        K=[[F((seed*(i+1)+j*j+3*i*j+2*i)%9,8) for j in range(4)]
           for i in range(2)]+[[F(0)]*4]
        old,new=probe_costs(P,U,K)
        counts[(new>old)-(new<old)+1]+=1
    print('Original 250 probe replay: [better,equal,worse] =',counts)

# Exact finite partial-plan construction, independently certified by all Hall cuts.
def partial(P,U,C,tau):
    nr,nc=len(P),len(U);N=nr+nc+2;source=N-2;sink=N-1
    cap=[[F(0)]*N for _ in range(N)]
    for i,p in enumerate(P):cap[source][i]=p
    for j,u in enumerate(U):cap[nr+j][sink]=u
    for i in range(nr):
        for j in range(nc):
            if C[i][j]<=tau:cap[i][nr+j]=F(1)
    initial=[row[:] for row in cap]
    while True:
        prev=[-1]*N;prev[source]=source;todo=deque([source])
        while todo and prev[sink]<0:
            x=todo.popleft()
            for y in range(N):
                if prev[y]<0 and cap[x][y]>0:prev[y]=x;todo.append(y)
        if prev[sink]<0:break
        x=sink;aug=F(1)
        while x!=source:aug=min(aug,cap[prev[x]][x]);x=prev[x]
        x=sink
        while x!=source:
            y=prev[x];cap[y][x]-=aug;cap[x][y]+=aug;x=y
    flow=[[initial[i][nr+j]-cap[i][nr+j] for j in range(nc)] for i in range(nr)]
    deficit=1-sum(map(sum,flow))
    hall=F(0)
    for bits in product((0,1),repeat=nr):
        ids=[i for i,b in enumerate(bits) if b]
        neigh=[j for j in range(nc) if any(C[i][j]<=tau for i in ids)]
        hall=max(hall,sum(P[i] for i in ids)-sum(U[j] for j in neigh))
    assert deficit==hall
    return flow,deficit

def test_layers(P,U,C):
    thresholds=[F(1,8),F(1,4),F(1,2),F(1)]
    nr,nc=len(P),len(U);remaining=[F(1)]*nr
    total=[[F(0)]*nc for _ in range(nr)]
    rem=[];deficits=[];assigned=[];assertions=0
    for tau in thresholds:
        pi,deficit=partial(P,U,C,tau)
        assert all(sum(row)<=P[i] for i,row in enumerate(pi))
        assert all(sum(pi[i][j] for i in range(nr))<=U[j] for j in range(nc))
        assert all(pi[i][j]==0 or C[i][j]<=tau for i in range(nr) for j in range(nc))
        filtered=[[remaining[i]*pi[i][j] for j in range(nc)] for i in range(nr)]
        for i in range(nr):
            for j in range(nc):total[i][j]+=filtered[i][j]
        remaining=[remaining[i]*(1-sum(pi[i])/P[i]) for i in range(nr)]
        r=sum(P[i]*remaining[i] for i in range(nr))
        assert all(0<=x<=1 for x in remaining) and r<=deficit
        assert all(sum(filtered[i][j] for i in range(nr))<=U[j] for j in range(nc))
        rem.append(r);deficits.append(deficit);assigned.append(sum(map(sum,filtered)))
        assertions+=6 # includes the exact all-subset Hall check in partial
    assert rem[-1]==0
    assert all(sum(total[i])==P[i] for i in range(nr))
    assert all(sum(total[i][j] for i in range(nr))<=len(thresholds)*U[j] for j in range(nc))
    exact=sum(Pi*Cij for row,cost in zip(total,C) for Pi,Cij in zip(row,cost))
    tau_bill=sum(t*m for t,m in zip(thresholds,assigned))
    telescoping=thresholds[0]+sum((thresholds[j+1]-thresholds[j])*rem[j] for j in range(3))
    hall_bill=thresholds[0]+sum((thresholds[j+1]-thresholds[j])*deficits[j] for j in range(3))
    assert exact<=tau_bill==telescoping<=hall_bill
    return assertions+4

def run_checks():
    counts=[0,0,0]
    P=[F(1,3),F(2,3)];U=[F(1,6),F(1,3),F(1,2)]
    fixtures=[[[F(0)]*3]*2,[[F(1)]*3]*2,
              [[F(0),F(1),F(1)],[F(1),F(0),F(1)]],
              [[F(1,8),F(1,4),F(1,2)],[F(1),F(1,2),F(0)]]]
    for C in fixtures:counts[0]+=test_layers(P,U,C)
    for raw in list(product((F(0),F(1,2),F(1)),repeat=6))[:36]:
        counts[1]+=test_layers(P,U,[list(raw[:3]),list(raw[3:])])
    P3=[F(1,6),F(1,3),F(1,2)];U4=[F(1,10),F(1,5),F(3,10),F(2,5)]
    for seed in range(97):
        C=[[F((seed*(i+1)+j*j+3*i*j+2*i)%9,8) for j in range(4)] for i in range(3)]
        counts[2]+=test_layers(P3,U4,C)
    print('Partial-plan three-stage PASS:',counts,'total',sum(counts),'finite inputs',4+36+97)

if __name__=='__main__':
    if '--replay-probe' in sys.argv:replay_probe()
    else:run_checks()
