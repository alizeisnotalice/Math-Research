from fractions import Fraction as F
from math import comb
from itertools import product
counts={'binomial_rate':0,'selector_center_union':0,'plan_capacity_payment':0}
rho8=F(4**8*28,7**8)
assert rho8==F(1835008,5764801)<1
for n in range(1,257):
    k=n//8
    b=sum((F(comb(n,j)*4**j,2**n) for j in range(k+1)),F(0))
    assert b**8<=rho8**n
    if n<8: assert b==F(1,2**n)
    counts['binomial_rate']+=1
# Exact center-volume of the union over a finite radius menu.
# This union dominates every selector from that menu; a=1, Ru<=2.
for dim in (1,2,3):
 for R,menu in ((F(5,4),[F(1)]),
                (F(3,2),[F(1),F(5,4)]),
                (F(2),[F(1),F(5,4),F(3,2),F(7,4)])):
  cuts=sorted({F(0),R}|{(R-s)/2 for s in menu}|{(R+s)/2 for s in menu})
  cells=[((cuts[i]+cuts[i+1])/2,cuts[i+1]-cuts[i]) for i in range(len(cuts)-1)]
  for k in range(dim+1):
   volume=F(0)
   for box in product(cells,repeat=dim):
    point=[x[0] for x in box]
    accepted=any(all(2*x<R+s for x in point)
                 and sum(2*x>R-s for x in point)<=k for s in menu)
    if accepted:
     vol=F(1)
     for _,width in box:vol*=width
     volume+=2**dim*vol
   bound=R**dim*sum(F(comb(dim,j)*4**j,2**dim) for j in range(k+1))
   assert volume<=bound
   counts['selector_center_union']+=1
# Exact full-f/source-marginal algebra for the center-cap payment.
# Finite quadrature; not claimed to be a native high-past Lebesgue field.
for seed in range(60):
 f=[F(1+(j*3+seed)%9,3) for j in range(8)]
 dy=[F(1,4)]*8
 intervals=[(0,2),(1,4),(2,6),(0,6),(1,8),(0,8)]
 c=[[int(lo<=j<hi) for j in range(8)] for lo,hi in intervals]
 R=[sum(dy[j]*c[i][j] for j in range(8)) for i in range(6)]
 m=[sum(f[j]*dy[j]*c[i][j] for j in range(8)) for i in range(6)]
 q=[m[i]/R[i] for i in range(6)]
 du=[F(1+(i+seed)%4,7) for i in range(6)]
 h=F(2); total=F(0); cap_bound=F(0)
 plans=[]
 for v in range(6):
  U=[dy[z]*c[v][z]/R[v] for z in range(8)]
  src=[dy[y]*c[v][y]*max(f[y]-q[v],F(0))/m[v] for y in range(8)]
  d=sum(src)
  anchor=(v+seed)%6
  r=sum(U[z]*c[anchor][z] for z in range(8))
  plan=[[src[y]*U[z]*(1+F((y+seed)%3,2)*(c[anchor][z]-r))
         for z in range(8)] for y in range(8)]
  assert all(sum(row)==src[y] for y,row in enumerate(plan))
  assert all(sum(plan[y][z] for y in range(8))<=2*d*U[z] for z in range(8))
  plans.append(plan)
 for u in range(6):
  V=F(0)
  for v in range(6):
   mask=m[u]>F(3,2)*m[v] and R[u]>R[v] and (u+v+seed)%3!=0
   if not mask:continue
   overlap=sum(f[y]*dy[y]*c[u][y]*c[v][y] for y in range(8))
   if overlap==0:continue
   V+=du[v]
   A=1-m[v]/m[u]
   term=sum(plans[v][y][z]*F((u+y+seed)%5,4)*c[u][y]*(1-c[u][z])
            for y in range(8) for z in range(8))
   assert term<=overlap/m[v]<=1
   total+=du[u]*du[v]*A*term/(h*R[u])
  cap_bound+=du[u]*V/(h*R[u])
 assert 0<=total<=cap_bound
 counts['plan_capacity_payment']+=1
print('PASS',counts,'total',sum(counts.values()))
