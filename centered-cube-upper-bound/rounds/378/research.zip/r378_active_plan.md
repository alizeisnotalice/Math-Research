# R378 — Bounded active-water checkpoint and partial-plan layer audit

This note stops the narrow active-water route at an accurate comparison. It does not claim a new root payment. Its second part independently verifies the parent's proposed finite partial-plan construction, including the source filter and full template count.

## 1. Direct active-only water level

Freeze the original actual P_v,U_v,K_v,L_v,C_v=L_v−K_v and all full-f masses, actual receiver du, original source marks, J/past and clock. Suppress v. Let g(y)=E_UC(y,·), A={g>0}, α=P(A), and F=A^c. On F the nonnegative C is zero U-almost everywhere. Construct the existing measurable near-box proposal only on A, with row integral one and C≤ξg there, 0<ξ<1. Put

\[
 H_A(z)=\int_A\rho^0(y,z)P(dy),\qquad E_UH_A=\alpha.
\]

There is a unique a_A∈[2−α,2] satisfying

\[
 a_A+E_U(H_A-a_A)_+=2. \tag{1}
\]

For α>0 the lower endpoint is strict: E_Umin(H_A,2−α)>0. The same continuous, increasing, parameter-measurable water-level argument as R376 applies; α=0 is treated directly with a_A=2 and the original zero-cost source sent to U. Infinite H_A lies in a U-null set and is handled as in R376.

At each target z retain mass min(H_A(z),a_A), prioritizing b(y,z)=g(y)−C(y,z)≥0 under the active proposal source measure. Fractionally fill its threshold atom, including the zero-benefit level if needed. This produces measurable 0≤k_A≤1_Aρ^0, with

\[
 R_A(z)=E_Pk_A=\min(H_A(z),a_A),\quad
 \beta_A(y)=1-E_Uk_A(y,\cdot)\ (y\in A),\quad
 \boxed{\delta_A=\int_A\beta_AP=E_U(H_A-a_A)_+=2-a_A.} \tag{2}
\]

Thus the lost mass is precisely an excess of **active proposal demand**, with no free-source proposal occupancy in it. Complete the active source by its rowwise uniform refill β_AU. The active target is R_A+δ_A≤2. Its remaining capacity is

\[
 S(z)=2-R_A(z)-\delta_A=a_A-R_A(z)\ge0,\quad E_US=2-\alpha.
\]

Send every free source row to S U/(2−α). The free target is (1−α)S/(2−α)≤S and its cost is zero. This preserves the exact whole P source marginal and target≤2U. Multiply by the original surplus factor d_v and integrate actual dv for the original plan. Its floor/good price remains the same 3Γ_n template, not an extra charge.

Let T_z(s)=∫_Aρ^0(y,z)1_{b(y,z)>s}P(dy). The exact bad cost is

\[
 G_A=E_Pg-\int U(dz)\int_0^B\min(a_A,T_z(s))ds. \tag{3}
\]

This is optimal within active proposal subflows with **uniform active refill**, followed by arbitrary zero-cost free completion. Indeed, for any such retained subflow of total mass T≤α, its retained target R must satisfy R≤2−α+T. Also R≤H_A, so with a'=2−α+T,

\[
 a'+E_U(H_A-a')_+\le2,
\]

and hence a'≤a_A. The columnwise priority reward is therefore an attainable upper bound for that class. This is the same direct layer-cake argument as R376, with the genuine active demand replacing total proposal occupancy.

Compared with R376's all-source proposal plus uniform refill, H_A≤H_full gives a_A≥a_full, and all free proposal benefit is zero. Columnwise priority therefore proves G_A≤G_R376 at identical template fee. It does **not** prove G_A≤G_R377, because R377 nonuniform refill can exploit target choices excluded by the new uniform-active-refill restriction. The exact comparison is between the entire costs (3) and the old retained cost plus its actual R377 refill cost; the two gains cannot be mixed. No uniform quantitative improvement is inferred.

A limited structural observation further narrows the novelty. On a column where old R376 retained free mass is positive, all active proposal mass has already been retained (active benefits are strictly positive on the near-box support). There H_A<a_full; the new active-only retained part is the same full active proposal there. Adding its new uniform active refill and keeping the old retained free mass costs at most a_full+δ_A≤2. On columns with no old retained free mass the new active plan is already within cap two. Thus the new active plan can be completed while retaining the old k, if arbitrary common refill is allowed. It need not lie inside R377's stronger proportional row-cap subclass. This construction is consequently not evidence of a gain beyond an optimal arbitrary fixed-k refill.

## 2. Already executed finite diagnostic and stopping decision

The bounded 250-profile diagnostic uses P=(1/3,1/3,1/3), U=(1/10,1/5,3/10,2/5), two specified nonconstant kernel rows and one zero-cost row. It compares the exact R377 free-buffer cost with (3), using the same proposal, kernel and source weights. All arithmetic is Fraction arithmetic. The actual result, replayed without expanding the input range, is:

- direct active-water strictly better: 0;
- equal: 194;
- strictly worse: 56.

This finite evidence is neither a theorem of dominance nor a native hard-field realization. It supports stopping this narrow route rather than packaging its elementary change of demand as a general new payment. The exact original range and formulas are saved in the companion script's `--replay-probe` mode; no new adverse-input search is undertaken.

## 3. Independent audit of the parent's multilevel partial-plan construction

Here the reference probabilities P,U and full original C∈[0,B] stay frozen. Let 0≤τ_0≤...≤τ_J=B. For each j choose an actual jointly measurable partial plan π_j satisfying

\[
 (\pi_j)_Y=p_jP\le P,\quad (\pi_j)_Z\le U,\quad
 C\le\tau_j\quad\pi_j\text{-a.e.},\quad
 \pi_j(Y\times Z)=1-\delta_j. \tag{4}
\]

No row-normalization of p_j is made. Set r_{-1}=1 and use the positive filtered plan

\[
 \widetilde\pi_j(dy,dz)=r_{j-1}(y)\pi_j(dy,dz),\qquad
 r_j=r_{j-1}(1-p_j). \tag{5}
\]

By induction 0≤r_j≤1. Each layer's target is still at most U, and its source is exactly the mass removed from r_{j-1}P. Write R_j=∫r_jdP. Then

\[
 \boxed{R_j\le\int(1-p_j)dP=\delta_j.} \tag{6}
\]

No independence, nesting of relations, or source reset is used. For the last layer choose π_J=P⊗U (legal because C≤B), so r_J=0. The sum of the filtered plans has exact source P and target≤(J+1)U. Its complete cost satisfies the exact layer-bill identity

\[
 \begin{aligned}
 \int C\,d\sum_j\widetilde\pi_j
 &\le\sum_{j=0}^J\tau_j(R_{j-1}-R_j)\\
 &=\tau_0+\sum_{j=0}^{J-1}(\tau_{j+1}-\tau_j)R_j\\
 &\le\boxed{\tau_0+\sum_{j=0}^{J-1}(\tau_{j+1}-\tau_j)\delta_j}.
 \end{aligned} \tag{7}
\]

Thus the direction of the proposed filtering and every telescoping term are correct. For a doubling schedule, J≤ceil(log_2(B/τ_0)) when B>τ_0; if B≤τ_0 a single full product layer suffices. There are J+1 target charges, so the original floor plus good template has coarse coefficient **J+2**, not J+1. All original common marks and actual dv remain in each plan's cost before any positive bound.

For τ_0=ζq_-, the integrated first term is

\[
 \tau_0\int_Ed_vdv\le\zeta X_q.
\]

The weighted defect term in (7) is still unpaid until the actual geometric relations supply a bound for it. The O(log n) stage count requires the synchronized bound on B/τ_0 in the chosen original parameters; it cannot be asserted for an arbitrary unsynchronized tiny τ_0. The corresponding Γ price and ε_0-dependent source fee must be rebuilt together.

### Finite relations and precise history scope

For a finite source/target partition with actual allowed rectangles, maximal partial mass is certified by the finite network flow and its Hall cuts. Thus δ_j is a finite, verifiable source-demand defect. Multiplication by r_{j-1} in (5) preserves that source/target relation even when r varies inside source cells. Countably many actual dyadic near-capture rectangles can be approximated by finite unions; one must retain the deficits of those chosen finite relations or prove the relevant limit. The proof does not assume an arbitrary measurable sublevel {C≤τ_j} is a union of allowed rectangles, and invokes no infinite-dimensional attainment theorem.

A targeted check of R375 geometry, R376 priority and R377 refill found the earlier Hall-capacity discussion and feasible truncation/refill plans, but not (5)–(7). This is not a full-history novelty certification. The algebraic filtering/telescoping itself is elementary; any substantive new global payment would come from the actual geometric bound for the defect term, not from renaming that term.

## 4. Three-stage finite exact verification

Companion script: `/tmp/r378_active_plan_check.py`.

The default mode constructs rational maximum partial transports on finite allowed-cell relations, independently checks every source-subset Hall deficit, then performs the exact current-source-density filtering (5). It verifies support cost thresholds, both marginals, the terminal full match, target layer count, the telescoping identity and the final deficit bound. Thresholds are 1/8,1/4,1/2,1; these finite arithmetic kernels are not claimed to be native high-past fields.

Actual execution: **PASS [112,1008,2716], total 3836 grouped assertions on 137 inputs** (four boundary inputs, 36 two-by-three inputs, 97 three-by-four inputs). Replay of the pre-existing 250 active-water probes returns exactly **[0,194,56]** for better/equal/worse. No general root conclusion follows from either check set.

## 5. Final independent read of the parent layered proof

The complete `/tmp/r378_layered.md` was read after the checks above. No mathematical error was found in the finite dyadic construction or noncircular parameter allocation. In particular:

- The certified rectangles use the actual omission measure. Boolean source atoms and depth-M target cells give a genuine finite relation; refining M preserves all old feasible edges/plans. The finite LP-basis selection, zero-mass conventions, countable infimum δ_∞ and least admissible finite depth are measurable. No arbitrary sublevel-rectangle decomposition is assumed.
- Choosing Bbar and t first, then ε_0=η/L_(n,t), gives ε_0≤η/2 and hence B=A_n/h≤Bbar. The single-layer case and exact-power-of-two endpoint have the correct counts, with no duplicate last level. The finite-depth error is at most Bbar·ρ∫d_vdv≤ε'X_q, including ρ≥1.
- The target count t, floor-plus-good coefficient t+1, and the resulting C338=O_(η,ε)(√n log^(3/2)(n+2)) source fee are consistent. The geometric weighted deficit remains expressly unpaid.

The finite LP-basis argument already suffices for measurable plan selection. If using the alternative augmenting algorithm wording, specifying breadth-first Edmonds–Karp makes finite termination for arbitrary real capacities explicit. This is a wording clarification, not a gap in the existing LP-basis proof.

No new computation or enlarged input range was used for this final read. The saved 3836-check script and its previous counts are unchanged.
