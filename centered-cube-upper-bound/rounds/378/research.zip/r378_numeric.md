# R378 — real zero-loss geometry, maximum active retention, and Hall defects

## Decision evidence

The 2D cap2 remainder is explained **exactly** by a geometric Hall deficit in this frozen field. It is not merely a failure of the explicit refill algorithm: the active source masses exceed twice the uniform target capacity of their true zero-loss intersection boxes. The original positive costs on the forced leakage multiply these defects to give exactly the independently certified all-cap2 remainder.

The two 1D fields have zero Hall defects, consistent with their certified zero all-cap2 cost. Their old priority retention still left some active source unretained, so zero-flow geometry also identifies the extra mass available before unavoidable leakage.

These are source/target continuum cell integrals with finite receiver quadrature and fixed diagnostic marks. No native hard-field, general dimension rate or universal source-density assertion follows.

## Complete frozen input and scale

The same R377 fields are preserved: actual compact piecewise-constant L1 source f, all receiver matching m_u=R_u^n and q_u=1, every actual cube, source labels, full original finite ω/J/strict-past masks and physical clock including its terminal atom. Source masses remain 4,4,33/4. The first two cases have 15 receiver intervals and 16 full source cells; the expanded case has 12 cubes and 208 full 2D cells. Receiver weights are finite quadrature, not dx.

The script rederives the original full marks and common all-u cost C_v(y,z)=L_v(y)−K_v(y,z). It does not replace the source by point masses or arbitrary indicators. Original complete target cells inside Q_v are all retained, including those where f=0. Source rows have actual μ_v^+ mass r_i; d_v=Σr_i and U_v is actual uniform target volume.

A source row is **active** if some C_ij>0, and free only if every C_ij=0. Among the 42 v, ten are nontrivial: four, four, two in the stages. Their active source-row counts are (1,2,1,1), (1,2,1,1), and (1,1). Thus each Hall optimization has at most two active rows. No new MATLAB or numerical LP call is necessary.

## Exact max-flow and finite optimality certificate

For active rows only, build zero-loss edges i→j iff C_ij=0. The exact rational network has source capacities r_i, target capacities b_j=2d_vU_j, and sufficiently large zero-edge capacity. Standard-library Fraction augmenting paths produce a feasible partial transport, with no sampling or floating comparison.

All subsets I of active rows are also enumerated. Let N(I) be their complete zero-target neighbor union. The Hall defect is

    D=max_I [Σ_{i∈I}r_i − 2d_v U_v(N(I))] ≥0.

The empty subset is included, and closed cell boundaries are null. Any zero transport has mass at most active_mass−D. The cut is also an explicit weak-dual certificate: source prices α_i=0 on I and 1 outside, target prices β_j=1 on N(I) and 0 outside obey α_i+β_j≥1 on every zero edge. The returned partial flow attains that exact upper bound for each v. All 42 flow/cut gaps are zero, including 32 trivial no-active cases. Across them there are only 56 Hall subsets.

For each active source row, the code independently constructs the actual box

    C0_i=Q_v ∩ ⋂_{u:original positive marked contribution} Q_u.

It checks each target cell's box membership against C_ij=0, computes the actual Euclidean volume, and compares its normalized volume with Σ_{C_ij=0}U_j. All twelve active rows have positive zero boxes. Thus the graph edges are the complete real intersection geometry, not chosen favorable target subsets.

A maximum-zero partial transport does **not** reserve capacity for uniform refill of its missing rows. We do not call it a whole-plan construction or substitute its retained mass for a complete cost. Full-cost upper values are inherited from and exactly rechecked against R375/R377's existing feasible cap2 plans and duals.

## New 2D geometric calculation

Both nontrivial small receivers have side 3/2 and volume 9/4. Their complete zero boxes each have physical volume 3/8, so U_v(C0)=1/6.

| v (zero-based) | True zero box | d_v | Active μ+ mass | Cap2 zero-target capacity | Hall defect | Positive original C outside zero box |
|---|---|---:|---:|---:|---:|---:|
| 1 | [−1/4,0]×[−3/4,3/4] | 11/12 | 5/12 | 11/36 | 1/9 | 63/3040 |
| 7 | [0,1/4]×[−3/4,3/4] | 17/18 | 19/36 | 17/54 | 23/108 | 21/272 |

These are not point-source artifacts. The first active source cell is [−1/4,0]×[−1/2,−1/4], volume 1/16, actual f mass 1 and density 16. The second is [0,1/4]×[−3/4,−1/2], volume 1/16, mass 5/4 and density 20. Their actual surplus masses, divided by m_v=9/4, give 5/12 and 19/36.

Each has one active row and only two cost levels: zero on the displayed box and the displayed constant positive cost elsewhere. Any full cap2 coupling must send at least D active mass to positive cost. Hence its bad cost is at least cD. The previously certified full cap2 optimum attains this lower bound:

    v=1: (63/3040)(1/9)=7/3040,
    v=7: (21/272)(23/108)=161/9792.

Keeping original receiver weights 3/32 and 1/16,

    (3/32)(7/3040)+(1/16)(161/9792)=4627/3720960.

This is exactly the complete 2D all-cap2 bad remainder, namely 661/1884 of original G=1099/310080. It therefore supplies a precise geometric explanation of **all** of that sample remainder. It does not claim every Hall defect determines a cost in general; the constant positive layer is used explicitly.

## Comparison with old priority retention

The following masses are summed over v with their original quadrature weights. They are diagnostic sums, not a new global source mass or source budget.

| Field | Active mass | Max zero retention | Hall defect | Old priority active retention | Additional zero retention available |
|---|---:|---:|---:|---:|---:|
| Equal 1D | 13/96 | 13/96 | 0 | 749/5760 | 31/5760 |
| Weighted 1D | 17/96 | 17/96 | 0 | 197/1152 | 7/1152 |
| 2D | 83/1152 | 167/3456 | 41/1728 | 79/1920 | 31/4320 |

Every old priority active retention is checked feasible on the zero-edge graph, hence cannot exceed the maximum. In 2D its active loss is 89/2880; part is avoidable by adding zero retention, while the Hall part 41/1728 is unavoidable under cap2. In 1D no geometric zero-target bottleneck remains. The complete uniform-refill and optimal-refill costs remain those of R376/R377; mass differences alone are not charged as costs.

The next decision supported by this computation is specific: after the refill gap is removed, the surviving 2D obstruction is actual zero-target capacity versus concentrated surplus demand. Further tuning of an algorithm at unchanged target cap cannot remove that certified cost. Changing cap, source decomposition or the priced treatment of forced positive-cost leakage is a different question; no general solution is inferred here.

## Actual execution and reproduction

The local standard-library script ran twice in fresh Python processes, passing **627 exact grouped assertions**. They include 42 primal/cut zero-gap certificates, 56 feasible Hall cuts, 12 positive geometric zero boxes with 120 exact cell-incidence comparisons, full original mark reconstruction, and ten inherited full cap2 plan/dual revalidations. These are not 627 independent optimization experiments. There are no floating tests, no new solver candidates and no reused LP reruns.

Standalone files: `r378_numeric.py`, `r378_numeric_input.json`, `r378_numeric_result.json`, and these notes. Run:

    /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r378_numeric.py

The input snapshot includes all source/receiver cells, frozen fields and inherited cap2 certificates. The result includes exact max-zero partial flows, all Hall subsets, explicit cut prices, real zero-box coordinates/volumes and comparisons. Optional prepare reads frozen `r377_numeric_input.json` and `r377_numeric_result.json`, with SHA256 provenance recorded; verify reads no older temporary file. No old file or repository state is modified.

Scope: real L1 source/target geometry, exact full matching and all frozen finite diagnostic fields, but finite receiver quadrature rather than dx and diagnostic rather than native high-dimensional hard gates. The partial max-retention result is never promoted to a general whole-plan or root-budget theorem.
