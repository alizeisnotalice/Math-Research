#!/usr/bin/env python3
"""Exact active zero-loss max flow and geometric Hall certificates, no optimizer."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter,deque
from itertools import product
import json,sys,hashlib
BASE=Path(__file__).resolve().parent;COUNTS=Counter()
def ck(k,v):
 COUNTS[k]+=1
 assert v,k
def dot(a,b):return sum((F(x)*y for x,y in zip(a,b)),F(0))
def read(p):return json.loads((BASE/p).read_text())
def sha(p):return hashlib.sha256((BASE/p).read_bytes()).hexdigest()
def prepare():
 old=read('r377_numeric_input.json');data=dict(cases=old['cases'],inherited_cap2_certificates=old['inherited_cap2_certificates'],provenance={p:sha(p) for p in ['r377_numeric_input.json','r377_numeric_result.json']},scope='Actual frozen L1 complete source/target cells and full original diagnostic marks, finite receiver quadrature. Active zero-loss transport is partial mass diagnostic, not a whole-plan cost optimizer. No new MATLAB/LP calls.')
 (BASE/'r378_numeric_input.json').write_text(json.dumps(data,sort_keys=True,indent=2)+'\n');print('PREPARED three frozen models; active count at most2, exact maxflow and all Hall cuts')
def fullmarks(c):
 n=c['n'];N=len(c['receivers']);A=c['A'];vol=list(map(F,c['volumes']));x=list(map(F,c['source_mass']));f=[a/b for a,b in zip(x,vol)];R=[F(r['R']) for r in c['receivers']];w=[F(r['weight']) for r in c['receivers']];centers=[list(map(F,r['center'])) for r in c['receivers']];m=[r**n for r in R];mu=[a/b for a,b in zip(w,m)];radii=sorted(set(R));h=F(c['h']);H=F(c['H']);kap=F(c['kappa']);omega=[list(map(F,row)) for row in c['omega']]
 ck('stage2_full_source_same_all_actual_matching',all(dot(row,x)==mass for row,mass in zip(A,m)) and sum(x)==F(c['actual_W']))
 expected=[[F(0)]*len(x) for _ in range(N)]
 for u in range(N):
  for y in range(len(x)):
   past=sum(mu[t]*A[t][y] for t in range(N) if m[t]<m[u]/kap)
   if past<=h:continue
   for l,r in enumerate(radii):
    if r<R[u]:continue
    J=sum(mu[t]*A[t][y] for t in range(N) if R[t]<=r)
    if J>=H:
     ell=r**(-n)-(radii[l+1]**(-n) if l+1<len(radii) else 0)
     expected[u][y]+=h*m[u]*ell/J
 ck('stage2_reconstructed_full_omega_J_past_clock',expected==omega)
 for p in c['plans']:
  v=p['v'];src=p['source_cells'];tgt=p['target_cells'];d=F(p['d']);rows=list(map(F,p['row']));cols=list(map(F,p['col']));K=[list(map(F,row)) for row in p['K']];L=list(map(F,p['L']));C=[list(map(F,row)) for row in p['cost']]
  ck('stage2_original_source_and_uniform_target_marginals',rows==[vol[y]*(f[y]-1)/m[v] for y in src] and cols==[d*vol[z]/m[v] for z in tgt] and sum(rows)==sum(cols)==d)
  Lv=[];Kv=[]
  for y in src:
   aa=[]
   for u in range(N):
    S=m[u]>kap*m[v] and 2*max(abs(a-b) for a,b in zip(centers[u],centers[v]))>R[u]
    aa.append(mu[u]*(1-m[v]/m[u])/h*omega[u][y]*A[u][y] if S else F(0))
   Lv.append(sum(aa));Kv.append([sum(aa[u]*A[u][z] for u in range(N)) for z in tgt])
  ck('stage2_one_common_objective_all_u_and_original_marks',Lv==L and Kv==K and C==[[L[i]-a for a in row] for i,row in enumerate(K)])
 return True

def cap2_lower(p,cert):
 C=[list(map(F,row)) for row in p['cost']];r=list(map(F,p['row']));s=list(map(F,p['col']));T=[list(map(F,row)) for row in cert['plan']];rp=list(map(F,cert['row_potential']));cp=list(map(F,cert['column_potential']));nr=len(r);nc=len(s)
 ck('reused_cap2_primal_feasible',all(a>=0 for row in T for a in row) and [sum(row) for row in T]==r and all(sum(T[i][j] for i in range(nr))<=2*s[j] for j in range(nc)))
 ck('reused_cap2_dual_feasible',all(b<=0 for b in cp) and all(rp[i]+cp[j]<=C[i][j] for i in range(nr) for j in range(nc)))
 val=sum(T[i][j]*C[i][j] for i in range(nr) for j in range(nc));ck('reused_cap2_exact_optimal_benchmark',val==dot(r,rp)+dot([2*a for a in s],cp)==F(cert['value']));return val

def zero_box(c,p,i):
 n=c['n'];rec=c['receivers'];v=p['v'];y=p['source_cells'][i];A=c['A'];R=[F(r['R']) for r in rec];m=[r**n for r in R];center=[list(map(F,r['center'])) for r in rec];omega=[list(map(F,row)) for row in c['omega']];kap=F(c['kappa']);C=list(map(F,p['cost'][i]));activeu=[]
 for u in range(len(rec)):
  if m[u]>kap*m[v] and 2*max(abs(a-b) for a,b in zip(center[u],center[v]))>R[u] and omega[u][y]*A[u][y]>0:activeu.append(u)
 lo=[max(center[u][d]-R[u]/2 for u in [v]+activeu) for d in range(n)];hi=[min(center[u][d]+R[u]/2 for u in [v]+activeu) for d in range(n)];volume=F(1)
 for a,b in zip(lo,hi):volume*=max(F(0),b-a)
 target=[]
 for j,z in enumerate(p['target_cells']):
  cell=[[F(a),F(b)] for a,b in c['cells'][z]]
  inside=all(lo[d]<=a and b<=hi[d] for d,(a,b) in enumerate(cell))
  ck('zero_box_cell_incidence_exact',inside==(C[j]==0))
  if inside:target.append(j)
 mass=sum(F(p['U'][j]) for j in target);ck('zero_box_positive_true_uniform_volume',volume>0 and mass==volume/m[v])
 return dict(source_row=i,source_cell=p['source_cells'][i],bounds=[[str(a),str(b)] for a,b in zip(lo,hi)],volume=str(volume),uniform_volume=str(mass),target_positions=target,target_source_cell_ids=[p['target_cells'][j] for j in target],defining_marked_receivers=activeu)
def exact_flow(rows,cols,zero):
 na=len(rows);nt=len(cols);S=0;T=1+na+nt;N=T+1;cap=[[F(0)]*N for _ in range(N)];BIG=sum(rows)+sum(cols)+1
 for i,r in enumerate(rows):cap[S][1+i]=r
 for i in range(na):
  for j in range(nt):
   if zero[i][j]:cap[1+i][1+na+j]=BIG
 for j,b in enumerate(cols):cap[1+na+j][T]=b
 res=[r[:] for r in cap];value=F(0);augment=0
 while True:
  parent=[None]*N;parent[S]=S;q=deque([S])
  while q and parent[T] is None:
   u=q.popleft()
   for v in range(N):
    if parent[v] is None and res[u][v]>0:parent[v]=u;q.append(v)
  if parent[T] is None:break
  v=T;path=[]
  while v!=S:path.append((parent[v],v));v=parent[v]
  amount=min(res[u][v] for u,v in path)
  for u,v in path:res[u][v]-=amount;res[v][u]+=amount
  value+=amount;augment+=1
 flow=[[cap[1+i][1+na+j]-res[1+i][1+na+j] if zero[i][j] else F(0) for j in range(nt)] for i in range(na)]
 ck('zero_transport_primal_feasible',all(a>=0 for row in flow for a in row) and all(sum(row)<=r for row,r in zip(flow,rows)) and all(sum(flow[i][j] for i in range(na))<=cols[j] for j in range(nt)) and sum(sum(row) for row in flow)==value)
 return value,flow,augment

def analyze(c,p,oldret,benchmark):
 C=[list(map(F,row)) for row in p['cost']];r=list(map(F,p['row']));U=list(map(F,p['U']));d=F(p['d']);cols=[2*d*u for u in U];active=[i for i,row in enumerate(C) if any(a>0 for a in row)];free=[i for i,row in enumerate(C) if all(a==0 for a in row)];rows=[r[i] for i in active];zero=[[a==0 for a in C[i]] for i in active];boxes=[zero_box(c,p,i) for i in active];amax=sum(rows)
 flowvalue,flow,augment=exact_flow(rows,cols,zero);cuts=[]
 for bits in product([0,1],repeat=len(active)):
  ids=[i for i,b in enumerate(bits) if b];neighbor=[j for j in range(len(U)) if any(zero[i][j] for i in ids)];demand=sum(rows[i] for i in ids);capacity=sum(cols[j] for j in neighbor);deficit=demand-capacity
  alpha=[F(0) if i in ids else F(1) for i in range(len(active))];beta=[F(1) if j in neighbor else F(0) for j in range(len(U))]
  ck('every_geometric_hall_cut_dual_feasible',all(alpha[i]+beta[j]>=1 for i in range(len(active)) for j in range(len(U)) if zero[i][j]))
  upper=dot(rows,alpha)+dot(cols,beta);ck('hall_cut_mass_upper_bound',flowvalue<=upper and upper==amax-deficit)
  cuts.append(dict(active_subset=[active[i] for i in ids],neighbor_target_positions=neighbor,demand=str(demand),neighbor_uniform_volume=str(sum(U[j] for j in neighbor)),neighbor_true_volume=str(sum(F(c['volumes'][p['target_cells'][j]]) for j in neighbor)),capacity=str(capacity),deficit=str(deficit),source_dual=list(map(str,alpha)),target_dual=list(map(str,beta))))
 best=max(cuts,key=lambda a:F(a['deficit']));D=F(best['deficit']);ck('exact_maxflow_hall_primal_dual_zero_gap',D>=0 and flowvalue==amax-D)
 retained=[list(map(F,row)) for row in oldret];oldmass=sum(retained[i][j] for i in active for j in range(len(U)));oldlost=amax-oldmass
 ck('old_priority_active_retention_is_feasible_zero_transport',all(retained[i][j]>=0 and (C[i][j]==0 or retained[i][j]==0) for i in active for j in range(len(U))) and all(sum(retained[i])<=r[i] for i in active) and all(sum(retained[i][j] for i in active)<=cols[j] for j in range(len(U))))
 ck('old_retention_below_max_and_hall_loss_lower',oldmass<=flowvalue and D<=oldlost)
 positives=[a for i in active for a in C[i] if a>0];costmin=min(positives) if positives else F(0);costlower=costmin*D;ck('hall_minpositive_cost_lower_bound_below_benchmark',costlower<=benchmark)
 oneconstant=len(active)==1 and len({a for a in C[active[0]] if a>0})==1
 if oneconstant:ck('observed_one_active_constant_positive_layer_hall_exact_cost',benchmark==costlower)
 return dict(v=p['v'],weight=p['weight'],d=str(d),active_source_rows=active,free_source_rows=free,active_mass=str(amax),max_active_zero_retention=str(flowvalue),hall_deficit=str(D),old_priority_active_retention=str(oldmass),old_priority_active_loss=str(oldlost),extra_zero_retention_available=str(flowvalue-oldmass),minimum_positive_cost=str(costmin),hall_cost_lower=str(costlower),allcap2_optimal_bad=str(benchmark),hall_cost_explains_exact_optimum=benchmark==costlower,one_active_constant_positive_layer=oneconstant,zero_geometry=boxes,max_zero_transport=[list(map(str,row)) for row in flow],augmentations=augment,hall_certificate=best,all_hall_cuts=cuts)
def verify():
 data=read('r378_numeric_input.json');bench={(a['name'],a['v']):a for a in data['inherited_cap2_certificates']};summ=[];certs=[]
 for c in data['cases']:
  fullmarks(c);weighted={k:F(0) for k in ['active_mass','max_active_zero_retention','hall_deficit','old_priority_active_retention','old_priority_active_loss','extra_zero_retention_available','hall_cost_lower','allcap2_optimal_bad']};nontrivial=0;positivecuts=0
  for p,old in zip(c['plans'],c['residual_problems']):
   ck('old_retention_same_receiver',p['v']==old['v']);ob=cap2_lower(p,bench[(c['name'],p['v'])]) if p['nonzero_cost'] else F(0);cert=analyze(c,p,old['retained'],ob);cert['name']=c['name'];certs.append(cert);w=F(p['weight'])
   for k in weighted:weighted[k]+=w*F(cert[k])
   nontrivial+=bool(cert['active_source_rows']);positivecuts+=F(cert['hall_deficit'])>0
  G=F(c['original_diagonal']);ck('weighted_hall_cost_explains_observed_allcap2_remainder',weighted['hall_cost_lower']==weighted['allcap2_optimal_bad'])
  summ.append(dict(stage=c['stage'],name=c['name'],n=c['n'],actual_source_W=c['actual_W'],original_G=str(G),nontrivial_active_v=nontrivial,positive_hall_deficit_v=positivecuts,weighted_diagnostics={k:str(v) for k,v in weighted.items()},hall_cost_fraction_of_G=str(weighted['hall_cost_lower']/G),scope='Outer receiver-weighted active masses are diagnostics, not a new global source mass. Partial maxzero flows are not passed off as a whole cost-optimal plan.'))
 out=dict(status='PASS',exact_grouped_checks=sum(COUNTS.values()),check_counts=dict(COUNTS),summary=summ,certificates=certs,scope=data['scope'],provenance=data['provenance'])
 (BASE/'r378_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='certificates'},sort_keys=True,indent=2))
if __name__=='__main__':prepare() if len(sys.argv)>1 and sys.argv[1]=='prepare' else verify()
