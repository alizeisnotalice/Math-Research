# R378 完整费用账：不混用不同场或不同计划

记W=||f||_1，X_q=∫_E q_u du，W_ν=||ν||_1，ν≤f，q_-=3λ/4，A_n=1+nlog(b/a)，b≤2a，Λ=128/119。原入口与原场合同参照附入R377ledger和R376ledger。

## 选定一条完整计划后再分账

同一完整来源精确计划的原bad费用精确分为G_sparse+G_dense。sparse包含原门并附j≤floor(n/8)，dense附互补j>n/8；没有丢掉任何pair。sparse付款σ_nX_q，其中
\[
 \sigma_n=\varepsilon_0\widehat b_n/(1+\sqrt n).
\]
该界不需目标cap，故既能用于旧cap2计划，也能用于本轮t层计划。不能将旧计划的good信用加在新计划的bad估计上。

本轮新方案：先按r378_layered确定Bbar、层数t，再定
\[
 \mathcal L_{n,t}=2+\frac{72+(t+1)\Gamma_n}{1+\sqrt n},\qquad
 \varepsilon_0=\eta/\mathcal L_{n,t},\qquad
 h=\frac{1+\sqrt n}{\varepsilon_0q_-}.
\]
用该h重建全部原门与标记，并在同一场上按dense核构造来源精确、目标≤td_vU_v的完整计划。其full bad的sparse部分用来源精确界，dense部分用分层构造。全核floor+good≤(t+1)p，得到
\[
 B_H(f,\nu)\le\mathcal D_{\rm dense}
 +(\eta+\sigma_n+\varepsilon+\varepsilon')X_q+C_{338}W. \tag{L1}
\]
其中
\[
 C_{338}=\frac\lambda{q_-}
 \left[\frac{2+3\sqrt n+2e^{-\sqrt n}}{\varepsilon_0}+1+\sqrt n\right],
\]
\[
 \Gamma_n=1+\frac{n}{4(\sqrt n+1)}
 +2\sqrt n\sqrt{1/4+\tfrac12\log(1+\sqrt n)}(1-1/\sqrt2).
\]
τ阈值从εq_-到Bbar；finite depth逼近费用≤ε'X_q。全部实际source权d_v、dv和阈值增量留在D_dense中。t≤O_{η,ε}(log(n+2))，故本式来源价为O_{η,ε}(sqrt(n)log^(3/2)(n+2))W。这只证明已列来源价的阶，不是D_dense的阶。

原始入口完整保留为
\[
 T_{\rm entrance}\le8\lambda HW+2d_{\rm eff}A_nW_\nu/H
 +2\mathcal D_{\rm dense}
 +2(\eta+\sigma_n+\varepsilon+\varepsilon')X_q+2C_{338}W.
\]
整式仍乘Λ。因为bhat≤1、ε0≤η/2，所以σ_n≤η/2。若仅给此槽总系数κ，可取η=ε=ε'=κ/(7Λ)，则2Λ(η+σ_n+ε+ε')≤κ。此例不认证其他槽总系数之和，也不免去η变化时全场重建。

## 仍未付款和禁止重复收益

未付：D_dense的一般来源根阶预算；原入口H费用与H选择；一般soft/crossing/entry接口；合同外重尾、宽距离、低pe高度与极端尺度比的全部补集；初始、删除跳跃、未来被删来源的历史原子；全来源/尺度聚合、外积分、截断与极限。物理时钟末端原子不是历史原子付款。

本轮没有优化阈值以遗漏补集；sparse/dense仅在原合同内分割。若继续旧cap2的R377路线，可合法将M1用于dense核，但其来源失量/捕获余额仍未付。若采用L1分层计划，则不能再扣旧M1的Capture或旧计划振荡信用；只能在同场对完整计划成本作合法比较。可数关系深度增加的误差已在ε'内；不能默认D_dense为零，也不能把有限诊断Hall缺口推成一般模型上界。
