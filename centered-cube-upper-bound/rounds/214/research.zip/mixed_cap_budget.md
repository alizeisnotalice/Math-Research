# R214 主证明：共同接收行上的加法帽及相关剩余

## 范围

本稿保持一般中心立方体n^(1/2+o(1))目标，但只支付原far remaining正域中明确的混合帽子域。原负余额保留给精确补域一次；没有证明该补域或near/其它原块已支付。

沿用R213原全部RT1资格：固定同一行与有限正负截断，p>0、T>0、e_g>0、q>0；终端G⊔B=Zg，两槽原Π_t=1_Zt w_tν/e_t，来源Zt递减，w为实际min-product时钟。完整外测度dT=1I1j q^-1 p h_R aω dx β(dy)ν(dz)，外系数2Λ，Λ=128/119。原heavy给T e_g>sqrt(ell)q，ell=1+log n；FIRST给∫Jν≤q、∫K0ν≤q。T、K0及J都取原真实行的值，沿辅助t固定，不重新优化selector或历史。

## 两个帽使用同一来源账

预选L0>0、κ>0，定义

    HJ(v)=L0 J_v/p,
    HK(v)=K0v/(κT),
    H(v)=HJ(v)+HK(v).

K0依真实x、软度和夹断尺度；不假定它对接收点独立，也不将它积分归一。J=P1,b才是固定窗口、可在最后dx归一的核。H沿t固定即可应用R213真实clock结算。

在原正remaining域分成三个互斥部分：目标w_t(v)≤H_v；目标>H_v而坏端w_t(u)≤H_u；两端均>H。坏端始终u∈B，目标v∈G。等号归已付片，零w后验槽先置零。

第一片用D+≤kv、坏端概率≤1、et≥eg，逐目标帽FTC给行价M_G/eg，M_G=∫G Hν。第二片保完整Π后有Π(B_low)≤M_B/e_t，M_B=∫B Hν，故由原倒分母clock

    ∫kbar_t/e_t dlogt ≤1/e_r−1/e_l≤1/e_g

得到M_B/eg。删除对1/e的贡献非负，不能遗漏或假定来源固定；孔时间域只作非负扩大。必须先在同一行合并G/B标签：

    R_paid ≤(M_G+M_B)/eg
           = ∫Zg Hν/eg
           ≤L0 QJ/(p eg)+q/(κTeg).                    (MC1)

两项都不领取负信用，也不将每个分支先上放全ν而多记一份来源。

## 两种不同外层费用

MC1第一项按R213原source证明：一次hard帽16/3，原high列∫β/eg≤1/(2K)，保唯一j及固定共同J后真实dx积分，得到

    2Λ P_J-bound ≤16Λ L0/(3K) Wν ≤16Λ L0/(3K) WA.      (MC2)

这是同一共同父构造的来源账，独立窗口仍须保各自费用。不使用ν≤β。

MC1第二项先用原heavy得到统一行界q/(κTeg)<1/(κsqrtell)。随后只用原完整外测度Tsmall≤4X，得到

    2Λ P_K-bound ≤8Λ/(κsqrtell) X.                     (MC3)

MC2的hard16/3不能再乘到MC3；MC3也不能把X偷偷换成任意∫q dx。两项来自同一个行上界拆开积分，并不要求按receiver把它们各自识别为另一对不交交通。

因此

    2Λ(P_rem−N_avail)
      ≤2Λ(P_both-outside-H−N_avail)
        +16ΛL0/(3K) WA+8Λ/(κsqrtell) X.               (MC4)

共同取L0=Ksqrt n、κ=8Λ/(ε_mix sqrtell)，得到一次(16Λ/3)sqrt n WA+ε_mix X。ε_mix必须独立预留，旧R211恢复槽及R212/R213低域source价已经包含或另计，不能重复使用；κ随预定n/ε选择合法，不能沿t或来源后验自适应改变。没有小维数回退遗漏，因MC3的heavy界直接对每个原合法n成立。

## 加法帽确切保留的相关几何

令a_t(z)=L0 J_z/(p w_t(z))、b_t(z)=K0z/(κT w_t(z))。未付补域的每一端准确满足

    a_t(z)+b_t(z)<1.                                  (MC5)

它比a<1、b<1分别成立更强；不能为降低复杂度丢掉其相关余量。尤其加法帽支付的区域可以包括a<1、b<1但a+b≥1，不仅是两旧帽事件的并集。

保原H0、Hhat与一维a_s，令

    D_s(x,z)=Σ_i log[a_s/f_s(|x_i−z_i|/Hhat)].

R213的真实核恒等K0z/T=(H0/Hhat)^n exp(−D_s)给MC5的等价严格必要式

    a_t(z)<1,
    D_s(x,z)> n log(H0/Hhat)−log w_t(z)−logκ
              −log(1−a_t(z)).                         (MC6)

两端z=v,u都满足MC6，且来源、p、K0、J、w仍为同一接收行。不把a视作独立随机量；a接近1时右侧强化是真实相关成本。所有scale clamp保留。额外capture/rho0近单位条件只授予target v，不授予bad u。

MC6尚无统一接收测度价格；FIRST上矩不控制低K0后验尾，任意来源也不由张量核表达自动变成独立坐标。原good/bad、FA、suffix、Pi²/e²和全部负余额仍要与这个条件共同结算。

## 核验状态

解析证明只调用已审R213分段FTC/倒分母恒等、原FIRST/heavy与外账。有限本机检查另见capacity_cap_checks.py及numeric_notes.md；它们是条件时钟/容量模型，不能认证原空间FULL。最终独审绑定见audit.md，主目标未闭合。
