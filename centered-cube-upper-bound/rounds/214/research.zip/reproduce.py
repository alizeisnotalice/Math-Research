#!/usr/bin/env python3
"""Verify R214 package hashes and replay finite evidence, not a general proof."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
STEM = 'capacity_cap_checks'
REQUIRED = {'reproduce.py', 'task_contract.md', STEM + '.py', STEM + '.json'}


def verify_manifest():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    if not isinstance(manifest, dict) or not REQUIRED.issubset(manifest):
        raise ValueError('manifest.json must be a filename-to-SHA256 mapping covering the driver, contract, numeric script and reference JSON')
    for name, digest in manifest.items():
        if not isinstance(name, str) or not isinstance(digest, str) or not re.fullmatch(r'[0-9a-f]{64}', digest):
            raise ValueError('Invalid manifest entry: ' + repr(name))
        relative = Path(name)
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Manifest paths must stay within the package: ' + name)
        path = (ROOT / relative).resolve()
        if not path.is_relative_to(ROOT) or not path.is_file():
            raise ValueError('Missing or escaping package file: ' + name)
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != digest:
            raise ValueError('SHA256 mismatch: ' + name)
    print('Verified', len(manifest), 'manifest file hashes', flush=True)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify-only', action='store_true')
    parser.add_argument('--output-dir', type=Path, help='Directory for a fresh replay JSON; reference JSON is never overwritten')
    parser.add_argument('--numeric-python', default=sys.executable, help='Python 3 with standard library; inherited PYTHONPATH is preserved')
    args = parser.parse_args()
    manifest = verify_manifest()
    if args.verify_only:
        return
    if args.output_dir is None:
        parser.error('--output-dir is required unless --verify-only is selected')
    numeric_path = Path(args.numeric_python).expanduser()
    numeric_python = str(numeric_path.resolve()) if numeric_path.is_file() else shutil.which(args.numeric_python)
    if numeric_python is None:
        parser.error('--numeric-python executable was not found')
    output_dir = args.output_dir.expanduser().resolve()
    output = output_dir / (STEM + '.json')
    protected = {(ROOT / name).resolve() for name in manifest}
    if output.resolve() in protected or output.exists() or output.is_symlink():
        parser.error('Use a fresh output JSON path outside all manifest-bound source files')
    output_dir.mkdir(parents=True, exist_ok=True)
    # Execute a relocated copy, so no dependency on the source checkout's cwd
    # or original absolute location can silently satisfy the replay.
    with tempfile.TemporaryDirectory(prefix='r214_numeric_replay_') as temporary:
        work = Path(temporary)
        for name in ('task_contract.md', STEM + '.py'):
            shutil.copyfile(ROOT / name, work / name)
        print('Running a temporary relocated copy', flush=True)
        subprocess.run(
            [numeric_python, str(work / (STEM + '.py')), '--output', str(output)],
            check=True, cwd=work, env=os.environ.copy(),
        )
    if output.read_bytes() != (ROOT / (STEM + '.json')).read_bytes():
        raise ValueError('Complete replay JSON differs from the manifest-bound reference: ' + str(output))
    # Confirm the package remained unchanged during execution as well.
    verify_manifest()
    print(STEM, 'complete JSON byte-identical:', output, flush=True)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, subprocess.CalledProcessError) as error:
        print('Reproduction failed:', error, file=sys.stderr)
        sys.exit(1)
