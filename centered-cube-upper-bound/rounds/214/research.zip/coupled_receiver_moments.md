# R214：同一接收点的双腿核矩与显式一致费用

状态：给出原HH与双方低K0/w_t子域的固定物理参数联合矩上界、精确一维tensor因子及可核算尾界。保同一个receiver x，不将v/u来源或两个似然比独立化。也给能覆盖连续selector的粗点态包络，但完整保留其指数维数、soft inverse和source位移费用；未得到原Pi²/RT1的线性来源付款。theta+chi<1/2只是统一充分域，不是最优积分域。

使用H04技能仅限真实模型/矩母函数、零层和统一参数范围纪律；已读SKILL与provenance。本稿不援引LDP/MDP，不将Chernoff或共轭量解释成概率渐近。本节代数是一般joint-moment工具在新两腿K0补域的具体代入；不把旧R124一般矩/盒接口重新登记成新付款。

## CM1　真实核、固定参数与准确正域

固定同一receiver积分之前的s∈(0,1]、Lcur、Hhat、b、y,v,u，Lcur,Hhat∈[b/2,b]。令
\[
 h=1_{[-1/2,1/2]},\quad
 w(r)=\int_0^1e^{-|r|/a}\,da,\quad
 \varphi=h*w,\quad f_s=(1-s)h+s\varphi.
 \tag{CM1}
\]
p_y=P_s,Lcur(x−y)，J_v=P1,b(x−v)，K_v=P_s,Hhat(x−v)，u腿同理。原K0即此K，而非一个可自由替换的来源密度。

固定原(omega,V,j,y,t)，原w_t(y,v)、w_t(y,u)、完整Pi_t独立x；这不意味着终端G/B和原Hrem独立x。先对确定v,u作下式，再在能保持实际来源测度时Tonelli。所有原gate可保在左侧；若正放删去，不能声称与原事件等价。

写mathsf L>0为原HH阈值，kappa>0为父级新lowK阈值，mathsf T>0为原捕获系数。固定参数情形中T由同一g/cj等确定。只考虑实际两腿正域
\[
 \mathcal E=\{p_y w_v>\mathsf L J_v,\quad
 p_y w_u>\mathsf L J_u,\quad
 K_v<\kappa\mathsf T w_v,\quad
 K_u<\kappa\mathsf T w_u\}.
 \tag{CM2}
\]
wv=w_t(y,v)、wu同理。w0且J>0时HH空，先处理；零p/Q/eg、空far原零支仍保。CM2是一个必要支持交集，不自行等同于全部baseline或mixed帽补域；精确mixed耦合另保于CM3a。

## CM2　共同receiver的精确联合矩

取r,tau≥0（tau是本节指数，不是原clock起点）、theta,chi≥0，设
A=1+r+tau，R=r+tau，Theta=theta+chi。定义
\[
 \mathcal M=\int_{\mathbb R^n}
 p_y(x)^A J_v(x)^{-r}J_u(x)^{-\tau}
 K_v(x)^{-\theta}K_u(x)^{-\chi}\,dx.
 \tag{CM3}
\]
各零指数因子直接定义为1；不在s0的K0零区形成0除0。先s>0，所有K/J严格正。

设lambda=Lcur/b、eta=Hhat/b、d_v=(v−y)/b、d_u=(u−y)/b。归一一维核
\[
 p_\lambda(z)=\lambda^{-1}f_s(z/\lambda),\quad
 j_d(z)=\varphi(z-d),\quad
 k_{\eta,d}(z)=\eta^{-1}f_s((z-d)/\eta).
\]
逐坐标同一个变量z_i给
\[
 m_i=\int_{\mathbb R}p_\lambda(z)^A
 j_{d_{v,i}}(z)^{-r}j_{d_{u,i}}(z)^{-\tau}
 k_{\eta,d_{v,i}}(z)^{-\theta}
 k_{\eta,d_{u,i}}(z)^{-\chi}\,dz,
\]
\[
 \boxed{\mathcal M=b^{n\Theta}\prod_{i=1}^n m_i.}
 \tag{CM4}
\]
证明是物理张量公式、x=y+bz的Jacobian及非负Tonelli；总density幂为1−Theta，故单位b^(nTheta)不能漏。两腿在每个m_i共享z，不能再把m_i拆成v腿/u腿各自积分的乘积。

等价地，固定p_lambda(z)dz概率下，m_i是向量
(log(p_lambda/j_v),log(p_lambda/j_u),−log k_v,−log k_u)
的一个共同矩母函数值。其分量通常相关；只在固定张量接收核诱导的坐标概率下可以对i相乘。来源nu/beta或原Pi不因此变成独立坐标概率。

## CM3　两腿HH与低K的有限Chernoff上界

在CM2上，四个正比值p_ywv/(mathsf L Jv)、p_ywu/(mathsf L Ju)、kappa T wv/Kv、kappa T wu/Ku均大于1。任意上述非负指数乘积因而大于等于1；在补集左侧为0。因此
\[
 \boxed{\int p_y1_{\mathcal E}\,dx
 \le\frac{(\kappa\mathsf T)^\Theta}
 {\mathsf L^{R}}
 w_v^{r+\theta}w_u^{\tau+\chi}\,
 b^{n\Theta}\prod_i m_i.}
 \tag{CM5}
\]
这是有限正不等式，不需概率大偏差定理。Theta0时不除K；全指数0仅给∫p=1，不能把该退化称为尾衰减。可在一个真实共同参数组上优化指数；不能逐坐标、逐腿各选不同source/selector后仍宣称得到共同可实现的原矩。

CM5保wv/ wu/ T以及b单位，不能在source积分前随意外提。实际a=T(w_tau−w_h)、alpha0J和其它capture门尚未在本正放中利用，故CM5本身不包含它们的额外几何压缩。也不从K低自动反推原full baseline条件成立。

## CM3a　原mixed帽补域的耦合必须先保留

本轮父稿mixed_cap_budget给原补域每腿精确条件，以下mathfrak a不是捕获损失a=TDelta：
\[
 \mathfrak a_z=\frac{\mathsf L J_z}{p_yw_z},\qquad
 \mathfrak b_z=\frac{K_z}{\kappa\mathsf T w_z},\qquad
 \mathfrak a_z+\mathfrak b_z<1,\quad z=v,u.
 \tag{CM5a}
\]
它严格强于分别a<1、b<1；不能在放松后声称保留了全部mixed事件。对任意theta,chi≥0，直接有较精确正界
\[
 \begin{split}
 \int p_y1_{mixed}\,dx
 \le{}&(\kappa\mathsf T)^\Theta w_v^\theta w_u^\chi
 \int p_yK_v^{-\theta}K_u^{-\chi}
 1_{\{\mathfrak a_v<1,\mathfrak a_u<1\}}\\
 &\hspace{10mm}\cdot(1-\mathfrak a_v)^\theta
                  (1-\mathfrak a_u)^\chi\,dx.
 \end{split}\tag{CM5b}
\]
零指数直接因子1，active正分母资格同CM1。两个(1−a)是完整n维核比值的函数，不能假装它们逐坐标tensor。

若要接CM4的可计算矩，sharp有限标量上放为
\[
 C(r,\theta)=\sup_{0<a<1}a^r(1-a)^\theta
 =\frac{r^r\theta^\theta}{(r+\theta)^{r+\theta}},
 \qquad1_{\{a<1\}}(1-a)^\theta\le C(r,\theta)a^{-r}.
 \tag{CM5c}
\]
r,theta>0时由r/a−theta/(1−a)=0得最大点a=r/(r+theta)；端点r0、theta0或双0均置C=1，sup可能仅极限达到。两腿分别应用后，CM5的右侧再乘C(r,theta)C(tau,chi)。指数仍共同预选，不独立重选来源或receiver。它保留耦合的sharp标量费用后才进一步放松，不能把常数改善解释成一般来源价。

精确空间缺陷也保留该耦合。若K_z/T=(H0/Hhat)^n exp(−D_s(x,z))，mixed条件推出
\[
 \mathcal D_s(x,z)>
 n\log(H_0/\widehat H)-\log w_z-\log\kappa
 -\log(1-\mathfrak a_z),\qquad\mathfrak a_z<1.
 \tag{CM5d}
\]
当a接近1时新增正成本不能丢掉。target还交真实capture/alpha0支持；bad腿不自动继承capture。CM5b、CM5d是保留原耦合的接口；若用较粗CM5或CM5c，必须明确已丢掉哪些信息，不能由此宣布mixed补域/root预算已付。

## CM4　尾界、全部尺度及soft端点

对epsilon>0，置c_epsilon=epsilon/(1+epsilon)。在w积分只取a∈[1/(1+epsilon),1]给
\[
 w(r)\ge c_\epsilon e^{-(1+\epsilon)|r|},\qquad
 \varphi(r)\ge c_\epsilon
 e^{-(1+\epsilon)(|r|+1/2)}.
 \tag{CM6}
\]
另一方面w(r)≤e^−|r|、phi(r)≤e^(1/2)e^−|r|；核心内fs≤1，核心外fs=sphi，所以全实数
\[
 f_s(r)\le e^{1/2}e^{-|r|},\qquad f_s(r)\ge s\varphi(r).
 \tag{CM7}
\]
固定s≥smin>0。定义
\[
 \delta_\epsilon=A/\lambda-(1+\epsilon)(R+\Theta/\eta).
 \tag{CM8}
\]
用三角不等式逐项保持同一个z，可得一维integrand≤B_i e^−delta_epsilon|z|，其中
\[
 \begin{split}
 B_i={}&\lambda^{-A}\eta^{\Theta}
 c_\epsilon^{-(R+\Theta)}s_{min}^{-\Theta}
 \exp\{A/2+(1+\epsilon)(R+\Theta)/2\}\\
 &\times\exp\{(1+\epsilon)[(r+\theta/\eta)|d_{v,i}|
              +(\tau+\chi/\eta)|d_{u,i}|]\}.
 \end{split}\tag{CM9}
\]
故delta_epsilon>0时
\[
 m_i\le2B_i/\delta_\epsilon,
 \qquad \int_{|z|>Z}\text{integrand}\,dz
 \le(2B_i/\delta_\epsilon)e^{-\delta_\epsilon Z}.
 \tag{CM10}
\]
这是解析上界；有限quad在此下可独列尾部，但机器precision差不自动成为interval误差。

原精确尾指数的充分严格条件为
\[
 \delta_0=A/\lambda-R-\Theta/\eta>0.
 \tag{CM11}
\]
因为可按实际R/Theta选足够小epsilon使CM8仍正。没有要求epsilon只依Theta：R无上界时那样的统一选择不成立。本稿只调用严格正gap的充分域，不以该包络作端点或必要充分判别。

lambda,eta∈[1/2,1]给delta0≥1−2Theta，故Theta<1/2覆盖全部这些尺度。若固定R、Theta，显式选
\[
 \epsilon=\frac{1-2\Theta}{2(R+2\Theta)}
 \quad(R+2\Theta>0),\qquad
 \epsilon=1\quad(R=\Theta=0),
\]
则delta_epsilon≥delta_*=(1−2Theta)/2>0。

s→1无inverse-soft退化，s→0时smin^−Theta真实保留。若s=0且Theta>0，K可在p仍正的开放区域为0，负幂矩可能为infinity，不能用0乘无穷抵消。可先在Theta0分支保HH矩、或保原零K区域另算；本稿没有证明其一般价。严格soft并非免费覆盖全部原s∈[0,1]。

## CM5　连续selector的合法粗上放及其全部代价

这部分给一个不交换sup和积分的实际适配途径，并不声称其经济。仍限s(x)≥smin>0、共同Lcur(x)/b,Hhat(x)/b∈[1/2,1]、b/y/v/u固定。共同选择器可任意可测。固定指数R、Theta<1/2，取上一节epsilon和delta_*，置
\[
 B_* =2^A c_\epsilon^{-(R+\Theta)}s_{min}^{-\Theta}
 \exp\{A/2+(1+\epsilon)(R+\Theta)/2\}.

\]
由lambda^-A≤2^A、eta^Theta≤1、eta^-1≤2，CM9--10是同一个点态包络，故对任意该实际selector直接有
\[
 \boxed{\int p_{s(x),L(x)}^A J_v^{-r}J_u^{-\tau}
 K_{s(x),H(x),v}^{-\theta}K_{s(x),H(x),u}^{-\chi}\,dx
 \le b^{n\Theta}\left(\frac{2B_*}{\delta_*}\right)^n
 e^{(1+\epsilon)[(r+2\theta)\|d_v\|_1+
                 (\tau+2\chi)\|d_u\|_1]}.}
 \tag{CM12}
\]
证明先逐点用同一指数包络，再积分e^−delta_*||z||1，不是sup∫代替∫sup。代价包含C^n、smin^−nTheta及来源位移指数，没有免费soft/scale选择器根界。

若CM5也用于该selector，还须将实际T(x)^Theta保在receiver积分内，或对本共同参数范围用有证明的Tmax。原T=cj^(n/2)/(g^n sqrtell)、g≥a_win/cj给
Tmax≤cj^(3n/2)/(a_win^n sqrtell)，因而(b^n Tmax)^Theta仍含(b/a_win)^(nTheta)和原cj/ell费用。wv、wu只有在固定原j,y,t后才独立x；原time/j积分不能先免费合并。若smin、b或窗口也随外层变，所有常数留各窗或取已证明统一范围，不从E sum中无条件抽出。

有限参数菜单时还可逐共同参数求和；这支付实际菜单总价。旧R123/R124 arcsine/盒方案另有测试裕度、尺度与Gamma适配费用，本稿不重证其通用接口。CM12只是一个明确昂贵的可行替代，不能因“已有选择器工具”抹掉本joint inverse-K的成本。

## CM6　真实来源回代与第一处尚缺

固定原omega,V,j,y,t且Pi_t独立x时，确定源对(v,u)的CM4--5可在同一实际Pi_t²上非负Tonelli；没有把source抽成独立坐标。但终端G/B、capture、high、原Hrem、g/h以及T可依x，所以须保原mask或明确正放。尤其Pi_t含e_t^-2，不能将CM4后的source pair积分冒充linear WA。

CM12的source位移指数对任意有限正nu不保证有有限矩。即使能保精确乘积∏m_i而不用粗尾包络，也还需要在原RT1的py/hard source/beta/Pi²及原high/uniquej/window中支付其共同source积分。不能先对各source独立取最坏receiver再用共同父质量消掉M²/e²。

这些限制说明：新两腿lowK域的确可写成一个可复算共同receiver矩，且存在明确一致可积域；但Chernoff优化本身没有给C nK/mathsfL WA或epsilon X。低K、HH与原baseline的其余联合条件若被正放删去，就只得到较弱上界，不能再把它报告为原mixed帽补域已经结算。

## CM7　最小有限数值接口

建议父级批准后最多6组actual physical一维核积分：b1,y0，s取.25/.75/.99/1，lambda/eta取(.5,1)/(1,.5)/(.75,.75)，dv/du取0/.5/−.5/2的少量指定组合。共同指数r=tau1/4、theta=chi1/8，Theta1/4给所有scale delta0≥1/2。所有硬面x=±lambda/2,dv±eta/2,du±eta/2分段，保持闭面不作错误逆值；积分单点边界零测。

可用25/40位quad并按CM10独列解析尾；不同精度一致非严格interval证书，不认证原FIRST/history/完整Pi。另取theta=chi0时比较共同m(r,tau)与m(r,0)m(0,tau)，只作shared-x依赖诊断，不能把后一乘积当正确因子化。n维tensor由CM4证明，不靠有限n拟合猜率。未执行的建议不写作通过；实际范围由最终numeric_notes记载。

结论：本文提供实际两腿lowK补域的精确joint receiver矩与全部尺度/soft/selector成本；原来源列与signed剩余预算未闭合。需要更强的mixed帽/原capture约束改善这些指数成本，而不是仅对已放松事件取一个看似正的rate。
