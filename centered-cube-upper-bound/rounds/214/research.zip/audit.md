# R214 independent audit — final frozen review

Final status: passed within the scopes in sections 7–8; all ten other work files are bound in section 8. Sections 1–6 preserve the chronological independent screens, and the earlier pending statements there are superseded by the final review. No general centered-cube bound or remaining mixed-cap signed budget is certified.

Status: independent premise screen only. Read the R214 contract before any new author proof. At this checkpoint no R214 author manuscript, numerical code, TeX, or final driver has been reviewed. Only this file is owned by the auditor; no Git, numeric execution, PDF compilation, or other-file edits were performed. The R213 frozen results are used within their audited scope, without redoing their historical proofs.

## 1. Exact remaining object and unchanged credit

The original RT1 common receiver/outer-source measure, actual selector, unique j, actual windows and double posterior remain in force. The current positive object is the complete rho0 baseline on the both-high domain p_y w_t(v)>L0 J_v and p_y w_t(u)>L0 J_u, L0=K sqrt(n), with all original positive gates. The two-low union was already paid once in R213; its allowance is not newly available. All still-available original negative stays assigned once to the final complementary signed object. No deletion atom is identified with the original time-density Ndel.

The necessary R213 spatial support is not a tail price. In particular, the lower-clamp term n log(H0/Hhat), inside gains, eta_eff, Delta, and the actual target support must remain. A positive or near-unit target does not impose the same capture condition on the bad source u.

## 2. Independent receiver-model and selector screen

For fixed physical parameters s,L,Hhat and fixed y,v, the outer product p_s,L(x-y) is a probability density in x. Its coordinates are independent receiver coordinates only. Source v and source u must remain jointly represented at the same x; their original labels, actual Pi_v Pi_u, and e_t^{-2} are not independent random samples from that receiver law.

A concrete legal fixed-parameter moment is, for theta>0 and 0<s<=1,

    integral p_s,L(x-y) exp(theta sum_i F_s(|x_i-v_i|/Hhat)) dx
      = product_i integral [L^{-1} f_s(z/L)]
          [a_s / f_s((z+y_i-v_i)/Hhat)]^theta dz.

This is a deterministic same-x tensor identity; it does not replace the original source measure. The exponential tails give finite positive moments when theta < Hhat/L. The boundary theta=Hhat/L generally has divergent polynomial tails, so one cannot assert a single positive moment uniformly over unrestricted scale ratios or use the endpoint without an additional argument. Pure-hard s=0 has zeros and needs its own support treatment. Uniform bounds must also cover displacement, s tending to zero or one, and both clamp regimes within the actual claimed parameter range.

The actual p_{s(x),L(x)}(x-y) is not automatically a normalized probability in x. A fixed-parameter integral or fixed-parameter tail estimate is not valid for an arbitrary receiver selector merely because its constant is uniform. One needs a pointwise common majorant, a proved maximal integral estimate with its full parameter cost, or a genuinely justified common-parameter averaging argument. The same restriction applies to Hhat, g, eta_eff and the current capture/background field when they depend on the receiver selector. A finite menu costs its actual sum unless a stronger common estimate is proved.

At fixed original (omega,V,j,y,t), the preterminal clock posterior can be independent of x, which permits nonnegative Tonelli in that exact order. Terminal G/B, rho0, actual history, high gates, spatial deficit and the receiver selector need not be independent of x. Dropping a positive gate is legal; moving these correlated fields outside the x integral, replacing Pi by J nu/Q, or using nu<=beta is not. If J nu/Q is introduced, its exact Radon–Nikodym factors to Pi must remain on both legs. The common-parent source index and independent-window costs remain those already audited in R181/R212–213.

The target deficit threshold is receiver dependent and may be negative under the lower clamp. A deterministic lower threshold, positive moment, or favorable mean must therefore be proved in the exact direction before applying exponential Markov. FIRST's upper integral of K0 does not itself pay a low-K0 tail under w_t nu/e_t. Nor does a sourcewise coordinate count create independent source probabilities.

## 3. New fixed K0-cap screen (before author proof)

The following candidate was independently checked after receipt as a precise proposition. Let kappa>0 be common and preselected (dependence on n and an independently allocated epsilon is allowed), and retain the actual row's fixed auxiliary amplitude T and kernel K0. Set

    H_v = K0_v/(kappa T),   low_t(v) = {w_t(v)<=H_v}.

Apply the already audited abstract cap-FTC and reciprocal-clock arguments with this H, rather than assigning a receiver probability. For terminal surviving targets G,

    positive traffic with low target <= M_G/e_g,
    M_G = integral_G H_v nu(dv).

For the disjoint part with high target and low terminal bad source B,

    Pi_t(B intersect low_t) <= M_B/e_t,
    positive traffic <= M_B integral m_t/e_t dlog(t) <= M_B/e_g,
    M_B = integral_B H_u nu(du),   m_t=Pi_t k_t.

Here all actual positive coefficients are bounded above by one, D+<=k_v, and the full actual m_t includes every current surviving source. The original time domain may have holes; only its nonnegative upper bound is enlarged. General nested deletion contributes positively to d(1/e), so it strengthens, rather than invalidates, integral_clock m_t/e_t<=1/e_g. This is a reciprocal-normalizer fact, not a negative-credit claim.

Preserve the same G/B labels until addition. Since G disjoint-union B=Z_g,

    union positive row <= (M_G+M_B)/e_g
       = integral_Zg K0 nu/(kappa T e_g)
       <= q/(kappa T e_g) < 1/(kappa sqrt(ell)).

The last strict inequality uses the actual inherited heavy condition T e_g>sqrt(ell) q. Thus the original outer 2 Lambda and Tsmall<=4 X give

    Raw_union <= 8 Lambda/(kappa sqrt(ell)) X.

Choosing kappa=8 Lambda/(epsilon sqrt(ell)) pays this identified positive piece with one separately allocated epsilon X slot. No receiver-selector cost is omitted: a uniform bound on each actual row is obtained before the outer integral, so fixed-parameter receiver normalization is not used. This is the complete two-ended K0-cap union; using the full-source upper bound separately on both legs would unnecessarily double its allowance.

Use >= in K0/(T w_t)>=kappa for the paid piece and < on each leg of the complement. If w_t=0 its original posterior mass is zero and is processed before division. Empty far windows and zero target contributions are processed first; T,e_g,q and kappa must have their actual positive-row qualifications before the displayed quotients. Kappa must not be reselected as a function of the running source or clock. Any row-dependent choice would require its exact remaining weight and a separate outer budget.

This dynamic cap is different from the R211 algebraic alpha0 repair using a=T Delta. It can be applied to the currently unpaid rho0/HH positive remainder; it does not authorize collecting again on already paid repair or two-low traffic. Negative is left entirely on the complementary signed domain. No strict new physically realized FULL instance, no payment for the both-low K0 complement, and no general root closure are certified at this stage.

## 4. Method scope and pending review

Applied H04 only for real-model, moment-domain, correlation and uniform-parameter discipline. Read its SKILL.md, provenance and cube-interface; no cited literature theorem, large-deviation/MDP asymptotic, Gaussian approximation or rate-function probability interpretation is used.

Pending: author proofs and precise mapping of the remaining both-high/both-low-K0 geometry, all source/selector weights, numerical evidence within its actual finite scope, and final integration. No final hash binding or future-driver success is claimed in this preliminary checkpoint.

## 5. Additive fixed cap — independent screen after resumption

Before reading any author proof, checked the parent's stronger cap

    H_v = L0 J_v/p_y + K0_v/(kappa T),

with common preselected L0,kappa>0 and the same actual row. All its fields are fixed with respect to the auxiliary clock. The same two-ended argument applies to this single cap, rather than independently choosing or summing two cap events. Retaining the time-fixed rho0 on terminal targets can sharpen the row bound to

    [integral_G rho0_v H_v nu(dv) + integral_B H_u nu(du)]/e_g
      <= L0 Q_J/(p_y e_g) + q/(kappa T e_g).

The original R212 J-column/high calculation and the uniform heavy-row calculation therefore give, with both contributions counted once,

    Raw_additive-cap <= 16 Lambda L0/(3K) W_A
                         + 8 Lambda/(kappa sqrt(ell)) X.

This replaces, rather than adds again to, the R213 two-low allowance. The additive cap event contains the union of the old individual cap events, but no strict physically realized FULL enlargement is asserted.

The exact unpaid complement is, on each leg z=v,u of positive posterior mass,

    j_z + K0_z/(kappa T w_t(z)) < 1,
    j_z = L0 J_z/(p_y w_t(z)).

Thus j_z<1, and for strictsoft positive kernels its spatial version is

    sum_i F_s(x,z) > n log(H0/Hhat) - log w_t(z)
                    - log kappa - log(1-j_z).

Keeping merely j_z<1 and K0_z/(T w_t(z))<kappa loses the additional correlated margin and is only a weaker necessary condition. The logarithmic correction depends on the same actual receiver, clock and source. The target must additionally satisfy its actual rho0/capture condition; the bad source must not inherit that condition. Pure-hard zero kernels use the original cap inequality or explicit extended-value conventions, not an unjustified finite logarithm. Negative stays once on this exact complementary signed object. No integral price for that object has yet been shown.

## 6. Joint physical moment candidate — premise check only

An author supplied a precise candidate before its proof. For fixed scales L/b=lambda and Hhat/b=eta in [1/2,1], fixed strictsoft s>0, fixed y,v,u, and exponents r,t,theta,chi>=0, write A=1+r+t and Theta=theta+chi. The same-x joint moment

    M = integral p_y^A J_v^{-r} J_u^{-t}
                    K0_v^{-theta} K0_u^{-chi} dx

has scaling b^{n Theta} times a product of genuine one-dimensional integrals. This is receiver-coordinate tensorization, not independent source sampling. Multiplying the two HH ratios and the two low-K0 ratios in the correct direction yields the advertised nonnegative event majorant with factors L0^{-(r+t)}, (kappa T)^Theta, and w_t(v)^{r+theta} w_t(u)^{t+chi}.

Its exact exponential tail domain is

    delta0 = A/lambda - (r+t) - Theta/eta > 0.

In particular Theta<1/2 gives delta0>=1-2Theta uniformly over the stated scale interval. If using weakened explicit lower bounds of the form exp(-(1+epsilon)|x|), the actual envelope gap is instead

    delta_epsilon = A/lambda
                    - (1+epsilon)[r+t+Theta/eta] > 0.

An epsilon chosen only from Theta cannot be uniform over unbounded r+t; its selection must retain the exponents or their declared compact range. The zero exponents remove their inverse factors; pure-hard s=0 cannot be assigned the strictsoft inverse-kernel bound. A common pointwise exponential envelope can legitimately bound receiver-adaptive parameters, but all scale constants, inverse-softness, exponential-in-n and source-displacement costs remain. The original posterior normalization, terminal masks, outer measure and actual source budgets are not paid by the moment identity itself. Awaiting full proof and actual use.

## 7. First full manuscript and evidence review

After the independent screens above, read mixed_cap_budget.md, the then-complete main proof.tex.txt, receiver_deficit_geometry.md (c959c68aabde73eca2d84eebd1431b5a4d65e6a7d92dd03235d773eaf2369f72), and the first complete coupled_receiver_moments.md in full. The mixed-cap main theorem and RD1–25 pass within the stated original-row scope. In particular:

* MC1/RD12 retain the actual G/B partition until addition, and keep the full posterior mean in the reciprocal-clock bound. Equality is paid, the strict complement is preserved, and no negative credit is consumed by these upper bounds.
* MC2/RD14 use the single hard constant 16/3, original high/FIRST column, unique j and fixed common-window J normalization in the correct order, yielding 16 Lambda L0/(3K) W_nu. The common-parent W_nu<=W_A is used without nu<=beta. Independent windows still require their actual summed costs.
* MC3/RD15 first produce a receiver-uniform actual-row bound from heavy and then use the original complete outer Tsmall<=4X. Its coefficient is 8 Lambda/(kappa sqrt(ell)); it must not acquire an extra 16/3 or replace the original X by an unrelated receiver integral.
* MC4/RD25 leave all available negative on the exact complementary signed object once. The new epsilon slot is separate from the R211 repair slot. The J component already contains and replaces the R212–213 low-J allowance, rather than adding it again.
* The two-end sum constraint, its log(1-j) correction, the target-only capture condition, actual w_t rather than w_g, strictsoft zero guards, and the conditional closed-core exclusion including lower clamp are stated correctly. The necessity is not advertised as a remaining integral bound.

The first complete CM4–12 joint moment proof, one-dimensional constants, epsilon choice and pointwise selector envelope also pass, subject to one requested wording correction: its initial CM11 sentence suggested that the delta0=0 boundary could be rescued by polynomial tails. That claim is not warranted for these strictsoft kernels and was sent to the author for narrow removal. Only the strict positive-gap domain is needed for the proof. The author also proposed a mixed-slack refinement; it was screened independently but final revised text is not yet recorded as reviewed here.

Read capacity_cap_checks.py, its entire numeric_notes.md and the final JSON structure without running the script. The recorded counts are nine finite four-source models (3/3/3), eighteen pure/additive cap budget evaluations and 69 recorded sum-not-union source/time witnesses. The actual clock normalizers, G={0,1}, B={2}, E-only deletion, cap crossing and derivative primitives, complete reciprocal-clock continuous integral plus positive deletion jump, and original pointwise double-Pi positive bounds are all represented. G/B capacities remain separate until addition. No negative balance is used.

The pure fixture chooses kappa=e_g/(4n M_all), then constructs K0=kappa T H and q=integral K0 nu; its stronger rational T e_g=4nq qualification is conditional algebra, not physical FIRST/history or the prescribed theorem kappa_n. The mixed J fields and q_mixed are separately defined. All nine pure fixtures pass the strong gate; the mixed fixtures n2_heavy_deleted_source, n4_correlated_coordinates, expanded_n8, expanded_n16 and expanded_n64 have the mixed strong-heavy diagnostic false. They must not inherit pure qualification or be called whole physical inputs. The notes correctly retain this distinction and call zero-J fields auxiliary algebra. The tests certify finite capacity/time-upper-bound arithmetic, not full original spatial traffic integration, selector adaptation, or general dimension order.

The three evidence hashes match the final author notification:

    capacity_cap_checks.py   1ceab120cdb08586c45ab165f42486337cfc6b491086cd323f28353ca28f310c
    capacity_cap_checks.json d847af905ecea1ab575236321b10d43ad4993398c4fb0bc7da96726e13d743f8
    numeric_notes.md         daf332f0c0561e877fb08695b10edc5499761c405839328caf07dcd2a599a767

The author reports an actual isolated script+contract replay, exit zero and whole-JSON byte identity, 0.055 seconds. This audit did not rerun it. The driver was statically reviewed: it checks a filename-to-hash manifest, rejects escaping paths, requires a fresh nonprotected JSON output, executes a relocated script+contract copy with the selected Python, compares complete JSON bytes, and rechecks source hashes. The future parent manifest-driven run is not claimed to have occurred.

Pending final revised CM text, final report and any integration updates, followed by actual final byte/hash binding. This remains an open audit, not a frozen final certificate.

## 8. Final integrated review and byte binding

Read final coupled_receiver_moments.md (02763c7ce7c0a11fa02bebeff575dbb8b3534207b4f9cce5889a05934c619fa4), including CM5a–d and the corrected CM11, after the complete first-version review. The requested endpoint wording correction is complete: only the strict positive-gap sufficient domain is invoked, without an unsupported endpoint claim. The mixed refinement passes: first retain the two same-x factors (1-a_v)^theta and (1-a_u)^chi on their actual common event; they are not coordinatewise tensor factors. Only subsequently use sup_{0<a<1} a^r(1-a)^theta = r^r theta^theta/(r+theta)^{r+theta}, with the explicit zero-exponent conventions, to obtain the product of the two scalar constants multiplying CM5. Boundary suprema are not falsely stated to be attained. Target-only capture, soft inverse, displacement, scale constants and original source/selector costs are retained. No suggested six-case physical moment quadrature was executed or certified this round.

Read the final report and the complete 131-line main TeX against the mixed-cap and receiver-deficit manuscripts. Main theorem, constants, sum-not-union complement, original fixed-row qualification, independent epsilon allocation, common-parent/window scope and all unconsumed negative-credit qualifications agree. The report accurately separates the proved additive-cap positive budget from the unpaid complementary signed object and near/other blocks. It reports actual finite conditional models and parent replay rather than a physical FULL realization or a future final-driver result. H04 is used only within the read method discipline, with no external asymptotic theorem borrowed. No further necessary mathematical or integration correction remains at the bound bytes.

Approved actual result is precisely

    Raw_paid <= (16 Lambda L0/(3K)) W_A
                    + (8 Lambda/(kappa sqrt(ell))) X,

on the original qualified row family, with a common preselected additive cap and the actual two positive legs combined before their source enlargement. At L0=K sqrt(n), kappa=8 Lambda/(epsilon_mix sqrt(ell)), this gives one (16 Lambda/3) sqrt(n) W_A plus one separately allocated epsilon_mix X. It already contains the earlier two-low J allowance. It does not establish the desired general bound, an economical selector joint-moment estimate, linear source payment for the mixed-cap complement, or a strict new FULL input instance.

The auditor performed static mathematical/code/JSON inspection and read-only digest calculations only. The numerical author and parent report actual script replays; these reports are not represented as auditor execution. No PDF compilation, numeric rerun, Git operation, new agent, or parent manifest-driven final replay was performed by this auditor. The final driver is statically accepted and awaits the parent's actual post-freeze run.

Actual directory count at binding: eleven regular files including this audit, with no manifest yet. The ten other files below were hashed from their current bytes. This audit and the future manifest are deliberately excluded, preventing a self-referential hash table. Any later byte change invalidates the corresponding binding and requires a narrow updated review.

| File | SHA-256 |
|---|---|
| capacity_cap_checks.json | d847af905ecea1ab575236321b10d43ad4993398c4fb0bc7da96726e13d743f8 |
| capacity_cap_checks.py | 1ceab120cdb08586c45ab165f42486337cfc6b491086cd323f28353ca28f310c |
| coupled_receiver_moments.md | 02763c7ce7c0a11fa02bebeff575dbb8b3534207b4f9cce5889a05934c619fa4 |
| mixed_cap_budget.md | be258569210b35c20405c337dbe8b57637c23fce8a84d4f1b8e2115f14aa11a6 |
| numeric_notes.md | daf332f0c0561e877fb08695b10edc5499761c405839328caf07dcd2a599a767 |
| proof.tex.txt | b4c9989eff3f6b67c19b06c781b997a26d87078644ec251a2857b469f080552e |
| receiver_deficit_geometry.md | c959c68aabde73eca2d84eebd1431b5a4d65e6a7d92dd03235d773eaf2369f72 |
| report.md | 77f375781842d988d9309b41f23a70022ea9a2b168e9a17712aa236d5c768448 |
| reproduce.py | 510eedf0be2761278de3aecf71a19ca78b357af0cbda8f0e8dfaa599d2124741 |
| task_contract.md | 0b792edffcf3e30440d2c12d77d75b2d0604cf2a653ca7165fd5f6e4880a16bb |

Final review frozen after rechecking this table against the actual files. No pending author correction remains.
