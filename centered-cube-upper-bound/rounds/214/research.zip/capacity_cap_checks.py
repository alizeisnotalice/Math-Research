#!/usr/bin/env python3
"""R214 exact conditional clock two-leg cap budgets, not spatial FULL data."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
Z=F(0)
G={0,1};B={2};E={3};ALL=G|B|E
LEFT=F(1,2);RIGHT=F(1);DELETE=F(13,20)
def dot(a,b):return sum((x*y for x,y in zip(a,b)),Z)
def w(cs,t):
    out=F(1)
    for c in cs:out*=min(F(1),c/t)
    return out

def cap_loss(cs,h,star):
    cuts=sorted(set([LEFT,RIGHT,star]+[c for c in cs if LEFT<c<RIGHT]))
    parts=[];total=Z
    for a,b in zip(cuts,cuts[1:]):
        mid=(a+b)/2;k=sum(c<mid for c in cs);prod=F(1)
        for c in cs:
            if c<mid:prod*=c
        gate=w(cs,mid)<=h
        assert (w(cs,a)<=h) if gate else (w(cs,b)>=h)
        value=prod*(a**(-k)-b**(-k)) if gate and k else Z
        assert value>=0
        total+=value;parts.append({'left':a,'right':b,'k':k,'closed_low_interior':gate,'integral':value})
    assert total==max(Z,min(w(cs,LEFT),h)-w(cs,RIGHT)) and total<=h
    return {'direct_piecewise_integral':total,'capped_endpoint_loss':max(Z,min(w(cs,LEFT),h)-w(cs,RIGHT)),'segments':parts}

def inverse_clock(nu,cs):
    def energy(t,ids):return sum((nu[v]*w(cs[v],t) for v in ids),Z)
    parts=[]
    for a,b,ids in ((LEFT,DELETE,ALL),(DELETE,RIGHT,G|B)):
        cuts=sorted(set([a,b]+[c for v in ids for c in cs[v] if a<c<b]))
        for lo,hi in zip(cuts,cuts[1:]):
            mid=(lo+hi)/2;e=energy(mid,ids)
            score={v:sum(c<mid for c in cs[v]) for v in ids}
            power_derivative=sum((nu[v]*w(cs[v],mid)*score[v] for v in ids),Z)/(e*e)
            kbar=sum((nu[v]*w(cs[v],mid)*score[v]/e for v in ids),Z)
            assert power_derivative==kbar/e
            value=1/energy(hi,ids)-1/energy(lo,ids)
            assert value>=0
            parts.append({'left':lo,'right':hi,'alive':sorted(ids),'integral_by_exact_FTC':value,'midpoint_direct_inverse_log_derivative':power_derivative})
    continuous=sum((p['integral_by_exact_FTC'] for p in parts),Z)
    jump=1/energy(DELETE,G|B)-1/energy(DELETE,ALL)
    difference=1/energy(RIGHT,G|B)-1/energy(LEFT,ALL)
    assert jump>=0 and continuous+jump==difference and continuous<=difference
    return {'segments':parts,'continuous_integral':continuous,'delete_inverse_jump':jump,'endpoint_inverse_difference':difference}

def cap_budget(nu,cs,h,stars,eg,inv):
    mg=sum((nu[v]*h[v] for v in G),Z);mb=sum((nu[v]*h[v] for v in B),Z);me=sum((nu[v]*h[v] for v in E),Z)
    loss=[cap_loss(cs[v],h[v],stars[v]) for v in sorted(G)]
    lossweighted=sum((nu[v]*loss[v]['direct_piecewise_integral'] for v in sorted(G)),Z)
    target_price=lossweighted/eg;bad_price=mb*inv['continuous_integral'];combined=target_price+bad_price
    assert combined<=(mg+mb)/eg<=(mg+mb+me)/eg
    probes=[]
    # Includes both exact cap crossing times: equality belongs to low.
    for t in sorted(set([F(11,20),DELETE,F(17,20)]+stars)):
        ids=ALL if t<DELETE else G|B
        ws=[w(c,t) for c in cs];e=sum((nu[v]*ws[v] for v in ids),Z)
        pi=[nu[v]*ws[v]/e if v in ids else Z for v in range(4)]
        k=[sum(c<t for c in cv) for cv in cs];kb=dot(pi,k)
        gl={v for v in G if ws[v]<=h[v]};gh=G-gl;bl={u for u in B if ws[u]<=h[u]}
        assert not gl&gh and gl|gh==G
        lowpositive=sum((pi[v]*pi[u]*max(0,k[v]-k[u]) for v in gl for u in B),Z)
        highbadpositive=sum((pi[v]*pi[u]*max(0,k[v]-k[u]) for v in gh for u in bl),Z)
        ftcdensity=sum((nu[v]*k[v]*ws[v]/e for v in gl),Z)
        badmass=sum((pi[u] for u in bl),Z)
        assert lowpositive<=ftcdensity and badmass<=mb/e and highbadpositive<=mb*kb/e
        assert all((ws[v]<=h[v])==(v in gl) for v in G)
        probes.append({'t':t,'alive':sorted(ids),'w':ws,'k':k,'Pi':pi,'e':e,'kbar':kb,'target_low':sorted(gl),'target_high':sorted(gh),'bad_low':sorted(bl),
            'target_low_positive_double_Pi':lowpositive,'target_low_FTC_density':ftcdensity,
            'target_high_badlow_positive_double_Pi':highbadpositive,'Pi_badlow':badmass,'badlow_posterior_bound':mb/e,'badlow_inverse_density_price':mb*kb/e})
    return {'H':h,'cap_crossing_times':stars,'M_G':mg,'M_B':mb,'M_E':me,'M_terminal':mg+mb,'M_all':mg+mb+me,
            'target_FTC_losses':loss,'target_low_FTC_price':target_price,'badlow_inverse_price':bad_price,
            'combined_two_leg_price':combined,'terminal_source_cap_price':(mg+mb)/eg,'all_source_cap_price':(mg+mb+me)/eg,'probes':probes,'passed':True}

def case(name,stage,n,nu,cs):
    starsk=[F(4,5),F(9,10),F(17,20),F(9,10)]
    starsmix=[F(3,5),F(7,10),F(13,20),F(7,10)]
    hk=[w(cs[v],starsk[v]) for v in range(4)];hmix=[w(cs[v],starsmix[v]) for v in range(4)]
    hj=[hmix[v]-hk[v] for v in range(4)];assert all(x>=0 for x in hj)
    eg=sum((nu[v]*w(cs[v],RIGHT) for v in G|B),Z);mall=dot(nu,hk)
    # Pick once as a conditional fixture parameter, not a claimed original kappa_n.
    kap=eg/(4*n*mall);tcap=F(1,2);k0=[kap*tcap*x for x in hk];q=dot(nu,k0)
    assert tcap*eg==4*n*q and tcap*eg>n*q and all(k0[v]/(kap*tcap)==hk[v] for v in range(4))
    inv=inverse_clock(nu,cs);pure=cap_budget(nu,cs,hk,starsk,eg,inv)
    assert pure['combined_two_leg_price']<=q/(kap*tcap*eg)<1/(kap*n)
    scales=[]
    for scale in (F(1,1024),F(1),F(1024)):
        st=tcap*scale;sk=[x*scale for x in k0];sq=q*scale
        assert all(sk[v]/(kap*st)==hk[v] for v in range(4)) and st*eg>n*sq
        assert sq/(kap*st*eg)==q/(kap*tcap*eg)
        scales.append({'scale':scale,'T':st,'K0':sk,'q':sq,'q_over_kappa_T_eg':sq/(kap*st*eg)})
    mixed=cap_budget(nu,cs,hmix,starsmix,eg,inv)
    p=F(1);l0=F(1);j=hj;jsum=dot(nu,j);qmix=max(q,jsum)
    assert all(hmix[v]==hj[v]+hk[v] and hj[v]==l0*j[v]/p for v in range(4))
    additiveprice=dot(nu,hj)/eg+dot(nu,hk)/eg
    assert mixed['terminal_source_cap_price']<=additiveprice==mixed['all_source_cap_price']
    witnesses=[]
    for probe in mixed['probes']:
        for v in probe['alive']:
            ww=probe['w'][v]
            assert (ww>hmix[v])==(hj[v]/ww+hk[v]/ww<1)
            if ww>hj[v] and ww>hk[v] and ww<=hmix[v]:
                witnesses.append({'t':probe['t'],'v':v,'w':ww,'H_J':hj[v],'H_K':hk[v],'H_mix':hmix[v]})
    return {'name':name,'stage':stage,'n':n,'nu':nu,'C':cs,'terminal_G':sorted(G),'terminal_B':sorted(B),'deleted_E':sorted(E),'delete_time':DELETE,
            'e_g':eg,'T':tcap,'kappa':kap,'K0':k0,'q_pure':q,'strong_heavy_T_eg_gt_n_q':tcap*eg>n*q,
            'heavy_scope':'n>=sqrt(1+log n) for integer n>=1; the stronger rational gate is checked. kappa chosen for this conditional model, not original kappa_n.',
            'inverse_clock':inv,'pure_K0_cap':pure,'pure_budget_q_over_kappa_T_eg':q/(kap*tcap*eg),'external_coefficient_diagnostic_Lambda_one':{'eight_times_capacity_price':8*q/(kap*tcap*eg),'strong_heavy_upper_coefficient':8/(kap*n),'scope':'Coefficient only; no original outer X measure constructed.'},'q_T_rescalings':scales,
            'mixed_fields':{'p':p,'L0':l0,'J':j,'J_nu':jsum,'q_mixed':qmix,'K0_nu':q,'H_J':hj,'H_K':hk,'H_mix':hmix,
                'heavy_for_mixed_q_diagnostic':tcap*eg>n*qmix,'sum_source_prices':additiveprice,'sum_not_union_witnesses':witnesses,'cap_budget':mixed,
                'scope':'Separate conditional additive fields, not a common spatial kernel. Pure-q heavy is not transferred to q_mixed; zero J slots are auxiliary algebra.'},
            'negative_credit_used':Z,'passed':True}

def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,list):return [encode(v) for v in x]
    return x

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'capacity_cap_checks.json');args=ap.parse_args()
    base=[[F(9,20)],[F(7,10)],[F(1)],[F(1,4)]]
    rows=[case('n1_equal_mass','initial',1,[F(1)]*4,base),case('n1_unequal_mass','initial',1,[F(1),F(2),F(3),F(1,2)],base),
          case('n1_swapped_background_scores','initial',1,[F(1)]*4,[[F(9,20)],[F(7,10)],[F(1,4)],[F(1)]]),
          case('n2_heavy_deleted_source','stress',2,[F(1),F(1),F(1),F(2**20)],[c*2 for c in base]),
          case('n2_rare_target','stress',2,[F(1,2**40),F(1),F(2**20),F(1,16)],[c*2 for c in base]),
          case('n4_correlated_coordinates','stress',4,[F(1)]*4,[c*4 for c in base])]
    for n in (8,16,64):
        cs=[[F(1,4) if j%3==0 else F(9,10) for j in range(n)],[F(7,10) if j%2==0 else F(1) for j in range(n)],
            [F(1) if j%3 else F(1,2) for j in range(n)],[F(1,2**(j%8+1)) for j in range(n)]]
        rows.append(case('expanded_n'+str(n),'expanded',n,[F(1,2**20),F(3),F(1024),F(1,16)],cs))
    witnesses=sum(len(r['mixed_fields']['sum_not_union_witnesses']) for r in rows)
    assert witnesses>0
    result={'schema':'R214_capacity_cap_Fraction_v1','inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
            'counts':{'models':len(rows),'pure_and_mixed_caps':2*len(rows),'sum_not_union_recorded_witnesses':witnesses},'models':rows,'all_passed':True,
            'scope':['Finite complete min-product clock/cap/source arrays, no spatial K0/J/high/FIRST/history/FULL realization.',
            'Two positive legs are disjoint by target low/high; equality belongs to low. No negative balance is used.',
            'Target-low time flux is bounded by an independently integrated capped clock loss; bad-low time flux by exact inverse-clock FTC. These are time-integrated upper certificates, not sampled-time integrals of original traffic.',
            'Pure and additive cap fields distinguished; their q/heavy qualifications are not silently interchanged. No dimension-order fit or general theorem certification.']}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(encode(result),sort_keys=True,indent=2)+'\n')
    print(json.dumps(result['counts'],sort_keys=True)+' PASS')
if __name__=='__main__':main()
