# R214：同一来源的 J–K0 加法帽与双端接收缺陷

状态：证明原完整 far 正交通的一项联合预算。以同一真实行的加法帽
`H_z=L0 J_z/p_y+K0_z/(kappa T)`，两端至少一端满足 `w_t(z)<=H_z` 的全部正交通，只需一次来源价和一次独立接收误差：
`16Λ L0/(3K) Wν+8Λ/(kappa sqrt ell)X`。
预定 `L0=K sqrt n`、`kappa=8Λ/(epsilon_K sqrt ell)` 后，费用为 `16Λ/3 sqrt n WA+epsilon_K X`。原负余额完整仅留补集一次。

这个付款同时保留共同来源质量、真实归一化分母和实际 K0/FIRST；它不把静态低 K0 支持误作尾概率。补集满足两腿共同的加法单纯形约束，因而 R213 的坐标缺陷获得额外的真实 J-slack 项。一般补集 signed 预算尚未闭合。

## 1. 原对象及本轮不变的资格

使用 R212–213 冻结原式、R213 `two_ended_cap.md` TC1–4 的倒分母时钟，以及 R211 `joint_capacity.md` JC1–3、JC8–9、JC19–30 的实际 heavy 和完整 rho 基线替换。R211 JC22–25、JC28–30 已再次窄读：其所付对象是 `a delta-rho<=G_U J/Q_J` 的恢复，与本稿动态加法帽的原正交通不同，不能重复调用同一恢复额度。

固定原合法共同窗口、有限 signed 截断及实际行
`(omega,V,j,x,y,硬源z0,history)`。记
\[
 p=p_y=P_{s,L}(x-y)>0,\quad J_z=P_{1,b}(x-z),\quad
 Q_J=\int J_z\,d\nu(z),\quad K_{0z}=P_{s,\widehat H}(x-z).
\tag{RD1}
\]
原当前 selector、终端 g、同源 alpha0、capture E、FA、suffix Ψ、remaining 指示和历史保持实际值。它们即使由原 rho 决定，也不根据 rho0 或新帽重选。完整正基线权仍为
\[
 \rho_{0v}=1_E(v)
 \left(1-\frac{DK_{0v}+(Dq/Q_J)J_v}{T\Delta_v}\right)_+,
 \quad\Delta_v=w_\tau(v)-w_h(v),\quad h<g.
\tag{RD2}
\]
零 `Q_J,p,e_g,T` 或空 far 行按原定义先隔离，不写零乘无穷。原有效 strict-soft 范围为 `0<s<=1`；有限距离的 J、K0 严格正。

终端集合 `G=S_g,B=D_g` 是同一 `Z_g` 的不交划分。实际 far 内侧区间记 `(l,r) subset [tau,h]`，两集合的来源在整个区间存活。后验为
\[
 d\Pi_t(z)=e_t^{-1}1_{Z_t}(z)w_t(z)d\nu(z),\quad
 -\frac{d w_t(z)}{d\log t}=k_t(z)w_t(z),\quad0\le k_t\le n.
\tag{RD3}
\]
原 `Z_t` 递减，`e_t>=e_g>0`。定义 `m_t=int k_t dPi_t`。一般删除包括连续、奇异连续及原子部分；在原有限正窗上
\[
 d(1/e_t)\ge(m_t/e_t)d\log t,
 \qquad\int_l^r\frac{m_t}{e_t}\frac{dt}{t}
 \le\frac1{e_r}-\frac1{e_l}\le\frac1{e_g}.
\tag{RD4}
\]
这是同一个真实分母的单调链式法则，不将 Pi 视为固定概率。只使用实际区间内侧端点；若原账不包含端点删除，本稿不恢复它。

所需原容量/资格是
\[
 \int K_0d\nu\le q,\quad Q_J\le q,\quad
 p e_g\ge2Kq,\quad T e_g>\sqrt\ell\,q,
 \quad\ell=1+\log n.
\tag{RD5}
\]
最后一项是 R211 已重新核实的完整原 heavy，不由较弱 high 反推。若另行删掉该 heavy，本稿接收误差付款不获授权。

## 2. 一般同钟加法帽及两端一次合账

预先固定 `L0>0,kappa>0`，可依维数和已分配误差选定，但不随正在积分的 target、bad 来源、t 或事后后验重选。定义
\[
 H_z=\frac{L_0J_z}{p}+\frac{K_{0z}}{\kappa T}.
\tag{RD6}
\]
H_z 可以依同一行的 x,y 和实际 selector；关键是其在该行辅助 t 中固定。以下所有估计先逐真实行完成，才进行外层积分，因此不需要假定 K0 或 H_z 独立于 x。

将原正交通中集合
\[
 \mathcal C_H(t)=\{w_t(v)\le H_v\}\ \cup\ \{w_t(u)\le H_u\}
\tag{RD7}
\]
分成两个不交片：target 低的整片，以及 target 高而 bad 低的片。门相等纳入已付片，严格大于留补集。所有原正门和 rho0 均先保留；仅为正上界才放松不超过1的因子。

记
\[
 M_G=\int_G\rho_{0v}H_vd\nu(v),\qquad
 M_B=\int_BH_ud\nu(u).
\tag{RD8}
\]
目标 v 终端存活，物理权单调且 AC，故
\[
 \int_l^r1_{\{w_t(v)\le H_v\}}k_t(v)w_t(v)\frac{dt}{t}
 =\big[\min(w_l(v),H_v)-w_r(v)\big]_+\le H_v.
\tag{RD9}
\]
等号平台的 k_t w_t 为零，阈值跨越无额外 dt 原子。用 `D_t^+=(kv-ku)+<=kv`、实际 u 后验质量不超过1、`e_t>=e_g`，target 低片的行交通至多
\[
 R_{L*}\le\frac1{e_g}\int_G\rho_{0v}
 [\min(w_l(v),H_v)-w_r(v)]_+d\nu(v)
 \le M_G/e_g.
\tag{RD10}
\]

另一方面，bad 低片的实际后验质量满足
\[
 \Pi_t(B\cap\{w_t\le H\})
 \le M_B/e_t.
\]
于是 target 高、bad 低片由 RD4 得
\[
 R_{HL}\le M_B\int_l^r\frac{m_t}{e_t}\frac{dt}{t}
 \le M_B(1/e_r-1/e_l)\le M_B/e_g.
\tag{RD11}
\]
这里 m_t 是完整原后验的 score 均值，不是人为删掉 E_t 后重归一的均值。原未终端存活来源对归一化的影响仍在 RD4 中；删除只增加该倒分母预算。

**共同来源是关键。** 两片分别保自己的 G、B 容量，最后才相加：
\[
 \begin{split}
 R_{\mathcal C_H}
 &\le\frac{M_G+M_B}{e_g}\\
 &\le\frac1{e_g}\int_{Z_g}H_zd\nu(z)
 \le\boxed{\frac{L_0Q_J}{p e_g}
             +\frac{q}{\kappa T e_g}.}
 \end{split}
\tag{RD12}
\]
不把两项分别放大成全 nu 后再加倍。可保 RD10–11 作为更锐的真实损失与归一化增量；也可保 RD8 中 rho0 的同 alpha 信息。最后一次上放并不声称该信息无用，只是足够得到本轮的付款。

该引理仅需要原终端目标权在 `[0,1]`；在当前应用中它是完整 rho0，未乘一个额外 J-share。没有使用任何原负信用。

## 3. 完整原外积分：来源价与接收价分别结算

完整外测度为
\[
 d\mathcal T=1_I1_{\{j(x)=j\}}q^{-1}p h_R(x-z_0)a_\omega
 \,dx\,\beta_V(dy)\nu_V(dz_0),\qquad
 \mathbb E\sum_{V,j}\int1_{high}d\mathcal T\le4X.
\tag{RD13}
\]
X 保持原定义；不另认成所有接收域的 `int q dx`。真实 dx、hard 来源、期望、V/j 和所有窗口均在此。

对 RD12 的 J 项采用 R212 的实际来源列证明：一次使用 hard 帽 `q^-1 h_R nu<=16/3`，再用
\[
 \int1_{high}\frac{d\beta_V(y)}{e_g(y)}
 \le\frac1{2Kq}\int p\,d\beta_V\le\frac1{2K}.
\]
原唯一 j 指示保至 J 不再含 j 后才求和；固定窗口的 `int J nu_V dx=||nu_V||` 最后使用。因此
\[
 2\Lambda\,\mathbb E\sum\int1_{high}
 \frac{L_0Q_J}{p e_g}\,d\mathcal T
 \le\frac{16\Lambda L_0}{3K}W_\nu
 \le\frac{16\Lambda L_0}{3K}W_A.
\tag{RD14}
\]
共同父预算不需要 `nu<=beta`。

对 K0 项不使用这个 hard 帽或一个 K0 的 receiver 包络，而先在原行用 heavy：
\[
 \frac{q}{\kappa T e_g}\le\frac1{\kappa\sqrt\ell}.
\]
然后仅用 RD13 的完整原外测度，得到
\[
 2\Lambda\,\mathbb E\sum\int1_{high}
 \frac{q}{\kappa T e_g}\,d\mathcal T
 \le\frac{8\Lambda}{\kappa\sqrt\ell}X.
\tag{RD15}
\]
因此实际联合正片满足
\[
 \boxed{Raw_{\mathcal C_H}^{+}
 \le\frac{16\Lambda L_0}{3K}W_A
       +\frac{8\Lambda}{\kappa\sqrt\ell}X.}
\tag{RD16}
\]
两项是同一正上界的两个可积部分，分别使用其有效外账；没有为 K0 部分额外乘 `16/3`，也没有把 J 的固定空间列套给自适应 K0。

预先分配一个新的 `epsilon_K>0`，取
\[
 L_0=K\sqrt n,\qquad
 \kappa_n=\frac{8\Lambda}{\epsilon_K\sqrt{1+\log n}}.
\tag{RD17}
\]
则 RD16 为
\[
 Raw_{\mathcal C_H}^{+}
 \le\frac{16\Lambda}{3}\sqrt n\,W_A+\epsilon_KX.
\tag{RD18}
\]
新 kappa 只是同一实际正积分的预定分类参数；不改变原 epsilon_RC、D、capture 或历史。它没有重用 R211 恢复的 epsilon 槽。R213 的 J 低片已包含在 RD7 中，其来源价由 RD14 一次替换，不再另加旧的 `16Λ/3 sqrt n WA`。

所有独立窗口仍须用其原共同来源/外测度合账。如果 RD13 只对某个窗口族成立，就只对该族应用 RD15；不能逐窗免费复用同一个 X。时间和删除已由 RD9、RD4 结算，没有再收 time-menu，也没有把原尺度 selector 改成固定参数来省费。

## 4. 比独立两门更准确的共同补集

加法帽正支包含旧 J 低门和单独 K0 动态高门，但还包含两项分别小于1、和已经达到1的真实中间区域。这里只证明包含关系与同价付款，不凭代数开集宣称额外 FULL 输入严格实例。

补集对两腿 z=v,u 都满足
\[
 \frac{L_0J_z}{p w_t(z)}+
 \frac{K_{0z}}{\kappa T w_t(z)}<1.
\tag{RD19}
\]
原 Pi 的正质量支上 `w_t(z)>0`。令
\[
 j_t(z)=\frac{L_0J_z}{p w_t(z)}\in(0,1).
\]
则 RD19 等价于
\[
 \frac{K_{0z}}{T w_t(z)}<\kappa(1-j_t(z)),\qquad z=u,v.
\tag{RD20}
\]
这里 p、T、J、K0、w_t 均来自同一个实际 receiver 行。既不独立化两来源，也不把实际 t 的 w_t 替换成 w_g。

原 R213 物理归一为
\[
 a_s=1-s+s\varphi(1/2),\quad H_0^nT=a_s^n,\quad
 R_H=H_0/\widehat H,
\]
\[
 \mathcal D_s(x,z)=\sum_i\log\frac{a_s}{f_s(|x_i-z_i|/\widehat H)},
 \qquad K_{0z}/T=R_H^n e^{-\mathcal D_s(x,z)}.
\tag{RD21}
\]
故已付片补集得到两端共同的精确必要阈值
\[
 \boxed{\mathcal D_s(x,z)>
 n\log R_H-\log w_t(z)-\log\kappa
 -\log(1-j_t(z)),\qquad z=u,v.}
\tag{RD22}
\]
新项 `−log(1−j_t(z))` 是原 J 与 K0 共享来源容量留下的真实 slack，不是先对两项各取最坏值。原 HH 的 J 比值越接近其阈值，这项越大。它始终在同一门内使用；跨越 `j_t>=1` 的来源已由 RD7 支付，不能对其继续写这个对数。

目标 v 仍须另满足原同 alpha0 条件。若 `rho0>1−eta`（`0<eta<=1`），定义
`eta_eff=eta−alpha0 J_v/(T Delta_v)>0`，则其缺陷还严格大于
\[
 \log(D/\eta_{eff})+n\log R_H-\log\Delta_v.
\tag{RD23}
\]
因此目标阈值可取 RD22 与 RD23 的最大值；bad u 不属于 capture E，不能把 RD23 同样套给 u。

## 5. 原闭核/外部距离的双端后果与限制

复用 R213 的精确分解，记
`r_i(z)=|x_i-z_i|/Hhat`，`O_z={i:r_i>.5}`，`m_z=|O_z|`，
\[
 J_s=\log\frac{a_s}{s\varphi(1/2)},\quad
 V_z=\sum_{i\in O_z}(r_i-.5),\quad
 D_{in,z}=\sum_{i\notin O_z}\log\frac{f_s(r_i)}{a_s}\ge0.
\]
外尾 log-hazard 在 `[1,8]` 内，故
\[
 \mathcal D_s(x,z)\le m_zJ_s+8V_z-D_{in,z}.
\]
结合 RD22，补集每腿都必须满足
\[
 m_zJ_s+8V_z>
 n\log R_H-\log\kappa-\log w_t(z)
 -\log(1-j_t(z))+D_{in,z}.
\tag{RD24}
\]
两式相加保留 `−log(w_t(v)w_t(u))` 与
`−log[(1-j_t(v))(1-j_t(u))]`，而原双后验恰含同一个 `w_t(v)w_t(u)/e_t^2`。这是下一步应共同处理的物理乘积，没有在此付掉倒 e 或获得来源独立性。

闭 Hhat 核内 `K0/T>=R_H^n`。所以若预定 kappa 在某原行满足 `kappa<=R_H^n`，RD20 的两腿都被迫位于该闭核之外。未夹断/上夹断时 `R_H>=1`，因而 `kappa<=1` 足够；下夹断 `R_H<1` 则必须保完整条件，不能统一排除闭核。RD17 不保证所有有限 n 都有 kappa<=1；只有相应维数条件成立才用这一推论。

s=1 时 J_s=0，尾距离仍保留；0<s<1 的硬面 r_i=.5 按原 closed h 归内部。本文不把自适应 selector 的这些面删为零，也不把 Hhat 外部坐标数换成物理时钟 score k_t。若要延伸至 s=0 或 K0=0 槽，应回到 RD19 的无对数不等式，并另作零核约定；本稿不授普通有限对数公式。

## 6. 原 signed 回代及尚缺的唯一联合付款

在原有限 signed 截断上，正项按 RD7 与其严格补集不交分配，而全部负余额保持原位：
\[
 2\Lambda(P_0-N_{avail})
 \le\frac{16\Lambda}{3}\sqrt n W_A+\epsilon_KX
       +2\Lambda(P_{\rm simplex}-N_{avail}).
\tag{RD25}
\]
`P_simplex` 是同一原 RT1/双 Pi 积分，仅加上两腿 RD19；所有 remaining、FA、suffix、rho0、good/bad、真实 dx 与独立窗口费用仍在。原 rho 到 rho0 的 R211 恢复若回接，只额外加其已经单独分配的一份费用，不能按 share 或窗口重复。

本轮真正新增的吸收是 RD15–18，并且加法帽把原已付 J 片与它同价共同覆盖。尚未证明的是 `P_simplex-N_avail` 的根阶来源预算或更小接收吸收。其首个几何接口已具体化为 RD22–24：两个同点 K0 缺陷同时超过各自真实 clock/J-slack 阈值，目标再含同 alpha0 的 RD23。

仅有 `int K0 nu<=q` 不能支付这两个低 K0 比值事件；它提供大核的上容量，不能反向估计低核后验质量。也不能以核级空间积分代替原 `p beta(dy) Pi_t(dv)Pi_t(du)` 的联合列：真实 `e_t^-2`、selector 与门必须留到一个合法共同上界中。若将剩余写成 R212 constant-good 势，原实际内侧端点、suffix 泄漏、完整删除变差和已消费负信用差同样不能消失。

因此本稿没有把新的单纯形补集改名成已付量；它交付的是可直接代入原积分的一次新增 epsilon 付款，以及由同一付款强制出的更尖锐双端空间条件。一般上界仍开放。
