# R149 ell-capacity numerical result

The compact exact producer certifies the frozen finite-model question: using one source allocation across each receiver's whole window, replace the common `Lg` factor by the receiver/source `ell_v` built from the complete receiver-specific terminalbad set. The six-source denominator remains intact, and the same `nu`, `rho`, score segments, and original FA caps are used.

All 179 receiver rows pass individually. Their exact rational conservative budgets use `eta_v` rounded upward to multiples of `1/10^9`; the maximum is approximately `0.16566870955001697` at I1 id 244. The maximum rounded `eta_v` upper bound is approximately `0.132320307`. This establishes each row's saved 690-cap full-coverage budget is at most one. These budgets are per distinct receiver row and must not be summed across the 179 rows.

| Original stage | I1 rows / maximum budget | P1 rows / maximum budget |
|---|---:|---:|
| initial | 2 / 0.16566870955001697 | 25 / 0.0003210143454152042 |
| pressure | 0 / — | 5 / 0.00032083593865753207 |
| expanded | 9 / 0.1619282906399436 | 138 / 0.0003211364486099013 |

The implementation checked all 2,214 row/source/score-segment extrema entries. There are three unique receiver-specific bad patterns; each has one compact certificate, linked by every row using it. All 2,214 segments have zero interior critical roots in this saved model. Exact Fraction Sturm counts establish root completeness; the derivative sign is constant on each segment, so its supremum is selected at a one-sided segment endpoint. Per-source eta lower and upper brackets are exact rational floor/ceiling multiples of `1/10^9`. The producer then uses the upper endpoints in every source budget and `a_v=b_v/mu_v`, verifies `sum(mu_v a_v)=sum b_v<=1`, checks all 690 original cap identities against the R147 archive, and re-evaluates every cap cost with exact rationals.

The main result was compacted from a complete expanded JSON preserved outside the repository: `/Users/zhengzhihao/Desktop/T/output/r149_full_ell_capacity_exact_20261015.json`, SHA256 `7e066a1b9a794c8c4437ffaab8d1bfd6bf7888b608cf69ddc9915ecf0ac05bdd`. The final JSON is about 1 MB. There were seven producer attempts: six completed runs and one failed compact-schema attempt caused by an empty endpoint-candidate list on zero-source segments; the zero branch was handled explicitly before the final run.

Frozen input fingerprints:

- R148 archive: `b8c8ab5a2f335dacfffd9463aeea46cb1a06f706cfce8864186fdef9da1d3f2d`
- R148 `optimal_budget.json`: `f4c64bba9dc750de21b5a1129bdff74dc098e425c7967e8f7a3110b893d4bec0`
- R147 archive: `b04c96e209e7d37342909dc8aea42c18913c930573779aff7c8728de38eef0f1`
- R147 `time_coverage.json`: `589b2a37ffca9a5c0a801c435c8d4918f0fd6a1d16fec519ef2dc088cbf3c0de`
- R136 `active_traffic_v2.json`: `1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de`
- R142 `numeric_receiver.json`: `c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55`

The computed claim is limited to full coverage of the original finite FA cap model for these saved rows. It does not assert a continuous-x, arbitrary-`nu`, or general root-order result. Independent Sol review is requested for the root/extremum and fixed-allocation certificate.
