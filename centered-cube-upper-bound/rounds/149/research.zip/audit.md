# R149 Sol 独立审计：真实 score-qualified bad 通量系数

状态：按主代理最新优先级，先不研究随机混合、不读作者稿。只审转发的新 \(\ell(v)\) 命题；唯一写本文件，不 Git、不改他人文件。原固定预算门及外价沿 R147/R148 已审合同。

## 1. 量词与准确原交通

固定实际 \(R=(\omega,V,j,x,y)\)，在整条内部时间窗和外 hard 来源积分前固定同一原 \(\nu,Q,p,q,G,D_0,\rho\) 及接收参数。沿原定义
\[
d\mu(v)=Q_vd\nu(v)/q,\quad
r_t(v)=KQ_v/[pw_t(v)],\quad
L_t=Kq/(pe_t),\quad L_g=Kq/(pe_g)\le1/2.
\]
\(\mu\) 为原来的子概率、不是重新归一化来源；准确地
\(d\Pi_t=1_{Z_t}L_t\,d\mu/r_t\)，\(L_t\le L_g\)。
E=\(G\cap\{\rho>0\}\subset Z_g\) 的来源在原 \([\tau,h]\) 全窗存活。置 \(z_v(t)=\rho_v/r_t(v)\)，这里 z 不是外 hard 来源。
\[
-dz_v(t)=k_t(v)z_v(t)\frac{dt}{t},
\]
且 z 连续非增；原 terminal \(\rho_v\) 不随 t 重算。

原 terminal 正项的 bad 源必须确实包含于本式的 \(D_0\)。本合同只支付 \(G\times D_0\) 的原正交通；非 terminal bad／futurebad／删除源若属别槽仍保留，不能因本式而删掉。额外原 \(\Psi\)、FA、history、旧已付补集门可留在左边，证明上界时仅用其非负且至多 1。

## 2. 新系数与零分支

定义同一原 posterior 上
\[
B_t(v)=
\begin{cases}
\displaystyle\int_{D_0}\frac{[k_t(v)-k_t(u)]_+}{k_t(v)}d\Pi_t(u),
&k_t(v)>0,\\[4pt]0,&k_t(v)=0,
\end{cases}
\]
\[
\ell(v)=\operatorname*{ess\,sup}_{t\in[\tau,h]}L_tB_t(v).
\]
这个 \(\ell\) 不应与旧对数长度或似然比符号混用。逐行
\[
0\le B_t(v)\le\Pi_t(D_0)\le1,\qquad0\le\ell(v)\le L_g.
\]
它保留实际 bad 后验及真实 \(\delta/k_v\) 资格，没有把小 \(\nu(D_0)\) 当作小 posterior，也没有重新归一化 bad 来源。

\(k_t(v)=0\) 时所有正 \(\delta\) 为零，B 定义为 0，不计算 \(0/0\)。\(\ell(v)=0\) 时 \(L_tB_t(v)=0\) 对几乎处处 t 成立，因而该来源的原正时间交通为零；不能仅凭一个采样时间 B=0 就归零。零 \(\ell\) 无需分配正预算或作除法。有限正商以外仍沿原零交通约定。

本版本先不把 FA 放进 B。若以后加入原 pair 门，必须证明该门与 B 在外 hard 来源积分前共同定义、不依正在积分的 hard z；依 hard z 的 history 不能不声明地放入本 \(\ell\)。

## 3. 可测 ess-sup 与不同来源的零测时间

假设原 \(\Pi_{R,t}\) 是原合同给出的可测概率核，\(D_0(R)\)、score 和参数均可测，则 \((R,v,t)\mapsto L_tB_t(v)\) 联合可测。对任何有理 \(\eta\ge0\)，
\[
\{\ell(R,v)>\eta\}
=\left\{(R,v):
\int 1_{\{\tau(R)\le t\le h(R)\}}
1_{\{L_tB_t(v)>\eta\}}\frac{dt}{t}>0\right\}.
\]
故 \(\ell\) 是联合可测函数。空窗定义 \(\ell=0\)；可测变端点也可用固定 log-time 参数化处理。这里使用的是 dt/t 本质上确界，不是对不知可测性的全部点 t 取任意 supremum。

对每个 v，\(L_tB_t(v)\le\ell(v)\) 的例外 t 集可以不同。非负 Tonelli/Fubini 使其在原 \(\mu_R(dv)\,dt/t\) 中为零，不需假设一个同时适合全部 v 的共同零集。原 \(\nu,\mu,\Pi_t\) 不因取 ess-sup 改变；\(\ell\) 虽依 v 和 receiver R，仍在整条时间窗固定。

## 4. 一般固定源预算的精确估计

选非负联合可测 \(a(R,v)\)，不按当前 t、bad u 或外 hard z 重选，且
\[
\int_E a(v)d\mu(v)\le1.
\]
在 \(\ell>0,a>0\) 上置 \(c(v)=a(v)/(2N\ell(v))\)。新原正子支为
\[
\Omega_{\rm new}
=\Omega_{\rm rem}\cap
\{\ell>0,\ a>0,\ z_v(t)\le c(v)\}.
\]
零 \(\ell\) 来源可另列为原时间交通零项，是否并入门不改变积分；a=0、\(\ell>0\) 的来源不收正交通。

固定外 hard 来源后，先对同一 \(\Pi_t(u)\) 积分，删额外正门给
\[
\begin{aligned}
I_a
&\le\int_Ed\mu(v)\int_\tau^h
k_t(v)z_v(t)L_tB_t(v)
1_{\{z_v(t)\le c(v)\}}\frac{dt}{t}\\
&\le\int_E\ell(v)d\mu(v)
\int_\tau^h k_t(v)z_v(t)1_{\{z_v(t)\le c(v)\}}\frac{dt}{t}\\
&=\int_E\ell(v)
[\min(z_v(\tau),c(v))-\min(z_v(h),c(v))]d\mu(v)\\
&\le\int_E\ell(v)c(v)d\mu(v)
\le\frac1{2N}.
\end{aligned}
\]
这不是对 bad posterior 作人工衰减，而是用其原真实通量系数的整窗上界。每个来源只用一次 \(\ell c=a/(2N)\)，不为各时间片复制原 \(\mu\) 预算。非负积分可先截断，避免无穷量相减。

## 5. 是否真扩大原确定正支

令 \(m=\mu(E)\)。m=0 时由 \(\Pi_t\ll\mu\) 原正交通为零。m>0 时取原均分预算 \(a=1/m\)，新门等价于
\[
\boxed{r_t(v)\ge2Nm\,\ell(v)\rho_v.}
\]
与旧门 \(r_t\ge2NmL_g\rho_v\) 使用同一个原 m、\(\mu,\rho\)。因 \(\ell\le L_g\)，新门逐点包含旧门（零 \(\ell\) 仅为零交通另支）。若某来源 \(\ell<L_g\) 且新增区间有真实 bad/FA/\(\Psi\) 正交通，便确实扩大了**原确定正项**的可付范围，无须随机混合，也不只是分数覆盖权。

一般没有证明这种严格扩大在每个输入发生，更没有证明新门补集无正交通。新全窗充分预算变为
\[
a_{\rm full}^{new}(v)=2N\ell(v)\rho_v/r_\tau(v),
\qquad
\int_Ea_{\rm full}^{new}d\mu\le1
\]
仍须实际证明；不能从 \(\ell\le L_g\) 自动得到后一个 \(1/N\) 大小。若数值检查，须保留原全时间坏后验／score 及全部正门，不能只用点值估 ess-sup。

## 6. 与原 soft 接收外价的合法接合

本预算 a 与 \(\ell\) 可随实际 receiver 参数自适应；证明固定的是一个实际 x 内的整条时间曲线，没有冻结 x 选择器。上一节已把来源与真实时间消为不依 x、j、u、v 的共同数值 \(1/(2N)\)，所以按既有合同依次：

1. 保留原 hard 资格，以 \(q^{-1}\int h_Ra_\omega d\nu(z)\le16/3\) 得 \(8/(3N)\)；
2. 来源和时间消尽后才合并唯一 j；
3. 用同一固定尺度带的原 JT13 soft/L 接收包络 \(3(2n+3)D_n\)。

故
\[
2\Lambda P(\Omega_{\rm new})
\le16\Lambda\frac{(2n+3)D_n}{N}W_\beta.
\]
N 在该 soft/尺度带事先固定，取 \(N=2n+3\) 后为 \(48\Lambda\sqrt nW_\beta\)。不再乘时间 \(\log2\)，不新增 \(\ell\) 的参数菜单；跨带/层级仍按原 Wβ 合同汇总，不能额外复制质量。若 N 又随来源或当前 t 自选，不能直接沿用这个共同帽。

## 7. 负项与后审风险

新 gate 仅分割原正交通：
\[
P-N_{\rm old}=P1_{\Omega_{\rm new}}
+P1_{\Omega_{\rm new}^c}-N_{\rm old}.
\]
原 \(\rho,\alpha,Q,\nu,e_t\) 全部保持，负项不附新门、不重复领取或返还；futurebad、\(N_{del}\)、terminal 外坏源及全部未覆盖部分仍按原账保留。

后审需核：D0 真是该正槽的全部 bad 域；\(\Pi_t\) 与 source budget 同一原 \(\nu\)；\(\ell\) 真是整窗本质上确界而非若干时间点最大；零 \(\ell\)/零 k 分支无错误除法；a 和 \(\ell\) 在外 hard z 前固定。若这些满足，本命题是可使用的一般加权正支估计并可真扩确定门；它不解决剩余补集或一般总目标。预审结束，等待主路线后审。

## 8. posterior_capacity 作者稿首审

已读父稿 posterior_capacity.md；本轮新的一般预算证明与第 1–6 节独立推导一致。它按原 \(\Pi_t\) 先积 bad，保留真实 \(L_tB_t(v)\)，再用每个来源整窗固定的 \(\ell(v)\) 与 FTC。零 k/零 \(\ell\)、本质上确界的可测性及 Tonelli 例外集处理均正确。主门与旧 \(L_g\) 门的包含关系是原确定正支的包含，没有以随机平均冒充并集。

在给定 R148 near-soft 联合包络 \(\le32\sqrt n N_k\) 的接口下，常数也正确：源时间 \(1/(2N_k)\)、hard \(16/3\)、signed \(2\Lambda\) 合成 \(16\Lambda/(3N_k)\)，再乘该包络即 \((512/3)\Lambda\sqrt n\) 每带。far 用旧全参数包络得 \(48\Lambda\sqrt n\)。N 必须是该带共同固定的 N；原层级不可复制 Wβ。这里不重做另一审计者负责的 near-soft 包络证明。

覆盖目标的 \(c_{\min}(v)=\operatorname{ess\,sup}_{t\in F_v}\rho_v/r_t(v)\) 是固定下阈值门覆盖该实际正时间支持的最小帽。用 \(\bar\ell\ge\ell\) 形成 \(a_{\rm full}=2N\bar\ell c_{\min}\)，只给**足够预算**：原定理实际帽为 \(a/(2N\ell)\ge c_{\min}\)。它不是原带门流量最优分配，也不证明一般全覆盖；父稿已使用这个正确方向。

已向主代理提出三项最终表述核对：

1. 若原 history 依外 hard z，F_v 必须先在原 nonnegative 外 hard/history 权及全部 bad 源上聚合实际时间密度，再取 dt/t ess-sup。不能对每个正在积分的 hard z 各选一个 \(c_{\min}\)，却套同一个外 z 前固定预算。
2. “旧 full 预算乘 \(\bar\eta=\bar\ell/L_g\)”仅在**同 N** 时成立。若旧数据用 \(N_{\rm old}=2n+3\)，新 near 带用 \(N_k\)，正确重算为
\[
b_{\rm full}^{new}
=(N_k/N_{\rm old})\,(\bar\ell/L_g)\,b_{\rm full}^{old}.
\]
也可先把旧 full 成本重算到 \(N_k\)，再乘 \(\bar\eta\)。
3. 新增几何覆盖只有新旧门差集；若本轮记账选择整个新覆盖的重述费用，base 应先删其他 old high/FA/TOP 等，但不要把被替代的对应 \(L_g\) 门再累计旧费。完整替换与差集另付这两种安全记账不能混用。

数值的 \(\ell\) 必须取完整原 \([\tau,h]\)，包含无 FA 正交通的时间/score 段、score 跳点两侧极限以及原删源造成的 e 变化；不能用 FA 内部点或单点 B 值替代。对 finite 保存模型可给有理根区间包络，但那不认证真实核。按主代理分工，本审计不重复全菜单数值，等待最终稿修订及独立数值审计结论后绑定。

## 9. posterior_capacity / research 最终双稿绑定

最终 SHA-256：

- posterior_capacity.md：03f87cacfb69eec0794c41a43c739679c847f79e379b90a95150e93a06ddf6c8
- research.tex：80e14812ad99ec46ca0b11841140bb5ea2307a0e94561f6069299504f3715088

已读修订全文和 TeX，检查数学对应及第 8 节提出的三点，不重复全菜单数值：

1. F_v 明确先按全部 bad 与依赖的外 hard/history 原正权聚合，预算及阈值仍在当前 hard z 积分前统一固定。覆盖 F 的最小 c 与使用 \(\bar\ell\) 的**足够**来源预算区分正确，没有把它当真实流量最优分配。
2. 同 N 的旧 full 成本乘 \(\bar\ell/L_g\) 与改用 \(N_k\) 时附加 \(N_k/N_{\rm old}\) 均已明确。当前有限 n=4/16 检查沿 Nold；不能将其他带的 N 成本默认照搬。
3. 新的几何只增加差集；最终费用明确替换 R147–148 相应 \(L_g\) 完整覆盖条目。其他旧 high/FA/TOP 先剔除，不能将被替代旧门费用再次叠加。TeX 的总价和这个记账方式一致。

新系数定理、固定源预算、零 k/零 \(\ell\)、联合可测 ess-sup/Fubini、原归一化、确定门包含及负项身份都与独立第 1–7 节一致。N 在 near-soft 每带共同固定后，整体安全价
\[
[48+(512/3)(K_n+1)]\Lambda\sqrt nW_\beta
\]
的代数因子正确；小维回退用 48。near-soft 包络接口沿用原已审结果，本审计没有重新把其来源平均或菜单当作免费常数。

两稿均明确只处理 terminalgood→terminalbad 正槽，保留严格补集、futurebad、\(N_{del}\) 与其余未付项。它们没有以有限保存模型全覆盖推出一般输入闭合，也未把 \(\ell\) 的 sup 见证时刻当成当前时刻。数值完整区间证书另由分配的审计者负责，本审计不越过该范围宣称已独立认证其真实核精度。

**最终判定：双稿在声明范围通过，第 8 节三项风险已修复，无剩余更正。** 本轮是可使用的一般确定正子支扩大及其完整外价；一般总目标仍未证明。未进行随机混合扩展，未重跑数值或 LaTeX，未 Git、未改他人文件；本次范围结束。


