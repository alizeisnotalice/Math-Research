# R149 数值方案与证书合同（仅方案；未启动producer）

本文件独占交付。已读R148 `optimal_budget_notes.md`、`optimal_budget_plan.md`、`early_geometry_notes.md`、R149 `r148_research.tex`；未重复179条来源优化，未新抽样。证书检查采用已读 `math-l03-rational-and-interval-certificates/SKILL.md` 的方向约定；该技能明确未验证通用向外舍入浮点区间API，故以下精确核证要求有理区间/多项式证书，不能只用多精度相合。

## A. 真实连续x接收诊断：已有入口与最小下一实验

明确新问题：R148逐receiver最优来源预算仍有I1残量；该残量在固定同一ν的真实x空间中，是否集中在很小接收测度，或在正接收体积上持续存在？这不同于再次优化原179记录。原179=11 I1+168 P1，其记录权之和不是dx。

已找到最近且实际执行过的入口：

- `rounds/142/research.zip` 中 `numeric_receiver.py`、`numeric_receiver_plan.md`、`receiver_sampling_proof.md`、`receiver_contract_audit.md`、`numeric_receiver.json`。可读原副本位于 `/Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015/centered_cube_round142_20261015/`。
- 原输入 `centered_cube_round136_20261014/active_traffic_v2.json` SHA256 `1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de`；R141 `numeric_joint.json` SHA256 `acafcde85224fc1e5e2e9663f00e5233ead8daa8adb0d7382ce3436bb0b7618b`。R142脚本 `Model.__init__/scan/traffic/mp_record` 已实现固定共同ν、真实核x扫描、实际标签及rho/alpha重建；不要直接import其主程序或运行原菜单。
- R142已做6951接收点，含6912随机点；新实验不重复该菜单。它的uniform盒只覆盖CORE盒，p抽样估计p dx，F/p均值才对应dx；条件统计界很宽，非区间核证。
- 与历史代理交叉定位：R89 `receiver_probe.py` 是有限节点hard判别；R128 `receiver_numeric.py/receiver_verify.py` 是另一套有理盒源/接收几何的精确体积及弱型下界，不是原同一ν/FIRST/history实现。未找到已实现全部FULL历史的producer；这只是限定搜索结果，不声称它不存在。

可执行的最小连续空间方案限原I1(n=4)固定一份ν，先冻结R142 I1的最高复核控制节点所选源质量、六源位置、s/L/Hhat/Lplus/b/R/y、tau/h、所有来源时间阈值及固定lambda=q(x0)。不更换ν或逐x重选lambda。扫描域取全部六源hard接收立方体的并集（hardmass=0外部主F恒零），以有理面坐标分割互不重叠4维盒；不能只扫对角线或CORE盒。连续盒内重算p,K0,K1,K2,J,Q=(K1+K2+J)/3、三测试q、hardmass、good/bad、E、U、alpha、rho、所有原FA与Psi。完整共同e和全时间保留，不冻结G1/G4角色。

同一盒上同时输出：真实F_whole；旧共同分配残量；能证的最佳固定来源残量上下界（若已证明新ℓ门则另列该门残量）。各量乘实际p·hardmass/q，积分按盒Lebesgue体积dx；另列p dx质量，不能混为dx。这样局部覆盖缺口与空间质量分开呈现。不得以有限点“正”代替正体积：要么有一个所有门及正交通下界严格成立的有理子盒证书，要么保持未决。

先验误差合同：有理盒区间包围所有真实E3核值、门、FA根和时间原函数；门跨零的盒细分，预算耗尽的盒保留[0,解析F上界]乘真实盒体积，计入总误差。已经有R142真实E3公式和R143时间primitive，但**尚无本次核读确认的向外舍入E3/闭式log/atan区间实现**，不能将float64或70位一致性冒称盒证书。若暂做cubature，只能报告有界必要模型的数值估计及未认证误差，不能输出确定空间结论。先做n4，不因稀有性开启n16高维新菜单。

FULL缺项明确为原omega/V/j/forest历史、a_omega/history门、真实Z_t删除及top/light资格、连续FIRST而非三测试必要条件、原beta及其外预算/unique j的实现。没有这些对象时此实验仍是原核必要模型接收诊断，不能认证一般FULL或根阶预算。

## B. 父策略优先实验：精确计算固定ell，不重新优化a

新问题明确：将原Lg粗帽改成同一row、同一source整窗固定的ell_v，原真实FA全覆盖所需预算是否降到1内？输入仍是完整179原接收记录、同一ν、rho/alpha、receiver位置、原Q三核、原time与FA/Psi；不添加或删除来源。

对原terminalbad集合（不是只取实际FA eligible G4）定义

    B_t(v)=sum_{u terminalbad}(1-k_u(t)/k_v(t))_+ Pi_t(u),  k_v=0时取0;
    ell_v=esssup_{t in [tau,h]} L_t B_t(v),   eta_v=ell_v/Lg.

全六源共同e_t=sum nu_u c_u t^(-k_u)保留。由Lg=Kq/(p eg)，有精确消去式

    eta_v = eg * max_{全部score段及单侧端点} S_v(t)/e_t^2,
    S_v(t)=sum_terminalbad nu_u c_u t^(-k_u) (1-k_u/k_v)_+.

故无需将小p/q相除再求sup；eta只依原ν、eg、score c/k与原terminalbad标签。须保持receiver的bad集合；不能用“某source在原FA中不出现”从terminalbad中删除它。eta应满足0<=eta<=1；用Lt<=Lg与B<=1核对。score边界按各段单侧极限纳入；端点孤点不改变esssup，但邻域极限可能达到最大。

### B1. 代数极值与证书

每score段核验score为0,d,2d的子集（原I1/P1符合，仍须逐段断言），置u=t^d；写e=P(u)/u^r，S=H(u)/u^r，则S/e²=N(u)/P(u)^2，N=u^r H。所有输入按保存十进制转Fraction，P在正闭区间有严格正下界。候选集完整包括左右端和多项式

    D(u)=N'(u)P(u)-2N(u)P'(u)

在内部的全部实根。D恒零则该段为常数；S=0/kv=0单独返回0。端点有理，内根用精确Sturm计数、平方自由分解和有理隔离区间；在每隔离区间用有理区间包住N/P²并向外返回，端点精确评估。保存多项式系数、根数/隔离盒、所有候选值上下界及最终eta上下界。不能只做time网格、浮点root筛选、或比较端点。若希望先用浮点定位，可以提议隔离区间，但最终根完整性和包围须独立核验。

eta_v整窗固定，不依当前t、inner bad或outer hard源变化。FA/Psi不进入ell的定义；若另做仅FA限制版本，必须另名并另证原预算，不混用本版本。

### B2. 无优化的全覆盖判别

直接复用R148 `optimal_budget.json` 每row的 `full_coverage_source_b`，它等于

    old_bfull_v=max_{该v所有原正FA cap} 2N nu_v rho_v w_v(lo)/eg.

空交通source取0；这不删其ν、e、terminal membership。每source新最小预算为

    new_bfull_v=old_bfull_v*eta_v;
    C_new=sum_v new_bfull_v.

依据w非增，firstFA端点确为该v的最大门成本；多个FA cap要取最早有效端点，不以最后cap覆盖前面时间。与原表达 `mu_v*2N ell_v rho_v/r_first(v)` 逐source交叉核对，mu=Qnu/q。保留N=2n+3。本实验只检新门全覆盖可行性，不重复R148 active-subset来源收益优化。

用eta上端构造保守固定allocation：b_v=old_bfull_v*eta_v.upper，a_v=b_v/mu_v（零mu按零交通分支处理，不做0/0）。若sum b<=1，保存精确预算与每原cap的门包含证书；此为充分的保存模型全覆盖证明。若C_new.lower>1，证明本ell门全覆盖不可行；不能推论其它策略不能付。若区间跨1，只细化根盒，最后仍跨则标未决；不可作为失败或全覆盖。

ell为0的source若同时存在正FA交通需立即报合同矛盾（正delta、正Pi_bad应强迫ell>0）；不得用0门分母。原rho/FA/Q核保存小数仅认证同一冻结模型，不提升成真实核机器区间证书。

### B3. 输入、输出与核证交接

- R148 `research.zip::optimal_budget.json`：179行的case/id/stage/distribution、mu/rho/Q/q/p/eg/Lg、原bfull逐source与总成本；旧I1成本1.07715016423至1.25202785049仅作输入对照。
- R147 `research.zip::time_coverage.json`：原179名单、Gplus、所有完整原FA cap、whole/paid历史对照；不得根据残量筛掉P1。
- R142 `numeric_receiver.json`：按(case,id,stage,distribution)精确联接原x、good/bad、alpha、核与FA，使用R148 producer相同读取层级/原记录，不在mp复核副本之间随意替换。原receiver SHA `c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55`。
- R136 `active_traffic_v2.json`：精确原source位置/threshold/c/k/wg；ν按R142每case的 `nu_exact` 复原，不回退到未调质量的R136默认ν。R148原producer已有读取与比对函数，可读而不import顶层执行。
- 新producer应只有一份ell脚本、结果JSON、说明；保存archive/member/input/script/plan SHA、完整179计数(11 I1/168 P1)、完整690 cap计数相容性、所有失败/未决与producer次数。只报逐row可付、C_new区间和有限记录结果，不给dx百分比或一般定理阶数。
- 核证需独立重算：候选根完备、eta包含及<=1、端点方向、固定a预算、原cap全覆盖。实现者可用精确有理多项式库，但不能依赖浮点优化状态。审核者不重复producer的“同代码再次执行”冒充独立代数证书。

本文件是设计及输入定位；未运行新ell、cubature或179优化，未新增核、未改他人文件、未Git。等待父代理决定是否交由实现代理执行，当前数值方案工作停止。

## B4. 父审允许的简化证书（执行监督追加）

不必研发Sturm或求精确最大值。若每段N、P系数非负，P>0，则任意有理子区间[a,b]上可直接认证

    N(a)/P(b)^2 <= N(u)/P(u)^2 <= N(b)/P(a)^2.

精确有理自适应分割保存所有叶盒并检查无缝覆盖整段，最大叶盒上界给该段sup上界，任一端点实际值给sup下界。系数有负号时可用有理Horner区间且验证分母正性。只要保守C_new.upper<1，已足够构造固定a及认证全FA覆盖，不要求精确eta或最优成本；跨1才继续细分或报告未决。此前B1的完整驻点证书是可选精确路线，不是唯一验收条件。

本轮保存n4/16沿用Nold=2n+3，故C_new=Σold_bfull eta。若将来改为Nk，成本必须再乘Nk/Nold；不能将原Nold成本直接宣称新门准确最小成本。核证只认证保存有理模型，不提升原核小数输入为真实区间。
