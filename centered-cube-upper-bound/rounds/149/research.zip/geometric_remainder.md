# R149：新 bad 容量门补集的共同三核与储备局部化

状态：GR4–GR8 是原共同 ν/α 上可核验的几何必要条件和真实接收上界；没有证明该上界具有统一根阶外价，不登记一份新增付款。父稿的 bad 容量 FTC 门另行付款，本稿不重复其证明或领取其费用。主体处理其严格补集。

## GR1. 精确待证积分、旧工具及反例边界

沿 R148 的合法原行 (ω,V,j,x,y)，p=P_{s,L}(x-y)，Q_v=Q_x^*(v) 为原三核平均，Q_E=∫E₊Q_v dν，μ=Qν/q，m=Q_E/q，E₊=S_g∩{ρ>0}。N=N_n(1−s) 是 R148 已付 softness 分层中的固定层常数。保持原 ν、α、ρ、good/bad、high、FA、Ψ、low-c、history 和实际 hard 窗口。

父稿新增定义为

\[
B_t(v)=\int_{D_0}\left(1-\frac{k_t(u)}{k_t(v)}\right)_+d\Pi_t(u),\qquad
\ell_v=\mathop{\rm ess\,sup}_{\tau\le r\le h}L_rB_r(v),
\quad L_r=\frac{Kq}{pe_r}.
\tag{GR1}
\]

k_t(v)=0 时 B_t(v)=0。ℓ_v 整窗固定，不依外 hard 来源 z。0≤ℓ_v≤L_g；ℓ=0 来源无正交通。父稿门 r_t(v)≥2Nmℓ_vρ_v 包含 R148 门。本稿唯一余域 Ω− 为原未付正域再交

\[
r_t(v)<2Nm\ell_v\rho_v,
\quad\text{等价于}\quad
Q_v<\frac{2Np}{Kq}Q_E\ell_v\rho_vw_t(v).
\tag{GR2}
\]

待证的是完整原积分

\[
2\Lambda\,\mathbb E\sum_{V,j}\int\frac pq h_R(x-z)a_\omega(x,y,z)
\rho_v\delta_t(v,u)1_{\Omega_-}\Psi\chi_{FA}
\,dx\,d\beta_V(y)\,d\nu(z)\,d\Pi_t(v)d\Pi_t(u)\frac{dt}{t},
\tag{GR3}
\]

其余原资格未写入公式的部分均包含在 Ω− 中。目标是 O(Λ√n polylog(2+n))Wβ，或原允许的可吸收 εX 加该项。不是要求每个 x 行得到 O(1/N) 帽。

允许工具：R147 固定预算密度定理；R148 连续 (s,L) 接收包络及分层费用；原共同 bad 余额 αQ_J≥D∫D₀K₀dν；R136 AB1–AB2 的同行 CS 机制。下文直接核算所用 CS，不将旧 AB2 的核尾或接收费用视作已付。R148 的两源端点只是否定必要约束层的逐行小量；其 Q、ρ 未实现完整三核/α/history，不能作为 GR3 的 FULL 反例。此处不再展开该端点。

## GR2. 保留共同 bad 余额的实际逆核矩

在 E₊ 上 A_v=w_τ(v)−w_h(v)>0，令

\[
a_v=\left(1-\frac{DK_{0,v}}{TA_v}\right)_+,
\qquad \rho_v=a_v-\frac{\alpha J_v}{TA_v}>0.
\tag{GR4}
\]

这里是实际 α，不逐来源优化。对 k_r(v)>0 定义

\[
\mathcal H_r(v)=\int_{D_0\cap Z_r}
\left(1-\frac{k_r(u)}{k_r(v)}\right)_+^2
\frac{w_r(u)^2}{K_{0,u}}\,d\nu(u),
\qquad
\mathcal S_v=\mathop{\rm ess\,sup}_{\tau\le r\le h}
\frac{\mathcal H_r(v)}{e_r^4}.
\tag{GR5}
\]

k_r(v)=0 的切片对 H 与 S 贡献置0。D₀ 的严格低-score 来源才贡献；没有把 ν 当作概率。原实际 s>0 使 K₀,J 正，零来源行先按原约定处理。所有积分可先在原有限截断上进行；S=∞ 只给扩展上界，不认证有限价格。

同一 α 余额和 CS 给

\[
B_r(v)\le\frac1{e_r}
\sqrt{\int_{D_0}K_0d\nu}\sqrt{\mathcal H_r(v)}
\le\frac1{e_r}\sqrt{\frac{\alpha Q_J}{D}}\sqrt{\mathcal H_r(v)}.
\]

乘 L_r 并取同一整窗上确界，得到

\[
\boxed{\ell_v\le\frac{Kq}{p}
\sqrt{\frac{\alpha Q_J}{D}}\sqrt{\mathcal S_v},}
\qquad
\boxed{\rho_v\ell_v\le\frac{Kq}{p}
\sqrt{\frac{TA_vQ_J}{DJ_v}}\,
\rho_v\sqrt{a_v-\rho_v}\sqrt{\mathcal S_v}.}
\tag{GR6}
\]

第二式只代入 GR4；仍保留实际 ρ。若进一步放松，ρ²(a−ρ)≤4a³/27，恢复与 AB2 相同的 sharp 标量常数 2/(3√3)，但本稿主式不作这一步。α=0 时原正 soft 下 bad 质量为零，因而 B=ℓ=0，相关交通为空；不计算 0·∞。

## GR3. 新严格补集必须满足的三核联合几何条件

把 GR6 代入 GR2，再平方。所有因子均非负且原余域上正，q、p、K 准确消去：

\[
\boxed{Q_v^2J_v
<4N^2Q_E^2\,w_t(v)^2\frac{TA_vQ_J}{D}
\rho_v^2(a_v-\rho_v)\,\mathcal S_v.}
\tag{GR7}
\]

这不是自由 Q 比值的必要约束模型：Q_v 是实际三核，Q_E 是同一接收点、同一 E₊、同一 ν 的积分，J、K₀、a、A、ρ、S 都来自原相同几何及 α。尤其 ρ 接近 a 时，原储备因子 a−ρ 必须保留；把它独立替成1会丢掉共同 bad 余额提供的限制。

令

\[
\Xi_t(v)=\frac{4N^2Q_E^2w_t(v)^2TA_vQ_J}
 {D Q_v^2J_v}\,\rho_v^2(a_v-\rho_v)\mathcal S_v.
\tag{GR8}
\]

则 Ω−⊂{Ξ_t(v)>1}。由于原 Q_v≥J_v/3，另有较松的必要条件

\[
J_v^3<36N^2Q_E^2w_t(v)^2\frac{TA_vQ_J}{D}
\rho_v^2(a_v-\rho_v)\mathcal S_v.
\tag{GR9}
\]

GR7 比只保留 good 的单一 Q/J 门更细，保留全部三核共同容量；GR9 仅显示此处至少需要抵消三个 J 次幂所代表的来源/接收尾比。它们都是必要条件，不是 Ω− 的等价替换，也不是已付充分门。

一个明确的排除证书是：若实际行/来源满足 Ξ_t(v)≤1，则该时刻不可能属于新严格补集。这一证书不需要另选 α 或 ν。未证明一般行都满足它。

## GR4. 原 FA 低门可以留在当前 bad 矩

父稿 ℓ 使用 GR1 的完整 B，因此 GR5 的整窗 S 不得悄悄换成更小的 FA 矩。另一方面，GR3 的**当前时刻**正积分确实含原 FA 低门

\[
\delta_t(v,u)>\frac{r_t(v)}{K B_{FA}}.
\]

对 k_t(v)>0，定义

\[
\mathcal H_t^{FA}(v)=\int_{D_0\cap Z_t}
\left(\frac{\delta_t(v,u)}{k_t(v)}\right)^2
1_{\{\delta_t(v,u)>r_t(v)/(KB_{FA})\}}
\frac{w_t(u)^2}{K_{0,u}}d\nu(u),
\tag{GR10}
\]

k=0 时取0。同一次 CS 给当前原 FA 交通

\[
\rho_vk_t(v)B_t^{FA}(v)
\le\frac{\rho_vk_t(v)}{e_t}
\sqrt{\frac{\alpha Q_J}{D}}\sqrt{\mathcal H_t^{FA}(v)}.
\tag{GR11}
\]

Ψ 和其他正门可留在原定义中，只在此上界使用其≤1。GR10 的 gap 是实际 r_t；不是无门 δ² 矩，也没有把两份 e_t 合成一份。

## GR5. 可审的真实接收上界与完整尚欠费用

先在原 GR3 中只放松外 z 相关额外正门，保留 aω 并用实际 hard 帽16/3。以 GR7 局部化，再对当前 bad 来源使用 GR11。任意固定 θ>0 都有

\[
\begin{aligned}
2\Lambda P(\Omega_-)
\le\frac{32\Lambda}{3}\mathbb E\sum_{V,j}
\int &p\,dx\,d\beta_V(y)\frac{dt}{t}\,
\frac{\sqrt{\alpha Q_J/D}}{e_t^2}\\
&\times\int_{E_+}\rho_vk_t(v)w_t(v)
\sqrt{\mathcal H_t^{FA}(v)}\,
\min\{1,\Xi_t(v)^\theta\}\,d\nu(v).
\end{aligned}
\tag{GR12}
\]

右侧保留原实际 j 选择、原合法时间窗、softness 层和剩余单点资格；它们在显示式中省略但不删除。证明只有非负 Tonelli、原 hard 帽、GR6–GR11 和 1_{Ξ>1}≤min(1,Ξ^θ)。未选 θ 值来声称收敛或新付款。

GR12 是带真实接收几何的可审上界：新增因子明确依赖原 Q_v²J_v、共同 Q_E²、原 bad 的 K₀ 逆矩以及实际储备因子，不能把它当作一个新的无定义能量。它至多改善历史 AB2/CS 上界，未承诺严格改善每个输入。原两份后验在此准确留下 e_t^{-2}，另一个 e_r^{-4} 仅位于定义 ℓ 的整窗 S 中；r 与 t 是两个可能不同的时间。

**尚欠的准确全局估计**是 GR12 右侧（连同原全部选择器）≤εX+Cε√n polylog(2+n)Wβ。当前没有这一结论。具体不能执行的步骤是

\[
\int p(x-y)\,Q_E(x)^2\,F_x(v,u)\,dx
\ \not\le\ \bigl(\sup_x Q_E(x)^2\bigr)
                  \times\text{一份免费的来源概率费用},
\]

其中 F 包含 1/(Q_v²J_vK_{0,u}) 的相应幂、真实 w/e 和 α。Q_E 的 E₊ 与参数均依 x；FIRST 只给 Q_E≤q，而原 high 给的是 e_g 的下界，不给替换这些逆矩所需的来源后验负权矩上界。分别对 good 尾、bad 逆 K₀ 和 Q_E 取上确界会再次丢失要支付的共同来源/接收关联。固定参数的 R136 分数核积分即使适用，仍须保留其维数、soft、尺度及来源归一费用；不能由它直接宣布 GR12 已付。

因此本稿没有重复要求逐行 O(1/N)，没有免费合并仍含 S、Π、α 的 j，也没有将 GR12 的未定量命名成可付预算。原负项不参与抵扣。

## GR6. ℓ 大的见证时间约束：排除错误的早晚拼接

若某个实际 r 满足 L_rB_r(v)≥ηL_g，0<η≤1，则

\[
\frac{e_r}{e_g}\le\frac1\eta,
\qquad
\Pi_r(D_0\cap\{k_r(u)<k_r(v)\})
\ge B_r(v)\ge\eta\frac{e_r}{e_g}\ge\eta.
\tag{GR13}
\]

证明为 L_r/L_g=e_g/e_r，且 B_r≤严格低-score bad 后验质量≤1。故 ℓ_v 大必须由总 e_r 已接近终端 e_g、且 bad 后验质量不小的时刻见证。不能一面用极早时的大 w_t/w_g 放大来源，另一面把仅在晚时达到的 ℓ_v 当作同一时刻的容量。另一方面，GR2 的低 r_t 时刻未必是此见证时刻；GR13 本身未支付二者之间的完整通量，故本稿在 GR5 中显式保留两个时间。

本轮交付的实质范围为：GR6 的共同储备矩帽、GR7 的新严格补集几何局部化、GR10–GR12 的原 FA 与真实 dx 上界，以及 GR13 的见证时间约束。它们适用于一般原来源，但尚未闭合一般根阶付款；父稿已经证明的 ℓ 门费用独立保留一次。
