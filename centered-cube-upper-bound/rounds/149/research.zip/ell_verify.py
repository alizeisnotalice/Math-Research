#!/usr/bin/env python3
"""Independent rational Bernstein verifier; no producer import or floating kernels.
Only certifies the frozen 179-row necessary model, not FULL or a dx integral.
"""
import argparse
from fractions import Fraction as F
from pathlib import Path
from math import comb
from zipfile import ZipFile
import hashlib,json,sys
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent

def sha(data): return hashlib.sha256(data).hexdigest()
def pe(p,x): return sum(v*x**k for k,v in enumerate(p))
def derivative_ratio(S,P):
    z=[F(0)]*4
    for i,s in enumerate(S):
        for k,p in enumerate(P):
            if i+k: z[i+k-1]+=(i-2*k)*s*p
    while len(z)>1 and z[-1]==0: z.pop()
    return z

def bernstein(p,a,b):
    n=len(p)-1
    q=[sum(p[i]*comb(i,k)*a**(i-k)*(b-a)**k for i in range(k,n+1)) for k in range(n+1)]
    return [sum(q[k]*F(comb(i,k),comb(n,k)) for k in range(i+1)) for i in range(n+1)]

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input-root',default='/Users/zhengzhihao/Desktop/T/output')
    ap.add_argument('--certificate',default=str(ROOT/'ell_capacity.json'))
    ap.add_argument('--archive148',default=str(ROOT.parents[1]/'148/research.zip'))
    ap.add_argument('--archive147',default=str(ROOT.parents[1]/'147/research.zip'))
    args=ap.parse_args();base=Path(args.input_root)
    src_bytes=(base/'centered_cube_round136_20261014/active_traffic_v2.json').read_bytes()
    rec_bytes=(base/'centered_cube_round142_20261015/numeric_receiver.json').read_bytes()
    assert sha(src_bytes)=='1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de'
    assert sha(rec_bytes)=='c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55'
    cert_bytes=Path(args.certificate).read_bytes();j=json.loads(cert_bytes)
    src={c['id']:c for c in json.loads(src_bytes)['cases']};rec=json.loads(rec_bytes)
    with ZipFile(args.archive148) as z: old_bytes=z.read('optimal_budget.json')
    with ZipFile(args.archive147) as z: cap_bytes=z.read('time_coverage.json')
    old={(r['case'],r['id']):r for r in json.loads(old_bytes)['records']}
    caprows={(r['case'],r['id']):r for r in json.loads(cap_bytes)['records']}
    assert len(old)==len(caprows)==179
    counts=dict(rows=0,segments=0,positive_vsegments=0,zero_vsegments=0,derivative_Bernstein_strict_sign=0,caps=0)
    maxcost=F(0);maxconservative=F(0);maxeta=F(0);patterns={};seen=set();signs={}
    for row in j['rows']:
        cid=row['case'];key=(cid,row['id']);assert key not in seen;seen.add(key)
        c=src[cid];case=rec['cases'][cid]
        nu=[F(int(x['numerator']),int(x['denominator'])) for x in case['nu_exact']]
        r=next(x for x in case['records'] if x['id']==row['id']);o=old[key]
        assert all(bool(r['bad'][i])!=bool(r['good'][i]) for i in range(6))
        bad=[i for i in range(6) if r['bad'][i]];pattern=cid+':'+','.join(map(str,bad));patterns[pattern]=patterns.get(pattern,0)+1
        eg=sum(nu[i]*F(c['atoms'][i]['wg']) for i in range(6));assert eg==F(o['e_g'])
        assert row['stage']==r['stage']==o['stage'] and row['distribution']==r['distribution']==o['distribution']
        N=2*c['n']+3;assert row['N']==N
        assert all(F(o['rho'][i])==F(str(r['rho'][i])) for i in range(6))
        assert all(F(o['Q'][i])==F(str(r['Q'][i])) for i in range(6))
        assert F(o['p'])==F(str(r['p'])) and F(o['q'])==F(str(r['q']))
        assert all(F(o['mu'][i])==nu[i]*F(str(r['Q'][i]))/F(str(r['q'])) for i in range(6))
        d=min(k for s in c['score_segments'] for k in s['k'] if k>0);etas=[];upper=[]
        assert F(c['score_segments'][0]['lo'])==F(c['derived']['tau'])
        assert F(c['score_segments'][-1]['hi'])==F(c['derived']['h'])
        assert all(F(c['score_segments'][i]['hi'])==F(c['score_segments'][i+1]['lo']) for i in range(len(c['score_segments'])-1))
        for v in range(6):
            vals=[]
            for si,s in enumerate(c['score_segments']):
                counts['segments']+=1;ks=s['k'];cs=list(map(F,s['c']))
                assert all(k in (0,d,2*d) for k in ks)
                P=[sum(nu[i]*cs[i] for i in range(6) if ks[i]==rank*d) for rank in range(3)]
                S=[sum(nu[i]*cs[i]*(1-F(ks[i],ks[v])) for i in bad if ks[v]>ks[i] and ks[i]==rank*d) if ks[v] else F(0) for rank in range(3)]
                a=F(s['hi'])**(-d);b=F(s['lo'])**(-d);assert 0<a<b and pe(P,a)>0
                if any(S):
                    counts['positive_vsegments']+=1;B=bernstein(derivative_ratio(S,P),a,b)
                    assert all(x<0 for x in B) or all(x>0 for x in B),(key,v,si,'not monotone')
                    counts['derivative_Bernstein_strict_sign']+=1
                    sg='+' if all(x>0 for x in B) else '-';signs[cid+':'+str(tuple(bad))+':'+str(v)+':'+str(si)]=sg
                else: counts['zero_vsegments']+=1
                eta=max(eg*pe(S,x)/pe(P,x)**2 for x in (a,b));vals.append(eta)
                if 'eta_certificate_id' in row:
                    ec=j['eta_certificates'][row['eta_certificate_id']]
                    assert ec['case']==cid and ec['bad_mask']==''.join('1' if z else '0' for z in r['bad'])
                    zz=ec['certificate']['by_source'][v]['segments'][si]
                    assert zz['segment']==si and zz['root_count']==0
                    expected=('positive' if sg=='+' else 'negative') if any(S) else 'zero'
                    assert zz['derivative_sign']==expected
                    assert F(zz['segment_eta_lower_1e9'])<=eta<=F(zz['segment_eta_upper_1e9'])
            eta=max(vals);assert 0<=eta<=1;etas.append(eta)
            if 'eta_bounds_1e9' in row:
                bound=row['eta_bounds_1e9'][v];assert bound['v']==v
                low,up=F(bound['lower']),F(bound['upper']);assert low<=eta<=up
            else:
                bound=row['eta'][v];low,up=F(bound['eta_lower']),F(bound['eta_upper']);assert low==eta==up
            upper.append(up)
        bnew=[F(o['full_coverage_source_b'][v])*etas[v] for v in range(6)]
        bcon=[F(o['full_coverage_source_b'][v])*upper[v] for v in range(6)]
        # The saved allocated b may use exact eta or its conservative rational upper.
        saved_b=list(map(F,row['new_full_coverage_source_b_upper']))
        assert all(bnew[v]<=saved_b[v]<=bcon[v] for v in range(6))
        if 'eta_bounds_1e9' in row: assert saved_b==bcon
        assert F(row['new_budget_lower'])<=sum(bnew)<=F(row['new_budget_upper'])
        assert sum(saved_b)==F(row['new_budget_upper'])<=1 and sum(bcon)<=1
        mu=list(map(F,o['mu']));aa=[saved_b[v]/mu[v] if mu[v] else F(0) for v in range(6)]
        assert sum(mu[v]*aa[v] for v in range(6))==sum(saved_b)
        if 'new_full_coverage_source_a' in row: assert aa==list(map(F,row['new_full_coverage_source_a']))
        req=[F(0)]*6;orig=r['traffic']['FA_caps'];capset=set()
        for cap in orig:
            v=cap['v'];s=c['score_segments'][cap['segment']];lo=F(str(cap['lo']));hi=F(str(cap['hi']))
            assert lo<hi and r['good'][v] and r['bad'][cap['bad']] and F(o['rho'][v])>0 and s['k'][v]>s['k'][cap['bad']]
            base=2*N*nu[v]*F(o['rho'][v])*F(s['c'][v])*lo**(-s['k'][v])/eg
            want=base*etas[v];assert saved_b[v]>=want
            req[v]=max(req[v],base);counts['caps']+=1
            capset.add((cap['segment'],v,cap['bad'],lo,hi))
        assert req==list(map(F,o['full_coverage_source_b']))
        archived={(z['segment'],z['v'],z['u'],F(z['original_FA_lo']),F(z['original_FA_hi'])) for z in caprows[key]['caps']}
        assert capset==archived and len(orig)==row['cap_count']
        counts['rows']+=1;maxcost=max(maxcost,sum(saved_b));maxconservative=max(maxconservative,sum(bcon));maxeta=max(maxeta,*etas)
    assert seen==set(old) and counts==dict(rows=179,segments=2214,positive_vsegments=716,zero_vsegments=1498,derivative_Bernstein_strict_sign=716,caps=690)
    print(json.dumps(dict(status='PASS',scope='Frozen rational 179-row necessary model only; no FULL or dx inference; generic root library not audited',counts=counts,bad_patterns=patterns,distinct_derivative_sign_certificates=len(signs),max_saved_budget_upper_1e9=str(F(-(-maxcost.numerator*10**9//maxcost.denominator),10**9)),max_rounded_eta_conservative_budget_upper_1e9=str(F(-(-maxconservative.numerator*10**9//maxconservative.denominator),10**9)),max_exact_eta_upper_1e9=str(F(-(-maxeta.numerator*10**9//maxeta.denominator),10**9)),certificate_sha256=sha(cert_bytes),source_sha256=sha(src_bytes),receiver_sha256=sha(rec_bytes),r148_member_sha256=sha(old_bytes),r147_member_sha256=sha(cap_bytes),verifier_sha256=sha(Path(__file__).read_bytes())),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
