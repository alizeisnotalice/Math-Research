# R149 有限历史定位：receiver 数值与原 FIRST/history 实现

口径：只定位既有证据，不把必要模型、有限采样或局部条件式登记为原始完整弱型证明。检查对象限于本索引所列历史报告/脚本；没有重跑数值程序。

## 找到的 receiver 与真实体积数值

- **真实中心立方体体积和有限弱型下界：R128。**
  - 程序：[receiver_numeric.py](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/receiver_numeric.py)、独立校验器 [receiver_verify.py](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/receiver_verify.py)，数值及范围说明在 [receiver_execution_note.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/receiver_execution_note.md) 与 `receiver_result_summary.json`。
  - 对有理盒源密度、给定有限接收盒，程序以精确 Fraction 网格/顶点检验严格质量门，并以盒交并集精确体积计算
    `lambda * |certified_receiver_union| / original_L1`。这是实际 Lebesgue `dx` 的有限中心盒弱型**下界证书**；不是 receiver 上界、连续来源优化或全局弱型常数。
  - 已报告例：`single` 为 n=1、lambda=1/2、L1=1，比例 1/8；`separated` n=2、lambda=1/8、L1=3/4，比例 1/192；`overlap` n=2、lambda=1/4、L1=5/2，比例 1/80；`asymmetric` n=3、lambda=1/32、L1=5/8，比例 1/5120。触门边界例也保留（strict equality 与 above equality 比例为0，below equality 为917503/4194304）。24配置、14178顶点经独立递归坐标扫描复核，13组正体积证书。receiver/source 都是输入的有理盒；没有同一个连续 `nu` 上的接收点连续扫描或核积分。
  - 核/对象来源：这套计算是原盒平均算子的几何接口；见同目录 `receiver_capacity_geometry.md`，用 `A_r f(x)` 的盒平均及盒halo条件构造几何证书。它不使用 R136 的 `phi/psi/J/K0` 软核，也不声称原 FIRST。

- **固定共同 `nu` 的 receiver 真实连续采样：R142（不是连续积分）。**
  - 数据、脚本和方案：[numeric_receiver.py](/Users/zhengzhihao/Desktop/T/output/centered_cube_round142_20261015/numeric_receiver.py)、[numeric_receiver_plan.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round142_20261015/numeric_receiver_plan.md)、[receiver_sampling_proof.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round142_20261015/receiver_sampling_proof.md)；历史合同检索为 [history_receiver.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round142_20261015/history_receiver.md)。固定六源共同 `nu`，改变真实 n 维 receiver `x`，用 uniform-core / `p(x)dx` iid 随机点；报告 6912 random receivers、36 pressure receivers、3 controls，脚本另做有限核积求积。不是连续 `x` 扫描、盒区间积分或 `dx` 弱型体积证书。
  - 原报告 `numeric_receiver_plan.md` 明说是 finite-source necessary model，非 FULL/forest/维数阶。核和参数来自既有 R141 必要六原子模型，`s=.25, L=.9, R=b=1, y=(.3,…,.3)`，保留原 `T,Hhat,Lplus,tau,h`；不是给任意 `f` 构造的真实完整 FIRST。`history_receiver.md` 对 R134–141 定向检索也明确目标双门正幂 Chernoff 接收积分未定位，邻近容量式不等于目标付款。

- **较早的 receiver 随机节点检查：R89。** `receiver_probe.py` 与 `receiver_results.json` 用固定有限节点上的区间判别；脚本头写明只认证 finite-node hard predicates，原/余门为 UNKNOWN，未得 whole `Fnew` volume/Hall。没有连续 `dx` 体积或固定 `nu` 连续接收扫描，不能升级为 FULL。

## 离原 `rho, alpha, FIRST/history` 完整实现最近者

- **R136 的 `active_traffic_v2` 是近源时间交通实现，但明确不完整。** [active_traffic_v2.py](/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/package/centered_cube_round136_20261014/active_traffic_v2.py) 与 `active_traffic_v2.json` 固定12个有限来源模型，按 score 段解析积 `rho(v) * (k_v-k_z)_+ * nu_v nu_z w_v w_z / e_t^2`，并逐段保留原 FA 门和 Psi 可用性。核/权重的定义、参数及 `phi/psi`, `A,K0,K1,K2,J`, `rho`, `alpha` 构造在该轮包内 `protocol_v2.md`、`active_capacity_audit.md` 及 `proof`/输入数据。R136 README 和 JSON scope 都明示“true kernels, necessary finite-source FA/Psi model; no FULL/history/outer integral certification”；README 记录 12/12必要检查、12个联合真实接收积分高精度对照通过，仍没有 FULL/history。
- **R142/R143 是同一有限 receiver 数据上的续作。** R143 [numeric_flux.py](/Users/zhengzhihao/Desktop/T/output/centered_cube_round143_20261015/numeric_flux.py) 从 R136 固定来源时间数据及 R142 接收模型取数，核对原 Psi 图、共同 cut 与正反通量；[round_report.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round143_20261015/round_report.md) 说明这只复用 R142 的6951行，不重采样/重算核。保留 `nu` 不重归一、窗口、删除及负项合同，但未建立原完整 history 全局积分的付款。
- **最接近当前共享预算/接收时间链：R147–R148 固定保存模型。** R148 [round_report.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round148_20261015_final_checkpoint/work/round_report.md) 和 [optimal_budget_notes.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round148_20261015_final_checkpoint/work/optimal_budget_notes.md) 固定同一179 receivers、原 `rho,Q,nu,terminal E+,Psi,FA` 区间和六源 `e_t`，没有换核、rho或接收样本。P1 168行完整覆盖预算≤1；I1 11行全覆盖需1.07715–1.25203，认证最优后仍有正交通；按有限记录权重的残率18.2802477%降至16.6581867%（179行合计16.6579916%）。报告明确这些不是 `dx` 覆盖率、任意连续 `nu` 最优策略或全局付款。R148 的 `early_geometry.py` 对690个原FA cap作100/160位解析时间积分，但脚本自身 scope 明说不是 `dx` 覆盖，也非机器区间证书。

## 核定义与完整性判断

R148 的 `source_cs10_review.md` 可核验另一条完整平滑 FIRST 局部路线的核恒等式（`phi`, `psi_s` 与 score/mixed derivative）；其结论仅通过 CS1–10 成分记录及 TOP/LOWTRACE 输出删除集成，明确保留 HIGHTRACE 的旧 CP `R_*`，未支付该残项，也未给 source FIRST realization 或 spatial operator norm。R136 是 `rho/alpha/FA/Psi` 交通公式最直接可运行的历史代码；R142 是固定同一 `nu` receiver 真实点采样的最近实例；R128 是唯一在已检查材料中找到的真实 `dx` 盒体积/弱型比值有限精确证书。没有找到将三者合并为同一原始 `rho, alpha`、完整 FIRST/history、连续 receiver 积分且具实际中心立方体弱型比值的数值实现。以上“未找到”仅限本次定向有限检查，不能解释为历史上绝对不存在。

## 追加定向检索：是否已有 source-specific `ell_v` 付款

按 R147–148 定向检索 `ess sup_t`、bad-posterior、`(1-k_u/k_v)`、原整窗门等词，并实读 R147 report、R148 capacity / tools_history / audit_sol / early_geometry 对应段，**未定位到**以
`ell_v = esssup_t L_t ∫_bad (1-k_u/k_v)_+ dΠ_u`
替代共同 `L_g`，并已证明整窗固定预算门付款的同一分支。

最接近的是 R147/R148 已审主门：对终端固定 good 来源质量 `m`，在 `r_t(v) ≥ 2(2n+3)L_g m ρ(v)` 子支作整窗时间积分，付款 `2ΛP ≤ 48Λ√n Wβ`；证明以 bad posterior 概率至多1及 `δ≤k_good` 放松，故该门实际只用统一 `L_g`。R148 `early_geometry.py` 则对同一179行保存模型及原FA残余窗解析积分，分别保留 eligible bad posterior 与全 terminal-bad posterior，结果显示若直接丢后者可以近两倍放大；但它是有限数据审计/上帽，不建立新的 source-specific 门或一般总预算。

R148 `tools_history.md` 的 TH7–8、`capacity.md` CAP12 也不是所问式：它们给定已指定时间集后的最小固定源密度，核心是 `esssup ρ/r_t` 或 `z_on`（真实正交通支持），并沿用 `L_g`；没有 bad posterior 的 score 差积分，也没替换原 R147 的共同付款合同。故现有相近结果不能合并成 `ell_v` 整窗付款。
