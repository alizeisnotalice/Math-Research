"""Replay final R149 producer and independent verifier from archived inputs."""
from pathlib import Path
import argparse,json,zipfile,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--rounds',required=True,type=Path);ap.add_argument('--destination',required=True,type=Path);a=ap.parse_args();rounds=a.rounds.resolve();dst=a.destination.resolve();dst.mkdir(parents=True,exist_ok=False)
for n,member,rel in [(139,'active_traffic_v2.json','centered_cube_round136_20261014/active_traffic_v2.json'),(142,'numeric_receiver.json','centered_cube_round142_20261015/numeric_receiver.json')]:
 with zipfile.ZipFile(rounds/str(n)/'research.zip') as z:
  p=dst/'inputs'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(member))
for name in ['ell_capacity.py','ell_capacity_plan.md','ell_verify.py']:shutil.copy2(ROOT/name,dst/name)
frozen=json.loads((ROOT/'ell_capacity.json').read_text())
args=['--input-root',str(dst/'inputs'),'--archive147',str(rounds/'147/research.zip'),'--archive148',str(rounds/'148/research.zip')]
subprocess.run([sys.executable,str(dst/'ell_capacity.py'),*args,'--execution-count',str(frozen['execution_count'])],check=True)
def norm(v):
 if isinstance(v,dict):
  out={}
  for k,x in v.items():
   if k in {'elapsed_seconds','finished_utc','started_utc','executed_utc'}:continue
   if k=='input_sha256':out[k]={Path(p).name:h for p,h in x.items()}
   else:out[k]=norm(x)
  return out
 if isinstance(v,list):return list(map(norm,v))
 return v
assert norm(json.loads((dst/'ell_capacity.json').read_text()))==norm(frozen)
print('VERIFIED producer mathematical output; only runtime timestamps/duration and input-path labels normalized',flush=True)
res=subprocess.run([sys.executable,str(dst/'ell_verify.py'),*args,'--certificate',str(dst/'ell_capacity.json')],check=True,capture_output=True,text=True)
report=json.loads(res.stdout);assert report['status']=='PASS';(dst/'independent_verification.json').write_text(res.stdout)
print(res.stdout)
print('PASS producer replay and independent rational Bernstein verification')
