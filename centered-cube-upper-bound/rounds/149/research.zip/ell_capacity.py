#!/usr/bin/env python3
"""Exact rational ell_v capacity audit for the frozen 179-row model."""
from fractions import Fraction as F
from pathlib import Path
from zipfile import ZipFile
from collections import Counter
import argparse, datetime, hashlib, json, math, sys, time
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'ell_capacity.json'
DEFAULT=Path('/Users/zhengzhihao/Desktop/T/output')
ARCH148=ROOT.parents[1]/'148/research.zip'
ARCH147=ROOT.parents[1]/'147/research.zip'
P_SRC=DEFAULT/'centered_cube_round136_20261014/active_traffic_v2.json'
P_REC=DEFAULT/'centered_cube_round142_20261015/numeric_receiver.json'
PLAN=ROOT/'ell_capacity_plan.md'

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p): return sha_bytes(Path(p).read_bytes())
def f(x): return F(str(x))
def jfrac(x): return F(int(x['numerator']),int(x['denominator']))
def serial(x):
    if isinstance(x,F): return str(x)
    if isinstance(x,dict): return {str(k):serial(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [serial(v) for v in x]
    return x

def trim(p):
    p=list(p)
    while len(p)>1 and p[-1]==0: p.pop()
    return p or [F(0)]
def pzero(p): return len(trim(p))==1 and trim(p)[0]==0
def padd(a,b):
    a,b=trim(a),trim(b); z=[F(0)]*max(len(a),len(b))
    for i,v in enumerate(a): z[i]+=v
    for i,v in enumerate(b): z[i]+=v
    return trim(z)
def pneg(a): return [-v for v in trim(a)]
def psub(a,b): return padd(a,pneg(b))
def pmul(a,b):
    a,b=trim(a),trim(b); z=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): z[i+j]+=x*y
    return trim(z)
def pscale(a,c): return trim([c*x for x in a])
def pder(a): return trim([F(i)*a[i] for i in range(1,len(a))] or [F(0)])
def peval(a,x):
    z=F(0)
    for c in reversed(trim(a)): z=z*x+c
    return z
def pdivmod(a,b):
    a,b=trim(a),trim(b)
    if pzero(b): raise ZeroDivisionError
    if len(a)<len(b): return [F(0)],a
    q=[F(0)]*(len(a)-len(b)+1); r=a[:]
    while not pzero(r) and len(r)>=len(b):
        k=len(r)-len(b); c=r[-1]/b[-1]; q[k]=c
        for i,v in enumerate(b): r[k+i]-=c*v
        r=trim(r)
    return trim(q),trim(r)
def pmonic(a):
    a=trim(a)
    return pscale(a,F(1,a[-1]))
def sturm_chain(p):
    p=trim(p)
    if pzero(p): return []
    seq=[p,pder(p)]
    if pzero(seq[1]): return [p]
    while True:
        _,r=pdivmod(seq[-2],seq[-1])
        if pzero(r): break
        seq.append(pneg(r))
    return seq
def variations(chain,x):
    signs=[]
    for p in chain:
        v=peval(p,x)
        if v: signs.append(1 if v>0 else -1)
    return sum(a!=b for a,b in zip(signs,signs[1:]))
def strip_endpoint_roots(p,x):
    p=trim(p); factor=[-x,F(1)]
    while len(p)>1 and peval(p,x)==0:
        q,r=pdivmod(p,factor)
        assert pzero(r)
        p=q
    return p
def root_count_open(p,a,b):
    if not a<b:return 0
    q=strip_endpoint_roots(strip_endpoint_roots(p,a),b)
    if len(q)<=1:return 0
    ch=sturm_chain(q)
    return variations(ch,a)-variations(ch,b)
def isolate_roots(p,a,b,bits=96):
    """All distinct real roots in (a,b), with rational isolating boxes."""
    p=trim(p)
    if pzero(p) or len(p)<=1:return []
    ans=[]; stack=[(a,b)]
    while stack:
        lo,hi=stack.pop(); count=root_count_open(p,lo,hi)
        if count==0: continue
        mid=(lo+hi)/2
        if peval(p,mid)==0:
            ans.append((mid,mid,'exact'))
            # Endpoint factors are ignored by the open count on both children.
            stack.append((lo,mid)); stack.append((mid,hi)); continue
        if count==1 and hi-lo<=F(1,2**bits)*max(F(1),abs(lo),abs(hi)):
            ans.append((lo,hi,'isolated'));continue
        stack.append((mid,hi));stack.append((lo,mid))
    ans.sort(key=lambda z:z[0])
    # A rational root hit exactly by a split belongs to neither child; its exact record is retained.
    return ans

def interval_ratio(S,P,lo,hi,eg):
    # Coefficients are nonnegative, so S and P are increasing on x>=0; P>0.
    sl,sh=peval(S,lo),peval(S,hi); pl,ph=peval(P,lo),peval(P,hi)
    assert 0<pl<=ph and 0<=sl<=sh
    return eg*sl/(ph*ph), eg*sh/(pl*pl)
def poly_payload(p): return [str(x) for x in trim(p)]
def grid_floor(x,scale=10**9): return F((x*scale).numerator//(x*scale).denominator,scale)
def grid_ceil(x,scale=10**9):
    y=x*scale; return F(-((-y.numerator)//y.denominator),scale)
def sign_label(x): return 'positive' if x>0 else ('negative' if x<0 else 'zero')

def segment_eta(seg, bad, nu, eg, d, root_bits=96):
    ks=list(map(int,seg['k'])); cs=list(map(f,seg['c']))
    assert len(ks)==len(cs)==6
    assert all(k in (0,d,2*d) for k in ks),('unsupported score exponents',ks,d)
    lo,hi=f(seg['lo']),f(seg['hi']); assert 0<lo<hi
    # x=t^{-d}; its closed interval reverses the time endpoints.
    xa,xb=hi**(-d),lo**(-d)
    P=[F(0)]*3; S=[F(0)]*3
    for i,(k,c) in enumerate(zip(ks,cs)):
        j=k//d; P[j]+=nu[i]*c
        if bad[i]:
            for v,kv in enumerate(ks):
                if kv==0: continue
            # For this receiver v, bad contributions are formed below; this P is shared.
    candidates=[]
    per_v=[]
    for v,kv in enumerate(ks):
        if kv==0:
            per_v.append(dict(eta_lower=F(0),eta_upper=F(0),S=[F(0)],D=[F(0)],roots=[],candidates=[]));continue
        Sv=[F(0)]*3
        for u,ku in enumerate(ks):
            if bad[u] and ku<kv:
                j=ku//d
                Sv[j]+=nu[u]*cs[u]*(F(1)-F(ku,kv))
        S=trim(Sv); P0=trim(P)
        if pzero(S):
            per_v.append(dict(eta_lower=F(0),eta_upper=F(0),S=S,D=[F(0)],roots=[],candidates=[]));continue
        D=psub(pmul(pder(S),P0),pscale(pmul(S,pder(P0)),F(2)))
        root_boxes=isolate_roots(D,xa,xb,root_bits) if not pzero(D) else []
        cand=[]
        for x in (xa,xb):
            val=eg*peval(S,x)/(peval(P0,x)**2)
            cand.append(dict(kind='endpoint',x=[x,x],value_lower=val,value_upper=val))
        for rl,rh,kind in root_boxes:
            vl,vh=interval_ratio(S,P0,rl,rh,eg)
            cand.append(dict(kind=kind,x=[rl,rh],value_lower=vl,value_upper=vh))
        lower=max(z['value_lower'] for z in cand); upper=max(z['value_upper'] for z in cand)
        per_v.append(dict(eta_lower=lower,eta_upper=upper,S=S,D=D,roots=root_boxes,candidates=cand))
    return dict(time_interval=[lo,hi],x_interval=[xa,xb],P=P,by_v=per_v)

def record_eta(row, rec, source_case, nu, root_bits=96):
    bad=list(map(bool,rec['bad'])); assert len(bad)==6
    eg=f(row['e_g']); segs=source_case['score_segments']
    positive=sorted({int(k) for seg in segs for k in seg['k'] if int(k)>0})
    assert positive and len(set(positive))==len(positive)
    # Frozen I1/P1 rows use 0,d,2d score levels.
    d=positive[0]; assert all(int(k) in (0,d,2*d) for seg in segs for k in seg['k'])
    per_v=[]; total_intervals=0; total_roots=0
    for v in range(6):
        intervals=[]; lo=F(0); hi=F(0)
        for si,seg in enumerate(segs):
            item=segment_eta(seg,bad,nu,eg,d,root_bits)
            z=item['by_v'][v]; intervals.append(dict(segment=si,time_interval=item['time_interval'],x_interval=item['x_interval'],P=item['P'],**z)); lo=max(lo,z['eta_lower']);hi=max(hi,z['eta_upper'])
        total_intervals+=len(intervals);total_roots+=sum(len(z['roots']) for z in intervals)
        per_v.append(dict(v=v,name=source_case['atoms'][v]['name'],bad=bad[v],eta_lower=lo,eta_upper=hi,segments=intervals))
    # A zero ell with positive full-window FA traffic is contradictory.
    positive_fa_sources={int(c['v']) for c in rec.get('traffic',{}).get('FA_caps',[])}
    for z in per_v:
        assert z['eta_upper']<=1, ('ell/Lg bound failed',z['v'],z['eta_upper'])
        if z['eta_upper']==0: assert z['v'] not in positive_fa_sources
    return per_v,dict(score_step=d,segment_count=len(segs),segment_source_v_count=total_intervals,isolated_root_count=total_roots)

def compact_eta_certificate(source_case, eta, counts):
    seg_signatures=[]
    for v in eta:
        source_segments=[]
        for z in v['segments']:
            mid=sum(z['x_interval'],F(0))/2
            cand=z['candidates']; seg_lower=max((q['value_lower'] for q in cand),default=F(0)); seg_upper=max((q['value_upper'] for q in cand),default=F(0))
            source_segments.append(dict(segment=z['segment'],root_count=len(z['roots']),derivative_sign=sign_label(peval(z['D'],mid)),segment_eta_lower_1e9=grid_floor(seg_lower),segment_eta_upper_1e9=grid_ceil(seg_upper)))
        seg_signatures.append(dict(v=v['v'],name=v['name'],eta_lower_1e9=grid_floor(v['eta_lower']),eta_upper_1e9=grid_ceil(v['eta_upper']),segments=source_segments))
    return dict(source_case=source_case['id'],score_step=counts['score_step'],bad_pattern_source_specific=True,by_source=seg_signatures)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input-root',default=str(DEFAULT));ap.add_argument('--archive148',default=str(ARCH148));ap.add_argument('--archive147',default=str(ARCH147));ap.add_argument('--root-bits',type=int,default=96);ap.add_argument('--execution-count',type=int,default=1);args=ap.parse_args()
    start=time.monotonic();srcpath=Path(args.input_root)/'centered_cube_round136_20261014/active_traffic_v2.json';recpath=Path(args.input_root)/'centered_cube_round142_20261015/numeric_receiver.json'
    a148=Path(args.archive148);a147=Path(args.archive147)
    with ZipFile(a148) as z: opt_bytes=z.read('optimal_budget.json')
    with ZipFile(a147) as z: tc_bytes=z.read('time_coverage.json')
    opt=json.loads(opt_bytes);tc=json.loads(tc_bytes); old={(r['case'],r['id']):r for r in opt['records']};caps={(r['case'],r['id']):r for r in tc['records']}
    assert len(old)==179 and len(caps)==179
    src_data=json.loads(srcpath.read_text());src_cases={c['id']:c for c in src_data['cases']}
    receiver=json.loads(recpath.read_text());picked=[]
    for cid,case in receiver['cases'].items():
        if cid not in ('I1','P1'): continue
        nu=[jfrac(z) for z in case['nu_exact']]
        for r in case['records']:
            key=(cid,r['id'])
            if key in old:
                assert key in caps and r['stage']==old[key]['stage']
                picked.append((cid,r,nu,case))
    assert len(picked)==179
    picked.sort(key=lambda x:({'initial':0,'pressure':1,'expanded':2}[x[1]['stage']],x[0],x[1]['id']))
    rows=[];intervals=0;roots=0;full_caps=0;eta_cache={};eta_certificates={}
    for cid,rec,nu,_case in picked:
        row=old[(cid,rec['id'])]; source_case=src_cases[cid]
        cache_key=(cid,tuple(map(bool,rec['bad'])))
        cert_id=cid+':bad'+''.join('1' if b else '0' for b in cache_key[1])
        if cache_key not in eta_cache:
            eta_cache[cache_key]=record_eta(row,rec,source_case,nu,args.root_bits)
            eta_certificates[cert_id]=dict(case=cid,bad_mask=''.join('1' if b else '0' for b in cache_key[1]),certificate=compact_eta_certificate(source_case,eta_cache[cache_key][0],eta_cache[cache_key][1]),counts=eta_cache[cache_key][1])
        eta,counts=eta_cache[cache_key]
        positive_fa_sources={int(c['v']) for c in rec.get('traffic',{}).get('FA_caps',[])}
        for z in eta:
            if z['eta_upper']==0: assert z['v'] not in positive_fa_sources
        b_old=list(map(f,row['full_coverage_source_b']))
        eta_bar=[grid_ceil(eta[i]['eta_upper']) for i in range(6)]
        eta_floor=[grid_floor(eta[i]['eta_lower']) for i in range(6)]
        b_new=[b_old[i]*eta_bar[i] for i in range(6)]
        b_lo=[b_old[i]*eta_floor[i] for i in range(6)]
        cost_lo=sum(b_lo,F(0));cost_hi=sum(b_new,F(0))
        # Independently re-express ell threshold against every original cap.
        caprow=caps[(cid,rec['id'])]; cap_entries=caprow['caps']
        cap_count=len(rec.get('traffic',{}).get('FA_caps',[])); full_caps+=cap_count
        assert len(cap_entries)==cap_count, (cid,rec['id'],len(cap_entries),cap_count)
        saved_keys={(int(z['segment']),int(z['v']),int(z['u']),f(z['original_FA_lo']),f(z['original_FA_hi'])) for z in cap_entries}
        live_keys={(int(z['segment']),int(z['v']),int(z['bad']),f(z['lo']),f(z['hi'])) for z in rec.get('traffic',{}).get('FA_caps',[])}
        assert saved_keys==live_keys, (cid,rec['id'],'original FA cap mismatch')
        required_by_v=[F(0)]*6; minimum_cap_slack=None; cap_identity=[]
        for cap in rec.get('traffic',{}).get('FA_caps',[]):
            v=int(cap['v']); seg=source_case['score_segments'][int(cap['segment'])]
            lo=f(cap['lo']); k=int(seg['k'][v]); coeff=f(seg['c'][v]); nuv=nu[v]; rhov=f(row['rho'][v])
            base=F(2*int(row['N']))*nuv*rhov*coeff*lo**(-k)/f(row['e_g'])
            required=base*eta[v]['eta_upper']; required_by_v[v]=max(required_by_v[v],required)
            assert eta[v]['eta_upper']>=eta[v]['eta_lower']
            assert b_new[v]>=required
            slack=b_new[v]-required
            minimum_cap_slack=slack if minimum_cap_slack is None else min(minimum_cap_slack,slack)
            cap_identity.append((int(cap['segment']),v,int(cap['bad']),f(cap['lo']),f(cap['hi'])))
        assert all(required_by_v[i]<=b_new[i] for i in range(6)), 'each original cap must fit the rounded-up source allocation'
        alloc=[b_new[i]/f(row['mu'][i]) if f(row['mu'][i]) else F(0) for i in range(6)]
        assert all(x>=0 for x in b_new) and sum(b_new,F(0))==cost_hi<=1
        assert sum((f(row['mu'][i])*alloc[i] for i in range(6)),F(0))==cost_hi
        cap_key_bytes=json.dumps(serial(sorted(cap_identity)),separators=(',',':')).encode()
        row_eta_bounds=[dict(v=i,lower=eta_floor[i],upper=eta_bar[i]) for i in range(6)]
        rows.append(dict(case=cid,id=rec['id'],stage=rec['stage'],distribution=rec['distribution'],n=row['n'],N=row['N'],eta_certificate_id=cert_id,eta_bounds_1e9=row_eta_bounds,new_full_coverage_source_b_upper=b_new,new_full_coverage_source_a=alloc,new_budget_lower=cost_lo,new_budget_upper=cost_hi,new_full_coverage_certified=cost_hi<=1,cap_count=cap_count,cap_identity_sha256=sha_bytes(cap_key_bytes),cap_inclusion_checked_exactly=True))
        intervals+=counts['segment_source_v_count'];roots+=counts['isolated_root_count']
    assert sum(r['cap_count'] for r in rows)==690
    strata={}
    def stage_summary(rr):
        maxrow=max(rr,key=lambda r:r['new_budget_upper']) if rr else None
        return dict(N=len(rr),max_receiver_budget_upper=maxrow['new_budget_upper'] if maxrow else None,max_receiver_id=maxrow['id'] if maxrow else None,rows_certified_full_count=sum(r['new_full_coverage_certified'] for r in rr),rows_over_budget_count=sum(r['new_budget_lower']>1 for r in rr))
    for stage in ['initial','pressure','expanded']:
        for cid in ['I1','P1']:
            rr=[r for r in rows if r['stage']==stage and r['case']==cid]
            strata[stage+'/'+cid]=stage_summary(rr)
    for cid in ['I1','P1']:
        rr=[r for r in rows if r['case']==cid]
        strata[cid]=stage_summary(rr)
    maxrow=max(rows,key=lambda r:r['new_budget_upper']); max_eta=max(grid_ceil(z['eta_upper']) for cert in eta_cache.values() for z in cert[0])
    out=dict(status='completed_exact_rational_candidate_certificate',execution_count=args.execution_count,scope='Frozen same-179 receiver and six-source model; ell_v is the full terminalbad-time supremum; no source/time reoptimization, kernel change, new sampling, dx claim, or general theorem.',definition='eta_v=eg*esssup_{t in [tau,h]} S_v(t)/e(t)^2; S_v=sum_{u terminalbad} nu_u c_u t^-ku (1-ku/kv)_+, kv=0 gives 0.',rounding='Per-source eta bounds are outward rational floor/ceil multiples of 1e-9. The producer computes the exact Fraction extrema and checks these bounds before writing.',source_archives={'R148_archive_sha256':sha_file(a148),'R148_member_optimal_budget_sha256':sha_bytes(opt_bytes),'R147_archive_sha256':sha_file(a147),'R147_member_time_coverage_sha256':sha_bytes(tc_bytes)},input_sha256={str(srcpath):sha_file(srcpath),str(recpath):sha_file(recpath)},script_sha256=sha_file(Path(__file__)),plan_sha256=sha_file(PLAN),counts=dict(producer_attempts=args.execution_count,successful_producer_runs=args.execution_count-1,failed_attempts_before_final=1,receivers=len(rows),I1=sum(r['case']=='I1' for r in rows),P1=sum(r['case']=='P1' for r in rows),original_FA_caps=full_caps,receiver_source_segment_suprema=intervals,distinct_eta_certificates=len(eta_certificates),isolated_interior_critical_roots=roots,certificate_grid_denominator=10**9),budget=dict(max_receiver_budget_upper=maxrow['new_budget_upper'],max_receiver_case=maxrow['case'],max_receiver_id=maxrow['id'],max_eta_upper=max_eta,all_179_rows_at_most_one=all(r['new_full_coverage_certified'] for r in rows),rows_certified_full=sum(r['new_full_coverage_certified'] for r in rows),rows_over_budget_count=sum(r['new_budget_lower']>1 for r in rows),strata=strata),eta_certificates=eta_certificates,rows=rows,elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    OUT.write_text(json.dumps(serial(out),ensure_ascii=False,indent=2)+'\n')
    print('MAX ROW BUDGET',float(maxrow['new_budget_upper']),'case',maxrow['case'],'id',maxrow['id'],'all rows <=1',all(r['new_full_coverage_certified'] for r in rows),'roots',roots,'seconds',out['elapsed_seconds'])
    for k,v in strata.items(): print(k,v['N'],float(v['max_receiver_budget_upper']) if v['max_receiver_budget_upper'] is not None else None,v['rows_certified_full_count'])
if __name__=='__main__':main()
