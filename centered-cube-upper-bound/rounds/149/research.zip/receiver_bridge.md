# R149：真实 Q* 混合接收测度的似然比桥与 Fisher 的适用边界

结论：给出同一原 ν 的准确变测度式、一个带显式平方似然费的 Fisher 桥，以及低比值补集对应的准确大似然尾。未获得该补集的一般新付款。两处独立缺口是：真实核的 softness Fisher score 并不是交通的时间 score k_t；将实际交通转到 Q* 混合接收测度还需控制本文 RB149.5 的明确逆 Q 矩。后者不能由 FIRST、高门、终端 good 和低比值不等式的方向直接推出。本文不把 dx 换成 Π，不假设来源坐标独立，不以固定尺度特殊源完成替代原问题。

## 1. 精确合同、目标及历史边界

固定原有限合法截断和实际行 (ω,V,j,y,t)。所有原接收选择器 s(x),L(x),L⁺(x),g(x),R(x)、共同 α、终端 E₊(x)=S_g∩{ρ>0}、全部 Ψ/FA/history/旧已付补集保持原值。原来源 ν=ν_V；外测度始终是 β_V，不能改成 ν。记

\[
 Q_x(v)=\tfrac13\{P_{s,L}(x-v)+P_{s,L^+}(x-v)+J_b(x-v)\},\quad
 F(x)=\int Q_x(v)d\nu(v),\quad F_+(x)=\int_{E_+(x)}Q_x(v)d\nu(v).
\]

FIRST 给 F≤q；m=F₊/q。非零正软核保证正交通行 F>0；F₊=0 行没有本支正交通。原

\[
 d\Pi_t(v)=1_{Z_t}(v)w_t(v)d\nu(v)/e_t,
 \quad e_t\ge e_g>0,\quad L_g=Kq/(pe_g)\le\tfrac12,
 \quad p w_g(v)\le KQ_x(v)\ (v\in E_+).
 \tag{RB149.1}
\]

目标只针对 R148 未付域

\[
 \mathcal L=\{v\in E_+:Q_x(v)e_g<2N(s)\rho_v w_t(v)F_+(x)\},
 \tag{RB149.2}
\]

并保留其余原门。N(s) 是 R148 的实际分段值，不在来源、时间、hard z 内重新选择。R148 已付其严格互补门；本文不重新领取该费用。

已实际读取 R148 的 research.tex、capacity.md、source_cs10.md；以及 R146 research.zip 中 scale_joint.md、receiver_bridge.md、pair_energy.md、tools_history.md。归档内 **scale_joint.md 是同点 good/bad 似然夹带 SJ1–13**；条件 SC 变测度桥 RB4–10 实际位于 **receiver_bridge.md**。该旧桥把 A*β 转到 e_t(y)dy/z_t^n，其最优常数是 ess sup z_t^n b_β A*/e_t。本文不重证它。以下换的是另一变量上的真实 Q* 混合接收测度，故不能援用旧 SC 的 n 级方差帽。

## 2. 同一 ν 的准确后验与低门方向

定义真正归一化的 Q 后验及其 good 限制：

\[
 \pi_x(dv)=Q_x(v)d\nu(v)/F(x),\qquad
 \eta_{+,x}(dv)=1_{E_+}Q_x(v)d\nu(v)/F_+(x).
\]

这两者是概率；原 μ=Qν/q 是次概率，不能冒充其中任一个。对原 Π，准确 Radon–Nikodym 密度为

\[
 \ell_t(x,v)=\frac{d\Pi_t}{d\pi_x}(v)
 =\frac{F(x)1_{Z_t}(v)w_t(v)}{e_tQ_x(v)},
 \quad
 h_t(x,v)=\frac{d(1_{E_+}\Pi_t)}{d\eta_{+,x}}(v)
 =\frac{F_+(x)w_t(v)}{e_tQ_x(v)}.
 \tag{RB149.3}
\]

E₊⊂Z_g⊂Z_t，故第二式无需额外 Z_t。h_t 的积分是 Π_t(E₊)，不必等于1。令 a₊=F₊/F，则 h_t=a₊ℓ_t 于 E₊。低门准确等价于

\[
 \boxed{\mathcal L=\{v\in E_+:\rho_v h_t(x,v)>e_g/(2N(s)e_t)\}.}
 \tag{RB149.4}
\]

因此低比值补集是 **交通相对于真实 Q-good 后验超过容量阈值的似然比尾**。这里“尾”只指 RB149.4 的显式阈值，不断言 h_t>1。它给的是下界，不能作为控制 Π≤Cη₊ 的上界使用。R148 已付门正好是相反方向；把同一有界密度论证移到补集会反转不等号。

对任意接收选择器，上述都是逐点恒等式；无需冻结参数。最直接的平方似然费是可由原核计算的

\[
 \boxed{C_{2,\rho}(x,t):=\int\rho_v^2h_t^2d\eta_{+,x}
 =\frac{F_+(x)}{e_t^2}\int_{E_+}\frac{\rho_v^2w_t(v)^2}{Q_x(v)}d\nu(v).}
 \tag{RB149.5}
\]

例如 Cauchy 与 RB149.4 给

\[
 \int_{\mathcal L}\rho_vd\Pi_t(v)
 \le\eta_{+,x}(\mathcal L)^{1/2}C_{2,\rho}^{1/2},\qquad
 \int_{\mathcal L}\rho_vd\Pi_t(v)
 \le\frac{2N(s)e_t}{e_g}C_{2,\rho}.
 \tag{RB149.6}
\]

第二式用 a1_{a>c}≤a²/c；这是一项明确、可检验的低支上界，不是已付总价。若先以 δ≤n 删除 bad 来源，则逐 t 低支价格至多 n 倍 RB149.6；原 dx、p/q、hard z、β、j 和时间仍必须积分。

终端 good 只给以下真实上界：

\[
 C_{2,\rho}\le\frac{KF_+}{pe_t^2}
 \int_{E_+}\rho_v^2\frac{w_t(v)^2}{w_g(v)}d\nu(v)
 =mL_g\frac{e_g}{e_t^2}
 \int_{E_+}\rho_v^2\frac{w_t(v)^2}{w_g(v)}d\nu(v).
 \tag{RB149.7}
\]

w_t/w_g≤(g/t)^n、ρ≤1 继而给 C₂,ρ≤mL_g(e_g/e_t)(g/t)^n。此粗界有限但可指数大；它不是所需根阶预算。t=g 时有 h_g≤mL_g≤1/2，且 C₂,ρ≤mL_gΠ_g(E₊)≤(mL_g)²≤1/4；早时还带未付的 w_t²/w_g 矩。FIRST 仅给 F/q≤1，高门仅给 L_g≤1/2，都不删除此逆 Q 矩。共同 α 仍完整留在 ρ² 内。

## 3. 真正可证的混合 Fisher 定理及全部条件

这里只为说明真实核所提供的信息，先固定 ν 及**常数** L,L⁺,b，令 s∈[1/2,1] 变化；不令这些参数随 x 变化。ν 是任意有限正测度，N_ν=||ν||，不要求产品结构。取 Q_s=(P_{s,L}+P_{s,L⁺}+J_b)/3。沿 R148 已核的一坐标 softness score

\[
 a_s=(\phi-h)/\psi_s,\quad \mathbb E_{\psi_s}a_s=0,
 \quad \mathbb E_{\psi_s}a_s^2\le100,
\]

两个 soft 乘积核的分量 score 是 A_a(x,v)=Σ_i a_s((x_i-v_i)/L_a)，J 分量 score 为0。这个 s 导数不移动 hard 跳面，所以存在普通密度导数；不能改成移动尺度的 Fisher 并丢掉 hard 面原子。令

\[
 H_s(x,v)=\partial_s\log Q_s(x-v),\quad
 F_s(x)=\int Q_s(x-v)d\nu(v),\quad
 \pi_{s,x}=Q_s(x-v)\nu/F_s(x).
\]

则以直接的加权 Jensen 和条件平方展开可证

\[
 \boxed{\int F_s(x)\operatorname{Var}_{\pi_{s,x}}H_s\,dx
 +\int\frac{(\partial_sF_s(x))^2}{F_s(x)}dx
 =\int\!\int Q_s(x-v)H_s(x,v)^2d\nu(v)dx
 \le\frac{200}{3}nN_\nu.}
 \tag{RB149.8}
\]

证明：对固定 x,v，H_s 是三个完整 n 维核分量 score 的责任概率平均，故 Q_sH_s²≤Σ_a κ_a A_a²/3。先固定 v 积分真实 dx，再用每个分量内部的产品概率得 ∫κ_aA_a²≤100n。对混合后验作 Var+mean² 分解即得等式。来源 ν 从未被当成独立坐标；Q_s 也不是逐坐标混合。无外部定理或论文引用。

RB149.8 包含真实核的 Fisher 数据处理；它控制 **H_s 的后验方差**，并不控制任意来源函数的后验方差。自适应 s(x),L(x) 的实际积分也不能直接应用其固定参数总价：用包络或参数分层时，必须另付该 score 平方族的接收费用。R148 的零阶核包络 CS10 没有自动给这个带 score 平方的包络。本节固定参数只是严格的辅助构件，非原交通的固定尺度完成。

## 4. Fisher 到实际交通的完整平方似然桥

给出一个不隐藏费用的精确命题。对某个已合法冻结或另有接收包络证书的 Q，设

\[
 d\mathcal M(x,u,v)=F(x)dx\,d\pi_x(u)d\pi_x(v).
\]

固定外 hard 来源 z，把原全部正门（包括 RB149.2、D₀(u)、E₊(v)、唯一 j、时间窗、history、Ψ/FA、已付补集等）收为 0≤χ≤1；ρ 不再放进 χ。定义

\[
 B(x,z,u,v)=\frac{p_x h_{R(x)}(x-z)a_\omega(x,y,z)}{q(x)F(x)}
 \rho_v\chi\,\ell_t(x,u)\ell_t(x,v).
 \tag{RB149.9}
\]

于是原该 t,z 行的正交通**准确**是 ∫B δ_t dℳ，尚须乘外 ν(dz)、β(dy)、dt/t、EΣV,j 及2Λ。尤其 dx 没有消失；两份 e_t 仍完整藏在两份 ℓ_t 内。平方桥费有显式原核形式

\[
 \boxed{\mathcal R_{t,z}:=\int B^2d\mathcal M
 =\int dx\,\frac{p_x^2h_R(x-z)^2a_\omega^2}{q(x)^2}
 \frac{F(x)}{e_t^4}
 \iint\frac{1_{Z_t}(u)1_{Z_t}(v)w_t(u)^2w_t(v)^2}
 {Q_x(u)Q_x(v)}\rho_v^2\chi^2\,d\nu(u)d\nu(v).}
 \tag{RB149.10}
\]

这里 F 在分子而非分母。硬来源的一阶帽 ∫h_Raν/q≤16/3 不控制 RB149.10 中的 h_R² 及两个逆 Q；若先消去 z，也必须写出相应积分后的平方费，不能把16/3使用两次。

对任意实数 c，令 E_c(x,v)=k_t(v)−cH_s(x,v)，记

\[
 J_c=\int F(x)\operatorname{Var}_{\pi_x}E_c(x,\cdot)dx,
 \quad I_H=\int F\operatorname{Var}_{\pi_x}H_s dx.
\]

若 ℛ、J_c 有限，则两次 Cauchy–Schwarz 给真正的桥

\[
 \boxed{\int B\delta_t\,d\mathcal M
 \le\mathcal R_{t,z}^{1/2}
 \{\sqrt2|c|I_H^{1/2}+\sqrt{2J_c}\}.}
 \tag{RB149.11}
\]

证明只用 δ₊≤|k(v)−k(u)|≤|c||H(v)−H(u)|+|E_c(v)−E_c(u)|，和同一 π 的两份抽样差平方=2Varπ。可在证明中对完整原门 χ 作任意缩小，不需要门可微。若满足第3节固定参数条件，则 I_H≤(200/3)nN_ν；一般实际参数则需另证其相应 I_H 总帽。c 可以在整个本行预先选择，也可使用已另证的逐 x 校准并相应修改积分；不能逐 pair 选 c 再当成同一 Fisher 常数。

RB149.11 是有明确似然费和校准费的积分估计。要产生一般根阶付款，必须把其右端在原外 ν、β、j、dt/t 总和后付到 C√n polylog(n)Wβ 或原可吸收 εX；不能只报其中 I_H 的√n。它并未满足这些条件，故不登记新付款。

## 5. 为什么 Fisher 的 n 级常数不能直接替换 k_t

差异不只是符号或缺一项归一化。k_t(v)=Σ_i1_{a_i(y,v)<t} 是固定 y,t 的来源阈值统计；H_s(x,v) 是接收核对 s 的平滑参数 score。阈值跳跃位置在 y-v 上，而 softness score 的变量是 x-v；原合同没有给 k_t=cH_s+小残差。

下面是对一个潜在通用引理的严格压力检验，不是原 FULL 反例。取实际 s=1、固定 L,L⁺,b 的严格正平移连续 Q，任意 n。选择同一坐标阈值的两侧来源 v₋,v₊，令所有坐标距离阈值 ε，且 k_t(v₋)=0、k_t(v₊)=n。令 ν=(δv₋+δv₊)/2，ε↓0。设 q₋(x)=Q(x−v₋)、q₊(x)=Q(x−v₊)。那么准确地

\[
 \int F(x)\operatorname{Var}_{\pi_x}k_t\,dx
 =\frac{n^2}{2}\int\frac{q_-(x)q_+(x)}{q_-(x)+q_+(x)}dx
 \longrightarrow\frac{n^2}{4}.
 \tag{RB149.12}
\]

极限只用平移的 L¹ 连续性：ab/(a+b)=(a+b)/4−(a−b)²/[4(a+b)]，最后一项≤|a−b|/4。Q 是原三核，来源也始终是同一 ν；可把原子换成位于两侧、不跨阈值的小盒有界密度，结论仍可任意逼近。这里不要求来源独立。

所以“真实 Q* 混合后验的任意 k_t 方差总是≤Cn||ν||”这个无原门引理是假的，不能由 RB149.8 推出。反过来，即使选 c=0，RB149.11 的 J₀ 在此可有 n² 级；若想让 c≠0 校准，仍须由原门证明其残差费用，而非引用 Fisher 名称。这个例子没有认证 terminal good、ρ、high、FA、history 同时成立；它不反驳原完整目标，也不证明原门无法修复。其唯一用途是排除“Q 混合 + 数据处理自动给交通 score 根阶”的逻辑步骤。

还可把 k_t 作为来源权重的指数倾斜参数：ν_θ(dv)∝e^{θk_t(v)}ν(dv)。此时混合输出的 Fisher 加平均条件方差等于 Var_{ν/||ν||}k_t，而该完整信息本来可为 n²/4。数据处理只把它变小，没有创造 n 级上界。这与真实核的 s-Fisher 是两种不同参数，不能交换。

## 6. 可由原门推出的条件和准确停止点

| 条件／费用 | 原合同已给什么 | 本文判定 |
|---|---|---|
| Q 后验归一化 | F≤q、F₊≤F，非零行严格正 | π、η₊合法；μ仍为次概率 |
| 交通对 Q 的密度 | RB149.3，E₊⊂Z_t | 准确恒等式，无需来源独立 |
| 未付低门 | ρh_t>e_g/(2Ne_t) | 大似然尾，方向不给上密度帽 |
| 终端 good/high | h_g≤mL_g≤1/2 | 当前 h_t 仍付 w_t/w_g 和 e_g/e_t |
| 低支平方费 | RB149.5、RB149.7 | 精确逆 Q 矩；未获累计上帽 |
| 固定参数真实核 Fisher | RB149.8，s≥1/2、常数尺度 | 已证；只对真实核的 softness score |
| 交通 score 校准 | 需控制 J_c | 无原门已证帽；无门 n 级方差命题被 RB149.12 排除 |
| 实际 dx 变测度 | RB149.9–10 | 需支付双逆 Q、p²、hard平方及原外账 |
| 自适应参数／j／时间 | RB149.8本身不含这些选择费 | 仍需合法接收包络与整窗消源，不能先免费合并 |

下一条可审核的实质命题应直接针对原完整低域证明：RB149.5 或 RB149.10 的**原门积分后的矩预算**，同时给出 k_t 与核 score 的校准／替代联合方差控制；或绕过 Fisher，直接给该大似然尾的原三来源整窗接收估计。本文已将这两项分别化为逆 Q 的具体积分和一个不能由裸数据处理省略的 score 误差，未把未知总价重新命名为已付能量。

没有新增总体数值实验、没有引用未核外定理，没有操作 Git 或其他代理文件。一般中心立方体弱(1,1)根阶目标仍未闭合。完成本有界任务后停止。
