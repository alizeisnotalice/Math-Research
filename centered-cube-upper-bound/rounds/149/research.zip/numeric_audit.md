# R149 ell_capacity 独立数值核证

状态：最终精简版实际独立审核通过（2026-10-15），SHA已绑定。只认证原保存有理必要模型，不认证FULL或真实dx积分。

## 首版独立方法与结果

未import producer、未重跑其main，也未采用其Sturm实现作证明。另写临时只读核证表达式，从原R136 source、R142 receiver、R148 optimal_budget输入重新构造每个row的完整terminalbad、nu、eg、score段及

    S_v(x)=Σterminalbad_u νu cu x^(ku/d)(1−ku/kv)_+,
    P(x)=Σ全部六源 νu cu x^(ku/d),  x=t^(-d),
    eta_v=eg sup S_v/P².

独立核对全部score段无缝覆盖[tau,h]，保留各段单侧值。2214个source×score段中，716个正分段独立计算D=S'P−2SP'，将x=a+(b−a)y换元后转为Bernstein基，全部系数严格同号。因此这716个分段严格单调，无内部驻点，sup精确取端点；其余1498个分段S恒零。此证据独立于producer的“根数0”输出；不验证其通用Sturm/root-isolation库。

完整terminalbad模式实际为：I1的11行全部索引(3,4)；P1的153行索引(3)，另15行索引(3,4)。没有仅从原FA eligible G4恢复bad。所有六源均保留共同P，所有eg从原nu与wg重新求和，与R148逐行值精确相等。

179行全部eta的首版有理上下端与独立端点最大值精确相等，且0<=eta<=1。独立计算b_v=old_bfull_v eta_v，并按原690个FA cap的真实lo、c、k逐项验证b_v>=2N nu_v rho_v w_v(lo)eta_v/eg；每source最大成本与该b_v相等。逐行Σmu_v a_v=Σb_v<=1通过，不靠浮点summary。

首版精确有理核验的显示值：max行预算0.16566870845164552，max eta 0.13232030612272602，179/179全覆盖；这些显示小数不替代对应有理证书。本保存n4/16沿用Nold=2n+3；未来换Nk须乘Nk/Nold。

首版审查对象SHA256：JSON `7e066a1b9a794c8c4437ffaab8d1bfd6bf7888b608cf69ddc9915ecf0ac05bdd`；脚本 `d4e891cf39f52c3e00dc73b2db3655bcc49a63d2010a91fb91533789e33b1ee4`。最终交付压缩结构改变时必须另绑定，不把此SHA当最终版。

## 最终精简版审核通过

最终JSON SHA256 `26e1ee3c52f85587fda99d9524ca3ba811e6ceca38b03aa525c582df1ef20c22`，含每row显式a向量。独立程序 `ell_verify.py` 已对该版本实际执行，exit0、PASS，约1.61秒。核验包括全部2214分段的完整bad及共同分母、716严格Bernstein导数符号与1498零分段、简表每分段root0及符号/eta范围、逐source eta向外舍入、原179行完整性及690原FA cap身份。

对最终简表，逐source保存b**精确等于** old_bfull乘eta的向上1e-9有理界；保存a精确等于b/mu；每row精确Σmu a=Σb<=1。不是只检查浮点摘要。最大保守行预算的向上1e-9有理界为 `16566871/100000000=0.165668710<1`；最大精确eta的向上1e-9界为 `132320307/1000000000`。这些均明显分离于判别端1，无需进一步优化或Sturm研发。原Cnew下端与上端方向亦核验，旧Nold保持。

独立核证程序SHA256 `d6f648b5031d04b5a8b70818197f2a4c0786759139bd7e6f0746cfd401041ea7`。运行方式：`python3 rounds/149/work/ell_verify.py`；另支持 `--input-root`、`--certificate`、`--archive148`、`--archive147`。从历史归档及原输入重建，不依赖83MB首版或Luna producer代码；只需标准库。

结论：父提出的ell门在**此179行保存必要模型**的真实原FA时间目标上有保守固定来源全覆盖证书。R148的正最优残量针对旧Lg门，不能转称一般不可付障碍；本新覆盖也不支付真实接收dx/FULL/一般维数阶。一般root库、真实核舍入误差及连续空间FULL合同仍未认证。

本审核完成停止，无新接收/时间抽样，无重复来源优化，无Git。
