#!/usr/bin/env python3
"""Exact R785 gated two-mark transport and directional deletion on finite real cubes."""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
import sys


def ss(xs):
    return sum(xs,F(0))


def prod(xs):
    out=F(1)
    for v in xs:
        out*=v
    return out


def mu1(q):
    lo,hi=q
    if lo>=hi:
        return F(0)
    period=F(1,8)

    def cumulative(x):
        j=x//period
        u=x-j*period
        return j*period+u/2+max(F(0),u-period/2)
    return cumulative(hi)-cumulative(lo)


def volume_bin(m):
    b=m.numerator.bit_length()-m.denominator.bit_length()
    return b-1 if F(2)**b>m else b


def setup(name,n):
    if name=="reflection":
        r=[F(k,16) for k in (16,22,22,23,30)]
        centers=[(F(k,32),) for k in (0,-42,44,-44,60)]
        eta=F(1,48)
        bit_cut=F(1,32)
        mids=(3,4)
    elif name=="biaxial":
        r=[F(1),F(3,2),F(15,8)]
        centers=[(F(0),F(0)),(F(9,4),F(0)),(F(0),F(11,4))]
        eta=F(1,8)
        bit_cut=F(7,8)
        mids=(1,2)
    else:
        assert name=="third_face"
        r=[F(1),F(3,2),F(15,8),F(3,2)]
        centers=[(F(0),F(0),F(0)),(F(9,4),F(0),F(0)),
                 (F(0),F(11,4),F(0)),(F(0),F(0),F(9,4))]
        eta=F(1,8)
        bit_cut=F(7,8)
        mids=(1,2,3)
    axes=len(centers[0])
    a=32*n
    ids=range(len(r))
    m=[(2*s)**n for s in r]
    I=[M/a**n for M in m]
    h=[I[i]/m[i] for i in ids]
    ends=[tuple((c-s,c+s) for c in center) for center,s in zip(centers,r)]
    for i in ids:
        assert 1<=r[i]<2
        assert prod(mu1(q) for q in ends[i])*mu1((-r[i],r[i]))**(n-axes)==m[i]
        for j in range(i):
            assert any(abs(x-y)>(r[i]+r[j])/a for x,y in zip(centers[i],centers[j]))

    def mu_inter(indices):
        s=min(r[i] for i in indices)
        active=prod(mu1((max(ends[i][l][0] for i in indices),min(ends[i][l][1] for i in indices)))
                    for l in range(axes))
        return active*mu1((-s,s))**(n-axes)

    overlap={(v,w):mu_inter((v,w)) for v,w in product(ids,repeat=2)}
    bins=[volume_bin(x) for x in m]
    keys=tuple(range(min(bins),max(bins)+1))
    B,U=keys[:len(keys)//2],keys[len(keys)//2:]
    assert all(bins[v] in U for v in mids)
    lower=[u for u in ids if bins[u] in B]
    good={(v,w) for v,w in overlap if v!=w and bins[v]!=bins[w]
          and 0<overlap[v,w]<=eta*min(m[v],m[w])}
    K={(i,j):overlap[i,j]/(m[i]*m[j]) if (i,j) in good else F(0)
       for i,j in overlap}
    degree={v:ss(I[j]*K[v,j] for j in ids) for v in mids}
    assert all(degree.values())
    far={(v,w) for v,w in product(mids,repeat=2) if max(m[v],m[w])>4*min(m[v],m[w])
         and 0<overlap[v,w]<=eta*min(m[v],m[w])}
    assert far
    # Known horizontal source cell P is all [-4,4]. Finite slabs/shells refine it.
    cuts=[]
    for l in range(axes):
        points={t for q in ends for t in q[l]}
        if not l:
            points.update((F(-4),F(4),bit_cut))
        co=sorted(points)
        cuts.append(list(zip(co,co[1:])))
    steps=sorted({F(0),*r})
    tau={}
    truth={v:{} for v in mids}
    marks={}
    for Q in product(*cuts):
        if Q[0][0]<-4 or Q[0][1]>4:
            continue
        p=prod(mu1(q) for q in Q)
        if not p:
            continue
        for s0,s1 in zip(steps,steps[1:]):
            members=[i for i in ids if s1<=r[i] and
                     all(lo<=l<hh<=hi for (lo,hi),(l,hh) in zip(ends[i],Q))]
            if not any(u in members for u in lower):
                continue
            mass=p*(mu1((-s1,s1))**(n-axes)-mu1((-s0,s0))**(n-axes))
            H=ss(h[i] for i in members)
            for u in lower:
                if u not in members:
                    continue
                mark=(u,Q,s0,s1)
                tau[mark]=H*h[u]*mass
                marks[mark]=int(Q[0][0]>=bit_cut)
                for v in mids:
                    if v in members and (u,v) in good:
                        truth[v][mark]=h[u]*mass
    x={v:ss(truth[v].values())/m[v] for v in mids}
    assert all(x[v]==ss(I[u]*K[v,u] for u in lower)>0 for v in mids)
    original_W={v:I[v]*x[v]**2/degree[v] for v in mids}
    gated={}
    accepts={}
    for v in mids:
        norm=ss(truth[v].values())
        nu={a:w/norm for a,w in truth[v].items()}
        assert ss(nu.values())==1 and len({marks[t] for t in nu})==2
        for a1,a2 in product(nu,repeat=2):
            u,g=a1[0],a2[0]
            mu_left=truth[v][a1]/h[u]
            mu_right=truth[v][a2]/h[g]
            old=(I[u]*I[v]*K[u,v])*(I[g]*K[v,g]/degree[v])*mu_left*mu_right/(overlap[u,v]*overlap[v,g])
            assert old==original_W[v]*nu[a1]*nu[a2]
            if marks[a1]<=marks[a2]:
                gated[v,a1,a2]=old
        prob0=ss(w for t,w in nu.items() if not marks[t])
        accepts[v]=1-prob0*(1-prob0)
    M={v:ss(w for row,w in gated.items() if row[0]==v) for v in mids}
    assert all(M[v]==original_W[v]*accepts[v] for v in mids)
    return mids,r,centers,eta,degree,m,I,tau,marks,gated,far,accepts,x,original_W,overlap


def margins(data):
    out=defaultdict(F)
    for (v,a,b),w in data.items():
        out[0,v,a]+=w
        out[1,v,b]+=w
    return out


def energies(D,inds,tau,far):
    B=defaultdict(F)
    for e in (0,1):
        for (v,w),a in product(product(inds,repeat=2),tau):
            B[e,v,w]+=D[e,v,a]*D[e,w,a]/tau[a]
    total=[ss(B[e,v,w] for v,w in far) for e in (0,1)]
    diagonal=[ss(B[e,v,v] for v in inds) for e in (0,1)]
    return total,diagonal,B


def peel(gated,inds,tau,far,t,reverse):
    inc={v:[w for w in inds if (v,w) in far] for v in inds}

    def deg(D,e,v,a):
        return ss(D[e,w,a] for w in inc[v])/tau[a]

    initial=margins(gated)
    D=initial.copy()
    live=dict(gated)
    order=sorted(live,reverse=reverse)
    deleted=[]
    while True:
        candidate=None
        for rec in order:
            if rec not in live:
                continue
            v,a,b=rec
            bad=[(e,deg(D,e,v,r)) for e,r in enumerate((a,b)) if deg(D,e,v,r)<t]
            if bad:
                candidate=(rec,bad[-1] if reverse else bad[0])
                break
        if candidate is None:
            break
        rec,(cause,rate)=candidate
        v,a,b=rec
        w=live.pop(rec)
        assert rate==deg(D,cause,v,rec[cause+1])<t
        deleted.append((rec,cause,rate,w,
                        all(deg(initial,e,v,u)>=t for e,u in enumerate((a,b)))))
        D[0,v,a]-=w
        D[1,v,b]-=w
    assert {key:w for key,w in D.items() if w}==dict(margins(live))
    assert all(all(deg(D,e,rec[0],rec[e+1])>=t for e in (0,1)) for rec in live)
    assigned={}
    for e in (0,1):
        class_data={rec:w for rec,cause,_,w,_ in deleted if cause==e}
        weight=ss(class_data.values())
        g=margins(class_data)
        physical=ss(g[e,v,a]*g[e,w,a]/tau[a] for (v,w),a in product(far,tau))
        chronological=2*ss(w*s/tau[rec[e+1]]
                           for k,(rec,d1,_,w,_) in enumerate(deleted) for nex,d2,_,s,_ in deleted[k+1:]
                           if d1==d2==e and rec[e+1]==nex[e+1] and (rec[0],nex[0]) in far)
        actual_departures=ss(w*rate for _,cause,rate,w,_ in deleted if cause==e)
        assert physical==chronological<=2*actual_departures<=2*t*weight
        assigned[e]={"deleted_count":len(class_data),"assigned_true_mass":weight,
                     "same_reason_far_energy":physical,"deletion_fee":actual_departures,
                     "cap_2t_times_assigned_mass":2*t*weight}
    final,diag,_=energies(D,inds,tau,far)
    assert ss(live.values())+ss(v["assigned_true_mass"] for v in assigned.values())==ss(gated.values())
    promoted=[x for x in deleted if x[-1]]
    first={e:next(({'central':q[0],'cause_record':q[e+1],'degree_at_delete':r,'record_weight':w}
                   for q,cause,r,w,_ in deleted if cause==e),None) for e in (0,1)}
    return live,{"reverse_record_order_and_right_first":reverse,"total_retained":ss(live.values()),
                  "positive_retained_records":len(live),"all_live_records_pass_both":True,
                  "deletions_of_records_initially_passing_both":len(promoted),
                  "first_deletion_per_direction":first,
                  "core_far_energy":final,"core_diagonal_energy":diag,"assigned":assigned}


def row_peel(inds,M,B,far,t):
    live=set(inds)
    deaths=[]
    while live:
        candidates=[]
        for v in sorted(live):
            for e in (0,1):
                rate=ss(B[e,v,w] for w in live if (v,w) in far)/M[v]
                if rate<t:
                    candidates.append((v,e,rate))
        if not candidates:
            break
        v,e,rate=candidates[0]
        live.remove(v)
        deaths.append((v,e,rate))
    for e in (0,1):
        ids={v for v,c,_ in deaths if c==e}
        direct=ss(B[e,v,w] for v,w in far if v in ids and w in ids)
        order=2*ss(B[e,v,w] for i,(v,c,_) in enumerate(deaths)
                   for w,c2,_ in deaths[i+1:] if c==c2==e and (v,w) in far)
        assert direct==order<=2*ss(rate*M[v] for v,c,rate in deaths if c==e)<=2*t*ss(M[v] for v in ids)
    assert all(ss(B[e,v,w] for w in live if (v,w) in far)>=t*M[v] for v,e in product(live,(0,1)))
    return {"retained_middle_labels":sorted(live),"removed_by_middle_row":[[v,e,rate] for v,e,rate in deaths]}


def certify(name,n):
    mids,r,centers,eta,d,m,I,tau,marks,gated,far,accepts,x,W,overlap=setup(name,n)
    D=margins(gated)
    M={v:ss(w for rec,w in gated.items() if rec[0]==v) for v in mids}
    contrast={}
    for v in mids:
        assert ss(D[e,v,a] for a in tau for e in (0,))==ss(D[1,v,a] for a in tau)==M[v]
        assert all(F(0)<=D[e,v,a]/tau[a]<=1 for e,a in product((0,1),tau))
        actual=ss(w for (v0,a,b),w in gated.items() if v0==v and marks[a] and not marks[b])
        left_high=ss(D[0,v,a] for a in tau if marks[a])
        right_low=ss(D[1,v,b] for b in tau if not marks[b])
        fake=left_high*right_low/M[v]**2
        assert actual==0<fake
        contrast[v]={"actual_gate_mass_equals_original_W_times_acceptance":[M[v],W[v],accepts[v]],
                     "actual_probability_left_high_right_low":actual,
                     "before_gate_probability_left_high_right_low":1-accepts[v],
                     "same_marginals_independently_paired_probability":fake,
                     "postgate_left_high":left_high/M[v],"postgate_right_low":right_low/M[v]}
    initial,diag,B=energies(D,mids,tau,far)
    # Independently sum true pairs of marked records using the same central price mark.
    checks=[F(0),F(0)]
    diagonals=[F(0),F(0)]
    for (q,w),(s,p) in product(gated.items(),repeat=2):
        for e in (0,1):
            c=q[e+1]
            if c!=s[e+1]:
                continue
            z=w*p/tau[c]
            if (q[0],s[0]) in far:
                checks[e]+=z
            if q[0]==s[0]:
                diagonals[e]+=z
    assert checks==initial and diagonals==diag and all(diag)

    common=set.intersection(*({rec[1] for rec in gated if rec[0]==v and rec[1]==rec[2]} for v in mids))
    protected={}
    common_mark_witness=None
    if name=="reflection":
        assert not common and initial==[0,0]
        t=F(1,64)
        threshold_origin="positive diagnostic since both true marked far energies are zero"
    else:
        assert common and min(initial)>0
        a=min(common)
        protected={(v,a,a):gated[v,a,a] for v in mids}
        D0=margins(protected)
        min_inside=min(ss(D0[e,w,a] for w in mids if (v,w) in far)/tau[a]
                       for e,v in product((0,1),mids))
        assert min_inside>0
        common_mark_witness={"mark":a,"tau_mass":tau[a],
                             "actual_left_and_right_density_each_middle":{v:[D[e,v,a]/tau[a] for e in (0,1)] for v in mids}}
        t=min_inside/2
        threshold_origin="half the smallest actual far degree on the prespecified in-fixture common marked diagonal subflow"

    outputs=[]
    lives=[]
    for backwards in (False,True):
        remain,details=peel(gated,mids,tau,far,t,backwards)
        assert set(protected)<=set(remain)
        assert 0<=len(remain)<len(gated)
        if name=="reflection":
            assert not remain
        else:
            assert set(rec[0] for rec in remain)==set(mids)
        outputs.append(details)
        lives.append(remain)
    assert lives[0]==lives[1]
    pressure=[]
    if name=="third_face":
        initial_levels=sorted({b for (v,a,b0) in gated for e,u in enumerate((a,b0))
                               if (b:=ss(D[e,w,u] for w in mids if (v,w) in far)/tau[u])>0})
        assert len(initial_levels)==12
        for idx,threshold in ((0,F(28,99951)),(3,F(144,33317))):
            assert threshold==(initial_levels[idx]+initial_levels[idx+1])/2
            core0,details0=peel(gated,mids,tau,far,threshold,False)
            core1,details1=peel(gated,mids,tau,far,threshold,True)
            assert core0==core1 and details0["deletions_of_records_initially_passing_both"]>0
            assert any(x["same_reason_far_energy"] for x in details0["assigned"].values())
            if idx==0:
                assert len(core0)==33 and set(q[0] for q in core0)==set(mids)
            else:
                assert not core0 and all(x["same_reason_far_energy"] for x in details0["assigned"].values())
            pressure.append({"diagnostic_t":threshold,"two_adjacent_initial_positive_degrees":initial_levels[idx:idx+2],
                             "record_orders":[details0,details1]})
    return {"n":n,"shape":name,"eta":eta,"fixed_far_volume_ratio_strictly_greater_than":4,
            "centers_in_active_axes":centers,"radii":r,"real_m":m,"real_disjoint_owner_weights":I,
            "owner_cubes":"each true center with physical radius s_i/(32n)",
            "common_mark_witness":common_mark_witness,
            "true_old_hard_full_degree":d,"old_same_source_class_x":x,"old_same_source_class_peak":W,
            "far_edges":[[v,w,overlap[v,w]/min(m[v],m[w]),max(m[v],m[w])/min(m[v],m[w])]
                         for v,w in sorted(far) if v<w],
            "nonproduct_gate":contrast,"tau_mark_count":len(tau),
            "original_gated_record_count":len(gated),"initial_far_energy_left_and_right":initial,
            "initial_diagonal_fees_left_and_right":diag,"t":t,"threshold_selection":threshold_origin,
            "exact_record_peelings":outputs,"whole_middle_row_comparison":row_peel(mids,M,B,far,t),
            "additional_positive_deletion_fee_pressure":pressure,
            "scope":"finite real 783/784 source geometry; diagnostic p-bit and volume cut; τ includes actual common weak mark, not just its price"}


if __name__=="__main__":
    print(json.dumps({"python":sys.version.split()[0],"arithmetic":"Fraction","command":"python -B core785.py",
                      "mu":"product finite support [-8,8]^n with period 1/8 and half-cycle densities 1/2,3/2",
                      "models":[certify(name,n) for name,n in [("biaxial",8),("reflection",6),
                                                              ("biaxial",12),("third_face",8)]]},
                     indent=2,sort_keys=True,default=str))
