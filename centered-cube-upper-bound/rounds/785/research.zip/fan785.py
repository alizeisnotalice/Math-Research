"""Exact private-source families, measurable finite matchings, localized far mass and box volumes."""
from fractions import Fraction as Q
from itertools import product
from math import isqrt
from core785 import setup, margins
import json
import sys
from flint import arb, ctx, __version__ as flint_version

ctx.prec=256

def frac(t):
    t=Q(t)
    return arb(t.numerator)/arb(t.denominator)

def bin_number(x):
    b=x.numerator.bit_length()-x.denominator.bit_length()
    return b-int(Q(2)**b>x)

def matching_family(p,n):
    # Coordinates 0,...,2p-1 encode vertex tags. All unused centres are zero.
    delta=Q(1,16)
    eta=Q(1,8)
    r=[Q(1)]*(2*p)+[Q(3,2)+Q(3*((i+j)%p),8*(p-1)) for i,j in product(range(p),repeat=2)]
    tags=[{i} for i in range(2*p)]+[{i,p+j} for i,j in product(range(p),repeat=2)]
    m=[(2*t)**n for t in r]
    bins=[bin_number(t) for t in m]
    a=Q(1,(32*n)**n)
    I=[a*t for t in m]
    Bvol=delta**n
    ids=list(range(len(r)))
    V=range(2*p,len(r))
    root_right_start=min(bins)+(max(bins)-min(bins)+1)//2
    assert bins[0]<root_right_start<=min(bins[v] for v in V)
    C=[[((r[v]-delta) if j in tags[v] else (delta-r[v])) for j in range(2*p)] for v in ids]
    assert n>=2*p
    def common(v,w):
        d=len(tags[v]^tags[w])
        lo=min(r[v],r[w])
        return (2*lo)**(n-d)*(2*delta)**d
    def direct(v,w):
        out=(2*min(r[v],r[w]))**(n-2*p)
        for x,y in zip(C[v],C[w]):
            out*=max(0,min(x+r[v],y+r[w])-max(x-r[v],y-r[w]))
        return out
    for v in ids:
        assert common(v,v)==m[v]
        for t in range(2*p):
            # Entire source cube about e_t of radius delta/2 lies in A_v iff t is an admitted tag.
            inside=all(abs((1 if j==t else 0)-C[v][j])+delta/2<=r[v] for j in range(2*p))
            separated=any(abs((1 if j==t else 0)-C[v][j])-delta/2>r[v] for j in range(2*p))
            assert inside==(t in tags[v]) and separated==(t not in tags[v])
        for w in range(v):
            assert common(v,w)<=eta*min(m[v],m[w])
            assert max(abs(x-y) for x,y in zip(C[v],C[w]))>(r[v]+r[w])/(32*n)
    # Check the intersection formula independently for each pattern of radii and tag mismatch.
    seen=set()
    for v in ids:
        for w in range(v+1):
            key=(min(r[v],r[w]),max(r[v],r[w]),len(tags[v]^tags[w]))
            if key not in seen:
                assert common(v,w)==direct(v,w)
                seen.add(key)
    cols=[[] for _ in range(2*p)]
    d={}
    x={}
    W={}
    mark={}
    raw={}
    for v in V:
        for t in tags[v]:
            cols[t].append(v)
        d[v]=sum((a*common(v,j)/m[v] for j in ids if bins[j]!=bins[v]),Q(0))
        x[v]=sum((a*common(v,j)/m[v] for j in range(2*p)),Q(0))
        W[v]=I[v]*x[v]**2/d[v]
        mark[v]=a*Bvol/(m[v]*x[v])
        raw[v]=W[v]*mark[v]**2
        assert raw[v]==I[v]*a*a*Bvol**2/(m[v]**2*d[v])
    retained=min(raw.values())
    quota={v:retained/raw[v] for v in V}
    assert all(0<q<=1 for q in quota.values())
    tau=(p+1)*a*a*Bvol
    F=p*retained/tau
    acceptance=min(retained/(W[v]*mark[v]) for v in V)
    for t in range(2*p):
        incident=cols[t]
        assert len(incident)==p
        for v in incident:
            others=tags[v]-{t}
            assert len(others)==1 and len(tags[v])==2
            for w in incident:
                if v==w:
                    continue
                assert (max(m[v],m[w])>4*min(m[v],m[w]) and common(v,w)<=eta*min(m[v],m[w]))
                assert others.isdisjoint(tags[w])
        # A cyclic p-tuple on the uniformly weighted incident edges, completed with the actual cells,
        # has all p marginals equal to the prescribed conditional probability.
        for j in range(p):
            assert sorted(incident[(k+j)%p] for k in range(p))==sorted(incident)
    def move(v,side):
        t=next(t for t in tags[v] if (t>=p)==bool(side))
        rows=sorted(cols[t],key=lambda mid:m[mid])
        return rows[(rows.index(v)+1)%p]
    walkers=list(V)
    for k in range(3*p+2):
        walkers=[move(v,k%2) for v in walkers]
        assert sorted(walkers)==list(V)
    steps=p//2
    increasing=0
    for start in V:
        past=[start]
        v=start
        ok=True
        for j in range(steps):
            side=j%2
            w=move(v,side)
            if m[w]<=m[v]:
                ok=False
                break
            unused=next(t for t in tags[w] if (t>=p)!=bool(side))
            assert all(unused not in tags[old] for old in past)
            assert all(m[w]>4*m[old] for old in past)
            past.append(w)
            v=w
        increasing+=ok
    assert Q(increasing,p*p)==1-Q(steps,p)
    def log10s(q):
        return str(frac(q).log()/arb(10).log())
    return {"p":p,"n":n,"physical_middle_fathers":p*p,"small_fathers":2*p,
            "distinct_exact_product_checks":len(seen),"relative_conflict":str(Q(1,p)),
            "positive_core":True,"exact_p_tuple":p,
            "fresh_monotone_steps":steps,"strictly_increasing_and_fresh_fraction":str(Q(increasing,p*p)),"fixed_alternating_steps":3*p+2,
            "log10_mark_F":log10s(F),"log10_min_acceptance_at_middle_and_mark":log10s(acceptance),
            "log10_max_x":log10s(max(x.values())),"log10_kept_peak":log10s(p*p*retained),
            "max_acceptance_at_middle_and_mark_below_one_over_1000":max(retained/(W[v]*mark[v]) for v in V)<Q(1,1000),
            "light_fixture_F_below_one_over_1000":F<Q(1,1000)}

def translated(n):
    # A0 at zero, A1 at (9/4)e1 and A2 at (11/4)e2. Only u=0 is in the small child.
    m=[Q(2)**n,Q(3)**n,Q(15,4)**n]
    a=Q(1,(32*n)**n)
    overlap={(0,1):m[0]/8,(0,2):m[0]/16,(1,2):5*m[1]/64}
    triple=Q(2)**(n-2)/32
    J=triple/(3*overlap[1,2])
    W={}
    for v in (1,2):
        x=a*overlap[0,v]/m[v]
        d=a*(overlap[0,v]+overlap[1,2])/m[v]
        W[v]=a*m[v]*x*x/d
    U=J*W[2]
    assert 0<U and 0<J<=1 and m[2]>4*m[1]
    rows=[]
    for copies in (1,4,16):
        translations=[(8*i,8*j) for i,j in product(range(4),repeat=2)][:copies]
        assert all(max(abs(i-k),abs(j-h))>=8 for (i,j),(k,h) in product(translations,repeat=2) if (i,j)!=(k,h))
        totals=sum((W[1]+W[2] for t in translations),Q(0))
        localized=sum((J*W[2] for t in translations if t==translations[0]),Q(0))
        assert totals==copies*sum(W.values()) and localized==U
        assert 24+2+6<8*n  # all four-by-four translates fit inside one frozen common price cube
        rows.append({"copies":copies,"q_over_one_copy":str(totals/sum(W.values())),
                     "U_at_first_over_one_copy":str(localized/U),"U_over_q":str(U/totals)})
    return {"n":n,"J":str(J),"U_first":str(U),"tests":rows}

def one_axis(A,t,signed):
    if signed:
        return (2-A)**2/8+t*(2-A)/2
    if A<=1:
        return 1+t-3*A*A/4-(1-A)*max(0,A-t)
    return 2*one_axis(A,t,True)

def by_sections(A,t,signed):
    def value(u):
        intervals=[]
        for lo,hi in [(A,u+1)]+([] if signed else [(u-1,-A)]):
            lo=max(lo,u-1)
            hi=min(hi,u+1)
            if lo<=hi:
                intervals.append((lo-t,hi+t))
        intervals.sort()
        size=sum((hi-lo for lo,hi in intervals),Q(0))
        if len(intervals)==2:
            size-=max(0,min(hi for _,hi in intervals)-max(lo for lo,_ in intervals))
        return size
    cuts=sorted({-Q(1),Q(1),max(-Q(1),min(Q(1),A-1)),max(-Q(1),min(Q(1),1-A))})
    # Each open piece is affine. Integrate by midpoint to avoid isolated boundary slices.
    return sum(((hi-lo)*value((lo+hi)/2)/4 for lo,hi in zip(cuts,cuts[1:])),Q(0))

def ticket_match(weights,adjacent):
    # Each ticket has unit integer mass. The posterior on labels is not uniform.
    tickets=[i for i,w in enumerate(weights) for _ in range(w)]
    total=len(tickets)
    m=len(weights)
    def no(i,j):
        return min((j-i)%m,(i-j)%m)<=adjacent
    bad=[sum(weights[j] for j in range(m) if no(i,j)) for i in range(m)]
    pi=[Q(w,total) for w in weights]
    zeta=Q(max(bad),total)
    naive=[sum((pi[i]*pi[j]/(1-Q(bad[i],total)) for i in range(m) if not no(i,j)),Q(0))
           for j in range(m)]
    naive_tv=sum(abs(a-b) for a,b in zip(pi,naive))/2
    assert naive_tv>0 and sum(naive)==1
    rows=[(i,) for i in tickets]
    stages=[]
    while 2*(len(rows[0]))*zeta<1:
        owner=[None]*total
        def assign(i,seen):
            for j,label in enumerate(tickets):
                if j in seen or any(no(x,label) for x in rows[i]):
                    continue
                seen.add(j)
                if owner[j] is None or assign(owner[j],seen):
                    owner[j]=i
                    return True
            return False
        assert all(assign(i,set()) for i in range(total))
        assert all(k is not None for k in owner)
        column=[None]*total
        for j,i in enumerate(owner):
            column[i]=tickets[j]
        rows=[r+(j,) for r,j in zip(rows,column)]
        for k in range(len(rows[0])):
            assert sorted(r[k] for r in rows)==sorted(tickets)
        assert all(not no(r[i],r[j]) for r in rows for i in range(len(r)) for j in range(i))
        stages.append(len(rows[0]))
    # On each ordered tuple the successor permutation has exactly one wrap.
    p=len(rows[0])
    wraps=sum(sum(r[i+1]<=r[i] for i in range(p-1))+(r[0]<=r[-1]) for r in map(sorted,rows))
    assert wraps==total
    return {"types":m,"tickets":total,"forbidden_cyclic_radius":adjacent,"zeta":str(zeta),
            "feasible_tuple_sizes":stages,"naive_row_normalization_TV":str(naive_tv),
            "exact_matched_marginal_TV":"0","cyclic_wrap_fraction":str(Q(wraps,p*total))}

def extra_filter(name,n):
    mids,r,centers,eta,d,m,I,tau,_,R,far,_,x,W,_=setup(name,n)
    def in_parent(mark,w):
        points=mark[1]
        return mark[3]<=r[w] and all(abs((lo+hi)/2-c)<=r[w]
                                    for c,(lo,hi) in zip(centers[w],points))
    def other(row,e):
        return row[2-e]
    def conflict(row,s,e):
        return ((row[0],s[0]) not in far or in_parent(other(row,e),s[0])
                or in_parent(other(s,e),row[0]))
    by_m=margins(R)
    marg={}
    for row,w in R.items():
        if row[1]!=row[2]:
            continue
        v,t,_=row
        square=w/W[v]
        nu=Q(isqrt(square.numerator),isqrt(square.denominator))
        assert nu*nu==square
        marg[v,t]=W[v]*nu
    q=sum(W.values())
    assert sum(marg.values())==q
    fee={}
    extra=[]
    for e in range(2):
        ee=Q(0)
        for row,w in R.items():
            mark=row[e+1]
            fee[e,row]=sum((w0 for s,w0 in R.items() if s[e+1]==mark and conflict(row,s,e)),Q(0))/tau[mark]
            ee+=w*sum((w0 for s,w0 in R.items() if s[e+1]==mark and (row[0],s[0]) in far and conflict(row,s,e)),Q(0))/tau[mark]
        extra.append(ee)
    Hcap=sum(I[i]/m[i] for i in range(len(m)))
    assert all(E<=2*Hcap*eta*q/min(x.values()) for E in extra)
    mark_F=sorted({sum(by_m[e,v,t] for v in mids)/tau[t] for (v,t) in marg for e in (0,1)})
    trials=[]
    for zeta,t,b in [(Q(1,4),mark_F[0]/2,Q(1,4)),(Q(1,2),mark_F[-1],Q(1,4)),
                     (Q(3,4),mark_F[len(mark_F)//2],Q(1,2))]:
        live={row:w for row,w in R.items() if all(fee[e,row]<=zeta*t for e in (0,1))}
        discard_bad=sum(R.values())-sum(live.values())
        assert discard_bad<=sum(R[row]*k for (e,row),k in fee.items())/(zeta*t)
        soft=cond=Q(0)
        levels=[]
        while live:
            D=margins(live)
            weak=set()
            low_accept=set()
            for row in live:
                v=row[0]
                for e in (0,1):
                    a=row[e+1]
                    if sum(D[e,w,a] for w in mids)<t*tau[a]:
                        weak.add(row)
                    if D[e,v,a]<b*marg[v,a]:
                        low_accept.add(row)
            new=weak|low_accept
            if not new:
                break
            levels.append(len(new))
            soft+=sum(live[row] for row in weak)
            cond+=sum(live[row] for row in low_accept-weak)
            live={row:w for row,w in live.items() if row not in new}
        assert soft<=2*t*sum(tau.values()) and cond<=2*b*q
        assert sum(R.values())==discard_bad+soft+cond+sum(live.values())
        for row in live:
            for e in (0,1):
                pool={s:w for s,w in live.items() if s[e+1]==row[e+1]}
                assert sum(w for s,w in pool.items() if conflict(row,s,e))<=zeta*sum(pool.values())
        trials.append({"zeta":str(zeta),"t":str(t),"b":str(b),"initial_conflict_deletions":len(R)-len(live)-sum(levels),
                       "weak_fibre_iterations":levels,"final":len(live)})
    return {"n":n,"shape":name,"initial":len(R),"extra_actual_cross_price_conflict_energy":list(map(str,extra)),
            "relative_pruning":trials}

def wide():
    def uniform_tail(t):
        if t<=-1: return Q(1)
        if t<0: return 1-(1+t)**2/2
        if t<1: return (1-t)**2/2
        return Q(0)
    out=[]
    for n in (256,1024,4096,2**16,2**24,2**40,2**80):
        an=arb(n)
        kx=((3*an/(74*an.log())).sqrt()-20+arb(1)/2).floor().unique_fmpz()
        assert kx is not None
        K=max(48,int(kx))
        atom=Q(K,K+20)**2
        h=1+Q(1,32*n)
        for A in (Q(3,4),Q(9,10),Q(5,4)):
            threshold=A*h/2
            lo=atom*uniform_tail(threshold+Q(2,K))
            hi=1-atom+atom*uniform_tail(threshold-Q(2,K))
            assert 0<lo<hi<1
            out.append({"n":n,"p":2,"K":K,"threshold_over_h_over_two":str(A),"positive_signed_one_axis_lower":str(lo),
                        "positive_signed_one_axis_upper":str(hi),"owner_cost_one_axis":str(one_axis(A,Q(1),True))})
    return out

if __name__=="__main__":
    axes=[(A,t,signed) for A in [Q(i,10) for i in range(21)]
          for t in (Q(1,2),Q(3,4),Q(1)) for signed in (False,True)]
    assert all(one_axis(A,t,signed)==by_sections(A,t,signed) for A,t,signed in axes)
    assert one_axis(Q(9,10),Q(1),True)==Q(561,800)
    print(json.dumps({"python":sys.version.split()[0],"python_flint":flint_version,"arb_bits":ctx.prec,
                      "families":[matching_family(p,n) for p,n in ((3,32),(5,64),(8,128))],
                      "translated_biaxial":[translated(n) for n in (8,12,24)],
                      "finite_nonuniform_Hall":[ticket_match([1+(i%3) for i in range(m)],j) for m,j in ((9,0),(17,0),(25,1))],
                      "record_conflicts":[extra_filter(nm,n) for nm,n in (("reflection",6),("biaxial",8),("third_face",8))],
                      "axis_checks":len(axes),"signed_A_0.9_t_1":str(one_axis(Q(9,10),Q(1),True)),
                      "unsigned_A_0.9_t_1":str(one_axis(Q(9,10),Q(1),False)),
                      "original_wide_window":wide()},ensure_ascii=False,indent=2,sort_keys=True))
