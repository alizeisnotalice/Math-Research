"""R762 exact Euclidean witness maximization and fractional cover certificate."""

import argparse
from collections import defaultdict
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from math import prod
from pathlib import Path
from platform import python_version


def cube(center,radius):
    return tuple((x-radius,x+radius) for x in center)


def meet(*boxes):
    return tuple((max(x[0] for x in axis),min(x[1] for x in axis)) for axis in zip(*boxes))


def volume(box):
    return prod(max(Q(0),right-left) for left,right in box)


def membership(boxes,point):
    return tuple(j for j,A in boxes.items() if all(lo<=x<=hi for (lo,hi),x in zip(A,point)))


def slab(lo,hi,n):
    return ((Q(lo),Q(hi)),)+((Q(-4),Q(4)),)*(n-1)


def point_str(y):
    return list(map(str,y))


def run_geometry(n,parents,price,gate):
    a,K = 32*n,Q(4)
    G = (2+Q(1,a))**n
    A = {j:cube(center,s) for j,(center,s) in parents.items()}
    E = {j:cube(center,s/a) for j,(center,s) in parents.items()}
    d = {j:volume(Aj) for j,Aj in A.items()}
    v = {j:volume(Ej) for j,Ej in E.items()}
    assert all(meet(A[j],E[j])==E[j] and v[j]>0 for j in A)
    assert all(volume(meet(X,Y))==0 for X,Y in combinations(E.values(),2))

    def mu(box):
        return sum(w*volume(meet(box,P)) for P,w in price)

    m = {j:mu(Aj) for j,Aj in A.items()}
    assert all(m[j]>=d[j] for j in A)
    gamma = {j:v[j]/m[j]/G for j in A}
    assert K*sum(gamma.values())<=1  # Hence this cap holds even on boundaries.

    def the_gate(j,k):
        return gate.get(frozenset((j,k)))

    def direct(j,k,extra):
        g = the_gate(j,k)
        if g is None:
            return Q(0)
        cut,probability = g
        return K*gamma[k]*probability*mu(meet(A[j],A[k],cut,*extra))/m[j]

    C = {(j,k):direct(j,k,()) for j,k in product(A,repeat=2)}
    D = {(j,k):C[j,k] if d[k]<d[j] else Q(0) for j,k in C}
    assert all(v[j]*C[j,k]==v[k]*C[k,j] for j,k in C)
    endpoints = [
        sorted({x for B in (*A.values(),*(P for P,w in price),*(I for I,w in gate.values()))
                for x in B[axis]})
        for axis in range(n)
    ]
    rho = defaultdict(Q)
    eta = defaultdict(Q)
    cell_exit = defaultdict(Q)
    price_cells = 0
    for cell in product(*(zip(axis,axis[1:]) for axis in endpoints)):
        x = tuple((lo+hi)/2 for lo,hi in cell)
        mask = membership(A,x)
        if "t" not in mask:
            continue
        mass = mu(cell)
        if not mass:
            continue
        price_cells += 1
        accepted = Q(0)
        for j in mask:
            g = the_gate("t",j)
            if g is not None and d[j]<d["t"] and membership({"g":g[0]},x):
                b = K*gamma[j]*g[1]
                accepted += b
                cell_exit[j] += mass*b/m["t"]
        assert 0<=accepted<=1
        rho[mask] += mass/m["t"]
        eta[mask] += mass*accepted/m["t"]
    eta = {mask:w for mask,w in eta.items() if w}
    assert sum(rho.values())==1 and 0<sum(eta.values())<=1
    assert all(cell_exit[j]==D["t",j] for j in A)
    p = {i:sum(w for P,w in eta.items() if i in P) for i in A}
    assert all(p[i]==sum(direct("t",j,(A[i],)) for j in A if d[j]<d["t"]) for i in A)
    w = {i:gamma[i]*p[i] for i in A}

    axis_midpoints = [[(p+q)/2 for p,q in zip(axis,axis[1:])] for axis in endpoints]
    closed_reps = [sorted(set(axis+mid+[axis[0]-1,axis[-1]+1]))
                   for axis,mid in zip(endpoints,axis_midpoints)]
    open_reps = [sorted(set(mid+[axis[0]-1,axis[-1]+1]))
                 for axis,mid in zip(endpoints,axis_midpoints)]

    def score(Y,weight=w):
        return sum(weight[i] for i in membership(A,Y))

    def score_by_price(mask):
        return sum(mass*sum(gamma[i] for i in Z if i in mask) for Z,mass in eta.items())

    visited = set()
    strict_projections = 0
    witnesses = []
    for Y in product(*closed_reps):
        M = membership(A,Y)
        projected = tuple(min(max(x,left),right) for x,(left,right) in zip(Y,A["t"]))
        assert all(i in membership(A,projected) for i in M if w[i]>0)
        fixed_score = score(Y)
        projected_score = score(projected)
        assert fixed_score<=projected_score
        strict_projections += projected_score>fixed_score
        witnesses.append((fixed_score,Y,M))
        if M not in visited:
            assert fixed_score==score_by_price(M)
            visited.add(M)
    B,optimal,opt_mask = max(witnesses,key=lambda row:row[0])
    assert B>0 and strict_projections>0
    open_B = max(map(score,product(*open_reps)))
    packing = {i:w[i]/B for i in A}
    assert all(sum(packing[i] for i in M)<=1 for M in visited)
    assert sum(packing[i] for i in opt_mask)==1
    for_i_max = sum(w.values())
    random_score = sum(w[i]*mu(meet(A["t"],A[i]))/m["t"] for i in A)
    assert random_score==sum(mass*score_by_price(mask) for mask,mass in rho.items())
    assert 0<random_score<B<for_i_max
    return {
        "n":n,"centers":{j:point_str(y) for j,(y,s) in parents.items()},
        "half_sides":{j:str(s) for j,(y,s) in parents.items()},
        "G_upper":str(G),"K":str(K),
        "m_over_d":{j:str(m[j]/d[j]) for j in A},"v":{j:str(v[j]) for j in A},
        "positive_price_cells_inside_t":price_cells,
        "fixed_witness_coordinate_representatives":len(witnesses),
        "witness_membership_patterns":len(visited),"strict_projections":strict_projections,
        "eta_t_total":str(sum(eta.values())),"p_ti":{j:str(p[j]) for j in A},
        "B_t":str(B),"best_open_cell_value":str(open_B),"optimal_point":point_str(optimal),
        "optimal_labels":opt_mask,"separate_point_for_each_label":str(for_i_max),
        "random_rho_t_witness_expectation":str(random_score),
        "rho_t_probability_of_a_maximizer":str(sum((mass for mask,mass in rho.items()
                                                     if score_by_price(mask)==B),Q(0))),
        "random_to_optimal_ratio":str(random_score/B),
        "separate_to_optimal_ratio":str(for_i_max/B),
        "lambda":{j:str(packing[j]) for j in A},
        "packing_total_d_lambda":str(sum(d[i]*packing[i] for i in A)),
    },(A,gamma,eta,w,B,D,score,direct)


def touching_family(n,extended=False):
    zero = (Q(0),)*(n-1)
    spans = {
        "t":(Q(0),Q(2)), "outer":(Q(1,4),Q(3)),
        "left":(Q(-1,2),Q(1,2)), "right":(Q(1,2),Q(1,2)),
        "far":(Q(7,4),Q(1,2)), "tiny":(Q(-3,4),Q(1,8)),
    }
    if extended:
        spans.update({
            "mid_left":(Q(-1,8),Q(1,4)), "mid_right":(Q(5,8),Q(3,8)),
            "back_left":(Q(-3,8),Q(1,8)), "inner_right":(Q(3,4),Q(1,4)),
            "far_small":(Q(15,8),Q(1,8)),
        })
    parents = {j:((x,)+zero,s) for j,(x,s) in spans.items()}
    price = [(slab(-4,5,n),Q(1)),(slab(-1,Q(-1,4),n),Q(2)),
             (slab(Q(1,2),Q(3,2),n),Q(1))]
    gate = {
        frozenset(("t","left")):(slab(Q(-1,4),0,n),Q(1)),
        frozenset(("t","right")):(slab(0,Q(1,4),n),Q(1)),
        frozenset(("t","far")):(slab(Q(5,4),2,n),Q(1,8)),
        frozenset(("left","tiny")):(cube(*parents["tiny"]),Q(1)),
    }
    if extended:
        gate[frozenset(("t","inner_right"))]=(slab(Q(1,2),Q(3,4),n),Q(1,32))
    result,data = run_geometry(n,parents,price,gate)
    A,gamma,eta,w,B,D,score,direct = data
    first,second = D["t","left"],D["left","tiny"]
    assert first>0 and second>0
    old_price = gate[frozenset(("t","left"))][0]
    same_price = direct("left","tiny",(old_price,))
    assert same_price==0
    if not extended:
        assert result["optimal_point"]==["0"] and Q(result["best_open_cell_value"])<B
        assert result["rho_t_probability_of_a_maximizer"]=="0"
    result.update({"case":"touching_and_true_refresh",
                   "strict_refresh": {"parent_order":["t","left","tiny"],
                                      "t_to_left":str(first),"left_to_tiny":str(second),
                                      "fresh_two_step_probability_given_t":str(first*second),
                                      "fresh_two_step_mass_times_v_t":str(Q(result["v"]["t"])*first*second),
                                      "second_step_on_first_price_support":str(same_price)}})
    return result


def fractional_cycle():
    centers = (
        (Q(0),Q(0)),(Q(9,10),Q(-7,20)),(Q(29,20),Q(11,20)),
        (Q(11,20),Q(29,20)),(Q(-7,20),Q(9,10)),
    )
    child = [f"k{i}" for i in range(5)]
    parents = {"t":((Q(1,2),Q(1,2)),Q(2))}
    parents.update({j:(y,Q(1,2)) for j,y in zip(child,centers)})
    pockets = [cube(y,Q(1,64)) for y in centers]
    assert all(volume(meet(P,Qb))==0 for P,Qb in combinations(pockets,2))
    for i,P in enumerate(pockets):
        assert volume(meet(P,cube(*parents[child[i]])))==volume(P)
        assert all(volume(meet(P,cube(*parents[j])))==0 for j in child if j!=child[i])
    price = [(P,Q(16,5)/volume(P)) for P in pockets]
    gate = {frozenset(("t",j)):(cube(*parents[j]),Q(1)) for j in child}
    result,data = run_geometry(2,parents,price,gate)
    A,gamma,eta,w,B,D,score,direct = data
    family = {j:A[j] for j in child}
    cycle_edges = [(child[i],child[(i+1)%5]) for i in range(5)]
    assert all(volume(meet(A[i],A[j]))>0 for i,j in cycle_edges)
    nonedges = [pair for pair in combinations(child,2)
                if frozenset(pair) not in set(map(frozenset,cycle_edges))]
    assert all(any(max(a,c)>min(b,d) for (a,b),(c,d) in zip(A[i],A[j])) for i,j in nonedges)
    assert not any(all(frozenset(pair) in set(map(frozenset,cycle_edges))
                       for pair in combinations(triple,2)) for triple in combinations(child,3))

    pins = []
    for i,j in cycle_edges:
        vertex = tuple((a+b)/2 for (a,b) in meet(A[i],A[j]))
        assert set(membership(family,vertex))=={i,j}
        pins.append((vertex,Q(1,2)))
    cover = {j:sum(weight for y,weight in pins if j in membership(A,y)) for j in A}
    assert all(cover[j]==1 for j in child)
    witness_mass = sum(weight for y,weight in pins)
    dual_lb = sum(Q(1,2) for j in child)  # Every point covers at most two cycle squares.
    assert witness_mass==dual_lb==Q(5,2)
    integer_witness = [pins[0][0],pins[2][0],centers[4]]
    assert set.union(*(set(membership(family,y)) for y in integer_witness))==set(child)
    assert 2*2<len(child)

    common = w["t"]
    child_weight = w[child[0]]
    assert all(w[j]==child_weight>0 for j in child)
    integral = sum(mass*score(y) for y,mass in pins)
    double_integral = sum(mass*sum(gamma[j]*cover[j] for j in pattern)
                          for pattern,mass in eta.items())
    assert integral==double_integral==witness_mass*B
    assert integral-witness_mass*common==sum(w[j] for j in child)==witness_mass*(B-common)
    assert all(len(Z)==2 and Z[0]=="t" for Z in eta)
    adaptive = sum(mass*sum(gamma[j] for j in Z) for Z,mass in eta.items())
    assert adaptive-common==5*child_weight and B-common==2*child_weight
    result.update({"case":"fractional_five_cycle","fractional_mass_m":str(witness_mass),
                   "exact_integer_cover_number":len(integer_witness),
                   "fractional_pins_point_and_mass":[[point_str(y),str(weight)] for y,weight in pins],
                   "fractional_cover_by_label":{j:str(c) for j,c in cover.items()},
                   "fractional_kernel_cost":str(integral),"common_t_contribution":str(common),
                   "before_price_best_child_score":str(B-common),
                   "after_price_adaptive_child_score":str(adaptive-common),
                   "after_price_adaptive_full_score":str(adaptive),
                   "adaptive_to_fixed_full_ratio":str(adaptive/B),
                   "optimal_partial_cover_primal_dual":partial_cover_certificate(family,pins,child_weight),
                   "adaptive_to_fixed_child_ratio":str((adaptive-common)/(B-common))})
    return result


def rank_window_audit():
    """Two separately weighted descending-rank ledgers at one common price."""
    d = tuple(map(Q,(1,1,2,2,2,4,4,8,16,16,32,64)))
    centers = []
    tiers = defaultdict(int)
    for di in d:
        centers.append(di/2*(Q(1,2)+tiers[di]*Q(1,8)))
        tiers[di] += 1
    A = [cube((y,),di/2) for y,di in zip(centers,d)]
    E = [cube((y,),di/64) for y,di in zip(centers,d)]
    m = [volume(meet(B,((Q(-128),Q(128)),))) for B in A]  # Unit AC price.
    v = list(map(volume,E))
    assert m==list(d) and all(B[0][0]<0<B[0][1] for B in A)
    assert all(volume(meet(B,C))==0 for B,C in combinations(E,2))
    g = [vi/mi for vi,mi in zip(v,m)]
    G,K = Q(65,32),Q(4)
    kappa = (Q(1),Q(1,2),Q(1,3),Q(1),Q(1,2),Q(1),Q(1,4),Q(1,2),Q(1),Q(1,3),Q(1,2),Q(1))
    f = [K/G*qi*gi for qi,gi in zip(kappa,g)]
    assert 0<sum(f)<=1 and sum(f)/sum(g)<=K/G
    values = sorted(set(d))
    results = []
    for side,weights in (("receiver",g),("source",f)):
        W = sum(weights)
        for ratio in (Q(2),Q(4)):
            desc = {x:sum(w for di,w in zip(d,weights) if di<=x/ratio) for x in values}
            window = {x:sum(w for di,w in zip(d,weights) if x/ratio<di<=x) for x in values}
            edge = {x:sum(w for di,w in zip(d,weights) if di==x/ratio) for x in values}
            largest_window = max(window.values())
            assert all(desc[x]+window[x]==sum(w for di,w in zip(d,weights) if di<=x) for x in values)
            assert edge[Q(4)]>0  # Values exactly at the lower edge belong to desc.
            tests = []
            for threshold in sorted({Q(0),desc[Q(2)]/W,desc[Q(8)]/W,Q(1)}):
                for strict in (False,True):
                    low = [x for x in values if (desc[x]/W < threshold if strict else desc[x]/W <= threshold)]
                    total = sum(w for di,w in zip(d,weights) if di in low)
                    bound = threshold*W+largest_window
                    assert total<=bound
                    if low:
                        last = max(low)
                        assert low==[x for x in values if x<=last]
                        assert total==desc[last]+window[last]
                    else:
                        assert total==0
                        last = None
                    tests.append({
                        "tau":str(threshold),"strict":strict,"last_volume":str(last),
                        "low_original_weight":str(total),"tau_W_plus_max_window":str(bound),
                        "attains_bound":total==bound,
                    })
            if side=="receiver" and ratio==2:
                at_tie = [x for x in tests if x["tau"]=="1/6"]
                assert at_tie[0]["last_volume"]=="2" and at_tie[0]["attains_bound"]
                assert at_tie[1]["last_volume"]=="1" and not at_tie[1]["attains_bound"]
            results.append({
                "side":side,"ratio":str(ratio),"original_weight_total":str(W),
                "maximum_half_open_window_weight":str(largest_window),
                "volumes_p_desc_window_lower_edge_weight": [
                    [str(x),str(desc[x]/W),str(desc[x]),str(window[x]),str(edge[x])] for x in values
                ],
                "threshold_tests":tests,
            })
    source_load = sum(f)
    receiver_load = sum(g)
    product_count = 0
    for ratio in (Q(2), Q(4)):
        descending = {x:sum(w for di,w in zip(d,g) if di<=x/ratio) for x in values}
        widest = max(sum(w for di,w in zip(d,g) if x/ratio<di<=x) for x in values)
        for cut in (Q(1,20), Q(1,5), source_load*descending[Q(8)]/receiver_load, Q(9,10)):
            eligible = {x for x in values if source_load*descending[x]<cut*receiver_load}
            charge = source_load*sum(w for di,w in zip(d,g) if di in eligible)
            assert charge<=cut*receiver_load+source_load*widest
            product_count += 1
    return {"joint_source_rank_tests":product_count,
            "volumes":list(map(str,d)),"one_common_price":"0","m_equals_d":True,
            "parent_centers":list(map(str,centers)),
            "receiver_weights":list(map(str,g)),"source_weights":list(map(str,f)),
            "side_separated_checks":results}


def partial_cover_certificate(family,pins,child_weight):
    # The preceding geometry certifies all points hit at most two labels.
    result = []
    for budget,dual_multiplier in (
        (Q(1),Q(1)),(Q(2),Q(1)),(Q(5,2),Q(1,2)),(Q(3),Q(0))
    ):
        each = budget/len(pins)
        coverage = {j:sum(each for point,_ in pins if j in membership(family,point))
                    for j in family}
        assert each>=0 and each*len(pins)==budget
        capped = {j:min(Q(1),coverage[j]) for j in family}
        primal = sum(child_weight*val for val in capped.values())
        dual_u = {j:child_weight*dual_multiplier for j in family}
        assert all(0<=u<=child_weight for u in dual_u.values())
        peak = max(sum(dual_u[j] for j in membership(family,y)) for y,_ in pins)
        assert peak==2*child_weight*dual_multiplier
        intercept = sum(child_weight-u for u in dual_u.values())
        dual = intercept+budget*peak
        assert dual==primal==min(2*budget,len(family))*child_weight
        result.append({
            "m":str(budget),"primal_mass_at_each_cycle_edge_pin":str(each),
            "primal_label_coverage":{j:str(c) for j,c in coverage.items()},
            "dual_u":{j:str(u) for j,u in dual_u.items()},
            "dual_offset":str(intercept),"dual_peak_over_all_y":str(peak),
            "primal_objective":str(primal),"dual_objective":str(dual),
            "C_m_over_child_weight":str(primal/child_weight),
        })
    return result


def report():
    return {
        "scope":(
            "Finite actual priced intervals and squares with positive disjoint owners. "
            "The decreasing marked kernels retain the original m_j under the displayed sample gates. "
            "Witness points range over the whole space including exact closed-boundary strata. "
            "These checks concern the witness and kernel interfaces."
        ),
        "python":python_version(),"source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "models":[touching_family(1),fractional_cycle(),touching_family(2,extended=True)],
        "descending_rank_bridge":rank_window_audit(),
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out",type=Path)
    group.add_argument("--check",type=Path)
    args = parser.parse_args()
    result = report()
    data = (json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data,"certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    for item in result["models"]:
        print(f"{item['case']} n={item['n']} parents={len(item['v'])} "
              f"B_t={item['B_t']} membership_patterns={item['witness_membership_patterns']}")


if __name__=="__main__":
    main()

