#!/usr/bin/env python3
"""Frozen periodic unit-lattice pilot; float Monte Carlo, not a finite-source certificate."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,hashlib,json,platform,resource,shlex,signal,sys,time
from pathlib import Path
import numpy as np
import sympy as sp

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args();start=time.perf_counter()
 def stop(*_):raise TimeoutError('60s pilot guard; no parameter expansion')
 signal.signal(signal.SIGALRM,stop);signal.alarm(60)
 seed=60120261024;N=4096;B=4096;block=128
 b,t,n,m=sp.symbols('b t n m',positive=True);logf=m*sp.log(b+1)+(n-m)*sp.log(b)-n*sp.log(b+t)
 derivative=sp.factor(sp.diff(logf,b));res=sp.simplify(sp.diff(logf,b)-((n*t-m)*b+(n-m)*t)/(b*(b+1)*(b+t)));assert res==0
 def tail(values,lam):return {'lambda':float(lam),'strict_tail_count':int(np.count_nonzero(values>lam)),'sample_count':len(values),'empirical_budget':float(lam*np.mean(values>lam))}
 def optimum(values):
  v=np.sort(values)[::-1];scores=v*np.arange(1,len(v)+1)/len(v);k=int(np.argmax(scores));lam=np.nextafter(v[k],0.);d=tail(values,lam);d['supremum_left_limit']=float(scores[k]);d['winning_rank']=k+1;return d
 rows=[]
 for dim in (32,128,512,2048):
  runstart=time.perf_counter();rng=np.random.default_rng(seed);maxima=[];b0wins=0;selected_bs=[];selected_ts=[]
  ranks=np.arange(1,dim+1,dtype=float)[None,:]
  for first in range(0,N,block):
   u=np.sort(rng.random((min(block,N-first),dim)),axis=1);best=-dim*np.log(u[:,-1]);bestb=np.zeros(len(u),dtype=np.int64);bestt=u[:,-1].copy()
   for parity in (0,1):
    T=u if parity==0 else 1-u[:,::-1];den=ranks-dim*T;valid=den>0
    bst=np.divide(T*(dim-ranks),den,out=np.zeros_like(T),where=valid)
    minb=2 if parity==0 else 1;maxb=B if parity==0 else B-1
    bst=np.clip(bst,minb,maxb);lo=np.clip(2*np.floor((bst-parity)/2)+parity,minb,maxb);hi=np.minimum(lo+2,maxb)
    for cand in (lo,hi):
     logs=ranks*np.log1p(1/cand)-dim*np.log1p(T/cand);logs=np.where(valid,logs,0.)
     idx=np.argmax(logs,axis=1);v=logs[np.arange(len(u)),idx];win=v>best;bestb[win]=cand[np.arange(len(u)),idx][win].astype(np.int64);bestt[win]=T[np.arange(len(u)),idx][win];best=np.maximum(best,v)
   maxima.extend(np.exp(best));b0wins+=int(np.count_nonzero(bestb==0));selected_bs.extend(bestb.tolist());selected_ts.extend(bestt.tolist())
  values=np.array(maxima);full=optimum(values);h1=optimum(values[:N//2]);h2=optimum(values[N//2:]);cross1=tail(values[N//2:],h1['lambda']);cross2=tail(values[:N//2],h2['lambda'])
  bs=np.array(selected_bs);ts=np.array(selected_ts)
  def aggregate(keep):
   out=[]
   for chosen in np.unique(bs[keep]):
    vals=ts[keep&(bs==chosen)];out.append({'b':int(chosen),'count':len(vals),'t_quantiles_0_25_50_75_100':np.quantile(vals,[0,.25,.5,.75,1]).tolist()})
   return out
  rows.append({'winner_b_t_aggregation_all_samples':aggregate(np.ones(N,dtype=bool)),'winner_b_t_aggregation_above_full_selected_lambda':aggregate(values>full['lambda']),'n':dim,'samples':N,'seed_reinitialized_each_dimension':seed,'B_max_integer_part':B,'full_sample_optimized':full,'first_half_optimized':h1,'second_half_optimized':h2,'second_half_at_first_half_selected_lambda':cross1,'first_half_at_second_half_selected_lambda':cross2,'both_halves_at_full_selected_lambda':[tail(values[:N//2],full['lambda']),tail(values[N//2:],full['lambda'])],'M_float_min':float(values.min()),'M_float_median':float(np.median(values)),'M_float_max':float(values.max()),'b0_selected_samples':b0wins,'max_selected_positive_b':max(selected_bs),'selected_b_equals_cap_count':sum(x==B for x in selected_bs),'elapsed_seconds':time.perf_counter()-runstart})
 d={'scope':'Periodic infinite unit lattice, not a finite-source halo certificate. Exactly frozen n32,128,512,2048;4096iid uniform centers per dimension; integer part b<=4096.','formula':'u_j=2dist(x_j,Z) iidUniform[0,1]. At b+t, even positive b uses count(u<=t), odd b uses count(1-u<=t); density=(b+1)^m*b^(n-m)/(b+t)^n. At b0 only m=n is nonzero, optimum t=max(u).','event_completeness':'For each fixed b density decreases between sorted entry events. At each event evaluate the maximizing integer b of its parity, so all t events and all b<=B covered in float arithmetic; not an interval proof.','continuous_derivative':str(derivative),'symbolic_derivative_residual':str(res),'monotonicity_proof':'Derivative numerator=(nt-m)b+(n-m)t. If m>nt, maximum occurs at b*=t(n-m)/(m-nt), increasing before/decreasing after. Restricted parity optimum is among nearest legal integers bracketing b*, clamped at positive minimum and B. If m<=nt, density increases to1 as b->infinity, hence <=1 and cannot beat the b0 baseline>=1.','integer_and_tail_numerics':'logdensity=m*log1p(1/b)-n*log1p(t/b). Float ties and near events are not rigorously classified. Empirical optimal lambda is selected on same samples; half-sample cross-selection diagnostics expose tail overfitting. nextafter places lambda below the maximizing sample value for strict tail.','limitations':'No strict probability/confidence lower bound, no uniform-in-lambda concentration certificate, no infinite-b tail bound, no periodic-to-finite truncation loss or finite positive source construction, no dimension-order inference.','results':rows,'execution':{'interpreter':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'sympy':sp.__version__,'processes':1,'block_size':block,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'command':shlex.join([sys.executable,*sys.argv]),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
 args.output.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
 for r in rows:print(json.dumps(r))
 print(d['execution'])
if __name__=='__main__':main()
