#!/usr/bin/env python3
"""Independent labelled-coordinate allocation DP; no author recurrence/import."""
import argparse,hashlib,itertools,json,math,platform,shlex,sys,time
from fractions import Fraction as F
from pathlib import Path

def allowed_from_source_counts(n,D,lam):
 # Bin a means (a-1)/D < u < a/D, ignoring null boundaries.
 # At r=2+j/D coordinate counts 3 if u<j/D, else2.
 # At r=2-j/D=1+(1-j/D), count2 iff u>j/D: n-k factors2.
 # At r=j/D<1, all n coordinates must be captured, so k=n.
 allowed=[]
 for j in range(1,D+1):
  keep=[]
  for k in range(n+1):
   inequalities=[(3**k*2**(n-k)*D**n,(2*D+j)**n),(2**(n-k)*D**n,(2*D-j)**n)]
   if k==n:inequalities.append((D**n,j**n))
   strict=any(num*lam.denominator>den*lam.numerator for num,den in inequalities)
   if not strict:keep.append(k)
  allowed.append(keep)
 return allowed

def labelled_dp(n,D,lam):
 allowed=allowed_from_source_counts(n,D,lam);state=[1]+[0]*n;trace=[]
 for j in range(1,D+1):
  nxt=[0]*(n+1);keep=set(allowed[j-1])
  for k,ways in enumerate(state):
   if ways:
    for l in range(n-k+1):
     if k+l in keep:nxt[k+l]+=ways*math.comb(n-k,l)
  state=nxt;trace.append([str(v) for v in state])
 return state[n],allowed,trace

def direct_exhaustive(n,D,lam):
 # Independent actual cube integer counts at one representative of each bin cell.
 count=0
 for assignment in itertools.product(range(1,D+1),repeat=n):
  x=[F(2*a-1,4*D) for a in assignment];received=False
  for j in range(1,D+1):
   for r in (F(2*D+j,D),F(2*D-j,D),F(j,D)):
    mass=math.prod(sum(abs(v-F(z))<=r/2 for z in range(-2,3)) for v in x)
    if F(mass,1)>lam*r**n:received=True
  count+=received
 return count

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--author-results',type=Path,default=Path(__file__).with_name('RESULTS.json'));ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args();start=time.perf_counter();raw=args.author_results.read_bytes();author=json.loads(raw);small=[]
 for n,D in ((2,2),(3,2),(2,4),(3,4),(4,4)):
  lam=F(5,4);bad,allow,_=labelled_dp(n,D,lam);receive=direct_exhaustive(n,D,lam);assert receive==D**n-bad
  small.append({'n':n,'D':D,'lambda':str(lam),'direct_actual_cube_integer_enumeration_assignments':D**n,'receiving_cells':str(receive),'complement_cells':str(bad),'matches_labelled_DP':True})
 # Strict threshold regression, side1 and mass1 give equality, not reception.
 assert not(F(1)>F(1)*F(1)**2)
 rows=[]
 for D in (32,64,128):
  n=32;lam=F(5);bad,allowed,trace=labelled_dp(n,D,lam);ar=next(r for r in author['results'] if r['D']==D);total=D**n;p=F(total-bad,total)
  assert str(bad)==ar['complement_cells'];assert allowed==ar['complement_allowed_cumulative_counts'];assert p==F(ar['receiving_probability_exact'])
  L=10000;K=9998;factor=F(2*K,2*L+1)**n;periodic=lam*p;finite=periodic*factor
  assert finite==F(ar['finite_q_lower_bound_exact']) and finite>2
  assert F(3,2)+K<L # every chosen cube lies inside finite source coordinate bounds
  rows.append({'n':n,'D':D,'lambda':str(lam),'independently_derived_allowed':allowed,'complement_cells_exact':str(bad),'all_cells_exact':str(total),'receiving_probability_exact':str(p),'periodic_budget_exact':str(periodic),'periodic_budget_display':float(periodic),'boundary_factor_exact':str(factor),'finite_q_lower_bound_exact':str(finite),'finite_q_lower_bound_display':float(finite),'author_complement_count_exact_match':True,'author_allowed_exact_match':True,'author_finite_lower_bound_exact_match':True,'strictly_above2':True})
 d={'scope':'Independent reproduction of three frozen receiving-subdomain certificates, not complete halo volume. No pilot, no source/parameter scan.','source_count_derivation':'u in bin a at x=u/2. Side2+j/D counts3 or2 according to u<j/D, yielding3^k2^(n-k); side2-j/D counts2 or1 according to u>j/D, yielding2^(n-k); sidej/D captures lattice0 in all coordinates iff k=n. Bin boundaries are null. Strict mass>lambda*r^n is implemented by integer cross multiplication.','independent_recurrence':'G_0(0)=1; from k labelled coordinates already assigned to first j-1 unit-width bins, assign l of remaining n-k labels to bin j with binom(n-k,l) choices. Keep only allowed k+l. Complement count=G_D(n). No author recurrence or geometry function imported/executed.','finite_transfer_check':'All chosen cube sides<=3; K+3/2<L certifies captured periodic lattice points occur in finite source[-L,L]^32. The receiving subset restricted to integer number(2K)^32 period cells has volume(2K)^32*p and source mass(2L+1)^32.','strict_equality_regression':'mass1, side1,lambda1 is not strict reception.','small_direct_tests':small,'results':rows,'author_json_raw_sha256':hashlib.sha256(raw).hexdigest(),'all_assertions_passed':True,'execution':{'interpreter':sys.executable,'python':platform.python_version(),'command':shlex.join([sys.executable,*sys.argv]),'runtime_seconds':time.perf_counter()-start,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
 args.output.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n');print(json.dumps({'small_tests':small,'budgets':[(r['D'],r['periodic_budget_display'],r['finite_q_lower_bound_display']) for r in rows],'execution':d['execution']}))
if __name__=='__main__':main()
