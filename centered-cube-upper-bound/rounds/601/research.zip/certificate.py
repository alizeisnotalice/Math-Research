#!/usr/bin/env python3
"""Exact receiving-subset certificate, NOT complete-halo volume or an upper bound."""
from fractions import Fraction as F
from math import comb
from itertools import product
from pathlib import Path
import json,sys,hashlib,time,platform,argparse,shlex

def constraints(n,D,lam):
 out=[]
 for j in range(1,D+1):
  allowed=[]
  for k in range(n+1):
   even=F(3**k*2**(n-k)*D**n,(2*D+j)**n)>lam
   odd=F(2**(n-k)*D**n,(2*D-j)**n)>lam
   zero=k==n and F(D**n,j**n)>lam
   if not(even or odd or zero):allowed.append(k)
  out.append(allowed)
 return out

def certificate(n,D,lam):
 allowed=constraints(n,D,lam);prev=[1]+[0]*n
 for ks in allowed:
  nxt=[0]*(n+1)
  for k in ks:nxt[k]=sum(comb(k,l)*prev[l] for l in range(k+1))
  prev=nxt
 total=D**n;bad=prev[n];p=F(total-bad,total)
 return p,allowed,bad

def main():
 ap=argparse.ArgumentParser();ap.add_argument("--output",type=Path,default=Path(__file__).with_suffix(".json"));args=ap.parse_args()
 start=time.perf_counter();small=[]
 for n,D in ((2,2),(3,2),(2,4),(3,4),(4,4)):
  lam=F(5,4);p,allowed,bad=certificate(n,D,lam);count=0
  for assignment in product(range(1,D+1),repeat=n):
   received=False
   for j in range(1,D+1):
    k=sum(a<=j for a in assignment)
    # Exact actual fixed-radius counts on the whole open cell.
    even=F(3**k*2**(n-k)*D**n,(2*D+j)**n)
    odd=F(2**(n-k)*D**n,(2*D-j)**n)
    zero=F(D**n,j**n) if k==n else F(0)
    if max(even,odd,zero)>lam:received=True
   count+=received
  assert F(count,D**n)==p
  small.append({'n':n,'D':D,'lambda':str(lam),'assignments':D**n,'receiver_count':count,'DP_matches_exhaustive':True})
 rows=[];n=32;lam=F(5);L=10000;c=2;K=L-c;factor=F(2*K,2*L+1)**n
 for D in (32,64,128):
  p,allowed,bad=certificate(n,D,lam);qperiodic=lam*p;qfinite=qperiodic*factor
  rows.append({'n':n,'D':D,'lambda':str(lam),'complement_allowed_cumulative_counts':allowed,'all_cells':str(D**n),'complement_cells':str(bad),'receiving_probability_exact':str(p),'periodic_budget_exact':str(qperiodic),'periodic_budget_display':float(qperiodic),'finite_L':L,'finite_K':K,'finite_source_count':str((2*L+1)**n),'boundary_factor_exact':str(factor),'finite_receiving_volume_lower_bound':str((2*K)**n*p),'finite_q_lower_bound_exact':str(qfinite),'finite_q_lower_bound_display':float(qfinite),'finite_q_strictly_above_2':qfinite>2})
 assert F(rows[-1]['finite_q_lower_bound_exact'])>F(127,50)
 assert all(F(rows[j]['receiving_probability_exact'])<=F(rows[j+1]['receiving_probability_exact']) for j in range(2))
 data={'scope':'Exact finite union of specified fixed-radius reception events on periodic Z^32; finite tensor unit-atom source via interior unit-cell transfer. Gives a lower bound on the full halo, NOT its exact volume, NOT H and NOT any general upper bound.','method':'Integer multinomial cumulative-count DP. F_j(k)=sum_l binom(k,l)F_(j-1)(l), keeping complement-allowed k. Strict level, rational comparisons. Cell boundaries are Lebesgue-null.','source_definition':'All z in Z^32 intersect [-10000,10000]^32, each mass1; lambda5. No source enumeration required.','radii':'For j=1..D: 2+j/D, 2-j/D, and j/D (last only if all coordinates captured). All sides<=3.','finite_transfer':'Interior receivers [-9998,9998]^32. Each radius<=3 cube lies in source bounding region; period1 event volume equals (19996)^32*p. Source mass=(20001)^32.','small_exhaustive_tests':small,'results':rows,'execution':{'interpreter':sys.executable,'python':platform.python_version(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'runtime_seconds':time.perf_counter()-start,'command':shlex.join([sys.executable,*sys.argv])}}
 path=args.output;path.write_text(json.dumps(data,indent=2)+'\n')
 print(json.dumps({'small_tests':small,'budgets':[{'D':r['D'],'periodic':r['periodic_budget_display'],'finite_lower':r['finite_q_lower_bound_display'],'above2':r['finite_q_strictly_above_2']} for r in rows],'execution':data['execution']}))
if __name__=='__main__':main()
