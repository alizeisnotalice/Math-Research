# R233：真实 growing-heavy 分母与共同空间来源价

本稿证明：在原 heavy 有效时间内，局部 hard 帽和同一真实乘积权可给出无 terminal-deficit 截断、无 persistent-subset 逆质量、无 late-clock 补项的正交通估计。与同节点 QG/Gini 上界取 min，再按原尺度求和，得到显式 `ρ^{2/3}(1+log_+ρ)^{1/3}` 来源价。它改进原线性拥挤费用，但该来源矩仍非免费输入预算；不宣称一般根阶闭合。

## HG1 原对象、量词及 heavy 资格

固定原 `(ω,V,j,y)`，以下省去这些指标。令 `n≥2, γ=1+1/n, c=γ^{-j}, 0<a≤b≤2a, q>0, ell=1+log n, τ=a/c`。原有限 hard 来源为 ν，

\[
w_t(v)=\prod_{i=1}^n\min(1,A_i(y,v)/t),\qquad
\mu_t=1_{Z_t}w_t\nu,\quad e_t=\mu_t(V),\quad \Pi_t=\mu_t/e_t.
\]

`A_i=b C(|y_i-v_i|/b)/c>0`，`Z_t` 是原递减、右连续的有限森林 carrier。原分段内 `-d w_t/dlog t=k_t w_t`，`0≤k_t≤n`。无效时刻及 `e_t=0` 行的交通置零。原 positive score 为 `δ_t(v,u)=(k_t(v)-k_t(u))_+`，两份 Π 是同一原后验。

窄核原 R117 `joint_geometry.md` JG1–2：在**实际 heavy 有效时刻**有

\[
e_t>\ell q c^{-n/2}t^n=A_f(t/\tau)^n,
\qquad A_f=\ell q a^n c^{-3n/2}>0.\tag{HG1}
\]

原时域是这些时刻与原 high/history/先前已付支补集等门的交。用 `χ_t(v,u)∈[0,1]` 保留这些正门及其来源依赖；它只在 heavy 有效时刻非零。本文先在 `χ≠0` 使用 HG1，再把显式非负上界积分到节点外窗。绝不声称 HG1 在外放新增时刻成立，也不把 subset endpoint 质量 H 替成 e_t。祖链实际维数与输入资格继续保留；抽象 n≥2 引理不是低维 FULL 输入构造。

## HG2 一般 growing-floor clock 引理

固定 `g_*≥h>τ`，记 `w_*=w_{g_*}`。设 F 和 α 是**不依 t** 的可测函数，

\[
0\le F(v)\le C_0\alpha(v)/\sqrt{w_*(v)},\quad
0\le\alpha\le1,\qquad
m_\alpha=\int_{Z_\tau}\alpha(v)^2\,d\nu(v),\quad C_0=16/3.
\]

则对原同后验、任意上述 χ，

\[
\boxed{
\int_\tau^h\iint \chi_t(v,u)F(v)\delta_t(v,u)
          \,d\Pi_t(v)d\Pi_t(u)\frac{dt}{t}
\le C_0\left(\frac{g_*}{\tau}\right)^{n/2}
       \sqrt{\frac{m_\alpha}{A_f}}
       \left[1-\left(\frac{\tau}{h}\right)^n\right].}\tag{HG2}
\]

如果 `h≤τ` 或 `m_α=0`，左边为零，按空窗解释右边为零。无 heavy 行亦直接为零。不需要 terminal good 存活、H>0、e_t 的导数、或删除补偿信用。

**证明。** 每个坐标的 min 权给 `w_t≤(g_*/t)^n w_*`。在实际 heavy 时刻，用 `δ≤k_t(v)≤n`、另一后验质量为一，以及同一个 e_t 的 Cauchy 不等式，

\[
\begin{aligned}
\iint\chi F\delta\,d\Pi_t^2
&\le\int Fk_t\,d\Pi_t
\le \frac n{e_t}\int_{Z_t}Fw_t\,d\nu\\
&\le\frac n{\sqrt{e_t}}
       \left(\int_{Z_t}F^2w_t\,d\nu\right)^{1/2}
\le nC_0(g_*/t)^{n/2}\sqrt{m_\alpha/e_t}\\
&\le nC_0(g_*/\tau)^{n/2}\sqrt{m_\alpha/A_f}
                  (t/\tau)^{-n}.
\end{aligned}\tag{HG3}
\]

这里 `Z_t⊂Z_τ`，且 `F²w_t≤C_0²(g_*/t)^n α²`。末行只在 HG1 原域使用；对该原域的积分由整个 `[τ,h]` 上末行的积分上控。最后
`n∫_τ^h(t/τ)^{-n}dt/t=1-(τ/h)^n`，得到 HG2。所有步骤为正上界，不领取旧 signed 负项。证毕。

## HG3 同一 receiver/hard-source 列及局域化

沿用已审 R229–232 的节点覆盖。节点 M 从 `M_0=a/c²` 按 γ 上增，最后截于 b，终点不重复；`M_0>b` 时没有节点。两朝向为

\[
(L^*,R^*)=(M,c^2M)\quad\hbox{或}\quad(c^2M,M),
\qquad g_*=cM,\quad w_*=\bar w_{c^2M}.
\]

第三腿尺度不丢：原三腿为 `(A,σ)=(L,s),(min(b,γL),s),(b,1)`，对应合法节点版本。固定一腿、一个 soft 菜单值和朝向。Ω 保原 receiver hardband，因而对每个合法 `B∈[a,b]` 有 `h_B*ν(x)≤C_0q`。只保已证、固定节点后的 capture 排除 `C_*(x,v)∈[0,1]`：原 `R≤L` 分支可保相应 `Q_max(a,R*/γ³)(v)` 排除；原 `R>L` 只有 upper-clamp `H_0≥a` 才保 `Q_a(v)` 排除。lower-clamp 不增添完整 core 排除。其它依 s、实际尺度、t 的门不能伪装成固定 C_*；可按正方向去掉。

定义真实静态列和普通半密度 affinity：

\[
\begin{aligned}
F_{\rm ex}(y,v)&=\frac1q\int\nu(dz)\int_\Omega
C_*(x,v)h_{R^*}(x-z)
\frac{\sqrt{P_{r,L^*}(x-y)P_{\sigma,A^*}(x-v)}}{\sqrt{w_*(y,v)}}\,dx,\\
\alpha_M(y,v)&=\int_\Omega C_*(x,v)
\sqrt{P_{r,L^*}(x-y)P_{\sigma,A^*}(x-v)}\,dx\le1.
\end{aligned}\tag{HG4}
\]

所有核归一。局部帽与已证 QG 是**同一个列的两个不同上界**：

\[
F_{\rm ex}\le\min\left\{
\frac{C_0\alpha_M}{\sqrt{w_*}},\quad
B_ME_*(y,v)\right\},\quad
B_M=\frac{\|\nu\|}{qM^n},\quad
E_*=\exp(-\eta\Delta_*),\quad\eta=25/2^{69}.\tag{HG5}
\]

第一项先在 Ω 内积分 hard z，第二项保 hard z 用固定节点 common-window QG。没有先 cap 后再重复乘 QG。由 HG2，精确列可以保

\[
m_M(y)=\int_{Z_\tau(y)}\alpha_M(y,v)^2\nu(dv)\le\|\nu\|.\tag{HG6}
\]

这保留实际空间来源局域化：每一腿、soft 菜单值、朝向的 α_M 与 m_M 均不同，必须逐项保留。该平方 affinity 来源质量尚没有免费的全局预算；它是精确可计算的下一步空间接口，不能用一个未经控制的共同 α 取代。

## HG4 全 deficit、全 far 偏移的统一节点价

取 `U≥0`，外节点 clock 为 `τ≤t≤h_M=g_*exp(-U/n)`。设

\[
\rho=\|\nu\|/(qa^n),\quad x=n\log(M/M_0),\quad s=x-U.
\]

`s≤0` 为空窗。对 `s>0`，HG2 取 `α=1,m_α≤||ν||` 得

\[
G_{jM}=\frac{C_0}{\sqrt\ell}\sqrt\rho\,c^{3n/4}
e^{x/2}(1-e^{-s}).\tag{HG7}
\]

另一方面 HG5 的统一帽 `F_ex≤B_M` 与同后验 Gini 恒等式

\[
\iint(k_v-k_u)_+\,d\Pi_t(v)d\Pi_t(u)
=\int_0^n\Pi_t\{k>r\}\bigl(1-\Pi_t\{k>r\}\bigr)dr\le n/4
\]

给 `Q_{jM}=B_M s/4=(ρ/4)c^{2n}e^{-U}s e^{-s}`。因此每个实际节点交通满足

\[
\boxed{\mathcal K_{jM}(y)\le\min\{G_{jM},Q_{jM}\}.}\tag{HG8}
\]

保 HG6 时把 HG7 中 `√ρ` 换成 `√(m_M(y)/(qa^n))`，其它幂次不变；Gini 备选仍保原 B_M。所有 terminal deficit 均被包含，没有 `w_g≥e^{-D}` 的条件或 late-clock 项。该式只覆盖原 far 正支，`U=0` 不自动包含此前划分的其它母量。

## HG5 原量回代与明确亚线性来源费

原 positive 母量的外因子为 `2Λ/q`，终端 good 半密度替换给外 `√(K/3)` 和原三腿。固定 `(j,y,t)` 的 Π、e、k、heavy 域不依 receiver x 或 hard 来源 z，故先做 HG4 的 receiver/hard-source 积分合法。原 R229 向上节点损失≤`γ^{4n}≤e^4`，共同 soft 菜单损失4，`N_n≤8+4√n log(n-1)`。不再重做 FIRST，也不重用已 cap 的 hard 核。

若保精确各腿 affinity，必须使用未因式分解的

\[
2\Lambda\sqrt{K/3}\,(4e^4)
\mathbb E\sum_V\sum_{j,M}\sum_{\substack{\text{三腿、两朝向}\\\text{soft 菜单}}}
\int\beta_V(dy)\,\min\{G_{jM}^{\rm affinity}(y),Q_{jM}\}.\tag{HG9}
\]

取统一 `α≤1` 后才可提出至多 `6N_n`，得到

\[
\mathcal P_{\rm far}(U)
\le2\Lambda\sqrt{K/3}\,(24e^4N_n)
\mathbb E\sum_V\int\beta_V(dy)\sum_{j,M}\min\{G_{jM},Q_{jM}\}.\tag{HG10}
\]

本轮 `source_price.md` SP5–6 完整证明、独审已筛过如下节点求和：对正规间距 `h=nlogγ∈[log2,1]` 与一个额外截 b 点，
`Σ min(a_j e^{s/2},b_j s e^{-s})≤min(3b_j,9a_j^{2/3}b_j^{1/3}(1+log_+(b_j/a_j))^{1/3})`。
HG7 中仅丢弃 `1-e^{-s}≤1`，取

\[
a_j=C_0\ell^{-1/2}\sqrt\rho\,c^{3n/4}e^{U/2},\quad
b_j=(\rho/4)c^{2n}e^{-U}.
\]

对原固定 V，a,q,β,ν 在 j 间共同（R230 已审资格），`Σ_j c^{7n/6}≤2`、`Σ_j c^{2n}≤4/3`，所以

\[
\begin{aligned}
\Xi(\rho,U)=\min\bigg\{&\rho e^{-U},\quad
18\left(\frac{C_0^2}{4\ell}\right)^{1/3}\rho^{2/3}
\left[1+\log_+\left(\frac{\sqrt{\ell\rho}}{4C_0}e^{-3U/2}\right)\right]^{1/3}\bigg\},\\
\boxed{\mathcal P_{\rm far}(U)&\le
2\Lambda\sqrt{K/3}\,(24e^4N_n)
\mathbb E\sum_V\|\beta_V\|\Xi(\rho_V,U).}
\end{aligned}\tag{HG11}
\]

`ρ=0` 定义费用为零；若来源、q 或 a 依 j 改变，则停在 HG10 逐 j 价，不能套 HG11。全域空窗 `U≥nlog(b/a)` 直接为零。原 high、capture、RN/history、good/bad、先前付款补集仍在原正母量中；这些正门仅在上述允许方向被上放，没有添加负信用或后验重归一。

新降低的是来源拥挤费用：在大 ρ 时由线性 ρ 降至 `ell^{-1/3}ρ^{2/3}(1+log_+ρ)^{1/3}`，保所有实际尺度、soft 和原 heavy clock。仍未支付 `EΣ||β_V||Xi(ρ_V,U)`，以及外 `√K` 和 soft 菜单费；`Σ||β_V||≤W_β` 本身不足以控制这个加权来源矩。不宣称 `εX+C√n polylog(n)W_β` 或一般弱型目标已闭合。

## HG6 补充：全 carrier 固定-floor 层势

HG2 的粗矩界最简，但分布敏感的层势也可在原全 `Z_t` 上成立，不需要 R232 的 persistent S。给定静态 `F≥0`，设

\[
R_\lambda(t)=\int_{Z_t\cap\{F>\lambda\}}w_t\,d\nu,
\qquad G(z)=\begin{cases}z,&0\le z\le1,\\1+\log z,&z\ge1.\end{cases}
\]

Rλ 非增，原有限森林下分段绝对连续且仅有限向下跳。在无跳片段，`-dRλ/dlog t=∫_{Zt,F>λ}k_t w_t dν`。实际 heavy 时间满足 `e_t≥max(A_f,Rλ(t))`，因此

\[
\begin{aligned}
\int_\tau^h\iint\chi F\delta\,d\Pi_t^2\frac{dt}{t}
&\le\int_0^\infty
\left[G\!\left(\frac{R_\lambda(\tau)}{A_f}\right)
-G\!\left(\frac{R_\lambda(h)}{A_f}\right)\right]d\lambda\\
&\le\int_0^\infty G\!\left(\frac{\mu_\tau\{F>\lambda\}}{A_f}\right)d\lambda.
\end{aligned}\tag{HG12}
\]

证明先以 `1/max(A_f,Rλ)` 控实际 heavy 时间上的连续损失，再补整个 clock 的非负连续损失。连续势降等于总势降减去每个删除跳的
`∫_{R_+}^{R_-}dr/max(A_f,r)≥0`，故不超过总势降。开放或删除端点从原域内单侧取值，dt 零集不影响。删除跳这里只扩大正 majorant，不借用原 signed 删除负账。最后 Tonelli。F 不有界时先截断再单调收敛，允许两侧为无穷。

若 `D_F=∫F²dμτ<∞`，Markov 层尾给

\[
\int_0^\infty G\!\left(\frac{\mu_\tau\{F>\lambda\}}{A_f}\right)d\lambda
\le4\sqrt{D_F/A_f}.\tag{HG13}
\]

`D_F=0` 为零；否则令 `λ_0=√(D_F/A_f)`，`(0,λ_0)` 积分为 `3λ_0`，`(λ_0,∞)` 为 `λ_0`。HG5 还保 `F≤B_M`，可在层势中保有限 λ 上端与真实来源尾。对 HG4，`D_F≤C_0²(g_*/τ)^n m_M(y)`。HG2 给这一粗矩费用更好的常数1和 `1-(τ/h)^n`；HG12 的实际分布敏感版本有时更小，应按同一交通取 min，不重复加账。全 carrier 层势去掉 H 奇异，但其来源尾积分仍不免费。

## HG7 本机核查与范围

作者实际运行本机 Python/Fraction/mpmath（60 位），完成47项检查：36项坐标 min 权比例的有理精确比较、n=2/16/512 与三个 clock 长度的9项 growing-floor 原函数核查、两个相差50数量级的层尾积分核查。返回 `checks=47,dps=60,result=PASS`。这是有限代数/高精度诊断，不是 FULL 物理实例或向外舍入证明；一般结论由上文证明承担。本轮独立数值稿 `heavy_checks.py/json` 另保真实阈值、删除与 heavy 出口的有限过程验证，按其实际记录读取，不把作者47项混入其计数。

作者核查可复现：使用本机既有 mpmath，执行下列 Python。

```python
from fractions import Fraction as Q
import mpmath as mp
mp.mp.dps=60
checks=0
for n in (2,16,512):
 for z in (mp.mpf('0.000001'),mp.mpf('.2'),mp.mpf('2')):
  v=mp.quad(lambda u:n*mp.exp(-n*u),[0,z/n])
  assert abs(v-(1-mp.exp(-z)))<mp.mpf('1e-50');checks+=1
for A in (Q(1,10),Q(1),Q(7,3)):
 for t in (Q(1),Q(5,4),Q(3,2)):
  g=Q(2)
  for k in (Q(1,3),Q(1),Q(4,3),Q(3)):
   assert min(Q(1),k/t)<=g/t*min(Q(1),k/g);checks+=1
for D,A in ((mp.mpf(1),mp.mpf(1)),(mp.mpf('1e-30'),mp.mpf('1e20'))):
 l0=mp.sqrt(D/A)
 v=l0*(mp.quad(lambda u:1-2*mp.log(u),[0,1])
       +mp.quad(lambda u:u**-2,[1,mp.inf]))
 assert abs(v-4*l0)<=mp.mpf('1e-50')*l0;checks+=1
print({'checks':checks,'dps':mp.mp.dps,'result':'PASS'})
```

有限交付止于式 HG11 的实际亚线性来源价和 §HG3 的精确空间平方 affinity 入口；余来源矩仍需后续共同几何结算。
