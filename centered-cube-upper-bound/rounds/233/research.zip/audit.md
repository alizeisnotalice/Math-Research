# R233 independent audit — statement-first checkpoint

Status: FINAL PASS for the specified original positive far-traffic estimates, author integration and recorded numerical implementation; frozen after the independent full replay below. Initial mathematical screening preceded both R233 author proofs. This file alone is auditor-owned. The global arbitrary-positive-L1 root bound is not certified.

## Authentic denominator and allowed domain

Read `task_contract.md` and the R117 `joint_geometry.md` JG1–2 interface. On the original heavy/valid times only,
\[
e_t>\ell q c^{-n/2}t^n=A_\tau(t/\tau)^n,\quad
\tau=a/c,\quad A_\tau=\ell q a^n c^{-3n/2}>0.
\]
The posterior is the original common \(\Pi_t=1_{Z_t}w_t\nu/e_t\), zero on invalid times. A persistent-subset endpoint mass \(H\) may be arbitrarily small; it has no inherited heavy lower bound. After using the heavy inequality on the actual traffic, its nonnegative analytic majorant may be integrated over the full node clock. This does not extend the heavy inequality to invalid times.

## Independent analytic screening

1. **Fixed-floor persistent version is valid.** If \(S\subset Z_T\), \(H=\int_Sw_Td\nu\), and \(\mu=1_S(w_\tau-w_T)\nu\), its level cost is
\[
\int_0^\infty\int_0^{\mu\{F>\lambda\}}
\frac{ds\,d\lambda}{\max(A_\tau,H+s)}.
\]
This follows from the same residual-mass derivative as R232, with the denominator replaced by its actual stronger lower bound. No assumption \(H\ge A_\tau\) is needed.

2. **Full-carrier BV version is valid and needs no persistent/late split.** For static nonnegative \(F(v)\), let
\(R_\lambda(t)=\int_{Z_t\cap\{F>\lambda\}}w_t\,d\nu\). It is nonincreasing BV. Its continuous raw-weight loss is \(\int_{Z_t\cap\{F>\lambda\}}k_tw_t\,d\nu\,d\log t\); deletions add nonnegative drops. With
\[
G(x)=\begin{cases}x,&0\le x\le1,\\1+\log x,&x>1,\end{cases}
\]
the BV chain rule gives a continuous-traffic upper bound
\(G(R_\lambda(\tau)/A_\tau)-G(R_\lambda(h)/A_\tau)\).
At a deletion its additional potential drop is
\(\int_{R_+}^{R_-}ds/\max(A_\tau,s)\ge0\).
This is an added positive majorant cost, not expenditure of the original signed deletion credit. Finite right-continuous forest jumps and one-sided endpoints must be retained in the author proof. Dropping the final potential gives the all-carrier level cost
\[
\Gamma_A(F,\mu_\tau)=\int_0^\infty G(\mu_\tau\{F>\lambda\}/A)\,d\lambda,
\quad\mu_\tau=1_{Z_\tau}w_\tau\nu.
\]

3. **Node tail and moment bounds have the claimed scale price.** Write \(g^*=cM\), \(M_0=a/c^2\), \(x=n\log(M/M_0)\), and \(r_0=\tau/g^*\). The coordinate min weights give
\(w_\tau/w_*\le r_0^{-n}=e^x\). Thus \(F\le C_0/\sqrt{w_*}\) implies
\[
F^2w_\tau\le C_0^2e^x,\qquad
\mu_\tau\{F>\lambda\}\le C_0^2e^x\|\nu\|/\lambda^2.
\]
The exact scalar integral \(\int_0^\infty G(C/(A\lambda^2))d\lambda=4\sqrt{C/A}\) yields
\(4C_0\ell^{-1/2}\sqrt\rho\,c^{3n/4}e^{x/2}\), with \(\rho=\|\nu\|/(qa^n)\). This grows with node scale and cannot alone be reported as a global square-root source bound. An optional common-moment improvement is
\(\Gamma_A=\int F^\downarrow(r)/\max(A,r)dr\le\sqrt{2\int F^2d\mu_\tau/A}\); it does not remove the scale factor.

4. **Growing-floor direct bound is independently verified.** On actual heavy times and for \(r=t/g^*\),
\[
\int Fk_t\,d\Pi_t
\le nC_0r^{-n/2}\frac{\int_{Z_t}\sqrt{w_t}\,d\nu}{e_t}
\le nC_0r_0^{-n/2}\sqrt{\|\nu\|/A_\tau}(t/\tau)^{-n}.
\]
The first inequality uses \(k_t\le n\) and \(w_t\le r^{-n}w_*\); the second uses Cauchy with the same actual \(e_t=\int_{Z_t}w_td\nu\), followed by the growing heavy floor. For \(h>\tau\) its clock integral is at most
\[
\frac{C_0}{\sqrt\ell}\sqrt\rho\,c^{3n/4}e^{x/2}
\bigl(1-e^{-(x-U)}\bigr),\qquad h=g^*e^{-U/n};
\]
it is zero for \(h\le\tau\). The other posterior has mass at most one and \((k_v-k_u)_+\le k_v\). This applies to all current carrier points and all deficits, without endpoint-mass, persistent-survivor, or late-slice assumptions.

## Scale/source sum obligations

The safe direct node bound above can be intersected with the same-node QG/Gini bound, not multiplied by it. Set \(s=x-U\ge0\),
\[
a_j=C_0\ell^{-1/2}\sqrt\rho\,c^{3n/4}e^{U/2},\qquad
b_j=(\rho/4)c^{2n}e^{-U}.
\]
For regular \(s\)-nodes of spacing \(n\log\gamma\in[\log2,1]\) and at most one capped endpoint, independent splitting gives
\[
\sum_M\min(a_je^{s/2},b_jse^{-s})
\le\min\{3b_j,9a_j^{2/3}b_j^{1/3}(1+\log_+(b_j/a_j))^{1/3}\}.
\]
For \(b/a\ge1\), choose the split \(t=\tfrac23[\log(b/a)+\log(1+\log(b/a))]\); the regular and capped contributions are bounded by \(5ae^{t/2}+3be^{-t}(t+1)\), giving 9. For \(b/a<1\), use the linear bound. Since \(\sum_jc_j^{7n/6}<2\) and \(\sum_jc_j^{2n}\le4/3\), a safe common-source total is
\[
\min\!\left\{\rho e^{-U},\;
18\left(\frac{C_0^2}{4\ell}\right)^{1/3}\rho^{2/3}
\left[1+\log_+\!\left(\frac{\sqrt\ell\sqrt\rho e^{-3U/2}}{4C_0}\right)\right]^{1/3}\right\}.
\]
This retains the original outer \(2\Lambda\sqrt{K/3}\), \(24e^4N_n\), receiver/source \(\beta\) integral and leaf/expectation sums. It improves the explicit congestion price, not yet the arbitrary-source input budget.

## Original-quantity qualifications for the forthcoming author audit

The static node cost must first be obtained while retaining the actual receiver hardband \(\Omega\):
\(F=\min(C_0/\sqrt{w_*},B_ME_*)\), \(B_M=\|\nu\|/(qM^n)\).
Only then may receiver gates be positively dropped. No repeated hard cap, free \(\nu\)-to-\(\beta\) substitution, source renormalization, or reintroduction of deleted receiver conditions is authorized. The same actual \(\Pi_t\), original heavy/valid clock, hard source and all three original half-density legs must survive until the appropriate column step. A cut depending on the other source or on time cannot be treated as a static \(F(v)\) without its own uniform domination. Common \(a,q,\nu\) over \(j\) is essential for the displayed geometric sum. The residual expected \(\beta\)-weighted nonlinear \(\rho\)-price, high/other original branches, \(\sqrt K\), and the soft-menu cost remain payable; no root closure or negative-credit payment follows.

## Local computation actually run

Independent local Python run, exit 0: 90 bounded checks of coordinate min-weight ratio/squared comparison, positive BV jump-majorant direction, and midpoint checks of \(\int_0^Lne^{-nz}dz=1-e^{-nL}\). Fraction comparisons were exact; the scalar quadrature was floating diagnostic evidence. These checks are not a physical FULL instance or the proof of the general estimates above.

The preceding checkpoint was written before reading any R233 author proof. The subsequent author audit follows.

## Author proofs and integration review

Read the complete `heavy_geometry.md`, `source_price.md`, parent `proof.tex.txt`, `report.md`, and `reproduce.py`. The theoretical chain passes within its explicitly stated original positive far branch. In particular:

- HG2–3 uses the same actual normalizer and retains the original heavy indicator until the growing-floor majorant is obtained. The optional static spatial factor is charged by \(\int_{Z_\tau}\alpha_M^2d\nu\). Each leg/menu/orientation has its own factor; HG9 correctly retains the full finite sum rather than extracting a free common affinity.
- HG4–5 and SP4–7 compare upper bounds on the same node traffic. Their min is legitimate; the hard local cap and QG are alternative column bounds, not repeated factors. The spacing, unique capped endpoint, all-j common-source condition, geometric constant 9, all-j constant 18 and original outer \(24e^4N_n\,2\Lambda\sqrt{K/3}\) agree with the independent derivation above.
- HG6 and main (6) first use the heavy inequality on actual heavy times, then enlarge the nonnegative continuous raw-loss majorant over the original raw process on the full physical node window. They do not restore a posterior on invalid times. At a deletion, the extra positive potential drop makes the claimed upper bound larger. No favorable signed deletion credit is reused.
- The parent added the requested finite-truncation, \(n\ge2\), \(0<a\le b\le2a\), \(q>0\), finite-source domain and full-raw-window clarification. The only author correction needed after the read was a final cross-reference to the spatial-affinity section (now §HG3); no mathematical change was required.
- The report keeps the all-deficit/full-clock claim confined to the selected original far traffic. It explicitly retains the nonlinear expected source price, \(\sqrt K\), menu fee and other original branches. It does not certify the global endpoint or an input-mass payment.
- The driver copies the contract and self-contained numerical source outside the package, compares the entire regenerated JSON byte-for-byte, and verifies the same manifest before and after. The future parent replay receipt is separate execution evidence; it is not pre-certified by this audit.

Independent local execution of the actual embedded source-note code: 635 assertions at 60 dps, maximum mixed-bound ratio `0.4492643830226752`, scalar tail integral `4.0`, exit 0. Independent execution of the heavy-note embedded code: 47 checks at 60 dps, exit 0. These finite checks support implementation consistency; the universal estimates rest on the proofs.

Numerical-source review identified one scope issue before freezing: the generated cost's former `Delta=-log(wstar)` was not additive QG deficit. The numerical author replaced it with the exact rational additive \(\sum_i(1-\omega_i)\), recording log deficit separately, and restarted the full run. The final frozen numerical result and hash binding remain to be checked below; the earlier JSON is not accepted as evidence for the corrected generated cost.

## Final numerical audit and actual execution

The final `heavy_checks.py` source was read in full, including the added all-current-carrier BV calculation, exact before/after deleted-mass identities, actual additive-deficit generation, capped physical-node enumeration and positive omitted tails. Floor quadrature splits at its transition after a stable change of variable. Product-clock quadrature splits at each threshold, deletion and genuine monotone heavy exit. Empty-heavy and zero-persistent-source branches are retained; the latter can still have positive all-carrier traffic. The node calculation uses the specified gamma grid and its unique cap, checks small dimensions against an independent Fraction physical-scale loop, and pays both omitted-j and omitted-node tails rather than dropping them. Neither ordinary 40/70-dps output nor its positive-tail calculation is advertised as directed interval arithmetic.

Independent complete execution of the final frozen source, exit 0:

`PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 heavy_checks.py --output /tmp/r233_independent_audit_heavy_checks.json`

The script was invoked by its absolute path in this work directory. All **141 configurations** completed: 36 floor, 54 product clocks (also testing full-Z BV/growing-floor), 6 rational tail staircases and 45 physical node menus. Six analytic price comparisons are separate scalar diagnostics. The entire independently generated **1,012,318-byte JSON is byte-identical** to the frozen `heavy_checks.json`, SHA256 `c76b4d7198129f07cfd698d2f637f35bd1e14bab181749b816bdf4f2b78fbda8`. The recorded node ratio upper bound has maximum `0.3121317249961519`; the generated-cost growing-floor ratio has maximum `0.03507977435007009`. These are finite-model diagnostics, not universal sharp constants or FULL original histories.

The corrected additive deficit and separate log-deficit fields were inspected in the final source. The JSON's source and contract hashes equal the actual files. Both Python files parse successfully. `numeric_notes.md` and the final report accurately describe the correction, full run, count and evidence limits. The parent package/manifest replay has not been run by this auditor and will have its own external receipt.

## Final conclusion and frozen binding

No remaining correction blocks the estimates or their recorded implementation. The original heavy floor yields the new all-deficit node estimate without a persistent-subset floor or late error; its proper all-j/node combination gives the stated sublinear congestion price. The unproved step remains the **expected original spatial/source moment** in (10), together with the explicit external parameters and complementary branches. No arbitrary-positive-L1 input budget, new signed refund, or general root endpoint closure is certified.

Final SHA256 table (audit itself intentionally excluded):

| File | SHA256 |
|---|---|
| `task_contract.md` | `7110ecdd088e4819d38baa648c75c963c037b3022704addd0d3b4e5720ab4263` |
| `proof.tex.txt` | `4a07cf3d3813069e763c28eb5beb609a9476db339e7cb732004613e22948541f` |
| `heavy_geometry.md` | `baeeabfdd26bf9830943e0c809e3c4cff9fef5e33acebae3bb6e31fcb7420799` |
| `source_price.md` | `eb825b4cca5be569afd87af41717860a03be290bab6378043fdd8701fb9fa5bb` |
| `heavy_checks.py` | `370999235f8d1fd2da34d1c96a818d3de98b2f35fee9910d1643f93c4d2f7ac4` |
| `heavy_checks.json` | `c76b4d7198129f07cfd698d2f637f35bd1e14bab181749b816bdf4f2b78fbda8` |
| `numeric_notes.md` | `419858b1ba28ed23abc62d9d91878c7ed11c1e820425df86ab5ad1d84b67f8ed` |
| `report.md` | `8ee1be9641b10fc23dc2c0c9678f3d4731cbcc2c86287346e649b9d74a7c270f` |
| `reproduce.py` | `9138ec8d7ba85d7486826476933dcecf9e0f98f1dd1c01b767ff50ece81f5c94` |

Audit frozen; no further writes planned. No Git, PDF compilation or spawned agent was used.
