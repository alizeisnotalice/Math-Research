#!/usr/bin/env python3
"""R233 fixed-floor layer potential and actual heavy-gated finite clocks."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent

def m(x):
 x=F(x);return mp.mpf(x.numerator)/x.denominator

def G_closed(A,H,q):
 if not q:return mp.mpf(0)
 if H>=A:return mp.log1p(m(q/H))
 z=A-H
 return m(min(q,z)/A)+(mp.log(m((H+q)/A)) if q>z else 0)

def G_quad(A,H,q):
 if not q:return mp.mpf(0)
 b=m(A+H);end=mp.log1p(m(q/(A+H)));knots=[mp.mpf(0),end]
 if H<A and q>A-H:knots.insert(1,mp.log(m(2*A/(A+H))))
 def integrand(z):
  s=b*mp.expm1(z);return b*mp.exp(z)/max(m(A),m(H)+s)
 return mp.quad(integrand,knots)

def potential(A,H,mu,cost,dps,quad=True):
 with mp.workdps(dps):
  A,H=F(A),F(H);mu=list(map(F,mu));cost=list(map(F,cost));assert A>0 and H>=0 and min(mu,default=0)>=0 and min(cost,default=0)>=0
  levels=sorted(set([F(0)]+cost));closed=mp.mpf(0);direct=mp.mpf(0);noH=mp.mpf(0);weighted=F(0);rows=[]
  for lo,hi in zip(levels,levels[1:]):
   tail=sum((p for p,f in zip(mu,cost) if f>(lo+hi)/2),F(0));weighted+=(hi-lo)*tail;v=G_closed(A,H,tail);closed+=m(hi-lo)*v;noH+=m(hi-lo)*G_closed(A,F(0),tail)
   if quad:direct+=m(hi-lo)*G_quad(A,H,tail)
   rows.append({'from_cost_exact':str(lo),'to_cost_exact':str(hi),'tail_mass_exact':str(tail),'floor_transition_mass_exact':str(max(F(0),A-H))})
  assert weighted==sum((p*f for p,f in zip(mu,cost)),F(0))
  linear=m(weighted/A);tol=mp.mpf(10)**(-dps+8)*max(1,abs(closed),abs(noH))
  assert closed<=noH+tol and noH<=linear+tol
  if quad:assert abs(closed-direct)<=tol
  return {'A_exact':str(A),'H_exact':str(H),'mu_exact':[str(x) for x in mu],'cost_exact':[str(x) for x in cost],'closed_potential':mp.nstr(closed,32),'direct_layer_quadrature':mp.nstr(direct,32) if quad else None,'closed_vs_quadrature_abs_difference':mp.nstr(abs(closed-direct),16) if quad else None,'no_H_floor_majorant':mp.nstr(noH,32),'linear_bound':mp.nstr(linear,32),'weighted_mass_exact':str(weighted),'levels':rows,'H_zero_branch':H==0,'zero_potential_branch':closed==0,'scope':'Exact rational levels; ordinary closed log evaluation and independently transformed floor quadrature, not interval certification.'}

def floor_menu():
 patterns=[('zero_mass',['0','0'],['0','100']),('same_cost',['1','2','5'],['3','3','3']),('rare_high',['1','1e-30','2'],['1','1e12','0']),('cross_floor',['0','1/10','9/10','10'],['0','1','3','5'])]
 return [{'stage':('initial' if H=='2' else 'stress' if H=='0' else 'expanded'),'name':name,'A':A,'H':H,'mu':mu,'cost':Fs} for H in ('2','0','1e-80') for A in ('1e-60','1','10') for name,mu,Fs in patterns]

def prodF(xs):
 v=F(1)
 for x in xs:v*=x
 return v

def wt_exact(a,t):return F(a['mass'])*prodF(min(F(1),F(alpha)/t)**cnt for alpha,cnt in a['thresholds'])

def clock_model(n,kind,fraction):
 S=[{'mass':'1','cost':'1','thresholds':[['3/5',n]]},{'mass':'2','cost':'3','thresholds':[['4/5',n]]}];E=[{'mass':'3','thresholds':[['11/20',n]],'delete':'3/4'},{'mass':'1/7','thresholds':[['19/20',n]],'delete':'17/20'}]
 if kind=='all_alive':
  for a in E:a['delete']=None
 elif kind=='same_weights':
  for a in S:a['thresholds']=[['3/4',n]];a['cost']='2'
  E=[]
 elif kind=='zero_loss':
  for a in S:a['thresholds']=[['5/4',n]]
 elif kind=='rare_high':S[1]['mass']='1e-30';S[1]['cost']='1e12'
 elif kind=='empty_S':S=[]
 initial=sum((wt_exact(a,F(1,2)) for a in S+E),F(0));A=F(fraction)*initial
 return {'stage':('initial' if n==2 else 'stress' if n==16 else 'expanded'),'n':n,'kind':kind,'A_fraction_initial_e_exact':fraction,'A_exact':str(A),'tau':'1/2','T':'1','persistent_sources':S,'outside_sources':E}

def integrate_heavy(c,dps):
 with mp.workdps(dps):
  n=c['n'];A=F(c['A_exact']);tau=F(c['tau']);T=F(c['T']);S=c['persistent_sources'];E=c['outside_sources'];H=sum((wt_exact(a,T) for a in S),F(0));mu=[wt_exact(a,tau)-wt_exact(a,T) for a in S];cost=[F(a['cost']) for a in S]
  P=potential(A,H,mu,cost,dps,False);knots=sorted(set([tau,T]+[F(alpha) for a in S+E for alpha,cnt in a['thresholds'] if tau<F(alpha)<T]+[F(a['delete']) for a in E if a['delete'] and tau<F(a['delete'])<T]));pieces=[];total=mp.mpf(0);heavy_length=mp.mpf(0)
  def wt(a,t):return m(a['mass'])*mp.fprod(min(1,m(alpha)/t)**cnt for alpha,cnt in a['thresholds'])
  for lo,hi in zip(knots,knots[1:]):
   mid=(lo+hi)/2;alive=[a for a in E if not a['delete'] or mid<F(a['delete'])];scores=[sum(cnt for alpha,cnt in a['thresholds'] if F(alpha)<mid) for a in S]
   def density(t):return sum(wt(a,t) for a in S+alive)
   def gap(t):return density(t)-m(A)*(t/m(tau))**n
   left,right=m(lo),m(hi);branch='empty';end=left
   if gap(left)>0:
    if gap(right)>=0:end=right;branch='whole_piece'
    else:
     rootlo,roothi=left,right
     for _ in range(4*dps):
      rootmid=(rootlo+roothi)/2
      if rootmid==rootlo or rootmid==roothi:break
      if gap(rootmid)>0:rootlo=rootmid
      else:roothi=rootmid
     end=(rootlo+roothi)/2;branch='monotone_heavy_exit'
   val=mp.mpf(0)
   if end>left:
    def integrand(u):
     t=mp.exp(u);return sum(m(a['cost'])*k*wt(a,t) for a,k in zip(S,scores))/density(t)
    val=mp.quad(integrand,[mp.log(left),mp.log(end)]);total+=val;heavy_length+=mp.log(end/left)
   pieces.append({'from_t_exact':str(lo),'to_t_exact':str(hi),'alive_outside_count':len(alive),'persistent_scores':scores,'heavy_branch':branch,'heavy_endpoint':mp.nstr(end,32),'integral':mp.nstr(val,32)})
  # Re-evaluate unrounded closed level sum for comparison.
  bound=sum(m(F(r['to_cost_exact'])-F(r['from_cost_exact']))*G_closed(A,H,F(r['tail_mass_exact'])) for r in P['levels']);tol=mp.mpf(10)**(-dps+8)*max(1,abs(bound));assert total<=bound+tol
  return {'H_exact':str(H),'loss_mass_exact':[str(v) for v in mu],'heavy_direct_integral':mp.nstr(total,32),'fixed_floor_potential':P['closed_potential'],'margin_potential_minus_heavy':mp.nstr(bound-total,32),'heavy_log_clock_length':mp.nstr(heavy_length,32),'no_heavy_branch':heavy_length==0,'H_below_A':H<A,'H_zero_branch':H==0,'fixed_S':True,'complete_original_finite_normalizer':True,'growing_floor':'A*(t/tau)^n','pieces':pieces,'potential':P,'scope':'Heavy gate enforced before quadrature, all actual thresholds/deletions split. No H>=A assumption; no interval certificate or FULL claim.'}

def full_clock_extensions(c,dps):
 with mp.workdps(dps):
  n=c['n'];A=F(c['A_exact']);tau=F(c['tau']);T=F(c['T']);S=c['persistent_sources'];E=c['outside_sources'];allatoms=S+E
  costs={id(a):F(a['cost']) if 'cost' in a else F(2 if i==0 else 5) for i,a in enumerate(E)}
  costs.update({id(a):F(a['cost']) for a in S});levels=sorted(set([F(0)]+list(costs.values())))
  C0=mp.mpf(16)/3;eta=m(F(25,2**69));B=mp.mpf(1 if n==2 else 10**6 if n==16 else 10**100)
  generated={};generated_rows=[]
  for a in allatoms:
   wstar=wt_exact(a,T)/F(a['mass']);log_deficit=-mp.log(m(wstar));Delta_exact=sum((cnt*(1-min(F(1),F(alpha)/T)) for alpha,cnt in a['thresholds']),F(0));Delta=m(Delta_exact);fv=min(C0/mp.sqrt(m(wstar)),B*mp.exp(-eta*Delta));generated[id(a)]=fv
   generated_rows.append({'wstar':mp.nstr(m(wstar),32),'wstar_exact_fraction_sha256':hashlib.sha256(str(wstar).encode()).hexdigest(),'actual_additive_Delta_exact':str(Delta_exact),'log_deficit_separate':mp.nstr(log_deficit,32),'F':mp.nstr(fv,32),'mass_exact':a['mass']})
  def wt(a,t):return m(a['mass'])*mp.fprod(min(1,m(alpha)/t)**cnt for alpha,cnt in a['thresholds'])
  def live(time,after=False):return S+[a for a in E if not a['delete'] or (F(a['delete'])>time if after else F(a['delete'])>=time)]
  def layer_mass(alive,t,level):return sum((wt_exact(a,t) for a in alive if costs[id(a)]>level),F(0))
  def level_potential(alive,t):return sum(m(hi-lo)*G_closed(A,F(0),layer_mass(alive,t,(lo+hi)/2)) for lo,hi in zip(levels,levels[1:]))
  start=level_potential(live(tau,True),tau);end=level_potential(live(T,True),T);jumps=mp.mpf(0);jumprows=[]
  for delete in sorted(set(F(a['delete']) for a in E if a['delete'] and tau<F(a['delete'])<=T)):
   beforealive=live(delete,False);afteralive=live(delete,True);identities=[]
   for fl,fh in zip(levels,levels[1:]):
    level=(fl+fh)/2;bm=layer_mass(beforealive,delete,level);am=layer_mass(afteralive,delete,level);dm=sum((wt_exact(a,delete) for a in E if a['delete'] and F(a['delete'])==delete and costs[id(a)]>level),F(0));assert bm-am==dm and dm>=0;identities.append([str(bm),str(am),str(dm)])
   before=level_potential(beforealive,delete);after=level_potential(afteralive,delete);drop=before-after;assert drop>=0;jumps+=drop;jumprows.append({'time_exact':str(delete),'positive_potential_jump_drop':mp.nstr(drop,32),'exact_layer_mass_jump_identity_sha256':hashlib.sha256(json.dumps(identities).encode()).hexdigest()})
  knots=sorted(set([tau,T]+[F(alpha) for a in allatoms for alpha,cnt in a['thresholds'] if tau<F(alpha)<T]+[F(a['delete']) for a in E if a['delete'] and tau<F(a['delete'])<T]));direct=mp.mpf(0);majorant=mp.mpf(0);growing=mp.mpf(0);heavy_pieces=0
  for lo,hi in zip(knots,knots[1:]):
   mid=(lo+hi)/2;alive=live(mid,True);scores={id(a):sum(cnt for alpha,cnt in a['thresholds'] if F(alpha)<mid) for a in alive}
   def density(t):return sum(wt(a,t) for a in alive)
   def gap(t):return density(t)-m(A)*(t/m(tau))**n
   left,right=m(lo),m(hi);stop=left
   if gap(left)>0:
    if gap(right)>=0:stop=right
    else:
     rl,rh=left,right
     for _ in range(4*dps):
      z=(rl+rh)/2
      if z==rl or z==rh:break
      if gap(z)>0:rl=z
      else:rh=z
     stop=(rl+rh)/2
   def layer_integrand(u):
    t=mp.exp(u);ws={id(a):wt(a,t) for a in alive};v=mp.mpf(0)
    for fl,fh in zip(levels,levels[1:]):
     included=[a for a in alive if costs[id(a)]>(fl+fh)/2];mass=sum(ws[id(a)] for a in included);num=sum(scores[id(a)]*ws[id(a)] for a in included);v+=m(fh-fl)*num/max(m(A),mass)
    return v
   majorant_knots=[left,right]
   for fl,fh in zip(levels,levels[1:]):
    included=[a for a in alive if costs[id(a)]>(fl+fh)/2]
    def rminus(t):return sum(wt(a,t) for a in included)-m(A)
    if rminus(left)>0 and rminus(right)<0:
     rl,rh=left,right
     for _ in range(4*dps):
      z=(rl+rh)/2
      if z==rl or z==rh:break
      if rminus(z)>0:rl=z
      else:rh=z
     majorant_knots.append((rl+rh)/2)
   majorant_knots=sorted(set(majorant_knots))
   majorant+=mp.quad(layer_integrand,[mp.log(v) for v in majorant_knots])
   if stop>left:
    heavy_pieces+=1
    def direct_fun(u):
     t=mp.exp(u);return sum(m(costs[id(a)])*scores[id(a)]*wt(a,t) for a in alive)/density(t)
    def growing_fun(u):
     t=mp.exp(u);return sum(generated[id(a)]*scores[id(a)]*wt(a,t) for a in alive)/density(t)
    direct+=mp.quad(direct_fun,[mp.log(left),mp.log(stop)]);growing+=mp.quad(growing_fun,[mp.log(left),mp.log(stop)])
  tol=mp.mpf(10)**(-dps+9)*max(1,abs(start),abs(majorant));assert direct<=majorant+tol and abs(start-end-majorant-jumps)<=tol
  totalmass=sum((F(a['mass']) for a in allatoms),F(0));r0=m(tau/T);z=n*mp.log(m(T/tau));bound=C0*mp.sqrt(m(totalmass/A))*r0**(-mp.mpf(n)/2)*(-mp.expm1(-z));assert growing<=bound*(1+mp.mpf(10)**(-dps+8))
  return {'all_source_costs_exact':[str(costs[id(a)]) for a in allatoms],'start_all_Z_floor_potential':mp.nstr(start,32),'end_all_Z_floor_potential':mp.nstr(end,32),'endpoint_potential_drop':mp.nstr(start-end,32),'continuous_all_clock_layer_majorant':mp.nstr(majorant,32),'positive_deletion_jump_drop':mp.nstr(jumps,32),'chain_identity_abs_error':mp.nstr(abs(start-end-majorant-jumps),16),'jump_rows':jumprows,'all_Z_continuous_heavy_score_integral':mp.nstr(direct,32),'all_Z_bound_margin':mp.nstr(start-end-direct,32),'heavy_pieces':heavy_pieces,'growing_floor_generated_cost_sources':generated_rows,'growing_cost_B':mp.nstr(B,32),'eta_exact':str(F(25,2**69)),'gstar':'1','r0':mp.nstr(r0,32),'z_n_log_h_over_tau':mp.nstr(z,32),'growing_cost_all_Z_heavy_integral':mp.nstr(growing,32),'growing_floor_bound':mp.nstr(bound,32),'growing_floor_bound_ratio':mp.nstr(growing/bound,32),'scope':'All current Z_t, deletion atoms carry costs; positive jumps only in the BV chain. No persistent assumption for this bound. Generated static F satisfies the actual product wstar upper envelope; not original spatial qualification/FULL.'}


def compact_potential(p):
 p=dict(p);rows=p.pop('levels');p['level_count']=len(rows);p['exact_level_identity_sha256']=hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest();p.pop('mu_exact');p.pop('cost_exact');return p

def tail_menu():
 out=[]
 for q in (F(2),F(3,2),F(11,10)):
  costs=[];x=F(1,100)
  while x<=100:costs.append(x);x*=q
  mu=[1/costs[i]**2-1/costs[i+1]**2 for i in range(len(costs)-1)]+[1/costs[-1]**2]
  for H in ('0','1e-20'):out.append({'ratio':str(q),'H':H,'costs':costs,'mu':mu})
 return out

def difference(a,b,key):
 with mp.workdps(70):
  v=abs(mp.mpf(a[key])-mp.mpf(b[key]))/max(1,abs(mp.mpf(b[key])));assert v<mp.mpf('1e-25');return mp.nstr(v,16)

def node_menu():
 rows=[]
 for n in (2,16,64):
  for b in ('1','2'):
   for T in ('-10','10'):
    for U in ('0','1/2'):rows.append({'stage':'node_initial','n':n,'b':b,'log_rho':T,'U':U})
 for n in (512,4096,1000000):
  for T in ('0','50','200'):
   for U in ('0','3'):rows.append({'stage':'node_expanded','n':n,'b':'2','log_rho':T,'U':U})
 for n in (2,16,512):rows.append({'stage':'node_cap_boundary','n':n,'b_gamma_power':2,'log_rho':'20','U_node':1})
 return rows

def node_sum(c,dps):
 with mp.workdps(dps):
  n=c['n'];h=n*mp.log(1+mp.mpf(1)/n);ell=1+mp.log(n);C0=mp.mpf(16)/3;T=m(c['log_rho']);X=min(c['b_gamma_power']*h,n*mp.log(2)) if 'b_gamma_power' in c else n*mp.log(m(c['b']));U=c['U_node']*h if 'U_node' in c else m(c['U'])
  loglinear=T-U;logarg=mp.log(ell)/2+T/2-3*U/2-mp.log(4*C0);lognonlinear=mp.log(18)+mp.log(C0*C0/(4*ell))/3+2*T/3+mp.log(1+max(logarg,mp.mpf(0)))/3;logprice=min(loglinear,lognonlinear)
  actualj=int(mp.floor(X/(2*h)))+1
  while 2*actualj*h<=X:actualj+=1
  while actualj and 2*(actualj-1)*h>X:actualj-=1
  surplus=max(mp.mpf(0),loglinear-logprice);limitJ=max(1,int(mp.ceil((surplus+110)/(2*h))));J=min(actualj,limitJ);L=150+surplus;total=mp.mpf(0);count=0;omitted_inner=False
  def term(j,x):
   s=x-U
   if s<=0:return mp.mpf(0)
   logA=mp.log(C0)-mp.log(ell)/2+T/2-mp.mpf(3)*j*h/4+x/2+mp.log(-mp.expm1(-s));logG=T-mp.log(4)-2*j*h-x+mp.log(s)
   return mp.exp(min(logA,logG)-logprice)
  for j in range(J):
   cap=X-2*j*h;K=max(0,int(mp.floor(U/h))+1)
   while K*h<=U:K+=1
   while K>0 and (K-1)*h>U:K-=1
   k=K
   while k*h<cap and k*h-U<=L:
    total+=term(j,k*h);count+=1;k+=1
   if k*h<cap:omitted_inner=True
   if cap>U:
    if cap-U<=L:total+=term(j,cap);count+=1
    else:omitted_inner=True
  jtail=mp.exp(loglinear-logprice-2*J*h) if J<actualj else mp.mpf(0)
  innertail=mp.exp(loglinear-logprice-L)*(3*L+2)/3 if omitted_inner else mp.mpf(0)
  upper=total+jtail+innertail;assert upper<=1+mp.mpf('1e-28')
  brute_diff=None
  if n<=64:
   gamma=F(n+1,n);b=min(gamma**c['b_gamma_power'],F(2)) if 'b_gamma_power' in c else F(c['b']);check=mp.mpf(0);j=0
   while gamma**(2*j)<=b:
    M0=gamma**(2*j);M=M0
    while M<b:check+=term(j,n*mp.log(m(M/M0)));M*=gamma
    check+=term(j,n*mp.log(m(b/M0)));j+=1
   brute_diff=abs(check-total);assert brute_diff<mp.mpf('1e-28')
  return {'n':n,'log_rho':mp.nstr(T,32),'U':mp.nstr(U,32),'ell':mp.nstr(ell,32),'n_log_gamma':mp.nstr(h,32),'X_n_log_b':mp.nstr(X,32),'actual_j_count':actualj,'evaluated_j_count':J,'evaluated_node_count':count,'sum_over_min_price_partial':mp.nstr(total,32),'omitted_j_tail_over_price_upper':mp.nstr(jtail,16),'omitted_inner_tail_over_price_upper':mp.nstr(innertail,16),'sum_over_min_price_upper':mp.nstr(upper,32),'margin_to_price_one':mp.nstr(1-upper,32),'log_linear_price':mp.nstr(loglinear,32),'log_nonlinear_price':mp.nstr(lognonlinear,32),'small_n_physical_rational_loop_difference':mp.nstr(brute_diff,16) if brute_diff is not None else None,'scope':'Actual j and physical capped M nodes. Positive omitted tails use linear G majorants and R230 per-j bound; evaluated in ordinary high precision, not interval certification.'}

def price_comparisons():
 out=[]
 with mp.workdps(70):
  for n in (512,1000000):
   ell=1+mp.log(n);C0=mp.mpf(16)/3
   for rho in (10**6,10**12,10**24):
    r=m(rho);price=18*(C0*C0/(4*ell))**(mp.mpf(1)/3)*r**(mp.mpf(2)/3)*(1+max(mp.log(mp.sqrt(ell*r)/(4*C0)),mp.mpf(0)))**(mp.mpf(1)/3)
    out.append({'n':n,'rho_exact':str(rho),'U':'0','new_analytic_price_over_old_rho':mp.nstr(min(r,price)/r,32),'scope':'Analytic price comparison only, not an actual extremal ratio.'})
 return out

def main(output):
 floors=[];clocks=[];tails=[]
 for c in floor_menu():
  lo=potential(c['A'],c['H'],c['mu'],c['cost'],40);hi=potential(c['A'],c['H'],c['mu'],c['cost'],70);floors.append({'configuration':c,'at_40dps':compact_potential(lo),'at_70dps':compact_potential(hi),'relative_precision_difference':difference(lo,hi,'closed_potential')})
 for n in (2,16,512):
  for kind in ('all_alive','delete_outside','same_weights','zero_loss','rare_high','empty_S'):
   for fraction in (('1e-100','1/2','2') if n==512 else ('1/1000','1/2','2')):
    c=clock_model(n,kind,fraction);lo=integrate_heavy(c,40);hi=integrate_heavy(c,70);exlo=full_clock_extensions(c,40);exhi=full_clock_extensions(c,70);lo['potential']=compact_potential(lo['potential']);hi['potential']=compact_potential(hi['potential']);clocks.append({'configuration':c,'at_40dps':lo,'at_70dps':hi,'relative_precision_difference':difference(lo,hi,'heavy_direct_integral'),'all_Z_at_40dps':exlo,'all_Z_at_70dps':exhi,'all_Z_precision_difference':difference(exlo,exhi,'all_Z_continuous_heavy_score_integral'),'growing_floor_precision_difference':difference(exlo,exhi,'growing_floor_bound_ratio')})
 for c in tail_menu():
  checks=[]
  for i,f in enumerate(c['costs']):
   tail=sum(c['mu'][i:],F(0));assert tail*f*f<=1;checks.append({'cost_upper_exact':str(f),'tail_mass_below_cost_exact':str(tail),'tail_times_cost_squared_exact':str(tail*f*f)})
  lo=potential('1',c['H'],c['mu'],c['costs'],40);hi=potential('1',c['H'],c['mu'],c['costs'],70);assert mp.mpf(hi['closed_potential'])<4
  tails.append({'configuration':{'stage':'expanded_tail','ratio':c['ratio'],'H':c['H'],'A':'1','D':'1','atom_count':len(c['costs'])},'exact_tail_summary':{'interval_count':len(checks),'all_tail_cost_squared_at_most_one':True,'checks_sha256':hashlib.sha256(json.dumps(checks,sort_keys=True).encode()).hexdigest(),'construction':'cost_i=(1/100)q^i<=100; mu_i=cost_i^-2-cost_(i+1)^-2, final mu=cost_last^-2'},'at_40dps':compact_potential(lo),'at_70dps':compact_potential(hi),'relative_precision_difference':difference(lo,hi,'closed_potential'),'analytic_upper':'4*sqrt(D/A)=4'})
 nodes=[]
 for c in node_menu():
  lo=node_sum(c,40);hi=node_sum(c,70);nodes.append({'configuration':c,'at_40dps':lo,'at_70dps':hi,'relative_precision_difference':difference(lo,hi,'sum_over_min_price_upper')})
 result={'actual_node_sum_cases':nodes,'analytic_price_comparisons':price_comparisons(),'actual_node_sum_formula':'sum_j,M min{(C0/sqrt(ell))*sqrt(rho)*c_j^(3n/4)*exp(x/2)*(1-exp(-(x-U))), (rho/4)*c_j^(2n)*exp(-x)*(x-U)} for x>U.','actual_node_sum_price':'min{rho exp(-U),18(C0^2/(4ell))^(1/3)rho^(2/3)[1+log_+(sqrt(ell)*sqrt(rho)*exp(-3U/2)/(4C0))]^(1/3)}; original outer prefixes retained.','schema':'R233_actual_heavy_fixed_floor_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'contract_sha256':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'source_method':'Self-contained product-clock rules adapted from R232 weighted_checks.py sha256 7f7347234c67f70a96883346165a6fbacecfc3fd6c51e25b7e35a423391e7c83.','case_count':len(floors)+len(clocks)+len(tails)+len(nodes),'fixed_floor_cases':floors,'actual_heavy_product_clock_cases':clocks,'finite_tail_cases':tails,'analytic_no_H_tail_constant':{'majorant':'G_A,0(m)=m/A if m<=A, else 1+log(m/A)','split':'lambda0=sqrt(D/A); integrals below/above lambda0 are 3lambda0 and lambda0','constant':4,'scope':'Analytic majorant integral, not a finite-sample fitted constant.'},'scope':['Fixed common S and complete current normalizer, deletions only outside S.','Actual heavy times use growing A(t/tau)^n; fixed A enters only the proven candidate upper potential.','No assumption H>=A, no negative/deletion credits, no separate cost-layer posteriors.','Ordinary highprecision quadrature and exact rational level/tail identities, not interval proof.','No actual spatial source-price or histories/FULL certification.']}
 output.write_text(json.dumps(result,indent=2)+'\n');print('complete',result['case_count'],'floor',len(floors),'clock',len(clocks),'tail',len(tails),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'heavy_checks.json');main(ap.parse_args().output)
