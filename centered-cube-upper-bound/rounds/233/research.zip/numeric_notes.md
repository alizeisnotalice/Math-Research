# R233 运行前有限方案

固定A>0、H≥0、非负loss质量mu_i与固定costF_i，层势Psi=sum cost-level宽度 G_A,H(tailmass)，G=integral_0^mass ds/max(A,H+s)。闭式按H≥A与H<A、mass是否超过A−H分支；H0/零mass/零cost单独保留。独立直接求积采用s=(A+H)expm1(z)变换并在H+s=A分片，避免极小H或巨大mass的普通线性求积失真。36个固定floor例覆盖H0/1e−80/2，A1e−60/1/10、零mass/同cost/rare高cost/跨floor边界。

复用R232的实际productweight规则但脚本自足：固定persistentS，e_t含全部当前来源，删除只在S外。n2/16/512，每6模式、3个A（initial e_tau的.001/.5/2倍），共54例。新增真实heavy门e_t>A(t/tau)^n；因e_t递减而floor递增，逐threshold/删除分片定位唯一连续交点后只对真实heavy部分直接积分。heavy上界用同S、同loss与固定floor势，不假设H≥A。保没有heavy的分支，不回收删除负credit。40/70dps独立核验。

另6个有限有理lambda^-2尾阶梯：lambda从.01到约100，ratio2/1.5/1.1，H0/1e−20，A=D=1；精确Fraction证明每一层tail≤1/lambda²，核Psi≤4sqrt(D/A)。无H floor核在mass≤A时mass/A，超过时1+log(mass/A)；将此majorant对D/lambda²在lambda0=sqrt(D/A)两侧解析积分得3lambda0+lambda0=4lambda0。常数4来自解析积分而不是有限拟合。总96例；不扩空间模型，不认证FULL，完整--output字节复跑与合同/源码绑定。

## 实际扩展与决定性结果

原96例固定floor/固定S heavy时钟已实际通过。A1、H0或1e−80的同rare高cost配置，固定floor势均为约1+1e−18，而R232相同loss/cost无floor、H1e−80势约1.15e14。这是保留分母floor后的实际smallH改善，不把势免费当预算。六个有理tail≤lambda^-2阶梯的q2/1.5/1.1势约2.85976/3.26439/3.78660，均低于解析常数4；所有tail层质量乘cost上端平方精确≤1。常数4来自解析split，不是有限拟合。

按父级新增审定命题，同54时钟另计算全Z_t、带cost删除来源的BV层账：Rlambda(t)=∑当前alive且cost>lambda wtν；端点势为∫lambda[G(Rlambda(tau)/A)−G(Rlambda(h)/A)]。直接heavy连续score≤连续全clock层majorant；端点势差=连续majorant+正删除jump。删除jump只作非负majorant/链恒等式记录，不从别处借负credit。每个删除时刻每层的before−after=deleted质量以Fraction精确核验并保存摘要。S空的模型在本全Z版本仍可有非零交通，不再依赖persistent H。

为避免主维度时growingfloor在首阈值前已关门而全零，n512的最小A/e_tau从初探.001明确调整为1e−100；其余两值.5/2不变，n2/16仍.001/.5/2。不增加模型族。n512同权cost2例的全clock层majorant约294.58644，但真正heavy积分仅22.66037，展示真实growing门作用。删除模型中n512、A/e_tau1e−100，全Z重成本原门积分约1.72331，continuous majorant≈259.68184、端点势差≈799.87871、正jump≈540.19687。70dps最大BV链绝对误差约2.55e−57，发生在大cost值例；40/70dps归一输出一致。普通数值误差不作区间证书。

## 直接growingfloor与actual additive折扣

同一原子/删除/真实heavy时钟生成固定F=min(C0/sqrt(wstar),B exp(−eta Delta*))，C0=16/3，eta=25/2^69；wstar为gstar=1的实际product weight（去mass）。Delta*严格用实际additive sum cnt(1−min(1,alpha/T))，以Fraction保存；−logwstar单独标log_deficit_separate，不作实际additive折扣。审计指出初版误用log deficit后，旧计算已停止并全部重跑正确版本。

核直接界∫全Z F k Pi 1_heavy dt/t≤C0 sqrt(nu/A) r0^(−n/2)(1−exp(−z))，r0=tau/gstar=.5，z=nlog(h/tau)>0。B在n2/16/512取1/1e6/1e100；完整当前e_t及所有当前来源保留。所有54个实际成本时钟通过，最大界比约.0350798（n16空S但全Z仍有删除来源），没有用prescribed F替换actual additive折扣。此处weights是有限product clocks，不认证真实空间来源或原history资格。

## 真正j/node求和与源价比较

compare给准LHS：对x=nlog(M/M0j)、s=x−U>0，sum min{(C0/sqrtell)sqrtrho cj^(3n/4) exp(x/2)(1−exp(−s)), (rho/4)cj^(2n) exp(−x)s}，M0j=cj^−2、cj=gamma^−j、gamma=1+1/n、a1、b∈[1,2]，每j独立保唯一b cap。右侧取min{rho exp(−U),18(C0²/(4ell))^(1/3)rho^(2/3)[1+log_+(sqrtell sqrtrho exp(−3U/2)/(4C0))]^(1/3)}。全j线性系数为1，不误用每j的3/4；原24e4N及2Lambda sqrtK/3等外前缀仍在外。

45个三阶段真实节点配置，n2/16/64初探，节点/封顶边界压力，n512/4096/1e6扩大；T=logrho作为输入，避免rho overflow。小n独立用Fraction物理M=M0 gamma^k生成节点/封顶，与规范坐标求和对比；大n不枚举百万平方：只截断显式正尾，遗漏j尾由R230每j线性界给rho exp(−U) exp(−2Jh)，遗漏inner/cap尾由(3L+2)exp(−L)指数majorant；两尾单独报出，非丢弃。最大实际sum/两价min上界约.312131725，出现在n16,b2,logrho−10,U.5；40/70dps32位输出一致，小n物理Fraction loop输出也一致。有限结果不证明通用常数18，作者/独审负责一般预算证明。

六个解析新价/旧rho标量复核：U0，n512下rho1e6/1e12/1e24约.3221859919/.004179761604/5.338887357e−7；n1e6下约.2588416001/.003322542548/4.223737074e−7，与父级独立值吻合。这只是解析价格数值比较，不是真实极值或输入比。

最终总141配置（36 floor+54时钟含全Z/growing附核+6尾阶梯+45节点），只保必要scalars、精确输入和摘要，避免逐积分大dump。不认证FULL、原来源空间容量已免费付清或一般root目标闭合。

最终correct-additive源码以独立--output路径全JSON复跑逐字节一致。141配置；JSON字节数1012318；JSON SHA256：c76b4d7198129f07cfd698d2f637f35bd1e14bab181749b816bdf4f2b78fbda8；源码SHA256：370999235f8d1fd2da34d1c96a818d3de98b2f35fee9910d1643f93c4d2f7ac4。JSON无runtime/输出路径。全部本轮有限任务完成，停止。
