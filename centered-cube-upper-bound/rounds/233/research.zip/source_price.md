# R233：heavy 分母后的亚线性来源价

**主结论。** 原 heavy 门没有在当前实际 clock 中消失。用本轮 growing-floor 节点界，保同一真实 `β,ν,q,a` 跨比例带求和，可将 R230 的线性来源拥挤价 `ρ` 改进成显式的 `ρ^{2/3}(1+log_+ρ)^{1/3}` 价，并与原 `ρe^{-U}` 取较小者。下面完整证明来源层尾及几何节点求和；growing-floor 的一般 clock 定理由本轮 `heavy_geometry.md` 负责，不重复其 BV 层势证明。这仍是实际来源矩费用，不是免费 `W_β` 预算，也不证明一般根阶闭合。

## SP1 原 heavy 门的窄核与当前适用域

本轮 `task_contract.md` 明确要求保原 heavy 时域。窄核原文：

* [R117 joint_geometry.md:25–32](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:25)，JG2：`τ=a/c≤t≤bc` 且 `e_t>ell q c^{-n/2}t^n`，`ell=1+log n`。`e_t` 非增，右侧严格增，因此非空 heavy 集是由 τ 开始的初始区间，开放右端从域内取极限；若 τ 不合格，后续亦无合格时间。
* [同稿:15–23](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:15)：`Π_t=1_{Z_t}w_tν/e_t`，原 `Z_t` 递减，`w_t` 正且非增。它不是按 receiver 或来源代价层重建的后验。
* [R215 proof.tex.txt:211–221](/Users/zhengzhihao/Desktop/T/output/centered_cube_round215_20261016_final_checkpoint/proof.tex.txt:211)：`I^0` 是**原 clock 域**与 `[a/c,bc]` 的交，不是用这个外区间替代原域。
* R232 冻结 `weighted_survival.md` WS2、WS5–6 仍对原有效过程和同一 `Π_t` 工作，无效行置零；其 receiver/node enlargement 没有授予新的 heavy 行。本轮使用的是该实际正母量，不是把已放松的 R215 W4 反称原门。

因此，在固定原 `(ω,V,j,y)` 后，必须保实际 heavy 指示 `1_{I_{j,V,y}}(t)`；仅在这些时刻可用

\[
 e_t\ge A_f(t/\tau)^n,\quad
 A_f=\ell q c^{-n/2}\tau^n
     =\ell q a^n c^{-3n/2}. \tag{SP1}
\]

对 Gini 备选界可正上放到整个节点 clock；对 floor 界不能先丢 heavy 指示再补回。以下不假设 terminal subset 质量 `H≥A_f`，不使用 β 的后验化、soft rank 或新的全局来源密度帽。祖链其它实际维数/soft/历史门照原保留，抽象 n≥2 公式不构造低维 FULL 输入。

## SP2 固定节点的真实静态列

`γ=1+1/n`、`c=c_j=γ^{-j}`、`M_0=a/c²`。R229 的有限向上网格从 `M_0` 开始，按 γ 倍增，最后截于 b，若已恰为 b 不重复；`M_0>b` 时为空。原节点仍满足 `a≤L^*,R^*≤b≤2a`、`g^*=cM`、`m^*=c²M`，并且使用原三腿。

记

\[
 \rho=\frac{\|\nu\|}{qa^n},\qquad
 B_M=\rho(a/M)^n,\qquad
 F_M(y,v)=\min\left\{\frac{C_0}{\sqrt{w_*(y,v)}},\ B_ME_*(y,v)\right\},
 \quad C_0=16/3. \tag{SP2}
\]

这里 `w_*=\bar w_{m^*}`、`E_*=exp(-ηΔ_*)` 为原 exact-min 节点权与已审 QG 缺口。SP2 是 R231/R232 对**同一个 receiver/hard-source 列**的两个上界取 min：第一项使用原 Ω 内全部合法物理尺度的局部 hard 帽与普通 affinity≤1；第二项保 hard 来源后用 QG。不能将它解释为先 cap 再额外乘一次 QG，也没有把 hard z 限制为后验来源。

固定 far 偏移 `U≥0`，令

\[
 x=n\log(M/M_0),\qquad s=x-U.
\]

`s≤0` 时节点无 clock；`s>0` 时实际节点外窗为 `[τ,g^*e^{-U/n}]`，其 `dlog t` 长为 `s/n`。F_M 独立 t，真实 high/capture/history 等门仍保原值，或仅在合法方向作 `[0,1]` 正上放。

## SP3 候选平方层尾确实成立

令 `r_0=τ/g^*=M_0/M=e^{-x/n}`。原乘积权给

\[
 w_\tau(y,v)\le r_0^{-n}w_*(y,v).
\]

对初始实际加权来源 `μ_τ=1_{Z_τ}w_τν`，任何 `λ>0` 由 `F_M>λ⇒w_*<C_0²/λ²` 推出

\[
 \boxed{\mu_\tau\{F_M>\lambda\}
 \le\frac{C_0^2r_0^{-n}\|\nu\|}{\lambda^2}.} \tag{SP3}
\]

旧 R232 persistent 损失测度 `μ≤μ_τ` 同样适用。这里只比较相同来源上的原权，不把 β 换成 ν，也不声称未加权 ν 有 `λ^{-2}` 尾。

若调用本轮 fixed-floor 层引理，令 `G(z)=z`（`0≤z≤1`）、`G(z)=1+log z`（`z≥1`），则 SP3 单独给

\[
 \int_0^\infty G\left(\frac{\mu_\tau\{F_M>\lambda\}}{A_f}\right)d\lambda
 \le4C_0r_0^{-n/2}\sqrt{\|\nu\|/A_f}. \tag{SP4}
\]

证明只需代换 `λ=√(C_0²r_0^{-n}||ν||/A_f)u`，以及
`∫_0^1(1-2log u)du+∫_1^∞u^{-2}du=3+1=4`。此式去掉了原未付小 H 逆量，但下面 growing floor 更强，主结论不采用 SP4 的因子4。

## SP4 主 clock 接口与两个节点上界

本轮 `heavy_geometry.md` 的 growing-floor 界（本文先以该主线接口为前提，其最终独审状态与主稿同步），在原 heavy 域、原全 `Z_t` 与同一 Π 下给出

\[
 \boxed{\mathcal K_{j,M}(y)
 \le\frac{C_0}{\sqrt\ell}\sqrt\rho\,c^{3n/4}
        e^{x/2}(1-e^{-s}),\qquad s=x-U>0.} \tag{SP5}
\]

此接口无需固定 persistent subset、无需 H 下界，且不留 late clock。其指数核对如下：`F_M≤C_0/√w_*`、`w_t≤(g^*/t)^n w_*`，Cauchy 与 SP1 给瞬时 score 价≤`nC_0√(||ν||/A_f)r_0^{-n/2}e^{-z}`，其中 `z=nlog(t/τ)`；积分 `z∈[0,s]` 即 SP5。这里只列来源/幂次核对，一般有效域、零行与 BV 补充归主 clock 稿。

另一方面 `F_M≤B_M` 与原同后验 Gini 给

\[
 \mathcal K_{j,M}(y)\le
 \frac\rho4c^{2n}e^{-U}s e^{-s}. \tag{SP6}
\]

两个上界估同一节点的实际正交通，因此可取 min，不作相加信用。丢弃 SP5 中 `1-e^{-s}≤1` 后，设

\[
 a_j=\frac{C_0}{\sqrt\ell}\sqrt\rho\,c^{3n/4}e^{U/2},\qquad
 b_j=\frac\rho4c^{2n}e^{-U},
\]

则

\[
 \mathcal K_{j,M}(y)\le
 \min\{a_je^{s/2},\ b_js e^{-s}\}. \tag{SP7}
\]

SP5–7 对所有真实来源 y 一致，才可在后续 β 积分中提出。它们没有消去 `√K`、soft 菜单或真实来源质量。

## SP5 混合几何节点引理及完整证明

令 `log2≤h≤1`、`0≤s_0<h`，正规节点为 `s=s_0+kh,k≥0`，另允许至多一个非正规截断点 `s_cap≥0`。对 a,b>0，

\[
 \boxed{\sum_{\rm regular+cap}\min\{ae^{s/2},bs e^{-s}\}
 \le\min\left\{3b,\ 9a^{2/3}b^{1/3}
              (1+\log_+(b/a))^{1/3}\right\}.} \tag{SP8}
\]

有限节点子集可先正上放到完整正规尾。正规 `Σ s e^{-s}≤2`：令 `q_0=e^{-h}≤1/2`，精确和为
`e^{-s0}[s0/(1-q0)+h q0/(1-q0)^2]≤2(s0+1)e^{-s0}≤2`。额外截断点 `s e^{-s}≤1`，得3b。

若 b≤a，`a^{2/3}b^{1/3}≥b`，第二个9倍界随3b成立。若 `r=b/a≥1`，记 `L=log r`，取

\[
 t=\frac23[L+\log(1+L)],\qquad
 K=a^{2/3}b^{1/3}(1+L)^{1/3}=ae^{t/2}.
\]

对正规 `s≤t` 使用增长帽，逆几何和给≤`ae^{t/2}/(1-e^{-h/2})<4K`。对正规 `s>t` 使用衰减帽；从首个这样的点 `s'≥t` 起，精确尾和≤`2b(s'+1)e^{-s'}≤2b(t+1)e^{-t}`，因为 `(s+1)e^{-s}` 非增。唯一截断点若在 t 前，其价≤K；若在 t 后，则≤`b(t+1)e^{-t}`，故无条件可再上放为两者之和。总价≤

\[
 5K+3b(t+1)e^{-t}.
\]

由 `log(1+L)≤L`，`t+1≤(4/3)(1+L)`，而
`be^{-t}=K/(1+L)`，所以总价≤`5K+4K=9K`。证毕。实际原节点 far 后的正规偏移恰在 `[0,h)`，`h=nlogγ∈[log2,1]`，最后截 b 点单独支付；没有把截断点误作等间距节点。

## SP6 全 j/M 来源价：显式 2/3 次幂

对同一原 V，a,q,β,ν 在 j 之间共同。令

\[
 L_U(\rho)=1+\log_+\left(
       \frac{\sqrt\ell\sqrt\rho}{4C_0}e^{-3U/2}\right).
\]

ρ=0 时全部来源交通为零，下式定义为零。ρ>0 时

\[
 \frac{b_j}{a_j}
 =\frac{\sqrt\ell\sqrt\rho}{4C_0}c_j^{5n/4}e^{-3U/2},\quad
 a_j^{2/3}b_j^{1/3}
 =\left(\frac{C_0^2}{4\ell}\right)^{1/3}\rho^{2/3}c_j^{7n/6}.
\]

使用 SP8、`Σ_jc_j^{7n/6}≤2` 及 `Σ_jc_j^{2n}≤4/3`，得到

\[
 \boxed{\sum_j\sum_{M\in\mathcal M_j}\mathcal K_{j,M}(y)
 \le\Xi_{\ell,C_0}(\rho,U):=
 \min\left\{\rho e^{-U},\
 18\left(\frac{C_0^2}{4\ell}\right)^{1/3}
        \rho^{2/3}L_U(\rho)^{1/3}\right\}.} \tag{SP9}
\]

两几何级数由 `γ^n≥2` 保证；特别 `γ^{-7n/6}<1/2`。有限物理节点、空带与有限 j 只使左侧更小。如果 a,q 或来源依 j 改变，则不得提出这些量，必须保 SP7–8 的逐 j 价格。

第一项恰是全 j 后的 R230 备选线性来源价。第二项是新的亚线性价，来自同一个 actual-column 的真实局部 cap、growing heavy floor 和物理 QG 衰减的联合，而不是给 ν 添加全局密度帽。U 在混合主幂次中抵消，但保留于 `L_U` 与原指数备选；不声称一般 far 衰减被免费增强。`U≥nlog(b/a)` 时原所有节点空，交通直接为零。

## SP7 原三腿完整 prefactor 与仍需支付的来源矩

原 receiver-first 节点覆盖为三腿×两朝向×`4e^4N_n`，`N_n≤8+4√n log(n-1)`。SP2 已含 hard 来源 ν(z) 与共同 q 的归一价；两份 ν(v/u) 保在实际 Π 后由 clock 界处理。因而

\[
 \boxed{\mathcal P_{far}(U)\le
 2\Lambda\sqrt{K/3}\,(24e^4N_n)\,
 \mathbb E\sum_V\|\beta_V\|
        \Xi_{\ell,C_0}(\rho_V,U),\qquad
 \rho_V=\frac{\|\nu_V\|}{q_Va_V^n}.} \tag{SP10}
\]

所有实际 L/R/s、high、terminal good/bad、capture、suffix、RN history 和已付支的正补集仍属于原母量；上界只按允许方向放松它们。没有重新计算节点 FIRST 或 capture，没有把 β 当 Π，没有再领取 hard cap、负项、删除或已付浮动带费用。时间空行与零来源都直接取零。

新结论量化减少的是实际来源拥挤价格，不是一般 `W_β` 结算。SP10 仍有 `√K`，并要求支付实际来源矩
`EΣ_V||β_V||ρ_V^{2/3}L_U(ρ_V)^{1/3}`；仅 `Σ||β_V||≤W_β` 不提供此矩的统一帽。源 cut、rank、low-N 的旧条件不在本稿被升级为这种帽。因此不宣布 `εX+C√n polylog(n)W_β`、near 支或整个弱型目标已闭合。

## SP8 本机有限验证

实际运行已有 mpmath 60位：对 `h=log2,0.8,1`，三种正规偏移，七种 `b/a` 比率（`10^{-6}` 至 `10^{30}`），各400个正规节点及五种额外截点，核对 SP8 两个上界；另核层尾积分4与 n=2,16,512,10^6 的 j 级数。共635项断言全部 PASS，最大 `实际混合和/(9K)` 约0.4492643830。这只是有限高精度诊断，不是向外舍入证书、FULL 输入或一般节点证明；SP8–10 的一般结论由上文证明与本轮 clock 接口承担，后者须按 SP4 同步独审状态。

复现脚本（需现有 mpmath；本机使用已有 vendor `PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor`）：

```python
import mpmath as mp
mp.mp.dps=60
checks=0; largest=mp.mpf(0)
for h in (mp.log(2),mp.mpf('0.8'),mp.mpf(1)):
  for f in (mp.mpf(0),mp.mpf('0.2'),mp.mpf('0.9')):
    s0=f*h
    for ratio in (mp.mpf('0.000001'),mp.mpf('0.1'),mp.mpf(1),
                  mp.mpf(2),mp.mpf(100),mp.mpf('1e12'),mp.mpf('1e30')):
      a=mp.mpf(1); b=ratio
      regular=sum(min(a*mp.exp((s0+k*h)/2),
                      b*(s0+k*h)*mp.exp(-(s0+k*h))) for k in range(400))
      for cap in (mp.mpf(0),mp.mpf('0.01'),mp.mpf(1),mp.mpf(10),mp.mpf(100)):
        actual=regular+min(a*mp.exp(cap/2),b*cap*mp.exp(-cap))
        L=1+max(mp.mpf(0),mp.log(b/a))
        mixed=9*a**(mp.mpf(2)/3)*b**(mp.mpf(1)/3)*L**(mp.mpf(1)/3)
        assert actual<=3*b+mp.mpf('1e-50'); checks+=1
        assert actual<=mixed+mp.mpf('1e-50'); checks+=1
        largest=max(largest,actual/mixed)
val=mp.quad(lambda t:1-2*mp.log(t),[0,1])+mp.quad(lambda t:1/t**2,[1,mp.inf])
assert abs(val-4)<mp.mpf('1e-50'); checks+=1
for n in (2,16,512,1000000):
  gam=1+mp.mpf(1)/n
  assert 1/(1-gam**(-mp.mpf(7)*n/6))<2; checks+=1
print({'mpmath_dps':mp.mp.dps,'assertions':checks,
       'max_mixed_bound_ratio':mp.nstr(largest,16),
       'tail_integral':mp.nstr(val,20),'result':'PASS',
       'scope':'finite high-precision diagnostics, not interval proof'})
```

实际返回 `assertions=635,result=PASS,tail_integral=4.0`。数值作者另负责真实物理节点的完整三阶段检查，本稿不预报其结果。有限任务到此停止。
