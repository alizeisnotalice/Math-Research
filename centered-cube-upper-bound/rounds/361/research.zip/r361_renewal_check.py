from fractions import Fraction as F
import json
from pathlib import Path
checks=0
rows=[]
def ck(v):
 global checks
 checks+=1
 assert v
for stage,ns in [('initial',[3,4]),('saturated_columns',[8,12]),('expanded',[24,40])]:
 for n in ns:
  for c in [F(0),F(1,8),F(3,8)]:
   A=[[F(0)]*n for _ in range(n)];D=[[F(0)]*n for _ in range(n)]
   for u in range(n):
    if u+1<n:A[u][u+1]=c
    if u+2<n:D[u][u+2]=1-c
   R=[[F(int(u==v)) for v in range(n)] for u in range(n)]
   for u in reversed(range(n)):
    for v in range(u+1,n):R[u][v]=sum(A[u][j]*R[j][v] for j in range(u+1,v+1))
   H=[[sum(R[u][j]*D[j][v] for j in range(n)) for v in range(n)] for u in range(n)]
   beta=[1-sum(A[u])-sum(D[u]) for u in range(n)]
   h=[sum(R[u][v]*beta[v] for v in range(n)) for u in range(n)]
   eta=[1-sum(A[u][v] for u in range(n)) for v in range(n)]
   ck(all(1-c<=x<=1 for x in eta))
   ck(all(sum(H[u])+h[u]<=1 for u in range(n)))
   ck(all(sum(eta[u]*H[u][v] for u in range(n))<=eta[v] for v in range(n)))
   ck(sum(eta[u]*h[u] for u in range(n))==sum(beta))
   i=[F(u+1,n) for u in range(n)]
   j=i[:];term=[]
   for k in range(n):
    term.append(sum(j[u]*h[u] for u in range(n)))
    ck(term[-1]<=sum(beta)/(1-c))
    j=[sum(j[u]*H[u][v] for u in range(n)) for v in range(n)]
   ck(not any(j))
   val=[F(0)]*n
   for u in reversed(range(n)):val[u]=beta[u]+sum((A[u][v]+D[u][v])*val[v] for v in range(u+1,n))
   ck(sum(term)==sum(i[u]*val[u] for u in range(n)))
   rows.append(dict(stage=stage,n=n,c=str(c),total=str(sum(term)),native_terminal_capacity=str(sum(beta)),per_D_count_bound=str(sum(beta)/(1-c))))
print(json.dumps(dict(status='PASS',checks=checks,scope='Exact finite triangular kernel algebra, not actual centered-cube realizations.',rows=rows),ensure_ascii=False))
