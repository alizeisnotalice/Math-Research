# R361 — One source-rank terminal price per disjoint-jump count

## 1. New paid portion and scope

Work with the unchanged actual R360 history process, before its terminal direction-source deletion. Use the canonical source-labelled receiver kernels from r360_terminal.md, and write A=C0+B0 and D for the nonempty, disjoint low-face-coordinate event (D is not the numerical rank-window constant). On the actual receiver reference sigma=q du they obey

    A+D<=Pbar,  sigma(A+D)<=sigma,
    sigma A<=c sigma,  c=theta+r_p<1.                        (1)

The first two inequalities are JOINT inequalities: A and D partition parts of the SAME actual common-source envelope. For the explicit established range n>=2^32, c<=3/8. All kernels retain the true rank window and strict factor-K mass growth. Let bbar_z(u)=1-Qbar_z(u,E) be the native missing-rank probability after a genuine source draw. Its actual source capacity is

    tau(z)=integral xi_z(du)bbar_z(u)=E_h min(D_cap(z),h),
    D_cap(z)=xi_z(E),
    integral f(z)tau(z)dz<=b_*W,
    b_*=(D0+Delta)/2.                                      (2)

The OLD result pays normal terminals with no D continuation at C_noD W, where C_noD=b_*/(1-c). The NEW result is: for every integer k>=0, the actual normal-terminal source measure of paths having EXACTLY k D continuations satisfies

    T_k(dz)<=[1/(1-c)] f(z)tau(z)dz.                        (3)

Thus the SAME price works for each k; it does not grow as (1-c)^(-k). In particular choose explicitly

    L=ceil(log(n+2)).                                      (4)

The whole actual normal-terminal branch with 1<=number of D<=L is paid by

    F_(1:L)<= L C_noD W.                                  (5)

Only k=1,...,L is a new charge. The k=0 fee was already available and is used once. The remaining normal paths have at least L+1 genuine D continuations. This is an unconditional branch receipt under the already proved canonical geometry (1), not an estimate for all those remaining paths.

No source posterior is renormalized, no old qualification is restarted after D, and no bound on a renewal operator's row probability is asserted. The key new comparison is a joint COLUMN telescoping identity proved next.

## 2. Joint column telescoping through an entire A excursion

Let N be the actual finite strict-mass horizon from R360. Both A and A+D have no surviving N-edge path. Define the positive finite resolvent

    R_A=Id+A+...+A^(N-1).

Products act forward on receiver measures, from left to right. From (1),

    sigma A^j<=c^j sigma,
    sigma R_A<=[sum_(j<N)c^j]sigma<=sigma/(1-c).             (6)

More importantly, the JOINT capacity implies

    sigma D<=sigma-sigma A.

Multiply this positive-measure inequality by R_A. Since A^N=0, it gives the exact telescoping comparison

    sigma D R_A<=(sigma-sigma A)R_A=sigma.                   (7)

Thus D followed by all possible A-excursion VISITS preserves a reference COLUMN cap. D R_A is an occupation operator, not generally a substochastic transition: R_A counts several visits on an excursion. It is neither renormalized nor inserted into the actual path process.

For the actual injection I<=sigma define the canonical reference measures

    V_k=I R_A (D R_A)^k,  k>=0.

Equations (6)-(7) imply, without an exponential-in-k factor,

    V_k<=sigma/(1-c).                                      (8)

Every term in this finite positive expansion has the word order

    A^(j_0) D A^(j_1) D ... D A^(j_k), j_i>=0.

Such a word has exactly k D edges. Impossible lengths vanish by the same strict native mass horizon. Using only separate bounds sigma A<=c sigma and sigma D<=sigma would lose (7) and introduce the unnecessary factor (1-c)^(-k); that is not the argument here.

## 3. Dominate the ACTUAL marked arrivals, without replacing the process

The original injection I is the actual nonrich crossing entrance, with its old source, old u,v, original time, full J/eta/Omega, initial core and initial witness-crossing marks. Later arrivals retain every actual source/rank/history mark. At each current history, the next A or D continuation is a positive restriction of the corresponding canonical SOURCE-LABELLED kernel. This follows from the original full-f draw and the actual rich/inner/current-high/ancestor/rank/target-high order. No future terminal event is conditioned upon.

Let G_k be the sum of actual alive nonrich arrivals over all generations whose past contains exactly k D continuations. A rigorous positive expansion by continuation words, keeping histories and then projecting the current receiver, gives

    G_k<=I R_A(D R_A)^k=V_k.                               (9)

One can equivalently prove (9) inductively: the arrivals after any fixed number of consecutive A continuations are dominated by multiplication by A at each step; sum this finite excursion, then pass through the next actual D continuation and repeat. History-dependent acceptance only deletes mass from the corresponding word. No Markov assumption about the projected actual history process is needed. Counting each word by its actual number of D edges prevents double counting; each arrival has a unique such number.

At an actual normal termination, the source is drawn from the original pi_u(dz)=f(z)c_u(z)dz/m_u before all current tests. The normal event is a positive restriction of native missing-rank loss. Therefore its source measure, restricted to count k, is bounded by

    T_k(dz)<=integral G_k(du)pi_u(dz)bbar_z(u).

Apply (8)-(9) and the EXACT identity sigma(du)pi_u(dz)=f(z)dz xi_z(du):

    T_k(dz)<= [f(z)/(1-c)]dz integral xi_z(du)bbar_z(u)
             =[f(z)tau(z)/(1-c)]dz.

This proves the sourcewise bound (3), and hence (5). The same-source missing-rank capacity is paid once for each selected D count, rather than once for each physical generation. Several A visits at many different generations are already included in (7); their source traffic has not been declared disjoint.

This bound concerns genuinely NORMAL terminals. Previously paid rich, inner, high-face and ancestor stops are not relabelled as native missing-rank loss. Strict mass growth means only k<=N-1 can occur, so counts beyond that range automatically vanish even if L in (4) is larger.

## 4. Correct terminal ordering and the resulting original-B_H slot

Let F_norm be all actual normal terminals of the unchanged R360 process, before terminal direction selection. There is an exact positive partition

    F_norm=F_0+F_(1:L)+F_(>L,raw),                          (10)

with F_0<=C_noD W and the new bound (5). Do NOT first take the old R360 F_D direction selection and then inherit its source ratios after removing counts 1,...,L. The required order is (10), followed by a freshly defined direction-source selection on F_(>L,raw).

In detail, let f(z)L_>(z)dz be its terminal-source marginal and f(z)L_(>,i)(z)dz its i-th face-event marginal, using its ACTUAL terminal source z. These are recomputed from the restricted marked terminal law. At each generation that law is still a positive restriction of f(z)c_u(z)q_u dzdu/m_u. The old actual-center one-face envelope therefore still gives

    L_(>,i)(z)<=N B_1(alpha),
    B_1(alpha)=(1-alpha)+[n(1-alpha)+alpha]log(b/a).

With L_n=log(n+2), delete the entire source set

    S_>={z:L_>(z)>0, max_i L_(>,i)(z)>=L_>(z)/L_n}.

Its whole terminal traffic costs at most C_dir W, where C_dir=N B_1(alpha)L_n. Let the new remaining mass be F_(>L,disp). Then

    F_norm<=F_(>L,disp)+[(L+1)C_noD+C_dir]W.                 (11)

Every remaining path has at least L+1 actual D continuations; every terminal tuple still has a nonempty low face count; its positive remaining terminal-source columns satisfy strict direction ratio <1/L_n. This ratio is a new terminal-source property, not a condition on the first-D source or on all earlier path states. All whole-path sparse-face/shell/freshness conditions from R360 and all initial crossing/time/history marks remain.

Combining (11) with the original R360 pre-terminal positive decomposition gives, for n>=2^32,

    B_H<=F_(>L,disp)
       +[(13/3)epsilon+gamma_eff+beta+alpha_rec+c_eff]X_q
       +[C_epsilon,n+8s+C_path,n+C_dir+(L+1)C_noD]W
       +(D_top,n+C_hit,n+s)W_ex.                            (12)

Here C_path,n=2N C_m; all other constants are precisely the already certified R360 ones. Relative to its subsequent noD-payment ledger, the additional source fee is ONLY L C_noD W. Direction selection is reconstructed and charged once. No old noD fee, first-D flux fee, or per-generation native terminal fee is repeated.

Using c<=3/8 gives

    L C_noD<= (8/5)ceil(log(n+2)) b_*=O(sqrt(n)log(n+2)).     (13)

The exact coefficient is retained in (12). For 1<=n<2^32 the earlier bounded-dimensional whole-terminal bound from r360_terminal.md remains available; this note does not assert c<1 there without its separate check. On an empty original branch all these terminal flows vanish.

Entrance factor two and exterior Lambda=128/119 multiply the new fee, giving the extra 2Lambda L C_noD W. There is NO new X_q fee. All original two-source entrance, general-soft/scale/threshold complements, original chronological time atoms and outer integration/limiting obligations remain. The rank/source accounting does not spend original B_H negative-square credit again.

## 5. What is and is not solved

The receipt (5) is an actual new portion with at least one D continuation. It uses the canonical geometry already proved for A together with the JOINT source-matched column capacity and missing-rank source formula; it does not assume that D itself has a small norm or that paths renew independently after D. The sourcewise estimate (3) is stronger than just a total-mass estimate for that paid portion.

No fixed covered fraction is claimed for every input. Paths with at least L+1 D jumps remain unpriced. Paying every possible D count by the same argument would again produce N C_noD W, generally of linear dimensional order. Source resets on different paths may still reuse the same source. The new continuation target is now a true multiple-D path condition, not a renamed arbitrary terminal residue. No general root bound for all of B_H or the global weak-type target is proved.

## 6. Actual exact checks

The embedded Fraction checks verify the new JOINT column telescoping, the correct operator order D R_A, word-count occupation bounds, per-count terminal source bounds and the new finite-count receipt. They include history-dependent edge and terminal acceptance, rather than replacing it by a Markov process. They are finite operator/source-label diagnostics, not realizations of the original centered-cube or hard high-past contract. The analytic geometric inputs are (1)-(2).

~~~python
from fractions import Fraction as F
from itertools import product
counts={'joint_column':0,'history_words':0,'source_terminal':0,'count_bill':0}
def ck(ok,key):
    assert ok
    counts[key]+=1
def vm(v,M):
    return [sum((v[u]*M[u][w] for u in range(len(v))),F(0)) for w in range(len(v))]
def mm(M,T):
    return [vm(row,T) for row in M]
def eye(n):return [[F(u==v) for v in range(n)] for u in range(n)]
def add(M,T):return [[a+b for a,b in zip(r,s)] for r,s in zip(M,T)]
def check_case(sig,A,D,c):
    n=len(sig);K=add(A,D)
    ck(all(x<=1 for x in map(sum,K)),'joint_column')
    ck(all(v<=c*s for v,s in zip(vm(sig,A),sig)),'joint_column')
    ck(all(v<=s for v,s in zip(vm(sig,K),sig)),'joint_column')
    RA=eye(n);power=eye(n)
    for j in range(1,n):power=mm(power,A);RA=add(RA,power)
    ck(all(v==0 for row in mm(power,A) for v in row),'joint_column')
    defect=[s-v for s,v in zip(sig,vm(sig,A))]
    ck(vm(defect,RA)==sig,'joint_column')
    block=mm(D,RA)
    ck(all(v<=s for v,s in zip(vm(sig,block),sig)),'joint_column')
    injection=[sig[u]*F(u+1,n+1) for u in range(n)]
    refs=[];ref=vm(injection,RA)
    for k in range(n):
        refs.append(ref)
        ck(all(v<=s/(1-c) for v,s in zip(ref,sig)),'joint_column')
        ref=vm(ref,block)
    native=[(1-sum(K[u]))/F(1+u%3) for u in range(n)]
    post=[]
    for u in range(n):
        weights=[F(1+z+(u%2)) for z in range(3)];total=sum(weights)
        post.append([a/total for a in weights])
    caps=[sum((sig[u]*native[u]*post[u][z] for u in range(n)),F(0)) for z in range(3)]
    visits=[[F(0)]*n for k in range(n)]
    terminal=[[F(0)]*3 for k in range(n)]
    other=[F(0)]
    def walk(u,amount,k,origin,word):
        visits[k][u]+=amount
        normal=F(0)
        for z in range(3):
            accept=F(1+(origin+u+k+z+word%3)%4,4)
            val=amount*native[u]*post[u][z]*accept
            terminal[k][z]+=val;normal+=val
        outbound=F(0)
        for v in range(u+1,n):
            for isD,M in [(0,A),(1,D)]:
                if not M[u][v]:continue
                accept=F(1,2) if (word+origin+u+isD)%3==0 else F(1)
                val=amount*M[u][v]*accept;outbound+=val
                walk(v,val,k+isD,origin,2*word+1+isD)
        remainder=amount-normal-outbound
        ck(remainder>=0,'history_words');other[0]+=remainder
    for origin,v in enumerate(injection):walk(origin,v,0,origin,0)
    ck(sum(map(sum,terminal))+other[0]==sum(injection),'history_words')
    for k in range(n):
        ck(all(v<=r for v,r in zip(visits[k],refs[k])),'history_words')
        for z in range(3):
            ck(terminal[k][z]<=caps[z]/(1-c),'source_terminal')
    for L in [1,2,3,n+1]:
        paid=sum((sum(terminal[k]) for k in range(1,min(L,n-1)+1)),F(0))
        ck(paid<=L*sum(caps)/(1-c),'count_bill')
        low=sum(terminal[0])+paid
        rest=sum((sum(terminal[k]) for k in range(L+1,n)),F(0))
        ck(low+rest==sum(map(sum,terminal)),'count_bill')
    return block
# Interface pressure: D R_A is an occupation operator, not a probability kernel.
A=[[F(0)]*3 for _ in range(3)];D=[[F(0)]*3 for _ in range(3)]
A[1][2]=F(1);D[0][1]=F(1)
block=check_case([F(1),F(1),F(4)],A,D,F(1,4))
ck(sum(block[0])==2,'joint_column')
# Jointly saturated and unsaturated nonuniform-capacity DAGs.
for n,c,scale in product([2,4,6,8,10],[F(1,8),F(1,4),F(3,8)],[F(0),F(1,2),F(1)]):
    sig=[F(2*n-u,n+1) for u in range(n)]
    A=[[F(0)]*n for _ in range(n)];D=[[F(0)]*n for _ in range(n)]
    for u in range(n):
        if u+1<n:A[u][u+1]=c*sig[u+1]/sig[u]
        if u+2<n:D[u][u+2]=(1-c)*scale*sig[u+2]/sig[u]
    check_case(sig,A,D,c)
print('PASS exact count-terminal checks',counts,'total',sum(counts.values()))
~~~


## Actual local verification

The embedded Python `Fraction` script was executed locally without alteration. It returned:

~~~text
PASS exact count-terminal checks {'joint_column': 550, 'history_words': 4060, 'source_terminal': 819, 'count_bill': 368} total 5797
~~~

These are exact finite operator/source-label interface checks, including history-dependent acceptance and conservation. They do not assert that the finite fixtures realize the original cube geometry or high-past entrance. The continuum result is established by the proof above. Only this owned report was written; the source script is embedded for independent reproduction.
