# R361 — Mass-gap path compression and a weighted history-pair comparison

**Outcome.** No new payment for the high-D-count terminal remainder is proved here. The single-path Bessel estimate below is a standard consequence of the already established strict mass gap, recorded as an auxiliary tool. A second positive estimate compares a genuinely averaged, mass-weighted history-pair measure to the original receiver product measure. It can be applied to an original capture-square integrand when the receiver layer is the same. Its mass weights cannot currently be removed in the terminal application. Neither result spends the old negative-square credit again.

Read: r360_geometry.md, r360_terminal.md, r360_remainder.md, and the definitions of the original square in r355_astra.md. No other file is modified.

## 1. Exact single-path statements

Put K=exp(sqrt(n)), rho=K^(-1/2). On a real surviving path let U_j be its visited receiver and m_j its full-f cube mass. Every continuation, including C and B, has m_{j+1}>K m_j. One may instead select successive D-targets: the same inequality between successive selected masses holds, while all intermediate actual history restrictions remain in force.

In L2(f(z)dz), set

    psi_j(z)=1_{Q_{U_j}}(z)/sqrt(m_j).

Then ||psi_j||=1 and, for i<j,

    0<=<psi_i,psi_j>
       =f(Q_{U_i} intersection Q_{U_j})/sqrt(m_i m_j)
       <=sqrt(m_i/m_j)<rho^(j-i).                       (1)

Consequently the finite Gram operator has norm at most

    B_rho=(1+rho)/(1-rho),

by the absolute row-sum bound. Equivalently, for every h in L2(f),

    sum_j m_j |pi_{U_j}(h)|^2 <= B_rho integral f |h|^2. (2)

For arbitrary coefficient vectors on an earlier block i<=a and a later block j>=a+r, r>=1, the cross-Gram norm is at most

    rho^r/(1-rho^2).                                    (3)

Indeed its entries are bounded by rho^r rho^(a-i)rho^(j-a-r); this rank-one positive envelope has the asserted norm. Thus a large separation in D count supplies exponential suppression of *same-history normalized common-source correlations*. This does not use a cap on f, face-volume estimates, independence, or a changed receiver measure.

Equations (1)–(3) are auxiliary consequences of mass growth, not new D geometry or a new source payment. They hold before using the disjoint-coordinate property.

## 2. An actual averaged history-pair domination

This statement retains the original history process rather than postulating independent receivers. Work at a fixed receiver layer E with

    mu(du)=du/m_u,  sigma(du)=q_u du,  q_u<=lambda.

Assume the already available actual generation marginals G_i<=sigma and a horizon of at most N visits. The canonical receiver continuation kernel satisfies, for every current receiver and every history,

    P(u,dv)
      <= (1/w) R_v^(-n) dv integral pi_u(dz)1_{Q_v}(z)
      <= (lambda/w) mu(dv).                             (4)

Actual acceptance only restricts this kernel. For any d>=1, its actual alive d-step conditional endpoint measure, given the history at i, obeys the same envelope (4): integrate the last-step envelope against a substochastic conditional distribution of all preceding states and marks. No Markov assumption on the projected receiver sequence is necessary.

Let M_{i,j}(du,dv) be the actual receiver-pair marginal of histories alive at visit j, retaining U_i=u and U_j=v. The preceding argument proves

    M_{i,j}(du,dv) <= (lambda/w) G_i(du) mu(dv),  i<j.   (5)

The actual support also obeys m_v>K^(j-i)m_u. Define the positive weighted pair measure

    Pi_r(du,dv)
      =sum_{0<=i<j<N, j-i>=r}
           M_{i,j}(du,dv)/sqrt(m_u m_v),  r>=1.

Combining the support with (5), and using G_i/m_u<=q_u mu<=lambda mu, gives

    Pi_r <= [N lambda^2/w] [rho^r/(1-rho)] mu tensor mu. (6)

This bound is for real receiver measure and all original histories. Any further positive restriction — e.g. both visits lying on a selected normal-terminal path, or at least r D edges between them — inherits (6), because r D edges imply j-i>=r. It is not necessary to erase their source or rank marks to define the restricted pair measure; only the positive envelope in (4) forgets them for the estimate.

The factor N/w is bounded by 3 under N<=3sqrt(n) and w=1+sqrt(n)-log(4/3)>sqrt(n). Thus the comparison coefficient in (6) is at most

    3 lambda^2 rho^r/(1-rho).                            (7)

This is a useful comparison without a remaining path-length factor. It controls a *mass-weighted pair observable*, not terminal mass.

## 3. Exact interface to the original capture square

At a fixed original physical time t, write its unchanged capture-square integrand as

    Gamma_t(u,v)
      =integral f(z)sqrt(a_t(z))1_{Q_u}(z)1_{Q_v}(z)dz,
    P(t)=integral Gamma_t(u,v)^2 mu(du)mu(dv).

If the receivers in (6) lie in that same original E_t, with the same m and mu, positivity gives the rigorous comparison

    integral Gamma_t(u,v)^2 Pi_r(du,dv)
      <= [N lambda^2/w] [rho^r/(1-rho)] P(t).            (8)

The same implication applies to any explicitly retained common-source positive mask by using its actual nonnegative integrand bounded by Gamma_t^2. It does not authorize replacing the original square by a mask with a different source law. If the history layer is not the same E_t, (8) requires a separately proved layer embedding; no such embedding is inferred here.

Equation (8) is a real history-to-original-receiver comparison, rather than the unproved assertion that the single-path Bessel bound survives arbitrary cross-history aggregation. It may serve as a sublemma in a fresh proof starting from the unspent original square. The old proof has already used its negative credit, so (8) cannot be added as a second deduction in the current ledger.

## 4. What remains missing for the actual high-D terminal fee

The native terminal integrand is linear in

    1_{Q_u}(z)/m_u times the actual missing-rank probability,

averaged over all preterminal histories. It contains no second earlier receiver and no factor Gamma_t(u,v)^2/sqrt(m_u m_v). Neither (2) nor (8) supplies that extra capture.

In particular, after integrating (2) against the measure of initial paths, the direct right side is

    B_rho I(E) integral f|h|^2.

The total initial mass I(E) remains. This is the precise aggregation loss in the naive Bessel argument; setting it to 1 would silently normalize the real entrance and then fail to restore its mass. Terminal source columns also combine different histories, whereas (1) only controls two receivers on one ordered history.

The new weighted pair comparison (8) avoids that particular loss, but still requires a substantive bridge from the high-D normal-terminal linear functional to its weighted two-receiver capture observable. Removing 1/sqrt(m_u m_v) using only the one-octave radius range can cost powers up to 2^n in the mass scale; strict forward growth does not provide a uniform removal. Moreover the true path permits a terminal source outside every ancestor cube, so terminal survival itself supplies no earlier-source capture lower bound. One must retain some other original source/clock capture in such a bridge and prove that it is present with adequate averaged weight.

Accordingly this note supplies the proved tools (2), (6), and the precisely qualified interface (8), but no assertion bounding F_D, no new W fee, and no new X_q absorption. The separately proved low-D-count terminal head payment remains independent. Work stops at this explicit missing terminal-to-capture bridge.

## 5. Local mathematical computation actually run

Standard-library Python Fraction arithmetic checked 8,000 finite geometric-Gram row and cross-block inequalities with rho in {1/2,1/3,1/4,1/8,1/16} and path lengths 1 through 40. A separate exact finite-DAG calculation checked 3,276 weighted pair-domination entries, using masses 4^j, receiver weights mu_j=1/m_j, sigma_j=1, and transitions P(u,v)=mu_v/(2w) for v>u, with w in {1,2,4}. It directly formed generation marginals, all matrix powers, and the weighted pair sum in (6). All checks passed.

These computations check algebra only; the analytic proofs above establish the actual-process statements. The finite DAG is not claimed to realize the cube, hard-past, or original-square qualifications. Floating illustrations at n=16,64,256,1024 gave B_rho approximately 1.3130353, 1.0373147, 1.0006712, 1.000000225; an underflow at n=2^32 was ignored rather than interpreted as rho=0.
