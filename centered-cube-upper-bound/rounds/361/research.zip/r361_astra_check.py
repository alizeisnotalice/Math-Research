#!/usr/bin/env python3
"""R361 exact arithmetic checks.

The initial checks were executed as inline Python, not saved as a script.
This file reconstructs those two Fraction checking blocks from the actual
recorded tool-call source. Its execution is a NEW reproducibility run.
No cube realization or terminal payment is certified by these finite checks.
"""
from fractions import Fraction as F

# Block 1: the exact Fraction block from the original inline Gram check.
checks = 0
for den in [2, 3, 4, 8, 16]:
    r = F(1, den)
    B = (1 + r) / (1 - r)
    for L in range(1, 41):
        for i in range(L):
            rowsum = sum(r ** abs(i - j) for j in range(L))
            assert rowsum <= B
            checks += 1
        for cut in range(1, L):
            # Squared HS envelope across an ordered cut; the envelope
            # matrix is rank one, so this is also its squared operator norm.
            hs = sum(
                r ** (2 * (j - i))
                for i in range(cut)
                for j in range(cut, L)
            )
            assert hs <= (r / (1 - r * r)) ** 2
            checks += 1
assert checks == 8000
print('PASS', checks, 'exact path-Gram envelope checks')

# Block 2: the exact Fraction operations from the original inline DAG check.
# Only formatting and descriptive variable naming outside the arithmetic
# have been adjusted. The checked formulas and parameter ranges are unchanged.
count = 0
for L in range(2, 9):
    m = [F(4) ** j for j in range(L)]
    root = [F(2) ** j for j in range(L)]
    mu = [1 / x for x in m]
    for w in [F(1), F(2), F(4)]:
        P = [
            [mu[v] / (2 * w) if v > u else F(0) for v in range(L)]
            for u in range(L)
        ]
        assert all(sum(row) <= 1 for row in P)
        assert all(sum(P[u][v] for u in range(L)) <= 1 for v in range(L))
        power = [[[F(u == v) for v in range(L)] for u in range(L)]]
        for d in range(1, L):
            power.append([
                [sum(power[-1][u][k] * P[k][v] for k in range(L))
                 for v in range(L)]
                for u in range(L)
            ])
        G = [[F(u + 1, L + 1) for u in range(L)]]
        for i in range(1, L):
            G.append([
                sum(G[-1][u] * P[u][v] for u in range(L))
                for v in range(L)
            ])
        for r in range(1, L):
            cap = F(L, w) * F(1, 2) ** r / (1 - F(1, 2))
            for u in range(L):
                for v in range(L):
                    actual = sum(
                        G[i][u] * power[d][u][v] / (root[u] * root[v])
                        for i in range(L)
                        for d in range(r, L - i)
                    )
                    assert actual <= cap * mu[u] * mu[v]
                    count += 1
assert count == 3276
print('PASS', count, 'exact weighted real-history pair-domination algebra checks (finite DAG diagnostics only)')
print('NEW REPRODUCIBILITY RUN TOTAL:', checks + count)
