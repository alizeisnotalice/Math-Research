# R629 独立终审（一页范围）

2026-10-28。已读`/tmp/ccu_r629_outer.md`与`/tmp/ccu_r629_joint.md`；无新计算、扫描或Agent，只核公式、量词及未付位置。

**总体：关键恒等式及方向通过；没有新的全局估计或根阶改善。** 唯一需明写的条件：joint(1)的collar高度h_i≥0，且“disjoint seeds”指outer cubes A_i本身不交；否则fresh差量或Σμ(A_i)=μ(∪A_i)不能直接使用。

1. **列截断。** compact F⊂E1使outer R有统一正下界，故S_F有限可测。准确有∫S_Fdμ=τ|F|、∫_F C_L=[τ|F|−T_L(F)]/L≤M。若T_L≤θτ|F|+A_nM，则

   τ(1−θ)|F|≤(L+A_n)M。

   系数正确；必须1−θ统一正、L+A_n为目标量级，且估计对全部compact F统一。每个F可重新冻结其共同核，取内正则sup合法，不能把各F/各层的source预算相加。平凡θ=1无吸收。

2. **全部future。** s>R−d保证s+d>R，outer upper及包含关系确给(7)。σ>τ、ησ=(σ/τ)^(1/n)−1时，ρσ(y)≤max{R−d,d/ησ}，继而R≥η_nρ1(y)≥log(4/3)ρ1(y)/n；方向正确。它只是receiver半径相对来源自身尺度的下界，没有共同上界、重列尾费或fresh质量的不交分配。

3. **cluster及重叠列。** h_i≥0下，整个cluster union包含于扩大seed cube，减去seed的准确μ质量得到fresh费。η=1/(8n)的系数<e^(1/8)−1<1/7。加权重叠seeds只能得Bη∫c dμ；w_i=v_i/d_i时仅等于BητV。将其换成BηM须另证共同column容量；若称原packing还需Lebesgue-a.e.负载可行。缩权后的receiver信用也必须实付，source容量与receiver cover不能交换。

4. **core及诊断。** D≤(1−τ^(1/n))R_i时，每个strict 1-bad半径确小于R_i−D，故其cube在A_i内；这只给O(R_i/n)局部core，不保持截源后的Bτ。固定δ=1/8周期模型每胞weakratio≤8；n32/128/512的经验outer-logvolume宽度既不检验普适根阶，也不证明S_F重列尾。

**最终未付：** outer稿(5)的同源全receiver重列尾严格吸收，或与之等价强度的共同几何预算；joint的thin-cluster条件尚未覆盖全部receiver，近尺度重叠列也未支付。两稿已如实保留这些缺口。既有恢复接口、局部工具和有限容易诊断不列为本轮维数成果；R559母账仍开放。审查完成，停止。

**有界续审与最终整合（2026-10-28）。** 已独立核`outer_followup.md`，并仅对`/tmp/ccu_r629_bundle/REPORT.tex`第1–3节作整合核验。固定R后T_F是线性算子，其adjoint为T_F* h(y)=∫_F h(x)1_Q(y)/V(R(x))dx，故S_F=T_F*1_F及||S_F||²₂≤B_{2,n}²|F|正确；不需把R与f独立化。B取固定维数有限范数，不认证维数无关界。

标量式由s²−4L(s−L)=(s−2L)²给出；本机SymPy只核该恒等式。完整尾费为

T_L≤[H B_{2,n}²/(4L)]|F|+∫(f−H)_+(S_F−L)_+。

积分有限性由∫fS_F=τ|F|保证，不要求f∈L²。吸收系数为θ₀=H B_{2,n}²/(4Lτ)，方向正确；H=1时高密度来源支持于E1仅是a.e.微分定理结论，不能控制其重列残余。若先支付receiver {f>1}的体积≤M，剩余F₀须用其自己的S_F₀（原compact F的半径下界仍适用），并保留这笔额外M。

最终报告保留一般H及B_{2,n}依赖，H=1后才写θ₀；要求高密度残余另有θ₁τ|F|+A_nM且θ₀+θ₁<1，未声称已证。即使另有好的B界，也不自动支付该残余。第1–3节与已审稿一致，h_i≥0及outer seeds不交也已明写；无新增数学错误或一般闭合宣称。此次不认证其余历史/数值段，完成停止。
