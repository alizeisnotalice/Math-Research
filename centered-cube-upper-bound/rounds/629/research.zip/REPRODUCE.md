# R629 复现与计算调度

一般根阶上界未闭合；REPORT.tex 明确保留高密度来源的共同重列尾及原始总账。三个 AUTHOR 文件保留独审对应的原稿，AUDIT.md 指明原稿所需补充条件；最终 LaTeX 已纳入这些条件。

使用本机独立环境：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。历史版本、随机种子、参数、执行命令和原文件哈希见 historical_summary.json。无需原来的约4MB全量输出；完整批次可由种子重建。

生产入口默认14进程、每任务4点，先按原block seed生成原样本，再分片。每个进程限制数值库为一个线程。资源字段区别槽位、存活进程和真实CPU；没有采到的active task数填null。默认并发不代表已经测得14核持续忙碌。后续需结合其他运行任务和实际内存调低，禁止多个Agent各开14个进程争用。

```sh
python ccu_r629_numeric.py --phase block --n 7 --cosets 1 --block 0 --samples 16 --workers 1 --chunk-size 16 --output-dir replay_chunk16
python ccu_r629_numeric.py --phase block --n 7 --cosets 1 --block 0 --samples 16 --workers 4 --chunk-size 4 --output-dir replay_chunk4
python highdim_audit.py --stage pilot --workers 1 --output-dir replay_exact
python highdim_audit.py --stage remaining --workers 14 --output-dir replay_exact
```

实际只运行了前两种调度的同一七维分块，以及新版精确入口的一个128维pilot；数学输出一致。verification_receipt.json 内原路径 replay_chunk16/ccu_r629_block.json、replay_chunk4/ccu_r629_block.json 在本包精简为 replay_chunk16.json、replay_chunk4.json。highdim_replay_receipt.json 是128维重放回执。历史12点完整核验的原结果保存在 historical_highdim_result.json，当时使用4进程，不能把它算成新版14进程的实测。

highdim_inputs.json 冻结12个点的完整坐标、binary64格距、计数、原样本编号和哈希。整数事件枚举严格核的是这些二进制有理输入；显示半径、无理格距误差、全部样本及采样误差不在证书范围。生产和核验都保留两余类的两个乘积之和，不擅自作坐标独立化。

不为提高CPU占用重跑已完成任务。历史完整浮点批次平均宿主CPU约61.82%、峰值99.69%；12点精确审计也未满载。新细分调度只经上述小规模一致性验证，不声称已测得全批加速比。未调用MATLAB或Arb，未编译PDF。
