# R629：outer cubes 的全union预算与未闭合的列费

**结论。** 本轮未得到完整receiver的根阶估计或统一收缩。下述union级工具确实利用outer upper，不能冒充新的全局付款；试图允许重叠seeds时，准确的source列费仍未被抵消。没有逐pair累加来源预算。

固定τ=3/4。同一μ=f dx的outer cube `A_i=Q(c_i,R_i)` 满足

`μ(A_i)=τd_i`，`μQ(c_i,s)<=τ(2s)^n`（s>R_i），`d_i=(2R_i)^n`。

## 1. 可用的全cluster工具

若一组实际outer cubes `A_j=Q(c_j,R_j)` 满足`R_j+||c_j−c_i||∞<=R_i+h_i`，则其**整个union**在Q(c_i,R_i+h_i)中，故

`μ((∪_jA_j)\A_i)<=τ[(2(R_i+h_i))^n−(2R_i)^n]`。  (1)

不需μ密度帽。对一套disjoint seeds、`h_i=ηR_i`，令H=∪A_i，则所有对应cluster的共同fresh union满足

`μ(fresh outside H)<=[(1+η)^n−1]μ(H)`。

η=1/(8n)时系数<1/7。它是真实来源小量，但只对已包含在thin collars内的clusters成立；本轮没有将全部receiver归入这些clusters。

还可严格定位局部1-bad菜单：若`D=||x−c_i||∞<=(1−τ^(1/n))R_i`，那么x处的每个strict 1-bad cube都包含于A_i。因为对r≥R_i−D，outer upper给

`μQ(x,r)<=[τ(1+D/r)^n](2r)^n<=(2r)^n`。

其余r<R_i−D的cube在A_i内。于是该core内E1可由μ|A_i局部判断。范围只有O(R_i/n)；不能据此保证root比例receiver覆盖，也不能声称占用核Bτ在截源后不变。

## 2. 重叠seeds时，fresh节省的准确列账

允许任意非负charging权w_i，设`c(y)=Σ_iw_i1_Ai(y)`、`Bη=(1+η)^n−1`。同一outer upper严格给

`Σ_iw_i μ((1+η)A_i\A_i)`
` <=BηΣ_iw_i μ(A_i)=Bη∫c(y)dμ(y)`。               (2)

因此overlap本身不会使右端变成Bη M。需要另证同一套权的source column容量；若要回原packing，更须真实Lebesgue-a.e. load可行。

对有限compact receiver cover取原不交increments I_i⊂B_i、v_i、V=Σv_i。自然选`w_i=v_i/d_i`时，(2)仅成为

`weighted fresh <=Bη τV`。                         (3)

它可作为已有主不等式中的吸收误差，但没有产生`K sqrt(n)M`主项；这些w_i尚不是packing。若先缩权来保证c≤1，则source只付M，然而尚未证明缩后的`Σw_i d_i`仍能保留root比例的真实receiver。这正是本轮未闭合的联合步骤，不是一个已经证明的coverage机制。

把R_i/n直接放到R_i/sqrt(n)会令(1)–(2)出现exp(O(sqrt(n)))，本稿未略去这笔费。对普通maximal-disjoint outer cover，只知的宽包围亦不能换成thin collar；近尺度重叠列费用没有被(1)的fresh节省消掉。

## 3. 停止点

未找到同一个输入依赖family及同一套权，同时达到完整receiver root目标与source列一次付款。没有将上述未证相容性命名为新定理，也未把pairwise质量上界相加当成总M。工具(1)可保留供后续使用；本轮不主张新的全局预算改善。

未运行计算、扫描、agent或修改仓库。完成停止，待安排。
