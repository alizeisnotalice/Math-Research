#!/usr/bin/env python3
"""Independent integer-lattice scans of 12 pre-existing R629 extreme rows."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import sys,json,math,time,hashlib,resource,argparse,concurrent.futures
from fractions import Fraction as F
from pathlib import Path
sys.set_int_max_str_digits(100000)
INPUT=Path(__file__).resolve().with_name('highdim_inputs.json')
OUT=None; MD=None
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def worker(rec):
 start=time.monotonic(); cpu=time.process_time();n=rec['n'];k=rec['cosets'];af=F.from_float(rec['a']);xs=list(map(F.from_float,rec['x']));Q=max([2*af.denominator]+[v.denominator for v in xs]);assert Q&(Q-1)==0
 a=int(af*Q);X=[int(z*Q) for z in xs];delta=F(k)/af**n;v=F(3,4)/delta;assert v>1
 cutoff=n*af/(4*(v-1)/(v+1));cut=math.ceil(cutoff*Q);Qpow=Q**n
 ev=[]
 for group in range(k):
  shift=group*a//2
  for axis,z in enumerate(X):
   q=(z-shift)//a;left=z-(q*a+shift);right=(q+1)*a+shift-z
   while left<=cut:ev.append((left,group,axis));left+=a
   while right<=cut:ev.append((right,group,axis));right+=a
 ev.sort(); counts=[[0]*n for _ in range(k)];zero=[n]*k;products=[1]*k; i=0;best=[(0,1),(0,1)];wins=[None,None];eps=[]; near=[]
 while i<len(ev):
  left=ev[i][0]
  while i<len(ev) and ev[i][0]==left:
   _,g,j=ev[i];old=counts[g][j];counts[g][j]+=1
   if old==0:zero[g]-=1
   else:products[g]=products[g]//old*(old+1)
   i+=1
  right=ev[i][0] if i<len(ev) else cut
  if left>=right:continue
  m=sum(products[g] for g in range(k) if zero[g]==0)
  if m==0:continue
  leftpow=(2*left)**n; norm=m*Qpow;cond1=norm>leftpow;condt=4*norm>3*leftpow
  if condt:
   rightpow=(2*right)**n
   for t,condition,mnum,mden in ((0,cond1,m,1),(1,condt,4*m,3)):
    if not condition:continue
    if mnum*Qpow <= mden*rightpow: num,den=mnum,mden
    else:num,den=rightpow,Qpow
    bn,bd=best[t]
    if num*bd>bn*den:best[t]=(num,den);wins[t]=(left,right,m)
  if i%4096==0 and time.monotonic()-start>300:raise TimeoutError('per-record limit; no proof')
 def display(pair):
  num,den=pair
  return math.exp((math.log(num)-math.log(den))/n)/2 if num else 0.
 info={}
 for i,(tag,key,wkey) in enumerate((('one','r1','witness_1'),('tau','r_tau','witness_tau'))):
  a0,b0,count=wins[i];saved=rec['saved'];actual=display(best[i]); info[tag]={'exact_radius_display':actual,'saved_radius':saved[key],'radius_relative_error':abs(actual/saved[key]-1),'exact_count':str(count),'saved_winner_count':saved[wkey]['count'],'winner_count_match':str(count)==saved[wkey]['count'],'exact_left_binary_rational':str(F(a0,Q)),'exact_right_event_binary_rational':str(F(b0,Q)),'saved_entry':saved[wkey]['left'],'entry_abs_difference':abs(float(F(a0,Q))-saved[wkey]['left']),'volume_numerator':str(best[i][0]),'volume_denominator':str(best[i][1])}
 return {'n':n,'cosets':k,'extreme':rec['extreme'],'block':rec['block'],'row':rec['row'],'seed':rec['seed'],'classification':'E1' if best[0][0]>0 else 'not_E1','strict_all_events_to_safe_cutoff':True,'event_count':len(ev),'safe_cutoff':str(cutoff),'coordinate_denominator':str(Q),'one':info['one'],'tau':info['tau'],'wall_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def main():
 global OUT,MD
 ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['pilot','remaining'],required=True);ap.add_argument('--workers',type=int,default=14);ap.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent);args=ap.parse_args();assert 1<=args.workers<=14
 args.output_dir.mkdir(parents=True,exist_ok=True);OUT=args.output_dir/'highdim_result.json';MD=args.output_dir/'highdim_report.md'
 data=json.loads(INPUT.read_text());tasks=data['tasks'];h=sha(Path(__file__));sourcehash=sha(INPUT)
 if args.stage=='pilot':
  task=next(r for r in tasks if r['n']==128 and r['cosets']==2 and r['extreme']=='min'); results=[worker(task)]
  doc={'input_sha256':sourcehash,'script_sha256':h,'tasks_selected':[{key:r[key] for key in ('n','cosets','extreme','block','row','seed')} for r in tasks],'results':results,'commands':[[sys.executable,*sys.argv]],'stage':'pilot'}
 else:
  doc=json.loads(OUT.read_text());assert doc['input_sha256']==sourcehash and doc['script_sha256']==h
  done={(r['n'],r['cosets'],r['extreme']) for r in doc['results']};remaining=[r for r in tasks if (r['n'],r['cosets'],r['extreme']) not in done]
  t=time.monotonic()
  with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
   for f in concurrent.futures.as_completed([pool.submit(worker,r) for r in remaining]):
    result=f.result();doc['results'].append(result);OUT.write_text(json.dumps(doc,indent=2));print('done',result['n'],result['cosets'],result['extreme'],'cpu',round(result['cpu_seconds'],2),'rssMB',round(result['peak_rss_bytes']/2**20,1),flush=True)
  doc['remaining_wall_seconds']=time.monotonic()-t;doc['workers']=args.workers;doc['commands'].append([sys.executable,*sys.argv]);doc['stage']='complete'
 OUT.write_text(json.dumps(doc,indent=2));
 with MD.open('w') as f:
  f.write('# R629 高维极端样本有理复核\n\n每个维数 n=32,128,512、coset 数 k=1,2 各选已存命中样本 log Vτ 最小与最大，共12点；不产生新数据。保存的 binary64 格距、坐标以二进制公共分母化为整数，逐一枚举排序全部轴入点事件，并以整数幂严格比较每平台的两个阈值，直到有理安全 cutoff。双余类计数为两个轴乘积之和，严格不等号和同半径同时事件精确处理；每个 V 的精确整数分子分母保存在 JSON。相对半径差是仅供显示的浮点对照；不是原无理格距或一般情形的证书。\n\n')
  f.write('| n | cosets | 样本 | block / row | 事件数 | r1 / rτ 相对差 | winner计数吻合 | CPU秒 | RSS MiB |\n|---:|---:|---|---|---:|---|---|---:|---:|\n')
  for r in sorted(doc['results'],key=lambda x:(x['n'],x['cosets'],x['extreme'])):
   f.write(f"| {r['n']} | {r['cosets']} | {r['extreme']} | {r['block']} / {r['row']} | {r['event_count']} | {r['one']['radius_relative_error']:.3g} / {r['tau']['radius_relative_error']:.3g} | {r['one']['winner_count_match']} / {r['tau']['winner_count_match']} | {r['cpu_seconds']:.2f} | {r['peak_rss_bytes']/2**20:.1f} |\n")
  f.write('\nJSON 保存任务编号、输入哈希、命令、精确 cutoff、winner 及完整计数；此有限复核不证明高维渐近结论。\n')
 print('stage',args.stage,'results',len(doc['results']))
if __name__=='__main__':main()
