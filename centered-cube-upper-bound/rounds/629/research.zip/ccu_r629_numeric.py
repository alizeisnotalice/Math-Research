import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,ctypes,hashlib,heapq,json,math,platform,resource,shlex,sys,time
from pathlib import Path
import numpy as np
TAU=.75

def parameters(n,k):
 delta=.125;a=(k/delta)**(1/n);cut=n*a/(2*math.log(TAU/delta))*1.00000000001;return delta,a,cut

def scan(x,k,a,cut):
 n=len(x);heap=[];counts=[[0]*n for _ in range(k)];zeros=[n]*k;products=[1]*k
 for c in range(k):
  shift=c*a/2
  for i,z in enumerate(x):
   q=math.floor((z-shift)/a);left=q*a+shift;right=left+a;heapq.heappush(heap,(z-left,c,i));heapq.heappush(heap,(right-z,c,i))
 best1=besttau=0.;events=0;amb=0;win1=wintau=None
 while heap:
  r=heap[0][0]
  if r>=cut:break
  while heap and heap[0][0]==r:
   _,c,i=heapq.heappop(heap);old=counts[c][i];counts[c][i]+=1
   if old==0:zeros[c]-=1
   else:products[c]=products[c]//old*(old+1)
   heapq.heappush(heap,(r+a,c,i));events+=1
  count=sum(products[c] for c in range(k) if zeros[c]==0)
  if count==0:continue
  if r==0:return {'status':'atomic_receiver_null_case','events':events}
  logm=math.log(count);marg1=logm-n*math.log(2*r);next_r=min(heap[0][0],cut)
  if abs(marg1)<1e-10:amb+=1
  if marg1>0:
   right=min(next_r,.5*math.exp(logm/n))
   if right>best1:best1=right;win1={'left':r,'right':right,'count':str(count),'log_margin_at_entry':marg1}
  margtau=marg1-math.log(TAU)
  if abs(margtau)<1e-10:amb+=1
  if margtau>0:
   right=min(next_r,.5*math.exp((logm-math.log(TAU))/n))
   if right>besttau:besttau=right;wintau={'left':r,'right':right,'count':str(count),'log_margin_at_entry':margtau}
 if best1==0:return {'status':'not_E1','events':events,'near_equality_events':amb}
 assert besttau>=best1*(1-1e-12)
 return {'status':'E1','events':events,'near_equality_events':amb,'r1':best1,'r_tau':besttau,'log_V_tau':n*math.log(2*besttau),'radius_ratio':besttau/best1,'witness_1':win1,'witness_tau':wintau}

def block_slice(arg):
 n,k,block,N,first,last=arg;t=time.monotonic();cpu=time.process_time();delta,a,cut=parameters(n,k);seed=629000000+n*1000+k*100+block;rng=np.random.default_rng(seed);points=(rng.random((N,n))-.5)*a;rows=[]
 for x in points[first:last]:
  z=scan(x,k,a,cut);z['x']=x.tolist();rows.append(z)
 return {'n':n,'cosets':k,'block':block,'N':N,'seed':seed,'delta':delta,'spacing_binary64':a,'cut_binary64':cut,'first':first,'last':last,'rows':rows,'elapsed_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def combine(parts):
 parts=sorted(parts,key=lambda p:p['first']);assert parts[0]['first']==0 and parts[-1]['last']==parts[0]['N'] and all(a['last']==b['first'] for a,b in zip(parts,parts[1:]));p=parts[0]
 return {**{k:p[k] for k in ('n','cosets','block','N','seed','delta','spacing_binary64','cut_binary64')},'rows':[z for p in parts for z in p['rows']],'max_chunk_elapsed_seconds':max(p['elapsed_seconds'] for p in parts),'block_wall_seconds':None,'wall_note':'Individual chunk durations do not determine block wall time.','cpu_seconds':sum(p['cpu_seconds'] for p in parts),'peak_rss_bytes_macos':max(p['peak_rss_bytes_macos'] for p in parts),'chunk_count':len(parts)}

def ticks():
 lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib');v=(ctypes.c_uint32*4)();c=ctypes.c_uint32(4);return list(v) if lib.host_statistics(lib.mach_host_self(),3,v,ctypes.byref(c))==0 else None

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=('pilot','full','block'),default='full');ap.add_argument('--workers',type=int,default=14);ap.add_argument('--n',type=int,default=7);ap.add_argument('--cosets',type=int,choices=(1,2),default=1);ap.add_argument('--block',type=int,default=0);ap.add_argument('--samples',type=int,default=16);ap.add_argument('--chunk-size',type=int,default=4);ap.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent/'replay');args=ap.parse_args();assert 1<=args.workers<=14 and args.chunk_size>=1 and args.samples>=1;args.output_dir.mkdir(parents=True,exist_ok=True);path=args.output_dir/'ccu_r629_numeric.json';md=args.output_dir/'ccu_r629_numeric.md';start=time.monotonic()
 if args.phase=='block':
  pieces=[(args.n,args.cosets,args.block,args.samples,i,min(i+args.chunk_size,args.samples)) for i in range(0,args.samples,args.chunk_size)]
  with concurrent.futures.ProcessPoolExecutor(max_workers=min(args.workers,len(pieces))) as pool:r=combine(list(pool.map(block_slice,pieces)))
  (args.output_dir/'ccu_r629_block.json').write_text(json.dumps(r));print('block',args.n,args.cosets,args.block,'samples',args.samples,'chunks',len(pieces),'E1',sum(z['status']=='E1' for z in r['rows']));return
 if args.phase=='pilot':out={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),'commands':[],'results':[],'resource_samples':[],'semantics':'uniform actual receiver in fundamental cell; one or two globally coupled cosets; full all-radius scans; finite binary64 diagnostic'};tasks=[(n,k,0,16) for n in (7,32) for k in (1,2)]
 else:
  out=json.loads(path.read_text()) if path.exists() else {'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),'commands':[],'results':[],'resource_samples':[],'semantics':'uniform cell receiver; one or two globally coupled cosets; full all-radius scans; binary64 diagnostic'}
  present={(r['n'],r['cosets'],r['block']) for r in out['results']};tasks=[(n,k,b,16) for n in (32,128,512) for k in (1,2) for b in range(8) if (n,k,b) not in present];out['prior_pilot_script_sha256']=out['script_sha256'];out['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
  if not tasks:print('all default blocks already present');return
 out['commands'].append(shlex.join([sys.executable]+sys.argv));prev=ticks();last=time.monotonic()
 def save():
  summaries=[]
  for n in sorted({r['n'] for r in out['results']}):
   for k in (1,2):
    rs=[r for r in out['results'] if r['n']==n and r['cosets']==k];N=sum(r['N'] for r in rs);ok=[q for r in rs for q in r['rows'] if q['status']=='E1'];vals=np.array([q['log_V_tau'] for q in ok]);rat=np.array([q['radius_ratio'] for q in ok]);d={'n':n,'cosets':k,'samples':N,'E1_hits':len(ok),'ambiguous_event_count':sum(q.get('near_equality_events',0) for r in rs for q in r['rows'])}
    if len(vals):
     p10,p25,p75,p90=np.quantile(vals,[.1,.25,.75,.9]);d.update({'logV_q10':float(p10),'logV_q90':float(p90),'width80':float(p90-p10),'IQR':float(p75-p25),'width80_over_sqrt_n':float((p90-p10)/math.sqrt(n)),'r_ratio_median':float(np.median(rat))})
    summaries.append(d)
  out['summaries']=summaries;path.write_text(json.dumps(out));lines=['# R629 outer-witness log-mass width','', 'Each x is uniformly sampled in the periodic fundamental cell. Both 1 and τ=.75 outer witnesses use one complete event scan to the safe cutoff. The second model is a sum of two globally coupled coset products. Values describe finite E1-conditioned samples, not a bound or asymptotic exponent. All floating event/cutoff ambiguities are outside the statistical assessment.','','| n | cosets | N | E1 hits | central 80% log Vτ width | IQR | width/√n | median rτ/r1 |','|---:|---:|---:|---:|---:|---:|---:|---:|']
  for z in summaries:
   if z['E1_hits']:lines.append('| %d | %d | %d | %d | %.7g | %.7g | %.7g | %.7g |'%(z['n'],z['cosets'],z['samples'],z['E1_hits'],z['width80'],z['IQR'],z['width80_over_sqrt_n'],z['r_ratio_median']))
   else:lines.append(f"\nNo E1 hits: n={z['n']}, cosets={z['cosets']}, N={z['samples']}")
  lines+=['','The central-80% sample width is descriptive and may be unstable with few E1 hits. No monotone fit or claim about all finite sources is made.'];md.write_text('\n'.join(lines)+'\n')
 pieces=[(n,k,b,N,i,min(i+args.chunk_size,N)) for n,k,b,N in tasks for i in range(0,N,args.chunk_size)];parts={};needed={(n,k,b):math.ceil(N/args.chunk_size) for n,k,b,N in tasks}
 with concurrent.futures.ProcessPoolExecutor(max_workers=min(args.workers,len(pieces))) as pool:
  pending={pool.submit(block_slice,q) for q in pieces}
  while pending:
   done,pending=concurrent.futures.wait(pending,timeout=.2,return_when=concurrent.futures.FIRST_COMPLETED)
   for f in done:
    piece=f.result();key=(piece['n'],piece['cosets'],piece['block']);parts.setdefault(key,[]).append(piece)
    if len(parts[key])==needed[key]:
     r=combine(parts.pop(key));out['results'].append(r);save();print('done',r['n'],r['cosets'],r['block'],'hits',sum(q['status']=='E1' for q in r['rows']),'chunk_cpu',round(r['cpu_seconds'],3),flush=True)
   now=time.monotonic()
   if now-last>=.2:
    t=ticks();d=[(t[i]-prev[i])%(1<<32) for i in range(4)];out['resource_samples'].append({'phase':args.phase,'elapsed_seconds':now-start,'live_worker_processes':sum(p.is_alive() for p in pool._processes.values()),'worker_slots':args.workers,'active_tasks':None,'host_cpu_percent':100*(sum(d)-d[2])/sum(d) if sum(d) else None,'note':'live processes and worker slots do not establish active tasks; active tasks were not sampled'});prev=t;last=now
 out['last_phase']=args.phase;out['last_wall_seconds']=time.monotonic()-start;out['worker_cpu_sum_seconds']=sum(r['cpu_seconds'] for r in out['results']);out['max_worker_rss_bytes']=max(r['peak_rss_bytes_macos'] for r in out['results']);save()
if __name__=='__main__':main()
