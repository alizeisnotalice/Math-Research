#!/usr/bin/env python3
"""Exact endpoints and finite clock quadrature, NOT a FULL geometric input."""
import argparse,json,hashlib
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp

def run(dps):
    with mp.workdps(dps):
        rows=[]
        for k in [0,1,8,32,128,512]:
            n=k+1; eps=mp.power(2,-2*k)
            # Three original source slots, terminal and never renormalized separately.
            # G: all n active; B: first k active; S: no active coordinates.
            def stat(t):
                x=t**(-n); y=t**(-k); e=x+y+eps
                pg,pb,ps=x/e,y/e,eps/e
                cut=pg*(pb+n*ps)
                mean=n*pg+k*pb
                return e,cut,mean
            ep=F(1,2**(2*k))
            exact=1/(2+ep)-F(1,2**n)/(F(1,2**n)+F(1,2**k)+ep)
            exactmp=mp.mpf(exact.numerator)/exact.denominator
            gap=mp.mpf(1)/(n+2)
            grid=sorted(set([mp.mpf(1),1+gap,mp.mpf('1.1'),mp.mpf('1.5'),mp.mpf('1.9'),2-gap,mp.mpf(2)]))
            def quad(fun):return sum(mp.quad(fun,[a,b]) for a,b in zip(grid[:-1],grid[1:]))
            integral=quad(lambda t:stat(t)[1]/t)
            assert abs(integral-exactmp)<mp.mpf('1e-32')
            prices=[]
            for alpha in [mp.mpf(0),mp.mpf('.5'),mp.mpf(1)]:
                left=quad(lambda t:stat(t)[1]/stat(t)[0]**alpha/t)
                right=quad(lambda t:stat(t)[1]*stat(t)[0]**alpha/t)
                price=left*right
                assert price+mp.mpf('1e-32')>=exactmp**2
                if alpha==0:assert abs(price-exactmp**2)<mp.mpf('1e-32')
                H=eps/mp.power(2,n)
                prices.append({'alpha':str(alpha),'J':mp.nstr(left,90),'partner':mp.nstr(right,90),'price':mp.nstr(price,90),'over_true_square':mp.nstr(price/exactmp**2,90),'H_squared_price':mp.nstr(H**2*price,90)})
            # Check pointwise coordinate cut, using the very same source probabilities.
            for t in grid:
                e,c,m=stat(t);pg=t**(-n)/e;pb=t**(-k)/e
                coord=k*(pg+pb)*(1-pg-pb)+pg*(1-pg)
                assert c<=coord+mp.mpf('1e-32')
                assert coord<=m*(1-m/n)+mp.mpf('1e-32')
            eg=stat(mp.mpf(2))[0];eta=1-1/(32*mp.sqrt(n));H=eps/mp.power(2,n)
            assert eta*mp.power(2,n)*H<=eg
            rows.append({'stage':'initial' if k<=1 else 'stress' if k<=32 else 'expanded','common_far_coordinates':k,'n':n,'near_mass_exact':str(ep),'hard_H':mp.nstr(H,90),'eta':mp.nstr(eta,90),'terminal_e':mp.nstr(eg,90),'clock_integral_exact':str(exact),'clock_square_exact':str(exact**2),'clock_integral_quad':mp.nstr(integral,90),'prices':prices})
        return rows

def numbers(x,p=''):
    out={}
    if isinstance(x,list):
        for i,v in enumerate(x):out.update(numbers(v,p+str(i)+'/'))
    elif isinstance(x,dict):
        for k,v in x.items():
            if k.endswith('_exact') or k=='stage':continue
            if isinstance(v,(dict,list)):out.update(numbers(v,p+k+'/'))
            elif isinstance(v,str):out[p+k]=mp.mpf(v)
    return out

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=parser.parse_args()
    lo=run(40);hi=run(70)
    with mp.workdps(100):
        ll,hh=numbers(lo),numbers(hi);assert ll.keys()==hh.keys()
        diffs={k:abs(ll[k]-hh[k])/max(1,abs(hh[k])) for k in ll};worst=max(diffs,key=diffs.get)
        assert diffs[worst]<mp.mpf('1e-30')
        error=mp.nstr(diffs[worst],90)
    result={'schema':'R274-three-source-cut-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'models':6,'stages':{'initial':2,'stress':2,'expanded':2},'alpha_prices_per_precision':18,'precision_fields':len(diffs)},'mp40':lo,'mp70':hi,'max_relative_difference':error,'worst_field':worst,'scope':['Threshold product weights, same full three-slot posterior, positive persistent near mass, exact posterior derivative endpoint. No coordinates are assumed independent under the source law.','Actual target kernel values and FIRST/high/history geometry are NOT constructed. K_G=w_g(G), other target values zero; this choice makes the source CS exact. Rational endpoint identity is exact, quadrature is ordinary mpmath, not interval certification.','There is no active coordinate common to ALL sources, since the persistent near source is inactive. Far sources have k common coordinates, but their small near complement remains in every denominator and cut. The hard-floor inequality is checked; this alone is not a FULL certificate.','alpha0 exactness is a property of these finite examples, not a universal statement that alpha0 dominates other choices or proves a general dimension order. H_squared_price is retained: huge relative clock gaps need not imply a large globally weighted original cost.']}
    a.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'counts':result['counts'],'maxdiff':error,'alpha1_over_true':[r['prices'][2]['over_true_square'] for r in hi]}))

if __name__=='__main__':main()
