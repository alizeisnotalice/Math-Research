# R274 independent coordinate-cut and fractional-clock screen

**Verdict: PASS for the stated current terminal-good/terminal-bad positive slot and the paired clock inequality.** Original qualification and elementary inequalities were checked before reading `/tmp/r274_main.md` or another author proof. This is not a general source budget or global closure.

## 1. Exact original slot and static terminal sets

Directly read the R223 frozen `negative_contract.md`, lines 16–55 and 88–104. Its NC2 defines

    B=D_g={u in Z_g:p_y w_g(u)>K Q_x*(u)},
    G=S_g=Z_g minus B,  E_t=Z_t minus Z_g,
    D_t(v,u)=k_t(v)−k_t(u).

NC4, lines 50–55, explicitly gives the **current positive remainder** on G×B with (k_good−k_bad)_+. The two complete copies are the same original Π_t, including its full carrier and degree; NC3 lines 35–42 specifies this product measure. At fixed actual x,y,j,g and history, G and B are terminal sets static in t, and G,B⊂Z_t for t≤g. Their receiver dependence has not disappeared.

The future-deleted set E_t is not terminal good. NC4 has its own E_t×B continuous reverse term, and NC8 contains a separate future positive-score integral with a minus sign. This screening does not silently apply the new 1_G target half-density to E_t or claim that every historical future term is G×B. The current P_r is precisely the G×B slot stated above. Original extra positive capture/FA/suffix/current-allocation gates have values in [0,1] and may be positively enlarged here; no signed negative gate or credit is changed.

## 2. Coordinate cut domination without independence assumptions

Write a_i(v,t)=1_{A_i(y,v)<t} and k_t(v)=sum_i a_i(v,t). For any two indicator vectors,

    (sum_i a_i(v)−sum_i a_i(u))_+
       ≤sum_i a_i(v)[1−a_i(u)].                         (C1)

Indeed the difference is the number of v-only coordinates minus the number of u-only coordinates, while the right side counts the former. For v∈G, integrating (C1) over u∈B under the actual Π_t gives

    integral_B (k_t(v)−k_t(u))_+ Π_t(du)≤c_t(v),
    c_t(v)=1_G(v)sum_i a_i(v,t)Π_t(B intersect {a_i=0}). (C2)

This is a positive upper bound, generally not an equality: coordinate cancellations in the positive score can be lost. For v outside G, (C2) is understood with the original 1_G on the left as well.

Let m_cut=Π_t c_t, p_i=Π_t a_i and m_t=sum_i p_i. Then

    m_cut=sum_i Π_t(G intersect {a_i=1})
                      Π_t(B intersect {a_i=0})
       ≤sum_i p_i(1−p_i)
       =m_t−sum_i p_i²
       ≤m_t(1−m_t/n)≤m_t.                             (C3)

Only the given product of the two complete posterior copies is used. Neither the coordinates nor β,ν or the hard source are assumed independent. If a coordinate is active Π_t-almost surely, its bad-inactive factor is zero and it contributes nothing. It is therefore legitimate to say common fully active coordinates disappear from this cut. The worst-case cut mass is still at most n/4; (C3) alone does not imply a root-order total budget.

The scalar c_t is nonnegative, at most 1_G k_t, and is both receiver/terminal-set dependent and time dependent through Π_t and activity. It cannot be moved outside actual receiver/time integrals as a frozen source quantity without a new theorem.

## 3. Same-source Cauchy and the fractional clock

Fix a nonnegative actual physical target K(x,v), static at the actual row during the clock, and retain the original terminal denominator w_g. Set

    B_cut(t)=integral_(Z_t) c_t(v)w_t(v)sqrt(K(x,v)/w_g(y,v))ν(dv),
    F_cut(t)=integral_(Z_t) c_t(v)w_t(v)K(x,v)/w_g(y,v)ν(dv).

Since G⊂Z_t, the explicit 1_Z may be omitted only with that same qualification. The first source Cauchy factor has mass integral c_t w_t ν=e_t m_cut, so

    B_cut(t)²≤e_t m_cut(t) F_cut(t).                     (C4)

On m_cut=0, B_cut=0. This needs no new law or normalization for the cut measure.

To avoid confusion with the physical lower scale a, call the proposed exponent α∈(0,1]. With e_g>0 on nonzero valid high rows, define

    I_cut=integral_tau^g B_cut(t)/e_t dlogt,
    J_cut,α=integral_tau^g m_cut(t)/e_t^α dlogt.

Clock Cauchy with factors sqrt(m_cut/e^α) and B_cut e^(α/2−1)/sqrt(m_cut), followed by (C4), proves

    I_cut²≤J_cut,α integral_tau^g e_t^(α−1)F_cut(t)dlogt. (C5)

For α=1 the remaining F_cut has no degree factor. For α<1 the negative degree power e_t^(α−1) is mandatory and cannot be discarded or treated as a free constant. Keeping both factors preserves dimensions. J_cut,α=0 implies the original I_cut is zero; handle that case before a possible formal 0 times infinity. Empty/invalid rows and empty clocks are zero before division. Extended nonnegative versions use ordinary finite positive truncation.

No derivative of c_t or m_cut has been invoked. In particular it would be false to treat m_cut as the actual logarithmic degree decay. The comparison to full m_t in (C3) is what permits an endpoint bound:

    J_cut,α≤integral_tau^g m_t/e_t^α dlogt
      =[e_g^(−α)−e_tau^(−α)
         −sum_(tau<t≤g)(e_t^(−α)−e_(t−)^(−α))]/α.     (C6)

The equality on the second line belongs to the **full m_t** inverse-degree ledger, not to m_cut itself. Threshold births do not jump weights. The original finite-tree carrier has only deletion jumps, which make e^(−α) jump positively. The start is right-continuous, an included terminal deletion is subtracted, and an open right endpoint requires simultaneous left-limit terminal values/event conventions. These positive degree-loss identities do not spend any original signed negative credit.

For example α e_g^α J_cut,α≤1−(e_g/e_tau)^α≤1. This is a valid normalized comparison, not a general source payment. A smaller actual far-clock domain may be kept or positively enlarged to the original raw [tau,g]; an exact full-interval endpoint identity is not automatically an identity for an arbitrarily disconnected smaller domain.

## 4. Applicability and unproved costs

The actual original good-kernel half-density is legal on G. The cut c_t may replace its good-slot score upper bound while keeping both complete original posteriors intact. This does not extend the terminal-good inequality to future-deleted sources, replace β/ν, create a new posterior or a source-independent cut, or make the actual G/B selector independent of x. The target inverse weight, fractional residual degree when α<1, actual source/receiver loading and all outer original costs remain. No root-order source total follows merely from the disappearance of common active coordinates.

## 5. Actually executed bounded arithmetic

Executed 12 exact Fraction coordinate laws at n=1,2,3,4, with three positive probability vectors per dimension, nonempty terminal G/B and an optional third class. All 45 good-slot pointwise score bounds, cut-mass inequalities and source-Cauchy squares passed. These are probability algebra tests, not actual clamp/FIRST/FULL geometries. Exact executed code:

```python
from fractions import Fraction as F
laws=points=0
for n in range(1,5):
    N=2**n
    bits=[[(v>>i)&1 for i in range(n)] for v in range(N)]
    k=[sum(x) for x in bits]
    G=set(range(N//2,N));B=set(range(max(1,N//4)))
    for typ in range(3):
        w=[i+1 if typ==0 else N-i if typ==1 else 1+(i%3)
           for i in range(N)]
        tot=sum(w);P=[F(x,tot) for x in w]
        c=[sum(F(bits[v][i])*sum(P[u] for u in B if not bits[u][i])
               for i in range(n)) if v in G else F(0)
           for v in range(N)]
        for v in G:
            assert sum(max(0,k[v]-k[u])*P[u] for u in B)<=c[v]
            points+=1
        mc=sum(P[v]*c[v] for v in range(N))
        m=sum(P[v]*k[v] for v in range(N))
        pi=[sum(P[v]*bits[v][i] for v in range(N)) for i in range(n)]
        assert mc<=sum(p*(1-p) for p in pi)<=m*(1-m/n)<=m
        e=F(7,3);q=[F(v+1,5) for v in range(N)]
        bc=e*sum(P[v]*c[v]*q[v] for v in range(N))
        fc=e*sum(P[v]*c[v]*q[v]**2 for v in range(N))
        assert bc**2<=e*mc*fc
        laws+=1
print('PASS',laws,'exact coordinate-cut laws;',points,
      'good-slot pointwise bounds; mass and source-CS checks')
```

# Addendum: alpha-zero and actual terminal common activity

## A. Alpha-zero clock Cauchy

**Verdict: PASS as a separate formula.** Set L_cut=integral m_cut dlogt. Direct clock Cauchy, with factors sqrt(m_cut) and B_cut/(e_t sqrt(m_cut)), and then the same source Cauchy, gives

    I_cut²≤L_cut integral F_cut(t)/e_t dlogt.             (Z1)

Zero cut mass implies B_cut=0; L_cut=0 is handled before a formal zero times infinity. This keeps both the cut occupation and the target's degree denominator. It is not obtained by substituting alpha=0 into a source/high coefficient containing 1/alpha. When the whole original finite-tree interval is used, the full mean has the distinct logarithmic ledger

    L_cut≤integral m_t dlogt
      =log(e_tau/e_g)−sum_(tau<t≤g)log(e_(t−)/e_t).

It is not a constant high-loading cap without its own further argument. The positive-alpha endpoint identity and its paired residual degree factor stay as previously stated.

## B. Terminal common factor and the genuine near witness

**Verdict: PASS on a nonzero original near-hard row.** Suppose k0(t) counts coordinates active on every terminal source in Z_g (or essentially every source under ν|Z_g), with its usual measurable definition. H>0 supplies a positive-ν set of near surviving hard sources. For ν-almost every such z, Tonelli over time and terminal source implies k0(t)≤k_t(z) for almost every t. Thus

    exp[integral_tau^g k0(t)dlogt]
      ≤exp[integral_tau^g k_t(z)dlogt]
      =w_tau(z)/w_g(z)
      ≤1/eta.                                          (Z2)

The last step uses w_tau≤1 and the actual near-survivor lower bound w_g≥eta. The clocks and endpoint conventions are the original ones; threshold equalities have zero dlogt measure. H=0 provides no near witness and is a zero response treated separately. A condition only on terminal G or only on terminal B is not enough unless it also contains that near hard witness. A third near group in an abstract model must still be placed consistently within the actual terminal carrier/partition if an original qualification is claimed.

Consequently an abstract model with a huge factor common to all terminal sources cannot simultaneously be treated as a nonzero actual near-hard instance with the stated weight lower bound. Large activity under high posterior probability with an extremely small near mass is not excluded by (Z2); it still requires the actual H²/e_g or loading geometry. This observation is a qualification, not a payment of that remaining joint quantity.

### Essential limitation on factorization of the complete posterior

Terminal common activity is not automatically common to future-deleted E_t=Z_t minus Z_g. It alone does **not** justify applying a nonincreasing-degree inverse identity after factoring a common term from the full original posterior. One can algebraically divide every raw weight by the same time factor and preserve Π by dividing e as well, but the resulting logarithmic score is m_t−k0(t), which can be negative when future sources are not active on those coordinates. The tilded degree may increase, and the positive cut/inverse inequalities no longer follow.

A positive clamp-factor reduction preserving all those inverse-ledger properties needs the stronger activity hypothesis on every source in each entire current Z_t, or an independent proof of the required tilded derivative/positivity inequalities. The terminal near bound (Z2) is valid without such a factorization and must not be used to manufacture it.

## C. Actual bounded alpha-zero arithmetic

Executed eight exact Fraction clock-Cauchy cases, including zero cut mass. They are only finite weighted-CS checks, not clamp/FIRST/FULL laws. Code:

```python
from fractions import Fraction as F
for mask in range(8):
    e=[F(4),F(2),F(1)]
    dt=[F(1,2),F(1,3),F(2,5)]
    c=[F((mask>>i)&1) for i in range(3)]
    q=[F(1,3),F(2),F(5,4)]
    B=[e[i]*c[i]*q[i] for i in range(3)]
    FF=[e[i]*c[i]*q[i]**2 for i in range(3)]
    I=sum(dt[i]*B[i]/e[i] for i in range(3))
    L=sum(dt[i]*c[i] for i in range(3))
    M=sum(dt[i]*FF[i]/e[i] for i in range(3))
    assert I*I<=L*M
print('PASS 8 exact alpha-zero clock-CS cases including zero cut mass')
```
