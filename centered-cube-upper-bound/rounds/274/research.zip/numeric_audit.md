# R274 bounded independent audit of the six three-source cut diagnostics

Audit scope: formula/code review of `/tmp/r274_cut_checks.py` and its current JSON. I did not rerun its quadratures, the nine-law menu, or an additional geometric search. No parent file was modified.

Reviewed bindings:

- Python SHA256: `aaa425ef057e2ec49d174c2716cbad03dd79e1b36841280e8a1b66ca964c8f84`.
- JSON SHA256: `acdb5ac98da1eaf4d96c1aa37cd2cc0ee433639cc6c9beba27d476ccba52a3c0`.
- The JSON script_sha256 equals the actual reviewed Python digest.

## N1. Exact row law and endpoint

For k in {0,1,8,32,128,512}, put n=k+1, epsilon=2^(-2k), and on the open clock (1,2),
\[
 x=t^{-n},\quad y=t^{-k},\quad e=x+y+\epsilon,
 \qquad (g,b,s)=(x,y,\epsilon)/e.
\]
These are the **same full three-source posterior** in every expression. With the target cut G against {B,S},
\[
 c_G=b+ns,\quad m_c=g(b+ns),\qquad
 -\frac{d g}{d\log t}=g(n-ng-kb)=g(b+ns)=m_c.
\]
Therefore
\[
 I=\int_1^2m_c\,dt/t
 =\frac1{2+\epsilon}
  -\frac{2^{-n}}{2^{-n}+2^{-k}+\epsilon}.
\]
This is exactly the script's Fraction endpoint. The stored exact square is its rational square. All six endpoints were independently reconstructed with Fraction and matched.

Endpoint convention: the active vectors (1,...,1), (1,...,1,0), and 0 are the right-limit vectors at t=1. If one implements the strict original convention k_t=# {A_i<t} with thresholds A_i=1, their values at exactly t=1 are different. This changes neither the clock integrals nor the endpoint probabilities; it should be described as a right-limit endpoint convention, not a strict pointwise score equality at t=1. The same issue does not affect the constant-weight inactive coordinates at the upper endpoint.

## N2. Original masked cut versus the full positive Gini

Use the three nested binary active vectors just stated. Nestedness makes the positive score difference equal the directed coordinate disagreement for each ordered pair. On the **masked** cut G x {B,S},
\[
 \sum_i\Pi(G\cap\{a_i=1\})\Pi(\{B,S\}\cap\{a_i=0\})
 =g b+n g s=m_c.
\]
The script's `coord` instead includes the additional B x S pairs:
\[
 \mathcal J_{\rm full}=g b+n g s+k b s
 =k(g+b)s+g(1-g)=\texttt{coord}.
\]
Thus its assertion m_c<=coord is correct. It is not asserting m_c=the full unmasked Gini. The additional bound
\[
 \texttt{coord}\le m(1-m/n),\qquad m=ng+kb,
\]
is the coordinate marginal Jensen bound, with each coordinate marginal in [0,1]. The audit checked the masked equality, full equality and both inequalities exactly at seven rational times for all six k values. No coordinate independence under the source law is used.

## N3. Source Cauchy and alpha prices

The artificial target values are K_G=w_g(G), K_B=K_S=0. The cut score measure on the target slot is supported on G. Consequently its square-root test equals 1 wherever that cut measure is nonzero, so the target/source Cauchy step is an equality and the exact cut clock response is I.

For any real alpha, ordinary clock Cauchy gives
\[
 I^2\le\left(\int_1^2m_c e^{-\alpha}\,dt/t\right)
         \left(\int_1^2m_c e^{\alpha}\,dt/t\right).
\]
The script computes precisely this product at alpha=0,1/2,1. At alpha=0 both factors are I, so equality is exact. This is a property of this target/cut diagnostic, not a theorem that alpha=0 is always the best row bound.

Crucially, the script does **not** use the inverse-power continuous-degree identity with m_c in place of the full mean m. Such an identity would in general be false: de/dlog t=-em, while m_c is the cut flux. Thus these numeric prices are valid direct Cauchy prices, not numerically inferred inverse-degree budgets.

## N4. Actual H-squared loading is retained

With R=2 the assigned hard floor is
\[
 H=\epsilon/2^n=2^{-(3k+1)},\qquad H^2=2^{-(6k+2)}.
\]
The JSON's H_squared_price is H^2 times each clock price, with no removal of the persistent source from any denominator. The check eta*2^n*H<=e_g holds since its left side is eta*epsilon and e_g>=epsilon. Eta=1-1/(32sqrt n) is consistent with the displayed a=1,b=2 near-floor scale, but that isolated inequality does not certify the other original gates.

The following stored alpha=1 values were independently read and their products verified at 100-digit working precision:

| k | price / I² | H² price |
|---:|---:|---:|
| 0 | 1.00276856 | 0.00445674917 |
| 1 | 1.05560277 | 0.000155901981 |
| 8 | 9.88454345 | 2.46396778e-16 |
| 32 | 11002907.3 | 1.21726685e-53 |
| 128 | 5.51659104e34 | 2.46758219e-199 |
| 512 | 1.36257734e149 | 1.62874086e-778 |

The large relative Cauchy gaps therefore do not imply a large original H²-weighted traffic price. There is no active coordinate shared by **all** three sources; the persistent S slot is inactive. Calling the k far-shared coordinates a full-row common factor would be incorrect.

## N5. Actual local verification and scope conclusion

An independent local Python check performed:

- 144 exact Fraction assertions: six exact endpoints/squares, seven rational-time masked/full cut identities and inequalities per row, and the exact H formula.
- 36 stored-decimal identity checks at mpmath 100 digits: price=J*partner and H_squared_price=H²*price for all 18 alpha records, with relative discrepancies below 1e-65.
- Script/JSON source-binding verification.

Actual output was `PASS 180 exact/digit-identity checks; no quadrature rerun`. The saved ordinary 40/70-digit quadratures are author-executed numerical evidence, not interval certification; this audit did not independently rerun them.

Formula/code conclusion: PASS for the stated finite three-slot cut diagnostic, with the endpoint right-limit qualification in N1. It does not construct actual target P kernels, absolutely continuous original sources, FIRST/high, receiver dx, seed/history or a FULL instance. The artificial zero target values are not asserted to be values of the original strictly positive soft kernels. It neither proves a global dimension order nor pays the current full source traffic. No negative credit is used.
