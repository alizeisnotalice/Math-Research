#!/usr/bin/env python3
import argparse,hashlib,json,re,subprocess,sys,tempfile
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def audit_cut(root):
    rows=json.loads((root/'cut_checks.json').read_text())['mp70'];count=0
    with mp.workdps(100):
        for row in rows:
            k=row['common_far_coordinates'];n=k+1;ep=F(1,2**(2*k))
            endpoint=1/(2+ep)-F(1,2**n)/(F(1,2**n)+F(1,2**k)+ep)
            assert endpoint==F(row['clock_integral_exact']);count+=1
            assert endpoint**2==F(row['clock_square_exact']);count+=1
            for t in [F(1),F(7,6),F(4,3),F(3,2),F(5,3),F(11,6),F(2)]:
                x=t**(-n);y=t**(-k);e=x+y+ep;g,b,s=x/e,y/e,ep/e
                mc=g*(b+n*s)
                assert mc==g*b+n*g*s;count+=1
                full=k*(g+b)*s+g*(1-g)
                assert full==mc+k*b*s;count+=1
                m=n*g+k*b
                assert mc<=full<=m*(1-m/n);count+=1
            H=ep/F(2**n)
            assert H==F(1,2**(3*k+1));count+=1
            hm=mp.mpf(H.numerator)/H.denominator
            for price in row['prices']:
                p=mp.mpf(price['price']);j=mp.mpf(price['J']);v=mp.mpf(price['partner'])
                assert abs(p-j*v)/abs(p)<mp.mpf('1e-65');count+=1
                hprice=mp.mpf(price['H_squared_price'])
                assert abs(hprice-hm**2*p)/abs(hprice)<mp.mpf('1e-65');count+=1
    assert count==180
    print('PASS 180 independent endpoint/cut/stored-product identities')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check-only',action='store_true');args=parser.parse_args()
    root=Path(__file__).resolve().parent
    for name,sha in json.loads((root/'manifest.json').read_text())['sha256'].items():assert digest(root/name)==sha,name
    print('PASS manifest hashes')
    blocks=re.findall(r'```python\n(.*?)```',(root/'screen.md').read_text(),re.S)
    assert len(blocks)==2
    for block in blocks:exec(compile(block,'screen.md','exec'),{'__name__':'__main__'})
    audit_cut(root)
    if args.check_only:return
    with tempfile.TemporaryDirectory(prefix='r274-replay-') as tmp:
        for stem in ['numeric_checks','cut_checks']:
            out=Path(tmp)/(stem+'.json')
            subprocess.run([sys.executable,str(root/(stem+'.py')),'--output',str(out)],check=True)
            assert out.read_bytes()==(root/(stem+'.json')).read_bytes(),stem
            print('PASS byte-identical replay',stem)

if __name__=='__main__':main()
