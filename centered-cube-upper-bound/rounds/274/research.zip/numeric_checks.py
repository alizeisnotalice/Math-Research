#!/usr/bin/env python3
"""R274 same-carrier two-stage time-CS diagnostics; finite polynomial clocks."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp

def enc(x):return mp.nstr(x,100)
def mm(x):
 q=F(x);return mp.mpf(q.numerator)/q.denominator
def source(mass,bins,K='1',delete=None):return {'mass':F(mass),'bins':[(F(a),k) for a,k in bins],'Kraw':F(K),'delete':F(delete) if delete else None}
def menus():
 return [('initial','single_n2',2,[source('1',[('1',2)])]),('initial','single_n8',8,[source('1',[('1',8)])]),('initial','correlated_two_n8',8,[source('1',[('1',8)]),source('3',[('5/4',4),('3/2',4)],'1/3')]),('stress','nearhard_massive_carrier',64,[source('1000000',[('1999999/1000000',64)],'1/1000000000000'),source('1',[('1',64)])]),('stress','deleted_hard_carrier',64,[source('10',[('2',64)],'0','3/2'),source('1',[('5/4',64)])]),('stress','late_birth_target',64,[source('10',[('2',64)],'0','3/2'),source('1',[('1999/1000',64)])]),('expanded','delete_with_correlated_target_n128',128,[source('1000000',[('2',128)],'0','3/2'),source('1',[('5/4',64),('7/4',64)])]),('expanded','single_n512',512,[source('1',[('1',512)])]),('expanded','heterogeneous_n512',512,[source('1',[('1',512)]),source('10',[('5/4',256),('7/4',256)],'1/10'),source('100',[('3/2',128),('19/10',384)],'1/100')])]
def weight(z,t):
 out=F(1)
 for a,k in z['bins']:out*=min(F(1),a/t)**k
 return out

def run(dps):
 with mp.workdps(dps):
  rows=[]
  for stage,name,n,src in menus():
   norm=sum(z['mass']*z['Kraw'] for z in src);K=[z['Kraw']/norm for z in src];assert sum(z['mass']*Kj for z,Kj in zip(src,K))==1
   wg=[weight(z,F(2)) for z in src];knots=sorted({F(1),F(2)}|{a for z in src for a,k in z['bins'] if 1<a<2}|{z['delete'] for z in src if z['delete']})
   J1=mp.mpf(0);Jhalf=mp.mpf(0);Ftotal=mp.mpf(0);Fhalf=mp.mpf(0);trueI=mp.mpf(0);exactJ1=F(0);endpointJhalf=mp.mpf(0);midchecks=0;support=[]
   for left,right in zip(knots,knots[1:]):
    mid=(left+right)/2;alive=[i for i,z in enumerate(src) if z['delete'] is None or z['delete']>mid];ks={i:sum(k for a,k in src[i]['bins'] if a<mid) for i in alive};coeff={i:src[i]['mass']*mp.mpf(1) for i in []}
    exactcoeff={i:src[i]['mass'] for i in alive}
    for i in alive:
     for a,k in src[i]['bins']:
      if a<mid:exactcoeff[i]*=a**k
    def values(x):
     wt={i:mm(exactcoeff[i])*mp.exp(-ks[i]*x) for i in alive};e=sum(wt.values());scoremass=sum(ks[i]*wt[i] for i in alive);m=scoremass/e;ff=sum(mm(K[i]/wg[i])*ks[i]*wt[i] for i in alive);B=sum(mp.sqrt(mm(K[i]/wg[i]))*ks[i]*wt[i] for i in alive)
     return e,m,ff,B
    l,r=mp.log(mm(left)),mp.log(mm(right));e,m,ff,B=values((l+r)/2);assert B*B<=e*m*ff*(1+mp.mpf('1e-30'))+mp.mpf('1e-40');midchecks+=1
    # All quantities use this one mixture e and the same alive list.
    J1+=mp.quad(lambda x:values(x)[1]/values(x)[0],[l,r]);Jhalf+=mp.quad(lambda x:values(x)[1]/mp.sqrt(values(x)[0]),[l,r]);Ftotal+=mp.quad(lambda x:values(x)[2],[l,r]);Fhalf+=mp.quad(lambda x:values(x)[2]/mp.sqrt(values(x)[0]),[l,r]);trueI+=mp.quad(lambda x:values(x)[3]/values(x)[0],[l,r])
    el=sum(src[i]['mass']*weight(src[i],left) for i in alive);er=sum(src[i]['mass']*weight(src[i],right) for i in alive);exactJ1+=1/er-1/el
    with mp.extradps(30):endpointJhalf+=2/mp.sqrt(mm(el))*mp.expm1(mp.log(mm(el/er))/2)
    support.append({'left':str(left),'right':str(right),'alive_sources':alive,'scores':[ks[i] for i in alive],'e_left_exact':str(el),'e_right_exact':str(er)})
   old=J1*Ftotal;half=Jhalf*Fhalf;truth=trueI**2
   assert truth<=old*(1+mp.mpf('1e-30'))+mp.mpf('1e-40') and truth<=half*(1+mp.mpf('1e-30'))+mp.mpf('1e-40')
   r1=abs(J1-mm(exactJ1))/max(1,abs(J1));rh=abs(Jhalf-endpointJhalf)/max(1,abs(Jhalf));assert r1<mp.mpf('1e-30') and rh<mp.mpf('1e-30')
   sourcejson=[{'mass':str(z['mass']),'threshold_bins':[[str(a),k] for a,k in z['bins']],'K_normalized':str(K[i]),'wg_underlying_terminal':str(wg[i]),'delete':str(z['delete']) if z['delete'] else None} for i,z in enumerate(src)]
   rows.append({'stage':stage,'name':name,'n':n,'sources':sourcejson,'target_cost_exact':'1','all_positive_K_sources_terminal':all(K[i]==0 or z['delete'] is None for i,z in enumerate(src)),'interval_support':support,'pointwise_CS_midpoint_checks':midchecks,'J1':enc(J1),'Jhalf':enc(Jhalf),'J1_endpoint_exact':str(exactJ1),'J1_endpoint_relative_residual':enc(r1),'Jhalf_endpoint':enc(endpointJhalf),'Jhalf_endpoint_relative_residual':enc(rh),'integral_F':enc(Ftotal),'integral_F_e_minus_half':enc(Fhalf),'true_integral_B_over_e':enc(trueI),'true_squared':enc(truth),'old_J1_price':enc(old),'half_Jhalf_price':enc(half),'half_over_old':enc(half/old) if old else None,'old_over_true':enc(old/truth) if truth else None,'half_over_true':enc(half/truth) if truth else None,'half_improves_old':half<old})
  return {'cases':rows}

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and k not in ['stage','name','J1_endpoint_exact']:
    try:
     val=mp.mpf(v)
     if mp.isfinite(val):out[path+k]=val
    except ValueError:pass
   elif isinstance(v,(dict,list)) and k not in ['sources','interval_support']:out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();lo=run(40);hi=run(70)
 with mp.workdps(120):
  x=fields(lo);y=fields(hi);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);assert diff[worst]<mp.mpf('1e-28')
 out={'schema':'R274-half-time-CS-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'finite_laws_per_precision':9,'stage_laws':{'initial':3,'stress':3,'expanded':3},'pointwise_CS_midpoint_checks_per_precision':sum(r['pointwise_CS_midpoint_checks'] for r in hi['cases']),'half_improves_old_cases':sum(r['half_improves_old'] for r in hi['cases']),'precision_fields_compared':len(diff)},'mp40':lo,'mp70':hi,'precision_max_relative_difference':md,'precision_worst_field':worst,'definitions':{'e':'sum_alive nu w','m':'sum_alive k nu w/e','F':'sum_alive K k nu w/wg','B':'sum_alive k nu w sqrt(K/wg)','J_a':'integral m/e^a dlogt','true':'(integral B/e dlogt)^2','old':'J1 integral F dlogt','half':'Jhalf integral F e^(-1/2) dlogt'},'scope':['Compressed threshold bins are exact rational product-clamp laws on[1,2], dimension n<=512. All positive-K targets survive terminal2; only K0 carriers may delete. Same e,m and alive support are used in both prices and true B integral.','J1 independent endpoint accounting is exact Fraction; Jhalf endpoint primitive is independently evaluated with30 guard digits. Deletion jumps are excluded by summing only continuous interval endpoint differences.','B is the actual finite target sum, not replaced by sqrt(eF). Pointwise B^2<=e m F is checked and both time-CS bounds are compared to the true square.','Ordinary40/70 quadrature, not interval certificate. Abstract normalized target cost sum Knu=1 is not a physical kernel/FIRST/FULL/history construction. Price improvements or near-equality at finite examples do not imply universal improvement or dimension order.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst}))
if __name__=='__main__':main()
