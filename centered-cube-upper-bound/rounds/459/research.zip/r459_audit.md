# R459 最终独立审计

**FINAL PASS（限定实际单端参考、同流后验/retention 比较、原容量接口与列明有限验证）。** 完整原一般根阶预算、实际 channel 的一致几何上界均仍未证明；本报告不认证它们。辅助稿一处 beta*覆盖范围已澄清，当前无待修数学阻断项。2026-10-21。

## 独立依据与准确结论

独立PRE `/tmp/r459_audit_pre.md` 已在读取 R459 作者证明前形成，保存单端参考与同流信息推导；此后实读R458实际接受权/双条件核、作者 geometry/mainproof 与主代理 information 整合稿。没有将有限验证数或作者摘要代替原测度证明。

1. **单端帽保原实际流。** 取实际P=Xi_can,out，推前到(A,y,u,j)得P1，质量R精确保持。只为上界积分另一端真实保留条件质量<=1，再用 `Bsafe_yj>=ell_j-C_A>=b ell_j`，得到 `b kappa_safe<=kappa_raw` 以及逐j `P1_j<=S sigma pi_A kappa_raw_yj`。去soft原逐来源帽、实际非零bin的strict父过去支持均保留；没有假设旧路径/来源已独立，没有删除实际P1中的history接受信息。两端/阶段只累计一次S。
2. **有效性与共同参考。** 固定分析参数的 `N=1+ceil(eps0/delta)`，不足ell_j或无active的来源/bin补共同墓地概率，不伪造截短后仍总质量1的raw核。于是有限参考B1总质量SX，`P1<=N B1`，无zeta损失。P1不在墓地承载质量。参考自身无原history；只有真实P及其投影保持原门。
3. **真正后验。** 实际u∈E时，参考来源后验为 `k0=pi_A c_u w_yj/(I_beta/m_A)`；ell_j m_u在该fiber为常数而相消。没有另一来源的无效bin或被筛实际z污染此后验。I_beta=0、w=0处没有实际接受质量，零流不定义不存在的posterior。
4. **可积性与原子。** canonical分位权保partial atom比例，不给新中心原历史。固定field有正m_-、finite E/X、w<=1、J=I_beta/m_A<=1。对实际u部分，以 `w|logw|, J|logJ|<=1/e` 与 `ell_j m_u>=h m_-` 可得 reference中channel绝对可积的有限粗界（例如 `2SX|E|/(e h m_-)`）；再用 `P1<=N B1` 传给实际P1。该粗界只证合法性、不收源价。墓地不进入实际channel。联合密度与边缘密度均<=N，有限测度熵负部受reference质量控制，所以retention链式法则不含∞−∞。这不需f logf。
5. **真实质量gap。** P1来源后验k支持QA∩Qu。完整matching给I_Au<=m_u，同一实际P继承strict `m_A>K²m_u`。因此 `∫KL(k||pi_A)>=∫log(m_A/m_u)>=2sqrt(n) R`；参考B1没有自动获得这个mass门。事实上在同一fiber精确有 `KL(k||pi_A)=log(m_A/m_u)+KL(k||pi_u)`，不把pi_u用作新history来源。
6. **Retention及channel。** 有限参考链式法则精确给

\[
H_{parent}=H_{ret}+\mathcal C(P_1),\quad
0\le H_{ret}\le R\log N+R\log(SX/R)\le R\log N+SX/e,
\]
\[
\boxed{(2\sqrt n-\log N)R\le\mathcal C(P_1)+SX/e},\qquad
\mathcal C(P_1)=\int\log\frac{m_Aw_{y,j}(m_u)}{I^\beta_{Auj}}dP_1.
\]

这是同一个实际P1积分，保接受权和bin权；不能换成base平均MI或把k置为k0。S=0、SX=0、R=0按零流约定，不作0/0。channel可带符号，也精确包含 `log(m_A/m_u)`；该质量gap不能左右重复使用，两个KL之差须在同一可积log中解释。

## 原容量与一处已修范围

最低质量分配的原子安全质量轴恒等式、`∫q_u a_ell du<=lambda ell W`成立；它不是实际accepted incoming的列帽。原outgoing在 `1-a_h` 部分；incoming仍含真正父重复D(y)，其累计是ell X而非ell W。用incoming上界从outgoing正项中反向相减无效。单源RN `D(y)w/(ell q_u)` 中m_u相消，不能自称已经获得logmass drift。

独审提出 mainproof(4)的 beta_y* 必须支配全部实际bin，不能任取更短source长度。作者最终已明确本处专取 `t_y=rho_y(B_y)`、`beta_y*=rho_y|B_y`，该修订充分且公式正确。最终mainproof SHA使用下列新版本45a78f...。

旧R435 clipping熵作用于实际新源Delta g_i(z)，当前channel是接受后的旧源y后验；没有已证权重变换把两者等同。空间cell投影给cell KL加非负within-cell KL，丢后者是下界，不能用作所需上价。

## 费用、N依赖与未付项

固定delta、eps0，若sqrt(n)>=logN，可将retention的SX/e项在本比较除以sqrt(n)，用旧 `X<=A_nW` 计成 `S A_n/(e sqrt(n))W=O(S sqrt(n))W`。若delta经入口倍率回代依n变化，logN条件与依赖须原样保留；有限低维仅按固定参数旧粗界处理。不能将此条件项再作为一笔独立母账negative credit。

具体充分但未证的新几何比较仍为

\[
\mathcal C(P_1)\le\eta\sqrt n X+C_\eta n\log^A(n+2)W.
\]

只有证成它，才可与上述式及R458旧soft/return/rounding费用拼合。原R458比较仍保，母G0/BH/入口各自槽系数16Fhat、32Fhat、64Lambda0Fhat分别整乘、不相加，旧X/W槽不退款。本轮没有已证明的完整canonical余项W付款，也没有general closure或新的原剩余非空实例认证。

## 实际独立复现与范围

指定Python `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。在新目录

`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r459_audit_isolated_x7j39evx`

实际运行 geometry内嵌3代码块、mainproof_check、numeric，各一次：五份stdout均与冻结replay.json逐字节一致。numeric JSON仅实际诊断 `compute_index.seconds` 不同，其余字段完全相同。

- geometry：3个h值的同一native局部容量场，K=2而非原K、无原high/history；3个后验profile的6个SymPy身份/128-bit Arb方向，及3个有限B1 retention表。均不当完整history或一般channel价格证据。
- mainproof：最终总38 Fraction断言，stdout阶段为18、30、38，不合计为86或另加8。部分为有限matching-incidence而非native selector实现，核方向与分母。
- numeric：333 Fraction/SymPy/Arb检查、8个有限来源分区，含零w、partial w、零retention、比值2^20及非嵌套接口；7个正retention身份、零例只保零贡献。log-prime Fraction与SymPy精确身份、Arb256位方向区分清楚。massratio3/5等toy分区不是原strictmass样本，N=1等仅有限预算接口。没有据这些表否定native目标或证明原大维阶数。

资源耗时仅原实际运行记录，独审未重测RSS；没有MATLAB、代理、repo或PDF操作。PRE临时算术仅审查辅助，不计本轮归档新增覆盖。

## 最终10输入SHA256

审计自身不自绑定；独立PRE保留于原文件，不复制全文。白名单全部输入如下。

- `r459_main.md`: `7009360c774243e098e036953fb41710d4079599d10c61dc2c4b58867d06311f`
- `r459_information.md`: `4d334eb4455fb284a167a2f19a487a8c4aa4855929696c64fc1f8f04dc5c1362`
- `r459_geometry.md`: `81a4da990d1b095382dc703a7576216090ff9106154dce6ec6964d817055b80f`
- `r459_mainproof.md`: `45a78fbba0e2e23397bfd641b167bf0e2338352dc862589b02e77dab9e026a19`
- `r459_mainproof_check.py`: `a226e209ade4e5172d8add89dfcd524a2a73e80b15513416b9ecfa05fcf5a314`
- `r459_numeric.md`: `c2bab6fffc5fed2ffd7316244727f7060385fc7cadb7b16d354c57e67769af7a`
- `r459_numeric.py`: `6050e28cd6dd2194bf3cbe1cc5300b579cd344d80f5220d8561133942256bd3c`
- `r459_numeric.json`: `1bffd13b2280bf583e489a97f4b48475b8c511e0fe997d0bf5c75a09d9db5c7d`
- `r459_history.md`: `bd74d8483c033c5b95660c8cf8a3fbb2ed27df0eda68af8ddb2858b932e5b233`
- `r459_replay.json`: `e5d79cc63422ef2b60397ddbcc91f22bb13c875ff31ffbcddeccd33c31ac2c26`
