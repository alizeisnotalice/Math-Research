# R459：联合终端容量/Hall 旧结果索引

**已有的真实联合双端判据（R445）。** 在每个原记录 \(\xi=(e,A,y,z,t)\)，原路径联合子概率 \(\Gamma_\xi\le\mu_\xi\otimes\nu_\xi\) 的真实两边缘为 \(\eta_\xi,\zeta_\xi\)，等总质量 \(r_\xi\)；它们保留原历史筛选，未条件化归一。分析边容量是
\[
a_\xi(dw,dv)=\mathfrak c\,1_{N_\alpha}(w,v)\mu_\xi(dw)\nu_\xi(dv).
\]
最大可行部分匹配质量精确为 \(r_\xi-d_\xi\)，其中
\[
d_\xi=\sup_{B,T\subset E}\big[\eta_\xi(B)+\zeta_\xi(T)-r_\xi-a_\xi(B\times T)\big]_+.
\]
出处：[/tmp/r445_geometry.md:36-47,56-100](/tmp/r445_geometry.md)。该文给出由有限生成分割 max-flow/min-cut 逼近及可测实现的连续论证；R445 audit 明确警告单有弱 cut 只是 deficiency 下界，连续等式须有极限/紧性条件（[/tmp/r445_audit.md:83-98]）。匹配部分可按真实第二边缘拉回原流并付费，但 \(\int d_\xi d\Lambda\) 的几何预算、固定匹配比例均未证（[/tmp/r445_audit.md:3,79-89]）。故这是“任意两个端点集合的联合 cut + 边容量”判据，不是某一终端接收点的独立 vertex-capacity 公式。

**近似构造与后续容量类。** R446 用实际两边缘在 receiver 空间分格，同格构造
\(H_j=\eta|_{E_j}\otimes\zeta|_{E_j}/\max(e_j,f_j,MN/\mathfrak c)\)，满足 \(H\le\mathfrak c1_{near}\mu\otimes\nu\) 且两边缘受限；其损失精确为实际 cell-marginal imbalance 加该构造的 capacity underfill，仍不是最优 Hall deficiency 等式或来源预算（[/tmp/r446_geometry.md:7-38,40-74]）。R450 另有每父/方向共享体积 \(\kappa(w,v)\) 的容量价及全覆盖 iff 判据 \(\int H_A(v)L_A(a(v))dv\le m_A^2/q^2\)（[/tmp/r450_mainproof.md:37-60]）；它是列覆盖/共同父体积条件，不是双端联合 Hall，也未导出目标覆盖。

**与所问 \(c(u)\) 的差别。** 在检索到的上述确切段落中，没有看到已证的单端接收容量 \(c(u)=q\,m_u^{-1}\int f(y)\,\text{canonical-selector}(y,u)dy\) 被作为任一端可结算的 vertex cap，并据此得到双终端任一端结算的 Hall/min-cut 定理。R445 的容量是依赖 \((w,v)\) 的乘积参考测度乘 near 指示，cut 要同时选 \(B,T\)；R446 的格容量依赖两实际边缘；R450 的 \(\kappa\) 依赖 \((w,v)\) 且受共同父积分条件。不能把这些分别改写为上述单端 \(c(u)\)，也不能由它们声称该新容量已包含/已收费。此结论仅是指定旧记录的定位，不表示其他材料中不存在该机制。
