from fractions import Fraction as F
# Algebraic entropy-interface checks only, not a native-cube/history model.
checks=0
def ck(a):
    global checks
    assert a
    checks+=1
rho=[F(1),F(2),F(1),F(2)]
q=[F(1),F(4,3),F(1),F(4,3)]
ell=F(2)
w=[F(1),F(1,2),F(0),F(0)]
D=sum(a*b for a,b in zip(rho,q))
p=[a*b/D for a,b in zip(rho,q)]
kap=[a*b/ell for a,b in zip(rho,w)]
ck(sum(p)==1);ck(sum(kap)==1)
for pi,ki,qi,wi in zip(p,kap,q,w):
    ck(ki/pi==D*wi/(ell*qi))
for exponent in [4,8,12]:
    mass=[F(1),F(2),F(4),F(2**exponent)]
    # One accepted down edge has this exact multiplicative log-potential ratio.
    flow=F(3,7)
    out=[F(0),F(0),F(0),flow]
    inc=[flow,F(0),F(0),F(0)]
    ck(sum(out)==sum(inc)==flow)
    ck(mass[3]/mass[0]==2**exponent)
    # Reverse canonical target is absent, while forward target has positive mass.
    ck(kap[0]>0 and kap[3]==0)
    ck(D*w[0]/(ell*q[0])==kap[0]/p[0])
print(f"PASS {checks} exact Fraction assertions; scalar canonical RN and directed-flow interface only.")

# Source-capacity / CDF integration: finite matching-incidence algebra.
src=[F(1),F(2),F(1)]
capture=[[1,1,0],[0,1,1],[1,1,1]]
vol=[F(1,2),F(3,4),F(1,3)]
mass=[sum(f*c for f,c in zip(src,row)) for row in capture]
qv=[F(1),F(1),F(1)]
h=F(1,4)
mu=[v/m for v,m in zip(vol,mass)]
D=[sum(qv[j]*mu[j]*capture[j][x] for j in range(3)) for x in range(3)]
w=[[F(0)]*3 for _ in range(3)]
for x in range(3):
    left=min(h,sum(mu[j]*capture[j][x] for j in range(3)))
    for m in sorted(set(mass)):
        inds=[j for j in range(3) if mass[j]==m]
        block=sum(mu[j]*capture[j][x] for j in inds)
        part=min(left,block)
        frac=part/block if block else F(0)
        for j in inds:w[x][j]=frac
        left-=part
    ck(left==0)
alloc=[sum(src[x]*capture[j][x]*w[x][j] for x in range(3))/mass[j] for j in range(3)]
for threshold in [F(0),F(3),F(7,2),F(4)]:
    direct=sum(vol[j]*alloc[j] for j in range(3) if mass[j]<=threshold)
    cdf=sum(src[x]*min(h,sum(mu[j]*capture[j][x] for j in range(3) if mass[j]<=threshold)) for x in range(3))
    ck(direct==cdf)
    weighted=sum(vol[j]/mass[j]*sum(src[x]*D[x]*capture[j][x]*w[x][j] for x in range(3)) for j in range(3) if mass[j]<=threshold)
    weightedcdf=sum(src[x]*D[x]*min(h,sum(mu[j]*capture[j][x] for j in range(3) if mass[j]<=threshold)) for x in range(3))
    ck(weighted==weightedcdf)
ck(sum(vol[j]*alloc[j] for j in range(3))<=h*sum(src))
print(f"PASS total {checks} Fraction assertions; added matched-incidence CDF identities, not full native/history.")
# Same actual conditional source law in every KL factor; exact likelihood identities.
mA,mu,I=F(4096),F(3),F(2)
source=[F(1),F(2)]
ww=[F(1),F(1,2)]
actual=[F(1,4),F(3,4)]
pa=[a/mA for a in source] # other parent source mass is 4093
pu=[a/mu for a in source]
k0=[a*b/I for a,b in zip(source,ww)]
ck(sum(actual)==1);ck(sum(k0)==1)
for pp,aa,uu,kk,wi in zip(actual,pa,pu,k0,ww):
    ck(pp/aa==(pp/kk)*(mA*wi/I))
    ck(mA*wi/I==(mA/mu)*(mu*wi/I))
ck(mu*ww[0]/I>1)
ck(mu*ww[1]/I<1)
print(f"FINAL PASS {checks} Fraction assertions, including actual-law channel factorization.")
