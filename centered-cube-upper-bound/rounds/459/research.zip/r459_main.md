# 第459轮：实际单端共同参考与剩余共同捕获信息预算

完整一般根阶上界仍未证明。本轮直接研究R458留下的实际canonical父外联合流。建立了不损失真实接受权的单端信息预算，但未取得剩余channel项的全局源价；不能将本轮描述为中间段硬层已经闭合。

## 本轮准确对象与新增比较

固定同一完整原场和R458的分析参数，令P=Xi_can,out，R=P(1)，N=1+ceil(eps0/delta)。只把P推前到(A,y,u,j)，得P1，质量仍为R；原另一来源、旧阶段和路径依赖均通过真实投影保留，没有把原流换成独立参考。

每个有效bin的raw canonical概率是beta_(y,ell_j)/ell_j。安全部分质量Bsafe>=b ell_j，故原单份soft恰给b κsafe<=κraw。先积分另一端真实条件概率（总量<=1），得到逐bin帽
\[
(P_1)_j\le S\sigma(dA)\pi_A(dy)\kappa^{raw}_{y,j}(du).
\]
把无效bin补为共同墓地概率，形成总质量SX的单端参考B1，满足P1<=N B1。墓地不承载实际流；实际u处的参考旧源后验准确为
\[
k^0_{Auj}(dy)=\frac{f(y)c_A(y)c_u(y)w_{y,j}(m_u)}{I^\beta_{Auj}}\,dy,
\quad I^\beta_{Auj}=\int f c_Ac_uw_{y,j}(m_u).
\]
有效性与零点由同一分位核定义处理，不把不足ell_j的来源截短后仍称概率。该单端参考无需R457双端的1/zeta损失。

实际旧源后验k支持QA与Qu交集，原strict质量门给
\[
\int KL(k\Vert\pi_A)\,d(P_1)_{Auj}\ge2\sqrt n R.
\]
这是实际P1上的结论，不能施加到参考B1。相对参考后验的保留信息成本满足
\[
H_{ret}\le R\log N+R\log(SX/R)\le R\log N+SX/e.
\]
因此得到
\[
\boxed{(2\sqrt n-\log N)R\le\mathcal C(P_1)+SX/e,}
\quad
\mathcal C(P_1)=\int\log\frac{m_Aw_{y,j}(m_u)}{I^\beta_{Auj}}\,dP_1.
\]
完整证明、墓地后验、绝对可积性和零流约定见information附件；Astra独立核验记录在geometry附件。该式没有用reference均值替代实际接受权。

## 已支付的量与明确未付的量

当sqrt n>=log N时，上式的SX/e项除以sqrt n可用旧X<=A_nW计费，至多S A_n/(e sqrt n) W，单octave为根阶。核数N及其参数依赖保留；若入口回代使delta依赖n，必须另核logN条件。有限较小维数只按固定参数的旧线性上界处理。

尚须证明同一实际P1的几何比较
\[
\mathcal C(P_1)\le\eta\sqrt n X+C_\eta n\log^A(n+2)W.
\]
这条式子未证。本轮仅支付保留信息成本，没有支付这个实际共同捕获channel。

尤其，channel精确含有log(mA/mu)：
\[
\log\frac{m_A w}{I^\beta}=\log\frac{m_A}{m_u}+\log\frac{m_u w}{I^\beta}.
\]
其第二项在同一条件law下为KL(k||pi_u)−KL(k||k0)，应作为一个可积log处理。不能把质量落差既当作左侧收益，又在右侧删去或再使用一次。上述信息预算未自动降低原共同父几何的难度。

## 本轮决策与完整母账

最低质量分配确有真实容量∫q_u a_ell(u)du<=lambda ell W，但实际终端入量保留父累计D(y)，对应预算是ell X，不是ell W。故本轮停止仅靠行列容量或一源熵的路线：其似然比D(y)w/(ell q_u)中接收质量消去，不能产生严格质量下降的收益。这是同流公式核查，不是无目的反例排除。

旧R435空间clipping熵总量n log5 W作用于新源Delta g_i(z)，当前channel平均则作用于真实接受后的旧源y。条件化到空间单元只给下界并留下单元内KL，尚未得到所需上比较；不将两者混同。后续几何工作应直接针对实际I_beta与接受权，而不再重复分位压缩或声称有限核数已经给根价。

R458原比较仍为
\[
R_{433}\le[S\zeta+2S\varepsilon_0/s+2S\delta]X+R.
\]
本轮信息式只用于其R槽。原入口倍率64 Lambda0 Fhat、G0/BH各自16/32倍率、全部已付与未付X/W费用保留，不将三槽相加，不重复付同一个信息项，不宣称总吸收完成。

## 验证与交付范围

本轮使用64项D01规范核对真实正测度/参考/边缘，不移用未经核验的OT或路径强对偶。参考比较和信息恒等式由解析推导证明；有限Fraction、SymPy、Arb检查只核实际输入的代数、原子、零点与误差。实际检查数、命令和隔离复现见各附件及replay。原生局部字段、抽象来源分区与原完整history明确区分。

复用1名Astra high、2名Sol high、1名Sol medium、1名Luna medium。没有实际扣额数据，不估算模型成本。仅精简归档详细LaTeX文本与必要复现，不编译PDF，独审后本轮单独提交推送。

主代理已在新隔离目录实际运行geometry内嵌的3份代码、mainproof_check（最终总38项Fraction）和numeric（333项Fraction/SymPy/Arb，8个有限分区）。numeric结果除compute_index.seconds外逐字段一致，stdout及规范化散列保存在replay.json。几类计数不相加冒充原生几何样本数。未运行MATLAB；这些任务使用有理/符号/区间工具已足够。
