# R459 后验KL、channel与retention账的有限核验（冻结）

八个有限来源分区、333项Fraction/SymPy/Arb检查通过。七个正retention例的两个identity残差严格为0；零retention例只保留零贡献，不定义不存在的posterior。显式质量比2^20的两例表明：支付retention KL不自动降低channel，receiver KL可同步变化使质量增益完整留下。这里不是native cube/history实例或全局预算证明。

## 1. 输入与支持条件

每例给有理来源质量f_i>0、A_i,U_i∈{0,1}、cutoff权0≤w_i≤1、retention 0≤F_i≤1。完整质量及参考为

`m_A=Σf_iA_i`，`m_u=Σf_iU_i`，`Iβ=Σf_iA_iU_iw_i`，

`π_A(i)=f_iA_i/m_A`，`π_u(i)=f_iU_i/m_u`，`k0(i)=f_iA_iU_iw_i/Iβ`。

本轮Iβ均严格正。令α=Σk0F，α>0时k=k0F/α。w=0、A/U不相交或reference为0处k也必须为0；所有KL按0log0=0处理，未给zero-reference放正posterior。α0时不构造k，不伪造一个满足identity的概率。总Iβ=0的情况不在本轮正reference接口中。

初步2例：固定w1、retention分别全留及不等保留。边界3例：w含0、w含1/3的partial cutoff、全F0。扩大3例：质量比2^20的flat/concentrated对照，以及A、U非嵌套且m_A/m_u=3/5。完整有理输入在脚本/JSON；没有任意几何或原history资格声明。

## 2. 两个identity与channel

定义 `channel=E_k log(m_A w/Iβ)`。逐例精确核

`KL(k||π_A)=KL(k||k0)+channel`，

`channel=log(m_A/m_u)+KL(k||π_u)−KL(k||k0)`。

第一式直接来自k0/π_A=m_Aw/Iβ在k支持上的比值；第二式来自k0/π_u=m_uw/Iβ。脚本将所有正有理log分解成log prime的有理线性组合，Fraction残差字典严格空，再由SymPy核表达式差为0；不是浮点近似相等。

| 类别/例 | m_A/m_u | α | KL(k||k0) | channel |
|---|---:|---:|---|---|
| 初步：w1全留 | 2 | 1 | 0 | log2 |
| 初步：w1不等保留 | 2 | 3/4 | (5/3)log2−log3 | log2 |
| 边界：zero w | 9/4 | 1/2 | 0 | 2log3 |
| 边界：partial w | 12/5 | 1/2 | (1/3)log2 | 2log2−(2/3)log3 |
| 边界：F全0 | 2 | 0 | 不定义，质量贡献0 | 不定义，质量贡献0 |
| 扩大：大mass比flat | 2^20 | 1 | 0 | 20log2 |
| 扩大：大mass比concentrated | 2^20 | 1/2 | log2 | 20log2 |
| 扩大：非嵌套 | 3/5 | 5/7 | log7−log5−(2/5)log2 | −log7+(7/5)log2+log3 |

大mass比两例使用来源质量 `(1,1,2(2^20−1))`，A捕全部，u只捕前两项，w在前两项均1。此时k0=π_u；flat与集中k使KL(k||π_u)和KL(k||k0)分别同步从0增至log2，故channel严格不变。改变retention可改变保留总质量R，但不能据此说单位保留质量的channel质量项已经被支付或减少。

partial w例则确有 `channel<log(12/5)`，说明是否降低取决于两个KL的差与cutoff，不是retention KL单项越大就可独立减去多少。zero-w例甚至channel=log9大于单独massgain log(9/4)，reference支持变化的代价没有自动消失。

## 3. 明确定义的有限label/retention预算

每例显式取S=3/2、X=2，参考base量B=SX=3；这些只是有限概率接口输入，不是从native几何推得的原X。按N=1,2或3，用 `F_j(i)=F_i 1{i mod N=j}` 给disjoint label retention，所以Σ_jF_j=F≤1。记α_j=Σk0F_j，R=BΣα_j=Bα。

同时记录三种不同KL费用，避免同名混账：

- aggregate source retention：R KL(k||k0)；
- label-conditioned source费用：`H_source=BΣ_j α_j KL(k_j||k0)`；
- 更强的joint费用：`H_joint=R KL(P(j,i)||(1/N)k0(i))`，其中P=k0F_j/α。

逐例核 `H_joint=H_source+R KL(label posterior||uniform_N)`。因此若作者Hret只指source conditional费用，本轮还核了更强的joint上界；两者是比较关系，不是两笔额外加收费。

正R时，joint RN逐点为 `N F_j(i)/α≤N/α`，Fraction核最大值和该帽。随后精确/Arb核

`H_source≤H_joint≤RlogN+Rlog(SX/R)=Rlog(N/α)`。

N1全留、两个大mass比例joint预算取等；其余正R例差的Arb区间严格正。zero R以连续延拓将各质量费用置0。每例完整费用、joint/source分解、RN帽、budget与gap区间均在JSON。

特别在两大mass比对照中，joint retention预算均为3log2并取等，而channel仍为20log2/单位保留质量。这不是一般native反例；它仅明确预算identity没有自动删除质量项。

## 4. 标量最大值与误差控制

SymPy实际核 `φ(t)=tlog(1/t)` 的导数−logt−1、二阶导数−1/t，最大点t=e^-1处φ=1/e，及t↓0极限0。对每例正retention的t=α（含1），256-bit Arb核 `1/e−αlog(1/α)>0`；零例使用已核极限。这也给 `Rlog(SX/R)≤SX/e` 的有限接口标量核验，未替原几何证明一个可用X界。

所有质量、posterior、log prime系数与identity为Fraction/SymPy精确值；log数值、KL非负及预算strict gap使用Arb256bits完整区间。无浮点数学mask；JSON里的耗时是诊断浮点，不参与判断。

## 5. 复现与计算索引

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r459_numeric.py
```

实际Python3.12.14、SymPy1.14.0、python-flint0.9.0。333checks PASS；冻结测时运行.21秒，最大RSS73,465,856bytes。范围恰8例、三类，未作反例扫描、native/history或全局结论。没有repo/他人修改、git或agent。

只交付 `/tmp/r459_numeric.py`、`/tmp/r459_numeric.json`、`/tmp/r459_numeric.md`。JSON集成compute_index（输入、责任、解释器、命令、误差口径与完成状态）；脚本自含、同目录写结果，无旧文件运行依赖。完成停止。
