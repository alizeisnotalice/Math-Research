# R459：实际单端分位核的共同参考与信息预算

本附件由主代理整合独立预审推导；Astra随后独立核验。只证明显示的参考帽和信息预算，不证明实际channel的根阶几何价格。

## 1. 精确对象与不能省略的接受权

令 P=Xi_can,out 为R458实际保留的完整路径正分量，质量R。固定原场、h、delta、eps0，取共同上限

\[
N=1+\lceil\varepsilon_0/\delta\rceil,\quad
\ell_j=h+j\delta h,\quad j=0,\ldots,N-1.
\]

来源x的有效bin要求ell_j<=t_x=rho_x(B_x)。令w_xj=d beta_(x,ell_j)/d rho_x，raw概率kappa_xj=beta/ell_j。有效bin时该核只依来源/原场，不依原父或起点。无效bin不假装存在质量ell_j，下面补一个共同墓地。

R458实际P在保全部原record r的表示为

\[
 d\Pi^0(r)b\sum_{j,k}\omega_{r,y,j}\omega_{r,z,k}
 \kappa_{y,j}^{\bar z}(du)\kappa_{z,k}^{\bar y}(dv)
 1_{u,v\notin Q_A}.
\tag{1}
\]

这里omega=c Bsafe/s，sum omega<=1；a0是Pi0的真实静态RN，<=1。所有history只通过该实际正分和系数保留，不能改变omega或a0再称同P。

## 2. 一个比双端reference更便宜的合法单端帽

在实际非零bin上，beta支持原父 strict past，因此

\[
C_{y,j}(z):=\beta_{y,\ell_j}\{c_u(z)=1\}\le C_A(y,z)=(1-b)h,
\]
\[
B_{y,j}^{safe}=\ell_j-C_{y,j}(z)\ge b\ell_j,
\qquad b\kappa_{y,j}^{\bar z}\le\kappa_{y,j}.
\tag{2}
\]

这是单份soft对**单端canonical归一**的支配，不是单位双端乘积帽。

把实际P只推前到(A,y,u,j)，记P1，R不变。先在(1)对另一端积分并求和k，sum omega_zk<=1；再用(2)、a0 E[omega_yj]<=1和pi_A(dz)积分1，逐j得到

\[
\boxed{\quad
(P_1)_j(dA,dy,du)\le
 S\sigma(dA)\pi_A(dy)\kappa_{y,j}(du).\quad}
\tag{3}
\]

这一**上界**删除了部分接受信息，但下面所有channel费用仍以实际P1积分，不把它换成reference均值。原父外门/旧history没有在P1中删除；这里只为证明密度帽而正上放。原完整P始终保留，P1是费用所依变量的真实投影，不给参考路径或父授予历史。方向e可保留并分别用B_e，最后sum B_e=S；没有另乘两端或stage数。

定义概率核K_xj：有效bin取kappa_xj，无效或无active来源取共同墓地delta_partial。参考

\[
\mathcal B_1(dA,dy,du,j)=\frac S N\sigma(dA)\pi_A(dy)K_{y,j}(du),
\quad |\mathcal B_1|=SX,
\qquad P_1\le N\mathcal B_1.
\tag{4}
\]

墓地与实际E不交，实际P1没有墓地质量。该reference只用一端，避免另一来源无效bin引入归一问题；即使原另一端可用bin因z而变，(3)先把其整个条件质量积到<=1，仍正确。没有用双随机类比、也没有由row/column预算直接得W价格。

## 3. 正确的reference后验、零点及可积性

固定实际u∈E、j，置

\[
I^\beta_{Auj}=\int f(y)c_A(y)c_u(y)w_{y,j}(m_u)dy,
\qquad J_{Auj}=I^\beta_{Auj}/m_A.
\]

无效来源的w在此取零。对mathcalB1条件于(A,u,j)，其真正来源后验为

\[
k^0_{Auj}(dy)=\frac{c_u(y)w_{y,j}(m_u)}{J_{Auj}}\pi_A(dy).
\tag{5}
\]

墓地仅影响u=partial的后验，不污染实际u∈E公式。若不补墓地、而保双端subprob reference，则另一端有效bin总质量只是A的因子，在条件于(A,u,j)后仍会相消；不能让该因子偷偷依赖y或被筛过的实际z。

J=0处reference与P1均为零，不定义后验除零。w=0处实际P1也为零。0log0按极限取0。全field有m_->0、finite E与X，J<=1；reference积分的w|logw|和J|logJ|分别用<=1/e，分母ell_j m_u>=h m_-，得到log(k0/pi_A)在reference下绝对可积。再由P1<=N B1得到同一log在实际P1下绝对可积。这一步不需要f logf；只用完整L1 f与原qband/octave。S=0或R=0单独取零。

## 4. 必须在同一个实际测度上的质量gap与KL分解

令lambda=(P1)_(A,u,j)，k_Auj为P1的真实来源条件law。由P1绝对连续于reference，k<<k0<<pi_A，且它支持QA∩Qu。于是

\[
\int \mathrm{KL}(k_{Auj}\Vert\pi_A)\,d\lambda
\ge\int\log\frac{m_A}{I_{Au}}\,dP_1
\ge\int\log\frac{m_A}{m_u}\,dP_1
\ge2\sqrt n\,R.
\tag{6}
\]

I_Au=f(QA∩Qu)<=m_u是真实matching；P1继承同P的strict m_A>K²m_u，不能给reference的任意u免费赋此gap。即使仅保一个来源/终端，(6)已计全R，不需要再把另一端重复计价。

精确同流链式分解为

\[
\int\mathrm{KL}(k\Vert\pi_A)d\lambda
 =H_{ret}+\mathcal C(P_1),
\]
\[
H_{ret}=\int\mathrm{KL}(k\Vert k^0)d\lambda,\qquad
\mathcal C(P_1)=\int\log\frac{m_A w_{y,j}(m_u)}{I^\beta_{Auj}}\,dP_1.
\tag{7}
\]

这里C可能带符号，保实际接受权和实际bin权；不是未过滤base的平均mutual information。

由(4)，归一联合KL与条件KL链式法则给

\[
0\le H_{ret}\le R\log N+R\log\frac{SX}{R}
\le R\log N+SX/e.
\tag{8}
\]

在SX=0/R=0时按零流约定，不写0/0。因(7)cross项绝对可积、(8)有限，相关KL可按截断/链式极限合法处理，无无穷减无穷。故得到建设性可核比较

\[
\boxed{\quad(2\sqrt n-\log N)R
\le\mathcal C(P_1)+SX/e.\quad}
\tag{9}
\]

(9)不支付C，也不使row/column约束自动成为几何接收预算。

## 5. 该桥的真实费用与尚缺内容

原X=∫fD<=A_nW。固定delta,eps0时N固定，若sqrt n>=logN，则(9)右端的已付retention代价除以sqrt n，给至多

\[
\frac{S A_n}{e\sqrt n}W=O(S\sqrt n)W
\]

（单octave A_n<=1+nlog2）。有限低维可用R<=SX，常数依固定N和原参数；若母账回代令delta依n，则logN必须原样保留，不能称无条件维度一致。

一个具体充分但**未证**的共同父/终端比较是：在同一P1及其真实I_beta下证明

\[
\mathcal C(P_1)\le
 \eta\sqrt n X+C_\eta n\log^A(n+2)W.
\tag{10}
\]

这样(9)在上述大维给R<=eta X+O(C_eta sqrt n polylog)W，加回R458既有soft/return/rounding费用后，母槽仍须整乘16/32/64各自系数；不能再重复拿Hret作独立negative credit。真正未付者是(10)的加权overlap-channel项，不是retention项或单核row=ell。

仅用beta source列<=1、stationarity或核族有限，不能把实际C(P1)换成B1下均值；若改测度，需保密度/熵费用。log(mA/mu)的增益只能使用P1实际支持，不能直接放到较大reference或单个任意center列上。此处不提出已证的whole-budget结论，也不否定其他保门比较。

