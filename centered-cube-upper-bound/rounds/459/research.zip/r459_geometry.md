# R459：最低质量分配的真实容量，以及尚未付掉的父入量

结论：本轮没有证明新的根阶收据。只筛查一个具体机制——以 canonical 最低质量分配给出的真实中心容量结算原双终端流。该容量确实可加，但实际父入量的源加权比较仍缺；不把下面的精确投影或未知比较计为进展。

## 1. 唯一候选与可加资源

输入严格为 R458 (12)–(13) 的实际 Ξ_can，含 a′_{ij}、两份 whole-avoid 条件化、原 y,z、所有旧阶段与历史。两端 own-low、父外、m_u<m_A/K²。固定原场
\[
B_y=\{u:Z_u(y)\le h\},\qquad
\vartheta(u)=\frac1{m_u}\int_{Q_u}f(y)1_{B_y}(u)\,dy\in[0,1].\tag{1}
\]
这不是假设孩子上的来源law等于完整 π_u；(1)只是用完整 f 定义一个可审容量。匹配 m_u=f(Q_u) 与 Tonelli 给
\[
\int_E\vartheta(u)\,du
=\int f(y)\rho_y(B_y)\,dy
\le(1+\varepsilon_0)hW.\tag{2}
\]
所用旧低秩界 ρ_y(B_y)≤h+s/q 也包含没有 active 起点的来源。最低质量权的全序支持这一分配，但不是可把两个归一后的 safe 核排序的理由。

尝试的实际比较是：若原单端 incoming 中不能由 Cq·ϑ(u)du 接住的正量可以≤εX结算，则(2)立即给
\[
|\Xi_{\rm can}|\le\varepsilon X+C(1+\varepsilon_0)qhW
=\varepsilon X+C(1+\varepsilon_0)sW/\varepsilon_0.
\tag{3}
\]
C可含固定参数及允许的 log 幂。这是本次试图证明的有向接收容量比较；**未证明该超额界**。下面定位它在哪个原生积分上卡住，而不把(3)本身当新定理。

## 2. 保原接受权的入量式

只投影 Ξ_can 的一个实际终端，例如捕 y 排 z 的 u；另一端、bin与旧标签按其真实权积分。记 resulting (A,y,u) 测度为 Λ，终端边缘 j(u)du，故 ∫j=|Ξ_can|。

R457 单端 soft 抵消 b/a_y≤1、原总 Green 终端帽与原 S 合同给
\[
d\Lambda\le\frac S h\,
\sigma(dA)\pi_A(dy)\,
1_{m_A>K^2m_u}\,1_{u\notin Q_A}\,
1_{B_y}(u)\rho_y(du).\tag{4}
\]
没有 ζ^{-1}，也没有 bin 数因子。只有在这一步正上放才去掉另一端约束；不能据(4)声称上包络仍利用了 low-common、低 p 或 TG/Tloc。

为精确保留它们，令 d_act(A,y,u)∈[0,1] 为 Λ 对(4)参考的实际 RN 密度；零参考处取0。它来自原 a′与真实路径权的投影，不是自由选择的新乘子。定义
\[
\mathcal D_{\rm act}(y,u)=
\int_E\frac{c_A(y)}{R_A^n}
1_{m_A>K^2m_u}1_{u\notin Q_A}
 d_{\rm act}(A,y,u)\,dA.
\]
则完整匹配与 q_A/m_A=R_A^{-n} 给准确式
\[
\boxed{j(u)=\frac{S}{h m_u}
\int_{Q_u}f(y)1_{B_y}(u)\mathcal D_{\rm act}(y,u)\,dy.}\tag{5}
\]
这是实际原流的来源加权父累计量。没有将 a′删掉后伪称原历史仍参与比较。

原生 selector 中心包络仅给 0≤D_act≤A_n。因此由(2)与(5)，当前路线能证明的价格只是
\[
|\Xi_{\rm can}|\le S(1+\varepsilon_0)A_nW,\tag{6}
\]
同时仍有旧 |Ξ_can|≤SX。单 octave 下(6)是线性维数级，并非目标。

**唯一未消步骤：** 需要对(5)中的实际接受权加权父累计量给联合几何节省，使其在真实终端捕获来源上的平均从 A_n 降到 O(qh)=O(√n)，或把超过这一尺度的实际 j 质量另行吸收。canonical 排序只决定 1_{B_y}(u) 与低质量权，并未限制所有较重父 A 的这一累计量；不能由“每源行约 h、每中心来源列≤1”推出所需父入量帽。将 d_act 换成1只会提出更强未证命题，并丢掉当前最可能重要的原接受门。

这说明下一步应直接利用 d_act 内的原低共同捕获/实际双来源权，而不是继续优化分位族大小或重复 source-column 守恒。本稿未提出额外未付分支，也未改变母账。

## 3. 本机小型原生核验与局限

指定 Python 的 Fraction 实算了一个固定真实一维场的三个 h 值。完整 f 是两个宽 1/100 的均匀来源包，中心分别−1/2、1/2，总质量1、3。小接收中心区间 [−11/20,−9/20]、边长1，完全捕第一包；大接收中心区间 [−1/20,1/20]、边长2，完全捕两包。两个中心区间不交且均为正 Lebesgue 体积。故 m=(1,4)、q_A=(1,2)，完整匹配，octave成立；算术检查用 K=2，仅检验(1)–(2)，不认证原 K=e^{√n}、high-rank 或完整历史。

h=1/40、1/20 时 θ=(1,3/4)，两侧总量均7/40；h=1/10 时严格过去/停止等号给 θ=(1,1)，两侧均1/5。三例全部通过。没有用该有限检验支持未知的(3)。实际执行代码如下：

```python
from fractions import Fraction as F
f=[F(1),F(3)]; mass=[F(1),F(4)]
vol=[F(1,10),F(1,10)]; B=[[1,0],[1,1]]; K=F(2)
for h in [F(1,40),F(1,20),F(1,10)]:
 Z=[[sum((vol[v]/mass[v]*B[v][x] for v in range(2)
          if K*mass[v]<mass[u]),F(0))
     for x in range(2)] for u in range(2)]
 low=[[int(Z[u][x]<=h) for x in range(2)] for u in range(2)]
 theta=[sum((f[x]*B[u][x]*low[u][x] for x in range(2)),F(0))/mass[u]
        for u in range(2)]
 t=[sum((vol[u]/mass[u]*B[u][x]*low[u][x] for u in range(2)),F(0))
    for x in range(2)]
 lhs=sum((vol[u]*theta[u] for u in range(2)),F(0))
 rhs=sum((f[x]*t[x] for x in range(2)),F(0))
 assert lhs==rhs and all(0<=x<=1 for x in theta)
 print(h,theta,lhs)
```

## 4. 同轮追加：单端参考的独立核查

本节是主代理指定的新后验路线，不延长前述 priority 尝试。记 R=|Ξ_can,out|，P₁为其(A,y,u,j)单端投影，保留真实 bin j。N=1+ceil(ε₀/δ) 是 R458 的全局 bin 数。以下只是核验实际参考与信息费用；不宣称 channel 几何价已付。

原 finite-bin 条件权 γ_{ξ,y,j}≤1，另一端 Σ_kγ_{ξ,z,k}≤1。记 ℓ_j=h+jδh，B_safe=β_{y,ℓ_j}{c_u(z)=0}。每个实际非零 bin 在父过去内，故
\[
 B_{\rm safe}\ge\ell_j-C_A(y,z)\ge b\ell_j,
 \qquad b\kappa_{y,j}^{z}\le\kappa^{\rm raw}_{y,j}:=\beta_{y,\ell_j}/\ell_j.
\tag{7}
\]
因此原记录积分和父外正删后，逐 j 的准确支配为
\[
 P_{1,j}\le S\sigma(dA)\pi_A(dy)\kappa^{\rm raw}_{y,j}(du).
\tag{8}
\]
没有假定 bin 权与来源独立。对无效 bin（例如 ℓ_j>ρ_y(B_y)），把 raw 核定义成墓地点概率 δ_∂；实际 P₁ 在这些 bin 为零。定义带 j 标签的有限参考
\[
\mathcal B_1=\frac S N\sigma(dA)\pi_A(dy)
 \sum_{j=0}^{N-1}\delta_j\otimes K^{\rm raw}_{y,j}(du).
\tag{9}
\]
则 |B₁|=SX，P₁≤N B₁。参考没有原历史资格；只有 P₁ 保留原门。

对 F=(A,u,j) 分解。有限有效纤维上 B₁ 的旧来源后验正是
\[
 k_0(dy)=\frac{f(y)c_A(y)c_u(y)w_{y,j}(m_u)}{I_{Au}^{\beta}}\,dy,
 \quad I_{Au}^{\beta}=\int f(y)c_A(y)c_u(y)w_{y,j}(m_u)\,dy.
\tag{10}
\]
因 ℓ_jm_u 在该纤维为常数，不出现在 k₀ 中。记实际后验 k、P_F 为实际纤维质量，H_ret=∫P_F KL(k||k₀)。非归一测度的 log-sum/data processing 给
\[
\begin{aligned}
H_{\rm ret}
&=\int P_1\log\frac{dP_1}{d\mathcal B_1}
 -\int P_F\log\frac{dP_F}{d(\mathcal B_1)_F}\\
&\le R\log N+R\log(SX/R)
\le R\log N+SX/e.
\end{aligned}\tag{11}
\]
R=0 取零；SX=0 时所有实际流为零。两个相对密度均≤N，其熵负部由有限参考质量控制，故(11)没有∞−∞。这是原接受/保留的信息费用，不是来源几何 channel 的费用。

## 5. 支持熵、真实 channel 与未消的质量对数

在同一纤维，实际 k 支持 Q_A∩Q_u，且实际质量门 m_A>K²m_u。用完整 π_u=f c_u/m_u，精确有
\[
\mathrm{KL}(k\|\pi_A)
=\log(m_A/m_u)+\mathrm{KL}(k\|\pi_u)
\ge 2\sqrt n.
\tag{12}
\]
定义真实 channel 积分
\[
H_{\rm ch}=\int P_1\log\frac{m_Aw_{y,j}(m_u)}{I_{Au}^{\beta}}.
\tag{13}
\]
以同一 P₁ 的对数定义，链式等式为
\[
H_{\rm parent}=H_{\rm ret}+H_{\rm ch},\qquad
(2\sqrt n-\log N)R\le H_{\rm ch}+SX/e.
\tag{14}
\]
若 H_parent 无限，(14)只给扩展实数意义下的平凡上界。由于(11)有限，(13)负部有限，(14)不作未定义的∞−∞。

更明确地，在同一纤维的同一积分上，
\[
\log\frac{m_Aw_{y,j}}{I_{Au}^{\beta}}
=\log(m_A/m_u)+
\log\frac{m_uw_{y,j}}{I_{Au}^{\beta}},
\]
后项的实际均值为 KL(k||π_u)−KL(k||k₀)，有限性不足时应保留左边单一对数，不能形式相减两个无穷。这说明 **支持 KL 下界没有再创造一份质量落差信用**：H_ret+H_ch 本来就等于原 log(m_A/m_u) 加孩子后验 KL。另一方面它也没有否定路线；(11)确将可控的 retention 从真正 channel 中分离出来。

唯一需要的新几何预算现在是对(13)本身给 O(n polylog(n)W)+o(√n)X，而不是再次使用(12)。k一般不等于k₀；在实际 k 下，channel 甚至可小于 log(m_A/m_u)，故也不能把 k₀ 的 Gibbs 均值性质移植过来。只删 w 会留下更强的捕获小质量对数 log(m_A/Iβ)，目前没有它的真实中心预算。本轮未取得该预算，既不追加 W 收据，也不将(14)宣称原目标已降低难度。

## 6. 追加计算范围

指定 Python 实跑了3个有限后验 profile 的6个 SymPy 精确对数恒等式，并用128-bit Arb核数值：channel/gap分别约(4.60517,4.60517)、(4.97137,4.60517)、(3.06937,4.39445)。最后一例严格 channel<gap，说明必须使用实际 k 而非 k₀；这是代数接口校验，不是原生几何或原历史反例。另3个有限 B₁ 分解以 N=2,3,1 核(11)，H_ret 上界分别约0.734875、0.895880、0.328810，实际约0.249329、0.441507、0.213681，全部 Arb严格通过。没有新增几何扫描。

后验恒等式的实际执行代码：

```python
import sympy as sp
from flint import arb,ctx
ctx.prec=128
Q=sp.Rational
cases=[(Q(100),[Q(1,4),Q(3,4)],[Q(1),Q(1)],[Q(1,4),Q(3,4)]),
       (Q(100),[Q(1,4),Q(1,4),Q(1,2)],[Q(1),Q(1,3),Q(0)],
        [Q(1,3),Q(2,3),Q(0)]),
       (Q(81),[Q(1,8),Q(3,8),Q(1,4),Q(1,4)],
        [Q(1,100),Q(1),Q(0),Q(0)],[Q(1,2),Q(1,2),Q(0),Q(0)])]
for num,(ratio,pu,w,k) in enumerate(cases,1):
 I=sum(a*b for a,b in zip(pu,w));k0=[a*b/I for a,b in zip(pu,w)]
 ret=sum(a*sp.log(a/b) for a,b in zip(k,k0) if a)
 child=sum(a*sp.log(a/b) for a,b in zip(k,pu) if a)
 channel=sum(a*sp.log(ratio*b/I) for a,b in zip(k,w) if a)
 parent=sum(a*sp.log(a/(b/ratio)) for a,b in zip(k,pu) if a)
 assert sp.simplify(sp.expand_log(parent-ret-channel,force=True))==0
 assert sp.simplify(sp.expand_log(parent-sp.log(ratio)-child,force=True))==0
 def A(x):return arb(int(sp.numer(x)))/arb(int(sp.denom(x)))
 ch=sum((A(a)*A(ratio*b/I).log() for a,b in zip(k,w) if a),arb(0))
 print(num,ch,A(ratio).log())
 if num==1:assert sp.simplify(channel-sp.log(ratio))==0
 if num==3:assert ch<A(ratio).log()
```

有限 B₁ retention 校验的实际执行代码：

```python
from fractions import Fraction as F
from flint import arb,ctx
ctx.prec=128
cases=[(2,[[F(1,10),F(2,10)],[F(3,10),F(4,10)]],
        [[F(2),F(0)],[F(1),F(1,2)]]),
       (3,[[F(1,5),F(1,10)],[F(2,5),F(3,10)]],
        [[F(0),F(3)],[F(1,2),F(0)]]),
       (1,[[F(1,4)]*2]*2,[[F(1,10),F(1)],[F(1),F(1,10)]])]
def A(x):return arb(x.numerator)/arb(x.denominator)
for N,B,d in cases:
 P=[[B[i][j]*d[i][j] for j in range(2)] for i in range(2)]
 R=sum(map(sum,P),F(0));T=sum(map(sum,B),F(0))
 assert T==1 and R<=T and all(0<=x<=N for row in d for x in row)
 H=arb(0)
 for b,p in zip(B,P):
  for bj,pj in zip(b,p):
   if pj:H+=A(pj)*A(pj*sum(b)/(bj*sum(p))).log()
 upper=A(R)*(arb(N).log()+A(T/R).log())
 assert H>=0 and H<=upper
 print(N,R,H,upper)
```
