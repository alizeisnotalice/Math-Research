# R459 — canonical allocation capacity versus the actual parent load

The single candidate examined here is to charge the mass-decreasing accepted terminal flow to the native canonical allocation capacity. That capacity has a genuine root-scale total. The calculation below identifies precisely the extra parent load that remains; it does not establish the full R458 remainder bound.

## 1. A finite native allocation budget, including atoms

Freeze the original full \(f\), actual centers and side selector, \(m_u=f(Q_u)\), \(q\le q_u=m_u/R_u^n\le\lambda\), and \(\rho_y(du)=c_u(y)du/m_u\). Put
\[
F_t(y)=\rho_y\{m_u\le t\},\qquad
D(y)=\int q_A\rho_y(dA)=\int c_A(y)R_A^{-n}dA\le A_n .
\]
For a fixed \(\ell>0\), use the lowest-mass submeasure
\(\beta_{y,\ell}\) of total \(\min(\ell,J(y))\). Its cutoff weight is \(w_{y,\ell}(m)\in[0,1]\), constant on a mass atom with the exact partial fraction. Define
\[
a_\ell(u)=\int\pi_u(dy)w_{y,\ell}(m_u),\quad
C_\ell(t)=\int f(y)\min(F_t(y),\ell)\,dy .
\]
Then, as measures on the mass axis,
\[
dC_\ell(t)=(m_\#(a_\ell(u)\,du))(dt),\qquad
C_\ell(\infty)\le\ell W,\qquad
\int q_u a_\ell(u)\,du\le\lambda\ell W. \tag{1}
\]
Indeed \(\beta_{y,\ell}\{m_u\le t\}=\min(F_t(y),\ell)\), also at a crossing atom. Tonelli and \(f(y)c_u(y)/m_u=\pi_u(dy)/dy\) prove (1). No density bound on \(f\) is used.

The same statement holds with a measurable source-dependent length \(t_y\le(1+\varepsilon_0)h\): writing \(\beta_y^*=\beta_{y,t_y}\) and \(a_*(u)=\int\pi_u w_y^*(m_u)\),
\[
\int q_u a_*(u)\,du\le\lambda(1+\varepsilon_0)hW. \tag{2}
\]
Thus the proposed allocation reference itself has the desired root price.

## 2. What the actual R458 acceptance permits

Let \(\mathcal F(dA,du)\) be the old-terminal projection of the actual retained \(\Xi_{\rm can}\) in R458 (12)–(13), with all its labels and father-outside restriction. Its mass is \(R_{\rm can}\); on its support \(m_A>K^2m_u\). This is a projection of the original accepted flow, not an arbitrarily filled transport plan.

There are two rigorous comparisons.

First, the original high-rank source gate puts the lowest \(h\) quantile strictly below the original parent mass, so \(w_{y,h}(m_A)=0\) on every contributing old-source record. Since the parent/source projection is dominated by \(S\sigma\pi_A\),
\[
\mathcal F_{\rm out}(dA)\le S q_A[1-a_h(A)]\,dA. \tag{3}
\]
The actual outgoing flow lies in the **unallocated** part of the native reference. Thus replacing this deficit by the paid \(a_h\) would reverse its role.

Second, for the incoming comparison specifically take \(t_y=\rho_y(B_y)\) and \(\beta_y^*=\rho_y|_{B_y}\), so every actual bin measure is dominated by \(\beta_y^*\). This comparison is not asserted for an arbitrarily shorter source-dependent length. Retaining the conditioning factors gives
\[
\mathcal F_{\rm in}(du)
 \le {S\over h}\int f(y)D(y)\,\beta_y^*(du)\,dy
 ={S\over h}\left[\int\pi_u(dy)D(y)w_y^*(m_u)\right]du. \tag{4}
\]
For clarity, this follows before integrating labels. The other endpoint's retained conditional mass is at most one; for the old endpoint the original soft satisfies \(b/s_y\le1\). The remaining killed coefficient sum is at most \(1/h\), and every bin measure is at most \(\beta_y^*\). Finally use the original \(\Pi^0\) static cap \(S\sigma\pi_A^2\). The second conditioning denominator has therefore been integrated with its true conditional probability, not silently bounded by one. All further positive restrictions can be retained on the left.

The factor \(D(y)\) in (4) is the genuine multiplicity of accepted possible parents. It is not present in (1). Its corresponding fixed-length cumulative reference is exactly
\[
C_\ell^D(t)=\int f(y)D(y)\min(F_t(y),\ell)\,dy,\qquad
C_\ell^D(\infty)\le\ell X,\quad X=\int fD. \tag{5}
\]
For variable \(t_y\), the right side is at most \((1+\varepsilon_0)hX\). Consequently (4) currently gives only \(S(1+\varepsilon_0)X\), or the coarse linear source price \(S(1+\varepsilon_0)A_nW\). The source-column inequality for \(\beta\) alone does not erase the multiplier \(D\).

This is the precise issue for a positive depletion argument: the canonical allocation is fixed by the original field, and repeated original parents do not deplete it. A proof must control the actual excess of the accepted incoming column over the reference \(q_u a_*(u)du\), using its original correlated weights. Equations (3)–(5) give neither such depletion nor a favorable signed comparison. They do not justify charging each accepted parent once to the same unchanged allocation.

## 3. Why the strict logarithmic gap does not repair this automatically

For the actual \(\mathcal F\), finite octave mass bounds make the following identity legitimate:
\[
2\sqrt n\,R_{\rm can}
 \le\int\log(m_A/m_u)\,d\mathcal F
 =\int\log(m/m_0)\,
       d(\mathcal F_{\rm out}-\mathcal F_{\rm in}),\quad m_0=qa^n. \tag{6}
\]
The two marginals have equal total mass, but are not balanced at each receiver. Inserting (3) in the positive term and subtracting an *upper* bound such as (4) is invalid. Dropping the negative term only restores the old \(O(nX)\) log price.

The natural one-source entropy also does not contain this gap. For
\[
p_y(dA)=q_A\rho_y(dA)/D(y),\qquad
\kappa_{y,\ell}=\beta_{y,\ell}/\ell
\]
on a source with \(J(y)\ge\ell\), its exact derivative is
\[
{d\kappa_{y,\ell}\over dp_y}(u)
 ={D(y)w_{y,\ell}(m_u)\over\ell q_u}. \tag{7}
\]
The mass \(m_u\) cancels. Although
\[
\int fD\,{\rm KL}(\kappa_{y,\ell}\Vert p_y)
 \le A_n\log_+\!\left({A_n\over\ell q}\right)W
\]
on the eligible source set, this reference entropy is not a lower bound for the log-mass drift (6). Such a comparison would require an additional actual joint geometric estimate. It is not supplied by canonical row mass, source-column capacity, or the original stage entropy contract R435.

## 4. The actual conditional-source KL gain and its stage interface

There is a different, valid entropy gain that (7) does not rule out. Augment the actual accepted measure by its bin \(j\), project to \((A,u,j,y)\), and condition on \((A,u,j)\). Denote the actual conditional source law by \(P_{Auj}\). It is supported on \(Q_A\cap Q_u\), so
\[
{\rm KL}(P_{Auj}\Vert\pi_A)
 =\log(m_A/m_u)+{\rm KL}(P_{Auj}\Vert\pi_u)
 \ge2\sqrt n. \tag{8}
\]
The conditional law is the actual one; neither posterior on the right generates new history.

Write
\[
I^\beta_{Au,j}=\int f(y)c_A(y)c_u(y)w_{y,\ell_j}(m_u)\,dy,\qquad
k^0_{Au,j}(dy)=\frac{f(y)c_A(y)c_u(y)w_{y,\ell_j}(m_u)}
 {I^\beta_{Au,j}}\,dy .
\]
Zero \(I^\beta\) fibers carry no accepted bin mass. The exact channel term in the retention/reference split is
\[
\log\frac{m_Aw_{y,\ell_j}(m_u)}{I^\beta_{Au,j}}
 =\log\frac{m_A}{m_u}
  +\log\frac{m_uw_{y,\ell_j}(m_u)}{I^\beta_{Au,j}}. \tag{9}
\]
Its actual conditional average is the log-mass gap plus
\[
{\rm KL}(P_{Auj}\Vert\pi_u)-{\rm KL}(P_{Auj}\Vert k^0_{Au,j}). \tag{10}
\]
The difference in (10) means the single integral of the second logarithm in (9); it is not permission to subtract two infinite entropies. The pointwise likelihood identity can always first be used on finite truncations. Any global use must retain the available integrability/retention estimates. This note does not independently certify the separate retention-entropy price proposed in the main audit.

Thus (8) is a real joint entropy gain, unlike the one-source comparison (7). But its mass gap remains inside the channel (9). The second term can have either sign, and it must be kept together with the retention term.

The precise R435 stage-budget issue is as follows. Its proved entropy dissipation is
\(\sum_i\int\Delta g_i(z)\eta_i(z)\,dz\le n\log5\,W\), on the **new source** \(z\), with its actual clipping increments. In contrast, (9) is averaged over the accepted conditional **old source** \(y\), given \(A,u,j\); its law includes the original current load, the other source, conditional-avoid denominators, and the actual bin occupation coefficient. No proved identity turns these weights into \(\Delta g_i(z)\eta_i(z)\).

Even projecting onto the R435 spatial cells does not give the required upper bound. The entropy chain rule gives a cell-level KL **plus** nonnegative within-cell conditional KL. Discarding the latter provides a lower bound, whereas paying (9) requires an upper bound with the original weights. Canonical mass ordering does not bound this within-cell term or its accepted parent multiplicity. Treating \(P_{Auj}\) as \(k^0_{Au,j}\) would delete exactly that original acceptance information.

**Decision.** The allocation budget (1)–(2), the same-flow comparisons (3)–(5), and the true gain (8) are valid. The candidate has not supplied the needed upper estimate on the actual weighted channel (9) from the existing clipping entropy. This is the specific remaining comparison; no additional gate or mother-ledger receipt is asserted.

## 5. Local verification

The local math Python actually ran r459_mainproof_check.py: **38 exact Fraction assertions**. They verify (7), equal-mass directed-flow accounting, and the two cumulative identities (1) and (5), including a partial atom shared by receivers. Eight further assertions check the same-law likelihood identities (8)–(10), with both signs present in the second logarithm of (9). The latter fixture has full-source matching masses computed from its incidence table, but is only finite matching-incidence algebra, not a native continuous cube/history realization. The checks are evidence for directions and normalizations; the integral proofs above are analytic.
