#!/usr/bin/env python3
"""Eight finite source-partition posterior/channel audits; not native history."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,platform,time
import sympy as s
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0;started=time.perf_counter()
def ck(x):
 global checks
 assert x
 checks+=1
def ar(x):return arb(x.numerator)/x.denominator
# Exact linear combinations of log primes; all logarithm arguments are positive rational.
def add(*items):
 out={}
 for v in items:
  for p,c in v.items():out[p]=out.get(p,Q(0))+c
 return {p:c for p,c in out.items() if c}
def scale(c,v):return {p:c*x for p,x in v.items() if c*x}
def logq(x):
 ck(x>0);out={}
 for integer,sign in ((x.numerator,1),(x.denominator,-1)):
  for p,e in s.factorint(integer).items():out[int(p)]=out.get(int(p),Q(0))+sign*int(e)
 return {p:Q(c) for p,c in out.items() if c}
def kl(p,q):
 out={}
 for a,b in zip(p,q):
  if a:ck(b>0);out=add(out,scale(a,logq(a/b)))
 return out
def expr(v):return s.Add(*(s.Rational(c.numerator,c.denominator)*s.log(p) for p,c in sorted(v.items())))
def val(v):return sum((ar(c)*arb(p).log() for p,c in v.items()),arb(0))
def nonnegative(v):
 if not v:return True
 return val(v)>0
DATA=[
 dict(stage='initial',name='constant_w_no_retention',f=['1','1','2'],A=[1,1,1],U=[1,1,0],w=['1','1','0'],F=['1','1','0'],N=1),
 dict(stage='initial',name='constant_w_unequal_retention',f=['1','1','2'],A=[1,1,1],U=[1,1,0],w=['1','1','0'],F=['1','1/2','0'],N=1),
 dict(stage='boundary',name='zero_weight_has_zero_posterior',f=['1','3','5'],A=[1,1,1],U=[1,1,0],w=['1','0','0'],F=['1/2','1','0'],N=2),
 dict(stage='boundary',name='partial_cutoff',f=['2','3','7'],A=[1,1,1],U=[1,1,0],w=['1','1/3','0'],F=['1/4','1','0'],N=2),
 dict(stage='boundary',name='zero_retained_mass',f=['1','1','2'],A=[1,1,1],U=[1,1,0],w=['1','1','0'],F=['0','0','0'],N=2),
 dict(stage='expanded',name='large_mass_ratio_flat',f=['1','1',str(2*(2**20-1))],A=[1,1,1],U=[1,1,0],w=['1','1','0'],F=['1','1','0'],N=2),
 dict(stage='expanded',name='large_mass_ratio_concentrated',f=['1','1',str(2*(2**20-1))],A=[1,1,1],U=[1,1,0],w=['1','1','0'],F=['1','0','0'],N=2),
 dict(stage='expanded',name='non_nested_parent_receiver',f=['1','2','3','5'],A=[1,1,1,0],U=[0,1,1,1],w=['0','1','1/2','0'],F=['0','1/2','1','0'],N=3),
]
S=Q(3,2);X=Q(2);BASE=S*X
results=[]
for spec in DATA:
 f,w,F=([Q(x) for x in spec[key]] for key in ('f','w','F'));A,U=spec['A'],spec['U'];N=spec['N']
 ck(all(x>0 for x in f) and all(0<=x<=1 for x in w+F))
 mA=sum((x*a for x,a in zip(f,A)),Q(0));mu=sum((x*u for x,u in zip(f,U)),Q(0))
 I=sum((x*a*u*z for x,a,u,z in zip(f,A,U,w)),Q(0));ck(I>0 and mA>0 and mu>0)
 piA=[x*a/mA for x,a in zip(f,A)];piu=[x*u/mu for x,u in zip(f,U)]
 k0=[x*a*u*z/I for x,a,u,z in zip(f,A,U,w)]
 alpha=sum((p*z for p,z in zip(k0,F)),Q(0));R=BASE*alpha
 ck(sum(k0)==1 and all(not p or w[i]>0 for i,p in enumerate(k0)))
 labels=[[z if i%N==j else Q(0) for i,z in enumerate(F)] for j in range(N)]
 ck(all(sum(row[i] for row in labels)==F[i]<=1 for i in range(len(f))))
 aj=[sum((p*z for p,z in zip(k0,row)),Q(0)) for row in labels];ck(sum(aj)==alpha)
 sourceKL={}
 for row,a in zip(labels,aj):
  if a:
   posterior=[p*z/a for p,z in zip(k0,row)]
   sourceKL=add(sourceKL,scale(BASE*a,kl(posterior,k0)))
 record=dict(**spec,mA=mA,mu=mu,mass_ratio=mA/mu,I_beta=I,piA=piA,piu=piu,k0=k0,
   alpha=alpha,S=S,X=X,SX=BASE,R=R,label_retention=labels,label_retained_mass=aj)
 if alpha:
  k=[p*z/alpha for p,z in zip(k0,F)]
  KA=kl(k,piA);KU=kl(k,piu);K0=kl(k,k0)
  channel={}
  for p,z in zip(k,w):
   if p:channel=add(channel,scale(p,logq(mA*z/I)))
  residual1=add(KA,scale(-1,K0),scale(-1,channel))
  residual2=add(channel,scale(-1,logq(mA/mu)),scale(-1,KU),K0)
  ck(not residual1 and not residual2)
  ck(s.simplify(expr(KA)-expr(K0)-expr(channel))==0)
  ck(s.simplify(expr(channel)-expr(logq(mA/mu))-expr(KU)+expr(K0))==0)
  ck(nonnegative(KA) and nonnegative(KU) and nonnegative(K0))
  joint_p=[k0[i]*labels[j][i]/alpha for j in range(N) for i in range(len(f))]
  joint_q=[k0[i]/N for j in range(N) for i in range(len(f))]
  peak_joint_RN=max(p/q for p,q in zip(joint_p,joint_q) if p)
  ck(peak_joint_RN<=Q(N)/alpha)
  jointKL=scale(R,kl(joint_p,joint_q))
  label_p=[a/alpha for a in aj];label_ref=[Q(1,N)]*N
  label_cost=scale(R,kl(label_p,label_ref))
  ck(not add(jointKL,scale(-1,sourceKL),scale(-1,label_cost)))
  ck(nonnegative(jointKL) and nonnegative(sourceKL) and nonnegative(label_cost))
  budget=scale(R,logq(Q(N)/alpha))
  budget_split=add(scale(R,logq(Q(N))),scale(R,logq(BASE/R)))
  ck(not add(budget,scale(-1,budget_split)))
  gap=add(budget,scale(-1,jointKL));ck(nonnegative(gap))
  ck(nonnegative(add(sourceKL,scale(-R,K0))))
  scalar=scale(alpha,logq(1/alpha));ck(arb(-1).exp()-val(scalar)>0)
  record.update(status='IDENTITIES_DEFINED',k=k,KL_parent=str(expr(KA)),KL_receiver=str(expr(KU)),KL_retention=str(expr(K0)),
   KL_retention_interval=str(val(K0)),channel=str(expr(channel)),channel_interval=str(val(channel)),
   mass_gain_log=str(expr(logq(mA/mu))),mass_gain_interval=str(val(logq(mA/mu))),
   identity_1_residual='0',identity_2_residual='0',aggregate_retention_cost=str(expr(scale(R,K0))),
   peak_joint_RN=peak_joint_RN,joint_RN_cap=Q(N)/alpha,Hret_source=str(expr(sourceKL)),Hret_source_interval=str(val(sourceKL)),
   Hret_joint=str(expr(jointKL)),Hret_joint_interval=str(val(jointKL)),label_KL_cost=str(expr(label_cost)),
   retention_budget=str(expr(budget)),retention_budget_interval=str(val(budget)),budget_gap_interval=str(val(gap)),
   budget_equality=not gap,scalar_alpha_log_inverse_interval=str(val(scalar)),
   scalar_one_over_e_gap_interval=str(arb(-1).exp()-val(scalar)))
 else:
  ck(R==0 and not sourceKL)
  record.update(status='ZERO_RETENTION_NO_POSTERIOR_K',k=None,channel=None,identity_1_residual=None,identity_2_residual=None,
   Hret_source='0',Hret_joint='0',retention_budget='0',budget_gap_interval='0',scalar_alpha_log_inverse_interval='0')
 results.append(record)
# The two large mass-gain cases have exactly unchanged channel despite changed retention KL.
ck(results[5]['mass_ratio']==2**20 and results[6]['mass_ratio']==2**20)
ck(results[5]['channel']==results[6]['channel']=='20*log(2)')
ck(results[5]['KL_retention']=='0' and results[6]['KL_retention']=='log(2)')
t=s.symbols('t',positive=True);phi=t*s.log(1/t)
ck(s.simplify(s.diff(phi,t)+s.log(t)+1)==0)
ck(s.simplify(s.diff(phi,t,2)+1/t)==0)
ck(s.simplify(phi.subs(t,s.exp(-1))-s.exp(-1))==0)
ck(s.limit(phi,t,0,dir='+')==0)
out=dict(scope='eight finite probability/source-partition audits only, no native geometry/original history/global budget proof',
 executable=sys.executable,python=platform.python_version(),sympy=s.__version__,python_flint=flint.__version__,arb_bits=ctx.prec,checks=checks,
 scalar_bound='t*log(1/t)<=1/e for t>0, extended 0 at t=0; symbolic concavity/max point and Arb at retained alpha',
 compute_index=dict(input='eight rational f/A/U/w/F/N partitions embedded in script',responsibility='numeric only; no scan/agents/repo edits',
  command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r459_numeric.py',status='complete and frozen',
  arithmetic='Fraction + SymPy exact log-prime identities; Arb256 bounds; only runtime is floating diagnostic',seconds=time.perf_counter()-started),
 cases=results)
def enc(x):
 if isinstance(x,Q):return str(x)
 raise TypeError(type(x).__name__)
(ROOT/'r459_numeric.json').write_text(json.dumps(out,default=enc,indent=2)+'\n')
print('executable:',sys.executable,'Python:',platform.python_version(),'SymPy:',s.__version__,'python-flint:',flint.__version__,'Arb bits:',ctx.prec)
for r in results:
 print(r['stage'],r['name'],'massratio=',r['mass_ratio'],'alpha=',r['alpha'],'R=',r['R'],'status=',r['status'])
 if r['alpha']:print(' channel=',r['channel'],'KLret=',r['KL_retention'],'joint budget equality=',r['budget_equality'],'gap=',r['budget_gap_interval'])
print('PASS',checks,'exact/symbolic/Arb checks; 8 finite partitions, no scan')
