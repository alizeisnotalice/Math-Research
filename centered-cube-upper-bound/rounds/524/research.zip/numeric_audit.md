# R524 逐类型两动作 QP 独审

审核 /tmp/r524_numeric.py、json、md。结论：**通过所声明的三个原正δ周期 whole-highslow、逐类型 oldR/V 问题；未发现阻断性错误。** 不认证连续半径、原有限边界 oracle、一般L1最优性，亦不对本轮PRE几何桥作成果认证。

## 1. 源柱与变量范围：通过

原n/q、δ、first-hit测度及原alpha分类未变；模型构造部分与冻结r523_numeric.py逐字相同。三个类型数分别3、28、39，总70；未删掉任何原两动作类型。x_kd是old概率，1−x_kd是V概率，每个类型独立允许[0,1]全范围。

原正厚度模型只在oldR/V两个半径使用完整捕获/排除条带。因此周期字段在来源小立方内部恒定，整数平移及完整来源数给old列qP_kd、phase0、窗k/2，以及V列(q/G)2^dP_kd、phase4d、窗(k+d)/2。字段先按相位和窗合并再取平方，d=0的old/V共享相位窗及全部相邻交叉均保留。这里没有借用δ=0中间动作的源柱公式。

H的同phase对角1、相邻1/2确为真实单位窗Gram，故PSD。cp.psd_wrap只是数值接口；严格PSD依据字段构造，不依赖浮点特征值。各类型P严格为正，最终JSON的70个权重均经本审Arb核验。

## 2. 价格、gap与唯一最优性：通过

cold=q beta_(F,0)(k)、cnew=(q/G)2^d beta_(F,4d)(k+d)是每单位父类型测度的真实价格；乘P一次后求和正确，不应再多乘q。候选场完整包含所有类型，价格没有按单类型隔离计算。

脚本逐类型以正项计算gap：diff>0时为P x diff，diff<0时为P(1−x)(−diff)。符号正确；B−m_F与该正项和仅用球包含0核算术相容。实际候选所有x精确为0，且全部diff=cold−cnew严格>0，故所有正项精确为0；零gap不是由小球或求解器容差推断。

特别地，对任意可行x，直接真实字段展开给

\[
f(x)=B_{\rm end}+2\sum_{k,d}P_{kd}x_{kd}
(c^{\rm old}_{kd}-c^{\rm new}_{kd})+\|D x\|_H^2.
\]

这里第一项后的求和表示P、x与括号中差值的乘积。由于P>0、diff>0及Gram PSD，任何非零x都严格增加能量，纯V是该QP唯一全局最优；不需要H严格正定。切线下界2m_F−B=B−2r因此准确等于端点平方。

## 3. 浮点与有理化：通过

Clarabel仅用浮点中心选择候选。有限解先截取边界或化为分母2^44的有理概率，再用原P的Arb场重算；最终全部概率精确0，属于[0,1]。本审确认全部70行new_only、全部P及cnew正、全部old−new严格正、全部gap贡献精确0。原求解器状态和微小old概率均不承担严格证明。

正文保留周期两动作最优性与有限实际候选能量夹界的区别；[f4B,B]仅为固定端点候选夹界，没有冒称有限边界oracle。有限模型和连续动作的更大选择集未被本次证书覆盖。

## 4. 本机独立重放

实际使用指定 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python -I，python-flint/Arb256。除上述70行证书外，本审重算ΣP cnew与字段平方的相容性，并核原模型构造前缀与R523冻结代码一致。

随后仅复制脚本到全新临时目录执行，316个守卫全部通过。新JSON去掉顶层seconds和每模型solver.solve_time后，与冻结JSON逐字段完全一致，包括原始浮点候选、迭代数、有理概率及全部Arb球。输出：

`PASS independent isolated replay: all fields except wall/solver times identical; 316 checks and 70 strict type certificates; frozen model construction unchanged`

未重跑64步、未新增n/q或动作扫描、未改作者文件，未运行MATLAB。该有限结果支持“三个完整逐类型两动作QP均唯一取端点”的研究决策；它没有给出一般联合几何规律。审计完成后停止。
