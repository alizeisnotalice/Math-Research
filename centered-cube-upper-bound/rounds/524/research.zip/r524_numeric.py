#!/usr/bin/env python3
"""R524 original positive-delta whole-highslow independent-type two-action convex QP."""
from pathlib import Path
from fractions import Fraction as Q
import json,sys,platform,time
import numpy as np
import cvxpy as cp
import clarabel
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def aa(x):
 x=Q(x);return arb(x.numerator)/x.denominator

def firsthit(n,p,targets):
 S=sum(p,arb(0));remaining=S;dp=[arb(0) for j in range(n+1)];dp[0]=arb(1);P=[]
 for prob,target in zip(p[:-1],targets):
  ratio=prob/remaining;ck(ratio>0 and ratio<1);nd=[arb(0) for j in range(n+1)];hit=arb(0)
  for r,mass in enumerate(dp):
   if mass==0:continue
   m=n-r;w=(1-ratio)**m
   for inc in range(m+1):
    z=mass*w;nr=r+inc
    if nr==target:hit+=z
    else:nd[nr]+=z
    if inc<m:w=w*(m-inc)/(inc+1)*ratio/(1-ratio)
  P.append(hit);dp=nd;remaining-=prob
 out=[x*S**n for x in P];none=sum(dp,arb(0))*S**n
 ck((sum(out,arb(0))+none-S**n).contains(0))
 return out,none

def model(n,qpower,stage):
 q=2**qpower;ks=list(range(qpower+1,n+1));K=len(ks);delta=Q(1,10000*n*K);G=Q(4,3)
 base=arb(2).root(n);grow=aa(G).root(n);R=[base**(k-qpower) for k in ks];V=[grow*r for r in R]
 oldA=[r-1-2*aa(delta) for r in R];oldB=[r-1+2*aa(delta) for r in R]
 newA=[v-1-2*aa(delta) for v in V];newB=[v-1+2*aa(delta) for v in V]
 ck(all(1+2*aa(delta)<r<2-2*aa(delta) for r in R))
 ck(all(oldB[j]<newA[j] for j in range(K)));ck(all(newB[j]<oldA[j+1] for j in range(K-1)));ck(newB[-1]<1)
 Fold=[oldA[j]-8*j*aa(delta) for j in range(K)]
 Fnew=[newA[j]-(8*j+4)*aa(delta) for j in range(K)]
 S=1-8*K*aa(delta)
 bins=[Fold[0]]+[Fold[j]-Fold[j-1] for j in range(1,K)]+[S-Fold[-1]]
 ck(all(z>0 for z in bins));ck((sum(bins,arb(0))-S).contains(0))
 asc,none=firsthit(n,bins,ks)
 C=1+arb(4).log();An=1+n*arb(2).log();threshold=1/An;baseK=arb(2).root(4)
 L=1000*n;factor2=Q(L-2,L)**n;factor3=Q(L-3,L)**n;beta_cell=Q(2*n,L+3)
 ck(beta_cell<Q(1,500));ck(Q(2*n)/beta_cell==L+3)
 def st(x):return x.str(35,radius=True)
 results=[]
 for name,P in [('ascending_k',asc)]:
  ell=[q*p for p in P];beta_k=[ell[j]+(ell[j-1]/2 if j else 0)+(ell[j+1]/2 if j+1<K else 0) for j in range(K)];alpha=[b/C for b in beta_k]
  energy=sum((l*b for l,b in zip(ell,beta_k)),arb(0));discrete=sum((l*l for l in ell),arb(0))
  high=[];low=[];unclassified=[]
  for j,a in enumerate(alpha):
   if a>threshold:high.append(j)
   elif a<threshold:low.append(j)
   else:unclassified.append(j)
  ck(not unclassified)
  highP=sum((P[j] for j in high),arb(0));highScore=sum((ell[j]*beta_k[j] for j in high),arb(0))
  rows=[{'k':k,'P_arb':st(P[j]),'ell_arb':st(ell[j]),'alpha_arb':st(alpha[j]),'An_alpha_arb':st(An*alpha[j]),'class':'high' if j in high else 'low','K_target_arb':st(baseK.max(An*alpha[j]))} for j,k in enumerate(ks)]
  out={'shared_selector':name,'rows':rows,'real_window_Q_over_W_periodic_arb':st(energy),'discrete_label_sum_ell_squared_arb':st(discrete),'finite_Q_over_W_lower_arb':st(aa(factor2)*energy),'finite_Q_over_W_upper_arb':st(energy),'high_k':[ks[j] for j in high],'high_P_arb':st(highP),'high_receiver_nu_per_cell_arb':st(q*highP),'high_score_per_cell_arb':st(highScore),'high_score_fraction_periodic_arb':st(highScore/energy)}
  if name=='ascending_k':
   slowP=rapidP=unknownP=arb(0);slowScore=rapidScore=unknownScore=arb(0);details=[];joint=[]
   for j in high:
    k=ks[j];remaining=n-k;prob=(Fnew[j]-Fold[j])/(S-Fold[j]);ck(prob>0 and prob<1)
    w=(1-prob)**remaining;target=baseK.max(An*alpha[j]);sp=rp=up=arb(0)
    for inc in range(remaining+1):
     z=P[j]*w;ratio=arb(2)**inc
     if ratio<target:
      sp+=z;joint.append((k,inc,z))
     elif ratio>target:rp+=z
     else:up+=z
     if inc<remaining:w=w*(remaining-inc)/(inc+1)*prob/(1-prob)
    ck((sp+rp+up-P[j]).contains(0))
    slowP+=sp;rapidP+=rp;unknownP+=up;slowScore+=q*sp*beta_k[j];rapidScore+=q*rp*beta_k[j];unknownScore+=q*up*beta_k[j]
    details.append({'k':k,'additional_coordinate_probability_arb':st(prob),'slow_P_arb':st(sp),'rapid_P_arb':st(rp),'unresolved_P_arb':st(up)})
   out['full_high_classification']={'slow_P_arb':st(slowP),'rapid_P_arb':st(rapidP),'unresolved_P_arb':st(unknownP),'slow_receiver_nu_per_cell_arb':st(q*slowP),'slow_oldscore_per_cell_arb':st(slowScore),'slow_score_fraction_periodic_arb':st(slowScore/energy),'rapid_score_fraction_periodic_arb':st(rapidScore/energy),'finite_safe_slow_receiver_nu_over_W_lower_arb':st(aa(factor3)*q*slowP),'finite_safe_slow_score_over_W_lower_arb':st(aa(factor3)*slowScore),'details':details,'reason':'ascending first-hit filters only earlier coordinates; above current radius remaining coordinates retain categorical conditional law'}
  results.append(out)
 # Full actual phase/window fields for independent type probabilities.
 def add(field,phase,k,a):
  c=field.setdefault(phase,{});c[k]=c.get(k,arb(0))+a
 def inner(x,y):return sum((a*(y.get(k,arb(0))+(y.get(k-1,arb(0))+y.get(k+1,arb(0)))/2) for k,a in x.items()),arb(0))
 def finner(x,y):return sum((inner(c,y.get(phase,{})) for phase,c in x.items()),arb(0))
 def field_for(xs):
  f={}
  for (k,d,p),x in zip(joint,xs):
   add(f,0,k,q*p*aa(x));add(f,4*d,k+d,aa(Q(q*2**d)/G)*p*(1-aa(x)))
  return f
 def beta(f,phase,k):
  c=f.get(phase,{});return c.get(k,arb(0))+(c.get(k-1,arb(0))+c.get(k+1,arb(0)))/2
 labels=sorted(set([(0,k) for k,d,p in joint]+[(4*d,k+d) for k,d,p in joint]));index={t:i for i,t in enumerate(labels)}
 H=np.zeros((len(labels),len(labels)))
 for i,(phase,k) in enumerate(labels):
  for j,(phase2,k2) in enumerate(labels):
   if phase==phase2:H[i,j]=1. if k==k2 else (.5 if abs(k-k2)==1 else 0.)
 c=np.zeros(len(labels));D=np.zeros((len(labels),len(joint)))
 for j,(k,d,p) in enumerate(joint):
  old=float(q*p);new=float(aa(Q(q*2**d)/G)*p)
  c[index[(4*d,k+d)]]+=new
  D[index[(0,k)],j]+=old;D[index[(4*d,k+d)],j]-=new
 x=cp.Variable(len(joint));expr=c+D@x
 problem=cp.Problem(cp.Minimize(cp.quad_form(expr,cp.psd_wrap(H))),[x>=0,x<=1])
 problem.solve(solver='CLARABEL',tol_gap_abs=1e-12,tol_gap_rel=1e-12,tol_feas=1e-12,max_iter=500)
 ck(problem.status in ('optimal','optimal_inaccurate'))
 raw=np.asarray(x.value).flatten();ck(bool(np.all(np.isfinite(raw))))
 # Rational feasible probabilities. Boundary snap is only candidate construction.
 den=2**44;xs=[]
 for v in raw:
  if v<1e-8:r=Q(0)
  elif v>1-1e-8:r=Q(1)
  else:r=Q(round(float(np.clip(v,0,1))*den),den)
  xs.append(r)
 ck(all(0<=r<=1 for r in xs))
 A=field_for(xs);B=finner(A,A);endpoint=finner(field_for([Q(0)]*len(joint)),field_for([Q(0)]*len(joint)))
 minlinear=arb(0);average=arb(0);directgap=arb(0);rows=[]
 for (k,d,p),r,rv in zip(joint,xs,raw):
  cold=q*beta(A,0,k);cnew=aa(Q(q*2**d)/G)*beta(A,4*d,k+d)
  diff=cold-cnew
  if diff>0:choice='new';gap=p*aa(r)*diff
  elif diff<0:choice='old';gap=p*(1-aa(r))*(-diff)
  else:choice='unresolved';gap=p*((aa(r)*cold+(1-aa(r))*cnew)-cold.min(cnew))
  minimum=cold.min(cnew);minlinear+=p*minimum;average+=p*(aa(r)*cold+(1-aa(r))*cnew);directgap+=gap
  rows.append({'k':k,'d':d,'phase_j_new':4*d,'P_arb':st(p),'old_probability_exact':str(r),'old_probability_float':float(r),'raw_solver_old_probability':float(rv),'candidate_support':('new_only' if r==0 else ('old_only' if r==1 else 'both')),'old_window_start_exact':str(Q(k,2)),'new_window_start_exact':str(Q(k+d,2)),'old_over_new_F_price_arb':st(cold/cnew),'old_F_price_arb':st(cold),'new_F_price_arb':st(cnew),'old_minus_new_F_price_arb':st(diff),'strictly_cheaper_action':choice,'oracle_gap_contribution_arb':st(gap)})
 gap=directgap;lower=B-2*gap
 ck((B-average).contains(0));ck((gap-(B-minlinear)).contains(0));ck(gap>=0);ck(lower>0)
 ck(gap/ B<aa(Q(1,10**7)))
 if all(r==0 for r in xs):ck((B-endpoint).contains(0))
 else:ck(B<endpoint)
 endpoint_exact_optimal=all(r==0 for r in xs) and all(row['strictly_cheaper_action']=='new' for row in rows)
 ck(endpoint_exact_optimal)
 ck(all(p>0 for k,d,p in joint))
 improve=arb(0) if endpoint_exact_optimal else endpoint-B
 # Existing positive-field finite brackets remain candidate brackets only, not finite oracle.
 factor4=Q(L-4,L)**n
 out={'stage':stage,'n':n,'q':q,'scope':'Original positive-delta whole-highslow; periodic complete oldR/V independent-type QP; no continuous or finite-boundary oracle',
 'delta_exact':str(delta),'G':str(G),'type_count':len(joint),'actual_phase_window_column_count':len(labels),
 'solver':{'name':'CLARABEL','status':problem.status,'objective_float':problem.value,'num_iters':problem.solver_stats.num_iters,'solve_time':problem.solver_stats.solve_time,'requested_gap_abs':1e-12,'requested_gap_rel':1e-12},
 'rational_probability_denominator':str(den),'rows':rows,'strict_endpoint_unique_global_optimum_certified':endpoint_exact_optimal,'optimal_probability_old_exact':'0 on every original type','optimal_improvement_over_endpoint_exact':'0','oracle_gap_exact':'0',
 'endpoint_energy_over_W_periodic_arb':st(endpoint),'feasible_energy_over_W_periodic_arb':st(B),'two_action_minimum_lower_over_W_periodic_arb':st(lower),'full_two_action_oracle_linear_minimum_over_W_arb':st(minlinear),'full_two_action_oracle_gap_over_W_arb':st(gap),'full_gap_over_B_arb':st(gap/B),
 'certified_optimum_interval_arb':{'lower_arb':st(lower),'upper_arb':st(B)},'certified_optimality_width_over_B_arb':st(2*gap/B),
 'feasible_improvement_over_endpoint_arb':st(improve),'feasible_over_endpoint_arb':st(B/endpoint),'optimal_improvement_over_endpoint_interval_arb':{'lower_arb':st(improve),'upper_arb':st(endpoint-lower)},
 'finite_candidate_energy_over_W':{'lower_arb':st(aa(factor4)*B),'upper_arb':st(B)},'finite_core_factor_exact':str(factor4),
 'certificate':'Bmin>=2 inf_V<A,V>-||A||^2 = B-2 full_oracle_gap; independent complete two-action choices on every original type; Gram is exact periodic source-field square',
 'interpretation_limit':'The exact endpoint support is certified by strict Arb old-minus-new prices at every original type and convexity, independent of floating solver status; this is only the periodic two-action problem'}
 print('MODEL',stage,'types',len(joint),'B/endpoint',st(B/endpoint),'gap/B',st(gap/B),'new_only_types',sum(r['candidate_support']=='new_only' for r in rows),flush=True)
 return out

def main():
 start=time.perf_counter();models=[model(16,1,'probe'),model(64,2,'pressure'),model(64,4,'expanded_density')]
 out={'scope':'R524 original positive-delta three models; complete independent-type periodic two-action convex QP, no winner iteration or new scan',
 'environment':{'executable':sys.executable,'python':platform.python_version(),'python_flint':flint.__version__,'numpy':np.__version__,'cvxpy':cp.__version__,'clarabel':clarabel.__version__,'installed_solvers':cp.installed_solvers(),'arb_precision_bits':ctx.prec},'models':models,'checks':checks,'seconds':time.perf_counter()-start}
 (ROOT/'r524_numeric.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS R524 independent-type QP and Arb full-oracle lower bound')
if __name__=='__main__':main()
