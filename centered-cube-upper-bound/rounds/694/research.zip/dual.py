"""Independent exact actual-history and multipool checks. Finite evidence only."""
from fractions import Fraction as F
from itertools import combinations_with_replacement
from pathlib import Path
import json,hashlib,time,sys
P=Path(__file__).resolve().parent

def merge(intervals):
 out=[]
 for l,r in sorted(intervals):
  if l>=r:continue
  if out and l<=out[-1][1]:out[-1]=(out[-1][0],max(out[-1][1],r))
  else:out.append((l,r))
 return out

def length(intervals):return sum((r-l for l,r in merge(intervals)),F(0))

def weighted_union(intervals):
 endpoints=sorted({e for l,r,w in intervals if w>0 for e in (l,r)})
 total=F(0)
 for l,r in zip(endpoints,endpoints[1:]):
  mid=(l+r)/2
  total+=(r-l)*max([F(0)]+[w for ll,rr,w in intervals if ll<mid<rr])
 return total

def multipool(N):
 a=32;q=F(1,2);alpha=F(1,32);c=F(33,32)
 centers=[F(-N+2*i+1,a) for i in range(N)]
 parents=[(y-1,y+1) for y in centers]
 eps=sorted({x for p in parents for x in p});cells=list(zip(eps,eps[1:]));mids=[(l+r)/2 for l,r in cells]
 rows=[[j for j,x in enumerate(mids) if l<x<r] for l,r in parents]
 load=[F(0)]*len(cells);history=[list(load)];remaining=set(range(N));order=[];theta=[];residual=[];cross={}
 while remaining:
  caps={i:1-max(load[j] for j in rows[i]) for i in remaining}
  chosen=max(remaining,key=lambda i:(caps[i],-i));ri=caps[chosen];th=alpha*ri
  order.append(chosen);residual.append(ri);theta.append(th);remaining.remove(chosen)
  for j in rows[chosen]:load[j]+=th
  assert all(x<=1 for x in load)
  history.append(list(load))
  for i in remaining:
   if i not in cross and max(load[j] for j in rows[i])>=q:cross[i]=len(order)
 assert all((ri<=q)==(i in cross) for i,ri in zip(order,residual))
 active=set()
 for i,m in cross.items():
  active.update(j for j in rows[i] if history[m-1][j]<q<=history[m][j])
 pools={}
 for j in sorted(active):
  tau=next(m for m in range(1,N+1) if history[m][j]>=q)
  pool=tuple(m for m in range(tau) if j in rows[order[m]])
  assert pool and max(pool)==tau-1
  assert sum((theta[m] for m in pool),F(0))==history[tau][j]
  pools.setdefault(pool,[]).append(cells[j])
 pools={k:merge(v) for k,v in pools.items()}
 D=2*sum(theta,F(0));V=F(N,16);bad=F(len(cross),16);H=length([cells[j] for j in active]);assert H<=D/q
 poolrows=[]
 for pool,z in pools.items():
  m=max(pool);h=c*residual[m]/q;B=sum((theta[i] for i in pool),F(0));halo=merge([(l-h,r+h) for l,r in z])
  assert residual[m]<=q+theta[m]
  poolrows.append({'pool':pool,'z':z,'B':B,'h':h,'halo':halo,'mass':length(halo)})
 limit=sum((p['mass'] for p in poolrows),F(0));halo_union=length([x for p in poolrows for x in p['halo']])
 moments=[]
 available=sorted(set(i for pool in pools for i in pool))
 for k in (1,2):
  A=base=F(0)
  for I in combinations_with_replacement(available,k):
   factor=2 if k==2 and I[0]!=I[1] else 1
   m=max(I);h=c*residual[m]/q;pieces=[];b=F(0)
   for p in poolrows:
    if not all(i in p['pool'] for i in I):continue
    w=F(1)
    for i in I:w*=theta[i]/p['B']
    b+=w*length(p['z'])
    pieces.extend((l-h,r+h,w) for l,r in p['z'])
   base+=factor*b;A+=factor*weighted_union(pieces)
  assert base==H and A>=bad
  moments.append({'k':k,'normalized_halo_exact':str(A),'halo_over_D':float(A/D),'base_exact':str(base)})
 return {'N':N,'a':a,'alpha':'1/32','temperature':'-1/(32 log(31/32))','owner_V':str(V),'D':str(D),'D_decimal':float(D),'order':order,'bad_count':len(cross),'bad_volume':str(bad),'active_cells':len(active),'active_volume':str(H),'distinct_first_hit_pools':len(pools),'pool_halo_sum':str(limit),'pool_halo_sum_over_D':float(limit/D),'pool_halo_union':str(halo_union),'sum_over_union':float(limit/halo_union) if halo_union else None,'moments':moments}


import multiprocessing as mp, socket, os
def run_one(n):
 start=time.process_time()
 r=multipool(n)
 assert F(r['pool_halo_union'])>=F(r['bad_volume'])
 return {'N':n,'cpu_s':time.process_time()-start,'pools':r['distinct_first_hit_pools'],'bad':r['bad_volume'],'D':r['D'],'union':r['pool_halo_union'],'sum':r['pool_halo_sum'],'halo':[m['normalized_halo_exact'] for m in r['moments']]}
if __name__=='__main__':
 lo,hi,workers=map(int,sys.argv[1:4])
 t0=time.monotonic()
 with mp.get_context('fork').Pool(workers) as pool:
  rows=pool.map(run_one,range(lo,hi+1),chunksize=1)
 print(json.dumps({'host':socket.gethostname(),'python':sys.version,'workers':workers,'logical':os.cpu_count(),'elapsed':time.monotonic()-t0,'rows':rows}))
