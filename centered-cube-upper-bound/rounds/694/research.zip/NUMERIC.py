#!/usr/bin/env python3
"""R694 exact stopped-tuple whole kernels: unrestricted,terminal-hit,active-bad supports."""
from fractions import Fraction as Q
from pathlib import Path
import hashlib,json,sys,time,platform
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;start=time.time();ctx.prec=512
X=Q(31,32);BETA=THRESHOLD=Q(1,2);A=32;C0=Q(33,32)
def ab(v):return arb(v.numerator)/v.denominator
def merge(intervals):
 out=[]
 for lo,hi in sorted((lo,hi) for lo,hi in intervals if lo<hi):
  if out and lo<=out[-1][1]:out[-1]=(out[-1][0],max(hi,out[-1][1]))
  else:out.append((lo,hi))
 return out
def intersect(U,V):return merge([(max(a,c),min(b,d)) for a,b in U for c,d in V if max(a,c)<min(b,d)])
def dilate(U,h):return merge([(lo-h,hi+h) for lo,hi in U if lo<hi])
def length(U):return sum((hi-lo for lo,hi in U),Q(0))
def as_strings(v):
 if isinstance(v,Q):return str(v)
 if isinstance(v,(list,tuple)):return [as_strings(x) for x in v]
 if isinstance(v,dict):return {k:as_strings(x) for k,x in v.items()}
 return v
def frac_hash(v):return hashlib.sha256((hex(v.numerator)+'/'+hex(v.denominator)).encode()).hexdigest()
def encode(v):
 bits=max(v.numerator.bit_length(),v.denominator.bit_length())
 exact=str(v) if bits<=2048 else {'numerator_hex':hex(v.numerator),'denominator_hex':hex(v.denominator)}
 return {'exact':exact,'sha256_hex_num_slash_den':frac_hash(v),'numerator_bits':v.numerator.bit_length(),'denominator_bits':v.denominator.bit_length(),'Arb_512':str(ab(v))}

def prepare(kind):
 N=32 if kind=='equal_grid' else 64
 radii=[Q(1)]*N if kind=='equal_grid' else[Q(15,16)**i for i in range(N)]
 centers=[-1+Q(2*i+1,32) for i in range(N)] if kind=='equal_grid' else radii[:]
 parents=[(c-s,c+s) for c,s in zip(centers,radii)];cores=[(c-s/A,c+s/A) for c,s in zip(centers,radii)]
 assert all(max(a,c)>=min(b,d) for i,(a,b) in enumerate(cores) for c,d in cores[i+1:])
 v=[hi-lo for lo,hi in cores];di=[2*s for s in radii];w=[v[i]/di[i] for i in range(N)];assert all(vv==Q(1,32) for vv in w)
 V=length(merge(cores));assert V==sum(v,Q(0));common=(max(lo for lo,hi in parents),min(hi for lo,hi in parents));assert common[0]<common[1]
 theta=[(1-X)*X**i for i in range(N)];cum=[Q(0)]
 for th in theta:cum.append(cum[-1]+th)
 assert all(cum[i]==1-X**i for i in range(N+1))
 endpoints=sorted(set(v for B in parents for v in B));cells=[]
 for lo,hi in zip(endpoints,endpoints[1:]):
  mid=(lo+hi)/2;bits=[a<mid<b for a,b in parents];prefix=[Q(0)]
  for th,yes in zip(theta,bits):prefix.append(prefix[-1]+th*yes)
  B=next((f for f in prefix[1:] if f>=THRESHOLD),prefix[-1]);hit=prefix[-1]>=THRESHOLD
  assert B<=prefix[-1] and B<=THRESHOLD+max(theta)
  cells.append({'interval':(lo,hi),'mass':hi-lo,'parent_bits':bits,'prefix_fields':prefix,'FN':prefix[-1],'B_stopped':B,'terminal_hit':hit})
 for m in range(N):assert max(c['prefix_fields'][m] for c in cells if c['parent_bits'][m])==cum[m]
 first=next(i for i in range(N) if X**i<=BETA);bad=list(range(first,N));assert first==22
 bad_volume=sum((v[j] for j in bad),Q(0))
 if kind=='equal_grid':assert V==2 and bad_volume==Q(5,8)
 else:assert V==1-Q(15,16)**N and bad_volume==Q(15,16)**first-Q(15,16)**N
 low=[merge([c['interval'] for c in cells if c['prefix_fields'][m]<THRESHOLD]) for m in range(N)]
 terminal=merge([c['interval'] for c in cells if c['terminal_hit']])
 active=merge([c['interval'] for c in cells if any(c['parent_bits'][j] for j in bad) and c['prefix_fields'][first-1]<THRESHOLD<=c['prefix_fields'][first]])
 assert intersect(active,terminal)==active
 for c in cells:
  mid=sum(c['interval'],Q(0))/2;c['active_bad_support']=any(lo<mid<hi for lo,hi in active)
 groups=[];maxcomp={'stop':0,'terminal_hit':0,'active_bad':0};empty={k:0 for k in maxcomp}
 iterator=[(aa,m) for m in range(N) for aa in range(m+1)] if kind=='equal_grid' else[(None,m) for m in range(N)]
 for aa,m in iterator:
  I=(parents[m][0],parents[aa][1]) if kind=='equal_grid' else parents[m]
  raw=merge([I]);stop=intersect(raw,low[m]);hit=intersect(stop,terminal);act=intersect(stop,active);h=C0*radii[m]*X**m/BETA
  row={'min_label':aa,'max_label':m,'raw_intersection':raw,'h':h,'raw_length':length(raw),'raw_halo_length':length(dilate(raw,h))}
  for name,U in (('stop',stop),('terminal_hit',hit),('active_bad',act)):
   halo=dilate(U,h);assert all(lo<hi for lo,hi in U+halo)
   if not U:assert not halo;empty[name]+=1
   maxcomp[name]=max(maxcomp[name],len(U));row[name]={'interval_union':U,'halo_union':halo,'length':length(U),'halo_length':length(halo)}
  groups.append(row)
 active_B_values=set(c['B_stopped'] for c in cells if c['active_bad_support']);assert len(active_B_values)==1
 Bconst=next(iter(active_B_values))
 for row in groups:
  assert row['active_bad']['interval_union']==(active if row['max_label']<first else [])
 normalized_halo_limit=length(active)+2*C0*radii[first-1]*X**(first-1)/BETA
 D=sum((dd*th for dd,th in zip(di,theta)),Q(0));assert sum(c['mass']*c['FN'] for c in cells)==D
 if kind=='equal_grid':assert active==[(Q(-19,32),Q(1,32))]
 else:assert active==[(Q(0),2*Q(15,16)**22)]
 return {'kind':kind,'N':N,'radii':radii,'centers':centers,'parents':parents,'cores':cores,'v_i':v,'w_i':w,'theta_i':theta,'cumtheta':cum,'V':V,'D':D,'common_intersection':common,'cells':cells,'first_cross_processed_count':first,'trigger_label':first-1,'bad_labels':bad,'Vbad':bad_volume,'terminal_hit_union':terminal,'Hbad_active_union':active,'active_B_constant':Bconst,'active_first_hit_pool_labels':list(range(first)),'exact_active_normalized_halo_limit':normalized_halo_limit,'groups':groups,'maximum_stop_union_components_observed':maxcomp,'empty_group_counts':empty}

def moments(g,k):
 cum=g['cumtheta'];N=g['N'];groups=g['groups'];cache={};sums={'raw_base':Q(0),'raw_halo':Q(0)}
 for name in ('stop','terminal_hit','active_bad'):sums[name+'_base']=Q(0);sums[name+'_halo']=Q(0)
 checksum=hashlib.sha256();weighttotal=Q(0)
 def power(aa,mm):
  if aa>mm:return Q(0)
  key=(aa,mm)
  if key not in cache:cache[key]=(cum[mm+1]-cum[aa])**k
  return cache[key]
 for row in groups:
  aa=row['min_label'];m=row['max_label']
  if aa is None:weight=cum[m+1]**k-cum[m]**k
  elif aa==m:weight=g['theta_i'][m]**k
  else:weight=power(aa,m)-power(aa+1,m)-power(aa,m-1)+power(aa+1,m-1)
  assert weight>=0;weighttotal+=weight
  checksum.update((str(aa)+':'+str(m)+':'+hex(weight.numerator)+'/'+hex(weight.denominator)+';').encode())
  sums['raw_base']+=weight*row['raw_length'];sums['raw_halo']+=weight*row['raw_halo_length']
  for name in ('stop','terminal_hit','active_bad'):
   sums[name+'_base']+=weight*row[name]['length'];sums[name+'_halo']+=weight*row[name]['halo_length']
 assert weighttotal==cum[-1]**k
 # Independent global-cell source-prefix calculation, with real spatial stop/hit masks.
 independent={name:Q(0) for name in ('stop','terminal_hit','active_bad')};raw=Q(0)
 for c in g['cells']:
  pf=c['prefix_fields'];stopped=sum((pf[m+1]**k-pf[m]**k for m in range(N) if pf[m]<THRESHOLD),Q(0))
  assert stopped==c['B_stopped']**k
  raw+=c['mass']*c['FN']**k
  independent['stop']+=c['mass']*stopped
  if c['terminal_hit']:independent['terminal_hit']+=c['mass']*stopped
  if c['active_bad_support']:independent['active_bad']+=c['mass']*stopped
 assert raw==sums['raw_base']
 normalization=THRESHOLD**(-k);D=g['D'];newbound=THRESHOLD**(-1)*(1+max(g['theta_i'])/THRESHOLD)**(k-1)*D
 result={'k':k,'normalization_q_to_minus_k':str(normalization),'ordered_tuple_weight_sum_exact':encode(weighttotal),'aggregation_weight_sha256':checksum.hexdigest(),'raw_without_stop':{'base_mass':encode(normalization*sums['raw_base']),'halo_mass':encode(normalization*sums['raw_halo']),'raw_cell_integral_identity_passed':True},'stopped_no_derivative_k_bound':encode(newbound),'old_derivative_bound_factor_over_new':k,'mask_versions':{}}
 for name in ('stop','terminal_hit','active_bad'):
  assert independent[name]==sums[name+'_base']
  base=normalization*sums[name+'_base'];halo=normalization*sums[name+'_halo'];assert 0<base<=newbound and halo>=base
  result['mask_versions'][name]={'base_mass':encode(base),'halo_mass':encode(halo),'base_over_D':str(ab(base/D)),'halo_over_D':str(ab(halo/D)),'halo_over_base':str(ab(halo/base)),'independent_Bk_masked_integral_hash':frac_hash(normalization*independent[name]),'independent_stopped_increment_identity_passed':True,'no_k_bound_passed':True}
 exact_base=sums['active_bad_base']/g['active_B_constant']**k
 exact_halo=sums['active_bad_halo']/g['active_B_constant']**k
 assert exact_base==length(g['Hbad_active_union']) and exact_halo>=g['exact_active_normalized_halo_limit']
 assert exact_halo==normalization*sums['active_bad_halo']*(THRESHOLD/g['active_B_constant'])**k
 result['exact_active_normalized']={'base_mass':encode(exact_base),'halo_mass':encode(exact_halo),'conversion_factor_from_q_normalization':encode((THRESHOLD/g['active_B_constant'])**k),'base_over_D':str(ab(exact_base/D)),'halo_over_D':str(ab(exact_halo/D)),'halo_over_base':str(ab(exact_halo/exact_base)),'halo_limit_last_source':encode(g['exact_active_normalized_halo_limit']),'halo_minus_limit':encode(exact_halo-g['exact_active_normalized_halo_limit']),'single_actual_first_hit_pool_verified':True}
 return result

families=[prepare('equal_grid'),prepare('nested')];records={g['kind']:[] for g in families};timings=[]
for stage,ks in ((1,(1,2)),(2,(4,8,16,32))):
 tick=time.time()
 for k in ks:
  for g in families:records[g['kind']].append(moments(g,k))
 timings.append({'stage':stage,'k_values':list(ks),'elapsed_seconds':time.time()-tick});print('stage',stage,'passed k',ks,flush=True)
# Optional k64 is admitted only after the measured required stages are cheap.
if time.time()-start<10:
 tick=time.time()
 for g in families:records[g['kind']].append(moments(g,64))
 timings.append({'stage':3,'k_values':[64],'elapsed_seconds':time.time()-tick});print('cheap optional k64 passed',flush=True)
familyout=[]
for g in families:
 geometry={k:v for k,v in g.items() if k not in ('groups','cells')}
 geometry['cells']=g['cells'];geometry['tuple_group_geometry']=g['groups']
 familyout.append({'input_and_geometry':as_strings(geometry),'moments':records[g['kind']]})
temp=-arb(1)/(32*(arb(31)/32).log())
out={'scope':'Two frozen actual1D direct finite inputs, true disjoint cores and corrected rank. Exact whole stopped-tuple kernel diagnostics only; no original high-tau history or general halo/receiver budget is proved.','python':sys.version,'platform':platform.platform(),'python_flint_version':flint.__version__,'precision_bits':ctx.prec,'command':[sys.executable,str(Path(__file__).resolve())],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'parameters':{'n':1,'a':32,'x':'31/32','theta_i':'(1-x)x^i=(1/32)x^i','r_i':'x^i before ownselection','t_exact':'-1/(32log(31/32))','t_Arb':str(temp),'beta_and_q':'1/2','h_m':'(33/32)*s_m*r_m/beta','delta_max_theta':'1/32'},'kernel_definitions':{'C_I':'intersection_i Ai intersect {F_before_last_time<q}, as positive interval unions','terminal_hit':'C_I intersect {FN>=q}','active_bad':'C_I intersect Hbad;Hbad=union_bad_j [Aj intersect{F_before_kj<q<=F_after_kj}], actual firstcross before ownselection','stopped_identity':'sum_m1{Fprev<q}(Fm^k-Fprev^k)=B(x)^k, B=firsthittingFvalue orFN ifneverhit','mask_identities':'B^k1{FN>=q} andB^k1Hbad respectively','improved_unexpanded_bound':'q^-k integral B^k <= q^-1(1+delta/q)^(k-1)D, no derivativek factor','grid_weight':'For a<m:theta[a..m]^k-theta[a+1..m]^k-theta[a..m-1]^k+theta[a+1..m-1]^k; a=m uses theta_a^k','nested_weight':'cum_m^k-cum_prev^k; repeats and ordered tuples included','positive_volume_rule':'Empty or zero-length sets are discarded before dilation; each union component is dilated then merged. No face is inflated.'},'families':familyout,'stage_timings':timings,'summary':{'family_count':2,'k_values':sorted(set(r['k'] for vv in records.values() for r in vv)),'all_fraction_aggregation_and_pointwise_identities_passed':True,'all_three_support_masks_distinguished':True,'all_improved_no_k_bounds_passed':True,'true_first_cross_processed_count':22,'active_halo_over_D_is_primary_diagnostic':True},'elapsed_seconds':time.time()-start,'errors':[],'prior_execution_note':'Initial launch stopped at parse time on an else-spacing typo; no numerical result was produced before correction.'}
(ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
brief=[]
for family in out['families']:
 for r in family['moments']:
  brief.append({'family':family['input_and_geometry']['kind'],'k':r['k'],'versions':{name:{key:val[key] for key in ('base_over_D','halo_over_D','halo_over_base')} for name,val in r['mask_versions'].items()}})
print(json.dumps({'summary':out['summary'],'stage_timings':timings,'elapsed_seconds':out['elapsed_seconds'],'source_sha256':out['script_sha256'],'RESULT_sha256':hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest(),'ratios':brief},indent=2))
