# R257 独立审计

## 命题先行独筛（未读作者桥接稿）

本审唯一编辑audit.md；未改其他工作者稿。首次读取257/work尚不存在，按明确责任创建本文件。只窄读冻结原片段：R223 joint_budget JB1、R128 proof RT1–4及cj<=1陈述、R117 joint_geometry JG1–2、R113 joint_budget B2/coupled_transport C8、R237 source_ledger SL1/SL4；未预认作者新结论。

**候选实际子支链条可成立。** 原完整正母式是2Λ E sum_Vj integral q^-1 p_y h_R aω 1_j high [integral_Jfar Θ (kv−ku)+ Π_yjt(dv)Π_yjt(du)dlogt] dx β_V(dy)ν_V(dz)，其中原Θ及其余正筛选在[0,1]。必须保实际receiver合法域及原sources，已付款正支若重叠须先在本余正项中不交化，不从负信用借款。

### 原双后验与clock资格

R117 JG1–2/原RT4给有效heavy时刻e_t>0、Π=1Z wtν/e_t为同一原概率，k=#(Ai<t)在[0,n]；无效时钟原积分为0。放松good/bad和Θ等正门到同一个完整Π×Π，不改变归一化或源slot。若X,X'为该同分布score的两个乘积测度变量，则

`E(X−X')+ = integral_0^n p_r(1−p_r) dr <=n/4`。

这里iid仅指同后验的乘积积分，绝不假设score坐标或原来源独立。原RT4的τ_j=a/c_j<=g<=b c_j、0<c_j<=1及Jfar subset[τ_j,h],h<=g给logclock<=log(b c_j²/a)<=log(b/a)<=log2。原uniquej是固定(x,V)唯一actual比例带；必须先取得逐行一致n log2/4上界，再由sum_j 1_j<=1消去j，不能先sum多个posterior或网格选择免费付款。

### actual core高度及原两尺度pair

原p=P_s,L=L^-n product[(1−s)h+sφ]。φ为对称递减核，φ<=φ0<1，故保1_core直到使用p 1_core<=c_s^n h_L，c_s=1−s+sφ0。在n c_s^n<=1子域p 1_core<=h_L/n，恰抵消Gini的n。core外绝不能用h_L支配soft核。

φ0=1−2 integral_0^1 r exp(−1/(2r))dr。只取r∈[1/2,1]即给1−φ0>=3/(4e)>1/4（e<3可由阶乘级数严格比较证明），因此φ0<3/4。s>=4log n/n是nc_s^n<=1的合法充分门，若该阈值>1则子支为空；不把原strictsoft下门误认成这个更高门。原s<=1−d_n及大n祖链仍原位，不据低维标量诊断生成FULL实例。

R256双原来源Cauchy可直接扩为不同的actual尺度L(x),R(x)各属于[a,b]：同一normalized shift/cell/receiver底测度上，两侧分别为h_L*β_C与h_R*ν_C；各自由全[a,b] receiver帽付对角平方。因此

`integral_E integral h_L(x−y)h_R(x−z)P_D(y−z) β(dy)ν(dz) dx <=8lambda kappa_D sqrt(massβ massν)`。

不需L=R，不需βν次序，也不先hardcap再免费补一个h_R。β,ν<=f及原Mf<=4lambda是所需帽资格；若放aω包含的历史/receiver门，仍须保合法receivercap域，不能向无帽新x授资格。

### 系数与来源总账

对P_D加权原正nearcore子项，依次用n log2/4、p<=h_L/n、1/q<=4/(3lambda)、双侧pair价8lambda kappa_D，得到

`P_core,PD <=(16Λ log2/3) kappa_D E sum_V sqrt(Wβ,V Wν,V)`。

若取无权metric near indicator ||y−z||1<=D/2再乘2；不能把ℓ1换成ℓ∞。固定D=a/(8sqrt n)，kappa_D<=2+sqrt n/8使完整实际正子支root收费。D不能事后免费改变；P_D与near indicator是两种上放，不能对重叠交通重复累加信用。

R113 B2、coupled C8及R237 SL4保β_V,ν_V<=α_V=μ_hi|V，且固定seed的V不交，故sum sqrt(Wβ Wν)<=sum massα<=mass μ_hi，期望后<=W_hi<=||f||。Λ=128/119只来自原母式一次；这里没有额外root来源或negative退款，也不靠x只有一个V去取消来源mass（实际用sum_V mass账）。其他soft/core外、低soft或nc_s^n>1、未留pair权补集和原signed/history账均未付。

### 本人实际标量核查代码

下列普通mp60计算实际执行，用于φ0公式及充分core门算术诊断；不是区间或实际FULL验证。一般φ0<3/4由上面的r区间解析下界证明。

```python
import mpmath as mp
mp.mp.dps=60
phi0=1-2*mp.quad(lambda r:r*mp.exp(-1/(2*r)) if r else 0,[0,1])
assert 0<phi0<mp.mpf(3)/4
npass=0;nempty=0
for n in [1,2,16,512,2**20,2**40]:
 s0=4*mp.log(n)/n
 if s0>1:nempty+=1;continue
 c=1-s0+s0*mp.mpf(3)/4
 assert mp.log(n)+n*mp.log(c)<=mp.mpf('1e-56')
 npass+=1
print('phi0 ordinary mp60',mp.nstr(phi0,25))
print('PASS coreheight scalar checks',npass,'empty threshold models',nempty,'not FULL')
```

实际φ0=.5567912714496430852614012，5非空标量核验PASS、1阈值域空；低维只作核算。等待作者准确桥、主稿及最终numeric范围后审，不冻结。


## actual_bridge.md 作者稿后全文审核

**AB1–8 PASS。** 在上述独立statement-screen、原片段阅读和本机核算后读作者稿，当前受审SHA26790f7b4f8e15edceae4bfad3517696de1f32804a738622265f35e7d230dbe2。AB7从已移除旧付款正子份额的remaining-positive起步；所有额外权[0,1]，真正原dT、q、hardz、βν、两Π、high、history与actualselector先完整保留，随后只正上放。负项完全没有新门，不重复消费R223信用。

AB2扩两actual scales的samecell-Cauchy证明确实成立，各自allRcap由原master G0授，而非从selectedR推上节点或从已消hardz的SOCC11重建。AB8 raw价32/3 χκ不能独自付clock；AB9–11逐时刻同Π正Gini与原τ端点给nlog2/4，先统一bound再uniquej，顺序正确。AB12整体16Λlog2/3系数准确。AB14真正metric近对再×2，无额外Λ或j标签代价。

AB3–6 core高度仅在hardcore上使用，φ0解析tail3/(4e)>1/4足够，s0下门独立于原strictsoft下门。大维数祖链和s<=1−d_n等未解除；若新门冲突为空直接零，不宣称存在FULL实例或占固定正比例。AB15同seed原ν<=β<=α、V不交，允许W_pair<=Wβ<=W_A<=W_hi；没有用x唯一V取消source mass，也没有拿过去已付slot顶替本轮新收费。

本人实际从AB8 Markdown抽取运行11项bounded检查，输出逐行与作者稿相同；其中n512/1e6 fail祖维门明确，n1e9仅标量检查原祖维必要门，不认证完整FULL。普通mp60 φ0求积不当interval。前述初筛本人5非空/1空标量码仍独立归档，不与作者11项混为不同物理实例。全部一般结论由AB2–6严格证明，不由检查拟合。

## 新各向异性单cluster工具的独立预审（未读作者证明）

令全部r_i>0、A_R=(R^n product r_i)^−1 1_(axis rectangle of sides Rr_i)，R∈[a,b]，任意正来源支撑axis-aligned sideD cube。候选κ_r=2+sum_i log(1+D/(a r_i)) **可成立**。

对mass m>0、levelu>0，t^n product r_i=m/u。若t<=a，level empty。若m/u>=D^n，函数product(ρr_i+D)严格递增，存在唯一ρ>=0使其=m/u。中心为sourcecube center、边ρr_i+D的core体积m/u，先付m；core外capture且response>u迫使ρ<R<t。全部outside尺度冻结在[max(a,ρ),min(b,t)]，归一homothetic rectangle全尺度sup kernel的L1仍1+nlog(B/A)，可单次Tonelli。ρ>=a时nlog(t/ρ)=sumlog(1+D/(ρr_i))<=sumlog(1+D/(a r_i))；ρ<a时product(ρr_i+D)<=product(ar_i+D)也给t/a相同比价。m/u<D^n时不取core，t/a的product界同样由product D/(a r_i)<=product(1+D/(a r_i))给出。A>B为空，A=B保单kernel非空；ρ0边界及m0都需明确。没有用免费的仿射把aspect费消掉。

该工具若用于全部softfamily还须正混合表示、r0边界atom、countable aspect π阈值与0/1/2 log矩完整支付。最关键height只对actual selected softresponse由原current FIRST授，不能给sup_(all s,L)在E上同一帽。即便bare selected软硬nearpair可得root乘对数，它的原score/clock仍须另接；本审不先认证整个offcore原交通付款。


## mixed_geometry.md 完整作者稿审核

**MG1–8 PASS。** 在各向异性lemma及selected-cap独筛之后完整读作者稿，当前SHAa5e5086d6a4010c9813d4dbebb58e6679a1cf01d472d9e8c80e41da8759c430c。

MG2直接threshold-core证明符合先筛：r_i>0，sourcecube axis aligned；m0、t<=a、ρ0、m/u<d^n、短窗空与单尺度均可覆盖。长短方面比费用以sumlog显式保留，不是免费仿射推得。MG3共同B_C=Q_(b+d)(centerC)来自硬簇响应>0；对所有软簇来源y，|x_i−y_i|/L<=(b/2+d)/a<=3/2，所以只在该共同硬窗口内用ψ截断是准确换核，不删实际软尾。

ψ的正区间混合密度−rφ'(r/2)/2及r3的质量3φ(3/2)atom准确；零半径无额外atom，因为φ有界。φ'有界1给l>=1的衰减，l0边界质量单保；w总量<=v<1、ω=w/ζ总量<=ζ<1且M1/M2为完整无限log矩，未截断小aspect。P(|W|>2)>=epsilon的解析区间下界成立，来源不被假定独立。

MG4关键不是任意θ/rescale免费取sup：binomial单项由(1−s+sζ)^n总和支配，给共同s的e^(−cns0)及每个subset的1/binom系数，仍保ω总量<1供熵求和。预选π总和<=1，不依actualweights免费选择。弱和证明的low阈uπ/2总量<=u/2，bigunion付sum a/u，中段积分付a[1+log(2/π)]；countable用finitepartial monotone，全部费用有限由M1/M2保证。sup的可测性由L1来源卷积对(s,L)连续（ψ边界为source-null hyperplanes）及稠密可数参数保证，或直接使用可数正矩形majorant。

令Lsum=sum l_i logγ。真实乘积展开为(κ+Lsum)(A0+2kC_n+2Lsum)，逐项求和恰为MG4.4：κ零阶、κk、(A0+2κ)M1、kLsum、M2与M1²两项全保。K_n<=C_*κlog(n+2)的各项都使用κ>=2、log(n+2)>=log3及C_n<=c0log(n+2)，方向正确；C_*大但为显式绝对常数，不声称优化。无限aspect矩只属于分析正核混合，不是原source/Π的独立坐标模型。

MG5严格只用actual selected F_C<=q而非sup_(all s,L)帽；F_C在B_C上由已证弱族majorize，G_C>0才需要该域。cell平方预算分别2q e^(−cns0)K massβC与8λκ massνC，逐cell后按来源质量Cauchy得到4sqrt(qλ) e^(−cns0/2)sqrt(Kκ)W_pair。shift与samecell概率保实际source、E、s/L/R不变；true ℓ1 near再×2。

MG7实际无权near来源列的8sqrt(qλ)，乘原2Λ/q、Gini n/4、clock log2，再用sqrt(λ/q)<=2/sqrt3，恰给8Λlog2/√3系数。阈s0=2logn/(cn)使n e^(−cns0/2)=1，故whole-soft（含off-core）的强soft近对原remaining-positive子项确为root乘sqrtlog付款；不是只付bare sourcecolumn。原soft上门/祖维/history仍需取交，空支为0，不声称非空或比例。低soft列虽有bare价格，未抵消原n score，不能称同样交通已付。

本人实际从MG8提取执行87项有限ordinary-double标量检查，输出checks87与作者相同；它只核window比价和binomial公式，通用weak、无限混合、强soft回代由正文严格证明。不把87或AB11与原FULL实例混计。尚待主LaTeX、正式numeric、report/driver后冻结。


## 正式数值源码与说明静审（主稿整合前）

已读当前完整numeric及最终notes。40项anisot用Fraction精确比较t^n/product，rho=b只标outside witness empty、sub-D^n不一律裁空；极小aspect的n1/2分支仍可有外窗，边界方向正确。20同概率Gini检查保归一概率与k范围，仅有限score代数，不授原几何。

phi0的w积分/r积分/E3三种实现及ψ质量E4/alpha-density+boundary atom两种实现均实际参与程序比较，普通mp40/70不作向外区间。alpha_regular的分部积分号、iphi在1/2两侧常数和l0 atom都准确；257bands中只有l>=1才套密度界，8/64/256有显式正遗漏质量及一二阶log矩tail，未截尾当0。C_*极大但显式有限，不当最优常数。notes的e<=11/4也有阶乘级数几何上放证明，未拿硬编码数值冒作一般证明。

强soft的8行/84单项和4付款门行严格先判断sstar<=1；大n loggamma差导致最大precision difference约1.8974e−37已明说，不宣称40位都正确。n10^6标量付款门合法不等于满足原祖维/软上门等全部FULL资格。194显示字段与上述数学证明等级分开；本轮没有新增真实receiver/FIRST/历史合格物理模型，全部源码scope及notes明确，不重复旧轮模型。

本轮两个新门AB core与MG whole-strongsoft存在交叠，主稿若合并一般已付union，应先明确互补分配（例如先MG强soft whole，再AB core中间soft），或只给两个分别可选定理；不能拿交叠交通变成两份新credit。sum两合法上界是安全但较松的union价，不能声称逐点不交而未定义。


## 主整合终审、修复与最终结论

**PASS，无待修数学阻断，可冻结。** 主稿MG1–7逐字数学链与附件一致，新增原母式/clock/来源账节完整保留q、一次2Λ、full同y双Π、actual唯一j与W_pair来源账。core分支先付，再仅将whole-strongsoft近对用于其余未付/非core部分，交集无重复信用；原负项仍原位，未拼SOCC11或旧半密度付款。初筛要求的两新门不交分配已明确。

本审检出并由主代理修复一处重要抄录：原d_n应为1000sqrt(log(n+2)/n)，旧主整合误写1000sqrt(log(n+2))/n会放宽原soft上门。最终主稿ee04794f4987230a3dd56f4eea971dac028e567da116f9b139b85064009c17fb已实读正确，并显式补λ>0,q>0。MG附件9494fe的‘原λ,q’按此正量合同及MG7原q范围理解；作者不再改稿。MG最终仅补dimensionless D=d/a及从未付款正余量开始，数学无变。

因此本轮成功不止bare sourcecolumn：强soft门s>=2logn/(cn)的真实near ℓ1来源原完整正子交通（含off-core、score、全clock）具有明确O(sqrt(nlog(n+2)))输入质量价；core较低门另有更便宜实际付款。全部原祖维、soft上门、history及旧已付款剔除保留，子支可为空，不声称固定比例或一般weak1覆盖。低soft近对、pair互补和全局原正负母账仍未闭合。

最终数值/source/contract自绑定、两个Python AST、40个Fraction aspect guards与20个归一Gini JSON guards本人实际核对PASS。正式194个40/70字段、3混合尾阶段、257bands/256非atom密度界、8strongsoft行84项单项及4付款门与report/notes一致，max差1.8974155718687745e−37的loggamma损失明确。未新增物理receiver/FIRST/FULL实例；正式完整numeric字节重放由主代理实际执行并另存回执，不冒称本人重跑全部194字段生成。

本人本轮实际执行的有限数学代码为：audit附录φ0与5非空core标量/1空域诊断；AB8完整11项检查（输出逐行一致）；MG8完整87项普通double公式检查。代码均归档可重放，通用定理来自上文独审证明，不靠这些有限检查。report的三类证据和未付边界正确，未称一般目标闭合。

最终reproduce.py静审PASS：manifest全部前验；临时目录完整运行numeric并逐字节比较JSON；提取audit/AB/MG全部Python块执行；manifest全部后验；输出scope仅finite checks，不认证一般证明。没有源码改写、PDF编译、重建原posterior或额外安装。主代理在本audit冻结后生成最终manifest并运行包外全驱动，回执不再回写audit。

### 最终受审SHA256

不绑定audit自身，避免循环；后续版本变更需重新核对。

|文件|SHA256|
|---|---|
|task_contract.md|`e919e2ddffb81613d1776aa28882301cc92e31107d85697118dcaab791a77afc`|
|proof.tex.txt|`ee04794f4987230a3dd56f4eea971dac028e567da116f9b139b85064009c17fb`|
|actual_bridge.md|`26790f7b4f8e15edceae4bfad3517696de1f32804a738622265f35e7d230dbe2`|
|mixed_geometry.md|`9494fe34e840edae4556f0b5904a85b7fb8a62e90cf0a2929f2783bbc590b5f5`|
|report.md|`30d1d9800cdf222d55f3c1bece3c5ae5eb2097fad96b2c9a30a0b973c180eb33`|
|reproduce.py|`07909a25a37bcdf4f3b12d45fc2fc2e61654e6e5e23d3cf8116c0b798ceefbd1`|
|numeric_checks.py|`e2e7a908161a3a20568367b73730a4f7c612dd4a06bb66914a54447f60b143d2`|
|numeric_checks.json|`edceee3f9da384b6db58dade2d6427de82ce698513a14ed54eec95da5635b7f5`|
|numeric_notes.md|`3cc86ec56f1c1cfd869157b53cf1a9a5cebb3b03ff44362516718795a3802ea0`|

R257独立审计完成，audit.md冻结并停止写入。
