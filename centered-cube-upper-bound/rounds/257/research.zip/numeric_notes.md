# R257 先行有界方案

独立三类证据：Fraction anisotropic乘积/空窗分支，mpmath40/70原核phi0和强soft标量，Fraction有限共同score分布。全部不认证FULL、一般维数阶或多来源付款闭合。沿用已读取L03技能边界，普通mp不是向外舍入区间。

计划n1/2/8/64，各两种aspect（含ri=2^-32），ρ0,a/2,a,2a，共32乘积例；再8个m/u<D^n分支。该分支不先裁空，直接比较t^n与a^n prod r、b^n prod r判断窗口，以免极小aspect下错误空窗。soft阈值8个n（先检查s0≤1才断言合法soft）；Gini用20个有限分布含平衡端点取等、稀有高score、zero-score，均保完整共同posterior。等待作者稳定离散uniform混合谱/entropy矩公式后仅加少量针对检查，不扩旧diag模型。

## 最终实际范围

本轮已实际运行，未重跑旧diag/receiver模型。证据分为有限代数、真实一维核积分与明确无限正谱的有限检查；没有新增原FIRST/capture/history合格的FULL实例。

实际counts：40 anisotropic_fraction_cases（其中8 sub_D_power_branches）、20 finite_score_gini_cases、8 core soft_threshold_rows、3 mixture_truncation_stages、每精度257个mix bands（l0只含质量检查，l≥1的geometric bound checks为256）、8 strong_soft_rows及每精度84个二项单项检查、4 wholefamily_payment_threshold_rows、194个40/70显示字段。全部断言通过。三阶段如下：anisotropic初探n1/2、压力n8、扩大n64；Gini初探n2、压力n8、扩大n64/512；core soft初探n2/4/8/16、压力n64/512、扩大n10^6/10^9；混合谱按截断l8/64/256标initial/stress/expanded。所有参数完整存JSON。

## 有理各向异性窗口与Gini

a=1,b=2，D=1/(8ceil√n)，n∈{1,2,8,64}。每n有ri全1及tiny-first/two-block两种profile：后者首项2^-32，其余坐标交替1/2、2。ρ∈{0,1/2,1,2}共32例，以m/u=∏(ρri+D)构造。无需计算t的n次方根，精确Fraction核对

(m/u)/(A^n∏ri)≤∏(1+D/ri)，A=max(1,ρ)。

这是nlog(t/A)≤Σlog(1+D/ri)的正量乘积形式，方向不经浮点log判断。另8例m/u=D^n/2，不能解正ρ，仅作coreempty；仍精确比较t^n=(m/u)/∏ri与a^n,b^n。25/40例必要外窗为空；sub-D^n的tiny n1、n2两例外窗仍非空且t>b，说明“小质量比D^n”不能一律裁空。这里只核阈值优化的代数，不声称有限ri菜单证明一般L1 weak lemma。

外部见证的严格条件为R>ρ且R<t；ρ=b时外窗为空，但内部core费用仍留着。空的是必要外部见证窗口，不是把所有闭区间端点相等的核一概说成零；本菜单a1,b2，没有测试a=b的独立单尺度模型。n1/2 tiny-profile分支尤其保留极端aspect的费用。

20个共同归一score分布全部Fraction检查Σπiπj(ki−kj)+≤n/4；n2/8/64/512各含zero、平衡两端、稀有高score、三级与偏斜四级分布。平衡两端4例取等；概率和及score范围都精确核验。它们只是完整有限posterior的代数诊断，不认证原cube来源、历史或交通输入。

## 原核phi0与core门

w(v)=exp(−v)−vE1(v)（v≥0，w0=1）。原phi0用三种独立实现比较：2∫_0^.5w(v)dv、∫_0^1 2r(1−exp(−1/(2r)))dr、1−2E3(1/2)。40/70位分片普通求积及解析E3均给

phi0≈.55679127144964308526140124767563846447232920967732。

积分的微小数值差不是严格区间误差。解析phi0≤3/4来自1−phi0≥3/(4e)>1/4；e≤11/4可由k!≥2·3^(k−2)（k≥2）的几何级数上放，脚本Fraction核对3/(4·11/4)>1/4。该有限有理残差不替代正积分推导。

core s0=4logn/n对8个n检查：n2/4/8时s0>1，标合法soft支为空，不把负的c_s当原核；n16/64/512/10^6/10^9时比较n(1−s0+s0phi0)^n≤n(1−s0/4)^n≤1。采用log1p形式，避免n10^9下直接相减再乘幂损失精度。这只是原core标量支付，不代替whole softfamily分支或原历史资格。

## 正截断phi混合与未丢尾的矩

采用唯一稳定作者方案 `mixed_geometry.md` MG3：ψ=phi·1[-1.5,1.5]，ε=.5e^-4，γ=1+ε/2，v=1−ε/2，ζ=sqrt v。正measure α(dr)=−rphi'(r/2)dr/2+3phi(1.5)δ3，Rl=3γ^-l，wl=γ α((Rl/γ,Rl])、ωl=wl/ζ。l0含atom3，绝不对它使用l≥1的密度bound。

完整截断phi质量用E4闭式1−2(E4(1)−E4(2))与直接αdensity分片求积+atom独立校对，约.8779206997781991。完整Σω≈.8839667433842308<ζ≈.9977079183196936<1。这里截断是作者共同hardwindow几何所允许的ψ；本脚本不把ψ当整个实线phi的上界，也不把原phi外尾免费删除。

band regular mass不嵌套求积：α((l,h])=lphi(l/2)−hphi(h/2)+2∫_(l/2)^(h/2)phi，由E4原函数求值；l0另加边界atom。检查l0…256 positivity，l1…256检查ωl≤[9γ/(4ζ)]γ^-2l。实际最大band/bound比约.00770456；宽松bound不是实测最优谱。全部是普通mp检查，不是interval证书。

阶段截断8/64/256的partial mass约.26111231/.39332810/.79522018；正遗漏尾质量分别约.62285443/.49063864/.08874657。尾质量通过α((0,R_(L+1)])闭式保留，并与完整mass相加校对，不能把正尾当0。第一、第二log-index矩的正尾以上述几何ωbound完整求和；完整上界M1≈123.97395820、M2≈123.97482068。各阶段partial actual moments+positive tail upper均≤M1/M2。log-aspect entropy使用log(1+1/Rl)≤log(4/3)+l logγ，保留mass项与M1；不因只显示256bands而声称无限熵矩已数值求和精确。

## wholefamily强soft指数与付款门

n∈{2,16,512,10^6}、s0∈{1/4,3/4}共8行，每行测试s=s0,(1+s0)/2,1以及k端点、中点与加权二项mode（去重）；每精度共84个单项断言。验证binom(n,k)s^k(1−s)^(n−k)ζ^k≤(1−s+sζ)^n≤exp[−(1−ζ)ns0]。n10^6不枚举百万项；闭式二项总和及loggamma单项是普通高精度计算，不是随机模拟或逐坐标独立soft菜单。

另只按作者MG4.4/6及MG7公式评估n2/16/512/10^6四行Kn、C*κlog(n+2)和s*=2logn/[(1−ζ)n]。C*约2.458166780938e12，是保守且很大的显式常数，不能当实际极值或实用最优价。四行Kn上界比较均通过。s*约302.40946、151.20473、10.63158、.01205499；前三个超过1，合法strongsoft支为空。n10^6时nexp[−(1−ζ)ns*/2]=1。这里只确认付款因子的标量实现，原soft上端、唯一j、双Π、q/FIRST及来源总账的通用回代由作者/独审承担，不由这些表认证FULL。

## 精度、复现与停止边界

最终194个保存字段使用50位序列化，比较实际40/70工作精度。最大相对差1.8974155718687745e−37（分母max(1,|70位值|)），来自大n二项单项的loggamma相减/指数；不宣称40位全部正确，也不把一致性当outward interval。Fraction核心没有浮点替代；普通log/aspect与无限尾公式的显示值只作有限实现核查。一般各向异性、弱和熵及原强soft近对定理来自作者/独审证明；低soft和远sourcepair仍待付款。未追加真实receiver积分模型或推断一般阶数。

在归档解压目录执行：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
numeric_checks.py --contract task_contract.md --output numeric_checks.replay.json
```

本机实际环境Python3.12.14、mpmath1.3.0（上述vendor）。无额外安装或NumPy/SciPy/MATLAB/旧checkpoint依赖，脚本自足；JSON无时间戳、耗时或本机路径，绑定脚本/合同SHA256。所有正式检查已经实际执行；最后由主代理从包外完整逐字节重放。沿用已读取 [L03技能](/Users/zhengzhihao/.codex/skills/math-l03-rational-and-interval-certificates/SKILL.md) 的精确证书边界，没有声称该技能认证通用浮点interval API。
