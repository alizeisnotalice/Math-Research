# R257合同：各向异性极值几何与原软硬近对付款

基线R256提交9d6d4caa555c72f1d526ba8ee7bcfdc10dca3019。总目标仍为一般中心立方体弱型n^(1/2+o(1))上界，未闭合。

准确原对象：R223 JB1原正交通，q^-1 P_{s,L}(x−y)h_R(x−z)a dxβν，外2Λ EΣV,j，原同y双Π、score正差、实际Jfar/history门均保留。q∈[3λ/4,λ]；E属原Mf≤4λ，FIRST只给实际所选soft响应≤q，不给全softsup帽。P_{s,L}=L^-n∏[(1−s)h+sφ]，h=1[-1/2,1/2]，φ=h*w,w(v)=∫0¹exp(−|v|/t)dt。来源链、clock、uniquej必须原文核验。

新几何：任意source支持sideD cube、归一homothetic rectangle方面比ri>0、R∈[a,b]，证明weak价2+Σlog(1+D/(ari))。用自适应core体积而非免费仿射推导；μ=0、core参数ρ=0、短窗空及单尺度边界都保留。

主攻：利用共同hardwindow截断soft尾部，正离散uniform-interval混合总质量严格小于1，并付全部subset/方面比/无限半径熵矩；得到对任意小支持来源、全部共同soft和L的受限softmax弱价。真实selected FIRST帽结合R256shiftgrid给近soft-hard pair预算。若强soft指数能够抵消实际Gini n/4，必须完整回代score、clock、q、2Λ和来源质量才能称原正子交通已付款。lowsoft及1−P_D补量不得删除。

独立已可审核分支：core |x−y|∞≤L/2上p≤c_s^n hL，φ0≤3/4，s≥4logn/n则n c_s^n≤1，原positive近pair可付款。它作为真实部分保留，不代替主攻whole softfamily。

任务分工：peak仅mixed_geometry.md；compare仅actual_bridge.md（原定义与准确回代）；audit仅audit.md（独立先审命题后读稿）；numeric仅numeric_checks.py/json与numeric_notes.md；主代理合同、LaTeX、报告、复现及提交。多人共享，不覆盖其他文件，不由子Agent做git/PDF。

允许已证工具：R251小支持几何；R255粗来源能量；R256真实接收近对；原R117/R128/R223定义及R237sourceledger；通用Tonelli/弱型和界须给完整费用。禁止R222去hR后凭空恢复，禁止actualcap当supcap，禁止数值认证一般阶或免费soft菜单。L03严格分Fraction证书与普通mp精度。

每项核心策略按初探、压力、扩大范围进行本机计算；归档包含准确有限范围、原模型与仅代数诊断区别。重要未证连接保持显式。完成本轮独审/复现后单独提交并推送origin/main，控制文件数量、不编译PDF。
