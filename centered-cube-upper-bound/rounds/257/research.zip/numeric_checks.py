#!/usr/bin/env python3
"""R257 bounded algebra/kernel diagnostics. Fraction is exact; mpmath is not interval."""
import argparse,hashlib,itertools,json,math
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fs(x):return str(x.numerator)+'/'+str(x.denominator)
def enc(x):return mp.nstr(x,50)
def m(x):return mp.mpf(x.numerator)/x.denominator if isinstance(x,F)else mp.mpf(x)
def prod(v):
    out=F(1)
    for x in v:out*=x
    return out

def anisotropic():
    rows=[]
    for n in [1,2,8,64]:
        D=F(1,8*(math.isqrt(n)+(math.isqrt(n)**2<n)));phase='initial'if n<=2 else'stress'if n==8 else'expanded'
        for profile in ['isotropic','tiny_first_two_block']:
            r=[F(1)]*n if profile=='isotropic'else [F(1,2)if j%2==0 else F(2)for j in range(n)]
            if profile!='isotropic':r[0]=F(1,2**32)
            volume=prod(r);rhs=prod(1+D/v for v in r)
            for rho in [F(0),F(1,2),F(1),F(2)]:
                mass_over_u=prod(rho*v+D for v in r);A=max(F(1),rho)
                lhs=mass_over_u/(A**n*volume)
                assert lhs<=rhs
                is_empty=(rho>=2 or mass_over_u<=A**n*volume)
                rows.append({'phase':phase,'n':n,'profile':profile,'r':list(map(fs,r)),'D':fs(D),'rho':fs(rho),'mass_over_u':fs(mass_over_u),'A':fs(A),'t_power_n':fs(mass_over_u/volume),'threshold_ratio_power':fs(lhs),'entropy_product_upper':fs(rhs),'empty_necessary_open_outer_window':is_empty,'branch':'rho_ge_b'if rho>=2 else't_le_A'if mass_over_u<=A**n*volume else't_ge_b'if mass_over_u>=F(2)**n*volume else'A_lt_t_lt_b','sub_D_power_branch':False})
            # No positive rho solves the core-volume equation in this branch.
            mass_over_u=D**n/2;A=F(1);lhs=mass_over_u/volume
            assert lhs<=rhs
            rows.append({'phase':phase,'n':n,'profile':profile,'r':list(map(fs,r)),'D':fs(D),'rho':'0/1','mass_over_u':fs(mass_over_u),'A':'1/1','t_power_n':fs(lhs),'threshold_ratio_power':fs(lhs),'entropy_product_upper':fs(rhs),'empty_necessary_open_outer_window':mass_over_u<=volume,'branch':'t_le_a'if mass_over_u<=volume else't_ge_b'if mass_over_u>=F(2)**n*volume else'a_lt_t_lt_b','sub_D_power_branch':True})
    return rows

def gini_cases():
    rows=[]
    for n in [2,8,64,512]:
        for name,scores,prob in [('zero',[0],[F(1)]),('balanced',[0,n],[F(1,2)]*2),('rare_high',[0,n],[F(99,100),F(1,100)]),('three_level',[0,n//2,n],[F(1,4),F(1,2),F(1,4)]),('skew_four',[0,n//4,n//2,n],[F(1,100),F(49,100),F(49,100),F(1,100)])]:
            assert sum(prob)==1 and all(0<=v<=n for v in scores)
            J=sum((p*q*max(0,x-y)for p,x in zip(prob,scores)for q,y in zip(prob,scores)),F(0));assert J<=F(n,4)
            rows.append({'phase':'initial'if n==2 else'stress'if n==8 else'expanded','n':n,'name':name,'scores':scores,'probabilities':list(map(fs,prob)),'full_positive_pair_score':fs(J),'bound':fs(F(n,4)),'margin':fs(F(n,4)-J),'scope':'A finite common normalized score distribution; no FULL qualification.'})
    return rows

def kernel_and_soft(dps):
    with mp.workdps(dps):
        w=lambda v:mp.mpf(1)if v==0 else mp.exp(-v)-v*mp.e1(v)
        direct=2*mp.quad(w,[0,mp.mpf('.001'),mp.mpf('.1'),mp.mpf('.5')])
        by_r=mp.quad(lambda r:2*r*(1-mp.exp(-mp.mpf('.5')/r))if r else 0,[0,mp.mpf('.01'),mp.mpf('.25'),1])
        expint=1-2*mp.expint(3,mp.mpf('.5'))
        assert abs(direct-by_r)<mp.mpf('1e-35')and abs(direct-expint)<mp.mpf('1e-35')and direct<mp.mpf(3)/4
        eupper=F(11,4);assert F(3,4)/eupper>F(1,4)
        out={'phi0_direct_w_integral':enc(direct),'phi0_r_integral':enc(by_r),'phi0_E3':enc(expint),'phi0_quadrature_internal_difference':enc(abs(direct-by_r)),'analytic_e_rational_upper':fs(eupper),'analytic_phi0_upper':'3/4','soft_rows':[]}
        for n in [2,4,8,16,64,512,10**6,10**9]:
            s0=4*mp.log(n)/n;qualified=s0<=1
            row={'phase':'initial'if n<=16 else'stress'if n<=512 else'expanded','n':n,'s0':enc(s0),'legal_soft_threshold':qualified}
            if qualified:
                actual=mp.exp(mp.log(n)+n*mp.log1p(-s0*(1-direct)));upper=mp.exp(mp.log(n)+n*mp.log1p(-s0/4))
                assert actual<=upper<=1
                row.update({'n_actual_height':enc(actual),'n_analytic_height_upper':enc(upper)})
            else:row['scope']='s0>1: empty soft branch, not a qualified soft threshold.'
            out['soft_rows'].append(row)
        return out

def numeric_anisot(rows,dps):
    with mp.workdps(dps):
        out=[]
        for i,v in enumerate(rows):
            lhs=mp.log(m(F(v['threshold_ratio_power'])));rhs=mp.log(m(F(v['entropy_product_upper'])))
            assert lhs<=rhs
            out.append({'case':i,'log_threshold_ratio':enc(lhs),'sum_log_aspect_upper':enc(rhs)})
        return out

def positive_mixture(dps):
    with mp.workdps(dps):
        eps=mp.exp(-4)/2;gamma=1+eps/2;v=1-eps/2;zeta=mp.sqrt(v);logg=mp.log(gamma);qg=gamma**-2
        E=lambda j,x:mp.expint(j,x)
        def phi(x):
            x=abs(x)
            return 1-E(3,mp.mpf('.5')+x)-E(3,mp.mpf('.5')-x)if x<=mp.mpf('.5')else E(3,x-mp.mpf('.5'))-E(3,x+mp.mpf('.5'))
        def iphi(x):
            return x+E(4,mp.mpf('.5')+x)-E(4,mp.mpf('.5')-x)if x<=mp.mpf('.5')else mp.mpf('.5')-E(4,x-mp.mpf('.5'))+E(4,x+mp.mpf('.5'))
        def alpha_regular(lo,hi):return lo*phi(lo/2)-hi*phi(hi/2)+2*(iphi(hi/2)-iphi(lo/2))
        atom=3*phi(mp.mpf('1.5'));truncated=1-2*(E(4,1)-E(4,2))
        wfun=lambda x:mp.mpf(1)if x==0 else mp.exp(-abs(x))-abs(x)*mp.e1(abs(x))
        density=lambda r:r*(wfun((r-1)/2)-wfun((r+1)/2))/2
        direct=mp.quad(density,[0,mp.mpf('.5'),1,2,3])+atom
        fullomega=gamma*truncated/zeta
        assert abs(direct-truncated)<mp.mpf('1e-34')
        assert truncated<1-eps and fullomega<=zeta<1
        C=9*gamma/(4*zeta)
        M1=C*logg*qg/(1-qg)**2;M2=C*logg**2*qg*(1+qg)/(1-qg)**3
        omegas=[];maxbandratio=mp.mpf(0)
        for level in range(257):
            upper=3*gamma**(-level);lower=upper/gamma
            aa=alpha_regular(lower,upper)+(atom if level==0 else 0);om=gamma*aa/zeta
            assert om>=0
            if level>=1:
                ratio=om/(C*qg**level);assert ratio<=1;maxbandratio=max(maxbandratio,ratio)
            omegas.append(om)
        stages=[]
        for phase,L in [('initial',8),('stress',64),('expanded',256)]:
            partial=sum(omegas[:L+1]);Rtail=3*gamma**(-(L+1));tailmass=gamma*alpha_regular(mp.mpf(0),Rtail)/zeta
            assert abs(partial+tailmass-fullomega)<mp.mpf('1e-32')
            p1=sum(om*(j*logg)for j,om in enumerate(omegas[:L+1]));p2=sum(om*(j*logg)**2 for j,om in enumerate(omegas[:L+1]))
            start=L+1
            tail1=C*logg*qg**start*(start/(1-qg)+qg/(1-qg)**2)
            tail2=C*logg**2*qg**start*(start**2/(1-qg)+2*start*qg/(1-qg)**2+qg*(1+qg)/(1-qg)**3)
            assert p1+tail1<=M1 and p2+tail2<=M2
            aspect=sum(om*mp.log(1+gamma**j/3)for j,om in enumerate(omegas[:L+1]))
            stages.append({'phase':phase,'last_level':L,'partial_mass':enc(partial),'positive_omitted_tail_mass':enc(tailmass),'complete_mass':enc(fullomega),'partial_log_index_moment1':enc(p1),'partial_log_index_moment2':enc(p2),'positive_tail_moment1_upper':enc(tail1),'positive_tail_moment2_upper':enc(tail2),'completed_moment1_upper':enc(p1+tail1),'completed_moment2_upper':enc(p2+tail2),'partial_log_aspect_entropy':enc(aspect)})
        strong=[]
        for n in [2,16,512,10**6]:
            for s0 in [mp.mpf('.25'),mp.mpf('.75')]:
                bound=mp.exp(-(1-zeta)*n*s0);maxterm=mp.mpf(0);maxsum=mp.mpf(0);checks=0
                for ss in [s0,(1+s0)/2,mp.mpf(1)]:
                    complete=mp.exp(n*mp.log1p(-ss*(1-zeta)));assert complete<=bound;maxsum=max(maxsum,complete/bound)
                    mode=int(mp.floor((n+1)*ss*zeta/(1-ss+ss*zeta)))
                    for k in sorted({0,n//2,n,min(n,mode)}):
                        if ss==1:term=zeta**n if k==n else mp.mpf(0)
                        else:term=mp.exp(mp.loggamma(n+1)-mp.loggamma(k+1)-mp.loggamma(n-k+1)+k*mp.log(ss*zeta)+(n-k)*mp.log1p(-ss))
                        assert term<=bound;maxterm=max(maxterm,term/bound);checks+=1
                strong.append({'n':n,'s0':enc(s0),'term_checks':checks,'exponential_bound':enc(bound),'max_term_over_bound':enc(maxterm),'max_binomial_sum_over_bound':enc(maxsum)})
        u0=1-zeta;A0=3+4*mp.log(2);c0=1+(-mp.log(1-1/gamma)+mp.log(2))/mp.log(3)
        Cstar=A0/(u0*mp.log(3))+2*c0*zeta/u0**2+(A0/2+2)*M1/(u0**2*mp.log(3))+c0*M1*(1+zeta)/u0**3+M2/(u0**2*mp.log(3))+2*M1**2/(u0**3*mp.log(3))
        payment=[]
        for n in [2,16,512,10**6]:
            D=1/(8*mp.sqrt(n));kappa=2+n*mp.log1p(D);Cn=mp.log(2)+mp.log(n+1)-mp.log(1-1/gamma)
            Kn=kappa*(A0/u0+2*Cn*zeta/u0**2)+(A0+2*kappa)*M1/u0**2+2*Cn*M1*(1+zeta)/u0**3+2*M2/u0**2+4*M1**2/u0**3
            upper=Cstar*kappa*mp.log(n+2);assert Kn<=upper
            sstar=2*mp.log(n)/(u0*n);row={'n':n,'sstar':enc(sstar),'legal_soft_threshold':sstar<=1,'K_n':enc(Kn),'K_n_global_upper':enc(upper),'K_over_global_upper':enc(Kn/upper)}
            if sstar<=1:
                factor=mp.exp(mp.log(n)-u0*n*sstar/2);assert abs(factor-1)<mp.mpf('1e-35');row['n_times_exponential_payment_factor']=enc(factor)
            else:row['scope']='sstar>1: empty selected strong-soft branch; no payment model instantiated.'
            payment.append(row)
        return {'Cstar':enc(Cstar),'wholefamily_payment_threshold_rows':payment,'epsilon':enc(eps),'gamma':enc(gamma),'zeta':enc(zeta),'truncated_phi_mass_E4':enc(truncated),'truncated_phi_mass_direct_alpha':enc(direct),'complete_omega_mass':enc(fullomega),'omega_mass_upper':enc(zeta),'omega0':enc(omegas[0]),'moment1_global_upper':enc(M1),'moment2_global_upper':enc(M2),'log_aspect_entropy_global_upper':enc(mp.log(mp.mpf(4)/3)*fullomega+M1),'max_checked_band_over_bound':enc(maxbandratio),'stages':stages,'strong_soft_rows':strong,'scope':'Positive truncated-phi uniform-interval mixture; finite band diagnostics retain explicit positive omitted mass/moment bounds. Not FULL or original source-capacity proof.'}

def numericfields(obj,prefix=''):
    out={}
    if isinstance(obj,dict):
        for k,v in obj.items():
            if isinstance(v,str)and k not in ['scope','analytic_e_rational_upper','analytic_phi0_upper']:
                try:out[prefix+k]=mp.mpf(v)
                except ValueError:pass
            elif isinstance(v,(dict,list)):out.update(numericfields(v,prefix+k+'/'))
    elif isinstance(obj,list):
        for i,v in enumerate(obj):out.update(numericfields(v,prefix+str(i)+'/'))
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));ap.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md'));a=ap.parse_args();ar=anisotropic();g=gini_cases();lo={'kernel':kernel_and_soft(40),'anisotropic':numeric_anisot(ar,40),'positive_mixture':positive_mixture(40)};hi={'kernel':kernel_and_soft(70),'anisotropic':numeric_anisot(ar,70),'positive_mixture':positive_mixture(70)}
    with mp.workdps(100):
        x=numericfields(lo);y=numericfields(hi);assert x.keys()==y.keys();diff=[abs(x[k]-y[k])/max(1,abs(y[k]))for k in x];maxdiff=enc(max(diff));assert max(diff)<mp.mpf('1e-34')
    result={'schema':'R257-bounded-anisotropic-soft-v1','script_sha256':sha(__file__),'contract_sha256':sha(a.contract),'counts':{'anisotropic_fraction_cases':len(ar),'sub_D_power_branches':sum(v['sub_D_power_branch']for v in ar),'finite_score_gini_cases':len(g),'soft_threshold_rows':len(hi['kernel']['soft_rows']),'precision_fields_compared':len(diff),'mixture_truncation_stages':len(hi['positive_mixture']['stages']),'mixture_bands_checked_per_precision':257,'mixture_geometric_band_checks_per_precision':256,'wholefamily_payment_threshold_rows':len(hi['positive_mixture']['wholefamily_payment_threshold_rows']),'strong_soft_rows':len(hi['positive_mixture']['strong_soft_rows']),'strong_soft_term_checks_per_precision':sum(v['term_checks']for v in hi['positive_mixture']['strong_soft_rows'])},'anisotropic_cases':ar,'gini_cases':g,'mp40':lo,'mp70':hi,'precision_max_relative_difference':maxdiff,'scope':'Finite algebra and actual one-coordinate kernel integration. No FULL, no source independence assumption, no general dimension-order proof. MP is ordinary quadrature, not outward interval.'}
    a.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':result['counts'],'maxdiff':maxdiff}))
if __name__=='__main__':main()
