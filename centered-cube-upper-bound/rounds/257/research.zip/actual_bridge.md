# R257: original positive soft-core near-pair traffic, with score and clock paid

The proved new payment concerns a positive share of the actual remaining
traffic before hard-source elimination. It retains the true source pair,
the original receiver, its two scales, and the full posterior clock. It
does not assert payment of the soft-core complement or all soft degrees.
Only this file is changed. No negative credit is used.

## AB1. Narrow original-source audit

All line references are to the indicated frozen files, not an assembled
proof containing embedded copies.

| Original file and lines | Retained fact |
|---|---|
| [R116 astra_first.md:9–16](/Users/zhengzhihao/Desktop/T/output/centered_cube_round116_20261014/astra_first.md:9) | `h=1[-1/2,1/2]`, `w(v)=integral_0^1 exp(-|v|/r)dr`, `phi=h*w`, and `P_s,L(v)=L^-n product[(1-s)h(v_i/L)+s phi(v_i/L)]`. The same scalar s is used in all coordinates. Both w and phi have integral one; phi<=1. |
| [R117 joint_geometry.md:5](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:5) | The actual remainder inherits `s<=1-d_n`, `L<=b-2a/n`, `d_n=1000 sqrt(log(n+2)/n)`, and `n>4*10^6 log(n+2)`. The underlying closed-family formula allows `s in [0,1]`, `a<=L,R<=b<=2a`; inherited actual gates remain in place. |
| [R128 proof.md:14,35](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:14) | The actual strict-soft domain also retains `s>1-2^(-1/n)`; the pure-hard `s=0` boundary is not an actual remaining input. Our new positive restriction does not discard or alter this original gate. |
| [R128 proof.md:604–630](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:604) | RT1–3 give the actual measure `q^-1 p_y h_R a_omega dx beta_V(dy)nu_V(dz)` with original finite truncation, unique `j(x)`, `0<=a_omega<=1`, common `3lambda/4<=q<=lambda`; the positive mother quantity has outer factor `2Lambda`, `Lambda=128/119`. |
| [R128 proof.md:636–650](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:636) | `gamma=1+1/n`, `c_j=gamma^-j`, `g=sqrt(LR)`, `tau_j=a/c_j<=g<=b c_j`, `h=g exp(-u/n)<=g`, and `J_far=I_(j,V,y) intersect [tau_j,h]`. RT4 defines the true normalized posterior, rather than an independent replacement source. |
| [R117 joint_geometry.md:15–30,71–74](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:15) | `Pi_t=1_Zt w_t nu/e_t` is a probability on nonempty heavy rows; `k_t=# {i:A_i<t}` lies in `[0,n]`. The heavy domain is an initial interval. Empty rows contribute zero. |
| [R222 weight_contract.md:27–42,82–94](/Users/zhengzhihao/Desktop/T/output/centered_cube_round222_20261016_final_checkpoint/weight_contract.md:27) | The actual RN factor has a jointly measurable version in `[0,1]`. Removing it from a positive upper bound requires retaining the genuine receiver E and every capacity qualification used there. |
| [R244 receiver_ledger.md:9–27](/Users/zhengzhihao/Desktop/T/output/centered_cube_round244_20261017_final_checkpoint/receiver_ledger.md:9) | The exact ancestor is `GENERAL_CURRENT_REDUCTION.md:5–13`: `G_0=sup_(a<=R<=b) h_R*f` and `2lambda<G_0<=4lambda` on E. Thus the inherited hard cap is for every scale in `[a,b]`, including both actual L and actual R used in AB2; it is not inferred from a selected-R inequality. |
| [R223 joint_budget.md:9–27,104–119](/Users/zhengzhihao/Desktop/T/output/centered_cube_round223_20261016_final_checkpoint/joint_budget.md:9) | JB1 keeps hard z and soft y before SOCC11; positive-only gates can be removed upwards, whereas signed negative terms cannot receive those new gates. The two posterior factors already contain both powers of `e_t^-1`. |

The actual selectors L(x),R(x),s(x), and j(x) are fixed by receiver and
the original outer data; they are not reselected by soft y, hard z, or
auxiliary v,u. Posterior Pi_t still depends on the same y and j. Nothing
below asserts a product law for its coordinates.

## AB2. The two-scale hard-source budget needed here

Fix one outer seed and leaf V, and a genuine receiver subset E_V with
`M_[a,b] f<=4lambda`, where `a<=b<=2a`. Take original sources
`beta_V,nu_V<=f`, finite positive L1, and actual measurable L(x),R(x)
in `[a,b]`. Fix D>0 and

    P_D(y-z)=product_i(1-|y_i-z_i|/D)_+,
    kappa_D=min{(1+D/a)^n,2+n log(1+D/a),1+n log(b/a)}.

For each source-shift s in `[0,D)^n`, restrict both sources to the same
half-open D-cells C. Write

    Z_LR,D(x)=integral h_L(x-y)h_R(x-z)P_D(y-z)beta(dy)nu(dz).

The same-cell probability identity from R256 is valid with these two
different actual scales, since both are independent of the source
integration variables:

    Z_LR,D(x)=average_shift sum_C
                    (h_L*beta_C)(x)(h_R*nu_C)(x).              (AB1)

For each cell, `h_L*beta_C<=M beta_C<=4lambda` on E_V, and the analogous
statement holds for nu and R. R251's package weak bound and layer cake
therefore give

    integral_E_V (h_L*beta_C)^2 dx<=8lambda kappa_D ||beta_C||,
    integral_E_V (h_R*nu_C)^2 dx<=8lambda kappa_D ||nu_C||.

Cauchy--Schwarz first in `(x,shift,C)`, then mass additivity, prove

    integral_E_V Z_LR,D dx
         <=8lambda kappa_D sqrt(||beta_V||||nu_V||).           (AB2)

This is R256 CP8's same proof, not an assumption that L=R. The actual
all-hard-scale cap on E is essential. No source-dependent new scale is
chosen. It is also legitimate to use the finer R256 per-cell energy/weak
minimum here, but AB2 is the source-priced bound used below.

## AB3. Soft-core height: the exact constant and a simple sufficient gate

Let `m_phi=phi(0)`. Since w is even and decreases on the positive half
line, `phi'(v)=w(v+1/2)-w(v-1/2)<=0` for v>=0 (almost everywhere,
or by integrating the translated interval directly). Thus phi<=m_phi.
Tonelli evaluates its exact scalar formula:

    m_phi=integral_0^1 2r(1-exp(-1/(2r)))dr
         =1-2 integral_0^1 r exp(-1/(2r))dr.                  (AB3)

In particular

    1-m_phi >=2 exp(-1) integral_(1/2)^1 r dr
             =3/(4e)>1/4,
    c(s):=1-s+s m_phi<=1-s/4.                               (AB4)

The last strict inequality uses the elementary `e<3`; weak versions
suffice throughout. On the actual soft-source hard core

    C_y(x):={||x-y||_infty<=L(x)/2}

one has the genuine pointwise comparison

    1_C_y p_y(x)<=c(s(x))^n h_{L(x)}(x-y).                   (AB5)

This does not hold without the core indicator. In particular the
positive soft tails have not been replaced by a hard cube kernel.

Fix any s0 in `[0,1]` and restrict to the actual receiver subset
`E_V(s0)={x in E_V:s(x)>=s0}`. Then the height factor in AB5 is bounded
by `chi0=c(s0)^n`. For n>=2, the simple sufficient threshold

    s0=4 log(n)/n<=1  ==> n chi0<=1                         (AB6)

follows from `(1-s0/4)^n<=exp(-n s0/4)=1/n`. If the stated threshold
exceeds 1, or conflicts with an original gate, the subdomain is empty;
no existing source or selector is changed. The actual high-dimensional
ancestral range is consistent with the threshold, but no FULL instance
is inferred merely from that consistency.

## AB4. Original positive functional and its two separately paid layers

Start with the currently unpaid positive part in a legal original
finite truncation I, after removing all positive subparts already paid.
For fixed x,y,z,V,j, let

    W_j(x,y,z)=integral_Jfar dt/t
       integral Pi_(j,V,y,t)(dv)Pi_(j,V,y,t)(du)
                         Theta_I(x,y,z,v,u,t) [k_t(v)-k_t(u)]_+,

where Theta_I is the product of the original high/good/bad, suffix,
FA, capture remainder and still-retained history indicators/weights;
every such positive factor lies in `[0,1]`. Any factor already outside
the displayed clock integral may equivalently be kept there. This
definition retains the exact two posteriors with their full normalizer.
It never replaces them by unnormalized nu or by a product-coordinate law.

The actual allocated positive quantity with the probabilistic near-pair
weight is

    P_core,D(s0)=2Lambda E sum_(V,j) integral_E_V(s0) dx/q
       integral beta_V(dy)nu_V(dz)
       1_{j(x)=j} a_omega(x,y,z) 1_C_y(x)
                         p_y(x)h_R(x-z) P_D(y-z) W_j(x,y,z). (AB7)

All source gates in a_omega, including the original y--hard-z relation,
remain in AB7. It is a positive share of the original remaining traffic,
since `1_C_y P_D 1_{s>=s0}` lies in `[0,1]`. It is not a new FULL input.

First, before any score/history factor is inserted, AB2 and AB5 give
the raw source-measure price (with no outer `2Lambda`)

    E sum_(V,j) integral q^-1 p_y h_R a_omega
               1_j 1_C_y 1_{s>=s0} P_D dx beta_V nu_V
       <=(32/3) chi0 kappa_D W_pair,
    W_pair:=E sum_V sqrt(||beta_V||||nu_V||).                 (AB8)

AB8 alone does not pay AB7: its clock/history density is not bounded by
one. The following uniform original-clock bound is what pays that layer.

## AB5. Score and clock really included

For any probability law of a random variable K in `[0,n]`, independent
copies K,K' satisfy

    E(K-K')_+=integral_0^n Pr(K>r)Pr(K<=r)dr<=n/4.           (AB9)

The first identity follows by layer cake and symmetry, or by integrating
`1_{K>r>=K'}`. Applied at each actual posterior Pi_t, it requires no
independence among the coordinates of k_t. Since Theta_I<=1, it bounds
the original gated double-posterior score from above.

For the actual j selected at x, R128 RT4 gives

    J_far subset [tau_j,h], tau_j=a/c_j, h<=g<=b c_j,
    length_log(J_far)<=log(b c_j^2/a)<=log(b/a)<=log2.        (AB10)

Empty windows contribute zero. This uses the actual tau_j, not a
replacement lower endpoint. Restricting further by heavy/history can
only shorten the positive integral. Hence for every actual x,y,z,j,

    W_j(x,y,z)<=n log2/4.                                  (AB11)

This bound is uniform in every source variable and actual j. Thus in
the nonnegative integral we may first replace W_j by this same bound,
then use `sum_j 1_{j(x)=j}=1` pointwise, and only then apply AB2.
There is no extra j-count, independent-clock construction, or uncharged
interchange of a selector with an unbounded clock integral.

Combining AB2, AB5, AB7 and `lambda/q<=4/3` gives the fully normalized
original-positive bound

    P_core,D(s0)
       <=(16 Lambda log2/3) n chi0 kappa_D W_pair.           (AB12)

In particular, at `D=d=a/(8sqrt(n))` and on the actual soft gate AB6,

    P_core,d(s0)
       <=(16 Lambda log2/3)(2+sqrt(n)/8) W_pair.            (AB13)

This pays the stated actual positive subpart including score, full
clock, original `q^-1`, and the one original `2Lambda`. No epsilon X
error is needed. All original histories may reduce this price; none is
asserted to survive as a new unrestricted source capacity.

If the probabilistic weight P_D in AB7 is replaced by the actual metric
indicator `1_{||y-z||_1<=D/2}`, then `1_near<=2P_D`, and AB12--13 hold
with an additional factor two. Thus the strict actual near-pair/core
positive subtraffic has price

    P_core,near,d(s0)
       <=(32 Lambda log2/3)(2+sqrt(n)/8) W_pair.            (AB14)

The weighted-pair complement `1-P_D` includes unretained nearby pairs.
The indicator-near formulation leaves its genuine distance complement.
Neither complement is paid by the corresponding estimate.

## AB6. Original source mass and the recovery constant, counted once

The applicable coupled branch has `nu_V<=beta_V<=alpha_V`, where
`alpha_V=mu_hi,omega|V`; R113 coupled_transport.md:51--72 proves the
pointwise domination, and its lines 76--84 preserve the original hard
source/history. The retained V are disjoint for each full seed. Set

    W_A:=E sum_V ||alpha_V||,
    W_beta:=E sum_V ||beta_V||.

This explicitly defines W_A rather than identifying an ambiguous mass
symbol with `||f||_1`. From the actual source domination and disjointness,

    W_pair<=W_beta<=W_A<=W_hi:=E||mu_hi,omega||<=||f||_1.     (AB15)

The exact definitions/source budget are R113 joint_budget.md:15--22
(B2), R107 integration.md:226--232 (disjoint original alpha leaves),
and R237 source_ledger.md:82--100 (SL4 and recovery). In particular all
bounds AB12--14 may charge the original W_A, or retain the smaller
W_pair. This does not move the new charge into a previously paid source
slot or take its maximum with an earlier coefficient.

The common-leaf seed is averaged as a probability seed. Its genuine
row recovery is `Lambda=128/119`, as R237 SL3 documents from R107 and
R128 RT3. AB7 already includes the entire original `2Lambda`; AB12--14
must not be multiplied by Lambda again. Earlier root, soft extraction,
and negative/source credits remain on their original separate ledger.

## AB7. Exact interface boundary

This proof starts from JB1 before hard-z integration. R222 SOCC11 has
already integrated h_R nu and encoded original gates in eta; one cannot
start from that later formula and insert a new h_R or a new P_D(y-z).
Nor can AB8's raw source price be mistaken for the score-paid AB12.

The actual positive subpart paid in AB13 is specified by three things:
the original soft-source hard core, the probabilistic same-cell pair
weight, and the stated actual soft gate. AB14 instead pays the genuine
metric near-pair indicator with twice the price. All original selectors,
posterior laws, hard source and source history are unchanged. Outside
the soft gate, AB12 retains the full factor `n c(s0)^n`; it is not
uniformly root-order. The off-core soft kernel requires a separate
soft--hard near-pair estimate. None is obtained by replacing phi by h.
The current independent companion route may establish such an estimate;
this file does not presume it. Original negative credits are unconsumed
by this positive payment and may be used only once in their own domains.

## AB8. Bounded local mathematical checks

Python with local mpmath 1.3.0 at 60 decimal digits was actually run.
The quadrature value for phi(0) is numerical evidence, not an interval
certificate; AB3--4 prove the needed bound analytically. The exact
Fraction posterior tests verify AB9 on two finite laws at each listed
n. The scalar gate checks are diagnostics, not a construction of a
FULL original input. In particular n=512 and 10^6 fail the actual
ancestral dimension gate and are labelled accordingly.

```python
import sys
sys.path.insert(0, '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
from fractions import Fraction as F
mp.mp.dps = 60
m = mp.quad(lambda r: 2*r*(1-mp.exp(-1/(2*r))) if r else 0,
            [0, mp.mpf('.5'), 1])
print('phi0', mp.nstr(m, 52))
print('tail_gamma', mp.nstr(1-m, 52))
print('analytic_tail_lower', mp.nstr(3/(4*mp.e), 52))
checks = 0
for n in [1, 2, 4, 7]:
    for weights in [[F(1,n+1)]*(n+1),
                    [F(1,2)]+[F(0)]*(n-1)+[F(1,2)]]:
        score = sum(weights[i]*weights[j]*max(i-j,0)
                    for i in range(n+1) for j in range(n+1))
        assert score <= F(n,4)
        checks += 1
for n in [512, 10**6, 10**9]:
    s0 = 4*mp.log(n)/n
    gain = n*mp.power(1-s0/4,n)
    assert gain <= 1
    checks += 1
    print('n',n,'s0',mp.nstr(s0,22),'n_upperheight',mp.nstr(gain,22),
          'ancestral_dimension_gate',bool(n>4*10**6*mp.log(n+2)))
print('PASS',checks,'bounded checks; phi quadrature is numerical, not interval')
```

Actual output:

```text
phi0 0.5567912714496430852614012476756384644723292096773181
tail_gamma 0.4432087285503569147385987523243615355276707903226819
analytic_tail_lower 0.2759095808785817411966428276210956505843583482738259
n 512 s0 0.0487369111331211545684 n_upperheight 0.9624086396005351911896 ancestral_dimension_gate False
n 1000000 s0 0.00005526204223185709641643 n_upperheight 0.9999045695088001697226 ancestral_dimension_gate False
n 1000000000 s0 8.289306334778564462465e-8 n_upperheight 0.9999997852731466128775 ancestral_dimension_gate True
PASS 11 bounded checks; phi quadrature is numerical, not interval
```
