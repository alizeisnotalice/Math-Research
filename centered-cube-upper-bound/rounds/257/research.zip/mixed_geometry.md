# R257：共同硬窗口内的全软度近来源付款

## MG1. 准确对象与新结论

令 \(n\ge1\)、\(0<a\le b\le2a\)、\(0<d\le a/2\)，\(h_R\) 为完整边长 \(R\) 的归一中心立方体核。原软核是
\[
 w(u)=\int_0^1e^{-|u|/t}dt,\quad \varphi=h_1*w,\quad
 P_{s,L}(x)=L^{-n}\prod_{i=1}^n[(1-s)h_1(x_i/L)+s\varphi(x_i/L)].
\]
这里 \(w\) 的积分为一，\(0\le\varphi\le1\)，\(\varphi\) 偶且递减于正半轴。所有软坐标使用同一个 \(s\)。

设 \(\beta,\nu\) 是原非负有限 \(L^1\) 子来源，\(E\) 为真实接收域，\(s(x),L(x),R(x)\) 是原共同接收选择器，\(s(x)\in[s_0,1]\)、\(L,R\in[a,b]\)。仅假设原来已授的两个帽：
\[
 P_{s(x),L(x)}*\beta(x)\le q,\qquad
 M_{[a,b]}\nu(x)\le4\lambda\quad(x\in E). \tag{MG1.1}
\]
第一个帽只用于 **actual selected** 响应，不用于所有软度的上确界。

记 \(P_d(v)=\prod_i(1-|v_i|/d)_+\)、\(W_\beta=\|\beta\|\)、\(W_\nu=\|\nu\|\)，以及
\[
 Z_d(x)=\iint P_{s(x),L(x)}(x-y)h_{R(x)}(x-z)P_d(y-z)\,d\beta(y)d\nu(z).
\]
下文给出显式绝对常数 \(C_*<\infty\)、\(c>0\)，证明
\[
 \int_E Z_d\le4\sqrt{q\lambda}\,e^{-cns_0/2}
 \sqrt{C_*}\,\kappa_d\sqrt{\log(n+2)}\sqrt{W_\beta W_\nu},
 \quad \kappa_d=2+n\log(1+d/a). \tag{MG1.2}
\]
真实近对 \(\|y-z\|_1\le d/2\) 的同一积分不带 \(P_d\) 时，右边乘二。取 \(d=a/(8\sqrt n)\)，得到一般全软度、全物理选择器的根阶乘 \(\sqrt{\log(n+2)}\) **来源列** 付款。MG7 再支付原 score/clock 后得到一个包含 off-core 的原强软度近对交通分支；没有宣称低软度或远来源已付。

## MG2. 各向异性单簇弱型：独立证明

对任意 \(r_i>0\)，令
\[
 H_R^{\mathbf r}(x)=\frac{1_{\{|x_i|\le Rr_i/2\ \forall i\}}}{R^n\prod_i r_i}.
\]
若 \(\sigma\) 支撑于中心 \(z\)、完整边长 \(d\) 的立方体且质量为 \(m\)，则
\[
 u|\{\sup_{a\le R\le b}H_R^{\mathbf r}*\sigma>u\}|
 \le m\left[2+\sum_i\log\left(1+\frac d{ar_i}\right)\right]. \tag{MG2.1}
\]
这不是把各向同性结果直接作仿射变换所得。

证明。\(m=0\) 时平凡。令 \(t^n\prod_i r_i=m/u\)。超过阈值的见证尺度必须满足 \(R<t\)。若 \(t\le a\)，超水平集为空。

若 \(m/u\ge d^n\)，取唯一 \(\rho\ge0\) 使
\(\prod_i(\rho r_i+d)=m/u\)。中心为 \(z\)、边长为 \(\rho r_i+d\) 的矩形体积恰为 \(m/u\)。其外任一接收点若与来源在某个见证矩形相交，则某坐标距离说明 \(R>\rho\)。故外部只需尺度窗
\([\max(a,\rho),\min(b,t)]\)。当此窗非空时，归一同心矩形核的逐点尺度上确界积分为
\(1+n\log(\min(b,t)/\max(a,\rho))\)。这是径向壳层直接积分，或仿射变换下的归一立方体壳层公式。Tonelli 加 Markov 付一次 \(m\)。若 \(\rho\ge a\)，
\[
 n\log(t/\rho)=\sum_i\log(1+d/(\rho r_i))
 \le\sum_i\log(1+d/(ar_i)).
\]
若 \(\rho<a\)，由定义直接得
\(n\log(t/a)\le\sum_i\log(1+d/(ar_i))\)。加内部的 \(m\) 即证。

若 \(m/u<d^n\)，不设内部矩形。见证窗仍可非空，只使用 \([a,\min(b,t)]\)，且
\[
 n\log(t/a)<\sum_i\log(d/(ar_i))
 \le\sum_i\log(1+d/(ar_i)).
\]
这时甚至少一个内部常数。端点不改变严格超水平集的估计。证毕。

## MG3. 共同硬窗口产生严格次概率软核

固定一个边长 \(d\) 的来源簇 \(C\)，中心为 \(z_C\)。若硬响应 \(h_R*\nu_C(x)>0\)，则
\(x\in B_C:=Q_{b+d}(z_C)\)。对任何 \(y\in C\)，
\[
 |x_i-y_i|/L\le (b/2+d)/a\le1+d/a\le3/2.
\]
所以在 \(B_C\) 上可把软因子 **准确** 换成
\(\psi(u)=\varphi(u)1_{[-3/2,3/2]}(u)\)，不改变该簇的软响应。

取
\[
 \epsilon=\tfrac12 e^{-4},\quad \gamma=1+\epsilon/2,\quad
 v=1-\epsilon/2,\quad \zeta=\sqrt v,\quad c=1-\zeta>0.
\]
若 \(U\) 在 \([-1/2,1/2]\) 均匀、\(W\) 密度为 \(w\)，则 \(|W|>2\) 蕴含 \(|U+W|>3/2\)。此外
\[
 \mathbb P(|W|>2)=2\int_0^1t e^{-2/t}dt
 \ge\tfrac12 e^{-4}=\epsilon.
\]
故 \(m_\psi=\int\psi\le1-\epsilon\)。

\(\varphi'(u)=w(u+1/2)-w(u-1/2)\) 在正半轴非正且绝对值不超过一。于是正区间混合
\[
 \psi=\int_{(0,3]}h_r\,d\alpha(r),\quad
 d\alpha(r)=-\tfrac r2\varphi'(r/2)dr+3\varphi(3/2)\delta_3,
 \quad \|\alpha\|=m_\psi \tag{MG3.1}
\]
成立（端点任意约定只改零测集）。令 \(r_\ell=3\gamma^{-\ell}\)、
\(w_\ell=\gamma\alpha((r_\ell/\gamma,r_\ell])\)。\(\ell=0\) 的区间包含边界原子。由向上取半径，
\[
 \psi\le\sum_{\ell\ge0}w_\ell h_{r_\ell},\quad
 \sum_\ell w_\ell\le\gamma(1-\epsilon)\le v,
 \quad w_\ell\le\frac{9\gamma}{4}\gamma^{-2\ell}\quad(\ell\ge1). \tag{MG3.2}
\]
最后一式只用于没有边界原子的 \(\ell\ge1\)；\(w_0\le\gamma\) 单独保留。

设 \(\omega_\ell=w_\ell/\zeta\)。其总量不超过 \(\zeta<1\)。写 \(q_g=\gamma^{-2}\)，则
\[
 \sum\omega_\ell\ell\log\gamma\le M_1
 =\frac{9\gamma}{4\zeta}\log\gamma\frac{q_g}{(1-q_g)^2},
\]
\[
 \sum\omega_\ell(\ell\log\gamma)^2\le M_2
 =\frac{9\gamma}{4\zeta}(\log\gamma)^2
 \frac{q_g(1+q_g)}{(1-q_g)^3}. \tag{MG3.3}
\]
这是包括所有小半径的完整费用；没有删去小半径尾。

## MG4. 全软度弱上确界：共同参数与熵逐项支付

对 \(s\ge s_0\)，任意 \(0\le k\le n\)，二项分布的单项不超过总和，故
\[
 {n\choose k}s^k(1-s)^{n-k}\zeta^k
 \le(1-s+s\zeta)^n\le e^{-cns_0}. \tag{MG4.1}
\]
将 \(\psi\) 用 (MG3.2) 正上放，并按软坐标集合 \(S\)、\(|S|=k\) 展开。共同 \(s\) 的上确界不产生逐坐标独立选择：每个矩形分量的系数至多
\[
 e^{-cns_0}{n\choose k}^{-1}\prod_{i\in S}\omega_{\ell_i}. \tag{MG4.2}
\]
其硬坐标 aspect 为一，软坐标 aspect 为 \(r_{\ell_i}\)。MG2 的弱常数不超过
\(\kappa_d+\sum_{i\in S}\ell_i\log\gamma\)，因为令 \(D=d/a\) 后
\(\log(1+D/r)\le\log(1+D)+\log_+(1/r)\)。

使用如下可数弱和引理：若 \(f_j\ge0\) 的弱常数为 \(a_j\)，\(\pi_j>0\)、\(\sum_j\pi_j\le1\)，则
\[
 u|\{\sum_jf_j>u\}|\le\sum_j a_j[3+2\log(2/\pi_j)]. \tag{MG4.3}
\]
证明：先删 \(\cup_j\{f_j>u\}\)，费用 \(\sum a_j/u\)；低段 \(f_j\le u\pi_j/2\) 总量至多 \(u/2\)；其余中段的截断积分至多 \(a_j[1+\log(2/\pi_j)]\)，再 Markov。可数情形由有限和单调极限得到。

对上述矩形分量选择
\[
 \pi_{k,S,\boldsymbol\ell}=
 \frac{2^{-k-1}}{{n\choose k}}
 \prod_{i\in S}[(1-\gamma^{-1})\gamma^{-\ell_i}].
\]
总和不超过一。这里 \(\log{n\choose k}\le k\log(n+1)\) 完整保留。记
\[
 A_0=3+4\log2,\quad C_n=\log2+\log(n+1)-\log(1-\gamma^{-1}),\quad u_0=1-\zeta.
\]
将 MG3 的零、一、二阶对数矩代入 MG4.3，逐项对 \(k\) 求和（把 \(0\le k\le n\) 正放到无限和），得到如下显式常数：
\[
 K_n(d)=\kappa_d\left[\frac{A_0}{u_0}+\frac{2C_n\zeta}{u_0^2}\right]
 +\frac{(A_0+2\kappa_d)M_1}{u_0^2}
 +\frac{2C_nM_1(1+\zeta)}{u_0^3}
 +\frac{2M_2}{u_0^2}+\frac{4M_1^2}{u_0^3}. \tag{MG4.4}
\]
其中用到 \(\sum k\zeta^{k-1}=u_0^{-2}\)、\(\sum k^2\zeta^{k-1}=(1+\zeta)u_0^{-3}\)、\(\sum k(k-1)\zeta^{k-2}=2u_0^{-3}\)。因此对任意簇内 \(L^1\) 来源 \(\sigma\)，
\[
 t\left|\left\{x\in B_C:
 \sup_{s_0\le s\le1,\ a\le L\le b} P_{s,L}*\sigma(x)>t\right\}\right|
 \le e^{-cns_0}K_n(d)\|\sigma\|. \tag{MG4.5}
\]
这已同时支付软度与物理尺度，而非固定参数公式指向自适应选择器。

为明确维数阶，令
\(c_0=1+[-\log(1-\gamma^{-1})+\log2]/\log3\)。由 \(C_n\le c_0\log(n+2)\)、\(\kappa_d\ge2\)，有
\(K_n(d)\le C_*\kappa_d\log(n+2)\)，其中可取绝对常数
\[
 C_*=
 \frac{A_0}{u_0\log3}+\frac{2c_0\zeta}{u_0^2}
 +\frac{(A_0/2+2)M_1}{u_0^2\log3}
 +\frac{c_0M_1(1+\zeta)}{u_0^3}
 +\frac{M_2}{u_0^2\log3}+\frac{2M_1^2}{u_0^3\log3}. \tag{MG4.6}
\]
没有优化该常数。

## MG5. 只对实际选中响应使用高度帽

固定任意平移的边长 \(d\) 网格，将 \(\beta_C,\nu_C\) 定义为原来源的真实限制。令
\(F_C(x)=P_{s(x),L(x)}*\beta_C(x)\)、\(G_C(x)=h_{R(x)}*\nu_C(x)\)。在 \(G_C>0\) 的位置必有 \(x\in B_C\)。MG1.1 给 \(F_C\le q\)、\(G_C\le4\lambda\) 于 \(E\)。利用 MG4.5 的分布估计而只截断 selected \(F_C\)，
\[
 \int_{E\cap B_C}F_C^2\le2q e^{-cns_0}K_n(d)\|\beta_C\|.
\]
R251 的单簇硬弱型同样给
\[
 \int_E G_C^2\le8\lambda\kappa_d\|\nu_C\|.
\]
逐簇 Cauchy 后再对簇质量 Cauchy，
\[
 \int_E\sum_CF_CG_C
 \le4\sqrt{q\lambda}\,e^{-cns_0/2}\sqrt{K_n(d)\kappa_d}
 \sqrt{W_\beta W_\nu}. \tag{MG5.1}
\]
此处来源每簇只付一次，无簇数、质量均匀性或网格熵假设。\(F_C\) 的全软上确界没有获得高度帽。

## MG6. 平移平均给真实近来源对

在 \([0,d)^n\) 均匀平移网格，两个点落同胞的概率恰为 \(P_d(y-z)\)。正 Tonelli 把 MG5.1 左边平均成 \(\int_E Z_d\)，从而证明 MG1.2。若 \(\|y-z\|_1\le d/2\)，则
\(P_d(y-z)\ge1-\|y-z\|_1/d\ge1/2\)。因此真实近对指标的右价乘二。

该平均只是证明原正来源对积分的工具：不裁掉原 posterior 的任何来源，不修改 \(\beta,\nu\)，不赋予它们新 cut 或 rank。\(E\) 与实际 \(s,L,R\) 在平移平均中保持不变。

## MG7. 原正交通的强软度近对分支

采用原已认证资格：\(3\lambda/4\le q\le\lambda\)，原正母式的外因子 \(2\Lambda/q\)，硬来源 \(z\) 与软来源 \(y\) 为实际 \(\nu_V,\beta_V\)；原剩余正门、capture、history 介于零一。原双 \(\Pi_{j,t}(y)\) 完整保留，其 iid score Gini 不超过 \(n/4\)。原 far clock 长度不超过 \(\log2\)；保原唯一 \(j(x)\) 和互不交 receiver-leaf 门后求和，不重复 \(E\) 费用。此接口与本轮 actual_bridge.md 的原量规范相同。

故只对已付款正子项剔除后的原正余交通中
\[
 s(x)\ge s_0,\qquad \|y-z\|_1\le d/2
\]
的真实来源子项，先正放其余门、逐 \(x,y,t\) 使用完整双后验的 Gini，再用 MG6，得到
\[
 \mathcal P_{\mathrm{near},\,s\ge s_0}
 \le\frac{8}{\sqrt3}\Lambda\log2\,
 n e^{-cns_0/2}\sqrt{K_n(d)\kappa_d}\,
 \mathbb E\sum_V\sqrt{\|\beta_V\|\|\nu_V\|}. \tag{MG7.1}
\]
这一步显式支付了 \(n/4\) 与完整时钟长度；它们不是免费的。

取 \(d=a/(8\sqrt n)\)、\(s_0=2\log n/(cn)\)。若该阈值超过原允许软度上端，此支为空；否则 \(n e^{-cns_0/2}=1\)，且
\[
 \mathcal P_{\mathrm{near},\,s\ge s_0}
 \le\frac{8}{\sqrt3}\Lambda\log2\sqrt{C_*}
 (2+\sqrt n/8)\sqrt{\log(n+2)}\,W_{\mathrm{pair}},
 \quad W_{\mathrm{pair}}=\mathbb E\sum_V\sqrt{\|\beta_V\|\|\nu_V\|}. \tag{MG7.2}
\]
原 \(0\le\nu_V\le\beta_V\le\alpha_V\) 与 leaf 来源总账给 \(W_{\mathrm{pair}}\le\mathbb E\sum_V\|\alpha_V\|\le\|f\|_1\)。这是含 soft-core 外部的一般原近对强软度分支的根阶多对数付款，不要求簇少、质量均匀、簇内平滑。原范围 \(s\le1-d_n\) 只需与该门取交；不声称此交覆盖固定正比例。

准确剩余仍包括原低软度近对和所有远来源对。MG1.2 在低软度仍有根阶来源列价，但乘上原 score 的 \(n\) 后不能宣称同样的原交通付款；MG7 未闭合一般全输入目标。

## MG8. 本机有限核算与证明边界

下列标准库代码实际运行通过 87 个标量检查。它只检查 MG2 的窗口对数式与 MG4.1；无限混合、弱型、原来源和时钟回代由正文证明，不由这些有限检查认证。

```python
import math
checks = 0
for n in (1, 4, 16):
    a = 1.; D = 1/(8*math.sqrt(n))
    asp = [3*1.7**(-(i % 9)) for i in range(n)]
    for rho in (0., .2, 1., 1.5, 3.):
        lt = sum(math.log(rho + D/r) for r in asp)/n
        lhs = max(0., n*(lt-math.log(max(a, rho))))
        rhs = sum(math.log1p(D/(a*r)) for r in asp)
        assert lhs <= rhs + 1e-11
        checks += 1
v = 1-math.exp(-4)/4
r = math.sqrt(v)
for n in (1, 4, 16):
    for s in (.01, .25, .9):
        for k in range(n+1):
            assert (math.comb(n,k)*s**k*(1-s)**(n-k)*r**k
                    <= math.exp(-(1-r)*n*s)+1e-12)
            checks += 1
print({'checks': checks, 'scope': 'finite scalar formula checks only'})
```
