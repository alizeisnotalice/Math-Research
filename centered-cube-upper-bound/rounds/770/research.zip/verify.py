"""R770 exact interval pricing, exterior allocation, and local packing budgets."""

import argparse
from collections import defaultdict, deque
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
from platform import python_version


def interval(c,r):
    return c-r,c+r


def meet(*intervals):
    return max(a for a,b in intervals),min(b for a,b in intervals)


def length(I):
    return max(Q(0),I[1]-I[0])


def inside(I,x):
    return I[0]<=x<=I[1]


def difference(A,D):
    l,r = A
    p,q = D
    return [I for I in ((l,min(r,p)),(max(l,q),r)) if length(I)]


def union_mu(intervals,mu):
    merged = []
    for a,b in sorted(I for I in intervals if length(I)):
        if merged and a<=merged[-1][1]:
            merged[-1]=(merged[-1][0],max(b,merged[-1][1]))
        else:
            merged.append((a,b))
    return sum(mu(I) for I in merged)


def subsets(n):
    return (I for k in range(n+1) for I in combinations(range(n),k))


def specification(name):
    if name=="basic":
        A = [(0,2),(Q(3,2),Q(7,2)),(Q(5,2),Q(9,2))]
        return A,Q(1,4),Q(1,2),Q(1,1024)
    if name=="crowded":
        A = [(0,2),(0,2),(Q(3,2),Q(7,2)),(Q(3,2),Q(7,2))]
        return A,Q(1,4),Q(1,2),None
    A = [(-2,0),(Q(-3,4),Q(5,4)),(Q(1,2),Q(7,2)),(Q(11,4),Q(19,4)),
         (Q(17,4),Q(29,4)),(6,10),(Q(1,4),Q(17,4))]
    return A,Q(1,8),Q(1,4),None


def real_input(name):
    A,halo_u,low_density,lambda_fixed = specification(name)
    A = [tuple(map(Q,I)) for I in A]
    D = [interval((l+r)/2,(1+halo_u)*(r-l)/2) for l,r in A]
    core = [interval((l+r)/2,(r-l)/64) for l,r in A]
    related = defaultdict(list)
    for i,I in enumerate(core):
        related[I].append(i)
    owners = {}
    for (l,r),bucket in related.items():
        w = (r-l)/len(bucket)
        for index,i in enumerate(bucket):
            owners[i] = (l+index*w,l+(index+1)*w)
    assert all(length(I)>0 and meet(I,core[i])==I for i,I in owners.items())
    assert all(length(meet(X,Y))==0 for X,Y in combinations(owners.values(),2))
    density = []
    for n in range(-8,14):
        mid = Q(n)+Q(1,2)
        density.extend([((Q(n),mid),low_density),((mid,Q(n+1)),2-low_density)])

    def mu(I):
        return sum(w*length(meet(I,cell)) for cell,w in density)

    m = list(map(mu,A))
    d = list(map(length,A))
    v = [length(owners[i]) for i in range(len(A))]
    assert m==d and all(x>0 for x in m)
    assert all(meet(D[i],I)==I for i,I in enumerate(A))
    histories = []
    for i,(l,r) in enumerate(A):
        if name=="basic":
            histories.append((i,0,v[i],A[i]))
            continue
        amount = Q(3+i%3,8)
        if name=="crowded":
            cuts = ((l+(i%2)*Q(1,8),r),(l+Q(1,2),r-Q(1,8))) if i<2 else (
                (l,r-Q(1,4)),(l+Q(1,8),r))
        else:
            cuts = ((l,r-Q(1+i%2,8)),(l+Q(1,8),r))
        histories.extend([(i,0,v[i]*amount,cuts[0]),(i,1,v[i]*(1-amount),cuts[1])])
    j = [sum(w for i,direction,w,C in histories if i==label) for label in range(len(A))]
    assert all(j[i]<=v[i] for i in range(len(A)))
    assert all(0<length(C) and meet(A[i],C)==C for i,direction,w,C in histories)

    expanded_admissible = set()
    if name=="expanded":
        gate_limit = Q(9,10)
        expanded_admissible = {
            (i,k) for i,k in product(range(len(A)),repeat=2) if i!=k
            and mu(meet(A[i],D[k]))<gate_limit*m[i]
            and mu(meet(A[k],D[i]))<gate_limit*m[k]
        }

    def allowed(i,b,k,c):
        if i==k:
            return False
        if name=="basic":
            return True
        if name=="crowded":
            return (i<2)!=(k<2) and (b!=c or (i+k)%2==0)
        return (i,k) in expanded_admissible and (b==c or (i+k)%2==1)

    points = sorted({z for I in (*A,*D,*(I for I,w in density),*(C for i,b,w,C in histories)) for z in I})
    cells = [(I,(I[0]+I[1])/2,mu(I)) for I in zip(points,points[1:]) if length(I)]
    return A,D,owners,m,d,v,j,histories,allowed,mu,cells,low_density,halo_u,lambda_fixed


def energy(A,m,histories,allowed,mu,cells):
    pairs = tuple(product(range(len(A)),repeat=2))
    phi = [[sum((w/m[i] for label,tag,w,C in histories if i==label and inside(C,x)),Q(0))
            for i in range(len(A))] for I,x,price_mass in cells]
    raw = {(i,j):sum(price_mass*row[i]*row[j] for (_,_,price_mass),row in zip(cells,phi)) for i,j in pairs}
    original = defaultdict(Q)
    directions = defaultdict(Q)
    raw_by_labels = defaultdict(Q)
    for i,s,w,C in histories:
        for j,t,y,B in histories:
            joint = w*y*mu(meet(C,B))/(m[i]*m[j])
            raw_by_labels[i,j] += joint
            gate = allowed(i,s,j,t)
            assert gate==allowed(j,t,i,s)
            if gate:
                original[i,j] += joint
                directions[i,j,s,t] += joint
    assert all(raw[i,j]==raw_by_labels[i,j]>=original[i,j] for i,j in pairs)
    positive = [(i,j) for i,j in combinations(range(len(A)),2) if original[i,j]+original[j,i]]
    b = [original[i,j]+original[j,i] for i,j in positive]
    assert sum(b)==sum(original.values())
    edge_energy = [[i,j,str(original[i,j]),str(original[j,i]),str(b[e]),
                    [[s,t,str(directions[i,j,s,t])] for s,t in product(range(2),repeat=2)
                     if directions[i,j,s,t]]]
                   for e,(i,j) in enumerate(positive)]
    return phi,raw,positive,b,edge_energy


def rational_flow(b,prices,neighbors,lam):
    root,offset,sink = 0,1+len(b),1+len(b)+len(prices)
    capacity = defaultdict(Q)
    graph = [[] for _ in range(sink+1)]

    def arc(x,y,cap):
        graph[x].append(y)
        graph[y].append(x)
        capacity[x,y]=cap

    total = sum(b)
    for e,w in enumerate(b):
        arc(root,e+1,w)
    for j,((I,x,mu),M) in enumerate(zip(prices,neighbors)):
        arc(offset+j,sink,lam*mu)
        for e in M:
            arc(e+1,offset+j,total)
    residual = capacity.copy()
    paid = Q(0)
    augmentations = 0
    while True:
        parent = {root:-1}
        queue = deque([root])
        while queue and sink not in parent:
            x=queue.popleft()
            for y in graph[x]:
                if y not in parent and residual[x,y]>0:
                    parent[y] = x
                    queue.append(y)
        if sink not in parent:
            break
        path = []
        y = sink
        while y!=root:
            x=parent[y]
            path.append((x,y))
            y=x
        push = min(residual[x,y] for x,y in path)
        for x,y in path:
            residual[x,y]-=push
            residual[y,x]+=push
        paid+=push
        augmentations+=1
    fed = [capacity[root,e+1]-residual[root,e+1] for e in range(len(b))]
    assert sum(fed)==paid and all(0<=x<=w for x,w in zip(fed,b))
    support_cuts = []
    assigned = [Q(0)]*len(b)
    for j,((I,x,mu),M) in enumerate(zip(prices,neighbors)):
        if mu==0:
            continue
        lo,hi = I
        cursor = lo
        area_density = mu/(hi-lo)
        for e in M:
            sent = capacity[e+1,offset+j]-residual[e+1,offset+j]
            assert sent>=0
            if sent:
                end = cursor+sent/(lam*area_density)
                assert cursor<end<=hi
                support_cuts.append((e,cursor,end,sent))
                cursor=end
                assigned[e]+=sent
    assert assigned==fed
    return paid,fed,tuple(e for e in range(len(b)) if e+1 in parent),augmentations,support_cuts


def packing_certificate(A,I):
    edges = sorted({x for j in I for x in A[j]})
    dp = [Q(0)]*len(edges)
    chosen = [() for _ in edges]
    for r,y in enumerate(edges[1:],1):
        dp[r],chosen[r] = dp[r-1],chosen[r-1]
        for j in I:
            if A[j][1]!=y:
                continue
            l = edges.index(A[j][0])
            candidate = dp[l]+length(A[j])
            if candidate>dp[r]:
                dp[r],chosen[r] = candidate,chosen[l]+(j,)
    primal = chosen[-1]
    dual = [(edges[k],edges[k+1],dp[k+1]-dp[k]) for k in range(len(edges)-1)]
    assert all(length(meet(A[i],A[j]))==0 for i,j in combinations(primal,2))
    assert all(w>=0 for l,r,w in dual)
    assert all(sum(w for l,r,w in dual if inside(A[i],(l+r)/2))>=length(A[i]) for i in I)
    assert sum(length(A[i]) for i in primal)==sum(w for l,r,w in dual)==dp[-1]>0
    return dp[-1],primal,dual


def gamma_budget(A,m,j,phi,cells):
    U_all = list(subsets(len(A)))[1:]
    ratios = {}
    for U in U_all:
        P0,primal,dual = packing_certificate(A,U)
        ratios[U] = sum(j[i] for i in U)/P0
    max_fraction = Q(0)
    for U in U_all:
        gamma = max(value for J,value in ratios.items() if set(J).issubset(U))
        row = sum(j[i] for i in U)
        quad = Q(0)
        envelope = Q(0)
        for (I,x,w),f in zip(cells,phi):
            original = sum(f[i] for i in U)
            cap = sum(j[i]/m[i] for i in U if inside(A[i],x))
            assert 0<=original<=cap
            quad += w*original**2
            envelope += w*cap**2
        assert quad<=envelope<=2*gamma*row
        max_fraction = max(max_fraction,quad/(2*gamma*row))
    all_indices = tuple(range(len(A)))
    P0,primal,dual = packing_certificate(A,all_indices)
    gamma = max(ratios.values())
    jtotal = sum(j)
    true_quad = sum(w*sum(y)**2 for (_,_,w),y in zip(cells,phi))
    return {"subsets_with_primal_dual":len(U_all),"P0_all":str(P0),
            "primal_disjoint_labels":list(primal),
            "nonzero_dual_cells":[[str(l),str(r),str(w)] for l,r,w in dual if w],
            "gamma_all":str(gamma),"j_total":str(jtotal),"true_phi_energy":str(true_quad),
            "two_gamma_j_budget":str(2*gamma*jtotal),
            "largest_fraction_of_budget_over_all_label_subsets":str(max_fraction)}


def optimal_cut_extensions(name,A,D,m,edges,b,exterior,mu,cells,neighbors,phi,
                           histories,allowed,lam,critical,sub,witness):
    alpha = max(mu(meet(A[i],D[j]))/m[i] for pair in edges for i,j in (pair,pair[::-1]))
    assert 0<=alpha<=1
    packings = {}
    lower_positive = 0
    for F,demand,supply in sub:
        if not F:
            assert demand==supply==0
            continue
        U = tuple(sorted({i for e in F for i in edges[e]}))
        if U not in packings:
            packings[U] = packing_certificate(A,U)
        P0,primal,_ = packings[U]
        outside_intervals = []
        for i in primal:
            partner = next(j if k==i else k for e in F for k,j in [edges[e]] if i in (k,j))
            chosen = difference(A[i],D[partner])
            assert sum(mu(I) for I in chosen)==m[i]-mu(meet(A[i],D[partner]))>=(1-alpha)*m[i]
            outside_intervals.extend(chosen)
        realized = sum(mu(I) for I in outside_intervals)
        assert realized==union_mu(outside_intervals,mu)
        assert (1-alpha)*P0<=realized<=supply
        lower_positive += (1-alpha)*P0>0
    assert lower_positive==((len(sub)-1) if alpha<1 else 0)

    F = set(witness)
    U = {i for e in F for i in edges[e]}
    remain = [e for e in range(len(edges)) if e not in F]
    supply_at = {S:supply for S,demand,supply in sub}
    selected_supply = supply_at[witness]
    complement_hits = []
    residual_checks = 0
    for S,demand,supply in sub:
        if F.intersection(S):
            continue
        only_new = sum(mass for (_,_,mass),M in zip(cells,neighbors)
                       if not F.intersection(M) and any(e in M for e in S))
        assert only_new==supply_at[tuple(sorted(F.union(S)))]-selected_supply
        assert demand<=lam*only_new
        residual_checks+=1
    assert residual_checks==2**len(remain)

    outside_cells, outside_neighbors = [],[]
    index = {e:j for j,e in enumerate(remain)}
    for cell,M in zip(cells,neighbors):
        if not F.intersection(M):
            outside_cells.append(cell)
            outside_neighbors.append(tuple(index[e] for e in M))
    if remain:
        paid_out,all_out,_,_,out_cuts = rational_flow([b[e] for e in remain],
                                                      outside_cells,outside_neighbors,lam)
        assert paid_out==sum(b[e] for e in remain) and all_out==[b[e] for e in remain]
        assert all(lam*mu((a,c))==w and any(meet((a,c),I)==(a,c) for I in exterior[remain[e]])
                   for e,a,c,w in out_cuts)
    else:
        paid_out = Q(0)

    crossing = [e for e in remain if sum(i in U for i in edges[e])==1]
    for e in crossing:
        i,j = edges[e]
        common = Q(0)
        leakage = [Q(0),Q(0)]
        for (_,x,w),M,f in zip(cells,neighbors,phi):
            if F.intersection(M):
                continue
            for a,s,q,C in histories:
                for c,t,z,B in histories:
                    if (a,c) in ((i,j),(j,i)) and allowed(a,s,c,t) and inside(C,x) and inside(B,x):
                        common+=w*q*z/(m[a]*m[c])
            leakage[0]+=w*f[i]*int(not inside(D[j],x))
            leakage[1]+=w*f[j]*int(not inside(D[i],x))
        assert 0<=common<=b[e] and all(w>=0 for w in leakage)
        complement_hits.append({"edge_index":e,"labels":[i,j],"cross_energy":str(b[e]),
                                "common_energy_on_X_F_complement":str(common),
                                "two_true_history_exterior_masses_on_X_F_complement":list(map(str,leakage))})
    if name in ("basic","expanded"):
        assert crossing
    else:
        assert not crossing

    lambda_full = critical*Q(9,8) if name=="basic" else critical
    zero_deficit = max(demand-lambda_full*supply for S,demand,supply in sub)
    assert zero_deficit==0
    if name=="basic":
        assert all(demand-lambda_full*supply<0 for S,demand,supply in sub if S)
    full_paid,full_edges,full_cut,_,_ = rational_flow(b,cells,neighbors,lambda_full)
    assert full_paid==sum(b) and full_edges==b and not full_cut
    return {
        "alpha_true_bidirectional":str(alpha),"F_lower_bound_checks_including_empty":len(sub),
        "F_with_positive_packing_lower_bound":lower_positive,"optimal_F_labels":sorted(U),
        "complement_Fprime_checks":residual_checks,"all_complement_demands_paid_outside_X_F":str(paid_out),
        "positive_crossing_edges_one_endpoint_outside_U":complement_hits,
        "zero_deficit_lambda":str(lambda_full),"zero_deficit_check":str(zero_deficit),
        "empty_optimal_F":list(full_cut),"full_paid":str(full_paid),
    }


def audit(name):
    A,D,owners,m,d,v,j_by_label,histories,allowed,mu,cells,low,halo_u,lam = real_input(name)
    phi,Qij,edges,b,edge_energy = energy(A,m,histories,allowed,mu,cells)
    exterior = [difference(A[i],D[j])+difference(A[j],D[i]) for i,j in edges]
    neighbors = [tuple(e for e,X in enumerate(exterior) if any(inside(I,x) for I in X)) for I,x,w in cells]
    sub = []
    for F in subsets(len(edges)):
        supply = union_mu([I for e in F for I in exterior[e]],mu)
        assert supply==sum(w for (_,_,w),M in zip(cells,neighbors) if any(e in M for e in F))
        demand = sum(b[e] for e in F)
        assert supply>0 or demand==0
        sub.append((F,demand,supply))
    critical = max(demand/supply for F,demand,supply in sub if F)
    single = max(demand/supply for F,demand,supply in sub if len(F)==1)
    if name=="crowded":
        assert critical>single
        lam = (single+critical)/2
    elif name=="expanded":
        lam = Q(3,4)*critical
    assert lam>0
    deficit,witness = max((demand-lam*supply,F) for F,demand,supply in sub)
    assert 0<deficit<sum(b)
    paid,fed,cut,augmentations,assignment = rational_flow(b,cells,neighbors,lam)
    assert paid+deficit==sum(b)
    cut_volume = union_mu([I for e in cut for I in exterior[e]],mu)
    assert sum(b[e] for e in cut)-lam*cut_volume==deficit
    assert all(any(length(meet((l,r),I))==r-l for I in exterior[e]) and lam*mu((l,r))==value
               for e,l,r,value in assignment)
    assert all(length(meet((l,r),(a,c)))==0 for (e,l,r,p),(f,a,c,q) in combinations(assignment,2))
    retained = [w-f for w,f in zip(b,fed)]
    if name=="basic":
        assert any(f==w for f,w in zip(fed,b))
        assert any(0<f<w for f,w in zip(fed,b))
    if name=="crowded":
        assert all(lam*supply>=demand for F,demand,supply in sub if len(F)==1)
        assert any(supply<sum(union_mu(exterior[e],mu) for e in F) for F,demand,supply in sub if len(F)>1)
        assert any(Qij[i,j]*2>b[e] for e,(i,j) in enumerate(edges))

    outer_rows = []
    row_targets = defaultdict(set)
    expected_X = []
    for e,(i,j) in enumerate(edges):
        row_targets[i].add(j)
        row_targets[j].add(i)
        ij,ji = (m[i]-mu(meet(A[i],D[j])))/m[i], (m[j]-mu(meet(A[j],D[i])))/m[j]
        Z = union_mu(exterior[e],mu)
        assert 0<=ij<=1 and 0<=ji<=1 and m[i]*ij+m[j]*ji==Z
        left = sum(w*f[i] for (_,x,w),f in zip(cells,phi) if not inside(D[j],x))
        right = sum(w*f[j] for (_,x,w),f in zip(cells,phi) if not inside(D[i],x))
        assert left==sum(w/m[i]*sum(mu(I) for I in difference(C,D[j]))
                        for label,tag,w,C in histories if label==i)
        assert right==sum(w/m[j]*sum(mu(I) for I in difference(C,D[i]))
                         for label,tag,w,C in histories if label==j)
        expected_X.append([i,j,str(ij),str(ji),str(Z),str(left),str(right)])
    for i,targets in sorted(row_targets.items()):
        total = sum(w*f[i] for (_,x,w),f in zip(cells,phi))
        one_union = sum(w*f[i] for (_,x,w),f in zip(cells,phi)
                        if any(not inside(D[j],x) for j in targets))
        repeated = sum(w*f[i]*sum(not inside(D[j],x) for j in targets)
                       for (_,x,w),f in zip(cells,phi))
        assert 0<=one_union<=total and one_union<=repeated
        outer_rows.append([i,str(total),str(one_union),str(repeated)])
    if name=="crowded":
        assert any(Q(single)<Q(repeated) for i,total,single,repeated in outer_rows)
    expanded_screen = {}
    if name=="expanded":
        limit = Q(9,10)
        assert all(mu(meet(A[i],D[j]))<limit*m[i] and mu(meet(A[j],D[i]))<limit*m[j]
                   for i,j in edges)
        blocked = []
        for i,j in combinations(range(len(A)),2):
            hits = (mu(meet(A[i],D[j]))/m[i],mu(meet(A[j],D[i]))/m[j])
            if mu(meet(A[i],A[j]))>0 and max(hits)>=limit:
                blocked.append([[i,j],list(map(str,hits))])
        assert blocked
        alpha = max(mu(meet(A[i],D[j]))/m[i] for pair in edges for i,j in (pair,pair[::-1]))
        U = tuple(sorted({i for e in witness for i in edges[e]}))
        P0,primal,_ = packing_certificate(A,U)
        exterior_mass = union_mu([I for e in witness for I in exterior[e]],mu)
        assert alpha==Q(25,32) and P0==6 and (1-alpha)*P0==Q(21,16)<=exterior_mass==Q(209,32)
        expanded_screen = {
            "expanded_strict_true_bilateral_limit":str(limit),
            "positive_price_pairs_rejected_by_this_limit":blocked,
            "optimal_cut_positive_packing_lower": {
                "pairs":[edges[e] for e in witness],"P0":str(P0),"packing_labels":primal,
                "one_minus_alpha_P0":str((1-alpha)*P0),"X_F_price_mass":str(exterior_mass),
            },
        }
    return {
        **expanded_screen,
        "phase":name,"parent_A":[list(map(str,I)) for I in A],"outer_D":[list(map(str,I)) for I in D],
        "owners_E":[list(map(str,owners[i])) for i in range(len(A))],
        "periodic_density_low_high":list(map(str,(low,2-low))),
        "m_and_d":list(map(str,m)),"v":list(map(str,v)),
        "I_histories_label_direction_weight_C":[[i,tag,str(w),list(map(str,C))] for i,tag,w,C in histories],
        "b_pair_ordered_energies_and_direction_components":edge_energy,
        "lambda":str(lam),"singleton_critical_lambda":str(single),"all_Hall_critical_lambda":str(critical),
        "subsets_F_checked":len(sub),"worst_F":list(witness),"residual_min_cut_F":list(cut),
        "total_b":str(sum(b)),"deficit":str(deficit),"paid":str(paid),
        "per_pair_paid_held":[[list(P),str(f),str(r)] for P,f,r in zip(edges,fed,retained)],
        "exact_paid_pieces_edge_l_r_and_paid_mass":[[e,str(l),str(r),str(mass)] for e,l,r,mass in assignment],
        "flow_augmentations":augmentations,
        "exterior_i_j_two_parent_fractions_X_mu_and_two_history_masses":expected_X,
        "original_row_total_union_exterior_sum_with_repetitions":outer_rows,
        "gamma_budget":gamma_budget(A,m,j_by_label,phi,cells),
        "optimal_cut_extensions":optimal_cut_extensions(name,A,D,m,edges,b,exterior,mu,cells,neighbors,phi,
                                                          histories,allowed,lam,critical,sub,witness),
    }


def report():
    return {
        "scope":(
            "Three finite 1D AC priced families, exact m=d, physical halo expansions and disjoint owners. "
            "The finite symmetric pair masks and history weights diagnose the exterior allocation interface."
        ),
        "python":python_version(),"source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "experiments":[audit(name) for name in ("basic","crowded","expanded")],
    }


def main():
    parser = argparse.ArgumentParser()
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--out",type=Path)
    action.add_argument("--check",type=Path)
    args = parser.parse_args()
    cert = report()
    data = (json.dumps(cert,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data,"certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    for c in cert["experiments"]:
        print(f"{c['phase']} {len(c['m_and_d'])} parents, {c['subsets_F_checked']} Hall subsets, "
              f"paid={c['paid']}, deficit={c['deficit']}")


if __name__=="__main__":
    main()

