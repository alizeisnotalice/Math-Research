# R200：真实 capture 的硬面再进入与一次恢复账

状态：辅助证明检查点。本稿给出真实物理参数下、任意原正 L1 来源的全路径 lost-capture 上界。它使用具有已证 BV 的缓冲势，不假设原 good 指示函数有 BV；连续恢复、source 核面与原删除分别记账。最后给出显式有限 receiver 费用及 selector 的适用范围。该费用不是一般根阶界，也未支付 R199 FS14 的全部权重。

## RG1　固定的原参数与路径

沿 R199 FS1–4 固定同一窗口、ω,V,j,x,y,s,R、q、ν=νV 及原 D。物理核为
\[
 f_s=(1-s)1_{[-1/2,1/2]}+s\phi,\quad
 P_{s,H}(x)=H^{-n}\prod_i f_s(x_i/H),\quad J_z=P_{1,b}(x-z).
\]
先取 0<s<1。固定 R,j 的一个连通合法比例带 I=[L0,L1]，a≤L≤b≤2a，且固定原 far 参数 u0≥0，
\[
 g=\sqrt{LR},\quad h=g e^{-u_0/n},\quad \tau=a/c_j,\qquad h\ge\tau.
\]
若原带只给 g≥τ，须先与 h≥τ 相交；h<τ 时 Δ 不可直接当作正量。以下统一取右起态、闭端右末态：L0 事件已计入初值，外 current 面和在 (L0,L1] 上求和，V(L1) 是完成该点物理面及原删除更新后的右态。若某应用只取左末态，必须同时将面和改为 (L0,L1)、末项改为 V(L1−)，两套约定不可混用。比例带端点若没有原右侧资格，该右态只能用于辅助物理势的估计，不能补出合法 α 或借原资格负项。固定 R 的比例条件可分成 L≤R 与 L≥R 两个连通分支；若使用两支，就各付一次本稿初值/路径费用。

写 ℓn=1+log n，
\[
 T={c_j^{n/2}\over g^n\sqrt{\ell_n}},\quad
 H=\widehat H=\max(a,\min(b,g c_j^{-1/2}m_s\ell_n^{1/(2n)})),
 \quad m_s=1-s+s\phi(1/2),
\]
\[
 a_z=T\Delta_z,\quad \Delta_z=w_\tau(y,z)-w_h(y,z)\ge0,
 \quad k_z=DP_{s,H}(x-z),\quad c_z=\min(a_z,k_z).
\]
为免与窗口 a 混淆，下面所有 a_z 均带来源下标。若扩到 h<τ，必须用 (a_z)+ 替代，不在该区声明原 far target 有资格。

令 Lf=min(b,γL)，
\[
 Q_z={P_{s,L}(x-z)+P_{s,Lf}(x-z)+J_z\over3},\quad
 F_z(L)=1_{Z_g(y)}(z)1_{\{B_{\rm hard}(z)=0\}},\quad
 \lambda_z(L)=\log {KQ_z\over p_y w_g(y,z)},\quad p_y=P_{s,L}(x-y).
\]
F_z 只减：Z_g 只删，Bhard=1_{R≤L}1_{Q_R(x)} 只增。Δ=0 处 c_z=0，故不必把 a_z>0 再作一个可重入门。原捕获量为 U_z=F_z c_z 1_{λ_z≥0}，端点迹不存在时以 RG3 的包络损失为准。

原 α 始终由同一来源给定
\[
 \alpha_L Q_J=Dq-\int U_z(L)\,d\nu(z),\qquad Q_J=\int J_z\,d\nu(z).
\]
本稿不重选 α，也不对非 FIRST 状态声称 α≥0。缓冲势可在辅助物理路径上定义；将结果用于 α 的精确跳响应，仍须两侧共同合法容量及 R199 的迹资格。FIRST/high/history 等外资格的进入账不被本稿删去。

## RG2　真实跳幅的缓冲势

记
\[
 j_s=\log {m_s\over s\phi(1/2)}>0,\qquad
 \Psi_s(l)=\min\{1,\max\{0,(l+j_s)/(2j_s)\}\},
 \qquad V_z=F_zc_z\Psi_s(\lambda_z). \tag{RG1}
\]
这是物理 current 硬面跳幅，不是另选阈值。跨一个外 y 的 current 单坐标硬面，p_y 乘 exp(js)。对原 ν≪Leb，source 的 Q_z、K0,z 硬面与此面同时相交的 z 为 ν 零集；按 R199 的 source 超平面/Tonelli 论证，
\[
 \lambda_{z,+}=\lambda_{z,-}-j_s,\qquad c_{z,+}=c_{z,-}. \tag{RG2}
\]
允许 F 同刻删除。

在 F 不删的面上，可能丢失原 good-capture 的来源必满足 λ−∈[0,js]。这里保留两个闭端点：原 good 单侧迹可能从等号的不同侧逼近；不利用“等号层 ν 零”。对这个完整闭区间，
\[
 \Psi_s(\lambda_-)-\Psi_s(\lambda_--j_s)=1/2. \tag{RG3}
\]
若 F 同刻删且 λ−≥0，则 Ψs(λ−)≥1/2；不要求 λ−≤js。

因此定义该面可测的包络损失
\[
 L_z^{\rm face}=c_z\big[
 1_{\{F_-=F_+=1,\ 0\le\lambda_-\le j_s\}}
 +1_{\{F_-=1,F_+=0,\ \lambda_-\ge0\}}\big],
\]
就有
\[
 L_z^{\rm actual}\le L_z^{\rm face}\le2(V_{z,-}-V_{z,+}). \tag{RG4}
\]
若实际 U 迹存在，左项取 (U−−U+)+；无迹时，中项仍控制一切由 good 的左右聚点造成的 capture 丢失。它可能多计临界等号，却不漏计。F 只减且 Ψ 单调，故外 current 面上的 V 跳总是非正。

## RG3　不假原 good 有 BV 的全路径充账

固定 (x,y,z) 时，p_y、Q_z、k_z 只有有限物理坐标硬面。去掉这些面，它们在紧正尺度带上分段 AC；其 log 的连续变差有限。w_g,w_h 是有限个连续幂函数片段，T、H 连续分段 AC。F 是单调指示函数，至多删一次。故 V_z 是 BV，具有单侧迹；这不推出原 1_{λ≥0} 或额外原资格 H 有 BV。

将 V 的所有外 current 面负跳与其余变差分开，得到
\[
 \sum_{\rm outer\ faces}L_z^{\rm actual}
 \le2\left[V_z(L0)+\operatorname{Var}_+
     (V_z;I\setminus\text{outer faces})-V_z(L1)\right]. \tag{RG5}
\]
还可减去其余负变差。式 RG5 的恢复项不能删除：例如 js=c=F=1，λ 路径为 1/2→(面)−1/2→(恢复)1/2→(面)−1/2，V 为 3/4,1/4,3/4,1/4。两次损失总计 2，恰等于 2(3/4+1/2−1/4)；若把恢复项漏掉则只得到错误的 1。

正恢复具有如下实际上界：
\[
 \operatorname{Var}_+(V;\text{非外面})
 \le\operatorname{Var}_+c
 +{1\over2j_s}\int_I c(\partial_{\log L}\lambda)_+\,d\log L
 +\sum_{\text{source }Q\text{ faces}}c_*\min\{1,(\Delta\log Q)_+/(2j_s)\}. \tag{RG6}
\]
其中 c* 可用该处两侧的最大值或整条路径 sup k。source K0 的跳已计在 Var+c 中，不可漏掉。F 的删除只给负项；它不消耗正恢复预算。

证明 RG6：在连续部分用乘积法则、0≤Ψ≤1 及 Lip(Ψ)=1/(2js)；在跳点用 Δ(cΨ)≤(Δc)+ + max(c−,c+)(ΔΨ)+。Q-source 跳外，p_y 的硬跳已被 RG5 分出；w_g 连续。这个证明直接使用已证 BV 的物理量，不对原 good 门作未经证明的 coarea。

## RG4　实际 a=TΔ 的恢复，不按每个祖先/每面重领

以 r=log L 为钟，记 kh(z) 为原 h 时刻的整数 score。由于 h 随 L 的 log 速度为 1/2，
\[
 a_z'={T\over2}\{-n\Delta_z+k_h(z)w_h(y,z)\},\qquad
 \Delta_z'={k_h(z)\over2}w_h(y,z)\ge0. \tag{RG7}
\]
T 下降，Δ 上升。设
\[
 A_{0,z}=T(L0)w_\tau(y,z),\qquad K_z^*=\sup_{L\in I}k_z(L).
\]
在 c 的 a-控制恢复部分 (a≤k)，由 (da)+≤T dΔ，令 zeta=Δ/wτ∈[0,1]，有 T wτ≤A0 且 T wτ≤K*/zeta。因此
\[
 \int_{\{a\le k\}}(da)_+
 \le\Phi(A_0,K^*)
 :=\int_0^1\min(A_0,K^*/\zeta)\,d\zeta, \tag{RG8}
\]
\[
 \Phi(A,K)=
 \begin{cases}A,&K\ge A,\\K[1+\log(A/K)],&0<K<A,\\0,&K=0.\end{cases} \tag{RG9}
\]
A=0 时为 0。wτ>0；零 Δ 端点用极限即可，不除 Δ。RG8 是捕获率真实恢复的截断对数价，而不是未知 good-flux 记号。

还可保留明确的有限弧数上界：kh 单调且至多 n 次增加。在 kh 常值片段内，RG7 的括号等于 (n+kh)wh−n wτ，它单调下降，因此 a' 只能由正变负。a 的正增弧数 Nz≤n+1。在每条增弧上，a 从小到大，故 ∫1_{a≤k}(da)+≤K*。于是
\[
 \operatorname{Var}_+c_z\le
 \min\{\Phi(A_{0,z},K_z^*),\,N_zK_z^*\}
 +\operatorname{Var}_+k_z. \tag{RG10}
\]
这同时保留实际较小的 A0、wτ、Nz；不能把 Nz 付给每个外面再加一次。一个可选的纯显式界是，对 0<p<1，
\[
 \Phi(A,K)\le A^{1-p}K^p/(1-p), \tag{RG11}
\]
直接在 RG8 中使用 min(A,K/zeta)≤A^(1−p)(K/zeta)^p。RG10 已提供多项式维度上界，不需要使用可能指数大的 RG11 核积分。

## RG5　log-good 的连续恢复费

原已证 logφ Lipschitz 常数记 Lφ=2/(1−e^{-1})。在不跨核硬面的连续片段，f_s 的 log 径向斜率在 [−Lφ,0]。因而
\[
 (\log p_y)'\ge-n,\qquad
 (\log Q_z)'\le {L_\phi\over a}\|x-z\|_1,\qquad
 -(\log w_g)'=k_g(z)/2\le n/2,
\]
\[
 (\lambda_z')_+\le {3n\over2}+{L_\phi\over a}\|x-z\|_1. \tag{RG12}
\]
这里窗口 a 是全物理尺度下界。Lf 的导数在活动段是 γ 而非 1，但其 log 速度为 1；封顶后为 0，所以 Q 的上述连续 score 界成立。没有把普通导数 (Lf)' 错设为≤1。

φ=h*w 且 w=∫0¹2t Laplace_t dt，故
\[
 \int |r|\phi(r)dr\le1/4+2/3=11/12,
 \qquad\int |r|f_s(r)dr\le11/12. \tag{RG13}
\]
这保留真实位移矩；不是来源坐标独立假设。

## RG6　同中心 source-face 的 receiver 积分压缩

以下先固定 s,R,j、I，令 H(L) 与正在积分的 receiver x 无关，D 为固定原常数。每个 Q_z 组成核 P_s,L 与 P_s,Lf 在单坐标硬面至多跳 exp(js)，所以 ΔlogQ≤js；重合跳可按组成面多计。每组成面使 Ψ 增量至多 1/2。

与来源 z 同中心的 K0 给出精确 coarea 归一：
\[
 \int dx\sum_{\text{source }Q\text{ faces}}K_{0,L}(x-z)
 = n\int_{L0}^{L1}\left[
 {f_s(L/(2H))\over H}
 +(Lf)'{f_s(Lf/(2H))\over H}\right]dL. \tag{RG14}
\]
第一项来自 x_i=z_i±L/2 的两面，各 Jacobian 1/2；第二项保留 (Lf)'。其余 n−1 坐标核积分恰为 1。闭面取核右值，上式可将 K0 的同刻硬面取右较大值；此选择只会增大恢复上界。对通常横截参数，同刻 K0-source 面为零；若 H=L 或 H=Lf 在一段恒等，使用右值式仍成立。

因为 fs≤1、H≥a，且 L1−L0≤b−a、Lf(L1)−Lf(L0)≤b−a，
\[
 \int dx\sum_{\text{source }Q\text{ faces}} k_*\,(\Delta\Psi)_+
 \le Dn(b-a)/a. \tag{RG15}
\]
k* 在此只需该面 K0 的两侧最大值，不应替换成所有 L 的独立 sup。RG15 是同中心空间几何的真实压缩；它去掉了逐 source 面再领全尺度包络的额外乘数。

## RG7　固定参数的全 receiver、全路径有限费用

R198 已审尺度 BV 工具给出：设 H−=min_I H、H+=max_I H，
\[
 v_s=\log(H_+/H_-)\{n(1-s)+3\sqrt n/4\},\qquad E_s=1+v_s,
\]
\[
 \int\sup_{L\in I}P_{s,H(L)}dx\le E_s,
 \qquad\int\operatorname{Var}_+(P_{s,H(L)})dx\le v_s. \tag{RG16}
\]
H 的 log 行程至多 (1/2)log(L1/L0)；若 clamp 使 H 恒定，vs=0。该引理基于真实 scale-score Fisher 上界<9/4 和正硬面质量，未借用虚假光滑 fs。

用 c≤k、RG12–13，对连续 log-good 恢复有
\[
 {1\over2j_s}\int dx\int_I c(\lambda')_+d\log L
 \le {Dn\log(L1/L0)\over2j_s}
 \left({3\over2}+{11L_\phi b\over12a}\right). \tag{RG17}
\]
RG10 与 RG16 给
\[
 \int\operatorname{Var}_+c_z\,dx
 \le\int\min\{\Phi(A_{0,z},K_z^*),N_zK_z^*\}dx+Dv_s
 \le D\{(n+1)E_s+v_s\}. \tag{RG18}
\]
初始 ∫V_z(L0)dx≤D。将 RG15、RG17、RG18 代回 RG5，正 Tonelli 得
\[
 \boxed{\int dx\sum_{\rm outer\ faces}\int L_z^{\rm actual}\,d\nu(z)
 \le2D\nu(V)\left[
 1+(n+1)E_s+v_s+{n(b-a)\over a}
 +{n\log(L1/L0)\over2j_s}
 \left({3\over2}+{11L_\phi b\over12a}\right)\right].} \tag{RG19}
\]
可减去非负终端势，并用 RG18 第一行保留实际 A0、Nz 以明显锐化。常数全显式、输入仅要求原有限 L1 来源。恢复计在同一来源路径上，未把每个硬面的同一质量各领一份 reserve。

RG19 通常至多是 O(Dν(V)[n²(1−s)+n^{3/2}+n/js]) 的粗价，不是 O(√n)；也不声称粗总量优于直接按至多 n 个外面计数。新工具是有实际参数控制的连续恢复/再进入账、无需 good-BV 的缓冲势，以及 RG8、RG15 的可直接加权位置。

## RG8　receiver 适应选择的资格与可付代价

RG14、RG17 的精确归一要求固定 R,j、I、s 后 H(L) 不随正在积分的 x 改变。不能将 R(x)、随 x 的端点/H± 代入 RG19 后免费使用 ∫K0 dx=1。以下是保守但合法的 R 适应费用接口，仍固定 s。

取全 H∈[a,b]，vs*、Es* 按 RG16 定义。逐 x 的 H(L,x) 随 L 单调，其正变差被全 H 路径的正变差支配。初值付 DEs*，RG18 仍用 D[(n+1)Es*+vs*]。source 面的其余 n−1 坐标须用共同尺度包络，给
\[
 \text{RG15右端}\quad\leadsto\quad Dn(b-a)E_{n-1,s}^*/a, \tag{RG20}
\]
其中 E0,s*=1，E_{n-1,s}*=1+log(b/a)[(n−1)(1−s)+3√(n−1)/4]。理由是面上 fs/H≤1/a，剩余 receiver 的共同 H 包络积分为 E_{n−1,s}*；Lf 的两面 Jacobian 不变。

连续位移矩可用正径向包络显式付款：
\[
 \sup_{H\in[a,b]}P_{s,H}(x)
 \le P_{s,b}(x)+n\int_a^bP_{s,H}(x){dH\over H}.
\]
因此其质量≤Bn=1+n log(b/a)，一阶 l1 矩≤(11/12)nb Bn。RG17 在适应 H 情况可用
\[
 {Dn\log2\over2j_s}B_n
 \left({3\over2}+{11L_\phi b\over12a}\right) \tag{RG21}
\]
替换。这里未把 source-z 面上的 x 适应尺度视作固定尺度。沿实际路径先逐 x 充账，再用统一完整窗口的正包络，才允许 receiver 积分。

RG20–21 保留了适应 R/端点的额外维度价格；若原比例带有两个连通部分，仍各付一次。原 j/窗口重用不由该正包络消除。s(x) 的选择也没有由“对每个固定 s 统一”自动付掉：若 s 固定有限 N 菜单，可正放为 N 份；如欲用 R198 Jeffreys 工具，须对这里整个非线性捕获势/1/js 费用另给合法比较，不能仅混合裸 K0 后宣称本稿 α 与 good 门也已混合。

## RG9　零支、原回代与第一个未付费用

1. s=1：外 current 硬面振幅为零，本文 lost-current-face 总量为零；不代入 1/js。s=0：py 在其硬核支撑外为零，只有 L=max_i2|xi−yi| 的首次非零进入可能造成 current-face good 损失，后续 current 坐标面不产生 py 跳。该一次损失≤相应 k；固定或适应 R 的 receiver 价可用 D[1+n log(b/a)]（即 n 维、s=0 的全 H 包络价），无需 log-good 除零。源 ν=0、QJ=0 行不使用 α 分式，实际 RC target 按原零约定处理。
2. 原 Z 的全部删除和 Bhard 的进入已在 F 只减中保留；没有假设 ν≤β、来源坐标独立或 f 光滑。原 ν≪Leb 仅用于共面 source 零集；若换成任意原子测度，应把 Q/K0 与外面同时跳完整保留，而不是套 RG2。
3. RG5–21 是真实 lost-capture 量的正积分工具，不是原 raw 恒等式。R199 FS14 仍含 target 的 H+A+、F−、J²/(a_v S_v QJ) 与原 βΠ_t²、source/receiver 掩码。它们可能依面/receiver/target，不能用 RG19 的无权归一直接提出，也不能把 ν(V) 乘 β(V) 自动换成线性 W_A。
4. 原 αQJ=Dq−∫Uν 保持不变；α=0 时 RG1–21 不除 α，给 capture 本身的预算，但任何原正 target 仍照其零支处理。逐面 α 上跳由同源 lost-capture 给出，跨面之间可下降；本稿正是给这种下降所需恢复的可量化路径位置，不再默认 α 沿全 L 单调。
5. 全局求和需保每个实际 j、窗口及两分支。若先扩成所有固定 j 时间窗，完整时间费仍在；unique-j 只在原同一 receiver 时点可用。窗口不同时，log(L1/L0)、Es、vs 留在各窗内，或统一用 log2 及相应最坏常数。

最早尚未支付的步骤是：在 RG6 的实际恢复测度上保留 FS14 的 target/source 权，证明一个可由原 source/current 容量支付的加权积分界，同时保留 high/reciprocal/FIRST/history 的新进入。当前结果已把恢复变为明确物理导数、同中心 source 面及截断对数核，而没有证明这些加权项的一般根阶预算。本稿到此停止，不把粗恢复常数登记成一般闭合。
