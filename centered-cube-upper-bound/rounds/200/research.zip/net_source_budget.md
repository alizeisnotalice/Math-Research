# R200：共同来源先积分的完整二次净面补偿

本稿沿 R199 FS1–14 的原 capture、同 α 与真实面测度，给出比逐 target 正部、以及线性 aggregate 补偿都更紧的完整二次净面判据。它改变尺度包络的合法积分顺序，但尚不证明一般 middle-hard 的根阶来源预算。有限例只验证同来源代数，不是 FIRST/FULL 物理输入。

## 1. 原对象、量词与共同选择

固定原窗口及 (ω,V,j,y,t)，用原
\[
 d\Pi_t(z)=1_{Z_t}(z)w_t(y,z)d\nu_V(z)/e_t(y).
\tag{NS1}
\]
这些对象在固定参数后不依 x 或运行的 current 尺度 L。两槽使用同一原 Π_t；不把 ν/e_t 当概率，也不重选 Z_t。外来源 β_V 和 ν_V 只由共同父控制，不假设两者的支配关系。

固定合法 s,R,j，在单个 outer-y current 硬面比较 L 的 −、+ 迹。原 q、ν、RC 常数、窗口相同；只有满足原共同合法状态与 R199 FS-A 的部分使用下述等式。没有单侧迹的状态只享 R199 的 cluster 次序，不能据此假定整个资格族 BV。

沿 R199 记
\[
 a_v=T\Delta_v,\ k_v=DK_{0,v},\ S_v=p_v+p_v^++J_v,
 \quad A_v=1_E\left[1-\frac{k_v+\alpha J_v}{a_v}\right]_+\frac{J_v}{S_v},
\]
\[
 \alpha Q_J=Dq-\int_E\min(a_z,k_z)d\nu(z),\qquad Q_J=\int Jd\nu.
\tag{NS2}
\]
p_v^+ 在 S 中是 L⁺ 核，不是右迹。原 E=Z_g∩good∩{B_hard=0,a>0}；B_hard=1_{R≤L}1_{Q_R(x)}。ν-a.e. 的 a_v,k_v,S_v,J_v 在该面具有共同背景值；Z_g 只缩、B_hard 只增。相应来源损失给
\[
 d_\alpha:=\alpha_+-\alpha_-
 =Q_J^{-1}\int_{\mathcal L}\min(a_z,k_z)d\nu(z)\ge0,
 \qquad\mathcal L=E_-\setminus E_+.
\tag{NS3}
\]
Q_J=0 是零来源行，先除去。a_v=0 的 target 余权先取零，不形成逆 a_v。

固定来源帽 B_cap（例如 R198 的 B₀/W_g(y,v)），并令
\[
 F_\pm(v)=\frac{\min((p_y^\pm)^2,(B_{cap}J_v)^2)}{J_v},\qquad
 \Delta F=F_+-F_-\ge0.
\tag{NS4}
\]
帽对该跳必须相同。原 good/high-A 资格上这仍覆盖实际 p_y²/J_v；不能对 s,L 重新选帽而不记交换。

H±(u,v)∈[0,1] 是其余全部原门，包括 bad/reciprocal、high、高 A 子域、原 history、时间资格、接收域与唯一 j。令 h=min(H−,H+)。h 可依 u,v，本面内两侧相同。只有共同合法部分需要定义两侧 A；仅一侧合法的部分归入资格进入/退出。

实际 L(x) 对所有 u,v 相同。因此可先把目标与 bad 槽积分，再在 L 上取上确界或正变差：
\[
 \int H_{L(x)}A_{L(x)}^2F_{L(x)}d\Pi_t^2
 \le\sup_{L\in\text{共同族}}\int H_LA_L^2F_Ld\Pi_t^2.
\tag{NS5}
\]
不能反向把右侧等同于 ∫sup_L；后者会丢失本稿的跨 target 净补偿。NS5 仅在原选择被该共同族覆盖时使用；没有证明任意辅助 L 都具备 FIRST。

## 2. 完整二次 aggregate 定理

令 V₊={v:A₊(v)>0}。在 V₊ 上定义
\[
 d_v=\frac{J_v^2}{a_vS_v},\qquad A_-=A_++d_\alpha d_v.
\tag{NS6}
\]
定义以下均为**同一原** dΠ_t(u)dΠ_t(v) 下的非负积分：
\[
 P=\int h A_+^2\Delta F\,d\Pi_t^2,\quad
 C=\int_{V_+}hF_-A_+d_v\,d\Pi_t^2,\quad
 D_2=\int_{V_+}hF_-d_v^2\,d\Pi_t^2,
\]
\[
 X_{\rm tar}=\int_{\{A_+=0\}}hA_-^2F_-\,d\Pi_t^2.
\tag{NS7}
\]
这里 X_tar 包括失去 good/terminal/capture 资格及余权被 α 完全压至零的 target。它不是旧删除负信用。

**定理 NS-A。** 在共同迹、有限截断且 NS7 有限时，
\[
 \boxed{N:=\int h(A_+^2F_+-A_-^2F_-)d\Pi_t^2
 =P-2d_\alpha C-d_\alpha^2D_2-X_{\rm tar}.}
\tag{NS8}
\]
当 dα=0 时先直接使用 N=P−X_tar，不形成 0·∞；C、D₂及根判据仅在所列有限截断或可积条件下使用。dα>0 的 still-active 槽有 a_v>α_+J_v≥dα J_v，因而 dα d_v≤J_v/S_v≤1，但这不自行支付 F_- 的来源积分。NS8 保留相同来源产生的二次项，不把它并入不定号余项。它严格蕴含先前线性界 N≤P−2dαC−X_tar。

证明。在 V₊ 用 NS6 展开 A_-²；乘 F_- 并把 A_+²(F_+−F_-) 单列，得到三个所列项。在 A₊=0 上恰为 −A_-²F_-。同一 dα 对全部 target 公共，故积分后仍是同一个 dα 和 dα²。证毕。

附带可核校验为
\[
 C^2\le D_2\int_{V_+}hF_-A_+^2d\Pi_t^2.
\tag{NS9}
\]
这是 Cauchy 上界，不能倒过来作为补偿所需的 C 下界。

### 整体净面消失判据

若 P≤X_tar，已有 N≤0。若 P>X_tar 且 D₂>0，则
\[
 N\le0\iff d_\alpha\ge
 d_{\rm crit}:=\frac{\sqrt{C^2+D_2(P-X_{\rm tar})}-C}{D_2}
 =\frac{P-X_{\rm tar}}{\sqrt{C^2+D_2(P-X_{\rm tar})}+C}.
\tag{NS10}
\]
若 D₂=0，则 NS9 给 C=0，必须直接使用 N=P−X_tar。所有量都按原面后的实际 A、共同来源计算；NS10 不能作为重新选择 α 的规则。

与逐 target FS9 不同，NS10 允许部分 target 有正净增量，另一些 target 的同 α 损失或退出将其抵消。对有限面菜单或已认证 BV 路径，同一固定来源测度下
\[
 [\int n_vd\Pi_t^2]_+\le\int[n_v]_+d\Pi_t^2,
\tag{NS11}
\]
所以必须在积分后取正，才能使用这种覆盖。它消去的是共同状态的净面变差，不声称相应原 raw 时间交通为零。

## 3. 来源损失的物理带状表达与资格进入

在共同背景值中，置
\[
 C_\pm=Z_{g,\pm}\cap\{B_{{\rm hard},\pm}=0,a>0\},\quad C_+\subset C_-.
\]
令 η_±(z)∈{0,1} 是原 good 指示的实际单侧迹，不能以极限背景的闭不等式擅自指定阈值等号层。忽略 min(a,k)=0 的无质量槽，E_±=C_±∩{η_±=1}，且 η_+≤η_-。NS3 的 lost 集因此具有精确不交分解
\[
 \mathcal L=
 (C_-\setminus C_+)\cap\{\eta_-=1\}
 \;\dot\cup\;
 C_+\cap\{\eta_-=1,\eta_+=0\}.
\tag{NS12}
\]
第二项的 good 迹差满足严格带/闭带夹逼
\[
 \{p_y^-w_g<KQ<p_y^+w_g\}
 \subseteq\{\eta_-=1,\eta_+=0\}
 \subseteq\{p_y^-w_g\le KQ\le p_y^+w_g\}.
\tag{NS12a}
\]
在 KQ=p_y^-w_g 或 KQ=p_y^+w_g 的层上，保留实际 η_±；不声称该层 ν 零。第二项是真实共同 good 阈值带及其有迹端点；第一项是 terminal/原硬捕获的退出。每个来源在这一次跳中至多计算一次，没有新 source probability。它保留 min(TΔ,DK₀) 的真实密度，而非使用无权 lost 质量。

NS12 对 positive compensation 的用途是给 dα 的真实值。原 FIRST 与 reserve 只给当前可用容量的上界；它们没有给 NS12 这条具体阈值带的质量下界。特别不能从 ∫k(μ−χ)≤αQJ 推断 dα≥dcrit。

对所有原 H 的交换，用共同权 h 具有精确分解
\[
 \int(H_+A_+^2F_+-H_-A_-^2F_-)d\Pi_t^2
 =N+I_H-X_H,
\tag{NS13}
\]
\[
 I_H=\int(H_+-H_-)_+A_+^2F_+d\Pi_t^2,\quad
 X_H=\int(H_--H_+)_+A_-^2F_-d\Pi_t^2.
\]
所以实际正净面至多
\[
 [P-2d_\alpha C-d_\alpha^2D_2-X_{\rm tar}]_++I_H.
\tag{NS14}
\]
新的 high、bad/reciprocal、history、时间窗和 selector/FIRST 资格入口完整留在 I_H。仅一侧合法的状态直接使用相应完整入口/退出值，不借另一侧 α。不能把 I_H 也当作 NS10 已付。

## 4. 同来源有限例：二次与共同积分确有额外效力

此例只核原形式的共同 α、E(p) 和平方代数；不认证实际 φ 核、FIRST、原森林或 FULL。

来源 ν 三点质量为 (3,1,1)，给定
\[
 a=(4,100,2),\quad k=(1,1,5/4),\quad J=(1,1,1),\quad
 Q=(1,1,41/100),\quad w_g=(1/4,1/4,2/5),
\]
\[
 K=1,\quad Dq=21/4,\quad p_-=1,\quad p_+=2107/2000.
\]
所有点共同 terminal、B_hard=0。E_- 是三点；E_+ 是前两点。Q_J=5，直接计算得 α_-=0、α_+=1/4。取 Π=ν/5、固定帽 B_cap≥2，h 只保前两 target，另一槽总质量 1。

前两点
\[
 A_-=(1/4,33/100),\quad A_+=(11/48,79/240),\quad
 d_v=(1/12,1/300).
\]
以下为便于核验，全部积分值都乘回共同 5：
\[
 P=560883407/19200000000,\quad C=1051/18000,\quad D_2=469/22500,\quad X_{\rm tar}=0.
\]
于是
\[
 P-2d_\alpha C=1050221/57600000000>0,
\]
\[
 N=P-2d_\alpha C-d_\alpha^2D_2
 =-73989779/57600000000<0.
\tag{NS15}
\]
两个 target 的未乘来源质量的净增量分别为
\[
 -38826671/9216000000,\qquad
 2616041209/230400000000>0.
\]
因此逐 target 先取正部和只保线性 aggregate 都不能认证此面消失，完整二次 aggregate 可以。这里的 α 不是自由挑选，而由同一来源 E± 算得；也没有以该有限例宣称原 FULL 覆盖严格扩大。

## 5. 全路径与原外积分的准确账

固定 s 的面 coarea 为
\[
 \sum_{i,\pm}\frac L2\,d\mathcal H^{n-1}(x)\,d\log L.
\tag{NS16}
\]
原 current 选择器 L(x)、s(x) 在同一窗口也对 outer y 共同。因此在固定 receiver、j,t 与共同参数域时，还应优先使用更外一层
\[
 \int\beta_V(dy)\int H_{L(x),y}A_{L(x),y}^2F_{L(x),y}d\Pi_{y,t}^2
 \le\sup_L\int\beta_V(dy)\int H_{L,y}A_{L,y}^2F_{L,y}d\Pi_{y,t}^2.
 \tag{NS16a}
\]
这里 \(\beta_V(dy)\Pi_{y,t}^2\) 虽依 y，却不依运行 L。允许将 y-dependent 的原可定义域放在该固定测度内；t≤h(L)、unique-j、FIRST及其它随 L 的资格仍在 H_L，不能假装固定。若不同窗口具有不同选择器，NS16a 不跨窗口合并。

因此逐 y 先取正也可能丢失合法抵消。原 β_V≪Lebesgue 时，仅就外 y 核硬面部分，在有界截断下将 y 推送到 L=2|x_i−y_i|，得到关于 dL 绝对连续的来源壳通量：coarea 的导数模为 2，密度系数 1/2。这容许将该来源壳通量与同一 L 的连续尺度通量联合再取正。它不证明整个 H/α 路径绝对连续或 BV，也不自动把壳通量交给 FIRST 付款。未截断时须由相应可积性/正测度极限合法通过，不写 ∞−∞。

共同来源净面预算必须将 NS14 在此真实测度、β_V(dy)、原 ω,V,j、原 dt/t 窗及原接收域上积分。两个 Π_t 已在 NS7 中保留。不能把其权重改成 ν/e_t 的概率，也不能把 β 换成 ν。共同 target 积分顺序只改变净通量的计算，不授予跨 y 或跨窗口的免费抵消。

来源跨多个面重新进入 capture 后可能再次失去。NS12 每面只计一次，但没有说整个路径每个来源只失去一次。NS8 必须与真实连续恢复/状态交换一起使用；不能把 Σ_faces dαQJ 直接上界为一次 Dq。该跨路径恢复由本轮独立工具处理；本稿不重复领取其信用。

若合法尺度路径族具有所需 BV，最终需用起点、连续正变差、NS14 的净正硬面、其余资格入口共同支配实际伴随。若还要覆盖软度选择，R198 的混合成本及该混合与资格的一致性义务仍保留。放宽唯一 j 为固定时间参考后必须支付全 \(\mathcal T_*\) 或逐窗总和，不能因为先积分 target 而删去。

若最终这些项确能合计证明原伴随 \(\mathcal C\le B_nW_A\)，则已修复的原能量
\[
 \mathcal E_{J}\le nW_\nu/(2K),\qquad W_\nu\le W_A
\]
给
\[
 \operatorname{Raw}\le\frac{32\Lambda}{3}\sqrt{\frac{nB_n}{2K}}\,W_A.
\tag{NS17}
\]
本稿尚未证明这种 B_n；NS17 只列真实回代系数，不把未控制的面量命名为已付预算。

第一处实质未付关系是：在原真实 NS16 配重下，NS12 的 capture 带质量及退出 target 是否足够大，使 NS14 的残余正部与 I_H 具有允许的来源/接收费用。FIRST 给上容量，不能反向供应这个下界；同时即使共同状态 N≤0，I_H 仍可能为正。因此本轮不认证一般 root 闭合，也不把 NS10 当作另一个原 raw 任意切门。严格成果是共同选择下完整二次净流计算，以及它确实强于逐目标/线性计费的有限同来源验证。后续应在此共同净流上证明覆盖，而不是恢复逐 target 上确界。
