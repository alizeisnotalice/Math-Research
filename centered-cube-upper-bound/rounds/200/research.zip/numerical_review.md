# R200 exact reentry and aggregate checks

The approved checker passed seven ramp paths and three common-source aggregate fixtures with Fraction only. It constructs finite path/algebra examples, not physical kernels, original coarea/FIRST/history or FULL inputs. No phi-half evaluation, arbitrary parameter scan or asymptotic fit was needed.

## Ramp ledger

For j>0, Psi_j(l)=clip((l+j)/(2j),0,1) and V=F c Psi_j(l), with F in {0,1} only decreasing. Each outer event keeps c fixed and changes l by exactly -j. Its weighted lost cost is c if F survives and lminus belongs to the closed interval [0,j], or if F is simultaneously deleted with lminus>=0. The disjunction is counted once. Each event independently checks cost<=2(Vminus-Vplus).

The whole path separately totals nonouter positive and negative potential changes, checks the exact signed-recovery budget and its weaker version retaining only positive recovery. Three stages cover a single face; repeated entry with recovery plus both closed endpoints; simultaneous deletion, legal scaling and j=0. At j=0 the event list is empty and the ramp quotient is never evaluated. The same rule is not extrapolated to a zero-j jump.

The key repeated fixture j=c=F=1 has l=1/2 -> -1/2 -> 1/2 -> -1/2, with the middle step nonouter recovery. The potentials are 3/4,1/4,3/4,1/4. Weighted lost cost 2 equals the full budget 2; omitting recovery gives the incorrect upper bound 1. A scaled fixture with j=3/2,c=7/3 reproduces the identity at cost 14/3. Endpoint fixtures at lminus=0 and j both incur the closed-threshold cost; a strict endpoint test would incorrectly omit them. These finite checks illustrate the ledger, not an original path-level integrable source budget.

## Same-source aggregate compensation

Each fixture fixes nu,a,k,J,Q,wg,K and Dq. E(p) is recomputed from p wg<=KQ and a>0, with all other abstract gates fixed true. At each endpoint alpha=(Dq-sum_E min(a,k)nu)/QJ, QJ=sum J nu. The checker verifies source capacity sum k nu<=Dq, nesting of E, and delta-alpha QJ=lost capture mass. It does not freely choose two alphas.

The initial fixture uses the author's two-source arrays with pminus=1,pplus=6/5. It includes a target that exits E. Its two target nets are 21/1600 and -2500/15129; the total before posterior normalization is -3682291/24206400, while the sum of target positive parts is 21/1600. The generic signed-square identity is checked, but the retained-target quadratic formula is deliberately not applied to the exiting target.

The stress fixture uses nu=(3,1,1), a=(4,100,2), k=(1,1,5/4), J=(1,1,1), Q=(1,1,41/100), wg=(1/4,1/4,2/5), Dq=21/4 and pplus=2107/2000. Only the first two targets are retained by the common target mask. Both recomputed alphas are 0 and 1/4. Direct target evaluation and the independent aggregate expansion agree exactly with:

- P=560883407/19200000000,
- C=1051/18000 and D2=469/22500,
- P-2 delta-alpha C=1050221/57600000000>0,
- P-2 delta-alpha C-(delta-alpha)^2 D2=-73989779/57600000000<0.

Individual target nets are -38826671/9216000000 and +2616041209/230400000000. Thus the positive second target and positive linear aggregate do not certify a positive complete aggregate. The expanded fixture scales nu and Dq together by 7/3; endpoint alphas and posterior-normalized aggregate stay unchanged.

For every aggregate case the complete posterior is Pi=nu/sum nu, corresponding to the stated abstract wt=1, rather than a renormalized eligibility law. The code independently computes the explicit Pi_v Pi_u double sum and the factorized sum, including all u mass. Both agree exactly. Positive part after aggregation is zero, while the sum of target positive parts is strictly positive. This is a finite conditional algebra distinction, not authorization to change the positive-part order in an original bound without its precise hypotheses.

## Reproduction and scope

Use standard-library Python only:

```sh
python3 reentry_checks.py --output reentry_checks.json
```

Relocation requires just the script and local task_contract.md, bound by its filename hash in JSON. Output is deterministic and includes all rational inputs and ledger entries. A fresh temporary-directory copy was run once and its complete JSON matched byte-for-byte. No other agent's files were edited. L03's exact-residual discipline is retained; no floating or interval certificate is invoked. These examples do not prove general physical reentry payment, eligibility-entry control, or an original root-scale source budget.
