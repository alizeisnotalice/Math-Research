# R200 独立审计

仅维护本文件；非独占仓库，无Git/spawn/他人编辑。先读task_contract.md，以下先于本轮作者全文。一般原来源预算尚未闭合。

## 1. FS14跨面的方向和重用检查

固定同一nu、J、QJ>0、C=Dq及原合法s,R,j/window族时，M_U(L)=integral U_L nu，alpha QJ=C-M_U。有限partition上精确有总下降<=初始M_U+总恢复上升；若实际族BV，外current面capture损失之和<=M_U(a)+Var⁺(M_U)，也可先逐source再以integral[U_a+Var⁺U_z]nu收费。连续min(a,k)增长、good重新进入与source kernel面均可能恢复可再失去的质量。每时刻0<=M_U<=Dq或reserve上界不控制累计恢复。

FS14的正部是[正面项-实际补偿]_+。一个lost总量上界不能上付此正部；需实际联合补偿下界或完整加权path不等式。target系数F^-A^+J²/(aS)随L和v变化，不能把无权lost望远镜直接套进去。若改用product-BV，必须保系数变化、资格进入及所有非kernel跳；cluster序不授BV。分式仅在有效活跃a>0支使用，零支按原有限表达，不作0乘无穷。

原L(x)对u/v共同，但fixeds/R/j辅助path不等于已认证原FIRST/history family。改变s、R、j、window、source或J/QJ会产生新的状态/归一费用。原time域随g变化也须在同一H中保留。所有receiver积分须真实dx/coarea；不能用y-u近替target/source cell近。

## 2. ramp恢复候选：作者前独筛

Sol准确候选取j_s=log[(1-s+sphi(.5))/(sphi(.5))]>0，ell_z=log[KQ_z/(p_y wg_z)]，F_z=1_{Zg,Bhard0}，Psi(ell)=clip((ell+j_s)/(2j_s),0,1)，V_z=F_z c_z Psi(ell_z)。需c_z=min((a_z)_+,k_z)，或将路径限于h>=tau的非空far部分，不能因g>=tau就假a=TDelta>=0。

孤立outer current面有ell_+=ell_--j_s。若good资格丢失且carrier不丢，trace端点需允许ell_-∈[0,j_s]，Psi差仍恰1/2。若同刻Z删/B进入导致capture丢失，ell_-可更大，此时F_+=0且Psi_->=1/2，同样给V下降>=c/2。故跨面lost总量<=2[V_initial+非outer面的正恢复]，可保末态扣除。它是来源反复使用的准确上账，不是FS14所需补偿下界。

恢复包括完整(dc)_+（尤其K0源硬面）、c/(2j_s)(dell)_+、Q_z源hard跳；Z/B只向下。s0/s1与p零集另处理，不能在j_s=0用分式。只声称具资格的fixed参数族，未认证整个原G的path/BV。

## 3. 显式恢复收费的两个锐化：独筛

固定far路径a=TDelta，T下降、Delta上升。A0=T_start w_tau，K*=sup_L k；在a<=k处置z=Delta/w_tau，active正恢复<=integral_0^1min(A0,K*/z)dz=:Phi(A0,K*)。Phi=A0当K*>=A0；Phi=K*[1+log(A0/K*)]当0<K*<A0；K*=0先取0。因此Var⁺min(a,k)<=Phi+Var⁺k。可用任意0<p<1的Phi<=A0^(1-p)(K*)^p/(1-p)给显式而可能指数大的receiver费用；不把其称root。

源Q的两个current尺度各至多n个coordinate entry，每个logQ正跳<=j_s，ramp正跳<=1/2。固定Hhat(L)参数族，同中心coarea给

integral dx sum_(Q-source-faces) K0 <= n integral_I [f_s(L/(2H))/H+(Lplus)' f_s(Lplus/(2H))/H]dL <=2n(b-a)/a。

末步用Lplus(b)-Lplus(a)<=b-a，不能误称(Lplus)'<=1。乘D与ramp的1/2后为Dn(b-a)/a。

这些归一与moment积分要求Hhat(L)对正在积分的x是fixed参数族。若实际R=R(x)、端点或Hhat依receiver，不能原样用integral K0=1；需另证selector包络或明确只作fixed参数kernel工具。全局窗口费用须统一或逐窗保留。上述有限恢复上界不直接控制原target配重、Mi^-1或资格进入。

## 4. aggregate target有限跳：作者前独筛

固定j,y,t的同一原Pi_t²确不依运行L，且原selector对u/v共同。若H两侧相同，可先积signed target差再取正。stillactive部分精确减去deltaalpha integral H F^- J²(A^-+A^+)/(aS) Pi²；A^+=0的exit保全部负项-integral H(A^-)²F^- Pi²。同一个deltaalpha不能为各target另选。

[ integral net ]_+<=integral[net]_+，完整positive variation亦可在共同测度、可测path及有限截断下使用；这比逐target先正放更紧，但不是新增来源价。H变化、随g移动的time域、j或来源measure变化须先共同状态并保精确交换。原Pi fixed不能推出H fixed。等待作者实际联合比例/费用及全文，不以积分顺序改名为一般进展。


## 5. 同一actual deltaalpha的完整二次aggregate：独筛

父发送准确二次式后独推，未读其证明。共同合法状态取h=min(H^-,H^+)；stillactive d=J²/(aS)、A^-=A^++deltaalpha d。定义

P=integral h(A^+)²DeltaF，C=integral_still hF^- A^+d，D2=integral_still hF^-d²，Exit=integral_{A^+=0}h(A^-)²F^-。

精确净量为N=P-2deltaalpha C-deltaalpha²D2-Exit。若P<=Exit，则N<=0；若P>Exit且D2>0，N<=0等价于

deltaalpha >=[sqrt(C²+D2(P-Exit))-C]/D2。

D2=0时C=0（在共同finite/truncated积分中），P>Exit则不能由此消失。deltaalpha=0必须先用N=P-Exit，不能形成0乘可能无穷的C/D2。deltaalpha>0时stillactive a>alpha^+J>=deltaalpha J使deltaalpha d<=1，但仍需F^-来源可积/有限截断，未付全局费用。

完整state跳为N+Entry-ExitH，其中Entry=integral(H^+-H^-)_+(A^+)²F^+，ExitH为反侧对应非负量，因此正部<=N_++Entry。h仅在两侧都有合法定义的状态使用，单侧入口不补造alpha前态。该阈值用原lost/QJ的同一actual deltaalpha，不是可自由优化的参数。它给更紧实际aggregate判据，不自动给其所需联合质量下界或全局付款。


## 6. 作者后读：全路径恢复稿

全文核验reentry_geometry.md通过，已处理唯一端点修项：RG1统一右起态/闭端右末态，outer和为(L0,L1]，V(L1)为完成物理/删除更新后的右值；若左末态则同改为开末和V(L1-)。缺原右资格的端点只给辅助势估计，不补合法alpha。

RG2–6闭端good-loss与F删除分开、V物理BV不推原good-BV、完整source K0/Q恢复均准确。RG7–13的T/Delta实际导数、Phi截断对数恢复、有限增弧替代、1/j_s与真实一阶矩均正确。RG14同中心source coarea保Lf普通导数与右大值；每component ramp最多1/2后RG15系数正确。RG16–19固定参数receiver价显式但非root，且仅lost上账。

RG8没有偷用actual R(x)归一：初值/Var+k用全H正包络，source面剩余n-1维付E_(n-1,s)，连续位移矩付Bn=1+nlog(b/a)，零维与s0/s1单列。仍固定s，soft选择和两比例分支/j/window各自收费。RG19的无权nu质量不能替FS14 target/source配重；其首缺口准确。

## 7. 作者后读：共同来源aggregate与shell接口

全文核验net_source_budget.md通过。NS8/10完整二次及deltaalpha0/有限积分守卫正确，exit target全部负项保留；NS9 Cauchy是上界而非补偿下界。数值例的P/C/D2乘回5与原Pi归一约定清楚。

父指出并由作者修复的NS12现已实读：eta±为actual good traces，lost精确分成carrier退出与共同carrier的eta-1/eta+0。严格阈值带包含于迹差、迹差包含于双闭端阈值带；端点层保eta而不假nu零。NS3/8不受该窄修影响。NS13 H交换、NS16a更外共同y选择器与j/time/window费用准确，未重选后验或把判据当全体付款。

global_shell_aggregation.md全文通过。fixedx的y_i=x_i∓L/2换元确给(L/2)dlogL，beta density只以联合coarea的a.e.L代表元出现，不宣称每个fixedL有空间trace。signed shell先聚合再正部可严格更紧；其所需共同合法族/加权绝对可积/有限截断及连续与非kernel项均明列。它是合法积分位置，不是一般来源预算或完整alpha/H族BV证明。

## 8. 数值静态核验

逐行静核reentry_checks.py及numerical_review.md，无另行运行。7ramp检查约定的闭端包络lost，source F只删、外面c不变、重复恢复的正确与错误预算均准确；这些不认证连续Phi导数或actual trace必然损失。3aggregate由同一E(p)和完整source数组重算alpha；退出target不套stillactive二次，C/D2/完整平方符号及nu和Dq共同缩放均准确。

Pi明确为完整nu/e、wt=1，显式Pi_v Pi_u双和独立核对factorized net/e和逐target正部，未归一化到eligible子集。Fraction仅证有限数组/路径；非physical/FIRST/FULL和非一般root预算标签清楚。作者报告隔离全JSON字节一致，本审计只作静态核验。


## 9. 报告与复现入口窄审

report.md与已审三稿一致：完整二次仅给共同净面判据，ramp lost总量上界不能上付FS14；fixed/adaptive恢复费、共同source壳层接口、beta nu双质量尚未线性化及soft/j/time/window入口均明确保留。7+3有限代数的非physical/FULL标签准确，没有将局部净消失称为原raw整支付款。

reproduce.py静态通过：先核未来manifest，要求新JSON输出位置，运行唯一标准库脚本、传递非零退出并比较完整JSON字节。父报告7+3实际重跑一致；本审计不另执行。总driver须在manifest生成后由父实际运行，当前不提前认证。等待详细tex一次最终整合核与哈希绑定。


## 10. 最终整合核验与冻结

proof.tex.txt原565行全文及最后新增容量资格句均已核对，与三份责任稿一致：两侧原K0-FIRST保alpha非负，单侧资格不能借共同补偿；NS12实际eta端点、deltaalpha零支、完整二次/target退出、RG右起闭端右末、Phi恢复和适应H正包络、GS有符号coarea均准确。最后版本566行，不编译PDF。当前无必须修项。

最终report/reproducer及7+3脚本/JSON/notes已核相同范围；父与数值作者报告实际完整JSON重放一致，本独审没有重复运行。最终manifest总driver与归档复核由父后续实际执行，不提前声明完成，不循环绑定manifest。

通过范围为：同一actual来源/共同选择器下的完整二次净面判据，具有明确物理恢复费用的ramp全路径上账，同中心source面压缩，以及合法有符号共同壳层接口。来源重新进入未被免费忽略，lost上容量未被反向当补偿下容量；原target/source权、资格入口、soft/j/time/window及FS14一般root预算仍未付。不认证一般弱型闭合或新增原raw整支付款。

以下实算绑定当前10个其他work文件；排除本文件自身及未来manifest。到此冻结停止，仅维护本文件。

| 文件 | SHA256 |
|---|---|
| global_shell_aggregation.md | `351ffc34feb7c10a231cb2c907ebe1457601bed27d36fe05cbb1b525ac5bbce2` |
| net_source_budget.md | `829964f004bb3fe6a4447d672498c53d5e2a200f8feaf8f5abdcbb61852e63c9` |
| numerical_review.md | `30091e87528f623f9bc77e69b9887db4a952d842db94eff50da77417d4e575fb` |
| proof.tex.txt | `8508deecc59f9517c2312f5b9084a987c4621bd765485f183d87446b2719ffbd` |
| reentry_checks.json | `e2b861f29760ecce0d65be21b33c9a11c6ab57a82a8494a5a16f7f99ce12b3f4` |
| reentry_checks.py | `4bab8b680f1f744228bc87905481bb03204f9f7835c8cf00aadfdd5b2b2804e1` |
| reentry_geometry.md | `75ca1c4aa54dd5fb051d0d2270ce42339a2bc2f7f8c35b57f755c2ffce4e9905` |
| report.md | `9b5cc86892aa5e9ba1c7804714267ab178398cb1f584295c5741520523cf12be` |
| reproduce.py | `3800d23bd93f1069358f37ebd79c92ec66e70fd4ffc30c693337076b9b05eccd` |
| task_contract.md | `a88af83d4baf946025f06b4d834b5de321f3016e101a907ba09d8cf4aff470ef` |
