# 第200轮：共同净面二次补偿与捕获恢复预算

一般任意正L1输入的n^(1/2+o(1))一致弱型上界仍未闭合。本轮基线为第199轮0823d094c8fc1723c2c9296133c4c9f6bb84a727。目标是实际联合来源净流，不重复裸线性逐面估计或泛化反例排除。

## 本轮严格结果

共同尺度下，先在原Π_t²测度上积分target/bad槽，再取净通量正部。对共同合法面、h=min(H−,H+)、仍活跃target d_v=J²/(aS)，完整净跳为N=P−2δα C−δα²D2−X_tar。δα仍由同一原来源失捕获质量除QJ给出；C、D2均为实际后态积分，不能自由调整α。退出target与完整二次项保留，给NS10的整体净面消失判据。它允许个别target增长，并在有限同来源例中严格强于逐target先取正部及只留线性补偿。判据不等于某一原raw时间分支已付款。

原good阈值带的两端须保真实单侧门η±；严格带包含于真实loss、真实loss包含于闭带，不能把背景等号值当作侧迹。此处经审核修正。所有only-one-side合法状态、新high、history/reciprocal/FIRST入口和全部j/time仍保留。

对同一来源跨多个外硬面，构造宽度由真实跳幅j_s决定的线性ramp势V=F min(a,k) Ψ(log(KQ/(py wg)))。每次实际capture损失≤2倍势下降；重新进入必须由势的恢复付款。这个势具有物理BV，而不假设原good指示函数BV。端点统一右起态、闭端右末态和(L0,L1]面和，避免重复端点。

恢复具有明确费用：a=TΔ的a控制正恢复≤Φ(A0,K*)=∫0¹min(A0,K*/z)dz，K*<A0时等于K*[1+log(A0/K*)]；同中心Q来源面用精确coarea只付Dn(b−a)/a；连续log-good导数、一阶位移矩、K0正变差及适应R的额外正包络均完整保留。RG19/20/21给任意原L1来源的显式有限路径价，但粗维度价格并非根阶，也不声称比简单面计数更小。新作用是明确重新进入的实际物理费用和加权位置，不能把lost总量上界当作所需负补偿下界。

此外，真实同window L(x)对outer y也共同。β绝对连续时，外source硬跳可按coarea推为共同尺度上的来源壳层密度，之后才取正部；其代表元仅a.e.尺度有意义。global_shell_aggregation.md是准确积分接口，非新增付款定理。整体α/history的BV资格不能由这一局部壳层接口推出。

## 定义、证明与独审范围

net_source_budget.md给实际二次净流；reentry_geometry.md给全路径ramp和恢复价；global_shell_aggregation.md明确共同外来源聚合。详细LaTeX为proof.tex.txt。引用R199/198/196等已证工具均保各自范围，不导入新外部文献定理。阈值迹和端点费用经独立审查处理；audit.md记录独筛与作者后读。

全部receiver仍是真实Lebesgue及L/2 coarea；α、ν、β、Π_t²、窗口与time不重选。共同测度的finite truncation不能重算α；所有signed极限须相应可积，不能用∞−∞。固定s,R,j范围与接收点适应选择的额外费用分别保留。

## 实际数值与复现

本机Python Fraction实际通过7条ramp路径及3组同来源aggregate，完整JSON隔离重放一致，主代理也重跑一致。三阶段覆盖初探、闭阈值/删除/重复进入压力、合法质量缩放和扩大参数。重复进入例lost=2、完整预算=2，而漏恢复会错误得到1。退出target例聚合负但逐target正部为正；三来源例线性净1050221/57600000000>0，完整二次净−73989779/57600000000<0，且一个target自身仍为正。完整Π_vΠ_u双和与简化积分独立对照，没有对eligible集合重新归一。

这些是有限条件代数检查，严格标签为非physical/FULL；不能证明一般原几何可实现、均匀维度阶数或入口预算。按L03技能区分精确代数证书与物理证明。本轮未作浮点拟合，不需要新增依赖；python3 reproduce.py --verify-only；python3 reproduce.py --output-dir <新的空目录>。最终driver核验以归档前实际执行为准；不编译PDF。

## 首个未付关系与下一步

仍须在原真实来源/面测度下，证明[P−2δα C−δα²D2−X_tar]_+与资格入口I_H的合计预算，而不是仅给NS10一个名字。FIRST和reserve提供上容量，不能反向供应具体good阈值带的lost下界；RG恢复上界也不能替代它。原target权依面、source和receiver，尚不能从RG19提出或把β(V)ν(V)换为线性W_A。

下一步应在共同source-shell净通量上与连续负Jacobian项联合估计，尽量保outer y/target的公共尺度，避免再次把每个来源分别取上确界。所有s选择、Wg、全j/time、适应R/history入口均仍在总体目标内。本轮没有证明一般根阶，也没有把局部净消失当成raw整支完成。

复用1 Astra high、2 Sol high、1 Sol medium；缺少逐模型实际扣额数据，不猜模型成本。完成核验后单轮提交，精简归档；展开文件备份到仓库外。
