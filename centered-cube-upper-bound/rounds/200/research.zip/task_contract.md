# R200：同一来源跨硬面的净通量与重新进入预算

基线R199提交0823d094c8fc1723c2c9296133c4c9f6bb84a727，完整检查点/Users/zhengzhihao/Desktop/T/output/centered_cube_round199_20261016_final_checkpoint。一般任意正L1一致根阶目标不变。重心为原FS14联合来源积分，不以重新命名余项或有限toy结论代替付款。

必要定义见R199 flux_source_budget.md FS1–14：共同固定(ω,V,j,x,y,R,s)，p_y在current硬面正跳；a_z=TΔ_z,k_z=DK0_z,S_z=3Q_z,J固定。E_L=Z_g∩{p_y w_g≤KQ_z}∩{B_hard=0,a_z>0}；U=1_Emin(a,k)；αQJ=Dq−∫Uν。共同合法状态、合法迹处，δαQJ=∫lostmin(a,k)ν≥0，A+≤A−，净截帽平方跳=A+²ΔF−F−(A−²−A+²)。FS9给消失判据；没有整体BV保证，资格新入口须单独保留。

准确本轮目标：是否能将这些真实正净面增量，在βΠ_t²、原Lebesgue coarea及共同来源账下控制到允许根阶最终回代的预算？必须量化来源重新进入/连续恢复，不能每面重领同一lost质量，也不能把单纯capture质量上界当所需下界。可先证明能改变付款策略的新全路径不等式，但必须给实际原参数映射和费用；不得仅报告恒等式改名。所有j/time、soft混合、窗口、Wg费用保留。

允许工具：R199固定s完整cap尺度界，R198共同soft平方根混合，R196实际reserve与target联合二次补偿，R197有限位移反集中；依其原假设，不自由重选α/ν/β/history。当前反例风险只是原G不自动BV、正入口不免费、m可比n不覆盖全体；不继续泛化反例搜集。

职责：Astra主攻来源联合净预算；Sol辅助全路径再进入/连续恢复账；Sol独立审查先独筛命题；Sol medium待准确公式后用本机数学工具三阶段验证。父负责主要推导和整合。只读必要片段，各独占分配文件，不git、不spawn、不覆盖他人；阶段交付后停止。完成独审后逐轮精简提交推送，详细LaTeX不编译PDF。
