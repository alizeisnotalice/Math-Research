#!/usr/bin/env python3
"""Exact finite ramp ledgers and same-source aggregate compensation checks."""
import argparse
from fractions import Fraction as F
import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent


def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [encode(v) for v in x]
    return x


def ramp(l,j):
    assert j>0
    return max(F(0),min(F(1),(l+j)/(2*j)))


def path_check(stage,name,j,c,lstart,events):
    j,c,lstart=map(F,(j,c,lstart))
    if j==0:
        assert not events
        return {'stage':stage,'name':name,'j':j,'no_jump_branch':True,
                'weighted_lost':F(0),'ramp_not_evaluated':True,'status':'PASS'}
    state=(1,c,lstart)
    def potential(st):return st[0]*st[1]*ramp(st[2],j)
    initial=potential(state);positive=negative=lost_total=F(0);rows=[]
    for kind,lnew,fnew in events:
        f,c,l=state;after=(fnew,c,F(lnew))
        assert fnew in (0,1) and fnew<=f
        beforeV=potential(state);afterV=potential(after);change=afterV-beforeV
        lost=False;cost=F(0)
        if kind=='outer':
            assert after[2]==l-j
            lost=(f==1 and ((fnew==1 and 0<=l<=j) or (fnew==0 and l>=0)))
            cost=c if lost else F(0)
            assert cost<=2*(beforeV-afterV)
            lost_total+=cost
        else:
            assert kind=='recovery'
            positive+=max(F(0),change);negative+=max(F(0),-change)
        rows.append({'kind':kind,'l_minus':l,'l_plus':after[2],'F_minus':f,'F_plus':fnew,
            'V_minus':beforeV,'V_plus':afterV,'weighted_lost':cost,'closed_lost_condition':lost})
        state=after
    terminal=potential(state)
    loose=2*(initial+positive-terminal)
    signed=2*(initial+positive-negative-terminal)
    assert lost_total<=signed<=loose
    omit_recovery=2*(initial-terminal)
    if name=='repeat_requires_recovery':
        assert lost_total==2 and signed==2 and omit_recovery==1
    if name=='scaled_repeat':assert lost_total==signed==F(14,3)
    return {'stage':stage,'name':name,'j':j,'c':c,'no_jump_branch':False,'events':rows,
        'V_start':initial,'V_end':terminal,'nonouter_positive_increase':positive,'nonouter_negative_decrease':negative,
        'weighted_lost':lost_total,'budget_with_positive_recovery':loose,'budget_with_signed_recovery':signed,
        'incorrect_budget_omitting_recovery':omit_recovery,'omitting_recovery_fails':lost_total>omit_recovery,'status':'PASS'}


def aggregate(stage,kind,scale=F(1)):
    scale=F(scale)
    if kind=='exit_target':
        nu=[scale,scale];a=[F(4),F(1)];k=[F(1),F(1,2)];Q=[F(1),F(41,100)];wg=[F(1,4),F(2,5)]
        Dq=F(3,2)*scale;pplus=F(6,5);targets=[0,1]
    else:
        nu=[3*scale,scale,scale];a=[F(4),F(100),F(2)];k=[F(1),F(1),F(5,4)]
        Q=[F(1),F(1),F(41,100)];wg=[F(1,4),F(1,4),F(2,5)]
        Dq=F(21,4)*scale;pplus=F(2107,2000);targets=[0,1]
    n=len(nu);J=[F(1)]*n;QJ=sum(J[i]*nu[i] for i in range(n));pm=F(1);Bcap=F(2)
    assert sum(k[i]*nu[i] for i in range(n))<=Dq
    def state(p):
        E=[p*wg[i]<=Q[i] and a[i]>0 for i in range(n)]
        alpha=(Dq-sum(min(a[i],k[i])*nu[i] for i in range(n) if E[i]))/QJ
        assert alpha>=0
        rho=[max(F(0),1-(k[i]+alpha*J[i])/a[i]) for i in range(n)]
        A=[rho[i]*J[i]/(3*Q[i]) if E[i] else F(0) for i in range(n)]
        return E,alpha,rho,A
    Em,am,rm,Am=state(pm);Ep,ap,rp,Ap=state(pplus);da=ap-am
    lost=[i for i in range(n) if Em[i] and not Ep[i]]
    lostmass=sum((min(a[i],k[i])*nu[i] for i in lost),F(0))
    assert all(not Ep[i] or Em[i] for i in range(n)) and da*QJ==lostmass
    P=C=D2=negative=net=positive=F(0);terms=[]
    for i in targets:
        Fm=min(pm**2,(Bcap*J[i])**2)/J[i];Fp=min(pplus**2,(Bcap*J[i])**2)/J[i]
        d=J[i]**2/(a[i]*3*Q[i])
        pos=Ap[i]**2*(Fp-Fm);neg=Fm*(Am[i]**2-Ap[i]**2);delta=Ap[i]**2*Fp-Am[i]**2*Fm
        assert delta==pos-neg
        P+=nu[i]*pos;negative+=nu[i]*neg;net+=nu[i]*delta;positive+=nu[i]*max(F(0),delta)
        if Ep[i] and Ap[i]>0:
            assert Am[i]-Ap[i]==da*d
            C+=nu[i]*Fm*Ap[i]*d;D2+=nu[i]*Fm*d*d
        terms.append({'target':i,'nu':nu[i],'A_minus':Am[i],'A_plus':Ap[i],'d_target':d,
            'positive_face_term':pos,'negative_square_term':neg,'net_per_target':delta,'retained_active':Ep[i] and Ap[i]>0})
    assert net==P-negative
    e=sum(nu);posterior=[m/e for m in nu];assert sum(posterior)==1
    # Independent explicit double sums retain the complete source posterior.
    deltas={term['target']:term['net_per_target'] for term in terms}
    joint=sum((posterior[i]*posterior[u]*deltas[i] for i in targets for u in range(n)),F(0))
    joint_positive=sum((posterior[i]*posterior[u]*max(F(0),deltas[i]) for i in targets for u in range(n)),F(0))
    assert joint==net/e and joint_positive==positive/e
    assert max(F(0),joint)==0 and joint_positive>0
    # u-slot posterior is the same complete source law; its total mass is one.
    result={'stage':stage,'kind':kind,'mass_scale':scale,
        'inputs':{'nu':nu,'a':a,'k':k,'J':J,'Q':Q,'wg':wg,'Dq':Dq,'K':F(1),'wt':[F(1)]*n,'QJ_original_scalar':QJ,'p_minus':pm,'p_plus':pplus,'Bcap':Bcap,'H_target_indices':targets,'fixed_other_gates':'true'},
        'E_minus':Em,'E_plus':Ep,'lost_indices':lost,'lost_capture_mass':lostmass,
        'alpha_minus':am,'alpha_plus':ap,'target_terms':terms,'P':P,'negative_square_compensation':negative,
        'net_aggregate':net,'sum_per_target_positive_parts':positive,'posterior':posterior,'e':e,'posterior_aggregate':net/e,'posterior_positive_parts':positive/e,'direct_joint_double_sum':joint,'direct_joint_positive_parts':joint_positive,'positive_part_after_aggregation':max(F(0),joint),'status':'PASS'}
    if kind=='exit_target':
        assert net/scale==-F(3682291,24206400) and positive/scale==F(21,1600)
        assert terms[0]['net_per_target']==F(21,1600) and terms[1]['net_per_target']==-F(2500,15129)
        result['quadratic_retained_formula_applied']=False
    else:
        linear=P-2*da*C;full=linear-da*da*D2
        assert full==net and linear>0 and full<0 and positive>0
        assert P/scale==F(560883407,19200000000) and C/scale==F(1051,18000) and D2/scale==F(469,22500)
        assert linear/scale==F(1050221,57600000000) and full/scale==-F(73989779,57600000000)
        assert terms[0]['net_per_target']==-F(38826671,9216000000) and terms[1]['net_per_target']==F(2616041209,230400000000)
        result.update({'quadratic_retained_formula_applied':True,'C':C,'D2':D2,'linear_compensated':linear,'full_quadratic_compensated':full})
    return result


def run():
    paths=[
        path_check('initial','single_face',1,1,'1/2',[('outer','-1/2',1)]),
        path_check('stress','repeat_requires_recovery',1,1,'1/2',[('outer','-1/2',1),('recovery','1/2',1),('outer','-1/2',1)]),
        path_check('stress','closed_left_endpoint',1,1,0,[('outer',-1,1)]),
        path_check('stress','closed_right_endpoint',1,1,1,[('outer',0,1)]),
        path_check('expanded','simultaneous_deletion',1,1,2,[('outer',1,0)]),
        path_check('expanded','scaled_repeat','3/2','7/3','3/4',[('outer','-3/4',1),('recovery','3/4',1),('outer','-3/4',1)]),
        path_check('expanded','pure_soft_no_jump',0,1,0,[]),
    ]
    ag=[aggregate('initial','exit_target'),aggregate('stress','retained_targets'),aggregate('expanded','retained_targets',F(7,3))]
    assert ag[1]['posterior_aggregate']==ag[2]['posterior_aggregate'] and ag[1]['alpha_plus']==ag[2]['alpha_plus']
    return {'schema':'r200_reentry_v1','arithmetic':'stdlib Fraction only',
        'inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'ramp_formula':'Psi_j(l)=clip((l+j)/(2j),0,1), j>0; V=F c Psi_j',
        'path_budget':'sum c 1_lost <= 2[V_start+sum(nonouter positive V increases)-V_end]',
        'path_count':len(paths),'paths':paths,'aggregate_case_count':len(ag),'aggregate_cases':ag,'status':'PASS',
        'limitations':['Finite exact path and common-source scalar algebra, not physical kernels, original coarea/FIRST/history or FULL.',
            'The zero-j case has no face events and never evaluates the ramp quotient.',
            'Lost conditions retain both closed endpoints and count a simultaneous deletion only once.',
            'The complete retained-target quadratic identity is not applied to targets that exit eligibility.',
            'No free choice of endpoint alpha: each uses the same full source arrays and E(p) capture definition.',
            'A positive-part after aggregation differs from summing per-target positive parts; neither operation is silently interchanged.',
            'No phi-half numerics, asymptotic fit, or general original source budget is claimed.']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'reentry_checks.json');args=ap.parse_args()
    r=run();args.output.write_text(json.dumps(encode(r),indent=2,sort_keys=True)+'\n')
    print('PASS: 7 ramp paths and 3 common-source aggregate cases, Fraction exact')
