# R396 — one coordinate-geometry candidate screened; no new payment

**Status.** No new general estimate for BH or G_core was obtained. The exact-reference feasibility and source-capacity slack in R332 are prior results, not advances of this round. All original fees, original high/clock fields, and the R391 coefficient on the unpaid core remain unchanged.

The one new candidate screened was a joint directional-energy estimate for actual cube membership differences under the full source measure. Its intended purpose was to obtain a root-dimensional summation from cube coordinates without assuming that f has independent coordinates. The screening below identifies why ordinary martingale orthogonality does not prove the required estimate.

Let W=∫f>0 and fix the coordinate filtration F_i=σ(z_1,...,z_i) under the probability f(z)dz/W. For each actual pair put h_uv(z)=c_u(z)−c_v(z), and define

\[
 d_i^{uv}=\mathbb E_f[h_{uv}\mid\mathcal F_i]
           -\mathbb E_f[h_{uv}\mid\mathcal F_{i-1}],\quad 1\le i\le n.
\]

No receiver, radius, source, or old mark is changed. The exact weighted orthogonality identity is

\[
 f(Q_u\triangle Q_v)
 =\frac{(m_u-m_v)^2}{W}+\sum_{i=1}^n\int f(z)|d_i^{uv}(z)|^2dz. \tag{1}
\]

This is a standard conditional-expectation identity, not a new payment. In particular it uses full f, including its coordinate correlations.

To state the concrete attempted estimate, retain the original high-source/clock pair weight

\[
 w_r(u,v)=\int\frac{f(y)1_{J_y(r)\ge H}}{J_y(r)}
                  c_u(y)c_v(y)dy,
\]

with zero integrand outside the high set and the actual prefix pair measure μ⊗μ. The exact symmetric-difference representation of BH, followed by (1), gives

\[
 B_H=\mathcal E_0+\sum_{i=1}^n\mathcal E_i,
\quad
 \mathcal E_0=\frac1{2W}\int\ell(dr)\int_{E_r^2}w_r(u,v)(m_u-m_v)^2\,d\mu(u)d\mu(v),
\]
\[
 \mathcal E_i=\frac12\int\ell(dr)\int_{E_r^2}w_r(u,v)
                  \left[\int f|d_i^{uv}|^2\right]d\mu(u)d\mu(v). \tag{2}
\]

All terms are nonnegative. This is the same original square written through its boundary-source expression; none of Q, R_cross or R_clock is retained as a second credit on top of (2).

A genuinely useful intermediate geometric theorem for this candidate would have to give, uniformly over the actual matched field,

\[
 \mathcal E_0\le\tfrac\varepsilon2 X+C_\varepsilon\sqrt n\log^A(n+2)W,
 \qquad
 \left(\sum_{i=1}^n\mathcal E_i^2\right)^{1/2}
 \le\frac\varepsilon{2\sqrt n}X+C_\varepsilon\log^A(n+2)W.       \tag{3}
\]

Cauchy would then bound the actual total (2). Neither inequality in (3) was proved. This is a specific directional-energy hypothesis, not a claimed sufficient-condition achievement. Orthogonality establishes (1) but does not bound the square sum in (3): the energies in (2) are positive numbers integrated with the same non-product J/clock weight. Bounds of size O(W) on every direction separately would yield O(nW), not O(√nW). The nonzero mean term E_0 is an additional necessary cost and cannot be silently discarded on far-mass edges.

Thus this candidate currently does not exploit the actual matched cube geometry strongly enough. There is no new source price, new X absorption, root estimate, or reduction of the actual residual. Work stops rather than presenting the orthogonal decomposition as progress toward a completed budget.

**Actual local check.** A standard-library Python Fraction run verified (1) and pairwise orthogonality in 27 cases, in dimensions 2,3,4. Sources were correlated positive weights on {0,1}^n; coordinate capture patterns were realizable by axis-parallel cubes of common side 6/5, with coordinate centers 0,1/2,1. The cases check weighted conditional-expectation algebra only. They do not realize native receiver du, the synchronized historical/core conditions, or the missing estimates (3). Output: `Exact weighted-coordinate decomposition: 27 cases PASS`. No numerical test of a root bound was performed and no separate script was created.

Only this checkpoint was written; no repository or other agent's files were changed.
