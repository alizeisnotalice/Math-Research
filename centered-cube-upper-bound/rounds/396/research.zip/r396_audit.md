# R396 exact-reference scope audit — FINAL PASS

FINAL PASS for the exact high-source reference inclusion, its complete original bill, the bounded historical correction and the explicitly unpaid coordinate candidate. This is not a new root source estimate or paid original traffic branch. Only this audit file is edited; no author/repository files are changed.

## Independent derivation before author conclusions

For M_uv=(sqrt(m_u)+sqrt(m_v))^2/4 and the actual high-source feature G_H, weighted Cauchy-Schwarz gives

    G_H^2<=I_uv S_G,
    I_uv<=min(m_u,m_v)<=M_uv,
    S_*=G_H^2/M_uv<=S_G.

M_uv>0 on actual receivers because m_u>=q_-a^n>0. G_H is nonnegative, so theta=1 in the R331 reference yields sqrt(S_*)sqrt(M_uv)=G_H exactly. Thus arbitrary-reference fitting cannot be the missing capacity-class feasibility issue. This does not assert that the resulting source/geometric bill is small.

## Historical claim checked against the actual local proofs

Read R332 core §1 equation (1) and its following paragraph, plus the R331 capacity definitions already examined in the preceding round. R332 explicitly constructs S0=4G_all^2/(sqrt(m_u)+sqrt(m_v))^2, proves S0<=S_G, and says theta=1 gives the exact original G_all feature. It explicitly does not count the inclusion as a new budget. R331 defines the general subcapacity class and saturated Gibbs member but does not itself state that exact-reference member. The R396 historical correction is therefore accurate within these specifically read notes; no exhaustive history/novelty claim is certified.

The high-only result is an immediate decreasing-feature variant of that already written all-row inclusion. R395's restricted local/global mixing and amplitude inequalities remain valid, but their error is the artificial Hilbert distance from G_H in a selected family. The full class can have distance zero. The prior PASS for those restricted inequalities is not an assertion that their optimization pays the original whole-slot deficit.

## Full author-proof review: real measures, null sets and budget

Read r396_reference_scope.md in full. Its kernels use the same full f, actual du/m_u, original E_r, original high gate and complete physical ell, including b's atom. Joint measurability follows from nonnegative parameter integrals. For the saturated Gibbs kernel, Tonelli proves the zero-J exceptional source mass vanishes in ell(dr)dmu(u); this is the needed product null set, not only a separate pointwise claim for each receiver. Its pair integral is |E_r|, so S_G is finite pair-a.e. S_*<=S_G is therefore a legitimate symmetric real-prefix subcapacity and all null infinite values can be ignored/defined harmlessly on the required null sets.

The exact R331 norm bill applies to this subcapacity with fixed theta=1. Writing b_*=integral S_*dmu,

    L_*=integral ell integral m_u(m_u-b_*)dmu,
    D_*=(1/4)integral xi S_*(sqrt(m_u)-sqrt(m_v))^2,
    Q_H=X_q-L_*-D_*.

All three terms are nonnegative and finite. Original matching with the inclusive tail gives integral ell integral m_u^2dmu=X_q; no prefix-count fee or scale envelope is introduced. Combining with the already exact high-source identity yields

    BH(f,f)=L_*+D_*-L_low-R_cross-R_clock,
    L_low=X_q-L_H>=0.

For nu<=f, positivity gives BH(f,nu)<=BH(f,f). L_low stays with a NEGATIVE sign and there is no extra lambda H W completion. All original credit terms are used once. The displayed proposed root upper estimate on this bill is precisely the original outstanding target, not a new reduction or partial receipt. No inequality presently bounds that bill at root size.

## Actually executed finite check and evidence limits

Reviewer read and actually executed the unique Python block embedded in r396_reference_scope.md: exit 0, 45 Fraction finite-incidence cases, including 27 genuinely mixed high/low rank cases. It checks S_*<=S_G, row subcapacity, Q_H+L_*+D_*=X and both exact BH identities. Rational-square source ranks make every radical used in the script exact. Its single-prefix finite-incidence weights do not realize general native receiver du or original historical/core conditions; the analytic proof, not these cases, supplies the continuum statement. Reviewer rerun repeats the author's cases and is not a new independent experimental count.

## Coordinate-Doob candidate: bounded review, no payment

Read r396_geometry.md. Under the actual full-source probability f dz/W, h_uv=c_u-c_v is bounded in L2. Its full-coordinate Doob differences are orthogonal and sum to h minus its mean. Thus

    f(Qu symmetric-difference Qv)
       =(m_u-m_v)^2/W+sum_i integral f|d_i|^2.

There is no source-coordinate independence assumption. Conditional expectations may be chosen jointly measurable using the fixed coordinate conditional kernels in the actual Euclidean source space. The original high-source common-capture weight w_r remains in the receiver pair integral. Positive Tonelli gives BH=E0+sum_i Ei with the displayed factor 1/2; it is another exact boundary-source representation of the original square, not an additional negative square available to spend twice.

The two inequalities labeled (3) would be sufficient by Cauchy-Schwarz, but neither is proved. In particular E0 is a real positive cost, and scalar energies after pair/clock integration are not orthogonal vectors giving an automatic root sum. An O(W) estimate per coordinate would still sum to O(nW). The note makes these limitations explicit and claims no new paid branch.

The note's 27 correlated finite-source cases are an AUTHOR execution report; no executable block is supplied there and this reviewer did not independently reproduce their exact cases. Their finite source-coordinate capture patterns are not a native du/history fixture. This record is kept separate from the actually rerun 45 exact-reference cases. The analytic Doob identity is verified directly above, not inferred from those reported cases.

## Literature record and unchanged research boundary

Read r396_literature.md solely as a bounded primary-source scope record. It explicitly distinguishes a conditional general-dimensional kernel principle, a planar square construction and a separate ball construction, and records the missing general cube-majorant construction. No theorem from that note or linked external sources is called in the R396 exact-reference/Doob proof. This auditor did not freshly open/re-verify those external sources, obstacle hypotheses or their numerical kernel constants; these are not independently certified by this audit.

The old actual core coefficient 2 in BH, entrance coefficient 4Lambda, and complete r392 ledger remain unchanged. No new source W fee, X absorption, terminal deletion or geometric root bound is obtained. Any future whole-BH estimate must replace the whole old BH slot, not stack its internal fees or reuse Q_H/R_cross/R_clock. The remaining useful target is the actual jointly determined slack/Dirichlet bill with the original favorable credits retained. Rewriting it, fitting a different reference, or naming a directional sufficient condition does not close it.

## Frozen SHA256 bindings

Historical dependencies are context, not a fresh audit of the entire old reduction. The literature file is bound for scope/provenance only, with the external-verification limitation stated above.

- `/tmp/r396_reference_scope.md`: `9f3c15e5b97edbe4657fd8c87116fb01525b13861159f243f17cf55fa186c550`
- `/tmp/r396_geometry.md`: `ac9914d1eaabcf0c746641d0e6c40a83bb64fb4f145fe7d3c1a53c62a5aec011`
- Earlier literature draft audited for scope only: `3c08d7efb556b9d9e2746bb97f0de2572105d0345165140bbc061f90a6357bbd` (superseded; not archived).
- `/tmp/r332_core.md`: `a4b6ab845f45ca39726a7d1f6d5cf070b105ee92576e8b7767babc32e6304f1e`
- `/tmp/r331_core.md`: `1858c2eb422b64acc9796a53cbbac30efbe6be1fd58a9786f84ced40b9f9c227`
- `/tmp/r329_core.md`: `a0839511190d64279c89a81b819f5cad8d68d774edbffdf5c48726dc62affacc`
- `/tmp/r392_ledger.md`: `4031079b6dcb0660da0460e316c19e4d71ff2dff055ba616aa41a4d376cc79f1`


## Final parent report/readme consistency addendum

Read r396_main.md and r396_readme.md in full. They correctly state that the R332 all-row exact member implies the high-source inclusion by the decreasing-feature argument, preserve the validity of R395's restricted-family optimization, and stop treating reference fitting as the principal missing root payment. The source/geometry interpretation is not inflated into a new estimate. The 45 actually reproduced Fraction cases are separate from the geometry author's unprovided 27-case execution report.

The unchanged old core coefficient 2 in BH and 4Lambda at the entrance, all original time/scale/soft obligations and absence of a new W/X fee are stated correctly. The parent reports no new MATLAB experiment, consistent with the bounded rational-algebra task. There is no model-billing efficiency estimate without data. The scope-check standalone script equals the embedded proof block after stripping surrounding whitespace; its reproduction instruction is accurate.

Additional final-report bindings:

- `/tmp/r396_main.md`: `dd3f71ce61efeed98d99efb8344d2d7eb264c1874ef05a0f121bc66f5725b3f7`
- `/tmp/r396_readme.md`: `9e487d0c62ef2c607023bd4b522965e4ae45b4194c90cb3d76fa073f2a9fa045`
- `/tmp/r396_scope_check.py`: `5504442ce321b2d50c269f166b951f7d67b719c14879699a573ec1e7dfe1b7a3`
- `/tmp/r396_scope_check.result.txt`: `fa131978cad59bc76dcc83d412151816eb309fd8dc620d3c3964312ad722846a`

## Parent integration note (not an independent-auditor assertion)

The source agent subsequently compressed the literature note to 126 words. The parent read the final version and verified its narrower scope and explicit unaudited external hypotheses. The audit agent hit model capacity before rebinding it. No mathematical proof depends on that source note. Final archived literature SHA256: `379c85b99d37d48e6f1151010593a6f8513cce992b5cc804f8c7a499c3c4a0d1`. The independent proof audit and report addendum above remain unchanged.
