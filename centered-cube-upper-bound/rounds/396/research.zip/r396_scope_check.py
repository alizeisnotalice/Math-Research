from fractions import Fraction as F
from itertools import product
count=0; mixed=0
mu=[F(9,25),F(16,25)]
patterns=[(1,0),(0,1),(1,1)]
J=[F(9,25),F(16,25),F(1)]
sqrtJ=[F(3,5),F(4,5),F(1)]
for ru,rv in product((F(1),F(2),F(3)),repeat=2):
 m=[ru*ru,rv*rv]; roots=[ru,rv]
 f=[m[0]-F(1,2),m[1]-F(1,2),F(1,2)]
 for H in (F(1,4),F(1,2),F(3,4),F(1),F(5,4)):
  high=[j>=H for j in J]
  G={}; SG={}; S={}
  for u,v in product(range(2),repeat=2):
   G[u,v]=sum(f[y]*high[y]*patterns[y][u]*patterns[y][v]/sqrtJ[y] for y in range(3))
   SG[u,v]=sum(f[y]*patterns[y][u]*patterns[y][v]/J[y] for y in range(3))
   M=(roots[u]+roots[v])**2/4
   S[u,v]=G[u,v]**2/M
   assert 0<=S[u,v]<=SG[u,v]
  rows=[sum(S[u,v]*mu[v] for v in range(2)) for u in range(2)]
  assert all(rows[u]<=m[u] for u in range(2))
  X=sum(mu[u]*m[u]**2 for u in range(2))
  L=sum(mu[u]*m[u]*(m[u]-rows[u]) for u in range(2))
  D=sum(mu[u]*mu[v]*S[u,v]*(roots[u]-roots[v])**2/4 for u,v in product(range(2),repeat=2))
  Q=sum(mu[u]*mu[v]*G[u,v]**2 for u,v in product(range(2),repeat=2))
  assert Q+L+D==X
  LH=sum(f[y]*high[y]*sum(mu[u]*m[u]*patterns[y][u] for u in range(2)) for y in range(3))
  BH=RC=RK=F(0)
  for y,z in product(range(3),repeat=2):
   A=sum(mu[u]*patterns[y][u]*patterns[z][u] for u in range(2))
   BH+=f[y]*f[z]*high[y]*(A-A*A/J[y])
   RC+=f[y]*f[z]*high[y]*(not high[z])*A*A/J[y]
   RK+=f[y]*f[z]*high[y]*high[z]*A*A*(1/sqrtJ[y]-1/sqrtJ[z])**2/2
  assert BH==LH-Q-RC-RK
  assert BH==L+D-(X-LH)-RC-RK
  count+=1; mixed+=int(any(high) and not all(high))
print('PASS exact finite-incidence cases',count,'mixed high/low',mixed)
