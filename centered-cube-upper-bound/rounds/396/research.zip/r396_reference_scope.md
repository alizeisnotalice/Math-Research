# R396 — the original high-source feature is already inside the capacity class

**Conclusion.** The proposed inclusion is correct, with actual du, every original prefix and the full ell measure. Its all-row version is already explicit in `/tmp/r332_core.md`, §1 equation (1) and the following paragraph; that note also says the inclusion is not a new budget. R331 supplies the class and its saturated Gibbs member but does not state this exact-reference member. R395 states its approximation-error identity but does not point out that the full class already attains zero error. The high-only version below follows immediately by decreasing the all-row feature. This is a scope correction, not a newly paid estimate.

## 1. Exact inclusion, including null sets and the physical atom

Keep the hard-matched field of R329/R331: full f≥0 in L1, actual finite receiver set E, m_u=∫f c_u=q_uR_u^n, q_-≤q_u≤λ, a≤R_u≤b≤2a, μ(du)=du/m_u, E_r={R≤r}, J_y(r)=∫_{E_r}c_u(y)dμ(u), Y_r={J_y(r)≥H}, H>0. Keep ell=b^−nδ_b+nr^−n−1 1_[a,b]dr. No selector, source or clock is changed.

On E_r² define

G_H(r,u,v)=∫f(y)1_Yr(y)c_u(y)c_v(y)/√J_y(r)dy,
I_uv=∫f(y)c_u(y)c_v(y)dy,
S_G(r,u,v)=∫f(y)c_u(y)c_v(y)/J_y(r)dy,
M_uv=(√m_u+√m_v)²/4,
S_*(r,u,v)=G_H(r,u,v)²/M_uv.                                (1)

Zero-J source integrands are zero. The lower bound m_u≥q_-a^n>0 makes M_uv strictly positive on actual receivers. All fields in (1) are jointly measurable by nonnegative parameter integration.

Weighted Cauchy–Schwarz, followed by actual full-f matching, gives

G_H²≤I_uv S_G,
I_uv≤min(m_u,m_v)≤M_uv,
0≤S_*≤S_G.                                                (2)

For almost every actual receiver in the original product measure,

∫_{E_r}S_G(r,u,v)dμ(v)=m_u.                                (3)

To justify the zero-J issue, at each fixed r Tonelli gives
∫_{E_r}dμ(u)∫f(y)c_u(y)1_{J_y(r)=0}dy=∫f1_{J=0}J dy=0.
The same nonnegative argument integrated against ell treats the terminal atom and continuous radii simultaneously. Thus (3) holds ell(dr)dμ(u)-almost everywhere, exactly the measure required by R331. Moreover ∫S_G dμ⊗dμ=|E_r|<∞, so S_G and G_H are finite almost everywhere in the pair measure. No source-density bound is used.

Equations (2)–(3) prove the required row subcapacity

b_*(r,u):=∫_{E_r}S_*(r,u,v)dμ(v)≤m_u.                      (4)

With the permissible prefix-independent θ≡1, the R331 reference is exactly

h_*(r,u,v)=.5√S_*(√m_u+√m_v)=G_H(r,u,v).                   (5)

In particular it is nonnegative, jointly measurable, and in L²(dξ), where dξ=ell(dr)1_{E_r²}dμ(u)dμ(v). Indeed the row-capacity bill gives ||h_*||²≤X_q=∫qdu<∞. Hence no approximation, measurable minimizer, extra transport construction, or prefix-dependent θ is required to represent the original feature.

## 2. The exact next accounting obligation

Define the actual capacity slack and Dirichlet terms of this precise member:

L_*=∫ell(dr)∫_{E_r}m_u[m_u−b_*(r,u)]dμ(u),
D_*=.25∫S_*(r,u,v)(√m_u−√m_v)²dξ.

R331's exact identity, with the original inclusive tail ∫_[R,b]ell=R^−n, gives

Q_H:=||G_H||²=X_q−L_*−D_*.                                (6)

All terms are nonnegative and finite. Let L_H=∫a_H f, L_low=X_q−L_H≥0, and retain R329's nonnegative high-low and unequal-clock credits R_cross,R_clock. Then, for the same full source,

BH(f,f)=L_H−Q_H−R_cross−R_clock
       =L_*+D_*−L_low−R_cross−R_clock.                     (7)

For the actual dominated second source ν≤f, BH(f,ν)≤BH(f,f). Equation (7) adds no λH W completion fee; L_low is retained with its negative sign. The old entrance costs and outer multiplier remain unchanged.

A root theorem therefore still needs a genuinely geometric upper estimate on the right side of (7), for example

L_*+D_*≤εX+C_ε√n log^A(n+2)W
             +L_low+R_cross+R_clock.                      (8)

Equation (8) is recorded only to expose the exact outstanding bill. By (7) it is an equivalent target, not a new reduction or a proved bound. No available capacity inequality bounds this bill at the requested size. The previous negative credits cannot be spent twice, and replacing them or the full-f masses by independent blocks is not justified.

The strategic implication is precise: for any other reference h, the R395 upper bound exceeds BH(f,f) by ||h−G_H||². Since (5) attains zero in the full admissible class, further reference fitting alone removes an artificial error. It cannot settle the original deficit in (7). R395's explicit mixing/amplitude improvements remain mathematically valid within their restricted families, but are not the primary missing geometric payment. The useful next question is an estimate for this actual jointly determined capacity slack and Dirichlet cost, with the original credits retained—not a better approximation algorithm for G_H.

## 3. Actual local arithmetic verification

A standard-library Python Fraction run verified 45 finite-incidence cases, of which 27 have genuinely mixed high/low source ranks:

`PASS exact finite-incidence cases 45 mixed high/low 27`

It checked S_*≤S_G, row subcapacity, Q_H+L_*+D_*=X_q, and both exact expressions in (7). These are algebra diagnostics, not native cube realizations or evidence for (8). The code actually run is reproduced below; the analytic proof supplies real du and all physical-prefix generality.

```python
from fractions import Fraction as F
from itertools import product
count=0; mixed=0
mu=[F(9,25),F(16,25)]
patterns=[(1,0),(0,1),(1,1)]
J=[F(9,25),F(16,25),F(1)]
sqrtJ=[F(3,5),F(4,5),F(1)]
for ru,rv in product((F(1),F(2),F(3)),repeat=2):
 m=[ru*ru,rv*rv]; roots=[ru,rv]
 f=[m[0]-F(1,2),m[1]-F(1,2),F(1,2)]
 for H in (F(1,4),F(1,2),F(3,4),F(1),F(5,4)):
  high=[j>=H for j in J]
  G={}; SG={}; S={}
  for u,v in product(range(2),repeat=2):
   G[u,v]=sum(f[y]*high[y]*patterns[y][u]*patterns[y][v]/sqrtJ[y] for y in range(3))
   SG[u,v]=sum(f[y]*patterns[y][u]*patterns[y][v]/J[y] for y in range(3))
   M=(roots[u]+roots[v])**2/4
   S[u,v]=G[u,v]**2/M
   assert 0<=S[u,v]<=SG[u,v]
  rows=[sum(S[u,v]*mu[v] for v in range(2)) for u in range(2)]
  assert all(rows[u]<=m[u] for u in range(2))
  X=sum(mu[u]*m[u]**2 for u in range(2))
  L=sum(mu[u]*m[u]*(m[u]-rows[u]) for u in range(2))
  D=sum(mu[u]*mu[v]*S[u,v]*(roots[u]-roots[v])**2/4 for u,v in product(range(2),repeat=2))
  Q=sum(mu[u]*mu[v]*G[u,v]**2 for u,v in product(range(2),repeat=2))
  assert Q+L+D==X
  LH=sum(f[y]*high[y]*sum(mu[u]*m[u]*patterns[y][u] for u in range(2)) for y in range(3))
  BH=RC=RK=F(0)
  for y,z in product(range(3),repeat=2):
   A=sum(mu[u]*patterns[y][u]*patterns[z][u] for u in range(2))
   BH+=f[y]*f[z]*high[y]*(A-A*A/J[y])
   RC+=f[y]*f[z]*high[y]*(not high[z])*A*A/J[y]
   RK+=f[y]*f[z]*high[y]*high[z]*A*A*(1/sqrtJ[y]-1/sqrtJ[z])**2/2
  assert BH==LH-Q-RC-RK
  assert BH==L+D-(X-LH)-RC-RK
  count+=1; mixed+=int(any(high) and not all(high))
print('PASS exact finite-incidence cases',count,'mixed high/low',mixed)
```

Only this scope note is written. The general root bound remains unproved; further reference optimization is not pursued here.
