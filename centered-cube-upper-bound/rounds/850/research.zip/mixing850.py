"""Exact posterior envelopes on the existing handoff850 true-box fixtures."""
from collections import defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction as F
from pathlib import Path
from runpy import run_path
import sys

HANDOFF = run_path(str(Path(__file__).with_name("handoff850.py")))


def mixture(rows, matrix):
    powers = HANDOFF["powers"](matrix)
    mu = [row.fraction for row in rows for _ in (0, 1)]  # units mu0
    death = [mu[t] * (1 - sum(row.values())) for t, row in enumerate(matrix)]
    assert all(d > 0 for d in death)
    source = [sum(mu[z] for z in range(1 - k, len(mu), 2)) for k in (0, 1)]
    assert source == [F(59), F(59)]  # A and B are the two actual private packets.
    target = [death[t] / 2 ** rows[t // 2].bin for t in range(len(mu))]
    pi = [[F(0)] * len(mu) for _ in source]
    for e, mass in enumerate(mu):
        private = 1 - e % 2
        for level in powers[2:]:
            for t, prob in level[e].items():
                pi[private][t] += mass * prob * death[t] / mu[t]
    assert sum(map(sum, pi)) == sum(a * sum(row.values()) for a, row in zip(mu, powers[2]))
    partitions = [(row.bin, phase) for row in rows for phase in (0, 1)]
    f = [[p / (source[z] * target[t]) for t, p in enumerate(row)] for z, row in enumerate(pi)]
    assert sum(p for row in pi for p in row) == weighted_sum(f, source, target)
    return pi, source, target, partitions, f


def weighted_sum(f, source, target):
    return sum(value * source[z] * target[t] for z, row in enumerate(f)
               for t, value in enumerate(row))


def source_average(f, source):
    mass = sum(source)
    shared = [sum(a * row[t] for a, row in zip(source, f)) / mass
              for t in range(len(f[0]))]
    return [shared.copy() for _ in f]


def terminal_averages(f, target, bins):
    bin_mass = defaultdict(F)
    for t, b in enumerate(bins):
        bin_mass[b] += target[t]
    all_mass = sum(target)
    separated, combined = [], []
    for row in f:
        weighted = defaultdict(F)
        for t, b in enumerate(bins):
            weighted[b] += target[t] * row[t]
        separated.append([weighted[b] / bin_mass[b] for b in bins])
        combined.append([sum(weighted.values()) / all_mass] * len(row))
    return separated, combined


def envelope(*matrices):
    return [[max(values) for values in zip(*rows)] for rows in zip(*matrices)]


def raised_counts(first, second, pi):
    raised = [p > 0 for r1, r2, rp in zip(first, second, pi)
              for a, b, p in zip(r1, r2, rp) if b > a]
    return sum(raised), len(raised) - sum(raised)


def decimal(q):
    with localcontext() as ctx:
        ctx.prec = 15
        return f"{Decimal(q.numerator) / Decimal(q.denominator):.8E}"


def print_gate(name, tau, pi, source, target, models):
    full = sum(map(sum, pi))
    print(f"  strict gate {name}; scaled tau={decimal(tau)}")
    for label, matrix in models:
        pay = F(0)
        size = F(0)
        cells = live_cells = 0
        for z, row in enumerate(matrix):
            for t, value in enumerate(row):
                if value > tau:
                    cells += 1
                    live_cells += pi[z][t] > 0
                    pay += pi[z][t]
                    size += source[z] * target[t]
        assert 0 <= pay <= full
        print(f"    {label:16s} Π/μ0={str(pay):22s} share={decimal(pay / full)} "
              f"νθ-size/μ0²={decimal(size)} cells={cells}/{live_cells}")


def compute(rows, n, h):
    p, _, _, _ = HANDOFF["kernels"](rows, n, h)
    pi, source, target, bins, f = mixture(rows, p)
    source_coarse = source_average(f, source)
    terminal_bin, terminal_all = terminal_averages(f, target, bins)
    integral = weighted_sum(f, source, target)
    assert all(weighted_sum(x, source, target) == integral
               for x in (source_coarse, terminal_bin, terminal_all))
    mz = envelope(f, source_coarse)
    mt = envelope(f, terminal_bin, terminal_all)
    cumulative_bins, cumulative_all = terminal_averages(mz, target, bins)
    assert weighted_sum(mz, source, target) == weighted_sum(cumulative_bins, source, target)
    assert weighted_sum(mz, source, target) == weighted_sum(cumulative_all, source, target)
    mt_mz = envelope(mz, cumulative_bins, cumulative_all)
    choices = (("raw", f), ("source", mz), ("terminal", mt), ("source→terminal", mt_mz))
    print(f"n={n}, H/t={h}; Π/μ0={sum(map(sum, pi))}; ν(A)=ν(B)=59 μ0; θ/μ0={decimal(sum(target))}")
    print("  raised (positive Π, zero Π) cells: source/raw, terminal/raw, sequential/source, bin-only:",
          raised_counts(f, mz, pi), raised_counts(f, mt, pi),
          raised_counts(mz, mt_mz, pi), raised_counts(f, envelope(f, terminal_bin), pi))
    max_f = max(map(max, f))
    print_gate("half of raw maximum", max_f / 2, pi, source, target, choices)
    source_slot = HANDOFF["normal_state"](rows, 31)
    z = next(z for z in (0, 1) if pi[z][source_slot] > 0 and mz[z][source_slot] > f[z][source_slot])
    print(f"  source witness slot 31, private {'AB'[z]}: exact cell Π/μ0={pi[z][source_slot]}")
    source_threshold = (f[z][source_slot] + mz[z][source_slot]) / 2
    print_gate("source probe", source_threshold, pi, source, target, choices)
    shifted = 2 * next(i for i, row in enumerate(rows) if row.slot == 22 and row.x > 0)
    z = next(z for z in (0, 1) if mt[z][shifted] > f[z][shifted])
    assert pi[z][shifted] == 0
    print(f"  terminal witness shifted slot 22, private {'AB'[z]}: original cell Π is zero.")
    terminal_threshold = mt[z][shifted] / 2
    print_gate("terminal probe", terminal_threshold, pi, source, target, choices)


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "Fraction exact; displayed decimals rounded.")
    print("Π uses true terminal D and all depths >=2 of the existing reduced-rank Ptest.")
    print("Compare against ν×θ, with ν=μ private marginal, θ=D/2^bin, λ=1.")
    print("Densities and thresholds are scaled by μ0. Source pools A,B; terminal core+tag→bin+tag→all.")
    print("Cells reports total selected rectangles / selected rectangles with positive Π.")
    rows64, _, _ = HANDOFF["real_fixture"](64)
    compute(rows64, 64, 7)
    compute(rows64, 64, 8)
