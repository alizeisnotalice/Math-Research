"""R850: old-witness cell mass caps and exact cubical lattice envelope replay."""

from fractions import Fraction as F
from itertools import combinations, product
from math import ceil, comb, floor, isqrt, prod
import sys

from flint import arb, ctx, __version__ as flint_version


def tent(distance, delta):
    return max(F(0), 1-max(F(0),abs(distance)-delta/2))


def lifts(phase, delta):
    reach = 1+delta/2
    low = floor(phase-reach)
    high = ceil(phase+reach)
    return {q: weight for q in range(low,high+1)
            if (weight := tent(phase-q,delta)) > 0}


def phase_checks():
    deltas = (F(0), F(1,128), F(1,64), F(1,32), F(2,3), F(7,3))
    count = 0
    for delta in deltas:
        phases = (F(0),delta/4,delta/2,F(1,4),F(1,2),F(15,16),F(-7,5))
        for phase in phases:
            assert sum(lifts(phase,delta).values()) == 1+delta
            count += 1
    print("Exact one-axis lattice checks:",count,"closed-cell suprema sum to 1+delta.")
    demo = F(1,64)
    assert lifts(F(0),demo) == {-1:demo/2, 0:F(1), 1:demo/2}
    assert lifts(F(1,2),demo) == {0:(1+demo)/2, 1:(1+demo)/2}
    print("  Delta=1/64: zero phase weights 1/128,1,1/128; half phase 65/128,65/128.")
    print("  Omitting the two noncentral zero-phase cells gives 1 < 65/64.")


def max_distance(a,b):
    return max(abs(x-y) for x,y in zip(a,b,strict=True))


def lattice_distance(a,b,period):
    return max(min((x-y)%period,(y-x)%period) for x,y in zip(a,b,strict=True))


def physical_example():
    n = 4
    lam, density, L = F(1), F(3,2), F(2)
    g = 2
    k = n
    D = L**n
    delta = F(g,32*n)
    unit = delta*L
    eps = F(1,1024)
    old_side = F(4,3)
    old_halo = old_side+2*unit
    assert old_side**2 < 2
    assert old_halo**2 < 2
    assert 2**(k-g-1) < old_side**n <= 2**(k-g)
    assert 1 <= old_side < old_halo < L <= 2
    zero = (F(0),)*n
    marks = (
        tuple((a,b,F(0),F(0)) for a,b in product((F(-1),F(1)),repeat=2)),
        tuple((a,b,F(0),F(0)) for a,b in product((F(-3,2),F(1,2)),repeat=2)),
    )
    refs = (marks[0][-1], marks[1][-1])
    all_marks = marks[0]+marks[1]
    assert all(max_distance(s,t)>2*eps for s,t in combinations((zero,)+all_marks,2))

    root = {z:tuple(v/2 for v in z) for z in all_marks}
    old = {z:(z[0],z[1],F(-1,8),F(0)) for z in all_marks}
    ref_cores = tuple((p[0]/2,p[1]/2,F(1,8),F(0)) for p in refs)
    all_cores = tuple(root.values())+tuple(old.values())+ref_cores
    assert all(max_distance(x,y)>2*eps for x,y in combinations(all_cores,2))

    for z in all_marks:
        x = root[z]
        assert max(max_distance(x,zero),max_distance(x,z))+2*eps<L/2
        assert max_distance(old[z],z)+2*eps<old_side/2
        # For every actual reference p in its packet, the corresponding
        # eligible cell's center is within eps of z's nominal center.
        assert max_distance(old[z],z)+2*eps+unit/2<old_halo/2
        assert max(map(abs,z))+eps+unit/2 < 4
    for p,x in zip(refs,ref_cores):
        assert max(max_distance(x,zero),max_distance(x,p))+2*eps<old_side/2
    assert all(max(map(abs,x))+eps+L/2<4 for x in all_cores)
    assert lam < density < 2*lam
    # sigma=eta is the full 3/2 density on [-4,4]^4. All original chosen
    # witness cubes and enlarged old cubes stay in that support.
    actual_cell_mass = density*unit**n
    geometric_hat = 2*lam*old_halo**n
    common_hat = 2*lam*D*F(1,2)
    assert actual_cell_mass < geometric_hat < common_hat

    classes = []
    for p in refs:
        classified = []
        for z in all_marks:
            d0 = lattice_distance(p,z,L)
            if d0 == 0:
                assert d0+2*eps<unit/2
                classified.append(z)
            else:
                assert d0-2*eps>unit/2
        classes.append(tuple(classified))
    assert tuple(classes)==marks
    print("4D actual boxes: L=2, cap bin k=4, old side 4/3, old bin 2, delta=1/64.")
    print("  Eight root and ten old disjoint positive receiver cores; sigma=eta=3/2 on [-4,4]^4.")
    print("  Enlarged old side",old_halo,"; cell true mass",actual_cell_mass,
          "< old scale cap",geometric_hat,"< common cap",common_hat)
    print("  2 phases, each with 4 external physical copies, uniformly valid on each source packet.")

    for p,selected in zip(refs,marks):
        box_weights = tuple(prod(tent((w-q)/L,delta) for w,q in zip(zero,z))
                            for z in selected)
        assert sum(box_weights)==(1+delta)**2<(1+delta)**n
        print("  Reference nominal first two coords",p[:2],
              "; four actual-class directional sup weights",tuple(map(str,box_weights)),
              "; sum",sum(box_weights),"; full lattice sum",(1+delta)**n)

    # Actual R subflow uses g=1 on W x Z_j in each root core, W x P_i
    # in the two reference old cores, and Z_j x Z_j in each recorded
    # eligible old core, g=0 elsewhere. The two real reference choices
    # have equal old conditional mass for every w in the packet W.
    packet_mass = density*(2*eps)**n
    core_volume = (2*eps)**n
    root_mass = core_volume*packet_mass**2/L**(2*n)
    per_reference_old = core_volume*packet_mass**2/old_side**(2*n)
    assert 0 < root_mass < per_reference_old
    all_root_mass = len(all_marks)*root_mass
    blind_mass = sum(len(c)*root_mass/len(refs) for c in classes)
    read_mass = sum(len(c)*root_mass for c in classes)
    assert blind_mass/all_root_mass==F(1,2) and read_mass==all_root_mass
    blind_joint = ((F(1,4),F(1,4)),(F(1,4),F(1,4)))
    read_joint = ((F(1,2),F(0)),(F(0),F(1,2)))
    assert list(map(sum,blind_joint)) == list(map(sum,read_joint))
    assert list(map(sum,zip(*blind_joint))) == list(map(sum,zip(*read_joint)))
    assert sum(blind_joint[i][i] for i in range(2))==blind_mass/all_root_mass
    assert sum(read_joint[i][i] for i in range(2))==read_mass/all_root_mass
    assert all_root_mass==F(9,2**115)
    print("  Original marked root mass 9*2^(-115); accepted mass blind 9*2^(-116), adaptive 9*2^(-115).")
    print("  Joint table entries: blind all 1/4; adaptive diagonal 1/2, off-diagonal 0.")
    print("  Same reference and private phase marginals; blind hit 1/2, adaptive hit 1.")


def old_cap_checks():
    ctx.prec = 192
    two = arb(2)
    log_two = two.log()
    print("192-bit Arb margins: -log2(halo volume / claimed old-volume cap) and",
          "-log2[2^(-g/2)(1+delta)^n] at the smallest tested g.")
    count = 0
    for n in (2,4,16,64,256,1024,4096):
        min_g = isqrt(n-1)+1
        for g in sorted({min_g,(n+1)//2,n}):
            if not min_g <= g <= n:
                continue
            u = arb(g)/n
            old_ratio = (-u*log_two).exp()
            halo = old_ratio + u/16
            cap = (-u*log_two/2).exp()
            assert halo < cap < 1
            volume_margin = -n*(halo/cap).log()/log_two
            lattice_cost_log2 = -g/arb(2)+n*(1+u/32).log()/log_two
            assert volume_margin > 0 and lattice_cost_log2 < -arb(7)*g/16
            count += 1
            if g==min_g:
                print("  n",n,"g",g,":",volume_margin.str(8),(-lattice_cost_log2).str(8))
    print("  Distinct (n,g) checked:",count,"; all old-halo and combined bounds strictly certified.")


def secondary_lifts():
    # This counts noncentral physical cells only at an aligned phase.
    # It is a diagnostic and is intentionally not a phase-uniform saving.
    n, g = 32, 6
    delta = F(g,32*n)
    r = 2
    aligned = [comb(n,j)*delta**j for j in range(n+1)]
    half = [F(comb(n,j),2**n)*(1+delta)**n for j in range(n+1)]
    assert sum(aligned)==sum(half)==(1+delta)**n
    aligned_tail = sum(aligned[r:])/sum(aligned)
    half_tail = sum(half[r:])/sum(half)
    assert aligned_tail < F(1,50) and half_tail > F(999,1000)
    print("32D normalized envelope weight of at least two nonprimary physical lifts:",
          f"aligned {float(aligned_tail):.9g}, half-phase {float(half_tail):.9g}.")


if __name__ == "__main__":
    print("Python",sys.version.split()[0],"| python-flint",flint_version,"| Fraction plus Arb")
    phase_checks()
    physical_example()
    old_cap_checks()
    secondary_lifts()
    print("All exact and Arb assertions passed; finite geometric checks, no high-load conclusion.")
