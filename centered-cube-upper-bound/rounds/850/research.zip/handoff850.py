"""Exact two-endpoint handoff, joint middle, and terminal accounting."""
from collections import defaultdict, namedtuple
from fractions import Fraction as F
from itertools import combinations
from math import isqrt
import sys

CORE = F(1, 4096)
PACKET = F(1, 128)
SIGMA = F(3, 2)
T64 = F(2) ** -1220
PACKET64 = SIGMA * (2 * PACKET) ** 64
CORE64 = (2 * CORE) ** 64
GATE = F(15, 16)
Core = namedtuple("Core", "slot bin side x y fraction g volume")


def bin_side(k):
    lo, hi = 2 ** 16, 2 ** 17
    limit = 2 ** (k + 16 * 64)
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if mid ** 64 <= limit:
            lo = mid
        else:
            hi = mid
    side = F(lo, 2 ** 16)
    assert F(2) ** (k - 1) < side ** 64 <= 2 ** k
    return side


def ceil_log2(x):
    j = max(0, x.numerator.bit_length() - x.denominator.bit_length())
    while 2 ** j < x:
        j += 1
    assert F(2) ** (j - 1) < x <= 2 ** j
    return j


def real_fixture(n):
    packet_mass = SIGMA * (2 * PACKET) ** n
    t = T64 * (4 * CORE * PACKET) ** (n - 64)
    rows = []
    for k in range(59):
        s = bin_side(k)
        j = ceil_log2(s ** n)
        y = F(k - 29, 512)
        main = {49: F(1, 3), 22: F(3, 4)}.get(k, F(1))
        parts = [(F(0), main)]
        if main < 1:
            parts.append((F(3, 8), 1 - main))
        for x, fraction in parts:
            g = T64 * fraction * s ** 128 / (CORE64 * PACKET64)
            rec = (2 * CORE) ** n * s ** (2 * (n - 64))
            assert 0 < g <= 1 and 1 <= s <= 2
            assert max(abs(x), abs(y), CORE * s ** 2) + CORE + 1 < 4
            for a in (F(-1, 16), F(1, 16)):
                assert max(abs(x - a) + CORE, abs(y) + CORE,
                           CORE * s ** 2) + PACKET < s / 2
            row = Core(k, j, s, x, y, fraction, g, rec)
            assert row.volume * g * packet_mass ** 2 / s ** (2 * n) == t * packet_mass * fraction
            rows.append(row)
    assert all(max(abs(x.x - y.x), abs(x.y - y.y)) > 2 * CORE
               for x, y in combinations(rows, 2))
    assert len({x.bin for x in rows}) == 59
    return rows, t, packet_mass


def comparison(new, old, n):
    slack = (new.side - old.side) / 2
    displacement = max(abs(new.x - old.x), abs(new.y - old.y)) + 2 * CORE
    if n > 64:
        displacement = max(displacement, CORE * (new.side ** 2 + old.side ** 2))
    if displacement <= slack:
        return True, F(1)
    upper_first = max(F(0), (new.side + old.side) / 2 - abs(new.x - old.x) + 2 * CORE)
    upper_relative = min(F(1), upper_first / old.side)
    assert upper_relative < GATE
    return False, upper_relative


def kernels(rows, n, h_over_t):
    b = 1 + isqrt(n - 1)
    h, d = F(h_over_t), F(h_over_t, 2)
    # Common u is sampled in [slot,slot+1) in units of t. For m=2 there
    # is one old slot, with J_1=[H,H+d]. Whole-bin means every pair u,v.
    p = [{} for _ in range(2 * len(rows))]
    bare = [{} for _ in p]
    worst_reject = F(0)
    for i, x in enumerate(rows):
        for j, y in enumerate(rows):
            if x.slot < 2 * h or x.bin - y.bin <= b:
                continue
            gap = x.slot - y.slot
            if not h <= gap - 1 <= gap + 1 <= h + d:
                continue
            passed, overlap_bound = comparison(x, y, n)
            if not passed:
                worst_reject = max(worst_reject, overlap_bound)
            for phase in (0, 1):
                e, f = 2 * i + phase, 2 * j + 1 - phase
                bare[e][f] = y.fraction / d
                if passed:
                    p[e][f] = bare[e][f]
    return p, bare, d, worst_reject


def advance(dist, matrix):
    result = defaultdict(F)
    for e, mass in dist.items():
        for f, value in matrix[e].items():
            result[f] += mass * value
    return dict(result)


def powers(matrix):
    levels = [[{e: F(1)} for e in range(len(matrix))]]
    while any(levels[-1]):
        nxt = [advance(row, matrix) for row in levels[-1]]
        if not any(nxt):
            break
        levels.append(nxt)
    return levels


def normal_state(rows, slot, phase=0):
    return 2 * next(i for i, row in enumerate(rows) if row.slot == slot and row.x == 0) + phase


def verify(n, rows, t, packet, p, bare, d_over_t):
    mu = [r.fraction for r in rows for _ in (0, 1)]  # units mu0=t*packet/2
    # Between a fixed point of a source pack and a fixed point of the other,
    # h for a single real core is independent of the points. Sum cores only once.
    h_all = [row.volume * row.g / row.side ** (2 * n) for row in rows]
    assert all(h == t * row.fraction / packet for h, row in zip(h_all, rows))
    h_bin = defaultdict(F)
    for row, h in zip(rows, h_all):
        h_bin[row.bin] += h
    d = d_over_t * t
    mu0 = t * packet / 2
    pstar = [{} for _ in p]
    for e, row in enumerate(p):
        for f, prob in row.items():
            pstar[f][e] = mu[e] * prob / mu[f]
    assert all(sum(row.values()) <= 1 for row in (*p, *pstar))
    l, ls = powers(p), powers(pstar)
    assert len(l) == len(ls) and len(l) > 3
    checked = 0
    maxima = []
    for r, level in enumerate(l[2:], 2):
        assert sum(map(len, level)) == sum(map(len, ls[r]))
        maximum = F(0)
        for e, vec in enumerate(level):
            for f, value in vec.items():
                q = value / mu[f]
                assert q == ls[r][f][e] / mu[e]
                assert (e - f) % 2 == r % 2
                maximum = max(maximum, q)
                if r == 2:
                    eligible_j = {rows[m // 2].bin for m in bare[e] if f in bare[m]}
                    exact = sum(h_all[m // 2] for m in p[e] if f in p[m])
                    cap = sum(h_bin[j] for j in eligible_j)
                    assert q == mu0 * 2 * exact / d ** 2 <= mu0 * 2 * cap / d ** 2
                    checked += 1
        maxima.append(maximum)
    kill = [1 - sum(row.values(), F(0)) for row in p]
    death = {e: a * k for e, (a, k) in enumerate(zip(mu, kill)) if k}
    reverse = death
    recovered = defaultdict(F)
    depth_mass = []
    for level in l:
        by_forward = sum(mu[e] * sum(prob * kill[f] for f, prob in vec.items())
                         for e, vec in enumerate(level))
        assert by_forward == sum(reverse.values())
        depth_mass.append(by_forward / sum(mu))
        for e, mass in reverse.items():
            recovered[e] += mass
        reverse = advance(reverse, pstar)
    assert not reverse and all(recovered[e] == a for e, a in enumerate(mu))
    # Two independent branches, each terminal at depth >=2, using actual D.
    branch_mass = F(0)
    endpoints = defaultdict(F)
    for e in range(len(mu)):
        terminal = defaultdict(F)
        for level in l[2:]:
            for f, prob in level[e].items():
                terminal[f] += prob * kill[f]
        assert sum(terminal.values()) == sum(l[2][e].values())
        branch_mass += mu[e] * sum(terminal.values()) ** 2
        for f, first in terminal.items():
            for g, second in terminal.items():
                endpoints[f, g] += mu[e] * first * second
    assert sum(endpoints.values()) == branch_mass
    f, g = normal_state(rows, 40), normal_state(rows, 31, 1)
    endpoint_density = endpoints[f, g] / (death[f] * death[g])
    assert endpoint_density == sum(
        sum(level[f].get(e, 0) for level in ls[2:])
        * sum(level[g].get(e, 0) for level in ls[2:]) / mu[e]
        for e in range(len(mu))) > 0
    root = normal_state(rows, 58)
    q3 = l[3][root][g] / mu[g]
    return l, maxima, checked, depth_mass, branch_mass / sum(mu), endpoint_density, q3


def run(n, h_over_t, label):
    rows, t, packet = real_fixture(n)
    p, bare, d, reject = kernels(rows, n, h_over_t)
    l, maxima, checked, depth_mass, branch, endpoint, q3 = verify(n, rows, t, packet, p, bare, d)
    e, f = normal_state(rows, 58), normal_state(rows, 40 if h_over_t == 7 else 38)
    viable_mid = [rows[mid // 2] for mid in bare[e] if f in bare[mid]]
    centers = [(m.slot, m.bin, m.x, m.fraction) for m in viable_mid]
    z = sum(row.fraction for row in viable_mid)
    actual = l[2][e][f] / rows[f // 2].fraction
    cap = F(len({row.bin for row in viable_mid}), 1) / d ** 2
    if h_over_t == 7:
        assert actual == F(4, 147) and z == 1
    else:
        assert actual == F(7, 48) and z == 3
    print(f"{label}: n={n}, H/t={h_over_t}, d/t={d}, 59 bins and 61 actual cores.")
    print("  rejections: actual intersection/smaller volume <=", reject,
          "; two-step positive tagged pairs checked", checked)
    print("  selected root and target original slots", rows[e // 2].slot, rows[f // 2].slot,
          "rank-qualified intermediary (original slot,true bin,x,weight):", centers)
    print("  (t*packet/2) q_2 and rank-qualified cap:", actual, cap,
          "; max scaled q_r, r>=2:", maxima)
    print("  D(P*)^r / |mu|, depths 0..L:", depth_mass)
    print("  two independent terminal branches, both depths >=2, mass/|mu|:", branch)
    print("  scaled q_3 (58,phase0)->(31,phase1), scaled DxD density at (40,phase0),(31,phase1):",
          q3, endpoint)
    print("  mu0=t*packet/2 = 3 * 2^(-%d)" % (1220 + 17 * (n - 64) + 6 * n + 2))


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "Fraction exact; two positive real source packs.")
    print("First step retains one original continuous point; two steps give a density against mu.")
    print("Same-source whole-bin rule, u>=2H, common J1, alternating tags; m=2.")
    print("Scaled H and a geometric test gate 15/16; high-load and general asymptotic gates untested.")
    run(64, 7, "INITIAL")
    run(64, 8, "MULTIPLE-MIDDLE STRESS")
    run(256, 8, "DIMENSION EXPANSION, unchanged pointwise g")
