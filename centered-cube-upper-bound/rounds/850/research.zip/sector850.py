"""Real terminal/source charges and receiver volumes from Round 850."""
from fractions import Fraction
from math import comb, factorial, isqrt
from pathlib import Path
from runpy import run_path
import sys

from flint import arb, ctx, __version__ as flint_version

fixture = run_path(str(Path(__file__).with_name("handoff850.py")))
F = Fraction


def ball(q):
    return arb(q.numerator) / q.denominator


def terminal_source(n, h):
    rows, rank_unit, packet = fixture["real_fixture"](n)
    kernel, _, _, _ = fixture["kernels"](rows, n, h)
    root = [row.fraction for row in rows for _ in range(2)]
    kill = [1 - sum(line.values()) for line in kernel]
    weight = [root[i] * kill[i] for i in range(len(root))]
    root_unit = rank_unit * packet / 2
    powers = fixture["powers"](kernel)
    depth_count = len(powers) - 1
    b = isqrt(n - 1) + 1
    graded = [[F(), F()] for _ in root]
    projected_mass = F()
    count = 0
    for r in range(1, len(powers)):
        for e, line in enumerate(powers[r]):
            private = 1 - e % 2
            for t, prob in line.items():
                v = rows[t // 2].side ** n
                assert v * 2 ** (b * r) <= 2 ** rows[e // 2].bin
                reverse = root[e] * prob / root[t]
                graded[t][private] += 2 ** (b * r) * reverse
                projected_mass += weight[t] * reverse
                count += 1
    # These are true continuous packet projections. The true root private
    # coordinate is uniform within its packet, including at depth one.
    mass_once = sum(root[e] * sum(line.values()) for e, line in enumerate(kernel))
    assert projected_mass == mass_once
    charged = sum(
        root_unit * weight[t] * rows[t // 2].side ** n * max(block) / packet
        for t, block in enumerate(graded)
    )
    # eta is the cut to the two packets of the ambient constant source.
    fraction_of_budget = charged / (4 * (n + 2) * 2 * packet)
    assert 0 < fraction_of_budget < 1
    log_ratio = ball(fraction_of_budget).log() / arb(2).log()
    selected = fixture["normal_state"](rows, 31, 1)
    print(f"n={n}, H/t={h}, depth={depth_count}, positive terms={count},",
          f"all positive-depth roots in units mu0={projected_mass};")
    print("  weighted reverse occupations of the two real private packets",
          "at slot 31/tag 1:", *(str(v) for v in graded[selected]))
    print("  log2 of integrated true cap / (4(n+2)S):", log_ratio.str(10))


def terminal_pair_tents(n, h):
    rows, t, packet = fixture["real_fixture"](n)
    kernel, _, _, _ = fixture["kernels"](rows, n, h)
    unit = t * packet / 2
    half_packet_side = fixture["PACKET"]
    # True opposite packs: center separation 1/8 on one axis, 0 on others.
    # This lower bound for p_L holds for every actual ordered source pair,
    # for all L>=1. It tests the pointwise upper comparison strictly.
    minimum_tent = (1 - F(1, 8) - 2 * half_packet_side) * (1 - 2 * half_packet_side) ** (n - 1)
    by_bin = {}
    for s, transitions in enumerate(kernel):
        row = rows[s // 2]
        key = row.bin, s % 2
        weight = unit * row.fraction * (1 - sum(transitions.values())) / 2 ** row.bin
        by_bin[key] = by_bin.get(key, F()) + weight
    marginal = F()
    joint = F()
    for (j, role), weight in by_bin.items():
        assert role in (0, 1)
        m_fraction = weight * 2 ** j / (4 * packet)
        j_fraction = weight * 2 ** (2*j) / (4 * packet ** 2 * minimum_tent)
        assert 0 < m_fraction <= 1 and 0 < j_fraction <= 1
        marginal = max(marginal, m_fraction)
        joint = max(joint, j_fraction)
    print(f"terminal roles n={n}, H/t={h}, {len(by_bin)} true bin/role cells;",
          "maximum log2 comparison shares, single and joint:",
          (ball(marginal).log()/arb(2).log()).str(9),
          (ball(joint).log()/arb(2).log()).str(9))


def receiver_volumes():
    log2 = arb(2).log()
    for n in (64, 256, 1024, 4096, 16384, 65536):
        b = isqrt(n - 1) + 1
        depth = n // (b + 1)
        for r in sorted({2, min(4, depth), depth}):
            h = b * (r - 1)
            delta = h * log2 / (8 * n)
            exact_floor = (h * log2 / (8 * arb(100 * (n + 2) ** 3).log())).floor().unique_fmpz()
            assert exact_floor is not None
            exceptions = int(exact_floor)
            # Worst allowed bin L_j=1. The integer factor uses the full
            # non-asymptotic union over sets of exceptional coordinates.
            multiplicity = sum(comb(n, i) * (4 * r) ** i for i in range(exceptions + 1))
            log_volume = n * (1 + delta).log() / log2 + arb(multiplicity).log() / log2
            assert log_volume < arb(h) / 4
            if r == depth:
                print(f"n={n}, T={depth}, exceptional axes={exceptions},",
                      "log2(volume cap / 2^(b(T-1))):", (log_volume - h).str(9))


def passive_cube():
    # Convolution of 2r-1 exact one-dimensional uniform increments.
    def cdf(m, x):
        return sum((-1) ** j * comb(m, j) * (x - j) ** m
                   for j in range(x.numerator // x.denominator + 1)) / factorial(m)
    values = []
    for r in (2, 4, 16, 64):
        m = 2 * r - 1
        centered_unit = cdf(m, F(m + 1, 2)) - cdf(m, F(m - 1, 2))
        assert 0 < centered_unit < 1
        values.append(centered_unit)
        print(f"r={r}, unit-interval probability for the passive comparison:",
              ball(centered_unit).str(10))
    assert values[0] == F(2, 3) and values == sorted(values, reverse=True)


if __name__ == "__main__":
    ctx.prec = 192
    print(f"Python {sys.version.split()[0]} | python-flint {flint_version} | 192-bit Arb")
    print("Real packets of the reduced-rank true-box fixture; true private, not retained, endpoint.")
    for n, h in ((64, 7), (64, 8), (256, 8)):
        terminal_source(n, h)
        terminal_pair_tents(n, h)
    receiver_volumes()
    passive_cube()
    print("Exact rational assertions and Arb enclosures passed.")
