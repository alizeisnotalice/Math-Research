import numpy as np
from pathlib import Path
import json,sys,platform,time
# Positive piecewise-constant L1 source, full bounding domain midpoint quadrature.
# All source box and intersection integrals are analytic; center integrals are NOT certified.
boxes=[(0.10,[-1,-1],[1,1]),(15.,[-.08,-.08],[.08,.08]),(4.,[.42,-.08],[.58,.08])]
lam=1.; n=2
lo=np.array([x[1] for x in boxes]);hi=np.array([x[2] for x in boxes]);dens=np.array([x[0] for x in boxes])
W=np.sum(dens*np.prod(hi-lo,axis=1));b=(W/lam)**(1/n);a=b*1e-7

def mass(B,r):return np.sum(dens*np.prod(np.maximum(0,np.minimum(hi,B+r/2)-np.maximum(lo,B-r/2)),axis=1))
def outer(B):
 cuts=np.unique(np.clip(np.r_[a,b,2*np.abs(lo-B).ravel(),2*np.abs(hi-B).ravel()],a,b));roots=[]
 for left,right in zip(cuts[:-1],cuts[1:]):
  mid=(left+right)/2;coef=np.zeros(n+1)
  for k in range(len(dens)):
   p=np.array([1.])
   for j in range(n):
    upper=(hi[k,j],0.) if hi[k,j]<B[j]+mid/2 else (B[j],.5)
    lower=(lo[k,j],0.) if lo[k,j]>B[j]-mid/2 else (B[j],-.5)
    if upper[0]+upper[1]*mid <=lower[0]+lower[1]*mid:p=np.array([0.]);break
    p=np.polynomial.polynomial.polymul(p,[upper[0]-lower[0],upper[1]-lower[1]])
   coef[:len(p)]+=dens[k]*p
  coef[n]-=lam
  if np.max(np.abs(coef))<1e-12:roots.append(right);continue
  for z in np.polynomial.polynomial.polyroots(coef):
   if abs(z.imag)<1e-9 and left-1e-10<=z.real<=right+1e-10 and z.real>=a:
    if abs(mass(B,z.real)/z.real**n-lam)<1e-7:roots.append(float(z.real))
 return max(roots) if roots else None

def run(k,theta):
 lower=lo.min(axis=0)-b/2;upper=hi.max(axis=0)+b/2;step=(upper-lower)/k;weight=float(np.prod(step))
 centers=[];rs=[]
 for i in range(k):
  for j in range(k):
   B=lower+(np.array([i,j])+.5)*step;r=outer(B)
   if r is not None:centers.append(B);rs.append(r)
 C=np.array(centers);r=np.array(rs);v=r**n;N=len(r);L=n+1
 lowerC=C-r[:,None]/2;upperC=C+r[:,None]/2
 sums={key:0. for key in ['A','M','near_A','near_M','far_A','far_M','positive_Gamma','negative_Gamma','nested_A','nested_M','core_A','core_M']}
 for start in range(0,N,128):
  end=min(N,start+128);il=np.maximum(lowerC[start:end,None,:],lowerC[None,:,:]);ih=np.minimum(upperC[start:end,None,:],upperC[None,:,:]);vol=np.prod(np.maximum(0,ih-il),axis=-1)
  mu=np.zeros_like(vol)
  for z in range(len(dens)):mu+=dens[z]*np.prod(np.maximum(0,np.minimum(ih,hi[z])-np.maximum(il,lo[z])),axis=-1)
  w=weight**2/(v[start:end,None]*v[None,:]);aa=mu*w;mm=lam*vol*w;gg=aa-mm
  ratio=r[start:end,None]/r[None,:];near=(ratio>=1/L)&(ratio<=L)
  rho=vol/np.minimum(v[start:end,None],v[None,:]);core=near & (np.maximum(ratio,1/ratio)>np.exp(1/(4*np.sqrt(n)))) & (rho<1/np.sqrt(n))
  nested=np.all((lowerC[start:end,None,:]>=lowerC[None,:,:])&(upperC[start:end,None,:]<=upperC[None,:,:]),axis=-1)|np.all((lowerC[start:end,None,:]<=lowerC[None,:,:])&(upperC[start:end,None,:]>=upperC[None,:,:]),axis=-1)
  vals={'A':aa.sum(),'M':mm.sum(),'near_A':aa[near].sum(),'near_M':mm[near].sum(),'far_A':aa[~near].sum(),'far_M':mm[~near].sum(),'positive_Gamma':gg[gg>0].sum(),'negative_Gamma':-gg[gg<0].sum(),'nested_A':aa[nested].sum(),'nested_M':mm[nested].sum(),'core_A':aa[core].sum(),'core_M':mm[core].sum()}
  for key,val in vals.items():sums[key]+=float(val)
 X=lam*N*weight
 rooterr=max(abs(mass(B,R)/R**n-lam) for B,R in zip(C,r))
 caperr=max(max(mass(B,R*t)/(R*t)**n-lam for t in [1.01,1.1,1.5,2,4]) for B,R in zip(C,r))
 assert rooterr<1e-7 and caperr<1e-7
 assert abs(sums['nested_A']-sums['nested_M'])<1e-7
 gamma=sums['A']-sums['M']
 return {'grid':k,'centers':N,'center_cell_volume':weight,'R_min':float(r.min()),'R_max':float(r.max()),'X':X,'W':float(W),'X_over_W':X/W,'A_over_X':sums['A']/X,'Gamma_over_X':gamma/X,'positive_Gamma_over_X':sums['positive_Gamma']/X,'negative_Gamma_over_X':sums['negative_Gamma']/X,'theta':theta,'required_K_on_grid':(gamma-theta*sums['A'])/X,'root_residual':rooterr,'sampled_outer_cap_max_excess':caperr,'sums':sums}
results=[run(k,.5) for k in [25,41,65,129,257]]
out={'scope':'n=2 fixed positive box-source, midpoint quadrature of full center domain; no certified center quadrature error, no general bound or dimensional claim','source':boxes,'level':lam,'a':a,'b':float(b),'environment':{'python':platform.python_version(),'executable':sys.executable,'numpy':np.__version__},'results':results}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(results,indent=2))
