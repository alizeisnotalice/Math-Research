# R394 — screening the actual local block coupling

**Status: no new payment.** This is a bounded compatibility check of one concrete coupling, not a general obstruction or a new research-round receipt. Only the R331 identities and the R333 accounting restrictions are used. No old Dirichlet credit is spent twice.

## 1. The proposed actual coupling

Fix a measurable countable partition of the real receiver set E into blocks B_j. At every original prefix use B_j(r)=B_j∩E_r and v_j(r)=|B_j(r)|, and define

\[
 S_r(u,v)=\sum_{j:v_j(r)>0}
 \frac{m_um_v}{v_j(r)}1_{B_j(r)}(u)1_{B_j(r)}(v).
\]

This is measurable, symmetric, and supported on actual receivers. Since μ(dv)=dv/m_v,

\[
 \int S_r(u,v)\mu(dv)=m_u
\]

for almost every actual receiver in each prefix. Thus its coupling measure S_r μ⊗μ has both marginals du; the capacity slack L_θ is zero. The same prefix-independent θ required by R331 is retained. This verifies feasibility, not the needed source-profile bound.

## 2. Exact compatibility calculation in a real Lebesgue field

Take R≡1, a=b=1, and E a cube of side L≤1/2 centered at zero, of volume V=L^n. Let P be a positive-volume cube centered at zero with side strictly smaller than 1−L. Every selected Q_1(u), u∈E, contains P. Put

\[
 f=\frac m{|P|}1_P,\qquad m>0.
\]

Then every actual receiver has m_u=q(u)=m; choose λ=m and q_-=3m/4. This is exact full-f matching with actual du, not a discrete receiver quadrature. W=m and X=mV. Choose 0<H≤V/m. On the full source support P, J=V/m, every capture indicator is one, and the cut e_S and the source low-row term vanish. The original clock is its genuine terminal atom δ_1.

Let v_j=|B_j|>0 and let θ be any bounded real measurable function on E. Write

\[
 \bar\theta_j=v_j^{-1}\int_{B_j}\theta\,du,
 \qquad \mathcal V_j=\int_{B_j}(\theta-\bar\theta_j)^2du.
\]

Directly expanding the R331 fit gives

\[
 \int f(y)R_{S,\theta}(y,1)dy
 =m\left[V+\int_E\theta^2du
 -\frac2{\sqrt V}\sum_j\sqrt{v_j}\int_{B_j}\theta\,du\right].
\]

The **same coupling's** available Dirichlet credit is exactly

\[
 D_\theta=\frac m2\sum_j\mathcal V_j.
\]

Completing the ordinary scalar squares proves

\[
\boxed{\begin{aligned}
 \int f R_{S,\theta}-D_\theta
 &=mV\left[1-\sum_j(v_j/V)^2\right]\\
 &\quad+m\sum_jv_j\left(\bar\theta_j-\sqrt{v_j/V}\right)^2
       +\frac m2\sum_j\mathcal V_j.
\end{aligned}}                                                    \tag{1}
\]

All sums converge for bounded θ: ∑v_j=V and ∑v_j^{3/2}≤V^{3/2}. Equality in the lower bound is attained by the bounded block-constant choice θ=√(v_j/V) on B_j. Hence for N equal-volume blocks the optimal remaining fit after the entire available D_θ is exactly

\[
 (1-1/N)X.                                                       \tag{2}
\]

This is a compatibility failure of the proposed **Dirichlet absorption mechanism**, even when the geometric cut is identically zero. Making the blocks spatially small does not make this fit small. Allowing arbitrary within-block θ does not fix the issue, as (1) explicitly accounts for that freedom.

It is **not** a counterexample to the desired root source bound: this field has X/W=V≤1. A source price of order W can cover (2). No assertion about the general optimum or general local transport is drawn from this example.

## 3. Which square was lost, and what remains unproved

In this field the all-row feature integral is constant on every receiver pair:

\[
 (\Phi f)(u,v)=m^{3/2}/\sqrt V.
\]

Its Gram energy on pairs in different blocks equals

\[
 Q_{\rm off}(f)
 =\frac mV\sum_{i\ne j}v_iv_j
 =mV\left[1-\sum_j(v_j/V)^2\right].                              \tag{3}
\]

Thus the exact minimum in (1) is the cross-block common-source square energy that a reference supported only on within-block pairs fails to represent. This identifies the loss; it does not price a general remainder.

One may lawfully retain the original off-block negative square and linearize only the within-block square. In the special field above, (3) then cancels the displayed minimum exactly. For general actual cubes, however, the two source factors in that retained square involve the true weighted intersections and J(y); their comparison with the off-block fit is not supplied by small block diameter or by the single-cube matching equations. A new joint geometric estimate would have to control that comparison with a root source price. It has not been constructed here. The previously paid directional R333 cut is not subtracted again.

The concrete verdict is therefore narrow: **the independent local block coupling is feasible, but small cut plus its own Dirichlet credit does not by itself make its fit inexpensive.** No generally payable new subbranch is asserted. Work stops at this screening result.

## 4. Actual local computation record

The following Python standard-library Fraction code was executed. It checks (1), its lower bound, and (3) for three stages N=4,9,16, with 135 cases per stage, **405 exact cases total, PASS**. Each block has two equal-measure θ subcells in the diagnostic; the analytic proof above permits arbitrary measurable θ. This calculation is an algebra check for the real-field formula, not a numerical root-bound certificate.

```python
from fractions import Fraction as F
counts=[]
for N in (4,9,16):
 root={4:2,9:3,16:4}[N]
 count=0
 for m in (F(1),F(3,2),F(2)):
  for V in (F(1,4),F(1,9),F(1,16)):
   v=V/N
   for base in (F(-1),F(0),F(1,root),F(1),F(2)):
    for shift in (F(0),F(1,7),F(1,3)):
     vals=[(base+F(i%3-1,5)+shift,base+F(i%3-1,5)-shift) for i in range(N)]
     means=[(x+y)/2 for x,y in vals]
     intsq=sum(v*(x*x+y*y)/2 for x,y in vals)
     meanterm=sum(v*z*z for z in means)
     var=intsq-meanterm
     defect=m*(V+intsq-2*sum(v*z/root for z in means))
     D=m*var/2
     claimed=m*V*(1-F(1,N))+m*sum(v*(z-F(1,root))**2 for z in means)+m*var/2
     assert defect-D==claimed
     assert defect-D>=m*V*(1-F(1,N))
     assert m*V*(1-F(1,N))==m*V*(N*N-N)/N**2
     count+=1
   optimum=m*(V+V/N-2*V/N)
   assert optimum==m*V*(1-F(1,N))
 counts.append(count)
print('Fraction exact checks: stages',counts,'total cases',sum(counts),'PASS')
```

Only this checkpoint file was written; no repository or other agent's research file was changed.
