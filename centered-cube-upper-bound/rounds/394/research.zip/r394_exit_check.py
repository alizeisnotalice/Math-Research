"""Exact checks for a bounded-rate jump model with unbounded V and no K gap.
Finite block checks are diagnostics; infinite sums are proved separately.
"""
from fractions import Fraction as F
from pathlib import Path
import json
counts={'model':0,'resolvent_layers':0,'tails':0}
def ck(t,key):
 assert t,key
 counts[key]+=1
def eye(n):return [[F(i==j) for j in range(n)] for i in range(n)]
def matmul(a,b):return [[sum((a[i][k]*b[k][j] for k in range(len(b))),F(0)) for j in range(len(b[0]))] for i in range(len(a))]
def add(a,b,coef=F(1)):return [[x+coef*y for x,y in zip(ar,br)] for ar,br in zip(a,b)]
def scale(a,c):return [[c*x for x in row] for row in a]
def inv(a):
 n=len(a);q=[list(row)+ir for row,ir in zip(a,eye(n))]
 for j in range(n):
  i=next(i for i in range(j,n) if q[i][j]);q[j],q[i]=q[i],q[j]
  pivot=q[j][j];q[j]=[x/pivot for x in q[j]]
  for i in range(n):
   if i!=j:
    t=q[i][j];q[i]=[x-t*y for x,y in zip(q[i],q[j])]
 return [row[n:] for row in q]
def power(a,n):
 b=eye(len(a))
 for _ in range(n):b=matmul(b,a)
 return b
def column(v):return [[F(x)] for x in v]
def ext(v):return v+[[F(0)]]
def absorption(v,r,V):return [[V[0]*v[0][0]],[V[1]*v[1][0]],[r*(v[0][0]+v[1][0])]]
for k in (1,2,4,8,16,32):
 r=F(1,2**(2*k));w=F(1,2**(4*k));u=column([2**k,F(1,2**k),0]);kap=F(2)
 A=[[r*(2 if i==j else -1) for j in range(3)] for i in range(3)]
 mu=column([kap,kap,r*(u[0][0]+u[1][0])]);nu=add(matmul(A,u),mu)
 V=[kap/u[0][0],kap/u[1][0]]
 K=[[A[i][j]+(V[i] if i==j else 0) for j in range(2)] for i in range(2)]
 ck(nu[2][0]==0 and all(x[0]>0 for x in nu[:2]),'model')
 ck(all(0<=x[0]<=kap for x in mu),'model')
 ck(sum(x[0] for x in mu)==sum(x[0] for x in nu),'model')
 ck(matmul(K,u[:2])==nu[:2],'model')
 ck(absorption(u[:2],r,V)==mu,'model')
 ck(K[0][0]==F(2,2**(2*k))+F(2,2**k),'model')
 for s in (F(1,16),F(1),F(16)):
  R=inv(add(scale(eye(3),s),A));T=inv(add(scale(eye(2),s),K))
  As=scale(R,s);Bs=scale(T,s)
  z0=matmul(T,nu[:2]);etas=[]
  for j in range(9):
   zj=matmul(power(Bs,j),z0);eta=absorption(zj,r,V);etas.append(eta)
   ck(all(0<=eta[i][0]<=mu[i][0] for i in range(3)),'resolvent_layers')
   rhs=add(nu,eta,F(-1)) if j==0 else add(scale(ext(matmul(power(Bs,j-1),z0)),s),eta,F(-1))
   ck(matmul(add(scale(eye(3),s),A),ext(zj))==rhs,'resolvent_layers')
  for N in (1,2,4,8):
   lhs=add(matmul(power(As,N),nu),ext(matmul(power(Bs,N),nu[:2])),F(-1))
   rhs=column([0,0,0])
   for j in range(N):rhs=add(rhs,matmul(power(As,N-j),etas[j]))
   ck(lhs==rhs,'resolvent_layers')
   derivative=add(scale(matmul(matmul(power(As,N),add(eye(3),As,F(-1))),nu),N),ext(scale(matmul(matmul(power(Bs,N),add(eye(2),Bs,F(-1))),nu[:2]),N)),F(-1))
   rhs=scale(matmul(As,etas[N]),-N)
   for j in range(N):rhs=add(rhs,scale(matmul(matmul(power(As,N-j),add(eye(3),As,F(-1))),etas[j]),N))
   ck(derivative==rhs,'resolvent_layers')
   partial=column([0,0,0])
   for j in range(N):partial=add(partial,etas[j])
   ck(add(partial,absorption(matmul(power(Bs,N),u[:2]),r,V))==mu,'resolvent_layers')
for L in (1,4,16,64):
 mass=sum((F(1,2**(4*k))*(4+F(1,2**k)+F(1,2**(3*k))) for k in range(1,L+1)),F(0))
 tail=4*F(1,2**(4*L))*F(1,15)+F(1,2**(5*L))*F(1,31)+F(1,2**(7*L))*F(1,127)
 ck(mass+tail==F(4,15)+F(1,31)+F(1,127),'tails')
 ck(sum((F(1,2**(2*k))+F(1,2**(6*k)) for k in range(1,L+1)),F(0))+F(1,3*2**(2*L))+F(1,63*2**(6*L))==F(1,3)+F(1,63),'tails')
result={'scope':'Exact bounded-rate countable graph model; not cube geometry. Infinite construction and no-gap follow from explicit series and Rayleigh bounds, not finite tests.','counts':counts,'total':sum(counts.values()),'M':str(F(4,15)+F(1,31)+F(1,127)),'u_L1':str(F(1,7)+F(1,31)),'u_L2_squared':str(F(1,3)+F(1,63)),'Omega_measure':str(F(2,15))}
Path(__file__).with_suffix('.result.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',result)
