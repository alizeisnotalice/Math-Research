# R394 exit/Abel domain audit — FINAL PASS

FINAL PASS for removal of the bounded-V assumption under the stated actual capped data and bounded symmetric jump hypotheses. This is a fixed-operator domain extension only; no original cube payment or general upper bound is certified. Only this file is edited. The independent screen below preceded r394_exit_abel.md. The old nonlocal_abel_absorption_review_20261007.md was read in full and already proves the bounded-V complete-exit/layer theorem. No bounded-V theorem is counted as new here. The only proposed extension is to the actual unbounded multiplication V=kappa/u on a finite-measure positive set. No centered-cube or variable-generator transfer is certified.

## Independent domain conclusion

Assume kappa>0, Omega={u>0} up to null sets, m(Omega)<infinity, u>=0 in L1 and L2, bounded-rate symmetric conservative nonnegative jump generator A, and nu=Au+mu>=0 in L1 and L2 supported in Omega. Require mu=kappa on Omega, mu=J_exit u outside and 0<=mu<=kappa globally. These are genuine input conditions, not supplied merely by Markovness. Uniform rates make Au in L1 as well as L2 and justify mass conservation M_nu=M_mu by signed Fubini.

A_Omega=P A E is the KILLED compression, including the outside-exit diagonal. It is not the censored within-Omega generator. The multiplication V=kappa/u is measurable, finite and positive almost everywhere on Omega but may be unbounded. Since Vu=kappa 1_Omega belongs to L2, u is in D(V). Bounded selfadjoint perturbation gives selfadjoint nonnegative K=A_Omega+V with D(K)=D(V), and Ku=nu|Omega follows from the actual equations. It is not an additional unsupported formal identity. Positivity/sub-Markovness of e^(-tK) follows from the killed positive semigroup and nonnegative multiplication potential. It must be justified as such, not inferred from selfadjointness alone.

The complete positive exit operator R maps D(V) into L2(X): inside Vz, outside integral_Omega j(x,y)z(y)dm(y). The external part is bounded by the rate/Schur estimate; the inside multiplication is generally unbounded. For z in D(K), A E z=E K z-Rz, and Ru=mu. Neither outside-exit absorption nor its mass may be omitted. Since V>0, ker K={0}; no quantitative spectral gap is needed. The kappa=0 degenerate case should either be excluded or separately treated, not use V>0 without qualification.

For g_t=e^(-tK)nu>=0, the graph-domain identity

    integral_0^b g_t dt=u-e^(-bK)u

is valid for u in D(K); the right side is positive and bounded above by u. Thus e^(-bK)u decreases to zero strongly in L2 and almost everywhere. Multiplication by V can be passed through the positive integrals by Tonelli. V e^(-bK)u is dominated by Vu=kappa 1_Omega, so its convergence is in L2 as well; the bounded outside-exit operator also converges in L2. Consequently integral_0^infinity Rg_t dt=mu, interpreted by positive integration, without claiming that R is bounded on all L2. This is the essential new domain argument. A V-truncation must NOT silently retain the positivity of nu=Ku when changing K.

Gamma-resolvent z_j=s^j(s+K)^(-j-1)nu belongs to D(K). The identity Rz_j=integral p_j(st)Rg_t dt and its derivative must be established using graph convergence/positive domination, rather than commuting a globally unbounded R through an arbitrary L2 integral. Once this is proved, 0<=Rz_j<=sup(p_j)mu, sum_j Rz_j=mu, and all old layer hypotheses follow. The integrated layer mass M/j is only for j>=1; the zero layer generally has a divergent ds/s mass integral. Its limiting contribution in the Abel energy must retain the possibly positive free-A kernel endpoint with favorable negative sign.

Abel notation A_s=s(s+A)^(-1), B_s=s(s+K)^(-1) gives

    D_N=A_s^N E nu-E B_s^N nu
       =sum_(j=0)^(N-1) A_s^(N-j) eta_j,
    eta_j=Rz_j.

The complete-exit sign and finite sum indices matter. The old layer theorem then yields 276 sqrt(N) kappa M once its exact layer, derivative, Beta and endpoint hypotheses have been verified. This is not a conclusion from a fixed Markov kernel alone, nor a cube receipt.

## Actual bounded arithmetic check

Reviewer ran 26 exact Fraction checks on one explicit symmetric three-state jump field, two-state Omega, saturated internal mu and positive external exit. The checks verify A E=E K-R, mass equality, the full D_N identity and the differentiated telescoping identity for s=1/3,1,3 and N=1,2,3,4. These finite bounded-V checks confirm signs/indices only; they do not prove the unbounded-V extension or the square-function integral. No author code or proof was read before this screen.

Independent-screen result: the extension is valid with the stated interpretation and guards. The completed author-proof and dependency review follows.


## Completed author-proof review

Read the entire frozen r394_exit_abel.md and the whole standalone r394_exit_check.py/result. The theorem explicitly assumes kappa>0, u in L1 intersect L2, Omega={u>0}, saturated internal mu=kappa, global 0<=mu<=kappa, mu in L1, and nonnegative nu=Au+mu supported in Omega. Thus Omega has finite measure automatically, nu is in L1 and L2, and the full mu/nu mass equality is legitimate. These assumptions are substantive input data, not an obstacle construction proved for arbitrary sources.

The killed compression, generator sign, complete positive outside jump contribution and identity A E=E K-R are correct. On the multiplication domain D(V), bounded A_Omega makes K selfadjoint and nonnegative with exactly that domain. The form argument supplies a positive sub-Markov semigroup. Vu=kappa makes u a genuine graph-domain vector and proves Ku=Pnu, rather than a formal multiplication. R is a closed graph-bounded map D(K)->L2(X), not a bounded L2 operator. The bound ||Rz||2<=||Kz||2+3Q||z||2 is sufficient. No V-truncation is used to manufacture a positive changed source.

For u_t=e^(-tK)u and g_t=e^(-tK)Pnu, positivity of Ku gives the special decreasing orbit identity. Strict positivity of V kills ker K, but does not require or imply a spectral gap. Inside absorption is dominated by kappa on finite Omega; outside absorption is dominated by the actual mu. Graph-norm integration away from zero followed by positive Tonelli and these two componentwise domination arguments correctly prove integral Rg_t dt=mu. There is no unjustified claim that integral ||Rg_t||2 dt is finite.

Each resolvent layer belongs to D(K). Integrating first on compact positive-time intervals and using closedness/positive multiplication and kernel integration identifies its complete exit with the Gamma integral. The resulting supremum-Poisson cap times mu controls the limit in L2 and L1. This also justifies the layer sum and derivative: scalar logarithmic derivative bounds dominate all difference quotients by a fixed multiple of mu on each compact s interval. The positive scalar Beta calculation passes to these integrals. M/j is restricted to j>=1; the zero layer is never assigned that finite mass. Its two limiting values are correct.

The finite Abel difference and derivative identities use j=0,...,N-1 and the complete full-space exit. Neither A and K commutation nor simultaneous diagonalization is invoked. The old abstract proof needs only the established layer caps, mass, derivative, Beta and endpoint facts, plus the fixed selfadjoint A and its positive L-infinity contraction. All these inputs are now available. Its four squared bounds 2,64sqrt(N),2sqrt(N),sqrt(N), followed by the four-vector inequality, give the inherited constant 276sqrt(N). This is an application of the existing independently proved scalar theorem, not a new bounded-V theorem or a transfer of a Euclidean maximal result.

The free-A zero endpoint <mu,P_ker(A)mu> is nonnegative and enters integration by parts with a favorable minus sign. It has not been set to zero. The result permits a zero free mode, and the killed operator has no positive uniform gap requirement. The external corollary follows simply because the zero-extended killed term and its s derivative vanish on Omega complement.

## Genuine unbounded-V and no-gap example

The countable disjoint three-vertex graph is coherent relative to its actual reference weights w_k=2^(-4k). Rates r_k=2^(-2k) are transition rates, while jump density relative to m is r_k/w_k, so the displayed graph is symmetric and uniformly bounded-rate (total rate at most 1/2). Both u components, mu, nu and the outside absorption have the stated signs and formulas. The geometric sums for ||u||1=1/7+1/31, ||u||2^2=1/3+1/63, m(Omega)=2/15 and M=4/15+1/31+1/127 are correct.

V=(2^(1-k),2^(1+k)) is genuinely unbounded above, approaches zero along the first vertices, and Vu=2 on Omega. The first-vertex Rayleigh quotient 2r_k+2^(1-k) tends to zero, proving no positive uniform spectral gap, while positivity of V still gives ker K=0. Componentwise constants supply free-A zero modes. These are analytic infinite-domain conclusions from exact series and trial vectors; a finite block computation is not substituted for them.

## Actual computation and its limits

Reviewer actually reran r394_exit_check.py: exit 0, 584 Fraction checks (36 model, 540 resolvent/layer, 8 exact tail identities). Reviewer also executed the unique Python block embedded in the proof: exit 0, 2976 Fraction scalar Gamma/Beta/Abel-coefficient checks. The standalone cases use finite blocks k=1,2,4,8,16,32 with finite matrices, while the tail cases check exact convergent-series formulas. These computations support formulas/signs and are not proofs of graph-domain limiting operations or the full integrated square-function bound. Reviewer reruns do not create additional independent cases beyond those scripts. The earlier reviewer 26 three-state checks are separate and not merged into the author's or parent's counts.

The F04 skill and its bounded prior index were used to locate and inspect the actual older proof; the old nonlocal_abel_absorption_review_20261007.md was read in full. No fresh validation of the external paper's full proof is claimed here. The late spectral Schur argument and constant were checked against that local proof, whose lack of bounded-V-to-unbounded-V coverage was explicit. The present domain work supplies precisely that missing extension.

## Final applicability conclusion

PASS for the frozen unbounded-potential exit-layer theorem with its stated data. It does not construct those capped data for arbitrary input, cover unbounded jump rates, handle a changing generator across scales, prove Euclidean high-frequency/Mellin comparison for cubes, or establish the original actual selector/history/source-traffic migration. The cube total ledger is unchanged and no source W receipt, new X absorption or reused negative-square credit is certified.

## Frozen SHA256 bindings

- `/tmp/r394_exit_abel.md`: `4eb363ffb44c359a5f6ea829e71a957261410942717a18e0101a062b2313724c`
- `/tmp/r394_abel_prior.md`: `5a00ecbcdbb3f7b46037df2244ac4ddc6c66db52a71c2f2ae7fe53078f7fa0ec`
- `/tmp/r394_exit_check.py`: `4cb45b7976d085ea7620968c86e134291cc37851608ffdedd79ef623cf5814d9`
- `/tmp/r394_exit_check.result.json`: `a88fe661b663e3d1ccdb86088d7621b70775048882d0a3785db88eeb66b1981f`
- `/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/geom_20261006/nonlocal_abel_absorption_review_20261007.md`: `76c68bfebf6033392ec2128e6a9f05477074108d6e05bbe5439e7c7c17506456`
- `/Users/zhengzhihao/.codex/skills/math-f04-poisson-gamma-abel-square-function/SKILL.md`: `1102ac9b098f7cb915119f8438a01d28314e588a0ff5d3fde3ab472d7b75e59d`


## Final parent report/readme consistency addendum

Read final r394_main.md and r394_readme.md. The report correctly limits the new result to unbounded V under saturated capped data, distinguishes Abel power N from cube dimension n, preserves the old 276 theorem as a dependency, and books no cube W/source-traffic payment. The unchanged r392 ledger is a context attachment, not replaced by this fixed-process theorem. No original selector/history/high-frequency migration is claimed.

One summary assumption was corrected before final binding: main now explicitly includes mu in L1. This is necessary: u in L1 intersect L2 and 0<=mu<=kappa with saturation alone do not ensure finite Omega or Vu in L2. With mu in L1, M is finite and nu in L1 intersect L2 follows exactly as in the author theorem. The corrected main is consistent with the proved domain result.

The report's 584 and 2976 exact-check receipts match the reviewed scripts. r394_scalar_check.py is byte-for-byte the same Python code block after stripping outer whitespace, so the standalone reproduction matches the actually executed embedded test. The separate 405-check local geometry checkpoint is ONLY parent-reported and is not included in this reviewer's proof/code audit; its formula and evidence are not certified by this addendum. Main explicitly says it yields no new root receipt and does not change the theorem or ledger. No 405 cases are folded into the reviewed exit-layer counts.

Additional final bindings:

- `/tmp/r394_main.md`: `e3f510065d578680ac41721b266d12628297614065254448452c3cffd4c65b7b`
- `/tmp/r394_readme.md`: `a0d456720e786f5b9e274fed818b82dfaa9942c78d14b10060b0d9c3f7d7e753`
- `/tmp/r394_scalar_check.py`: `a42dd74e644d6c36cacf26da0b3b376cb594126204acf0db684fe125ab17dc78`
- `/tmp/r392_ledger.md`: `4031079b6dcb0660da0460e316c19e4d71ff2dff055ba616aa41a4d376cc79f1`
