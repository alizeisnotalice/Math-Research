from fractions import Fraction as F
from math import factorial,comb
count=0
for N in range(2,25):
 for j in range(1,N):
  coeff=F(N*factorial(N-1)*factorial(N-j-1),factorial(N)*factorial(j-1)*factorial(N-j-1))
  assert coeff==F(j,factorial(j))
  count+=1
for N in range(1,25):
 for k in range(1,10):
  a=F(k,10)
  for j in range(N):
   direct=F(N-j)*a**(N-j)*(1-a)+j*a**(N-j)
   if j:
    direct-=j*a**(N-j+1)
   assert direct==N*a**(N-j)*(1-a)
   count+=1
print('Exact scalar Gamma/Beta and Abel-telescoping coefficient checks:',count,'PASS')
