# R394 — unbounded killing potential in the nonlocal exit-layer construction

**Precise scope.** This note removes the assumption `V∈L∞` from the bounded-jump theorem already proved in [the 2026-10-07 review](/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/geom_20261006/nonlocal_abel_absorption_review_20261007.md). That review already includes the full exterior exit operator and the abstract Abel estimate with constant 276. Those facts are not claimed anew. The additional work below verifies every layer input when `V=κ/u` is unbounded, using the actual obstacle data and positive-order integration. No truncation is assumed to preserve a positive modified source.

The proof architecture of the earlier scalar estimate follows [Spector–Stockdale, §§3.3–3.4](https://arxiv.org/html/2609.05377v1). Their Euclidean result is not a theorem about arbitrary cube selectors. The present extension concerns a single fixed symmetric jump operator and specified capped obstacle data.

## 1. The theorem and its concrete domain

Let `(X,m)` be a sigma-finite measure space and `j(x,dy)` a measurable nonnegative kernel such that

\[
 m(dx)j(x,dy)=m(dy)j(y,dx),\qquad
 q(x):=j(x,X)\le Q<\infty\quad\text{a.e.}
\]

Define `J h(x)=∫h(y)j(x,dy)` and `A=qI−J`. These are bounded on `L¹` and `L²`, with `||J||₂≤Q`, `||A||₂≤2Q`. The operator A is self-adjoint and nonnegative on `L²(m)`. Its semigroup and Abel means are positive contractions on `L¹,L²,L∞`, and `∫Ah dm=0` for `h∈L¹`.

Assume `κ>0`, `u≥0`, `u∈L¹∩L²`, and set `Ω={u>0}` modulo null sets. Suppose

\[
 0\le\mu\le\kappa,\quad \mu\in L^1,\quad
 \mu=\kappa\ \text{a.e. on }\Omega,\qquad
 \nu:=Au+\mu\ge0,\quad \nu=0\ \text{a.e. on }\Omega^c.       \tag{1}
\]

Thus `ν∈L¹∩L²` automatically. Write

\[
 M=\int\mu\,dm=\int\nu\,dm<\infty.
\]

The equality follows from absolute Fubini for `Au`, using `u∈L¹` and bounded jump rates. Moreover `m(Ω)≤M/κ`, and `||μ||₂²≤κM`. The case `M=0` is trivial and is excluded below.

Let E denote zero extension from Ω to X, P its adjoint restriction, and put

\[
 A_\Omega=PAE,\quad V=\kappa/u\text{ on }\Omega,\quad
 K=A_\Omega+V,\quad \mathcal D(K)=\mathcal D(V)
 =\{z\in L^2(\Omega):Vz\in L^2(\Omega)\}.                     \tag{2}
\]

The positive measurable V is finite a.e. on Ω but need not be bounded above or bounded away from zero. The bounded self-adjoint perturbation theorem makes K self-adjoint on this domain. Its quadratic form is

\[
 \langle z,Kz\rangle
 =\frac12\int_{\Omega\times\Omega}|z(x)-z(y)|^2m(dx)j(x,dy)
 +\int_\Omega[q_{\rm out}(x)+V(x)]|z(x)|^2dm(x),                \tag{3}
\]

with form domain `D(V^{1/2})`. This form is densely defined and closed. Truncation of functions in the form shows that `e^{-tK}` is sub-Markov; equivalently one can establish positivity and contraction by bounded-potential approximations in the form theorem. This use of approximation concerns only the operator: no capped-data identity or positivity of a truncated modified source is assumed.

Define

\[
 \mathsf A_s=s(s+A)^{-1},\qquad \mathsf B_s=s(s+K)^{-1},\qquad
 D_N(s)=\mathsf A_s^N\nu-E\mathsf B_s^N(P\nu),\quad N\ge1.
\]

Then the claimed conclusion is

\[
 \boxed{\displaystyle
 \int_0^\infty\|s\partial_sD_N(s)\|_{L^2(X)}^2\frac{ds}{s}
 \le276\sqrt N\,\kappa M.}                                    \tag{4}
\]

In particular the same bound holds for `s∂s(𝔄_s^Nν)` restricted to Ωᶜ, because the killed term vanishes there. There is no assumed spectral gap for either operator.

## 2. The complete exit operator, with its domain retained

For `z∈D(V)` define the operator from Ω to the whole space by

\[
 (\mathcal Rz)(x)=
 \begin{cases}
 V(x)z(x),&x\in\Omega,\\
 \displaystyle\int_\Omega z(y)j(x,dy),&x\in\Omega^c.
 \end{cases}                                                   \tag{5}
\]

This is positive on nonnegative inputs. It is generally **not** bounded on `L²(Ω)`. It is bounded for the graph norm of K:

\[
 \|\mathcal Rz\|_2
 \le\|Kz\|_2+3Q\|z\|_2.                                      \tag{6}
\]

Indeed `Vz=Kz−A_Ωz`, and the exterior part is a restriction of J(Ez). The operator R is also closed as a map with domain D(V): convergence of z and Rz in their respective L² spaces gives convergence of Vz on Ω, where multiplication by V is closed; the exterior component converges by boundedness of J.

Since `Vu=κ1_Ω∈L²(Ω)`, one has `u∈D(K)`. The data (1) give the three exact identities

\[
 Ku=P\nu,\qquad \mathcal Ru=\mu,\qquad
 AEz=EKz-\mathcal Rz\quad(z\in D(K)).                           \tag{7}
\]

On Ωᶜ the second identity uses `ν=u=0`, hence
`μ(x)=−Au(x)=∫_Ωu(y)j(x,dy)`. This exterior density is part of μ and of M. It cannot be dropped. Inside Ω, the identity is simply `Vu=κ`.

Since V is strictly positive a.e., (3) implies `ker K={0}`. It does **not** imply a positive spectral gap: u can be unbounded and hence V can approach zero.

## 3. Positive-order absorption identity without bounded R

Let

\[
 u_t=e^{-tK}u,\qquad g_t=e^{-tK}(P\nu)\ge0.
\]

Because `u∈D(K)` and `Ku=Pν`, for `0≤s<t` one has in L²

\[
 u_s-u_t=\int_s^t g_a\,da\ge0.                                \tag{8}
\]

Thus this particular orbit is decreasing in the positive order. This is a consequence of the nonnegative source `Ku≥0`; it is not a monotonicity assertion for arbitrary positive semigroup orbits. Choose the corresponding monotone versions. Then

\[
 0\le u_t\le u,\qquad u_t\downarrow0\text{ a.e.},\qquad
 u_t\to0\text{ in }L^2\text{ and }L^1.                         \tag{9}
\]

The L² limit is zero by the spectral theorem and `ker K=0`; the monotone a.e. limit therefore is zero. The L¹ conclusion follows by domination by u.

The two parts of `Ru_t` must be handled separately:

* On Ω, `0≤Vu_t≤Vu=κ` and `Vu_t↓0`; finite `m(Ω)` gives convergence in L¹ and L².
* On Ωᶜ, positive kernel integration gives `0≤J(Eu_t)≤J(Eu)=μ`. Dominated convergence inside the kernel gives pointwise convergence to zero wherever μ is finite, followed by L¹ and L² convergence using `μ∈L¹∩L∞`.

Consequently

\[
 \mathcal Ru_t\to0\quad\text{in }L^1(X)\cap L^2(X).             \tag{10}
\]

For `t>0`, `g_t∈D(K)` by the spectral bound on `Ke^{-tK}`; `t↦Rg_t` is strongly continuous on compact subintervals of `(0,∞)` by (6). On `0<δ<T`, graph-norm integration of (8) yields

\[
 \int_\delta^T\mathcal Rg_tdt=\mathcal Ru_\delta-\mathcal Ru_T.
\]

As `δ↓0`, `u_δ→u` in the graph norm because `u∈D(K)`, so the right side converges to `μ−Ru_T`. All integrands are nonnegative, hence Tonelli identifies the positive pointwise integral as well. Finally (10) proves

\[
 F(t):=\mathcal Rg_t\ge0,\qquad
 \boxed{\displaystyle\int_0^\infty F(t)dt=\mu}                 \tag{11}
\]

with positive pointwise meaning and convergence in L¹ and L² of the truncated integrals. In particular `∫∫F(t,x)dm(x)dt=M`. No assertion that `∫||F(t)||₂dt` is finite is needed.

## 4. All layer inputs now follow for the unbounded potential

Set

\[
 z_j(s)=s^j(s+K)^{-j-1}(P\nu),\qquad
 \eta_j(s)=\mathcal Rz_j(s),\qquad
 p_j(t)=e^{-t}t^j/j!,\quad j\ge0.                              \tag{12}
\]

The resolvent expression belongs to D(K). The Gamma integral and positive Tonelli in (5) give

\[
 z_j(s)=\int_0^\infty p_j(st)g_tdt,\qquad
 \eta_j(s)=\int_0^\infty p_j(st)F(t)dt.                         \tag{13}
\]

The first integral is an ordinary L² Bochner integral. For the second, no boundedness of R is silently used: first integrate over `[δ,T]`, then apply positive Tonelli separately to multiplication by V and to the exterior jump kernel. The resulting positive integral is dominated by `sup p_j·μ`, hence converges in L²; closedness in (6), or the componentwise formula itself, identifies it with Rz_j. This also verifies its L¹ finiteness.

The elementary Poisson bound `sup p_j≤(j+1)^{-1/2}` (including j=0) gives

\[
 0\le z_j(s)\le(j+1)^{-1/2}u,\qquad
 0\le\eta_j(s)\le(j+1)^{-1/2}\mu,\qquad
 \sum_{j=0}^\infty\eta_j(s)=\mu.                              \tag{14}
\]

The layer sum converges in L¹ and L² by positive domination. For `j≥1`, another application of Tonelli gives the exact scale mass

\[
 \int_0^\infty\|\eta_j(s)\|_1\frac{ds}{s}=\frac Mj,
 \qquad
 \int_0^\infty\|\eta_j(s)\|_2^2\frac{ds}{s}
 \le\frac{\kappa M}{j\sqrt{j+1}}.                              \tag{15}
\]

There is no j=0 version of the mass integral. Differentiation of (13) is legitimate in L²: the logarithmic derivative of the scalar kernel is
`j p_j−(j+1)p_{j+1}`, whose absolute value is bounded by a constant depending on j, so its integral against F is dominated by that constant times μ. The same bound controls difference quotients. Hence

\[
 s\partial_s\eta_j=j\eta_j-(j+1)\eta_{j+1}.                    \tag{16}
\]

For `1≤j<N`, the scalar substitution `v=(1−θ)/θ` in the Gamma kernels proves

\[
 j\eta_j(s)=N\int_0^1\eta_N(s/\theta)
 \frac{(N-1)!}{(j-1)!(N-j-1)!}
 \theta^{j-1}(1-\theta)^{N-j-1}d\theta.                        \tag{17}
\]

All kernels are positive, so the calculation passes to (13) without an additional domain assumption. Finally, scalar dominated convergence in (13) yields

\[
 \eta_0(s)\to\mu\quad(s\downarrow0),\qquad
 \eta_0(s)\to0\quad(s\to\infty)
 \quad\text{in }L^1\cap L^2.                                  \tag{18}
\]

Equations (14)–(18) are exactly the layer hypotheses used by the previously proved abstract square-function lemma.

## 5. Full-space identities and inheritance of the old 276 bound

Equation (7), applied to (12), gives

\[
 (s+A)Ez_0=\nu-\eta_0,\qquad
 (s+A)Ez_j=sEz_{j-1}-\eta_j\quad(j\ge1).
\]

Therefore the finite Abel telescoping is exact on the **whole** space:

\[
 D_N(s)=\sum_{j=0}^{N-1}\mathsf A_s^{N-j}\eta_j(s),\qquad
 sD_N'(s)=N\sum_{j=0}^{N-1}\mathsf A_s^{N-j}(I-\mathsf A_s)\eta_j(s)
             -N\mathsf A_s\eta_N(s).                          \tag{19}
\]

The index range is `0≤j<N`. Each term is L² differentiable; no simultaneous diagonalization of A and K is involved.

For clarity, the existing abstract estimate applies with no modification of its scalar constants. Its four pieces have squared bounds

\[
 2\kappa M,\qquad64\sqrt N\kappa M,\qquad
 2\sqrt N\kappa M,\qquad\sqrt N\kappa M,
\]

respectively for the zeroth layer, early layers, late layers, and terminal term. The late-layer scalar Schur operator has row integral at most 2 and column integral at most 1; its derivation uses (17) and the fixed spectral decomposition of A. Summing four vectors costs at most a factor four, giving `276√NκM` as in (4).

The zero mode must be kept. Specifically, in the zeroth-layer integration by parts the endpoint is

\[
 E_N(0)=\langle\mu,P_{\ker A}\mu\rangle\ge0,
 \qquad E_N(\infty)=0,
 \quad E_N(s)=\langle\eta_0(s),\mathsf A_s^N\eta_0(s)\rangle.
\]

It enters with a minus sign and is favorable. In a finite conservative reversible graph it is generally nonzero; it has not been set to zero here. The proof only needs (18), not invertibility of A. Thus every input of the old abstract estimate is established for the unbounded V of (2), and the same numerical constant is legally inherited.

## 6. Boundaries of the conclusion

This is a domain extension of a fixed-operator theorem. It does not construct the capped decomposition (1) for every proposed source. It also does not cover unbounded total jump rates or an arbitrary abstract closed form without the displayed jump-kernel and exit representation. In particular, this note makes no assertion that truncated potentials retain positive modified sources.

The following cube interfaces remain unproved here: comparison of the original actual selector and historical traffic with this fixed process; changes of generator across scales; any error from homogenization; and the requisite high-frequency or maximal-response comparison. Neither (4) nor the Ωᶜ corollary pays an original cube source-traffic slot by itself.

## 7. An explicit nonempty example with unbounded V and no gap

The following countable graph, supplied by the parent task, satisfies the theorem's assumptions and lies outside the old bounded-V scope. For each integer k≥1 take a disjoint three-vertex component. Every vertex in that component has reference measure `w_k=2^{-4k}`. Each of its three undirected edges has actual transition rate `r_k=2^{-2k}` in either direction. Equivalently the symmetric jump **density with respect to m** is `r_k/w_k` on such an edge; integrating against the destination vertex measure gives the rate r_k. The total jump rate is at most 1/2.

Put, on the three vertices,

\[
 u_k=(2^k,2^{-k},0),\qquad \kappa=2,\qquad
 \mu_k=(2,2,2^{-k}+2^{-3k}).
\]

Then Ω consists of the first two vertices of every component, `0≤μ≤2`, and direct evaluation gives

\[
 \nu_k=Au_k+\mu_k
 =\bigl(2+2^{1-k}-2^{-3k},\quad
        2+2^{1-3k}-2^{-k},\quad0\bigr)\ge0.
\]

The exact convergent geometric sums are

\[
 \|u\|_1=1/7+1/31,\quad \|u\|_2^2=1/3+1/63,\quad
 m(\Omega)=2/15,\quad M=4/15+1/31+1/127.
\]

Also `Vu=2` on Ω, so `Vu∈L²`, whereas

\[
 V_k=(2^{1-k},2^{1+k})
\]

is unbounded. In the kth component, the Rayleigh quotient of the vector supported only on its first vertex is `2r_k+2^{1-k}`, which tends to zero. Hence K has no positive uniform spectral gap, although `ker K={0}` as proved above. The full conservative A does have zero modes, namely componentwise constants, so the favorable zeroth-layer endpoint must be retained.

These statements follow from the displayed formulas and geometric series; no finite truncation is substituted for the infinite-domain assertion. This note does not claim a new numerical run of this example. It is an analytic domain example, not a cube construction.

## 8. Actual computation, limited to scalar consistency

A local Python `Fraction` run checked 276 Gamma/Beta factorial coefficients and 2700 Abel derivative/telescoping coefficients, **2976 exact checks total, PASS**. These are algebra checks, not a numerical verification of the domain limit or the integrated square-function theorem. The domain conclusions above are proved analytically. No old finite-graph numerical record was rerun or relabelled as new evidence.

Executed code:

```python
from fractions import Fraction as F
from math import factorial,comb
count=0
for N in range(2,25):
 for j in range(1,N):
  coeff=F(N*factorial(N-1)*factorial(N-j-1),factorial(N)*factorial(j-1)*factorial(N-j-1))
  assert coeff==F(j,factorial(j))
  count+=1
for N in range(1,25):
 for k in range(1,10):
  a=F(k,10)
  for j in range(N):
   direct=F(N-j)*a**(N-j)*(1-a)+j*a**(N-j)
   if j:
    direct-=j*a**(N-j+1)
   assert direct==N*a**(N-j)*(1-a)
   count+=1
print('Exact scalar Gamma/Beta and Abel-telescoping coefficient checks:',count,'PASS')
```

Only `/tmp/r394_exit_abel.md` is authored for this task. No repository or other agent's file is modified.
