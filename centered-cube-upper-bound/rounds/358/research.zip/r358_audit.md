# R358 independent audit — preliminary screen and energy-file review

Status: FINAL PASS for the bounded energy identity, smoothing construction, explicit packing-cost note, numerical scope, and unchanged R357 ledger. No general root-order receipt is certified. This is not a new paid root-order receipt. Only this audit file is owned by the reviewer; no author or repository file was changed.

## Independent conclusions before author review

Let sigma=q du on the original finite receiver set, I=i sigma the original entrance, and G=g sigma the sum of ALL arrivals of the unchanged killed history process, before the current tests. Required contracts are sigma P<=sigma, 0<=i<=1, and the genuine finite mass-growth horizon giving 0<=g<=N. Keep every old source, clock, rank and endpoint mark. In particular, G and its edge measure must not be conditioned on eventual membership in F_low.

For aggregate surviving edges T, the joint domination T<=G(du)P(u,dv) permits a joint Radon--Nikodym density in [0,1]. It defines Kbar<=P; set Kbar=0 on {g=0}. Thus sigma Kbar<=sigma and the exact marginal balance is G=I+G Kbar. Standard Borel receiver/history spaces and finite measures suffice for the measurable disintegration. This is an effective marginal kernel, not a claim that the history process was originally Markov in the receiver alone.

Only the selected ordinary native-rank terminal event is used to define Z_low=beta G. It gives beta<=1-Kbar1 and beta<=b_native, with beta=0 on {g=0}. Rich, inner-source and ancestor-recapture stops must not be included as native rank terminals. Posthoc source/direction/face gates are legitimate positive restrictions; no future-conditioned posterior or continuation kernel is used. The exact source-rank identity is int b_native d sigma=int f min(D,Delta)<=Delta W, including fractional equal-mass ranks and the original full-f posterior.

Writing J_inj=int i g d sigma, the exact identity is

    2 J_inj = int sigma Kbar (g(u)-g(v))^2
              + int sigma(1-Kbar1)g^2
              + int (sigma-sigma Kbar)g^2.

No reversibility is needed. Both marginal deficits are nonnegative. Since g<=N and sigma(E)=X_q<infinity, all terms are finite. Cauchy--Schwarz in beta sigma gives

    F_low^2 <= (int beta d sigma)(int beta g^2 d sigma)
             <= 2 Delta W J_inj.

Zero terminal capacity causes F_low=0 directly. If a new actual-field bound J_inj<=C log^A(n+2) X_q were established, Young's inequality would give source fee C Delta log^A(n+2) W/(2 epsilon) and receiver fee epsilon X_q. Both inherit the original entrance and exterior multipliers. That bound is not proved here. The available estimate J_inj<=N I(E)<=N X_q retains Delta*N=O(n). Strict mass growth and finite horizon alone do not remove this factor.

The identity preserves actual edge dissipation, stopping loss, and reference column deficit. It is a sharper exact diagnostic than replacing occupation by N at the outset, but does not by itself pay any new part of the original flow. A valid sufficient condition would bound cumulative entrance-density cost along actual effective-kernel trajectories, or supply a nonnegative supersolution V>=i+Kbar V with int I V bounded by the desired logarithmic multiple of X_q. No such condition is inferred from terminal sparse-face information.

## Bounded local calculation actually executed

Python standard-library Fraction calculation: 24 nonreversible finite substochastic models; 480 exact assertions PASS. Four reference weights (1,2,3,4), forward probability 1/2, varied generation filters and selected normal-terminal probabilities were aggregated for four generations. The checks cover exact entrance balance, reference subinvariance, both terminal-rate bounds, g<=N, all three energy terms, and Cauchy--Schwarz. This is finite algebra only, not an original cube/rank realization and not a new geometric budget. No parent pipeline was rerun.

## Author energy note reviewed

Read /tmp/r358_energy.md in full after the independent screen. Its statements (1)--(12), zero-G conventions, actual/full-arrival scope, finite-energy justification, and conditional Young fee agree with the independent derivation. The note correctly excludes artificial horizon terminal mass, future conditioning, and reuse of old B_H square credit. No mathematical correction requested.

Reviewed byte binding:

- /tmp/r358_energy.md: SHA256 6249b9ee9fb7ad3aa1d17961c05f77c2a26f072b4df99bacf16da05d4b7561b0

This preliminary waiting status is superseded by the final integration review below.

## Additional independent screen: averaged noncyclic rank shift

Status: PASS with the following precise scope; no author smoothing proof read for this screen. This is an auxiliary construction and has not replaced the original R355/R357 process.

For each source z let xi_z=c_u(z)du/R_u^n with finite total D(z). Choose the increasing mass rank with uniform randomization over every positive-mass equal-mass block: R_z(u,ds) is a probability kernel supported on the corresponding rank interval. A non-atomic mass rank is a point mass. The joint law xi_z(du)R_z(u,ds) has s-marginal Lebesgue on [0,D(z)]. Standard Borel disintegration supplies the inverse conditional receiver law at rank. All assertions are xi_z-almost everywhere; zero D sources may use zero transition. Rank endpoints have no Lebesgue mass.

Let D0=1+sqrt(n)+log(4/3), Delta=2(1+sqrt(n)), w=Delta-D0>0. Average noncyclic shifts h uniformly over (D0,Delta). Disintegrating the target rank, then using t=s+h and Tonelli, gives the receiver transition density relative to xi_z(dv):

    k_z(u,v) = (1/w) int R_z(u,ds) int R_z(v,dt)
                         1{D0<t-s<Delta}.

In particular 0<=k<=1/w. One must randomize both the initial equal-mass rank and the target receiver conditional on its rank; an arbitrary deterministic within-atom tie rule need not satisfy this density formula. Each fixed noncyclic shift has row mass <=1 and reference column <=xi_z; averaging preserves both. If the strict upper mass tail xi_z{m_v>K m_u}>Delta, all initial randomized ranks have more than Delta rank available above them, so the row is exactly one. This row-one condition is for that eligible input only; it is not automatically true for all later arrivals of an iterated process.

The closed mass-window capacity xi_z{m_u<=m_v<=K m_u}<=D0 implies that rank displacement >D0 lands strictly above K m_u. Equal-mass target blocks and threshold atoms are thereby excluded up to null rank endpoints. The original positive late input has the required strict tail only when the existing soft-score/high-past contracts actually supply it; it must not be inferred merely from a nonzero full rank row.

For sigma=q du and the full-f posterior, the labelled edge measure is

    sigma(du) pi_u(dz) Qbar_z(u,dv)
       = f(z) dz xi_z(du) k_z(u,v) xi_z(dv),

so it is bounded by f(z)dz xi_z(du)xi_z(dv)/w. Integrating z gives sigma Pbar<=sigma. This uses the original full-f posterior and all true du factors, not a source density cap. The exact native top-rank loss is

    int sigma bbar = int f(z) E_h min(D(z),h) dz
       <= ((D0+Delta)/2) W.

Thus the proposed density, strict mass growth, subinvariance and averaged loss cap are valid. They do not certify occupation, new total-flow domination, or any replacement of the already frozen process/ledger. A changed kernel would require its own marked entrance and stopping decomposition before transferring later terminal conclusions.

Local tool evidence: Python Fraction, 16 finite atomic rank models, 634 exact assertions PASS. Exact rank-rectangle areas were used to check density bounds, rows/columns, eligible row equality, and the averaged min(D,h) loss identity. These are algebraic rank tests, not native cube/process realizations.

## Smoothing author file review

Read /tmp/r358_smoothing.md in full after the independent screen. PASS for its bounded construction (6)--(18). The disintegration formula handles a repeated mass atom using its entire rank interval; (8) is the correct positive-part rectangle area. Incoming ramp A(t), outgoing ramp A(D-s), and averaged terminal function (11) have the stated endpoint values. Strict gap follows from the CLOSED mass-window cap and OPEN displacement interval, while row-one availability is restricted to the original positive late input.

The strengthened bound k(u,v)+k(v,u)<=1/w is valid by disjoint opposite oriented rank strips. Consequently the symmetric nonnegative product estimate (17) has factor 1/(2w), and the real squared-difference estimate (18) has factor 1/w after the factor-two product variance expansion. Neither is a lower overlap/capture-square bound. Full-f labelled identity (14) and source intersection density (15) retain the real receiver measures. The note correctly distinguishes the new witness law from the archived process and lists the stopping/terminal predicates that would require reconstruction before any ledger replacement.

Embedded code was read for scope, not rerun: its 401 recorded checks are finite rank-block algebra, not full high-past cube-history realizations. No author test count is merged with the reviewer's separate 634 exact checks.

Reviewed byte binding:

- /tmp/r358_smoothing.md: SHA256 666c186f1459c53f236f863a2bea5b3c2e3cd9f3e91b7889f4a1e2c66beebc93

This interim status is superseded by the final integration review below. No new source or receiver fee has been charged.

## Final file-level integration review and freeze

Conclusion: PASS for the explicitly bounded R358 deliverable. Read the final main, ledger, readme, energy, smoothing and geometry notes, both numerical programs and both numerical notes, their JSON outputs, and the extracted proof scripts. No mathematical correction is outstanding. This review does not re-audit the complete historical/global reduction or certify the eventual TeX layout. Only this audit file was edited; no author/repository files were modified.

1. The actual energy note applies to the unchanged complete R355 killed process. F_low=F_sparse is only its selected R357 normal-terminal event. Three nonnegative dissipations and both deficits remain in the exact identity. The original full-f rank loss provides Delta W, not an assumed density cap. The conditional J_inj logarithmic bound and resulting source coefficient C Delta/(2 delta) are stated with the right direction and are not inserted as an already paid term. Presently J_inj<=N X_q only.
2. The smoothing tool is a distinct new kernel/witness. Its density and symmetric square factors are correct, including equal-mass rank randomization, sourcewise subinvariance and averaged native terminal loss. The final main explicitly restricts its row-one assertion to eligible original late inputs. Its new terminal predicates and flow-dependent direction ratios have not been migrated. Nothing from the new kernel is substituted into the old residual or old energy aggregate.
3. The endpoint-packet note correctly charges entrance projections once, not cumulative visits. The radius density ratio is used once between endpoints; shared-source capture supplies the consecutive-center displacement. The certified envelope is D_n=1+2(lambda/q_-)^(1/n)/(exp(1/sqrt(n))-1), and packet volume costs D_n^n. Actual root cubes, measurable packet assignment, and favorable full-f overlap are hypotheses, not proven constructions. Anisotropic overlap retains int f sum d_nu 1_Bnu. Neither terminal low face count nor source-direction dispersion is transferred to earlier transitions. No new paid branch or geometric impossibility claim is made.
4. The rank diagnostics use actual compact positive-volume source boxes with exact cube incidence and actual matched m/q, but finite receiver quadrature and diagnostic small shifts. The reset mean is zero only before truncation; the reference truncated reset is negative covariance. The actual incoming-density correction is retained and takes both signs in the recorded fixtures. Exact occupation is a rational resolvent with same-mass self-loops; it is not an original strict-mass finite-horizon process. The energy diagnostics reuse frozen mechanism inputs without importing/rerunning the old main; their embedded inputs match every relevant field of numeric_result.json, and the provenance SHA matches its actual bytes. Killed kernels retain both row and column dissipations. Their measured J/X is not a uniform bound.
5. Result files report PASS 296 rank assertions and PASS 255 energy assertions, with the declared 61/82/153 and 25/27/33 profile breakdowns. The proof scripts have the same executable content as the unique embedded blocks; their extracted files differ only by outer blank-line formatting. The parent reports fresh actual execution of all four programs: 296+255+401+6244=7196 exact Fraction assertions and three ordinary float size diagnostics. This reviewer inspected code/results, and did not unnecessarily repeat those pipelines. Separately this reviewer actually ran 480 energy-algebra assertions and 634 atomic smoothing assertions; those 1114 finite-algebra checks are not included in the parent's 7196. No rank.md claim or unarchived code is needed for the reset facts used in main.
6. The ledger retains the exact R357 residual and all source costs: [C_epsilon,n+8s+C_dir+C_multi]W+(D_top+C_hit+s)W_ex, and unchanged receiver coefficient [(13/3)epsilon+gamma_eff+beta+alpha_rec+c_eff]X_q. There is no R358 source or receiver addition. Entrance two and exterior Lambda still multiply every applicable fee. The bound <889/2304 and remaining >1415/2304 retain the explicit condition that the historical CZ 1/256 belongs to the same certified X account. An absorption balance is not an estimate of any remaining integral.
7. General soft and crossing terms, the hard-contract exterior, wide distance/low-pe/extreme-scale and threshold complements, chronological initial/deletion/future-source atoms, and source/layer/scale/outer-integration/truncation-limit costs remain unpaid. New rank termination is not a payment of historical time atoms. General B_H and the dimension-uniform target remain unresolved.

### Frozen SHA256 bindings

- /tmp/r358_main.md: `77727c988b9170c6bb29c25c602026a088902c3848f3097b98f974bee36a2d28`
- /tmp/r358_ledger.md: `6e822924916e53f30d1b890ac8083fd1447c424e808f1a14f6c51ccd665423dd`
- /tmp/r358_readme.md: `1280bf95f385d2bf49f87bebb049033bb62261544e76dddd39088cc395156f58`
- /tmp/r358_energy.md: `6249b9ee9fb7ad3aa1d17961c05f77c2a26f072b4df99bacf16da05d4b7561b0`
- /tmp/r358_smoothing.md: `666c186f1459c53f236f863a2bea5b3c2e3cd9f3e91b7889f4a1e2c66beebc93`
- /tmp/r358_geometry.md: `8342bb5b8bde7a87dd5f04e5cfee5eb2dc2a183134babc95d84b335f2fea3d0e`
- /tmp/r358_numeric.py: `c49af036aa20a55e47c3063b40c88b3221fef0bdc49a1f696b3196f7c08311b6`
- /tmp/r358_numeric.md: `17636e59e0db0dd58d37ff4114646dd6018ce687f0761e69d457f6708fd4245b`
- /tmp/r358_numeric_result.json: `be0d5b910517f3703936786750967f7ff6d87de5456fa4e2ff849f602d77ff51`
- /tmp/r358_energy_checks.py: `b39a4bfac15dfd23d353179f910a0a913008910a8c011ba1a42f31108ac60ac5`
- /tmp/r358_energy_checks.md: `2acbac98aac117b07c1f5cd24f157bce706eaa5a72d8207b045e918a485d04eb`
- /tmp/r358_energy_checks_result.json: `b334563951a03ae72a49825f13431c8d1a41162b2914a6d9147bb0f4b0976a07`
- /tmp/r358_smoothing_checks.py: `8fa27c0e0493e23f44ee102030b29a4c00814e68a5685ae227de7c84620c2688`
- /tmp/r358_geometry_checks.py: `c6cc84e0b572a80409bec8d7c3d35663b0d2676f57863582e3b863ce51d04ec5`

Necessary earlier-interface bindings below are dependency identifiers, not a claim of a fresh full-history re-audit in R358. The detailed current-file contracts used by the energy/smoothing notes and the carried R357 ledger were checked at the stated scope.

- /tmp/r357_ledger.md: `2ed62fbf2d32e3d4293281f1d9ed4417aab78653f6e094b6e806a4a10f8c89aa`
- /tmp/r357_geometry.md: `5d954e2b627ba7504e78df7bdc1ce69f94dd0c63c7fb2de5e52c2e303db3f66c`
- /tmp/r355_geometry.md: `42febb6f3d8a479db4799f30a9be06cb3d87e2a8011a752321d8f2f7deb0ae64`
- /tmp/r350_geometry.md: `eef2a5ba2e20828387aab0ac8a8d3b58a55196229a44ae63f8870804b5b74b20`
- /tmp/r357_audit.md: `41689edac70bfbc7e6afadfa94d1f94aa6b494f644d7c116d21b8153946f7808`

Final freeze: 2026-10-18. No further work is asserted or required within this bounded audit.
