R358 actual-cube finite rank-reset exploration

Frozen fresh local Python processes returned PASS 296 exact Fraction assertions: initial 61, same-mass/self-loop stress 82, expanded 2D 153. Reproduce:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r358_numeric.py
```

The self-contained standard-library script writes r358_numeric_result.json beside itself. Source boxes, masses, receiver cube centres/sides/finite weights, rank groups, P, sigma, input I, occupation G, potentials and reset terms are recorded exactly. There is no optimizer, imported temporary data, or random matrix search.

Actual geometry, finite receiver scope. Every source is a positive-volume uniform box of side 1/50. Exact endpoint tests verify each physical receiver cube wholly captures or misses every source box. The actual full source masses m_u=sum_z f_z c_uz and q_u=m_u/R_u^n are used, never reset. Receivers have positive QUADRATURE weights dx_u, not a claimed continuum receiver-dx realization. Initial/distinct and tie-pressure fixtures use source centres 0,1 with masses 1,2. The 2D fixture uses the four corners of [0,1]^2 with masses 1,2,3,5, private cubes, two row cubes and a shared cube. These compact positive-L1 sources genuinely determine all incidences and masses.

Atom-safe rank kernel. For each source, xi_z(u)=c_uz dx_u/R_u^n. Receivers of the SAME matched mass are grouped into a single rank atom [a,b] of width sum xi_z. Rank conditional on any current receiver in that group is uniform on the WHOLE group block; it is not ordered by receiver id. A noncyclic shift Delta maps s to s+Delta. On a target group [c,d], target receiver v is disintegrated with probability xi_z(v)/(d-c). Consequently

Q_z(u,v)=length([a+Delta,b+Delta] intersect [c,d])/(b-a) * xi_z(v)/(d-c).

The stress fixture has two actual source-sharing cubes with equal m; their kernel rows agree. Source target-rank density is checked to equal the original xi density restricted to ranks s>Delta, including partial atoms. All losses are retained as terminal subrow probability. P(u,v)=sum_z pi_u(z)Q_z(u,v), using the actual full-source posterior pi_u(z)=f_z c_uz/m_u.

Delta=1/4 or 1/5 is explicitly DIAGNOSTIC, not the original 2(1+sqrt(n)). The menus, q values and input are not claimed to satisfy original high-past/hard-entry/history qualification. There can be same-mass transitions and self-loops; no strict mass-growth or nilpotence is asserted.

Reference and actual occupation. sigma_u=q_u dx_u satisfies sigma P<=sigma exactly. Positive diagnostic I_u=sigma_u/(u+2) is at most sigma but is not claimed to be the original marked input. The full occupation G=I+GP is solved by exact rational Gaussian elimination. Transitions to lower matched mass are absent, and each same-mass block has strict subrow loss to higher mass or killing. This certifies finite-block transience despite self-loops. All G are nonnegative; terminal loss sums exactly to the input. Ten explicit generations each obey the reference cap.

| Fixture | Input total | Reference total | Occupation total |
|---|---:|---:|---:|
| Distinct small | 5/12 | 5/4 | 11/18 |
| Same-mass/self-loop | 7/2 | 23/2 | 313/6 |
| Actual 2D source | 7207/4032 | 1397/144 | 1157915/193536 |

The stress occupation is about 4.5362 times the reference total, while every generation respects it. This is evidence against replacing a sum of generation occupancies by the single-generation cap, not a claim about a native hard branch.

Continuous rank potential. Given current receiver u, sample z from pi_u and then S uniformly on its entire source mass-group block. V(u)=E S. The actual joint transition integrates the START rank over the overlap interval and uses TARGET rank S+Delta. Thus every successful same-source point-rank shift has increment Delta exactly, but neither block-midpoint changes nor receiver-potential changes are automatically Delta.

The complete UNTRUNCATED current joint obeys E[V(u)-S]=0. After reference rank shifting, the correct reset is

R_ref=sum_w sigma_w E[(V(w)-S)1_{S>Delta}]
     =-sum_w sigma_w Cov(S,1_{S>Delta}) <=0.

The code verifies each covariance sign and the full equality. It does NOT call this truncated reset zero. For arbitrary relative incoming density g=weights/sigma, the target-rank weight is

B(w,z,s)=1_{s>Delta} sum_u H_z(s-Delta,u)g(u),

where H disintegrates the source rank atom by xi. Partitioning every target rank block at all shifted group boundaries gives an exact integral of (V(w)-s)B. That target formula agrees with joint edge integration for reference sigma, input I, occupation G, and the signed difference G-sigma. No source/receiver independence is inserted.

| Fixture | R_ref | Occupation reset | Occupation minus reference reset |
|---|---:|---:|---:|
| Distinct small | 0 | 0 | 0 |
| Same-mass/self-loop | -33/32 | -143/24 | -473/96 |
| Actual 2D source | -99/800 | -561187/5806080 | +786577/29030400 |

Thus the actual-minus-reference correction has both signs in these predeclared actual-cube fixtures. Although the displayed total resets happen to be nonpositive, no general sign for actual g is inferred. The reference covariance alone does not pay the correction.

Finally, the occupation-weighted receiver-potential change is checked against three exact pieces: actual target-rank resampling reset, Delta times successful occupation mass, and the survival-conditioned starting-rank correction. The receiver-potential balance also equals terminal-current potential minus initial potential. This retains atom conditioning and source resampling instead of treating mean drift as automatically zero.

Bounded conclusion. The examples certify the finite atom-safe kernel and expose two quantitatively material issues: same-mass self-loop occupation can greatly exceed one reference layer, and the actual-source reset differs from the favorable reference covariance by an unsigned correction. They do not certify the original native Q, original input, continuous receiver du, strict mass growth, core payment, or a root bound. No search for positive/negative arbitrary incidence examples or dimension asymptotic was conducted.
