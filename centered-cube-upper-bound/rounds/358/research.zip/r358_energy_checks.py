#!/usr/bin/env python3
"""Independent finite energy checks on frozen actual-cube rank-reset matrices."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json
BASE=Path(__file__).resolve().parent;C=Counter()
# Embedded frozen r358_numeric_result.json mechanism inputs; no runtime import/re-execution.
PROVENANCE_SHA256='be0d5b910517f3703936786750967f7ff6d87de5456fa4e2ff849f602d77ff51'
DATA=[{'name': 'distinct_masses_small_shift', 'n': 1, 'Delta': '1/4', 'source_masses': ['1', '2'], 'source_rank_groups': [[['0', '1/4', [0]], ['1/4', '5/12', [2]]], [['0', '1/4', [1]], ['1/4', '5/12', [2]]]], 'P': [['0', '0', '2/3'], ['0', '0', '2/3'], ['0', '0', '0']], 'sigma': ['1/4', '1/2', '1/2'], 'input_I': ['1/8', '1/6', '1/8']}, {'name': 'same_mass_atom_and_selfloops', 'n': 1, 'Delta': '1/4', 'source_masses': ['1', '2'], 'source_rank_groups': [[['0', '4', [0, 1]], ['4', '29/6', [3]]], [['0', '5/2', [2]], ['5/2', '10/3', [3]]]], 'P': [['75/128', '45/128', '0', '1/16'], ['75/128', '45/128', '0', '1/16'], ['0', '0', '9/10', '1/10'], ['0', '0', '0', '7/10']], 'sigma': ['5/2', '3/2', '5', '5/2'], 'input_I': ['5/4', '1/2', '5/4', '1/2']}, {'name': 'two_dimensional_full_source', 'n': 2, 'Delta': '1/5', 'source_masses': ['1', '2', '3', '5'], 'source_rank_groups': [[['0', '5/16', [0]], ['5/16', '95/144', [4]], ['95/144', '127/144', [6]]], [['0', '5/16', [1]], ['5/16', '95/144', [4]], ['95/144', '127/144', [6]]], [['0', '5/16', [2]], ['5/16', '95/144', [5]], ['95/144', '127/144', [6]]], [['0', '5/16', [3]], ['5/16', '95/144', [5]], ['95/144', '127/144', [6]]]], 'P': [['9/25', '0', '0', '0', '16/25', '0', '0'], ['0', '9/25', '0', '0', '16/25', '0', '0'], ['0', '0', '9/25', '0', '0', '16/25', '0'], ['0', '0', '0', '9/25', '0', '16/25', '0'], ['0', '0', '0', '0', '53/125', '0', '72/125'], ['0', '0', '0', '0', '0', '53/125', '72/125'], ['0', '0', '0', '0', '0', '0', '1/10']], 'sigma': ['5/16', '5/8', '15/16', '25/16', '25/24', '25/9', '22/9'], 'input_I': ['5/32', '5/24', '15/64', '5/16', '25/144', '25/63', '11/36']}]
def ck(k,v):
 C[k]+=1
 assert v,k
def solve(A,b):
 M=[list(r)+[v] for r,v in zip(A,b)];n=len(b)
 for j in range(n):
  k=next(i for i in range(j,n) if M[i][j]);M[j],M[k]=M[k],M[j];a=M[j][j];M[j]=[v/a for v in M[j]]
  for i in range(n):
   if i!=j:
    a=M[i][j];M[i]=[v-a*w for v,w in zip(M[i],M[j])]
 return [r[-1] for r in M]
def check(model,profile):
 before=sum(C.values());P=[list(map(F,r)) for r in model['P']];sig=list(map(F,model['sigma']));I=list(map(F,model['input_I']));n=len(sig);D=F(model['Delta']);f=list(map(F,model['source_masses']));W=sum(f);X=sum(sig)
 nativeb=[1-sum(r) for r in P];rankcap=sum(f[z]*min(D,F(gs[-1][1])) for z,gs in enumerate(model['source_rank_groups']));B0=sum(sig[u]*nativeb[u] for u in range(n))
 ck('native_rankloss_exact_source_cap',B0==rankcap<=D*W)
 T=[[P[u][v]*(F(1) if profile=='native' else 1-F(u%3+1,8) if profile=='row_kill' else F(2+(u+v)%3,4)) for v in range(n)] for u in range(n)]
 for u in range(n):ck('tilted_kernel_only_adds_killing',all(0<=T[u][v]<=P[u][v] for v in range(n)))
 rowloss=[1-sum(r) for r in T];coldef=[sig[v]-sum(sig[u]*T[u][v] for u in range(n)) for v in range(n)]
 ck('tilted_submarkov_and_subinvariance',all(v>=0 for v in rowloss+coldef))
 G=solve([[F(int(i==j))-T[j][i] for j in range(n)] for i in range(n)],I);g=[G[u]/sig[u] for u in range(n)];i=[I[u]/sig[u] for u in range(n)]
 ck('positive_occupation_and_input_cap',all(v>=0 for v in G) and all(0<=v<=1 for v in i))
 for v in range(n):ck('exact_tilted_occupation_equation',G[v]==I[v]+sum(G[u]*T[u][v] for u in range(n)))
 J=sum(sig[u]*i[u]*g[u] for u in range(n));Dir=sum(sig[u]*T[u][v]*(g[u]-g[v])**2 for u in range(n) for v in range(n));Row=sum(sig[u]*rowloss[u]*g[u]**2 for u in range(n));Col=sum(coldef[v]*g[v]**2 for v in range(n))
 ck('three_term_energy_identity',2*J==Dir+Row+Col)
 ck('all_energy_dissipations_nonnegative',Dir>=0 and Row>=0 and Col>=0)
 beta=[nativeb[u]/(u+2) for u in range(n)]
 ck('selected_terminal_legality_nonfull',all(0<=beta[u]<=nativeb[u]<=rowloss[u] for u in range(n)) and any(beta[u]<nativeb[u] for u in range(n)))
 Bbeta=sum(sig[u]*beta[u] for u in range(n));Fbeta=sum(G[u]*beta[u] for u in range(n));selectedsquare=sum(sig[u]*beta[u]*g[u]**2 for u in range(n))
 ck('selected_terminal_cauchy_exact',Fbeta**2<=Bbeta*selectedsquare)
 ck('selected_terminal_square_under_row_dissipation',selectedsquare<=Row)
 ck('exact_selected_Bbeta_energy_bound',Fbeta**2<=2*Bbeta*J)
 ck('exact_native_B0_energy_bound',Fbeta**2<=2*B0*J)
 ck('DeltaW_energy_bound',Fbeta**2<=2*D*W*J)
 ck('tilted_termination_conserves_original_input',sum(G[u]*rowloss[u] for u in range(n))==sum(I))
 ck('selected_terminal_is_part_of_actual_terminal',Fbeta<=sum(I))
 young=[];L=J/X
 for eta in [F(1,16),F(1,4)]:
  sourcecoef=D*L/(2*eta);nativecoef=B0/W*L/(2*eta);selectedcoef=Bbeta/W*L/(2*eta)
  ck('Young_conditioned_Delta_fee',Fbeta<=eta*X+sourcecoef*W)
  ck('Young_conditioned_exact_B0_fee',Fbeta<=eta*X+nativecoef*W)
  ck('Young_conditioned_exact_Bbeta_fee',Fbeta<=eta*X+selectedcoef*W)
  young.append(dict(eta=str(eta),X_fee=str(eta*X),W_coefficient_Delta=str(sourcecoef),W_coefficient_exact_B0=str(nativecoef),W_coefficient_exact_Bbeta=str(selectedcoef),condition='Uses this finite model L=J/X; no uniform/polylog L bound certified.'))
 return dict(name=model['name'],kill_profile=profile,X_reference=str(X),input_total=str(sum(I)),occupation_total=str(sum(G)),J=str(J),J_over_X=str(L),two_J=str(2*J),Dirichlet=str(Dir),rowloss_g_squared=str(Row),column_deficit_g_squared=str(Col),beta=list(map(str,beta)),native_B0=str(B0),exact_source_rankcap=str(rankcap),Delta_W=str(D*W),selected_Bbeta=str(Bbeta),selected_terminal_Fbeta=str(Fbeta),Fbeta_squared=str(Fbeta**2),bound_2DeltaWJ=str(2*D*W*J),selected_fraction_of_terminal=str(Fbeta/sum(I)),unselected_terminal=str(sum(I)-Fbeta),Young_conditional=young,exact_checks=sum(C.values())-before)
def main():
 rows=[check(m,p) for m in DATA for p in ['native','row_kill','edge_kill']]
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),provenance_sha256=PROVENANCE_SHA256,models=rows,scope='Mechanism-only exact energy/terminal checks on embedded frozen actual cube/source-box finite receiver quadrature matrices. No old main execution, native full-history claim, continuum receiver dx, strict mass-growth horizon, or uniform energy budget. J/X explicitly measured, not bounded by polylog.')
 (BASE/'r358_energy_checks_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),models=[dict(name=r['name'],kill=r['kill_profile'],J_over_X=float(F(r['J_over_X'])),Fbeta=float(F(r['selected_terminal_Fbeta'])),checks=r['exact_checks']) for r in rows]),sort_keys=True))
if __name__=='__main__':main()
