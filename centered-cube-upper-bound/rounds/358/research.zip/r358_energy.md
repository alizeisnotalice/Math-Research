# R358 — Actual-flow energy with the native terminal source capacity

## Status and quantitative statement

This note proves an energy inequality for the actual R355 killed history process and its R357 selected normal-terminal remainder. It does not prove the outstanding geometric bound for the energy's injection-overlap quantity. No fee is added to the R357 ledger.

Let sigma(dw)=q_w dw on the actual finite receiver set E, and let I=i sigma be the original incoming witness measure after the R353 clock/inner restrictions. Let G be the sum of all arrival measures in the unchanged R355 killed process, before their current rich/source/ancestor/rank tests. Write G=g sigma. The existing column bound and finite strict-mass-growth horizon imply

    0<=i<=1, 0<=g<=N, G(E)<infinity.

These are ACTUAL arrivals. They are not conditioned on eventual survival into the low-face remainder. Set

    J_inj = integral i(w)g(w)sigma(dw).

Then the R357 low-face, direction-diffuse normal-terminal mass satisfies

    F_low^2 <= 2 Delta W J_inj,       Delta=2(1+sqrt(n)), W=int f.    (1)

More precisely the factor Delta W can be replaced by B0=int beta sigma, where beta is the actual selected-terminal probability per aggregated arrival defined below. The square inequality follows from a nonnegative three-part energy identity, not from deleting the generation count N. The current unconditional estimate J_inj<=N I(E)<=N X_q still leaves the old dimensional loss.

If a NEW geometric estimate J_inj<=C log^A(n+2) X_q is established for this actual entrance and process, then for every epsilon>0,

    F_low <= epsilon X_q + [C Delta/(2 epsilon)]log^A(n+2)W.      (2)

This is conditional. Neither finite calculations nor the algebra below certify that new estimate.

## 1. Frozen receiver/source kernel

Keep the original arbitrary nonnegative L1 source f, true centered cubes, and matching

    m_u=int f c_u=q_u R_u^n, 3lambda/4<=q_u<=lambda, a<=R_u<=b<=2a.

The genuine full-f posterior is pi_u(dz)=f(z)c_u(z)dz/m_u. The native noncyclic rank shift Q_z(u,dv), including equal-mass rank randomization, shifts a uniform source rank by Delta and drops top ranks. Set

    P(u,dv)=int pi_u(dz)Q_z(u,dv).

Its sourcewise column identity implies sigma P<=sigma. All surviving jumps increase matched mass strictly by K=exp(sqrt(n)). The R355 process only kills parts of this continuation law according to its real marks. Its old source, small endpoint, physical clock and initial-witness conditions are unchanged.

Let

    b(u)=int pi_u(dz)[1-Q_z(u,E)].

This is the probability of ordinary native rank termination if a full posterior draw is made without the additional kills. Exact atom-safe source-rank accounting yields

    int sigma(du)b(u)
      =int f(z) min(D(z),Delta)dz <=Delta W,                     (3)
    D(z)=int c_u(z) R_u^(-n)du.

Indeed the lost set in the source rank interval (0,D(z)) has length min(D(z),Delta). This holds with mass atoms. It is not a source density bound or an assumption that a final posterior remains unchanged after conditioning.

## 2. Aggregate edges while retaining the actual history process

Let T(du,dv) be the sum over all generations and histories of the real surviving continuation edges. Before each current source test the posterior is the genuine pi_u; all history/current tests only delete probability. Therefore, as joint measures,

    T(du,dv)<=G(du)P(u,dv).                                    (4)

Disintegration and Radon--Nikodym domination give a measurable effective kernel Kbar with

    T(du,dv)=G(du)Kbar(u,dv),  0<=Kbar(u,dv)<=P(u,dv).           (5)

On {g=0}, choose Kbar=0. The domination can be chosen sigma-almost everywhere: on {g>0}, G and sigma are equivalent, and on its complement the zero choice is dominated. Thus

    sigma Kbar<=sigma P<=sigma.                               (6)

This kernel is defined from the actual aggregate edge measure. It does not assert that the original history process was Markov in u alone, does not replace its pathwise law, and does not grant terminal geometric conditions to all arrivals. It is sufficient for the exact marginal balance

    G=I+G Kbar.                                                (7)

Every noninitial arrival corresponds to exactly one actual continuation edge, and no artificial horizon terminal mass is added. The existing finite native mass-growth horizon makes these sums finite.

## 3. Selected normal-terminal reward

Let Z_low(du) be the current-receiver marginal of the R357 remaining terminal measure, retaining both its source-direction gate and terminal face-count gate. These gates are positive restrictions of the ordinary native rank-terminal event, after the genuine posterior draw. At each actual pre-test history their probability is at most b(u). They are also disjoint from the current surviving continuation event. Hence

    Z_low<=bG,  Z_low<=G-T(du,E).

Write Z_low=beta G and choose beta=0 where g=0. The choices above give sigma-a.e.

    0<=beta<=b,   beta<=1-Kbar1.                               (8)

The future or globally determined source thresholds are used only as restrictions of the completed terminal event. No conditioned posterior or renormalized continuation law is inserted. The inequalities follow before integrating out that actual joint source event.

Consequently

    F_low=int beta g d sigma,
    B0=int beta d sigma<=int b d sigma<=Delta W.                (9)

No geometric property of F_low is inferred for G or Kbar. Those quantities include all arrivals in the unchanged R355 process, including paths later stopped or paid elsewhere.

## 4. The complete energy identity

Let d=sigma-sigma Kbar>=0. Since 0<=g<=N and sigma(E)=X_q<infinity, all following quantities are finite. Multiplying (7) by g and expanding a square gives the exact identity

    2 J_inj
      =int sigma(du)Kbar(u,dv)[g(u)-g(v)]^2
         +int sigma(du)[1-Kbar1(u)]g(u)^2
         +int d(dv)g(v)^2.                                   (10)

To check the expansion, the edge square contributes

    int sigma (Kbar1) g^2 +int (sigma Kbar)g^2
       -2 int sigma(du)g(u)Kbar(u,dv)g(v).

Adding the row-loss and column-defect terms replaces its first two terms by 2 int sigma g^2. By (7), the last integral equals int g d(G-I), so the result is 2 int g dI=2J_inj. All three terms on the right of (10) are nonnegative. No reversibility of Kbar is assumed.

Using (8),

    int beta g^2 d sigma
      <=int (1-Kbar1)g^2 d sigma <=2J_inj.                     (11)

Cauchy--Schwarz for the measure beta sigma now gives

    F_low^2 <=B0 int beta g^2 d sigma <=2 B0 J_inj
              <=2 Delta W J_inj.                             (12)

If B0=0 the selected mass is zero, so no division by zero is needed. This proves (1).

## 5. Exact remaining requirement and cost

Let L_n=log(n+2). If J_inj<=C L_n^A X_q is proved, (12) gives sqrt(2C Delta L_n^A W X_q). The identity

    sqrt(a x)<=epsilon x+a/(4epsilon)

for a,x>=0 proves (2). Delta=2(1+sqrt(n)), so its source fee is root order times the stated logarithms. Entrance factor two and exterior Lambda would multiply BOTH terms of (2); epsilon would have to be allocated within the complete existing absorption ledger.

Currently only J_inj<=N I(E)<=N X_q follows from g<=N. Inserting it into (12) gives a source price involving N Delta=O(n), not the target root order. The independent sourcewise rank column and the terminal sparse-face conditions have not yet removed this N factor from J_inj.

Thus J_inj is a specifically defined actual overlap of the initial injection with cumulative arrivals. It is not an arbitrary renamed remainder and is not inserted as a new paid quantity in the ledger. Its edge dissipation, stopping loss and reference column deficit are displayed exactly in (10), making possible comparison estimates testable. It remains a new geometric task to bound it without transferring terminal conditions to the entire arrival field or reusing old B_H square credit.
