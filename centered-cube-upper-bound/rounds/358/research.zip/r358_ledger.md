# 第358轮完整总账：本轮不新增付款

下文完整保留第357轮历史基账及356/357新增分支。本轮 F_low 与 F_sparse 同义；能量式的 J_inj 尚未获得对数预算，平滑核尚未迁移，因此任何项都不被移除，也不增加接收吸收系数。下文“本轮”措辞属于相应历史轮次，并非第358轮再次收费。

# 第357轮完整总账：高面数终端交通的联合付款

沿用351原入口和352已认证分支，不重新认证历史全局归约。\(W=\int f\)，\(X_q=\int_Eq\le X=\lambda|E|\)，\(W_{ex}=\int g_{ex}\)，\(\varepsilon=119/3072\)，\(\Lambda=128/119\)，\(s=1+\sqrt n\)。原入口不变：
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H+2B_H.
\]
取 \(A_n=1+n\log(b/a)\)，\(\sigma^n=\min(1,s/A_n)\)。第353轮从351的原标记核心重新准确分解：先取 \(r\ge\sigma R_{w_0}\)；再取其补集中 \(y\in\sigma Q_{w_0}\)；剩余R才应用352的首次回捕分解。因此
\[
G_{core}=G_{clock}+G_{inner}+B_{rec,R}+F_{edgefresh}.
\]
本轮从clock、inner之后的原R重新构造路径：先rich接收点停止，随后真实full-f抽源，依次测试inner-source、祖先回捕，最后原秩核正常终端/继续。设B_joint是前两种停止之和，则准确分解改为
\[
G_{core}=G_{clock}+G_{inner}+B_{joint}+B_{rec,new}+F_{shell}.
\]
旧原场、时钟、来源和初始见证均冻结。每代真实接收边缘不超过q，至多N代。令 \(\sigma_*^n=\min(1,s/(NA_n))\)，\(p_w=\pi_w(\sigma_*Q_w)\)，\(\theta=1/4\)。联合停止概率 \(1_{p_w\ge\theta}+p_w1_{p_w<\theta}\le p_w/\theta\)，真实中心容量给
\[
B_{joint}\le N\sigma_*^n A_nW/\theta\le4sW.
\]
因此新增来源费4sW，无新增Xq费。先前回捕证明在新被杀死过程仍给B_rec,new<=alpha_rec Xq，只计同一份上界，不另加原whole-R回捕费。clock和inner费用分别仍c_eff Xq与sWex。
原highpast必要条件失败则整流为零且c_eff=alpha_rec=0，否则
\[
c_{eff}=(\lambda/q_-)e^{-\sqrt n}\max(1,A_n/s)<\varepsilon/16,
\qquad\alpha_{rec}=N/(e^{\sqrt n}-1)<\varepsilon/16.
\]
其中N=max(1,ceil(log[(lambda/q_-)(b/a)^n]/sqrt(n)))，全部原外乘保留。

完整当前硬层账：
\[
B_H\le F_{shell}
+[(13/3)\varepsilon+\gamma_{eff}+\beta+\alpha_{rec}+c_{eff}]X_q
+[C_{\varepsilon,n}+8s]W+(D_{top,n}+C_{hit,n}+s)W_{ex}.
\]
\(\beta=\varepsilon/16\) 为350/351原级联费，不重复增加；\(\gamma_{eff}=0\) 或 \((8/3)e^{-\sqrt n}<\varepsilon/16\) 仍由原highpast条件决定。
\[
C_{\varepsilon,n}=\frac\lambda{q_-}\left[\frac{2+3\sqrt n+2e^{-\sqrt n}}\varepsilon+1+\sqrt n\right],\quad
D_{top,n}=s+\log(4/3),\quad
C_{hit,n}=2(\lambda/q_-)s(1+\log(1/\varepsilon)).
\]
相较353/354，仅新增4sW；其他来源费与接收费全部保留，接收吸收系数不变。入口2和外乘Lambda作用于全部新旧项。接收系数为
\[
13/36+2\Lambda(\beta+\gamma_{eff}+\alpha_{rec}+c_{eff}).
\]
只有历史CZ的1/256属于同一认证X账时，合计才是
\[
853/2304+2\Lambda(\gamma_{eff}+\alpha_{rec}+c_{eff})<889/2304.
\]
未分配吸收余额大于1415/2304，不是任何未付积分的估计。本轮新增来源费外乘后为8Lambda sW，不能漏乘入口2与Lambda。

剩余F_shell仍有原初始w0上的旧cross门。每个访问w的完整后验满足pi_w(Qw minus sigma_*Qw)>3/4；每次实际抽样source也在该shell中且避开全部先前祖先cube。前一结论来自rich停止，后一结论来自inner-source停止，不能相互替代。非空原分支有N<=sqrt(n)、An/s<=sqrt(n)，所以1-sigma_*<=-log(sigma_*)<=log(n)/n。此宽度不代表任意f边界质量小，反而余流的posterior大部分质量集中其中。原r及旧y的cross门只绑定w0，不迁移后来endpoint。跨路径终端累计来源预算仍未得到根阶估计。

独立未付槽全部保留：一般软层C_H-S_H、越阈I_H、hard合同外质量可比重尾；宽距离、低pe、极端尺度比及全部阈值补集；初始I_time、删除跳跃J_time、未来被删来源D_time；H选择、分层、来源、物理尺度、外积分、截断及极限费用。原ell末端原子和辅助秩核终止不替代历史时间原子。负重叠信用只允许使用一次。

本轮未证明B_H全体或一般一致弱型上界，也未证明只剩常数与对数打磨。


## 356新增分支（以上355基账原样保留供核对）

只将现有正常终端余流按同一个最终来源z的集合分成F_shell=F_dir+F_disp；不重启过程，不追加rich或回捕费。令L_n=log(n+2)，

    C_dir=N[(1−sigma_*)+(n(1−sigma_*)+sigma_*)log(b/a)]L_n

在原入口为空时取0；否则C_dir<=3sqrt(n)L_n²。新账为

    B_H <= F_disp + [(13/3)epsilon+gamma_eff+beta+alpha_rec+c_eff]X_q
           +[C_epsilon,n+8s+C_dir]W+(D_top+C_hit+s)W_ex.

来源费外乘完整为2Lambda C_dir W。X_q系数与355完全相同，在旧CZ属于同一X的明确条件下仍<889/2304。没有把原平方union条件的delta X_q另加到这份账里。其余所有未付槽、真实原时钟末端原子、入口两倍因子和历史外乘均沿上文保留。新余流方向分散是最终来源列的汇总性质，不能赋予每条路径或旧来源。


## 357新增分支（以上既有基账保留供核对）

现有F_disp不重建过程，按同一终端来源的H/L与原tuple面数分割：先整来源H>=L/4，再剩余来源上的高面tuple。两项合称F_multi，余为F_sparse。设

    m=1+ceil(8log(n+2)), t=1−sigma_*,
    C_m=P(Bin(n,t)>=m)+nlog(b/a)P(Bin(n−1,t)>=m−1),
    C_multi=4N C_m.

原入口为空则源费置0；非空时C_multi<=4sqrt(n)，更精确保留C_m<=A_n/(n+2)^4。新账

    B_H <= F_sparse+[(13/3)epsilon+gamma_eff+beta+alpha_rec+c_eff]X_q
           +[C_epsilon,n+8s+C_dir+C_multi]W
           +(D_top+C_hit+s)W_ex.

外乘完整新增2Lambda C_multi W。X_q系数不变；旧CZ属于同一X的明确条件下仍<889/2304。没有再收费355的rich/inner/recapture或356的direction-source事件；原平方信用也没有再次扣除。余流每个terminal tuple只含1到m−1个面，且每个正剩余source列L_i,new<4L_new/[3log(n+2)]，不把旧阈值无损迁移。

全部原未付槽、时钟端点、真实来源费、尺度与外积分保留；新的rank终端分割不结算任何原历史时间原子。


## 358冻结结论

最终账仍为第357轮显示的 B_H <= F_sparse + 接收系数 X_q + 来源费 W + 超额来源费 W_ex。R358的F_low²<=2Delta W J_inj已证，但J_inj<=C log^A(n+2) X_q未证。新平滑秩核的共同来源密度界已证，但其新见证与路径未进入此账。入口2、Lambda、全部其他未付槽及旧CZ是否属同一X的条件，全部不变。
