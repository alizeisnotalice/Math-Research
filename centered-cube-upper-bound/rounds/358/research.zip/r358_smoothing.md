# R358 — Averaging genuine rank shifts gives an absolutely continuous source edge

**Proved tool, not a completed ledger replacement.** Averaging the actual noncyclic rank shift over a window of width comparable to sqrt(n) preserves the strict mass gap and sourcewise capacity, while giving an explicit pointwise density bounded by the reciprocal window width. Mass atoms are included. The resulting actual edge measure is dominated by a common-source product measure. This is an upper energy comparison; it is not a lower bound for the original capture square or a root payment for the remaining flow.

## 1. Frozen actual field and rank kernels

Keep the original arbitrary nonnegative f in L1, finite actual Lebesgue receiver set E, and

    c_u(z)=1_(Q_(R_u)(u))(z),  m_u=integral f(z)c_u(z)dz=q_u R_u^n,
    q_-=3lambda/4<=q_u<=lambda,  a<=R_u<=b<=2a,
    xi_z(du)=q_uc_u(z)du/m_u=c_u(z)R_u^(-n)du,
    D(z)=xi_z(E),  sigma(du)=q_u du,
    pi_u(dz)=f(z)c_u(z)dz/m_u.

Every field uses the same full f. Set

    K=exp(sqrt(n)),  D0=1+sqrt(n)+log(4/3),
    Delta=2(1+sqrt(n)),  w=Delta-D0=1+sqrt(n)-log(4/3)>0.       (1)

The established actual-center mass-window bound is

    xi_z{t<=m<=Kt}<=D0,  t>0.                                (2)

Use the jointly measurable original randomized mass-rank kernel R_z(u,ds). For a positive mass atom it is uniform on the ENTIRE mass atom's rank interval; it does not separately order receivers of equal mass. For a nonatom it is the Dirac rank. The original disintegration is

    xi_z(du)R_z(u,ds)=1_(0,D(z))(s)ds H_z(s,du),              (3)

with H_z(s,.) a probability for almost every rank. The rank of u lies between the strict and inclusive cumulative xi_z masses at m_u. These are standard Borel measurable versions from the actual joint measure; exceptional dy-null source sections also have zero f(z)dz mass. Set the kernels to zero on noncapturing/irrelevant rows as needed.

For h in the OPEN interval (D0,Delta), define the complete noncyclic subkernel

    Q_z^h(u,dv)=integral R_z(u,ds)
                1_{0<s<D(z)-h} H_z(s+h,dv).                  (4)

Endpoint conventions in (4) affect only joint null sets. No wrapping or renormalization occurs. Define

    Qbar_z(u,dv)=(1/w) integral_(D0,Delta) Q_z^h(u,dv)dh.      (5)

Equations (4)-(5) also define a probability extension retaining the sampled shift h and both ranks, alongside every original source, time and history mark.

## 2. Explicit density and the mass-atom proof

For almost every actual capturing row,

    Qbar_z(u,dv)=k_z(u,v)xi_z(dv),
    k_z(u,v)=(1/w) integral R_z(u,ds) integral R_z(v,dt)
                           1_{D0<t-s<Delta}.                 (6)

In particular

    0<=k_z(u,v)<=1/w,
    k_z(u,v)+k_z(v,u)<=1/w.                                  (7)

To prove (6), integrate a nonnegative test function of v in (5), use t=s+h, and obtain

    (1/w) integral R_z(u,ds)
           integral_(s+D0,s+Delta)1_{0<t<D(z)}H_z(t,dv)dt.

Apply (3) in the (t,v) direction and then Tonelli. This is exactly (6). The calculation does not require any density of R_z(u,.) or a nonatomic mass pushforward. In (7), the first bound uses two probability kernels; for the second, interchange the two independent rank integrations in k(v,u). The events D0<t-s<Delta and D0<s-t<Delta are disjoint since D0>0.

Here the two rank integrations are the explicit randomized kernels from (3), not independent source/receiver posteriors assumed about the original traffic. Formula (6) is also a direct measurable version of the averaged kernel. It regularizes even a deterministic rank relation; it does not regularize or change f.

For two positive mass atoms with rank intervals (a,b], (c,d], put l_u=b-a, l_v=d-c. Then the exact block density is

    k_z(u,v)=[T(D0)-T(Delta)]/(w l_u l_v),
    T(h)=1/2[(d-a-h)_+^2-(d-b-h)_+^2
                         -(c-a-h)_+^2+(c-b-h)_+^2].          (8)

Indeed T(h) is the area of {(s,t) in (a,b]x(c,d]:t-s>h}. Receiver labels sharing one mass atom use its full interval in (8); their different xi masses are supplied by the factor xi_z(dv) in (6).

## 3. Strict gap, availability, columns and terminal cost

If a routed pair in (4) had m_v<=K m_u, rank support would imply

    h<=F_z(Km_u)-F_z^-(m_u)=xi_z{m_u<=m<=K m_u}<=D0,

contradicting h>D0. Thus every surviving averaged edge has c_u(z)c_v(z)=1 and m_v>K m_u. The closed-window cap and open shift interval retain strictness even at mass atoms.

Every original positive late row has xi_z{m>K m_u}>Delta: this is the original eta>0 consequence U_z(Km_u)>2B, B=(1+sqrt(n))/q_-, followed by xi_z>=q_-rho_z. Its ranks satisfy s<=F_z(Km_u)<D(z)-Delta. Consequently every shift in (D0,Delta) survives, and

    Qbar_z(u,E)=1 on the original positive late rows.         (9)

On arbitrary capturing rows it remains substochastic. For each shift,

    xi_z Q_z^h(dv)=integral_h^(D(z))H_z(t,dv)dt<=xi_z(dv).

Averaging proves xi_z Qbar_z<=xi_z. More exactly, with

    A(t)=min(1,max(0,(t-D0)/w)),

its incoming column fraction is

    xi_z Qbar_z(dv)=xi_z(dv) integral A(t)R_z(v,dt).           (10)

Its row survival probability is integral A(D(z)-s)R_z(u,ds). Hence the exact total terminal rank loss at source z is

    integral xi_z(du)[1-Qbar_z(u,E)]=F(D(z)),
    F(D)=(1/w) integral_(D0,Delta)min(D,h)dh
        = D,                                      0<=D<=D0,
        = D-(D-D0)^2/(2w),                         D0<D<Delta,
        = (D0+Delta)/2,                            D>=Delta. (11)

This includes D=0 and the two threshold equalities. In particular

    integral f(z)F(D(z))dz <=[(D0+Delta)/2] W <=Delta W.       (12)

The endpoint interval is averaged once; no additional fee is charged for the continuum of shifts. Since log(4/3)<1/3,

    w>sqrt(n)+2/3,  1/w<1/sqrt(n),
    (D0+Delta)/2=(3/2)(1+sqrt(n))+(1/2)log(4/3).             (13)

The first inequality follows, for example, from integrating 1/t<1 on (1,4/3). These are analytic bounds, not floating-point certificates.

## 4. Actual common-source edge and usable upper energy inequalities

Define the genuine resampled receiver transition

    Pbar(u,dv)=integral pi_u(dz)Qbar_z(u,dv).

The complete source-labelled edge measure is EXACTLY

    sigma(du)pi_u(dz)Qbar_z(u,dv)
       =f(z)dz xi_z(du)xi_z(dv)k_z(u,v).                     (14)

In particular sigma Pbar<=sigma, and (14) is bounded above by
w^(-1) f(z)dz xi_z(du)xi_z(dv), with its actual rank window in (6) and strict mass gap still retained. After source integration its density relative to du dv is at most

    [q_u q_v/(w m_u m_v)] integral f(z)c_u(z)c_v(z)dz.        (15)

This is actual source intersection mass, not intersection volume times an assumed density cap. The edge is directed; (14) does not assert reversibility.

For nonnegative measurable receiver functions A,B, Tonelli gives

    integral sigma(du)Pbar(u,dv) A(u)B(v)
      <=(1/w) integral f(z)[integral A xi_z][integral B xi_z]dz. (16)

For a single nonnegative A, symmetrizing its symmetric product and using the second bound in (7) improves this to

    integral sigma(du)Pbar(u,dv) A(u)A(v)
      <=(1/(2w)) integral f(z)[integral A xi_z]^2 dz.          (17)

For real A with finite displayed moments, the same argument gives

    integral sigma(du)Pbar(u,dv)[A(u)-A(v)]^2
      <=(1/w) integral f(z){D(z) integral A^2 xi_z
                                      -[integral A xi_z]^2}dz. (18)

Apply (7) to the symmetric squared difference and expand its product-measure integral to prove (18). These are upper comparisons with the ACTUAL common source. They do not bound the right-hand sides by root W: D, the amplitudes and their squared source integrals remain genuine quantities to estimate. In particular no arrived amplitude is reset to an original bound a<=lambda.

## 5. What has and has not been migrated

The tool can be inserted at the ORIGINAL positive late entrance because of (9), preserving its total and every old mark; sourcewise columns give the same newly constructed incoming bound kappa_bar<=q p^g<=q. The resulting witness joint measure is different from the archived fixed-shift one. It cannot simply be substituted into an already restricted residual inequality.

The following are migration checks required before any new full ledger is asserted:

* R350 diffuse-witness and R351 peeling proofs use the incoming q-cap and full-f posterior. Rebuild their exact marked split for the new incoming measure.
* R351 iteration uses subinvariance and the strict mass gap; those hold here. Its row terminal cost can use (11). Reconstruct the new path and preserve the finite horizon; do not claim its residual equals the archived path residual.
* R353 clock/inner estimates use clock independence, strict mass gap and sourcewise columns, all retained. Their old-time and source crossing masks must be applied to the new initial witness and repartition the original entrance.
* R355 rich/inner/recapture and R356–357 terminal geometric receipts use ordered stopping, per-generation q-caps, strict ancestral mass gaps and the actual terminal source joint domination. Verify these for the newly generated path in that order; previous terminal predicates and source direction-density ratios are flow-dependent and must be recomputed.

This note performs none of those complete ledger replacements. There is no claimed gain in the total unpaid flow, no free source occupation estimate, and no alteration of the original full J, ell, q, f or old source/history fees. Its bounded constructive output is (6)-(18).

## 6. Exact interval-block check

The embedded Fraction script checks the strip-area formula independently against exact piecewise-linear integration of translated interval overlap. It also checks repeated mass atoms, rows, columns, strict mass gaps, the averaged terminal formula and the source-square/Dirichlet upper comparisons. These finite rank-block fixtures test the kernel algebra; they are not realizations of the full original high-past/cube-history contract. That contract enters analytically through (2) and the original availability guard.

~~~python
from fractions import Fraction as F
from itertools import product
pos=lambda x:max(F(0),x)
counts={'strip':0,'row':0,'column':0,'gap':0,'terminal':0,'energy':0}
D0=F(5,4);Delta=F(5,2);width=Delta-D0;K=F(2)
fixtures=[([F(3,4),F(1),F(5,4),F(1,2),F(1),F(3,4)],False),
          ([F(1),F(5,4),F(3,4),F(1),F(1,2),F(5,4)],True),
          ([F(1,2)],False),([F(5,4)],True),
          ([F(5,4),F(5,4)],True),([F(1),F(1)],True)]
for groupweights,split in fixtures:
    labels=[];left=F(0)
    for i,g in enumerate(groupweights):
        parts=[g/F(3),2*g/F(3)] if split else [g]
        labels.extend((F(4)**i,p,left,left+g) for p in parts)
        left+=g
    D=left;N=len(labels)
    def tail(a,b,c,d,h):
        return (pos(d-a-h)**2-pos(d-b-h)**2-pos(c-a-h)**2+pos(c-b-h)**2)/2
    def rampint(a,b):
        return (pos(b-D0)**2-pos(a-D0)**2-pos(b-Delta)**2+pos(a-Delta)**2)/(2*width)
    Q=[[F(0)]*N for _ in range(N)]
    density=[[F(0)]*N for _ in range(N)]
    for u,v in product(range(N),repeat=2):
        mu,wu,a,b=labels[u];mv,wv,c,d=labels[v]
        area=tail(a,b,c,d,D0)-tail(a,b,c,d,Delta)
        knots=sorted(set([D0,Delta]+[h for h in [c-b,c-a,d-b,d-a] if D0<h<Delta]))
        overlap=lambda h:pos(min(b+h,d)-max(a+h,c))
        other=sum(((hi-lo)*(overlap(lo)+overlap(hi))/2 for lo,hi in zip(knots,knots[1:])),F(0))
        assert area==other and area>=0;counts['strip']+=1
        density[u][v]=area/(width*(b-a)*(d-c))
        Q[u][v]=wv*density[u][v]
        assert 0<=density[u][v]<=1/width
        if Q[u][v]:
            assert mv>K*mu;counts['gap']+=1
    for u,(mu,wu,a,b) in enumerate(labels):
        row=sum(Q[u]);expected=rampint(D-b,D-a)/(b-a)
        assert row==expected and 0<=row<=1
        upper=sum((v[1] for v in labels if v[0]>K*mu),F(0))
        if upper>Delta:assert row==1
        counts['row']+=1
    for v,(mv,wv,c,d) in enumerate(labels):
        col=sum((labels[u][1]*Q[u][v] for u in range(N)),F(0))
        assert col==wv*rampint(c,d)/(d-c) and 0<=col<=wv
        for u in range(N):assert density[u][v]+density[v][u]<=1/width
        counts['column']+=1
    lost=sum((labels[u][1]*(1-sum(Q[u])) for u in range(N)),F(0))
    target=D if D<=D0 else ((D0+Delta)/2 if D>=Delta else D-(D-D0)**2/(2*width))
    assert lost==target and target<=Delta;counts['terminal']+=1
    for seed in range(1,5):
        A=[F(1+(u+seed)%5,3) for u in range(N)]
        edge=sum((labels[u][1]*Q[u][v]*A[u]*A[v] for u,v in product(range(N),repeat=2)),F(0))
        sq=sum((labels[u][1]*A[u] for u in range(N)),F(0))**2
        assert edge<=sq/(2*width)
        energy=sum((labels[u][1]*Q[u][v]*(A[u]-A[v])**2 for u,v in product(range(N),repeat=2)),F(0))
        var=D*sum((labels[u][1]*A[u]**2 for u in range(N)),F(0))-sq
        assert energy<=var/width;counts['energy']+=2
print('PASS',counts,'total',sum(counts.values()))
~~~

Actual execution passed 401 recorded checks: 217 independent strip-area comparisons, 29 row formulas, 29 column formulas, 72 positive-edge strict-gap checks, 6 terminal formulas and 48 energy inequalities. The check script is entirely embedded above and has no external file dependency. Only `/tmp/r358_smoothing.md` was written; no Git or other-author files were modified.
