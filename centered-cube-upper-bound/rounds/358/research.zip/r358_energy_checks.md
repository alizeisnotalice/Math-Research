R358 independent finite energy / terminal-interface checks

Frozen fresh local Python processes returned PASS 255 exact Fraction assertions. The three inherited actual-cube fixtures each have native, row-killed and edge-killed profiles: 25 checks per initial profile, 27 per same-mass/self-loop profile, 33 per 2D profile. These counts are new energy checks only; they do not count or rerun the earlier geometry/rank-reset exploration.

Reproduce:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r358_energy_checks.py
```

The self-contained script embeds the minimal exact mechanism inputs from frozen r358_numeric_result.json, SHA256 be0d5b910517f3703936786750967f7ff6d87de5456fa4e2ff849f602d77ff51. It executes no old main and has no runtime dependency on old temporary files. These inputs come from the previously verified actual positive-L1 source-box/cube geometries; receiver weights remain finite quadrature, not actual receiver dx. Source masses, actual m/q, rank groups and original diagnostic I are preserved.

For each profile, sigma=q dx, I<=sigma, and Ptilde<=P. Native uses P unchanged; row-kill multiplies row u by 1-(u mod 3+1)/8; edge-kill multiplies edge (u,v) by [2+(u+v mod 3)]/4. Every entry comparison, substochastic row and subinvariant sigma-column condition is checked exactly. G=I+G Ptilde is solved by rational Gaussian elimination. Let i=I/sigma, g=G/sigma and J=sum sigma i g. The exact identity is

2J = sum_uv sigma_u Ptilde_uv (g_u-g_v)^2
    +sum_u sigma_u(1-sum_v Ptilde_uv)g_u^2
    +sum_v [sigma_v-sum_u sigma_u Ptilde_uv]g_v^2.

All three terms are nonnegative and stored separately. The column-deficit term is essential for these noninvariant killed kernels; it is not silently discarded as an equality.

| Fixture | Native J/X | Row-kill J/X | Edge-kill J/X |
|---|---:|---:|---:|
| Initial distinct masses | 19/120 = 0.158333 | 0.150694 | 0.147222 |
| Same-mass/self-loop | 1135/736 = 1.542120 | 0.414071 | 0.300842 |
| Actual 2D source | 0.109038 | 0.078877 | 0.086482 |

Here X=sum sigma is the reference receiver cost, not the input total. The result records both. These finite measured values do not prove a uniform or polylogarithmic J/X estimate. For the native self-loop stress, the Dirichlet, row-loss and column-deficit shares of 2J are approximately 10.60%,46.05%,43.35%. At row kill the shares are approximately 3.03%,46.74%,50.23%; omitting the third term would materially change the account.

Selected terminal. Native rank loss is b=1-P1. The exact original source-rank capacity is

B0=sum sigma b=sum_z f_z min(A_z,Delta)<=Delta W,

where A_z is the full xi_z rank mass and W=sum f_z. This is recomputed from the embedded source rank groups. In these three fixtures all rank masses exceed Delta, so B0=Delta W (3/4,3/4,11/5). No improvement from a smaller actual B0 is claimed. The selected terminal beta_u=b_u/(u+2) is nonnegative, strictly smaller than full b somewhere, and satisfies beta<=b<=1-Ptilde1. It is a diagnostic selected terminal, not a relabeling of the entire original core.

With Bbeta=sum sigma beta and Fbeta=sum G beta, the program verifies the stronger chain

Fbeta^2 <= Bbeta sum sigma beta g^2
        <= Bbeta RowLossEnergy <=2 Bbeta J
        <=2 B0 J <=2 Delta W J.

Original input mass equals the full killed-terminal mass sum G(1-Ptilde1). Fbeta is only a selected part; unselected terminal mass is output explicitly. The selected fraction of input in the native initial/tie/2D fixtures is respectively 0.286111,0.2,0.125. Killing reduces selected occupation in the declared variants; this does not mean the killed complement is free traffic.

Conditional Young fee. For eta=1/16 and 1/4, use only the MEASURED finite L=J/X. The output checks

Fbeta <= eta X + [Delta L/(2eta)]W,

and the sharper replacements of Delta by B0/W and Bbeta/W. Each result lists its X fee and W coefficient. This is a conditional algebraic fee: a useful general bound would still require an independently proved bound on J/X for the actual historical aggregate. No such bound is supplied by these fixtures, the energy identity, or per-generation subinvariance.

Scope. These are finite exact mechanism checks on frozen actual-source/cube quadrature inputs, including equal-mass atom-safe rank blocks and self-loops. The diagnostic Delta values are not original hard-entry parameters; no native finite-horizon or strict mass-growth realization is asserted. The exact infinite occupation solves are distinct from an original finite native path aggregate. Continuous receiver dx, full historical input admissibility, general energy control, polylog budget, and root payment remain outside the numerical certificate.
