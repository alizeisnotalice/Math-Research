#!/usr/bin/env python3
"""Atom-safe rank shift on actual cube/source-box incidence; finite receiver quadrature."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json
BASE=Path(__file__).resolve().parent;C=Counter()
def ck(k,v):
 C[k]+=1
 assert v,k
def solve(A,b):
 M=[list(a)+[z] for a,z in zip(A,b)];n=len(b)
 for j in range(n):
  k=next(i for i in range(j,n) if M[i][j]);M[k],M[j]=M[j],M[k];p=M[j][j];M[j]=[v/p for v in M[j]]
  for i in range(n):
   if i!=j:
    p=M[i][j];M[i]=[a-p*z for a,z in zip(M[i],M[j])]
 return [r[-1] for r in M]
def model(stage,name,n,centres,f,receivers,Delta):
 before=sum(C.values());h=F(1,100);nr=len(receivers);nz=len(f);inc=[];m=[];sig=[]
 for x,R,dx in receivers:
  cc=[]
  for y in centres:
   inside=all(abs(a-b)+h<=R/2 for a,b in zip(x,y));outside=any(abs(a-b)-h>=R/2 for a,b in zip(x,y));ck('actual_whole_positive_source_box_geometry',inside or outside);cc.append(int(inside))
  mass=sum(a*b for a,b in zip(f,cc));ck('positive_actual_mass_and_receiver_weight',mass>0 and dx>0);inc.append(cc);m.append(mass);sig.append(mass/R**n*dx)
 pi=[[f[z]*inc[u][z]/m[u] for z in range(nz)] for u in range(nr)]
 xi=[[F(inc[u][z])*receivers[u][2]/receivers[u][1]**n for u in range(nr)] for z in range(nz)]
 groups=[];block=[{} for z in range(nz)];Q=[[[F(0) for v in range(nr)] for u in range(nr)] for z in range(nz)];edges=[];ties=0
 for z in range(nz):
  gs=[];left=F(0)
  for mass in sorted(set(m[u] for u in range(nr) if inc[u][z])):
   ids=[u for u in range(nr) if inc[u][z] and m[u]==mass];width=sum(xi[z][u] for u in ids);right=left+width;gs.append((left,right,ids));ties+=len(ids)>1
   for u in ids:block[z][u]=(left,right)
   left=right
  groups.append(gs)
  for u in range(nr):
   if not inc[u][z]:continue
   a,b=block[z][u];U=b-a
   for v in range(nr):
    if not inc[v][z]:continue
    c,d=block[z][v];V=d-c;lo=max(a,c-Delta);hi=min(b,d-Delta)
    if hi>lo:
     q=(hi-lo)/U*xi[z][v]/V;Q[z][u][v]=q;edges.append((u,z,v,q,(lo+hi)/2));ck('same_source_true_rank_increment',((lo+hi)/2+Delta)-(lo+hi)/2==Delta)
   ck('source_rank_subrow_and_noncyclic',sum(Q[z][u])<=1)
  for v in range(nr):
   if not inc[v][z]:continue
   c,d=block[z][v];expected=xi[z][v]*max(F(0),d-max(c,Delta))/(d-c)
   ck('source_rank_target_truncated_density',sum(xi[z][u]*Q[z][u][v] for u in range(nr))==expected)
  # All same-mass source-capturing receivers use the entire group's uniform rank block.
  for a,b,ids in gs:
   for u in ids:ck('tie_atom_uses_common_uniform_block',block[z][u]==(a,b))
   if len(ids)>1:ck('tie_uniform_rank_kernel_rows_agree',all(Q[z][u]==Q[z][ids[0]] for u in ids))
 P=[[sum(pi[u][z]*Q[z][u][v] for z in range(nz)) for v in range(nr)] for u in range(nr)]
 for u in range(nr):
  ck('no_lower_matched_mass_transition',all(P[u][v]==0 for v in range(nr) if m[v]<m[u]))
  ck('same_mass_block_strict_subrow_transience',sum(P[u][v] for v in range(nr) if m[v]==m[u])<1)
 for v in range(nr):ck('matched_reference_subinvariance',sum(sig[u]*P[u][v] for u in range(nr))<=sig[v])
 V=[sum(pi[u][z]*sum(block[z][u])/2 for z in range(nz) if inc[u][z]) for u in range(nr)]
 for u in range(nr):ck('untruncated_source_rank_mean_reset_zero',sum(pi[u][z]*(V[u]-sum(block[z][u])/2) for z in range(nz) if inc[u][z])==0)
 I=[sig[u]/(u+2) for u in range(nr)];G=solve([[F(int(i==j))-P[j][i] for j in range(nr)] for i in range(nr)],I)
 ck('exact_occupation_positive',all(g>=0 for g in G))
 for v in range(nr):ck('actual_occupation_resolvent',G[v]==I[v]+sum(G[u]*P[u][v] for u in range(nr)))
 lost=[1-sum(P[u]) for u in range(nr)];ck('occupation_terminal_mass_conservation',sum(G[u]*lost[u] for u in range(nr))==sum(I))
 gen=I[:]
 for j in range(10):
  ck('finite_generation_cap_not_occupation_cap',all(gen[u]<=sig[u] for u in range(nr)));gen=[sum(gen[u]*P[u][v] for u in range(nr)) for v in range(nr)]
 def reset(weights):
  # Actual target point rank, not target block mean, appears in this reset.
  direct=sum((weights[u]*pi[u][z]*q*(V[v]-s-Delta) for u,z,v,q,s in edges),F(0));target=F(0)
  g=[weights[u]/sig[u] for u in range(nr)]
  for z,gs in enumerate(groups):
   for v in range(nr):
    if not inc[v][z]:continue
    a,b=block[z][v];cuts=sorted(set([a,b]+[x for x in [Delta]+[e+Delta for l,r,ids in gs for e in [l,r]] if a<x<b]))
    for lo,hi in zip(cuts,cuts[1:]):
     s=(lo+hi)/2
     if s<=Delta:continue
     sourcegroup=next(((l,r,ids) for l,r,ids in gs if l<s-Delta<r),None)
     if sourcegroup is None:continue
     l,r,ids=sourcegroup;B=sum(xi[z][u]*g[u] for u in ids)/(r-l)
     target+=sig[v]*pi[v][z]*(hi-lo)/(b-a)*(V[v]-s)*B
  ck('actual_reset_target_B_matches_joint_edges',target==direct)
  return direct
 ref=reset(sig);input_reset=reset(I);occupation_reset=reset(G);covsum=F(0)
 for v in range(nr):
  prob=moment=F(0)
  for z in range(nz):
   if not inc[v][z]:continue
   a,b=block[z][v];lo=max(a,Delta)
   if lo<b:prob+=pi[v][z]*(b-lo)/(b-a);moment+=pi[v][z]*(b-lo)/(b-a)*(lo+b)/2
  cov=moment-V[v]*prob;ck('reference_truncation_covariance_nonnegative',cov>=0);covsum+=sig[v]*cov
 ck('complete_reference_reset_is_negative_covariance',ref==-covsum<=0)
 # Centering at full reference is a linear difference identity, not an assertion R_g=0.
 diff=reset([G[u]-sig[u] for u in range(nr)])
 ck('actual_occupation_reference_difference_identity',occupation_reset==ref+diff)
 # The exact point-rank increment remains Delta even though receiver potential drift need not equal it.
 edgechange=sum((G[u]*pi[u][z]*q*(V[v]-V[u]) for u,z,v,q,s in edges),F(0))
 resetpart=sum((G[u]*pi[u][z]*q*(V[v]-s-Delta) for u,z,v,q,s in edges),F(0))
 startpart=sum((G[u]*pi[u][z]*q*(s-V[u]) for u,z,v,q,s in edges),F(0));shiftpart=Delta*sum(G[u]*sum(P[u]) for u in range(nr))
 ck('rank_shift_plus_resampling_reset_potential_decomposition',edgechange==resetpart+shiftpart+startpart)
 ck('occupation_receiver_potential_balance',edgechange==sum(G[u]*lost[u]*V[u] for u in range(nr))-sum(I[u]*V[u] for u in range(nr)))
 return dict(stage=stage,name=name,n=n,source_centres=[[str(v) for v in x] for x in centres],source_box_side=str(2*h),source_masses=list(map(str,f)),receivers=[dict(centre=list(map(str,x)),R=str(R),quadrature_dx=str(dx),m=str(m[u]),q=str(m[u]/R**n)) for u,(x,R,dx) in enumerate(receivers)],Delta=str(Delta),tie_source_mass_groups=ties,source_rank_groups=[[[str(a),str(b),ids] for a,b,ids in gs] for gs in groups],P=[[str(v) for v in row] for row in P],sigma=list(map(str,sig)),input_I=list(map(str,I)),occupation_G=list(map(str,G)),input_total=str(sum(I)),occupation_total=str(sum(G)),reference_total=str(sum(sig)),occupation_exceeds_reference_total=sum(G)>sum(sig),potential_V=list(map(str,V)),reference_reset=str(ref),input_reset=str(input_reset),occupation_reset=str(occupation_reset),occupation_reference_reset_difference=str(diff),rank_shift_contribution=str(shiftpart),start_conditioning_contribution=str(startpart),receiver_potential_edge_change=str(edgechange),exact_checks=sum(C.values())-before,scope='Actual compact positive-L1 source boxes and actual cube incidence. Receiver dx are finite quadrature weights, NOT continuum receiver measure. Diagnostic Delta, not original 2(1+sqrt(n)); no native hard入口/highpast/massgrowth or original marked I realization.')
def main():
 cases=[]
 cs=[(F(0),),(F(1),)]
 cases.append(model('initial','distinct_masses_small_shift',1,cs,[F(1),F(2)],[((F(0),),F(2,5),F(1,10)),((F(1),),F(2,5),F(1,10)),((F(1,2),),F(6,5),F(1,5))],F(1,4)))
 cases.append(model('stress','same_mass_atom_and_selfloops',1,cs,[F(1),F(2)],[((F(0),),F(2,5),F(1)),((F(1,100),),F(1,2),F(3,4)),((F(1),),F(2,5),F(1)),((F(1,2),),F(6,5),F(1))],F(1,4)))
 centres=[(F(0),F(0)),(F(1),F(0)),(F(0),F(1)),(F(1),F(1))];rs=[(z,F(2,5),F(1,20)) for z in centres]+[((F(1,2),F(0)),F(6,5),F(1,2)),((F(1,2),F(1)),F(6,5),F(1,2)),((F(1,2),F(1,2)),F(3,2),F(1,2))]
 cases.append(model('expanded','two_dimensional_full_source',2,centres,list(map(F,[1,2,3,5])),rs,F(1,5)))
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),models=cases,scope='Atom-safe source rank reset diagnostics on actual cube-generated finite quadrature. Full reference reset is negative covariance after truncation, not zero. Occupation exact rational solve, not a per-generation capacity claim for its sum. No general payment theorem.')
 (BASE/'r358_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),models=[{k:x[k] for k in ['name','exact_checks','tie_source_mass_groups','input_total','occupation_total','reference_total','reference_reset','occupation_reset']} for x in cases]),sort_keys=True))
if __name__=='__main__':main()
