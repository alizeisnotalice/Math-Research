# R358 — Unique receiver centers and the full cost of endpoint packing

## Result and scope

This note screens one proposed way to pay the entire R357 remainder F_low: pack each retained path's entrance center near its terminal receiver and charge actual Lebesgue center volume once. The unique receiver field R(w) does remove a generation factor from this particular entrance-volume charge. The remaining geometric cost is explicit: the available universal path envelope has dilation

    D_n = 1 + 2(λ/q_-)^(1/n)/(exp(1/√n)−1).

Thus a root-cube packing with source overlap M would give

    F_low ≤ (λ/q_-) M D_n^n W,

not a root bound. The assertion is conditional on the specified packing; neither its existence with favorable overlap nor a substantially smaller entrance envelope is proved. A sharper anisotropic formulation below identifies the exact weighted overlap that would suffice. This is a priced geometric reduction and limitation, not a new paid branch. The R357 ledger is unchanged.

## 1. Frozen marked flow

Keep the actual full-f data

    Q_w = w + [−R_w/2,R_w/2]^n,
    m_w = ∫_{Q_w} f = q_w R_w^n,
    q_- = 3λ/4 ≤ q_w ≤ λ,   a ≤ R_w ≤ b ≤ 2a,
    W = ∫ f,   K = exp(√n).

A retained path has receivers w_0,...,w_J, with at most N visits. Each genuine continuation uses the native noncyclic rank kernel with its strict shift Δ = 2(1+√n). Its actual sampled source z_j satisfies

    z_j ∈ Q_{w_j} ∩ Q_{w_{j+1}},
    m_{w_{j+1}} > K m_{w_j}.                         (1)

All old original source/receiver/physical-clock marks, ηΩ, full J, and the initial crossing condition are retained. The R355 actual-source shell and ancestor-fresh conditions are retained at every visited receiver. R357's terminal tuple (z,w_J) has

    1 ≤ #{i: |z_i−(w_J)_i| > σ_* R_{w_J}/2} < m,
    m = 1+ceil(8log(n+2)),

and its common-source face columns obey L_i/L < 4/[3log(n+2)]. These are qualifications of the terminal measure; they are not imposed on earlier sampled sources.

Let P_low denote this full marked terminal path measure. Its mass is F_low. Projection onto the initial witness w_0 has a density bounded by q_{w_0} with respect to actual dw_0:

    (w_0)_# P_low ≤ q_w dw.                         (2)

Indeed, the R350 initial arrival has density κ_0≤q. Subsequent operations are positive restrictions and subprobability kernels; their terminal mass for each fixed entrance is at most its initial mass. Multiple possible futures do not duplicate that mass. Formula (2) uses the entrance projection, not a sum of per-generation marginals.

## 2. Endpoint mass growth controls radius ratios without repeated q losses

Put c=(λ/q_-)^(1/n) and r=exp(−1/√n). For i<J, (1) gives

    (R_{w_i}/R_{w_J})^n
      = (m_{w_i}/m_{w_J})(q_{w_J}/q_{w_i})
      < (λ/q_-) K^{−(J−i)},

hence

    R_{w_i} < c r^{J−i} R_{w_J}.                    (3)

The factor λ/q_- occurs only once, through the endpoint density ratio. Multiplying a fresh factor λ/q_- for every transition would give an unnecessary loss. This calculation uses the same full-f masses as the rank kernel.

For each coordinate, common capture in (1) gives the actual center displacement bound

    |(w_{j+1})_k−(w_j)_k| ≤ (R_{w_j}+R_{w_{j+1}})/2. (4)

If x∈Q_{w_i}, the triangle inequality and (4) imply

    ||x−w_J||∞
      ≤ R_{w_i}/2 + Σ_{j=i}^{J−1}(R_{w_j}+R_{w_{j+1}})/2
      = R_{w_J}/2 + Σ_{j=i}^{J−1}R_{w_j}
      < R_{w_J}[1/2+c Σ_{h=1}^{J−i}r^h].            (5)

Consequently every ancestor cube lies in the same terminal-centered envelope:

    Q_{w_i} ⊂ D_n Q_{w_J}.                          (6)

If a finite length is to be retained, replace D_n by

    D_{n,N}=1+2c Σ_{h=1}^{N−1}r^h ≤ D_n.

The case J=0 requires no transition: Q_{w_0}=Q_{w_J}. This proof permits arbitrary coordinate changes of direction and uses no disjointness between paths.

The exact coordinate form, before the triangle inequality, is

    (w_i−w_J)_k = −Σ_{j=i}^{J−1}(w_{j+1}−w_j)_k.     (7)

Any improvement based on cancellation or few active coordinates must control these sums on the same retained path measure. Neither (1) nor the terminal face-count condition deletes terms from (7).

## 3. Actual receiver-volume packet lemma

Suppose the marked path measure is partitioned into countably many measurable packets P_ν. Suppose for each packet there is an actual receiver b_ν whose cube B_ν=Q_{b_ν} contains every terminal cube of that packet, up to path-null exceptions. No such selection is asserted to exist with good overlap.

For nested axis-parallel cubes Q⊂B and D≥1 one has DQ⊂DB. In each coordinate, the center separation is at most (R_B−R_Q)/2, and

    (R_B−R_Q)/2 + D R_Q/2 ≤ D R_B/2.

Together with (6), this puts every entrance center of packet ν in D_n B_ν. Projection (2) then proves the exact one-packet estimate

    ||P_ν|| ≤ ∫_{D_n B_ν∩E} q_w dw
             ≤ λ D_n^n R_{b_ν}^n
             = (λ/q_{b_ν}) D_n^n m_{b_ν}
             ≤ (λ/q_-) D_n^n m_{b_ν}.              (8)

This is a charge for whole paths, not for their individual visits. It contains no extra N factor. It is valid even if different paths visit the same receiver center at different generations.

For the total packet sum, the source cost is equally explicit:

    Σ_ν m_{b_ν} = ∫ f(z) Σ_ν 1_{B_ν}(z) dz.         (9)

Thus if the actual full-f overlap obeys

    Σ_ν 1_{B_ν}(z) ≤ M  for f(z)dz-almost every z,

then (8)–(9) give

    F_low ≤ (λ/q_-) D_n^n M W.                     (10)

There is no assumption that small boundary volume controls f-mass. All source mass in (9) is real full-f mass. The passage from countably many packets uses Tonelli; it does not require finite overlap unless the final finite bound is sought.

## 4. Anisotropic cost and the missing geometric assertion

The same proof has an exact version that does not commit to an isotropic dilation. Suppose packet ν has entrance centers in a measurable set V_ν. Then

    ||P_ν|| ≤ ∫_{V_ν∩E} q_w dw ≤ λ|V_ν|.            (11)

If V_ν lies in a box with side lengths ℓ_{ν,1}R_{b_ν},...,ℓ_{ν,n}R_{b_ν}, define d_ν=∏_i ℓ_{ν,i}. Then

    F_low ≤ (λ/q_-) Σ_ν d_ν m_{b_ν}
           = (λ/q_-) ∫ f(z) Σ_ν d_ν1_{B_ν}(z) dz.   (12)

A sufficient genuinely root-scale packing assertion would therefore be the existence of these packets, roots and entrance boxes with

    ∫ f(z) Σ_ν d_ν1_{B_ν}(z) dz
      ≤ C_δ √n log^A(n+2) W,                       (13)

after removing a submeasure of mass at most δX_q. The discarded submeasure and its fee are part of (13)'s proposed conclusion, not available for free. If (13) were proved for the actual remaining marked flow, (12) would pay all F_low by δX_q plus a root-polylog source fee.

The available conclusion (6) supplies d_ν=D_n^n. For n≥1, with x=√n, elementary convexity gives

    1/x ≤ exp(1/x)−1 ≤ (e−1)/x,
    1 ≤ c ≤ 4/3,

so the certified isotropic envelope has

    1+2x/(e−1) ≤ D_n ≤ 1+(8/3)x.                    (14)

This identifies a large cost in this proof, not a lower bound on the optimal cost of the actual problem. With bounded root overlap, a root-polylog version of (12) would instead require aggregate padding satisfying approximately

    Σ_i log ℓ_{ν,i} ≤ (1/2)log n + O(loglog(n+2)),

or a comparably small f-weighted average. A statement that only O(log n) coordinates need padding still requires pricing the product of their side-length factors and the choice of the packet/coordinate sets. It is not an automatic consequence of terminal low face count.

In particular the terminal condition compares z with w_J. Earlier displacement compares w_j with w_{j+1}, through the different sampled source z_j. The needed information is joint in

    (earlier receiver, continuation source, later receiver, terminal source).

The already proved direction dispersion averages terminal (z,w_J) tuples; it supplies no estimate for the earlier coordinate sums (7). Ancestor freshness says the terminal source is outside ancestor cubes, and does not replace it by a common source of all ancestors. Thus importing the terminal O(log n) face set into every earlier transition would change the original marked condition.

The unique-center observation is nonetheless correctly accounted for by (8): it removes artificial repeated entrance volume. What remains to prove is a joint spatial packet assertion such as (13), with controlled padding and source overlap, rather than another per-generation center cap. Neither the existing native rank contraction nor the terminal face restrictions currently prove (13).

## 5. Checks and accounting status

The following code was actually run with Python's standard-library Fraction arithmetic. It passed 6,244 exact scalar checks: all sign choices for seven finite path lengths and four rational radius ratios; endpoint density-ratio identities; and anisotropic volume/source conversion. These are algebra checks for (3), (5) and (12), not realizations of the full-f/high-past path process. The proof above is independent of the finite checks.

```python
from fractions import Fraction as F
from itertools import product
import math
checks=0
for J in range(1,8):
    for r in [F(1,3),F(1,2),F(2,3),F(3,4)]:
        R=[r**(J-i) for i in range(J+1)]
        D=1+2*r/(1-r)
        for signs in product([-1,1],repeat=J):
            centers=[F(0)]
            for i,sgn in enumerate(signs):
                centers.append(centers[-1]+sgn*(R[i]+R[i+1])/2)
            for i in range(J):
                exact=R[-1]/2+sum(R[i:J])
                assert abs(centers[i]-centers[-1])+R[i]/2<=exact<=D/2
                checks+=1
        for qb in [F(3,4),F(1)]:
            mb=qb*R[-1]**3
            ell=[F(3,2),F(4,3),F(5,4)]
            volume=R[-1]**3*math.prod(ell)
            assert volume==math.prod(ell)*mb/qb
            checks+=1
for m0,m1,q0,q1 in product([F(1,2),F(3),F(7)],
                           [F(2),F(5),F(9)],
                           [F(3,4),F(1)],[F(3,4),F(1)]):
    assert (m0/q0)/(m1/q1)==(m0/m1)*(q1/q0)
    checks+=1
print('Exact Fraction scalar checks:',checks,'PASS')
for n in [128,1024,4096]:
    c=(4/3)**(1/n)
    D=1+2*c/math.expm1(1/math.sqrt(n))
    print('Float diagnostic n=%d D=%.9g log(D^n)=%.9g'
          %(n,D,n*math.log(D)))
```

Actual floating diagnostics (not exact certificates):

| n | D_n | log(D_n^n) |
|---:|---:|---:|
|128|22.6908422|399.611061|
|1024|64.0229114|4259.06279|
|4096|128.011524|19874.2847|

No new X_q or W payment is added to the R357 ledger. No part of F_low is removed by this note. The complete general target remains unproved; the bounded outcome is the actual-center packet lemma, its explicit dilation/source-overlap cost, and the precise joint packing assertion still needed.
