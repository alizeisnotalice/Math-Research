# R151 receiver积分初探：独立核验通过，积分误差未认证

冻结单I1(n4)质量(12,8,8)、固定lambda与真实接收x，m4/m8两个预声明网格合计8376个对称评价点。独立核验通过：全部几何/重叠权与aggregate，另4个既有点的真实E3/mp70控制。结果为有限确定性求积诊断，不是严格积分上下界、FULL或维数阶证据。

## 采用文件与独立程序

- receiver_probe.json SHA256 `6bfc604946efcb7461b354e1d1f5347319b519548e1c4448a35643b5f911b731`。
- receiver_probe.py SHA256 `24ef92aaeaca8b6c110e899f61c2b5a5dfe558f6235534c5c1d144bab8e1bba0`。
- receiver_numeric_plan.md SHA256 `bcb76cb948645b3dbe9099e95d88a49aedd269a626f52fecb45024ea43773c69`。
- receiver_verify.py SHA256 `4b36bea641214646cdf961a2d2dbd11a9975b75a7020413ef743e4a737835893`。

独立verifier不import producer，标准库完成全部有理几何与存储积分重求和，mpmath完成4个固定控制。producer修正过输出m误用x0Q的问题及mp70控制中B_FA/eg浮点输入问题；这两项不改变已报A/B，但本审核只采用修正后的上述版本。

明细位于仓库外 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json`，SHA256 `6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9`。紧凑摘要内保存路径/SHA；明细可由producer重建，不要求重复归档16MB数据。

## 实际核验

1. 从R142 nu_exact按(12,8,8)重新归一化，核对保存nu及从mp70 x0核容量给出的精确lambda。输入SHA为R136 `1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de`、R142 `c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55`。
2. 全8376条有理坐标、source盒、index排序、orbit、闭盒支持mask、k与nu加权hardmass精确核验；原权精确为orbit/(m^4 k)。分别重算A/B/p质量/dx体积及门前后aggregate、2N倍数和条件平均。
3. corrected权采用**不同于producer面切分**的精确子集证明：对当前来源cell，k=1+M，

       ∫cell 1/k dx = Σ_{S⊂其他5盒} (−1)^|S|/(|S|+1) · Vol(cell∩∩_{i∈S}C_i)。

   对全8376个cell逐条Fraction核对corrected权及orbit，再独立重算corrected A/B/M/V。两档corrected总权均严格等于3698/625；未新增核评价。
4. 固定复核点是x0、m8最高B_post integrand点(-1,1,1,1)/16、m8最高I点(7,-3,7,5)/16及首m4点(-47/40)^4。独立真实E3乘积、q/alpha/rho/good、当前Q(x)形成的m、原FA完整两score I及动态门复核通过；非零I的float相对差不超过1.98e-16。x0 I≈0.08733319051928236，2NI≈1.92133019142421，恢复R150控制。固定lambda在x0上界的舍入near不当作严格分类证书。

全部网格点near标签为0、invalid为0；复核点不认证未复核所有核值或真实积分误差。

## 两档结果与测度口径

corrected权只精确修掉支持重叠的1/k积分，仍在原midpoint评价p、hardmass/q、I及资格；它不修复这些函数的跳面或光滑变化误差。两档原权总体积均751/128=5.8671875，真支持体积3698/625=5.9168，原权均偏低0.0496125；即使两档原体积一致也不是误差认证。

本次corrected与原权A/B仅有浮点舍入差（被改权的重叠cell处实际I为0）；p质量变化，必须用各自匹配的M作条件平均。

| 量（corrected权） | m4 | m8 |
|---|---:|---:|
| A_pre=∫p I | 0.0057162061 | 0.0033772640 |
| B_pre=∫p hardmass/q I | 0.0014547490 | 0.0012560049 |
| M_pre=∫p | 0.3798001257 | 0.2388351438 |
| A_post | 0 | 0.0003992734 |
| B_post | 0 | 0.0001241827 |
| M_post | 0.0147491280 | 0.0061549743 |
| 2N A_post | 0 | 0.0087840148 |
| 2N B_post | 0 | 0.0027320186 |
| 条件p平均2N A_post/M_post | 0 | 1.4271407679 |

pre始终限制hard_positive支持、定义有效以及原来源/FA/Psi资格；post再加固定lambda、高/heavy/hard等全部已实现必要receiver门。p在全空间为概率密度，但支持内M<1；A/M是条件平均，A是原未重新归一化的p积分，B还有原硬来源外因子。三者不能互换。source beta、完整FIRST/history、唯一j及FULL资格没有由此核验。

m4有2个after网格代表点、m8有12个；m4的after点I=0，不能据m4零积分断言集合无正交通。m8的A_post/A_pre≈0.1182、B_post/B_pre≈0.09887，仅为离散诊断。m8条件平均仍>1，而未条件化2N A_post很小：这同时说明receiver质量与条件平均必须分开，不以小未条件化量抹去R150裸行障碍。

粗细A_pre差≈0.0023389420，post从0变正，p质量亦差明显。因此本轮**未展示收敛**；不把数值小宣称真实接收上界。所有实质误差（门/核硬面、重叠、p/FA来源切换、无穷精度核）未给认证上下界。支持外因hard_positive为假恰为0，无尾遗漏；这不扩展为无hard资格的全空间pI结论。

## 便携复现

把原输入根下相应 `centered_cube_round136_20261014/active_traffic_v2.json`、`centered_cube_round141_20261015/numeric_joint.json`、`centered_cube_round142_20261015/numeric_receiver.json` 准备齐，使用同一已安装numpy/scipy/mpmath运行环境：

    python3 receiver_probe.py --input-root INPUT_ROOT --detail-output /tmp/r151_receiver_points.json
    python3 receiver_verify.py --input-root INPUT_ROOT --summary receiver_probe.json --detail /tmp/r151_receiver_points.json

producer相对自身目录输出紧凑receiver_probe.json；detail参数由调用方决定，不会重置λ/质量或扩大菜单。verifier只读取输入/摘要/明细并输出PASS及SHA，不改文件；已对上述冻结结果实际exit0/PASS。producer需要其计划文件同目录以绑定SHA。外部runtime依赖不重复打包。核验完成停止。

### 实际独立核验环境（补记，不改冻结代码）

本次Sol独立verifier实际使用 `/opt/homebrew/opt/python@3.14/bin/python3.14`；环境PYTHONPATH未设置。receiver_verify.py只用标准库及mpmath，自行加入mpmath vendor路径 `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor`，不import numpy/scipy。

producer则需带numpy的bundled Python；代码自行加入scipy runtime `/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime` 并从其真实 `scipy/special/_ufuncs` 加载expn，同时加入上述mpmath vendor。系统Python缺numpy的import失败属于环境预检，未执行模型，不能登记为新的数学计算失败。父已用bundled Python完整重现producer，数学摘要和16.55MB明细SHA逐字节一致；这不替代独立verifier核验。
