# R151 固定I1质量的真实接收积分诊断（父已批；两档有界初探）

只用R150已选I1(n4)质量参数(a,b,c)=(12,8,8)，不扩大质量菜单。目标是比较x0的裸行2NI≈1.92133与固定lambda后真实接收积分/平均；数值为确定性离散诊断，不称认证积分、FULL或维数阶。实现文件receiver_probe.py/json/implementation_notes.md由Luna独占，本文件及独立核验由Sol负责。不改他人文件，不Git。

## 1. 输入与固定对象

原R136 active_traffic_v2.json SHA1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de；原R142 numeric_receiver.json SHAc46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55。可用根 `/Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015/`。复用R142 producer的真实E3产品核与scan/traffic定义，不import运行原main。

以R142 I1 nu_exact为基准：G1-3乘2^12、G4乘2^8、far保持、CORE乘2^8，再全体归一化。原source位置、y、s/L/Hhat/Lplus/b/R、K/D/T/B_FA、threshold、wg/wtau/wh/A、score各段c/k、tau/h与原未归一化后缀Psi固定。六源共同e_t及weight/profile不依x；不把每x不同good/bad改成不同nu。

固定lambda取新nu在x0=0的mp70 control核值所重建max(q0,qJ,qstar)，作为一份**精确定义的有理参数**；它在整个x扫描不变。lambda不用R150简表的宽绝对小数格重建。x0真实核复核如遇上界等号舍入，标near，不逐x重置lambda。

## 2. 支持、精确对称与重叠恒等式

I1六source位置：G1=(-.8)^4，G2=(-1.6)^4，G3=(-.8,-1.6,-.8,-1.6)，G4=(.8)^4，far=(4)^4，CORE=0。必要资格含hard_positive，故支持在六个R=1立方体C_i=v_i+[-.5,.5]^4的并集。这个支持是有限且完整的；本目标域外因hard_positive为假恰为0，**没有无穷尾遗漏**。如果另报不含hard资格的纯pI全空间目标，则域外不能称0，本轮不做该目标。

只有坐标交换1↔3、2↔4的精确对称（每盒亦不变），可用排序指标和orbit权降低重复计算。它是4维对称基本域，不把x1=x3、x2=x4二维截面当积分；没有额外反射或G1/G2交换对称。

重叠用恒等式

    ∫_{并集}f(x)dx = Σ_i ∫_{C_i} f(x)/k(x) dx,
    k(x)=Σ_i 1_{C_i}(x)。

k是盒覆盖数，不是nu加权hardmass；两者分别算。支持mask、k及hardmass在有理source中心/网格坐标上作精确≤比较，避免浮点边界误分；边界采用原≤，虽零测仍可能命中网格。可另以64个子集的包含排斥精确求并集体积作权重诊断，数值体积差不是目标误差界。

## 3. 冻结两档网格与权重

每个C_i采用m=4与m=8两档tensor midpoint：

    x_j=v_ij+(index_j+1/2)/m−1/2, index_j=0,...,m−1。

只枚举index1<=index3、index2<=index4，orbit=(index1==index3?1:2)*(index2==index4?1:2)。每评价点权为 orbit/(m^4 k(x))。每档六盒的评价点数分别600、7776，总8376；展开后的六盒原midpoint点数分别1536、24576。可缓存跨盒重复x，但须记录缓存与原权，不改网格。两档分别完整跑，不按命中新增点或m=16。这里1/k是正确连续重叠恒等式的离散化，有限网格仍可能因重叠跳面而有体积偏差。

## 4. 每个x重新求真实核和资格

用R142真实phi：r<=.5时phi=1−E3(.5−r)−E3(.5+r)，r>.5时phi=E3(r−.5)−E3(r+.5)，E3(0)=1/2。一维核=((1−s)1_|d|<=H/2+s phi(d/H))/H，取4维乘积。算p、K0、K1、K2、J，Q=(K1+K2+J)/3，q=maxΣnu K0/Σnu J/Σnu Q。

按原定义重算good⇔p wg<=KQ、bad补集、E=good且A>0、U=min(TA,DK0)、alpha=(Dq−Σnu U)/QJ、rho=[1−(U+alpha J)/(TA)]_+，不得冻结x0标签/rho。重算hardmass=Σnu 1_C_i(x)，m=Σ_{good,A>0,rho>0}Qnu/q。Psi由固定原profile/原后缀构造，可逐36对核对后复用其布尔值；真实FA重算，不能继承x0 cap。

定义有效要求q>0、QJ>0、alpha>=0及数值有限，失败则明确invalid，不用undefined积分置0蒙混。对定义有效的点，before只含hard_positive支持及原good/bad/rho/FA/Psi；after再加固定lambda的3lambda/4<=q<=lambda、hardmass/R^n<=4lambda、high p eg>=2Kq、heavy eg>ell_old cj^(-n/2)g^n q，以及原已审strict_s/scale/tau_h_g、FIRST三测试和Hhat<Lplus。所有失败门共现和首失败数都保存，不把三测试叫完整FIRST/history。

## 5. 原FA全时间I(x)（不做time网格）

逐原score段使用自己的c/k；I1正delta只在scores{0,4}段上发生。令z=t^-4，e=A_c z+B_c（A_c=Σ_{k=4}nu c，B_c=Σ_{k=0}nu c，完整六源）。对good v、bad u、rho_v>0、Psi_vu、delta=4，原FA条件是

    B_FA delta p w_v(t)>Q_v。

score段起点lo的z_start=lo^-4，真实FA终点的

    z_end=max(score_hi^-4, Q_v/(B_FA delta p c_v))。

若z_end>=z_start则空cap；否则原pair完整时间积分为

    I_vu(x)=rho_v nu_v nu_u c_v c_u (z_start−z_end)
            / [(A_c z_start+B_c)(A_c z_end+B_c)]。

这是delta=4与dlogt变换相消后的原式；禁止额外乘4，也不删e源。对全部原pair/cap求和得I(x)，不乘outer。float实现可用R142稳定expm1式或直接此有理正差；近空cap标near。x0控制须复核2NI≈1.9213301914（N=11）以及R150原I，没有outer混入。

## 6. 输出测度、门前后比和误差边界

每档分别以真实dx网格权求

    A_pre/post = ∫支持 p(x) I(x) 1_{pre/post}(x) dx，
    B_pre/post = ∫支持 p(x) hardmass(x)/q(x) I(x) 1_{pre/post}(x) dx。

A是p加权裸时间费用，B是原硬source外因子费用；不是同一量。另保存M_pre/post=∫支持 p(x)1_pre/post dx、V_pre/post=∫支持1_pre/post dx、post/pre比、2N A/B、2N A/M的条件p平均（M=0时undefined），以及未条件化2N A。p本身为全空间概率核，但支持内M通常<1，不能假装重新归一化后仍是原p测度。比较x0行值时用这些准确口径。

保存两档绝对/相对差、最大I与B/p、最大贡献点及门失败计数。粗细差只作稳定性诊断；离散hard核面、fixedlambda/high/good/rho门和重叠k跳面可产生未解析误差，不认证真实积分上下界或稀有集合为空。没有实际区间求积证书，不因两档接近给置信区间。

float64真E3 batch沿用R142运行时。near阈值相对1e-10：固定lambda边、高/heavy/hardcap、good阈值、rho原分子、FA空端、核硬面均计。最多12个mp70复核点：x0；各档B_post贡献最高前三点（去重）；各档关键相对margin绝对值最小两点（去重）；再按预声明顺序取直至12，不增加网格。mp70仅核局部浮点/门一致性，不认证区间误差。若near导致after分类不确定，另报optimistic/pessimistic离散统计或标其贡献，不删点/换点。

## 7. 核验与停止

独立核验必须检查单nu/固定lambda、真实E3核、每点标签/alpha/rho同步、四维orbit及1/k权、支持边界精确比较、I原函数不重复delta、两个积分口径、失败门与near处理。可完整重算权与支持，抽定固定subset作mp复核，但不得将一次同producer重跑当独立证书。保存代码/输入/计划SHA、实际尝试/完成/失败记录和采用版本；最多已声明8376核评价（另最多12复核），不新增质量/x网格。

一般核区间求积后续可在每个硬面分割盒用E3有理向外包围与区间range×体积，对跨门盒细分、未解决盒保留全解析上界；本初探未实现该误差认证，不能声称已完成。原FULL/history、Z_t删除/top/light、beta/unique j外价仍缺。完成两档诊断和核验后停止。

## 8. 实施前独立精确权重fixture

已用与producer无关的Fraction枚举核验：六盒并集真体积经64个子集包含排斥为3698/625=5.9168。m4的600对称点/1536展开点以及m8的7776对称点/24576展开点，按orbit/(m^4 k)求和的离散体积**两档均为751/128=5.8671875**，均比真体积低0.0496125。这个巧合直接说明粗细一致并不认证真实积分误差；不得将两档权重强行归一为真体积，因那会改变已声明求积公式。两档菜单保持不扩，结果须同时报此体积fixture与未认证跳面误差。
