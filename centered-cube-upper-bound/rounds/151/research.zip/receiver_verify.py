#!/usr/bin/env python3
"""Independent exact receiver weights/aggregates plus four fixed mp70 controls.
No producer import. Midpoint diagnostics do not certify quadrature error or FULL.
"""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import argparse,hashlib,json,math,sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
ROOT=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()
def close(a,b):assert math.isclose(float(a),float(b),rel_tol=1e-12,abs_tol=1e-15),(a,b)
def exact_cell_weight(pos,base,idx,m):
    lo=[pos[base][d]-F(1,2)+F(idx[d],m) for d in range(4)];hi=[z+F(1,m) for z in lo];others=[i for i in range(6) if i!=base];out=F(0)
    # Independent of producer face splitting: inclusion-exclusion for 1/(1+M).
    for size in range(6):
        for ids in combinations(others,size):
            vol=F(1)
            for d in range(4):vol*=max(F(0),min([hi[d]]+[pos[i][d]+F(1,2) for i in ids])-max([lo[d]]+[pos[i][d]-F(1,2) for i in ids]))
            out+=F((-1)**size,size+1)*vol
    return out

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--summary',default=str(ROOT/'receiver_probe.json'));ap.add_argument('--detail');ap.add_argument('--input-root',default='/Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015');args=ap.parse_args()
    jb=Path(args.summary).read_bytes();j=json.loads(jb);detail=Path(args.detail or j['detail_output']['path']);db=detail.read_bytes();assert sha(db)==j['detail_output']['sha256'];rowsmap=json.loads(db)['point_records'];base=Path(args.input_root)
    sb=(base/'centered_cube_round136_20261014/active_traffic_v2.json').read_bytes();rb=(base/'centered_cube_round142_20261015/numeric_receiver.json').read_bytes();assert sha(sb)=='1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de';assert sha(rb)=='c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55'
    c=next(c for c in json.loads(sb)['cases'] if c['id']=='I1');rc=json.loads(rb)['cases']['I1'];at=c['atoms'];pos=[[F(z) for z in a['position']] for a in at]
    nu0=[F(int(z['numerator']),int(z['denominator'])) for z in rc['nu_exact']];raw=[nu0[i]*2**(12 if i<3 else 8 if i in [3,5] else 0) for i in range(6)];nu=[z/sum(raw) for z in raw];assert nu==list(map(F,j['constants']['nu_exact']))
    k0=next(r for r in rc['verifications'] if r['id']==0 and r['distribution']=='control');Q0=[sum(F(k0[z][i]) for z in ['K1','K2','J'])/3 for i in range(6)];lam=max(sum(nu[i]*F(k0['K0'][i]) for i in range(6)),sum(nu[i]*F(k0['J'][i]) for i in range(6)),sum(nu[i]*Q0[i] for i in range(6)));assert lam==F(j['constants']['lambda_exact'])
    counts={}
    for mm,rr in rowsmap.items():
        m=int(mm);wold=F(0);wnew=F(0);seen=set();agg={typ:{lab:{k:0. for k in ['A','B','M_p','V_dx']} for lab in ['pre','post']} for typ in ['old','new']}
        for r in rr:
            ctr=r['source_box'];idx=r['index'];key=(ctr,*idx);assert key not in seen;seen.add(key);xx=list(map(F,r['xq']));assert idx[0]<=idx[2] and idx[1]<=idx[3];assert xx==[pos[ctr][d]+F(2*idx[d]+1-m,2*m) for d in range(4)]
            hits=[all(abs(xx[d]-p[d])<=F(1,2) for d in range(4)) for p in pos];cover=sum(hits);hm=sum(nu[i] for i in range(6) if hits[i]);orb=(1 if idx[0]==idx[2] else 2)*(1 if idx[1]==idx[3] else 2);wo=F(orb,m**4*cover);wn=orb*exact_cell_weight(pos,ctr,idx,m)
            assert hits==r['hard_sources'] and cover==r['cover_multiplicity_k'] and orb==r['orbit'] and hm==F(r['hardmass']);assert wo==F(r['dx_weight']) and wn==F(r['dx_weight_corrected']);wold+=wo;wnew+=wn
            assert r['valid'] and r['I']>=0 and r['before'];p,q,I=r['p'],r['q'],r['I'];close(r['A_integrand'],p*I);close(r['B_integrand'],p*float(hm)/q*I)
            for typ,w in [('old',wo),('new',wn)]:
                for lab,take in [('pre',r['before']),('post',r['after'])]:
                    if take:
                        for k,val in [('A',p*I),('B',p*float(hm)/q*I),('M_p',p),('V_dx',1)]:agg[typ][lab][k]+=float(w)*val
        assert len(rr)==(600 if m==4 else 7776) and wold==F(751,128) and wnew==F(3698,625)
        for typ,summary in [('old',j['summaries'][mm]),('new',j['corrected_overlap_weights']['summaries'][mm])]:
            for lab in ['pre','post']:
                for k in agg[typ][lab]:close(agg[typ][lab][k],summary[lab][k])
                close(summary[lab]['2N_A'],22*agg[typ][lab]['A']);close(summary[lab]['2N_B'],22*agg[typ][lab]['B']);close(summary[lab]['2N_A_over_M'],22*agg[typ][lab]['A']/agg[typ][lab]['M_p'])
        counts[mm]=dict(points=len(rr),original_weight=str(wold),corrected_weight=str(wnew),near=sum(bool(r['near']) for r in rr))
    # Four fixed controls are independently evaluated with true E3, not source code.
    mp.mp.dps=70
    def M(z):
        z=F(str(z));return mp.mpf(z.numerator)/z.denominator
    nmp=list(map(M,nu));par=c['parameters'];der=c['derived'];eg=sum(nmp[i]*M(at[i]['wg']) for i in range(6))
    def phi(t):
        t=abs(t);E=lambda z:mp.mpf('.5') if z==0 else mp.expint(3,z)
        return 1-E(mp.mpf('.5')-t)-E(mp.mpf('.5')+t) if t<=mp.mpf('.5') else E(t-mp.mpf('.5'))-E(t+mp.mpf('.5'))
    def kernel(s,H,xx):return mp.fprod(((1-s)*(abs(z)<=H/2)+s*phi(z/H))/H for z in xx)
    rr=rowsmap['8'];selected=[j['x0_control'],max((r for r in rr if r['after']),key=lambda r:r['B_integrand']),max(rr,key=lambda r:r['I']),rowsmap['4'][0]];mpresults=[]
    for r in selected:
        xx=list(map(M,r['xq']));s=M(par['s']);L=M(par['L']);p=kernel(s,L,[z-M(par['y']) for z in xx]);d=[[xx[k]-M(a['position'][k]) for k in range(4)] for a in at];K0=[kernel(s,M(der['Hhat']),z) for z in d];K1=[kernel(s,L,z) for z in d];K2=[kernel(s,M(der['Lplus']),z) for z in d];J=[kernel(1,M(par['b']),z) for z in d];Q=[(K1[i]+K2[i]+J[i])/3 for i in range(6)];q=max(sum(nmp[i]*z[i] for i in range(6)) for z in [K0,J,Q]);qj=sum(nmp[i]*J[i] for i in range(6));good=[p*M(a['wg'])<=M(par['K'])*Q[i] for i,a in enumerate(at)];T=M(der['T']);U=[min(T*M(a['A']),M(par['D'])*K0[i]) if good[i] and M(a['A'])>0 else 0 for i,a in enumerate(at)];alpha=(M(par['D'])*q-sum(nmp[i]*U[i] for i in range(6)))/qj;rho=[max(0,1-(U[i]+alpha*J[i])/(T*M(a['A']))) if good[i] and M(a['A'])>0 else 0 for i,a in enumerate(at)];I=mp.mpf(0)
        for sg in c['score_segments']:
            ks=sg['k'];cs=list(map(M,sg['c']));A=sum(nmp[i]*cs[i] for i in range(6) if ks[i]==4);B=sum(nmp[i]*cs[i] for i in range(6) if ks[i]==0)
            for v in range(6):
                for u in range(6):
                    if not(good[v] and not good[u] and rho[v]>0 and ks[v]>ks[u] and c['pairs'][6*v+u]['Psi']):continue
                    assert ks[v]-ks[u]==4;z0=M(sg['lo'])**-4;z1=max(M(sg['hi'])**-4,Q[v]/(M(par['B_FA'])*4*p*cs[v]))
                    if z1<z0:I+=rho[v]*nmp[v]*nmp[u]*cs[v]*cs[u]*(z0-z1)/((A*z0+B)*(A*z1+B))
        assert good==r['good'];rel=abs(I-r['I'])/max(abs(I),mp.mpf('1e-300'));assert rel<mp.mpf('1e-12');close(p,r['p']);close(q,r['q']);close(alpha,r['alpha'])
        for i in range(6):close(rho[i],r['rho'][i])
        m=sum(Q[i]*nmp[i]/q for i in range(6) if good[i] and M(at[i]['A'])>0 and rho[i]>0);close(m,r['m'])
        hm=sum(nmp[i] for i in range(6) if all(abs(d[i][k])<=mp.mpf('.5') for k in range(4)));lf=M(lam)
        g={'lambda_lower':q>=3*lf/4,'lambda_upper':q<=lf,'hard_cap':hm<=4*lf,'high':p*eg>=2*M(par['K'])*q,'heavy':eg>M(der['ell'])*M(der['cj'])**-2*M(der['g'])**4*q}
        for key,z in g.items():
            # The fixed-lambda x0 upper boundary is near and intentionally not certified.
            if r is not j['x0_control']:assert bool(z)==r['gates'][key]
        mpresults.append(dict(xq=r['xq'],I=mp.nstr(I,20),relative_float_I=mp.nstr(rel,5)))
    print(json.dumps(dict(status='PASS',scope='Independent exact geometry/overlap weights and stored aggregate reconstruction; four mp70 controls only; no quadrature error/FULL/dx bound certification',meshes=counts,mp70_controls=mpresults,summary_sha256=sha(jb),detail_sha256=sha(db),verifier_sha256=sha(Path(__file__).read_bytes())),indent=2))
if __name__=='__main__':main()
