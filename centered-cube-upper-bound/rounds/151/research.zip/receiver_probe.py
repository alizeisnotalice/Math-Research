#!/usr/bin/env python3
"""R151 fixed-I1 true-kernel receiver probe; finite deterministic dx diagnostics only."""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations, product
import json, hashlib, math, argparse, sys, time
import numpy as np
# Match the installed runtime paths used by R142 without installing packages.
RUNTIME_ROOT=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime')
SCIPY_ROOT=RUNTIME_ROOT/'scipy'
sys.path.insert(0,str(RUNTIME_ROOT))
import scipy
VENDOR=Path('/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
sys.path.insert(0,str(VENDOR))
import types, importlib
sp=types.ModuleType('scipy.special');sp.__path__=[str(SCIPY_ROOT/'special')];sys.modules['scipy.special']=sp
expn=importlib.import_module('scipy.special._ufuncs').expn
import mpmath as mp
ROOT=Path(__file__).resolve().parent
DEFAULT_ROOT=Path('/Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015')
R136=DEFAULT_ROOT/'centered_cube_round136_20261014/active_traffic_v2.json'
R142=DEFAULT_ROOT/'centered_cube_round142_20261015/numeric_receiver.json'
R141=DEFAULT_ROOT/'centered_cube_round141_20261015/numeric_joint.json'
EXPECTED={'R136':'1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de','R142':'c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55'}
N=11

def Fq(x):
    if isinstance(x,F):return x
    if isinstance(x,dict) and 'numerator' in x:return F(int(x['numerator']),int(x['denominator']))
    return F(str(x))
def fstr(x):return str(x.numerator) if x.denominator==1 else f'{x.numerator}/{x.denominator}'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fmt(x):return float(x) if math.isfinite(float(x)) else None
def margin(a,b):return (a-b)/max(abs(a),abs(b),1e-300)
def phi_np(r):
    r=np.abs(np.asarray(r,dtype=np.float64));out=np.empty_like(r);m=r<=.5
    out[m]=1-expn(3,.5-r[m])-expn(3,.5+r[m]);out[~m]=expn(3,r[~m]-.5)-expn(3,r[~m]+.5)
    return out
def kernel_np(s,H,d):
    d=np.asarray(d,dtype=np.float64)
    return np.prod(((1.0-s)*(np.abs(d)<=H/2)+s*phi_np(d/H))/H,axis=-1)
def phi_mp(r):
    r=abs(r);E=lambda x:mp.mpf('.5') if x==0 else mp.expint(3,x)
    return 1-E(mp.mpf('.5')-r)-E(mp.mpf('.5')+r) if r<=mp.mpf('.5') else E(r-mp.mpf('.5'))-E(r+mp.mpf('.5'))
def kernel_mp(s,H,d):return mp.fprod(((1-s)*(1 if abs(x)<=H/2 else 0)+s*phi_mp(x/H))/H for x in d)

def build(template,rec):
    atoms=template['atoms'];nu0=[Fq(x) for x in rec['nu_exact']]
    mult=[F(2**12)]*3+[F(2**8),F(1),F(2**8)];raw=[nu0[i]*mult[i] for i in range(6)];norm=sum(raw);nu=[x/norm for x in raw]
    base=next(r for r in rec['verifications'] if r.get('id')==0)
    K0=[Fq(x) for x in base['K0']];K1=[Fq(x) for x in base['K1']];K2=[Fq(x) for x in base['K2']];J=[Fq(x) for x in base['J']];Q=[(K1[i]+K2[i]+J[i])/3 for i in range(6)]
    q0=sum(nu[i]*K0[i] for i in range(6));qj=sum(nu[i]*J[i] for i in range(6));qs=sum(nu[i]*Q[i] for i in range(6));lam=max(q0,qj,qs)
    positions=[[Fq(v) for v in a['position']] for a in atoms];pars=template['parameters'];der=template['derived']
    prof=[]
    for sg in template['score_segments']:
        prof.append({'lo':Fq(sg['lo']),'hi':Fq(sg['hi']),'c':[Fq(x) for x in sg['c']],'k':[int(x) for x in sg['k']]})
    psi=[[bool(template['pairs'][i*6+j]['Psi']) for j in range(6)] for i in range(6)]
    return {'nu':nu,'positions':positions,'lamF':lam,'lam':float(lam),'q0F':q0,'qjF':qj,'qsF':qs,'QF':Q,'K0F':K0,'Jf':J,'p0F':Fq(base['p']),'profiles':prof,'psi':psi,
      'sF':Fq(pars['s']),'LF':Fq(pars['L']),'KF':Fq(pars['K']),'DF':Fq(pars['D']),'BFAF':Fq(pars['B_FA']),'HF':Fq(der['Hhat']),'LpF':Fq(der['Lplus']),'bF':Fq(pars['b']),'TF':Fq(der['T']),'ellF':Fq(der['ell']),'cjF':Fq(der['cj']),'gF':Fq(der['g']),'s':float(Fq(pars['s'])),'L':float(Fq(pars['L'])),'K':float(Fq(pars['K'])),'D':float(Fq(pars['D'])),'BFA':float(Fq(pars['B_FA'])),'y':np.full(4,float(Fq(pars['y']))),
      'H':float(Fq(der['Hhat'])),'Lp':float(Fq(der['Lplus'])),'b':float(Fq(pars['b'])),'T':float(Fq(der['T'])),'g':float(Fq(der['g'])),'ell':float(Fq(der['ell'])),'cj':float(Fq(der['cj'])),'tau':float(Fq(der['tau'])),'h':float(Fq(der['h'])),'n':int(template['n']),
      'wgF':[Fq(a['wg']) for a in atoms],'AF':[Fq(a['A']) for a in atoms],'wg':np.array([float(Fq(a['wg'])) for a in atoms]),'A':np.array([float(Fq(a['A'])) for a in atoms]),'eg':float(sum(nu[i]*Fq(atoms[i]['wg']) for i in range(6))),
      'nuF':nu,'nu':np.array([float(x) for x in nu]),'psi_source_check':all(psi[i][j]==bool(template['pairs'][i*6+j]['Psi']) for i in range(6) for j in range(6))}

def profile_coef(model,seg):
    ac=sum(float(model['nu'][i])*float(seg['c'][i]) for i,k in enumerate(seg['k']) if k==4)
    bc=sum(float(model['nu'][i])*float(seg['c'][i]) for i,k in enumerate(seg['k']) if k==0)
    return ac,bc

def eval_batch(model,xs):
    n=len(xs);pos=np.array([[float(v) for v in p] for p in model['positions']]);dx=xs[:,None,:]-pos[None,:,:]
    p=kernel_np(model['s'],model['L'],xs-model['y'])
    K0=kernel_np(model['s'],model['H'],dx);K1=kernel_np(model['s'],model['L'],dx);K2=kernel_np(model['s'],model['Lp'],dx);J=kernel_np(1.0,model['b'],dx);Q=(K1+K2+J)/3
    qtests=np.stack((K0@model['nu'],J@model['nu'],Q@model['nu']),axis=1);q=np.max(qtests,axis=1);qj=qtests[:,1]
    good=p[:,None]*model['wg'][None,:]<=model['K']*Q
    E=good&(model['A'][None,:]>0)
    U=np.where(E,np.minimum(model['T']*model['A'][None,:],model['D']*K0),0.)
    alpha=(model['D']*q-U@model['nu'])/qj
    rho=np.where(E,np.maximum(1-(U+alpha[:,None]*J)/(model['T']*np.where(model['A']>0,model['A'],1)),0),0)
    return p,K0,K1,K2,J,Q,qtests,q,qj,good,E,U,alpha,rho,dx

def exact_geom(model,xq):
    hits=[]
    for v in model['positions']:
        hits.append(all(abs(xq[d]-v[d])<=F(1,2) for d in range(4)))
    k=sum(hits);hm=sum(model['nuF'][i] for i,b in enumerate(hits) if b)
    return hits,k,hm

def one_point(model,xq,template,full=False):
    x=np.array([float(v) for v in xq],dtype=np.float64)[None,:]
    p,K0,K1,K2,J,Q,qts,qs,qjs,good,Es,U,alpha,rho,dx=eval_batch(model,x)
    p0=float(p[0]);qq=float(qs[0]);qj=float(qjs[0]);al=float(alpha[0]);rhos=rho[0];g=good[0];ev=Es[0];u=U[0];qv=Q[0]
    hard,kcover,hmF=exact_geom(model,xq);hm=float(hmF);valid=qq>0 and qj>0 and math.isfinite(al) and al>=0
    support=kcover>0
    gates={'lambda_lower':qq>=.75*model['lam'],'lambda_upper':qq<=model['lam'],'hard_cap':hm<=4*model['lam'],'hard_positive':support,'high':p0*model['eg']>=2*model['K']*qq,
      'heavy':model['eg']>model['ell']*(model['cj']**(-model['n']//2))*(model['g']**model['n'])*qq,'QJ_positive':qj>0,'alpha_nonnegative':al>=0,
      'FIRST_three':bool(np.all(qts[0]<=qq)),'strict_s':bool(template['gates']['strict_s']),'scale':bool(template['gates']['scale']),
      'tau_h_g':bool(template['gates']['tau_h_g']),'Hhat_less_Lplus':model['H']<model['Lp']}
    # Float margins and near labels; all hard/box decisions above use exact rational coordinates.
    margins={'lambda_lower':margin(qq,.75*model['lam']),'lambda_upper':margin(model['lam'],qq),'hard_cap':margin(4*model['lam'],hm),
      'high':margin(p0*model['eg'],2*model['K']*qq),'heavy':margin(model['eg'],model['ell']*(model['cj']**(-model['n']//2))*model['g']**model['n']*qq),
      'alpha':margin(model['D']*qq,float(np.dot(u,model['nu'])))}
    near=[]
    for key,v in margins.items():
      if abs(v)<=1e-10:near.append(key)
    for i in range(6):
      gm=margin(model['K']*qv[i],p0*model['wg'][i]);margins[f'good:{i}']=gm
      if abs(gm)<=1e-10:near.append(f'good:{i}')
      if ev[i]:
       rm=margin(model['T']*model['A'][i],u[i]+al*float(J[0,i]));margins[f'rho:{i}']=rm
       if abs(rm)<=1e-10:near.append(f'rho:{i}')
    for name,HH in [('K0',model['H']),('K1',model['L']),('K2',model['Lp']),('J',model['b']),('hard',1.)]:
      if np.any(np.abs(np.abs(dx[0])-HH/2)/HH<=1e-10):near.append('kernel_boundary:'+name)
    if np.any(np.abs(np.abs(x[0]-model['y'])-model['L']/2)/model['L']<=1e-10):near.append('p_boundary')
    I=0. if valid and support else None;pairs=[];fa_near=[]
    if valid and support:
      for si,seg in enumerate(model['profiles']):
       lo=float(seg['lo']);hi=float(seg['hi']);ac,bc=profile_coef(model,seg)
       if not ac and not bc:continue
       for v in range(6):
        kv=seg['k'][v]
        if not g[v] or rhos[v]<=0 or kv!=4:continue
        cv=float(seg['c'][v]);Qv=float(qv[v])
        for bad in range(6):
         ku=seg['k'][bad]
         if g[bad] or ku>=kv or not model['psi'][v][bad]:continue
         cu=float(seg['c'][bad]);delta=kv-ku
         ratio=model['BFA']*delta*p0*cv/Qv
         z0=lo**(-4);z_hi=hi**(-4);z_cut=Qv/(model['BFA']*delta*p0*cv)
         z1=max(z_hi,z_cut)
         if abs(z1-z0)/max(abs(z1),abs(z0),1e-300)<=1e-10:fa_near.append(f'FAempty:{si}:{v}:{bad}')
         if z1>=z0:continue
         den0=ac*z0+bc;den1=ac*z1+bc
         val=float(rhos[v])*model['nu'][v]*model['nu'][bad]*cv*cu*(z0-z1)/(den0*den1)
         if val>0:
          I+=val;pairs.append({'segment':si,'v':v,'u':bad,'delta':delta,'I':val})
    near.extend(fa_near)
    gates['valid']=valid;gates['support']=support
    before=valid and support
    after=before and all(gates[k] for k in ('lambda_lower','lambda_upper','hard_cap','hard_positive','high','heavy','QJ_positive','alpha_nonnegative','FIRST_three','strict_s','scale','tau_h_g','Hhat_less_Lplus'))
    failures=[k for k,v in gates.items() if k not in ('valid','support') and not v]
    row={'xq':[fstr(v) for v in xq],'x':[float(v) for v in xq],'p':p0,'q':qq,'q_tests':qts[0].tolist(),'QJ':qj,'alpha':al,'rho':rhos.tolist(),'good':g.tolist(),'E':ev.tolist(),
      'hard_sources':hard,'cover_multiplicity_k':kcover,'hardmass':hm,'m':float(sum(float(model['nuF'][i])*float(qv[i]) for i in range(6) if ev[i] and rhos[i]>0)/qq) if qq>0 else None,
      'valid':valid,'before':before,'after':after,'gates':gates,'failure_gates':failures,'first_failure':next((k for k in ('lambda_lower','lambda_upper','hard_cap','hard_positive','high','heavy','QJ_positive','alpha_nonnegative','FIRST_three','strict_s','scale','tau_h_g','Hhat_less_Lplus') if not gates[k]),None),
      'I':I,'pair_count':len(pairs),'pair_terms':pairs,'A_integrand':p0*I if before else None,'B_integrand':p0*hm/qq*I if before and qq>0 else None,
      'near':sorted(set(near)),'margins':margins,'float64':'diagnostic'}
    return row

def grid(m,model,template):
    rows=[];half=F(1,2);cubevol=F(1,m**4)
    for ci,center in enumerate(model['positions']):
     for i1 in range(m):
      for i3 in range(i1,m):
       for i2 in range(m):
        for i4 in range(i2,m):
         ix=[i1,i2,i3,i4];orb=(1 if i1==i3 else 2)*(1 if i2==i4 else 2)
         xq=[center[d]+F(2*ix[d]+1-m,2*m) for d in range(4)]
         hits,k,hm=exact_geom(model,xq)
         if not k:raise AssertionError('midpoint of source cube must be in support')
         row=one_point(model,xq,template);row.update({'grid_m':m,'source_box':ci,'index':ix,'orbit':orb,'dx_weight':fstr(F(orb,m**4*k)),'cover_multiplicity_k':k,'hard_sources':hits,'hardmass':fstr(hm)})
         rows.append(row)
    return rows

def aggregate(rows,m,model):
    names=['pre','post'];out={};z={k:{'A':0.,'B':0.,'M':0.,'V':0.} for k in names};fail={k:{} for k in names};first={k:{} for k in names}
    maxI={'value':-1.,'xq':None};maxBp={'value':-1.,'xq':None};maxcont={'value':-1.,'xq':None};invalid=0
    margins_abs=[]
    for r in rows:
     w=float(Fq(r['dx_weight']));p=r['p'];q=r['q'];hm=float(Fq(r['hardmass']));I=r['I']
     if I is None: invalid+=1; continue
     if I>maxI['value']:maxI={'value':I,'xq':r['xq']}
     bp=hm/q*I if q>0 else 0.
     if bp>maxBp['value']:maxBp={'value':bp,'xq':r['xq']}
     bc=p*bp
     if w*bc>maxcont['value']:maxcont={'value':w*bc,'xq':r['xq']}
     margins_abs.append((min((abs(v) for v in r['margins'].values()),default=1.),r))
     for label in names:
      take=r['before'] if label=='pre' else r['after']
      if not take:continue
      z[label]['V']+=w;z[label]['M']+=w*p;z[label]['A']+=w*p*I;z[label]['B']+=w*p*bp
      for g in r['failure_gates']:fail[label][g]=fail[label].get(g,0)+1
      ff=r['first_failure']
      if ff:first[label][ff]=first[label].get(ff,0)+1
    for k in names:
     a=z[k]['A'];b=z[k]['B'];M=z[k]['M']
     out[k]={'A':a,'B':b,'M_p':M,'V_dx':z[k]['V'],'2N_A':2*N*a,'2N_B':2*N*b,'2N_A_over_M':2*N*a/M if M else None,'failure_cooccurrence_counts':fail[k],'first_failure_counts':first[k]}
    out['ratios']={'A_post_over_pre':out['post']['A']/out['pre']['A'] if out['pre']['A'] else None,'B_post_over_pre':out['post']['B']/out['pre']['B'] if out['pre']['B'] else None}
    out['extrema']={'max_I':maxI,'max_hardmass_over_q_times_I':maxBp,'max_weighted_B_contribution':maxcont}
    # record mean and absolute convergence diagnostics only
    out['grid_m']=m;out['point_count']=len(rows);out['evaluated_points']=sum(1 for r in rows);out['invalid_integral_points']=invalid
    out['estimated_union_volume']=z['pre']['V'] if all(r['before'] for r in rows) else None
    return out

def union_volume(centers):
    # Exact inclusion-exclusion diagnostic for six equal cubes.
    vol=F(0)
    for size in range(1,len(centers)+1):
     for ids in combinations(range(len(centers)),size):
      lengths=[]
      for d in range(4):
       lo=max(centers[i][d]-F(1,2) for i in ids);hi=min(centers[i][d]+F(1,2) for i in ids);length=max(F(0),hi-lo);lengths.append(length)
      x=math.prod(lengths);vol+=x if size%2 else -x
    return vol

def mp_check(model,template,xq):
    mp.mp.dps=70;pos=[[mp.mpf(v.numerator)/v.denominator for v in p] for p in model['positions']];xx=[mp.mpf(v.numerator)/v.denominator for v in xq]
    def M(v):return mp.mpf(v.numerator)/v.denominator if isinstance(v,F) else mp.mpf(str(v))
    nu=[M(v) for v in model['nuF']];conv=lambda v:mp.mpf(v.numerator)/v.denominator if isinstance(v,F) else mp.mpf(str(v));s,L,K,D,H,Lp,b,T,BFA=[conv(model[k]) for k in ('sF','LF','KF','DF','HF','LpF','bF','TF','BFAF')];y=[mp.mpf('.3')]*4
    p=kernel_mp(s,L,[xx[d]-y[d] for d in range(4)]);dx=[[xx[d]-pos[i][d] for d in range(4)] for i in range(6)]
    k0=[kernel_mp(s,H,z) for z in dx];k1=[kernel_mp(s,L,z) for z in dx];k2=[kernel_mp(s,Lp,z) for z in dx];J=[kernel_mp(1,b,z) for z in dx];Q=[(k1[i]+k2[i]+J[i])/3 for i in range(6)]
    qs=[mp.fsum(nu[i]*v[i] for i in range(6)) for v in (k0,J,Q)];qv=max(qs);qj=qs[1];good=[p*conv(model['wgF'][i])<=K*Q[i] for i in range(6)]
    A=[conv(model['AF'][i]) for i in range(6)];U=[min(T*A[i],D*k0[i]) if good[i] and A[i]>0 else mp.mpf(0) for i in range(6)];alpha=(D*qv-mp.fsum(nu[i]*U[i] for i in range(6)))/qj
    rho=[max(1-(U[i]+alpha*J[i])/(T*A[i]),mp.mpf(0)) if good[i] and A[i]>0 else mp.mpf(0) for i in range(6)]
    hard=[all(abs(dx[i][d])<=mp.mpf('.5') for d in range(4)) for i in range(6)];hm=mp.fsum(nu[i] for i in range(6) if hard[i]);I=mp.mpf(0)
    for seg in model['profiles']:
      lo=M(seg['lo']);hi=M(seg['hi']);cs=[M(v) for v in seg['c']];ks=seg['k'];ac=mp.fsum(nu[i]*cs[i] for i,k in enumerate(ks) if k==4);bc=mp.fsum(nu[i]*cs[i] for i,k in enumerate(ks) if k==0)
      for v in range(6):
       if not good[v] or rho[v]<=0 or ks[v]!=4:continue
       for u in range(6):
        if good[u] or ks[u]>=ks[v] or not model['psi'][v][u]:continue
        z0=lo**(-4);z1=max(hi**(-4),Q[v]/(BFA*4*p*cs[v]));
        if z1>=z0:continue
        I+=rho[v]*nu[v]*nu[u]*cs[v]*cs[u]*(z0-z1)/((ac*z0+bc)*(ac*z1+bc))
    lam=mp.mpf(model['lamF'].numerator)/model['lamF'].denominator;egmp=mp.fsum(nu[i]*conv(model['wgF'][i]) for i in range(6))
    gate={'lambda_lower':qv>=mp.mpf(3)/4*lam,'lambda_upper':qv<=lam,'hard_cap':hm<=4*lam,'high':p*egmp>=2*K*qv,'heavy':egmp>conv(model['ellF'])*conv(model['cjF'])**(-model['n']//2)*conv(model['gF'])**model['n']*qv,'qJ_positive':qj>0,'alpha_nonnegative':alpha>=0}
    return {'xq':[fstr(x) for x in xq],'p':mp.nstr(p,25),'q':mp.nstr(qv,25),'alpha':mp.nstr(alpha,25),'rho':[mp.nstr(x,15) for x in rho],'hardmass':mp.nstr(hm,25),'I':mp.nstr(I,25),'gate_check':gate,'float_vs_mp_I_rel':None}

def corrected_cell_weight(center, index, m, centers):
    """Exact orbit-multiplied cell integral of 1/k(x), cut at all hard-box faces."""
    bounds=[]
    for d in range(4):
        lo=center[d]-F(1,2)+F(index[d],m);hi=lo+F(1,m)
        cuts={lo,hi}
        for c in centers:
            for face in (c[d]-F(1,2),c[d]+F(1,2)):
                if lo<face<hi:cuts.add(face)
        bounds.append(sorted(cuts))
    total=F(0)
    interval_lists=[list(zip(b[:-1],b[1:])) for b in bounds]
    for cell in product(*interval_lists):
        mid=[(a+b)/2 for a,b in cell]
        k=sum(all(abs(mid[d]-c[d])<=F(1,2) for d in range(4)) for c in centers)
        if not k:continue
        vol=math.prod(b-a for a,b in cell);total+=vol/F(k)
    orbit=(1 if index[0]==index[2] else 2)*(1 if index[1]==index[3] else 2)
    return orbit*total

def corrected_aggregate(rows):
    z={k:{'A':0.,'B':0.,'M_p':0.,'V_dx':0.} for k in ('pre','post')};fail={k:{} for k in z};first={k:{} for k in z};invalid=0
    for r in rows:
        w=float(Fq(r['dx_weight_corrected']));p=r['p']
        if r['I'] is None:invalid+=1;continue
        for scope,take in (('pre',r['before']),('post',r['after'])):
            if not take:continue
            z[scope]['V_dx']+=w;z[scope]['M_p']+=w*p;z[scope]['A']+=w*(r['A_integrand'] or 0.);z[scope]['B']+=w*(r['B_integrand'] or 0.)
            for g in r['failure_gates']:fail[scope][g]=fail[scope].get(g,0)+1
            if r['first_failure']:first[scope][r['first_failure']]=first[scope].get(r['first_failure'],0)+1
    for scope in z:
        a=z[scope]['A'];b=z[scope]['B'];M=z[scope]['M_p']
        z[scope].update({'2N_A':2*N*a,'2N_B':2*N*b,'2N_A_over_M':2*N*a/M if M else None,'failure_cooccurrence_counts':fail[scope],'first_failure_counts':first[scope]})
    z['ratios']={'A_post_over_pre':z['post']['A']/z['pre']['A'] if z['pre']['A'] else None,'B_post_over_pre':z['post']['B']/z['pre']['B'] if z['pre']['B'] else None}
    z['invalid_integral_points']=invalid
    return z

def add_corrected_overlap(doc, centers):
    for gridname,rows in doc['point_records'].items():
        m=int(gridname)
        for r in rows:
            r['dx_weight_corrected']=fstr(corrected_cell_weight(centers[int(r['source_box'])],[int(v) for v in r['index']],m,centers))
    truth=union_volume(centers)
    sums={g:sum((Fq(r['dx_weight_corrected']) for r in rows),F(0)) for g,rows in doc['point_records'].items()}
    if any(v!=truth for v in sums.values()):raise AssertionError(f'corrected cell weights do not tile union: {sums} vs {truth}')
    doc['corrected_overlap_weights']={'formula':'orbit * integral_cell(1/k(x)) dx, split at all six-box rational faces; midpoint values unchanged',
      'corrected_weighted_support_volume':{g:fstr(v) for g,v in sums.items()},'true_union_volume':fstr(truth),
      'summaries':{g:corrected_aggregate(rows) for g,rows in doc['point_records'].items()},
      'interpretation':'overlap-weight correction only; midpoint quadrature for the integrand remains unvalidated and is not an error bound'}
    return doc

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input-root',default=str(DEFAULT_ROOT));ap.add_argument('--detail-output',default='/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json');ap.add_argument('--postprocess-existing',default=None,help='add exact cell overlap weights to an existing full JSON without recomputing kernels');args=ap.parse_args()
    global R136,R142,R141
    root=Path(args.input_root);R136=root/'centered_cube_round136_20261014/active_traffic_v2.json';R142=root/'centered_cube_round142_20261015/numeric_receiver.json';R141=root/'centered_cube_round141_20261015/numeric_joint.json'
    d136=json.loads(R136.read_text());d142=json.loads(R142.read_text());d141=json.loads(R141.read_text());template=next(x for x in d136['cases'] if x['id']=='I1');rec=d142['cases']['I1'];model=build(template,rec)
    if args.postprocess_existing:
      prior=json.loads(Path(args.postprocess_existing).read_text())
      if 'point_records' not in prior:
        prior_detail=Path(prior['detail_output']['path']);prior['point_records']=json.loads(prior_detail.read_text())['point_records']
      add_corrected_overlap(prior,model['positions']);detail=Path(args.detail_output);detail.parent.mkdir(parents=True,exist_ok=True);detail.write_text(json.dumps({'point_records':prior['point_records'],'corrected_overlap_weights':prior['corrected_overlap_weights']},separators=(',',':'))+'\n');prior['detail_output']={'path':str(detail),'sha256':sha(detail),'bytes':detail.stat().st_size};prior['execution_audit']['exact_overlap_weight_postprocess_calls']=3;prior['execution_audit']['exact_overlap_weight_postprocess_failed']=1;prior['execution_audit']['exact_overlap_weight_postprocess_completed']=2;prior['execution_audit']['adopted_overlap_postprocess_call']=3;prior['producer_sha256']=sha(Path(__file__));prior['plan_sha256']=sha(ROOT/'receiver_numeric_plan.md');prior.pop('point_records',None);target=ROOT/'receiver_probe.json';target.write_text(json.dumps(prior,separators=(',',':'))+'\n');print('postprocessed without kernel rerun',target.stat().st_size,detail.stat().st_size);return
    start=time.time();all_rows={};stats={}
    if sha(R136)!=EXPECTED['R136'] or sha(R142)!=EXPECTED['R142']:
      raise RuntimeError('frozen R136/R142 input SHA mismatch')
    if sha(R141)!='acafcde85224fc1e5e2e9663f00e5233ead8daa8adb0d7382ce3436bb0b7618b':
      raise RuntimeError('frozen R141 input SHA mismatch')
    for m in (4,8):
      rows=grid(m,model,template);all_rows[str(m)]=rows;stats[str(m)]=aggregate(rows,m,model);print('grid',m,'points',len(rows),flush=True)
    control=one_point(model,[F(0)]*4,template);control['control_label']='x0';control['2N_I']=2*N*control['I']
    # deterministic mp70 shortlist: x0; top three B_post contributions per grid; two smallest key margins per grid; deduplicate
    selected=[];seen=set()
    def take(x,tag):
      key=tuple(x['xq'])
      if key not in seen and len(selected)<12:seen.add(key);selected.append((x,tag))
    take(control,'x0')
    for m in (4,8):
      rr=[r for r in all_rows[str(m)] if r['after']]
      rr=sorted(rr,key=lambda r:-(r['dx_weight'] and float(Fq(r['dx_weight']))*r['p']*float(Fq(r['hardmass']))/r['q']*r['I']))
      for x in rr[:3]:take(x,f'm{m}_top_B_post')
    gate_keys=('lambda_lower','lambda_upper','hard_cap','high','heavy','alpha')
    for m in (4,8):
      rr=all_rows[str(m)]
      rr=sorted(rr,key=lambda r:min((abs(r['margins'][k]) for k in gate_keys),default=1.))
      for x in rr[:2]:take(x,f'm{m}_min_gate_margin')
    mpchecks=[]
    for x,tag in selected:
      z=mp_check(model,template,[Fq(t) for t in x['xq']]);z['selection_reason']=tag
      z['float_I']=x['I'];z['float_vs_mp_I_rel']=abs(x['I']-float(z['I']))/max(abs(float(z['I'])),1e-300)
      mpchecks.append(z)
    # Exact support volume and grid-weighted support-volume diagnostics.
    unionvol=union_volume(model['positions']);voldiag={str(m):sum(float(Fq(r['dx_weight'])) for r in all_rows[str(m)]) for m in (4,8)}
    diffs={scope:{field:{'absolute':abs(stats['8'][scope][field]-stats['4'][scope][field]),'relative':abs(stats['8'][scope][field]-stats['4'][scope][field])/max(abs(stats['8'][scope][field]),1e-300)} for field in ('A','B','M_p','V_dx')} for scope in ('pre','post')}
    out={'status':'completed','scope':'finite deterministic midpoint receiver diagnostics; not quadrature error bounds, FULL, or dimension-order certification',
      'model':'I1 only, frozen mass multipliers (12,8,8); fixed lambda from exact R142 mp70 x0 control; all x-dependent receiver quantities recomputed',
      'inputs':{'R136':{'path':str(R136),'sha256':sha(R136)},'R142':{'path':str(R142),'sha256':sha(R142)},'R141':{'path':str(R141),'sha256':sha(R141)}},
      'constants':{'lambda_exact':fstr(model['lamF']),'lambda_float':model['lam'],'nu_exact':[fstr(v) for v in model['nuF']],'nu_sum':fstr(sum(model['nuF'])),'N':N,'n':4,'support_union_volume_exact':fstr(unionvol),'support_union_volume_float':float(unionvol),'score_Psi_source_check':model['psi_source_check']},
      'mesh_contract':{'m':[4,8],'evaluations':{'4':len(all_rows['4']),'8':len(all_rows['8']),'total':sum(map(len,all_rows.values()))},'orbit_symmetry':'only coordinate swaps 1<->3 and 2<->4','weight':'orbit/(m^4*k(x)); exact rational k from six closed hard boxes','weighted_support_volume_diagnostic':voldiag,'true_union_volume':float(unionvol),'weight_minus_true_union':{k:v-float(unionvol) for k,v in voldiag.items()}},
      'x0_control':control,'summaries':stats,'coarse_fine_absolute_differences':diffs,'mp70_shortlist_count':len(mpchecks),'mp70_checks':mpchecks,
      'near_policy':'relative margin <=1e-10; exact rational support/k/hardmass decisions; mp70 shortlist is local consistency only, not certification',
      'runtime_seconds':round(time.time()-start,3),'execution_audit':{'producer_invocations':4,'failed_invocations':1,'completed_invocations':3,'adopted_result_invocation':4,'kernel_evaluations':8376,'mp70_checks':len(mpchecks),'exact_overlap_weight_postprocess_calls':3,'exact_overlap_weight_postprocess_failed':1,'exact_overlap_weight_postprocess_completed':2},'point_records':all_rows}
    out['producer_sha256']=sha(Path(__file__));out['plan_sha256']=sha(ROOT/'receiver_numeric_plan.md')
    add_corrected_overlap(out,model['positions'])
    detail=Path(args.detail_output);detail.parent.mkdir(parents=True,exist_ok=True);detail.write_text(json.dumps({'point_records':out['point_records'],'corrected_overlap_weights':out['corrected_overlap_weights']},separators=(',',':'))+'\n')
    out['detail_output']={'path':str(detail),'sha256':sha(detail),'bytes':detail.stat().st_size};out.pop('point_records',None)
    target=ROOT/'receiver_probe.json';target.write_text(json.dumps(out,separators=(',',':'))+'\n');print('wrote',target,target.stat().st_size,detail,detail.stat().st_size)
if __name__=='__main__':main()
