# R151 主接收几何检查点：相反核检验的共同来源交换

状态：本轮没有得到新的根阶接收估计，不登记新增付款。以下保存实际完成的直接空间归约、明确的粗价，以及尚缺的具体联合控制。它不同于再增加一个逐行门，也没有声称 R150 必要模型为 FULL 反例。R151 辅助切口估计由其他稿件负责，本稿不重证或领取其费用。

## RG1. 原目标与读取范围

实读本轮 `geometry_contract.md`，沿用已经读过并核算的 R148 连续接收包络、R149 原 bad 容量和 R150 三门。没有扫描更多历史或引用新论文。

设 Ω₃ 是原合法未付正域再交 R150 三门的严格补集。沿原记号

\[
\mathfrak h_t(v)=L_tB_t(v),\quad
\ell_v=\operatorname*{ess\,sup}_r\mathfrak h_r(v),\quad
\kappa(t)=\lfloor\log_2(e_t/e_g)\rfloor,
\]
\[
\Omega_3\subset\left\{r_t(v)<2Nm\rho_v
\min\!\left(\ell_v,L_g(\kappa+1)(\kappa+2)2^{-\kappa},
2\sqrt{\ell_v\mathfrak h_t(v)}\right)\right\}.
\tag{RG1}
\]

N=N_n(1−s) 为 R148 的实际 softness 分段常数。这里没有用 RG1 推导每行 O(1/N)。目标仍是原整份 Ω₃ 交通，经真实 dx、原 β、ν、j、尺度和 history 聚合后的根阶多对数费用。

固定 (ω,V,j,y,t) 后，Π_t、w_t、e_t 和 k_t 不依 x；相反，实际 g、s、L、Q、terminal 分类、ρ 及 Ω₃ 均仍依 x。只对前一组量使用 Tonelli 提到接收积分外。

## RG2. 相反检验的准确空间形状

在非零 terminal 来源上定义

\[
F_v(x)=\frac{KQ_x^*(v)}{w_{g(x)}(y,v)},
\qquad F_u(x)=\frac{KQ_x^*(u)}{w_{g(x)}(y,u)}.
\tag{RG2}
\]

这些使用同一个实际三核 Q*=(K₁+K₂+J)/3 和实际 g。原 good-v/bad-u 门准确要求

\[
\boxed{F_u(x)<p(x-y)\le F_v(x).}
\tag{RG3}
\]

因此两门是同一个接收核 p 与两个原来源的相反检验，不是两个独立概率事件。不能分别对 F_v、F_u 或 Q_E 取最有利上确界。ρ_v 保留原共同 α：ρ_v=[1−(DK₀(v)+αJ(v))/(TA_v)]₊，并在原不合资格处为零。

先仅以原 hard 帽 q^{-1}∫h_Raωdν≤16/3 做合法正上界，仍保留所有不依外 hard z 的实际门。将 Ω₃、Ψ、FA 和剩余历史依原变量记为 G_t(x;v,u)∈[0,1]，其中包括 RG3；若某门依 z，则只在这一步明确放松为≤1。于是

\[
2\Lambda P(\Omega_3)\le\frac{32\Lambda}{3}
\mathbb E\sum_{V,j}\int d\beta_V(y)\frac{dt}{t}
\iint\delta_t(v,u)\,\mathcal C_t(v,u)\,d\Pi_t(v)d\Pi_t(u),
\tag{RG4}
\]
\[
\mathcal C_t(v,u)=\int p(x-y)\rho_v(x)
G_t(x;v,u)1_{\{j(x)=j\}}\,dx.
\tag{RG5}
\]

原实际窗口也在 G 中。RG4 的系数为2Λ乘16/3；两后验仍原样存在，没有把 β 换成 ν。

## RG3. 实际完成的来源交换：消逆核而不伪造独立性

定义只保留 terminal/储备资格的对称非负函数

\[
R_t(x;v,u)=\rho_v(x)1_{\{v\in S_g,\ u\in D_0\}}
+\rho_u(x)1_{\{u\in S_g,\ v\in D_0\}}.
\tag{RG6}
\]

ρ 在不合 terminal 资格处按原定义置零，故这仍是同一共同 α 上的函数。对同一 Π_t² 交换 v,u（交换必须连同全部来源标签），有严格正上界

\[
\iint\rho_v\delta_t(v,u)G_t(v,u)\,d\Pi_t^2
\le\frac12\iint|k_t(v)-k_t(u)|R_t(x;v,u)\,d\Pi_t^2.
\tag{RG7}
\]

证明：左边先去掉除 terminal/ρ 以外的正门；其交换式与原式取平均。每个有方向的正 score 差≤绝对差，即得 RG7。没有交换 y 与 v，没有假设 Π 坐标独立。若要保持原 Ω₃、Ψ、FA 的收益，应在两个对称项中分别保留原门和交换后的门；不可只交换 ρ。

由此产生一个具体的、无逆 K₀ 矩的充分空间问题：控制

\[
\mathcal D_{j,y,t}(v,u)=\int 1_{\{j(x)=j,\ t\in J_j(x)\}}
 p(x-y)R_t(x;v,u)\,dx,
\tag{RG8}
\]

并在原 Π_t²、dt/t、β 下积分 |k_t(v)−k_t(u)|。这里 R 仅在两个相反检验 RG3 或其交换成立时非零。源/接收交换没有生成额外 e^{-1}、逆核或重新归一化来源。这是本轮确认可用的估计顺序；RG8 本身不是已付的新预算。

## RG4. 已有工具真正给出的费用

现有 JT13/CS10 只能在进一步去掉 RG3、ρ 等收益后控制 RG8。逐行以 δ≤n、good/bad 互斥且 Π 概率给

\[
\iint\rho_v\delta_t(v,u)1_{S_g}(v)1_{D_0}(u)d\Pi_t^2
\le n\Pi_t(S_g)\Pi_t(D_0)\le n/4.
\]

时间窗包含于原共同 [a,b] 且 b/a≤2，故源时间帽为 n log2/4。此时才可合并唯一 j，再用 JT13 得

\[
\boxed{2\Lambda P(\Omega_3)
\le8\Lambda n\log2\,(2n+3)D_nW_\beta,
\qquad D_n\le3\sqrt n.}
\tag{RG9}
\]

它是 O(n^{5/2}) 的旧粗级别，不是目标。对单个 near-soft 带上端 D、A=√nD，CS10 的正确同类价格为

\[
\frac{8\Lambda}{3}n\log2\,\mathcal E_n(D)W_\beta
\le\frac{256\Lambda}{3}n^{3/2}\log2\,(1+A)^2W_\beta.
\tag{RG10}
\]

R148 在已付门上用整窗1/(2N)抵消了 (1+A)²；当前 Ω₃ 上没有同一行帽，不能继续调用这个抵消。也不能先把 Π_t 或 R_t 中依 j 的来源几何删掉，再免费用唯一 j。

## RG5. 尚缺的具体控制，以及下一步应避免的误操作

需要的是 RG8 中**相反核检验的联合接收质量**与 score 差/整窗通量的耦合，不是 p 的另一个无权包络。以下具体步骤当前没有依据：

1. 对每个固定 s,L 的核使用 ∫P_{s,L}=1 后，直接代入原 x 依赖选择器。RG3、g、ρ、Q_E 同时随实际参数变化；固定参数概率质量不能支付其选择。
2. 将两个来源的 good/bad 事件分开平均。它们必须以 F_u<p≤F_v 的同一 p 夹层出现；分别用 Q_v 或 Q_u 的独立最优上界，会丢失唯一有希望支付 score 的空间相关。
3. 以两个归一核的 L¹ 距离直接控制此夹层的 p 质量。没有相对检验余量或对实际 F_v/p≈1 水平集的测度控制，这个推断并不由三角不等式成立；本轮没有证明原交通可支付该水平集项。
4. 把 CS10 的两参数 FTC 直接用于 pT_rem。其导数还会产生 terminal 检验水平集、共同 α/ρ、窗口和原 history 的变化；旧 CS10 只控制核本身的 regular 与 hard-face TV。没有证明这些新增项的符号、变差或原外价，不能删除它们。

因此，下一轮可检验的主几何对象已明确为：同一原三核下的相反检验夹层 RG3，带原 α 余权的接收质量 RG8，及它与 |k_t(v)−k_t(u)| 和实际时间的共同平均。若先去掉这两个相关因素，只能恢复 RG9/RG10；再加一个逐行门不能解决本稿的目标。本轮未得到此共同平均的根阶界，也未发现可吸收的 εX 负账，故不补造付款声明。

本稿固定原 ν 及全部归一量/gate，仅对非负积分使用截断；不截断 ν 后重算 Π、ρ 或 gate 并声称单调极限。原负项、futurebad、Ndel 和所有既有付款继续原位保留。
