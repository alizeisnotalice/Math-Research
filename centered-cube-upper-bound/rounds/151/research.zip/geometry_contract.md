# R151 接收几何最小公式包

目的：为主代理/Astra 的联合接收估计提供已存公式、变量关系与合同边界。此文件只作历史定位，不新增证明。以下把“原交通母式”“已审的接收包络”“条件 hard 子支”分开；有限模型或作者草稿不提升成一般已证付款。

## 1. 坐标、真实接收核和共同来源权重

### 原交通母式（R128 RT1–6；R140 β–ν contract）

对固定合法实际行 (r=(\omega,V,j,x,y,z,\text{history}))，外接收测度为

\[
d\mathcal T_I(r)=1_I1_{\{j(x)=j\}}q^{-1}
P_{s(x),L(x)}(x-y)\,h_{R(x)}(x-z)\,a_\omega(x,y,z)\,dx\,d\beta_V(y)\,d\nu_V(z).
\]

变量不能合并：(x) 是实际接收点；(y) 是外层 soft / β 来源，且唯一 (p) 核是 (p=P_{s,L}(x-y))；(z) 是外层 hard / ν 来源，带真实 (h_R(x-z)) 与历史因子。内层 good (v) 和 auxiliary bad (z') 仍以 (d\nu(v)d\nu(z')) 积分，二者不是外部 (y,z) 的同义记号。

原 (a_\omega\in[0,1]) 保留 hard 资格、完整历史与其余原门；原因子依赖实际 ((x,y,z,\omega))，不能按辅助 (z')、逐时 score 层或当前外 hard (z) 重新选择。(d\beta_V(y)) 与 (d\nu_V(z)) 不可交换或合并；β−ν 余额仍保留。R128 RT1 明确外测度为 (dx,d\beta(y)d\nu(z))，R140 的来源审计也指出 (a_\omega) 不是把 (y,z) 识别成一点的因子。

### 一维真核与尺度化产品核

R128 RT4–6（`joint_receiver_tail.md` 第51–83行）给出

\[
h_1=1_{[-1/2,1/2]},\quad w(u)=\int_0^1e^{-|u|/r}\,dr,\quad \phi=h_1*w,
\quad p_s=(1-s)h_1+s\phi,
\]
\[
P_{s,H}(x-v)=H^{-n}\prod_{i=1}^n p_s((x_i-v_i)/H).
\]

这里 (P_{s,L}) 就是实际 receiver kernel：(p(x,y)=P_{s,L}(x-y))。核包括硬面及软卷积，不是 Gaussian，也不是只用纯 soft 因子。R136 数值源实现同一坐标/尺度定义：`research.zip` 成员 `centered_cube_round136_20261014/active_traffic_v2.py` 第31–55行定义 `kernel(s,H,z)` 为逐坐标乘积并逐源计算 K0/K1/K2/J；被调用的真实 φ 为 R135 成员 `centered_cube_round135_20261014/real_joint_numeric.py` 第18–34行的 E3 公式。

R128 RT5 定义同一实际 (x) 上的三项 FIRST 测试

\[
K_1(v)=P_{s,L}(x-v),\quad K_2(v)=P_{s,L^+}(x-v),\quad
J(v)=K_3(v)=P_{1,b}(x-v),\quad L^+=\min(b,(1+1/n)L),
\]
\[
Q_x^*(v)=\frac{K_1(v)+K_2(v)+J(v)}3.
\]
共同 low-kernel

\[
H_0=\sqrt{LR}\,c_j^{-1/2}(1-s+s\phi(1/2))\ell^{1/(2n)},\quad
H_* =\min(b,H_0),\quad \widehat H=\max(a,H_*),
\]
\[
K_0(v)=P_{s,\widehat H}(x-v),\qquad
T=\frac{c_j^{n/2}}{(\sqrt{LR})^n\sqrt\ell},\qquad \ell=1+\log n.
\]
R128 RT5 的原 good/bad 门是 (p(x,y)w_g(y,v)\le KQ_x^*(v)) 与严格反向侧 (>KQ_x^*(z'))，其中 `K` 按原行冻结；FIRST 给 ∫K0 dν,∫Jdν,∫Q*dν≤q，不给低核子域的反向质量界。R140 JT1 使用对应原 capture 记号。

### (w_t)、posterior 与坐标依赖

R128 RT4 定义

\[
F(u)=\max(h_1(u),\phi(u)),\quad C(d)=\int_{-1/2}^{1/2}F(u-d)du,
\quad \alpha_i(y,v)=\frac b{c_j}C(|y_i-v_i|/b),
\]
\[
w_t(y,v)=\prod_i\min\{1,\alpha_i(y,v)/t\},\quad
Z_t=\{v:w_t(y,v)>0\text{ 且满足原存活门}\},\quad
 d\Pi_t(v)=e_t(y)^{-1}1_{Z_t}w_t(y,v)d\nu_V(v).
\]
因此 (w_t,e_t,\Pi_t,Z_t) 依来源差 (y-v)、原比例带 (j,V)、时间 (t) 和固定 ν 构造，发生在 receiver (x) 积分之前；它们不依赖 (x) 或外 hard (z)。固定 ((\omega,V,j,y,t)) 后这些项可提出 (x)-积分。相反，(s(x),L(x),R(x),H(x),D_g,S_g,w_g,A,\rho)、当前 good/bad、FA/Psi 与历史门仍依实际行/接收点，不能免费提出或以 Π_g 代 Π_t。

(w_t) 的输入差 (y-v) 与接收核的差 (x-y) 不同；外 hard 的 (x-z) 也不同。任何核比或条件化估计都必须保留这三个实际几何位移。

## 2. hard 中间段与 (a_\omega) 合同

### 通用原 hard/source 合同

R128 RT1–3 保留真实 (h_R(x-z)a_\omega(x,y,z),d\nu(z))；ν hard 支持及历史只给原外来源。辅助内来源 (z') 只参加 (\Pi_t) 与 score/Psi/FA 积分，不继承原 hard capture/history。原负项不附正项 FA/ρ 门，正负账不得混用。

R140 `beta_source_contract.md` 第13–17行从 R117 母式核对 β 与 ν：

\[
 d\mathcal T=q^{-1}P_{s,L}(x-y)h_R(x-z)a_\omega(x,y,z)
 dx\,d\beta_V(y)d\nu_V(z),\quad 0\le a_\omega\le1.
\]

该审计强调 (a_\omega) 保留原全部门；未证明辅助点取得原硬资格，也未提供将 ν 换成 β 的接桥。

### R140 已审的一个真实 hard 中间子支（有条件，非全域）

R140 `joint_transport.md` 第216–245行的 JT8 是可直接引用的条件合同：在**原R139已付支补集**内，保留原完整时间窗 (t\in J_{far})、原低-score、FA/Psi/ρ 与 hard 历史 (a_\omega)，并限制

\[
H<L^+,\quad C_J(v)\le3,\quad R>L,\quad H_0\ge a,
\quad z\in Q_H(x),\quad c_j^{n/2}\le(n+1)^{-2}.
\]

(Q_H) 是 hard core；整份 (\eta_0=K_0\nu/q=\eta_U+\eta_R) 一并允许，不能把捕获份额、储备份额和总份额各算一遍。这里选择条件依共同 (j) 和当前实际行，在外 (z) 积分前定下，不可逐 (z) 重选。JT16 已审出的子支费用为

\[
2\Lambda P_{core,*}\le25\Lambda\sqrt{n\ell}\,W_\beta,
\qquad \ell=1+\log n.
\]

JT8 的范围仅覆盖该条件 core 支；原R139已付部分先去重，JT8未覆盖的 hard shell、未满足 `C_J≤3` /尺度限制及其余大Γ分支不由此获付。R139 既有 Γ 小支另有条件付款，不等于上述完整 hard core 合同。

### 来源捕获重写：结构已审，别当作额外付款

R140 JT2–5（`joint_transport.md` 第24–75行）将 (K_0\nu/q=\eta_0=\eta_U+\eta_R)，其中 η_U=Uν/(Dq)、η_R=(DK0-U)ν/(Dq)；外核转换为

\[
q^{-1}h_R(x-z)d\nu(z)=\frac{h_R(x-z)}{K_0(x-z)}(d\eta_U+d\eta_R)(z),
\]

并精确保留捕获密度 (d\eta_U/d\Pi_t=(T e_t/(Dq))(A/w_t)c)，(c=U/(TA))。JT5 将原三来源正交通精确写成对外hard (z) 与内 good/bad 来源的 (\Pi_t^{\otimes3}) 积分，同时保留 (h_R/K_0)、(A/w_t)、两份内来源 (e_t^{-1}) 和真实 (a_\omega,G_t)。JT5–10 是正确分解/桥接恒等式与条件界；R140 文首说大Γ一般闭合未得，JT10 明说捕获桥自身不是整类付款。

## 3. 已审连续接收包络：JT13 / CS10 的适用边界

### JT13：全 (s) 与固定比例带尺度网格

R140 `joint_transport.md` JT13（第177–186行；引用 R117/R139 已证工具）给

\[
D_n=1+\frac\pi2\sqrt n\le3\sqrt n,\qquad
\int_{\mathbb R^n}\sup_{s\in[0,1],L\in[a,b]}P_{s,L}(x-y)dx
\le3(2n+3)D_n.
\]

这是固定尺度带 ([a,b]) 的**真实 Lebesgue receiver envelope**，含连续 softness 和至多 (2n+3) 个向上 (L)-网格点。证明账：固定 (L) 的 softness variation ∫|∂sP|≤√n/√(s(1−s))，对 (sin[0,1]) 积分并加端点质量得 (D_n)；(L) 向上 γ=1+1/n 网格，(P_{s,L}≤\gamma^nP_{s,L_{grid}}≤3P_{s,L_{grid}})。JT13 本身付了连续 receiver 选择器费用，不意味着任何仍含 (z,v,u,t,j) 的交通可先对 (j) 或来源免费上确界。

R140 JT14（第190–204行）给正确回代顺序：先对外 hard 与两份 Π 内来源积分，得到与 (j,x,y,t,V) 无关的共同数值 (I_j≤B)；再放宽全部 (J_{far,j}\subset[a,b])、用 (\sum_j1_{j(x)=j}≤1)、(\int_a^b dt/t≤\log2)、JT13 与原 (W_\beta=E\sum_V\|\beta_V\|)。输出 (2\Lambda P≤6\Lambda B\log2(2n+3)D_nW_\beta)。若没先消去来源与 (j)-依赖，不能套这条包络。

### CS10：near-one 的连续 soft/scale 包络

旧原件 [next_spatial_compensated_split.md](/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/high_marked_cover/next_spatial_compensated_split.md) CS9–10，第100–120行，给 (0≤d<1/2)、固定任意 (y)、(b/a≤2)：

\[
\int\sup_{1-d≤s≤1,\ a≤L≤b}P_{s,L}(x-y)dx
\le1+10\sqrt n d+\log2\Big[2nd+\sqrt{28n}
+d\{10\sqrt n\sqrt{28n+n^2d^2}+6n+10nd\sqrt n\}\Big].
\]

它通过两参数 FTC（softness 与 log-scale）控制完整混合导数 TV，硬面 trace 跳跃保留在 CS9；是一参数两个估计简单相加无法替代的联合包络。定 (A=\sqrt n d) 后，R148 `capacity.md` 第36–48行简化为

\[
\mathcal E_n(d)≤\sqrt n(5+53A+14A^2)≤32\sqrt n(1+A)^2.
\]

**独立审计状态：** `compensated_split_review.md` 第1–5、54–64行判 CS1–10 与独立复算通过；R148 `source_cs10_review.md` 第98–127行审计旧 CS10 集成草稿也通过。但支付边界须精确：CS10 用于原完整平滑 FIRST 的 TOP/LOWTRACE 输出集合删去，付费 (O(\sqrt n\log n)W_{full})；review 第110–114行确认仍余原 CP (R_*) 在 HIGHTRACE 上，严格 hardeligible/history 等资格保持，残余没缩小、没付款。因此不能拿 CS10 宣称完整 receiver 弱型端点已闭合，也不能把它直接当作含 hard (h_R(x-z)a_\omega) 因子的 JT13。

## 4. R136 接收尾包络的区别与审计状态

R136 `research.zip`（21成员；见该轮 README）中的 `active_capacity_audit.md` §AB8–17 / `fractional_kernel_envelope.md` 给共同 α 容量下的真实核逆矩估计，并有固定尺度块内可测核参数选择器包络。AB12–17 独审通过：真实核尾和尺度因子正确、保留两份 (e_t^{-1})、(T,Q_J,q,h_R,a_\omega)、原 history 与 (d\beta\,d\nu)。但是原稿明确指出 (1<r<3/2) 的 (B_r) 可能为 (+\infty)，其核价仍有指数维度，必要来源尾与外交通仍待统一支付。它不是 (P_{s,L}) 的无条件连续 (dx) weak-type receiver envelope；也不替代 JT13/CS10。

R136 数值 `active_traffic_v2.py` 是 true-kernel finite-source FA/Psi 必要模型。其 v2 改动在 `protocol_v2.md` 说明只是补入极小 core hard source，使 ∫ h_Rν 正；仍未实现 continuous ν≤f、full future FIRST、FULL/history 或真实 (h_Ra_\omega d\beta dx) 交通。数值积分的多精度相合不能提升其范围。

## 5. 核验文件、归档成员与审计标签

- **原源、尺度、FIRST 及 (w_t) 坐标约定：** R128 `joint_receiver_tail.md` RT1–6，第20–83行；状态为原合同/历史证明输入，不能删除门。
- **R140 hard/source 核与 β/ν 条款：** `joint_transport.md` JT1–8，第5–75、177–245行；结构与 JT13/14 经 R140 `transport_prior_audit.md` 第137–209行审计。JT16/17 是有条件已付子支，非全域付款。
- **R136 原包核矩：** R136 `research.zip` 成员 `centered_cube_round136_20261014/active_capacity_audit.md`（ACA/AB）、`fractional_kernel_envelope.md`、`protocol_v2.md`、`active_traffic_v2.py`；README 说明相应核矩独审 PASS 并明确指数维数/母式费用未闭。
- **连续联合 CS10：** `cube_general_20261003/high_marked_cover/next_spatial_compensated_split.md` 第100–120行；`compensated_split_review.md` 是独立审计，PASS 但明确 HIGHTRACE 残余未付。

归档缺失记录：R136 的 proof/协议/脚本在 rounds/136/research.zip 中；完整数值执行结果与部分审计记录在 Desktop/T 输出目录，README说明 ZIP 只含必要摘要/复现材料。R140 原文当前定位于 Desktop/T/output 的工作文件；此索引只按它们列出的章节与行引用，不声称每个输出工作文件都作为 R140 `research.zip` 成员归档。未读取或补造缺失成员。
