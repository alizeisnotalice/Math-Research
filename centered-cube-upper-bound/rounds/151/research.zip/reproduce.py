"""R151 archive replay. Run with Python containing NumPy and the documented local SciPy/mpmath runtime."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--rounds',required=True,type=Path);ap.add_argument('--destination',required=True,type=Path);a=ap.parse_args();dst=a.destination.resolve();dst.mkdir(parents=True,exist_ok=False)
for n,member,rel in [(139,'active_traffic_v2.json','centered_cube_round136_20261014/active_traffic_v2.json'),(141,'numeric_joint.json','centered_cube_round141_20261015/numeric_joint.json'),(142,'numeric_receiver.json','centered_cube_round142_20261015/numeric_receiver.json')]:
 with zipfile.ZipFile(a.rounds/str(n)/'research.zip') as z:
  p=dst/'inputs'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(member))
for f in ['cut_check.py','receiver_probe.py','receiver_numeric_plan.md','receiver_verify.py']:shutil.copy2(ROOT/f,dst/f)
subprocess.run([sys.executable,str(dst/'cut_check.py')],check=True)
assert json.loads((dst/'cut_check.json').read_text())==json.loads((ROOT/'cut_check.json').read_text())
subprocess.run([sys.executable,str(dst/'receiver_probe.py'),'--input-root',str(dst/'inputs'),'--detail-output',str(dst/'receiver_probe_points.json')],check=True)
original=json.loads((ROOT/'receiver_probe.json').read_text());fresh=json.loads((dst/'receiver_probe.json').read_text())
ignored={'inputs','runtime_seconds','execution_audit','detail_output'}
for k in original:
 if k not in ignored:assert original[k]==fresh[k],k
assert hashlib.sha256((dst/'receiver_probe_points.json').read_bytes()).hexdigest()==original['detail_output']['sha256']
r=subprocess.run([sys.executable,str(dst/'receiver_verify.py'),'--summary',str(dst/'receiver_probe.json'),'--detail',str(dst/'receiver_probe_points.json'),'--input-root',str(dst/'inputs')],check=True,capture_output=True,text=True)
assert json.loads(r.stdout)['status']=='PASS';(dst/'verification.json').write_text(r.stdout)
print('PASS: all mathematical summaries, byte-identical receiver detail, exact cut checks, independent receiver verification. No certified quadrature error or FULL claim.')
