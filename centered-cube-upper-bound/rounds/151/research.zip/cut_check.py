#!/usr/bin/env python3
"""Exact Fraction pressure checks for the R151 finite cut identities.

This is a finite diagnostic only. It is not a proof of the proposed lemma.
Standard library only; run from any directory with Python 3.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse
import json
import random

OUT = Path(__file__).with_name("cut_check.json")
SEED = 151015


def fs(x):
    return f"{x.numerator}/{x.denominator}"


def weight(src, t):
    ans = F(1)
    for a in src["thresholds"]:
        ans *= min(F(1), a / t)
    return ans


def alive(src, t):
    return src["delete_time"] is None or t < src["delete_time"]


def kcount(src, t, side="strict"):
    if side == "right":
        return sum(a <= t for a in src["thresholds"])
    return sum(a < t for a in src["thresholds"])


def mass_at(src, t):
    return src["mass"] * weight(src, t) if alive(src, t) else F(0)


def profile(sources, t, r, side="strict"):
    A = B = KA = KB = e = F(0)
    for src in sources:
        m = mass_at(src, t)
        e += m
        if src["kind"] == "G":
            k = kcount(src, t, side)
            if k > r:
                z = src["rho"] * m
                A += z
                KA += k * z
        elif src["kind"] == "D":
            k = kcount(src, t, side)
            if k <= r:
                B += m
                KB += k * m
        # e_g is the full surviving source mass at the terminal time, so its
        # accumulation is handled by a separate profile call at g below.
    return A, B, KA, KB, e


def make_source(kind, thresholds, mass, rho=F(0), delete_time=None):
    return dict(kind=kind, thresholds=thresholds, mass=mass, rho=rho,
                delete_time=delete_time)


def test_at(sources, t, tau, g, c, side="strict"):
    n = len(sources[0]["thresholds"])
    rows = []
    for r in range(n + 1):
        A, B, KA, KB, e = profile(sources, t, r, side)
        eg_terminal = profile(sources, g, r)[4]
        _, Bt, _, _, _ = profile(sources, tau, r, "strict")
        S = A + B + c
        drift = (B * KA - A * KB + c * KA) / (S * S) if S else F(0)
        lower = A * (B + (r + 1) * c) / (S * S) if S else F(0)
        d = Bt / (Bt + (r + 1) * c) if Bt + (r + 1) * c else F(0)
        lhs = A * B / (e * e) if e else F(0)
        rhs = 4 * d * drift
        # These are the explicit hypotheses used in the finite contract.
        contract = (c > 0 and c <= eg_terminal
                    and tau <= t <= g and Bt >= B and S <= 2 * e)
        rows.append(dict(r=r, A=fs(A), B=fs(B), KA=fs(KA), KB=fs(KB),
                         B_tau=fs(Bt), c=fs(c), e=fs(e), e_g=fs(eg_terminal),
                         S=fs(S), d_r=fs(d), drift=fs(drift),
                         drift_lower=fs(lower), lhs=fs(lhs), rhs=fs(rhs),
                         lower_pass=drift >= lower,
                         inequality_pass=(lhs <= rhs) if contract else None,
                         contract_valid=contract,
                         S_le_2e=(S <= 2 * e)))
    return rows


def check_jump(sources, t, c):
    n = len(sources[0]["thresholds"])
    rows = []
    for r in range(n + 1):
        Am, Bm, *_ = profile(sources, t, r, "strict")
        Ap, Bp, *_ = profile(sources, t, r, "right")
        a, b = Ap - Am, Bm - Bp
        Sm, Sp = Am + Bm + c, Ap + Bp + c
        lhs = (Ap / Sp - Am / Sm) if Sm and Sp else F(0)
        rhs = (a * (Bm + c) + Am * b) / (Sm * Sp) if Sm and Sp else F(0)
        rows.append(dict(r=r, A_minus=fs(Am), B_minus=fs(Bm),
                         A_plus=fs(Ap), B_plus=fs(Bp), a=fs(a), b=fs(b),
                         delta_phi=fs(lhs), formula=fs(rhs),
                         monotone_jumps=(a >= 0 and b >= 0),
                         identity_pass=(lhs == rhs)))
    return rows


def atom(thresholds, kind, mass, rho=F(0), delete_time=None):
    return make_source(kind, list(map(F, thresholds)), F(mass), F(rho),
                       F(delete_time) if delete_time is not None else None)


def fixed_cases():
    return [
        ("initial_minimal", [atom([F(1, 2)], "G", 1, F(1, 2)),
                             atom([F(3, 4)], "D", 1)], F(1, 4), F(1, 2)),
        ("initial_mixed", [atom([F(1, 3), F(1, 2)], "G", F(3, 2), F(2, 3)),
                           atom([F(1, 2), F(3, 4)], "D", F(5, 3)),
                           atom([F(1, 4), F(1)], "X", F(1, 2))],
         F(1, 3), F(3, 4)),
        ("initial_rho_zero", [atom([F(1, 4), F(1, 2), F(3, 4)], "G", 2, 0),
                              atom([F(1, 2), F(3, 4), F(1)], "D", 1)],
         F(1, 2), F(1)),
    ]


def random_case(rng, idx):
    n = rng.randint(1, 32)
    count = rng.randint(3, 12)
    levels = [F(1, 4), F(1, 3), F(1, 2), F(2, 3), F(3, 4),
              F(1), F(5, 4), F(3, 2), F(7, 4), F(2)]
    sources = []
    for i in range(count):
        kind = "G" if i == 0 else ("D" if i == 1 else rng.choice(["G", "D", "X"]))
        thresholds = [rng.choice(levels) for _ in range(n)]
        mass = F(rng.randint(0, 9), rng.randint(1, 7))
        if i < 2 and mass == 0:
            mass = F(1, rng.randint(1, 7))
        rho = F(rng.randint(0, 6), 6) if kind == "G" else F(0)
        delete = None
        # Extras may disappear before g; terminal G,D sources never do.
        if kind == "X" and rng.randrange(3) == 0:
            delete = rng.choice([F(1, 2), F(1), F(3, 2)])
        sources.append(make_source(kind, thresholds, mass, rho, delete))
    return n, sources


def source_json(src):
    return dict(kind=src["kind"], mass=fs(src["mass"]),
                rho=fs(src["rho"]),
                thresholds=[fs(a) for a in src["thresholds"]],
                delete_time=fs(src["delete_time"]) if src["delete_time"] is not None else None)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--full", metavar="PATH", type=Path,
                        help="also write every exact case and row to PATH")
    args = parser.parse_args()
    cases = []
    for name, sources, t, c in fixed_cases():
        tau, g = F(1, 4), F(2)
        eg = profile(sources, g, 0)[4]
        if c > eg:
            c = eg
        times = sorted({t, F(1, 2), F(1), F(3, 2), F(2)})
        times = [x for x in times if tau <= x <= g]
        rows = []
        for x in times:
            egx = profile(sources, g, 0)[4]
            cx = min(c, egx)
            rows.append(dict(t=fs(x), checks=test_at(sources, x, tau, g, cx)))
        cases.append(dict(stage="initial", id=name, n=len(sources[0]["thresholds"]),
                          tau=fs(tau), g=fs(g), c=fs(c),
                          sources=[source_json(s) for s in sources], profiles=rows))

    # Simultaneous threshold crossings with a zero-mass extra source deleted at the event.
    t = F(1)
    sources = [atom([F(1, 2), t, t], "G", 2, F(1, 2)),
               atom([F(1, 3), t, t], "D", F(3, 2)),
               atom([F(1, 4), F(3, 4), t], "X", 1),
               make_source("X", [F(1, 2), t, t], F(0), F(0), None)]
    c = F(1, 3)
    pre_e = sum((mass_at(s, t) for s in sources), F(0))
    sources[-1]["delete_time"] = t
    post_e = sum((mass_at(s, t) for s in sources), F(0))
    eg = profile(sources, F(2), 0)[4]
    c = min(c, eg)
    jump_rows = check_jump(sources, t, c)
    cases.append(dict(stage="simultaneous_threshold_zero_mass_delete",
                      id="ties_and_zero_mass", n=3, tau="1/4", g="2", t=fs(t),
                      c=fs(c), sources=[source_json(s) for s in sources],
                      zero_mass_deletion_preserves_e=(pre_e == post_e),
                      jump_checks=jump_rows,
                      profile_checks=test_at(sources, t, F(1, 4), F(2), c)))

    rng = random.Random(SEED)
    expanded = []
    for idx in range(48):
        n, srcs = random_case(rng, idx)
        tau, g = F(1, 4), F(2)
        eg = profile(srcs, g, 0)[4]
        if eg == 0:
            # The first G source is positive, but its g-weight may be zero only if malformed.
            raise AssertionError("positive terminal G mass must give e_g>0")
        c = eg * F(rng.randint(1, 4), 4)
        times = sorted({F(1, 2), F(1), F(3, 2), F(2)} |
                       {a for s in srcs for a in s["thresholds"] if tau <= a <= g})
        checks = [dict(t=fs(t), checks=test_at(srcs, t, tau, g, c)) for t in times]
        # Also test every simultaneous threshold event by left/right limits.
        jumps = [dict(t=fs(t), checks=check_jump(srcs, t, c))
                 for t in sorted({a for s in srcs for a in s["thresholds"] if tau < a < g})]
        expanded.append(dict(id=f"expanded_{idx:02d}", n=n, source_count=len(srcs),
                             tau=fs(tau), g=fs(g), c=fs(c),
                             sources=[source_json(s) for s in srcs],
                             profiles=checks, jumps=jumps))

    all_profile_rows = [row for case in cases for prof in case.get("profiles", [])
                        for row in prof["checks"]]
    all_profile_rows += cases[3]["profile_checks"]
    all_profile_rows += [r for case in expanded for prof in case["profiles"] for r in prof["checks"]]
    all_jump_rows = cases[3]["jump_checks"] + [r for case in expanded for ev in case["jumps"] for r in ev["checks"]]
    summary = dict(
        initial_cases=len(cases) - 1,
        simultaneous_event_cases=1,
        expanded_cases=len(expanded),
        expanded_n_min=min(x["n"] for x in expanded),
        expanded_n_max=max(x["n"] for x in expanded),
        expanded_sources_min=min(x["source_count"] for x in expanded),
        expanded_sources_max=max(x["source_count"] for x in expanded),
        profile_rows=len(all_profile_rows),
        jump_rows=len(all_jump_rows),
        drift_lower_failures=sum(not r["lower_pass"] for r in all_profile_rows),
        cut_inequality_failures=sum(r["inequality_pass"] is False for r in all_profile_rows),
        contract_invalid_rows=sum(not r["contract_valid"] for r in all_profile_rows),
        jump_monotonicity_failures=sum(not r["monotone_jumps"] for r in all_jump_rows),
        jump_identity_failures=sum(not r["identity_pass"] for r in all_jump_rows),
        zero_mass_deletion_e_unchanged=cases[3]["zero_mass_deletion_preserves_e"],
        seed=SEED,
        scope="Exact finite Fraction pressure tests only; not a proof of the R151 lemma and no order fitting.")
    status = "PASS_FINITE_PRESSURE_TESTS" if not any([
        summary["drift_lower_failures"], summary["cut_inequality_failures"],
        summary["contract_invalid_rows"], summary["jump_monotonicity_failures"],
        summary["jump_identity_failures"]]) else "FAIL"
    assumptions = dict(e="all currently surviving source masses times w_t",
                       e_g="all sources surviving at g with weight w_g, including G,D,other terminal sources",
                       c="0<c<=e_g; no assumption e>=A+B+c",
                       B_tau="same cut B at tau; D sources are terminal and survive throughout",
                       extra_sources="may be deleted; only terminal G,D are permanent",
                       threshold_k="number of coordinates with a_i<t; right limit uses a_i<=t")
    configuration = dict(seed=SEED, initial_case_ids=[name for name, *_ in fixed_cases()],
                         event_case_id="ties_and_zero_mass", expanded_case_count=48,
                         expanded_n_range=[1, 32], expanded_source_count_range=[3, 12],
                         times="tau=1/4; finite snapshots and all interior threshold events through g=2",
                         cuts="computed r=0,...,n, including extra zero-cut r=n; target range is r=0,...,n-1",
                         arithmetic="exact fractions; all rows computed before summary is written")
    compact = dict(status=status, assumptions=assumptions, configuration=configuration,
                   summary=summary)
    if args.full is not None:
        full = dict(status=status, assumptions=assumptions, configuration=configuration,
                    summary=summary, initial_and_event_cases=cases, expanded_cases=expanded)
        args.full.parent.mkdir(parents=True, exist_ok=True)
        args.full.write_text(json.dumps(full, indent=2, ensure_ascii=False) + "\n")
    OUT.write_text(json.dumps(compact, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(dict(status=status, summary=summary,
                          full_output=str(args.full) if args.full else None), indent=2))


if __name__ == "__main__":
    main()
