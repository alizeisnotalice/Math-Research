# R151：正 score 切口的终端双组输运与三核容量注入

结论：给出全时间、任意共同来源下的 regularized cut 输运估计。它逐切口精确保留阈值注入，合法避开已删来源的归一化跳变，并产生新的调和切口因子 d_r。所得接收费用明确落在原共同 μ=Q*ν/q 的边界／阈值逆 r 矩上；未证明该费用的一般根阶外价。本文没有重新扫描反例，没有重述裸行1/N目标，也不重登记旧 SIA 方差身份。

## 1. 原对象、切口表示及待证命题

固定原有限合法行 ξ=(ω,V,j,x,y)，τ≤t≤h≤g。原 ν、p,q、三核

\[
 Q_v=\tfrac13\{P_{s,L}(x-v)+P_{s,L^+}(x-v)+J_b(x-v)\},\quad
 d\mu(v)=Q_vd\nu(v)/q,\quad C=Kq/p
\]

以及 E₊、D₀、ρ、共同 α 和所有接收选择器均沿实际行固定，不依外 hard 来源 z。E₊与D₀互斥且均含于Z_g；原 high 给 e_t≥e_g≥2C>0。保留

\[
 w_t(v)=\prod_i\min(1,a_i(y,v)/t),\quad
 k_t(v)=\#\{i:a_i(y,v)<t\},\quad
 e_t=\int_{Z_t}w_t\,d\nu,\quad
 d\Pi_t=1_{Z_t}w_t\,d\nu/e_t,
 \quad r_t(v)=KQ_v/(pw_t(v)).
\]

任选一个整窗固定来源子集 E_*⊂E₊，它须包含待估余部可能使用的所有good来源；可始终取E₊。例如当前余部仍在R149门补集内时，可取

\[
 E_*=E_+\cap\{r_\tau(v)<2N(s)m\ell_v\rho_v\}.
 \tag{ST1}
\]

这是从r_t不减得到的来源必要筛选；m、ℓ、ρ保持原值，不因筛选重新归一化。更细的time/pair/history门仍保留在原目标，下面只用其≤1作正上界。

以u=log t为时间变量，对r=0,…,n−1定义原裸切口质量

\[
 A_r(t)=\int_{E_*}\rho_vw_t(v)1_{\{k_t(v)>r\}}d\nu(v),\qquad
 B_r(t)=\int_{D_0}w_t(v)1_{\{k_t(v)\le r\}}d\nu(v).
 \tag{ST2}
\]

则不是不等式而是准确的层分解

\[
 \mathcal T_*:=\int_\tau^h\iint_{E_*\times D_0}
 \rho_v[k_t(v)-k_t(u)]_+d\Pi_t(u)d\Pi_t(v)\frac{dt}{t}
 =\sum_{r=0}^{n-1}\int_\tau^h\frac{A_r(t)B_r(t)}{e_t^2}\frac{dt}{t}.
 \tag{ST3}
\]

原完整正余部≤这个裸terminal槽，但没有把其负项、futurebad或删除来源吞入此记号。

**欲证命题。** 任选整窗固定的0<c≤e_g。构造精确正阈值费用J_r，使

\[
 \mathcal T_*\le4\sum_{r=0}^{n-1}d_r
 \{\Phi_r(\tau)-\Phi_r(h)+J_r\},\qquad
 d_r=\frac{B_r(\tau)}{B_r(\tau)+(r+1)c},\quad
 \Phi_r=\frac{A_r}{A_r+B_r+c}.
 \tag{ST4}
\]

以下证明对阈值原子、连续阈值分布及原Z_t删源均有效；切口端点统一使用右态score。dt/t积分不受单点版本影响。特别可取c=e_g；原high e_g≥2Kq/p另保证c=2C合法，后者用于第4节与原三核容量的显式接合。不同c同时改变势、注入及d_r，本文不声称最终总帽对c单调。

## 2. 阈值注入的精确定义，不乘现成方差身份

令θ_r(v)为{a_i(y,v)}的第r+1小顺序统计量。同一来源在切口r恰于θ_r穿越一次；多坐标同时穿越时，在相应多个r各收费一次，准确保留重数。定义正原始注入测度

\[
 dI^G_r=\int_{E_*}\rho_vw_{\theta_r(v)}(v)
 1_{\{\tau<\theta_r(v)\le h\}}\delta_{\log\theta_r(v)}\,d\nu(v),
\]
\[
 dI^D_r=\int_{D_0}w_{\theta_r(v)}(v)
 1_{\{\tau<\theta_r(v)\le h\}}\delta_{\log\theta_r(v)}\,d\nu(v).
 \tag{ST5}
\]

ν可以任意相关；这些是来源的推前积分，不是独立坐标假设。右态初始化不再收费θ=τ；终点右态计θ=h。若用严格score的终点，则同时删除终点注入，不能混用。

置

\[
 K^A_r(t)=\int_{E_*}\rho_vk_t(v)w_t(v)1_{\{k_t(v)>r\}}d\nu(v),
\quad
 K^B_r(t)=\int_{D_0}k_t(v)w_t(v)1_{\{k_t(v)\le r\}}d\nu(v).
\]

由原权重FTC和来源Tonelli得到BV测度身份

\[
 dA_r=-K^A_rdu+dI^G_r,\qquad
 dB_r=-K^B_rdu-dI^D_r,
 \quad K^A_r\ge(r+1)A_r,\quad K^B_r\le rB_r.
 \tag{ST6}
\]

特别B_r本身非增。ST6只对固定terminal两组建立；没有把过滤门乘进SIA而遗漏测试函数变化。

**删源为何没有遗漏。** E_*与D₀均含于Z_g，故不会在[τ,h]被原Z_t删掉。ST2的原始分子没有删除跳变；Φ只依这两个分子和常数c，故也没有删除跳变。删除仍改变e_t、Π_t和实际交通，但证明只用始终合法的e_t≥A_r+B_r与e_t≥c。若任一组包含futurebad／以后被删来源，本结论不能照抄：ST6须加入该组删除测度，Φ亦有相应有符号跳。这里没有说原e_t的跳为零，而是选择了确实不受其跳变影响的双组比值。

## 3. regularized cut 身份与新调和因子

记S=A+B+c（本节省略r），定义非负漂移

\[
 D_r(t)=\frac{(B_r+c)K^A_r-A_rK^B_r}{S_r^2}
 \ge\frac{A_r\{B_r+(r+1)c\}}{S_r^2}\ge0.
 \tag{ST7}
\]

Φ的连续阈值注入费用为

\[
 dJ_r^{\mathrm{cont}}=\frac{B_r+c}{S_r^2}d(I_r^G)^{\mathrm{cont}}
 +\frac{A_r}{S_r^2}d(I_r^D)^{\mathrm{cont}}.
\]

上标cont表示去除原子的连续部分，包括绝对连续和奇异连续部分。若时刻s同时有good进入质量a≥0与bad离开质量b≥0（b≤B_−），则定义**同刻联合原子费用**

\[
 \boxed{\Delta J_r(s)=
 \frac{(B_-+c)a+A_-b}
 {(A_-+B_-+c)(A_-+B_-+c+a-b)}.}
 \tag{ST8}
\]

它恰等于Φ(A_−+a,B_−−b)−Φ(A_−,B_−)，非负且不依赖同刻good/bad的人为先后次序。令J_r为连续费用与所有联合原子费用之和。BV链式法则准确给

\[
 \boxed{\int_\tau^h D_r(t)\frac{dt}{t}
 =\Phi_r(\tau)-\Phi_r(h)+J_r.}
 \tag{ST9}
\]

右侧逐切口非负；终点项保留，因此终点才发生的阈值注入会被相应Φ_h抵消，没有无价领取整窗通量。

由于ρ≤1、E_*与D₀不交且都存活于Z_t，A_r+B_r≤e_t；再用所选c≤e_g≤e_t，得S_r≤e_t+c≤2e_t。这个比较没有删除跳变假设。又B_r(t)≤B_r(τ)，于是

\[
 \frac{A_rB_r}{e_t^2}
 \le4\frac{A_rB_r}{S_r^2}
 \le4\frac{B_r(t)}{B_r(t)+(r+1)c}D_r(t)
 \le4d_rD_r(t).
 \tag{ST10}
\]

ST3、ST9和ST10证明ST4。这一步保留了cK^A的真实负漂移贡献，因而多出d_r；若把cK^A提前丢掉，只能恢复无调和节省的普通切口望远镜。

令B^\mathrm{raw}_τ=∫D₀w_τdν、β₀=B^raw_τ/c，则

\[
 d_r\le\min\{1,\beta_0/(r+1)\},\quad
 \sum_{r=0}^{n-1}d_r\le\min\{n,\beta_0H_n\},
 \quad H_n=\sum_{j=1}^n1/j.
 \tag{ST11}
\]

这是真正的切口gap节省：当前bad raw质量相对于高门容量c有界时，高切口费用按1/(r+1)衰减。它不假定某个bad原质量小就有小后验；β₀使用的是实际共同w_τ与同一c。

## 4. 化为实际三核共同容量的边界／注入矩

为得到完全显式、可审的来源primitive，以下仅放大ST4，不称放大后费用已付。直接由ST8及连续导数，

\[
 J_r\le I_r^G((\tau,h])/c+I_r^D((\tau,h])/(4c),\qquad
 \Phi_r(\tau)\le A_r(\tau)/c.
 \tag{ST12}
\]

为证联合原子上界，可仅在证明中把同一Φ差写成先加入a、再移除b的两段差；第一段≤a/c，第二段的常数1/4来自A/[(A+B+c)(A+B-b+c)]≤A/(A+c)^2≤1/(4c)。这个分解只用于上界，J_r仍由顺序无关的ST8定义，不增加第二份来源收费。good项保持原ρ，未优化α。

对每个来源设

\[
 W_\tau(v)=\sum_{r<k_\tau(v)}d_r,
\quad
 W_{\mathrm{cross}}(v;f)=\sum_{r:\tau<\theta_r(v)\le h}d_rf(\theta_r(v)).
\]

原Q测度恒等式w_t dν/C=dμ/r_t准确给出

\[
 \boxed{\mathcal T_*\le(4C/c)\mathcal S_{cut},}
\]
\[
 \mathcal S_{cut}:=
 \int_{E_*}\rho_v\frac{W_\tau(v)}{r_\tau(v)}d\mu(v)
 +\int_{E_*}\rho_v\sum_{r:\tau<\theta_r(v)\le h}
 \frac{d_r}{r_{\theta_r(v)}(v)}d\mu(v)
 +\frac14\int_{D_0}\sum_{r:\tau<\theta_r(v)\le h}
 \frac{d_r}{r_{\theta_r(v)}(v)}d\mu(v).
 \tag{ST13}
\]

当取原high保证合法的c=2C时，ST13的因子4C/c=2；若取c=e_g，保留实际因子4C/e_g≤2。

这不是把“精确流积分”改名：右侧只由端点、每源各顺序统计阈值及原三核比值组成，来源时间积分已经消去。μ仍是原共同三核容量，不因E_*、切口或时间重新分配。ST13是可检验的正边界／注入上帽；没有任何j、x或β预算被假设免费。

一个较粗但输入明确的行帽如下。设A^raw_τ=∫E_*ρw_τdν、α₀=A^raw_τ/c。每个good来源的起始切口r<k_τ与窗内穿越切口互不相交；且w_θ≤w_τ。因此ST12–13又给

\[
 \boxed{\mathcal T_*\le
 4(\alpha_0+\beta_0/4)\sum_rd_r
 \le4(\alpha_0+\beta_0/4)\min\{n,\beta_0H_n\}.}
 \tag{ST14}
\]

所以α₀、β₀有绝对上帽的实际行有O(log(n+1))裸terminal时间交通帽。这比只据0≤k≤n的O(n log(h/τ))粗价更小，但并不是一般原行帽：high控制e_g/c，不控制e_τ/c；FIRST也不提供α₀、β₀的一般上界。本文没有用“实际I1行2NI>1”否定任何接收平均结论，也没有要求ST14为1/N。

## 5. 原ρ／α和实际接收x留下的准确费用

ST4、ST13均保留原ρ；在实际E₊上仍可代入原

\[
 \rho_v=\left(1-\frac{DK_{0,v}}{TA_v}\right)_+
 -\frac{\alpha J_v}{TA_v}>0,
 \qquad A_v=w_\tau(v)-w_h(v),
\]

共同bad余额αQ_J≥D∫D₀K₀dν也仍成立。本文没有分别优化α或把该余额作用到futurebad。若用CS把ST13中的bad阈值逆r矩转到K₀逆矩，必须付其原接收尾，不可把R149 GR6–12尚未支付的矩当作常数。

记

\[
 \mathcal H_{cut}(\xi)=\sum_rd_r
 \{\Phi_r(\tau)-\Phi_r(h)+J_r\}\ge0.
\]

原目标仍含全部真实hard、Ψ/FA、history及新旧已付补集。只为正上界放松额外z资格、保留a_ω并用原hard帽16/3后，ST4给

\[
 \boxed{2\Lambda P_{rem}\le
 \frac{128\Lambda}{3}\mathbb E\sum_{V,j}
 \int p(x-y)\,\mathcal H_{cut}(\omega,V,j,x,y)
 \,dx\,d\beta_V(y).}
 \tag{ST15}
\]

也可用ST13的可计算放大，得到

\[
 \boxed{2\Lambda P_{rem}\le
 \frac{128\Lambda}{3}\mathbb E\sum_{V,j}
 \int p(x-y)\,\frac{C(\xi)}{c(\xi)}\mathcal S_{cut}(\omega,V,j,x,y)
 \,dx\,d\beta_V(y).}
 \tag{ST16}
\]

取c=2C时ST16系数等于64Λ/3乘p S_cut；一般c保持显示的实际C/c，不能把依ξ的比值移出外积分。

β保持原外测度；dt/t与三份来源已按同一行处理，不能再乘一次log2。实际s,L,R,g,τ,h与唯一j选择都留在ξ，不可在H_cut或S_cut尚未取得共同帽前免费合并j。即便ST14为O(logn)，再直接乘原全参数接收包络仍有其维数费用；不能据此宣布根阶外价。

**准确未证命题**是ST15或ST16右侧≤εX+Cε√n polylog(2+n)Wβ。与旧SIA全来源注入相比，这里已把需求缩到：terminal good阈值带原ρ、terminal bad阈值带实际对方cut系数，并无已删来源注入／删除罚；每个cut还乘d_r。ST13中的未付primitive明确为

\[
 \int p(x-y)\,\frac{Q_x^*(v)}q
 \frac{\rho_vd_r}{r_{\theta_r(v)}(v)}\,dx
 \quad\text{或}\quad
 \int p(x-y)\,\frac{Q_x^*(v)}q
 \frac{d_r}{r_{\theta_r(v)}(v)}\,dx,
\]

连同原ξ选择和ν、β积分。代数上Q/r会消成pw_θ/K，故FIRST的∫Qν≤q不能单独控制它；所需的是原three-kernel eligibility、ρ储备以及d_r的联合接收局部化，而非一份新的无条件来源质量预算。

这些费用较旧全来源穿越更窄，但本文未证明它们一般可求和到根阶。交付的新增可核验估计是ST4的regularized cut输运、ST10–11的调和抑制以及ST13的原三核容量注入primitive；没有以方差身份、跳变删除或定义势函数本身宣称付款。

仅写本文件，未Git、未修改他人文件，完成后停止等待。
