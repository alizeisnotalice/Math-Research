#!/usr/bin/env python3
"""Independent complete three-atom interval union and exact translation integral."""
import argparse,hashlib,itertools,json,platform,resource,shlex,sys,time
from fractions import Fraction as F
from pathlib import Path

PARAMETERS=[(F(5,4),F(1,2)),(F(9,8),F(1,4)),(F(4,3),F(1)),(F(7,5),F(3,2))]

def plus(x,y):return x[0]+y[0],x[1]+y[1]
def minus(x,y):return x[0]-y[0],x[1]-y[1]
def at(x,t):return x[0]*t+x[1]
def output_line(x):return {'coefficient_t':str(x[0]),'constant':str(x[1])}
def integrate_line(line,a,b):return line[0]*(b*b-a*a)/2+line[1]*(b-a)

def interval_union(intervals):
 vals=sorted((a,b) for a,b in intervals if a<b)
 if not vals:return F(0)
 total=F(0);a,b=vals[0]
 for c,d in vals[1:]:
  if c<=b:b=max(b,d)
  else:total+=b-a;a,b=c,d
 return total+b-a

def actual_union(points,weights):
 intervals=[]
 for mask in range(1,1<<len(points)):
  ids=[i for i in range(len(points)) if mask>>i&1];mass=sum(weights[i] for i in ids)
  intervals.append((max(points[i] for i in ids)-mass/2,min(points[i] for i in ids)+mass/2))
 return interval_union(intervals)

def forms(d,b,sample):
 positions=[(F(0),F(0)),(F(0),d),(F(1),F(0))];weights=[F(1),F(1),b];records=[]
 for mask in range(1,8):
  ids=[i for i in range(3) if mask>>i&1];mass=sum(weights[i] for i in ids)
  low_position=min(ids,key=lambda i:(at(positions[i],sample),i));high_position=max(ids,key=lambda i:(at(positions[i],sample),-i))
  lower=plus(positions[high_position],(F(0),-mass/2));upper=plus(positions[low_position],(F(0),mass/2))
  records.append({'subset':mask,'lower':lower,'upper':upper,'min_position_owner':low_position,'max_position_owner':high_position})
 return records

def sample_between(a,b):
 if a is None:return b-1
 if b is None:return a+1
 return (a+b)/2

def in_open(t,a,b):return (a is None or a<t) and (b is None or t<b)

def union_affine(records,sample):
 active=[r for r in records if at(r['lower'],sample)<at(r['upper'],sample)]
 active.sort(key=lambda r:(at(r['lower'],sample),r['subset']))
 if not active:return (F(0),F(0)),[]
 lo=active[0]['lower'];hi=active[0]['upper'];total=(F(0),F(0))
 for rec in active[1:]:
  if at(rec['lower'],sample)<=at(hi,sample):
   if at(rec['upper'],sample)>at(hi,sample):hi=rec['upper']
  else:total=plus(total,minus(hi,lo));lo=rec['lower'];hi=rec['upper']
 return plus(total,minus(hi,lo)),[r['subset'] for r in active]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r594_exact_results.json'));args=ap.parse_args();start=time.perf_counter();cases=[]
 for d,b in PARAMETERS:
  assert 1<d<F(3,2) and 0<b<2*d-1
  pureA=actual_union([F(0),d],[F(1),F(1)]);pureB=actual_union([F(0)],[b]);assert pureA==d+1 and pureB==b
  purebase=pureA+pureB
  events={F(0):[{'type':'source_order'}],d:[{'type':'source_order'}]}
  source_chambers=[(None,F(0)),(F(0),d),(d,None)]
  for left,right in source_chambers:
   sample=sample_between(left,right);records=forms(d,b,sample)
   endpoints=[(str(r['subset'])+':'+name,r[name]) for r in records for name in ('lower','upper')]
   for (name1,f1),(name2,f2) in itertools.combinations(endpoints,2):
    a,c=minus(f1,f2)
    if not a:continue
    root=-c/a
    if in_open(root,left,right):events.setdefault(root,[]).append({'type':'linear_endpoint_crossing_or_birth','endpoints':[name1,name2],'within_source_chamber':[None if left is None else str(left),None if right is None else str(right)]})
  cuts=sorted(events);bounds=[None]+cuts+[None];segments=[];integral=F(0);absolute=F(0);positive=F(0);negative=F(0)
  for left,right in zip(bounds,bounds[1:]):
   sample=sample_between(left,right);records=forms(d,b,sample)
   allforms=[r[name] for r in records for name in ('lower','upper')]
   # Every linear comparison is constant throughout this entire open segment:
   # all possible interior roots were explicitly generated, including births.
   for f1,f2 in itertools.combinations(allforms,2):
    a,c=minus(f1,f2)
    if a:assert not in_open(-c/a,left,right)
   union,active=union_affine(records,sample);D=minus(union,(F(0),purebase))
   assert at(union,sample)==actual_union([F(0),d,sample],[F(1),F(1),b])
   if left is None or right is None:
    assert D==(F(0),F(0));area=F(0);partpositive=F(0);partnegative=F(0)
   else:
    area=integrate_line(D,left,right);integral+=area
    partition=[left,right]
    if D[0]:
     root=-D[1]/D[0]
     if left<root<right:partition.insert(1,root)
    partpositive=F(0);partnegative=F(0)
    for a,c in zip(partition,partition[1:]):
     val=integrate_line(D,a,c)
     if at(D,(a+c)/2)>=0:assert val>=0;partpositive+=val
     else:assert val<=0;partnegative+=val
    assert partpositive+partnegative==area
    positive+=partpositive;negative+=partnegative;absolute+=partpositive-partnegative
   segments.append({'left':None if left is None else str(left),'right':None if right is None else str(right),'complete_union_affine':output_line(union),'D_affine':output_line(D),'active_actual_subset_masks':active,'signed_integral':str(area),'positive_integral':str(partpositive),'negative_integral':str(partnegative),'all_linear_order_and_birth_events_excluded_from_interior':True})
  # Check exact values at every event against both adjacent segment limits.
  for i,t in enumerate(cuts):
   trueD=actual_union([F(0),d,t],[F(1),F(1),b])-purebase
   for j in (i,i+1):
    f=segments[j]['D_affine'];line=(F(f['coefficient_t']),F(f['constant']));assert at(line,t)==trueD
  assert integral==positive+negative and absolute==positive-negative
  # The asserted analytic value is used ONLY here, after full geometric integration.
  target=-b*d;assert integral==target
  cases.append({'d':str(d),'b':str(b),'parameter_conditions_exact':True,'actual_pure_A_volume':str(pureA),'actual_pure_B_volume':str(pureB),'pure_base_sum':str(purebase),'source_subset_count':7,
    'breakpoints':[{'t':str(t),'generators':events[t]} for t in cuts],'segments':segments,'both_tails_exactly_zero':True,'continuity_at_all_events_checked':True,
    'integral_D_exact':str(integral),'integral_D_positive_exact':str(positive),'integral_D_negative_exact':str(negative),'integral_abs_D_exact':str(absolute),'analytic_minus_bd_exact':str(target),'exact_comparison_residual':'0'})
 result={'scope':'Four fixed rational three-atom inputs, full seven-subset/all-scale interval unions, complete real translation line. Independent endpoint-event integration, not a general gain or extremizer counterexample.',
  'object':{'n':1,'lambda':1,'A_positions':['0','d'],'A_masses':['1','1'],'B_position_after_translation':'t','B_mass':'b','cube_convention':'side=mS for n1 lambda1, interval halfwidth mS/2','D':'actual complete union length minus actual pure A and B lengths'},
  'algorithm':'Build affine endpoints independently in the three source-order chambers, generate every valid pairwise endpoint crossing (including every own-subset birth), partition the whole real line, derive affine union lengths by exact endpoint ordering, integrate every segment with Fraction; check all event values and zero tails.',
  'cases':cases,'all_exact_comparisons_passed':True,'error':'0: all endpoints, event roots, union coefficients and integrals are rational Fraction, with no floating computation',
  'execution':{'interpreter':sys.executable,'python':platform.python_version(),'processes':1,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]])}}
 args.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'cases':[(c['d'],c['b'],len(c['breakpoints']),c['integral_D_exact'],c['integral_D_positive_exact'],c['integral_D_negative_exact']) for c in cases],'all_passed':True,'execution':result['execution']}))
if __name__=='__main__':main()
