import sys,time,platform,json,ast,functools
from pathlib import Path
import numpy as np,sympy as sp,flint
from flint import arb,ctx
ctx.prec=256;START=time.monotonic();UNION_EVALS=0
# Receiving and union functions copied from R543; this file is self-contained.
def area(lo, hi):
    global UNION_EVALS
    UNION_EVALS += 1
    if len(lo) == 0:
        return 0.0
    contains = (lo[:, None, :] <= lo[None, :, :]).all(2) & (hi[:, None, :] >= hi[None, :, :]).all(2)
    np.fill_diagonal(contains, False)
    for i in range(len(lo)):
        for j in range(i):
            if np.all(lo[i] == lo[j]) and np.all(hi[i] == hi[j]):
                contains[i, j] = False
    keep = ~contains.any(0)
    lo = lo[keep]
    hi = hi[keep]
    edges = np.unique(np.r_[lo[:, 0], hi[:, 0]])
    ans = 0.0
    for a, b in zip(edges[:-1], edges[1:]):
        ix = np.flatnonzero((lo[:, 0] < (a + b) / 2) & (hi[:, 0] > (a + b) / 2))
        if not len(ix):
            continue
        ix = ix[np.argsort(lo[ix, 1])]
        low, high = (lo[ix[0], 1], hi[ix[0], 1])
        length = 0.0
        for i in ix[1:]:
            if lo[i, 1] > high:
                length += high - low
                low, high = (lo[i, 1], hi[i, 1])
            else:
                high = max(high, hi[i, 1])
        ans += (b - a) * (length + high - low)
    return float(ans)

def receiver(x, w):
    N = len(w)
    bits = np.array([[bool(mask >> i & 1) for i in range(N)] for mask in range(1, 1 << N)])
    r = np.sqrt(bits @ w)
    low = np.max(np.where(bits[:, :, None], x[None, :, :], -np.inf), axis=1) - r[:, None] / 2
    high = np.min(np.where(bits[:, :, None], x[None, :, :], np.inf), axis=1) + r[:, None] / 2
    ok = (high > low).all(1)
    return (low[ok], high[ok])

def ev(e):
 e=sp.sympify(e)
 if e.is_Rational:return arb(int(e.p))/int(e.q)
 if e.is_Add:return sum((ev(t) for t in e.args),arb(0))
 if e.is_Mul:
  a=arb(1)
  for t in e.args:a*=ev(t)
  return a
 if e.is_Pow:
  a,p=e.args
  if p.is_Rational:return ev(a).root(int(p.q))**int(p.p)
 raise ValueError(str(e))
def cmp(a,b):
 d=ev(a)-ev(b)
 if d>0:return 1
 if d<0:return -1
 if sp.simplify(a-b)==0:return 0
 raise ArithmeticError(str(a-b))
def unique(v):
 s=sorted(v,key=functools.cmp_to_key(cmp));o=[]
 for x in s:
  if not o or cmp(x,o[-1])!=0:o.append(x)
 return o

def exact_union(x,w):
 if not w:return sp.Integer(0)
 boxes=[]
 for mask in range(1,1<<len(w)):
  ids=[i for i in range(len(w)) if mask>>i&1];half=sp.sqrt(sum(w[i] for i in ids))/2
  low=[max([x[i][j] for i in ids],key=functools.cmp_to_key(cmp))-half for j in range(2)];high=[min([x[i][j] for i in ids],key=functools.cmp_to_key(cmp))+half for j in range(2)]
  if all(cmp(high[j],low[j])>0 for j in range(2)):boxes.append((low,high))
 edges=[unique([p[k][j] for p in boxes for k in (0,1)]) for j in range(2)]
 def rank(v,j):return next(i for i,e in enumerate(edges[j]) if cmp(v,e)==0)
 ranks=[([rank(lo[j],j) for j in range(2)],[rank(hi[j],j) for j in range(2)]) for lo,hi in boxes];U=0
 for i in range(len(edges[0])-1):
  ys=sorted((lo[1],hi[1]) for lo,hi in ranks if lo[0]<=i<hi[0])
  if not ys:continue
  lo,hi=ys[0];length=0
  for c,d in ys[1:]:
   if c>hi:length+=edges[1][hi]-edges[1][lo];lo,hi=c,d
   else:hi=max(hi,d)
  length+=edges[1][hi]-edges[1][lo];U+=(edges[0][i+1]-edges[0][i])*length
 return sp.expand(U)

def cert(e):
 a=ev(e);sg=1 if a>0 else -1 if a<0 else 0 if sp.simplify(e)==0 else None
 assert sg is not None
 return dict(exact=str(e),arb256=str(a),sign=sg,float=float(e))
b=(1+sp.sqrt(sp.Rational(1,2)))/2
inputs=[('one_source',[[0,0]],[1]),('R540_two_source_contact',[[0,0],[b,0]],[sp.Rational(1,2)]*2),('asymmetric_three_source',[[0,0],[sp.Rational(2,5),sp.Rational(1,50)],[sp.Rational(9,20),sp.Rational(7,100)]],[sp.Rational(2,5),sp.Rational(3,10),sp.Rational(3,10)])]
results=[]
for name,x,w in inputs:
 x=[[sp.sympify(v) for v in p] for p in x];w=list(map(sp.Rational,w));N=len(w);original=exact_union(x,w);oldsubset={};outcomes_by_p=[]
 for mask in range(1<<N):
  ids=[i for i in range(N) if mask>>i&1];oldsubset[mask]=exact_union([x[i] for i in ids],[w[i] for i in ids])
 for p in [sp.Rational(1,4),sp.Rational(1,2),sp.Rational(3,4)]:
  EU=0;EM=0;RHS=0;prob_sum=0;outs=[]
  for mask in range(1<<N):
   ids=[i for i in range(N) if mask>>i&1];k=len(ids);prob=p**k*(1-p)**(N-k);wt=[w[i]/p for i in ids];xs=[x[i] for i in ids];u=exact_union(xs,wt)
   if ids:
    lo,hi=receiver(np.array(xs,float),np.array(wt,float));uf=area(lo,hi)
   else:uf=0.
   assert abs(uf-float(u))<1e-12
   EU+=prob*u;EM+=prob*sum(wt);RHS+=prob*oldsubset[mask]/p;prob_sum+=prob
   outs.append(dict(mask=mask,retained_count=k,probability=str(prob),total_mass=str(sum(wt)),U=cert(u),R543_float_union_area=uf,float_cross_check_abs_error=abs(uf-float(u))))
  EU=sp.expand(EU);RHS=sp.expand(RHS);assert EM==1 and prob_sum==1
  row=dict(p=str(p),probability_sum=str(prob_sum),expected_mass_exact=str(EM),expected_U=cert(EU),expected_U_minus_original=cert(EU-original),suspect_scaled_unscaled_subset_RHS=cert(RHS),proposed_identity_residual=cert(EU-RHS),outcomes=outs);outcomes_by_p.append(row)
  print(name,p,'EU-c',float(EU-original),'identity residual',float(EU-RHS),flush=True)
 results.append(dict(name=name,N=N,positions=[[str(v) for v in r] for r in x],masses=[str(v) for v in w],original_U=cert(original),thinning=outcomes_by_p))
from fractions import Fraction as F
periodic=[]
for k in [1,2,3,5,8]:
    xs=[F(3*i,2) for i in range(k)]; boxes=[]
    for mask in range(1,1<<k):
        ids=[i for i in range(k) if mask>>i&1]; r=F(len(ids))
        lo=max(xs[i] for i in ids)-r/2; hi=min(xs[i] for i in ids)+r/2
        if lo<hi: boxes.append((lo,hi))
    boxes.sort(); lo,hi=boxes[0]; total=F(0)
    for a,b in boxes[1:]:
        if a>hi: total+=hi-lo; lo,hi=a,b
        else: hi=max(hi,b)
    total+=hi-lo
    assert total==F(3*k-1,2)
    periodic.append(dict(k=k,full_union=str(total),expected=str(F(3*k-1,2))))

out=dict(command=sys.executable+' '+str(Path(__file__).resolve()),versions=dict(python=platform.python_version(),numpy=np.__version__,sympy=sp.__version__,python_flint=flint.__version__),precision_bits=256,seed=None,scope='Exactly three fixed R543 inputs, three fixed retention probabilities, all Bernoulli outcomes. Positions fixed, retained masses divided by p. Complete union, not individual-box sum. No optimization or extremizer claim.',method='Reuse copied R543 receiver/area definitions without executing its experiments; independent exact algebraic endpoint sweep with Arb256 ordering verifies every nonempty outcome. Expectation probabilities and expected mass are exact rational. Interval signs are for these finite exact expressions.',normalization_warning='U(tx, t^2 m)=t^2 U(x,m) in dimension2. Scaling masses alone does not in general scale U linearly, because positions stay fixed.',single_source_exact_calibration='U(m/p)=m/p on retained event, U(empty)=0; Bernoulli expectation m, and expected mass m.',full_union_float_evaluations=UNION_EVALS,elapsed_seconds=time.monotonic()-START,results=results)
out['periodic_single_source_exact_checks']=periodic
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
