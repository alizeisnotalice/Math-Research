#!/usr/bin/env python3
"""Exact p-threshold cuts on the two R454 native 1D fullcapture fields."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,platform
import sympy as s
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0
def ck(x):
 global checks
 assert x
 checks+=1
def ar(q):return arb(q.numerator)/q.denominator
P=[(Q(-251,1000),Q(-249,1000)),(Q(249,1000),Q(251,1000))]
BASE=[(Q(-3,5),Q(-2,5)),(Q(-1,20),Q(1,20)),(Q(2,5),Q(3,5))]
THRESHOLDS=[Q(1,16),Q(1,4),Q(1,2)]
def pieces(Ey):
 out=[]
 for al,ar0,R in Ey:
  cuts=sorted(set([al,ar0]+[p+sign*R/2 for l,r,_ in Ey for p in (l,r) for sign in (-1,1) if al<p+sign*R/2<ar0]))
  for l,r in zip(cuts,cuts[1:]):
   mid=(l+r)/2;u=Q(0);v=Q(0)
   for el,er,_ in Ey:
    if max(el,mid-R/2)>=min(er,mid+R/2):continue
    lo=(el,Q(0)) if el>=mid-R/2 else (-R/2,Q(1))
    hi=(er,Q(0)) if er<=mid+R/2 else (R/2,Q(1))
    u+=(hi[0]-lo[0])/R;v+=(hi[1]-lo[1])/R
   ck(0<u+v*l<=1 and 0<u+v*r<=1)
   out.append(dict(left=l,right=r,R=R,p_intercept=u,p_slope=v))
 return out
def cut(piece,tau):
 l,r,u,v=(piece[k] for k in ('left','right','p_intercept','p_slope'))
 pl,pr=u+v*l,u+v*r;cross=None
 if min(pl,pr)>=tau:
  high=r-l;interval=(l,r)
 elif max(pl,pr)<=tau:
  # Nonconstant equality at just an endpoint has zero receiver measure.
  high=Q(0);interval=None
 else:
  ck(v!=0)
  cross=(tau-u)/v;ck(l<cross<r and u+v*cross==tau)
  interval=(cross,r) if v>0 else (l,cross)
  high=interval[1]-interval[0]
 low=r-l-high
 ck(high>=0 and low>=0 and high+low==r-l)
 if interval:
  ck(u+v*interval[0]>=tau and u+v*interval[1]>=tau)
 return dict(**piece,tau=tau,threshold_crossing=cross,high_interval=interval,high_length=high,low_length=low)
def run(name,weights,sides):
 E=[(l,r,R) for (l,r),R in zip(BASE,sides)]
 B=[]
 for l,r,R in E:
  row=[]
  for pl,pr in P:
   full=pl>r-R/2 and pr<l+R/2
   miss=pr<l-R/2 or pl>r+R/2
   ck(full!=miss);row.append(int(full))
  B.append(row)
 ck(B==[[1,0],[1,1],[0,1]])
 masses=[sum((a*b for a,b in zip(weights,row)),Q(0)) for row in B]
 X=sum(((r-l)*m/R for (l,r,R),m in zip(E,masses)),Q(0))
 source=[]
 for i,a_i in enumerate(weights):
  Ey=[e for e,row in zip(E,B) if row[i]]
  source.append(dict(mass=a_i,Ey=Ey,pieces=pieces(Ey)))
 rows=[]
 for tau in THRESHOLDS:
  high=Q(0);low=Q(0);records=[]
  for i,src in enumerate(source):
   details=[cut(p,tau) for p in src['pieces']]
   hi=src['mass']*sum((z['high_length']/z['R'] for z in details),Q(0))
   lo=src['mass']*sum((z['low_length']/z['R'] for z in details),Q(0))
   high+=hi;low+=lo;records.append(dict(source_index=i,high_gamma=hi,low_gamma=lo,cuts=details))
  ck(high+low==X)
  rows.append(dict(tau=tau,Xhigh=high,Xlow=low,Xsum=high+low,high_fraction_of_X=high/X,records=records))
 return dict(name=name,source_packets=P,source_weights=weights,receivers=E,receiver_mass=masses,
 W=sum(weights),X=X,q_min=min(m/R for m,(_,_,R) in zip(masses,E)),q_max=max(m/R for m,(_,_,R) in zip(masses,E)),source=source,thresholds=rows)
results=[run('R454_equal_sides',[Q(1,2),Q(1,2)],[Q(1),Q(1),Q(1)]),
 run('R454_unequal_source_central_side_two',[Q(1,3),Q(2,3)],[Q(1),Q(2),Q(1)])]
ck(results[0]['X']==Q(3,10) and results[1]['X']==Q(1,4))
alpha,L,n=s.symbols('alpha L n',positive=True)
logobj=s.log(4)+s.log(n)/2+alpha*L-s.log(alpha)/2
ck(s.simplify(s.diff(logobj,alpha)-(L-1/(2*alpha)))==0)
ck(s.simplify(s.diff(logobj,alpha,2)-1/(2*alpha**2))==0)
ck(s.simplify((s.diff(logobj,alpha)).subs(alpha,1/(2*L)))==0)
coeff=[]
for tau in THRESHOLDS:
 logL=(1/ar(tau)).log()
 ck(logL>arb(1)/2) # all three prescribed cases are in the interior regime
 astar=1/(2*logL)
 ck(astar>0 and astar<1)
 selected=4*(astar*logL).exp()/astar.sqrt()
 closed=4*(2*arb(1).exp()*logL).sqrt()
 ck((selected-closed).contains(0))
 endpoint=4*(1/ar(tau))
 ck(endpoint>selected)
 coeff.append(dict(tau=tau,L_interval=str(logL),alpha_star_interval=str(astar),
 C_tau_over_sqrt_n_interval=str(closed),C_at_selected_alpha_interval=str(selected),
 endpoint_alpha_one_interval=str(endpoint),endpoint_minus_opt_interval=str(endpoint-selected),
 formula='C_tau=4*sqrt(n)*sqrt(2*e*log(1/tau)) for L>=1/2; else 4*sqrt(n)/tau'))
out=dict(scope='two native 1D gate/mass-budget checks and scalar coefficient optimization only; no general low-p coverage, Phi integral, or history claim',
 executable=sys.executable,python=platform.python_version(),sympy=s.__version__,python_flint=flint.__version__,arb_bits=ctx.prec,
 checks=checks,cases=results,coefficient_checks=coeff)
def enc(x):
 if isinstance(x,Q):return str(x)
 raise TypeError(type(x).__name__)
(ROOT/'r455_numeric_certificate.json').write_text(json.dumps(out,default=enc,indent=2)+'\n')
print('executable:',sys.executable,'Python:',platform.python_version(),'SymPy:',s.__version__,'python-flint:',flint.__version__,'Arb bits:',ctx.prec)
for r in results:
 print(r['name'],'X=',r['X'],'qband=',r['q_min'],r['q_max'])
 for z in r['thresholds']:print(' tau=',z['tau'],'Xhigh=',z['Xhigh'],'Xlow=',z['Xlow'],'sum=',z['Xsum'])
for r in coeff:print('tau=',r['tau'],'alpha*=',r['alpha_star_interval'],'C_tau/sqrt(n)=',r['C_tau_over_sqrt_n_interval'])
print('PASS',checks,'exact/symbolic/Arb checks; two fields x three thresholds, no scan')
