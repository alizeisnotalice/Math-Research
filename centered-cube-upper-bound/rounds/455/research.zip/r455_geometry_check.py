from fractions import Fraction as F

P=[(F(-251,1000),F(-249,1000)),(F(249,1000),F(251,1000))]
E=[(F(-3,5),F(-2,5)),(F(-1,20),F(1,20)),(F(9,20),F(11,20))]
B=[[1,0],[1,1],[0,1]]
a=[F(1,2),F(1,2)]
m=[sum(a[i]*row[i] for i in range(2)) for row in B]
tau=F(1,4)
half=F(1,2)
for j,(l,r) in enumerate(E):
    for i,(p,q) in enumerate(P):
        if B[j][i]:
            assert p>=r-half and q<=l+half
        else:
            assert q<l-half or p>r+half

def overlap(A,interval):
    l,r=interval
    return max(F(0),min(r,A+half)-max(l,A-half))
def py(A,i):
    return sum(B[j][i]*overlap(A,E[j]) for j in range(3))

X=sum((r-l)*m[j] for j,(l,r) in enumerate(E))
Xlow=F(0); Llow=F(0); Jtotal=F(0); Exttotal=F(0)
segments=0
for j,(l,r) in enumerate(E):
    knots={l,r}
    for u,v in E:
        for t in (u-half,u+half,v-half,v+half):
            if l<t<r: knots.add(t)
    initial=sorted(knots)
    for left,right in zip(initial,initial[1:]):
        for i in range(2):
            pl,pr=py(left,i),py(right,i)
            if pr!=pl:
                t=left+(tau-pl)*(right-left)/(pr-pl)
                if left<t<right: knots.add(t)
    ordered=sorted(knots)
    for left,right in zip(ordered,ordered[1:]):
        mid=(left+right)/2; width=right-left
        low=[bool(B[j][i] and py(mid,i)<tau) for i in range(2)]
        lowmass=sum(a[i]*low[i] for i in range(2))
        lowcapture=sum(a[i]*low[i]*py(mid,i) for i in range(2))
        J=sum(m[k]*overlap(mid,E[k]) for k in range(3))
        inside=sum(a[i]*B[j][i]*py(mid,i) for i in range(2))
        outside=J-inside
        # Actual full matching and the local inequality, with R=V=1.
        assert outside>=0
        assert lowcapture<=tau*lowmass
        assert J<=tau*lowmass+(m[j]-lowmass)+outside
        Xlow+=width*lowmass; Llow+=width*lowcapture
        Jtotal+=width*J; Exttotal+=width*outside
        segments+=1
assert X==F(1,4) and Xlow==F(1,5)
assert Llow<=tau*Xlow
assert (1-tau)*Xlow<=X-Jtotal+Exttotal
print('PASS: full-capture native geometry, q-band [1/2,1], exact affine integration')
print('segments =',segments)
print('tau =',tau,'X =',X,'X_low =',Xlow,'X_high =',X-Xlow)
print('low internal capture =',Llow,'; tau X_low =',tau*Xlow)
print('internal matched mass =',Jtotal,'; external-source contribution =',Exttotal)
print('Scope: low-p local bookkeeping only; no high-dimensional budget or history.')
