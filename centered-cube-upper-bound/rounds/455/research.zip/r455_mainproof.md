# R455 — direct use of the paid center kernel on the original accepted flow

## Exact projection and a paid two-endpoint portion

Keep the R435 contract's complete field and history. Thus \(m_A=f(Q_A)=q_A V_A\), \(V_A=R_A^n\), \(\sigma(dA)=q_A\,dA\), \(\pi_A(dx)=f(x)c_A(x)dx/m_A\), and \(S=\beta+C_{\rm col}\). Let \(P^*\) be **any positive restriction of the original \(\Pi_{433}\)** on its full record space. Its static pushforward has a measurable RN density
\[
 dP^*_{A,y,z}=S L(A,y,z)\,\sigma(dA)\pi_A(dy)\pi_A(dz),\qquad0\le L\le1. \tag{1}
\]
All stage/current/clock/early/path/future gates stay in this density; it is not a newly generated history. For \(S=0\) everything is zero. Put \(R^*=P^*(1)\) and
\[
 \ell_y(A,y)=\int L(A,y,z)\pi_A(dz).
\]
Full matching gives the exact identity
\[
 R^*=S\int f(y)dy\int_{E_y}\frac{\ell_y(A,y)}{V_A}\,dA. \tag{2}
\]
Indeed \(q_A/m_A=1/V_A\). There is also the analogous identity with the other source and its conditional average. This does not require \(L\) to be symmetric.

Use the actual same-source center-volume fraction
\[
 p_y(A)=\frac{|E_y\cap Q_A|}{V_A},\qquad
 E_y=\{w\in E:y\in Q_w\}.
\]
R454 proves, for \(0<\alpha\le1\),
\[
 \Phi_\alpha=\int f(y)\int_{E_y}V_A^{-1}p_y(A)^\alpha\,dA\,dy
 \le4\sqrt{n/\alpha}\,W. \tag{3}
\]
For any \(0<\tau\le1\), split the original records disjointly into
\[
 \{p_y(A)\ge\tau\},\quad
 \{p_y(A)<\tau,\ p_z(A)\ge\tau\},\quad
 \{p_y(A)<\tau,\ p_z(A)<\tau\}. \tag{4}
\]
Since \(0\le\ell_y\le1\) and \(1_{p\ge\tau}\le\tau^{-\alpha}p^\alpha\), (2)–(3) pay the first portion by \(4S\tau^{-\alpha}\sqrt{n/\alpha}W\). Exchange only the two source integration variables in the symmetric **base measure** to pay the second portion by the same amount; retain its own, possibly nonsymmetric, \(L\). Consequently
\[
 \boxed{R^*\le P^*[p_y(A)<\tau,\ p_z(A)<\tau]
       +8S\tau^{-\alpha}\sqrt{n/\alpha}\,W.} \tag{5}
\]
There is no new \(X_q\) fee. This is a proved positive portion of the original flow, not a claim that it has a fixed fraction of \(R^*\).

One may minimize the displayed price: if \(a_\tau=\log(1/\tau)>1/2\), choose \(\alpha=1/(2a_\tau)\), giving \(8S\sqrt{2en a_\tau}W\). If \(a_\tau\le1/2\), choose \(\alpha=1\). In particular a fixed polynomial threshold \(\tau=(n+2)^{-c}\), \(c>0\), has a root-dimensional price with a square-root logarithmic loss (with the stated small-\(a_\tau\) alternative). No threshold is silently sent to zero.

## Original mother-ledger coefficient

The source of the outer coefficient is `/tmp/r433_main.md`, the three mother-ledger displays at lines 113–125: the original entrance contains \(64\Lambda_0\widehat F R433\), where \(\Lambda_0=128/119\) and \(\widehat F=(1-32\delta-16\eta)^{-1}\). Applying (5) directly to that slot adds exactly
\[
 512\Lambda_0\widehat F S\tau^{-\alpha}\sqrt{n/\alpha}\,W. \tag{6}
\]
The corresponding additions to the \(G_0\) and \(B_H\) displays are respectively \(128\widehat F S\tau^{-\alpha}\sqrt{n/\alpha}W\) and \(256\widehat F S\tau^{-\alpha}\sqrt{n/\alpha}W\). These are alternatives at their respective levels of the same ledger, not fees to sum together. Every old initial/deletion/scale fee remains. To avoid repeat charging, (5) can instead be applied after previous receipts to their actual remaining positive restriction \(P^*\); it neither refunds old fees nor pays the same records again.

## The single unresolved source-to-center comparison

The two quantities are exactly different measures on different geometric events:
\[
 p_y(A)=V_A^{-1}\int_E c_w(y)1_{Q_A}(w)\,dw,
\]
\[
 Z_A(y)=\int_E c_w(y)1_{m_w<m_A/K}\frac{dw}{m_w},\quad
 C_A(y,z)=\int_E c_w(y)c_w(z)1_{m_w<m_A/K}\frac{dw}{m_w}. \tag{7}
\]
High \(Z_A(y)\) can be supplied by centers outside \(Q_A\). Low \(C_A(y,z)\) concerns capture of the **source** \(z\) by \(Q_w\), not membership of the center \(w\) in \(Q_A\). Thus neither gate supplies the missing lower bound on \(p_y(A)\) or \(p_z(A)\). This statement does not assert that the full original gates are compatible with every low-\(p\) model; it identifies the comparison still unproved.

The precise \(\alpha=1\) paid kernel is, by Tonelli,
\[
 \Phi_1=\int_{E\times E}1_{Q_A}(w)
       \frac{f(Q_A\cap Q_w)}{V_A^2}\,dA\,dw. \tag{8}
\]
In contrast, the accepted exclusive expansion in R452(2) keeps strict mass order, \(1/m_w\), \(1/Z_A(y)\), and the source-dependent original \(L(A,y,z)(1-c_w(z))\). Substituting (8) for that expansion would discard both the center-inside indicator and its incompatible weights. No such substitution has been proved.

Even replacing a source posterior by a uniform center law has the explicit, nonzero matching defect
\[
 \pi_A(E_y)-p_y(A)
 =V_A^{-1}\int_{Q_A}\bigl(f(w)/q_A-1\bigr)1_{E_y}(w)\,dw. \tag{9}
\]
Full matching cancels this integrand only without the indicator. The actual acceptance \(L\) need not be that indicator either. Therefore (5) is the current rigorous bridge; the remaining **same original** two-low-\(p\) intersection has no proved contraction or source price here. No general \(M_2\) assertion, density cap, history refresh, or second use of old square credit is made.

## Actual local verification

`r455_mainproof_check.py` was run; `r455_mainproof.result.txt` records **108 exact Fraction assertions**. Nine continuous one-dimensional fixtures use \(E=[0,d]\), actual constant side 1, and full \(f=1_{[-2,2]}+c1_E\). Every actual center has exactly \(m_A=1+cd\), so matching is exact. The script checks (2)'s unmarked coefficient, the full center/source identity (8), and (9). It also checks the positive threshold split algebra. These fixtures have no strict-far witnesses and do **not** certify the original history or refute a possible bound on its low-\(p\) part. The general receipt (5) is proved analytically.
