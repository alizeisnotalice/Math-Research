# R455 independent audit — FINAL PASS（原流正子分支预算）

FINAL PASS：认证R454的Φα价格对同一完整原剩余正测度的高p门收费，单端≤4Sτ^−α√(n/α)W、两端OR≤8Sτ^−α√(n/α)W，保原S及母账乘子。**未证明双低p交集可吸收、完整原R或全尺度一般根阶上界；无固定付款比例保证。** 下方保留作者前PRE，其当时待核的projection事项已在本FINAL核回。

## 1. 原支配合同已按实际负载核回

独立读取R435 contract的exact load、R413主稿§1/§3b的原逐端投影以及R433主稿末端母账，不仅依赖一句静态支配假设。原source投影的密度是同一完整f/π_A下

    Σ_e,i a_i^e(A,y)b_i(z)θ_i^e(A,y,z)，

其中0≤a_i^e≤B_e、0≤θ_i^e≤1、Σ_i b_i(z)≤1、Σ_eB_e=S。θ是原early/clock/路径/未来等记录保留后的RN平均，原R433额外门只为正限制，故实际密度≤S。任意尚未付款正限制P*亦继承；没有新增τ_stage^−1、stage数或双端2损失。

因此P*的(A,y,z)真实投影确有RN L∈[0,1]，而不是假设full history记录独立。所有新p门由投影静态事件拉回原records；分拆精确，旧current/relative-rank/路径和先前正过滤全部不重算。root修后direct稿已明确该区别，S0为零流。

## 2. 价格、参数、补集与母账

完整matching使σπ_A=f c_A/V_A，Φα无需额外q、λ或r因子。对指定y端high用1_{p≥τ}≤τ^−αp^α即可正上放，另一source概率先积1。第二端以对称**基底**积分上放，不要求L对称；用先y-high、再y-low/z-high、最后双low的互斥分拆，OR的8S系数正确。只付原尚存正记录，不能退款或重新记旧收据；无逐输入非零/占比保证。

α最小值与PRE一致：log(1/τ)≥1/2选1/[2log(1/τ)]，小值选α1，τ1也合法。root选τ=(n+2)^−c,c≥1使所有n≥1处于内点档，单端4S√[2ec nlog(n+2)]W，OR再乘2。S及Fhat等若有n/参数依赖必须保留，不能把公式直接称绝对常数root一般定理。τ是新增p-cutoff，不修改原stage门或生成核。

实际读R433的G0/BH/入口三个显示，原R系数为16Fhat、32Fhat、64Λ₀Fhat。因此OR增加分别为128Fhat S、256Fhat S、512Λ₀Fhat S乘τ^−α√(n/α)W；三个是同一账不同层的替代显示，不能加在一起。未花ε吸收额度，所有旧初始/删除/尺度项继续保留。若未来只证原low≤εX+QW，只进入R槽，不能错解为direct X_low预算或同时重扣旧付款。

## 3. 低支附件与有限证据

Geometry式(1)的真实父内同源捕获Tonelli、式(2)的父依赖外源分解和(3)(4)符号/σ乘法正确。qband与a>0保证所列正积分有限。J_in−O_A只是原内部交叠，分解本身不构成额外收缩；跨父O_A不可当可加W价。high Z、low common与p测的是不同加权/空间事件，未被偷换。主证Φ1式(8)、posterior-minus-volume式(9)保真，后者matching只有去掉source-dependent indicator才消去。

Numeric两个真一维场的p门均在整receiver区间上分段精确积分，常数段等τ归high，非恒定端点零测。side2保其γ权1/2，六行high+low恰等X。三个Arb最优α参数与解析表达式一致；它们只核有限门质量/标量优化，未验证原Φ积分或low-p/history预算。主证九个常side、完整非均匀f的连续场只核系数、Φ1和匹配缺陷，没有strict-far原history资格。

## 4. 实际隔离复现与状态

指定数学Python `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 在新目录
`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r455_audit_isolated_hohbou2l`
实际运行三个白名单脚本；三份stdout与冻结输出逐字节一致，numeric生成JSON亦逐字节一致。

范围分开记录：mainproof 108 Fraction断言（九native系数场及scalar split）；geometry一个native一维场的六段Fraction账；numeric两个场×三阈值及标量优化的132项精确/符号/256-bit Arb检查。一般正分支定理依解析证明，不由这些模型认证。资源记录保原实跑，不估扣额；PRE符号辅助不追加正式覆盖。无未修阻断。

最终范围是原高p正子测度可付，双low交集及全尺度闭合仍未付；不是把未付交集改名或用检查数完成总目标。

## 5. 最终字节绑定（14输入）

- `r455_main.md`: `3985abedb5cf18027f87a3e629121c120e1869024abace1dae8c9361d042b4b1`
- `r455_direct_budget.md`: `c2d05f710eb39ebc4e13a4dc1a4df6412ecceb75c1e9c4e397e2e13014783284`
- `r455_geometry.md`: `b6c376193ba6570550a52c710dd3a33857a8133c7cf7483cc68e62a8f3d77339`
- `r455_geometry_check.py`: `0ace4076b67bd7d85dcc31b63e8866d46ea30a5c7f7b6e87a62f95e5761879a8`
- `r455_geometry.result.txt`: `a1e595c05281a1b3cabd02aa980b9dc40a311ee9ff971e9cd559f3882b7a334f`
- `r455_mainproof.md`: `af91e84683a4f87276c41794b0036a869c4fe25d2840d5eab1c0252f083f03cc`
- `r455_mainproof_check.py`: `80599a920cc32d3f599fdf5ec4542c0d000d842966aa83179ef1a005b21f8d5e`
- `r455_mainproof.result.txt`: `8b449b4c1649bea1251325fbcdb083a963e8d9d75613d6835af56c38a95a1e63`
- `r455_numeric.md`: `17fb4a33bfed044aff09b20a0fe0c1143e0757c46464f1849157cca07d114949`
- `r455_numeric.py`: `5e35d822e3b2630fb21d68ed0039830e4f198b93a0d3f1ccb02f567d9ed312ff`
- `r455_numeric_certificate.json`: `e87e240f273bfbbe5ee3221c86dfe129bd4efa15ec627c7a9f5d348b5d848b26`
- `r455_numeric_run.txt`: `bd4fe2c772f9700645ad4a531fb88b4e799af80fa3a4c4667d0fa5c3df804fd4`
- `r455_numeric_resources.txt`: `663041e0550c8055ba4f421e8508ed34af2b065fac97d6ae6012a975dfeb2574`
- `r455_numeric_compute_index.md`: `c1dc961e96fe9a042d7009d2e79a08ad6e309dbfdb67b64416a3b4b6cb158874`

---

# R455 independent audit — PRE

PRE ONLY。独立核高p分支、最优α及低支缺口，未读R455作者新证明。已证R454一般几何界可用；没有认证低p、原全R或全尺度闭合。只修改本文件，等待作者具体步骤。

## 1. 同一测度与完整分拆

完整非负f∈L¹，真实可测接收E和单值side a≤R_A≤b≤2a，m_A=f(Q_A)=q_AR_A^n，q≤q_A≤λ。定义

    γ(dy,dA)=f(y)c_A(y)R_A^−n dy dA=σ(dA)π_A(dy)，
    γ(all)=X=∫fD=∫q_A dA， W=∫f。

这是direct X，不是q|E|，没有额外λ或r因子。D≤A_n保证X≤A_nW有限。p=p_y(A)=|E_y∩Q_A|/R_A^n∈[0,1]。由已证小胞覆盖，p=0异常对γ为零；但仅有零集结论不量化小正p。

对固定0<τ≤1，明确取high={p≥τ}、low={p<τ}，故X=X_high+X_low无遗漏，阈值等号只收费一次。零p异常置于low不增质量。W0/X0均为零结论。已证Φα=∫p^αdγ≤4√(n/α)W适用于每个0<α≤1，故

    X_high≤τ^−α Φα≤4√n W exp(αL)/√α， L=log(1/τ)≥0。

这里只对high给下界p^α≥τ^α；在low上p^α≤τ^α是反向，不能据Φ上界推出X_low上界。

## 2. 最优允许参数与小维数

log[exp(αL)/√α]=αL−(1/2)logα，导数L−1/(2α)，二阶导1/(2α²)>0。因此在0<α≤1的精确最佳选择和费用为

    α*=1                         若0≤L≤1/2，
    α*=1/(2L)                    若L≥1/2，

    X_high≤4√n W × { exp(L)       (L≤1/2)，
                      √(2eL)     (L≥1/2) }。

边界L1/2两式相等；τ1时L0、α1合法，不使用1/logτ。τ↓0时本费用发散，不给所有p的有限root总价；τ0不在这条参数论证内。τ>1则high空，不能借此处理low。

若τ=n^−c、c>0固定，L=c logn。n1时τ1，用α1，high≤4W；较小n若c logn<1/2仍必须α1，不能误取α>1。其余n给4√(2ec n logn)W。统一安全（不必最佳）取α=1/(1+2L)，得到

    X_high≤4√[e n(1+2c logn)]W
           =O_c(√(n log(n+2)))W。

不把4√(2ec n logn)直接用于n1。任何固定有限小维数也可用整个X≤(1+nlog2)W支付，但该粗界不能用于n→∞。常数中没有隐含新的来源密度帽或按stage重复费用；α只依n,τ，不更换selector。

## 3. 准确低支目标与反馈

若能另证同一direct γ上的

    X_low≤εX+Cε√n log^A(n+2)W， 0≤ε<1，

则与上述high分支合并才有

    X≤[B_high(n,τ)+Cε√n log^A(n+2)]W/(1−ε)。

这里需要完整low={p<τ}，不能只界其一个正子分支、一个固定来源或不带fD的条件概率。1/(1−ε)作用于全部direct高低费用。若最终得到的其实是原R_low≤εX+QW，而非X_low，不得用此式反推X；它只进入原R槽的64Λ₀Fhat回代。

原实际P若已有source投影≤Sσπ_A²，则单一指定source端的high事件可正上放为≤S X_high；两个端的OR若均收费需≤2S X_high或另有互斥联合分析。不能在已经包含双方向的S上再次无根据增/减2，也不能把投影上的高门变成路径或时钟的新资格。即使这些正子分支能付，原低source交集及完整history的预算仍需另证。本PRE没有据此宣布新母账付款。

X的整个单band/octave根价若将来成立，尚须原全尺度入口/初始/删除/最终吸收的完整手续。原R与X槽不同，不能混用ε系数，也不能与旧替代whole-R收据叠加重复结算。

## 4. 现有熵工具为什么尚未给所需低支

H=∫log(e/p)dγ≥(1+L)X_low。结合已证stable上界只能推出

    X_low≤[(1+nlog8)X+W/e]/(1+L)。

L=c logn时X系数约n/logn，并不变成固定ε。若仅靠此式选L≈n/ε以吸收，high费用√(nL)已回到O(n/√ε)W量级。故需要利用完整matching及共同来源相关性的额外低p估计；既有stable entropy及正power矩本身没有完成它。

R454的D³≤(64/log2)nH_y仍不提供lowγ的所需源价，更不是F≤CH。将它重命名、将p趋零的Lebesgue定性性质当定量费用，或对低p反向使用正power上界，都不是闭合。

## 5. 实际本机辅助与PRE状态

指定math-research-tools Python/SymPy实际核导数、严格log凸性、α=1/(2L)时费用平方2eL、α1端点expL及L1/2连续相接；一般参数优化由第2节解析证明。仅符号辅助，无新增native/history样本或有限维扫描，不把检查数作证明。

PRE结论：高p分支及其最佳合法参数通过；小n和补集明确。低p的εX+root来源价及原全尺度/原R整体桥仍未证，等待作者稿，不提前FINAL。


## 6. root direct-budget稿的后续限定核验

已在独立PRE后读取 `r455_direct_budget.md`。其τ=(n+2)^−c、c≥1与初始τ=n^−c不同，是显式安全选择；所有n≥1有Lτ≥log3>1/2，因此α=1/(2c log(n+2))始终合法，高p支价格

    4S√[2ec n log(n+2)]W

成立，保S及母账Λ₀·64Fhat，不花ε、不另加双端OR的2。该价只针对一个指定source标签y的门；low完整保留，无逐输入非零或固定占比保证。

完整history的正确测度表述如下，作为最终作者稿的审查条件：设Ω上原正测度Π，其投影r:Ω→(A,y,z)满足ρ=r#Π≤S σπ_A²。定义Π_high=1_{p_y(A)≥τ}Π、Π_low=1_{p_y(A)<τ}Π，永远有Π=Π_high+Π_low精确，所有原records只乘同一可测门。其质量满足

    Π_high(all)≤S∫σπ_A(dy)π_A(dz)1_{p_y(A)≥τ}
               =S X_high。

不需在完整clock/history记录上建立产品AC。S>0时由有限measure RN，投影可准确写ρ=S L σπ_A²、0≤L≤1；L是各原门在投影后的条件平均，不是给辅助receiver原资格，也不代表full记录measure等于无标签product。S0原flow零。只有projection domination也已足够上述价；不能因只有上界就把high/low的精确原measure分拆改成不等式。若作者保留抽象Π直接为(A,y,z)测度，则其等式模型合法，但应用到完整R应补此投影/拉回说明。

这里尚未独立重新认证原R433具体static projection合同；须由作者按实际原式给出，不凭L记号臆造。即使该合同成立，这仍只是原子测度的新high正分支预算，未付完整low或整个弱型问题。已向root提出上述最小表述澄清，等待冻结稿。
