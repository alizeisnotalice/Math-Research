# R455 原joint γ上的精确high/low-p分割（冻结）

沿R454同两条真实一维fullcapture场，完成六项精确门分割。所有Xhigh+Xlow=X；用实际receiver区间积分，没有以receiver中心取代整个门。另用SymPy检查标量极小值导数、256-bit Arb核三个Cτ；未计算原Φ积分或low-p覆盖桥，未估计任意维数阶数。

## 1. 保持的原joint与真实场

共同source packets中心±1/4，半宽1/1000；共同receiver区间 L=[−3/5,−2/5]、O=[−1/20,1/20]、R=[2/5,3/5]。全packet×全receiver的capture严格为(1,0),(1,1),(0,1)。

场1：source质量1/2,1/2，三side均1，W1、X3/10，qband[1/2,1]。场2：source质量1/3,2/3，side为1,2,1，W1、X1/4，qband[1/3,2/3]，octave2。它们均是非负L¹函数与真实Lebesgue receiver场，输入完全内置本轮脚本。

对source packet i，E_i是实际捕获其全部点的receiver集合；定义

`p_i(A)=|E_i∩Q_A|/R_A`，`dγ=f(y)c_A(y)dy dA/R_A`。

对packet来源积分后 `dγ_i(A)=a_i 1_(A∈E_i)dA/R_A`，所以 `X=Σ_i a_i∫_(E_i) dA/R_A`。本轮在同一γ上取p≥τ和p<τ，不将f换成fresh posterior，不采用别的归一。

## 2. 精确门切割

在每段原receiver上，分割所有Q_A边界跨越E_i端点的位置，得到p_i(A)=u+vA。每个阈值交点 `(τ−u)/v` 若在段内则用Fraction计算；high长度与low长度之和严格等于原段长。常数段等于τ时归high；非恒定段只有端点等于τ时该点零测，不改变预算。

例如左source的outer receiver L上，p为1/5、A+3/4、3/10三个相接段；τ1/4精确交点A=−1/2，high子区间长1/10。右source镜像。第一场中央p=1/5−A（右source取镜像），其p=1/4只出现在端点；第二场中央p恒3/20。该结构同时保留side2的γ权重1/2，未把中央receiver体积原样付两次。

| 场 | τ | Xhigh | Xlow | 和 |
|---|---|---:|---:|---:|
| 场1，X=3/10 | 1/16 | 3/10 | 0 | 3/10 |
| 场1 | 1/4 | 1/10 | 1/5 | 3/10 |
| 场1 | 1/2 | 0 | 3/10 | 3/10 |
| 场2，X=1/4 | 1/16 | 1/4 | 0 | 1/4 |
| 场2 | 1/4 | 1/10 | 3/20 | 1/4 |
| 场2 | 1/2 | 0 | 1/4 | 1/4 |

JSON保存逐source、逐piece的affine系数、真实交点、high interval、high/low长度及γ质量。以上全为严格有理数，无quadrature或浮点mask。

## 3. 高p理论常数的标量核验

按作者候选 `Cτ=4√n min_(0<α≤1) τ^(−α)/√α`，令 L=log(1/τ)>0。目标log除去常数后的导数是 `L−1/(2α)`，二阶导数 `1/(2α²)>0`，故

`α*=min(1,1/(2L))`。

当L≥1/2时 `Cτ/√n=4√(2eL)`；L≤1/2时为4/τ。SymPy核导数和内点驻点；三指定τ均由Arb严格证L>1/2、0<α*<1。Arb分别评价原目标在α*及closed form，区间相容；且α=1端点值严格较大。

| τ | α*（显示值） | Cτ/√n（显示值） |
|---|---:|---:|
| 1/16 | .1803368801111204 | 15.52976758765424 |
| 1/4 | .3606737602222409 | 10.98120397148136 |
| 1/2 | .7213475204444817 | 7.764883793827120 |

完整256-bit区间和误差见JSON。两个实际场均n=1；表按√n归一保留作者参数，没有把三个阈值当作维数实验，也没有借门质量检查宣称高p原Φ界成立。

## 4. 实跑与交付

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r455_numeric.py
```

实际Python3.12.14、SymPy1.14.0、python-flint0.9.0、Arb256bits。132项Fraction/符号/区间检查PASS；实际.17秒，最大RSS71,090,176bytes。只读R454脚本以保同一输入，未执行或修改其输出；本脚本无外部输入依赖，输出在自身目录。无scan、solver、git、spawn、repo或他人修改。

冻结白名单：`r455_numeric.py`、`r455_numeric_certificate.json`、`r455_numeric_run.txt`、`r455_numeric_resources.txt`、`r455_numeric.md`、`r455_numeric_compute_index.md`。本轮只核有限场的门/预算与标量常数，不负责原low-p覆盖、原R桥或一般阶数。完成停止。
