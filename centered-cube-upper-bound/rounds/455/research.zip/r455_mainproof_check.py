from fractions import Fraction as F
checks=0
print('Native 1D model: E=[0,d], selected side=1, f=1[-2,2]+c1E.')
print('All centers are Lebesgue centers, m_A=1+cd is constant; no strict-far/history gates are certified.')
for d in (F(1,10),F(1,5),F(1,4)):
    for c in (F(0),F(3),F(90)):
        m=1+c*d
        # D(y)=d on an interval of length 1-d, with two linear ramps.
        source_first=d*(1-d)+d*d+c*d*d
        source_square=d*d*(1-d)+2*d**3/3+c*d**3
        # I_Aw=1-|A-w|+cd; all w in E lie inside Q_A.
        center_pair=d*d*(1+c*d)-d**3/3
        assert source_first==m*d
        assert source_square==center_pair
        assert 0<d*(1+c)/m<=1
        assert d*(1+c)/m-d==c*d*(1-d)/m
        checks+=4
        print('d=',d,'c=',c,'mass=',m,'Phi1=',source_square,'posterior-minus-volume=',c*d*(1-d)/m)
print('Exact positive high-p split checks, alpha=1:')
for p in (F(0),F(1,10),F(1,2),F(1)):
    for tau in (F(1,10),F(1,2),F(1)):
        for ell in (F(0),F(2,5),F(1)):
            high=ell if p>=tau else F(0)
            low=ell-high
            assert high+low==ell
            assert high<=p/tau
            checks+=2
print('PASS:',checks,'Fraction assertions; native integral identities and scalar split only.')
