# R455 计算索引

- 所有权：Sol medium，仅/tmp/r455_numeric*；无repo/他人修改、git或spawn。
- 输入：与R454完全相同两条真实L1、全capture、连续receiver场，本轮脚本自含；只读旧脚本未执行/覆盖。
- 定义：p_i=|E_i∩Q_A|/R_A，原γ=f(y)c_A(y)dy dA/R_A；X为γ总质量。
- 范围：2场×τ1/16,1/4,1/2；Fraction求affine门交点/长度/γ积分；Xhigh+Xlow精确等X。
- 标量：SymPy核log目标导数、二阶导数与α*=1/(2L)驻点；Arb256核三个最优α和Cτ/√n区间及endpoint比较。未算Φ或原low-p/R桥。
- 实跑：指定Python3.12.14、SymPy1.14.0、python-flint0.9.0；132checks PASS，.17s、RSS71,090,176bytes。
- 文件：r455_numeric.py、r455_numeric_certificate.json、r455_numeric_run.txt、r455_numeric_resources.txt、r455_numeric.md、本index；均/tmp，同目录无旧依赖复现。
- 状态：冻结停止；有限门/预算证据，不估任意n阶数。
