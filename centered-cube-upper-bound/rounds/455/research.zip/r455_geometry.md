# R455 — low-p shared-source allocation: bounded proof attempt

**Outcome.** No contraction or new source price for the complete low-p
traffic is proved. The single mechanism tested was to use full matching
to replace the small internal capture of a low-p source by mass supplied
elsewhere. The calculation below keeps the actual receiver field and
identifies precisely the external-source term which that mechanism
would have to settle across parents. It is not a new paid branch.

## 1. Exact candidate and actual local consequence

Use the task's same field: \(V_A=R_A^n\),
\(m_A=f(Q_A)=q_AV_A\), \(q\le q_A\le\lambda\), and
\(a\le R_A\le b\le2a\). Let
\[
E_y=\{B\in E:y\in Q_B\},\quad
p_y(A)=\frac{|E_y\cap Q_A|}{V_A},\quad
\sigma(dA)=q_A\,dA.
\]
Fix \(0<\tau<1\). Define the **parent-dependent actual source measure**
\[
f_A^\ell(y)=f(y)c_A(y)1_{\{p_y(A)<\tau\}},\qquad
a_A=\frac{\int f_A^\ell}{m_A}.
\]
Then \(X_{\rm low}(\tau)=\int a_A\,d\sigma(A)\). The proposed
mechanism was to charge this traffic by the extra source mass needed to
match receivers centered inside \(Q_A\), and to make that charge common
across different parents. To be useful it would need a genuine
contraction, for example \(X_{\rm low}\le(1-c)X+C_r\sqrt n\,
\operatorname{polylog}(n)W\) with fixed \(c>0\). This is a candidate
goal, not a proved consequence of the next formula.

Tonelli gives the exact local statement
\[
\int_{B\in E\cap Q_A}f_A^\ell(Q_B)\,dB
=\int f_A^\ell(y)|E_y\cap Q_A|\,dy
\le\tau V_A m_A a_A.
\tag{1}
\]
No source density bound is used. The small quantity in (1) is an
integral over actual **centers**. It does not say that \(m_Aa_A\) is
small.

## 2. Where complete matching leaves the unpaid term

For the same parent put
\[
J_A^{\rm in}=\int_{B\in E\cap Q_A}m_B\,dB,\qquad
O_A=\int_{B\in E\cap Q_A}f(Q_B\setminus Q_A)\,dB.
\]
The full matching identity is retained, not replaced by a volume bound:
\[
J_A^{\rm in}
=\int_{B\in E\cap Q_A}
 \left[f_A^\ell(Q_B)
 +(f1_{Q_A}-f_A^\ell)(Q_B)
 +f(Q_B\setminus Q_A)\right]dB.
\tag{2}
\]
The middle term is at most \(V_A m_A(1-a_A)\), so (1) implies
\[
(1-\tau)a_A
\le1-\frac{J_A^{\rm in}}{V_A m_A}
       +\frac{O_A}{V_A m_A}.
\tag{3}
\]
Upon integrating with the unchanged parent weight \(d\sigma\),
\[
(1-\tau)X_{\rm low}
\le X-\int_E\frac{J_A^{\rm in}}{V_A^2}\,dA
       +\int_E\frac{O_A}{V_A^2}\,dA.
\tag{4}
\]
These finite positive integrals are legitimate under the stated octave
and band assumptions; in particular \(|E|<\infty\) follows from
\(q|E|\le X\le(1+n\log(b/a))W\). Equation (4) is only bookkeeping:
subtracting \(O_A\) from \(J_A^{\rm in}\) recovers the internal
intersection capture, so (4) is not an independent improved estimate.

The exact uncompleted operation is a **joint comparison of the last two
terms of (4)** giving an adequate net internal capture while charging the
external supplies only once in \(f\). A receiver centered inside \(Q_A\)
can obtain its matched mass from \(Q_B\setminus Q_A\). The identity
\(m_B=q_BV_B\) does not identify those supplies for different parents
as disjoint, nor provide the required signed cancellation. Integrating
the positive external supplies separately therefore has no established
\(W\) price. No claim that such a comparison is impossible is made.

This also locates why a source-preserving reassignment is insufficient:
the original joint measure \(\sigma(dA)\pi_A(dy)\) has source marginal
\(f(y)D(y)dy\). Reassigning the private complements in (2) without a
joint saving retains this repeated source weight. Dividing by \(D\)
changes the parent marginal, as checked in R454, and is not a settlement
of (4).

## 3. Proven high-p payment and the scope of this attempt

The supplied R454 estimate legitimately gives, for every
\(0<\alpha\le1\),
\[
X-X_{\rm low}(\tau)
\le4\tau^{-\alpha}\sqrt{n/\alpha}\,W.
\]
This is an existing input, not a new result of this attachment. For
example, taking \(\tau=n^{-C}\) and
\(\alpha=1/(C\log n)\le1\) gives
\(4e\sqrt{Cn\log n}\,W\) on that complement. The low-p traffic is
left intact. Neither a bound on the full source-conditioned entropy nor
a pointwise second-moment comparison has been assumed. The main target
remains open after this bounded attempt; no new ledger fee is asserted.

## 4. Actual finite verification

The designated local math Python ran `/tmp/r455_geometry_check.py`;
stdout is `/tmp/r455_geometry.result.txt`. The one-dimensional native
field consists of source packets at \(\pm1/4\), half-width \(1/1000\),
each of mass \(1/2\), and actual center intervals
\([-3/5,-2/5]\), \([-1/20,1/20]\), \([9/20,11/20]\). All selected
side lengths equal one. Exact endpoint checks give the full-capture
rows \((1,0),(1,1),(0,1)\) and matched band \([1/2,1]\).

The script splits the actual affine center-overlap functions at their
breakpoints and at \(p=1/4\); `Fraction` arithmetic verifies (1)--(4),
with the strict low-p event and all boundary equalities retained. It
finds \(X=1/4\), \(X_{\rm low}=1/5\). These values are only a
bookkeeping check for a real full-matching field, not evidence for or
against a high-dimensional bound and not an original-history instance.
No search or additional family was run.
