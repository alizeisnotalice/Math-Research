# R254: positive pair kernels and signed tensor interpolation to the actual source

This auxiliary note independently checks the kernel constants used by
the main author and proves the transfer to an arbitrary positive source.
The new source transfer has an explicit interpolation error; it does
not infer a source-global budget from a kernel L1 norm alone. All source
positions and weights are retained. Product probability calculations
below concern the kernel integral, not independent source coordinates.

## PK1. Normalization and the checked positive-kernel estimate

Let h_R=R^-n 1_[-R/2,R/2]^n, 0<s<=t<=2s, delta=log(t/s), and

    F_R=h_R*h_R,
    C_st=h_s*h_t,
    B_st=F_s+F_t-2C_st=(h_s-h_t)*(h_s-h_t).

All three nonnegative kernels F_s,F_t,C_st integrate to one; B_st is
continuous, compactly supported, signed, and has integral zero. Put
A_n=log(n+1)+4. The checked kernel statement is

    ||B_st||_1<=n A_n ((t-s)/s)^2,
    ||(B_st)_+||_1<=min(2,2n A_n delta^2).             (PK1)

For any finite disjoint scale windows [s_j,t_j] within [a,b], b<=2a,

    sum_j ||(B_sj,tj)_+||_1
                         <=2 log(b/a)sqrt(n A_n).     (PK2)

The main author gives the full kernel proof. The following independent
verification records the boundary and truncation constants, including
the potentially singular diagonal score terms.

## PK2. Independent verification of the midpoint and derivative constants

In one dimension put m=(s+t)/2, h=(t-s)/2. Then

    F_R(x)=(R-|x|)_+/R^2,
    C_st(x)=min(s,(m-|x|)_+)/(st).

C_st is flat up to |x|=h. Its difference from F_m changes sign at
x_0=mh/t. On [0,x_0], F_m-C_st is a triangle of height
1/m-1/t=h/(mt) and base x_0. Symmetry and zero integral give

    ||C_st-F_m||_1=2h^2/t^2=(t-s)^2/(2t^2).          (PK3)

Tensor telescoping for probability densities costs at most n times
this one-dimensional norm. Spatial derivatives are not involved in
the next log-scale check: differentiating the one-dimensional F_R
twice in R gives the measure

    partial_R^2 F_R=R^-3(2-6|x|/R)1_|x|<R dx
                                +R^-2(delta_-R+delta_R),
    ||partial_R^2 F_R||_TV=(16/3)R^-2.                (PK4)

The two boundary atoms are positive and must not be omitted.
For the first derivative, R partial_R F_R=Z F_R in the interior,
where Z=(1-u)^-1-2, u=|x|/R has density 2(1-u) on (0,1).
Thus EZ=0, E|Z|=1. For n>=2 truncate at T=n-1:

    X=Z1_{Z<=T}, Y=Z1_{Z>T}, b_n=EY=2n/(n+1)^2,
    EX=-b_n,
    EX^2=2log(n+1)-4+8/(n+1)-4/(n+1)^2
                                                <=2log(n+1).

The independent copies here are the coordinates of the normalized
product kernel. They do not describe a source posterior. For the
mixed scale-derivative term,

    E|sum_{i!=j}X_i X_j|
       <=2n EX^2+n(n-1)b_n^2<=4nlog(n+1)+4,

    E|sum_{i!=j}(Z_i Z_j-X_i X_j)|
       <=n(n-1)b_n(2-b_n)<=4n.

The first bound uses (sum X_i)^2-sum X_i^2; the second uses
Z_iZ_j-X_iX_j=Y_i Z_j+X_i Y_j and E|X|=1-b_n.
Adding PK4's n one-coordinate terms gives, for n>=2,

    ||partial_R^2 F_R^{(n)}||_TV
                  <=4n[log(n+1)+3]/R^2.              (PK5)

Indeed the intermediate bound is
[4nlog(n+1)+4+4n+(16/3)n]/R^2, and 4<=2n. For n=1 use PK4
directly. The centered second difference around m costs h^2 times
the supremum in PK5. The extra 2(C_st-F_m) costs at most
n(t-s)^2/t^2 by PK3. These prove the first PK1 with its stated A_n.
Since B_st has zero integral its positive L1 norm is half its full
norm. Also (B_st)_+<=F_s+F_t, so its integral is at most 2.
Finally (t-s)/s=e^delta-1<=2delta for delta<=log2. This proves the
second PK1. The scalar inequality min(2,2nA_n delta^2)<=2sqrt(nA_n)delta
and disjointness prove PK2, including degenerate zero windows.

## PK3. Exact signed interpolation identity

For a new physical interpolation length d>0 define the one-dimensional
nonnegative kernels

    k_d(z)=(d-|z|)_+/d^2,
    H_d(z)=(d-|z|)_+^3/(6d^2).

Distributionally,

    H_d''=k_d-delta_0,
    0<=H_d<=(d^2/6)k_d.                              (PK6)

The ordinary second derivative off zero is k_d; the derivative jump
at zero is -1. At +-d the function and its first derivative vanish,
so no extra atoms are present. Tensorize delta_0=k_d-H_d'' in all
coordinates. Put K_d=product_i k_d=h_d*h_d and c_d=d^2/6. For a
continuous signed compactly supported f whose mixed spatial
derivatives partial^{2S}f are finite measures, the exact expansion is

    f=K_d*f +sum_{empty!=S subset[n]}(-1)^|S|
       (product_{i in S}H_d product_{i notin S}k_d)
                                          *partial^{2S}f.

Consequently, pointwise,

    f<=K_d*Gamma_f,
    Gamma_f=f_+ dx
        +sum_{empty!=S} c_d^|S| |partial^{2S}f|.       (PK7)

This proof never differentiates |f| or f_+. Absolute values are taken
only after the signed exact expansion. The product kernels are
nonnegative, and their domination by c_d^|S| K_d proves PK7.
All convolutions in this expansion are continuous for the kernels
used here. Alternatively mollify f, use the same identity, and pass
to the uniform/L1 limit with the derivative total-variation bounds.

## PK4. Actual arbitrary-source transfer

Let mu be any finite nonnegative L1 source; finite positive measures
also suffice for this lemma. Define E_d(mu)=||h_d*mu||_2^2, which is
finite since ||h_d*mu||_2<=d^(-n/2)||mu||. For any positive finite Gamma,

    integral (K_d*Gamma)(x-y)mu(dx)mu(dy)
       =integral Gamma(dz)
              <h_d*mu,translation_z(h_d*mu)>
       <=E_d(mu)||Gamma||.                            (PK8)

Evenness of K_d and Tonelli give the identity (the translation sign
is immaterial); ordinary Cauchy--Schwarz gives the inequality. There
is no posterior normalizer, grid-source replacement, density cap,
or independence hypothesis in PK8. Inserting PK7 proves

    integral f(x-y)mu(dx)mu(dy)
       <=E_d(mu)[||f_+||_1
                  +sum_{empty!=S}c_d^|S| ||partial^{2S}f||_TV]. (PK9)

This is the productive signed-kernel transfer. It is stronger than
attempting to control a source pairing from ||f_+||_1 alone and pays
the interpolation error explicitly.

## PK5. The explicit mixed-spatial-derivative error for B_st

In one dimension, spatial differentiation (in x, not R) gives

    partial_x^2 F_R=R^-2(delta_-R-2delta_0+delta_R),
    ||partial_x^2 F_R||_TV=4/R^2,

    partial_x^2 C_st=(st)^-1
         (delta_-m-delta_-h-delta_h+delta_m),
    ||partial_x^2 C_st||_TV=4/(st).                    (PK10)

At h=0 the middle atoms combine correctly. Undifferentiated factors
are probability densities. Therefore for windows in [a,b] and every
nonempty S,

    ||partial^{2S} B_st||_TV<=4(4/a^2)^|S|.            (PK11)

For N finite windows, apply PK9 to the signed sum f=sum_j B_sj,tj.
Its positive part is bounded by sum_j (B_sj,tj)_+, and the derivative
norms by the N individual bounds in PK11. The exact final statement is

    sum_j ||(h_tj-h_sj)*mu||_2^2
       <=E_d(mu){sum_j ||(B_sj,tj)_+||_1
                       +4N[(1+2d^2/(3a^2))^n-1]}.   (PK12)

All terms concern the same original source pair. The identity on the
left follows from the continuous even pair kernel B, so the signed
source pairing is nonnegative before applying the upper bound.
Combining with PK2 yields, for disjoint windows,

    sum_j ||(h_tj-h_sj)*mu||_2^2
       <=E_d(mu){2log(b/a)sqrt(n A_n)
                       +4N[(1+2d^2/(3a^2))^n-1]}.   (PK13)

This retains both the source energy at the actual chosen d and the
number of windows. They cannot be changed or summed for free.

## PK6. Coarse cells versus an intermediate interpolation length

At the requested single-window cell side d=s/(8sqrt(n)), take a=s.
The nonempty-derivative error is at most 4(e^(1/96)-1); it does not
vanish with delta. Thus the pure delta^2 kernel fee is not by itself
an arbitrary-source delta^2 E_d bound at that fixed coarse scale.

For N windows and d=a/n^(3/4), the total error is explicitly at most

    (8N/(3sqrt(n))) exp(2/(3sqrt(n))).                 (PK14)

In particular if N<=n it is at most (8/3)e^(2/3)sqrt(n). Together
with PK13 this is an actual arbitrary-source square-increment bound
at an intermediate smoothing length. The source energy E_d(mu) must
still be supplied by its true source budget. No maximal-over-all-
partitions claim follows just from the finite-window bound, and no
new original traffic or high residual is declared paid here.

## PK7. Direct fixed-scale consequence with the exact constant 2/3

The transfer also applies directly to the nonnegative kernel F_R.
Its base L1 mass is one, and for each S its mixed spatial derivative
has exact total variation (4/R^2)^|S|. Therefore PK9 gives the new
fixed-scale comparison, for every R,d>0 and every positive finite source,

    E_R(mu)<=T_{R,d}E_d(mu),
    T_{R,d}=(1+2d^2/(3R^2))^n.                        (PK15)

This proof does not invoke the older fixed-grid sampling theorem.
There is no source density or grid-cell-uniformity assumption. It
improves the constant 32 in that route to the displayed exact 2/3
in this continuous-energy comparison. It does not remove the cost of
choosing the original receiver scale.

For example the already legal upward grid with J=ceil(n log(b/a)),
N<=J+1 nodes and node ratio at most exp(1/n) gives directly

    ||M_[a,b]mu||_2^2<=e^2 N T_{a,d}E_d(mu).          (PK16)

Duplicate endpoint nodes can be removed. N<=3n, and all terms concern
the same source. The sharper dyadic-prefix use of PK13 is developed
by the main author and is not replaced by a free supremum here.

At d=a/(8n^(3/4)), put x=1/(96sqrt(n)). Then

    T_{a,d}<=e^x, T_{a,d}-1<=x/(1-x)<=1/(95sqrt(n)),
    T_{a,d}<=96/95,
    4J(T_{a,d}-1)<=12sqrt(n)/95 if J<=3n.             (PK17)

These are analytic inequalities, including n=1. With this note's
A_n=log(n+1)+4 notation the disjoint-window term in PK13 remains
2log(b/a)sqrt(n A_n); its factor sqrt(n) is not omitted.

## PK8. Bounded actual checks

The embedded local Python code was actually run. Six midpoint identities
PK3 were integrated with exact Fraction arithmetic, splitting at the
affine zero whenever required. Twelve genuine L1 sources, each uniform
of mass one on a cube of side width, checked PK12 at the requested
d=s/(8sqrt(n)), in dimensions 1,2,4,16 and three ratios t/s. For
width<min(d,(t-s)/2), the source formulas used are exact:

    <mu,F_s*mu>=[1/s-width/(3s^2)]^n,
    <mu,C_st*mu>=t^-n,
    E_d(mu)=[1/d-width/(3d^2)]^n.

Thus no atom was substituted for the source. Output was `PASS 18`,
with maximum source-increment/right-side ratio
0.049058783246551466823 at 60-digit mpmath precision. These twelve
inequalities are ordinary finite numerical diagnostics, not an interval
certificate or dimension extrapolation; the proof is PK6--12.

```python
from fractions import Fraction as F
import mpmath as mp
mp.mp.dps=60
checks=0
for s,t in [(F(1),F(2)),(F(1),F(3,2)),(F(1),F(5,4)),
            (F(1),F(65,64)),(F(2),F(129,64)),(F(1,2),F(33,64))]:
 mid=(s+t)/2; h=(t-s)/2
 diff=lambda x:min(s,max(F(0),mid-x))/(s*t)-max(F(0),mid-x)/(mid*mid)
 cuts=[F(0),h,mid]; area=F(0)
 for l,r in zip(cuts,cuts[1:]):
  vl,vr=diff(l),diff(r)
  if vl*vr<0:
   z=l-vl*(r-l)/(vr-vl)
   area+=(abs(vl)*(z-l)+abs(vr)*(r-z))/2
  else:
   area+=(abs(vl)+abs(vr))*(r-l)/2
 assert 2*area==(t-s)**2/(2*t*t); checks+=1
maxratio=mp.mpf(0)
for n in [1,2,4,16]:
 for es in ['0.25','0.015625','0.000244140625']:
  s=mp.mpf(1); t=s+mp.mpf(es); d=s/(8*mp.sqrt(n))
  width=min(d,(t-s)/2)/8
  Es=1/s-width/(3*s*s); Et=1/t-width/(3*t*t)
  increment=Es**n+Et**n-2/t**n
  Ed=(1/d-width/(3*d*d))**n
  delta=mp.log(t/s); A=mp.log(n+1)+4
  kernel=min(2,2*n*A*delta*delta)
  correction=4*((1+2*d*d/(3*s*s))**n-1)
  rhs=Ed*(kernel+correction)
  assert 0<=increment<=rhs
  maxratio=max(maxratio,increment/rhs); checks+=1
print('PASS',checks,'checks: 6 exact midpoint identities and',
      '12 genuine L1 source-transfer cases')
print('max source/rhs',mp.nstr(maxratio,20))
```

## PK9. Weighted dyadic prefix bound, including the last partial block

This verifies the stronger main consequence without charging the worst
layer at every level. Write ell=log(b/a), J=ceil(n ell), N=J+1, and
R_j=min(b,a exp(j/n)), 0<=j<=J. Put G_n=n A_n, where this note's
A_n=log(n+1)+4, and T=T_{a,d}. Thus G_n includes the factor n.
Let H_j=h_Rj*mu. Form the finite signed function sequence

    a_0=H_0, a_j=H_j-H_{j-1} for 1<=j<=J,

and pad it by zero to length P=2^ceil(log2 N). Its dyadic levels are
k=0,...,q-1 with q=ceil(log2 N)+1 and block length r_k=2^k.
At a fixed level the first block sums to H_min(r_k-1,J), with energy
at most T E_d(mu). All other nonzero blocks are scale increments.
Their number is at most

    M_k=ceil(N/r_k)-1=floor((N-1)/r_k)<=N/r_k.       (PK18)

Indeed the last partly padded block is just H_end-H_start, not a
second increment. When r_k>=N there are no such other blocks. Their
log-scale windows have disjoint interiors, individual length at most
r_k/n, and total length at most ell. Hence PK1 and PK12 give the
valid bound on the sum of the squared L2 norms of *all* level-k blocks,

    sum_blocks ||block||_2^2<=D_k E_d(mu),
    D_k=T+min(2N/r_k,2G_n ell r_k/n)
                                    +4N(T-1)/r_k.   (PK19)

The actual M_k can replace N/r_k throughout if desired. The formula
also covers N=1 and ell=0, with its harmless conservative error term.

Every prefix H_j=sum_{i=0}^j a_i is a sum of at most one aligned
dyadic block from each level. For arbitrary fixed positive weights
w_k, pointwise weighted Cauchy gives

    max_j |H_j|^2
       <=(sum_k w_k)sum_k (1/w_k)sum_blocks |block|^2.

Integrating and choosing w_k=sqrt(D_k) proves

    ||max_j H_j||_2^2<=(sum_k sqrt(D_k))^2 E_d(mu).  (PK20)

Weights are fixed scalars, not receiver selectors. Positivity of the
original source and the legal upward grid then give an additional
factor e^2 for the full continuous maximal response.

Put g=(1-2^(-1/2))^-1. The geometric sums yield

    sum_k sqrt(D_k)
       <=q sqrt(T)+2g(4N G_n ell/n)^(1/4)
                                      +2g sqrt(N(T-1)). (PK21)

For the middle term set U=2N, V=2G_n ell/n and split the dyadic
lengths at sqrt(U/V). On each side the square root of min(U/r,Vr)
is bounded by a geometric sequence of ratio 2^(-1/2), with boundary
term at most (UV)^(1/4); this costs at most 2g(UV)^(1/4). If V=0
the term is zero. The last term is 2sqrt(N(T-1)) times the decreasing
geometric sum, at most 2g sqrt(N(T-1)). Thus no layer-count factor
is hidden in PK21.

At d=a/(8n^(3/4)), PK17, N<=3n and G_n=n A_n make the completely
explicit arbitrary-source estimate

    ||M_[a,b]mu||_2^2
       <=e^2 [q sqrt(96/95)
             +2g(12n A_n ell)^(1/4)
             +2g sqrt(3/95)n^(1/4)]^2 E_d(mu).      (PK22)

Together with the direct estimate PK16 one can take their minimum.
Since q<=log2(3n)+2 and ell<=log2, the bracket squared is
O(sqrt(n log(n+2))+log^2(n+2))=O(sqrt(n log(n+2))) with absolute
constants. This is a maximal *smoothing-energy* comparison for the
same arbitrary positive source. It does not remove E_d(mu), change
d on different layers, or by itself grant a general weak-L1 budget.
The source extraction and any original-traffic insertion remain the
separate actual-source steps stated by the main author.
