# R254：不交尺度窗的真实共同重叠抵消

## SO1　准确新定理与来源范围

采用完整边长归一 (h_R=R^{-n}1_{[-R/2,R/2]^n})，(K_R=h_R*h_R)。令 (n\ge1)、(0<a\le b\le2a)，并设有限尺度区间 ([s_j,t_j]\subset[a,b]) 内部互不相交。定义真实两来源核
\[
 B_{s,t}=K_s+K_t-2h_s*h_t,\qquad
 A_n=n[\log(n+1)+4].
\]
本轮证明
\[
 \boxed{\|B_{s,t}\|_1\le A_n\big((t-s)/s\big)^2,}\tag{SO1.1}
\]
及其完整尺度总价
\[
 \boxed{\sum_j\|(B_{s_j,t_j})_+\|_1
 \le2\log(b/a)\sqrt{A_n}
 \le2\log2\sqrt{n[\log(n+1)+4]}.}\tag{SO1.2}
\]
所有 cross 项均是同一对实际来源的 (h_s*h_t)，未独立最大化或改成别的后验。

所以对任意非负 \(\mu\in L^1\cap L^2\)，
\[
 \boxed{\sum_j\|(h_{t_j}-h_{s_j})*\mu\|_2^2
 \le2\log(b/a)\sqrt{A_n}\,\|\mu\|_2^2.}\tag{SO1.3}
\]
这是真实正核几何给出的根阶乘 \(\sqrt{\log n}\) 的增量价。对任意非负有限 (L^1) 来源，SO1.1–2 仍是无条件核定理；但 SO1.3 的右边可能无穷。**尚未证明将 \(\|\mu\|_2^2\) 换成 \(S_d\|h_d*\mu\|_2^2\)**，其中 (d=a/(8\sqrt n)) 且 \(\eta_d(1+\eta_d)=32d^2/a^2\)、(S_d=(1+\eta_d)^n\)。不能把本结果当作 R253 对任意胞内 (L^1) 来源的目标已经闭合。

## SO2　一维三角核的参数二阶导数：边界原子必须保留

写
\[
 k_R(x)=\frac{(R-|x|)_+}{R^2},\qquad K_R=k_R^{\otimes n}.
\]
对尺度参数 (R\)，第一导数为 (L^1) 函数
\[
 \partial_Rk_R(x)=R^{-2}(-1+2|x|/R)1_{|x|<R}.
\]
第二导数是有限 signed measure：
\[
 \partial_R^2k_R
 =R^{-3}(2-6|x|/R)1_{|x|<R}\,dx
  +R^{-2}(\delta_{-R}+\delta_R).\tag{SO2.1}
\]
两端的正原子来自第一导数在移动边界处的非零值。其总变差为
\[
 \|\partial_R^2k_R\|_{\rm TV}
 =R^{-2}\left[2\int_0^1|2-6u|du+2\right]
 =\frac{16}{3R^2}.\tag{SO2.2}
\]
这些是参数分布导数；不声称第二导数作为空间 (L^1) 函数存在。下文对测试函数先成立，再以有限 TV 控制积分；不会把边界原子删去。

## SO3　中心化 score 的可积二次交叉和

在一维概率密度 (k_R(x)dx) 下，令 (U=|x|/R\)。其密度为 (2(1-u)1_{0<u<1}\)。令
\[
 Z=(1-U)^{-1},\qquad X=Z-2.
\]
则 (Z) 的密度是 (2z^{-3}1_{z>1}\)，并且
\[
 \mathbb EX=0,\qquad\mathbb E|X|=1,
 \qquad \frac{R\partial_Rk_R(x)}{k_R(x)}=X
 \quad(k_R(x)>0).
\]
\(\mathbb EX^2\) 发散，所以不能把无限方差的正、负项分拆后使用 variance 公式。

对 (n\ge2\)，仅在有限截断上操作：(X'=X1_{Z\le n}\)。直接积分得
\[
 \mathbb E|X-X'|=2/n-2/n^2\le2/n,
 \quad|\mathbb EX'|\le2/n,
\]
\[
 \mathbb E(X')^2
 =2\log n+8/n-4/n^2-4\le2\log n,
 \qquad\mathbb E|X'|\le1.\tag{SO3.1}
\]
令 (X_1,\ldots,X_n) 独立同分布。有限截断下有
\[
 \begin{aligned}
 \mathbb E\left|\sum_{i\ne j}X_i'X_j'\right|
 &\le\mathbb E\left(\sum_iX_i'\right)^2+
       \mathbb E\sum_i(X_i')^2\\
 &\le4n\log n+4.
 \end{aligned}
\]
逐个乘积相减并用不同坐标独立性，
\[
 \mathbb E\left|\sum_{i\ne j}(X_iX_j-X_i'X_j')\right|
 \le2n(n-1)\mathbb E|X-X'|\mathbb E|X|
 \le4(n-1).
\]
故得到有限且显式的真实交叉和估计
\[
 \boxed{\mathbb E\left|\sum_{i\ne j}X_iX_j\right|
 \le4n\log n+4n.}\tag{SO3.2}
\]
这里每个不同坐标乘积绝对可积；没有把右边改成无穷的单坐标平方和。

## SO4　三角张量的参数二阶总变差

参数乘积法则（signed measure 意义下）给
\[
 \partial_R^2K_R
 =\sum_i(\partial_R^2k_R)_i\!\bigotimes_{\ell\ne i}k_R
 +\sum_{i\ne j}(\partial_Rk_R)_i(\partial_Rk_R)_j
       \!\bigotimes_{\ell\ne i,j}k_R.
\]
第一和的 TV 至多 (16n/(3R^2)\)。第二和是一个整体的绝对连续 signed measure；其 (L^1) 范数由 SO3.2 至多为
\(R^{-2}(4n\log n+4n)\)。所以 (n\ge2) 时
\[
 \|\partial_R^2K_R\|_{\rm TV}
 \le R^{-2}n(4\log n+28/3).
\]
(n=1) 直接使用 SO2.2。统一地，
\[
 \boxed{\|\partial_R^2K_R\|_{\rm TV}
 \le\frac{n[4\log(n+1)+10]}{R^2}.}\tag{SO4.1}
\]
对每个紧尺度区间这给出可积 TV 控制。先对光滑紧支测试函数使用参数微积分，再用 TV 对偶及近似，即可合法积分这一分布二阶导数。

## SO5　真实 mixed-scale overlap 与中点核：精确一维距离

设 (s\le t\)，(m=(s+t)/2\)，(h=(t-s)/2\)。一维 mixed overlap 是
\[
 c_{s,t}(x)=(h_s*h_t)_{\text{一维}}(x)
 =\begin{cases}
 1/t,&|x|\le h,\\
 (m-|x|)/(st),&h<|x|\le m,\\
 0,&|x|>m.
 \end{cases}
\]
与 (k_m) 相比，负差仅在 \(|x|<mh/t\)；其负部积分为 (h^2/t^2\)。两密度积分均为一，因此
\[
 \|c_{s,t}-k_m\|_1=2h^2/t^2
                    =\frac{(t-s)^2}{2t^2}.\tag{SO5.1}
\]
对概率密度张量逐因子 telescoping，不产生指数费用：
\[
 \|h_s*h_t-K_m\|_1
 \le n\|c_{s,t}-k_m\|_1
 =\frac{n(t-s)^2}{2t^2}.\tag{SO5.2}
\]
这一步没有假定不同坐标取独立最坏尺度；所有坐标仍共用同一 (s,t\)。

## SO6　短窗二阶抵消及全部窗的总价

参数二阶差的积分公式为
\[
 K_{m-h}+K_{m+h}-2K_m
 =\int_{-h}^h(h-|v|)\,\partial_R^2K_{m+v}\,dv.
\]
结合 SO4.1 及 \\(m+v\ge s\\)，
\[
 \|K_s+K_t-2K_m\|_1
 \le\frac{(t-s)^2}{4s^2}n[4\log(n+1)+10].
\]
再把真实 cross 留到最后，用 SO5.2：
\[
 \begin{aligned}
 \|B_{s,t}\|_1
 &\le\|K_s+K_t-2K_m\|_1
       +2\|K_m-h_s*h_t\|_1\\
 &\le n[\log(n+1)+7/2]\big((t-s)/s\big)^2\\
 &\le A_n\big((t-s)/s\big)^2.
 \end{aligned}
\]
这证明 SO1.1。由于 \(\int B_{s,t}=0\)，其正部 (L^1) 质量是全 (L^1) 范数的一半。另有 (B_{s,t}\le K_s+K_t\)，故正部质量不超过 (2\)。令 \(\delta=\log(t/s)\le\log2\)，使用 \(e^\delta-1\le2\delta\) 得
\[
 \|(B_{s,t})_+\|_1\le\min\{2,2A_n\delta^2\}
 \le2\sqrt{A_n}\,\delta.\tag{SO6.1}
\]
不交窗的总对数长度不超过 \(\log(b/a)\)，所以求和即得 SO1.2。零长度窗及 (a=b) 情形自动为零。不需要窗数有限上界、最小窗长或选定的离散网格。

## SO7　回到真实来源：已付的 L2 范围与未付的平滑能量桥

对非负 (\mu\in L^1\cap L^2\)，原平方响应精确为
\[
 \|(h_t-h_s)*\mu\|_2^2
 =\iint B_{s,t}(y-z)\mu(y)\mu(z)\,dy\,dz.
\]
正来源允许把核上放为其正部，Young–Cauchy 给
\[
 \iint(B_{s,t})_+(y-z)\mu(y)\mu(z)\,dy\,dz
 \le\|(B_{s,t})_+\|_1\|\mu\|_2^2.
\]
使用 SO1.2 得 SO1.3，所有来源只保留原 \(\mu\) 一次。

对任意有限 (L^1) 来源，原每个尺度响应依然属于 (L^2\)，但这不授予 \(\mu\in L^2\)。真正待接回的最短条件是下列**同一正核族的来源平滑控制**（一个足够条件，而非本轮已证）：
\[
 \iint\Big[\sum_j(B_{s_j,t_j})_+\Big](y-z)
                   \,d\mu(y)d\mu(z)
 \le C S_d\|h_d*\mu\|_2^2
               \sum_j\|(B_{s_j,t_j})_+\|_1.\tag{SO7.1, 未证}
\]
SO7.1 若有维数无关常数，将与本轮核价一起证明目标。但仅知道正核的积分质量不足以授予它；本轮证明的核含短尺度边界结构，R252 单个 cube 的二阶采样定理没有自动适用于这些核。也不能把 Young 不等式里的 \(\|\mu\|_2\) 换成更小的 \(\|h_d*\mu\|_2\)。

较弱但实际可核的情形是原来源本身满足
\(\|\mu\|_2^2\le Q S_d\|h_d*\mu\|_2^2\)：SO1.3 随即给 (Q\) 倍的目标。这里 (Q\) 必须由原来源核实并收费，不假设胞内均匀、不删除 full posterior 来源、不从 cut/rank 推出密度帽。对已有原密度上界的来源，可用 \(\|\mu\|_2^2\le\|\mu\|_\infty\|\mu\|_1\)；但一般高浓缩余源并未获得这个条件。

本轮正向增量是 SO1.1–2 的二阶共同重叠抵消，不是另写 R253 的未付 (L_{s,t}\)。它已把 Lebesgue 核总价从线性尺度级降到根阶乘 \(\sqrt{\log n}\)；任意 (L^1) 来源到平滑能量的传递仍未证，因而一般原交通的根阶总目标仍开放。

## SO8　实际本机公式核验及复现

本轮在本机 Python 标准库上实际运行以下固定范围：8 组有理尺度的 midpoint 距离精确检查，5 个截断维数的 score 积分 Simpson 核查，以及单坐标导数 TV 精确检查，共 25 条断言通过。Simpson 每段固定 65536 子区间，截断二阶矩与公式的最大浮点差为 (9.414691248821327\times10^{-13}\)。这些是公式核验，不替代 SO2–6 的一般证明，也未检查原 FULL 交通或授予 SO7.1。完整最小复现代码如下。

```python
from fractions import Fraction as F
from math import log
checks = 0
pairs = [
    (F(1), F(1)), (F(1), F(5, 4)), (F(1), F(3, 2)),
    (F(1), F(2)), (F(3, 2), F(7, 4)), (F(7, 4), F(2)),
    (F(8, 7), F(9, 7)), (F(99, 100), F(101, 100)),
]
for s, t in pairs:
    m, h = (s + t) / 2, (t - s) / 2
    x0 = m * h / t
    def diff(x):
        cross = F(1) / t if x <= h else (m - x) / (s * t)
        return cross - (m - x) / (m * m)
    pts = sorted(set([F(0), x0, h, m]))
    value = 2 * sum((r - l) * (abs(diff(l)) + abs(diff(r))) / 2
                    for l, r in zip(pts, pts[1:]))
    assert value == (t - s)**2 / (2 * t * t)
    checks += 1

def simpson(f, a, b, N=65536):
    step = (b - a) / N
    return step / 3 * (
        f(a) + f(b)
        + 4 * sum(f(a + k * step) for k in range(1, N, 2))
        + 2 * sum(f(a + k * step) for k in range(2, N, 2)))

errors = []
for n in (2, 3, 8, 32, 128):
    second = simpson(lambda v: 2 / v - 8 + 8 * v, 1 / n, 1)
    tail = simpson(lambda v: 2 - 4 * v, 0, 1 / n)
    error = abs(second - (2 * log(n) + 8 / n - 4 / (n*n) - 4))
    errors.append(error)
    assert error < 1e-8
    checks += 1
    assert abs(tail - (2 / n - 2 / (n*n))) < 1e-10
    checks += 1
    assert second <= 2 * log(n)
    checks += 1
absfirst = simpson(lambda v: 2 * abs(1 - 2 * v), 0, 1)
assert abs(absfirst - 1) < 1e-10
checks += 1
# Exact integrals of the two affine pieces of |2-6u|, plus two atoms.
tv = 2 * ((F(1, 3) * F(2)) / 2 + (F(2, 3) * F(4)) / 2) + 2
assert tv == F(16, 3)
checks += 1
print('midpoint Fraction cases', len(pairs))
print('score dimensions', [2, 3, 8, 32, 128])
print('maximum Simpson formula error', max(errors))
print('assertions', checks, 'PASS')
```
