#!/usr/bin/env python3
"""R254 finite L1 box energy diagnostics; Fraction certificates, not FULL.
Profile integration adapted from R252 frozen numeric_checks.py (length/profile/inner).
Only this file, standard library and mpmath are required for replay.
"""
import argparse, hashlib, json, math
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fs(x): return str(x.numerator)+'/'+str(x.denominator)
def exact(x):
    if max(x.numerator.bit_length(),x.denominator.bit_length())<3000: return {'fraction':fs(x)}
    def sig(v):
        q=abs(v); return {'bits':q.bit_length(),'sha256':hashlib.sha256(q.to_bytes((q.bit_length()+7)//8,'big')).hexdigest(),'sign':-1 if v<0 else 1}
    return {'numerator':sig(x.numerator),'denominator':sig(x.denominator)}
def m(x): return mp.mpf(x.numerator)/x.denominator if isinstance(x,F) else mp.mpf(x)
def enc(x): return mp.nstr(x,50)
def length(z,l,x,R): return max(F(0),min(z+l/2,x+R/2)-max(z-l/2,x-R/2))
def profile(z,l,x,R): return length(z,l,x,R)/(l*R)
def inner(z,l,w,q,R,S):
    pts=sorted({p+sg*(T+v)/2 for p,v,T in [(z,l,R),(w,q,S)] for sg in [-1,1]}|{p+sg*abs(T-v)/2 for p,v,T in [(z,l,R),(w,q,S)] for sg in [-1,1]})
    total=F(0)
    for a,b in zip(pts,pts[1:]):
        x0,x1=profile(z,l,a,R),profile(z,l,b,R);y0,y1=profile(w,q,a,S),profile(w,q,b,S)
        total+=(b-a)*(2*x0*y0+x0*y1+x1*y0+2*x1*y1)/6
    return total

def gram(boxes,R,S):
    total=F(0)
    for mass,z,l in boxes:
        for mass2,w,q in boxes:
            val=mass*mass2
            for zi,li,wi,qi in zip(z,l,w,q): val*=inner(zi,li,wi,qi,R,S)
            total+=val
    return total

def k(x,R):return max(F(0),R-abs(x))/R**2
def cross(x,s,t):
    h=(t-s)/2;mid=(s+t)/2;x=abs(x)
    return F(1)/t if x<=h else max(F(0),mid-x)/(s*t)
def positive_affine_integral(f,pts):
    ans=F(0)
    for a,b in zip(pts,pts[1:]):
        fa,fb=f(a),f(b)
        if fa*fb<0:
            c=a+(b-a)*(-fa)/(fb-fa)
            ans+=positive_affine_integral(f,[a,c,b]);continue
        ans+=(b-a)*(max(F(0),fa)+max(F(0),fb))/2
    return ans

def scalar_cases():
    out=[]
    for s,t in [(F(1),F(1)),(F(1),F(9,8)),(F(1),F(3,2)),(F(1),F(2)),(F(5,4),F(7,4)),(F(7,4),F(2)),(F(99,100),F(101,100)),(F(3,2),F(151,100))]:
        mid=(s+t)/2;h=(t-s)/2
        points=sorted({F(0),h,mid,mid*h/t})
        diff=lambda x:cross(x,s,t)-k(x,mid)
        val=2*(positive_affine_integral(diff,points)+positive_affine_integral(lambda x:-diff(x),points))
        assert val==(t-s)**2/(2*t*t)
        d=s
        # H moments from exact monomial integration; H'' regular part K, jump H'=-1.
        moment=lambda j:sum(F(math.comb(3,i))*(-1)**i*d**(3-i)*d**(j+i+1)/F(j+i+1) for i in range(4))/(3*d*d)
        assert moment(0)==d*d/12
        assert F(-1,2)-F(1,2)==-1
        # F(x)=x^4: K*F-F = H*F'' at x=1/3.
        x=F(1,3); km2=d*d/6;km4=d**4/15
        lhs=6*x*x*km2+km4;rhs=12*(x*x*moment(0)+moment(2))
        assert lhs==rhs
        for y in [F(0),d/3,d*2/3,d]:
            H=(d-y)**3/(6*d*d)
            assert H<=d*d*k(y,d)/6
        out.append({'s':fs(s),'t':fs(t),'midpoint_cross_L1':fs(val),'green_mass':fs(moment(0)),'quartic_identity_both_sides':fs(lhs),'green_domination_points':4})
    return out

def ceil_root4(a):
    r=math.isqrt(math.isqrt(a))
    while r**4<a:r+=1
    return r

def low_menu():
    def box(mass,z,l):return (F(mass),[F(x) for x in z],[F(x) for x in l])
    return [
      ('initial','one_interval',1,[box(1,[0],[F(3,8)])],F(1),F(3,2)),
      ('initial','two_unequal_intervals',1,[box(F(1,3),[-F(1,2)],[F(1,8)]),box(F(2,3),[F(1,4)],[F(1,4)])],F(1),F(2)),
      ('stress','correlated_two_boxes',2,[box(F(1,4),[-F(1,3)]*2,[F(1,10)]*2),box(F(3,4),[F(1,3)]*2,[F(1,5),F(1,8)])],F(7,4),F(2)),
      ('stress','corner_short_window',2,[box(F(1,3),[0,0],[F(1,20)]*2),box(F(2,3),[F(3,4),-F(3,4)],[F(1,16)]*2)],F(199,100),F(2)),
      ('expanded','heterogeneous_three_boxes',3,[box(F(1,6),[-F(1,2),0,0],[F(1,10)]*3),box(F(1,3),[0,F(1,2),0],[F(1,8),F(1,9),F(1,10)]),box(F(1,2),[0,0,F(1,2)],[F(1,6)]*3)],F(1),F(5,4)),
      ('expanded','opposite_corners',3,[box(F(2,5),[-F(3,4)]*3,[F(1,32)]*3),box(F(3,5),[F(3,4)]*3,[F(1,16)]*3)],F(3,2),F(2))]

def bound(n,s,t,d):
    # log(n+1)<=ceil(log2(n+1)), log(t/s)<=t/s-1.
    logup=n.bit_length(); Aup=n*(logup+4)
    kern=min(F(2),F(Aup,2)*((t-s)/s)**2)
    err=4*((1+2*d*d/3)**n-1)
    return kern,err

def source_cases():
    out=[]; numerical=[]
    for phase,name,n,boxes,s,t in low_menu():
        d=F(1,8*ceil_root4(n**3));es=gram(boxes,s,s);et=gram(boxes,t,t);c=gram(boxes,s,t);ed=gram(boxes,d,d);inc=es+et-2*c;kb,er=bound(n,s,t,d)
        assert inc>=0 and ed>0 and inc<=(kb+er)*ed
        assert es<=(1+2*d*d/(3*s*s))**n*ed
        assert et<=(1+2*d*d/(3*t*t))**n*ed
        out.append({'phase':phase,'name':name,'n':n,'boxes':[{'mass':fs(v),'centres':list(map(fs,z)),'sides':list(map(fs,l))} for v,z,l in boxes],'s':fs(s),'t':fs(t),'d':fs(d),'E_s':exact(es),'E_t':exact(et),'cross':exact(c),'increment':exact(inc),'E_d':exact(ed),'rational_kernel_mass_upper':fs(kb),'transfer_error':exact(er),'transfer_margin':exact((kb+er)*ed-inc),'fixed_scale_s_margin':exact((1+2*d*d/(3*s*s))**n*ed-es),'fixed_scale_t_margin':exact((1+2*d*d/(3*t*t))**n*ed-et)})
        numerical.append((name,n,s,t,d,inc/ed,kb+er,1))
    base=[(F(1,3),[F(-1,4)],[F(1,8)]),(F(2,3),[F(1,4)],[F(1,4)])]
    for n in [1,4,16,64,81,256]:
        d=F(1,8*ceil_root4(n**3));ed=gram(base,d,d)**n;total=F(0);rbound=F(0);smallest=None
        for j in range(n):
            s=F(n+j,n);t=F(n+j+1,n)
            es=gram(base,s,s)**n;et=gram(base,t,t)**n
            inc=es+et-2*gram(base,s,t)**n
            assert es<=(1+2*d*d/(3*s*s))**n*ed
            assert et<=(1+2*d*d/(3*t*t))**n*ed
            kb,er=bound(n,s,t,d)
            assert inc>=0 and inc<=(kb+er)*ed
            total+=inc;rbound+=kb+er
            margin=(kb+er)-inc/ed
            smallest=margin if smallest is None else min(smallest,margin)
        er=4*((1+2*d*d/3)**n-1)
        out.append({'phase':'expanded','name':'tensor_two_interval_'+str(n),'n':n,'implicit_source_boxes':str(2**n),'one_coordinate_mixture':[{'mass':fs(v),'centre':fs(z[0]),'side':fs(l[0])}for v,z,l in base],'d':fs(d),'exact_target_d':ceil_root4(n**3)**4==n**3,'nodes':'1+j/n, j=0..n','intervals':n,'N_le_3n':True,'fixed_scale_endpoint_checks':2*n,'E_d':exact(ed),'increment_sum':exact(total),'sum_rational_transfer_coefficients':exact(rbound),'smallest_interval_normalized_margin':exact(smallest),'sum_error_coefficients':exact(n*er)})
        numerical.append(('tensor_two_interval_'+str(n),n,F(1),F(2),d,total/ed,rbound,n))
    return out,numerical

def numerical_rows(data,dps):
    with mp.workdps(dps):
        out=[]
        for name,n,s,t,d,ratio,rbound,N in data:
            A=n*(mp.log(n+1)+4);err=4*mp.expm1(n*mp.log1p(2*m(d)**2/3))
            out.append({'name':name,'normalized_increment':enc(m(ratio)),'conservative_rational_transfer_upper':enc(m(rbound)),'whole_window_kernel_price':enc(2*mp.log(m(t)/m(s))*mp.sqrt(A)),'sum_transfer_error':enc(N*err),'error_over_sqrt_n':enc(N*err/mp.sqrt(n))})
        return out

def price_rows(dps):
    with mp.workdps(dps):
        out=[]
        for n in [16,256,4096,65536,2**24,2**40]:
            nr=ceil_root4(n**3);d=F(1,8*nr);sqrt_n=math.isqrt(n)
            assert sqrt_n**2==n and nr**4==n**3
            nx=n*2*d*d/3
            geometric_excess=nx/(1-nx)
            assert geometric_excess<=F(1,95*sqrt_n)
            J=int(mp.ceil(n*mp.log(2)));q=J.bit_length()+1
            Tminus=mp.expm1(n*mp.log1p(2*m(d)**2/3));T=1+Tminus
            kernel=2*mp.log(2)*mp.sqrt(n*(mp.log(n+1)+4))
            raw=mp.e**2*q*q*(T+kernel+4*J*Tminus)
            alternative=mp.e**2*(J+1)*T
            previous=min(raw,alternative)
            N=J+1;An=n*(mp.log(n+1)+4);ell=mp.log(2)
            level_D=[];counts=[]
            for level in range(q):
                block=2**level;count=(N+block-1)//block
                assert (count-1)*block<N<=count*block
                assert (count-1)*block<=N
                if N<=10000:
                    assert count-1==len({i//block for i in range(N)}-{0})
                counts.append(count-1)
                level_D.append(T+min(mp.mpf(2)*N/block,2*An*ell*block/n)+mp.mpf(4)*N/block*Tminus)
            sqrt_sum=sum(mp.sqrt(v)for v in level_D)
            weighted=mp.e**2*sqrt_sum**2
            C=2/(1-1/mp.sqrt(2))
            sum_upper=q*mp.sqrt(T)+C*(4*N*An*ell/n)**mp.mpf('.25')+C*mp.sqrt(N*Tminus)
            assert sqrt_sum<=sum_upper
            P=min(previous,weighted)
            old=3*mp.e**2*n*mp.exp(32*n*m(d)**2)
            assert Tminus<=m(F(1,95*sqrt_n))
            assert 4*J*Tminus<=12*sqrt_n/mp.mpf(95)
            out.append({'n':n,'d':fs(d),'J':J,'q':q,'T':enc(T),'T_minus_1':enc(Tminus),'rational_geometric_excess_upper':fs(geometric_excess),'rational_target_excess_upper':fs(F(1,95*sqrt_n)),'derivative_error_4J_Tminus':enc(4*J*Tminus),'derivative_error_upper':enc(mp.mpf(12)*sqrt_n/95),'new_unminimized_P':enc(raw),'new_alternative_P':enc(alternative),'previous_P':enc(previous),'P_weighted':enc(weighted),'weighted_sqrt_sum':enc(sqrt_sum),'weighted_sqrt_sum_analytic_upper':enc(sum_upper),'noninitial_nonzero_block_counts':counts,'nonzero_block_count_scope':'N consecutive nonzero leaves; first block separately paid T. Exact noninitial count ceil(N/2^k)-1=floor((N-1)/2^k)<=N/2^k; small N independently enumerated.','N':N,'final_P':enc(P),'new_P':enc(P),'old_P':enc(old),'new_over_old':enc(P/old),'tau_new_over_old':enc(old/P),'scope':'Same-d analytic-price evaluation with tau=lambda*sqrt(n)/P. Old P is the R252 relaxed bound at this same d, not a union of optimized earlier branches. No physical high-dimensional source.'})
        return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));p.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md'));args=p.parse_args()
    scalars=scalar_cases();sources,data=source_cases();lo=numerical_rows(data,40);hi=numerical_rows(data,70);prices40=price_rows(40);prices70=price_rows(70)
    with mp.workdps(100):
        diffs=[abs(mp.mpf(a[k])-mp.mpf(b[k]))/max(1,abs(mp.mpf(b[k]))) for a,b in zip(lo,hi) for k in a if k!='name']
        diffs += [abs(mp.mpf(a[k])-mp.mpf(b[k]))/max(1,abs(mp.mpf(b[k]))) for a,b in zip(prices40,prices70) for k in a if isinstance(a[k],str) and k not in ['d','rational_geometric_excess_upper','rational_target_excess_upper','scope','nonzero_block_count_scope']]
        maxdiff=enc(max(diffs));assert max(diffs)<mp.mpf('1e-36')
    result={'schema':'R254-finite-L1-energies-v1','scope':'Finite actual positive-volume L1 box sources. Rational source-transfer comparisons test instances only; no general lemma, FULL, or root closure certificate. MP log prices are non-interval diagnostics.','script_sha256':sha(__file__),'contract_sha256':sha(args.contract),'counts':{'scalar_fraction_cases':len(scalars),'true_L1_source_models':len(sources),'low_dimensional_models':6,'factorized_tensor_models':6,'source_interval_checks':sum(r.get('intervals',1)for r in sources),'precision_values_compared':len(diffs),'fixed_scale_endpoint_checks':2*sum(r.get('intervals',1)for r in sources),'scalar_price_cases':len(prices70),'weighted_dyadic_block_count_checks':sum(len(v['noninitial_nonzero_block_counts'])for v in prices70)},'scalar_fraction_cases':scalars,'source_models':sources,'mp40':lo,'mp70':hi,'scalar_price_mp40':prices40,'scalar_price_mp70':prices70,'precision_max_relative_difference':maxdiff,'precision_scope':'50 digit serialization retains 40/70 working precision differences; not certified quadrature errors. No numerical spatial quadrature: all source energies use Fraction piecewise polynomial integrals.','provenance':'profile/inner generalizes R252 frozen numeric_checks.py length/profile/inner; mixed-scale arguments and tensor energies implemented independently here.'}
    args.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':result['counts'],'max_relative_difference':maxdiff}))
if __name__=='__main__':main()
