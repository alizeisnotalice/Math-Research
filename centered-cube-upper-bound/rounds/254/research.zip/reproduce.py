#!/usr/bin/env python3
"""Frozen R254 hashes, exact diagnostics, and embedded author checks."""
from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,re
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
for name,expected in manifest['sha256'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
print('manifest PASS',len(manifest['sha256']),flush=True)
with tempfile.TemporaryDirectory(prefix='cube-r254-replay-') as tmp:
    output=Path(tmp)/'numeric_checks.json'
    subprocess.run([sys.executable,str(root/'numeric_checks.py'),'--contract',str(root/'task_contract.md'),'--output',str(output)],check=True)
    assert output.read_bytes()==(root/'numeric_checks.json').read_bytes(),'numeric JSON differs'
    print('numeric JSON byte-identical PASS',flush=True)
    for name in ['scale_overlap.md','pair_kernel_geometry.md']:
        blocks=re.findall(r'```python\n(.*?)```',(root/name).read_text(),re.S)
        assert blocks,('missing embedded reproduction',name)
        for i,block in enumerate(blocks):
            script=Path(tmp)/(name+'.'+str(i)+'.py');script.write_text(block)
            subprocess.run([sys.executable,str(script)],check=True)
        print('embedded checks PASS',name,len(blocks),flush=True)
for name,expected in manifest['sha256'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
print('post-replay hashes PASS; no PDF compilation')
