# R254 独立审核

## 命题先行筛查：未读scale_overlap作者证明

目录仅有作者文件时先独立推导，不改他人、不Git/PDF/spawn。原µ为同一任意非负有限L1来源，d>0；不替换胞内分布或Π。

### 1. 确定性插值主引理：PASS

一维k_d(x)=(d−|x|)_+/d²，H_d(x)=(d−|x|)_+³/(6d²)。分布上H_d''=k_d−δ0：内部二阶导为k_d，0处一阶导jump=−1，±d处值/一阶导均为0。故对连续F及有限measure二阶导，

`F=k_d*F−H_d*F''`，`0≤H_d≤c k_d`，c=d²/6。

不把H_d的曲率当处处光滑函数而漏掉δ0。n维逐坐标写I=K_i−H_i∂i²，算子交换后精确展开，得到

`F=Σ_{S⊂[n]}(−1)^|S| [∏_{i∈S}H_i ∏_{i∉S}k_i]*∂^{2S}F`。

每个full product核连续非负，S非空项用measure总变差、S空项用F_+，再按H_i≤c k_i，即

`F≤K_d*[F_+ dx+Σ_{S≠∅}c^|S| |∂^{2S}F|]`。

所有不同坐标子集混合二阶导都必须是有限signed measures；仅各纯∂i²有限不足以删掉其他S。可用紧支撑mollifier/分布卷积恒等式证明，连续F及连续核使最终pointwise成立，不限a.e.。

### 2. 原来源双积分与必要guard

若预算measure G=F_+dx+Σc^|S||∂^{2S}F|为有限measure，则µ非负Tonelli和

`∫K_d(y−z−w)µ(dy)µ(dz)=<h_d*µ,shift_w(h_d*µ)>≤E_d(µ)`

给`∫F(y−z)µ²≤E_d(µ) G(R^n)`；F_+ pair可积，因此左边至少作为有定义extended signed integral成立（可为−∞）。对实际B_st连续compact support，双积分本来有限。

**泛型积分版需guard：** 只假设连续F及其mixed导measure，并不保证一般signed pair积分有定义；例如F(x)=x与无限一阶moment的有限µ会产生正负部同时无限。故finite-budget版本应明确||F_+||1<∞，或另假设pair可积；实际B_st没有此问题。点态插值引理本身不受此guard影响。µ0分支单独按零处理，避免0乘∞。

### 3. 对B_st的空间curvature费用：PASS

B_st=h_s*h_s+h_t*h_t−2h_s*h_t，a≤s≤t≤b≤2a，为连续compact support核。每坐标triangle二阶空间导TV=4/R²；cross trapezoid二阶导TV≤4/(st)（退化s=t合并内部atoms亦成立）。其余未求导坐标仍是probability L1核，所以

`TV(∂^{2S}B_st)≤4(4/a²)^|S|`。

因此N个区间的插值误差至多`4N[(1+2d²/(3a²))^n−1]`，完整subset次数未丢。当N≤3n、d=a/(8n^(3/4))时，n·2d²/(3a²)=1/(96√n)，该误差≤(12/95)√n（用e^x−1≤x/(1−x)）。这是固定d下任意原L1的E_d transfer，不是R253较粗d=a/(8√n)自动已有的结论。

若作者另证Σdisjoint||B_st,+||1≤2log2 sqrt[n(log(n+1)+4)]，与本引理即可支付每dyadic层的原L1平方增量；含一个initial response项的block另保R252 fixedscale E_d界，正性up-grid还保e²，再RM有限prefix平方预算给O(√n log^(5/2)(n+2))E_d。该推论需逐项核作者kernel定理及最终常数；未授一般weak1或全部来源root。

本机实际20组Fraction H≤c k节点及H质量/jump算术诊断PASS；一般分布与张量证明如上，不以有限节点代替。等待作者稿和主整合。

## scale_overlap 完整作者稿审核

**SO2–6 PASS。** 尺度参数二阶导的两个移动边界原子均为+R^−2；内部绝对积分10/(3R²)加原子2/R²给16/(3R²)。纯kernel概率score Z−2的二阶矩无限，作者只在有限截断Z≤n上使用平方矩；different-coordinate乘积L1可积，截断整体界4nlog n+4与尾差4(n−1)合成4nlog n+4n准确。这里tensor独立仅描述kernel Lebesgue积分，不授原来源/Π坐标独立。

乘积参数二阶导TV≤n[4log(n+1)+10]/R²，n1另用16/3。该族作为test函数后的weak measure积分合法，不要求移动δ_R在TV范数中连续或存在Bochner导数。中点cross-triangle一维L1=(t−s)²/(2t²)，概率tensor telescoping无指数；central second差面积(t−s)²/4和cross项系数合成A_n=n(log(n+1)+4)安全。B积分0，正部为半个L1且≤2，故min(2,2A_n log²(t/s))及全不交窗2log(b/a)√A_n严格成立。

SO7直接支付L1∩L2原来源、旧coarse d=a/(8√n)的任意L1平滑transfer仍未证，这与parent另用更细d支付显式插值error不冲突。没有把Young里的||µ||2擅改成更小平滑能量。

本独审实际提取SO8全部代码运行，8 midpoint Fraction+5 score维数/TV共25断言PASS，max Simpson差9.414691248821327e−13。它是有限普通Simpson公式核算，不替代SO2–6的解析proof或认证FULL。

## pair_kernel_geometry 与新增max后果独筛

**PK1–7全文PASS。** PK2改用score截断n−1，其较松常数仍足够4n[log(n+1)+3]；n≥2时intermediate的+4被2n覆盖，最终midpoint+cross给n(log(n+1)+4)。PK3明确continuous compact f，自动满足初筛中generic signed-integral guard。全signed tensor展开后才取变差，不微分f_+。PK4正源pair/autocorr原样保留；PK5所有spatial mixed derivatives的TV与4N error单位正确。PK6 d=a/n^.75（无8）与parent较细d带8为不同安全选择，不混常数。

独审实际提取PK7代码运行，6有理midpoint及12真实uniform小cube L1 transfer共18检查PASS，max source/rhs=.049058783246551466823，普通mp60非区间。

主代理新增consequences已在读主稿前独筛：插值F=K_R直接给E_R≤T_R E_d，T_R=(1+2d²/(3R²))^n。N=J+1尺度节点、J=ceil(nlog(b/a))、q=ceil(log2N)+1。每dyadic层唯一包含f0=h_aµ的首block telescopes为h_Rµ，其余非零blocks给互不交窗口、数≤J。因此每层平方和≤[T_d+2L√A_n+4J(T_d−1)]E_d，prefix Cauchy q²和positive roundup e²均须保留。Padding、a=b/N1和首block资格成立；不是逐阶Minkowski漏平方。

fine d=a/(8n^.75)时T_d≤96/95，T_d−1≤1/(95√n)，所以J≤3n给12√n/95纠正。直接union e²NT_d是同一M的另一界，可取min而无菜单倍数。由最终square系数P取energy/mass threshold τ=λ√n/P，实际σ满足E_dσ≤τmass即可付εX+√n mass/(4ε)；所有P仍隐含完整scale费用，且原high残余继续保留，尚非一般weak1闭合。等待主稿和最终数值后绑定。

## 主稿T1–T11完整整合审查

**PASS。** T3明确F连续compact支撑，finite Γ与signed pair积分guard齐备；全source positive不可改signed。T5显式保4M(T_d−1)，任意窗口数不自动免费截到3n。T6对K_R的所有mixed TV精确为(4/R²)^|S|，给更尖固定尺度2/3参数，是本轮独立插值后果而非旧32猜测。

T7–8 finite grid的N=J+1、q=ceil log2N+1及padding到2^(q−1)一致。每层首block总响应是h_Rµ，以T6付；其他blocks的对应原尺度窗口内部不交且数≤J，T5可用。q个层与prefix Cauchy再乘q，平方总费q²无遗漏。正性upward ratio≤exp1/n、平方e²与直接union N均保留，两个同M bounds取min无菜单收费。a=b时J0/N1/q1不除0。连续R质量在每center连续（L1来源不赋cube边界质量），可数尺度保证可测，原adaptive selector合法被支配。

T9 fine d_*=a/(8n^.75)参数及12√n/95、q增长给O(√n log^(5/2)(n+2))是解析推论，不依数值拟合。旧d=a/(8√n)更粗的R253 candidate仍未证，没有被换尺度后冒称完全解决。T10初始hereditary、τ=λ√n/P与unit root来源价、T11同实际E/原R及原剩余来源全部正确。唯一量词建议已修：T4现显式λ>0、ε>0。原source质量/父账/双Π不能擅换成完整输入W；R222/R223信用边界保留。

## 正式数值源码与说明静审

最终菜单8 scalar Fraction、12真L1（6低维+6factorized tensor）、428增量区间、856端点核、6纯price、120精度字段，与说明一致。Mixed-scale profile全部支撑/平台knots分段线性乘积Fraction积分，即使R<sourcebox side也有效。tensor是明确product-mixture输入，不是给一般来源强加坐标独立；巨大2^n盒source按1D能量乘幂精确表示。

rational d=1/[8 ceil fourthroot(n³)]≤理论fine d；只有完美维度等号，JSON有标记。conservative kernel bound用A_up=n(ceil log2(n+1)+4)，positivepart≤A_up relativewidth²/2，再加完整derivative error；没有用浮点log当有理cert。巨大Fraction的位数/整数SHA摘要仍来自实际精确运算，可由完整source定义重建。40/70数值price含J=ceil(nlog2)普通计算，不是区间证书或general ceiling proof；主q/N费由解析定义保证。

6个price只在同d比较新P与R252 relaxed P_old，τ比=P_old/P，不宣称优于所有历史可优化分支，也无高维FULL实例。当前notes的8Green例只测试矩、quartic identity与每例4个有理支配点，一般分布主引理由解析证明；source Fraction checks不代替一般RM。等待报告/driver最后静审及最终hash冻结。

## 最终结论、证据归属与复现

**PASS，无待修数学阻断，可冻结。** 新通用工具T1–T9确实支付了真实kernel cross抵消与任意正L1来源的空间插值传递；不能再把这两个已证步骤泛称未付。但窗口任意多时的4M error、旧更粗d候选、原high残余与全局source/doubleΠ/soft预算仍未闭合。T10–11是明确energy/mass条件下的真实部分原来源付款，不是整个函数类weak1结论。

最终λ>0、ε>0量词已实读；compactF限定解决初筛generic signed-pair可能无定义的guard。PK7新增固定尺度2/3与95/96参数句逐项核过，与主稿一致；原有限检查block仅随章节重编号为PK8，代码数学未变。

最终numeric/code/notes/report静审PASS。已直接读取JSON核8 scalar、12实际L1模型(6低维/6product tensor)、428增量窗、856端点断言、6纯price、120精度字段，最大relative差4.408757517e−41。Factorized模型为具体L1输入，不是给一般来源假定独立；巨大精确有理运算按位数及整数SHA摘要并可重建。Finite对比不作为通用RM或维数阶证明；ordinary40/70 log/price含有限ceil计算不是interval证书。新旧P价只同d比较，不说优于全部已优化历史分支。

本独审实际运行：初筛20组Peano有理节点/质量与jump诊断（临时非独立归档程序，不列正式receipt）；SO8全部25检查（8有理midpoint、score Simpson/TV，maxerror9.414691248821327e−13）；PK最终不变代码的18检查（6有理midpoint、12真L1小cube transfer，maxratio.049058783246551466823）。后两代码均嵌作者稿可重放。最终脚本/合同JSON自绑定PASS，全部报告计数直接复核。未重跑正式numeric全套，不冒称主代理完整字节复放或作者工作为本人执行。主代理已报告完整numeric生成与字节比较通过；最终manifest归档后完整驱动回执由主代理另存，不再改本audit。

reproduce.py静审PASS：manifest['sha256']全部前验，临时目录中实际运行numeric并逐字节比对完整JSON，抽取两作者python blocks运行，然后全部hash后验。路径与contract显式传入，临时产物不改原数值；附码assertions均已归档。不存在把runtime、FULL或PDF编译作为本轮已验证内容。report保留全部剩余原账及已付R222/R223边界，无额外信用消费。

## 冻结受审SHA256

不绑定audit自身；以下后续变更需要重新核对。

|文件|SHA256|
|---|---|
|task_contract.md|`d02dcce234173dd38cf396b67afd22ffca3fbe8348bac16f36f0a7ef7e1ebfbd`|
|proof.tex.txt|`7ec360766aef8030e6d5c1ecc0bb6eba9e5c2f29aae4dd4a4df33719a89acf87`|
|scale_overlap.md|`5b131b750d891da510ff18ac2f731b463607fc3c27925ec3c5e0dfadbd74ea91`|
|pair_kernel_geometry.md|`6c234923b1a1a990d8bc464aaa2b836ced78c8131949aaaff9b35e0afc0258a5`|
|report.md|`0a6aebc7a4c08537d97fff55878f858253983d12d940d4333eaa7faa78a41397`|
|reproduce.py|`a37c6583eec418bbf78021b6ce7ca5ec41b8b06949f8e298e580e04cfe33939f`|
|numeric_checks.py|`553e2a03103a3615033d18f2122d8802668f4b17bc5b3604647e6158015cc8bb`|
|numeric_checks.json|`2c2bbdef2af751e31bc6e8daad1851d07ebeae4ac709b74331d384d8c15ca2b8`|
|numeric_notes.md|`808a443a552cf23e580c29edf9eee103e3d4b5dd6ee2b69a5f4e39b770a1c46e`|

R254审计完成，audit.md至此冻结并停止写入。

## 经主代理授权重开：加权dyadic层的新引理独筛

前述冻结SHA保留为旧版本历史，本次只审新增引理，不重跑已过physical或作者检查。尚未读新appendix时独立推导如下。

令level blocklen r=2^k，k=0,...,q−1。唯一首block仍按T支付，其余非零block数≤ceil(N/r)−1≤N/r；每段logwidth≤r/n且总logwidth≤ell。所以每层kernel正部质量同时≤2N/r及2A_n ell r/n，mixed-derivative插值误差≤4N/r(T−1)。因此D_k=T+min(2N/r,2A_n ell r/n)+4N/r(T−1)确为该层的真实平方能量上界。首block与pad/末点截b均未漏，所有参数固定于来源/receiver之外。

对任一prefix，最多每层一block。任意w_k>0，逐点weighted Cauchy与所有blocks非负平方求和给

`||maxprefix||²≤(Σw_k)Σ(D_k/w_k)E_d`。

取w_k=√D_k，得到(Σ√D_k)²E_d，仍保连续R的e²正性取整。它不需要正交性，也不把层间来源换成独立副本。与旧P取min是同一个M的两合法价，不额外菜单收费。

√(T+K+error)≤√T+√K+√error。kernel和的项为min(√(2N)2^(−k/2),√(2A_n ell/n)2^(k/2))，交叉点两侧各为ratio2^−1/2的几何和，因此

`Σ√D_k ≤ q√T + [2/(1−2^−1/2)] (4N A_n ell/n)^(1/4) + [2/(1−2^−1/2)]√(N(T−1))`。

ell0单独按kernel项0，不能在交叉点比值中除0；实际D界仍成立且旧direct P可取min。q层数、N≤3n、fine d下T−1≤1/(95√n)均沿已证，不重新假定。平方为O(log²(n+2)+√(nlog(n+2)))，且log³(n+2)≤(81/e³)n使它可统一写O√(nlog(n+2))，包括小n用绝对常数。因此新严格阶优于旧的q²统一层费；一般high/weak1仍未闭合。

独立实际只新增2个ordinary mp70 scalar交叉检查n256及2^40，Σ√D/闭式cap=.5533086109412573/.8355686081359954，weighted/旧RM价=.249578571132002/.02056934232342113，均通过。只作新引理算术诊断，非区间或physical模型；未重复旧25/18嵌入检查。等待新主稿/6scalar价格版本最终绑定。


## 加权修订最终整合审查与重新冻结

**PASS，无新增待修阻断。** 最终主稿 T8、T9a–b 及作者 PK18–22 与上述独筛一致。首块始终包含非零 f0，单独支付 T；非首块数为 ceil(N/r)−1=floor((N−1)/r)，最后部分填零块只对应一个真实尺度差。每层总窗长及单窗长共同给 min(2N/r,2A_n ell r/n)，没有把首块当作零初值增量。固定正权 sqrt(D_k) 的点态 Cauchy 不依赖正交性，不改变实际来源；e² 正性取整仍完整保留。T9a 在 2^k=sqrt(U/V) 两侧求几何和，ell=0 明确分开，常数及所有 n 因子与作者 G_n 的记号一致。

因此在相同 fine d=a/(8n^(3/4)) 上，任意非负有限 L1 原来源确有

`||M_[a,b]mu||2² <= O(sqrt(n log(n+2))) E_d(mu)`。

q² 首块费没有被删除，而由 log³(n+2)<=C n 的解析不等式吸收。T8 保留旧 union 和 unweighted RM 价格，与新 weighted 价格可取同一算子的 min；同 d、同原势下初始提取比例逐点不减，绝对来源费用仍按新质量计。主稿 T10–11、report 保留高剩余、跨带来源、soft 与双后验的未付条件，不将本工具当作一般 weak1 或 FULL 闭合。

最终 numeric 修订静审 PASS：只新增原六个 scalar price 的 D_k、weighted_P、闭式 cap 与非首块计数；没有新增或重新解释物理来源。JSON 中 150 个精度字段、110 个整数计数及其他原菜单数与 report/notes 一致。本人本次实际运行了最终源码/合同 SHA 自绑定、两 Python AST 解析，以及 JSON 全 110 个 count=floor((N−1)/2^k)、count*2^k<=N 的独立整数核验，全部通过。价格表达式中的 q=J.bit_length()+1 等于 ceil(log2(J+1))+1；小 N 另枚举并排除首块，精度说明保持 ordinary/noninterval。未重复旧物理模型或两作者已执行的 25/18 检查，也未冒称本人重放最终完整 JSON。正式完整迁移驱动由主代理在最终 manifest 后执行并另存回执。

report 最终更新的 O(sqrt(nlog(n+2)))、同势提取范围及 150/110 统计准确；reproduce.py 仍对两作者实际代码和完整 JSON 执行重放、manifest 前后校验。新 PK9 无另增运行代码，旧嵌入 18 检查仍是其原范围，不拿它替代 weighted 引理证明。

### 本次最终受审 SHA256（替代上方历史冻结表）

不绑定 audit 自身。除以下新版本外，旧冻结审查保留为历史，不混称旧数值已是本次字节重放。

|文件|SHA256|
|---|---|
|task_contract.md|`d02dcce234173dd38cf396b67afd22ffca3fbe8348bac16f36f0a7ef7e1ebfbd`|
|proof.tex.txt|`b2a8dc68e67844c01a4aec26186a97589b4e0e471d18befb4214d5db6803dbe4`|
|scale_overlap.md|`5b131b750d891da510ff18ac2f731b463607fc3c27925ec3c5e0dfadbd74ea91`|
|pair_kernel_geometry.md|`313e1c2c8d6d203b95315ddb17e5349d36993ec1900f6547301dcc78677a99f3`|
|report.md|`807269958598ae454caa9e828d2153f58ebd242b362abfa9872b97015f7ff3e1`|
|reproduce.py|`a37c6583eec418bbf78021b6ce7ca5ec41b8b06949f8e298e580e04cfe33939f`|
|numeric_checks.py|`7de361f5d2a20d70554d60b7cb16c974924fd31484809adca6e3d038b2fc4ab8`|
|numeric_checks.json|`14b1c2e56e84059cec6aa044ff7eb63a3511870446a51b65558e40f9c16d7421`|
|numeric_notes.md|`db6372276315810a70d31a82b18465c41a6a8b399303111bac23aca8eefc9303`|

R254 加权修订审计完成；audit.md 重新冻结，停止写入。
