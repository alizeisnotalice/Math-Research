# R330 — actual receiver-pair coverage; its budget remains open

**Checkpoint, not a new root receipt.** The all-row completion in `/tmp/r330_aux.md` supplies the usable common-source square. Below, an explicit Hilbert reference covers the original high-row positive term using only receiver pairs that actually serve a high row. Its exact quadratic bill is retained. No root bound for that bill, no alternative small-bill dual, and no new generally paid branch are proved here. The round's positive completion result is the auxiliary theorem, not this interface.

## 1. Contract and the more flexible square dual

Keep the frozen R329/R330 hard-matched contract, in particular actual `E,R,q`, `q_-≤q≤λ`, `q_-=3λ/4`, `a≤R≤b≤2a`, and the SAME feasible source `g≥0`, `g∈L¹`, `Tg=q`. Set

\[
 m_u=q(u)R(u)^n,\quad d\mu(u)=1_E(u)du/m_u,\quad
 c_u(y)=1_{Q_{R(u)}(u)}(y),\quad E_r=E\cap\{R\le r\},
\]
\[
 J_y(r)=\int_{E_r}c_u(y)d\mu(u),\quad
 V_y(r)=\int_{E_r}c_u(y)du,\quad Y_r=\{J_y(r)\ge H\},
\]
\[
 \ell=b^{-n}\delta_b+nr^{-n-1}1_{[a,b]}dr,\quad
 a_H(y)=\int\ell(dr)1_{Y_r}(y)V_y(r).
\]

No radius atom or paid history block is removed. On the real feature space with measure

\[
 d\xi(r,u,v)=\ell(dr)1_{u,v\in E_r}d\mu(u)d\mu(v),
 \qquad \varphi_y(r,u,v)=\frac{c_u(y)c_v(y)}{\sqrt{J_y(r)}},        \tag{1}
\]

a zero row means a zero feature. Define `Φg=∫g(y)φ_y dy`. The completed square is `Q_all(g)=||Φg||²`. The auxiliary result gives

\[
 B_H(g,g)\le\int a_Hg-Q_{\rm all}(g)+\lambda H\|g\|_1.          \tag{2}
\]

For any real `h∈L²(ξ)`, `ψ∈L¹(E)` signed, and `c≥0`, it therefore suffices that

\[
 a_H(y)-2\langle h,\varphi_y\rangle\le c+T^*\psi(y)\quad\text{a.e.},
 \qquad \|h\|_2^2+\int_E\psi q\le\varepsilon X                 \tag{3}
\]

to obtain `B_H≤εX+(c+λH)||g||₁`. This is Hilbert's inequality
`−||Φg||²≤−2⟨h,Φg⟩+||h||²`, with the unchanged identity `⟨T*ψ,g⟩=∫ψq`.

All pairings are legitimate: `||φ_y||²=∫ell J_y≤a^{-n}A_n/q_-`, so `Φg` is a Bochner-integrable feature vector for `g∈L¹`; absolute Fubini for the receiver potential follows from `∫g T*|ψ|=∫|ψ|q≤λ||ψ||₁`. An arbitrary feature reference is more flexible than requiring `h=Φg₀` for a nonnegative source `g₀`. This does not assert that such a source reference exists.

## 2. Exact coverage by active receiver pairs

Define the measurable, radius-dependent active-pair mask

\[
 \chi_r(u,v)=1_{\{|Y_r\cap Q_{R(u)}(u)\cap Q_{R(v)}(v)|>0\}}.     \tag{4}
\]

The measure in (4) is Lebesgue measure; it is a test of actual high-row incidence, not a replacement for source mass. Define

\[
 h(r,u,v)=\frac{m_u+m_v}{4\sqrt H}\chi_r(u,v).                    \tag{5}
\]

For almost every high row `(r,y)`, in the sense of `ell(dr)dy`, the active mask equals one for `μ×μ`-almost every pair with `c_u(y)c_v(y)=1`. To justify this without regularity of the selector, first use Fubini: each actual cube has Lebesgue-null boundary, so for almost every `y`, the cubes whose boundary contains `y` form a `μ`-null set. For each fixed `r`, almost every `y∈Y_r` is a Lebesgue density point of `Y_r`. If that `y` is interior to both cubes, their intersection contains a neighborhood of `y`, hence has positive intersection measure with `Y_r`. These assertions combine under the finite measure `ell`; this includes each of its atoms. Joint measurability follows by writing the intersection volume as an integral of jointly measurable indicators.

Consequently, for almost every `y∈Y_r`,

\[
 \frac{2}{\sqrt{J_y(r)}}\iint_{E_r^2}h(r,u,v)c_u(y)c_v(y)
                                      d\mu(u)d\mu(v)
 =\sqrt{\frac{J_y(r)}H}\,V_y(r)\ge V_y(r).                    \tag{6}
\]

Indeed, the numerator before dividing by `2√(HJ)` is
`∫∫(m_u+m_v)c_uc_v dμdμ=2J_yV_y`. Low rows contribute nonnegatively. Integrating (6) gives the exact covering inequality

\[
 a_H(y)\le2\langle h,\varphi_y\rangle\quad\text{a.e. }y.        \tag{7}
\]

There is no receiver translation and no common-source density cap. If there are no high rows, this reference vanishes; unneeded intersecting pairs are not charged.

The exact bill is

\[
 \boxed{\quad
 \mathcal C_H=\|h\|_2^2
 =\frac1{16H}\int\ell(dr)\iint_{E_r^2}\chi_r(u,v)
 \left(\frac{m_u}{m_v}+\frac{m_v}{m_u}+2\right)dudv.
 \quad}                                                        \tag{8}
\]

Thus `B_H≤λH||g||₁+C_H`. The active mask in (8) depends on the true prefix radius. It must not be replaced by a mask at `max(R(u),R(v))` while performing the `ell` integration.

A source-occupancy-adapted version improves this candidate without changing coverage. On an active pair put

\[
 j_*(r,u,v)=\mathop{\rm ess\,inf}_{y\in Y_r\cap Q_u\cap Q_v}J_y(r),
 \qquad h_*(r,u,v)=\frac{m_u+m_v}{4\sqrt{j_*(r,u,v)}}\chi_r(u,v). \tag{8a}
\]

On inactive pairs define `h_*=0`. One has `H≤j_*≤A_n/q_-`. Measurability follows by testing, at rational thresholds `t`, whether
`∫1_(Y_r∩Q_u∩Q_v)1_(J_y(r)<t)dy` vanishes. Essential-infimum and Fubini give `j_*≤J_y(r)` for almost every captured high `(r,y,u,v)`. Thus the integrand in the coverage calculation is at least the same expression with `√j_*` replaced by `√J_y(r)`, and its pair integral gives exactly `V_y(r)`. Therefore (7) remains valid with `h_*`, while its exact bill is

\[
 \mathcal C_*=
 \int\ell(dr)\iint_{E_r^2}\frac{\chi_r(u,v)}{16j_*(r,u,v)}
       \left(\frac{m_u}{m_v}+\frac{m_v}{m_u}+2\right)dudv
 \le\mathcal C_H.                                             \tag{8b}
\]

This is a legitimate local-occupancy improvement of the candidate, with `B_H≤λH||g||₁+C_*`. It is not a root bound on `C_*`; an active pair can still meet high rows arbitrarily close to the threshold. It retains the essential minimum on the actual common high-source region, rather than replacing local row masses by a global maximum.

## 3. The precise remaining budget and a coarse bound's limitation

Discarding only the active mask, in favor of ordinary nonempty actual-cube intersection, gives the upper bound

\[
 \mathcal C_H\le\overline{\mathcal C}_H
 :=\frac1{16H}\iint_{E^2}1_{Q_u\cap Q_v\ne\varnothing}
 \frac{m_u/m_v+m_v/m_u+2}{\max(R(u),R(v))^n}dudv.                \tag{9}
\]

Here, and only here, the exact inclusive Stieltjes tail yields the displayed maximum-radius factor. A finite universal estimate is

\[
 \overline{\mathcal C}_H\le
 \frac7{12H}(1+b/a)^n A_n\,|E|,\qquad A_n=1+n\log(b/a).          \tag{10}
\]

For completeness, on ordered radii `s=R(v)≤t=R(u)`, the coefficient in (9) is at most `(14/3)s^{-n}`. Intersection requires `|u−v|∞≤(t+s)/2`. The full-space envelope for this shifted family has exact integral

\[
 (1+t/a)^n+n\int_a^t\frac{(t+s)^{n-1}}{s^n}ds
 \le(1+t/a)^n[1+n\log(t/a)]\le(1+b/a)^nA_n.
\]

Symmetry supplies at most a factor two, proving (10) and the required `L²` integrability of (5). This exponential *upper estimate* does not establish that the actual bill is large or that this approach is impossible. It loses exactly the active high-row information that (8) retains and can be very loose even when (8) is zero.

For `λH` of root size, the concrete open step is to control (8b), or to replace (5) by a weighted reference on these SAME actual pairs while paying any uncovered source profile by a receiver potential in (3). Precisely, a proposed weight `ω_r(u,v)` gives `h_ω=ω_r(m_u+m_v)χ_r/(4√H)`; one must check BOTH its actual squared bill and

\[
 a_H(y)-2\langle h_\omega,\varphi_y\rangle
       \le c+T^*\psi(y),\qquad
 \|h_\omega\|_2^2+\int\psi q\le\varepsilon X.                 \tag{11}
\]

The substantive geometry required is a sparsification or weighting of active actual pairs satisfying (11) with `c` at root size. High-row support of small Lebesgue measure cannot simply be deleted: its source mass is not controlled by that volume. An implementation must compute the true prefix-dependent active mask, keep local `J_y(r)` in each feature, and certify the pointwise deficit, including all unrepresented source positions. Replacing every local denominator by `J_max`, using a Schur upper bound as overlap coercivity, or omitting the rejected profile does not verify (11).

A local Python `Fraction` run verified the pair-coverage algebra and inclusive-tail conversion in finite incidence fields. Those computations are algebra diagnostics only; neither a literal-cube root certificate nor a numerical lower bound on the actual bill is claimed. This checkpoint stops here: (7) is proved, while the needed budget in (11) remains open. Only `/tmp/r330_core.md` is authored; no Git or other research file is changed.
