# Exact finite-incidence algebra diagnostics, not a literal cube model.
from fractions import Fraction as F
from itertools import product
mu=[F(1),F(3),F(5)];c=[[int(y>=u) for y in range(3)] for u in range(3)]
J=[F(1),F(4),F(9)];root=[F(1),F(2),F(3)];A=[[sum(mu[u]*c[u][y]*c[u][z] for u in range(3)) for z in range(3)] for y in range(3)]
ct=0
for g in product((F(1,3),F(1),F(2)),repeat=3):
 m=[sum(g[y]*c[u][y] for y in range(3)) for u in range(3)];V=[sum(mu[u]*m[u]*c[u][y] for u in range(3)) for y in range(3)]
 for sqrtH in (F(1),F(2),F(3),F(4)):
  H=sqrtH**2;high=[j>=H for j in J];h={};raw={}
  for u,v in product(range(3),repeat=2):
   ids=[y for y in range(3) if high[y] and c[u][y] and c[v][y]]
   h[u,v]=(m[u]+m[v])/(4*min(root[y] for y in ids)) if ids else F(0)
   raw[u,v]=(m[u]+m[v])/(4*sqrtH) if ids else F(0)
  bill=sum(mu[u]*mu[v]*h[u,v]**2 for u,v in h);rawbill=sum(mu[u]*mu[v]*raw[u,v]**2 for u,v in raw)
  assert bill<=rawbill;ct+=1
  p=[2/root[y]*sum(mu[u]*mu[v]*c[u][y]*c[v][y]*h[u,v] for u,v in h) for y in range(3)]
  assert all(p[y]>=V[y] for y in range(3) if high[y]);ct+=1
  Q=sum(g[y]*g[z]*A[y][z]**2/(root[y]*root[z]) for y,z in product(range(3),repeat=2))
  assert sum(g[y]*p[y] for y in range(3))-Q<=bill;ct+=1
  NH=sum(g[y]*V[y] for y in range(3) if high[y]);NL=sum(g[y]*V[y] for y in range(3) if not high[y])
  EH=sum(g[y]*g[z]*A[y][z]**2/J[y] for y,z in product(range(3),repeat=2) if high[y])
  assert NH-EH<=NL+bill;ct+=1
print('PASS active-pair adaptive-reference exact algebra checks',ct)
