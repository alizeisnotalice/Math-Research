# R330 independent preauthor screen — low-row completion of the hard shared square

Ownership: only /tmp/r330_audit.md. No author R330 proof has been read; no Git or other-author edits. Contract is frozen R329 HARD shared field alpha1,s0,L=R, finite E, a<=R<=b, q in[q_-,lambda], fixed U,J,A,H and A_yz=A_zy. For each nonnegative L1 candidate g require the SAME actual Tg=q on E, so the linear coefficient V_y(r)=integral_prefix c_u(y)du is unchanged. All radii and original masks remain in the full prefixes. This is not a general-soft/history identification.

## 1. Strict low-row linear payment

Define L_low(g)=integral g(y)dy integral ell(dr)1{J_y(r)<H} V_y(r). At J=0, V=A=0. If the row crosses H at inclusive tau, its low radii are exactly[a,tau), excluding the WHOLE crossing atom, even when J(tau-)=H or tau=a,b. Positive Tonelli gives

 integral_[a,tau) V_y(r)ell(dr)
 =integral_(R(u)<tau) U_y(u)q(u)R(u)^n [R(u)^(-n)-tau^(-n)]du
 <=lambda J_y(tau-)<=lambda H.

There is no terminal ell atom in this strict interval even when tau=b. A never-crossing row has low radii all[a,b], including b, and its integral is integral U_y q<=lambda J_y(b)<lambda H. Thus L_low<=lambda H ||g||1. At a crossing tau=a low cost is0; at J(b)=H use the crossing case, not the never-cross case. This source-once bound does not require small physical increments or splitting a same-radius block.

## 2. Completion, PSD and exact optimized upper relaxation

Let high={J>=H}, low={0<J<H}, and m_t=1_high+t²1_low for0<=t<=1. Define Q_t by the symmetric Gram kernel integral ell A²sqrt(m_t(y)m_t(z))/sqrt(J_yJ_z), with zero outside positive J. Its two-receiver feature representation proves PSD. Exact symmetrization gives

 E_high+t² E_low=Q_t+1/2 integral ell g_y g_z A² [sqrt(m_t(y)/J_y)-sqrt(m_t(z)/J_z)]² >=Q_t.

Here E_low is the original low-row full-square quantity, not Q_LL. Since Q_LL<=E_low<=L_low, D=L_low-Q_LL>=0. Write C=Q_HL>=0; Q_t=Q_HH+2tC+t²Q_LL. The ORIGINAL B_H=L_high-E_high therefore satisfies

 B_H<=L_high-Q_HH-2tC+t²D.

The true E_low and its whole capture square were used once to justify the inequality; they are not separate negative credits for reuse. In particular replacing D by lambda H||g||1 is a further upper relaxation, not a new equality.

Maximizing2tC-t²D over[0,1] yields gain Gamma=C²/D when D>0,C<=D; otherwise Gamma=2C-D when C>=D, including D=0. At C=D=0 set Gamma0; if D0,C>0 the maximizer is t1 and Gamma2C. All quantities refer to one common source g on both sides and the fixed original high/low split. No independent high/low source maximizers are selected.

For each fixed t, L_high+t²L_low-Q_t is concave in g on the common affine feasible cone Tg=q, because its linear terms and PSD kernel are fixed. Its pointwise infimum over t is also concave (hypograph intersection), although the original B_H itself need not be concave. Optimizing t depending on g is valid for this upper relaxation; it provides no interchange of an outer source supremum with inf_t and no general dual attainability theorem.

At a legitimately chosen lambda H of root size, L_low has root source price, but this alone is not a root bound for B_H. A useful general estimate still needs sufficient common-source cross energy C versus the full high-row first moment/energy. Whole crossing atoms belong to high and have not been paid merely by the strict low-row estimate. H and any complementary entrance cost remain fixed unless their original ledger is recomputed.

## 3. Actual bounded independent algebra diagnostics

Reviewer executed 515 Fraction assertions: {'low_bound': 240, 'completion_identity': 243, 'optimized_gain': 16, 'D_positive': 16}. Low-row tests use finite weighted incidence/source models with actual q defined from the same discrete source, not a claimed Lebesgue cube/history realization. Separate coefficientwise completed-square tests use rational square-root J values; scalar maximization includes D=0 and C=0. The all-input proof remains the analytic argument above. No author file or test was read before this screen.

Initial verdict: PASS for the stated strict-low linear receipt and optimized PSD upper relaxation; no general root certificate or whole physical-crossing payment follows merely from this completion. Await author proof/integration.

The243 completion identities were additionally replayed with an explicit Fraction root table {1:1,4:2,9:3}, verifying root squares exactly and avoiding any numerical square-root conversion. This is verification of the same cases, not an added243 distinct test cases.

## 4. Final author comparison

Read /tmp/r330_aux.md in full after independent screen, including the final provenance/general-row clarification. PASS. The fixed hard shared contract is explicit; no free PSD restoration of a zero low-row block is asserted. The exact strict-low payment, arbitrary fixed measurable m completion, its clock discrepancy credit, scalar family, D>=0, D0 endpoints and infimum concavity agree with sections1–2. The dual correctly uses a_H+l_m, or alternatively a_H and an explicitly added completion source fee; these are alternatives. All L1 pairings remain finite by the bounded hard Gram kernel. No general root receiver dual certificate, strong duality or original-history realization of every feasible g is asserted.

Final clarification correctly identifies the low-row stopping/Fubini payment as an old tool newly used for PSD completion and common-source cross gain, rather than an additional independently new theorem. General U with actual same-R nu cap yields only the analogous4lambda H Wbeta low-row linear receipt; it supplies neither hard A symmetry nor the PSD completion migration to a general-soft kernel.

Author320 Decimal tests use70-digit arithmetic and1e-60 tolerance; they are finite-incidence diagnostics, not interval or actual cube/history certificates. They are distinct from this reviewer's515 rational algebra cases. No author replay was performed by the reviewer.

Final author binding: /tmp/r330_aux.md — 60fad120a56aafdc60f29118da393c7091dd90669b1ae995ba454f12e17c315c

## 5. Full-beta/full-nu numerator and numeric implementation review

Read /tmp/r330_numeric.py/md and primary /tmp/r330_checks.py in full; no full replay. PASS. For the actual uniform Q4 source and original receiver-shell field, positive Fubini gives Z_m=integral_y,z A_yz²=sum_(i,j)(r_i r_j)^(-n) integral_Ei,Ej |Q_ri(u) intersection Q_rj(v)|² du dv. Unlike R329, both source integrals in this numerator are complete. Since each actual receiver cube is contained in Q4, replacing source integrals by the full intersection volume is exact. This remains a fixed validation input, not the lower-hard-band/history entrance.

The displacement density of the two receiver intervals is the centred overlap trapezoid l(s_i,s_j;x). The capture intersection contributes l(r_i,r_j;x)², so their product is cubic on the combined knots. The four signed n-th powers correctly expand BOTH receiver shells, and each Gram normalization includes both physical radii. No receiver/source cross term is discarded. Simpson integration is exactly cubic; the independent affine-coefficient integral matches the polynomial algebra. The low-dimensional receiver-polygon calculation clips the actual rectangle into difference-coordinate strips, triangulates, and integrates affine overlap SQUARED using Area/6 times(sum vertex squares+sum pair products), which is correct. This is actual geometric integration, not quadrature samples.

Global first moment is Mall_m=sum_(j<=m)|Ej|r_j^n, not the central-row first moment. Its complete ell sum, including b, is X=|E| for q=lambda1. For all source y, J_y<=Jcentral, and J_y0 implies A_yz0. Hence the SAME original full-square energy Eall_m>=Z_m/Jcentral_m. Therefore BH<=B_all<=X-sum ell Z/Jcentral is a legitimate complete-source UPPER BOUND for this fixture. It is not an evaluation of B_all or the high-J restricted quantity. The summation-by-parts check holds without monotonicity of Z/Jcentral. The small relative saving in tested high dimensions is a limitation of this denominator relaxation, not a general dimension/asymptotic obstruction or a root certificate. Full source masses4^n and original fields are retained.

Primary reports42625 exact numeric checks plus1150 exact scalar/PSD algebra checks=43775. The latter script includes low-clock equalities/crossing boundaries and exact scalar completion on finite Gram data; it is not an original cube realization. Author320 Decimal diagnostics and reviewer515 rational cases are separate; the reviewer has not added either to the primary total or repeated complete numeric execution.

SHA256 bindings at this review:
- /tmp/r330_numeric.py — 8520be654697b469357489073e19ae1e29fc7c120d03971cb27fec3fafcf6d41
- /tmp/r330_numeric.md — cc40f57c29981c1fe9c73402bad68c049b1b2ceaec266c963d70f7f371e27646
- /tmp/r330_checks.py — 15ffbcb659bdc43fc9125ad1552cdde640c80aa996fcc35be6dd6d3de74b9de7

## 6. Independent preauthor screen of explicit Hilbert feature certificates

Use the FULL completed hard Gram feature phi_(r,u,v)(y)=c_u(y)c_v(y)/sqrt(J_y(r)), assigned0 at J0, with base measure ell(dr)1{R(u),R(v)<=r}dmu(u)dmu(v), dmu=1_E du/[qR^n]. Write m_u=q(u)R(u)^n>0. Define active(r,u,v) by positive LEBESGUE volume of Q_Ru(u) intersection Q_Rv(v) intersection Y_r. This is a measurable pair/clock gate, not a new source-dependent witness choice. Inactive pairs have their high-y capture product zero for a.e.y by the definition of zero volume; positive Tonelli over(r,u,v,y) suffices to remove them on one Lebesgue-null set of y. Thus the proof does not require selecting a favorable point or an unproved affinity lower bound. It applies to the original L1 sources, not arbitrary singular point-source measures. Cube-face conventions are harmless null sets.

For h_H=(m_u+m_v)active/(4sqrt(H)), at every high clock for a.e.y,

 2(Phi*h_H)_r(y)=V_y(r)sqrt(J_y(r)/H)>=V_y(r).

Indeed the unweighted pair numerator is sum/integral c_uc_v(m_u+m_v)dmu_udmu_v=2V_yJ_y. The full r integral can also contain NONNEGATIVE LOW-clock contributions: only the inequality2Phi*h_H>=integral_high V sqrt(J/H)>=a_H is asserted globally. The exact finite-energy bill is

 ||h_H||²=(16H)^(-1) integral ell dr integral_prefixpair active [m_u/m_v+m_v/m_u+2]du dv.

Finite E, fixed positive a,q_- and finite b,lambda make this finite. Dropping active gives an optional larger geometric bill, not evidence that the actual active cost must be large.

For the adaptive version let j_*(r,u,v)=essinf of J_y(r) over the positive-volume intersection Q_Ru intersection Q_Rv intersection Y_r, only on active pairs. H<=j_*<=A_n/q_- and it is measurable using positive-volume rational sublevel sets of the jointly measurable J. For a.e. captured high y, j_*<=J_y(r); the simultaneous statement under the pair/r integral follows by Tonelli. Set h_*=(m_u+m_v)active/(4sqrt(j_*)). Its nonnegative high-clock contribution satisfies2Phi*h_*>=a_H, since replacing sqrt(j_*) by sqrt(J_y) lowers each pair summand and gives V_y. Inactive pairs are assigned h0 without dividing by an empty essential infimum. The exact norm is integral active[m_u/m_v+m_v/m_u+2]/(16j_*) du dv ell, at most the fixed-H bill.

For either h, the actual source energy Q_all(g)=||Phi g||² and Hilbert square inequality give Q_all>=2<h,Phi g>-||h||². Combined with the SAME full completion B_H<=L_high+L_low-Q_all and the pointwise cover a_H<=2Phi*h, this proves

 B_H(g,g)<=L_low(g)+||h||²<=lambda H||g||1+||h||².

The completion source bill occurs once; the feature norm is an actual receiver-pair cost that remains to be source/output-priced. No root estimate, small-X receiver certificate or generic geometric lower correlation follows from this construction alone. Existing crossing/large-atom payments are alternative full-slot bounds, not disjoint fees to add to this completion. No new general-soft symmetry has been proved.

Primary432 finite-incidence algebra tests are reported, including adaptive coverage, bill comparison and Hilbert completion. They are not literal cube/history validation or general-root evidence and are not counted as reviewer execution. No additional full run was made for this screen. Await final author file.

## 7. Final core, notation and integration comparison — PASS

Read final /tmp/r330_core.md in full after section6's independent screen. PASS. The feature space is the actual receiver-pair prefix space with original ell and mu, and a zero J row has zero feature. Its norm satisfies ||phi_y||²=integral ell J_y<=a^(-n)A_n/q_-, so finite L1 sources map to finite-energy Bochner vectors. The arbitrary Hilbert-reference dual is legitimate; signed psi in L1(E) has absolute Fubini via actual Tg=q. No source reference g0 is assumed to realize an arbitrary Hilbert h.

The density-point/boundary/Tonelli proof correctly obtains active-pair coverage for ell(dr)dy-a.e.high row. This also follows directly from the zero-volume inactive intersection and positive Tonelli, as independently screened. The identity is per HIGH clock only; low-clock contributions to the full feature integral remain nonnegative. Essential-infimum j_* measurability uses rational positive-volume sublevels; H<=j_*<=A_n/q_- on active pairs, and j_*<=J_y a.e. on their common high region. The adaptive bill is the original pair ratio/(16j_*), <=the fixed-H active bill. It is not replaced by a global J_max or a source density bound. Active is clock-dependent and cannot be pulled through ell using only the maximum pair radius.

The optional full-intersection envelope constant7/12 is correct. On ordered radii s<=t the ratio coefficient in(9) is at most(14/3)s^(-n). The shifted cube family envelope has exact full-space integral(1+t/a)^n+n integral_a^t(t+s)^(n-1)s^(-n)ds. Bounding this by(1+b/a)^n A_n, and then using symmetry factor at most2 with1/(16H), gives7/(12H). This proves finite energy, but its exponential upper bound does NOT prove that the actual active/adaptive bill is large or that the route fails. The exact receiver-pair bill is still unpriced at root size/small X in general.

The final numeric note uses Eall for the original square integral A²/J_y and Qall for the completed symmetric normalized Gram A²/sqrt(J_yJ_z). Section5 above has been updated to Eall notation. BOTH have lower bound Z/Jcentral in this actual fixture, while neither reciprocal integral is evaluated exactly by Z alone. The exact Z computation integrates the complete beta and nu, not only central rows, but its resulting B_all estimate remains an upper bound. No exact B_H/B_all, general asymptotic rate, lowpe/history interface or complete-root conclusion is claimed.

Read final checkpoint ledger and verification. PASS: lambda H completion source bill is retained once; it is not added to the already-separated R327/R328 crossing and large-atom bounds. Whole-slot replacements retain their actual target/recovery/outer coefficients. The low-row Fubini is accurately identified as an old mechanism with a new PSD-completion use, not independently counted twice. No free H change or free general-soft symmetry is asserted. Fixed q/common source class is kept for the variational statements. Unpaid dense-atom/continuous innovations, original source/history/time deletion slots, Phi_next/P_suffix, entrance/aspect/lowpe/wide/all-scale/outer and epsilon_original obligations remain explicit. No general new positive X error is registered, and no generally root-priced receiver-pair bill is proved.

Actual PRIMARY execution record:42625 exact numeric+1150 exact scalar/PSD+432 exact feature algebra=44207. The latter two are not cube models. Author320 70-digit Decimal tolerance tests are noninterval and separate. Reviewer515 rational algebra cases are separate;243 root-table identities were additionally replayed as verification of the SAME cases, not additional distinct cases. This reviewer did not repeat the full primary runs. No later primary typesetting is independently certified or compiled by this receipt.

Final verdict: PASS for the stronger completed hard-field upper relaxation, explicit gain, full-source-pair exact numerator diagnostic, and valid feature-cover certificate WITH its unpriced bill. No remaining correction within this bounded audit. General root closure is still open.

## 8. Frozen SHA256 bindings

- /tmp/r330_aux.md — 60fad120a56aafdc60f29118da393c7091dd90669b1ae995ba454f12e17c315c
- /tmp/r330_core.md — 5967c2b8077f5c8cc369c116cb826e62d80fa05f02071f669f1d7de9063d8fac
- /tmp/r330_numeric.py — 8520be654697b469357489073e19ae1e29fc7c120d03971cb27fec3fafcf6d41
- /tmp/r330_numeric.md — 7ce83d38d5372bf30b21b5a34c1b98654b42c7722842fbdd6c507ed6f255c865
- /tmp/r330_checks.py — 15ffbcb659bdc43fc9125ad1552cdde640c80aa996fcc35be6dd6d3de74b9de7
- /tmp/r330_feature_checks.py — 73ce8ba14a7fa356594e4b22f02dc0e9889f59f658f20ccb1bdd68f7ed848053
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round330_20261018_final_checkpoint/checks.py — 15ffbcb659bdc43fc9125ad1552cdde640c80aa996fcc35be6dd6d3de74b9de7
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round330_20261018_final_checkpoint/combined.md — 085ce16cd1a986db68918d8ec30d6e5566a61d35fd132f32c07057d725e041c7
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round330_20261018_final_checkpoint/completion.md — 60fad120a56aafdc60f29118da393c7091dd90669b1ae995ba454f12e17c315c
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round330_20261018_final_checkpoint/core.md — 5967c2b8077f5c8cc369c116cb826e62d80fa05f02071f669f1d7de9063d8fac
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round330_20261018_final_checkpoint/feature_checks.py — 73ce8ba14a7fa356594e4b22f02dc0e9889f59f658f20ccb1bdd68f7ed848053
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round330_20261018_final_checkpoint/ledger.md — 4acc283b931478b273f459b255b46adaebbf0af1365037cc57feb3b979d393c9
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round330_20261018_final_checkpoint/numeric.py — 8520be654697b469357489073e19ae1e29fc7c120d03971cb27fec3fafcf6d41
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round330_20261018_final_checkpoint/numeric_notes.md — 7ce83d38d5372bf30b21b5a34c1b98654b42c7722842fbdd6c507ed6f255c865
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round330_20261018_final_checkpoint/numeric_summary.json — 9ca805f319a2f257446a6f99bf8fadf77d565e0e44f1224008ea305f9b760c8d
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round330_20261018_final_checkpoint/research.tex — 940ea8c3e57bb03601d65981e7d51b0d4ad1e8ee56f14445938bd49c31447531
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round330_20261018_final_checkpoint/verification.txt — 20059bca1eef0d4df72ca0909b982b7b62561fdbebb215bf71e18283a10f1569

Frozen after this receipt. Only /tmp/r330_audit.md was edited. No Git, other-author edits, repeated full numeric run or TeX/PDF compilation.
