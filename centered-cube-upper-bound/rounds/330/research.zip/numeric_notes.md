# R330 — exact global source-pair tensor moments

Run (standard library only):

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r330_numeric.py
```

The script writes deterministic `/tmp/r330_numeric.json`. All calculations and assertions use exact rational arithmetic. Large fractions are stored by an explicitly described signed numerator/denominator digest and a descriptive decimal. Gates and bounds do not use those decimals.

## Formula audit and actual scope

Keep the R328 physical input: f=β=ν=1_Q4, δ=1/(4n), a=1,b=2, r_j=1+j/n, s_j=r_j−δ, E0=Q_s0 and Ej=Q_sj minus Q_s(j−1). Each receiver has s=0,L=R=r_j,q=λ=1,α=1. Its whole kernel cube lies inside Q4, so actual q=1, FIRST density1_E and the selected hard response cap hold. Source and receiver volumes are positive. No actual winner or complete original lowpe/history qualification is asserted.

This round integrates **both complete sources y,z over Q4**, not only the central β subset. With

A_yz(m)=Σ_(j≤m) r_j^(−n)∫_Ej 1_Qrj(u)(y)1_Qrj(u)(z) du,

positive Fubini gives the exact global numerator

Z_m=∫_Q4∫_Q4 A_yz(m)^2 dy dz
   =Σ_(i,j≤m)(r_i r_j)^(−n)∫_Ei∫_Ej |Q_ri(u)∩Q_rj(v)|² du dv.

All receiver kernel cubes lie inside Q4; thus the intersection measure is genuinely the full-source integral. Outer/inner shell expansion turns each term into four signed n-th powers of

I(s,t;r,v)=∫_R l(s,t;x) l(r,v;x)^2 dx,

where l is the centered-interval overlap trapezoid. Here l(s,t;x) is the difference-density of the two receiver intervals, not a source-response surrogate. It has breakpoints ±(s+t)/2 and ±|s−t|/2. The product is cubic on their common partition. The script integrates it exactly using Simpson's cubic-exact formula and separately verifies direct affine-coefficient integration.

For n1/2, a second geometric calculation integrates |Q_r(u)∩Q_v(w)|² directly on the two-dimensional receiver rectangle. It clips the rectangle into diagonal strips of u−w, triangulates each strip, and integrates the square of the affine overlap by exact triangle moments. These24 comparisons check the one-dimensional displacement formula independently before tensorization. They are not point quadrature or sampled source masses.

## The bound, and what is not computed

Let J_y(m)=∫prefix U_y. Every source row satisfies J_y(m)≤Jcentral_m=Σ_(j≤m)|Ej|r_j^(−n), simply because each kernel indicator is at most1. Central y∈Qδ attains equality, but no concentration assumption is used to apply this global upper bound. Define the contribution as0 on J_y=0, where A_yz=0. Then

Eall_m=∫β(dy)ν(dz) A_yz(m)^2/J_y(m) ≥ Z_m/Jcentral_m.

Here Eall is the original square term. With this round's separate convention Qall_m=∫β(dy)ν(dz) A_yz(m)^2/√(J_y(m)J_z(m)), the same lower bound Qall_m≥Z_m/Jcentral_m also holds; its integrand is defined as0 when either row mass vanishes.

The true global first moment is

Mall_m=Σ_(j≤m)|Ej|r_j^n.

With ell_m=r_m^(−n)−r_(m+1)^(−n), and final ell_n=b^(−n), its complete layer integral is exactly X=Σ|Ej|=(2−δ)^n. Therefore

0≤BH≤B_all≤X−Σ_m ell_m Z_m/Jcentral_m.

This is a **true full β/ν upper bound for this fixed fixture**, not an evaluation of B_all. BH is smaller because its nonnegative integrand has an additional high-J restriction. The script does not claim that this global denominator relaxation is sharp, or integrate the exact reciprocal1/J_y. Wf=Wβ=Wν=4^n and the central positive subset massδ^n remain in the result.

The terminal b atom is retained. The square-term ell sum is also checked against its discrete summation-by-parts expression, independently of whether Z/Jcentral increments are monotone.

## Actual output and interpretation

|n|X|upper bound B_all|fraction of X saved by square lower bound|
|---|---:|---:|---:|
|1|1.75|0.982291667|0.438690476|
|2|3.515625|2.936785468|0.164647689|
|4|14.091812134|13.732568040|0.0254931083|
|8|225.696367368|225.506524995|0.000841140577|
|16|57806.936123|57806.837722|1.70223445e−6|
|32|3.789367667e9|3.789367667e9|1.34159047e−11|
|64|1.627720483e19|1.627720483e19|1.59415616e−21|

The n64 upper bound and X round to the same displayed double, but their exact rational difference is strictly positive and retained. This relaxation offers very little relative saving in the larger tested dimensions. This is an honest limitation of this fixed-fixture bound; it neither proves an asymptotic rate nor establishes an extremal/general root claim.

## Reproduction record

Two fresh standalone runs passed **42,625 exact checks**. Stages: n1/2 independent115; n4/8/16 initial2,894; n32/64 expanded39,616. Counts include39,384 separate cubic-integrator comparisons,24 independent receiver-polygon integrals,2,928 nonnegative shell-pair moments,134 prefix moment bounds and7 full first-moment ell identities. The JSON records exact prefix moments/digests, full source masses and final bounds. No files from another round are imported or modified.
