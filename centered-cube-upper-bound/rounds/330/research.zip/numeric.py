#!/usr/bin/env python3
"""Full-source-pair exact tensor diagnostic, actual uniform R328 input."""
from fractions import Fraction as F
from functools import lru_cache
from collections import Counter
from pathlib import Path
import json,hashlib
C=Counter()
def ck(k,v):
 C[k]+=1
 assert v,k
def brief(x):
 if max(abs(x.numerator).bit_length(),x.denominator.bit_length())<1400:return str(x)
 a=abs(x.numerator);raw=(str(x.numerator<0)+':'+str(a.bit_length())+':').encode()+a.to_bytes((a.bit_length()+7)//8,'big')+b'/'+x.denominator.to_bytes((x.denominator.bit_length()+7)//8,'big')
 return dict(decimal=float(x),sha256=hashlib.sha256(raw).hexdigest(),encoding='negative_flag:numerator_bitlength:unsigned_numerator_bytes/unsigned_denominator_bytes')
def trap(s,r,x):return max(F(0),min(s,r,(s+r)/2-abs(x)))
def breaks(s,r):return [F(0),abs(s-r)/2,(s+r)/2]
def clip(poly,bound,above):
 out=[]
 for p,q in zip(poly,poly[1:]+poly[:1]):
  vp=p[0]-p[1]-bound;vq=q[0]-q[1]-bound;ip=vp>=0 if above else vp<=0;iq=vq>=0 if above else vq<=0
  if ip:out.append(p)
  if ip!=iq:
   t=vp/(vp-vq);out.append(tuple(p[j]+t*(q[j]-p[j]) for j in range(2)))
 return out

def polygon_integral(s,t,r,v):
 if not s or not t:return F(0)
 pts=sorted(set([-x for x in breaks(r,v)]+breaks(r,v)));total=F(0)
 for lo,hi in zip(pts,pts[1:]):
  poly=[(-s/2,-t/2),(s/2,-t/2),(s/2,t/2),(-s/2,t/2)]
  poly=clip(clip(poly,lo,True),hi,False)
  if len(poly)<3:continue
  a=poly[0]
  for b,c in zip(poly[1:-1],poly[2:]):
   area=abs((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))/2
   values=[trap(r,v,p[0]-p[1]) for p in [a,b,c]]
   total+=area*(sum(x*x for x in values)+values[0]*values[1]+values[0]*values[2]+values[1]*values[2])/6
 return total

@lru_cache(None)
def cubic(s,t,r,v,independent=False):
 if not s or not t:return F(0)
 pts=sorted(set(breaks(s,t)+breaks(r,v)));out=F(0)
 for a,b in zip(pts,pts[1:]):
  def fun(x):return trap(s,t,x)*trap(r,v,x)**2
  mid=(a+b)/2;simpson=(b-a)*(fun(a)+4*fun(mid)+fun(b))/6
  # Separate coefficient expansion of three affine factors.
  h=b-a;p=trap(s,t,a);dp=trap(s,t,b)-p;q=trap(r,v,a);dq=trap(r,v,b)-q
  coeff=h*(p*q*q+(2*p*q*dq+dp*q*q)/2+(p*dq*dq+2*dp*q*dq)/3+dp*dq*dq/4)
  ck('cubic_two_exact_integrators',simpson==coeff)
  out+=simpson
 out*=2
 if independent:ck('lowdim_receiver_polygon_integral',out==polygon_integral(s,t,r,v))
 return out

def model(n):
 delta=F(1,4*n);rs=[1+F(j,n) for j in range(n+1)];ss=[r-delta for r in rs]
 vs=[s**n-(ss[j-1]**n if j else 0) for j,s in enumerate(ss)];hs=[v/r**n for v,r in zip(vs,rs)]
 J=Z=M=F(0);Zs=[];Js=[];Ms=[]
 for j,r in enumerate(rs):
  ck('actual_q_FIRST_source_support',ss[j]/2+r/2<=2 and ss[j]/2+delta/2==r/2)
  row=[]
  for i in range(j+1):
   entry=F(0)
   for s,sign in [(ss[i],1),(ss[i-1] if i else F(0),-1)]:
    for t,sgn in [(ss[j],1),(ss[j-1] if j else F(0),-1)]:entry+=sign*sgn*cubic(s,t,rs[i],r,n<=2)**n
   entry/=rs[i]**n*r**n
   ck('source_pair_shell_Gram_nonnegative',entry>=0);row.append(entry)
  Z+=2*sum(row[:-1],F(0))+row[-1];J+=hs[j];M+=vs[j]*r**n
  # J_y<=Jcentral, 0<=A_yz<=J_y gives Z<=Jcentral*global first moment.
  ck('pair_second_moment_bound',0<Z<=J*M)
  Zs.append(Z);Js.append(J);Ms.append(M)
 ell=[r**(-n)-(rs[j+1]**(-n) if j<n else 0) for j,r in enumerate(rs)]
 X=sum(vs);first=sum((w*m for w,m in zip(ell,Ms)),F(0))
 ck('full_global_first_moment_ell',first==X==(2-delta)**n)
 squarelower=sum((w*z/j for w,z,j in zip(ell,Zs,Js)),F(0));upper=X-squarelower
 ck('true_fixture_global_upper_nonnegative',0<=upper<X)
 ck('global_square_ell_endpoint',squarelower==rs[0]**(-n)*Zs[0]/Js[0]+sum((rs[i]**(-n)*(Zs[i]/Js[i]-Zs[i-1]/Js[i-1]) for i in range(1,n+1)),F(0)))
 return dict(n=n,W_f=str(4**n),central_source_mass=str(delta**n),X=brief(X),global_first_moment_ell=brief(first),global_square_term_lower=brief(squarelower),B_all_upper=brief(upper),BH_upper_same=brief(upper),saving_fraction=brief(squarelower/X),saving_decimal=float(squarelower/X),upper_over_X=float(upper/X),X_decimal=float(X),upper_decimal=float(upper),prefixes=[dict(radius=str(r),J_central=brief(j),global_first_moment=brief(m),Z_global_pair_second_moment=brief(z),Qall_lower=brief(z/j)) for r,j,m,z in zip(rs,Js,Ms,Zs)])
def main():
 models=[];stages=[]
 for title,ns in [('small_independent',[1,2]),('initial_expansion',[4,8,16]),('expanded',[32,64])]:
  before=sum(C.values());models.extend(model(n) for n in ns);stages.append(dict(stage=title,dimensions=ns,checks=sum(C.values())-before))
 result=dict(status='PASS',total_checks=sum(C.values()),check_counts=dict(C),stages=stages,models=models,scope='True full beta=f and nu=f source-pair integrals for this fixed actual R328 receiver-shell fixture. Z and first moments exact; Qall>=Z/Jcentral yields an upper bound, not exact B_all. No general root bound or full history claim.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','total_checks','check_counts','stages']},sort_keys=True))
if __name__=='__main__':main()
