# R330 — completing low rows at a source-linear price

Status: a stronger family of positive semidefinite (PSD) quadratic upper relaxations of the frozen R329 hard-matched slot is proved. The completion price is at most `λH ||g||₁`, with no `A_n` multiplier. It recovers usable high/low cross energy on the same source `g`. A general small-receiver-bill root certificate is still not constructed. The low-row Stieltjes payment itself is the same stopping/Fubini mechanism as the earlier low-row `4λH` tools, and is not counted again as an independent new theorem. The new use here is its legal completion of the common-source square, recovering high/low energy and the explicit scalar-parameter gain.

## 1. Frozen contract and first screen

Use exactly `/tmp/r329_core.md` §1. The actual receiver set `E` is finite; `a≤R(u)≤b≤2a`, `q_-≤q(u)≤λ`, `q_-=3λ/4`, and

\[
 d\mu(u)=\frac{1_E(u)du}{q(u)R(u)^n},\quad c_u(y)=1_{Q_{R(u)}(u)}(y),
\]
\[
 J_y(r)=\int_{R\le r}c_u(y)d\mu(u),\quad
 A_{yz}(r)=\int_{R\le r}c_u(y)c_u(z)d\mu(u).
\]

The actual `E,R,q` and every prefix remain frozen. Work on the same common-source cone

\[
 \mathcal G=\{g\ge0:g\in L^1,\ R(u)^{-n}\int c_u(z)g(z)dz=q(u)\text{ a.e. on }E\}.
\]

Write `h_y(r)=1_{J_y(r)≥H}`, `H>0`, and

\[
 \ell(dr)=b^{-n}\delta_b(dr)+nr^{-n-1}1_{[a,b]}(r)dr,
 \qquad V_y(r)=\int_{R\le r}c_u(y)du.
\]

For every `g∈G`, the constraint gives `∫g(z)A_yz(r)dz=V_y(r)`. Set

\[
 a_H(y)=\int\ell(dr)h_y(r)V_y(r),\quad
 E_H(g)=\int\ell(dr)\iint g(y)g(z)h_y(r)\frac{A_{yz}(r)^2}{J_y(r)}dydz.
\]

As usual, a zero row contributes zero. The original full quantity is
`B_H(g,g)=∫a_H g−E_H(g)`.

A free PSD minorant cannot simply restore a low row: on a set where the original gated quadratic vanishes on every nonnegative source supported there, a dominated PSD form has zero energy there, hence zero cross pairing by its Cauchy–Schwarz inequality. At one fixed clock this applies to `J<H`. Thus a universal zero-cost PSD completion is blocked. The following construction pays for completing those rows; it does not assume the original arithmetic reciprocal matrix is PSD.

## 2. The exact low-row linear bill has no scale-envelope factor

Define the fixed measurable coefficient

\[
 l_H(y)=\int\ell(dr)1_{J_y(r)<H}V_y(r).
\]

Then, including all physical radius atoms and both endpoint cases,

\[
 0\le l_H(y)\le\lambda H.                                      \tag{1}
\]

Here is the proof that avoids the erroneous `λH A_n` bound. If the row first reaches `H` at `τ∈[a,b]`, right-continuity of its finite cumulative measure gives `J_y(τ)≥H` and `J_y(τ−)≤H`. Its low clocks are exactly `[a,τ)`. Positive Fubini and the actual tail identity give

\[
 l_H(y)=\int_{R(u)<\tau}c_u(y)
       [R(u)^{-n}-\tau^{-n}]du
 =\int_{R<\tau}q(u)[1-(R(u)/\tau)^n]c_u(y)d\mu(u)
 \le\lambda J_y(\tau-)\le\lambda H.                            \tag{2}
\]

The crossing atom is excluded in its entirety from this low-row bill. This is a physical-radius gate, not an internal rank ordering. If the row never reaches `H`, the explicit `b` atom completes the full tail and

\[
 l_H(y)=\int_E c_u(y)R(u)^{-n}du
        =\int_E q(u)c_u(y)d\mu(u)
        \le\lambda J_y(b)<\lambda H.                            \tag{3}
\]

These formulas also cover `τ=a`, `τ=b`, and `a=b`. A row of total mass zero has zero bill. All functions are measurable; the first crossing is a measurable stopping radius of the right-continuous measurable cumulative field. No continuous-clock hypothesis is used.

Consequently, for every `g∈G`,

\[
 L_H(g):=\int l_Hg\le\lambda H\|g\|_1.                         \tag{4}
\]

Also `l_H≤T*1_E`, so `L_H(g)≤∫_E q≤λ|E|`; this alternative is not a small receiver bill by itself.

For provenance and scope, the same old low-row argument works without hard symmetry: if an actual row field `U_y(u)≥0` has cumulative `J`, actual capture `A_yz=∫_(R≤r)U_y(u)c_u(z)du`, and the selected same-radius cap `ν(Q_R(u))≤4λR(u)^n`, then

\[
 \int\beta(dy)\int\ell(dr)1_{J_y(r)<H}
       \int A_{yz}(r)\nu(dz)\le4\lambda H W_\beta.
\]

This follows from the identical stopped tail calculation applied to `4λ∫_(R≤r)R^n dJ_y`. It does not supply `A_yz=A_zy`, a common-source Gram, or any soft extension of Sections 3–5. The improved hard constant `λH` above uses the frozen matched constraint and actual `q≤λ`.

## 3. PSD completion with its exact clock credit

Choose any fixed measurable `m_y(r)` satisfying

\[
 m=1\text{ on }\{J\ge H\},\qquad0\le m\le1\text{ on }\{J<H\}.
\]

Define

\[
 K_m(y,z)=\int\ell(dr)A_{yz}(r)^2
       \sqrt{\frac{m_y(r)m_z(r)}{J_y(r)J_z(r)}},\qquad
 Q_m(g)=\iint g(y)K_m(y,z)g(z)dydz.                            \tag{5}
\]

A factor with `J=0` is assigned zero. This is PSD, since it is the Gram kernel of the genuine two-receiver features

\[
 \varphi_{r,u,v}(y)=\sqrt{m_y(r)/J_y(r)}\,c_u(y)c_v(y)
\]

under `ell(dr)1_{R(u),R(v)≤r}dμ(u)dμ(v)`. Its scale integral contains the original `b` atom. No layer receives an independent source allocation.

Let `E_extra,m` be the same square energy with row weight `m−h`. Symmetrization gives the exact identity

\[
 E_H(g)+E_{\mathrm{extra},m}(g)=Q_m(g)+C_m(g),\qquad
 C_m(g)=\frac12\int\ell(dr)\iint gg A^2
 \left(\sqrt{m_y/J_y}-\sqrt{m_z/J_z}\right)^2\ge0.              \tag{6}
\]

Moreover `A²/J_y≤A`, so

\[
 E_{\mathrm{extra},m}(g)\le\int g(y)l_m(y)dy,\quad
 l_m(y)=\int\ell(dr)(m_y-h_y)V_y(r)\le l_H(y).                 \tag{7}
\]

The exact and priced conclusions are therefore

\[
 B_H=\int a_Hg-Q_m-C_m+E_{\mathrm{extra},m}
 \le\int(a_H+l_m)g-Q_m
 \le\int a_Hg-Q_m+\lambda H\|g\|_1.                           \tag{8}
\]

For `m≡1`, this restores the full normalized Gram, including high/low and low/low interactions; the whole reciprocal-clock discrepancy is the explicit nonnegative `C_m`. For `m=h`, it is the original R329 PSD relaxation with zero completion bill. These are alternative upper bounds on the same full slot, not additional payments to previously separated innovation blocks.

Finiteness is automatic in this hard slot: `J≤A_n/q_-`, `A≤min(J_y,J_z)`, and hence every `K_m≤A_n/(q_-a^n)`. Thus all `L¹` reference energies and pairings used here are finite.

## 4. A scalar family gives an explicit improvement over the old relaxation

Take `m_t=h+t²(1−h)`, `0≤t≤1`. Write `Q_HH` for the old high/high energy, `Q_LL` for the normalized low/low energy, and `Q_HL` for just the high-row/low-column orientation, all with coefficient `A²/√(J_yJ_z)` and the same `g`. Then

\[
 Q_{m_t}=Q_{HH}+2tQ_{HL}+t^2Q_{LL},\qquad l_{m_t}=t²l_H.
\]

The quantity `D(g)=L_H(g)−Q_LL(g)` is nonnegative: the original low-row square energy dominates `Q_LL` by symmetrization on low/low and has additional nonnegative cross terms, while it is bounded by `L_H`. Therefore

\[
 B_H(g,g)\le\int a_Hg-Q_{HH}-2tQ_{HL}+t²D(g).                 \tag{9}
\]

This is not just a paid full completion: optimizing the single common `t` never worsens the old bound. With `c=Q_HL≥0`, the gain is

\[
 \Gamma(c,D)=\max_{0\le t\le1}(2tc-t²D)
 =\begin{cases}c²/D,&D>0,\ c\le D,\\2c-D,&D>0,\ c>D,\\2c,&D=0.\end{cases}       \tag{10}
\]

The optimizer is `min(1,c/D)` when `D>0`, and `t=1` when `D=0`. Thus the old concave upper relaxation is improved by the certified nonnegative amount `Γ`; it is strictly improved whenever `Q_HL>0`. Since `D≤λH||g||₁`, replacing `D` in the maximization by that explicit upper bound gives a weaker but source-priced gain. Zero source mass gives all energies zero.

For each fixed `t`, the right side of (9) is a linear functional minus the PSD quadratic `Q_m_t`, so is concave in the same `g`. Its infimum over `t∈[0,1]` remains concave. The optimization does not copy `g` per clock, choose an independent posterior, or assert that every `g∈G` realizes an original historical construction.

## 5. Dual interface and exact scope

The R329 tangent certificate now applies to `K_m` and linear coefficient `a_H+l_m`: for `g₀≥0` in `L¹`, signed `ψ∈L¹(E)`, and `c₀≥0`, it suffices to verify

\[
 a_H+l_m-2K_mg_0\le c_0+T^*\psi\quad\text{a.e.},\qquad
 Q_m(g_0)+\int_E\psi q\le\varepsilon X,
\]

to obtain `B_H(g,g)≤εX+c₀||g||₁` for every `g∈G`. If instead a certificate is made with `a_H` and the completed kernel, (8) adds at most `λH||g||₁` to its source coefficient. For the root choice `H≈√A_n/λ` that completion itself has root source price. Constructing a small receiver dual bill and the other root coefficient remains unproved; neither (9) nor (10) establishes that missing geometry.

This strengthens the frozen common-source optimization by a measurable PSD completion and a rigorously bounded fee. It is not a general root estimate for the original remaining innovations. In particular, a signed source or a change of the frozen `q,R,U,J` would invalidate the stated comparisons.

## 6. Local computation and reproducibility scope

Standard Python on this machine lacked `mpmath`; a built-in 70-digit `decimal` run instead passed **320** assertions on 40 finite-incidence cumulative fields, dimensions 1–3, four physical radii, four source sites and four receiver features. It tested the stopped low-row fee, `D≥0`, four scalar completion parameters, and the optimized gain. These are arithmetic diagnostics with tolerance `10^-60`, not interval certificates or literal-cube/root evidence. The analytic proof above is independent of them.

Minimal reproduction (standard Python; no third-party package):

```python
from decimal import Decimal as D, getcontext
getcontext().prec=70
checks=0; tol=D('1e-60')
for case in range(1,41):
    n=1+case%3; radii=[D(1),D(5)/4,D(3)/2,D(2)]
    g=[D(1+(case+i)%4)/7 for i in range(4)]
    C=[[1,int((case+j)%2==0),int((case+2*j)%3!=0),1]
       for j in range(4)]
    mu=[D(1+(case+j)%5)/9 for j in range(4)]
    H=D(2+case%5)/8
    lam=max(sum(g[z]*C[j][z] for z in range(4))/radii[j]**n
            for j in range(4))
    ll=eh=qhh=qhl=qll=D(0)
    for k,r in enumerate(radii):
        weight=r**(-n)-(radii[k+1]**(-n) if k<3 else D(0))
        J=[sum(mu[j]*C[j][y] for j in range(k+1)) for y in range(4)]
        A=[[sum(mu[j]*C[j][y]*C[j][z] for j in range(k+1))
            for z in range(4)] for y in range(4)]
        high=[v>=H for v in J]
        for y in range(4):
            if not high[y]:
                ll+=weight*g[y]*sum(g[z]*A[y][z] for z in range(4))
            for z in range(4):
                if not J[y] or not J[z]: continue
                e=weight*g[y]*g[z]*A[y][z]**2
                if high[y]: eh+=e/J[y]
                q=e/(J[y]*J[z]).sqrt()
                if high[y] and high[z]: qhh+=q
                elif high[y] and not high[z]: qhl+=q
                elif not high[y] and not high[z]: qll+=q
    assert ll<=lam*H*sum(g)+tol; checks+=1
    delta=ll-qll
    assert delta>=-tol; checks+=1
    for t in [D(0),D(1)/10,D(1)/2,D(1)]:
        qt=qhh+2*t*qhl+t*t*qll
        assert eh>=qt-t*t*ll-tol; checks+=1
    t=min(D(1),qhl/delta) if delta>tol else D(1)
    gain=2*t*qhl-t*t*delta
    assert gain>=-tol; checks+=1
    assert eh>=qhh+gain-tol; checks+=1
print('PASS',checks)
```

Only `/tmp/r330_aux.md` is authored. No other research file or repository is changed.
