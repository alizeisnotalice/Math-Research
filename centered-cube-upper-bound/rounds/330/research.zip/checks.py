from fractions import Fraction as F
from itertools import product
ct={'low_clock':0,'completion':0,'optimal_gain':0}
for n in (1,2,4,8,16):
 r=[F(1),F(5,4),F(3,2),F(2)];h=[F(1,3),F(1,4),F(1,2),F(1,5)];q=[F(3,4),F(1),F(7,8),F(4,5)]
 J=[];V=[];j=v=F(0)
 for R,x,p in zip(r,h,q):j+=x;v+=p*R**n*x;J.append(j);V.append(v)
 ell=[R**(-n)-(r[k+1]**(-n) if k<3 else 0) for k,R in enumerate(r)]
 for H in [F(1,10),J[0],J[1],(J[1]+J[2])/2,J[2],J[3],F(2)]:
  low=sum((e*v for e,v,j in zip(ell,V,J) if j<H),F(0));assert 0<=low<=H;ct['low_clock']+=1
  ks=[k for k,j in enumerate(J) if j>=H]
  if ks:
   k=ks[0];direct=sum((q[i]*h[i]*(1-(r[i]/r[k])**n) for i in range(k)),F(0))
  else:direct=sum((p*x for p,x in zip(q,h)),F(0))
  assert low==direct;ct['low_clock']+=1
roots=[F(1),F(2),F(3)];J=[x*x for x in roots]
A=[[min(i,j) for j in J] for i in J]
for g in product((F(1,3),F(1),F(2)),repeat=3):
 for H in (F(1,2),F(2),F(5),F(10)):
  high=[j>=H for j in J];N=[g[i]*sum(g[j]*A[i][j] for j in range(3)) for i in range(3)]
  NH=sum(N[i] for i in range(3) if high[i]);NL=sum(N[i] for i in range(3) if not high[i])
  EH=sum((g[i]*g[j]*A[i][j]**2/J[i] for i in range(3) for j in range(3) if high[i]),F(0));BH=NH-EH
  def energy(h1,h2):return sum((g[i]*g[j]*A[i][j]**2/(roots[i]*roots[j]) for i in range(3) for j in range(3) if high[i]==h1 and high[j]==h2),F(0))
  QHH,C,QLL=energy(True,True),energy(True,False),energy(False,False);D=NL-QLL
  assert C>=0 and D>=0
  best=F(1) if D==0 else min(F(1),C/D)
  gain=2*best*C-best*best*D
  for t in (F(0),F(1,4),F(1,2),F(1),best):
   upper=NH-QHH-2*t*C+t*t*D
   assert upper>=BH>=0;ct['completion']+=1
   assert gain>=2*t*C-t*t*D>=-D;ct['optimal_gain']+=1
print('PASS',ct,'total',sum(ct.values()))
