# R207 finite common-cap and scale checks

All requested finite groups ran successfully: nine common-theta cases (including a zero branch), eleven product-scale cases, two rejected invalid-domain guards, and five n-values with four scalar clamp interval checks each. Exact Fraction primitives and clock identities are distinguished from 25/50dps logarithms and quadrature diagnostics. This is not a physical C(d) input or an original FULL/history realization, and no dimension order is fitted.

## Common theta optimization

The optimized objective is precisely the half-interval envelope F_R(theta)=R^theta/[(1-theta)sqrt(theta)], 0<theta<=1/2, after relaxing the original scalar C_theta<=1. It is not the exact best-C_theta optimization and is not a direct computation of the original physical N_B.

Initial R values are 0,1e-6,1. Pressure uses exp(-1) and exp(-1+-1e-6), treating the seam's log R as the specified exact numeric argument rather than introducing a round-trip exp/log branch error. Expanded values are 1e-1000,1e6,1e1000. Both precisions check the endpoint/interior rule, D=log R+1/(1-theta)-1/(2theta), Dprime>0 and neighboring objective values. For log R<=-1 the selected endpoint is theta=1/2 and its derivative is nonpositive. Otherwise the stable rationalized formula gives the interior stationary point. R=0 is handled before log and division.

Each nonzero row checks 4sqrt(71/6)F_R(theta_star)<=65min[sqrt(R),sqrt(log(e+R))]. The largest observed ratio is approximately .598750; R=1 gives theta=1/3 and ratio .549987, while R=1e1000 gives theta approximately .000217053 and ratio .493693. The 25/50dps ratio differences are all below 1e-22. These finite diagnostics check the implementation and constants, not the general optimization proof or a physical realization.

## Exact products and source clock

For q(xi)=product_i max(C_i,xi), the code splits at the distinct C_i inside (xi0,1). Each segment q=a*xi^k integrates as a(hi^k-lo^k)/k for k>0, using Fraction exactly. A k=0 segment is kept as the coefficient times log(hi/lo), with the rational part and log terms separate. Repeated thresholds do not duplicate a breakpoint. Independent mpmath quadrature evaluates the original max-product rather than the monomial primitive.

In every nonempty current-band interval xi>=xi0>=1/2, the segment exponent k>=m=#{C_i<=1/2} and coefficient a<=1 give q<=xi^m. The primitive is checked against (1-xi0^m)/m for m>0; m=0 uses log(1/xi0), never a zero denominator. xi0>1 is zero before integration. Invalid xi0=0 and tau=0 are rejected before logarithms.

The exact source relations use tau=min(xi0,1/2), D_i=max(C_i,tau), qtau=product D_i, w_tau=product C_i/qtau, and Bstar/B0=1/product C_i. Thus w_tau*(Bstar/B0)=1/qtau exactly. Segment coefficients and direct point values also verify I(D,xi0)=I(C,xi0) and q(xi)/qtau=w_tau/w_xi. Consequently w_tau*(Bstar/B0)*I(C)=I(D)/product D_i, including each independent log coefficient. Numerical fields retain both w_tau I and I/qtau. The actual original posterior normalizer e_t is not removed or paid by this identity.

## Three product stages and observed values

The initial three C lists at xi0=1/2 are (1/4), (1/4,3/4), and (1/2,1/2); their exact integrals are 1/2,13/32,3/8, with uppers 1/2,1/2,3/8.

Pressure has C=(1/8,1/2,1/2,7/8), giving m=3 and integral .26239013671875; C=(3/4,7/8), giving m=0 and integral approximately .4926489772 with a genuine logarithmic segment; and C=(1/4,3/4),xi0=6/5, giving an empty interval and zero integral. The m=0 case retains a separate log(5/4) platform.

Expanded cases are n=1 with C=2^-100,xi0=3/4; n=2 with C=(1/8,3/4),xi0=1/2; n=16 with eight C=1/4 and eight C=3/4; n=128 with 64 C=2^-20 and 64 C=1/2; and n=1024 with every C=1. All but the first use xi0=1/2. Their integrals are respectively 1/4,13/32,approximately .0630775290,(1-2^-128)/128,and log 2. The n=2 expanded list and the initial (1/4,3/4) list have different tiny C and terminal w_tau but exactly the same D,qtau and unclamped joint cap. Their different clamp platforms are kept separately. No extra independent source budget is inferred.

The n=128 case has m=n and the integral equals the m-count upper. The n=1024 case has m=0 and retains log 2, not a 1/n gain. Its clamp platform is another log 2, making the displayed total 2log 2. A clamp platform is only the separately reported scalar path length. The extra-speed scalar upper integral is checked separately below; actual physical relative-velocity flux, capture/gate changes, source reuse, selector and the original e_t costs are not computed or declared paid. All products are one-dimensional in xi, with no high-dimensional receiver integration.

## Separate clamp extra-speed scalar bound

For b=B=1, the authored analytic bound extra(L)<=n/L, integrated against dlogL, gives n integral L^(-2)dL. Five Fraction configurations use n=1,2,16,128,1024, gamma=1+1/n and Lc=1/gamma. Each checks the full interval L0=Lc, the partial interval L0=(1+Lc)/2, the empty L0=1 and reverse L0=3/2. Empty and reverse intervals return zero before evaluating a signed reversed primitive.

The two independent rational expressions n(1/L0-1) and n(1-L0)/L0 agree for every nonempty case and are at most one. Full intervals equal n(gamma-1)=1 exactly; partial intervals equal n/(2n+1) exactly. This finite scalar integration checks an analytic upper budget, not actual mixed-face quadrature or an assertion that physical flux attains one. It neither erases the original source/selector weights nor equates the log(gamma) platform length with this different velocity integral.

## Reproduction and precision scope

Use the existing mpmath 1.3.0 dependency with normal import. The local environment is:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
 /opt/homebrew/opt/python@3.14/bin/python3.14 cap_scale_checks.py --output cap_scale_checks.json
```

The script binds task_contract.md by portable filename/hash and records mpmath version plus entry SHA. Runtime and machine-specific paths do not enter JSON. Finite Fraction primitives/clock coefficients are exact certificates of these arrays; all logarithms, optimization values and quadrature comparisons are noninterval high-precision diagnostics, not certified rounding errors or a general theorem.


A fresh temporary-directory copy of the final script and contract was actually run with exit 0; its complete JSON matched byte-for-byte. Measured isolated replay time was 0.272 seconds (notes only). Replay directory: /var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r207_clamp_final_replay_lq0b793x.
