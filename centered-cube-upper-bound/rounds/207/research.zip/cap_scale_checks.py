#!/usr/bin/env python3
"""Finite exact product-scale checks and noninterval quadrature diagnostics."""
import argparse,hashlib,json,math
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent

def enc(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x

def mpr(x):return mp.mpf(x.numerator)/x.denominator

def product_case(stage,label,C,xi0,platform_gamma=F(1),tau=F(1,2)):
    assert C and all(0<c<=1 for c in C) and xi0>=F(1,2) and platform_gamma>=1 and 0<tau<=min(F(1),xi0)
    m=sum(c<=F(1,2) for c in C);n=len(C)
    Di=[max(c,tau) for c in C];qtau=math.prod(Di);Cprod=math.prod(C);wt=Cprod/qtau
    assert 0<wt<=1
    Bstar_over_B0=1/Cprod;clock_coefficient=wt*Bstar_over_B0
    assert clock_coefficient==1/qtau
    cuts=sorted({xi0,F(1)}|{c for c in C if xi0<c<1}) if xi0<1 else []
    rational=F(0);logs=[];pieces=[]
    for lo,hi in zip(cuts,cuts[1:]):
        mid=(lo+hi)/2;k=sum(c<=mid for c in C);a=math.prod(c for c in C if c>mid)
        assert k>=m and 0<a<=1
        assert k==sum(c<=mid for c in Di) and a==math.prod(c for c in Di if c>mid)
        ratio_checks=[]
        for xi in (lo,mid,hi):
            direct=math.prod(max(c,xi) for c in C)
            assert direct==a*xi**k and direct<=xi**m
            assert direct==math.prod(max(c,xi) for c in Di)
            wxi=Cprod/direct
            assert wt/wxi==direct/qtau
            ratio_checks.append(dict(xi=xi,q_xi=direct,q_xi_over_q_tau=direct/qtau,w_xi=wxi,w_tau_over_w_xi=wt/wxi))
        if k:
            part=a*(hi**k-lo**k)/k;rational+=part
        else:
            part=None;logs.append((a,hi/lo))
        pieces.append(dict(lo=lo,hi=hi,k=k,coefficient=a,rational_integral=part,clock_ratio_checks=ratio_checks))
    exact_bound=F(0) if xi0>=1 else (1-xi0**m)/m if m else None
    if not logs and exact_bound is not None:assert rational<=exact_bound
    runs=[]
    for precision in (25,50):
        with mp.workdps(precision):
            closed=mpr(rational)+sum(mpr(a)*mp.log(mpr(ratio)) for a,ratio in logs)
            # Direct product evaluation at quadrature nodes is independent of
            # the monomial primitive and its interval exponent/coefficient.
            mpC=[mpr(c) for c in C]
            quad=sum(mp.quad(lambda xi:mp.fprod(max(c,xi) for c in mpC)/xi,[mpr(lo),mpr(hi)]) for lo,hi in zip(cuts,cuts[1:]))
            bound=mpr(exact_bound) if exact_bound is not None else mp.log(1/mpr(xi0))
            assert abs(closed-quad)<mp.mpf(10)**(-precision+4)*max(1,abs(closed))
            assert 0<=closed<=bound+mp.mpf(10)**(-precision+4)
            platform=mp.log(mpr(platform_gamma))
            runs.append(dict(dps=precision,closed_integral=mp.nstr(closed,precision),independent_direct_product_quad=mp.nstr(quad,precision),difference=mp.nstr(abs(closed-quad),precision),unclamped_upper=mp.nstr(bound,precision),separate_clamp_log_gamma=mp.nstr(platform,precision),total_with_platform=mp.nstr(closed+platform,precision),weighted_clock_integral=mp.nstr(mpr(wt)*closed,precision),joint_cap_over_B0=mp.nstr(closed/mpr(qtau),precision)))
    return dict(stage=stage,label=label,n=n,C=C,xi0=xi0,m=m,m_over_n=F(m,n),empty_interval=xi0>=1,segments=pieces,exact_rational_part=rational,log_terms=[dict(coefficient=a,ratio=r) for a,r in logs],exact_rational_upper=exact_bound,platform_gamma=platform_gamma,tau=tau,D_i=Di,q_tau=qtau,C_product=Cprod,w_t=wt,Bstar_over_B0=Bstar_over_B0,exact_clock_coefficient=clock_coefficient,I_D_equals_I_C_by_segment_coefficients=True,runs=runs,status='PASS_FINITE_EXACT_AND_NONINTERVAL')

def optimizer_checks():
    table=[('initial','zero',None),('initial','1e-6','1e-6'),('initial','1','1'),('stress','exp(-1)','exp:-1'),('stress','exp(-1-1e-6)','exp:-1.000001'),('stress','exp(-1+1e-6)','exp:-.999999'),('expanded','1e-1000','1e-1000'),('expanded','1e6','1e6'),('expanded','1e1000','1e1000')]
    rows=[]
    for stage,label,spec in table:
        runs=[]
        for precision in (25,50):
            with mp.workdps(precision):
                if spec is None:
                    runs.append(dict(dps=precision,R='0',theta_star=None,optimized_F='0',scaled_price='0',constant65_bound='0',branch='zero_R_no_log'));continue
                if spec.startswith('exp:'):u=mp.mpf(spec[4:]);R=mp.exp(u)
                else:R=mp.mpf(spec);u=mp.log(R)
                theta=mp.mpf('.5') if u<=-1 else 2/(2*u+3+mp.sqrt(4*u*u+4*u+9))
                derivative=u+1/(1-theta)-1/(2*theta)
                second=1/(1-theta)**2+1/(2*theta**2)
                if u<=-1:assert derivative<=mp.mpf(10)**(-precision+3)
                else:assert abs(derivative)<mp.mpf(10)**(-precision+5)*max(1,abs(u))
                Fstar=mp.exp(theta*u)/((1-theta)*mp.sqrt(theta));nearby=[]
                for trial in sorted({theta/2,theta*mp.mpf('.999'),min(mp.mpf('.5'),theta*mp.mpf('1.001')),mp.mpf('.5')}):
                    value=mp.exp(trial*u)/((1-trial)*mp.sqrt(trial))
                    assert Fstar<=value*(1+mp.mpf(10)**(-precision+4))
                    nearby.append(dict(theta=mp.nstr(trial,precision),F=mp.nstr(value,precision)))
                scaled=4*mp.sqrt(mp.mpf(71)/6)*Fstar
                upper=65*min(mp.sqrt(R),mp.sqrt(mp.log(mp.e+R)))
                assert second>0 and scaled<=upper
                runs.append(dict(dps=precision,R=mp.nstr(R,precision),log_R=mp.nstr(u,precision),theta_star=mp.nstr(theta,precision),log_derivative=mp.nstr(derivative,precision),log_second_derivative=mp.nstr(second,precision),optimized_F=mp.nstr(Fstar,precision),scaled_price=mp.nstr(scaled,precision),constant65_bound=mp.nstr(upper,precision),ratio=mp.nstr(scaled/upper,precision),nearby=nearby,branch='endpoint_half' if u<=-1 else 'interior'))
        if spec is not None:
            with mp.workdps(60):
                ratio_difference=abs(mp.mpf(runs[0]['ratio'])-mp.mpf(runs[1]['ratio']))
                assert ratio_difference<mp.mpf('1e-22')
            difference=mp.nstr(ratio_difference,50)
        else:difference='0'
        rows.append(dict(stage=stage,label=label,runs=runs,crossprecision_ratio_difference=difference,status='PASS_NUMERICAL_NONINTERVAL'))
    return dict(cases=rows,scope='Only the common-theta half-interval envelope F_R=R^theta/[(1-theta)sqrt(theta)] is optimized. The exact scalar C_theta has already been relaxed to one; this is not optimization of the original best C_theta or the actual physical face integral.',status='PASS_NUMERICAL_NONINTERVAL')


def clamp_speed_checks():
    rows=[]
    for n in (1,2,16,128,1024):
        gamma=1+F(1,n);Lc=1/gamma
        checks=[]
        for label,L0 in [('full',Lc),('partial',(1+Lc)/2),('empty',F(1)),('reverse',F(3,2))]:
            if L0>=1:
                integral=F(0);independent=F(0)
            else:
                integral=n*(1/L0-1)
                independent=n*(1-L0)/L0
            assert integral==independent and 0<=integral<=1
            if label=='full':assert integral==n*(gamma-1)==1
            if label=='partial':assert integral==F(n,2*n+1)
            checks.append(dict(label=label,L0=L0,empty_interval=L0>=1,exact_integral=integral,independent_expression=independent,upper=F(1)))
        rows.append(dict(stage='initial' if n in (1,2) else 'stress' if n in (16,128) else 'expanded',n=n,b=F(1),B=F(1),gamma=gamma,Lc=Lc,checks=checks))
    return dict(cases=rows,status='PASS_FINITE_EXACT',scope='Scalar analytic clamp-speed upper-bound integral only: extra(L)<=nB*b/L, integrated against dlogL at fixed b=B=1. This does not compute actual physical face flux or assert that the bound one is attained.',formula='n integral_{L0}^1 L^(-2)dL = n(1/L0-1) if L0<1, otherwise zero; full clamp Lc=1/(1+1/n) gives one.')


def run():
    initial=[product_case('initial','n1_small_C',[F(1,4)],F(1,2)),product_case('initial','n2_crossing',[F(1,4),F(3,4)],F(1,2)),product_case('initial','n2_repeated_half',[F(1,2)]*2,F(1,2))]
    stress=[product_case('stress','repeated_half_boundary',[F(1,8),F(1,2),F(1,2),F(7,8)],F(1,2)),product_case('stress','m0_log_segment',[F(3,4),F(7,8)],F(1,2),F(5,4)),product_case('stress','empty_above_one',[F(1,4),F(3,4)],F(6,5))]
    expanded=[product_case('expanded','n1_tiny_C',[F(1,2**100)],F(3,4)),product_case('expanded','n2_same_D_different_C',[F(1,8),F(3,4)],F(1,2),F(3,2)),product_case('expanded','n16_half_low_C',[F(1,4)]*8+[F(3,4)]*8,F(1,2)),product_case('expanded','n128_all_low_C',[F(1,2**20)]*64+[F(1,2)]*64,F(1,2)),product_case('expanded','n1024_m0_clamp',[F(1)]*1024,F(1,2),F(2))]
    # These two cases have different terminal products but the same D_i,
    # source-clock q_tau and unclamped joint cap. No source posterior is omitted.
    left=initial[1];right=expanded[1]
    assert left['D_i']==right['D_i'] and left['q_tau']==right['q_tau'] and left['exact_rational_part']==right['exact_rational_part']
    assert left['w_t']!=right['w_t']
    guards=[]
    for label,xi0,tau in [('zero_xi0',F(0),F(1,2)),('zero_tau',F(1,2),F(0))]:
        try:product_case('guard',label,[F(1,4)],xi0,tau=tau)
        except AssertionError:guards.append(dict(label=label,status='REJECTED_BEFORE_LOG'))
        else:raise AssertionError('Invalid domain not rejected')
    return dict(schema='r207_cap_scale_v2',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},dependency=dict(name='mpmath',version=mp.__version__,entry_sha256=hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()),optimizer=optimizer_checks(),clamp_speed=clamp_speed_checks(),initial_products=initial,stress_products=stress,expanded_products=expanded,invalid_guards=guards,same_D_identity=dict(left_label=left['label'],right_label=right['label'],same_unclamped_joint_cap=True,different_w_t=True,clamp_platforms_kept_separate=True),status='PASS_FINITE_EXACT_AND_NONINTERVAL_CHECKS',limitations=['Finite scalar product inputs are not a physical C(d) or original FULL realization.','Rational monomial integrals and guards are exact; logarithms and quadrature checks use 25/50dps noninterval arithmetic.','Clamp platform log(gamma) is retained separately; extra relative velocity and actual posterior normalizer are not paid by it.','Common-theta optimization is for the half-interval C_theta<=1 envelope, not the original best scalar constant or actual face integral.'])

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'cap_scale_checks.json');args=ap.parse_args()
    result=run();args.output.write_text(json.dumps(enc(result),indent=2,sort_keys=True)+'\n');print(result['status'])
