# R207：乘积尺度积分的精确公式与原来源时间权

状态：纯代数核证明。给出全部断点/重复值/零层的精确积分，并保source-time ξt与原乘积权的joint形式。非空路径确可严格优于先取终端sup，但原Π归一化、来源、窗口、clamp与receiver选择费用没有因此支付。Ci定义的原历史资格由主source稿核定，本稿不替代它。

## PS1　定义、空区间与零边界

固定n≥1及Ci∈(0,1]，记
\[
 C_\Pi=\prod_{i=1}^nC_i>0,\qquad
 q_C(\xi)=\prod_i\max(C_i,\xi).
\]
定义正路径积分（非反向oriented积分）
\[
 I(C;x)=\begin{cases}
 \int_x^1q_C(\xi)\,d\xi/\xi,&0<x<1,\\
 0,&x\ge1.
 \end{cases} \tag{PS1}
\]
x=1或x>1表示物理区间为空，不能用负log制造负费用。若x=0按正广义积分取值，因q_C≥CΠ>0，所以I=∞。负x不在正尺度clock定义域。Ci=0不在本命题中；不得用浮点下溢产生的0套用含CΠ的商。

## PS2　排序分段的完整精确式

先限0<x<1。令
\[
 x=\beta_0<\beta_1<\cdots<\beta_M=1
\]
为{x,1}与所有严格落在(x,1)内的Ci的去重排序。M≥1。对ℓ=0,…,M−1置
\[
 k_\ell=\#\{i:C_i\le\beta_\ell\},\qquad
 P_\ell=\prod_{C_i>\beta_\ell}C_i.
\]
空乘积取1；在(βℓ,βℓ+1)上，恰有kℓ个max因子等于ξ，其余等于原Ci，因此q=Pℓ ξ^kℓ。得到
\[
 \boxed{I(C;x)=\sum_{\ell=0}^{M-1}P_\ell\,
 \begin{cases}
 (\beta_{\ell+1}^{k_\ell}-\beta_\ell^{k_\ell})/k_\ell,&k_\ell>0,\\
 \log(\beta_{\ell+1}/\beta_\ell),&k_\ell=0.
 \end{cases}} \tag{PS2}
\]
证明仅是逐段积分ξ^(k−1)。断点本身对Lebesgue积分零；重复Ci必须同时进入k，不能只算一次；恰等x的Ci在首段已计为低层；Ci=1对每个ξ<1贡献常数1。去重避免零长度段和log1/零层歧义。若不去重也可保零长度段，但不能除以k0。此公式包括无内部断点、所有Ci相等、所有Ci1及首段k0情形。

有理输入的k>0贡献全为有理数；零层贡献是明确的有理系数乘log比，不能冒充Fraction精确数值。若至少一个Ci≤x，首段及后续k均正，不出现log层。公式不靠数值拟合。

## PS3　m界、实际起点计数与等号

若1/2≤x<1，令m=#{Ci≤1/2}。对所有ξ≥x，这m个因子都等于ξ，其余≤1，故q_C(ξ)≤ξ^m。因此
\[
 \boxed{I(C;x)\le U_m(x),\qquad
 U_m(x)=\begin{cases}(1-x^m)/m,&m\ge1,\\-\log x,&m=0.\end{cases}} \tag{PS3}
\]
m0是m→0的对数极限，不是除零。x≥1的统一写法必须用(1−x^m)+/m及(−logx)+，或先按PS1取空区间零；若x>1而未取正部，题面右端为负，不是有效正预算。

更强且适用任意0<x<1的是起点实际计数
\[
 k_x=\#\{i:C_i\le x\},\qquad I(C;x)\le U_{k_x}(x). \tag{PS4}
\]
证明相同。x≥1/2时kx≥m，所以该式不弱于PS3；U_k随整数k非增，来自∫x¹ξ^k dξ/ξ逐点比较。

在非空区间，PS4等号当且仅当所有Ci>x都等于1；否则某因子max(Ci,ξ)<1使q<ξ^kx在正测度区间严格。PS3等号当且仅当所有Ci>1/2都等于1。空区间下不应用这些严格等号刻画。

另有
\[
 q_C(x)\log(1/x)\le I(C;x)\le\log(1/x). \tag{PS5}
\]
右式在非空域严格当且仅当至少一个Ci<1。证明：全Ci1时q恒1；否则设所有小于1的Ci之最大值c<1，在(max(x,c),1)上q=ξ^r<1，r≥1。这一段有正对数长度，积分严格。该严格性不是一个统一的定量间隙；Ci→1时增益可趋0。

## PS4　保留原source-time ξt的两个精确joint

固定τ=ξt，非空应用域明确为
\[
 0<\tau\le x<1. \tag{PS6}
\]
τ=1且x≥τ只有空区间；不对空域声称strict改善。定义原乘积时间权
\[
 w_\tau(C)=\prod_i\min(1,C_i/\tau)
 ={C_\Pi\over q_C(\tau)}. \tag{PS7}
\]
这是代数乘积，不将w或Ci叫作来源概率。

第一份joint是保未归一tilted source权后，终端归一帽比例的积分：
\[
 \boxed{J_\tau(C;x):=w_\tau I(C;x)
 ={C_\Pi\over q_C(\tau)}I(C;x).} \tag{PS8}
\]
相比先以supξq_C(ξ)=q_C(1)=1替代当前因子，精确上界是wτlog(1/x)。非空域下，若某Ci<1则PS8严格小于该值；否则等号。也可保持PS3/4得到Jτ≤wτ U_kx(x)，不先丢wτ≤1。

第二份joint直接保实际帽。对固定外部B0≥0，令
\[
 B_\xi={B_0\over\prod_i\min(1,C_i/\xi)}
       ={B_0q_C(\xi)\over C_\Pi},\qquad
 B_*=B_1=B_0/C_\Pi. \tag{PS9}
\]
B0固定时准确有Bξ/B*=q_C(ξ)。若B0本身随ξ变，以下不能将它提出积分。
\[
 \boxed{w_\tau\int_x^1 B_\xi\,{d\xi\over\xi}
 =B_0\,{I(C;x)\over q_C(\tau)}.} \tag{PS10}
\]
这比“先取sup Bξ=B*再保wτ”的B0 log(1/x)/q_C(τ)严格小，条件仍是非空且某Ci<1。它不要求来源坐标独立，完全使用同一组Ci。

## PS5　clock截断后的显式乘积：tiny Ci倒数恰消

置Di=max(Ci,τ)，则Di∈[τ,1]。ξ≥x≥τ时
\[
 q_D(\xi)=q_C(\xi),\qquad\prod_iD_i=q_C(\tau),
\]
\[
 \boxed{{w_\tau B_\xi\over B_0}
 ={q_C(\xi)\over q_C(\tau)}
 =\prod_i\max(1,\xi/D_i),\qquad
 {I(C;x)\over q_C(\tau)}={I(D;x)\over\prod_iD_i}.} \tag{PS11}
\]
B00时用原零对象，不在左式除B0。证明逐坐标看：若Ci≤τ，分子因子是ξ、分母τ；若Ci>τ，分子max(Ci,ξ)、分母Ci。所有Ci<τ的individual tinyCi完全取消，留下clock τ的费用，而非这些Ci的个体倒数。这是实际乘积身份，不是另选截断输入或来源。这里的取消仅针对线性wτ Bξ因子及其积分；若应用OC2/SG13，额外的sqrt(log(e+Bξ(1−s)))（或以B*上放后的对应对数）仍依赖原Ci，不得称完整非线性面价的tinyCi依赖全部消失。

结合单调与逐坐标max(Ci,ξ)/max(Ci,τ)≤ξ/τ，还得
\[
 \log(1/x)\le K_\tau(C;x):={I(C;x)\over q_C(\tau)}
 \le{\log(1/x)\over q_C(\tau)}, \tag{PS12}
\]
\[
 K_\tau(C;x)\le {U_{k_x}(x)\over q_C(\tau)},\qquad
 K_\tau(C;x)\le{1-x^n\over n\tau^n}. \tag{PS13}
\]
后一式在全部Ci≤τ时精确等号。τ≥1/2时τ^−n仍可能指数大，不能把它称为root费用。
PS12表明改善是相对“先取终端sup”，绝不是相对B0基准的无条件收缩；一般Kτ≥log(1/x)。两侧在某Ci<1时都严格（上侧由PS5，低侧用q_C(ξ)>q_C(τ)的正测度末段）。

## PS6　精确小例与零层校准

1. 全Ci1：q恒1、I=log(1/x)、wτ1，joint无严格增益。
2. n1，C≤τ≤x<1：qξ=ξ，I=1−x，wτ=C/τ，Kτ=(1−x)/τ，与tiny C本身无关。τ=x=1/2时Kτ1，而先sup帽价为2log2>1；该strict由∫1/2¹1/ξ dξ>1/2直接证明，不靠浮点。
3. C=(1/4,1/4,1)、x=τ=1/2：qξ=ξ²、I=3/8，CΠ=1/16、qτ=1/4、wτ=1/4，Jτ=3/32、Kτ=3/2。重复断点必须同时计入k2。
4. C=(3/4,1)、x=τ=1/2：首段k0，I=(3/4)log(3/2)+1/4，Kτ=log(3/2)+1/3。该式含真正log层，不能标成有理数。
5. x=1或x>1：全部积分与对应joint先零，无负log；x0且Ci>0则I∞，不是浮点失败。

这些是解析/有理接口而非已执行的数值。现有数值作者可用去重断点、逐段symbolic log或mp25/50核验；实际证据归其责任文件，本稿不预报通过。

## PS7　原current band、clamp平台与Π归一化

若原source稿已核给定Ci与τ满足PS6，且固定当前邻尺度γ≥1、0<a≤b，unclamped path的下端为L0=max(a,bτ/γ)、上端b/γ，则变量ξ=γL/b给
\[
 \int_{L_0}^{b/\gamma}{B_L\over B_*}d\log L
 =I(C;\max(\gamma a/b,\tau)). \tag{PS14}
\]
原区间为空时PS1先零，不能用oriented反向积分。若起点≥1/2可用m界，更精确可用PS2/4。这里仅确认代数换元；原τ=ξt、Ci=C(|yi−vi|/b)、t≤g与实际Lband的来源资格由主稿核定，本稿不另构树或补历史。

clamp平台ξbarL=min(1,γL/b)=1时，B_L/B*=1，平台正路径长度为
\[
 \ell_{\rm plat}=\left[\log{b\over\max(a,b/\gamma)}\right]_+.
\]
平台另加ellplat，未归一joint另加wτ ellplat；实际jointcap/B0另加ellplat/q_C(τ)。这不是unclamped I的一部分；额外面速度、continuous/bulk与资格交换仍按原合同保留。

原Πτ(dv)=1Zτ(v)wτ(C(v))ν(dv)/eτ，因此每个固定source的上述乘积还须乘1Zτν/eτ。eτ依原来源及时间，不能由PS11取消，不可跨τ积分当常数。即使Πτ概率，也不是1Zτν/eτ概率。质量1且保留在Zτ内的单原子来源时eτ=wτ，Πτ不因wτ小而变小；故未归一乘积的strict改善不认证归一来源积分的uniform收缩。Ci低于τ的个体inverse已消，不意味着所有source/normalizer费用已付。

## PS8　适用边界与停止范围

本文完整证明exactpiecewise I、m/实际起点计数界、非空域strict条件与source-time联合clipped乘积。没有把共单调坐标的积分改成独立边际乘积，也没有重选Ci/τ或取各坐标不同clock。没有为eτ、B0、原β/ν、uniquej/time/window、receiver selector或source reuse提供新预算。固定pair代数可正Tonelli回原状态，但实际外权必须保留；与R206核级root工具组合也不自动得到一般raw根阶。

本稿到此停止，送全文审；下一步整理仅依父明确授权，不新增数学路线。
