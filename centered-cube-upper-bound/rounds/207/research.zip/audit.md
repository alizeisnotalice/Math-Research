# R207 independent premise audit

## 1. Order and scope

Read only `task_contract.md` before this independent screen, not the new author proofs. The auditor owns only this file, with no Git, spawning, numerical execution or PDF compilation. The original beta Pi^2, fixed-source cap, all qualification/trace exchanges and original time/window/selector account remain. This is an initial candidate review, not a final all-source certificate.

## 2. Logarithmic cap-power optimization

The audited R206 estimate gives, for 0<theta<=1/2 and R=B(1-s)>0,

    N_B <=4sqrt(71/6) B sqrt(n) R^theta/[(1-theta)sqrt(theta)],

because C_theta<=1 in this half interval: for t<=1, h(t)<=sqrt(t)<=t^theta; for t>=1, h(t)<=1<=t^theta. This does not claim that C_theta is identically one or replace the original sharp constants elsewhere.

Set k=log(e+R)>=1 and theta=1/(2k). Then theta<=1/2, (1-theta)^(-1)<=2 and R^theta<=sqrt(e), so the coefficient is at most 8sqrt(71e/3)sqrt(k)<65sqrt(k). The simple numerical inequality may be proved with e<11/4, without relying on floating-point fitting. Combined with the already proved half-power estimate 40 B sqrt(nR), this gives

    N_B <=65 B sqrt(n) min(sqrt(R),sqrt(log(e+R))).

R=0 is handled by the actual zero hard jump or zero cap before logarithms of R are formed. B must be finite and receiver-independent in this fixed-source application. The estimate concerns the original positive nonlinear relative-face kernel on gamma in [1,2], not its source/global payment or the extra clamp velocity.

The proposed exact optimizer of the coarse half-interval objective also passes. Write a=log R. The derivative of log[R^theta/((1-theta)sqrt(theta))] is a+1/(1-theta)-1/(2theta), strictly increasing. At theta=1/2 it equals a+1. Hence theta=1/2 is optimal when a<=-1; otherwise the unique root is

    theta=2/[2a+3+sqrt(4a^2+4a+9)].

The formula includes a=0, giving 1/3, and matches 1/2 at a=-1. It optimizes this stated coarse upper coefficient, not the full C_theta-dependent sharp bound or an actual joint source functional. Whole-product exponents cannot be separately optimized by coordinate and then recombined.

## 3. Band-majorized source cap

Conditionally on the accurate original band and clock implications supplied for subsequent source verification,

    xi_g<=xi_bar(L)=min(1,gamma L/b),
    t<=g => L>=b xi_t/gamma,

the cap comparison has the correct direction. Since w(xi)=product min(1,C_i/xi) decreases with xi, B_actual=B0/w(xi_g)<=B_L=B0/w(xi_bar). G_B(P,delta)=BP h(Bdelta/P) increases with B, so one may first enlarge to this fixed-L/source-pair cap and only then apply the fixed-cap receiver estimate. This does not apply a fixed-cap theorem directly to a receiver-dependent B_actual.

For C_i in (0,1], define B_star=B0/product C_i. Exact algebra gives

    B_L/B_star=product max(C_i,xi_bar).

Under the original a>=b/2 and gamma>=1, xi_bar>=1/2. For m=#{i:C_i<=1/2}, the m selected factors equal xi_bar and the others are at most one, giving B_L/B_star<=xi_bar^m. Zero m is allowed; no inverse m is formed there. The assumption C_i<=1 and this scale range are required, not optional replacements by a probability source density.

## 4. Legal common-path integration and clamp platform

Let L0=max(a,b xi_t/gamma), with all source/window/clock data fixed for this common L path. In the unclamped segment L in [L0,b/gamma], a nonempty interval requires L0<b/gamma. For m>0 direct integration gives

    integral xi_bar(L)^m dlogL
      =[1-max(gamma a/b,xi_t)^m]_+/m.

When m=0 use the actual positive logarithmic interval length, and when the interval is empty take zero first. This includes scale-endpoint and xi_t endpoint cases without dividing by m. It does not assert that the actual chosen L(x) graph is a common path integral.

For fixed s, monotonicity of the optimized receiver bound gives the legitimate path coefficient

    65 sqrt(n) B_star sqrt(log(e+B_star(1-s)))

times the preceding attenuation integral. The half-power estimate instead has coefficient 40 sqrt(n) B_star sqrt(B_star(1-s)) and attenuation exponent 3m/2. If s varies on a common path, the varying coefficient stays inside its integral unless an actual uniform bound is supplied; fixed-s factoring cannot be borrowed for an adaptive softness selector.

On the full allowed L path, the relative |v-y| component has a clamp platform where xi_bar=1. For L0<=b and m>0 its attenuation integral is

    log[b/max(L0,b/gamma)]
       +1_(L0<b/gamma)[1-(gamma L0/b)^m]/m,

at most log gamma+1/m and also at most log(b/a). Empty full paths are zero first; m=0 uses log(b/L0). In the platform, the target scale is b and its effective ratio b/L remains in [1,gamma], so the fractional fixed-slice theorem still applies to the relative center-speed component. Its actual extra clamp boundary speed, continuous/bulk and gate/endpoint changes are not included. The absence of attenuation on that platform cannot be erased by the pre-clamp 1/m factor.

## 5. Initial conclusion

Both the optimized fractional cap estimate and the scale/product attenuation algebra pass the independent screen, conditional on the stated original band/clock facts being established from the actual definitions in the author proof. All current/source correlations, actual beta Pi^2, source B_star weights, j/time/window, endpoint/gate and receiver-selector costs remain. No general original root-order budget is certified. Awaiting complete author statements/proofs and later final integration before any final hash binding.

## 6. Exact product/clock candidate screened before proof

For 0<xi0<1 and C_i in (0,1], let q(xi)=product max(C_i,xi). Sort the distinct breakpoints xi0=beta0<...<betaM=1, inserting only C_i in (xi0,1). On each interval indexed l=0,...,M-1, put k_l=#{C_i<=beta_l} and P_l=product_(C_i>beta_l) C_i. Then q=P_l xi^k_l and its exact log-scale integral is P_l(beta_(l+1)^k_l-beta_l^k_l)/k_l when k_l>0, or P_l log(beta_(l+1)/beta_l) otherwise. Repeated C_i and equal endpoints cause no new interval. xi0>=1 is the empty integral; xi0=0 with all C_i>0 gives an infinite integral because q tends to their positive product.

For the accurate time factor tau=xi_t on the nonempty domain 0<tau<=xi0<1,

    w_t=product min(1,C_i/tau)=C_product/q(tau).

Let D_i=max(C_i,tau). On xi>=xi0, q_D(xi)=q_C(xi), so exact algebra yields

    w_t integral B_xi dlogxi
       =B0 I(C,xi0)/q_C(tau)
       =B0 I(D,xi0)/product D_i.

Equivalently w_t B_xi/B0=product max(1,xi/D_i). Thus individual C_i<tau really cancel from this particular cap/time product; the actual posterior factor 1/e_t and all carrier/source occupations remain. For a nonempty interval, I(C,xi0)<log(1/xi0) exactly when at least one C_i<1; otherwise equality. Empty intervals do not have that strict conclusion. These statements were checked from the accurate candidate before reading its author proof and do not establish an original source payment.

## 7. Full parent optimization manuscript review

After the screens, read complete `optimized_cap_geometry.md` OC1–6. The bound C_theta<=1, logarithmic choice, half-power comparison, constant 65, coarse half-interval optimizer and its boundary/root branches agree with the independent derivation. The whole-product exponent and receiver-independent-cap qualifications are explicit. The cap comparison in OC6 uses monotonicity and correctly preserves q_L linearly rather than replacing it by a fractional power. The manuscript states that its source/cap integral and common-path price do not pay inverse overlap, selectors, clamp/gate/recovery or original energy. Its OC4 fixed-source-cap notation is read under that stated independence hypothesis, not as permission to freeze an actual varying g(x). The later band majorant is the proposed legitimate replacement when g varies. No necessary mathematical revision was found; original band/source provenance and the exact product proof are still to be reviewed when delivered.

## 8. Full source-scale and product reviews

Read complete `source_scale_geometry.md` version `f009ea0e690b76a8589167a26ebfd3463f9af472dfdc80f82e05b25acf2a2598`. Also directly read R128 `proof.md` lines 637–667 and the cited R201 ST1 definition. The actual gamma,c_j,g ratio band and time domain, C/w_t normalization, and the restricted list of x-independent fixed-(omega,V,j,y,t) objects agree with SG1–6. The original R201 W_g is the fixed product lower bound, distinct from actual receiver-dependent w_g. Thus SG's prior uniform B_L enlargement, rather than freezing actual g(x), is the lawful fixed-cap interface. The fixed-s source/cap, high-A, empty-row, positive-a and far-domain qualifications are present.

SG8–21 pass: the relative-face definition uses actual jump and face speed, nonbounded scores are not silently placed inside an H<=1 gate, and the whole-source posterior normalization is retained. Exact m and half-power attenuation, zero m, empty intervals, relative clamp platform, fixed-s factoring and common s(L) versus receiver-dependent softness are distinguished. The row/source/time upper bound still contains its true B_star/Theta weights. No necessary revision was found in the delivered manuscript. Its then-unpaid clamp-extra status is refined only by the later separately screened result in section 11 below.

Read complete 157-line `product_scale_integral.md`, version `1c48f074420163d08a65fe96ad628516898cb14682d8a626b6c32ee2d854d864`. PS1–14 pass. The breakpoint formula counts repeated thresholds jointly and treats exact x endpoints, zero monomial exponents, empty paths and x=0 correctly. Actual starting-count k_x and m bounds, equality/strict conditions and nonuniform improvement are accurate. The joint w_tau/B_xi identities and D_i clipping cancel only the stated individual tiny-C factors, not e_tau or the posterior source occupation. Its K_tau bounds retain exponential clock prices if present. The clamp platform is separate; since tau<=1, the time lower restriction cannot raise the platform's start beyond max(a,b/gamma). No original uniform source contraction is inferred. No necessary revision was found.

## 9. Numerical static review

Read complete `cap_scale_checks.py`, final `numeric_notes.md` and frozen JSON. The JSON status is PASS_FINITE_EXACT_AND_NONINTERVAL_CHECKS with nine optimizer cases, eleven product cases and two rejected invalid-domain guards. Their actual script/JSON/notes hashes match the authors' reported ca7d630291ea71907d2681f09453f224c430c13de373b828f54f10bdffe994ed, 60756088bf9904725ae1575b2040e8c864523947556e6e5f5729910a904e3977 and b5cdb7ee47b78b57e2fe799bb682197408bf054a8cfabd681aef0b28da7eae91. No numerical script was executed by this auditor.

The theta seam uses its specified log argument directly; the stable interior formula, zero-R branch, derivative/convexity and finite neighboring values are consistent. The scale code uses Fraction for positive-power primitives and retains rational coefficients of genuine logarithmic terms separately. Direct max-product quadrature is independent of the monomial primitive. Segment point checks and D_i coefficients correctly verify the source-clock identities; differing tiny C values with identical D_i retain the same unclamped joint cap but different w_t. Empty above-one paths and zero guards are correct. High-n arrays are product algebra examples, not actual multidimensional physical source configurations. The separately appended platform lengths in those arrays need not describe one admissible original b/a<=2 window; the notes explicitly withhold physical/FULL and selector claims. Twenty-five/fifty-digit calculations and reported temporary replay are not interval certificates or auditor-side runs.

## 10. Reproducer static review

Read the complete R207 reproducer. It is the reviewed R206 confined-manifest/temporary-relocation driver with the round and actual numeric stem changed to cap_scale_checks. It checks required manifest coverage and hashes, rejects escaping/missing files and protected/existing output, copies the script and contract to a temporary directory, runs the actual --output interface with inherited environment, compares full JSON bytes and rechecks bound files. This static review does not pre-certify the parent's later final execution. No necessary revision was found. Report and TeX integration remain for final review.

## 11. New clamp-extra candidate, screened before proof

The parent then proposed a direct positive bound for the previously unestimated extra clamp component, using the original nonlinear envelope itself. This candidate passes independently. In the clamped segment ell=b, its extra absolute speed is b/2. For every fixed common s,L and each face,

    integral_face P_s,L(x-y) dH = L^(-1) f_s((v_i-y_i +/- b/2)/L)<=1/L,

because the other receiver coordinates integrate to one. Using actual B<=B_star and G_B<=BP, the two faces per coordinate therefore give extra(L)<=n B_star b/L. Put L_star=max(L0,b/gamma). On the nonempty interval [L_star,b], direct log-scale integration gives

    integral extra(L) dlogL <=n B_star(b/L_star-1)
       <=n B_star(gamma-1)=B_star,

where the last equality uses the actual gamma=1+1/n. Empty intervals are zero first; at s=1 the actual hard jump is already zero. A common s=s(L) is allowed slice by slice; receiver-dependent s(x,L) cannot borrow this product normalization. Closed outer point traces satisfy the same positive bound, but original simultaneous finite jumps still retain their actual shared-state qualifications. This is a dimension-free fixed-source cap-envelope kernel-path price, not a source or selector payment and not a lower bound for a needed negative compensation. Continuous/bulk, alpha/capture, entry/endpoint, nonbounded original scores and full beta Pi^2/j/time/window costs remain. Awaiting formal integration of this new candidate before final freeze.

## 12. Formal clamp integration and added finite checks

Read the added SG7b/SG19a–c and its corresponding scope updates in `source_scale_geometry.md`, version `cab3d58f35d7c51e81389c1b45981ed206823a0f36110f2ce4f1728db4f1cb37`. The actual face definition, empty interval, Xi=n(b/L_lo-1)<=1, s=1 branch, common s(L) and receiver-dependent s(x,L) distinction agree with the independent derivation in section 11. The source return explicitly adds B_star Xi rather than claiming it is already a W_A price. No necessary mathematical revision was found.

Read only the added `clamp_speed_checks` function and final notes changes after the earlier full script review. Five exact n choices each check full, partial, empty and reversed intervals. The two rational expressions n(1/L0-1) and n(1-L0)/L0 agree; the partial value n/(2n+1), full value one and zero-path guards are correct. The code/notes call this a scalar integral of the analytic upper bound, not actual physical face flux or an attained optimizer. It is separate from the clamp platform log length. No numerical execution was performed by this auditor.

The parent's requested extra scope was independently checked: PS11 cancels individual tiny C only in the linear product w_tau B_xi. In the optimized nonlinear price, sqrt(log(e+B_xi(1-s))) still contains B_xi and hence the original C values. A linear identity does not remove this remaining logarithmic dependence, actual e_tau or any source/selector weight. The formal product manuscript, final report and TeX must be read with this qualification; a one-sentence author clarification was requested before final binding.

## 13. Final numerical files and report checkpoint

Read the added scalar clamp section and the final JSON/notes. Actual counts are nine optimizer cases, eleven product cases, two invalid guards, and five n groups with four clamp intervals each, twenty exact checks. Final numeric script/JSON/notes hashes are 38e89aa7c4d81b5b5fcfb172dfec649661d3611feaf7fcb7dfaa041fd113c9e1, 7c4166539aa83de8684d4388b350264ce2a1d647aa40116fb03ed4acf69ad717 and 93468c4926e26b64a9ef9f7ee48a01644af266396464b990e537900f0e12ca28. The earlier three hashes in section 9 identify that prior reviewed checkpoint, not the final package. The final author-reported temporary replay is exit zero, byte-identical JSON, 0.272 seconds; this is not an auditor execution or a forecast of the parent driver.

Read complete current `report.md`. The nonlinear cap estimate, coarse optimizer qualification, actual band-majorized cap, product/time identities, linear-only tiny-C cancellation, residual logarithmic dependence, relative clamp platform and the new B_star extra-speed kernel price are represented accurately. The report retains actual e_t/source/selector/alpha/gate/time/window costs and the original energy restriction. Its finite n/product and twenty-clamp counts agree with the JSON; it does not claim a bound's exact scalar value is attained by a physical face flux. No necessary report revision was found. Final TeX and product-scope clarification remain for final integration review before binding.

## 14. Final full TeX and scope review

Read complete 634-line `proof.tex.txt` against all three reviewed mathematical manuscripts and final numerical notes. The common-exponent bound and coarse optimizer, exact product primitive/equality/zero cases, time clipping and retained e_tau, actual band/current cap construction, fixed-cap receiver splice, m/Theta path formulas and relative clamp platform agree. The newly integrated extra clamp speed is independently bounded through G_B<=BP and the true product receiver normalization, not by confusing it with a platform length. All fixed-s/common-s(L) versus receiver-dependent selector restrictions, actual beta Pi^2 and original energy limitations remain. No necessary transcription or mathematical revision was found.

Actually reread the final product manuscript's two scope clarifications, SHA-256 dc90161e38d742b013f46efc8d197c5a91c0a510ebf2b11a1356a3af5f26dbfb. Individual tiny-C inverses cancel only from the specified linear time/cap factor, while the nonlinear square-root-log weight still depends on the original C. The text correctly retains clock-tau costs, rather than denying the explicit tau^(-n) price. The TeX includes both qualifications. The latest report's added structural-check paragraph reports the parent's actual static checks only, expressly without compilation; this does not substitute for the mathematical full read.

Accepted results are the stated near-linear fixed-source cap estimate, actual band-majorized common-scale path bounds, exact linear source-time product identities and the qualified B_star clamp-extra kernel path price. They do not establish a general original raw root-order or weak-type budget. Original source normalization and residual logarithms, receiver selectors, common alpha/capture entries, recharge, endpoints, continuous and other gate exchanges, all beta Pi^2/j/time/window/source reuse and the original energy pairing still need their stated fees. This auditor ran no numerical script or parent driver and compiled no PDF. No necessary revision remains; the file bindings below precede the parent's final manifest/driver execution.

## 15. Final SHA-256 bindings

Actual byte hashes of the ten reviewed files; this audit and the future manifest are excluded:

| File | SHA-256 |
| --- | --- |
| `cap_scale_checks.json` | `7c4166539aa83de8684d4388b350264ce2a1d647aa40116fb03ed4acf69ad717` |
| `cap_scale_checks.py` | `38e89aa7c4d81b5b5fcfb172dfec649661d3611feaf7fcb7dfaa041fd113c9e1` |
| `numeric_notes.md` | `93468c4926e26b64a9ef9f7ee48a01644af266396464b990e537900f0e12ca28` |
| `optimized_cap_geometry.md` | `182af25c010d210a4955e35493aa60d14619b6c31f71e5d4fe58ca9b20f7e816` |
| `product_scale_integral.md` | `dc90161e38d742b013f46efc8d197c5a91c0a510ebf2b11a1356a3af5f26dbfb` |
| `proof.tex.txt` | `f097eeac0da960724be3dff9b90f98ca1a2bc5c3c71e67c4cb1c53f32e56e3e6` |
| `report.md` | `c675d18cc17653415cd7ea69e5131d8224f36f643f7f474271ff7ccac17cd542` |
| `reproduce.py` | `7ee81201752103972823f890a96a550dc5a560e02683720bc071d927f8afde5a` |
| `source_scale_geometry.md` | `cab3d58f35d7c51e81389c1b45981ed206823a0f36110f2ce4f1728db4f1cb37` |
| `task_contract.md` | `07adbf0a1362e28db846325376ac7a3f54cefb3eba89c64a7891998895f7436f` |

Final status: accepted within the stated qualifications; no necessary revision remains. Audit frozen before final package execution/archive.
