# R207：实际终端帽、共同 current 尺度与来源路径费用

状态：证明不先用来源固定下界 Wg 替换实际 wg 的尺度相关帽，并得到原相对硬面分量的共同尺度路径积分界。原 t<=g 限制和来源位移给出显式 Theta 因子；actual clamp 额外速度的核路径费另证至多 B_*。该结果没有支付剩余 inverse-Wg 来源矩，也不把固定 soft 的共同路径积分当作一般 receiver-adaptive selector 界。端态及 capture/资格交换仍保留。

## SG1　实际读到的原定义与出处

本稿使用以下窄段，均实际读取：

- R128 `proof.md` 第 637–667 行，RT4–6：g、原比例带、辅助时间、w_t、Pi_t 的量词以及三个测试核。文件为 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md`。
- R196 `target_displacement.md` TD1–3、TD11：原 A 与 good/high-A 的实际帽。文件为 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round196_20261016_final_checkpoint/target_displacement.md`。
- R201 `signed_transport_budget.md` ST1（第 13 行）：此前来源固定下界 Wg 与实际 wg 的区别。文件为 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round201_20261016_final_checkpoint/signed_transport_budget.md`。
- R206 最终包 `parent_fractional_geometry.md` PF2–5 及 `affinity_deficit_geometry.md`：实际非线性帽面包络，目录 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round206_20261016_final_checkpoint/`。

原量为
\[
 \gamma=1+1/n,\quad c_j=\gamma^{-j},\quad
 g=\sqrt{LR},\quad a\le L,R\le b\le2a,
\]
\[
 c_{j+1}g\le\min(L,R)\le c_jg,
 \qquad a/c_j\le g\le bc_j.
 \tag{SG1}
\]
原 far 时间 t 满足 t<=h<=g，h=g exp(-u/n)，且仍在原可定义辅助域内。以下任何 e_t=0、空时间域或没有原 far 资格的行先取零。

设 h1=1_{[-1/2,1/2]}、w(r)=∫_0^1 exp(-|r|/q)dq、phi=h1*w、f_s=(1-s)h1+s phi，
\[
 C(d)=\int_{-1/2}^{1/2}\max(h1,\phi)(z-d)\,dz,
 \quad C_i=C(|y_i-v_i|/b),\quad \xi_t=c_jt/b.
\]
对于有限来源位置，0<C_i<=1：phi 正，且 h1、phi 都不超过 1。于是所有以下有限来源帽都定义良好，但不因此具有来源可积性。

原定义精确给
\[
 w_t(y,v)=\prod_i\min(1,C_i/\xi_t),\quad
 \eta_t(v)=1_{Z_{j,V,y,t}}(v)w_t(y,v),\quad
 e_t(y)=\int\eta_t\,d\nu_V,
 \quad \Pi_{y,t}(dv)={\eta_t(v)\over e_t(y)}\nu_V(dv).
 \tag{SG2}
\]
固定原 `(omega,V,j,y,t)` 后，nu、Z_t、w_t、e_t、Pi_t 独立 receiver x 和运行 current L；g、w_g、terminal capture、alpha、current softness、全部 history 门不因此独立 x。不能用 Pi_g 替换 Pi_t，也不能把 nu/e_t 当作概率。

## SG2　保留原 high-A 帽

令 S_v=p_v+p_v^++J_v，J_v=P_{1,b}(x-v)，原 A=1_good rho J_v/S_v。固定高 A 层 A>=1-eta0，0<eta0<1。由实际 good 与 A，
\[
 p_yw_g\le KS_v/3,\quad S_v/J_v=\rho/A,
 \qquad {p_y\over J_v}\le {B_0\rho\over w_g}
 \le {B_0\over w_g},\quad B_0={K\over3(1-\eta_0)}.
 \tag{SG3}
\]
此处原 rho、alpha、来源和所有门都未重选。只对已在这些门中的非负项使用帽，然后才可正放松门。原固定来源帽为 B_*=B0/∏C_i，本稿在面积分之前不立即使用它。

## SG3　由实际比例带得到 receiver-uniform 的逐尺度帽

原比例带给 c_jg<=gamma L；又 g<=bc_j，故
\[
 \xi_g={c_jg\over b}\le
 \bar\xi_L:=\min(1,\gamma L/b).
 \tag{SG4}
\]
由于 w_xi 随 xi 递减，定义
\[
 B_L={B_0\over\prod_i\min(1,C_i/\bar\xi_L)}
 \quad\Longrightarrow\quad {B_0\over w_g(x;y,v)}\le B_L.
 \tag{SG5}
\]
对固定 b,j,y,v 和共同 L，B_L 不依 x，允许原 R(x)、g(x) 随 receiver 变化，只要求它们仍满足同一原比例带。这个结论不是将实际 g 重新选成 bar-xi，也不改变原 Pi 或 prior。

同时，t<=g 给
\[
 \xi_t\le\xi_g\le\gamma L/b,
 \qquad L\ge L_0:=\max(a,b\xi_t/\gamma).
 \tag{SG6}
\]
若 L0>b，原所限行为空；L0=b 时尺度路径积分为零，端点项不因而消失。以下各空区间均先取零。

## SG4　真实面泛函与固定帽定理的合法接缝

设 ell_L=min(b,gamma L)、Gamma_L=ell_L/L∈[1,2]。第 i 坐标的实际 target 硬跳为
\[
 \delta_i p_{s,\ell_L}(x-v)
 =(1-s)\ell_L^{-n}
   \prod_{k\ne i}f_s((x_k-v_k)/\ell_L)
 \quad\text{on }x_i=v_i\pm\ell_L/2.
 \tag{SG7}
\]
零 outer 密度 P=p_{s,L}(x-y) 时，G_B(P,delta) 取零。令
\[
 G_B(P,\delta)=BP\,[1-(1+B\delta/P)^{-2}].
\]
取全部原有且在 [0,1] 内的资格因子 H_L(x,y,v,u)。定义相对面分量
\[
 \mathcal N_L^{act}=\sum_{i,\pm}\int_{x_i=v_i\pm\ell_L/2}
 H_L\,|v_i-y_i|\,
 G_{B_0/w_g(x)}(P,\delta_i p_{s,\ell_L})\,d\mathcal H^{n-1}.
 \tag{SG8}
\]
这精确标明面测度与速度。此式用于 R206 已取得的帽面正上界；其它原 score 等非有界因子不被宣称已包含在 H<=1 内，须按它们自己的原费用保留。

G_B 对 B 非减。先由 SG5 在原有效域逐点上放 B0/wg<=B_L，再丢 H，最后应用固定帽 PF4–5，得到对共同固定 s,L 的严格界
\[
 \mathcal N_L^{act}
 \le C_\theta B_L^{1+\theta}
 \sum_i c_\theta((v_i-y_i)/L,\Gamma_L)
       \prod_{k\ne i}A_\theta((v_k-y_k)/L,\Gamma_L)
\]
\[
 \le C_\theta K_\theta B_L^{1+\theta}(1-s)^\theta\sqrt n,
 \quad K_\theta={4\over1-\theta}
       \sqrt{71\over6\min(\theta,1-\theta)}.
 \tag{SG9}
\]
一次使用中的 theta 共同用于全部坐标。这里没有把 variable B 插入固定帽定理后再形式上提出；SG5 提供了先验合法的逐面统一帽。也没有假定来源坐标独立。closed current 面沿用原 PF 的完整面表示，不能因来源绝对连续就删掉 receiver 面测度。

本轮父稿的共同 theta 优化给
\[
 \mathcal N_L^{act}\le65 B_L\sqrt n
   \min\{\sqrt{B_L(1-s)},\sqrt{\log(e+B_L(1-s))}\},
 \tag{SG10}
\]
并可单独使用 R206 已证的较小半指数常数
\[
 \mathcal N_L^{act}\le40 B_L^{3/2}\sqrt{n(1-s)}.
 \tag{SG11}
\]
SG10 的依据仅为 PF5、0<theta<=1/2 上 C_theta<=1，及 theta=1/[2log(e+B_L(1-s))]；没有新增 selector 许可。s=1 时原 delta_i 全零，SG8–11 均先为零。

## SG5　来源位移给出的尺度衰减

令
\[
 B_*={B_0\over\prod_i C_i},\qquad
 m=\#\{i:C_i\le1/2\}\in\{0,\ldots,n\}.
\]
因为 L>=a>=b/2 且 gamma>=1，有 bar-xi_L>=1/2。于是
\[
 {B_L\over B_*}=\prod_i\max(C_i,\bar\xi_L)
 \le\bar\xi_L^m. \tag{SG12}
\]
这是一条真实共同来源几何界：m 只由同一 y,v,b 决定；不使用任何来源独立性。m 小时不产生虚构的维数收益。

固定 s，设 R_*=B_*(1-s)。由 SG10、B_L<=B_*，
\[
 \mathcal N_L^{act}\le65\sqrt n\,B_*
 \sqrt{\log(e+R_*)}\,\bar\xi_L^m. \tag{SG13}
\]
半指数支则保留更强的 bar-xi_L^{3m/2}。

## SG6　unclamped 路径的精确下端与零支

定义 L_c=b/gamma。对 a<=L<=L_c，真实 target 尺度 ell=gamma L，沿原 material 运动的相对法向速度恰为 v_i-y_i。因此 SG8 是本处的完整相对目标面分量。

对任意 real exponent q>0，令
\[
 \Theta_q^{unc}:=
 \begin{cases}
 [1-(\gamma L_0/b)^q]/q,&L_0<L_c,\\
 0,&L_0\ge L_c.
 \end{cases}
 \tag{SG14}
\]
q=0 时按真实积分定义
\[
 \Theta_0^{unc}=[\log(L_c/L_0)]_+.
\]
则直接换元 xi=gamma L/b 给
\[
 \int_{L_0}^{L_c}\bar\xi_L^q\,{dL\over L}=\Theta_q^{unc}
\]
（空区间取零），并对 m>0 等价于
\[
 \Theta_m^{unc}=
 {[1-\max(\gamma a/b,\xi_t)^m]_+\over m}
 \le\min\{1/m,\,[\log(L_c/L_0)]_+\}.
 \tag{SG15}
\]
因此
\[
 \boxed{\int_{L_0}^{L_c}\mathcal N_L^{act}\,{dL\over L}
 \le\sqrt n B_*\min\{
 40\sqrt{R_*}\,\Theta_{3m/2}^{unc},
 65\sqrt{\log(e+R_*)}\,\Theta_m^{unc}\}.} \tag{SG16}
\]
m=0 在两处均使用 Theta0 的真实对数；s=1 先原硬跳为零；a>=Lc 或 L0>=Lc 则整个 unclamped 路径为空。这里没有把端点值当作尺度路径长度的一部分。

## SG7　relative clamp 平台与实际额外速度

对于 L>=Lc，目标 ell=b、Gamma_L=b/L∈[1,gamma]。逐 L 的 PF 界仍可估 SG8 所定义的相对速度分量，且 B_L=B_*。它的路径长度为
\[
 \Theta^{plat}=
 \begin{cases}
 \log\!\bigl(b/\max(L_0,L_c)\bigr),&\max(L_0,L_c)<b,\\
 0,&\max(L_0,L_c)\ge b.
 \end{cases}
 \quad0\le\Theta^{plat}\le\log\gamma.
 \tag{SG17}
\]
所以全窗 relative 分量可将 SG16 的每个 Theta_q^{unc} 换为
\[
 \Theta_q^{rel}=\Theta_q^{unc}+\Theta^{plat}.
 \tag{SG18}
\]
这仍受实际总路径长度 [log(b/L0)]_+ 限制。m>0 时可再粗界 Theta_m^{rel}<=1/m+log gamma。只有 m 与 n 可比时，这才给 O(1/n) 的相对尺度因子；不能对一般来源对宣称 1/n。特别 m=0 不享此收益。

actual clamp 的目标面不随 L 移动，其 material 法向速度是
\[
 |v_i-y_i\pm b/2|\le|v_i-y_i|+b/2.
 \tag{SG19}
\]
SG17–18 只估前项。新增 b/2 速度不能用 unclamped 相对面定理删掉，下面独立计费。其它 cap/alpha/current 状态交换也不在 SG8 的定义内。

## SG7b　actual clamp 额外速度的 B_* 路径包络

令 L_lo=max(L0,Lc)。L_lo>=b 时该路径为空；否则定义
\[
 \Xi=n\left({b\over L_{lo}}-1\right)
 \le n(\gamma-1)=1.
 \tag{SG19a}
\]
空路径取 Xi=0。令 mathcalE_L 为 SG8 的同一实际帽、硬跳和原资格 H，只将每面的相对速度 |v_i-y_i| 换为 b/2。由于 G_B(P,delta)<=BP、Bactual<=B_*，可先正放松 H，而对每一个共同固定 s,L，
\[
 \int_{x_i=v_i\pm b/2}P_{s,L}(x-y)\,d\mathcal H^{n-1}
 ={1\over L}f_s((v_i\pm b/2-y_i)/L)\le {1\over L}.
 \tag{SG19b}
\]
这里其它坐标的真实核积分恰为 1，f_s<=1。两面各乘 b/2，再求和 n 个坐标，得到
\[
 \mathcal E_L\le n B_* b/L,
 \qquad
 \boxed{\int_{L_{lo}}^b\mathcal E_L\,{dL\over L}
 \le nB_*\left({b\over L_{lo}}-1\right)=B_*\Xi\le B_*.}
 \tag{SG19c}
\]
原 gamma=1+1/n 是最后无维数损失的必要输入。若 s=1，实际 hard delta 为零，mathcalE_L 先为零；SG19c 是安全的较粗上界。若 s=s(L) 是每一 L 对全部 receiver 共同的值，SG19b 仍可逐 L 使用，因此 SG19c 不增加 soft 菜单费。若 s=s(x,L)，其它坐标不再是同一归一产品核，不能这样积分为 1。

SG19c 支付的是 actual clamp 额外速度的几何核路径，保留下来的原来源权就是 B_* Xi；它不是一个已经支付的 W_A 来源价格，也不覆盖 cap/alpha/资格的状态交换。

## SG8　原 beta Pi² 回代

在合法的共同固定 s 路径上，先保持原 same-alpha、高 A、good、receiver、time、history、唯一 j 等门；用 SG3 得帽后，才作 SG4–9 的正放松。由于固定原 `(omega,V,j,y,t)` 的 Pi 独立 x,L，正 Tonelli 允许把面路径界积分于原来源测度。得到 unclamped 相对分量的明确上界
\[
 65\sqrt n\,\mathbb E\sum_{V,j}\int_{I_j}{dt\over t}
 \int\beta_V(dy)\int\Pi_{y,t}(dv)\Pi_{y,t}(du)\,
 B_*\sqrt{\log(e+B_*(1-s))}\,\Theta_m^{unc}(y,v,j,t).
 \tag{SG20}
\]
也可采用 SG16 的较小两支 minimum；全窗 relative 分量用 Theta^{rel}。actual clamp 的额外速度再加同一原 beta Pi² 时间来源积分下的 B_* Xi（SG19c），不得把它误作已付线性来源质量。原 far 子域之外的行可保持零；若将 t 域正扩大到共同 I_j，必须保其原可定义性、e_t>0 及空行约定。I_j、各独立窗口与全部 j 的费用都在式中，没有免费删去完整 T_*。

余下 u 后验若已不出现在上界里，可用其真实概率质量<=1；这不消去 v 槽中的 B_* 或 Theta，也不将 nu/e_t 变为概率。未假设 nu<=beta；来源质量仅有原共同父来源账 W_beta,W_nu<=W_A。

SG20 的来源权比先以 Wg=∏C_i 代入、再付 log(b/a) 的粗矩小，且 t<=g 的时间/尺度关联被保留。它仍含
\[
 {B_0\over\prod_i C_i}
 \sqrt{\log\!\left(e+{B_0(1-s)\over\prod_i C_i}\right)}
 \Theta_m^{unc/rel}, \tag{SG21}
\]
尚无无条件 W_A 预算。原概率归一不能免费控制这份反重叠加权量。

## SG9　共同选择器、端态与本轮准确边界

SG16–20 证明的是共同固定 s 的尺度路径积分。若 s=s(L) 在每个 L 上是对所有 receiver 共同的确定路径，SG9 可逐 L 使用，但 SG13 抽出的 R_* 必须改为该路径的统一上界，或保留 (1-s(L)) 在积分内；不能继续使用某个单一 s 值。若 s=s(x,L) 随 receiver 变化，则每个面上也不再是同一 mixed product 核，尚须独立的合法 soft-selector 包络及费用。

同样，积分 dlogL 的结果不是直接针对任意 L(x) 的无费估计。把实际共同选择器的端值或正变差转为这份路径面项，仍须 R201/R204/R205 的完整 transport/finite-state 账，包括初始端态、receiver 域边界、连续项、cap 变化、target/capture/high/history 的真实交换以及 recharge。它们没有被 SG20 支付。

本轮可确证的几何进展是 SG4–6 的实际 terminal/current/time 联结、SG12–18 的精确尺度平均，以及 SG19c 的 actual clamp 额外速度核价，而非新增任意条件门。当前最具体未付关系是：在合法处理共同 soft/receiver selector 后，能否用原 same-alpha/capture/source 资格给 SG21 加 B_* Xi 的实际 beta Pi² 时间来源积分一个来源价，或与原 receiver 预算联合吸收。既有静态 capture 容量及 Pi 概率质量均不能直接给出该结论。

即使某个面分量获得 kernel sqrt(n) 价，作为 companion 配原 nWnu/(2K) 能量仍可能仅得 raw n^(3/4)，不由本稿自动成为原一般根阶弱型预算。
