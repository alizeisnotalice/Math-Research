"""Exact positive-width spine and physical reentry checks."""
from decimal import Decimal, localcontext
from fractions import Fraction as F
from itertools import product
from math import isqrt
import sys

SIGMA = F(3, 2)


def fmt(x):
    with localcontext() as ctx:
        ctx.prec = 15
        return f"{Decimal(x.numerator) / Decimal(x.denominator):.8E}"


def true_spine():
    # Actual receiver squares of width v_i/128; cubes of side l_i centered
    # at every point of the receiver squares. All containment has slack.
    side = tuple(map(F, ("2", "4/3", "1")))
    volume = [l ** 2 for l in side]
    widths = [v / 128 for v in volume]
    center = tuple(map(F, ("-1/8", "0", "1/8")))
    for i in range(2):
        distance = center[i + 1] - center[i]
        combined = (widths[i + 1] + widths[i]) / 2
        assert combined < distance
        assert distance + combined + side[i + 1] / 2 < side[i] / 2
    assert volume[0] == 4 and 1 < volume[1] < 2 and volume[2] == 1
    assert all(abs(c) + w / 2 + 1 < 4 for c, w in zip(center, widths))
    starts = dict(zip("ACBD", map(F, ("-5/16", "-3/32", "1/8", "11/32"))))
    pack_width, transverse = F(3, 16), F(7, 8)
    ends = [a + pack_width for a in starts.values()]
    assert all(upper < lower for upper, lower in zip(ends, list(starts.values())[1:]))
    assert center[2] + widths[2] / 2 - side[2] / 2 < min(starts.values())
    assert max(ends) < center[2] - widths[2] / 2 + side[2] / 2
    assert transverse + widths[2] < side[2]
    mass = SIGMA * pack_width * transverse
    # Local order is (previous,next); physical pair order swaps at middle.
    g = ({"DA": F(1)}, {"AD": F(1), "CB": F(1), "AB": F(1, 8)}, {"BC": F(1)})
    private0, private2 = "D", "C"
    joint = sum((mass ** 2 * g[0].get(private0 + a, 0) * g[1].get(a + b, 0)
                 * g[2].get(b + private2, 0)) for a, b in product(starts, repeat=2))
    middle_mass = sum(g[1].values()) * mass ** 2
    first = sum(v for key, v in g[1].items() if key[0] == "A") * mass ** 2
    second = sum(v for key, v in g[1].items() if key[1] == "B") * mass ** 2
    wrongly_independent = first * second / middle_mass
    bare_pair_product = (len(starts) * mass) ** 2
    denominator = volume[1] * volume[2]  # lambda=1
    assert joint == mass ** 2 / 8 < wrongly_independent < bare_pair_product
    assert joint / wrongly_independent == F(17, 81)
    assert bare_pair_product / denominator > F(1, 2)

    # The full rank rule stops whenever the sampled current rank is below 2H.
    unit_load = widths[0] ** 2 * mass / volume[0] ** 2
    assert all(w ** 2 * mass / v ** 2 == unit_load for w, v in zip(widths, volume))
    old_load = F(9, 8) * unit_load
    h = old_load
    max_rank = old_load + unit_load
    assert max_rank == F(17, 8) * unit_load < 2 * h
    print("TRUE k=2 spine, n=2, lambda=1, sigma=3/2 on [-4,4]^2; g sparse, bare h=1.")
    print("  I_0=A_1, I_1=A_2 for all real receiver positions, volumes", *volume[1:])
    print("  raw Y, all-source independent product, wrong middle-marginal product:",
          joint, bare_pair_product, wrongly_independent)
    print("  divided by lambda^2 |I_0||I_1|:", joint / denominator,
          bare_pair_product / denominator, wrongly_independent / denominator)
    print("  Y / wrong middle product =", joint / wrongly_independent)
    print("  reduced rank H, first-source rank supremum, cutoff 2H:", h, max_rank, 2 * h)
    print("  full rank cutoff: first-hop probability and two-step mass both 0")


def dyadic_side(n, b, r):
    denom = 2 ** 12
    goal = (2 ** (n - r * b)) * denom ** n
    lo, hi = denom, 2 * denom
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if mid ** n <= goal:
            lo = mid
        else:
            hi = mid
    assert lo ** n <= goal < hi ** n
    return F(lo, denom), F(hi, denom)


def root_charges():
    print("PHYSICAL REENTRY; l_x=2; H has no role in the volume sum.")
    for n in (64, 256, 1024, 4096, 16384):
        b = 1 + isqrt(n - 1)
        h, depth = 8 * (b + 2), n // (b + 1)
        assert b % 4 == 0
        branches = 2 ** (b // 4)
        q = F(branches, 2 ** (b // 2))
        series = F(0)
        for r in range(1, depth + 1):
            actual_cap = F(2) ** (-r * b)
            enlarged_ratio = F(2) ** (-r * b // 2)
            assert actual_cap == enlarged_ratio ** 2
            branch_sum = branches ** r * enlarged_ratio
            assert branch_sum == q ** r
            series += branch_sum
        infinite = q / (1 - q)
        assert infinite - series == q ** (depth + 1) / (1 - q)
        one, last = dyadic_side(n, b, 1), dyadic_side(n, b, depth)
        factor = 4 * (n + 2) * (depth + 1)
        print("  n,b,H,T,B =", n, b, h, depth, branches,
              "level-1 coefficient relative to 2*lambda*v_x:", q)
        print("    dyadic true-side threshold brackets r=1,T:", one, last,
              "root cap/S finite,infinite:", fmt(factor * series), fmt(factor * infinite))


def private_charge():
    # n=2, scaled b=r=B=T=1; l_x=2, l_y=1, enlarged child side 2^(3/4).
    half_core = F(1, 64)
    source_half = F(1, 32)
    y = (F(-1, 4), F(1, 4))
    private = (F(-11, 16), F(11, 16))
    for j in range(2):
        span = half_core + source_half
        assert abs(y[j]) + span < F(1, 2)  # shared positive-width anchor at 0
        assert abs(y[j] - private[j]) + span < F(1, 2)
        distance_to_other = abs(y[j] - private[1 - j]) - span
        assert distance_to_other ** 4 > F(1, 2)  # enlarged half-side is 2^(-1/4)
        assert abs(private[j]) + span < 1
    assert half_core + source_half < F(1, 2)  # the second coordinate
    source_mass = SIGMA * (2 * source_half) ** 2
    raw = (2 * half_core) ** 2 * source_mass * (2 * source_mass) / 16
    print("POSITIVE-WIDTH PRIVATE TEST, n=2 scaled b=B=T=1; enlarged sides 2^(3/4).")
    print("  current |F|, fixed ex ante branch charge, branch chosen after private read:",
          raw, raw / 2, raw)


def terminal_replay():
    # Four actual oriented records in a 2D window. All coordinates below
    # denote the first axis; second-axis centers are zero. The comparison
    # kernel is explicitly prescribed, without the asymptotic rank gates.
    sides = tuple(map(F, ("1", "4/3", "2", "2")))
    centers = tuple(map(F, ("0", "9/20", "1", "47/50")))
    sites = tuple(map(F, ("-1/5", "1/4", "4/5", "9/5", "1/10")))
    pairs = ((0, 1), (2, 1), (2, 3), (2, 4))
    active = (0, 1, 0, 0)
    radius = F(1, 1000)
    for i, (center, length, endpoints) in enumerate(zip(centers, sides, pairs)):
        assert all(abs(sites[q] - center) + 2 * radius < length / 2 for q in endpoints)
        assert all(abs(center - other) > 2 * radius for other in centers[:i])
        assert abs(center) + 1 + radius < 4
        assert length ** 4 / 32 <= 1
    assert all(abs(a - b) > 2 * radius for i, a in enumerate(sites) for b in sites[:i])
    # g_i=v_i^2/32; the four equal positive row masses are normalized to one.
    # Given a transition, keep the physical common endpoint and resample only
    # its private partner and the receiver from the old record's actual boxes.
    kernel = ({}, {0: F(1)}, {1: F(1, 2)}, {1: F(1, 2)})
    for i, row in enumerate(kernel):
        for j in row:
            assert pairs[i][active[i]] == pairs[j][1 - active[j]]
    death = [1 - sum(row.values()) for row in kernel]
    reversed_kernel = [{i: row[j] for i, row in enumerate(kernel) if j in row}
                       for j in range(4)]
    assert all(sum(row.values()) <= 1 for row in reversed_kernel)

    def inside(source_state, terminal):
        distance = abs(sites[pairs[source_state][1 - active[source_state]]] - centers[terminal])
        if distance + 2 * radius < sides[terminal] / 2:
            return True
        assert distance - 2 * radius > sides[terminal] / 2
        return False

    def revisit(source_state, old_state, steps):
        # Model b0=1/2 in dimension two. Enlarged half-side to the eighth
        # power is rational. The inequalities hold on the whole cores.
        distance = abs(sites[pairs[source_state][1 - active[source_state]]] - centers[old_state])
        half_power = (sides[source_state] / 2) ** 8 / 2 ** steps
        assert sides[old_state] ** 8 <= sides[source_state] ** 8 / 4 ** steps
        if (distance + 2 * radius) ** 8 < half_power:
            return True
        assert max(F(0), distance - 2 * radius) ** 8 > half_power
        return False

    def bad(path):
        return any(revisit(i, j, t - s) for s, i in enumerate(path)
                   for t, j in enumerate(path) if s < t)

    def paths(kernel_rows, state, prefix=()):
        full = prefix + (state,)
        yield full, F(1)
        for next_state, weight in kernel_rows[state].items():
            for path, continuation in paths(kernel_rows, next_state, full):
                yield path, weight * continuation

    direct = [F(0)] * 3
    reverse = [F(0)] * 3
    for start in range(4):
        for path, weight in paths(kernel, start):
            weight *= death[path[-1]]
            for pos, indicator in enumerate((True, inside(start, path[-1]), bad(path))):
                if indicator:
                    direct[pos] += weight
        for prefix, probability in paths(reversed_kernel, start):
            ordered = prefix[::-1]
            for pos, indicator in enumerate((True, inside(ordered[0], start), bad(ordered))):
                if indicator:
                    reverse[pos] += death[start] * probability
    assert direct == reverse == [F(4), F(5, 2), F(1, 2)]
    assert direct[1] == sum(death) + direct[2]
    print("TERMINAL OCCUPATION: four positive-width 2D oriented records; prescribed kernel, b0=1/2.")
    print("  total, hits in terminal cube, bad paths (one row mass as unit):", *direct)
    print("  one terminal charge, reverse columns saturating:", sum(death), (0, 1))


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "exact fractions; scientific display rounded.")
    true_spine()
    root_charges()
    private_charge()
    terminal_replay()
