"""R849: exact P0 blocks in a positive-width identity-transport history."""

from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
from math import prod
import sys


DIM = 64
CORE = F(1, 4096)
PACKET = F(1, 128)
DENSITY = F(3, 2)
PACKET_MASS = DENSITY * (2*PACKET)**DIM
CORE_VOLUME = (2*CORE)**DIM
T = F(1, 2**1220)
H = 7*T
D = H/2
BINS = (58, 49, 40, 31, 22, 13)
THRESHOLD = F(15, 16)


@dataclass(frozen=True)
class Core:
    time: int
    side: F
    x: F
    y: F
    fraction: F

    @property
    def v(self):
        return self.side**DIM

    @property
    def g(self):
        # F on each real ordered packet pair is a target fraction of one
        # common bin mass.  The actual R density conditional on packet w
        # has total integral |E| eta(private) g / v^2.
        return T*self.fraction*self.v**2/(CORE_VOLUME*PACKET_MASS)

    @property
    def mass(self):
        return CORE_VOLUME*PACKET_MASS**2*self.g/self.v**2


def side_in_bin(k):
    den = 2**16
    lo, hi = den, 2*den
    limit = 2**k * den**DIM
    while hi-lo > 1:
        mid = (lo+hi)//2
        if mid**DIM <= limit:
            lo = mid
        else:
            hi = mid
    side = F(lo, den)
    assert F(2)**(k-1) < side**DIM <= F(2)**k
    return side


def cores():
    out = {}
    for k in range(max(BINS)+1):
        side = side_in_bin(k)
        y = F(k-29, 512)
        if k in (49,22):
            p = F(1,3) if k == 49 else F(3,4)
            out[k] = (Core(k,side,F(0),y,p), Core(k,side,F(3,8),y,1-p))
        else:
            out[k] = (Core(k,side,F(0),y,F(1)),)
    rows = tuple(c for bunch in out.values() for c in bunch)
    for r, s in combinations(rows,2):
        assert max(abs(r.x-s.x), abs(r.y-s.y))>2*CORE
    packet_centers = (F(-1,16),F(1,16))
    assert 2*PACKET < packet_centers[1]-packet_centers[0]
    for r in rows:
        assert all(max(abs(r.x-p), abs(r.y))+CORE+PACKET < r.side/2
                   for p in packet_centers)
        assert max(abs(r.x),abs(r.y))+CORE+1 < 4
        assert 1 <= r.side <= 2 and 0 < r.g < 1
    # The same density g on an ordered pair of positive packets yields
    # the same true t_j(w) in either orientation, for every w in its packet.
    assert all(sum(r.mass for r in bunch)/PACKET_MASS==T for bunch in out.values())
    return out


def rank(time):
    return time*T, (time+1)*T


def reference_probability(new, old):
    u0,u1 = rank(new)
    v0,v1 = rank(old)
    assert u0 >= 2*H and old < new-8
    assert H <= u0-v1 <= u1-v0 <= H+D
    # Every u in the true current interval accepts the entire old interval.
    # In the old interval the reference draws the actual conditional record.
    return (v1-v0)/D


def overlap_pass(r, s):
    delta = max(abs(r.x-s.x), abs(r.y-s.y)) + 2*CORE
    small = min(r.side,s.side)
    large = max(r.side,s.side)
    if delta < (large-small)/2:
        return True, F(1)
    maximum_first_overlap = max(F(0), (small+large)/2-abs(r.x-s.x)+2*CORE)
    normalized = maximum_first_overlap/small
    assert normalized < THRESHOLD
    return False, normalized


def compact(mass):
    quotient = mass.denominator
    odd = quotient//(quotient & -quotient)
    exponent = (quotient//odd).bit_length()-1
    return f"{mass.numerator}/{odd} * 2^(-{exponent})"


def replay():
    E = cores()
    caps = tuple(reference_probability(k,j) for k,j in zip(BINS,BINS[1:]))
    assert caps==(F(2,7),)*5
    assert rank(BINS[-1])[1]==2*H
    reference_mass = PACKET_MASS*T/2 * prod(caps)
    print("Python", sys.version.split()[0], "| Fraction exact; R849 identity transport")
    print("sigma=3/2 on [-4,4]^64, eta is its cut to two positive disjoint packets.")
    print("59 actual dyadic bins, 61 disjoint positive receiver cores; 1<M_[1,2]<=2.")
    print("5-step bins",BINS,"; H/t=7, d/t=7/2, small-H test; last rank stops below 2H.")
    print("All prescribed pairs satisfy true all-rank compatibility; P0 old-bin probability 2/7.")
    print("Real labelled reference path mass",compact(reference_mass))
    print("Condition on actual private source points, four fixed receivers, and the path bins.")
    print("Every source point obeys the same estimates on its positive packet; identity transport")
    print("shares the realized endpoint of adjacent records and leaves the actual private end fixed.")
    acceptance = F(0)
    accepted_pairs = []
    all_states = []
    max_bad = F(0)
    for a,b in product(E[49],E[22]):
        rows=(E[58][0],a,E[40][0],E[31][0],b,E[13][0])
        conditional = a.fraction*b.fraction
        # Directly integrate one actual receiver factor per visited record.
        raw_history = rows[0].mass/2*prod(
            old.mass/(PACKET_MASS*D) for old in rows[1:])
        assert raw_history==reference_mass*conditional
        checks = tuple(overlap_pass(r,s) for r,s in zip(rows,rows[1:]))
        assert tuple(ok for ok,_ in checks)==(a.x==0,a.x==0,True,b.x==0,b.x==0)
        bad_bounds = [bound for passed, bound in checks if not passed]
        max_bad = max([max_bad, *bad_bounds])
        passed = all(ok for ok,_ in checks)
        acceptance += conditional*passed
        all_states.append((conditional,passed))
        accepted_pairs.append((a.fraction,b.fraction,conditional,passed))
    assert sum(p for p,_ in all_states)==1
    assert acceptance==F(1,4)
    p,q=E[49][0].fraction,E[22][0].fraction
    assert (p,p*p,q,q*q)==(F(1,3),F(1,9),F(3,4),F(9,16))
    assert acceptance==p*q and p*p*q*q==F(1,16)
    print("Gate: true intersection / smaller witness volume >=",THRESHOLD,
          "; uniformly passing ratio 1, failing ratio <=",max_bad)
    print("Same receiver vs separate redraw in its two neighboring stars: bin 49",p,p*p,
          "; bin 22",q,q*q)
    print("Exact P0 four-state table (first location weight, second location weight, joint, accepted):",
          accepted_pairs)
    print("Middle records three stars apart: joint",acceptance,"= product of the two block probabilities;",
          "incorrect redraw in every separate star",p*p*q*q)
    print("Actual accepted labelled path mass",compact(reference_mass*acceptance))
    wrong=lambda c: c[0].g**2/sum(r.g**2 for r in c)
    erroneously_duplicated=wrong(E[49])*wrong(E[22])
    assert (wrong(E[49]),wrong(E[22]),erroneously_duplicated)==(F(1,5),F(9,10),F(9,50))
    print("Double-counting each shared middle g would give pair probabilities 1/5 and 9/10,",
          "joint",erroneously_duplicated)
    print("A finite conditional-law check; no high-load premise used.")


if __name__ == "__main__":
    replay()
