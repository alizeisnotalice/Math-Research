"""Independent rational certificate for the terminal logarithmic potential identity."""
from collections import defaultdict, namedtuple
from fractions import Fraction as F
from functools import cache
from math import prod
import sys

State = namedtuple("State", "bin endpoints phase receiver")


def strip(upper, lower, h):
    a, b = upper
    c, d = lower

    def width(u):
        return max(F(0), min(d, u - h) - max(c, u - 2 * h))

    knots = sorted({a, b} | {z + offset for z in (c, d) for offset in (h, 2 * h)
                              if a < z + offset < b})
    return sum((v - u) * (width(u) + width(v)) for u, v in zip(knots, knots[1:])) / (2 * h)


def geometry():
    n = 4
    sides = tuple(map(F, ("1", "9/8", "5/4", "3/2", "2")))
    centers = dict(zip("ABCD", map(F, ("-3/16", "-1/16", "1/16", "3/16"))))
    receivers = tuple(F(i - 2, 16) for i in range(5))
    pack_mass = F(3, 2) * F(1, 32) * F(1, 4) ** (n - 1)
    receiver_volume = F(1, 32) * F(1, 8) ** (n - 1)
    template = ((0, "AB", F(1)), (0, "AD", F(1, 2)), (1, "DB", F(1)),
                (2, "DC", F(1)), (3, "AC", F(1)), (3, "AB", F(1, 2)), (4, "AB", F(1)))
    capacities = [receiver_volume * pack_mass ** 2 / sides[i] ** (2 * n)
                  for i, _, _ in template]
    unit = F(3, 4) * min(cap / row[-1] for cap, row in zip(capacities, template))
    masses = [unit * w for _, _, w in template]
    h = F(3, 2) * unit / pack_mass
    for i, side in enumerate(sides):
        assert (side == 1 and i == 0) or 2 ** (i - 1) < side ** n <= 2 ** i
        assert all(abs(z - receivers[i]) + F(1, 32) < side / 2 for z in centers.values())
        assert abs(receivers[i]) + 1 + F(1, 64) < 4
    assert all(0 < mass <= cap for mass, cap in zip(masses, capacities))
    assert all(b - a > F(1, 32) for a, b in zip(receivers, receivers[1:]))
    states = [State(i, pair, phase, receivers[i]) for i, pair, _ in template for phase in (0, 1)]
    mu = [mass / 2 for mass in masses for _ in (0, 1)]
    groups = defaultdict(lambda: defaultdict(list))
    for e, st in enumerate(states):
        groups[st.phase, st.endpoints[st.phase]][st.bin].append(e)
    full = [{} for _ in states]
    gated = [{} for _ in states]
    for (phase, _), by_bin in groups.items():
        masses_by_bin = {i: sum(mu[e] for e in entries) for i, entries in by_bin.items()}
        t = {i: 2 * mass / pack_mass for i, mass in masses_by_bin.items()}
        rank = {}
        start = F(0)
        for i, length in sorted(t.items()):
            assert 0 < length <= h < 4
            rank[i] = start, start + length
            start += length
        for i, current in rank.items():
            for j, old in rank.items():
                if j >= i:
                    continue
                overlap = strip(current, old, h)
                if not overlap:
                    continue
                for e in by_bin[i]:
                    for f0 in by_bin[j]:
                        f = f0 ^ 1
                        weight = overlap / t[i] * mu[f0] / masses_by_bin[j]
                        full[e][f] = weight
                        a, b = (states[k].endpoints[1 - phase] for k in (e, f))
                        if a != b:
                            assert abs(centers[a] - centers[b]) - F(1, 32) > F(1, 16)
                            gated[e][f] = weight * (F(3, 4) if centers[b] < centers[a] else 1)
    spine = (12, 9, 6, 5, 0)
    assert mu[spine[0]] * prod(gated[e][f] for e, f in zip(spine, spine[1:])) == F(1, 2 ** 58)
    short = [{f: p for f, p in row.items() if states[f].bin >= 2} for row in gated]
    print("TRUE BOXES: partial rank-window strip integration, without the u<2H cutoff or the full-bin gate.")
    for name, ker in (("all strip edges", full), ("finite partner-gated variant", gated),
                      ("short partner-gated variant", short)):
        report("true boxes: " + name, states, mu, ker)
    print("  All three finite variants use identical real sources, centers, oriented labels and one old slot.")
    print("  H =", h, "calibrated to small true loads; theoretical H about sqrt(n) untested.")


def transpose(states, mu, p):
    q = [{} for _ in p]
    for e, row in enumerate(p):
        for f, value in row.items():
            a, b = states[e], states[f]
            assert a.bin > b.bin and a.phase != b.phase
            assert a.endpoints[a.phase] == b.endpoints[a.phase]
            q[f][e] = mu[e] * value / mu[f]
    return q


def state_potential(states, q):
    v = [F(1)] * len(states)
    depth = [0] * len(states)
    for e in sorted(range(len(states)), key=lambda e: states[e].bin, reverse=True):
        v[e] += sum(value * v[f] for f, value in q[e].items())
        depth[e] = max((1 + depth[f] for f in q[e]), default=0)
    iterate = [F(1)] * len(states)
    for _ in range(max(depth)):
        iterate = [1 + sum(w * iterate[f] for f, w in row.items()) for row in q]
    assert v == iterate
    return v, max(depth)


@cache
def logunit(value):
    z = (value - 1) / (value + 1)
    assert 0 <= z <= F(1, 3)
    count = 24
    approximation = 2 * sum(z ** (2 * j + 1) / (2 * j + 1) for j in range(count))
    error = 2 * z ** (2 * count + 1) / ((2 * count + 1) * (1 - z ** 2))
    return approximation, approximation + error


@cache
def logbound(value):
    assert value >= 1
    twos = 0
    while value > 2:
        value /= 2
        twos += 1
    a, b = logunit(value)
    lo, hi = logunit(F(2))
    return a + twos * lo, b + twos * hi


def bracket(linear, logs, total, digits=9):
    lower = upper = linear
    for value, weight in logs.items():
        lo, hi = logbound(value)
        if weight < 0:
            lo, hi = hi, lo
        lower += weight * lo
        upper += weight * hi
    scale = 10 ** digits
    lo, hi = lower * scale / total, upper * scale / total
    a = lo.numerator // lo.denominator
    b = -(-hi.numerator // hi.denominator)

    def text(z):
        front, tail = divmod(abs(z), scale)
        sign = "-" if z < 0 else ""
        return f"{sign}{front}.{tail:0{digits}d}"

    return f"[{text(a)},{text(b)}]"


def report(name, states, mu, p):
    q = transpose(states, mu, p)
    c = [sum(row.values(), F(0)) for row in q]
    row_sums = [sum(row.values(), F(0)) for row in p]
    assert all(0 <= w <= 1 for w in c + row_sums)
    death = [mass * (1 - row) for mass, row in zip(mu, row_sums)]
    assert all(death[f] == mu[f] - sum(mu[e] * q[e].get(f, 0) for e in range(len(mu)))
               for f in range(len(mu)))
    v, max_depth = state_potential(states, q)
    success, failure, rhs = defaultdict(F), defaultdict(F), defaultdict(F)
    harmonic = s_linear = f_linear = F(0)
    for e, mass in enumerate(mu):
        ve, survive = v[e], c[e]
        missing = 1 - survive
        assert (sum(weight * v[f] for f, weight in q[e].items()) + missing) / ve == 1 - survive / ve
        harmonic += mass * survive / ve
        point_success = sum(weight * (v[f] / ve - 1) for f, weight in q[e].items())
        point_failure = missing * (1 / ve - 1)
        assert survive / ve + point_success + point_failure == 0
        s_linear += mass * point_success
        f_linear += mass * point_failure
        for f, weight in q[e].items():
            success[ve] += mass * weight
            success[v[f]] -= mass * weight
        failure[ve] += mass * missing
        rhs[ve] += death[e]
    assert harmonic + s_linear + f_linear == 0
    assert all(success[k] + failure[k] == rhs[k] for k in success.keys() | failure.keys() | rhs.keys())
    mass = sum(mu)
    print(name, "states", len(states), "depth", max_depth,
          "max V", max(v), "max c", max(c), "D/mu", sum(death) / mass)
    print("  normalized intervals c/V, success phi, failure phi, D log V:",
          bracket(harmonic, {}, mass), bracket(s_linear, success, mass),
          bracket(f_linear, failure, mass), bracket(F(0), rhs, mass))
    print("  exact affine zero and exact log coefficients for", len(rhs.keys()), "potential values")
    divergent = [e for e in range(len(mu)) if len({v[f] for f in q[e]}) > 1]
    if divergent:
        e = max(divergent, key=lambda e: (c[e], len(q[e])))
        candidates = defaultdict(F)
        for f, weight in q[e].items():
            candidates[v[f]] += weight
        print("  divergent future at bin", states[e].bin, "c", c[e], "V", v[e],
              "potential:mass", sorted(candidates.items()), "failure", 1 - c[e])


def abstract():
    print("ABSTRACT CONTROLS; oriented labels are retained, no geometric rank realization claimed.")
    height = 13
    states = [State(0, ("a", "b"), 0, "Y0")]
    for i in range(1, height):
        phase = i % 2
        endpoints = list(states[-1].endpoints)
        endpoints[1 - phase] = f"w{i}"
        states.append(State(i, tuple(endpoints), phase, f"Y{i}"))
    states.append(State(1, ("short", "b"), 1, "Yside"))
    uniform = [{} for _ in states]
    for i in range(1, height):
        uniform[i][i - 1] = F(1)
    branched = [row.copy() for row in uniform]
    branched[1][0] = branched[-1][0] = F(127, 256)
    mu = [F(1)] * len(states)
    report("uniform long chain with isolated control", states, mu, uniform)
    report("same states with strong lateral divergence", states, mu, branched)


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "Fraction and certified log series, no float certificates.")
    geometry()
    abstract()
