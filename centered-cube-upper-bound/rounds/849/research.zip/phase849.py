"""R849 exact grid-phase expectations on actual consecutive cubical overlaps."""

from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction as F
from itertools import combinations
from math import ceil, comb, floor, prod
import sys


N = 32
H = F(1, N)
EPS = H/16
CORE = EPS/128


def length(interval):
    return max(F(0), interval[1]-interval[0])


def intersection(a, b):
    return max(a[0],b[0]), min(a[1],b[1])


def phase_cuts(intervals):
    return sorted({F(0), H} | {endpoint % H for pair in intervals for endpoint in pair})


def count_at(interval, phase):
    lo, hi = interval
    return max(0, floor((hi-phase)/H)-ceil((lo-phase)/H)+1)


def moment(intervals):
    cuts = phase_cuts(intervals)
    value = F(0)
    for lo, hi in zip(cuts,cuts[1:]):
        phase = (lo+hi)/2
        value += (hi-lo)/H * prod(H*count_at(i,phase) for i in intervals)
    return value


@dataclass(frozen=True)
class Averages:
    baseline: F
    shared: F
    partition: F
    mixed: F
    positive_by_blocks: tuple


def average(intervals, bridge):
    k = len(intervals)
    baseline = prod(map(length,intervals))
    table = {(i,j):moment(intervals[i:j]) for i in range(k) for j in range(i+1,k+1)}
    assert all(table[i,i+1]==length(intervals[i]) for i in range(k))
    partition = probability = F(0)
    positive = []
    for blocks in range(1,k+1):
        prob_cutset = F(1,k*comb(k-1,blocks-1))
        positive_count = 0
        for cuts in combinations(range(1,k),blocks-1):
            bounds = (0,*cuts,k)
            contribution = prod(table[i,j] for i,j in zip(bounds,bounds[1:]))
            if bridge is None:
                assert contribution > 0
            else:
                assert (contribution > 0) == (bridge in cuts or bridge+1 in cuts)
            positive_count += int(contribution > 0)
            partition += prob_cutset*contribution
            probability += prob_cutset
        if bridge is not None:
            expected = comb(k-1,blocks-1)-comb(k-3,blocks-1)
            assert positive_count == expected
        positive.append(positive_count)
    assert probability == 1
    shared = table[0,k]
    mixed = F(N,N+1)*baseline + (shared+partition)/(2*(N+1))
    return Averages(baseline,shared,partition,mixed,tuple(positive))


def ceiling_volume_bin(v):
    k = v.numerator.bit_length()-v.denominator.bit_length()
    if F(2)**k < v:
        k += 1
    assert F(2)**(k-1) < v <= F(2)**k
    return k


def cube_model(k, bridge):
    sides = tuple(F(2)-2*i*H for i in range(k+1))
    assert all(1 <= side <= 2 and side/H == floor(side/H) for side in sides)
    bins = tuple(ceiling_volume_bin(l**N) for l in sides)
    assert all(i>j for i,j in zip(bins,bins[1:]))
    first_axes = []
    first_centers = []
    for i,l in enumerate(sides):
        phase = H/2 if bridge is not None and i>bridge else F(0)
        segment = (phase,phase+l) if i%2==0 else (phase+EPS-l,phase+EPS)
        first_axes.append(segment)
        first_centers.append(sum(segment)/2)
    assert all(abs(c-d)>2*CORE for c,d in combinations(first_centers,2))
    assert all(abs(c)+CORE+1 < 4 for c in first_centers)
    assert 2*CORE < H
    # The actual receiver cores are positive cubes with half-side CORE.
    # Other axes of adjacent witnesses stay nested because the half-side
    # difference H exceeds 2*CORE, so their lengths are complete grid lengths.
    assert all((l-s)/2==H for l,s in zip(sides,sides[1:]))
    thin = tuple(intersection(a,b) for a,b in zip(first_axes,first_axes[1:]))
    expected = []
    for i in range(k):
        if bridge is None or i<bridge:
            expected.append((F(0),EPS))
        elif i==bridge:
            expected.append((F(0),H/2+EPS))
        else:
            expected.append((H/2,H/2+EPS))
    assert list(thin)==expected
    lower = tuple((a+CORE,b-CORE) for a,b in thin)
    upper = tuple((a-CORE,b+CORE) for a,b in thin)
    for i,(inside,outside,v) in enumerate(zip(lower,upper,thin)):
        a,b = first_axes[i:i+2]
        assert intersection((a[0]+CORE,a[1]-CORE),(b[0]+CORE,b[1]-CORE))==inside
        assert intersection((a[0]-CORE,a[1]+CORE),(b[0]-CORE,b[1]+CORE))==outside
        assert 0<length(inside)<length(v)<length(outside)<H
    # Actual uniform sources with density 3/2 restricted to disjoint
    # positive cubes. There is one real packet for each w_i in I_i,
    # plus private boundary packets, with separate positions on axis 2.
    edge_for_source = (0,*range(k),k-1)
    orthogonal_marks = tuple((i-F(k+1,2))*4*CORE for i in range(k+2))
    assert all(y-x>2*CORE for x,y in zip(orthogonal_marks,orthogonal_marks[1:]))
    for edge,mark in zip(edge_for_source,orthogonal_marks):
        first = sum(thin[edge])/2
        assert lower[edge][0] < first-CORE < first+CORE < lower[edge][1]
        assert abs(mark)+2*CORE < sides[edge+1]/2
    # Background sigma=3/2 on [-4,4]^N makes every actual witness here
    # strict at lambda=1 and puts all receiving cores inside the height band.
    # For all other axes, direct grid counting also checks the three
    # arbitrary phases below. The analytic constancy follows by periodicity.
    for side in sides[1:]:
        for phase in (H/19,H/7,4*H/5):
            assert count_at((-side/2,side/2),phase)*H==side
    return thin,lower,upper,bins


def compact(q):
    return str(q) if q.denominator < 10**7 else f"{float(q):.9g}"


def directed(q, rounding):
    with localcontext() as context:
        context.prec = 10
        context.rounding = rounding
        return str(Decimal(q.numerator)/Decimal(q.denominator))


def run(k,bridge):
    thin,lower,upper,bins = cube_model(k,bridge)
    nominal = average(thin,bridge)
    inner,outer = average(lower,bridge),average(upper,bridge)
    assert inner.baseline <= nominal.baseline <= outer.baseline
    assert inner.shared <= nominal.shared <= outer.shared
    assert inner.partition <= nominal.partition <= outer.partition
    assert inner.mixed <= nominal.mixed <= outer.mixed
    if bridge is None:
        assert nominal.shared==H**(k-1)*EPS
        assert nominal.partition==sum(H**(k-b)*EPS**b for b in range(1,k+1))/k
    else:
        assert outer.shared==0 and inner.partition>0
        assert sum(nominal.positive_by_blocks)==3*2**(k-3)
    baseline_weight = F(N,N+1)
    exploratory_weight = F(1,2*(N+1))
    ratio_lower = baseline_weight + exploratory_weight*(inner.shared+inner.partition)/outer.baseline
    ratio_upper = baseline_weight + exploratory_weight*(outer.shared+outer.partition)/inner.baseline
    assert ratio_lower <= nominal.mixed/nominal.baseline <= ratio_upper
    tag = "aligned" if bridge is None else f"half-phase switch, bridge edge {bridge}"
    print("k",k,tag,"; actual volume bins",bins)
    print("  phase breakpoints / h",tuple(map(str,(p/H for p in phase_cuts(thin)))))
    print("  baseline, full-shared, random partition, mixed / h^k:",
          *(compact(v/H**k) for v in (nominal.baseline,nominal.shared,nominal.partition,nominal.mixed)))
    print("  positive cutsets by block count",nominal.positive_by_blocks,
          "; hybrid / independent:",compact(nominal.mixed/nominal.baseline))
    print("  positive-width core ratio enclosure",
          f"[{directed(ratio_lower, ROUND_FLOOR)}, {directed(ratio_upper, ROUND_CEILING)}]")


if __name__ == "__main__":
    print("Python",sys.version.split()[0],"| Fraction exact | n=32, h=1/32, eps=h/16, core radius eps/128")
    print("Pure 3/2 background on a finite box; all disjoint receiver cores and source packets have positive width.")
    print("Axes 2..32 contribute exact full-grid-length factors; the reported ratios are also n-dimensional.")
    for k,bridge in ((2,None),(4,None),(8,None),(4,2),(8,4)):
        run(k,bridge)
    print("All rational assertions passed. Geometric denominators tested; no high-load claim.")
