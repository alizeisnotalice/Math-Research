"""Anchored reference with independent donor centers uniform on [-1,1]^n."""
import sys,os,socket,json,random,math,time
from multiprocessing import get_context
def trial(spec):
    b,p,j=spec
    n=1<<b
    seed=1721919+b*100000+p*1000+j
    rng=random.Random(seed)
    minupper=2.
    widths=[]
    for _ in range(n):
        v=[rng.random() for t in range(p)]
        m=min(v); minupper=min(minupper,2*m)
        widths.append(1-(max(v)-m))
    L=math.log(n)
    row=[]
    for alpha in (.35,.5,.65,.85):
        rad=max(0.,alpha*L/n-minupper)
        score=math.fsum(math.log1p(rad/s) for s in widths)/(p*L)
        row.append(score)
    return (b,p,row,os.getpid())
if __name__=='__main__':
    parity,w,lo,hi,reps=map(int,sys.argv[1:])
    jobs=[(b,p,j) for b in range(lo,hi+1) for p in (2,4,8) for j in range(parity,reps,2)]
    with get_context('fork').Pool(w) as pool: output=pool.map(trial,jobs,1)
    summary=[]
    for b in range(lo,hi+1):
        for p in (2,4,8):
            samples=[x[2] for x in output if x[:2]==(b,p)]
            for idx,alpha in enumerate((.35,.5,.65,.85)):
                cs=[s[idx] for s in samples]
                summary.append([b,p,alpha,len(cs),sum(s<=.5 for s in cs),min(cs),sum(cs)/len(cs),max(cs)])
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,workers=len({x[3] for x in output}),args=sys.argv[1:],records=summary)))
