"""Exact mixed integral by two independent finite expansions."""
import itertools,random,json,math
rng=random.Random(99704)
count=0
for n in (1,2,3,4):
    for trial in range(20):
        boxes=[];weights=[]
        for i in range(5):
            s=rng.choice((1,2,3))
            cen=[rng.randint(-2,2) for _ in range(n)]
            boxes.append([(x-s,x+s) for x in cen]);weights.append(rng.randint(1,5))
        cells=[]
        for k in range(n):
            faces=sorted({y for box in boxes for y in box[k]})
            cells.append(list(zip(faces,faces[1:])))
        vals=[]
        for c in itertools.product(*cells):
            vol=math.prod(b-a for a,b in c)
            w=sum(w for box,w in zip(boxes,weights) if all(lo<=a and b<=hi for (lo,hi),(a,b) in zip(box,c)))
            vals.append((vol,w))
        for r in (2,3,4):
            lhs=sum(v*w**r for v,w in vals);rhs=0
            for ids in itertools.product(range(len(boxes)),repeat=r):
                widths=[max(0,min(boxes[i][k][1] for i in ids)-max(boxes[i][k][0] for i in ids)) for k in range(n)]
                rhs+=math.prod(widths)*math.prod(weights[i] for i in ids)
            assert lhs==rhs;count+=1
print(json.dumps(dict(comparisons=count,seed=99704)))
