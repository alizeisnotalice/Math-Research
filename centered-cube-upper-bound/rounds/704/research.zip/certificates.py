"""Exact geometric arithmetic and strict bounds on dimension powers."""
from fractions import Fraction as F
from random import Random
from flint import arb,ctx
import json,sys,flint
rng=Random(704)
def exact(n):
    a=32*n; h=1+F(1,a); sj=F(1)
    for trial in range(96):
        x=[F(rng.randint(-a,a),a) for k in range(n)]
        # z=0. Simulate two arbitrary dense directions and a feasible vector in their span.
        g=[[F(rng.randint(-4,4),8) for k in range(n)] for col in range(2)]
        v=[g[0][k]+g[1][k] for k in range(n)]
        tol=[abs(x[k]+v[k]) for k in range(n)]
        # Guaranteed only from radius one onward.
        for s in (F(1),F(5,4),F(3)):
            y=[s*F(rng.randint(-16,16),16) for k in range(n)]
            delta=[(g[0][k]-g[1][k])/(2*n) for k in range(n)]
            assert max(map(abs,delta))<=1/(F(2)*n)
            assert all(abs(x[k]+v[k]+delta[k]-y[k])<=(1+tol[k]+F(1,n))*s for k in range(n))
    return 288
ctx.prec=1400
profiles=sum(exact(n) for n in (2,4,12,32,64))
tested=0
for bits in range(8,1001):
    n=2**bits; L=arb(n).log()
    for d,A,g_num in ((1,1,1),(2,2,2),(5,5,3)):
        gamma=F(g_num,8); p=2*(int(F(A+2*d,1)/(F(1,2)-gamma)) + 2)
        vec=arb(g_num)/8*L/n
        logcost=arb(n)*(vec+arb(33)/(32*n)).log1p()
        assert logcost<=arb(g_num)/8*L+arb(33)/32
        assert (A+2*d)*L+p*logcost-p*L/2 < p*arb(33)/32
        tested+=1
print(json.dumps(dict(python=sys.version,flint=flint.__version__,precision=ctx.prec,profiles=profiles,interval_cases=tested)))
