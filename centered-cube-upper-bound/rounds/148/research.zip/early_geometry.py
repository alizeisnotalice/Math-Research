#!/usr/bin/env python3
"""Full saved early-time residual and posterior-bad caps, no kernels/quadrature."""
import sys,json,hashlib,time,datetime,zipfile,importlib.util,argparse
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--input-root',default='/Users/zhengzhihao/Desktop/T/output');ap.add_argument('--r147-archive',default=str(ROOT.parent.parent/'147/research.zip'));args=ap.parse_args();BASE=Path(args.input_root);ARCHIVE=Path(args.r147_archive)
FILES={'source':(BASE/'centered_cube_round136_20261014/active_traffic_v2.json','1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de'),'receiver':(BASE/'centered_cube_round142_20261015/numeric_receiver.json','c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55'),'primitive':(BASE/'centered_cube_round143_20261015/numeric_flux.py','eda566f1d7a622788a4fc863cde6f31ad8cdb3808f1da0c29f52ad126d8d6521')}
COVERAGE_SHA='589b2a37ffca9a5c0a801c435c8d4918f0fd6a1d16fec519ef2dc088cbf3c0de'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fr(x):return F(str(x))
def jf(x):return F(int(x['numerator']),int(x['denominator']))
def mm(x):return mp.mpf(x.numerator)/x.denominator if isinstance(x,F) else mp.mpf(x)
def dec(x,n=100):return mp.nstr(x,n)
def quant(vals):
 vals=sorted(vals)
 if not vals:return {'N':0}
 out={'N':len(vals)}
 for p in [0,.1,.5,.9,.99,1]:
  z=(len(vals)-1)*p;i=int(z);out[str(p)]=float(vals[i]+(vals[min(i+1,len(vals)-1)]-vals[i])*(z-i))
 return out
start=time.monotonic();data={};hashes={}
for k,(p,expected) in FILES.items():
 hashes[k]=sha(p);assert hashes[k]==expected,(k,hashes[k])
 if k!='primitive':data[k]=json.loads(p.read_text())
with zipfile.ZipFile(ARCHIVE) as z:raw=z.read('time_coverage.json')
hashes['R147_time_coverage_member']=hashlib.sha256(raw).hexdigest();assert hashes['R147_time_coverage_member']==COVERAGE_SHA;coverage=json.loads(raw)
spec=importlib.util.spec_from_file_location('r143_guarded_primitive',FILES['primitive'][0]);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
source={c['id']:c for c in data['source']['cases']};want={(r['case'],r['id']) for r in coverage['records']};receivers={};nu_bycase={}
for cid,c in data['receiver']['cases'].items():
 if cid in ['I1','P1']:nu_bycase[cid]=list(map(jf,c['nu_exact']))
 for r in c['records']:
  if (cid,r['id']) in want:receivers[(cid,r['id'])]=r
assert len(receivers)==179

def model(ss,nu):
 ks=ss['k'];cs=list(map(fr,ss['c']));levels=sorted(set(ks));groups={k:sum((nu[i]*cs[i] for i in range(6) if ks[i]==k),F(0)) for k in levels};return ks,cs,levels,groups

def pair_integral(ss,nu,v,u,lo,hi):
 if hi<=lo:return mp.mpf(0)
 ks,cs,levels,g=model(ss,nu);assert ks[v]>ks[u]
 if len(levels)==2:
  d=levels[1]-levels[0];assert ks[v]-ks[u]==d;A,B=map(mm,[g[levels[1]],g[levels[0]]]);z0,z1=lo**(-d),hi**(-d);return mm(nu[v]*nu[u]*cs[v]*cs[u])*(z0-z1)/((A*z0+B)*(A*z1+B))
 assert levels==[0,8,16];A,B,C=[g[k] for k in reversed(levels)];ix={(2,1):0,(2,0):1,(1,0):2}[(levels.index(ks[v]),levels.index(ks[u]))];return mm(nu[v]*nu[u]*cs[v]*cs[u])*(old.primitive(hi**8,A,B,C)[ix]-old.primitive(lo**8,A,B,C)[ix])

def reciprocal_quadratic(u,A,B,C):
 a,b,c=map(mm,[A,B,C]);dd=4*A*C-B*B;v=2*c*u+b
 if dd==0:return -1/(c*(u+b/(2*c)))
 if dd>0:
  z=mp.sqrt(mm(dd));return 2/z*mp.atan(v/z)
 z=mp.sqrt(mm(-dd));assert v>z;return mp.log((v-z)/(v+z))/z

def single_high_integral(ss,nu,v,lo,hi):
 if hi<=lo:return mp.mpf(0)
 ks,cs,levels,g=model(ss,nu);assert ks[v]==max(levels)
 if len(levels)==2:
  assert levels==[0,ks[v]];A,B=map(mm,[g[ks[v]],g[0]]);e=lambda t:A*t**(-ks[v])+B;return mm(nu[v]*cs[v])/A*mp.log(e(lo)/e(hi))
 assert levels==[0,8,16];A,B,C=[g[k] for k in reversed(levels)];a,b,c=map(mm,[A,B,C])
 def primitive(t):
  u=t**8;P=a+b*u+c*u*u;H=reciprocal_quadratic(u,A,B,C);return 2*mm(nu[v]*cs[v])/a*(mp.log(u)-mp.log(P)/2-b*H/2)
 return primitive(hi)-primitive(lo)

def posterior_range(ss,nu,which,lo,hi):
 ks,cs,levels,g=model(ss,nu);points=[lo,hi]
 def value(t):
  weights=[mm(nu[i]*cs[i])*t**(-ks[i]) for i in range(6)];return sum(weights[i] for i in which)/sum(weights)
 if len(levels)==3:
  assert levels==[0,8,16];A,B,C=[g[k] for k in reversed(levels)];a,b,c=[sum((nu[i]*cs[i] for i in which if ks[i]==k),F(0)) for k in reversed(levels)];d0=b*A-a*B;d1=2*(c*A-a*C);d2=c*B-b*C;roots=[]
  if d2:
   disc=d1*d1-4*d2*d0
   if disc>=0:
    sq=mp.sqrt(mm(disc));roots=[(-mm(d1)+sq)/(2*mm(d2)),(-mm(d1)-sq)/(2*mm(d2))]
  elif d1:roots=[-mm(d0)/mm(d1)]
  for u in roots:
   if u>0:
    t=mp.root(u,8)
    if lo<t<hi:points.append(t)
 vals=[value(t) for t in points];return dict(min=dec(min(vals)),max=dec(max(vals)),critical_times=[dec(t) for t in points[2:]],lo=dec(vals[0]),hi=dec(vals[1]))

def calculate(row,precision):
 cid=row['case'];r=receivers[(cid,row['id'])];src=source[cid];nu=nu_bycase[cid]
 with mp.workdps(precision):
  assert all(r['gates'].values()) and r['traffic']['positive_raw'];bad=[i for i in range(6) if r['bad'][i]];outer=fr(r['p'])*fr(r['hardmass'])/fr(r['q']);I=UB=U0=mp.mpf(0);caprows=[];seen=set()
  for cp in row['caps']:
   si=cp['segment'];v=cp['v'];u=cp['u'];ss=src['score_segments'][si];ks,cs,levels,g=model(ss,nu);assert cp['u_name']=='G4' and u==3 and r['good'][v] and r['bad'][u] and src['pairs'][6*v+u]['Psi'];assert ks[v]-ks[u]==cp['delta']>0;assert (v,si) not in seen;seen.add((v,si));rho=fr(r['rho'][v]);assert rho>0 and str(rho)==cp['rho'];lo,hi=map(fr,[cp['effective_lo'],cp['effective_hi']]);assert lo>=fr(ss['lo']) and hi<=fr(ss['hi']);left=mm(lo)
   if cp['gate']=='full':right=left
   elif cp['gate']=='empty':right=mm(hi)
   else:
    power=jf(cp['entry_power_exact']);assert lo**ks[v]<power<hi**ks[v];right=mp.root(mm(power),ks[v])
   if right>left:
    val=mm(rho)*pair_integral(ss,nu,v,u,left,right);boundB=val*ks[v]/cp['delta'];bound0=mm(rho)*single_high_integral(ss,nu,v,left,right);assert val>=0 and boundB>=val and bound0>=boundB;eligible=posterior_range(ss,nu,[u],left,right);totalbad=posterior_range(ss,nu,bad,left,right);weightmean=boundB/bound0
   else:val=boundB=bound0=mp.mpf(0);eligible=totalbad=None;weightmean=None
   base=mp.mpf(cp['residual']);change=abs(val-base)/abs(base) if base else abs(val);assert change<mp.mpf('1e-55');I+=val;UB+=boundB;U0+=bound0
   caprows.append(dict(segment=si,v=v,u=u,v_name=cp['v_name'],u_name=cp['u_name'],score_v=ks[v],score_u=ks[u],delta=cp['delta'],bad_source_prior_nu=str(nu[u]),all_terminalbad_prior_nu=str(sum((nu[i] for i in bad),F(0))),rho=str(rho),original_FA_lo=cp['original_FA_lo'],original_FA_hi=cp['original_FA_hi'],effective_lo=cp['effective_lo'],effective_hi=cp['effective_hi'],R147_gate=cp['gate'],entry_power_exact=cp['entry_power_exact'],residual_lo=dec(left),residual_hi=dec(right),residual_log_length=dec(mp.log(right/left)) if right>left else '0.0',true_residual=dec(val,precision),keep_window_bad_cap=dec(boundB,precision),drop_window_bad_cap=dec(bound0,precision),true_over_keep_bad=dec(val/boundB) if boundB else None,keep_bad_over_drop_bad=dec(weightmean) if weightmean is not None else None,eligible_bad_posterior=eligible,all_terminalbad_posterior=totalbad,R147_cap_relative_difference=dec(change,30)))
  baseline=mp.mpf(row['internal_residual']);reldiff=abs(I-baseline)/abs(baseline) if baseline else abs(I);assert reldiff<mp.mpf('1e-95');return dict(case=cid,id=row['id'],stage=row['stage'],distribution=row['distribution'],n=row['n'],precision=precision,outer_saved_factor_exact=str(outer),true_residual=dec(I,precision),keep_window_bad_cap=dec(UB,precision),drop_window_bad_cap=dec(U0,precision),F_true_residual=dec(mm(outer)*I,precision),F_keep_window_bad_cap=dec(mm(outer)*UB,precision),F_drop_window_bad_cap=dec(mm(outer)*U0,precision),true_over_keep_bad=dec(I/UB) if UB else None,keep_bad_over_drop_bad=dec(UB/U0) if U0 else None,R147_row_relative_difference=dec(reldiff,35),caps=caprows)

def summarize(rows):
 with mp.workdps(180):
  sums={k:sum((mp.mpf(r[k]) for r in rows),mp.mpf(0)) for k in ['true_residual','keep_window_bad_cap','drop_window_bad_cap','F_true_residual','F_keep_window_bad_cap','F_drop_window_bad_cap']};return {'receiver_N':len(rows),'positive_residual_receiver_N':sum(mp.mpf(r['true_residual'])>0 for r in rows),'sums':{k:dec(v) for k,v in sums.items()},'true_over_keep_bad':dec(sums['true_residual']/sums['keep_window_bad_cap']) if sums['keep_window_bad_cap'] else None,'keep_bad_over_drop_bad':dec(sums['keep_window_bad_cap']/sums['drop_window_bad_cap']) if sums['drop_window_bad_cap'] else None,'F_keep_bad_over_drop_bad':dec(sums['F_keep_window_bad_cap']/sums['F_drop_window_bad_cap']) if sums['F_drop_window_bad_cap'] else None}
allrows=coverage['records'];first=[r for r in allrows if r['case']=='I1' and r['stage']=='initial'];pressure=[r for r in allrows if r['case']=='P1' and r['stage']=='pressure'];assert len(first)==2 and len(pressure)==5;keys={(r['case'],r['id']) for r in first+pressure};rest=[r for r in allrows if (r['case'],r['id']) not in keys];phases=[('I1_initial_two',first),('P1_existing_pressure_five',pressure),('remaining_fixed_menu',rest)];records=[];phase_results=[];checks={'receiver_N':179,'cap_N':690,'precision_digits':[100,160],'max_precision_relative_change':'0','max_R147_row_relative_difference':'0','max_R147_cap_relative_difference':'0','nonnegative_and_order_pass':True,'bad_source_structure':'all690 original caps u=G4; one cap per(v,score segment), so no duplicate union in drop-bad cap'}
with mp.workdps(180):
 for phase,rr in phases:
  phase_rows=[]
  for r in rr:
   low=calculate(r,100);high=calculate(r,160);errs=[]
   for k in ['true_residual','keep_window_bad_cap','drop_window_bad_cap','F_true_residual','F_keep_window_bad_cap','F_drop_window_bad_cap']:
    a,b=mp.mpf(low[k]),mp.mpf(high[k]);errs.append(abs(a-b)/abs(b) if b else abs(a))
   err=max(errs);assert err<mp.mpf('1e-70');high['precision_check_max_relative']=dec(err,40);high['low100']={k:low[k] for k in ['true_residual','keep_window_bad_cap','drop_window_bad_cap']};records.append(high);phase_rows.append(high);checks['max_precision_relative_change']=dec(max(mp.mpf(checks['max_precision_relative_change']),err),40);checks['max_R147_row_relative_difference']=dec(max(mp.mpf(checks['max_R147_row_relative_difference']),mp.mpf(high['R147_row_relative_difference'])),40)
   for cp in high['caps']:checks['max_R147_cap_relative_difference']=dec(max(mp.mpf(checks['max_R147_cap_relative_difference']),mp.mpf(cp['R147_cap_relative_difference'])),40)
  pr={'phase':phase,'summary':summarize(phase_rows)};phase_results.append(pr);print(phase,pr['summary'],flush=True)
assert len(records)==179 and sum(len(r['caps']) for r in records)==690
strata={stage+'/'+cid:summarize([r for r in records if r['stage']==stage and r['case']==cid]) for stage in ['initial','pressure','expanded'] for cid in ['I1','P1']}
for cid in ['I1','P1']:strata[cid]=summarize([r for r in records if r['case']==cid])
source_sums=defaultdict(lambda:[mp.mpf(0)]*3);score_sums=defaultdict(lambda:[mp.mpf(0)]*3)
with mp.workdps(180):
 for r in records:
  factor=mm(fr(r['outer_saved_factor_exact']))
  for cp in r['caps']:
   for dest,key in [(source_sums,r['case']+'/'+cp['v_name']+'->'+cp['u_name']),(score_sums,r['case']+'/'+str(cp['score_v'])+'>'+str(cp['score_u']))]:
    for i,k in enumerate(['true_residual','keep_window_bad_cap','drop_window_bad_cap']):dest[key][i]+=factor*mp.mpf(cp[k])
 def pack_sums(d):return {k:{'F_true_residual':dec(v[0]),'F_keep_window_bad_cap':dec(v[1]),'F_drop_window_bad_cap':dec(v[2]),'keep_bad_over_drop_bad':dec(v[1]/v[2]) if v[2] else None} for k,v in d.items()}
 out={'status':'completed_full_time_early_geometry','execution_count':1,'executed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_sha256':hashes,'script_sha256':sha(Path(__file__)),'plan_sha256':sha(ROOT/'early_geometry_plan.md'),'mpmath_version':mp.__version__,'scope':'Whole saved FA residual intervals, same179 receivers; no new kernels/rho/time samples/quadrature or dx coverage. Two upper caps retain original pair windows; no independence assumption.','precision_note':'100/160-digit analytic primitives and exact rational entry powers, not machine intervals for kernels/endpoints/roots.','bad_mass_semantics':'B_v^res=sum_bad alpha_vu Pi_u with original FA residual window; total terminalbad posterior separately includes all saved bad sources, even those outside original positive-score pair. Drop-bad uses v-window union; dataset has one eligible bad source/cap per v and score segment.','checks':checks,'phases':phase_results,'strata':strata,'summary':summarize(records),'source_strata':pack_sums(source_sums),'score_layer_strata':pack_sums(score_sums),'records':records,'elapsed_seconds':time.monotonic()-start}
(ROOT/'early_geometry.json').write_text(json.dumps(out,ensure_ascii=False,separators=(',',':'))+'\n');print('FINAL',out['summary'],'checks',checks,'seconds',out['elapsed_seconds'],flush=True)
