# All-softness compensated split at the original complete smooth FIRST

Status: analytic CS1–10 and all registered three-stage actual-kernel records independently reviewed PASS in compensated_split_review.md. The general compensated partial payment is accepted; no high-trace spatial payment or endpoint is claimed.

## CS1. Exact original event and final remainder

Work after the accepted positive-source C-infinity smoothing reduction and the already paid FIRST physical endpoints. Keep the ORIGINAL complete positive source f, its q in[3lambda/4,lambda], softness sigma and actual interior physical winner L in[a,b], b/a<=2. Then F=P_sigma,L*f(x)=q and its ordinary complete-source physical derivative is zero. The original future cap and every current CP residual qualification are retained; no FIRST is computed on the hi source or a parent restriction. In particular the original softness lower bound implies sigma>=1/(4n). The retained hi source can be nonsmooth and its derivative is never set to zero.

Write Phi_full(x,L) for the HARD PART OF THE FULL PRODUCT derivative, convolved with this smooth complete source. Its normalized shape measure is

    sum_i (1-sigma)|u_i|delta_(|u_i|=1/2)
                   prod_(j!=i)psi_sigma(u_j).

The physical kernel uses the same R^(-n) dilation normalization as P_sigma,R. Thus Phi_full retains every other psi factor and is NOT the pure h-tensor trace; after convolution with the bounded smooth complete source it is the ordinary finite face response at the original L. With the actual regular score S_sigma(u)=sum_i beta_sigma(u_i)|u_i|[-log phi]'(|u_i|), the exact identity is

    0=Phi_full+int P_sigma,L(x-y) S_sigma((x-y)/L)f(y)dy-nq.

This point identity is only used for the smooth COMPLETE source at its original interior maximum. It is not an evaluation of a source-group BV density at a selected cusp.

For large dimensions specified below, split the existing original output set into

    TOP: sigma>1-d_n,
    LOWTRACE: sigma<=1-d_n and Phi_full<=n(1-sigma)q/2,
    HIGHTRACE: sigma<=1-d_n and Phi_full>n(1-sigma)q/2.    (CS1)

Equality belongs to LOWTRACE. The final unpaid quantity is the OLD current CP R* traffic restricted to HIGHTRACE, preserving its original eligible-large-parent condition, original two winners, source-hi, GOOD, far/notLOW/high-marked and balanced weights. No new source traffic is introduced. Paying TOP and LOWTRACE as OUTPUT sets permits deletion of all their original traffic; their fees are charged once in the outer weak ledger, rather than added as new near/LOW/pair fees. No fixed reduction in the old R* is asserted. In smaller dimensions the whole original event is paid by the existing strong envelope as stated in CS5, so there is no new remainder in those dimensions.

## CS2. Actual-kernel moments with explicit constants

The original phi satisfies phi(1/2)>1/5 and |phi'/phi|<=5: inside use phi>=phi(1/2), |phi'|<=1; outside phi is a positive Laplace transform, so its log derivative decreases from the same face value. Since phi=h*w and w is the normalized mixture with density int_0^1 exp(-|u|/t)dt,

    int u² phi(u)du=1/12+1=13/12,
    int exp(c|u|)phi(u)du<=exp(c/2)/(1-c), 0<=c<1.

Put w_sigma(u)=beta_sigma(u)|u|[-log phi]'(|u|). Under the TRUE one-coordinate probability density psi_sigma, including both hard and soft pieces,

    E w_sigma=sigma, E w_sigma²<=25(13/12)<28.       (CS2)

The equality follows from int |u|[-phi'(u)]du=1. For sigma>=1/2, the observable softness score a_sigma=(phi-h)/psi_sigma has mean0 and |a_sigma|<=10, hence E a_sigma²<=100. These are independent-coordinate TRUE PRODUCT-KERNEL identities, not independence of an arbitrary source posterior.

For any sigma in(0,1], 0<t<=1/20, put j_sigma,t=psi_sigma exp[t(w_sigma-sigma)], m_sigma,t=int j_sigma,t. The centered Taylor estimate gives

    1<=m_sigma,t<=exp(3000t²).                     (CS3)

For completeness, |w_sigma-sigma|<=5|u|+1. At t<=1/20, (5r+1)²exp[t(5r+1)]<=1700exp(r/2): use (5r+1)²<=50r²+2 and r²<=32exp(r/4). Both the hard density and phi have E exp(|u|/2)<3. Thus the centered second Taylor remainder is at most2550t²; 3000 is a conservative bound. Jensen gives the lower bound1.

## CS3. All sigma and physical scales of the tilted kernel are paid

Define the positive normalized-score tilt

    Z_sigma,t(u)=prod_i j_sigma,t(u_i)
               =P_sigma(u) exp[t(S_sigma(u)-n sigma)].

The scalar radial BV bound

    ||-j-u j'||_TV<=10000 m_sigma,t                (CS4)

holds uniformly in sigma and t<=1/20, including the hard jump. Here is a direct justification of finite uniform constants. Inside the hard core, w_sigma increases from0 to a value at most5/2, so its weighted radial variation is bounded by (5/4)exp(1/8). Outside, writing H=-log phi gives |r w'|<=r H'+r²(-H''); moreover phi(-H'')<=phi'' there. Integrating r²phi''exp(r/4) twice by parts gives finite face terms and int(2+r+r²/16)phi exp(r/4), bounded using the displayed exponential moment. The term |r psi'| is similarly bounded by5r phi plus the hard face atom. All these bounds are well below10000, while m>=1. At the hard face the tilted inside trace exceeds the outside trace: with a=(1-sigma)/(sigma phi(1/2)), the log outside/inside ratio is -log(1+a)+t s_phi(1/2)a/(1+a)<=0 since t s_phi(1/2)<=1/8. Canonical closed h thus has no unaccounted isolated value.

Here is an explicit conservative certificate for(CS4), rather than an unspecified BV constant. Since j<=psi exp(r/4), the regular psi derivative term is at most5 E_phi[r exp(r/4)]<30; use r exp(-r/4)<=2 and E_phi exp(r/2)<3. The inside t-weighted score-derivative term is at most t exp(1/8)(5/2)<.15, including both signs. For the outside term, double-sided integration by parts at r=1/2 gives

    2 int_(1/2)^infinity r² phi''(r) exp(r/4)dr <3+14=17.

The two boundary terms are at most2exp(1/8)[1/4+17/16]<3, since phi(1/2),-phi'(1/2)<=1. The remaining bulk term is E_phi[(2+r+r²/16)exp(r/4);r>=1/2]<3(2+2+9/16)<14, using r²exp(-r/4)<9. Thus the outside t-term is at most .05(30+17)=2.35. The hard jump mass is at most exp(1/8)<1.14. Including the -j term gives scalar TV<m+34<35m, so the registered10000 constant is amply certified without introducing a factor C^n.

The tilted shape is NOT ray-decreasing. On the inside face phi''(r)=-E1(1/2-r)-E1(1/2+r) tends to minus infinity; w_sigma'(r) tends to positive infinity, whereas psi_sigma'/psi_sigma stays finite. Hence partial_r log j_sigma,t tends to positive infinity for each fixed sigma>0,t>0. Its small rising cusp is integrable and is explicitly covered by the inside score variation bound. A ray-decreasing dilation formula would be invalid here.

Tensorization and the physical FTC yield, for every fixed sigma,

    int sup_(a<=R<=b) Z_sigma,t,R <=[1+10000 n log2] m_sigma,t^n.

There is also an actual pointwise softness comparison, including faces. For sigma>=1/(4n), |a_sigma|<=5/sigma, and inside |partial_sigma w_sigma|=|u|[-phi']h/psi_sigma²<=12.5/sigma²; outside it is zero. Therefore

    |partial_sigma log Z_sigma,t|<=100 n³.         (CS5)

A closed grid on[1/(4n),1] of spacing at most1/(100n³) has at most102n³ nodes and dominates ANY selected sigma pointwise by e times one grid kernel, without changing L or q. Thus the genuine two-parameter strong column is

    int sup_(sigma>=1/(4n),a<=R<=b) Z_sigma,t,R
       <=e(102n³)[1+10000n log2] exp(3000nt²).      (CS6)

This pays both parameters. It does not transfer a fixed-sigma conclusion freely to sigma(x), or use the original future cap on the tilted kernel.

## CS4. LOWTRACE is a true original-W output payment

At LOWTRACE the full-source stationarity identity implies

    int P_sigma,L f [S_sigma-nsigma]>=n(1-sigma)q/2.

Jensen in the ORIGINAL full-source response posterior gives

    Z_sigma,t,L*f(x)>=q exp[tn(1-sigma)/2].        (CS7)

Set A=1000. In the large-dimension regime n>4A²log(n+2), put d_n=A sqrt(log(n+2)/n)<1/2 and t=d_n/12000. Since LOWTRACE has1-sigma>=d_n, positive Tonelli, (CS6), and (CS7) give

    q|E_LOWTRACE|<=e(102n³)[1+10000n log2]
                    exp[-n d_n²/48000] W_full.   (CS8)

The exponential factor is (n+2)^(-A²/48000), with exponent greater20. Thus CS8 is at most an absolute constant times W_full, and in particular costs O(sqrt(n)polylog(n))W_full. No arbitrary source-group mass upper bound is required. Every original source contributes to the convolution and its original W is charged.

## CS5. The complete near-one strip and finite dimensions

For sigma in[1-d,1], d<1/2, true kernel independence and CS2 give

    ||D_logR P_sigma||_TV<=2n(1-sigma)+sqrt(28n),
    ||partial_sigma P_sigma||_1<=10sqrt(n),
    ||partial_sigma D_logR P_sigma||_TV
       <=10sqrt(n) sqrt[28n+n²(1-sigma)²]+5n
                       +n[1+10(1-sigma)sqrt(n)]. (CS9)

The last bound retains both terms. For the regular part, D_logR P=(S-n)P, partial_sigma gives (S-n)Q+sum partial_sigma w with Q=sum a. Cauchy-Schwarz uses E Q²<=100n and E(S-n)²<=28n+n²(1-sigma)². Also int psi partial_sigma w<=5, so that sum costs at most5n. For the hard face measure, differentiating its coefficient1-sigma gives n, while differentiating the other n-1 probability factors contributes at most10n(1-sigma)sqrt(n). No hard trace is omitted or evaluated at a selected face.

A two-parameter FTC in sigma and logR, starting at(1-d,a), integrates the absolute mixed derivative measure in CS9. Its positive envelope includes canonical hard-face traces and obeys

    int sup_(1-d<=sigma<=1,a<=R<=b) P_sigma,R
       <=1+10sqrt(n)d+log2[2nd+sqrt(28n)
          +d{10sqrt(n)sqrt(28n+n²d²)+6n+10n d sqrt(n)}]. (CS10)

For d=d_n this is O_A(sqrt(n)log(n+2)). Thus q|E_TOP| has that exact original-W fee, with no cell, pair, source-depth or mass restriction. This is the FULL parameter strip, not a fixed-sigma BV estimate.

If n<=4A²log(n+2), the accepted full coefficient envelope has mass D<=1+pi sqrt(n)/2 and physical strong constant D(1+2nlog2). It costs at most C A²sqrt(n)log(n+2)W_full in these dimensions; the relation defining this regime absorbs the factor n. This is a general finite-dimension payment, not evidence from a special function family. It covers all sigma, so TOP/LOWTRACE/HIGHTRACE need only be defined in the large regime.

## CS6. Exact effect on the existing residual

On smooth original outputs the union of the two paid output sets has q-fee O_A(sqrt(n)log(n+2))W_full. Multiplying by lambda/q<=4/3 gives its weak-event fee. First delete these output sets from the ORIGINAL event; then apply the existing CP ledger on their complement. Every old nonnegative paid integral only decreases under that output restriction, so each old fee is retained once. The new residual is exactly the original CP R* restricted to HIGHTRACE in CS1; in particular its hardeligible parent still has the strict BT+PA high-source-mass qualification, and that mass is not relabelled as captured mass. This is OUTPUT deletion followed by restriction of the old ledger, not an unproved direct conversion of the TOP/LOWTRACE portions of R* into lambda|E|. The old balanced or mixed source fees are not duplicated on those deleted rows.

The original arbitrary L1 problem is still handled through the accepted smooth-source weak transfer. We do not assert convergence of this auxiliary trace selector under smoothing, only the uniform paid-set bound for each smooth source and the still-unpaid smooth high-trace residual. Proving a uniform bound for that latter residual would be sufficient for the weak-limit passage; it is not proved here.

This is a proposed general compensated partial split, not closure of high compensation. No rare-event claim for HIGHTRACE, positive absolute-flux fee, group derivative zero, lossless source restriction or final endpoint follows from these formulas.

## CS7. Numerical scope and provenance

The pre-execution registration tests the actual phi, psi, score and their derivatives, hard face jumps, centered tilt moments, and complete product moment inequalities in three stages. Large tensor dimensions use exact product-kernel algebra from one-dimensional integrals. This is not source posterior independence, an actual-FIRST realization, or a numerical spatial norm. Positive omitted radial tails are bounded analytically rather than floored to zero. The numerical quadrature is not an interval certificate; all claimed orders must be established by CS1–10 and an independent audit.

All three registered stages completed and pass. There are27 one-coordinate softness rows and108 saved tilt records, plus14 tensor-moment rows. The four large-regime rows have n=268435456 and d_n<1/2; only sigma=1-d_n is away-band eligible, while the other three check near-one mixed moments and tilted-kernel ingredients. Their saved Chernoff fee fields are formula diagnostics, not actual-away/FIRST qualifications; next_compensated_scope.json makes this explicit without rewriting executed records. Mass/regular-score-mean errors are at most1.56e-14, the maximum scalar tilted radial-TV upper is2.000604<10000, and the maximum observed-score mixed CS9 log ratio is below-2.26. Canonical tilted hard jumps are nonnegative, including equality at sigma1. The positive centered exponential remainder uses exact analytic probability mass1 and mean0, rather than numerically recentering or renormalizing a truncated density. The omitted positive exponential tail remains explicit in each saved record. The results embed the frozen registration and executed script hashes; results SHA256 is77d53eca8e4e5b580a908d083c5bb892593badb275bcec149003704b78bd9d92. These checks pressure actual full-kernel ingredients, not an actual source FIRST or an operator norm.
