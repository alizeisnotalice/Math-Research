# R148：共同来源时间预算与连续 soft/尺度包络的联合付款

状态：取得一个新的任意输入根阶对数子支付款。主结论是 CAP7–CAP10 的分段门；它严格保留原共同 ν、Q* 三核、ρ、α 和真实接收 dx。R147 的整窗预算定理及历史 CS10 是已证工具，本稿不重证或重登记它们。端点筛查仅置于末节，未用必要条件外放松否定 FULL 问题。

## 1. 精确待证命题与范围

固定原有限合法截断和一条固定绝对比例带 [a,b]，b/a≤2。使用 R147 原合同：

\[
Q_x(v)=\tfrac13\{P_{s,L}(x-v)+P_{s,L^+}(x-v)+P_{1,b}(x-v)\},
\quad \mu_x(dv)=Q_x(v)\nu(dv)/q,
\]
\[
r_t(v)=\frac{KQ_x(v)}{p(x-y)w_t(v)},\quad
L_g=\frac{Kq}{p(x-y)e_g}\le\tfrac12,
\quad E_+=S_g\cap\{\rho>0\},\quad m=\mu_x(E_+).
\tag{CAP1}
\]

这些均为同一实际行 (ω,V,j,x,y) 的原值。E₊、ρ、m、Lg 和所选 s、L 在该行内部时间与外 hard 来源 z 积分前固定。m=0 为零正交通；其余零商沿原零交通约定。ν 可任意相关，β 始终为原外测度。设 d=1−s，N₀=2n+3。令 Ω₀ 为 R147 主门付款以前的原未付正域，保留 high、FIRST、原 Ψ/FA、low-c、history、good/bad、原 hard 资格及全部既有付款补集。R147 已付的是 Ω₀∩{r_t≥2N₀Lgmρ}。

**本轮命题：** 构造只依 n 和实际 softness s 的分段 Nₙ(d)≤N₀，使

\[
\Omega_{\mathrm{new}}
=\Omega_0\cap\{2N_n(d)L_gm\rho\le r_t<2N_0L_gm\rho\}
\tag{CAP2}
\]

的原完整交通具有显式 O(Λ√n log(2+n))Wβ 费用。本轮不要求、不声称 Ω₀ 中所有行的完整来源时间帽为 O(1/n)。

## 2. 唯一使用的两个已证工具及历史去重

R147 q_capacity.md 的固定预算密度定理：在每条实际行，a(v)≥0 整窗固定、∫E₊a dμ≤1，则门 ρ/r_t≤a/(2NLg) 的整份两来源和时间正交通≤1/(2N)。本稿始终只选 a=1/m；N 在每个 softness 层为一个共同常数，不为每个来源或时间另取容量。原 hard 帽 16/3 随后给 8/(3N)。

历史文件 `/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/high_marked_cover/next_spatial_compensated_split.md` CS9–CS10 及同目录 `compensated_split_review.md` 第3节已经证明真实核的连续二参数包络，含硬面跳跃的两项，量词为 0≤D<1/2、任意固定 y 和 b/a≤2：

\[
\begin{aligned}
\mathcal E_n(D)&:=\int\sup_{1-D\le s\le1,\ a\le L\le b}
 P_{s,L}(x-y)\,dx\\
&\le1+10\sqrt nD+\log2\bigl[2nD+\sqrt{28n}\\
&\hspace{25mm}+D\{10\sqrt n\sqrt{28n+n^2D^2}+6n+10nD\sqrt n\}\bigr].
\end{aligned}
\tag{CAP3}
\]

这是完整连续选择器包络，不是固定 s 或固定 L 的积分。原 TOP/LOWTRACE 输出删除和其他旧付款继续保留；尤其不能将 TOP 已付带重登记为新覆盖。本轮仅将 CAP3 与 R147 新的整窗共同预算按 softness 共同分层。所检查历史已有 CAP3、R147 时间定理，但没有将此组合当作旧独立付款；创新范围只限 CAP2 与下面的全价。

令 A=√nD。将 CAP3 中各项准确换写，得

\[
\mathcal E_n(D)\le\sqrt n\{1+10A+
\log2[\sqrt{28}+8A+10A\sqrt{28+A^2}+10A^2]\}.
\]

用 √(28+A²)≤√28+A、√28<5.3、log2<0.7，有

\[
\boxed{\mathcal E_n(D)\le\sqrt n(5+53A+14A^2)
\le32\sqrt n(1+A)^2.}
\tag{CAP4}
\]

常数 32 绝对、与 n、来源及物理尺度无关；没有将硬面项或接收选择费用省略。

## 3. 按 softness 固定分层并选择时间预算

n<64 时置 Nₙ(d)=N₀，故本轮新增域为空，不另收费。以下 n≥64。定义

\[
K_n=\left\lceil\log_2(\sqrt n/4)\right\rceil,
\qquad D_k=\min\{2^k/\sqrt n,\,1/4\},\quad0\le k\le K_n.
\tag{CAP5}
\]

互斥带为 I₀=[0,D₀]，I_k=(D_{k−1},D_k] (1≤k≤Kₙ)，及 I_far=(1/4,1]。所有近 soft 带上端均≤1/4<1/2，CAP3 可直接适用；等号归属明确。在 d∈I_k 上取

\[
N_k=(1+\sqrt nD_k)^2,
\qquad
N_n(d)=\begin{cases}N_k,&d\in I_k,\\N_0,&d>1/4.\end{cases}
\tag{CAP6}
\]

因为 D_k≤1/4，有 N_k≤(1+√n/4)²<N₀。因而每个新带的付款门都包含 R147 主门；本轮只收费其与 R147 严格补集的交集 CAP2。far 带的新增交集为空。

固定 actual s 之后 k 唯一，N_k 不随内部时间、v、u 或 z 改变。对各个不同层使用同一 μ 并不意味着将一份来源容量无价花多次：每层下面单独付一次完整费用，总层数显式相加。

## 4. 原完整外账的每层及总费用

在固定 k、实际 (ω,V,j,x,y) 和合法原时间窗中，R147 定理以 a=1/m、N=N_k 给来源时间帽 1/(2N_k)。额外的原门和 R147 未付补集只缩小正交通。证明中对每个 z 放松这些额外正门，但保留原 aω；原 hard 帽给 8/(3N_k)。到此已经完成原 dt/t 与三份来源积分，不能再乘 log2。

此时才合并原唯一 j：Σ_j1_{j(x)=j}≤1。虽然原参数及来源预算随实际 x,j 改变，消源后的数值帽 8/(3N_k) 对同层全部行一致，所选 p 则逐点由
sup_{1−D_k≤s≤1, L∈[a,b]}P_{s,L}(x-y)
支配。于是以 P_new,k 表示未乘 2Λ 的原该层新增正交通，

\[
\begin{aligned}
2\Lambda P_{\mathrm{new},k}
&\le\frac{16\Lambda}{3N_k}\mathcal E_n(D_k)W_\beta\\
&\le\boxed{\frac{512}{3}\Lambda\sqrt n\,W_\beta}.
\end{aligned}
\tag{CAP7}
\]

这里 β 没有换成 ν，实际 dx 用 CAP3 支付。原 common α 留在同一个 ρ 内，未优化每源 α，未再次领取任何负账、futurebad 或 Ndel。j 在来源和整窗尚未消去前没有被免费删除。每一固定绝对比例带按原 Wβ 台账处理；本稿不授权跨尺度带无价求上确界。

令

\[
B_n=\begin{cases}0,&n<64,\\1+\lceil\log_2(\sqrt n/4)\rceil,&n\ge64.\end{cases}
\]

对互斥带求和得到新增的一般付款

\[
\boxed{2\Lambda P_{\mathrm{new}}
\le\frac{512}{3}\Lambda B_n\sqrt n\,W_\beta.}
\tag{CAP8}
\]

旧 R147 48Λ√n 费用只保留一次。将它和新增互斥域合并，原完整分解变为

\[
\boxed{2\Lambda P(\Omega_0)
\le\left(48+\frac{512}{3}B_n\right)\Lambda\sqrt n\,W_\beta
+2\Lambda P(\Omega_0\cap\{r_t<2N_n(1-s)L_gm\rho\}).}
\tag{CAP9}
\]

Bₙ=O(log(2+n))，故这是根阶对数价格。若某层已被旧 TOP 输出删除而为空，实际可不计该层；CAP8 只给不依赖这类额外节省的统一上价。

## 5. 几何门、等价形式与真实覆盖

主交付为 CAP6 的锐分段门，而非一个被大常数弱化的统一替代。每层门均有原核的准确等价式

\[
\boxed{Q_x(v)e_g\ge2N_n(1-s)\rho(v)w_t(v)
             \int_{E_+}Q_x(w)\,d\nu(w).}
\tag{CAP10}
\]

q、p、K 在门中代数消去，真实三核、共同来源质量、终端 e_g、当前 w_t 和共同 ρ 仍完整保留。所获节省来自实际接收几何：连续参数带的费用为 √n(1+√nD)²，恰由同行整窗预算 N_k 消去。它不是将剩余积分重新命名为能量或假设所有行小。

在第一带 N_k=4，而 R147 是 N₀=2n+3；在后续带 d≤D_k≤2d，

\[
N_k\le(1+2\sqrt n d)^2\le8(1+nd^2).
\]

far 带 N₀≤35(1+nd²)，小维 n<64 时 N₀≤131。故一个较保守的全域充分门是

\[
\boxed{r_t(v)\ge262\,[1+n(1-s)^2]L_gm\rho(v).}
\tag{CAP11}
\]

它包含于 CAP9 已付的分段门，不另收费。不要将 CAP11 的较窄覆盖替代 CAP6 再声称相同精度，也不要把全 s 包络免费当作 √n。

未覆盖部分准确为 CAP9 最后项；near-soft 带的阈值已从 N₀ 降至 N_k，far 带仍是原阈值。不存在一般定理断言这个新补集为空。原负项和非本合同资格的台账项保持原位。本稿没有运行新数值或以有限样本宣称全窗覆盖。

## 6. 简短端点筛查：为何转向接收几何

仅对“用 R147 固定预算密度直接收完原早时补集”的策略，可给准确必要且充分预算。对每个 v，令 S_v 为该原补集上实际正交通出现的时间集（先对原 u,z 非负核积分，保留所有原门，取 dt/t 意义的正支撑）；定义 z_on(v)=ess sup_{t∈S_v}ρ(v)/r_t(v)，空集置0。覆盖该正支撑所需最小固定密度是 a_min(v)=2N₀Lg z_on(v)，故最小预算为

\[
\mathcal B_{\min}=2N_0L_g\int z_{\mathrm{on}}\,d\mu
=\frac{2N_0}{e_g}\int\rho(v)w_{t_{\mathrm{on}}(v)}(v)\,d\nu(v).
\tag{CAP12}
\]

最后一式将单调连续 w 在实际首时的单侧值作为记号；没有首时的来源置0。原 FA 低门 r<K B_FA δ 只限制正时间支持，不自动给 CAP12≤1。若 E₊ 的每个来源均有正测度早时补集，则该集上 z_on>1/(2N₀Lgm)，从而 B_min>1：原 uniform 预算的剩余不能仅由另一份总量≤1的固定密度全收。

一个必要约束层的端点检查说明为何不能冻结 Lg 后追逐统一 1/n 行帽。取 n≥2、τ=1、g=2、h=2e^{-1/n}，两源 w_t(v)=t^{-n}、w_t(u)=1，ν_v=2^n、ν_u=3；取 p=K=1、q=2、Q_v=2^{-n}、Q_u=1/6、ρ_v=1/2。则 μ总=3/4、Lg=1/2、m=1/2，terminal good r_g(v)=1、bad r_g(u)=1/6，高门等号；整个时间窗 r_t(v)<N₀/4 均在旧补集。若 B_FA n>1，FA 低门也成立。保留真实 L_t 的源时间通量恰为

\[
\frac12\left[\frac{2^n}{2^n+3}-\frac e{e+3}\right]
\longrightarrow\frac3{2(e+3)}>0.
\]

它不是原三核、α/history、hard 接收几何的 FULL 实现：Q 数值和 ρ 在此仅满足必要约束，不能当作原一般输入反例。真实 Q 的位置耦合并未由这个模型检验。CAP3–CAP10 正是本轮保留真实核后得到的可积接收上帽；它绕开上述逐行要求，付出了明确的 logarithmic 层数，并留下 CAP9 的更小实际补集。
