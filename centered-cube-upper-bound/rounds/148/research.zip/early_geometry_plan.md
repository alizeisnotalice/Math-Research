# R148 early_geometry 执行前冻结协议

仅写early_geometry_plan.md、early_geometry.py/json/notes.md（本work）；不改其他agent/旧数据、无Git/PDF。用R147完整时间结果同179receiver，不新增核/ρ/接收或time采样，不作dx覆盖或一般阶数结论。

## 绑定输入和顺序

读取rounds/147/research.zip中的time_coverage.json（member SHA589b2a37ffca9a5c0a801c435c8d4918f0fd6a1d16fec519ef2dc088cbf3c0de），不解压写其他文件。另读旧output R136 active_traffic_v2.json SHA1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de，R142 numeric_receiver.json SHAc46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55，R143纯primitive脚本SHAeda566f1d7a622788a4fc863cde6f31ad8cdb3808f1da0c29f52ad126d8d6521。R142只选择原179行，质量始终其nu_exact。旧核、原good/bad/Psi/rho、所有原FA cap不重选。

先2条I1原initial真实残余receiver（83、244），再5条P1原pressure（原残余为0的控制），再其余172条，不以初步结果追加或换菜单。全菜单沿原stage/distribution汇总。

## 完整残余时间对象

R147每cap给原effective_lo/hi、gate full/partial/empty及exact entry power。用相同精确有理entry power重新求根，残余早窗为[lo,entry]（partial）、全原FA窗（empty）、空（full）；不用打印的entry近似替代。原FA/Psi/score测试逐cap核对，保留所有零残余条，不改端点。

令alpha_vu(t)为该pair原FA与R147残余窗指示，Pi_i=nu_i w_i/e，k_i取原score段。主量：
I=∫Σvu alpha_vu ρv (kv−ku)+ Pi_v Pi_u dt/t；
U_B=∫Σv ρv kv Pi_v B_v^res(t) dt/t，B_v^res=Σbad u alpha_vu Pi_u；
U_0=∫Σv ρv kv Pi_v 1_{至少一个原pair残余窗开启} dt/t。

即先保留原pair窗口的bad后验质量，再用该窗口化bad质量<=1删掉。若多bad窗重叠，U0必须按v/score段的窗口union只积一次，不能逐pair重复丢掉Pi_u。已检查本输入690cap的bad均G4，非零残余仅I1 G1/2/3→G4及P1 farB→G4；执行仍核此结构，否则保留失败而不猜新primitive。

另报告原terminalbad总后验Pi_Btotal（包含未通过pair正δ/FA的其他bad源）与窗口eligible B_v^res的区别。不得把I1 bad far B漏掉后说bad总质量小。给bad源、score(kv,ku)、残余时间长度、端点/驻点后验范围，以及U_B/U0（U0权下窗口bad平均）与I/U_B（δ→kv损失）。所有都用真实共同e(t)，不将nu小误当后验小。

## 解析方法及误差

真I复用R147同R142/R143两score和三score原函数，U_B在每pair为(kv/delta)*I（相同窗口），不重新求积。U0仅需本模型high-score v：两score e=A t^(−d)+B时，∫kv Pi_v dt/t=(nu_v c_v/A)log[e(lo)/e(hi)]（本输入kv=d、低score0）；三score k={0,d,2d}、u=t^d、P=A+Bu+Cu²时，∫kv Pi_v dt/t=2nu_v c_v∫du/(uP)。后一原函数为(2nu_v c_v/A)[log u−.5logP−.5B H(u)]，H'=1/P，按4AC−B²的log/atan/rational分支实现。禁止把舍入相近值相减后无检查置零。

原bad后验总质量和eligible质量是线性/二次有理比，范围从端点及导数驻点解析求得，非网格抽样；同score段阈值单侧约定沿R147。100/160位完整闭式独立运行并报告相对变化；真I与R147 row/cap残余校核，U_B>=I、U0>=U_B和非负性校核。多精度相合不是kernel/根/原FA的区间证书。

保存每cap原区间/entry power引用、坏源和score分解、三个完整时间积分及两份原posterior质量范围，按case/stage/distribution/source/score层输出。可乘R147保存外因子p hardmass/q作原有限receiver记录sum的对照，但不混同dx或积分权。不得只报点值代替完整时间积分。一次脚本可重建全部输出，UTC/elapsed除外。完成停止。
