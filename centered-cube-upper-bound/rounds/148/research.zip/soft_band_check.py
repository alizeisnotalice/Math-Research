#!/usr/bin/env python3
"""Exact finite arithmetic checks for the declared dyadic soft-band strategy."""
from fractions import Fraction as F
from pathlib import Path
from math import isqrt,sqrt,log,factorial
import json,hashlib,time,datetime
ROOT=Path(__file__).resolve().parent
DEN=2**120

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def brackets(n):
 q=isqrt(n*DEN*DEN);lo=F(q,DEN);hi=lo if q*q==n*DEN*DEN else F(q+1,DEN);assert lo*lo<=n<=hi*hi;return lo,hi

def endpoint(kind,value=None):return dict(kind=kind,**({'value':value} if value is not None else {}))
def interval(e,n):
 if e['kind']=='rational':return e['value'],e['value']
 assert e['kind']=='sqrt_n_over_4';l,h=brackets(n);return l/4,h/4

def near_bands(n):
 assert n>=64;limit2=F(n,16);lower=F(0);upper=F(1);out=[];first=True
 while True:
  end=endpoint('rational',upper) if upper*upper<=limit2 else endpoint('sqrt_n_over_4');beg=endpoint('rational',lower);loA,hiA=interval(end,n);Nlo,Nhi=(1+loA)**2,(1+hiA)**2;boundactual=8*(1+lower*lower);assert Nhi<=2*n+3 and Nhi<=boundactual
  out.append(dict(lower=beg,upper=end,left_closed=first,right_closed=True,A_upper_bracket=[loA,hiA],N_bracket=[Nlo,Nhi],N0=2*n+3,N_le_N0=True,N_le_8_actual_one_plus_nd2=True,exact_bound_at_lower=boundactual))
  if end['kind']=='sqrt_n_over_4' or upper*upper==limit2:break
  first=False;lower=upper;upper*=2
 assert out[0]['lower']==endpoint('rational',F(0)) and out[0]['left_closed']
 for a,b in zip(out,out[1:]):assert a['upper']==b['lower'] and a['right_closed'] and not b['left_closed']
 last=out[-1]['upper'];assert last['kind']=='sqrt_n_over_4' or last['value']**2==limit2
 assert all(interval(x['lower'],n)[1]<interval(x['upper'],n)[0] for x in out)
 # Positive intervals with a radical last endpoint require an exact squared comparison too.
 for x in out:
  if x['upper']['kind']=='sqrt_n_over_4':assert x['lower']['value']**2<limit2
 return out

def diag_cs10(n,A):
 sn=sqrt(n);d=A/sn;env=1+10*sn*d+log(2)*(2*n*d+sqrt(28*n)+d*(10*sn*sqrt(28*n+n*n*d*d)+6*n+10*n*d*sn));return env/(sn*(1+A)**2)
def one(n,stage):
 row=dict(stage=stage,n=n,N0=2*n+3,small_dimension=n<64,sqrt_n_bracket=brackets(n),domain_d='[0,1)',near_bands=[],partition_exact=True,uniform_262_gate_inclusion=True)
 if n<64:assert 2*(2*n+3)<=258;row['fallback_domain']='[0,1)';row['fallback_2N_le_262']=2*(2*n+3)<=262
 else:
  row['near_bands']=near_bands(n);row['near_domain']='[0,1/4]';row['far_domain']='(1/4,1)';row['far_2N0_le_64_one_plus_nd2']=4*n+6<=4*n+64
  for b in row['near_bands']:
   A=float(interval(b['upper'],n)[0]);b['CS10_ratio_float_diagnostic']=diag_cs10(n,A);assert b['CS10_ratio_float_diagnostic']<32
 return row

def encode(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {str(k):encode(v) for k,v in x.items()}
 if isinstance(x,list) or isinstance(x,tuple):return [encode(v) for v in x]
 return x

def main():
 started=time.monotonic();stages=[('initial',[1,4,16,64]),('pressure',[63,64,65,255,256,257]),('expanded',[2**k for k in range(6,41)])];taylor=sum((F(7,10)**k/factorial(k) for k in range(5)),F(0));assert taylor>2 and F(6)**2>=28;coeff=[F(26,5),F(288,5),F(14)];target=[F(32),F(64),F(32)];assert all(a<=b for a,b in zip(coeff,target));assert 16<=262 and 64<=262 and 258<=262
 rows=[one(n,stage) for stage,ns in stages for n in ns];bs=[b for r in rows for b in r['near_bands']];out=dict(status='completed_exact_arithmetic',execution_count=1,scope='Declared soft-band arithmetic/partition/gate checks only; no original179 traffic/kernel/TV/FULL proof',script_sha256=sha(Path(__file__)),plan_sha256=sha(ROOT/'soft_band_check_plan.md'),sqrt_enclosure_denominator=str(DEN),symbolic_certificate=dict(log2_upper=F(7,10),positive_exp_taylor_lower=taylor,CS10_Env_over_sqrtn_polynomial_coefficients=coeff,target_32_one_plus_A_squared_coefficients=target,coefficientwise_domination=True,near_2N_comparison_coefficient=16,far_2N_comparison_coefficient=64,small_max_2N=258,uniform_comparison_coefficient=262),records=rows,summary=dict(stage_dimension_counts={k:len(v) for k,v in stages},dimension_records=len(rows),unique_dimensions=len(set(r['n'] for r in rows)),near_band_records=len(bs),max_bands_per_dimension=max(len(r['near_bands']) for r in rows),all_exact_checks_pass=True,original_receiver_traffic_recomputed=False,CS10_max_float_diagnostic_ratio=max(b['CS10_ratio_float_diagnostic'] for b in bs),CS10_diagnostic_only=True),elapsed_seconds=time.monotonic()-started,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(ROOT/'soft_band_check.json').write_text(json.dumps(encode(out),ensure_ascii=False,indent=2)+'\n');print(json.dumps(out['summary'],indent=2));print('seconds',out['elapsed_seconds'])
if __name__=='__main__':main()
