# R148 optimal fixed-source budget on original full FA time

The original179 receivers were retained, with originalρ,Q,ν,terminal E+,Ψ,FA intervals and full six-source e_t unchanged. All source allocations are fixed for the entire time window and all inner bad/outer hard sources. The computation used the approved exact model, not the main author's flux-relaxation bound.

Results:

- P1: all168 receivers have a rational feasible allocation covering100% of their original accepted FA time. Their largest full-coverage budget is.0121847588892412<1. This is an exact domain-inclusion certificate, so the optimum is exactly whole traffic without evaluating a new transcendental objective.
- I1: all11 receivers require more than budget1 for complete coverage. Exact active-set optimization still leaves positive traffic. Each row's rational feasible lower bound and rational tangent upper bound coincide exactly, giving a certified finite-model optimum, not a floating optimum assertion.
- Every I1 optimum allocates b_G1=1 and b_i=0 to the other sources. Equivalently a_G1=1/μ_G1 and other a_i=0. This is one fixed source strategy, not a time-dependent choice. It improves coverage, but does not remove the early-time residual.

I1 finite-record weighted residual decreases from18.2802477333% under uniform a=1/m to16.6581867382% at the certified optimum. Over all179 archived finite-record weights, the display ratio changes from18.2800335896% to16.6579915961%. Aggregate values use archived high-precision whole-F weights and are finite-record diagnostics, not dx integrals. Per-I1 objectives, optimum values and all bounds are exact rational numbers for the saved model.

## Exact budget and why full coverage fails

Let μ_i=Q_iν_i/q, b_i=μ_i a_i, N=2n+3, and L*=Lg. The original allocation gate is equivalent to

`b_i ≥ d_i(t)=2Nν_iρ_i w_i(t)/e_g`,  with Σ_{E+}b_i≤1.

The code checks this equality against the unreduced Q,q,p,K expression. Full E+ is retained; a source with zero accepted FA traffic may have a_i=0 under the original allocation theorem. Such zero allocation does not delete its ν mass, contribution to e_t, originalρ or terminal membership. In particular all six sources remain in every denominator even when only G1 is allocated budget.

Since w_i is nonincreasing, exact minimum budget for full measure coverage is

`B_full=Σ_i max_{original positive FA intervals of i} d_i(lo)`.

For a source without accepted traffic this maximum is0. At budget below this value, at least one source misses a positive-length part of an accepted interval (all accepted integrands are positive inside the finite model); equality at an endpoint itself has no mass. I1's B_full ranges from1.07715016423 to1.25202785049. Thus its whole-time failure cannot be explained solely by choosing uniform allocation poorly. The particular optimal residual remains positive even after allowed budget redistribution.

## Certification of the true I1 objective

All11 I1 rows were checked to have at most3 accepted source channels, one FA cap per source, in a two-score segment with scores{0,4}. Set z=t^-4, e=A z+B, and d_i(t)=D_i z with D_i=2Nν_iρ_i c_i/e_g. For cap[lo,hi], activation l_i=D_i hi^-4 and full-cover cost u_i=D_i lo^-4. Original outer-weighted traffic covered by budget b is0 below l_i, constant above u_i, and between them exactly

`f_i(b)=R_i(b−l_i)/(A b+B D_i)`,

where `R_i=(p hardmass/q)ρ_iν_iν_bad c_i c_bad/(A hi^-4+B)`.

This retains the true FA interval, original pair weight and full e_t² denominator. Its derivative is `R_i(A l_i+B D_i)/(A b+B D_i)^2>0`; second derivative is negative. The positive activation kink means the whole function is not globally concave.

The code enumerates all8 active source subsets for every I1 row. Budgets below activation can be replaced by0 without decreasing coverage, and budgets above full-cover cost can be truncated without decreasing coverage. Thus these boxes cover a global optimum. Each active box has bounds[l_i,u_i] and Σb≤1. A floating calculation proposes a point only; it is converted to rational numbers, clamped and adjusted to make the original budget feasible exactly. Its true rational objective supplies a lower bound.

At this rational point each active f_i has an exact supporting tangent. The maximum of their summed linear functions over the same box and budget is solved by exact rational bounded knapsack (descending slope). This supplies a rigorous upper bound for that box. Taking maxima over all boxes gives global bounds. Every I1 global upper equals its feasible lower exactly, with Fraction gap0. All tangent slopes, intercepts, box candidates and linear maximizers are saved; the certificate does not rely on the floating optimizer's status or numerical tolerance.

The uniform a=1/m objective is also evaluated by this exact formula. Its rational whole/covered values agree with archived R147 high-precision values to better than the frozen relative1e−60 threshold. No primitive was reinvented: the rational formula is the same two-score primitive already used by R142/R143/R147, with gate entry expressed directly in z/b. P1 optimum certification needed only monotone endpoint inclusion, so no new primitive evaluation was necessary.

## I1 complete row results

All rows choose b=(1,0,0,0,0,0) and spend exactly1. Percentages are display values; their rational values are in JSON.

|I1 id|original stage|full-coverage budget|uniform residual %|certified optimal residual %|upper−lower|
|---:|---|---:|---:|---:|---:|
|83|initial|1.14435023076|15.47486083|14.00203466|0|
|244|initial|1.25202785049|25.75828683|23.77438704|0|
|501|expanded|1.14379412794|15.41289057|13.95392989|0|
|513|expanded|1.07715016423|8.604757174|7.419857005|0|
|1015|expanded|1.21258682615|22.1151305|20.28688739|0|
|1392|expanded|1.2020719011|21.12700643|19.33639073|0|
|1568|expanded|1.14781548598|15.84572321|14.31788063|0|
|1877|expanded|1.19739013536|20.65127314|18.93185034|0|
|2117|expanded|1.12105324417|13.12561875|11.76642525|0|
|2150|expanded|1.16116665329|17.13601947|15.59395676|0|
|2152|expanded|1.22375993762|23.1436865|21.29822755|0|

For example I1 id244 improves residual25.7582868307%→23.7743870384%, and id513 improves8.60475717434%→7.41985700510%. The early-time obstruction survives the best allowed fixed source allocation.

## Three original stages

No new expansion was invented: the original initial, pressure and expanded menus were processed in order.

|original stage/case|records|full coverage feasible|uniform residual %|certified optimum residual %|
|---|---:|---:|---:|---:|
|initial/I1|2|0|20.90006401|19.15761191|
|initial/P1|25|25|1.601873869e-15|0|
|pressure/I1|0|0|—|—|
|pressure/P1|5|5|0|0|
|expanded/I1|9|0|17.67593319|16.08164288|
|expanded/P1|138|138|8.094572965e-16|0|

P1's uniform residual was already extremely small and entirely from the B channel; the newly feasible full allocation covers that remainder as well. Its optimum100% is exact in the saved model, despite the original remaining contribution being numerically tiny. No receiver is unresolved.

## Reproduction, execution and scope

The standard-library-only producer ran once, without error, in about.66 seconds. It reads R147 research.zip members directly and references the existing R136/R142 inputs; no archived input was copied into the delivery. `--archive` and `--input-root` allow portable references. Archive/member/input/script/plan SHA256 and the actual strategy are saved in JSON. The four owned files are the only outputs.

The result is a certified optimum for fixed per-source allocations in this frozen finite FA/time model. It does not establish an optimal strategy for arbitrary continuousν or a common source formula across different receiver rows, does not change any original allocation theorem constants, and does not give a dx/global/root-order bound. A budget concentrated on G1 is only a finite-row optimizer; it is not a new general paid selection rule without the original measurability and full budget theorem. The positive I1 optimum residual is an explicit remaining task, not hidden under the improved allocation. Delivery complete; work stops.
