# R148 fixed-source-budget true-FA coverage protocol (frozen)

Own optimal_budget.py/json/plan.md/notes.md only. Read R147 research.zip members directly (time_coverage.json, numeric_margin.json and source proof metadata), and reference existing R142/R136 inputs by path; do not copy historical inputs into this delivery. No Git, new receiver/time sampling, kernels or change to originalρ,Q,ν,e_t,E+.

The parent approved the following exact model before execution. Each of the same179 original receivers receives one whole-window fixed source allocation a_i≥0 with Σ_{E+} μ_i a_i≤1, μ_i=Q_iν_i/q. N=2n+3,L*=Lg. The objective is the original accepted FA/Ψ pair traffic over complete saved time, covered by r_i(t)≥2N Lgρ_i/a_i; a_i=0 means empty gate. An allocation cannot vary with time, inner bad source or outer hard source. Full E+ is retained, including zero-traffic CORE; zero allocation is allowed by QC4, not a deletion or renormalization. Define b_i=μ_i a_i. The identical gate is

`b_i ≥ d_i(t)=2N ν_iρ_i w_i(t)/e_g`,   Σb_i≤1.

Common p,q,K,Q cancellation is checked, not used to replace original fields. Every reported source strategy includes a_i,b_i and its exact budget, fixed across all original FA caps of that receiver.

## First exact test: whole coverage

For every accepted source i, b_full,i=max over its original positive FA intervals of d_i(lo). Since w_i is nonincreasing, this is the exact smallest budget allowing full measure coverage of all those intervals. For sources with no accepted FA traffic use b_full=0 while retaining them in E+. If Σb_full≤1, choosing those b proves the true coverage optimum is100% by nonnegative objective monotonicity. If Σb_full>1, complete coverage is impossible in this frozen model; do not label another feasible allocation “optimal” without a bound.

Use original score domains intersected with saved FA_caps exactly as R147 (all are rational inputs). Compare to R147 uniform a=1/m (m=μ(E+)) on the same exact saved model. For full-feasible rows, the coverage certificate is domain inclusion, so no transcendental integration is required to certify the fraction1; archived R147 whole/paid numbers are only displayed as baseline diagnostics.

## I1 true-objective rational optimization when full coverage is infeasible

I1's accepted traffic has one cap per positive-traffic source, all in the two-score segment. Verify this structure before using it. Let z=t^-4, e=A z+B and d_i(t)=D_i z, D_i=2Nν_iρ_i c_i/e_g. For cap[lo,hi], l_i=D_i hi^-4 and u_i=D_i lo^-4. Its outer-factor-weighted covered value is0 for b<l_i, full for b≥u_i, and on[l_i,u_i]

`f_i(b)=R_i (b−l_i)/(A b+B D_i)`,

`R_i=(p·hardmass/q)ρ_iν_iν_bad c_i c_bad/(A hi^-4+B)`.

This is increasing concave on the active interval, with exact derivative R_i(A l_i+B D_i)/(A b+B D_i)^2. Its activation kink forbids treating the whole function as globally concave. Enumerate all active source subsets (at most8 after structural verification), assigning inactive b=0 and active b∈[l,u]. Skip subsets whose lower budgets exceed1.

For a subset, a floating bisection/water-fill calculation may suggest a candidate only. Convert it to rational b, clamp exactly to[l,u] and adjust to Σb≤1. Evaluate the actual feasible objective exactly to get a lower bound. At that rational point, concavity gives exact rational tangent lines. Maximize their sum over the same box and resource constraint by an exact rational linear knapsack sorted by tangent slopes; this is an upper bound on the subset's true optimum. Max over subsets gives a global certified sandwich. Record every subset candidate, tangents, linear-max allocation and bound; target relative gap≤1e−10 of whole. If not met, report the larger certified gap rather than asserting optimality. A full-feasible subset is solved exactly.

For a P1 row that is not full-feasible, do not silently substitute a different relaxed objective: retain certified upper=whole and a feasible original uniform allocation lower only if its true integration can be enclosed. If unresolved, explicitly report the row as unresolved; no unsupported optimum claim.

## Three original stages and fixed menu

Process all original initial records (I1=2,P1=25), pressure records(P1=5), expanded records(I1=9,P1=138), preserving every original distribution and id. No invented expansion, random search or replacement of the true FA/e objective by the main author's flux relaxation. Within each stage run the full-budget test before any I1 optimizer.

Save exact rational full-coverage costs, all allocations and I1 certificates, comparisons with uniform, source budget conservation, and counts/maximum remaining residual by original stage/case. Archived R147 analytic whole/paid values are high-precision finite-model diagnostics, not certified actual kernels or dx integrals. I1 rational coverage is exact for the saved two-score model. Preserve input/archive/member/script/plan SHA256, chosen strategy, execution count and any failures. Stop at the four-file delivery; no general theorem/root-order claim.
