# R148 限定历史与 E03：后验时间势、删源和固定来源分配

结论：后验质量势的归一化误差及删除正跳已有明确历史；R147 已证明任意整窗固定分配 a(v) 的预算定理，不能把重新选择 a 本身当新定理。限定检索未定位到“原 Π 流有免费单调熵势，因而完整剩余已付”的结论，也没有不指定优化目标的唯一最优分配。以下给作者可直接核用的旧身份、有限模型补全及精确最小覆盖预算；均不提供原接收外账的免费帽。

## 1. 范围与 E03 使用等级

本轮只定向检索后验质量、entropy/KL、log e、删除跳、FTC与分配等词，重点实读 R122 `weighted_suffix_integration_private.md`、R135 `area_flux.md`，以及当前工作目录的 `r147_q_capacity.md`、`r147_q_extremal.md`。为追到必要原式，只追加读取 R117 `audit_normalized.md` §2–4 及 R137 `posterior_budget.md` PB8–12 的熵条件片段；没有通读全史。R147工作片段来自既有 `rounds/147/research.zip`，不把本轮拷贝当新证明。

已读安装的 E03 `SKILL.md`、`references/method.md`、`cube-interface.md`、`provenance.md`。本轮**未调用或新核读 E03 外部原论文**，不凭旧 full_read 标签引用常数4/32或显式 Bellman 势。实际可用的是独立有限树代数：若节点质量满足 m(child)=m(parent)p(child|parent)，且
\[
\Phi(v)\ge c(v)+\sum_wp(w|v)\Phi(w),
\]
乘 m(v) 后有限求和，内部边消去，保留末层势。必须证明质量守恒、局部不等式及终端符号；逐路径预算需要 sup 子节点，不能换成平均预算。

本模型最近的映射是**未归一化**来源存活质量 \(1_{Z_t}w_t\nu\)：有限时间分割下可把权损失与真正删除分配到墓地节点，使质量守恒。归一化后的 Π_t 每次重置总质量为1，不能直接沿用同一流质量；其修正正是下面的 log e 和删除项。E03 没有证明这些修正有根阶外价。不同 j/history/中心的重叠也不自动构成单树。

## 2. 最邻近旧身份与新颖性边界

| 已有位置 | 已证或明确记录的内容 | 不能省略的条件/费用 |
|---|---|---|
| [R117 audit_normalized.md:31](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/audit_normalized.md:31)，§2–4 | 无删除段 \(e'_t=-e_tm_t/t\)、\(\partial_t\Pi_t=(m_t-k_t)\Pi_t/t\)；删除比例 d=r_removed/e− 给后验跳正变差 d≤log(e−/e+)。 | a.e.导数、正闭窗质量下界与有限/可控跳；阈值穿越改变 k，但不使 wt 跳。原固定行的正质量下界不是统一费用帽。 |
| [R135 area_flux.md:134](/Users/zhengzhihao/Desktop/T/output/centered_cube_round135_20261014/area_flux.md:134)，AF14及紧接文字 | \(H_t=e_t^{-1}\int_{S_g}\rho w_t\nu\)，\(\int_{S_g}\rho k_t d\Pi_t=-H'_t+H_tm_t\)。终端分子连续，删源令 H 正跳；连续误差含 log(e_start/e_end)。 | ρ与Sg须沿整窗固定，不能删除 \(H_tm_t\) 或后验正跳。AF14不是免费熵耗散。 |
| [R122 weighted_suffix_integration_private.md:15](/Users/zhengzhihao/Desktop/T/output/centered_cube_round122_20261014/weighted_suffix_integration_private.md:15)，第1节 | 原 pair 后缀F≤0时，signed积分=\(F(\tau)/e_\tau^2+\int Fd(e^{-2})\le0\)。 | 要每个后缀、完整原窗；删源使 e−²上跳在此式中非正，是该 pair signed 槽的符号，不能挪作另一质量势的负账。已消费N_Z不返还。 |
| 同件第2节，约31–49行 | 静态捕获 c(v)=min(1,K/(TA))，\(\int cA\nu/e_g\le q/(Te_g)\)，用一次原FTC。 | 这是旧下降量分配，未证明其正余补集根阶价；不是按时刻最优重选测试。 |
| 当前 [r147_q_capacity.md:37](/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/148/work/r147_q_capacity.md:37)，QC4–7 | 固定 \(\mu_Q=Q\nu/q\)、L*≥Lt、\(\int_{E_+}a\,d\mu_Q\le1\)，则门 \(\rho/r_t\le a/(2NL_*)\) 的整窗后验正交通≤1/(2N)。 | a可依整行与v，不能随t、内bad u或外hard z重选；不能把若干分配的门并集只付一份。 |
| 同件QC8–14 | 主a=1/m，替代a=ρ/Mρ及其固定凸组合；主支已付48Λ√nWβ，补集保留。 | 这些只是可行选择，不是对任意残余目标都最优；Lh替代Lg也是已有理论选项，不能再登记同价新支。 |
| 当前 `r147_q_extremal.md` QE6–8 | 全行共同λ的上证书；infλ不能移入pair变成逐pair最优。 | 时点代数帽仍有真实接收外价，不能替代固定a的时间预算或把必要约束最优点当FULL。 |

R137 PB8–12 的“熵”是 score倾斜来源相对于 K₀容量概率的 Rényi/KL 费用；趋近1阶需要正指数矩和外积分支配。它不是 Π_t 时间流单调性的定理，也不支付 log(eτ/eh)。

## 3. 作者可用的质量势与删除项：完整公式

先在有限非零来源、有限删除时刻模型上书写，u=log t、m_t=EΠt k_t、et>0。令 f(v)∈[0,1]沿整窗固定，\(H_t=E_{\Pi_t}f\)。在无删除段，旧后验导数直接给
\[
H'_u=-E_{\Pi_t}(fk_t)+H_tm_t=-\operatorname{Cov}_{\Pi_t}(f,k_t).
\tag{TH1}
\]
设删除时刻s的旧质量比例为 \(d_s=(e_{s-}-e_s)/e_{s-}<1\)，以及 \(d_{f,s}=e_{s-}^{-1}\int_{removed}fw_s\nu\)。精确跳为
\[
H_s-H_{s-}=\frac{d_sH_{s-}-d_{f,s}}{1-d_s}.
\tag{TH2}
\]
对 R135 的 terminal \(f=\rho1_{S_g}\)，被删来源上f=0，故
\[
\Delta H_s=\frac{d_sH_{s-}}{1-d_s}=d_sH_s\ge0.
\]
于是
\[
\int_\tau^hE_{\Pi_t}(fk_t)\frac{dt}{t}
=H_\tau-H_h+\int_\tau^hH_tm_t\frac{dt}{t}
+\sum_{\tau<s\le h}\Delta H_s.
\tag{TH3}
\]
这补全 AF14 的跳项，属于旧母式的直接代数展开，不能列为新的已付预算。起点取右态；终点若有删除，按同一右态并计其跳。固定来源的阈值点没有额外H原子。

同时有精确总质量身份
\[
\boxed{\log\frac{e_\tau}{e_h}
=\int_\tau^h m_t\frac{dt}{t}
+\sum_{\tau<s\le h}-\log(1-d_s).}
\tag{TH4}
\]
因此 0≤H≤1 与 \(\Delta H_s\le d_s\le-\log(1-d_s)\) 给误差的 log比帽，但该比没有一般输入无关上界；相对单调et≥eg不支付它。连续/奇异删源需要明确的删除测度及BV链式法则，不能只把离散和换成0；本报告不把有限跳式冒称连续删源全域证明。

若候选f本身随t移动（例如early集合），TH1会有门变化项；除非证明门边界上的被积势为0或另有符号，不能直接复用TH3并删边界。TH2亦须用实际门的左右态，不能给负项附新正门。

## 4. “熵势差”的可证明范围

限定有限正原子模型、固定严格正参考测度 μ（可取R147的固定μQ），定义密度 \(g_t=d\Pi_t/d\mu\)、\(\mathcal H_t=\int\log g_t\,d\Pi_t\)。所有对数在正后验支持上，0log0取0。无删除段直接微分得
\[
\mathcal H'_u=-\operatorname{Cov}_{\Pi_t}(k_t,\log g_t).
\tag{TH5}
\]
当 μ=μQ 时 \(g_t=L_t/r_t\)，故右边等于 \(\operatorname{Cov}_{\Pi_t}(k_t,\log r_t)\)，**没有自动符号**。μQ为次概率不影响这条代数式，也不能将其重新归一化时的常数漏掉。

删除旧后验比例d后，设 \(J_{del}=\int_{removed}\log g_{s-}\,d\Pi_{s-}\)，则
\[
\mathcal H_s-\mathcal H_{s-}
=\frac{d\mathcal H_{s-}-J_{del}}{1-d}-\log(1-d).
\tag{TH6}
\]
该跳一般不单调。虽然 \(KL(\Pi_s\Vert\Pi_{s-})=-\log(1-d)\)，这更换了参考测度，不能据此宣称固定μ的熵势每次只增加该项。一般来源欲沿用TH5–6，须先核对对数可积、可微分支配和跳项有限；有限KL本身不保证所需时间共同支配。限定历史未找到这个熵势可免费控制原剩余交通的外预算；TH5–6只是本轮可自证的有限模型身份，不借E03名称引用。

## 5. 最优固定源分配：先指定覆盖目标

R147 已允许任意固定a，因此“再优化a”首先是该定理的应用。没有目标时，常数a=1/m与ρ/Mρ无法统一排序。对一个明确的可测目标时间集合 \(F_v\subset[\tau,h]\)，要求QC5覆盖其上几乎每个时间，精确所需最小密度为
\[
a_{min}(v)=2NL_*\rho(v)\operatorname*{ess\,sup}_{t\in F_v}\frac1{r_t(v)},
\tag{TH7}
\]
空Fv取0，esssup按dt/t；有限时间窗下可由有理水平集的截面测度检可测。QC5的逐点不等式使任意可行a≥amin，反之取amin即可，所以最小总预算恰为 \(\int a_{min}d\mu_Q\)。该量≤1时可直接用既有QC6付指定目标；若>1，不能称“优化分配已经覆盖”。这不优化或改变原ρ、Q、α。

若要求覆盖整窗且ρ>0，rt非减，
\[
a_{min}=\frac{2NL_*\rho}{r_\tau},\qquad
\int a_{min}d\mu_Q
=2N\frac{L_*}{L_\tau}E_{\Pi_\tau}[\rho1_{E_+}].
\tag{TH8}
\]
后式一般不≤1，精确暴露初始后验质量费用。若仅覆盖真实正score/原门出现的时间，Fv可相应缩小，需使用其实际首个有效时刻，而不能把所有始终零score来源从旧主m定义中事后删掉后宣称原主门未变。新的a始终只领取同一份预算；与旧主门取并集须重新检验共同a或准确去重。

TH7是“给定覆盖目标”的最小固定预算，不是对原剩余总流量的最优控制定理。若改为最大化已付交通/最小化残余，必须写出实际时间收益函数与完整外权；其最优a通常不同，且可能依赖整条未来路径。即使逐行可测最优a存在，也仍需保持不依外z/u/time的QC合同，支付原β、dx、unique j、尺度与history；不由E03自动提供。

作者当前最有价值的接口是：用TH1–4保留归一化及删除项，或在移动early超额势中直接证明新增边界项为0/有利；再以TH7核算任何主张覆盖的固定源预算。单纯重命名熵或采用更优a不会消除R147 QC14的实际余部。没有新数值、没有外原论文调用、没有Git或其他文件修改，交付停止。

## 6. 追加短索引：连续(s,L)两参数联合包络已经存在

按追加任务，只追读 [R117 sources_scope.md:17](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/sources_scope.md:17) 所指原件 [next_spatial_compensated_split.md:100](/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/high_marked_cover/next_spatial_compensated_split.md:100) CS9–10 与 [compensated_split_review.md:52](/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/high_marked_cover/compensated_split_review.md:52) 的实审片段。确有**连续soft参数与物理尺度的联合FTC**，不是固定s的一参数结论，更不是免费冻结s(x)。

准确范围为 \(s\in[1-d,1]\)、\(0<d<1/2\)、\(a\le L\le b\le2a\)。旧CS9在真实产品核、observed score下给
\[
\|D_{\log L}P_s\|_{TV}\le2n(1-s)+\sqrt{28n},\qquad
\|\partial_sP_s\|_1\le10\sqrt n,
\]
\[
\|\partial_sD_{\log L}P_s\|_{TV}
\le10\sqrt n\sqrt{28n+n^2(1-s)^2}+6n+10n(1-s)\sqrt n.
\tag{TH9}
\]
混合项的硬面贡献明确包括：对硬面系数1−s求导的 n，以及其余n−1坐标概率因子求导的至多 \(10n(1-s)\sqrt n\)；正规部分另有5n。不能遗漏硬面原子、只取latent-mask的 \(1/[s(1-s)]\) 方差或把两套一参数帽相乘冒作此式。

完整两参数FTC从(1−d,a)起步，保留基准质量、soft变差、物理变差和混合导数TV，得到旧CS10
\[
\int\sup_{\substack{1-d\le s\le1\\a\le L\le b}}P_{s,L}
\le1+10\sqrt n\,d+\log2\left[2nd+\sqrt{28n}
+d\{10\sqrt n\sqrt{28n+n^2d^2}+6n+10nd\sqrt n\}\right].
\tag{TH10}
\]
因此主阶是 \(\sqrt n+nd+n^{3/2}d^2\) 等项，d=A/√n给 \(O(\sqrt n(1+A+A^2))\)。这已经处理soft近1时硬跳尺度费用与soft方向的耦合；不能作为本轮首次完成联合包络登记。JT13的全soft价 \(3(2n+3)D_n\) 则是L网格的O(n)乘全soft变化O(√n)，两者范围不同。

原TOP直接输出费也已登记：[R117 final_sources.md:19](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/final_sources.md:19) 与同源CS5–6。大维度 \(n>4\cdot1000^2\log(n+2)\) 才定义 \(d_n=1000\sqrt{\log(n+2)/n}<1/2\)；TOP={s>1−dn}已经删输出，费用是原W_full口径，不自动可退成Wβ；小维度用完整强包络回退。较宽候选带超出的部分未因此自动已付，边界s=1−dn也不能因严格TOP门而无证删除。

全soft范围存在已证尺度障碍：[R122 remaining_mixture_geometry_private.md:114](/Users/zhengzhihao/Desktop/T/output/centered_cube_round122_20261014/remaining_mixture_geometry_private.md:114)，RM9及同轮softness mixture独审：因 \(P_{s,L}\ge(1-s)^nh_L\)，
\[
\int\sup_{L\in[a,b]}P_{s,L}\ge(1-s)^n[1+n\log(b/a)].
\tag{TH11}
\]
原s下门可趋近 \(1-2^{-1/n}\)，此时 \((1-s)^n\) 趋近1/2；对固定非退化octave，全参数包络至少Ω(n)。这不是原最大算子弱型反例，也不排除将全参数JT13从O(n√n)改成O(n)的有效改进；它只排除把包含近hard端的全参数正包络统一宣称为根阶polylog。限定实读未定位一般全soft联合O(n)定理，不能据未命中宣布其不存在。
