#!/usr/bin/env python3
"""Certified fixed-source allocation for frozen original FA time coverage."""
from fractions import Fraction as F
from pathlib import Path
from zipfile import ZipFile
from itertools import combinations
from collections import defaultdict
import json,hashlib,argparse,math,time,datetime,sys
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--input-root',default='/Users/zhengzhihao/Desktop/T/output');ap.add_argument('--archive',default=str(ROOT.parents[1]/'147/research.zip'));args=ap.parse_args();BASE=Path(args.input_root);ARCH=Path(args.archive)
P=dict(source=BASE/'centered_cube_round136_20261014/active_traffic_v2.json',receiver=BASE/'centered_cube_round142_20261015/numeric_receiver.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fr(x):return F(str(x))
def jf(x):return F(int(x['numerator']),int(x['denominator']))
def ser(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {str(k):ser(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [ser(v) for v in x]
 return x
def wt(c,t):
 v=F(1)
 for a in c:v*=min(F(1),a/t)
 return v

def fval(m,b):
 if b<=m['l']:return F(0)
 b=min(b,m['u']);return m['R']*(b-m['l'])/(m['A']*b+m['D'])
def grad(m,b):return m['R']*(m['A']*m['l']+m['D'])/(m['A']*b+m['D'])**2

def subset_certificate(models,active):
 low={i:models[i]['l'] for i in active};up={i:models[i]['u'] for i in active};ls,us=sum(low.values(),F(0)),sum(up.values(),F(0))
 if ls>1:return dict(active=list(active),feasible=False,lower_budget=ls)
 if not active:return dict(active=[],feasible=True,candidate={},lower=F(0),upper=F(0),method='zero allocation')
 if us<=1:
  val=sum((fval(models[i],up[i]) for i in active),F(0));return dict(active=list(active),feasible=True,candidate=up,lower=val,upper=val,method='whole coverage of this subset',budget=us)
 # Floating arithmetic proposes a point; all feasibility/objective/upper checks below are Fraction.
 def suggested(i,lam):
  m=models[i];numer=float(m['R']*(m['A']*m['l']+m['D']));b=(math.sqrt(numer/lam)-float(m['D']))/float(m['A']);return min(float(up[i]),max(float(low[i]),b))
 left=0.;right=max(float(grad(models[i],low[i])) for i in active)
 for _ in range(180):
  mid=(left+right)/2
  if sum(suggested(i,mid) for i in active)>1:left=mid
  else:right=mid
 point={i:min(up[i],max(low[i],F(repr(suggested(i,right))))) for i in active};excess=sum(point.values(),F(0))-1
 if excess>0:
  for i in active:
   cut=min(point[i]-low[i],excess);point[i]-=cut;excess-=cut
  assert excess==0
 else:
  spare=-excess
  for i in active:
   add=min(up[i]-point[i],spare);point[i]+=add;spare-=add
 assert sum(point.values(),F(0))<=1 and all(low[i]<=point[i]<=up[i] for i in active)
 value=sum((fval(models[i],point[i]) for i in active),F(0));slopes={i:grad(models[i],point[i]) for i in active};intercept=sum((fval(models[i],point[i])-slopes[i]*point[i] for i in active),F(0));linear=low.copy();spare=1-ls
 for i in sorted(active,key=lambda i:slopes[i],reverse=True):
  add=min(up[i]-low[i],spare);linear[i]+=add;spare-=add
 upper=intercept+sum((slopes[i]*linear[i] for i in active),F(0));assert upper>=value
 return dict(active=list(active),feasible=True,method='rational feasible point plus exact concave tangents and bounded linear knapsack',candidate=point,budget=sum(point.values(),F(0)),lower=value,upper=upper,tangent_slopes=slopes,tangent_intercept=intercept,linear_maximizer=linear,linear_max_budget=sum(linear.values(),F(0)))

def analyze(cid,r,c,nu,old):
 n=c['n'];N=2*n+3;rho=list(map(fr,r['rho']));Q=list(map(fr,r['Q']));q,p=map(fr,[r['q'],r['p']]);K=fr(c['parameters']['K']);eg=sum(nu[i]*fr(c['atoms'][i]['wg']) for i in range(6));mu=[nu[i]*Q[i]/q for i in range(6)];gp=[i for i in range(6) if r['good'][i] and rho[i]>0];m=sum(mu[i] for i in gp);Lg=K*q/(p*eg);full=[F(0)]*6;caps=defaultdict(list)
 for cap in r['traffic']['FA_caps']:
  s=c['score_segments'][cap['segment']];i,j=cap['v'],cap['bad'];lo=max(fr(cap['lo']),fr(s['lo']));hi=min(fr(cap['hi']),fr(s['hi']));assert hi>lo and i in gp and r['bad'][j] and c['pairs'][6*i+j]['Psi'];a=list(map(fr,c['atoms'][i]['thresholds']));wlo=wt(a,lo)
  # Use saved score coefficient as the same original finite-model weight, preserving120-digit rounding.
  wlo=fr(s['c'][i])/lo**s['k'][i];cost=2*N*nu[i]*rho[i]*wlo/eg;full[i]=max(full[i],cost);caps[i].append((cap,s,lo,hi))
  Ci=K*Q[i]/p;assert cost==mu[i]*(2*N*Lg*rho[i])/(Ci/wlo)
 fullcost=sum(full);uniform=[mu[i]/m if i in gp else F(0) for i in range(6)];assert sum(uniform)==1
 row=dict(case=cid,id=r['id'],stage=r['stage'],distribution=r['distribution'],n=n,N=N,Gplus=gp,mu=mu,mu_total=sum(mu),m=m,Lg=Lg,rho=rho,Q=Q,q=q,p=p,e_g=eg,full_coverage_budget=fullcost,full_coverage_source_b=full,full_coverage_possible=fullcost<=1,uniform_b=uniform,uniform_a=[F(1)/m if i in gp else F(0) for i in range(6)],uniform_budget=sum(uniform),archived_whole_F=old['F_whole'],archived_uniform_paid_F=old['F_paid'],archived_uniform_residual_fraction=old['residual_fraction'],objective='original full saved FA/Psi traffic with full e_t, common rho and whole-window fixed source allocation')
 if fullcost<=1:
  chosen=full;row.update(strategy='exact full-coverage allocation',optimal_covered_fraction_lower=F(1),optimal_covered_fraction_upper=F(1),optimal_residual_fraction_lower=F(0),optimal_residual_fraction_upper=F(0),gap_fraction=F(0),certificate='Nonnegative objective bounded by whole traffic; all positive FA intervals included by rational monotone endpoint tests.')
 elif cid=='I1':
  assert len(caps)<=3 and all(len(z)==1 for z in caps.values());models={};factor=p*fr(r['hardmass'])/q
  for i,items in caps.items():
   cap,s,lo,hi=items[0];j=cap['bad'];ks=s['k'];cf=list(map(fr,s['c']));assert sorted(set(ks))==[0,4] and ks[i]==4 and ks[j]==0;A=sum(nu[v]*cf[v] for v in range(6) if ks[v]==4);B=sum(nu[v]*cf[v] for v in range(6) if ks[v]==0);D=2*N*nu[i]*rho[i]*cf[i]/eg;l=D*hi**-4;u=D*lo**-4;R=factor*rho[i]*nu[i]*nu[j]*cf[i]*cf[j]/(A*hi**-4+B);models[i]=dict(A=A,D=B*D,R=R,l=l,u=u)
  ids=list(models);certs=[]
  for size in range(len(ids)+1):
   for active in combinations(ids,size):certs.append(subset_certificate(models,active))
  feasible=[z for z in certs if z['feasible']];best=max(feasible,key=lambda z:z['lower']);lower=best['lower'];upper=max(z['upper'] for z in feasible);whole=sum((fval(models[i],models[i]['u']) for i in models),F(0));base=sum((fval(models[i],uniform[i]) for i in models),F(0));upper=min(upper,whole);assert 0<=base<=lower<=upper<=whole;gap=(upper-lower)/whole;assert gap<=F(1,10**10);chosen=[best['candidate'].get(i,F(0)) for i in range(6)];err=abs(base-fr(old['F_paid']))/whole;assert err<F(1,10**60);errw=abs(whole-fr(old['F_whole']))/whole;assert errw<F(1,10**60)
  row.update(strategy='active-set enumeration with exact rational tangent upper and feasible lower',models=models,active_set_certificates=certs,chosen_active_set=best['active'],whole_F_exact=whole,uniform_paid_F_exact=base,uniform_residual_F_exact=whole-base,baseline_comparison_relative=err,whole_comparison_relative=errw,optimal_paid_F_lower=lower,optimal_paid_F_upper=upper,optimal_covered_fraction_lower=lower/whole,optimal_covered_fraction_upper=upper/whole,optimal_residual_fraction_lower=(whole-upper)/whole,optimal_residual_fraction_upper=(whole-lower)/whole,gap_fraction=gap)
 else:
  chosen=uniform;row.update(strategy='unresolved P1 non-full-feasible row; uniform retained without optimum assertion',optimal_covered_fraction_lower=F(0),optimal_covered_fraction_upper=F(1),optimal_residual_fraction_lower=F(0),optimal_residual_fraction_upper=F(1),gap_fraction=F(1))
 row['chosen_b']=chosen;row['chosen_a']=[chosen[i]/mu[i] if i in gp else F(0) for i in range(6)];row['chosen_budget']=sum(chosen);assert row['chosen_budget']<=1 and all(chosen[i]==0 for i in range(6) if i not in gp);assert sum(mu[i]*row['chosen_a'][i] for i in gp)==row['chosen_budget'];return row

def summary(rows):
 W=sum((fr(r['archived_whole_F']) for r in rows),F(0));base=sum((fr(r['archived_whole_F'])*fr(r['archived_uniform_residual_fraction']) for r in rows),F(0));lo=sum((fr(r['archived_whole_F'])*r['optimal_residual_fraction_lower'] for r in rows),F(0));hi=sum((fr(r['archived_whole_F'])*r['optimal_residual_fraction_upper'] for r in rows),F(0));return dict(N=len(rows),full_coverage_feasible_count=sum(r['full_coverage_possible'] for r in rows),certified_nonzero_residual_count=sum(r['optimal_residual_fraction_lower']>0 for r in rows),unresolved_count=sum(r['gap_fraction']==1 for r in rows),max_gap_fraction=max([r['gap_fraction'] for r in rows] or [F(0)]),finite_record_archived_F_whole_sum_display=float(W),uniform_residual_fraction_display=float(base/W) if W else None,optimal_residual_fraction_lower_display=float(lo/W) if W else None,optimal_residual_fraction_upper_display=float(hi/W) if W else None)
def main():
 start=time.monotonic()
 with ZipFile(ARCH) as z:member={k:z.read(k) for k in ['time_coverage.json','numeric_margin.json']}
 tc=json.loads(member['time_coverage.json']);old={(r['case'],r['id']):r for r in tc['records']};assert len(old)==179;src={c['id']:c for c in json.loads(P['source'].read_text())['cases']};rec=json.loads(P['receiver'].read_text());picked=[]
 for cid,case in rec['cases'].items():
  for r in case['records']:
   if (cid,r['id']) in old:picked.append((cid,r,case))
 assert len(picked)==179;picked.sort(key=lambda x:({'initial':0,'pressure':1,'expanded':2}[x[1]['stage']],x[0],x[1]['id']));rows=[]
 for cid,r,case in picked:rows.append(analyze(cid,r,src[cid],list(map(jf,case['nu_exact'])),old[(cid,r['id'])]))
 out=dict(status='completed_certified_finite_model',execution_count=1,scope='Same179 original receivers, true original saved FA/e coverage, fixed source budget only; no kernels/new sampling/dx/FULL/root claim',archive_sha256=sha(ARCH),archive_member_sha256={k:hashlib.sha256(v).hexdigest() for k,v in member.items()},input_sha256={k:sha(p) for k,p in P.items()},script_sha256=sha(Path(__file__)),plan_sha256=sha(ROOT/'optimal_budget_plan.md'),summary=summary(rows),strata={},records=rows,elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 for stage in ['initial','pressure','expanded']:
  for cid in ['I1','P1']:out['strata'][stage+'/'+cid]=summary([r for r in rows if r['stage']==stage and r['case']==cid])
 for cid in ['I1','P1']:out['strata'][cid]=summary([r for r in rows if r['case']==cid])
 (ROOT/'optimal_budget.json').write_text(json.dumps(ser(out),ensure_ascii=False,indent=2)+'\n');print('SUMMARY',ser(out['summary']),flush=True)
 for r in rows:
  if r['case']=='I1':print('I1',r['id'],r['stage'],'fullcost',float(r['full_coverage_budget']),'uniformResidual',r['archived_uniform_residual_fraction'],'optResidual',float(r['optimal_residual_fraction_lower']),float(r['optimal_residual_fraction_upper']),'gap',float(r['gap_fraction']),flush=True)
 print('seconds',out['elapsed_seconds'],flush=True)
if __name__=='__main__':main()
