# R148：early 补集的截断后验势与真实 Q 占用扣减

状态：恒等式通过；未得到一般补集付款。只写本文件，不修改他人文件，不操作 Git/PDF。

## TP1. 先筛命题及历史边界

R135 `area_flux.md` §5、AF14 已证明固定终端余权的质量势
\(\int\rho k\,d\Pi=-H'+H\mathbb E_\Pi k\)，并明确归一化和删源正跳不能删除。R143 `score_flux_budget.md` 已指出完整反向 score 交通不等于原 \(\Psi\) 负交通。本稿不将这些事实登记为新增结果。

本轮候选是：用 R147 **最终共享质量分支的准确补集**构造截断超额势，将移动门槛的通量完整计入，检验是否出现可与三个真实 Q 核比较的扣减。成立的是 TP5 的恒等式；它没有自动给出 \(O(1/n)\) 的逐行帽。仅凭后验权重、连续分段幂和非增删源不能宣称这样的帽；也不假设 good/bad score 全序。

## TP2. 固定实际行及完整时间

固定原有限截断的实际行 \((\omega,V,j,x,y,z,\mathrm{history})\)，保留实际 \(p=P_{s,L}(x-y)\)、\(Q_v=(P_{s,L}(x-v)+P_{s,L^+}(x-v)+J_b(x-v))/3\)、\(q,g,\tau=a/c_j,h<g\)。内部时间为完整 \([\tau,h]\)，原远窗只是其中的可测子集。\(Z_t\) 非增，
\[
w_t(v)=\prod_i\min(1,a_i(y,v)/t),\quad k_t(v)=\sum_i1_{a_i<t},\quad
e_t=\int_{Z_t}w_t\,d\nu>0,\quad d\Pi_t=1_{Z_t}w_t\,d\nu/e_t.
\tag{TP1}
\]
固定终端 good 集 \(G\subset Z_g\)，将原时间固定的 \(\rho\in[0,1]\) 在 \(G^c\) 上延为零。所有原正资格门稍后仅在上界中放宽；原负门不变。记
\[
d\mu_Q=Q_vd\nu/q,\quad r_t(v)=KQ_v/(pw_t(v)),\quad
F_t=Kq/(pe_t),\quad m_t=\int k_t\,d\Pi_t.
\tag{TP2}
\]
FIRST/high 给 \(\mu_Q(\mathbb R^n)\le1\)、\(F_t\le F_g\le1/2\)，且准确地
\[
d\Pi_t=1_{Z_t}F_t r_t^{-1}d\mu_Q.
\tag{TP3}
\]
有商行使用 TP2；原零交通行直接置零。没有将 \(\mu_Q\) 归一成概率，没有以常数替代共同 \(e_t\)。以下导数均对 \(s=\log t\)。

## TP3. 与 R147 最终分支一致的 early 域

在 \(E_+=G\cap\{\rho>0\}\) 上预先固定正有限阈值 \(c(v)\)，在整个内部时间不重选。记
\[
b_t(v)=\rho_v/r_t(v),\qquad A_t=\{v\in E_+:b_t(v)>c(v)\}.
\tag{TP4}
\]
R147 的预算密度 \(a(v)\) 对应 \(c(v)=a(v)/(2NF_g)\)。其最终采用版本为 \(m_Q=\mu_Q(E_+)\)、\(c=1/(2NF_gm_Q)\)，故本稿的 early 域恰为
\[
r_t(v)<2NF_gm_Q\rho_v.
\]
若 \(m_Q=0\)，该交通为零。预算密度为零处未获 R147 付款，不能免费加入本稿正阈值分支。最简 \(c=1/N\) 只是较小 R147 基础支的补集，不替代最终共享质量补集。

定义
\[
E_t=F_t\int_{Z_t}(b_t-c)_+d\mu_Q,
\quad C_t=F_t\int_{Z_t\cap A_t}c\,d\mu_Q,
\quad H_t=\int_{A_t}\rho\,d\Pi_t=E_t+C_t.
\tag{TP5}
\]
于是 \(0\le E_t\le H_t\le1\)。\(C_t\) 是**三个完整核的真实 Q 占用量**，不是另造的面积权。共享质量版本还给 \(C_t\le F_t/(2NF_g)\le1/(2N)\)。这只是上界，不能反向用来支付正误差。

## TP4. 连续段、score 阈值与删源的准确变化

在无删源的时间段，\(b'_t=-k_t b_t\)、\(F'_t=m_tF_t\)，所以链式法则给
\[
E'_t=m_tE_t-\int_{A_t}\rho_vk_t(v)d\Pi_t(v).
\tag{TP6}
\]
函数 \((b-c)_+\) 在门槛处为零，因此移动 early 边界没有遗漏的质量项。\(w_t\) 在坐标阈值处连续；\(k_t\) 可跳，但 TP6 只微分 \(w_t\) 而不微分 \(k_t\)，故没有额外 score 激活原子。等号平台上的通量为零。

在同一时间的删源跳，先按原历史删源，再取右状态。设删去的 \(w\) 质量比例为 \(d_s\in[0,1)\)，令
\[
D_s=F_{s-}\int_{Z_{s-}\setminus Z_{s+}}(b_s-c)_+d\mu_Q.
\]
\(b_s,c,Q,w\) 在该跳不变，则
\[
E_{s+}=\frac{E_{s-}-D_s}{1-d_s},\qquad
\Delta E_s=\frac{d_sE_{s-}-D_s}{1-d_s}=d_sE_{s+}-D_s.
\tag{TP7}
\]
这是完整跳公式，不丢弃删除分子。对本稿实际 \(\rho\) 支持 \(G\subset Z_g\) 的情形，删去来源的 \(\rho=0\)，故 \(D_s=0\)、\(\Delta E_s=d_sE_{s+}\ge0\)。特别地，共同归一化即使只删去坏来源仍产生正跳。\(\sum_s d_s\le\sum_s-\log(1-d_s)\) 只是价格表达式，并非已有根阶预算。

## TP5. 完整双来源正交通的精确势差

在同一实际 \(\Pi_t\) 上定义
\[
T_t=\iint1_{A_t}(v)\rho_v[k_t(v)-k_t(u)]_+d\Pi_t(v)d\Pi_t(u),
\]
\[
R_t=\iint1_{A_t}(v)\rho_v[k_t(u)-k_t(v)]_+d\Pi_t(v)d\Pi_t(u).
\tag{TP8}
\]
这些是放宽原正门后的完整来源对，\(R_t\) 并非原已记账的负交通。用 \(a_+-(-a)_+=a\)，准确得到
\[
T_t-R_t=\int_{A_t}\rho k\,d\Pi_t-m_tH_t
=-E'_t-m_tC_t.
\tag{TP9}
\]
因而含全部端点及删源跳的全窗恒等式为
\[
\boxed{\int_\tau^hT_t\frac{dt}{t}
=E_\tau-E_h+\sum_{s\in(\tau,h]}\Delta E_s
 +\int_\tau^h(R_t-m_tC_t)\frac{dt}{t}.}
\tag{TP10}
\]
采用右连续端点；若原截断采用左端状态，应相应把该端的跳列入和式。所有内部阈值已包含，没有另外的 \(\log2\) 费用。有限删源下直接成立；更一般截断极限必须保留跳和的极限或其变差预算，不能默删。

新增结构仅是移动截断带来的 \(-m_tC_t\) 与零边界项。将 \(C=0\) 即退回 AF14 加完整反向交通的旧身份。对原 early 剩余正积分，保持 \(\Psi\)、FA、good/bad、low、history、旧付款补集及远窗后，其值 **不超过** TP10 左侧，因为所放宽的门均在 \([0,1]\)。这不授权把 TP8 的 \(R_t\) 从原负账扣去。

## TP6. 熵势核验：同样保留归一化与跳价

若相应积分有限，令 \(\psi(z)=1_{z>1}(z\log z-z+1)\)，
\[
\Phi_t=F_t\int_{Z_t}c\,\psi(b_t/c)d\mu_Q.
\]
同一证明给
\[
\Phi'_t=m_t\Phi_t-\int_{A_t}\rho k\log(b_t/c)d\Pi_t,
\quad
\Delta\Phi_s=d_s\Phi_{s+}-F_{s-}\int_{Z_{s-}\setminus Z_{s+}}c\psi(b_s/c)d\mu_Q.
\tag{TP11}
\]
它控制的是另带 \(\log(b/c)\) 的通量；当 \(b/c\downarrow1\) 时该因子趋零，不能直接上界原未加权交通。原 R147 共享质量阈值满足 \(c\ge1/N\)，终端 good 给 \(r_g\ge1\)，而 \(w_\tau/w_g\le(g/\tau)^n\le2^n\)，故仅有粗帽 \(\Phi_t\le(n\log2+\log N)_+H_t\)。没有免费熵下降或新的维度收益。本稿不引入人工面积衰减权。

## TP7. 具体的真实 Q 比较缺口

TP10 的可检验非同义几何输入可以是下式；它直接比较共同来源的反向 score 尾与三个实际接收核，而非假设目标交通已有预算：对实际 early 来源 v，
\[
\boxed{p\rho_v w_t(v)\int_{Z_t}[k_t(u)-k_t(v)]_+w_t(u)d\nu(u)
\le c(v)KQ_v\int_{Z_t}k_t(u)w_t(u)d\nu(u).}
\tag{TP12}
\]
若 TP12 成立，除以共同 \(e_t\)、再按 \(F_t\mu_Q(dv)\) 积分即可得 \(R_t\le m_tC_t\)。也可只要求 TP12 的有符号缺陷在**原实际接收测度**下可积并有明确预算。该条件使用 \(Q=(P+P^++J)/3\) 全部三核、同一 \(p,x,y,\nu,w_t\)，没有把 \(\beta\) 改为 Lebesgue 测度。它比 good/bad score 全序弱，但仍未由现有 good/bad/FIRST 推出；例如低 score 的 early 来源面对高 score 后验质量时方向可能失败。没有独立证明就不能调用。

即使 TP12 成立，也还须支付 \(E_\tau\) 与 \(\sum d_sE_{s+}\)，或通过原负预算中一个已证明的匹配消去它们。终端 \(-E_h\) 必须保留，不能假称初端为零。一个具体初端几何对象是
\[
E_\tau=\frac1{e_\tau}\int_G
\left[\rho_vw_\tau(v)-\frac{c(v)KQ_v}{p}\right]_+d\nu(v).
\tag{TP13}
\]
这是真实 Q 对早期余权的覆盖缺口，终端 good 仅控制 \(w_g\)，不控制 TP13 中的 \(w_\tau\)。因此 TP12 与 TP13 可直接用于实际 receiver/source 数据核验，而非隐藏在一个新命名的未知总交通中。数值点值不能替代 \(dx\,dt/t\) 或全部自适应选择器预算。

## TP8. 全外价与结论

令 \(B(r)\) 为 TP10 右侧完整括号；恒等式保证 \(B(r)\ge0\)。原外行测度仍是
\[
d\mathcal T_I=1_I1_{j(x)=j}\,p(x-y)h_R(x-z)a_\omega(x,y,z)\,q^{-1}
\,dx\,d\beta(y)\,d\nu(z)
\]
及原种子、V、history 汇总。准确上界为
\[
2\Lambda P_{\mathrm{early,rem}}\le2\Lambda\int B(r)d\mathcal T_I.
\tag{TP14}
\]
原负项仍分别留在母式；这里没有调用或消费它们。\(\alpha\) 仍通过原 \(\rho\) 进入 TP5、TP12、TP13；\(q,e_t,\nu\)、实际 \(dx\)、任意 \(\beta\)、实际 j、连续 \(s,L,H\) 都没有删去。

若将来证明完整来源/时间量 \(B(r)\le B_0\) 对所有实际行一致，则只在此时才能依次用硬来源帽 \(16/3\)、唯一 j、JT13 的 \(3(2n+3)D_n\) 接收包络，得到
\[
2\Lambda P_{\mathrm{early,rem}}
\le32\Lambda(2n+3)D_nB_0W_\beta,
\qquad D_n=1+\tfrac\pi2\sqrt n.
\tag{TP15}
\]
另一旧外价为 \(8\Lambda B_0X\)。没有另乘时间长度；完整时间已在 B 内。即使粗用 \(E_\tau\le1\) 且暂时忽略其余未付项，TP15 仍是 \(O(n^{3/2})W_\beta\) 的端点价，不能称根阶。一般 root 回代需要整个 B 的 \(O(1/n)\) 行帽，或绕过统一行帽、直接证明 TP14 的真实接收几何预算；本稿未证明其中任何一个。

交付：TP10 是保留共同归一化、移动 early 门、全部阈值、删除跳及终端的自足身份；TP12、TP13 明确指出可与实际三核接收几何结合的两个对象。它不是一般早期补集付款，未扩大 R147 已证明的根阶覆盖。一般目标仍 UNPROVED；完成停止。
