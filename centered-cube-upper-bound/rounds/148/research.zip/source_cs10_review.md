# Independent review of the all-softness compensated output split

Status: **PASS for CS1–10, the saved three-stage ingredient records, and the separate output-deletion integration draft.** This is a general partial payment at the original complete smooth FIRST. It does not pay the high-trace residual or prove the general cube endpoint.

Reviewer owns this file only. No owner proof, registration, script, data, run, or root ledger was changed. The audit independently reconstructed saved arithmetic; it did not rerun the quadrature or produce a new source family.

## 1. Original event, score and hard trace

The argument keeps the fixed original threshold q in [3lambda/4,lambda], complete positive smooth source f, and an original interior physical winner. Only this complete convolution has physical derivative zero. The retained hi source, GOOD restrictions, and source parents do not acquire stationarity. The assumption is available after the accepted complete-source smoothing and physical-endpoint deletion; it is not a statement about arbitrary nonsmooth selected box cusps.

For h=1_[−1/2,1/2], psi_s=(1−s)h+s phi, put b_s=s phi/psi_s and w_s=b_s(−u phi'/phi). The physical derivative has regular part (sum w_s−n)P_s and positive hard part

    sum_i (1−s)|u_i| delta_(|u_i|=1/2)
                      product_(j≠i) psi_s(u_j).

With the original physical normalization, convolution of this latter measure with the complete smooth source is Phi_full. It is the hard component of the full product derivative, not the pure h-tensor trace. The owner made this definition explicit during review.

Consequently Phi_full+S_full=nq at the original interior winner. The LOWTRACE condition implies S_full−nsq ≥ n(1−s)q/2, with equality correctly included. Jensen is applied to the actual response posterior P_s,L(x−y)f(y)dy/q. No posterior coordinate independence is assumed. Independence occurs only in the unconditioned product-kernel moment calculations.

The original hard event and original FIRST also imply s>1−2^(−1/n)≥log(2)/(2n)>1/(4n). It is therefore legitimate to use the stated polynomial softness grid. TOP, LOWTRACE and HIGHTRACE form a measurable partition of the retained smooth output set: selected parameters are measurable, and the complete smooth trace is an ordinary continuous response. In the finite regime the whole event is paid instead.

## 2. Scalar moments, tilted BV and two-parameter envelope

The exact kernel identities are valid. In particular phi(1/2)>1/5, |phi'/phi|≤5, integral u²phi=13/12, and integral exp(c|u|)phi≤exp(c/2)/(1−c). The observed regular score satisfies E_psi w_s=s and E_psi w_s²≤25(13/12)<28. For s≥1/2 the observed softness score a_s=(phi−h)/psi_s has mean zero and absolute value at most 10. This observed score has a uniform Fisher bound near s=1; the latent-mask Fisher bound 1/[s(1−s)] would not give the required strip estimate.

For X=w_s−s, the displayed centered Taylor estimate bounds E[X²exp(t|X|)] by 5100 at t≤1/20. Thus 1≤m_s,t≤exp(3000t²). The lower bound is Jensen and is essential when converting an absolute scalar variation bound to a multiple of m: no constant is raised to the nth power.

The tilted scalar j=psi_s exp[t(w_s−s)] is indeed nonmonotone. Its inside-face derivative can diverge upward because phi'' has an integrable logarithmic cusp. The proof uses complete BV, rather than a ray-decreasing dilation argument. Independently checking the explicit certificate gives:

* regular psi derivative contribution <30;
* inside t-weighted score derivative contribution <.15, using monotonicity of w_s inside and its face value ≤5/2;
* outside t-term ≤.05(30+17)=2.35, including the two integration-by-parts boundary terms;
* hard jump contribution <1.14;
* the remaining −j contribution is m.

Thus dilation TV <m+34<35m, and the registered 10000m is safe. The outside calculation correctly uses phi(−H'')≤phi'' for H=−log phi, not a pointwise bound on phi'' at the hard face. The positive inside cusp is integrable. At a canonical hard face the inside tilted trace exceeds the outside trace: log(1+a)≥a/(1+a) and t times the pure-soft face score ≤1/8 prove the claimed sign. There is no extra isolated face value to add.

Tensorization now yields physical variation ≤10000n m^n. Physical FTC on an octave therefore gives [1+10000n log2]m^n. This is a general BV argument including face atoms, with no ray monotonicity premise.

The pointwise softness derivative satisfies per coordinate

    |partial_s log j| ≤ 5/s+12.5t/s²+t.

At s≥1/(4n), its product sum is below 100n³. A closed grid of at most 102n³ nodes and spacing at most 1/(100n³) dominates all selected softnesses by an e factor. This step pays the actual joint softness/physical supremum, rather than promoting a fixed-softness bound to a varying selected parameter for free.

With d=1000 sqrt(log(n+2)/n) and t=d/12000, Jensen and the scalar mass bound give the exact exponent

    −tnd/2+3000nt² = −nd²/48000.

The resulting coefficient L_n=e(102n³)(1+10000nlog2)(n+2)^(−1000000/48000) is bounded by an absolute constant. All source mass is present and paid in the original spatial measure W_full.

## 3. Complete near-one strip, including mixed face atoms

The mixed physical/softness derivative estimate was checked independently. Write Q=sum a_s and S=sum w_s under the true product kernel. The regular part of the mixed derivative is

    P_s [Q(S−n)+sum partial_s w_s].

Cauchy–Schwarz gives 10sqrt(n)sqrt(28n+n²(1−s)²). The additional term costs at most 5n because, inside the hard core, psi_s partial_s w_s=r(−phi')/psi_s and psi_s≥phi/2. Outside this derivative is zero.

Differentiating the physical hard-face measures contributes both n, from differentiating 1−s, and at most 10n(1−s)sqrt(n), from differentiating the other coordinate densities. These atoms cannot be omitted. Together they give exactly the CS9 bound.

The two-parameter FTC uses the base mass 1, softness variation at the base physical scale, physical variation at the base softness, and the integral of the full mixed derivative TV. This proves CS10, including canonical face traces. A one-parameter softness bound plus a one-parameter physical bound would not justify it.

In the large regime d<1/2, all observed-score estimates are used only at s≥1/2. Substituting d gives terms of orders sqrt(n), n d, n^(3/2)d² and sqrt(n)d, hence T_n=O_A(sqrt(n)log(n+2)). For n≤4A²log(n+2), D(1+2nlog2), with D≤1+pi sqrt(n)/2, is bounded by C A²sqrt(n)log(n+2). The finite-regime fallback covers all softnesses and does not extrapolate the near-one Fisher estimate below 1/2. The large fixed A changes only an absolute constant.

## 4. Saved numerical ingredients and provenance

The frozen records contain 27 scalar softness rows, 108 tilt records and 14 tensor-moment rows, with tensor counts 4/4/6 across the three stages. All listed softnesses and tilts match the registration. The result-embedded registration/script hashes, all three run summaries and the terminal result hash match the current files. The scope file pins the same result.

Independently checking saved quantities, including conditions omitted from the script's aggregate passed flag, gives:

| Check | Saved maximum or minimum | Required bound |
|---|---:|---:|
| Regular-score second moment | 1.9901650911408884 | ≤28 |
| Observed-score second moment, s≥1/2 | 1.3195471302561805 | ≤100 |
| Mean softness derivative of regular score, s≥1/2 | .25374449066396787 | ≤5 |
| Absolute observed-score mean | 4.083376432123531e−16 | numerical zero |
| Probability-mass error | 5.551115123125783e−16 | ≤registered 1e−4 |
| Regular-score mean error | 1.554312234475219e−14 | ≤registered 1e−4 |
| MGF bound excess | −2.99950466140202e−7 | ≤0 |
| Scalar radial TV upper diagnostic | 2.0006030127285084 | ≤10000 |
| Canonical tilted jump | minimum 0 | ≥0 |

Every saved tensor CS9 formula and log ratio was reconstructed exactly in ordinary double arithmetic; maximum reconstruction discrepancy was zero. All 14 have s≥1/2 and a negative CS9 excess. The four large-regime rows all have n=268435456 and d=.2688882390656924. Only s=1−d is away-band eligible; the other three are near-one ingredients. The separate scope file correctly treats their saved Chernoff fields as formula diagnostics, not qualifying original LOWTRACE outputs.

The script integrates the positive centered exponential remainder while using the analytic exact mass 1 and mean zero. It does not normalize a truncated density or numerically recenter it. Its positive omitted exponential tail is valid: outside the core phi(r)≤(1/2)exp(1/2−r), whose factor 1/2 cancels the two radial signs. The scalar BV tail also has a conservative analytic bound; for r≥32.5, phi''(r)≤exp(1/2−r)/(r−1/2), so the registered polynomial tail coefficient easily dominates the regular outside derivative tail.

The finite positive quadratures do not enclose their own errors. Accordingly saved fields named upper remain quadrature-plus-tail diagnostics, not interval-certified inequalities. Large tensor rows use product moment algebra from these scalar integrals. None is a source realization, a posterior independence test, a continuous FIRST certificate, or a spatial operator norm. No full-source weak exponent is inferred from these screens.

Pinned SHA256 values:

    registration e4843249f1d9beec3c31b02eb5ac313b39d916c46afd5fdeeb818ceef745eb92
    script       09cc290102d260634ab598d84fb0d841fe6c57c56bfda3c606e75db9347d4bf8
    results      77d53eca8e4e5b580a908d083c5bb892593badb275bcec149003704b78bd9d92
    run          1cda77c86e23e6aa193f599af2cc3cc8ebb55a0b72ed9716eb1b10c5fcdb59e0
    scope        950d71bfc21413eae48f5db02a5e27743e91c92567fa005f3c7777cdb0e15170

## 5. Complete-band integration and exact unpaid qualification

The root's separate compensated_integration_draft.md is also PASS. The legitimate procedure deletes TOP and LOWTRACE as OUTPUT sets first, charging

    lambda|TOP union LOWTRACE| ≤ (4/3)(T_n+L_n)W_full.

Then apply the existing complete CP proof on the remaining measurable original output subset. Its source-fixed forests, birth eligibility, dyadic bands, source coins, two selectors and all original qualifications persist; positive paid estimates remain valid on a subset. This gives

    lambda|E_band| ≤ P_MM
      +(128/63)J[A_n+Csq K_s sqrt(n)]W_hi
      +(4/3)(T_n+L_n)W_full +(128/63)R_H.

Here R_H is exactly the old CP R_* with x additionally restricted to HIGHTRACE. It retains the strict source-fixed hardeligible parent threshold, original complete-source FIRST and q, source-hi, GOOD, far/notLOW/high-marked conditions, both original winners and balanced weights. Parent eligible mass is still not actual captured mass. No shrinkage of that residual is established.

In particular R_* is a traffic integral, so inserting q times the removed output volume as a bound for its deleted part would need an extra row-cap factor. The draft correctly avoids that invalid substitution by reapplying CP on the retained rows. The direct output fee gets neither a coin factor 2 nor 128/63. Old output/pair/source fees occur once, and W_full cannot be replaced by W_hi.

The complete arbitrary-L1 endpoint continues to use the accepted smooth-source transfer. This auxiliary trace partition is established for every complete smooth approximating source, with uniform constants; no convergence of the trace selector or high-trace residual is asserted. A uniform payment of the still-unpaid smooth high-trace residual would suffice for the weak-limit passage. The present result does not supply it.

Pinned audited proof SHA256: ee34d19fe9d99d8404af6b53b8db6fc467561ca398743a057ee3da6042857a5f.
Pinned integration-draft SHA256: 929824f894d4a50c69457d8e36a616b64349a73d677886aff0c5c0b8df149112.

Conclusion: formulas, numerical scope/provenance, and the stated complete-band substitution pass. HIGHTRACE remains unpaid; the general square-root endpoint remains open.

## 6. Root integration correspondence

The subsequently integrated main section `概率接口阶段证明.tex`, beginning at line 3107, and `GENERAL_CAPACITY_TREE_LEDGER.md` §8 / `GENERAL_CURRENT_REDUCTION.md` §18 were checked against the audited proof and output-deletion draft. **Correspondence PASS.** The TeX and `.tex.txt` mirror are byte-identical at this check. No numerical rerun or compilation was performed by this reviewer; the root's reported built-in compilation success is separate from this correspondence audit.

The main text retains the full original smooth-source stationarity, actual centered score moments, nonmonotone inside-face cusp, complete scalar BV and hard jumps, both parameter-envelope costs, full near-one mixed hard-face terms, and the finite-regime fallback. Its displayed parameter supremum extends the physical interval to [a,2a], which is a legitimate positive enlargement of the original [a,b]. The direct output term is exactly `(4/3)(T_n+L_n)W_full`. It has no 128/63 or source-coin factor. The old CP fee remains once, and its residual is only restricted by the original output HIGHTRACE event, retaining the original forest, source-heavy, source-hi, GOOD, birth, both-scale and fractional-weight qualifications.

The main text explicitly rejects replacing deleted traffic by q times output volume, states that the high-trace term is unpaid, and makes no trace-selector convergence or general endpoint claim. Numerical scope matches all 27/108/14 records and the one-of-four away-qualified large-row restriction. The ledger sections preserve the same formulas and scope. All three integrated presentations therefore express the accepted partial output refinement without enlarging its conclusion.

Integration snapshot SHA256: TeX and mirror `f42e8265211a4b7503ffe31d02b7aa8d2ade0bc8edc19fa2536b3cb71b2f7a59`; capacity ledger `851b8510afd5d9831eea9a5b5995726efcbe56379723cfa021aca982037899a4`; current reduction `a3957047b50eef9d67d005e5d714319b1cfb14c6956705410bf6cad390f9455f`.
