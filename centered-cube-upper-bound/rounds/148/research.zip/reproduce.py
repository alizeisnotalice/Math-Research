"""Replay R148 final numerical artifacts using minimal archived inputs."""
from pathlib import Path
import argparse,json,zipfile,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--rounds',required=True,type=Path);ap.add_argument('--destination',required=True,type=Path);a=ap.parse_args();dst=a.destination.resolve();dst.mkdir(parents=True,exist_ok=False);rounds=a.rounds.resolve()
for n,member,rel in [(139,'active_traffic_v2.json','centered_cube_round136_20261014/active_traffic_v2.json'),(142,'numeric_receiver.json','centered_cube_round142_20261015/numeric_receiver.json'),(143,'numeric_flux.py','centered_cube_round143_20261015/numeric_flux.py')]:
 with zipfile.ZipFile(rounds/str(n)/'research.zip') as z:
  p=dst/'inputs'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(member))
def norm(v):
 if isinstance(v,dict):return {k:norm(x) for k,x in v.items() if k not in {'elapsed_seconds','executed_utc','finished_utc','started_utc','input_root','archive','r147_archive'}}
 if isinstance(v,list):return list(map(norm,v))
 return v
for stem in ['dual_check','optimal_budget','early_geometry','soft_band_check']:
 for suffix in ['.py','_plan.md']:
  p=ROOT/(stem+suffix)
  if p.exists():shutil.copy2(p,dst/p.name)
 cmd=[sys.executable,str(dst/(stem+'.py'))]
 if stem in ['optimal_budget','early_geometry']:
  cmd+=['--input-root',str(dst/'inputs'),'--archive' if stem=='optimal_budget' else '--r147-archive',str(rounds/'147/research.zip')]
 subprocess.run(cmd,check=True)
 result=json.loads((dst/(stem+'.json')).read_text());frozen=json.loads((ROOT/(stem+'.json')).read_text())
 assert norm(result)==norm(frozen),stem
 print('VERIFIED',stem,flush=True)
print('PASS four final producers; mathematical fields compared, runtime timestamps/durations and relocated input paths excluded')
