# R148 Sol 独立预审：全早段预算、真实覆盖与放松对偶

状态：只读 r147_research.tex 必要定义，未读本轮作者新稿。以下从同一原实际行独立计算；不修改他人文件，不 Git，不重跑数值。

## 1. 全早段覆盖的预算准确是多少

固定原实际 \((\omega,V,j,x,y)\)，在 t 和外 hard 来源积分前固定原 \(Q,p,q,\nu,G,\rho,L_g\)。沿原定义
\[
d\mu=Qd\nu/q,\quad L_t=Kq/(pe_t),\quad
r_t=KQ/(pw_t),\quad E=G\cap\{\rho>0\},\quad z_v(t)=\rho_v/r_t(v).
\]
\(\Pi_t=1_{Z_t}L_t\mu/r_t\)、\(L_t\le L_g\)，且 E 属于 terminal \(Z_g\)，故在整窗 \([\tau,h]\) 存活。z 连续非增，\(-dz_v=k_t(v)z_vdt/t\)。此处 z 是通量变量，不是外 hard 来源。

原预算定理用 \(c_v=a(v)/(2NL_g)\)，门为 \(z_v(t)\le c_v\)。所以
\[
a_{full}(v)=2NL_g\,\rho_v/r_\tau(v)
\]
确实充分覆盖 E 的整窗；但预算准确为
\[
\boxed{\begin{aligned}
B_{full}
&=2N\frac{L_g}{L_\tau}\int_E\rho_vd\Pi_\tau(v)\\
&=\frac{2N}{e_g}\int_E\rho_vw_\tau(v)d\nu(v)
=2N\int_E\rho_v\frac{w_\tau(v)}{w_g(v)}d\Pi_g(v).
\end{aligned}}
\]
它是原 terminal posterior 的**带真实 \(\rho w_\tau/w_g\) 权矩**，不是自动等于无权 good 质量。即使额外 \(w_\tau=w_g,\rho=1\)，旧 high 的 \(\Pi_g(G)\le1/2\) 也只给 \(B_{full}\le N\)，不是 \(\le1\)；一般 \(w_\tau/w_g\ge1\) 还有真实费用。

预算定理若按总预算 B 计费，其正通量帽是 B/(2N)。代入 \(B_{full}\) 后 N 完全消失。保留终点精确下降量则有
\[
L_g\int_E[z_v(\tau)-z_v(h)]d\mu(v)
=\frac1{e_g}\int_E\rho_v[w_\tau(v)-w_h(v)]d\nu(v),
\]
回到旧完整逐来源 FTC 价格。只有另证 \(B_{full}\le1\)，才能用此 a 覆盖全窗且保留 \(1/N\)；这本身就是待付的原带权质量条件。若 \(B_{full}>1\) 后将 a 除以 B，门变成 \(z_t\le z_\tau/B\)，通常重新丢失早时段。

\(a_{full}\) 是覆盖几何整窗的充分预算，不必是覆盖**实际**正交通的最小预算：FA、\(\Psi\)、bad 后验或 history 可使部分早时段无正质量。更小预算须利用这些原门证明，不能按当前 t 重选 a。

## 2. 真实覆盖优化须保留实际 bad posterior

先固定一个外 hard 来源及原资格，令 \(\chi(t,v,u)\in[0,1]\) 包含原 \(\Psi\)、FA、low、history、旧已付补集，\(\rho\) 单列。定义
\[
\beta_v(t)=\int_{D_0}\delta_t(v,u)\chi(t,v,u)d\Pi_t(u),
\qquad 0\le\beta_v(t)\le k_t(v)\Pi_t(D_0)\le k_t(v).
\]
同一预算 a 的真实来源/时间覆盖准确为
\[
\mathcal P[a]=\int_EH_v(a(v))d\mu(v),\quad
H_v(a)=\int_\tau^hL_tz_v(t)\beta_v(t)
1_{\{z_v(t)\le a/(2NL_g)\}}\frac{dt}{t}.
\]
不能把 \(\Pi_t(D_0)\) 或 \(\beta_v\) 换成 1 后仍称为实际覆盖。若原定理要求 a 在外 hard 来源积分前共同固定，优化时须先把外 hard/history 权积入同一 \(H_v\)，不能对每个正在积分的 hard 来源各选一个 a。

在 \(k_t(v)>0\) 上沿 z 的下降量推前，其实际密度为
\[
f_v(z)=L_{t(z)}\frac{\beta_v(t(z))}{k_{t(z)}(v)},
\qquad0\le f_v(z)\le L_{t(z)}\Pi_{t(z)}(D_0)\le L_g.
\]
常值段 \(k_t(v)=0\) 时 \(\delta=\beta=0\)，没有额外推前原子。置 \(A_v=z_v(\tau)\)、\(B_v=z_v(h)\)，便有
\[
H_v(a)=\int_{B_v}^{\min\{A_v,a/(2NL_g)\}}f_v(z)dz,
\]
上限低于 B 时按 0 解释。所有原门和坏后验随 t 的真实变化仍在 f 内；f 一般不单调，所以 H 不自动凹。

## 3. 优化方向及有限 KKT 结论

最大真实覆盖的问题是
\[
\sup_{a\ge0,\ \int_Ea\,d\mu\le1}\int_EH_v(a(v))d\mu(v),
\]
等价于在相同原总交通下最小化余部。可截为 \(0\le a\le a_{full}\)。若 profile 可微且乘子正则条件成立，内点一阶条件是
\[
H'_v(a)=\frac{f_v(a/(2NL_g))}{2NL_g}=\lambda.
\]
边界分别为 \(H'_+(0)\le\lambda\)、\(H'_-(a_{full})\ge\lambda\)，并有 \(\lambda\ge0\)、\(\lambda(1-\int a\,d\mu)=0\)。应按**实际** profile 排序，而非只按 \(r_\tau\) 或 \(\rho\)。

非凹时这些仅为适用正则条件下的局部必要测试，不是一般全局水位定理。始终正确的充分全局证书是：同一个 \(\lambda\ge0\) 下，每个 a(v) 全局最大化 \(H_v(a)-\lambda a\)，同时预算可行、互补条件成立。仅相同边际导数不足以证明全局最优；此处不声称一般存在最优分配或强对偶。

## 4. 主代理转发的通量放松对偶

现在**明示放松** \(f_v\le L_g\)。用帽 c，成本为
\[
\int_Ec_vd\mu(v)\le C:=1/(2NL_g),
\]
放松收益为
\[
\Phi[c]=\int_Eh_v(c_v)d\mu(v),\quad
h_v(c)=\min(A_v,c)-\min(B_v,c).
\]
真实覆盖仅满足 \(\mathcal P[a]\le L_g\Phi[c]\)。对任意 \(\lambda\ge0\)，逐源精确计算为
\[
\sup_{c\ge0}[h_v(c)-\lambda c]
=[A_v-B_v-\lambda A_v]_+
=[(1-\lambda)A_v-B_v]_+.
\]
最大值可在 c=0 或 c=A 取得；\(\lambda=0\)、A=B、A=0 的退化也符合。因此任意可行分配有
\[
\boxed{\Phi[c]\le\lambda C+
\int_E[(1-\lambda)A_v-B_v]_+d\mu(v),\quad\lambda\ge0.}
\]
可对完整右端再取 inf。这是正确弱对偶上帽；取 \(\lambda=1\) 就回到已有 \(\Phi\le C\)，不凭改写新增付款。

**原子激活 gap 存在。** 取 \(\mu=\delta_v\)、A=1、B=1/2、C=1/4。任何可行 c≤1/4 均无通量，放松 primal=0；对偶最小值在 \(\lambda=1/2\) 为 1/8。不能一般宣称强对偶、只选 c=0/A 即可填任意预算，或把同一物理原子拆成几个来源。激活区 c≤B 也直接显示非凹性。

这个例子是所写放松优化问题的原子反例，未认证原核/high 全部联合实现性；它足以否定未加额外条件的放松强对偶说法，不作为原一般目标的反例。

若另假设原 μ 无原子，可研究阈值层的可测子集选择，但可实现性、预算等号及强对偶须单独证明；一般共同 ν 允许原子，不能以允许分源替换原输入类。

方向尤其重要：最大化 \(\Phi\) 是最大化**真实覆盖的上界**，不等于最大化 \(\mathcal P\)。实际 bad 后验可在某些高放松收益时段为零，放松最优分配的真实覆盖因而可以很差。覆盖上界不能从原总交通中按同值扣除来证明余部小；需要所选 a 的真实覆盖下界，或实际补集的直接上界。

## 5. 后审接受标准

须分别标明预算可行、几何门覆盖、实际正交通、放松目标、弱对偶。所有 a/c 和 λ 按原定理在整条 t 窗及外 hard 来源积分前固定；\(\mu,L_g,\rho,\Pi_t\) 不用删截后的来源重算。原 FA、\(\Psi\)、bad 质量和 history 的删除只产生已说明的正放松，不返还负预算。

优化或数值须报告实际坏后验/严格门下的收益与补集，而不只报 \(\Phi\) 或对偶值。原子 gap、终点 B、全早段预算中的 \(w_\tau/w_g\) 均不能删除。全目标及全部未付来源/时间/接收层级继续保留。独立先审结束，等待指定后审材料；不扩展历史或样本。

## 6. allocation_dual 与有限有理检查的后审

已读作者 allocation_dual.md、dual_check.py/json，当前 SHA-256：

- allocation_dual.md：ebdffb715fe9483ea0291c3d3a479d8f80415ab7ce29748bc73e2265569b0bbe
- dual_check.py：6c206860256d241834be1b0a289015ccbd3616c167991b16aaae7c8db4ff386d
- dual_check.json：7d5d8220885b7283ac706c84b1291170cbc9abfff2757c3b6d0b73cac67e7bad

逐源三段证明、非负积分后的共同 λ 弱对偶，以及把 λ 限于 [0,1] 均符合第 4 节独立推导。实际 traffic 与放松 F 明确区分，未宣称原子强对偶或原总付款。程序的枚举正是 81 组 A/B、21 个 c、17 个 λ，共 28917 个有理不等式检查，与输出数一致；这是有限代数 sanity check，普遍命题来自逐点证明，不依赖枚举覆盖。JSON 的 atomic_gap 是记录的解析短例，不是枚举程序另算的优化值；本审计已独立算得第 4 节的 primal/dual 值。

**平台成本须精确区分。** A=B 的来源没有正通量，因此最小完整通量预算无需支付该来源的 A。对放松通量问题，覆盖全部正通量的最小帽为
\[
c^{flux}_{min}(v)=A_v1_{\{A_v>B_v\}},
\]
对应成本 \(\int_{E\cap\{A>B\}}A\,d\mu\)。作者正文在阈值充要声明中已排除 A=B；后面 \(\int_E A\,d\mu\) 被称作**充分**预算，仍合法，但不能将它提升为一般最小预算。本审计第 1 节同样只将全 E 的 a_full 称为充分预算。

**实际门首时刻的定义建议。** FA 自身依当前 pair (v,u)，与实际 bad posterior、正 score 和 history 的非零性不同。如果要从首时刻求“实际全部正交通”的最小帽，应使用
\[
A_v^{act}=\operatorname*{ess\,sup}_{t:\ L_tz_v(t)\beta_v(t)>0}z_v(t)
\]
（ess-sup 对原时间测度；空支持取 0），而不是未说明的仅 FA 首时刻。以原 \(\beta_v\) 聚合 pair 后，\(\tau_v\) 的相应单侧 z 极限可给同一值；a 仍固定整窗。当前稿的 FA 首时刻句可作为覆盖 FA 之后全窗的充分方案，但若作者希望表达最小实际预算，须按此澄清。该点已通知主代理。

待上述文字澄清/短例是否修订确认后绑定最终正文；一般弱对偶数学本身已通过，继续等待 optimal_budget 的真实目标证书，不扩展数值。

## 7. allocation_dual 最终修订绑定

最终正文 SHA-256：
`65542eb76bf8c4da5d710cd05f56ff25e14e54f4447300409d58e5705953f84c`。

已核正文补入原子 primal 0／dual 1/8 的短例，并将实际覆盖门阈值改为聚合全部 bad 来源之后真实正密度时间支持的 ess-sup；不再仅凭 FA 自身首时刻断言最小实际成本。A>B 的完整正通量阈值与全 E 的充分预算明确区分。第 6 节两项文字风险已解决。dual_check.py/json 的绑定 SHA 保持不变；普遍逐点弱对偶及有限检查声明范围通过，无剩余更正。

## 8. optimal_budget 真目标与全局证书审查

已逐行读 optimal_budget.py、冻结计划、JSON 和说明。最终 SHA-256：

- py：`49965edfce30b70da2f37c16f3ea6e13f2a3ecdaff849e00c52d34c99c87cabf`
- plan：`d87596b3f50e670aaacb9c3fa793f78daab791576f9099d8c8de54e6edf0c87b`
- json：`f4c64bba9dc750de21b5a1129bdff74dc098e425c7967e8f7a3110b893d4bec0`
- notes：`eeef6297bc6235504007ca584326699c1e7120a4a8027ee4c3bb5c909be80f2c`

输出内 archive、成员、原 R136/R142 输入、script 和 plan SHA 已核对实际文件。本审计未重跑 producer 或浮点优化。

**原预算与全覆盖证书正确。** 代码用 \(b_i=\mu_i a_i\)，其原门精确化为
\[
b_i\ge d_i(t)=2N\nu_i\rho_iw_i(t)/e_g,
\qquad\sum_i b_i\le1.
\]
原 \(\mu,Q,q,\nu,e_t,\rho\) 均未重算；E+ 中无实际接受 FA 交通的来源可以分配 0，但其质量及六源 e 分母仍保留。每源 full b 是其全部**原正 FA caps 与原 score 段交集**左端成本的最大值；cap 内正 score、\(\rho\)、bad、\(\Psi\)、正长度均核实。因此 endpoint 单调包含可证全时间覆盖，而不是中点命中或将 bad posterior 置 1。

**I1 真目标闭式正确。** 原积分保留 \(e=A t^{-4}+B\) 的六源分母及实际 bad 源质量。令 z=t^-4，\(\delta=4\) 与 \(-dz=4zdt/t\) 恰抵消，得到 active 段
\[
f_i(b)=\frac{R_i(b-l_i)}{A b+B D_i},\quad
f'_i(b)=\frac{R_i(A l_i+B D_i)}{(A b+B D_i)^2}>0,
\quad f''_i(b)<0.
\]
系数 R 与代码一致，包含原 hard/p/q 外因子、\(\rho\nu_i\nu_{bad}c_ic_{bad}\) 及端点分母。它不是第 4 节的放松通量目标。

**活跃子集枚举完整。** b≤l 无收益可改成 0，b≥u 可截到 u，所以每源 inactive 0／active [l,u] 覆盖全局。三个接受通道给 8 个子集，每个子集先核最低预算；active 盒内 f 凹，任一有理可行点给下界，其精确切线给全盒上界。按有理切线斜率降序的 bounded linear knapsack 精确最大化该上线性函数。因此对各盒取最大上、下界是全局证书，未将非凹总问题直接水位化。

## 9. 独立有理证书复核结果与边界

本审计实际以 Fraction 从**原 R136/R142 输入**重新形成 179 行的 FA 端点 full 成本、I1 的闭式系数和全部输出证书，未调用作者浮点建议器。结果：

- 168 行 P1 的原 cap 端点预算确实全部可行；所选 b 覆盖全部接受 caps，100% 最优由域包含及非负原目标上界证明。
- 11 行 I1 的闭式模型系数逐项相等；每行恰有全部 8 子集，共 88 个子集记录。可行标记、候选预算、真实有理下值、切线斜率/截距、精确线性 knapsack 上值全部一致。
- 11 行的全局上值等于可行下值，Fraction gap 为 0，所选 b 都为 (1,0,0,0,0,0)。全部预算等式 \(\sum\mu_i a_i=\sum b_i\le1\) 精确成立。

I1 全覆盖预算大于 1 且最优仍有正残余，作者没有隐藏早段失败。汇总用旧 archived whole-F 作为有限记录展示权，说明已明确其不是 dx 积分；P1 的极小旧余部被覆盖，也不推出一般输入全覆盖。上述“最优”限于同一保存六源 FA／时间模型和允许的固定源预算；不认证真实核/FULL，不证明一般可测来源选择公式或任意相关 ν 的全局根阶结论。完整外层与未付余部继续保留。

最终：allocation_dual 与 optimal_budget 均在其声明范围通过；一般目标未闭合。仅修改本审计文件，未 Git、未改他人文件、未新增采样或 producer 执行。本次分配范围结束。

## 10. early_geometry 的最后有界后审

已读 early_geometry.py/json/notes，并核对实际导入的 R143 primitive 有 main guard；没有运行历史 producer。最终 SHA-256：

- py：f8006b315f8245b497c9f8a40a13703dd0f4bda2c19cbf3cb72edf9126810043
- plan：d50534562b0ee39a4c65ed9b78121ffc0c9376c8992adad491840af2538a45cc
- json：db6e8cbd514c5f4c0e50d5c71fb0fe0b7d1eaa2a7df8cf86e7e222789c1f1ed6
- notes：04321a8539137243c899e66187cb11784e350fb51a677126f4cee2534c3908fe

JSON 内 script/plan SHA 已核对。其余部明确是 **R147 原均分/shared-slack 门的余部**，不是 R148 最优 G1 分配的余部；两种对象不能混算覆盖比例。

**两帽定义及窗口通过。** 对同一原 FA/\(\Psi\)/正 score 与该余部窗口，真实 I 用 \(\rho\delta\Pi_v\Pi_u\)，\(U_B\) 仅将 \(\delta\) 换成 \(k_v\)，保持原窗口内 eligible bad 的 \(\Pi_u\)；\(U_0\) 才把该 eligible bad 因子上界成 1，仍保留 v 的原余部窗口。它不是先删 FA 后再领取其收益。全部 690 cap 的 bad 源为 G4；代码及输出均核到每个 receiver 的 (v,score-segment) cap 至多一条，因此 U0 对每个 v 窗口只算一次，没有按多个 bad 来源重复付款。该实现边界是本冻结菜单，不能自动外推到多 bad 重叠窗口；后者须先作 union。

代码按 R147 exact entry power 恢复余部结束点，保留 original/effective FA 端点、full/empty/partial 情形，未用打印时间中点或 65 位 entry 替代完整时间。与原行残量的数值比较不替代输入/窗口定义，但本次符号模型与之相同。已有 JSON 中 690 cap 的 \(0\le I\le U_B\le U_0\) 次序逐条核对通过。

**独立一条 I1 解析核查。** 本审计只取原 initial receiver244 的三个 cap，直接从 R136/R142 重建同一六源
\(e=A t^{-4}+B\)、原 \(\nu,\rho\) 与 cap。若 \(x_0=lo^{-4}\)、\(x_1=right^{-4}\)，其实际单 pair 余量为
\[
I_{vu}=\rho_v\nu_v\nu_uc_vc_u
\frac{x_0-x_1}{(Ax_0+B)(Ax_1+B)}.
\]
partial 情形的 \(right^4\) 是原有理 entry power，故这条 I 可以直接用 Fraction 核对，无须近似求根。对应删 bad 帽为
\[
U_{0,v}=\rho_v\frac{\nu_vc_v}{A}
\log\frac{Ax_0+B}{Ax_1+B}.
\]
使用独立公式得到该 receiver 外因子后 I 约
0.000720099799007820493469970367790，
U0 约
0.00147989993041443303305290163261；
三个 cap 相对输出差分别不超过约 \(7.10\times10^{-161}\) 与 \(4.60\times10^{-160}\)。I1 的 \(\delta=k_v=4\)，所以 \(U_B=I\)；约两倍放大来自丢 eligible bad posterior，不是丢一份 e 后的原 \(\nu\) 小质量。

**P1 半比例已体现在帽中。** 输出的 153 条正 P1 余部 cap 均为 \(k_v=16,k_u=8,\delta=8\)。代码显式取 \(U_B=I\,k_v/\delta=2I\)，保存值与 2I 的差仅约 \(2.97\times10^{-160}\) 的打印舍入。故 P1 的 \(\delta/k_v=1/2\) 没有被遗漏或错误算作 bad 质量收益；\(U_B/U_0\) 接近 1 与 actual I 再少一半是两个不同步骤。三 score 的 U0 原函数经符号微分也与 \(2\nu_vc_v\int du/[u(A+Bu+Cu^2)]\) 相符。

本次只独立核一条 I1 行、保存 P1 score 结构和证书元数据，没有重跑完整菜单。原产物的 100/160 位相合、解析根/驻点、R147 相合仅作为多精度**非区间**诊断；它们不认证真实核或原 FA/root 标签的机器区间误差，不给 dx/global 付款。声明范围通过，无需更正；本轮分配范围结束，停止。

