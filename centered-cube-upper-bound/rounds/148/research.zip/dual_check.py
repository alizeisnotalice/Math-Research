"""Finite exact checks; the general algebraic proof is in allocation_dual.md."""
from fractions import Fraction as F
from pathlib import Path
import json
checks=0
for A in [F(i,4) for i in range(9)]:
 for B in [F(i,8) for i in range(int(A*8)+1)]:
  for c in [F(i,8) for i in range(21)]:
   for lam in [F(i,8) for i in range(17)]:
    assert min(A,c)-min(B,c)-lam*c<=max(F(0),A-B-lam*A)
    checks+=1
Path(__file__).with_suffix('.json').write_text(json.dumps({'scope':'finite exact rational sanity check, proof in allocation_dual.md','cases':checks,'passed':checks,'atomic_gap':{'A':'1','B':'1/2','budget':'1/4','primal':'0','dual':'1/8'},'not_general_closure':True},indent=2)+'\n')
print('PASS',checks)
