# R148 Astra 独立先审：good 后验势、协方差及删除的准确时间账

本稿在作者新证明前独立推导，只核原 R128 RT2–6 与 R147 已审 RN/时间合同，不读本轮作者正文。固定同一实际行的 p、q、Q、共同 ν、terminal G=S_g 与 ρ；0≤ρ≤1，G⊂Z_g。只写本文件，不 Git、不改他人文件。目标是给可直接验算的恒等式，不把未控制的修正项当反例或宣布路线失败。

## 1. 两个不同的时间势

用 u=log t 表示时间（以下来源对记 v,w，避免混淆）。令
\[
f(v)=\rho_v1_G(v),\quad
M_t=\int f\,d\Pi_t,\quad
A_t=\int_G\frac{\rho_v}{r_t(v)}d\mu_Q(v),
\]
\[
d\mu_Q=Qd\nu/q,\quad r_t=KQ/(pw_t),\quad
L_t=Kq/(pe_t),\quad M_t=L_tA_t.
\tag{AP1}
\]
RN 完整版本为 \(d\Pi_t=1_{Z_t}L_tr_t^{-1}d\mu_Q\)；G 是 terminal 存活集合，所以 AP1 的 A 不再含变化的 Z。A 是未归一的固定来源势，M 是实际后验质量。它们的导数不能混用。

逐源 w_t 连续 AC，\(\partial_u w_t=-k_tw_t\)，故
\[
-A'_u=\int_G\rho_vk_t(v)r_t(v)^{-1}d\mu_Q(v)\ge0.
\tag{AP2}
\]
A 单调且无删除跳；M 同时受来源权下降和 e_t 归一化影响，未必单调。坐标阈值改变 k 的取值，不给 w、A 或固定支持后验额外阈值原子。

## 2. 固定支持：负导数恰为协方差，而非正交通

在没有删除的时间部分，\(e'_u=-e_tE_{\Pi_t}k_t\)。商法则给
\[
\boxed{-M'_u=\operatorname{Cov}_{\Pi_t}(f,k_t)
=E_{\Pi_t}(fk_t)-M_tE_{\Pi_t}k_t.}
\tag{AP3}
\]
这一式不要求 ν 或 Π 坐标独立，也不假设 good/bad 的 score 全序。

定义完整 pair 图上的
\[
D_\pm(t)=\iint(f(v)-f(w))_+
\bigl(\pm[k_t(v)-k_t(w)]\bigr)_+d\Pi_t(v)d\Pi_t(w).
\]
交换 v,w 可直接核得
\[
\boxed{D_+-D_-=\operatorname{Cov}_{\Pi_t}(f,k_t).}
\tag{AP4}
\]
这里没有遗漏1/2：\(\frac12\iint(f(v)-f(w))(k_v-k_w)\) 是协方差，而单侧 f 正差已经完成相应对称化。

原正项在 G×bad 上的系数为 ρ_v，bad 上 f=0；原 Ψ、FA、旧未付等正门均≤1。因此在域匹配的正放松后，原 P_t≤D_+(t)。但 D_- 是**完整图新比较中的反向量**，并非原 Ψ 图内的负预算；不能把原 N_Z/N_del 直接认作 D_-。从 AP3–4 只能得到 signed 差的端点，正通量还要保留反向量。

## 3. 实际 Z_t 递减：连续删除与跳跃

取相容右连续版本，记 \(\chi_t(v)=1_{Z_t}(v)\)。对任意固定 f∈[0,1]，定义非负删除流
\[
d\mathcal D(u,dv)=w_{e^u}(v)d\nu(v)[-d_u\chi_{e^u}(v)],
\quad d\mathcal D_1=\int d\mathcal D,
\quad d\mathcal D_f=\int f\,d\mathcal D.
\]
这是源被删除产生的测度，可含原子、连续及奇异连续部分。则
\[
de=-eE_\Pi k\,du-d\mathcal D_1,
\quad d(eM)=-eE_\Pi(fk)\,du-d\mathcal D_f.
\tag{AP5}
\]
在 e>0 的连续部分，准确为
\[
dM^c=-\operatorname{Cov}_\Pi(f,k)du+
\frac{M\,d\mathcal D_1^c-d\mathcal D_f^c}{e}.
\tag{AP6}
\]
若在某删除时 e_-→e_+>0，令 \(\ell=e_--e_+\)、\(\ell_f=(eM)_--(eM)_+\)，则
\[
\boxed{\Delta M
=\frac{M_-\ell-\ell_f}{e_+}
=\frac{M_+\ell-\ell_f}{e_-}.}
\tag{AP7}
\]
不能在跳项中把 e_+ 与 e_- 任意互换。一般 f 的删除跳可正可负；对本轮 \(f=\rho1_G\)，G⊂Z_g，删除源上 f=0，故 \(\mathcal D_f=0\)、\(\ell_f=0\)，连续删除补偿及删除跳都非负。

将 AP6 的删除部分和 AP7 的跳总和记为 C_del。正 terminal 质量行上有 e_t≥e_g>0，所有商合法；其完整恒等式是
\[
\boxed{\int_\tau^h\operatorname{Cov}_{\Pi_t}(f,k_t)\frac{dt}{t}
=M_\tau-M_h+C_{del}.}
\tag{AP8}
\]
对 terminal f，C_del≥0，并可保留粗帽
\[
C_{del}\le\int\frac{d\mathcal D_1^c}{e}
+\sum\frac{\ell}{e_-}\le\log(e_\tau/e_h).
\]
这是明确归一化费用，未证明是已付常数；尤其不因名字“删除”就与原 N_del 相消。e_h=0 的灭绝行不能套含 e_+ 的式子，须按原零交通规则单列；原 high 的正 terminal 行避免该情况。

## 4. 可直接用于正交通的完整时间身份

AP4、AP8 直接给
\[
\boxed{\int_\tau^hD_+\frac{dt}{t}
=M_\tau-M_h+C_{del}+\int_\tau^hD_-\frac{dt}{t}.}
\tag{AP9}
\]
它是原 P 正放松后的准确上界接口。若要删反向项，须证明相应 score 同序或别的实际比较，不能由 good/bad 名称推出。

另一个不补完整 pair 图的粗正接口为 \(U_t=E_{\Pi_t}(fk_t)\)。bad Π 质量≤1且 δ≤k_v 给 P_t≤U_t。由 AP2、M=LA 及 Stieltjes 乘积法则，
\[
\boxed{\int_\tau^hU_t\frac{dt}{t}
=-\int_\tau^hL_t\,dA_t
=M_\tau-M_h+\int_{(\tau,h]}A_t\,dL_t.}
\tag{AP10}
\]
A 连续，因此最后一项在 L 删除跳上用同一 A 值无歧义。进一步准确分解为
\[
\int A\,dL
=\int_\tau^hM_tE_{\Pi_t}k_t\frac{dt}{t}+C_{del}.
\tag{AP11}
\]
归一化漂移是非负项，不能把 AP10 写成只有 M 的端点。由于 L_t≤L_h，另有合法上界
\[
\int U_t\frac{dt}{t}\le L_h(A_\tau-A_h)
=\frac{e_\tau}{e_h}M_\tau-M_h.
\tag{AP12}
\]
它保留真实质量比，不自动给统一费用。R147 截顶门之所以能把 AP2 变成可付帽，是其准确限制了每源未归一势高度；这一资格不能无门移植为 M 的单位端点帽。

## 5. 如坚持保留原 Ψ signed 槽，应检查的精确拆分

令 D₀ 为 terminal bad，\(\Delta=k_v-k_w\)，并保持原正系数 χ∈[0,1]（删除旧已付正支时用 χ_eff）。定义
\[
X_t=\iint_{G\times D_0}\Psi\rho_v\Delta\,d\Pi_t^2,
\quad
H_G(t)=\frac12\iint_{G\times G}(\rho_v-\rho_w)\Delta\,d\Pi_t^2,
\]
\[
H_{miss}(t)=\iint_{G\times(Z_t\setminus G)}\rho_v\Delta\,d\Pi_t^2-X_t.
\]
则逐时刻精确为 \(\operatorname{Cov}(f,k)=X_t+H_G+H_{miss}\)。H_miss 包含原缺 Ψ 边与未纳入 D₀ 的实际来源；它们都是 signed 量，不能假定符号。

原 terminal signed integrand 的逐 pair 身份为
\[
\rho\chi\delta_+-\delta_-
=\rho\Delta-[(1-\rho)\delta_-+\rho(1-\chi)\delta_+].
\]
令方括号在同一 G×D₀、Ψ 下的积分为 H_slack≥0，则
\[
\boxed{S_{terminal}
=M_\tau-M_h+C_{del}
-\int_\tau^h(H_G+H_{miss}+H_{slack})\frac{dt}{t}.}
\tag{AP13}
\]
H_G、H_miss 不能凭 good 标签丢掉。若另加原 futurebad−N_del，要按其真实域接回；H_miss 中为补全协方差而引入的 future 来源不是已经消费的 future 预算。AP13 是完整的一套身份，不能与另一个势的较小端点或缺边项逐项拼取。

## 6. 动态测试/时间窗的额外项

上述 f=ρ1_G 固定。若改用 f_t，例如当前未付门、似然门或时间改变的 good 集，连续部分须另加 \(E_{\Pi_t}(\partial_u f_t)du\)（或相应有限变差测试项）。同时有删除与测试跳时，准确写法为
\[
\Delta M=
\frac{\int_{Z_+}w(f_+-f_-)d\nu
-\int_{Z_-\setminus Z_+}wf_-d\nu
+M_-\ell}{e_+}.
\tag{AP14}
\]
这清楚区分进入新门的来源与实际被删来源，避免漏掉阈值激活质量。没有测试 BV/可积性时，不授予此种 Stieltjes 端点公式。

同理，任意时间门 χ_J 不能只拿全窗 M_τ−M_h；有限多个区间要对各自端点求和，BV 时间测试还保留 \(\int M\,d\chi_J\) 及同门删除补偿。若先对非负正项扩大到完整[τ,h]，则 AP9/10 可直接用，但反向/漂移项也随之完整保留。

## 7. 作者后审的最小验收条件

1. 明确用未归一 A 还是实际后验 M，写出所使用的准确身份；不混用两者导数。
2. 若以 M 端点支付正交通，保留 AP9 的 reverse，或 AP10–11 的归一化漂移；若用 signed 原图，则完整匹配 AP13 的 within-good、缺边与松弛项。
3. 删除跳按 AP7 的正确分母；terminal f 的删除补偿为非负。若声称抵消 N_del，逐项核时刻、来源、原门和系数。
4. 动态测试、再剪窗、t 依赖参数均有相应变化项；完整 FTC 不凭命名消去它们。
5. 新估计若确实控制上述项，给同一实际行完整数值帽或真实原外费用。源与时间消尽前不合并唯一 j；β、q、hard、两份后验及负账保留。单位端点本身仍不是总根阶价格。

**独立先审结论：** AP1–14 给出可直接核验的时间势接口。完整正交通可以由 good 后验端点**加上明确反向/漂移与删除项**控制；没有一般等式把它仅写成后验质量的净下降。是否这些保留项能进一步支付，留给本轮作者的新估计审查，不以该接口预断失败。完成先审，等待 time_potential/capacity 正文。

## 8. 本轮主新增：soft 分层与完整原外费用的独立后审

任务随后转为 `capacity.md` CAP3–CAP11。审查先从历史原件 `next_spatial_compensated_split.md` CS9–CS10 与 `compensated_split_review.md` §3 独立核算，再读本轮作者稿；以下结论不依赖作者自评。AP1–14 仅作为备用时间势接口，不是本轮主付款的证明。

**CS10 的简化通过。** 令 A=√nD，n≥1，原包络除以 √n 后为

\[
\frac{1+10A}{\sqrt n}+\log2\,[\sqrt{28}+8A+10A\sqrt{28+A^2}+10A^2].
\]

以 √(28+A²)≤√28+A、√28<5.3、log2<0.7 支配，常数项≤4.71、一次项≤52.7、二次项≤14。因此 CAP4 的 5+53A+14A²≤32(1+A)² 正确。此处使用完整连续 softness/物理尺度联合包络，CS9 的正则混合导数及两类硬面项均已包含；不能将它解释为固定 s 的核质量1。

**分带及门通过。** n≥64 时令 K=ceil(log₂(√n/4))、D_k=min(2^k/√n,1/4)。I₀=[0,D₀]、I_k=(D_{k−1},D_k] 恰为 K+1 个互斥近 soft 带；即使 √n/4 是2的整数次幂，最后一带也非空且无重复。n=64 时 K=1，带为 [0,1/8] 与 (1/8,1/4]。far=(1/4,1] 明确分配边界。每带 D_k≤1/4<1/2，历史包络资格充分。

N_k=(1+√nD_k)² 在该带全部 actual rows 为同一常数，严格小于 N₀=2n+3。实际选中的 s 在一行时间及外 hard 来源积分以前固定，故 k、N_k 不随 t、v、u、z 重选。R147 时间预算只需共同 a=1/m，因而给同层全部行完整来源及时间帽1/(2N_k)。可直接扩大每行的正时间门到该预算门；原 FA、Ψ、low/history、TOP 删除及旧付款补集只缩小正项。没有对不同来源或时刻重复动用一份 μ 的预算。

**完整费用通过，未遗漏 j 或时间价。** 来源与时间已消尽后乘原 hard 帽16/3，再乘 signed 系数2Λ，得到16Λ/(3N_k)。此时仍保留实际唯一 j 指示。对每个 ω,V,y，所选 p 可由同一近 soft 包络支配，并用 Σ_j1_{j(x)=j}≤1 后才积分 dx。于是

\[
2\Lambda P_{new,k}\le \frac{16\Lambda}{3N_k}\mathcal E_n(D_k)W_\beta
\le\frac{512}{3}\Lambda\sqrt n W_\beta.
\]

不能先分别积分各 j 再丢弃 j 的个数；作者 CAP7 没有这样做。β 全程是原外测度，未替换为 ν；Wβ 是原 EΣ_V||β_V||。时间已在1/(2N_k)内完整积分，故没有额外 log2，也没有省略隐藏的 time/j 预算。

每个 softness 带各付一次512/3，全部 K+1 带显式相加；不同带虽用相同 μ，费用并未免费合并。CAP8–9 的总价与旧 R147 的48Λ√n一次正确。新增严格取旧门下方差集 [2N_kL_gmρ,2N₀L_gmρ)，因此没有把已付 R147/FA/TOP 区重新认作新增覆盖。n<64 与 far 的 N=N₀，新增域为空；仍保留一次旧付款。结论只对原固定绝对比例带及其 Wβ 台账成立，不授权跨绝对尺度带另取无价上确界。

**等价门及余部通过。** 消去 p,q,K 得 CAP10 的 Q_x(v)e_g≥2N_kρ(v)w_t(v)∫E₊Q_xdν；Q 是原三核平均，e_g、ρ、E₊、共同 ν 全部保留。I₀ 的 N=4；其余近带 D_k≤2d，故 N_k≤8(1+nd²)。far 的 N₀≤35(1+nd²)，n<64 的 N₀≤131，足以推出 CAP11 的保守系数262。该统一门仅是锐分段门的子集，作者没有将两者覆盖精度混同。

**审查结论：CAP3–CAP11 通过。** 这是用已证整窗共同预算与历史连续接收几何联合得到的一般输入子支付款，价格 O(Λ√n log(2+n))Wβ；没有依靠 AP1–14 的时间势望远镜，也没有宣称消掉其逆向/漂移项。原新补集严格保留为 r_t<2N_n(1−s)L_gmρ，不能据此宣称 FULL 闭合。CAP12 后的必要约束模型未用于主付款审查，也不构成原三核 FULL 反例。本节未运行数值，有限样本结果不用于证明 CAP7–9。

## 9. 主稿对应及最终 SHA 绑定

`work/research.tex` 的来源合同、联合包络、完整分层、旧支去重、统一门及未付域与上述通过的 CAP3–CAP11 一致。主稿采用更简洁的 √28≤6，得到
\[
E_n(D)/\sqrt n\le26/5+(288/5)A+14A^2\le32(1+A)^2,
\]
其三个系数分别由 1+0.7·6、10+0.7(8+60)、0.7·20 得到，准确且对 n≥1 成立。总价为 n≥64 时 [48+(512/3)(K_n+1)]Λ√nWβ，小维仅旧48；near/far 边界、旧 TOP 输出删除、统一262只充分子门均没有在主稿中扩大。主稿再次明确固定来源时间预算用完以后才合并唯一 j，不曾按每 j 领取 Wβ。

本次最终绑定范围是主新增数学命题及其主稿对应；数值段的优化证书与有限记录比例不作为本审查证明依据，本审查也未重跑这些记录。备用 `time_potential.md` 的作者稿尚未在此绑定，AP1–14 是本审查独立给出的接口。

最终核验文件 SHA256：

- `capacity.md`：`7a70519d5f19221f5491b86335d7e6ab08a9be63413d079ab30bc98f9e47b540`。
- `research.tex`：`bfe94e40770a32f585e72e8505328144408b3c316dc7fe8a2db75c61037ff9c5`。

**最终结论：主新增 soft 分层付款及两稿对应通过；严格补集仍未付。** 本审查仅写 `audit_astra.md`，未改作者文件、未 Git、未编译 PDF。
