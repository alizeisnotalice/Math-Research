# R148：共同 λ 的时间积分检查点（未形成新增付款）

本检查点保留 R147 的真实共同来源证书，并定位其沿时间积分的障碍。逐对的三核对数势确实可计算；它不能控制每时刻重新取来源上确界的积分。以下不把该原函数、换测度或未付余项登记为本轮进展，不继续扩展此路线。

## 1. 精确对象与一个合法共同参数

固定原实际行及时间窗 \([\tau,h]\)，\(h<g\)。保留共同 \(\nu\)、递减的 \(Z_t\)、\(w_t(v)=\prod_i\min(1,a_i(y,v)/t)\)、\(e_t=\int_{Z_t}w_t\,d\nu\)、\(d\Pi_t=1_{Z_t}w_t\,d\nu/e_t\) 及 \(k_t(v)=-d\log w_t(v)/d\log t\)。所有商均在原正有限域，零交通行单独置零。原三核是
\[
 Q_v=Q_x^*(v)=\tfrac13[P_{s,L}(x-v)+P_{s,L^+}(x-v)+J_b(x-v)],\qquad d\mu=Q_v\,d\nu/q.
\]
它不是逐坐标混合后的乘积。记
\[
 r_t(v)=KQ_v/(p_xw_t(v)),\quad L_t=Kq/(p_xe_t),\quad L_g=Kq/(p_xe_g)\le\tfrac12.
\]
在此窗内 \(L_t\le L_g\)，而 \(r_t\) 连续不减；不对可能有删源跳跃的 \(e_t\) 微分。

\(G,B=D_0\) 为原 terminal good、bad，二者互斥。正抑制仍为
\[
 \rho_v=\left(1-\frac{DK_{0,v}+\alpha J_v}{TA_v}\right)_+,
 \quad A_v=w_\tau(v)-w_h(v),\quad\alpha=\mathcal R/Q_J,
\]
并保留原强制清零约定。令 \(E_+=G\cap\{\rho>0\}\)、\(m=\mu(E_+)\)、\(N=2n+3\)，当前剩余集合为
\[
 E_-(t)=E_+\cap\{r_t(v)<2NL_gm\rho_v\}.
\]
\(E_+,m,\rho,L_g\) 整行固定；不按时间或 score 改选来源，不归一化剩余 \(\nu\)。令 \(\delta_t(v,u)=[k_t(v)-k_t(u)]_+\)，\(\psi_t\in[0,1]\) 保留原未归一后缀 \(\Psi\)、旧 FA 未付门及其余原正门。欲付的仍是
\[
 P_-(t)=\iint_{E_-(t)\times B}\rho_v\delta_t(v,u)\psi_t(v,u)\,d\Pi_t(v)d\Pi_t(u).
\]

取一个整行共同且时间不变的 \(\lambda=1/L_g\)。R147 QE6 给出
\[
 P_-(t)\le\frac{(1+L_t/L_g)^2}{4}
 \mathop{\mathrm{ess\,sup}}_{E_-(t)\times B}
 \rho_v\delta_t\psi_t f_v(t)f_u(t)
 \le\mathop{\mathrm{ess\,sup}}_{E_-(t)\times B}
 \rho_v\delta_t\psi_t f_v(t)f_u(t),\tag{MT1}
\]
其中
\[
 a_v=\frac{e_gQ_v}{q},\qquad
 f_v(t)=\frac1{1+r_t(v)/L_g}=\frac{w_t(v)}{w_t(v)+a_v}.
\]
这是旧证书的合法实例，不是新增估计。\(a_v\) 使用实际三核、实际 \(e_g,q\)，没有假设来源独立或将 \(\beta\) 换成 Lebesgue 测度。

## 2. 可计算的逐对原函数及不可交换处

对每个固定来源对 \((v,u)\)，由 \(\delta_t\le k_t(v)\)、\(f_u\le1\)，有
\[
 \int_\tau^h \rho_v\delta_t(v,u)\psi_t(v,u)f_v(t)f_u(t)\,\frac{dt}{t}
 \le \rho_v\log\frac{w_\tau(v)+e_gQ_v/q}{w_h(v)+e_gQ_v/q}.\tag{MT2}
\]
右端直接来自
\(d\log(w_t(v)+a_v)/d\log t=-k_t(v)f_v(t)\)。断点不增加原函数跳项。MT2 中可加入当前补集指示后仍成立，因为只缩小非负积分；这里明确放松 \(\psi_t\le1\)，不改动任何原负项。若 \(\rho=0\)，左右均为零。

MT2 的对数保留三核接收位置，因此比先把所有核比扔掉更有结构；但它只是一条固定来源的时间计算。MT1 需要的是
\[
 \int_\tau^h\operatorname{ess\,sup}_{(v,u)\in E_-(t)\times B}
  \rho_v\delta_t\psi_t f_vf_u\,\frac{dt}{t},\tag{MT3}
\]
而非各固定对积分的上确界。一般合法方向为
\(\sup_{v,u}\int F_{vu}\le\int\sup_{v,u}F_{vu}\)，反向未经证明。虽然每个 \(r_t(v)\) 不减、每个来源的补集资格是初始区间，\(k_t\) 的不同跳时仍允许上确界赢家切换。现有共同 moment 预算不提供这些赢家的统一覆盖重数。

对有限来源菜单，把上确界换成求和可消除交换问题，但引入来源对数或覆盖质量；原合同不控制这笔费用，不能外推为一般结论。改用来源平均再以 \(\delta_t\le k_t(v)\) 积分，则退回已有 FTC／R135 AF14 质量势，不计新付款。取 \(\lambda(t)=1/L_t\) 虽逐时合法，却使 \(L_t/r_t\) 同时含共同归一化变化及删源跳跃，不能沿用 MT2 的单调原函数。

可测性不是此处主障碍：固定 \(1/L_g\) 为可测合法参数；若用时间变化参数，可限制到事先固定的可数 \(\lambda L_t\) 网格，点态取下确界得到可测上帽。非负函数用 Tonelli 可交换真实积分；Tonelli 不授权把来源上确界移出时间积分，也不授权交换 \(\inf_\lambda\sup_{v,u}\)。

## 3. 真实外账与停止结论

MT1 右端若记作一个上帽，其实际费用仍须放回
\[
 2\Lambda\,\mathbb E\sum_{V,j}\int
 q^{-1}p_xh_R(x-z)\,[\text{MT1 右端}]\,
 dx\,d\beta(y)\,d\nu(z)\,\frac{dt}{t},\tag{MT4}
\]
连同全部原 history、唯一 \(j\)、实际 \(s,L,R,g,T\)、旧 FA 未付资格及时间窗。两份 \(w/e_t\) 已在 \(\Pi_t^2\) 使用，不再另给来源预算。若企图使用 MT2，必须额外证明一个保留实际 \(Q^*\) 接收几何的来源覆盖／切换估计，并支付其重数及对数势的 MT4 外积分，最终达到
\(\varepsilon X+C_\varepsilon\sqrt n\log^A(2+n)W_\beta\)。这里缺少的正是这两笔可定位费用；本稿没有证明它们，也不把 MT3 改名作为成果。

尤其不能先把对数势或时间帽取统一接收上确界，再套 JT13 的包络，把由此恢复的维数费用省略。原 \(\beta\) 虽由 L1 合同绝对连续，其密度并不保持乘积或反射结构；没有可用的免费接收平均。必要 \(\Pi/w\) 条件本身也不能迫使一般整时间剩余交通为 \(O(1/n)\)，故继续只优化共同 moment 参数并非当前优先方向。

结论：本路线没有新增可付款时间界；它留下明确的来源切换与三核对数势接收费用缺口。已知 I1 的早期非零剩余不被排除。本轮应优先推进真实 soft 分层与共同来源预算的接合；本检查点停止于此。R147 已付主分支、原 \(\Psi\) 内负项、futurebad、\(N_{\rm del}\) 均原位且不重复领取。
