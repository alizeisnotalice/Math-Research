# R148 bounded soft-band arithmetic check (frozen)

Own only soft_band_check.py/json/plan.md. Do not modify parent files or expand original179 traffic (n4/16 use unchanged small-dimension N0 branch). Standard library only; one deterministic run, no kernel/receiver/time optimization.

Three predeclared stages retain duplicates: initial n=[1,4,16,64]; pressure n=[63,64,65,255,256,257]; expanded n=2^k,k=6..40. Let d=1−s∈[0,1), N0=2n+3. For n<64 the whole domain uses N0. For n≥64, the near domain d∈[0,1/4] is represented by A=√n d: first closed[0,1], then half-open(lower,upper] with dyadic upper2×lower, clipped at√n/4. Shared endpoints belong only to the left band; d=1/4 belongs to near, and far is(1/4,1), using N0.

Each near band uses fixed N=(1+A_upper)^2, not the varying actual A. Check exact chain adjacency/nonempty bands/last endpoint, N≤N0, and N≤8(1+A_actual²) throughout the band by bounding against its lower endpoint. Algebraic last endpoints use Fraction sqrt bounds from integer isqrt(n·2^240)/2^120; exact square roots stay exact. No floating sqrt is used for inclusion/cost assertions.

Uniform gate: for X=Lg·m·ρ≥0, `r≥262(1+nd²)X` implies `r≥2N_branch X`. Prove cases symbolically: near2N≤16(1+nd²); far2N0=4n+6≤64(1+nd²) for d≥1/4; smalln<64 gives2N0≤258≤262(1+nd²). Verify coefficient inequalities with Fraction and check all declared near-band intervals. This is a gate inclusion, not a new independent budget or union of paid gates.

Use the actual old CS10 expression, not merely the proposed32 bound:

`Env=1+10√n d+log2[2nd+√(28n)+d(10√n√(28n+n²d²)+6n+10nd√n)]`.

For arithmetic n≥1,A=√n d≥0, sqrt28≤6, sqrt(28+A²)≤6+A,1/√n≤1 and log2≤7/10 imply

`Env/√n ≤26/5+(288/5)A+14A² ≤32(1+A)²`.

Check the coefficient inequalities exactly; certify log2<7/10 by the positive Taylor lower sum for exp(7/10) through degree4 being>2. Actual float Env/[√n(1+A)²] at near-band upper endpoints is reported as a diagnostic only. The CS10 theorem itself retains its original d<1/2 range; these checks do not re-prove its analytic kernel/TV hypotheses.

JSON will list every declared dimension, all symbolic/rational endpoint brackets, fixed N brackets, assertion results, maximum diagnostic ratios and SHA256. No root-order/FULL or original traffic improvement claim follows from arithmetic; complete the three owned files and stop.
