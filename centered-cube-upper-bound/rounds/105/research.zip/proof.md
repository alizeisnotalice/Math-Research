# 第105轮：有偿几何切分与深出生中间段

2026-10-13。上一轮提交05a746737372441820543a2ad58f21101fb91826已核对同步；本轮开始时专用Math-Research工作区干净、main及远端正确。本轮仍针对任意正L1输入的一般中心立方体 n^(1/2+o(1)) 一致弱型上界，不将有条件的支或有限检验当作完成。目标尚未闭合。

本轮由两名Astra、四名Sol分别承担实际空间切分、来源盒质量、原出生门、预冻结来源图、数值和独立审核。主代理负责同一交通下的预算整合及提交。所有角色限定文件责任；中断的来源图角色在确认终端后复用原上下文恢复，没有重启数值实验。

## 实质几何进展

上一轮留下可能空间极大的重连通来源组件。本轮构造预冻结的周期来源间隔带，按实际来源质量在有限平移中选最优者。删除来源的交通，以及因此捕获不足的保留来源交通，合计付根阶来源费。保留的大捕获行至多捕获一个边长O(n^(3/2))a的块。这个过程完整记录跨边界捕获，未假设所有边界接收行都已支付，也没有将原软硬端点的跨块关系删除。

在这些新块上，轻质量块继续按对数包价付款，质量过大的块按真实接收邻域付款。两种块质量类别互斥，可以共用一次来源质量预算；出生和来源切分费用则如实相加。余下整盒的平均余额质量降至常数倍λ/√n，这不意味着来源点态密度有上界。

另从原已保留的硬出生门出发，将每个原来源细格对应的半径限制在其固定出生半径之后的对数窗口，宽度√n的部分只需根阶来源费。来源格不交，因此没有格数或森林深度费。深出生终端保留原整格质量的指数小上界，不能把这个接收点依赖门吸入新来源测度。

统一总账以R104已付项P104为起点，Wμ为旧重组件实际来源质量，得到
\[
 R_{\rm out}\le P_{104}
 +[2+3\sqrt n+\log(16/\beta^2)]W_\mu
 +X/768+T_{\rm mid},\qquad\beta=1/6144.
\]
这里P104=O(√n log(n+2))W，Wμ≤W；出生版本使用原FULL的大维出生资格。没有出生资格的抽象支配类仍有对应的几何切分式，但没有深出生条件。主定理没有新增X误差。

## 准确剩余与下一项责任

Tmid是原交通的实际子项，同时具有空间有界、低整盒均值、细格深出生限制。其块质量仍可能处于从exp(√n)到exp(O(nlogn))的范围，尚无普遍根阶付款或统一收缩。仅知的有限终端仍可能按n收费，因此本轮不改善全局已确认的O(nlogn)基准为目标根阶，也不免费迭代当前步骤。

辅助来源图精化只给可测分组、显式包价不增和真实heavy子集关系；它不保证严格收益。未经本轮三阶段实际验证的mass-articulation构造保留本地PRIVATE，不纳入本轮公开主成果。没有为了凑路线而把候选接口当成已证明的几何结论。

## 证据与阅读范围

本轮使用更新64项技能中的E03、G03及相关来源/可测性审计规则，逐项区分平均预算、来源守恒、跨块交通及终端；不借用未核的Bellman常数、捕获树Gram映射或无限LP强对偶。证明主要由有限平均、真实几何分块、已证窗口包络与原hard行帽组成。主代理和出生作者实际重读原出生门指定段落，独审另核；未声称全文重审全部历史研究笔记。

数值使用新的非原子slab输入，在同一来源上比较小周期结构方案及真正理论周期，核对正的删除交通、保留低捕获和保留大捕获。原FULL全套资格未认证，只如实验证明确机制及出生必要条件。精确实施与实际结果见数值和复现章节；有限成功不替代Tmid的一般估计。详细LaTeX文本保留，不编译PDF；仅归档紧凑公开结果及必要复现程序。


## source partition

## 1. 同一实际来源、原交通与有限K

沿用R104 integration的原f≥0∈L1、W、λ、E、X=λ|E|、R(x)∈[a,2a]及完整hard带2λ<A_Rf≤4λ。共同森林参数ω下的原gω≤f，cap-first后的来源
\[
\nu_\omega^{res}(dz)=(g_\omega(z)-\sqrt n\lambda)_+dz
\]
已在receiver之前冻结。以下ν均指这份νres；不以原f或receiver依赖筛选代替。所有source图、包、系数可以依ω，但不依x。

固定R104已经支付尾部的有限a-grid cell box K。Ai=a(i+[0,1)^n)，K中有N个cell，按固定lex序编号为1,…,N；0专用于inactive标记。原f图对∫Ai f>0的cells连接index∞distance≤3。现用实际余额
\[
v_i(\omega)=\nu_\omega(A_i),\quad
O_i(\omega)=\mathbf1_{\{v_i(\omega)>0\}} \tag{1}
\]
构造ν-positive子图，连接同一index≤3的positive vertices。源质量零的格子不收费、不恢复为正源。

原heavy实际交通是同一G1 h_R dx dν dP，保留owner residual、原FULL及共享历史，并限制z∈K、bK=ν(K∩Qx)≥βλR^n、旧f-component的实际ν质量大于阈值。这里β是进入本模块时**已经实际成立**的capture门（R104 β=δ/2），不从旧source门自动传递。

## 2. 可测有限组件与cube唯一捕获

**命题1。** 上述ν-positive图的canonical components Cj(ω)可以在固定N个slot中联合可测地定义；它们细化原f-positive组件。每个原winner cube Qx在K内只能捕获一个ν-positive组件的正来源质量。

证明：vi是可测kernel积分，Oi可测。固定有限indices，邻接条件为固定index关系乘OiOj。任何两positive vertices连通可由长度≤N−1的simple path判定；这样的path只有有限个。故reachability是有限可测布尔组合。给每个positive vertex赋其连通类的最小lex编号，inactive vertices赋0。标签是finite-pattern的可测函数；
\[
\mathbf1_{C_j(\omega)}(z)
=\sum_i\mathbf1_{\{label_i(\omega)=j\}}\mathbf1_{A_i}(z),\quad
m_j(\omega)=\sum_i v_i(\omega)\mathbf1_{\{label_i=j\}} \tag{2}
\]
联合可测。空slot质量为零，忽略即可。没有逐点argmax或无限可测选择假设。

ν≤f dz给Oi=1⇒∫Ai f>0。ν图的每条边也是旧f图边，所以ν组件包含于唯一旧组件。一个Qx捕获的任意两个positive cells之间index∞距离≤3，因为其捕获点之间距离≤R≤2a；它们在ν图直接连接。于是所有K内正ν捕获都在同一组件。ν-zero cells和cell边界没有来源交通；结论针对ν/T几乎处处，不是任意空点的断言。

## 3. 实际对数价格不增

令S0=λa^n（与原soft端q等其他符号区分），Hn=1+nlog2。对固定b∈(0,1]定义实际单包证书价格
\[
p_b(m)=\begin{cases}
0,&0\le m<bS_0,\\
m[1+\min\{n\log2,\log(4m/(b^2S_0))\}],&m\ge bS_0.
\end{cases} \tag{3}
\]
这是R104精确source包价格：active m用共同u=1、c=bS0/m和贡献门b；inactive m使用u=0，不能有capture≥bλR^n的eligible行。以下比较的是这套显式证书的价格，不是宣称它等于最优Hall价格或operator常数。

**命题2。** 若同一实际来源包精化为不交子包，质量m=Σr mr，则
\[
\sum_r p_b(m_r)\le p_b(m). \tag{4}
\]
证明：p_b(m)/m在m>0上非减，低于bS0时为零，到threshold处向上跳，此后为正的非减min-log表达式。因此p_b(mr)≤mr[p_b(m)/m]，求和。m=0直接处理。

旧f组件C的ν质量等于其ν-positive children质量之和：删掉的vertices只有ν-zero cells。对每个ω在每个旧组件应用(4)，再取期望，得到整个共同实际source价格不增。没有graph度、component数或forest深度费用。参数b保持相同；若另一次source删除需要把b减半，必须另计价格，不能引用(4)掩盖。

## 4. 真正新付部分与heavy单调

给阈值M*=S0 exp(s)，s≥0。若一个新的ν组件C'质量mC'>M*，其旧父组件质量至少mC'>M*。原bK、G1、f、λ、R完全不变，故
\[
T_{H,new}\text{ 是 }T_{H,old}\text{ 的可测实际子交通}. \tag{5}
\]
旧heavy父中新增light children的交通可按R104同包资格支付。因unique capture，原行bK全部属于这个child，bK≥βλR^n⇒其包质量≥βS0；取c=βS0/mchild∈(0,1]，则捕获≥βλR^n≥c mchild。于是所释放的准确部分
\[
T_{release}=T_{H,old}\mathbf1_{\{m_{new}(z,\omega)\le M_*\}}
\]
有共同来源费
\[
\|T_{release}\|
\le[1+\log(4/\beta^2)+s]
E\sum_{new\ children\subset oldheavy}m_{child}
\mathbf1_{\{m_{child}\le M_*\}}. \tag{6}
\]
这不是给newlight重算一个receiver来源；相同ω图和包在x之前冻结，实际新light质量账仍是νres。旧已经支付的light parent不再重复付费。

严格价格改进可以逐ω记录
\[
\Delta_{ref}=\sum_{old\ parents}
\left[p_\beta(m_C)-\sum_{new\ children}p_\beta(m_{child})\right]\ge0. \tag{7}
\]
它不保证处处严格，也不保证heavy真实traffic或source质量减少固定比例。若ν-positive cells与f-positive cells一致且原图连通，精化完全无收益。尤其不能把(1)–(7)单独冒称本轮重组件攻坚已经完成。

## 5. 与本轮正切分主线的范围

本轮主攻由Astra的有偿source走廊切分、bornnear几何及top盒均值付款承担；本文的PUBLIC增量是预冻结ν图的可测精化、实际包价单调、真实heavy集合缩小及准确释放支。这有助于把f-positive但零余额的连接去掉，避免按旧f支撑高估残余source连通性。

来源与交通保留同一FULL：νres本身未重新取得旧FULL资格，所有原G1 gate继续作为交通限制。若与走廊模块串用，进入本模块的b必须采用那个模块实际保留的门；不能退回较大的旧β。预冻结partition并非按receiver最优重新分包。

算法是有限source graph构造；N和可能的mask数是计算复杂度，不是付款常数。任意抽象L1没有自动可计算zero-test；原数组积分或认证上下界未知时，只能保留可能positive vertices作为安全粗图。本文没有声称对所有L1输入有高效通用数值求解器。

当前三阶段source菜单已由父与numeric冻结，本文不新增f或实验。相同source上的ν-mask/component identity可以作为本轮解析/实际检查；无articulation的同源图只能作noop控制，不能冒称已经实测全部图或正bridge切分收益。下面PRIVATE保存独立有限付款候选，未经三阶段实际验证不并入本轮主成果。

一般heavy实际交通根阶预算仍OPEN。PUBLIC精化没有支付新positive bridge删除，没有给cheap separator普遍存在或统一收缩，也没有减少本轮旧尾预算X/768。

## hard constraints

本轮对 R104 的真实重组件终端新增一项可直接支付的分支：hard 半径处于其原来源细格出生半径之后的对数窗口内。费用按不交来源格求和，宽度 `√n` 时只付根阶来源费。余项仍是原实际交通，并严格增加“每个参与格的原整格质量相对当前 cube 指数小”的条件；没有证明这个深出生余项可以全部付根阶。

## 1. 原出生门及收费对象

固定 R105 contract 与 R104 integration (I1)–(I11)。尤其保留完整 `f,λ,q`、原 hard `R(x)∈[a,b]`、`b≤2a`、`q∈[3λ/4,λ]`，及原实际 `G_1≤1`。来源余额 `νres,ω=(g_ω−√nλ)+ dz≤μhi` 已在 receiver 之前冻结；它不是新 FIRST 输入。

原 FULL 大维路线在 `n≥512` 使用下面的出生门；有限小维沿上游已付处理。窗口与计数证明本身对任何 `n≥1`、明确满足 (B1)–(B2) 的来源和实际交通都成立，不以这一代数范围替代原 FULL 的适用维数。

以下 `C` 专指**原出生细格**，全边长 `d_0=a/n`；它与 R104 的 side-`a` 所有权格、连通宏组件和共享森林节点不同。原出生参数为

\[
 H_C=\mu_{hi}(C),\qquad
 t_C=\left(\frac{H_C\sqrt n}{e^2q}\right)^{1/n}
 \quad(H_C>0),\qquad t_C=0\quad(H_C=0).
 \tag{B1}
\]

原 hard 捕获端 `z∈C` 的实际交通保留

\[
 t_C\le R(x).
 \tag{B2}
\]

这不是额外假设或重新计算的出生：原已付整格异常输出后，每个剩余 receiver、每个物理 `r∈[a,b]` 的整格未截断响应不超过 `q/√n`；原 hard 顶带已付后，`R+2d_0≤b`。若 `z∈C∩Q_x`，整个 `C` 都在 `Q(x,R+2d_0)` 内，故

\[
 H_C\le\frac q{\sqrt n}(R+2d_0)^n
 \le\frac{e^2q}{\sqrt n}R^n,
\]

最后用 `R≥a`、`(1+2d_0/R)^n≤e²`，得到 (B2)。`t_C` 没有作 `a,b` clamp，且始终使用旧完整 `μhi` 的 `H_C`。`H_C=0` 的格满足 `νres,ω(C)=0`，无需对其定义出生对数。

令 `νH,ω` 为 receiver 前冻结的实际重组件来源：R104 有限 `K_0` 内、实际余额质量超过重阈值的组件之 `νres,ω` 限制。组件唯一性使 (I11) 能写为

\[
 dT_H=A_H(x,z,\omega)h_{R(x)}(x-z)
          dx\,d\nu_{H,\omega}(z)dP(\omega),\qquad 0\le A_H\le G_1\le1.
 \tag{B3}
\]

这里 `A_H` 保留 (I11) 的 `b_0≥βλR^n` 门及全部原 FULL 门；所有 source/corridor 子割仍可追加在它上面。记 `W_H=E||νH||≤W_res`。需要时可直接取 `νH=νres`，只将重组件条件留在 `A_H`；下面较精细的 `W_H` 付款来自明确的预冻结来源限制。

与本轮 `partition.md` 的记号对应，`νH=μ`、`W_H=W_μ`，可直接取其 (P3)–(P4) 的 `A_H=Ĝ`。只在有正实际捕获的行使用“唯一旧组件”来证明这一等价；没有在不活跃行断言 `μ(Q_x)=b_0`。

## 2. 新生窗口的一源正付款

**定理。** 对任意确定 `L≥0`，将 (B3) 按原标签 `C(z)` 分为

\[
 dT_{\rm near,L}=1_{\{0\le n\log(R/t_{C(z)})\le L\}}dT_H,
 \qquad dT_{\rm deep,L}=1_{\{n\log(R/t_{C(z)})>L\}}dT_H.
 \tag{B4}
\]

在实际交通意义下有精确分解以及来源一次价格

\[
 \boxed{T_H=T_{\rm near,L}+T_{\rm deep,L},\qquad
 T_{\rm near,L}\le[1+\min\{L,n\log(b/a)\}]W_H.}
 \tag{B5}
\]

证明。固定 `ω` 及 `H_C>0` 的原细格。所有该格参与 near 支的原 winner 位于 source-fixed 窗口

\[
 J_C=[a,b]\cap[t_C,t_Ce^{L/n}].
\]

空窗口没有该支交通。非空时令 `r_C^−=max(a,t_C)`、`r_C^+=min(b,t_Ce^{L/n})`；可以是 singleton。只在取得正上界时使用 `A_H≤1`，而不删除原交通定义中的历史门。有限半径立方体包络的准确质量为

\[
 \int_{\mathbb R^n}\sup_{r_C^-\le r\le r_C^+}h_r(x-z)dx
 =1+n\log(r_C^+/r_C^-)
 \le1+\min\{L,n\log(b/a)\}.
\]

因此该格 near 交通至多上述因子乘 `νH,ω(C)`。原出生格作为半开不交分区，正 Tonelli 求和给 `Σ_CνH,ω(C)=||νH,ω||`，再取同一 `ω` 平均即得 (B5)。没有细格数、森林深度、重组件数或 endpoint 标签费；没有捕获比例门或贡献比例门。原连续 `R` 不被改成有限尺度 winner。

更精确的实际价格是 `EΣ_{J_C≠∅}[1+n log(r_C^+/r_C^-)]νH,ω(C)`。也可以在 receiver 前冻结非负宽度 `L_C(ω)`，逐格使用对应窗口，只按该实际质量加权价格支付；宽度不能依当前 receiver 改选后再免费拼接。

取 `L=√n`，得到本轮新增实际分支付款

\[
 \boxed{T_H\le(1+\sqrt n)W_H+T_{\rm deep,\sqrt n}.}
 \tag{B6}
\]

费用可能使用与 R104 ownership、light component 相同的来源余额；集成时系数照价相加，而不是声称那些来源不交。对原已付支只取互补交集，不能重新领取既有费用。

## 3. 更强的真实终端

`T_deep,L` 保留原 `G_1`、高密度 excess、harmonicbad `F<1/√n`、有限 `K_0`、唯一重组件、`b_0≥βλR^n`，并新增

\[
 \boxed{H_{C(z)}<\frac{e^2q}{\sqrt n}R(x)^n e^{-L}.}
 \tag{B7}
\]

这是 (B1) 与 `R>t_Ce^{L/n}` 的等价后果。它是**旧原格的整格质量**上界；`νres` 的点态密度仍没有对应上界。深出生选择依 `x,R(x),z`，所以本稿仅将它写为 `A_H` 的实际子门，绝不定义一个 receiver-dependent `νdeep` 后当作预冻结来源。

下面给出该终端一个进一步可核的计数约束。固定 `x,ω`，令

\[
 N_L(x,\omega)=\#\{C:\nu_{H,\omega}(C\cap Q_x)>0,
                     \ t_C<R(x)e^{-L/n}\}.
\]

此数有限。设其真实 row 密度为 `r_L(x,ω)=∫A_H1_deep h_R dνH`。逐格 `νH(C)≤H_C`，用 (B7) 正求和得到

\[
 \boxed{r_L(x,\omega)\le
      \frac{e^2q}{\sqrt n}e^{-L}N_L(x,\omega).}
 \tag{B8}
\]

故 `r_L≥ρλ` 的 receiver 必须满足

\[
 N_L\ge\frac{\rho\lambda\sqrt n}{e^2q}e^L
 \ge\frac{\rho\sqrt n}{e^2}e^L.
 \tag{B9}
\]

这里是真实来源细格数；它不是 Bernstein 标签、endpoint 活动坐标数或源原子数。仅有 `G_1` 交通很小的行不需要满足一个固定 `ρ` 下界。

若预先选择 `ρ>0` 并实际删除 `r_L<ρλ` 的行，这份额外子交通至多 `ρX`；于是准确的高 row 终端全都满足 (B9)。`ρX` 是 **R104 原 `X/768` 之外**的新增费用，集成时必须重新核对吸收预算，不能将它写为免费门。

每边长 `R≤2a` 的 cube 正质量相交细格数至多 `(2n+2)^n`，所以还成立

\[
 T_{\rm deep,L}\le
 \frac{e^2}{\sqrt n}e^{-L}(2n+2)^n X.
 \tag{B10}
\]

这只在 `L` 达到 `n log(2n+2)` 的量级时产生小的 `X` 费。不能把 (B9) 的指数多格解释成已经证明的熵耗散或根阶有限重访预算。宽度 `√n` 的本轮真正收益是 (B6) 的正付款与 (B7) 的严格剩余条件，(B10) 仅保留完整末端账。

## 4. 与本轮空间切分的组合

出生窗口付款可在 periodic source corridor 切分之前或之后取原子交通的互补交集。深出生门始终在原 `C(z)` 上计算；corridor 的来源删割和有限盒分组仍在同一预冻结 `νH` 或 `νres` 上建立。边界接收点、跨 corridor 捕获与后续 source tail 费用不能因 (B7) 而删除。

相较 R104，本模块支付的是原重组件内的一个此前未指定窗口的实际子交通，且无需 R104 的 ownership 低扩张或任何新 capture 比例假设。原微盒非集中约束只控制 `μ(C∩Q_x)`，这里窗口用的是整格 `H_C`；二者没有被混成一个条件。原 source-core 已保存的认证半径也保持原定义，没有由本轮的新窗口宽度重算或免费扩展。

没有证明 near 支对每份合法原输入占固定比例，也没有构造满足全部 FULL 门的新实例来量化这一比例。一般终端预算、重组件内部递归收缩和完整 `n^(1/2+o(1))` 目标仍开放。

## 5. 保留原 pair 标签时的短附录

仅在尚保留原 soft `y`、hard `z` 及唯一父组 `P` 的实际联合交通中，深出生子割还给一个精确的质量比。原 strict CP/GP 与 (B7) 相除得

\[
 \frac{h(P)}{H_{C(z)}}>
 \max\left\{
 \frac{n e^L}{e^2v_j}
       \left(\frac{\min(L_s,R_h)}{R_h}\right)^n,
 \frac{\sqrt n e^L}{e^2}
       \left(\frac{L_s}{R_h}\right)^{n/2}
 \right\}.
 \tag{B11}
\]

原 `v_j>0,H_C>0`；若 `R_h≤L_s`，第一项即 `n e^L/(e²v_j)`。只用原定义中的 `h(P)`，没有将它改成当前捕获质量。此代数无需 `C(z)⊂P`，也不因此推出父组的所有格都是深出生。它仅登记为携带原 pair 标签的结构：已经积分 soft 端的 `G_1(x,z,ω)` 不提供一个新可选父组，故 (B11) 没有进入本轮主余项的无条件属性或已付价格。

## partition

## 1. 结论及准确输入

本节对 R104 I11 的实际重组件交通给出普遍的正向几何切分。以预冻结的来源走廊打断原组件；走廊来源和由此产生的低捕获边界交通合计支付根阶来源费。保留部分只在空间边长 O(n^{3/2})a 的块中捕获，轻块再按来源质量支付根阶费。尚未支付的是这些空间有界块中的真实重块交通；没有证明其质量或交通统一收缩。

固定 R104 全部原对象：f≥0，W=∫f<∞，λ>0，X=λ|E|<∞，a≤R(x)≤2a，2λ<A_Rf≤4λ；预冻结 νres_ω=(g_ω−√nλ)₊dz，原完整 G，及已构造的实际余项门

\[
G_1=G1_{\{b_\omega\ge\delta\lambda R^n\}}(1-\Gamma)_+,
\quad\delta=1/3072,\quad\beta=1/6144.
\tag{P1}
\]

这里只使用同一个既定 G₁，不重新计算 Γ，不给 νres 或新子来源重新赋予 FULL 资格。原有限截断 K、原 f-positive 格图组件 C、b_K=νres(K∩Q_x) 也保持不变。记

\[
H_n=1+n\log2,\quad M_*=\lambda a^n e^{\sqrt n},
\quad S_\omega=\bigcup_{C:\,\nu^{res}_\omega(C)>M_*}C,
\quad\mu_\omega=1_{S_\omega}\nu^{res}_\omega,
\quad W_\mu=E\|\mu_\omega\|.
\tag{P2}
\]

S_ω⊂K 是预冻结原重组件并。原图保证每个赢家 Q_x 正质量捕获至多一个 C。因此在对 μ 的实际交通有贡献的行，μ(Q_x)=b_K。为使后面删除门时也保持这个资格，明确使用

\[
A(x,\omega)=1_{\{\mu_\omega(Q_x)\ge\beta\lambda R(x)^n\}},
\quad\widehat G=G_1\mathbf1_{\{b_K\ge\beta\lambda R^n\}}A.
\tag{P3}
\]

于是原 I11 准确等于

\[
T_H=E\int_E\int \widehat G(x,z,\omega)h_{R(x)}(x-z)
\,d\mu_\omega(z)\,dx.
\tag{P4}
\]

证明等价只需在 μ 实际捕获正时用唯一旧组件；不能在任意不活跃行直接声称 μ(Q_x)=b_K。若 W_μ=0 则全交通为零。

## 2. 冻结周期走廊及质量选择

沿用原边长 a 的半开格，写为 A_k=c_0+a(k+[0,1)ⁿ)，k∈ℤⁿ。取整数 L≥4。对每个有限平移

\[
s\in\mathcal S_L=\{0,\ldots,L-1\}^n
\]

定义来源走廊

\[
D_s=\bigcup\{A_k:\ \text{至少一个 }j\text{ 满足 }
(k_j-s_j)\bmod L\in\{0,1,2\}\}.
\tag{P5}
\]

每个坐标删掉连续三格宽的周期条带。令 s_ω 为使 μ_ω(D_s) 最小的平移，重名时按预定字典序取第一个，D_ω=D_{s_ω}。这个选择只读完整的预冻结 μ_ω；不依接收点、赢家或当前被捕获的子来源。

对固定格 k，各坐标残基在均匀 s 下独立均匀，故

\[
p_L=1-(1-3/L)^n,
\quad \frac1{L^n}\sum_{s\in\mathcal S_L}\mu_\omega(D_s)
=p_L\|\mu_\omega\|.
\]

有限平均和最小值给出

\[
\boxed{\mu_\omega(D_\omega)\le p_L\|\mu_\omega\|,
\qquad p_L\le3n/L.}
\tag{P6}
\]

第二式是并集界。此处空间坐标上的有限平移平均并未假设 f、来源或接受分布有坐标独立性。

设 μ^D=1_Dμ、μ'=1_{D^c}μ。保留的几何盒为

\[
P_{s,j}=c_0+a\big(s+Lj+[3,L)^n\big),\qquad j\in\mathbb Z^n.
\tag{P7}
\]

每个盒全边长 (L−3)a，两相邻盒之间至少有一个坐标的三 a 宽来源空隙。μ' 支持在这些盒中；实际块为 P_{s_ω,j}∩S_ω，但使用整个盒记其包并无额外质量。K 由有限格组成，所以实际非零块仅有限个。

## 3. 真实跨块捕获与全部边界付款

若 z,z' 分属不同保留盒，则某一坐标上的距离至少 3a，除半开端点差异外实际上严格大于或等于此数。任意 Q_x 的坐标宽度≤2a，因此不可能同时正质量捕获这两个保留盒。故

\[
\text{每个 }Q_x\text{ 捕获至多一个保留来源块。}
\tag{P8}
\]

这不是对原赢家捕获作删减假设。原赢家可以同时捕获走廊来源与保留来源，甚至原先跨越许多待分块边界；其被删除的来源交通在下面完整付款。不删除任何接收点，也不以边界接收体积很小作为理由。

首先保留窗口包络 H_n：对任意预冻结有限子来源 η，

\[
\int_{\mathbb R^n}\int \sup_{a\le r\le2a}h_r(x-z)
\,d\eta(z)dx=H_n\|\eta\|.
\tag{P9}
\]

这是有限半径核包络的准确积分，适用于本轮任意原选择器。令

\[
b'(x,\omega)=\mu'_\omega(Q_x),\quad
b_D(x,\omega)=\mu^D_\omega(Q_x),\quad\beta'=\beta/2.
\]

在 A=1 且 b'<β'λRⁿ 的行，

\[
b_D=\mu(Q_x)-b'\ge\beta\lambda R^n-b'>b'.
\tag{P10}
\]

现在把 (P4) 精确分成删除来源、保留来源的低捕获行、保留来源的大捕获行。前两项分别记 T_D、T_low。因 0≤Ĝ≤A≤1，

\[
T_D\le H_n E\|\mu^D_\omega\|,
\]
\[
T_{low}\le E\int_E A1_{\{b'<\beta'\lambda R^n\}}
\frac{b'}{R^n}dx
\le E\int_E\frac{b_D}{R(x)^n}dx
\le H_n E\|\mu^D_\omega\|.
\tag{P11}
\]

中间无门表达仍只在原选择器定义的 E 上积分，随后用 (P9) 的全空间包络支配，不需要在 E 外定义 R。合并得到

\[
\boxed{T_D+T_{low}\le2H_np_LW_\mu.}
\tag{P12}
\]

(P10) 必须先在原 A=1 上使用，之后才能放松门。尤其没有把 light 旧组件行或 μ 没有捕获的行强行使用这个转移。走廊同一份来源最多在这两个明确项中被按包络付两次，系数 2 已列明。

取

\[
L_n=3+\left\lceil6\sqrt n\,H_n\right\rceil.
\tag{P13}
\]

则 L_n≥4，L_n>6√nH_n，所以

\[
2H_np_{L_n}\le6nH_n/L_n<\sqrt n.
\tag{P14}
\]

n=1 时 H₁=1+log2，L₁=14，p₁₄=3/14，2H₁p₁₄=3(1+log2)/7<1，取整和低维无例外。保留盒边长≤[6√n(1+nlog2)+1]a=O(n^{3/2})a；此处仅为几何直径信息，不把盒体积视为根阶。

## 4. 新轻块的实际单包付款与新重块终端

对每个保留盒 P_j=P_{s_ω,j}，记预冻结质量

\[
m_j(\omega)=\mu'_\omega(P_j).
\tag{P15}
\]

由 (P8)，若 b'≥β'λRⁿ，则唯一捕获的保留盒 P_{j_x} 满足捕获量 b'，且 m_{j_x}≥β'λaⁿ。质量小于此活跃门槛的盒不可能出现在该分支，对其置 u_j=0、捕获标签 c_j=1；m_j=0 项直接省略。其余盒取 u_j=1，

\[
c_j=\frac{\beta'\lambda a^n}{m_j}\in(0,1],
\quad\text{贡献标签 }\beta',
\quad H_j=1_{\{\mu'(P_j\cap Q_x)\ge c_jm_j,
\ \mu'(P_j\cap Q_x)\ge\beta'\lambda R^n\}}.
\tag{P16}
\]

所有标签都在接收点之前冻结。实际大捕获行的唯一块确实满足 H_j，不需追加 receiver-dependent 选择来源。对这份实际子交通应用 R104 对数单包付款：保留原 G₁、完整 f 的 hard 上界及选择器，只对正上界删除 Ĝ，得到

\[
\text{该包交通}\le m_j\left[1+\log\frac{4m_j}
{(\beta')^2\lambda a^n}\right].
\tag{P17}
\]

这也可与 H_nm_j 取小值。定义新轻块集合 β'λaⁿ≤m_j≤M_*，其来源质量期望为 W_light。由 (P17) 和块间真实不交，

\[
T_{light}\le A_nW_{light},\qquad
A_n=1+\log(16/\beta^2)+\sqrt n.
\tag{P18}
\]

唯一剩余为

\[
T_{box}=E\int_E\int
\widehat G(x,z,\omega)h_{R(x)}(x-z)
1_{\{b'\ge\beta'\lambda R^n\}}
1_{\{m_{j_x}>M_*\}}
\,d\mu'_\omega(z)dx.
\tag{P19}
\]

无唯一捕获块时定义被积式为零。它是原 I11 的真实子交通；不是改造后假装具有 FULL 资格的另一个输入。综上，对所有原输入无条件成立

\[
\boxed{
T_H\le2H_np_LW_\mu+A_nW_{light}+T_{box}.
}
\tag{P20}
\]

取 (P13) 得

\[
\boxed{
T_H\le\sqrt n W_\mu+
[1+\log(16/\beta^2)+\sqrt n]W_{light}+T_{box}
\le[2\sqrt n+1+\log(16/\beta^2)]W_\mu+T_{box}.
}
\tag{P21}
\]

这是一次完整来源分块账，没有新增 X 误差。因此可直接加到 R104 I2，既有 X/768 不改变。新重块费用仍可粗界 T_box≤H_nW_box，但 W_box 没有已证明的统一小比例。

## 5. 新信息、可测性、极限和原门

这一步不是 R104 连通组件改名：原 f-positive 图可以通过任意长的正质量桥连成一个巨大重组件；本构造实际删除预冻结的正来源走廊，并将它们以及因此失去贡献门的保留交通一起付款。剩余块即使仍重，其空间边长也有仅依 n,a 的统一界。原 R104 仅靠图分组既不能产生这些来源间隙，也没有 (P12) 的真实边界付款。

另一方面，空间有界不意味着来源总质量有界。不能用盒数量、格邻接度或 n 维体积常数填补 (P19)；亦未证明每次重做切分会使剩余质量或实际交通按固定比例下降。若进行后续递归，必须为每一层重新登记贡献门、来源重复费和终端，不能免费迭代 (P21) 后删除终端。本轮没有声称一般根阶已经闭合。

原有限 K 的格图固定，重组件质量是 ω 的可测函数，所以 μ_ω 是可测有限测度核。每个 μ_ω(D_s) 可测，有限字典序最小值选择 s_ω 可测。全部新盒取自有限平移的可数固定 Borel 库；由于 K 有限，每个样本只有有限个非零盒。质量、捕获量、标签和实际门联合可测，无需连续最优化或未经证明的可测选择。所有积分交换是非负 Tonelli；每一步都是有限分块守恒，没有树深极限、隐藏叶子或 ∞−∞。如实现时枚举包含零质量盒，可由单调收敛移除它们，结果不变。

完整原 FIRST/fullfuture、hard/soft 赢家、出生、共享森林、distinct-child LCA、失败币、strict CP/GP、重捕获、owntrace/GOOD/clock、非集中、短壳、lowS/lowcoin、cutoff、source-core、角门补集仍在原 G₁ 内。走廊及其余来源只是已冻结 μ 的限制，原 pair 门仍在原 y,z 处判定。完整 f 用来核验原硬带与有限 K 图；收费质量始终是实际 μ 而非 f。没有改变原单一帽或把来源出生格质量上界改成密度上界。

若其他已审模块先支付 birthlog≤√n 分支，可将其剩余 x,z 门乘入 Ĝ；(P11) 仍成立，因为仅用 0≤Ĝ≤A。μ 则仍必须是预冻结来源，不能把该接收点依赖 birthdeep 门吸入 μ。两模块如使用同一 W_μ，应把费用相加，不能宣称来源预算互斥。

## dense route

本文件接在本轮走廊切分之后，对新得到的有界来源块支付一个明确分支：块质量大到足以支付其整个接收邻域时，该块的全部原实际交通按根阶结算。它使用原 hard 行上界，不使用强 `Lp` 再截顶。所得余项在来源空间有界之外，还具有明确的块质量上界。中间质量区间的统一根阶估计仍未证明。

这一付款使用既有的“来源固定接收邻域”原理，新增之处是将它合法作用于本轮产生的不交来源块，结算实际剩余交通。本文不将 elementary halo 估计称为新 maximal 定理，也不声称旧 FULL 补集上已构造出该分支严格非空的例子。

## 1. 同一实际交通及本轮新来源块

继续 R104 (I11)。原余额 `ν_ω^res` 的密度是 `(g_ω−√nλ)+`，只支撑于原 `g_ω>√nλ`；**余项密度本身并无 `√nλ` 下界**。本轮先限制到旧重组件并，再删走廊，所得预冻结来源记作 `η_ω=μ′_ω≤ν_ω^res`，与 `partition.md` (P15) 和 `integration.md` (J4) 完全相同。原 `f,G,R,E,λ` 及 FULL 门保持不变。

允许本轮走廊、低保留捕获转移和轻块付款之后的任意实际子门 `0≤J(x,z,ω)≤1`。将其与 (I11) 的原门相乘，统一记为 `G_*≤1`。所需两项原上界仅为

\[
 a\le R(x)\le2a,\qquad
 \int G_*(x,z,\omega)h_{R(x)}(x-z)d\eta_\omega(z)
 \le A_{R(x)}f(x)\le4\lambda. \tag{1}
\]

主线直接使用走廊之后的整个 canonical 盒：`P_j=B_j`，每盒全边长 `s=(L−3)a`，质量为 `η_ω(B_j)=μ′_ω(B_j)`，已经合并同盒内全部旧组件来源；不在中途另作池化。以下证明也允许可选的一般表示：来源包 `P_j(ω)` 互不交，且 `P_j⊂B_j`。使用实际余额质量

\[
 m_j(\omega)=\eta_\omega(P_j),\qquad
 V_L=|B_j+Q_{2a}|=((L-1)a)^n. \tag{2}
\]

`P_j,B_j,m_j` 在接收点选择之前冻结并联合可测；盒编号有限或可数。包的容纳盒不要求互不相交；收费守恒只用来源包 `P_j` 互不交。走廊构造本身给更强的空间分离，但本节付款不需要它。

## 2. 超重块的整块实际付款

冻结超重标签

\[
 \mathcal J_{\rm top}(\omega)
 =\left\{j:m_j\ge\frac{4\lambda V_L}{\sqrt n}\right\},\qquad
 W_{\rm top}=\mathbb E\sum_{j\in\mathcal J_{\rm top}}m_j. \tag{3}
\]

令 `T_top` 是现存实际交通中来源 `z∈∪_{j∈J_top}P_j` 的部分，则

\[
 \boxed{T_{\rm top}\le4\lambda V_L\,
        \mathbb E\#\mathcal J_{\rm top}
        \le\sqrt n\,W_{\rm top}.} \tag{4}
\]

其中第一式允许先解释为非负和；第二式与有限来源总质量共同保证所有实际收费有限。

证明。若 `z∈P_j⊂B_j` 且 `h_R(x−z)>0`，则 `x∈B_j+Q_R⊂B_j+Q_{2a}`。因此该包实际交通

\[
 T_j(\omega)
 =\int_E\int_{P_j}G_*h_R(x-z)d\eta_\omega(z)dx
 \le\int_{E\cap(B_j+Q_{2a})}A_Rf(x)dx
 \le4\lambda V_L. \tag{5}
\]

这里真正使用的是接收位置的 Lebesgue 体积。即使某包只被部分捕获，甚至每个接收点捕获比例极小，(5) 仍覆盖该包全部现存交通。根据 (3)，`4λV_L≤√n m_j`；对超重包求和并取期望得 (4)。源包不交给

\[
 W_{\rm top}\le\mathbb E\sum_jm_j\le W_{\rm heavy}. \tag{6}
\]

若此前已经支付 birth-near，剩下的 birth-deep 是 `x,z` 联合门，只加入 `G_*`；`m_j` 仍是这里预冻结的实际来源包质量，不能改成依接收点条件化的 deep 来源质量。不同模块若都按同一质量余额收费，其费用系数要相加。

没有把同一点不同包的行帽免费合成一个较小帽；实际使用的是逐包 `4λV_L` 再通过每包质量门分别清算。容纳盒重叠亦不会引入未登记费用。被积式保留同一原 `G_*`，不是在新包上重新运行 FIRST 或原分类。

## 3. 付款后的精确质量窗口

先删除本轮已付的轻块 `m_j≤λa^n e^{√n}`，再按 (3) 支付超重块。若剩余包存在，其质量必满足

\[
 \boxed{\lambda a^n e^{\sqrt n}<m_j
       <\frac{4\lambda((L-1)a)^n}{\sqrt n}.} \tag{7}
\]

保留的实际量是

\[
 T_{\rm middle}
 =\mathbb E\sum_j\int_E\int_{P_j}
     G_*h_R(x-z)
     \mathbf1_{\{\lambda a^n e^{\sqrt n}<m_j<4\lambda V_L/\sqrt n\}}
     d\eta_\omega(z)dx, \tag{8}
\]

其中 `G_*` 包括本轮轻块之前已保留的原门、走廊切分门及捕获下门。轻块和超重块阈值若交叠，按“先轻、后超重”的顺序只收费一次；式 (8) 准确给最后剩余。不存在满足区间的包时终端为零，但没有证明一般输入会如此。

令 `J_top′=J_top∩{j:m_j>λa^n e^{√n}}`，相应实际交通与质量记为 `T_top′,W_top′`。从轻块之后的实际交通 `T_after-light` 出发，完全精确的正拆分与付款为

\[
 T_{\rm after-light}=T'_{\rm top}+T_{\rm middle}
 \le\sqrt n W'_{\rm top}+T_{\rm middle}. \tag{9}
\]

`T_top′,W_top′` 仅包含尚未按轻块支付的超重包。式 (3) 的全超重质量满足 `W_top′≤W_top`，可作保守上界；集成时可使用这份不重复余额。

若 `L=3+ceil(6√n(1+n log2))`，则 (7) 的对数上端是

\[
 \log\frac{m_j}{\lambda a^n}
 < n\log(L-1)+\log4-\tfrac12\log n. \tag{10}
\]

同时，(7) 给出一个有用而不同于点态密度的终端约束：剩余每包相对于其容纳盒的平均质量密度满足

\[
 \boxed{\frac{m_j}{|B_j|}
 <\frac{4\lambda}{\sqrt n}
       \left(1+\frac2{L-3}\right)^n
 \le\frac{4e^{1/3}\lambda}{\sqrt n}.} \tag{10a}
\]

证明：`L−3≥6√n H_n`，且 `H_n=1+n log2≥(n+1)/2≥√n`，所以

\[
 \left(1+\frac2{L-3}\right)^n
 \le \exp\!\left(\frac{2n}{L-3}\right)
 \le \exp\!\left(\frac{\sqrt n}{3H_n}\right)\le e^{1/3}.
\]

这里 (10a) 是**块质量除以容纳盒体积**的上界；没有给 `g_res` 逐点上界，也不排除盒内极细的高峰。主线 `P_j=B_j,η=μ′` 已经是 canonical 整盒池化，故 (10a) 直接是每个剩余完整物理盒的实际余额平均。仅在可选的分组件表示中，若多个不同原组件的包共用同一容纳盒，逐包 (10a) 不能无因子相加。要使它成为整个物理盒的余额平均密度界，可以先完成轻包付款，再将同一物理盒内所有尚未付的重包合并为一份预冻结包，用该合并包的实际质量执行 (3)–(5)。这些合并包仍按物理盒互不交；每个非空合并包至少包含一个原重包，故仍保留 (7) 的严格下界，(10a) 此时对整盒剩余来源成立。采用该顺序时，式 (2)–(11) 的 `P_j,m_j` 统一指合并后的包和质量；原轻包来源已经从此来源族中移走，因此不重收轻包费。此合并是固定来源再表示，保持原每个接收点的 `G_*`；无需给合并包新的 FULL 资格。

它一般仍为 `O(n log(n+2))`，远大于已付轻块的 `√n` 截止。因而空间局部化与这一上端删除**尚未**形成根阶总预算或统一收缩。剩余交通始终可保留已有有限终端

\[
 T_{\rm middle}\le(1+n\log2)W_{\rm middle},\qquad
 W_{\rm middle}=\mathbb E\sum_{j\text{满足}(7)}m_j. \tag{11}
\]

(11) 只说明余项有限，仍是线性维数费用。没有将 (10) 的层数免费忽略，也没有对该密度/质量范围逐层复用一份 `W`。

主线整盒分类还能精确共享轻盒与超重盒的预算。若
`A_n=1+log(16/β²)+√n`，则先轻后 top 的来源类别不交，故

\[
 A_nW_{\rm light}+\sqrt nW'_{\rm top}
 \le A_n(W_{\rm light}+W'_{\rm top})
 \le A_n\mathbb E\|\mu'_\omega\|\le A_nW_\mu. \tag{12}
\]

因此接入父稿 (J6) 不另增加一份 `√n W_μ`：出生 `(1+√n)W_μ`、走廊至多 `√nW_μ`、(12) 合计为 `[2+3√n+log(16/β²)]W_μ`。出生和走廊与块分类仍可能使用相同来源，其系数确实相加；只有轻/top 两个互斥质量标签共享 (12)。这与整盒均值 (10a) 使用完全相同的 `m_j=μ′(B_j)`。

## 4. 与旧 source-core、出生和截顶的区别

旧 source-core 的保存证书以**原森林节点** `P` 为对象，并要求核心 `K` 承载几乎全部原 `μ_hi(P)`，然后按 `q|K+Q_b|` 收费。本轮 `P_j` 是走廊产生的新来源块，使用的是本轮实际预冻结 `η(P_j)`；它既不必是原节点，也不保证承载某个包含节点的绝大多数 `μ_hi`。所以 (3) 不能自动翻译成旧已保存证书，也不能仅凭旧 source-core 补集就宣称 (8) 前的超重支为空。

反过来，(4) 的机制确实是同一 elementary 来源邻域付款。本文只登记其对这些新不交包的合法作用，不声称另造了一条独立于 source-core 原理的几何定理。是否在完整 FULL 补集上发生严格新增覆盖，须另有原门资格见证；本轮不提供这种见证。

原出生上界是每个原细格的 `H_C≤e²qR^n/√n`。它不控制一个走廊盒包含多少个细格，不能从而推出 `m_j` 的根阶规模上界。高密度 support 的小体积也不控制 `B_j+Q_{2a}` 的体积。本证明直接计算并支付该接收邻域，所以没有做这种替换。

PUBLIC 结论限于 (4)、(7)–(12)。真正未付的是同一实际门上的空间有界、质量处于 (7) 的来源块交通；所有 cross-child、birthdeep 或其它保留门继续留在 `G_*` 中。

## integration

本节沿同一原 R_out 组合各项付款。对原 FULL 大维路线使用其已经保留的出生门；在一般抽象支配类中，出生结论只在明确满足该门时使用。周期来源切分与盒邻域付款本身不要求出生门。所有原接收测度、赢家、完整 f 及 G 的历史条件均保持原样。

## 1. 共同对象与顺序

记 R104 定理右侧已付项为 P104，包含截頂、所有权、有限源尾与原轻组件费，但不包括 X/768。已证
\[
 R_{\rm out}\le P_{104}+X/768+T_H,
 \qquad P_{104}=O(\sqrt n\log(n+2))W.
 \tag{J1}
\]
其中 R104 的费用可明确写成
\[
 P_{104}=768C_2^2\sqrt n\,W_{\rm cap}
 +\{2\sqrt n[1+\log(24576\sqrt n)]
       +1+\log(4\cdot6144^2)+\sqrt n\}W_{\rm res},
 \quad W_{\rm cap}+W_{\rm res}\le W.
 \tag{J1a}
\]
C2 为 R104 已核引用的维数一致 cube 强L2常数；本轮不重新宣称证明该外部定理。

T_H 始终为 R104(I11) 的原实际余项。沿用有限 K 中的原 f-positive 格图重组件并 Sω，令 μω=1Sω νres,ω，Wμ=E||μω||≤Wres。它是预冻结来源，未按当前赢家删除深出生以外来源。唯一旧组件捕获性质允许把原实际门写成 Ĝ≤1{μω(Qx)≥βλR^n}，其中 β=1/6144；非活跃行不宣称 μ(Qx)=bK。

固定
\[
 H_n=1+n\log2,\quad L=3+\lceil6\sqrt nH_n\rceil,
 \quad p_L=1-(1-3/L)^n,\quad
 \beta'=\beta/2,\quad M_*=\lambda a^n e^{\sqrt n},
 \quad A_n=1+\log(16/\beta^2)+\sqrt n.
 \tag{J2}
\]
原出生细格边长 a/n，原质量 H_C=μhi(C)，tC=(H_C√n/(e²q))^(1/n)，q∈[3λ/4,λ]。原 FULL 剩余的实际硬捕获满足 tC≤R；H_C=0 的格没有 μ 来源。先支付 0≤nlog(R/tC)≤√n，余下门乘
\[
 B_{\rm deep}(x,z)=1_{\{n\log(R(x)/t_{C(z)})>\sqrt n\}}.
 \tag{J3}
\]
这一步付 (1+√n)Wμ，不改变预冻结 μ。若没有原出生资格，省略此步和对应费用、深出生结论，后续几何拆分仍成立。

## 2. 切分、轻块和盒邻域统一收费

按 μω 在 L^n 个周期位移中选删除质量最小者，字典序破同名。每坐标删连续三层 a 格，删除来源 Dω，保留 μ′=1Dc μ。来源删除及原活跃行中 b′=μ′(Qx)<β′λR^n 的保留交通，合计至多 2Hn pL Wμ≤√n Wμ。没有删除接收点，没有新增 X 误差。

保留盒 B_j 的边长为 (L−3)a，彼此有三 a 间隔，R≤2a 的赢家最多捕获一个。m_j=μ′(B_j) 为整个冻结盒的实际来源质量，不是当前深出生子交通的条件质量。在 b′≥β′λR^n 分支，活跃盒 m_j≥β′λa^n。

轻盒 β′λa^n≤m_j≤M* 按 A_n m_j 支付。随后只在未付重盒中，对
\[
 m_j\ge M_{\rm top}:=\frac{4\lambda((L-1)a)^n}{\sqrt n}
 \tag{J4}
\]
使用原行帽 A_Rf≤4λ 及真实接收邻域 |B_j+Q2a|=((L−1)a)^n，按 √n m_j 支付整块实际交通。令相应来源质量为 Wlight、Wtop′；按“先轻、后top”定义，它们是不交来源类别，故
\[
 W_{\rm light}+W'_{\rm top}\le E\|\mu'_\omega\|\le W_\mu.
 \tag{J5}
\]
这份互斥只用于这两个块质量类别；出生与来源走廊仍可能对相同 μ 另行收费，费用必须相加。

由 A_n≥√n，得到准确总账
\[
 \begin{aligned}
 T_H\le{}&(1+\sqrt n)W_\mu+2H_np_LW_\mu
       +A_nW_{\rm light}+\sqrt nW'_{\rm top}+T_{\rm mid}\\
 \le{}&[2+3\sqrt n+\log(16/\beta^2)]W_\mu+T_{\rm mid}.
 \end{aligned}
 \tag{J6}
\]
无出生门的版本删除第一项 (1+√n)Wμ，得到 [1+2√n+log(16/β²)]Wμ 加同一几何中间段，但没有 Bdeep 条件。原 FULL 的版本回代 (J1)：
\[
 \boxed{R_{\rm out}\le
 P_{104}+[2+3\sqrt n+\log(16/\beta^2)]W_\mu
 +X/768+T_{\rm mid}.}
 \tag{J7}
\]
新增已付部分为根阶，R104 的唯一 X/768 没有重复使用或增大。

## 3. 最后实际余项的全部条件

最后的 Tmid 以同一 μ′、原 R 和 Ĝ 积分，另保留 Bdeep、b′≥β′λR^n 及当前唯一捕获盒的质量门
\[
 M_*<m_{j_x}<M_{\rm top}.
 \tag{J8}
\]
没有唯一捕获盒时被积式定义为零。它确是原 T_H 的实际子交通，原 cap 余额、harmonicbad、FULL 各门全部仍在；没有给 μ′重新执行 FIRST。

每个剩余盒除空间边长 O(n^(3/2))a 外，还满足实际盒均值界
\[
 \frac{m_j}{|B_j|}
 <\frac{4\lambda}{\sqrt n}
       \left(1+\frac2{L-3}\right)^n
 \le\frac{4e^{1/3}\lambda}{\sqrt n}.
 \tag{J9}
\]
因为 log2≥1/2，Hn≥(n+1)/2≥√n，故 L−3≥6n；再用 log(1+u)≤u。这是整个 canonical 盒的平均质量界，绝不是 νres 的点态密度界。余额 (g−√nλ)+ 的密度本身也没有 √nλ 的正下界。

在每个实际硬来源对上，原出生格同时满足
\[
 H_{C(z)}<\frac{e^2q}{\sqrt n}R(x)^n e^{-\sqrt n}.
 \tag{J10}
\]
(J9) 约束新大盒的实际余额平均，(J10) 约束原细格的完整 μhi 整格质量；二者的对象、尺度和量词不同，不能混同。

## 4. 仍未闭合的责任

本轮对任意大来源组件进行有偿切分，并对跨边界捕获完整分账：删除来源和低保留捕获已付款，大保留捕获继续进入轻块、超重块或真实中间段，没有交通漏项。留下空间有界、低盒均值、深出生的真正中间段。原软硬端点之间的跨块关系仍保留在原门内，未宣称全部跨边界接收行已付清。这不是将原组件改名，也没有只验证一个固定尺度函数族。各结论对明确原假设下的一般输入成立。

但盒质量的剩余对数范围仍可能从 √n 延伸至 nlog(L−1)+log4−(logn)/2=O(nlog(n+2))。低盒均值和逐细格质量小尚未给出 Tmid 的普遍根阶上界；没有已证统一收缩可供免费迭代。现有有限终端仍只有 Tmid≤Hn Wmid。必须继续建立这些真实几何限制下的联合来源—接收估计，原一般 n^(1/2+o(1)) 目标尚未完成。

本组合不使用可选的额外低行 ρX 或极深出生 L约nlogn 的付款，也不把可选 articulation 切分或来源图精化默认为已经覆盖所有余项。那些构造另有准确范围及费用；主公式 (J7) 的来源账与误差账独立完整。

本角色仅拥有numeric.py/numeric.md；共享目录不改他人文件、不Git。已完整读contract、R104 integration I1–I12与hard_bridge全文。本协议是新的真实slab来源族，**执行前尚未实现或执行**（历史checkpoint已被下方实际回执替代）；不重跑R104实例，不拟合n幂。只认证明确广泛dominating-class机制及下述出生必要条件观测，不声称原FIRST/FULL/F2全部资格。


## 实际结论、计数与可复现范围

唯一producer实际完成冻结三阶段并PASS。它计算3个新的非原子L1 f输入、6个真实n维source slab boxes、4个预冻结ν/G标签（n64两标签的来源ν相同、G互换），在同源P5/root-period下得到6个scheme states、16个scheme-label receiver rows、32个positive source–receiver joint paircells。没有重跑R104例、追加输入/精度或出现FAIL/UNKNOWN。两个period共享同一f与同一原G、νres、μheavy，不是6个新f输入；所有实际交通来自n维真实Lebesgue体积，横向微薄support因子α与receiver因子X在原始数据中均保留。

|阶段n|认证Lroot / 来源长度T|old actual heavy质量|P5保留盒m / root保留盒m|P5/root真实删除质量|root new-heavy/X|birth-first final-middle/X|
|---:|---:|---:|---:|---:|---|---|
|4|49 / 245|735|6 / 138|441 / 45|150994943/603979776|0|
|16|294 / 1470|17640|24 / 3492|10584 / 180|150994943/603979776|150994943/603979776|
|64|2181 / 10905|10915905|2002 / 2180178|6549543 / 15015|150994943/402653184|150994943/402653184|

所有stage的原余额捕获b=1、Af=3，原δ-low交通0；宏包最低质量9/36/3003均严格大于Db=4/8/16，故**全部原packet Hfalse、实际Γdense0、G1=G**。有限相关12packet直接宏盒积分与全局2T包解析界互相核对。F分别1/15、1/60、1/5005，FD0；old f-positive图为两条相邻正来源格行，固定连通，实际old-heavy资格由exp有理上界认证。它们是I11公式在所述dominating class中的真实heavy交通实例，**不是已认证FULL原难支实例**。

每个period都有真实正删除质量，不利用零删除退化。真实最小lex shift=(0,2,1,…,1)通过uniform long-coordinate全period下界3/P与compact坐标达到该下界认证；没有枚举P^n。跨走廊接收行同时捕获deleted cell2和kept cell3，二者全E的strip面积各1/2；各row/pair的partial jointvolume由二维endpoint原函数计算，再用不同的affine capture积分逐项核对。原G取1或1/2，实际deleted和retained流量都正，未删除边界receiver或改G。retained-low γ门的流量也实算并在同一删除来源费2Hn d中付，未并入原δ费用或免费丢弃。

三个root-period上，通用有理检验2Hn p≤K全部true，实际删除3/P对应的更紧源费也≤K Wμ；三个P5上相同root-constant flags均false。小period正向机制由真实2Hn d收费，不能由其轻盒结果声称理论root-period已经变轻。P5保留盒6/24/2002均严格低于exp(K)有理下界，newheavy终端0；root保留盒138/3492/2180178均严格高于exp(K)上界，newheavy正交通完整保留。

canonical source盒先移除light，再池化剩余heavy判top；全部6scheme的top after-light标签均false，因此没有虚构top正覆盖。root方案确有middle质量及实际交通，整盒mean严格满足所存更强rational bound4(1+2/(P−3))^n/K；P−3≥6n及log(1+u)≤u解析保证该bound≤4exp(1/3)/K。这是整盒平均质量密度，**没有点态密度上界**；原slab高峰仍在。

birth附模块使用同一完整f的μhi=f、原细格质量HC及解析multiplicity，未枚举出生格/2^n角点。各类tC≤R1均由exp(2)区间核；n4 visible near、hidden deep，n16/n64两类deep且near-window空。n4 birth-near实际支付全部可见heavy交通，因此组合final-middle0；n16/n64的真实deep+middle流量仍为正，数值比例如表。birth-deep只作为同一固定源上的source门乘入G，μheavy/shift/packet质量从未按current x改选。n4/16/64均未达原FULL出生大维门n≥512，这些仅是实例必要条件及窗口代数认证，未赋原森林/σ/FIRST/FULL资格。

本证书认证真实source/cap/res质量平衡、partial joint traffic、走廊有偿切分、light/重终端、top/middle与出生窗口必要条件。原FULL全部门、强Lp/Cp常数数值验证、一般heavy根阶预算或统一收缩不由有限三阶段推出；source_partition的正articulation菜单没有在本producer中执行。理论period的n16/n64 actual finalmiddle并未小于X/768，不能删掉或归入旧遗漏预算。一般目标仍OPEN。

标准库自包含numeric.py内嵌唯一菜单。未改码时`python3 numeric.py`输出确定性JSON加末尾一个换行，stderr只输出耗时诊断；全部质量/密度/volume/price/certificate端点用Fraction字符串，巨大birth multiplicities为整数字符串。代码及stdout在唯一执行后冻结；本报告摘要与后续核验只解析归档，不import/执行producer。独审与父已在运行前实际完整读最终代码并静态PASS；父隔离同码重放已实际完成并独立归属，不能计为本作者第二次producer。

## 1. 执行前冻结的唯一菜单与精确输入

全边长cube；a=λ=q=1、δ=1/3072、β=δ/2、γ=β/2=1/12288。三阶段n=4,16,64，K=√n=2,4,8，D=2K，隐藏来源强度h分别2,11,1000。每个f同时检验P=5和P=Lroot两种同源方案（共6scheme states，不增加f）。Hn=1+n ln2；Lroot=3+ceil(6KHn)，用Fraction T64 ln2有向包围认证两个端点ceil相同；不能猜ceil或用float。T=5Lroot为共同long-source长度。预期Lroot为49/294/2181，须实际包围核验而非写死作为证书。

α=64^{-(n−1)}。visible source box S_v=[0,T]×∏_{j=2}^n[1/8−1/128,1/8+1/128]；hidden S_h的第二坐标改为[3/2−1/128,3/2+1/128]，其他坐标相同。两盒互不交、各真实体积Tα。f的每单位long-coordinate质量为visible3、hidden(h+Kα)，即密度3/α、(h+Kα)/α。预冻结原νω=g dz的每单位long-coordinate质量为visible(1+Kα)、hidden(h+Kα)，因此0≤ν≤f且visible上严格ν<f。来源为真实常密度非原子L1函数，不是原子或1D替代。

cap-first gcap=min(g,K)在两个支撑盒均为K，gres=g−K分别密度1/α、h/α。因此νres的真实per-length质量**精确**1与h，Wcap=2TKα、Wres=T(1+h)、Wν=Wcap+Wres≤Wf=T(3+h+Kα)。这些等式从真实密度求得，不同时误设原g=f=νres。

E=[5/2,7/2]×∏_{j=2}^n[1/8−1/32,1/8+1/32]，R=1；X=|E|=16^{-(n−1)}。visible transverse支撑全被每Qx捕获，hidden second-coordinate支撑与每Qx严格分离；visible first-coordinate capture length恒1且处于[0,T]内部。因此每x∈E上A_Rf=3，2<3≤4。所有n维volume、source密度、λ、R因子保留。

阶段1/2一标签ω0；阶段3两标签ω0/ω1各概率1/2，sourceν不随标签改变。G按来源first owner integer i的parity：ω0 even1/odd1/2，ω1互换；G在E外可置0。这是原机制测试的冻结G，非恒1；没有因此继承其他原FULL门。

## 2. 原余额/宏包/old-heavy的真实资格

unit-grid所有权：每slab在first index i=0,…,T−1有一格，visible transverse owner=(0,…,0)，hidden second owner=1而其余0。共2T个f-positive及νres-positive cells，格质量vi分别1/h。不展开所有cells：用均匀slab解析表示和有限求和认证源一次账。f-positive graph索引ℓ∞距≤3；同first i两行相连、相邻i两行相连，故只有一个连通组件；T≥4时边数13T−24。Kcover=[0,T]×[0,2]×[0,1]^{n−2}含全f支撑，t=∫Kcover^c f=0。old实际组件m=T(1+h)，用正Taylor exp(K)包围严格认证m>exp(K)，来源μheavy=νres全体，不拿f(C)代替余额质量。

Bi side5按原owner同心。任一有vi>0的packet宏包在first坐标捕获slab长度ℓ_i=min(T,i+3)−max(0,i−2)≥3；两条slab的横向支撑都在Bi内。因此mi=ℓ_i(1+h)≥3(1+h)>D·b，b=νresQx=1。任何packet aBi≤b=1，故全部H_i=0、实际Γdense=0；此证书覆盖全部2T packets，不只捕获owner。ui=Dvi/mi、Σui mi=DWres按均匀源解析核，实际相关finite packet records可列i=0,…,5两行，其余由统一界核Hfalse；不偷跳未枚举packet。对E内真实捕获owner i2/i3，其mi=5(1+h)，故F=1/[5(1+h)]<1/K，FD=0。原res lowδ门失败流量0，G1=G，I11公式在已说明支配类中的真实heavy交通实例为正，**非已认证FULL原难支实例**。actualG1是按新余额重算出的原门子交通，不是任意指定的外放松。

## 3. 周期切分、最小lex shift与source费

每P方案，按各坐标(i−s_j) mod P∈{0,1,2}删除source格；其余格保留。shift在{0,…,P−1}^n中选择真实μheavy删除mass最小者，tie取lex最小。候选s=(0,2,1,…,1)：first uniform source长度T为P整数倍，所以每first shift精确删除3/P来源质量；其他坐标删除只能增加，故所有shift删质量≥3/P·Wres。s2=2避开second owners0/1，其余sj=1避开owner0，达到下界。first s1=0是最小；second s2=0或1均删掉正来源，s2=2首次不删；其余sj=0删正来源，sj=1首次不删。因此s为**实际最小lex最优shift**，不用P^n枚举/贪心。

实际删除质量d=3T(1+h)/P、保留质量Wkeep=(P−3)T(1+h)/P。n维随机shift上界p=1−(1−3/P)^n仍精确存，核d≤pWres，不把actual3/P误当通用高维删除比例。切分费上界2Hn d，亦存通用2Hn pWres。理论P=Lroot用有理Hn上端认证2Hn p≤K，故root boundary source费≤K Wres；P5仅结构压力，root flag可能false，绝不拿小P费称根阶。

真实保留盒first区间[jP+3,(j+1)P)，second区间[5−P,2)，其他[4−P,1)，都side(P−3)，j=0,…,T/P−1。只有这些T/P个盒有source，其余盒来源0。每盒实际mB=(P−3)(1+h)，label前冻结。所有来源compact，source尾仍0。P5的mB=6/24/2002须通过exp(K)有理下界认证light；root P的mB=(Lroot−3)(1+h)须通过exp(K)有理上界认证heavy；未知则UNKNOWN停止，不追加菜单或精度。

## 4. 跨块捕获与实际切分交通

同一E的Qx正捕获visible owner cell2的deleted来源及cell3的retained来源；hidden从不捕获。令r=x1−5/2∈[0,1]，deleted/kept实际capture masses分别1−r、r。两者均是真实n维正来源积分；不能扔掉跨走廊接收点。retained packet uB=1{mB≥γ}=1、cB=γ/mB、贡献阈值γ；H_B={bB≥cB mB且bB≥γR^n}在捕获盒j0上恰为r≥γ，其他盒Hfalse。receiver预冻结精确分段E_low:[5/2,5/2+γ)、E_high:[5/2+γ,7/2]；标签源相同，分段不变。新low不是原δ low，必须另以删除source尾转移付费。

固定R的source×receiver joint strip体积用独立端点原函数计算：I=[A,B],J=[C,D]，V(t)=[(D+t−A)_+²−(C+t−A)_+²−(D+t−B)_+²+(C+t−B)_+²]/2；捕获area=V(1/2)−V(−1/2)，n维乘各坐标area。统一门用整receiver盒capture界核，不用joint均值代替点态H。G在source cell2/3上分别为1/1/2或1/2/1，真实交通为density×jointvolume×G（R^n=1），保留E/source体积。全E两source strip area各1/2；分段面积直接原函数求，另用∫_0^γr dr=γ²/2和∫_γ^1r dr=(1−γ²)/2交叉核验，非同表达式镜像。

逐pair核Tres=Tdeleted+Tkept_low+Tkept_high；原ν流量Tν=Tcap+Tres，及Γdense0/G1身份；保留新packet对kept_high的Γnew=1，而deleted Γnew0、kept_low Hfalse。核实际deleted+kept_low≤2Hn d，原b=1≥β，low b'=r<γ⇒deleted capture1−r>b'是同一原G1的有效尾转移依据。source費不会从uniformreceiver强制忽略crossblock。

P5所有kept boxes为light，付实际kept_high，新localheavy terminal0；root P所有kept boxesheavy，light payment0，actual kept_high作为newheavy终端完整保留。label0实际Tdeleted=X/2、Tkept_low=γ²X/4、Tkept_high=(1−γ²)X/4；label1分别X/4、γ²X/2、(1−γ²)X/2。这些解析预期由独立joint-volume计算实际核，不写死输出当测量。两标签总Tres均3X/4。stage3期待取概率平均。

source价记录mass coupon/成本与实际traffic分开。light统一价上界[1+log(4/γ²)+K]Wkeep，log(4/γ²)=2log(3/2)+28log2；heavy已知有限价HnWkeep作为保守备选，不把它当root已付。候选正付款为cut fee+light fee+newheavy actual terminal。原cap强Lp常数Cp不在此数值验证范围。

## 5. 同源canonical-box top/middle观测与组合余项

在每个预冻结保留盒先支付light，再**池化盒内所有剩余heavy余额来源**，本例只有一个old组件，不使用逐component mean替代整盒mean。记录raw mB/(P−3)^n、top阈值Mtop=4(P−1)^n/K、after-light质量m_afterlight=mB（heavy）或0（light）；top′=1{m_afterlight≥Mtop}，middle=1{m_afterlight>0且m_afterlight<Mtop}，标签均在receiver前冻结。P5已light，故afterlight0；root虽heavy但预期top′false/middletrue，不写死top结果。actual Ttop=Tkept_high·top′、Tmid=Tkept_high·middle，核Tkept_high=Tlight+Ttop+Tmid；top候选源价K·Wtop与实际Ttop单列，不把没有top交通写成验证一般新根阶定理。

root P用Fraction核P−3≥6n（由定义P−3≥6KHn且Hn≥K，亦直接整数核）。池化top删后m_aftertop<Mtop时canonical mean严格小于4[1+2/(P−3)]^n/K；保存这一**更强可计算有理上界**。独立解析证明ln(1+u)=∫_0^u(1+t)^−1dt≤u给nln[1+2/(P−3)]≤2n/(P−3)≤1/3，故有理上界≤4exp(1/3)/K；不新增exp(1/3)数值或把smallP的mean当同一理论保证。

birth必要条件observables按下一节分类后，可另记录birthnear先付的同一原G1实际交通，及组合finalmid=Tkept_high·deep(source)·middle(box)。这是在**固定μheavy/shift/包质量**上添加实际source门；不因某个x免费重选μ、shift或packet。n4预计visible near导致组合finalmid0，而n16/n64 root-period visible deep且middle，真实正finalmid须保留；不从此有限数据声称收缩。

## 6. 同输入出生窗口必要条件观测（非FULL继承）

仅作附加解析observable：q=1、d0=1/n birth-grid，μhi=f1{f>K}=f（由真实密度核）。不声明原共享森林/出生门已构造。已实际读hard_constraints全文：原FULL出生大维路线n≥512，本菜单三个维数均未达到；其B1–B2代数必要条件可以逐实例认证，但不能移作原FULL资格。沿first有Tn个full birth cells；n4 visible transverse不跨birth边界，HC_v=3/n、multiplicity=Tn；hidden second跨1.5 birth边界，HC_h=(h+Kα)/(2n)、multiplicity=2Tn。n16/n64所有n−1 transverse坐标center为birth边界，HC_v=3/(n2^{n−1})、HC_h=(h+Kα)/(n2^{n−1})、每slab multiplicity=Tn2^{n−1}。这些只按解析乘积积分和整数计数，不展开2^n角点或birth cells；核HC×multiplicity=对应f总质量。

tC^n=HC K/exp(2)，用正exp(2)有理区间核每类tC^n≤R^n=1。窗口参数Lbirth=K，near条件nlog(R/tC)≤K等价HC K exp(K)/exp(2)≥1；有向ratio下界≥1认证near、上界<1认证deep，否则UNKNOWN。JC^n=[1,2^n]∩[tC^n,tC^n exp(K)]，输出空窗/含R1标签及端点包围；实际visible near/deep子交通依同G1/真实jointvolume分开，隐藏类actualtraffic0仍source mass照记。预计n4 visible near、hidden deep；n16/n64均deep。只核合法的质量/出生必要条件和window algebra，不把它新增原FULLstatus或继承原σ资格。

## 7. 精度、计数、执行控制

Fraction标准库，log2/log(3/2)用64项正atanh级数及全部geometric tail，exp(2/4/8)用64项Taylor j0..63，next=K^64/64!，tail≤next/(1−K/65)。log/exp端点与mass/traffic字符串分离，ceil/比较方向明确。代码除少量真实captured unit sourcepieces、receiver cells、scheme/labels外不展开P^n shift、2T图全部节点、2^n birth角点。均匀/slab/full-support和connected ladder的解析证书保留，不能把无执行枚举写成已枚举。

固定3个f实例/6个真实source slab boxes、ν标签1/1/2（共4）；每实例两period（共6scheme states），每标签每period2个receiver rowcells、每行2个positive source paircells，合16scheme-label rows/32positive joint paircells。同一几何在两个period复核不增加physical f。代码保存所有actual records、cost/residual、original/dense/heavy身份、完整stdout与exit/timing/code-output hashes；只在父+独审完整statement筛查后实现/自审/唯一producer执行，父隔离同码重放独立归属。FAIL或UNKNOWN停止，不扩大输入。

此protocol已由主代理及独审完整statement筛查PASS；最终代码双方完整静态读PASS，随后完成唯一producer。一般heavy根阶或统一收缩仍须证明；本例的root-period重终端预期仍正，不以L5正付款删除理论period终端。



## 唯一producer实际回执

```json
{
  "role": "producer sole actual execution",
  "command": "python3 numeric.py",
  "exit_code": 0,
  "outer_runtime_seconds_diagnostic": 0.07763712499945541,
  "stderr_utf8": "{\"runtime_seconds_diagnostic\": 0.05528420799964806}\n",
  "python": "3.14.6 (main, Jun 10 2026, 10:03:53) [Clang 21.0.0 (clang-2100.0.123.102)]",
  "code_bytes": 27358,
  "code_sha256": "845f884b471472ecc2b58369b9c568c079775b4a09eba19d1dfda7ff23b0e464",
  "stdout_bytes": 450267,
  "stdout_sha256": "c41bec5c07196eaa4a5948280517bc957004995ca878a2b073f2cc5f86a985ed",
  "execution_count": 1,
  "additional_inputs_or_precision_refinements": 0
}
```

## 实际摘要（解析完整stdout，不重跑）

```json
{
  "status": "PASS",
  "counts": {
    "additional_inputs_or_precision_refinements": 0,
    "physical_f_instances": 3,
    "physical_source_slab_boxes": 6,
    "positive_joint_pair_cells": 32,
    "pre_frozen_nu_labels": 4,
    "producer_execution_menu_passes": 1,
    "scheme_label_rows": 16,
    "scheme_states": 6,
    "shift_or_birth_corner_enumerations": 0
  },
  "records": [
    {
      "n": 4,
      "Lroot": 49,
      "T": 245,
      "W_res": "735",
      "F": "1/15",
      "birth_near_visible": true,
      "schemes": [
        {
          "P": 5,
          "d": "441",
          "mB": "6",
          "light": true,
          "heavy": false,
          "top": false,
          "middle": false,
          "root_constant_test": false,
          "T_heavy_over_X": "0",
          "finalmiddle_over_X": "0"
        },
        {
          "P": 49,
          "d": "45",
          "mB": "138",
          "light": false,
          "heavy": true,
          "top": false,
          "middle": true,
          "root_constant_test": true,
          "T_heavy_over_X": "150994943/603979776",
          "finalmiddle_over_X": "0"
        }
      ]
    },
    {
      "n": 16,
      "Lroot": 294,
      "T": 1470,
      "W_res": "17640",
      "F": "1/60",
      "birth_near_visible": false,
      "schemes": [
        {
          "P": 5,
          "d": "10584",
          "mB": "24",
          "light": true,
          "heavy": false,
          "top": false,
          "middle": false,
          "root_constant_test": false,
          "T_heavy_over_X": "0",
          "finalmiddle_over_X": "0"
        },
        {
          "P": 294,
          "d": "180",
          "mB": "3492",
          "light": false,
          "heavy": true,
          "top": false,
          "middle": true,
          "root_constant_test": true,
          "T_heavy_over_X": "150994943/603979776",
          "finalmiddle_over_X": "150994943/603979776"
        }
      ]
    },
    {
      "n": 64,
      "Lroot": 2181,
      "T": 10905,
      "W_res": "10915905",
      "F": "1/5005",
      "birth_near_visible": false,
      "schemes": [
        {
          "P": 5,
          "d": "6549543",
          "mB": "2002",
          "light": true,
          "heavy": false,
          "top": false,
          "middle": false,
          "root_constant_test": false,
          "T_heavy_over_X": "0",
          "finalmiddle_over_X": "0"
        },
        {
          "P": 2181,
          "d": "15015",
          "mB": "2180178",
          "light": false,
          "heavy": true,
          "top": false,
          "middle": true,
          "root_constant_test": true,
          "T_heavy_over_X": "150994943/402653184",
          "finalmiddle_over_X": "150994943/402653184"
        }
      ]
    }
  ]
}
```


## 独审完整数据阅读与父隔离重放回执

独审已实际完整静态读取27358字节最终代码、全部narrative及450267字节原始stdout，未import/执行producer。其独立saved-data审核遍历10142节点、6758有理串和83个interval，以不同的梯形积分重算全部32个jointpairs，核16rows/6schemes source/traffic账、Γ门、根费、source价及birth-first组合界，PASS；这是审核者报告的实际静态检查，不是本作者新增运行。

父实际隔离复制同一代码运行一次，stdout450267字节与归档逐字节一致、exit0；outer0.078934209s，stderr仅inner0.057343500s计时JSON。其独立解析source/traffic conservation、root boundary fee及positive middle，并明确original_FULL_certified=false。本作者实际读取parent_numeric_receipt.json后将原文回执归档；不把父执行计入自己唯一producer。两次程序调用归属为producer1次＋parent replay1次，没有其他菜单或重跑。该receipt文件SHA256为0e946f02691a1bfbae5ea02d5c78dbd4d7b765515f6b7a46cf3393ed2b9c7bbd。

```json
{
  "status": "PASS",
  "source_sha256": "845f884b471472ecc2b58369b9c568c079775b4a09eba19d1dfda7ff23b0e464",
  "source_bytes": 27358,
  "stdout_sha256": "c41bec5c07196eaa4a5948280517bc957004995ca878a2b073f2cc5f86a985ed",
  "stdout_bytes": 450267,
  "stdout_identical": true,
  "exit_code": 0,
  "execution_count": 1,
  "producer_execution_count": 1,
  "isolated_copy": true,
  "python": "3.14.6 (main, Jun 10 2026, 10:03:53) [Clang 21.0.0 (clang-2100.0.123.102)]",
  "wall_seconds_diagnostic": 0.0789342089992715,
  "stderr_utf8": "{\"runtime_seconds_diagnostic\": 0.0573435000005702}\n",
  "counts": {
    "additional_inputs_or_precision_refinements": 0,
    "physical_f_instances": 3,
    "physical_source_slab_boxes": 6,
    "positive_joint_pair_cells": 32,
    "pre_frozen_nu_labels": 4,
    "producer_execution_menu_passes": 1,
    "scheme_label_rows": 16,
    "scheme_states": 6,
    "shift_or_birth_corner_enumerations": 0
  },
  "additional_parent_checks": {
    "rowcells": 16,
    "paircells": 32,
    "source_and_traffic_conservation": true,
    "root_boundary_fee": true,
    "retained_positive_middle": true,
    "original_FULL_certified": false
  },
  "stage_summaries": [
    {
      "n": 4,
      "P": 5,
      "root": false,
      "light": true,
      "middle": false,
      "final_middle_over_X": "0"
    },
    {
      "n": 4,
      "P": 49,
      "root": true,
      "light": false,
      "middle": true,
      "final_middle_over_X": "0"
    },
    {
      "n": 16,
      "P": 5,
      "root": false,
      "light": true,
      "middle": false,
      "final_middle_over_X": "0"
    },
    {
      "n": 16,
      "P": 294,
      "root": true,
      "light": false,
      "middle": true,
      "final_middle_over_X": "150994943/603979776"
    },
    {
      "n": 64,
      "P": 5,
      "root": false,
      "light": true,
      "middle": false,
      "final_middle_over_X": "0"
    },
    {
      "n": 64,
      "P": 2181,
      "root": true,
      "light": false,
      "middle": true,
      "final_middle_over_X": "150994943/402653184"
    }
  ]
}
```

## 完整原始stdout

以下JSON及末尾一个换行完整恢复实际stdout，不截断或重排。

```json
{
  "counts": {
    "additional_inputs_or_precision_refinements": 0,
    "physical_f_instances": 3,
    "physical_source_slab_boxes": 6,
    "positive_joint_pair_cells": 32,
    "pre_frozen_nu_labels": 4,
    "producer_execution_menu_passes": 1,
    "scheme_label_rows": 16,
    "scheme_states": 6,
    "shift_or_birth_corner_enumerations": 0
  },
  "exp_series": {
    "positive_terms_j_0_through_63": 64,
    "tail": "next=K^64/64!; <=next/(1-K/65)"
  },
  "logs": {
    "ln2": {
      "lower": "3508595171842993185134796784736611366655501408312351140098685578379184556173245757359910454882815130815005200896/5061832854904846645955900741673035877578026003792249877488563088418276175757042525151232593509677298791370051125",
      "upper": "42103142062115918221617561416839336399866016899748213681184226970503191837707222979818147583109816019560407766877/60741994258858159751470808900076430530936312045506998529862757061019314109084510301814791122116127585496440613500"
    },
    "ln_3_over_2": {
      "lower": "99448331066922616689242862152928156760049037851038926218707721402650129923939425104613497764131644308716364224391398517987195528995799033344/245269763237908906160973151628447474866476827707793781098319518935963034544300150534613323686884754463999325224676795187406241893768310546875",
      "upper": "397793324267690466756971448611712627040196151404155704874830885610600519695757700418453991067309649013771635498505314036774554517904120461581/981079052951635624643892606513789899465907310831175124393278075743852138177200602138453294747539017855997300898707180749624967575073242187500"
    },
    "positive_atanh_terms": 64,
    "tail": "2*z^129/[129*(1-z^2)] fully charged"
  },
  "publication": "PUBLIC independent two-slab physical mechanism; no private recipes",
  "records": [
    {
      "Af_whole_receiver_bounds": {
        "lower": "3",
        "upper": "3"
      },
      "D": "4",
      "E_bounds": [
        [
          "5/2",
          "7/2"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ]
      ],
      "F_D_exact": "0",
      "F_captured_exact": "1/15",
      "Gamma_dense_all_actual_pairs": "0",
      "Hn": {
        "lower": "19096213542276819386495087880619481344200031637041654437883305401935014400450025554590874413040937822051390854709/5061832854904846645955900741673035877578026003792249877488563088418276175757042525151232593509677298791370051125",
        "upper": "57288640626830458159485263641858444032600094911124963313649916235758020364978350555271845363638847915934517920252/15185498564714539937867702225019107632734078011376749632465689265254828527271127575453697780529031896374110153375"
      },
      "K": "2",
      "Lroot": 49,
      "T_source_length": 245,
      "X": "1/4096",
      "a": "1",
      "beta": "1/6144",
      "birth_observations": {
        "d0": "1/4",
        "mu_hi_equals_f_by_actual_density": true,
        "near_source_mass": "245",
        "near_source_price_upper_1_plus_K": "735",
        "near_visible": true,
        "original_FULL_certified": false,
        "original_FULL_large_dimension_threshold": 512,
        "q": "1",
        "scope": "Actual HC and birth/window necessary-condition observations on this dominating-class input; not inherited original FULL/birth forest.",
        "types": [
          {
            "HC_mu_hi_full_f": "3/4",
            "HC_times_multiplicity_f_mass": "735",
            "J_C_power_n_empty": false,
            "J_C_power_n_lower_if_nonempty": "1",
            "J_C_power_n_upper_if_nonempty": {
              "lower": "19212237136148142917714524771543442236076258996256070643277107151320388111/12808158090765428611809683181028961490717505997504047095518071434213592334",
              "upper": "6404079045382714305904841590514480745358752998752023547759035717106796167/4269386030255142870603227727009653830239168665834682365172690478071197358"
            },
            "birth_L": "2",
            "birth_d0": "1/4",
            "deep_at_R1": false,
            "multiplicity_analytic_not_enumerated": "980",
            "near_at_R1": true,
            "res_mass_source_once": "245",
            "slab": "visible",
            "t_C_le_R1": true,
            "t_C_power_n": {
              "lower": "2600093554429577597783216690588417224744026603012693262762569964599609375/12808158090765428611809683181028961490717505997504047095518071434213592334",
              "upper": "41271326260786945996558995088705035313397247666868147027977301025390625/203304096678816327171582272714745420487579460277842017389175737051009398"
            },
            "t_C_power_n_times_exp_L": {
              "lower": "19212237136148142917714524771543442236076258996256070643277107151320388111/12808158090765428611809683181028961490717505997504047095518071434213592334",
              "upper": "6404079045382714305904841590514480745358752998752023547759035717106796167/4269386030255142870603227727009653830239168665834682365172690478071197358"
            }
          },
          {
            "HC_mu_hi_full_f": "262145/1048576",
            "HC_times_multiplicity_f_mass": "64225525/131072",
            "J_C_power_n_empty": true,
            "J_C_power_n_lower_if_nonempty": null,
            "J_C_power_n_upper_if_nonempty": null,
            "birth_L": "2",
            "birth_d0": "1/4",
            "deep_at_R1": true,
            "multiplicity_analytic_not_enumerated": "1960",
            "near_at_R1": false,
            "res_mass_source_once": "490",
            "slab": "hidden",
            "t_C_le_R1": true,
            "t_C_power_n": {
              "lower": "227200508275313873123627113118100211126840951282254158455631301123321533203125/3357581794545612518014237587807656081022649892209700921807489318050487948804096",
              "upper": "3606357274211331319422652589176193827410173829877050134216369859100341796875/53294949119771627270067263298534223508296030035074617806468084413499807629312"
            },
            "t_C_power_n_times_exp_L": {
              "lower": "1678797301351851641721424698745418554992070304857849212927292418060961047119365/3357581794545612518014237587807656081022649892209700921807489318050487948804096",
              "upper": "1678797301351851641721424698745418554992070304857849212927292418060961081198215/3357581794545612518014237587807656081022649892209700921807489318050487880646656"
            }
          }
        ]
      },
      "ceil_6K_Hn": {
        "ceil_lower": 46,
        "ceil_upper": 46,
        "input_interval": {
          "lower": "76384854169107277545980351522477925376800126548166617751533221607740057601800102218363497652163751288205563418836/1687277618301615548651966913891011959192675334597416625829521029472758725252347508383744197836559099597123350375",
          "upper": "229154562507321832637941054567433776130400379644499853254599664943032081459913402221087381454555391663738071681008/5061832854904846645955900741673035877578026003792249877488563088418276175757042525151232593509677298791370051125"
        },
        "unique_certified": true
      },
      "counts": {
        "physical_f_instances": 1,
        "physical_source_slab_boxes": 2,
        "positive_joint_pair_cells": 8,
        "pre_frozen_nu_labels": 1,
        "scheme_label_rows": 4,
        "scheme_states": 2
      },
      "crosssection_volume_alpha": "1/262144",
      "delta": "1/3072",
      "dense_packets_global_closed_certificate": {
        "all_packet_H_false_strict_residual": "5",
        "all_packet_aBi_upper": "1",
        "cell_v_hidden": "2",
        "cell_v_visible": "1",
        "first_i_range": [
          0,
          244
        ],
        "macro_m_formula": "ell_i(1+h), ell_i=min(T,i+3)-max(0,i-2)>=3",
        "minimum_macro_mass": "9",
        "relevant_direct_integral_packets": [
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 0,
            "m_direct_integral": "9",
            "m_over_D": "9/4",
            "second_owner": 0,
            "u": "4/9",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 0,
            "m_direct_integral": "9",
            "m_over_D": "9/4",
            "second_owner": 1,
            "u": "8/9",
            "v": "2"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 1,
            "m_direct_integral": "12",
            "m_over_D": "3",
            "second_owner": 0,
            "u": "1/3",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 1,
            "m_direct_integral": "12",
            "m_over_D": "3",
            "second_owner": 1,
            "u": "2/3",
            "v": "2"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 2,
            "m_direct_integral": "15",
            "m_over_D": "15/4",
            "second_owner": 0,
            "u": "4/15",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 2,
            "m_direct_integral": "15",
            "m_over_D": "15/4",
            "second_owner": 1,
            "u": "8/15",
            "v": "2"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 3,
            "m_direct_integral": "15",
            "m_over_D": "15/4",
            "second_owner": 0,
            "u": "4/15",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 3,
            "m_direct_integral": "15",
            "m_over_D": "15/4",
            "second_owner": 1,
            "u": "8/15",
            "v": "2"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 4,
            "m_direct_integral": "15",
            "m_over_D": "15/4",
            "second_owner": 0,
            "u": "4/15",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 4,
            "m_direct_integral": "15",
            "m_over_D": "15/4",
            "second_owner": 1,
            "u": "8/15",
            "v": "2"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 5,
            "m_direct_integral": "15",
            "m_over_D": "15/4",
            "second_owner": 0,
            "u": "4/15",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 5,
            "m_direct_integral": "15",
            "m_over_D": "15/4",
            "second_owner": 1,
            "u": "8/15",
            "v": "2"
          }
        ],
        "source_once_coupon": "2940",
        "total_nonzero_packets_not_enumerated": 490
      },
      "gamma_new": "1/12288",
      "hidden_per_length_res_mass": "2",
      "lambda": "1",
      "n": 4,
      "nu_label_probabilities": [
        "1"
      ],
      "old_f_positive_graph": {
        "Kcover_bounds": [
          [
            "0",
            "245"
          ],
          [
            "0",
            "2"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ]
        ],
        "actual_res_component_mass": "735",
        "components": 1,
        "edges_analytic_count": 3161,
        "exp_K": {
          "lower": "101652048339408163585791136357372710243789730138921008694587868525504699/13757108753595648665519665029568345104465749222289382342659100341796875",
          "upper": "6404079045382714305904841590514480745358752998752023547759035717106796167/866697851476525865927738896862805741581342201004231087587523321533203125"
        },
        "f_tail_outside_K_exact": "0",
        "old_heavy_certified": true,
        "positive_cells_analytic_count": 490,
        "proof": "Two adjacent positive rows along first indices 0..T-1; adjacent index cells connect; fixed index l_infinity distance<=3. Other cells source0 analytically; no full grid enumeration."
      },
      "original_delta_low_traffic": "0",
      "res_capture_b_whole_receiver": "1",
      "schemes": [
        {
          "P": 5,
          "W_light": "294",
          "W_middle": "0",
          "W_top_after_light": "0",
          "actual_delete_fraction": "3/5",
          "beta_new": "1/12288",
          "birth_first_final_middle_over_X": "0",
          "birth_near_source_price_upper": "735",
          "boundary_fee_using_actual_delete_mass": {
            "lower": "38192427084553638772990175761238962688400063274083308875766610803870028800900051109181748826081875644102781709418/11478079036065411895591611659122530334644049895220521264146401561039175001716649716896219032901762582293356125",
            "upper": "114577281253660916318970527283716888065200189822249926627299832471516040729956701110543690727277695831869035840504/34434237108196235686774834977367591003932149685661563792439204683117525005149949150688657098705287746880068375"
          },
          "boundary_fee_using_universal_p": {
            "lower": "267346989591875471410931230328672738818800442918583162130366275627090201606300357764272241782573129508719471965926/49474478603730223687894877841045389373465732306985005448906903280341271559123490159035426865955873199540328125",
            "upper": "802040968775626414232793690986018216456401328755749486391098827300612285109696907773805835090943870823083250883528/148423435811190671063684633523136168120397196920955016346720709841023814677370470477106280597867619598620984375"
          },
          "box_mass_times_analytic_count": "294",
          "c": "1/73728",
          "counts": {
            "physical_f_inputs_added": 0,
            "positive_joint_pair_cells": 4,
            "scheme_label_rows": 2,
            "source_shift_enumerations": 0
          },
          "delete_mass_actual": "441",
          "each_kept_box_mass_actual": "6",
          "heavy_certified": false,
          "heavy_finite_alternative_Hn_Wkeep": {
            "lower": "0",
            "upper": "0"
          },
          "is_root_period": false,
          "kept_box_volume": "16",
          "kept_boxes_analytic_count": 49,
          "labels": [
            {
              "label": 0,
              "ledger": {
                "T_birth_deep": "0",
                "T_birth_near": "3/16384",
                "T_cap": "3/2147483648",
                "T_deleted": "1/8192",
                "T_deleted_after_birth": "0",
                "T_final_middle": "0",
                "T_kept_high": "150994943/2473901162496",
                "T_kept_low": "1/2473901162496",
                "T_light": "150994943/2473901162496",
                "T_light_after_birth": "0",
                "T_low_after_birth": "0",
                "T_middle": "0",
                "T_new_heavy": "0",
                "T_nu": "393219/2147483648",
                "T_res": "3/16384",
                "T_top": "0",
                "T_top_after_birth": "0"
              },
              "probability": "1",
              "rows": [
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/15",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "0",
                  "T_birth_near": "49151/2473901162496",
                  "T_cap": "49151/324259173170675712",
                  "T_deleted": "24575/1236950581248",
                  "T_deleted_after_birth": "0",
                  "T_final_middle": "0",
                  "T_kept_high": "0",
                  "T_kept_low": "1/2473901162496",
                  "T_light": "0",
                  "T_light_after_birth": "0",
                  "T_low_after_birth": "0",
                  "T_middle": "0",
                  "T_new_heavy": "0",
                  "T_nu": "2147456341/108086391056891904",
                  "T_res": "49151/2473901162496",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "12287/12288",
                    "upper": "1"
                  },
                  "kept_capture_bounds": {
                    "lower": "0",
                    "upper": "1/12288"
                  },
                  "kept_packet_H_constant_on_halfopen_row": false,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_low_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "0",
                      "T_birth_near": "24575/1236950581248",
                      "T_cap": "24575/162129586585337856",
                      "T_deleted": "24575/1236950581248",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "1073706325/54043195528445952",
                      "T_res": "24575/1236950581248",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": true,
                      "cap_density": "2",
                      "f_density": "786432",
                      "independent_affine_capture_area": "24575/301989888",
                      "nu_density": "262146",
                      "raw_joint_capture_volume": "24575/324259173170675712",
                      "res_density": "262144",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/262144"
                    },
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "0",
                      "T_birth_near": "1/2473901162496",
                      "T_cap": "1/324259173170675712",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "1/2473901162496",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "43691/108086391056891904",
                      "T_res": "1/2473901162496",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": true,
                      "cap_density": "2",
                      "f_density": "786432",
                      "independent_affine_capture_area": "1/301989888",
                      "nu_density": "262146",
                      "raw_joint_capture_volume": "1/324259173170675712",
                      "res_density": "262144",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/262144"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "5/2",
                      "30721/12288"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "1/50331648",
                  "right_endpoint_excluded_for_low": true
                },
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/15",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "0",
                  "T_birth_near": "452935681/2473901162496",
                  "T_cap": "452935681/324259173170675712",
                  "T_deleted": "150970369/1236950581248",
                  "T_deleted_after_birth": "0",
                  "T_final_middle": "0",
                  "T_kept_high": "150994943/2473901162496",
                  "T_kept_low": "0",
                  "T_light": "150994943/2473901162496",
                  "T_light_after_birth": "0",
                  "T_low_after_birth": "0",
                  "T_middle": "0",
                  "T_new_heavy": "0",
                  "T_nu": "19789212838571/108086391056891904",
                  "T_res": "452935681/2473901162496",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "0",
                    "upper": "12287/12288"
                  },
                  "kept_capture_bounds": {
                    "lower": "1/12288",
                    "upper": "1"
                  },
                  "kept_packet_H_constant_on_halfopen_row": true,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_high_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "0",
                      "T_birth_near": "150970369/1236950581248",
                      "T_cap": "150970369/162129586585337856",
                      "T_deleted": "150970369/1236950581248",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "6596046391979/54043195528445952",
                      "T_res": "150970369/1236950581248",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": true,
                      "cap_density": "2",
                      "f_density": "786432",
                      "independent_affine_capture_area": "150970369/301989888",
                      "nu_density": "262146",
                      "raw_joint_capture_volume": "150970369/324259173170675712",
                      "res_density": "262144",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/262144"
                    },
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "1",
                      "T_birth_deep": "0",
                      "T_birth_near": "150994943/2473901162496",
                      "T_cap": "150994943/324259173170675712",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "150994943/2473901162496",
                      "T_kept_low": "0",
                      "T_light": "150994943/2473901162496",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "6597120054613/108086391056891904",
                      "T_res": "150994943/2473901162496",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": true,
                      "cap_density": "2",
                      "f_density": "786432",
                      "independent_affine_capture_area": "150994943/301989888",
                      "nu_density": "262146",
                      "raw_joint_capture_volume": "150994943/324259173170675712",
                      "res_density": "262144",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/262144"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "30721/12288",
                      "7/2"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "12287/50331648",
                  "right_endpoint_excluded_for_low": false
                }
              ]
            }
          ],
          "ledger": {
            "T_birth_deep": "0",
            "T_birth_near": "3/16384",
            "T_cap": "3/2147483648",
            "T_deleted": "1/8192",
            "T_deleted_after_birth": "0",
            "T_final_middle": "0",
            "T_kept_high": "150994943/2473901162496",
            "T_kept_low": "1/2473901162496",
            "T_light": "150994943/2473901162496",
            "T_light_after_birth": "0",
            "T_low_after_birth": "0",
            "T_middle": "0",
            "T_new_heavy": "0",
            "T_nu": "393219/2147483648",
            "T_res": "3/16384",
            "T_top": "0",
            "T_top_after_birth": "0"
          },
          "light_certified": true,
          "light_source_price_upper": {
            "lower": "7570245233736722596481260847024143118611522682364741122252582415121084676808051177672026023288118111776291123643272487721336385235212155709683973562110465179995572074539991340731343465552388144435174/1108965786179722103056862020981486823672078258795955443100623073144245226649475196394609526652073209286627575514449462073571751817888904983897393702891166593349492330844441312365233898162841796875",
            "upper": "22710735701210167789443782541072429355834568047094223366757747258868288996072270949719613137664241173607844114489515677101294144049281143243949475354107874452742216582734731307633144940007991721429157/3326897358539166309170586062944460471016234776387866329301869219432735679948425589183828579956219627859882726543348386220715255453666714951692181108673499780048476992533323937095701694488525390625"
          },
          "middle_after_light": false,
          "new_heavy_terminal_over_X": "0",
          "p_universal_exact": "609/625",
          "pooled_after_light_mass_per_box": "0",
          "pooled_after_top_box_mean": "0",
          "rational_mean_upper_after_top": "32",
          "raw_box_mean": "3/8",
          "representative_first_kept_box_bounds": [
            [
              "3",
              "5"
            ],
            [
              "0",
              "2"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ]
          ],
          "retained_mass_actual": "294",
          "root_constant_test_2_Hn_actual_fraction_le_K": false,
          "root_constant_test_2_Hn_p_le_K": false,
          "root_exp_one_third_mean_proof": {
            "P_minus_3_ge_6n": false,
            "certified_for_root_only": false,
            "proof": "For root period only: log(1+u)<=u from positive integral; 2n/(P-3)<=1/3 gives (1+2/(P-3))^n<=exp(1/3). Small P has no such certification; no exp(1/3) numerical evaluation.",
            "twon_over_P_minus_3": "4"
          },
          "shift_optimal_lex": [
            0,
            2,
            1,
            1
          ],
          "shift_proof": "Full uniform T/P first-coordinate periods force deletion>=3/P for every shift; compact coordinates (0,1), then (0) permit exactly shift(0,2,1,...), lex first among equality choices.",
          "top_after_light": false,
          "top_source_price_upper_K_Wtop": "0",
          "top_threshold_actual": "512",
          "u": "1",
          "zero_captured_remainder_certificates": [
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate",
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate",
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate"
          ]
        },
        {
          "P": 49,
          "W_light": "0",
          "W_middle": "690",
          "W_top_after_light": "0",
          "actual_delete_fraction": "3/49",
          "beta_new": "1/12288",
          "birth_first_final_middle_over_X": "0",
          "birth_near_source_price_upper": "735",
          "boundary_fee_using_actual_delete_mass": {
            "lower": "38192427084553638772990175761238962688400063274083308875766610803870028800900051109181748826081875644102781709418/112485174553441036576797794259400797279511688973161108388634735298183915016823167225582946522437273306474890025",
            "upper": "114577281253660916318970527283716888065200189822249926627299832471516040729956701110543690727277695831869035840504/337455523660323109730393382778202391838535066919483325165904205894551745050469501676748839567311819919424670075"
          },
          "boundary_fee_using_universal_p": {
            "lower": "172515193140928786337596623913516394463503085809034306191837781001080920093665530860173959447411832284412264981441106/139302824221450363286565091545518362096181796800036118324363031295747783345412934746553769214928660707720677226855",
            "upper": "517545579422786359012789871740549183390509257427102918575513343273837955977214418916325851015113352072552434891556568/417908472664351089859695274636555086288545390400108354973089093887243350036238804239661307644785982123162031680565"
          },
          "box_mass_times_analytic_count": "690",
          "c": "1/1695744",
          "counts": {
            "physical_f_inputs_added": 0,
            "positive_joint_pair_cells": 4,
            "scheme_label_rows": 2,
            "source_shift_enumerations": 0
          },
          "delete_mass_actual": "45",
          "each_kept_box_mass_actual": "138",
          "heavy_certified": true,
          "heavy_finite_alternative_Hn_Wkeep": {
            "lower": "38192427084553638772990175761238962688400063274083308875766610803870028800900051109181748826081875644102781709418/14671979289579265640451886207747930079936307257368840224604530691067467176107369638119514763796166083453246525",
            "upper": "114577281253660916318970527283716888065200189822249926627299832471516040729956701110543690727277695831869035840504/44015937868737796921355658623243790239808921772106520673813592073202401528322108914358544291388498250359739575"
          },
          "is_root_period": true,
          "kept_box_volume": "4477456",
          "kept_boxes_analytic_count": 5,
          "labels": [
            {
              "label": 0,
              "ledger": {
                "T_birth_deep": "0",
                "T_birth_near": "3/16384",
                "T_cap": "3/2147483648",
                "T_deleted": "1/8192",
                "T_deleted_after_birth": "0",
                "T_final_middle": "0",
                "T_kept_high": "150994943/2473901162496",
                "T_kept_low": "1/2473901162496",
                "T_light": "0",
                "T_light_after_birth": "0",
                "T_low_after_birth": "0",
                "T_middle": "150994943/2473901162496",
                "T_new_heavy": "150994943/2473901162496",
                "T_nu": "393219/2147483648",
                "T_res": "3/16384",
                "T_top": "0",
                "T_top_after_birth": "0"
              },
              "probability": "1",
              "rows": [
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/15",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "0",
                  "T_birth_near": "49151/2473901162496",
                  "T_cap": "49151/324259173170675712",
                  "T_deleted": "24575/1236950581248",
                  "T_deleted_after_birth": "0",
                  "T_final_middle": "0",
                  "T_kept_high": "0",
                  "T_kept_low": "1/2473901162496",
                  "T_light": "0",
                  "T_light_after_birth": "0",
                  "T_low_after_birth": "0",
                  "T_middle": "0",
                  "T_new_heavy": "0",
                  "T_nu": "2147456341/108086391056891904",
                  "T_res": "49151/2473901162496",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "12287/12288",
                    "upper": "1"
                  },
                  "kept_capture_bounds": {
                    "lower": "0",
                    "upper": "1/12288"
                  },
                  "kept_packet_H_constant_on_halfopen_row": false,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_low_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "0",
                      "T_birth_near": "24575/1236950581248",
                      "T_cap": "24575/162129586585337856",
                      "T_deleted": "24575/1236950581248",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "1073706325/54043195528445952",
                      "T_res": "24575/1236950581248",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": true,
                      "cap_density": "2",
                      "f_density": "786432",
                      "independent_affine_capture_area": "24575/301989888",
                      "nu_density": "262146",
                      "raw_joint_capture_volume": "24575/324259173170675712",
                      "res_density": "262144",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/262144"
                    },
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "0",
                      "T_birth_near": "1/2473901162496",
                      "T_cap": "1/324259173170675712",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "1/2473901162496",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "43691/108086391056891904",
                      "T_res": "1/2473901162496",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": true,
                      "cap_density": "2",
                      "f_density": "786432",
                      "independent_affine_capture_area": "1/301989888",
                      "nu_density": "262146",
                      "raw_joint_capture_volume": "1/324259173170675712",
                      "res_density": "262144",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/262144"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "5/2",
                      "30721/12288"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "1/50331648",
                  "right_endpoint_excluded_for_low": true
                },
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/15",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "0",
                  "T_birth_near": "452935681/2473901162496",
                  "T_cap": "452935681/324259173170675712",
                  "T_deleted": "150970369/1236950581248",
                  "T_deleted_after_birth": "0",
                  "T_final_middle": "0",
                  "T_kept_high": "150994943/2473901162496",
                  "T_kept_low": "0",
                  "T_light": "0",
                  "T_light_after_birth": "0",
                  "T_low_after_birth": "0",
                  "T_middle": "150994943/2473901162496",
                  "T_new_heavy": "150994943/2473901162496",
                  "T_nu": "19789212838571/108086391056891904",
                  "T_res": "452935681/2473901162496",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "0",
                    "upper": "12287/12288"
                  },
                  "kept_capture_bounds": {
                    "lower": "1/12288",
                    "upper": "1"
                  },
                  "kept_packet_H_constant_on_halfopen_row": true,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_high_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "0",
                      "T_birth_near": "150970369/1236950581248",
                      "T_cap": "150970369/162129586585337856",
                      "T_deleted": "150970369/1236950581248",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "6596046391979/54043195528445952",
                      "T_res": "150970369/1236950581248",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": true,
                      "cap_density": "2",
                      "f_density": "786432",
                      "independent_affine_capture_area": "150970369/301989888",
                      "nu_density": "262146",
                      "raw_joint_capture_volume": "150970369/324259173170675712",
                      "res_density": "262144",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/262144"
                    },
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "1",
                      "T_birth_deep": "0",
                      "T_birth_near": "150994943/2473901162496",
                      "T_cap": "150994943/324259173170675712",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "150994943/2473901162496",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "150994943/2473901162496",
                      "T_new_heavy": "150994943/2473901162496",
                      "T_nu": "6597120054613/108086391056891904",
                      "T_res": "150994943/2473901162496",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": true,
                      "cap_density": "2",
                      "f_density": "786432",
                      "independent_affine_capture_area": "150994943/301989888",
                      "nu_density": "262146",
                      "raw_joint_capture_volume": "150994943/324259173170675712",
                      "res_density": "262144",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/262144"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "30721/12288",
                      "7/2"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "12287/50331648",
                  "right_endpoint_excluded_for_low": false
                }
              ]
            }
          ],
          "ledger": {
            "T_birth_deep": "0",
            "T_birth_near": "3/16384",
            "T_cap": "3/2147483648",
            "T_deleted": "1/8192",
            "T_deleted_after_birth": "0",
            "T_final_middle": "0",
            "T_kept_high": "150994943/2473901162496",
            "T_kept_low": "1/2473901162496",
            "T_light": "0",
            "T_light_after_birth": "0",
            "T_low_after_birth": "0",
            "T_middle": "150994943/2473901162496",
            "T_new_heavy": "150994943/2473901162496",
            "T_nu": "393219/2147483648",
            "T_res": "3/16384",
            "T_top": "0",
            "T_top_after_birth": "0"
          },
          "light_certified": false,
          "light_source_price_upper": {
            "lower": "0",
            "upper": "0"
          },
          "middle_after_light": true,
          "new_heavy_terminal_over_X": "150994943/603979776",
          "p_universal_exact": "1287345/5764801",
          "pooled_after_light_mass_per_box": "138",
          "pooled_after_top_box_mean": "3/97336",
          "rational_mean_upper_after_top": "663552/279841",
          "raw_box_mean": "3/97336",
          "representative_first_kept_box_bounds": [
            [
              "3",
              "49"
            ],
            [
              "-44",
              "2"
            ],
            [
              "-45",
              "1"
            ],
            [
              "-45",
              "1"
            ]
          ],
          "retained_mass_actual": "690",
          "root_constant_test_2_Hn_actual_fraction_le_K": true,
          "root_constant_test_2_Hn_p_le_K": true,
          "root_exp_one_third_mean_proof": {
            "P_minus_3_ge_6n": true,
            "certified_for_root_only": true,
            "proof": "For root period only: log(1+u)<=u from positive integral; 2n/(P-3)<=1/3 gives (1+2/(P-3))^n<=exp(1/3). Small P has no such certification; no exp(1/3) numerical evaluation.",
            "twon_over_P_minus_3": "4/23"
          },
          "shift_optimal_lex": [
            0,
            2,
            1,
            1
          ],
          "shift_proof": "Full uniform T/P first-coordinate periods force deletion>=3/P for every shift; compact coordinates (0,1), then (0) permit exactly shift(0,2,1,...), lex first among equality choices.",
          "top_after_light": false,
          "top_source_price_upper_K_Wtop": "0",
          "top_threshold_actual": "10616832",
          "u": "1",
          "zero_captured_remainder_certificates": [
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate",
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate",
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate"
          ]
        }
      ],
      "scope": "Real I11-form heavy traffic in the stated dominating class, not a certified original FULL hard instance; root-period positive middle retained.",
      "source_ledger": {
        "W_cap": "245/65536",
        "W_f": "160563445/131072",
        "W_nu": "48169205/65536",
        "W_res": "735",
        "Wcap_plus_Wres_equals_Wnu": true,
        "nu_le_f": true
      },
      "sources": [
        {
          "bounds": [
            [
              "0",
              "245"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ]
          ],
          "cap_density": "2",
          "cap_mass": "245/131072",
          "f_density": "786432",
          "f_mass": "735",
          "name": "visible",
          "nu_density": "262146",
          "nu_mass": "32112885/131072",
          "res_density": "262144",
          "res_mass": "245",
          "volume": "245/262144"
        },
        {
          "bounds": [
            [
              "0",
              "245"
            ],
            [
              "191/128",
              "193/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ]
          ],
          "cap_density": "2",
          "cap_mass": "245/131072",
          "f_density": "524290",
          "f_mass": "64225525/131072",
          "name": "hidden",
          "nu_density": "524290",
          "nu_mass": "64225525/131072",
          "res_density": "524288",
          "res_mass": "490",
          "volume": "245/262144"
        }
      ],
      "stage": "pilot_positive_cross_boundary"
    },
    {
      "Af_whole_receiver_bounds": {
        "lower": "3",
        "upper": "3"
      },
      "D": "8",
      "E_bounds": [
        [
          "5/2",
          "7/2"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ]
      ],
      "F_D_exact": "0",
      "F_captured_exact": "1/60",
      "Gamma_dense_all_actual_pairs": "0",
      "Hn": {
        "lower": "61199355604392737608112649297458817744066048536789868119067532342485229074528974642909799871634719391831453265461/5061832854904846645955900741673035877578026003792249877488563088418276175757042525151232593509677298791370051125",
        "upper": "183598066813178212824337947892376453232198145610369604357202597147267595878100019494726288112968295974615741220883/15185498564714539937867702225019107632734078011376749632465689265254828527271127575453697780529031896374110153375"
      },
      "K": "4",
      "Lroot": 294,
      "T_source_length": 1470,
      "X": "1/1152921504606846976",
      "a": "1",
      "beta": "1/6144",
      "birth_observations": {
        "d0": "1/16",
        "mu_hi_equals_f_by_actual_density": true,
        "near_source_mass": "0",
        "near_source_price_upper_1_plus_K": "0",
        "near_visible": false,
        "original_FULL_certified": false,
        "original_FULL_large_dimension_threshold": 512,
        "q": "1",
        "scope": "Actual HC and birth/window necessary-condition observations on this dominating-class input; not inherited original FULL/birth forest.",
        "types": [
          {
            "HC_mu_hi_full_f": "3/524288",
            "HC_times_multiplicity_f_mass": "4410",
            "J_C_power_n_empty": true,
            "J_C_power_n_lower_if_nonempty": null,
            "J_C_power_n_upper_if_nonempty": null,
            "birth_L": "4",
            "birth_d0": "1/16",
            "deep_at_R1": true,
            "multiplicity_analytic_not_enumerated": "770703360",
            "near_at_R1": false,
            "res_mass_source_once": "1470",
            "slab": "visible",
            "t_C_le_R1": true,
            "t_C_power_n": {
              "lower": "2600093554429577597783216690588417224744026603012693262762569964599609375/839395448636403129503559396951914020255662473052425230451872329512621987201024",
              "upper": "41271326260786945996558995088705035313397247666868147027977301025390625/13323737279942906817516815824633555877074007508768654451617021103374951907328"
            },
            "t_C_power_n_times_exp_L": {
              "lower": "141960297984957364513875147613592070744428204138801273720072652439044345939/839395448636403129503559396951914020255662473052425230451872329512621987201024",
              "upper": "137453621858450781513434666736970100244605086547093303970808471267069655673/812747974076517315868525765302646908501514458034887921548638287305872066347008"
            }
          },
          {
            "HC_mu_hi_full_f": "3404335108034795755972591617/162259276829213363391578010288128",
            "HC_times_multiplicity_f_mass": "2502186304405574880639854838495/154742504910672534362390528",
            "J_C_power_n_empty": true,
            "J_C_power_n_lower_if_nonempty": null,
            "J_C_power_n_upper_if_nonempty": null,
            "birth_L": "4",
            "birth_d0": "1/16",
            "deep_at_R1": true,
            "multiplicity_analytic_not_enumerated": "770703360",
            "near_at_R1": false,
            "res_mass_source_once": "16170",
            "slab": "hidden",
            "t_C_le_R1": true,
            "t_C_power_n": {
              "lower": "2950529923839864050189849164747205225293531928690946907178014393456378926004085996617923321533203125/259780308665229572709572200839497502500853231952163976054621587634981832421321094546474316162008659001344",
              "upper": "46833808314918476987140462932495321036405268709380109637746260213593316285779142803459100341796875/4123496962940151947770987314912658769854813205589904381819390279920346462664993612651428665646401978368"
            },
            "t_C_power_n_times_exp_L": {
              "lower": "161093475459090542594739828019231974330412087950765025276788876975578302231523044100199274432173131121/259780308665229572709572200839497502500853231952163976054621587634981832421321094546474316162008659001344",
              "upper": "155979396873087668226652849351954768796113291507883604066779365698888558322013298285889794459212097747/251533314739349268814030226209672184961143605540984167290982807075141134222564610371737148604430520680448"
            }
          }
        ]
      },
      "ceil_6K_Hn": {
        "ceil_lower": 291,
        "ceil_upper": 291,
        "input_interval": {
          "lower": "489594844835141900864901194379670541952528388294318944952540258739881832596231797143278398973077755134651626123688/1687277618301615548651966913891011959192675334597416625829521029472758725252347508383744197836559099597123350375",
          "upper": "1468784534505425702594703583139011625857585164882956834857620777178140767024800155957810304903746367796925929767064/5061832854904846645955900741673035877578026003792249877488563088418276175757042525151232593509677298791370051125"
        },
        "unique_certified": true
      },
      "counts": {
        "physical_f_instances": 1,
        "physical_source_slab_boxes": 2,
        "positive_joint_pair_cells": 8,
        "pre_frozen_nu_labels": 1,
        "scheme_label_rows": 4,
        "scheme_states": 2
      },
      "crosssection_volume_alpha": "1/1237940039285380274899124224",
      "delta": "1/3072",
      "dense_packets_global_closed_certificate": {
        "all_packet_H_false_strict_residual": "28",
        "all_packet_aBi_upper": "1",
        "cell_v_hidden": "11",
        "cell_v_visible": "1",
        "first_i_range": [
          0,
          1469
        ],
        "macro_m_formula": "ell_i(1+h), ell_i=min(T,i+3)-max(0,i-2)>=3",
        "minimum_macro_mass": "36",
        "relevant_direct_integral_packets": [
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 0,
            "m_direct_integral": "36",
            "m_over_D": "9/2",
            "second_owner": 0,
            "u": "2/9",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 0,
            "m_direct_integral": "36",
            "m_over_D": "9/2",
            "second_owner": 1,
            "u": "22/9",
            "v": "11"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 1,
            "m_direct_integral": "48",
            "m_over_D": "6",
            "second_owner": 0,
            "u": "1/6",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 1,
            "m_direct_integral": "48",
            "m_over_D": "6",
            "second_owner": 1,
            "u": "11/6",
            "v": "11"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 2,
            "m_direct_integral": "60",
            "m_over_D": "15/2",
            "second_owner": 0,
            "u": "2/15",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 2,
            "m_direct_integral": "60",
            "m_over_D": "15/2",
            "second_owner": 1,
            "u": "22/15",
            "v": "11"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 3,
            "m_direct_integral": "60",
            "m_over_D": "15/2",
            "second_owner": 0,
            "u": "2/15",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 3,
            "m_direct_integral": "60",
            "m_over_D": "15/2",
            "second_owner": 1,
            "u": "22/15",
            "v": "11"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 4,
            "m_direct_integral": "60",
            "m_over_D": "15/2",
            "second_owner": 0,
            "u": "2/15",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 4,
            "m_direct_integral": "60",
            "m_over_D": "15/2",
            "second_owner": 1,
            "u": "22/15",
            "v": "11"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 5,
            "m_direct_integral": "60",
            "m_over_D": "15/2",
            "second_owner": 0,
            "u": "2/15",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 5,
            "m_direct_integral": "60",
            "m_over_D": "15/2",
            "second_owner": 1,
            "u": "22/15",
            "v": "11"
          }
        ],
        "source_once_coupon": "141120",
        "total_nonzero_packets_not_enumerated": 2940
      },
      "gamma_new": "1/12288",
      "hidden_per_length_res_mass": "11",
      "lambda": "1",
      "n": 16,
      "nu_label_probabilities": [
        "1"
      ],
      "old_f_positive_graph": {
        "Kcover_bounds": [
          [
            "0",
            "1470"
          ],
          [
            "0",
            "2"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ]
        ],
        "actual_res_component_mass": "17640",
        "components": 1,
        "edges_analytic_count": 19086,
        "exp_K": {
          "lower": "39532246723741956144214744531771671051079978874631376697319034374559829/724058355452402561343140264714123426550828906436283281192584228515625",
          "upper": "15272624650938975723714962970774455582733898505232589330089830140785517297/279727877989778189532233188934556350457470234186550774300735040283203125"
        },
        "f_tail_outside_K_exact": "0",
        "old_heavy_certified": true,
        "positive_cells_analytic_count": 2940,
        "proof": "Two adjacent positive rows along first indices 0..T-1; adjacent index cells connect; fixed index l_infinity distance<=3. Other cells source0 analytically; no full grid enumeration."
      },
      "original_delta_low_traffic": "0",
      "res_capture_b_whole_receiver": "1",
      "schemes": [
        {
          "P": 5,
          "W_light": "7056",
          "W_middle": "0",
          "W_top_after_light": "0",
          "actual_delete_fraction": "3/5",
          "beta_new": "1/12288",
          "birth_first_final_middle_over_X": "0",
          "birth_near_source_price_upper": "0",
          "boundary_fee_using_actual_delete_mass": {
            "lower": "979189689670283801729802388759341083905056776588637889905080517479763665192463594286556797946155510269303252247376/3826026345355137298530537219707510111548016631740173754715467187013058333905549905632073010967254194097785375",
            "upper": "2937569069010851405189407166278023251715170329765913669715241554356281534049600311915620609807492735593851859534128/11478079036065411895591611659122530334644049895220521264146401561039175001716649716896219032901762582293356125"
          },
          "boundary_fee_using_universal_p": {
            "lower": "101022599794700104678388804959124217055981390472428146348610185810455568114567405304934001642374504016880316389331612743216/236837845644388708677499223733558274804044751010000217567147783013275848073316339992318794356789374614833831787109375",
            "upper": "303067799384100314035166414877372651167944171417284439045830557629141834148749837893807004825009614266688838462725436301648/710513536933166126032497671200674824412134253030000652701443349039827544219949019976956383070368123844501495361328125"
          },
          "box_mass_times_analytic_count": "7056",
          "c": "1/294912",
          "counts": {
            "physical_f_inputs_added": 0,
            "positive_joint_pair_cells": 4,
            "scheme_label_rows": 2,
            "source_shift_enumerations": 0
          },
          "delete_mass_actual": "10584",
          "each_kept_box_mass_actual": "24",
          "heavy_certified": false,
          "heavy_finite_alternative_Hn_Wkeep": {
            "lower": "0",
            "upper": "0"
          },
          "is_root_period": false,
          "kept_box_volume": "65536",
          "kept_boxes_analytic_count": 294,
          "labels": [
            {
              "label": 0,
              "ledger": {
                "T_birth_deep": "3/4611686018427387904",
                "T_birth_near": "0",
                "T_cap": "3/1427247692705959881058285969449495136382746624",
                "T_deleted": "1/2305843009213693952",
                "T_deleted_after_birth": "1/2305843009213693952",
                "T_final_middle": "0",
                "T_kept_high": "150994943/696341272098026404630757376",
                "T_kept_low": "1/696341272098026404630757376",
                "T_light": "150994943/696341272098026404630757376",
                "T_light_after_birth": "150994943/696341272098026404630757376",
                "T_low_after_birth": "1/696341272098026404630757376",
                "T_middle": "0",
                "T_new_heavy": "0",
                "T_nu": "928455029464035206174343171/1427247692705959881058285969449495136382746624",
                "T_res": "3/4611686018427387904",
                "T_top": "0",
                "T_top_after_birth": "0"
              },
              "probability": "1",
              "rows": [
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/60",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "49151/696341272098026404630757376",
                  "T_birth_near": "0",
                  "T_cap": "49151/215507185434265620706642550693012228946385189057069056",
                  "T_deleted": "24575/348170636049013202315378688",
                  "T_deleted_after_birth": "24575/348170636049013202315378688",
                  "T_final_middle": "0",
                  "T_kept_high": "0",
                  "T_kept_low": "1/696341272098026404630757376",
                  "T_light": "0",
                  "T_light_after_birth": "0",
                  "T_low_after_birth": "1/696341272098026404630757376",
                  "T_middle": "0",
                  "T_new_heavy": "0",
                  "T_nu": "15211497717728931472891713732607/215507185434265620706642550693012228946385189057069056",
                  "T_res": "49151/696341272098026404630757376",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "12287/12288",
                    "upper": "1"
                  },
                  "kept_capture_bounds": {
                    "lower": "0",
                    "upper": "1/12288"
                  },
                  "kept_packet_H_constant_on_halfopen_row": false,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_low_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "24575/348170636049013202315378688",
                      "T_birth_near": "0",
                      "T_cap": "24575/107753592717132810353321275346506114473192594528534528",
                      "T_deleted": "24575/348170636049013202315378688",
                      "T_deleted_after_birth": "24575/348170636049013202315378688",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "7605594116359555063911494475775/107753592717132810353321275346506114473192594528534528",
                      "T_res": "24575/348170636049013202315378688",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "4",
                      "f_density": "3713820117856140824697372672",
                      "independent_affine_capture_area": "24575/301989888",
                      "nu_density": "1237940039285380274899124228",
                      "raw_joint_capture_volume": "24575/431014370868531241413285101386024457892770378114138112",
                      "res_density": "1237940039285380274899124224",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/1237940039285380274899124224"
                    },
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "1/696341272098026404630757376",
                      "T_birth_near": "0",
                      "T_cap": "1/215507185434265620706642550693012228946385189057069056",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "1/696341272098026404630757376",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "1/696341272098026404630757376",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "309485009821345068724781057/215507185434265620706642550693012228946385189057069056",
                      "T_res": "1/696341272098026404630757376",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "4",
                      "f_density": "3713820117856140824697372672",
                      "independent_affine_capture_area": "1/301989888",
                      "nu_density": "1237940039285380274899124228",
                      "raw_joint_capture_volume": "1/431014370868531241413285101386024457892770378114138112",
                      "res_density": "1237940039285380274899124224",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/1237940039285380274899124224"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "5/2",
                      "30721/12288"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "1/14167099448608935641088",
                  "right_endpoint_excluded_for_low": true
                },
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/60",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "452935681/696341272098026404630757376",
                  "T_birth_near": "0",
                  "T_cap": "452935681/215507185434265620706642550693012228946385189057069056",
                  "T_deleted": "150970369/348170636049013202315378688",
                  "T_deleted_after_birth": "150970369/348170636049013202315378688",
                  "T_final_middle": "0",
                  "T_kept_high": "150994943/696341272098026404630757376",
                  "T_kept_low": "0",
                  "T_light": "150994943/696341272098026404630757376",
                  "T_light_after_birth": "150994943/696341272098026404630757376",
                  "T_low_after_birth": "0",
                  "T_middle": "0",
                  "T_new_heavy": "0",
                  "T_nu": "140176803682722617038850509628194817/215507185434265620706642550693012228946385189057069056",
                  "T_res": "452935681/696341272098026404630757376",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "0",
                    "upper": "12287/12288"
                  },
                  "kept_capture_bounds": {
                    "lower": "1/12288",
                    "upper": "1"
                  },
                  "kept_packet_H_constant_on_halfopen_row": true,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_high_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "150970369/348170636049013202315378688",
                      "T_birth_near": "0",
                      "T_cap": "150970369/107753592717132810353321275346506114473192594528534528",
                      "T_deleted": "150970369/348170636049013202315378688",
                      "T_deleted_after_birth": "150970369/348170636049013202315378688",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "46723066132697089101710555619500033/107753592717132810353321275346506114473192594528534528",
                      "T_res": "150970369/348170636049013202315378688",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "4",
                      "f_density": "3713820117856140824697372672",
                      "independent_affine_capture_area": "150970369/301989888",
                      "nu_density": "1237940039285380274899124228",
                      "raw_joint_capture_volume": "150970369/431014370868531241413285101386024457892770378114138112",
                      "res_density": "1237940039285380274899124224",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/1237940039285380274899124224"
                    },
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "1",
                      "T_birth_deep": "150994943/696341272098026404630757376",
                      "T_birth_near": "0",
                      "T_cap": "150994943/215507185434265620706642550693012228946385189057069056",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "150994943/696341272098026404630757376",
                      "T_kept_low": "0",
                      "T_light": "150994943/696341272098026404630757376",
                      "T_light_after_birth": "150994943/696341272098026404630757376",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "46730671417328438835429398389194751/215507185434265620706642550693012228946385189057069056",
                      "T_res": "150994943/696341272098026404630757376",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "4",
                      "f_density": "3713820117856140824697372672",
                      "independent_affine_capture_area": "150994943/301989888",
                      "nu_density": "1237940039285380274899124228",
                      "raw_joint_capture_volume": "150994943/431014370868531241413285101386024457892770378114138112",
                      "res_density": "1237940039285380274899124224",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/1237940039285380274899124224"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "30721/12288",
                      "7/2"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "12287/14167099448608935641088",
                  "right_endpoint_excluded_for_low": false
                }
              ]
            }
          ],
          "ledger": {
            "T_birth_deep": "3/4611686018427387904",
            "T_birth_near": "0",
            "T_cap": "3/1427247692705959881058285969449495136382746624",
            "T_deleted": "1/2305843009213693952",
            "T_deleted_after_birth": "1/2305843009213693952",
            "T_final_middle": "0",
            "T_kept_high": "150994943/696341272098026404630757376",
            "T_kept_low": "1/696341272098026404630757376",
            "T_light": "150994943/696341272098026404630757376",
            "T_light_after_birth": "150994943/696341272098026404630757376",
            "T_low_after_birth": "1/696341272098026404630757376",
            "T_middle": "0",
            "T_new_heavy": "0",
            "T_nu": "928455029464035206174343171/1427247692705959881058285969449495136382746624",
            "T_res": "3/4611686018427387904",
            "T_top": "0",
            "T_top_after_birth": "0"
          },
          "light_certified": true,
          "light_source_price_upper": {
            "lower": "65778536928083193544629565722890058967445637588294103382365990257039206960623540745216451399676297270694625104366150171364772602433046654721725128475283769095080588520612182659216807981377112967981392/369655262059907367685620673660495607890692752931985147700207691048081742216491732131536508884024403095542525171483154024523917272629634994632464567630388864449830776948147104121744632720947265625",
            "upper": "197335610784249580633888697168670176902336912764882310147097970879157900607055561569277634741427986518315641261576036225592597714048297373084355822768063138587285768434754606261163340290937957208933256/1108965786179722103056862020981486823672078258795955443100623073144245226649475196394609526652073209286627575514449462073571751817888904983897393702891166593349492330844441312365233898162841796875"
          },
          "middle_after_light": false,
          "new_heavy_terminal_over_X": "0",
          "p_universal_exact": "152587825089/152587890625",
          "pooled_after_light_mass_per_box": "0",
          "pooled_after_top_box_mean": "0",
          "rational_mean_upper_after_top": "65536",
          "raw_box_mean": "3/8192",
          "representative_first_kept_box_bounds": [
            [
              "3",
              "5"
            ],
            [
              "0",
              "2"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ]
          ],
          "retained_mass_actual": "7056",
          "root_constant_test_2_Hn_actual_fraction_le_K": false,
          "root_constant_test_2_Hn_p_le_K": false,
          "root_exp_one_third_mean_proof": {
            "P_minus_3_ge_6n": false,
            "certified_for_root_only": false,
            "proof": "For root period only: log(1+u)<=u from positive integral; 2n/(P-3)<=1/3 gives (1+2/(P-3))^n<=exp(1/3). Small P has no such certification; no exp(1/3) numerical evaluation.",
            "twon_over_P_minus_3": "16"
          },
          "shift_optimal_lex": [
            0,
            2,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1
          ],
          "shift_proof": "Full uniform T/P first-coordinate periods force deletion>=3/P for every shift; compact coordinates (0,1), then (0) permit exactly shift(0,2,1,...), lex first among equality choices.",
          "top_after_light": false,
          "top_source_price_upper_K_Wtop": "0",
          "top_threshold_actual": "4294967296",
          "u": "1",
          "zero_captured_remainder_certificates": [
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate",
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate",
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate"
          ]
        },
        {
          "P": 294,
          "W_light": "0",
          "W_middle": "17460",
          "W_top_after_light": "0",
          "actual_delete_fraction": "1/98",
          "beta_new": "1/12288",
          "birth_first_final_middle_over_X": "150994943/603979776",
          "birth_near_source_price_upper": "0",
          "boundary_fee_using_actual_delete_mass": {
            "lower": "489594844835141900864901194379670541952528388294318944952540258739881832596231797143278398973077755134651626123688/112485174553441036576797794259400797279511688973161108388634735298183915016823167225582946522437273306474890025",
            "upper": "1468784534505425702594703583139011625857585164882956834857620777178140767024800155957810304903746367796925929767064/337455523660323109730393382778202391838535066919483325165904205894551745050469501676748839567311819919424670075"
          },
          "boundary_fee_using_universal_p": {
            "lower": "202233071451846753187914215593548642960849491483542219187607033298360494944840919727832434400476910055834147484318172246984019649137656779721/3132657406894667013889604531121326642077383023078629442621412269066997009527878934377415187683419500238973399395833708441177456533975040",
            "upper": "606699214355540259563742646780645928882548474450626657562821100290999547115085711433043878151575408892515057092825614928250963906376986933663/9397972220684001041668813593363979926232149069235888327864236807200991028583636803132245563050258500716920198187501125323532369601925120"
          },
          "box_mass_times_analytic_count": "17460",
          "c": "1/42909696",
          "counts": {
            "physical_f_inputs_added": 0,
            "positive_joint_pair_cells": 4,
            "scheme_label_rows": 2,
            "source_shift_enumerations": 0
          },
          "delete_mass_actual": "180",
          "each_kept_box_mass_actual": "3492",
          "heavy_certified": true,
          "heavy_finite_alternative_Hn_Wkeep": {
            "lower": "244797422417570950432450597189835270976264194147159472476270129369940916298115898571639199486538877567325813061844/1159640974777742645121626744942276260613522566733619674109636446373030051719826466243123160025126528932730825",
            "upper": "734392267252712851297351791569505812928792582441478417428810388589070383512400077978905152451873183898462964883532/3478922924333227935364880234826828781840567700200859022328909339119090155159479398729369480075379586798192475"
          },
          "is_root_period": true,
          "kept_box_volume": "2644160564383891543066320812507233336641",
          "kept_boxes_analytic_count": 5,
          "labels": [
            {
              "label": 0,
              "ledger": {
                "T_birth_deep": "3/4611686018427387904",
                "T_birth_near": "0",
                "T_cap": "3/1427247692705959881058285969449495136382746624",
                "T_deleted": "1/2305843009213693952",
                "T_deleted_after_birth": "1/2305843009213693952",
                "T_final_middle": "150994943/696341272098026404630757376",
                "T_kept_high": "150994943/696341272098026404630757376",
                "T_kept_low": "1/696341272098026404630757376",
                "T_light": "0",
                "T_light_after_birth": "0",
                "T_low_after_birth": "1/696341272098026404630757376",
                "T_middle": "150994943/696341272098026404630757376",
                "T_new_heavy": "150994943/696341272098026404630757376",
                "T_nu": "928455029464035206174343171/1427247692705959881058285969449495136382746624",
                "T_res": "3/4611686018427387904",
                "T_top": "0",
                "T_top_after_birth": "0"
              },
              "probability": "1",
              "rows": [
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/60",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "49151/696341272098026404630757376",
                  "T_birth_near": "0",
                  "T_cap": "49151/215507185434265620706642550693012228946385189057069056",
                  "T_deleted": "24575/348170636049013202315378688",
                  "T_deleted_after_birth": "24575/348170636049013202315378688",
                  "T_final_middle": "0",
                  "T_kept_high": "0",
                  "T_kept_low": "1/696341272098026404630757376",
                  "T_light": "0",
                  "T_light_after_birth": "0",
                  "T_low_after_birth": "1/696341272098026404630757376",
                  "T_middle": "0",
                  "T_new_heavy": "0",
                  "T_nu": "15211497717728931472891713732607/215507185434265620706642550693012228946385189057069056",
                  "T_res": "49151/696341272098026404630757376",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "12287/12288",
                    "upper": "1"
                  },
                  "kept_capture_bounds": {
                    "lower": "0",
                    "upper": "1/12288"
                  },
                  "kept_packet_H_constant_on_halfopen_row": false,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_low_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "24575/348170636049013202315378688",
                      "T_birth_near": "0",
                      "T_cap": "24575/107753592717132810353321275346506114473192594528534528",
                      "T_deleted": "24575/348170636049013202315378688",
                      "T_deleted_after_birth": "24575/348170636049013202315378688",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "7605594116359555063911494475775/107753592717132810353321275346506114473192594528534528",
                      "T_res": "24575/348170636049013202315378688",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "4",
                      "f_density": "3713820117856140824697372672",
                      "independent_affine_capture_area": "24575/301989888",
                      "nu_density": "1237940039285380274899124228",
                      "raw_joint_capture_volume": "24575/431014370868531241413285101386024457892770378114138112",
                      "res_density": "1237940039285380274899124224",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/1237940039285380274899124224"
                    },
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "1/696341272098026404630757376",
                      "T_birth_near": "0",
                      "T_cap": "1/215507185434265620706642550693012228946385189057069056",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "1/696341272098026404630757376",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "1/696341272098026404630757376",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "309485009821345068724781057/215507185434265620706642550693012228946385189057069056",
                      "T_res": "1/696341272098026404630757376",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "4",
                      "f_density": "3713820117856140824697372672",
                      "independent_affine_capture_area": "1/301989888",
                      "nu_density": "1237940039285380274899124228",
                      "raw_joint_capture_volume": "1/431014370868531241413285101386024457892770378114138112",
                      "res_density": "1237940039285380274899124224",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/1237940039285380274899124224"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "5/2",
                      "30721/12288"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "1/14167099448608935641088",
                  "right_endpoint_excluded_for_low": true
                },
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/60",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "452935681/696341272098026404630757376",
                  "T_birth_near": "0",
                  "T_cap": "452935681/215507185434265620706642550693012228946385189057069056",
                  "T_deleted": "150970369/348170636049013202315378688",
                  "T_deleted_after_birth": "150970369/348170636049013202315378688",
                  "T_final_middle": "150994943/696341272098026404630757376",
                  "T_kept_high": "150994943/696341272098026404630757376",
                  "T_kept_low": "0",
                  "T_light": "0",
                  "T_light_after_birth": "0",
                  "T_low_after_birth": "0",
                  "T_middle": "150994943/696341272098026404630757376",
                  "T_new_heavy": "150994943/696341272098026404630757376",
                  "T_nu": "140176803682722617038850509628194817/215507185434265620706642550693012228946385189057069056",
                  "T_res": "452935681/696341272098026404630757376",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "0",
                    "upper": "12287/12288"
                  },
                  "kept_capture_bounds": {
                    "lower": "1/12288",
                    "upper": "1"
                  },
                  "kept_packet_H_constant_on_halfopen_row": true,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_high_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "150970369/348170636049013202315378688",
                      "T_birth_near": "0",
                      "T_cap": "150970369/107753592717132810353321275346506114473192594528534528",
                      "T_deleted": "150970369/348170636049013202315378688",
                      "T_deleted_after_birth": "150970369/348170636049013202315378688",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "46723066132697089101710555619500033/107753592717132810353321275346506114473192594528534528",
                      "T_res": "150970369/348170636049013202315378688",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "4",
                      "f_density": "3713820117856140824697372672",
                      "independent_affine_capture_area": "150970369/301989888",
                      "nu_density": "1237940039285380274899124228",
                      "raw_joint_capture_volume": "150970369/431014370868531241413285101386024457892770378114138112",
                      "res_density": "1237940039285380274899124224",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/1237940039285380274899124224"
                    },
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "1",
                      "T_birth_deep": "150994943/696341272098026404630757376",
                      "T_birth_near": "0",
                      "T_cap": "150994943/215507185434265620706642550693012228946385189057069056",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "150994943/696341272098026404630757376",
                      "T_kept_high": "150994943/696341272098026404630757376",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "150994943/696341272098026404630757376",
                      "T_new_heavy": "150994943/696341272098026404630757376",
                      "T_nu": "46730671417328438835429398389194751/215507185434265620706642550693012228946385189057069056",
                      "T_res": "150994943/696341272098026404630757376",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "4",
                      "f_density": "3713820117856140824697372672",
                      "independent_affine_capture_area": "150994943/301989888",
                      "nu_density": "1237940039285380274899124228",
                      "raw_joint_capture_volume": "150994943/431014370868531241413285101386024457892770378114138112",
                      "res_density": "1237940039285380274899124224",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/1237940039285380274899124224"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "30721/12288",
                      "7/2"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "12287/14167099448608935641088",
                  "right_endpoint_excluded_for_low": false
                }
              ]
            }
          ],
          "ledger": {
            "T_birth_deep": "3/4611686018427387904",
            "T_birth_near": "0",
            "T_cap": "3/1427247692705959881058285969449495136382746624",
            "T_deleted": "1/2305843009213693952",
            "T_deleted_after_birth": "1/2305843009213693952",
            "T_final_middle": "150994943/696341272098026404630757376",
            "T_kept_high": "150994943/696341272098026404630757376",
            "T_kept_low": "1/696341272098026404630757376",
            "T_light": "0",
            "T_light_after_birth": "0",
            "T_low_after_birth": "1/696341272098026404630757376",
            "T_middle": "150994943/696341272098026404630757376",
            "T_new_heavy": "150994943/696341272098026404630757376",
            "T_nu": "928455029464035206174343171/1427247692705959881058285969449495136382746624",
            "T_res": "3/4611686018427387904",
            "T_top": "0",
            "T_top_after_birth": "0"
          },
          "light_certified": false,
          "light_source_price_upper": {
            "lower": "0",
            "upper": "0"
          },
          "middle_after_light": true,
          "new_heavy_terminal_over_X": "150994943/603979776",
          "p_universal_exact": "10954406712981013030066320841215/72379772059249583476264088436736",
          "pooled_after_light_mass_per_box": "3492",
          "pooled_after_top_box_mean": "4/3028820806854400392974021549263726617",
          "rational_mean_upper_after_top": "2950406972172702977764211681592612043201/2644160564383891543066320812507233336641",
          "raw_box_mean": "4/3028820806854400392974021549263726617",
          "representative_first_kept_box_bounds": [
            [
              "3",
              "294"
            ],
            [
              "-289",
              "2"
            ],
            [
              "-290",
              "1"
            ],
            [
              "-290",
              "1"
            ],
            [
              "-290",
              "1"
            ],
            [
              "-290",
              "1"
            ],
            [
              "-290",
              "1"
            ],
            [
              "-290",
              "1"
            ],
            [
              "-290",
              "1"
            ],
            [
              "-290",
              "1"
            ],
            [
              "-290",
              "1"
            ],
            [
              "-290",
              "1"
            ],
            [
              "-290",
              "1"
            ],
            [
              "-290",
              "1"
            ],
            [
              "-290",
              "1"
            ],
            [
              "-290",
              "1"
            ]
          ],
          "retained_mass_actual": "17460",
          "root_constant_test_2_Hn_actual_fraction_le_K": true,
          "root_constant_test_2_Hn_p_le_K": true,
          "root_exp_one_third_mean_proof": {
            "P_minus_3_ge_6n": true,
            "certified_for_root_only": true,
            "proof": "For root period only: log(1+u)<=u from positive integral; 2n/(P-3)<=1/3 gives (1+2/(P-3))^n<=exp(1/3). Small P has no such certification; no exp(1/3) numerical evaluation.",
            "twon_over_P_minus_3": "32/291"
          },
          "shift_optimal_lex": [
            0,
            2,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1
          ],
          "shift_proof": "Full uniform T/P first-coordinate periods force deletion>=3/P for every shift; compact coordinates (0,1), then (0) permit exactly shift(0,2,1,...), lex first among equality choices.",
          "top_after_light": false,
          "top_source_price_upper_K_Wtop": "0",
          "top_threshold_actual": "2950406972172702977764211681592612043201",
          "u": "1",
          "zero_captured_remainder_certificates": [
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate",
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate",
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate"
          ]
        }
      ],
      "scope": "Real I11-form heavy traffic in the stated dominating class, not a certified original FULL hard instance; root-period positive middle retained.",
      "source_ledger": {
        "W_cap": "735/77371252455336267181195264",
        "W_f": "3184600751061640757177997066975/154742504910672534362390528",
        "W_nu": "1364828893312131753076284457695/77371252455336267181195264",
        "W_res": "17640",
        "Wcap_plus_Wres_equals_Wnu": true,
        "nu_le_f": true
      },
      "sources": [
        {
          "bounds": [
            [
              "0",
              "1470"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ]
          ],
          "cap_density": "4",
          "cap_mass": "735/154742504910672534362390528",
          "f_density": "3713820117856140824697372672",
          "f_mass": "4410",
          "name": "visible",
          "nu_density": "1237940039285380274899124228",
          "nu_mass": "227471482218688625512714076895/154742504910672534362390528",
          "res_density": "1237940039285380274899124224",
          "res_mass": "1470",
          "volume": "735/618970019642690137449562112"
        },
        {
          "bounds": [
            [
              "0",
              "1470"
            ],
            [
              "191/128",
              "193/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ]
          ],
          "cap_density": "4",
          "cap_mass": "735/154742504910672534362390528",
          "f_density": "13617340432139183023890366468",
          "f_mass": "2502186304405574880639854838495/154742504910672534362390528",
          "name": "hidden",
          "nu_density": "13617340432139183023890366468",
          "nu_mass": "2502186304405574880639854838495/154742504910672534362390528",
          "res_density": "13617340432139183023890366464",
          "res_mass": "16170",
          "volume": "735/618970019642690137449562112"
        }
      ],
      "stage": "known_heavy_structure_pressure"
    },
    {
      "Af_whole_receiver_bounds": {
        "lower": "3",
        "upper": "3"
      },
      "D": "16",
      "E_bounds": [
        [
          "5/2",
          "7/2"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ],
        [
          "3/32",
          "5/32"
        ]
      ],
      "F_D_exact": "0",
      "F_captured_exact": "1/5005",
      "Gamma_dense_all_actual_pairs": "0",
      "Hn": {
        "lower": "229611923852856410494582894964816163343530116135782722843804440104686087770844770996185501706009845670951702908469/5061832854904846645955900741673035877578026003792249877488563088418276175757042525151232593509677298791370051125",
        "upper": "688835771558569231483748684894448490030590348407348168531413320793305897930586695252544059110286088209340634423407/15185498564714539937867702225019107632734078011376749632465689265254828527271127575453697780529031896374110153375"
      },
      "K": "8",
      "Lroot": 2181,
      "T_source_length": 10905,
      "X": "1/7237005577332262213973186563042994240829374041602535252466099000494570602496",
      "a": "1",
      "beta": "1/6144",
      "birth_observations": {
        "d0": "1/64",
        "mu_hi_equals_f_by_actual_density": true,
        "near_source_mass": "0",
        "near_source_price_upper_1_plus_K": "0",
        "near_visible": false,
        "original_FULL_certified": false,
        "original_FULL_large_dimension_threshold": 512,
        "q": "1",
        "scope": "Actual HC and birth/window necessary-condition observations on this dominating-class input; not inherited original FULL/birth forest.",
        "types": [
          {
            "HC_mu_hi_full_f": "3/590295810358705651712",
            "HC_times_multiplicity_f_mass": "32715",
            "J_C_power_n_empty": true,
            "J_C_power_n_lower_if_nonempty": null,
            "J_C_power_n_upper_if_nonempty": null,
            "birth_L": "8",
            "birth_d0": "1/64",
            "deep_at_R1": true,
            "multiplicity_analytic_not_enumerated": "6437175811961685131919360",
            "near_at_R1": false,
            "res_mass_source_once": "10905",
            "slab": "visible",
            "t_C_le_R1": true,
            "t_C_power_n": {
              "lower": "2600093554429577597783216690588417224744026603012693262762569964599609375/472537628711924431098981951144191957611571036890680217865559075353270295493204857023509823488",
              "upper": "41271326260786945996558995088705035313397247666868147027977301025390625/7500597281141657636491777002288761231929698998264765362945382148464607712712665693564174336"
            },
            "t_C_power_n_times_exp_L": {
              "lower": "7750769648132565987346433640978023042945147648900082594064727930658809625591/472537628711924431098981951144191957611571036890680217865559075353270295493204857023509823488",
              "upper": "2337533703405059583485432367914006993696355403358533096067743897598397376363/142511348341691495093343763043486463406664280967030541895962260820827546541540648177719312384"
            }
          },
          {
            "HC_mu_hi_full_f": "76957043352332967211482500195592995713046365762627825523336510555167425334955489475418488779072100860950445293568001/45427420268475430659332737993000283397102585042957378767593137448789955507087370207886940669610222847547657600391636120845912601788416",
            "HC_times_multiplicity_f_mass": "839216557757191007441216664632941618250770618641456437331984647604100773277689612729438620135781259888664605926359050905/76957043352332967211482500195592995713046365762627825523336510555167425334955489475418488779072100860950445293568",
            "J_C_power_n_empty": true,
            "J_C_power_n_lower_if_nonempty": null,
            "J_C_power_n_upper_if_nonempty": null,
            "birth_L": "8",
            "birth_d0": "1/64",
            "deep_at_R1": true,
            "multiplicity_analytic_not_enumerated": "6437175811961685131919360",
            "near_at_R1": false,
            "res_mass_source_once": "10905000",
            "slab": "hidden",
            "t_C_le_R1": true,
            "t_C_power_n": {
              "lower": "66698504129452840241354354917612370277919239413564593556451560348283029235883364808317927201508166973292483237467908135736454294409125554676359410081534977287271367326946787523321533203125/36365098778392187899985053515813470095045027840674009747664977076638660602821385910174800786770187321287347543137426199210347784452062867169874234626681439718740498154629802782463937326806260542784021725184",
              "upper": "1058706414753219686370704046311307464728876816088326881848437465845762368823545473147903606373145507512579099007427113265658004673160723090100943017167221861702720116300742659100341796875/577223790133209331745794500251007461826111553026571583296269477406962854994060421388080199565288808492583211749530464304014965254977449592588845150109770818348485983944579843381395729566972965027051470848"
            },
            "t_C_power_n_times_exp_L": {
              "lower": "198825438608428139562600692292545781314771745071849494386649999548247498323972631878170465378943556434395722405408907650952562057450482856439631896649859259520497165500681545076064273102771197/36365098778392187899985053515813470095045027840674009747664977076638660602821385910174800786770187321287347543137426199210347784452062867169874234626681439718740498154629802782463937326806260542784021725184",
              "upper": "59963227516827534153800208786640792324944667187569505308482745557642348453443528432790061024047794467826679986997801968551071356973110578535209323527939773699301956645320454822516705843520121/10967252012530977303170095504769141774696119507504860082629120070732294244887148006373523791740487361359081023241078821776284339844571542259188057852085645548621233694947017024246518861772486335513977946112"
            }
          }
        ]
      },
      "ceil_6K_Hn": {
        "ceil_lower": 2178,
        "ceil_upper": 2178,
        "input_interval": {
          "lower": "3673790781645702567913326319437058613496481858172523565500871041674977404333516335938968027296157530735227246535504/1687277618301615548651966913891011959192675334597416625829521029472758725252347508383744197836559099597123350375",
          "upper": "11021372344937107703739978958311175840489445574517570696502613132692894366889387124040704945764577411349450150774512/5061832854904846645955900741673035877578026003792249877488563088418276175757042525151232593509677298791370051125"
        },
        "unique_certified": true
      },
      "counts": {
        "physical_f_instances": 1,
        "physical_source_slab_boxes": 2,
        "positive_joint_pair_cells": 16,
        "pre_frozen_nu_labels": 2,
        "scheme_label_rows": 8,
        "scheme_states": 2
      },
      "crosssection_volume_alpha": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
      "delta": "1/3072",
      "dense_packets_global_closed_certificate": {
        "all_packet_H_false_strict_residual": "2987",
        "all_packet_aBi_upper": "1",
        "cell_v_hidden": "1000",
        "cell_v_visible": "1",
        "first_i_range": [
          0,
          10904
        ],
        "macro_m_formula": "ell_i(1+h), ell_i=min(T,i+3)-max(0,i-2)>=3",
        "minimum_macro_mass": "3003",
        "relevant_direct_integral_packets": [
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 0,
            "m_direct_integral": "3003",
            "m_over_D": "3003/16",
            "second_owner": 0,
            "u": "16/3003",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 0,
            "m_direct_integral": "3003",
            "m_over_D": "3003/16",
            "second_owner": 1,
            "u": "16000/3003",
            "v": "1000"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 1,
            "m_direct_integral": "4004",
            "m_over_D": "1001/4",
            "second_owner": 0,
            "u": "4/1001",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 1,
            "m_direct_integral": "4004",
            "m_over_D": "1001/4",
            "second_owner": 1,
            "u": "4000/1001",
            "v": "1000"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 2,
            "m_direct_integral": "5005",
            "m_over_D": "5005/16",
            "second_owner": 0,
            "u": "16/5005",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 2,
            "m_direct_integral": "5005",
            "m_over_D": "5005/16",
            "second_owner": 1,
            "u": "3200/1001",
            "v": "1000"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 3,
            "m_direct_integral": "5005",
            "m_over_D": "5005/16",
            "second_owner": 0,
            "u": "16/5005",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 3,
            "m_direct_integral": "5005",
            "m_over_D": "5005/16",
            "second_owner": 1,
            "u": "3200/1001",
            "v": "1000"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 4,
            "m_direct_integral": "5005",
            "m_over_D": "5005/16",
            "second_owner": 0,
            "u": "16/5005",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 4,
            "m_direct_integral": "5005",
            "m_over_D": "5005/16",
            "second_owner": 1,
            "u": "3200/1001",
            "v": "1000"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 5,
            "m_direct_integral": "5005",
            "m_over_D": "5005/16",
            "second_owner": 0,
            "u": "16/5005",
            "v": "1"
          },
          {
            "H": false,
            "aBi_upper_safe": "1",
            "first_owner": 5,
            "m_direct_integral": "5005",
            "m_over_D": "5005/16",
            "second_owner": 1,
            "u": "3200/1001",
            "v": "1000"
          }
        ],
        "source_once_coupon": "174654480",
        "total_nonzero_packets_not_enumerated": 21810
      },
      "gamma_new": "1/12288",
      "hidden_per_length_res_mass": "1000",
      "lambda": "1",
      "n": 64,
      "nu_label_probabilities": [
        "1/2",
        "1/2"
      ],
      "old_f_positive_graph": {
        "Kcover_bounds": [
          [
            "0",
            "10905"
          ],
          [
            "0",
            "2"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ],
          [
            "0",
            "1"
          ]
        ],
        "actual_res_component_mass": "10915905",
        "components": 1,
        "edges_analytic_count": 141741,
        "exp_K": {
          "lower": "41009363217632624271674252068666788587011363221693558698755174236289998019/13757108753595648665519665029568345104465749222289382342659100341796875",
          "upper": "2337533703405059583485432367914006993696355403358533096067743897598397376363/784155198954951973934620906685395670954547705670494793531568719482421875"
        },
        "f_tail_outside_K_exact": "0",
        "old_heavy_certified": true,
        "positive_cells_analytic_count": 21810,
        "proof": "Two adjacent positive rows along first indices 0..T-1; adjacent index cells connect; fixed index l_infinity distance<=3. Other cells source0 analytically; no full grid enumeration."
      },
      "original_delta_low_traffic": "0",
      "res_capture_b_whole_receiver": "1",
      "schemes": [
        {
          "P": 5,
          "W_light": "4366362",
          "W_middle": "0",
          "W_top_after_light": "0",
          "actual_delete_fraction": "3/5",
          "beta_new": "1/12288",
          "birth_first_final_middle_over_X": "0",
          "birth_near_source_price_upper": "0",
          "boundary_fee_using_actual_delete_mass": {
            "lower": "333855737282053220859123529278842701501492788861428079014891655912213571618808297028453719480538315605563776028913926/561864008758446736147841130166837149248310134731074467475697978512407167916199636491423309302883483049325125",
            "upper": "1001567211846159662577370587836528104504478366584284237044674968433466775591073054897199061946355972256381282451633778/1685592026275340208443523390500511447744930404193223402427093935537221503748598909474269927908650449147975375"
          },
          "boundary_fee_using_universal_p": {
            "lower": "180219247998215527669315200148002643177514578827887353252850747773389322657734210315363201525803888181791083880034021526022434327987013820343893491901505574/181980474488889352926009330139982851828967112721525861610364534742420693964964329018110451880269548874976930086244664153127814643085002899169921875",
            "upper": "540657743994646583007945600444007929532543736483662059758552243696322859524643767625046506066033173262101054382417297446925757913991383900952405333958624722/545941423466668058778027990419948555486901338164577584831093604227262081894892987054331355640808646624930790258733992459383443929255008697509765625"
          },
          "box_mass_times_analytic_count": "4366362",
          "c": "1/24600576",
          "counts": {
            "physical_f_inputs_added": 0,
            "positive_joint_pair_cells": 8,
            "scheme_label_rows": 4,
            "source_shift_enumerations": 0
          },
          "delete_mass_actual": "6549543",
          "each_kept_box_mass_actual": "2002",
          "heavy_certified": false,
          "heavy_finite_alternative_Hn_Wkeep": {
            "lower": "0",
            "upper": "0"
          },
          "is_root_period": false,
          "kept_box_volume": "18446744073709551616",
          "kept_boxes_analytic_count": 2181,
          "labels": [
            {
              "label": 0,
              "ledger": {
                "T_birth_deep": "3/28948022309329048855892746252171976963317496166410141009864396001978282409984",
                "T_birth_near": "0",
                "T_cap": "3/2227754207823337509102134573095845373483021732054960903603121346630505452738612005129840239901060253798165190221481644194672219102234100585084307285020612396607419274589973120157653414182912",
                "T_deleted": "1/14474011154664524427946373126085988481658748083205070504932198000989141204992",
                "T_deleted_after_birth": "1/14474011154664524427946373126085988481658748083205070504932198000989141204992",
                "T_final_middle": "0",
                "T_kept_high": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                "T_kept_low": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                "T_light": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                "T_light_after_birth": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                "T_low_after_birth": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                "T_middle": "0",
                "T_new_heavy": "0",
                "T_nu": "230871130056998901634447500586778987139139097287883476570009531665502276004866468426255466337216302582851335880707/2227754207823337509102134573095845373483021732054960903603121346630505452738612005129840239901060253798165190221481644194672219102234100585084307285020612396607419274589973120157653414182912",
                "T_res": "3/28948022309329048855892746252171976963317496166410141009864396001978282409984",
                "T_top": "0",
                "T_top_after_birth": "0"
              },
              "probability": "1/2",
              "rows": [
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/5005",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "49151/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_birth_near": "0",
                  "T_cap": "49151/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                  "T_deleted": "24575/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_deleted_after_birth": "24575/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_final_middle": "0",
                  "T_kept_high": "0",
                  "T_kept_low": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_light": "0",
                  "T_light_after_birth": "0",
                  "T_low_after_birth": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_middle": "0",
                  "T_new_heavy": "0",
                  "T_nu": "420279515312279741267952929679287925810215769288768916921945870033003791404266362578477126886685869935175037402689991/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                  "T_res": "49151/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "12287/12288",
                    "upper": "1"
                  },
                  "kept_capture_bounds": {
                    "lower": "0",
                    "upper": "1/12288"
                  },
                  "kept_packet_H_constant_on_halfopen_row": false,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_low_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "24575/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_birth_near": "0",
                      "T_cap": "24575/168189810928024604539988150072535539400863975691210913280871352979838879763980683176153969876403579281439870100120984231101228410848784146367586106890239703835721531675616807119855074222978801598464",
                      "T_deleted": "24575/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_deleted_after_birth": "24575/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "210135482264842518802464715811855318849790493179619868026221638543693275289614572650934373527299653184206354787717575/18687756769780511615554238896948393266762663965690101475652372553315431084886742575128218875155953253493318900013442692344580934538753794040842900765582189315080170186179645235539452691442089066496",
                      "T_res": "24575/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "24575/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "24575/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    },
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_birth_near": "0",
                      "T_cap": "1/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "8550782594703663023498055577288110634782929529180869502592945617240825037217276608379832086563566762327827254841/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                      "T_res": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "1/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "1/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "5/2",
                      "30721/12288"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "1/88928324534258838085302516486672313231311348223211953182303424518077283563470848",
                  "right_endpoint_excluded_for_low": true
                },
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/5005",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "452935681/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_birth_near": "0",
                  "T_cap": "452935681/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                  "T_deleted": "150970369/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_deleted_after_birth": "150970369/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_final_middle": "0",
                  "T_kept_high": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_kept_low": "0",
                  "T_light": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_light_after_birth": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_low_after_birth": "0",
                  "T_middle": "0",
                  "T_new_heavy": "0",
                  "T_nu": "3872954537615050604742610805074838523568748473474546500329067088940938429233857525581889552793320061283919582921768881721/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                  "T_res": "452935681/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "0",
                    "upper": "12287/12288"
                  },
                  "kept_capture_bounds": {
                    "lower": "1/12288",
                    "upper": "1"
                  },
                  "kept_packet_H_constant_on_halfopen_row": true,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_high_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "150970369/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_birth_near": "0",
                      "T_cap": "150970369/168189810928024604539988150072535539400863975691210913280871352979838879763980683176153969876403579281439870100120984231101228410848784146367586106890239703835721531675616807119855074222978801598464",
                      "T_deleted": "150970369/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_deleted_after_birth": "150970369/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "1290914803561189452309157121285694081846003105921432136547303456631780117733130982742171742266541616064767379631602806329/18687756769780511615554238896948393266762663965690101475652372553315431084886742575128218875155953253493318900013442692344580934538753794040842900765582189315080170186179645235539452691442089066496",
                      "T_res": "150970369/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "150970369/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "150970369/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    },
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "1",
                      "T_birth_deep": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_birth_near": "0",
                      "T_cap": "150994943/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_kept_low": "0",
                      "T_light": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_light_after_birth": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "1291124930492671700124296562503450359876742261631682227234460175677378193767595560097546068260236829154384823658563269063/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                      "T_res": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "150994943/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "150994943/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "30721/12288",
                      "7/2"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "12287/88928324534258838085302516486672313231311348223211953182303424518077283563470848",
                  "right_endpoint_excluded_for_low": false
                }
              ]
            },
            {
              "label": 1,
              "ledger": {
                "T_birth_deep": "3/28948022309329048855892746252171976963317496166410141009864396001978282409984",
                "T_birth_near": "0",
                "T_cap": "3/2227754207823337509102134573095845373483021732054960903603121346630505452738612005129840239901060253798165190221481644194672219102234100585084307285020612396607419274589973120157653414182912",
                "T_deleted": "1/28948022309329048855892746252171976963317496166410141009864396001978282409984",
                "T_deleted_after_birth": "1/28948022309329048855892746252171976963317496166410141009864396001978282409984",
                "T_final_middle": "0",
                "T_kept_high": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                "T_kept_low": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                "T_light": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                "T_light_after_birth": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                "T_low_after_birth": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                "T_middle": "0",
                "T_new_heavy": "0",
                "T_nu": "230871130056998901634447500586778987139139097287883476570009531665502276004866468426255466337216302582851335880707/2227754207823337509102134573095845373483021732054960903603121346630505452738612005129840239901060253798165190221481644194672219102234100585084307285020612396607419274589973120157653414182912",
                "T_res": "3/28948022309329048855892746252171976963317496166410141009864396001978282409984",
                "T_top": "0",
                "T_top_after_birth": "0"
              },
              "probability": "1/2",
              "rows": [
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/5005",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "24577/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_birth_near": "0",
                  "T_cap": "24577/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                  "T_deleted": "24575/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_deleted_after_birth": "24575/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_final_middle": "0",
                  "T_kept_high": "0",
                  "T_kept_low": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_light": "0",
                  "T_light_after_birth": "0",
                  "T_low_after_birth": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_middle": "0",
                  "T_new_heavy": "0",
                  "T_nu": "210152583830031926128511711923009895071060059038678229765226824434927756939689007204151133191472780317731010442227257/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                  "T_res": "24577/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "12287/12288",
                    "upper": "1"
                  },
                  "kept_capture_bounds": {
                    "lower": "0",
                    "upper": "1/12288"
                  },
                  "kept_packet_H_constant_on_halfopen_row": false,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_low_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "24575/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_birth_near": "0",
                      "T_cap": "24575/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                      "T_deleted": "24575/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_deleted_after_birth": "24575/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "210135482264842518802464715811855318849790493179619868026221638543693275289614572650934373527299653184206354787717575/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                      "T_res": "24575/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "24575/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "24575/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    },
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_birth_near": "0",
                      "T_cap": "1/168189810928024604539988150072535539400863975691210913280871352979838879763980683176153969876403579281439870100120984231101228410848784146367586106890239703835721531675616807119855074222978801598464",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "8550782594703663023498055577288110634782929529180869502592945617240825037217276608379832086563566762327827254841/18687756769780511615554238896948393266762663965690101475652372553315431084886742575128218875155953253493318900013442692344580934538753794040842900765582189315080170186179645235539452691442089066496",
                      "T_res": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "1/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "1/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "5/2",
                      "30721/12288"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "1/88928324534258838085302516486672313231311348223211953182303424518077283563470848",
                  "right_endpoint_excluded_for_low": true
                },
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/5005",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "452960255/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_birth_near": "0",
                  "T_cap": "452960255/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                  "T_deleted": "150970369/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_deleted_after_birth": "150970369/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_final_middle": "0",
                  "T_kept_high": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_kept_low": "0",
                  "T_light": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_light_after_birth": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_low_after_birth": "0",
                  "T_middle": "0",
                  "T_new_heavy": "0",
                  "T_nu": "3873164664546532852557750246292594801599487629184796591016223807986536505268322102937263878787015274373537026948729344455/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                  "T_res": "452960255/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "0",
                    "upper": "12287/12288"
                  },
                  "kept_capture_bounds": {
                    "lower": "1/12288",
                    "upper": "1"
                  },
                  "kept_packet_H_constant_on_halfopen_row": true,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_high_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "150970369/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_birth_near": "0",
                      "T_cap": "150970369/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                      "T_deleted": "150970369/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_deleted_after_birth": "150970369/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "1290914803561189452309157121285694081846003105921432136547303456631780117733130982742171742266541616064767379631602806329/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                      "T_res": "150970369/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "150970369/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "150970369/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    },
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "1",
                      "T_birth_deep": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_birth_near": "0",
                      "T_cap": "150994943/168189810928024604539988150072535539400863975691210913280871352979838879763980683176153969876403579281439870100120984231101228410848784146367586106890239703835721531675616807119855074222978801598464",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_kept_low": "0",
                      "T_light": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_light_after_birth": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "1291124930492671700124296562503450359876742261631682227234460175677378193767595560097546068260236829154384823658563269063/18687756769780511615554238896948393266762663965690101475652372553315431084886742575128218875155953253493318900013442692344580934538753794040842900765582189315080170186179645235539452691442089066496",
                      "T_res": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "150994943/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "150994943/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "30721/12288",
                      "7/2"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "12287/88928324534258838085302516486672313231311348223211953182303424518077283563470848",
                  "right_endpoint_excluded_for_low": false
                }
              ]
            }
          ],
          "ledger": {
            "T_birth_deep": "3/28948022309329048855892746252171976963317496166410141009864396001978282409984",
            "T_birth_near": "0",
            "T_cap": "3/2227754207823337509102134573095845373483021732054960903603121346630505452738612005129840239901060253798165190221481644194672219102234100585084307285020612396607419274589973120157653414182912",
            "T_deleted": "3/57896044618658097711785492504343953926634992332820282019728792003956564819968",
            "T_deleted_after_birth": "3/57896044618658097711785492504343953926634992332820282019728792003956564819968",
            "T_final_middle": "0",
            "T_kept_high": "150994943/2914003338338593606379192860235278359963610258578209281877718614608356427807812747264",
            "T_kept_low": "1/2914003338338593606379192860235278359963610258578209281877718614608356427807812747264",
            "T_light": "150994943/2914003338338593606379192860235278359963610258578209281877718614608356427807812747264",
            "T_light_after_birth": "150994943/2914003338338593606379192860235278359963610258578209281877718614608356427807812747264",
            "T_low_after_birth": "1/2914003338338593606379192860235278359963610258578209281877718614608356427807812747264",
            "T_middle": "0",
            "T_new_heavy": "0",
            "T_nu": "230871130056998901634447500586778987139139097287883476570009531665502276004866468426255466337216302582851335880707/2227754207823337509102134573095845373483021732054960903603121346630505452738612005129840239901060253798165190221481644194672219102234100585084307285020612396607419274589973120157653414182912",
            "T_res": "3/28948022309329048855892746252171976963317496166410141009864396001978282409984",
            "T_top": "0",
            "T_top_after_birth": "0"
          },
          "light_certified": true,
          "light_source_price_upper": {
            "lower": "6925737060165485984820882083629798231538712967350346342862273262239256677561086383329509224975826808900394875300503493321498026606310869841629815591265621177832783649050748888045608877009763060887183998/54285038484322060988797441586506348011919914766235581130799730853214801304519764858477389416535052202841909290917106535069945893183372971239732558882784378695429694516860763542354106903076171875",
            "upper": "20777211180496457954462646250889394694616138902051039028586819796535930452709440511931997669217998158129996356469411081496900266344762289060419969017270363703071599708228675210651062904045340621127434639/162855115452966182966392324759519044035759744298706743392399192559644403913559294575432168249605156608525727872751319605209837679550118913719197676648353136086289083550582290627062320709228515625"
          },
          "middle_after_light": false,
          "new_heavy_terminal_over_X": "0",
          "p_universal_exact": "542101086242752217003726381988226782003339009/542101086242752217003726400434970855712890625",
          "pooled_after_light_mass_per_box": "0",
          "pooled_after_top_box_mean": "0",
          "rational_mean_upper_after_top": "9223372036854775808",
          "raw_box_mean": "1001/9223372036854775808",
          "representative_first_kept_box_bounds": [
            [
              "3",
              "5"
            ],
            [
              "0",
              "2"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ],
            [
              "-1",
              "1"
            ]
          ],
          "retained_mass_actual": "4366362",
          "root_constant_test_2_Hn_actual_fraction_le_K": false,
          "root_constant_test_2_Hn_p_le_K": false,
          "root_exp_one_third_mean_proof": {
            "P_minus_3_ge_6n": false,
            "certified_for_root_only": false,
            "proof": "For root period only: log(1+u)<=u from positive integral; 2n/(P-3)<=1/3 gives (1+2/(P-3))^n<=exp(1/3). Small P has no such certification; no exp(1/3) numerical evaluation.",
            "twon_over_P_minus_3": "64"
          },
          "shift_optimal_lex": [
            0,
            2,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1
          ],
          "shift_proof": "Full uniform T/P first-coordinate periods force deletion>=3/P for every shift; compact coordinates (0,1), then (0) permit exactly shift(0,2,1,...), lex first among equality choices.",
          "top_after_light": false,
          "top_source_price_upper_K_Wtop": "0",
          "top_threshold_actual": "170141183460469231731687303715884105728",
          "u": "1",
          "zero_captured_remainder_certificates": [
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate",
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate",
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate"
          ]
        },
        {
          "P": 2181,
          "W_light": "0",
          "W_middle": "10900890",
          "W_top_after_light": "0",
          "actual_delete_fraction": "1/727",
          "beta_new": "1/12288",
          "birth_first_final_middle_over_X": "150994943/402653184",
          "birth_near_source_price_upper": "0",
          "boundary_fee_using_actual_delete_mass": {
            "lower": "459223847705712820989165789929632326687060232271565445687608880209372175541689541992371003412019691341903405816938/337118405255068041688704678100102289548986080838644680485418787107444300749719781894853985581730089829595075",
            "upper": "1377671543117138462967497369788896980061180696814696337062826641586611795861173390505088118220572176418681268846814/1011355215765204125066114034300306868646958242515934041456256361322332902249159345684561956745190269488785225"
          },
          "boundary_fee_using_universal_p": {
            "lower": "10266762786056148101421268683796369999885878732684486868204895397664733624368368063042873243366872563730211516488993248228031362332336331994308135766845659803351474376787782483732939384433813057811721574965017385012035743686104961227336743782359016982566845638352303146568640012227572901195242/122942371790145521967406948683673115111642386044502910023703718111063509048744395312043890394224519849649214000872645803876420857812288235128635154106037830754946149759705746606983033037138235166658688928911242976825887114035651818042279898612876750774692023779784675743463533449320885",
            "upper": "30800288358168444304263806051389109999657636198053460604614686214423060915910083918876984717764010054475600986814319573791796110016469763426471485399541852767332621778391137083208137515634212372502752491187778641695817551215422627977670847460916930709732984020440221900469711711906353563749726/368827115370436565902220846051019345334927158133508730071111154333190527146233185936131671182673559548947642002617937411629262573436864705385905462318113492264838449279117239820949099111414705499976066786733728930477661342106955454126839695838630252324076071339354027230390600347962655"
          },
          "box_mass_times_analytic_count": "10900890",
          "c": "1/26790027264",
          "counts": {
            "physical_f_inputs_added": 0,
            "positive_joint_pair_cells": 8,
            "scheme_label_rows": 4,
            "source_shift_enumerations": 0
          },
          "delete_mass_actual": "15015",
          "each_kept_box_mass_actual": "2180178",
          "heavy_certified": true,
          "heavy_finite_alternative_Hn_Wkeep": {
            "lower": "5051462324762841030880823689225955593557662554987219902563697682303093930958584961916081037532216604760937463986318/10215709250153577020869838730306129986332911540564990317739963245680130325749084299844060169143336055442275",
            "upper": "15154386974288523092642471067677866780672987664961659707691093057452729754472907295555969300426293940605493957314954/30647127750460731062609516190918389958998734621694970953219889737040390977247252899532180507430008166326825"
          },
          "is_root_period": true,
          "kept_box_volume": "4322191718359157675158711317714561408423734057779594806152175175715590923909121497440730595756115343127338450259994328276502353938879489920495181086009254093733020516941993891008922663535471069629661362930954797056",
          "kept_boxes_analytic_count": 5,
          "labels": [
            {
              "label": 0,
              "ledger": {
                "T_birth_deep": "3/28948022309329048855892746252171976963317496166410141009864396001978282409984",
                "T_birth_near": "0",
                "T_cap": "3/2227754207823337509102134573095845373483021732054960903603121346630505452738612005129840239901060253798165190221481644194672219102234100585084307285020612396607419274589973120157653414182912",
                "T_deleted": "1/14474011154664524427946373126085988481658748083205070504932198000989141204992",
                "T_deleted_after_birth": "1/14474011154664524427946373126085988481658748083205070504932198000989141204992",
                "T_final_middle": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                "T_kept_high": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                "T_kept_low": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                "T_light": "0",
                "T_light_after_birth": "0",
                "T_low_after_birth": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                "T_middle": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                "T_new_heavy": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                "T_nu": "230871130056998901634447500586778987139139097287883476570009531665502276004866468426255466337216302582851335880707/2227754207823337509102134573095845373483021732054960903603121346630505452738612005129840239901060253798165190221481644194672219102234100585084307285020612396607419274589973120157653414182912",
                "T_res": "3/28948022309329048855892746252171976963317496166410141009864396001978282409984",
                "T_top": "0",
                "T_top_after_birth": "0"
              },
              "probability": "1/2",
              "rows": [
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/5005",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "49151/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_birth_near": "0",
                  "T_cap": "49151/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                  "T_deleted": "24575/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_deleted_after_birth": "24575/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_final_middle": "0",
                  "T_kept_high": "0",
                  "T_kept_low": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_light": "0",
                  "T_light_after_birth": "0",
                  "T_low_after_birth": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_middle": "0",
                  "T_new_heavy": "0",
                  "T_nu": "420279515312279741267952929679287925810215769288768916921945870033003791404266362578477126886685869935175037402689991/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                  "T_res": "49151/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "12287/12288",
                    "upper": "1"
                  },
                  "kept_capture_bounds": {
                    "lower": "0",
                    "upper": "1/12288"
                  },
                  "kept_packet_H_constant_on_halfopen_row": false,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_low_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "24575/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_birth_near": "0",
                      "T_cap": "24575/168189810928024604539988150072535539400863975691210913280871352979838879763980683176153969876403579281439870100120984231101228410848784146367586106890239703835721531675616807119855074222978801598464",
                      "T_deleted": "24575/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_deleted_after_birth": "24575/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "210135482264842518802464715811855318849790493179619868026221638543693275289614572650934373527299653184206354787717575/18687756769780511615554238896948393266762663965690101475652372553315431084886742575128218875155953253493318900013442692344580934538753794040842900765582189315080170186179645235539452691442089066496",
                      "T_res": "24575/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "24575/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "24575/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    },
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_birth_near": "0",
                      "T_cap": "1/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "8550782594703663023498055577288110634782929529180869502592945617240825037217276608379832086563566762327827254841/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                      "T_res": "1/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "1/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "1/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "5/2",
                      "30721/12288"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "1/88928324534258838085302516486672313231311348223211953182303424518077283563470848",
                  "right_endpoint_excluded_for_low": true
                },
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/5005",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "452935681/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_birth_near": "0",
                  "T_cap": "452935681/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                  "T_deleted": "150970369/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_deleted_after_birth": "150970369/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_final_middle": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_kept_high": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_kept_low": "0",
                  "T_light": "0",
                  "T_light_after_birth": "0",
                  "T_low_after_birth": "0",
                  "T_middle": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_new_heavy": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_nu": "3872954537615050604742610805074838523568748473474546500329067088940938429233857525581889552793320061283919582921768881721/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                  "T_res": "452935681/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "0",
                    "upper": "12287/12288"
                  },
                  "kept_capture_bounds": {
                    "lower": "1/12288",
                    "upper": "1"
                  },
                  "kept_packet_H_constant_on_halfopen_row": true,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_high_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "150970369/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_birth_near": "0",
                      "T_cap": "150970369/168189810928024604539988150072535539400863975691210913280871352979838879763980683176153969876403579281439870100120984231101228410848784146367586106890239703835721531675616807119855074222978801598464",
                      "T_deleted": "150970369/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_deleted_after_birth": "150970369/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "1290914803561189452309157121285694081846003105921432136547303456631780117733130982742171742266541616064767379631602806329/18687756769780511615554238896948393266762663965690101475652372553315431084886742575128218875155953253493318900013442692344580934538753794040842900765582189315080170186179645235539452691442089066496",
                      "T_res": "150970369/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "150970369/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "150970369/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    },
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "1",
                      "T_birth_deep": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_birth_near": "0",
                      "T_cap": "150994943/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_kept_high": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_new_heavy": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_nu": "1291124930492671700124296562503450359876742261631682227234460175677378193767595560097546068260236829154384823658563269063/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                      "T_res": "150994943/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "150994943/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "150994943/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "30721/12288",
                      "7/2"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "12287/88928324534258838085302516486672313231311348223211953182303424518077283563470848",
                  "right_endpoint_excluded_for_low": false
                }
              ]
            },
            {
              "label": 1,
              "ledger": {
                "T_birth_deep": "3/28948022309329048855892746252171976963317496166410141009864396001978282409984",
                "T_birth_near": "0",
                "T_cap": "3/2227754207823337509102134573095845373483021732054960903603121346630505452738612005129840239901060253798165190221481644194672219102234100585084307285020612396607419274589973120157653414182912",
                "T_deleted": "1/28948022309329048855892746252171976963317496166410141009864396001978282409984",
                "T_deleted_after_birth": "1/28948022309329048855892746252171976963317496166410141009864396001978282409984",
                "T_final_middle": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                "T_kept_high": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                "T_kept_low": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                "T_light": "0",
                "T_light_after_birth": "0",
                "T_low_after_birth": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                "T_middle": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                "T_new_heavy": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                "T_nu": "230871130056998901634447500586778987139139097287883476570009531665502276004866468426255466337216302582851335880707/2227754207823337509102134573095845373483021732054960903603121346630505452738612005129840239901060253798165190221481644194672219102234100585084307285020612396607419274589973120157653414182912",
                "T_res": "3/28948022309329048855892746252171976963317496166410141009864396001978282409984",
                "T_top": "0",
                "T_top_after_birth": "0"
              },
              "probability": "1/2",
              "rows": [
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/5005",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "24577/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_birth_near": "0",
                  "T_cap": "24577/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                  "T_deleted": "24575/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_deleted_after_birth": "24575/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_final_middle": "0",
                  "T_kept_high": "0",
                  "T_kept_low": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_light": "0",
                  "T_light_after_birth": "0",
                  "T_low_after_birth": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_middle": "0",
                  "T_new_heavy": "0",
                  "T_nu": "210152583830031926128511711923009895071060059038678229765226824434927756939689007204151133191472780317731010442227257/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                  "T_res": "24577/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "12287/12288",
                    "upper": "1"
                  },
                  "kept_capture_bounds": {
                    "lower": "0",
                    "upper": "1/12288"
                  },
                  "kept_packet_H_constant_on_halfopen_row": false,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_low_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "24575/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_birth_near": "0",
                      "T_cap": "24575/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                      "T_deleted": "24575/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_deleted_after_birth": "24575/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "210135482264842518802464715811855318849790493179619868026221638543693275289614572650934373527299653184206354787717575/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                      "T_res": "24575/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "24575/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "24575/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    },
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_birth_near": "0",
                      "T_cap": "1/168189810928024604539988150072535539400863975691210913280871352979838879763980683176153969876403579281439870100120984231101228410848784146367586106890239703835721531675616807119855074222978801598464",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "8550782594703663023498055577288110634782929529180869502592945617240825037217276608379832086563566762327827254841/18687756769780511615554238896948393266762663965690101475652372553315431084886742575128218875155953253493318900013442692344580934538753794040842900765582189315080170186179645235539452691442089066496",
                      "T_res": "1/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "1/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "1/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "5/2",
                      "30721/12288"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "1/88928324534258838085302516486672313231311348223211953182303424518077283563470848",
                  "right_endpoint_excluded_for_low": true
                },
                {
                  "Af_exact": "3",
                  "F_D_exact": "0",
                  "F_exact": "1/5005",
                  "R": "1",
                  "R_power_n": "1",
                  "T_birth_deep": "452960255/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_birth_near": "0",
                  "T_cap": "452960255/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                  "T_deleted": "150970369/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_deleted_after_birth": "150970369/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_final_middle": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_kept_high": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_kept_low": "0",
                  "T_light": "0",
                  "T_light_after_birth": "0",
                  "T_low_after_birth": "0",
                  "T_middle": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_new_heavy": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                  "T_nu": "3873164664546532852557750246292594801599487629184796591016223807986536505268322102937263878787015274373537026948729344455/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                  "T_res": "452960255/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                  "T_top": "0",
                  "T_top_after_birth": "0",
                  "b_res_exact": "1",
                  "deleted_capture_bounds": {
                    "lower": "0",
                    "upper": "12287/12288"
                  },
                  "kept_capture_bounds": {
                    "lower": "1/12288",
                    "upper": "1"
                  },
                  "kept_packet_H_constant_on_halfopen_row": true,
                  "mu_heavy_capture_equals_b_K_active": true,
                  "name": "new_kept_high_gamma",
                  "original_low_delta": false,
                  "pair_cells": [
                    {
                      "G1": "1/2",
                      "G_original": "1/2",
                      "Gamma_dense": "0",
                      "Gamma_new": "0",
                      "T_birth_deep": "150970369/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_birth_near": "0",
                      "T_cap": "150970369/336379621856049209079976300145071078801727951382421826561742705959677759527961366352307939752807158562879740200241968462202456821697568292735172213780479407671443063351233614239710148445957603196928",
                      "T_deleted": "150970369/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_deleted_after_birth": "150970369/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_final_middle": "0",
                      "T_kept_high": "0",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "0",
                      "T_new_heavy": "0",
                      "T_nu": "1290914803561189452309157121285694081846003105921432136547303456631780117733130982742171742266541616064767379631602806329/37375513539561023231108477793896786533525327931380202951304745106630862169773485150256437750311906506986637800026885384689161869077507588081685801531164378630160340372359290471078905382884178132992",
                      "T_res": "150970369/4371005007507890409568789290352917539945415387867313922816577921912534641711719120896",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "150970369/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "150970369/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "2",
                          "3"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": true,
                      "source_owner_first_index": 2,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    },
                    {
                      "G1": "1",
                      "G_original": "1",
                      "Gamma_dense": "0",
                      "Gamma_new": "1",
                      "T_birth_deep": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_birth_near": "0",
                      "T_cap": "150994943/168189810928024604539988150072535539400863975691210913280871352979838879763980683176153969876403579281439870100120984231101228410848784146367586106890239703835721531675616807119855074222978801598464",
                      "T_deleted": "0",
                      "T_deleted_after_birth": "0",
                      "T_final_middle": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_kept_high": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_kept_low": "0",
                      "T_light": "0",
                      "T_light_after_birth": "0",
                      "T_low_after_birth": "0",
                      "T_middle": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_new_heavy": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_nu": "1291124930492671700124296562503450359876742261631682227234460175677378193767595560097546068260236829154384823658563269063/18687756769780511615554238896948393266762663965690101475652372553315431084886742575128218875155953253493318900013442692344580934538753794040842900765582189315080170186179645235539452691442089066496",
                      "T_res": "150994943/2185502503753945204784394645176458769972707693933656961408288960956267320855859560448",
                      "T_top": "0",
                      "T_top_after_birth": "0",
                      "birth_near_visible": false,
                      "cap_density": "8",
                      "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
                      "independent_affine_capture_area": "150994943/301989888",
                      "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
                      "raw_joint_capture_volume": "150994943/1345518487424196836319905200580284315206911805529687306246970823838711038111845465409231759011228634251518960800967873848809827286790273170940688855121917630685772253404934456958840593783830412787712",
                      "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
                      "source_bounds": [
                        [
                          "3",
                          "4"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ],
                        [
                          "15/128",
                          "17/128"
                        ]
                      ],
                      "source_deleted": false,
                      "source_owner_first_index": 3,
                      "source_volume": "1/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
                    }
                  ],
                  "receiver_bounds": [
                    [
                      "30721/12288",
                      "7/2"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ],
                    [
                      "3/32",
                      "5/32"
                    ]
                  ],
                  "receiver_volume": "12287/88928324534258838085302516486672313231311348223211953182303424518077283563470848",
                  "right_endpoint_excluded_for_low": false
                }
              ]
            }
          ],
          "ledger": {
            "T_birth_deep": "3/28948022309329048855892746252171976963317496166410141009864396001978282409984",
            "T_birth_near": "0",
            "T_cap": "3/2227754207823337509102134573095845373483021732054960903603121346630505452738612005129840239901060253798165190221481644194672219102234100585084307285020612396607419274589973120157653414182912",
            "T_deleted": "3/57896044618658097711785492504343953926634992332820282019728792003956564819968",
            "T_deleted_after_birth": "3/57896044618658097711785492504343953926634992332820282019728792003956564819968",
            "T_final_middle": "150994943/2914003338338593606379192860235278359963610258578209281877718614608356427807812747264",
            "T_kept_high": "150994943/2914003338338593606379192860235278359963610258578209281877718614608356427807812747264",
            "T_kept_low": "1/2914003338338593606379192860235278359963610258578209281877718614608356427807812747264",
            "T_light": "0",
            "T_light_after_birth": "0",
            "T_low_after_birth": "1/2914003338338593606379192860235278359963610258578209281877718614608356427807812747264",
            "T_middle": "150994943/2914003338338593606379192860235278359963610258578209281877718614608356427807812747264",
            "T_new_heavy": "150994943/2914003338338593606379192860235278359963610258578209281877718614608356427807812747264",
            "T_nu": "230871130056998901634447500586778987139139097287883476570009531665502276004866468426255466337216302582851335880707/2227754207823337509102134573095845373483021732054960903603121346630505452738612005129840239901060253798165190221481644194672219102234100585084307285020612396607419274589973120157653414182912",
            "T_res": "3/28948022309329048855892746252171976963317496166410141009864396001978282409984",
            "T_top": "0",
            "T_top_after_birth": "0"
          },
          "light_certified": false,
          "light_source_price_upper": {
            "lower": "0",
            "upper": "0"
          },
          "middle_after_light": true,
          "new_heavy_terminal_over_X": "150994943/402653184",
          "p_universal_exact": "115919861983768005620643657047400801773825603222230921317889677840115027355219664483474765426309375390168261912014036311280472659283352452934879354355148541743781103120316785502257665/1374682154777212799061202739838245952436590858958108470090036971518856496942301091000099708900972350637100913106738308603253907382364456684731821157482208742094269950055513101000573441",
          "pooled_after_light_mass_per_box": "2180178",
          "pooled_after_top_box_mean": "91/180407033907636600515849040726043968963341433249002204113539326142231860919489168438130503203778084277791904593872373665435443440140224138930427459972003259609859776147507884256153379394585151917090799020408832",
          "rational_mean_upper_after_top": "124241267257814063326368199463296441168896228629870606353268219295558136987813041914295200555794065278178204800894900531753432812805000000000000000000000000000000000000000000000000000000000000000/234306482547192713569560397269021877220896032434382136471372669041788137180293364455722275453313307434654669554997858460927519509333472151640019602819915001174552895900414001783462816164641443841",
          "raw_box_mean": "91/180407033907636600515849040726043968963341433249002204113539326142231860919489168438130503203778084277791904593872373665435443440140224138930427459972003259609859776147507884256153379394585151917090799020408832",
          "representative_first_kept_box_bounds": [
            [
              "3",
              "2181"
            ],
            [
              "-2176",
              "2"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ],
            [
              "-2177",
              "1"
            ]
          ],
          "retained_mass_actual": "10900890",
          "root_constant_test_2_Hn_actual_fraction_le_K": true,
          "root_constant_test_2_Hn_p_le_K": true,
          "root_exp_one_third_mean_proof": {
            "P_minus_3_ge_6n": true,
            "certified_for_root_only": true,
            "proof": "For root period only: log(1+u)<=u from positive integral; 2n/(P-3)<=1/3 gives (1+2/(P-3))^n<=exp(1/3). Small P has no such certification; no exp(1/3) numerical evaluation.",
            "twon_over_P_minus_3": "64/1089"
          },
          "shift_optimal_lex": [
            0,
            2,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1,
            1
          ],
          "shift_proof": "Full uniform T/P first-coordinate periods force deletion>=3/P for every shift; compact coordinates (0,1), then (0) permit exactly shift(0,2,1,...), lex first among equality choices.",
          "top_after_light": false,
          "top_source_price_upper_K_Wtop": "0",
          "top_threshold_actual": "2291846860498246127558399105325996298514522019948557766464696823078462630589467961886277681021104372534216672830028986232501119955479259820638213242880000000000000000000000000000000000000000000000000000000000000000",
          "u": "1",
          "zero_captured_remainder_certificates": [
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate",
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate",
            "zero up to Lebesgue-null endpoint boundary; full-box gap certificate"
          ]
        }
      ],
      "scope": "Real I11-form heavy traffic in the stated dominating class, not a certified original FULL hard instance; root-period positive middle retained.",
      "source_ledger": {
        "W_cap": "10905/38478521676166483605741250097796497856523182881313912761668255277583712667477744737709244389536050430475222646784",
        "W_f": "841734207430462580463540314626840443105522930497380806643980601546913075597522681567626935996188603668330599744138128025/76957043352332967211482500195592995713046365762627825523336510555167425334955489475418488779072100860950445293568",
        "W_nu": "420027887157474099224328940648787279934510694630048946884658316125852437025483651171084029377958520574276635266142710425/38478521676166483605741250097796497856523182881313912761668255277583712667477744737709244389536050430475222646784",
        "W_res": "10915905",
        "Wcap_plus_Wres_equals_Wnu": true,
        "nu_le_f": true
      },
      "sources": [
        {
          "bounds": [
            [
              "0",
              "10905"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ]
          ],
          "cap_density": "8",
          "cap_mass": "10905/76957043352332967211482500195592995713046365762627825523336510555167425334955489475418488779072100860950445293568",
          "f_density": "1846969040455991213075580004694231897113112778303067812560076253324018208038931747410043730697730420662810687045632",
          "f_mass": "32715",
          "name": "visible",
          "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348552",
          "nu_mass": "839216557757191007441216664632941618250770618641456437331984647604100773277689612729438620135781259888664605926369945/76957043352332967211482500195592995713046365762627825523336510555167425334955489475418488779072100860950445293568",
          "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544",
          "res_mass": "10905",
          "volume": "10905/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
        },
        {
          "bounds": [
            [
              "0",
              "10905"
            ],
            [
              "191/128",
              "193/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ],
            [
              "15/128",
              "17/128"
            ]
          ],
          "cap_density": "8",
          "cap_mass": "10905/76957043352332967211482500195592995713046365762627825523336510555167425334955489475418488779072100860950445293568",
          "f_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544008",
          "f_mass": "839216557757191007441216664632941618250770618641456437331984647604100773277689612729438620135781259888664605926359050905/76957043352332967211482500195592995713046365762627825523336510555167425334955489475418488779072100860950445293568",
          "name": "hidden",
          "nu_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544008",
          "nu_mass": "839216557757191007441216664632941618250770618641456437331984647604100773277689612729438620135781259888664605926359050905/76957043352332967211482500195592995713046365762627825523336510555167425334955489475418488779072100860950445293568",
          "res_density": "615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544000",
          "res_mass": "10905000",
          "volume": "10905/615656346818663737691860001564743965704370926101022604186692084441339402679643915803347910232576806887603562348544"
        }
      ],
      "stage": "parameter_dimension_label_expansion"
    }
  ],
  "round": 105,
  "scope": "Exact true n-dimensional source/receiver partial-capture certificates, root-period source boundary price and honest heavy/middle terminals. No FULL, uniform contraction, Cp numerical validation or n-law fit.",
  "status": "PASS"
}
```

## 核验范围与实际复现记录

主代理实际全文审阅来源图PUBLIC、出生窗口、来源走廊、盒邻域及统一组合，独审先检查各准确命题与漏项，再读作者证明。原出生门另实际核回原证明的2280–2310及3536–3560行；它来自已支付的整格异常和hard顶层补集，不是给新余额重新定义出生。原FULL的大维适用范围与抽象必要条件测试严格区分。

审核修正包括：来源图slot从1编号、child捕获标签取精确比值而非只有下界；走廊低捕获转移先保留原活跃行；整盒均值用canonical盒的全部冻结余额；轻块与top只共享互斥类别预算；跨边界捕获只完整分账，未宣称所有跨边界行已付清。深出生仍在x,z联合门内，不成为接收点依赖的来源核。

本轮没有使用新的外部研究定理。更新的数学技能用于守恒、量词、可测性及终端审计；未引用尚未阅读原文的Bellman或捕获树结论。既有有限窗口包络和R104严格单包工具按原假设使用。

固定三阶段数值协议在首次执行前经父与独审核验。公开来源是实际n维常密度slab，所有测度及捕获保留真正体积。长来源的均匀性给有限shift最优与图连接的解析证书，未冒称枚举L^n平移、指数多出生格或所有图。小周期与理论周期分别报告费用，不能以小周期成功替代理论period的根阶检查。

实际执行：作者首次生产运行与主代理一次隔离复制 `python3 -I numeric.py` 均 exit 0。冻结程序27358字节，SHA-256 `845f884b471472ecc2b58369b9c568c079775b4a09eba19d1dfda7ff23b0e464`；完整stdout450267字节，两次逐字节一致，SHA-256 `c41bec5c07196eaa4a5948280517bc957004995ca878a2b073f2cc5f86a985ed`。未追加输入、精度或实验菜单。

三阶段分别使用n=4、16、64；共3个真实f、6个来源slab、4个预冻结标签、6个方案状态、16个接收行、32个正联合捕获格。理论周期实际为49、294、2181，三者通用边界费用均通过根阶有理区间检查；小周期5三者均未通过该费用条件。小周期的轻块支付不能替代理论周期的结论。

父代理另外逐项读取并解析全部JSON，核对实际源质量、每个正格的原交通/截顶/余额与删除/低保留/大保留恒等式、先出生后几何的完整分解、互斥块分类和费用。理论周期n=16、64仍留下正中间段，除以X分别为150994943/603979776及150994943/402653184；n=4由出生近窗付款后中间段为0。所有top类别在本菜单中为空，因此没有正top数值见证，top的一般结论依靠正文证明。所有算例未认证原FULL全套资格，也未证明一般Tmid上界。

独审另静态解析完整stdout，并用分段线性捕获长度的梯形积分重新计算32个正联合体积；这是对已有数据的独立数学复核，未额外运行producer。其源账、行与标签总账、Γ支持、根阶边界费用和正中间段检查通过。


## 公开几何核验证程序

```python
"""PUBLIC R105 exact physical periodic-corridor certificates; stdlib only.

Three NEW two-slab non-atomic f inputs, each with P5/root-period schemes.
Actual cap/res, original G, recomputed dense/harmonic and heavy qualification.
True n-dimensional partial joint capture, source deletion and retained-low fee.
Birth-grid mass/window NECESSARY-CONDITION observations, not original FULL.
Fixed sources/shift/package masses; positive root-period middle terminal kept.
No dimension-law fit, source-cell/shift/corner enumeration or hidden reruns.
"""
from fractions import Fraction as F
import json
import math
import sys
import time

DELTA = F(1, 3072)
BETA = DELTA / 2
GAMMA = BETA / 2


def log_bounds(x):
    assert x in (F(2), F(3, 2))
    z = (x - 1) / (x + 1)
    power, square, lo = z, z * z, F(0)
    for j in range(64):
        lo += 2 * power / (2 * j + 1)
        power *= square
    return lo, lo + 2 * power / (129 * (1 - square))


LOG2, LOG15 = log_bounds(F(2)), log_bounds(F(3, 2))


def exp_bounds(k):
    assert k in (2, 4, 8)
    term, lo = F(1), F(1)
    for j in range(1, 64):
        term *= F(k, j)
        lo += term
    following = term * F(k, 64)
    return lo, lo + following / (1 - F(k, 65))


EXP2 = exp_bounds(2)


def iv(lo, hi):
    assert lo <= hi
    return {'lower': str(lo), 'upper': str(hi)}


def scale_iv(pair, mass):
    assert mass >= 0
    return iv(pair[0] * mass, pair[1] * mass)


def ceil_fraction(x):
    return (x.numerator + x.denominator - 1) // x.denominator


def box_volume(box):
    return math.prod(hi - lo for lo, hi in box)


def bounds_json(box):
    return [[str(a), str(b)] for a, b in box]


def intersection_volume(a, b):
    assert len(a) == len(b)
    return math.prod(max(F(0), min(hi, bh) - max(lo, bl))
                     for (lo, hi), (bl, bh) in zip(a, b))


def strip_cdf(I, J, t):
    """Independent exact endpoint primitive: area of x-z <= t."""
    a, b = I
    c, d = J
    pos2 = lambda v: max(F(0), v) ** 2
    return (pos2(d + t - a) - pos2(c + t - a)
            - pos2(d + t - b) + pos2(c + t - b)) / 2


def strip_area(I, J, radius):
    area = strip_cdf(I, J, radius / 2) - strip_cdf(I, J, -radius / 2)
    assert 0 <= area <= (I[1] - I[0]) * (J[1] - J[0])
    return area


def joint_capture_volume(receiver, source, radius):
    assert len(receiver) == len(source)
    return math.prod(strip_area(I, J, radius) for I, J in zip(receiver, source))


def capture_length(x, source_interval, radius):
    c, d = source_interval
    return max(F(0), min(x + radius / 2, d) - max(x - radius / 2, c))


def capture_volume_bounds(receiver, source, radius):
    """Whole receiver-box bounds, independent of joint indicator averaging."""
    minima, maxima = [], []
    for (a, b), (c, d) in zip(receiver, source):
        la, lb = capture_length(a, (c, d), radius), capture_length(b, (c, d), radius)
        low, high = min(la, lb), max(la, lb)
        plateau_lo = min(c + radius / 2, d - radius / 2)
        plateau_hi = max(c + radius / 2, d - radius / 2)
        if max(a, plateau_lo) <= min(b, plateau_hi):
            high = max(high, min(radius, d - c))
        assert 0 <= low <= high
        minima.append(low)
        maxima.append(high)
    return math.prod(minima), math.prod(maxima)


def zero_joint_certificate(receiver, source, radius):
    gap = any(max(sl - rh, rl - sh, F(0)) >= radius / 2
              for (rl, rh), (sl, sh) in zip(receiver, source))
    assert gap and joint_capture_volume(receiver, source, radius) == 0
    return 'zero up to Lebesgue-null endpoint boundary; full-box gap certificate'


def owner_gate(index, label):
    return F(1) if (index % 2 == 0) == (label == 0) else F(1, 2)


def birth_observations(n, root, T, h, alpha, expK):
    """Analytic tensor census, no birth-cell or corner materialization."""
    if n == 4:
        types = [('visible', F(3, n), T * n, F(T)),
                 ('hidden', (h + root * alpha) / (2 * n), 2 * T * n, T * h)]
    else:
        count = T * n * 2 ** (n - 1)
        types = [('visible', F(3, n * 2 ** (n - 1)), count, F(T)),
                 ('hidden', (h + root * alpha) / (n * 2 ** (n - 1)), count, T * h)]
    records = []
    near_flags = {}
    near_mass = F(0)
    for name, HC, multiplicity, resmass in types:
        fmass = F(3 * T) if name == 'visible' else T * (h + root * alpha)
        assert HC * multiplicity == fmass
        tn = (HC * root / EXP2[1], HC * root / EXP2[0])
        assert 0 < tn[0] <= tn[1] <= 1
        window_top = (HC * root * expK[0] / EXP2[1], HC * root * expK[1] / EXP2[0])
        near, deep = window_top[0] >= 1, window_top[1] < 1
        if not near and not deep:
            raise ValueError('UNKNOWN_BIRTH_WINDOW_STOP_NO_PRECISION_EXTENSION')
        near_flags[name] = near
        if near:
            near_mass += resmass
        records.append({'slab': name, 'HC_mu_hi_full_f': str(HC), 'birth_d0': str(F(1, n)),
                        'multiplicity_analytic_not_enumerated': str(multiplicity),
                        'HC_times_multiplicity_f_mass': str(HC * multiplicity),
                        'res_mass_source_once': str(resmass), 't_C_power_n': iv(*tn),
                        't_C_le_R1': True, 'birth_L': str(root),
                        't_C_power_n_times_exp_L': iv(*window_top),
                        'near_at_R1': near, 'deep_at_R1': deep,
                        'J_C_power_n_empty': deep,
                        'J_C_power_n_lower_if_nonempty': '1' if near else None,
                        'J_C_power_n_upper_if_nonempty': iv(min(F(2 ** n), window_top[0]), min(F(2 ** n), window_top[1])) if near else None})
    return {'q': '1', 'd0': str(F(1, n)), 'mu_hi_equals_f_by_actual_density': True,
            'original_FULL_large_dimension_threshold': 512, 'original_FULL_certified': False,
            'types': records, 'near_visible': near_flags['visible'], 'near_source_mass': str(near_mass),
            'near_source_price_upper_1_plus_K': str((1 + root) * near_mass),
            'scope': 'Actual HC and birth/window necessary-condition observations on this dominating-class input; not inherited original FULL/birth forest.'}


def actual_scheme(n, root, T, h, P, source_visible, source_hidden, receiver, alpha,
                  probabilities, Hn, expK, birth, root_period):
    assert T % P == 0 and P >= 5
    count = T // P
    Wres = T * (1 + h)
    d = F(3, P) * Wres
    Wkeep = Wres - d
    p = 1 - (1 - F(3, P)) ** n
    assert F(3, P) <= p <= F(3 * n, P) and d <= p * Wres
    shift = [0, 2] + [1] * (n - 2)
    kept_box = [(F(3), F(P)), (F(5 - P), F(2))] + [(F(4 - P), F(1))] * (n - 2)
    assert box_volume(kept_box) == (P - 3) ** n
    kept_visible = list(source_visible)
    kept_hidden = list(source_hidden)
    kept_visible[0] = kept_hidden[0] = (F(3), F(P))
    assert intersection_volume(kept_visible, kept_box) == box_volume(kept_visible)
    assert intersection_volume(kept_hidden, kept_box) == box_volume(kept_hidden)
    m = F((P - 3) * (1 + h))
    assert m == (box_volume(kept_visible) + h * box_volume(kept_hidden)) / alpha
    assert count * m == Wkeep
    light, heavy = m <= expK[0], m > expK[1]
    if not light and not heavy:
        raise ValueError('UNKNOWN_KEPT_BOX_CLASS_STOP_NO_PRECISION_EXTENSION')
    assert m >= GAMMA
    u, c = F(1), GAMMA / m
    top_threshold = F(4 * (P - 1) ** n, root)
    mass_after_light = F(0) if light else m
    top = mass_after_light >= top_threshold
    middle = 0 < mass_after_light < top_threshold
    mass_after_top = F(0) if top else mass_after_light
    rational_mean_limit = F(4, root) * F(P - 1, P - 3) ** n
    if mass_after_top:
        assert mass_after_top / (P - 3) ** n < rational_mean_limit
    if root_period:
        assert P - 3 >= 6 * n
        assert 2 * Hn[1] * p <= root
    small_rows = []
    for name, bounds, open_right in (('new_kept_low_gamma', (F(5, 2), F(5, 2) + GAMMA), True),
                                     ('new_kept_high_gamma', (F(5, 2) + GAMMA, F(7, 2)), False)):
        box = list(receiver)
        box[0] = bounds
        small_rows.append({'name': name, 'box': box, 'low': open_right,
                           'right_endpoint_excluded_for_low': open_right})
    # Complete source partition for actual receiver captures. Remainders null.
    pieces = []
    for index in (2, 3):
        b = list(source_visible)
        b[0] = (F(index), F(index + 1))
        assert box_volume(b) == alpha
        pieces.append({'index': index, 'box': b, 'deleted': index == 2})
    before, after = list(source_visible), list(source_visible)
    before[0], after[0] = (F(0), F(2)), (F(4), F(T))
    zero_certificates = [zero_joint_certificate(receiver, b, F(1)) for b in (before, after, source_hidden)]
    assert box_volume(before) + sum((box_volume(x['box']) for x in pieces), F(0)) + box_volume(after) == box_volume(source_visible)
    X = box_volume(receiver)
    total = {key: F(0) for key in ('T_nu', 'T_cap', 'T_res', 'T_deleted', 'T_kept_low', 'T_kept_high',
             'T_light', 'T_top', 'T_middle', 'T_new_heavy', 'T_birth_near', 'T_birth_deep',
             'T_deleted_after_birth', 'T_low_after_birth', 'T_light_after_birth', 'T_top_after_birth', 'T_final_middle')}
    labels = []
    pairs = 0
    for label, probability in enumerate(probabilities):
        row_records = []
        label_totals = {key: F(0) for key in total}
        for row in small_rows:
            V = box_volume(row['box'])
            ra, rb = row['box'][0][0] - F(5, 2), row['box'][0][1] - F(5, 2)
            bmin, bmax = capture_volume_bounds(row['box'], kept_visible, F(1))
            assert (bmin / alpha, bmax / alpha) == (ra, rb)
            hidden_min, hidden_max = capture_volume_bounds(row['box'], kept_hidden, F(1))
            assert hidden_min == hidden_max == 0
            if row['low']:
                assert 0 <= ra < rb == GAMMA
                H = False  # affine b'=r<gamma on this half-open receiver cell.
            else:
                assert GAMMA == ra < rb <= 1
                H = True
                assert ra >= c * m and ra >= GAMMA
            values = {key: F(0) for key in total}
            pair_records = []
            for piece in pieces:
                i = piece['index']
                G = owner_gate(i, label)
                joint = joint_capture_volume(row['box'], piece['box'], F(1))
                assert joint > 0 and joint <= V * alpha
                # Independent affine single-x capture integral check.
                affine_area = ((rb - ra) - (rb ** 2 - ra ** 2) / 2) if piece['deleted'] else (rb ** 2 - ra ** 2) / 2
                assert joint == affine_area * X * alpha  # X transverse volume; full E first length1.
                res_density, cap_density = 1 / alpha, F(root)
                nu_density = res_density + cap_density
                tres, tcap, tnu = G * res_density * joint, G * cap_density * joint, G * nu_density * joint
                assert tnu == tres + tcap
                gamma_dense = F(0)  # all global packets have mi/D>b, certified in physical record.
                G1 = G
                gamma_new = u if not piece['deleted'] and H else F(0)
                tdel = tres if piece['deleted'] else F(0)
                tlow = tres if not piece['deleted'] and row['low'] else F(0)
                thigh = tres if not piece['deleted'] and not row['low'] else F(0)
                assert tres == tdel + tlow + thigh
                if thigh:
                    assert gamma_new == 1
                near = birth['near_visible']
                deep = not near
                amounts = {'T_nu': tnu, 'T_cap': tcap, 'T_res': tres, 'T_deleted': tdel,
                           'T_kept_low': tlow, 'T_kept_high': thigh,
                           'T_light': thigh if light else F(0), 'T_top': thigh if top else F(0),
                           'T_middle': thigh if middle else F(0), 'T_new_heavy': thigh if heavy else F(0),
                           'T_birth_near': tres if near else F(0), 'T_birth_deep': tres if deep else F(0),
                           'T_deleted_after_birth': tdel if deep else F(0),
                           'T_low_after_birth': tlow if deep else F(0),
                           'T_light_after_birth': thigh if deep and light else F(0),
                           'T_top_after_birth': thigh if deep and top else F(0),
                           'T_final_middle': thigh if deep and middle else F(0)}
                assert thigh == amounts['T_light'] + amounts['T_top'] + amounts['T_middle']
                assert tres == amounts['T_birth_near'] + amounts['T_deleted_after_birth'] + amounts['T_low_after_birth'] + amounts['T_light_after_birth'] + amounts['T_top_after_birth'] + amounts['T_final_middle']
                for key, value in amounts.items():
                    values[key] += value
                pairs += 1
                pair_records.append({'source_owner_first_index': i, 'source_bounds': bounds_json(piece['box']),
                                     'source_volume': str(alpha), 'raw_joint_capture_volume': str(joint),
                                     'independent_affine_capture_area': str(affine_area),
                                     'nu_density': str(nu_density), 'cap_density': str(cap_density), 'res_density': str(res_density),
                                     'f_density': str(3 / alpha), 'G_original': str(G), 'G1': str(G1),
                                     'Gamma_dense': str(gamma_dense), 'source_deleted': piece['deleted'],
                                     'Gamma_new': str(gamma_new), 'birth_near_visible': near,
                                     **{key: str(value) for key, value in amounts.items()}})
            assert values['T_res'] <= V
            for key, value in values.items():
                label_totals[key] += value
            row_records.append({'name': row['name'], 'receiver_bounds': bounds_json(row['box']), 'receiver_volume': str(V),
                                'right_endpoint_excluded_for_low': row['right_endpoint_excluded_for_low'],
                                'R': '1', 'R_power_n': '1', 'Af_exact': '3', 'b_res_exact': '1',
                                'original_low_delta': False, 'mu_heavy_capture_equals_b_K_active': True,
                                'kept_capture_bounds': iv(ra, rb), 'deleted_capture_bounds': iv(1 - rb, 1 - ra),
                                'kept_packet_H_constant_on_halfopen_row': H, 'F_exact': str(F(1, 5 * (1 + h))),
                                'F_D_exact': '0', 'pair_cells': pair_records,
                                **{key: str(value) for key, value in values.items()}})
        assert label_totals['T_res'] == F(3, 4) * X
        gd, gk = owner_gate(2, label), owner_gate(3, label)
        assert label_totals['T_deleted'] == gd * X / 2
        assert label_totals['T_kept_low'] == gk * GAMMA ** 2 * X / 2
        assert label_totals['T_kept_high'] == gk * (1 - GAMMA ** 2) * X / 2
        for key, value in label_totals.items():
            total[key] += probability * value
        labels.append({'label': label, 'probability': str(probability), 'rows': row_records,
                       'ledger': {key: str(value) for key, value in label_totals.items()}})
    boundary_fee = (2 * Hn[0] * d, 2 * Hn[1] * d)
    universal_boundary_fee = (2 * Hn[0] * p * Wres, 2 * Hn[1] * p * Wres)
    light_factor = (1 + 2 * LOG15[0] + 28 * LOG2[0] + root,
                    1 + 2 * LOG15[1] + 28 * LOG2[1] + root)
    assert F(4) / GAMMA ** 2 == F(3, 2) ** 2 * 2 ** 28
    Wlight, Wtop, Wmiddle = (Wkeep if light else F(0)), (Wkeep if top else F(0)), (Wkeep if middle else F(0))
    assert Wkeep == Wlight + Wtop + Wmiddle
    light_fee = (light_factor[0] * Wlight, light_factor[1] * Wlight)
    top_fee = root * Wtop
    birth_fee = F(birth['near_source_price_upper_1_plus_K'])
    assert total['T_deleted'] + total['T_kept_low'] <= boundary_fee[0]
    assert total['T_light'] <= light_fee[0] and total['T_top'] <= top_fee
    assert total['T_new_heavy'] <= Hn[0] * (Wkeep if heavy else 0)
    assert total['T_middle'] <= Hn[0] * Wmiddle
    assert total['T_birth_near'] <= birth_fee
    assert total['T_res'] <= boundary_fee[0] + light_fee[0] + total['T_new_heavy']
    assert total['T_res'] <= birth_fee + boundary_fee[0] + light_fee[0] + top_fee + total['T_final_middle']
    assert total['T_nu'] == total['T_cap'] + total['T_res']
    return {'P': P, 'is_root_period': root_period, 'shift_optimal_lex': shift,
            'shift_proof': 'Full uniform T/P first-coordinate periods force deletion>=3/P for every shift; compact coordinates (0,1), then (0) permit exactly shift(0,2,1,...), lex first among equality choices.',
            'p_universal_exact': str(p), 'actual_delete_fraction': str(F(3, P)),
            'delete_mass_actual': str(d), 'retained_mass_actual': str(Wkeep),
            'boundary_fee_using_actual_delete_mass': iv(*boundary_fee),
            'boundary_fee_using_universal_p': iv(*universal_boundary_fee),
            'root_constant_test_2_Hn_p_le_K': 2 * Hn[1] * p <= root,
            'root_constant_test_2_Hn_actual_fraction_le_K': 2 * Hn[1] * F(3, P) <= root,
            'kept_boxes_analytic_count': count, 'representative_first_kept_box_bounds': bounds_json(kept_box),
            'kept_box_volume': str((P - 3) ** n), 'each_kept_box_mass_actual': str(m),
            'box_mass_times_analytic_count': str(m * count), 'u': str(u), 'c': str(c), 'beta_new': str(GAMMA),
            'light_certified': light, 'heavy_certified': heavy, 'pooled_after_light_mass_per_box': str(mass_after_light),
            'top_threshold_actual': str(top_threshold), 'top_after_light': top, 'middle_after_light': middle,
            'raw_box_mean': str(m / (P - 3) ** n), 'pooled_after_top_box_mean': str(mass_after_top / (P - 3) ** n),
            'rational_mean_upper_after_top': str(rational_mean_limit),
            'root_exp_one_third_mean_proof': {'P_minus_3_ge_6n': P - 3 >= 6 * n,
                 'twon_over_P_minus_3': str(F(2 * n, P - 3)),
                 'certified_for_root_only': root_period,
                 'proof': 'For root period only: log(1+u)<=u from positive integral; 2n/(P-3)<=1/3 gives (1+2/(P-3))^n<=exp(1/3). Small P has no such certification; no exp(1/3) numerical evaluation.'},
            'W_light': str(Wlight), 'W_top_after_light': str(Wtop), 'W_middle': str(Wmiddle),
            'light_source_price_upper': iv(*light_fee), 'top_source_price_upper_K_Wtop': str(top_fee),
            'heavy_finite_alternative_Hn_Wkeep': scale_iv(Hn, Wkeep if heavy else F(0)),
            'birth_near_source_price_upper': str(birth_fee),
            'zero_captured_remainder_certificates': zero_certificates,
            'labels': labels, 'ledger': {key: str(value) for key, value in total.items()},
            'new_heavy_terminal_over_X': str(total['T_new_heavy'] / X),
            'birth_first_final_middle_over_X': str(total['T_final_middle'] / X),
            'counts': {'scheme_label_rows': 2 * len(probabilities), 'positive_joint_pair_cells': pairs,
                       'physical_f_inputs_added': 0, 'source_shift_enumerations': 0}}


def physical_case(n, stage, hidden_rate):
    root = math.isqrt(n)
    assert root ** 2 == n
    h = F(hidden_rate)
    Hn = (1 + n * LOG2[0], 1 + n * LOG2[1])
    ceil_input = (6 * root * Hn[0], 6 * root * Hn[1])
    ceil_lo, ceil_hi = ceil_fraction(ceil_input[0]), ceil_fraction(ceil_input[1])
    if ceil_lo != ceil_hi:
        raise ValueError('UNKNOWN_ROOT_PERIOD_CEIL_STOP_NO_EXTENSION')
    Lroot, T = 3 + ceil_lo, 5 * (3 + ceil_lo)
    alpha = F(1, 64) ** (n - 1)
    expK = exp_bounds(root)
    Wres, Wcap = F(T) * (1 + h), 2 * T * root * alpha
    Wnu, Wf = Wres + Wcap, T * (3 + h + root * alpha)
    assert Wnu <= Wf and Wcap + Wres == Wnu and 1 + root * alpha < 3
    source_visible = [(F(0), F(T))] + [(F(1, 8) - F(1, 128), F(1, 8) + F(1, 128))] * (n - 1)
    source_hidden = list(source_visible)
    source_hidden[1] = (F(3, 2) - F(1, 128), F(3, 2) + F(1, 128))
    receiver = [(F(5, 2), F(7, 2))] + [(F(1, 8) - F(1, 32), F(1, 8) + F(1, 32))] * (n - 1)
    assert box_volume(source_visible) == box_volume(source_hidden) == T * alpha
    assert intersection_volume(source_visible, source_hidden) == 0
    f_visible_density, f_hidden_density = 3 / alpha, (h + root * alpha) / alpha
    assert f_visible_density > root and f_hidden_density > root
    vb, hb = capture_volume_bounds(receiver, source_visible, F(1)), capture_volume_bounds(receiver, source_hidden, F(1))
    assert vb == (alpha, alpha) and hb == (F(0), F(0))
    Af = (f_visible_density * vb[0] + f_hidden_density * hb[0],
          f_visible_density * vb[1] + f_hidden_density * hb[1])
    assert Af == (F(3), F(3)) and 2 < Af[0] <= Af[1] <= 4
    b = vb[0] / alpha + h * hb[0] / alpha
    assert b == 1 and b >= DELTA and b >= BETA
    assert Wres > expK[1] and 3 * (1 + h) > 2 * root * b
    Kcover = [(F(0), F(T)), (F(0), F(2))] + [(F(0), F(1))] * (n - 2)
    assert all(intersection_volume(s, Kcover) == box_volume(s) for s in (source_visible, source_hidden))
    relevant_packets = []
    for i in range(6):
        length = min(T, i + 3) - max(0, i - 2)
        m = length * (1 + h)
        for second_owner, v in ((0, F(1)), (1, h)):
            macro = [(F(i - 2), F(i + 3)), (F(second_owner - 2), F(second_owner + 3))] + [(F(-2), F(3))] * (n - 2)
            # Direct macro/source integrals check the closed-form masses.
            actual_m = (intersection_volume(macro, source_visible) + h * intersection_volume(macro, source_hidden)) / alpha
            assert actual_m == m and m / (2 * root) > b
            captured_upper = capture_volume_bounds(receiver, source_visible, F(1))[1] / alpha
            assert captured_upper <= b
            relevant_packets.append({'first_owner': i, 'second_owner': second_owner, 'v': str(v),
                                     'm_direct_integral': str(actual_m), 'u': str(2 * root * v / m),
                                     'aBi_upper_safe': str(b), 'm_over_D': str(m / (2 * root)), 'H': False})
    birth = birth_observations(n, root, T, h, alpha, expK)
    probabilities = [F(1)] if n != 64 else [F(1, 2), F(1, 2)]
    schemes = [actual_scheme(n, root, T, h, P, source_visible, source_hidden, receiver, alpha,
                            probabilities, Hn, expK, birth, P == Lroot) for P in (5, Lroot)]
    assert F(schemes[0]['ledger']['T_res']) == F(schemes[1]['ledger']['T_res'])
    assert F(schemes[0]['ledger']['T_nu']) == F(schemes[1]['ledger']['T_nu'])
    return {'stage': stage, 'n': n, 'K': str(root), 'D': str(2 * root), 'a': '1', 'lambda': '1',
            'delta': str(DELTA), 'beta': str(BETA), 'gamma_new': str(GAMMA),
            'hidden_per_length_res_mass': str(h), 'Hn': iv(*Hn),
            'ceil_6K_Hn': {'input_interval': iv(*ceil_input), 'ceil_lower': ceil_lo, 'ceil_upper': ceil_hi,
                           'unique_certified': True}, 'Lroot': Lroot, 'T_source_length': T,
            'crosssection_volume_alpha': str(alpha), 'E_bounds': bounds_json(receiver), 'X': str(box_volume(receiver)),
            'sources': [{'name': name, 'bounds': bounds_json(s), 'volume': str(box_volume(s)),
                         'f_density': str(fd), 'nu_density': str(nd), 'cap_density': str(root), 'res_density': str(rd),
                         'f_mass': str(fd * box_volume(s)), 'nu_mass': str(nd * box_volume(s)),
                         'cap_mass': str(root * box_volume(s)), 'res_mass': str(rd * box_volume(s))}
                        for name, s, fd, nd, rd in (('visible', source_visible, f_visible_density, 1 / alpha + root, 1 / alpha),
                                                    ('hidden', source_hidden, f_hidden_density, h / alpha + root, h / alpha))],
            'source_ledger': {'W_f': str(Wf), 'W_nu': str(Wnu), 'W_cap': str(Wcap), 'W_res': str(Wres),
                              'Wcap_plus_Wres_equals_Wnu': True, 'nu_le_f': True},
            'Af_whole_receiver_bounds': iv(*Af), 'res_capture_b_whole_receiver': '1',
            'original_delta_low_traffic': '0', 'Gamma_dense_all_actual_pairs': '0',
            'dense_packets_global_closed_certificate': {'total_nonzero_packets_not_enumerated': 2 * T,
                'first_i_range': [0, T - 1], 'cell_v_visible': '1', 'cell_v_hidden': str(h),
                'macro_m_formula': 'ell_i(1+h), ell_i=min(T,i+3)-max(0,i-2)>=3',
                'minimum_macro_mass': str(3 * (1 + h)), 'all_packet_aBi_upper': '1',
                'all_packet_H_false_strict_residual': str(3 * (1 + h) - 2 * root),
                'source_once_coupon': str(2 * root * Wres), 'relevant_direct_integral_packets': relevant_packets},
            'F_captured_exact': str(F(1, 5 * (1 + h))), 'F_D_exact': '0',
            'old_f_positive_graph': {'positive_cells_analytic_count': 2 * T, 'edges_analytic_count': 13 * T - 24,
                'components': 1, 'actual_res_component_mass': str(Wres), 'exp_K': iv(*expK), 'old_heavy_certified': True,
                'Kcover_bounds': bounds_json(Kcover), 'f_tail_outside_K_exact': '0',
                'proof': 'Two adjacent positive rows along first indices 0..T-1; adjacent index cells connect; fixed index l_infinity distance<=3. Other cells source0 analytically; no full grid enumeration.'},
            'nu_label_probabilities': list(map(str, probabilities)), 'birth_observations': birth, 'schemes': schemes,
            'counts': {'physical_f_instances': 1, 'physical_source_slab_boxes': 2, 'pre_frozen_nu_labels': len(probabilities),
                       'scheme_states': 2, 'scheme_label_rows': sum(s['counts']['scheme_label_rows'] for s in schemes),
                       'positive_joint_pair_cells': sum(s['counts']['positive_joint_pair_cells'] for s in schemes)},
            'scope': 'Real I11-form heavy traffic in the stated dominating class, not a certified original FULL hard instance; root-period positive middle retained.'}


def run():
    records = [physical_case(4, 'pilot_positive_cross_boundary', 2),
               physical_case(16, 'known_heavy_structure_pressure', 11),
               physical_case(64, 'parameter_dimension_label_expansion', 1000)]
    counts = {key: sum(r['counts'][key] for r in records) for key in records[0]['counts']}
    counts.update({'additional_inputs_or_precision_refinements': 0, 'producer_execution_menu_passes': 1,
                   'shift_or_birth_corner_enumerations': 0})
    return {'round': 105, 'status': 'PASS', 'publication': 'PUBLIC independent two-slab physical mechanism; no private recipes',
            'logs': {'ln2': iv(*LOG2), 'ln_3_over_2': iv(*LOG15), 'positive_atanh_terms': 64,
                     'tail': '2*z^129/[129*(1-z^2)] fully charged'},
            'exp_series': {'positive_terms_j_0_through_63': 64, 'tail': 'next=K^64/64!; <=next/(1-K/65)'},
            'counts': counts, 'records': records,
            'scope': 'Exact true n-dimensional source/receiver partial-capture certificates, root-period source boundary price and honest heavy/middle terminals. No FULL, uniform contraction, Cp numerical validation or n-law fit.'}


if __name__ == '__main__':
    started = time.perf_counter()
    result = run()
    print(json.dumps(result, sort_keys=True, indent=2) + '\n', end='')
    print(json.dumps({'runtime_seconds_diagnostic': time.perf_counter() - started}), file=sys.stderr)
```
