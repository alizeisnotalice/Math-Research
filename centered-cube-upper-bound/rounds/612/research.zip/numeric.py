"""R612 identity and restricted reuse of R601 integer DP, no pilot or parameter scan."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
from math import comb
import json,sys,time,platform,hashlib,resource,zipfile
import sympy as sp
import flint
from flint import arb,ctx
START=time.perf_counter();ctx.prec=256
history_member_sha='4c9334e9193663d9e6c159c32dd5ff903ee5b5f8fda79dae86aaa54a49b3c36e'
hist=Path(sys.argv[2]) if len(sys.argv)>2 else None
if hist is not None:
 with zipfile.ZipFile(hist) as archive:history_source=archive.read('certificate.py')
 assert hashlib.sha256(history_source).hexdigest()==history_member_sha
def A(q):
 q=Q(q);return arb(q.numerator)/q.denominator
def iv(q):return {'lo_exact':str(q.lower().fmpq()),'hi_exact':str(q.upper().fmpq()),'display':q.str(32)}
def contains(v,lo,hi):return lo<=v<hi
# Half-open intervals make the identity pointwise; closed centered cubes agree a.e.
one_dim=[]
for t in [Q(0),Q(1,3),Q(1,2),Q(1)]:
 lo=(1-t)/2;hi=(1+t)/2
 points=sorted(set([Q(0),Q(1,4),Q(1,2),Q(3,4),Q(999,1000),lo,hi]))
 points=[v for v in points if 0<=v<1]
 for x in points:
  old=sum(contains(x+m,Q(-1,2),Q(1,2)) for m in range(-2,3))
  shell=sum(contains(x+m,Q(-1),Q(-1,2)) or contains(x+m,Q(1,2),Q(1)) for m in range(-2,3))
  actual=sum(contains(x+m,-(1+t)/2,(1+t)/2) for m in range(-2,3))
  assert old==shell==1 and actual==1+int(lo<=x<hi)
 one_dim.append({'t':str(t),'arc_halfopen':[str(lo),str(hi)],'boundary_points_checked':[str(x) for x in points],'old_periodization':'1','shell_periodization':'1','actual_interval_periodization':'[1+1_arc]/(1+t)','identity_exact':True})
s,t=sp.symbols('s t',real=True)
assert sp.expand((1-s)+s-1)==0
assert sp.expand(((1-s)+s)**2-1)==0
assert sp.cancel((1+t)/(1+t)-1)==0
# Restricted R601 DP: only odd family side2-j/D, all in[1,2].
def restricted(n,D,lam):
 allowed=[];minmargin=None
 for j in range(1,D+1):
  ks=[]
  for k in range(n+1):
   value=Q(2**(n-k)*D**n,(2*D-j)**n)
   if value<=lam:ks.append(k)
   else:minmargin=min(minmargin,value-lam) if minmargin is not None else value-lam
  allowed.append(ks)
 prev=[1]+[0]*n
 for ks in allowed:
  nxt=[0]*(n+1)
  for k in ks:nxt[k]=sum(comb(k,l)*prev[l] for l in range(k+1))
  prev=nxt
 return Q(D**n-prev[n],D**n),allowed,prev[n],minmargin
rows=[];n=32;lam=Q(5);L=10000
for D in [32,64,128]:
 p,allowed,bad,margin=restricted(n,D,lam)
 assert p>0 and margin>0
 eps=Q(1,10000*n*D);retained_coordinate=1-4*D*eps
 assert 0<retained_coordinate<1 and eps<Q(1,4*D)
 thickprob=p*retained_coordinate**n;assert thickprob>0 and eps<1
 cut_factor=Q(L-1,L)**n
 finite_L1=lam*cut_factor*thickprob
 geometry_pairs=0
 for bin_index in range(1,D+1):
  xmin=(Q(bin_index-1,D)+2*eps)/2;xmax=(Q(bin_index,D)-2*eps)/2
  for radius_index in range(1,D+1):
   radius=2-Q(radius_index,D);captured=0
   for atom in [-1,0,1,2]:
    inside=xmax-radius/2<=atom-eps and xmin+radius/2>=atom+eps
    outside=xmax+radius/2<=atom-eps or xmin-radius/2>=atom+eps
    assert inside != outside
    captured+=int(inside)
   assert captured==(2 if bin_index>radius_index else 1)
   geometry_pairs+=1
 assert finite_L1>0
 rows.append({'n':n,'D':D,'lambda':'5','side_menu':'2-j/D, j=1..D; no 2+j/D and no j/D family',
  'complement_allowed_counts':allowed,'total_cells':str(D**n),'complement_cells':str(bad),'receiving_probability_exact':str(p),'periodic_lambda_times_receiving_probability':iv(A(lam*p)),
  'minimum_strict_density_margin_exact':str(margin),'positive_thickness_halfwidth_exact':str(eps),'one_dimensional_bin_radius_capture_pairs_exactly_checked':geometry_pairs,'source_box_boundary_guard':'whole retained x-interval inclusion/exclusion for atoms -1,0,1,2; reflection and integer translation cover all receiver phases; farther sources cannot enter support','retained_per_coordinate_exact':str(retained_coordinate),'retained_all_coordinates_exact':str(retained_coordinate**n),'L1_boundary_factor_exact':str(cut_factor),'L1_source_mass_exact':str((2*L)**n),'L1_source':'f=F_epsilon*1_[-L,L]^n; F_epsilon is Z^n-periodic unit atoms convolved with uniform[-epsilon,epsilon]^n','L1_receiver':'[-L+1,L-1]^n',
  'finite_L1_receiving_ratio_lower_exact':str(finite_L1),'finite_L1_receiving_ratio_lower':iv(A(finite_L1)),
  'bridge_on_finite_interior':'P_(1,s)*f=1 for every s in[0,1/2], a.e.; since1<=lambda/2=5/2, every certified true-cube receiver is in low-bridge remainder',
  'finite_L1_lower_above_1':finite_L1>1,'finite_L1_lower_above_2':finite_L1>2,'finite_L1_lower_above_5_over_2':finite_L1>Q(5,2)})
out={'status':'PASS_PERIODIZATION_AND_R601_RESTRICTED_ODD_MENU_FINITE_L1_CERTIFICATE','one_dimensional_identity':one_dim,
 'general_periodic_identity':'For any Z^n-periodic nonnegative measure/density with period-cell mass W0, both old interval and full shell length1 periodize to1 a.e.; each coordinate-label block periodizes to1, so P_(1,s)*f=W0 for all s. Actual U_(1+t) periodization is product_i[1+1_{[(1-t)/2,(1+t)/2)}(x_i)]/(1+t)^n.',
 'nonL1_periodic_boundary':'Periodic nonzero f is not itself finite L1. Only the specified finite atomic and positive-thickness constructions are claimed as finite inputs.',
 'history':{'R601_archive_reference':'rounds/601/research.zip','optional_checked_archive':str(hist) if hist is not None else None,'member':'certificate.py','member_sha256':history_member_sha,'producer_read_original_archive':True,'reuse':'Same integer cumulative-count DP as archived R601; constraints keep ONLY odd side2-j/D >lambda. Old three-family probability is not reused. No pilot executed.','R512_reference':'rounds/512/research.zip!r512_numeric.md finite L1 periodic-grid thickening precedent; old selector raw/square certificates are not claimed to be this bridge identity.'},
 'rows':rows,'thickening_proof':'First form periodic F_epsilon from unit atoms and uniform halfwidth-epsilon boxes; then cut f=F_epsilon 1_[-L,L]^n. Integer L gives exactly (2L)^n cell masses, including partial source boxes across cut boundaries. For receiver[-L+1,L-1]^n every bridge/cube source coordinate support has halfwidth<=1, so finite and periodic convolutions agree a.e. In u_i=2dist(x_i,Z), delete width2epsilon at both ends of each length1/D bin. Each bin retains exactly1/D-4epsilon, so every DP assignment box has the same factor(1-4D epsilon)^n. All source boxes are then captured fully or excluded for every side2-j/D, retaining the strict original density margin. Exact receiving-subset ratio is lambda p_D(1-1/L)^n(1-4D epsilon)^n.',
 'scope':'Confirms bridge low-value remainder includes this broad periodic true-cube difficulty. Restricted historical menu gives a receiving-subset lower bound, not full halo volume, no optimized pi, no general upper bound or counterexample to all recovery methods.',
 'versions':{'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__},'interpreter':sys.executable,'command':[sys.executable,*sys.argv],'arb_bits':ctx.prec,'processes':1,'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
output=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/ccu_r612_periodic.json');output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'rows':[{'D':r['D'],'periodic':r['periodic_lambda_times_receiving_probability']['display'],'finite_L1':r['finite_L1_receiving_ratio_lower']['display']} for r in rows],'seconds':out['runtime_seconds'],'script_sha256':out['script_sha256']},indent=2))
