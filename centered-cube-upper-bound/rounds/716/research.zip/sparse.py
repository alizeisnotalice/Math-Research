"""R716 actual A-source violated-coordinate distribution on real R715 owners.

All generated local files have prefix sparse. Arb256/384, plus a remote
Decimal110 aggregate crosscheck. No coordinate dictionary restriction is used.
"""
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys
from flint import arb,ctx

BASE=Path(__file__).resolve().parent
history={'__name__':'sparse_readonly_history'}
exec(compile((BASE/'sparse_history.py').read_text(),str(BASE/'sparse_history.py'),'exec'),history)


def st(x):return x.str(38)


def floor_unique(x):
    value=x.floor().unique_fmpz();assert value is not None
    return int(value)


def calculate(b,K,bits):
    raw=history['calculate'](b,K,bits);ctx.prec=bits;A=arb
    n=1<<b;a=32*n;root=1<<(b//2);l2=A(2).log();t=A(root)/l2
    g=(-A(2)/a).log1p();W=A(raw['raw_shell_fraction_W']);Wcond=8*W
    JA=int(raw['JA']);eA=root-JA*W
    RA=A(raw['A_max_radius']);Amin=A(raw['A_min_radius'])
    full=-(-JA*W/t).expm1()
    partial=(-JA*W/t).exp()*(-(-eA/t).expm1())
    assert (full+partial-A('.5')).contains(0)
    assert A(raw['A_expanded_parent_first_axis_lower_min'])>A('.125')
    # The first coordinate is outside EVERY original A_i^+ on EVERY real owner.
    # Remaining coordinates are independent digit draws before conditioning.
    lower_digits=max(0,floor_unique(A(a)/2*(A('.25')/RA-A(4)/n)-1))
    upper_digits=-floor_unique(-A(a)/2*(A('.75')/Amin-A(4)/n))
    p_lo=A(lower_digits)/a;p_hi=A(upper_digits)/a;N=n-1
    mu_lo=N*p_lo;mu_hi=N*p_hi
    assert 0<p_lo<p_hi<A('.5')
    tilt=(W/t).exp()
    median_lower=n//10;median_upper=n//2
    low_log=-(mu_lo-(median_lower-1))**2/(2*mu_lo)
    upper_threshold=A(median_upper)
    assert upper_threshold>mu_hi
    high_log=-upper_threshold*(upper_threshold/mu_hi).log()+upper_threshold-mu_hi
    low_weight_fraction=2*(partial+full*tilt*low_log.exp()/Wcond)
    high_weight_fraction=2*(partial+full*tilt*high_log.exp()/Wcond)
    assert low_weight_fraction<A('.5') and high_weight_fraction<A('.5')
    sparse_rows=[]
    original_high=A(raw['original_A_median_high_weight_lower_every_owner_point'])
    for cap in [b//4,b,b*b]:
        assert cap<mu_lo
        logtail=-(mu_lo-(cap-1))**2/(2*mu_lo)
        mass_upper=partial+full*tilt*logtail.exp()/Wcond
        surviving=original_high-mass_upper
        assert mass_upper<A('.01') and surviving>A('.49')
        sparse_rows.append({'allowed_arbitrary_violated_coordinates':cap,
                            'unconditioned_lower_tail_log_upper':st(logtail),
                            'capturable_A_weight_upper_at_every_owner_point':st(mass_upper),
                            'capturable_fraction_of_all_A_weight_upper':st(2*mass_upper),
                            'original_high_weight_not_captured_lower':st(surviving),
                            'shared_coordinate_dictionary_needed':False})
    # Mean over TRUE receiver Lebesgue measure, not point sampling. Uniform
    # coordinate |x| in[1/4,3/4] has mean1/2. Midpoint discretization costs<=1/a.
    # Under first-coordinate restriction and boundary, for one other axis:
    # p_boundary=[p*(1-T)+T/a]/(8W), T=(1-8/a)*rho^(n-2).
    T=(1-A(8)/a)*((n-2)*g).exp()
    avg_p_lo=A('.25')/RA-A(2)/n-A(1)/a
    avg_p_hi=A('.25')/Amin-A(2)/n+A(1)/a
    conditional_lo=(avg_p_lo*(1-T)+T/a)/Wcond
    conditional_hi=(avg_p_hi*(1-T)+T/a)/Wcond
    mean_fraction_lo=(1+2*full*(-W/t).exp()*N*conditional_lo)/n
    mean_fraction_hi=(1+2*full*tilt*N*conditional_hi+2*partial*N)/n
    assert 0<mean_fraction_lo<mean_fraction_hi<1
    logVT=A(raw['VT']).log();logratio=A(raw['log_D_over_VT'])
    # Same original A witness for every row, source budget once per source.
    log_source_coefficient=logVT-n*l2-n*Amin.log()
    log_actual_ratio=-l2-logratio
    assert log_actual_ratio<=log_source_coefficient
    return {'b':b,'n':f'2^{b}','K':K,'precision_bits':bits,
            'A_source_count_symbolic':'N=sqrt(n)*a^n','A_original_pool_total_weight_exact':'1/2',
            'all_actual_owner_points_first_axis_violated':True,
            'other_axis_uniform_violation_probability_lower':st(p_lo),
            'other_axis_uniform_violation_probability_upper':st(p_hi),
            'theta_weighted_median_violated_axis_count_lower':str(median_lower),
            'theta_weighted_median_violated_axis_count_upper':str(median_upper),
            'theta_fraction_below_median_lower_upper':st(low_weight_fraction),
            'theta_fraction_above_median_upper_upper':st(high_weight_fraction),
            'true_receiver_volume_average_violation_axis_fraction_lower':st(mean_fraction_lo),
            'true_receiver_volume_average_violation_axis_fraction_upper':st(mean_fraction_hi),
            'partial_A_layer_actual_weight':st(partial),'sparse_tests':sparse_rows,
            'VT':raw['VT'],'D':raw['D'],'V':raw['V'],
            'log10_original_normalized_excess_lower':raw['log10_original_normalized_excess_lower'],
            'log10_VT_over_4sqrt_n_D':raw['log10_VT_over_4sqrt_n_D'],
            'log10_direct_per_source_payment_coefficient':st(log_source_coefficient/A(10).log()),
            'log10_actual_origin_high_upper_VT_half_over_D':st(log_actual_ratio/A(10).log()),
            '_values':(p_lo,p_hi,mean_fraction_lo,mean_fraction_hi,low_weight_fraction),
            '_remote_values':[float(p_lo),float(p_hi),float(mean_fraction_lo),float(mean_fraction_hi),float(2*partial)]}


REMOTE=r'''
from decimal import Decimal as D,localcontext
import json,socket,sys
with localcontext() as c:
 c.prec=110
 rows=[]
 for b in [32,48,64]:
  for K in [4,8,16]:
   n=1<<b;a=32*n;root=1<<(b//2);l2=D(2).ln();t=D(root)/l2
   g=(1-D(2)/a).ln();lh=(1+D(1)/a).ln();Q=(D(n-1)*g).exp()
   W=(1-Q)/8+Q/a;wc=8*W;JA=int(D(root)/W);JB=int(D(K*root)/W)
   lRB=lh-D(JB)*g;lAmin=lRB+l2/n+lh;lRA=lAmin-D(JA)*g
   RA=lRA.exp();Amin=lAmin.exp()
   lo=max(0,int(D(a)/2*(D('.25')/RA-D(4)/n)-1))
   q=D(a)/2*(D('.75')/Amin-D(4)/n);hi=int(q.to_integral_value(rounding='ROUND_CEILING'))
   plo=D(lo)/a;phi=D(hi)/a
   full=1-(-D(JA)*W/t).exp();eA=D(root)-JA*W
   partial=(-D(JA)*W/t).exp()*(1-(-eA/t).exp())
   T=(1-D(8)/a)*(D(n-2)*g).exp()
   avglo=D('.25')/RA-D(2)/n-D(1)/a;avghi=D('.25')/Amin-D(2)/n+D(1)/a
   clo=(avglo*(1-T)+T/a)/wc;chi=(avghi*(1-T)+T/a)/wc
   mlo=(1+2*full*(-W/t).exp()*D(n-1)*clo)/n
   mhi=(1+2*full*(W/t).exp()*D(n-1)*chi+2*partial*D(n-1))/n
   rows.append({'b':b,'K':K,'lower_digits':str(lo),'upper_digits':str(hi),'values':[str(plo),str(phi),str(mlo),str(mhi),str(2*partial)]})
 print(json.dumps({'host':socket.gethostname(),'python':sys.version,'backend':'Decimal110 independent aggregate check','rows':rows}))
'''


def main():
    rows=[]
    for b in [32,48,64]:
        for K in [4,8,16]:
            lower=calculate(b,K,256);higher=calculate(b,K,384)
            for x,y in zip(lower['_values'],higher['_values']):assert x.overlaps(y)
            del higher['_values'];rows.append(higher)
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B -']
    run=subprocess.run(command,input=REMOTE,text=True,capture_output=True,timeout=40)
    remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
    if run.returncode==0:
        remote['result']=json.loads(run.stdout)
        for local,other in zip(rows,remote['result']['rows']):
            assert local['b']==other['b'] and local['K']==other['K']
            for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-14,abs(x)*1e-12)
        remote['crosscheck_passed']=True
    else:remote['stdout']=run.stdout
    for row in rows:del row['_remote_values']
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'history_source_sha256':hashlib.sha256((BASE/'sparse_history.py').read_bytes()).hexdigest(),
            'rows':rows,'remote':remote,
            'precise_distribution':['m_i(x)=#{k:x_k is outside projection_k((1+4/n)A_i)} for ACTUAL original A first-half sources and ACTUAL receiving x. Source sampling law is theta_i/(1/2), not a synthetic uniform pool.',
                                    'The first coordinate is always violated. Other midpoint source digits are independent before the actual first-axis restriction and boundary conditioning. Their probabilities are uniformly bounded by the certified p_lo,p_hi.',
                                    'Conditioning on the first-axis last1/8 domain changes boundary probability to8W; lower/upper binomial tail bounds pay1/(8W), and actual full-layer theta variation pays exp(W/t).',
                                    'The entire actual partial last A layer is conservatively charged as bad. Therefore reported tail bounds may be far above the true tails, but remain valid uniformly over every real owner point.',
                                    'Median bounds are theta-weighted and uniform over all receiving points. The mean-fraction bounds additionally integrate over the actual uniform Lebesgue rectangle tiled by the disjoint owners.'],
            'direct_payment_scope':['For caps b/4,b,b^2, a source can choose its own arbitrary violated-coordinate locations. This is more permissive than requiring one shared coordinate dictionary; nevertheless the capturable original A weight at physical x is tiny, and almost1/2 original high weight remains.',
                                    'This only tests direct physical receiving locations. It does not rule out shifted spatial destinations or a general allocation theorem.',
                                    'The same genuine original A witness can be used for every row. For each A source, its total receiving charge is<=theta_i*VT<=VT/(2^n*Amin^n)*d_i*theta_i. Source budgets are used once.',
                                    'Thus this finite family is directly payable by its huge original D despite failure of sparse-coordinate coverage at x. The exact per-source coefficient and original normalization are reported.'],
            'numerical_scope':['Nine real histories b32,48,64 and K4,8,16, local Arb256/384 enclosures and independent MacBook Decimal110 aggregates. No finite-coordinate arrays or Monte Carlo replace the actual source grid.',
                               'The imported sparse_history.py is an unchanged local copy of R715 two_centers.py; no dependency on another temporary directory is needed.',
                               'All local files have prefix sparse. No Git changes, remote files or remaining processes.']}
    output=BASE/'sparse.json';output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'remote_exit':run.returncode,'remote_crosscheck':remote.get('crosscheck_passed',False),
                      'rows':[{k:r[k] for k in ['b','K','theta_weighted_median_violated_axis_count_lower','true_receiver_volume_average_violation_axis_fraction_lower','true_receiver_volume_average_violation_axis_fraction_upper']} for r in rows]},indent=2))


if __name__=='__main__':main()
