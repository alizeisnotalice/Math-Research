"""Finite, exact combinatorial check of the weighted incidence deletion."""
from itertools import product
from random import Random
from hashlib import sha256
import json

def check(mask, weights, volumes, column_cap, row_cap, exhaustive=False):
    rows = len(volumes)
    columns = len(weights)
    adjacency = [{i for i in range(columns) if mask >> (j*columns+i) & 1}
                 for j in range(rows)]
    def mass(R, C):
        return sum(volumes[j]*sum(weights[i] for i in adjacency[j]&C) for j in R)
    def run(reverse):
        R, C = set(range(rows)), set(range(columns))
        while True:
            low_rows = [j for j in R if sum(weights[i] for i in adjacency[j]&C)<=row_cap]
            low_cols = [i for i in C if sum(volumes[j] for j in R if i in adjacency[j])<=column_cap[i]]
            if not low_rows and not low_cols:
                break
            if low_rows and (not low_cols or not reverse):
                R.remove(low_rows[-1])
            else:
                C.remove(low_cols[0])
        return R,C
    R,C=run(False)
    assert (R,C)==run(True)
    old=mass(set(range(rows)),set(range(columns)))
    bill=row_cap*sum(volumes)+sum(w*b for w,b in zip(weights,column_cap))
    assert old<=mass(R,C)+bill
    if exhaustive:
        for a,b in product(range(1,1<<rows),range(1,1<<columns)):
            r={j for j in range(rows) if a>>j&1}
            c={i for i in range(columns) if b>>i&1}
            if all(sum(weights[i] for i in adjacency[j]&c)>row_cap for j in r) and all(sum(volumes[j] for j in r if i in adjacency[j])>column_cap[i] for i in c):
                assert r<=R and c<=C
    return mass(R,C)

rng=Random(716)
results=[check(mask,[2,1,3],[1,3,2],[2,1,2],2,True) for mask in range(512)]
for j in range(1024):
    nr=rng.randrange(2,15)
    nc=rng.randrange(2,12)
    results.append(check(rng.getrandbits(nr*nc),[rng.randrange(1,8) for _ in range(nc)],
                         [rng.randrange(1,10) for _ in range(nr)],
                         [rng.randrange(1,20) for _ in range(nc)],rng.randrange(1,15)))
print(json.dumps(dict(exhaustive_graphs=512, additional_graphs=1024,
    positive_remaining=sum(v>0 for v in results),
    witness=sha256(str(results).encode()).hexdigest())))
