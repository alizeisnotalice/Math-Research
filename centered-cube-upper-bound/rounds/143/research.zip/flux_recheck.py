from pathlib import Path
import json,hashlib,sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
mp.mp.dps=70
root=Path(__file__).resolve().parent;p=root/'numeric_flux.json';src=root.parent/'centered_cube_round142_20261015/numeric_receiver.json'
d=json.loads(p.read_text());rec=json.loads(src.read_text());summary={}
for cid,c in d['cases'].items():
 T=[[mp.mpf(x) for x in row] for row in c['time_kernels']['matrix_T_decimal']];worst=mp.mpf(0);reverse=positive=0
 assert len(c['records'])==2317
 for row in c['records']:
  raw=rec['cases'][cid]['records'][row['id']];f=[mp.mpf(str(raw['rho'][i])) if raw['good'][i] else mp.mpf(0) for i in range(6)]
  plus=mp.fsum(max(f[i]-f[j],0)*T[i][j] for i in range(6) for j in range(6));minus=mp.fsum(max(f[i]-f[j],0)*T[j][i] for i in range(6) for j in range(6))
  for val,key in [(plus,'Dplus'),(minus,'Dminus')]:
   err=abs(val-mp.mpf(row[key]))/max(1,abs(val));worst=max(worst,err);assert err<mp.mpf('1e-35')
  if row['accepted_positive'] and row['main_gates_pass']:
   positive+=1;reverse+=minus>0
   assert mp.mpf(row['accepted_internal'])<=plus*(1+mp.mpf('1e-10'))
 summary[cid]={'checked_rows':len(c['records']),'positive_main':positive,'positive_main_with_reverse':reverse,'max_normalized_difference':mp.nstr(worst,15)}
result={'input_sha256':{str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in [p,src]},'precision':70,'method':'Independent recomputation of both all-pair fluxes from original saved receiver rho/good and analytic matrix; no sampling or quadrature; matrix primitive proof audited in R142.','cases':summary,'status':'PASS'}
(root/'flux_recheck.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
