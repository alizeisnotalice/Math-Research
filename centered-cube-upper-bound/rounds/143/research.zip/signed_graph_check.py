"""Read-only posthoc decomposition of the original Psi graph on saved main-positive rows.
No new sampling or integration. Frozen six-source model has Z_t all six.
"""
from pathlib import Path
import json,hashlib,sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
sys.set_int_max_str_digits(0)
import mpmath as mp
mp.mp.dps=100
r=Path(__file__).resolve().parent
fp=r/'numeric_flux.json';rp=r.parent/'centered_cube_round142_20261015/numeric_receiver.json';sp=r.parent/'centered_cube_round136_20261014/active_traffic_v2.json'
f=json.loads(fp.read_text());receivers=json.loads(rp.read_text());sources=json.loads(sp.read_text());out={}
assert f['status'].startswith('completed'),f['status']
def m(v):return mp.mpf(str(v))
def rat(x):return mp.mpf(x['numerator'])/mp.mpf(x['denominator'])
for cid,c in f['cases'].items():
 orig=next(c for c in sources['cases'] if c['id']==cid);rec=receivers['cases'][cid]['records'];matrix=c['time_kernels']['matrix_T_decimal'];T=[[m(v) for v in row] for row in matrix]
 psi=[[bool(orig['pairs'][i*6+j]['Psi']) for j in range(6)] for i in range(6)];end=[rat(v)+rat(w) for v,w in zip(c['time_kernels']['endpoint_coefficients'],c['time_kernels']['internal_jump_coefficients'])];rows=[]
 for fr in c['records']:
  if not(fr['main_gates_pass'] and fr['accepted_positive']):continue
  rr=rec[fr['id']];good=rr['good'];pairs=[(i,j) for i in range(6) for j in range(6) if good[i] and not good[j]]
  plain=mp.fsum(T[i][j] for i,j in pairs if psi[i][j]);negative=mp.fsum(T[j][i] for i,j in pairs if psi[i][j]);missing=mp.fsum(T[i][j]-T[j][i] for i,j in pairs if not psi[i][j]);endpoint=mp.fsum(end[i] for i in range(6) if good[i]);accepted=m(fr['accepted_internal']);suppression=plain-accepted;net=accepted-negative
  residual=net-(endpoint-missing-suppression)
  assert abs(residual)<mp.mpf('1e-35')
  assert suppression>=-mp.mpf('1e-20')
  rows.append(dict(id=fr['id'],distribution=fr['distribution'],stage=fr['stage'],negative_original=mp.nstr(negative,40),missing_Psi_signed=mp.nstr(missing,40),unweighted_good_endpoint_with_saved_jump=mp.nstr(endpoint,40),positive_suppression=mp.nstr(suppression,40),signed_actual=mp.nstr(net,40),identity_abs_residual=mp.nstr(abs(residual),10)))
 out[cid]={'rows':rows,'positive_main_count':len(rows),'negative_nonzero_count':sum(m(x['negative_original'])>0 for x in rows),'missing_Psi_nonzero_count':sum(m(x['missing_Psi_signed'])!=0 for x in rows),'scope':'Finite all-six Z_t model; no deletion terms represented.'}
result={'input_sha':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [fp,rp,sp]},'scope':'Posthoc graph decomposition; does not prove uniform geometric control. Coefficients from original analytic diagnostic only.','cases':out}
(r/'signed_graph_check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print({cid:{k:v for k,v in c.items() if k!='rows'} for cid,c in out.items()})
