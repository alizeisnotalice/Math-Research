# R143 independent responsibility audit

Audited source: source_responsibility.md, SHA-256
8921f81687d29e3759646552855ed443e07545aa6904c082c4db0fea3517e26a.
The scalar calculation below was checked independently before reading that source. The source mapping was then checked against R142 joint_receiver_common_alpha.md CA1–CA2 and the JR8 source-weight contract in joint_receiver_geometry.md.

**Verdict:** SR6–SR7 and SR14 are correct on their stated finite positive rows. The original reserve, posterior weights, score integration, and hard-source integration map correctly. The manuscript does not establish a root-order payment. Its endpoint/domain statements should be made explicit as described in the last section.

## 1. Independent scalar and marginal proof

Let \(\eta\) be a finite nonnegative measure of mass \(R\), and let \(j\,d\nu\) be a probability measure. Thus \(j\ge0\), \(\int j\,d\nu=1\), and \(j\) has a finite representative \(\nu\)-almost everywhere. Work first with \(0<R<\infty\) and measurable \(B\in[0,\infty]\). Set

\[
\ell(v)=\int_0^1 1_{\{\tau Rj(v)<B(v)\}}\,d\tau.
\]

For \(j(v)>0\),
\[
\ell(v)=\min\{1,B(v)/(Rj(v))\}.
\]
The strict threshold has no effect on this length, including \(B=Rj\). If \(j=0\), then \(\ell=1\) for \(B>0\), and \(\ell=0\) for \(B=0\); all these rows have zero \(j\,d\nu\) measure.

Tonelli gives, for measurable receiver and source sets \(V\) and \(A\),
\[
\Gamma(V)=R\int_V j(v)\ell(v)\,d\nu(v)
=\int_V \min\{B(v),Rj(v)\}\,d\nu(v),
\]
\[
\Gamma(A)=\eta(A)c,\qquad c=\int j(v)\ell(v)\,d\nu(v)\le1.
\]
These are measure equalities, not merely total-mass identities. The capacity conclusion applies to every source set: \(\Gamma(A)\le\eta(A)\). In particular, the auxiliary reserve atom is charged at most its assigned mass. The formula for \(c\) should use \(\ell\), or interpret the quotient formula only on \(j>0\), to avoid \(0/0\).

For \(R=0\), \(\eta=0\) and \(\Gamma=0\). There is no need to define a quotient in the formula for \(c\); choosing \(c=0\) is sufficient.

If \(\lambda(v)\ge0\), the weighted receiver marginal is
\[
\lambda(v)\min\{B(v),Rj(v)\}\,d\nu(v).
\]
Its source marginal is
\[
\kappa\,d\eta(a),\qquad
\kappa=\int\lambda(v)j(v)\ell(v)\,d\nu(v)\in[0,\infty].
\]
There is no bound \(\kappa\le c\) or \(\kappa\le1\) without an additional bound on \(\lambda\). Integrating outer nonnegative weights does not restore such a bound.

## 2. Independent residual/tail proof

Allow outer variables, a nonnegative measure \(\mu\), and corresponding \(R,j,B,\lambda\). For finite \(R\), define
\[
\Xi=B/j\quad(j>0),\qquad
\Xi=\infty\quad(j=0,\ B>0),\qquad
\Xi=0\quad(j=B=0).
\]
Fix \(0<\varepsilon<1\), and write
\[
F=\{\Xi>R/(1-\varepsilon)\}.
\]
On a row with \(0<B<\infty\), the condition \(F\) is equivalent to \(Rj<(1-\varepsilon)B\), including \(j=0\). Therefore the pointwise inequalities are
\[
\varepsilon B1_F
\le (B-Rj)_+
\le \varepsilon B+(1-\varepsilon)B1_F.
\]
For \(B=0\), all three quantities vanish. For \(B=\infty\) and finite \(Rj\), the residual and the upper-bound demand are infinite, and \(F\) holds, so the same extended inequalities hold.

Multiplication by \(\lambda\) and Tonelli prove
\[
\boxed{\varepsilon E_\varepsilon\le L
\le\varepsilon D+(1-\varepsilon)E_\varepsilon,}
\]
with exactly the definitions in the requested candidate. Nonnegative extended integrals use the usual zero-weight convention; no expression \(D-S\) or \(\infty-\infty\) is needed. When \(D<\infty\), both \(L\) and \(E_\varepsilon\) are finite. When \(D=\infty\), the upper inequality may be uninformative but remains valid.

For \(R=0\), every row of positive demand belongs to \(F\); hence \(L=D=E_\varepsilon\), with extended equality allowed. The strict threshold puts equality \(\Xi=R/(1-\varepsilon)\) into the small-tail side, where the residual is exactly \(\varepsilon B\) when \(B>0\). The open range \(0<\varepsilon<1\) avoids undefined endpoint thresholds; endpoint statements should be given separately.

The nonnegative identity
\[
(B-Rj)_++\min\{B,Rj\}=B
\]
also proves \(L+S=D\), for \(S=\int d\mu\int\lambda\min\{B,Rj\}\,d\nu\), on finite-reserve rows. For \(B=\infty\), its two summands are respectively infinite and finite almost everywhere in this domain.

The inequalities prove precisely the source's claimed consequences: \(L\le C\) implies \(E_\varepsilon\le C/\varepsilon\); a budget for \(D\) together with \(E_\varepsilon\le C\) supplies \(L\le\varepsilon D+(1-\varepsilon)C\). A bound \(L\le\varepsilon D+C\) alone does not imply \(E_\varepsilon\le C/\varepsilon\).

## 3. Audit of the original-source mapping

CA1 gives, on the legal receiver domain,
\[
d_x(a)=DK_0(x-a)-U_x(a)\ge0,\qquad
R_0(x)=D(q(x)-Q_0(x))\ge0,
\]
\[
R(x)=R_0(x)+\int d_x(a)\,d\nu(a),\qquad
\alpha(x)=R(x)/Q_J(x).
\]
Consequently \(\eta_x=d_x\,\nu+R_0\delta_\star\) has exactly the required mass \(R(x)\). This uses the original common reserve once; it creates no reserve indexed independently by \(v,u\), or hard source \(z\).

With \(j_x(v)=J(x-v)/Q_J(x)\) and \(0<Q_J(x)<\infty\),
\[
\int j_x\,d\nu=1,\qquad \alpha(x)J(x-v)=R(x)j_x(v).
\]
On \(0<TA_v<\infty\), nonnegativity of \(Rj\) gives
\[
\rho_v(x)
=\frac{[TA_v-DK_0(x-v)-R(x)j_x(v)]_+}{TA_v}
=\frac{[B_x(v)-R(x)j_x(v)]_+}{TA_v}.
\]
Thus SR2's \(B_x\), \(j_x\), and reserve substitution are correct.

JR8 retains the nonnegative score
\(\delta_t(v,u)=[k_t(v)-k_t(u)]_+\)
and the source weight
\[
b_t(v)b_t(u)\,d\nu(v)d\nu(u)d\nu(z),\qquad
b_t(v)=1_{Z_t}(v)w_t(y,v)/e_t(y).
\]
Since \(\nu,Z_t,w_t,e_t,\Pi_t\) are fixed in the receiver integral and do not depend on the hard source \(z\), integration over \(u\) gives exactly
\[
\sigma_t(v)=\int\delta_t(v,u)b_t(u)\,d\nu(u).
\]
The two denominators remain: one \(e_t^{-1}\) in \(b_t(v)\), and one in \(\sigma_t(v)\). Neither denominator disappears when the \(u\) variable is integrated out. The bound \(\sigma_t\le n\) uses the original \(\delta_t\le n\), but SR4 correctly keeps the actual \(\sigma_t\).

After legally deleting the additional positive gates, integration over \(z\) gives the original hard-source integral
\[
H(x)=\int h_{R_{\rm scale}(x)}(x-z)\,d\nu(z).
\]
It gives no posterior normalization for \(z\), and no second application of a hard cap. Replacing the original receiver factor \(1/q(x)\) by \(1/q_-\) is an upper relaxation because \(q(x)\ge q_->0\). Therefore
\[
\lambda_x(v)=\frac{b_t(v)\sigma_t(v)1_{\rm good}(x,v)}{TA_v},
\qquad
d\mu(x)=\frac{1_\Omega(x)p_xH(x)}{q_-}\,dx
\]
are the correct weights of this relaxed positive expression.

The integrations defining \(\sigma_t\) and \(H\) require that any retained extra gate depending on \(u\) or \(z\) has already been legally deleted. Otherwise it must remain inside the relevant integral. The source explicitly states this condition and does not claim the relaxed quantity retains the removed high/history/qualification gates. The good gate is allowed to remain because its stated dependence is \((x,v)\).

SR9–SR10 correctly record the still-unpaid weighted source marginal. There is one \(1/q_-\), the actual \(H\), the actual posterior/score weights, and the later original \(\mathbb E\sum_{V,j}\int d\beta_V(y)\int dt/t\) and cell/level fees. There is no derivation of a \(C\sqrt n\,\mathrm{polylog}(n)W_\beta\) bound from these identities.

## 4. Precise domain and wording corrections

1. **Name the relaxed quantity explicitly.** SR4 is an equality for the positive expression after gate deletion and \(q^{-1}\le q_-^{-1}\). To prevent an equality being read across this relaxation, use: “Define the relaxed fixed-row quantity \(\mathcal L\) by SR4; the original positive traffic is bounded above by the corresponding original outer sum/integral of \(\mathcal L\).”

2. **State finite normalization conditions.** In SR2–SR3 use \(0<Q_J(x)<\infty\) and \(0<TA_v<\infty\) on the rows where the quotients are formed. \(Q_J=0\), \(A_v=0\), and \(e_t=0\) retain the original zero-traffic conventions; they are not evaluated by dividing by zero. The finite positive-row setup already supplies these conditions, but \(Q_J>0\) by itself would not guarantee that \(j_x\,d\nu\) is a probability if \(Q_J=\infty\).

3. **Keep the layer-cake domain positive in \(j\).** SR11–SR12 are correct for the original strictly positive \(J\) on these normalized rows. A generic probability density \(j\) can vanish. In that extension, \(M=\lambda j\,\nu\) misses demand on \(j=0\), even if \(\Xi=\infty\) is assigned there. The exact formula then needs the additional term \(\int d\mu\int_{\{j=0\}}\lambda B\,d\nu\). The scalar SR14 proof above does cover zero \(j\). This is not a defect of SR12 under the source's explicitly positive-soft-kernel restriction.

4. **Do not extend the finite-reserve coupling implicitly.** SR6–SR10 are proved for finite \(R\). For \(R=\infty\), \(j>0\), and finite \(B\), the residual is indeed zero. If SR8 is stated on such rows too, define their suppression directly as \(\lambda B\), equivalently by the receiver expression \(\lambda\min\{B,Rj\}\); do not define it through a nonexistent finite-\(R\) \(\Gamma_x\). No source-capacity marginal from SR9 is asserted there. Rows with both infinite demand and infinite reserve require a separate original limiting definition and are outside the displayed scalar subtraction formulas.

5. **Preserve the original normalized source throughout truncation.** The limit statement in SR5 is correct when truncating only integration domains or nonnegative integrands while fixing the original \(\nu,e,Q_J,R,b,\sigma\), and original kernels. Replacing \(\nu\) by truncated source measures and recomputing \(e,Q_J,R\) does not give the monotonicity claimed for fixed normalized integrands. No such replacement is justified by these proofs.

These are domain/wording clarifications, not a new payment estimate. The independently verified objects are the finite shared-reserve coupling, its exact weighted and unweighted marginals, and the complete-constant residual tail inequalities.

## 5. Final revision binding and disposition

Final source SHA-256 verified from disk:
919be407293df1d226030315b9944b373d1d50a4ee7840cecfad318b0fe222a9.

This follow-up checked only implementation of the five requested revisions; it did not repeat the already-passed mathematical audit.

1. **Implemented.** SR4 now explicitly defines the relaxed fixed-row quantity after gate deletion and the \(q^{-1}\) relaxation, and separately states that original positive traffic is bounded above by its original outer integral.
2. **Implemented.** SR2 now requires finite positive \(Q_J\), \(TA_v\), and original positive \(J\) on quotient rows; SR1 requires finite positive \(e\). Zero rows use their original zero-traffic conventions, and infinite normalization rows are excluded from these quotient formulas.
3. **Implemented.** SR11–SR12 now explicitly restrict the displayed layer-cake identity to positive \(j\) and state the missing \(\lambda B\) term on \(j=0\) for a generic-density extension.
4. **Implemented.** SR6–SR10 now restrict the source-capacity coupling to finite \(R\), set zero-reserve conventions without division, and define suppression directly at the receiver for infinite reserve with finite demand. They explicitly withhold SR9–SR10 source-capacity claims on those infinite-reserve rows and exclude \(B=R=\infty\) from the scalar subtraction domain.
5. **Implemented.** SR1 and SR5 now fix the original normalized source quantities throughout domain/integrand truncation, distinguish pre-collapse approximation of \(u,z\) integrals from their fixed \(\sigma,H\) values, and forbid re-normalization from a truncated source.

**Final disposition:** all five requested revisions are implemented in the source bound to the SHA above. The prior finite-domain correctness verdict stands; no remaining correction is identified within this follow-up scope. This disposition adds no root-order payment claim.
