#!/usr/bin/env python3
"""Analytic all-pair forward/reverse flux on existing receivers; no sampling/quadrature."""
import sys,json,hashlib,time,datetime,traceback
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
sys.set_int_max_str_digits(0)
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'numeric_flux.json'
SRC=ROOT.parent/'centered_cube_round136_20261014/active_traffic_v2.json'
REC=ROOT.parent/'centered_cube_round142_20261015/numeric_receiver.json'
ORACLE=ROOT.parent/'centered_cube_round142_20261015/time_primitive_check.json'
EXPECTED={SRC:'1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de',REC:'c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55',ORACLE:'44758cfaba246b3fa8ed28ef05aa9919c6b6db58cfb3f7c99a530e457eff23e9'}
def fr(x):return F(str(x))
def jf(x):return F(int(x['numerator']),int(x['denominator']))
def fj(x):return dict(numerator=str(x.numerator),denominator=str(x.denominator))
def m(x):return mp.mpf(x.numerator)/x.denominator if isinstance(x,F) else mp.mpf(x)
def dec(x,dps=40):return mp.nstr(m(x),dps)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(out):OUT.write_text(json.dumps(out,ensure_ascii=False,separators=(',',':'))+'\n')
def quant(values):
 vals=sorted(m(x) for x in values)
 if not vals:return None
 return {str(p):dec(vals[min(len(vals)-1,int((len(vals)-1)*p))]) for p in [0,.5,.9,.99,1]}

def primitive(u,A,B,C):
 a,b,c=map(m,[A,B,C]);D=4*A*C-B*B;dd=m(D);P=a+b*u+c*u*u;v=2*c*u+b
 if D==0:
  h=b/(2*c);z=u+h
  return [-1/(3*c*c*z**3),(-1/z**2+2*h/(3*z**3))/(c*c),(-1/z+h/z**2-h*h/(3*z**3))/(c*c)]
 if D>0:t=mp.sqrt(dd);H=2/t*mp.atan(v/t)
 else:t=mp.sqrt(-dd);assert v>t;H=mp.log((v-t)/(v+t))/t
 I0=(2*c*H+v/P)/dd
 return [I0,-1/(c*P)-b/c*I0,a/c*I0-u/(c*P)]

def kernels(c,receiver):
 nu=list(map(jf,receiver['nu_exact']));segs=[];T=[[F(0) for _ in range(6)] for _ in range(6)];closed=[];all_fraction=True;per=[]
 for ss in c['score_segments']:
  lo,hi=map(fr,[ss['lo'],ss['hi']]);ks=ss['k'];cf=list(map(fr,ss['c']));levels=sorted(set(ks));assert [sum(fr(v)**2<lo*hi for v in a['thresholds']) for a in c['atoms']]==ks
  groups={k:sum(nu[i]*cf[i] for i in range(6) if ks[i]==k) for k in levels};Pi=[]
  for t in [lo,hi]:
   w=[cf[i]*t**(-ks[i]) for i in range(6)];e=sum(nu[i]*w[i] for i in range(6));assert e>0;Pi.append([nu[i]*w[i]/e for i in range(6)])
  segs.append(dict(lo=lo,hi=hi,k=ks,c=cf,groups=groups,Pi=Pi))
  if len(levels)==1:per.append(dict(levels=levels,zero_delta=True));continue
  if len(levels)==2:
   low,high=levels;d=high-low;A,B=groups[high],groups[low];z0,z1=lo**(-d),hi**(-d);factor=(z0-z1)/((A*z0+B)*(A*z1+B));assert factor>0
   for i in range(6):
    for j in range(6):
     if ks[i]>ks[j]:T[i][j]+=nu[i]*nu[j]*cf[i]*cf[j]*factor
   per.append(dict(levels=levels,factor_exact=fj(factor),groups_exact={str(k):fj(v) for k,v in groups.items()}))
  elif len(levels)==3:
   all_fraction=False;d=levels[1]-levels[0];assert levels==[0,d,2*d];A,B,C=[groups[k] for k in reversed(levels)];assert min(A,B,C)>0;values=[]
   for precision in [100,160]:
    with mp.workdps(precision):left=primitive(m(lo)**d,A,B,C);right=primitive(m(hi)**d,A,B,C);values.append([mp.nstr(v-w,precision) for v,w in zip(right,left)])
   with mp.workdps(160):
    highvals=list(map(mp.mpf,values[1]));lowvals=list(map(mp.mpf,values[0]));errs=[abs(v-w)/abs(v) for v,w in zip(highvals,lowvals)];assert max(errs)<mp.mpf('1e-80') and min(highvals)>0
    for i in range(6):
     for j in range(6):
      if ks[i]>ks[j]:idx={(2,1):0,(2,0):1,(1,0):2}[(levels.index(ks[i]),levels.index(ks[j]))];T[i][j]=m(T[i][j])+m(nu[i]*nu[j]*cf[i]*cf[j])*highvals[idx]
   closed.append(dict(precision=[100,160],values=values,relative_errors=[dec(e,30) for e in errs],Delta_sign=(4*A*C-B*B>0)-(4*A*C-B*B<0)))
   per.append(dict(levels=levels,groups_exact={str(k):fj(v) for k,v in groups.items()},closed_form=True))
  else:raise ArithmeticError('Unexpected score levels; no menu change')
 endpoint=[segs[0]['Pi'][0][i]-segs[-1]['Pi'][1][i] for i in range(6)];jump=[sum(segs[k+1]['Pi'][0][i]-segs[k]['Pi'][1][i] for k in range(len(segs)-1)) for i in range(6)];signed=[sum(T[i][j]-T[j][i] for j in range(6)) for i in range(6)] if all_fraction else [mp.fsum(m(T[i][j])-m(T[j][i]) for j in range(6)) for i in range(6)]
 if all_fraction:res=[signed[i]-endpoint[i]-jump[i] for i in range(6)];assert all(v==0 for v in res)
 else:
  res=[m(signed[i])-m(endpoint[i]+jump[i]) for i in range(6)];assert max(abs(v) for v in res)<mp.mpf('1e-80')
 record=dict(arithmetic='Fraction' if all_fraction else '100/160 closed-form mp',nu_exact=list(map(fj,nu)),segments=per,matrix_T_exact=[[fj(v) for v in row] for row in T] if all_fraction else None,matrix_T_decimal=[[dec(v,160) for v in row] for row in T],endpoint_coefficients=list(map(fj,endpoint)),internal_jump_coefficients=list(map(fj,jump)),identity_vector_residual=[dec(v,160) for v in res],identity_vector_pass=True,closed_checks=closed)
 return T,endpoint,jump,all_fraction,record

def point(c,r,T,end,jump,exact,oracle):
 fv=[fr(r['rho'][i]) if r['good'][i] else F(0) for i in range(6)];assert all(0<=v<=1 for v in fv)
 if exact:
  plus=sum(max(fv[i]-fv[j],F(0))*T[i][j] for i in range(6) for j in range(6));minus=sum(max(fv[i]-fv[j],F(0))*T[j][i] for i in range(6) for j in range(6));ep=sum(fv[i]*end[i] for i in range(6));jp=sum(fv[i]*jump[i] for i in range(6));corrected=plus-minus-ep-jp;assert corrected==0
 else:
  plus=mp.fsum(m(max(fv[i]-fv[j],F(0)))*m(T[i][j]) for i in range(6) for j in range(6));minus=mp.fsum(m(max(fv[i]-fv[j],F(0)))*m(T[j][i]) for i in range(6) for j in range(6));ep=mp.fsum(m(fv[i]*end[i]) for i in range(6));jp=mp.fsum(m(fv[i]*jump[i]) for i in range(6));corrected=plus-minus-ep-jp;assert abs(corrected)<mp.mpf('1e-80')
 assert abs(ep)<=1 and plus>=0 and minus>=0
 tr=r['traffic'];main=tr.get('main_gates_pass',all(r['gates'].values()));accepted_F=F(0);source='main gate excluded'
 if main:
  if c['id']=='P1':
   rr=oracle.get(r['id'])
   if rr:accepted_F=fr(rr['F_raw']);source='R142 audited posthoc primitive oracle'
   else:assert not tr['positive_raw'];source='No positive accepted cap'
  else:accepted_F=fr(tr['F_raw']);source='R142 stored two-score traffic'
 factor=fr(r['p'])*fr(r['hardmass'])/fr(r['q']);accepted=accepted_F/factor if factor>0 else F(0);pM=m(plus);mM=m(minus);aM=m(accepted);overshoot=max(aM-pM,mp.mpf(0));compatible=aM<=pM*(1+mp.mpf('1e-10')) if pM>0 else aM==0
 ratio_rev=mM/pM if pM>0 else None;ratio_accept=aM/pM if pM>0 else None;ratio_plus=pM/aM if aM>0 else None
 Ctime=m(fr(r['hardmass'])/fr(r['q']))*(max(m(ep),mp.mpf(0))+mM) if main and tr['positive_raw'] else None;threshold=F(1,c['n']+1)
 rec=dict(id=r['id'],stage=r['stage'],distribution=r['distribution'],f_saved=[str(v) for v in fv],f_all_zero=all(v==0 for v in fv),f_all_equal=len(set(fv))==1,main_gates_pass=bool(main),accepted_positive=bool(tr['positive_raw']),uncertain=r['uncertain'],Dplus=dec(plus),Dminus=dec(minus),reverse_positive=minus>0,endpoint_difference=dec(ep),saved_internal_jump=dec(jp,160),uncorrected_identity_residual=dec(plus-minus-ep,160),jump_corrected_identity_residual=dec(corrected,160),identity_pass=True,arithmetic_exact_fraction=exact,accepted_internal=dec(accepted),accepted_source=source,accepted_F=dec(accepted_F),accepted_vs_Dplus_pass=compatible,accepted_excess=dec(overshoot),Dminus_over_Dplus=dec(ratio_rev) if ratio_rev is not None else None,accepted_over_Dplus=dec(ratio_accept) if ratio_accept is not None else None,Dplus_over_accepted=dec(ratio_plus) if ratio_plus is not None else None,Dplus_gt_one=plus>1,C_time_posthoc=dec(Ctime) if Ctime is not None else None,C_time_threshold_exact=fj(threshold),C_time_cover_posthoc=Ctime<=m(threshold) if Ctime is not None else None)
 return rec

def summarize(rows):
 positive=[r for r in rows if r['main_gates_pass'] and r['accepted_positive']]
 rat=lambda key,rr:[r[key] for r in rr if r[key] is not None]
 out=dict(count=len(rows),zero_f=sum(r['f_all_zero'] for r in rows),constant_f=sum(r['f_all_equal'] for r in rows),Dplus_zero=sum(mp.mpf(r['Dplus'])==0 for r in rows),reverse_positive=sum(r['reverse_positive'] for r in rows),identity_failures=sum(not r['identity_pass'] for r in rows),accepted_domination_failures=sum(not r['accepted_vs_Dplus_pass'] for r in rows),Dplus_gt_one=sum(r['Dplus_gt_one'] for r in rows),Dminus_over_Dplus=quant(rat('Dminus_over_Dplus',rows)))
 out['max_abs_uncorrected_identity_residual']=dec(max([abs(mp.mpf(r['uncorrected_identity_residual'])) for r in rows] or [0]),160)
 out['max_abs_jump_corrected_residual']=dec(max([abs(mp.mpf(r['jump_corrected_identity_residual'])) for r in rows] or [0]),160)
 out['positive_main']=dict(count=len(positive),reverse_positive=sum(r['reverse_positive'] for r in positive),Dminus_over_Dplus=quant(rat('Dminus_over_Dplus',positive)),accepted_over_Dplus=quant(rat('accepted_over_Dplus',positive)),Dplus_over_accepted=quant(rat('Dplus_over_accepted',positive)),C_time_cover=sum(bool(r['C_time_cover_posthoc']) for r in positive),C_time=quant(rat('C_time_posthoc',positive)))
 return out

def main():
 recover=OUT.exists()
 if recover:
  previous=json.loads(OUT.read_text());assert previous['cases']['P1']['status']=='case_exception' and previous['cases']['I1']['status']==previous['cases']['I2']['status']=='completed_analytic'
 else:previous=None
 for p,h in EXPECTED.items():assert sha(p)==h
 src=json.loads(SRC.read_text());data=json.loads(REC.read_text());ora=json.loads(ORACLE.read_text());assert ora['receiver_sha']==EXPECTED[REC];oracle={r['id']:r for r in ora['records']}
 out=dict(status='running',run_count=1,started_utc=utc(),input_sha256={str(p):h for p,h in EXPECTED.items()},sha256={str(p):sha(p) for p in [Path(__file__),ROOT/'numeric_flux_plan.md']},scope='All-pair analytic finite saved receiver diagnostic; no sampling/quadrature/optimization/FULL/root claim',posthoc_derivation='Parent requested after plan freeze: C_time=(hardmass/q)(max(endpoint,0)+Dminus), threshold1/(n+1); diagnostic only, no deletion contract or audited universal constants',cases={},exceptions=[]);
 if not previous:save(out)
 out['startup_recovery']={'exit_code': 1, 'mathematical_execution': False, 'script_sha256': 'c54906876afca7ab3838a2f32082eebdce0494cf282b283158591317236619e8', 'actual_error': "SyntaxError: '(' was never closed", 'line': 94, 'cause': 'Missing close parenthesis in summary serialization expression; no data read or analytic calculation executed.'};out['attempt']=2;out['mathematical_execution_count']=1;
 if not previous:save(out)
 if previous:
  out=previous;out['recovery_history']={'prior_status':previous['status'],'P1_failure':previous['cases']['P1'],'prior_code_sha256':previous['sha256'][str(Path(__file__))],'fix':'Mixed Fraction/mpf subtraction in P1 matrix signed sums; converted only numeric matrix operands, no mathematical/threshold changes; completed I1/I2 rows reused.'};out['exceptions']=[];out['recovery_code_sha256']=sha(Path(__file__));out['status']='recovering_P1';out['attempt']=3;save(out)
 mp.mp.dps=160
 for cid in (['P1'] if previous else ['I1','I2','P1']):
  start=time.monotonic();c=next(c for c in src['cases'] if c['id']==cid);receiver=data['cases'][cid];row=dict(n=c['n'],status='initializing',records=[]);out['cases'][cid]=row
  try:
   T,end,jump,exact,krecord=kernels(c,receiver);row['time_kernels']=krecord
   for r in receiver['records']:
    try:row['records'].append(point(c,r,T,end,jump,exact,oracle if cid=='P1' else {}))
    except Exception:row.setdefault('errors',[]).append(dict(id=r['id'],traceback=traceback.format_exc()));out['exceptions'].append(dict(case=cid,id=r['id']))
   row['summary']=summarize(row['records']);groups=defaultdict(list)
   for r in row['records']:groups[(r['stage'],r['distribution'])].append(r)
   row['strata']={stage+':'+dist:summarize(rr) for (stage,dist),rr in groups.items()};row['status']='completed_with_row_errors' if row.get('errors') else 'completed_analytic';row['elapsed_seconds']=time.monotonic()-start;save(out);print(cid,'count',len(row['records']),'reverse',row['summary']['reverse_positive'],'positive-main',row['summary']['positive_main'],'elapsed',row['elapsed_seconds'],flush=True)
  except Exception:row.update(status='case_exception',traceback=traceback.format_exc());out['exceptions'].append(dict(case=cid));save(out);print(cid,'case_exception',flush=True)
 out['status']='completed_with_failures' if out['exceptions'] else 'completed_analytic';out['finished_utc']=utc();out['summary']=dict(receiver_count=sum(len(c['records']) for c in out['cases'].values()),exceptions=len(out['exceptions']),new_sampling_count=0,quadrature_count=0,FULL=False,general_root_claim=False);save(out);print(out['summary'],flush=True)
if __name__=='__main__':main()
