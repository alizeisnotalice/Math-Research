# R143 固定接收点正反通量诊断（执行前冻结）

仅读取R142已保存的6951接收行（6912随机+36压力+3控制），按原initial/pressure/expanded/control及uniform/p分层；不抽样、不重跑receiver producer、不新增求积、不优化质量/半径。固定R142每例的ν、时间窗、w_t及每个接收行已重算的good/rho，令f_v=1_good rho_v，整个t窗口固定，须核0≤f≤1。所有36对参与，不冻结旧来源标签。

## 1. 准确量与检查

Π_i(t)=ν_i c_i t^-k_i/e_t，原score严格阈值分段。

Dplus(t)=Σ(f_i−f_j)_+(k_i−k_j)_+Π_iΠ_j；
Dminus(t)=Σ(f_i−f_j)_+(k_j−k_i)_+Π_iΠ_j。

在每个score段，−d EΠ f/dlogt=Dplus−Dminus。先计算独立x的矩阵T_ij=∫(k_i−k_j)_+Π_iΠ_j dlogt，随后每行Dplus_int=Σ(f_i−f_j)_+T_ij、Dminus_int=Σ(f_i−f_j)_+T_ji。端点矩EΠ_tau f−EΠ_h f用同一时间模型计算。记录全零f、全同f及零Dplus的行，不作除零比值。

保存120位c和分段端点有独立舍入，不能强说边界精确连续。每个内部break比较左右Π，保存jump；整段恒等式应为Dplus_int−Dminus_int−global_endpoint=Σ(EΠ_next_lo f−EΠ_prev_hi f)。先核精确/高精度jump修正恒等式，同时单独报告未经修正的残差和jump规模，不静默修改原系数或端点。

原good×bad的rho正交通在同一f上受Dplus逐点支配，FA/Psi只删减。因此主要合法receiver的accepted_internal≤Dplus_int；accepted为R142主固定λ门的F除以p hardmass/q。I1/I2直接读取其已保存交通；P1优先读取已审计time_primitive_check.json恢复值，不重算FA端点交通；其主门未通过时accepted=0。若比较的float FA端点与保存整段端点舍入有细微差，保存真实比值与正部超额，不把容差当精确证明。

## 2. 仅几个解析时间核

I1/I2每个两score段(l,l+d)的高低pair整段积分
 c_i c_j(z0−z1)/[(A z0+B)(A z1+B)]，z=t^-d，
A/B为高/低组νc和。乘ν_iν_j得到T_ij，完全Fraction；单score段为0。两score式沿R142 time_algebra.md，不调用求积。

P1唯一三score有效段令u=t^d，P=A+B u+C u²；高–中/高–低/中–低积分为c_i c_j∫[1,2u,u²]/P² du。复用R142 time_primitive_check.py的有理原函数Δ分支，只计算整段三个公共核一次，100/160位两次纯闭式求值，要求相对一致<10^-80。没有quadrature。P1其他单score段0。

对每例完整matrix及端点/jump保存可复现系数、ν和结果。每行f来自保存float的精确十进制有理解释；Fraction结论仅针对保存系数模型，不认证新x真实核或FULL。

## 3. 预算、阈值与交付

最多6951已有行，100/160仅P1公共三核及必要恒等式复核；不增加40个独立接收行（R142高精度复核仍是同点，主诊断使用冻结主receiver行）。输入receiver、原时间源、P1恢复oracle SHA开跑前绑定。

检查：两scorejump修正恒等式精确0；P1公共闭式一致<10^-80、归一化恒等式残差≤10^-80。支配比较采用原浮点结果的数值相容阈值accepted≤Dplus(1+10^-10)，同时记录超额；失败不换数据/容差。定义reverse为严格>0的保存模型值，报告reverse零/非零计数、Dminus/Dplus分位/最大、accepted/Dplus及Dplus/accepted（仅非零分母），分层和合法正行单列。

额外记录Dplus>1的行与端点差[-1,1]检查，以免将端点有界误当总正变差有界；不因本有限菜单reverse较小而推出一般root预算。 arbitrary threshold priors仍可能维持O(n)交通，本次不拟合维度阶。

交付numeric_flux.py/json/notes，原R142数据和父代理文件不改；无git/PDF。完成停止。
