# R143：保留原Psi图与负项的共同cut时间账

状态：裸正score时间命题不成立；本稿主体是保留原负项全部松弛后的精确cut重组及其准确缺边费用。不把链特殊族当作目标，不登记新的统一付款。固定原u₀、完整实际接收行及共同alpha；rho在该行时间窗内固定。

## SF143.1. 必要历史定位与原负项方向

限定检索R133–R136：R135 `history_score_channel.md`记录了R131的Eδ≤n/4及未支付阈值穿越费；R135 `area_flux.md`保留A=wτ−wh的FTC及eτ/eg归一化费用；R136 `ordered_score_capacity.md` OS1–OS7已处理score整数层的容量重数，但未给本次一般时间根阶界。另核R122 `weighted_suffix_integration_private.md`和R138 `signed_flux_connection.md`：Psi是固定pair的未归一后缀资格，不能当作单来源cut；去掉Psi补集已使用过其负账。

记G=S_g⊂Z_g，D₀=D_g∩Z_g；在终端存活支持上G与D₀构成原good/bad分割。原bad在时刻t还可能包含

\[
D_{future}(t)=D_g\cap(Z_t\setminus Z_g).
\tag{SF143.1}
\]

该块不能因正放松而删掉，以下先单独处理两个来源都在Z_g的块；future块及N_del在最后原位保留。

对每个原pair，记Δ=k_v−k_u、δ₊=Δ₊、δ₋=(−Δ)₊，χ=χ_FA。0≤rho≤1、0≤χ≤1给出完整恒等式

\[
\boxed{\rho\chi\delta_+-\delta_-
=\rho\Delta-\big[(1-\rho)\delta_-+\rho(1-\chi)\delta_+\big].}
\tag{SF143.2}
\]

两项括号中的松弛都非负，必须与原Psi及时间域一起保留。原负项系数仍是−1；N_Zc只使用这一次，N_del尚未消费。若此前已付款并移除部分正支，可把这些剩余正资格并入χ_eff∈[0,χ_FA]，仍得精确身份；如不这样定义，本稿对完整正项的身份给剩余正项上界，不能为负项追加同样新门。以下χ可指这两种明确选择之一。

## SF143.2. 一般阈值向量的共同cut表示：不要求链

定义终端支持上的辅助概率

\[
e_g^*(t)=\int_{Z_g}w_t d\nu,\qquad
 d\pi_t^g(v)=1_{Z_g}(v)w_t(v)d\nu(v)/e_g^*(t).
\tag{SF143.3}
\]

这里星号表示固定终端集合后再随t加权，**不是**原e_g常数或Π_g。若ν(Z_g)=0，good正交通为空；否则e_g^*(t)>0。任意相关ν、任意正阈值向量均满足a.e.

\[
\frac d{d\log t}\int f\,d\pi_t^g
=-\operatorname{Cov}_{\pi_t^g}(f,k_t)
\tag{SF143.4}
\]

对本稿f(v)=rho(v)1_G(v)∈[0,1]成立。w_t是AC，k_t的逐源阈值跳变不会给固定f另加跳项；它们已经通过实际k_t进入导数。不能对随t改变的score cut直接照搬此句。

对0≤ℓ≤1置C_ℓ={v∈Z_g:f(v)>ℓ}⊂G。共同层蛋糕表示

\[
f(v)=\int_0^1 1_{C_\ell}(v)d\ell
\tag{SF143.5}
\]

具有至多1的总cut参数质量，不要求将来源分解成若干链，也没有链宽度因子。每个cut固定于本行整段时间。以\pi_t^g为两端概率，

\[
\iint_{C_\ell\times(Z_g\setminus C_\ell)}(k_v-k_u)d\pi_t^g(v)d\pi_t^g(u)
=-\frac d{d\log t}\pi_t^g(C_\ell).
\tag{SF143.6}
\]

问题在于原Psi图不是这些完整cuts。设F(t)=∫f dπ_t^g，并直接定义两个明确的缺边积分

\[
M_\Psi(t)=\iint_{G\times D_0}
 (1-\Psi(v,u))\rho(v)(k_v-k_u)d\pi_t^g(v)d\pi_t^g(u),
\]
\[
M_G(t)=\frac12\iint_{G\times G}
 (\rho(v)-\rho(w))(k_v-k_w)d\pi_t^g(v)d\pi_t^g(w).
\tag{SF143.7}
\]

不赋予这两个量任何未证的符号或预算。逐cut补全并积分ℓ，得到一般向量下的精确身份

\[
\boxed{
\iint_{G\times D_0}\Psi(v,u)\rho(v)(k_v-k_u)d(\pi_t^g)^2
=-F'(\log t)-M_\Psi(t)-M_G(t).}
\tag{SF143.8}
\]

证明也可直接展开协方差：G×D₀的全边贡献是ρ(v)(k_v−k_u)，G×G贡献是M_G，D₀×D₀为0；再删去Psi补图得到M_Psi。此式保留原完整Psi图，不将Psi=1冒作一般情况。rho由同一alpha决定，其在不同good源之间的变化完整留在M_G中。

SF143.5–8给出了无需链的共同cut表示。若此时丢掉SF143.2的松弛，M_G会成为额外未付项；保留松弛则能精确消去这一内部good项，见SF143.13–15，不能提前单独给M_G收费。

## SF143.3. 原分母、真实时间窗及删除来源的费用

原Π_t在Z_g×Z_g上的密度准确等于

\[
 d\Pi_t(v)d\Pi_t(u)
=\left(\frac{e_g^*(t)}{e_t}\right)^2
 d\pi_t^g(v)d\pi_t^g(u).
\]

记

\[
\omega(t)=1_{J_{far}}(t)\left(\frac{e_g^*(t)}{e_t}\right)^2\in[0,1].
\tag{SF143.9}
\]

本稿在signed项中保留这个因子，**不**以e_t≥e_g^*(t)作signed方向替换。原两份e_t分母没有消失。定义原松弛

\[
L_{\rho,\chi}(t)=\iint_{G\times D_0}\Psi
\big[(1-\rho(v))\delta_-+\rho(v)(1-\chi)\delta_+\big]d(\pi_t^g)^2\ge0.
\]

由SF143.2、8，完整终端块的原signed余量精确为

\[
\boxed{S_{surv}=-\int_\tau^h\omega(t)\,dF(t)
-\int_\tau^h\omega(t)[M_\Psi(t)+M_G(t)+L_{\rho,\chi}(t)]\frac{dt}{t}.}
\tag{SF143.10}
\]

F是AC，故该式对任意原可测时间窗有意义。只有已确认omega为BV且取相容端点版本时，第一项才可进一步写成

\[
-\int\omega\,dF
=\omega(\tau)F(\tau)-\omega(h)F(h)+\int F\,d\omega
\le1+\operatorname{Var}_+(\omega).
\tag{SF143.11}
\]

omega同时包含时间窗边界及future来源造成的归一化比例变化；e_g^*(t)/e_t一般不由两个分母分别单调而自动单调。任意可测窗不能直接领取BV端点公式；若有无限变化，其正变差不能免费置零。

R122在原初始heavy窗合同下曾证明J_far=[τ,h]至端点零测。确切调用该合同可删除时间窗指示的边界费用，但仍须保留e_g^*(t)/e_t；本稿不把该结论无条件推广到另行剪取的正/负时间窗。

原future bad块准确是

\[
S_{future}=\int_{J_{far}}\iint_{G\times D_{future}(t)}
\Psi\{\rho\chi(k_v-k_u)_+-(k_u-k_v)_+\}
 d\Pi_t(v)d\Pi_t(u)\frac{dt}{t}.
\tag{SF143.12}
\]

它不属于SF143.3的终端归一化概率，不被e_t≥e_g^*删除。恢复原母式时，尚有S_future−N_del；其域、时间窗、Psi及history未逐项匹配前，不声称二者相消。

## SF143.4. 保留松弛后，内部good缺陷精确消去

令f₀=(1−ρ)1_G、F₀(t)=∫f₀dπ_t^g，并记

\[
X_0(t)=\iint_{G\times D_0}\Psi(1-\rho(v))\Delta\,d(\pi_t^g)^2,
\quad
U_{\rho,\chi}(t)=\iint_{G\times D_0}\Psi(1-\rho(v)\chi)\delta_+d(\pi_t^g)^2.
\]

逐pair直接计算，得到非平凡的准确抵消关系

\[
\boxed{X_0+L_{\rho,\chi}=U_{\rho,\chi}\ge0.}
\tag{SF143.13}
\]

事实上(1−ρ)(δ₊−δ₋)+(1−ρ)δ₋+ρ(1−χ)δ₊=(1−ρχ)δ₊。f₀的完整cut内部good项恰为−M_G，因为其good内差是−(ρ(v)−ρ(w))；两者相加没有内部good边。置

\[
g(t)=\pi_t^g(G),\qquad
M_\Psi^1(t)=\iint_{G\times D_0}(1-\Psi)\Delta\,d(\pi_t^g)^2.
\tag{SF143.14}
\]

由f+f₀=1_G，SF143.10精确重组为

\[
\boxed{S_{surv}=-\int_\tau^h\omega\,dg
-\int_\tau^h\omega M_\Psi^1\frac{dt}{t}
-\int_\tau^h\omega U_{\rho,\chi}\frac{dt}{t}.}
\tag{SF143.15}
\]

这条重组对一般相关ν与一般阈值向量成立，保留原两份分母、Ψ图和所有负项，且无需ρ与score同序。它说明**改写成未加权cut时无需独立支付M_G**；原松弛允许准确回到未加权good cut。这不是总费用下降：F与g的端点可能符号不同，M_Ψ与M_Ψ¹也不同，不能在两种表示中逐项挑较小值并丢掉配套项。最终的“补图损失减正端抑制”结构与R138 `signed_flux_connection.md`的L_Z−G一致，本稿不把同一接口重复登记为新付款。

共同alpha还给实际保留抑制项一个方向正确的下界。在A_v>0时，令

\[
a_v=\frac{DK_0(v)}{TA_v},\quad b_v=\frac{\alpha J_v}{TA_v},\quad
\mathcal R_x=D(q-Q_0)+\int(DK_0-U)d\nu=\alpha Q_J.
\]

在未被原额外零门强制清零时ρ_v=(1−a_v−b_v)₊；强制清零只减小ρ。故一般均有

\[
1-\rho_v\chi\ge1-\rho_v
\ge\min\{1,a_v+b_v\}\ge\min\{1,b_v\}.
\]

所以

\[
\boxed{U_{\rho,\chi}(t)\ge
\iint_{G\times D_0}\Psi
\min\!\left\{1,\frac{J_v\mathcal R_x}{TA_vQ_J}\right\}
\delta_+\,d(\pi_t^g)^2.}
\tag{SF143.16}
\]

所有来源共用同一R_x，不逐pair重新领取容量。真实s>0、ν非零给Q_J>0。A_v=0时按原约定ρ_v=0，抑制系数准确为1；右边比较系数也可定义为1，无需解释0/0。其他强制ρ=0的原门只使抑制系数增大。SF143.16是同一已保留负贡献的下界，不能再在别的槽重复扣除。

尚未获得的具体几何连接是：Ψ=0的反向补图损失，能否由Ψ=1上的SF143.16抑制，加上真实接收平均的可支付边界控制。两者位于不同pair域，SF143.16没有提供跨域配对。R122完整原后缀合同下，Ψ=0每pair的归一signed积分≤0，故−∫ωM_Ψ¹是非负损失；这个事实不给其大小上界，也不允许返还已用N_Z。任意剪窗时连该符号也需重新核验。

阈值链不能补这个几何连接：即使所有a_i由共同r排列，真实来源的坐标符号分支仍能改变x−v的核比与good标签。未证明实际p(x−y)dx平均控制这些跨域变化前，不能把good看作单调初段。这里不再另开链分解或反例路线。

父代理本轮有限模型积分提供一个具体压力检查（本稿引用其已完成计算，不将其当作一般证明）：P1的168个正main点有149个Dminus>0，Dminus/Dplus中位约0.0819；I1的11个正main点Dminus=0。但这179个正main点的原N_Zc均为0，缺失Ψ的signed量均为负。I1的完整未加权good端点约−0.0247140、缺失Ψ signed约−0.0286336，实际正端抑制仅约0.00084–0.00127，正main约0.00265–0.00308。未加权表示由相对较大的两项抵消产生小余量，而加权f的端点反为正。故“有反向score”不能等同于“原Ψ图内有可用负交通”，SF143.15也不能被宣称降低了费用。应同时保留SF143.10和SF143.15，并寻求加权势与其匹配缺边的真实几何控制；这批数据不认证一般接收付款或FULL。

## SF143.5. 原母式的唯一剩余组合与外账

记R_Ψ=−∫ωM_Ψ¹dt/t、A_ρ,χ=∫ωU_ρ,χdt/t。未剪正项时，将SF143.15与future块拼回，原行的signed槽准确为

\[
\boxed{-\int\omega\,dg+R_\Psi-A_{\rho,\chi}
+S_{future}-N_{del}.}
\tag{SF143.17}
\]

移除已付正支后该式为合法上界，或使用前述χ_eff保持身份。若omega已证明BV，第一项按SF143.11用g替换F，至多1+Var₊(omega)。若未证明BV，则原Stieltjes/AC积分原样保留，不能另授端点价。需要几何支付的是**这一组合**，不是把R_Ψ、M_G或来源变差另命名后分别假设有帽。尤其S_future−N_del仍要求原域、原Ψ、time/history的准确匹配。

乘原q⁻¹p h_R a_history，恢复dx dβ(y)dν(z)、EΣ_{V,j}及2Λ，SF143.17原位接到原目标。N_Zc只在SF143.2消费一次；N_del未被认定相消；SF143.16只保留同一抑制，不是新负账。任意相关ν、外hard源不属Z_t的情况均未改变。

即使在一个认证范围内omega=1、R_Ψ≤A_ρ,χ且future删除账配平，也只有逐行≤1。直接套T_small≤4X给8ΛX，不是任意εX；原hard帽16/3及全soft/L包络也可能仍产生O(n^{3/2})Wβ。因此不能从时间端点身份宣布总根阶。只有消源后得到共同数值帽，才可按R140合并唯一j；不同λ层、adaptive s/L及原β账全部须支付。

本轮完成的准确检查点：裸score根阶命题不成立；保留N_Zc的完整松弛可将加权cut的good内部误差精确消掉，并留下共同alpha提供的实际正端抑制SF143.16。尚缺在真实接收积分下控制加权SF143.10（等价于SF143.17）的势与跨Ψ域缺边组合；未加权重组没有证明减小该费用。现有推导没有证明该组合达到εX+Cε√n log^A n Wβ。没有把这个缺口改名为已付能量，也没有认定完整目标不可能。仅保存本文件，完成后停止，无Git、无PDF。

## 附：裸命题的简短精确筛查（不作为原几何反例）

令所有a_i(r)=r，取任意0<a<b及0<ε<1，在r∈[εa,b/ε]上用有限正测度dν=r^{-n/2-1}dr；可乘常数归一化而不改Π_t。对t∈[a,b]，记A_t=(εa/t)^{n/2}、B_t=(εt/b)^{n/2}，均≤ε^{n/2}。k_t只取n或0，且

\[
\Pi_t(k=n)=\frac{1-A_t}{2-A_t-B_t},\qquad
\Pi_t(k=0)=\frac{1-B_t}{2-A_t-B_t}.
\]

两端质量一致趋1/2，故裸正score积分一致趋n log(b/a)/4。一般上界恰为Eδ=Σ_{m=0}^{n-1}P(k≤m)P(k>m)≤n/4。因此对给定n及a<b，该类有限正ν的裸时间积分上确界准确等于n log(b/a)/4。持续整个窗口，不是瞬时n例子。它没有认证原C阈值几何、good/bad、共同alpha或接收域，只否定最初删除这些门后的裸命题；主体不据此否定原完整问题。
