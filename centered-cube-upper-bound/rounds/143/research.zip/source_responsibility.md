# R143：共同 alpha 的来源责任分解

## SR1. 范围与恢复检查点

仅使用 R142 `joint_receiver_common_alpha.md` CA1–CA2 及 `joint_receiver_geometry.md` JR8 的合同。固定原 ω,V,j,y,t、同一非负来源 ν 及其全部原归一化量；只截断积分域或非负被积量，并在有限正行上证明，再用非负积分通过极限，不以截断来源重新归一化。本文不调用 R141 的共享储备账，不重用 hard 帽，不假设来源坐标独立、e 的下界或距离矩。

目标是将共同 R/QJ 的实际抑制分解成每个储备来源只输出一次的非负耦合，精确列出接收端、good 来源端及储备来源端的边际；由此识别可直接控制正剩余量的最小尾条件。没有预设这些边际已满足统一根阶预算。

## SR2. 先准确消去一份 score 来源和一份 hard 来源

在 0<e_t(y)<∞ 的原行，记
\[
b_t(v)={1_{Z_t}(v)w_t(y,v)\over e_t(y)},\quad
d\Pi_t(v)=b_t(v)d\nu(v),\quad
\sigma_t(v)=\int[k_t(v)-k_t(u)]_+d\Pi_t(u).
\tag{SR1}
\]
这里 ∫b_t dν=1、0≤σ_t≤n；下文保留 σ_t，不把它换成 n。e=0 的原行交通置0，不定义商。固定接收 x 的合法 CA 域 Ω，记
\[
R_0(x)=D(q-Q_0),\quad R(x)=R_0(x)+\int d_x(a)d\nu(a),
\quad j_x(v)={J(x-v)\over Q_J(x)},\quad
B_x(v)=[TA_v-DK_0(x-v)]_+.
\tag{SR2}
\]
以下形成商的行均要求 0<QJ(x)<∞、0<TA_v<∞，并取 0<J(x-v)<∞ 的原正软核行；因此 j_xν 是概率且 j_x>0，B_x(v) 有限。QJ=0、A_v=0、e_t=0 均按原零交通/零余量约定处理，不以除零公式求值。无限归一化量不在本稿商的适用域。定义
\[
\lambda_x(v)={b_t(v)\sigma_t(v)1_{good}(x,v)\over TA_v},
\quad H(x)=\int h_{R_{\rm scale}(x)}(x-z)d\nu(z),
\quad d\mu(x)={1_\Omega(x)p_xH(x)\over q_-}\,dx.
\tag{SR3}
\]
R_scale 是原 hard 核尺度，区别于储备 R(x)。所有未保留的历史/资格门仅作 JR8 允许的正放松。good 门可原样保留；若有依 u,z 的其他门，则须先保留全三源表达或合法删除，不能假称 SR3 仍含那些门。

定义完成门删除及 q(x)^−1≤q_-^−1 后的放松固定行量为
\[
\boxed{\mathcal L=\int d\mu(x)\int\lambda_x(v)
[B_x(v)-R(x)j_x(v)]_+d\nu(v).}
\tag{SR4}
\]
原正交通≤对应原外层对 L 的求和/积分，而非与放松后的 L 相等。SR4 内部的等式来自 ρ=[B−Rj]_+/(TA)，随后对 u、z 各作一次 Tonelli。两份 e^−1 完整留在 b_t(v) 和 σ_t(v) 内。H 是原 hard 来源积分的准确值，没有再用 hard 帽，也没有把外 hard z 当作 Π_t 的抽样。1/q_- 只出现一次。最后仍须施加原 EΣ_(V,j)∫dβ_V(y)∫dt/t 和参数单元/层级求和。

## SR3. 每个储备来源只输出一次的责任耦合

添一个符号点 ⋆，令储备来源测度
\[
d\eta_x(a)=d_x(a)d\nu(a)+R_0(x)\delta_\star(da),\qquad
\eta_x(\{\star\}\cup\mathbb R^n)=R(x).
\tag{SR5}
\]
当 0<R(x)<∞，在 (a,v,τ) 上定义非负耦合
\[
d\Gamma_x(a,v,\tau)=d\eta_x(a)\,j_x(v)d\nu(v)\,d\tau\,
1_{\{0<\tau<1,\;\tau R(x)j_x(v)<B_x(v)\}}.
\tag{SR6}
\]
它的两个准确边际为
\[
\boxed{\begin{aligned}
\Gamma_x(dv)&=\min\{B_x(v),R(x)j_x(v)\}\,d\nu(v),\\
\Gamma_x(da)&=c_x\,d\eta_x(a),\qquad
c_x=\int j_x(v)\min\{1,B_x(v)/(R(x)j_x(v))\}\,d\nu(v)\le1.
\end{aligned}}
\tag{SR7}
\]
故每个真实储备来源 a 及 ⋆ 的输出均至多它拥有的容量；没有为每个 v 复制 R。R=0 时 Γ=0，并取 c_x=κ_x=0，不计算 SR7/SR9 中的商。责任耦合的边际声明只适用于有限 R；R=∞ 且 j>0、B有限的行其剩余量直接为0，无需声称无限储备耦合存在特定极限。若将概率密度 j 泛化为可为零，SR7/SR9 的商只在 j>0 上使用；也可统一使用 ℓ_x(v)=∫_0^1 1_{τRj<B}dτ 代替 min 表达，避免零分母。

先仅对有限 R 的接收行，把 Γ 按 λ_x(v) 加权，得到被实际 posterior/score/good 交通使用的抑制量。若
\[
\mathcal D=\int d\mu(x)\int\lambda_x(v)B_x(v)d\nu(v),\quad
\mathcal S=\int d\mu(x)\int\lambda_x(v)d\Gamma_x(a,v,\tau),
\]
则准确的非减法恒等式为
\[
\boxed{\mathcal L+\mathcal S=\mathcal D.}
\tag{SR8}
\]
全部三项非负，允许同时为∞；不作∞−∞。若纳入 R=∞、j>0、B有限的行，则其抑制直接定义为 ∫λB dν，等价于接收端表达 ∫λmin(B,Rj)dν；SR8 仍成立，但不通过 Γ 定义该行，也不对该行声明 SR9–10 的来源容量边际。B=R=∞ 的行须另由原问题给出极限定义，不在这里的标量减法域。

在有限 R 的接收域，加权后的储备来源边际明确为
\[
\int d\mu(x)\,\kappa_x\,d\eta_x(a),\qquad
\kappa_x=\int\lambda_x(v)j_x(v)
\min\{1,B_x(v)/(R(x)j_x(v))\}\,d\nu(v).
\tag{SR9}
\]
于是对真实 a，其总责任密度是
\[
\int {1_\Omega p_xH(x)\over q_-}\,d_x(a)\kappa_x\,dx,
\tag{SR10}
\]
另有 ⋆ 的同式 R0 项。**这是尚未支付的加权边际**：c_x≤1 不推出 κ_x≤1，因 λ 含原 posterior、score 和 1/(TA_v)。更不能先为每个 hard z 领取一份 R；若保留 z，Γ 的整体测度只乘一次 p_x h_R(x−z)dν(z)dx/q_-，其 z 边际正是该式积分，不是一个新的可用储备。SR3 将它准确收为 H(x)。

## SR4. 直接控制剩余量的核比值尾；准确最小缺口

定义不含正剩余量 ρ 的显式核比值及其测度
\[
\Xi_x(v)={Q_J(x)[TA_v-DK_0(x-v)]_+\over J(x-v)},
\qquad dM_x(v)=\lambda_x(v){J(x-v)\over Q_J(x)}d\nu(v).
\tag{SR11}
\]
这两个对象仅由原正核、真实两 posterior、score 和 good 门构成。它们保留小 J、小 TA 和小 e 的实际价格，未预设可积性。非负 layer-cake 给准确的直接平均公式
\[
\boxed{\mathcal L=\int d\mu(x)\int_{R(x)}^\infty
M_x\{v:\Xi_x(v)>r\}\,dr.}
\tag{SR12}
\]
证明是 [B−Rj]_+=j[Xi−R]_+ 及 Tonelli。SR11–12 使用原严格正 J，故 j>0。R=0 时积分从0开始，R=∞ 的合法有限需求行按0处理。若泛化到允许 j=0 的概率密度，即使在 j=0、B>0 处设 Xi=∞，M=λjν 仍会漏掉该处需求；SR12 右侧必须另加 ∫dμ∫_{j=0}λB dν。本文原正核域无需该附加项。这一式没有分给每个 v 一个独立 alpha，没有用 Jensen 放大后再丢掉共同储备。

更可操作的是以下带完整常数的双边检验。固定 0<ε<1，定义原核比值的大尾需求
\[
\mathcal E_\varepsilon=\int d\mu(x)\int
\lambda_x(v)B_x(v)
1_{\{\Xi_x(v)>R(x)/(1-\varepsilon)\}}d\nu(v).
\tag{SR13}
\]
则
\[
\boxed{\varepsilon\mathcal E_\varepsilon\le\mathcal L
\le\varepsilon\mathcal D+(1-\varepsilon)\mathcal E_\varepsilon.}
\tag{SR14}
\]
在 B>0 行，剩余/需求恰为 [1−R/Xi]_+。Xi≤R/(1−ε) 时该比值≤ε，反之它介于ε和1之间；分别积分即得。B=0 行两边为0；R=0 行全需求进入大尾，L=D=Eε，右侧仍准确。阈值等号放在小尾一侧无妨。

因此，如果某个后续原预算能支付 D，而能对 SR13 的**显式加权核比值尾**证明 Eε≤C，那么立刻得到 L≤εD+(1−ε)C。反过来任何 L≤C 都强制 Eε≤C/ε。SR12 是精确必要充分的尾积分条件；SR14 给出允许吸收 εD 时的单阈值充分条件，以及不作吸收时的必要尾条件。不能由 L≤εD+C 单独推出 Eε≤C/ε；该更强断言并未使用。它准确定位所缺的来源平均估计，不能把 Eε 或 SR10 直接宣布为 C√n polylog(n)Wβ。

一个特别简单的可核验充分条件是 Xi_x(v)≤L_x 对需求测度 λBν 几乎处处成立。则直接有
\[
\int\lambda_x[B_x-Rj_x]_+d\nu
\le[1-R(x)/L_x]_+\int\lambda_x B_xd\nu,
\tag{SR15}
\]
当 L_x>0；零需求行另按0处理。此条件涉及原 J 对有效需求的支配，实际是否成立必须证明，不能以共同 ν 自动推出。允许例外的精确版本就是 SR13–14。

## SR5. 量词、归一化及不能免费取得的结论

1. SR6–10 是一次共享储备的责任分解；SR12–15 直接上界实际正剩余来源平均。二者用途不同：不能把 SR9 的已用储备再当成可支配第二个正项的容量。
2. 尾条件含 H(x)=∫h_R(x−z)dν(z)、b_t(v)σ_t(v)/(TA_v)、1/q_- 及实际 good 门。没有将 H 替成免费常数，没有第二次使用 hard 帽，没有删除任一 e^−1。对每个 t、j 和单元分别有效，随后原外部费用必须真实求和。
3. CA1–CA2 本身允许 q=Q0、U=DK0，从而 R=0。在这种合法零储备行，只要 B>0，正剩余就是全部需求。这说明不可能只凭“同一 ν”和非负核合同证明统一严格收缩。此为合同级障碍，并未宣称原全部门能实现该配置。
4. 即使有限 R>0，没有原核比值大尾控制也不能推出收缩：SR15 的比例在 Xi/R→∞ 时趋1。本文不添加 e 下界、来源独立性或距离矩来绕开它。
5. 极限采用固定原 ν、e、QJ、R、b、σ 及原核的非负表达：只截断积分域或非负被积量，再用 Tonelli/单调收敛。u、z 的原积分一旦收为 σ、H，随后即固定这两个原量；若在未收积分前截断 u、z，得到的是逐步逼近的非负积分，不重定义原 posterior。不能把 ν 换成截断来源后重新计算 e、QJ、R 或其他归一化量，随后未经证明宣称这些比值单调。SR8 保持 L+S=D，避免无穷量相减。

**交付范围。** 新增可验证对象是 SR6 的容量耦合及全部边际、SR14 的直接剩余双边尾检验。尚缺的是 SR13 在原外层 EΣ_(V,j)∫dβ∫dt/t、实际参数单元上的统一有价估计，以及需要吸收时 D 与原可用预算的合法比较；没有证明这些费用是根阶。本文没有修改其他文件、运行 Git 或编译 PDF。

