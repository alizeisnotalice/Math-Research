# R143 全pair正反通量：有限诊断结果与误差账

本轮只使用R142原6951接收行，保留initial/pressure/expanded/control及uniform/p分层；没有抽样、kernel重跑、quadrature、质量或半径优化。f_v=1_good rho_v来自该行实际新标签，固定整个时间窗；没有冻原G1/G4标签。零f、常f、零Dplus均保留。

## 1. 决策结果

| 原例 | 全部行反向非零 | 正main行 | 正main中反向非零 | 正main Dminus/Dplus |
|---|---:|---:|---:|---|
| I1 | 772/2317 | 11 | 0 | 0 |
| I2 | 1206/2317 | 0 | 0 | 不适用 |
| P1 | 1266/2317 | 168 | 149 | 中位.0819175，最大.0835991 |

P1的168行包括163随机uniform正点及5压力点；其中initial uniform25行/24反向、expanded uniform138行/123反向、pressure5行/2反向。p流没有正main，控制x0因固定λ上端数值边界未列入此分支。I1正main为initial uniform/p各1、expanded uniform3/p6；这些行反向为零。

因此不能把该有限菜单称为forward-only。P1反向来自149个正main点CORE的f_CORE>0而其score较低：reverse主项是CORE→G4，全部168点的反向积分合计该pair约2.70496e−6，其它CORE→G1/G3/G2/B合计极小。这里只是已有样本的只读pair分解，不新增时间积分。外于正main分支的反向也很多，其比Dplus可很大，说明端点有界本身不能支付一般正变差。

原accepted rho-weighted good×bad、FA/Psi交通受Dplus数值支配：全部行失败0，主要非零分支I1 accepted/Dplus约.943702860145416（Dplus/accepted约1.05965558）；P1 accepted/Dplus范围[.451751,1]、中位.903945，Dplus/accepted最大2.213608。P1 accepted读取R142已独立审计闭式oracle，包括原63个未算项；没有重新求截端积分。主门失败时accepted=0。

## 2. 协方差恒等式与时间舍入

每例完整36对矩阵T_ij独立接收x。I1/I2用保存有理ν/c/端点作Fraction整段式，P1用三score有理原函数仅计算三个公共整段核的100/160位版本，相对一致<10^-80；无数值quadrature。随后对每行精确保存f做Σ(f_i−f_j)_+T_ij与交换矩阵计算。

−dEΠf/dlogt=Dplus−Dminus在每段成立。原120位c/端点独立舍入使内部break的Π左右有极小jump，未静默替换为连续数据。global endpoint残差等于保存的Σ(EΠ_next_lo f−EΠ_prev_hi f)。

| 原例 | 最大未修正残差 | jump修正后 |
|---|---:|---:|
| I1 | 1.93115e−121 | Fraction精确0 |
| I2 | 9.60798e−129 | Fraction精确0 |
| P1 | 5.08996e−128 | 最大6.39001e−162 |

6951行恒等式检查通过，accepted支配数值相容阈值10^-10无失败，原端点差均在[−1,1]，菜单中没有Dplus>1；后者不是一般定理。全零f数I1/I2/P1为815/135/144；这些行不强除Dplus。完整时间matrix、端点和jump系数、100/160公共核证据均在JSON，单行Fraction数值由同JSON系数与绑定R142输入可精确重建，显示小数不是证明依据。

## 3. 冻结后请求的C_time（明确事后派生）

父代理在冻结后请求C_time=(hardmass/q)(max(endpoint_difference,0)+Dminus)，阈值1/(n+1)。代码/JSON独立标为posthoc，不改Dplus、Dminus、accepted目标或门。

正main共179行（含5压力点）全部数值满足阈值；I1最大.00336699<1/5，P1最大1.19682346e−7<1/17。此项提示时间候选费用在本菜单非常小，但没有已审统一常数、删源合同、forest或一般接收包络支付证明，不能据此宣布root预算成立或直接消源。

## 4. 实际执行与恢复历史

第一次启动exit1，summary括号SyntaxError，未读输入、未进行数学计算；实际错误、行号与脚本SHA保存在startup_recovery。第二次session97150完成I1/I2全部4634行，P1公共闭式之后在Fraction零矩阵与mpf相减处TypeError；原traceback/脚本SHA保存在recovery_history。

仅修复混合类型减法后session63144恢复P1的2317行，直接复用I1/I2完成行，没有重算这些行。最终6951个distinct原接收行全部完成，0最终row/case失败；新抽样0、quadrature0。P1公共三核因失败恢复重复了纯闭式求值，不能声称无失败的单次启动。metadata_postrun_correction将未在恢复分支更新的数学运行计数从1如实改为2，不改任何数值结果。

这些是保存有限系数/float receiver核与标签上的诊断，非新x真实核区间证书或全局恒等式预算认证。 arbitrary threshold priors可能维持O(n)交通；本菜单不能凭端点有界推广一般root结论。

## 5. 冻结SHA与复现依赖

- numeric_flux_plan.md: `d29eb6a6fc568d754ed2d1d7ec63035aeb494ab9ceb7b078d8d614b435859243`
- numeric_flux.py: `eda566f1d7a622788a4fc863cde6f31ad8cdb3808f1da0c29f52ad126d8d6521`
- numeric_flux.json: `d43c449225d9d0eea6a5b3a6ceb977f8734d2813c09215324e70c79c9e836bb8`

输入绑定：R136原时间/source JSON、R142 numeric_receiver.json（c46a9046…）、R142 time_primitive_check.json（44758cfa…），完整SHA在结果JSON；只依赖Python标准库和已有vendor mpmath。脚本fresh输出一次执行；已有失败P1恢复仅处理缺失case，成功后再次调用拒绝。未修改任何父代理或旧数据文件，未Git/PDF。完成停止。
