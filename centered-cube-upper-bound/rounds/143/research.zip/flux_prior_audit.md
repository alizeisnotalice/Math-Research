# R143 固定测试流、实际删源与signed门独立先审

本稿不读取R143作者 `newscore_flux_budget` 或其他作者证明；仅读原RT2–4及R135历史的相关少量接口。只写本文件，无Git/PDF/新数值。固定支持命题通过；实际删源、Ψ图、时间窗与外测度费用必须分别保留。

## FPA1. 任意有限ν的固定支持恒等式

令n有限、ν为非零有限正测度，a_i(z)>0可测，0<τ≤h≤2τ，w_t=∏min(1,a_i/t)，e_t=∫w_tν，Π_t=w_tν/e_t，k_t=#{a_i<t}，f∈[0,1]可测且与t无关。记u=logt、μ(u)=E_(Π_t)f。

每个来源的w在u上连续、绝对连续，几乎处处∂_u w=−k_tw；|∂_uw|≤n可由有限ν支配。e_t≥e_h>0是本给定非零数据上的合法性下界，不是输入无关预算。分子∫fwν与e皆AC，商μ亦AC，故几乎处处

\[
-\mu'(u)=\operatorname{Cov}_{\Pi_t}(f,k).
\]

任意ν可含重复阈值、阈值原子或连续阈值分布；Fubini给几乎处处微分，阈值会改变k的单侧版本，却不使w/e/μ跳跃。因此本式不含dk的阈值注入原子。严格a_i<t在时间积分中与右态版本相同；端点μ直接按连续权w取值，无额外阈值收费。ν=0行不定义Π，按原零交通处理。

定义主代理的D⁺、D⁻。因为交换v/u后

\[
\iint(f_v-f_u)_+(k_v-k_u)d\Pi_t^2
=\tfrac12\iint(f_v-f_u)(k_v-k_u)d\Pi_t^2
=\operatorname{Cov}_{\Pi_t}(f,k),
\]

得到准确

\[
\boxed{-d\mu=(D^+-D^-)du,qquad
\int_{\log\tau}^{\log h}D^+du
=\mu_\tau-\mu_h+\int D^-du
\le1+\int D^-du.}
\]

没有遗漏1/2：它只在对称完整pair公式中出现，单侧f正差定义已完成该对称化。D±有限；例如(f_v−f_u)₊≤f_v(1−f_u)，故D±≤nμ(1−μ)≤n/4，粗reverse价仍为nlog2/4，不是root价。

## FPA2. terminal good的最尖端点信息

固定接收x、共同原尺度及时间窗后，原w_g、S_g/D_g、A=w_τ−w_h、B/E/U、α及ρ可作为与t无关的对象；FA与k_t不能固定。取G为该固定terminal good集合、f=1_Gρ，0≤f≤1，则原G×bad的正接受流（保留Ψ、FA等≤1）至多D⁺，因为bad上f=0而good上f=ρ。若原bad仅是终端D_g⊂Gᶜ，仍是正流子集，不得将其signed流当成全补集cut。

端点无需粗收1：精确μ_τ−μ_h保留同一ρ；上界可收μ_τ≤Π_τ(G)。若G⊂Z_h为terminal存活支持，即使后来纳入删源也有

\[
N_\tau-N_h=\int_G\rho(w_\tau-w_h)d\nu,
\quad N_t=\int_G\rho w_t d\nu,
\]
\[
\boxed{\mu_\tau-\mu_h
=\frac1{e_\tau}\int_G\rho A\,d\nu
-\left(1-\frac{e_h}{e_\tau}\right)\mu_h
\le\frac1{e_\tau}\int_G\rho A\,d\nu.}
\]

这是比单位端点更具体的原terminal good余通量；它仍含ρ、ν与归一化e_τ，不给其免费输入质量帽。固定支持时另有w_h≥(τ/h)ⁿw_τ，所以μ_τ−μ_h≤[1−(τ/h)ⁿ(e_τ/e_h)]μ_τ≤(1−(τ/h)ⁿ)Π_τ(G)。可保留实际ratio及good质量，而不是自动用1。归一化的精确端点差也可写∫_Gρ[dΠ_τ−dΠ_h]，正部给其非负上帽。

原high若在g给terminal bad质量信息，不能直接把Π_g的good帽套到Π_τ或Π_h；时间tilt、实际Z和e ratio须证明。原f虽可对每个x固定，却依x及共同ν，不能因此移出接收积分或按来源重选α。

## FPA3. 实际Π含Z_t：完整删除补偿

RT4实际Π_t=1_(Z_t)w_tν/e_t，Z_t可随t删除。仅知道它在固定t不依x，不等于在整个时间区间不变。固定支持FPA1只能逐未删除区间使用。

对单调删除情形，设χ(u,z)=1_(Z_(e^u))(z)为共同可测、逐z右连续非增，取e,N的同一右态。定义非负删除流

\[
dL(u,dz)=w_{e^u}(z)\,d\nu(z)[-d_u\chi(u,z)],
\quad dL_1=\int dL,\quad dL_f=\int f(z)dL.
\]

删除可以给原子、连续或奇异连续时间测度；权本身的阈值没有原子。非负Fubini/Stieltjes乘积给

\[
de=-eE_{\Pi}k\,du-dL_1,qquad
dN=-eE_{\Pi}(fk)\,du-dL_f.
\]

在e>0区间，连续部分准确为

\[
d\mu^c=-(D^+-D^-)du+
\frac{\mu\,dL_1^c-dL_f^c}{e}.
\]

在删除时u₀，记删除前后e₋,e₊>0、l=e₋−e₊、l_f=N₋−N₊，则

\[
\boxed{\Delta\mu
=\frac{\mu_-l-l_f}{e_+}
=\frac{\mu_+l-l_f}{e_-}.}
\]

这不是阈值穿越补偿。若e₊=0而选原零交通后μ₊=0，必须单列灭绝跳Δμ=−μ₋；不用含e₊的商。原terminal存活e_g>0行使整个实际区间e≥e_g，避免该零商，但e_g仍无免费统一下界。

把连续删除项和上述全部jump记为signed C_del，则准确余额

\[
\int D^+du=\mu_\tau-\mu_h+\int D^-du+
C_{del}((\log\tau,\log h]).
\]

若只求正上界，应加C_del的正变差，而非假定它≤0。任意f∈[0,1]有|Δμ|≤l/e₋，连续部分的正变差≤dL_1^c/e。因此在正终端质量行，可保留明确删除价

\[
\mathcal R_{del}=\int\frac{dL_1^c}{e}+
\sum\frac{l}{e_-}
\le\log(e_\tau/e_h),
\]

后一界用l/e₋≤log(e₋/e₊)及log e的连续余额。该ratio可很大，不能视为常数或改成已付N_Z返还。

对实际terminal f=1_Gρ、G⊂Z_g⊂Z_h，删除源上f=0，故dL_f=0，连续补偿μdL/e非负，跳变Δμ=μ₊l/e₋≥0。它们逐项≤上述normalized删除价，提供可尝试与原未消费N_del匹配的量；是否真正匹配必须核同一外行、时刻、系数及原门，不能凭“N_del”名称自动抵消。

历史定位：R135 `score_injection_audit.md` SIA2已记录实际Z删除及连续补偿不能省略；`proof.md` AF14（约828–842行）已记录归一化势的e漂移与删除正跳、原Ψ/门匹配缺口。此处固定f没有dk注入，但没有解除这些原门/外测度问题，不将接口重述登记新总预算。

## FPA4. 尚未消费N_Zc的signed上放方向正确

原RT2/3同一G×bad、Ψ、J_far及外测度中，正项带ρ χ_FA δ⁺，原N_Zc带δ⁻而不带ρ/FA。逐pair正确上界为

\[
\boxed{\rho\chi_{FA}\delta^+-\delta^-
\le\rho(\delta^+-\delta^-)=\rho(k_v-k_u).}
\]

右边减左边为ρ(1−χ_FA)δ⁺+(1−ρ)δ⁻≥0。因此这是把更负的原项向上放松；**没有给原负项附门**。若正项还含已付补集等接受因子≤1，相同方向成立。原N_Zc仅用当前未消费的同一份，不能重复领取已消费N_Z。R135的门警示不能被理解为否定这个明确合法的signed上界。

但是右边仍带同一Ψ图和J_far。即便无Ψ且bad=Gᶜ，令

\[
I_{GG}=\tfrac12\iint_{G\times G}(\rho_v-\rho_u)(k_v-k_u)d\Pi^2,
\]

则cross cut满足

\[
\iint_{G\times G^c}\rho_v(k_v-k_u)d\Pi^2
=\operatorname{Cov}(f,k)-I_{GG}.
\]

ρ通常不在G上常数，I_GG无自动符号，不能把cross signed流直接当−μ'。有Ψ时还要扣掉G×bad上(1−Ψ)的signed删边项；若bad只占终端Gᶜ的一部分，则再有G×[Gᶜ\bad] signed缺项。这些项无已证统一符号/付款，不能把可能被删除的负边免费补回，以全无门协方差冒作原signed目标。

Ψ是pair资格，不是自动可分one-source势。任意固定pair graph乘Π²的导数一般出现k_v+k_u−2E k，不能凭命名把它变成k_v−k_u；需真正的图势或门结构比较。原Ψ漏边与已消费N_Z的关系必须保留，不以全pair补边重复利用旧负账。

## FPA5. 时间切片和全部外费用

固定支持的endpoint公式针对整个单一区间。原J_far若是子区间，可在其自身端点用同一恒等式；若为有限多区间，端点价逐组件加总，不能只领一次μ_τ−μ_h。一般可测时间门不能免费升级为BV测试；若时间门m有BV，形式上要保留∫μ dm及删除补偿的同门积分。若原good/ρ也随t变，则还加E_Π[df]及跳变交互，不能沿用固定f式。

最终原外量仍为期望Σ_V,j的q⁻¹p(x,y)h_R(x−z)a_history dx dβ_V(y)dν_V(z)，以及原signed2Λ。positive接受流≤D⁺是合法上界，但其reverse流和normalized删除补偿仍需在**同一**外测度下付款；原hard z不需存活，β不改ν，两份e分母始终属于Π²。若端点粗界≤1且合法时间组件只有一个，恢复外积分至多给原T_small≤4X的2Λ·4X=8ΛX粗费，不是可任意吸收的εX，也不是root Wβ。

若改用核接收包络，须付实际soft/L/menu及source/终端good质量平均。只有所有源和score/time效应先消成共同数值帽，才有已审JT14唯一j合并；Ψ图/within-good/删除reverse等仍依j和来源时不能提前使用。固定ν概率或端点μ≤1没有这些外付款。

**独立先审结论：** 固定支持导数及单位/terminal-good端点通过；actual删源需完整连续/jump补偿。尚未消费N_Zc的同ρ signed上放方向通过，但Ψ图、within-good权差、J_far切片与删除匹配阻止直接替换为完整cut导数。剩余reverse/图缺陷/删除及原hard/q、dx、β、j/menu费用均保留；未认一般root预算。未读新作者稿，交付后停止。

## FPA6. 作者冻结post-audit绑定与终端概率

FPA1–5独立记录保留不改。随后只实读冻结作者 `score_flux_budget.md`，绑定SHA256 **`17d71c48005748a8971caf2fef2a6e86ac219e1b0efe9a76d39dd6e7081a6e62`**。本后审不运行或重核父代理数值菜单，不打开新研究任务。

SF143.2把先审FPA4的上放升级为完整差额身份，括号(1−ρ)δ⁻+ρ(1−χ)δ⁺确为非负，保留原Ψ/时间域，负项系数仍是−1。旧已付正支若删去，可并入χ_eff≤χ_FA；否则完整正项身份只给未付正项上界。没有给负项附这个positive补集门。

SF143.3–6正确改用固定**terminal集合**Z_g上的π_t^g，而非在actual Z_t上丢掉删除项。e_g*(t)=∫_(Z_g)w_tν随t变化，不是e_g或Π_g；ν(Z_g)=0时good空，禁止除零。此固定支持上f=ρ1_G AC导数成立，cut层蛋糕参数总质量1且无链要求；SF143.6无需额外1/2。其辅助π仍可能因terminal g/G及实际接收行而依x，不产生移出dx的新资格。

在Z_g内G、D₀构成原fixed good/bad分割时，SF143.7–8正是FPA4的weighted covariance拆分：全cut贡献=G×D₀ full边+M_G，再扣Ψ缺边。M_G与M_Ψ无一般自动符号，作者未先行将它们登记付款。若原D_g定义已限制terminal支持，则后述future块为空；若含其他时刻存活bad，则保留其真实域，不能补造新的bad来源。

## FPA7. SF143.9–12实际归一化、窗口/BV和future域

actual Π_t在Z_g两端的乘积准确为(e_g*/e_t)²(π_t^g)²，SF143.9的ω因此保留原**两份**e_t分母。代入完整pair身份给SF143.10准确等式；没有因为ratio≤1就替换signed积分权。ρ在完整该接收行时间段固定，χ可随pair/t变化，全部松弛照原域保留。

F是AC，所以任意可测J_far下−∫ωdF本身合法。只有ω为BV、端点版本相容时，分部积分才给ω(τ)F(τ)−ω(h)F(h)+∫F dω，且上帽≤1+Var₊ω。e_g*与e_t分别非增并不使ratio自动单调；实际删除导致其正跳已进入ω。单调右态Z_t、有限ν、正terminal e_g下ratio为有限BV，但其正变差仍须支付，不因存在而消失；一般剪窗另加窗边界，任意可测窗不授予BV常数。

少量实读R122 `weighted_suffix_integration_private.md` 第5–7行：在**原初始heavy窗**合同下，e_t≥e_g>ell q c_j^(−n/2)gⁿ≥ell q c_j^(−n/2)tⁿ，整段[τ,h]属于原heavy窗，故J_far=[τ,h]至端点零测。作者的条件调用准确；另剪positive/negative窗不得继承此事实。即便消去窗指示，ratio仍保留。

SF143.12的future域恰为原G×[D_g∩(Z_t\Z_g)]，positive/negative、Ψ、FA与时间均仍取actual Π_t；它不属于π_t^g。N_del是否匹配这个future signed块须核原域、时刻、history及系数。固定terminal测试避免显写FPA3的删除μ补偿，但不能因此免费消掉归一化ω或future块；两种记账只是放置补偿的位置不同。

## FPA8. SF143.13–15保留松弛后的内部good消去

定义f₀=(1−ρ)1_G、X₀=∫_(G×D₀)Ψ(1−ρ)Δ。逐pair

\[
X_0+L_{\rho,\chi}
\text{的被积函数}
=(1-\rho)\Delta+(1-\rho)\delta^-+\rho(1-\chi)\delta^+
=(1-\rho\chi)\delta^+.
\]

故SF143.13 X₀+L=U≥0完全准确。f₀在good内部的权差为−(ρ_v−ρ_w)，其内部cut项为−M_G。由于f+f₀=1_G，**把完整终端signed流**写成X_ρ−L=(X_ρ+X₀)−U，即得SF143.15：

\[
S_{surv}=-\int\omega\,dg-\int\omega M_\Psi^1du
-\int\omega U_{\rho,\chi}du.
\]

因此完整保留松弛后，无需另独立支付M_G。先审“不能把weighted cross流直接当cut导数”仍正确；作者不是证明M_G有好符号，而是改变测试为未加权1_G并同时改变缺Ψ项与正端抑制，从而精确抵消。

必须把SF143.10与SF143.15各作为一整套表示：前者是F端点、M_Ψ(ρ)、M_G及L；后者是g端点、M_Ψ¹及U。不得取较小的F端点搭配较小的未加权缺图项，或从一种表示抹掉M_G后保留另一种表示的松弛。未加权重组未证明总费用减少，作者已明确说明。

少量实读R138 `signed_flux_connection.md` SF6–7及其域声明：完整原后缀窗、e_t⁻²非减时，Ψ=0每pair的未归一全部后缀≤0，Stieltjes给其actual normalized signed积分≤0。这里ω(π_t^g)²正好回到actual Π_t²，所以−∫ωM_Ψ¹≥0；该符号不来自ω单调，也不是M_Ψ¹逐点非正。任意剪窗须重核符号，不能重定义Ψ。这个补图损失−正端抑制结构已有R138接口，本后审不重复登记新付款。

## FPA9. SF143.16共同α抑制及SF143.17外账

在A_v>0、原ρ≤(1−a_v−b_v)₊、a_v=DK₀/(TA_v)>0、b_v=αJ_v/(TA_v)≥0时

\[
1-\rho_v\chi\ge1-\rho_v\ge\min(1,a_v+b_v)
\ge\min(1,b_v).
\]

SF143.16对同一Ψ=1正Δ域积分这个下界，方向准确。其他原ρ强制零门只增强抑制；A_v=0行ρ=0，右比较系数另定义1而不计算0/0。所有来源共享同一R_x=αQ_J，不按pair再领容量。此下界属于已保留−U的一部分，不能在另槽重复扣减；它与Ψ=0缺图损失处于不同pair域，仍缺真正跨域配对/接收平均比较。

SF143.17完整拼回的是同一组：−∫ωdg+R_Ψ−A_(ρ,χ)+S_future−N_del。其与SF143.10等价（给定同一χ_eff）；若没有编码旧positive删除，只是未付signed项上界。原N_Zc只在pair身份中出现一次，已消费N_Z不返回，N_del未被凭名判相消。

恢复原q⁻¹p h_R a_history、dx、dβ(y)dν(z)、EΣ_(V,j)和2Λ时，所有缺图、抑制、future/删除及窗口变差仍在同一外行下。β未改ν，外hard z不需存活，ν相关允许；辅助terminalπ没有source乘积独立性含义。共同数值source帽尚未建立，不能提前合并j/菜单。就算某条件域行价≤1，恢复原T_small≤4X只有8ΛX粗价，非允许任意εX或root Wβ；作者正确保留这个边界。

## FPA10. 有限模型证据与最终结论

父代理 `signed_graph_check.json` 所报告179个positive main点，原N_Zc=0、missing-Ψ signed全负，以及I1 unweighted端点负而实际正量正，是**固定有限必要模型**的门/抵消压力证据。它支持“不能免费删除Ψ”的解释，但不证明所有实际行缺图量的符号/大小、抑制不足、FULL或一般付款失败。本后审未重跑或独立重算这些数值，不用它们替代SF143.10–17的解析核验。

附录裸score筛查只使用任意正阈值、有限r测度而非原C几何，给Eδ上确界n/4及完整时间nlog(b/a)/4；其积分推导与范围正确，不否定固定f的端点身份，也不是原完整问题的反例。不能把裸界不达root推成带good/ρ/Ψ及接收积分的目标不可能。

**作者post-audit结论：SF143.10、13–16及17 PASS，未发现需修复的公式错误。** 加权图、两份分母、BV窗口、内部good消去、common α抑制、futurebad/N_del域与不拼接两种signed表示均已准确保留。得到的是一般向量下的精确重组及明确抑制，不是新增统一付款；剩余需在真实外测度上控制势/跨Ψ域缺边/抑制组合及future删除匹配。独立先审保留，仅追加本文件，冻结hash交付后停止。
