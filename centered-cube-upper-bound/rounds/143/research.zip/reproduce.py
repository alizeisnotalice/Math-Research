"""Portable saved-data checks. Usage: python reproduce.py REPO EMPTY_WORK.
Requires Python >=3.11 and mpmath; no sampling, quadrature or PDF compilation.
"""
from pathlib import Path
import sys,json,zipfile,shutil,subprocess,hashlib
src=Path(__file__).resolve().parent
repo=Path(sys.argv[1]).resolve(); work=Path(sys.argv[2]).resolve()
assert not work.exists(), 'Use a new work directory'
work.mkdir(parents=True)
out=work/'centered_cube_round143_20261015';out.mkdir()
for name in ['numeric_flux.json','flux_recheck.py','signed_graph_check.py']:
 shutil.copy2(src/name,out/name)
inputs=[(139,'active_traffic_v2.json','centered_cube_round136_20261014','1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de'),(142,'numeric_receiver.json','centered_cube_round142_20261015','c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55')]
for rnd,name,folder,expected in inputs:
 with zipfile.ZipFile(repo/f'centered-cube-upper-bound/rounds/{rnd}/research.zip') as z: data=z.read(name)
 assert hashlib.sha256(data).hexdigest()==expected
 target=work/folder;target.mkdir(exist_ok=True);(target/name).write_bytes(data)
for name in ['flux_recheck','signed_graph_check']:
 subprocess.run([sys.executable,str(out/(name+'.py'))],check=True,stdout=subprocess.DEVNULL)
 got=json.loads((out/(name+'.json')).read_text()); expected=json.loads((src/(name+'.json')).read_text())
 assert got['cases']==expected['cases'],name
 for key in ('status','scope','method','precision'):
  assert got.get(key)==expected.get(key),(name,key)
print('PASS: both checks reproduce all case results; absolute input-path keys intentionally differ.')
