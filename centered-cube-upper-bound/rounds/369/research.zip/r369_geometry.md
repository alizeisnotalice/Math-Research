# R369 — Uniform adaptive radius-margin capacity

**FINAL PREFERRED THEOREM.** Define beta=1+1/n, s_eff=max(a,R_v/beta), and

    Bplus: sum e_i<=n[(1+beta)s_eff-R_u]^2/(4 beta s_eff).

Let I=exp(-1)-1/4 and Cplus_n=e sum_(j=0)^(n-1)exp[-I(j+1)/beta]<72. The actual selected capacity is at most Cplus_n/q_-. On the original R338 high-past contract,

    B_H(f,nu)<=G_(out,not Bplus)
        +epsilon_0[2+Cplus_n/(1+sqrt(n))]X_q+C338 W.     (P)

There is no new source fee. Set epsilon_0=epsilon/40 for a uniform epsilon X_q allocation. Bplus contains the fallback B and the entire old D, so this is a REPLACEMENT receipt, not an additional fee. Section 7 gives the complete capture-box proof and final constant. The fallback below remains valid but is not charged together with (P).

**Proved fallback theorem.** Put beta=1+1/n and s_eff(v)=max(a,R_v/beta). The branch

    B: sum_i e_i(u,v)<=n(2s_eff(v)-R_u)^2/(8s_eff(v)),
    e_i=(2|u_i-v_i|-(R_u-R_v))_+,

has actual small-receiver capacity at most C_n/q_-, uniformly in u,y and the measurable actual radius selector, where

    C_n=sum_(j=0)^(n-1)exp(-j/4)<=n, C_n<5.

It contains the entire R368 fixed-ratio D, so its receipt REPLACES that old receipt. On the unchanged R338 high-past contract,

    B_H(f,nu)<=G_(out,not B)
        +epsilon_0[2+C_n/(1+sqrt(n))]X_q+C338 W.          (1)

No new source fee is incurred. The coefficient in brackets is <4, so epsilon_0=epsilon/4 is valid. The original complement remains unpaid. Section 7 proves the preferred stronger capture-box mechanism (P); the fallback constant in (1) must not be assigned to Bplus.

## 1. Contract

E is the actual measurable Lebesgue receiver set of finite measure; f>=0 is in L1; a<=R_u<=b<=2a are cube SIDE LENGTHS. All masses are full matching masses:

    m_u=f(Q_u)=q_u R_u^n, q_-=3lambda/4<=q_u<=lambda,
    mu(du)=du/m_u, c_u(y)=1_(Q_u)(y), E_r={u:R_u<=r},
    J_r(y)=integral_(E_r)c_u(y)mu(du),
    V_r(y)=integral_(E_r)c_u(y)du, X_q=integral_E q_u du,
    W=integral f.

The original clock is ell=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr and ell([R,b])=R^(-n). Retain precisely

    K=exp(sqrt(n)), h*=(1+sqrt(n))/(epsilon_0 q_-),
    alpha=(1+sqrt(n))^(1/n),
    Z_y(t-)=integral_E c_w(y)1_(m_w<t)mu(dw),
    D0={2||u-v||_infinity<=alpha R_u}.

Write the original positive measure, including its loss, as

    dGamma=ell(dr)f(y)dy [1_(J_r(y)>=H)/J_r(y)]
      1_(u,v in E_r)c_u(y)c_v(y)(m_u-m_v)
      1_(m_u>K m_v)1_(Z_y(m_u/K-)>h*)mu(du)mu(dv).       (2)

Zero-J rows are zero. Then G_out=integral 1_(not D0)dGamma. K>lambda/q_- ensures R_v<R_u on this support. H, J, all strict gates, full f and the terminal clock atom are unchanged.

The screened general claim is: for any 0<kappa<1/4, put

    B_kappa={sum e_i<=kappa n(2s_eff-R_u)^2/s_eff},
    a_kappa=1/2-2kappa,
    C_(kappa,n)=sum_(j=0)^(n-1)exp(-a_kappa j).

For each actual u and source y,

    integral_E c_v(y)1_(R_v<R_u)1_(B_kappa)(u,v)mu(dv)
       <=C_(kappa,n)/q_-.                              (3)

The final B is B_(1/8). The parameter family records a rate tradeoff, not multiple stacked charges.

## 2. Actual-selector partition and minimum-radius floor

Set s_j=a beta^j, j=0,...,n. Because beta^n>=2, the n intervals [s_j,s_(j+1)), with the last upper endpoint included, cover [a,b]. Intersect them with [a,b]. Empty bins cost zero. Every actual receiver is assigned once, including endpoint atoms. This partitions the existing receiver field; it does not introduce an independent dR integration.

If v is in bin j,

    s_j<=R_v<=beta s_j,
    a<=s_eff(v)=max(a,R_v/beta)<=s_j.

For a nonempty selected bin, s_j<R_u and R_u<=2a, so

    R_u/2<=a<=s_eff<=s_j,
    c_j=(R_u-s_j)/s_j in [0,1],
    delta_j=1-c_j=2-R_u/s_j in [0,1].

The function g_u(s)=(2s-R_u)^2/s has derivative 4-R_u^2/s^2>=0 for s>=R_u/2. Thus the actual allowance is at most

    kappa n g_u(s_j)=kappa n s_j delta_j^2.              (4)

Also (2|v_i-u_i|-(R_u-s_j))_+<=e_i(u,v). Therefore selected real centers in this bin lie in

    u+[-(R_u-s_j)/2,(R_u-s_j)/2]^n
       +(kappa n s_j delta_j^2/2) B_1^n.               (5)

The floor max(a,R_v/beta) is retained. At R_u=2a and s_j=a, delta_j=0 and the allowed excess is zero. No negative margin or discarded minimum-radius block occurs.

## 3. Exact polynomial and endpoint-safe rate estimate

The disjoint face partition of a cube plus an l1 ball gives

    |[-L/2,L/2]^n+(t/2)B_1^n|
       =sum_(k=0)^n binom(n,k)L^(n-k)t^k/k!.

Consequently (5), normalized by s_j^n, has volume

    P_n(c_j,z_j), z_j=kappa n delta_j^2,
    P_n(c,z)=sum_(k=0)^n binom(n,k)c^(n-k)z^k/k!.

For theta>0,

    P_n(c,z)<=(c+theta)^n exp(z/theta).                 (6)

Expand the right side and retain the nonnegative terms with equal binomial and exponential degrees k. Their sum is exactly P_n. This proof also handles c=0; it does not divide by c.

For delta=1-c>0 choose theta=delta/2. Using log(1-delta/2)<=-delta/2,

    P_n(c,kappa n delta^2)
       <=exp[-n delta/2+2kappa n delta]
       =exp(-a_kappa n delta).                        (7)

At c=1, delta=0, P_n(1,0)=1, so (7) remains true by direct evaluation. At c=0, theta=1/2 is valid. Thus the near-critical ratio and the opposite endpoint need no patched cutoff.

Since m_v>=q_-s_j^n, the selected actual mu capacity in bin j is bounded by exp(-a_kappa n delta_j)/q_-. The volume is real receiver dv, not a source f-mass bound. Additional original common-source, time, mass or past restrictions can only reduce the positive integral.

## 4. All-bin summability

For every relevant bin,

    delta_j>=2-2beta^(-j)>=2j/(n+j),
    n delta_j>=2nj/(n+j)>=j, 0<=j<=n-1,                (8)

using R_u<=2a and beta^j>=1+j/n. Summing the disjoint actual bins proves (3):

    C_(kappa,n)=(1-exp(-a_kappa n))/(1-exp(-a_kappa)).

Bins with s_j>=R_u have no strictly smaller selected receiver and can be included harmlessly in this positive upper bound. The first critical bin costs at most 1/q_-; the subsequent bin costs form a geometric series. This explicitly pays the full radius-selector union.

For kappa=1/8,

    C_n<=n,
    C_n<1/(1-exp(-1/4))<5.                             (9)

The final inequality follows from exp(1/4)>5/4. The n-bound is NONSTRICT: C_1=1. This avoids incorrectly writing C_n<min(n,5) for n=1.

## 5. Direct original high-past payment and exact complement

For any nonzero pair in (2), every w in its global strict mass past satisfies

    R_w^n=m_w/q_w<m_u/(Kq_-)
       <=[lambda/(Kq_-)]R_u^n<R_u^n.

Since u is in E_r, all such w are in E_r. Hence J_r(y)>=Z_y(m_u/K-)>h*. This is the existing past gate, not a new H choice.

Using m_u-m_v<=m_u, (3) and m_u mu(du)=du, the selected pair row divided by J is at most C_n V_r(y)/(q_-J_r(y)). It vanishes for J<=h*. Therefore

    G_(out,B)<=C_n X_q/(q_-h*)
       =epsilon_0 C_n X_q/(1+sqrt(n)),                 (10)

by the unchanged identity integral ell integral f V=X_q. No new source fee or square credit is used.

The inherited R338 statement is

    B_H(f,nu)<=G_out+2epsilon_0 X_q+C338 W, nu<=f,
    C338=(lambda/q_-)[(2+3sqrt(n)+2exp(-sqrt(n)))/epsilon_0
                     +1+sqrt(n)].

Together with the exact split G_out=G_(out,B)+G_(out,not B), this proves (1). For n<=3, C_n/(1+sqrt(n))<sqrt(n)<2; for n>=4 it is <5/3<2. Thus epsilon_0=epsilon/4 gives at most epsilon X_q and the unchanged root-order fee C338(epsilon/4,n).

The unpaid G_(out,not B) retains all of (2) and precisely

    2||u-v||_infinity>alpha R_u,
    sum e_i>n(2max(a,R_v/beta)-R_u)^2/[8max(a,R_v/beta)].

Equality belongs to the paid branch. This complete positive complement is still unestimated.

## 6. Old D is replaced; new lower ratios are covered

For n>=8, old D required R_v>=3R_u/4 and sum e<=nR_v/64. On it,

    beta<=9/8, 8R_v/9<=s_eff<=R_v,
    2s_eff-R_u>=4R_v/9.

Thus the B allowance is at least 2nR_v/81>=nR_v/64. Old D was empty for n<8. Hence D subset B in every dimension and its former d_n receipt is REPLACED, not added. Old N/A and center recapture remain already paid by R338's D0.

For a strictly lower-ratio example take n>=128, b=2a,

    R_u=2a, R_v=5a/4, u=0, v=(11a/10)e_1,
    y=(3a/5)e_1.

Then y lies strictly in both cubes, R_v/R_u=5/8<3/4, and sum e=29a/20. Here s_eff=5an/[4(n+1)] and the B allowance is

    a(n-4)^2/[40(n+1)]>29a/20.

The inequality holds at n=128 and the left side increases for n>4. Also (11/10)^n>=1+n/10>1+sqrt(n), so alpha<11/10 and the pair is outside D0. Uniform full f on a containing box gives mass ratio (8/5)^n>exp(sqrt(n)) here. This verifies geometric/far-mass coverage beyond old D. It does not claim arbitrary H/high-past gates or a fixed covered fraction; a full difficult-input witness requires those independent checks.

The criterion is continuous in actual R_v except for the harmless floor junction and imposes no fixed ratio cutoff. It permits ratios approaching 1/2 as their actual radius margin allows, but does not claim to pay every such pair.

## 7. Preferred capture-enhanced theorem Bplus

This preferred mechanism replaces the fallback with its own capacity constant. The slice and Laplace arguments below were independently checked; no external theorem is required.

Fix 0<kappa<1/2. Define

    T_cap(v)=kappa n[(1+beta)s_eff(v)-R_u]^2/[beta s_eff(v)],
    B_cap={sum e_i<=T_cap(v)}.

The function [(1+beta)s-R_u]^2/(beta s) increases for s>=R_u/(1+beta), which includes s>=a. Therefore T_cap(v) is bounded in bin j by T_cap(s_j). Besides the excess body, real capture c_v(y) implies v belongs to the cube of center y and side beta s_j.

For a symmetric excess body sum_i(2|v_i-u_i|-L)_+<=t, each coordinate slice is an interval centered at u_i. At fixed other coordinates, its overlap with a translated interval of fixed length is maximized when that interval is centered at u_i. Apply this fact successively in all coordinates, using Fubini. The intersection with the capture box is therefore largest when y=u. This is a deterministic real-center volume comparison, not an assertion that f has independent coordinates.

Write s=s_j, L=R_u-s, and

    delta=((1+beta)s-R_u)/(beta s)=1-L/(beta s) in [0,1].

On the centered capture box of side beta s, the normalized Lebesgue coordinate excess divided by beta s delta has distribution

    (1-delta) atom_0 + delta Uniform[0,1].

Only these UNIFORM CENTER coordinates are independent. For any t>0 their one-coordinate Laplace transform is

    1-delta+delta(1-exp(-t))/t
       <=exp{-delta[1-(1-exp(-t))/t]}.

The lower-tail event sum excess<=kappa n beta s delta^2 consequently has probability at most

    exp(-n delta I_kappa(t)),
    I_kappa(t)=1-(1-exp(-t))/t-kappa t.                  (11)

For every kappa<1/2, I_kappa(t)>0 for sufficiently small t>0; this follows from the elementary expansion (1-exp(-t))/t=1-t/2+O(t^2). A fully explicit choice is kappa=1/4,t=1, giving I=exp(-1)-1/4>0.

Actual bin capacity is at most beta^n exp(-n delta_j I)/q_-. Since beta^n<=e and

    n delta_j>=(1+2nj/(n+j))/beta>=(j+1)/beta,

all bins have the explicit total bound

    Cplus_n=e sum_(j=0)^(n-1)exp[-I(j+1)/beta]
       <e/(exp(I/beta)-1)<=e beta/I<72.                (12)

For the final fixed kappa=1/4,t=1, I=exp(-1)-1/4>1/12 because e<3. Also beta<=2. Thus the last constant is rigorous: e beta/I<3*2*12=72. The elementary estimate exp(x)-1>=x was used. This is a dimension-independent total over ALL actual bins, not a free uncountable union. It is larger than the fallback constant because the paid geometry is broader. No optimization of 72 is claimed.

For kappa=1/4, B_cap contains the fallback B: at every s>=a, putting d=2s-R_u>=0 gives

    [(1+beta)s-R_u]^2=(d+(beta-1)s)^2>=d^2,
    (1/4)/beta>=(1/8), since beta<=2.

At kappa=1/4 write Bplus=B_cap. It contains the fallback B, hence old D. The strict-past argument in Section 5 applies without change and gives

    G_(out,Bplus)<=epsilon_0 Cplus_n X_q/(1+sqrt(n)).

This proves the final preferred (P), with no new source fee. It REPLACES (10) and the R368 D receipt. Since 1+sqrt(n)>=2, the complete X_q coefficient is <38epsilon_0; choosing epsilon_0=epsilon/40 safely gives at most epsilon X_q. C338 then has its original formula evaluated at epsilon/40 and remains root-order. The fallback's smaller constant is not borrowed for this broader branch.

The exact remaining G_(out,not Bplus) retains all of (2), including h*, and precisely

    2||u-v||_infinity>alpha R_u,
    sum e_i>n[(1+beta)max(a,R_v/beta)-R_u]^2
                    /[4 beta max(a,R_v/beta)].

This is a complete positive split; the strict complement is unpaid. The general capture theorem only asserts kappa<1/2. No attainment or positive rate is claimed at kappa=1/2.

## 8. Actual local arithmetic evidence

The Fraction code appended below was actually run. It returned:

    PASS {'generating_polynomial':147,'actual_bin_envelope':2868,
          'rate_sum':183,'old_D_inclusion':96,
          'outside_new_ratio':3} total 3297

These are finite algebra/geometry diagnostics for the fallback theorem, not full high-past certificates. Section 7 is supported by the analytical proof above, not by these tests. No optimization or counterexample search was run.

~~~python
from fractions import Fraction as F
from math import comb,factorial
from random import Random
rng=Random(369)
counts={'generating_polynomial':0,'actual_bin_envelope':0,'rate_sum':0,'old_D_inclusion':0,'outside_new_ratio':0}
for n in [1,2,4,8,16,32,64]:
 for c in [F(0),F(1,8),F(1,4),F(1,2),F(3,4),F(7,8),F(1)]:
  delta=1-c
  for kappa in [F(1,16),F(1,8),F(3,16)]:
   z=kappa*n*delta**2
   P=sum(F(comb(n,k))*c**(n-k)*z**k/factorial(k) for k in range(n+1))
   if delta==0:assert P==1
   else:
    theta=delta/2
    truncated_exp=sum((z/theta)**k/factorial(k) for k in range(n+1))
    assert P<=(c+theta)**n*truncated_exp
    assert c+theta==1-delta/2
   counts['generating_polynomial']+=1
for n in [1,2,4,8,16,32,64,128]:
 beta=F(n+1,n)
 for j in range(n):
  s=beta**j
  if s>2:continue
  delta_min=2-2/s
  assert n*delta_min>=j
  counts['rate_sum']+=1
  for q in [F(0),F(1,3),F(2,3),F(1)]:
   rv=s*(1+q/n)
   if rv>=2:continue
   for lam in [F(1,4),F(1,2),F(3,4),F(1)]:
    ru=rv+lam*(2-rv)
    seff=max(F(1),rv/beta)
    assert ru/2<=seff<=s<=rv<ru
    g=lambda x:(2*x-ru)**2/x
    assert g(seff)<=g(s)
    e=[F(rng.randrange(0,33),32) for _ in range(n)]
    d=[(ru-rv+x)/2 for x in e]
    binexcess=sum(max(F(0),2*x-(ru-s)) for x in d)
    assert binexcess<=sum(e)
    if sum(e)<=n*g(seff)/8:assert binexcess<=n*g(s)/8
    counts['actual_bin_envelope']+=1
for n in [8,9,16,32,64,128]:
 beta=F(n+1,n)
 for ru in [F(4,3),F(3,2),F(7,4),F(2)]:
  for ratio in [F(3,4),F(4,5),F(7,8),F(15,16)]:
   rv=ru*ratio
   if rv<1:continue
   seff=max(F(1),rv/beta)
   assert n*(2*seff-ru)**2/(8*seff)>=n*rv/64
   counts['old_D_inclusion']+=1
for n in [128,256,512]:
 ru=F(2);rv=F(5,4);d=F(11,10);y=F(3,5)
 seff=max(F(1),rv/F(n+1,n));e=2*d-(ru-rv)
 assert e==F(29,20) and e<n*(2*seff-ru)**2/(8*seff)
 assert rv<3*ru/4 and abs(y-d)<rv/2 and y<ru/2
 assert F(11,10)**n>1+n/F(10) and n*n>100*n
 counts['outside_new_ratio']+=1
print('PASS',counts,'total',sum(counts.values()))
~~~

Only /tmp/r369_geometry.md is written. Proofs are analytic; checks do not replace them.
