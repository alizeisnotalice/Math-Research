from fractions import Fraction as F
from itertools import product
from math import factorial

checks = 0

def pieces(x, l, base):
    lo, hi = x-l/2, x+l/2
    atom = max(F(0), min(hi,base/2)-max(lo,-base/2))/l
    out = [('a',atom,F(0),F(0))] if atom else []
    left_hi = min(hi,-base/2)
    if lo < left_hi:
        out.append(('i',F(1)/(2*l),-2*left_hi-base,-2*lo-base))
    right_lo = max(lo,base/2)
    if right_lo < hi:
        out.append(('i',F(1)/(2*l),2*right_lo-base,2*hi-base))
    return out

def cdf(laws, T):
    ans = F(0)
    for terms in product(*laws):
        coeff, shift, widths = F(1), F(0), []
        for typ,c,a,b in terms:
            coeff *= c
            if typ == 'i':
                shift += a
                widths.append(b-a)
        k = len(widths)
        if k == 0:
            ans += coeff * (shift <= T)
            continue
        vol = F(0)
        for mask in product((0,1),repeat=k):
            z = T-shift-sum((w for w,t in zip(widths,mask) if t),F(0))
            if z > 0:
                vol += (-1)**sum(mask)*z**k/F(factorial(k))
        ans += coeff*vol
    return ans

for n in (1,2,3):
    for R in (F(1),F(3,2),F(2)):
        for l in (F(1),F(3,2)):
            s=F(1)
            offsets=(F(-3,4)*l,F(-1,4)*l,F(0),F(1,4)*l,F(3,4)*l) if n<3 else (-l/2,F(0),l/2)
            for T in (F(0),F(1,8),F(1,2),F(1),F(2)):
                central=cdf([pieces(F(0),l,R-s)]*n,T)
                for xs in product(offsets,repeat=n):
                    val=cdf([pieces(x,l,R-s) for x in xs],T)
                    assert 0 <= val <= central <= 1
                    checks += 1

for n in (1,2,3,4):
    for delta in (F(1,4),F(1,2),F(3,4),F(1)):
        l=F(1); s=F(1); R=2-delta
        law=pieces(F(0),l,R-s)
        mixture=[]
        if delta<1: mixture.append(('a',1-delta,F(0),F(0)))
        mixture.append(('i',F(1),F(0),delta))
        T=n*delta*delta/4
        assert cdf([law]*n,T)==cdf([mixture]*n,T)
        checks += 1
        mean=sum((c*(b*b-a*a)/2 for typ,c,a,b in law if typ=='i'),F(0))
        assert mean==delta*delta/2
        checks += 1

lower=sum((F((-1)**k,factorial(k)) for k in range(10)),F(0))
upper=sum((F((-1)**k,factorial(k)) for k in range(9)),F(0))
assert F(0)<lower<upper<1
assert lower-F(1,4)>F(1,12)
checks += 2
print('PASS', checks, 'exact Fraction checks')
