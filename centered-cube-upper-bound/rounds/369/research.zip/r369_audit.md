# R369 independent audit — FINAL PASS

Status: FINAL PASS for the preferred capture-box proposition, the author proofs, the actual lower-ratio witness, final integration and the bounded code/result audit. No unresolved correction was found in the reviewed statements. Only this audit file is reviewer-owned; no author/repository file was edited. No general root closure, fixed covered proportion, or complete historical reduction audit is certified.

## Independent preferred-proposition screen before author proofs
Freeze R338/R368 full-f actual hard matching, real finite-Lebesgue E, a<=R<=b<=2a, m=qR^n, q_-=3lambda/4<=q<=lambda and unchanged original mu,J,H,strict mass/global-past/physical-clock/exterior gates. K=e^sqrt(n)>lambda/q_- gives R_v<R_u. Set beta=1+1/n,w=max(a,R_v/beta), and the preferred B allowance T_B=n[(1+beta)w-R_u]^2/(4beta w). This is NOT the distinct smaller fallback allowance n(2w-R_u)^2/(8w).

Actual small radii occupy at most n disjoint geometric bins with lower s=a beta^j because beta^n>=2. Within any nonempty selected bin,w<=s<R_u and w>=a>=R_u/2. The threshold T(x)=n[(1+beta)x-R_u]^2/(4beta x) is nondecreasing for x>=R_u/(1+beta), so the original allowance is <=T(s). Replacing R_v by s lowers the coordinate excesses and enlarges the original center set. Capturing the SAME original source y implies the small center belongs to Q_(beta s)(y).

For the low-excess body, each one-coordinate slice is a centered interval about u_i (possibly empty). Its intersection with any interval of fixed length is maximized by centering that interval at u_i. Successively applying Fubini proves that the intersection volume with Q_(beta s)(y) is maximized at y=u. This is only a deterministic center-volume upper bound; no actual source y,J,q or qualification is changed. It neither assumes f coordinates independent nor replaces source f mass by volume.

At that centered comparison, delta=((1+beta)s-R_u)/(beta s) lies in[0,1] for a relevant bin. Under UNIFORM center measure, normalized coordinate excess X=E/(beta s delta) has law (1-delta)atom0+delta Uniform[0,1]; its coordinates are independent only because this comparison box is Lebesgue-product. The event is sum X<=n delta/4. Its t1 Laplace transform1-delta/e yields exp[-n delta(e^-1-1/4)]<=exp(-n delta/12). Equivalently E X=delta/2,E X^2=delta/3 and e^-x<=1-x+x^2/2 give the same bound without estimating e^-1. At delta0 the bound is the trivial1 and no division is made.

Actual mass density is <=1/(q_-s^n), so the bin capacity includes beta^n<e<3. The crucial INDEX SHIFT is n delta_j>=[1+2n(1-beta^-j)]/beta>=(j+1)/beta>=(j+1)/2, using beta^j>=1+j/n and j<=n. Thus all bins cost <=3 sum_(j>=0)e^[-(j+1)/24]/q_-<=72/q_-. The+1 cannot be dropped while retaining72: it is supplied by beta-1 at the first bin. No uncountable free selector union, missing beta^n factor or missing n-bin charge occurs.

For n>=8, oldD is contained in preferredB: threshold is increasing inw>=R_u/2; at w=R_v/beta and R_u/R_v<=4/3, beta<=9/8 gives T/(nR_v)>=(1+1/beta-R_u/R_v)^2/4>=25/324>1/64. For n<8 oldD was empty. Thus B REPLACES oldD, rather than adding its fee.

The original G row uses loss<=m_u and m_u mu(du)=du, giving g_B<=72V/(q_-J). On its nonzero support the ORIGINAL strict global past lies wholly in the current physical prefix, so J>h*=(1+sqrt(n))/(epsilon0 q_-). Consequently G_out,B<=72epsilon0 X_q/(1+sqrt(n)), with NO new source fee. The exact new positive complement retains all original gates and sum excess>T_B. Combined with R338 the coefficient is epsilon0[2+C_n/(1+sqrt(n))], with C_n<=72; it is <=38epsilon0, so epsilon0=epsilon/40 safely bounds this slot by epsilon X_q. Original entrance2 and outerLambda apply; no global absorption margin is thereby granted.

## Final author notes after independent screen
Read /tmp/r369_geometry.md in full. Its fallback polynomial proof is valid: P_n(c,z)<=(c+theta)^n exp(z/theta), choosingtheta=(1-c)/2 gives the stated geometric bin sum<5. Endpointdelta0 is direct and C_1=1 is correctly nonstrict. Its fallback is narrower than the preferred capture-box B and contains oldD; the preferred B in section7 contains fallback because beta<=2. The fallback<5 constant or total<4 receiver coefficient must NOT be assigned to the larger preferred B. Section7 correctly proves the actual capture-body extremizer, Laplace rate, beta^n factor and all-bin sum, sufficient for the separate72 constant. The fallback, preferred branch and oldD are alternatives, never stacked payments. Author3297 Fraction checks concern fallback algebra/geometry only, not the whole preferred theorem or native high-past input.

Read final /tmp/r369_capture.md in full, including its added analytic second-moment proof. Its exact centered atom+uniform law, zero-threshold/extremizer boundary, delta0 convention and Chernoff direction agree with the independent screen. The sub-1/2 Laplace threshold is about the center law only. The HIGHsum coordinate law, central mean coefficient1/2 and outside-center joint-mgf subtraction are correct conditional geometric identities but do not pay the complement. In particular an upper Chernoff rate is zero below the mean, and source f weighting cannot be removed. The outside-center product subtraction preserves that original geometric gate and is not a new fee. Author1744 Fraction checks are finite CDF/atom/interval diagnostics, not a source-independence or full high-past realization.

## Actual lower-ratio witness
Read /tmp/r369_witness.md, its exact script and result JSON in full. PASS for n10000,lambda4/3,q_-=1,uniform compact fullf,epsilon0=119/3072,H=h*=310272/119. U at-.5e1 is overridden toR2 and V at.6e1 toR1.25; the baseline is a continuum radius field. U baseline is correctly NOT claimed to equal1, and removing U,V costs<2 since baselineR0>=1. All actual cubes lie inside source support, q=1, every y in positive-volumeY is captured, and strict global mass past>9794/3 exceedsH/h*.

For the full U times V, excess is1.45 plus/minus4rho, only in the first coordinate, actual ratio5/8<3/4 excludes oldD, and the exact rational threshold T_B=49985001125/100020001 exceeds that entire excess interval. The floor w=12500/10001 is retained. The rational alpha bound shows the whole boxes are also outside the old R338 center dilation. At the original b atom, J_b>H andJ_b<1+n, so the displayed positive lower bound keeps clock2^-n and both masses2^n,(5/4)^n. This certifies the new branch of original G_out at the STATED epsilon0/H, not every later epsilon/40 allocation, any fixed useful fraction, R355 terminal/path shell, or historical first-ever coverage. The22 exact parameter assertions accompany the analytic continuum construction, not a sparse-menu approximation.

## Local reviewer arithmetic
A reviewer-local Python Fraction exercise actually verified137 scalar assertions:136 shifted-rank-index inequalities for n1..16 and0<=j<n, plus25/324>1/64. This is exact arithmetic only, separate from the parent totals and no full pipeline repeat. No general complement budget is inferred.

## Final integration, code/results and evidence boundary
Read the final main, ledger, numeric notes and README against the reviewed geometry, capture and witness proofs. PASS. The preferred branch is B+ with C_n^+=e sum exp[-(e^-1-1/4)(j+1)/beta]<72. Its larger threshold is not assigned the fallback<5 constant. Old D is contained and its payment is replaced, not added; the positive remainder retains every original G_out gate and the strict excess-threshold complement. The final ledger ends with the exact unchanged bytes of /tmp/r368_ledger.md, explicitly marked as historical alternative accounting rather than extra terms.

The preferred hard-slot inequality, source coefficient C338, entrance 8lambda H W+2d_eff A_n Wnu/H+2B_H and outer Lambda=128/119 are consistent. The receiver coefficient is 2Lambda epsilon0[2+C_n^+/(1+sqrt(n))]. Taking epsilon0=epsilon/40 is sufficient because the bracket is<38; this choice also changes h* and C338 and the final main/ledger explicitly require recomputation. It does not certify remaining absorption or the independent entry/H fees. Source weighting, original physical clock including b atom, full J and original q field are frozen throughout. No additional square or path credit is deducted.

Read all four scripts and both result JSONs within their stated finite scope. The parent reports actual successful executions totaling6092 exact Fraction assertions:3297 fallback,1744 capture,1029 enhanced actual-bin tests,22 witness. This audit does not claim to have repeated those pipelines. The reviewer137 exact scalar assertions are separate and are not added to6092. The geometry/capture standalone scripts match the unique final tilde-fenced embedded Python blocks after stripping outer whitespace. The two JSON counts/parameters agree with the final notes. Finite center-volume tests do not certify source independence, all dimensions, or native high-past realization; the specified n10000 witness has its separate analytic positive-volume construction. Its H/epsilon0 and coverage limitations remain explicit.

The HIGHsum/outside joint-mgf identity and smaller fallback are valid auxiliary tools, not additional paid branches. The precise unpaid preferred remainder is original G_out intersect excess>Tplus. All independent soft/crossing, entrance compatibility, other scale/threshold/low-pe/distance regimes, historical initial/deletion/future-source time atoms, source/physical-scale aggregation, outer integration and limiting obligations remain unpaid as listed in the final ledger. The review did not revalidate all historical coefficients or certify the final global n^(1/2+o(1)) bound. No PDF compilation, Git state, archive packaging or publication is part of this audit.

## Frozen byte bindings
SHA256 below binds the reviewed final bytes. The audit itself is hashed separately after saving.

- `/tmp/r369_main.md` — `12d0c216cf1dab0ec7b975b0b622aa7d64efc0a0a2e08f1cda50cfcfa2491c45`
- `/tmp/r369_ledger.md` — `dad79013a378bb021da53d4d02f87d7d3eb9bc204e08b2825bf4577d416ef538`
- `/tmp/r369_readme.md` — `d6d059ae0bea56eba44e5debbdf501eb4c5881f18e58d0d98773f9bf19eb65bd`
- `/tmp/r369_geometry.md` — `39a70e93ceda92a9ba5b7ad0cb70f3af3a4353f97defd80b472f33676de68a70`
- `/tmp/r369_capture.md` — `af64d3b83446d386c89a37114028dfd728faf4812d97a341b5338361556b4dbd`
- `/tmp/r369_witness.md` — `86d6ba189b225474409da6890c5c3a84400476dc704a7bcfe2be6bc12d8dff4d`
- `/tmp/r369_numeric.md` — `651fbcfaa9c46cc6bc4bfae5ee66c827e1da3627fba1e7042e6654d4f070b252`
- `/tmp/r369_geometry_check.py` — `fcfd3feda9e2f43caa9a3f85981d917291af8690c40cf199c8144d7db883ed40`
- `/tmp/r369_capture_check.py` — `b35443bf37a676311f865e7919544821672122e6a3b77e4de991932e66b796b9`
- `/tmp/r369_capture_bin_check.py` — `7ba3f06a027f0a7e065e6fbeffafdac06b3c6fd76065c538c74fbc2fbdb79966`
- `/tmp/r369_capture_bin_result.json` — `566d3e890a781e9c84d21c8def610aa4fa2c9908639af0844b3abed10b191e74`
- `/tmp/r369_witness_check.py` — `b0ffa2eb3b09d211bb2f1cc268de65788bb9a5efc5d520de2bf97a412514af29`
- `/tmp/r369_witness_result.json` — `87b12e9d3c593ab66ec6736b938330bd11c5369455583acf1f9a33ffe5d8d26a`

Necessary inherited contracts (bounded dependency review, not a fresh full-history audit):

- `/tmp/r338_main.md` — `69d779d69b422fe80e0ebfc92c9fe0eabe45bff783be6ce7eda8fdee9380a357`
- `/tmp/r368_audit.md` — `41b8e0c1beceb475bca738a3a3a678600c10e0396f16e00e44d0d8dd10c63653`
- `/tmp/r368_ledger.md` — `9e89db5695cb96db4e7b4736b792ea67fd6414baf230e2be295f236e58c31894`
- Authoritative R338 archive `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/338/research.zip` — `f86cab6035c70f44d83655981dcf34750b257ad9f8f4c4f50e1bde6fd5728820`; member `main.md` matches the bound R338 contract SHA above, as verified in the prior bounded dependency audit.

Final disposition: PASS within these contracts and evidence limits. No outstanding requested correction. Frozen; no further work is required for this bounded audit.
