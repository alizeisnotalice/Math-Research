from fractions import Fraction as F
from pathlib import Path
import json
counts={'bin_rate':0,'effective_threshold':0,'fallback_inclusion':0,'old_D_inclusion':0,'mixture_moment':0}
for n in [1,2,4,8,16,32,128,512,2048]:
 beta=F(n+1,n)
 for j in sorted(set([0,min(1,n-1),n//4,n//2,n-1])):
  s=beta**j
  if s>=2:continue
  for frac in [F(0),F(1,2),F(1)]:
   rv=s*(1+frac/n)
   if rv>=2:continue
   for t in [F(1,4),F(1,2),F(1)]:
    ru=rv+t*(2-rv)
    w=max(F(1),rv/beta)
    delta=((1+beta)*s-ru)/(beta*s)
    assert 0<delta<1 and n*delta>=(j+1)/beta
    counts['bin_rate']+=1
    T=lambda x:F(n,4)*((1+beta)*x-ru)**2/(beta*x)
    assert ru/(1+beta)<=w<=s and T(w)<=T(s)
    counts['effective_threshold']+=1
    assert T(w)>=F(n,8)*(2*w-ru)**2/w
    counts['fallback_inclusion']+=1
    if n>=8 and rv>=F(3,4)*ru:
     assert T(w)>=n*rv/64
     counts['old_D_inclusion']+=1
for k in range(101):
 d=F(k,100);mean=d/2;second=d/3
 assert 1-mean+second/2==1-d/3
 assert F(1,3)-F(1,4)==F(1,12)
 counts['mixture_moment']+=1
result={'counts':counts,'total':sum(counts.values()),'dimensions':[1,2,4,8,16,32,128,512,2048],'arithmetic':'exact Fraction','scope':'capture enhanced actual-bin envelope, rate lower bound and inclusions; no full-input proof from finite tests'}
Path(__file__).with_name('r369_capture_bin_result.json').write_text(json.dumps(result,indent=2))
print('PASS capture-bin',counts,'total',sum(counts.values()))
