# R369: A true high-past exterior witness below the former radius-ratio cutoff

This is a positive-volume original G_out witness in the new adaptive capture branch B and outside the old R368 branch D. It does not prove a useful covered fraction or general closure.

Set n=10000,a=1,b=2,lambda=4/3,q_-=1,f=1_[-3,3]^n,epsilon0=119/3072. Let K=exp100, alpha=101^(1/10000), h_*=H=310272/119. With delta=10^-6,rho=10^-7, define

    E=[-3/4+delta,3/4-delta]^n,
    R0(w)=max(1,2||w||inf+2delta),
    Y=[-delta,delta]^n,
    U=(-1/2,0,...,0)+[-rho,rho]^n,
    V=(3/5,0,...,0)+[-rho,rho]^n.

Use actual selector R=2 on U, R=5/4 on V, R=R0 otherwise. Both boxes lie inside E and are disjoint. The baseline on U is below3/2 (it is NOT claimed to equal1); on V it is below5/4. All actual cubes lie within the full source support, giving exact q=1 and m=R^n. Every y in Y is captured by every receiver; this follows from the baseline delta margin and the two override inequalities |center|+rho+delta<R/2.

On U times V the center separation has first coordinate11/10 plus/minus2rho and other coordinates at most2rho. The actual radius difference is3/4; hence the only nonzero excess lies in [29/20-4rho,29/20+4rho]. The ratio Rv/Ru=5/8 is strictly below3/4, so these pairs are OUTSIDE the old R368 D branch regardless of its sum condition.

Let beta=1+1/n and w_eff=max(a,Rv/beta). For the new B define

    T_B=(n/4)*[(1+beta)w_eff-Ru]^2/(beta w_eff).

Here beta w_eff=5/4 and w_eff=12500/10001. The exact rational script certifies the whole-box excess upper is less than T_B. Thus every such pair satisfies B. There is no radius-menu approximation in this assertion: the exact override radii are part of the actual selector, while the remaining field keeps a continuum of radii.

The old center dilation is also genuinely escaped. From(21/20)^100>101, alpha<21/20, and the separation lower11/10-2rho>21/20. Hence2||u-v||inf>alpha Ru. The big center is outside the small cube. The original N/A masks fail by their tiny thresholds, but this is not the relevant novelty criterion; failure of the stronger R338 center mask and of R368 D is certified explicitly.

For every receiver outside U, actual radius<=3/2. The inequality(4/3)^4>3>exp1 implies(4/3)^10000>exp100, so its mass is strictly below2^n/K. All such receivers enter the original GLOBAL strict past of each u in U. The baseline capacity is exactly

    integral_E R0^(-n)dw
      =(1-2delta)^n+n integral_1^(3/2)(r-2delta)^(n-1)r^(-n)dr
      >49n/150.

Bernoulli gives(1-2delta)^(n-1)>49/50 and log(3/2)>=1/3. Removing U,V costs at most their volumes, each<1, since R0>=1. Thus for all y in Y,

    Z_y(2^n/K-)>49n/150-2=9794/3>h_*=H.

At the original terminal clock atom r=b, J_b>=Z>H. All original strict mass, past, common-source, physical-prefix and exterior-center predicates hold simultaneously, and the pair is in B minus D. The universal actual-center estimate J_b<=1+nlog2<1+n therefore yields a strictly positive original contribution at least

    2^(-n)|Y||U||V|[2^n-(5/4)^n]/[2^n(5/4)^n(1+n)]>0.

The full receiver masses and terminal clock atom are retained. W=6^n is finite; no significant covered fraction is asserted. This construction uses its stated epsilon0/H, not all possible later absorption allocations; it does not assert R355 terminal-path shell qualifications or first-ever coverage across every historical alternative.

Local verification:22 exact Fraction assertions check the boxes, full capture margins, original past/high-J constants, alpha bound, actual adaptive threshold, and failure of the old ratio condition. These finite inequalities accompany the analytic continuum construction; they do not substitute for the general B proof.
