# R369 — Capture-centered low-tail extremizer and exact conditional law

Status: a proved center-geometry estimate, uniform in the actual source location. It supplies the capture-volume ingredient for the actual-radius argument in R369's main geometry file. It does not itself replace the common radius selector, pay the remaining HIGHsum branch, or use source-density bounds. The H05 Chernoff skill was used to check the product structure and tail direction; the proof below is self-contained.

## 1. Frozen contract and the precise geometric claim

The original hard field remains fixed: f≥0 is integrable, m_u=∫_{Q_u}f=q_u R_u^n, q_-≤q_u≤λ, a≤R_u≤b≤2a, μ(du)=du/m_u. In the original G_out all original source y, physical r, full J_y(r), strict past, far-mass, and outside-center masks remain unchanged. Cubes here have SIDE LENGTH as subscript. Only center Lebesgue volume is estimated below; no assertion identifies f-mass with volume.

Fix an actual large center u and radius R. For a deterministic comparison scale s≤R and a capture-envelope factor β>0 set l=βs and

    E_i(v)=(2|v_i-u_i|−(R−s))_+,
    B_T={v: Σ_i E_i(v)≤T},  T≥0.

For every y∈R^n (in particular for every actually captured source),

    |B_T ∩ Q_l(y)| ≤ |B_T ∩ Q_l(u)|.                    (1)

Thus the same source-independent upper bound holds after integrating either side against an arbitrary positive source measure. This operation does not create a source-density cap.

Assume first R<(1+β)s, and put

    δ=((1+β)s−R)/(βs) ∈ (0,1].

For 0≤κ<1/2 and any t>0,

    |Q_l(y) ∩ B_(κ n l δ²)| / l^n
      ≤ [exp(κδt){1−δ+δ(1−exp(−t))/t}]^n
      ≤ exp[−nδ I_κ(t)],                              (2)

    I_κ(t)=1−(1−exp(−t))/t−κt.

One may take the infimum of the first expression over t>0, or the supremum of I in the second. In particular,

    κ=1/4:  |Q_l(y) ∩ B_(n l δ²/4)| / l^n
                    ≤ exp(−nδ/12).                  (3)

If R≥(1+β)s, set δ=0; the asserted bound is the trivial bound 1. At equality R=(1+β)s the entire central capture cube lies in B_0, so replacing this by a strictly smaller bound would be incorrect.

## 2. Proof of the extremizer and the exact law

For fixed coordinates v_j, j≠i, a section of B_T in coordinate i is empty or an interval centered at u_i: the available remaining budget is nonnegative, and E_i is even and nondecreasing in |v_i−u_i|. An interval of fixed length l has maximal intersection with this section when its center is u_i. Fubini therefore allows replacing the i-th interval of Q_l(y) by the centered interval without decreasing the intersection volume. Do this for i=1,…,n. This proves (1), including T=0 and flat sections. No convex-body theorem or source independence is required.

Now let V be UNIFORM CENTER LEBESGUE MEASURE on Q_l(u). Its coordinates are independent. Each E_i(V) has an atom of mass (R−s)/l=1−δ at zero and density 1/l on (0,lδ). Equivalently,

    X_i=E_i(V)/(lδ) has law (1−δ)δ_0+δ Unif[0,1].     (4)

Consequently E X_i=δ/2, and

    E exp(−t X_i)=1−δ+δ(1−exp(−t))/t.

The event in (2) is ΣX_i≤κnδ. Apply Markov's inequality to exp(−tΣX_i), multiply the independent CENTER-coordinate Laplace transforms, and use log(1−x)≤−x with x=δ[1−(1−exp(−t))/t]∈[0,1). This proves (2).

For t=1, I_(1/4)(1)=e^(−1)−1/4>1/12. The strict inequality follows analytically from e<3: for k≥2, k!≥2^(k−1), with a strict inequality for k≥3, so Σ_(k≥0)1/k!<3. This proves (3); numerical approximations are not the certificate.

An independent polynomial certificate avoids exponential constants entirely: for 0≤x≤1, e^(−x)≤1−x+x²/2 (differentiate twice, or use the integral Taylor remainder). From (4), E X_i=δ/2 and E X_i²=δ/3. Thus E e^(−X_i)≤1−δ/3. Markov and 1−δ/3≤exp(−δ/3) give exp(nδ/4)(1−δ/3)^n≤exp(−nδ/12), proving (3) again. This is an analytic moment argument; no finite numerical approximation certifies an exponential inequality.

The threshold κ<1/2 is exact for this particular exponential bound: write A(t)=∫_0^1(1−e^(−tx))dx. Then A(t)<t/2 for t>0, while A(t)≥t/2−t²/6. Hence I_κ(t)>0 is possible exactly when κ<1/2. For example t=3(1/2−κ) gives I_κ(t)≥(3/2)(1/2−κ)². This is a statement about the Laplace exponent, not a claim that arbitrary source posteriors have this law.

## 3. Actual-radius use and all costs that this lemma leaves to the caller

If the unchanged actual selector is partitioned into a bin s≤R_v≤βs and R_v<R, then c_v(y)=1 implies v∈Q_(βs)(y). Also

    (2|v_i−u_i|−(R−s))_+
        ≤ (2|v_i−u_i|−(R−R_v))_+,
    1/m_v ≤ 1/(q_- s^n).

Therefore any selected bin subset on which the SUM of the left-hand protrusions is at most κnβsδ² has actual μ-capacity at most

    β^n exp(−nδ I_κ(t))/q_-.                          (5)

The same conclusion follows if the larger, actual protrusion sum satisfies that threshold. Every original positive mask may be retained. Formula (5) is a bound for real dv and a frozen actual-radius bin, not integration over an independently chosen radius. Its β^n factor and the sum over bins must be paid by the caller. This file does not assert their sum is bounded, nor add another source/receiver fee to the main ledger; Astra's separate actual-bin proof is responsible for that step. In particular β=1+1/n incurs β^n<e, not a hidden dimension-free factor equal to one.

The estimate retains the intersection with the capture cube before applying the tail bound. It is uniform over y, so no unknown source entropy is needed for this LOWsum direction. A quantitative comparison with a source-free envelope requires the actual bin parameters; no unproved superiority for all parameters is asserted.

## 4. Brief HIGHsum screening, with the outside-center gate preserved

For actual side s and y∈Q_R(u), write x_i=y_i−u_i and source depths d_i^±=R/2∓x_i. Under center-uniform V∈Q_s(y), let b_i^±=2(s−d_i^±)_+. The exact coordinate law has an atom

    p_0i=1−(b_i^++b_i^-)/(2s)

at zero, and densities 1/(2s) on each of (0,b_i^+) and (0,b_i^-), with multiplicities. Thus

    M_i(θ)=p_0i+(1/(2s))Σ_± ∫_0^(b_i^±) exp(θt)dt,
    mean_i=[(s−d_i^+)_+²+(s−d_i^-)_+²]/s.             (6)

Convexity and d_i^++d_i^-=R give, for s≥R/2,

    Σ mean_i ≥ n(2s−R)²/(2s),                        (7)

with equality at y=u. In particular the earlier /(4s) expression is not the exact central mean. The true central mean coefficient is 1/2. The κ<1/4 condition used in the earlier mixed-volume proof is a sufficient proof threshold, not this mean threshold.

For s_eff=max(a,s/(1+1/n)), R≤2a and s_eff≤s, the function (2s−R)²/s is nondecreasing on s≥R/2. Hence any threshold κn(2s_eff−R)²/s_eff with κ<1/4 is below the mean (unless the threshold and mean both vanish). The optimized ordinary upper Chernoff rate

    sup_(θ≥0){θT−Σ log M_i(θ)}

is zero whenever T≤Σmean_i, since the convex log-mgf has that derivative at zero. Therefore this HIGHsum-alone argument does not pay the complement of the new LOWsum gate.

This does NOT dispose of the original G_out geometry. For its actual enlarged-center gate 2||V−u||_∞>αR, α>1, put b_out=s+(α−1)R and

    M_i^in(θ)=p_0i+(1/(2s))Σ_± ∫_0^min(b_i^±,b_out) exp(θt)dt.

The precise joint-volume upper bound is

    P(ΣE_i>T, 2||V−u||_∞>αR)
      ≤ inf_(θ≥0) exp(−θT)[Π_i M_i(θ)−Π_i M_i^in(θ)]. (8)

The product subtraction is the exact exponential moment with the outside-center gate. For central y and s<αR it vanishes, even when the HIGHsum-only rate is zero. For general f, controlling its source-weighted actual-selector integral remains unproved here; q_u fixes only ∫_(Q_u)f. No boundary volume is substituted for source mass. The original high-past gate, clock, full J, and HIGHsum complement have not been changed or paid by (8).

## 5. Reproducible local arithmetic checks

The script below uses exact Fraction arithmetic to evaluate the full distribution of ΣE_i under translated capture cubes, by atoms plus interval convolutions and inclusion-exclusion. It tests the central extremizer at positive and zero thresholds in dimensions 1–3, the central mixture CDF, its exact first moment, and a rational Taylor certificate for e^(−1)−1/4>1/12. These finite checks are diagnostics; Sections 1–4 supply the proof. No source independence or favorable source sampling enters them.

~~~python
from fractions import Fraction as F
from itertools import product
from math import factorial

checks = 0

def pieces(x, l, base):
    lo, hi = x-l/2, x+l/2
    atom = max(F(0), min(hi,base/2)-max(lo,-base/2))/l
    out = [('a',atom,F(0),F(0))] if atom else []
    left_hi = min(hi,-base/2)
    if lo < left_hi:
        out.append(('i',F(1)/(2*l),-2*left_hi-base,-2*lo-base))
    right_lo = max(lo,base/2)
    if right_lo < hi:
        out.append(('i',F(1)/(2*l),2*right_lo-base,2*hi-base))
    return out

def cdf(laws, T):
    ans = F(0)
    for terms in product(*laws):
        coeff, shift, widths = F(1), F(0), []
        for typ,c,a,b in terms:
            coeff *= c
            if typ == 'i':
                shift += a
                widths.append(b-a)
        k = len(widths)
        if k == 0:
            ans += coeff * (shift <= T)
            continue
        vol = F(0)
        for mask in product((0,1),repeat=k):
            z = T-shift-sum((w for w,t in zip(widths,mask) if t),F(0))
            if z > 0:
                vol += (-1)**sum(mask)*z**k/F(factorial(k))
        ans += coeff*vol
    return ans

for n in (1,2,3):
    for R in (F(1),F(3,2),F(2)):
        for l in (F(1),F(3,2)):
            s=F(1)
            offsets=(F(-3,4)*l,F(-1,4)*l,F(0),F(1,4)*l,F(3,4)*l) if n<3 else (-l/2,F(0),l/2)
            for T in (F(0),F(1,8),F(1,2),F(1),F(2)):
                central=cdf([pieces(F(0),l,R-s)]*n,T)
                for xs in product(offsets,repeat=n):
                    val=cdf([pieces(x,l,R-s) for x in xs],T)
                    assert 0 <= val <= central <= 1
                    checks += 1

for n in (1,2,3,4):
    for delta in (F(1,4),F(1,2),F(3,4),F(1)):
        l=F(1); s=F(1); R=2-delta
        law=pieces(F(0),l,R-s)
        mixture=[]
        if delta<1: mixture.append(('a',1-delta,F(0),F(0)))
        mixture.append(('i',F(1),F(0),delta))
        T=n*delta*delta/4
        assert cdf([law]*n,T)==cdf([mixture]*n,T)
        checks += 1
        mean=sum((c*(b*b-a*a)/2 for typ,c,a,b in law if typ=='i'),F(0))
        assert mean==delta*delta/2
        checks += 1

lower=sum((F((-1)**k,factorial(k)) for k in range(10)),F(0))
upper=sum((F((-1)**k,factorial(k)) for k in range(9)),F(0))
assert F(0)<lower<upper<1
assert lower-F(1,4)>F(1,12)
checks += 2
print('PASS', checks, 'exact Fraction checks')
~~~

Execution record: the embedded script was actually run with local Python 3 and returned `PASS 1744 exact Fraction checks` (exit status 0).
