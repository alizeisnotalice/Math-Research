from fractions import Fraction as F
from math import comb,factorial
from random import Random
rng=Random(369)
counts={'generating_polynomial':0,'actual_bin_envelope':0,'rate_sum':0,'old_D_inclusion':0,'outside_new_ratio':0}
for n in [1,2,4,8,16,32,64]:
 for c in [F(0),F(1,8),F(1,4),F(1,2),F(3,4),F(7,8),F(1)]:
  delta=1-c
  for kappa in [F(1,16),F(1,8),F(3,16)]:
   z=kappa*n*delta**2
   P=sum(F(comb(n,k))*c**(n-k)*z**k/factorial(k) for k in range(n+1))
   if delta==0:assert P==1
   else:
    theta=delta/2
    truncated_exp=sum((z/theta)**k/factorial(k) for k in range(n+1))
    assert P<=(c+theta)**n*truncated_exp
    assert c+theta==1-delta/2
   counts['generating_polynomial']+=1
for n in [1,2,4,8,16,32,64,128]:
 beta=F(n+1,n)
 for j in range(n):
  s=beta**j
  if s>2:continue
  delta_min=2-2/s
  assert n*delta_min>=j
  counts['rate_sum']+=1
  for q in [F(0),F(1,3),F(2,3),F(1)]:
   rv=s*(1+q/n)
   if rv>=2:continue
   for lam in [F(1,4),F(1,2),F(3,4),F(1)]:
    ru=rv+lam*(2-rv)
    seff=max(F(1),rv/beta)
    assert ru/2<=seff<=s<=rv<ru
    g=lambda x:(2*x-ru)**2/x
    assert g(seff)<=g(s)
    e=[F(rng.randrange(0,33),32) for _ in range(n)]
    d=[(ru-rv+x)/2 for x in e]
    binexcess=sum(max(F(0),2*x-(ru-s)) for x in d)
    assert binexcess<=sum(e)
    if sum(e)<=n*g(seff)/8:assert binexcess<=n*g(s)/8
    counts['actual_bin_envelope']+=1
for n in [8,9,16,32,64,128]:
 beta=F(n+1,n)
 for ru in [F(4,3),F(3,2),F(7,4),F(2)]:
  for ratio in [F(3,4),F(4,5),F(7,8),F(15,16)]:
   rv=ru*ratio
   if rv<1:continue
   seff=max(F(1),rv/beta)
   assert n*(2*seff-ru)**2/(8*seff)>=n*rv/64
   counts['old_D_inclusion']+=1
for n in [128,256,512]:
 ru=F(2);rv=F(5,4);d=F(11,10);y=F(3,5)
 seff=max(F(1),rv/F(n+1,n));e=2*d-(ru-rv)
 assert e==F(29,20) and e<n*(2*seff-ru)**2/(8*seff)
 assert rv<3*ru/4 and abs(y-d)<rv/2 and y<ru/2
 assert F(11,10)**n>1+n/F(10) and n*n>100*n
 counts['outside_new_ratio']+=1
print('PASS',counts,'total',sum(counts.values()))
