# R427：原双保源路径的终端互中心事件——一次真实匹配付款

2026-10-20。本轮支付 R425 内一个未加权的实际终端事件：至少一个终端中心位于另一终端的指定扩张 cube 内。证明将完整匹配 \(f(Q_w)=m_w\) 用于两个来源的共同积分，消掉一份质量分母，再按真实中心容量结算。该事件与 R419 的初始见证事件不同；不重新抽样终端、不改原质量软权。其补集仍未获得一般根阶总预算。

## 1. 准确原场与新事件

沿用 `/tmp/r425_main.md` 的同一实际 \(\Pi425\)，总量为 \(R425\)。所有阶段 \(i\)、\(b_i,D_i\)、旧新来源 \(y,z\)、原父端 \(A\)、时钟、首次删除、early、全部历史/空间门及 R423–425 软权保持。完整 \(f\ge0\) 属于 \(L^1\)，
\[
 m_v=f(Q_v)=q_vR_v^n,\quad q_-\le q_v\le\lambda,\quad
 a\le R_v\le b\le2a,\quad
 \mu(dv)=dv/m_v,\quad \sigma(dA)=q_A\,dA,\quad
 \pi_A(dx)=f(x)c_A(x)dx/m_A .
\]
\(R_v\) 是边长。两条固定来源路径的终端分别记 \(w,t\)，停止后不复制终端。当前正支给
\[
 m_w,m_t<m_A/K^2,\quad
 Z_w(y)\le h,\quad Z_t(z)\le h,\quad
 w,t\notin Q_A,\qquad K=e^{\sqrt n}.
 \tag{1}
\]
取 \(\alpha\ge1\)，只扩张事件中的几何盒，不改变任何实际 cube、质量或路径核。定义
\[
 \mathsf E_\alpha^{\rm term}
 =\{w\in\alpha Q_t\}\cup\{t\in\alpha Q_w\}.
 \tag{2}
\]
本轮精确正分拆为
\[
 P_{\rm term}(\alpha)=\Pi425(\mathsf E_\alpha^{\rm term}),\qquad
 R_{\rm sep}(\alpha)=\Pi425((\mathsf E_\alpha^{\rm term})^c),\qquad
 R425=P_{\rm term}(\alpha)+R_{\rm sep}(\alpha).
 \tag{3}
\]
这里付的是事件上原费用的全部质量，不另乘一个节点质量权。

## 2. 一般真实匹配双矩

固定实际父 \(A\)，任意 \(\kappa>1\)，记
\(\mathcal E_A(\kappa)=\{v:m_v<m_A/\kappa\}\)。
对任意可测实际选择器与任意完整 \(f\)，有
\[
 \begin{aligned}
 \mathcal M_A^\to(\alpha,\kappa)
 :=\int\pi_A(dy)\pi_A(dz)
 \int_{\mathcal E_A(\kappa)^2}
 c_w(y)c_t(z)1_{\{w\in\alpha Q_t\}}\,\mu(dw)\mu(dt)
 \le\frac{\alpha^n}{\kappa q_-^2}.
 \end{aligned}
 \tag{4}
\]
反方向同界，故 whole union 上界为两倍。原 own-low、父外及其他正门均可保留在左端，证明上界时删除。

**证明。**置 \(I_{Av}=f(Q_A\cap Q_v)\)。先交换两个完整来源积分：
\[
 \mathcal M_A^\to=
 \frac1{m_A^2}\int_{\mathcal E_A(\kappa)}
 \frac{I_{At}}{m_t}\,dt
 \int_{\mathcal E_A(\kappa)\cap\alpha Q_t}
 \frac{I_{Aw}}{m_w}\,dw.
 \tag{5}
\]
由实际完整匹配 \(I_{Aw}\le f(Q_w)=m_w\)，内层不超过
\(|\alpha Q_t|=\alpha^nR_t^n=\alpha^n m_t/q_t\)。因此
\[
 \mathcal M_A^\to
 \le\frac{\alpha^n}{q_-m_A^2}
       \int_{\mathcal E_A(\kappa)}I_{At}\,dt .
 \tag{6}
\]
这一步是两来源共同结算中的实质质量消去，不能在缺少完整匹配的任意 incidence 模型中直接使用原生中心价格。

令 \(r_*=(m_A/(\kappa q_-))^{1/n}\)。严格质量门保证实际 \(R_t<r_*\)。对每个固定来源 \(z\)，所有捕获 \(z\) 的这些实际 \(t\) 中心均落在 \(Q_{r_*}(z)\)，所以
\[
 \begin{aligned}
 \int_{\mathcal E_A(\kappa)}I_{At}\,dt
 &=\int f(z)c_A(z)
       \int_{\mathcal E_A(\kappa)}c_t(z)\,dt\,dz\\
 &\le m_A r_*^n=\frac{m_A^2}{\kappa q_-}.
 \end{aligned}
 \tag{7}
\]
代回 (6) 即得 (4)。若 \(r_*\le a\)，严格小质量集为空，原积分为零；其余质量原子也保持原严格门。整个证明只扩大真实中心积分区域，不引入有质量的虚构 receiver，不将选择器边长当独立积分变量，也没有以体积控制任意来源密度。

引理 (4) 的数学机制是 R419 已证的匹配消去；本轮新增的是它对**原终端联合流**的合法应用及不同事件的实际付款，不把同一个引理重证称为新一般定理。

## 3. 原终端联合流的支配，不能免费恢复独立性

R426 已核如下真实退出核事实。固定来源 \(x\)，从 active 起点按原核
\[
 P_x(v,db)=1_{\{m_b<m_v/K\}}\rho_x(db)/Z_v(x),\qquad
 \rho_x(db)=c_b(x)\mu(db)
 \]
运行至 own-low，终端子核受
\[
 1_{\{Z_b(x)\le h\}}\rho_x(db)/h
 \tag{8}
\]
支配。其证明以 own-low 质量初段的 \(\rho_x\)-质量至少为 \(h\) 作首次退出归纳，保留严格质量原子；不按路径长度累加 \(\rho_x/h\)。

当前原流已保留初始 own-high 正限制。因此先对原 exclusive 初始 law 乘 active 指示，得到总量不超过一的子概率，再应用 (8)；没有初始 own-low Dirac 项，也不对 active 事件重新归一。来源仍是原来的 \(y,z\)。

给定原父及双来源，原两条完整路径在**生成时**条件独立。受全部未来门、R423 cross-affinity、R425 软权限制后的实际终端 law 通常不独立。本证明只在上界中删除这些未来正限制，然后使用原生成核及 (8) 的乘积，保留事件 (2) 和终端质量门 (1)。所得正支配为
\[
 h^{-2}\rho_y(dw)\rho_z(dt)\,
 1_{\{m_w,m_t<m_A/K^2\}} .
 \tag{9}
\]
随后在同一冻结场上共同求和 stage，使用
\(\sum_i b_i(z)\le1\) 和原逐旧来源两父端帽 \(\beta,C_{\rm col}\)，两父端合为 \(S=\beta+C_{\rm col}\)。于是 (4) 取 \(\kappa=K^2\) 给
\[
 \boxed{\displaystyle
 P_{\rm term}(\alpha)
 \le\Delta_{\rm term}(\alpha)X_q,\qquad
 \Delta_{\rm term}(\alpha)
 =\frac{2S\alpha^n}{K^2 q_-^2h^2}.}
 \tag{10}
\]
两倍只来自事件的两个方向；交集实际只删除一次。\(S\) 已含两父端，不再乘两端数、路径长度、stage 数或 \(\tau^{-1}\)。这里使用退出核 (8)，不能沿用初始 exclusive 分母的较小 \(B_L\) 系数。

本轮固定
\[
 \alpha=\alpha_{\rm term}=K^{2/n}=e^{2/\sqrt n},
 \qquad
 \boxed{\Delta_{\rm term}=\frac{2S}{q_-^2h^2}
            =\frac{2S\varepsilon_0^2}{s^2}},\quad
 s=1+\sqrt n .
 \tag{11}
\]
这是原未加权子分支的一笔可吸收型 \(X_q\) 价格；不宣称原全部吸收余额已自动满足。所有占用层合计也只收一次：
\[
 \sum_k P_{{\rm term},k}\le\Delta_{\rm term}X_q.
 \tag{12}
\]
没有由 (12) 推出整个单层余项的 \(P\) 型预算。

## 4. 与旧付款的区别、准确总账及剩余

R419 支付的是**初始**两个见证的互中心事件，扩张系数为 \(e^{1/\sqrt n}\)；没有将该条件传给终端。R423 控制全部跨链 \(f\)-亲和总量，但互中心接近并不强制 \(f(Q_w\cap Q_t)\) 大。下述真实中心模型同时具有初始分离、极小跨链亲和和终端互中心包含，因此本轮事件不被这些已认证的几何门排除；未认证的完整历史条件不作非空推断。

记 \(R_{\rm sep}=R_{\rm sep}(\alpha_{\rm term})\)，它是原 \(\Pi425\) 的正限制，完整补集为
\[
 w\notin e^{2/\sqrt n}Q_t,\qquad
 t\notin e^{2/\sqrt n}Q_w ,
 \tag{13}
\]
连同全部 R425 原标签。不存在来源刷新、历史重建或质量软权退款。设置
\[
 C_{\rm sep}=C425+\Delta_{\rm term},\qquad V_{\rm sep}=V425 .
 \]
保留原 \(\widehat F=(1-32\delta-16\eta)^{-1}\) 与 \(\Lambda=128/119\)，则
\[
 G_0\le16\widehat F\{R_{\rm sep}+C_{\rm sep}X_q+V425W\},
 \]
\[
 B_H\le32\widehat F R_{\rm sep}+
       (E387+32\widehat F C_{\rm sep})X_q+
       (S390+8s+32\widehat F V425)W ,
 \]
\[
 \mathrm{入口}\le\Lambda\{
 8\lambda HW+2d_{\rm eff}A_{{\rm entrance},n}W_\nu/H
 +64\widehat F R_{\rm sep}+(2E387+64\widehat F C_{\rm sep})X_q
 +(2S390+16s+64\widehat F V425)W\}.
 \tag{14}
\]
新增入口价格恰 \(64\Lambda\widehat F\Delta_{\rm term}X_q\)，没有新 \(W\) 价。原低维、全尺度及旧入口常数均未改。

对于剩余双终端分离支，R426 的实际父匹配式仍保
\[
 K^2\max(m_w,m_t)<m_A\le r,\quad
 f(Q_A)=m_A,\quad w,t\notin Q_A .
 \]
现在另有 (13)。但 (5) 的消分母机制依靠 \(w\) 中心属于指定 \(\alpha Q_t\)；在 (13) 上，不能仍以 \(\alpha^nR_t^n\) 控制该中心域。当前尚缺的是保留实际原门、双终端分离与真实父质量子水平的共同积分结算，不能将两份完整来源积分拆成 \(W^2\)，也不能把父排除体积当来源质量。故一般 \(R_{\rm sep}\le tX_q+C_t sW\) 仍未证明。本轮至此停止，不追加其他几何近支。

## 5. 三阶段本机证据

实际运行 `/tmp/r427_geometry_check.py`，使用标准库 Fraction。

1. 九个一维原生条件双矩以分段多项式精确积分核验 (4) 中的匹配消去。另三个非均匀完整来源模型取
   \(f=1_{[-3,3]}+\text{一个总质量为 }p\text{ 的中心 packet}\)，
   \(p\in\{1/20,1/10,1/5\}\)；父边长 2，子边长 1、中心在
   \([-0.3,0.3]\)。所有子 cube 均在父内并完整捕获 packet，
   所以 \(I_{Av}=m_v=1+p,\ m_A=2+p\)，两来源匹配消去可精确核算。
   这是固定父条件矩；若父中心与子中心域重合，将该一个中心指定父边长并从子域剔除该零测点，不改变原生子中心积分。
2. 二十七个均匀完整来源的原生张量模型，维数 \(64,144,256\)，严格质量间隔采用更强的 \(3^{2\sqrt n}>e^{2\sqrt n}\)，精确检查终端所用 \(K^2\) 双矩。张量化只用于这些明确均匀测试，不是一般 \(f\) 的独立性假设。
3. 三个正体积原生中心块模型，维数 \(144,225,400\)。完整
   \(f=1_{[-4,4]^n}\)。父中心在 0 附近、边长 2；
   两初始中心分别在
   \((1.1,-0.6,\ldots,-0.6)\)、
   \((1.1,0.6,\ldots,0.6)\) 附近、边长 \(3/2\)；
   两终端中心分别在
   \((1.1,-0.2,\ldots,-0.2)\)、
   \((1.1,0.2,\ldots,0.2)\) 附近、边长 1。
   中心块半宽 \(1/(1000n)\)。来源首坐标均为 \(0.65\)，第二坐标分别
   \(0.15-1/(100n)\)、\(-0.15+1/(100n)\)，其余分别为 \(-0.6,+0.6\)。
   严格不等式允许来源也在小邻域内变化。

第三阶段实际核验完整匹配 \(q=1\)、父外、初始 exclusive 与相对 collar、初始互中心分离、所有节点对父的 \(K^2\) 间隔、每步 \(K\) 间隔、R423 跨链亲和小于 \(1/8\)、R425 两软权保持正，以及终端互中心在未扩张 cube 内。它们是有正 Lebesgue 体积的几何/匹配兼容模型；**未认证**初始 own-high、原 \(\Gamma_i,D_i\)、重尾和完整时钟/历史条件，所以不声称构造了完整原 \(R425\) 正流实例。

实际输出：

```text
Stage 1 PASS: 9 native polynomial moments and 3 nonuniform full-f native cancellation cases
Stage 2 PASS: 27 native uniform-source tensor moments with strict gap stronger than K^2
Stage 3 PASS: 3 positive-volume native center-block geometry certificates
Stage 3: matching, terminal event, initial separation, both mass gaps,
R423 cross-affinity, R425 soft positivity, and initial collar checked.
NOT certified: initial own-high, original Gamma/stage/D/heavy-source/history.
ALL R427 CHECKS PASS
```

一般付款由 (4)–(11) 的原生证明给出，有限证据不替代一般证明，也不补齐未认证的历史。
