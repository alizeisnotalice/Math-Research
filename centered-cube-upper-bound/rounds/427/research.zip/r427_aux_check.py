from fractions import Fraction as F
from pathlib import Path
import json

# Actual n-dimensional Lebesgue center boxes, not point receivers.
# Source is a nonuniform finite union of product boxes of half-side 1/100.
def inclusion(center, side, point, center_width):
    radius=F(1,100)
    return abs(point-center)+radius+center_width/2 <= side/2

def exclusion(center, side, point, center_width):
    radius=F(1,100)
    return abs(point-center)-radius-center_width/2 > side/2

def native(nroot, ext, width):
    n=nroot*nroot; N=2**n; V=width**n
    assert 0<ext<=F(1,8)
    # Exact coordinate checks certify all source/center cells, including f=0 gaps.
    for sign in [-1,1]:
        assert inclusion(F(0),F(2),sign*F(4,5),width)
        assert exclusion(F(0),F(2),sign*F(3,2),width)
        for p in [sign*F(4,5),sign*F(3,2)]:
            assert inclusion(sign*F(23,20),F(1),p,width)
        for p in [-sign*F(4,5),-sign*F(3,2)]:
            assert exclusion(sign*F(23,20),F(1),p,width)
        assert inclusion(F(0),F(2),sign*F(1,2),width)
        assert inclusion(sign*F(1,2),F(1),sign*F(1,2),width)
        assert exclusion(sign*F(1,2),F(1),-sign*F(1,2),width)
    assert F(23,20)-width/2 > 1+width/2 # All child centers outside every parent cube.
    mA=F(N); mw=1+ext; qA=mA/F(2**n); qw=mw
    assert qA==1 and 1<=qw<=F(4,3)
    # e<11/4 gives a certified STRICT m_w<m_A/exp(2sqrt(n)).
    assert mw*F(11,4)**(2*nroot)<mA
    h=F(2*(1+nroot)); a=V/mw; b=V/mA
    # Internal source has one child and parent; external source one child.
    assert a<h and a+b<h
    # Both parent and child are own-low; B_A excludes the parent by mass.
    BA=a; raw=V*BA*BA/(h*h)
    I_low=F(1) # Each child meets exactly one internal mass-one packet.
    overlap_mean=F(N)*V*I_low/(mA*mw)
    assert overlap_mean==BA
    assert raw==V/mA**2*(F(N)*V*I_low/mw)**2/h**2
    X=V*(1+N*mw); W=N*mw; eps=F(1,2)
    assert raw <= (1+eps)**2*X
    # This fixture does not have high-past original history; high-rank is not asserted.
    return {'n':n,'external_packet_mass':str(ext),'center_width':str(width),
            'B_A':str(BA),'raw_joint':str(raw),'Xq':str(X),'W':str(W),
            'actual_K_squared_mass_gap_certified':True,'parent_outside_centers':True,
            'all_source_ranks_below_h':True}

def atoms(weights,K,h):
    masses=[F(1),F(2),F(4),F(8),F(16)]
    weights=list(map(F,weights));J=sum(weights)
    T=[sum(weights[:i+1]) for i in range(5)]
    Z=[sum(weights[j] for j in range(5) if masses[j]<masses[i]/K) for i in range(5)]
    B=max(t-z for t,z in zip(T,Z))
    low=sum(w for w,z in zip(weights,Z) if z<=h)
    assert low<=min(J,h+B)
    if any(z>h for z in Z):assert low>=h
    for threshold in [F(0),h,h+B,J]:
        assert sum(w for w,t in zip(weights,T) if t<=threshold)<=threshold
    return {'weights':list(map(str,weights)),'K':str(K),'h':str(h),'window_cap':str(B),'terminal_mass':str(low),'active':any(z>h for z in Z)}

stages={
 'initial':[native(3,F(j,32),F(1,50)) for j in [1,2,3]],
 'matching_pressure':[native(r,e,w) for r in [3,4] for e in [F(1,32),F(1,8)] for w in [F(1,40),F(1,20)]],
 'expanded':[native(r,e,F(1,50)) for r in [5,8,12,20] for e in [F(1,64),F(1,16),F(1,8)]]}
a=[atoms(w,K,h) for w in [[1,2,3,4,5],[0,5,0,1,7]] for K in [F(2),F(3)] for h in [F(0),F(2),F(6)]]
# Atomic terminal laws; the actual closed K-window is <= epsilon*h.
# Not a native center model. Includes unreachable terminal atoms and nonzero TV.
def terminal_tv(h,count):
    K=F(2);eps=F(1,2);weights=[h/4]*count;masses=[F(3,2)**j for j in range(count)]
    Z=[sum(weights[k] for k in range(count) if masses[k]<m/K) for m in masses]
    T=[sum(weights[:j+1]) for j in range(count)]
    assert max(t-z for t,z in zip(T,Z))<=eps*h
    terminal=[j for j,z in enumerate(Z) if z<=h];B=sum(weights[j] for j in terminal)
    assert h<=B<=(1+eps)*h
    U=[weights[j]/B if j in terminal else F(0) for j in range(count)]
    laws=[];rows=[]
    for j in range(count):
        if j in terminal:
            P=[F(int(k==j)) for k in range(count)]
        else:
            P=[sum(weights[l]*laws[l][k]/Z[j] for l in range(j) if masses[l]<masses[j]/K) for k in range(count)]
            assert sum(P)==1 and all(P[k]<=weights[k]/h if k in terminal else P[k]==0 for k in range(count))
            tv=sum(abs(P[k]-U[k]) for k in range(count))/2
            assert tv<=1-h/B
            rows.append({'start':j,'TV':str(tv),'bound':str(1-h/B)})
        laws.append(P)
    # Two actual active terminal laws; conditional fee is an explicit [0,1] array.
    ids=[r['start'] for r in rows];pair_count=0
    for j,k in zip(ids,ids[::-1]):
        P=laws[j];Q=laws[k]
        tv=sum(abs(P[l]*Q[m]-U[l]*U[m]) for l in range(count) for m in range(count))/2
        assert tv<=1-(h/B)**2
        psi=lambda l,m:F((l+2*m)%4,3)
        difference=abs(sum(psi(l,m)*(P[l]*Q[m]-U[l]*U[m]) for l in range(count) for m in range(count)))
        assert difference<=tv
        paid=remaining=original=F(0)
        for l in range(count):
            for m in range(count):
                base=P[l]*Q[m];ref=U[l]*U[m];fee=psi(l,m)
                assert base==0 or ref>0
                ratio=base/ref if ref else F(0)
                excess=max(F(0),1-1/ratio) if ratio else F(0)
                residual=fee*base*(1-excess)
                assert residual<=ref
                paid+=fee*base*excess;remaining+=residual;original+=fee*base
        assert original==paid+remaining and paid<=tv
        initial_mass=F(2,7)
        assert initial_mass*difference<=initial_mass*(1-(h/B)**2)
        pair_count+=1
    return {'h':str(h),'atoms':count,'terminal_mass':str(B),'active_rows':rows,'pair_checks':pair_count}
tvrows=[terminal_tv(F(h),count) for h in [1,2,3] for count in [12,16]]
summary={'native_stage_counts':{k:len(v) for k,v in stages.items()},'native_total':sum(map(len,stages.values())),'atomic_cases':len(a),'TV_single_rows':sum(len(x['active_rows']) for x in tvrows),'TV_pair_checks':sum(x['pair_checks'] for x in tvrows),'positive_common_part_checks':sum(x['pair_checks'] for x in tvrows),'all_pass':True}
Path(__file__).with_name('r427_aux_result.json').write_text(json.dumps({'summary':summary,'native':stages,'atomic':a,'terminal_tv':tvrows},indent=2)+'\n')
print('PASS',summary)
print('Native fixtures: continuous Lebesgue centers and full nonuniform f, octave q-matching, strict K^2 and outside. No original high-past/stage/history realization.')
print('Atomic cases: finite rank/CDF algebra only, not native fixtures.')
print('r427_aux_result.json')
