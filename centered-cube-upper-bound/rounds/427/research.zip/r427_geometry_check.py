"""R427: exact native moment checks and limited geometry certificates.
No test claims to realize the original complete stage/history contract.
"""
from fractions import Fraction as F
from itertools import product


def overlap(x, R, r):
    return max(F(0), min(r, (R+r)/2-abs(x)))


def primitive(x, R, r):
    L, p = (R+r)/2, (R-r)/2
    total = F(0)
    for lo, hi, slope, intercept in (
            (-L,-p,F(1),L), (-p,p,F(0),r), (p,L,F(-1),L)):
        end = min(x, hi)
        if end > lo:
            total += slope*(end*end-lo*lo)/2+intercept*(end-lo)
    return total


def joint(R, r, alpha):
    # Actual center integral int I_At int_{w in alpha Qt} I_Aw dw dt,
    # for uniform full f and equal child side length r, in one dimension.
    L, p, d = (R+r)/2, (R-r)/2, alpha*r/2
    points = {-L,L,-p,p}
    points.update(v+sgn*d for v in (-L,-p,p,L) for sgn in (-1,1))
    points = sorted(x for x in points if -L <= x <= L)
    def integrand(t):
        return overlap(t,R,r)*(primitive(t+d,R,r)-primitive(t-d,R,r))
    return sum(((b-a)*(integrand(a)+4*integrand((a+b)/2)+integrand(b))/6
                for a,b in zip(points,points[1:])),F(0))


native1 = 0
for r, alpha in product((F(1),F(5,4),F(3,2)),
                        (F(1),F(5,4),F(3,2))):
    J = joint(F(2),r,alpha)
    assert 0 < J <= alpha*2*r**3
    native1 += 1

# Nonuniform full f: f=1 on [-3,3] plus a packet in [-.1,.1].
# Child centers are [-.3,.3], child side 1, parent side 2 at 0.
# Every child lies in parent and contains the whole packet.
# Hence I_Av=m_v, cancelling both child masses exactly.
nonuniform = 0
for packet_mass in [F(1,20),F(1,10),F(1,5)]:
    ma, mv = 2+packet_mass, 1+packet_mass
    # q_parent=ma/2, q_child=mv, q_-=1.
    assert 1 <= ma/2 <= mv <= F(4,3)
    Kappa = F(3,2)
    assert mv < ma/Kappa
    length, halfwidth = F(3,5), F(1,2)
    pair_center_area = length**2-(length-halfwidth)**2
    moment = pair_center_area/ma**2
    assert 0 < moment <= 1/Kappa
    nonuniform += 1
print("Stage 1 PASS:",native1,"native polynomial moments and",
      nonuniform,"nonuniform full-f native cancellation cases")

native_tensor = 0
for d,r,alpha in product((8,12,16),
                         (F(1),F(5,4),F(3,2)),
                         (F(1),F(5,4),F(3,2))):
    n, R = d*d,F(2)
    # e^(2 sqrt n)<3^(2 sqrt n), so this is a stronger actual mass gap.
    Kappa = F(3)**(2*d)
    if (R/r)**n <= Kappa:
        continue
    actual = (joint(R,r,alpha)/(R**2*r**2))**n
    assert 0 < actual <= alpha**n/Kappa
    native_tensor += 1
print("Stage 2 PASS:",native_tensor,
      "native uniform-source tensor moments with strict gap stronger than K^2")


def inside(source, center, side, slack):
    return all(abs(x-c)+slack < side/2 for x,c in zip(source,center))


geom = 0
for d in (12,15,20):
    n=d*d
    eps=F(1,100*n)
    block=F(1,1000*n)
    # Parent center near 0; initial centers near (1.1,-/+ .6,...).
    # Terminal centers near (1.1,-/+ .2,...).
    w0=[F(11,10)]+[F(-3,5)]*(n-1)
    t0=[F(11,10)]+[F(3,5)]*(n-1)
    w=[F(11,10)]+[F(-1,5)]*(n-1)
    t=[F(11,10)]+[F(1,5)]*(n-1)
    y=[F(13,20),F(3,20)-eps]+[F(-3,5)]*(n-2)
    z=[F(13,20),F(-3,20)+eps]+[F(3,5)]*(n-2)
    assert inside(y,[F(0)]*n,F(2),block)
    assert inside(z,[F(0)]*n,F(2),block)
    assert inside(y,w0,F(3,2),block) and inside(z,t0,F(3,2),block)
    assert inside(y,w,F(1),block) and inside(z,t,F(1),block)
    # Initial exclusivity uses coordinate 3, not inherited at later nodes.
    assert abs(y[2]-t0[2])-block > F(3,4)
    assert abs(z[2]-w0[2])-block > F(3,4)
    # All child centers outside every parent in its small center block.
    assert F(11,10)-2*block > 1
    # Initial pair still outside the R419 alpha=e^(1/d) expansion.
    assert F(6,5)-2*block > F(3,4)/(1-F(1,d))
    # Terminal pair is within the OTHER UNEXPANDED cube, robustly.
    assert F(2,5)+2*block < F(1,2)
    # Actual mass ratios; uniform full f=1 on [-4,4]^n and fixed side lengths.
    assert F(4,3)**n > F(3)**(2*d)
    assert F(3,2)**n > F(3)**d
    # R425 B soft weight: e^2 sum(Rchild/Rparent)^d < 1, using e<3.
    assert 18*(F(3,4)**d+F(1,2)**d) < 1
    # R425 A: log(4/3)>=1/4, log 2>=1/2 give exact upper bounds.
    r_initial, r_terminal=F(n,4)-d,F(n,2)-d
    assert 2*(1+r_initial/3)**-3+2*(1+r_terminal/3)**-3 < 1
    # All four cross-chain affinities remain jointly <1/8 under center blocks.
    cross = ((F(3,10)+2*block)/F(3,2))**(n-1)
    cross += (F(3,5)+2*block)**(n-1)
    cross += 2*(F(9,20)+2*block)**(n-1)
    assert cross < F(1,8)
    # Initial relative collar is certified without numerical logarithms.
    collar_ratio=(F(3,4)-eps-block)/F(3,4)
    assert collar_ratio**(2*n) > F(1,n+2)
    geom+=1
print("Stage 3 PASS:",geom,
      "positive-volume native center-block geometry certificates")
print("Stage 3: matching, terminal event, initial separation, both mass gaps,")
print("R423 cross-affinity, R425 soft positivity, and initial collar checked.")
print("NOT certified: initial own-high, original Gamma/stage/D/heavy-source/history.")
print("ALL R427 CHECKS PASS")
