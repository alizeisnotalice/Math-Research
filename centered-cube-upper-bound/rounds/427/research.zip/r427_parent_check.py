from fractions import Fraction as F
import json
counts={}
for phase,epss in [('initial',[F(1,2),F(1,4),F(1,8)]),('pressure',[F(1,3),F(1,10),F(1,32)]),('expanded',[F(1,64),F(1,256),F(1,1024)])]:
 count=0
 for eps in epss:
  delta=1-1/(1+eps)**2
  for theta in [F(1,2),F(1)]:
   for ell in [3,10,100,1000]:
    cy,cz=1+eps,1+eps/2
    uy=[1/cy,1-1/cy];uz=[1/cz,1-1/cz]
    py=[1-theta+theta*cy,1-theta];pz=[1-theta+theta*cz,1-theta]
    assert sum(a*b for a,b in zip(uy,py))==sum(a*b for a,b in zip(uz,pz))==1
    beta=F(7,3)*F(2,5)*F(3,7) # unnormalized original initial-active mass
    raw=pa=pb=rem=tv=F(0)
    for j in range(2):
     for k in range(2):
      u=uy[j]*uz[k];p=py[j]*pz[k]
      history=F(2+j+2*k,6)
      near=(j==1 or (k==1 and ell%2==0))
      # p=0 is P-null. Give the retained weight 1 there, harmless.
      kept=min(F(1),1/p) if p else F(1)
      excess=1-kept
      raw+=beta*u*p*history
      pa+=beta*u*p*history*near
      pb+=beta*u*p*history*(not near)*excess
      this=beta*u*p*history*(not near)*kept
      rem+=this
      assert 0<=this<=beta*u
      tv+=u*max(F(0),p-1)
    assert raw==pa+pb+rem
    assert tv<=1-1/(cy*cz)<=delta
    assert pb<=beta*delta
    # General full-account substitution, no change of inherited feedback.
    S=F(5,2);X=F(31,7);W=F(19,5)
    C=F(1,97);V=F(7,3);hat=F(8,5);lam=F(128,119)
    assert beta<=S*X
    da=2*S*eps**2/F((1+ell)**2);db=S*delta
    # Bound on B itself follows actual inequality, not an assumed dimension fit.
    assert pb<=db*X
    assert db<=2*S*eps and da<=2*S*eps**2/F((1+ell)**2)
    # Use exact paid amounts to test all residual/account coefficients.
    for mult in [16,32,64]:
     assert mult*hat*(raw+C*X+V*W)==mult*hat*(rem+(C+(pa+pb)/X)*X+V*W)
    assert 64*lam*hat*(raw+C*X+V*W)==64*lam*hat*(rem+(C+(pa+pb)/X)*X+V*W)
    count+=1
 counts[phase]=count
print('PASS',json.dumps(counts,sort_keys=True),'total',sum(counts.values()))
print('Exact dominated terminal-law/retained-history models and complete account identities; original active base mass retained.')
print('No native terminal chain, geometric event realization, global absorption, or general closure certified.')
