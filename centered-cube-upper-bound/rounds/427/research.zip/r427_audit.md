# R427 independent audit — FINAL PASS (bounded scope)

FINAL PASS for the universal own-low capacity, actual terminal mutual-position payment A, and original-path terminal excess-density payment B, with the final main/README account and evidence limits below. No general root-order remainder estimate, total absorption balance, or full-history numerical fixture is certified. Only this audit file was edited.

Sections 1–6 preserve the independent pre-author derivations; section 7 records the completed post-author review and frozen byte bindings.

## 1. Closed window at every positive mass

Fix the original source x and any M>0. Let u=(2||v−x||∞)^n. Capture implies m_v=q_vR_v^n≥q_-u. On the actual closed window M/K≤m_v≤M, also u≤M/q_- and
1/m_v≤1/max(M/K,q_-u).
Consequently the true Lebesgue CENTER envelope gives
ρ_x{M/K≤m_v≤M}
≤∫_0^{M/q_-}du/max(M/K,q_-u)
=1/q_-+(logK)/q_-.
The inner center-volume base is 1/q_-; both mass endpoints and full mass atoms are included. No endpoint layer is assumed zero-measure for the chosen selector. The proof does not integrate a freely chosen radius, impose a source-density cap, use q≤λ, or require that M equal an actual parent mass. It only uses actual center capture and the positive lower q bound. The original octave/full-matching field satisfies these assumptions; this specific window lemma does not itself need an octave restriction.

With closed T_M=ρ_x{m_v≤M} and strict Z_M=ρ_x{m_v<M/K}, the exact measure split is
T_M=Z_M+ρ_x{M/K≤m_v≤M}.
For the original finite field these quantities are finite, hence 0≤T_M−Z_M≤B0=(1+logK)/q_-. More generally the safe extended-measure statement is T_M≤Z_M+B0; one must not write an undefined infinity-minus-infinity difference. Original K=e^(√n), s=1+√n, h=s/(ε_0q_-) give B0=s/q_-=ε_0h exactly.

## 2. Own-low set: closed atoms and zero rows

Let B_x={v:Z_v(x)≤h}, h>0, where Z_v(x)=Z_{m_v}. Every v∈B_x with ρ_x-positive support has
T_{m_v}≤h+B0.
For any mass pushforward, the INCLUSIVE CDF sublevel satisfies ρ_x{v:T_{m_v}≤a}≤a. Its set is an initial mass segment: a crossing atom with closed rank above a is excluded whole, while an atom ending exactly at a is included whole. Approximating that segment by a countable cofinal family of mass prefixes proves the inequality without continuity or mass-atom subdivision.

Therefore
ρ_x(B_x)≤h+B0=(1+ε_0)h.
If an active state exists, the original bottom-h argument also gives ρ_x(B_x)≥h: the first crossing-h atom, if any, has strict far past at most its left rank≤h and is included as a whole; the nonatomic case follows by monotone prefix limits. Thus active existence gives h≤ρ_x(B_x)≤h+B0. If no active state exists, B_x has all ρ_x mass, still bounded above; the lower bound h need not hold. J(x)=0 is zero flow. Capture-zero receivers contribute no ρ_x mass regardless of their formal low label.

## 3. Exactly what may be used subsequently

For one ORIGINAL active start, its normalized unfiltered terminal kernel H_x(v,db) still obeys
H_x(v,db)≤1_B(db)ρ_x(db)/h,
with probability mass 1. The new capacity makes that envelope's total at most 1+B0/h; it does not turn its center-reference mass into an upper bound on actual terminal traffic. For an arbitrary nonnormalized initial source measure ℓ_x of mass M(x), the actual terminal measure has total M(x) and bound
H_{ℓ_x}(db)≤[M(x)/h]1_Bρ_x(db).
Nothing here proves M(x)≤h, or M(x)≤h+B0. The original initial column may supply M(x)≤C_xλJ(x), which retains its source-rank amplification. Future positive restrictions can be dropped for such upper bounds; conditioning and renormalizing on retained terminals divides by a possibly small survival probability and is not covered by the original row bound.

One valid integrated REFERENCE-capacity consequence is
∫σ(dv)π_v(dx)1_{Z_v(x)≤h}≤λ(h+B0)f(x)dx,
using σπ=f(x)q_vρ_x(dv)dx. This becomes a once-only source price only for an actual measure with the corresponding verified column domination. Initial own-low receipts already paid in R411 cannot be recharged, and their column hats are not automatically terminal-arrival columns. Terminal own-low gives no new original clock/deletion/opposite-source-exclusive/history qualification. At the initial screen this approved only the capacity lemma; the later actual applications are independently checked in §§5–7.

## 4. Actual local mathematical check

Executed a bounded native Fraction diagnostic. For f=1 on Q4, E=Q2, select side R_i on the center annulus Q_Ri\Q_R(i−1), with R_i=1+i/L (first block Q1). Each selected cube lies in Q4, has full matching m_i=R_i^n and q=1, captures source x=0, and the exact ρ atom is (R_i^n−R_(i−1)^n)/R_i^n (initial weight1). Twelve dimension/shell/K profiles (n=1,16,64; L=4,8; rational diagnostic K=2,9) gave 168 closed-window endpoint checks and 36 own-low checks; the 20 active cases also satisfied the lower bound h. All passed. A positive rational atanh-series LOWER bound on logK already dominated each tested window, so the comparisons are exact, not floating certificates.

This is a pointwise native-center/matching capacity diagnostic with rational test K,h; it is not the synchronized K=e^(√n), original h, or full history flow. Temporary reviewer execution is not an archived script or a future author/parent experiment total. General assertions above are analytic, not inferred from these finite checks.

## 5. Independent terminal mutual-position screen (A)

The proposed terminal event passes as a positive branch. Every generated terminal after the active initial witness retains the fixed original source and satisfies m_w,m_t<m_A/K², because the R425 restriction already imposes that cutoff on every node; the transition kernel is not regenerated with K². For one direction w∈αQ_t, the exact full-parent posterior integral is

    m_A^(-2)∫ [I_Aw/m_w][I_At/m_t]1_{w∈αQ_t} dw dt.

Use I_Aw≤m_w before the w center integration. The actual w centers form a subset of αQ_t, with volume α^n R_t^n≤α^n m_t/q_-. For the remaining strict far t centers, full matching gives ∫I_At dt≤m_A(m_A/K²)/q_-. Thus the directed raw moment is at most α^n/(K²q_-²); the OR of both directions costs at most twice this. The terminal probability kernels are dominated by ρ_y/h and ρ_z/h before future restrictions, so the original common-stage envelope S gives

    P_A≤[2S α^n/(K²q_-²h²)]X_q.

With α=exp(2/√n), α^n=K², hence Δ_A=2S/(q_-²h²)=2Sε_0²/s². There is no λ, τ, or extra endpoint factor. This statement concerns the SAME generated terminal pair; resampling is unnecessary. The initial R419 mutual-position event does not cover terminal positions, and small full-source affinity does not rule out nearby centers whose cube intersection carries zero f mass. This does not certify a nonzero eligible branch for every input or a fixed fraction of the remainder.

## 6. Independent normalized comparison and actual positive split (B)

Fix an original base ticket r before future/path retention, including the parent, original two sources and all preceding labels. Let a_y,a_z be the probabilities that the two original initial witness laws land in active states. Retain their product as an ORIGINAL unnormalized ticket weight. If either is zero the contribution is zero; no division or U construction is required there. Otherwise normalize the active initial laws only for this representation and generate their independent original paths before applying retained-history predicates.

Their terminal probabilities P_y,P_z satisfy P_x≤ρ_x|B_x/h. Set B_x=ρ_x(B_x) and U_x=ρ_x|B_x/B_x. Active existence gives h≤B_x≤(1+ε_0)h. Thus P=P_y⊗P_z has density p_r relative to U=U_y⊗U_z bounded by B_yB_z/h², and

    TV(P,U)≤1−h²/(B_yB_z)≤δ_TV:=1−(1+ε_0)^(-2).

Here TV is sup-event distance, equal to ∫(p_r−1)_+dU. Conditional independence is asserted only for the unfiltered generated paths. Let ψ_r(w,t)∈[0,1] be the original conditional expectation of ALL full-path retention and the A-complement given the terminal pair. Then ∫ψ_r dP≤∫ψ_r dU+δ_TV. Choose the conditional version to vanish on P-null terminal sets and preserve any explicit terminal predicate. The U reference does not itself acquire original history qualification.

There is an actual positive split, not merely a comparison: on the original tickets multiply the retained fee by (1−1/p_r)_+ (zero where p_r=0, which carries no original P mass). Its cost is ∫ψ_r(p_r−1)_+dU≤δ_TV. The kept original fee is ∫ψ_r min(p_r,1)dU≤∫ψ_r dU. This keeps the original paths, sources and every history predicate; it is not a refreshed U-law flow and need not equal the U reference. In particular p_r must be the UNFILTERED active-product terminal density fixed before A and all future retention, not recomputed after survival conditioning. Multiplying by the original a_ya_z and using the common-stage envelope once gives the proposed whole-round price Sδ_TV X_q, with no additional two-endpoint factor.

The parent-adopted order A then this excess mark is therefore consistent with C427=C425+Δ_A+Sδ_TV, V425 unchanged, subject to final inspection of the exact author construction and mother-account feedback. The two branches do not refresh history and do not bound the final unweighted remainder by a source price.

Executed 72 temporary exact Fraction checks of TV domination and retained/common/excess identities over finite probability pairs and retention functions; all passed. They are reviewer algebra checks, not native-center/history fixtures and not additions to parent/author totals.

The independent pre-author screen ended here. The author proofs and final main/README were subsequently reviewed as recorded below.


## 7. Final post-author review, account and reproduction

Read the complete final geometry/auxiliary/main/README and all three scripts. Geometry now consistently calls the A-only intermediate remainder/account R_sep/C_sep/V_sep, separate from the main A+B final R427/C427. The auxiliary finite recursion supplies jointly measurable terminal densities relative to ρ_x; it does not invoke a source/history product absolute-continuity assumption or normalize a retained path law. Its §3 reference comparison is explanatory only; the formal payment is §3b's original-ticket excess mark. Zero active mass and p=0 cases are explicitly harmless. The unfiltered p_r is fixed before A and all future filters.

The exact adopted split is R425=P_A+P_B+R427 with

    Δ_A=2Sε_0²/s²,  Δ_B=S[1−(1+ε_0)^(-2)],
    C427=C425+Δ_A+Δ_B,  V427=V425.

The inherited feedback Fhat=(1−32δ−16η)^(-1) is unchanged. G0/BH/entry residual multipliers stay respectively 16Fhat, 32Fhat, 64ΛFhat. Only the X slot increases; the entry increment is exactly 64ΛFhat(Δ_A+Δ_B)X. All old exterior/source slots, original h, and low-dimensional/full-scale contracts remain. No retrospective ε_0 change, extra TV fee, τ factor, new W price, or proof of overall absorption is asserted. The final retained conditional terminal measure is a submeasure of U_y⊗U_z, not that full probability law; it retains the actual paths and complete original history.

Three scripts were actually rerun in an isolated temporary directory, using copied scripts and without modifying author outputs. Current source scripts and all three stdout files are byte-identical to that isolated execution; the auxiliary JSON is also byte-identical. Counts remain separated: parent 72 finite dominated-law/account configurations; geometry 9 native polynomial plus 3 nonuniform cancellation cases, 27 tensor moments, and 3 positive-volume geometric compatibility certificates; auxiliary 23 continuous-center/full-matching models, 12 atomic CDF cases, 48 single-terminal and 48 two-terminal TV/positive-split checks (the common-part assertions reuse those 48 pair cases). These are not all distinct full-history experiments.

The native scalar/tensor/block calculations correctly retain actual side lengths, whole source-cell masses and Lebesgue center volumes. The three geometric compatibility certificates check matching, mass gaps, initial separation/collar, cross-affinity and R425 positive soft weights, but do not implement original own-high, Γ_i/D_i, heavy-source or full history. Auxiliary native models explicitly have low ranks and likewise do not implement those qualifications. General payments rest on the analytic proofs plus the stated inherited contracts. The reviewer's temporary 72 probability checks and earlier local capacity diagnostic are excluded from the parent/author statistics.

The remaining source–parent–terminal joint integral remains unpaid. Neither terminal capacity nor the two positive payments establishes a fixed removed fraction, an improved whole right side for each input, or the desired general weak-type bound. Within this scope no mandatory correction remains.

## 8. SHA-256 byte bindings

- `r427_main.md`: `80ee1733dc6e97874d99353f10dd54dcd46cb6479723d9f9025d0d4ac2133fe1`
- `r427_readme.md`: `2ddbac52516c1cdbde128d5a278aff0a8860ee5ebde6743e723f768300f4b66e`
- `r427_geometry.md`: `ad10223211308211908357824c576e5fcb643580d640f7afa469412bbf4e8b8c`
- `r427_aux.md`: `290d79976e38fe778890f9727c813171131874e46f08d9df56c4fbb79914c15d`
- `r427_parent_check.py`: `3b070b611230cee732faf70fa70eae5a29b1d36dc6a9b16915dca3d4760a9ed3`
- `r427_aux_check.py`: `086bcd04456c9dbec962c48e5634f1c70b15f421bd829ccc360057d0acb6c279`
- `r427_geometry_check.py`: `ea401819403efe915a37ce15dd515b639c20637abf8c8d4c843fe780613b7ff0`
- `r427_parent.result.txt`: `70ae7fb94238d37c63489e84efc3fe404a3daf6eeeabb6af9b8b5a6fa9a258ca`
- `r427_aux.result.txt`: `ecdbc3267de5af3d1588499f4d36960b4449cfcd0798427fefc68a76d81918ab`
- `r427_geometry.result.txt`: `4da410cc1b4743b852b5a0378398f124504b2bdf77f68b3b526cacbbc3ad4f8f`
- `r427_aux_result.json`: `80d1d6f920ddb0cf10d8f4f04050e8ec3abef36230e7dcd976a2eaf2c3113a41`

Bindings cover the reviewed final bytes only. Any mathematical, scope, or code change requires a corresponding re-audit; archive assembly itself is outside this audit. FINAL PASS; bounded task complete.
