# R427 辅助：终端 own-low 的原生闭秩容量与有价来源参考

本稿证明任意见证节点都可用的闭质量窗界，并由原保源路径得到一次有价的终端参考测度比较。它不是新的 W 付款；§3b 另给一次显式 X 价格的原正共同部分分拆，不将参考测度生成的节点赋予原历史。父匹配双矩的根阶来源上界仍未证明。

## 1. 全量词：质量窗不只适用于原端点

冻结完整 f≥0、W=∫f、实际 Lebesgue 接收中心 E、同一个可测选择器 Q_w（边长 R_w）、m_w=f(Q_w)=q_wR_w^n，q_-≤q_w≤λ，a≤R_w≤b≤2a。令 μ(dw)=dw/m_w，ρ_x(dw)=c_w(x)μ(dw)，J(x)=ρ_x(E)，σ(dA)=q_A dA，π_A=f c_A/m_A。记 K=e^{√n}、h=(1+√n)/(ε_0q_-)，0<ε_0≤1/2。

**对任意来源 x、任意数值 0<L≤U**，有
\[
 \rho_x\{L\le m_w\le U\}\le\frac{1+\log(U/L)}{q_-}.\tag{1}
\]
证明：捕获 x 的中心满足 m_w≥q_-(2||w−x||∞)^n，同时 m_w≥L、m_w≤U。因此实际被积密度正支配于
\[
 \frac{1_{q_-(2\|w-x\|_\infty)^n\le U}}
 {\max(L,q_-(2\|w-x\|_\infty)^n)}.
\]
变量 t=(2||w−x||∞)^n 的中心子水平体积为 t，积分等于 (1+log(U/L))/q_-。这只积分中心 Lebesgue 体积，不给 f 密度帽。闭窗的两个质量端点均保留，不声称实际选择器的端点事件零测。

定义闭秩与严格过去
\[
 T_w(x)=\rho_x\{v:m_v\le m_w\},\quad
 Z_w(x)=\rho_x\{v:m_v<m_w/K\}.
\]
取 L=m_w/K,U=m_w 得
\[
 0\le T_w(x)-Z_w(x)\le B_0:=(1+\log K)/q_-=\varepsilon_0h.\tag{2}
\]
所以该量词确实覆盖任意辅助路径节点 w；无需它继承原 Γ 的 high/early/clock 资格。(1)是 R407 真实质量窗引理的不对称写法，(2)不是新的收费。

## 2. 终端整块原子与容量

令 L_x={w:Z_w(x)≤h}，B_x=ρ_x(L_x)。质量推前的闭 CDF 满足
\[
 \rho_x\{w:T_w(x)\le a_0\}\le a_0\quad(a_0\ge0).
\]
证明可将每个质量原子展开成秩区间：闭秩是右端点，只有整段右端点≤a_0才纳入；连续部分按广义逆积分。由(2)，
\[
 B_x\le\min(J(x),(1+\varepsilon_0)h).\tag{3}
\]
若存在 active 节点 Z_w(x)>h，则 B_x≥h：底部秩 [0,h] 必在终端初段；跨越 h 的原子左秩≤h且严格 far 秩≤左秩，整个原子仍为终端。无跨越原子时用分位数极限。因此有 active 输入的来源满足
\[
 h\le B_x\le(1+\varepsilon_0)h.\tag{4}
\]
这也说明“终端 own-low”本身不是小概率事件。零流、J=0、无 active 输入的来源不需要定义下述归一参考。

## 3. 原路径的有价终端参考：保初始质量与完整费用

使用原固定来源路径核
\[
 P_x(w,dv)=1_{m_v<m_w/K}\rho_x(dv)/Z_w(x),\qquad Z_w(x)>h,
\]
到 Z≤h 时停止。质量具有正上下界，严格 K 下降保证有限停止。R412/R423 已证明：从任意 active 起点 w，**完整终端概率** H_x(w,db) 满足
\[
 H_x(w,db)\le1_{L_x}(b)\rho_x(db)/h.
\]
令 U_x=1_{L_x}ρ_x/B_x，则 H_x≤(B_x/h)U_x。采用 TV(P,Q)=sup_B|P(B)−Q(B)|，对概率 P≤cQ，min(dP,dQ)≥dP/c，故
\[
 \operatorname{TV}(H_x(w,\cdot),U_x)
 \le1-h/B_x\le\frac{\varepsilon_0}{1+\varepsilon_0}.\tag{5}
\]
任意非归一 active 起点测度 ν_x 的质量 a_x 必须保留：终端输出与 a_xU_x 的 TV 差≤a_x(1−h/B_x)。a_x=0 时两者皆零。

以下仅对原构造已存在的保源双路径应用；不从两个单边帽推断任意耦合的乘积帽。固定原完整初始记录 r，其中包括父 A、来源 y,z、初始 active w,t 和进入该记录的实际质量。原两路径在该记录下使用既有的两个生成核，未条件化未来限制，其终端法为
\[
 P_r=H_y(w,\cdot)\otimes H_z(t,\cdot)
 \le\frac{B_yB_z}{h^2}(U_y\otimes U_z).
\]
于是
\[
 \operatorname{TV}(P_r,U_y\otimes U_z)
 \le\delta_r:=1-\frac{h^2}{B_yB_z}
 \le\delta_\varepsilon:=1-(1+\varepsilon_0)^{-2}.\tag{6}
\]

令 0≤F≤1 收集同一完整路径上的全部未来/历史/空间/质量/soft 限制，包括 Π425 全节点 K² 门。令 V_r 是 F 加权路径法的终端推前，V_r≤P_r。定义
\[
 \psi_r=\frac{dV_r}{dP_r},\quad0\le\psi_r\le1,
\]
在 P_r 零密度处取0。准确可测实现是以 U_y⊗U_z 为共同参考，分别取 P_r,V_r 的可测核密度 p_r,v_r，置 ψ_r=v_r/p_r（p_r=0处为0）。有限次原核复合、可测终端集合及标准 Borel 接收空间保证这种参数化核密度可取可测。这里没有对“完整记录×来源”产品绝对连续性作额外假定：初始记录 r 已经固定，所需支配是上面已证的终端测度支配。

于是原条件费用 ∫F d原路径=∫ψ_r dP_r，且
\[
 \left|\int\psi_r\,dP_r-\int\psi_r\,d(U_y\otimes U_z)\right|
 \le\delta_r.\tag{7}
\]
ψ 是原历史费用的终端条件投影；U 参考上的 ψ 不是重新生成的历史资格。P_r-null 终端处的零延拓是定义的一部分，不能把 ψ 直接改成1。

设 Λ(dr) 为原 active 初始记录测度。必须在删除未来限制前取 Λ，原共同阶段与两父端包络给 |Λ|≤S X_q（S=β+C_col，已含两端）。若有初始子概率，其实际质量包含在 Λ 中。定义
\[
 R=\int\Lambda(dr)V_r(E^2),\qquad
 R_{\rm ref}=\int\Lambda(dr)\int\psi_r\,d(U_y\otimes U_z).
\]
则有一次性、无阶段/路径长度倍数的比较
\[
 \boxed{|R-R_{\rm ref}|\le\int\delta_r\,d\Lambda
 \le[1-(1+\varepsilon_0)^{-2}]S X_q.}\tag{8}
\]
这是有价参考比较，**不是原流的正支付款**。初始原记录、来源关联及 ψ 中全部历史仍在 R_ref；并未取得 R_ref 的根阶 W 界。若正式采用(8)，这笔 X 误差必须新增核算，不能与以前的 ε_0 费用自动合并或宣称可吸收。

### 3b. 正共同部分分拆：正式可付版本

正式构造不需要对完整历史取条件密度。对 active 起点 v，用有限路径递推定义终端相对 ρ_x 的密度 g_x(v,b)：第一步直接落终端的项为
\[
 1_{m_b<m_v/K}1_{L_x}(b)/Z_v(x),
\]
再加第一步落 active 节点 a 的积分
\(\int 1_{m_a<m_v/K}1_{Z_a>h}\rho_x(da)g_x(a,b)/Z_v(x)\)。
质量每步严格下降 K 倍、全场质量有正上下界，所以只有统一有限步数；每项均可测，递推得到联合可测 g，且已证终端支配给 g≤1_{L_x}/h（相对ρ_x几乎处处）。原始起点始终 active，故不需把终端起点 Dirac 伪装成ρ密度。

保留上节**未按未来事件过滤**的 P_r 和 U_r=U_y⊗U_z，直接置
\[
 p_r(b,d)=B_yB_z\,g_y(w,b)g_z(t,d).
\]
于是 P_r=p_rU_r。于原完整路径终端 (b,d) 处定义
\[
 e_r(b,d)=(1-1/p_r(b,d))_+,\qquad
 k_r=1-e_r=\min(1,1/p_r).
\]
p_r=0 处规定 e_r=0、k_r=1；该处原 P_r 质量为零。这两个标记只乘原路径票据，不生成另一份历史。对于原费用 F（也可含先前主几何 A 的任何正余权），精确分拆
\[
 R=P_B+R_B,\quad
 P_B=\int d\Lambda\,\mathbb E_r[F e_r],\quad
 R_B=\int d\Lambda\,\mathbb E_r[F k_r].
\]
直接使用原路径上的 0≤F≤1，
\[
 \mathbb E_r[F e_r]\le\mathbb E_r[e_r]
 =\int(p_r-1)_+\,dU_r=\operatorname{TV}(P_r,U_r).
\]
故真正原正支得到
\[
 \boxed{P_B\le S[1-(1+\varepsilon_0)^{-2}]X_q.}\tag{8b}
\]
对任意可测终端集合 C，剩余条件终端推前直接满足
\[
 V_{B,r}(C)=\mathbb E_r[F k_r1_{\mathrm{terminal}\in C}]
 \le\int_C\min(p_r,1)\,dU_r\le U_r(C).\tag{8c}
\]
若采用上节 ψ 记号，其精确密度是 ψ_r min(p_r,1)；但正式正分拆及(8c)不依赖该条件投影。
这是未归一子概率容量，**不是终端法等于 U_r**；其原来源、初始标签、全历史、路径及全部旧门仍保留。所有初始进入量在 Λ 中，不因剩余概率小而归一。

若主稿先付 A 支，直接把 (1−χ_A) 纳入 F，仍使用同一个未过滤 P_r 的密度 p_r；不能从 A 筛后的条件路径重新定义 p_r。因此(8b)可在 A 之后不交计价，W 无新增；不追溯改变生成路径或 h。原无权 R_B 的根阶估计仍未闭合，(8c)只是有价取得的实际终端容量。

## 4. 父匹配双矩：精确保留的量与当前价格

对固定原父 A，题设量为
\[
 B_A(x)=\int_{m_w<m_A/K^2,\ w\notin Q_A}
 c_w(x)1_{Z_w(x)\le h}\mu(dw).
\]
这里 w∉Q_A 是中心外侧，不是 Q_w 与 Q_A 不交。令
\[
 I^{\rm low}_{Aw}=\int f(x)c_A(x)c_w(x)1_{Z_w(x)\le h}dx.
\]
完整匹配与 Tonelli 给严格恒等式
\[
 \mathcal B:=\int\sigma(dA)\int\pi_A(dy)\pi_A(dz)
 \frac{B_A(y)B_A(z)}{h^2}
 =\frac1{h^2}\int\frac{q_A dA}{m_A^2}
 \left[\int_{m_w<m_A/K^2,w\notin Q_A}\frac{I^{\rm low}_{Aw}}{m_w}dw\right]^2.\tag{9}
\]
没有将 low 标记在混合父后验之后因式分解，也未把 I^low 当均匀体积。

由(3)和 Jensen，可安全得到
\[
 \mathcal B\le(1+\varepsilon_0)^2X_q,
\quad
 \mathcal B\le\frac\lambda{h^2}\int f(x)J(x)B_x^2dx
 \le\frac{\lambda A_n}{q_-}(1+\varepsilon_0)^2W.\tag{10}
\]
第二界仍为线性维数。它明确显示自己的价格：终端秩帽消去两份 h，但原父捕获 J 仍留下。对原费使用 Green 的 ρ/h 支配时必须先保原双路径，再正删除限制；不能由(3)重新归一终端而免费取消初始进入量。

目前缺的是(9)中实际父共享、外侧和 I^low 的联合跨父比较。仅将 I^low≤I_Aw≤m_w、或 B_A≤B_x≤(1+ε_0)h，尚不能把(10)改成根阶 W。式(8)提供可测的终端参考及明确 X 误差；它没有支付这一联合比较，也不把双参考来源视为无条件独立。

## 5. 实际检查与证据边界

r427_aux_check.py 已实际运行：23 个 native 连续中心模型（3 初步、8 匹配压力、12 扩大，n=9至400），12 个有限 CDF 原子例，以及48个 active 单终端 TV 和48个双终端 TV/有界费用检查，全部通过。

Native 模型取父中心小盒、边长2，孩子中心小盒、边长1；完整来源由内侧质量1小胞和父外侧质量 δ∈(0,1/8] 小胞组成。所有中心盒内捕获模式由精确坐标包含/排斥计算固定，m_A=2^n、m_w=1+δ、q_A=1、q_w=1+δ，故满足真实 octave 和 q∈[1,4/3]。孩子中心全部在每个父立方体外，严格 K² 质量门由 e<11/4 的有理上包围核验；e<11/4 可由四阶正级数加尾项≤1/100直接证。计算(9)两侧用完整来源质量和实际中心体积，未以点接收者或均匀密度替代。该模型所有实际秩较小，**不实现原 high-past、stage 或完整历史**，不冒充完整余流样本。

12 个 CDF 例只检验闭秩、零原子和 crossing 原子。TV 检查另用质量 (3/2)^j、每原子 h/4、K=2，真实闭窗帽≤h/2；递推原停止核的完整终端分布，含不可达终端原子，精确核(5)–(7)、原正共同部分分拆/剩余终端≤U及初始质量2/7。它们是有限秩模型，非 native 中心或原 K=e^{√n} 的历史实现。TV 的一般证明不依赖该替代 K 的数值。

结论：普遍 own-low 量词成立；正式正分拆(8b)花 S[1−(1+ε_0)^−2]X_q，使剩余终端推前受 U_y⊗U_z 支配且保原完整历史。没有新增 W 价格，也没有完成剩余根阶预算。停止扩展。
