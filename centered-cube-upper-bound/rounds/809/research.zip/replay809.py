#!/usr/bin/env python3
"""Rebuild all five R809 computations, checking the saved LP certificates exactly."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile


def checked(data, wanted, label):
    actual = sha256(data).hexdigest()
    if actual != wanted:
        raise ValueError(f"{label}: expected {wanted}, got {actual}")
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rounds", required=True, type=Path)
    parser.add_argument("--work", required=True, type=Path, help="new directory for the replay")
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    with (here / "MANIFEST.json").open() as source:
        spec = json.load(source)
    for name, digest in spec["members"].items():
        checked((here / name).read_bytes(), digest, name)
    work = args.work.resolve()
    work.mkdir(parents=True, exist_ok=False)
    for r, names in spec["upstream_files"].items():
        bundle = args.rounds.resolve() / r / "research.zip"
        checked(bundle.read_bytes(), spec["upstream_archives"][r], str(bundle))
        with ZipFile(bundle) as archive:
            for name, digest in names.items():
                (work / name).write_bytes(checked(archive.read(name), digest, name))
    for name in spec["members"]:
        if name.endswith(".py") and name != "replay809.py" or name == "route809.json":
            (work / name).write_bytes((here / name).read_bytes())
    python = [sys.executable, "-B"]
    raw = subprocess.check_output(python + ["reverse805.py"], cwd=work)
    (work / "reverse805.json").write_bytes(checked(raw, spec["derived"]["reverse805.json"], "reverse805.json"))
    subprocess.run(python + ["ranks807.py", "--output", "ranks807.json"], cwd=work, check=True)
    checked((work / "ranks807.json").read_bytes(), spec["derived"]["ranks807.json"], "ranks807.json")
    commands = [
        ("reuse809.json", ["reuse809.py", "--output", "reuse809.json"]),
        ("cap809.json", ["cap809.py", "--output", "cap809.json"]),
        ("route809.json", ["route809.py", "--check", "route809.json"]),
        ("joint809.json", ["joint809.py", "--output", "joint809.json"]),
        ("peel809.json", ["peel809.py", "--output", "peel809.json"]),
    ]
    for name, command in commands:
        subprocess.run(python + command, cwd=work, check=True)
        digest = spec["results"][name]
        checked((work / name).read_bytes(), digest, name)
        print("SHA256", digest, name, flush=True)
    print("Round 809 verified: both upstream archives, both derived inputs, all five result files.")


if __name__ == "__main__":
    main()
