#!/usr/bin/env python3
"""Balanced W rerouting with rational transport and linear-programme certificates."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from math import floor
from pathlib import Path
import platform
import subprocess
import sys


DEPENDENCIES={
    'reuse809.py':'404f2e325e76790384d08899a676dd72e57126b96acacc9ec50a35b3efaf6fa0',
    'reuse809.json':'8e966167489ee0abc5f149c3eebf4936c06f4ef9a2bb02562ca4a5a511819ce3',
    'ranks807.json':'b35edff1c0c8d097197f5a7017691a71dfcc859ee4fc9e1a57703dfb80bcabac',
    'rectangle806.py':'04714603e8dfbc8b7fe6f1f9e431c4fd8cf9c3b671e567e34bd5315244c576be',
    'triples806.py':'203a1f2ff8c6e13b66f77ad81055e71471f87b59ae805a3037c69d4ed0e3ae98',
    'reverse805.py':'c9a810c2807fa592e0fc76c514738522d8414d2e01c548579856e64d8b7fb17e',
    'reverse805.json':'955de184b852e78a2913ca9e1865404afa746c0425a920c3aa80bf9896dad886',
    'shared805.py':'d35faf62af4a6498cfaff0bd8ce1b59ebdd870143847660c67f02aa0aa10ceab',
}
LAWS=('raw_actual_four_corner_product','normalized_by_own_actual_c_h')
CAPS=(1,2)
GRID=10**14


def total(x):
    return sum(x,F(0))


def aggregate_input(stage,old_data,model,old,triples,reuse):
    M,D=F(old_data['M']),F(old_data['D'])
    cfg=None
    nr=0
    C={name:defaultdict(F) for name in LAWS}
    for z,info in sorted(old_data['active_true_price_atoms'].items(),key=lambda item:int(item[0])):
        z=int(z)
        mids=info['physical_middle_membership']
        if len(mids)==1:
            for law in LAWS:
                C[law][z,mids[0]]=F(old_data['calculations'][law]['mother_by_public_price_cell'][str(z)])
            continue
        if cfg is None:
            cfg=triples.genuine_config(stage,model,old)
        Z=old.box(info['representative_Z'])
        H,Ht,lx,ra=triples.same_z_edges(stage,cfg,M,D,Z,model,old)
        num,rooted,_=reuse.edges_by_owner(H,Ht,lx,ra)
        nr+=1
        m=F(info['true_mu'])
        for law,masses in zip(LAWS,(num,rooted),strict=True):
            assert m*total(masses.values())==F(old_data['calculations'][law]['mother_by_public_price_cell'][str(z)])
            for (_,t,_),v in masses.items():
                assert t in mids
                C[law][z,t]+=m*v
    models=[]
    for law in LAWS:
        stored=old_data['calculations'][law]
        S=F(stored['mother'])
        Z=sorted(map(int,stored['mother_by_public_price_cell']))
        rz={z:F(stored['mother_by_public_price_cell'][str(z)])/S for z in Z}
        wp={tuple(row['W']):F(row['mother'])/S for row in stored['W_actual_sector_rows']}
        wt={tuple(row['W']):{int(t):F(k)/F(row['mother']) for t,k in row['latent_central_mass'].items()}
            for row in stored['W_actual_sector_rows']}
        true={(z,tuple(row['W'])):F(k)/S for row in stored['W_actual_sector_rows'] for z,k in row['each_old_price_cell_mass']}
        x={k:v/S for k,v in C[law].items()}
        assert all(total(m for (i,_),m in x.items() if i==z)==rz[z] for z in Z)
        old_t={t for _,t in x}
        t_weights={t:total(w for (_,u),w in x.items() if u==t) for t in old_t}
        assert all(total(p.values())==1 for p in wt.values())
        assert all(total(wp[W]*wt[W].get(t,0) for W in wp)==t_weights[t] for t in old_t)
        assert {t for W in wt for t in wt[W]}==old_t
        assert total(rz.values())==total(wp.values())==total(x.values())==1
        real=dict(S=S,Z=Z,W=sorted(wp),T=sorted(old_t),r=rz,w=wp,pw=wt,C=x,truth=true)
        check_transport(real,true)
        models.append(real)
    return models,nr


def check_transport(data,K):
    r,w=data['r'],data['w']
    assert all(v>=0 and z in r and W in w for (z,W),v in K.items())
    assert all(total(v for (i,_),v in K.items() if i==z)==r[z] for z in r)
    assert all(total(v for (_,V),v in K.items() if V==W)==w[W] for W in w)


def sent(data,K):
    Q=defaultdict(F)
    for (z,W),v in K.items():
        for t,p in data['pw'][W].items():
            Q[z,t]+=v*p
    return Q


def paid(data,K,A):
    check_transport(data,K)
    Q=sent(data,K)
    value=total(min(c,A*Q[k]) for k,c in data['C'].items())
    assert 0<=value<=1
    if A==1:
        assert value==1-total(abs(data['C'].get(k,0)-Q.get(k,0)) for k in data['C'].keys()|Q.keys())/2
    return value,Q


def repair_transport(data,approx):
    r,w=dict(data['r']),dict(data['w'])
    result=defaultdict(F)
    for i,z in enumerate(data['Z']):
        for j,W in enumerate(data['W']):
            want=F(max(0,floor(F(float(approx[i,j]))*GRID)),GRID)
            d=min(r[z],w[W],want)
            if d:
                result[z,W]+=d
                r[z]-=d
                w[W]-=d
    for z,W in product(data['Z'],data['W']):
        d=min(r[z],w[W])
        if d:
            result[z,W]+=d
            r[z]-=d
            w[W]-=d
    assert not any(r.values()) and not any(w.values())
    check_transport(data,result)
    return dict(result)


def dual_from_params(data,A,s,v):
    assert all(0<=q<=1 for q in s.values()) and s.keys()<=data['C'].keys() and v.keys()==data['w'].keys()
    def score(z,W):
        return A*total(s.get((z,t),0)*p for t,p in data['pw'][W].items())
    u={z:max(score(z,W)-v[W] for W in data['W']) for z in data['Z']}
    assert all(u[z]+v[W]>=score(z,W) for z,W in product(data['Z'],data['W']))
    return total(r*u[z] for z,r in data['r'].items())+total(w*v[W] for W,w in data['w'].items())+total(
        c*(1-s.get(zt,0)) for zt,c in data['C'].items()),u


def pure_two_middle_certificate(data):
    """Exact rearrangement for the two-label case when every true row is pure."""
    if len(data['T'])!=2 or len(data['C'])!=len(data['Z']):
        return None
    first,second=data['T']
    label={z:t for z,t in data['C']}
    r={t:total(w for z,w in data['r'].items() if label[z]==t) for t in data['T']}
    desire=r[first]
    score={W:data['pw'][W].get(first,0)-data['pw'][W].get(second,0) for W in data['W']}
    allocated={}
    cut=None
    for W in sorted(data['W'],key=lambda W:(-score[W],W)):
        allocated[W]=min(desire,data['w'][W])
        if allocated[W]:
            cut=score[W]
        desire-=allocated[W]
    assert not desire and cut is not None
    K={}
    for z,W in product(data['Z'],data['W']):
        t=label[z]
        amount=allocated[W] if t==first else data['w'][W]-allocated[W]
        if amount:
            K[z,W]=data['r'][z]*amount/r[t]
    s={zt:F(1) for zt in data['C']}
    v={W:max(data['pw'][W].get(first,0)-cut,data['pw'][W].get(second,0)) for W in data['W']}
    assert paid(data,K,1)[0]==dual_from_params(data,1,s,v)[0]
    return dict(selected_primal='exact_two_label_rearrangement',K=[[z,list(W),x] for (z,W),x in sorted(K.items())],
                dual_s=[[z,t,y] for (z,t),y in sorted(s.items())],dual_v=[[list(W),x] for W,x in sorted(v.items())])


def scipy_proposal(data,A,baseline):
    if A==1:
        exact=pure_two_middle_certificate(data)
        if exact:
            return exact
    import numpy as np
    from scipy.optimize import linprog
    Z,W=data['Z'],data['W']
    C=sorted(data['C'])
    positions={z:i for i,z in enumerate(Z)}
    m,n=len(Z),len(W)
    nq=m*n
    cols=nq+len(C)
    eq=np.zeros((m+n,cols))
    rhs_eq=[]
    for i,z in enumerate(Z):
        eq[i,i*n:(i+1)*n]=1
        rhs_eq.append(float(data['r'][z]))
    for j,w in enumerate(W):
        eq[m+j,j:nq:n]=1
        rhs_eq.append(float(data['w'][w]))
    ub=np.zeros((2*len(C),cols))
    rhs_ub=np.zeros(2*len(C))
    for k,(z,t) in enumerate(C):
        i=positions[z]
        ub[k,nq+k]=1
        rhs_ub[k]=float(data['C'][z,t])
        ub[len(C)+k,nq+k]=1
        for j,w in enumerate(W):
            ub[len(C)+k,i*n+j]=-A*float(data['pw'][w].get(t,0))
    obj=np.r_[np.zeros(nq),-np.ones(len(C))]
    res=linprog(obj,A_ub=ub,b_ub=rhs_ub,A_eq=eq,b_eq=rhs_eq,bounds=(0,None),method='highs-ds',
                options={'dual_feasibility_tolerance':1e-10,'primal_feasibility_tolerance':1e-10})
    assert res.success, res.message
    K=repair_transport(data,res.x[:nq].reshape((m,n)))
    tag,K=max([('float_candidate_repaired_exactly',K),*baseline.items()],key=lambda p:paid(data,p[1],A)[0])
    s={zt:F(round(max(0,min(1,float(-k)))*GRID),GRID) for zt,k in zip(C,res.ineqlin.marginals[len(C):],strict=True)}
    v={w:F(round(float(-k)*GRID),GRID) for w,k in zip(W,res.eqlin.marginals[m:],strict=True)}
    current=paid(data,K,A)[0]
    if A>1 and 0<1-current<F(1,10**8) and dual_from_params(data,A,s,v)[0]>=1:
        # Maximize uniform coverage slack when the ordinary objective is flat at one.
        demand=np.asarray([float(data['C'][zt]) for zt in C])
        relax=np.column_stack((ub[len(C):,:nq]/demand[:,None],np.ones(len(C))))
        objective=np.r_[np.zeros(nq),-1.0]
        eq_slack=np.column_stack((eq[:,:nq],np.zeros(m+n)))
        interior=linprog(objective,A_ub=relax,b_ub=np.zeros(len(C)),A_eq=eq_slack,b_eq=rhs_eq,
                         bounds=(0,None),method='highs-ds',
                         options={'dual_feasibility_tolerance':1e-10,'primal_feasibility_tolerance':1e-10})
        assert interior.success
        alternative=repair_transport(data,interior.x[:nq].reshape((m,n)))
        if paid(data,alternative,A)[0]>current:
            K=alternative
            tag='uniform_slack_candidate_repaired_exactly'
    if paid(data,K,A)[0]==1 or dual_from_params(data,A,s,v)[0]>1:
        s={}
        v={W:F(0) for W in data['W']}
    return dict(selected_primal=tag,K=[[z,list(W),x] for (z,W),x in sorted(K.items()) if x],
                dual_s=[[z,t,y] for (z,t),y in sorted(s.items()) if y],dual_v=[[list(W),x] for W,x in sorted(v.items())])


def verified_certificate(cert):
    return ({(z,tuple(W)):F(b) for z,W,b in cert['K']},
            {(z,t):F(b) for z,t,b in cert['dual_s']},
            {tuple(W):F(b) for W,b in cert['dual_v']})


def flow_variance(data,K):
    check_transport(data,K)
    kernel={(z,W):v/(data['r'][z]*data['w'][W]) for (z,W),v in K.items()}
    assert all(total(data['w'][W]*kernel.get((z,W),0) for W in data['W'])==1 for z in data['Z'])
    assert all(total(data['r'][z]*kernel.get((z,W),0) for z in data['Z'])==1 for W in data['W'])
    Q=sent(data,K)
    tau={t:total(c for (z,j),c in data['C'].items() if j==t) for t in data['T']}
    assert all(total(Q[z,t] for z in data['Z'])==tau[t] for t in tau)
    VZ=total(data['r'][z]*(data['C'].get((z,t),0)/data['r'][z]-tau[t])**2 for z,t in product(data['Z'],data['T']))
    VW=total(data['w'][W]*(data['pw'][W].get(t,0)-tau[t])**2 for W,t in product(data['W'],data['T']))
    VK=total(data['r'][z]*(Q[z,t]/data['r'][z]-tau[t])**2 for z,t in product(data['Z'],data['T']))
    assert VK<=VW
    actual,_=paid(data,K,1)
    schur_upper=1-max(F(0),VZ-VW)/4
    assert actual<=schur_upper
    return dict(physical_price_posterior_variance=VZ,actual_W_posterior_variance=VW,
                rerouted_posterior_variance=VK,exact_balanced_Schur_row_and_column_constant_is_one=True,
                A1_variance_only_total_mass_upper=schur_upper)


def solve_case(data,A,old):
    independence={(z,W):r*w for z,r in data['r'].items() for W,w in data['w'].items()}
    truth=data['truth']
    baseline={'independent_rerouting':independence, 'original_true_W_given_z':truth}
    cert=scipy_proposal(data,A,baseline) if old is None else old['certificate']
    K,s,v=verified_certificate(cert)
    L,recovered=paid(data,K,A)
    U,u=dual_from_params(data,A,s,v)
    assert L<=U and L>=max(paid(data,x,A)[0] for x in baseline.values())
    assert U-L<=F(1,10**12),(float(L),float(U))
    full='certified full coverage' if L==1 else 'certified strict shortage' if U<1 else 'unresolved in certified gap'
    return dict(A=A,independent_paid_fraction=paid(data,independence,A)[0],
                true_W_given_z_paid_fraction=paid(data,truth,A)[0],
                certified_optimized_paid_fraction_lower=L,certified_optimized_paid_fraction_upper=U,
                exact_primal_dual_gap=U-L,can_cover_all_original_mass=full,
                minimum_amplified_receipt_to_positive_demand=min(A*recovered[k]/d for k,d in data['C'].items()),
                attained_rational_delta_from_one=1-L,certified_minimum_unpaid_fraction=1-U,
                variance_and_weighted_Schur=flow_variance(data,K) if A==1 else None,
                certificate=cert)


def data_digest(data):
    processed=[data['S'],[(z,data['r'][z]) for z in data['Z']],[(W,data['w'][W],data['pw'][W]) for W in data['W']],
               [(z,t,c) for (z,t),c in sorted(data['C'].items())],[(z,W,k) for (z,W),k in sorted(data['truth'].items())]]
    return sha256(json.dumps(processed,default=str,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def main():
    here=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    for v in ('805','806','807'):
        p.add_argument(f'--r{v}-dir',type=Path,default=here)
    group=p.add_mutually_exclusive_group()
    group.add_argument('--output',type=Path)
    group.add_argument('--check',type=Path)
    args=p.parse_args()
    sys.set_int_max_str_digits(0)
    paths={v:getattr(args,f'r{v}_dir').resolve() for v in ('805','806','807')}
    for name,h in DEPENDENCIES.items():
        if name=='reverse805.json':
            continue
        v=next((v for v in paths if v in name),None)
        assert sha256(((paths[v] if v else here)/name).read_bytes()).hexdigest()==h
    sys.path[:0]=list(map(str,paths.values()))
    import reverse805 as model
    import shared805 as old
    import triples806 as triples
    import reuse809 as reuse
    fixture=paths['805']/'reverse805.json'
    data=fixture.read_bytes() if fixture.is_file() else subprocess.check_output([sys.executable,'-B',str(fixture.with_suffix('.py'))])
    assert sha256(data).hexdigest()==DEPENDENCIES['reverse805.json']
    upstream=json.loads((here/'reuse809.json').read_text())['stages']
    previous=json.loads(args.check.read_text()) if args.check else None
    if previous:
        runtime=previous['runtime']
    else:
        import numpy,scipy
        runtime=dict(python=platform.python_version(),architecture=platform.machine(),numpy=numpy.__version__,scipy=scipy.__version__)
    results=[]
    for i,(s,prior) in enumerate(zip(json.loads(data)['stages'],upstream,strict=True)):
        assert s['stage']==prior['stage']
        ledgers,nr=aggregate_input(s,prior,model,old,triples,reuse)
        laws=[]
        for j,(name,K) in enumerate(zip(LAWS,ledgers,strict=True)):
            proofs=[solve_case(K,A,previous['stages'][i]['laws'][j]['amplification'][k] if previous else None)
                    for k,A in enumerate(CAPS)]
            laws.append(dict(name=name,mother_true_absolute_mass=K['S'],normalized_positive_old_price_rows=len(K['Z']),
                normalized_positive_owner_half_columns=len(K['W']),old_middle_labels=K['T'],exact_input_table_SHA256=data_digest(K),
                amplification=proofs))
        results.append(dict(stage=s['stage'],dimension=s['n'],multi_middle_atoms_rebuilt_once=nr,laws=laws))
    report=dict(runtime=runtime,dependencies=DEPENDENCIES,reproduction='python -B route809.py --check route809.json',stages=results,
        overall_scope=dict(data='Use all positive true z price atoms and actual W half sectors in reuse809, with both frozen laws. In atoms with one physical middle, its full R_z is the unique t mass. Only multi-middle atoms are reconstructed from the existing true h and full degrees, once for both laws.',
            LP='K has fixed original (normalized) z and W marginals. Covered mass at (z,t) is min(C_zt,A*sum_W K_zW*p_W(t)). K is allowed to reroute globally across existing sectors, not to create legal original path edges.',
            primal='The pure two-label case has exact rearrangement. Otherwise HiGHS proposes a transport, with a uniform slack problem if needed at the full-coverage boundary. Round candidate cells down on a rational grid, clip to exact remaining row and column capacities, then greedily fill their equal deficits. All checks and objective bounds use exact Fraction arithmetic.',
            dual='For s_zt in [0,1], put r_zt=1-s_zt. For each z choose u_z=max_W(A*sum_t s_zt*p_W(t)-v_W). The rigorous upper bound is sum_z R_z u_z+sum_W P_W v_W+sum C_zt r_zt. The stored dual v,s suffice for exact independent verification. Check mode does not call the float optimizer.',
            spectral='Balanced rows and columns give weighted Schur on the routing kernel with norm one. Exact Jensen on centered middle-label vectors gives a separate A=1 upper if true z-label variance exceeds W-label variance.',
            limits='Certified finite linear programme on the actual 1/2/3-dimensional selected diagnostic bins. No asymptotic rerouting claim.'))
    text=json.dumps(report,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for st in results:
            for law in st['laws']:
                for r in law['amplification']:
                    print(st['stage'],law['name'],r['A'],'ind/true/opt',
                      *[format(float(r[k]),'.11g') for k in ('independent_paid_fraction','true_W_given_z_paid_fraction','certified_optimized_paid_fraction_lower')],
                      'gap',format(float(r['exact_primal_dual_gap']),'.4g'),r['can_cover_all_original_mass'])
        if args.check:
            print('byte-identical, independently verified rational certificates')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
