#!/usr/bin/env python3
"""Exact common-source capacities and receiver-specific partitions."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform
import subprocess
import sys


DEPENDENCIES={
    'reuse809.json':'8e966167489ee0abc5f149c3eebf4936c06f4ef9a2bb02562ca4a5a511819ce3',
    'reverse805.py':'c9a810c2807fa592e0fc76c514738522d8414d2e01c548579856e64d8b7fb17e',
    'reverse805.json':'955de184b852e78a2913ca9e1865404afa746c0425a920c3aa80bf9896dad886',
    'shared805.py':'d35faf62af4a6498cfaff0bd8ce1b59ebdd870143847660c67f02aa0aa10ceab',
}


def total(values):
    return sum(values,F(0))


def actual_joint(stage,old_data,old):
    T,U=stage['middle_cubes'],stage['small_cubes']
    M,D=F(old_data['M']),F(old_data['D'])
    fibres,_,_=old.reconstruct(stage)
    visible=defaultdict(lambda:defaultdict(F))
    for t,frame in enumerate(fibres):
        if not M<=F(T[t]['m'])<2*M:
            continue
        for (g,q,W),row in frame.items():
            if not D<=F(U[g]['m'])<2*D:
                continue
            for (u,z,Us),w in row.items():
                if D<=F(U[u]['m'])<2*D:
                    assert w>0
                    visible[g,W][t,u]+=w
    ref=old_data['calculations']['normalized_by_own_actual_c_h']
    known={tuple(row['W']):row for row in ref['W_actual_sector_rows']}
    assert known.keys()==visible.keys()
    for W,row in visible.items():
        actual=known[W]
        assert total(row.values())==F(actual['mother'])
        for j,k in enumerate(('latent_central_mass','latent_old_mass')):
            v=defaultdict(F)
            for e,w in row.items():
                v[e[j]]+=w
            assert v=={int(i):F(x) for i,x in actual[k].items()}
    S=total(w for r in visible.values() for w in r.values())
    assert S==F(ref['mother'])>0
    aggregate=defaultdict(F)
    for r in visible.values():
        for e,w in r.items():
            aggregate[e]+=w
    expected={(v['t'],v['u']):F(v['retained_true_flux']) for v in stage['by_t_u']
              if M<=F(T[v['t']]['m'])<2*M and D<=F(U[v['u']]['m'])<2*D and F(v['retained_true_flux'])>0}
    assert aggregate==expected
    return M,D,S,visible


def actual_membership(boxes,model,mu):
    by_axis=[]
    for d in range(len(boxes[0])):
        breaks=sorted({p for B in boxes for p in B[d]})
        by_axis.append([(sum(1<<i for i,B in enumerate(boxes) if B[d][0]<=a<b<=B[d][1]),
                        mu(((a,b),)) if d==0 else b-a) for a,b in zip(breaks,breaks[1:])])
    masks=defaultdict(F)
    for coords in product(*by_axis):
        mask=(1<<len(boxes))-1
        w=F(1)
        for m,v in coords:
            mask &= m
            w *= v
        if mask:
            masks[mask]+=w
    assert all(w>0 for w in masks.values())
    return masks


def capacity(entries,model,mu):
    """Prefix-flow primal and disjoint-interval dual, each verified in true mu atoms."""
    assert entries
    labels=sorted(entries)
    boxes=[entries[e] for e in labels]
    n=len(boxes[0])
    J=[mu(B) for B in boxes]
    masks=actual_membership(boxes,model,mu)
    for i,d in enumerate(J):
        assert d==total(w for mask,w in masks.items() if (mask>>i)&1)>0
    # In the true fixture, all transverse boxes are nested about the same center.
    transverse=sorted((B[1:] for B in boxes),key=model.volume)
    if n>1:
        assert all(model.inside(A,B) for A,B in zip(transverse,transverse[1:]))
    first_tail=transverse[0]
    cuts=sorted({p for B in boxes for p in B[0]})
    ci={p:i for i,p in enumerate(cuts)}
    ends=defaultdict(list)
    for i,B in enumerate(boxes):
        l,r=B[0]
        ends[ci[r]].append((ci[l],i))
    prefix=[F(0)]
    chains=[()]
    for right in range(1,len(cuts)):
        best,chain=prefix[-1],chains[-1]
        for left,i in ends[right]:
            amount=prefix[left]+J[i]
            if amount>best:
                best=amount
                chain=chains[left]+(i,)
        prefix.append(best)
        chains.append(chain)
    deposits=[]
    primal=defaultdict(F)
    union_by_strips=F(0)
    for j,(a,b) in enumerate(zip(cuts,cuts[1:]),1):
        active=[i for i,B in enumerate(boxes) if B[0][0]<=a<b<=B[0][1]]
        if active:
            widest=max((boxes[i][1:] for i in active),key=model.volume)
            union_by_strips+=mu(((a,b),)+widest)
        w=prefix[j]-prefix[j-1]
        assert w>=0
        if not w:
            continue
        Q=((a,b),)+first_tail
        mask=sum(1<<i for i in active)
        assert mu(Q)>0 and mask in masks
        assert all(mu(model.clip(Q,B))==(mu(Q) if i in active else 0) for i,B in enumerate(boxes))
        primal[mask]+=w
        deposits.append(dict(actual_source_subbox=Q,positive_true_mu=mu(Q), assigned_w=w,
                             active_demands=[labels[i] for i in active]))
    for i in range(len(labels)):
        assert total(w for mask,w in primal.items() if (mask>>i)&1)>=J[i]
    disjoint=chains[-1]
    assert all(sum((mask>>i)&1 for i in disjoint)<=1 for mask in masks)
    optimum=prefix[-1]
    assert optimum==total(primal.values())==total(J[i] for i in disjoint)
    full=(1<<len(labels))-1
    U=total(masks.values())
    assert U==union_by_strips and max(J)<=optimum<=U
    if masks.get(full,0)>0:
        assert optimum==max(J)
    return dict(actual_edges=labels,real_edge_demands=[dict(e=e,J=J[i]) for i,e in enumerate(labels)],
        capacity=optimum,max_J=max(J),true_mu_union=U,true_mu_common=masks.get(full,F(0)),
        positive_membership_atoms=len(masks),capacity_by_exact_primal=total(primal.values()),
        capacity_by_exact_disjoint_dual=total(J[i] for i in disjoint),
        primal_positive_source_deposits=deposits,dual_unit_edges=[labels[i] for i in disjoint])


def partition_tests(W_rows,H,M,S,lookup):
    methods=[('globally_common_one_group',lambda W,e:()),
         ('global_split_by_middle',lambda W,e:(e[0],)),
         ('global_split_by_small',lambda W,e:(e[1],)),
         ('receiver_specific_all_active',lambda W,e:(W[0],)),
         ('half_sector_specific_all_active',lambda W,e:W),
         ('receiver_specific_split_by_middle',lambda W,e:(W[0],e[0])),
         ('receiver_specific_split_by_small',lambda W,e:(W[0],e[1],))]
    out=[]
    for name,group_key in methods:
        members=defaultdict(set)
        by_group=defaultdict(lambda:defaultdict(F))
        for W,row in W_rows.items():
            w=total(row.values())
            part=defaultdict(F)
            for e,c in row.items():
                k=group_key(W,e)
                part[k]+=c/w
                members[k].add(e)
            assert total(part.values())==1
            for k,p in part.items():
                by_group[k][W]=p
        groups=[]
        for k,events in sorted(members.items()):
            cid,c=lookup(frozenset(events))
            p=by_group[k]
            square=total(total(W_rows[W].values())/S*x*x for W,x in p.items())
            assert square>0 and c['capacity']>0
            for W,x in p.items():
                assert x<=1 and all(e in H for e in events)
                assert x==total(w for e,w in W_rows[W].items() if group_key(W,e)==k)/total(W_rows[W].values())
            groups.append(dict(group=k,certificate_id=cid,real_edges=sorted(events),C=c['capacity'],
                   union=c['true_mu_union'],max_J=c['max_J'],actual_W_conditional_p=[(W,v) for W,v in sorted(p.items())],
                   E_W_squared=square,M_over_c_times_E_square=M*square/c['capacity']))
        score=total(v['M_over_c_times_E_square'] for v in groups)
        out.append(dict(partition=name,groups=groups,total_joint_capacity_score=score))
    return out


def test_axis_split(H,mu,model):
    cut=F(1,2)
    lo,hi={},{}
    cut_through=0
    for e,B in H.items():
        a,b=B[0]
        L=((a,min(b,cut)),)+B[1:]
        R=((max(a,cut),b),)+B[1:]
        assert mu(L)+mu(R)==mu(B)
        if mu(L):
            lo[e+(-1,)]=L
        if mu(R):
            hi[e+(1,)]=R
        cut_through+=bool(mu(L) and mu(R))
    assert lo and hi and cut_through
    L,R,S=(capacity(x,model,mu) for x in (lo,hi,{**lo,**hi}))
    assert L['capacity']+R['capacity']==S['capacity']
    assert S['capacity']>max(mu(B) for B in H.values())
    return dict(axis=0,cut=cut,physical_edges_sliced_through_positive_source_on_both_sides=cut_through,
        original_max_J=max(mu(B) for B in H.values()),exact_capacity_sum_of_disjoint_sides=S['capacity'],
        max_sliced_J=S['max_J'],left=L,right=R,complete_sliced_certificate=S)


def example(stage,previous,model,old):
    M,D,S,by_W=actual_joint(stage,previous,old)
    T,U=stage['middle_cubes'],stage['small_cubes']
    amp=F(stage['true_source_amplitude'])
    mu=lambda B:model.source_mass(B,amp)
    H={e:model.clip(old.box(T[e[0]]['A']),old.box(U[e[1]]['A'])) for row in by_W.values() for e in row}
    assert all(mu(B)>0 for B in H.values())
    known=dict()
    def lookup(key):
        if key not in known:
            known[key]=(len(known),capacity({e:H[e] for e in key},model,mu))
        return known[key]
    policies=partition_tests(by_W,H,M,S,lookup)
    cid,C=lookup(frozenset(H))
    assert policies[0]['total_joint_capacity_score']==M/C['capacity']
    assert policies[3]['total_joint_capacity_score']>=policies[0]['total_joint_capacity_score']
    sliced=test_axis_split(H,mu,model)
    assert sliced['exact_capacity_sum_of_disjoint_sides']>=C['capacity']
    return dict(stage=stage['stage'],dimension=stage['n'],M=M,D=D,original_true_mother_mass=S,
        original_positive_t_u_count=len(H),original_positive_W_count=len(by_W),common_capacity_certificate_id=cid,
        strictly_formulated_partitions=policies,axis_sliced_diagnostic=sliced,
        capacity_certificates=[dict(id=tag,**c) for tag,c in known.values()],
        actual_original_W_and_t_u_joint=[dict(W=W,original_mass=total(row.values()),
             absolute_t_u_masses=[dict(e=e,mass=w) for e,w in sorted(row.items())]) for W,row in sorted(by_W.items())])


def main():
    here=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--r805-dir',type=Path,default=here)
    flags=p.add_mutually_exclusive_group()
    flags.add_argument('--output',type=Path)
    flags.add_argument('--check',type=Path)
    args=p.parse_args()
    sys.set_int_max_str_digits(0)
    r5=args.r805_dir.resolve()
    for name,digest in DEPENDENCIES.items():
        if name!='reverse805.json':
            assert sha256(((r5 if '805' in name else here)/name).read_bytes()).hexdigest()==digest
    sys.path.insert(0,str(r5))
    import reverse805 as model
    import shared805 as old
    model_file=r5/'reverse805.json'
    raw=model_file.read_bytes() if model_file.is_file() else subprocess.check_output([sys.executable,'-B',str(model_file.with_suffix('.py'))])
    assert sha256(raw).hexdigest()==DEPENDENCIES['reverse805.json']
    previous=json.loads((here/'reuse809.json').read_text())['stages']
    results=[]
    for stage,ref in zip(json.loads(raw)['stages'],previous,strict=True):
        assert stage['stage']==ref['stage']
        results.append(example(stage,ref,model,old))
    output=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='Fraction exact'),
         dependencies=DEPENDENCIES,reproduction='python -B cap809.py --check cap809.json',stages=results,
         scope=dict(original='Frozen actual first oriented original root law, or the same four-edge law divided by its own exact closure. Integrate the actual z, q and other owner marks in the frozen fibres. True W half masses and physical t/u margins match reuse809. No rectangle scan is repeated.',
           capacity='For each positive pair e, H_e is the genuine physical A_t intersect A_u in the selected diagnostic bins. No upper bound is imposed on w_a, exactly as in the posed capacitated-source cover. Every deposit can be realized by a constant nonnegative density over its positive true subbox. All full-dimensional membership atoms are included in the dual check.',
           proof='The transverse boxes are nested with positive common width. On first-axis cuts prefix constraints are S_R>=S_L+J_e and S_j>=S_(j-1). Exact longest prefixes give a primal. Their chains supply disjoint interval constraints with dual weight one, verified in the actual physical membership atoms. Independent union from transverse largest boxes is checked.',
           scoring='Groups are fixed by global middle/small labels or visible physical receiver/half before solving capacity. For a receiver-specific group, only W belonging to it contributes to its conditional p_W. The squared probabilities are averaged using the original normalized W mother.',
           slice='At the deterministic first-axis cut 1/2 split the actual physical H_e and its genuine demand mu on each side. This independent geometric control holds the original conditional W experiment fixed. The two exact capacities add across the disjoint true source pockets.',
           limits='True finite 1/2/3-dimensional source and owner geometry of the frozen diagnostic fixtures. No general high-dimensional capacity or rerouting claim.'))
    text=json.dumps(output,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for s in results:
            p=s['strictly_formulated_partitions']
            c=s['capacity_certificates'][s['common_capacity_certificate_id']]
            print(s['stage'],'c/max/union',c['capacity'],c['max_J'],c['true_mu_union'],
                  'global/receiver/half scores',*[format(float(p[i]['total_joint_capacity_score']),'.9g') for i in (0,3,4)],
                  'actual sliced capacity',s['axis_sliced_diagnostic']['exact_capacity_sum_of_disjoint_sides'])
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
