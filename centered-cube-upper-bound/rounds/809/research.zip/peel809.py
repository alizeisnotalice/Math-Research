#!/usr/bin/env python3
"""Exact whole-row deletion by strict-majority source capacities."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import combinations, product
import json
from math import lcm
from pathlib import Path
import platform
import subprocess
import sys


DEPENDENCIES={
    'cap809.json':'9711c45bde9a4f181c4fb48943b2ecd7a2e58784ac16380cbd403ce30158066e',
    'reverse805.py':'c9a810c2807fa592e0fc76c514738522d8414d2e01c548579856e64d8b7fb17e',
    'reverse805.json':'955de184b852e78a2913ca9e1865404afa746c0425a920c3aa80bf9896dad886',
}
GRID=tuple(map(F,(0,'1/8','1/4','1/2',1,2,4)))


def total(x):
    return sum(x,F(0))


def active(mask,i):
    return bool((mask>>i)&1)


def as_box(B):
    return tuple(tuple(map(F,row)) for row in B)


def scheduling(boxes,mu):
    """Whole-group value for the separate sliced-regression certificates."""
    values=[]
    ordered=sorted(boxes,key=lambda B:B[0][1])
    for i,B in enumerate(ordered):
        left=B[0][0]
        other=max((values[k] for k in range(i) if ordered[k][0][1]<=left),default=F(0))
        best=max(values[-1] if values else F(0),mu(B)+other)
        values.append(best)
    return values[-1]


def audit_original_capacity(cert,boxes,mu,model):
    labels=[tuple(e) for e in cert['actual_edges']]
    J={tuple(r['e']):F(r['J']) for r in cert['real_edge_demands']}
    assert all(J[e]==mu(boxes[e]) for e in labels)
    delivered=dict.fromkeys(labels,F(0))
    primal=F(0)
    for p in cert['primal_positive_source_deposits']:
        Q=as_box(p['actual_source_subbox'])
        mass=mu(Q)
        w=F(p['assigned_w'])
        assert mass==F(p['positive_true_mu'])>0 and w>=0
        covered={tuple(e) for e in p['active_demands']}
        assert all(mu(model.clip(Q,boxes[e]))==(mass if e in covered else 0) for e in labels)
        for e in covered:
            delivered[e]+=w
        primal+=w
    ds=[tuple(e) for e in cert['dual_unit_edges']]
    assert all(mu(model.clip(boxes[i],boxes[j]))==0 for i,j in combinations(ds,2))
    dual=total(J[e] for e in ds)
    assert all(delivered[e]>=J[e] for e in labels)
    assert primal==dual==F(cert['capacity'])==F(cert['capacity_by_exact_primal'])==F(cert['capacity_by_exact_disjoint_dual'])
    return labels,primal


class Fixture:
    def __init__(self,physical,prior,model):
        self.name=physical['stage']
        self.mu=lambda B:model.source_mass(B,F(physical['true_source_amplitude']))
        self.M=F(prior['M'])
        T,U=physical['middle_cubes'],physical['small_cubes']
        rows=prior['actual_original_W_and_t_u_joint']
        Ws=sorted(tuple(r['W']) for r in rows)
        full={(tuple(r['W']),tuple(s['e'])):F(s['mass']) for r in rows for s in r['absolute_t_u_masses']}
        labels={e for _,e in full}
        boxes={e:model.clip(as_box(T[e[0]]['A']),as_box(U[e[1]]['A'])) for e in labels}
        self.e=sorted(labels,key=lambda e:(boxes[e][0][1],e))
        self.j_scale=lcm(*(self.mu(boxes[e]).denominator for e in self.e))
        costs=[int(self.mu(boxes[e])*self.j_scale) for e in self.e]
        mask_before=[sum(1<<j for j,f in enumerate(self.e[:i]) if boxes[f][0][1]<=boxes[e][0][0])
                     for i,e in enumerate(self.e)]
        cap=[0]*(1<<len(self.e))
        for m in range(1,len(cap)):
            i=m.bit_length()-1
            cap[m]=max(cap[m^(1<<i)],costs[i]+cap[m&mask_before[i]])
        self.cap=cap
        self.labels=[sorted({e[0] for e in self.e}),Ws]
        self.cost_denominator=[{i:F(T[t]['m']) for i,t in enumerate(self.labels[0])},
                               {i:self.M for i in range(len(Ws))}]
        self.cut_scale=lcm(*(v.denominator for v in full.values()))
        self.both_masks=tuple((1<<len(r))-1 for r in self.labels)
        self.parts=[defaultdict(list),defaultdict(list)]
        self.events=[]
        epos={e:i for i,e in enumerate(self.e)}
        for (W,(t,u)),mass in sorted(full.items()):
            i,j=self.labels[0].index(t),Ws.index(W)
            entry=(i,j,epos[t,u],int(mass*self.cut_scale))
            eid=len(self.events)
            self.events.append(entry)
            self.parts[0][i].append(eid)
            self.parts[1][j].append(eid)
        self.initial=F(prior['original_true_mother_mass'])*self.cut_scale
        assert self.initial.denominator==1
        self.initial=int(self.initial)
        assert sum(row[3] for row in self.events)==self.initial>0
        self.old_cert_count=0
        for cert in prior['capacity_certificates']:
            E,c=audit_original_capacity(cert,boxes,self.mu,model)
            mask=sum(1<<epos[e] for e in E)
            assert c==F(cap[mask],self.j_scale)
            self.old_cert_count+=1
        sliced=prior['axis_sliced_diagnostic']
        for name in ('left','right','complete_sliced_certificate'):
            cert=sliced[name]
            sl={}
            cut=F(sliced['cut'])
            for t,u,d in cert['actual_edges']:
                B=boxes[t,u]
                a,b=B[0]
                sl[t,u,d]=(((a,min(b,cut)) if d<0 else (max(a,cut),b)),)+B[1:]
            E,c=audit_original_capacity(cert,sl,self.mu,model)
            assert c==scheduling([sl[e] for e in E],self.mu)
            self.old_cert_count+=1

    def labels_of(self,mask):
        return [e for i,e in enumerate(self.e) if active(mask,i)]

    @lru_cache(maxsize=None)
    def threshold(self,side,label,opposite_live):
        weights=defaultdict(int)
        for event in self.parts[side][label]:
            row=self.events[event]
            if active(opposite_live,row[1-side]):
                weights[row[2]]+=row[3]
        mother=sum(weights.values())
        if not mother:
            return None
        subsets=[(0,0)]
        for e,w in sorted(weights.items()):
            subsets.extend([(mask|(1<<e),mass+w) for mask,mass in subsets])
        best=None
        weak=None
        for mask,paid in subsets[1:]:
            if 2*paid>=mother:
                cand=self.cap[mask],mask,paid
                if weak is None or cand<weak:
                    weak=cand
                if 2*paid>mother and (best is None or cand<best):
                    best=cand
        assert best is not None and weak is not None and 2*best[2]>mother
        norm=self.cost_denominator[side][label]
        return dict(strict_half_capacity_over_row_scale=F(best[0],self.j_scale)/norm,
            weak_half_capacity_over_row_scale=F(weak[0],self.j_scale)/norm,
            strict_majority_capacity=F(best[0],self.j_scale),strict_majority_actual_edges=self.labels_of(best[1]),
            strict_majority_weight_fraction=F(best[2],mother),current_positive_row_mass=F(mother,self.cut_scale))

    def candidates(self,side,state,budget):
        active_rows={}
        for i in range(len(self.labels[side])):
            if not active(state[side],i):
                continue
            cert=self.threshold(side,i,state[1-side])
            if cert and cert['strict_half_capacity_over_row_scale']<=budget:
                active_rows[i]=cert
        return active_rows

    def simulate(self,bt,bw,schedule):
        state=list(self.both_masks)
        good=set(range(len(self.events)))
        pay=[]
        used_rows=set()
        budgets=(bt,bw)
        plans={'t_only':((0,),),'W_only':((1,),),'t_then_W':((0,),(1,)),
                'W_then_t':((1,),(0,)),'both_same_snapshot':((0,1),)}[schedule]
        removed_weight=0
        while True:
            changed=False
            for sides in plans:
                picked=[self.candidates(s,state,budgets[s]) if s in sides else {} for s in (0,1)]
                if not any(picked):
                    continue
                changed=True
                fresh=[]
                credited=defaultdict(int)
                for e in sorted(good):
                    row=self.events[e]
                    eligible=[s for s in sides if row[s] in picked[s]]
                    if eligible:
                        fresh.append(e)
                        s=eligible[0]
                        credited[s,row[s]]+=row[3]
                assert fresh
                paid=sum(self.events[e][3] for e in fresh)
                assert paid==sum(credited.values())>0
                steps=[]
                for s in sides:
                    for i,cert in picked[s].items():
                        assert (s,i) not in used_rows
                        used_rows.add((s,i))
                        state[s]^=1<<i
                        steps.append(dict(side=('t','W')[s],row=self.labels[s][i],
                            paid_once_original_mass=F(credited[s,i],self.cut_scale),**cert))
                good.difference_update(fresh)
                removed_weight+=paid
                remain=sum(self.events[e][3] for e in good)
                assert remain+removed_weight==self.initial
                pay.append(dict(rows=steps,paid_mass=F(paid,self.cut_scale),remaining_mass=F(remain,self.cut_scale)))
            if not changed:
                break
        for s in {s for sides in plans for s in sides}:
            assert not self.candidates(s,state,budgets[s])
        assert set(e for e,row in enumerate(self.events) if all(active(state[s],row[s]) for s in (0,1)))==good
        live_fraction=F(self.initial-removed_weight,self.initial)
        assert live_fraction==1-total(w['paid_mass'] for w in pay)/F(self.initial,self.cut_scale)
        compact=dict(live_fraction=live_fraction,whole_row_payment_phases=len(pay),
            surviving_original_positive_entry_count=len(good),
            paid_rows=[(row['side'],row['row']) for wave in pay for row in wave['rows']])
        return compact,pay,good

    def independent_union(self,bt,bw):
        low=[self.candidates(s,self.both_masks,b) for s,b in enumerate((bt,bw))]
        return F(sum(v for i,j,_,v in self.events if i not in low[0] and j not in low[1]),self.initial)


def example(stage,prior,model):
    f=Fixture(stage,prior,model)
    cached={}
    for s,name in enumerate(('t_only','W_only')):
        cached[name]=[dict(budget=b,**f.simulate(b if s==0 else F(0),b if s==1 else F(0),name)[0]) for b in GRID]
    base_rows=[]
    for s in (0,1):
        base_rows.append([dict(label=lab,**f.threshold(s,i,f.both_masks[1-s])) for i,lab in enumerate(f.labels[s])])
    table=[]
    witness=None
    counts=defaultdict(int)
    for bt,bw in product(GRID,repeat=2):
        union=f.independent_union(bt,bw)
        result={sched:f.simulate(bt,bw,sched) for sched in ('t_then_W','W_then_t','both_same_snapshot')}
        summary={sched:x[0] for sched,x in result.items()}
        lv=[x['live_fraction'] for x in summary.values()]
        diff=len({frozenset(x[2]) for x in result.values()})>1
        later=len(result['both_same_snapshot'][1])>1
        counts['later_parallel_wave']+=later
        counts['schedule_dependent_terminal_edge_set']+=diff
        counts['joint_smaller_than_first_independent_union']+=any(h<union for h in lv)
        counts['joint_larger_than_first_independent_union']+=any(h>union for h in lv)
        counts['nonempty_terminal_all_schedules']+=all(h>0 for h in lv)
        score=max(abs(h-union) for h in lv),int(diff),int(later)
        entry=dict(B_t=bt,B_W=bw,survival_if_only_union_of_independent_first_pass=union,
                   simultaneous_old_snapshot_has_later_cascade=later,schedule_changes_terminal_edge_set=diff,**summary)
        if score>(F(0),0,0) and (witness is None or score>witness[0]):
            witness=score,dict(entry,exact_payment_waves={k:v[1] for k,v in result.items()})
        table.append(entry)
    no_interaction=not any(counts[k] for k in ('later_parallel_wave','schedule_dependent_terminal_edge_set',
                                               'joint_smaller_than_first_independent_union','joint_larger_than_first_independent_union'))
    refine=None
    if no_interaction:
        # Only if needed, test the genuine initial threshold breakpoints in this same finite fixture.
        true_knots=[sorted({c['strict_half_capacity_over_row_scale'] for c in row}) for row in base_rows]
        for bt,bw in product(*true_knots):
            union=f.independent_union(bt,bw)
            choices={k:f.simulate(bt,bw,k) for k in ('t_then_W','W_then_t','both_same_snapshot')}
            if any(res[0]['live_fraction']!=union for res in choices.values()) or len(choices['both_same_snapshot'][1])>1:
                refine=dict(B_t=bt,B_W=bw,first_independent_union=union,
                    exact_results={k:dict(v[0],payment_waves=v[1]) for k,v in choices.items()})
                break
    return dict(stage=stage['stage'],dimension=stage['n'],true_original_mother=F(f.initial,f.cut_scale),
        total_original_positive_entries=len(f.events),true_t_u_edge_labels=len(f.e),all_subset_capacities_computed=len(f.cap),
        frozen_cap809_primal_dual_certificates_rechecked=f.old_cert_count,
        initial_strict_vs_weak_majority_changes=[sum(r['strict_half_capacity_over_row_scale']!=r['weak_half_capacity_over_row_scale'] for r in b) for b in base_rows],
        initial_t_rows=base_rows[0],initial_W_rows=base_rows[1],independent_one_side=cached,whole_cartesian_grid=table,
        interaction_grid_counts=dict(counts),strongest_actual_grid_interaction=witness[1] if witness else None,
        targeted_refinement_only_if_no_coarse_interaction=refine)


def main():
    here=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--r805-dir',type=Path,default=here)
    files=p.add_mutually_exclusive_group()
    files.add_argument('--output',type=Path)
    files.add_argument('--check',type=Path)
    args=p.parse_args()
    r5=args.r805_dir.resolve()
    for name,h in DEPENDENCIES.items():
        if name!='reverse805.json':
            assert sha256(((r5 if '805' in name else here)/name).read_bytes()).hexdigest()==h
    sys.path.insert(0,str(r5))
    import reverse805 as model
    fixture=r5/'reverse805.json'
    raw=fixture.read_bytes() if fixture.is_file() else subprocess.check_output([sys.executable,'-B',str(fixture.with_suffix('.py'))])
    assert sha256(raw).hexdigest()==DEPENDENCIES['reverse805.json']
    st=json.loads(raw)['stages']
    cp=json.loads((here/'cap809.json').read_text())['stages']
    data=[]
    for s,r in zip(st,cp,strict=True):
        assert s['stage']==r['stage']
        data.append(example(s,r,model))
    out=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='exact integers and Fraction'),
        reproduction='python -B peel809.py --check peel809.json',dependencies=DEPENDENCIES,
        budgets=GRID,stages=data,
        scope=dict(data='One frozen bin pair per actual fixture. W denotes the true owner half, and the starting weights come from cap809 original raw first edges with full degrees.',
          row='Only a subset with strictly more than half the currently surviving row weight qualifies. The whole row is then deleted if its minimum such source capacity divided by true m_t or by M for W is at most the corresponding fixed budget.',
          geometry='Every subset capacity uses the proved nested-transverse genuine cube interval recurrence. All frozen cap809 unsliced and sliced primal/dual certificates are independently rechecked against actual physical source and their exact demands.',
          schedule='One-side states, two alternating batch orders, and both sides from the same previous snapshot are compared. On a simultaneous snapshot, t is assigned the overlapping payment first and each original positive entry is paid once. Unpaid mass equals true retained mass. Zero rows are inert.',
          diagnostics='Cartesian grid on the two fixed dimensionless budgets. A targeted refinement at genuine initial threshold breakpoints occurs only if a fixture has no coarse interaction. Finite diagnostic geometry, without a fitted dimensional rate or additional asymptotic gate.'))
    text=json.dumps(out,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for x in data:
            print(x['stage'],x['all_subset_capacities_computed'],'sets',x['interaction_grid_counts'],
                  'strict vs weak',x['initial_strict_vs_weak_majority_changes'])
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
