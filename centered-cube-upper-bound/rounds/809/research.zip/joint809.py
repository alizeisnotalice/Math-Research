#!/usr/bin/env python3
"""Check the two actual overlap factors, balanced parent routing, and posterior moment."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys

import flint
from flint import arb, fmpq
import sympy


def total(items):
    return sum(items, F(0))


def digest(data):
    return sha256(data).hexdigest()


def ball(r):
    return arb(fmpq(r.numerator, r.denominator))


def interval(x):
    return x.str(27)


def projected_table(stage, frozen, model, old, triples):
    fibres, marks, T, U, mu, mid_bin, small_bin, *_ = triples.genuine_config(stage, model, old)
    M, D = (F(frozen[k]) for k in ('M', 'D'))
    tm = [t for t in range(len(T)) if mid_bin[t] == M]
    ud = [u for u in range(len(U)) if small_bin[u] == D]
    Tbox = [old.box(a['A']) for a in T]
    Ubox = [old.box(a['A']) for a in U]
    boxes = []
    def idx(box):
        if box not in boxes:
            boxes.append(box)
        return boxes.index(box)
    it = {t:idx(Tbox[t]) for t in tm}
    iu = {u:idx(Ubox[u]) for u in range(len(U))}
    igleft = {g:idx(model.two_halves(Ubox[g])[0]) for g in range(len(U))}
    prices = {idx(row['price']) for t in tm for row in marks[t].values()}
    # Re-aggregate the physical old price by the same active price boxes and
    # physical middle-cube tags as in reuse809. Additional cuts refine q only.
    ztags = {idx(marks[t][left]['price']) for t in tm for row in fibres[t].values()
             for left in row if left[0] in ud} | set(it.values())
    items = [dict(retained_true_flux=1, external=[B], true_mu_external=mu(B)) for B in boxes]
    atoms, _ = model.source_membership_atoms(items, stage['n'], mu)
    atoms = [(frozenset(tags), weight) for tags, weight in atoms if weight]
    zparts, qparts = defaultdict(lambda: defaultdict(F)), defaultdict(lambda: defaultdict(F))
    zdomain = {}
    for tags, weight in atoms:
        z = tuple(sorted(tags & ztags))
        zdomain[z] = (tuple(t for t in tm if it[t] in tags),)
        # The actual small parents can extend the z-partition; store supports
        # below only for the old labels with positive root mass.
        for box_id in tags & prices:
            zparts[box_id][z] += weight
        for g in range(len(U)):
            if iu[g] not in tags:
                continue
            full_tag = (int(igleft[g] in tags), tuple(sorted(tags & (prices | set(it.values())))))
            qparts[g, -1][full_tag] += weight
            for box_id in tags & prices:
                qparts[g, box_id][full_tag] += weight
    Warea = {(g,k):model.volume(B) for g in range(len(U))
             for k,B in enumerate(model.two_halves(old.box(U[g]['owner'])))}
    mt = {t:F(T[t]['m']) for t in tm}
    mu_u = {u:F(U[u]['m']) for u in range(len(U))}
    bt = {t:F(T[t]['j'])/mt[t] for t in tm}
    bu = {u:F(U[u]['j'])/mu_u[u] for u in range(len(U))}
    vg = {g:F(U[g]['j'])/F(U[g]['v']) for g in range(len(U))}
    alpha = {(t,u):mu(model.clip(Tbox[t],Ubox[u]))/mu_u[u] for t in tm for u in range(len(U))}
    dm = min(F(stage['true_physical_degrees'][t]['d_original']) for t in tm)
    # N[z,W,q membership,t,u] is the actual 1/c_h distinguished marginal.
    fine = defaultdict(F)
    for t in tm:
        for b, right in fibres[t].items():
            g, _, k = b
            ib = idx(marks[t][b]['price'])
            qcells = qparts[g,ib]
            mq = total(qcells.values())
            assert mq == mu(marks[t][b]['price']) > 0
            for a, root_mass in right.items():
                u = a[0]
                if u not in ud:
                    continue
                ia = idx(marks[t][a]['price'])
                zcells = zparts[ia]
                mz = total(zcells.values())
                assert mz == mu(marks[t][a]['price']) > 0
                for z, zw in zcells.items():
                    for q, qw in qcells.items():
                        fine[z,(g,k),q,t,u] += root_mass*zw*qw/(mz*mq)
    R = total(fine.values())
    assert R == F(frozen['original_retained_first_edge_mass_independent_check'])
    results = []
    for name, channel in (('receiver',lambda q:()), ('receiver_and_q_side',lambda q:q[0]),
                          ('receiver_and_full_q',lambda q:q)):
        mx = defaultdict(lambda:defaultdict(F))
        mc = defaultdict(lambda:defaultdict(F))
        mz = defaultdict(lambda:defaultdict(F))
        theta, source = defaultdict(F), defaultdict(F)
        for (z,W,q,t,u),v in fine.items():
            c = (W,channel(q))
            mx[z,c][t,u] += v
            mc[c][t,u] += v
            mz[z][t,u] += v
        for (g,k),area in Warea.items():
            for q, weight in qparts[g,-1].items():
                c = ((g,k),channel(q))
                v = vg[g]*area*weight/mu_u[g]
                theta[c] += v
                for t in tm:
                    if it[t] in q[1]:
                        source[c,t] += v
        Y = total(F(G['j']) for G in U)
        assert total(theta.values()) == Y
        omega = {ct:f/theta[ct[0]] for ct,f in source.items()}
        for c,row in mc.items():
            for (t,u),v in row.items():
                assert v <= theta[c]*bt[t]*bu[u]*(mu_u[u]/mt[t])*alpha[t,u]*omega[c,t]/dm
        marginal_c = {c:total(row.values()) for c,row in mc.items()}
        occ_t = max(total(bt[t] for t in actual) for (actual,) in zdomain.values())
        occ_u = max(total(bu[u] for u in ud if iu[u] in tags) for tags,_ in atoms)
        cap = Y*occ_t*occ_u/dm
        invmoment = Iraw = F(0)
        I = arb(0)
        Dweight = arb(0)
        uncovered = [F(0), F(0)]
        worst = [F(0), F(0)]
        for (z,c),row in mx.items():
            row_mass = total(row.values())
            for (t,u),v in row.items():
                ratio = (v/row_mass)/(mc[c][t,u]/marginal_c[c])
                weight = mt[t]/(mu_u[u]*alpha[t,u]*omega[c,t])
                invmoment += v*weight/ratio
                Iraw += v/ratio
                I += ball(v/R)*ball(ratio).log()
                Dweight += ball(v/R)*ball(weight).log()
                for i, factor in enumerate((F(1),weight)):
                    uncovered[i] += v*(1-min(F(1),factor/ratio))
                    worst[i] = max(worst[i],ratio/factor)
        assert invmoment <= cap
        margin = I-Dweight+ball(invmoment/R).log()
        assert margin >= 0 or margin.contains(0)
        # Conditional on z alone, sample its real t or u; route to a receiver
        # observation under the original law conditional on that very label.
        label_mass = [defaultdict(F),defaultdict(F)]
        for row in mc.values():
            for pair,v in row.items():
                for i,l in enumerate(pair):
                    label_mass[i][l] += v
        routed = defaultdict(F)
        rooted_cover = [F(0),F(0)]
        for z,row in mz.items():
            for c,crow in mc.items():
                K = total(total(v for p,v in row.items() if p[i]==l)*
                          total(v for p,v in crow.items() if p[i]==l)/label_mass[i][l]
                          for i in range(2) for l in label_mass[i])/2
                routed[z,c] = K
            assert total(routed[z,c] for c in mc) == total(row.values())
            for pair,v in row.items():
                t,u = pair
                supported = [c for c in mc if pair in mc[c]]
                unweighted = total(routed[z,c]*mc[c][pair]/marginal_c[c] for c in supported)
                compensated = total(routed[z,c]*mc[c][pair]/marginal_c[c]*
                               mt[t]/(mu_u[u]*alpha[t,u]*omega[c,t]) for c in supported)
                rooted_cover[0] += min(v,unweighted)
                rooted_cover[1] += min(v,compensated)
        assert all(total(routed[z,c] for z in mz)==v for c,v in marginal_c.items())
        results.append(dict(channel=name,active_reference_states=len(mc),positive_joint_price_rows=len(mx),
              actual_total=R,inverse_moment=invmoment,unweighted_inverse_moment=Iraw,
              physical_occupancy_upper=cap,receiver_weight=Y,d_min=dm,
              middle_occupancy=occ_t,small_occupancy=occ_u,cost_over_certified_upper=invmoment/cap,
              canonical_actual_coverage_at_A1=[1-w/R for w in uncovered],
              canonical_full_coverage_threshold=worst,
              single_parent_balanced_routing_coverage_at_A1=[w/R for w in rooted_cover],
              conditional_information_nats=interval(I),mean_log_compensation=interval(Dweight),
              jensen_gap_nats=interval(margin)))
    return dict(stage=stage['stage'],physical_dimension=stage['n'],z_positive= len(mz),
                labels=len(set((t,u) for z,W,q,t,u in fine)),results=results)


def main():
    args=argparse.ArgumentParser(description=__doc__)
    args.add_argument('--upstream',type=Path,default=Path.cwd())
    args.add_argument('--reuse',type=Path,default=Path('reuse809.json'))
    args.add_argument('--output',type=Path,required=True)
    cli=args.parse_args()
    sys.path.insert(0,str(cli.upstream.resolve()))
    import reverse805 as model
    import shared805 as old
    import triples806 as triples
    flint.ctx.prec=384
    prior=(cli.upstream/'reverse805.json').read_bytes()
    prior_check=cli.reuse.read_bytes()
    assert digest(prior)=='955de184b852e78a2913ca9e1865404afa746c0425a920c3aa80bf9896dad886'
    assert digest(prior_check)=='8e966167489ee0abc5f149c3eebf4936c06f4ef9a2bb02562ca4a5a511819ce3'
    m_t,m_u,a,h,b_t,b_u,v,deg = sympy.symbols('m_t m_u a h b_t b_u v deg',positive=True)
    expanded=(b_t*m_t)*(b_u*m_u)*(a/m_t)*(v*h/m_t)/deg
    factor=v*b_t*b_u*m_u/m_t*a*h/deg
    assert sympy.cancel(expanded-factor)==0
    stages=[projected_table(s,k,model,old,triples) for s,k in zip(json.loads(prior)['stages'],
                                          json.loads(prior_check)['stages'],strict=True)]
    scope=('True physical old price is the original diagnostic A_t intersection A_u in these fixtures. '
           'The fresh y coordinate is integrated on its true exterior pocket. '
           'No large-dimension terminal assumptions are imposed. For the compensation experiment '
           'we retain the two input-mass intersection fractions and the volume ratio. '
           'The geometric two-point product is omitted from the multiplier. The single-price owner '
           'caps are used to bound the exact sum. The three channels reveal progressively more '
           'of the same opposite price. Its full membership cell suffices because all relevant '
           'edge densities relative to the true source are constant there.')
    result=dict(python=platform.python_version(),sympy=sympy.__version__,flint=flint.__version__,
                arb_bits=flint.ctx.prec,scope=scope,input_sha256=[digest(prior),digest(prior_check)],stages=stages)
    cli.output.write_text(json.dumps(result,indent=2,sort_keys=True,default=str)+'\n')
    for s in stages:
        for row in s['results']:
            print(s['stage'],row['channel'],s['z_positive'],row['active_reference_states'],
                  'moment/cap',float(row['cost_over_certified_upper']),
                  'canonical',[round(float(v),8) for v in row['canonical_actual_coverage_at_A1']],
                  'one-parent',[round(float(v),8) for v in row['single_parent_balanced_routing_coverage_at_A1']])
if __name__=='__main__':
    main()

