#!/usr/bin/env python3
"""All genuine same-bin price cells and exact shared-owner repeat laws."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform
import subprocess
import sys


DEPENDENCIES={
    'ranks807.json':'b35edff1c0c8d097197f5a7017691a71dfcc859ee4fc9e1a57703dfb80bcabac',
    'rectangle806.py':'04714603e8dfbc8b7fe6f1f9e431c4fd8cf9c3b671e567e34bd5315244c576be',
    'triples806.py':'203a1f2ff8c6e13b66f77ad81055e71471f87b59ae805a3037c69d4ed0e3ae98',
    'reverse805.py':'c9a810c2807fa592e0fc76c514738522d8414d2e01c548579856e64d8b7fb17e',
    'reverse805.json':'955de184b852e78a2913ca9e1865404afa746c0425a920c3aa80bf9896dad886',
    'shared805.py':'d35faf62af4a6498cfaff0bd8ce1b59ebdd870143847660c67f02aa0aa10ceab',
}


def total(x):
    return sum(x,F(0))


def price_atoms(stage,config,M,D,model,old,frozen_box):
    fibres,marks,T,U,mu,middle_bin,small_bin,*_=config
    old_boxes={}
    for t,frame in enumerate(fibres):
        if middle_bin[t]!=M:
            continue
        for row in frame.values():
            for u,z,r in row:
                if small_bin[u]==D:
                    old_boxes[t,u,z]=marks[t][u,z,r]['price']
    boxes=[old_boxes[key] for key in sorted(old_boxes)]
    n_price=len(boxes)
    physical_middles=[t for t in range(len(T)) if middle_bin[t]==M]
    boxes.extend(old.box(T[t]['A']) for t in physical_middles)
    price_records=[dict(retained_true_flux=1,external=[B],true_mu_external=mu(B)) for B in boxes]
    atoms,reps=model.source_membership_atoms(price_records,stage['n'],mu)
    assert total(m for _,m in atoms)==mu(((-model.SUPPORT,model.SUPPORT),)*stage['n'])
    original_vol=model.volume(frozen_box)
    original_tags=[]
    for i,B in enumerate(boxes):
        vol=model.volume(model.clip(frozen_box,B))
        assert vol in (0,original_vol)
        if vol:
            original_tags.append(i)
    frozen_atom=None
    result=[]
    for z,(tags,weight) in enumerate(atoms):
        if tuple(original_tags)==tags:
            frozen_atom=z
        physical_mask=tuple(physical_middles[i-n_price] for i in tags if i>=n_price)
        result.append((z,reps[tags],weight,physical_mask,any(i<n_price for i in tags)))
    assert frozen_atom is not None
    return result,frozen_atom


def edges_by_owner(H,Ht,lx,ra):
    raw=defaultdict(F)
    rooted=defaultdict(F)
    gram=F(0)
    merges=0
    for x,row in H.items():
        direction,t,g,_,half=x
        if direction!=0:
            continue
        other={}
        for xx,xxrow in H.items():
            cc=total(ra[a]*row[a]*xxrow[a] for a in row.keys()&xxrow.keys())
            other[xx]=lx[xx]*cc
            gram+=lx[x]*lx[xx]*cc**2
        for a,h in row.items():
            c=total(other[xx]*ha for xx,ha in Ht[a].items())
            assert c>0
            u=a[0]
            w=lx[x]*ra[a]*h
            raw[((g,half),t,u)]+=w*c
            rooted[((g,half),t,u)]+=w
            merges+=1
    assert gram==total(raw.values())
    return raw,rooted,merges


def summaries(marks):
    mt=defaultdict(F)
    mu=defaultdict(F)
    for (t,u),w in marks.items():
        mt[t]+=w
        mu[u]+=w
    w=total(mt.values())
    assert w==total(mu.values())>0
    return w,dict(mt),dict(mu)


def collect_atoms(mother):
    by_z,by_W=defaultdict(dict),defaultdict(dict)
    for (z,W),cell in mother.items():
        v=summaries(cell)
        by_z[z][W]=v
        by_W[W][z]=v
    return dict(by_z),dict(by_W)


def fuse(rows):
    marks=F(0)
    mt=defaultdict(F)
    mu=defaultdict(F)
    for w,tt,uu in rows:
        marks+=w
        for t,b in tt.items():
            mt[t]+=b
        for u,a in uu.items():
            mu[u]+=a
    assert marks==total(mt.values())==total(mu.values())>0
    return marks,dict(mt),dict(mu)


def compare_reuse(mother,z_info,W_area,G_ratio):
    by_z,by_W=collect_atoms(mother)
    S=total(v[0] for row in by_z.values() for v in row.values())
    W_sum={W:fuse(row.values()) for W,row in by_W.items()}
    z_sum={z:fuse(row.values()) for z,row in by_z.items()}
    assert total(w[0] for w in W_sum.values())==S==total(w[0] for w in z_sum.values())>0

    def label_overlap(u,v):
        return total(a*b*G_ratio[i][j] for (i,a),(j,b) in product(u.items(),v.items()))

    # Integrate over receiving sectors first. Actual W is uniformly spread on
    # each E_g half, so the marked density is the sector's mass divided by area.
    W_diag=W_old_hit=W_diag_hit=W_G=W_diag_G=F(0)
    collision_diag=collision_cross=F(0)
    extreme_cross=(F(0),None)
    for W,row in by_W.items():
        w,t,u=W_sum[W]
        local_diag=total(v[0]**2 for v in row.values())
        W_diag+=local_diag/w
        W_diag_hit+=total(v[0]*total(a for k,a in v[1].items() if k in z_info[z][2]) for z,v in row.items())/w
        W_old_hit+=total(a*total(v[0] for z,v in row.items() if k in z_info[z][2]) for k,a in t.items())/w
        W_G+=label_overlap(u,u)/w
        W_diag_G+=total(label_overlap(v[2],v[2]) for v in row.values())/w
        collision_diag+=local_diag/W_area[W]
        collision_cross+=(w*w-local_diag)/W_area[W]
        for (z,q),(zz,qq) in product(row.items(),repeat=2):
            if z!=zz and q[0]*qq[0]/w>extreme_cross[0]:
                extreme_cross=q[0]*qq[0]/w,(z,zz,W)
    W_cross=S-W_diag
    assert W_diag_hit==W_diag

    # Independently sum each ordered pair of public old-price membership cells.
    z_diag=z_cross=z_hit=z_hit_diag=z_G=z_G_diag=F(0)
    raw_diag=raw_cross=F(0)
    baseline_mass=baseline_diag=baseline_hit=baseline_diag_hit=baseline_G=baseline_G_diag=F(0)
    price_pair_rows=[]
    for z,zz in product(by_z,repeat=2):
        left,right=by_z[z],by_z[zz]
        shared_W=left.keys()&right.keys()
        zz_middles=z_info[zz][2]
        shared=total(left[W][0]*right[W][0]/W_sum[W][0] for W in shared_W)
        hit=total(total(v for t,v in left[W][1].items() if t in zz_middles)*right[W][0]/W_sum[W][0]
                  for W in shared_W)
        G=total(label_overlap(left[W][2],right[W][2])/W_sum[W][0] for W in shared_W)
        C=total(left[W][0]*right[W][0]/W_area[W] for W in shared_W)
        zb,zzb=z_sum[z],z_sum[zz]
        bb=zb[0]*zzb[0]/S
        b_hit=total(x for t,x in zb[1].items() if t in zz_middles)*zzb[0]/S
        b_G=label_overlap(zb[2],zzb[2])/S
        baseline_mass+=bb
        baseline_hit+=b_hit
        baseline_G+=b_G
        z_hit+=hit
        z_G+=G
        if z==zz:
            z_diag+=shared
            z_hit_diag+=hit
            z_G_diag+=G
            raw_diag+=C
            baseline_diag+=bb
            baseline_diag_hit+=b_hit
            baseline_G_diag+=b_G
        else:
            z_cross+=shared
            raw_cross+=C
        price_pair_rows.append((z,zz,shared,hit,G,C,bb,b_hit,b_G))
    assert baseline_mass==z_diag+z_cross==S
    assert z_diag==W_diag and z_cross==W_cross
    assert z_hit==W_old_hit and z_hit_diag==W_diag_hit
    assert z_G==W_G and z_G_diag==W_diag_G
    assert raw_diag==collision_diag and raw_cross==collision_cross
    assert baseline_diag==baseline_diag_hit
    assert 0<=z_G<=S and 0<=baseline_G<=S and 0<=z_hit<=S and 0<=baseline_hit<=S
    for z,v in z_sum.items():
        assert total(row[2] for row in price_pair_rows if row[0]==z)==v[0]
        assert total(row[2] for row in price_pair_rows if row[1]==z)==v[0]
    original_ind_same_sector=total(v[0]**2 for v in W_sum.values())/S**2
    digest=sha256(json.dumps(price_pair_rows,default=str,separators=(',',':')).encode()).hexdigest()
    by_W_rows=[dict(W=W,actual_Lebesgue=W_area[W],mother=w[0],latent_central_mass=w[1],latent_old_mass=w[2],
                    number_positive_old_price_cells=len(by_W[W]),each_old_price_cell_mass=[(z,v[0]) for z,v in sorted(by_W[W].items())])
               for W,w in sorted(W_sum.items())]
    return dict(mother=S,mother_by_public_price_cell=dict((z,v[0]) for z,v in z_sum.items()),
          original_single_root_marginals_preserved=True,
          actual_shared_W_diag_same_price_cell_mass=z_diag,actual_shared_W_cross_different_price_cell_mass=z_cross,
          actual_shared_W_same_price_cell_probability=z_diag/S,actual_shared_W_cross_price_cell_probability=z_cross/S,
          actual_independent_W_same_price_cell_mass=baseline_diag,actual_independent_W_different_price_cell_mass=S-baseline_diag,
          actual_independent_W_same_price_cell_probability=baseline_diag/S,
          actual_independent_W_same_owner_half_probability=original_ind_same_sector,
          actual_shared_W_z2_in_original_t1_probability=z_hit/S,
          independent_W_z2_in_original_t1_probability=baseline_hit/S,
          actual_shared_W_rehit_given_different_price_cells=(z_hit-z_hit_diag)/z_cross if z_cross else None,
          independent_W_rehit_given_different_price_cells=(baseline_hit-baseline_diag_hit)/(S-baseline_diag) if S>baseline_diag else None,
          actual_shared_W_overlap_G_two_given_first_mass_probability=z_G/S,
          independent_W_overlap_G_two_given_first_mass_probability=baseline_G/S,
          actual_shared_W_overlap_G_given_different_price_cells=(z_G-z_G_diag)/z_cross if z_cross else None,
          independent_W_overlap_G_given_different_price_cells=(baseline_G-baseline_G_diag)/(S-baseline_diag) if S>baseline_diag else None,
          unnormalized_shared_Lebesgue_W_collision_same_price_cell=raw_diag,unnormalized_shared_Lebesgue_W_collision_different_price_cells=raw_cross,
          two_order_validated=True,exact_complete_price_pair_table_SHA256=digest,
          max_single_reused_W_cross_cell_witness=dict(mass=extreme_cross[0],price1_price2_W=extreme_cross[1]),
          W_actual_sector_rows=by_W_rows)


def example(stage,frozen,model,old,triples):
    w=frozen['fixed_original_anchor_witness']
    M,D=F(w['central_bin']),F(w['small_bin'])
    config=triples.genuine_config(stage,model,old)
    _,_,_,U,mu,*_=config
    frozen_box=old.box(w['points']['z']['positive_subbox'])
    candidates,frozen_atom=price_atoms(stage,config,M,D,model,old,frozen_box)
    geom={}
    status=('positive','no_real_price_box_in_bin','real_price_box_without_positive_square_support')
    atom_mass={key:F(0) for key in status}
    active={}
    square_mother=defaultdict(dict)
    normalized_mother=defaultdict(dict)
    counters={key:0 for key in status}
    frozen_z=tuple(map(F,w['points']['z']['price_point']))
    # The original subbox is a witness in the selected family, not the
    # definition of its complete positive price support.
    frozen_graph,_,_,_=triples.same_z_edges(stage,config,M,D,frozen_box,model,old)
    a1,a2=[(u,r,tuple(v)) for u,r,v in w['encoded_rights']]
    x1,x2=map(tuple,w['encoded_lefts'])
    assert [frozen_graph[x][a] for x,a in product((x1,x2),(a1,a2))]==[F(v) for v in w['true_corner_h']]
    for id,Z,weight,tm,has_price_box in candidates:
        geom[id]=Z,weight,tm
        if not has_price_box:
            counters['no_real_price_box_in_bin']+=1
            atom_mass['no_real_price_box_in_bin']+=weight
            continue
        H,Ht,lx,ra=triples.same_z_edges(stage,config,M,D,Z,model,old)
        if not H:
            counters['real_price_box_without_positive_square_support']+=1
            atom_mass['real_price_box_without_positive_square_support']+=weight
            continue
        raw,norm,nedges=edges_by_owner(H,Ht,lx,ra)
        assert raw and norm and set(raw)==set(norm)
        for (W,t,u),v in raw.items():
            assert t in tm
            square_mother[id,W][t,u]=weight*v
            normalized_mother[id,W][t,u]=weight*norm[W,t,u]
        active[id]=dict(true_mu=weight,representative_Z=Z,physical_middle_membership=tm,
                        first_encoded_edges=nedges,raw_true_four_edges_mass_on_atom=weight*total(raw.values()),
                        normalized_per_root_mass_on_atom=weight*total(norm.values()))
        atom_mass['positive']+=weight
        counters['positive']+=1
    G=[old.box(v['G']) for v in U]
    mG=list(map(mu,G))
    ratio=[[mu(model.clip(A,B))/mG[i] for B in G] for i,A in enumerate(G)]
    assert all(0<=r<=1 for row in ratio for r in row)
    W_boxes={(g,k):E for g,obj in enumerate(U) for k,E in enumerate(model.two_halves(old.box(obj['owner'])))}
    W_area={W:model.volume(E) for W,E in W_boxes.items()}
    compare={name:compare_reuse(ledger,geom,W_area,ratio) for name,ledger in
             [('raw_actual_four_corner_product',square_mother),('normalized_by_own_actual_c_h',normalized_mother)]}
    _,_,_,_,_,m_bin,d_bin,*_=config
    expected=total(F(r['retained_true_flux']) for r in stage['by_t_u'] if m_bin[r['t']]==M and d_bin[r['u']]==D)
    assert compare['normalized_by_own_actual_c_h']['mother']==expected and frozen_atom in active
    assert len(candidates)==sum(counters.values())
    anchor_scale=mu(frozen_box)/active[frozen_atom]['true_mu']
    assert 0<anchor_scale<=1
    return dict(stage=stage['stage'],dimension=stage['n'],M=M,D=D,fixed_first_direction=0,
        all_price_atom_counts=counters,true_mu_by_price_status=atom_mass,active_true_price_atoms=active,
        actual_G_pocket_overlap_over_own_mu=ratio,previous_frozen_z_inside_same_family_check=True,
        previous_frozen_point=frozen_z,previous_frozen_z_only_mu=mu(frozen_box),
        previous_frozen_atom_id=frozen_atom,previous_frozen_box_fraction_of_all_positive_price_mu=mu(frozen_box)/atom_mass['positive'],
        previous_frozen_box_raw_four_corner_mass=anchor_scale*active[frozen_atom]['raw_true_four_edges_mass_on_atom'],
        previous_frozen_box_per_root_mass=anchor_scale*active[frozen_atom]['normalized_per_root_mass_on_atom'],
        original_retained_first_edge_mass_independent_check=expected,
        actual_receiving_halfboxes=[dict(W=k,physical_box=E,actual_volume=W_area[k]) for k,E in sorted(W_boxes.items())],
        calculations=compare)


def main():
    here=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    for v in ('805','806','807'):
        p.add_argument(f'--r{v}-dir',type=Path,default=here)
    group=p.add_mutually_exclusive_group()
    group.add_argument('--output',type=Path)
    group.add_argument('--check',type=Path)
    args=p.parse_args()
    sys.set_int_max_str_digits(0)
    paths={v:getattr(args,f'r{v}_dir').resolve() for v in ('805','806','807')}
    for name,sha in DEPENDENCIES.items():
        if name!='reverse805.json':
            v=next(v for v in paths if v in name)
            assert sha256((paths[v]/name).read_bytes()).hexdigest()==sha
    sys.path[:0]=list(map(str,paths.values()))
    import reverse805 as model
    import shared805 as old
    import triples806 as triples
    r5=paths['805']/'reverse805.json'
    fixture=r5.read_bytes() if r5.is_file() else subprocess.check_output([sys.executable,'-B',str(r5.with_suffix('.py'))])
    assert sha256(fixture).hexdigest()==DEPENDENCIES['reverse805.json']
    previous=json.loads((paths['807']/'ranks807.json').read_text())['stages']
    stages=[]
    for s,w in zip(json.loads(fixture)['stages'],previous,strict=True):
        assert s['stage']==w['stage']
        stages.append(example(s,w,model,old,triples))
    out=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='Fraction exact'),
        reproduction='python -B reuse809.py --check reuse809.json',dependencies=DEPENDENCIES,stages=stages,
        scope=dict(coverage='Take all genuine positive z membership cells in the frozen R807 bins, rather than restricting to the original anchor price box. Membership includes all actual middle parents of the same bin, so every re-hit test is exact on complete actual cells.',
            raw_law='For first direction zero, integrate the actual complete positive four-edge product h*c_h. Original q and W are integrated on their real reference boxes. The other left arm retains both original directions. The second law divides by each specified original edge own strictly positive genuine closure c_h, yielding the original first-edge marginal.',
            repeat='Use the actual single-root W marginal, then resample two independent complete roots conditional on that same continuous W in its true uniform receiving half. Different physical owner halves are disjoint up to null boundaries. Opposite q and both old price values are not fixed. Diagonal means the same actual old-price membership cell, not equality of two continuous price points.',
            collision='Separately give the unnormalized overlap of the two Lebesgue W densities. Their same-half product divides by the actual half volume. It is distinct from the genuine shared W conditional pair law, which divides by that half original mother mass. Both diagonal and cross are independently checked by price pairs and W sectors.',
            full='Actual 1/2/3-dimensional physical cubes and frozen genuine path masks, with no added high-dimensional terminal assumptions. Exact table hash seals (z,zprime,shared,hit,G,collision,independent,independent_hit,independent_G).'))
    text=json.dumps(out,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for s in stages:
            for law,v in s['calculations'].items():
                print(s['stage'],law,s['all_price_atom_counts']['positive'],len(v['W_actual_sector_rows']),
                     'diag',format(float(v['actual_shared_W_same_price_cell_probability']),'.8g'),
                     format(float(v['actual_independent_W_same_price_cell_probability']),'.8g'),
                     'hit',format(float(v['actual_shared_W_z2_in_original_t1_probability']),'.8g'),
                     format(float(v['independent_W_z2_in_original_t1_probability']),'.8g'),
                     'G',format(float(v['actual_shared_W_overlap_G_two_given_first_mass_probability']),'.8g'),
                     format(float(v['independent_W_overlap_G_two_given_first_mass_probability']),'.8g'))
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
