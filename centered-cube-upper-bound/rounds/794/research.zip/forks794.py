"""R794: geometric-mean fork overlap and two genuine micro-scale shadow checks."""

import argparse
from fractions import Fraction as F
from itertools import combinations, product
import json
from math import isqrt
from pathlib import Path
import platform
import sys

import flint
from flint import arb, ctx, fmpq


ctx.prec=256
C={"forward":F(1,4),"inverse":F(1,8)}


def ar(x):
    q=F(x)
    return arb(fmpq(q.numerator,q.denominator))


def prod(xs):
    q=F(1)
    for x in xs:
        q*=x
    return q


def sides(T,x,z,s,tau,mode):
    assert abs(x-T)<=s and abs(z-T)<=s
    assert all(0<=b<1 for b in tau)
    beta=tuple(v/(1-v) for v in tau)
    if mode=="forward":
        c1,c2=T+tau[0]*(x-T),T+tau[1]*(z-T)
        r1,r2=s*(1-tau[0]),s*(1-tau[1])
    else:
        c1,c2=T-beta[0]*(x-T),T-beta[1]*(z-T)
        r1,r2=s*(1+beta[0]),s*(1+beta[1])
    a,b=(c1-r1,c1+r1),(c2-r2,c2+r2)
    overlap=max(F(0),min(a[1],b[1])-max(a[0],b[0]))
    shift=abs(c1-c2)
    radial=abs(r1-r2)
    gap=max(radial,shift)
    closed=max(F(0),r1+r2-gap)
    assert overlap==closed
    assert 2*max(r1,r2)>=r1+r2
    D=min(tau)*abs(x-z)/s
    assert gap/(r1+r2)>=C[mode]*D
    if mode=="forward":
        assert all(T-s<=lo<=hi<=T+s for lo,hi in (a,b))
    else:
        assert all(lo<=T-s<T+s<=hi for lo,hi in (a,b))
    geometric_squared=overlap**2/(4*r1*r2)
    if geometric_squared:
        # At containment this is the atanh bound; as gap increases its derivative
        # is at least 1/(r1+r2). Check its directed numerical consequence also.
        if gap:
            assert ar(geometric_squared).log()/2 < -ar(gap/(r1+r2))
        else:
            assert geometric_squared==1 and D==0
    return dict(intervals=[a,b],radii=[r1,r2],centers=[c1,c2],
                true_overlap_length=overlap,computed_from_max_gap=closed,
                actual_center_distance=shift,actual_radius_difference=radial,largest_gap=gap,
                squared_geometric_mean_ratio=geometric_squared,
                normalized_by_sum_half_radii=overlap/(r1+r2),
                normalized_by_larger_interval=overlap/(2*max(r1,r2)),
                normalized_by_smaller_interval=overlap/(2*min(r1,r2)),
                exponent_demand=D,exact_gap_over_radius_sum=gap/(r1+r2))


def sample(name,mode,s,T,a,b,tau):
    x,z=[u+s*v for u,v in zip(T,a)],[u+s*v for u,v in zip(T,b)]
    q=[sides(u,v,w,s,tau,mode) for u,v,w in zip(T,x,z)]
    length=prod(c["true_overlap_length"] for c in q)
    geom=prod(c["squared_geometric_mean_ratio"] for c in q)
    alt=prod(c["normalized_by_sum_half_radii"] for c in q)
    larger=prod(c["normalized_by_larger_interval"] for c in q)
    smaller=prod(c["normalized_by_smaller_interval"] for c in q)
    r=q[0]["radii"]
    assert geom==length**2 / ((4*r[0]*r[1])**len(q))
    assert larger**2<=alt**2<=geom<=smaller**2<=1
    D=sum(o["exponent_demand"] for o in q)
    if geom==1:
        assert not D
    log=None if not geom else ar(geom).log()/2
    if geom and geom!=1:
        assert log < -ar(C[mode]*D)
    return dict(name=name,mode=mode,n=len(q),same_T=T,true_prices_x_z=[x,z],s=s,tau=tau,
                inverse_beta=[a/(1-a) for a in tau],
                independent_axis_interval_and_max_checks=q,
                actual_overlap_volume=length,
                squared_geometric_mean_normalized_intersection=geom,
                ratios_by_sum_radii_larger_smaller_denoms=[alt,larger,smaller],
                min_tau_times_L1_price_distance_over_s=D,
                constant_used=C[mode],certified_log_geom_ratio_Arb=log,
                requested_log_upper=-C[mode]*D)


def all_signs():
    pts=[F(-1),F(-1,2),F(0),F(1,2),F(1)]
    tau=[F(0),F(1,8),F(1,4),F(1,3),F(1,2),F(3,4),F(7,8)]
    T,s=F(5,13),F(11,7)
    output={}
    for mode in C:
        counts={"tested_axes":0,"radial_dominates":0,"center_dominates":0,
                "ties":0,"center_cancellation_with_separate_prices":0,"zero_overlap":0,
                "equal_tau_axes":0}
        signs=set()
        for a,b,t,u in product(pts,pts,tau,tau):
            shape=sides(T,T+s*a,T+s*b,s,(t,u),mode)
            counts["tested_axes"]+=1
            r,c=shape["actual_radius_difference"],shape["actual_center_distance"]
            counts["radial_dominates"]+=int(r>c)
            counts["center_dominates"]+=int(c>r)
            counts["ties"]+=int(c==r)
            counts["zero_overlap"]+=int(shape["true_overlap_length"]==0)
            counts["equal_tau_axes"]+=int(t==u)
            counts["center_cancellation_with_separate_prices"]+=int(c==0 and a!=b and min(t,u)>0)
            signs.add(((a>0)-(a<0),(b>0)-(b<0)))
        assert len(signs)==9 and all(counts[k]>0 for k in counts if k!="zero_overlap")
        assert bool(counts["zero_overlap"])==(mode=="forward")
        output[mode]=dict(counts=counts,sign_patterns=sorted(signs))
    T=(F(1,7),F(-2,9),F(1,8),F(4,7))
    t=(F(1,4),F(1,2))
    diag=(
        sample("exact_forward_center_cancellation","forward",F(9,8),T,
               (F(1),F(-1),F(1,2),F(-1,2)),(F(1,2),F(-1,2),F(1,4),F(-1,4)),t),
        sample("exact_inverse_center_cancellation","inverse",F(9,8),T,
               (F(1),F(-1),F(1,2),F(-1,2)),(F(1,3),F(-1,3),F(1,6),F(-1,6)),t))
    for item in diag:
        assert item["squared_geometric_mean_normalized_intersection"]==F(2,3)**4
        assert all(x["actual_center_distance"]==0<x["actual_radius_difference"]
                   for x in item["independent_axis_interval_and_max_checks"])
        assert item["ratios_by_sum_radii_larger_smaller_denoms"][2]==1
        assert item["min_tau_times_L1_price_distance_over_s"]>0
    return dict(all_rational_two_sign_axis_enumerations=output,exact_cancellations=diag)


def extreme():
    T=(F(13,7),F(-4,13),F(0))
    s=F(17,11)
    return [
        sample("forward_nonempty_equal_radii_near_opposite_faces","forward",s,T,
               (F(1),F(-1),F(127,128)),(F(-1),F(1),F(-127,128)),(F(127,256),)*2),
        sample("forward_disjoint_despite_common_ancestor","forward",s,T,
               (F(1),F(-1),F(1,8)),(F(-1),F(1),F(-1,8)),(F(255,256),F(3,4))),
        sample("inverse_unequally_extreme_radii_near_opposite_faces","inverse",s,T,
               (F(-1),F(1),F(0)),(F(1),F(-1),F(1,4)),(F(1023,1024),F(255,256))),
        sample("inverse_fixed_radius_and_opposite_signs","inverse",s,T,
               (F(-1),F(1),F(1)),(F(1),F(-1),F(1)),(F(63,64),)*2)]


def growing(n):
    a,b=1-F(1,n),1-F(2,n)
    tau=F(1,4),F(1,4)*(1+F(1,n))
    result={}
    for mode in C:
        axis=sides(F(0),a,b,F(1),tau,mode)
        assert axis["actual_center_distance"]<axis["actual_radius_difference"]
        q=axis["squared_geometric_mean_ratio"]
        assert 0<q<1
        log=ar(q).log()*n/2
        required=-C[mode]*axis["exponent_demand"]*n
        assert log < ar(required)
        free=-n*axis["actual_center_distance"]/sum(axis["radii"])
        assert log < ar(free)
        result[mode]=dict(one_exact_axis=axis,certified_joint_log_geometric_mean_ratio_Arb=log,
                          requested_upper_log=required,
                          log_of_center_only_bound_arithmetic_denominator=free)
    return dict(n=n,same_direction_offsets=[a,b],exact_tau=tau,comparison_by_direction=result)


def micro(n):
    root=isqrt(n)
    assert root*root==n
    exponent=arb(2).log()/root
    rho=(-exponent).exp()
    h=1+F(1,32*n)
    s0=ar(F(7,4))
    s1,s2=s0*rho,s0*rho*rho
    eps=[s/ar(32*n+1) for s in (s0,s1,s2)]
    physical=[s/ar(h) for s in (s0,s1,s2)]
    assert all(1<r<2 for r in physical)
    x=(s0,arb(0))
    T1=((1-rho)*s0,arb(0))
    z=(T1[0]+s1,s1/3)
    T2=(T1[0]+(1-rho)*(z[0]-T1[0]),(1-rho)*(z[1]-T1[1]))
    c1,c2=(T1[0]+eps[1],T1[1]),(T2[0]+eps[2],T2[1])
    assert x[1]!=z[1] and z[1]>0 and x[0].overlaps(z[0])
    assert z[1]<physical[1] and z[0].overlaps(c1[0]+physical[1])
    assert x[0].overlaps(eps[0]+physical[0])
    assert T1[0].overlaps(s0-s1)
    assert T2[0].overlaps(s0-s2)
    assert T2[1]<T2[0]
    assert c1[0]-eps[0]>eps[0]+eps[1]
    assert c2[0]-c1[0]>eps[1]+eps[2]
    span=(n*(s0/s1).log()/arb(2).log(),n*(s1/s2).log()/arb(2).log())
    assert all(q.contains(root) for q in span)
    shadow=s0-s2+eps[2]
    assert c2[0].overlaps(shadow) and c2[0]>c2[1]
    return dict(n=n,exact_block_width_each_in_log2_volume=int(root),
                both_log2_volume_widths_Arb=span,actual_rho_Arb=rho,
                physical_ancestor_and_descendant_radii_Arb=physical,
                true_first_two_price_coordinates_Arb=[x,z],
                true_contracted_probe_coordinates_Arb=[T1,T2],
                terminal_actual_center_Arb=c2,actual_owner_probe_error_Arb=eps[2],
                ancestor_shadow_radius_Arb=shadow,sqrt_n_times_shadow_over_s0_Arb=shadow*root/s0)


def shared_terminal():
    # Three genuine terminal receivers reached with different second anchor
    # prices. A single positive-volume source measure (or its centre point)
    # observes every terminal parent at once.
    n=4
    a=32*n
    s0,s1,s2=F(7,4),F(3,2),F(6,5)
    eps=s2/(a+1)
    r=s2*a/(a+1)
    T1=(s0-s1,F(0),F(0),F(0))
    c1=(T1[0]+s1/(a+1),)+T1[1:]
    z=[(s0,y,F(0),F(0)) for y in (F(-1,2),F(0),F(1,2))]
    assert all(max(abs(y-k) for y,k in zip(anchor,c1))<=s1*a/(a+1) for anchor in z)
    probes=[tuple(F(4,5)*t+F(1,5)*q for t,q in zip(T1,anchor)) for anchor in z]
    c=[(p[0]+eps,)+p[1:] for p in probes]
    assert all(max(abs(u-v) for u,v in zip(x,y))>2*eps for x,y in combinations(c,2))
    price=(F(1,2),F(0),F(0),F(0))
    box_s=F(1,8)
    assert all(max(abs(q-y) for q,y in zip(price,j))+box_s<r for j in c)
    return dict(n=n,source_point_in_every_terminal_parent=price,
                true_second_anchor_choices=z,true_terminal_probes=probes,
                real_parent_centres=c,terminal_parent_radius=r,
                terminal_owner_half_side=eps,
                one_source_probability_cube_radius=box_s,actual_Leb_volume=(2*box_s)**n,
                one_probability_mass_and_each_of_three_true_parent_hit_probabilities=[1,[1,1,1]])


def main():
    p=argparse.ArgumentParser(description=__doc__)
    out=p.add_mutually_exclusive_group()
    out.add_argument("--output",type=Path)
    out.add_argument("--check",type=Path)
    args=p.parse_args()
    data=dict(
        arithmetic="Exact rational geometry and 256-bit Arb directed logarithmic checks",
        python={"executable":sys.executable,"version":platform.python_version(),
                "architecture":platform.machine(),"python_flint":flint.__version__},
        command="python -B forks794.py --check forks794.json",
        scope=("Forward boxes are centered at T+tau*(x-T) with radius (1-tau)s. "
               "The inverse uses T-beta*(x-T), radius (1+beta)s. Both prices belong to "
               "the same original Q(T,s); beta=tau/(1-tau). The main ratio is the "
               "intersection over the geometric mean of the two volumes. The large "
               "examples are scalar tensor tests and two separate rational/interval "
               "motions; these are geometric interface checks."),
        initial_exact_axes_and_products=all_signs(),extreme_and_equal_radii=extreme(),
        increasing_n_same_direction_scalar_tests=[growing(2**k) for k in (6,20,40)],
        two_consecutive_sqrt_n_width_blocks=[micro(n) for n in (64,65536)],
        one_source_point_or_probability_for_multiple_actual_terminal_parents=shared_terminal())
    text=(json.dumps(data,indent=2,sort_keys=True,default=str)+"\n").encode()
    if args.output:
        args.output.write_bytes(text)
    elif args.check:
        if args.check.read_bytes()!=text:
            raise SystemExit("certificate differs")
        print("forks794: exact one-axis forks, geometric-mean caps and two-block shadows agree")
    else:
        print(text.decode(),end="")


if __name__=="__main__":
    main()

