"""R793: a positive physical price/probe region that hits several volume frames."""

import argparse
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
import json
from pathlib import Path
import platform
import sys


Q_LO, Q_HI = F(1189207115,10**9), F(1189207116,10**9)
assert Q_LO**4 < 2 < Q_HI**4


@dataclass(frozen=True)
class Q4:
    """Exact arithmetic at the positive real q=2^(1/4); q^4=2."""
    a: tuple

    def __add__(self,y):
        return Q4(tuple(a+b for a,b in zip(self.a,y.a)))

    def __neg__(self):
        return Q4(tuple(-v for v in self.a))

    def __sub__(self,y):
        return self + -y

    def __mul__(self,y):
        values=[F(0)]*4
        for i,a in enumerate(self.a):
            if a:
                for j,b in enumerate(y.a):
                    if b:
                        values[(i+j)%4] += a*b*(2 if i+j>=4 else 1)
        return Q4(tuple(values))

    def __pow__(self,n):
        exact = rational(1)
        for _ in range(n):
            exact = exact*self
        return exact

    def scalar(self):
        assert all(v==0 for v in self.a[1:])
        return self.a[0]

    def bounds(self):
        lo=hi=F(0)
        for j,a in enumerate(self.a):
            u,v=a*Q_LO**j,a*Q_HI**j
            lo+=min(u,v)
            hi+=max(u,v)
        return lo,hi


def rational(x):
    return Q4((F(x),F(0),F(0),F(0)))


Q = Q4((F(0),F(1),F(0),F(0)))
ZERO=rational(0)


def floor_log2(x):
    u=x.numerator.bit_length()-x.denominator.bit_length()
    return u-(F(2)**u>x)


def total(values):
    return sum(values,F(0))


@dataclass(frozen=True)
class Frame:
    j: int
    s: F
    c: tuple
    m: F
    D: F
    t: Q4
    owner: F


def parent_family(n):
    a=32*n
    h=1+F(1,a)
    p0=(F(1,2),)+(F(0),)*(n-1)
    eps=F(1,4096*n)
    X=[(-eps,eps)]*n
    P=[(v-eps,v+eps) for v in p0]
    out=[]
    for j,s in enumerate((F(11,8),F(13,8),F(31,16))):
        m=(2*s)**n
        D=F(2)**floor_log2(m)
        power=4*(F(floor_log2(m)+1,n)-1)
        assert power.denominator==1 and power in (2,3,4)
        r=Q**int(power)
        assert ((r*rational(2))**n).scalar()==2*D
        t=r*rational(h)
        lo,hi=t.bounds()
        center=F(round(((lo+hi)/4)*2**20),2**20)
        c=(center,)+(F(0),)*(n-1)
        out.append(Frame(j,s,c,m,D,t,(2*s/a)**n))
    assert all(F(1)<=p.s<F(2) for p in out)
    assert all(out[i].D<out[i+1].D for i in range(2))
    assert all(abs(v.c[0]-u.c[0])>(u.s+v.s)/a for u,v in combinations(out,2))
    assert all(abs(v.c[0]-u.c[0]) + u.s < v.s for u,v in combinations(out,2))
    # A genuine smaller visible parent, with a disjoint center core.
    U_c,U_s=F(-1,2),F(1)
    assert all(abs(U_c-v.c[0])>(U_s+v.s)/a for v in out)
    assert all(abs(p[0])<1 and abs(p[1])<1 for p in P)
    return a,h,out,U_c,U_s,X,P,p0,eps


def product_range(a,b,c,d):
    pts=(a*c,a*d,b*c,b*d)
    return min(pts),max(pts)


def center_ranges(frame,X,P):
    tl,th=frame.t.bounds()
    result=[]
    for (xl,xh),(pl,ph) in zip(X,P):
        lo,hi=product_range(tl,th,pl,ph)
        result.append((xl+lo,xh+hi))
    return result


def prove_positive_region(n,a,h,frames,U_c,U_s,X,P):
    report=[]
    size_x=(X[0][1]-X[0][0])**n
    size_p=(P[0][1]-P[0][0])**n
    assert size_x*size_p>0
    for f in frames:
        ranges=center_ranges(f,X,P)
        hi=f.t.bounds()[1]
        shift=max(max(abs(lo-y),abs(up-y)) for (lo,up),y in zip(ranges,f.c))
        assert shift < f.s/a
        assert all(y-f.s<x<z<y+f.s for (x,z),y in zip(X,f.c))
        assert U_c-U_s<X[0][0]<X[0][1]<U_c+U_s
        assert all(-U_s<x<z<U_s for x,z in X[1:])
        assert all(abs(y)+f.s<4 for y in f.c)
        assert all(max(abs(lo),abs(up))+hi<4 for lo,up in ranges)
        # Each actual realized present receiver contains A_f in its predicted box.
        assert f.t.bounds()[0] > h*f.s
        # A true visible first price can be drawn from this literal intersection.
        left_first=min(U_c+U_s,f.c[0]+f.s)-max(U_c-U_s,f.c[0]-f.s)
        left_overlap=left_first*(2*U_s)**(n-1)
        assert 0<size_x<left_overlap<=F(3,4)*(2*U_s)**n
        # x ~ mu|A_small cap A_f / true intersection; W ~ Leb|E_f / |E_f|.
        # p=(W-x)/t_f and t_f^n is exactly rational at a standard dyadic upper edge.
        path_tube_mass=size_x/left_overlap*size_p*(f.t**n).scalar()/f.owner
        assert 0<path_tube_mass<1
        report.append(dict(j=f.j, displacement_sup_on_tube=shift,
                           true_owner_half_side=f.s/a, true_first_price_denominator=left_overlap,
                           true_receiver_denominator=f.owner,
                           positive_joint_probability_of_shared_x_p_tube=path_tube_mass))
    for j,i in combinations(range(len(frames)),2):
        old,now=frames[j],frames[i]
        for (lo,hi),c in zip(center_ranges(old,X,P),now.c):
            assert max(abs(lo-c),abs(hi-c))+old.t.bounds()[1] < now.s
    return size_x,size_p,report


def per_axis_cells(frame, previous, x, p, axis):
    # The old predictor boxes are nested for |p|<1. Place their exact physical
    # boundaries on this coordinate; do not reuse their theoretical volumes.
    bounds=[rational(frame.c[axis]-frame.s)]
    for old in reversed(previous):
        bounds.append(rational(x)+old.t*rational(p-1))
    for old in previous:
        bounds.append(rational(x)+old.t*rational(p+1))
    bounds.append(rational(frame.c[axis]+frame.s))
    k=len(previous)
    output=[]
    for j,(a,b) in enumerate(zip(bounds,bounds[1:])):
        width=b-a
        assert width.bounds()[0]>0
        mask=sum(1<<i for i in range(k) if k-i<=j<k+i+1)
        output.append((mask,width))
    return output


def direct_membership(frame, previous, x, p, explicit):
    axes=[per_axis_cells(frame,previous,a,b,k) for k,(a,b) in enumerate(zip(x,p))]
    full=(1<<len(previous))-1
    mass={full:rational(1)}
    for axis in axes:
        out={}
        for (old,w),(coordinate,length) in product(mass.items(),axis):
            type_mask=old&coordinate
            out[type_mask]=out.get(type_mask,ZERO)+w*length
        mass=out
    if explicit:
        # An additional explicit product enumeration in n=4.
        path={}
        for pieces in product(*axes):
            mask=full
            w=rational(1)
            for m,size in pieces:
                mask&=m
                w=w*size
            path[mask]=path.get(mask,ZERO)+w
        assert path==mass
    by_first={}
    for mask,val in mass.items():
        # All physical price choices with no return go into the new-price piece.
        j=next((k for k in range(len(previous)) if mask&(1<<k)),-1)
        by_first[j]=by_first.get(j,F(0))+val.scalar()
    assert total(by_first.values())==frame.m
    return by_first


def probability_test(n,h,frames,p0,eps,tube):
    x0=(F(0),)*n
    directions=tuple(F(1) if j%2 else F(-1) for j in range(n))
    probes=[(tuple(sign*eps*v/2 for v in directions),
             tuple(y-sign*eps*v/3 for y,v in zip(p0,directions))) for sign in (0,1,-1)]
    data=[]
    for i, current in enumerate(frames):
        prev=frames[:i]
        old_expanded=F(0)
        entries={}
        for j, earlier in enumerate(prev):
            box_size=2*h**n*earlier.D
            entries[j]=box_size-old_expanded
            old_expanded=box_size
        entries[-1]=current.m-old_expanded
        assert all(w>0 for w in entries.values())
        for x,p in probes:
            assert all(abs(v)<1 for v in p)
            assert direct_membership(current,prev,x,p,explicit=n==4)==entries
        raw_old=frames[i-1].m if i else F(0)
        old_law=old_expanded/current.m
        new_law=1-old_law
        false_smaller=raw_old/current.m
        if i:
            assert 0<false_smaller<old_law<1
            assert 0<new_law<1
        prob_tube=tube[i]["positive_joint_probability_of_shared_x_p_tube"]
        data.append(dict(j=i,D=current.D, true_parent_m=current.m, true_s=current.s,
                         true_center_x0=current.c[0], t_bounds=current.t.bounds(),
                         actual_first_hit_source_volume=entries,
                         fixed_probe_pairs_checked=len(probes),
                         original_right_z_denominator=current.m,
                         conditional_old_and_new_price=[old_law,new_law],
                         compare_if_smaller_actual_parent_is_used_as_old=false_smaller,
                         wrongly_new_if_only_actual_smaller_parent_used=old_law-false_smaller,
                         positive_original_joint_tube_old_and_new=[prob_tube*old_law,prob_tube*new_law]))
    assert sum(bool(r["conditional_old_and_new_price"][0]) for r in data)==2
    return data


def prediction_density(n,h,frames,p0,entries):
    """One shared physical source reference; compare predicted and actual new layers."""
    origin=(F(0),)*n
    support=Frame(-1,F(4),origin,F(8)**n,F(1),rational(4),F(1))
    by_first=direct_membership(support,frames,origin,p0,explicit=n==4)
    predicted=[by_first[j] for j in range(3)]
    actual=[d["actual_first_hit_source_volume"][-1] for d in entries]
    assert all(0<a<b for a,b in zip(actual,predicted))
    assert total(predicted)+by_first[-1]==support.m
    G_pred = [F(1,3)/v for v in predicted]
    G_actual = [F(1,3)/v for v in actual]
    assert total(a*b for a,b in zip(G_pred,predicted))==1
    assert total(a*b for a,b in zip(G_actual,actual))==1
    gate_rows=[]
    L=F(1)
    N=n+2
    U=2*N
    for i,parent in enumerate(frames):
        # Compare the very same diagnostic M_i and the two separately normalized
        # densities built using the single true Lambda=mu on Q(0,4).
        M=F(3,2)*(predicted[i]+actual[i])
        assert L*parent.D<=M<=U*parent.D
        enumerated=direct_membership(parent,frames[:i],origin,p0,explicit=False)
        pn=[enumerated.get(j,0) if j<i else enumerated[-1] if j==i else F(0)
            for j in range(3)]
        an=[w if j<=i else F(0) for j,w in enumerate(actual)]
        assert sum(pn)==parent.m and total(an)<=parent.m
        assert pn==[predicted[j] if j<i else actual[j] if j==i else 0 for j in range(3)]
        pm=[v/parent.m for v in pn]
        am=[v/parent.m for v in an]
        pred_gate=[M*w>=1 for w in G_pred]
        actual_gate=[M*w>=1 for w in G_actual]
        hit_pred=total(v for v,ok in zip(pm,pred_gate) if ok)
        hit_actual=total(v for v,ok in zip(am,actual_gate) if ok)
        assert not pred_gate[i] and actual_gate[i] and hit_pred<hit_actual
        gate_rows.append(dict(
            current_true_parent_i=i,actual_D=parent.D,diagnostic_M=M,
            actual_right_price_Lebesgue_denominator=parent.m,
            conditional_probability_by_predicted_layer=pm,
            conditional_probability_by_actual_new_layer=am,
            missing_probability_outside_actual_new_layers=1-total(am),
            passes_MG_ge_1_using_predicted_layer=pred_gate,
            passes_MG_ge_1_using_actual_new_layer=actual_gate,
            original_right_price_conditional_E_G_predicted_and_actual=[
                total(a*b for a,b in zip(G_pred,pm)),total(a*b for a,b in zip(G_actual,am))],
            conditional_gate_probability_using_predicted_and_actual=[hit_pred,hit_actual],
            old_gate_and_first_new_gate_using_predicted_and_actual=[
                [total(pm[j] for j in range(i) if pred_gate[j]),pm[i] if pred_gate[i] else 0],
                [total(am[j] for j in range(i) if actual_gate[j]),am[i] if actual_gate[i] else 0]],
            conditional_fee_E_1_gate_over_M_using_predicted_and_actual=[hit_pred/M,hit_actual/M]))
    return dict(
        raw_common_reference_mass=support.m,
        total_weight_for_predicted_and_actual_layers=[F(1),F(1)],
        true_predicted_frame_layers_Lambda_volumes=predicted,
        true_parent_new_layers_Lambda_volumes=actual,
        constant_score_on_predicted_layers=G_pred,
        constant_score_on_actual_new_layers=G_actual,
        original_right_price_actual_parent_checks=gate_rows,
        diagnostic_caps_L_U=[L,U])


def ceil_log2(q):
    lo=floor_log2(q)
    return lo if F(2)**lo==q else lo+1


def log_bounds_near_one(x):
    """Return exact bounds for log x for x in [1,2]."""
    assert 1<=x<=2
    a=(x-1)/(x+1)
    square=a*a
    current=a
    lo=F(0)
    for i in range(40):
        lo+=2*current/(2*i+1)
        current*=square
    hi=lo+2*current/(81*(1-square))
    return lo,hi


def log_bounds(x):
    k=floor_log2(x)
    assert k>=0
    l0,l1=log_bounds_near_one(F(2))
    a,b=log_bounds_near_one(x/F(2)**k)
    return k*l0+a,k*l1+b


def exact_gate_optimum(L,U,G):
    threshold=1/G
    first=ceil_log2(threshold/U)
    tail=max(first,ceil_log2(threshold/L))
    plateau=tail-first
    D0=F(2)**first
    Dt=F(2)**tail
    bounded_sum=plateau*G+2/(L*Dt)
    assert U*D0>=threshold and U*D0/2<threshold
    assert L*Dt>=threshold
    # Independent per-bucket optimization, including inactive predecessors,
    # and then the exact remaining geometric tail after these visited buckets.
    visit=list(range(first-3,tail+20))
    explicit=F(0)
    three=[0,0,0]
    last=None
    for d in visit:
        D=F(2)**d
        chosen=max(L*D,threshold)
        if chosen>U*D:
            three[0]+=1
            assert d<first
        else:
            explicit+=1/chosen
            if chosen>L*D:
                three[1]+=1
                assert first<=d<tail and chosen==threshold
            else:
                three[2]+=1
                assert d>=tail
            last=1/chosen
    assert three==[3,plateau,20] and last is not None
    assert explicit+last==bounded_sum
    a=L*G*D0
    j=max(0,ceil_log2(1/a))
    assert bounded_sum/G==j+2/(a*F(2)**j)
    ratio=U/L
    l0,l1=log_bounds(ratio)
    q0,q1=log_bounds_near_one(F(2))
    # Directed lower bound for the proposed upper coefficient.
    if F(2)**floor_log2(ratio)==ratio:
        assert bounded_sum/G<=2+floor_log2(ratio)
    else:
        assert bounded_sum/G<2+l0/q1
    assert l0<=l1 and q0<q1
    return dict(G=G,first_active_exponent=first,first_lower_cap_exponent=tail,
                maximum_per_bin_fee_sum=bounded_sum,
                exact_best_sum_over_G=bounded_sum/G,
                first_active_lower_and_upper_M=[L*D0,U*D0],
                first_M_that_can_pass_gate_at_D_1=max(L,threshold),
                M_can_pass_at_D_1=max(L,threshold)<=U,
                independently_enumerated_inactive_plateau_tail_buckets=three)


def large_scale(n):
    from math import isqrt
    N=n+2
    k=isqrt(n)
    assert k*k==n
    log_lower,log_upper=log_bounds(F(N))
    a=k*log_lower**3
    b=k*log_upper**3
    # Exact adjacent integers enclosing the true sqrt(n)*log^3(n+2).
    lower=a.numerator//a.denominator
    assert lower<a<=b<lower+1
    L=F(lower+1)
    U=F(2*N)
    assert U>L
    eps=F(1,1024)
    attained={
        "D_1_gate_exact_at_upper":exact_gate_optimum(L,U,1/U),
        "D_1_gate_just_above_upper":exact_gate_optimum(L,U,(1-eps)/U),
        "D_1_gate_exact_at_lower":exact_gate_optimum(L,U,1/L),
        "D_1_gate_just_above_lower":exact_gate_optimum(L,U,(1-eps)/L)}
    upper_phase=attained["D_1_gate_exact_at_upper"]["exact_best_sum_over_G"]
    assert all(row["exact_best_sum_over_G"]<=upper_phase for row in attained.values())
    return dict(n=n,diagnostic_C0=1,N=N,true_L_between_adjacent_integers=[lower,lower+1],
                chosen_exact_L=L,actual_upper_coefficient=U,upper_over_lower=U/L,
                independent_three_region_checks=attained)


def case(n):
    a,h,frames,U_c,U_s,X,P,p0,eps=parent_family(n)
    sx,sp,tube=prove_positive_region(n,a,h,frames,U_c,U_s,X,P)
    comparison=probability_test(n,h,frames,p0,eps,tube)
    P0=total(f.owner for f in frames)
    draw=tuple(f.owner/P0 for f in frames)
    mix_old=total(draw[i]*c["positive_original_joint_tube_old_and_new"][0] for i,c in enumerate(comparison))
    mix_new=total(draw[i]*c["positive_original_joint_tube_old_and_new"][1] for i,c in enumerate(comparison))
    assert 0<mix_old and 0<mix_new
    return dict(n=n,shrink_denominator=a,h=h,visible_left_small_center_radius=[U_c,U_s],
                true_occupied_center_count=len(frames),x_box=X,p_box=P,
                explicit_positive_tube_measure=sx*sp, tube_left_and_owner_margins=tube,
                actual_price_exit_and_entrance=comparison,
                normalized_three_layer_price_density=prediction_density(n,h,frames,p0,comparison),
                same_explicit_owner_weight_mixture_current_probabilities=draw,
                mixture_old_and_new_joint_mass_on_tube=[mix_old,mix_new])


def main():
    p=argparse.ArgumentParser(description=__doc__)
    out=p.add_mutually_exclusive_group()
    out.add_argument("--output",type=Path)
    out.add_argument("--check",type=Path)
    args=p.parse_args()
    data=dict(
        python={"executable":sys.executable,"version":platform.python_version(),
                "architecture":platform.machine()},
        arithmetic="Exact rational operations in Q(2^(1/4)); ordered roots rigorously bracketed by two rational fourth powers",
        command="python -B frames793.py --check frames793.json",
        model=("Lebesgue on the compact support Q(0,4). Each true parent lies inside it "
               "and has mu(A_i)=(2s_i)^n. All center cores E_i are disjoint and stay in "
               "the same physical radius octave [1,2). These are the equality geometry "
               "and the actual first-price and receiver normalizations; no full peak gate "
               "is imposed. Given the current parent, the first price is uniform on its "
               "true intersection with the smaller visible parent and the last price is "
               "independently uniform on the current A_i. For every x,p in a positive "
               "tube, T_d=x+hr_D p lies in the actual E_i at all three true dyadic end radii. "
               "An old later price means it is covered by an occupied smaller predicted "
               "cube Q(T_d,hr_D)."),
        certified_fourth_root_bounds=(Q_LO,Q_HI),
        diagnostic_linear_charge=(
            "Maximum over one unit of weight per exact dyadic bucket D. Allowed M is in [L D,U D], "
            "U=2 C0 N. With the gate M G>=1 the optimizer takes M=max(L D,1/G) only if <=U D. "
            "The exact three-region sum implies (2+log2(U/L)) G. L in the large probes is a "
            "certified rounded value, C0=1 is diagnostic."),
        linear_charge_large_scale=[large_scale(2**power) for power in (24,36,60)],
        literal_1_plus_log_without_constant_boundary=exact_gate_optimum(F(1),F(1),F(1)),
        cases=[case(n) for n in (4,8,16)])
    text=(json.dumps(data,sort_keys=True,indent=2,default=str)+"\n").encode()
    if args.output:
        args.output.write_bytes(text)
    elif args.check:
        if args.check.read_bytes()!=text:
            raise SystemExit("certificate differs")
        print("frames793: true shared probes, predicted old prices and first entrances agree")
    else:
        print(text.decode(),end="")


if __name__=="__main__":
    main()

