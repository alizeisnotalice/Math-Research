"""R794: exact descending rank columns and separately certified two-price motion."""

import argparse
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
import platform
import sys


joint = None
frames = None


def R(x):
    return frames.rational(x)


def qsum(seq):
    return sum(seq,R(0))


def qsort(seq):
    return sorted(seq,key=lambda z:joint.qbounds(z)[0])


def qmin(seq):
    return min(seq,key=lambda z:joint.qbounds(z)[0])


def qmax(seq):
    return max(seq,key=lambda z:joint.qbounds(z)[0])


def interval_intersection(*ranges):
    left=qmax(a for a,b in ranges)
    right=qmin(b for a,b in ranges)
    if joint.less(left,right):
        return left,right
    return None


def length(interval):
    return interval[1]-interval[0] if interval else R(0)


def moved(interval,delta):
    return interval[0]+delta,interval[1]+delta


def subset(inside,outside):
    return (joint.equal_or_larger(inside[0],outside[0]) and
            joint.equal_or_larger(outside[1],inside[1]))


def ranks(fiber,params,chosen_middle_history,tick):
    grouped=[]
    fine=[]
    start=R(0)
    uses=[R(0)]*3
    for d in range(3):
        original_start=start
        invW=R(1/params[d]["W"])
        for key,m in sorted(fiber.items()):
            _,history=key
            h=chosen_middle_history if d==1 else 0
            if tick<history[d][h]:
                end=start+m*invW
                fine.append((d,key,(start,end)))
                start=end
                uses[d]+=m
        assert joint.less(original_start,start)
        grouped.append((original_start,start))
        assert length(grouped[d])==uses[d]*invW
    assert qsum(uses[d]*R(1/params[d]["W"]) for d in range(3))==start
    return grouped,fine,uses


def one_generation(groups, fine, delta):
    # Exact coarse interval intersections; keep all accepted paths including
    # those completing only part of a bin, without wrapping.
    true=[[length(interval_intersection(start,moved(end,delta))) for end in groups]
          for start in groups]
    coarse_by_fine=[[R(0)]*3 for _ in range(3)]
    cols=[]
    arbitrary=[]
    for dest,_,column in fine:
        enters=[]
        from_subflow=[]
        for k,(source,key,origin) in enumerate(fine):
            takes=interval_intersection(origin,moved(column,delta))
            if takes is None:
                continue
            coarse_by_fine[source][dest]+=length(takes)
            image=moved(takes,-delta)
            assert subset(image,column)
            enters.append(image)
            # As a concrete partial subflow, vary a physical cell's density
            # and keep only an interior source rank subinterval.
            a,b=origin
            local=length(origin)*R(F(1,4))
            part=interval_intersection(takes,(a+local,b-local))
            from_subflow.append(length(part)*R(F(1+(k%3),4)))
        ranges=sorted(enters,key=lambda ab:joint.qbounds(ab[0])[0])
        # Disjoint clipped images imply the bound for every density <=1,
        # not only for the recorded partial subflow.
        assert all(joint.equal_or_larger(b[0],a[1]) for a,b in zip(ranges,ranges[1:]))
        c=qsum(length(ab) for ab in ranges)
        test=qsum(from_subflow)
        assert joint.equal_or_larger(length(column),c)
        assert joint.equal_or_larger(c,test)
        cols.append(c)
        arbitrary.append(test)
    assert coarse_by_fine==true
    assert all(true[i][j]==R(0) for i,j in product(range(3),repeat=2) if j>i)
    column_totals=[qsum(row[j] for row in true) for j in range(3)]
    row_totals=[qsum(row) for row in true]
    assert all(joint.equal_or_larger(length(I),v) for I,v in zip(groups,column_totals))
    assert all(joint.equal_or_larger(length(I),v) for I,v in zip(groups,row_totals))
    whole=groups[-1][-1]
    assert qsum(cols)==qsum(row_totals)==whole-delta
    assert joint.less(qsum(arbitrary),whole-delta)
    successive=[]
    for step in (1,2,3):
        final=(R(0),whole-delta*R(step))
        slices=[length(interval_intersection(I,final)) for I in groups]
        direct=[qsum(length(interval_intersection(source,moved(I,delta*R(step))))
                     for source in groups) for I in groups]
        assert slices==direct
        assert all(joint.equal_or_larger(length(I),v) for I,v in zip(groups,slices))
        successive.append(slices)
    return dict(non_wrapping_delta=delta,exact_coarse_row_column_intersections=true,
                row_totals=row_totals,column_totals=column_totals,
                fine_column_count=len(cols),bounds_for_every_fine_column=True,
                example_actual_partial_subflow_terminal_total=qsum(arbitrary),
                complete_source_carried_rank_generation_one_two_three=successive)


def repeated_terminal(groups,fine):
    a,b,c=map(length,groups)
    e=qmin((a,b,c))*R(F(1,8))
    delta=b*R(F(1,2))+e
    candidate=(a-e*R(F(3,2)),a-e*R(F(1,2)))
    assert subset(candidate,groups[0])
    assert subset(moved(candidate,delta),groups[1])
    assert subset(moved(candidate,delta*R(2)),groups[2])
    chosen=None
    for j,key,I in fine:
        if j==0:
            trim=interval_intersection(candidate,I)
            if trim:
                chosen=(key,trim)
                break
    assert chosen
    key,J=chosen
    once=moved(J,delta)
    twice=moved(J,delta*R(2))
    assert subset(once,groups[1]) and subset(twice,groups[2])
    assert not interval_intersection(once,twice)
    image_one=interval_intersection(moved(once,-delta),groups[0])
    mid=interval_intersection(moved(twice,-delta),groups[1])
    assert mid is not None
    image_two=interval_intersection(moved(mid,-delta),groups[0])
    assert image_one==image_two==J
    paid_in_J=length(image_one)+length(image_two)
    assert joint.less(R(0),length(J)) and paid_in_J==R(2)*length(J)
    return delta,dict(terminal_single_right_type=key,
                      strict_generational_paths=[[1,0],[2,1,0]],
                      terminal_window=J,distinct_initial_rank_intervals=[once,twice],
                      disjoint_initial_rank_total=paid_in_J,
                      one_column_budget_on_J=length(J),
                      generation_one_and_two_each_charge=length(J),
                      same_physical_terminal_window_cumulative_fee=paid_in_J,
                      cumulative_over_terminal_window_budget=2)


def rank_case(n):
    x,p,main,core,u,g,top,params,_,_=joint.input_case(n)
    assert all(l["W"]<r["W"] for l,r in zip(params,params[1:]))
    fibers=[joint.build_fiber(n,x,p,main,core,g,False)[0],
            joint.build_fiber(n,x,p,main,core,u,True)[0]]
    tables=[]
    for choice,interval in ((0,(F(0),F(1,4))),(1,(F(1,4),F(1,2)))):
        tick=sum(interval)/2
        by_side=[]
        for fiber in fibers:
            intervals,fine,H=ranks(fiber,params,choice,tick)
            delta,witness=repeated_terminal(intervals,fine)
            total=intervals[-1][-1]
            trials=[one_generation(intervals,fine,dq)
                    for dq in (total*R(F(1,8)),total*R(F(1,2)),delta)]
            by_side.append(dict(actual_H_d_lambda_masses=H,
                                W_d=[row["W"] for row in params],
                                intervals_ranked_by_original_absolute_bins=intervals,
                                distinct_rank_pieces_of_actual_hidden_arm=len(fine),
                                rank_transport_trials=trials,
                                strict_different_generation_witness=witness))
        tables.append(dict(old_history_in_middle_physical_parent=choice,
                           same_one_threshold_interval_for_both_directions=interval,
                           actual_midpoint_threshold=tick,
                           both_directions=by_side))
    return dict(n=n,true_visible_price=x,normalized_owner_probe=p,
                actual_full_d_v=[row["full_d_v"] for row in params],
                absolute_middle_bins=[row["actual_absolute_volume_D"] for row in params],
                increasing_W_and_increasing_absolute_bin_orders_coincide=True,
                shared_true_tables=tables)


def add(a,b):
    return tuple(x+y for x,y in zip(a,b))


def sub(a,b):
    return tuple(x-y for x,y in zip(a,b))


def mul(q,a):
    return tuple(q*x for x in a)


def norm(a):
    return max(map(abs,a))


def by_anchor(t,x,rho):
    return add(x,mul(rho,sub(t,x)))


def motion_case(n,s0,rho1,rho2,boundary):
    a=32*n
    h=1+F(1,a)
    S=[s0,rho1*s0,rho2*rho1*s0]
    true=[r/h for r in S]
    errors=[r/a for r in true]
    assert all(F(1)<=r<F(2) for r in true)
    T0=(F(0),)*n
    eps1=F(0) if boundary else 3*errors[0]
    eps2=F(0) if boundary else 3*errors[1]
    x=(s0-eps1,)+(F(0),)*(n-1)
    T1=by_anchor(T0,x,rho1)
    z=add(T1,(S[1]-eps2,S[1]/3)+(F(0),)*(n-2))
    T2=by_anchor(T1,z,rho2)
    probes=[T0,T1,T2]
    places=[add(t,((e if boundary else e/2),)+(F(0),)*(n-1))
            for t,e in zip(probes,errors)]
    assert x!=z and x[1]!=z[1]
    assert norm(sub(x,places[0]))<=true[0] and norm(sub(z,places[1]))<=true[1]
    assert all(norm(sub(t,c))<=e for t,c,e in zip(probes,places,errors))
    assert all(norm(sub(t,c))+r<=s for t,c,r,s in zip(probes,places,true,S))
    assert all(norm(sub(places[i],places[j]))>errors[i]+errors[j]
               for i,j in combinations(range(3),2))
    assert all(norm(c)+r<4 for c,r in zip(places,true))
    assert norm(sub(T1,T0))+S[1]<=S[0] and norm(sub(T2,T1))+S[2]<=S[1]
    bounds=[]
    for j in (1,2):
        span=S[0]-S[j]
        shift=norm(sub(T0,probes[j]))
        eps=norm(sub(probes[j],places[j]))
        current=norm(sub(T0,places[j]))
        shadow=span+eps
        assert shift<=span and current<=shadow
        assert (current==shadow)==boundary
        all_ancestor_E=norm(sub(places[0],places[j]))+errors[0]
        enlarged_radius=shadow+norm(sub(places[0],T0))+errors[0]
        assert all_ancestor_E<=enlarged_radius
        bounds.append(dict(terminal_j=j,soft_radii_drop=span,
                           actual_ancestor_to_landing_probe=shift,
                           terminal_real_owner_error=eps,
                           actual_ancestor_probe_to_terminal_center=current,
                           Q_terminal_center_shadow_radius_for_ancestor_probe=shadow,
                           entire_ancestor_owner_radius_about_terminal_center=all_ancestor_E,
                           enlarged_shadow_radius_if_asking_for_entire_initial_owner=enlarged_radius))
    positive=None
    if not boundary:
        sx=true[0]-norm(sub(x,places[0]))
        sz=true[1]-norm(sub(z,places[1]))
        slack=min(sx,sz,min(errors)/2)
        width=slack/4
        assert width>0
        assert (1-rho1)*width<errors[1]/2
        assert (rho2*(1-rho1)+1-rho2)*width<errors[2]/2
        positive=(2*width)**(2*n)
    return dict(n=n,physical_center_owners=places,true_parent_radii=true,
                true_owner_errors=errors,soft_frame_radii=S,rho=[rho1,rho2],
                different_actual_first_and_second_price=[x,z],true_probes=probes,
                tests_with_actual_boundary_prices=boundary,
                ancestor_probe_and_owner_shadow_tests=bounds,
                positive_two_price_neighborhood_measure_at_interior_test=positive)


def encode(x):
    if isinstance(x,F):
        return str(x)
    if isinstance(x,frames.Q4):
        return str(x.scalar()) if x.a[1:]==(0,0,0) else {
            "exact_coefficients_in_1_q_q2_q3":x.a}
    raise TypeError(type(x).__name__)


def main():
    global joint,frames
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--joint-dir",type=Path)
    p.add_argument("--geometry-dir",type=Path)
    out=p.add_mutually_exclusive_group()
    out.add_argument("--output",type=Path)
    out.add_argument("--check",type=Path)
    args=p.parse_args()
    for path in (args.joint_dir,args.geometry_dir):
        if path:
            sys.path.insert(0,str(path))
    import joint794 as joint
    import frames793 as frames
    joint.frames=frames
    joint.root_left,joint.root_right=F(1),F(2)
    for _ in range(100):
        mid=(joint.root_left+joint.root_right)/2
        if mid**4<2:
            joint.root_left=mid
        else:
            joint.root_right=mid
    doc=dict(
        python={"executable":sys.executable,"version":platform.python_version(),
                "architecture":platform.machine()},
        arithmetic="Exact rational coefficients at q=2^(1/4); directed rational root brackets.",
        command="python -B ranks794.py --check ranks794.json",
        dependencies={x:sha256(Path(m.__file__).read_bytes()).hexdigest()
                      for x,m in (("joint794.py",joint),("frames793.py",frames))},
        scope=("The rank input is the actual frozen left price and probe of joint794 in both directions. "
               "The two common tables use the old physical-history law and real threshold intervals already used there. "
               "Within a frame, exact member types split each original rank interval deterministically. "
               "All substochastic shifts keep their absolute rank between successive generations. "
               "The two-price motion fixtures certify geometry, with true source mass equal to individual parent volume "
               "and true disjoint owner cores. They do not impose a full predecessor graph."),
        rank_cases=[rank_case(n) for n in (4,8,16)],
        separate_motion_cases=[
            motion_case(4,F(7,4),F(6,7),F(4,5),True),
            motion_case(8,F(15,8),F(17,20),F(9,10),False),
            motion_case(16,F(31,16),F(15,16),F(7,8),False)])
    data=(json.dumps(doc,indent=2,sort_keys=True,default=encode)+"\n").encode()
    if args.output:
        args.output.write_bytes(data)
    elif args.check:
        if args.check.read_bytes()!=data:
            raise SystemExit("certificate differs")
        print("ranks794: actual rank columns, repeated terminal and two-price nested motion agree")
    else:
        print(data.decode(),end="")


if __name__=="__main__":
    main()

