"""One terminating receiver per starting record, with all candidate volumes counted by a pointwise maximum."""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import isqrt
from pathlib import Path
import platform
import sys
from flint import arb, ctx

ctx.prec = 256
def out(x):
    return str(x)
def check_source(a,b):
    # A periodic Lebesgue density, 3/2 on the first half-period, 1/2 on the second.
    def primitive(x):
        period=Q(1,8)
        k=x//period
        r=x-k*period
        return k*period+r/2+min(r,period/2)
    assert -6 <= a <= b <= 6
    return primitive(b)-primitive(a)
def intervals(cuts):
    c=sorted(set(cuts))
    return list(zip(c,c[1:]))
def example(stride,reverse):
    g=Q(1,16)
    indices=list(range(-64,65))
    terminals=[k for k in indices if abs(k)<=32 and k%stride==0]
    m={k:2*(1+Q((k//stride)%2,16)) for k in terminals}
    half={k:Q(1,4) if k//stride%2==0 else Q(1,8) for k in terminals}
    assert all(check_source(k*g-m[k]/2,k*g+m[k]/2)==m[k] for k in terminals)
    owners={k:(k*g-g/2,k*g+g/2) for k in indices}
    start=set(indices)-set(terminals)
    # All physical cores are disjoint and allowable both at stop and at start (start radius 3/2).
    assert all(owners[k][1]==owners[k+1][0] for k in indices[:-1])
    wc=intervals([s for p in owners.values() for s in p]
                 +[k*g+j*half[k] for k in terminals for j in [-1,1]])
    yc=intervals([Q(-6),Q(6)]+[k*g+j*m[k]/2 for k in terminals for j in [-1,1]])
    rows=[]
    for wl,wr in wc:
        w=(wl+wr)/2
        label=next((k for k in indices if owners[k][0]<w<owners[k][1]),None)
        if label is None:
            continue
        hits=[k for k in terminals if abs(w-k*g)<half[k]]
        if hits:
            rows.append((wr-wl,hits,label))
    # A single joint law per initial receiver. Choose a genuine nearby physical terminal.
    # This diagnostic kernel is not claimed to implement the high-peak rank shifts.
    flow=dict.fromkeys(terminals,Q(0))
    for vol,hits,label in rows:
        if label in start:
            ws=[m[k]**(-1 if reverse else 1) for k in hits]; total=sum(ws,Q(0))
            for k,q in zip(hits,ws):
                flow[k]+=vol*q/total
    pa=dict.fromkeys(terminals,Q(0))
    bill=Q(0); mixed_bill=Q(0); naive=Q(0); Dmax=Q(0); above=Q(0)
    for yl,yr in yc:
        y=(yl+yr)/2; source=check_source(yl,yr)
        meets=set(k for k in terminals if abs(y-k*g)<m[k]/2)
        if not meets:
            continue
        D=Q(0); Ds=Q(0)
        for vol,hits,_ in rows:
            den=[1/m[k] for k in hits if k in meets]
            D+=vol*max(den,default=Q(0))
            Ds+=vol*sum(den,Q(0))
        assert D>0 and D<=Ds
        Dmax=max(Dmax,D); above+=source*(D>1); score=min(1,1/D)
        bill+=source*min(1,D); naive+=source*Ds
        mixed_bill+=source*score*sum(flow[k]/m[k] for k in meets)
        for k in meets: pa[k]+=source*score/m[k]
    paid=sum(flow[k]*pa[k] for k in terminals)
    assert all(0<p<=1 for p in pa.values()) and paid==mixed_bill<=bill<=check_source(-6,6)
    return dict(stride=stride,allocation="inverse mass" if reverse else "mass",true_terminals=len(terminals),
        nonterminal_owners=len(start),receiver_rows=len(rows),price_intervals=len(yc),total_flow=out(sum(flow.values())),
        paid_start_then_terminal=out(paid),paid_source_then_receiver=out(mixed_bill),integrated_upper=out(bill),
        integral_of_unclipped_repeated_sum=out(naive),max_D=out(Dmax),source_mass_D_above_one=out(above),
        nontrivial_terminal_scores=sum(0<p<1 for p in pa.values()))
def product(n):
    root=isqrt(n); assert root*root==n
    g=Q(1,16*n); r=Q(1,2*root)
    # All cube centres are in g Z^n cap [-3,3]^n. Each owner is a mesh tile of half width g/2.
    # Every source coordinate is strictly in (0,g/2). Exactly 2/g centres per coordinate have y in A.
    count=int(2/g); assert count*g==2 and g<=2*r
    envelope=(1+r-g/2)**n
    repeated=(count*r)**n
    assert repeated>envelope>1
    if n<=4:
        # Separately verify the exact union by one-coordinate interval sweep, then tensorize.
        price=g/4
        c=[k*g for k in range(-int(3/g),int(3/g)+1) if abs(price-k*g)<=1]
        assert len(c)==count and c[0]==-1+g and c[-1]==1
        cc=intervals([v+sgn*r for v in c for sgn in [-1,1]])
        length=sum(b-a for a,b in cc if any(v-r<(a+b)/2<v+r for v in c))
        assert (length/2)**n==envelope
    full_width=1+r-g/2
    half_width=Q(1,2)+r
    def constrained(b):
        return half_width**b * full_width**(n-b)
    left,right=0,n
    while left+1<right:
        middle=(left+right)//2
        if constrained(middle)<=1:
            right=middle
        else:
            left=middle
    assert constrained(right)<=1<constrained(right-1)
    value=arb(1)+arb(r.numerator)/int(r.denominator)-arb(g.numerator)/(2*g.denominator)
    logs=arb(n)*value.log()/arb(10).log()
    return dict(n=n,neighbours_per_axis=count,shadow_halfwidth=out(r),core_mesh=out(g),
                D_exact_base=out(1+r-g/2),repeated_sum_exact_base=out(count*r),power=n,one_sided_axis_base=out(half_width),first_axes_making_D_at_most_one=right,
                log10_envelope_interval=str(logs),exact_order_checked=True)
def make():
    return dict(python=sys.version.split()[0],architecture=platform.machine(),arb_bits=ctx.prec,
        scope="True disjoint Lebesgue owner cells and true first-crossing mass identities. Diagnostic initial-to-terminal couplings and tensor geometric envelopes. No assertion of a surviving full hard branch.",
        tests=[example(s,v) for s in [16,4,2] for v in [False,True]],
        product_geometry=[product(n) for n in [4,16,64,256,1024]])
def main():
    ap=argparse.ArgumentParser(); g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--output",type=Path);g.add_argument("--check",type=Path);a=ap.parse_args()
    data=(json.dumps(make(),sort_keys=True,indent=2)+"\n").encode()
    if a.output: a.output.write_bytes(data)
    else: assert a.check.read_bytes()==data
    print("shadows794 PASS",sha256(data).hexdigest())
if __name__=="__main__":
    main()
