"""R794: one true frame tube, hidden arm layers and a shared history/threshold table."""

import argparse
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
import platform
import sys


frames = None
ETA = F(3,4)
HALF, PERIOD = F(1,16), F(1,8)


def R(x):
    return frames.rational(x)


def qsum(xs):
    return sum(xs,R(0))


def fsum(xs):
    return sum(xs,F(0))


def qbounds(x):
    lo=hi=F(0)
    for k,a in enumerate(x.a):
        x0,x1=a*root_left**k,a*root_right**k
        lo+=min(x0,x1)
        hi+=max(x0,x1)
    return lo,hi


def comparison(x,y):
    if x==y:
        return 0
    a,b=qbounds(x-y)
    assert a>0 or b<0
    return 1 if a>0 else -1


def less(x,y):
    return comparison(x,y)<0


def positive(x):
    return comparison(x,R(0))>0


def equal_or_larger(x,y):
    return comparison(x,y)>=0


def inv(x):
    assert x!=R(0)
    a,b,c,d=x.a
    opposite=frames.Q4((a,-b,c,-d))
    pair=x*opposite
    assert pair.a[1]==pair.a[3]==0
    conjugate=frames.Q4((pair.a[0],F(0),-pair.a[2],F(0)))
    norm=(pair*conjugate).scalar()
    ans=opposite*conjugate*R(1/norm)
    assert ans*x==R(1)
    return ans


def primitive(x):
    lo,hi=qbounds(x)
    k=lo//PERIOD
    assert k==hi//PERIOD
    r=x-R(k*PERIOD)
    left=r if less(r,R(HALF)) else R(HALF)
    return R(k*PERIOD)+r*R(F(1,2))+left


def price0(x,y):
    assert less(x,y)
    return primitive(y)-primitive(x)


def price_rational(lo,hi):
    return price0(R(lo),R(hi)).scalar() if lo<hi else F(0)


def sorted_cuts(values):
    cuts=sorted(set(values),key=lambda x:qbounds(x)[0])
    assert all(less(a,b) for a,b in zip(cuts,cuts[1:]))
    return cuts


@dataclass(frozen=True)
class Parent:
    c: tuple
    s: F
    m: F
    E: F


def input_case(n):
    a,h,main,Uc,Us,X,P,p0,eps=frames.parent_family(n)
    x=(eps/4,)+(F(0),)*(n-1)
    z=(F(0),)*(n-2)

    def item(c,s):
        return Parent(c,s,(2*s)**n,(2*s/a)**n)

    core=[item(f.c,f.s) for f in main]
    u=item((Uc,F(0))+z,Us)
    g=item((F(5,4),F(41,32))+z,F(21,16))
    top=item((F(0),F(51,16))+z,F(63,32))
    all_parents=core+[u,g,top]
    for v in all_parents:
        assert all(abs(y)+v.s<6 for y in v.c)
        assert price_rational(v.c[0]-v.s,v.c[0]+v.s)*(2*v.s)**(n-1)==v.m
    assert all(max(abs(x-y) for x,y in zip(v.c,w.c))>(v.s+w.s)/a
               for v,w in combinations(all_parents,2))
    frames.prove_positive_region(n,a,h,main,Uc,Us,X,P)
    assert all(lo<=y<=hi for (lo,hi),y in zip(X,x))
    X_positive=[(eps/8,3*eps/8)]+X[1:]
    assert all(abs(y-c)<q.s for q in [u,g] for y,c in zip(x,q.c))
    assert all(c-q.s < lo < hi < c+q.s
               for q in [u,g] for (lo,hi),c in zip(X_positive,q.c))
    assert 0 < X_positive[0][0] < X_positive[0][1] < F(1,8)
    positive_measure=(eps/4)*(2*eps)**(2*n-1)
    assert positive_measure > 0
    part=[]
    for j,v in enumerate(core):
        edge={}
        for i,q in enumerate(all_parents):
            left=max(v.c[0]-v.s,q.c[0]-q.s)
            right=min(v.c[0]+v.s,q.c[0]+q.s)
            mass=price_rational(left,right)
            for sv,sq in zip(v.c[1:],q.c[1:]):
                mass*=max(F(0),min(sv+v.s,sq+q.s)-max(sv-v.s,sq-q.s))
            if v.m!=q.m and 0<mass<=ETA*min(v.m,q.m):
                edge[i]=q.E*mass/(v.m*q.m)
        assert 3 in edge and 4 in edge and 5 in edge
        degree=fsum(edge.values())
        down=fsum(w for i,w in edge.items() if all_parents[i].m<v.m)
        assert degree>down>0
        c=2*h**n*main[j].D/v.m  # j_i = |E_i| in this fixture.
        M=v.m*degree
        width=((main[j].t*R(2))**n).scalar()
        assert 1/(M/c)==width/(degree*v.m*v.m)
        old_history_I=[v.E/2,v.E/2] if j==1 else [v.E]
        assert fsum(old_history_I)==v.E
        part.append(dict(j=j,actual_side_radius=v.s,true_parent_m=v.m,I_equals_owner=v.E,
                         actual_incident_arm_weights=edge,full_d_v=degree,down_d_v=down,
                         M=M,c=c,W=M/c,actual_absolute_volume_D=main[j].D,
                         fixed_physical_old_history_I=old_history_I))
    return x,p0,main,core,u,g,top,part,eps,positive_measure


def gate(j,k,u,g):
    """A fixed physical gate on the two literal original first coordinates."""
    if not less(u,R(0)):
        if j==0:
            return F(1,2) if less(g,R(F(3,2))) else F(0)
        if j==1 and k==0:
            if less(g,R(F(7,8))):
                return F(1,4)
            return F(3,4) if not less(g,R(F(3,2))) and less(g,R(F(9,4))) else F(0)
        if j==1 and k==1:
            if less(g,R(F(5,8))):
                return F(1)
            return F(1,2) if not less(g,R(F(5,4))) and less(g,R(F(35,16))) else F(0)
        if less(g,R(1)):
            return F(1,2)
        return F(1) if less(g,R(F(5,2))) else F(0)
    if j==0:
        return F(1,4) if not less(u,R(F(-1,4))) and less(g,R(1)) else F(0)
    if j==1 and k==0:
        return F(1) if not less(u,R(F(-5,8))) and less(g,R(F(1,4))) else F(0)
    if j==1 and k==1:
        return F(1,4) if not less(u,R(F(-1,8))) and less(g,R(F(1,8))) else F(0)
    return F(1,4) if not less(u,R(-1)) and less(g,R(F(1,2))) else F(0)


def member(lo,hi,point):
    return less(lo,point) and less(point,hi)


def build_fiber(n,x,p0,main,core,hidden,reverse):
    # Shared real owners are guaranteed by the same true positive probe tube.
    cut_values = ((F(-1),F(-5,8),F(-1,4),F(-1,8),F(0))
                  if reverse else
                  (F(1,8),F(1,4),F(1,2),F(5,8),F(7,8),F(1),
                   F(5,4),F(3,2),F(35,16),F(9,4),F(5,2)))
    true=[[ (R(w-v.s),R(w+v.s)) for w in v.c[:2]] for v in core]
    hats=[[(R(y)+f.t*R(p-1),R(y)+f.t*R(p+1)) for y,p in zip(x[:2],p0[:2])] for f in main]
    axes=[]
    for k in (0,1):
        a,b=R(hidden.c[k]-hidden.s),R(hidden.c[k]+hidden.s)
        all_cuts={a,b}
        for shape in true+hats:
            all_cuts |= {c for c in shape[k] if member(a,b,c)}
        if k==0:
            all_cuts |= {R(t) for t in cut_values if member(a,b,R(t))}
        bounds=sorted_cuts(all_cuts)
        axes.append(list(zip(bounds,bounds[1:])))
    out={}
    examples={}
    for ((a,b),(c,d)) in product(*axes):
        price=((a+b)*R(F(1,2)),(c+d)*R(F(1,2)))
        hit_geom=tuple(i for i,shape in enumerate(hats)
                       if all(member(lo,hi,y) for (lo,hi),y in zip(shape,price)))
        hit_true=tuple(i for i,shape in enumerate(true)
                       if all(member(lo,hi,y) for (lo,hi),y in zip(shape,price)))
        assert all(i in hit_geom for i in hit_true)
        U,G=(price[0],R(x[0])) if reverse else (R(x[0]),price[0])
        survival=tuple(tuple(gate(j,k,U,G) if j in hit_true else F(0)
                             for k in range(2 if j==1 else 1)) for j in range(3))
        key=(hit_geom,survival)
        mass=price0(a,b)*(d-c)*R((2*hidden.s)**(n-2)*hidden.E/hidden.m)
        out[key]=out.get(key,R(0))+mass
        examples.setdefault(key,price)
    assert qsum(out.values())==R(hidden.E)
    assert all(hidden.s<min(v.s for v in core) and hidden.s<min(qbounds(f.t)[0] for f in main)
               for f in main)
    return out,examples


def profile_rows(fiber,params):
    weights=[R(1/x["W"]) for x in params]
    expected={}
    true_by_j=[R(0)]*3
    fractions=[[R(0)],[R(0),R(0)],[R(0)]]
    union=[R(0)]*3
    hindsight=[R(0)]*3
    for key,mu in fiber.items():
        _,survival=key
        average=tuple(fsum(z)/len(z) for z in survival)
        expected[key]=average
        for j,group in enumerate(survival):
            true_by_j[j]+=mu*weights[j]*R(average[j])
            if max(group)>0:
                union[j]+=mu*weights[j]
            hindsight[j]+=mu*weights[j]*R(max(group))
            for k,xi in enumerate(group):
                fractions[j][k]+=mu*weights[j]*R(xi)
    assert all(positive(v) for v in true_by_j)
    phase_support=[qsum(mu for (_,xi),mu in fiber.items() if xi[1][k]>0) for k in (0,1)]
    overlap_support=qsum(mu for (_,xi),mu in fiber.items() if min(xi[1])>0)
    assert positive(overlap_support) and any(less(overlap_support,v) for v in phase_support)
    assert all(qsum(group)*R(F(1,len(group)))==w for group,w in zip(fractions,true_by_j))
    assert all(less(a,b) for a,b in zip(true_by_j,union))
    b=max(range(2),key=lambda k:qbounds(fractions[1][k])[0])
    assert less(fractions[1][1-b],fractions[1][b])
    return expected,weights,dict(
        actual_original_charge_by_bin=true_by_j,
        actual_original_charges_for_fixed_histories_by_bin=fractions,
        fixed_middle_phase_supports_and_overlap_on_the_same_actual_arm_reference=[phase_support,overlap_support],
        total_original_charge=qsum(true_by_j),
        unrestricted_support_as_unit_fee=qsum(union),
        total_if_choose_best_history_for_that_side_per_bin=fractions[0][0]+fractions[1][b]+fractions[2][0],
        also_look_at_hidden_arm_then_choose_history=qsum(hindsight),
        best_middle_bin_history_for_this_side=b)


def first_enter(fiber,first_func):
    pieces=[R(0)]*3
    for key,mu in fiber.items():
        j=first_func(key)
        if j is not None:
            pieces[j]+=mu
    return pieces


def layer_norm(fiber,examples,expected,weights,params,profile):
    def geometric(key):
        return min(key[0]) if key[0] else None

    def eligible(key):
        return next((j for j,t in enumerate(expected[key]) if t>0),None)

    geoms=first_enter(fiber,geometric)
    actual=first_enter(fiber,eligible)
    assert all(positive(v) for v in geoms+actual)
    G=[[R(F(1,3))*inv(v) for v in group] for group in (geoms,actual)]
    assert all(qsum(z*w for z,w in zip(g,layer))==R(1) for g,layer in zip(G,(geoms,actual)))
    cumulative=[]
    for group in (geoms,actual):
        z=R(0)
        coeff=[]
        for j,mu in enumerate(group):
            D=params[j]["actual_absolute_volume_D"]
            z+=mu*R(1/D)
            coeff.append(inv(R(D)*(R(1)+z)))
        integral=qsum(mu*w for mu,w in zip(group,coeff))
        cumulative.append(dict(final_Z=z,layer_score=coeff,row_integral=integral))
    raw_true=profile["actual_original_charge_by_bin"]
    once_mesh=[R(0)]*3
    actual_new=[R(0)]*3
    sum_fit=R(0)
    charged_linear=[R(0),R(0)]
    candidates=[]
    witness=None
    actual_terms=[]
    for key,mu in fiber.items():
        jg,ja=geometric(key),eligible(key)
        mix=qsum(weights[j]*R(w)*inv(raw_true[j]) for j,w in enumerate(expected[key]))
        sum_fit+=mu*mix
        for j,xi in enumerate(expected[key]):
            if not xi:
                continue
            assert jg is not None and ja is not None
            assert jg<=j and ja<=j
            mass=mu*weights[j]*R(xi)
            if jg==j:
                once_mesh[j]+=mass
            if ja==j:
                actual_new[j]+=mass
            scores=[R(params[j]["M"])*G[0][jg],R(params[j]["M"])*G[1][ja]]
            for i,s in enumerate(scores):
                charged_linear[i]+=mass*s
            actual_terms.append((j,mass,scores))
            if jg<ja and scores[0]!=scores[1]:
                candidates.append((scores[0]+scores[1])*R(F(1,2)))
                if witness is None:
                    witness=dict(active_current_bin=j,price_first_two_coords=examples[key],
                                 geometric_first_bin=jg,eligibility_first_bin=ja,
                                 actual_positive_original_piece=mass,M_times_G_in_two_laws=scores)
    assert sum_fit==R(3) and charged_linear[0]!=charged_linear[1]
    assert witness and candidates

    def paid(t):
        bins=[[R(0)]*3 for _ in range(2)]
        for j,mass,score in actual_terms:
            for i,value in enumerate(score):
                if equal_or_larger(value,t):
                    bins[i][j]+=mass
        return bins

    strict=None
    for t in sorted_cuts(candidates):
        arr=paid(t)
        if qsum(arr[0])!=qsum(arr[1]):
            strict=dict(common_fixed_threshold=t,fee_by_bin_geometric_and_eligible=arr,
                        total_fee_geometric_and_eligible=[qsum(x) for x in arr])
            break
    assert strict
    return dict(
        first_geometric_layers_and_first_eligible_layers=[geoms,actual],
        first_entry_numerator_lambda_new_over_W_for_geometric_and_eligible_union=[
            qsum(a*b for a,b in zip(layer,weights)) for layer in (geoms,actual)],
        normalized_1_over_3_new_layer_integrals=[F(1),F(1)],
        total_integral_of_three_separately_normalized_actual_conditionals=sum_fit,
        integral_if_conditional_mixture_weights_are_1_over_3=sum_fit*R(F(1,3)),
        R793_cumulative_unrenormalized_scores=cumulative,
        original_fee_by_bin_that_is_first_geometric=once_mesh,
        original_fee_by_bin_that_is_first_eligible=actual_new,
        full_original_MG_linear_fee_two_normalized_first_hit_laws=charged_linear,
        unit_threshold_fee_by_bin_geometric_and_eligible=paid(R(1)),
        fixed_diagnostic_threshold_with_strict_fee_difference=strict,
        witness_genuinely_different_first_hits=witness)


def table_audit(fibers,expected,weights,reports):
    knots=sorted({F(0),F(1)}|{z for f in fibers for _,phis in f for group in phis for z in group})
    total_table_weight=F(0)
    true_time=[R(0),R(0)]
    first_paid=[R(0),R(0)]
    pointwise=[defaultdict(F),defaultdict(F)]
    checked=0
    joint_draws=[]
    first_by_direction_bins=[[R(0)]*3 for _ in range(2)]
    for k,(a,b) in product(range(2),zip(knots,knots[1:])):
        threshold=(a+b)/2
        probability=(b-a)/2
        total_table_weight+=probability
        draw=dict(actual_middle_phase_chosen=k,one_public_threshold_interval=[a,b],
                  length_times_original_history_probability=probability,
                  by_direction_first_layers_and_full_fee=[])
        for l,fiber in enumerate(fibers):
            layers=[R(0)]*3
            prefix_sets=[set() for _ in range(3)]
            repeat=R(0)
            for key,mu in fiber.items():
                _,survival=key
                included=[j for j in range(3) if survival[j][k if j==1 else 0]>=threshold]
                for j in included:
                    pointwise[l][key,j]+=probability
                    repeat+=mu*weights[l][j]
                    for i in range(j,3):
                        prefix_sets[i].add(key)
                if included:
                    layers[min(included)]+=mu
            prefix=[qsum(fiber[key] for key in s) for s in prefix_sets]
            assert layers==[prefix[j]- (prefix[j-1] if j else R(0)) for j in range(3)]
            block=qsum(x*y for x,y in zip(layers,weights[l]))
            assert equal_or_larger(repeat,block)
            true_time[l]+=repeat*R(probability)
            first_paid[l]+=block*R(probability)
            for j,(mass,weight) in enumerate(zip(layers,weights[l])):
                first_by_direction_bins[l][j]+=mass*weight*R(probability)
            draw["by_direction_first_layers_and_full_fee"].append([layers,repeat])
            checked+=1
        joint_draws.append(draw)
    assert total_table_weight==1
    assert [qsum(row) for row in first_by_direction_bins]==first_paid
    for l,phi in enumerate(expected):
        for key,values in phi.items():
            assert tuple(pointwise[l][key,j] for j in range(3))==values
    assert true_time==[r["total_original_charge"] for r in reports]
    assert all(positive(f) and less(f,t) for f,t in zip(first_paid,true_time))
    assert reports[0]["best_middle_bin_history_for_this_side"]!=reports[1]["best_middle_bin_history_for_this_side"]
    # If one tried choosing a deterministic optimal history, the two sides
    # cannot both use their separate optima. Our table uses the actual law instead.
    left,right=(r["actual_original_charges_for_fixed_histories_by_bin"] for r in reports)
    same_best=max((left[1][k]+right[1][k] for k in range(2)),key=lambda x:qbounds(x)[0])
    separately=qsum(group[r["best_middle_bin_history_for_this_side"]]
                    for group,r in zip((left[1],right[1]),reports))
    assert less(same_best,separately)
    return dict(the_actual_common_table_and_threshold_total_probability=total_table_weight,
                one_fixed_original_table_used_for_both_directions=True,
                exact_table_times_direction_trials_checked=checked,
                recovered_original_mean_fee_by_direction=true_time,
                expected_normalized_first_entry_sum_lambda_new_over_W=first_paid,
                expected_first_entry_numerator_by_side_and_bin=first_by_direction_bins,
                actual_table_and_threshold_interval_exact_weights=joint_draws,
                same_fixed_history_best_sum_across_both_vs_selecting_separately=[same_best,separately])


def case(n):
    x,p,main,core,u,g,top,params,eps,tube_weight=input_case(n)
    fiber_out=[build_fiber(n,x,p,main,core,g,False),build_fiber(n,x,p,main,core,u,True)]
    expect=[]; weights=[]; reports=[]; layers=[]
    for i,(fiber,examples) in enumerate(fiber_out):
        A,B,C=profile_rows(fiber,params)
        expect.append(A); weights.append(B); reports.append(C)
        layers.append(layer_norm(fiber,examples,A,B,params,C))
    full_geo=[]
    for f in main:
        low=R(x[0])+f.t*R(p[0]-1)
        up=R(x[0])+f.t*R(p[0]+1)
        full_geo.append(price0(low,up)*(f.t*R(2))**(n-1))
    assert any(w!=R(2*(1+F(1,32*n))**n*f.D) for w,f in zip(full_geo,main))
    return dict(
        n=n,real_true_visible_price_center=x,common_normalized_probe=p,
        physical_left_and_right_arm_centers_and_radii=[(u.c,u.s),(g.c,g.s)],
        physical_upper_neighbor_center_and_radius=(top.c,top.s),
        all_three_bins_have_positive_original_density_same_x_p_in_both_directions=True,
        positive_x_p_tube_side=2*eps,
        certified_positive_two_direction_subtube_Lebesgue_measure=tube_weight,
        actual_probe_geometry_by_middle=params,
        pure_source_mu_of_the_full_predictor_boxes=full_geo,
        two_fixed_physical_hidden_arm_references=[g.E,u.E],
        exact_price_membership_types_by_direction=[len(o[0]) for o in fiber_out],
        by_direction_overlapping_true_conditional_fees=reports,
        by_direction_geometry_vs_actual_eligible_first_hit=layers,
        global_common_history_threshold_and_first_hit=table_audit(
            [o[0] for o in fiber_out],expect,weights,reports))


def archive(x):
    if isinstance(x,F):
        return str(x)
    if isinstance(x,frames.Q4):
        if x.a[1:]==(0,0,0):
            return str(x.scalar())
        return {"exact_coefficients_in_1_q_q2_q3":x.a}
    raise TypeError(type(x).__name__)


def main():
    global frames,root_left,root_right
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--geometry-dir",type=Path)
    out=p.add_mutually_exclusive_group()
    out.add_argument("--output",type=Path)
    out.add_argument("--check",type=Path)
    args=p.parse_args()
    if args.geometry_dir:
        sys.path.insert(0,str(args.geometry_dir))
    import frames793 as frames
    root_left,root_right=F(1),F(2)
    for _ in range(100):
        mid=(root_left+root_right)/2
        if mid**4<2:
            root_left=mid
        else:
            root_right=mid
    result=dict(
        python={"executable":sys.executable,"version":platform.python_version(),
                "architecture":platform.machine()},
        arithmetic="Exact Fraction coefficients in the real field Q(q), q^4=2; exact rational root brackets for inequalities.",
        command="python -B joint794.py --check joint794.json",
        dependency={"frames793.py":sha256(Path(frames.__file__).read_bytes()).hexdigest()},
        scope=("Use R793's three exact physical frame centres, standard dyadic end radii and positive tube. "
               "The compact true source has alternating densities 3/2 and 1/2 on the first-coordinate half-periods, "
               "on Q(0,6); two added physical small arms and a larger real owner give diagnostic hard edges "
               "with eta=3/4 and full d. At each of two real visible arm labels fix the same x and probe; "
               "the same right physical arm reference is used for every candidate within a direction. "
               "The finite private gate is a declared nonproduct pressure model, with two histories of "
               "equal original I_v/2 at the middle bin and genuinely different supports. "
               "The full near-extreme reduction and higher-dimensional gates are outside this finite scope."),
        cases=[case(n) for n in (4,8,16)])
    val=(json.dumps(result,indent=2,sort_keys=True,default=archive)+"\n").encode()
    if args.output:
        args.output.write_bytes(val)
    elif args.check:
        if args.check.read_bytes()!=val:
            raise SystemExit("certificate differs")
        print("joint794: shared real frames, cumulative eligible arms and common threshold table agree")
    else:
        print(val.decode(),end="")


if __name__=="__main__":
    main()

