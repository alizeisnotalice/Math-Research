from fractions import Fraction as F
import json

def logs(x,N=100):
 assert x>=1
 z=(x-1)/(x+1);lo=2*sum((z**(2*j+1)/F(2*j+1) for j in range(N)),F(0));hi=lo+2*z**(2*N+1)/(F(2*N+1)*(1-z*z));return lo,hi

# Constant guards in growing dimension, no floating-point inequalities.
rows=[]
for n in [2,4,8,16,32,64,128,256,1024,4096]:
 d=F(1,100*n);D=16*n*n;beta=(1-F(4,D))**(n-1);ratio=F(D-2,D-4)**(n-1)
 assert beta>=F(7,8) and ratio<2
 assert F(1,4)*F(D-2,D)**(n-1)<F(1,4)
 lo43,hi43=logs(F(4,3));lo2,hi2=logs(F(2))
 logQlo=(n-1)*lo43-hi2
 rows.append({'n':n,'source_fraction_display':float(beta),'capture_ratio_display':float(ratio),'certificate_lower_display':float(1+F(7,8)*max(F(0),logQlo)),'core_weak_ratio_display':float(F(1,4)*F(D-2,D)**(n-1))})
# Original continuous-winner geometry and anchor condition.
winners=[]
for n in [2,8,32]:
 d=F(1,100*n)
 for R in [F(7,5),F(3,2),F(7,4),F(19,10)]:
  x=(R-d)/2
  assert F(4,3)<R<2 and x>F(1,2)+d/2
  def H(L):return min(d,max(F(0),L/2-x+d/2))/(d*L)
  assert H(F(1))==0 and H(R)==1/R
  assert F(3,8)<H(R)<F(3,4)
  for L in [R-d,R-d/2,R,R+d/2,F(2)]:
   assert H(L)<=H(R)
  assert x-d/2>0 # exact positive derivative numerator in partial stage
  winners.append({'n':n,'winner':str(R),'x1':str(x),'height':str(H(R))})
# Integrate the source capture factor exactly; R runs from 4/3 to 2.
# For any tangential interior y, dx1 from the two faces equals dR.
source=[]
for n in [2,3,4,8,16,32]:
 exact=(F(2)**n-F(4,3)**n)/n
 lower=F(2,3)*F(4,3)**(n-1)
 assert exact>=lower
 source.append({'n':n,'exact_capture_volume':str(exact),'used_lower':str(lower),'exact_source_profile':'1/4'})
# Scalar optimization of the proven certificate, tested with certified logs.
# Scaling logQ avoids enormous atanh ratios when n is large.
optimization=[]
l43,u43=logs(F(4,3));l2,u2=logs(F(2))
for n in [4,16,64,256]:
 q=F(4,3)**(n-1)/2
 for s in [F(1),F(3,2),F(2),F(4),q,q*2]:
  if s<1:continue
  # Verify f'(s)>=1/8 for s<q via nonnegativity of log(q/s).
  assert q>1 and s>=1
  if s==1:continue # exact equality at the minimizer
  if s>=q:
   assert s>=1+F(7,8)*((n-1)*u43-l2)
  else:
   ls,us=logs(s if s<=4 else F(1))
   assert s<=4
   logratio_lower=(n-1)*l43-u2-us
   target_upper=1+F(7,8)*((n-1)*u43-l2)
   assert s*(1+F(7,8)*max(F(0),logratio_lower))>=target_upper
  optimization.append({'n':n,'s':str(s),'passed':True})
print(json.dumps({'status':'PASS','scope':'exact rational geometry and analytic-certificate guards; not a numerical general weak-type proof','dimension_guards':rows,'continuous_winner_checks':winners,'source_capture_integrals':source,'certificate_checks':optimization},indent=2,sort_keys=True))
