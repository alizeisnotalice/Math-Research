"""Exact two-cell kernel, positive-width realization and pinned R814 bookkeeping."""

import argparse
from collections import defaultdict
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction as F
from hashlib import file_digest, sha256
from itertools import product
from json import loads
from math import isqrt, prod
from pathlib import Path
import sys
from zipfile import ZipFile

BITS = 104
Q_FIXED = (F(1, 2), F(1, 4), F(1, 8), F(1, 16))
DIMENSIONS = (16, 256, 4096)
PIN_814 = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"


def root_interval(value, degree):
    assert value >= 0 and degree in {2, 4, 8}
    denominator = 1 << BITS
    scaled = (value.numerator << (BITS * degree)) // value.denominator
    for _ in range(degree.bit_length() - 1):
        scaled = isqrt(scaled)
    lower = F(scaled, denominator)
    upper = lower if lower**degree == value else F(scaled + 1, denominator)
    assert lower**degree <= value <= upper**degree
    return lower, upper


def c_squared(q):
    if q <= F(1, 2):
        return 1 + q**4 / (1 - 2*q*q)
    return (1 + q)**2 / 2


def display(lower, upper=None, precision=19):
    upper = lower if upper is None else upper
    assert lower <= upper
    with localcontext() as ctx:
        ctx.prec = precision
        ctx.rounding = ROUND_FLOOR
        lo = Decimal(lower.numerator) / Decimal(lower.denominator)
        ctx.rounding = ROUND_CEILING
        hi = Decimal(upper.numerator) / Decimal(upper.denominator)
    return f"[{lo}, {hi}]"


def product_interval(q_bounds, n):
    # C(q) is increasing by its defining supremum of affine functions of q.
    lo, hi = q_bounds
    lo_c, _ = root_interval(c_squared(lo), 2)
    _, hi_c = root_interval(c_squared(hi), 2)
    return lo_c**n, hi_c**n


def constants():
    print("u=3/4; F(t)=(1+t^6+2*q*t^3)/(1+t^4)^(3/2)")
    print("0<=t<=1; t/(1+t*t)=q for q<=1/2; t=1 for q>=1/2.")
    print("F(0)=1; F(1)=(1+q)/sqrt(2); symmetry s and 1-s.")
    for q in Q_FIXED:
        lo_d, hi_d = root_interval(1 - 4*q*q, 2)
        lo_t, hi_t = 2*q/(1 + hi_d), 2*q/(1 + lo_d)
        assert lo_t / (1 + lo_t**2) <= q <= hi_t / (1 + hi_t**2)
        lo_s = lo_t**4 / (1 + lo_t**4)
        hi_s = hi_t**4 / (1 + hi_t**4)
        lo_c, hi_c = root_interval(c_squared(q), 2)
        print("q", q, "C^2", c_squared(q), "C", display(lo_c, hi_c),
              "t*", display(lo_t, hi_t), "s*", display(lo_s, hi_s))
    for n in DIMENSIONS:
        for q in Q_FIXED:
            print("n", n, "constant q", q, "C^n", display(*product_interval((q, q), n)))
        for degree in (8, 4):
            interval = root_interval(F(1, n), degree)
            print("n", n, f"q=n^(-1/{degree})", display(*interval),
                  "C^n", display(*product_interval(interval, n)))


def positive_width():
    length = F(1, 16)
    radius = F(1)
    width = 2*radius - length
    intervals_by_axis = []
    for q in Q_FIXED:
        separation = (1 - q) * width
        assert separation > 15 * length
        sources = ((F(0), length), (separation, separation + length))
        centers = tuple((hi - radius, lo + radius) for lo, hi in sources)
        assert all(hi - lo == width for lo, hi in centers)
        assert centers[0][1] - centers[1][0] == q * width
        intervals_by_axis.append(centers)
    dimension = len(intervals_by_axis)
    cells = tuple(product((0, 1), repeat=dimension))
    # t=q is an explicit rational test vector; its coordinate masses are
    # proportional to (1,t^4) and the squared pair normalization is rational.
    pair_normalization_squared = prod(1 + t**4 for t in Q_FIXED)**3
    coefficients = {cell: prod(t**3 for t, bit in zip(Q_FIXED, cell, strict=True) if bit)
                    for cell in cells}
    pair_total = F(0)
    for a, b in product(cells, repeat=2):
        volume = F(1)
        for axis, i, j in zip(intervals_by_axis, a, b, strict=True):
            volume *= min(axis[i][1], axis[j][1]) - max(axis[i][0], axis[j][0])
        assert volume == width**dimension * prod(
            q for q, i, j in zip(Q_FIXED, a, b, strict=True) if i != j)
        pair_total += coefficients[a] * coefficients[b] * volume
    shared_total = F(0)
    cuts = [tuple(sorted({x for interval in axis for x in interval}))
            for axis in intervals_by_axis]
    slices = [tuple(zip(axis[:-1], axis[1:], strict=True)) for axis in cuts]
    for receiver in product(*slices):
        available = [
            cell for cell in cells
            if all(axis[i][0] <= lo <= hi <= axis[i][1]
                   for axis, i, (lo, hi) in zip(intervals_by_axis, cell, receiver, strict=True))
        ]
        shared_total += max(coefficients[cell] for cell in available)**2 * prod(
            hi - lo for lo, hi in receiver)
    norm_squared = pair_normalization_squared * width**(2*dimension)
    assert pair_total**2 > norm_squared > shared_total**2 > 0
    print("positive widths", "source", length, "whole-source center", width)
    print("16 source cells, 256 pair intersections, 81 disjoint center cells")
    print("same explicit test vector, independent pair measure", display(*root_interval(pair_total**2/norm_squared, 2)),
          "disjoint optimal assignment", display(*root_interval(shared_total**2/norm_squared, 2)),
          "sharp disjoint norm 1")


def r814(rounds):
    path = rounds / "814" / "research.zip"
    with path.open("rb") as archive_file:
        assert file_digest(archive_file, "sha256").hexdigest() == PIN_814
    with ZipFile(path) as zip_file:
        manifest = loads(zip_file.read("MANIFEST.json"))
        assert all(sha256(zip_file.read(member)).hexdigest() == digest
                   for member, digest in manifest["members"].items())
        comb = {"__name__": "archived_comb811"}
        exec(zip_file.read("comb811.py"), comb)
        fixtures = {"original": comb["fixture"](*comb["FIXTURES"][-1]),
                    "rebuilt": loads(zip_file.read("comb814-rebuilt.json"))["stages"][0]}
        for label, stage in fixtures.items():
            record_count = 0
            bins = defaultdict(lambda: [0, F(0)])
            rights = defaultdict(lambda: (set(), set(), set()))
            parents = {row["id"]: row for row in stage["parents"]}
            source_masses = {row["mask"]: F(row["mass"]) for row in stage["cells"]}
            for root in stage["roots_cross"]:
                t, u, g = (root[name] for name in ("t", "u", "g"))
                middle, left, right = (parents[i] for i in (t, u, g))
                m = F(middle["m"])
                mid_bin = m.numerator.bit_length() - m.denominator.bit_length()
                mid_bin -= (m < F(2)**mid_bin)
                coefficient = (F(middle["j"])*F(left["j"])*F(right["j"])
                               / (F(middle["full_d"])*m*m*F(left["m"])*F(right["m"])))
                assert coefficient == F(root["coefficient"])
                subtotal = F(0)
                for z, q in product(root["z_masks"], root["q_masks"]):
                    subtotal += coefficient * source_masses[z] * source_masses[q]
                    partner, middle_labels, middle_bins = rights[q]
                    partner.add(z)
                    middle_labels.add(t)
                    middle_bins.add(mid_bin)
                assert subtotal == F(root["root_mass"])
                n = len(root["z_masks"]) * len(root["q_masks"])
                key = mid_bin, F(left["volume_bin"]), F(right["volume_bin"])
                bins[key][0] += n
                bins[key][1] += subtotal
                record_count += n
            assert record_count == 230
            mass = sum(w for _, w in bins.values())
            assert mass == F(stage["benchmarks"]["cross"]["mother"])
            print("R814", label, "dimension", stage["dimension"],
                  "rows", record_count, "mass", display(mass))
            for (middle, left, right), (n, w) in sorted(bins.items()):
                print("  bins", middle, left, right, "rows", n, "mass fraction", display(w/mass))
            for q, (partners, mids, scales) in sorted(rights.items()):
                print("  right mask", q, "distinct partners", len(partners),
                      "middle parents", "/".join(sorted(mids)),
                      "middle size bins", "/".join(map(str, sorted(scales))))
            for capacity in ("1", "tight"):
                archived = loads(zip_file.read(f"mu814-{label}-{capacity}.json"))
                assert F(archived["original_mass"]) == mass and archived["D"] == 512
                print("  archived R814 projected one-arm optimization, receiver factor",
                      archived["receiver_capacity_multiplier"])
                for result in archived["results"]:
                    lower, upper = F(result["lower"]), F(result["upper"])
                    assert 0 <= lower <= upper <= 1
                    print("   mode", result["mode"], "paid fraction", display(lower, upper),
                          "paid mass", display(mass*lower, mass*upper),
                          "tight source count", len(result["saturated_sources"]),
                          "tight receiver rows", result["saturated_owner_rows"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rounds", type=Path, required=True)
    args = parser.parse_args()
    print("Python", sys.version.replace("\n", " "), "executable", sys.executable)
    print("Exact integer/Fraction enclosures with", BITS, "dyadic bits for roots.")
    constants()
    positive_width()
    r814(args.rounds)
    print("PASS")


if __name__ == "__main__":
    main()
