from fractions import Fraction
from math import ceil, log, sqrt

def rational_bounds(n, k, epsilon, contact):
    # The true factor b_i is >= 4/7 on any axis and >= contact on k axes.
    lower_base = 1 - epsilon + epsilon * Fraction(4, 7)
    lower_contact = 1 - epsilon + epsilon * contact
    return lower_base ** (n - k) * lower_contact ** k

def threshold(n, kappa, epsilon):
    base = 1 - epsilon + epsilon / sqrt(3)
    contact = 1 - epsilon + epsilon * sqrt(n / (3 * kappa))
    return (log(n + 2) - n * log(base)) / (log(contact) - log(base))

lines = []
for n, epsilon, k in [(4096, Fraction(1, 128), 70), (65536, Fraction(1, 1024), 225)]:
    contact = n ** 0.5
    assert contact.is_integer()
    contact = int(contact)
    lower = rational_bounds(n, k, epsilon, contact)
    assert lower > n + 2
    lines.append(f"n={n}, K=1/3, epsilon={epsilon}, k={k}, "
                 f"exact product lower>N: {lower > n+2}, "
                 f"exact-product lower/N approx={float(lower/(n+2)):.6g}, "
                 f"exact theoretical threshold (float display)={threshold(n, 1/3, float(epsilon)):.6f}")
    # Synthetic p's satisfying the original padding; coarse 6n gate fails.
    # With n-k values p=1-1/(2n), b_i<1, so Σb_i ≤ n + k*contact.
    assert Fraction(1, 3*n) > Fraction(1, 32*n+1)
    assert n + k*contact < 6*n
    assert float(ceil(threshold(n, 1/3, float(epsilon)))) <= k

print("\n".join(lines))


def check_tilted_long_jumps():
    """Rational checks of the threshold record's conditional grid law."""
    from itertools import product
    from math import prod

    rho = Fraction(1, 8)
    gaps = (Fraction(1, 8), Fraction(1, 4), Fraction(3, 4), Fraction(1, 2))
    direct_total = expected_count = Fraction(0)
    for bits in product(range(2), repeat=4):
        mass = prod(rho*t/2 if bit else 1-t for bit, t in zip(bits, gaps, strict=True))
        direct_total += mass
        expected_count += sum(bits)*mass
    probabilities = [rho*t/(2*(1-t)+rho*t) for t in gaps]
    assert direct_total == prod(1-t+rho*t/2 for t in gaps)
    assert expected_count/direct_total == sum(probabilities)
    print("Conditional grid exact enumeration", direct_total, expected_count/direct_total)

    cases = (
        (4096, 4096, Fraction(1, 2), Fraction(1, 32)),
        (4096, 3072, Fraction(2, 3), Fraction(1, 32)),
        (65536, 65536, Fraction(1, 16), Fraction(1, 64)),
        (262144, 262144, Fraction(1, 8), Fraction(1, 64)),
    )
    for n, active, displacement, rho in cases:
        b = active*displacement
        k = int((rho*b)//4)
        p = rho*displacement/(2*(1-displacement)+rho*displacement)
        mean, variance = active*p, active*p*(1-p)
        fail = variance/(mean-k)**2
        assert k >= 1 and fail <= Fraction(1, 4)
        q = 2*rho
        excess = q**4/(1-2*q*q)
        v = (n//2)*excess
        assert n%2 == 0 and 0 <= v < 1
        # (1+x)^(n/2) is between 1+(n/2)x and its geometric majorant.
        low, high = (1+v)/(1<<k), 1/((1-v)*(1<<k))
        assert 0 < low <= high < Fraction(1, 4096)
        print("Long-jump profile", (n, active, displacement, rho), "k", k,
              "conditional mean", mean, "Chebyshev failure at most", fail,
              "tensor tail factor interval", low, high)
    print("PASS four-coordinate phase enumeration and four large-dimension gate certificates")

check_tilted_long_jumps()
