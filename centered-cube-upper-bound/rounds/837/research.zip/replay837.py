"""Replay the round-837 computations and preserve a path-independent transcript."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
from zipfile import BadZipFile, ZipFile


ROUND = 837
PRIOR_ARCHIVES = {
    "814": "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    "833": "8c37039dba896615b13e4de9c1bfe2a56ee8f539e192c11386285237f2537b17",
    "834": "15b8e65b789dbe30cd08ce0b376ae93fd19fa2341b895d15c50a2ed9cee284e8",
    "835": "b9d5caf5ecc41d12ec739e513e65d285e07da3109f0601c5f890335cd45a51c3",
    "836": "dee8408931ca89abfa189bea575fde535c8a7901c090c061c8ffc88d8055d89d",
}
CHECKS = {
    "kernelstudy.py": ("814",),
    "physical837.py": ("814", "833", "834", "835"),
    "gridnorm837.py": (),
    "check_masks837.py": (),
}
SCRIPTS = ("replay837.py", *CHECKS)
SETTINGS = {"PYTHONHASHSEED": "0", "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"}
LOG_HEADER = b"Round 837 computational verification\n"
ROUNDS_LABEL = "<rounds>"
RUN_VERSION = {"implementation": platform.python_implementation(),
               "version": platform.python_version()}


def digest(path):
    with path.open("rb") as source:
        return file_digest(source, "sha256").hexdigest()


def archive_paths(rounds):
    return {number: rounds / number / "research.zip" for number in PRIOR_ARCHIVES}


def verify_archives(paths):
    member_hashes = {}
    for number, expected in PRIOR_ARCHIVES.items():
        path = paths[number]
        with path.open("rb") as source:
            actual = file_digest(source, "sha256").hexdigest()
            if actual != expected:
                raise ValueError(f"R{number} archive SHA-256 mismatch: {actual}; expected {expected}")
            source.seek(0)
            with ZipFile(source) as archive:
                manifest = json.loads(archive.read("MANIFEST.json"))
                if manifest["round"] != int(number):
                    raise ValueError(f"R{number} manifest has the wrong round")
                members = manifest["members"]
                names = archive.namelist()
                if len(names) != len(set(names)) or set(names) != set(members) | {"MANIFEST.json"}:
                    raise ValueError(f"R{number} manifest does not match its ZIP members")
                for name, expected_hash in members.items():
                    if sha256(archive.read(name)).hexdigest() != expected_hash:
                        raise ValueError(f"R{number} member {name} failed SHA-256 validation")
                member_hashes[number] = members
    return member_hashes


def arguments(script, rounds):
    return ["--rounds", str(rounds)] if CHECKS[script] else []


def heading(script):
    return f"\n===== {script} =====\n".encode()


def scrub_paths(text, directory, rounds):
    prefixes = {
        os.fsencode(directory): b"<package>",
        os.fsencode(rounds): b"<rounds>",
        os.fsencode(sys.executable): b"<python>",
        os.fsencode(Path(sys.executable).resolve()): b"<python>",
    }
    for path in sorted(prefixes, key=len, reverse=True):
        text = text.replace(path, prefixes[path])
    return text


def run_check(script, directory, rounds):
    env = {key: value for key, value in os.environ.items() if not key.startswith("PYTHON")}
    result = subprocess.run(
        [sys.executable, "-B", "-s", script, *arguments(script, rounds)],
        cwd=directory,
        env={**env, **SETTINGS},
        capture_output=True,
        check=False,
    )
    return {
        "exit": result.returncode,
        "stdout": scrub_paths(result.stdout, directory, rounds),
        "stderr": scrub_paths(result.stderr, directory, rounds),
    }


def transcript(evidence, results):
    metadata = json.dumps(evidence, ensure_ascii=False, sort_keys=True).encode()
    sections = [LOG_HEADER, b"Evidence JSON: ", metadata, b"\n"]
    for script, result in zip(CHECKS, results, strict=True):
        sections.extend((heading(script), b"----- stdout -----\n", result["stdout"],
                         b"\n----- stderr -----\n", result["stderr"], b"\n"))
    sections.append(f"\nReplay status: {evidence['status']}\n".encode())
    return b"".join(sections)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rounds", type=Path, required=True, help="Directory containing the pinned rounds")
    parser.add_argument("--output", type=Path, help="Path for the transcript, defaults to stdout")
    args = parser.parse_args()
    directory = Path(__file__).resolve().parent
    rounds = args.rounds.resolve()
    paths = archive_paths(rounds)
    try:
        members = verify_archives(paths)
        hashes = {name: digest(directory / name) for name in SCRIPTS}
        protected = {*(path.resolve() for path in paths.values()),
                     *((directory / name).resolve() for name in (*SCRIPTS, "REPORT.tex", "MANIFEST.json"))}
        if args.output:
            same_file = args.output.exists() and any(
                path.exists() and args.output.samefile(path) for path in protected
            )
            if args.output.resolve() in protected or same_file:
                raise ValueError("the transcript must be distinct from all inputs")
        with ThreadPoolExecutor(max_workers=len(CHECKS)) as workers:
            pending = [workers.submit(run_check, script, directory, rounds) for script in CHECKS]
            results = [job.result() for job in pending]
        if any(digest(path) != PRIOR_ARCHIVES[number] for number, path in paths.items()):
            raise ValueError("a prior archive changed during replay")
        if any(digest(directory / name) != expected for name, expected in hashes.items()):
            raise ValueError("a replay script changed during replay")
    except (OSError, ValueError, KeyError, BadZipFile) as error:
        parser.error(str(error))

    runs = {}
    passed = True
    for script, result in zip(CHECKS, results, strict=True):
        run = {
            "arguments": arguments(script, ROUNDS_LABEL),
            "prior_rounds": list(CHECKS[script]),
            "script_sha256": hashes[script],
            "exit": result["exit"],
        }
        for channel in ("stdout", "stderr"):
            output = result[channel]
            run[f"{channel}_bytes"] = len(output)
            run[f"{channel}_sha256"] = sha256(output).hexdigest()
        runs[script] = run
        passed &= result["exit"] == 0 and bool(result["stdout"]) and not result["stderr"]

    evidence = {
        "round": ROUND,
        "status": "PASS" if passed else "FAIL",
        "python": RUN_VERSION,
        "dependencies": {},
        "settings": SETTINGS,
        "inputs": PRIOR_ARCHIVES,
        "input_members": members,
        "replay_sha256": hashes["replay837.py"],
        "individual_runs": runs,
    }
    log = transcript(evidence, results)
    if args.output:
        args.output.write_bytes(log)
    else:
        sys.stdout.buffer.write(log)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
