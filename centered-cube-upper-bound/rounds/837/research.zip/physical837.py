"""Fixed-phase tensor prices on the two R814 positive-width, four-dimensional fixtures.

Every selected complete arm stays in a real source box and retains its old
receiver law. The grid side is the archived a_D. Both fine labels -1 and 0
belong to the outer cell [-a_D,a_D) in every coordinate. Kernel K/P prices
one fixed physical phase. No pointwise inequality P <= K is used. The
random-shift mixture identity is a separate, general statement.

Each of the two absolute bands gets 1/2 of an eligible arm's budget.
The scores use the fixed band totals X,Y of the true single-arm references.
For u=3/4, score^4=(d_t m_t rho^h / (4 C P))^4/(X Y x_I y_J).
Here h is Hamming distance between actual sign cells and C=(1+rho^2)^2
follows from Young on the four binary coordinate alphabets. For the
endpoint u=1,rho=1, score=d_t m_t/(4 P sqrt(X Y)), with constant 1.
The printed score intervals have outward endpoints. Gate decisions compare
exact rational fourth-power bounds with 1. Positive-width rectangles give
certified subflow. Both archived fixtures have empty high-dimensional gates.
"""

import argparse
from collections import defaultdict
from contextlib import redirect_stdout
from fractions import Fraction as F
from hashlib import sha256
from math import isqrt, prod
from pathlib import Path
from platform import python_version
from zipfile import ZipFile


DEFAULT_ROUNDS = Path(
    "/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/"
    "centered-cube-upper-bound/rounds"
)
ARCHIVE_PINS = {
    814: "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    833: "8c37039dba896615b13e4de9c1bfe2a56ee8f539e192c11386285237f2537b17",
    834: "15b8e65b789dbe30cd08ce0b376ae93fd19fa2341b895d15c50a2ed9cee284e8",
    835: "b9d5caf5ecc41d12ec739e513e65d285e07da3109f0601c5f890335cd45a51c3",
}
MEMBER_PINS = {
    (814, "comb811.py"): "f573f0725c3b1364a5e600123d373fb2d737c6194718f20e967b52ba81dd2837",
    (814, "comb814-rebuilt.json"): "d0e3ed7f50bc7f1d02df4c50b2a669b73938da862359360efaa2234932a031b0",
    (833, "row833.py"): "0ace85f5a833ebf75bcc06081b04091dd3922f95f66cf5f8ce40a2d5f236686f",
    (834, "potential834.py"): "4ad755dd8b16728160326b5e5d680e7c9666580561c6a7da5d3921eac8c0fd6f",
    (835, "traffic835.py"): "cff81eadbdbfd3e65fa8f95b3a765d15ef6e369faa28a6ca5fd22eca82a3a6bc",
}
POLICIES = ("hard", "soft", "endpoint")


def verified_inputs(rounds):
    paths = {}
    members = {}
    for number, expected in ARCHIVE_PINS.items():
        path = rounds / str(number) / "research.zip"
        digest = sha256(path.read_bytes()).hexdigest()
        assert digest == expected, (path, digest)
        print("archive", number, digest)
        paths[number] = path
        with ZipFile(path) as zip_file:
            for (item_number, member), pin in MEMBER_PINS.items():
                if item_number == number:
                    contents = zip_file.read(member)
                    assert sha256(contents).hexdigest() == pin, member
                    print("member", number, member, pin)
                    members[member] = contents
    return paths, members


def load_module(data, member):
    namespace = {"__name__": "r837_pinned_" + member.removesuffix(".py")}
    exec(compile(data[member], member, "exec"), namespace)
    return namespace


def rational_string(value, digits, round_up):
    unit = 10**digits
    n = ((value.numerator*unit + value.denominator-1) // value.denominator
         if round_up else value.numerator*unit // value.denominator)
    integer, fraction = divmod(n, unit)
    return f"{integer}.{fraction:0{digits}d}"


def show(lo, hi, digits=12):
    assert 0 <= lo <= hi
    return f"[{rational_string(lo,digits,False)},{rational_string(hi,digits,True)}]"


def fourth_root_bounds(x):
    unit = 1 << 76
    k = isqrt(isqrt((x.numerator*unit**4) // x.denominator))
    lo = F(k, unit)
    hi = lo if lo**4 == x else F(k+1, unit)
    assert lo**4 <= x <= hi**4
    return lo, hi


def physical_label(box, min_side):
    label = []
    for lo, hi in box:
        # The endpoints on 0 have zero Lebesgue and source measure.
        assert -min_side < lo < hi < min_side
        assert hi <= 0 or lo >= 0
        label.append(-1 if hi <= 0 else 0)
    return tuple(label)


def overlap_bounds(left, right, scale):
    side_lo, side_hi = scale
    min_gaps, max_gaps = [], []
    for (a, b), (c, d) in zip(left, right, strict=True):
        min_gaps.append(max(F(0), a-d, c-b))
        max_gaps.append(max(abs(a-d), abs(b-c)))
    lo = prod(max(F(0), 1-g/side_lo) for g in max_gaps)
    hi = prod(max(F(0), 1-g/side_hi) for g in min_gaps)
    assert 0 < lo <= hi <= 1
    return lo, hi


def score_power_intervals(degree_mass, distance, X, Y, x, y, p_lo, p_hi):
    result = {}
    for policy, rho in (("hard", F(0)), ("soft", F(1, 8))):
        constant = (1+rho**2)**2
        # On the hard diagonal rho^0=1 also for rho=0.
        score_numerator = (degree_mass * rho**distance / (4*constant))**4
        denominator = X*Y*x*y
        result[policy] = (score_numerator / (denominator*p_hi**4),
                          score_numerator / (denominator*p_lo**4))
    endpoint_numerator = (degree_mass/4)**4
    result["endpoint"] = (endpoint_numerator / ((X*Y)**2*p_hi**4),
                          endpoint_numerator / ((X*Y)**2*p_lo**4))
    return result


def check_case(name, stage, prior, geo, row_tools):
    rows, cubes, owners, masses, prices, bits, source = prior["reconstruct"](stage)
    assert len(rows) == 230 and len(owners) == len(cubes)
    total = sum(rows.values())
    own_arms = {x for _, x, right in rows}
    assert own_arms == {right for _, x, right in rows}
    active = {mask for old, mask in own_arms}
    boxes = prior["source_atoms"](cubes, stage["density"], source, active,
                                  row_tools["axis_intervals"])
    best = {mask: max(v, key=lambda block: block[1]) for mask, v in boxes.items()}
    degree = {t: F(stage["degrees"][t]["full_d"]) for t in stage["middle_labels"]}
    assert max(degree.values()) < 1 and stage["dimension"] == 4
    assert all(masses[t] == prod(b-a for a, b in cubes[t]) for t in degree)
    bands = {t: geo["bin_volume"](masses[t]) for t in degree}
    assert set(bands.values()) == {6, 7}
    sides = {d: geo["extra_arrival_scale"](d) for d in set(bands.values())}
    min_side = min(s[0] for s in sides.values())
    labels = {mask: physical_label(box, min_side) for mask, (box, weight) in best.items()}
    print("fixture", name, "real middle powers of two", sorted(bands.items()),
          "complete degrees", sorted(degree.items()))
    print("proved all selected price boxes occupy the single outer cell [-a_D,a_D)^4;",
          "all four inner labels lie in {-1,0}; fixed phase 0")
    print("full mother / source-95 mother", total,
          sum(weight for (_, left, right), weight in rows.items() if right[1] == 95))
    for restrict_right in (False, True):
        case = "right-95" if restrict_right else "all-right"
        x_cells, y_cells = defaultdict(F), defaultdict(F)
        for u, z in own_arms:
            # Integral of Unif(E_u) is 1. True source mass is multiplied by
            # j_u/m_u and by the allocation 1/2 to the prospective band.
            assert bits[u] & z
            amount = prices[u]*best[z][1] / (2*masses[u])
            x_cells[labels[z]] += amount
            if not restrict_right or z == 95:
                y_cells[labels[z]] += amount
        X, Y = sum(x_cells.values()), sum(y_cells.values())
        retained = {(t, left, right): w for (t, left, right), w in rows.items()
                    if not restrict_right or right[1] == 95}
        mother = sum(retained.values())
        assert len(retained) == (58 if restrict_right else 230)
        print("case", name, case, "rows", len(retained), "band_reference_X_Y", X, Y)
        paid = {p: set() for p in POLICIES}
        integrals = {p: [F(0), F(0)] for p in POLICIES}
        cross = set()
        micro_mass = {}
        for row_id, row_weight in sorted(retained.items()):
            t, (u, z), (g, q) = row_id
            left, wz = best[z]
            right, wq = best[q]
            weight = row_weight*wz*wq / (source[z]*source[q])
            assert 0 < weight <= row_weight
            micro_mass[row_id] = weight
            distance = sum(a != b for a, b in zip(labels[z], labels[q], strict=True))
            if distance:
                cross.add(row_id)
            lo, hi = overlap_bounds(left, right, sides[bands[t]])
            thresholds = score_power_intervals(degree[t]*masses[t], distance, X, Y,
                                               x_cells[labels[z]], y_cells[labels[q]], lo, hi)
            printed = []
            for policy in POLICIES:
                lower_power, upper_power = thresholds[policy]
                lower = fourth_root_bounds(lower_power)[0]
                upper = fourth_root_bounds(upper_power)[1]
                integrals[policy][0] += lower*weight
                integrals[policy][1] += upper*weight
                if lower_power >= 1:
                    paid[policy].add(row_id)
                    status = "paid"
                elif upper_power == 0:
                    assert policy == "hard" and distance > 0
                    status = "geometric-zero"
                else:
                    # An ambiguous interval cannot be counted as paid or as zero.
                    raise AssertionError((row_id, policy, lower_power, upper_power))
                printed.append(policy+"="+show(lower, upper, 6)+"/"+status)
            print("row", t, u, z, g, q, "log2D", bands[t], "different-axes", distance,
                  "mass/mother", show(weight/mother, weight/mother, 15), *printed)
        count_cross = 10 if restrict_right else 70
        assert len(cross) == count_cross and paid["hard"] == retained.keys()-cross
        assert paid["soft"] == set(retained) and paid["endpoint"] == set(retained)
        common = cross & paid["soft"] & paid["endpoint"]
        assert common == cross
        for p in POLICIES:
            mass = sum(micro_mass[k] for k in paid[p])
            lo, hi = integrals[p]
            print("summary", name, case, p, "qualified", len(paid[p]),
                  "fraction", show(mass/mother, mass/mother, 15),
                  "score-integral/mother", show(lo/mother, hi/mother))
        cross_mass = sum(micro_mass[k] for k in cross)
        print("comparison", name, case, "cross", len(cross), "soft_endpoint_intersection",
              len(common), "cross-mass/mother", show(cross_mass/mother, cross_mass/mother, 15),
              "cross-middle-fathers", sorted({t for t, l, r in cross}),
              "cross-bands", sorted({bands[t] for t, l, r in cross}),
              "cross-z-masks", sorted({l[1] for t, l, r in cross}))
        assert cross_mass > 0
    print("outside selected positive-width subblocks untested; original R813 high-degree gate empty")


def run(rounds):
    print("Python", python_version(), "exact fractions, fourth-power decisions and directed display")
    paths, data = verified_inputs(rounds)
    prior = load_module(data, "potential834.py")
    geo = load_module(data, "traffic835.py")
    fixtures, row_tools = prior["load_inputs"](paths[814], paths[833])
    for name, stage in fixtures:
        check_case(name, stage, prior, geo, row_tools)
    print("PASS fixed-phase soft, hard and u=1 endpoint, same archive rows and shared reference budgets")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rounds", type=Path, default=DEFAULT_ROUNDS)
    parser.add_argument("--output", type=Path, help="Write the full row certificate to this path.")
    args = parser.parse_args()
    if args.output:
        with args.output.open("w", encoding="utf-8") as output, redirect_stdout(output):
            run(args.rounds)
    else:
        run(args.rounds)


if __name__ == "__main__":
    main()
