"""Exact random-grid geometry and certified U=3/4 score on a continuous input."""

from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction as F
from itertools import combinations_with_replacement, product
from math import isqrt, prod
import sys


BITS = 80
RHO = F(1, 4)
EPSILON = F(1, 65536)
D_VALUES = (32, 64)
PACKET_DISTANCE = F(64, 21)
SOURCE_SCALE = F(24)
C75_SQUARED = F(225, 224)
BAND_WEIGHT = F(1, 2)
THRESHOLDS = (F(1027, 1000), F(81, 40))


def root_bounds(x, degree):
    assert x >= 0 and degree in (2, 4)
    z = (x.numerator << (BITS * degree)) // x.denominator
    for _ in range(degree.bit_length() - 1):
        z = isqrt(z)
    lo = F(z, 1 << BITS)
    hi = lo if lo**degree == x else F(z + 1, 1 << BITS)
    assert lo**degree <= x <= hi**degree
    return lo, hi


def output(bounds):
    lo, hi = bounds
    assert lo <= hi
    with localcontext() as ctx:
        ctx.prec = 17
        ctx.rounding = ROUND_FLOOR
        lo = Decimal(lo.numerator) / Decimal(lo.denominator)
        ctx.rounding = ROUND_CEILING
        hi = Decimal(hi.numerator) / Decimal(hi.denominator)
    return f"[{lo}, {hi}]"


def axis_slices(points, a):
    period = 2*a
    cuts = sorted({F(0), period} | {(x + j*a) % period for x in points for j in (0, 1)})
    return zip(cuts[:-1], cuts[1:], strict=True)


def fine_index(x, shift, a):
    return (x - shift) // a


def partition_events(left, right, a):
    width = [F(0), F(0)]
    outer = F(0)
    for lo, hi in axis_slices(left + right, a):
        s = (lo + hi)/2
        li, ri = [{fine_index(x, s, a) for x in arm} for arm in (left, right)]
        if len({i//2 for i in li | ri}) != 1:
            continue
        outer += hi - lo
        if len(li) == len(ri) == 1:
            width[int(li != ri)] += hi - lo
    return outer/(2*a), width[0]/(2*a), width[1]/(2*a)


def closed_events(left, right, a):
    l, r = sorted([(min(left), max(left)), (min(right), max(right))])
    span = max(l[1], r[1]) - l[0]
    outer = max(F(0), 1 - span/(2*a))
    same = max(F(0), 1 - span/a)
    split_width = max(F(0), min(r[0], l[0] + a) - max(l[1], r[1] - a))
    return outer, same, split_width/(2*a)


def verify_phase_formula():
    xs = tuple(F(k, 4) for k in (-10, -7, -4, -2, 0, 1, 3, 4, 6, 7, 8, 9))
    groups = sorted(set([tuple(pair) for pair in combinations_with_replacement(xs, 2)]
                        + [xs[:4], xs[2:8], xs[1:6], xs[4:10], xs[-4:]]))
    rhos = (F(0), F(1, 16), F(1, 4), F(1))
    span_cases = [0, 0, 0]
    shape_cases = {"proper overlap": 0, "contain": 0, "touch": 0, "gap": 0}
    for a, left, right in product((F(1), F(7, 4)), groups, groups):
        lo, hi = sorted([(min(left), max(left)), (min(right), max(right))])
        span = max(lo[1], hi[1]) - lo[0]
        span_cases[0 if span < a else 1 if span < 2*a else 2] += 1
        shape = ("gap" if lo[1] < hi[0] else "touch" if lo[1] == hi[0]
                 else "contain" if hi[1] <= lo[1] else "proper overlap")
        shape_cases[shape] += 1
        actual = partition_events(left, right, a)
        expected = closed_events(left, right, a)
        assert actual == expected
        assert 0 <= expected[1] + expected[2] <= expected[0] <= 1
        for rho in rhos:
            exact = actual[1] + rho*actual[2]
            assert exact == expected[1] + rho*expected[2]
            if span < a:
                gap = max(F(0), hi[0] - lo[1])
                assert exact == 1 - span/a + rho*gap/(2*a)
    assert min(span_cases) > 0 and min(shape_cases.values()) > 0
    print("Exact phase tests:", sum(span_cases), "rho values", rhos)
    print("  span ranges [0,a), [a,2a), [2a,infty):", span_cases)
    print("  shape counts:", shape_cases)


@dataclass(frozen=True)
class Packet:
    lo: F
    hi: F
    mass: F

    def on(self, lo, hi):
        return self.mass * max(F(0), min(self.hi, hi) - max(self.lo, lo))/(self.hi - self.lo)


def packet(at, mass):
    return Packet(at, at + EPSILON, SOURCE_SCALE*mass)


def source_input():
    e, d = EPSILON, PACKET_DISTANCE
    left = (packet(F(0), F(1, 50)), packet(2*e, F(1, 50)), packet(d, F(24, 25)))
    right = (packet(4*e, F(24, 25)), packet(d + 2*e, F(1, 25)))
    filler = Packet(F(49), F(49)+e, F(48))
    packs = sorted((*left, *right, filler), key=lambda p: p.lo)
    assert all(p.hi < q.lo for p, q in zip(packs[:-1], packs[1:], strict=True))
    assert sum(p.mass for p in left) == sum(p.mass for p in right) == SOURCE_SCALE
    roots = ((F(1, 4), F(1, 2), F(24)), (F(2), F(5, 2), F(48)))
    for j, (lo, hi, radius) in enumerate(roots):
        assert 0 < left[1].hi < lo < hi < right[1].lo
        assert hi - radius < packs[0].lo
        if j == 0:
            assert lo + radius > packs[-2].hi
            assert packs[-1].lo - hi > 48
        else:
            assert lo + radius > packs[-1].hi
        m = F(2)*radius
        assert D_VALUES[j] <= m < 2*D_VALUES[j]
    assert roots[0][1] < roots[1][0]
    return left, right, filler, roots


def masses(source, i, width, shift):
    lo, hi = shift + i*width, shift + (i + 1)*width
    return sum(p.on(lo, hi) for p in source)


def den_range(left, right, li, ri, a, lo, hi):
    lows, highs = [], []
    for support, index, width in ((left, li//2, 2*a), (right, ri//2, 2*a),
                                  (left, li, a), (right, ri, a)):
        first, last = masses(support, index, width, lo), masses(support, index, width, hi)
        lows.append(min(first, last))
        highs.append(max(first, last))
    assert min(lows) > 0
    return lows, highs


def integrate(left, right, lp, rp, a):
    points = tuple(x for p in left + right for x in (p.lo, p.hi))
    totals = {key: [F(0), F(0)] for key in ("u75", "half0", "half1", "one")}
    bad_phase = F(0)
    for lo, hi in axis_slices(points, a):
        phase = (lo + hi)/2
        part = (hi - lo)/(2*a)
        li, ri = fine_index(lp.lo, phase, a), fine_index(rp.lo, phase, a)
        if li != fine_index(lp.hi, phase, a) or ri != fine_index(rp.hi, phase, a):
            bad_phase += part
            continue
        if li//2 != ri//2:
            continue
        g = int(li != ri)
        lows, highs = den_range(left, right, li, ri, a, lo, hi)
        den75 = C75_SQUARED**2
        for key, k, low, high, coefficient in (
            ("u75", 4, den75*prod(lows), den75*prod(highs), RHO**g),
            (f"half{g}", 2, prod(lows[2:]), prod(highs[2:]), F(1)),
            ("one", 2, prod(lows[:2]), prod(highs[:2]), F(1)),
        ):
            lower, _ = root_bounds(1/high, k)
            _, upper = root_bounds(1/low, k)
            totals[key][0] += coefficient*part*lower
            totals[key][1] += coefficient*part*upper
    assert 0 <= lp.lo < lp.hi < rp.lo < rp.hi < a
    assert lp.hi - lp.lo == rp.hi - rp.lo == EPSILON
    assert bad_phase == 2*EPSILON/a
    # These bad phase intervals each cut just one packet. If the boundary
    # sits at theta and the fixed tested point at f, in relative packet
    # coordinates, that point lies in its fragment of mass fraction
    # 1-theta for theta < f, and theta for theta > f. Integrating the
    # inverse square root of the fraction gives 4-2*(sqrt(f)+sqrt(1-f))
    # <= 2. The other packet is complete, and each coarse mass covers the
    # tested fine mass. Thus the error bound is uniform in both tested
    # points and in rho, including the strongest u=1 outer-only mask.
    _, upper_bound = root_bounds(1/(lp.mass*rp.mass), 2)
    error = 2*bad_phase*upper_bound
    mid = totals["u75"][0], totals["u75"][1] + error
    half_same = totals["half0"][0], totals["half0"][1] + error
    half_split = totals["half1"][0], totals["half1"][1] + error
    one = totals["one"][0], totals["one"][1] + error
    half_quarter = ((half_same[0] + RHO*half_split[0])/(1 + RHO),
                    (half_same[1] + RHO*half_split[1])/(1 + RHO))
    # Half-score at rho = (1+rho)^(-1)*(same + rho*split).
    # This certifies the benchmark optimized over all rho in [0,1].
    assert half_same[0] > half_split[1]
    assert mid[0] > max(half_same[1], one[1])
    # For a full-span group at u75 and u1/2, bad phases make no
    # contribution. For its broad u1 comparison the above bound still holds.
    assert totals["u75"][0] > max(totals["half0"][1], one[1])
    return {"u=3/4 rho=1/4": mid, "u=1/2 optimal rho=0": half_same,
            "u=1/2 rho=1/4": half_quarter, "u=1 rho=1 outer-only": one}, error, bad_phase


def ratio(x, y):
    assert 0 < y[0] <= y[1]
    return x[0]/y[1], x[1]/y[0]


def verify_scores():
    left, right, filler, roots = source_input()
    assert len(D_VALUES) * BAND_WEIGHT == 1
    print("Exact L1 packets, tags (lo,hi,mass):", left, right, "filler", filler)
    print("lambda=1, true cores (lo,hi,radius)", roots)
    print("uniform density in each packet; no atom; actual unweighted source totals 24 and 24")
    print("each of the two bands gets weight 1/2 on each side; weighted source totals 12 and 12")
    print("P(y,q)=1-(q-y)/a on tested pairs; weighted score numerator m_x*W_left*W_right/P")
    print("uniform pointwise score enclosures on each full positive tag packet product")
    print("integration d_tau=dx d_nu_left d_nu_right/m_x^2 over disjoint receiver pieces")
    weighted = [tuple(Packet(p.lo, p.hi, p.mass*BAND_WEIGHT) for p in side)
                for side in (left, right)]
    pooled = {}
    full_tau = F(0)
    common_weights = tuple(BAND_WEIGHT/v for v in THRESHOLDS)
    assert sum(common_weights) <= 1
    natural_paid = {key: F(0) for key in ("u75", "half", "one")}
    for D, (lo, hi, radius), threshold in zip(D_VALUES, roots, THRESHOLDS, strict=True):
        a, m_x = F(2*D), 2*radius
        core_midpoint = (lo + hi)/2
        receiver_pieces = ((lo, core_midpoint), (core_midpoint, hi))
        band_tau = F(0)
        for index, (xlo, xhi) in enumerate(receiver_pieces):
            lp, rp = left[index], right[-1]
            bounds, error, bad = integrate(*weighted, weighted[0][index], weighted[1][-1], a)
            p_lo = 1-(rp.hi-lp.lo)/a
            p_hi = 1-(rp.lo-lp.hi)/a
            assert 0 < p_lo <= p_hi < 1
            numerator = m_x*BAND_WEIGHT**2
            scores = {key: (numerator*v[0]/p_hi, numerator*v[1]/p_lo)
                      for key, v in bounds.items()}
            tau_mass = (xhi - xlo)*lp.mass*rp.mass/m_x**2
            full_tau += tau_mass
            band_tau += tau_mass
            print("D", D, "a", a, "m_x", m_x, "left packet", index+1,
                  "receiver", (xlo, xhi), "tau", tau_mass)
            print("  P bounds", output((p_lo, p_hi)), "bad phase measure", bad,
                  "absolute bad phase score <=", output((0, numerator*error/p_lo)))
            for label, score in scores.items():
                print(" ", label, output(score))
                use = pooled.setdefault(label, [F(0), F(0)])
                use[0] += score[0]*tau_mass
                use[1] += score[1]*tau_mass
            mid, half, one = (scores[k] for k in ("u=3/4 rho=1/4", "u=1/2 optimal rho=0",
                                                "u=1 rho=1 outer-only"))
            assert max(half[1], one[1]) < threshold < mid[0]
            # On a given band, rescaling both endpoint weights by c multiplies
            # both the local coarse/fine masses by c and every score by c.
            scale = common_weights[D_VALUES.index(D)] / BAND_WEIGHT
            assert mid[0]*scale > 1 > max(half[1], one[1])*scale
            natural_paid["u75"] += tau_mass

            print("  ratios to strongest u=1/2 and u=1", output(ratio(mid, half)), output(ratio(mid, one)))
        print("  threshold", threshold, "tau covered: u=3/4", band_tau,
              "out of", band_tau, "; u=1/2 optimal and u=1 outer-only 0")
    print("full tested tau", full_tau, output((full_tau, full_tau)))
    print("COMMON NATURAL GATE", D_VALUES, common_weights, "budget", sum(common_weights),
          "u75 / best half / strong one paid original tau at 1:", natural_paid)
    assert natural_paid == {"u75": full_tau, "half": 0, "one": 0}

    print("pooled integral of weighted score against original tau on these four records:")
    for key, result in pooled.items():
        print(" ", key, output(result))
    mid, half, one = (pooled[k] for k in ("u=3/4 rho=1/4", "u=1/2 optimal rho=0",
                                         "u=1 rho=1 outer-only"))
    assert mid[0] > max(half[1], one[1])
    print("  pooled strict ratios", output(ratio(mid, half)), output(ratio(mid, one)))
    print("Scope: this continuous two-true-root score model only; no R813 history test.")


def main():
    print("Python", sys.version.split()[0], sys.executable, "dyadic bits", BITS)
    verify_phase_formula()
    verify_scores()
    print("PASS")


if __name__ == "__main__":
    main()
