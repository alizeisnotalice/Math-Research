"""Continuous two-source overlap-lens costs for the two positive R814 fixtures."""

import argparse
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from itertools import product
from pathlib import Path
from platform import python_version
from zipfile import ZipFile


ROUNDS = Path(
    "/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/"
    "centered-cube-upper-bound/rounds"
)
PINS = {
    814: "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    832: "3eef2e83aab159531aa5b1049715568779e8c599998dde494ce0ea0e238c0303",
    833: "8c37039dba896615b13e4de9c1bfe2a56ee8f539e192c11386285237f2537b17",
}
FLOOR = Context(prec=63, rounding=ROUND_FLOOR)
CEIL = Context(prec=63, rounding=ROUND_CEILING)
NEAREST = Context(prec=63, rounding=ROUND_HALF_EVEN)
ZERO = F(0), F(0)


def check_archive(path, round_number):
    digest = sha256(path.read_bytes()).hexdigest()
    assert digest == PINS[round_number]
    print("ARCHIVE SHA256", round_number, digest)


def archive_module(path, member):
    with ZipFile(path) as archive:
        code = archive.read(member)
    print("MEMBER SHA256", member, sha256(code).hexdigest())
    namespace = {"__name__": "archive_" + member.removesuffix(".py")}
    exec(compile(code, member, "exec"), namespace)
    return namespace


@cache
def log(x):
    assert x > 0
    if x == 1:
        return ZERO
    a, b = Decimal(x.numerator), Decimal(x.denominator)
    lo = NEAREST.ln(FLOOR.divide(a, b))
    hi = NEAREST.ln(CEIL.divide(a, b))
    return F(FLOOR.next_minus(lo)), F(CEIL.next_plus(hi))


def add(a, b):
    return a[0] + b[0], a[1] + b[1]


def sub(a, b):
    return a[0] - b[1], a[1] - b[0]


def mul(x, a):
    return (x * a[0], x * a[1]) if x >= 0 else (x * a[1], x * a[0])


def point(x):
    return x, x


def div(a, b):
    assert a[0] >= 0 and b[0] > 0
    return a[0] / b[1], a[1] / b[0]


def output(a, digits=18):
    unit = 10**digits
    lo, hi = a
    low = lo.numerator * unit // lo.denominator
    high = -((-hi.numerator * unit) // hi.denominator)

    def text(x):
        whole, fract = divmod(abs(x), unit)
        sign = "-" if x < 0 else ""
        return f"{sign}{whole}.{fract:0{digits}d}"

    return f"[{text(low)}, {text(high)}]"


def score(distance, enlarged_side):
    assert 0 <= distance < enlarged_side
    return mul(F(-1), log(1 - distance / enlarged_side))


@cache
def phi_primitive(distance, enlarged_side):
    """Even second primitive of -log(1-|x|/B), zero value and slope at zero."""
    x = distance / enlarged_side
    assert 0 <= x < 1
    r = 1 - x
    principal = F(3, 4) * r**2 + x - F(3, 4)
    return mul(enlarged_side**2, add(point(principal), mul(-r**2 / 2, log(r))))


@cache
def rectangle(ql, qh, zl, zh, enlarged_side):
    # For integrands f(|z-q|) this signed four-corner sum of the even
    # second primitive is exactly the rectangle integral.
    d = tuple(abs(v) for v in (zh - ql, zl - qh, zl - ql, zh - qh))
    a, b, c, e = (phi_primitive(x, enlarged_side) for x in d)
    phi = sub(add(a, b), add(c, e))
    linear = (d[0]**3 + d[1]**3 - d[2]**3 - d[3]**3) / (6 * enlarged_side)
    area = (qh - ql) * (zh - zl)
    assert 0 <= linear <= area and phi[1] >= linear
    return (max(phi[0], linear), phi[1]), linear


def volume_bin_gate(n):
    return add(log(F(512)), add(mul(F(n), log(F(3))), mul(F(8), log(F(n + 2)))))


def real_fixture(name, stage, prior, row):
    cubes, sides, _, _, _, rows = prior["verified_rows"](stage)
    mu = {c["mask"]: F(c["mass"]) for c in stage["cells"] if F(c["mass"]) > 0}
    active = {z for _, (_, z), _ in rows} | {q for _, _, (_, q) in rows}
    marginal = row["marginals"](tuple(cubes.values()), stage["density"], mu, active)
    n = stage["dimension"]
    assert n == 4 and len(rows) == 230
    total = sum(rows.values())
    max_pointwise = mul(F(n), log(1 + F(n, 2)))
    assert max_pointwise[1] < min(mul(F(n), log(F(5)))[0], volume_bin_gate(n)[0])

    @cache
    def pair(t, z, q):
        enlarged = (1 + F(2, n)) * sides[t]
        phi, linear = ZERO, F(0)
        for axis, (a, b) in enumerate(cubes[t]):
            for (ql, qh, qd), (zl, zh, zd) in product(marginal[axis, q], marginal[axis, z]):
                assert a <= ql < qh <= b and a <= zl < zh <= b
                box_phi, box_linear = rectangle(ql, qh, zl, zh, enlarged)
                weight = qd * zd
                phi = add(phi, mul(weight, box_phi))
                linear += weight * box_linear
        assert phi[0] >= linear and phi[1] <= max_pointwise[1]
        return phi, linear

    total_phi, total_linear = ZERO, F(0)
    largest = None
    for (t, (u, z), (g, q)), weight in sorted(rows.items()):
        phi, linear = pair(t, z, q)
        premium = sub(phi, point(linear))
        total_phi = add(total_phi, mul(weight, phi))
        total_linear += weight * linear
        candidate = (premium[0], t, u, z, g, q)
        if largest is None or candidate > largest[0]:
            largest = candidate, phi, linear, premium
    mean_phi = mul(1 / total, total_phi)
    mean_linear = point(total_linear / total)
    premium = sub(mean_phi, mean_linear)
    assert 0 < premium[0] <= premium[1] and premium[1] - premium[0] < F(1, 10**52)
    print("REAL FIXTURE", name, "original rows", len(rows), "mass", total)
    print("REAL MEANS Phi", output(mean_phi, 30), "linear", output(mean_linear, 30),
          "increment", output(premium, 30), "relative increment", output(div(premium, mean_linear)))
    key, phi, linear, premium = largest
    print("REAL ROW EXAMPLE", key[1:], "Phi", output(phi), "linear", output(point(linear)),
          "increment", output(premium))
    print("REAL GEOMETRIC CAP Phi", output(max_pointwise), "gate at C=0",
          output(mul(F(n), log(F(5)))), "passing original mass fraction for C>=0", 0)
    print("REAL VOLUME-BIN GATE", output(volume_bin_gate(n)), "all rejected")


def synthetic():
    print("SYNTHETIC SCOPE positive-width source boxes and one formal geometric record;"
          " no R813 history, jump, or degree gates are imposed")
    for n in (16, 256, 4096, 65536):
        B = 1 + F(2, n)
        n_log5 = mul(F(n), log(F(5)))
        logn = log(F(n + 2))
        sharp = volume_bin_gate(n)
        print("SYNTHETIC DIMENSION", n, "actual side", 1, "enlarged side", B,
              "volume-bin gate", output(sharp, 12))
        profiles = (
            ("low", n, F(1, 2)),
            ("medium", 3*n//4, F(9, 10)),
            ("strong", 7*n//8, 1 - F(1, 4*n)),
            ("sparse strong", n//4, 1 - F(1, 4*n)),
        )
        for name, k, gap in profiles:
            eta = min(F(1, 2000), (1 - gap) / 8)
            # z is centered at -gap/2 on all axes. q is centered at
            # +gap/2 on flipped axes and at -gap/2 on the others.
            assert 0 < eta < gap/4 and gap/2 + eta < F(1, 2)
            # All q,z values in these two full-volume boxes are covered
            # by the coordinate bounds, with no center-point substitution.
            flip_lo = score(gap - 2*eta, B)[0]
            flip_hi = score(gap + 2*eta, B)[1]
            stay_hi = score(2*eta, B)[1]
            phi = k * flip_lo, k * flip_hi + (n-k) * stay_hi
            linear = k * (gap - 2*eta) / B, (k * (gap + 2*eta) + (n-k) * 2*eta) / B
            assert 0 < linear[0] <= linear[1] < phi[0] <= phi[1]
            excess = sub(phi, n_log5)
            if excess[0] >= 0:
                capacity = div(excess, logn)
            elif excess[1] <= 0:
                capacity = mul(F(-1), div(mul(F(-1), excess), logn))
            else:
                capacity = excess[0] / logn[0], excess[1] / logn[0]
            paid = {}
            for C in (0, 1, 4, 16):
                hurdle = add(n_log5, mul(F(C), logn))
                paid[C] = 1 if phi[0] > hurdle[1] else 0 if phi[1] <= hurdle[0] else "[0,1]"
            sharp_result = ("all pass" if phi[0] >= sharp[1] else
                            "all rejected" if phi[1] < sharp[0] else "undecided")
            hurdle = add(n_log5, logn)
            min_possible = max(0, (hurdle[0] - n * stay_hi) // (flip_hi - stay_hi) + 1)
            min_certified = hurdle[1] // flip_lo + 1
            assert min_possible <= min_certified
            print("SYNTHETIC", name, "k", k, "gap", gap, "halfwidth", eta,
                  "Phi/n", output(mul(F(1, n), phi), 12),
                  "linear/n", output(mul(F(1, n), linear), 12),
                  "(Phi - n ln5) / ln(n+2)", output(capacity, 12),
                  "volume-bin gate result", sharp_result,
                  "fraction certified at C=0,1,4,16", paid,
                  "C=1 minimum necessary / sufficient k (above n means unavailable)",
                  (min_possible, min_certified))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for round_number in PINS:
        parser.add_argument(f"--archive-{round_number}", metavar="ZIP", type=Path,
                            default=ROUNDS / f"{round_number}/research.zip")
    args = parser.parse_args()
    print("PYTHON", python_version(), "63-digit directed Decimal log, exact Fraction weights")
    for round_number in PINS:
        check_archive(getattr(args, f"archive_{round_number}"), round_number)
    prior = archive_module(args.archive_832, "foot832.py")
    row = archive_module(args.archive_833, "row833.py")
    assert log(F(2))[0] > F(2, 3)
    assert phi_primitive(F(0), F(1)) == ZERO
    _phi, linear = rectangle(F(0), F(1), F(0), F(1), F(2))
    assert linear == F(1, 6) and _phi[0] > linear
    for name, stage in prior["fixtures"](args.archive_814):
        real_fixture(name, stage, prior, row)
    synthetic()
    print("PASS continuous lens and finite positive-width certificates")


if __name__ == "__main__":
    main()

