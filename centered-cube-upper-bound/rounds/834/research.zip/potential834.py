"""R834 rational replay of a shared-source potential on the R814 price rows.

Use --archive for the R814 research.zip and --prior for the R833 research.zip.
The positive-width inner rank pools below are conservative subpools of the
actual continuous pools. The archive has no historical high-gate witness.
"""

import argparse
from collections import defaultdict
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, product
from json import loads
from math import comb, isqrt, prod
from pathlib import Path
from zipfile import ZipFile


ROUNDS = Path("/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/"
              "centered-cube-upper-bound/rounds")
PIN_814 = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
PIN_833 = "8c37039dba896615b13e4de9c1bfe2a56ee8f539e192c11386285237f2537b17"


def bind(code, name):
    namespace = {"__name__": name}
    exec(compile(code, name + ".py", "exec"), namespace)
    return namespace


def load_inputs(archive, prior):
    assert sha256(archive.read_bytes()).hexdigest() == PIN_814
    assert sha256(prior.read_bytes()).hexdigest() == PIN_833
    with ZipFile(archive) as z:
        comb = bind(z.read("comb811.py"), "archived_comb811")
        rebuilt = loads(z.read("comb814-rebuilt.json"))["stages"][0]
    with ZipFile(prior) as z:
        row = bind(z.read("row833.py"), "archived_row833")
    return (("original", comb["fixture"](*comb["FIXTURES"][-1])), ("rebuilt", rebuilt)), row


def cube(box):
    return tuple(tuple(map(F, v)) for v in box)


def volume(box):
    return prod(max(F(0), hi-lo) for lo, hi in box)


def reconstruct(stage):
    parents = {p["id"]: p for p in stage["parents"]}
    assert tuple(parents) == tuple(stage["parent_order"])
    bits = {t: p["bit"] for t, p in parents.items()}
    assert tuple(bits.values()) == tuple(1 << i for i in range(len(bits)))
    m = {t: F(p["m"]) for t, p in parents.items()}
    j = {t: F(p["j"]) for t, p in parents.items()}
    cubes = {t: cube(p["box"]) for t, p in parents.items()}
    owners = {t: cube(p["owner"]) for t, p in parents.items()}
    radius = {t: F(p["radius"]) for t, p in parents.items()}
    mu = {c["mask"]: F(c["mass"]) for c in stage["cells"] if F(c["mass"]) > 0}
    for t, p in parents.items():
        assert m[t] == sum(w for mask, w in mu.items() if mask & bits[t])
        assert all(hi-lo == 2*radius[t] for lo, hi in cubes[t])
        assert 0 < j[t] <= volume(owners[t]) == F(p["owner_volume"])
    for a, b in combinations(owners.values(), 2):
        assert not volume(tuple((max(l, x), min(h, y)) for (l,h), (x,y) in zip(a,b,strict=True)))

    mids = tuple(stage["middle_labels"])
    assert all(1 <= radius[t] < 2 and m[t] >= 16 for t in mids)
    d = {}
    permitted = {}
    for t in mids:
        terms = {}
        for u in parents:
            mask = bits[t] | bits[u]
            common = sum(w for z, w in mu.items() if z & mask == mask)
            assert common == F(stage["degrees"][t]["true_mu_intersections"][u])
            terms[u] = j[u]*common/(m[t]*m[u]) if u != t else F(0)
        assert terms == {u:F(w) for u,w in stage["degrees"][t]["full_terms"].items()}
        d[t] = sum(terms.values())
        assert d[t] == F(parents[t]["full_d"]) == F(stage["degrees"][t]["full_d"])
        old = {u: weight for u, weight in terms.items()
               if weight > 0 and parents[u]["role"] == "old" and radius[u] < radius[t]}
        assert old == {u:F(w) for u,w in stage["degrees"][t]["old_terms"].items()}
        assert 0 < sum(old.values()) == F(parents[t]["old_d"]) <= d[t]
        permitted[t] = {(u,z) for u in old for z in mu if z & bits[t] and z & bits[u]}

    rows = {}
    for root in stage["roots_cross"]:
        t,u,g = (root[k] for k in ("t","u","g"))
        assert F(parents[u]["volume_bin"]) != F(parents[g]["volume_bin"])
        coefficient = j[t]*j[u]*j[g]/(d[t]*m[t]**2*m[u]*m[g])
        assert coefficient == F(root["coefficient"]) > 0
        subtotal = F(0)
        for z,q in product(root["z_masks"], root["q_masks"]):
            key = t,(u,z),(g,q)
            assert key not in rows
            rows[key] = weight = coefficient * mu[z] * mu[q]
            subtotal += weight
        assert subtotal == F(root["root_mass"])
    assert rows.keys() == {
        (t,x,y) for t in mids for x,y in product(permitted[t], repeat=2)
        if F(parents[x[0]]["volume_bin"]) != F(parents[y[0]]["volume_bin"])
    }
    assert len(rows) == 230 and sum(rows.values()) == F(stage["benchmarks"]["cross"]["mother"])
    return rows, cubes, owners, m, j, bits, mu


def source_atoms(cubes, density, mu, active, axis_intervals):
    boxes = tuple(cubes.values())
    lo, hi = map(F, density["support"])
    coarse_axes, fine_axes = [], []
    for axis in range(len(boxes[0])):
        pieces = axis_intervals(boxes, axis, density)
        cuts = sorted({lo, hi} | {x for b in boxes for x in b[axis] if lo < x < hi})
        coarse, fine = [], []
        for a,b in zip(cuts,cuts[1:]):
            mid = (a+b)/2
            mask = sum(1 << i for i,c in enumerate(boxes) if c[axis][0] < mid < c[axis][1])
            halves = []
            for l,h in ((a,mid),(mid,b)):
                mass = sum(max(F(0), min(h,y)-max(l,x))*w for x,y,_,w in pieces)
                assert mass > 0
                halves.append((l,h,mass))
            coarse.append((mask, sum(x[2] for x in halves)))
            fine.append((mask, tuple(halves)))
        coarse_axes.append(coarse)
        fine_axes.append(fine)

    result, total = defaultdict(list), defaultdict(F)
    all_bits = (1 << len(boxes))-1
    for intervals in product(*coarse_axes):
        mask = all_bits
        for bits,_ in intervals:
            mask &= bits
        total[mask] += prod(mass for _,mass in intervals)
    assert dict(total) == mu

    for intervals in product(*fine_axes):
        mask = all_bits
        for bits,_ in intervals:
            mask &= bits
        if mask in active:
            for atoms in product(*(pieces for _,pieces in intervals)):
                result[mask].append((tuple((l,h) for l,h,_ in atoms), prod(w for _,_,w in atoms)))
    assert result.keys() == active
    assert all(sum(w for _,w in result[mask]) == mu[mask] for mask in active)
    return result


def exterior(tbox, box):
    # Each open source box stays inside a single face cell of the anchor.
    return tuple((i, -1 if h <= a else 1, l, h)
                 for i, ((a,b),(l,h)) in enumerate(zip(tbox,box,strict=True))
                 if h <= a or l >= b)


def dominant(conditions, candidate):
    return all((candidate[axis][1] <= lo if side < 0 else candidate[axis][0] >= hi)
               for axis,side,lo,hi in conditions)


def source_kernel(cubes, bits, atoms, mu, groups):
    # For q inside t, the coordinate deficit is monotone outward in |z-q|.
    # On each tested exterior coordinate any selected y lies no farther
    # out than every partner z in its positive-measure atom. Thus this
    # source subpool belongs to the actual B_{ji} for every q in its cell.
    plans = set()
    for group, keys in groups.items():
        support = {x[1] for _,x,_ in keys}
        for t,_,_ in keys:
            for z in support:
                for y in support:
                    if not (y & bits[t] or z & bits[t]):
                        plans.add((t,z,y))
    out = {}
    for t,z,y in sorted(plans):
        partner = atoms[z]
        for i, (box,_) in enumerate(atoms[y]):
            ext = exterior(cubes[t],box)
            assert ext  # Every source tested lies outside the anchor.
            probability = sum(mass for rect,mass in partner if dominant(ext,rect)) / mu[z]
            if probability:
                assert probability <= 1
                out.setdefault((t,z,y),{})[(y,i)] = probability
    return out


def grouped_flow(rows):
    # All middle radii lie in the original physical octave [1,2).
    # Conditional on a true q in this mask and actual W in the g-owner box,
    # the common right density cancels, leaving this exact finite law.
    groups = defaultdict(list)
    for k in sorted(rows):
        groups[k[2]].append(k)
    return dict(groups)


def active_state(rows, groups, active, denominator, kernel):
    field_by_anchor = defaultdict(lambda: defaultdict(F))
    active_groups = {}
    for g, keys in groups.items():
        base = sum(rows[k] for k in keys)
        retained = tuple(k for k in keys if k in active)
        anchor, partner = defaultdict(F), defaultdict(F)
        for t,x,y in retained:
            w = rows[t,x,y]
            anchor[t] += w
            partner[x[1]] += w
        active_groups[g] = base, retained, sum(anchor.values())
        support = {x[1] for _,x,_ in keys}
        for t, at in sorted(anchor.items()):
            for z, pt in sorted(partner.items()):
                # The two directions have equal integrals under the frozen pair law.
                coefficient = 2 * at * pt / (base * denominator[t])
                for y in sorted(support):
                    for cell, probability in kernel.get((t,z,y),{}).items():
                        field_by_anchor[t][cell] += coefficient * probability
    field = defaultdict(F)
    for values in field_by_anchor.values():
        for cell, value in values.items():
            field[cell] += value
    return dict(field), dict(field_by_anchor), active_groups


def source_atom_mass(cell, atoms):
    mask,i = cell
    return atoms[mask][i][1]


def log_sum(values, methods):
    lo, hi = F(0), F(0)
    for mass, argument in values:
        lower, upper = methods["logarithm"](argument)
        lo += mass*lower
        hi += mass*upper
    return lo,hi


def direction_price(t,g,z,field,groups,denominator,kernel,atoms):
    support = {x[1] for _,x,_ in groups[g]}
    price, pool_mass, low_mass = F(0), F(0), F(0)
    threshold = max(field.values())/2 if field else F(0)
    for mask in support:
        for cell,prob in kernel.get((t,z,mask),{}).items():
            amount = source_atom_mass(cell,atoms)*prob
            pool_mass += amount
            congestion = field.get(cell,F(0))
            price += amount/(1+congestion)
            if congestion <= threshold:
                low_mass += amount
    assert low_mass <= (1+threshold)*price <= (1+threshold)*pool_mass
    return price / denominator[t]


def coverage(groups, m, bits, mu):
    max_rank = F(1)
    multi = []
    for g,keys in groups.items():
        support = {x[1] for _,x,_ in keys}
        anchors = {t for t,_,_ in keys}
        if len(anchors) > 1:
            multi.append(g)
        for t in anchors:
            bound = 1 + sum(mu[z] for z in support if not z & bits[t])/m[t]
            max_rank = max(max_rank,bound)
    assert max_rank < 16
    return max_rank, multi


def check_scenario(name, active, rows, groups, rho, m, j, owners, atoms, kernel, log_methods):
    denominator = {t: rho[t]*m[t] for t in rho}
    field, anchor_fields, active_groups = active_state(rows, groups, active, denominator, kernel)
    assert field and len(anchor_fields) >= 2
    displayed = lambda x: format(float(x), ".11g")
    print_interval = log_methods["interval_text"]
    original_mass = sum(rows.values())
    retained_mass = sum(rows[k] for k in active)
    atom_mass = {cell: source_atom_mass(cell,atoms) for cell in field}
    cap = 2*sum(j[t]/m[t] for t in rho)
    assert all(v <= cap for v in field.values())
    for t, values in anchor_fields.items():
        for mask, i in values:
            box = atoms[mask][i][0]
            assert all(max(abs(l-b), abs(h-a)) <= F(13,2)
                       for (l,h),(a,b) in zip(owners[t],box,strict=True))
    collisions = {y for y in field if sum(y in f for f in anchor_fields.values()) >= 2}
    assert collisions
    potential = log_sum(((w,1+field[y]) for y,w in atom_mass.items()), log_methods)
    assert potential[1] <= sum(w * field[y] for y,w in atom_mass.items())
    separate_gap = log_sum(
        ((atom_mass[y], prod(1+f.get(y,F(0)) for f in anchor_fields.values())/(1+field[y]))
         for y in collisions), log_methods)
    assert separate_gap[0] > 0

    fees = {}
    base_anchor = {t: rho[t]*j[t] for t in rho}
    left_anchors, right_anchors = defaultdict(F), defaultdict(F)
    conditional = defaultdict(F)
    priced = F(0)
    paid_reconditioned = F(0)
    sigmas = []
    low = defaultdict(F)
    threshold = max(field.values())/2
    for g,(base,keys,live) in active_groups.items():
        if not keys:
            continue
        sigmas.append(live/base)
        for e1,e2 in product(keys,repeat=2):
            t1,z1,_ = e1
            t2,z2,_ = e2
            weight = rows[e1]*rows[e2]/base
            left_anchors[t1] += weight
            right_anchors[t2] += weight
            fee = F(0)
            for (t,z) in ((t1,z2[1]),(t2,z1[1])):
                ident = t,g,z
                if ident not in fees:
                    fees[ident] = direction_price(t,g,z,field,groups,denominator,kernel,atoms)
                fee += fees[ident]
            conditional[e1] += rows[e2]/base*fee
            priced += weight*fee
            paid_reconditioned += weight*fee*base/live
        for k in keys:
            _, x, _ = k
            z = x[1]
            low[g] += rows[k]*sum(
                w for i,(_,w) in enumerate(atoms[z]) if field.get((z,i),F(0)) <= threshold
            )/sum(w for _,w in atoms[z])
    assert left_anchors == right_anchors
    assert all(w <= base_anchor[t] for t,w in left_anchors.items())
    derivative = sum(atom_mass[y]*field[y]/(1+field[y]) for y in field)
    assert priced == derivative
    delta_observed = max(conditional.values())
    assert priced <= delta_observed*retained_mass
    assert min(sigmas) >= F(1,2) and priced <= paid_reconditioned <= 2*priced
    assert sum(low.values())**2/retained_mass <= sum(
        v*v/active_groups[g][2] for g,v in low.items()
    )

    # Price the disappearing ordered pairs independently of recomputing F.
    # Pick a positive-price row that leaves at least half its whole G group.
    candidates = [k for k in active if conditional[k] > 0 and
                  active_groups[k[2]][2] - rows[k] >= active_groups[k[2]][0]/2]
    deleted = max(sorted(candidates), key=lambda k: rows[k]*conditional[k])
    sampled_g = deleted[2]
    base, keys, _ = active_groups[sampled_g]
    dual_drop = F(0)
    for e1,e2 in product(keys,repeat=2):
        if deleted not in (e1,e2):
            continue
        t1,z1,_ = e1
        t2,z2,_ = e2
        dual_drop += rows[e1]*rows[e2]/base*(
            fees[t1,sampled_g,z2[1]] + fees[t2,sampled_g,z1[1]])
    narrower,_,_ = active_state(rows,groups,active-{deleted},denominator,kernel)
    assert narrower.keys() <= field.keys()
    assert all(field[y] >= narrower.get(y,F(0)) for y in field)
    drop = log_sum(((atom_mass[y],(1+field[y])/(1+narrower.get(y,F(0)))) for y in field),
                   log_methods)
    assert dual_drop == sum(atom_mass[y]*(field[y]-narrower.get(y,F(0)))/(1+field[y])
                              for y in field) > 0
    assert drop[0] > dual_drop and dual_drop >= rows[deleted]*conditional[deleted]
    new_phi = log_sum(((atom_mass[y],1+f) for y,f in narrower.items()),log_methods)
    assert potential[0]-new_phi[1] <= drop[1] and drop[0] <= potential[1]-new_phi[0]

    print("  scenario", name, "rows",len(active),"G",len(sigmas),
          "retained fraction",displayed(retained_mass/original_mass),
          "min sigma",displayed(min(sigmas)),
          "max anchor marginal fraction",displayed(max(w/base_anchor[t] for t,w in left_anchors.items())))
    print("   Fmax",displayed(max(field.values())),"cap",displayed(cap),
          "shared source atoms",len(collisions),
          "shared source mass",displayed(sum(atom_mass[y] for y in collisions)),
          "Phi",displayed(potential[0]),"separate minus shared Phi",displayed(separate_gap[0]))
    print("   delete",deleted,"mass fraction",displayed(rows[deleted]/retained_mass),
          "price drop",displayed(dual_drop),"log drop",displayed(drop[0]),
          "certified log drop / price drop",print_interval((drop[0]/dual_drop,drop[1]/dual_drop),16),
          "literal-delta pass fraction",displayed(sum(rows[k] for k in active
              if conditional[k] <= F(1,512))/retained_mass),
          "low-F actual mass fraction",displayed(sum(low.values())/retained_mass))


def run_fixture(name, stage, methods):
    rows,cubes,owners,m,j,bits,mu = reconstruct(stage)
    groups = grouped_flow(rows)
    mids = tuple(stage["middle_labels"])
    rho = {t: sum(w for k,w in rows.items() if k[0] == t)/j[t] for t in mids}
    assert all(rho[t] > 0 for t in mids)
    mask_active = {x[1] for _,x,_ in rows}
    atoms = source_atoms(cubes,stage["density"],mu,mask_active,methods["axis_intervals"])
    kernel = source_kernel(cubes,bits,atoms,mu,groups)
    max_rank,multi = coverage(groups,m,bits,mu)
    print("R814 SHARED-SOURCE POTENTIAL", name, "rows",len(rows),
          "true G classes",len(groups),"multi-anchor G classes",len(multi),
          "source atoms",sum(map(len,atoms.values())),"rank upper",format(float(max_rank),".11g"))
    print("  same q and actual right-owner coordinate; fixed physical window [1,2);"
          " no rank >= 16 and no historical high-gate witness")
    thinned = set(rows)
    for keys in groups.values():
        remaining_budget = sum(rows[k] for k in keys) / 16
        for k in sorted(keys, key=lambda k: (-rows[k], k)):
            if k[0] == mids[0] and rows[k] <= remaining_budget:
                thinned.remove(k)
                remaining_budget -= rows[k]
    assert 0 < len(thinned) < len(rows)
    polar = {k for g in multi if len({t for t,_,_ in groups[g]}) == 3 for k in groups[g]}
    for label, active in (("full", set(rows)), ("three-anchor G only", polar),
                          ("thin first-anchor rows within G", thinned)):
        check_scenario(label, active,rows,groups,rho,m,j,owners,atoms,kernel,methods)


PRICE_DOWN = Context(prec=50, rounding=ROUND_FLOOR)
PRICE_UP = Context(prec=50, rounding=ROUND_CEILING)
PRICE_NEAR = Context(prec=50, rounding=ROUND_HALF_EVEN)


def price_enclosure(x, name):
    args = Decimal(x.numerator), Decimal(x.denominator)
    operation = getattr(PRICE_NEAR, name)
    return (F(PRICE_DOWN.next_minus(operation(PRICE_DOWN.divide(*args)))),
            F(PRICE_UP.next_plus(operation(PRICE_UP.divide(*args)))))


def price_sqrt(x):
    a, b = isqrt(x.numerator), isqrt(x.denominator)
    if a*a == x.numerator and b*b == x.denominator:
        return (F(a, b),) * 2
    return price_enclosure(x, "sqrt")


def price_show(interval, digits=9):
    quantum = 10**digits
    lo, hi = (x * quantum for x in interval)
    a, b = lo.numerator // lo.denominator, -((-hi.numerator) // hi.denominator)

    def display(x):
        sign = "-" if x < 0 else ""
        whole, frac = divmod(abs(x), quantum)
        return f"{sign}{whole}.{frac:0{digits}d}"

    return f"[{display(a)}, {display(b)}]"


def price_det(xs):
    """Elimination over Q, with independent closed-form checks in 2D."""
    size = len(xs)
    if not size:
        return F(1)
    a = [list(row) for row in xs]
    value = F(1)
    for j in range(size):
        p = next((i for i in range(j, size) if a[i][j]), None)
        if p is None:
            return F(0)
        if j != p:
            a[j], a[p] = a[p], a[j]
            value = -value
        value *= a[j][j]
        for i in range(j + 1, size):
            f = a[i][j] / a[j][j]
            for k in range(j + 1, size):
                a[i][k] -= f * a[j][k]
    return value


def price_projection_stats(groups):
    """Mass and count per projection dimension, without enumerating axes."""
    n = sum(count for _, count in groups)
    m = len(groups[0][0])
    assert all(count > 0 and len(row) == m for row, count in groups)
    assert len({row for row, _ in groups}) == len(groups)
    totals, nonzero = [F(1)], [1]  # Empty projection has unit 0D volume.
    for k in range(1, min(n, m) + 1):
        volume, count = F(0), 0
        # A nonzero minor cannot use a repeated row. Its multiplicity is the
        # product of the numbers of coordinates in its distinct row types.
        for selected in combinations(groups, k):
            mult = prod(repeats for _, repeats in selected)
            projected_volume = sum(
                abs(price_det(tuple(tuple(row[j] for j in js) for row, _ in selected)))
                for js in combinations(range(m), k)
            )
            if projected_volume:
                volume += mult * projected_volume
                count += mult
        totals.append(volume)
        nonzero.append(count)
    return tuple(totals), tuple(nonzero)


def price_direct_projection(rows, coordinate_indices, pad):
    """Literal minors of columns of G and coordinate pad, for small n only."""
    k = len(coordinate_indices)
    if not k:
        return F(1)
    generators = [tuple(rows[i][j] for i in coordinate_indices) for j in range(len(rows[0]))]
    generators.extend(tuple(pad * (i == j) for i in range(k)) for j in range(k))
    return sum(abs(price_det(vectors)) for vectors in combinations(generators, k))


def price_area(generators):
    """Independent exact convex hull and shoelace for the 2D example."""
    pts = sorted({
        tuple(sum(coeff * vec[i] for coeff, vec in zip(signs, generators, strict=True))
              for i in range(2))
        for signs in product((F(-1, 2), F(1, 2)), repeat=len(generators))
    })

    def turn(x, y, z):
        return (y[0]-x[0]) * (z[1]-x[1]) - (y[1]-x[1]) * (z[0]-x[0])

    def half(sequence):
        out = []
        for p in sequence:
            while len(out) > 1 and turn(out[-2], out[-1], p) <= 0:
                out.pop()
            out.append(p)
        return out[:-1]

    hull = half(pts) + half(reversed(pts))
    return abs(sum(a[0]*b[1] - a[1]*b[0] for a, b in zip(hull, hull[1:] + hull[:1]))) / 2


def price_polynomial(totals, t):
    degree = max(k for k, vol in enumerate(totals) if vol)
    polynomial = sum(vol * t**(degree-k) for k, vol in enumerate(totals) if vol)
    return degree, polynomial


def price_log_product(factors):
    lo, hi = F(0), F(0)
    for base, exponent in factors:
        assert base > 0 and exponent >= 0
        if base == 1 or exponent == 0:
            continue
        p, q = price_enclosure(base, "ln")
        lo += exponent * p
        hi += exponent * q
    return lo, hi


def price_case(name, groups, eta, low_dim=False):
    """K has full generator segments centered at zero; eta pads each axis."""
    n = sum(count for _, count in groups)
    m = len(groups[0][0])
    widths = tuple((sum(map(abs, row)), count) for row, count in groups)
    generator_norms_sq = tuple(sum(count * row[j]**2 for row, count in groups) for j in range(m))
    total, supports = price_projection_stats(groups)
    r, arrival = price_polynomial(total, 1 + eta)
    shape_rank, thick_body = price_polynomial(total, eta)
    assert r == shape_rank and eta > 0 and all(w + eta <= 1 for w, _ in widths)
    assert total[1] == sum(w * count for w, count in widths)
    assert all(support <= comb(n, k) for k, support in enumerate(supports))

    # Normalized mean width sqrt(pi/2)*E[range of Gaussian projection].
    # A full generator contributes its Euclidean norm, independent of rank.
    norms = [price_sqrt(x) for x in generator_norms_sq]
    thin_shared = tuple(sum(x[k] for x in norms) for k in range(2))
    thick_shared = tuple(x + n*eta for x in thin_shared)
    bbox_shared = sum((w + eta) * count for w, count in widths)
    bbox_diagonal = price_sqrt(sum((w + eta)**2 * count for w, count in widths))
    assert thick_shared[1] <= bbox_shared

    if low_dim:
        rows = tuple(row for row, count in groups for _ in range(count))
        direct, direct_counts = [F(0)] * (n + 1), [0] * (n + 1)
        padded = [F(0)] * (n + 1)
        for k in range(n + 1):
            for axes in combinations(range(n), k):
                vol = price_direct_projection(rows, axes, F(0))
                direct[k] += vol
                direct_counts[k] += vol > 0
                padded[k] += price_direct_projection(rows, axes, eta)
            predicted = sum(comb(n-j, k-j) * eta**(k-j) * total[j]
                            for j in range(min(k, len(total)-1) + 1))
            assert padded[k] == predicted > 0
        assert tuple(direct[:len(total)]) == total and tuple(direct_counts[:len(supports)]) == supports
        assert not any(direct[len(total):])
        vp = (1 + eta)**(n-r) * arrival
        assert vp == sum(padded) == price_direct_projection(rows, tuple(range(n)), 1 + eta)
        if n == 2:
            s = 1 + eta
            original_segments = tuple(tuple(row[j] for row in rows) for j in range(m))
            assert price_area((*original_segments, (s, F(0)), (F(0), s))) == vp
            assert price_area((*original_segments, (F(1), F(0)), (F(0), F(1)))) == sum(total)
        print("PRICE LOW EXACT", name, "thick projection totals", tuple(map(str, padded)),
              "Q+K", sum(total), "Q+thick K", vp,
              "Q+bbox(thick K)", prod((1+eta+w)**c for w, c in widths))

    thin_cost = sum(total)
    vol_factors = ((1+eta, n-r), (arrival, 1))
    box_exponents = defaultdict(int)
    for width, count in widths:
        box_exponents[1 + eta + width] += count
    bbox_factors = tuple(sorted(box_exponents.items()))
    vol_log = price_log_product(vol_factors)
    bbox_log = price_log_product(bbox_factors)
    assert vol_log[1] < bbox_log[0]  # All selected fixtures are strictly oblique.
    if eta == F(1, n):
        # Since s^n<e<3, the positive pad keeps volume within a fixed
        # factor of the polynomial thin cost even with all projections positive.
        thin_log = price_enclosure(thin_cost, "ln")
        assert thin_log[1] < vol_log[0]
        assert vol_log[1] < price_enclosure(3*thin_cost, "ln")[0]
    gap_log = bbox_log[0] - vol_log[1], bbox_log[1] - vol_log[0]
    print("PRICE CASE", name, "n", n, "generators", m, "rank", r, "positive padding", eta,
          "projection supports by k", supports, "projection totals by k", tuple(map(str, total)),
          "unthick Q+K", thin_cost, "all thick projections supported", f"2^{n}")
    print("  exact Q+thick K factors", tuple((str(b), e) for b, e in vol_factors),
          "exact vol(thick K) factors", ((str(eta), n-r), (str(thick_body), 1)),
          "exact Q+coordinate box factors", tuple((str(b), e) for b, e in bbox_factors))
    print("  shared Gaussian price K", price_show(thin_shared),
          "shared price thick K", price_show(thick_shared), "coordinate box shared price", bbox_shared,
          "coordinate box Euclidean diagonal", price_show(bbox_diagonal),
          "log volume", price_show(vol_log), "log box volume", price_show(bbox_log),
          "log volume ratio box/zono", price_show(gap_log))
    return total, supports, generator_norms_sq


def price_checks():
    # Low dimensional reference, then oblique and linearly dependent cases.
    low_line = (((F(3, 8),), 1), ((F(1, 2),), 1))
    result = price_case("2D line", low_line, F(1, 16), low_dim=True)
    assert result == ((F(1), F(7, 8)), (1, 2), (F(25, 64),))
    low_band = (((F(1, 4), F(1, 4)), 1), ((F(1, 3), F(-1, 3)), 1), ((F(1, 2), F(0)), 1))
    price_case("3D two generators", low_band, F(1, 32), low_dim=True)
    dependent = (((F(1, 8), F(1, 4)), 1), ((F(1, 12), F(1, 6)), 1), ((F(-1, 8), F(-1, 4)), 1))
    assert price_case("3D two collinear generators", dependent, F(1, 32), low_dim=True)[0][-1] == 0
    low_three = tuple(((F(1, 4), F(sign_a, 4), F(sign_b, 4)), 1)
                      for sign_a, sign_b in product((-1, 1), repeat=2))
    price_case("4D three generators", low_three, F(1, 32), low_dim=True)

    # On every physical axis these zonotopes move a fixed positive amount.
    # Grouped multiplicities give exact costs within large ambient dimensions.
    for n in (16, 256, 4096, 65536):
        eta = F(1, n)
        line = (((F(1, 2),), n),)
        two = tuple(((F(1, 3), F(s, 3)), n//2) for s in (-1, 1))
        three = tuple((row, n//4) for row, _ in low_three)
        assert price_case("all-axes diagonal", line, eta) == ((F(1), F(n, 2)), (1, n), (F(n, 4),))
        assert price_case("two all-axes oblique generators", two, eta) == (
            (F(1), F(2*n, 3), F(n*n, 18)), (1, n, n*n//4), (F(n, 9),)*2)
        assert price_case("three all-axes oblique generators", three, eta) == (
            (F(1), F(3*n, 4), F(3*n*n, 32), F(n**3, 256)),
            (1, n, 3*n*n//8, n**3//16), (F(n, 16),)*3)
    print("PASS positive-width zonotope costs and Gaussian prices; artificial geometry only")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive",type=Path,default=ROUNDS/"814/research.zip")
    parser.add_argument("--prior",type=Path,default=ROUNDS/"833/research.zip")
    args = parser.parse_args()
    fixtures, methods = load_inputs(args.archive,args.prior)
    for name,stage in fixtures:
        run_fixture(name,stage,methods)
    print("PASS shared-source potential and frozen-law deletion")
    price_checks()


if __name__ == "__main__":
    main()
