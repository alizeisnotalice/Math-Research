"""R834 exact mixed-cone tests on spatial L1 input and true last-root receivers.

Root side is the supremum of s with mu(Q_s(x)) > s**n, threshold lambda=1.
All arithmetic in the certificate uses Fraction, including bounds for the
near gate via elementary rational bounds on exp. No archive input is needed.
"""

from fractions import Fraction as F
from itertools import product
from math import isqrt


DIMS = (2, 16, 256, 4096)


def span(center, half):
    return center - half, center + half


def long_jump(n, ratio):
    """A rational upper bound for sqrt(n) log(n+2), by log(2)<7/10."""
    sqrt_upper = isqrt(n - 1) + 1
    log_upper = F(7, 10) * (n + 1).bit_length()
    assert ratio > sqrt_upper * log_upper / 4
    if n > 2:
        assert ratio > sqrt_upper * log_upper
    else:
        # For n=2 the test ratio is <1, below even log(4).
        assert ratio < 1 < F(4, 3)


def one_scale(n, gamma):
    source_half = receiver_half = F(1, 256)
    position = F(31, 64)
    # Two boxes: common first interval, all other axes at +/-position.
    # At every x in the receiver all mass 1 lies strictly inside Q_1(x).
    assert position + source_half + receiver_half < F(1, 2)
    assert 2 * position > 2 * source_half
    full_contact_side = 2 * (position + source_half + receiver_half)
    assert full_contact_side == F(63, 64)
    # Full mass for s in (63/64,1); global mass cap gives t_x=h(x)=1.
    sep = (n - 1) * (2 * position - 2 * source_half)
    long_jump(n, sep)
    base_hi = 4 * source_half
    mixed_lo = 2 * gamma * sep / n
    assert mixed_lo > base_hi
    # Gradient is zero in the receiver interior. Check the actual slack too.
    full_sep_hi = (n - 1) * 2 * (position + source_half) + 2 * source_half
    assert 2 * ((1 - gamma) * 2 * source_half + gamma * full_sep_hi / n) < 2
    print("ONE SCALE", n, "gamma", gamma, "t=h=1, Jsum=2",
          "receiver and each source volume", f"128^-{n}",
          "l1/t lower", sep, "pure upper", base_hi, "mixed contribution lower", mixed_lo)


def three_scales(n, gamma, near):
    r = F(1, 2)
    far_r = F(1, 4)
    w = F(1, 16 * n)
    m = F(1, 2) - w
    e = r / (512 * n)
    bump = r / (16 * n)
    alpha0 = 1 - gamma + gamma / n

    # Local large source M=[-w,0]^n, mass 1-r^n. Two positive-width
    # satellite sources at the designated x-core have total mass r^n.
    # A third-scale source around 4*1 has mass far_r^n.
    mh = r * (1 + F(1, 2 * n)) if near else r * F(7, 4)
    ell = (1 - mh) / 2 - alpha0 * bump
    centers = m + ell + bump, m + ell
    x_intervals = tuple(span(value, e) for value in centers)
    assert ell > e > 0 and bump > 2 * e
    assert all(lo > m > r / 2 for lo, _ in x_intervals)
    top = tuple(span(value + r / 2 - 4 * e, e) for value in centers)
    bottom = (top[0], span(centers[1] - r / 2 + 4 * e, e))
    assert bottom[1][1] < top[1][0]
    assert 0 < min(lo for lo, _ in bottom + top)
    assert max(hi for _, hi in bottom + top) < m + F(1, 2) - e
    assert 2 * e < far_r / 2
    assert 4 - e - max(hi for _, hi in bottom + top) > 2
    assert 1 + far_r**n < 2**n

    # Any candidate s<=2 meets at most one cluster; no s>2 can exceed.
    # At a local center y with some y_i>m, the fraction of M in Q_s(y)
    # is at most [1-(1-s)/(2w)]_+. For r<s<1 either only satellite
    # mass <=r^n is available or the cap is
    # 1-(1-r^n)(1-s)/(2w) <= 1-n(1-s) <= s^n.
    assert (1 - r**n) / (2 * w) >= n
    # Thus t_y>r implies all y_i<=m, and t_y<=1 globally.
    # For y_i=m-j*e, 0<j<=1, all local sources are strictly in Q_1(y).
    # These centers have true root 1 and approach the upper orthant face.
    assert (m - e) + F(1, 2) > max(hi for _, hi in bottom + top)
    assert m - F(1, 2) == -w
    assert m - e > 0

    # At every x in the receiver, satellites are fully inside already
    # at sides in (r-4e,r), and M is absent. Hence t_x=r exactly.
    for k, (lo, hi) in enumerate(x_intervals):
        for a, b in (top[k], bottom[k]):
            assert max(abs(a - hi), abs(b - lo)) <= r / 2 - 2 * e
    # The far receiver 4*1+[-e,e]^n has true root far_r and h=far_r.
    # Centers with t_y>far_r must have a candidate sphere of side<=1
    # meeting the local cluster, hence y_i<3/2 for all i, so every cone
    # from them vanishes on the far receiver.
    assert 4 - e - F(3, 2) > F(1, 2)

    # For t_y<=r a cone has value <=r; for t_y>r the closest possible
    # apex is m*1. The limiting t_y=1 cones attain its supremum.
    # The first displacement stays uniquely largest and all signs +.
    # Thus grad h=-2[alpha0, gamma/n,...,gamma/n].
    assert 1 - 2 * (ell + alpha0 * bump) == mh
    lo_h, hi_h = mh - 2 * e, mh + 2 * e
    assert r < lo_h <= hi_h < 1
    lo_ratio, hi_ratio = lo_h / r, hi_h / r
    if near:
        assert hi_ratio < 1 + F(1, n) < 1 + F(13, 10 * n)
        # exp(1/n)>1+1/n and the true near gate holds on the whole box.
    else:
        # For z=1/n<=1/2, exp(z)<1+z+(3/5)z^2<=1+(13/10)z.
        # The retained near-gate estimate cannot cover this receiver.
        assert lo_ratio > F(5, 3) > 1 + F(13, 10 * n)

    # Independent directional calculation over every vertex of each
    # one-axis box. The exact deficit is r-2(max(p,q)-x), with correct
    # positive gradient sign. It always lies in [4e,12e].
    for k, (X, P, Q) in enumerate(zip(x_intervals, bottom, top, strict=True)):
        for x, p, q in product(X, P, Q):
            deficit = r - abs(p - q) - (p + q - 2 * x)
            assert deficit == r - 2 * (max(p, q) - x)
            assert 4 * e <= deficit <= 12 * e
            if k == 0:
                assert abs(p - q) <= 2 * e
            else:
                assert r - 10 * e <= abs(p - q) <= r - 6 * e
    separation = (n - 1) * (r - 10 * e)
    long_jump(n, separation / r)
    assert gamma * separation / n > 2 * e

    # At the actual rational centers, independently recompute J and its
    # decomposition. The pure infinity cone is active there too.
    p0 = (centers[0] + r / 2 - 4 * e, centers[1] - r / 2 + 4 * e)
    q0 = tuple(value + r / 2 - 4 * e for value in centers)
    beta = (alpha0, 1 - alpha0)  # axis 0 and the other axes collectively
    gaps = tuple(abs(p - q) for p, q in zip(p0, q0, strict=True))
    j_mixed = 2 - 2 * sum(b * (p + q - 2 * x) for b, p, q, x in
                          zip(beta, p0, q0, centers, strict=True)) / mh
    j_gap = 2 * sum(b * g for b, g in zip(beta, gaps, strict=True)) / mh
    assert j_mixed == 2 * (1 - r / mh) + j_gap + 16 * e / mh
    assert j_gap == 2 * gamma * (n - 1) * (r - 8 * e) / (n * mh)
    h_infty = 1 - 2 * (ell + bump)
    assert r < h_infty < mh
    j_pure = 2 - 2 * (p0[0] + q0[0] - 2 * centers[0]) / h_infty
    assert j_mixed > j_pure

    print("THREE SCALES", n, "near" if near else "supercone",
          "true t", (str(far_r), str(r), "1"), "target h/t envelope", lo_ratio, hi_ratio,
          "l1/t lower", separation / r, "core J_mixed", j_mixed, "core J_infty", j_pure,
          "receiver and each satellite volume", f"({2 * e})^{n}",
          "volume-ratio bound" if not near else "near test",
          f"(3/5)^{n}" if not near else "pass")


if __name__ == "__main__":
    for dimension in DIMS:
        lazy = F(1, (dimension + 1).bit_length())
        one_scale(dimension, lazy)
        three_scales(dimension, lazy, True)
        three_scales(dimension, lazy, False)
    print("PASS exact arithmetic; frozen endpoint/history comparison only")
