"""R763 paired original weights, true cube vertices, and terminal-price audit."""

import argparse
from collections import defaultdict
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from math import prod
from pathlib import Path
from platform import python_version


def cube(y,r):
    return tuple((x-r,x+r) for x in y)


def intersect(*boxes):
    return tuple((max(a for a,_ in axes),min(b for _,b in axes)) for axes in zip(*boxes))


def nonempty(box):
    return all(a<=b for a,b in box)


def volume(box):
    return prod(max(Q(0),b-a) for a,b in box)


def inside(box,x):
    return all(a<=t<=b for (a,b),t in zip(box,x))


def geometry(n):
    shrink,K = 32*n,Q(4)
    G = (2+Q(1,shrink))**n
    h = 1+Q(1,shrink)
    parameters = {
        "t":(Q(0),Q(0),Q(4)),
        "left":(Q(-7,4),Q(0),Q(2)),
        "right":(Q(13,8),Q(0),Q(7,4)),
        "midL":(Q(-3,8),Q(0),Q(9,8)),
        "midR":(Q(1,2),Q(0),Q(5,4)),
        "k":(Q(1,8),Q(0),Q(1,2)),
        "equal_tail":(Q(3,8),Q(1,8),Q(1,4)),
        "contact_large":(Q(2),Q(2),Q(1,2)),
        "contact_small":(Q(5,4),Q(5,4),Q(1,4)),
        "thin_small":(Q(81,64),Q(81,64),Q(1,4)),
        "t_face":(Q(17,4),Q(17,4),Q(1,4)),
    }
    if n==3:
        parameters.update({
            "deep_tail":(Q(1,4),Q(-1,8),Q(1,16)),
            "clip_target":(Q(13,4),Q(0),Q(3,4)),
            "clip_cross":(Q(4),Q(0),Q(1,2)),
        })
    s = {j:r for j,(_,_,r) in parameters.items()}
    centers = {j:(x,y)+(Q(0),)*(n-2) for j,(x,y,r) in parameters.items()}
    A = {j:cube(x,s[j]) for j,x in centers.items()}
    E = {j:cube(x,s[j]/shrink) for j,x in centers.items()}
    d = {j:volume(B) for j,B in A.items()}
    v = {j:volume(B) for j,B in E.items()}
    assert all(v[j]>0 and intersect(A[j],E[j])==E[j] for j in A)
    assert all(volume(intersect(B,C))==0 for B,C in combinations(E.values(),2))

    overlay_left = ((Q(-3,8),Q(-1,8)),)+((Q(-1,2),Q(1,2)),)*(n-1)
    overlay_right = ((Q(1,8),Q(3,8)),)+((Q(-1,4),Q(1,4)),)*(n-1)
    private = cube(centers["thin_small"],Q(1,32))
    price = [(((Q(-6),Q(6)),)*n,Q(2)),(overlay_left,Q(3)),
             (overlay_right,Q(7)),(private,Q(4096))]

    def mu(B):
        return sum(w*volume(intersect(B,P)) for P,w in price)

    m = {j:mu(B) for j,B in A.items()}
    assert all(m[j]>d[j] for j in A)
    a = {j:v[j]/m[j] for j in A}
    hats = {j:Q(1) if j in ("t","left") else Q(1+(i%3),3) for i,j in enumerate(A)}
    w = {j:K/G*hats[j]*a[j] for j in A}
    assert sum(w.values())<=1 and all(w[j]<=K/G*a[j] for j in A)
    points = [sorted({x for box in (*A.values(),*(B for B,_ in price)) for x in box[i]})
              for i in range(n)]
    patterns = defaultdict(Q)
    positive_cells = 0
    for cell in product(*(zip(axis,axis[1:]) for axis in points)):
        mid = tuple((a+b)/2 for a,b in cell)
        mass = volume(cell)*sum(coef for B,coef in price if inside(B,mid))
        if mass:
            mask = tuple(j for j,B in A.items() if inside(B,mid))
            patterns[mask] += mass
            positive_cells += 1
    S = sum(volume(B)*weight for B,weight in price)
    assert sum(patterns.values())==S
    assert all(m[j]==sum(mass for M,mass in patterns.items() if j in M) for j in A)
    ij_mass = {(i,j):mu(intersect(A[i],A[j])) for i,j in product(A,repeat=2)}
    assert all(value==sum(mass for M,mass in patterns.items() if i in M and j in M)
               for (i,j),value in ij_mass.items())
    return A,s,d,v,m,a,w,G,K,h,patterns,ij_mass,mu,S,positive_cells


def vertex_fraction(B,target):
    # product() keeps each of the two signs even on a collapsed axis.
    return Q(sum(inside(target,y) for y in product(*B)),2**len(B))


def endpoint_cases(A,s,mu,m):
    target = A["t"]
    rhos,vert,clipped = {},{},{}
    n_sign_checks = n_clipped_checks = n_strict_improvements = 0
    for i,j in product(A,repeat=2):
        B,C = A[i],A[j]
        Bi = intersect(B,target)
        assert nonempty(Bi)
        vert[i,j] = vertex_fraction(B,C)
        clipped[i,j] = vertex_fraction(Bi,C)
        rhos[i,j] = mu(intersect(B,C))/m[i]
        if s[i]<=s[j] and nonempty(intersect(B,C)):
            outside = sum(a<c or b>d for (a,b),(c,d) in zip(B,C))
            assert vert[i,j]==Q(1,2**outside)
            n_sign_checks += 1
            if nonempty(intersect(Bi,C)):
                clipped_outside = sum(a<c or b>d for (a,b),(c,d) in zip(Bi,C))
                assert clipped[i,j]==Q(1,2**clipped_outside)>=vert[i,j]
                n_strict_improvements += clipped[i,j]>vert[i,j]
                n_clipped_checks += 1
        if not nonempty(intersect(Bi,C)):
            assert clipped[i,j]==0
    th,tl,large,face = "contact_small","thin_small","contact_large","t_face"
    assert rhos[th,large]==0 and vert[th,large]==Q(1,4)
    assert 0<rhos[tl,large]<Q(1,1000) and vert[tl,large]==Q(1,4)
    assert volume(intersect(A[face],target))==0 and clipped[face,"t"]==1
    assert n_strict_improvements>0
    report = {
        "whole_corner_checks":n_sign_checks,"clipped_corner_checks":n_clipped_checks,
        "strict_clipped_improvements":n_strict_improvements,
        "touch_pair_rho_vert":[str(rhos[th,large]),str(vert[th,large])],
        "thin_pair_rho_vert":[str(rhos[tl,large]),str(vert[tl,large])],
        "collapsed_t_face_whole_clipped_vert":[str(vert[face,"t"]),str(clipped[face,"t"])],
    }
    return (rhos,vert,clipped),report


def directional_tensor(A,s,a,w,G,K,mass,probability_tables):
    children = [k for k in A if s[k]<s["t"]]
    marked = {}
    common = {}
    for index,k in enumerate(children):
        intersection = mass["t",k]
        common[k] = K/G*a["t"]*a[k]*intersection
        small_source = w[k]*a["t"]*intersection
        reverse_screen = Q(1) if k=="left" else Q(2+(index%2),3)
        large_source = w["t"]*a[k]*intersection*reverse_screen
        assert 0<=small_source<=common[k] and 0<=large_source<=common[k]
        assert small_source+large_source<=2*common[k]
        marked[k,"small_source"] = small_source
        marked[k,"large_source"] = large_source
    assert marked["left","small_source"]==marked["left","large_source"]==common["left"]>0
    assert any(marked[k,"small_source"]!=marked[k,"large_source"] for k in children)
    M = {k:marked[k,"small_source"]+marked[k,"large_source"] for k in children}
    T = sum(M.values())
    assert T==sum(marked.values())>0
    marked_tensor = {(u,v):m1*m2/T for (u,m1),(v,m2) in product(marked.items(),repeat=2)}
    assert all(sum(marked_tensor[u,v] for v in marked)==value
               ==sum(marked_tensor[v,u] for v in marked) for u,value in marked.items())
    N = {(i,j):M[i]*M[j]/T for i,j in product(children,repeat=2)}
    assert all(N[i,j]==sum(marked_tensor[(i,k),(j,l)] for k,l in product(
               ("small_source","large_source"),repeat=2))
               for i,j in N)
    assert sum(N.values())==T
    assert all(sum(N[i,j] for j in children)==M[i]==sum(N[j,i] for j in children)
               for i in children)
    wrong_denominator = sum(value*value for value in M.values())
    assert wrong_denominator != T and Q(0)<wrong_denominator/T<T
    estimates = []
    for name,table in zip(("rho","whole_vertices","clipped_vertices"),probability_tables):
        strict = False
        for budget in (Q(1),Q(5,2),Q(4)):
            capture = {j:budget*sum(M[i]/T*table[i,j] for i in children) for j in children}
            tensor_capture = sum(N[i,j]*min(1,budget*table[i,j]) for i,j in N)
            same_sigma = sum(M[j]*min(1,capture[j]) for j in children)
            assert 0<=tensor_capture<=same_sigma<=T
            assert budget!=1 or tensor_capture==same_sigma
            strict |= tensor_capture<same_sigma
            estimates.append([name,str(budget),str(tensor_capture/T),str(same_sigma/T)])
        assert strict
    return {
        "large_parent":"t","children":len(children),"original_orientation_marks":len(marked),
        "direction_small_source_large_source_totals": [
            str(sum(marked[k,side] for k in children)) for side in ("small_source","large_source")
        ],
        "T_t":str(T),"both_directions_tight_pair":"left",
        "tight_pair_common_cap_each_direction":str(common["left"]),
        "coverage_name_m_tensor_ratio_common_sigma_ratio":estimates,
        "diagonal_share":str(wrong_denominator/T**2),
        "wrong_marginal_multiplier_using_sum_M_squared":str(T/wrong_denominator),
    }


def path_terminal(A,s,d,v,m,a,w,G,K,patterns,mass,mu):
    allowed = {frozenset(edge) for edge in (
        ("t","left"),("left","midL"),("midL","k"),
        ("t","right"),("right","midR"),("midR","k"),
    )}
    C = {}
    for j,k in product(A,repeat=2):
        C[j,k] = Q(0)
        if frozenset((j,k)) in allowed:
            for mask,price in patterns.items():
                if j in mask and k in mask:
                    F = sum(w[i] for i in mask)
                    W = sum(a[i] for i in mask)
                    assert 0<F<=1 and F/W<=K/G
                    C[j,k] += a[k]*price/m[j]*F/W
    assert all(v[j]*C[j,k]==v[k]*C[k,j] for j,k in C)
    assert all(sum(C[j,k] for k in A)<=1 for j in A)
    D = {(j,k):C[j,k] if d[k]<d[j] else Q(0) for j,k in C}
    Dstar = {(k,j):v[j]*D[j,k]/v[k] for j,k in D}
    assert all(sum(Dstar[k,j] for j in A)<=1 for k in A)
    paths = {}
    for path in product(A,repeat=4):
        links = list(zip(path,path[1:]))
        fw = v[path[0]]*prod(D[edge] for edge in links)
        bw = v[path[-1]]*prod(Dstar[k,j] for j,k in reversed(links))
        assert fw==bw
        if fw:
            paths[path] = fw
    assert len(paths)==2 and all(p[-1]=="k" for p in paths)
    cap_prob = {}
    wrong_prob = {}
    endpoint_masks = [(mask,price/m["k"]) for mask,price in patterns.items() if "k" in mask]
    assert sum(p for _,p in endpoint_masks)==1
    for path,P in paths.items():
        j,k = path[1],path[-1]
        total_correct = sum(p for M,p in endpoint_masks if j in M)
        direct = mass[j,k]/m[k]
        wrong = mass[j,k]/m[j]
        assert total_correct==direct>wrong>0
        cap_prob[j] = direct
        wrong_prob[j] = wrong
        for M,p in endpoint_masks:
            mass_forward = P*p
            mass_backward = v[k]*p*prod(Dstar[b,a] for a,b in reversed(list(zip(path,path[1:]))))
            assert mass_forward==mass_backward
    both = sum(p for M,p in endpoint_masks if "left" in M and "right" in M)
    union = sum(p for M,p in endpoint_masks if "left" in M or "right" in M)
    assert both==mu(intersect(A["left"],A["right"],A["k"]))/m["k"]
    assert union==sum(cap_prob.values())-both==1
    wrong_independent = prod(cap_prob.values())
    assert both!=wrong_independent
    return {
        "D_cubed_paths_and_v_weighted_mass":[[p,str(wgt)] for p,wgt in paths.items()],
        "paths_total_mass":str(sum(paths.values())),
        "grandparent_hit_correct":{j:str(p) for j,p in cap_prob.items()},
        "grandparent_hit_wrong_ancestor_denominator":{j:str(p) for j,p in wrong_prob.items()},
        "w_shared_grandparent_both_and_union":[str(both),str(union)],
        "would_be_both_with_independent_w":str(wrong_independent),
        "positive_terminal_w_patterns":len(endpoint_masks),
    }


def dyadic(d):
    j = d.numerator.bit_length()-d.denominator.bit_length()
    return j if Q(2)**j<=d else j-1


def artificial_tail(n,d,v,m,a,w,G,h,patterns,S):
    ratio = Q(2**n)
    V = sum(v.values())
    W = {M:sum(a[j] for j in M) for M in patterns}
    assert sum(p*W[M] for M,p in patterns.items())==V
    tails = {}
    endpoint_values = set()
    endpoint_half = Q(0)
    endpoint_strict = Q(0)
    exact_equal = Q(0)
    windows = {}
    for M,p in patterns.items():
        source_F = sum(w[j] for j in M)
        changed_F = sum(w[j]/2 for j in M)
        if M:
            assert source_F>changed_F
        assert G/(G+W[M])+sum((a[i]/(G+W[M]) for i in M),Q(0))==1
        max_window = Q(0)
        for k in M:
            numerator = sum(a[j] for j in M if d[j]<=d[k]/ratio)
            strict = sum(a[j] for j in M if d[j]<d[k]/ratio)
            q = numerator/(G+W[M])
            fake_with_F = numerator/(G+source_F)
            fake_changed_F = numerator/(G+changed_F)
            if numerator:
                assert fake_with_F!=fake_changed_F
            assert q<=W[M]/(G+W[M])<1
            tails[M,k] = q
            window = sum(a[j] for j in M if d[k]/ratio<d[j]<=d[k])
            assert numerator+window==sum(a[j] for j in M if d[j]<=d[k])
            max_window = max(window,max_window)
            if k=="k":
                endpoint_values.add(q)
                endpoint_half += p/m[k]*q
                endpoint_strict += p/m[k]*strict/(G+W[M])
                if "equal_tail" in M:
                    assert d["equal_tail"]==d[k]/ratio
                    exact_equal += p
        windows[M] = max_window
        for j in {dyadic(d[j]) for j in M}:
            assert sum(a[i] for i in M if dyadic(d[i])==j)<=2*h**n
        assert max_window<=2*(n+1)*h**n
    assert exact_equal>0 and endpoint_half>endpoint_strict and len(endpoint_values)>1
    positive = [q for q in tails.values() if q]
    tau_tests = []
    int_window = sum(p*windows[M] for M,p in patterns.items())
    for tau in (min(positive),max(positive)/2):
        for strict in (True,False):
            actual = Q(0)
            for M,price in patterns.items():
                low = [k for k in M if (tails[M,k]<tau if strict else tails[M,k]<=tau)]
                val = sum(a[k] for k in low)
                assert val<=tau*(G+W[M])+windows[M]
                actual += price*val
            assert actual<=tau*(V+G*S)+int_window<=tau*(V+G*S)+2*(n+1)*h**n*S
            tau_tests.append({"tau":str(tau),"strict":strict,"actual_low_total":str(actual),
                              "tau_V_plus_GS":str(tau*(V+G*S)),
                              "integrated_window":str(int_window)})
    return {
        "cutoff_volume_ratio":str(ratio),"endpoint_w_tail_inclusive":str(endpoint_half),
        "endpoint_w_tail_strict":str(endpoint_strict),"equal_threshold_label_price_mass":str(exact_equal),
        "endpoint_distinct_auxiliary_probabilities":len(endpoint_values),"price_patterns_checked":len(patterns),
        "conditional_auxiliary_probabilities_use_only_g_and_G":True,
        "window_bound_2_h_to_n_n_plus_1_times_S":str(2*(n+1)*h**n*S),
        "low_rank_tests":tau_tests,
    }


def case(n):
    A,s,d,v,m,a,w,G,K,h,patterns,mass,mu,S,positive_cells = geometry(n)
    priors,corners = endpoint_cases(A,s,mu,m)
    return {
        "n":n,"parent_count":len(A),"parents":{j:[[str(a),str(b)] for a,b in box] for j,box in A.items()},
        "m_over_d":{j:str(m[j]/d[j]) for j in A},"v":{j:str(v[j]) for j in A},
        "G_upper":str(G),"K":str(K),"actual_positive_price_cells":positive_cells,
        "vertices":corners,"pairing":directional_tensor(A,s,a,w,G,K,mass,priors),
        "complete_marked_paths":path_terminal(A,s,d,v,m,a,w,G,K,patterns,mass,mu),
        "artificial_tail":artificial_tail(n,d,v,m,a,w,G,h,patterns,S),
    }


def report():
    return {
        "scope":(
            "True cubes, AC prices, actual disjoint full owners, and finite marked inputs in two and three dimensions. "
            "The original directed gates and the reversible three-step gates are explicitly chosen for these interfaces."
        ),
        "python":python_version(),"source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "models":[case(2),case(3)],
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out",type=Path)
    group.add_argument("--check",type=Path)
    args = parser.parse_args()
    result = report()
    data = (json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data,"certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    for model in result["models"]:
        print(f"n={model['n']} parents={model['parent_count']} price cells={model['actual_positive_price_cells']} "
              f"three-step histories={len(model['complete_marked_paths']['D_cubed_paths_and_v_weighted_mass'])}")


if __name__=="__main__":
    main()

