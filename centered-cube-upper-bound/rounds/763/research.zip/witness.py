"""R763 supplemental repair law and grouped-price KL certificates."""

from fractions import Fraction as Q
from itertools import combinations, product
from math import comb, prod

from flint import arb, ctx, fmpq, __version__ as flint_version


ctx.prec = 256


def ball(x):
    q = Q(x)
    return arb(fmpq(q.numerator,q.denominator))


def interval(c,s):
    return c-s,c+s


def meet(*intervals):
    return max(a for a,b in intervals),min(b for a,b in intervals)


def length(interval):
    a,b = interval
    return max(Q(0),b-a)


def has(J,x):
    return J[0]<=x<=J[1]


def covers(J,B):
    return has(J,B[0]) and has(J,B[1])


def multiply_linear(coef,a,b):
    values = [Q(0)]*(len(coef)+1)
    for i,v in enumerate(coef):
        values[i] += a*v
        values[i+1] += b*v
    return values


STRICT = {
    "d":(Q(-3,4),Q(1,4)),
    "c_touch":(Q(-1,8),Q(1,4)),
    "c_edge":(Q(-1),Q(-5,4)),
    "u_inside":(Q(0),Q(0)),
    "u_collapsed":(Q(9,8),Q(5,4)),
    "d_collapsed":(Q(9,8),Q(1,4)),
}
EQUAL = {
    "d":(Q(-3,4),Q(1,2)),
    "c_touch":(Q(-1,8),Q(1)),
    "u_inside":(Q(0),Q(1,2)),
    "u_collapsed":(Q(9,8),Q(2)),
    "g":(Q(0),Q(0)),
}


def repair_audit(names,sj,table):
    n = len(names)
    T = (Q(-1),Q(1))
    si = Q(1,8)
    alpha = min(Q(1,4),sj/2)
    old,repair = [],[]
    flags = []
    for name in names:
        yi,yj = table[name]
        B,J = meet(interval(yi,si),T),interval(yj,sj)
        assert B[0]<=B[1] and meet(J,T)[0]<=meet(J,T)[1]
        O = Q(sum(has(J,x) for x in B),2)
        R = length(meet(T,J))/(2*length(T))+Q(sum(has(J,x) for x in T),4)
        assert R>=alpha
        if meet(B,J)[0]>meet(B,J)[1]:
            flag = "d"
            assert O==0
        elif not covers(J,B):
            flag = "c"
            assert O==Q(1,2)
        elif not covers(J,T):
            flag = "u"
            assert O==1
        else:
            flag = "g"
            assert O==R==1
        assert flag==name[0]
        old.append(O)
        repair.append(R)
        flags.append(flag)

    d,c,u = (flags.count(k) for k in "dcu")
    r = d+c+u
    bernstein = [Q(1)]
    monomial = [Q(1)]
    for O,R in zip(old,repair):
        bernstein = multiply_linear(bernstein,O,R)
        monomial = multiply_linear(monomial,O,R-O)
    hit = sum(Q(1,(n+1)*comb(n,h))*coef for h,coef in enumerate(bernstein))
    assert hit==sum(coef/(h+1) for h,coef in enumerate(monomial))
    split = sum(Q(comb(n-r,h-d),(n+1)*comb(n,h)) for h in range(d,d+n-r+1))
    assert split==Q(1,(r+1)*comb(r,d))
    lower = split*alpha**d/Q(2**c)
    assert hit>=lower>0
    if n<=8:
        direct_hit = direct_split = Q(0)
        for repaired in product((False,True),repeat=n):
            weight = Q(1,(n+1)*comb(n,sum(repaired)))
            direct_hit += weight*prod(R if flag else O for O,R,flag in zip(old,repair,repaired))
            direct_split += weight*all(flag or state!="d" for flag,state in zip(repaired,flags))*all(
                not flag or state not in ("c","u") for flag,state in zip(repaired,flags)
            )
        assert direct_hit==hit and direct_split==split
    if n==1:
        assert hit==lower
    display = (str(hit),str(lower)) if n<=8 else (ball(hit).str(12),ball(lower).str(12))
    print(f"repair n={n:2} d,c,u={d},{c},{u} alpha={alpha} hit={display[0]} lower={display[1]}")


def grouped_price():
    t = (Q(-3),Q(3))
    labels = ("left","middle","right")
    A = {"t":t,"left":(Q(-2),Q(0)),"middle":(Q(-1,2),Q(3,2)),"right":(Q(1),Q(5,2))}
    centers = {j:(a+b)/2 for j,(a,b) in A.items()}
    d = {j:length(B) for j,B in A.items()}
    E = {j:interval(centers[j],d[j]/64) for j in A}
    assert all(length(meet(B,C))==0 for B,C in combinations(E.values(),2))
    U = ((Q(-3),Q(-1,4)),(Q(-1,4),Q(5,4)),(Q(5,4),Q(3)))
    price = (((Q(-4),Q(4)),Q(2)),((Q(-7,4),Q(-3,4)),Q(3)),
             ((Q(5,4),Q(9,4)),Q(5)))
    mu = lambda B: sum(weight*length(meet(P,B)) for P,weight in price)
    m = {j:mu(B) for j,B in A.items()}
    assert all(m[j]>d[j] for j in A)
    a = {j:length(E[j])/m[j] for j in A}
    G,K = Q(65,32),Q(4)
    hats = {"t":Q(1),"left":Q(1),"middle":Q(1,2),"right":Q(3,4)}
    source = {j:K/G*hats[j]*a[j] for j in A}
    raw = [{(i,k):coef*mu(meet(t,A[i],u))
            for i in labels
            for k,coef in enumerate((source[i]*a["t"],source["t"]*a[i]))}
           for u in U]
    masses = [sum(R.values()) for R in raw]
    total = sum(masses)
    P = [v/total for v in masses]
    for i in labels:
        for k,coef in enumerate((source[i]*a["t"],source["t"]*a[i])):
            original = coef*mu(meet(t,A[i]))
            assert sum(R[i,k] for R in raw)==original
            assert sum(R[i,k]*v/T for R,T in zip(raw,masses) for v in R.values())==original
            assert sum(v*R[i,k]/T for R,T in zip(raw,masses) for v in R.values())==original
    p = [{i:(R[i,0]+R[i,1])/T for i in labels} for R,T in zip(raw,masses)]
    plain = {i:sum(Pu*pu[i] for Pu,pu in zip(P,p)) for i in labels}
    grouped = {(i,j):sum(Pu*pu[i]*pu[j] for Pu,pu in zip(P,p)) for i,j in product(labels,repeat=2)}
    forgotten = {(i,j):plain[i]*plain[j] for i,j in grouped}
    for pair_law in (grouped,forgotten):
        assert all(sum(pair_law[i,j] for j in labels)==plain[i]==sum(pair_law[j,i] for j in labels)
                   for i in labels)
    j = "middle"
    assert grouped[j,j]>forgotten[j,j]
    Q_j = [Pu*pu[j]/plain[j] for Pu,pu in zip(P,p)]
    unnormalized = [Pu*pu[j] for Pu,pu in zip(P,p)]
    assert sum(Q_j)==1 and sum(unnormalized)==plain[j]<1
    print(f"prices p_j={plain[j]} grouped diagonal={grouped[j,j]} erased U diagonal={forgotten[j,j]}")
    assert all(has(A[j],centers[i])==(i==j) for i in labels)
    true_rho = {i:mu(meet(A[i],A[j]))/m[i] for i in labels}
    assert true_rho[j]==1 and mu(A[j])/m["t"]<1
    for name,hits in (("private_centers",{i:Q(i==j) for i in labels}),("actual_rho",true_rho)):
        conditional_hit = [sum(pu[i]*hits[i] for i in labels) for pu in p]
        average = sum(Pu*hu for Pu,hu in zip(P,conditional_hit))
        assert 0<average<1 and average==sum(plain[i]*hits[i] for i in labels)
        tilt = [Pu*hu/average for Pu,hu in zip(P,conditional_hit)]
        assert sum(tilt)==1
        lhs = -ball(average).log()
        entropy = sum(ball(q)*ball(q/Pu).log() for q,Pu in zip(Q_j,P) if q)
        loss = sum(-ball(q)*ball(h).log() for q,h in zip(Q_j,conditional_hit) if q)
        gap = entropy+loss-lhs
        tilted_entropy = sum(ball(q)*ball(q/r).log() for q,r in zip(Q_j,tilt) if q)
        assert abs(gap-tilted_entropy)<arb(2)**-200
        if name=="private_centers":
            assert tilt==Q_j and gap.contains(0)
        else:
            assert tilt!=Q_j and gap>0
        bad = sum(ball(q)*ball(q/Pu/h).log()
                  for q,Pu,h in zip(unnormalized,P,conditional_hit) if q)
        assert bad<lhs
        print(f"KL {name} common_hit={average} gap={gap.str(15)} forgotten_condition_LHS_gap={(lhs-bad).str(12)}")


def main():
    print(f"Closed intervals and exact Fraction; python-flint {flint_version}, Arb {ctx.prec} bits")
    repair_audit(("d",),Q(1,4),STRICT)
    repair_audit(tuple(STRICT),Q(1,4),STRICT)
    repair_audit(tuple(EQUAL),Q(1),EQUAL)
    repair_audit(("d",)*8+("c_touch",)*6+("u_collapsed",)*5+("g",)*13,Q(1),EQUAL)
    repair_audit(("d_collapsed",)*4+("c_edge",)*6+("u_inside",)*30,Q(1,4),STRICT)
    grouped_price()


if __name__=="__main__":
    main()

