"""R765 exact blind observation products and common-observation posterior draws."""

import argparse
from collections import Counter, defaultdict
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, combinations_with_replacement, product
import json
from math import factorial, prod
from pathlib import Path
from platform import python_version


def interval(y,r):
    return y-r,y+r


def meet(*intervals):
    return max(a for a,b in intervals),min(b for a,b in intervals)


def length(I):
    return max(Q(0),I[1]-I[0])


def inside(I,x):
    return I[0]<=x<=I[1]


def lower_band(d):
    k = d.numerator.bit_length()-d.denominator.bit_length()
    return k if Q(2)**k<=d else k-1


def fixture():
    h,L,a,G = Q(33,32),Q(1,8),32,Q(65,32)
    labels = {
        "k":(Q(0),Q(3,8)), "u0":(Q(-1,5),Q(1,2)), "u1":(Q(1,5),Q(1,2)),
        "p":(Q(-3,4),Q(3,2)), "q":(Q(3,4),Q(7,4)), "r":(Q(-5,4),Q(2)),
        "s":(Q(5,4),Q(5,2)),
    }
    A = {j:interval(y,r) for j,(y,r) in labels.items()}
    E = {j:interval(y,r/a) for j,(y,r) in labels.items()}
    d,v = ({j:length(B) for j,B in boxes.items()} for boxes in (A,E))
    assert all(length(meet(I,J))==0 for I,J in combinations(E.values(),2))
    pockets = [interval(z,Q(1,160)) for z in (Q(-1,5),Q(1,5))]
    price = [((Q(-8),Q(8)),Q(1)),(pockets[0],Q(2)),(pockets[1],Q(1))]

    def mu(I):
        return sum(w*length(meet(I,P)) for P,w in price)

    m = {j:mu(I) for j,I in A.items()}
    assert all(m[j]==d[j]+Q(3,80) for j in A)
    return A,E,d,v,m,pockets,price,mu,h,L,G


def blind_law(fit,price_states,pressure):
    A,E,d,v,m,pockets,price,mu,h,L,G = fit
    neighbors = tuple(j for j in A if d[j]>d["k"])
    bands = sorted({lower_band(d[j]) for j in neighbors})
    N = len(bands)
    assert N==3
    supports,values,load,posts = [],[],[],[]
    for z,side in price_states:
        assert inside(pockets[side],z)
        gate = {j:Q(1) for j in neighbors}
        gate.update({"u0":Q(1) if side==0 else Q(1,4),
                     "u1":Q(1,4) if side==0 else Q(1),
                     "q":Q(1) if side==0 else Q(3,4)})
        if pressure:
            gate.update({"u0":Q(1,8) if side==0 else Q(1,4),
                         "u1":Q(1,256) if side==0 else Q(1,8)})
        a = {j:v[j]*gate[j]/m[j] for j in neighbors if inside(A[j],z)}
        U = sum(a.values())
        assert U>L and a["p"]>0
        p = {j:w/U for j,w in a.items()}
        I,f = {},{}
        for j,w in p.items():
            b = lower_band(d[j])
            R = Q(2)**b
            assert R<=d[j]<2*R
            I[j] = tuple((y-z)/(h*R) for y in E[j])
            f[j] = N*2*h*R*w/v[j]
            assert -1<=I[j][0]<I[j][1]<=1
            assert f[j]<=N*2*h/U
        assert sum(p.values())==1
        supports.append(I)
        values.append(f)
        posts.append(p)
        load.append(U)

    obs_types = defaultdict(Q)
    for b in bands:
        members = [j for j in neighbors if lower_band(d[j])==b]
        cuts = sorted({Q(-1),Q(1)}|{x for I in supports for j in members for x in I[j]})
        for lo,hi in zip(cuts,cuts[1:]):
            v0 = (lo+hi)/2
            li = []
            for I,f in zip(supports,values):
                owners = [j for j in members if inside(I[j],v0)]
                assert len(owners)<=1
                li.append(f[owners[0]] if owners else Q(0))
            obs_types[tuple(li)] += (hi-lo)/(2*N)
    assert sum(obs_types.values())==1
    states = range(len(price_states))
    assert all(sum(q*f[i] for f,q in obs_types.items())==1 for i in states)
    cross = {}
    checks = []
    for i,j in product(states,repeat=2):
        f_integrated = sum(q*f[i]*f[j] for f,q in obs_types.items())
        pairs = []
        for u,w in product(neighbors,repeat=2):
            if lower_band(d[u])==lower_band(d[w]):
                overlap = length(meet(supports[i][u],supports[j][w]))/2
                if overlap:
                    pairs.append((u,w,overlap))
        volume_overlap = sum(ov for u,w,ov in pairs)
        assert f_integrated==sum(values[i][u]*values[j][w]*q/N for u,w,q in pairs)
        upper = 4*h*h*N/(load[i]*load[j])*volume_overlap
        assert 0<=f_integrated<=upper
        cross[i,j] = f_integrated
        checks.append({
            "a_b_price_state_indices":[i,j],"cross_integral":str(f_integrated),"upper":str(upper),
            "overlap_under_standard_uniform":str(volume_overlap),
            "colliding_true_label_pairs":[[u,w,str(q)] for u,w,q in pairs],
        })
    return cross,sorted(obs_types.items()),{
        "prices":[str(z) for z,side in price_states],"gate_pressure":pressure,"anchor_t":"p",
        "direction":"small_source","k":"k","high_load_L0":str(L),
        "U_per_price":list(map(str,load)),"N_q":N,"distinct_blind_atoms":len(obs_types),
        "pi_u_per_price":[{j:str(w) for j,w in p.items()} for p in posts],"cross_checks":checks,
        "blind_atoms_q_mass_and_f_per_price":[[str(q),list(map(str,f))] for f,q in sorted(obs_types.items())],
    }


def posterior_audit(cross,obs_types):
    prior = (Q(3,8),Q(1,2),Q(1,8))
    n = len(prior)
    states = range(n)
    eta,delta = Q(1,4),Q(1,2)
    bad_pairs = {(i,j) for i,j in product(states,repeat=2) if cross[i,j]<1-delta}
    assert bad_pairs and (0,1) in bad_pairs and (0,2) not in bad_pairs
    prior_bad = sum(prior[i]*prior[j] for i,j in bad_pairs)
    result = []
    for m in (1,2,3):
        q_total = evidence_total = bad_low = bad_pair_high = mass_without_denominator = Q(0)
        covariance_refs, actual = defaultdict(Q),defaultdict(Q)
        positive=0
        for choices in combinations_with_replacement(range(len(obs_types)),m):
            raw_multiplicity = factorial(m)//prod(factorial(c) for c in Counter(choices).values())
            q = raw_multiplicity*prod(obs_types[t][1] for t in choices)
            likelihood = [prod(obs_types[t][0][i] for t in choices) for i in states]
            w = [p*f for p,f in zip(prior,likelihood)]
            g = sum(w)
            q_total += q
            evidence_total += q*g
            mass_without_denominator += q*g*g
            if not g:
                continue
            positive += 1
            post = [wi/g for wi in w]
            assert sum(post)==1
            if g<eta:
                bad_low += q*g
            for i,j in product(states,repeat=2):
                Ppair = q*g*post[i]*post[j]
                assert Ppair==q*w[i]*w[j]/g
                actual[i,j] += Ppair
                covariance_refs[i,j] += q*likelihood[i]*likelihood[j]
                if g>=eta and (i,j) in bad_pairs:
                    bad_pair_high += Ppair
        assert q_total==evidence_total==sum(actual.values())==1
        assert all(sum(actual[i,j] for j in states)==prior[i]==sum(actual[j,i] for j in states)
                   for i in states)
        assert all(covariance_refs[i,j]==cross[i,j]**m for i,j in product(states,repeat=2))
        cross_power_budget = sum(prior[i]*prior[j]*cross[i,j]**m for i,j in bad_pairs)/eta
        coarse = prior_bad*(1-delta)**m/eta
        bad_total = bad_low+bad_pair_high
        assert 0<bad_low<=eta and 0<bad_pair_high<=cross_power_budget<=coarse
        assert bad_total<=eta+coarse<=eta+(1-delta)**m/eta
        assert mass_without_denominator>1
        result.append({
            "m":m,"positive_blind_observation_types":positive,
            "both_marginals":[str(sum(actual[i,j] for j in states)) for i in states],
            "posterior_resample_joint":[[str(actual[i,j]) for j in states] for i in states],
            "bad_g_below_eta":str(bad_low),"bad_c_and_g_at_least_eta":str(bad_pair_high),
            "bad_union":str(bad_total),"pre_prior_bad_mass":str(prior_bad),
            "cross_power_upper":str(cross_power_budget),"union_upper_eta_plus_prior_bad_delta_power":str(eta+coarse),
            "would_be_mass_without_g_denominator":str(mass_without_denominator),
        })
    return {"scope":"Explicit discrete prior, distinct from AC parent pricing.", "prior":list(map(str,prior)),
            "eta":str(eta),"delta":str(delta),"bad_ordered_price_pairs":sorted(bad_pairs),"by_m":result}


def multiplicity_audit(fit):
    A,E,d,v,m,pockets,price,mu,h,L,G = fit
    edges = sorted({x for I in A.values() for x in I}|{x for P,w in price for x in P})
    reps = sorted(set(edges+[(x+y)/2 for x,y in zip(edges,edges[1:])]+[edges[0]-1,edges[-1]+1]))
    D = {j:Q(2)**lower_band(d[j]) for j in A}
    assert all(D[j]<=d[j]<2*D[j] for j in A)
    nfree = {}
    for x in reps:
        M = tuple(j for j in A if inside(A[j],x))
        regular = sum(v[j]/d[j] for j in M)
        coarsened = sum(v[j]/D[j] for j in M)
        assert coarsened<=2*regular
        if regular:
            nfree[M] = coarsened/regular

    B = meet(A["p"],A["u0"])
    assert length(B)>0
    cells = []
    for x,y in zip(edges,edges[1:]):
        S = meet((x,y),B)
        if length(S)>0:
            mid=(S[0]+S[1])/2
            M=tuple(j for j in A if inside(A[j],mid))
            cells.append((M,mu(S),sum(v[j]/d[j] for j in M)))
    assert sum(w for M,w,Wd in cells)==mu(B)
    result = []
    for H in (Q(1),Q(3,16)/G):
        keep = [(M,w,Wd) for M,w,Wd in cells if Wd<=H*G]
        keep_mass = sum(w for M,w,Wd in keep)
        assert keep_mass>0
        weights = [(M,length(B)*w/keep_mass,Wd) for M,w,Wd in keep]
        assert sum(w for M,w,Wd in weights)==length(B)
        first = sum(w*Wd for M,w,Wd in weights)
        second = sum(v[j]/d[j]*sum(w for M,w,Wd in weights if j in M) for j in A)
        assert first==second<=H*G*length(B)
        result.append({"H":str(H),"kept_original_price_mass":str(keep_mass),
                       "omitted_original_price_mass":str(mu(B)-keep_mass),
                       "nu_mass":str(length(B)),"integral_Wd":str(first),"upper_HG_times_abs_B":str(H*G*length(B))})
    assert Q(result[0]["omitted_original_price_mass"])==0<Q(result[1]["omitted_original_price_mass"])
    return {
        "all_space_representatives_for_N_free_bound":len(reps),
        "exact_max_of_coarsened_over_Wd":str(max(nfree.values())),
        "B_tu":list(map(str,B)),"trim_checks":result,
        "scope":"The low-H trim is an algebraic pressure test on genuine pricing.",
    }


def report():
    fit = fixture()
    states = [(Q(-1,5),0),(Q(1,5),1),(Q(-1,5)+Q(1,320),0)]
    old_cross,_,old = blind_law(fit,states[:2],False)
    assert old_cross[0,1]>1
    assert [p[:2] for p in old["cross_checks"][1]["colliding_true_label_pairs"]]==[["u0","u1"]]
    cross,types,new = blind_law(fit,states,True)
    assert 0<cross[0,1]<Q(1,2)<1<cross[0,2]
    return {
        "scope":(
            "Actual R764 1D parents, disjoint full owners and nonuniform AC price. "
            "The f_z are evaluated at explicit price points under the displayed gates; the posterior test uses a separately chosen discrete prior. "
            "These checks concern the finite blind-observation interface."
        ),
        "python":python_version(),"source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "original_r764_gates":old,"pressure_gates":new,"posterior":posterior_audit(cross,types),
        "N_free_and_price_multiplicity":multiplicity_audit(fit),
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out",type=Path)
    group.add_argument("--check",type=Path)
    args = parser.parse_args()
    result = report()
    data = (json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data,"certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    print("Thirteen exact price-pair products and posterior resampling at m=1,2,3.")


if __name__=="__main__":
    main()

