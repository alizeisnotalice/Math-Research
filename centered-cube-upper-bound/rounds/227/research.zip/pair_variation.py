#!/usr/bin/env python3
"""R227 exact finite two-clock variation and centered integration-by-parts checks."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
CONTRACT_SHA256='86fcda8985ad573832554b3fe58d7f886a42af557143bd8f4eb9c60e76f88294'
def rat(x):return f'{x.numerator}/{x.denominator}'
def summary(x,small):
    out={'sha256_hex_fraction':hashlib.sha256((format(x.numerator,'x')+'/'+format(x.denominator,'x')).encode()).hexdigest(),'sign':(x>0)-(x<0),'numerator_bits':abs(x.numerator).bit_length(),'denominator_bits':x.denominator.bit_length()}
    if small:out['exact']=rat(x)
    return out

def threshold_groups(n,lo,hi,design):
    if design=='clustered':return [(lo,n)],[(hi,n)]
    if design=='equal':return [((lo+hi)/2,n)],[((lo+hi)/2,n)]
    if design=='outside':return [(lo/2,n)],[(2*hi,n)]
    groups=min(n,16) if design=='grouped_alternating' else n
    assert n%groups==0
    v=[];u=[]
    for slot in range(1,2*groups+1):
        threshold=lo+(hi-lo)*F(slot,2*groups+1);target=u if slot%4 in (0,1) else v;target.append((threshold,n//groups))
    assert sum(c for _,c in v)==sum(c for _,c in u)==n
    return v,u

def weight(t,groups):
    result=F(1)
    for alpha,count in groups:result*=min(F(1),alpha/t)**count
    return result

def case(n,lo,hi,design,mass_recipe):
    vg,ug=threshold_groups(n,lo,hi,design);scale=F(10)**(6 if n<=8 else 12 if n<=64 else 24);mu=F(1)
    mv=F(1) if mass_recipe=='equal' else scale if mass_recipe=='extreme_v' else 1/scale if mass_recipe=='extreme_u' else weight(lo,ug)/weight(lo,vg)*(hi/lo)**(n//2)
    assert mv>0 and mu>0 and hi/lo<=2
    knots=sorted(set([lo,hi]+[x for x,_ in vg+ug if lo<x<hi]));sigmas={}
    for t in knots:
      a=mv*weight(t,vg);b=mu*weight(t,ug);sigmas[t]=a/(a+b)
    segments=[];energy=F(0);variation=F(0);weighted_mass_upper=F(0);qs=[];kvlist=[];kulist=[]
    for left,right in zip(knots,knots[1:]):
      mid=(left+right)/2;kv=sum(c for x,c in vg if x<mid);ku=sum(c for x,c in ug if x<mid);q=ku-kv;sl=sigmas[left];sr=sigmas[right];delta=sr-sl;E=q*delta;V=abs(delta);W=delta/q if q else sl*(1-sl)*(right/left-1)
      assert E>=0 and W>=0 and W<=(right/left-1)/4 and V==(abs(q)*W if q else 0) and E==q*q*W
      energy+=E;variation+=V;weighted_mass_upper+=W;qs.append(q);kvlist.append(kv);kulist.append(ku)
      segments.append({'left':rat(left),'right':rat(right),'k_v':kv,'k_u':ku,'q_hprime':q,'sigma_left':summary(sl,n<=8),'sigma_right':summary(sr,n<=8),'sigma_delta':summary(delta,n<=8),'energy_exact':summary(E,n<=8),'TV_sigma_exact':summary(V,n<=8),'sigma_weight_mass_exact_if_q_nonzero_else_log_upper':summary(W,n<=8),'q_zero_uses_log_ratio_le_ratio_minus_one':q==0})
    qtv=sum(abs(qs[i+1]-qs[i]) for i in range(len(qs)-1));extended=abs(qs[0])+qtv+abs(qs[-1]);boundary=qs[-1]*(sigmas[hi]-F(1,2))-qs[0]*(sigmas[lo]-F(1,2));jumpterm=sum(((sigmas[knots[i+1]]-F(1,2))*(qs[i+1]-qs[i]) for i in range(len(qs)-1)),F(0));parts=boundary-jumpterm
    internal_count_increase=kvlist[-1]-kvlist[0]+kulist[-1]-kulist[0];remaining=2*n-kvlist[-1]-kulist[-1];initial_count=kvlist[0]+kulist[0]
    length_upper=hi/lo-1;checks={'positive_mass':True,'log_window_le_log2':hi/lo<=2,'q_abs_le_n':all(abs(q)<=n for q in qs),'q_total_variation_le_2n':qtv<=2*n,'centered_exact_integration_by_parts':energy==parts,'initial_endpoint_abs_le_activated_count':abs(qs[0])<=initial_count,'internal_TV_le_total_clock_count_increase':qtv<=internal_count_increase,'final_endpoint_abs_le_remaining_count':abs(qs[-1])<=remaining,'extended_variation_le_2n':extended<=2*n,'energy_le_half_extended_variation':energy<=F(extended,2),'energy_le_n':energy<=n,'finite_weighted_Cauchy':variation*variation<=energy*weighted_mass_upper,'weight_mass_upper_le_rational_length_over_4':weighted_mass_upper<=length_upper/4,'TV_squared_le_n_rational_length_over_4':variation*variation<=n*length_upper/4,'TV_squared_le_n_over_4':variation*variation<=F(n,4)}
    assert all(checks.values())
    values={'m_v':mv,'m_u':mu,'sigma_lo':sigmas[lo],'sigma_hi':sigmas[hi],'energy_E':energy,'TV_sigma':variation,'TV_sigma_squared':variation*variation,'weighted_mass_upper':weighted_mass_upper,'centered_boundary_term':boundary,'centered_jump_sum':jumpterm,'parts_energy':parts,'energy_over_n':energy/n,'rational_log_length_upper_ratio_minus_one':length_upper}
    return {'n':n,'window_lo':rat(lo),'window_hi':rat(hi),'design':design,'mass_recipe':mass_recipe,'v_threshold_groups':[{'alpha':rat(x),'count':c} for x,c in vg],'u_threshold_groups':[{'beta':rat(x),'count':c} for x,c in ug],'values':{k:summary(x,n<=8) for k,x in values.items()},'q_TV_internal':qtv,'q_extended_variation':extended,'count_budget':{'left_activated':initial_count,'internal_increase':internal_count_increase,'right_remaining':remaining,'sum':initial_count+internal_count_increase+remaining},'segments':segments,'checks':checks}

def envelope_F(sigma,A,B):
    assert 0<sigma<1 and A>0 and B>0
    return B*B*sigma/(1-sigma)-A*B if sigma<=A/(A+B) else A*B-A*A*(1-sigma)/sigma

def envelope_psi(sigma,A,B):
    return min(A*A*(1-sigma)/sigma,B*B*sigma/(1-sigma))

def weighted_case(n,lo,hi,design,mass_recipe,A,B):
    vg,ug=threshold_groups(n,lo,hi,design);scale=F(10)**(6 if n<=8 else 12 if n<=64 else 24);mu=F(1)
    mv=F(1) if mass_recipe=='equal' else scale if mass_recipe=='extreme_v' else 1/scale if mass_recipe=='extreme_u' else weight(lo,ug)/weight(lo,vg)*(hi/lo)**(n//2)
    knots=sorted(set([lo,hi]+[x for x,_ in vg+ug if lo<x<hi]));sig={};fv={};point_count=0;point_records=[]
    for t in knots:
      a=mv*weight(t,vg);b=mu*weight(t,ug);sigma=a/(a+b);f=envelope_F(sigma,A,B);psi=envelope_psi(sigma,A,B)
      assert -A*B<=f<=A*B and 0<psi<=A*B
      for factor in (F(1),F(2)):
        e=factor*max(a/A,b/B);pair=a*b/(e*e);assert pair<=psi and (factor!=1 or pair==psi);point_count+=1
      point_records.append({'t':rat(t),'sigma':summary(sigma,n<=8),'F':summary(f,n<=8),'psi':summary(psi,n<=8),'point_envelope_at_e_max_and_twice':True});sig[t]=sigma;fv[t]=f
    energy=F(0);flux=F(0);mass_upper=F(0);qs=[];segments=[];cross_count=0
    for left,right in zip(knots,knots[1:]):
      mid=(left+right)/2;q=sum(c for x,c in ug if x<mid)-sum(c for x,c in vg if x<mid);df=fv[right]-fv[left];E=q*df;V=abs(df);W=df/q if q else envelope_psi(sig[left],A,B)*(right/left-1)
      cross=(sig[left]-A/(A+B))*(sig[right]-A/(A+B))<0;cross_count+=int(cross)
      assert E>=0 and W>=0 and E==q*q*W and V==(abs(q)*W if q else 0) and W<=A*B*(right/left-1)
      energy+=E;flux+=V;mass_upper+=W;qs.append(q);segments.append({'left':rat(left),'right':rat(right),'q':q,'crosses_F_breakpoint':cross,'Delta_F':summary(df,n<=8),'weighted_energy':summary(E,n<=8),'flux_upper':summary(V,n<=8),'psi_mass_exact_if_q_nonzero_else_log_upper':summary(W,n<=8)})
    tvq=sum(abs(qs[i+1]-qs[i]) for i in range(len(qs)-1));extended=abs(qs[0])+tvq+abs(qs[-1]);boundary=qs[-1]*fv[hi]-qs[0]*fv[lo];jumps=sum((fv[knots[i+1]]*(qs[i+1]-qs[i]) for i in range(len(qs)-1)),F(0));length_upper=hi/lo-1
    checks={'centered_F_integration_by_parts':energy==boundary-jumps,'extended_TV_q_le_2n':extended<=2*n,'weighted_energy_le_AB_extended_variation':energy<=A*B*extended,'weighted_energy_le_2nAB':energy<=2*n*A*B,'weighted_finite_Cauchy':flux*flux<=energy*mass_upper,'psi_mass_upper_le_AB_rational_length':mass_upper<=A*B*length_upper,'flux_squared_le_2nLupper_A2B2':flux*flux<=2*n*length_upper*A*A*B*B,'all_pointwise_envelope_checks':True}
    assert all(checks.values())
    values={'A':A,'B':B,'m_v':mv,'m_u':mu,'weighted_energy':energy,'flux_upper':flux,'flux_upper_squared':flux*flux,'psi_mass_upper':mass_upper,'boundary_term':boundary,'internal_jump_sum':jumps,'exact_parts_energy':boundary-jumps,'rational_log_length_upper':length_upper,'target_squared_bound':2*n*length_upper*A*A*B*B}
    return {'n':n,'window_lo':rat(lo),'window_hi':rat(hi),'design':design,'mass_recipe':mass_recipe,'A':rat(A),'B':rat(B),'A_over_B':rat(A/B),'values':{k:summary(v,n<=8) for k,v in values.items()},'point_check_count':point_count,'F_breakpoint_crossing_segment_count':cross_count,'q_extended_variation':extended,'point_records':point_records,'segments':segments,'checks':checks,'scope':'Same positive clocks a,b define sigma and pointwise pair denominator bounds; no original posterior/envelope qualifications supplied.'}

def weighted_envelope_stages():
    stages=[]
    for name,ns,lo,hi,design_mass in [('initial',(2,8),F(1),F(2),(('alternating','equal'),('clustered','equal'),('equal','extreme_v'))),('pressure',(16,64),F(1),F(3,2),(('alternating','balanced'),('clustered','balanced'),('outside','extreme_u'))),('expanded',(512,4096),F(1),F(2),(('grouped_alternating','equal'),('clustered','balanced'),('outside','extreme_v')))]:
      rows=[weighted_case(n,lo,hi,design,mass,A,F(1)) for n in ns for design,mass in design_mass for A in (F(1),F(1,100),F(100))]
      stages.append({'stage':name,'case_count':len(rows),'cases':rows})
    zeros=[]
    for A,B in ((F(0),F(1)),(F(1),F(0)),(F(0),F(0))):
      e=F(1);a=A/2;b=B/2;assert a<=A*e and b<=B*e and a*b==0
      zeros.append({'A':rat(A),'B':rat(B),'finite_e':rat(e),'pair_clock_a':rat(a),'pair_clock_b':rat(b),'pair_traffic':'0/1','no_division_by_zero':True,'positive_capacity_F_formula_not_invoked':True,'scope':'Zero column from a<=A*e or b<=B*e with finite e; outside the strictly positive-clock lemma.'})
    return stages,zeros

def main(output):
    menus=[('initial',(1,2,4,8),F(1),F(2),('alternating','clustered','equal'),('equal','extreme_v','extreme_u')),('pressure',(16,64),F(1),F(3,2),('alternating','clustered','equal','outside'),('balanced','extreme_v','extreme_u')),('expanded',(512,4096),F(1),F(2),('grouped_alternating','clustered','outside'),('equal','balanced','extreme_v','extreme_u'))];stages=[]
    for name,ns,lo,hi,designs,masses in menus:
      rows=[case(n,lo,hi,design,mass) for n in ns for design in designs for mass in masses];stages.append({'stage':name,'case_count':len(rows),'cases':rows});print(name,len(rows),'exact cases passed',flush=True)
    weighted,zeros=weighted_envelope_stages()
    result={'schema':'R227_two_product_clock_variation_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'contract_sha256':CONTRACT_SHA256,'arithmetic':'Fraction and arbitrary-precision integers; no numerical logs or floats','formula_and_constants':{'q':'hprime=k_u-k_v','sigma_derivative':'sigma*(1-sigma)*q in log t','energy_exact':'sum_segments q*(sigma_right-sigma_left)','TV_sigma_exact':'sum_segments abs(sigma_right-sigma_left)','centered_parts':'E=[q*(sigma-1/2)]_lo^hi-sum_internal (sigma-1/2)*Delta_q','extended_variation_budget':'abs(q_lo)+TV(q)+abs(q_hi)<=2n','energy_bound':'E<=n','Cauchy_bound':'TV(sigma)^2<=n*L/4, L=log(t_hi/t_lo)','rational_certified_comparison':'L<=t_hi/t_lo-1<=1, hence TV(sigma)^2<=n/4','constant_scope':'Two each-n-coordinate positive product clocks without deletions only.'},'stages':stages,'case_count':sum(st['case_count'] for st in stages),'weighted_pair_envelope_stages':weighted,'weighted_positive_capacity_case_count':sum(st['case_count'] for st in weighted),'weighted_zero_capacity_branches':zeros,'weighted_formula':{'F_range':'[-AB,AB]','dF_d_logratio':'psi','psi_le_AB':True,'energy_bound':'sum q*DeltaF<=2nAB','flux_squared_bound':'(sum abs(DeltaF))^2<=2n*L*A^2*B^2','clock_convention':'Pointwise weights are the same a,b, including static masses, that define sigma.','original_envelope_entry':'Not supplied or inferred.'},'scope':['Exact finite two-source systems plus the stated elementary scalar derivation, not general multi-source traffic payment.','Thresholds and masses are algebraic recipes, not certified physical C geometry or posterior/history input.','No original FULL realization, source/selector budget, fitted order or asymptotic inference.','Large rational values use canonical hex fraction SHA256/bit lengths; all threshold and mass recipes reproduce them.','No deletion gates in this two-clock proof; new jumps would require their own signed account.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'pair_variation.json');args=ap.parse_args();main(args.output)
