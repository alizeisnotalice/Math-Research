# R227 two-clock variation：独立公式与运行前方案

只讨论两个各n坐标、质量正的product clocks，无删除：a=mv∏min(1,alpha_i/t)，b=mu∏min(1,beta_i/t)，sigma=a/(a+b)，q=h'=ku−kv（h=log(a/b)）。阈值之间sigma'=sigma(1−sigma)q，其中导数相对于log t。sigma在阈值连续，q分段整数。

令f=sigma−1/2，E=∫sigma(1−sigma)q²dlogt。精确分部式为E=[qf]_lo^hi−Σ f(tj)Δq_j。于是E≤(|q_lo|+|q_hi|+TV(q))/2。每个k从0单调到n；用窗口左已激活计数、窗口内部增加计数及右端剩余计数，得|q_lo|+TV(q)+|q_hi|≤2n。因此这里其实E≤n，比3n/4n保守常数更强。这只证明这个双源归一系统的标量不等式，尚无一般多源原测度回代。

TV(sigma)=∫sigma(1−sigma)|q|。Cauchy给TV(sigma)²≤E∫sigma(1−sigma)dlogt≤n*L/4。因此L≤log2时可用纯有理上界log2≤1，核TV²≤n/4。每个q非零段的权重积分恰(sigma_right−sigma_left)/q；q零段用sigma(1−sigma)*(right/left−1)上界，不需要浮点log。

三阶段有限菜单：初始n=1,2,4,8，窗口[1,2]，交替阈值/两团/相同clocks，质量比1、10^6、10^−6（36例）；压力n=16,64，窗[1,3/2]，交替/两团/相同/阈值全部窗外，质量balanced、10^12、10^−12（24例）；扩大n=512,4096，窗[1,2]，每clock16组交替阈值/两团/窗外阈值，质量1、balanced、10^24、10^−24（24例；等质量保留交替分组的非饱和对照）。balanced只为确定性质量配方，不认证优化；阈值交替顺序u,v,v,u反复，实际q有正负段。

每例用Fraction保存阈值及质量配方，逐段核sigma端点差、E=Σq Δsigma、精确分部式、总变差预算和两步Cauchy平方界。大有理数只存规范hex分子/分母SHA及bit长度，所有配方可复现。不评价真实log或拟合阶，不把有限模拟称FULL、多源预算、真实阈值几何或后验资格。脚本自足、--output、无runtime/路径，完整JSON重复核字节一致。

## 实际运行结果

三阶段36/24/24，共84个精确双clock系统全部通过：逐段幂关系、sigma连续端点、E分部恒等、extended q变差≤2n、E≤n、有限加权Cauchy及TV(sigma)²≤n*(hi/lo−1)/4≤n/4。全程Fraction和整数，没有浮点log证书。

扩大阶段n=512与4096使用每clock16组交替阈值，并保等质量对照，以实际测到q正负摆动而非仅饱和sigma；极端质量比与clustered/window-exterior分支均完整保留。zero-q相同clocks给E=TV=0，单独零除已规避。

n=4096、clustered阈值alpha=lo=1,beta=hi=2、balanced质量mv=2^2048,mu=1的E/n精确为(2^2048−1)/(2^2048+1)，仍严格小于1。它是有限式，不是对一般流量的维数阶拟合。

推导结果对这里的无删除双源系统有效，给比父级最初保守3n/4n更强的E≤n、TV²≤nL/4。尚未把它转成原多源两Pi/receiver/history/selector预算，也未认证alpha,beta来自真实C几何。若引入删除或改变归一分母，必须另列新的jump与预算，不能直接搬用本标量证明。

最终显式--output完整复跑JSON逐字节相同，SHA256=328108b97340680117bb26aa25973238673519b12310e49424c41b054eb8d2f5。源码/合同指纹在JSON，所有大有理结果以规范hex分子/分母SHA与bit长度记录，阈值与质量配方完整可复现，无runtime/路径字段。

复现：

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/227/work/pair_variation.py
```

## Weighted pair-envelope：运行前精确推导与菜单

保持原84例结果。正静态A,B下，令sigma由同两个正clock a,b构成；点态比较中的w_v,w_u在本验证中就是a,b，包含其静态质量，不能把含质量sigma与未含质量w混合。若e≥max(a/A,b/B)，则ab/e²≤psi=min(A²(1−sigma)/sigma,B²sigma/(1−sigma))。

给定分段F：sigma≤A/(A+B)时F=B² sigma/(1−sigma)−AB，否则F=AB−A²(1−sigma)/sigma。两式在分界同为0，F∈[−AB,AB]，dF/dh=psi，且psi≤AB。相同分段分部给E_F=Σq DeltaF=[qF]−ΣF Deltaq≤AB*extendedTV(q)≤2nAB。weighted flux=Σabs(DeltaF)，其平方由Cauchy≤E_F∫psi≤2nL A²B²。跨分界的段直接用准确端点F差，不能只取一侧导数。

新增54例：每阶段6个上下文，各配(A,B)=(1,1),(1/100,1),(100,1)。initial n2/8的alternating-equal,clustered-equal,equal-extreme_v；pressure n16/64的alternating-balanced,clustered-balanced,outside-extreme_u；expanded n512/4096的grouped_alternating-equal,clustered-balanced,outside-extreme_v。窗口沿前述各阶段。每阈值节点选e=max(a/A,b/B)及其两倍，精确核点态pair≤psi；每段核分部、energy、weighted Cauchy及flux²≤2n(hi/lo−1)A²B²。

另A=0或B=0三种组合单列：用a≤Ae,b≤Be、e有限的零column定义，导致至少一个pair权为零，直接定义零交通，不代入正容量F公式或除0。仍不自动声称原small-envelope、实际后验或一般多源预算。

## Weighted pair-envelope实际结果

新增54个正容量例（18/18/18，n至4096）全部通过：点态e=max(a/A,b/B)及其两倍的pair≤psi、F范围、centered分部、weighted energy≤2nAB、有限weighted Cauchy及flux²≤2n(hi/lo−1)A²B²。总计1692个点态e检查，实际出现27个跨F分界的段；这些段仍用两端分段F准确差值，没有错用单侧公式。三个A0/B0零容量分支均直接零交通，未除0。原84个未加权例完整保留且复跑通过。

这仍是同两个clock a,b定义sigma的有限验证与标量推导，不认证原small-envelope或多源Π/来源费用的接入条件。最终显式--output全JSON复跑逐字节相同，更新SHA256=d87adcecb7e7027d30e81e95b361cfd25044df3079eacdc4b41bb2e82c04d070。
