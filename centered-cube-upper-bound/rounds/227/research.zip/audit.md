# R227 独立审查

## 作者稿前：低测试门的权变化筛查

已读task_contract.md，沿用R226已独审的新静态门与真实来源资格，不重证其付款。尚未读本轮作者稿。当前仅有原P_lo=P_cur[Q_v<rp_yD_yv]，terminal good v满足p_yw_g(v)≤KQ_v，terminal bad u满足KQ_u<p_yw_g(u)。以下结论只作准确新接口筛查，未预认根阶预算。

### 1. 真正可推的静态收缩及K/ε依赖

固定实际(ω,V,x,j,y)，l=a/cj≤g；空clock置零，非零high行p_y>0、eg>0。w_l、w_g均正。D=w_l−w_g，低门严格给D>0。good与低门合并得到

    w_g<Kr(w_l−w_g)，
    w_g/w_l<c:=Kr/(1+Kr)，
    D/w_l>η:=1/(1+Kr)，
    log(w_l/w_g)>ell_*:=log(1+1/(Kr))。

r=16Λ/(3Kε_st)时，Kr=16Λ/(3ε_st)，所以

    c=16Λ/(16Λ+3ε_st)，
    η=3ε_st/(16Λ+3ε_st)，
    ell_*=log(1+3ε_st/(16Λ))。

K完全抵消。增大K能改善Q势下降比例3r，却不会将这个clock收缩改成更强的K阶常数。小ε_st时相对下降与log阈值均为O(ε_st)，任何用其倒数的估计须保ε_st^−1损失。该门只给最低相对drop，不给D本身绝对下界，因为w_l可很小；也不给logdrop上界。事实上logdrop=∫_l^g k_t(v)dlogt仍只知≤nlog(g/l)≤nlog2。

已用本机Fraction实际核9组K/ε的上述常数关系及K抵消，均通过；不是实际FULL实例或一般支付证据。

### 2. 归一后不继承逐源收缩

当前good v∈Zg，原Zt递减，所以v在[l,g]全程存活。对这些v，精确Radon–Nikodym比为

    dΠ_g/dΠ_l(v)=[w_g(v)/w_l(v)]·e_l/e_g。

因此新收缩只给≤c e_l/e_g，不给≤c。eg由high控制的是p_yeg≥2Kq，不能据此把e_l/eg当输入/维数一致常数，更不能在pβ真实dx积分后免费恢复。删除只会进一步减少e_t并放大存活源的归一权；即使不删除，其他源更快下降也可令该good源Π质量上升。

已用本机有理数核两原子归一恒等式：两初权均1，终权1/2和1/4，则第一原始权收缩1/2，但其Π终/初比为4/3。该小代数检查不具原C几何、good/bad/high/history全部资格，不称FULL反例；它仅说明丢掉e_l/eg在逻辑上没有依据。

固定terminal集合G_lo⊂Zg时，合法的弱质量比较是

    Π_g(G_lo) ≤c(e_l/e_g)Π_l(G_lo)。

还可精确写终端相对熵

    KL(Π_g||Π_l)=log(e_l/e_g)−E_{Π_g}log(w_l/w_g)≥0，
    ell_*Π_g(G_lo)≤log(e_l/e_g)−KL(Π_g||Π_l)≤log(e_l/e_g)。

这里Π_g≪Π_l，删除源只在Π_g上零质量；所有有限原行w正，公式有标准有限截断解释。它仍需实际degree比控制，没有出现免费可积熵预算。

### 3. 一个真实但尚不足的全clock熵/变差上界

在Z不跳的区间，设m_t=∫k_t(z)Π_t(dz)。则

    −∂logt log e_t=m_t。

删除时e_t下降，故其正log跳加在总degree损失中。因此原合法clock的good/bad任意正子门满足

    ∫∫ δ_t(v,u)·原正门 Π_t(dv)Π_t(du)dlogt
      ≤∫_l^g m_t dlogt
      ≤log(e_l/e_g)。

该估计保et且无坐标独立假设；结合粗δ≤n及原窗宽还可取min{nlog2,log(e_l/e_g)}。低门给逐源最低logdrop，不给这个总degree损失的上界，故不能仅由收缩推出一般root或εX付款。用logx≤x−1也只是把困难移成e_l/eg来源比，不能删分母。

沿上游一次hardcap32Λ/3，单纯这种row entropy路线至多给

    P_lo ≤(32Λ/3)EΣV∫E_V dx∫high p_yβV(dy) log(e_l(y)/e_g(y))。

要从中付εX+C√n polylog(n)Wν，仍需真实同x、同β/ν、原history门下的加权entropy/degree预算；FIRST只授∫pβ≤q，不授额外log矩。该式是准确条件接口，不把重命名的余项算作新付款。

### 4. 最早还需要几何或合法signed结构的位置

需要控制的是实际p_yβ/e_t对权变化、相对下降与两个目标槽的联合占用。单源w_g/w_l收缩与Q势下降只说明端点关系，不能限制有多少y指向同一v、同一源在不同receiver/scale/j下的复用，也不能支配β−ν的excess源。固定j,t conductance对称的stationary底测度是e_tν，不是β或ν；源交换仍带p_y/e_t和转置后的第三来源Π/score。当前低Q、high、capture/history一般不对称，不能用无环/可逆的名称替代拥塞预算。

若作者改用核内hard shell−bulk补偿，权仍须取实际原Ω或其wholeclock对应物，冻结终端s/L沿辅助尺度，不能将actual p_y换成中间尺度p_ell再沿用FIRST。若从消hard核后的式子回贴QG或hard面，不能再领16/3；也不能把相对收缩当作对receiver点x的核积分上界。真正的新定理可以是直接原P_lo付款，或有明确原测度回代且最终Young费用合格的联合预算；不要求作者先证明一个过强独立包络。

## 原signed付款审计清单

1. 先指出未消费的原negative是哪一项、其原系数/共同测度/来源槽/门；不能把R226高门已付后的余项自动配一份新负项。旧signed、suffix、删除、capture等账需逐项核所有权，未确认前不假设可用。
2. 当前正方向是good v减bad u的score。若选terminal bad质量势，连续导数要从当前原定义重推；删除future使存活bad概率上跳，其积分符号不能照搬相反方向旧test。端点、连续drift与全部删除Stieltjes项必须一起记。
3. aD_+−bD_−≤aD仅在原共同底测度且b≥a于负score域成立。低Q静态门、当前FA/浮动/J补权、capture/history等若只在positive，必须保signed completion/restoration价；不能把它们免费乘负项。每个支不能各领同一份原负信用。
4. 任何随t的test或权若作分部积分，须付其导数和跳，包括1/e_t的归一变化、process支持及由门引入的变化。actualx的p_y固定于辅助t，不意味着源交换后的p_y/e_t可当stationary权；转置要连同high/valid及第三来源一起转置。
5. 负项不能用positive hardcap16/3来上放；正源交换不等于signed交通可交换。β=ν+ρ只分配原positive来源，ρ未消失；ν≤β也不使Π相同或给soft rank。
6. signed结果要在原不交E_V和唯一j上积分，保真实dx、两Π、原门和共同q。任何新εX/来源价均应回代原常数，独立误差槽求和并保精确原补域；不把一个端点势或熵identity宣称完整付款。

## 初检状态

新低门确给相对权收缩与最低logdrop，K抵消及ε依赖已明确。准确可用弱结论是带degree比的terminal质量/熵比较和row entropy上界；它们单独不足以付一般归一全clock交通。最早需新几何是实际β/ν/receiver/history加权的degree或拥塞预算，或经原账审计可用的signed补偿。初检完成，尚未读作者稿；等待准确不等式后独审，不做大规模反例搜索。

## 新一般pair-envelope引理：作者稿前独立筛查通过

固定正有限clock窗，以ξ=logt作时间，长度L。两n坐标min-product权wv、wu均有正阈值，故正且连续分段log-AC；kv、ku分别是非减整数计数。令h=log(wv/wu)、q=ku−kv，则h′=q。任意正可测e(ξ)无需正则性，若静态有限A,B≥0满足wv/e≤A、wu/e≤B（a.e.足够），则乘积满足

    wvwu/e² ≤ψ(h):=min(A²e^(−h),B²e^h)。

A,B>0时，ψ(h)=AB exp(−|h−log(A/B)|)，因此supψ=AB、∫Rψ(h)dh=2AB。中心化原函数F′=ψ可明确取

    F(h)=B²e^h−AB，h≤log(A/B)；
    F(h)=AB−A²e^(−h)，h≥log(A/B)，

其范围[-AB,AB]。它C¹，单个ψ峰无需光滑二阶导数。对计数BV分部积分，

    ∫ψ(h)q²dξ=[qF(h)]_lo^hi−∫F(h)dq
              ≤AB(|q_lo+|+TVq+|q_hi−|)≤2nAB。

最后2n系数需完整端点计数：初端|q|≤ku+kv，末端|q|≤(n−ku)+(n−kv)，中段TVq≤Δku+Δkv，合计≤2n。端点用区间内单侧traces，重复/重合阈值合并跳，不把同点多个坐标误当单跳。再由Cauchy及∫ψdξ≤ABL，得到

    ∫|kv−ku| wvwu/e² dlogt ≤sqrt(2nL)AB。

A=0或B=0时相应原密度为零，乘积积分零，直接分支处理而不取log(A/B)。L=0也零；无穷A/B只给平凡无穷界。若权允许零阈值导致整源权恒零，可先删该零贡献，h只在正源上定义。原C阈值本来正。

真实Π可用masked密度envelope：若A(v)≥sup_t 1Zt(v)wt(v)/et（ν-a.e.且联合可测），对同时alive的pair乘积≤ψ；其他时刻原乘积零≤ψ，故完整窗的ψ/BV估计仍适用。这里无需微分Z或e，也不用假设原Π本身连续；不是把删除跳忽略，而是全程正支配。原η/history等≤1的门和正δ≤|kv−ku|可以保留后上放，static good/bad集合按原terminal定义。

对任意正来源测度ν，由Tonelli积分pair，得到无额外原子数因子的联合界

    ∫clock∫G∫B |kv−ku| Πt(dv)Πt(du)dlogt
      ≤sqrt(2nL)(∫G A(v)ν(dv))(∫B A(u)ν(du))。

此处“无原子数”指公式没有另乘原子计数，并不证明包络L¹质量小。每时刻∫Π=1不推出∫sup_t(dΠ/dν)≤1；常用A(v)=w_l(v)/eg仅给degree比级别，且真实β/p/receiver积分还未支付。即使row上形式根阶，也可能只是root·X而非可吸收εX+root·Wν来源价。因此该一般汇总工具通过，但不登记原新付款或当前低Q补域已闭合。

已实际用本机Fraction核12组两product权/静态A,B的中心化primitive端点、完整BV预算与∫ψq²≤2nAB（n1/2/4/16，含端点和重合阈值），全部通过；此有限代数核不授FULL或小envelope质量。

## signed_budget.md作者稿后完整审核：通过

已完整读最终129行稿，并窄核其指定原文：R123 current_ledger:44–73、R125 proof:165–175、R127 proof:251–268、R211 joint_capacity:116–148、R214 mixed_cap_budget:33–53、R218 large_clock:43–50、R121 global_ledger:101–116。R224/R226价沿已审原稿，不重读全史。所列K价格确为显式K⁰或按原L0=K√n抵消；C_G/Crec虽极大但只依预分配误差，不因统一预定K(n)自行多生√n。该表不是全部构造/未付槽的一致K定理。

SB1–5保完整原dT、good减bad方向、同一Ψ和只乘positive的θlo正确。bad-test连续导数及删除上跳给边界−Σjump；E×B反向余额已合入−∫E×B D+，不能另扣Ndel。suffix恢复−∫(1−Ψ)D可为正价，不得删；所有新旧已付positive补权在loss中，不能重加。SB6低Q好端test必添A×C的GG及A×E的GE项，原N_Zc/Ndel不支付它们，当前Q/D排序亦不授kt排序。该稿没有把未估负积分写进新门再登记付款。

旧R123/R125确列ΛT_Ac等未付项；最终稿只称本次所查尚未找到后续完整付款，未声称穷尽最新全史。统一K(n)~√n的receiver吸收路线还须全构造/全门同K重放并处理扩大后的低pe支，不能仅凭已付价格消K认证一般闭合。426项本机断言只有作者运行报告，无归档脚本，本审核不声称独立重跑这些断言。

## low_test_geometry.md作者稿后完整审核：通过

已全文审LG1–17，并窄核R217 peak_good_geometry主命题固定R资格、R211 JC19–23及JC28–30、R119 FA4的h=g exp(−u/n)。R=ρ或已付recapture后的ρ0确在完整actual行（含hardz/history）固定，不依辅助t；所有依原ρ确定的门保原值，不用ρ0重算。h和T为同actual x/j参数，非source重选尺度。

LG3–5保R与实际far Δ=w_τ−w_h，逐hardz先用∫Rkw≤RΔ及静态容量，行界cT/(2Kr′)一致，随后一次hard帽/同x FIRST/唯一Vj给16ΛcT/(3Kr′)X。即使门依hardz，该行上界对z一致，因而后取硬帽合法。RΔ≤D给更大静态门，准确计费是以同ε_st替换R226整门，不在已用份额上额外领取；若只处理旧Plo交集须另分误差。

eligible且非零的baseline上ρ0=(1−B/(TΔ))_+，所以ρ0Δ=(Δ−B/T)_+；强低门Q<rpρ0Δ严格等价Δ>B/T+Q/(rp)。LG8–10并未改capture系数/来源或各门；零R/Δ/非eligible先零，没有除0。good再给wg<Krρ0Δ只得到依来源的ρ0下界，非uniform正下界。LG17对同一Δ的反对称扣除/Lipschitz身份正确，仅两个同时eligible的形式比较，不把Q下降当B/T下降。

LG11–12中C_r、ρ0沿辅助t静态，F_r′=−∫Cρ0kw；terminal存活及ρ0≤1使et≥eg+F_r(t)−F_r(h)，故log(1+A_r/eg)归一化积分合法，无需微分Π或借删除信用。LG13 good容量≤Kq/p≤eg/2正确；结合w_τ/wg≤2^n给LG14及完整LG15价(32Λ/3)log((2^n+1)/2)X，确是nX而非root来源预算。LG16的Q加权逆wg平均仍需上控制，强低门只给下约束，作者明确未付。

## 最终主proof、一般pair来源回代与报告：通过

已通读最终proof.tex.txt 187行。新一般weighted pair theorem与作者稿前独立筛查一致，包含任意正可测normalizer和任意measurable支持mask；积分分部只对连续product ratio与计数q作，不引入e/mask导数。完整2n端点/BV预算、中心化F范围、∫ψ≤ABL及Cauchy常数均准确。正静态质量m_v/m_u可纳入clock或ν，但不可两处重复计；主稿明确提醒。

双源精确归一化特例E≤n、TV²≤nL/4正确；该特例本身不授多源同能量界。对一般ν的(5)由Tonelli保两份实际静态majorant质量M_G M_B，没有另乘原子数，也没有证明这些质量小。对原Plo的(6)只用一次上游32Λ/3、真实pβ/high/dx/不交Vj并保实际参数；静态低集合可限制G，其他正门可上放，未把正包络移给negative。explicit A_y(v)=w_l/eg有degree质量费用，逐时Π归一不能使其L¹为1。此来源汇总是真工具但不是新的原一般根阶付款。

主稿新增capture(7)–(8)忠实LG3/8/12–15，替换份额不叠加，baseline应用保原recapture条件。signed/K限制与作者最终限缩相同。report全文与三类交付一致：一般pair工具、同份额capture门替换、仍未付的实际包络/强低Q几何；没有用接口或有限toy宣称一般目标闭合。未认证所有后续低pe总账，未认证K扩大可完成整题。

## 数值源码和独立完整复跑：通过

已完整静审pair_variation.py。84个两源系统按真实threshold段用σ端点差精确积分，q=0段只对log质量作有理上界，避免除0；原函数中心化分部、单侧端点计数、有限Cauchy及log长度≤ratio−1方向均正确。54个weighted例使用同含静态质量的两clock定义σ，并以e=max(a/A,b/B)及其两倍核点态比较，未混含质量σ与未含质量权。跨F峰分段仍用准确端点F差；3个零容量分支先零，不取log(A/B)。大分数仅以规范hex分子/分母哈希与bit长度压缩，配方完整，不把截断小数当精确值。

已完整静审mixture_probe.py：固定carrier上between-jump均值导数为−Var，阈值处weighted-score跳，积分方差=初均值−终均值+内部跳之和；端点用1+和2−，不多算端点跳。n为2幂，阈值dyadic由同一数组取值，端点相等比较一致。结果用binary64/math.fsum，未作有向区间；质量与权在本菜单内无下溢零值。它只是多源标量诊断，不能从近似n²比值拟合阶、当严格反例或FULL几何证书。报告将此前中断Fraction混合运行排除出通过证据，本独审不将其当已完成计算。

独立完整实际运行两脚本：pair session32401 exit0，mixture直接exit0。两份JSON全部字节比较一致：

- pair_variation.json：4,203,834字节，SHA256 `d87adcecb7e7027d30e81e95b361cfd25044df3079eacdc4b41bb2e82c04d070`；84/54/3、1692点态检查及27跨F分界段均从原JSON逐项确认，全部checks真，源码/合同指纹匹配。
- mixture_probe.json：1,407字节，SHA256 `78d1fb9a3536b4aa98e68d42cb4dc76271723ee35ce71bc9453eab851e40c30c`；n4/16/64/128/512五记录及源码指纹匹配。普通浮点完整复现只支持该诊断实现，不认证解析误差或全域结论。

numeric_notes保较早84例历史JSON哈希，末尾明确由新增weighted后的d87ad...取代；最终数据/计数与代码一致。三个Python AST及LaTeX环境静检通过，未编译PDF。reproduce.py完整静审：仅标准库，包外新目录迁移两自足脚本、完整JSON比较、manifest前后核验，运行receipt外置；本审核不预称父级最终冻结后的迁移回执已执行。

## 最终受审SHA与冻结

|文件|SHA256|
|---|---|
|task_contract.md|86fcda8985ad573832554b3fe58d7f886a42af557143bd8f4eb9c60e76f88294|
|proof.tex.txt|acfef50032b8c615bd44c56f1aa85a99a777e0096b7794fc814749126b1dd22f|
|report.md|de3b68253e0ec622a77385529ca08fa68a2d7fc110134c915124496db0bd6fc7|
|low_test_geometry.md|e0ad14b0311d5276bf2021851a423287b006557bf170f9481241baabf978ebae|
|signed_budget.md|23eba61de94596e3905010955cab48ba181d6de0236ea274577ab187973e6cb7|
|pair_variation.py|dd1d6ba1dd2cc4fe1ff2e71fbba4d0440540d43fe860c547eeb74f9fcf759ccf|
|pair_variation.json|d87adcecb7e7027d30e81e95b361cfd25044df3079eacdc4b41bb2e82c04d070|
|numeric_notes.md|b8b2f5e9250678eecd10b8eec31b6e2f75879a9bbe42bbed502f8e850a28fadd|
|mixture_probe.py|7cca410d4694135fbead62590689263482a02249f735306ea128884273d50c68|
|mixture_probe.json|78d1fb9a3536b4aa98e68d42cb4dc76271723ee35ce71bc9453eab851e40c30c|
|reproduce.py|2e91c936c5a528c3f64dbbefe68142a71edcd86e7c6f78f12bf018e2a409ec66|

**冻结结论：上述范围独立审核通过，无修复阻断。** 一般pair汇总工具及capture门同份额替换成立；实际小envelope/强低Q补域的根阶来源价、signed新增GG/GE费用和完整一般目标仍未付。两脚本独立完整复跑JSON一致，无活跃session。本audit冻结并停止写入，父级继续manifest、外移最终driver及归档。
