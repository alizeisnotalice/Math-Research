"""Finite scalar mixture diagnostic, not FULL geometry or asymptotic proof."""
import argparse,math,json,hashlib
from pathlib import Path

def run():
 rows=[]
 for stage,ns in [('initial',(4,16)),('pressure',(64,128)),('expanded',(512,))]:
  for n in ns:
   N=4*n;aa=[1+i/N for i in range(N+1)];mm=[a**(-n/2) for a in aa]
   def mean(t,right):
    vs=[m*min(1,a/t)**n for a,m in zip(aa,mm)]
    return math.fsum(v*n for a,v in zip(aa,vs) if a<t or (right and a==t))/math.fsum(vs)
   jumps=math.fsum(n*m/math.fsum(m2*min(1,a2/a)**n for a2,m2 in zip(aa,mm)) for a,m in zip(aa[1:-1],mm[1:-1]))
   energy=mean(1,True)-mean(2,False)+jumps
   assert energy>=0
   rows.append({'stage':stage,'n':n,'sources':N+1,'variance_integral':energy,'variance_integral_over_n2':energy/n**2,'weighted_jump_budget':jumps})
 return {'rows':rows,'scope':'Binary64 scalar diagnostic using exact analytic variance identity. No spatial realization, FULL constraints, interval certificate or asymptotic order fit.','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=p.parse_args();args.output.write_text(json.dumps(run(),indent=2)+'\n')
