# R227：低测试余支保捕获的最强静态分配与全局缺口

本稿未取得 `P_lo≤εX+C√n polylog(n)Wβ`。完成的有限推进是：把R226的整段权损失门升级为**保原捕获权及实际 far 端点**的门，并准确代回原量；对已剥recapture的实际baseline，其补域成为一条同时保捕获核、测试核和时钟损失的严格不等式。随后保实际归一化推进到共同来源积分，最粗可证费用仍为线性 nX。本文不把新增门的数量、来源交换恒等式或这个未付积分当成根阶付款。

## LG1 准确原量及可带出时钟的权

沿R226 BP11–14，`P_lo=P_cur[Q_v<r p_yD_yv]`，其中

\[
 D_{yv}=w_{\tau_j}(y,v)-w_g(y,v),\quad
 \tau_j=a/c_j,\quad r={16\Lambda\over3K\varepsilon_{st}},\quad
 Q_x=(K_{1,x}+K_{2,x}+J_x)/3,\quad p_y=K_{1,x}(y).
\]

`P_cur`已包括原2Λ，保所有此前已付子集的补权及真实capture；原good槽v属于S_g⊂Z_g，原bad槽u属于D_g。以下新分配只操作同一个原正测度，原负余额仍原位一次。

捕获权的t静态性有原定位，不是新假设：R217冻结 `peak_good_geometry.md` §主命题明确从R128 RT2/RT6和R211 JC19–23读取，固定完整 `(ω,V,j,x,y,z,history)` 后，原ρ_r(v)以及已付recapture后的ρ0(v)均不依辅助t。R211 JC28–30允许对完整far余项作一次代数替换 `ρ=ρ0+δρ`；已经支付恢复时，此处使用ρ0且不重领恢复费。即使资格门依原ρ，所有门仍保原值，不用ρ0重算。

记实际far包络为 `[τ_j,h]`，`h≤g`，并定义

\[
 \Delta_{yv}=w_{\tau_j}(y,v)-w_h(y,v),\qquad 0\le\Delta_{yv}\le D_{yv}.
 \tag{LG1}
\]

原实际 `J_far=I_{j,V,y}∩[τ_j,h]`；其它时钟/历史门可使它更小。空窗、Δ=0或ρ=0的相应正交通先置零。h是原窗口端点，不是物理接收尺度L；固定实际x、j后它不依辅助来源位置。

## LG2 保capture的全时钟可付款门

设 `R_r(v)∈[0,1]` 是实际剩余正交通中固定于辅助t的target权，上层取ρ或ρ0。取任意实际静态非负测试T_x满足 `∫T_x(v)ν(dv)≤c_Tq`。令

\[
 \Gamma_r(v)=R_r(v)\Delta_{yv},\qquad
 A_R=\{v:T_x(v)\ge r' p_y\Gamma_r(v)\},\quad r'>0.
 \tag{LG2}
\]

对原完整正量的这个子交通，有

\[
 \boxed{P_{cur}[A_R]\le {16\Lambda c_T\over3Kr'}X.} \tag{LG3}
\]

**证明及实际回代。** 固定完整行，包括hard z及其history。在两份原Π上先保R，使用 `δ=(k_v−k_u)_+≤k_v` 和bad槽概率质量≤1，再用 `e_t≥e_g`。其它实际正权保留为≤1的因子。于是

\[
 \int_{J_{far}}\iint 1_{A_R}R(v)\Theta_t(v,u)\delta_t
       \Pi_{y,t}(dv)\Pi_{y,t}(du){dt\over t}
 \le {1\over e_g(y)}\int_{A_R}R(v)\Delta_{yv}\nu(dv)
 \le {c_Tq\over r'p_y e_g(y)}\le {c_T\over2Kr'}.
 \tag{LG4}
\]

第一步的权FTC为 `∫_{τ_j}^h k_t(v)w_t(v)dlogt=Δ_yv`；原v终端存活，删源资格及非连通有效子域只减小正积分。Γ=0行不除Γ。

即使R依hard z，LG4在每个原z行一致成立。随后在原RT1外测度中只用一次 `∫h_R(x−z)ν(dz)/q≤16/3`，得到系数32Λ/3；再对同一实际x使用 `∫p_yβ(dy)≤q`，保唯一j和不交真实receiver叶，`Σ_V|E_{ω,V}|≤|E|`，即得LG3。所有L/R/s可依x，不用任何移动参数列=1或ν≤β比较，无soft/scale菜单、无负信用。

取T=Q、c_T=1，r'=r，可用R226同一个ε_st额度证明更大集合的总价。因为 `RΔ≤D`，

\[
 \{Q_v\ge rp_yD_{yv}\}\subset
 \{Q_v\ge rp_yR(v)\Delta_{yv}\}. \tag{LG5}
\]

准确记账是**替换**R226的已付正分配：直接证明整个右侧≤ε_stX，余量改为其严格补集；不是在已用ε_st之外声称扩张部分另获一份免费ε_st。若坚持不改旧分配，则LG3也可仅用于当前P_lo中的交集，但须另列独立误差份额。

## LG3 baseline的真实联合支持

R211 JC19–22在原eligible集合给

\[
 \rho_0(v)=\left(1-{B_x(v)\over T\Delta_{yv}}\right)_+,
 \quad B_x(v)=\mathsf D K_{0,x}(v)+\alpha_0J_x(v),\quad
 \alpha_0={\mathsf Dq\over Q_J},\quad Q_J=\int J_x\,d\nu.
 \tag{LG6}
\]

这里 \(\mathsf D\) 是原capture参数，区别整段权差D；T、K0、α0和来源皆保持原实际值。zero/非eligible行沿原约定为零。原Q_J≤q给α0≥\(\mathsf D\)，但不添加新的ρ不等式。因而在eligible集合上有精确恒等式

\[
 \Gamma_r(v)=\rho_0(v)\Delta_{yv}
       =\bigl(\Delta_{yv}-B_x(v)/T\bigr)_+. \tag{LG7}
\]

在LG5加强后的非零余量，

\[
 \boxed{\Delta_{yv}>{B_x(v)\over T}+{Q_v\over rp_y}.} \tag{LG8}
\]

这比仅 `Q_v<rp_yD` 保留了真实capture扣除和实际far时长；与terminal good合用得到

\[
 w_g(y,v)\le{KQ_v\over p_y}<Kr\rho_0(v)\Delta_{yv},\qquad
 \rho_0(v)>{w_g(y,v)\over Kr\Delta_{yv}},
 \tag{LG9}
\]

\[
 w_{\tau_j}(y,v)-w_h(y,v)
 >{\mathsf D K_{0,x}(v)+\alpha_0J_x(v)\over T}
    +{w_g(y,v)\over Kr}. \tag{LG10}
\]

同时仍有 `Q_v<rp_yρ0Δ≤3rQ_y`、`Q_u<p_yw_g(y,u)/K≤3Q_y/K`。因此当 `3r<1,K>3` 时两端仍严格下降，但LG9不给ρ0一个维数/来源一致的正下界：w_g/Δ可以很小。不能把“保capture的剩余支持”改写成未授权的ρ0≥常数。

LG8的所有项同源同x；不能各自取最坏值后继续声称保留了联合几何。尤其K0与Q的比例一般带真实尺度代价，不从Q_v<Q_y推断B_v<B_y。

## LG4 保实际归一化能走到哪里

令C_r为固定完整行中LG8的eligible终端目标集合，定义

\[
 F_r(t)=\int_{C_r}\rho_0(v)w_t(y,v)\nu(dv),\qquad
 A_r=F_r(\tau_j)-F_r(h)
     =\int_{C_r}\bigl(\Delta_{yv}-B_x(v)/T\bigr)\nu(dv).
 \tag{LG11}
\]

这些对象依实际x,y,z/history；不是任意新选择的源。对t≤h，terminal存活及0≤ρ0≤1给

\[
 e_t(y)\ge e_g(y)+F_r(t)-F_r(h).
\]

沿R211已证normalizer-log机制，原该行正交通保rho后满足

\[
 R_{lo}(r)\le\int_{\tau_j}^h
 { -dF_r(t)\over e_g(y)+F_r(t)-F_r(h)}
 =\log\left(1+{A_r\over e_g(y)}\right). \tag{LG12}
\]

这是旧log工具对当前更精确集合C_r的合法应用，不作为另一个新增定理计数。它没有对Π微分，故不借删除负信用。若门依hard z，先逐z保留该log，再用H_R条件平均；不能把z依赖擅自消去。

原good与high实际上给一个有用但仍不足的质量约束：

\[
 \int_{S_g}w_g(y,v)\nu(dv)
 \le{K\over p_y}\int Q_v\nu(dv)
 \le{Kq\over p_y}\le\tfrac12e_g(y). \tag{LG13}
\]

另一方面逐坐标 `w_{τ_j}/w_g≤(g/τ_j)^n≤2^n`，`w_h≥w_g`，故

\[
 {A_r\over e_g(y)}
 \le {2^n-1\over2},\qquad
 R_{lo}(r)\le\log\frac{2^n+1}{2}<n\log2. \tag{LG14}
\]

将此完整代回原外测度，得到的仅是

\[
 P_{lo}^{new}\le {32\Lambda\over3}
       \log\frac{2^n+1}{2}\,X. \tag{LG15}
\]

这里来源、receiver、唯一j、capture皆已合法计入，但价格是nX，不是εX加根阶Wβ。更精确地，在每行good上用 `w_g≤KQ/p_y` 可保

\[
 {A_r\over e_g(y)}
 \le {1\over2q}\int_{C_r}Q_v
       {\rho_0(v)\Delta_{yv}\over w_g(y,v)}\nu(dv). \tag{LG16}
\]

LG8–10只给此联合比值在余域的**下**约束，未给其Q加权平均的上界。把LG16中的逆w_g上放到独立列正是会丢失共同source/receiver几何的步骤；本稿不这样取得一个虚假常数。全局未付量仍是LG12按真实外测度的积分，而不是已经从R226得到的εX。

## LG5 对称来源与捕获势：明确缺少哪一条联系

固定实际x，τ_j和h相同，因此Δ_yv=Δ_vy。baseline扣除 `b_x(v)=B_x(v)/T` 不依中心y（全部物理参数仍依x）。对两个同时eligible的形式表达，有

\[
 (\Delta_{yv}-b_x(v))_+-(\Delta_{yv}-b_x(y))_+
 =\int_{b_x(v)}^{b_x(y)}1_{\{a<\Delta_{yv}\}}\,da,
 \quad |\text{左边}|\le|b_x(y)-b_x(v)|. \tag{LG17}
\]

这只是准确的捕获扣除反对称结构；原eligible/history在交换时必须一起转置。Q下降与b下降没有已授权的一致比较，且原交通在时钟积分前仍是 `p_y/e_t(y)` 乘双Π score，不能用LG17把正交通直接换成捕获势差。

本轮同构造ν≤β=ν+ρ_exc及对称W允许R226 BP14的真实交换，但不能免去 `p_y/e_t(y)`、另一份Π及其high/history转置，ρ_exc槽仍另在。最早缺口有两个等价表现：

* 在保归一化路线，需要对LG12内 `A_r/e_g(y)` 的实际receiver/source加权分布获得根阶付款；LG8中的共同捕获扣除尚未给这个分布的上控制。
* 在共同源交换路线，需要将Q的严格下降和LG17的b势差、同一receiver几何与时钟占用连起来；仅用未归一核对称性不产生这个联系。

父级双源BV工具可控制一个固定来源对的归一化变差；把它在此处按所有v/u对直接相加会丢失多源共同分母。本文未作该未经证明的提升，也未花费工作构造否定FULL的标量例。

## LG6 实际本机检查与结论

本机Python标准库Fraction实际运行241项精确有理断言：ρΔ=(Δ−b)_+、11个满足good及加强低门的非零必要模型中的LG8–9、以及LG17的反对称/Lipschitz恒等式全部通过。输入枚举有理 `w_τ≥w_h≥w_g` 与扣除b；它只验证上述代数与零支，不认证FULL空间、来源history或总预算。

最终准确状态：LG3可把R226同一ε_st付款扩到保ρ和实际far权差的更大门；可用替换分配避免重复花费。剩余必须保LG8–10，并且本稿已把保归一化推导的现有费用明确算到LG15。没有取得所要求的原根阶余支预算；该失败是一个具体实际联合积分仍缺上界，不是把其改名为已付成果。
