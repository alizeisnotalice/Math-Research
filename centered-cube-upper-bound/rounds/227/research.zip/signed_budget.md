# R227：低Q补域的signed母式、GG交换价与K参数账

**结论范围。** 当前仍可用的负信用只有一次 `−2ΛN_Zc−2ΛN_del`；R226只删正hiQ，不消费它们。本稿从原母式给低Q的准确signed回代，并检查低Q test最早新增的GG/GE及suffix费用。未获得这些费用的全域根阶上界。另完成父级优先要求的K依赖核查：下表所列现行已付模块的来源系数均为K⁰（或由原L0=K√n抵消K），所以预先统一选K(n)~√n不使这些来源费升成n；然而所查旧总账仍列低pe、初始、跳跃等未付槽；本次未完整追踪其所有后续结算，不能据此认证一般闭合。

## SB1 原基准、余正门与一次负账

仅读本轮task_contract、R226 boundary_payment BP1–14、R223 negative_contract，并按需要回查R123当前总账与R116/R121。固定同一完整实际行 `r=(ω,V,j(x),x,y,z_hard,history)`，共同非负基准为

\[
 d\mathcal T_r=1_I1_{j(x)=j}\,q^{-1}p_y(x)h_R(x-z_hard)a_\omega(x,y,z_hard)
       dx\,\beta_V(dy)\nu_V(dz_hard),\qquad0\le a_\omega\le1. \tag{SB1}
\]

`A_hi={p_y e_g(y)≥2Kq}`。β、ν保持当前同构造来源，hard z不换为辅助点。令B=D_g为terminal bad、G=Z_g\B为terminal good、E_t=Z_t\Z_g；辅助好端v∈G，坏端u∈B，

\[
 D_t(v,u)=k_t(y,v)-k_t(y,u),\quad
 \Pi_t(dv)\Pi_t(du)=\frac{1_{Z_t}(v)1_{Z_t}(u)w_t(y,v)w_t(y,u)}{e_t(y)^2}\nu(dv)\nu(du).
\]

两Π已含两份e分母。原后缀补域Ψ=1_{Zcal^c}在同一完整行和terminal pair上不随t变化。令θ_cur∈[0,1]保FA不足、实际capture余权、所有此前已付子支后的补权；不把它移到负项上。

R226给 `r_st=16Λ/(3Kε_st)`、`D_v=w_{a/cj}(y,v)−w_g(y,v)`，再定义静态低门

\[
 L(v)=1_{\{Q_x^*(v)<r_st p_yD_v\}},\qquad\theta_{lo}(t,v,u)=\theta_{cur}(t,v,u)L(v). \tag{SB2}
\]

原far窗是同一完整合法 `[l,h]`（空窗贡献0；端点按原一侧值），而非可任意扩大signed积分的新窗。原row正负为

\[
 P_{lo,r}=\int_l^h\iint_{G\times B}\Psi\theta_{lo}D_t^+d\Pi_t^{\otimes2}\frac{dt}{t},
\]
\[
 N_{Zc,r}=\int_l^h\iint_{G\times B}\Psi D_t^-d\Pi_t^{\otimes2}\frac{dt}{t},\qquad
 N_{del,r}=\int_l^h\iint_{E_t\times B}D_t^-d\Pi_t^{\otimes2}\frac{dt}{t}. \tag{SB3}
\]

所以待付signed槽精确为

\[
 2\Lambda\,\mathbb E\sum_{V,j}\int1_{A_hi}
       [P_{lo,r}-N_{Zc,r}-N_{del,r}]\,d\mathcal T_r. \tag{SB4}
\]

这里P_lo全局量已包含2Λ。已用的N_Z不返回；N_del是未来删除端的连续dt反向配对，不是禁块跳跃原子。R223恢复的母账另列原初始、跳跃、低pe、大删源前缀；本稿不把这些原前缀从账中删除，也不凭该较旧索引断言其所有后续状态。准确出处为[R123 current_ledger.md:59–73](/Users/zhengzhihao/Desktop/T/output/centered_cube_round123_20261014/current_ledger.md:59)、[R223 negative_contract NC2–4](/Users/zhengzhihao/Desktop/T/output/centered_cube_round223_20261016_final_checkpoint/negative_contract.md:45)。R226支付hiQ仅删正量，全部未消费负信用可继续留给SB4一次。

不能在SB4先把正项hard因子上放到16/3或三腿半密度，再把原负项的系数也上放：有符号量不保该方向。使用下列test身份须回到SB1共同基准。

## SB2 全clock B-test保留的真实价

令F_B(t)=Π_t(B)。原禁块恒定段上

\[
 \partial_{\log t}F_B=\iint_{(G\cup E_t)\times B}D_t\,d\Pi_t^{\otimes2}.
\]

原真实删除不触及terminal B，故每次跳跃ΔF_B≥0。R223 NC8在当前低门下准确成为

\[
\begin{aligned}
 P_{lo,r}-N_{Zc,r}-N_{del,r}
 ={}&F_B(h-)-F_B(l+)-\sum_{l<s<h}\Delta F_B(s)\\
 &-\int_l^h\iint_{E_t\times B}D_t^+d\Pi_t^{\otimes2}\frac{dt}{t}\\
 &-\int_l^h\iint_{G\times B}(1-\Psi)D_t\,d\Pi_t^{\otimes2}\frac{dt}{t}\\
 &-\int_l^h\iint_{G\times B}\Psi(1-\theta_{lo})D_t^+d\Pi_t^{\otimes2}\frac{dt}{t}.
\end{aligned} \tag{SB5}
\]

证明只用 `Ψ(θD+−D−)=ΨD−Ψ(1−θ)D+`、上式导数及有限跳FTC。R226已付正域及全部更早正补权都在最后一行loss内，不能在这里再加回。E_t反向信用已经合入第二行，不再另扣第二份N_del。

第三行是先前已消费suffix域的回加费用。原完整窗下该域signed积分≤0，所以其前面负号可产生非负价格；不能删掉它。第一行边界虽在[−1,1]，乘原dT后只给receiver量级O(X)，没有自动ε或来源根阶价。现有低Q门没有证明最后一行loss足以补偿该边界与suffix回加。

## SB3 低Q好端test的最早缺项

令A=G∩{L=1}、C=G\A，二者沿t固定。把尚存负项按v端精确分给A/C只一次，则

\[
 P_{lo,r}-N_{Zc,r}-N_{del,r}
 =(P_{A,r}-N_{A,r})-N_{C,r}-N_{del,r}.
\]

对F_A(t)=Π_t(A)，原连续导数为

\[
 -\partial_{\log t}F_A
 =\iint_{A\times B}D_t\,d\Pi_t^{\otimes2}
  +\iint_{A\times C}D_t\,d\Pi_t^{\otimes2}
  +\iint_{A\times E_t}D_t\,d\Pi_t^{\otimes2}. \tag{SB6}
\]

因此用A-test试图只抓低Q时，除了F_A边界、删除上跳、suffix回加及已删正量loss，必新增

\[
 -\int\iint_{A\times C}(k_A-k_C)d\Pi_t^{\otimes2}\frac{dt}{t},\qquad
 -\int\iint_{A\times E_t}(k_A-k_E)d\Pi_t^{\otimes2}\frac{dt}{t}. \tag{SB7}
\]

前项是GG交换；原N_Zc只有G×B反向，N_del只有E_t×B反向，均不等于此费用。后项也无自动符号。L(v)按Q_v/D_v排序，不按每个t的k_t排序；terminal good/bad及当前低Q没有给 `k_A≥k_C,k_E`。不能把R226已付hiQ正域误作一份A×C反向信用。

这定位了最早未证步骤：须用同一实际低Q、捕获、source和receiver几何，为SB5的边界/suffix减loss给真实预算，或为SB7负部提供可支付的补偿。当前没有这样的联合下界，故本稿不将“D减未算反向积分”定义的新门登记为新成果；那只是把未付负信用估计藏入门内。

## SB4 优先核查：既有付款对good常数K的准确依赖

这里K是R116 F13引入的good/high阈值，不是旧K256、核K0、capture放大D或L0。此前来源构造/树费不含这个新阈值。以下仅列当前实际已付模块；未付核上界、条件路线、撤回的s=0付款都不算已付价格。

| 当前模块及准确出处 | 费用或参数 | K幂与说明 |
|---|---|---|
| [R121 global_ledger_audit_private.md:101–116](/Users/zhengzhihao/Desktop/T/output/centered_cube_round121_20261014/global_ledger_audit_private.md:101)，GL6 | B_FA=4Λlog2/(Kε_FA)，B_IJ=4Λ/(Kε_IJ)；各付ε_FA X、ε_IJ X | 门阈值K^−1；实际已付X价K⁰。near、D槽亦K⁰，不能合并误差槽。 |
| [R123 current_ledger.md:44–57](/Users/zhengzhihao/Desktop/T/output/centered_cube_round123_20261014/current_ledger.md:44)，G123-6/7 | C_G(ε)=608Λ/9(1+π/2)2^{N_G}，N_G=ceil exp(max{(16Λ/ε)²,256Λ/(3ε)}−1)；价εX+C_G√nWβ | C_G严格K⁰。R125 AC、R126 RC同价替换；[R127 proof.tex.txt:251–268](/Users/zhengzhihao/Desktop/T/output/centered_cube_round127_20261014/proof.tex.txt:251) SP1/MA用(ε_RC+ε_B)X+C_G(ε_RC)√nWβ，也K⁰。 |
| [R211 joint_capacity.md:116–148](/Users/zhengzhihao/Desktop/T/output/centered_cube_round211_20261016_final_checkpoint/joint_capacity.md:116)，JC12–15 | C_rec=32Λ/3(1+π/2)2^{N_rec}，N_rec=ceil exp((8Λ/ε_rec)²−1)；价ε_recX+C_rec√nW_A | K⁰；仅原持续恢复额度一次，不能再按各腿重领。 |
| [R214 mixed_cap_budget.md:33–53](/Users/zhengzhihao/Desktop/T/output/centered_cube_round214_20261016_final_checkpoint/mixed_cap_budget.md:33)，MC2–4 | J帽价16ΛL0/(3K)Wν，另8Λ/(κ√ell)X；原取L0=K√n、κ=8Λ/(ε_mix√ell) | 按原参数后为(16Λ/3)√nWν+ε_mixX，K⁰。K0和J费用不能混成一个来源帽。 |
| [R218 large_clock.md:43–50](/Users/zhengzhihao/Desktop/T/output/centered_cube_round218_20261016_final_checkpoint/large_clock.md:43)，LC4 | 浮动带价16ΛL0 ε/(3K)Wν，原L0=K√n | 为(16Λ/3)ε√nWν，K⁰；它替代被包含的R217支，不叠加。 |
| [R224 traffic_reentry.md:118–125](/Users/zhengzhihao/Desktop/T/output/centered_cube_round224_20261016_final_checkpoint/traffic_reentry.md:118)，TR7 | 终端J真实分配价εX+[128Λ²/(27ε)]d²e^dWν | K⁰；原√K good因子与high列K^−1/2抵消。 |
| [R226 boundary_payment.md:183–193](/Users/zhengzhihao/Desktop/T/output/centered_cube_round226_20261016_final_checkpoint/boundary_payment.md:183)，BP11 | static价16Λ/(3Kr_st)X，r_st=16Λ/(3Kε_st) | 价ε_stX，K⁰；低Q余域相应改变。 |

R128曾有显式√K的纯硬边界估计，但因原strictsoft门排除s=0已撤回实际付款，不得据该撤回式断言当前已付来源价随√K增长。R215指数核上界仍未付，亦不属于这里的已付来源系数。

**对新的C√n/K receiver价的结论。** 如果真能对当前对应高支余项给出 `C√n/K·X`，其中C对K一致，则在整套构造开始前统一取 `K(n)≥C√n/ε`（并满足原固定下门）可把它放入εX。上表所核现行价格不会仅因这个选择增加一个√n来源因子。不允许只改末端P_lo里的K：good/bad、高支、FA/IJ阈值、L0及当前全部正负门必须以同一预定K(n)重放，负项也不能沿用另一K的来源标签。

**核查范围与仍不能认证的结论。** [R123 current_ledger.md:62–69](/Users/zhengzhihao/Desktop/T/output/centered_cube_round123_20261014/current_ledger.md:62)和[R125 proof.tex.txt:169–175](/Users/zhengzhihao/Desktop/T/output/centered_cube_round125_20261014/proof.tex.txt:169)都显式保 `ΛT_{A^c}`，其中 `A^c={p_y e_g<2Kq}`。R116 [astra_first.md:129–135](/Users/zhengzhihao/Desktop/T/output/centered_cube_round116_20261014/astra_first.md:129)只有低支密度界 `p<2K c_j^{n/2}/(ell g^n)`，未给新来源/receiver价。K增大使这份低pe定义域扩大。以上只能确认所查R123/R125总账仍将它列为未付，不能自动推出它在所有后续轮次的完整状态。

按父级要求，本次另窄查R211–226各冻结目录的current/global/ledger文件名索引，以及同段report、task_contract与proof中低pe/T_Ac/前缀关键词。该范围只定位到R212 `normalized_ledger.md`（其对象是capture baseline的来源归一，非完整全局总账），没有定位到一份重新列清低pe全局结算的最新current/global总账；同段研究主要针对原high正子交通或其capture/clock子项。本次没有逐轮追完全部历史，因此准确状态为：**所查总账仍列低pe未付，尚未找到后续完整付款；不能认证K(n)选择的一般闭合。** 初始、跳跃和大删源等也不得仅靠本表注销。这里不声称已经证明“全部最新余项必仍包含同一低pe槽”。

## SB5 本机核验与停止点

实际运行本机Python Fraction：81组四来源整数score向量，核对G/B/E的B-test方向、A/C新增GG与GE以及三种正门权的净δ代数；另对3个K和3个平方维数核对L0/K、static Kr及TR7的K消去。共426项精确有理断言全部通过，仅是代数/常数核验，不授FULL、signed极限或根阶预算。

完成原未消费负账、低Q signed母式和K账的有限恢复。未得到新的全clock signed根阶估计，也未登记由未算负积分定义的额外付款门；准确缺口为SB5的边界/suffix净价或SB7的实际GG/GE补偿，以及所查总账仍列、但本次未完整追踪后续结算的低pe等槽。
