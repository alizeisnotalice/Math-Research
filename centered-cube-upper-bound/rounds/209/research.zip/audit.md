# R209 independent premise audit

## 1. Review order and exact original account

This is the independent candidate screen before reading any R209 author proof. The contract was initially absent, then read after creation. Directly read the permitted R128 RT1–3 and R121 GL1–5 source passages. Only this audit file is owned by the auditor; no Git, spawning, numeric execution or PDF compilation is performed.

The common original RT1 outer measure includes the same expectation, V,j, actual receiver dx, beta, hard-source nu, high/history qualifications and far time domain. The hard source is not the bad posterior source. The original signed J-share account, if using all available N, is (P_J-N)+P_other: P_other cannot spend N again. Already consumed negative credits do not return. A separate upper hard cap on a positive term is not an identity for the negative term and cannot be put outside a newly signed difference without a proved common comparison.

At a fixed legal original row let G and B be disjoint terminal surviving sets contained in Z_g. Let A=1_G rho J/S in [0,1] be fixed along the original auxiliary clock, and E_t=Z_t minus Z_g. Let D=k_v-k_u, Dplus=D_+, Dminus=(-D)_+, with the pair ordering v in G or E_t, u in B. The actual suffix Psi and positive gate h are retained, not declared constant in time or independent of the pair. Any current/receiver/alpha changes are outside a frozen auxiliary-time identity and require their own finite exchanges.

## 2. Ratio identity and zero rows

On a deletion-free interval write F=Pi_t(A), b=Pi_t(B), K_A=Pi_t(Ak), K_B=Pi_t(1_B k), and m=Pi_t(k). The actual posterior equation gives F'=mF-K_A and b'=mb-K_B. Thus

    C_A=integral_(G x B) A(v)(k_v-k_u) dPi_t^2
       =b K_A-F K_B=F b'-b F'=-b^2 R',
    R=F/b=(integral A w_t dnu)/(integral_B w_t dnu).

This uses the same row, the same two posterior slots and a target weight constant in the auxiliary time. No sorting or monotonicity of R follows. If the bad weighted mass is zero, its original posterior leg and C_A are zero first; no ratio is formed. Physical positive w and nonzero nu(B) ensure a positive denominator on a compact surviving window. Otherwise the identity is used only on positive-denominator localizations and their justified limits. Rows with e=0 are disposed of before posterior definitions.

Threshold changes do not make w jump: w'=-kw holds a.e., k is bounded by n, and both terminal surviving unnormalized integrals are locally AC. They do not inherit deletion jumps from Z_t. At a deletion of posterior fraction d<1, Fplus=Fminus/(1-d) and bplus=bminus/(1-d), so R has no deletion jump. Continuous singular deletion cancels from R for the same reason. A death row is handled before division.

## 3. What a ratio potential must still pay

With Y=Fb=b^2 R, the complete Stieltjes product identity is

    -integral b^2 dR=Y_ell-Y_g+integral R d(b^2).

The weight b is not constant. Its continuous derivative contains m-K_B/b; its genuine deletion contribution is R Delta(b^2)=Delta Y=(Fminus+Fplus)Delta b. Continuous singular renormalization likewise remains in the product rule. These terms are not original N_del: N_del is the dt density on E_t x B with reverse score, rather than a posterior normalization atom. A theorem is required to relate them with their full weights. Nor does nonnegativity of R imply that its positive variation is bounded by its initial value. Disjoint G,B imply 0<=Y<=b(1-b)<=1/4, but do not pay the weighted variation, outer source column or selector.

For the original positive/negative weights the exact fixed-time identity is

    P_J-N_GB
      =C_A-integral_GB A(1-Psi h)Dplus
           +integral_GB (1-Psi)A Dminus
           -integral_GB Psi(1-A)Dminus.

Equivalently the last two terms combine to -integral_GB(Psi-A)Dminus. All integrals use the same actual pair posterior and common gates/outer measure. The reverse suffix leakage is a positive term and cannot be discarded; the FA loss and unused (1-A) reverse credit are kept once. A pair/time-dependent Psi cannot be absorbed into a terminal one-variable A without charging its actual exchanges. Positive traffic restricted to further paid/unpaid sets must be disjointized before claiming any shared negative credit.

## 4. Independently screened deletion-safe potential

Before reading the main proof, define f=A on G, f=1 on E_t and f=0 on B, and T=Pi_t(f). Since only E sources are removed and their f equals one, a deletion of mass d gives

    Delta T=d(Tminus-1)/(1-d)<=0.

The continuous deletion correction is (T-1)dL/e<=0. On deletion-free intervals T'=-Cov_Pi(f,k). With the same ordered pair convention,

    Cov=C_GB+C_EB+I_GG+I_GE,
    I_GG=1/2 integral_GG(A_v-A_w)(k_v-k_w)dPi^2,
    I_GE=integral_GE(A_v-1)(k_v-k_z)dPi^2.

Consequently the exact original signed integrand Q equals

    Cov-I_GG-I_GE-integral_EB Dplus
        -integral_GB A(1-Psi h)Dplus
        -integral_GB(Psi-A)Dminus.

All factors and the one-half in I_GG were checked independently. Integrating Cov yields T_ell-T_g plus the actual nonpositive deletion changes, with the same diffuse/jump qualifications as R208. This is a correct potential identity, not a general budget. T_ell contains the E_ell mass and still requires the real RT1 source/receiver account. The internal G/G and G/E covariances need not be favorable. For general Psi the positive defect (A-Psi)_+Dminus and available credit (Psi-A)_+Dminus stay separate.

One precise constructive sufficient geometry, without claiming it is automatic, is the following when Psi=1. For almost every actual target v with A_v<1, require its low-score pool

    integral_E(k_v-k_z)_+dPi(z)
      +integral_G [(A_w-A_v)_+/(1-A_v)](k_v-k_w)_+dPi(w)

to be at most integral_B(k_u-k_v)_+dPi(u). Then the adverse parts of I_GE and I_GG are paid by the same unused (1-A_v) reverse credit once. The A_v=1 slot is zero before division. This is a physical joint tail condition in the same row, not an independent-source or freely optimized coupling statement. General Psi changes both the available credit and the positive gate defect.

## 5. Layer cake and necessary qualifications

The legal layer cake uses one fixed terminal A: A(v)=integral_0^1 1_{A(v)>lambda} dlambda. Each G_lambda is terminal surviving, the bad denominator is common, and the same actual nu, Pi, forest and reserve alpha are retained. Absolute-integrability truncations or separate nonnegative Tonelli establish the signed Fubini step; layer cake does not authorize infinity subtraction. The ratio and covariance identities may be averaged over lambda, but each layer cannot spend the whole original N independently. Original reverse credit splits into the layer mass A and its complementary 1-A exactly; original E_t negative traffic has no automatic identification with a layer deletion atom.

For the safe potential f_lambda=1_{E_t union G_lambda}, each actual deletion removes a value-one source. Layer-averaging recovers f and T, including internal selected/unselected G interactions. It does not erase those interactions. A time-dependent layer of A h or pair-dependent Psi produces moving-set/test exchanges and is not a frozen terminal layer. The original reserve is never recomputed for a level set.

Status: independent premise screen complete. The ratio and safe-potential algebra pass with the explicit residuals above. No general source/selector/raw payment is certified. Await accurate author manuscripts before full review; do not expand into a separate counterexample or unrequested research project.

## 6. Full main-potential review after the independent screen

Read the complete current `main_potential.md` after sections 1–5. Its covariance decomposition has the correct E/G orientation and one-half G/G factor. The two Gamma representations agree only with the explicitly signed D in the second representation's first term; that qualification is present. The integrated endpoint plus deletion-jump sign agrees with the actual posterior product rule. The text retains the initial E mass, internal antialignment and suffix leakage, and does not certify them as a source budget.

The additional constant ceiling c in [esssup_G A,1] is valid when fixed along the auxiliary time. With f_c=A_G+c1_E, the exact integrand has -c integral_EB Dplus and -(1-c) integral_EB Dminus, and the internal E/G coefficient is c-A. Its deletion jump d(T_c-minus-c)/(1-d) is nonpositive because f_c<=c. Zero c forces A=0 and is handled without a ratio. Choosing a ceiling for one realized row does not make its receiver/source cost small. If c is changed along time, its actual test/finite exchanges must be added.

The auxiliary author then supplied an accurate candidate before its proof: define, for each actual G target v, the nonnegative finite measure

    L_v(dw)=(c-A_v)1_E(w)Pi(dw)+(A_w-A_v)_+1_G(w)Pi(dw).

For physical integer k in {0,...,n}, its downward score work is exactly the sum over ell=1,...,n of L_v{k<=k_v-ell}. The reverse B work is the corresponding reflected upper-score sum. Thus requiring, for each actual v and every ell,

    L_v{k<=k_v-ell}
      +integral_B(A_v-Psi(v,u))_+1_{k_u>=k_v+ell}Pi(du)
      <=integral_B(Psi(v,u)-A_v)_+1_{k_u>=k_v+ell}Pi(du)

is a sufficient same-row geometry condition to pay the adverse internal work and gate defect using the original unused reverse credit once. It entails no extra factor n: the sum is the exact integer gap representation. For noninteger auxiliary scores only the continuous threshold integral is valid, not this discrete representation. The c-A=0 and c=0 endpoints require no division. No claim that the physical kernels or stopping trees satisfy these cuts has yet been proved, and no source/global payment follows merely by naming the condition.

Stage status: preliminary screen and full main-manuscript review complete without a required revision. Await the two author manuscripts and bounded evidence for the requested later review; this file is not yet finally hash-bound or frozen.

## 7. Additional actual target-balance screen and review

Independently screened, then read the main manuscript's added same-target balance section. Let l_v be the downward work of L_v and h_v the upward B work weighted by (Psi-A_v)_+. The exact internal decomposition is -I_c=integral_G l_v dPi-I_pos, with I_pos the nonnegative favorable ordered-pair contribution. The exact suffix decomposition is Gamma=Gamma_pos-Gamma_FA-integral_G h_v dPi. Hence the equality first contains integral_G(l_v-h_v)dPi; replacing it by integral_G(l_v-h_v)_+dPi gives precisely the stated upper bound with all remaining negative terms retained.

This is a weaker sufficient balance than requiring every reflected integer cut separately. The sum of actual score gaps introduces no additional factor n and does not reissue reverse credit. Gamma_pos, the initial T_c mass and the actual common RT1/receiver/source/selector account remain unpaid. No new unconditional estimate follows from the algebraic reorganization alone. No required revision was found in this addition.

## 8. Physical two-source clock candidate, screened before proof

The main raw author supplied a separate accurate candidate. At fixed sources and a finite positive-weight clock interval, write s=log t, l=log(w_v/w_u), a=l'=k_u-k_v, and b=w_v/(w_v+w_u). Physical k_i are nondecreasing integers between zero and n, so a is BV, |a|<=n and TV(a)<=2n. Since b is continuous and b'=b(1-b)a, ordinary AC/BV integration by parts gives

    integral b(1-b)a^2 ds
      =[(b-1/2)a]_ell^r-integral(b-1/2)da
      <=[|a_ell|+|a_r|+TV(a)]/2<=2n.

Cauchy–Schwarz with b(1-b)<=1/4 yields integral|b'|ds<=sqrt(n log(r/ell)/2). Zero length and n=0 are zero first. Threshold jumps of a are included once; b itself has no threshold atom. Endpoint states and the BV interval convention must agree, for example right start/right end with da on (ell,r]. This conclusion uses actual physical score monotonicity, not arbitrary nonnegative fractional-score arrays.

The original pair flux equals the logistic pair flux times the genuine coefficient 1_Z(v)1_Z(u)(w_v+w_u)^2/e_t^2 against nu tensor nu. This coefficient is not a probability normalization and cannot be deleted. The single positive direction is bounded by the pair TV, but the original common denominator, gates, all pair-source weights, receiver-dependent endpoints and j/time/window account remain. The candidate is accepted as a conditional physical pair-clock estimate, not a general source payment. Await the full author proof before certification of its eventual stated scope.

## 9. Full layer-potential manuscript review

Read the complete 262-line `layer_potential.md` after the independent screens. LP1–11 pass without a necessary revision. LP3 constructs the actual positive deletion measure from nested exits, uses a fixed f_c on the whole initial support, and obtains its BV quotient on finite time with e_g>0. This does not require spatial gradients of L1 inputs or BV of Psi/h. All right-state endpoint, atom and continuous-deletion conventions agree; a death row is guarded before division. The full original RT1 measure and single negative-credit account remain explicit.

The covariance block factors, exact layer averaging, c=0/c=A endpoints and non-division low-score measure are correct. LP13's orientation gives I_GG=P_GG-N_GG and I_GE=P_GE-N_GE; LP16–19 exactly decompose physical integer score gaps and retain the positive suffix defect rather than declaring the suffix one. Each credit is counted once in the common layer integral. The three stated rational models' covariance, adverse work and suffix-defect values were checked algebraically and agree. LP20 is a real conditional row bound, but the manuscript explicitly leaves its initial endpoint, cut insufficiency and actual source/receiver/selector budget open. No general root-order payment is accepted from these identities or conditions alone.

## 10. Stronger physical pair-clock screen and full ratio review

Before reading the ratio proof, independently checked the stronger endpoint coupling. Monotonicity of both integer score paths gives

    |a_start|+|a_end|+TV(a)
      <=|ku_start-kv_start|+|ku_end-kv_end|+Delta ku+Delta kv
      =2[max(ku_end,kv_end)-min(ku_start,kv_start)]=2N_pair.

Consequently the unweighted pair energy is at most N_pair<=n and its total variation at most sqrt(N_pair T)/2. Taking the integration-by-parts constant to be zero or one instead of one-half gives energy<=2N_pair min(sup vartheta,sup(1-vartheta)); the manuscript correctly takes the minimum with the preceding bound. A zero N_pair or zero time length gives zero first. Right-inner start/left-inner end and only internal threshold atoms are used consistently; simultaneous threshold jumps are combined.

Then read complete `weighted_ratio_geometry.md`, including its latest WR8 diffuse-deletion clarification. WR1–22 pass without a necessary revision. WR6 retains the signed suffix, FA loss, unused (1-A) reverse credit and the separate original N_del density. WR8's general Stieltjes form includes continuous singular normalization, so it does not omit that part of the original double-e product rule. The physical min-product representation and all amplitude endpoints in WR9–15 are correct and need no source-coordinate independence.

The original pair change of measure in WR16 is exact, with its actual Omega. WR18's weighted pair product rule uses the continuity of vartheta correctly. WR19 retains the other sources' normalization and genuine removal support. In WR21, post-jump Omega multiplies the score increment and pre-jump score multiplies dOmega, which exactly includes the simultaneous-jump cross term; no continuous chain rule is substituted for finite threshold/delete products. Merely measurable tests receive only the stated common-measure Cauchy bound or a positive removal before the ungated BV identity. WR22 is a genuine whole-clock physical pair estimate but retains the unpaid Omega, A differences, E/G support, selector and source/time/window factors on return to original traffic. The manuscript does not call the resulting expression a completed budget.

Stage status: both complete mathematical author manuscripts have been reviewed within their precise scopes. Numerical evidence is being expanded by its owner; no old numeric hash is finally bound here and no script has been run by this auditor. Await final evidence and integration before any final audit freeze.

## 11. Final finite evidence and reproducer static review

Read the complete final `potential_checks.py`, its JSON metadata and selected final records, `numeric_notes.md`, current report and driver; no numerical script was executed. The actual final numeric hashes are script `caa7b1b9adac785aef969e4920beaf5a06c744be7cbf5966afc261412197bb94`, JSON `3daeef19086703126288953fb12c4374a3dccca1bb6958fb95f9fdf138026306`, notes `12f23129b0774ba5ae05342f6196c9f06dfbe6e8de465d285eb9e2b2b7690fdb`.

The 134 finite models use normalized positive rational raw masses, actual E-only renormalization, independent covariance/unordered-block/half-ordered-GG evaluations and exact finite layer cake. The 5628 gate identities and 2814 c-deletion checks are repeated profiles, not independent new models. Binary Psi, signed Gamma, positive and negative CA/internal terms and all c-dependent E/B terms are retained. These are finite conditional posterior models, not original suffix/forest/FIRST/FULL realizations.

The additional nine product-clock paths sort the actual rational internal C/D thresholds and combine simultaneous events once. Their weights are exact min-products; each segment's power law and direct quotient derivative are checked before the exact energy a Delta vartheta and monotone-segment TV are accumulated. Right-inner start counts use C<=1/2; left-inner end counts use C<1. The independent Stieltjes boundary-minus-internal-jump calculation is correct. The forty positive terms of the atanh(1/3) expansion give a rational lower bound L40<log2. Thus TV^2<=N_pair L40/4 and <=energy L40/4 are stronger sufficient finite certificates, not interval approximations or universal lower bounds for TV. Zero N_pair and tiny nonzero rational weights are handled exactly. The original Omega source factor remains outside these certificates.

The three extra integer-cut examples use the same posterior and Psi at every layer. Two record true cuts and zero insufficiency; the third deliberately records `all_cut_conditions_hold=false`, insufficiency 1/9 and exact q-Cov=1/9. Its PASS status certifies defect arithmetic, not fulfillment of the cut condition. The JSON and notes correctly preserve this distinction and the non-FULL scope.

The final numeric author reports actual relocated complete-JSON byte-identical replay, exit 0, 0.573 seconds. This auditor only inspected that evidence and did not perform the run. The current report does not promote the pair bound, conditional cuts or initial endpoint to a general source/selector/root budget. The relocated-copy driver covers the correct R209 script/contract and full reference JSON, confines manifest paths, rejects protected/existing output, compares complete bytes and rechecks hashes. Its static acceptance does not pre-report the parent's later manifest driver execution. Await detailed TeX integration before final file binding.

## 12. Final detailed TeX and integration review

Read the complete final 681-line `proof.tex.txt`, SHA256 `f881816094158ca77409c3b9ef5c1aabd1569864dea06c053760b6d73bde781c`. It agrees with all three reviewed mathematical manuscripts and final finite evidence. The original J-share/negative-credit account and common RT1 outer measure are preserved. The safe potential's general BV proof uses actual nested exits, fixed terminal f_c and positive surviving mass; it does not grant BV to arbitrary suffix/history gates. Its right-start/closed-right-end deletion convention is explicitly distinguished from the right-inner/left-inner threshold convention for pair energy.

The target-aggregate balance first retains exact l_v-h_v, then takes its positive part with Gamma_pos separate. The stronger integer reflected cuts retain every source/credit coefficient and are described as sufficient, not necessary. The layer construction never reselects reserve alpha or issues a full negative credit at every level. The ratio Stieltjes formula retains continuous singular normalization. The weighted pair formula uses post-Omega for score jumps and pre-score for Omega jumps, so simultaneous threshold/deletion cross products remain exact. Its full-source Omega is neither normalized away nor paid by the unweighted pair theorem.

All mathematical zero/end-state guards, N_pair and rare-slot bounds, original source/selector/time/window costs and the n^(3/4) warning are consistently transcribed. The finite evidence section correctly separates 134 conditional posterior models, nine exact physical min-product clock paths and three integer-cut calibrations; the third cut is deliberately false and its PASS certifies only the predicted defect. The rational log2 lower bound is used only for stronger sufficient finite inequalities. The reported author replay is not described as an auditor or future parent-driver run.

Static file inspection also found 47 unique labels, 27 references with none missing, and no abnormal ASCII control characters. No necessary mathematical or transcription revision remains. This is a full mathematical/static consistency review, not PDF compilation or a new numerical execution.

## 13. Final decision and execution limits

Accepted in the stated scope: the weighted ratio identity and its complete normalization remainder; the deletion-safe fixed-c potential and exact internal/suffix balance; the conditional same-target/reflected-cut row estimates; and the whole-path physical two-source energy<=N_pair and TV<=sqrt(N_pair T)/2, with its rare-slot refinement and actual Omega return. The first general unpaid budget remains the initial G/E endpoint, internal/gate insufficiency and Omega/source reuse under the same original outer receiver/source/selector account. No general centered-cube root-order weak-type closure is certified.

The auditor only edited this audit and performed read-only mathematical/static inspection elsewhere. No numerical script, parent reproducer, Git action, subagent or PDF compiler was run. The later manifest/archive execution belongs to the parent and is not pre-reported here.

## 14. Frozen final byte bindings

The following ten reviewed work files are bound to their actual final bytes. The audit does not hash itself or a future manifest.

| File | SHA256 |
| --- | --- |
| `layer_potential.md` | `dfde511e1ab67371ed74bbf70b4bd981d37d48a7096a01249547ba495c09092b` |
| `main_potential.md` | `b01f381fcb7c13592aa2961ff4980860d922cbe43ee7056872ea3138a2df4a96` |
| `numeric_notes.md` | `12f23129b0774ba5ae05342f6196c9f06dfbe6e8de465d285eb9e2b2b7690fdb` |
| `potential_checks.json` | `3daeef19086703126288953fb12c4374a3dccca1bb6958fb95f9fdf138026306` |
| `potential_checks.py` | `caa7b1b9adac785aef969e4920beaf5a06c744be7cbf5966afc261412197bb94` |
| `proof.tex.txt` | `f881816094158ca77409c3b9ef5c1aabd1569864dea06c053760b6d73bde781c` |
| `report.md` | `3a20c1c127afa913b23e471c6fb58e32d8ee87785c84a7d4cbd5b364c8a2bcc6` |
| `reproduce.py` | `1e0fe6d247a508a064537d40da5fc9ac2e7a54b2cce226581ab841a8667c3fdb` |
| `task_contract.md` | `6b610b25fe7b37a4bd0f0400721ebc238099293db4a9a90031c25a38b89755e5` |
| `weighted_ratio_geometry.md` | `effe6b86b9618a0fa81de4e42325fbd0774626e206cbc176cacf0f788009afba` |

Status: final audit accepted within the exact scope above and frozen; no further audit work is pending for this checkpoint. General raw/root-order closure remains open.
