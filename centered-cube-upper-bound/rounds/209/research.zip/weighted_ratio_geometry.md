# R209：保目标权的比值流与物理阈值交换根界

本文只处理原共同来源测度。新实估计是：任意两条实际乘积阈值权的**条件两源后验**，其整个时间路径总交换满足根阶界，并有精确有限阈值能量与稀少一槽强化。将它乘回原双后验时保留完整可变pair权及归一化交换；没有证明这些费用的一般来源预算。原signed账在§1–2固定，不把删除重标误认作原删除负信用。

## 1. 固定原量及负信用余额

窄读来源为R128 `proof.md` RT1–6、R127 `proof.md` SP2–3、R121 `proof.md` GL1–5（1474–1551行），以及R170冻结 `soft_threshold_energy.md` §§1–3。文件均位于 `/Users/zhengzhihao/Desktop/T/output/` 对应轮次包。它们分别确认原外测度、终端集合、完整反向负交通及其后续消费状态。

固定原完整行，记 `G=S_g,B=D_g,E_t=Z_t\setminus Z_g`；G、B互斥且终端存活。`w'_t(v)=-k_t(v)w_t(v)`，prime表示对log t求导，
\[
 \Pi_t(dv)=1_{Z_t}(v)w_t(v)\nu(dv)/e_t,
 \quad A_v=1_G(v)\rho_v J_v/S_v\in[0,1],\quad
 S_v=p_v+p_v^++J_v.
\tag{WR1}
\]
A及原同α在行内时间固定，不能逐t重新捕获。原共同外测度为
\[
 d\mathcal T_I=1_I1_{j(x)=j}q^{-1}p_yh_R(x-z)a_\omega
 \,dx\,\beta_V(dy)\nu_V(dz).
\tag{WR2}
\]
另乘原high门，保期望及ΣV,j；硬源z不是bad源u。以下各行等式先在同一有限far区间及有限交通截断上成立，尚未分别对正负项使用hard帽。

令 `D_t(v,u)=k_t(v)-k_t(u)`、`Ψ=1_{𝒵^c}`；h_t包含其它原正门，`0≤h≤1`。原J子交通与两笔负项的行组合为
\[
 \mathcal R_A=\int\iint_{G\times B}
 \Psi\{A_vh_tD_t^+-D_t^-\}\,d\Pi_t^2d\log t
 -\int\iint_{E_t\times B}D_t^-\,d\Pi_t^2d\log t.
\tag{WR3}
\]
第二项才是原N_del的时间密度，没有ρ、FA、Ψ或终端good门。它不是删除事件上的负原子。第一项的负交通是仍未消费的N_Zc；已消费N_Z不返回。若将整份负信用用于J子份额，原总余项必须同时保留 `P_other+(P_J-N)`，P_other不得再领N；或者预先指定不超原负密度的可测分配。

## 2. 原归一化的精确保权抵消

令
\[
 F_t=\Pi_t A,\quad b_t=\Pi_tB,\quad
 G_A(t)=\int_G A_vw_t(v)d\nu(v),\quad
 N_B(t)=\int_Bw_t(u)d\nu(u).
\]
若B为零来源，则原行交通为零。其余在所用有限正窗内定义
\[
 R_t={G_A(t)\over N_B(t)}={F_t\over b_t}.
\tag{WR4}
\]
两个分子均只含终端存活源，故R连续、AC，并且删除时没有跳。无删除区间直接计算得
\[
 C_A(t)=\iint_{G\times B}A_vD_t\,d\Pi_t^2
 =F_tb_t'-b_tF_t'=-b_t^2R_t'.
\tag{WR5}
\]
因此
\[
\begin{split}
\mathcal R_A={}&-\int b_t^2dR_t
 -\int\iint_{G\times B}(1-\Psi)A_vD_t\,d\Pi_t^2d\log t\\
&-\int\iint_{G\times B}\Psi A_v(1-h_t)D_t^+\,d\Pi_t^2d\log t\\
&-\int\iint_{G\times B}\Psi(1-A_v)D_t^-\,d\Pi_t^2d\log t
 -N_{del}^{row}.
\end{split}
\tag{WR6}
\]
第二项是signed的suffix补项，不能只留下其有利部分。其余负量均只在同一账中使用一次。

若一次删除比例为 `d=Π_-(Z_-\setminus Z_+)<1`，则
\[
 F_+=F_-/(1-d),\quad b_+=b_-/(1-d),\quad
 \Delta(Fb)=(F_-+F_+)\Delta b.
\tag{WR7}
\]
这是原双e的正重标，不是N_del。在分段AC且仅有跳跃删除的路径上，再次分部会给
\[
 -\int b^2dR=F_\ell b_\ell-F_rb_r+
 \int2F_tb_t'd\log t+\sum\Delta(Fb),
\tag{WR8}
\]
一般连续奇异删除还需在WR8右端加 `∫2F_t db_t^{sing,c}`。统一写法为 `−∫b²dR=Y_ell−Y_r+∫R_t d(b_t²)`；R连续，故同一Stieltjes项同时包含连续、奇异及跳跃重标。WR5的价值是保共同归一结构，不能据此丢掉全部重标。终端ratio、R单调及其来源列价均未假定。

## 3. 两条实际阈值路径的能量定理

固定真实 `(ω,V,j,y)` 与两来源v,u，固定辅助时间窗 `[ell,r]`。令 `T=log(r/ell)≥0`。物理权为
\[
 w_t(z)=\prod_{i=1}^n\min(1,\alpha_i(z)/t),\quad
 \alpha_i(z)={b\over c_j}C(|y_i-z_i|/b)>0.
\tag{WR9}
\]
来源原参数与坐标可任意相关；以下不采用来源坐标独立。

允许任意两个固定正幅度 `a_v,a_u`，定义仅用于本引理的条件两源概率
\[
 \vartheta_t={a_vw_t(v)\over a_vw_t(v)+a_uw_t(u)},\quad
 L_t=\log{a_vw_t(v)\over a_uw_t(u)},\quad
 d_t=k_t(u)-k_t(v).
\tag{WR10}
\]
它不是替换原Π。一个幅度为零时ϑ恒0或1、交换为零；两幅度都零无行。原回代取两幅度1。

每个k_t(z)是0至n的非减整数阶梯，有限个阈值交叉可以同时发生。L和ϑ连续、AC；几乎处处
\[
 L_t'=d_t,\qquad \vartheta_t'=\vartheta_t(1-\vartheta_t)d_t.
\tag{WR11}
\]
以下取起点右内迹、末点左内迹，阈值Stieltjes测度只含开区间 `(ell,r)`；端点阈值不再另计。等价的右末约定亦可，但必须同时改边界与原子范围。

定义真实阈值费用
\[
 H_{vu}=|d_{\ell+}|+|d_{r-}|+
 \operatorname{TV}_{(\ell,r)}d,
\quad
 N_{vu}=\max\{k_{r-}(v),k_{r-}(u)\}
       -\min\{k_{\ell+}(v),k_{\ell+}(u)\}.
\]
物理单调性给
\[
 H_{vu}\le2N_{vu}\le2n.
\tag{WR12}
\]
证明：`TV d≤Δku+Δkv`，而
`|ku_l-kv_l|+|ku_r-kv_r|+Δku+Δkv=2(max k_r-min k_l)`。共同阈值的两腿跳可相消，因此真实H可能更小。

由ϑ连续、d为BV，严格分部得到
\[
\begin{split}
 \mathcal E_{vu}
 &:={\int_\ell^r}\vartheta_t(1-\vartheta_t)d_t^2d\log t\\
 &=[(\vartheta_t-1/2)d_t]_{\ell+}^{r-}
   -\int_{(\ell,r)}(\vartheta_t-1/2)\,dd_t
 \le H_{vu}/2\le N_{vu}\le n.
\end{split}
\tag{WR13}
\]
没有对score阶梯作遗漏原子的普通微分。再由Cauchy得
\[
 \boxed{\operatorname{TV}_{[\ell,r]}\vartheta
 \le\sqrt{\mathcal E_{vu}\int_\ell^r\vartheta_t(1-\vartheta_t)d\log t}
 \le {1\over2}\sqrt{T\,N_{vu}}\le {1\over2}\sqrt{nT}.}
\tag{WR14}
\]
所以早先只利用`TV d≤2n`得到的 `√(nT/2)` 也成立，但WR14使用两个端点与单调增量的共同预算更强。T=0时积分为0。

分部中的常数1/2可以分别换成0、1。记 `m_*=min(sup_tϑ_t,sup_t(1-ϑ_t))`，则
\[
 \mathcal E_{vu}\le H_{vu}\min(1/2,m_*)
 \le N_{vu}\min(1,2m_*).
\tag{WR15}
\]
这保留一槽确实稀少时的改善，不将固定幅度变成随t选择的概率。

## 4. 和原正负score逐点对齐

取幅度1，定义真实pair重用权
\[
 \Omega_t(v,u)={1_{Z_t}(v)1_{Z_t}(u)
 (w_t(v)+w_t(u))^2\over e_t^2}.
\]
则原双后验密度恰为
\[
 {d\Pi_t^2\over d(\nu\otimes\nu)}
 =\Omega_t\vartheta_t(1-\vartheta_t),\quad
 \delta_t(v,u)=[-d_t]_+.
\tag{WR16}
\]
故每个固定pair的原正/负flux分别是
`Ω(-ϑ')+` 与 `Ω(ϑ')+`，均乘原ν²及其它原权。WR14控制不带Ω的全部交换，不能把每个pair的根价直接求和当作原概率总价。

保A且暂时全配对/无其它正门时，同pair的signed交通精确为
\[
 \Omega_t\{A_v(-\vartheta_t')_+-(\vartheta_t')_+\}
 =-A_v\Omega_t\vartheta_t'
  -(1-A_v)\Omega_t(\vartheta_t')_+.
\tag{WR17}
\]
因此有限BV Ω下
\[
 \int\Omega\{A_v(-\vartheta')_+-(\vartheta')_+\}
 =A_v[\Omega_\ell\vartheta_\ell-\Omega_r\vartheta_r]
  +A_v\int\vartheta\,d\Omega
  -(1-A_v)\int\Omega(\vartheta')_+d\log t.
\tag{WR18}
\]
ϑ连续，所以删除、阈值同时发生亦无ϑ跳交叉。真实Ψ/h仍按WR6的准确项恢复；不能利用WR18重复使用原reverse负项。此式把原信用具体对应到条件两源概率的反向变差，并明确暴露实际pair重用的交换成本。

对原G×B或G×G终端pair，在非删除段
\[
 {\Omega_t'\over\Omega_t}
 =2(\bar k_t-k_t^{pair}),\quad
 k_t^{pair}=\vartheta_tk_t(v)+(1-\vartheta_t)k_t(u),
 \quad\bar k_t=\Pi_tk_t.
\tag{WR19}
\]
删除时Ω放大为 `(1-d)^{-2}Ω_-`。因此 `dΩ` 不由两条物理阈值单调性控制；其它来源及原删除的影响不能遗漏。涉及未来删除pair时，移除跳也保真实支持，不能只留正重标。

## 5. 带原pair权的能量账，不以逐pair上确界代付

对原非负可测测试 `0≤M≤1`（含H和所需来源标签），在同一原外测度下可直接Cauchy：
\[
 \int M\Omega\vartheta(1-\vartheta)|d|\,d\log t\,d\nu^2\,d\mathcal T
 \le\left(\int M\Omega\vartheta(1-\vartheta)\,d\log t\,d\nu^2\,d\mathcal T\right)^{1/2}
 \left(\int M\Omega\vartheta(1-\vartheta)d^2\,d\log t\,d\nu^2\,d\mathcal T\right)^{1/2}.
\tag{WR20}
\]
可把固定A差等非负因子并入共同测度，不能只给其中一因子附门后称等价。此处没有将d𝒯中的p、hard源或q省去。

对一个终端pair，若需利用WR13控制第二因子，实际无门加权能量满足
\[
 \begin{split}
 \mathcal E_{vu}[\Omega]
 &=\int\Omega\vartheta(1-\vartheta)d^2d\log t\\
 &=[\Omega(\vartheta-1/2)d]_{\ell+}^{r-}
 -\int\Omega_t(\vartheta_t-1/2)\,dd_t
 -\int d_{t-}(\vartheta_t-1/2)\,d\Omega_t.
 \end{split}
\tag{WR21}
\]
阈值原子用Ω后态、Ω原子用d前态，因而同时跳的乘积项完整保留。更一般BV情形用同一约定包括连续奇异部分。门M仅可测时不能再把它无价微分；可正放M后用WR21，或保持WR20。

WR21中的阈值项具有明确有限原子/端点费用；最后一项是原posterior重用引入的具体交换。即使WR13无权费用≤n，该项没有因此消失。不能提出 `sup Ω` 后只报告根价而隐去所得 `ν²/e²` 列。

## 6. 对内部反排序协方差的准确适用范围

主势中的G/G内部项为
\[
 I_{GG}(t)={1\over2}\iint_{G\times G}
 (A_v-A_u)(k_t(v)-k_t(u))\,d\Pi_t^2.
\]
其负部积分由WR16–20控制，但保实际 `|A_v-A_u|Ω`。当同一pair的A差固定时，WR14首先给条件两源路径价
\[
 \int |A_v-A_u|\,\vartheta_t(1-\vartheta_t)|k_t(v)-k_t(u)|d\log t
 \le {|A_v-A_u|\over2}\sqrt{TN_{vu}}.
\tag{WR22}
\]
这个界对实际C阈值任意排列成立，包含多次反排序交换，不要求R单调，也不只在少数坐标相近时成立。它是本稿的新物理联合估计。但实际I_GG还乘Ω，并有真实接收核/捕获/历史权，不能把WR22称为I_GG的一般来源根价。

E/G项还涉及未来删除标签；其支持和原N_del必须同账，不能借终端pair没有删除来扩大适用域。原s、L、R、j、g和α在每行固定。逐行得到WR14不允许任意接收选择器免费；辅助时间长度由原far窗控制，若扩大到fixed-j共同定义域，仍保原合法域和每个独立窗口费用。只有在原唯一j指示未丢且已获统一接收行价时才能无j菜单合并。

## 7. 明确结论与下一处预算

原共同双e可以在WR5的signed ratio中精确消去，且原物理阈值提供WR13–15的全时间根阶交换界。它避免将每次score交叉分别按n计价，也不是终端权比条件的重述。

一般付款仍缺一个具体联合结算：在原d𝒯、ν²及same-A下，WR21最后的pair重用交换，连同主势的E/G项及WR6未消费/已消费suffix区别，能否由原负余额与真实共同来源容量控制，同时使WR20两个因子的全局乘积达到目标来源价。若只独立使用既有n能量，再使用一个√n伴随核界，仍是n^(3/4)，没有完成根阶目标。

本文未更换source后验，未假ν≤β，未把删除原子叫作N_del，未给原只可测门BV资格，未使用每叶质量帽。没有把WR21的新表达式命名为已付款范数；其未付项写出了实际系数、score及归一化来源。
