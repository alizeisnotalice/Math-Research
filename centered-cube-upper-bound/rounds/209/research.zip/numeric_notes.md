# R209 exact finite potential checks

All calculations use the Python standard library and Fraction. The actual run passed 134 conditional finite models: three hand-calculated initial examples, three deletion/zero-weight/interleaved-score pressure examples, and 128 deterministic rational examples generated with seed 2091040. Separate additional groups contain nine actual threshold-product pair paths and three conditional cut calibrations. Expanded posterior models have 4–8 source atoms, positive rational raw masses normalized by their full total, and nonnegative integer scores 0–8. Atom count is not claimed to be original cube dimension. These data do not realize original physical source geometry, actual suffix gates, forest/history or FULL input.

## Ratio and continuous potential identities

G,B,E are a disjoint partition, G and B are nonempty, and A is fixed in [0,1] on G. On each current carrier p is a probability, b=p(B)>0, F=sum_G pA and R=F/b. The derivative is calculated from p'=p(mean k-k). The direct signed cross sum C_A=sum_GB A_v p_vp_u(k_v-k_u) agrees exactly with -b^2R' computed by the quotient rule. Positive and negative cross parts are recorded separately. No monotonicity of R is assumed.

For f=A on G,1 on E,0 on B, T=sum pf, the script checks -T'=Cov(f,k) by three independent representations: direct p' summation, the scalar covariance, and the full unordered-pair sum. It then partitions that sum into G/B weighted flux, E/B full flux, E/G (1-A) weighted signed flux, and G/G weighted signed flux. Each unordered pair appears once; the ordered G/G formula is independently divided by two. E/E and B/B contribute zero.

A finite exact layer cake splits at every distinct f value and computes each threshold's signed upper-set/complement flux. Its integrated mass equals T, and its integrated signed flux equals -T'. This checks the finite representation only; it grants no tree/Carleson or infinite-path budget.

The three initial examples have independently hardcoded rational F,b,R,R',C_A,T,T' and deletion increments. Their pre-deletion (C_A,T') pairs are (2/9,-1/3), (11/144,-13/48), and (0,0), with deletion (Delta(Fb),Delta T) pairs (5/36,-1/6), (35/576,-3/16), and (1/12,-5/12). These match the calculated expressions exactly.

## E-only deletion

Deletion is restricted to a fixed subset of E, including concurrent deletion of several atoms. Its d is the complete pre-deletion posterior mass, and d<1 follows here from retained positive B mass. The post-deletion probability is independently rebuilt by removing raw masses and normalizing the survivors. It is not freely assigned. Post-state continuous identities are then checked again on that carrier, with deleted atoms explicitly carrying zero mass.

The ratio R is unchanged, and Delta(Fb)=(Fminus+Fplus)Delta b is checked exactly, including F=0. The safe potential satisfies Tplus=(Tminus-d)/(1-d) and Delta T=-d(1-Tminus)/(1-d)<=0. There are 19 concurrent deletions and 47 zero-deletion examples. These are finite exact jumps, not deletion time densities or a consumption of original negative credit.

## Actual binary gate and fixed-c potential arithmetic

The finite gate interface keeps Psi binary (0 or 1), while h ranges over 0,1/2,1. Each model tests one pair-dependent mixed pattern and six constant combinations. Constant profiles are diagnostics, not an assumption that the original suffix gate is an entire-row constant. The mixed pattern is genuinely pair-dependent whenever there are multiple G/B pairs. No assertion is made that these abstract bit patterns are all realizable original suffix qualifications.

For every profile, the direct signed q=sum_GB Psi(AhDplus-Dminus)-sum_EB Dminus is compared with -T'-I-sum_EB Dplus+Gamma. Both expressions for Gamma are independently evaluated. In the alternative expression, -(1-Psi)A D uses signed D; it is not replaced by Dminus. Gamma is recorded with its actual sign. When Psi=1, each pair's mismatch contribution is nonpositive, but Psi=0 can produce positive Gamma, which is retained.

Every model also uses three fixed coefficient choices c=max_G A,(1+max_G A)/2,1. The choices can coincide; they remain three named algebra checks, not three independent models. For Tc=sum_G pA+c p(E), Ic=sum_EG(c-A_u)D+the unordered G/G term, the exact check is

q=-Tc'-Ic-c sum_EB Dplus-(1-c)sum_EB Dminus+Gamma.

The two c-dependent E/B terms are both retained. Deletion checks Tcplus=(Tcminus-cd)/(1-d) and Delta Tc=d(Tcminus-c)/(1-d)<=0. The c=0 case in the all-zero-A model is handled directly without division by c. In total there are 268 pre/post covariance-decomposition states, 5628 fixed-c/gate identities and 2814 fixed-c deletion checks; repeated algebra profiles do not constitute additional source models.

## Observed signed diagnostics and limits

Among pre-deletion models, C_A is negative/zero/positive in 47/17/70 cases; E/G in 66/13/55 and G/G in 38/60/36. Among the 938 pre-deletion gate profiles, Gamma is negative/zero/positive in 630/143/165. Thus the checker preserves the signed internal terms and gate correction; it neither drops them nor treats all potential increments as automatically paid. These sign counts describe this fixed menu only and are not a random statistical claim, a uniform theorem or an exponent fit.

The E03 skill's finite-budget and terminal-condition discipline was used. No tree reach masses, child transition model, Carleson conditions or infinite-depth terminal limit were supplied here, so no literature Bellman constants or tree migration conclusion are invoked. The exact identities are local finite conditional algebra. Bounds T<=1 or Tc<=c alone do not pay a source column, selector, entry/recharge or original common-measure integral.

## Actual product-threshold pair paths

Nine specified paths, three per stage, use n=1,2,4,8,16 coordinates with C_i,D_i in (0,1]. At tau in [1/2,1], weights are exactly wv=product min(1,C_i/tau), wu=product min(1,D_i/tau), and bpair=wv/(wv+wu). These are actual nonlinear product-clock weights, not arbitrary b samples. All distinct interior C/D thresholds are sorted; simultaneous thresholds share one breakpoint. On each segment exact endpoint weights also satisfy their constant-score power law, and the independent quotient derivative at its rational midpoint agrees with bpair(1-bpair)(ku-kv).

Initial paths are a same-source n=1 threshold 3/4; the endpoint pair C=1/2,D=1; and n=2 interleaving C=(1/2,3/4),D=(5/8,1). Pressure has the n=4 crossing arrays C=(1/2,5/8,7/8,1),D=(9/16,11/16,13/16,15/16), repeated identical thresholds, and n=8 separated arrays C_i=1/2,D_i=1. Expanded has n=8 dense alternating thresholds C_i=(8+i)/16,D_i=(17+2i)/32 for i=0..7; n=16 C_i=2^-100,D_i=1; and n=16 identical tiny C/D arrays. This last path has Npair=0 and is handled without division.

Start scores use right interior traces k(1/2+)=#{C_i<=1/2}; end scores use left interior traces k(1-)=#{C_i<1}, and likewise for D. No endpoint score jump is charged as an interior atom. Segment bpair is monotone, so TV is the exact sum of absolute endpoint changes. Its score difference a=ku-kv is constant there and energy is exactly sum a Delta bpair. The energy is independently checked against the finite Stieltjes identity [(bpair-1/2)a]_start^end minus the sum of (bpair-1/2)Delta a at interior thresholds. The old half-bound .5(|a_start|+|a_end|+TVa)<=2n and the new energy<=Npair=max(kv_end,ku_end)-min(kv_start,ku_start)<=n both pass.

The log-window is log 2. Instead of rounding it, the script constructs the exact rational lower bound L40=2sum_{j=0}^{39}(1/3)^(2j+1)/(2j+1)<log 2. Every chosen path passes the stronger sufficient Fraction comparisons TV^2<=Npair*L40/4 and TV^2<=energy*L40/4. The earlier weaker n*L40/2 check is also retained. Thus no false interval or floating claim is needed. For the n=1 opposite-endpoint path TV=energy=1/6. For separated n=8, TV=255/514 and energy=1020/257. The tiny unequal n=16 path remains exactly nonzero even when bpair is extremely close to zero; no float underflow can replace it by zero.

These are finite one-dimensional physical product-clock tests, not complete source geometries or an asymptotic/root-rate proof. In particular the original pair reweighting (wv+wu)^2/e^2 is outside this relative posterior certificate and has not been paid.

## Three conditional cut calibrations

These three small rational models use a single fixed p, the same binary Psi at every integer score layer, c=1 and h=1. The low mass combines (1-A_v)p on E and (A_w-A_v)_+p on G below k_v-ell. The reverse bad excess (A_v-Psi)_+ and available (Psi-A_v)_+ use the same B sources above k_v+ell. Each layer's signed deficit is kept, and the total defect U sums its positive part with the same p_v. Source credit is not reselected independently at each layer.

The balanced three-atom calibration and the four-atom reverse-weight-order calibration satisfy all cut inequalities with U=0. Their (q,Cov) values are (-1/3,-1/3) and (-7/8,-25/32). The third calibration keeps the first sources but changes Psi to zero: one cut is deliberately violated, U=1/9, and q-Cov=1/9 exactly, with q=-2/9 and Cov=-1/3. Its PASS label means that the predicted defect arithmetic is verified, not that its cut condition holds. All examples verify q<=Cov+U, explicitly recording whether the cut itself holds. These are conditional finite cut identities, not full physical qualification or an unconditional global budget.

## Reproduction

Only standard-library Python is required:

```sh
python3 potential_checks.py --output potential_checks.json
```

The --output path can be fresh. Relocation requires the script and task_contract.md; the latter is bound by portable filename/SHA in JSON. Seed and all finite inputs are explicit. JSON contains no runtime, installation path or probabilistic sampling error. This numerical task writes only potential_checks.py/json and these notes, without modifying other agents' files.


The final script and contract were actually copied to a fresh temporary directory and run with exit 0. Complete JSON matched byte-for-byte. Measured isolated replay time was 0.573 seconds, kept in notes only. Directory: /var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r209_pair_cut_final_79asmq5j. Actual local interpreter: /opt/homebrew/opt/python@3.14/bin/python3.14.
