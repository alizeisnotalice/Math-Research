# R209：保 A 层饼势、删除安全符号与同槽反射容量

状态：对原同一来源/森林/终端权建立保 A 的精确势和完整层间协方差；删除重标在该势中确为非正。内部不利层间交通可无除法地合并到同一 G 槽的真实低-score 测度，再以同槽原 bad 高-score 信用核验有限反射 cut。条件满足时得到真实保权行预算；原物理几何尚未证明这些 cut 的外测度不足可付，入口/selector/source 总账也未闭合。未读本轮 Astra 新稿。

使用 E03 技能仅限共同预算、终端及单次信用核查纪律，不迁移其树测度定理或常数；实际本文全为有限/有界测度代数和原时间权路径计算。

## LP1　原行、外测度与互斥来源

本轮合同以及冻结 R208 `raw_clock_joint.md` 前 70 行是本稿原对象出处：原 R128 RT1--3、RT4 的同一行、原 R127 SP2--3 的终端 target 支撑。外测度保持
\[
 d\mathcal T_I=1_I1_{j(x)=j}q^{-1}p_yh_{R(x)}(x-z)
 a_\omega(x,y,z)\,dx\,\beta_V(dy)\nu_V(dz).
 \tag{LP1}
\]
此硬源 z 不等于下述 bad 槽 u。原期望、V/j/window、high/far 和有限截断均不消失。所有 signed 恒等式先在同一 LP1 行及原未另行 hard 帽的共同测度成立，不能分别正放松两个符号后再相减。

固定原终端 G=S_g、B=D_g，G∩B为空，且 G∪B=Z_g。E_t=Z_t\Z_g 只删除，
\[
 Z_t=G\mathbin{\dot\cup}B\mathbin{\dot\cup}E_t,\quad
 w_t\ge0,\quad {d w_t\over d\log t}=-k_t w_t,\quad
 e_t=\int_{Z_t}w_t\,d\nu>0,\quad
 \Pi_t={1_{Z_t}w_t\nu\over e_t}.
 \tag{LP2}
\]
固定原 terminal A:G→[0,1]；实际 A=1_G rho J/S，在辅助 t 不重算 alpha/current/capture。来源 nu、beta 只共同父支配，无 nu<=beta。

原 suffix 门 Psi=1_{calZ^c} 可能依全部 pair/row/time；不假定为整行常数。其它正门 0<=h<=1。令 D_t(v,u)=k_t(v)−k_t(u)，D+=max(D,0)、D−=max(−D,0)。本稿精确处理的 signed 行密度为
\[
 \mathcal S_t=
 \int_{G\times B}\Psi(v,u)[A(v)h(v,u)D_+-D_-]d\Pi_t^2
 -\int_{E_t\times B}D_-d\Pi_t^2.
 \tag{LP3}
\]
原负信用只用于这一 J 子份额一次；其它正 share 不再领取它。LP3 不是将所有母 raw 定义成新泛函。所有量先有限截断，去截断须保实际可积性，不能作无穷减无穷。

## LP2　保权势及 c 参数

选对本行时间固定的 c∈[0,1]，满足 A<=c 为 nu|G-a.e.；可用 c=1，或合法可测的 esssup_G A。取全初始来源上的固定函数
\[
 f_c=A1_G+c1_{E_\ell},\qquad
 F_t=\int f_c\,d\Pi_t
 =\int_G A\,d\Pi_t+c\Pi_t(E_t),\qquad0\le F_t\le c.
 \tag{LP4}
\]
f 在已删 E 源上的值仍为 c，只是其来源权为零。因此没有给每次删除重定义一个新 target 或新 alpha。c=0 必使 A=0，此时正交通零、LP3非正，单独处理即可；后式不除 c。

本行 c 可依原 x,y,omega,V,j 等终端数据，但沿辅助 t 固定；不能逐运行时刻自由选最优 c 后仍丢其变化。esssup 的使用不默认给 source 积分价；在联合可测 A/nu 家族下，其可测性可由有理 a 的事件 ∫G1_{A>a}dν>0 判定。

无删除开段上，dot=d/dlogt，原商法则给
\[
 \dot\Pi_t=(\bar k_t-k_t)\Pi_t,\qquad
 \dot F_t=-\operatorname{Cov}_{\Pi_t}(f_c,k_t).
 \tag{LP5}
\]
这是同一原 Pi，不是假定归一 posterior 本身按−k衰减。

## LP3　删除、连续移除与端点：符号无需门 BV

在一次仅删除 E 的事件，令 d=Pi_-(deleted)<1。删除的是 f_c=c 的源，故
\[
 F_+={F_--cd\over1-d},\qquad
 \boxed{\Delta F={d\over1-d}(F_--c)\le0.}
 \tag{LP6}
\]
必须用 pre-delete F 和同一真实 d；并发删除合并一次。d=0 直接无跳；d=1 为死亡行，先终止，不能延续概率分母。这个势的删除跳不是原 N_del 的时间密度，也不再领取一遍原负信用。

可覆盖一般联合可测 nested E_t：在有限 log-time 区间，原 w 对时间绝对连续且非增，source 每点最多退出一次。按其实际退出时刻加权构造正删除测度 dL_t，未归一权 n_t=1_Zt w_tν 满足
\[
 dn_t=-k_tn_t\,d\log t-dL_t,\qquad d\lambda_t=dL_t(V)\ge0,
 \quad dL_t\text{ 仅支撑原退出的 E 来源。}
\]
例如右连续退出约定下，source z 的退出时刻为 s(z)，删除权为 w_{s(z)}(z)ν(dz)在该时刻的推前；有限原森林截断是其原子特例。阈值 k 自身的跳不产生 w 的跳。

若 nu 有限、0<=k<=n、有限时间且 e 有正下界，分子 ∫f_c dn 和分母 e 均有界变差，故 F 为 BV；不需要任意 L1 输入的空间梯度，也不需要 Psi/h 的 BV。连续删除部分严格为
\[
 dF_t|_{del,c}=(F_t-c){d\lambda_t\over e_t}\le0.
 \tag{LP7}
\]
此处仍需原联合可测 nested 支撑及退出/端态代表，不能仅由一个任意 nonnested selector 宣告上述删除测度存在。原终端 e_g>0 时 e_t>=e_g，给所需正下界；e_g=0 原行先按合同零/死亡分支处理。

取右起态 ell、闭端右末态 g，跳与删除计(ell,g]；纯时间积分不受端点零测影响。令 J_del 为这些真实原子事件，连续删除记LP7，则完整积分身份为
\[
 \int_\ell^g\operatorname{Cov}_{\Pi_t}(f_c,k_t)\,{dt\over t}
 =F_\ell-F_g+
 \sum_{t\in J_{del}}\Delta F_t+
 \int_{(\ell,g]}(F_t-c){d\lambda_t^c\over e_t}.
 \tag{LP8}
\]
原子用LP6、连续用其真实代表；死亡和去截断另守卫。最后两项均非正，不能将其说成另已获的 source 金额。

## LP4　协方差的完整 G/B/E 分拆

以下所有乘积测度均为同一实际 Pi_t²，省略 t。记
\[
 C_{GB}=\int_{G\times B}A(v)(k_v-k_u),\quad
 C_{EB}=\int_{E\times B}(k_z-k_u),
\]
\[
 I_{GG}=\tfrac12\int_{G\times G}(A(v)-A(w))(k_v-k_w),
 \quad
 I_{GE}^{(c)}=\int_{G\times E}(A(v)-c)(k_v-k_z).
 \tag{LP9}
\]
则精确有
\[
 \boxed{\operatorname{Cov}_{\Pi}(f_c,k)
 =C_{GB}+cC_{EB}+I_{GG}+I_{GE}^{(c)}.}
 \tag{LP10}
\]
证明由 Cov=1/2∫(f(v)−f(u))(kv−ku)Π²，按互斥来源分块；EE、BB为零，两种相反方向合并一次。GG不能因 A 终端固定就设零；A 随来源变化仍有内部协方差。GE系数为 A−c，不是 A，也不自动非负。

## LP5　层饼及不重复信用

令 G_a={v∈G:A(v)>a}，0<=a<=c，f_a=1_{E_ell∪G_a}，F_{a,t}=Π_t(E_t∪G_a)。则
\[
 f_c=\int_0^c f_a\,da,\quad
 F_t=\int_0^cF_{a,t}\,da,\quad
 \operatorname{Cov}(f_c,k)=\int_0^c\operatorname{Cov}(f_a,k)\,da.
 \tag{LP11}
\]
A=a 的端点对 da 零测，重复 A 值不会产生层数费。每个固定层的删除值为1，F_a<=1，删除非正；积分恢复LP6/7。

每层 covariance 精确为
\[
 \int_{G_a\times B}D+c_a\int_{E\times B}D
 +\int_{G_a\times(G\setminus G_a)}D
 +\int_{E\times(G\setminus G_a)}D,
 \qquad c_a=1.
\]
对 a 从0积到c，GB系数恢复 A，EB恢复 c，第三项恢复 I_GG，第四项恢复 I_GE^(c)。G_a 与 E 同值1，之间无该层项。

这不能解释为每一 a 均使用一次完整原 −D−：必须先共同 layer 积分得到LP10，再按LP12的精确权领取原负信用。层饼是同一势的线性分解，不另造森林、来源或捕获。

## LP6　原 signed 门的精确误差

不假 Psi 常数，只用0<=Psi,h<=1，逐pair代数给
\[
 \boxed{\begin{split}
 \mathcal S_t={}&\operatorname{Cov}_{\Pi_t}(f_c,k)
 -I_{GG}-I_{GE}^{(c)}
 -c\int_{E\times B}D_+-(1-c)\int_{E\times B}D_-\\
 &-\int_{G\times B}A(1-\Psi h)D_+
 -\int_{G\times B}(\Psi-A)D_-.
 \end{split}} \tag{LP12}
\]
所有积分仍同一 Pi²。证明：GB项相对AD差恰−A(1−Psi h)D++(A−Psi)D−；EB相对cD差恰−cD+−(1−c)D−，再用LP10。原Psi=指示也可能在坏方向关闭负信用，因此最后一项不自动非正。

不能仅从 c=1、F<=1 就称原剩余是导数；LP12的 GG、GE 以及 gate 差都实际存在。这个结论也不能用“R单调”替代证明。

## LP7　内部逆序通量与同一低 A 槽的测度

定向每对GG到低A槽v，定义非负分量
\[
 N_{GG}=\int_{G\times G}(A(w)-A(v))_+(k_v-k_w)_+,
 \quad P_{GG}=\int_{G\times G}(A(w)-A(v))_+(k_w-k_v)_+,
\]
\[
 N_{GE}=\int_{G\times E}(c-A(v))(k_v-k_z)_+,
 \quad P_{GE}=\int_{G\times E}(c-A(v))(k_z-k_v)_+.
 \tag{LP13}
\]
精确 I_GG=P_GG−N_GG、I_GE^(c)=P_GE−N_GE。A相等两源不贡献；无需假A与score同序。

对每一个实际v∈G，定义有限正测度
\[
 \boxed{\mathsf L_v(dw)=(c-A(v))1_E(w)\Pi(dw)
 +(A(w)-A(v))_+1_G(w)\Pi(dw).} \tag{LP14}
\]
不除c−A，c=A(v)边界安全；此时两项均零。则
\[
 \int_G\int(k_v-k_w)_+\mathsf L_v(dw)\Pi(dv)=N_{GG}+N_{GE}.
 \tag{LP15}
\]
内部不利项因而已合并到同一个v的真实低-score池，保source相关性和A。该池依原Pi/time，不是固定参考coupling，也未声称它独立receiver。

## LP8　同槽原负信用的有限反射 cut

这里使用实际整数score k∈{0,...,n}。对每v∈G、ell=1,...,n，定义
\[
 L_{v,\ell}=\mathsf L_v\{k\le k_v-\ell\},
\]
\[
 M_{v,\ell}=\int_B(A(v)-\Psi(v,u))_+
    1_{\{k_u\ge k_v+\ell\}}\Pi(du),
\quad R_{v,\ell}=\int_B(\Psi(v,u)-A(v))_+
    1_{\{k_u\ge k_v+\ell\}}\Pi(du),
\]
\[
 H_{v,\ell}=L_{v,\ell}+M_{v,\ell}-R_{v,\ell},\qquad
 \mathfrak U_t=\int_G\sum_{\ell=1}^n(H_{v,\ell})_+\Pi_t(dv).
 \tag{LP16}
\]
若集合阈值落在score范围外，按空集/全集直接定义，不截成错误层。整数身份 (a−b)+=Σell1{b<=a−ell} 给
\[
 \int_G\sum_\ell H_{v,\ell}\Pi(dv)
 =N_{GG}+N_{GE}
 +\int_{G\times B}(A-\Psi)_+D_-
 -\int_{G\times B}(\Psi-A)_+D_-.
 \tag{LP17}
\]
是精确恒等式，无额外 n 乘数；当然实际sum自身仍可随n大，不把其量级声明为小。

定义保留的全部有利项
\[
 \mathfrak P_t=P_{GG}+P_{GE}
 +c\int_{E\times B}D_++(1-c)\int_{E\times B}D_-
 +\int_{G\times B}A(1-\Psi h)D_+\ge0.
\]
LP12精确化为
\[
 \boxed{\mathcal S_t=\operatorname{Cov}_{\Pi_t}(f_c,k)
 +\int_G\sum_\ell H_{v,\ell}\Pi_t(dv)-\mathfrak P_t
 \le\operatorname{Cov}_{\Pi_t}(f_c,k)+\mathfrak U_t-\mathfrak P_t.}
 \tag{LP18}
\]
因此同一实际v及全部ell的可检验条件
\[
 \boxed{L_{v,\ell}+M_{v,\ell}\le R_{v,\ell}}
 \tag{LP19}
\]
能用同槽原GB负信用一次支付内部逆序与gate缺陷；没有每层重新选择来源、Psi或alpha。层间/反射层的sum是原scoregap的分解，并非复制信用。较弱的Σell H<=0亦足够，但LP19容易有限核验。

Psi=1时 M=0，R=(1−A(v))Pi_B{k>=kv+ell}，得到低score池与同v bad高score池的直接反射比较。Psi=0而A>0的坏方向，M而非R出现，明确记录关闭原负信用的真实代价。

非整数score不能用这些离散cuts；只可用连续阈值积分替换sum，并保实际可积条件。数值中任何分数score例不得当作本离散条件的检验。

## LP9　真实行预算及其尚未支付的外测度

积分LP18并用LP8，得到保权上界
\[
 \boxed{\int_\ell^g\mathcal S_t{dt\over t}
 \le F_\ell-F_g+\sum\Delta F_t
 +\int(F_t-c){d\lambda_t^c\over e_t}
 +\int_\ell^g(\mathfrak U_t-\mathfrak P_t){dt\over t}.}
 \tag{LP20}
\]
若LP19在实际support全部成立，U=0；删除项非正、Fg>=0，所以该条件支有行价Fell，而非丢A后的任意常数。原初始价完整为
\[
 F_\ell={\int_GAw_\ell\,d\nu+c\int_{E_\ell}w_\ell\,d\nu\over e_\ell}\le c.
 \tag{LP21}
\]
c小可降低初始后来删除来源的占用，但c=esssupA本身无source积分价；特别highA余域c可接近1。

LP20的所有项须共同乘LP1外测度、原期望/V/j、far和截断后再积分。即使使用Fell<=c<=1，原外层仍有自适应p_y=P_{s(x),L(x)}(x-y)、h_R(x-z)、唯一j及sources。不能以固定s,L的∫p_y dx=1支付receiver-adaptive价，也不能先分别hard帽signed两项。保A层饼未消原source/selector/window成本。

因此接一般根阶预算的准确后续要求是：由原实际核、森林、capture及receiver几何，对同一个真实外测度证明Fell端项与U的共同时间积分可用epsilon receiver或root-polylog来源支付，或与保留的P/终端/原负项联合结算；未证明这些反射cuts自动成立。静态capture或共同父来源nu,beta<=Aparent不能替代该外测度估计。本文没有从Pi概率性推出任何source列帽。

## LP10　三组可执行的最小有理模型

下列仅fixed-row条件代数，不声称物理C核/FIRST/森林/FULL或一般预算。全部h=1、c=1、score整数，使用同一Pi及Psi：

1. G,E,B各一源、Pi各1/3，A_G=1/2，k=(1,0,2)，Psi=1，n=2。唯一非零反射层ell1给L=R=1/6；U=0。S=Cov=−1/3，内部GE逆序与原GB多余负信用各1/18，恰相抵。
2. G有两源，连同E,B取Pi=(1/8,1/8,1/4,1/2)，A_G=(1/4,3/4)，k=(2,0,0,4)，Psi=1，n=4。低A槽ell1、2每层L=1/4、R=3/8；高A槽无向下score池。GG、GE两种内部逆序均存在，N_GG=1/64、N_GE=3/64，总1/16；反射条件仍成立，没有假定A和score同序。
3. 用模型1但Psi在G×B为0。ell1的L+M=1/3而R=0，U=1/9；实际S=−2/9，Cov=−1/3，差正好1/9。说明不能将suffix门当整行1而把其关闭信用删去。

删除测试可只删实际E，使用同一prePi的d重算postPi，检查LP6；不能另选删除后posterior。数值未执行前本文不预报通过，实际证据归数值责任文件。

## LP11　本轮新增与第一处物理缺口

新可用内容为：保A且对完整真实删除路径符号安全的层饼势；完整GG/GE有符号缺项；把内部逆序定向合并为同槽低score measure，并与原suffix门下实际bad高score负信用给出有限反射cut和准确不足。满足条件的支由LP20真实支付到保权初始端态，未使用新来源或重新归一。

没有证明一般原source/receiver结构使LP19成立，也没有证明LP21及U的外测度可积root价。它不是任意cut更名为闭合：LP16--19给出可直接验证、同source/同门/同score的具体阈值公式；其是否由实际mixed核、tree/capture共同几何支付，是准确首个待证步骤。本文不认证一般最终根阶目标。
