# R209 合同：保权势与全局极值几何

目标保持一般中心立方体 n^(1/2+o(1)) 弱型上界；本轮攻坚中间硬层同一来源权下的联合预算，不把代数身份当作最终闭合。

固定原RT1一行，保留外层期望、V,j、真实dx、beta、硬源nu、high及far时段。G=S_g,B=D_g固定终端存活且互斥，E_t=Z_t\Z_g；w'=-kw，prime=d/dlogt，Pi=1_Z w nu/e。A=1_G rho J/S属于[0,1]，沿原行时间固定。Psi=1_{Zcal^c}是原suffix门，不允许假为整行常数；h含其余正门，0<=h<=1。

原J子份额使用全负信用时，完整剩余为(P_J-N)+P_other；P_other不再用N。研究Q=积分[G×B Psi(Ah D+ - D-)] -积分[E×B D-]，D=kv-ku。来源外测度不得先分别hard帽再相减。

允许：R208已审一阶面核FO、共同捕获LC、原双后验RC，在其明确量词内使用；原R128 RT1–3、R121 GL1–5、R170来源定义窄读。禁止：无证R单调、source列界、nu<=beta、删除原子等同原Ndel时间密度、丢失A后声称来源可积。

准确任务：研究F=Pi A,b=Pi B,R=F/b与删除安全势T=Pi f，其中f=A onG,1 onE_t,0 onB；原负项和内部G/E协方差全部保留，求能由FO/LC几何付费的增量。成功是实质新保权预算或明确必要几何项与其可付款子部分；不得以重新命名余项作为一般闭合。

责任：主代理task_contract及main_potential.md与整合；Astra weighted_ratio_geometry.md；Sol辅助layer_potential.md；独审audit.md先审命题再读作者稿；数值Sol仅potential_checks.py/json及numeric_notes.md。多人共用文件，互不覆盖。数值三个阶段：手算、已知边界压力、扩大有理枚举，全部实际本机Fraction，有限模型不等于FULL物理输入。完成任务即停。不编译PDF。本轮完整核验后精简归档并独立提交推送。

技能：使用已安装E03树Bellman跨层预算势的预算/终端核查纪律；未建立树测度假设，不引用其文献常数或迁移定理。
