# 主推导：删除下降势及准确内部几何项

状态：有限状态、分段光滑原时钟的代数推导；待独审和一般来源预算。所有时间积分先在有限far子区间，所有外层测度保持RT1。

令 f=A on G, f=1 on E, f=0 on B，T=∫f dPi。非删除段f固定，Pi'=Pi(mean k-k)，故
-T'=Cov_Pi(f,k)=1/2∫∫(f(v)-f(u))(k(v)-k(u))dPi(v)dPi(u)。

将无序对分成G/B、E/B、E/G及G/G；E/E、B/B为零，得
-T'=C_GB+C_EB+I，
I=∫E×G(1-A_u)(k_v-k_u)dPi² +1/2∫G×G(A_v-A_u)(k_v-k_u)dPi²。
C_GB=∫G×B A_v D，C_EB=∫E×B D。

原signed行密度q满足精确式
q=-T'-I-∫E×B D+ + Γ，
Γ=∫G×B[-A(1-Psi h)D+ +(A-Psi)D-]。
等价 Γ=-∫(1-Psi)AD-∫Psi A(1-h)D+ -∫Psi(1-A)D-。
这里第二种表达第一个AD是signed乘积，并非D-。所有积分以同一Pi²为测度。Psi在0处可使Γ正，故不可直接丢弃。

一次仅删除E中质量d<1，T+=(T−−d)/(1−d)，从而ΔT=-d(1-T−)/(1-d)<=0。G、B存活且bad质量正时d<1自动；bad为零原q为零，另支处理。

因此在分段光滑有限跳路径上
∫q = T_l-T_r +ΣΔT -∫I -∫E×B D+ +∫Γ。
这是真实下降势。删除损失可保留为有利项，不需要把Ndel误当删除原子。

本轮核心几何问题现在具有具体形式：能否在原共同RT1外测度下，联合控制T_l（带E质量，不自动来源可积）、-∫I与Γ，并借助上述有利项恢复J来源权与根阶费用。单独T_l<=1不是source列预算。特别E/G项的(1-A)不能用A列积分替代；G/G项是实际A与score的反排序协方差，不能假设非负。需要利用A=rho J/S和物理时钟k的联合几何，而非抽象排序假设。

层饼表达A_v-A_u=∫_0^1(1_{A_v>a}-1_{A_u>a})da合法（有限状态Fubini）；其代价必须连同E/G和入口T_l整体处理。此处不宣称得到一般上界。


## 可优化的常数上盖
固定c∈[esssup_G A,1]，定义f_c=A onG,c onE,0 onB及T_c=Pi f_c。则
q=-T_c'-I_c-c∫EB D+ -(1-c)∫EB D- +Γ，
I_c=∫EG(c-A_u)D+1/2∫GG(A_v-A_u)D。
这里I_c中的D均signed，首项不是positive part。
删除E质量d时ΔT_c=d(T_c−-c)/(1-d)<=0，因为0<=f_c<=c。
这保留原负信用的(1-c)份，不能把每个c的信用重复相加。选最小c只优化同一行包络；esssup_G A依接收点，尚无全局source积分价格，不将其忽略。


## 同一target的反向容量缺口（待全文独审）
对v∈G令k=k_v，并在同一当前Pi上定义
L_v(dw)=(c-A_v)1_E(w)Pi(dw)+(A_w-A_v)_+1_G(w)Pi(dw)，
H_v(du)=(Psi(v,u)-A_v)_+1_B(u)Pi(du)。
则内部反排序支的总量为∫G l_v Pi(dv)，
l_v=∫(k-k_w)_+ L_v(dw)；原尚可用GB reverse容量为h_v=∫(k_u-k)_+H_v(du)。
在逐v配对后，仅收取Δ_v=(l_v-h_v)_+就给出一个确定上界；不需要新选来源，也没有把负信用重发给每个层。
整数score时 l_v=Σ_{j=1}^n L_v{k_w<=k-j}，h_v=Σ_{j=1}^n H_v{k_u>=k+j}。每个反射cut前者<=后者为充分条件，合计l_v<=h_v是更弱的充分条件；不把逐cut条件强加为必要条件。

若记Γ_pos=∫GB(A-Psi)_+D-、Γ_FA=∫GB A(1-Psi h)D+，I_pos为I的正向对贡献，则逐时
q<=-T_c' +∫G Δ_v Pi(dv)+Γ_pos−Γ_FA−I_pos−c∫EB D+−(1-c)∫EB D-。

这是可审计的实际负容量匹配，仍未证明一般原物理历史下Δ_v与Γ_pos、入口项在共同接收几何上的根阶费用。重要的是保持这些来自原量的确定积分，而非任意新余项范数。
