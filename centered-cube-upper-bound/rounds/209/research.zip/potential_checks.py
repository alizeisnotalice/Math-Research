#!/usr/bin/env python3
"""R209 exact finite posterior/potential algebra; no physical FULL certificate."""
import argparse,hashlib,json,random
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
HERE=Path(__file__).resolve().parent
SEED=2091040

def enc(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x

def positive(x):return max(F(0),x)
def bilinear(p,left,right,term):
    return sum((p[v]*p[u]*term(v,u) for v in left for u in right),F(0))


def continuous(p,k,A,G,B,E):
    assert sum(p)==1 and all(x>=0 for x in p)
    n=len(p);mean=sum((p[i]*k[i] for i in range(n)),F(0))
    pdot=[p[i]*(mean-k[i]) for i in range(n)];assert sum(pdot)==0
    massB=sum(p[i] for i in B);assert massB>0
    massA=sum(p[i]*A[i] for i in G)
    Fdot=sum(pdot[i]*A[i] for i in G);bdot=sum(pdot[i] for i in B)
    R=massA/massB;Rdot=(Fdot*massB-massA*bdot)/massB**2
    CA=bilinear(p,G,B,lambda v,u:A[v]*(k[v]-k[u]))
    CAplus=bilinear(p,G,B,lambda v,u:A[v]*positive(k[v]-k[u]))
    CAminus=bilinear(p,G,B,lambda v,u:A[v]*positive(k[u]-k[v]))
    assert CA==-massB**2*Rdot==CAplus-CAminus
    f=[A[i] if i in G else F(1) if i in E else F(0) for i in range(n)]
    T=sum(p[i]*f[i] for i in range(n));Tdot=sum(pdot[i]*f[i] for i in range(n))
    covariance=sum(p[i]*f[i]*k[i] for i in range(n))-T*mean
    unordered=sum((p[i]*p[j]*(f[i]-f[j])*(k[i]-k[j]) for i,j in combinations(range(n),2)),F(0))
    GB=CA;EB=bilinear(p,E,B,lambda v,u:k[v]-k[u])
    EG=bilinear(p,E,G,lambda v,u:(1-A[u])*(k[v]-k[u]))
    GG=sum((p[i]*p[j]*(A[i]-A[j])*(k[i]-k[j]) for i,j in combinations(G,2)),F(0))
    half_ordered_GG=bilinear(p,G,G,lambda v,u:(A[v]-A[u])*(k[v]-k[u]))/2
    assert GG==half_ordered_GG and -Tdot==covariance==unordered==GB+EB+EG+GG
    # Independent exact layer cake, with each cut's signed covariance computed
    # only between its upper set and complement (one occurrence per pair).
    cuts=sorted({F(0),F(1),*f});layer_T=layer_flux=F(0)
    for lo,hi in zip(cuts,cuts[1:]):
        mid=(lo+hi)/2;upper=[i for i in range(n) if f[i]>mid];lower=[i for i in range(n) if f[i]<=mid]
        layer_T+=(hi-lo)*sum(p[i] for i in upper)
        layer_flux+=(hi-lo)*bilinear(p,upper,lower,lambda v,u:k[v]-k[u])
    assert layer_T==T and layer_flux==-Tdot
    return dict(p=p,mean_score=mean,pdot=pdot,F=massA,b=massB,R=R,Fdot=Fdot,bdot=bdot,Rdot=Rdot,C_A=CA,C_A_positive=CAplus,C_A_negative=CAminus,f=f,T=T,Tdot=Tdot,covariance=covariance,unordered_covariance=unordered,terms=dict(GB=GB,EB=EB,EG=EG,GG_unordered=GG,GG_half_ordered=half_ordered_GG),layer_cuts=cuts,layer_T=layer_T,layer_flux=layer_flux)


def gates(p,k,A,G,B,E,pdot,c,psi,h):
    q=bilinear(p,G,B,lambda v,u:psi[v][u]*(A[v]*h[v][u]*positive(k[v]-k[u])-positive(k[u]-k[v])))-bilinear(p,E,B,lambda v,u:positive(k[u]-k[v]))
    Gamma=bilinear(p,G,B,lambda v,u:-A[v]*(1-psi[v][u]*h[v][u])*positive(k[v]-k[u])+(A[v]-psi[v][u])*positive(k[u]-k[v]))
    alternative=bilinear(p,G,B,lambda v,u:-(1-psi[v][u])*A[v]*(k[v]-k[u])-psi[v][u]*A[v]*(1-h[v][u])*positive(k[v]-k[u])-psi[v][u]*(1-A[v])*positive(k[u]-k[v]))
    assert Gamma==alternative
    for v in G:
        for u in B:
            if psi[v][u]==1:
                assert -A[v]*(1-h[v][u])*positive(k[v]-k[u])+(A[v]-1)*positive(k[u]-k[v])<=0
    Ic=bilinear(p,E,G,lambda v,u:(c-A[u])*(k[v]-k[u]))+sum((p[v]*p[u]*(A[v]-A[u])*(k[v]-k[u]) for v,u in combinations(G,2)),F(0))
    n=len(p);fc=[A[i] if i in G else c if i in E else F(0) for i in range(n)]
    Tc=sum(p[i]*fc[i] for i in range(n));Tcdot=sum(pdot[i]*fc[i] for i in range(n))
    EBplus=bilinear(p,E,B,lambda v,u:positive(k[v]-k[u]));EBminus=bilinear(p,E,B,lambda v,u:positive(k[u]-k[v]))
    rhs=-Tcdot-Ic-c*EBplus-(1-c)*EBminus+Gamma
    assert q==rhs and 0<=Tc<=c<=1
    return dict(q=q,Tc=Tc,Tcdot=Tcdot,Ic=Ic,EB_positive=EBplus,EB_negative=EBminus,Gamma=Gamma,Gamma_alternative=alternative,identity_rhs=rhs)


def check_case(stage,label,raw,k,G,B,E,Avalues,deleted,index):
    n=len(raw);G=sorted(G);B=sorted(B);E=sorted(E);deleted=sorted(deleted)
    assert set(G)|set(B)|set(E)==set(range(n)) and not(set(G)&set(B) or set(G)&set(E) or set(B)&set(E))
    assert all(x>0 for x in raw) and all(isinstance(x,int) and x>=0 for x in k) and set(deleted)<=set(E)
    A=[F(0)]*n
    for i,value in zip(G,Avalues):A[i]=F(value)
    assert len(Avalues)==len(G) and all(0<=A[i]<=1 for i in G)
    total=sum(raw);p=[r/total for r in raw];before=continuous(p,k,A,G,B,E)
    surviving_total=sum(raw[i] for i in range(n) if i not in deleted)
    after_p=[F(0) if i in deleted else raw[i]/surviving_total for i in range(n)];after=continuous(after_p,k,A,G,B,E)
    d=sum(p[i] for i in deleted);assert 0<=d<1
    assert after['R']==before['R']
    delta_b=after['b']-before['b'];delta_product=after['F']*after['b']-before['F']*before['b']
    assert delta_product==(before['F']+after['F'])*delta_b and delta_product>=0
    delta_T=after['T']-before['T'];jump=-d*(1-before['T'])/(1-d)
    assert after['T']==(before['T']-d)/(1-d) and delta_T==jump<=0
    rng=random.Random(SEED+index);psi=[[0]*n for _ in range(n)];h=[[F(0)]*n for _ in range(n)]
    pairs=[(v,u) for v in G for u in B]
    for j,(v,u) in enumerate(pairs):
        psi[v][u]=j%2 if len(pairs)>1 else rng.randrange(2)
        h[v][u]=[F(0),F(1,2),F(1)][j%3]
    profiles=[('mixed',psi,h)]
    for bit in (0,1):
        for hv in (F(0),F(1,2),F(1)):
            profiles.append(('constant_psi_'+str(bit)+'_h_'+str(hv),[[bit]*n for _ in range(n)],[[hv]*n for _ in range(n)]))
    cmax=max(A[i] for i in G);c_checks=[]
    for name,c in [('max_A',cmax),('midpoint',(1+cmax)/2),('one',F(1))]:
        results=[]
        for pname,Psi,H in profiles:
            pre=gates(p,k,A,G,B,E,before['pdot'],c,Psi,H);post=gates(after_p,k,A,G,B,E,after['pdot'],c,Psi,H)
            delta=post['Tc']-pre['Tc'];exact=d*(pre['Tc']-c)/(1-d)
            assert delta==exact<=0 and post['Tc']==(pre['Tc']-c*d)/(1-d)
            results.append(dict(profile=pname,before=pre,after=post,delta_Tc=delta,deletion_formula=exact))
        c_checks.append(dict(label=name,c=c,gate_profiles=results))
    return dict(stage=stage,label=label,raw_positive_masses=raw,k=k,G=G,B=B,E=E,A=A,deleted_E=deleted,before=before,after=after,deletion=dict(d=d,R_unchanged=True,delta_b=delta_b,delta_Fb=delta_product,Fb_product_rule_rhs=(before['F']+after['F'])*delta_b,delta_T=delta_T,T_deletion_formula=jump),mixed_psi=psi,mixed_h=h,optimized_c_potentials=c_checks,status='PASS_FINITE_EXACT')


def pair_path_checks():
    log2_lower=2*sum((F(1,3)**(2*j+1)/F(2*j+1) for j in range(40)),F(0))
    table=[('initial','n1_same',[F(3,4)],[F(3,4)]),('initial','n1_opposite_endpoints',[F(1,2)],[F(1)]),('initial','n2_interleaved',[F(1,2),F(3,4)],[F(5,8),F(1)]),('stress','n4_crossing',[F(1,2),F(5,8),F(7,8),F(1)],[F(9,16),F(11,16),F(13,16),F(15,16)]),('stress','n4_repeated_same',[F(1,2),F(1,2),F(3,4),F(3,4)],[F(1,2),F(1,2),F(3,4),F(3,4)]),('stress','n8_separated',[F(1,2)]*8,[F(1)]*8),('expanded','n8_dense_interleaved',[F(8+i,16) for i in range(8)],[F(17+2*i,32) for i in range(8)]),('expanded','n16_tiny_vs_one',[F(1,2**100)]*16,[F(1)]*16),('expanded','n16_tiny_same',[F(1,2**100)]*16,[F(1,2**100)]*16)]
    rows=[]
    for stage,label,C,D in table:
        n=len(C);assert len(D)==n and all(0<x<=1 for x in C+D)
        lo=F(1,2);hi=F(1);cuts=sorted({lo,hi}|{x for x in C+D if lo<x<hi})
        def weight(array,tau):
            value=F(1)
            for x in array:value*=min(F(1),x/tau)
            return value
        def posterior(tau):
            v=weight(C,tau);u=weight(D,tau);return v/(v+u)
        energy=TV=F(0);pieces=[]
        for left,right in zip(cuts,cuts[1:]):
            mid=(left+right)/2;kv=sum(x<mid for x in C);ku=sum(x<mid for x in D);a=ku-kv
            bl=posterior(left);br=posterior(right);db=br-bl
            assert a*db>=0
            vl=weight(C,left);ul=weight(D,left);vr=weight(C,right);ur=weight(D,right)
            assert vr==vl*(left/right)**kv and ur==ul*(left/right)**ku
            vm=weight(C,mid);um=weight(D,mid);bm=vm/(vm+um)
            bdot=((-kv*vm)*(vm+um)-vm*(-kv*vm-ku*um))/(vm+um)**2
            assert bdot==bm*(1-bm)*a
            part=a*db;variation=abs(db);energy+=part;TV+=variation
            pieces.append(dict(left=left,right=right,kv=kv,ku=ku,a=a,b_left=bl,b_right=br,delta_b=db,energy=part,total_variation=variation,bdot_midpoint=bdot,exact_weight_power_law=True))
        k_start_v=sum(x<=lo for x in C);k_start_u=sum(x<=lo for x in D)
        k_end_v=sum(x<hi for x in C);k_end_u=sum(x<hi for x in D)
        assert pieces[0]['kv']==k_start_v and pieces[0]['ku']==k_start_u and pieces[-1]['kv']==k_end_v and pieces[-1]['ku']==k_end_u
        Npair=max(k_end_v,k_end_u)-min(k_start_v,k_start_u)
        assert 0<=Npair<=n
        jump_work=TVa=F(0)
        for left,right in zip(pieces,pieces[1:]):
            assert left['right']==right['left']
            da=right['a']-left['a'];TVa+=abs(da)
            jump_work+=(posterior(left['right'])-F(1,2))*da
        boundary=(posterior(hi)-F(1,2))*pieces[-1]['a']-(posterior(lo)-F(1,2))*pieces[0]['a']
        assert energy==boundary-jump_work
        old_bound=(abs(pieces[0]['a'])+abs(pieces[-1]['a'])+TVa)/2
        assert 0<=energy<=old_bound<=2*n and energy<=Npair
        # Rational lower bound for log(2), hence deliberately stronger finite
        # sufficient comparisons than the analytic log(2) inequalities.
        assert TV*TV<=Npair*log2_lower/4
        assert TV*TV<=energy*log2_lower/4
        assert TV*TV<=n*log2_lower/2
        rows.append(dict(stage=stage,label=label,n=n,C=C,D=D,cuts=cuts,pieces=pieces,start_k_right=dict(v=k_start_v,u=k_start_u),end_k_left=dict(v=k_end_v,u=k_end_u),Npair=Npair,energy=energy,TV_b=TV,TV_b_squared=TV*TV,TV_a=TVa,stieltjes_boundary=boundary,stieltjes_jump_work=jump_work,old_energy_upper=old_bound,strong_energy_upper=Npair,strong_TV_squared_sufficient_upper=Npair*log2_lower/4,energy_TV_squared_sufficient_upper=energy*log2_lower/4,weak_TV_squared_sufficient_upper=n*log2_lower/2,b_start=posterior(lo),b_end=posterior(hi),status='PASS_FINITE_EXACT'))
    return dict(cases=rows,log2_rational_lower=log2_lower,log2_lower_terms=40,status='PASS_FINITE_EXACT',scope='Actual one-dimensional threshold-product clock weights, fixed rational C/D and n coordinates, not a full physical source/history input. Endpoint weights are continuous; endpoint score jumps are not included as fake interior atoms. Original pair posterior factor (wv+wu)^2/e^2 is not paid by this relative-pair certificate.')


def conditional_cut_checks():
    table=[('initial','balanced_cut',[F(1,3)]*3,[1,0,2],[0],[2],[1],[F(1,2)],2,1),('stress','two_good_reverse_order',[F(1,8),F(1,8),F(1,4),F(1,2)],[2,0,0,4],[0,1],[3],[2],[F(1,4),F(3,4)],4,1),('expanded','same_row_Psi_zero',[F(1,3)]*3,[1,0,2],[0],[2],[1],[F(1,2)],2,0)]
    rows=[]
    for stage,label,p,k,G,B,E,values,dimension,bit in table:
        n=len(p);A=[F(0)]*n
        for v,value in zip(G,values):A[v]=value
        state=continuous(p,k,A,G,B,E);Psi=[[bit]*n for _ in range(n)];H=[[F(1)]*n for _ in range(n)]
        result=gates(p,k,A,G,B,E,state['pdot'],F(1),Psi,H)
        defect=F(0);layers=[]
        for v in G:
            for ell in range(1,dimension+1):
                low=sum(((1-A[v])*p[w] for w in E if k[w]<=k[v]-ell),F(0))+sum((positive(A[w]-A[v])*p[w] for w in G if k[w]<=k[v]-ell),F(0))
                excess=sum((positive(A[v]-Psi[v][u])*p[u] for u in B if k[u]>=k[v]+ell),F(0))
                available=sum((positive(Psi[v][u]-A[v])*p[u] for u in B if k[u]>=k[v]+ell),F(0))
                gap=low+excess-available;part=p[v]*positive(gap);defect+=part
                layers.append(dict(v=v,ell=ell,low=low,excess=excess,available=available,signed_gap=gap,weighted_defect=part,cut_holds=gap<=0))
        assert result['q']<=state['covariance']+defect
        if label=='balanced_cut':assert defect==0 and result['q']==state['covariance']==F(-1,3)
        if label=='two_good_reverse_order':assert defect==0 and result['q']==F(-7,8) and state['covariance']==F(-25,32)
        if label=='same_row_Psi_zero':assert defect==F(1,9) and result['q']-state['covariance']==defect
        rows.append(dict(stage=stage,label=label,p=p,k=k,G=G,B=B,E=E,A=A,c=F(1),Psi_bit=bit,h=F(1),dimension_score_bound=dimension,layers=layers,defect=defect,q=result['q'],covariance=state['covariance'],q_minus_covariance=result['q']-state['covariance'],conditional_upper=state['covariance']+defect,all_cut_conditions_hold=all(layer['cut_holds'] for layer in layers),status='PASS_FINITE_EXACT'))
    return dict(cases=rows,status='PASS_FINITE_EXACT',scope='Three conditional integer-score cut examples with exactly the same p and binary Psi at all layers. No each-layer source reselection, actual physical qualification or unconditional global budget is certified.')


def run():
    rows=[]
    hand=[('initial','three_singletons',[F(1)]*3,[2,0,1],[0],[1],[2],[F(1)],[2]),('initial','two_weighted_good',[F(1),F(2),F(1),F(2)],[0,3,1,2],[0,1],[2],[3],[F(1,4),F(3,4)],[3]),('initial','constant_scores',[F(1),F(2),F(3)],[2,2,2],[0],[1],[2],[F(1,2)],[2]),('stress','concurrent_E_zero_A',[F(i) for i in (1,2,3,4,5)],[4,0,2,5,1],[0,1],[2],[3,4],[F(0),F(1,2)],[3,4]),('stress','all_good_A_zero',[F(i) for i in (5,1,2,4,1)],[0,5,1,4,3],[0,1],[2,3],[4],[F(0),F(0)],[4]),('stress','interleaved_no_deletion',[F(i) for i in (1,3,2,1)],[1,4,0,7],[0],[1],[2,3],[F(1)],[])]
    for values in hand:rows.append(check_case(*values,index=len(rows)))
    manual=[dict(F=F(1,3),b=F(1,3),R=F(1),Rdot=F(-2),C_A=F(2,9),T=F(2,3),Tdot=F(-1,3),delta_Fb=F(5,36),delta_T=F(-1,6)),dict(F=F(7,24),b=F(1,6),R=F(7,4),Rdot=F(-11,4),C_A=F(11,144),T=F(5,8),Tdot=F(-13,48),delta_Fb=F(35,576),delta_T=F(-3,16)),dict(F=F(1,12),b=F(1,3),R=F(1,4),Rdot=F(0),C_A=F(0),T=F(7,12),Tdot=F(0),delta_Fb=F(1,12),delta_T=F(-5,12))]
    for row,expected in zip(rows[:3],manual):
        for key,value in expected.items():assert (row['deletion'] if key.startswith('delta_') else row['before'])[key]==value
        row['independent_hand_values']=expected
    rng=random.Random(SEED)
    for j in range(128):
        n=rng.randrange(4,9);order=list(range(n));rng.shuffle(order)
        ng=rng.randrange(1,n-1);nb=rng.randrange(1,n-ng)
        G=sorted(order[:ng]);B=sorted(order[ng:ng+nb]);E=sorted(order[ng+nb:])
        raw=[F(rng.randrange(1,10),rng.randrange(1,8)) for _ in range(n)];k=[rng.randrange(9) for _ in range(n)]
        A=[F(rng.randrange(5),4) for _ in G];deleted=[i for i in E if rng.randrange(2)]
        rows.append(check_case('expanded','seeded_'+str(j),raw,k,G,B,E,A,deleted,index=len(rows)))
    assert len(rows)==134
    signs=lambda values:dict(negative=sum(x<0 for x in values),zero=sum(x==0 for x in values),positive=sum(x>0 for x in values))
    gammas=[profile['before']['Gamma'] for row in rows for c in row['optimized_c_potentials'][:1] for profile in c['gate_profiles']]
    assert any(x>0 for x in gammas) and any(x<0 for x in gammas)
    summary=dict(cases=len(rows),stage_counts={stage:sum(r['stage']==stage for r in rows) for stage in ('initial','stress','expanded')},score_covariance_decomposition_states=2*len(rows),gate_identities=2*3*7*len(rows),optimized_c_deletion_checks=3*7*len(rows),signed_C_A=signs([r['before']['C_A'] for r in rows]),signed_EG=signs([r['before']['terms']['EG'] for r in rows]),signed_GG=signs([r['before']['terms']['GG_unordered'] for r in rows]),Gamma_before_profile_signs=signs(gammas),concurrent_deletions=sum(len(r['deleted_E'])>1 for r in rows),zero_deletions=sum(not r['deleted_E'] for r in rows))
    return dict(schema='r209_finite_potential_v1',seed=SEED,arithmetic='Python stdlib Fraction exact',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},cases=rows,summary=summary,pair_paths=pair_path_checks(),conditional_cuts=conditional_cut_checks(),status='PASS_FINITE_EXACT',scope=['Finite conditional posterior/partition/gate algebra only; no physical source geometry, actual original suffix-gate realization, forest or FULL certificate.','C_A, internal covariance and Gamma retain their signed values. A partial gate h is only an auxiliary factor; Psi is always binary.','All unordered pairs occur once; the ordered GG formula explicitly carries factor one half.','No free source column, terminal payoff, infinite-path variation payment or guessed dimension order is inferred.'])

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=HERE/'potential_checks.json');args=parser.parse_args()
    result=run();args.output.write_text(json.dumps(enc(result),indent=2,sort_keys=True)+'\n');print(json.dumps(result['summary'],sort_keys=True));print(result['status'])
