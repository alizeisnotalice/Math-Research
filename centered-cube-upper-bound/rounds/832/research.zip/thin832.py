"""Verify the sparse-coordinate box utility on actual R814 rows and high dimensions.

Replay: python3 -B thin832.py [--archive /absolute/path/to/rounds/814/research.zip]
The R814 ZIP is pinned and foot832.py is the only companion source. Selection,
geometry and row masses use exact fractions. Transcendental values are enclosed,
using rational Taylor bounds in 4D and outward Decimal endpoints in high dimension.
"""

import argparse
from collections import defaultdict
from functools import reduce
from itertools import product
from math import factorial, prod
from pathlib import Path

from foot832 import (
    ARCHIVE, F, LOG_CEIL, LOG_FLOOR, LOG_NEAREST, Decimal,
    decimal_interval, expm1, fixtures, hull, inside, log_intervals,
    verified_rows,
)


def expand_groups(stage):
    cubes, sides, bins, points, bounds, rows = verified_rows(stage)
    weights = defaultdict(lambda: defaultdict(F))
    left_masks = defaultdict(set)
    for (t, (_, z), group), weight in rows.items():
        weights[group][t] += weight
        left_masks[t, group].add(z)
    boxes = {}
    for (t, group), masks in sorted(left_masks.items()):
        # Match foot832's with-right menu: actual representatives of the
        # left source cells and every piece of the genuine right source cell.
        boxes[t, group] = reduce(hull, [bounds[group[1]], *(points[z] for z in sorted(masks))])
        assert inside(boxes[t, group], cubes[t])
    total = sum(rows.values())
    assert sum(sum(block.values()) for block in weights.values()) == total
    records = {}
    for group, block in sorted(weights.items()):
        denom = sum(block.values())
        probs = {t: v / denom for t, v in block.items()}
        assert sum(probs.values()) == 1
        for t, weight in sorted(block.items()):
            for s, prob in sorted(probs.items()):
                box = boxes[s, group]
                current = cubes[t]
                good = tuple(inside((axis,), (span,))
                             for axis, span in zip(box, current, strict=True))
                assert all(good) == inside(box, current)
                exponents = tuple((hi - lo) / (2 * sides[t]) for lo, hi in box)
                assert all(0 <= h <= F(1, 2) for h, allowed in zip(exponents, good)
                           if allowed)
                records[t, s, group] = weight * prob, good, exponents, bins[t] != bins[s]
    assert sum(row[0] for row in records.values()) == total
    return total, records


def utility(p, good, exponents):
    intervals = [expm1(h) for h, allowed in zip(exponents, good) if allowed]
    reject_bad = (1 - p) ** good.count(False)
    formula = tuple(reject_bad * (prod(1 + p * interval[k] for interval in intervals) - 1)
                    for k in range(2))

    enumeration = [F(0), F(0)]
    total_probability = F(0)
    positive_masks = 0
    all_axis_zero = None
    for mask in product((False, True), repeat=len(good)):
        probability = p ** mask.count(True) * (1 - p) ** mask.count(False)
        total_probability += probability
        blocked = any(selected and not allowed for selected, allowed in zip(mask, good))
        h = sum((v for v, selected in zip(exponents, mask) if selected), F(0))
        bounds = (F(0), F(0)) if blocked else expm1(h)
        positive_masks += bounds[0] > 0
        for k in range(2):
            enumeration[k] += probability * bounds[k]
        if all(mask):
            all_axis_zero = bounds == (0, 0)
    assert total_probability == 1
    lo, hi = max(formula[0], enumeration[0]), min(formula[1], enumeration[1])
    assert 0 <= lo <= hi and hi - lo < F(1, 10**46)
    assert (lo > 0) == (positive_masks > 0) == any(
        h > 0 for h, allowed in zip(exponents, good) if allowed
    )
    if not all(good):
        assert all_axis_zero
    return (lo, hi), positive_masks, all_axis_zero


def report_fixture(name, stage):
    total, records = expand_groups(stage)
    print("FIXTURE", name, "R mass exact", str(total), "(t,s,G) triples", len(records))
    for p in (F(1, 4), F(1, 2)):
        sums = {key: [F(0), F(0)] for key in ("all", "bad>0", "bad>0,cross_bin")}
        positive = blocked = blocked_positive = cross_positive = 0
        losses = defaultdict(int)
        for weight, good, exponents, cross_bin in records.values():
            bounds, positive_masks, full_zero = utility(p, good, exponents)
            bad = good.count(False)
            keys = ["all"]
            positive += bounds[0] > 0
            if bad:
                blocked += 1
                assert full_zero
                keys.append("bad>0")
                if bounds[0] > 0:
                    assert positive_masks > 0
                    blocked_positive += 1
                    losses[bad] += 1
                if cross_bin:
                    keys.append("bad>0,cross_bin")
                    cross_positive += bounds[0] > 0
            for key in keys:
                for k in range(2):
                    sums[key][k] += weight * bounds[k]
        assert 0 < sums["bad>0"][0] < sums["all"][0]
        assert all((hi - lo) / total < F(1, 10**46) for lo, hi in sums.values())
        print("P", str(p), "16 masks per triple", "positive triples", positive,
              "bad>0 triples", blocked, "positive bad>0 triples", blocked_positive,
              "positive bad>0 cross-bin", cross_positive, "positive counts by bad", dict(losses),
              "all-axis exact zero on every bad>0 triple")
        print("ORIGINAL-MASS WEIGHTED", {k: decimal_interval(v, 43) for k, v in sums.items()})
        print("MOTHER-NORMALIZED", {
            k: decimal_interval(tuple(x / total for x in v)) for k, v in sums.items()
        })


def unary_bounds(interval, operator):
    """Correct rounding plus one ulp, at monotonically rounded arguments."""
    endpoints = []
    for frac, context, step in zip(interval, (LOG_FLOOR, LOG_CEIL),
                                   (LOG_FLOOR.next_minus, LOG_CEIL.next_plus), strict=True):
        arg = context.divide(Decimal(frac.numerator), Decimal(frac.denominator))
        endpoints.append(F(step(operator(arg))))
    return tuple(endpoints)


def negative(interval):
    return -interval[1], -interval[0]


def enclosed_log(interval):
    return log_intervals(interval[0])[0], log_intervals(interval[1])[1]


def high_dimension(n):
    b = F(1)
    current = (F(-1, 2), F(1, 2))
    good_span = (F(-1, 100), F(44, 100))
    bad_span = (F(-1, 100), F(54, 100))
    assert inside((good_span,), (current,)) and not inside((bad_span,), (current,))
    assert all(lo < 0 < hi for lo, hi in (good_span, bad_span))
    assert good_span[1] - good_span[0] == F(9, 20)
    assert bad_span[1] - bad_span[0] == F(11, 20)
    bad = n // 20
    good = n - bad
    x_lo, x_hi = expm1((good_span[1] - good_span[0]) / (2 * b))
    assert 0 < x_lo <= x_hi < 1
    delta = good * x_lo - bad, good * x_hi - bad
    logn = log_intervals(F(n + 2))
    u = tuple(4 * bound for bound in unary_bounds(
        tuple(n * bound for bound in logn), LOG_NEAREST.sqrt
    ))
    p_lo, p_hi = (bound / (2 * n) for bound in u)
    assert 0 < p_lo <= p_hi <= F(1, 2)
    assert delta[0] >= u[1]
    theory = p_lo * delta[0] - n * p_hi ** 2, p_hi * delta[1] - n * p_lo ** 2
    threshold = tuple(4 * bound for bound in logn)
    assert theory[0] >= threshold[1] > 0

    # A = log(avoiding every bad axis), B = log(the good-axis product).
    a = tuple(bad * x for x in enclosed_log((1 - p_hi, 1 - p_lo)))
    z = tuple(good * x for x in enclosed_log((1 + p_lo * x_lo, 1 + p_hi * x_hi)))
    az = tuple(x + y for x, y in zip(a, z))
    assert az[0] > theory[1]
    # The formulas below use only nonpositive exponential arguments.
    tail_lo, tail_hi = unary_bounds(negative(z), LOG_NEAREST.exp)
    residual_lo, residual_hi = unary_bounds(negative(az), LOG_NEAREST.exp)
    assert 0 < tail_lo <= tail_hi < F(1, 2)
    loss = enclosed_log((1 - tail_hi, 1 - tail_lo))
    gain = enclosed_log((1 - tail_hi + residual_lo, 1 - tail_lo + residual_hi))
    actual_log = tuple(x + y for x, y in zip(az, loss))
    log1p = tuple(x + y for x, y in zip(az, gain))
    log2 = log_intervals(F(2))
    assert actual_log[0] > theory[1] - log2[0]
    assert log1p[0] > theory[1] > threshold[1]
    print("HIGH DIMENSION", n, "good", good, "bad", bad,
          "widths good/bad", "9/20", "11/20",
          "current axis [-1/2,1/2]", "q=0 interior of B", "whole-box gate exact zero")
    print("CERTIFIED INTERVALS", {key: decimal_interval(interval, 16) for key, interval in {
        "Delta": delta, "u": u, "p": (p_lo, p_hi), "p*Delta-n*p^2": theory,
        "u^2/(4n)=4log(n+2)": threshold, "log(U)": actual_log, "log(1+U)": log1p,
    }.items()})


def trim_checks():
    """Physical boxes with q=0, b_t=1 and every axis outside A_t."""
    beta = F(1, 4)
    # Integral of expm1 on [0,c] equals c*sum_{j>=1} beta^j/(j+1)!.
    # Every term after the first omitted term has ratio <= beta.
    partial = sum(beta**j / factorial(j + 1) for j in range(1, 33))
    tail = beta**33 / factorial(34) / (1 - beta)
    cases = {}
    for n in (16, 256, 4096, 16384):
        width = F(1, 2) + F(1, n)
        a, c = width / 2, F(1, 2) / width
        d = 1 - c
        assert width > F(1, 2) and a * c == beta
        assert 0 < n * d == F(2 * n, n + 2) < 2
        x = c * partial, c * (partial + tail)
        y = tuple(z - d for z in x)
        assert 0 < y[0] < y[1] < x[1] < 1
        delta = tuple(n * z for z in y)
        log_n = log_intervals(F(n + 2))
        u = tuple(4 * z for z in unary_bounds(tuple(n * z for z in log_n), LOG_NEAREST.sqrt))
        p = tuple(z / (2 * n) for z in u)
        energy = tuple(4 * z for z in log_n)
        passes = delta[0] > u[1]
        assert passes == (n == 16384)
        assert passes or delta[1] < u[0]
        row = {
            "B_axis": ["0", str(width)], "a": str(a), "c": str(c), "D": str(n * d),
            "x=integral_expm1": decimal_interval(x), "y=x-(1-c)": decimal_interval(y),
            "Delta": decimal_interval(delta), "u=4sqrt(n log(n+2))": decimal_interval(u),
            "p=u/(2n)": decimal_interval(p), "Delta_gt_u": passes,
            "energy=4log(n+2)": decimal_interval(energy),
        }
        if p[0] > F(1, 2):
            assert n == 16
            row["status"] = "excluded by p>1/2"
        else:
            assert 0 < p[0] <= p[1] <= F(1, 2)
            log_a = enclosed_log((1 + p[0] * y[0], 1 + p[1] * y[1]))
            log_b = enclosed_log((1 - p[1] * d, 1 - p[0] * d))
            A, B = (tuple(n * v for v in log) for log in (log_a, log_b))
            # log(1+U) = A + log(1 + exp(-A)*(1-exp(B))).
            assert A[0] > 0 and B[1] < 0
            exp_a = unary_bounds(negative(A), LOG_NEAREST.exp)
            exp_b = unary_bounds(B, LOG_NEAREST.exp)
            correction = enclosed_log((1 + exp_a[0] * (1 - exp_b[1]),
                                       1 + exp_a[1] * (1 - exp_b[0])))
            log_u = tuple(a + cor for a, cor in zip(A, correction))
            assert 0 < log_u[1] - log_u[0] < F(1, 10**45)
            assert 0 < A[1] < log_u[0] and B[1] < 0
            beats_energy = log_u[0] > energy[1]
            assert beats_energy == (n in (4096, 16384))
            assert beats_energy or log_u[1] < energy[0]
            linear_lower = p[0] * delta[0] - n * p[1]**2
            assert A[0] > linear_lower
            assert not passes or linear_lower > energy[1]
            row.update({"status": "eligible", "log1p(U)": decimal_interval(log_u),
                        "log1p(U)_gt_energy": beats_energy})
        cases[str(n)] = row
    return {"all_axis_whole_gate": 0, "geometry": "artificial physical boxes", "cases": cases}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, default=ARCHIVE)
    args = parser.parse_args()
    for name, stage in fixtures(args.archive):
        report_fixture(name, stage)
    for n in (4096, 16384, 65536):
        high_dimension(n)
    print("ALL-AXIS TRIM", trim_checks())
    print("PASS exact zero gates and rationally enclosed utility on all checks")


if __name__ == "__main__":
    main()
