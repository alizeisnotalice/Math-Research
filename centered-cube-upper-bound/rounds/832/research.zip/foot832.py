"""Replay the fixed-real-right-arm box mixture on both 4D R814 fixtures.

Usage: python3 -B foot832.py [--archive PATH]

The only external input is the SHA256-pinned R814 ZIP. Geometry, probabilities,
and original masses are exact rational numbers. A positive Taylor series with a
geometric tail certifies exp(x)-1 for theta=1/2. The displayed decimal endpoints
are rounded outward.
"""

import argparse
from collections import defaultdict
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from itertools import combinations, product
from json import loads
from math import prod
from pathlib import Path
from platform import python_version
from zipfile import ZipFile


ARCHIVE = Path(
    "/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/"
    "centered-cube-upper-bound/rounds/814/research.zip"
)
PIN = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"


def fixtures(path):
    assert sha256(path.read_bytes()).hexdigest() == PIN
    print("ARCHIVE SHA256", PIN, "Python", python_version(), "theta", "1/2")
    with ZipFile(path) as archive:
        code = archive.read("comb811.py")
        rebuilt = archive.read("comb814-rebuilt.json")
    for name, data in (("comb811.py", code), ("comb814-rebuilt.json", rebuilt)):
        print("MEMBER SHA256", name, sha256(data).hexdigest())
    original = {"__name__": "archived_comb811"}
    exec(compile(code, "comb811.py", "exec"), original)
    return (
        ("original", original["fixture"](*original["FIXTURES"][-1])),
        ("rebuilt", loads(rebuilt)["stages"][0]),
    )


def as_box(box):
    return tuple((F(lo), F(hi)) for lo, hi in box)


def volume(box):
    return prod(max(F(0), hi - lo) for lo, hi in box)


def intersect(a, b):
    return tuple((max(lo, x), min(hi, y))
                 for (lo, hi), (x, y) in zip(a, b, strict=True))


def hull(a, b):
    return tuple((min(lo, x), max(hi, y))
                 for (lo, hi), (x, y) in zip(a, b, strict=True))


def inside(a, b):
    return all(lo <= x <= y <= hi
               for (x, y), (lo, hi) in zip(a, b, strict=True))


def point_box(point):
    return tuple((x, x) for x in point)


def true_face_cells(cubes, support):
    """Each true mask gets a first open face box and a hull of all its pieces."""
    all_bits = (1 << len(cubes)) - 1
    states = {all_bits: ((), ())}
    for axis in range(len(cubes[0])):
        cuts = sorted({*support, *(v for box in cubes for v in box[axis])})
        cuts = [v for v in cuts if support[0] <= v <= support[1]]
        updated = {}
        for lo, hi in zip(cuts, cuts[1:]):
            midpoint = (lo + hi) / 2
            bit = sum(1 << i for i, box in enumerate(cubes)
                      if box[axis][0] < midpoint < box[axis][1])
            for mask, (piece, bound) in states.items():
                new_mask = mask & bit
                new_piece, new_bound = piece + ((lo, hi),), bound + ((lo, hi),)
                if new_mask in updated:
                    old_piece, old_bound = updated[new_mask]
                    updated[new_mask] = old_piece, hull(old_bound, new_bound)
                else:
                    updated[new_mask] = new_piece, new_bound
        states = updated
    return states


def verified_rows(stage):
    assert stage["dimension"] == 4
    parents = {p["id"]: p for p in stage["parents"]}
    assert list(parents) == stage["parent_order"]
    assert all(p["bit"] == 1 << i for i, p in enumerate(parents.values()))
    cubes = {k: as_box(p["box"]) for k, p in parents.items()}
    owners = {k: as_box(p["owner"]) for k, p in parents.items()}
    support = tuple(map(F, stage["density"]["support"]))
    cells = true_face_cells(tuple(cubes.values()), support)
    mu = {c["mask"]: F(c["mass"]) for c in stage["cells"] if F(c["mass"]) > 0}
    assert F(stage["density"]["density_floor_one_axis"]) > 0
    assert cells.keys() == mu.keys()
    points = {}
    bounds = {}
    for mask, (piece, bound) in cells.items():
        assert volume(piece) > 0 and inside(piece, bound)
        p = tuple(a + (b - a) / 3 for a, b in piece)
        assert sum(parents[k]["bit"] for k, cube in cubes.items()
                   if inside(point_box(p), cube)) == mask
        assert all(not volume(intersect(piece, cube)) for k, cube in cubes.items()
                   if not mask & parents[k]["bit"])
        assert all(inside(bound, cube) for k, cube in cubes.items()
                   if mask & parents[k]["bit"])
        points[mask] = point_box(p)
        bounds[mask] = bound

    mids = tuple(stage["middle_labels"])
    bins = {k: F(p["volume_bin"]) for k, p in parents.items()}
    sides = {k: 2 * F(p["radius"]) for k, p in parents.items()}
    j = {k: F(p["j"]) for k, p in parents.items()}
    m = {k: F(p["m"]) for k, p in parents.items()}
    assert all(not volume(intersect(a, b)) for a, b in combinations(owners.values(), 2))
    for k, p in parents.items():
        assert all(hi - lo == sides[k] for lo, hi in cubes[k])
        assert 0 < j[k] <= volume(owners[k]) == F(p["owner_volume"])
        assert m[k] == sum(v for mask, v in mu.items() if mask & p["bit"])
    d = {}
    permitted = {}
    for t in mids:
        terms = {}
        for u, p in parents.items():
            bit = parents[t]["bit"] | p["bit"]
            joint = sum(v for mask, v in mu.items() if mask & bit == bit)
            assert joint == F(stage["degrees"][t]["true_mu_intersections"][u])
            terms[u] = j[u] * joint / (m[t] * m[u]) if t != u else F(0)
        assert terms == {u: F(v) for u, v in stage["degrees"][t]["full_terms"].items()}
        assert 0 < sum(terms.values()) == F(stage["degrees"][t]["full_d"]) == F(parents[t]["full_d"])
        d[t] = sum(terms.values())
        old = {u: term for u, term in terms.items()
               if term > 0 and parents[u]["role"] == "old" and sides[u] < sides[t]}
        assert old == {u: F(v) for u, v in stage["degrees"][t]["old_terms"].items()}
        assert 0 < sum(old.values()) == F(parents[t]["old_d"]) <= d[t]
        permitted[t] = {(u, z) for u in old for z in cells
                        if z & parents[t]["bit"] and z & parents[u]["bit"]}

    # The j's stand in the kernel coefficient; each endpoint owner carries
    # its actual normalized Lebesgue law on the archived disjoint owner box.
    # In particular there is no reweighting by representative face-box mass.
    rows = {}
    for root in stage["roots_cross"]:
        t, u, g = (root[k] for k in ("t", "u", "g"))
        coef = j[t] * j[u] * j[g] / (d[t] * m[t]**2 * m[u] * m[g])
        assert coef == F(root["coefficient"]) > 0
        root_mass = F(0)
        for z, q in product(root["z_masks"], root["q_masks"]):
            row = t, (u, z), (g, q)
            assert row not in rows
            weight = coef * mu[z] * mu[q]
            rows[row] = weight
            root_mass += weight
        assert root_mass == F(root["root_mass"])
    assert set(rows) == {
        (t, x, y) for t in mids for x, y in product(permitted[t], repeat=2)
        if bins[x[0]] != bins[y[0]]
    }
    assert len(rows) == 230 and len(stage["roots_cross"]) == 34
    assert min(rows.values()) > 0
    assert sum(rows.values()) == F(stage["benchmarks"]["cross"]["mother"])
    return cubes, sides, bins, points, bounds, rows


@cache
def expm1(x):
    """Both bounds are exact fractions; terms after degree 48 have ratio <= x/50."""
    assert 0 <= x <= 2
    term, lower = F(1), F(0)
    for k in range(1, 49):
        term = term * x / k
        lower += term
    return lower, lower + (term * x / 49) / (1 - x / 50)


def decimal_interval(interval, digits=22):
    scale = 10**digits
    lo, hi = interval
    lo = lo.numerator * scale // lo.denominator
    hi = -((-hi.numerator * scale) // hi.denominator)
    return "[" + ", ".join(f"{k // scale}.{k % scale:0{digits}d}" for k in (lo, hi)) + "]"


LOG_FLOOR = Context(prec=65, rounding=ROUND_FLOOR)
LOG_CEIL = Context(prec=65, rounding=ROUND_CEILING)
LOG_NEAREST = Context(prec=65, rounding=ROUND_HALF_EVEN)


@cache
def log_intervals(x):
    """Enlarge the correctly rounded Decimal.ln at both directed arguments."""
    assert x > 0
    if x == 1:
        return F(0), F(0)
    a, b = Decimal(x.numerator), Decimal(x.denominator)
    lower = LOG_NEAREST.ln(LOG_FLOOR.divide(a, b))
    upper = LOG_NEAREST.ln(LOG_CEIL.divide(a, b))
    return F(LOG_FLOOR.next_minus(lower)), F(LOG_CEIL.next_plus(upper))


def log_score(terms):
    totals = [F(0), F(0)]
    for weight, ratio in terms:
        assert weight > 0
        for i, v in enumerate(log_intervals(ratio)):
            totals[i] += weight * v
    return tuple(totals)


def mutual_information(table):
    """Conditional-Shannon information, weighted by unnormalized original mass."""
    middle_mass, endpoint_mass, y_mass = defaultdict(F), defaultdict(F), defaultdict(F)
    for (t, x, y), mass in table.items():
        middle_mass[t, y] += mass
        endpoint_mass[x, y] += mass
        y_mass[y] += mass
    return log_score(
        (mass, mass * y_mass[y] / (middle_mass[t, y] * endpoint_mass[x, y]))
        for (t, x, y), mass in table.items()
    )


def report_information(rows, weights, rm):
    # For a given Y=(g,q,W), the fixture density on each C_z matters only
    # through the common normalized restriction of mu; U similarly carries
    # its unchanged owner law given u. The continuous conditional
    # likelihood ratios for z and (u,z,U) thus equal these cell ratios.
    source = defaultdict(F)
    for (t, (_, z), y), mass in rows.items():
        source[t, z, y] += mass
    source_info = mutual_information(source)
    arm_info = mutual_information(rows)
    m_entropy = log_score((weight, sum(block.values()) / weight)
                          for block in weights.values() for weight in block.values())
    assert 0 < source_info[0] <= source_info[1] < arm_info[0] <= arm_info[1] < m_entropy[0]
    information = {"I(t;z cell|Y)": source_info,
                   "I(t;u,z cell|Y)": arm_info, "H(t|Y)": m_entropy}
    assert all((hi - lo) / rm < F(1, 10**60) for lo, hi in information.values())
    print("INFORMATION NATS", {k: decimal_interval(tuple(v / rm for v in interval))
                                for k, interval in information.items()})


def report_box_information(weights, boxes, rm):
    table = {(t, boxes[t, y], y): weight
             for y, block in weights.items() for t, weight in block.items()}
    info = mutual_information(table)
    box_mass = defaultdict(F)
    for (t, box, y), weight in table.items():
        box_mass[box, y] += weight
    entropy = log_score((weight, sum(weights[y].values()) / weight)
                        for (box, y), weight in box_mass.items())
    assert info == entropy  # Deterministic B_t given (t,Y); repeated boxes merge.
    assert 0 < info[0] <= info[1] and (info[1] - info[0]) / rm < F(1, 10**60)
    print("BOX INFORMATION NATS", "I(t;B_t(Y)|Y)", decimal_interval(tuple(v / rm for v in info)),
          "(B,Y) classes", len(box_mass), "from", len(table), "(t,Y) entries")


def report(name, stage):
    cubes, sides, bins, points, bounds, rows = verified_rows(stage)
    rm = sum(rows.values())
    weights = defaultdict(lambda: defaultdict(F))
    left_masks = defaultdict(set)
    for (t, (_, z), y), weight in rows.items():
        weights[y][t] += weight
        left_masks[t, y].add(z)
    assert sum(sum(item.values()) for item in weights.values()) == rm
    print("FIXTURE", name, "rows", len(rows), "Y cells", len(weights),
          "positive (t,Y) cells", len(left_masks), "raw mass", str(rm),
          "actual sides", {t: str(sides[t]) for t in stage["middle_labels"]},
          "volume bins", {t: str(bins[t]) for t in stage["middle_labels"]})
    report_information(rows, weights, rm)
    for with_right in (False, True):
        boxes = {}
        for (t, y), masks in sorted(left_masks.items()):
            reps = [points[z] for z in sorted(masks)]
            if with_right:
                reps.append(bounds[y[1]])
            box = reps[0]
            for point in reps[1:]:
                box = hull(box, point)
            assert inside(box, cubes[t])
            boxes[t, y] = box
        widths = {k: sum(hi - lo for lo, hi in b) for k, b in boxes.items()}
        sums = {k: [F(0), F(0)] for k in ("self", "other_same_bin", "other_cross_bin")}
        hits = dict.fromkeys(sums, 0)
        sample = None
        geometric_cross = 0
        for y, block in sorted(weights.items()):
            denominator = sum(block.values())
            pi = {t: v / denominator for t, v in block.items()}
            assert sum(pi.values()) == 1 and min(pi.values()) > 0
            for t, weight in sorted(block.items()):
                for s in sorted(block):
                    if not inside(boxes[s, y], cubes[t]):
                        continue
                    k = ("self" if s == t else "other_same_bin" if bins[s] == bins[t]
                         else "other_cross_bin")
                    if k == "other_cross_bin":
                        geometric_cross += 1
                    if widths[s, y] == 0:
                        continue
                    hits[k] += 1
                    interval = expm1(widths[s, y] / (2 * sides[t]))
                    contribution = tuple(pi[s] * value for value in interval)
                    for i, bound in enumerate(contribution):
                        sums[k][i] += weight * bound
                    if k == "other_cross_bin":
                        candidate = (weight * contribution[0], t, s, y)
                        if sample is None or candidate > sample[0]:
                            sample = (candidate, pi[s], weight, widths[s, y], contribution)
        assert geometric_cross > 0 and sample is not None and hits["other_cross_bin"] > 0
        label = "left-hull-with-complete-q-cell" if with_right else "left-hull-only"
        joint = tuple(sum(v[i] for v in sums.values()) for i in range(2))
        totals = {**sums, "joint": joint}
        assert all(hi >= lo >= 0 and (hi - lo) / rm < F(1, 10**48)
                   for lo, hi in totals.values())
        assert joint[0] > sums["self"][1]
        print("MENU", label, "certified B_t subset A_t", len(boxes),
              "geometric cross-bin hits", geometric_cross, "positive hits", hits)
        report_box_information(weights, boxes, rm)
        print("WEIGHTED SUM", {k: decimal_interval(v, 40) for k, v in totals.items()})
        print("WEIGHTED AVERAGE", {k: decimal_interval(tuple(x / rm for x in v))
                                   for k, v in totals.items()})
        (_, t, s, y), prob, weight, width, contribution = sample
        print("CROSS EXAMPLE", "Y", y, "t", t, "s", s, "pi_s", str(prob),
              "L_s", str(width), "b_t", str(sides[t]), "b_s", str(sides[s]),
              "B_s", tuple((str(a), str(b)) for a, b in boxes[s, y]),
              "A_t", tuple((str(a), str(b)) for a, b in cubes[t]),
              "addend", decimal_interval(contribution),
              "raw mass times addend", decimal_interval(tuple(weight * v for v in contribution), 40))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, default=ARCHIVE)
    args = parser.parse_args()
    for name, stage in fixtures(args.archive):
        report(name, stage)
    print("PASS both positive original R814 fixture replays")


if __name__ == "__main__":
    main()

