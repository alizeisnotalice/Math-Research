"""R832: fixed-left Gaussian prices, actual roots, and archived R814 rows.

Run with Python 3 -B and no third-party dependencies. Fractions certify the
support, root gaps, and probability inequalities. Decimal prices are displays
of exact expressions. The hard-root examples test geometry and the raw root
law. They do not impose the full R813 prefix/high-degree/long-jump filters.
"""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, product
from json import loads
from math import ceil, isqrt, prod, sqrt
from pathlib import Path
from zipfile import ZipFile


ARCHIVE = Path(
    "/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/"
    "centered-cube-upper-bound/rounds/814/research.zip"
)
SHA = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
DIMENSIONS = (4, 16, 64, 256, 1024)


def sqdist(left, right):
    """Squared distance for the common direct sum of interval indicators."""
    return sum(abs(a - b) for a, b in zip(left, right, strict=True))


def distance_inf(left, right):
    return max(abs(a - b) for a, b in zip(left, right, strict=True))


def prices(label, sites):
    """w(S)=sqrt(2 pi) E max_{p in S} G_p, with isonormal G."""
    d2 = tuple(sqdist(a, b) for a, b in combinations(sites, 2))
    d_inf = tuple(distance_inf(a, b) for a, b in combinations(sites, 2))
    assert len(sites) in (2, 3) and min(d_inf) > 0
    assert all(a >= b for a, b in zip(d2, d_inf, strict=True))
    # E max G = E range / 2 by sign symmetry. The real range for
    # three scalars is half the sum of the three absolute differences.
    divisor = 1 if len(sites) == 2 else 2
    print(label, "d2=" + ",".join(map(str, d2)), "linf=" + ",".join(map(str, d_inf)),
          "exact price=(" + "+".join(f"sqrt({d})" for d in d2) + f")/{divisor}",
          f"approx={sum(map(sqrt, d2))/divisor:.12g}")


def small_geometry():
    # These finite geometry probes use the same one-axis indicator embedding
    # t -> 1_[0,t]. They do not represent an original history.
    prices("PSEUDO two", ((F(0),), (F(3, 4),)))
    prices("PSEUDO three", ((F(0),), (F(1, 4),), (F(1),)))


def root_geometry():
    corner = F(3, 8)
    source_half = F(1, 64)
    recipient_half = F(1, 32)
    own_distance = source_half + recipient_half
    other_distance = 2 * corner - own_distance
    center_distance = corner + own_distance
    rho = 2 * corner - 2 * source_half
    assert (own_distance, other_distance, center_distance, rho) == (
        F(3, 64), F(45, 64), F(27, 64), F(23, 32))
    assert 2 * own_distance < F(1, 2)
    assert 2 * other_distance > 1
    assert 2 * center_distance < 1
    assert 2 * recipient_half < corner

    eps = F(1, 64)
    tube_lo, tube_hi = -F(1, 4), F(1, 4)
    tube_length = tube_hi - tube_lo
    tube_rho = F(1, 8)
    axis_gap = tube_rho - 2 * eps
    assert tube_rho > 4 * eps and 2 * axis_gap >= tube_rho
    tube_pack_upper = tube_length // axis_gap + 1
    assert tube_pack_upper == 6
    tube_witness = tuple(tube_lo + i * tube_rho for i in range(5))
    assert tube_witness[-1] == tube_hi
    assert (max(abs(tube_lo), abs(tube_hi)) + eps + recipient_half) * 2 == F(19, 32)
    print("HARD ROOTS central s=1, all boxes for s>27/32; corner s=1/2, own box"
          " for 3/32<s<=1; any other box requires s>=45/32 on A_sigma")
    print("TUBE t in [-1/4,1/4], eps=1/64, rho=1/8, pack 5<=M<=6;"
          " central s=1, entire tube for s>19/32;"
          " w<=2sqrt(2*length)=2 from Brownian reflection")
    for n in DIMENSIONS:
        # Uniform f on the corner boxes has total lambda, mass lambda*2^-n
        # in each box. At center root the actual q law is mu/lambda.
        boxes = 2**n
        right_boxes = boxes - 1
        mu_box = F(1, boxes)
        mu_right = right_boxes * mu_box
        assert boxes * mu_box == 1 and mu_box == F(1, 2)**n
        assert mu_right == 1 - mu_box
        recipient_volume = (2 * recipient_half)**n
        source_volume = boxes * (2 * source_half)**n
        assert recipient_volume == source_volume == F(1, 16)**n
        tube_volume = tube_length * (2 * eps)**(n - 1)
        assert tube_volume == F(1, 2) * F(1, 32)**(n - 1) > 0

        # Sudakov-Fernique with iid variables sqrt(rho/2)*Z_j gives
        # w >= sqrt(pi*rho) E max Z_j. The same bound is attained by a
        # rho-equilateral Hilbert placement of the chosen box labels.
        # P(Z>=a) >= (1/3)*exp(-(a+1)^2/2) >= p0, since sqrt(2*pi)<3 and
        # log(2)>2/3. Bonferroni for the two extreme signs gives
        # P(range>=2a) >= 1-2(1-p0)^M >= 1-2/(1+M*p0).
        a = F(isqrt(n), 4)
        # For all n >= 4 and a = sqrt(n)/4, ceil(3*(a+1)^2/4)
        # is at most n-2. Thus (2^n-1)*p0 >= 5/4 uniformly.
        assert ceil(F(27 * n, 64)) <= n - 2
        assert a + 1 <= F(3 * isqrt(n), 4)
        p0 = F(1, 3 * 2**ceil(F(3, 4) * (a + 1)**2))
        range_prob = 1 - F(2, 1 + right_boxes * p0)
        assert range_prob >= F(1, 9)
        # pi*rho>1, so w >= a*range_prob >= sqrt(n)/36 here.
        assert 3 * rho > 1 and a * range_prob >= F(isqrt(n), 36)
        # Orthogonal box-label placement gives d^2=rho between boxes
        # and w<=sqrt(2*pi*rho*log M)<2sqrt(n). This Gaussian mgf upper
        # bound is for the equilateral comparison, not every map.
        assert 2 * F(22, 7) * rho * F(7, 10) < 4
        print(f"n={n} M=2^{n}-1, right conditional mass=1-2^-{n}, "
              f"corner/central receiver each=2^-{4*n}, "
              f"tube volume=2^-{5*n-4}, "
              f"normalized corner width >= {F(isqrt(n),36)}, "
              f"equilateral width < {2*isqrt(n)}")


def qbox(box):
    return tuple(tuple(map(F, interval)) for interval in box)


def representative_points(boxes, support, position=F(1, 2)):
    """Give one strictly interior rational point in every nonempty face mask."""
    masks = {(1 << len(boxes)) - 1: ()}
    for axis in range(len(boxes[0])):
        cuts = sorted({*support, *(x for box in boxes for x in box[axis])})
        axis_masks = {}
        for lo, hi in zip(cuts, cuts[1:]):
            mid = lo + position * (hi - lo)
            key = sum(1 << j for j, box in enumerate(boxes)
                      if box[axis][0] < mid < box[axis][1])
            axis_masks.setdefault(key, mid)
        new = {}
        for (left, coords), (right, mid) in product(masks.items(), axis_masks.items()):
            new.setdefault(left & right, coords + (mid,))
        masks = new
    return masks


def box_intersection_volume(a, b):
    return prod(max(F(0), min(hi, top) - max(lo, bot))
                for (lo, hi), (bot, top) in zip(a, b, strict=True))


def archive_geometry(archive_path):
    assert sha256(archive_path.read_bytes()).hexdigest() == SHA
    with ZipFile(archive_path) as archive:
        stage = loads(archive.read("comb814-rebuilt.json"))["stages"][0]
    ordered = stage["parents"]
    parents = {p["id"]: p for p in ordered}
    assert list(parents) == stage["parent_order"]
    for index, p in enumerate(ordered):
        assert p["bit"] == 1 << index
    cubes = {p["id"]: qbox(p["box"]) for p in ordered}
    owner = {p["id"]: qbox(p["owner"]) for p in ordered}
    mu = {c["mask"]: F(c["mass"]) for c in stage["cells"] if F(c["mass"]) > 0}
    support = tuple(map(F, stage["density"]["support"]))
    reps = representative_points(tuple(cubes.values()), support)
    left_reps = representative_points(tuple(cubes.values()), support, F(1, 3))
    assert set(reps) == set(left_reps)
    assert F(stage["density"]["density_floor_one_axis"]) > 0
    assert set(mu) == set(reps)
    for mask, point in (*reps.items(), *left_reps.items()):
        assert all(support[0] < a < support[1] for a in point)
        realized = sum(p["bit"] for p in ordered if all(
            lo < x < hi for x, (lo, hi) in zip(point, cubes[p["id"]], strict=True)))
        assert realized == mask

    for i, p in parents.items():
        assert F(p["m"]) == sum(m for mask, m in mu.items() if mask & p["bit"])
        assert 0 < F(p["j"]) <= F(p["owner_volume"]) == box_intersection_volume(owner[i], owner[i])
    assert all(not box_intersection_volume(a, b) for a, b in combinations(owner.values(), 2))

    degrees = {}
    for t in stage["middle_labels"]:
        middle = parents[t]
        raw_full = {}
        raw_old = {}
        for u, p in parents.items():
            mask = middle["bit"] | p["bit"]
            joint = sum(m for k, m in mu.items() if k & mask == mask)
            assert joint == F(stage["degrees"][t]["true_mu_intersections"][u])
            term = F(0) if u == t else F(p["j"]) * joint / (F(middle["m"]) * F(p["m"]))
            raw_full[u] = term
            if p["role"] == "old" and F(p["radius"]) < F(middle["radius"]) and term:
                raw_old[u] = term
        recorded = stage["degrees"][t]
        assert raw_full == {u: F(value) for u, value in recorded["full_terms"].items()}
        assert raw_old == {u: F(value) for u, value in recorded["old_terms"].items()}
        assert 0 < sum(raw_old.values()) == F(recorded["old_d"]) < F(recorded["full_d"])
        degrees[t] = sum(raw_full.values())
        assert degrees[t] == F(recorded["full_d"]) == F(middle["full_d"])

    groups = defaultdict(lambda: defaultdict(F))
    law_rows = defaultdict(lambda: defaultdict(list))
    mass = F(0)
    nrows = 0
    for root in stage["roots_cross"]:
        t, u, g = (root[k] for k in ("t", "u", "g"))
        middle, left, right = parents[t], parents[u], parents[g]
        assert left["volume_bin"] != right["volume_bin"]
        assert {u, g} <= set(stage["degrees"][t]["old_terms"])
        m_t, m_u, m_g = (F(p["m"]) for p in (middle, left, right))
        j_t, j_u, j_g = (F(p["j"]) for p in (middle, left, right))
        d_t = degrees[t]
        coeff = j_t * j_u * j_g / (d_t * m_t**2 * m_u * m_g)
        assert F(root["coefficient"]) == coeff > 0
        tbit, ubit, gbit = (p["bit"] for p in (middle, left, right))
        assert set(root["z_masks"]) == {k for k in mu if k & (tbit | ubit) == tbit | ubit}
        assert set(root["q_masks"]) == {k for k in mu if k & (tbit | gbit) == tbit | gbit}
        root_mass = F(0)
        for zmask, qmask in product(root["z_masks"], root["q_masks"]):
            row_mass = coeff * mu[zmask] * mu[qmask]
            # Each full row has independent normalized Lebesgue receiver laws
            # on the two original owner boxes. After conditioning on the
            # actual z and U of the left arm, the relative qmask rate is
            # coeff*mu[qmask], with the original right owner law unchanged.
            key = u, zmask, middle["volume_bin"]
            groups[key][qmask] += row_mass / mu[zmask]
            law_rows[key][qmask].append((t, g, row_mass))
            root_mass += row_mass
            nrows += 1
        assert root_mass == F(root["root_mass"])
        mass += root_mass
    assert nrows == 230 and mass == F(stage["benchmarks"]["cross"]["mother"])

    def gap(masks):
        return min(distance_inf(reps[a], reps[b]) for a, b in combinations(masks, 2))

    best = max((gap(selected), key, selected)
               for key, group in groups.items() for selected in combinations(sorted(group), 3))
    rho, key, selected = best
    u, zmask, tbin = key
    assert rho > 0 and all(weight > 0 for weight in groups[key].values())
    z = left_reps[zmask]
    assert all(z != reps[mask] for mask in selected)
    left_receiver = tuple((a + b) / 2 for a, b in owner[u])
    print("ARCHIVE", SHA, "rows", nrows)
    print("FIXED LEFT", u, "z", tuple(map(str, z)), "U", tuple(map(str, left_receiver)),
          "middle bin", tbin, "right cells", len(groups[key]))
    total = sum(groups[key].values())
    for qmask in selected:
        law = law_rows[key][qmask]
        share = groups[key][qmask] / total
        assert share > 0 and all(row[2] > 0 for row in law)
        print("q", qmask, tuple(map(str, reps[qmask])), "zq linf", distance_inf(z, reps[qmask]),
              "conditional qcell share approx", f"{float(share):.12g}",
              "true row labels", [(t, g) for t, g, _ in law])
    pair = max(combinations(selected, 2), key=gap)
    prices("ARCHIVE two", tuple(reps[mask] for mask in pair))
    prices("ARCHIVE three", tuple(reps[mask] for mask in selected))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, default=ARCHIVE, help="Original R814 research.zip")
    args = parser.parse_args()
    small_geometry()
    root_geometry()
    archive_geometry(args.archive)

