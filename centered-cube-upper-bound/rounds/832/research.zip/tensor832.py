"""Round 832: exact two-site price and reuse on actual R814 positive rows.

Run with Python 3:
  PYTHONDONTWRITEBYTECODE=1 python3 tensor832.py [--archive PATH] [--exact]
Only the original cross-bin R rows are used. The capped alternatives keep the
same fixed archive and receiver laws, and restrict each original row by a
factor in (0,1]. They are subflows of that history.
"""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from math import log2
from pathlib import Path
from zipfile import ZipFile


PIN = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
ARCHIVE = Path(
    "/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/"
    "centered-cube-upper-bound/rounds/814/research.zip"
)


def load(path):
    archive_bytes = path.read_bytes()
    assert sha256(archive_bytes).hexdigest() == PIN
    print("ARCHIVE SHA256", PIN)
    with ZipFile(path) as archive:
        for member in ("comb811.py", "comb814-rebuilt.json"):
            print("MEMBER SHA256", member, sha256(archive.read(member)).hexdigest())
        archived = {"__name__": "archived_comb811"}
        exec(compile(archive.read("comb811.py"), "comb811.py", "exec"), archived)
        stages = json.loads(archive.read("comb814-rebuilt.json"))["stages"]
        return (
            ("original", archived["fixture"](*archived["FIXTURES"][-1])),
            ("rebuilt", stages[0]),
        )


def rebuild(stage):
    assert stage["dimension"] == 4
    parents = {p["id"]: p for p in stage["parents"]}
    bins = {i: F(p["volume_bin"]) for i, p in parents.items()}
    mu = {cell["mask"]: F(cell["mass"]) for cell in stage["cells"] if F(cell["mass"]) > 0}
    middle = tuple(stage["middle_labels"])
    mass = {i: F(p["m"]) for i, p in parents.items()}
    j = {i: F(p["j"]) for i, p in parents.items()}
    for i, p in parents.items():
        assert 0 < j[i] <= F(p["owner_volume"])
        assert sum(weight for z, weight in mu.items() if z & p["bit"]) == mass[i]
    permitted = {}
    for t in middle:
        permitted[t] = {
            (i, z) for i in stage["degrees"][t]["old_terms"]
            for z in mu if z & parents[i]["bit"] and z & parents[t]["bit"]
        }
        assert sum(j[i] * mu[z] / mass[i] for i, z in permitted[t]) == (
            F(parents[t]["old_d"]) * mass[t]
        )

    rows = {}
    roots = stage["roots_cross"]
    for root in roots:
        t, u, g = (root[k] for k in ("t", "u", "g"))
        assert bins[u] != bins[g]
        d_t = F(stage["degrees"][t]["full_d"])
        assert d_t == F(parents[t]["full_d"]) > 0
        coef = j[t] * j[u] * j[g] / (d_t * mass[t] ** 2 * mass[u] * mass[g])
        assert coef == F(root["coefficient"])
        root_sum = F(0)
        for z, q in product(root["z_masks"], root["q_masks"]):
            x, y = (u, z), (g, q)
            assert (t, x, y) not in rows
            rows[t, x, y] = coef * mu[z] * mu[q]
            root_sum += rows[t, x, y]
        assert root_sum == F(root["root_mass"])
    support = {(t, x, y) for t in middle for x, y in product(permitted[t], repeat=2)
               if bins[x[0]] != bins[y[0]]}
    assert set(rows) == support
    assert len(roots) == 34 and len(rows) == 230
    assert set(rows.values()) and min(rows.values()) > 0
    assert all(rows[t, x, y] == rows[t, y, x] for t, x, y in rows)
    assert sum(rows.values()) == F(stage["benchmarks"]["cross"]["mother"])
    return bins, middle, rows, permitted, mu, j, mass


def grouped(rows, key):
    result = defaultdict(F)
    for (t, x, y), value in rows.items():
        result[key(t, x, y)] += value
    return dict(result)


def rank(matrix, arms):
    a = [[matrix.get((x, y), F(0)) for y in arms] for x in arms]
    pivots = 0
    for col in range(len(arms)):
        pivot = next((i for i in range(pivots, len(arms)) if a[i][col]), None)
        if pivot is None:
            continue
        a[pivots], a[pivot] = a[pivot], a[pivots]
        for i in range(pivots + 1, len(arms)):
            factor = a[i][col] / a[pivots][col]
            if factor:
                for k in range(col, len(arms)):
                    a[i][k] -= factor * a[pivots][k]
        pivots += 1
    return pivots


def ranks(rows, arms, bins, middle):
    matrix = grouped(rows, lambda t, x, y: (x, y))
    each_middle = {t: rank(grouped({key: val for key, val in rows.items() if key[0] == t},
                                  lambda t, x, y: (x, y)), arms)
                   for t in middle}
    each_bin = {str(b): rank(grouped({key: val for key, val in rows.items() if bins[key[0]] == b},
                                   lambda t, x, y: (x, y)), arms)
                for b in sorted({bins[t] for t in middle})}
    return {
        "M": rank(matrix, arms),
        "each_t": each_middle,
        "each_bin": each_bin,
        "direct_sum_t": sum(each_middle.values()),
        "direct_sum_bin": sum(each_bin.values()),
    }


def reuse(rows, bins, arm_key):
    by_group = defaultdict(lambda: defaultdict(F))
    for (t, x, y), weight in rows.items():
        by_group[arm_key(x, y)][bins[t]] += weight
    value = F(0)
    for block in by_group.values():
        divisor = sum(block.values())
        value += sum(a * b for d, a in block.items() for e, b in block.items() if d != e) / divisor
    return value


def diagnostics(rows, bins, mu, j, mass):
    marginal_x = grouped(rows, lambda t, x, y: x)
    marginal_y = grouped(rows, lambda t, x, y: y)
    load_x = {x: val / (j[x[0]] * mu[x[1]] / mass[x[0]]) for x, val in marginal_x.items()}
    load_y = {y: val / (j[y[0]] * mu[y[1]] / mass[y[0]]) for y, val in marginal_y.items()}
    return {
        "raw_mass": sum(rows.values()),
        "right_source_cross_bin": reuse(rows, bins, lambda x, y: y[1]),
        "right_arm_cross_bin": reuse(rows, bins, lambda x, y: y),
        "complete_arm_cross_bin": reuse(rows, bins, lambda x, y: (x, y)),
        "max_left_original_base_load": max(load_x.values()),
        "max_right_original_base_load": max(load_y.values()),
    }


def report(label, rows, arms, bins, middle, mu, j, mass, exact):
    result = ranks(rows, arms, bins, middle)
    print(label, "RANK", result)
    # Fixed placement at 0 and 1 in the real Hilbert space R, with base field Q.
    print(label, "PRICE distance=1", {
        k: format(log2(result[k]), ".12g") for k in ("M", "direct_sum_t", "direct_sum_bin")
    })
    quantities = diagnostics(rows, bins, mu, j, mass)
    print(label, "MEASURE", {k: format(float(v), ".15g") for k, v in quantities.items()})
    if exact:
        print(label, "EXACT", {k: str(v) for k, v in quantities.items()})
    return result, quantities


def apply_transfer(half, original, delta, strength):
    out = {k: half[k] + strength * delta.get(k, 0) for k in half}
    assert set(delta) <= set(half)
    assert all(0 < a <= original[k] for k, a in out.items())
    return out


def least_cap(half, delta):
    assert delta and all(value for value in delta.values())
    return min(half[k] / abs(value) for k, value in delta.items())


def audit_same(a, b, keys):
    for key in keys:
        assert grouped(a, key) == grouped(b, key)



def segregation(original, full_matrix, arms, bins, middle, exact):
    """Keep M and every (t,u,g) total; drive the complete-arm reuse to zero."""
    t, s = "t0", "t2"
    boundary = original.copy()
    pure_small, pure_large = [], []
    for u, x, y in original:
        if u != s:
            continue
        assert {x[0], y[0]} == {"u0", "u1"}
        assert (t, x, y) in original
        if ("u0", 77) in (x, y):
            assert ("t1", x, y) not in original
            boundary[s, x, y] += boundary[t, x, y]
            boundary[t, x, y] = F(0)
            pure_small.append((x, y))
        else:
            boundary[t, x, y] += boundary[s, x, y]
            boundary[s, x, y] = F(0)
            pure_large.append((x, y))
    assert len(pure_small) == 6 and len(pure_large) == 12
    assert grouped(boundary, lambda u, x, y: (x, y)) == full_matrix
    small = sum(boundary[s, x, y] for x, y in pure_small)
    large = sum(boundary[t, x, y] for x, y in pure_large)
    displacement = min(small, large) / 2
    interior = boundary.copy()
    for x, y in pure_small:
        delta = displacement * boundary[s, x, y] / small
        interior[s, x, y] -= delta
        interior[t, x, y] += delta
    for x, y in pure_large:
        delta = displacement * boundary[t, x, y] / large
        interior[t, x, y] -= delta
        interior[s, x, y] += delta
    assert all(v > 0 for v in interior.values())
    assert all(v >= 0 for v in boundary.values())
    theta = min(original[k] / max(boundary[k], interior[k]) for k in original) / 2

    def path(epsilon):
        return {k: theta * ((1 - epsilon) * boundary[k] + epsilon * interior[k])
                for k in original}

    zero = path(F(0))
    assert reuse(zero, bins, lambda x, y: (x, y)) == 0
    assert grouped(zero, lambda u, x, y: (x, y)) == {
        key: val * theta for key, val in full_matrix.items()
    }
    # Any minor has degree at most the matrix dimension. The maximum
    # ranks across these distinct evaluations are the generic ranks.
    def flat(block):
        return (block["M"], *block["each_t"].values(), *block["each_bin"].values())

    checks = [flat(ranks(path(F(1, k + 1)), arms, bins, middle))
              for k in range(1, len(arms) + 2)]
    generic = tuple(map(max, zip(*checks)))
    baseline = None
    print("SEGREGATION active rank (M,t0,t1,t2,64,128)", generic,
          "scale", format(float(theta), ".15g"))
    for denominator in (2, 16, 256, 4096):
        value = path(F(1, denominator))
        assert all(0 < v <= original[k] for k, v in value.items())
        assert all(v == value[t, y, x] for (t, x, y), v in value.items())
        audit_same(zero, value, (lambda u, x, y: (x, y),
                                 lambda u, x, y: (u, x[0], y[0])))
        assert flat(ranks(value, arms, bins, middle)) == generic
        charge = reuse(value, bins, lambda x, y: (x, y))
        assert charge > 0
        if baseline is None:
            baseline = charge
        print("SEGREGATION SAMPLE", "epsilon", f"1/{denominator}",
              "charge", format(float(charge), ".15g"),
              "charge / sample at 1/2", format(float(charge / baseline), ".15g"))
        if exact:
            print("SEGREGATION EXACT", "scale", str(theta), "charge", str(charge))

def fixture(name, stage, exact):
    stage_bytes = json.dumps(stage, sort_keys=True, separators=(",", ":"), default=str).encode()
    print("FIXTURE", name, "CANONICAL SHA256", sha256(stage_bytes).hexdigest())
    bins, middle, original, permitted, mu, j, mass = rebuild(stage)
    arms = sorted({x for _, x, _ in original} | {y for _, _, y in original})
    matrix = grouped(original, lambda t, x, y: (x, y))
    print("SUPPORT", {"ordered_parent_triples": 34, "positive_rows": len(original),
                      "active_arms_per_site": len(arms), "nonzero_M": len(matrix),
                      "middle_bins": {t: str(bins[t]) for t in middle}})

    def inspect(label, rows):
        return report(label, rows, arms, bins, middle, mu, j, mass, exact)

    original_rank, original_cost = inspect("ORIGINAL", original)
    half = {key: value / 2 for key, value in original.items()}
    half_rank, half_cost = inspect("HALF", half)
    assert original_rank == half_rank
    assert all(original_cost[k] == 2 * half_cost[k] for k in original_cost)

    # D_left M D_right holds separately in every fixed t/volume block.
    scales = {arm: F(1 + index % 3, 3) for index, arm in enumerate(arms)}
    diag = {(t, x, y): value * scales[x] * scales[y] for (t, x, y), value in original.items()}
    assert all(0 < v <= original[k] for k, v in diag.items())
    diag_rank, diag_cost = inspect("DIAGONAL_SUBFLOW", diag)
    assert diag_rank == original_rank
    assert diag_cost["complete_arm_cross_bin"] < original_cost["complete_arm_cross_bin"]

    # Column transfer on all u1 cells. Its common row direction is the
    # true u1 base-weight vector; a signed displacement only varies over u0.
    t, s = "t0", "t2"
    ux = (("u0", 79), ("u0", 95))
    uy = tuple(sorted(y for y in permitted[t] if bins[y[0]] == F(32)))
    assert uy == tuple(sorted(y for y in permitted[s] if bins[y[0]] == F(32)))
    assert uy == (("u1", 23), ("u1", 87), ("u1", 95))
    transfer = {}
    for sign, x in zip((1, -1), ux):
        for y in uy:
            w = j[y[0]] * mu[y[1]] / mass[y[0]]
            transfer[t, x, y] = sign * w
            transfer[s, x, y] = -sign * w
    step = least_cap(half, transfer) / 2
    directed = apply_transfer(half, original, transfer, step)
    keys = (lambda t, x, y: (x, y),
            lambda t, x, y: (t, x[0], y[0]),
            lambda t, x, y: (t, y))
    audit_same(half, directed, keys)
    assert grouped(half, lambda t, x, y: (t, x)) != grouped(directed, lambda t, x, y: (t, x))
    directed_rank, directed_cost = inspect("DIRECTED_TRANSFER", directed)
    assert directed_rank == original_rank
    assert directed_cost["complete_arm_cross_bin"] < half_cost["complete_arm_cross_bin"]
    assert directed_cost["right_arm_cross_bin"] == half_cost["right_arm_cross_bin"]
    transposed = {(t, x, y): val for (t, y, x), val in directed.items()}
    audit_same(half, transposed, keys[:2])
    transposed_rank, transposed_cost = inspect("TRANSPOSED_TRANSFER", transposed)
    assert transposed_rank == original_rank
    assert transposed_cost["complete_arm_cross_bin"] == directed_cost["complete_arm_cross_bin"]
    assert transposed_cost["right_arm_cross_bin"] < half_cost["right_arm_cross_bin"]

    # A two-bin swap along a fixed parent pair and along its transpose.
    # Both middle-specific receiver/endpoint marginals stay fixed. Within
    # the selected rectangle all bin proportions at the half-flow coincide,
    # so its linear cost term vanishes and concavity is strict.
    swap = {}
    for i, x in enumerate(ux):
        for k, y in enumerate(uy[:2]):
            h = (-1) ** (i + k)
            swap[t, x, y] = swap[t, y, x] = F(h)
            swap[s, x, y] = swap[s, y, x] = F(-h)
    cap = least_cap(half, swap)
    swap_a = apply_transfer(half, original, swap, cap / 4)
    swap_b = apply_transfer(half, original, swap, cap / 2)
    strict_keys = (*keys, lambda t, x, y: (t, x))
    audit_same(half, swap_a, strict_keys)
    audit_same(half, swap_b, strict_keys)
    assert all(flow[t, x, y] == flow[t, y, x] for flow in (swap_a, swap_b)
               for t, x, y in flow)
    rank_a, cost_a = inspect("SYMMETRIC_SWAP_A", swap_a)
    rank_b, cost_b = inspect("SYMMETRIC_SWAP_B", swap_b)
    assert rank_a == rank_b
    quadratic = sum(F(2) / matrix[x, y] for u, x, y in swap if u == t) * 2
    # denominator in both modified flows is M_original(x,y)/2 on each pair.
    loss_a = half_cost["complete_arm_cross_bin"] - cost_a["complete_arm_cross_bin"]
    loss_b = half_cost["complete_arm_cross_bin"] - cost_b["complete_arm_cross_bin"]
    assert loss_a == quadratic * (cap / 4) ** 2 > 0
    assert loss_b == quadratic * (cap / 2) ** 2 == 4 * loss_a
    for quantities in (cost_a, cost_b):
        assert quantities["right_source_cross_bin"] == half_cost["right_source_cross_bin"]
        assert quantities["right_arm_cross_bin"] == half_cost["right_arm_cross_bin"]
    print("SWAP LOSS", format(float(loss_a), ".15g"), format(float(loss_b), ".15g"))
    if exact:
        print("SWAP LOSS EXACT", str(loss_a), str(loss_b))
    segregation(original, matrix, arms, bins, middle, exact)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", default=ARCHIVE, type=Path)
    parser.add_argument("--exact", action="store_true")
    args = parser.parse_args()
    for name, stage in load(args.archive):
        fixture(name, stage, args.exact)
    print("PASS exact positivity, original history/cross checks, ranks and cross-bin reuse")


if __name__ == "__main__":
    main()
