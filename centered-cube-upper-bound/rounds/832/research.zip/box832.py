"""Round 832 box-envelope certificate and fixed-q coding diagnostic.

Run: python3 -B box832.py
All inputs are synthetic rational geometry. There is no archived R813 input.
"""

from collections import Counter
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN
from fractions import Fraction as F
from math import log
from platform import python_version


PRECISION = 50
STEPS = 1536
TAIL_WIDTH = F(24)
FLOOR = Context(prec=PRECISION, rounding=ROUND_FLOOR)
CEILING = Context(prec=PRECISION, rounding=ROUND_CEILING)
NEAREST = Context(prec=PRECISION, rounding=ROUND_HALF_EVEN)
ONE = Decimal(1)
ZERO = Decimal(0)


def dec(x, context):
    return context.divide(Decimal(x.numerator), Decimal(x.denominator))


def exponential(x):
    # Decimal.exp is correctly rounded to nearest. Enlarge both ends by one ulp.
    lower = NEAREST.exp(dec(x, FLOOR))
    upper = NEAREST.exp(dec(x, CEILING))
    return FLOOR.next_minus(lower), CEILING.next_plus(upper)


def logarithm(x):
    lower = NEAREST.ln(dec(x, FLOOR))
    upper = NEAREST.ln(dec(x, CEILING))
    return FLOOR.next_minus(lower), CEILING.next_plus(upper)


def mul(a, b):
    return FLOOR.multiply(a[0], b[0]), CEILING.multiply(a[1], b[1])


def add(a, b):
    return FLOOR.add(a[0], b[0]), CEILING.add(a[1], b[1])


def sub(a, b):
    return FLOOR.subtract(a[0], b[1]), CEILING.subtract(a[1], b[0])


def rational(x):
    return dec(x, FLOOR), dec(x, CEILING)


def power(base, exponent, context):
    value = ONE
    while exponent:
        if exponent & 1:
            value = context.multiply(value, base)
        exponent //= 2
        if exponent:
            base = context.multiply(base, base)
    return value


def product_bounds(relative_widths, u):
    # Fractions supply each exact factor; all multiplications are nonnegative.
    lower, upper = ONE, ONE
    for weight, count in relative_widths.items():
        factor = max(F(0), 1 - weight * u)
        lower = FLOOR.multiply(lower, power(dec(factor, FLOOR), count, FLOOR))
        upper = CEILING.multiply(upper, power(dec(factor, CEILING), count, CEILING))
    return lower, upper


def envelope(widths, b):
    total = sum(widths)
    assert total > 0 and b > 0
    if max(widths) >= b:
        return ZERO, ZERO

    # u=L/s, P(u)=prod(1-u*d_i/L). P(u)/u decreases over this interval.
    weights = Counter(width / total for width in widths if width)
    a = total / b
    endpoint = total / max(widths)
    stop = min(endpoint, a + TAIL_WIDTH)
    step = (stop - a) / STEPS
    boundary = product_bounds(weights, a)
    previous = mul(boundary, rational(1 / a))
    lower, upper = ZERO, ZERO
    for i in range(1, STEPS + 1):
        u = a + i * step
        current = mul(product_bounds(weights, u), rational(1 / u))
        lower = FLOOR.add(lower, current[0])
        upper = CEILING.add(upper, previous[1])
        previous = current
    integral = mul((lower, upper), rational(step))
    if stop < endpoint:
        # Integral_stop^infty exp(-u)/u du <= exp(-stop)/stop.
        tail = mul(exponential(-stop), rational(1 / stop))
        integral = integral[0], CEILING.add(integral[1], tail[1])
    return add(boundary, mul(rational(F(len(widths))), integral))


def n2_closed_form(widths, b):
    # Integral of (1-d1/s)(1-d2/s)/s in the original s coordinate.
    d1, d2 = widths
    a = max(widths)
    integral = add(
        logarithm(b / a),
        rational((d1 + d2) * (1 / b - 1 / a) -
                 d1 * d2 * (1 / b**2 - 1 / a**2) / 2),
    )
    return add(rational((1-d1/b)*(1-d2/b)), mul(rational(F(2)), integral))


def price_bound(n, h):
    return mul(exponential(-h), rational(1 + n / h))


def tangent_bound(widths, b):
    relative = tuple(width/b for width in widths)
    baseline = product_bounds(Counter(r for r in relative if r), F(1))
    slope = sum(r / (1-r) for r in relative)
    return mul(baseline, rational(1 + len(widths)/slope))


def threshold(n, code_factor):
    # Monotone crossing code_factor * e^-h*(1+n/h) = 1.
    lower, upper = F(1,16), F(32)
    assert mul(price_bound(n, lower), rational(code_factor))[0] > 1
    assert mul(price_bound(n, upper), rational(code_factor))[1] < 1
    for _ in range(32):
        mid = (lower + upper) / 2
        value = mul(price_bound(n, mid), rational(code_factor))
        if value[0] > 1:
            lower = mid
        else:
            assert value[1] < 1
            upper = mid
    return display((dec(lower, FLOOR), dec(upper, CEILING)))


def display(bounds):
    # Print exact Decimal endpoints so displayed precision retains enclosure.
    return "[" + ",".join(map(str, bounds)) + "]"


def box_from_corners(widths):
    # The opposite true labels attain the diameter for the common binary
    # Hilbert embedding. Every other pair differs on a subset of the axes.
    lower = tuple(-width/2 for width in widths)
    upper = tuple(width/2 for width in widths)
    return sum(abs(x-y) for x, y in zip(lower, upper, strict=True))


def width_cases(n):
    varied = (F(3, 4), F(7, 8), F(9, 8), F(5, 4))
    if n == 2:
        yield "equal", (F(3, 4), F(3, 4)), F(3, 2), F(2)
        yield "unequal", (F(1, 2), F(3, 4)), F(1), F(2)
        return

    for h, factor in ((F(2), F(2)), (F(8), F(2)), (F(12), F(4))):
        yield "equal", (h/n,) * n, h, factor
    yield "two-active", (F(7, 8), F(5, 8)) + (F(0),) * (n-2), F(3, 2), F(1)
    for h, factor in ((F(4), F(2)), (F(8), F(2)), (F(12), F(4))):
        weights = tuple(varied[i % len(varied)] for i in range(n))
        yield "varied", tuple(h * w / sum(weights) for w in weights), h, factor


def run_geometry():
    count = 0
    for stage, dimensions in enumerate(((2,), (16, 64), (256, 1024)), start=1):
        print("GEOMETRY STAGE", stage)
        for n in dimensions:
            print(f"n={n} threshold code-factor 2: {threshold(n, F(2))}")
            for family, widths, h, code_factor in width_cases(n):
                assert len(widths) == n and h <= sum(widths) == box_from_corners(widths)
                tight = envelope(widths, F(1))
                coarse = price_bound(n, h)
                tilted = tangent_bound(widths, F(1))
                assert 0 < tight[0] <= tight[1] < tilted[0] <= tilted[1] < coarse[0]
                if n == 2:
                    independent = n2_closed_form(widths, F(1))
                    assert tight[0] <= independent[0] <= independent[1] <= tight[1]
                # g = -log(I * code_factor). Sign is certified by product vs 1.
                exact_product = mul(tight, rational(code_factor))
                coarse_product = mul(coarse, rational(code_factor))
                exact_sign = "+" if exact_product[1] < 1 else "-" if exact_product[0] > 1 else "?"
                coarse_sign = "+" if coarse_product[1] < 1 else "-" if coarse_product[0] > 1 else "?"
                assert "?" not in (exact_sign, coarse_sign)
                # log approximations are display only; the sign came from intervals.
                gain = -log(float((tight[0] + tight[1])/2 * dec(code_factor, NEAREST)))
                gain_coarse = -log(float((coarse[0] + coarse[1])/2 * dec(code_factor, NEAREST)))
                print(f"n={n} {family} L/b={sum(widths)} h={h} c={code_factor}"
                      f" I={display(tight)} T={display(tilted)} U={display(coarse)}"
                      f" gain={exact_sign}({gain:.6g}) bound-gain={coarse_sign}({gain_coarse:.6g})")
                count += 1
    assert envelope((F(1), F(1, 2)), F(1)) == (ZERO, ZERO)
    assert envelope((F(5, 4), F(1, 2)), F(1)) == (ZERO, ZERO)
    print("GEOMETRY CHECKS PASSED", count, "+ two zero-volume boundaries")


def receiver_geometry():
    signs = ((1, 1), (1, -1), (-1, 1), (-1, -1))
    q = (F(0), F(0))
    menu = tuple((q, (F(a, 2), F(b, 2))) for a, b in signs)
    cells = []
    for signs_xy in signs:
        for scale in (F(1), F(3, 4)):
            center = tuple(z*scale/4 for z in signs_xy)
            radius = scale/32
            cells.append((center, radius, scale))
    cells.append((q, F(1, 16), F(1, 8)))
    for i, (center, radius, _) in enumerate(cells):
        for other, other_radius, _ in cells[:i]:
            assert any(abs(a-b) > radius+other_radius for a,b in zip(center, other, strict=True))

    incidence = []
    for t, (center, radius, scale) in enumerate(cells):
        # Any center in the finite Lebesgue receiver cell has this incidence.
        assert all(abs(c)+radius <= scale/2 for c in center)
        row = []
        for box in menu:
            vertex = box[-1]
            all_fit = all(abs(c-v)+radius <= scale/2 for c,v in zip(center, vertex, strict=True))
            all_miss = any(abs(c-v)-radius > scale/2 for c,v in zip(center, vertex, strict=True))
            assert all_fit != all_miss
            row.append(all_fit)
        assert row == [t//2 == j for j in range(4)]
        incidence.append(tuple(row))

    cap = tuple((2*radius/scale)**2 for _, radius, scale in cells)
    pi_first = cap[:-1]
    pi = pi_first + (1-sum(pi_first),)
    assert cap[-1] == 1 and sum(pi) == 1 and all(0 < p <= c for p,c in zip(pi,cap,strict=True))
    return tuple(incidence), pi


def mixture_success(law, prior, incidence):
    return sum(p * sum(r for r, hit in zip(prior, row, strict=True) if hit)
               for p, row in zip(law, incidence, strict=True))


def average_log_ratios(law, denominator):
    total = ZERO, ZERO
    for p, q in zip(law, denominator, strict=True):
        if p:
            bounds = logarithm(p / q)
            # A possibly negative log needs all four endpoint products.
            weights = rational(p)
            lower = min(FLOOR.multiply(a,b) for a in weights for b in bounds)
            upper = max(CEILING.multiply(a,b) for a in weights for b in bounds)
            total = add(total, (lower, upper))
    return total


def run_menu():
    incidence, pi = receiver_geometry()
    uniform = (F(1,4),) * 4
    reference_hit = mixture_success(pi, uniform, incidence)
    assert reference_hit == F(1,128)
    reference_price = logarithm(1/reference_hit)
    print("SYNTHETIC FIXED-q MENU 8 active disjoint receiver cells, two scales,"
          " 1 reserve cell, pi_hit=1/128, pi density <= side^-2")
    for group in ((1,1,1,1), (4,2,1,1), (12,2,1,1), (7,4,3,2), (8,0,0,0)):
        # The normalized target lives on the eight real center/scale cells.
        # Two scales per occupied sign receive 3/4 and 1/4 except in the uniform case.
        scale_share = (F(1,2), F(1,2)) if len(set(group)) == 1 else (F(3,4), F(1,4))
        occupation = tuple(F(v,sum(group)) for v in group)
        target = tuple(p * s for p in occupation for s in scale_share) + (F(0),)
        assert sum(target) == 1
        assert all(sum(row) == 1 for p,row in zip(target,incidence,strict=True) if p)
        best_fixed = max(occupation)
        independent = mixture_success(target, uniform, incidence)
        assert independent == F(1,4)
        adapted_prior_success = mixture_success(target, occupation, incidence)
        assert adapted_prior_success == sum(p*p for p in occupation)

        # Deterministic choice after reading (t,x), with a precommitted uniform menu.
        # Change of law has two likelihood factors: P/pi on the history and 4 on
        # the box. A precommitted prior equal to the actual menu marginal saves
        # D(occupation||uniform) in expectation, leaving the entropy of the menu.
        i = average_log_ratios(target, pi)
        fixed_menu_cost = logarithm(F(4))
        fitted_prior_cost = average_log_ratios(occupation, (F(1),) * 4)
        fitted_prior_cost = (fitted_prior_cost[1].copy_negate(), fitted_prior_cost[0].copy_negate())
        gain = sub(reference_price, add(i, fixed_menu_cost))
        if len(set(group)) == 1:
            assert gain[0] < 0 < gain[1]
        else:
            assert gain[1] < 0
        pointwise_signs = tuple(
            "." if not p else "+" if 4*p/q < 1/reference_hit else "-" if 4*p/q > 1/reference_hit else "0"
            for p,q in zip(target,pi,strict=True)
        )
        # The likelihood optimized menu may read the history, hence succeeds on
        # all positive target rows. Omitting the menu term overstates gain by log 4.
        ignored_cost_gain = sub(reference_price, i)
        fitted_gain = sub(reference_price, add(i, fitted_prior_cost))
        if len(set(group)) == 1:
            assert fitted_gain[0] <= 0 <= fitted_gain[1]
        else:
            assert fitted_gain[1] < 0
        print(f"  occ={group} best-fixed={best_fixed} iid-uniform={independent}"
              f" iid-occupation={adapted_prior_success} history-selected=1"
              f" E[i]={float(i[0]):.9f} E[j-uniform]={float(fixed_menu_cost[0]):.9f}"
              f" E[j-fitted]={float(fitted_prior_cost[0]):.9f}"
              f" g-joint={float(gain[0]):.9f} g-fitted={float(fitted_gain[0]):.9f}"
              f" g-ignoring-j={float(ignored_cost_gain[0]):.9f}"
              f" signs={''.join(pointwise_signs)}")


if __name__ == "__main__":
    print("Python", python_version(), "decimal precision", PRECISION, "mesh", STEPS)
    run_geometry()
    run_menu()
