# R168：联合计数—距离容量门及可回代通式

状态：保留原 high 与实际 e_g/q，得到精确必要容量门和一条带显式可付款条件的 τ–capacity 通式。它没有支付一般中间带的容量尾；本稿不以扩大 m_0 邻近带为主要成果，不改变 θ=1/4，不延伸固定 I1。

## 1. 原量词与共同参数

仅使用本轮合同、自己 R167 已审 X3–X10，以及 R166 source_contract 的来源和实际 FIRST 接口。固定 0<s_0≤1，η=1−∫_{−1}^1φ、ε=s_0η、a=3ε/4。字母 a 在本节指数公式中仅指 3ε/4；尺度下端仍写 a_scale，以免与原尺度合同混淆。以下无新 α：ρ 始终由原同一个 α_RC 计算。

原接收参数 s,L,R,g、e_g、q 可依 x。固定 (ω,V,j,y,t) 时，Π_t 是原完整概率且不依 x 或外 hard 来源；ν≤β≤f dx，β、ν 不互换。原 good 为 p w_g(v)≤KQ_v，high 为 p e_g≥2Kq。hard 帽 16/3 只用一次，外 signed 因子 2Λ、安全 j 数≤n+2、时间≤log2 和原 W_β 聚合均保留。

## 2. 中间域强制的真实容量下界

令

\[
 A_s=1-s+s\phi(0),\quad
 B_{s,L}=s\phi(b/(2L)),\quad
 h_{s,L}=\log(A_s/B_{s,L}),\quad
 h_* =\log(\phi(0)/\phi(1/2))>0.
\]

对全部合法 s∈(0,1]、L≤b，有 h_{s,L}≥h_*。因为 A_s/s≥φ(0)，而 φ(b/(2L))≤φ(1/2)。

记 m=m_b(x,y)、D=D_b(x,y)。每个 core 内坐标的密度因子不超过 A_s；每个外坐标的硬部分为零。φ 的尾部是速率≥1的指数混合，故对 d≥0，

\[
 \phi\bigl(b/(2L)+d/L\bigr)
 \le\phi(b/(2L))e^{-d/L}.
\]

于是有原 p 的逐点界

\[
 p(x-y)\le L^{-n}A_s^n
       \exp[-m h_{s,L}-D/L].                              \tag{M1}
\]

把 high 代入，定义真实容量坐标

\[
 \Theta(x,y)=\log\frac{e_g(x,y)A_{s(x)}^n}
                         {2Kq(x)L(x)^n}.
\]

则所有原 high 行必须满足

\[
 \boxed{\quad
 m h_{s,L}+D/L\le\Theta(x,y),\qquad
 h_*m+D/b\le\Theta(x,y).
 \quad}                                                   \tag{M2}
\]

没有冻结 e_g，也没有把 e_g/q 视为常数。零分母沿原零交通处理。对实际未付中间域 m≥m_0+1、D>d_*，(M2) 特别给

\[
 \frac{e_g}{q}>2K L^n A_s^{-n}
       \exp\bigl[(m_0+1)h_{s,L}+d_*/L\bigr].             \tag{M3}
\]

这比只记录“m 大”保留了具体的容量需求；它本身不是尾预算。由于 e_g≤e_t，必要时可将 (M2) 右端上放为当前 e_t 对应的表达式；该操作只能放宽必要门，不能把反向包含或充分性一并推出。

## 3. τ–capacity 的来源统一空间通式

取固定 τ≥0、γ≥0，定义容量子支

\[
 \mathcal C_\gamma=
 \{s\ge s_0,\ \text{原 high},\ \Theta(x,y)\le\gamma n\}.
\]

由 (M2)，其接收点属于不依 source v,u 的几何域

\[
 \mathcal G_\gamma(y)=\{h_*m_b(x,y)+D_b(x,y)/b\le\gamma n\}.
                                                               \tag{M4}
\]

这一步使 e_g 的接收依赖保留在合法分支定义中，而不被提出积分。

归一 b=1，并沿 R167 记
H_V(X)=p_{s,ℓ}(X)^{3/4}[φ(X−V)/C(V)]^{1/4}。X5 给 core 质量≤e^{-a}。保留 X6 证明里的外尾，而不立即积分其 overflow，可得

\[
 \int_{|X|>1/2}H_V(X)
 e^{-\tau[h_*+(|X|-1/2)]}dX
 \le {20e^{-\tau h_*}\over1+2\tau}.                       \tag{M5}
\]

这是原外尾 e^{−|X|/2}(1+|X|)^{-1/2} 乘 e^{−τ(|X|−1/2)} 的直接积分；多项式因子上放至 1，所得积分与 τ=0 相比恰多因子 (1+2τ)^{-1}。对一般相关 ν 不作独立性假设。

在 (M4) 上，1≤exp{τ[γn−h_*m−D/b]}。产品 Tonelli 因而给每个固定来源向量的空间界

\[
 \boxed{\quad
 \int_{\mathcal G_\gamma(y)}\prod_iH_{V_i}(X_i)dX
 \le\left\{e^{\tau\gamma}
       \left[e^{-a}+{20e^{-\tau h_*}\over1+2\tau}\right]
      \right\}^{n}.
 \quad}                                                   \tag{M6}
\]

这是显式函数界，右端没有待证来源 supremum。它允许计数和距离混合，不令 δ=m。凡预先固定的 γ、τ 满足

\[
 \kappa:=-\log\left\{e^{\tau\gamma}
       \left[e^{-a}+{20e^{-\tau h_*}\over1+2\tau}\right]
                 \right\}>0,                             \tag{M7}
\]

就获得来源统一的指数收缩 e^{-κn}。若 (M7) 不成立，本通式不提供付款结论，不能依赖同一未付积分重新选 γ。

## 4. 原交通的完整回代条件与价格

原 good 给

\[
 1_{\rm good}p\chi_J\le(K/3)^{1/4}
       p^{3/4}[J/C_{\rm prod}]^{1/4}.
\]

ρ 使用原同 α_RC，只作 ρ≤1 上放。接收域 (M4) 用 b、h_*、γ 定义，不随 s/L 网格节点变动。因此 R167 的向下 s 网格、向上 L 网格直接适用，费用为

\[
 e^{3/2}(n+2)(1+n\log(1/s_0)).
\]

这是安全可用的旧菜单费；若主报告另证更小的 future-soft Bernstein 费用，可在其已核量词下替换。本稿不预领该改进。

再用原 Π_t 对 x 的独立性、Π_t² 总质量 1、δ≤n、时间 log2、一次 hard 帽、安全 j 数及 β 聚合，在 (M7) 成立时得到实际容量子支价格

\[
\begin{split}
 2\Lambda P_{\mathcal C_\gamma}
 &\le {32\Lambda\over3}(K/3)^{1/4}e^{3/2}\log2\,
 n(n+2)^2(1+n\log(1/s_0))e^{-\kappa n}W_\beta\\
 &\le\boxed{\ 96\Lambda(K/3)^{1/4}e^{3/2}\log2\,
 (1+\log(1/s_0))
 \left({7\over2e\kappa}\right)^{7/2}\sqrt n\,W_\beta\ }.
                                                               \tag{M8}
\end{split}
\]

实际 middle 与容量子支的交集当然满足同界。若与已付 U、S 或其他分支交叠，先取未付差集再使用 (M8)，不为同一交通再领预算。没有新增 q/e_t 下界、source 独立性或 history 概率归一化假设。

为说明 (M7) 是非空条件，可取 T=log(80e/a)、τ=(T−log T)/h_*、γ=a/(4τ)。因为 0<h_*<2、T>5，τ≥T/(2h_*)，所以

\[
 {20e^{-\tau h_*}\over1+2\tau}
 ={aT\over4e(1+2\tau)}\le {ah_*\over4e}
 <{a\over2e}\le e^{-a/2}-e^{-a}.
\]

最后一步用 a≤3/4 与 e^{a/2}−1≥a/2。故 (M6)≤e^{-an/4}，κ可取 a/4=3ε/16。此选择只作为通式的可用实例，不作为“解决中间带”的主成果；本稿不继续精细优化 m_0 邻近覆盖。

## 5. 一般中间带仍缺的最小接缝

原未付 middle 不保证 Θ≤γn。对任何已经预先固定并满足 (M7) 的容量层，剩余明确为

\[
 \mathcal M\cap\{\Theta>\gamma n\},
\]

其中 \(\mathcal M\) 保留 s≥s_0、D>d_*、m>m_0 及原未被 FIRST 高尾支付的门。所缺的是这份真实容量尾的 weighted 接收预算：须在原 dx、β、hard、同 α_RC、Π_t 和 δ 上，给出可加入 W_β 或原允许 receiver X 预算的上界。不能仅用 (M3) 的阈值取代这份预算。

现有合同中 FIRST 控制同一接收点 x 的合法核卷积；e_g 是以 y 为中心、终端由 x 选择的来源权势。ν≤β 和有限总质量未提供所需容量尾小概率。即使用 e_t 的 x 独立性，∫e_t(y)dβ(y) 仍是实际 β–ν 双来源积分；没有已证合同将其在这些门下变成可用的 W_β 线性尾估计。R166 source_contract 也明确没有统一全叶 q a_scale^n 局部质量帽，不能借此删除容量。

因此本路线的最小下一步是：在 (M3) 所刻画的大容量层上，证明一个保留上述实际权重的 source-capacity 尾支付，或将其与同 α_RC 的负项／原 receiver X 吸收严格连接。这里没有给该尾命名为新范数或宣称已付。低 soft s<s_0 和未覆盖的中间容量尾仍未闭合；本稿不展开新的反例或固定模型数值。有限路线交付至此停止。
