#!/usr/bin/env python3
"""One R168 rational LP candidate: bounded rigorous coefficient/margin check.
Uses R166 stdlib directed intervals; does not invoke the LP or source search.
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal
import importlib.util,json,hashlib,time
HERE=Path(__file__).resolve().parent
DEP=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round166_20261015_final_checkpoint/window_certificate.py')
sp=importlib.util.spec_from_file_location('r168_interval',DEP);iv=importlib.util.module_from_spec(sp);sp.loader.exec_module(iv)
I=iv.I
X=[F(51,100)]+[F(2,5)]*3
Y=[F(0)]*4
POS=[[F(53,50)]+[F(19,20)]*3, [F(-3,5)]*4, X]
NU=[F(483,10000),F(94843,100000),F(327,100000)]
QLEVEL=F(37,10000);LAM=F(423,100000)
S=F(1,4);L=F(9,10);R=F(1);N=4

def prod(xs):
    ans=I(1)
    for x in xs:ans=ans*x
    return ans

def log2_interval(terms=60):
    z=F(1,3)
    total=sum((2*z**(2*j+1)/F(2*j+1) for j in range(terms)),F(0))
    tail=2*z**(2*terms+1)/(F(2*terms+1)*(1-z*z))
    return I(I(total).lo,I(total+tail).hi)

def log_rational(q,terms=60):
    q=F(q);assert q>0;k=0
    while q<1:q*=2;k-=1
    while q>2:q/=2;k+=1
    z=(q-1)/(q+1)
    total=sum((2*z**(2*j+1)/F(2*j+1) for j in range(terms)),F(0))
    tail=2*z**(2*terms+1)/(F(2*terms+1)*(1-z*z))
    return I(k)*log2_interval()+I(I(total).lo,I(total+tail).hi)

def log_interval(q):
    return I(log_rational(F(q.lo)).lo,log_rational(F(q.hi)).hi)

def phi_range(q,N):
    assert q.lo>=0
    return I(iv.phi(F(q.hi),N).lo,iv.phi(F(q.lo),N).hi)

def kern(s,scale,delta,Na):
    scale=I(scale);out=I(1)
    for d in delta:
        dd=I(abs(d))
        if I(2*abs(d)).hi<=scale.lo:hard=I(1)
        elif I(2*abs(d)).lo>scale.hi:hard=I(0)
        else:hard=I(0,1)
        out=out*((I(1-s)*hard+I(s)*phi_range(dd/scale,Na))/scale)
    return out

def run(Na,expect_future_rejection=True):
    ell=I(1)+2*log2_interval()
    g=I(L).sqrt(); h=g*iv.exp_neg(F(1,400));tau=I(F(1,2))
    T=I(1)/(I(L**2)*ell.sqrt())
    ellroot=ell.sqrt().sqrt().sqrt()
    H=g*(I(1-S)+I(S)*iv.phi(F(1,2),Na))*ellroot
    assert H.lo>Decimal('.5') and H.hi<1
    C=[[iv.C(abs(y-z),Na) for y,z in zip(Y,row)] for row in POS]
    def weights(t):return [prod((cc/I(t)).capped_one() for cc in row) for row in C]
    wg=weights(g);wtau=weights(tau);wh=weights(h)
    Delta=[a-b for a,b in zip(wtau,wh)]
    A=[T*d for d in Delta]
    p=kern(S,I(L),[a-b for a,b in zip(X,Y)],Na)
    K={name:[kern(ss,scale,[a-b for a,b in zip(X,z)],Na) for z in POS]
       for name,ss,scale in [('K0',S,H),('K1',S,I(L)),('K2',S,I(1)),('J',F(1),I(1))]}
    K['Q']=[(a+b+c)/I(3) for a,b,c in zip(K['K1'],K['K2'],K['J'])]
    good=[True,False,True]
    goodm=[K['Q'][i]-p*wg[i] if good[i] else p*wg[i]-K['Q'][i] for i in range(3)]
    assert all(z.lo>0 for z in goodm)
    U=[I(min(a.lo,b.lo),min(a.hi,b.hi)) if good[i] else I(0) for i,(a,b) in enumerate(zip(A,K['K0']))]
    def dot(vec):return sum((I(n)*v for n,v in zip(NU,vec)),I(0))
    jnu=dot(K['J']);eg=dot(wg);alpha_num=I(QLEVEL)-dot(U);alpha=alpha_num/jnu
    Ntarget=(A[0]-K['K0'][0])*jnu-K['J'][0]*alpha_num
    rho=Ntarget/(A[0]*jnu)
    hard=[all(abs(a-b)<=R/2 for a,b in zip(X,z)) for z in POS]
    hmass=sum((n for n,hit in zip(NU,hard) if hit),F(0))
    margins={**{'q_ge_'+name:I(QLEVEL)-dot(K[name]) for name in K},
        'high':p*eg-2*I(QLEVEL),'alpha_num':alpha_num,
        'lambda_lower':I(QLEVEL-F(3,4)*LAM),'lambda_upper':I(LAM-QLEVEL),
        'hard_cap':I(4*LAM-hmass/R**N), 'hard_positive':I(hmass),
        'heavy_terminal':eg-ell*I(QLEVEL)*I(L**2), 'rho_N':Ntarget,
        **{'good_bad_'+str(i):z for i,z in enumerate(goodm)}}
    # Whole fixed interval [.51,.53]: exact counts (4,0,0), w_u=1.
    xi_lo=F(51,100);xi_hi=F(53,100)
    assert all(cc.hi<Decimal('.51') for cc in C[0])
    assert all(cc.lo>Decimal('.53') for row in C[1:] for cc in row)
    assert h.lo>Decimal('.53')
    low_weights=weights(I(xi_lo));high_weights=weights(I(xi_hi))
    etmax=dot(low_weights);dv=I(1)-K['K0'][0]/A[0]
    low_lhs=K['K0'][1]*K['J'][0]*etmax
    low_rhs=I(F(25,3))*dv*dv*A[0]*I(4)*jnu
    margins['lowc_whole_interval']=low_rhs-low_lhs
    margins['FA_whole_interval_assuming_BFA_ge_1']=I(4)*p*high_weights[0]-K['Q'][0]
    lowratio=low_lhs/low_rhs
    assert all(z.lo>0 for z in margins.values())
    future_a=[kern(S,I(F(1,2)),[a-b for a,b in zip(X,z)],Na) for z in POS]
    future_a_mass=dot(future_a)
    future_hard_only=I(NU[2])*future_a[2]
    if expect_future_rejection:
        assert future_hard_only.lo>I(QLEVEL).hi and future_a_mass.lo>I(QLEVEL).hi
    else:
        assert future_a_mass.hi<I(QLEVEL).lo
    c=I(1)-iv.phi(F(1,2),Na)
    r=I(F(1,4));ptilt=I(S)*c
    rate=r*log_interval(r/ptilt)+(I(1)-r)*log_interval((I(1)-r)/(I(1)-ptilt))
    Bstar=4*rate
    ustar=r/c
    lphi=2/(I(1)-iv.exp_neg(F(1)))
    # Both scale branches maximize at L'=L for this fixed displacement.
    shrink_derivative_margin=lphi*I(F(171,100))-I(4*L)
    assert shrink_derivative_margin.lo>0 and ustar.lo>Decimal('.25') and ustar.hi<1
    Hfull=I(1)+log_interval(I(72000));Hfixed=log_interval(I(2400))
    assert Bstar.hi<Hfixed.lo<Hfull.lo
    return dict(a_subdivisions=Na,ell=ell.out(),g=g.out(),h=h.out(),T=T.out(),Hhat=H.out(),
        C=[[z.out() for z in row] for row in C],wg=[z.out() for z in wg],Delta=[z.out() for z in Delta],
        p=p.out(),eg=eg.out(),kernels={k:[z.out() for z in v] for k,v in K.items()},
        U=[z.out() for z in U],alpha=alpha.out(),rho_target=rho.out(),QJ=jnu.out(),
        exact_hard=hard,hard_mass_exact=str(hmass),lowc_ratio_whole_interval=lowratio.out(),
        time_interval=[str(xi_lo),str(xi_hi)],count_profile=[4,0,0],
        geometric_classification=dict(old_rate_at_m_over_n=rate.out(),old_rate_exponent=Bstar.out(),
            new_Bstar_all_future_u_and_Lprime=Bstar.out(),maximizing_u=ustar.out(),maximizing_Lprime='9/10',
            shrink_derivative_positive_margin=shrink_derivative_margin.out(),
            full_H_zeta_001=Hfull.out(),fixed_test_H_zeta_001=Hfixed.out(),
            full_H_gate=False,fixed_test_H_gate=False),
        strict_margins={k:z.out() for k,z in margins.items()},
        additional_TRUE_FIRST_test=dict(future_s='1/4',future_L='1/2',kernel_values=[z.out() for z in future_a],
            hard_source_only_contribution=future_hard_only.out(),full_nu_contribution=future_a_mass.out(),
            hard_only_excess_over_q=(future_hard_only-I(QLEVEL)).out(),
            full_excess_over_q=(future_a_mass-I(QLEVEL)).out(),passes=not expect_future_rejection,
            conclusion=('REJECTED: the legal future K_(s,a) test exceeds common q already on the hard source alone' if expect_future_rejection else 'PASS for this endpoint; continuum future tests require the separate refined certificate')))

def main():
    start=time.monotonic();assert sum(NU)==1
    rational_hard_lower=NU[2]*(1-S)**N/F(1,2)**N
    assert rational_hard_lower>QLEVEL
    rows=[run(64),run(128)]
    d=sum((max(abs(x-y)-F(1,2),F(0)) for x,y in zip(X,Y)),F(0))
    m=sum(abs(x-y)>F(1,2) for x,y in zip(X,Y))
    assert d==F(1,100) and m==1
    # eps=s0*eta<1/4, theta>=16/eps => dstar<n/2048=1/512<D.
    assert F(N,2048)<d
    data=dict(scope='One rational five-test LP candidate: legacy margins certified, but REJECTED by an additional legal FIRST future K_(s,a) test. No remaining-model feasibility claim.',
        arithmetic='R166 directed Decimal + rational Taylor exp + convex midpoint/trapezoid E integrals + integer sqrt; logs use range-reduced atanh series with explicit positive tail.',
        input_sha256={str(DEP):hashlib.sha256(DEP.read_bytes()).hexdigest()},
        geometry=dict(n=N,xq=list(map(str,X)),yq=list(map(str,Y)),positions=[list(map(str,z)) for z in POS],s=str(S),L=str(L),R=str(R),a='1/2',b='1',cj='1',s0='1/4',
                      D_exact=str(d),m_exact=m,dstar_strict_upper='1/512',m0_exact=0),
        candidate=dict(nu=list(map(str,NU)),q=str(QLEVEL),lambda_value=str(LAM),target_v=0,bad_u=1,hard_z=2),
        pure_rational_FIRST_rejection=dict(center_hard_kernel_lower='81/16',single_hard_mass_lower=str(rational_hard_lower),excess_over_q=str(rational_hard_lower-QLEVEL)),
        refinements=rows,legacy_five_test_margins_all_strict=True,full_FIRST_status='REJECTED_BY_LEGAL_FUTURE_TEST_K_s_a',
        limitations=['Fixed Z_t=all three toy sources is assumed; original Z/Psi eligibility not constructed.',
                     'FA certificate uses only B_FA>=1; the n4 inherited constant satisfies that, but original Psi remains unverified.',
                     'No continuous receiver volume is certified; positive time interval is certified for fixed x.',
                     'q and lambda are independent common LP variables; the chosen q is explicitly incompatible with a legal future FIRST test.'],
        wall_seconds=round(time.monotonic()-start,3))
    (HERE/'lp_candidate_certificate.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps(dict(seconds=data['wall_seconds'],rho=rows[-1]['rho_target'],alpha=rows[-1]['alpha'],lowc=rows[-1]['lowc_ratio_whole_interval'],classification=rows[-1]['geometric_classification'],future_rejection=rows[-1]['additional_TRUE_FIRST_test']),indent=2))
if __name__=='__main__':main()
