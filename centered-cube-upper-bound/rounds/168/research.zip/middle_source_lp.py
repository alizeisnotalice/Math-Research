#!/usr/bin/env python3
"""Finite necessary-model LP in source masses and a common q (R168).

No FULL/FIRST/source realization or continuous dx/time mass is certified.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,types,importlib,importlib.util
import json,math,hashlib

SOURCE_DIR=Path(__file__).resolve().parent
HERE=SOURCE_DIR
RUNTIME=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime')
sys.path.insert(0,str(RUNTIME))
# Load the real SciPy linprog/HiGHS implementation without importing unrelated
# broken local PROPACK/COBYLA extensions. PROPACK is never called here.
svdp=types.ModuleType('scipy.sparse.linalg._svdp')
def unused_propack(*args,**kwargs):raise RuntimeError('PROPACK not used by this LP')
svdp._svdp=unused_propack;sys.modules[svdp.__name__]=svdp
op=types.ModuleType('scipy.optimize');op.__path__=[str(RUNTIME/'scipy/optimize')];sys.modules[op.__name__]=op
oo=importlib.import_module('scipy.optimize._optimize');op.OptimizeWarning=oo.OptimizeWarning;op.OptimizeResult=oo.OptimizeResult
linprog=importlib.import_module('scipy.optimize._linprog').linprog
DEP=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round165_20261015_final_checkpoint/hard_overlap_check.py')
sp=importlib.util.spec_from_file_location('r168_kernel_tools',DEP);kt=importlib.util.module_from_spec(sp);sp.loader.exec_module(kt)
old,np,mp=kt.old,kt.np,kt.mp


def fstr(x):return str(x.numerator) if x.denominator==1 else str(x)


def freeze(n,x,y,positions,s=.25,L=.9,R=1.,K=1.,D=1.):
    xq=[F(v) for v in x];yq=[F(v) for v in y];posq=[[F(v) for v in row] for row in positions]
    xx=np.array([float(v) for v in xq]);yy=np.array([float(v) for v in yq]);pos=np.array([[float(v) for v in row] for row in posq])
    a=.5;b=1.;cj=1.;ell=1+math.log(n);g=math.sqrt(L*R);zg=g;h=g*math.exp(-.01/n);tau=.5
    T=1/(g**n*math.sqrt(ell));H=max(a,min(b,g*(1-s+s*float(old.phi_np([.5])[0]))*ell**(1/(2*n))))
    Lp=min(b,(1+1/n)*L)
    C=np.array([[kt.C(float(yq[j]-row[j])) for j in range(n)] for row in posq])
    weight=lambda t:np.prod(np.minimum(1.,C/t),axis=1)
    wg=weight(zg);delta=weight(tau)-weight(h)
    dx=xx[None,:]-pos
    p=float(old.kernel_np(s,L,(xx-yy)[None,:])[0])
    K0=old.kernel_np(s,H,dx);K1=old.kernel_np(s,L,dx);K2=old.kernel_np(s,Lp,dx);J=old.kernel_np(1.,b,dx);Q=(K1+K2+J)/3
    future={name:old.kernel_np(ss,scale,dx) for name,ss,scale in (('F_s_a',s,a),('F_s_b',s,b),('F_1_a',1.,a),('F_1_b',1.,b))}
    good=p*wg<=K*Q;A=T*delta;B=D*K0;U=np.where(good&(delta>0),np.minimum(A,B),0.)
    hard=np.array([all(abs(xq[j]-row[j])<=F(str(R))/2 for j in range(n)) for row in posq])
    out=dict(n=n,xq=[fstr(v) for v in xq],yq=[fstr(v) for v in yq],positions=[[fstr(v) for v in row] for row in posq],
                s=s,L=L,R=R,a=a,b=b,K=K,D=D,cj=cj,ell=ell,g=g,zg=zg,h=h,tau=tau,T=T,Hhat=H,Lplus=Lp,
                p=p,C=C,wg=wg,delta=delta,A=A,B=B,U=U,good=good,hard=hard,K0=K0,K1=K1,K2=K2,J=J,Q=Q,
                D_b=float(sum((max(abs(xq[j]-yq[j])-F(1,2),F(0)) for j in range(n)),F(0))),
                m_b=sum(abs(xq[j]-yq[j])>F(1,2) for j in range(n)))
    out.update(future);return out


def common_readback(g,nu,q,lam,v,u):
    j=float(g['J']@nu);eg=float(g['wg']@nu);alpha=(g['D']*q-float(g['U']@nu))/j
    rho=np.where(g['good']&(g['A']>0),np.maximum(1-(g['B']+alpha*g['J'])/np.where(g['A']>0,g['A'],1),0.),0.)
    N=(g['A'][v]-g['B'][v])*j-g['J'][v]*(g['D']*q-float(g['U']@nu))
    # A fixed time point in the original [.5,min(h,g)] interval, retaining all
    # sources. New Psi/history and whole-window qualification are not assumed.
    xis=sorted(set([.5,min(g['h'],g['zg'])]+[float(c) for c in g['C'].ravel() if .5<float(c)<min(g['h'],g['zg'])]))
    times=[]
    for lo,hi in zip(xis[:-1],xis[1:]):
        if hi<=lo:continue
        t=math.sqrt(lo*hi);wt=np.prod(np.minimum(1.,g['C']/t),axis=1);ks=np.sum(g['C']<t,axis=1);de=max(int(ks[v]-ks[u]),0)
        if de<=0:continue
        et=float(wt@nu);pi=wt*nu/et;dv=max(1-g['B'][v]/g['A'][v],0.)
        c=g['B'][u]*g['J'][v]*et/(g['A'][v]*j*wt[u]*de)
        times.append(dict(lo=lo,hi=hi,xi=t,k_v=int(ks[v]),k_u=int(ks[u]),delta=de,Pi=pi.tolist(),
                          lowc_ratio=c/((4*(g['n']+1)**2/(3*g['n']))*dv*dv),
                          positive_score_density=float(rho[v])*g['J'][v]/(3*g['Q'][v])*de*float(pi[v]*pi[u]),
                          FA_ratio_with_legacy_n4_BFA=None))
    eta=kt.ETA;s0=.25;epsilon=s0*eta;alpha_decay=.75*epsilon;Tc=math.log(80*math.e/alpha_decay)
    Lphi=2/(1-math.exp(-1));theta=Lphi+(16+8*math.exp(Lphi))/epsilon;dstar=g['n']*epsilon/(8*theta)
    return dict(nu=nu.tolist(),q=q,lambda_value=lam,QJ=j,eg=eg,alpha_same_source=alpha,rho=rho.tolist(),N_target=N,
                rho_from_N=N/(g['A'][v]*j),high_ratio=g['p']*eg/(2*g['K']*q),
                q_tests={name:float(g[name]@nu) for name in ('K0','K1','K2','J','Q','F_s_a','F_s_b','F_1_a','F_1_b')},
                q_over_tests={name:q/float(g[name]@nu) for name in ('K0','K1','K2','J','Q','F_s_a','F_s_b','F_1_a','F_1_b')},
                hard_nu_mass=float(g['hard']@nu),hard_density=float(g['hard']@nu)/g['R']**g['n'],
                lambda_lower_ratio=q/(.75*lam),lambda_upper_ratio=lam/q,
                hard_cap_ratio=float(g['hard']@nu)/(4*lam*g['R']**g['n']),
                geometry=dict(D_b=g['D_b'],m_b=g['m_b'],dstar=dstar,m0=math.floor(alpha_decay*g['n']/(4*Tc)),
                              exterior=g['D_b']>dstar,above_small_count=g['m_b']>math.floor(alpha_decay*g['n']/(4*Tc)),
                              FIRST_high_tail_not_certified=True),
                positive_time_point_checks=times)


def solve(g,v,u,lambda_fixed=None):
    N=len(g['wg']);qs=lambda_fixed if lambda_fixed else max(g['p']*float(max(g['wg']))/(2*g['K']),1e-100)
    # Variables nu[0:N], q/qs, lambda/qs, tau. All scales below have the same
    # units as their slack; tau itself is dimensionless.
    nr=N+3;rows=[];names=[]
    def add(name,nucoef,qcoef=0.,lcoef=0.,sigma=1.):
        vec=np.zeros(nr);vec[:N]=-np.array(nucoef)/sigma;vec[N]=-qcoef*qs/sigma;vec[N+1]=-lcoef*qs/sigma;vec[N+2]=1.
        rows.append(vec);names.append(name)
    for key in ('K0','K1','K2','J','Q','F_s_a','F_s_b','F_1_a','F_1_b'):add('q_ge_'+key,-g[key],1.,sigma=qs)
    add('high',g['p']*g['wg'],-2*g['K'],sigma=2*g['K']*qs)
    add('alpha_nonnegative',-g['U'],g['D'],sigma=g['D']*qs)
    add('lambda_lower',np.zeros(N),1.,-.75,sigma=qs)
    add('lambda_upper',np.zeros(N),-1.,1.,sigma=qs)
    add('hard_cap',-g['hard'].astype(float)/g['R']**g['n'],0.,4.,sigma=4*qs)
    add('heavy_terminal',g['wg'],-g['ell']*g['g']**g['n'],sigma=max(float(max(g['wg'])),1e-100))
    nv=(g['A'][v]-g['B'][v])*g['J']+g['J'][v]*g['U']
    add('rho_target_N_positive',nv,-g['J'][v]*g['D'],sigma=g['A'][v]*qs)
    for index,label in ((v,'good_mass'),(u,'bad_mass')):
        mc=np.zeros(N);mc[index]=1.
        scale=min(1.,qs/max(float(g[k][index]) for k in ('K0','K1','K2','J','Q','F_s_a','F_s_b','F_1_a','F_1_b')))
        add(label,mc,sigma=max(scale,1e-100))
    add('hard_positive',g['hard'].astype(float),sigma=min(1.,qs*g['R']**g['n']))
    eq=np.zeros((1,nr));eq[0,:N]=1.;bounds=[(0,None)]*N+[(0,None),(0,None),(0,1)]
    if lambda_fixed:bounds[N+1]=(lambda_fixed/qs,lambda_fixed/qs)
    cost=np.zeros(nr);cost[-1]=-1.
    result=linprog(cost,A_ub=np.array(rows),b_ub=np.zeros(len(rows)),A_eq=eq,b_eq=[1.],bounds=bounds,method='highs',
                   options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    relaxed=False
    if not result.success:
        bounds[-1]=(-1.,1.);relaxed=True
        result=linprog(cost,A_ub=np.array(rows),b_ub=np.zeros(len(rows)),A_eq=eq,b_eq=[1.],bounds=bounds,method='highs',
                       options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    out=dict(target_v=v,bad_u=u,solver_success=bool(result.success),message=result.message,relaxed_negative_margin=relaxed,
             lambda_mode='fixed original lambda' if lambda_fixed else 'independent common lambda with 3lambda/4<=q<=lambda',q_scale=qs)
    if result.success:
        xx=result.x;out['tau']=float(xx[-1]);out['strict_candidate']=bool(xx[-1]>1e-7 and not relaxed)
        slack=-np.array(rows)@xx+xx[-1]
        out['smallest_normalized_slacks']=sorted([dict(name=name,slack=float(z)) for name,z in zip(names,slack)],key=lambda x:x['slack'])[:8]
        out['solver_min_residual']=float(min(-np.array(rows)@xx))
        out['readback']=common_readback(g,xx[:N],float(xx[N]*qs),float(xx[N+1]*qs),v,u)
    return out


def geometry_json(g):
    keys=['n','xq','yq','positions','s','L','R','a','b','K','D','cj','ell','g','zg','h','tau','T','Hhat','Lplus','p','D_b','m_b']
    out={key:g[key] for key in keys}
    out.update({key:g[key].tolist() for key in ('C','wg','delta','A','B','U','good','hard','K0','K1','K2','J','Q','F_s_a','F_s_b','F_1_a','F_1_b')})
    return out


def run_case(label,stage,g,lambda_fixed=None):
    targets=[i for i in range(len(g['wg'])) if g['good'][i] and g['A'][i]>g['B'][i] and g['J'][i]>0]
    bad=[i for i in range(len(g['wg'])) if not g['good'][i]]
    results=[solve(g,v,u,lambda_fixed) for v in targets for u in bad]
    return dict(label=label,stage=stage,geometry=geometry_json(g),targets=targets,bad=bad,results=results,
                strict_candidate_count=sum(r.get('strict_candidate',False) for r in results))


def selected_rational(g,BFA):
    """Round one interior n4 candidate to simple exact masses; mp70 crosscheck."""
    nuF=[F(3,25),F(2749,3125),F(1,3125)];qF=F(9,2500);laF=F(11,2500)
    assert sum(nuF)==1
    read=common_readback(g,np.array([float(z) for z in nuF]),float(qF),float(laF),0,1)
    mp.mp.dps=70
    M=lambda x:mp.mpf(x.numerator)/x.denominator if isinstance(x,F) else mp.mpf(str(x))
    s,L,R=map(M,[F(1,4),F(9,10),F(1)]);n=4;ell=1+mp.log(n);gg=mp.sqrt(L*R);h=gg*mp.exp(-M('.01')/n)
    T=1/(gg**n*mp.sqrt(ell));H=max(M('.5'),min(M(1),gg*(1-s+s*old.phi_mp(M('.5')))*ell**(1/(2*n))))
    pos=[[M(F(x)) for x in row] for row in g['positions']];x=[M(F(z)) for z in g['xq']]
    cs=[[kt.mp_C(v) for v in row] for row in pos];weight=lambda t:[mp.fprod(min(1,c/t) for c in row) for row in cs]
    wg=weight(gg);Delta=[a-b for a,b in zip(weight(M('.5')),weight(h))];A=[T*d for d in Delta]
    p=old.kernel_mp(s,L,x);dx=[[x[j]-row[j] for j in range(n)] for row in pos]
    arrays={key:[old.kernel_mp(ss,scale,d) for d in dx] for key,ss,scale in [('K0',s,H),('K1',s,L),('K2',s,M(1)),('J',M(1),M(1))]}
    arrays.update({key:[old.kernel_mp(ss,scale,d) for d in dx] for key,ss,scale in [('F_s_a',s,M('.5')),('F_s_b',s,M(1)),('F_1_a',M(1),M('.5')),('F_1_b',M(1),M(1))]})
    arrays['Q']=[(arrays['K1'][i]+arrays['K2'][i]+arrays['J'][i])/3 for i in range(3)]
    good=[p*wg[i]<=arrays['Q'][i] for i in range(3)]
    U=[min(A[i],arrays['K0'][i]) if good[i] and Delta[i]>0 else M(0) for i in range(3)]
    nu=list(map(M,nuF));q=M(qF);la=M(laF);dot=lambda arr:mp.fsum(nu[i]*arr[i] for i in range(3))
    qj=dot(arrays['J']);eg=dot(wg);alpha=(q-dot(U))/qj
    rho=[max(1-(arrays['K0'][i]+alpha*arrays['J'][i])/A[i],M(0)) if good[i] and A[i]>0 else M(0) for i in range(3)]
    margins={key:q-dot(arr) for key,arr in arrays.items()}
    margins.update(high=p*eg-2*q,alpha_numerator=q-dot(U),lambda_lower=q-M('.75')*la,
                   lambda_upper=la-q,hard_cap=4*la-nu[2],heavy_terminal=eg-ell*gg**n*q)
    Nv=(A[0]-arrays['K0'][0])*qj-arrays['J'][0]*(q-dot(U));margins['rho_N']=Nv
    timechecks=[]
    for xiF in (F(51,100),F(13,25),F(53,100)):
        xi=M(xiF);wt=weight(xi);et=dot(wt);ks=[sum(c<xi for c in row) for row in cs];de=ks[0]-ks[1]
        dv=1-arrays['K0'][0]/A[0]
        c=arrays['K0'][1]*arrays['J'][0]*et/(A[0]*qj*wt[1]*de)
        timechecks.append(dict(xi_exact=fstr(xiF),k=ks,delta=de,lowc_ratio=mp.nstr(c/((M(25)/3)*dv**2),25),
                               FA_ratio=mp.nstr(M(BFA)*de*p*wt[0]/arrays['Q'][0],25),
                               positive_score_density=mp.nstr(rho[0]*arrays['J'][0]/(3*arrays['Q'][0])*de*(wt[0]*nu[0]/et)*(wt[1]*nu[1]/et),25)))
    boundaries=[abs(abs(float(F(z)))-g['L']/2) for z in g['xq']]
    for scale in (g['Hhat'],g['L'],g['Lplus'],g['R']):
        boundaries.extend(abs(abs(float(F(g['xq'][j]))-float(F(row[j])))-scale/2) for row in g['positions'] for j in range(n))
    future=[]
    nu_float=np.array([float(z) for z in nuF]);dx_float=np.array([[float(z) for z in row] for row in dx])
    for uu in np.linspace(.25,1.,16):
        for scale in np.linspace(.5,1.,21):
            test=float(old.kernel_np(float(uu),float(scale),dx_float)@nu_float)
            future.append(dict(s_future=float(uu),L_future=float(scale),kernel_nu=test,over_q=test/float(qF)))
    hard_thresholds=[2*max(abs(F(g['xq'][j])-F(row[j])) for j in range(n)) for row in g['positions']]
    legal_thresholds=[z for z in hard_thresholds if F(1,2)<=z<=F(1)]
    return dict(case_label='three_sources_n4_offset0.55',target_v=0,bad_u=1,hard_source=2,
                nu_exact=[fstr(z) for z in nuF],q_exact=fstr(qF),lambda_exact=fstr(laF),geometry=geometry_json(g),
                float_readback=read,mp70=dict(p=mp.nstr(p,30),T=mp.nstr(T,30),Hhat=mp.nstr(H,30),
                    C=[[mp.nstr(c,25) for c in row] for row in cs],Delta=[mp.nstr(d,25) for d in Delta],
                    alpha=mp.nstr(alpha,30),rho=[mp.nstr(r,25) for r in rho],
                    positive_weak_and_strict_margin_values={k:mp.nstr(z,25) for k,z in margins.items()},
                    all_listed_margins_positive=all(z>0 for z in margins.values()),
                    rho_from_N=mp.nstr(Nv/(A[0]*qj),30),time_checks=timechecks),
                min_kernel_hard_boundary_distance_float=min(boundaries),
                future_pressure_grid=dict(s_count=16,L_count=21,count=len(future),worst=max(future,key=lambda r:r['over_q']),
                                          exceedances=sum(r['over_q']>1 for r in future),scope='Fixed selected candidate only; finite necessary future tests, not the continuum FIRST contract.',
                                          hard_thresholds_2max_distance_exact=[fstr(z) for z in hard_thresholds],
                                          legal_hard_thresholds_exact=[fstr(z) for z in legal_thresholds],
                                          threshold_endpoint_checks='None: all source hard thresholds lie outside [a,b]; no extra grid run.'),
                unresolved='Necessary finite model only: no Psi/history/FIRST or L1-source realization, no certified dx volume. mp70 is not interval arithmetic.')


def main():
    previous_path=SOURCE_DIR/'middle_source_lp.json'
    previous=json.loads(previous_path.read_text()) if previous_path.exists() else None
    first_pass=previous.get('first_pass',previous) if previous else None
    template=next(x for x in json.loads(old.R136.read_text())['cases'] if x['id']=='I1')
    model=old.build(template,json.loads(old.R142.read_text())['cases']['I1'])
    points=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json')
    row=next(r for r in json.loads(points.read_text())['point_records']['8'] if r['after'] and r['I']>0)
    mapping=freeze(4,[F(x) for x in row['xq']],[F(3,10)]*4,model['positions'])
    nu=model['nu'];alpha=(row['q']-float(mapping['U']@nu))/float(mapping['J']@nu)
    rho=np.where(mapping['good']&(mapping['A']>0),np.maximum(1-(mapping['B']+alpha*mapping['J'])/np.where(mapping['A']>0,mapping['A'],1),0.),0.)
    check=dict(original_xq=row['xq'],max_wg_relative_error=float(max(abs(mapping['wg']/model['wg']-1))),
               max_Delta_relative_error=float(max(abs(mapping['delta']/model['A']-1))),
               alpha_error=abs(alpha-row['alpha']),rho_max_abs_error=float(max(abs(rho-np.array(row['rho'])))),
               h_vs_original_relative_error=abs(mapping['h']/float(old.Fq(template['derived']['h']))-1))
    assert check['alpha_error']<1e-12 and check['rho_max_abs_error']<1e-12
    cases=[]
    for x in ([F(-21,100)]+[F(3,10)]*3,[F(81,100)]+[F(3,10)]*3):
        cases.append(run_case('legacy_sources_exterior','initial',freeze(4,x,[F(3,10)]*4,model['positions']),model['lam']))
        cases.append(run_case('legacy_sources_common_lambda_free','initial',freeze(4,x,[F(3,10)]*4,model['positions'])))
    def geometry(n,s,L,core,overflow,offset,bad_offset):
        x=[F(str(.5+overflow))]+[F(str(core))]*(n-1);y=[F(0)]*n
        return freeze(n,x,y,[[z+F(str(offset)) for z in x],[-F(str(bad_offset))]*n,x],s,L)
    for n in (4,8):
        for offset in (.55,.6,.65):
            cases.append(run_case(f'three_sources_n{n}_offset{offset}','pressure',geometry(n,.25,.9,.4,.01,offset,.6)))
    for n,s,L,core in [(4,.5,.9,.4),(8,.5,.9,.4),(16,.25,.9,.4),(16,.5,.75,.3),(16,1.,.9,.4)]:
        cases.append(run_case(f'expanded_n{n}_s{s}_L{L}','expanded',geometry(n,s,L,core,.02,.6,.6)))
    candidates=[dict(case=i,result=j) for i,c in enumerate(cases) for j,r in enumerate(c['results']) if r.get('strict_candidate')]
    selectedg=geometry(4,.25,.9,.4,.01,.55,.6)
    selected=selected_rational(selectedg,old.Fq(template['parameters']['B_FA']))
    out=dict(scope='Finite necessary LP only: source masses and common q/lambda vary at fixed geometry. No original continuous L1/FIRST/history realization.',
             inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (DEP,Path(old.__file__),old.R136,old.R142,points)},
             solver=dict(name='SciPy linprog, method=highs',scipy=importlib.import_module('scipy').__version__,
                         import_note='Real linprog/HiGHS loaded directly to bypass unused broken local PROPACK/COBYLA umbrella imports.'),
             producer_mapping_check=check,cases=cases,candidate_indices=candidates,
             selected_rational_candidate_status='Refreshed rational point passes the added future tests and a finite 16x21 future-pressure grid; full FIRST remains uncertified.',
             selected_rational_candidate=selected,
             first_pass=first_pass,
             first_pass_rejection=dict(status='The historical rational candidate is strictly rejected by a legal future test.',
                                      test='u=s=.25,Lprime=a=.5; hard source located at x',
                                      hard_kernel_lower_exact='81/16',hard_nu_exact='327/100000',
                                      hard_contribution_lower_exact=fstr(F(81,16)*F(327,100000)),
                                      old_q_exact='37/10000',excess_lower_exact=fstr(F(81,16)*F(327,100000)-F(37,10000)),
                                      proof='phi>=0, so the center hard term alone gives the stated rational lower bound.'),
             summary=dict(case_count=len(cases),LP_count=sum(len(c['results']) for c in cases),strict_candidate_count=len(candidates),
                          no_target_cases=sum(not c['targets'] for c in cases),no_bad_cases=sum(not c['bad'] for c in cases)),
             limitations=['Finite floating LP and coefficient readback are not interval certificates.',
                          'The common q is not set to producer max, and lambda is not redefined as a max of reference tests.',
                          'A positive rho/score point is not a full Psi/FA/history or continuous dx/time traffic example.',
                          'The full FIRST high-tail exclusion and f,beta,nu source domination are not certified.',
                          'No original hard/time/j/beta budget is paid by this feasibility search.'])
    (HERE/'middle_source_lp.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(summary=out['summary'],mapping=check,candidate_indices=candidates),indent=2))


if __name__=='__main__':main()
