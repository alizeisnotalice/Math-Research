# R168：共同 future 尺度—软度比较支付中间域的新分支

状态：得到新的显式联合几何统计量及其真实 raw 体积价格，覆盖一部分旧中间域，包括 s=1 时单一 soft 倾斜完全退化的几何。未证明整个中间带付款，也未提供完整正交通输入的新增样本。证明全为解析；未作数值实验、未 Git、未 spawn，仅写本文件。

读取范围：R168 task_contract；R167 proof.tex.txt 的共同 FIRST／剩余定义及 capped-rate；R167 exterior_geometry.tex.txt 的 m0；R166 exact_window_geometry/raw_audit 中已审 log phi 全局常数。未重推或优化旧单 soft 率函数。

## 1. 命题量词：共同测试必须先于来源选择

固定原 receiver x，原当前参数为 s=s(x)∈[s0,1]、L=L(x)∈[a,b]，s0>0，b/a≤2。共同原输入满足

\[
 P_{s,L}f(x)=q,\qquad P_{u,t}f(x)\le q
 \quad(s\le u\le1,\ a\le t\le b).
 \tag{1}
\]

本文用 t 表示测试物理尺度，**不是原交通的时间参数**；原时间积分仍写 dξ/ξ。对逐种子原叶来源先合并

\[
 \bar\beta_\omega=\sum_V\beta_V\le f(y)dy.
 \tag{2}
\]

每个测试 (u,t) 在同一 receiver 的整个 y 积分中固定。允许测试菜单依 x 的原 s,L 构造，不允许为每个 y 免费选择最佳测试。

同一来源的明确统计量为

\[
 d_i=|x_i-y_i|,\quad
 m=\#\{i:d_i>b/2\},\quad
 S_b=\sum_{d_i>b/2}d_i=bm/2+D_b,
\]
\[
 T=\sum_i d_i,\qquad
 J_t=\#\{i:t/2<d_i\le L/2\}\quad(t\le L).
 \tag{3}
\]

J_t 计数缩尺度时真正跨过原硬支撑的坐标，不能删去。置

\[
 a_\phi=\phi(1/2),\quad c=1-a_\phi,\quad
 L_\phi=\frac2{1-e^{-1}},\quad
 \ell(u)=\log\frac{1-cu}{u a_\phi}\ge0,
\]
\[
 \mathcal A(m;u,s)
 =m\log\frac us+(n-m)\log\frac{1-cu}{1-cs}.
 \tag{4}
\]

u=1 时 ell(1)=0；s=u=1 时 A=0。s≥s0 保证这些表达式有限，但不把 ell(s0) 藏入常数。

## 2. 初步：逐坐标核比较，保留方向和硬边界

### 2.1 两条已有/自证的一维事实

R166 已审的全局 log phi 控制为

\[
 \phi(r')\ge e^{-L_\phi|r'-r|}\phi(r).
 \tag{5}
\]

还需要尾部的反方向增长下界。对 z≥1/2，直接卷积积分给

\[
 \phi(z)=\int_0^1 v(1-e^{-1/v})e^{-(z-1/2)/v}dv.
\]

故 z2≥z1≥1/2 时，逐 v 比较得到

\[
 \phi(z_1)\ge e^{z_2-z_1}\phi(z_2).
 \tag{6}
\]

(6) 不涉及边界二阶导数或交换极限。

同一尺度 L 的合法 soft 比较保留 R167 的逐坐标证明：在 d_i>b/2≥L/2 上比值为 u/s；其它坐标至少为 (1-cu)/(1-cs)，因为硬支撑内 phi≥a_phi，硬支撑外 u/s≥1。因此

\[
 \frac{P_{u,L}(x-y)}{P_{s,L}(x-y)}
 \ge e^{\mathcal A(m;u,s)}.
 \tag{7}
\]

下文使用 (7) 与**新的尺度比较**相乘，而不是仅重做其 capped 共轭。

### 2.2 扩尺度 t≥L

对 d_i>b/2≥t/2，两次标准化位置都在 phi 尾部，(6) 给

\[
 \frac{t^{-1}f_u(d_i/t)}{L^{-1}f_u(d_i/L)}
 \ge\frac Lt\exp[(L^{-1}-t^{-1})d_i].
\]

其他坐标只用 f_u 偶单峰，得到比值≥L/t，包括新增硬支撑和闭面。乘积并结合 (7)：

\[
 \boxed{\log\frac{P_{u,t}(x-y)}{P_{s,L}(x-y)}
 \ge B_+(x,y;u,t):=
 n\log\frac Lt+(L^{-1}-t^{-1})S_b+
 \mathcal A(m;u,s),\quad L\le t\le b.}
 \tag{8}
\]

物理归一化 n log(L/t) 是负成本，不能省略。该式保留 m 与 overflow 的同源联合关系 S_b=bm/2+D_b。

### 2.3 缩尺度 t≤L

若 d_i≤t/2，两个位置都在硬支撑内，由 (5) 及常数硬项可得

\[
 f_u(d_i/t)/f_u(d_i/L)
 \ge\exp[-L_\phi(t^{-1}-L^{-1})d_i].
\]

若 d_i>L/2，两个位置都在软尾，相同比较直接来自 (5)。剩下跨界坐标 t/2<d_i≤L/2，则

\[
 \frac{f_u(d_i/t)}{f_u(d_i/L)}
 \ge e^{-L_\phi(t^{-1}-L^{-1})d_i}
 \frac{u\phi(d_i/L)}{1-u+u\phi(d_i/L)}
 \ge e^{-L_\phi(t^{-1}-L^{-1})d_i-\ell(u)}.
\]

因为 phi(d_i/L)≥a_phi，最后一个分式至少为 u a_phi/(1-cu)。缩尺度边界 d_i=t/2 不跨界；原边界 d_i=L/2 仍有硬项且在 t<L 时确实跨界，正好对应 (3)。因此

\[
 \boxed{\log\frac{P_{u,t}(x-y)}{P_{s,L}(x-y)}
 \ge B_-(x,y;u,t):=
 n\log\frac Lt-L_\phi(t^{-1}-L^{-1})T
 -J_t\ell(u)+\mathcal A(m;u,s),\quad a\le t\le L.}
 \tag{9}
\]

这是源于真实尺度变化的增益 n log(L/t)，由总距离 T 与真实跨界数 J_t 结算。没有独立 Bernoulli 假设，也没有 free mask。

## 3. 已有压力：具体能力和端点，不能推广什么

取 u=s，(8) 的尺度项非平凡当 S_b/L 足够大。写 z=1-L/t∈[0,1-L/b]，其值为

\[
 zS_b/L+n\log(1-z).
 \tag{10}
\]

若 S_b≤nL，则所有此类扩尺度下界≤0；因此它不能仅凭 m>m0 或 D_b>d* 覆盖整个中间域。当前 L=b 时扩尺度菜单退化为空增益。

取 u=s，(9) 精确保留 ell(s) 的跨界成本；只有 T 和 J_t 同时足够小才有正 gain。可使用显式帽

\[
 \ell(s)\le\ell(s_0)
 =\log[(1-cs_0)/(s_0a_\phi)],
 \tag{11}
\]

但这会损失该下门的实际费用。取 u=1 可消掉跨界成本，却必须支付 A(m;1,s)；少量外坐标、低 soft 时，该 soft 成本可能为负，不能删除。

当前 L=a 时没有缩尺度增益；a=b 时两条公式都退回同尺度 soft 比较。s=1 时 A=ell=0，但 (8)–(9) 的尺度收益仍存在，**不受旧 soft 倾斜 tau_max=0 的限制**。这恰是新工具相对于旧 capped-rate 的不同信息。

## 4. 扩大：付清全部连续合法测试菜单

### 4.1 已证的逐节点方案（保留核验，不作最终最优费用）

令 B(x,y;u,t) 按 t≥L 使用 (8)、t≤L 使用 (9)，在 t=L 二者相等；定义可计算的有限维统计量

\[
 B_*(x,y)=\sup_{s\le u\le1,\ a\le t\le b}B(x,y;u,t).
 \tag{12}
\]

其内容完全由 m、S_b、T 和 J_t 给定，不是一个新命名的未知核范数。J_t 随 t 只在有限个 2d_i 处改变；各段的其余表达式连续，闭面方向如上。因此 B_* 可由含端点的 countable dense 参数和右逼近表示，是可测统计量。

(12) 的逐来源选择本身**不**是一项合法 FIRST 测试。以下明确支付其菜单费用。

物理节点取 \(t_k=\min(b,a e^{k/n})\)，含 b；节点数

\[
 N_L\le\lceil n\log(b/a)\rceil+1\le n+2.
\]

对当前 receiver 的实际 s，soft 节点取 \(u_h=s e^{h/n}\le1\)，h从0到floor(n log(1/s))；s=1 时只含1。节点数

\[
 N_s(x)\le1+n\log(1/s),\qquad
 N_s(x)\le1+n\log(1/s_0).
\]

每个测试 t 向上舍入到 t_k，每个 u 向下舍入到 u_h≥s。由 f_u 单峰及 f_u≤(u/u_h)f_{u_h}，

\[
 P_{u,t}(x-y)\le e^2P_{u_h,t_k}(x-y).
 \tag{13}
\]

这里两个 e 分别是 t^{-n} 的物理归一化及 soft 的 n 维倍率。所有节点仍在**原同一 receiver 的** future 域内，不改变当前选择器，也不依 y 构造菜单。覆盖节点不必保持与原 t 同属扩／缩分段，因为 (13) 比较的是完整原核。

结合 (8)–(9) 和 (13)，若 B_*≥H，则某个节点核比至少 e^{H-2}。对各节点先用同一 (1)–(2)，再作有限并集，得到

\[
 \boxed{\frac1q\int_{\{B_*(x,y)\ge H\}}
 P_{s,L}(x-y)d\bar\beta_\omega(y)
 \le N_0 e^{2-H},\quad
 N_0=(n+2)[1+n\log(1/s_0)].}
 \tag{14}
\]

这是真正的二维连续菜单价格。固定 receiver 菜单时，每个 FIRST 测试仍先对全部来源积分；逐来源最优选择仅通过菜单并集付费。对 n≥1，N0=O(n²[1+log(1/s0)])；其 log 费用进入尾阈值，不能称免费 supremum。若仅使用 M 个预先指定的合法测试，可直接将 (14) 换成 M e^{-H}，无 e² 舍入损失。

### 4.2 主代理提出并独核的升级：future 正平均菜单

下列升级由主代理在本轮提出，本责任代理逐项独核。它直接针对未取凹幂的原 P，**不**适用于此前 direct 混合幂逐 mask 免费相加。

固定当前 s∈[0,1] 和一个测试尺度 t，写 u=s+(1−s)z，z∈[0,1]。逐坐标有 f_u=(1−z)f_s+zφ，因而完整产品可写为

\[
 P_{u,t}(x-y)=\sum_{S\subset[n]}A_S(x,y;t)
 z^{|S|}(1-z)^{n-|S|},\qquad A_S\ge0.
\]

对 k=0,…,n，由二项总和为1有

\[
 \sup_{0\le z\le1}z^k(1-z)^{n-k}
 \le\binom nk^{-1}
 =(n+1)\int_0^1z^k(1-z)^{n-k}dz.
\]

其中 beta 多项式积分可由分部积分 k 次直接验证为k!(n−k)!/(n+1)!，无须外部定理。先对每个非负 A_S 使用此式再求和，得到

\[
 \sup_{s\le u\le1}P_{u,t}(x-y)
 \le(n+1)\int_0^1P_{s+(1-s)z,t}(x-y)dz.
 \tag{14a}
\]

全部2^n项由正恒等式精确求和，没有遗失mask费用。s=1时参数平均退化为同一核，上式依然成立；s=0也成立。

沿原物理向上网格只损失e，故先对叶来源合并、再 Tonelli 和同一完整FIRST，得

\[
 \int\sup_{s\le u\le1,\ a\le t\le b}P_{u,t}(x-y)
 d\bar\beta_\omega(y)
 \le eN_L(n+1)q\le eN_1q,
 \quad N_1=(n+1)(n+2).
 \tag{14b}
\]

每个 z,t节点都属于同一receiver原future，未按y选择测试来使用FIRST。正平均已经在其之前固定；source supremum通过(14a)的确切费用支付。

因此(14)升级为

\[
 \boxed{\frac1q\int_{\{B_*\ge H\}}p_x(y)d\bar\beta_\omega(y)
 \le N_1e^{1-H}.}
 \tag{14c}
\]

菜单费用不再含s0；B_*的几何公式仍在s>0上定义，当前任务s≥s0>0无需另延拓。虽然(14b)本身对s=0有效，不能把含log(u/s)的B公式直接代s=0。下文最终raw用升级(14c)，不叠加旧(14)的费用。

## 5. 新分支的原 raw 回代与明确费用

令 B_rem 是 R167 所有已付分支的**真实补集**。只取

\[
 \mathcal A_H(x,y)=B_{\rm rem}\,
 1_{\{s(x)\ge s_0\}}1_{\{B_*(x,y)\ge H\}}.
 \tag{15}
\]

B_* 只依 x,y 及原参数，不依外硬 z 或内 v,u。保留 (15) 后，上放原 [0,1] 门；rho 使用原共同 alpha，仅上放至1。一次 hard 帽给16/3，chi_J≤1，原 δ≤n，固定时间的Π²质量≤1，时间长度≤log2，标签数安全帽n+2。

沿 R167 已核的同一回代，**先**合并 ΣVβV≤fdy再用升级 (14c)，得

\[
 \boxed{\operatorname{raw}(\mathcal A_H)
 \le C_{\rm vol}n(n+2)N_1e^{1-H}\,q|\mathcal E|,
 \qquad C_{\rm vol}=\frac{32\Lambda}{3}\log2.}
 \tag{16}
\]

没有重新领取 j 的唯一性折扣，没有第二次 hard 帽，没有给每个叶重领一个 q。Π支持、same-alpha、资格和history保持原值；上放只是对同一非负原量的合法估计。

给定0<ζ<1，选

\[
 \boxed{H=1+\log\frac{n(n+2)N_1}{\zeta}.}
 \tag{17}
\]

于是新分支价格为

\[
 \operatorname{raw}(\mathcal A_H)
 \le C_{\rm vol}\zeta q|\mathcal E|.
 \tag{18}
\]

仅在主文另有 \(q|\mathcal E|\le X\) 时，才可写成 CvolζX。该结论是可吸收的 receiver 体积价格，非 Wβ column 上界。菜单 N1=(n+1)(n+2)、原 score n、标签n+2都已计入；阈值为O(log n+log(1/ζ))，不含s0菜单费用。B_- 本身的 ell(s0)几何成本仍须保留。

## 6. 解析几何覆盖检查：确有旧中间域的新部分

不造有限 FIRST producer，也不称下面为实现全部门的正交通输入。这里只用一族明确的来源—receiver 几何，检验新筛选与旧三分支的集合关系。

取 n为20的正整数倍，a=b/2、原L=b；先取任意原s∈[max(s0,1/2),1]。恰m=n/20个坐标满足 d_i=b，其余d_i=0。则

\[
 m=n/20,\quad T=bn/20,\quad D_b=bn/40.
 \tag{19}
\]

R167 的 \(\varepsilon=s_0\eta\le1\)、\(\alpha=3\varepsilon/4\le3/4\)、\(T_\varepsilon=\log(80e/\alpha)>5\)，所以

\[
 m_0/n\le\alpha/(4T_\varepsilon)<3/80<1/20.
\]

又theta≥16/ε，故 \(d_*/(bn)=\varepsilon/(8\theta)\le1/128<1/40\)。因此此几何严格在 U与稀疏S之外。另有 φ(1/2)=∫_0^1v(1−e^{-1/v})dv≤1/2，故 c≥1/2，所取s给cs≥1/4>m/n=1/20。旧capped-rate因此为0，也不落任何正阈值的旧FIRST高尾。这包括严格s<1的整个区间；s0=1时只保留端点参照。

现在使用单个原合法测试 u=s、t=a=b/2。此处J_t=0且A(m;s,s)=0，(9) 给

\[
 B_-\ge n\log2-L_\phi n/20
 >n(\log2-1/5)>0.
 \tag{20}
\]

最后使用 \(L_\phi<4\)，因为1−e^{-1}>1/2。只要n满足 \(n(\log2-1/5)\ge H\)，该几何就在新的可付款筛选里。也可直接使用这一单测试，阈值仅为log[n(n+2)/ζ]，无需全菜单N1。

这些都是严格不等式；对坐标作足够小扰动仍成立，故不是仅零厚度配置。它证明新统计量具有旧几何门和旧capped-rate没有覆盖的区域；**不证明这些几何在某个完整原f下实际携带正交通**。如果它们存在，(16)–(18) 已经对同一原交通支付其来源量，无需另作FULL模型假设。

## 7. 尚未覆盖的范围与停止结论

新成功是 (8)–(9) 的逐坐标尺度证书、升级(14c)付清连续菜单后的共同FIRST预算，以及 (16)–(18) 对原中间域新增分支的真实回代。其来源统计量同时记录计数、overflow、总距离和硬边界跨越；没有假设mask与score独立。

一般剩余仍包括 B_*<H 的中间域。扩尺度可能因S_b≤nL无收益；缩尺度可能因T或J_t过大无收益；端点L=a或b各失去一个方向。两方向并不保证拼满整个中间带，尤其不能从测试族覆盖参数矩形就推断来源几何被覆盖。s=1虽不再自动阻断新尺度支，也没有因此被全部解决。

(19)–(20)是解析集合覆盖证据，不是有限数值猜阶，也不是FULL实例。没有执行数值三阶段，因为本任务无需数值探路：初步为核比证明，压力为(10)–(11)的无收益范围，扩大为全部连续菜单、原raw及新的中间域几何。交付至此停止。
