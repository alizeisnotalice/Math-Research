# R168 双方向联合 FIRST 核比较的有限独立检验

## 1. 对象、公式与等级

先向作者 r166_scale_budget 询问并收到最终逐坐标公式确认，之后才实现；未依赖本轮审计结论来认证定理。本任务只是独立数值核对给定下界，另对特定几何族给出初等代入证明。没有搜索来源质量，没有把 mp 当区间证书，也没有认证 FULL/history。

记一维核

\[
k_{s,L}(d)=L^{-1}[(1-s)1_{d\le L/2}+s\phi(d/L)],\quad d\ge0,
\quad a_0=\phi(1/2),\ c=1-a_0,\ L_\phi=2/(1-e^{-1}).
\]

取 s≤u≤1。逐坐标 soft 项为

\[
A_i=\begin{cases}\log(u/s),&d_i>b/2,\\
\log[(1-cu)/(1-cs)],&d_i\le b/2.
\end{cases}
\]

所以 n 维 soft 总式准确为

\[
A=m_b\log(u/s)+(n-m_b)\log[(1-cu)/(1-cs)].
\]

确认的扩方向 L′≥L 下界是

\[
B_+=n\log(L/L')+(1/L-1/L')\sum_{d_i>b/2}d_i+A.
\]

缩方向 L′≤L 的下界为

\[
B_-=n\log(L/L')-L_\phi(1/L'-1/L)\sum_i d_i
-J\log\frac{1-cu}{u a_0}+A,
\quad J=\#\{i:L'/2<d_i\le L/2\}.
\]

扩方向仅给 b-core 外坐标加正尺度差，其余坐标的该奖励置零；缩方向保留完整 Lφ 距离损失和 cross-hard penalty。二者目标都是

\[
\log\frac{P_{u,L'}(x-y)}{P_{s,L}(x-y)}\ge B_\pm.
\]

硬指示与 cross-hard 判定用精确 Fraction，因此 d=L/2 或 L′/2 的端点没有被 float 偷换。

## 2. 三阶段菜单与结果

固定 b=1，s∈{.001,.25,.75,1}，u∈{s,(1+s)/2,1}（去重），L,L′∈{.5,.75,1}。

| 阶段 | d 节点 | 比较数 | 最小 float slack |
|---|---|---:|---:|
| 初步 | 0,.25,1 | 270 | −3.06e−16 |
| 已有压力 | L/2、L′/2、b/2，各取精确点及两侧±10^−9，去重 | 570 | −2.23e−16 |
| 扩大 | 4,16 | 180 | −3.34e−15 |

合计 **1020** 例，slack 指真实 φ 数值核的 log ratio 减公式下界。没有 slack<−10^−11 的样例；最大 slack≈33.9808822161。阈值10^−11只是本有限浮点检查的报警线，不是数学容许误差。

最小负 slack 出现在等尺度 L=L′=.5、s=.25,u=1,d=16；这时真实比值恰为 u/s=4，下界也为 log4，负值来自对两个小核先取 log 再相减的消去误差。mp80 给出的 slack≈1.90e−80，与精确等号一致。

选取六个有界压力样例作 mp80 交叉核对：全局最小 slack、扩方向外坐标最紧、缩方向 crossing 最紧、最大 crossing penalty、最大绝对下界、最大 slack。最大 float/mp80 差为：

- 真实 log ratio：4.361e−15；
- 公式 lower log ratio：4.034e−15。

例如扩方向外坐标最紧样例的 mp slack≈.15107175，缩方向 crossing 最紧≈.20729846，s=.001 最大 crossing penalty 样例 slack≈.52722541。这些样例含硬边界两侧、很小 soft、远尾和 s=1 端点。全部参数、分项、slack 与高精输出见 JSON；mp未提供严格区间误差，所以数值扫描本身不证明全参数命题。

## 3. 旧几何之外的新几何族

取 n∈{20,100,1000}，m=n/20，a=.5,b=L=R=1,L′=.5；m 个坐标 d_i=1，其余为0。核对三组 future soft：(s,u)=(1,1)、(.99,1)、(.99,.99)，并令 s0=s。几何没有 hard crossing，故J=0。

旧 R167 阈值为

\[
\varepsilon=s_0\eta,\quad\theta=L_\phi+(16+8e^{L_\phi})/\varepsilon,
\quad d_*=n\varepsilon/(8\theta),
\quad m_0=\left\lfloor\frac{(3\varepsilon/4)n}{4\log(80e/(3\varepsilon/4))}\right\rfloor.
\]

此族严格有 D=m/2=n/40。利用已知0<η<1：θ≥16/ε，所以d*/n<1/128<1/40。又α=3ε/4<3/4、log(80e/α)>4，故m0<3n/64<n/20=m。因此 **D>d*、m>m0**，不是旧 U 或 small-m 分支的重复。此结论不靠 η 的数值小数。

旧受限 FIRST 尾在该层仍为0：φ(.5)<1/2，从而 c>1/2；对s=.99有 cs>.495>m/n=.05，故旧率函数 I_s(.05)=0；s=1时整个 I_1≡0。最大旧尾指数 nlog(1/s) 在s=.99时仅约 .01005034n，与这里新B为不同几何信息。**这只是此族的率函数状态，不声称所有 strict-soft 中间带旧率都为0。**

若u=s，新B为

\[
B=n(\log2-L_\phi/20)\approx.534949509873n.
\]

若s=.99,u=1，另外保留 soft 项，B≈.520726987778n。

这些 B 的正性还可以初等严格代入：由凸函数1/t的中点下界，log2>2/3；e>2给Lφ<4。因此u=s时B>7n/15。另一方面

\[
a_0=\int_0^1a(1-e^{-1/a})\,da>3/16,
\]

所以s=.99,u=1的core soft损失不超过n·.01c/a0<4n/75（使用log(1+t)≤t；外坐标正soft可丢）。故该组 **B>31n/75>0**，无需把 float 结果充作证明。

## 4. B>0 与完整 H 门分开

作者确认主菜单费用门为

\[
N_1=(n+1)(n+2),\qquad H=1+\log\frac{n(n+2)N_1}{\zeta}.
\]

这里明确选择 ζ=.01。此选择仅对应作者分支的体积价格

\[
C_{vol}\zeta q|E|,
\qquad C_{vol}=\frac{32\Lambda}{3}\log2,
\quad C_{vol}\zeta\approx.0739357\Lambda.
\]

它没有自动满足某个未指定的ε_abs吸收目标；若要求ε_abs X且q|E|≤X，还须ζ≤ε_abs/Cvol。

| n | m | H(ζ=.01) | B(s=u=1 或 s=u=.99) | B(s=.99,u=1) | 完整H门 |
|---:|---:|---:|---:|---:|---|
| 20 | 1 | 17.82751 | 10.69899 | 10.41454 | 两组均未过 |
| 100 | 5 | 24.07541 | 53.49495 | 52.07270 | 两组均通过 |
| 1000 | 50 | 33.24119 | 534.94951 | 520.72699 | 两组均通过 |

该 H 比较也可不用特殊函数数值误差：n=20时，log2<3/4（凸函数梯形上界），B<15+1/99<16；而n(n+2)N1/ζ=20328000>3^15，e<3给H>16，所以未过。n=100、1000时，令该整数为M_n，精确有理比较给

\[
(8/3)^{25}>M_{100}=10508040000,
\quad(8/3)^{35}>M_{1000}=100500800400000.
\]

e>8/3，故H100<26、H1000<36；前述最小B>31n/75已经分别大于26、36。这使表中 H 门判定具有初等严格余量，而非仅浮点标签。

JSON另保留单预指定测试门H_fixed=log[n(n+2)/ζ]，但不能拿它替换主菜单H。尤其n20的B>0并不意味着主菜单付款门成立。

## 5. 复现与停止点

复现使用已有含numpy/scipy/mpmath的本机runtime，不安装依赖：

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/168/work/joint_first_probe.py
```

脚本读取 R165 `hard_overlap_check.py` 所带旧数值工具，输入SHA-256为`beacc1f51d10803b19a3c489839c022a95ceb76ac81094a8790eb4a83d9a785f`；其直接依赖R151 `receiver_probe.py` 的SHA-256为`24ef92aaeaca8b6c110e899f61c2b5a5dfe558f6235534c5c1d144bab8e1bba0`；两项完整哈希均记录在JSON。原始φ核为E3公式，mp80独立用expint。脚本只写自己的JSON，1020例与六个mp样例均已完成，核心运行约0.06秒（不含导入开销）。未新增来源搜索、未改他人文件。

这里的成功是：给定双方向公式在指定有界菜单没有发现超出浮点误差的违例，并给出旧几何/旧率之外、达到明确H费用门的strict-soft解析几何族。没有原来源与same-α/high/low-c候选构造，没有完整FIRST或L1实现，不是FULL正交通证书。完成本有界检验后停止；另派的LP候选按原职责单独核验。
