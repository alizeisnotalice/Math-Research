# R168：中间计数带的联合几何预算

起点93e5c72（R167已推送）。R167冻结证据：/Users/zhengzhihao/Desktop/T/output/centered_cube_round167_20261016_final_checkpoint；R166 source_contract.md在对应round166_20261015_final_checkpoint。只读必要片段，不通读全部历史。所有人共享本轮目录，不改他人文件，不Git，不自行spawn，完成交付即停。

目标仍任意正L1一般一致sqrt(n)n^o(1)上界。当前中间域：原正交通中 s≥s0、D_b>d*、m_b>m0且不在已付FIRST高尾。s0费用不能隐藏。D_b=Σ(|x_i-y_i|−b/2)+，m_b=#外坐标。R167 U和S分支可付C(s0,K,Λ)√nWβ；高m按共同FIRST有受限MGF和ζq|E|费用；没有中间覆盖。完整定义见R167 task_contract.md及proof.tex.txt。

原来源：νV≤βV≤f dx，ΣVβV≤f dx。当前q是共同FIRST水平，P_s,L f=q、所有future s'≥s,L'∈[a,b]≤q；hR f≤4λ，q≥3λ/4。固定ω,V,j,y,t后Πt不依x,z，其他终端门仍依x。不得把有限producer三测试max当完整FIRST。

raw正量 2Λ EΣVj ∫ q^-1 p hR aω ρv χJv δ(v,u) Πt² dt/t dx dβ(y)dν(z)。good pwg(v)≤KQv，bad反向；Q=(K1+K2+J)/3；同一个α由αQJ=Dq−∫Uν决定，U=1good min(TΔ,DK0)，ρ=[1−(DK0+αJ)/(TΔ)]+。δ=(kv−ku)+；high peg≥2Kq。hard帽16/3只一次，j≤n+2、时间≤log2、外质量Wβ全部保留。R167 ER7–9可用：∫bad(K0/wt)dΠt≤αp/(2DK)，但无下门不能去掉κ权重。R144高κ付款不重报。

已知压力：CS分离直接窗丢指数；I1全部正接收在b-core，冻结I1满足3Kλ/(2eg)>s/L^n，故加密其外网格无益。I1分数核全空间积分约1.13878仅有限压力，不是一般反例。mask不等于δ，二项率函数倾斜端点有限，高soft退化。目标是新联合几何估计/真实可付分支/改变决策的数值，不重复归约或余项改名。

每项交付：准确命题、定义、证明或具体缺口、真实费用、有效范围；数值须初步/压力/扩大三阶段，保留输入及误差。审计先独立命题筛查，之后读作者证明。L1连续模型和有限必要模型严格分开。本轮最多使用既有8人，不编译PDF。主代理负责整合和最终提交。
