# R168 中间带独立量词检查点

状态：已读 R168 `task_contract.md`、R167 `proof.tex.txt` 的 FIRST/来源/高尾价格必要片段，以及 R166 冻结 `source_contract.md` 的 SC1–SC5、SC6 与 j/time 定义必要段。**尚未读取本轮任何作者稿。** 只写本文件，不 Git，不改他人、不 spawn。以下是可合法使用的比较与不可省条件，不登记新的中间带付款。

## 1. 共同 FIRST 的准确容量单位

固定同一实际 receiver x、种子 omega 和共同 FIRST 水平 q。对一个在该 x 合法的共同 future 测试 T=P_{s',H}，s'≥s(x)、H∈[a,b]，原来源合同给

    ∑_V∫T(x−y)β_V(dy)
      =∫T(x−y)(∑_Vβ_V)(dy)
      ≤Tf(x)≤q.

这是一个测试在完整共同输入上的一次容量。V/来源 y 可以按非负可测子域限制而使左侧减小，但不能每个 V、每个 y、每个 history 各自选择不同测试后分别调用 q，再把这些 q 无费相加。测试必须在被积分来源槽上保持共同。

对有限共同菜单 T_1,...,T_N，每个都在同一 x 合法，允许来源点选择标签 r(y,V)，但安全合计是

    ∑_V∫T_{r(y,V)}(x−y)β_V(dy)≤∑_{r=1}^N T_rf(x)≤Nq.

这只给带真实 N 费的容量，并不证明未知 selector 具有免费单测试预算。β≤f 是测度包含，不是 β 的概率化；外质量仍为原 W_beta。

## 2. 连续 future 参数的一种合法有限菜单比较

本节仅作逐 receiver 的 FIRST 容量比较，不是把自适应核移出 dx 的固定参数 column 证明。

固定该 x 的实际 s=s(x)>0。对任意 future u∈[s,1]，以 **当前 s 为锚** 取 sigma_k=s exp(k/n)，向下舍入满足 sigma≤u<e^(1/n)sigma。所有 sigma≥当前 s，因此都是合法 future。系数比较给 f_u≤e^(1/n)f_sigma，整个 n 维产品至多 e；菜单数 N_s≤1+nlog(1/s)。

H∈[a,b] 向上取相邻比≤e^(1/n)的网格，包含 b。偶递减性给 P_{sigma,H}≤eP_{sigma,H'}，N_H≤n+2。因此任意来源点选取的 future 参数都可被同一个菜单和支配，费用安全为 e²N_sN_H q。

若 s≥s0，可把菜单数上放为 [1+nlog(1/s0)](n+2)。**但不能直接把 soft 网格锚到 s0 再向下舍入，从而选到小于当前 s(x) 的 sigma；这种节点不受本行 future FIRST 控制。** 可用上述 current-anchored 菜单，或另证一个始终合法的共享覆盖。

这些菜单可以在逐 x 的 FIRST 估计中依该 receiver 选择，只要对当次所有来源相同且数量统一；若随后要固定节点并积分 x、领取 W_beta column 价格，还必须另付其 receiver 适应性或构造真正固定的包络。Nq 体积价格与 W_beta 来源价格不能互换。

## 3. high 对 e_g/q 的方向及合法一元比较

原 high p e_g≥2Kq 在 p>0 的非零交通行上给

    e_g/q≥2K/p,    q/e_g≤p/(2K),    1/e_g≤p/(2Kq).

它提供 e_g 的下界或逆分母上界，**不提供 e_g/q 的局部上帽**。用其消一个分母时，增加的 p/q 等因子须完整保留，不能把剩余量直接叫作容量已付。

可用 full FIRST 建立点态的 e_g/q 上比较，但必须把 w_g 与同一 x 上的合法测试核真实比较。一个准确但粗的示例为：令 c_phi=(1−e^(−1))/2、L_phi=1/c_phi，D_phi=L_phi exp(L_phi/2)。由 phi 在 core ≥c_phi，得 F≤L_phi phi；已核全线 log phi 的 L_phi 控制又给

    C(t)=∫core F(t−r)dr≤D_phi phi(t).

对 X=(x−y)/b、T=(y−v)/b，phi(T)≤exp(L_phi|X|)phi(T+X)。因 min(1,C/zg)≤C/zg，得到全部来源 v 上的准确点态比较

    w_g(y,v)≤(D_phi/zg)^n exp(L_phi||x−y||_1/b) b^n J(x−v).

用同一合法全软测试 J=P_{1,b} 与 ν_V≤f，遂有

    e_g(y)/q≤b^n(D_phi/zg)^n exp(L_phi||x−y||_1/b).

该式显示一条合法方向与完整价格，**不是**一般局部容量成果：右端含显式指数维数、来源位移和实际终端 zg。中间带只有 D_b 的下界，没有给这个正指数费用的统一上界。每个 y 上的点态比较亦不能在外 β 平均中各自再领取一次 q；若要合并，仍需第 1 节那样的共同测试/加权总证书。

更有效的一元或联合核比较可以提出，但作者必须给出其常数、来源域、同一 receiver 测试和合计使用次数；不能由 high 的反方向或 FIRST 的名称推断已经存在。

## 4. 必须保留的来源/时间/局部域条件

- 固定 (omega,V,j,y,t) 时 Π_t、e_t、ν、Z_t 不依 x 与外硬 z，可正 Tonelli 固定 t。终端 g(x)、e_{g(x)}、w_g、same-alpha、rho、high 和 selected s,L,R 仍依 x；不能以当前 t 固定替代终端冻结。
- e_g=∫_{Z_g}w_gν 的完整支持与零交通约定必须保留。未知 η=e_t/E_t 下界、全叶质量帽或任意 y 中心的小盒 q a^n 帽不能默用。已恢复的 hard 局部质量帽只属于同一实际 x 的 hard 盒，不自动移成 y-near 来源容量。
- R167 ER7–9 的 bad 矩是 ∫bad(K0/w_t)dΠ_t≤alpha p/(2DK)。若无 K0/w_t 的已证正下门，不能删除该权而得到 bad 后验质量帽。若按 κ 下层付质量，还须不交分层并付每层比较及合计费用，不能重复原同-alpha 余额。
- 中间域是 s≥s0、D_b>d*、m_b>m0 且排除已付 FIRST 高尾。receiver overflow 仍不同于原 score δ=(kv−ku)_+；full FIRST 的 source 上尾/receiver 体积价不是 δ 的额外下降因子。
- R167 高尾的价格是 C_vol zeta q|E|，不直接是 C sqrt(n)W_beta。若声称吸收，应给原体积量及可用吸收系数；若转来源价，应证明新的积分桥，而不是更换右端符号。
- hard16/3 只一次，signed2Lambda、原 j≤n+2、时间≤log2、V/history 聚合与外 W_beta 均须按原路径完整列出。

## 5. 下一审查入口与停止

本轮作者准确命题应明确：在中间带的哪个真实子域；需要 e_g/q 上界还是逆分母界；是哪一个共同 future 测试或怎样付连续菜单；Σ_Vβ_V≤f 在哪个积分次序使用；核比较是否对来源点统一；终端选择器和价格如何保留；最后是 W_beta 价格、可吸收体积价，还是仍有未付条件。

独立检查点完成。当前没有登记新的中间带付款或一般不可能性结论；不搜凑反例、不读作者猜测当证据。停止等待主代理指定成稿审核。


## 6. soft–scale joint FIRST 候选的独立推导（作者前）

以下先按主代理指定准确命题核验，尚未读取 `middle_joint_first.md`。记 d_i=|x_i−y_i|、a_phi=phi(1/2)>1/4、c=1−a_phi∈(0,1)、L_phi=2/(1−e^(−1))<4；这里 a_phi 不是其他稿中 2sinh(1/2) 的同名符号。当前 s>0，future u∈[s,1]，L,L'∈[a,b]。m=#{d_i>b/2}。

### 6.1 同尺度 soft 比较

在 hard 支撑内，f_u/f_s=(1−u+u phi)/(1−s+s phi) 对 phi 非减，最低为 (1−cu)/(1−cs)。在 hard 支撑外，比例 u/s≥1，不小于此数。对 d_i>b/2 的 m 个坐标，因 L≤b，hard 严格为零，比例恰为 u/s。因此

    soft(m;u,s)=m log(u/s)+(n−m)log[(1−cu)/(1−cs)]

确为 log(P_{u,L}/P_{s,L}) 的下界。s=u=1 时各 log 为 0；a_phi>0 确保 1−cu 始终正。原闭 hard 面只须在非 overflow 单元使用上述保守下界，无边界漏洞。

### 6.2 扩尺度下界

若 L'≥L，偶递减性给其余坐标 f_u(d/L')/f_u(d/L)≥1。在 d>b/2 坐标，L'≤b 保证两个参数都在 phi 的 tail。tail 是 rate 1/r≥1 的正指数混合，故 phi(t')/phi(t)≥exp(t−t') 对 t≥t'≥1/2 成立。结合归一化有

    log(P_{u,L'}(x−y)/p(x−y))
      ≥nlog(L/L')+(1/L−1/L')∑_{d_i>b/2}d_i+soft(m;u,s).

L'=L、u=s 等号退化正常。强制 tail 使用严格 d>b/2，未在自适应边界删除 hard。

### 6.3 缩尺度下界

若 L'≤L，设 J=#{L'/2<d_i≤L/2}。不跨 hard 边界的单坐标，由 log phi 的 L_phi 控制可给比值≥exp[−L_phi(1/L'−1/L)d_i]；在两端均 hard 的段，log(1−u+u phi) 的导数绝对值不超过 log phi，故同界成立。

跨边界时先用 phi 的同一比较，再乘

    u phi(d_i/L)/(1−u+u phi(d_i/L))
       ≥u a_phi/(1−cu).

分子原 phi≥phi(1/2)；该比例对 phi 非减。因此

    log(P_{u,L'}/p)
      ≥nlog(L/L')−L_phi(1/L'−1/L)∑d_i
         −J log[(1−cu)/(u a_phi)]+soft(m;u,s).

J 的严格左端、闭右端正好对应新 hard 已消失而原 hard 仍存在的坐标，包含 d=L/2、排除 d=L'/2，方向正确。u=1 时 jump 罚项为零；L'=L 时 J=0。

### 6.4 共享菜单和 raw 价格阈值

若 B(x,y)=sup_{u≥s,H∈[a,b]}log[P_{u,H}(x−y)/p(x−y)]，则第 2 节合法菜单直接给

    sup P_{u,H}/p≤e² max_{shared nodes}P_{sigma,H'}/p,
    N≤(n+2)[1+nlog(1/s0)]  (s≥s0).

因此在 B≥H 上，p≤exp(2−H)∑_{nodes}P_node。先合并 Σ_V beta_V≤f，再对同一共享菜单的每个合法 future 测试用一次 FIRST，得到 source 行质量≤Nq exp(2−H)。这不是每个 y 自选测试后各领 q。

恢复一次 hard16/3、signed2Lambda、delta≤n、j≤n+2、时间≤log2，价格为

    (32Lambda log2/3) n(n+2)N exp(2−H) q|E|.

取 H=2+log[Nn(n+2)/zeta] 正好为 C_vol zeta q|E|，C_vol=32Lambda log2/3。此为明确体积价格，不可直接改记 W_beta。若作者用可计算 log 下界代替 B，只要该下界≤B，阈值子域仍可用同一价格。

### 6.5 新几何族与 strict-soft 范围

在 L=b、L'=a=b/2，m=n/20 个坐标 d_i=b、其余为 0（可先取 n 为 20 的倍数）时，J=0、∑d_i=nb/20。端点 s=u=1 给 soft=0，缩尺度下界≥n[log2−L_phi/20]≥n(log2−1/5)>0。它不依旧 m 上尾的非退化倾斜，确实是不同的联合尺度 witness。

但 s=1 是原 strict s∈(0,1) 的端点，不能仅凭此端点称原实际正分支新覆盖。一个显式原合法邻域是 s∈[99/100,1)、future u=1：因 c/a_phi<3，有

    soft(m;1,s)≥−3n(1−s)≥−3n/100,

故同族仍有下界 n(log2−23/100)>0。m0/n<3/80<1/20，且 d*/(bn)<1/128<1/40（用 theta>16/epsilon 即可），所以此几何族在旧 sparse 与 U 的组合域外；它只是 source/receiver 几何 witness，不认证存在满 FIRST/good/rho/history 的正模型。实际阈值需 n(log2−23/100)≥H，有限 n 不得跳过此条件。

两条尺度下界与共享菜单阈值独立核验通过；已向作者提示 strict-soft 端点措辞，等待准确成稿后审。


## 7. 主代理 future-mixture 工具的独立核验（作者前）

本节按主代理准确命题独立推导，尚未读取其 `future_mixture.md`。

### 7.1 非负 Bernstein 展开与 n+1 常数

固定当前 s∈[0,1]、一个合法尺度 H，并以 t∈[0,1] 参数化 u=s+(1−s)t。准确单坐标恒等式是

    f_u=(1−t)f_s+t phi.

因此固定 x−y 后，产品 P_{u,H} 可写为 ∑_{S⊂[n]}A_S t^|S|(1−t)^(n−|S|)，其中 A_S≥0，且包括共同的 H^(−n)。对 k=|S|，二项分布总质量为 1 给 binomial(n,k)t^k(1−t)^(n−k)≤1；反复分部积分给该基函数在 [0,1] 的积分恰为 1/[(n+1)binomial(n,k)]。

故每个基函数的任意点值≤(n+1)倍其积分，逐项非负相加即得

    sup_{u≥s}P_{u,H}(x−y)
       ≤(n+1)∫_0^1P_{s+(1−s)t,H}(x−y)dt.                 (MIA1)

s=0 包含在纯核命题内；s=1 时参数图退化为常值，(MIA1) 仍成立，只是更松。无需除以 1−s，所以没有端点奇异。该常数在“只有 t^n 项”的核情形已是紧量级，不存在被忽略的 2^n mask 费用。

### 7.2 共同 FIRST 与尺度连续选择

对同一 receiver x，t-mixture 的每一个测试在所有被积分 y、V 上相同，且 u(t)≥当前 s，H∈[a,b]。由 Σ_V beta_V≤f 和非负 Tonelli，

    ∑_V∫sup_{u≥s}P_{u,H}(x−y)β_V(dy)≤(n+1)q.

这正使用完整 FIRST，不是按 y 选择各自的测试后分别领 q。mixture 随 x 的当前 s 改变不妨碍这条逐 receiver 容量不等式；后续若需要固定 column 核积分，仍须另审其接收选择。

尺度 H 向上取相邻比≤e^(1/n)、包含 b 的固定网格，点态 P_{u,H}≤eP_{u,H'}，N_H≤n+2。对该菜单真实求和后得

    ∑_V∫sup_{u≥s,H∈[a,b]}P_{u,H}(x−y)β_V(dy)
       ≤e(n+1)(n+2)q.                                  (MIA2)

soft 无需 s0 下门，也没有 log(1/s0) 菜单费用。尺度 e 与 N_H 各计一次，不能再叠第 6 节已被替代的 soft 网格价格。

### 7.3 共同来源上尾与完整 raw 阈值

在 p>0 的原非零源交通行定义 R(x,y)=sup_future P/p。p=0 的源点原 raw 权 p 为 0；可排除或给 R 一个扩展值，不影响以下 p 加权估计。

由 p1_{R≥e^H}≤e^(−H)sup_future P，再用 (MIA2)，source 行质量≤e(n+1)(n+2)e^(−H)q。一次 hard16/3、signed2Lambda、delta≤n、j≤n+2、时间≤log2 给

    C_vol (n+1)n(n+2)² exp(1−H)q|E|,
    C_vol=32Lambda log2/3.

取 H=1+log[(n+1)n(n+2)²/zeta] 正好为 C_vol zeta q|E|。无 s0 费用，亦不自动成为 W_beta column 价格。此阈值可用于第 6 节的任一显式 log 下界触发的子域，因为该下界≤log R。

### 7.4 新例的更直接 strict-soft 版本

第 6.5 节的端点/近端点论证可以进一步加强：同一 L=b、L'=a=b/2、m=n/20 个 d_i=b 其余 0，直接取 future u=s。于是 soft 项恰为 0，J=0，对**每个 s>0**都有

    log(P_{s,a}/P_{s,b})≥n(log2−L_phi/20)
                                >n(log2−1/5).

因此新几何不需要 s=1 端点或 strict-soft 连续近似。取原合法 s∈[max(s0,1/2),1)，由 phi(1/2)<1/2 得 c>1/2，所以 cs>1/4>m/n；旧 capped count 上尾的率函数在此几何上仍为 0，而上述尺度 witness 正线性增长。父级/作者送来的这一更简洁选取已经独立核过。

仍须 n(log2−1/5)达到实际 H 才触发相应有限 n 的 source 尾预算；不能称所有有限 n 自动覆盖。也不据此认证实际 FULL 正模型。若 s0=1，原 strict s<1 的所述子域为空，只剩端点纯核参照。

future-mixture 命题及阈值独立核验通过；等待两份准确成稿后审与最终绑定。


## 8. 两份最终成稿的作者后审与绑定

已在第 6–7 节独立推导之后实读 `middle_joint_first.md` 全稿、`future_mixture.md` 全稿。数值多项式 probe 不参与以下一般证明认证；未重复运行其有限测试。

### 8.1 `middle_joint_first.md`：几何与量词通过

(8) 的扩尺度下界、(9) 的缩尺度下界，与第 6 节独立证明一致。n log(L/t) 的物理归一化、S_b=bm/2+D_b、总距离 T、真实跨界 J_t 和 ell(u) 都保留；没有只凭 m 或 D_b 单个条件宣布全中间带覆盖。s=u=1、t=L、d=t/2 与 d=L/2 的边界约定正确。

B_* 的定义是明确可计算的逐坐标 log 下界 supremum，不是未知核范数付款假设。J_t 只有有限个边界：在 t=2d_i，J_t 随 t 从左侧 drop，(9) 的负 jump 罚项移去，值按右侧定义；t=L 的闭面也与相邻扩尺度分支相容。因此可以用包含物理端点的可数稠密参数及右逼近表示其 supremum；soft 参数连续。所述可测性成立。

旧 §4.1 菜单中，soft 向下节点锚当前 s，所以每个节点仍≥当前 s；尺度向上节点合法。原 (14) 的 e²与 N0 费用正确，但正文清楚标为保留核验而非最终价格。升级 §4.2 用第 7 节已核 future-mixture，(14a)–(14c) 的 N1=(n+1)(n+2)、e 而非 e²、无 s0 菜单费准确。两种菜单未在最终 raw 中叠加。

(15) 只在旧已付分支的真实补集登记新事件。它不依外硬或内 good/bad 来源，剩余资格正放松后，一次硬帽、原 Π 概率质量、delta≤n、时间≤log2、j≤n+2，再将 Σ_V beta_V≤f 合并到同一 receiver 的共同测试，得到

    raw≤C_vol n(n+2)N1 exp(1−H)q|E|,
    H=1+log[n(n+2)N1/zeta], C_vol=32Lambda log2/3.

故 (16)–(18) 常数与量词均通过。没有逐 y 各领取 q，没有将 q|E| 改写为 W_beta；只有额外已证 q|E|≤X 时才可记可吸收 X 价。

§6 的 strict-soft 修订比初始 s=1 端点例更强：u=s、J_t=0、soft=0，给所有 s>0 的 n(log2−L_phi/20)>n(log2−1/5)。取 s∈[max(s0,1/2),1)，c≥1/2 导致 m/n=.05<cs，旧非负倾斜的 capped rate=0（由 log(1−cs+cs e^tau)≥cs tau 即可证）。D_b>d*、m>m0 的比较与足够大 n 达到 H 的条件都明确。坐标可作小扰动且保持严格余量，但文稿没有声称构造 FULL 正输入；s0=1 明确只剩端点参照。此范围正确。

该稿 §4.1 一个 display 闭符号的排版问题已直接通知作者，不影响数学；最终文件修订仅为该排版时不改变以上结论。

### 8.2 `future_mixture.md`：FM1–FM5 与独立工具一致

FM1 的非负 Bernstein 逐项比较与第 7 节一致，s=0、1 都无需分母 1−s。FM2 的当前 s 可依 x，但在每次来源积分中混合测度/尺度菜单共同；同一完整 FIRST 对每个 mixture test 用一次，Sigma beta≤f 在之前/经 Tonelli 使用，合法。

p=0 点原 raw 的 p 权为 0，不对零取商。p>0 时 pR=sup_future P，故 R≥e^H 即便 sup 未达到也能直接给 p1≤e^(−H)pR；无需选择最大来源测试。kernel 的 soft 连续性、尺度从上逼近的右连续性（h 取闭面）及可数稠密尺度/soft 参数给可测 supremum，含 b 端点。FM3 的约定与证明准确。

FM4 的 e(n+1)n(n+2)² 包含尺度 e、Bernstein n+1、score n、scale 网格 n+2、原 j n+2；2Lambda×16/3×log2 正是 C_vol。FM5 的 H 恰好消去这一系数，得到 C_vol zeta q|E|。原随机 receiver 时用 E|E_omega| 的限定、原 E⊂E0/q≤lambda 才能进一步与 X 比较、无 W_beta 付款声明，均保留。

新付款后的剩余必须满足 R<e^H；这个准确残余条件不是整个一般目标已经解决。FM2 不含 s0，并不代表全部低 soft 都已支付。文稿保持这些边界。

### 8.3 文件绑定与最终结论

- `middle_joint_first.md`：初次完整实读版本 SHA256 `8fe7776b03eca430d370d14f0a6f87dc56bc7d227ff3c2aa35a17d8278fb4f69`；随后排版修订版本 SHA256 `216ce493ea8efbd92de2b3acfd2eca9ef6ebc0d84f74c62efe00016b2dcdf002`。
- `future_mixture.md`：SHA256 `9af9977b18f286fd2e73fbde79bf07fc2b1d0305f2b0417b27d6bd2bad525229`。

最终判定：两条联合 soft/尺度 log 下界、连续 future 正混合包络、共享 FIRST 容量与新中间分支的显式 raw 体积价格严格通过。该路线没有提供一般 e_g/q 的免费局部容量帽，而是使用另一条已付共同 future escape 证书。全部未被新事件触发的中间域与整体根阶目标仍未闭合。

本指定独审完成，停止；不扩展作者命题、不重复有限数值测试。

绑定补核：将最终 `middle_joint_first.md` 中唯一的 N_s display 闭符号 `\]` 反改为旧单字符 `]`，得到 SHA256 恰为原完整实读的 `8fe7776b03eca430d370d14f0a6f87dc56bc7d227ff3c2aa35a17d8278fb4f69`。因此最终 `216ce493...` 与原审版本严格仅差该排版修复，数学绑定无未核增改。
