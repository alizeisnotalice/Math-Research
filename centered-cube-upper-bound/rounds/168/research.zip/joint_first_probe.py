#!/usr/bin/env python3
"""R168 finite consistency probe of the confirmed two-direction FIRST comparison.
No theorem/interval/FULL certification is supplied by GL or mp comparisons.
"""
from pathlib import Path
from fractions import Fraction as F
import importlib.util
import hashlib,json,math,time

HERE=Path(__file__).resolve().parent
OLD_PATH=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round165_20261015_final_checkpoint/hard_overlap_check.py')
spec=importlib.util.spec_from_file_location('r168_old_numeric',OLD_PATH)
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
phi_np=old.old.phi_np
mp=old.mp
B=F(1)
SVALUES=[F(1,1000),F(1,4),F(3,4),F(1)]
SCALES=[F(1,2),F(3,4),F(1)]
A0=float(phi_np(.5));C=1-A0
LPHI=2/(1-math.exp(-1))

def kernel(s,L,d):
    # The hard membership is exact rational, including endpoints.
    return ((1-float(s))*int(2*abs(d)<=L)+float(s)*float(phi_np(float(abs(d)/L))))/float(L)

def sample(s,u,L,Lp,d,stage):
    outside=d>B/2
    crossing=Lp/2<d<=L/2 if Lp<L else False
    soft=math.log(float(u/s)) if outside else math.log1p(-C*float(u))-math.log1p(-C*float(s))
    density=math.log(float(L/Lp))
    if Lp>=L:
        direction='expand' if Lp>L else 'same'
        scale_extra=float(d*(1/L-1/Lp)) if outside else 0.
        cross_penalty=0.
    else:
        direction='shrink'
        scale_extra=-LPHI*float(d*(1/Lp-1/L))
        cross_penalty=math.log(float(u)*A0/(1-C*float(u))) if crossing else 0.
    lower=soft+density+scale_extra+cross_penalty
    actual=math.log(kernel(u,Lp,d))-math.log(kernel(s,L,d))
    return dict(stage=stage,s=str(s),u=str(u),L=str(L),Lprime=str(Lp),d=str(d),direction=direction,
                outside_b_core=outside,cross_hard=crossing,soft=soft,density=density,
                scale_extra=scale_extra,cross_penalty=cross_penalty,lower_log_ratio=lower,
                actual_log_ratio=actual,slack=actual-lower)

def mp_check(row):
    mp.mp.dps=80
    def M(z):
        q=F(z);return mp.mpf(q.numerator)/q.denominator
    s,u,L,Lp,d=[M(row[k]) for k in ('s','u','L','Lprime','d')]
    phi=old.old.phi_mp
    a0=phi(mp.mpf('.5'));c=1-a0;lphi=2/(1-mp.exp(-1))
    def kern(ss,ll):return ((1-ss)*int(2*d<=ll)+ss*phi(d/ll))/ll
    actual=mp.log(kern(u,Lp))-mp.log(kern(s,L))
    soft=mp.log(u/s) if row['outside_b_core'] else mp.log((1-c*u)/(1-c*s))
    lower=soft+mp.log(L/Lp)
    if Lp>=L:
        if row['outside_b_core']:lower+=d*(1/L-1/Lp)
    else:
        lower-=lphi*d*(1/Lp-1/L)
        if row['cross_hard']:lower+=mp.log(u*a0/(1-c*u))
    return dict(parameters={k:row[k] for k in ('s','u','L','Lprime','d','direction','outside_b_core','cross_hard')},
                mp80_actual_log_ratio=mp.nstr(actual,60),mp80_lower_log_ratio=mp.nstr(lower,60),
                mp80_slack=mp.nstr(actual-lower,60),
                float_actual_abs_error=float(abs(M(str(row['actual_log_ratio']))-actual)),
                float_lower_abs_error=float(abs(M(str(row['lower_log_ratio']))-lower)))

def geometry(n,s,u):
    assert n%20==0
    m=n//20;r=F(1,20);s0=s
    eta=old.ETA;eps=float(s0)*eta;alpha=3*eps/4
    theta=LPHI+(16+8*math.exp(LPHI))/eps
    dstar=n*eps/(8*theta)
    m0=math.floor(alpha*n/(4*math.log(80*math.e/alpha)))
    coords=[sample(s,u,F(1),F(1,2),F(1),'geometry')]*m+[sample(s,u,F(1),F(1,2),F(0),'geometry')]*(n-m)
    bound=sum(z['lower_log_ratio'] for z in coords)
    actual=sum(z['actual_log_ratio'] for z in coords)
    D=F(m,2)
    old_rate=0. if s==1 or float(r)<=C*float(s) else None
    assert old_rate==0.
    rigorous_B_lower=F(7*n,15) if u==s else F(31*n,75)
    zeta=F(1,100);N1=(n+1)*(n+2)
    fullH=1+math.log(n*(n+2)*N1/float(zeta))
    fixedH=math.log(n*(n+2)/float(zeta))
    return dict(n=n,m=m,s=str(s),u=str(u),s0=str(s0),a='1/2',b='1',L='1',R='1',Lprime='1/2',
                exterior_coordinate_d='1',other_coordinate_d='0',D_exact=str(D),
                dstar_numeric=dstar,m0_numeric=m0,D_gt_dstar=float(D)>dstar,m_gt_m0=m>m0,
                lower_log_ratio_B=bound,actual_log_ratio=actual,B_positive=bound>0,
                analytic_strict_B_lower=str(rigorous_B_lower),old_tail_rate_at_m_over_n=old_rate,
                old_tail_max_n_log_1_over_s=n*math.log(1/float(s)),
                zeta=str(zeta),N1=N1,full_H_threshold=fullH,full_H_gate=bound>=fullH,
                fixed_single_test_H=fixedH,fixed_single_test_H_gate=bound>=fixedH,
                volume_fee_per_Lambda_q_volume=(32/3)*math.log(2)*float(zeta),
                scope='Finite geometric/kernel example only; no high, original sources, same-alpha, FIRST realization or FULL claim')

def main():
    start=time.monotonic();rows=[]
    for s in SVALUES:
        for u in sorted({s,(1+s)/2,F(1)}):
            for L in SCALES:
                for Lp in SCALES:
                    stages={'initial':[F(0),F(1,4),F(1)],
                            'hard_boundary_pressure':sorted({v+e for v in {L/2,Lp/2,B/2} for e in (-F(1,10**9),F(0),F(1,10**9))}),
                            'expanded_far':[F(4),F(16)]}
                    for stage,ds in stages.items():
                        rows.extend(sample(s,u,L,Lp,d,stage) for d in ds)
    def summary(rr):
        return dict(count=len(rr),min_slack=min(r['slack'] for r in rr),max_slack=max(r['slack'] for r in rr),
                    float_violations_below_minus_1e_11=sum(r['slack'] < -1e-11 for r in rr),
                    min_row=min(rr,key=lambda r:r['slack']))
    stages={stage:summary([r for r in rows if r['stage']==stage]) for stage in sorted({r['stage'] for r in rows})}
    chosen=[];seen=set()
    selections=[('global_min',min(rows,key=lambda r:r['slack'])),
                ('expand_outside_min',min((r for r in rows if r['direction']=='expand' and r['outside_b_core']),key=lambda r:r['slack'])),
                ('shrink_cross_min',min((r for r in rows if r['cross_hard']),key=lambda r:r['slack'])),
                ('largest_cross_penalty',min((r for r in rows if r['cross_hard']),key=lambda r:r['cross_penalty'])),
                ('largest_absolute_bound',max(rows,key=lambda r:abs(r['lower_log_ratio']))),
                ('largest_slack',max(rows,key=lambda r:r['slack'])),
                ('small_s_far',max((r for r in rows if r['s']=='1/1000' and r['d']=='16'),key=lambda r:r['slack']))]
    for label,row in selections:
        key=tuple(row[k] for k in ('s','u','L','Lprime','d'))
        if key not in seen:
            seen.add(key);chosen.append(dict(selection=label,**mp_check(row)))
    assert all(r['slack']>=-1e-11 for r in rows)
    geom=[geometry(n,s,u) for s,u in ((F(1),F(1)),(F(99,100),F(1)),(F(99,100),F(99,100))) for n in (20,100,1000)]
    data=dict(scope='Finite numeric check of confirmed two-direction kernel comparison; float/mp consistency, not interval theorem certification or FULL.',
              inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (OLD_PATH,Path(old.old.__file__))},
              formula_confirmation='Author r166_scale_budget explicitly confirmed both directions before implementation.',
              parameters=dict(s_values=list(map(str,SVALUES)),future_u='s,(1+s)/2,1 (deduplicated)',L_values=list(map(str,SCALES)),Lprime_values=list(map(str,SCALES)),b='1',boundary_epsilon='1/1000000000'),
              constants=dict(phi_half=A0,c=C,Lphi=LPHI,eta=old.ETA),
              total=summary(rows),stage_summaries=stages,
              direction_summaries={direction:summary([r for r in rows if r['direction']==direction]) for direction in ('same','expand','shrink')},
              mp80_checks=chosen,max_mp80_actual_abs_error=max(z['float_actual_abs_error'] for z in chosen),
              max_mp80_lower_abs_error=max(z['float_lower_abs_error'] for z in chosen),
              geometric_examples=geom,records=rows,wall_seconds=round(time.monotonic()-start,3))
    (HERE/'joint_first_probe.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps(dict(cases=len(rows),minimum_float_slack=data['total']['min_slack'],mp_actual_max_error=data['max_mp80_actual_abs_error'],mp_bound_max_error=data['max_mp80_lower_abs_error'],geometry=[{k:z[k] for k in ('n','s','u','lower_log_ratio_B','full_H_threshold','full_H_gate')} for z in geom],wall_seconds=data['wall_seconds']),indent=2))

if __name__=='__main__':main()
