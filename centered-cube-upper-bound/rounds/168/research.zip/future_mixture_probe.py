#!/usr/bin/env python3
"""Finite exact nonnegative-product checks of FM1, not a continuous proof."""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import random,json
HERE=Path(__file__).resolve().parent

def check(A,B,stage,label):
 n=len(A);coeff=[F(1)]
 for a,b in zip(A,B):
  new=[F(0)]*(len(coeff)+1)
  for k,v in enumerate(coeff):new[k]+=v*a;new[k+1]+=v*b
  coeff=new
 integral=sum((v/F((n+1)*comb(n,k)) for k,v in enumerate(coeff)),F(0))
 samples=[]
 for t in map(F,['0','1/1000','1/10','1/2','9/10','999/1000','1']):
  value=F(1)
  for a,b in zip(A,B):value*=((1-t)*a+t*b)
  assert value==sum((v*t**k*(1-t)**(n-k) for k,v in enumerate(coeff)),F(0))
  slack=(n+1)*integral-value;assert slack>=0
  samples.append(dict(t=str(t),slack=str(slack)))
 return dict(stage=stage,label=label,n=n,A=list(map(str,A)),B=list(map(str,B)),integral=str(integral),samples=samples)

def main():
 rng=random.Random(168);rows=[]
 for n in [1,2,4,8]:
  rows.append(check([F(1)]*n,[F(2)]*n,'initial','constant factors'))
 for n in [1,4,16,32]:
  rows.append(check([F(0)]*n,[F(1)]*n,'pressure','all hard endpoint zeros'))
  rows.append(check([F(1)]*n,[F(0)]*n,'pressure','other endpoint'))
  rows.append(check([F(0) if i%2 else F(1) for i in range(n)],[F(1) if i%2 else F(0) for i in range(n)],'pressure','mixed endpoint zeros'))
 for n in [4,16,32,64]:
  A=[F(rng.randrange(1,11),rng.randrange(1,11)) for _ in range(n)]
  B=[F(rng.randrange(1,11),rng.randrange(1,11)) for _ in range(n)]
  rows.append(check(A,B,'expanded','nonidentical rational factors'))
 out=dict(scope='Finite Fraction implementation checks only; FM1 proof is analytic; not a FIRST model or new weak-type estimate.',seed=168,cases=rows,summary=dict(case_count=len(rows),exact_evaluation_count=sum(len(r['samples']) for r in rows),all_assertions_passed=True))
 (HERE/'future_mixture_probe.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['summary']))
if __name__=='__main__':main()
