#!/usr/bin/env python3
"""Same geometry, one refined rational candidate. No search or full f realization.
All u in [s,1] reduce to endpoints by this geometry's explicit convexity.
All future scales are covered by interval boxes, not a point grid.
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal
import importlib.util,json,hashlib,time
HERE=Path(__file__).resolve().parent
DEP=HERE/'lp_candidate_certificate.py'
sp=importlib.util.spec_from_file_location('r168_candidate_tools',DEP);ct=importlib.util.module_from_spec(sp);sp.loader.exec_module(ct)
I=ct.I
NU=[F(3,25),F(2749,3125),F(1,3125)]
q=F(9,2500);lam=F(11,2500)

def main():
    start=time.monotonic()
    assert sum(NU)==1
    ct.NU=NU;ct.QLEVEL=q;ct.LAM=lam
    # No nonhard source has any hard scale threshold in [.5,1].
    displacements=[[abs(a-b) for a,b in zip(ct.X,z)] for z in ct.POS]
    assert all(d>F(1,2) for row in displacements[:2] for d in row)
    assert all(d==0 for d in displacements[2])
    legacy=ct.run(64,expect_future_rejection=False)
    bounds=[]
    for i in range(32):
        lo=F(1,2)+F(i,64);hi=lo+F(1,64)
        for ss in (F(1,4),F(1)):
            vals=[ct.kern(ss,I(I(lo).lo,I(hi).hi),row,64) for row in displacements]
            total=sum((I(n)*k for n,k in zip(NU,vals)),I(0))
            assert total.hi<I(q).lo
            bounds.append(dict(L_interval=[str(lo),str(hi)],future_s=str(ss),upper_nu_kernel=str(total.hi),
                               strict_q_margin_lower=str(ct.iv.DN.subtract(I(q).lo,total.hi))))
    worst=max(bounds,key=lambda z:Decimal(z['upper_nu_kernel']))
    out=dict(scope='One refined rational source measure: finite gates and EVERY future kernel test on [s,1]x[a,b] pass rigorous intervals; no f/beta/Psi/FIRST equality/history realization.',
        inputs={DEP.name:hashlib.sha256(DEP.read_bytes()).hexdigest(),str(ct.DEP):hashlib.sha256(ct.DEP.read_bytes()).hexdigest()},
        candidate=dict(nu=list(map(str,NU)),q=str(q),lambda_value=str(lam),same_geometry_as_first_pass=True),
        legacy_gate_certificate=legacy,
        all_future_necessary_test=dict(soft_interval=['1/4','1'],scale_interval=['1/2','1'],
            soft_endpoint_reduction='Each nonhard source is const(L)*u^4, central hard source is L^-4*(1-(1-phi(0))*u)^4; nonnegative weighted sum is convex in u, so endpoints suffice.',
            hard_support_scale_breakpoints_inside_domain=[],scale_partition_cells=32,endpoint_interval_boxes=64,
            worst_upper=worst,all_boxes_strict_below_q=True,boxes=bounds),
        final_status='ALL_FUTURE_NU_NECESSARY_TESTS_CERTIFIED_ONLY',
        limitations=['Original q=P_s,L f and f>=nu not constructed; all-future upper bounds for nu are necessary only.',
                     'Finite atomic source is not an L1 density dominated by f dx; beta/history/original leaf not realized.',
                     'Original Psi/Z eligibility not certified; fixed-Z toy low-c/time checks retain that limitation.',
                     'The previous rational point remains FIRST-rejected; this certificate is a distinct post-constraint point.'],
        wall_seconds=round(time.monotonic()-start,3))
    (HERE/'lp_refined_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(seconds=out['wall_seconds'],rho=legacy['rho_target'],alpha=legacy['alpha'],worst=worst),indent=2))
if __name__=='__main__':main()
