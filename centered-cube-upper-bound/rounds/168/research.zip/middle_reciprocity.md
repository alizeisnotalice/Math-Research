# R168：源—接收转置的准确缺陷与外 surplus 储备分支

状态：转置本身未付清一般中间域；得到一个新的、费用完整的外 surplus 组件条件预算。它使用 beta−nu 已包含在同一个 alpha 中的 K0 储备，区别于 R144 对内部 bad K0/wt 的高核比付款。当前冻结必要模型没有 beta−nu 密度，尚不能认证该新门在剩余 middle 的新增数值覆盖，故不宣称一般中间域闭合。

## 1. 准确候选及量词先审

固定原 omega,V 与原 [a,b] 块，nu≤beta≤f dx，写

    sigma=beta−nu≥0。                                         (MR1)

这是实际外来源测度的唯一线性分解，不把 beta 换成 nu。原完整正交通于是等于“外nu组件”与“外sigma组件”的和；内good v、内bad u、外hard z始终按原nu积分。

在同一实际接收x、原j、外中心y上保留原rho、alpha_y、T、Delta_y(v)，并置

    d_y(v)=[1−D K0(x−v)/(T Delta_y(v))]+。

Delta=0等原退化行按零交通。本文的新门是

    T Delta_y(v) d_y(v)^2
          ≤ K0(x−y) w_g(y,v)/sqrt(n)。                        (MR2)

门只加在原正交通；所有middle、high、原good/bad、low-c、history及其他资格仍保留。无需把hard z换成y或u，无需来源坐标独立，不要求接收参数固定。K0的Hhat是同一原合法future尺度，不依被积分来源重新挑选。

**候选结论。** 外sigma组件与MR2的交具有完整signed价

    2 Lambda P_sigma,MR2
       ≤[8 Lambda K log(2)/(9D)] sqrt(n) W_beta。              (MR3)

本稿先核反例压力：sigma=0时该组件为空；小K0(x−y)使MR2更严格，不能因外receiver深尾而假定它成立；rho>0只给TDelta>DK0v，不推出MR2；同alpha不能按y或v重新分配。下面证明不需要这些虚假推论。

一般转置尝试与MR3分开审计：它不会产生一个免费的可逆后验，具体公式见§2。MR3若通过独审是一条条件预算，不等同于已认证非空FULL中间模型。

## 2. 详细平衡能给什么，不能给什么

固定原x,j,t和共同nu。对外中心y定义

W_t(y,u)=1_{Z_{j,V,y,t}}(u) w_t(y,u)，
e_t(y)=∫W_t(y,u)dnu(u)。

裸权w_t(y,u)由偶函数C和同一阈值构成，故w_t(y,u)=w_t(u,y)。实际W_t不自动对称。对原有限截断上两侧积分有限的任意非负可测F，准确缺陷为

∫ e_t(y)dnu(y) dPi_y,t(u) F(y,u)
 −∫ e_t(u)dnu(u) dPi_u,t(y) F(y,u)
 =∫∫w_t(y,u)[1_{Z_y}(u)−1_{Z_u}(y)]F(y,u)dnu(y)dnu(u)。       (MR4)

第二项中F仍按原参数顺序(y,u)读。若反向中心u在原构造/允许域上没有对应后验，该区域不可当作反向原交通；只可保留在缺陷部分。等式可先在两方向对象都定义、分母正的有限截断上写出，其他零行按原约定处理。

在互存活集合 M={u∈Z_y,y∈Z_u} 上，真正可逆的是 e_t(y)nu(dy) 与互存活的次Markov核，不是nu或beta。

令H_y(u)为对原good v后验积分后的非负因子，保留原rho_y(v)、delta_y(v,u)、good/bad和所有资格。在外nu组件中，互存活项满足准确转置

∫ dnu(y) p_y ∫dPi_y,t(u)1_M H_y(u)
 =∫dnu(u) p_u ∫dPi_u,t(y)1_M
       [p_y e_t(u)/(p_u e_t(y))] H_y(u)。                     (MR5)

这是固定行的恒等式。反向Pi如不属于原heavy/far资格，只是同一W/e的代数核，不能免费调用原预算。H_y(u)没有变成反向H_u(y)，同alpha_y也没有变成alpha_u。high给1/e_t(y)≤p_y/(2Kq)，代入MR5的比值只产生额外p_y与反向e_t(u)/p_u，未证明其有界。对单向支持M^c也尚无新价。

坏源方向还有一个明确压力。固定共同接收核，写p_a=P_s,L(x−a)、Q_a≥p_a/3。forward bad为p_y w_g(y,u)>KQ_u。由w_g对称，必有

    p_u w_g(u,y)/(KQ_y)<9 w_g(y,u)^2/K^2。                   (MR6)

因此在K≥3w_g(y,u)的边上（K≥3是统一充分条件），反向来源y为good，不能同为bad。转置不自动落回原bad交通或原负交通。若尝试把它交给反向捕获，需保留两个不同外中心的实际alpha；其准确差是

    QJ(alpha_y−alpha_u)=∫[U_u(v)−U_y(v)]dnu(v)。               (MR7)

右端没有逐项符号。不能把forward alpha的余额搬给reverse alpha并称作同一槽的付款。MR4–7是本次转置路线的可核验恒等式/必要关系，不是新可逆性假设。

## 3. 外sigma已在同一个 alpha 的储备中

K0(x−z)与QJ(x)=∫J(x−z)dnu(z)在同一(x,j)上不依外中心y。令

    B_sigma(x,j)=∫K0(x−y)dsigma(y)。                          (MR8)

原U_y≤D K0逐源成立，完整FIRST K0f(x)≤q以及sigma≤f dx−nu给

alpha_y QJ=Dq−∫U_y dnu
 ≥D[q−∫K0 dnu]
 ≥D∫K0 dsigma=D B_sigma。                                    (MR9)

这对所有外中心y同时成立，使用实际alpha_y，未重选它。若B_sigma=0，由K0>0可知sigma=0，该组件零。其余行定义真实概率

    dSigma_x,j(y)=K0(x−y)dsigma(y)/B_sigma。                  (MR10)

Sigma可能依x和j；本证明只在固定实际行中先对其积分，绝不把它拔到dx外。

原rho_y(v)=[d_y(v)−alpha_y Jv/(TDelta_y(v))]+。由MR9，对既定B_sigma有

B_sigma rho_y(v)
 ≤B_sigma[d_y(v)−D B_sigma Jv/(QJ TDelta_y(v))]+
 ≤QJ TDelta_y(v) d_y(v)^2/(4D Jv)。                          (MR11)

最后一步是一元二次式最大值；不是优化或重新选择alpha。这个储备用于同一个外sigma组件的一次估计，不把不同v的MR9当成可相加的独立容量。

## 4. 原good核与两份后验：逐行标量帽

先只看hard来源尚未计入的原内层，在固定(x,j,t)写

I_sigma,j,t(x)=∫dsigma(y) p_y
   ∫dPi_y,t(v)dPi_y,t(u)
      rho_y(v) chiJ_v delta_y(v,u) 1_{MR2} 1_{原全部资格}。

可保留原middle与所有旧未付补集。利用MR10–11及chiJ_v=Jv/(3Qv)，得

I_sigma,j,t(x)
 ≤QJ/(12D) ∫dSigma_x,j(y)
   ∫dPi_y,t(v)dPi_y,t(u)
       [p_y TDelta_y(v)d_y(v)^2/(K0(x−y) Qv)]
       delta_y(v,u) 1_good 1_{MR2}。

在原good上p_y/Qv≤K/w_g(y,v)，因此MR2给

    I_sigma,j,t(x)
       ≤K QJ/(12D sqrt(n))
          ∫dSigma_x,j(y)∫dPi_y,t(v)dPi_y,t(u)delta_y(v,u)
       ≤K QJ sqrt(n)/(12D)。                                (MR12)

三份概率归一都在同一实际行中合法：Sigma由原sigma精确换测度，两份Pi仍是原当前后验，delta≤n。未使用Pi_g替代Pi_t，也未删除et后称nu为概率。即使Sigma、good、rho、Delta和原资格依x，MR12仍是逐点上界。

此处付的是外beta−nu来源，不是ER9中的内部bad K0/wt门。MR2涉及外y的K0、good v的Delta与wg；对内u不添K0/wt下门，也不调用R144高c预算。

## 5. hard、时间、唯一j及完整来源质量

恢复外hard z与原a_history时，只使用一次

    q^(−1)∫h_R(x−z)a_history dnu(z)≤16/3。

在其原合法域可以保留a_history，或正向删其余门后用原资格上包络；不把任意模型a=1授予FULL身份。MR12不依hard z，故signed外价2Lambda连同这一次帽给32Lambda/3。

每个实际j的far时间属于共同[a,b]（tau_j=a/cj≥a，h≤g≤bcj≤b）。MR12的右端不依j和t，QJ=P1,b*nu也是共同的。因此**先**将时间正向上放[a,b]并用原Σj1_{j(x)=j}≤1合并，再积分dx，时间价至多log2，不收额外j数。

于是

2Lambda P_sigma,MR2
 ≤(32Lambda/3)[K sqrt(n)/(12D)]log2
       EΣV∫QJ,V(x)dx
 =[8Lambda K log2/(9D)]sqrt(n) EΣV||nuV||
 ≤[8Lambda K log2/(9D)]sqrt(n) W_beta，                        (MR13)

证明MR3。QJ的质量恒等式只用固定原b的归一核J，不涉及x自适应的K0；K0全部在逐行概率Sigma中消去，所以没有漏掉Hhat尺度费用。原同一块的所有s,L,R选择均允许，不需网格。跨V/种子由原W_beta预算支付；没有授予另行重复块预算。

## 6. 从组件到原beta的一个明确条件分支

由nu≤beta，令r=dnu/dbeta∈[0,1]。对任何预先给定eta∈(0,1]，在外来源门

    r(y)≤1−eta                                                (MR14)

上有1_{MR14}dbeta≤eta^(−1)dsigma。这只比较同一个原非负被积函数，不以sigma重建q、Pi、alpha或来源。故原完整外beta交通同时限制MR2、MR14时，由正性和MR13具有

    2Lambda P_beta,MR2,MR14
      ≤[8Lambda K log2/(9D eta)]sqrt(n)W_beta。               (MR15)

这是明确的输入测度条件，不把beta、nu假设成相等或独立。eta的逆费用不可省略。D沿原捕获参数（D≥1），不为该估计重选；即使D随n变化，也同时保留费用K/D及门中d_y(v)对D的依赖，不以增大D虚构固定覆盖。若eta随n趋零，eta^(−1)不能隐藏为维数无关常数。MR15给原正量中的真实条件子支；MR13给不需要选eta的组件预算。

## 7. 初步、旧压力与扩大范围

初步筛查：零sigma、零QJ、零et和Delta=0按原零交通；K0,J严格正来自原s>0。MR9的K0必须是合法future，不能选与y/v/u有关的新核。MR11在B_sigma=QJ TDelta d/(2D Jv)处达到二次上界，只用于核验系数1/4，不是在原模型中设置B_sigma。

旧压力：R167 ER9虽也用same-alpha二次式，但它只给带内部bad κ的矩；MR11–13用的是外sigma精确换测度及∫QJdx=||nu||，没有除内部κ、没有复用R144容量。旧I1仅保留nu的有限必要模型没有beta−nu密度，不能据其8个正行判断MR14或MR13的组件份额。没有以这些记录宣称新FULL覆盖。

扩大范围：证明适用于任意相关nu和beta、L1输入、实际接收选择器、任意middle子集；不依D_b或m_b具体取值，故也可限制到R168尚未付的中间带。MR2可能严格为空、可能覆盖少量或较多正交通，均不影响预算成立；当前尚未提供满足完整FIRST/history且位于剩余middle的新增正覆盖证据。

## 8. 当前停止位置

本稿严格条件预算是MR13/MR15，已由 middle_raw_audit.md §8 独审通过；其新覆盖在冻结数据中不可测，故不把“有条件上界”夸作一般middle进展已完成。

未付内容准确为：外nu组件（及转置的一向支持缺陷、et反向比、reverse资格/alpha错配），外sigma组件的MR2补集，以及MR15中没有固定surplus比例的剩余beta质量。原一般middle问题仍未闭合。

若继续纯转置路线，需要在原实际测度下控制MR5的p_y et(u)/(p_u et(y))连同H_y(u)，或证明反向good/capture可用同一全局账结算MR7；仅写详细平衡、仅用high再产生p_y²、或把反向原资格省略均不足。本文交付上述可验证结构与真实条件预算后停止。
