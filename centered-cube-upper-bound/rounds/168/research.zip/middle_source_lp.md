# R168：固定几何、变来源质量的必要模型LP

## 编码前的变量映射与约束

先固定n、x、y、s、L、R、a、b、cj和候选来源位置。原核给出p、wg、Delta、T、K0/K1/K2/J/Q；good由 `p*wg<=K*Q` 预先决定，不随LP质量或q改变。对 `E=good & Delta>0`，冻结 `U=1_E*min(T*Delta,D*K0)`。所有来源都进入U及J总和。

变量为非负nu_i、共同q、辅助共同lambda，以及标准化margin tau。约定sum(nu)=1仅选质量单位，不认证连续输入的无损归一化。

必要线性约束为：

- q>=K0·nu、K1·nu、K2·nu、J·nu、Q·nu；Q虽冗余仍保留。
- 最小future补测另加入当前s下L'=a、b，以及u=1下L'=a、b；b端的J重复项也保留，便于审计。这些仍只是完整FIRST的有限必要测试。
- high：p*(wg·nu)>=2Kq；保留原K、全部来源及终端wg。
- lambda带：3lambda/4<=q<=lambda；hard cap：R^-n*sum_hit(nu)<=4lambda；hard质量严格为正。lambda在这里是自由共同水平，不声称等于旧producer参考点的max。
- alpha非负：Dq−U·nu>=0。alpha只在求解后按 `(Dq−U·nu)/(J·nu)` 回代，绝不独立优化。
- 对目标good v，预核 `TDelta_v>DK0_v` 与J_v>0，然后加 `N_v=(TDelta_v−DK0_v)*(J·nu)−J_v*(Dq−U·nu)>0`。这等价于同alpha下rho_v>0，且rho_v=N_v/[(TDelta_v)*(J·nu)]。
- 指定bad u与good v须有正质量；外hard来源总质量也严格为正。冻结时间的正score、low-c等条件若使用，必须另列，不由rho正性自动推出。

每个不等式使用同量纲、事先固定的正标尺sigma，写成 `linear_slack>=tau*sigma`。先检查tau>=0的LP，再最大化tau；若无可行点，仅用允许负tau的阶段报告标准化违反量，不能冒充正模型。弱门被要求有正余量时搜索的是必要可行域的内部子集，未找到不等于一般模型不存在。

旧producer映射核验先用原I1已保存行的原nu/q重算U、alpha与rho，核对截正定义的一致性。求解时q是共同变量，仅满足五个必要测试；不再将它强制等于旧producer三测试max。完整FIRST、f/beta来源支配、Psi/history与连续dx均不由该LP认证。

## 三阶段结果

首轮五核模型共15个固定几何/水平模式、37次目标good/bad LP，11次得到tau>1e−7的正margin。其完整结果保留在JSON的 `first_pass`。补入四个future测试后，只重跑**相同15个几何和37个LP**，得到10个正margin候选；最后s=1是端点压力，不属于原strict-s域，其余9个满足0<s<1。后续只冻结并核对下述s=.25的n4修订候选，没有增加几何菜单。

1. 初步：原六源位置，x=(-.21,.3,.3,.3)或(.81,.3,.3,.3)，分别固定旧lambda或允许共同lambda变量，共4个模式。改变nu后没有找到正margin候选。固定lambda的最优放松margin约−.23327/−.17947，最紧约束含high、lambda下门及J/K2测试；自由lambda模式margin约−6e−9/−2.3e−8，接近求解容差，不能据此认证该来源族不可行。
2. 压力：n=4、8，s=.25、L=.9、R=b=1；x首坐标.51、其余.4。good候选在x外移.55/.60/.65，bad候选为(-.6)^n，独立hard候选位于x。6个模式均找到正margin有限模型。
3. 扩大：固定5组n/s/L/core坐标组合，仅到n=16，s=.25/.5/1、L=.75/.9；补测后4个模式有tau>1e−7，另一模式约6.8e−8低于候选阈值。没有据此猜维数阶或推广到连续输入。

负tau放松结果只用于定位最紧约束；JSON明确标识，不将其rho/score回代登记为可行交通。

## 首轮点明确被future排除

首轮易审点的hard质量为.00327、q=.0037。合法future `(u=s=.25,L'=a=.5)` 的中心核单用phi>=0就有精确下界81/16，因此该hard源贡献至少`.016554375`，比q多`.012854375`。首轮点明确违反真实future必要门，不能只以“FIRST未认证”淡化，更不能作为下一轮的可行起点。

旧点及首轮全部输出保留在 `first_pass`，拒绝的纯分数证明另存 `first_pass_rejection`。以下是加入future门后、重新求解同几何得到的修订点。

## 冻结的修订有理候选

全部位置与质量取精确分数：

\[
n=4,\quad y=0,\quad x=(51/100,2/5,2/5,2/5),
\quad s=1/4,L=9/10,R=b=1,a=1/2,c_j=1,
\]

\[
v_0=(53/50,19/20,19/20,19/20),\quad
u_1=(-3/5)^4,\quad z_2=x,
\]

\[
\nu=(3/25,2749/3125,1/3125),\quad
q=9/2500,\quad\lambda=11/2500.
\]

sum(nu)=1精确成立。good为{0,2}，bad为{1}；目标good为0，实际hard正质量来自2。lambda是共同辅助水平，q没有取三测试max。该例并未沿用或独立指定旧I1 alpha。

按原公式重建得T≈.7991953965、Hhat≈.8964290539，
`Delta≈(.03113894256,.89133227560,.72320383481)`。mp70用全部3源的同一个U/J总和给

\[
\alpha\approx1.40185884148,\qquad
\rho_0\approx.12908800963.
\]

N/(A0*QJ)与rho0一致。各个必要门都有明显正余量：

| 门 | mp70余量 |
|---|---:|
| q−K0·nu | .0032816490 |
| q−K1·nu | .0032865048 |
| q−K2·nu | .0033905712 |
| q−J·nu | .0011688546 |
| q−Q·nu | .0026153102 |
| q−F(s,a)·nu | .0003960339 |
| q−F(s,b)·nu | .0033905712 |
| q−F(1,a)·nu | .0023067902 |
| q−F(1,b)·nu | .0011688546 |
| p*eg−2Kq | .0006000247 |
| Dq−U·nu | .0034081226 |
| q−3lambda/4 | .0003000000 |
| lambda−q | .0008000000 |
| 4lambda−hard density | .0172800000 |
| 正rho的N0 | .0000078100 |

这些余量具有各自量纲，未跨行比较大小。JSON另存heavy正余量、全部核/C系数和精确质量。float与mp70的alpha/rho差约1e−15；mp70仍是高精交叉检查，不能替代系数区间或有向残差证书。核硬边界最小距离约.05，未处于跳点。

## 计数、时间与剩余资格

该点D_b=.01>d*≈8.65e−6，m_b=1>m0=0，摆脱旧固定I1无exterior的结论。它只是几何补集中的必要模型，完整FIRST高尾以及其它新付款门是否覆盖仍须另审。

在xi=.51、.52、.53，全来源支持不变，k=(4,0,0)、delta(0,1)=4。对应low-c比约1.256e−5，沿用相同n4参数的原B_FA时FA比约589.75、545.68、505.65；rho*chiJ*delta*Pi0*Pi1的点值约.00216087、.00200065、.00185495。没有把mask当score，也没有混同d_v与delta。

这段固定计数窗中，wt1=wt2=1，wt0为正的xi^-4倍数，故low-c和FA的时间变化可直接检查；但本文件不把三个数值点升级为完整Psi/history或连续dx、dt正质量证书。Z取全部候选来源仅是有限必要模型选择，未构造原完整历史。

## 共同future二维压力

只对上述新有理点，固定原q，取u从s=.25到1的16节点、L'从a=.5到b=1的21节点，共336个合法future测试。最大 `P_{u,L'}nu/q=.8899905741`，argmax为u=.25、L'=.5；没有越界。

逐源hard阈值 `2max_i|x_i-v_i|` 精确为11/10、111/50、0，全部不在[a,b]，所以没有需追加的合法内部阈值或±1e−8端点；未无故重跑更大网格。这336个节点仍不认证连续(u,L')上的完整FIRST，更没有构造同一个连续f。

独立精确任务随后对该新点报告：以u凸性端点和32个L'区间形成64盒，全部future的nu核上包络最大`.00320474908<q=.0036`，余量大于`.00039525092`；rho0区间约[.12707,.13095]。详见同目录 `lp_refined_certificate.py/json`。这是nu的全future必要测试证书，仍不是f completion或FULL合同；本文件的336点扫描没有被冒称区间证明。

## 实现核验、费用与复现

编码前映射采用原I1保存行的原nu/q：wg与Delta相对差≤6.6e−15、alpha误差1.12e−16、rho绝对差6.67e−16，h重建与原值一致。LP中U、good、核系数均在求解前冻结；目标N与source mass/hard mass都加了独立的量纲标尺。

使用本机SciPy原 `linprog(method='highs')`。本机PROPACK/COBYLA无关扩展有加载问题，脚本直接加载原linprog/HiGHS入口，未改求解实现或数学约束。HiGHS primal/dual容差设1e−9，候选阈值tau>1e−7；唯一冻结候选再以简单有理数和mp70回代。

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 centered-cube-upper-bound/rounds/168/work/middle_source_lp.py
```

结果写入同目录JSON，依赖与原输入SHA保留；稳定入口为 `selected_rational_candidate`，不依赖case序号。脚本从独立SOURCE_DIR读取随包冻结JSON的 `first_pass` 历史字段，HERE只控制输出；父级可把HERE设为全新目录重放，无需另给先前生成结果。已拒绝的首轮点不会混作当前输出。父级已重放首轮输出；修订轮由当前脚本复现。

本任务找到的是改变探路方向的有限必要模型：旧I1冻结模型的空域不能推广为任意新来源/变质量模型的空域；本候选同时使用新的固定来源几何、nu及共同水平。没有构造L1连续f、nu≤beta≤f dx、完整共同FIRST/history/Psi或唯一j；没有支付q逆权、Pi、hard/time/j及外beta费用。有限正模型不证明一般上界，也不是FULL反例。仅本任务三文件，未操作Git；交付停止。
