#!/usr/bin/env python3
"""Hash verification and separate-process replay using existing local inputs."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=Path);a=p.parse_args()
for name,digest in json.loads((HERE/'manifest.json').read_text())['sha256'].items():
 assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==digest,name
print('Bundle hashes PASS',flush=True)
if a.verify_only:raise SystemExit
if a.output_dir is None:p.error('--output-dir required for replay')
out=a.output_dir.resolve();out.mkdir(parents=True,exist_ok=True);assert out!=HERE
receipt={}
for name in ['future_mixture_probe','joint_first_probe','middle_source_lp','lp_candidate_certificate','lp_refined_certificate']:
 code="""from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
p=Path(sys.argv[1]);spec=importlib.util.spec_from_file_location('replay_module',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.HERE=Path(sys.argv[2]);m.main()
"""
 with (out/(name+'.log')).open('w') as f:subprocess.run([sys.executable,'-B','-c',code,str(HERE/(name+'.py')),str(out)],stdout=f,stderr=subprocess.STDOUT,check=True)
 expected=json.loads((HERE/(name+'.json')).read_text());actual=json.loads((out/(name+'.json')).read_text())
 expected.pop('wall_seconds',None);actual.pop('wall_seconds',None);assert expected==actual,name
 receipt[name]={'all_mathematical_fields_identical':True};print(name,'PASS',flush=True)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
