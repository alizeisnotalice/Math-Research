# 第476轮：保原双来源的锚定父族与全局来源核

## 目标和证明状态

本轮把第475轮的逐来源父族与完整原接受记录接在同一扩展流上：一批规模与接受密度成正比的质量近可加父中，指定锚父保留；原来的两条来源均在锚父之外，原阶段与历史不刷新。该扩展以统一常数保留原流，原来源被锚父捕获的损失只付一次来源质量。

另证明无条件Poisson剪枝产生全局近保核，但归一后的来源密度仍与原密度可比。故不能把随机打包本身误认为根阶收缩。锚定父族的跨来源共同计费仍未取得，原一般目标没有闭合。

## 1. 冻结原输入

$\mu=f dx$，$f\ge0$且$W=\int f<\infty$。实际Lebesgue中心$A\in E$，$a\le R_A\le b\le2a$，$m_A=\mu(Q_A)=q_AR_A^n$，$q\le q_A\le\lambda$，$r=\lambda/q$，$\sigma=q_A dA$，$X=\sigma(E)$。$\pi_A=c_A\mu/m_A$。

完整原接受测度$d\Pi(\xi)$的$(A,y,z)$投影为$\ell(A,y,z)\sigma(dA)\pi_A(dy)\pi_A(dz)$，$0\le\ell\le S$。所有初始、阶段、soft、early、严格质量路径、删除和未来门仍属于$\xi$。父边缘为$t(A)\sigma(dA)$，$0\le t\le S$，$R=|\Pi|$。以下无一处给新父原历史。

独立附加真实来源$x\sim\pi_A$后，来源边缘为$u(x)\mu(dx)$，其中
\[
u(x)=\int t(A)c_A(x)m_A^{-1}d\sigma(A),\qquad R=\int u\,d\mu.
\]
对$u>0$定义实际接受父后验
\[
P_x(dB)=\frac{t(B)c_B(x)}{m_Bu(x)}d\sigma(B),\quad
\gamma_{AB}=\frac{\mu(Q_A\cap Q_B)}{\sqrt{m_Am_B}}.
\]
真实中心CDF $|\{B:x\in Q_B,m_B\le v\}|\le v/q$ 给
\[
\int\gamma_{AB}\frac{c_B(x)}{m_B}d\sigma(B)\le4r,
\qquad \int\gamma_{AB}P_x(dB)\le\alpha_x:=4rS/u(x). \tag{1}
\]
第二式对每个固定相关父$A$成立，而非只对两个随机父平均。$S=0$时原流全零。

## 2. 指定锚父的可测质量打包

固定$x$和捕获$x$的锚父$B$。令$k=\lfloor u(x)/(64rS)\rfloor$，另取$k$个独立$P_x$父，与$B$组成$k+1$个带索引样本。记锚行和$L_B$及全样本有向非对角亲和和$O$。由(1)，
\[
\mathbb E L_B\le k\alpha_x\le1/16,\qquad
\mathbb E O\le\alpha_x k(k+1).
\]
$k\ge1$时设好事件
\[
\mathcal A_{x,B}=\{L_B\le1/2,\ O\le4\alpha_x k(k+1)\}.
\]
Markov及并集界给其概率$p_x(B)\ge1-1/8-1/4=5/8$。$k=0$时直接保留单个锚父，$p_x(B)=1$。

在好事件上删除原样本行和大于$1/2$的所有索引。锚父$B$不被删除，删除数不超过
\[
2O\le8\alpha_x k(k+1)\le(k+1)/2.
\]
保留族$\mathcal F$因此满足
\[
B\in\mathcal F,\quad |\mathcal F|\ge(k+1)/2,\quad
\tfrac12 I\preceq(\gamma_{CD})_{C,D\in\mathcal F}\preceq\tfrac32 I,
\quad
\mu(\cup_{C\in\mathcal F}Q_C)\ge\tfrac23\sum_{C\in\mathcal F}m_C. \tag{2}
\]
所有父均捕获$x$，相同的归一化来源向量不能同时存留。Gram和并集不等式由行和帽、$2\sqrt{m_Cm_D}\le m_C+m_D$及Cauchy–Schwarz给出；没有边界密度帽或质量可比假设。

取Borel版本、按整数$k$分层，样本事件、$p_x(B)$及删行映射均可测。条件于好事件的概率核密度至多$8/5$。这是可测随机族，不声称确定性或原时钟可预测选择。

## 3. 原记录、锚父和两条旧来源同时保留

对任意冻结的可测来源集合$G\subset\{u>0\}$，令$R_G=\int_Gu\,d\mu$。先在同一个原记录上附$x\in G$和$B\sim P_x$，记扩展测度$\Lambda_G$。其$(A,B,x)$投影为
\[
1_G(x)\frac{t(A)t(B)c_A(x)c_B(x)}{m_Am_Bu(x)}
 d\sigma(A)d\sigma(B)d\mu(x), \tag{3}
\]
关于$A,B$对称；具体旧来源及历史仍来自原$\xi$，不进行交换或重采样。

取对称接受权$h_x(A,B)=\min(p_x(A),p_x(B))\in[5/8,1]$，以及方向权
\[
o(A,B)=1_{m_A>m_B}+\tfrac12 1_{m_A=m_B}.
\]
对称性给$\int o h\,d\Lambda_G=\frac12\int h\,d\Lambda_G\ge5R_G/16$。等质量采用独立半概率标记，不遗漏原子。方向后$m_B\le m_A$。

同一原记录上的捕获损失满足
\[
\int o h\,1_{y\in Q_B}d\Lambda_G\le2rS\mu(G),\quad
\int o h\,1_{z\in Q_B}d\Lambda_G\le2rS\mu(G). \tag{4}
\]
证明以$h\le1$、$\ell\le S$正上放，保持$P_x$中的$t(B)$。以$y$为例，内积分是
\[
\int_{m_A\ge m_B}\frac{c_A(x)I_{AB}}{m_A^2}d\sigma(A)\le2r.
\]
使用$I_{AB}\le m_B$及递减包络$\min(m_B^{-2},v^{-2})$，其积分为$2/m_B$；真实CDF因此保留阈值原子并给上述界。外层剩余$\int t(B)c_B(x)d\sigma(B)/(m_Bu(x))=1$。$z$同理。不能将这一估计解释为原来源独立于历史，只是对非负原权的合法支配。

于是存在实际正子流$\Xi_G$，满足
\[
\boxed{|\Xi_G|\ge\frac5{16}R_G-4rS\mu(G).} \tag{5}
\]
它同时具有：原完整记录$\xi$；辅助共同源$x\in Q_A\cap Q_B$；$m_B\le m_A$；原$y,z\in Q_A\setminus Q_B$；以及包含$B$并满足(2)的父族$\mathcal F$。

**准确实现。** 先抽$B$及未条件化的$k$个辅助父，再在$\mathcal A_{x,B}$上以$h_x(A,B)/p_x(B)$薄化，边缘接受概率才是$h$。等价地，先用条件化好事件核，再直接乘$h$。不能在已经条件化后又只乘$h/p_x(B)$。最后保方向和两条旧来源外部事件。原父$A$不要求属于同一父族；也不要求$A$、$B$在同一Poisson实现中同时存活。

这把旧双来源的严格门与新的实际父族接到同一积分，不混用两个不兼容扩展。但不同$x$的父族仍能反复使用相同来源质量，式(2)不能按每个$x$重复收一次$W$。

## 4. 全局近保核说明什么费用尚未下降

几何附件另构造无条件Poisson过程，强度$\nu_x(dB)=t(B)c_B(x)d\sigma(B)/(crS m_B)$，$c>8$。删去亲和行和大于$1/2$的样本；每个实现仍满足(2)的Gram/并集性质，空族按零处理。Palm存活概率$s_x(B)$满足$1-8/c\le s_x(B)\le1$。

记$d_c=crS$，$a_c=1-8/c$。预期来源计数核为
\[
k(x,y)=d_c^{-1}\int t(B)c_B(x)c_B(y)s_x(B)m_B^{-2}d\sigma(B),
\]
去掉$s_x(B)$后的$k_0$对称，行、列皆为$u/d_c$。于是$a_ck_0\le k\le k_0$逐点成立；对称化$\min(k,k^\top)$同样成立，费用不必加倍。

归一成概率核$K/(K1)$后，输入原来源边缘$u\mu$的输出密度满足$a_cu\le\widehat u\le u/a_c$。这个概率核是Campbell预期存活父强度的归一化，等价于按保留人数偏置抽族后均选父；不是普通抽族后均选父。有限Poisson级数证明、可测性和零强度在附件完整列出。

对高来源集$E_L=\{u>L\}$，参考核的边界通量准确为
\[
d_c\int_{E_L\times E_L^c} k_0\,d\mu^2
=\int t(A)\pi_A(E_L)\pi_A(E_L^c)d\sigma(A).
\]
近保性没有给这个量相对高列质量的有偿下界，也没有付清终端。原$y,z$的外部事件(5)不是人工新来源离开$E_L$，两者不能等同。

## 5. 全体原流回代及母账

取$G=\{u>L\}$，低列原流不超过$LW$。由(5)，
\[
R\le\left(L+\frac{64}{5}rS\right)W+\frac{16}{5}|\Xi_G|. \tag{6}
\]
取$L\asymp\sqrt n$只支付低列和捕获损失；还必须对同一$\Xi_G$证明
\[
|\Xi_G|\le\frac5{16}\varepsilon X+C_\varepsilon\sqrt n\log^A(n+2)W
\]
才能得到目标。这仍未证明；不把(6)的增强结构归约当作一般闭合。下一步应针对锚定父族的跨来源列，用原$y,z$而不是刷新来源结算共同质量。

原宽距离、低pe、初始、删除跳跃、未来被删来源、极小尺度比与全尺度拼接费用均未从账中删去。第458轮吸收系数$S\zeta+2S\varepsilon_0/s+2S\delta_{\rm round}$及母倍率仍须与新增$\varepsilon$总和一起核算。没有一般证明，目标继续。

## 6. 实际计算与范围

指定独立Python环境运行Arb及有理算术；最终数值附件统一保存复现，避免重复原生场代码。Poisson概率是有限精确和的严格区间，无Monte Carlo或未核尾截断。原生连续块的占用很低，只核算法与常数；抽象共同/私有来源模型只核代数，不认证立方体几何或原历史。抽象对称模型中归一核完全保留原来源分布，说明不能把剪枝自动记作收缩。

锚定父族有限证书核对成功事件、保锚与规模，不替代上述一般证明。全部证明与条件结论经独立审查，记录实际运行结果；使用64项工具的精确证书原则，不以求解器状态认证连续命题。不编译PDF，只保存详细LaTeX文本和必要复现材料；实际扣额数据不可得。
