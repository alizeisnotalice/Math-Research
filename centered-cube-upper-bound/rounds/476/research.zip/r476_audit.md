# R476 FINAL PASS（限定已列命题，非一般根阶闭合）

独立预审先于作者稿完成，记录于 `r476_audit_pre.md`；后读七项冻结输入并完成本次后审。通过范围是指定锚父的可测随机打包、保原双来源与历史的同流正扩展、一次来源捕获损失、Poisson Campbell 逐点近保及其正确归一化，以及相应条件回代。没有认证原一般余项的根阶 W 预算。

## 数学核验

1. 真实中心质量 CDF 给固定父、固定来源的亲和行界 4r，配合 t≤S 后对每个固定锚 B 都有 E L_B≤kα、E O≤αk(k+1)，不是只对随机锚平均。k=floor[u/(64rS)] 保 kα≤1/16；两事件并集界给 p_x(B)≥5/8。删原 row>.5 的索引数≤2O≤(k+1)/2，锚必留，保留 Gram 谱在 [1/2,3/2] 且 union 质量≥2Σm/3。k=0、重复索引、u=0 与 S=0 分支均有合法约定；Borel 版本及按 k 分层给可测概率核。
2. 原 Π 附 x~π_A 后的 (A,B,x) 父投影确实对称，具体原 y,z 和 history 并未交换。对称 h=min(p_x(A),p_x(B))≥5/8 与含质量平局半分的方向权给定向质量≥5R_G/16。未条件试验乘 1_good·h/p_x(B)，等价于条件 good 试验乘 h；二者没有混用。原 A 无需属于锚 B 的 packing。
3. 捕获损失仅对非负原权正放 ℓ≤S，保持 P_x 内实际 t(B)。闭尾 Stieltjes 式的 −F_x(m_B−) 保留质量原子，内尾≤2r；原 y、z 各收至多 2rS μ(G)，同流 union 一次收 4rS μ(G)。因此实际正子流满足 |Ξ_G|≥5R_G/16−4rSμ(G)，且同时保原来源位于 Q_A\Q_B、共同附源、较小锚与其父族。新父族不继承原路径历史。
4. Poisson 的有限非负级数换指标证明 Campbell 等式；固定 Palm 点生存率≥a_c=1−8/c，给 μ² 密度 a_c k_0≤k≤k_0，故行列同界，min(k,kᵗ) 也无需把损失加到 16/c。有限强度、原子重数及零行均受覆盖。K/(K1) 是人数 size-bias 后选父的 Campbell 归一核，绝非普通抽 packing 后均选父。其输出满足 a_c u≤û≤u/a_c；此近保并不证明收缩、低列或新 W 预算。
5. 对 G={u>L}，低列质量≤LW，正子流不等式精确回代为 R≤(L+64rS/5)W+(16/5)|Ξ_G|。主稿的目标残项系数 5ε/16 与此匹配。全部旧门及继承母账费用仍保留；未把恢复常数或辅助族的逐实现 union 质量当跨来源共享付款。尚缺同一 Ξ_G 的整体来源列结算及一般上界。

## 实际独立复现与证据范围

使用指定 Python 环境，在新隔离目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r476_audit_ho007ago` 提取互补稿内嵌代码并复制数值脚本运行：互补稿 PASS 45 Fraction assertions；numeric PASS 151 checks。两份 stdout 与冻结 replay 逐字一致；数值 JSON 删除唯一计时字段 `compute_index.seconds` 后完全一致，canonical SHA256 为 `af63c76d77d5988e467d032fd545b411f51f194e805ba17694eb3dba9b27339c`。

数值原生证书只含低占用一维连续中心/完整来源块，匹配及实际 CDF 行已核；共同/私有来源压力场和三组锚定 Gram 是明确抽象有限入射模型，不认证立方体实现、高占用原场、原严格门或完整 history。概率采用完整有限 Poisson 公式和 240-bit Arb 包围，无 Monte Carlo 或未付截尾。geometry 所述此前实际 114 项核验仅按作者事实记录，不冒称本审计重跑，也不加入必要归档复现统计。原生低占用、抽象高占用与一般连续证明的范围没有互换。

## 冻结字节绑定

- `r476_main.md`: `5f9f8b9b36c0e6875c43b15f1670ae2b2387d913092429af3693b582877c2482`
- `r476_geometry.md`: `e1f37a6667018816dab2b87e8fa18be38994f73e976f60acb22c4f90e7a8be8b`
- `r476_complement.md`: `a30e96d4f9faf36b578d35a4a2797922fabdf87846e67568ffedb2751c1f0013`
- `r476_numeric.md`: `a29e22341eab815fab060ad07f32510171eb94fbdf4771a0c4f83011130afb41`
- `r476_numeric.py`: `6afa365490b214054d7f6c5cc0f5e621afa5fd7cb30f03d87ec68c141adc8355`
- `r476_numeric.json`: `47d916562cb82e789aa4056d1ba32b761b013eb97e96313c30f2938a7be31b38`
- `r476_replay.json`: `461b6a6749ba132a998f2ac3db9ac24a73632b09f92486a4f5e17488fbd5672e`
