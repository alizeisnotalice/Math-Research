# R476：保原两来源的定向外部泄漏

本稿证明共同来源随机父计划的一条常数 \(W\) 捕获损失：不重采原 \(y,z\)，质量定向保留恰好半流，其中原任一来源仍被代表父捕获的联合费用至多 \(4rSW\)。外部泄漏后的跨来源列尚未获得根阶上界；本稿不把半量泄漏称为全余付款。

## 1. 原记录不变的随机扩充

沿原合同 \(\mu=f\,dx,\sigma=q_A dA,m_A=\mu(Q_A),\pi_A=c_A\mu/m_A\)，\(r=\lambda/q\)。原记录记为 \(\xi\)，其中包含 \(A,y,z\) 及全部阶段、时钟、路径与接受门。准确静态投影为
\[
 d\Pi=\ell(A,y,z)\sigma(dA)\pi_A(dy)\pi_A(dz),\quad0\le\ell\le S,
 \quad t(A)=\int\ell\,d\pi_A^2.
\]
令 \(u(x)=\int t(A)c_A(x)d\sigma(A)/m_A\)。对任意冻结可测来源集 \(G\)，附加 \(x\sim\pi_A\)，在 \(x\in G,u(x)>0\) 上抽
\[
 P_x^t(dB)=\frac{t(B)c_B(x)}{m_Bu(x)}\sigma(dB).               \tag{1}
\]
原记录不变；\(B\) 只有实际几何与接受父边缘支持，不继承任何具体历史。记扩充测度为 \(\Omega_G\)，其总质量
\(R_G=\int_Gu\,d\mu\)。零 \(u\) 的来源无原扩充质量。

置 \(o(A,B)=1_{m_A>m_B}+\tfrac12 1_{m_A=m_B}\)。积分原 \(y,z\) 与其他原标签后，\((A,B)\) 的密度为
\[
 1_G(x)\frac{t(A)t(B)c_A(x)c_B(x)}{m_Am_Bu(x)}
       d\mu(x)d\sigma(A)d\sigma(B),
\]
它对称，故包括所有质量原子及平局，
\[
 \int o\,d\Omega_G=R_G/2.                                   \tag{2}
\]
(2) 不要求 \(\ell(A,y,z)\) 对称，更不把 \(t(A)\) 当作原记录的双来源接受权。

## 2. 原来源捕获损失的真实中心费用

对固定 \(x,B\)，真实匹配给 \(I_{AB}=\mu(Q_A\cap Q_B)\le m_B\)。实际中心质量 CDF 满足
\(F_x(s)=|\{A:x\in Q_A,m_A\le s\}|\le s/q\)。因此
\[
 \begin{split}
 \int_{m_A\ge m_B}\frac{c_A(x)I_{AB}}{m_A^2}d\sigma(A)
 &\le\lambda m_B\int_{[m_B,\infty)}s^{-2}dF_x(s)\\
 &=\lambda m_B\left[-\frac{F_x(m_B-)}{m_B^2}
              +2\int_{m_B}^{\infty}\frac{F_x(s)}{s^3}ds\right]
 \le2r.                                                     \tag{3}
 \end{split}
\]
左极限保留起点原子；没有将可变边长选择器换成固定半径薄层。

仅在估计原捕获支时正上放 \(\ell\le S\)，先积原 \(z\)、再积 \(y\in Q_A\cap Q_B\)，由 (3) 得
\[
 \begin{split}
 \int o\,c_B(y)d\Omega_G
 &\le S\int_G\frac{d\mu(x)}{u(x)}
 \int\frac{t(B)c_B(x)}{m_B}d\sigma(B)
 \int_{m_A\ge m_B}\frac{c_A(x)I_{AB}}{m_A^2}d\sigma(A)\\
 &\le2rS\mu(G\cap\{u>0\}).                               \tag{4}
 \end{split}
\]
换 \(y,z\) 的积分次序得到同样的 \(2rS\mu(G\cap\{u>0\})\)；不需要原接受权对称。于**同一** \(\Omega_G\) 上，令
\[
 R_{\rm out}=\int o(A,B)(1-c_B(y))(1-c_B(z))d\Omega_G.
\]
联合捕获事件用并集上界一次收费，准确得到
\[
 \boxed{R_G/2\le4rS\mu(G\cap\{u>0\})+R_{\rm out}.}          \tag{5}
\]
剩余保原 \(y,z\in Q_A\setminus Q_B\)、\(x\in Q_A\cap Q_B\)、\(m_B\le m_A\) 及全部原门。没有重采原来源，没有来源密度帽，没有分带或阶段次数。取 \(G=\{D>d\}\)，与原低 \(D\) 收据同序可写
\[
 R\le SdW+8rSW+2R_{\rm out}.                               \tag{6}
\]
这不是收缩：\(R_{\rm out}\) 的原权仍未付，系数二是恢复半流的真实代价。

## 3. 原门能用到哪里，不能用到哪里

这与 R474 从较大父重新抽来源的回落估计不同：(4) 的 \(y,z\) 就是原门所约束的来源，因此 high-\(Z\)、low-common、early 及原路径条件全部留在外部记录上。固定 \(A,B\) 时还有真实质量上放
\[
 \int\ell(A,y,z)(1-c_B(y))(1-c_B(z))d\pi_A^2
 \le S\left(1-\frac{I_{AB}}{m_A}\right)^2.                   \tag{7}
\]
它保来源差集质量，不把差集体积当作 \(f\) 质量。

然而这些门目前未控制外部原来源的跨父重复。精确退出 \(y\) 列是
\[
 \frac{d(\Omega_G^{\rm out})_y}{d\mu}(y)=
 \int\frac{c_A(y)}{m_A}d\sigma(A)
 \int\ell(A,y,z)d\pi_A(z)
 \int_G d\pi_A(x)\int P_x^t(dB)o(A,B)
                    (1-c_B(y))(1-c_B(z)),                  \tag{8}
\]
目前合法上界仅 \(S D(y)\)，总价 \(SX\)。原 high-\(Z\) 反而保证该原 \(y\) 上 \(D(y)\ge qZ_A(y)\) 大，不能用低占用收据消去 (8)。low-common 控制捕获原 \(y\) 的严格较小见证是否也捕获 \(z\)；当前 \(B\) 同时不捕获二者，所以不能把 \(B\) 当作该门中的合格见证。

因此本机制的实质是有一次 \(W\) 价格的**原来源**捕获损失与精确半量外泄；完整目标还需要将 (8) 的原接受权列结算，而不是用“每次离开一个盒子”推断跨 \(x\) 不重复。未取得该结算，不扩展辅助历史或另加阈值支。

## 4. 与指定锚父打包核的同流接口

以上捕获证明对任意额外可测 \(0\le\chi(A,B,x)\le1\) 都成立：仅将原同一 \(\Omega_G\) 乘 \(\chi\)，(4) 的两项价格仍各不超过 \(2rS\mu(G\cap\{u>0\})\)。若另外 \(\chi\) 对 \(A,B\) 对称且 \(\chi\ge c_{\rm surv}>0\)，则
\[
 \int o\chi\,d\Omega_G=\tfrac12\int\chi\,d\Omega_G
 \ge\frac{c_{\rm surv}}2R_G,
\quad
 \frac{c_{\rm surv}}2R_G
 \le4rS\mu(G\cap\{u>0\})+R_{\rm out}^{\chi}.                 \tag{9}
\]
其中 \(R_{\rm out}^{\chi}\) 保留同一原记录、\(\chi\)、定向与双外部标签。

具体地，假设另已构造以 \(B\) 为指定锚父的可测随机打包试验 \(Q_{x,B}(d\omega)\)，成功事件 \(E_{x,B}\) 上 \(B\) 确实保留，成功概率 \(p_x(B)\ge c_{\rm surv}\)。令
\(\chi(A,B,x)=\min(p_x(A),p_x(B))\)。在 (1) 抽出 \(B\) 后使用**未条件化**试验并乘
\[
 1_{E_{x,B}}\frac{\chi(A,B,x)}{p_x(B)}\le1,                  \tag{10}
\]
其 \((\xi,x,B)\) 边缘恰为 \(\chi\,d\Omega_G\)。等价地，抽取条件试验 \(Q_{x,B}(\cdot\mid E_{x,B})\) 后直接乘 \(\chi\)。若条件化后又仅乘 \(\chi/p_x(B)\)，则会少计原成功概率，不能使用 (9)。这里不要求 \(A\) 也在该打包中，亦未赋打包父原历史。

因此主稿若独立证明 \(p_x(B)\ge5/8\)，本稿接口准确给 \(5R_G/16\) 的定向质量与同一 \(4rS\mu(G)\) 联合捕获价。此处只证明接口，不重复或预设打包存在性证明，也不把一般正规化代表核当作 \(\chi\) 次概率核。

## 5. 实际有限核验

下列脚本已执行，stdout 为 `PASS 45 Fraction assertions: actual-parent mark orientation and original-two-source leakage; incidence algebra only`。三种非对称原接受权、三个来源阈值检验平局半分、同一双来源并集/外部补集及 (4) 的代数；中心尾常数用该模型直接算出的数，不冒称有限 incidence 已认证 native CDF 常数 \(2r\)。通用连续证明为 (3)–(4)。

```python
from fractions import Fraction as F
mu=[F(1),F(3),F(12)];sig=[F(1,3),F(1,4),F(1,5)]
c=[[1,0,0],[1,1,0],[1,1,1]];m=[F(1),F(4),F(16)]
checks=0
for mode in range(3):
 ell=lambda A,y,z:F(1) if mode==0 else F((A+2*y+z+mode)%5,5)
 t=[sum(mu[y]*mu[z]*c[A][y]*c[A][z]*ell(A,y,z)/m[A]**2 for y in range(3) for z in range(3)) for A in range(3)]
 u=[sum(t[A]*sig[A]*c[A][x]/m[A] for A in range(3)) for x in range(3)]
 for threshold in [F(0),min(u),max(u)]:
  total=oriented=hit_y=hit_z=union=escape=F(0)
  for A in range(3):
   for B in range(3):
    o=F(1) if m[A]>m[B] else F(1,2) if m[A]==m[B] else F(0)
    for x in range(3):
     if not u[x]>threshold:continue
     for y in range(3):
      for z in range(3):
       base=sig[A]*mu[y]*mu[z]*c[A][y]*c[A][z]*ell(A,y,z)/m[A]**2
       base*=mu[x]*c[A][x]/m[A]*t[B]*sig[B]*c[B][x]/(m[B]*u[x])
       total+=base;oriented+=base*o
       hit_y+=base*o*c[B][y];hit_z+=base*o*c[B][z]
       union+=base*o*int(c[B][y] or c[B][z])
       escape+=base*o*(1-c[B][y])*(1-c[B][z])
  assert oriented==total/2;checks+=1
  assert oriented==union+escape;checks+=1
  assert union<=hit_y+hit_z;checks+=1
  price=sum(mu[x] for x in range(3) if u[x]>threshold)
  # Measured finite-model tail constant; not a native 2r certificate.
  tail=max(sum(sig[A]*c[A][x]*sum(mu[y]*c[A][y]*c[B][y] for y in range(3))/m[A]**2 for A in range(3) if m[A]>=m[B]) for x in range(3) for B in range(3))
  assert hit_y<=tail*price;checks+=1
  assert hit_z<=tail*price;checks+=1
print('PASS',checks,'Fraction assertions: actual-parent mark orientation and original-two-source leakage; incidence algebra only')
```
