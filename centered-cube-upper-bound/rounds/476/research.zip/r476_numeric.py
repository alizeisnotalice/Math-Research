from fractions import Fraction as F
from pathlib import Path
from math import factorial
import sys,platform,json,time
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=240
start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator

def sf(v):return str(v)
def cdf(k,lam):
 return (-ar(lam)).exp()*sum((ar(lam)**j/factorial(j) for j in range(k+1)),arb(0))
def survival(lamself,lamothers,g):
 k=int(F(1,2)//g)
 ck(k*g<=F(1,2)<(k+1)*g)
 return (-ar(lamself)).exp()*cdf(k,lamothers),k

# Whole positive-volume source packets and receiver blocks, independent
# Lebesgue domains. Each tuple stores packet center, halfwidth, full mass.
packets=[(F(-83,100),F(1,100),F(3)),(F(0),F(1,100),F(1)),(F(83,100),F(1,100),F(8))]
centers=[F(-2,5),F(2,5)];length=[F(1,100)]*2;sides=[F(1),F(9,5)]
cap=[];margins=[]
for A in range(2):
 row=[];mr=[]
 for x,hw,m in packets:
  far=abs(centers[A]-x)+length[A]/2+hw
  near=max(F(0),abs(centers[A]-x)-length[A]/2-hw)
  if far<sides[A]/2:row.append(1);mr.append(sides[A]/2-far)
  else:ck(near>sides[A]/2);row.append(0);mr.append(near-sides[A]/2)
 cap.append(row);margins.append(mr)
ck(cap==[[1,1,0],[0,1,1]])
ck(abs(centers[0]-centers[1])>(length[0]+length[1])/2)
mu=[p[2] for p in packets]
m=[sum(mu[x]*cap[A][x] for x in range(3)) for A in range(2)]
ck(m==[F(4),F(9)])
q=[m[A]/sides[A] for A in range(2)];sig=[q[A]*length[A] for A in range(2)]
r=max(q)/min(q);ck(r==F(5,4))
g=[[F(1),F(1,6)],[F(1,6),F(1)]]
ck(sum(mu[x]*cap[0][x]*cap[1][x] for x in range(3))==1)
# Actual center CDF at all jumps, separately for every source packet.
for x in range(3):
 for v in sorted(set(m)):
  actual=sum(length[A]*cap[A][x] for A in range(2) if m[A]<=v)
  ck(actual<=v/min(q))
# Verify each used pointwise row bound, not merely its source average.
rows=[]
for x in range(3):
 vals=[]
 for A in range(2):
  if cap[A][x]:
   z=sum(sig[B]*cap[B][x]*g[A][B]/m[B] for B in range(2))
   ck(z<=4*r);vals.append(str(z))
 rows.append(vals)

cases=[]
for cp in (16,32,64):
 for x in range(3):
  lam=[sig[A]*cap[A][x]/(cp*r*m[A]) for A in range(2)]
  s=[]
  for A in range(2):
   if not cap[A][x]:s.append(arb(0));continue
   z,k=survival(lam[A],lam[1-A],F(1,6));ck(k==3)
   ck(z>1-ar(F(8,cp)));s.append(z)
  ratios=[]
  for y in range(3):
   B=sum(lam[A]*cap[A][y]/m[A] for A in range(2))
   K=sum((ar(lam[A]*cap[A][y]/m[A])*s[A] for A in range(2)),arb(0))
   if B:
    z=K/ar(B);ck(z>1-ar(F(8,cp)));ratios.append(dict(source_y=y,K_over_B=sf(z)))
   else:ck(K==0)
  u=sum(sig[A]*cap[A][x]/m[A] for A in range(2))
  up=sum((ar(sig[A]*cap[A][x]/m[A])*s[A] for A in range(2)),arb(0))
  cases.append(dict(phase='native_initial_and_tie_pressure',scope='NATIVE continuous 1D wholecapture static field, true CDF rows checked; no original history',cparam=cp,source_x=x,source_mass=str(mu[x]),u=str(u),nu=list(map(str,lam)),poisson_total_mean=str(sum(lam)),Palm_survival=list(map(sf,s)),pointwise_K_over_B=ratios,scaled_retained_occupancy=sf(up),expected_kept_parent_count=sf(up/ar(cp*r)),low_u=True))
# Abstract common+private indicator Gram fields, NOT cubes or native CDF.
# Every parent has common mass1 + private mass(qden-1), so g_off=1/qden.
# The reference source is common; per-parent raw occupancy weight=1.
for N,den in [(13,4),(49,16)]:
 ck(1+F(N-1,den)==4)
 for cp in (16,32,64):
  lam=F(1,cp);g0=F(1,den)
  s,k=survival(lam,(N-1)*lam,g0)
  ck(s>1-ar(F(8,cp)))
  uret=N*s
  # By symmetry K/B=s on common and every private target source.
  ck(s>0);ck(s<1)
  if N==49:ck(uret>32)
  # Normalization removes the row survival scalar in this symmetric model.
  # The two classes are common (mass1) and all private sources together.
  stationary=[F(1,den),F(den-1,den)]
  transition=[stationary[:],stationary[:]]
  for j in range(2):ck(sum(stationary[i]*transition[i][j] for i in range(2))==stationary[j])
  ck(sum(stationary)==1)
  # On every individual private source, the unique eligible parent is
  # unchanged; on common source all parent survivals equal. Thus this
  # aggregation reflects equality of the entire normalized kernels.
  cases.append(dict(normalized_kernel_equals_unpruned=True,normalized_source_stationary_classes=list(map(str,stationary)),normalized_class_transition=[[str(z) for z in rr] for rr in transition],stationary_original_occupancy_preserved=True,phase='abstract_common_private_pressure' if N==13 else 'abstract_high_u_expanded',scope='ABSTRACT-RANK indicator Gram only; no actual cube/CDF/history qualification',N=N,parent_mass=den,common_mass=1,private_mass_each=den-1,g_off=str(g0),cparam=cp,nu_each=str(lam),poisson_total_mean=str(N*lam),Palm_threshold_other_count=k,exact_expected_g_row=str(F(4,cp)),Palm_survival=sf(s),all_nonzero_pointwise_K_over_B=sf(s),retention_lower_bound=str(1-F(8,cp)),unpruned_u=N,scaled_retained_occupancy=sf(uret),expected_kept_parent_count=sf(uret/cp),retained_u_still_above_32=N==49))
# Anchored packing supplement: exact finite indicator Gram, not cubes.
anchored=[]
for N,expected_k in [(32,1),(64,3),(128,6)]:
 alpha=F(512+N-1,512*N);k=int(1/(16*alpha));ck(k==expected_k)
 threshold=4*alpha*k*(k+1)
 distinct_anchor_row=F(k,512);distinct_total=F(k*(k+1),512)
 ck(distinct_anchor_row<=F(1,2));ck(distinct_total<=threshold)
 # An anchor repeat makes anchor row at least1. If anchor is unique,
 # any repeated iid parent gives an ordered offdiagonal pair of weight2.
 ck(F(1)>F(1,2));ck(threshold<2)
 probability=F(1)
 for j in range(1,k+1):probability*=F(N-j,N)
 ck(probability>=F(5,8))
 # On good, all rows already have sum k/512 <= .5. No deletion occurs.
 kept=k+1;ck(kept>=F(k+1,2));ck(distinct_anchor_row<=F(1,2))
 anchored.append(dict(N=N,g_off='1/512',alpha_exact=str(alpha),k=k,ordered_off_threshold=str(threshold),distinct_ordered_total=str(distinct_total),distinct_anchor_and_other_row=str(distinct_anchor_row),anchor_repeat_min_row='1',nonanchor_repeat_min_ordered_total='2',good_iff_all_k_plus_one_distinct=True,good_probability=str(probability),good_probability_at_least_5_over_8=True,anchor_kept=True,kept_size_on_good=kept,scope='FINITE INDICATOR GRAM ONLY; no native cube or original history'))
result=dict(scope='Exact unconditional Campbell/Palm pruning probabilities. Native low-intensity field and separately labelled abstract Gram stress fields.',compute_index=dict(executable=sys.executable,python=platform.python_version(),arb_precision_bits=ctx.prec,seconds=time.perf_counter()-start,command='"'+sys.executable+'" r476_numeric.py'),native_geometry=dict(source_packets=[list(map(str,p)) for p in packets],center_centers=list(map(str,centers)),center_lengths=list(map(str,length)),sides=list(map(str,sides)),capture=cap,wholeblock_capture_margins=[[str(v) for v in row] for row in margins],masses=list(map(str,m)),q=list(map(str,q)),sigma=list(map(str,sig)),r=str(r),true_pointwise_row_values=rows),cases=cases,anchored_packing_supplement=anchored,checks=checks,errors='All input geometry, Gram values and thresholds rational exact; finite Poisson CDF polynomial times exp enclosed by 240-bit Arb, no truncated tail or Monte Carlo. Native per-source cases 9, abstract symmetric cases 6.')
(ROOT/'r476_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'checks; existing Poisson fields plus 3 exact anchored Gram certificates; no history claim')
