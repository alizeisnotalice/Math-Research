# R476：Poisson 父打包、近保来源核与未付高列通量

## 1. 同一实际场

沿 R475：\(\mu=f\,dx\)，\(\sigma=q_A\,dA\)，\(m_A=\mu(Q_A)=q_AR_A^n\)，\(q\le q_A\le\lambda\)，\(r=\lambda/q\)。实际原流 \(\Pi\) 的父边缘为 \(t(A)\sigma(dA)\)，\(0\le t\le S\)。令
\[
 u(x)=\int\frac{t(A)c_A(x)}{m_A}\sigma(dA),\quad
 \gamma_{AB}=\frac{\mu(Q_A\cap Q_B)}{\sqrt{m_Am_B}}.
\]
原流附独立真实来源 \(x\sim\pi_A\) 后的来源边缘正是 \(u\mu\)，总质量 \(R=\int u\,d\mu\)。这不改变原标签。R475 的真实中心质量 CDF 证明给
\[
 \int\frac{c_B(x)}{m_B}\gamma_{AB}\,\sigma(dB)\le4r.
 \tag{1}
\]
全篇 \(S=0\) 或 \(u(x)=0\) 的核取零。以下取常数 \(c>8\)，记 \(a_c=1-8/c>0\)、\(d_c=crS\)。

## 2. 不条件化的 Poisson 打包与逐点近保

固定 \(x\)，取有限 Poisson 父过程，强度
\[
 \nu_x(dA)=\frac{t(A)c_A(x)}{d_c m_A}\sigma(dA).
\]
逐实现删除与其余样本的 \(\gamma\) 行和大于 \(1/2\) 的样本。保留族每行非对角和不超过 \(1/2\)，故其 Gram 谱在 \([1/2,3/2]\)，且
\(\mu(\cup Q_A)\ge(2/3)\sum m_A\)，证明与 R475 相同，适用于每个有限实现。

这里所需的 Campbell–Mecke 等式可直接由有限 Poisson 级数证明，不另假设输运定理。固定 \(x\)，记 \(\ell=\nu_x(E)<\infty\)，对任意非负可测点配置函数 \(F\)，Tonelli 及交换样本索引给
\[
\begin{aligned}
 \mathbb E\sum_{A\in\mathcal N}F(A,\mathcal N-\delta_A)
 &=e^{-\ell}\sum_{n\ge1}\frac1{n!}
   \int\sum_{i=1}^n F(A_i,\sum_{j\ne i}\delta_{A_j})\,d\nu_x^{\otimes n}\\
 &=\int\nu_x(dA)\,e^{-\ell}\sum_{m\ge0}\frac1{m!}
   \int F(A,\sum_{j=1}^m\delta_{B_j})\,d\nu_x^{\otimes m}\\
 &=\int\nu_x(dA)\,\mathbb E F(A,\mathcal N).
\end{aligned}
\]
所有项非负，换序无须预设可积；有限强度的零情形直接取零。配置保留重数，故等式也覆盖原子强度。取 \(F\) 为插入点的存活指示，或再乘其来源积分，分别得到下面的计数与核公式。

在 Palm 条件下插入父 \(A\)，其余过程仍为强度 \(\nu_x\) 的 Poisson 过程。由 (1) 及 \(t\le S\)，其随机行和 \(Z\) 满足
\[
 \mathbb E Z=\int\gamma_{AB}\nu_x(dB)\le4/c.
\]
故 Palm 存活概率 \(s_x(A)=\Pr(Z\le1/2)\) 满足
\[
 a_c\le s_x(A)\le1.\tag{2}
\]
这是对每个相关 \((x,A)\) 的一致界，不只是总数平均。Mecke 公式给
\[
 \mathbb E\#\mathrm{ret}\ge a_c\frac{u(x)}{d_c}.
\]
标准 Borel 中心空间上的可测有限强度核给可测 Poisson 核；有限样本的删行规则可测。这里没有额外成功事件条件化。新父来自真实接受父边缘，但不继承某条原记录的历史。

定义实际来源输运
\[
 K(x,dy)=\mathbb E\sum_{A\in\mathrm{ret}}\pi_A(dy)=k(x,y)\mu(dy).
\]
Mecke 给其明确密度
\[
 k(x,y)=\frac1{d_c}\int\frac{t(A)c_A(x)c_A(y)}{m_A^2}s_x(A)\sigma(dA).
\tag{3}
\]
去掉 \(s_x\) 的密度记 \(k_0\)。\(k_0\) 对称，且 \(\int k_0(x,y)d\mu(y)=u(x)/d_c\)。因此
\[
 a_c k_0\le k\le k_0.\tag{4}
\]
所以行、列都处于 \([a_cu/d_c,u/d_c]\)。对称化
\(k_{\rm sym}(x,y)=\min(k(x,y),k(y,x))\) 仍满足 (4)：损失只需 \(8/c\)，不必 \(16/c\)。其总质量至少 \(a_cR/d_c\)，逐点行也同样近保。对称化通过削减输运边实现，不声称它本身仍是未加权的随机保留族。

## 3. 质量守恒接回原流后的决定性限制

令 \(r_K(x)=\int k(x,y)d\mu(y)\)，在 \(u>0\) 上用概率核 \(K/r_K\) 附加新来源。它保留原完整记录和全部历史，只给新来源添加辅助标签。其抽样含义是按保留人数对 packing 的原分布作 size-bias，再在该族中均匀选父并从其 \(\pi_A\) 抽源；等价于归一化 Campbell 强度。它不是先按普通 packing 分布抽族再均匀选父，后者给 \(\mathbb E[\sum\pi_A/\#\mathrm{ret}]\)，与本核一般不同。输出密度为
\[
 \widehat u(y)=\int\frac{u(x)}{r_K(x)}k(x,y)d\mu(x),
 \qquad \boxed{\ a_cu(y)\le\widehat u(y)\le u(y)/a_c\ }.\tag{5}
\]
证明：\(d_c\le u/r_K\le d_c/a_c\)，再积分 (4)。同样适用于 \(k_{\rm sym}\)。所以该近保打包输运没有把高 \(u\) 列变成 \(O(\sqrt n)\) 的来源容量；其输出实际上逐点保留至少 \(a_c\) 比例的原占用。若另以来源帽 \(L\) 截流，必失去至少
\(\int(a_cu-L)_+d\mu\)，此量尚未支付。

唯一仍需的几何桥可明确落到真实高列边界通量。对 \(E_L=\{u>L\}\)，未删核的逃逸量精确为
\[
 d_c\int_{E_L}\!\int_{E_L^c}k_0(x,y)d\mu(y)d\mu(x)
 =\int t(A)\pi_A(E_L)\pi_A(E_L^c)\sigma(dA).
\tag{6}
\]
删行及对称化后的通量介于右侧的 \(a_c/d_c\) 与 \(1/d_c\) 倍。逐实现质量打包并未给 (6) 对 \(\int_{E_L}u\) 的有偿下界；需要原接受门与真实父共同捕获来证明这一类联合比较，并支付低列容量及终端。\(x,y\) 是人工附源，原 high-rank/low-common 门不能自动用于它们。故本轮已构造合法全局近保核及强化逐点对称化界，但没有新增原 \(R\) 的根阶 \(W\) 付款，也不把 (6) 的改写算作闭合。

## 4. 本机核验范围

作者已实际运行同一原生静态连续中心块参数的 6 个 Poisson 核案例，114 项 Arb 区间断言全部通过；仅核计数/核公式、逐点帽、对称化及归一化输出界，不认证原历史。最终可复现代码与压力参数由本轮 numeric 附件统一覆盖，此处不重复归档代码，114 项不计入必要归档核验总数。
