#!/usr/bin/env python3
"""One real public-price Palm coupling versus hidden-old and actual-root couplings."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform


ROWS_SHA="04bbd600cd68bd2bb371559590a1902b97a345c02404ffc759a1147fb4b2bae9"
CLOUD_SHA="36f7170fef276bb5924e6b73dbc04a9b2803215248e1c43cc7852db7e62223fe"


def gate(a,b):
    u,i,below=a
    v,j,other=b
    return (u==v and i==j) or (u!=v and i==0 and j==1 and below and not other)


def matrices(n):
    return [[F(0) for _ in range(n)] for _ in range(n)]


def metrics(table, hit, meet, base, norm=None):
    n=len(table)
    size=base.total(w for row in table for w in row)
    if norm is not None:
        assert size==norm
    assert size>0
    count=base.total(table[i][i] for i in range(n))
    first=base.total(table[i][j]*hit[i][j] for i,j in product(range(n),repeat=2))
    second=base.total(table[i][j]*meet[i][j] for i,j in product(range(n),repeat=2))
    assert 0<=count<=second<=first<=size
    return dict(total=size,unnormalized_single_hit=first,unnormalized_overlap=second,
                unnormalized_same_old=count,means=dict(hit=first/size,overlap=second/size,same_old=count/size))


def compare(A,B):
    return {k:A["means"][k]-B["means"][k] for k in A["means"]}


def observed_price_slot(base, T,U,shares,amp,cloud):
    E=[base.owner(q,a) for q,a in zip(T,shares)]
    owner=[base.owner(q,F(1)) for q in U]
    sorted_E=sorted(E+owner)
    assert all(a[1]<b[0] for a,b in zip(sorted_E,sorted_E[1:]))
    mu=lambda q:base.real_mass(q,amp)
    m=list(map(base.length,T))
    s=list(map(base.length,U))
    I=list(map(base.length,E))
    j=list(map(base.length,owner))
    assert [mu(q) for q in T+U]==m+s
    cuts=sorted({*base.SOURCE,F(2),F(49,16),*(F(i,4) for i in range(-32,33)),
                 *(v for q in T+U for v in q)})
    cells=list(zip(cuts,cuts[1:]))
    assert cells==[tuple(F(q) for q in B) for B in cloud["true_price_atoms"]]
    price_mass=list(map(mu,cells))
    assert all(p/base.length(q) in (1-amp,1+amp) for p,q in zip(price_mass,cells))
    rec=[[(A[0],base.point(A)),(base.point(A),A[1])] for A in owner]
    for u,R in enumerate(rec):
        for interval in R:
            assert [v for v,A in enumerate(owner) if A[0]<base.point(interval)<A[1]]==[u]
    n=len(U)
    rooted=defaultdict(lambda:matrices(n))
    complete=defaultdict(lambda:defaultdict(F))
    first=defaultdict(F)
    second=defaultdict(F)
    predicted_first=defaultdict(F)
    predicted_second=defaultdict(F)
    total_paths=F(0)
    same=F(0)
    old_degrees=[]
    roots=[]
    witnesses={}
    for t,A in enumerate(T):
        d=F(0)
        bucket=defaultdict(list)
        for u,B in enumerate(U):
            Q=base.clip(A,B)
            qm=mu(Q)
            if not qm or s[u]>=m[t]:
                continue
            K=qm/(m[t]*s[u])
            d+=j[u]*K
            for a,h in product(range(len(cells)),(0,1)):
                if base.inside(cells[a],Q):
                    arm=j[u]*K*price_mass[a]/qm*base.length(rec[u][h])/j[u]
                    assert arm==price_mass[a]*base.length(rec[u][h])/(m[t]*s[u])
                    sig=(u,h,cells[a][1]<=2)
                    bucket[sig].append((u,a,h,arm))
        old_degrees.append(d)
        S={k:base.total(r[3] for r in ls) for k,ls in bucket.items()}
        assert d==base.total(S.values())
        factor=I[t]/d
        allowL={f:base.total(v for g,v in S.items() if gate(f,g)) for f in S}
        allowR={g:base.total(v for f,v in S.items() if gate(f,g)) for g in S}
        two_order=factor*base.total(S[f]*p for f,p in allowL.items())
        assert two_order==factor*base.total(S[g]*p for g,p in allowR.items())
        for f,ls in bucket.items():
            for u,a,h,w in ls:
                predicted_first[u,a]+=factor*w*allowL[f]
                predicted_second[u,a]+=factor*w*allowR[f]
        direct=F(0)
        for (p,left),(q,right) in product(bucket.items(),repeat=2):
            if not gate(p,q):
                continue
            for (u,a,i,v),(g,b,k,w) in product(left,right):
                real=factor*v*w
                direct+=real
                first[u,a]+=real
                second[g,b]+=real
                rooted[a,b][u][g]+=real
                complete[(a,b,g,k)][u]+=real
                complete[(b,a,u,i)][g]+=real
                if u==g:
                    same+=real
                key=(a,b,u,g)
                if key not in witnesses:
                    witnesses[key]=dict(actual_middle=t,full_original_d=d,physical_old_left=u,physical_old_right=g,
                         actual_left_price=cells[a],actual_right_price=cells[b],actual_U=rec[u][i],actual_V=rec[g][k],
                         original_weight=real)
        assert 0<direct==two_order<I[t]*d
        total_paths+=direct
        roots.append(dict(t=t,d=d,actual_unmarked=I[t]*d,actual_marked=direct))
    assert old_degrees==list(map(F,cloud["true_original_d"]))
    assert first==predicted_first and second==predicted_second
    assert total_paths==base.total(first.values())==base.total(second.values())==F(cloud["original_screened_true_path_total"])
    assert same==F(cloud["same_real_old_parent_path_total"])
    full=defaultdict(F)
    for a,posterior_num in complete.items():
        z=a[0]
        for u,value in posterior_num.items():
            full[u,z]+=value
    J=[base.total(w for (i,z),w in full.items() if i==u) for u in range(n)]
    assert J==list(map(F,cloud["original_combined_J_u"])) and base.total(J)==2*total_paths
    assert all(full[u,z]==first[u,z]+second[u,z] for u,z in product(range(n),range(len(cells))))
    pi=[[full[u,z]/J[u] for z in range(len(cells))] for u in range(n)]
    assert pi==[list(map(F,row)) for row in cloud["normalized_cloud_pi_u"]]
    hit=[[base.total(w for x,w in zip(cells,pi[u]) if base.inside(x,U[v])) for v in range(n)] for u in range(n)]
    assert hit==[list(map(F,row)) for row in cloud["all_frozen_real_pi_hits"]]
    meet=[[base.total(min(x,y) for x,y in zip(pi[u],pi[v])) for v in range(n)] for u in range(n)]
    assert all(hit[u][u]==meet[u][u]==1 for u in range(n))
    return dict(cells=cells,U=U,E=E,owner=owner,rec=rec,price_mass=price_mass,d=old_degrees,stages=roots,
                actual_root_mass=total_paths,actual_original_same_old_root_mass=same,
                source_u_price=full,actual_complete_rows=complete,both_actual_slots_mass=base.total(J),
                rooted_by_both_prices=rooted,real_root_witnesses=witnesses,frozen_J=J,hit=hit,meet=meet)


def main_palm(book,z0,base):
    pts=book["cells"]
    μ=book["source_u_price"]
    rows=book["actual_complete_rows"]
    n=len(book["U"])
    M=book["both_actual_slots_mass"]
    hit,meet=book["hit"],book["meet"]
    H={a:base.total(μ[u,a] for u in range(n)) for a in range(len(pts))}
    H={a:mass for a,mass in H.items() if mass}
    assert base.total(H.values())==M
    from_rows={}
    for a,u_map in rows.items():
        h=base.total(u_map.values())
        from_rows[a]=h
        z,_,g,s=a
        midpoint=base.point(book["rec"][g][s])
        assert [w for w,B in enumerate(book["owner"]) if B[0]<midpoint<B[1]]==[g]
        for u,w in u_map.items():
            # Genuine complete (u,a) atomic marginal of common-price Gamma.
            observed_row_given_z=h/H[z]
            hidden_u_given_row=w/h
            assert H[z]*observed_row_given_z*hidden_u_given_row==w
            # A same-hidden coupling preserves these complete marginals too.
            assert μ[u,z]*(w/μ[u,z])==w
    for z,amount in H.items():
        assert base.total(p for a,p in from_rows.items() if a[0]==z)==amount
    aggregate=matrices(n)
    enforced=matrices(n)
    smallest=None
    current_chosen=None
    price_cells=0
    for a,amount in H.items():
        posterior=[μ[u,a]/amount for u in range(n)]
        assert base.total(posterior)==1
        table=[[amount*q*r for r in posterior] for q in posterior]
        for u,v in product(range(n),repeat=2):
            aggregate[u][v]+=table[u][v]
            if u==v:
                enforced[u][u]+=μ[u,a]
        local=metrics(table,hit,meet,base,amount)
        for key,p in local["means"].items():
            if p<1:
                x=(1-p,pts[a],key)
                if smallest is None or x<smallest:
                    smallest=x
        if a==z0:
            visible=[(row,labels,from_rows[row]) for row,labels in rows.items() if row[0]==a]
            direct=matrices(n)
            actual_marginal_left=defaultdict(F)
            actual_marginal_right=defaultdict(F)
            expected_complete={(row,u):w for row,post,sm in visible for u,w in post.items()}
            for (a_id,tail,sm),(b_id,other,tm) in product(visible,repeat=2):
                amount_ab=sm*tm/amount
                for u,v in product(tail,other):
                    v_ab=amount_ab*(tail[u]/sm)*(other[v]/tm)
                    direct[u][v]+=v_ab
                    actual_marginal_left[a_id,u]+=v_ab
                    actual_marginal_right[b_id,v]+=v_ab
            assert direct==table
            assert actual_marginal_left==actual_marginal_right==expected_complete
            current_chosen=dict(actual_z_cell=pts[a],true_slot_weight=amount,actual_l_by_hidden_old=[μ[u,a] for u in range(n)],
                                actual_h_on_public_z_density=amount/book["price_mass"][a],
                                complete_observed_rows=len(visible),public_joint=table,
                                explicit_full_marginals_checked=len(expected_complete),
                                posterior_old=posterior,actual_public_common_z=local,
                                same_hidden_mass_if_filtering=local["unnormalized_same_old"],
                                true_forced_same_hidden_all_means=metrics(
                                    [[μ[u,a] if u==v else F(0) for v in range(n)] for u in range(n)],
                                    hit,meet,base,amount))
        if sum(p>0 for p in posterior)>1:
            price_cells+=1
    other=[[base.total(μ[u,a]*μ[v,a]/mass for a,mass in H.items()) for v in range(n)] for u in range(n)]
    assert other==aggregate
    assert base.total(enforced[u][u] for u in range(n))==M
    J=book["frozen_J"]
    assert [base.total(row) for row in aggregate]==[base.total(row[i] for row in aggregate) for i in range(n)]==J
    assert [base.total(row) for row in enforced]==[base.total(row[i] for row in enforced) for i in range(n)]==J
    true=metrics(aggregate,hit,meet,base,M)
    forced=metrics(enforced,hit,meet,base,M)
    assert all(s==1 for s in forced["means"].values())
    assert current_chosen
    return dict(actual_pooled_public_price_mass=M,positive_price_cells=len(H),ambiguous_price_cells=price_cells,
                complete_row_count=len(rows),price_grouped_matrix=aggregate,
                both_complete_marginals_are_original=True,public_actual= true,
                retained_if_filter_real_independent_pair_for_same_u=true["unnormalized_same_old"],
                forced_same_old_with_same_two_marginals=forced,
                forced_minus_actual=compare(forced,true),
                least_positive_conditional_forced_gap=smallest,selected_true_z=current_chosen)


def within_root(book,z0,q0,base):
    n=len(book["U"])
    G=book["rooted_by_both_prices"]
    hit,meet=book["hit"],book["meet"]
    A=matrices(n)
    B=matrices(n)
    smallest=None
    chosen=None
    for (z,q),physical in G.items():
        W=base.total(x for row in physical for x in row)
        marg_left=[base.total(row) for row in physical]
        marg_right=[base.total(row[j] for row in physical) for j in range(n)]
        rec=[[x*y/W for y in marg_right] for x in marg_left]
        assert [base.total(row) for row in rec]==marg_left
        assert [base.total(row[j] for row in rec) for j in range(n)]==marg_right
        actual=metrics(physical,hit,meet,base,W)
        redrawn=metrics(rec,hit,meet,base,W)
        gap=compare(actual,redrawn)
        for k,v in gap.items():
            if v:
                row=(abs(v),book["cells"][z],book["cells"][q],k,v)
                if smallest is None or row<smallest:
                    smallest=row
        for u,v in product(range(n),repeat=2):
            A[u][v]+=physical[u][v]
            B[u][v]+=rec[u][v]
        if z==z0 and q==q0:
            false=[(u,v,rec[u][v])
                   for u,v in product(range(n),repeat=2) if rec[u][v] and not physical[u][v]]
            chosen=dict(true_public_price_pair=(book["cells"][z],book["cells"][q]),
                        actual_original_root_label_matrix=physical,conditionally_redrawn_label_matrix=rec,
                        actual_joint=actual,discarded_dependence=redrawn,true_minus_redraw=gap,
                        positive_false_label_pairs=false,
                        actual_physical_receiver_example=next(w for (a,b,_,_),w in book["real_root_witnesses"].items()
                                                              if (a,b)==(z,q)))
    W=book["actual_root_mass"]
    actual=metrics(A,hit,meet,base,W)
    assert actual["unnormalized_same_old"]==book["actual_original_same_old_root_mass"]
    false=metrics(B,hit,meet,base,W)
    assert chosen
    return dict(actual_oriented_root_mass=W,actual_joint_labels=actual,
                redraw_both_label_marginals_from_only_actual_prices=false,
                true_minus_redraw=compare(actual,false),active_true_price_pair_count=len(G),
                least_positive_absolute_discrepancy=smallest,selected_old_true_price_pair=chosen)


def stage(name,T,U,shares,amp,z,q,cloud,base):
    book=observed_price_slot(base,T,U,shares,amp,cloud)
    closest=lambda z:next(i for i,p in enumerate(book["cells"]) if p[0]<z<p[1])
    z0,q0=closest(z),closest(q)
    assert z0==q0 and z!=q
    a=main_palm(book,z0,base)
    b=within_root(book,z0,q0,base)
    if name=="initial":
        assert a["public_actual"]["means"]["same_old"]==1
        assert all(x==0 for x in b["true_minus_redraw"].values())
    else:
        assert all(x>0 for x in a["forced_minus_actual"].values())
        assert b["selected_old_true_price_pair"]["positive_false_label_pairs"]
        assert all(x>0 for x in b["selected_old_true_price_pair"]["true_minus_redraw"].values())
    return dict(stage=name,physical_middle=T,physical_old=U,density_amplitude=amp,
                actual_middle_owners=book["E"],actual_old_owners=book["owner"],
                one_true_public_price=z,second_distinct_actual_price_in_same_cell=q,
                true_full_original_d=book["d"],real_roots_by_middle=book["stages"],
                frozen_combined_J_by_old=book["frozen_J"],pi_directed_hit=book["hit"],pi_true_overlap=book["meet"],
                same_public_z_palm=a,same_real_root_actual_vs_price_only_redraw=b)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    here=Path(__file__).resolve().parent
    parser.add_argument("--rows-dir",type=Path,default=here)
    parser.add_argument("--cloud-dir",type=Path,default=here)
    a=parser.add_mutually_exclusive_group()
    a.add_argument("--output",type=Path)
    a.add_argument("--check",type=Path)
    args=parser.parse_args()
    dep=args.rows_dir/"rows798.py"
    cloud=args.cloud_dir/"cloud802.json"
    assert sha256(dep.read_bytes()).hexdigest()==ROWS_SHA
    assert sha256(cloud.read_bytes()).hexdigest()==CLOUD_SHA
    spec=importlib.util.spec_from_file_location("rows798",dep)
    base=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    frozen={x["stage"]:x for x in json.loads(cloud.read_text())["stages"]}
    T=[base.iv(0,4),base.iv("1/4","17/4"),base.iv("1/2","9/2")]
    U=[base.iv(-1,1),base.iv(3,5),base.iv("9/8","25/8")]
    data=[
       stage("initial",[T[0],T[2]],[U[0],base.iv("5/2","9/2")],[F(1),F(3,4)],F(1,4),F(9,16),F(19,32),frozen["initial"],base),
       stage("pressure",T,U,[F(1),F(3,4),F(1,2)],F(1,2),F(97,32),F(193,64),frozen["pressure"],base),
       stage("expanded",T+[base.iv("3/8","27/8"),base.iv("7/8","31/8")],
             U+[base.iv("1/2",3),base.iv(2,"9/2")],[F(1),F(3,4),F(1,2),F(7,8),F(5,8)],
             F(3,4),F(97,32),F(193,64),frozen["expanded"],base)]
    out=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
             command="python -B palm803.py --check palm803.json",
             dependencies={"rows798.py":ROWS_SHA,"cloud802.json":CLOUD_SHA},
             scope=dict(precision="standard-library exact Fraction",
                 source="true compact one-dimensional nonuniform positive source inside its support; frozen cloud802 geometry, original two-leg screen, d, J, pi",
                 public="Gamma uses the actual combined two-slot price mass H_z. Conditional on the same z, sample twice from its original complete-row conditional and recover each hidden old by its real conditional. Both full marginal laws equal the original combined slot law.",
                 forced="force the same old via true labelwise couplings within z, which preserves the two full marginal laws. Separately record the true weight retained when merely filtering the independent Palm law.",
                 real_root="use the exact original directed two-arm joint. Redraw comparison exposes only its two actual price cells, not the disjoint physical owner locations which already determine the corresponding old label.",
                 normalization="raw root and raw two-slot Palm masses are separate. Rate comparisons normalize by their own original mass; two pooled slots retain both contributions including same old and same price cell.",
                 restriction="all old parents are in the actual size octave [2,4). This is a finite diagnostic using the frozen real cuts."),
             stages=data)
    text=json.dumps(out,sort_keys=True,indent=2,default=str)+"\n"
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for c in data:
            a=c["same_public_z_palm"]["selected_true_z"]["actual_public_common_z"]["means"]
            b=c["same_real_root_actual_vs_price_only_redraw"]["selected_old_true_price_pair"]["true_minus_redraw"]
            print(c["stage"],"public at z",[str(a[k]) for k in ("hit","overlap","same_old")],
                  "same root truth minus redraw",[str(b[k]) for k in ("hit","overlap","same_old")])
        if args.check:
            print("byte-identical")
    else:
        print(text,end="")


if __name__=="__main__":
    main()
