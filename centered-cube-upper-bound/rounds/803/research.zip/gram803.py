"""Exact two-dimensional continuous cube diagnostics for R803's off-diagonal Gram sum."""
import argparse
from collections import defaultdict
from fractions import Fraction as Q
from itertools import product
import json
from pathlib import Path
import platform

from flint import arb, ctx
import flint

ctx.prec = 384
HALF = Q(1, 2)


def cube(x, y, side, owner_share=1):
    x, y, side, part = Q(x), Q(y), Q(side), Q(owner_share)
    half = side / 2
    return dict(x=x, y=y, side=side, m=side**2, j=(side*part/64)**2,
                owner_radius=half*part/64,
                box=(x-half, x+half, y-half, y+half))


def inside(x, y, b):
    return b[0] < x < b[1] and b[2] < y < b[3]


def triangular(x):
    t=x-Q((x*4)//1,4)
    return min(t, Q(1,4)-t)


def group_cells(small, middle, amp):
    cubes = small+middle
    xs=sorted({Q(-4),Q(0),Q(4),*(a["box"][k] for a in cubes for k in (0,1))})
    ys=sorted({Q(-4),Q(4),*(a["box"][k] for a in cubes for k in (2,3))})
    mass=defaultdict(Q)
    for (xa, xb),(ya,yb) in product(zip(xs,xs[1:]),zip(ys,ys[1:])):
        x=(xa+xb)/2
        y=(ya+yb)/2
        mask=[inside(x,y,a["box"]) for a in cubes]
        ui=tuple(i for i in range(len(small)) if mask[i])
        ti=tuple(i for i in range(len(middle)) if mask[len(small)+i])
        amount=(xb-xa+amp*(triangular(xb)-triangular(xa)))*(yb-ya)
        assert amount>0
        if ui or ti:
            mass[ui,ti,x<0]+=amount
    for i,a in enumerate(cubes):
        val=sum(m for (U,T,neg),m in mass.items() if
                (i in U if i<len(small) else i-len(small) in T))
        assert val==a["m"]
    return [(set(U),set(T),neg,m) for (U,T,neg),m in mass.items() if U and T]


def gate(s, t):
    u,h,below=s
    g,k,negative=t
    return (u==g and h==k) or (u!=g and h==0 and k==1 and below and not negative)


def bucket(v):
    d=Q(1)
    while 2*d<=v:
        d*=2
    return d


def clipped_certificate(rows, bins, J):
    """Push forward the common sum of the two-observation references by D^3 F_d."""
    levels=defaultdict(Q)
    for d in sorted(set(bins)):
        ids=[i for i in range(len(bins)) if bins[i]==d]
        groups=defaultdict(Q)
        for mg,vec,w in rows:
            scale=d/max(d,mg)
            g=tuple(vec[i]/scale for i in ids)
            if any(g):
                groups[g]+=w*scale
        atoms=list(groups.items())
        for i,(left,wt) in enumerate(atoms):
            with_J=tuple(x/J[j] for x,j in zip(left,ids))
            for j in range(i+1):
                right,vt=atoms[j]
                level=d**3*sum(x*y for x,y in zip(with_J,right))
                if level:
                    levels[level]+=(1 if i==j else 2)*wt*vt/d**3
    peak=sum(x*w for x,w in levels.items())
    assert peak==sum(J)
    left=Q(0)
    for threshold,w in sorted(levels.items()):
        left+=threshold*w
        if 2*left>=peak:
            break
    cost=capture=upper_reduced=Q(0)
    partial=full=Q(0)
    for x,w in levels.items():
        k=min(Q(1),x/threshold)
        cost+=w*k*k
        capture+=w*x*k
        if x<threshold:
            upper_reduced+=w*x*x/(2*threshold)
            partial+=w*x
        else:
            upper_reduced+=w*(x-threshold/2)
            full+=w*x
    dual=cost*threshold/2+upper_reduced
    hs=sum(w*x*x for x,w in levels.items())
    assert dual==capture and capture*capture<cost*hs and partial and full
    return dict(distinct_positive_joint_density_levels=len(levels),sum_D3_HS_squared=hs,
                likelihood_at_clipping=threshold,squared_budget=cost,total_positive_reference_budget=sum(levels.values()),
                budget_fraction_of_full_positive_support=cost/sum(levels.values()),
                original_two_slot_fraction_captured=capture/peak,
                original_joint_mass_in_strictly_fractional_region=partial/peak,
                exact_dual_equals_primal=dual==capture)


def stage(name, small, middle, amp):
    all_cubes=small+middle
    assert all(2<=a["side"]<4 for a in all_cubes)
    for i,a in enumerate(all_cubes):
        for b in all_cubes[:i]:
            assert max(abs(a["x"]-b["x"]),abs(a["y"]-b["y"]))>a["owner_radius"]+b["owner_radius"]
    assert min(x["m"] for x in middle)>max(x["m"] for x in small)
    cells=group_cells(small,middle,amp)
    nu=len(small)
    J=[Q(0)]*nu
    degrees=[]
    true_root=Q(0)
    for t,a in enumerate(middle):
        sig=defaultdict(Q)
        for U,T,neg,m in cells:
            if t in T:
                for u in U:
                    for h in (0,1):
                        sig[u,h,neg]+=m*small[u]["j"]/(2*small[u]["m"]*a["m"])
        d=sum(sig.values())
        assert d>0
        degrees.append(d)
        true_root+=a["j"]*sum(i*j for si,i in sig.items() for sj,j in sig.items() if gate(si,sj))/d
    # Original price cell, opposite price cell and physical owner half are kept together.
    # Pool cells only after obtaining their identical full density vector and the opposite volume.
    blocks=defaultdict(Q)
    observations=0
    vectors={}
    for ix,(U,T,neg,xmass) in enumerate(cells):
        for iy,(G,T2,neg2,ymass) in enumerate(cells):
            common=T&T2
            if not common:
                continue
            central=sum(middle[t]["j"]/(middle[t]["m"]**2*degrees[t]) for t in common)
            for g in G:
                for h in (0,1):
                    vec=[]
                    for u in range(nu):
                        ways=2 if u==g else int(h==1 and neg and not neg2)+int(h==0 and neg2 and not neg)
                        vec.append(central*small[u]["j"]*ways/(2*small[u]["m"]) if u in U else Q(0))
                    if any(vec):
                        vectors[ix,iy,g,h]=tuple(vec)
                        w=xmass*ymass*small[g]["j"]/(2*small[g]["m"])
                        blocks[small[g]["m"],tuple(vec)]+=w
                        observations+=1
    rows=[(mg,v,w) for (mg,v),w in blocks.items()]
    for mg,v,w in rows:
        for u,h in enumerate(v):
            J[u]+=w*h
    assert all(J) and sum(J)==2*true_root
    C=[[Q(0)]*nu for _ in small]
    bins=[bucket(a["m"]) for a in small]
    weighted_same=[[Q(0)]*nu for _ in small]
    for mg,v,w in rows:
        for i,x in enumerate(v):
            if not x:
                continue
            for j,y in enumerate(v):
                if not y:
                    continue
                contrib=w*x*y
                C[i][j]+=contrib
                if bins[i]==bins[j]:
                    weighted_same[i][j]+=contrib*max(bins[i],mg)/bins[i]
    overlap=lambda i,j:min(bins[i],bins[j])**3*C[i][j]**2/(J[i]*J[j])
    diagonal=sum(overlap(i,i) for i in range(nu))
    same_off=sum(overlap(i,j) for i,j in product(range(nu),repeat=2) if i!=j and bins[i]==bins[j])
    cross=sum(overlap(i,j) for i,j in product(range(nu),repeat=2) if bins[i]!=bins[j])
    same_weighted=sum(bins[i]**3*weighted_same[i][j]**2/(J[i]*J[j])
                      for i,j in product(range(nu),repeat=2) if bins[i]==bins[j])
    same_common=diagonal+same_off
    assert same_weighted>=same_common and cross>0
    # Independent contraction: apply the conditional same-parent kernel to each
    # complete observation, then contract on the second observation with C.
    via_rows=Q(0)
    for mg,v,w in rows:
        via_rows+=w*sum(min(bins[i],bins[j])**3*x*y*C[i][j]/(J[i]*J[j])
                       for i,x in enumerate(v) if x for j,y in enumerate(v) if y)
    assert via_rows==diagonal+same_off+cross
    # Exact all-observation-pairs check in the first case. Dyadic kernel as layer integral.
    if name=="initial":
        from_pairs=Q(0)
        last=Q(0)
        for d in sorted(set(bins)):
            inc=d**3-last**3
            ids=[i for i in range(nu) if bins[i]>=d]
            for mg,x,w in rows:
                for mg2,y,w2 in rows:
                    value=sum(x[i]*y[i]/J[i] for i in ids)
                    from_pairs+=inc*w*w2*value**2
            last=d
        assert from_pairs==via_rows
    # The opposite view of the SAME actual record is a singular graph in the
    # continuous product reference: first price on one side equals opposite price on the other.
    # Integrate the physical row densities directly on that graph, with original unsplit root mass.
    swap_total=Q(0)
    swap_weight=Q(0)
    zero_alternatives=Q(0)
    for ix,(U,T,neg,mx) in enumerate(cells):
        for iy,(G,T2,neg2,my) in enumerate(cells):
            shared=T&T2
            if not shared:
                continue
            c=sum(middle[t]["j"]/(middle[t]["m"]**2*degrees[t]) for t in shared)
            for u,g,k,h in product(U,G,(0,1),(0,1)):
                ways=int(gate((u,k,neg),(g,h,neg2)))+int(gate((g,h,neg2),(u,k,neg)))
                if not ways:
                    continue
                path=ways*c*mx*my*small[u]["j"]*small[g]["j"]/(4*small[u]["m"]*small[g]["m"])
                va=vectors[ix,iy,g,h]
                vb=vectors[iy,ix,u,k]
                coeff=sum(min(bins[u],bins[j])**3*va[j]*vb[j]/J[j] for j in range(nu))
                swap_weight+=path
                swap_total+=path*coeff
                if all(va[j]*vb[j]==0 for j in range(nu) if j!=u and j!=g):
                    zero_alternatives+=path
    assert swap_weight==sum(J) and 0<swap_total
    cert=clipped_certificate(rows,bins,J)
    assert cert["sum_D3_HS_squared"]==same_weighted
    supports=defaultdict(Q)
    for mg,v,w in rows:
        supports[mg,tuple(i for i in range(nu) if v[i])]+=w
    full_cost=union_cost=multiple=Q(0)
    for (mg,i),wi in supports.items():
        for (mg2,j),wj in supports.items():
            layer=sorted({bins[u] for u in set(i).intersection(j)})
            if not layer:
                continue
            levels=[1/(d*max(d,mg)*max(d,mg2)) for d in layer]
            assert levels[0]<=sum(levels)<2*levels[0]
            full_cost+=wi*wj*sum(levels)
            union_cost+=wi*wj*levels[0]
            if len(layer)>1:
                multiple+=wi*wj*levels[0]
    assert full_cost==cert["total_positive_reference_budget"] and union_cost<full_cost<2*union_cost
    cert.update(one_common_union_cost=union_cost,total_vs_one_union_ratio=full_cost/union_cost,
                share_of_union_cost_used_in_multiple_bins=multiple/union_cost)
    return dict(clipped_common_kernel=cert,same_root_swap_average=swap_total/swap_weight,
                fraction_of_real_slots_without_a_third_completing_parent=zero_alternatives/swap_weight,
                stage=name,physical_small=small,physical_middle=middle,amplitude=amp,
                actual_mark_rows=observations,distinct_full_density_vectors_and_opposite_volume=len(rows),
                true_degrees=degrees,original_true_peak_mass=true_root,two_slot_J=J,
                bins=bins,common_gram=C,diagonal=diagonal,same_bin_distinct=same_off,
                different_bin=cross,total=via_rows,missed_fraction_if_only_diagonal=1-diagonal/via_rows,
                different_bin_fraction=cross/via_rows,same_bin_weighted_joint_reference=same_weighted,
                true_direct_pair_sum_in_initial=name=="initial")


def dimension(q):
    n=arb(2)**q
    ell=(n+2).log()
    r0=n.sqrt()*ell**2
    r1=r0+1
    k0=r0/(16384*ell)-1
    k1=r1/(16384*ell)
    w0=ell**4/8192**2
    w1=(r1/8192)**2/n
    assert k0>0
    xi0=(k0*w0).sqrt()
    xi1=(k1*w1).sqrt()
    scalar=6*ell-xi0/256
    near=arb(512).log()-r0/8192+xi1/128
    assert near<0 and (scalar<0 or scalar>0)
    return dict(n_power_of_two=q,log_model_upper=scalar.str(22),
                upper_sign="negative" if scalar<0 else "positive",
                log_near_relative_to_far_upper=near.str(22),xi_lower=xi0.str(22))


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    choices=cli.add_mutually_exclusive_group(required=True)
    choices.add_argument("--output",type=Path)
    choices.add_argument("--check",type=Path)
    opt=cli.parse_args()
    small=[cube("-3/4",0,2),cube("5/8",0,3,"3/4"),cube(0,"3/4","5/2"),
           cube("-1/8","-3/4",3,"1/2"),cube("7/8","7/8","9/4","7/8")]
    middle=[cube("-1/4","1/8","7/2"),cube("1/4","-1/4","15/4","3/4"),
            cube("1/2","1/2","13/4"),cube("-1/2","-1/2","7/2","1/2"),
            cube(0,0,"15/4","7/8")]
    diag=[stage(n,small[:k],middle[:k],e) for n,k,e in
          (("initial",2,Q(1,4)),("pressure",3,Q(1,2)),("expanded",5,Q(3,4)))]
    data=dict(python=platform.python_version(),flint=flint.__version__,arb_bits=ctx.prec,
              source="[-4,4]^2, density 1+amplitude or 1-amplitude on alternating vertical strips of width 1/8",
              scope="Actual continuous source and disjoint real receivers, original degrees and complete directional screen. "
                    "All radii in [1,2), two genuine small-parent volume bins. This does not realize all high-dimensional gates.",
              spectral="All positive within-parent, between-parent and cross-bin terms. Two summation orders verified; initial also exhausts pairs of compressed observations.",
              diagnostics=diag,parameter_stages=[dimension(q) for q in (32,128,512,2048,8192,32768)])
    output=(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True,default=str)+"\n").encode()
    if opt.check:
        assert opt.check.read_bytes()==output
        print("gram803 byte-identical")
    else:
        opt.output.write_bytes(output)


if __name__=="__main__":
    main()
