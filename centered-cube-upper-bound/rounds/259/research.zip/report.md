# 第259轮：实际硬来源支撑与共同接收熵费用

基线R258 a92c41655300d7dc5c87a301e65c70f35ac1bfce已推送，上一轮为实质进展。本轮未取得新的统一根阶付款，一般目标继续开放。

## 已严格取得的联合估计

原aω保硬z∈Z_g(y)⊂Z_t(y)，在near ||y−z||1≤a/(16√n)上，wt(y,z)≥c*=1−a/(16b√n)≥15/16。实际hard槽可写为e_tΠ_t/w_t，但e_t不能省。以原时钟不变的硬响应H记账，e_g≥c*R^nH，结合完整后验度数衰减（删除损失保正）得到原scoreclock的真实熵预算。

对同一真实dm=dx·1high,valid p_yβ(dy)/q，定义A=∫eτ/(c*R^n)dm、B=∫Hdm。原near正交通有逐叶预算2ΛB·min(nlog2/4,log(A/B))，再对原种子/叶求和。该式保来源、实际尺度、接收权与后验度数相关性；既没有人工score-label假设，也没有消费原负信用。

FIRST与MG257可进一步给εX+32Λ/√3 sqrt(Kκ) Σ√WβWν log_+(2Λρν/(c*ε))，ρν=N/(λa^n)。这个输入依赖对数明确保留，不称一般根阶上界。

## 决定下一步的资格核查

当前hardtail确有N>λa^n exp√n；R108/R109新建尾源后重新支付轻尾，R113耦合只改soft而保hard。详细引用见source_bridge SB8。故用叶总质量粗化后，logρν至少为√n；不能拿‘ρ多项式’作为当前实际非空root子支。需直接控制A/B或占用B与归一化的相关性，这与单独对B和总质量各取最坏帽不同。未证明这种相关性，不能宣称闭合。

同一raw overlap核可逆是R226旧工具重核，不计新成果。near anchor的carrier差还含移动D_V的两层距离壳，不能只保两禁块就声称两后验一致；壳层质量与原β/e差仍未付。本轮未以反例搜索代替主攻。

## 实际计算与复现等级

本机Python3.12.14/mpmath1.3.0，按L03区分Fraction资格证书与普通对数/积分。三阶段有限actual-C law核近反权、terminal度数帽及含删除的熵恒等式；响应表检FIRST子概率、logsum、Jensen与Young。它们未认证原FULL/FIRST/history的完整几何实例。完整参数、counts与误差见numeric_notes.md/JSON。

reproduce.py核manifest、重新计算JSON逐字节比对，并执行audit/source_bridge/joint_geometry附录代码；只有主代理实际包外运行通过后登记重放成功。详细LaTeX及独审保存在同包，不编译PDF。

## 尚未解决

一般near正交通统一root预算、near后缀恢复、少标签低soft与互补远来源的全局账仍未闭合。后续不应把显式logρ重新改名后宣称root；应继续使用原A/B共同几何，或证明合法原source交换可支付其补域。

模型实际扣额数据不可得，不猜成本。本轮复用一Astra与三Sol的限定任务，各自冻结后停止；最终紧凑归档、独立提交推送。
