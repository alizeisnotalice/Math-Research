# R259：实际近硬来源与共同接收熵结算

## JG1. 结论与准确范围

本轮得到原来源与真实接收域上的非线性预算
\[
 \mathcal P_{V,\mathrm{near}}\le
 2\Lambda B_V\min\left\{\frac{n\log2}{4},\log\frac{A_V}{B_V}\right\}. \tag{JG1}
\]
其中 \(A_V\) 保留实际初始度数、实际硬尺度与软来源权，\(B_V\) 保留同一硬来源的真实近接收占用；定义见 JG3。它使用原 hard-source 支持，而不是把任意硬来源免费当成第三份后验。JG4 给出 FIRST 与 R257 近来源列共同结算后的显式全来源价格。

**未取得本轮新的统一根阶交通付款。** 当前实际硬尾满足 \(\|\nu_V\|>\lambda a^n e^{\sqrt n}\)。把 JG1 中的联合量分别取全局质量帽，仍留下至少 \(\sqrt n\) 规模的对数费用。不得将全局质量多项式大小当作一个已认证、非空的当前分支。本稿不重复 R224 固定参数 affinity/clock 付款，不使用已消费的负信用。

## JG2. 原测度、静态支持与近来源反权

固定原随机种子与保留叶 \(V\)。沿用原 \(0<a\le b\le2a\)、\(\lambda>0\)、\(3\lambda/4\le q\le\lambda\)、\(\Lambda=128/119\)，以及原来源 \(0\le\nu_V\le\beta_V\le\alpha_V\)。记 \(N_V=\|\nu_V\|\)。原接收域 \(E_V\) 保所有与来源无关的实际资格；在每个种子下这些叶接收域不交。每个接收点仍只有一个原 \(j(x)\)、一组实际 \(s(x),L(x),R(x)\)，\(g(x)=\sqrt{L(x)R(x)}\)。

令 \(d=a/(8\sqrt n)\)、\(r=d/2\)、\(\eta=1-r/b\ge15/16\)。取原 lowsoft/lowlabel 正余项的静态软核份额 \(0\le\widetilde p(x,y)\le p_y(x)\)；也可取整个实际软核。这里静态指不依辅助时钟 \(t\)，不是把实际接收选择器冻结为常数。其余依 \(t,u,v\) 的非负余项门可以正上放；原静态来源 RN 权 \(0\le a_\omega(x,y,z)\le1\) 保留。若需正上放该 RN 权，只能换为仍保下述原支持的静态指标，不可先删支持再恢复。

R114 ratio_settlement S4（28–43 行）证明实际接受的硬来源
\[
 a_\omega(x,y,z)>0\ \Longrightarrow\ z\in Z_{j,g}(y)\subset Z_{j,t}(y),\qquad t\le g. \tag{JG2.1}
\]
R117 JG5 保留该 FULL/CP/history 资格；本轮 source_bridge SB6 给出原文链。禁块随 \(t\) 扩张。原过程仍为
\[
 w_t(y,v)=\prod_i\min\{1,bC(|y_i-v_i|/b)/(c_jt)\},\quad
 e_t(y)=\int_{Z_t(y)}w_t(y,v)\,d\nu_V(v),\quad
 d\Pi_{y,t}=1_{Z_t(y)}w_t(y,v)d\nu_V(v)/e_t(y).
\]
原 \(c_jt\le b\)，且 \(C(u)\ge(1-u)_+\)。故在 \(\|y-z\|_1\le r\) 上，
\[
 w_t(y,z)\ge\prod_i(1-|y_i-z_i|/b)\ge\eta. \tag{JG2.2}
\]
因此在保留 JG2.1 的实际行上可精确换测度
\[
 d\nu_V(z)=\frac{e_t(y)}{w_t(y,z)}d\Pi_{y,t}(z)
 \le\eta^{-1}e_t(y)d\Pi_{y,t}(z). \tag{JG2.3}
\]
此式的 \(e_t\) 没有消失；本稿不以此式单独声称付款。

定义静态近硬响应
\[
 H(x,y)=\int h_{R(x)}(x-z)a_\omega(x,y,z)
 1_{\{\|y-z\|_1\le r\}}\,d\nu_V(z). \tag{JG2.4}
\]
空窗 \(\tau_j=a/c_j>g\) 的行置零。由 \(h_R=R^{-n}1_{Q_R}\)、JG2.1–2，
\[
 e_g(y)\ge\eta R(x)^nH(x,y). \tag{JG2.5}
\]
只在 \(H>0\) 行作除法，此时整个 \([\tau_j,g]\) 上 \(e_t>0\)。原 high、heavy 等时间或辅助来源门若正上放，不改变 \(Z_t,e_t,\Pi_t\) 的定义。

## JG3. 不拆共同来源的接收熵界

令 \(m_t(y)=\int k_t(y,v)d\Pi_{y,t}(v)\)。原有限树的载体只有有限删除跳跃；在跳间
\(d\log e_t/d\log t=-m_t\)，删除使 \(e_t\) 下降。故
\[
 \int_{\tau_j}^{g}m_t(y)\,\frac{dt}{t}
 \le\log\frac{e_{\tau_j}(y)}{e_g(y)}
 \le\log\frac{e_{\tau_j}(y)}{\eta R(x)^nH(x,y)}. \tag{JG3.1}
\]
初端采用原右连续过程，末端若有删除，只增加右边。坐标激活时 \(w_t\) 连续，分段导数的 a.e. 恒等式足够。这里没有把连续 \(N_{\rm del}\) 当删除原子信用；只对一个正量使用实际总质量的单调性。

原双后验与 score 不变。逐点 \((k_t(v)-k_t(u))_+\le k_t(v)\)，所以原剩余 near 正量满足
\[
 \mathcal P_{V,\mathrm{near}}
 \le2\Lambda\int H(x,y)
 \log\frac{e_{\tau_{j(x)}}(y)}{\eta R(x)^nH(x,y)}\,dm_V(x,y),\quad
 dm_V=1_{E_V}(x)\frac{\widetilde p(x,y)}q\,dx\,d\beta_V(y). \tag{JG3.2}
\]
实际 far 子窗正放为 \([\tau_j,g]\)；所有未放掉的静态限制均可留在 \(\widetilde p\) 或 \(H\) 中。当前正余项的时间/辅助门上放不允许重领先前已付项。

设
\[
 A_V=\int \frac{e_{\tau_{j(x)}}(y)}{\eta R(x)^n}\,dm_V(x,y),\qquad
 B_V=\int H(x,y)\,dm_V(x,y). \tag{JG3.3}
\]
由 JG2.5，\(0\le B_V\le A_V\)。对 \(B_V>0\)，在概率测度 \(Hdm_V/B_V\) 下对 \(\log\) 用 Jensen：
\[
 \int H\log\frac{e_\tau}{\eta R^nH}\,dm_V
 \le B_V\log\frac{A_V}{B_V}. \tag{JG3.4}
\]
在 \(H=0\) 处积分按零定义；Jensen 的右侧可把 \(\{H>0\}\) 上的 \(A\) 正放为完整 \(A_V\)。不要求 \(dm_V\) 为概率。有限质量与有限接收域保证下面的 \(A_V\) 上界有限；一般扩展情形可先共同截断，\(A_V=\infty\) 时只是不提供信息。

另一方面，原两个独立同分布后验的 score 取值 \([0,n]\)，有
\(\iint(k(v)-k(u))_+d\Pi(v)d\Pi(u)\le n/4\)。原窗长度至多 \(\log2\)，故 \(\mathcal P\le2\Lambda(n\log2/4)B_V\)。与 JG3.4 取较小者即 JG1。相对于逐行熵帽，JG3.4 是同一个实际接收/来源测度的联合压缩；并不授 \(\log(A_V/B_V)\) 为常数。

## JG4. FIRST、真实近来源列与全部费用

原 actual FIRST 授 \(\int\widetilde p(x,y)d\beta_V(y)\le q\)，且 \(e_{\tau_j}(y)\le N_V\)、\(R\ge a\)。因此
\[
 A_V\le\frac{N_V|E_V|}{\eta a^n}. \tag{JG4.1}
\]
这一步不换成节点软核，也不对 \(y\) 相关的 \(e_\tau\) 假装作共同标量；它只是将其逐点上放为 \(N_V\)。

对任意 \(\varepsilon>0\)，由 \(\log u\le u-1\)，
\[
 2\Lambda B_V\log\frac{N_V|E_V|}{\eta a^nB_V}
 \le\varepsilon\lambda|E_V|
 +2\Lambda B_V\log_+\frac{2\Lambda N_V}{\eta\varepsilon\lambda a^n}. \tag{JG4.2}
\]
例如令 \(u=\varepsilon\lambda|E_V|/(2\Lambda B_V)\) 后展开对数即得；\(B_V=0\) 按零。与原 Gini 界同时使用，合法地得到
\[
 \mathcal P_{V,\mathrm{near}}\le\varepsilon\lambda|E_V|
 +2\Lambda B_V\min\left\{\frac{n\log2}{4},
 \log_+\frac{2\Lambda\rho_{\nu,V}}{\eta\varepsilon}\right\},\qquad
 \rho_{\nu,V}=\frac{N_V}{\lambda a^n}. \tag{JG4.3}
\]
取较小者发生在加 \(\varepsilon\lambda|E_V|\) 之后，不声称逐点对两行积分取最小。

R257 MG4.4 定义的 \(K_n(d)\)、\(\kappa_d=2+n\log(1+d/a)\) 满足
\(K_n(d)\le C_*\kappa_d\log(n+2)\)。其 MG6 在 actual FIRST 与 actual all-hard cap 上，对整个软度族和实际物理选择器已付真实 near 来源列，故
\[
 B_V\le\frac{16}{\sqrt3}\sqrt{K_n(d)\kappa_d}
 \sqrt{\|\beta_V\|\|\nu_V\|}. \tag{JG4.4}
\]
这里使用 \(\widetilde p\le p\)、\(a_\omega\le1\)；真实 near 指标相对于平移同胞核的因子二已包含。没有把 full-soft supremum 赋予高度帽。

在同一种子下先保唯一 \(j(x)\)，再按不交 \(E_V\) 求和，\(\mathbb E\sum_V\lambda|E_V|\le X\)。因此最终显式比较价是
\[
 \mathcal P_{\mathrm{near}}\le\varepsilon X+
 \frac{32\Lambda}{\sqrt3}\mathbb E\sum_V
 \sqrt{K_n(d)\kappa_d}\sqrt{\|\beta_V\|\|\nu_V\|}
 \min\left\{\frac{n\log2}{4},
 \log_+\frac{2\Lambda\rho_{\nu,V}}{\eta\varepsilon}\right\}. \tag{JG4.5}
\]
若参数随外数据变化，因子留在和内。\(\eta\) 可统一降低为 \(15/16\)。此式全保原来源；没有 \(\nu\) 重建、点态 \(\beta/\nu\) 比较或额外 soft/scale 菜单费。\(W_{\rm pair}=\mathbb E\sum_V\sqrt{\|\beta_V\|\|\nu_V\|}\le\|f\|_1\)，但对数加权和仍未付。

## JG5. 重尾资格与下一处真正缺口

本轮 source_bridge SB8 已按 R108 parent_integration:133、R109 integration_main:103–109、R113 coupled_transport:68–84 认证：当前非零硬尾 \(N_V>\lambda a^n e^{\sqrt n}\)。因此不能用“\(\log\rho_{\nu,V}\) 为多对数”解释 JG4.5 为当前一般根阶付款。以 JG4.4 单独取帽再乘此对数，恰会丢掉需要控制的联合几何。准确保留的较强量仍为 JG3.2，或其可计算联合上界 \(B_V\log(A_V/B_V)\)。目前没有证明 \(B_V\) 随全局 \(\rho_{\nu,V}\) 增大而足够衰减，亦没有将其整体支付到 \(\varepsilon X+C_\varepsilon\sqrt n\operatorname{polylog}(n)\|f\|_1\)。

near 原硬来源允许考虑换 anchor，但支持差仍是具体阻断。原接受门授 \(T_0(y)=T_0(z)\)，以及 \(A_{j,t}(y),A_{j,t}(z)\) 是两个不同原块；距离近本身不授这些结论。另有移动距离门
\[
 D_V(y)=V\cap\{\|v-y\|_1\le R_1\}\cap\{\|v-y\|_\infty\le R_\infty\},\quad
 R_1=17na,\ R_\infty=b(5\log n+1/2).
\]
令 \(r_1=\|y-z\|_1,r_\infty=\|y-z\|_\infty\)，则三角不等式给
\[
 |1_{D_V(y)}(v)-1_{D_V(z)}(v)|\le1_V(v)
 \left[1_{\{|\|v-y\|_1-R_1|\le r_1\}}
 +1_{\{|\|v-y\|_\infty-R_\infty|\le r_\infty\}}\right]. \tag{JG5}
\]
闭壳可安全覆盖原边界约定。交换完整 \(Z_t\) 还要支付两原禁块与这两个壳中的加权来源质量，随后除以各自真实度数。原 \(L^1\) 子来源资格不授“壳薄则质量小”，也不授点态 \(\beta\le C\nu\)。故仅比较共同支持上的原权不足以抵消完整 \(e_t\)。这定位了未得到的新桥，没有把该壳费登记为付款或引入新的假设。

## JG6. 本机有限核查与证据范围

以下标准库代码已在本机实际执行，输出 `PASS 28 Decimal scalar checks; precision=60`。只核查 JG3.4、JG4.2、JG4.3 的有限标量代数；没有声称这些例子是 FULL 来源/时钟实例。一般证明是上述 Jensen、单调质量与原来源帽。

```python
from decimal import Decimal as D, getcontext
getcontext().prec=60
checks=0
for k in range(1,5):
    weights=[D(1)/D(3), D(2)/D(5), D(k)/D(7)]
    H=[D(1)/D(k+2),D(k)/D(9),D(3)/D(8)]
    a=[H[i]*D(k+i+2) for i in range(3)]
    B=sum(w*h for w,h in zip(weights,H))
    A=sum(w*v for w,v in zip(weights,a))
    raw=sum(w*h*(v/h).ln() for w,h,v in zip(weights,H,a))
    assert raw <= B*(A/B).ln()+D('1e-55'); checks+=1
    for eps in (D('0.01'),D('0.3'),D(2)):
        Lam=D(128)/D(119); volume=D(k+1); lam=D(3)/D(4)
        cap=A/volume
        left=2*Lam*B*(cap*volume/B).ln()
        fee=max(D(0),(2*Lam*cap/(eps*lam)).ln())
        right=eps*lam*volume+2*Lam*B*fee
        assert left <= right+D('1e-55'); checks+=1
        gini=D(k)*D(2).ln()/D(4)
        assert min(left,2*Lam*B*gini) <= eps*lam*volume+2*Lam*B*min(gini,fee)+D('1e-55'); checks+=1
print('PASS',checks,'Decimal scalar checks; precision=60')
```
