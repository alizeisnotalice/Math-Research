#!/usr/bin/env python3
"""Replay finite checks; does not certify the general theorem."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    def verify():
        for name,value in manifest['sha256'].items():
            assert digest(ROOT/name)==value,name
    verify()
    with tempfile.TemporaryDirectory(prefix='cube-r259-') as tmp:
        out=Path(tmp)/'numeric_checks.json'
        subprocess.run([sys.executable,str(ROOT/'numeric_checks.py'),'--contract',str(ROOT/'task_contract.md'),'--output',str(out)],check=True)
        assert out.read_bytes()==(ROOT/'numeric_checks.json').read_bytes(),'JSON replay differs'
        blocks=0
        for name in ['audit.md','source_bridge.md','joint_geometry.md']:
            for i,src in enumerate(re.findall(r'```python\n(.*?)```',(ROOT/name).read_text(),re.S)):
                script=Path(tmp)/(name+'.'+str(i)+'.py');script.write_text(src)
                subprocess.run([sys.executable,str(script)],check=True)
                blocks+=1
    verify()
    print(json.dumps({'status':'PASS','manifest_files':len(manifest['sha256']),'json_byte_identical':True,'embedded_python_blocks':blocks,'scope':'finite checks only; general proof is separately audited'}))
if __name__=='__main__':main()
