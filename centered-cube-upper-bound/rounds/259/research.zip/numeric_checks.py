#!/usr/bin/env python3
"""R259 finite actual overlap clocks and static receiver inequalities; not FULL."""
import argparse,hashlib,json,math
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fs(x):return str(x.numerator)+'/'+str(x.denominator)
def enc(x):return mp.nstr(x,50)
def m(x):return mp.mpf(x.numerator)/x.denominator if isinstance(x,F)else mp.mpf(x)
def prod(v):
    ans=1
    for x in v:ans*=x
    return ans

def C(d):
    x=m(d);E=lambda t:mp.expint(4,t)
    def iphi(t):return t+E(mp.mpf('.5')+t)-E(mp.mpf('.5')-t)if t<=mp.mpf('.5')else mp.mpf('.5')-E(t-mp.mpf('.5'))+E(t+mp.mpf('.5'))
    return max(mp.mpf(0),1-x)+iphi(x+mp.mpf('.5'))-iphi(max(mp.mpf('.5'),x-mp.mpf('.5')))

def models():
    rows=[]
    for phase,n,masses in [('initial',2,[F(1),F(1,2),F(2),F(1),F(1,4)]),('stress',8,[F(1,10),F(3),F(1,100),F(100),F(2)]),('expanded',32,[F(1,10**4),F(1),F(10),F(1000),F(1,100)])]:
        rt=math.isqrt(n)+(math.isqrt(n)**2<n);dl=F(1,16*rt);near=dl/(4*n)
        patterns=[[near],[F(1,2),F(1)],[F(1),F(2)],[F(0),F(1,4)],[F(1,2),F(1,4)]]
        sources=[{'mass':mass,'distances':[p[j%len(p)]for j in range(n)],'delete':None if i<3 else F(3,4)if i==3 else F(7,8)}for i,(mass,p)in enumerate(zip(masses,patterns))]
        eta=1-dl/2;near_l1=n*near
        assert near_l1>0 and (2*near_l1)**2<F(1,256*n)
        hard_lower=(1-near)**n;assert hard_lower>=1-near_l1>=eta
        rows.append({'phase':phase,'n':n,'d_floor':dl,'eta_cert':eta,'hard_near_product_lower':hard_lower,'near_l1':near_l1,'sources':sources})
    return rows

def evaluate(src,A,t,before=False):
    weights=[s['mass']*prod(min(1,v/t)for v in aa)if s['delete']is None or(t<=s['delete']if before else t<s['delete'])else 0 for s,aa in zip(src,A)]
    e=sum(weights);assert e>0;pi=[v/e for v in weights];k=[sum(v<t for v in aa)for aa in A]
    mean=sum(p*kk for p,kk in zip(pi,k));gini=sum(p*q*max(0,kk-ll)for p,kk in zip(pi,k)for q,ll in zip(pi,k))
    return weights,e,pi,k,mean,gini

def rational_model(model):
    n=model['n'];src=model['sources'];near=src[0]['distances'][0];lookup={F(0):F(1),F(1,4):F(7,8),F(1,2):F(5,8),F(1):F(1,8),F(2):F(1,32),near:1-near}
    A=[[lookup[v]for v in s['distances']]for s in src];events=sorted({F(1,2),F(1)}|{v for aa in A for v in aa if F(1,2)<v<1}|{F(3,4),F(7,8)})
    checks=[]
    for a,b in zip(events,events[1:]):
        t=(a+b)/2;w,e,pi,k,mean,gini=evaluate(src,A,t);assert gini<=mean
        assert w[0]>=model['eta_cert']*src[0]['mass']
        checks.append({'left':fs(a),'right':fs(b),'scores':k,'mean':fs(mean),'gini':fs(gini),'margin_mean_minus_gini':fs(mean-gini)})
    w,e,pi,k,mean,gini=evaluate(src,A,F(1),before=True);support=model['eta_cert']*src[0]['mass'];assert e>=support
    return {'phase':model['phase'],'n':n,'midpoints':checks,'endpoint_e':fs(e),'terminal_support_lower':fs(support),'hard_near_weight_lower':fs(model['hard_near_product_lower']),'eta_cert':fs(model['eta_cert']),'scope':'Independent rational clock template, not an exact C-kernel representation.'}

def actual_model(model,dps):
    with mp.workdps(dps):
        n=model['n'];src=[{**s,'mass':m(s['mass']),'delete':None if s['delete']is None else m(s['delete'])}for s in model['sources']];lookup={v:C(v)for s in model['sources']for v in s['distances']};A=[[lookup[v]for v in s['distances']]for s in model['sources']]
        events=sorted({mp.mpf('.5'),mp.mpf(1)}|{v for aa in A for v in aa if mp.mpf('.5')<v<1}|{mp.mpf('.75'),mp.mpf('.875')});mean_int=mp.mpf(0);gini_int=mp.mpf(0);parts=[]
        for a,b in zip(events,events[1:]):
            mid=(a+b)/2;w,e,pi,k,mean,gini=evaluate(src,A,mid);assert gini<=mean
            coef=[s['mass']*prod(v for v in aa if v<mid)if s['delete']is None or mid<s['delete']else mp.mpf(0)for s,aa in zip(src,A)]
            def integrand(t,kind):
                ww=[cc*t**(-kk)for cc,kk in zip(coef,k)];ee=sum(ww);pp=[v/ee for v in ww]
                return (sum(p*kk for p,kk in zip(pp,k))if kind=='mean'else sum(p*q*max(0,kk-ll)for p,kk in zip(pp,k)for q,ll in zip(pp,k)))/t
            mm=mp.quad(lambda t:integrand(t,'mean'),[a,b]);gg=mp.quad(lambda t:integrand(t,'gini'),[a,b]);assert gg<=mm+mp.mpf('1e-33');mean_int+=mm;gini_int+=gg
            parts.append({'left':enc(a),'right':enc(b),'scores':k,'mean_integral':enc(mm),'gini_integral':enc(gg)})
        el=evaluate(src,A,mp.mpf('.5'))[1];er=evaluate(src,A,mp.mpf(1),before=True)[1];loss=mp.mpf(0);deletes=[]
        for t in [mp.mpf('.75'),mp.mpf('.875')]:
            eb=evaluate(src,A,t,True)[1];ea=evaluate(src,A,t)[1];ll=mp.log(eb/ea);assert ll>0;loss+=ll;deletes.append({'time':enc(t),'e_before':enc(eb),'e_after':enc(ea),'positive_logloss':enc(ll)})
        N=sum(s['mass']for s in src);H=src[0]['mass'];eta0=1-1/(32*mp.sqrt(n));eta_cert=m(model['eta_cert']);nearwt=prod(A[0]);support=eta0*H;support_cert=eta_cert*H
        assert nearwt>=eta_cert>=eta0 and er>=support_cert and el<=N
        raw=mp.log(el/er);res=mean_int-(raw-loss);upper=mp.log(N/support)
        assert abs(res)<mp.mpf('1e-30')and gini_int<=mean_int+mp.mpf('1e-32')and mean_int<raw<=upper
        return {'phase':model['phase'],'n':n,'C_values':{fs(v):enc(x)for v,x in sorted(lookup.items())},'actual_target_d':enc(1/(16*mp.sqrt(n))),'eta0':enc(eta0),'eta_cert':enc(eta_cert),'near_wg':enc(nearwt),'near_H':enc(H),'R':'1.0','R_power_n_H':enc(H),'endpoint_support_lower':enc(support),'endpoint_certified_stronger_lower':enc(support_cert),'e_l':enc(el),'e_r':enc(er),'N_total_source_mass':enc(N),'parts':parts,'deletions':deletes,'integrated_gini':enc(gini_int),'integrated_mean':enc(mean_int),'raw_endpoint_entropy':enc(raw),'actual_delete_logloss':enc(loss),'mean_entropy_residual':enc(res),'near_support_entropy_upper':enc(upper),'scope':'Actual C(d) thresholds on octave tau=.5,g=1, finite atomic law. H is terminal near atom times fixed h_R=1; not original FIRST/good/history qualification.'}

def static_models():
    rows=[]
    for phase,name,n,N,eps,h in [('initial','first_saturation',2,F(4),F(1,4),[F(1,4),F(3,4),F(1,2)]),('stress','small_rho_logplus_zero',8,F(1,2**64),F(3,4),[F(1,2),F(1,4),F(0)]),('expanded','large_rho',32,F(16),F(1,32),[F(1,16),F(1,8),F(1,4)]),('stress','zero_B',8,F(2),F(1,4),[F(0)]*3)]:
        massscale=max(F(1),N);beta=[massscale/3,2*massscale/3];nu=[N/3,2*N/3];p=[[v/massscale for v in row]for row in [[F(1),F(1)],[F(1,2),F(1,4)],[F(0),F(1,2)]]];assert all(0<=v<=b for v,b in zip(nu,beta));vol=[F(1,8),F(1,4),F(1,2)];vol=[4*v for v in vol]if phase=='expanded'else vol;weight=[sum(b*x for b,x in zip(beta,row))for row in p];q=F(1);lam=F(1);eta=F(15,16);H=[N*v for v in h]
        assert all(0<=w<=q for w in weight)and all(0<=hh<=min(4*lam,N/eta)for hh in H)
        E=sum(vol);submass=sum(v*w/q for v,w in zip(vol,weight));B=sum(v*w*hh/q for v,w,hh in zip(vol,weight,H));assert submass<=E
        D=[hh+N*f for hh,f in zip(H,[F(1,8),F(1,4),F(1,2)])];Cglobal=N/(eta*F(1,2)**n);assert all(hh<=dd<=Cglobal for hh,dd in zip(H,D));A=sum(v*w*dd/q for v,w,dd in zip(vol,weight,D));assert B<=A<=Cglobal*E
        rows.append({'phase':phase,'name':name,'n':n,'N':N,'epsilon':eps,'beta':beta,'nu':nu,'p':p,'volumes':vol,'first_masses':weight,'H':H,'varying_D':D,'varying_D_A':A,'coarse_A_upper':Cglobal*E,'q':q,'lambda':lam,'eta':eta,'Evolume':E,'subprob_mass':submass,'B':B})
    return rows

def static_values(rows,dps):
    with mp.workdps(dps):
        out=[];Lambda=mp.mpf(128)/119
        for r in rows:
            n=r['n'];N=m(r['N']);eta=m(r['eta']);a=mp.mpf('.5');E=m(r['Evolume']);B=m(r['B']);eps=m(r['epsilon']);rho=N/a**n;A=2*Lambda*rho/(eta*eps);lp=max(mp.mpf(0),mp.log(A));value=mp.mpf(0)
            for vv,ww,hh in zip(r['volumes'],r['first_masses'],r['H']):
                if hh>0:value+=m(vv)*m(ww)*m(hh)*mp.log(N/(eta*a**n*m(hh)))
            if B:
                tight=B*mp.log(N*m(r['subprob_mass'])/(eta*a**n*B));loose=B*mp.log(N*E/(eta*a**n*B));assert value<=tight+mp.mpf('1e-32')and tight<=loose+mp.mpf('1e-32')
            else:tight=loose=mp.mpf(0)
            rhs=eps*E+2*Lambda*B*lp;assert 2*Lambda*loose<=rhs+mp.mpf('1e-30')
            logsum=sum(m(vv)*m(ww)*m(hh)*mp.log(m(dd)/m(hh))for vv,ww,hh,dd in zip(r['volumes'],r['first_masses'],r['H'],r['varying_D'])if hh>0);Avar=m(r['varying_D_A']);logsum_bound=B*mp.log(Avar/B)if B else mp.mpf(0);assert logsum<=logsum_bound+mp.mpf('1e-32')and logsum_bound<=loose+mp.mpf('1e-32')
            out.append({'phase':r['phase'],'name':r['name'],'rho_nu':enc(rho),'B':enc(B),'dm_total_mass':enc(m(r['subprob_mass'])),'varying_D_A':enc(Avar),'varying_D_logsum_integral':enc(logsum),'varying_D_logsum_bound':enc(logsum_bound),'varying_D_logsum_margin':enc(logsum_bound-logsum),'weighted_entropy_integral':enc(value),'subprob_Jensen_bound':enc(tight),'Evolume_Jensen_bound':enc(loose),'positive_traffic_bound_2Lambda_Jensen':enc(2*Lambda*loose),'logplus_Young_factor':enc(lp),'Young_upper':enc(rhs),'Young_margin':enc(rhs-2*Lambda*loose),'scope':'Static positive-volume cell table satisfying exact FIRST/subprob and necessary hard/support caps. Responses are abstract constants, not actual P_s,L or an MG source-budget realization.'})
        return out

def logrho_costs(dps):
    with mp.workdps(dps):
        Lambda=mp.mpf(128)/119;eps=mp.mpf('.25');gamma=1+mp.exp(-4)/4;zeta=mp.sqrt(1-mp.exp(-4)/4);u=1-zeta;qg=gamma**-2
        M1=9*gamma/(4*zeta)*mp.log(gamma)*qg/(1-qg)**2;M2=9*gamma/(4*zeta)*mp.log(gamma)**2*qg*(1+qg)/(1-qg)**3;A0=3+4*mp.log(2)
        out=[]
        for n in [512,10**6]:
            logrho=mp.sqrt(n);eta=1-1/(32*mp.sqrt(n));kappa=2+n*mp.log1p(1/(8*mp.sqrt(n)));Cn=mp.log(2)+mp.log(n+1)-mp.log(1-1/gamma)
            K=kappa*(A0/u+2*Cn*zeta/u**2)+(A0+2*kappa)*M1/u**2+2*Cn*M1*(1+zeta)/u**3+2*M2/u**2+4*M1**2/u**3
            sourceprice=32*Lambda/mp.sqrt(3)*mp.sqrt(K*kappa);logfee=logrho+mp.log(2*Lambda/(eta*eps));fee=sourceprice*logfee
            assert fee>=n
            out.append({'n':n,'log_rho_input':enc(logrho),'root_reference_times_logrho_exact':n,'MG_source_price':enc(sourceprice),'retained_log_fee':enc(logfee),'explicit_MG_price_times_logfee':enc(fee),'price_over_n':enc(fee/n),'scope':'Formula-only log-domain stress at log rho=sqrt(n); no exp(sqrt(n)) formed, no actual FULL heavy-tail qualification or lower bound on optimal traffic cost.'})
        return out

def numericfields(obj,prefix=''):
    out={}
    if isinstance(obj,dict):
        for k,v in obj.items():
            if isinstance(v,str):
                try:out[prefix+k]=mp.mpf(v)
                except ValueError:pass
            elif isinstance(v,(dict,list)):out.update(numericfields(v,prefix+k+'/'))
    elif isinstance(obj,list):
        for i,v in enumerate(obj):out.update(numericfields(v,prefix+str(i)+'/'))
    return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));p.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md'));a=p.parse_args();mm=models();rat=[rational_model(v)for v in mm];ss=static_models();low={'laws':[actual_model(v,40)for v in mm],'static':static_values(ss,40),'logrho_costs':logrho_costs(40)};high={'laws':[actual_model(v,70)for v in mm],'static':static_values(ss,70),'logrho_costs':logrho_costs(70)}
    with mp.workdps(100):
        x=numericfields(low);y=numericfields(high);assert x.keys()==y.keys();diff=[abs(x[k]-y[k])/max(1,abs(y[k]))for k in x];md=enc(max(diff));assert max(diff)<mp.mpf('1e-28')
    geom=[{'phase':v['phase'],'n':v['n'],'a':'1/2','b':'1/1','d_floor':fs(v['d_floor']),'eta_cert':fs(v['eta_cert']),'near_l1':fs(v['near_l1']),'sources':[{'mass':fs(s['mass']),'distances':list(map(fs,s['distances'])),'delete':None if s['delete']is None else fs(s['delete'])}for s in v['sources']]}for v in mm]
    static=[{k:([list(map(fs,x))for x in val]if k=='p'else list(map(fs,val))if isinstance(val,list)else fs(val)if isinstance(val,F)else val)for k,val in r.items()}for r in ss]
    result={'schema':'R259-near-support-entropy-v1','script_sha256':sha(__file__),'contract_sha256':sha(a.contract),'counts':{'actual_overlap_laws':3,'rational_midpoint_checks':sum(len(v['midpoints'])for v in rat),'actual_interval_records_per_precision':sum(len(v['parts'])for v in high['laws']),'actual_delete_records_per_precision':6,'static_receiver_tables':len(ss),'static_first_rows_exact':sum(len(v['p'])for v in ss),'static_component_mass_chain_checks':sum(len(v['nu'])for v in ss),'static_D_qualification_rows':sum(len(v['varying_D'])for v in ss),'static_tables_with_dm_mass_gt_one':sum(v['subprob_mass']>1 for v in ss),'logrho_cost_diagnostic_rows':2,'precision_fields_compared':len(diff)},'geometry':geom,'rational_checks':rat,'static_receiver_tables':static,'mp40':low,'mp70':high,'precision_max_relative_difference':md,'scope':'Finite actual-C overlap laws and static FIRST/subprob algebra tables. Atomic laws and abstract constant response tables do not certify L1 FULL/history or original gates. Ordinary mp is not outward interval; rho/log fees remain explicit.'}
    a.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':result['counts'],'maxdiff':md}))
if __name__=='__main__':main()
