# R259 先行有界计划

3个新的finite actual-C clock law：n2/8/32三阶段，τ1/2,g1，terminal near v≠y且l1<d/2；另外far terminal与futuredeleted源，保持full posterior。核near权下界、terminal e支持帽、Gini≤mean与包含删除logloss的严格entropy账。有限原子law不认证FULL/FIRST/history，不重跑R258 signed整账。

另3个正体积receiver常数响应表加1个zero-B支：FIRST/subprob与mass资格Fraction，Jensen/Young的log普通mp40/70。响应表只测试不等式实现，不冒称真实P_s,L来源。保原ρ=N/(λa^n)以及显式log费，不由有限模型推统一polylog。

## 最终实际三阶段与计数

3个新的finite law分别n2 initial、n8 stress、n32 expanded，a=1/2,b=cj=R=g=1，τ=a/cj=1/2，clock log长log2（不沿用R258的log4 toy）。每例5源：3 terminal，其中首源near，另2源在3/4、7/8删。终端分割不由原good/bad门生成；有限atomic ν、固定receiver x=0不是正L1/FULL/FIRST/history实例。

实际counts：3 actual_overlap_laws；15 rational_midpoint_checks；每精度18 actual_interval_records、6 actual_delete_records；4 static_receiver_tables、12 static_first_rows_exact、8 static_component_mass_chain_checks；2 logrho_cost_diagnostic_rows；234个40/70显示字段。全部断言通过。没有旧R258 signed全账/旧谱模型重跑。

## 非零terminal near来源与支持帽

dtarget=a/(8sqrt n)=1/(16sqrt n)，取dfloor=1/(16ceil√n)。每个near坐标v_i=dfloor/(4n)>0，y=0；l1距离=dfloor/4严格小于dtarget/2，脚本以有理平方比较认证，不把v=y的平凡重合当near模型。所有坐标也在R1 hardcube内，故h_R(x−v)=1。H取完整terminal近原子的质量（其它源不满足near），未为ν构造L1或actual外receiver模型。

真实A_i=C(|v_i|)来自C(d)=∫h max(h,phi)的E4公式，b=cj1；hard overlap给C(d)≥1−d。所以wg(nearatg)≥∏(1−|vi|)≥1−Σ|vi|≥eta_cert=1−dfloor/2≥eta0=1−dtarget/(2b)。这些hardcomponent几何与乘积比较是Fraction证据，实际C/transcendental值是普通mp。wt随t递减，故g端的下界同时给整个[τ,g]的near权下界。n2/n8/n32的wg约.99522962/.99682749/.99841339，eta0约.97790291/.98895146/.99447573；更强有理eta_cert完整保留。

terminal source从未删除，因此e_r≥eta_cert·R^nH≥eta0·R^nH。实际H质量为1、1/10、1/10000。完整ν总质量N及所有far/E贡献一直保留；没有仅在near槽重新归一。窗口R1归一h_R1，故R^nH=H。

## 完整Π、Gini与含删除entropy

wt=∏min(1,A_i/t)，actual-C的所有激活A_i及两次删除时刻都分片。每片固定scorek，权为coeff·t^(−k)，对同一完整存活ν归一Pi。Gini=ΣPiPi(ki−kj)+≤ΣPi ki=mean逐点成立；积分分片普通mp40/70复算。midpoint Fraction模板独立使用有理A，明确不是actual C认证近似，核Gini≤mean及同一near支持。

删除logloss=Σlog(e_before/e_after)>0；mean积分满足

∫mean dlogt=log(e_l/e_r)−actual_delete_logloss≤log(e_l/e_r)≤log[N/(eta0 R^nH)]。

没有把删除logloss遗漏、改成FB跳或消费第二次信用。所有端点/删除保工作精度，显示字段不参与内部重读。n2/n8/n32的[Gini积分,mean积分,raw endpoint entropy,delete logloss]约为：

- [.12278305,.14865016,.84917550,.70052535]；
- [.12051147,.75158973,6.92666471,6.17507498]；
- [.68510201,1.74017471,16.11969362,14.37951891]。

三例都有严格正删除损失；第二个不等式因删除严格。对应near-support entropy上界约1.58048950、6.96870255、16.13458517。70位mean与端点-删除账残差分别0、−3.62e−71、7.24e−71。这是有限实际积分一致性，不认证一般熵定理或实际原交通付款。

## 静态FIRST/subprob Jensen与Young

4表分initial、stress小rho、expanded大rho与stress zero-B。每表3个互不交正体积receiver box：初探/两压力表体积1/8、1/4、1/2，E体积7/8；最终扩大表体积改为1/2、1、2，E体积7/2，使dm总质量为3/2。其余方向边1、首方向取给定体积，平移可取分离。p_ji为胞内常数非负响应，**不是**实际P_s,L计算。q=λ=1，beta和nu两分量质量显式给出，逐分量0≤nu≤beta，Σnu=N；必要FIRSTΣbeta p≤q与H≤min(4λ,N/eta)均Fraction认证。这样只有必要质量资格，不冒充完整原几何。

令a_j=Σbeta p_j/q≤1，B=Σvol_j a_j H_j。每个有理B、∫a≤|E|精确；H0处0log约定0。普通mp核

Σvol aH log[N/(eta a^nH)]≤B log[N∫a/(eta a^nB)]≤B log[N|E|/(eta a^nB)]。

这里空间下尺度a=1/2；a_j与a不是同一符号。然后取Lambda=128/119，rho_nu=N/(λa^n)，验证

2Lambda B log[rho_nu X/(eta B)]≤epsilon X+2Lambda B log_+[2Lambda rho_nu/(eta epsilon)]。

small-rho表确实走log+=0支，zero-B表不计算log除B、直接置左侧0。4表最终Young margin约3.17652、.65625、35.75702、.21875，均正。MG把B替为来源列费用的通用步骤由主稿/审核证明；这些响应表没有实现实际MG来源/receiver容量模型，不将其说成新原支。

## 保留logrho费用，不能声称新root结论

按主代理提醒，原重尾可能继承rho>exp(sqrt n)；这里不以低rho表宣布原分支非空。仅另加n512与10^6、logrho=sqrt n两个formula-only成本诊断，全程log域、不构造exp(sqrt n)。用R257已给定M1/M2闭式代入Kn，不重跑旧谱或构造高维物理源。

带单位Wpair的显式价[32Lambda/sqrt3·sqrt(Kn κ)]·log_+[2Lambda rho/(eta0 epsilon)]，epsilon1/4，两行约2.56162622e9、5.46565387e11，都超过n。裸root参考费sqrt n乘输入logrho正好为n（纯代数）；这表明该保留log价不能无条件读成root多对数n价。它不是原最优成本的下界，也不证明实际FULL重尾达到这些upperfees，不能把可能的重尾资格当这里已构造的输入。一般显式entropy/Young式仍合法，但本轮数值无新的统一root闭合结论。

## 精度、复现和停止

234个保存字段以50位序列化比较40/70实际工作精度；最大相对差3.9575599452391265335373374318241484935545757622517e−39，分母max(1,|70位值|)。这是普通mp复算一致性，不是outward interval或严格求积误差。Fraction只认证上述有限乘积、score/subprob/质量资格；一般引理来自作者/独审，不由3 laws/4 tables证明。

解压包中脚本与合同同目录执行：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
numeric_checks.py --contract task_contract.md --output numeric_checks.replay.json
```

本机实际Python3.12.14、mpmath1.3.0（vendor如上），标准库Fraction；自足脚本无旧checkpoint/NumPy/SciPy/MATLAB依赖及新安装。JSON绑定源码与合同SHA，无耗时/时间戳/本机路径。正式完整运行已完成，父级从包外唯一完整重放。本轮三责任文件冻结，不扩law或原模型。L03精确与普通mp边界沿用，不声称通用intervalAPI。


## 最后稳定log-sum附列（同4静态表）

没有新增law或table。每胞取有理D_j=H_j+N·(1/8,1/4,1/2)_j，逐胞Fraction验证H_j≤D_j≤N/(eta a^n)。A=Σvol_j a_jD_j、B=Σvol_j a_jH_j；12项D资格及A≥B、A≤N|E|/(eta a^n)精确核对。普通mp比较

Σvol aH log(D/H)≤B log(A/B)，

zero-B仍按0处理。该式不要求dm=vol·a的总量≤1；FIRST仅在把A粗化为N|E|/(eta a^n)时使用逐胞a_j≤1。为显式覆盖此点，现有expanded表的receiver体积整体乘4，dm总量=3/2>1；其余3表dm总量3/8。响应质量资格和nu≤beta不变，没有构造额外物理源或更改3个actual law。

初探varying-D raw/bound约.35365272/.36598928；small-rho约1.5388644e−21/4.0249782e−21；expanded两侧约4.21134711（D/H恒3，等号结构）；zero-B两侧0。这里D为有理表输入，不声称来自表中实际e_tau；一般原D=e_tau/(eta R^n)的资格与交通联结由主稿证明。最终counts额外static_D_qualification_rows12、static_tables_with_dm_mass_gt_one1，234精度字段maxdiff保持3.9575599452391265e−39。旧暂冻哈希由此最终源码/JSON取代，合同保持同版。
