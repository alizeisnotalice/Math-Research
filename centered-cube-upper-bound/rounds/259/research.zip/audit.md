# R259 独立审计

## 命题先行初筛（尚未读本轮作者稿）

本审仅编辑 audit.md。已读本轮 task_contract.md，独立窄读 R113 joint_budget.md 的 B5、B6、B8–10、B18–21 及可测性段，R114 ratio_settlement.md S3–5；不重审此前费用。结论如下。

**原 raw 禁块核的固定时刻对称资格 PASS；以其证明原低 soft 半密度总价仍缺实际测度联结。**

### 原定义确实给出的对称核

固定同一 seed、leaf V、比例带 j 及合法共同 t。R114 的 H_j(t) 是全森林共同阈值，A_{j,t}(y) 是同一半开分区中包含 y 的块：最粗轻节点加最细重补块。故在 V×V 上

- v∈T0(y) 当且仅当 y∈T0(v)（同原顶格）；
- v∉A_{j,t}(y) 当且仅当 y∉A_{j,t}(v)（不同同一分区块）；
- D_V(y) 的 l1≤17na 与 linf≤b(5log n+1/2) 位移门对称；两点均已限于 V；
- w_{j,t}(y,v)=∏min(1,bC(|y_i−v_i|/b)/(c_jt)) 对称。

因此以原定义 Z_{j,V}(y,t)=D_V(y)∩(T0(y)\A_{j,t}(y)) 得
`K_t(y,v)=1_{Z_{j,V}(y,t)}(v)w_{j,t}(y,v)=K_t(v,y)`，至少在共同来源 ν_V⊗ν_V 下成立。fallback 补块仍是分区，h=H 的闭阈值/右连续 convention 不破坏固定 t 对称。原可数 Borel 森林保证联合可测；不以某个新运输分区替换它。

此结论仅针对上述 raw Z。后续 actual high、FIRST、终端 good/bad、suffix、history、receiver 及 y 依赖有效 clock 门须原位保留；若将这些单边门塞进 K 或将 invalid rows 单边置零，对称性须重新核验。共同固定 j,t 的结论不将 x 依赖终端 g 或 y 依赖 heavy interval 变成共同时间域。

### 可逆身份及零来源端点

设 ν=ν_V 有限正测度，e_t(y)=∫K_t(y,v)ν(dv)。0≤e≤||ν||，Π_t=K_tν/e 在 e>0 定义，e=0 行置零。则精确有

`e_t(y)ν(dy)Π_t(y,dv)=K_t(y,v)ν(dy)ν(dv)=e_t(v)ν(dv)Π_t(v,dy)`。

由 Tonelli，零 e 集不会从正度行收到正转移质量（ν-a.e.），所以 Π 是正度域上的 Markov 核。m_t(dy)=e_t(y)ν(dy) 是有限可逆测度；若其总质量>0 可归一为平稳概率，若总质量=0 原核量全零，不能虚构概率归一化。不需要不可约，也不需要源点独立。单个固定 t 的裸核因此给 Lp(m_t) 收缩及

`<f,(I−Π_t)f>_(m_t)=1/2∬K_t(y,v)(f(y)−f(v))²ν(dy)ν(dv)`，

对有资格的 L2 函数成立。这些是可用的正工具，而非原交通付款。

### 最早未付的原测度连接

原外来源是 β(dy)，双 Π 均同一锚点 y；不是 m_t=e_tν。ν≤β 仅给 dν/dβ≤1，不能倒出 β≤Cν，更不能 β=e_tν。若 β 有 ν 奇异部分，直接可逆换测度连形式都不能省略该部分；即便 β=bν，单 Π 换基也保 b(y)/e_t(y)，双 Π 母项保 p_y b(y)/e_t(y)² 及两份 K。原 high 只授 actual receiver 的 ∫high β/e_t≤1/(2K)，不是这些因子的全来源平稳帽。

此外 actual x 选择器、hard z、三 future 腿、good/bad、suffix 和 score `k_t(y,v)−k_t(y,u)` 都不能随 y↔v 交换而免费保持。k_t(y,v) 本身对称不等于三点 score 差对交换不变。若另有非对称 actual source gate，最多可保其原核，或以两门 min 得真正对称子核并保正余项；不能称它支付了全量。任何 Schur/Dirichlet 接入必须先展示同一 ν、真实 dx 与原 hard z 下实际二次槽、两侧可付权及逆 e 费用。

固定时刻的 m_t 又随时间变化，不能把 fixed-t 可逆性视为整个时钟过程的共同平稳性；跨 t 分部会产生真实 degree/禁块删除项。当前没有借此消去原 score/clock 或给 lowlabel 一般根价，也未借原 N_del 或已耗 N_Z 信用。

## 实际有限算术检查（可复现，非实际核模型）

以下标准库 Fraction 程序已由本人实际运行，输出 PASS22。它只核共同分区对称核的详细平衡/平稳/Dirichlet/零行端点；权重是有理对称模板，不是实际 C 核或 FULL 证书。

```python
from fractions import Fraction as F
nu=[F(1),F(2),F(3),F(5)]
A=[[F(1,1+abs(i-j)) for j in range(4)] for i in range(4)]
labels=[0,0,1,2]; top=[0,0,0,1]
K=[[F(top[i]==top[j] and labels[i]!=labels[j])*min(F(1),A[i][j]/F(3,4)) for j in range(4)] for i in range(4)]
e=[sum((K[i][j]*nu[j] for j in range(4)),F(0)) for i in range(4)]
Pi=[[K[i][j]*nu[j]/e[i] if e[i] else F(0) for j in range(4)] for i in range(4)]
checks=0
for i in range(4):
 for j in range(4):
  assert e[i]*nu[i]*Pi[i][j]==K[i][j]*nu[i]*nu[j]==e[j]*nu[j]*Pi[j][i];checks+=1
for j in range(4):
 assert sum((e[i]*nu[i]*Pi[i][j] for i in range(4)),F(0))==e[j]*nu[j];checks+=1
f=[F(1),F(-2),F(3),F(4)]
lhs=sum((e[i]*nu[i]*f[i]*(f[i]-sum((Pi[i][j]*f[j] for j in range(4)),F(0))) for i in range(4)),F(0))
rhs=sum((K[i][j]*nu[i]*nu[j]*(f[i]-f[j])**2/2 for i in range(4) for j in range(4)),F(0))
assert lhs==rhs;checks+=1
assert e[3]==0 and all(x==0 for x in Pi[3]);checks+=1
print('PASS',checks,'fixed symmetric partition-kernel identities; not actual C/FULL/source payment')
```

初筛已完成；等待作者精确实际桥后审查，不将本文件当前状态称为本轮最终冻结。


## 检查点补充：旧工具身份与实际 hard 来源的换基

已从 R226 冻结 research.zip 直接实读 source_geometry.md SG3（第78–120行）：其 SG6–8 已证明同一分区/fallback/距离门的对称与详细平衡。因此本轮上述原资格筛查是**旧工具重新核验，不记为 R259 新数学进展**。未因本轮22项代数检查重新登记该旧定理。

父级另提出实际 hard 来源换基；独立筛查在明确原支持下成立。原 aω 保 hard z∈Z_g(y)，t≤g 及嵌套给 z∈Z_t(y)。令 η=1{||y−z||1≤d/2}，保原 far t≤g≤bc_j、c_j≤1，则 c_jt≤b。由 C(u)≥(1−u)+ 得

`w_t(y,z) ≥ ∏(1−|y_i−z_i|/b)+ ≥ 1−||y−z||1/b ≥ 1−d/(2b)>0`。

中间乘积不等式在总位移≤d/(2b)<1上合法；d=a/(8sqrt n) 给反权≤16/15。因此在该原实际 near 支持，准确有

`1_actual(z)ν(dz)=1_actual(z)[e_t(y)/w_t(y,z)]Π_y,t(dz)`，

其中 1_actual 必保原 hard z 的所有门，h_R(x−z) 仍在该槽内。可将反权正上放为 (1−d/(2b))^−1，但 **e_t(y) 必须保留**；不是把 hard ν 直接换成一个概率 Π。原两个 aux Π 因此变成同锚点三个 Π 的实际联合积分，不能以此识别独立来源、消除真实 dx/β、高门或重用已耗负信用。该精确 RN 身份本身还不是新原量付款。


## 新实际 near 熵费用：命题先行独筛

**条件明确后的候选 PASS，未声称统一 root 付款。** 此结论针对仍未付的原 positive near 子交通；不是重用可逆性。

固定 seed,leaf，N=||ν_V||，η0=1−d/(2b)>0。原 aω 与实际 s,L,R,j 对辅助 clock 静态；定义 H(x,y)=∫1near h_R(x−z)aω(x,y,z)ν(dz)，其中 aω 必仍保 actual hard z∈Z_g(y)。由 near 权下界得 e_g(y)≥η0R^nH≥η0a^nH。若 aω 包含辅助 t 依赖门，须先给真正静态且仍有 terminal support 的承载函数才能这样定义 H；不能从删过门的 R229 majorant 恢复该支持。

固定真实行的 Jfar 是一个区间 (l,r)⊂[τ_j,g]，采用 l+,r−。完整 Z_t 非增，权重连续递减，故

`∫_l^r E_(Π_y,t) k_t dlogt = log[e_l+(y)/e_r−(y)] − Σ_(l<t<r)log[e_t−(y)/e_t+(y)] ≤ log[N/e_g(y)]`。

这里真实删除使 log 度数额外下降，减号正确；若未来删除具有一般 BV 版本应保完整对应 Stieltjes 下降。有限原森林版本给有限跳，足够本接口。终端 e_g>0 的行可用此式；H>0 强制 e_g>0；H=0 时该 hard 来源行积分为零，无需除零或 0·∞。N=0 则整 leaf 为零。原 gated G×B score ≤完整 iid 正差≤EΠ k，故可正放到此完整均值；不声称人工 soft 标签支配 score。

记 A=N/(η0a^n)，那么 0≤H≤A，f(h)=h log(A/h) 在[0,A]非负凹、f(0)=0。逐 x 的原 high 测度 dσ_x(y)=1high p_yβ(dy)/q 是 subprob（FIRST 及原域保留），补足缺失质量于 h=0 后得 ∫f(H)dσ≤f(∫H dσ)。unique j 先逐 x 合并，a,N 对这些 j 共同；再对有限 Lebesgue 接收域 E_V Jensen。若 B_V=∫E_V∫H dσ dx，有

`Pnear,V ≤2Λ B_V log[A |E_V|/B_V]`。

B=0 或 |E_V|=0 贡献按极限为0；|E|无穷时先有限共同截断，有限ελ|E|才有意义。没有把 β 识别为 ν 或将 high 投影成无资格 source 容量。

令 s=B/|E_V|，s log(c/s)≤c/e 给安全 Young 式

`2Λ B log[A |E_V|/B] ≤ ελ|E_V|+2Λ B log_+[2ΛN/(η0 ελa^n)]`。

对数非负后可将 B 上放为 R257 全soft实际near价 (16/√3)√(K_nκ)√WβWν，故同 seed 不交 E_ω,V 使接收项总和≤εX；完整 outer 来源费为

`(32Λ/√3)√(K_nκ) EΣV √(Wβ,V Wν,V) log_+[2Λ||ν_V||/(η0 ελa^n)]`。

全部 Θ/high/history 在正上放前原位存在；hard z 的 terminal support 是新增连接所需的真正资源。此价覆盖该 actual near **正**余交通，不借 R258 signed 边界或任何旧负信用。它去掉了裸 n clock 因子与逆终端度数，得到确切非线性费用；仍有一般来源 logρν 的联合预算未证，不把该矩改名为全目标闭合。若 a,N,q 随 outer data 变化，该费用必须保持在原期望/求和中。

本人实际用 mp60 跑下列8项 Jensen/Young 有限诊断（非区间，非 FULL）；一般结论来自上面的凹性和原量证明。

```python
import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
mp.mp.dps=60
f=lambda A,h: h*mp.log(A/h) if h else mp.mpf(0)
checks=0
for A in [mp.mpf('0.5'),mp.mpf(2)]:
 H=[A/5,3*A/4]; w=[mp.mpf(1)/4,mp.mpf(1)/2]
 bx=sum(wi*hi for wi,hi in zip(w,H))
 assert sum(wi*f(A,hi) for wi,hi in zip(w,H))<=f(A,bx);checks+=1
 B=bx+2*A/10
 assert f(A,bx)+2*f(A,A/10)<=B*mp.log(3*A/B);checks+=1
for A,B,M,epslam,C in [('2','.3','1','.01','3'),('.001','.0002','2','4','2'),('2','0','1','.1','2'),('2','2','1','.1','2')]:
 A,B,M,epslam,C=map(mp.mpf,(A,B,M,epslam,C))
 lhs=C*B*mp.log(A*M/B) if B else mp.mpf(0)
 rhs=epslam*M+C*B*max(mp.mpf(0),mp.log(C*A/epslam))
 assert lhs<=rhs;checks+=1
print('PASS',checks,'finite Jensen/Young diagnostics; not FULL or a general proof')
```


## source_bridge.md 全文作者后审

受审 SHA256 `476244c95e71b073a3f0ebcfc0d34e396a3038b309e3ee400fae3d57678b8b01`，SB1–7 **PASS**。三 future 腿的 good 支配只用于真实 good 槽；SB4 hardcap 前与 SB5 一次 hardcap 后是替代上界，不叠收 hard 系数。SB6 物理半径与 clock 半径不同，gamma^(n/2) 费及 SB7 早时钟反权保留，未把 barw_m 识别为 w_t(m)。

SB9 的 source dual cap 是已有 R224 TR3 的正确算子形式：以同 y 的 β 做 Cauchy 得 m(v)²≤C∫H p_y1Z w_t/e_t β，ν 积分恰为 AC。SB10 只限独立于 y 的 target F_x，若带 u、score/history 或改变 y 的 source 门，必须回到原积分；普通 source marginal 没有 sqrt(p_y) 时 A 替换为真实 β 质量，不能免费去掉。high 与 FIRST 保原共同 receiver 条件，heavy 的 βmass/(B_jt^n) 也是有价的。

SB5 对称资格、旧 R226 归属、beta excess 与 transposed gates 的限制与独立初筛一致。SB6 原 actual hard 来源终端支持、near 反权、带 h_R 的物理单位与 triple posterior 的 p_y e_t/q 均准确；不授 high 对此乘子的上帽。作者没有把这些接口登记为新交通付款。

本人实际抽取运行 SB7：20 项标准库 Fraction 全部通过，四行数值与 Markdown 保存输出逐行相同。它们是有限有理核代数，不是实际 C 核、FULL 或一般移动列付款证书。


### 当前重尾下门：不得把新费用读成实际 global-smallρ 分支

compare 后续窄核指出当前 global hard 来源仍继承重尾门。本审进一步亲读 R108（20261013）parent_integration.md 第133行：receiver 删除后，同一冻结硬尾仍满足 `m_V>λa^n exp(sqrt n)`；并亲读 R113 coupled_transport.md C7–C9 周围“未更改已经构造的当前硬尾 ν”“原hard来源…不重建”。因此对现行非零 ν_V，N/(qa^n)>exp(sqrt n)（q≤λ），N/(λa^n)亦>exp(sqrt n)。

故将 B 上放为 MG 根阶列价后，其 global logρν 费并不获已证 polylogn；不能以任意正测度工具中的 smallρ 条件宣称当前实际源域新 root 付款，也不能默认该条件分支非空。新精确 `2ΛB log(A|E|/B)` 是合法实际联合量费用，未证明逐输入优于已有 n·B（或其它旧界）；旧界可保留取较小者。当前确切未付对象仍是其实际拥挤度/receiver/source 联合预算，不能以该费用的重新命名替代全局目标。


### 精确端点费用的加强（作者稿前独筛）

对静态实际 positive 核份额 ptilde≤p_y（lowlabel、未付正余量等），令 dm=1_E ptilde β(dy)dx/q，a_row=e_τj(y)/(η0R(x)^n)，A_V=∫a_row dm，B_V=∫Hdm。H≤a_row，因而可先在同一原行保完整实际端点，而不立刻以 N、a、|E| 上放。有限共同截断下，H加权的 log-sum/Jensen 给

`Pnear,V ≤2Λ∫H log(a_row/H)dm ≤2Λ B_V log(A_V/B_V)`。

这一步对有限 dm 无需概率归一：B>0 时以 Hdm/B 归一，再用 ∫_(H>0)a_row dm≤A 即可。B=0 行全零，A=0 强制B=0，按极限置0。A无穷时只得扩展上界，不伪称有有限付款。原 FIRST 才用于其后 A≤N|E_V|/(η0a^n)。另完整 gated iid Gini≤n/4 与原 logclock≤log2 独立给 `Pnear,V≤2Λ(nlog2/4)B_V`；可同精确熵式取较小者。

Young后还可安全保 `ελ|E_V|+2ΛB_V min{nlog2/4,log_+(2ΛN/(η0 ελa^n))}`：它由两个合法上界推出（给旧clock界添加非负ελ|E|后再取min）。这仍是有实际端点/degree信息的联合费用，而非全root结论；尤其不放松当前重尾门。


## joint_geometry.md 与主稿全文后审检查点

joint_geometry.md SHA256 `b3f7e34e7afdaf434fbe86554b2e9b09e123c03055543c4f2a45a2f86a5f3486` 全文 **PASS**。JG2 特别保静态 hard RN 门及原 terminal support，不从已松掉门的上界恢复。JG3 全区间以右连续起端和 g 终端给删除方向安全；实际 far 子窗仅正上放到 raw [τ_j,g]，不重建 Π、也不丢 actual 全时钟依赖门后反用它们。JG3.4 任意有限 dm 的 H 加权 log-sum 正确，zero H 与完整 A 正放方向准确。

JG4 原 FIRST 与 MG 源列费用未混核，先 exact A/B、再逐点端点帽、再 Young 与非负 fee 的次序合法。JG4.3 的 min 在允许加 receiver ε 费后使用，不声称积分取min的普遍交换。外系数 32Λ/√3、原 j 消去、同种子 receiver-leaf 不交吸收εX均正确。JG5 actual重尾资格明确；两个 moving-distance 壳的支持差由三角不等式得到，不能凭壳薄推出 L1 源质量小。未授 anchor change 消逆度、实际几何根阶或新负信用。

本人实际从 JG6 提取运行标准库 Decimal60 程序，`PASS 28 Decimal scalar checks; precision=60`，与作者输出匹配。只是有限标量诊断，非 actual FULL、非向外舍入证书。

主 proof.tex.txt 已完整实读：W/D/E0/E1/E2/E3 与上述独立推导一致；精确 E0 明确在叶总质量粗化前由原端点推得，非从 E1 反推。内侧 l+,r−、内部删除和、H0/空来源/有限截断、FIRST subprob、原 high/valid、同来源费用及第三 future 腿缺口均保留。当前主稿不称新统一根阶付款；将精确共同熵作为联合量价而非总体闭合。等待报告、正式数值与驱动最终冻结后仅做必要一致性审查及 SHA 绑定。


## 最终一致性审查与冻结结论

**PASS：所列原量条件下的实际共同接收熵费用及原接口；本轮未取得新的统一 root 付款。** 主稿、两作者稿、报告、数值与驱动当前版本已完成必要审查，无待修阻断。

source_bridge 最终仅追加 SB8，已实读；它将当前 global ρ 固定为 N/(λa^n)，保完整 R107→R108/R109 轻尾重付→R113 hardν不重建链。此修订与本人亲读的必要原片段一致。它没有改变已独立执行过的20项附录；旧版本 SHA 仅为前述后审检查点，以下最终表覆盖它。

主稿最终 E0–E3 与 joint_geometry JG1–5 完整一致：真实 static H 保终端hard来源，度数端点/删除方向正确，exact A/B 先保相关性，FIRST 与 MG 的后续粗化清楚，旧 Gini 价格仍可取较小者。report 准确区分已证联合量价、重尾下门对研究决策的限制与尚未闭合的原near/lowlabel/far总账；没有把 root 系数乘未付 logρ 称为新 root 分支，也未重领 R257/258 付款或 R223 负信用。

正式 numeric_checks.py 完整静读通过。three actual-C finite law 的正 near 源非零位移、terminal support、完整后验、坐标激活与删除分段、Gini≤mean、mean=logendpoint−deleteLoss 均按同一模型实现；τ=1/2,g=1 符合 octave 工具范围，但原子 law 不认证 actual FULL/good/history/L1 来源。独立有理 threshold 模板明确不是实际 C 的有理近似。四个静态响应表具有 Fraction FIRST/subprob、ν≤β、H≤D 及 A≥B 资格；D 是表输入，未冒称来自表中真实 eτ。expanded 的 dm 总质量3/2保留，正确验证 log-sum 不要求 dm 为概率。smallρ 表只是代数工具域，未据此声称当前重尾实际分支非空。

保存 JSON 的源码/合同 SHA 已与实际文件核对。正式计数为3 actual laws、15 rational midpoint、每精度18积分段与6删除记录、4静态表、12 FIRST行、8分量质量比较、12 D资格行、1个dm质量>1表、2个formula-only logρ费用行；234字段最大40/70相对变化3.9575599452391265e−39。普通 mp 复算不是 interval 或 FULL 证书，formula-only费用不是实际最优费用下界。作者/主代理实际整套执行与本人源码/保存输出审查分开；本人没有重复正式整 JSON 运行。

本人本轮实际独立运行并保可复现代码/来源：audit22项 Fraction 固定核、audit8项 mp60 Jensen/Young、source_bridge20项 Fraction、joint_geometry28项 Decimal60。这些是工具/有限算术诊断，不混成原实例数量。

reproduce.py 最终静审通过：manifest前后核验、全JSON重算逐字节比对、audit/source_bridge/joint_geometry三个Markdown全部Python附录抽取执行。audit含两个代码块，driver未假定每稿仅一块。driver验证有限实现，不能替代一般证明；最终包外整套运行由主代理随后登记独立receipt，不提前称本人已执行。无其他文件改动，无Git/PDF或新模型扩展。

## 最终受审 SHA256

以下绑定九件，audit不自绑定以免manifest循环。此处完成后本文件停止写入。

| 文件 | SHA256 |
|---|---|
| task_contract.md | 9501ec5459057f52a635a37156f5b62a241ea53f2130fc3d9d14b8981d4df934 |
| proof.tex.txt | 7190238706babcd75563c81287b0c8f6a0d77e71537ccaf962559ff73ee6ec8b |
| source_bridge.md | 5d0067c2795093a181fa0f48e5d574acb579302a66da9d30e9ebfb0081d6efa7 |
| joint_geometry.md | b3f7e34e7afdaf434fbe86554b2e9b09e123c03055543c4f2a45a2f86a5f3486 |
| numeric_checks.py | ee995adad17fd9a8e07798f4e9a344c3202a2c3283e225baed631bde6ebfd5c0 |
| numeric_checks.json | ff4b2eca9c817855647368b3bb9dba540991565969ad8d296e35a2ef82ac49e4 |
| numeric_notes.md | f77954ab86b818dc53deb0266f24b02c6a3fa127fb8a80e447fd4299e0998323 |
| report.md | f8d68d3e9e17976ee297e31e69a5b50aed236995d9c89acdea11915f7402b119 |
| reproduce.py | 941efaf1cdc9be8ed8f95b82140512b0e9127e7ca80fa3442ab6f5d5c5032951 |
