# R259: exact original half-density and source-exchange contract

This note restores existing interfaces for the common joint-geometry
route. The source Cauchy bound below is the operator form of the already
proved R224 TR2--3; raw reversibility is the already audited R226 SG6--8.
They are not registered again as new traffic payments. No position,
clock, source-mass, or inverse-weight fee is discarded.

## SB1. Original sources, selectors and normalized clock

Freeze the full original seed and retained terminal leaf V. The actual
coupled sources obey `nu_V<=beta_V<=alpha_V=mu_hi|V`, with disjoint V
for each seed. This is R113 coupled_transport.md:51--84, retained in
R237 source_ledger.md:17--32,82--100. Beta is not an independent second
sample from nu; no bound on d beta/d nu follows from nu<=beta.

The actual receiver uses `a<=L(x),R(x)<=b<=2a`, common scalar s(x),
`p_y(x)=P_s(x),L(x)(x-y)`, `g=sqrt(LR)`, and its unique j(x). The
one-dimensional factors are those of R116 astra_first.md:9--16:

    h=1[-1/2,1/2], w(u)=integral_0^1 exp(-|u|/r)dr,
    phi=h*w, P_s,L(v)=L^-n product_i[(1-s)h(v_i/L)+s phi(v_i/L)].

Retain the actual strict-soft and inherited upper/deletion gates;
no pure-hard boundary input is added. The original receiver has
`M_[a,b]f<=4lambda` and `3lambda/4<=q<=lambda`. The all-hard-scale
qualification is R244 receiver_ledger.md:9--27 (master G_0 band),
not an inference from one selected hard scale.

For fixed `(omega,V,j,y,t)`, before receiver x is integrated, write

    C(d)=integral_[-1/2,1/2] max(h,phi)(u-d)du,
    A_i(y,v)=b C(|y_i-v_i|/b)/c_j, c_j=(1+1/n)^(-j),
    w_t(y,v)=product_i min(1,A_i/t),
    Z_t(y)=D_V(y) intersect (T_0(y) minus A_(j,t)(y)),
    e_t(y)=integral_Zt(y) w_t(y,v)nu_V(dv),
    Pi_y,t(dv)=1_Zt(y)(v)w_t(y,v)nu_V(dv)/e_t(y),
    k_t(y,v)=sum_i 1_{A_i(y,v)<t}.                         (SB1)

These are R117 joint_geometry.md:9--30,71--74 and R128 proof.md:636--650.
Pi and e are independent of x and original hard z at this fixed index.
The actual g, good/bad sets, target kernels and history are not.
Both copies in the positive quantity are the same Pi_y,t. Empty or
invalid rows are set to zero before division. The heavy condition is

    e_t(y)>B_j t^n, B_j=ell q c_j^(-n/2), ell=1+log n,
    tau_j=a/c_j<=t<=g<=b c_j.                            (SB2)

The original high condition is `p_y(x)e_g(y)>=2Kq`. Since t<=g,
e_t>=e_g on a valid row. These conditions may depend on y and x;
they do not turn Pi_y,t into a y-independent source.

## SB2. Best common three-leg formula before scale comparisons

Let `K_1,x(v)=P_s,L(x-v)`, `K_2,x(v)=P_s,L+(x-v)` with
`L+=min(b,(1+1/n)L)`, and `K_3,x(v)=J_x(v)=P_1,b(x-v)`.
Original terminal-good implies

    p_y w_g(y,v)<= (K/3) sum_(a=1)^3 K_a,x(v),
    p_y<=sqrt(K/3) sum_a sqrt(p_y K_a,x(v))/sqrt(w_g(y,v)). (SB3)

Use SB3 in the original positive mother quantity while its hard kernel
is still present. Its legal upper expression has exactly the exterior

    2Lambda sqrt(K/3) E sum_(V,j) integral dx beta_V(dy)nu_V(dz)/q
       h_R(x-z) a_omega(x,y,z)
       integral_Jfar dt/t integral Pi_y,t(dv)Pi_y,t(du)
       chi rho_0(v) [k_t(y,v)-k_t(y,u)]_+
                         sum_a sqrt(p_y K_a,x(v))/sqrt(w_g(y,v)). (SB4)

All actual indicators, current remaining positive allocation and history
belong to chi and/or a_omega, with values in `[0,1]`. None is rebuilt at
a kernel node. The exact source-pair gate can still be retained here.
The coefficient is the one original `2Lambda`, `Lambda=128/119`; this
formula contains no prior hard-cap charge and no physical/soft mesh fee.
It is R224 traffic_reentry.md:11--35 and R229 adaptive_geometry.md:174--181.

Alternatively, integrate hard z once using R222's actual conditional
average eta. Since `q^-1(h_R*nu)<=16/3`, the three-leg upper bound becomes

    P_rem<= (32Lambda/3)sqrt(K/3) E sum_(V,j,a)
       integral_E dx integral beta_V(dy) integral_Jfar dt/t
       integral Pi_y,t(dv)Pi_y,t(du)
       eta delta_t sqrt(p_y K_a,x(v))/sqrt(w_g(y,v)).       (SB5)

Here `0<=eta<=1` still contains original high/valid/unique-j and history
qualifications, with hard-source-dependent gates conditionally averaged
as in R222 source_occupancy.md:37--52,112--158. SB5 is R224 TR1 before
any comparison with barw_L: no gamma^(n/2) has been paid. The hard
factor must not be inserted again after SB5, or charged twice.
SB4 and SB5 are alternatives. Allocating each leg to actual positive
traffic, when needed, uses the existing TR1a weight
`lambda_a=sqrt(K_a)/(sum_b sqrt(K_b))`; zero sums receive weight zero.
The actual remaining positive complement and all negative credits stay
on their original ledger.

## SB3. Exact physical-weight versus clock-weight fee

Define a separate physical-radius notation

    barw_r(y,v)=product_i min(1,b C(|y_i-v_i|/b)/r).

Then `w_t=barw_(c_j t)` and `w_g=barw_(c_j g)`. If
`m=min(L,R)`, the actual ratio band gives

    m<=c_j g<=(1+1/n)m=gamma m,
    gamma^(-n)barw_m<=w_g<=barw_m.                    (SB6)

Thus replacing `1/sqrt(w_g)` by `1/sqrt(barw_m)` costs at most
gamma^(n/2)<=sqrt(e). The notation `barw_m` is not the original
`w_t` evaluated at t=m; it equals the latter evaluated at t=m/c_j.
These statements are R222 source_occupancy.md:19--80.

For t<=g, the exact weight ratio is

    log(w_t/w_g)=integral_t^g k_r(y,v)dr/r,
    1<=w_t/w_g<=(g/t)^n.                             (SB7)

This is a coordinatewise identity, not an integral of posterior means.
Consequently replacing the half-density denominator by sqrt(w_t)
costs exactly sqrt(w_t/w_g), bounded by `(g/t)^(n/2)`. On the terminal
band `g exp(-d_clock/n)<=t<=g` it costs at most exp(d_clock/2), as
R224 TR4 proves. It is not a constant across the whole clock.

Likewise `sqrt(w_t/barw_m)<=max(1,m/(c_j t))^(n/2)`;
converting a physical-radius denominator to a clock denominator can
have this earlier-clock cost. Neither SB6 nor heavy removes it. One
may instead keep w_g or barw_m in the geometric kernel; a theorem
using that route must not also silently invoke the w_t Cauchy bound.

## SB4. Exact source dual cap: existing TR3 in operator form

Fix actual x, its unique j, t and V. Let H_x,t(y) be the original
high/valid indicator (possibly with further positive y-only restrictions),
zero outside legal e_t>0 rows. Put

    A_x,t=integral H_x,t(y)p_y(x)beta_V(dy)<=q,
    C_x,t=integral H_x,t(y) beta_V(dy)/e_t(y).

The actual high and FIRST give R224 TR2, and heavy gives independently

    C_x,t<=min{1/(2K), ||beta_V||/[B_j t^n]}.          (SB8)

Neither bound removes the receiver restriction H. Define the true
nu-density of the weighted half-posterior marginal by

    m_x,t(v)=integral H_x,t(y) sqrt(p_y(x))
                         1_Zt(y)(v)sqrt(w_t(y,v))/e_t(y) beta_V(dy).

Cauchy in y, followed by Tonelli and the actual Pi probability, proves

    integral m_x,t(v)^2 nu_V(dv)<=A_x,t C_x,t.         (SB9)

Indeed pointwise `m(v)^2<=C_x,t integral H p_y 1_Zt w_t/e_t beta(dy)`;
its nu integral equals `C_x,t integral H p_y beta`. Therefore for every
nonnegative measurable F_x(v), independent of y,

    integral H beta(dy) integral Pi_y,t(dv)
                           sqrt(p_y(x)) F_x(v)/sqrt(w_t(y,v))
       <=sqrt(A_x,t C_x,t integral F_x(v)^2 nu_V(dv)). (SB10)

For `F_x=sqrt(K_a,x)`, SB10 is the already proved R224 TR3 (lines 48--80),
with its full finite C_x,t retained. All actual s(x),L(x) remain inside
the same-x FIRST; no backward-node FIRST is assumed. Fixed J has an
actual global column integral ||nu_V||; moving K_1,x,K_2,x do not gain
that column normalization from SB10. Full same-x future FIRST may cap
their responses, but subsequent dx integration still carries receiver
volume and clock costs.

For the unweighted source marginal explicitly asked about,
`integral H beta(dy)Pi_y,t(dv)/sqrt(w_t)`, the same proof gives the
dual norm bound with `A_x,t` replaced by `integral H beta<=||beta||`.
Thus a genuine L2(nu) source cap exists, but it retains beta mass if
sqrt(p_y) is absent. Heavy supplies no free pointwise density cap.
If F depends on y, SB10 cannot replace it by one target column; the
unreduced beta--nu Cauchy integral must be retained. Extra u-Pi, score,
eta and history also cannot be made independent of y by this estimate.

## SB5. Genuine raw reversibility and its exact scope

For a fixed full seed,V,j,t the forest and h(A),H_j(t) are common.
R114 ratio_settlement.md:28--43 defines the coarsest light block
`h(A)<=H_j(t)` on each path, with the original finest heavy fallback.
The inclusion-maximal light blocks are disjoint. A point not in one
lies in a finest heavy fallback cell; these complete the same partition
of each T_0. Hence, with consistent half-open boundary conventions,

    v in A_(j,t)(y) iff A_(j,t)(v)=A_(j,t)(y)
                       iff y in A_(j,t)(v).         (SB11)

The distance relation `D_V(y)` is the symmetric R113 B5 upper cut
`||v-y||_1<=17na`, `||v-y||_infty<=b(5log n+1/2)`, with both in V.
Same T_0 is symmetric as well. Thus raw `Z_t(y,v)=Z_t(v,y)` and w_t
is symmetric. R226 source_geometry.md:81--113 already records and
proves exactly this qualification; no new partition is being selected.
The set relation does not require y to belong to nu support.

On nonempty rows detailed balance is

    e_t(y)nu_V(dy)Pi_y,t(dv)
      =Z_t(y,v)w_t(y,v)nu_V(dy)nu_V(dv)
      =e_t(v)nu_V(dv)Pi_v,t(dy).                    (SB12)

Zero-degree rows have zero e_t nu measure and their masked kernel is
zero. Its stationary measure is e_t nu, not beta, nu, or p_y beta.
For the shared nu part, unweighted anchor/source exchange costs

    nu(dy)Pi_y,t(dv)
       =[e_t(v)/e_t(y)]nu(dv)Pi_v,t(dy).             (SB13)

Use SB13 only on its nonzero-edge support; then both degrees are
positive, up to the relevant null sets. Even with nu<=beta one only
has `beta=nu+(beta-nu)`; the excess anchor source remains. All actual
high/valid and history indicators must be transposed, not incorporated
as if the raw symmetric kernel still had them symmetrically. For two
Pi factors, swapping one endpoint also changes the other conditional
law; its degree/score costs cannot be omitted.

These formulas give no additional free hard-z posterior. If a proof
uses the exact original hard-z source-born exclusion from R114 S4,
it must retain that original gate and account for the full inverse
w_t when changing nu(dz) to e_t Pi_y,t(dz)/w_t(y,z). A near-distance
indicator alone grants neither same top block nor the forbidden-block
exclusion. A later upper bound that removed a source gate cannot be
treated as retaining it without returning to the original mother term.

## SB6. Near hard-source normalization, only with its original support gate

There is an explicit stronger support statement for the original actual
hard z before any source-gate relaxation: R114 ratio_settlement.md:28--43,
S3--4, proves `z in Z_(j,V)(y,g)`. It uses the original strict CP LCA
mass test `h(P)>H_j(g)`; being in the same light block contradicts this,
and being in the same finest fallback has no distinct-child LCA.
R117 JG5:47--54 retains these CP/history conditions in the actual RN
kernel. Because forbidden blocks grow with t, that original support
implies `z in Z_g(y) subset Z_t(y)` for t<=g. This is not inferred from
proximity or from an upper bound whose a_omega has already been removed.

For any fixed distance cutoff `0<=r<b`, on `||y-z||_1<=r`,
`C(d_i)>=(1-d_i)_+` and `c_j t<=c_j g<=b c_j^2<=b` imply

    w_t(y,z)>=product_i(1-|y_i-z_i|/b)>=1-r/b,
    w_g(y,z)>=1-r/b.                                 (SB14)

The product inequality follows by induction for nonnegative coordinate
ratios whose sum is below one. It gives a real degree-normalization
bound without a minimum source mass:

    integral_{near intersect Z_t(y)} nu_V(dz)/e_t(y)<=1/(1-r/b),
    1_near 1_Zt nu_V(dz)
       =1_near e_t(y)Pi_y,t(dz)/w_t(y,z)
       <=[e_t(y)/(1-r/b)]Pi_y,t(dz).                 (SB15)

For `r=a/(16sqrt(n))`, the inverse-weight cost is at most 16/15.
If h_R is kept, the corresponding bound is
`integral_near h_R 1_Zt nu/e_t<=R^-n/(1-r/b)`; its physical units have
not disappeared. A soft/auxiliary transposition must still carry all
actual capture, good/bad, history, score and source-role restrictions.
Indeed replacing the original hard nu by this third posterior in the
unrelaxed mother density produces

    (p_y e_t/q) h_R a_omega
       Pi_y,t(dz)Pi_y,t(dv)Pi_y,t(du)/w_t(y,z),

with the original score and remaining gates. Neither high nor heavy
provides an upper bound on p_y e_t/q. SB15 is an actual source-normalizer
interface, not a payment of this full triple-posterior quantity.

## SB7. Bounded exact algebra diagnostics

The following standard-library Fraction script was actually executed:
20 checks, exit 0. These are finite weighted-kernel tests of SB8--13,
not physical cube instances, source histories, or a proof of a global
moving-column budget. The proofs are the measure arguments above.

```python
from fractions import Fraction as F
checks = 0
for c in range(4):
    nu = [F(1),F(2),F(3),F(4)]
    beta = [F(3,2),F(5,2),F(3),F(9,2)]
    w = [[F(0) if i==j else F(2+((i+j+c)%3),4)
          for j in range(4)] for i in range(4)]
    e = [sum(w[i][j]*nu[j] for j in range(4)) for i in range(4)]
    pi = [[w[i][j]*nu[j]/e[i] for j in range(4)] for i in range(4)]
    assert all(e[i]*nu[i]*pi[i][j] == e[j]*nu[j]*pi[j][i]
               for i in range(4) for j in range(4))
    checks += 1
    # Only anchor 0 is high/valid; all test values stay positive.
    p = [2/e[0]]+[F(1,100)]*3
    assert sum(p[i]*beta[i] for i in range(4)) <= 1 and p[0]*e[0] == 2
    checks += 1
    A,C = p[0]*beta[0], beta[0]/e[0]
    # Squaring eliminates the square root in m(v) exactly.
    norm2 = sum(beta[0]**2*p[0]*w[0][j]/e[0]**2*nu[j]
                for j in range(4))
    assert norm2 <= A*C and C <= F(1,2)
    checks += 1
    norm0 = sum(beta[0]**2*w[0][j]/e[0]**2*nu[j] for j in range(4))
    assert norm0 <= beta[0]*C
    checks += 1
    lhs = sum(nu[i]*pi[i][j]*F(1+i+2*j,7)
              for i in range(4) for j in range(4))
    rhs = sum(nu[j]*pi[j][i]*e[j]/e[i]*F(1+i+2*j,7)
              for i in range(4) for j in range(4))
    assert lhs == rhs
    checks += 1
    print('case',c,'A',A,'C',C,'weighted_norm2',norm2,'plain_norm2',norm0)
print('PASS',checks,'exact Fraction algebra checks')
```

Actual output:

```text
case 0 A 6/13 C 3/13 weighted_norm2 18/169 plain_norm2 9/26
case 1 A 6/13 C 3/13 weighted_norm2 18/169 plain_norm2 9/26
case 2 A 12/29 C 6/29 weighted_norm2 72/841 plain_norm2 9/29
case 3 A 6/13 C 3/13 weighted_norm2 18/169 plain_norm2 9/26
PASS 20 exact Fraction algebra checks
```

## SB8. The current global hard-source mass has an exponential lower gate

Use this round's definition `N_V=||nu_V||` and
`rho_V=N_V/(lambda a^n)`. Every retained nonzero outer leaf in the
actual R259 remainder satisfies

    N_V>M_*:=lambda a^n exp(sqrt(n)),
    rho_V>exp(sqrt(n)).                                  (SB16)

This is a tail-source condition, not merely the earlier tree condition
on sigma_V. Its shortest verified original chain is:

* [R107 integration.md:82](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/integration.md:82)
  defines M_*. Its lines 204--222 pay light leaves of the actual newly
  constructed top-k tail, `m_V<=M_*`, then explicitly retain the same
  nu thereafter. Lines 241--254 state `m_V>M_*` on the complementary
  heavy collection used by the later branch.
* [R108 parent_integration.md:60](/Users/zhengzhihao/Desktop/T/output/centered_cube_round108_20261013/parent_integration.md:60)
  reconstructs nu after its new extraction and repays the light-tail
  branch. Its [line 133](/Users/zhengzhihao/Desktop/T/output/centered_cube_round108_20261013/parent_integration.md:133)
  explicitly states that the redefined same frozen hard tail has
  `m_V>lambda a^n exp(sqrt(n))`.
* [R109 integration_main.md:51--58](/Users/zhengzhihao/Desktop/T/output/centered_cube_round109_20261013/integration_main.md:51)
  again rebuilds top-k nu, low tail rows, light leaves and soft/hard
  comparison on its new common residual. Its lines 103--109 expressly
  preserve the heavy-tail size and source-mass comparison for that
  same newly rebuilt nu.
* [R113 coupled_transport.md:68--72](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/coupled_transport.md:68)
  leaves the already constructed hard tail unchanged; lines 80--84
  preserve the hard source/history and only change the coupled soft
  extraction. R237 source_ledger.md:17--43 records the subsequent
  inheritance to the actual posterior branch used here.

Hence a putative root-price subbranch requiring this **global** rho_V
to be polynomial in n, or log rho_V to be polylogarithmic in n, is
not already supplied by the actual source qualifications. A displayed
price polynomial in log rho_V must retain that dependence; SB16 does
not turn it into a polylog(n) charge. Local or kernel-weighted source
mass may obey a different bound, but must not be identified with N_V.
For reference only, q<=lambda makes the distinct q-normalized global
ratio `N_V/(q a^n)` still larger. SB16 uses the lambda-normalized
definition throughout. No additional numerical check or original
traffic payment is claimed by this ancestry audit.
