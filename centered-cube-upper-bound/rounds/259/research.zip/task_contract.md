# R259：原半密度共同接收几何与归一化联结

基线R258 a92c41655300d7dc5c87a301e65c70f35ac1bfce已推送。一般目标未闭合；R257全soft近来源列和强soft正支、R258原signed近边界及高标签正尾已付，不重复探讨。

核心待证：剩余lowsoft/lowlabel near原正半密度交通，如何同一次估计支付score、实际s/L/R选择与原Π_y,t的e_t归一化？R224固定状态QG affinity与O(logn) clock已证，不能重新登记或免费搬到adaptive receiver。原hardz保留直到合法结算，第三J腿不能无条件删除。

精确定义沿R224 TR1–TR3与R258PB：p_y=P_s,L(x−y)，Q*=(K1+K2+J)/3；Π_y,t=e_t^-1 1Zt wt(y,v)ν(dv)，wt=∏min(1,bC(|yi−vi|/b)/(cj t))，原good p_y wg≤KQ*，high p_y e_g≥2Kq，t≤g，actualFIRST∫p_yβ≤q。由high+FIRST有∫high β/e_t≤1/(2K)，不得改成无接收域限制的来源帽。所有原leaf/uniquej/history/双Π与全部比值保留。

路线候选：在near(y,z)共同硬窗口内，非对称Cauchy一侧用R257MG2–6，另一侧保Q*ν与原归一化，期望不丢score交叠亏损；或合法对称source occupancy联结。必须先写二次槽准确式和允许帽，再长证。不能只有新余项命名。

子任务：peak只joint_geometry.md（唯一主瓶颈）；compare只source_bridge.md（最好原half-density桥、heavy与FIRST可授费用及源交换）；audit只audit.md独立先筛后读；numeric只numeric_checks.py/json和numeric_notes.md，待准确候选后有限实现。父主推导/合同/proof.tex.txt/report.md/reproduce.py与提交。多人共享不覆别件，子Agent不git/PDF。

本机数学工具辅助，沿用L03精确与普通mp分级，三阶段检查不作一般证明。若无完整新付款如实记录准确推进等级；每轮核验后单独提交推送origin/main，紧凑归档、不编译PDF。用户偏好推进全局极值几何，不重复固定尺度小支或反例清单。
