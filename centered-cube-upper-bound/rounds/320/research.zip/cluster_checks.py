#!/usr/bin/env python3
"""R320 independent exact physical tiny-cluster/shift-grid diagnostics."""
from fractions import Fraction as F
from math import comb
from collections import Counter
from pathlib import Path
import json
counts=Counter()
def ck(key,test):
 counts[key]+=1
 assert test,key

def contains(I,J):return I[0]<=J[0] and J[1]<=I[1]
def native(n):
 k=4 if n==16 else 8;s=F(1,n**4);delta=F(1,n**2);D=F(1,k);m=F(3,2**n);localres=3-k*s**n;remote=8100-F(k,2**n);eta=localres/3
 ck('native_residual_positive',0<eta<1 and remote>0)
 ck('old_deep_integer',3*k*3**k<2**n)
 ck('old_high_average',m*k**n>k)
 ck('orthant_narrower_than_fine',s/2<F(1,n))
 paths=[]
 for sign in [-1,1]:
  width=D;depth=0;orthant=(F(0),s/2) if sign==1 else (-s/2,F(0))
  while True:
   I=(F(0),width) if sign==1 else (-width,F(0))
   ck('old_path_whole_orthant',contains(I,orthant))
   ck('old_path_fine_aligned',width*n==int(width*n))
   ck('old_path_same_mass',m==F(3)*(s/2)**n/s**n)
   if width==F(1,n):break
   mid=width/2
   near=(F(0),mid) if sign==1 else (-mid,F(0))
   far=(mid,width) if sign==1 else (-width,-mid)
   ck('nonzero_child_whole_orthant',contains(near,orthant))
   ck('zero_sibling_source',far[1]<=orthant[0] or orthant[1]<=far[0])
   ck('pruning_must_recurse',m>m/2)
   width=mid;depth+=1
  paths.append(dict(sign=sign,depth=depth,terminal_width=width,terminal_mass=m))
 # Product of the one-dimensional corner paths accounts for all 2^n roots.
 ck('old_root_mass_sum',2**n*m==3)
 ck('terminal_high_average',m*n**n>k)
 recvhalf=(1-s)/2
 ck('continuous_all_radius_local_capture',recvhalf+s/2==F(1,2))
 ck('continuous_all_radius_remote_exclusion',F(7,4)-recvhalf>1)
 ck('native_winner_response',2<3<=4)
 ck('normalised_native_row',F(1,3)*localres<=1)
 for macrocenter in [0,2]:
  ck('macro_firstaxis_local',contains((F(macrocenter)-F(5,2),F(macrocenter)+F(5,2)),(-s/2,s/2)))
  ck('macro_firstaxis_remote',contains((F(macrocenter)-F(5,2),F(macrocenter)+F(5,2)),(F(7,4),F(9,4))))
 ck('macro_otheraxes_local',s/2<=F(5,2))
 ck('macro_otheraxes_remote',F(1,4)<=F(5,2))
 ck('ownership_capture_gate_failure',localres/(localres+remote)<F(1,2*k))
 ck('harmonic_native_failure',localres/(localres+remote)<F(1,k))
 ck('component_connected',2<=3)
 ck('component_heavy',localres+remote>3**k)
 ck('native_contribution_gate',localres>=F(1,6144))
 p=(1-s/delta)**n;B=(1+delta)**n;HV=eta*(1-s)**n
 ck('phase_probability_bernoulli',p>=1-F(1,n))
 ck('contained_new_mass_gate',3*k>=1)
 ck('mass_radius_inside_physical_window',1<=3*k<=2**n)
 # Rational enclosure of r_C=(3k)^(1/n), no floating roots.
 lo=F(1);hi=F(2);steps=0
 while (hi+delta)**n>3*k*B:
  mid=(lo+hi)/2
  if mid**n<=3*k:lo=mid
  else:hi=mid
  steps+=1
  assert steps<128
 ck('mass_radius_power_enclosure',lo**n<=3*k<=hi**n)
 ck('full_rowvolume_price',(hi+delta)**n<=3*k*B)
 ck('new_remote_cell_inactive',8100*2**n*delta**n<F(1,k))
 ck('new_cell_cannot_meet_both_sources',delta<F(7,4)-s/2)
 ck('positive_new_paid_lower',p*HV>0)
 ck('unchanged_absorption',1/(1-F(1,768)-F(1,128))==F(768,761))
 return dict(n=n,k=k,s=s,delta=delta,old_root_side=D,old_root_mass=m,old_paths=paths,old_root_count=2**n,local_residual=localres,remote_residual=remote,residual_factor=eta,native_traffic_V=HV,containment_probability=p,accepted_lower=p*HV,new_B=B,new_branch_cost_upper=3*k*B,mass_radius_lower=lo,mass_radius_upper=hi,mass_radius_bisection_steps=steps)
def interval_fractions(s,delta,phase):
 # Exact geometric source fractions in the new half-open grid cells.
 lo=-s/2;hi=s/2
 j0=(lo-phase)//delta;j1=(hi-phase)//delta
 pieces=[]
 for j in range(j0,j1+1):
  length=max(F(0),min(hi,phase+(j+1)*delta)-max(lo,phase+j*delta))
  if length:pieces.append(length/s)
 ck('phase_source_partition',sum(pieces)==1)
 return pieces

def phases(n):
 k=4 if n==16 else 8;s=F(1,n**4);delta=F(1,n**2);B=(1+delta)**n;eta=1-k*s**n/3;HV=eta*(1-s)**n
 records=[]
 phases=[('vertex',F(0)),('interior_cut',s/4),('containment_lower_boundary',s/2),('middle',delta/2),('containment_upper_boundary',delta-s/2),('upper_cut',delta-s/4)]
 for label,phase in phases:
  fractions=interval_fractions(s,delta,phase);mass=F(0);active=F(0);payfrac=F(0);patterns=[]
  if len(fractions)==1:
   ck('whole_cluster_mass',fractions[0]==1)
   categories=[(1,F(3))]
  else:
   ck('at_most_two_cells_per_axis',len(fractions)==2)
   categories=[(comb(n,j),3*fractions[0]**j*fractions[1]**(n-j)) for j in range(n+1)]
  for multiplicity,m in categories:
   mass+=multiplicity*m
   gate=m*k>=1
   if gate:
    active+=multiplicity*m;payfrac+=multiplicity*m/3
    ck('actual_R_one_rowvolume',(1+delta)**n<=k*m*B)
   patterns.append(dict(multiplicity=multiplicity,full_mass=m,active=gate))
  ck('phase_full_source_mass_once',mass==3)
  ck('phase_active_budget',0<=active<=3)
  ck('phase_actual_paid_bound',HV*payfrac<=k*B*active)
  # Analytic exact probability is the product of the length of good phases.
  contained=(s/2<=phase<=delta-s/2)
  ck('phase_containment_geometry',contained==(len(fractions)==1))
  if contained:ck('contained_all_original_traffic_paid',payfrac==1)
  records.append(dict(label=label,phase=phase,one_axis_source_fractions=fractions,whole_cluster_contained=contained,active_local_mass=active,actual_paid_fraction=payfrac,actual_paid_traffic=HV*payfrac,source_once_price=k*B*active,mass_categories=patterns))
 ck('one_axis_good_phase_length',(delta-s/2)-s/2==delta-s)
 return dict(n=n,phase_records=records)
def serial(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [serial(v) for v in x]
 return x

def main():
 stages=[];models=[];phase_models=[]
 before=sum(counts.values());models.append(native(16));stages.append(dict(stage='initial_native',checks=sum(counts.values())-before,n=[16]))
 before=sum(counts.values());phase_models=[phases(n) for n in [16,64]];stages.append(dict(stage='phase_boundary',checks=sum(counts.values())-before,n=[16,64]))
 before=sum(counts.values());models.append(native(64));stages.append(dict(stage='expanded_native',checks=sum(counts.values())-before,n=[64]))
 result=dict(status='PASS',arithmetic='Fraction/integer',total_checks=sum(counts.values()),check_counts=dict(counts),stages=stages,models=models,deterministic_shifts=phase_models,scope='Actual positive-L1 source and native positive-volume receiver subset. Algebraic tensor compression and coordinate bounds prove the stated geometry. Finite phase examples do not replace the analytical uniform-phase probability formula or certify all-input residual/root bounds.',source_definition='Uniform local Q_s(0) mass3 plus remote Q_(1/2)(2e1) mass8100. Old fine1/n and coarse1/sqrt(n) grids have phase0. New delta1/n² grid has independent uniform phase.',analytic_bridges=['Each corner orthant stays in the unique corner child under every allowed fine-aligned refinement; all other child masses zero; symmetric coordinate argument represents2^n old roots.','The local receiver openboxV=Q_(1-s) captures all local and no remote source for everyR[1,2], hence truewinnerR1,hardresponse3,normalisedgate1/3.','Good one-axis grid phases occupy an interval of lengthdelta-s, so independent phases give probability(1-s/delta)^n. Boundary seeds are null for uniform probability.','e<3 turns the integer old-deep/heavy inequalities into the corresponding exponential conditions.','Remote new-cell mass<1/sqrt(n), and no new cell meets both source components. Therefore every fixed-seed activeFULLsourcebudget is<=3.'])
 Path(__file__).with_suffix('.json').write_text(json.dumps(serial(result),sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['status','total_checks','check_counts','stages']},sort_keys=True))
if __name__=='__main__':main()
