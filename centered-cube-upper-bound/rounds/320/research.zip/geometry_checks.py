from fractions import Fraction as F
from random import Random
rng=Random(320)
counts={"markov":0,"energy":0,"comparison":0,"density":0,"prefix_atoms":0}
def ck(b,k):
    assert b,k
    counts[k]+=1
for case in range(48):
    nr,nx=4,4
    beta=[F(1,4)]*nr
    mass=[F(rng.randint(1,5),5) for _ in range(nx)]
    U=[[F(rng.randint(0,8),8) for _ in range(nx)] for _ in range(nr)]
    c=[F(int(i==case%nx)) for i in range(nx)]
    H=(F(1,10),F(1,4),F(1,2))[case%3]; d=H/3
    J=[sum(mass[i]*U[y][i] for i in range(nx)) for y in range(nr)]
    A=[sum(mass[i]*U[y][i]*c[i] for i in range(nx)) for y in range(nr)]
    v=[(min(d,A[y])-d*A[y]/H)/(A[y]*(1-A[y]/J[y]))
       if J[y]>=H and 0<A[y]<H else F(0) for y in range(nr)]
    rho=[sum(beta[y]*v[y]*U[y][i] for y in range(nr)) for i in range(nx)]
    active=[i for i in range(nx) if rho[i]>0]
    if not active:
        continue
    mu=[mass[i]*rho[i] for i in range(nx)]
    K=[[sum(beta[y]*v[y]*U[y][i]*U[y][j]/J[y]
             for y in range(nr) if v[y]>0)*mass[j]/rho[i]
          if rho[i]>0 else F(0) for j in range(nx)] for i in range(nx)]
    K2=[[sum(K[i][k]*K[k][j] for k in range(nx))
          for j in range(nx)] for i in range(nx)]
    M=max(max(row) for row in U)
    for i in active:
        ck(sum(K[i])==1 and sum(K2[i])==1,"markov")
        for j in range(nx):
            ck(mu[i]*K[i][j]==mu[j]*K[j][i],"markov")
            ck(K[i][j]/mass[j]<=M/H and K2[i][j]/mass[j]<=M/H,"density")
    C=sum(beta[y]*v[y]*A[y] for y in range(nr))
    E=sum(beta[y]*v[y]*A[y]*A[y]/J[y] for y in range(nr) if v[y])
    kc=[sum(K[i][j]*c[j] for j in range(nx)) for i in range(nx)]
    P=sum(mu[i]*kc[i]*kc[i] for i in range(nx))
    ck(E==sum(mu[i]*c[i]*kc[i] for i in range(nx)),"energy")
    Dir=sum(mu[i]*K2[i][j]*(c[i]-c[j])**2
            for i in range(nx) for j in range(nx))/2
    ck(C-P==Dir and 0<=P<=E<=C,"energy")
    # An arbitrary positive pair restriction diagnoses N<=C, not actual collar geometry.
    N=sum(beta[y]*v[y]/J[y]*sum(mass[i]*mass[j]*U[y][i]*U[y][j]*c[i]
              for i in range(nx) for j in range(nx) if abs(i-j)>1)
          for y in range(nr) if v[y])
    D=C-N
    for L in (F(3,2),F(2),F(4)):
        Cl=sum(beta[y]*v[y]*A[y] for y in range(nr) if J[y]>=L*H)
        Cs=C-Cl
        for Pg in (F(0),C*C/sum(mu),P):
            ck((1-1/L)*Cl-D<=N-Pg<=Cl+Cs,"comparison")
# Inclusive radius atoms: all equal-radius masses form one indivisible block.
for case in range(200):
    atoms=[F(rng.randint(0,20),10) for _ in range(6)]
    B=F(rng.randint(1,70),10)
    total=F(0); paid=F(0); paid_inclusive=F(0)
    for atom in atoms:
        total+=atom
        if total<B: paid+=atom
        if total<=B: paid_inclusive+=atom
    ck(paid<=B and paid_inclusive<=B,"prefix_atoms")
print(counts)
print("PASS",sum(counts.values()),"exact Fraction checks")
