# R320 — what shared receiver projection can pay on the original low-capture rows

## 1. Outcome and precise scope

This note proves a quantitative two-sided comparison for the ORIGINAL R319 compensated certificate. It changes the next proof target: on rows with J much larger than H and A<H, even the full receiver projection can remove only a small fraction of their linear capture mass. Paying that real high-J capture mass, up to already paid source terms, is necessary and sufficient for paying Pi_local. This is a rigorous limitation and interface simplification, **not a new root-source payment** and not a counterexample campaign.

Retain every R319 field and hypothesis:

    U_y(x)=1_E(x)alpha(x,y)P_(s(x),L(x))(x-y)/q(x),
    J_y(r)=integral_{R(x)<=r}U_y(x)dx,
    A_yz(r)=integral_{R(x)<=r}U_y(x)c_x(z)dx,
    c_x(z)=1_{Q_(R(x))(x)}(z),
    integral U_y(x)beta(dy)<=1,
    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)dr.

Here q_-=3lambda/4<=q<=lambda, a<=L,R<=b<=2a, and beta,nu are finite positive L1 sources. Original alpha includes the same low-pe, m, full e_g, aspect and history qualifications. Same-receiver hard caps, and matched nu<=f plus the same-receiver all-radius cap, have exactly their R319 meanings. No new density cap, winner identity, component FIRST, or higher-softness FIRST is assumed.

Fix H>=d>0. On Y_z(r)={J>=H,0<A<H}, use the unchanged

    g(A)=min(d,A)-(d/H)A,
    v_y(z,r)=g(A)/[A(1-A/J)], p_y=A/J;

set v=p=0 elsewhere. Thus 0<=v<=1. In particular J is the FULL original prefix mass, not the mass after a row, source or endpoint restriction. All fields below are measurable positive integrals of this data. Define

    C(z,r)=integral beta(dy)v_y A_yz(r),
    E(z,r)=integral beta(dy)v_y A_yz(r)^2/J_y(r).

The R319 auxiliary split uses eta^n=1/A_n, A_n=1+n log(b/a), and

    h_0=(a/2)min(1/n,(epsilon q_- H/A_n)^(1/n)),
    t_h=max(a,b-2h_0), LOW={r<t_h}.

Assume a<b here; the a=b fixed-scale case remains separately paid. Let N_cf be the R319 far-collar FIRST MOMENT (without the second endpoint miss indicator). It uses R(u)>a/eta, z in Q_R(u)(u) minus Q_(eta R(u))(u), and delta(u,w)>h_0, with the original v U_y(u)U_y(w)/J on the full prefix. Let

    D_omit(z,r)=C(z,r)-N_cf(z,r)>=0.

It is exactly the sum of the bottom, deep and near first moments on LOW. R319 proves

    integral_LOW D_omit <= K_omit,
    K_omit=(1+log A_n+epsilon)W_nu
                    +(16/3)Csoft_n W_beta,         (1)
    Csoft_n<=1+(pi/2)sqrt(n).

The top-layer true loss is at most 2W_nu. Csoft_n is the common-softness coefficient-sum upper bound, not integral sup_s P_s.

For a common actual receiver partition define the R317/R319 projection P_grid. The only facts about it needed for the main comparison are

    0<=P_grid(z,r)<=E(z,r).

In full detail, rho_v(x)=integral beta v U_y(x)1_{R(x)<=r}, b_v(x)=integral beta v U_y(x)p_y1_{R(x)<=r}, and P_grid=sum_i (integral_(Omega_i)b_v)^2/(integral_(Omega_i)rho_v), with zero denominators contributing zero. The compensated certificate is

    Pi_grid=integral_LOW [N_cf-P_grid] nu(dz)ell_n(dr). (2)

All terms in (2) are finite, bounded separately by A_n W_nu. Pi_grid is an auxiliary WHOLE-tent certificate, not original positive collar-far traffic.

## 2. Main comparison, with all source fees

For a fixed outer number ellambda>1 (not a receiver selector), define

    C_long=integral_LOW nu(dz)ell_n(dr)beta(dy)
                       v_y A_yz(r)1_{J_y(r)>=ellambda H},
    C_short=integral_LOW nu(dz)ell_n(dr)beta(dy)
                       v_y A_yz(r)1_{J_y(r)<ellambda H}. (3)

Rows off Y contribute zero. Then

    (1-1/ellambda)C_long-K_omit
          <=Pi_grid<=C_long+4lambda ellambda H W_beta. (4)

The lower bound holds for EVERY valid common-receiver partition, including its complete refinement limit. Thus it is not a limitation caused by a coarse grid.

Proof of the lower bound. On a long active row, A<H and J>=ellambda H imply p<1/ellambda. Therefore

    E_long<=C_long/ellambda, E_short<=C_short.

At every layer N_cf=C-D_omit. Integrate P_grid<=E to obtain

    Pi_grid>=C_long+C_short-integral_LOW D_omit
                       -C_long/ellambda-C_short.

Use (1). This retains the same original v and full J and uses no artificial density or posterior homogeneity.

Proof of the short-row receipt. Since v<=1, Tonelli and the inclusive ell tail give

    C_short
    <=integral beta(dy) integral_E dx U_y(x)
          1_{J_y(R(x))<ellambda H} R(x)^(-n)nu(Q_(R(x))(x))
    <=4lambda integral beta(dy) integral_E U_y(x)
                              1_{J_y(R(x))<ellambda H}dx
    <=4lambda ellambda H W_beta.                  (5)

Indeed if R(x)<=r and J_y(r)<ellambda H, then J_y(R(x))<ellambda H. For the finite pushforward measure U_y(x)dx under R(x), the integral over {J_y(R)<ellambda H} is at most ellambda H. An atom that first crosses the threshold is excluded as a WHOLE by the inclusive J; there is no assumed nonatomic radius law or random tie convention. Equality endpoints can alternatively be included with the same upper bound.

Finally Pi_grid<=integral_LOW N_cf<=C_long+C_short gives the upper bound in (4). Formula (5) is the existing prefix-mass payment, not a newly claimed saving. The new conclusion is the two-sided comparison with the strongest available projection.

For ellambda=2, (4) is particularly explicit:

    C_long/2-K_omit<=Pi_grid<=C_long+8lambda H W_beta. (6)

Thus any root estimate for Pi_grid implies

    C_long<=2Pi_grid+2K_omit,                       (7)

and any root estimate for C_long, combined with (6), supplies a root estimate for Pi_grid whenever lambda H has the required root-scale price. The right side of (7) is automatically nonnegative by the proved inequality; no unsigned replacement is silently made.

## 3. Original entry and the H_0 fees

The unchanged original entry and R319 localization are

    T_target<=8lambda H W_beta+2(d/H)A_n W_nu+2R_tent,
    R_tent<=2W_nu+K_omit+Pi_grid.                  (8)

At H_0=sqrt(d A_n/(4lambda))>=d, write S=sqrt(lambda d A_n), so lambda H_0=S/2. Combining (6) with (8) gives the valid but NOT closed continuation

    T_target<=12 S W_beta+4 S W_nu
                  +(32/3)Csoft_n W_beta
                  +(6+2log A_n+2epsilon)W_nu
                  +2 C_long.                     (9)

The additional 8 S W_beta relative to R319 is the explicit short-row payment 2*(8lambda H_0 W_beta). No source was copied once per row, receiver cell, layer, or hard source. Conversely, for this same H_0, a proposed bound Pi_grid<=epsilon'X+R_source would require

    C_long<=2epsilon'X+2R_source+2K_omit.            (10)

Consequently a projection-only argument cannot bypass an actual high-J shared-source capture estimate. It is legitimate to retain Pi_grid rather than use the weaker upper continuation (9); (9) is a cost comparison, not a recommended replacement when its short-row price is unnecessary.

The original lambda d=(4/3)kappa_0 psi_infinity/v_0, kappa_0=2K/(ell M), psi_infinity=3-2/(3gamma^n), gamma=1+1/n, remain in S in the matched R302 normalization. These parameters must not be confused with the auxiliary ellambda in (3). Every original positive outer factor and clock integral multiplies ALL the displayed terms. No unrelated time/scale branch has been discharged. If H_0<d, the existing coarse T_target<=2A_n W_nu<=4 S W_nu applies instead. Zero source mass and H=d are immediate; the latter has v=0 and zero tent.

## 4. Actual common-source Markov geometry and its exact missing estimate

There is a useful exact representation of the complete receiver projection. For fixed z,r put mu(dx)=rho_v(x)dx on the actual prefix. On rho_v(x)>0 define

    K(x,dw)=[integral beta(dy) v_y U_y(x)U_y(w)/J_y(r)]
                           1_{R(w)<=r}dw/rho_v(x), (11)

with U_y(x) also restricted to the prefix. Its values on mu-null states are irrelevant. The kernel K is Markov on the support of mu and reversible because mu(dx)K(x,dw) is symmetric. It is a positive semidefinite contraction: for any real L2 function f,

    <f,Kf>_mu=integral beta(dy) v_y/J_y
                     [integral_prefix U_y(x)f(x)dx]^2>=0,
    <f,Kf>_mu<=||f||_mu^2.

This uses the actual shared source beta, not a virtual center or new FIRST. With c(x)=c_x(z),

    Kc=b_v/rho_v,
    C=<c,c>_mu,
    E=<c,Kc>_mu,
    P_infinity=||Kc||_mu^2=<c,K^2c>_mu.            (12)

Hence, exactly,

    C-P_infinity
       =(1/2)integral mu(dx)K^2(x,dw)[c(x)-c(w)]^2. (13)

For a finite grid, define Delta_grid=P_infinity-P_grid>=0. Then

    Pi_grid=integral_LOW [(1/2)integral mu(dx)K^2(x,dw)
                                  (c(x)-c(w))^2-D_omit]
                         +integral_LOW Delta_grid. (14)

A fixed sequence of dyadic receiver refinements makes Delta_grid tend to zero in the integrated expression, by conditional L2 approximation and domination by E<=C, whose total integral is at most A_n W_nu. No free selector optimization is required.

What actual kernel geometry supplies immediately is only

    dK(x,w)/dw <=1/(q_- a^n H),
    dK^2(x,w)/dw<=1/(q_- a^n H).                  (15)

Indeed U_y(w)<=1/(q_-a^n) and every nonzero v row has J>=H; K is a probability mixture of U_y(w)dw/J_y. The same upper bound survives one more Markov step. Thus a short physical receiver jump of sup-norm at most h has conditional mass at most min(1,(2h/a)^n/(q_-H)), recovering the type of near receipt already paid in R319. No bound on source density is used.

Equations (13)-(15) do NOT control the remaining middle-distance two-step capture crossing. A sufficient next geometric assertion would bound the integral in (14), after subtracting D_omit, by epsilon'X plus the required source-root price. In view of (6)-(10), such an assertion must also pay the genuine linear capture C_long. Reversibility, positive semidefiniteness, finer receiver partitions and the point-height bound (15) alone do not supply this payment. We have not derived an additional estimate from the full-soft translation geometry with the arbitrary original alpha retained.

This is the precise stopping point. The original middle-distance shared-source mass, rather than a fresh scalar optimization of the projection or an unjustified local subtraction, must be addressed next. The parent's separate center-distance payments can be applied to disjoint actual pieces with their own proved ledger; this note neither duplicates them nor assumes their missing complement is paid.

## 5. Executed finite algebra and radius-atom checks

The following self-contained standard-library Python block checks the actual algebra of the common-source construction, the two-sided comparison and inclusive radius-atom accounting. The finite matrices are positive receiver measures satisfying a shared row upper cap; they are NOT asserted to realize the native full-soft/history/low-pe contract. They diagnose the universal algebra only. The analytic proof above provides the original-input statement.

```python
from fractions import Fraction as F
from random import Random
rng=Random(320)
counts={"markov":0,"energy":0,"comparison":0,"density":0,"prefix_atoms":0}
def ck(b,k):
    assert b,k
    counts[k]+=1
for case in range(48):
    nr,nx=4,4
    beta=[F(1,4)]*nr
    mass=[F(rng.randint(1,5),5) for _ in range(nx)]
    U=[[F(rng.randint(0,8),8) for _ in range(nx)] for _ in range(nr)]
    c=[F(int(i==case%nx)) for i in range(nx)]
    H=(F(1,10),F(1,4),F(1,2))[case%3]; d=H/3
    J=[sum(mass[i]*U[y][i] for i in range(nx)) for y in range(nr)]
    A=[sum(mass[i]*U[y][i]*c[i] for i in range(nx)) for y in range(nr)]
    v=[(min(d,A[y])-d*A[y]/H)/(A[y]*(1-A[y]/J[y]))
       if J[y]>=H and 0<A[y]<H else F(0) for y in range(nr)]
    rho=[sum(beta[y]*v[y]*U[y][i] for y in range(nr)) for i in range(nx)]
    active=[i for i in range(nx) if rho[i]>0]
    if not active:
        continue
    mu=[mass[i]*rho[i] for i in range(nx)]
    K=[[sum(beta[y]*v[y]*U[y][i]*U[y][j]/J[y]
             for y in range(nr) if v[y]>0)*mass[j]/rho[i]
          if rho[i]>0 else F(0) for j in range(nx)] for i in range(nx)]
    K2=[[sum(K[i][k]*K[k][j] for k in range(nx))
          for j in range(nx)] for i in range(nx)]
    M=max(max(row) for row in U)
    for i in active:
        ck(sum(K[i])==1 and sum(K2[i])==1,"markov")
        for j in range(nx):
            ck(mu[i]*K[i][j]==mu[j]*K[j][i],"markov")
            ck(K[i][j]/mass[j]<=M/H and K2[i][j]/mass[j]<=M/H,"density")
    C=sum(beta[y]*v[y]*A[y] for y in range(nr))
    E=sum(beta[y]*v[y]*A[y]*A[y]/J[y] for y in range(nr) if v[y])
    kc=[sum(K[i][j]*c[j] for j in range(nx)) for i in range(nx)]
    P=sum(mu[i]*kc[i]*kc[i] for i in range(nx))
    ck(E==sum(mu[i]*c[i]*kc[i] for i in range(nx)),"energy")
    Dir=sum(mu[i]*K2[i][j]*(c[i]-c[j])**2
            for i in range(nx) for j in range(nx))/2
    ck(C-P==Dir and 0<=P<=E<=C,"energy")
    # An arbitrary positive pair restriction diagnoses N<=C, not actual collar geometry.
    N=sum(beta[y]*v[y]/J[y]*sum(mass[i]*mass[j]*U[y][i]*U[y][j]*c[i]
              for i in range(nx) for j in range(nx) if abs(i-j)>1)
          for y in range(nr) if v[y])
    D=C-N
    for L in (F(3,2),F(2),F(4)):
        Cl=sum(beta[y]*v[y]*A[y] for y in range(nr) if J[y]>=L*H)
        Cs=C-Cl
        for Pg in (F(0),C*C/sum(mu),P):
            ck((1-1/L)*Cl-D<=N-Pg<=Cl+Cs,"comparison")
# Inclusive radius atoms: all equal-radius masses form one indivisible block.
for case in range(200):
    atoms=[F(rng.randint(0,20),10) for _ in range(6)]
    B=F(rng.randint(1,70),10)
    total=F(0); paid=F(0); paid_inclusive=F(0)
    for atom in atoms:
        total+=atom
        if total<B: paid+=atom
        if total<=B: paid_inclusive+=atom
    ck(paid<=B and paid_inclusive<=B,"prefix_atoms")
print(counts)
print("PASS",sum(counts.values()),"exact Fraction checks")
```

Actual fresh-process result: PASS, 1,574 exact Fraction checks: 580 Markov/reversibility checks, 60 energy checks, 270 two-sided comparisons, 464 density checks, and 200 inclusive-prefix atom checks. Thirty of the 48 deterministic matrix fixtures had nonzero active rows; empty active fixtures were skipped explicitly. These checks do not prove a root budget and are not a numerical counterexample search.

Reproduction without creating another file:

```sh
python3 - <<'PYCODE'
from pathlib import Path
s=Path("/tmp/r320_geometry.md").read_text()
code=s.split("```python\n",1)[1].split("\n```",1)[0]
exec(compile(code,"r320_embedded_checks","exec"), {"__name__":"__main__"})
PYCODE
```
