# R320 — a source-once concentration receipt across the old grid boundaries

**Proved:** a shifted fine source grid gives an explicit root-order geometric receipt for a new positive part of R319's COMBINED unpaid high-average and tag-rejected traffic. The exact mass gate is `m_C>=lambda R^n/sqrt(n)`. The proof uses only the actual total receiver-row bound, capture geometry, and a source-frozen partition. Its full-f source masses sum once. A frozen shift probability incurs no number-of-shifts fee.

This higher mass gate would be empty on an OLD deep packet if the same packet were reused. The new grid crosses the old fine-cell boundaries instead. An actual native construction below puts a compact cluster across2^n old cells; every original packet stays deep/high-average, while the new shifted grid pays at least15/16 of its positive native traffic for n16 (and63/64 for n64). Thus the estimate expands the paid range rather than renaming an old branch. The remaining traffic is stated explicitly. Only `/tmp/r320_entry.md` was written; no full weak-bound or all-scales claim.

## 1. Keep the exact combined unpaid measure

Use only the complete R316 entrance and the R318/R319 fields recorded in `/tmp/r319_entry.md`. The original input f, complete original hard band E, maximizing selector R(x) in[a,b], original dx, frozen residual source

`nu=(f-sqrt(n)lambda)_+ dz`, `X=lambda|E|`,

and every native mask remain unchanged. Let T denote the exact R318 aggregate-packet-deep measure. R319 split it exactly into its low-average tag-accepted part, high-average part and low-average tag-rejected part.

Here the target is the COMBINED actual unpaid measure

`U=T_hi+T_lo,rej`,

`dU=A_U(x,z)h_R(x-z)dx nu(dz)`. (1)

In particular `0<=U<=T`, so the normalization of the COMPLETE original hard traffic proves the actual total receiver-row bound

`integral A_U(x,z)h_R(x-z)nu(dz)<=lambda 1_E(x)`. (2)

Indeed every original gate is a contraction of `1_E lambda/M(x)` and nu<=f, while `h_R*f=M`. The proof below only needs(2); it does not replace a low coarse average by an original density cap. It does not assume a lower bound for the old tag-overlap theta.

The old aggregate-deep gate stays inside A_U throughout. A newly introduced source grid does NOT redefine the original deep packets, classifications, source fields or selector. If R319 used an auxiliary probability mixture, retain that seed or its exact integrated positive measure in(1).

## 2. General row-volume receipt for frozen source clusters

Let `{C}` be any source-frozen measurable partition. Each cell C is contained, up to source-null sets, in a frozen axis box with widths `d_(C,1),...,d_(C,n)`. Define FULL original source mass, mass radius, and geometric factor

`m_C=integral_C f`, `r_C=(m_C sqrt(n)/lambda)^(1/n)`,

`B_C=product_(j=1)^n(1+d_(C,j)/a)`. (3)

Zero-mass cells carry zero source traffic. On the unchanged actual source z in C define the new paid branch

`dU_paid,C=1_C(z)1_{R(x)<=r_C}dU`,

and keep its exact positive complement. Equivalently the paid predicate is

`m_C>=lambda R(x)^n/sqrt(n)`, INCLUDING equality. (4)

Any active cell has r_C>=a. Put `t_C=min(b,r_C)>=a`. For a captured source z in C on this branch, R<=t_C, so its receiver lies in the Minkowski sum of C's containing axis box and Q_(t_C). This sum has volume

`product_j(t_C+d_(C,j))`

` <=r_C^n product_j(1+d_(C,j)/a)`

` =(m_C sqrt(n)/lambda)B_C`. (5)

For EACH cell, its actual subtraffic row is at most the TOTAL row(2), and it vanishes outside this receiver set. Thus

`||U_paid,C||<=lambda product_j(t_C+d_(C,j))<=sqrt(n)B_C m_C`. (6)

The receiver sets of different cells can overlap. No receiver-union disjointness or bounded receiver multiplicity was used: sum(6), then use the DISJOINT source partition. Only cells in the frozen preactive family

`A={C:m_C>=lambda a^n/sqrt(n)}` (7)

can contribute. Consequently

`||U_paid||<=sqrt(n)sum_(C in A)B_C m_C`. (8)

This is a budget on complete f mass. It is added to earlier source fees even when the same f has already funded other legitimate branches. The sum is source-once within this receipt, not a declaration that its source is disjoint from earlier receipts. The number of preactive cells is finite for fixed positive lambda,a and finite||f||1, but no such count enters(8).

## 3. A concrete frozen random grid, with every shift cost included

Set the NEW grid side

`delta=a/n^2`.

Choose a seed sigma uniformly in `[0,delta)^n`, BEFORE receivers are selected, and let `C_(sigma,j)=sigma+delta j+[0,delta)^n`, j inZ^n. Its full masses `m_(sigma,j)=integral_(C_(sigma,j))f` and mass radii are frozen from f and sigma, not from x. For every fixed seed the cells partition space, and

`B_delta=(1+delta/a)^n=(1+1/n^2)^n<=exp(1/n)`. (9)

Define the exact source concentration functional

`W_act(sigma)=sum_{j:m_(sigma,j)>=lambda a^n/sqrt(n)}m_(sigma,j)<=W`.

Lift the SAME original measure U by the probability seed sigma and accept it if its original source z lies in a cell satisfying(4). Integrating the seed gives an actual weight p(x,z) in[0,1]:

`p(x,z)=Pr_sigma{m_(C_sigma(z))>=lambda R(x)^n/sqrt(n)}`,

`dU_new=p(x,z)dU`, `dU_left=[1-p(x,z)]dU`. (10)

This is an exact nonnegative decomposition U=U_new+U_left. The original positive measure and every original deep mask are preserved. The source kernel has original z marginal nu; the new seed is independent of receivers, while its cell label may depend on z and the seed.

Apply(8) at each frozen seed and integrate its normalized probability:

`||U_new||<=sqrt(n)B_delta E_sigma W_act(sigma)`

`           <=exp(1/n)sqrt(n)W`. (11)

The first expression is the actual sharper budget. There is no count of shifts, grid cells, or dimensions beyond the displayed factor. Overlap between distinct seeds is settled by probability averaging of complete source partitions, rather than by summing cover copies. A probability mixture of different grid sizes would retain its exact weighted version of(8); unnormalized independent scale copies would incur the sum of their costs. No such extra scale family is needed here.

This is a small-width row-volume estimate. It is NOT a claim that old packets of width a/sqrt(n) have a harmless positive inflation. The present total width sum is `n delta/a=1/n`, making(9) bounded. No hard-kernel domination by a positively enlarged cube and no original-f L2 assumption is used.

## 4. Why this is new relative to the old deep threshold

For an OLD R318 packet P, the unchanged gate is

`m_P<lambda R^n exp(-sqrt(n))/sqrt(n)`.

It implies `m_P<lambda R^n/sqrt(n)`. Therefore(4) would pay NONE of that old packet's current deep traffic if C=P. This is precisely why merely applying the high mass gate to the old packets would not be progress.

A new shifted C can instead collect source pieces from many old cells that meet at one old grid vertex, while its physical width is much smaller than the old fine width. Complete f masses, not one piece's mass, are used in(3). The old deep gate remains present independently for each original source. The next diagnostic verifies this intersection on actual native traffic, including high-average classification and all native gates.

## 5. Actual native high-average/deep traffic newly paid

Take n=k^2 with k=4 or8 (n16 or64), a=lambda=1, b=2. Use the OLD original fine grid of side1/n and OLD coarse root grid side1/k, both with a vertex at0. Since k is even these phases also subdivide the integer-centered side1 ownership grid. Set

`s=1/n^4`, `delta=1/n^2`.

Put a uniform local cube Q_s(0) of FULL mass3, density `3/s^n`, straddling that old grid vertex. In the ownership cell A2 centered at2e_1 put the external cube Q_(1/2)(2e_1) of full mass8100, density `8100*2^n`. These are the only two f-positive ownership cells. The local source lies in A0 centered at0. The exact residual masses are

`v_local=3-k s^n`, `v_ext=8100-k 2^(-n)`. (12)

Each of the2^n old coarse roots touching0 receives one local orthant, full mass

`m_old=3/2^n`.

The source orthant has coordinate width s/2<1/n and touches the root's corner. At EVERY allowed R318 refinement along original fine-cell boundaries it is entirely in one child, down to the fine grid. Thus any terminal packet on that source path has the same mass m_old and volume at most the old coarse-root volume k^(-n). In particular its average is at least

`m_old k^n=3(k/2)^n>k`. (13)

The exact R318 pruning rule follows the full-mass child until the finest cell (for n16, lengths1/4 to1/8 to1/16), but the high-average conclusion does not rely on asserting a particular stopping depth. Every possible allowed terminal has the stated mass and the average lower bound. This verifies the old HIGH-average classification, rather than assuming it from point concentration.

It is also old aggregate-deep at R=1:

`3/2^n < exp(-k)/k`. (14)

For n16/64 the stronger exact sufficient inequality `3k*3^k<2^n`, together with e<3, proves(14). This is stronger than the old fine-cell-deep bound with its extra e^2. Hence the local traffic is genuinely in the CURRENT unpaid high-average part of R319, not in a R318-paid branch.

Now take the receiver box `V=Q_(1-s)(0)`. It captures the entire local cube at EVERY r in[1,2]. The external cube is excluded at EVERY such radius: its nearest source coordinate distance is at least `5/4+s/2>1>=r/2`. Therefore

`h_r*f(x)=3/r^n`, `M(x)=3`, `R*=1`, `G_N=1/3` on V. (15)

Choose K0 to contain both entire source cells, giving zero source tail. The two cells are connected in the old graph (index distance2). Both side5 ownership macro-packages contain all source. Their captured residual is v_local, while full macro residual is v_local+v_ext; `(v_local+v_ext)/(2k)>v_local`, so each contributing macro capture gate is zero. Thus Theta=0 and G1 remains1/3. The harmonic sum is `v_local/(v_local+v_ext)<1/k`; the captured residual exceeds beta104; and the unique fixed component has `v_local+v_ext>3^k>exp(k)`. This verifies the original native masks. The actual local native mass over V, all high-average and aggregate-deep, is

`H_V=(v_local/3)(1-s)^n>0`. (16)

For a uniform shift of the NEW delta-grid, the local cube Q_s(0) lies wholly in ONE new cell with probability

`q=(1-s/delta)^n=(1-1/n^2)^n>=1-1/n`. (17)

The formula follows coordinatewise: a one-dimensional shifted grid cuts a fixed interval of length s with probability s/delta; phases are independent across coordinates. Boundary equalities are null in the shift seed. If the cluster is contained, that cell has full mass at least3, whereas the new mass gate at R=1 is only1/k. Thus EVERY local actual source pair on V is accepted on those shifts.

Consequently the new receipt pays actual traffic at least

`||U_new|| >= q H_V >=(1-1/n)H_V`. (18)

This is at least15/16 for n16 and63/64 for n64 of the positive actual high-average local traffic. It does not assume any lower bound for the old low-average tag theta.

The source budget is genuinely local here. Each new cell's external full mass is at most `8100*2^n delta^n<1/k`; the new cell side is too small to meet both source cubes. Thus external cells are never preactive, and `W_act(sigma)<=3` at every seed. The cost of the branch in this diagnostic is at most `3k(1+1/n^2)^n`; it does not charge the external mass8100. This is a true source-once budget on the concentrated local mass, despite its splitting across2^n old packets.

## 6. Complete ledger after the new geometric receipt

Retain the already-proved R319 epsilon=1/128 receipt, its source mass W_lo and exact combined unpaid U. Write

`G320=sqrt(n)B_delta E_sigma W_act(sigma)`.

It has no output-absorption loss. The actual complete-band inequality becomes

`X <=(768/761){P104(f,lambda)+S318+8C2^2 sqrt(n)W_lo`

`                         +G320+||U_left||}`. (19)

All previous source prices are added, even if they charge some of the same original source. The actual raw output loss remains `1/768+1/128=7/768`, so the coefficient768/761 is unchanged by this step. With a different R319 epsilon the unchanged entrance coefficient would be `768/(767-768epsilon)`.

The exact remaining positive measure is

`dU_left=Pr_sigma{m_(C_sigma(z))<lambda R(x)^n/sqrt(n)}dU`. (20)

Its old native and aggregate-deep masks, high-average and low-rejection weights, source nu and original dx all remain. Its root-order price is NOT proved. There is no universal accepted-fraction assertion for arbitrary inputs: if every small shifted cell is below the new threshold, this receipt contributes no mass. The concrete improvement is the uniform geometric bound(11), plus the certified positive scope expansion(18) on actual old-deep/high-average traffic. A diffuse high-average/rejected configuration still needs additional geometry; it is not erased by(20).

## 7. Executed arithmetic and independent checks

Local Python/Fraction execution at n16 and n64 checked all old-deep/high-average, native macro/heavy, external inactivity and new-budget inequalities stated above. At n16 it checked `s=1/65536`, `delta=1/256`, old packet mass3/65536, its exact old-deep sufficient inequality, the high-average lower bound, native macro and heavy inequalities, external-cell inactivity, and the exact shift probability

`q=319626579315078487616775634918212890625 / 340282366920938463463374607431768211456`.

This is approximately0.9392981 and is rigorously at least15/16 by Bernoulli's inequality. The row-volume factor `(1+1/256)^16` is approximately1.06436486; its exact displayed expression is used in the receipt. The diagnostic lower accepted mass qH_V is approximately0.93906880, strictly positive. At n64 the executed values were q approximately0.98449456, B_delta approximately1.01574577, and qH_V approximately0.98449080; the exact rational checks all passed. These numerical values illustrate scale; the rational inequalities and geometric argument above provide the proof.

The exact n16/64 parameters and all native gates were sent to `/root/r286_capture_numeric` for independent certificates. No unreturned numerical result is assumed here. `/root/r285_final_audit` independently screened the source-disjoint row-volume theorem, normalized-shift settlement and containment probability, reporting PASS; it requested the original terminal-packet trajectory be checked explicitly, which is done in(13). Final file audit is separate from that screen. No historical FULL or complete weak-bound conclusion is inferred.
