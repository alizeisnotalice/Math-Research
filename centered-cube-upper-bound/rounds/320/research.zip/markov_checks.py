#!/usr/bin/env python3
"""R320 bounded exact common-source Markov structure diagnostics."""
from fractions import Fraction as F
from collections import Counter
from pathlib import Path
import json
counts=Counter()
def ck(key,test):
 counts[key]+=1
 assert test,key

def fixtures():
 return [
 ('positive',[[1,F(1,2),0,1],[0,1,2,F(1,2)],[1,0,1,1]],[F(1,2),1,F(3,2),2],[F(1,3),F(2,3),1],[1,F(1,2),F(1,4)]),
 ('disconnected_zero_column',[[1,0,0],[0,1,0],[0,0,0]],[1,2,1],[1,1,1],[1,1,1]),
 ('zero_weight_rows',[[1,1,0],[0,1,1],[1,0,1]],[1,F(1,2),2],[0,1,1],[1,0,F(1,3)]),
 ('zero_total',[[1,2],[3,4]],[1,1],[0,0],[1,1])]
def run(name,U,dx,beta,v,c):
 U=[[F(x) for x in row] for row in U];dx=list(map(F,dx));beta=list(map(F,beta));v=list(map(F,v));c=list(map(F,c));ny=len(U);nx=len(dx)
 J=[sum((dx[x]*U[y][x] for x in range(nx)),F(0)) for y in range(ny)]
 L=[[beta[y]*v[y]*U[y][x]*dx[x] for x in range(nx)] for y in range(ny)]
 l=[sum(row) for row in L];q=[sum((L[y][x] for y in range(ny)),F(0)) for x in range(nx)]
 p=[sum((dx[x]*U[y][x]*c[x] for x in range(nx)),F(0))/J[y] if J[y] else F(0) for y in range(ny)]
 m=[sum((L[y][x]*p[y] for y in range(ny)),F(0))/q[x] if q[x] else F(0) for x in range(nx)]
 K=[[sum((L[y][x]*L[y][z]/(q[x]*l[y]) for y in range(ny) if l[y]),F(0)) if q[x] else F(int(x==z)) for z in range(nx)] for x in range(nx)]
 E=sum((l[y]*p[y]**2 for y in range(ny)),F(0));P=sum((q[x]*m[x]**2 for x in range(nx)),F(0))
 variance=sum((L[y][x]*(p[y]-m[x])**2 for y in range(ny) for x in range(nx)),F(0))
 ck('conditional_variance',E-P==variance)
 for x in range(nx):
  ck('Markov_rows',sum(K[x])==1)
  ck('kernel_conditional_mean',sum((K[x][z]*c[z] for z in range(nx)),F(0))==m[x] if q[x] else True)
  for z in range(nx):ck('detailed_balance',q[x]*K[x][z]==q[z]*K[z][x])
 inner=lambda a,b:sum((q[x]*a[x]*b[x] for x in range(nx)),F(0))
 Kc=[sum((K[x][z]*c[z] for z in range(nx)),F(0)) for x in range(nx)]
 K2c=[sum((K[x][z]*Kc[z] for z in range(nx)),F(0)) for x in range(nx)]
 ck('full_energy_K',E==inner(c,Kc))
 ck('projection_energy_K_squared',P==inner(c,K2c)==inner(Kc,Kc))
 ck('variance_K_minus_K_squared',E-P==inner(c,[Kc[x]-K2c[x] for x in range(nx)]))
 linear=inner(c,c);dirichlet=inner(c,[c[x]-Kc[x] for x in range(nx)])
 edge=sum((q[x]*K[x][z]*(c[x]-c[z])**2 for x in range(nx) for z in range(nx)),F(0))/2
 rowvariance=sum((l[y]*p[y]*(1-p[y]) for y in range(ny)),F(0))
 ck('Dirichlet_pair_form',dirichlet==edge)
 ck('Dirichlet_true_tent',dirichlet==linear-E==rowvariance)
 ck('energy_order',0<=P<=E<=linear)
 return dict(name=name,capture=c,J=J,row_mass=l,receiver_mass=q,p=p,m=m,K=K,E_full=E,P_infinity=P,conditional_variance=variance,true_tent=dirichlet,linear_capture=linear,scope='Finite nonnegative transport matrix with one common receiver indicator c, not a full original kernel/history realization.')
def serial(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [serial(v) for v in x]
 return x

def main():
 models=[]
 for name,U,dx,beta,v in fixtures():
  nx=len(dx)
  for c in [[0]*nx,[1]*nx,[i%2 for i in range(nx)]]:models.append(run(name,U,dx,beta,v,c))
 result=dict(status='PASS',arithmetic='Fraction',total_checks=sum(counts.values()),check_counts=dict(counts),fixtures=4,capture_tests=12,models=models,scope='Bounded structural identities only. Freeze beta,v,U,dx at the original z,r; reversibility applies at that frozen parameter. No root budget or original realizability is certified.',zero_column_convention='If receiver mass q_x=0 set K(x,x)=1. Such columns carry zero stationary mass and do not affect any identity.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(serial(result),sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['status','total_checks','check_counts','fixtures','capture_tests']},sort_keys=True))
if __name__=='__main__':main()
