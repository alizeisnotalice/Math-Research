from fractions import Fraction as F
from math import comb
from decimal import Decimal, localcontext
from itertools import product
ct={'common_soft_moment':0,'near_price':0,'two_source_long':0,'root_beta_long':0}
with localcontext() as ctx:
 ctx.prec=75
 def dec(q):return Decimal(q.numerator)/Decimal(q.denominator)
 for n in (1,2,8,32,128):
  cs=[F(comb(n,k)*k**k*(n-k)**(n-k),n**n) for k in range(n+1)]
  C=sum(cs);assert sum(k*c for k,c in enumerate(cs))==n*C/2;ct['common_soft_moment']+=1
  for ratio,lam,lh,eps in product((F(1),F(5,4),F(2)),(F(1,4),F(1),F(4)),(F(1,128),F(1,4),F(4)),(F(1,4),F(1,16))):
   An=1+n*dec(ratio).ln();q=3*dec(lam)/4;H=dec(lh/lam);ee=dec(eps);cc=dec(C);M=An*n*cc/2
   base=ee*q*H/(2*An)
   hr=Decimal(1)/2*min(Decimal(1),(base.ln()/n).exp())
   near=An*min(Decimal(1),(2*hr)**n/(q*H))
   assert near<=ee/2+Decimal('1e-60');ct['near_price']+=1
   target=min(ee*q/(4*dec(lam)),ee*q*H/(2*An))
   tr=Decimal(1)/2+max(Decimal(0),(M/target).ln())
   tail=M*(Decimal(1)/2-tr).exp()
   assert 4*dec(lam)*tail/q<=ee+Decimal('1e-60') and An*tail/(q*H)<=ee/2+Decimal('1e-60');ct['two_source_long']+=1
   target=min(cc*q/(4*dec(lam)),ee*q*H/(2*An))
   tr=Decimal(1)/2+max(Decimal(0),(M/target).ln())
   tail=M*(Decimal(1)/2-tr).exp()
   assert 4*dec(lam)*tail/q<=cc+Decimal('1e-60') and An*tail/(q*H)<=ee/2+Decimal('1e-60');ct['root_beta_long']+=1
print('PASS',ct)
