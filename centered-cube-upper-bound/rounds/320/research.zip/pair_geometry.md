# R320 — source-linear receiver-distance tails and the remaining symmetric annulus

## 1. Contract and result

Keep exactly the R319 original fields

    U_y(x)=1_E(x)alpha(x,y)P_(s(x),L(x))(x-y)/q(x),
    J_y(r)=integral_{R(x)<=r}U_y(x)dx,
    A_yz(r)=integral_{R(x)<=r}U_y(x)c_x(z)dx,
    c_x(z)=1{z in Q_(R(x))(x)},
    rho(x)=integral U_y(x)beta(dy)<=1.

The sources beta,nu are arbitrary finite positive L1; a<=L,R<=b<=2a, q_-=3lambda/4<=q<=lambda, and the same-selected-radius cap is nu(Q_(R(x))(x))<=4lambda R(x)^n. All original alpha, low-pe/m, aspect, history and outer costs remain. No hard winner, f-L2 assumption, source density cap or source comparability is used. In fact the optional all-radius cap is not needed for this theorem.

Fix H>0. Let 0<=v(y,z,r)<=1 be any measurable ENDPOINT-INDEPENDENT weight, and keep the gate J_y(r)>=H. The theorem applies both to v=1 (the original physical B_H) and to the actual R319 tent weight, which retains its full original A,J and support. Put

    ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr,
    A_n=1+n log(b/a),
    F1=integral beta nu ell_n A_yz(r)<=A_n W_nu.

The new paid branch is receiver separation ||u-w||_infinity>2t, not source separation |y-z|. Its ENTIRE capturing first moment has the source-linear receipt

    N_long^v <=min(1,T(t)/(q_-H))F1
                              +(4lambda/q_-)T(t)W_beta, (1)

where for t>=b/2 one can use

    T(t)=A_n sum_(k=1)^n c_nk min(1,k exp(1/2-t/b))
       <=M_n exp(1/2-t/b),
    M_n=A_n n C_n/2,
    C_n=sum_(k=0)^n c_nk<=1+(pi/2)sqrt(n),
    c_nk=max_(0<=s<=1) binom(n,k)s^k(1-s)^(n-k).    (2)

Only actual capturing-receiver caps and actual FIRST are used to remove one source mass. This differs from the older source-pair overlap tail with a product of source masses: neither its event nor its payment is substituted here.

The centre-near branch ||u-w||_infinity<=h has

    N_near^v<=min(1,(2h/a)^n/(q_-H))F1.             (3)

Unlike the older delta(u,w)=||u-w||_infinity+|R(u)-R(w)|/2 near branch, (3) retains ALL radius ratios and requires no top-scale deletion. The admissible h below can approach a/2, rather than a/(2n). This is actual receiver-volume geometry, not a thin-source-boundary assertion.

## 2. Exact symmetric loss, local overlap, and the whole square

For a symmetric receiver-pair region D define the positive baseline and overlap

    N_D^v=integral beta nu ell_n 1{J>=H} v/J
             integral_{R(u),R(w)<=r}U_y(u)U_y(w)c_u(z)1_D du dw,
    E_D^v=the same integral with c_u(z)c_w(z) in place of c_u(z),
    L_D^v=N_D^v-E_D^v>=0.

The exact physical symmetry identity is

    L_D^v=(1/2)integral beta(dy)ell_n(dr)1{J>=H}/J
        integral_{R(u),R(w)<=r}U_y(u)U_y(w)1_D
           [integral v(y,z,r)|c_u(z)-c_w(z)|nu(dz)]du dw. (4)

Thus the source term is the ACTUAL weighted mass of the cube symmetric difference. It is not replaced by its volume. The full overlap is

    E_full^v=integral beta nu ell_n1{J>=H}v A^2/J.

Set D_near={distance<=h}, D_mid={h<distance<=2t}, D_long={distance>2t}. The choices below ensure h<2t. This is a complete disjoint partition including both equalities. Then

    B_H^v=L_near^v+L_mid^v+L_long^v,
    B_H^v=N_near^v+N_long^v+Pi_mid,
    Pi_mid=N_mid^v-E_full^v.                        (5)

The first line is a positive physical-loss allocation. The second is a DIFFERENT, signed compensated allocation retaining the WHOLE capture square, not only E_mid. Indeed Pi_mid=L_mid-E_near-E_long<=L_mid. Both N_mid and E_full have finite integrals bounded by F1, so no infinity subtraction occurs. Their meanings must not be interchanged.

For oriented collar/history pair masks, the positive near/long bounds remain valid by domination. Formula (4) is asserted only for the whole physical field and symmetric pair regions; an oriented collar is not silently symmetrized or identified with a whole capture square.

## 3. Common-softness tail proof and the two actual source payments

The ORIGINAL one-dimensional soft profile is phi=h*omega, h=1_[-1/2,1/2], omega(t)=integral_0^1 exp(-|t|/u)du. Omega is a probability density because integral omega=2 integral_0^1 u du=1. If W has that law, then

    P(|W|>v)=2 integral_0^1 u exp(-v/u)du<=exp(-v), v>=0.

Adding a variable in[-1/2,1/2] gives P_phi(|X|>T)<=exp(1/2-T) for T>=1/2. For the normalized fixed-degree profile Q_k with exactly k soft coordinates, a coordinate union bound therefore gives

    P_(Q_k)(|X|_infinity>T)<=min(1,k exp(1/2-T)).

The common-s expansion is P_(s,L)=sum_k b_nk(s)Q_(k,L), not a separate coordinate maximization. Each Q_k is a normalized ray-decreasing profile. The original dilation envelope

    sup_(a<=L<=b)L^(-n)Q_k(x/L)
       <=b^(-n)Q_k(x/b)+n integral_a^b L^(-n)Q_k(x/L)dL/L

implies, after integration on |x|_infinity>t,

    integral_{|x|>t}sup_(s,L)P_(s,L)(x)dx<=T(t).

The exact symmetry c_nk=c_n,n-k gives sum k c_nk=n C_n/2, proving (2). All shared-softness and scale costs are visible; no component or future-softness FIRST is granted. Consequently every original row satisfies

    integral U_y(x)1{|x-y|_infinity>t}dx<=T(t)/q_- . (6)

If ||u-w||_infinity>2t, then either |u-y|_infinity>t or |w-y|_infinity>t. On the latter branch the second-endpoint integral, divided by the SAME full J>=H, is at most min(1,T(t)/(q_-H)). This leaves v A, hence at most the first term of (1).

On the capturing-u tail branch, integrate the second endpoint to its unchanged J. Drop v only positively, then integrate nu at the actual u and apply nu(Q_(R(u))(u))<=4lambda R(u)^n. Tonelli and the exact inclusive tail ell_n([R(u),b])=R(u)^(-n) cancel the physical volume. The resulting price is

    4lambda integral beta(dy)integral U_y(u)1{|u-y|>t}du
                                      <=(4lambda/q_-)T(t)W_beta.

This proves (1) for the WHOLE baseline, so loss plus overlap on that branch is paid ONCE. The factor is 4lambda/q_-=16/3, not a product W_beta W_nu. All physical radius atoms, including b, are retained.

For (3), phi<=1 and the actual common product profile imply U_y(w)<=1/(q_-a^n). The centre-near receiver set has actual volume (2h)^n regardless of R(u),R(w). Bound its conditional row mass and leave the capturing first moment F1. This proof needs no cap at a virtual receiver and no control of |R(u)-R(w)|.

## 4. Explicit thresholds and usable remaining middle kernels

For arbitrary desired source coefficients epsilon_beta,epsilon_nu>0, choose the outer-instance constants

    h=(a/2)min(1,[epsilon_nu q_-H/(2A_n)]^(1/n)),
    T0=min(epsilon_beta q_-/(4lambda),
                              epsilon_nu q_-H/(2A_n)),
    t=b[1/2+log_+(M_n/T0)].                         (7)

They depend only on the declared parameters, not on a favorable receiver or posterior. Then T(t)<=T0, h<=a/2 and t>=b/2, so

    N_near^v+N_long^v
                 <=epsilon_beta W_beta+epsilon_nu W_nu. (8)

Both interfaces are therefore valid:

    B_H^v<=epsilon_beta W_beta+epsilon_nu W_nu+L_mid^v,
    B_H^v<=epsilon_beta W_beta+epsilon_nu W_nu+Pi_mid. (9)

Taking epsilon_beta=epsilon_nu=epsilon gives epsilon(W_beta+W_nu). Taking epsilon_beta=C_n and epsilon_nu=epsilon gives C_n W_beta+epsilon W_nu, an explicit root-beta source receipt. These choices have DIFFERENT t and cannot be exchanged after forming the middle region. The h in(7) is (a/2)exp(-log_+[2A_n/(epsilon_nu q_-H)]/n); it is close to a/2 when that logarithm is o(n). No universal lower bound for h is claimed when q_-H is extremely small.

For the original physical B_H use v=1. For the R319 tent use its original weight v and the same threshold H, A,J. Then (9) bounds that exact auxiliary tent. Multiplying by its original target-entry coefficient or outer Lambda multiplies EVERY source fee and the retained remainder. No global target entry, all-scale assembly or unpriced outer integration is asserted.

The remaining positive kernel is precisely (4) on the finite centre-distance annulus

    h<||u-w||_infinity<=2t,

with ALL selected scale ratios in[a,b], full prefix, actual cube intersection benefit and original sources/masks. Alternatively the signed interface keeps Pi_mid=N_mid-E_full. No estimate turning its weighted symmetric-difference mass into a root source budget is proved. The all-radius upper cap alone supplies no lower bound for the actual source mass in intersections. Thin boundary volume times a nonexistent source density is not used.

For an already constructed R319 oriented far-collar baseline N_cf, its restriction distance>2t is bounded by the SAME long receipt (1), by positive domination. One may therefore retain its original whole-square/projection term after removing just that paid baseline portion. This does not authorize subtracting whole energy from an isolated positive local loss. No new projection theorem is introduced here.

The advance is a source-paid long-distance receiver branch and a wider centre-near branch, with an exact complete middle complement. The middle source-overlap estimate, rather than a new potential or an unproved density assumption, remains the specific unresolved geometric task.

## 5. Executed finite threshold checks

The following standard-library run passed five exact common-soft moment identities and270 cases each for near, two-source long and root-beta long thresholds. It uses75-digit Decimal elementary functions, hence threshold evaluations are numerical diagnostics rather than interval certificates. Formula(7) proves the uniform inequalities analytically. No original kernel/source realization is claimed by these scalar tests.

```python
from fractions import Fraction as F
from math import comb
from decimal import Decimal, localcontext
from itertools import product
ct={'common_soft_moment':0,'near_price':0,'two_source_long':0,'root_beta_long':0}
with localcontext() as ctx:
 ctx.prec=75
 def dec(q):return Decimal(q.numerator)/Decimal(q.denominator)
 for n in (1,2,8,32,128):
  cs=[F(comb(n,k)*k**k*(n-k)**(n-k),n**n) for k in range(n+1)]
  C=sum(cs);assert sum(k*c for k,c in enumerate(cs))==n*C/2;ct['common_soft_moment']+=1
  for ratio,lam,lh,eps in product((F(1),F(5,4),F(2)),(F(1,4),F(1),F(4)),(F(1,128),F(1,4),F(4)),(F(1,4),F(1,16))):
   An=1+n*dec(ratio).ln();q=3*dec(lam)/4;H=dec(lh/lam);ee=dec(eps);cc=dec(C);M=An*n*cc/2
   base=ee*q*H/(2*An)
   hr=Decimal(1)/2*min(Decimal(1),(base.ln()/n).exp())
   near=An*min(Decimal(1),(2*hr)**n/(q*H))
   assert near<=ee/2+Decimal('1e-60');ct['near_price']+=1
   target=min(ee*q/(4*dec(lam)),ee*q*H/(2*An))
   tr=Decimal(1)/2+max(Decimal(0),(M/target).ln())
   tail=M*(Decimal(1)/2-tr).exp()
   assert 4*dec(lam)*tail/q<=ee+Decimal('1e-60') and An*tail/(q*H)<=ee/2+Decimal('1e-60');ct['two_source_long']+=1
   target=min(cc*q/(4*dec(lam)),ee*q*H/(2*An))
   tr=Decimal(1)/2+max(Decimal(0),(M/target).ln())
   tail=M*(Decimal(1)/2-tr).exp()
   assert 4*dec(lam)*tail/q<=cc+Decimal('1e-60') and An*tail/(q*H)<=ee/2+Decimal('1e-60');ct['root_beta_long']+=1
print('PASS',ct)
```

Only `/tmp/r320_pair_geometry.md` is authored here; other authors' files and Git are unchanged.
