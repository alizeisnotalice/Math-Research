# R320 independent preauthor screen — common source kernel and receiver translation

Ownership: only this file; no Git or other author's file edits. This screen was written before reading any R320 author proof. It uses the frozen R319 contract, not a newly recomputed source/history qualification. This is a bounded constructive screen, not a root-budget or closure verdict.

## 1. A genuine common receiver Markov kernel is available

For fixed original z,r, retain the full U_y, inclusive prefix E_r={x:R(x)<=r}, J_y(r), actual R and all original qualifications. Let v_y(z,r) be the original minimum-tent weight (zero unless J>=H and 0<A<H). Define

 K_zr(u,w)=1_Er(u)1_Er(w) integral beta(dy) v_y U_y(u)U_y(w)/J_y(r).

Zero-J rows contribute zero. This is a nonnegative symmetric measurable density. Its two marginals are exactly rho_v(u)=1_Er(u) integral beta v_y U_y(u)<=rho(u)<=1. Consequently, after division by rho_v(u)>0, it is a common reversible Markov transition with invariant measure rho_v(u)du; zero rows are omitted. It is not a new selected source per z. Dependence on the frozen original z,r through v is legitimate, and must remain inside subsequent integrals. The original full J is not recomputed after geometric restriction.

For actual cube captures c_u(z), the original weighted tent equals

 (1/2) integral nu(dz)ell_n(dr) integral du dw K_zr(u,w)(c_u(z)-c_w(z))^2.

This exact identity offers a legal common-source coupling. It does not by itself concentrate w-u, control a far transition, or bound conditional cross-row variance. Marginal <=1 is not a bound by a translation-invariant displacement law. R319 Pi_local remains a compensated whole-tent certificate, not this positive actual pair flow or standalone collar-far loss.

## 2. What fixed soft-kernel translation actually pays

For fixed common s and L, P_s,L is the product of f_s=(1-s)h+s(h*w), scaled by L. Coupling the same coordinate noise and using convolution contraction gives

 ||P_s,L(.+hvec)-P_s,L||_1 <= 2 min(1, ||hvec||_1/L).

Indeed the one-dimensional uniform interval TV distance is 2 min(1,|h_i|/L); convolving it with the fixed probability (1-s)delta_0+s w can only reduce it. The product telescoping bound and the total bound 2 give the assertion. Hence arbitrary finite beta is allowed in the source-linear identity/bound

 integral beta(dy) integral du |P_s,L(u+hvec-y)-P_s,L(u-y)|
 <=2 W_beta min(1,||hvec||_1/L).

No density cap on beta or nu is used. A bounded original row coefficient can multiply this integrand positively. This is useful only after establishing the required domination of the OTHER pair/source/layer weights. In particular if, after integrating those weights, their nonnegative effective coefficient is <=g(hvec), uniformly in actual u,y, the resulting translation contribution is bounded by

 (2 W_beta/q_-) integral g(hvec) min(1,||hvec||_1/L) dhvec.

The exact g, its integral and scale/source/clock costs are part of the certificate. They are not provided merely by reversibility or a unit marginal. Finite frozen parameter classes can use this bound with their actual allocation weights and sums retained. No component FIRST is being granted.

## 3. Exact receiver change of variables and unavoidable original-field terms

Write m_y(u)=1_E(u)alpha(u,y)/q(u), and p_u(t)=P_(s(u),L(u))(t). Under w=u+hvec, the exact actual-row difference is

 U_y(u+hvec)-U_y(u)
 =m_y(u+hvec)[p_(u+hvec)(u+hvec-y)-p_u(u+hvec-y)]
  +m_y(u+hvec)[p_u(u+hvec-y)-p_u(u-y)]
  +[m_y(u+hvec)-m_y(u)]p_u(u-y).

The three terms are respectively parameter-selector change, spatial kernel translation at the frozen ORIGINAL u parameters, and original row-weight/gate change. The last term includes E, alpha (full e_g/m/ownership/history/low-pe/aspect qualification), and q. No regularity of those fields was assumed. The first includes actual s,L changes; fixed-kernel TV cannot delete it. Even the middle term uses u-selected parameters, so its integrated bound is not obtained by moving a supremum outside the fixed-parameter TV estimate. One must freeze parameters, prove a valid selected-parameter envelope, or pay the corresponding commutation/selector term.

The prefix factor also changes by

 1_{R(u+hvec)<=r}-1_{R(u)<=r}.

Capture is c_u(z)=1_{Q_R(u)(u)}(z). Its exact spatial change involves BOTH center displacement hvec and actual radius change R(u+hvec)-R(u). Thus a translated cube response requires a separate capture symmetric-difference term with the original nu. Same-selected-radius cap alone does not control arbitrary shifted-center/radius shells. The matched all-radius full-f cap, or a winner/defect contact estimate under its explicit hypotheses, is a possible payment interface; no cap is inherited at a virtual receiver. R319's small actual-receiver-volume estimate is another already valid interface for near pairs, but is not a translation regularity bound on nu.

If a proof also shifts y to preserve u-y exactly, the measure beta is translated and its TV/transport error must be kept. If it shifts z to align capture centers, nu and every z-dependent qualification are translated; their variation costs must likewise be kept. Arbitrary L1 sources have no uniform Lipschitz/density modulus. A simultaneous coordinate substitution is valid as an equality only with every affected measure, actual field and integration domain transformed. It does not turn the transformed fields into a new legal FIRST input at their new centers.

## 4. Positive applicable regimes, without claiming an input-uniform rate

A. Frozen s,L and an actual common transition certificate dominated by a displacement profile g permit the genuine source-linear soft translation payment in §2. Piecewise frozen receiver fields also permit it inside each piece; all cross-piece boundary/parameter/gate traffic remains an exact nonnegative defect unless separately controlled. Such a defect may be measured on the original receiver variables, rather than imposing a fictitious source density cap.

B. Arbitrary original measurable fields do have a qualitative receiver L1 translation modulus. The actual family U_y belongs to L1(du beta(dy)), since the positive common-soft/scale envelope gives finite integral, and/or original FIRST bounds its integral by finite |E|. Therefore

 integral beta(dy)||U_y(.+hvec)-U_y||_1 ->0 as hvec->0.

This follows from translation continuity on the product measure and dominated convergence; it assumes neither smooth alpha nor source density. Similarly the actual qualified integrable joint function U_y(u)c_u(z), or its original pair-qualified version, has product-measure receiver translation continuity when its finite original envelope is retained. A bounded additional weight can use that modulus with its actual bound and source/layer factors shown. This provides input-dependent small-error approximations, not a uniform dimension/source-root rate or a legal new selected-receiver field. It does not imply the common Markov transitions are mostly at such small displacements.

C. The denominator is protected on the original high-J region, but that is not invariance under arbitrary approximation. A translation that moves the COMPLETE analytic row with its original radius label can preserve J by Lebesgue change of variables, whereas re-centering its physical cube changes capture and full-f cap provenance. An approximation that changes the actual row/prefix must keep the changes in J, v, high-J gate and A, or work with a fixed-original-J domination identity. No small J defect can be silently divided away.

## 5. Bounded local calculations actually executed

Using local Python standard-library exact Fractions: 20 tensor uniform-cube TV bounds; 9 common-kernel symmetry/marginal checks; 3 Dirichlet identities; 243 exact three-term translation decompositions. Total 275 checks, all PASS. These are finite algebra/volume diagnostics, not original-history realizations, a general operator certificate, or proof of the missing root budget. General assertions in §§1–4 are analytic; no R319 test was rerun.

## 6. Current verdict and pending author comparison

The common-source Markov formulation and fixed-parameter soft-kernel TV route are valid constructive contracts. The precise missing interface is a source-conserving integrated bound on displacement/selector/gate/capture defects (or an actual quantitative projection saving), with original beta, nu, J, qualification and clock weights retained. A source density cap is not necessary for the valid frozen-kernel calculation, but it cannot be replaced by free receiver translation regularity either. No general Pi_local root bound, native rejection payment, all-scale assembly or global closure is established by this screen. Await bounded author proofs for comparison.

## 7. New independent far-receiver tail receipt — PASS before author proof

For t>=b/2 the complete common-soft/scale envelope, formed BEFORE restricting its receiver tail, gives

 T(t):=integral_{||x-y||_infinity>t} sup_{s,L in[a,b]}P_s,L(x-y)dx
 <=An Csoft min(1,n exp(1/2-t/b)).

Each fixed normalized soft coordinate is H+W; |H|<=1/2, and P(|W|>d)=2 integral_0^1 u exp(-d/u)du<=exp(-d). A union bound over at most n soft coordinates gives the exponential estimate for each positive coefficient shape. The actual scale L<=b only makes its normalized tail threshold larger. The full positive scale envelope has mass An and coefficient-sum Csoft; the trivial mass and tail bound can be minimized. This is not a ray-envelope applied to a non-ray-decreasing truncated profile.

In the original oriented capture/miss loss, ||u-w||_infinity>2t implies that the capturing endpoint u OR the missed endpoint w satisfies ||endpoint-y||>t. On the missed-end tail use integral Uw<=T(t)/q_-, divide the ORIGINAL J>=H, and keep the capturing first moment. FIRST and ell([Ru,b])=Ru^-n give T(t)An/(q_-H) Wnu. On the capturing-end tail, the full missed-end prefix is <=J; cancel only then, retain its original receiver cap nu(Q_Ru)<=4lambda Ru^n and integrate ell. This gives (4lambda/q_-)T(t)Wbeta. Therefore their union costs at most

 T(t)[An/(q_-H)Wnu+(4lambda/q_-)Wbeta].

The same bound holds with the original tent weight v<=1 and any further positive subset, without changing bad U, prefix, numerator, source, or original qualifications. No source volume/density cap is used. This pays very large SPATIAL receiver separation. It does not pay all R319 delta(u,w)>h pairs (radius mismatch and the moderate spatial annulus remain). If selecting t for a target epsilon, retain the displayed q_-H dependence and all outer factors; do not describe t=O(log n) without the needed parameter qualification.

## 8. Independent comparison screens for the two author mechanisms

Receiver projection: the common reversible Markov operator K from §1 is self-adjoint, positive semidefinite and contractive on L2(rho_v dx). For binary actual c, E_full=<c,Kc>, P_infinity=||Kc||² and C_v-P_infinity=(1/2)integral rho_v(du)K²(u,dw)(c_u-c_w)². The actual U height M=1/(q_-a^n) and ORIGINAL J>=H give K(u,w)<=M/H; K² inherits this density ceiling. It supplies the already-paid near-volume estimate, not general far concentration. On active rows with J>=L H (L>1), A<H implies E_long<=C_long/L. Thus Pi_grid>= (1-1/L)C_long-D_omit is a valid necessary structural comparison, not a new root payment. Inclusive small-J prefix control remains valid with crossing atoms excluded as a whole; this is an existing tool and not registered as a new saving.

Native cluster receipt: for any frozen disjoint bounded source clusters C, full mass mC=f(C), bounding-box widths d_i and rC^n=mC sqrt(n)/lambda, the actual CURRENT native remainder restricted to z in C and R<=rC is a positive actual subtraffic. Each cell row is <=lambda, since it is dominated by the original normalized full-f row. Its receiver support lies in box(C)+Q_min(b,rC); if active, rC>=a. Its total cost is therefore <=lambda prod(min(b,rC)+d_i)<=sqrt(n)mC prod(1+d_i/a). Summing full mC is legitimate ONCE for disjoint cells, independently of receiver overlap; it is a new source fee, not free reuse of earlier packet fees. Cubic side delta=a/n² gives factor<e^(1/n). An independent frozen uniform shift can be averaged without a shift-count factor. Exact remaining traffic must retain R>rC and/or inactive cells along with all original high-average/tag-rejection and packet-deep masks.

For the proposed n16 microcluster of side s=1/n^4 centered at an old grid vertex, random side delta=1/n² cells contain the entire cluster with probability (1-s/delta)^n=(1-1/n²)^n>=15/16. The row-volume mechanism is valid regardless of whether this example is eventually certified. Its claimed old CURRENT adaptive-Pdeep status requires the exact frozen R318 termination rule to be checked in the final author file; concentration alone does not identify that algorithm's terminal packets. A specified allowed finest partition is a different sufficient original partition choice and must be labelled if used. No original component/history/FULL identity follows from the cluster receipt.

## 9. Geometry author comparison — PASS within diagnostic scope

Read the complete frozen /tmp/r320_geometry.md, SHA256 24e518c0936e396afa09df4e2e60a1680364cfe795645785f0a8e000d204cdb0. It agrees with the independent Markov/projection screen. Its two-sided estimate retains all original v/full-J and paid omission costs. The short-row receipt uses inclusive original J(R), so a crossing atom is excluded whole; equality conventions remain bounded by the same threshold. At outer row multiplier 2 and H0, the continuation coefficients 12S Wbeta+4S Wnu and all added source fees are correct. It is explicitly a comparison/strategy diagnostic, not additional root payment. The fixed dyadic projection limit is justified by conditional L2 approximation under each finite rho_v measure and positive integrated domination by F1. K² inherits the height ceiling on rho_v-almost-everywhere states. The remaining middle-distance two-step crossing/high-J capture estimate remains unproved. No correction requested.

## 10. Native cluster author comparison — PASS

Read the complete frozen /tmp/r320_entry.md, SHA256 59611b8b9e22c1fce1f4c013b8c0f4c8a338cb10dac84c0a21e6a387cda27f3f. The source-frozen row-volume proof, finite active-cell census, normalized uniform-shift source lift, exact equality endpoint in the paid predicate, and unchanged 768/761 output coefficient agree with the independent screen. The added full-f source bill G320 is not declared disjoint from earlier source bills; it is genuinely added once within this new receipt. Its actual target is only the combined old high-average plus low-average tag-rejected native remainder, not a reconstruction of the original packet fields.

Independently read the frozen R318 termination rule (§3), then checked the proposed current-old-packet claim in the final author §5. In the specified phase and n16/n64 cases, each cluster orthant lies at its old root corner and remains entirely in one child at every allowed original fine-grid split; the positive child has the entire parent mass and forces refinement to the fine cell. Terminal mass is 3/2^n, its average is high, and the exact old-deep sufficient inequality holds. Remote support lies outside these old local roots. The current native selector/macro/harmonic/captured/heavy gates follow on the stated positive receiver SUBSET: all radii capture local mass 3, none capture the remote cube, R*=1, G1=1/3. The two ownership cells share the actual fixed component. The new shift contains the whole cluster with the stated normalized probability; external tiny cells cannot be preactive and cannot meet both clusters, so W_act<=3 is a valid sharper diagnostic budget.

This is an actual nonempty new paid branch of current old-deep/high-average traffic. It does not prove a uniform accepted fraction for arbitrary f; U_left retains the exact old qualifications and high-average/tag-rejection weights. No historical FULL or all-scale connector is inferred. No correction requested.

## 11. Pair-distance author comparison — PASS

Read /tmp/r320_pair_geometry.md, SHA256 a45c412c97f944131f4fae0b0a09f1a78c1f58de933810bee4575ab6bc376e25. It sharpens the independently screened loose n Csoft tail to the exact positive coefficient union sum and uses sum_k k c_nk=n C_n/2. Its long-distance bound pays the WHOLE baseline, hence loss and overlap together once; the source-linear coefficients and original actual cap/FIRST order agree with §7. The centre-near bound needs only spatial distance, retains all actual radius ratios and uses the full high-J denominator, so no top deletion or winner assumption is required for this alternative split.

The disjoint centre-near/middle/long partition is exhaustive, with the stated equality endpoints. The physical symmetric-loss identity holds because v is endpoint-independent. The positive middle loss and the DIFFERENT signed compensated middle certificate are clearly separated; whole capture square is not claimed dominated by its local middle overlap. Both interfaces in (9) are valid. The explicit h,t thresholds give near nu-price <=epsilon_nu/2 and long nu-price <=epsilon_nu/2, plus the declared beta-price. Changing epsilon_beta changes t and therefore changes the middle region; no selector exchange is made. Extremely small q_-H can make h extremely small and t large; these parameter dependencies remain explicit. No full middle-overlap/root bound is supplied.

The embedded diagnostic declares 5 exact Fraction common-soft coefficient identities and 270 cases each of three 75-digit ordinary Decimal threshold tests (810 total Decimal assertions). This is not an interval certificate or native spatial-input realization; the uniform theorem is analytically proved. No correction requested.

## 12. Entry evidence-only rebind

After the entry proof comparison, its author changed only the §7 paragraph to record actually executed n64 rational diagnostics alongside n16. Read that changed paragraph. No mathematical contract or formula changed. Current /tmp/r320_entry.md SHA256 is 219b33c8d90ecdd05ddb39896b3ef11253ec87014c89bcfc179d8070b863fdfe; the previous §10 proof comparison remains valid for these final bytes. Final integration/evidence binding remains pending.


## 13. Final primary integration and fresh-run evidence — PASS

Read final checkpoint combined.md, research.tex and source_references.json statically. Their coefficients and scope agree with the three author proofs. The actual physical B_H middle LOSS, the DIFFERENT signed middle baseline-minus-whole-square certificate, R319 Pi_grid and the native U_left are not conflated. The sharper tail displayed in TeX follows by minimizing the coefficient-sum mass bound with its exact first-degree moment bound. Its chosen half-nu thresholds sum to epsilon Wnu, and its beta threshold gives epsilon Wbeta, retaining q_-H and all original outer multipliers. No new output X loss is charged for distance or cluster receipts. The native branch adds G320 to all earlier source fees and keeps the existing 768/761 coefficient; it does not reuse an earlier fee as though sources were disjoint. No intermediate/native target identity or complete global ledger closure is asserted.

Read all four primary fresh execution logs: Markov 270 exact Fraction assertions; geometry 1574 exact Fraction assertions; pair 5 exact coefficient identities plus 810 ordinary 75-digit Decimal threshold diagnostics; cluster 218 exact Fraction/integer assertions. Total primary 2877=2067 exact+810 Decimal, as stated. These are assertion counts, not distinct spatial inputs or a uniform proof. The cluster script independently tracks the old R318 adaptive path, actual positive-volume receiver subset, exact phase interval probabilities, inactive remote cells and rational mass-radius brackets. Markov/geometry matrices are abstract structural diagnostics, not native-history inputs. The numerical evidence does not supply the missing middle/root estimate. This reviewer's own 275 checks in §5 are separate and are NOT added to the primary total.

Checked checkpoint copies of all three author proofs byte-identical to the current /tmp originals. Checked both extracted embedded geometry/pair scripts identical after whitespace trimming to their author code. Checked the cluster script byte-identical to its numeric author's frozen source and the cluster JSON matches the announced final hash. Final file binding follows; no redundant test rerun, PDF compile, repository/Git write, or expanded research was performed.

## 14. Frozen final receipt and exact remaining gap

PASS for the bounded source-linear near/long receiver-distance receipts, the new actual positive native cluster branch, the diagnostic two-sided projection comparison and the current static integration. B_H remains the principal geometric problem: actual finite middle-distance source-weighted capture/miss mass and actual high-J low-A capture still have no general root-source payment. The native new-grid small-mass U_left is exact and unpaid. Reversibility/PSD/density ceilings do not establish their missing quantitative saving. Auxiliary compensated integrals are not relabelled actual positive traffic. Complete broad-distance/low-pe/extreme-aspect/initial/deletion/future-deleted/physical-scale entry bookkeeping remains subject to its own identity and multiplicity checks; no general weak bound is certified.

SHA256 bindings (the proof copies have the same hashes as /tmp/r320_entry.md, /tmp/r320_geometry.md and /tmp/r320_pair_geometry.md respectively):

- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/entry.md`: `219b33c8d90ecdd05ddb39896b3ef11253ec87014c89bcfc179d8070b863fdfe`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/geometry.md`: `24e518c0936e396afa09df4e2e60a1680364cfe795645785f0a8e000d204cdb0`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/pair_geometry.md`: `a45c412c97f944131f4fae0b0a09f1a78c1f58de933810bee4575ab6bc376e25`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/combined.md`: `fd349d1dba3882a5d3127e685466795b86561b9ee728f4d80c57ade14ebf24a3`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/research.tex`: `3797964e79d2a3678248cc7b42dfb4dc3cadabcdc709d0e356854c6c35dcc069`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/source_references.json`: `27d32ecc275a6898e87bdb61c2d84bbd30087fbcc676df70e6f0f8270e416076`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/markov_checks.py`: `e57a5a7f6a7e2b571232a0597808812c40d16ea0eb0011531e3fbea440f1838d`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/markov_checks.json`: `d1d57699cc6b7d85a376c00aaa45bae4b75355574f4029d98c812401952ac3ab`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/markov_checks.md`: `d5feda4c320f241ce20e41c408f60f2404f85e48d4133d54b03b8fc01f0e11b5`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/markov_checks.log`: `330cce9f00df08dfd06fb67ce924b8e2c17ddbefde8bdaf87c8198bce11f17cf`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/geometry_checks.py`: `4315509afb8d66afd0907da7371e768e650956db11c0475059b0f762bba1914f`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/geometry_checks.log`: `4ee2f93f8ee636793a82b28167b725069cd68a58ad57375121fa50c45578a7b3`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/pair_checks.py`: `e606f215d8ead3d183fe27341bf777be5f7169297e4fc59c3af8e915a806db03`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/pair_checks.log`: `ade4fb8b58df3679cb2a7c6689d0863e333d232a9be623aee9dce28018cfec9f`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/cluster_checks.py`: `79dc2b239109492693606c977e005ebfdcd454b6b83af4eed69dd69055db2002`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/cluster_checks.json`: `479fcd6b47207a74f06b51098dae01882fe2d38916cea266bb882910ce1b4f36`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/cluster_checks.md`: `23a3e4d5f8b43876333c7cf8bbbaa918c48551d4e6b5f75855c28874ebcbe1d5`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round320_20261018_final_checkpoint/cluster_checks.log`: `67606b7f1f51dcb58d0d01c37e193e82df2d9f6a48516e2f851240e820e61a63`

Ownership respected: only /tmp/r320_audit.md written by this reviewer. This final bounded audit is frozen.
