"""R555 finite jump kernel LP. Exact rational symmetry assembly, binary64 HiGHS."""
from pathlib import Path
from fractions import Fraction as F
import itertools,math,json,time,sys,hashlib
import numpy as np
import scipy
from scipy.optimize import linprog
import sympy as sp
START=time.monotonic();L=3;J=7

def states(n):return [(a,b,c,n-a-b-c) for a in range(n+1) for b in range(n-a+1) for c in range(n-a-b+1)]
def make(n):
 st=states(n);lookup={s:i for i,s in enumerate(st)};weights=[math.factorial(n)//math.prod(math.factorial(a) for a in s)*2**(n-s[0]) for s in st]
 A=[[F(0) for s in st] for z in st]
 for row,s in enumerate(st):
  for a,num in enumerate(s):
   if not num:continue
   for t in range(1,J+1):
    v=F(num,t*t);A[row][row]-=2*v
    for sign in [-1,1]:
     dest=abs(a+sign*t)
     if dest<=L:
      ss=list(s);ss[a]-=1;ss[dest]+=1;A[row][lookup[tuple(ss)]]+=v
 origin=lookup[(n,0,0,0)];active=[r for r in range(len(st)) if r!=origin]
 lower=[int(s[2]==s[3]==0) for s in st];layer=[max(a for a in range(4) if s[a]) for s in st]
 return st,weights,A,active,lower,layer

def brute_check():
 n=2;st,w,A,active,lower,layer=make(n);pts=list(itertools.product(range(-L,L+1),repeat=n));ix={p:i for i,p in enumerate(pts)};orbit={s:i for i,s in enumerate(st)}
 def label(p):return tuple(sum(abs(x)==a for x in p) for a in range(4))
 B=[[F(0) for s in st] for p in pts]
 for row,p in enumerate(pts):
  B[row][orbit[label(p)]]-=sum(F(2*n,t*t) for t in range(1,J+1))
  for axis in range(n):
   for t in range(1,J+1):
    for sign in [-1,1]:
     dest=list(p);dest[axis]+=sign*t
     if max(map(abs,dest))<=L:B[row][orbit[label(dest)]]+=F(1,t*t)
 assert all(B[r]==A[orbit[label(p)]] for r,p in enumerate(pts))
 observed=[sum(label(p)==s for p in pts) for s in st];assert observed==w;assert sum(w)==7**n
 return dict(n=2,full_points=len(pts),orbit_variables=len(st),all_exact_generator_rows_match=True,all_exact_orbit_weights_match=True,total_weight=sum(w),full_obstacle_count=sum(max(map(abs,p))<=1 for p in pts),weighted_obstacle_count=sum(wi*lo for wi,lo in zip(w,lower)))

def solve(n,profile=False):
 st,w,A,active,lower,layer=make(n);Ar=sp.Matrix([[sp.Rational(v.numerator,v.denominator) for v in A[r]] for r in active])
 if profile:
  P=sp.zeros(len(st),4)
  for k,l in enumerate(layer):P[k,l]=1
  Ar=Ar*P;c=[sum(wi for wi,l in zip(w,layer) if l==a)/3**n for a in range(4)];lb=[1,1,0,0]
 else:c=[wi/3**n for wi in w];lb=lower
 arr=np.array(Ar,float);c=np.array(c);lb=np.array(lb,float)
 res=linprog(c,A_ub=-arr,b_ub=np.zeros(len(active)),bounds=list(zip(lb,[None]*len(lb))),method='highs',options={'time_limit':20})
 out=dict(n=n,profile=profile,variables=len(c),constraints=len(active),status=int(res.status),message=res.message,success=bool(res.success))
 if not res.success:return out,None
 x=res.x;beta=-res.ineqlin.marginals;gamma=res.lower.marginals
 capacity=arr.T@beta+gamma
 out.update(objective=float(res.fun),K=x.tolist(),generator_nonorigin=(arr@x).tolist(),internal_positive_generator_count=int(np.sum(arr@x>1e-8)),primal_obstacle_violation=float(max(0,np.max(lb-x))),primal_generator_violation=float(max(0,np.max(-arr@x))),dual_beta=beta.tolist(),dual_gamma=gamma.tolist(),dual_objective=float(lb@gamma),duality_gap=float(res.fun-lb@gamma),dual_stationarity_max_residual=float(np.max(np.abs(capacity-c))),dual_sign_violation=float(max(0,-np.min(beta),-np.min(gamma))),max_abs_primal=float(np.max(np.abs(x))),max_abs_dual=float(max(np.max(np.abs(beta)),np.max(np.abs(gamma)))),orbit_states=st,orbit_weights=w,lower=lb.tolist(),radius_layer=layer)
 return out,(Ar,c,lb,x)

def exact_candidate(n,profile,cache):
 Ar,c,lb,x=cache;d=len(x);rows=[];rhs=[]
 for k in range(d):
  if abs(x[k]-lb[k])<1e-7:
   row=[0]*d;row[k]=1;rows.append(row);rhs.append(sp.Rational(str(lb[k])))
 for k,v in enumerate(np.array(Ar,float)@x):
  if abs(v)<1e-7:rows.append(list(Ar.row(k)));rhs.append(sp.Rational(0))
 sol=sp.linsolve((sp.Matrix(rows),sp.Matrix(rhs)))
 values=list(next(iter(sol)))
 if any(v.free_symbols for v in values):return dict(status='active equations underdetermined')
 assert all(v>=sp.Rational(str(l)) for v,l in zip(values,lb));g=Ar*sp.Matrix(values);assert all(v>=0 for v in g)
 st,w,A,active,lower,layer=make(n)
 costs=[F(sum(wi for wi,l in zip(w,layer) if l==a),3**n) for a in range(4)] if profile else [F(wi,3**n) for wi in w]
 objective=sum(sp.Rational(v.numerator,v.denominator)*z for v,z in zip(costs,values))
 origin=st.index((n,0,0,0))
 fullvalues=[values[l] for l in layer] if profile else values
 origin_generator=sum(sp.Rational(v.numerator,v.denominator)*z for v,z in zip(A[origin],fullvalues))
 return dict(origin_generator_exact=str(origin_generator),weighted_sum_exact=str(objective*3**n),status='exact_rational_primal_feasible',n=n,profile=profile,values=[str(v) for v in values],objective_exact=str(objective),objective_float=float(objective),all_nonorigin_generator_nonnegative=True,all_obstacle_bounds_satisfied=True,positive_generator_rows=[k for k,v in enumerate(g) if v>0],generator_exact=[str(v) for v in g],max_denominator_digits=max(len(str(sp.denom(v))) for v in values),max_difference_from_float=float(max(abs(float(v)-z) for v,z in zip(values,x))),not_claimed='Primal certificate alone does not prove optimality or strict gain against profile optimum.')

def main():
 audit=brute_check();records=[];exact=[]
 for n in [2,3,4,6,8]:
  if time.monotonic()-START>45:break
  full,cf=solve(n);profile,cp=solve(n,True)
  records.append(dict(n=n,full=full,profile=profile,gain=(profile['objective']-full['objective']) if full['success'] and profile['success'] else None,relative_gain=(profile['objective']-full['objective'])/profile['objective'] if full['success'] and profile['success'] else None))
  if n==2 and full['success']:
   exact=[exact_candidate(n,False,cf)]
   if profile['success']:exact.append(exact_candidate(n,True,cp))
 result=dict(model=dict(L=L,J=J,dimensions=[2,3,4,6,8],generator='sum_j sum_t=1..7 t^-2(K(x+t ej)+K(x-t ej)-2K(x))',boundary='K=0 outside [-3,3]^n',obstacle='K>=1 when max|xj|<=1',constraints='K>=0 all finite states; AK>=0 at all x!=0; origin free generator',objective='sum all lattice K / 3^n',seed=None),exact_n2_brute_audit=audit,records=records,exact_primal_candidates=exact,resource=dict(max_orbit_variables=165,max_generator_constraints=164,matrix_storage_estimate_bytes=165*165*8,full_grid_enumerated_only_n2=True),versions=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,sympy=sp.__version__),command=f'{sys.executable} {Path(__file__)}',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.monotonic()-START,scope='Finite lattice with J=7 jumps and zero Dirichlet exterior; not continuous stable generator. Floating optima are candidate evidence; exact candidates only certify listed rational primal feasibility.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
 for r in records:print(r['n'],r['full'].get('objective'),r['profile'].get('objective'),r['relative_gain'])
 print('seconds',result['elapsed_seconds']);print('rational',[(e['profile'],e['status'],e.get('objective_float')) for e in exact])
if __name__=='__main__':main()
