"""Independent n=2 full-lattice rational primal audit; never solves an LP."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json, sys, hashlib
SOURCE=Path(__file__).with_name('r555_kernel_lp.json')
data=json.loads(SOURCE.read_text())
record=next(r['full'] for r in data['records'] if r['n']==2)
cert=next(c for c in data['exact_primal_candidates'] if c['n']==2 and not c['profile'])
assert data['model']['L']==3 and data['model']['J']==7
values=list(map(F,cert['values']))
# Orbit labels only decode the supplied candidate; all constraints below are
# evaluated by actual signed coordinate jumps on the original 49 lattice points.
labels=[tuple(s) for s in record['orbit_states']]
assert len(labels)==len(set(labels))==len(values)==10
bylabel=dict(zip(labels,values))
def label(p): return tuple(sum(abs(z)==a for z in p) for a in range(4))
box=list(product(range(-3,4),repeat=2))
assert set(map(label,box))==set(labels)
K={p:bylabel[label(p)] for p in box}
zero=F(0)
def kval(p): return K.get(tuple(p),zero)
def gen(p):
    ans=zero
    for axis in range(2):
        for t in range(1,8):
            for sign in (-1,1):
                q=list(p);q[axis]+=sign*t
                ans+=(kval(q)-kval(p))*F(1,t*t)
    return ans
AK={p:gen(p) for p in box}
cube=[p for p in box if max(map(abs,p))<=1]
assert len(box)==49 and len(cube)==9
assert all(k>=0 for k in K.values())
assert all(K[p]>=1 for p in cube)
assert all(v>=0 for p,v in AK.items() if p!=(0,0))
assert AK[(0,0)]==F(cert['origin_generator_exact'])<0
mass=sum(K.values(),zero)
objective=mass/F(9)
assert mass==F(cert['weighted_sum_exact'])
assert objective==F(cert['objective_exact'])
# Cross-check every supplied compressed generator value using full point rows.
active=[s for s in labels if s!=(2,0,0,0)]
reported_gen=dict(zip(active,map(F,cert['generator_exact'])))
assert all(v==reported_gen[label(p)] for p,v in AK.items() if p!=(0,0))
actual_positive_labels={label(p) for p,v in AK.items() if p!=(0,0) and v>0}
assert actual_positive_labels=={active[i] for i in cert['positive_generator_rows']}
positive_internal=[p for p,v in AK.items() if p!=(0,0) and v>0]
assert all(K[p]==0 for p in positive_internal)
# Entire possible generator support: K-support plus every reverse jump source.
# Beyond this finite set, every term in A K vanishes identically.
support=set(box)
for p in box:
    for axis in range(2):
        for t in range(1,8):
            for sign in (-1,1):
                q=list(p);q[axis]+=sign*t;support.add(tuple(q))
exterior={p:gen(p) for p in support if p not in K}
assert all(v>=0 for v in exterior.values())
a=-AK[(0,0)]
beta_internal=sum((v for p,v in AK.items() if p!=(0,0)),zero)
beta_external=sum(exterior.values(),zero)
assert beta_internal+beta_external==a
assert all(kval(p)==0 for p,v in exterior.items() if v>0)
# Check reported multiplicities by counting original signed grid, not formula.
assert [sum(label(p)==s for p in box) for s in labels]==record['orbit_weights']
result={
 'status':'exact_rational_primal_feasible_independently_verified',
 'dimension':2,'grid_points':49,'obstacle_points':9,'J':7,
 'mass_exact':str(mass),'objective_mass_over_9_exact':str(objective),
 'origin_AK_exact':str(-a),'beta_total_exact':str(a),
 'beta_internal_mass_exact':str(beta_internal),'beta_external_mass_exact':str(beta_external),
 'positive_internal_points':len(positive_internal),
 'positive_internal_orbits':len(actual_positive_labels),
 'positive_beta_only_where_K_zero':True,
 'all_original_reported_rational_values_match':True,
 'constraint_error':'0 (exact Fraction arithmetic; no tolerance)',
 'optimality_certified':False,
 'python':sys.version,'command':f'{sys.executable} {Path(__file__)}',
 'source_json_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
 'scope':'Only n=2 lattice, coordinate jumps t=1,...,7 with rate t^-2, zero exterior. No continuous stable or dimension extrapolation.'
}
Path(__file__).with_name('r555_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# R555 n=2 独立有理 primal 核验','',
'已用 Python Fraction 从原证书读入有理候选，显式重建 [-3,3]^2 的全部49个带符号格点；重新逐点逐轴累加 t=1,…,7、率 1/t² 的跳跃，没有调用原组装函数、LP 求解器或新维度计算。','',
'49点 K≥0、9个目标立方体点 K≥1、48个非原点 AK≥0 均精确成立。全域质量直接相加，与原证书 weighted_sum_exact 及目标 objective_exact 完全一致；逐点 AK 与原证书所有压缩行精确一致。误差为0（exact rational），无需浮点容差。','',
'盒外 K=0，故 AK 是非负邻值的正率和；远离有限跳跃可达集时 AK=0。脚本另外枚举全部可能可达盒外源点，检查非负并验证整个 Z² 的生成元总和为0，即 β(Z²)=a。','',
'盒内正 β=AK 出现在5个 orbit、'+str(len(positive_internal))+'个点，全部位于零集 {K=0}；盒外正 β 同样只在 K=0。因此正 β 仅在 K 的零集成立，与原脚本5个内部正生成行一致。这里 β 指 AK+aδ₀ 的非负测度，不是 LP 对偶乘子 dual_beta。','',
'只认证给定有理 primal 可行，不认证最优、不认证相对 profile 的严格收益，不外推连续稳定生成元或其他维数。','',
'运行命令：`'+result['command']+'`','',
'Python版本：`'+sys.version.replace('\n',' ')+'`','',
'最小结果：','```json',json.dumps(result,ensure_ascii=False,indent=2),'```','']
Path('/tmp/r555_certificate.md').write_text('\n'.join(lines))
print(json.dumps(result,ensure_ascii=False,indent=2))
