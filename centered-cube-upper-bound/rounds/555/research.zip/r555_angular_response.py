"""Bounded Riesz angular response: Gamma quadrature, no vertex enumeration except n9 audit."""
from pathlib import Path
import numpy as np
import scipy
from scipy.special import roots_genlaguerre,gammaln,logsumexp
import json,time,sys,hashlib,itertools
START=time.monotonic();SEED=5552026;DIMS=[9,33,129];COUNT=64;ORDERS=[64,128]

def gamma_rule(n,order):
 p=(n-1)/2;z,w=roots_genlaguerre(order,p-1)
 with np.errstate(divide='ignore'):lw=np.log(w)-gammaln(p)
 assert np.isfinite(z).all() and np.all(z>0)
 return z,lw,float(np.exp(logsumexp(lw)))

def responses(n,ys,order):
 z,lw,norm=gamma_rule(n,order);p=(n-1)/2;values=[]
 for y in ys:
  denom=n+float(y@y);a=2*z[:,None]*y[None,:]/denom
  lc=(np.logaddexp(a,-a)-np.log(2)).sum(1)
  values.append(p*np.log(n/denom)+logsumexp(lw+lc))
 return np.array(values),norm

def direct(n,y):
 # Independent direct formula, used only n9 fixed points.
 vertices=np.array(list(itertools.product([-1.,1.],repeat=n)))
 dist=np.sum((vertices-y)**2,axis=1);p=(n-1)/2
 return float(logsumexp(p*(np.log(n)-np.log(dist)))-n*np.log(2))

def main():
 records=[];audits=[]
 for n in DIMS:
  rng=np.random.default_rng(SEED+n);dirs=rng.normal(size=(COUNT,n));dirs/=np.linalg.norm(dirs,axis=1)[:,None]
  for name,r in [('nquarter_c1',n**.25),('nquarter_c2',2*n**.25),('sqrt_n_over3',np.sqrt(n/3)),('sqrt_n',np.sqrt(n)),('two_sqrt_n',2*np.sqrt(n))]:
   ys=r*dirs;logs={};norms={}
   for order in ORDERS:logs[order],norms[order]=responses(n,ys,order)
   diff=np.abs(logs[128]-logs[64]);stable=diff<=1e-6
   s=np.exp(logs[128]);outside=np.max(np.abs(ys),axis=1)>1;rel=np.abs(np.expm1(logs[64]-logs[128]));result=dict(n=n,radius_label=name,radius=float(r),seed=SEED+n,count=COUNT,directions=dirs.tolist(),logS_64=logs[64].tolist(),logS_128=logs[128].tolist(),S_128=s.tolist(),gamma_rule_normalization=norms,consistency=dict(log_difference_max=float(diff.max()),relative_difference_max=float(rel.max()),relative_difference_median=float(np.median(rel)),stable_count_1e6_log=int(stable.sum()),unstable_indices=np.flatnonzero(~stable).tolist()),outside_cube=outside.tolist(),linf=np.max(np.abs(ys),axis=1).tolist(),proportions=dict(below_075=float(np.mean(s<.75)),below_1=float(np.mean(s<1)),outside_cube=float(outside.mean()),outside_and_below_075=float(np.mean(outside&(s<.75)))),counts=dict(below_075=int(np.sum(s<.75)),below_1=int(np.sum(s<1)),outside_cube=int(outside.sum()),outside_and_below_075=int(np.sum(outside&(s<.75)))),quantiles={str(q):float(np.quantile(s,q)) for q in [0,.1,.25,.5,.75,.9,1]},threshold_disagreements={str(t):int(np.sum((logs[64]<np.log(t))!=(logs[128]<np.log(t)))) for t in [.75,1.]},trust='quadrature_order_consistent_not_certified' if stable.all() else 'contains_unstable_quadrature_do_not_treat_all_point_estimates_as_reliable')
   records.append(result)
   if n==9:
    for idx in [0,1,2]:
     exact=direct(n,ys[idx]);audits.append(dict(n=n,radius_label=name,direction_index=idx,direct_vertex_count=512,direct_logS=exact,gamma64_logS=float(logs[64][idx]),gamma128_logS=float(logs[128][idx]),relative_error_64=float(abs(np.expm1(logs[64][idx]-exact))),relative_error_128=float(abs(np.expm1(logs[128][idx]-exact)))))
 result=dict(model=dict(dimensions=DIMS,source='uniform cube vertices {-1,+1}^n',p='(n-1)/2',S='2^-n sum_v (n/|v-y|^2)^p',integral='(n/(n+|y|^2))^p E_Gamma(p,1) product_i cosh(2Z yi/(n+|y|^2))',directions='64 iid standard Gaussian vectors normalized to unit length per dimension; common directions across five radii',seed=SEED,orders=ORDERS),resource=dict(max_work_array_shape=[128,129],quadrature_evaluations=len(DIMS)*5*COUNT*len(ORDERS),direct_audits=15,working_memory_note='Per-point quadrature array <0.14 MiB; no high-dimensional vertex enumeration except 512 vertices in n9 audits.'),records=records,direct_audits=audits,versions=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__),command=f'{sys.executable} {Path(__file__)}',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.monotonic()-START,scope='Uniform spherical-angle finite Monte Carlo. Two quadrature orders are diagnostics, not interval or convergence certification. No radial occupation, absorption, full-Q finite-step or general dimension claim.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
 for r in records:print(r['n'],r['radius_label'],r['counts'],r['quantiles']['0.5'],r['consistency']['relative_difference_max'],r['trust'])
 print('audit_max',max(x['relative_error_128'] for x in audits),'seconds',result['elapsed_seconds'])
if __name__=='__main__':main()
