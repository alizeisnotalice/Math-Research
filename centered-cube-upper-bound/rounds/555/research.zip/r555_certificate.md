# R555 n=2 独立有理 primal 核验

已用 Python Fraction 从原证书读入有理候选，显式重建 [-3,3]^2 的全部49个带符号格点；重新逐点逐轴累加 t=1,…,7、率 1/t² 的跳跃，没有调用原组装函数、LP 求解器或新维度计算。

49点 K≥0、9个目标立方体点 K≥1、48个非原点 AK≥0 均精确成立。全域质量直接相加，与原证书 weighted_sum_exact 及目标 objective_exact 完全一致；逐点 AK 与原证书所有压缩行精确一致。误差为0（exact rational），无需浮点容差。

盒外 K=0，故 AK 是非负邻值的正率和；远离有限跳跃可达集时 AK=0。脚本另外枚举全部可能可达盒外源点，检查非负并验证整个 Z² 的生成元总和为0，即 β(Z²)=a。

盒内正 β=AK 出现在5个 orbit、28个点，全部位于零集 {K=0}；盒外正 β 同样只在 K=0。因此正 β 仅在 K 的零集成立，与原脚本5个内部正生成行一致。这里 β 指 AK+aδ₀ 的非负测度，不是 LP 对偶乘子 dual_beta。

只认证给定有理 primal 可行，不认证最优、不认证相对 profile 的严格收益，不外推连续稳定生成元或其他维数。

运行命令：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r555_certificate.py`

Python版本：`3.12.14 (main, Aug 25 2026, 13:50:33) [Clang 22.1.3 ]`

最小结果：
```json
{
  "status": "exact_rational_primal_feasible_independently_verified",
  "dimension": 2,
  "grid_points": 49,
  "obstacle_points": 9,
  "J": 7,
  "mass_exact": "3629934670352852/128916471324375",
  "objective_mass_over_9_exact": "3629934670352852/1160248241919375",
  "origin_AK_exact": "-713837562296425499699/11370432770809875000",
  "beta_total_exact": "713837562296425499699/11370432770809875000",
  "beta_internal_mass_exact": "1641335060894331757/37127943741420000",
  "beta_external_mass_exact": "844714799590145596471/45481731083239500000",
  "positive_internal_points": 28,
  "positive_internal_orbits": 5,
  "positive_beta_only_where_K_zero": true,
  "all_original_reported_rational_values_match": true,
  "constraint_error": "0 (exact Fraction arithmetic; no tolerance)",
  "optimality_certified": false,
  "python": "3.12.14 (main, Aug 25 2026, 13:50:33) [Clang 22.1.3 ]",
  "command": "/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r555_certificate.py",
  "source_json_sha256": "a6da4ff73bd6910509ba1df798290156125f8a7b5c67cfd6cb8a88eb244c9e01",
  "scope": "Only n=2 lattice, coordinate jumps t=1,...,7 with rate t^-2, zero exterior. No continuous stable or dimension extrapolation."
}
```
