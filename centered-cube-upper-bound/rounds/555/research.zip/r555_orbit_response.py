"""Exact finite vertex-response certificates for the Riesz limit only."""
from fractions import Fraction as F
from math import comb,isqrt
from pathlib import Path
import json,sys,hashlib,time
sys.set_int_max_str_digits(100000)  # bounded exact certificates exceed default display limit
start=time.monotonic();rows=[]
for n in [9,17,33,65,129]:
    for k in sorted({1,isqrt(n),n}):
        for t in [F(5,4),F(3,2),F(2)]:
            # y=(t,...,t,0,...,0), k nonzero coordinates. Sum all vertex signs.
            distances=[F(n)+k*t*t-2*t*(k-2*j) for j in range(k+1)]
            assert min(distances)>0
            v=sum((F(comb(k,j),2**k)*(F(n)/d)**((n-1)//2) for j,d in enumerate(distances)),F(0))
            rows.append(dict(n=n,k=k,t=str(t),response_float=float(v),strict_below_one=v<1,finite_lambda_upper_float=float(F(4,3)*v),finite_lambda_upper_strict_below_one=F(4,3)*v<1,numerator=str(v.numerator),denominator=str(v.denominator)))
result=dict(command=f'{sys.executable} {__file__}',python=sys.version,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),formula='sum_j binom(k,j)/2^k * (n/(n+k*t*t-2*t*(k-2*j)))^((n-1)/2)',initial_run='Stopped at Python 4300-digit serialization limit; rerun with 100000-digit limit, no numerical approximation introduced.',scope='Exact rational comparisons at listed odd n for lambda->0 isotropic Cauchy resolvent ratios. Not finite-lambda certification, not source volume/absorption, not finite-step cube majorization or weak-type bound.',rows=rows,elapsed_seconds=time.monotonic()-start)
Path(__file__).with_name('r555_orbit_response.json').write_text(json.dumps(result,indent=2))
for z in rows:
    print(z['n'],z['k'],z['t'],f"{z['response_float']:.8g}",z['strict_below_one'])
print('elapsed',result['elapsed_seconds'])
