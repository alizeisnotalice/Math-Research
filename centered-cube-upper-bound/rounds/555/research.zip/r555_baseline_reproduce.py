"""Reproduce the saved scalar baseline only; no generator admissibility claim."""
from pathlib import Path
import json, sys, hashlib
import sympy as s
n,a,q=s.symbols('n a q', positive=True)
# q=R**(a-n). For log F, d/d(log R) is the following expression.
d=a+(n-a)*q/(q-1)
assert s.simplify(d-(a-n*q)/(1-q))==0
assert s.simplify(d.subs(q,a/n))==0
minimum=(n/a)**(n/(n-a))
old=json.loads(Path(__file__).with_name('r555_kernel_baseline.json').read_text())
rows=[]
for row in old['rows']:
    value=float(s.N(minimum.subs({n:row['n'],a:row['a']}),40))
    error=abs(value-row['minimum'])
    assert error<=1e-12*max(1,abs(value))
    rows.append(dict(n=row['n'],a=row['a'],reproduced=value,stored_float_difference=error))
result=dict(command=f'{sys.executable} {__file__}',python=sys.version,sympy=s.__version__,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),exact_log_derivative_identity=True,exact_stationarity=True,rows=rows,scope='Scalar mass expression only. Float comparisons are reproduction checks, not rigorous interval bounds or generator certificates.')
Path(__file__).with_name('r555_baseline_reproduce.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,ensure_ascii=False))
