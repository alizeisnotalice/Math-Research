# R555 原仓库接口审核：二维比较核—障碍—全尺度

审查固定提交 [`72c022ba09032b522c878cca2f9b6c68217d77ea`](https://github.com/CoolRmal/centered-maximal-constant/tree/72c022ba09032b522c878cca2f9b6c68217d77ea)。本稿是指定源码接口及数学迁移条件的阅读审核，**未运行 Lean/lake build，未认证整库依赖或无公理性，不以README/源码注释的自称替代编译或独立重证**。

先读指定三文件，随后仅追踪实际接入它们所需的 Basic/Statement入口、JumpGenerator、BoundedFunctional、障碍Complementarity有关结论，以及 Transfer/Commutation、Scaling、Cauchy/Assembly、LooseKernel、Generator、Representation 的相关接口/片段；没有重审所有分析证明。为定位最终调用另读Solution入口。所有网络读取固定上述提交，没有改研究仓库。网页工具对GitHub树URL访问失败，实际改用本机Python urllib读取固定提交的raw原文件。

## 1. 比较归约：半径、维数和核正部

[`Comparison/Reduction.lean`](https://github.com/CoolRmal/centered-maximal-constant/blob/72c022ba09032b522c878cca2f9b6c68217d77ea/CenteredMaximal/Comparison/Reduction.lean) 中的所有核对象类型是 `Fin 2 → ℝ`；Pi范数是∞范数，因此closedBall是**半径r、侧长2r**的轴平行cube，体积(2r)^2。与本项目侧长R的约定换算为r=R/2。

源码定义 K_s(z)=s^(−2)K(z/s)，而核极大函数实际使用 `ENNReal.ofReal K_s`，即非负部分K_s^+乘|f|的非负积分后取所有s>0上确界。比较结论是：

    K(z)≥1 对全部 ||z||∞≤1
       ⇒ M_cube f≤(1/4)M_K f，
    M_K弱(1,1)常数≤m
       ⇒ c_2≤m/4。

纯比较本身没有要求K处处非负、偶、紧支撑或可积；但不能因这一点把后续全尺度质量常数∫K用于带负部K。后续障碍/恢复接口明确另要求非负可积核。单位目标cube的体积4是真实比较因子，不可把r误当侧长后遗漏它。`IsKernelWeakTypeBound` 的最终对象是任意实值可积f与所有扩展非负水平，作用于|f|，不是仅限非负光滑源。

## 2. 障碍接口：二维、0<α<2和实际输出

[`Obstacle/Main.lean`](https://github.com/CoolRmal/centered-maximal-constant/blob/72c022ba09032b522c878cca2f9b6c68217d77ea/CenteredMaximal/Obstacle/Main.lean) 的 `exists_obstacle_solution` 使用二维坐标稳定生成元。其准确定义见 [`Analysis/JumpGenerator.lean#L57-L67`](https://github.com/CoolRmal/centered-maximal-constant/blob/72c022ba09032b522c878cca2f9b6c68217d77ea/CenteredMaximal/Analysis/JumpGenerator.lean#L57-L67)：

    A_αφ(x)=Σ_{j=1}²∫_R
      [φ(x+t e_j)+φ(x−t e_j)−2φ(x)]|t|^(−1−α)dt。

代码未加入常用的稳定过程归一化常数。它是**坐标方向**的非局部生成元，不是各向同性分数Laplace、通常Laplace或任意生成元；迁移时必须保留定义与弱方程的符号/归一。测试类是光滑紧支撑函数。

输入条件为0<α<2、κ>0、可测f≥0、全空间上f≤某个有限常数、f在某个有限∞范数cube外为0。参数名`Mf`在此只是一个给定上界常数，**不是**极大函数Mf。输入无需对称或径向。

输出u、σ具备：u可测、u≥0 a.e.、u∈L1且跳跃能量有限；σ可测、处处0≤σ≤κ且σ∈L1；对全部测试φ，

    ∫u A_αφ=∫(σ−f)φ；
    σ=κ a.e. 于{u>0}；
    ∫σ=∫f，  |{u>0}|≤(∫f)/κ。

这些是接口**输出**，不是调用者额外假定的一份接收区域；不过其分析构造依赖Complementarity等下层证明，本次没有逐行重新认证。使用比较时Assembly用u_+=max(u,0)取得处处非负版本，弱式和正集均不变，不能默将“a.e.非负”当作逐点非负来卷积正测度。

## 3. 从核生成元到同一个异常集：强假设在哪里

实际连接由 [`Transfer/Commutation.lean#L369-L452`](https://github.com/CoolRmal/centered-maximal-constant/blob/72c022ba09032b522c878cca2f9b6c68217d77ea/CenteredMaximal/Transfer/Commutation.lean#L369-L452) 与 [`Cauchy/Assembly.lean#L193-L277`](https://github.com/CoolRmal/centered-maximal-constant/blob/72c022ba09032b522c878cca2f9b6c68217d77ea/CenteredMaximal/Cauchy/Assembly.lean#L193-L277) 给出。其核条件不止“AK离原点非负”：

- K处处非负、K∈L1、K(−z)=K(z)、K有紧支撑。
- 存在**非负有限Borel测度**β和原点系数a（Assembly要求a≥0），对所有光滑紧支撑φ有完整弱身份

      ∫K A_αφ=∫φ dβ−aφ(0)。                    (1)

  `Measure`类型本身为正测度；“有限”是独立类型条件。仅知道离原点的某个经典点态AK≥0，不能省略原点奇性、可能的其他奇异项、β的全空间有限性与弱式(1)。

在障碍弱式及上述条件下，Commutation得到a.e.的卷积身份

    K*f=K*σ−β*u+a u，

故在u=0处 `K*f≤κ∫K`。正性用于−β*u的符号；偶性用于配对交换；紧支撑确保K卷积测试函数仍为紧支撑测试函数；L1与有限β确保交换积分/分布到a.e.身份的可积性。当前源码没有证明可以删去这些条件。比较器在u=0时本身无需a的正号，但Assembly的缩放打包保留a≥0。

[`Transfer/Scaling.lean#L117-L134`](https://github.com/CoolRmal/centered-maximal-constant/blob/72c022ba09032b522c878cca2f9b6c68217d77ea/CenteredMaximal/Transfer/Scaling.lean#L117-L134) 精确保持

    β_s=s^(−α)(z↦sz)_#β，  a_s=s^(−α)a。

K_s的L1质量仍为m_K=∫K。取κ=λ/m_K，并对所有s复用**同一障碍u、同一Ω={u_+>0}**，遂有

    |Ω|≤m_K∫f/λ；
    ∀s>0，对a.e.x∉Ω，K_s*f(x)≤λ。              (2)

每个s的零集允许不同；Ω本身不允许随s改变。Assembly的这个结论在该文件仍以(1)为假设，不是仅由核质量推得的任意核定理。

## 4. AllScales：准确的全尺度与一般L1恢复

[`Transfer/AllScales.lean`](https://github.com/CoolRmal/centered-maximal-constant/blob/72c022ba09032b522c878cca2f9b6c68217d77ea/CenteredMaximal/Transfer/AllScales.lean) 的主定理 `isKernelWeakTypeBound_of_pointwise` 显式假设K≥0、K∈L1，并假设对**每个**非负有界紧支撑可测f及每个λ>0存在满足(2)的共同可测Ω。它不自行从“AK≥0”构造Ω，也不允许各尺度各有一个仅满足同样体积帽的不同Ω。

恢复方式没有额外常数：可积核的膨胀族在L1中随正尺度连续（源码从右逼近已足够）；有界f下卷积随尺度变化由 `||f||∞ ||K_r−K_s||1` 控制，且对x一致。所有正尺度的上确界因此等于正有理尺度的上确界，可一次删去可数零集。再以同时截断空间和高度的非负函数逐点单调逼近|f|，Tonelli/单调收敛交换积分与上确界，恢复任意可积实值f；0和∞水平单独处理。

所以在(2)真实可用时，全尺度恢复不是遗漏费用的接口。但它的主要强条件是同一Ω与核L1；不能用“每个尺度有弱型界”替代共同Ω。本次阅读没有发现该恢复暗含f的对称性、根场正则性或独立尺度选择，但未进行Lean实际编译。

## 5. 二维具体核、Representation填补的内容及最终调用

[`Cauchy/LooseKernel.lean#L43-L65`](https://github.com/CoolRmal/centered-maximal-constant/blob/72c022ba09032b522c878cca2f9b6c68217d77ea/CenteredMaximal/Cauchy/LooseKernel.lean#L43-L65) 使用ρ(z)=|z_1|+|z_2|、R=3797/2000、ε=159411/200000，核为

    K(z)=(R/ρ−1)_+/(R−1)−ε(1−ρ)_+²。

其主控目标是单位**diamond**ρ≤1，不是单位cube。原点的Lean实数除零版本会得到负值，Assembly另定义compKernel(0)=1，其他点保持K；这是单点修改，不改变L1卷积、质量或弱生成元配对，却确保所需的处处非负及原点domination。当前全链作用于L1来源，不能仅凭这一a.e.版本处理就声称对任意原子来源也已完成同一障碍恢复。

[`Cauchy/Generator.lean#L259-L323`](https://github.com/CoolRmal/centered-maximal-constant/blob/72c022ba09032b522c878cca2f9b6c68217d77ea/CenteredMaximal/Cauchy/Generator.lean#L259-L323) 的直接点态非负结论要求两个坐标均非零，随后得到a.e.非负；不是已经覆盖全部奇异轴和原点的分布结论。关键补全位于 [`Cauchy/Representation.lean#L480-L578`](https://github.com/CoolRmal/centered-maximal-constant/blob/72c022ba09032b522c878cca2f9b6c68217d77ea/CenteredMaximal/Cauchy/Representation.lean#L480-L578)：源码先建立完整测试配对表示，确认genDensity非负，再用光滑尺度截断及生成元衰减证明其全质量有限，定义正有限genMeasure，最后以 `genMeasure_representation` 填入Assembly的hgen。`weakTypeConstant_two_le_cost`、`weakTypeConstant_two_le_ratio`与`weakTypeConstant_two_le`在源码接口上不再有外置hgen假设。Solution的二维cube上界直接调用最后一个定理。因此不能把Assembly的条件形式误报成仓库最终尚未解除该假设；同时本次没有独立重证Representation的全部下层计算、Fubini和分布奇性分析。

最后的几何变换为 `L(u,v)=(u+v,u−v)`，detL=−2，将diamondρ≤1变为∞范数单位cube。于是核弱界常数m_K在变换后为2m_K，再除cube体积4得到

    c_2≤m_K/2=R²/(R−1)−ε/6
       =2787954611/718800000≈3.878623554535337<3.879。

diamond的体积2与此一致。不能直接将diamond核代入第1节的cube主控假设；坐标变换不可省。更不能将此线性等同推广至n≥3：一般ℓ1球与cube并非线性同形。这里也没有维数n的核质量、有限正生成测度或障碍理论证明。

## 6. 本项目可迁移的合同与准确缺口

可迁移的是完整机制：对所需维数/生成元，先证明同一障碍分解及L1/质量输出；再构造非负偶可积核，主控真实目标体，并严格建立正有限测度减原点的弱生成元表示；最后使用正确的同尺度缩放、同一异常集和L1恢复。一般维度的尺度连续与有理化本身可按同样证明重做，但不是该Fin2源码已提供的全维定理。

当前原中间合同所保留的最外cube根关系、Cauchy–Schwarz能量、共同θ或signed面身份，不自动给出这份障碍核证书；也不能以AK在普通点的形式计算代替完整弱分布表示。一个全维幂核即使质量优化给出某种baseline，若未核其对所选生成元的完整(1)、正有限β及目标cube主控，就尚不能使用此源的弱型常数结论。二维具体数值不提供原目标的n^(1/2+o(1))费用。

## 7. 实际读取与计算记录

本机urllib读取三指定raw文件并与 `/tmp/r555_external_tree.json` 的Git blob SHA核对，全部相符：Reduction=`9e5ed81ee16ec82e5f5bb68d13fff9b406fe5c41`；Obstacle/Main=`167d7196c95ffa90275b31c9c6e59ef826d61a1b`；AllScales=`7eff4a90b16abbf53b79eaee32e2b35b0a0d7bfa`。这验证所读字节对应固定tree，不是Lean证明认证。

实际以 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`（Python3.12.14、SymPy1.14.0）核detL=−2与上述核质量/diamond体积系数，精确输出cost=`2787954611/718800000`、kernel_mass=`2787954611/359400000`。未安装工具链、未编译、未运行README的构建/徽章验证；也未核验其欧氏球分支。结论限于本文明确读取的源码接口与迁移条件。指定任务完成后停止。

## 8. 追加：主代理全维条件桥的量词与常数核验

已读取 `/tmp/r555_all_dimension_bridge.tex`，仅审条件推论，未认证其全维障碍存在性或生成元交换假设。所写桥成立：K≥1_[−1,1]^n a.e.与非负性给B=∫K≥2^n>0；对L1来源，该核主控在每个固定x,s的卷积中成立，不要求重新强化为逐点核主控。障碍u是对固定f、κ一次选择；随后全部s都使用同一Ω={u>0}。

假设的卷积交换及缩放式给

    K_s*f=K_s*σ+s^(−α)au−s^(−α)((D_s)_#β)*u。

K_s、f、σ、u均L1，β有限，所以这些卷积项均L1；分布等式可传成a.e.等式，负测度卷积项的符号正确。不存在按尺度重选u或Ω的费用。对有界f，L1核伸缩连续使各x的尺度卷积连续；删去正有理尺度的可数零集后能控制全部尺度。故核极大坏集体积≤||f||1/κ。

cube平均的精确系数是2^(−n)，κ取2^nλ/B后得到weak1常数B/2^n，未丢半径/侧长因子。正截断f_j单调并增至f，不需要Ω_j嵌套；对一般实值L1再应用于|f|即可。若“生成元”未默认线性，表述时可显式补“线性”，因为卷积与弱方程展开按此含义使用。

这一通过仅证明全部未证输入到完整一般L1结论的桥；核紧支撑在此没有被免费删除，而是以更强的“卷积交换确实合法”为明确输入替代。全维障碍性质、完整正有限生成测度/交换、以及B/2^n的根阶费用仍均未由二维源码或本次审计取得。桥没有把条件性回代当作新付款。附录核验完成后停止。
