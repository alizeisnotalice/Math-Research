from fractions import Fraction as F
from itertools import product
from math import isqrt
counts = [0,0,0,0,0]
# Positive measures with rational square roots and square total masses.
vec = [(a,b) for a,b in product(range(13),repeat=2) if a*a+b*b>0 and isqrt(a*a+b*b)**2==a*a+b*b]
for a,b in vec:
  D=F(a*a+b*b); sd=isqrt(int(D))
  for c,d in vec:
    if c>a or d>b: continue
    E=F(c*c+d*d); se=isqrt(int(E))
    H=(F(a,sd)-F(c,se))**2+(F(b,sd)-F(d,se))**2
    raw=F((a-c)**2+(b-d)**2)
    assert raw == (sd-se)**2+sd*se*H
    assert raw <= D-E
    assert D*H <= 2*(D-E)
    assert H <= 2*(1-F(se,sd))
    counts[0]+=1
# Threshold increment bound, including equalities and f=0.
for old,ratio,f in product([F(1,7),F(1),F(5)], [F(1),F(17,16),F(2),F(5)], [F(0),F(1,7),F(1),F(17,16),F(2),F(5),F(25)]):
  new=old*ratio
  delta=(min(f,new)-min(f,old))/f if f else F(0)
  assert 0<=delta<=1-1/ratio
  counts[1]+=1
# Finite incidence diagnostics, prescribed nested endpoint sets, not a native history fixture.
Q=[{0,1},{1,2},{0,2}]
for fv,s,ratio in product([(F(1),F(2),F(4)),(F(3),F(1),F(2))], [F(0),F(1,10),F(1),F(4)], [F(17,16),F(2),F(3)]):
  m=[sum(fv[y] for y in q) for q in Q]
  pi=[[fv[y]/m[a] if y in Q[a] else F(0) for y in range(3)] for a in range(3)]
  base={(0,1):F(1,2),(1,2):F(2,3),(2,0):F(3,4)}
  sets=[{0,1,2},{0,1,2},{1,2},{2},set()]
  gam=[{e:w for e,w in base.items() if set(e)<=A} for A in sets]
  occ=[]
  for g in gam:
    occ.append([sum(w*((F(1,m[a]) if y in Q[a] else 0)+(F(1,m[b]) if y in Q[b] else 0)) for (a,b),w in g.items()) for y in range(3)])
  T=[F(1,4)*ratio**i for i in range(len(sets))]
  bs={}
  B=deleted=surviving=F(0)
  for i in range(1,len(sets)-1):
    bs[i]=[(min(fv[y],T[i])-min(fv[y],T[i-1]))/fv[y]*max(F(0),1-s/occ[i][y]) if occ[i][y] else F(0) for y in range(3)]
    def cost(g):
      return sum(w*sum((pi[a][y]+pi[b][y])*bs[i][y] for y in range(3)) for (a,b),w in g.items())
    bi=cost(gam[i]); stay=cost(gam[i+1]); drop=bi-stay
    assert bi==sum(fv[y]*bs[i][y]*occ[i][y] for y in range(3))
    assert 0<=drop<=2*(1-1/ratio)*(sum(gam[i].values())-sum(gam[i+1].values()))
    B+=bi; deleted+=drop; surviving+=stay
  assert B==deleted+surviving
  assert deleted<=2*(1-1/ratio)*sum(base.values())
  # Future first-deletion representation, keeping the entire accumulated mark.
  lag=F(0)
  for j in range(2,len(sets)-1):
    removed={e:w for e,w in gam[j].items() if e not in gam[j+1]}
    for (a,b),w in removed.items():
      lag+=w*sum((pi[a][y]+pi[b][y])*sum(bs[i][y] for i in range(1,j)) for y in range(3))
  assert lag==surviving
  counts[2]+=1
# Last-k threshold window, exact rational increments with decreasing occupations.
for ratio,f,cut in product([F(17,16),F(9,8),F(2)], [F(1,8),F(1),F(3),F(20)], [F(0),F(1),F(3)]):
  ts=[F(1,4)*ratio**i for i in range(9)]
  ds=[F(10-i) for i in range(9)]
  bb=[F(0)]+[(min(f,ts[i])-min(f,ts[i-1]))/f*max(F(0),1-cut/ds[i]) for i in range(1,9)]
  for j in range(1,9):
    for k in range(1,j+1):
      late=sum(bb[max(1,j-k+1):j+1])
      early=sum(bb[1:max(1,j-k+1)])
      assert late<=1-ratio**(-k)
      assert early<=min(f,ts[j-k])/f
      counts[3]+=1
# Schedule-free density-tail split, nonuniform jumps and every possible death.
for ts,f,delta in product([[F(1,4),F(1,3),F(4),F(9)], [F(1),F(17,16),F(3),F(100)], [F(1,100),F(2),F(5),F(6)]], [F(1,10),F(1),F(3),F(5),F(9),F(100)], [F(1,64),F(1,8),F(1,2),F(1)]):
  for j in range(1,len(ts)):
    for aa in [[F(1)]*len(ts),[F(3,4),F(2,3),F(1,2),F(0)]]:
      late=early=whole=F(0)
      low=(1-delta)*ts[j]
      for i in range(1,j+1):
        full=max(F(0),min(f,ts[i])-min(f,ts[i-1]))
        tail=max(F(0),min(f,ts[i],ts[j])-max(ts[i-1],low))
        assert 0<=tail<=full
        whole+=aa[i]*full/f;late+=aa[i]*tail/f;early+=aa[i]*(full-tail)/f
      assert late<=delta
      assert early+late==whole
      counts[4]+=1
print('PASS stages:', *counts, 'total:',sum(counts))
