from fractions import Fraction as F
from decimal import Decimal, localcontext
from itertools import product
from math import isqrt
counts={'atom_certificate':0,'sharp_nested_laws':0,'endpoint_source_laws':0}
# Phase 1: exact squared certificate sqrt(a*b)>=b for all 0<=b<=a.
for den,a_num,b_num in product((1,2,3,7),range(8),range(8)):
    a,b=F(a_num,den),F(b_num,den)
    if b>a: continue
    assert a*b>=b*b
    counts['atom_certificate']+=1
# Phase 2: nested restriction laws with square masses, including final zero.
# Affinity numerator is exactly the retained mass, so no irrational arithmetic.
for k,scale in product(range(1,13),(F(1),F(1,4),F(9,4))):
    root_scale=F(isqrt(scale.numerator),isqrt(scale.denominator))
    states=[]
    for j in range(k+1):
        states.append([F(2*l-1)*scale if l<=k-j else F(0) for l in range(1,k+1)])
    spent=F(0)
    for i in range(k):
        D=sum(states[i]); Dn=sum(states[i+1])
        rootD=F(k-i)*root_scale; rootDn=F(k-i-1)*root_scale
        H2=2-2*Dn/(rootD*rootDn) if Dn else F(2)
        assert rootD*H2==2*(rootD-rootDn)
        spent+=rootD*H2
    assert spent==2*k*root_scale
    counts['sharp_nested_laws']+=1
# Phase 3: finite matched incidence source types, exact endpoint conservation;
# Decimal is only a diagnostic for the irrational Hellinger sum.
source=[F(1,3),F(2,3),F(3,2)]
incidence=[[1,1,0],[0,1,1],[1,1,1]]
mass=[sum(w*c for w,c in zip(source,row)) for row in incidence]
base=[[F(0),F(1,7),F(1,9)],[F(1,11),F(0),F(1,5)],[F(1,13),F(1,17),F(0)]]
for q,du in product(((F(1),F(1),F(1)),(F(3,4),F(1),F(4,5))),((F(1),F(2),F(3)),(F(1,2),F(1,3),F(1,4)))):
    sigma=[q[a]*du[a] for a in range(3)]
    stages=[{0,1,2},{0,2},{2},set()]
    alphas=[]; Ds=[]; Gs=[]
    for kept in stages:
        gamma=[[base[a][b] if a in kept and b in kept else F(0) for b in range(3)] for a in range(3)]
        endpoint=[sum(gamma[a])+sum(gamma[b][a] for b in range(3)) for a in range(3)]
        density=[endpoint[a]/sigma[a] for a in range(3)]
        alpha=[[density[a]*sigma[a]*incidence[a][z]/mass[a] for a in range(3)] for z in range(3)]
        D=[sum(row) for row in alpha]; G=sum(map(sum,gamma))
        assert sum(source[z]*D[z] for z in range(3))==2*G
        if alphas:
            assert all(alpha[z][a]<=alphas[-1][z][a] for z in range(3) for a in range(3))
        alphas.append(alpha); Ds.append(D); Gs.append(G)
    with localcontext() as ctx:
        ctx.prec=70
        dec=lambda x:Decimal(x.numerator)/Decimal(x.denominator)
        for z in range(3):
            spent=Decimal(0)
            for i in range(len(stages)-1):
                D,Dn=Ds[i][z],Ds[i+1][z]
                if not D: H2=Decimal(0)
                elif not Dn: H2=Decimal(2)
                else:
                    aff=sum((dec(alphas[i][z][a])*dec(alphas[i+1][z][a])).sqrt() for a in range(3))
                    H2=2-2*aff/(dec(D)*dec(Dn)).sqrt()
                assert H2>=-Decimal('1e-65')
                spent+=dec(D).sqrt()*H2
            assert spent<=2*dec(Ds[0][z]).sqrt()+Decimal('1e-65')
    counts['endpoint_source_laws']+=1
print('PASS',counts,'total',sum(counts.values()))
print('Exact Fraction: atom certificates, sharp nested laws, all endpoint/source identities.')
print('Decimal70: normalized Hellinger diagnostics for 4 finite incidence models, not native geometry.')
