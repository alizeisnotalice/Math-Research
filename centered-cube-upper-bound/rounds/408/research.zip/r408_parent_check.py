from fractions import Fraction as F
from itertools import product
counts={};positive=0
for phase,N in [('initial',4),('large_jumps',6),('expanded',9)]:
 count=0
 for seed in range(1,5):
  f=[F(1+(i*seed)%7,3) for i in range(N)]
  C=[[int((i+a+seed)%3!=0 or i==a) for a in range(N)] for i in range(N)]
  m=[sum(f[z]*C[z][a] for z in range(N)) for a in range(N)]
  pi=[[f[z]*C[z][a]/m[a] for z in range(N)] for a in range(N)]
  edges=[(a,b,F(1+(a+2*b)%5,13),1+min((a+seed)%5,(b+seed)%5)) for a in range(N) for b in range(a+1,N)]
  G=sum(g for a,b,g,j in edges)
  for r,delta in product([F(5,4),F(3,2),F(3)],[F(1,16),F(1,32),F(1,128)]):
   T=[F(1,5)*r**i for i in range(7)]
   D=[[sum(g*(F(C[z][a],1)/m[a]+F(C[z][b],1)/m[b]) for a,b,g,j in edges if j>=i) for z in range(N)] for i in range(7)]
   original=late=early=F(0)
   for a,b,g,j in edges:
    sums=[F(0)]*N
    for i in range(1,j+1):
     for z in range(N):
      soft=max(F(0),1-F(1,20)/D[i][z]) if D[i][z] else F(0)
      full=(min(f[z],T[i])-min(f[z],T[i-1]))/f[z]*soft
      low=max(T[i-1],(1-delta)*T[j]);high=min(T[i],T[j],f[z])
      l=max(F(0),high-low)/f[z]*soft
      assert 0<=l<=full
      sums[z]+=l
      w=g*(pi[a][z]+pi[b][z])
      original+=w*full;late+=w*l;early+=w*(full-l)
    assert all(x<=delta for x in sums)
   assert original==late+early
   assert late<=2*delta*G
   positive+=late>0;count+=1
   # Exact feedback and source coefficient checks, not a smallness claim.
   Fabs=1/(1-32*delta) if delta<F(1,32) else None
   if Fabs:
    assert (1-32*delta)*Fabs==1
    assert 8+32*Fabs==8+2*(16*Fabs)
 counts[phase]=count
print('PASS terminal-relative source-slab positive splitting',counts,'total',sum(counts.values()))
print('strictly_positive_late_cost_cases',positive)
print('Exact finite marked-edge accounting, including large threshold jumps; no native geometric core or general root bound inferred.')
