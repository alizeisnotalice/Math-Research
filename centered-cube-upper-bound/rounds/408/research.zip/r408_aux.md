# R408：真实嵌套端点测度的时间 Hellinger 根阶总预算

2026-10-19。本稿证明所有阶段的归一化端点分布变化可由一次根阶来源费用支付，常数为2。尚未证明原密度切换费用 b_i 或未付原核心被该时间能量支配，故不声称一般目标闭合。

## 1. 原边、动态端点与来源条件law

冻结原 f、m_A=f(Q_A)=q_AR_A^n、q_-≤q_A≤λ、a≤R_A≤b≤2a，及所有时钟、来源与历史标记。令 γ_i 为原完整标记边测度通过既有端点作出的嵌套正限制；其端点投影满足 γ_{i+1}≤γ_i≤γ_0。可取 R397 的 γ_i=1_{A_i²}γ_0，下面无需修改其删除规则。

记 σ(dA)=q_A dA，G_i=γ_i(E²)，两端边缘之和为 s_i(A)σ(dA)。由原逐行/列容量，存在共同可测版本
\[
0\le s_{i+1}\le s_i\le S:=\beta+C_{\rm col},\qquad
\int s_i\,d\sigma=2G_i. \tag{1}
\]
可数阶段的 Radon–Nikodym 版本可在同一零集外同时单调；零集任意置零，不影响原边或源积分。

对每个真实来源 z 定义有限测度
\[
\alpha_i^z(dA)=s_i(A)q_Ac_A(z)\frac{dA}{m_A}
=s_i(A)c_A(z)R_A^{-n}dA,\quad
D_i(z)=\alpha_i^z(E). \tag{2}
\]
其正质量条件law为 p_i^z=α_i^z/D_i(z)。完整来源—端点联合测度为
\[
f(z)dz\,\alpha_i^z(dA)=s_i(A)\sigma(dA)\pi_A(dz),\qquad
\pi_A(dz)=f(z)c_A(z)dz/m_A. \tag{3}
\]
所以来源边缘为 fD_i dz、端点边缘为 s_iσ，后验 π_A 始终是同一 full-f 后验。特别
\[
\int fD_i=2G_i. \tag{4}
\]
这里归一化 p_i 仅描述动态端点条件law；不重新归一原输入，不改变 m、q、J 或任何原资格。

原真实中心包络给 A_n=1+n log(b/a) 及
\[
D_0(z)\le S\int\frac{1_{2\|A-z\|_\infty\le b}}
 {\max(a,2\|A-z\|_\infty)^n}dA=S A_n. \tag{5}
\]
它约束的是实际中心体积积分，不是来源密度。各来源测度联合可测；有限性、式(4)与后续换序均由非负参数积分保证。

## 2. 单步定理、零质量与最优常数

本文 Hellinger 平方约定为
\[
H^2(p,p')=\int(\sqrt{dp}-\sqrt{dp'})^2=2-2\operatorname{Aff}(p,p')
\]
（没有额外1/2）。设任意有限测度 α'≤α，质量 D'≤D。若两者正质量，令 r=dα'/dα∈[0,1]，则
\[
\operatorname{Aff}(\alpha/D,\alpha'/D')
=\frac{\int\sqrt r\,d\alpha}{\sqrt{DD'}}
\ge\frac{\int r\,d\alpha}{\sqrt{DD'}}=\sqrt{D'/D}.
\]
因此
\[
\boxed{\sqrt D\,H^2(p,p')\le2(\sqrt D-\sqrt{D'}).} \tag{6}
\]
不需要 α 的原子可分，也不需要 α' 是空间集合限制；真正的端点密度部分损失被 r∈[0,1] 覆盖。

统一零分母：只为归一化law增加一个形式墓地点 ∂。D=0时置 p=δ_∂，D>0时 p 支持真实 E。若 D>0、D'=0，H²=2，式(6)为等式；若 D=0 则 D'=0，两边为0。∂不作为实际接收者，不承载新的原边或来源费用。

常数2不能降低。例如 α'=α1_B 且0<α(B)<α(E)，亲和度恰为√(D'/D)，式(6)取等号；从正质量到零亦取等号。

## 3. 全阶段的根阶费用与终端信用

对每个 z 和有限 N，(6)直接望远镜给
\[
\sum_{i=0}^{N-1}\sqrt{D_i(z)}H^2(p_i^z,p_{i+1}^z)
\le2[\sqrt{D_0(z)}-\sqrt{D_N(z)}]. \tag{7}
\]
将 N→∞，D_i↓D_∞，由单调收敛得到
\[
\mathcal T:=\int f(z)\sum_{i\ge0}\sqrt{D_i(z)}H^2(p_i^z,p_{i+1}^z)dz
\le2\int f(\sqrt{D_0}-\sqrt{D_\infty}). \tag{8}
\]
终端项保留；D_∞正时不能擅自置零。以 α_∞ 为原嵌套端点密度的极限可定义 p_∞，D_∞>0 时 p_i→p_∞ 于全变差，D_∞=0 不需假设归一化 p_i 收敛。

由(4)、(5)，两个可比较而非相加的总价为
\[
\boxed{\mathcal T\le2\sqrt{S A_n}\,W,\qquad
\mathcal T\le2\sqrt{2WG_0}.} \tag{9}
\]
第二个界仅是 Cauchy–Schwarz。对 octave b/a≤2，第一项为 2√[S(1+n log2)]W：S维度一致时为一般根阶来源费用，无阶段数、密度层数或额外对数。

任何原先给定的可测权 0≤θ_i(z)≤1 乘在每个时间能量项上仍可用(9)，但这个正限制事实不证明原 b_i 费用本身是这样的能量项。

## 4. 跨过占用阈值的精确处理

固定 s_*>0，令 τ(z)=inf{i:D_i(z)≤s_*}。若0<τ<∞，只对 i<τ 的原law跳跃计费，包含唯一跨阈值跳跃 i=τ−1，则
\[
\sum_{i<\tau}\sqrt{D_i}H^2(p_i,p_{i+1})
\le2(\sqrt{D_0}-\sqrt{D_\tau}). \tag{10}
\]
无需将跨越原子拆开，也不把 D_{τ−1} 替成 s_*。若 τ=0，空和为0，右边也为0。

若分析需要在 τ 后关闭该来源law，可在原 τ 状态后仅加一个形式跳跃 p_τ→δ_∂，其精确费用为2√D_τ（D_τ=0时为0）。与(10)合并仍≤2√D_0；没有额外加一次2√s_*W。若不关闭，应保留(10)的终端信用。τ=∞时使用(8)的极限终端；未跨阈值不意味着来源已付款退出原核心。

上述停止时刻依赖 z，不用于重建全局 γ_i。它只是对同一来源时间预算作截断，保持原真实阶段不变。

## 5. 与原切换成本的精确边界

R397 原费用为
\[
B_i=\int [\min(f,T_i)-\min(f,T_{i-1})](D_i-s_*)_+dz
=\int\gamma_i[\pi_u(b_i)+\pi_v(b_i)].
\]
它由密度阈值的增加产生；式(8)由端点条件law随删除改变产生。当前没有证明 B_i≤C∫f√D_i H²，也没有证明其累计版本或原未付远域受这种能量控制。

尤其 α_{i+1}=t(z)α_i、t>0 时 p_{i+1}=p_i，时间能量为0，而总占用可以严格下降。完整费用桥若需要占用幅度，必须另外保留 D_i−D_{i+1} 或终端势；不能从归一化law稳定推出原切换费用为0。这是量的适用限制，不是一般几何路线的反例排除。

所以(9)是新、无条件、跨全部实际阶段的时间能量预算；尚无自动的 BH 或 switching ledger 新项。只有另证原 marked 费用由该量及已付误差支配后，才能按其真实入口系数乘(9)，原 square/删除信用也须各保一次。

## 6. 本机验证

脚本 `/tmp/r408_aux_check.py` 实际运行：

```
PASS {'atom_certificate': 144, 'sharp_nested_laws': 36, 'endpoint_source_laws': 4} total 184
Exact Fraction: atom certificates, sharp nested laws, all endpoint/source identities.
Decimal70: normalized Hellinger diagnostics for 4 finite incidence models, not native geometry.
```

144项为有理原子单步证书；36条平方质量嵌套限制law精确核验归一化H²、末端零质量和常数2的总等号；4个有限来源/接收类型模型用Fraction核动态端点与来源守恒，归一化Hellinger和只作70位Decimal诊断。有限模型不认证原实际半径选择器或完整历史。严格一般证明为(1)–(10)，数值未用于补足第5节未证桥。
