# 第404轮：真实质量匹配的邻域体积定理与完整根尺度近源付款

2026-10-19。第403轮留下近源双collar的计数软余项及全部远源。本轮利用真实匹配 f(Q_w)=m_w，将完整近源原积分一次估计，不再分解失败坐标或collar。新近域包括半宽约a/(2√n)的立方体位移域，以及半径a/8的ℓ1位移域。一般 n^(1/2+o(1)) 弱型上界仍未闭合；最后的远源原积分及原总账的其他槽完整保留。

## 1. 原合同与母积分

继承R400–403：f≥0为完整L1输入；真实接收测度du；a≤R_u≤b≤2a；m_u=f(Q_u)=q_u R_u^n；0<q_-≤q_u≤λ；μ(du)=du/m_u；σ=qdu；π_A=f1_QA/m_A。记X_q=σ(E)、W=∫f、K=exp(√n)、s=1+√n、h=s/(ε_0 q_-)、0<ε_0≤1/2、L≥4、S=β+C_col。全部原源、目标、阶段、时钟、历史和选择标记不改变；逐来源外出容量β、逐来源入列容量C_col及Σ_i b_i(z)≤1均保留。

定义严格远质量场
\[
Z_A(z)=\int_{m_w<m_A/K}c_w(z)\frac{dw}{m_w},\quad
C_A(y,z)=\int_{m_w<m_A/K}c_w(y)c_w(z)\frac{dw}{m_w},
\quad E_y=Z_A(y)-C_A(y,z),\quad E_z=Z_A(z)-C_A(y,z).
\]
这里“远质量”不是源位移距离；所有Z均使用原同一个actual receiver field。母余项R400含外部端和小端的低共同捕获soft补集与双高秩。在其正支原双秩不等式是
\[
\frac{1-\phi_u}{E_yE_z}\le\frac1{2Lh^2},\qquad
\frac{1-\psi_v}{E_yE_z}\le\frac1{(2-\varepsilon_0)(L-\varepsilon_0)h^2}.
\]
非正支费用为零。令
\[
B_L=\frac\beta{2L}+\frac{C_{\rm col}}{(2-\varepsilon_0)(L-\varepsilon_0)},\quad
d_{\rm face}=4\varepsilon_0^2 B_L\le S/L,
\quad A_n=1+n\log(b/a)\le1+n\log2<s^2.
\]
A_n/q_-是对所有中心和可测半径场的单源占用上界：内盒贡献1/q_-，外立方shell贡献n log(b/a)/q_-；正限制不增加。不是原论文的同名未定义常数。入口中的旧A_n若使用不同定义，仍保留为旧入口常数，本节的占用常数仅用于Δ404。

## 2. 核心：匹配消去分母，得到真实中心足迹体积

固定实际端点A、来源y和紧位移集合D。置M=m_A/K、R_*=(M/q_-)^(1/n)。若没有远质量接收者，相关积分为零。否则R_*>a，因为m_w≥q_-a^n且m_w<M。

对紧集D使用Tonelli（所有项非负）：
\[
\begin{aligned}
\int\pi_A(dz)\mathbf1_{z-y\in D}Z_A(z)
&=\frac1{m_A}\int_{m_w<M}\frac{f(Q_A\cap Q_w\cap(y+D))}{m_w}\,dw\\
&\le\frac{|D+Q_{R_*}(0)|}{m_A}.
\end{aligned}
\tag{1}
\]
证明关键有两个。第一，交集来源质量≤完整f(Q_w)=m_w，故分母在积分内真正消掉，绝未假设f有密度帽。第二，正贡献必有z∈Q_w∩(y+D)，而R_w<R_*，故中心w∈y+D+Q_R*(0)。这里Q_R*是边长R_*的中心立方体；用闭盒上界不会遗漏严格mass截断的边界。D紧确保Minkowski和紧且可测。真实接收者E只取其中一部分，故可放大到真实Lebesgue体积。此上界没有λ损失，没有复制来源、没有给w新时钟资格。

特别地，对D=∏[-d_j,d_j]，右端≤(q_-K)^(-1)∏(1+2d_j/a)。各方向宽度可不同，但选择域必须先冻结；不能无费用地对任意各向异性盒再取并。

## 3. 一般几何体积预算：根尺度立方体与ℓ1球联合

设0<θ≤1。定义两个固定紧位移域
\[
D_\infty(\theta)=\left[-\frac a2(e^{\theta/\sqrt n}-1),\frac a2(e^{\theta/\sqrt n}-1)\right]^n,
\qquad D_1(\theta)=\{v:\|v\|_1\le\theta^2a/8\},
\quad D(\theta)=D_\infty(\theta)\cup D_1(\theta).
\]
立方体扩张体积比由R_*>a得
\[
|D_\infty(\theta)+Q_{R_*}|/R_*^n
\le[e^{\theta/\sqrt n}]^n=e^{\theta\sqrt n}.
\tag{2}
\]
对ℓ1球，写ρ=θ²/8。按位于Q_R*外的坐标数k及符号划分，k个正超出量组成和≤ρa的单纯形，另n−k坐标在边长R_*区间。因此精确体积公式为
\[
\frac{|\rho aB_1+Q_{R_*}|}{R_*^n}
=\sum_{k=0}^n\binom nk\frac{(2\rho a/R_*)^k}{k!}
\le\sum_{k=0}^n\frac{(2\rho n)^k}{(k!)^2}
\le e^{2\sqrt{2\rho n}}=e^{\theta\sqrt n}.
\tag{3}
\]
最后一步：exp(√x)exp(√x)的非负双级数包含全部对角项Σx^k/(k!)²，所以是全维解析不等式，不从数值拟合指数。坐标边界的重合只在这里的真实中心体积计算中是零测集，不删除来源f的任何边界质量。

实际支付事件为z−y∈D(θ)，交叠只计一次。仅上界时用两域体积和。由R_*^n=m_A/(Kq_-)，
\[
\sup_y\int\pi_A(dz)\mathbf1_{z-y\in D(\theta)}Z_A(z)
\le\frac{2e^{-(1-\theta)\sqrt n}}{q_-}.
\tag{4}
\]
这同时覆盖密集小坐标位移和少数较大坐标位移，但不把精确零坐标的稀疏向量当成全L1来源的典型形态。

## 4. 完整近源原积分与双端stage费用

由于E_yE_z≤Z_A(y)Z_A(z)，且Z_A(y)≤A_n/q_-，对每个固定原(A,y)有
\[
\int\pi_A(dz)\mathbf1_{z-y\in D(\theta)}E_yE_z
\le\frac{2A_n e^{-(1-\theta)\sqrt n}}{q_-^2}.
\tag{5}
\]
将此量插入第1节原soft/rank不等式。外端保留dΓ_i=σ(du)π_u(dy)ℓ_i(u,y,dv)，在原old y上用ℓ_i(E)≤β；入端用原逐来源k_i(v,y)≤C_col。先在同一new z求和Σ_i b_i(z)≤1，再应用(5)；不能逐stage分别付一个完整(5)而遗漏stage数。只为上界丢掉其他正限制，未改变实际支付事件。得到
\[
R400[D(\theta)]\le\Delta_{404}(\theta)X_q,
\quad\Delta_{404}(\theta)=\frac{2\varepsilon_0^2 A_n}{s^2}B_L e^{-(1-\theta)\sqrt n}
\le\frac{d_{\rm face}}2e^{-(1-\theta)\sqrt n}
\le\frac S{2L}e^{-(1-\theta)\sqrt n}.
\tag{6}
\]
此处R400[D]是外部端和小端的完整原余项乘1_D；不要求failure sets相交、不要求任何inner或collar事件，也无需附加见证重采样。若外端使用旧E_uv/Z_u条件表达，保持其原恒等式；(1)只发生在原π_u的新源积分，未将E_uv/Z_u置1。

本轮主账取θ=1。由e^x−1≥x，n≥9时D∞(1)半宽≥a/(2√n)≥a/n≥ζa/n，所以包含R403的整个近域。R403近源双collar残余全部被本定理支付，而且还支付部分原远源。并非只支付一个特殊函数族；(1)–(6)对原完整f类和可测半径场成立。

## 5. 精确补集、完整替换和总账

从R400母积分直接拆分
\[
R400=R400[D(1)]+R404,\qquad
R404=R400\big[\|z-y\|_\infty>\tfrac a2(e^{1/\sqrt n}-1),\ \|z-y\|_1>a/8\big].
\tag{7}
\]
补集保留全部原高rank、低共同捕获soft、端点、源、stage、时钟和历史，不附加near专用的failure/collar/count限制。所有402–403近源费用整体撤回，由Δ404(1)替换；共同捕获旧系数仍只一次。保留
\[
\chi_n=\frac{2(\lambda/q_-)S\varepsilon_0}{K(1+\sqrt n)},\quad
P_L=\lambda h[\beta(L+\varepsilon_0)+C_{\rm col}L],\quad\Lambda=128/119.
\]
对n≥9，沿同一母账回代：
\[
G_0\le16R404+16(\chi_n+\Delta_{404})X_q+16(s+P_L)W,
\]
\[
B_H\le32R404+[E_{387}+32(\chi_n+\Delta_{404})]X_q+[S_{390}+40s+32P_L]W,
\]
\[
\text{原入口}\le\Lambda\{8\lambda HW+2d_{\rm eff}A_{\rm entrance,n}W_\nu/H+64R404
+[2E_{387}+64(\chi_n+\Delta_{404})]X_q+[2S_{390}+80s+64P_L]W\}.
\tag{8}
\]
A_entrance,n表示原入口常数（不在本轮重新定义或删除）。同参数、同n≥9场上R404≤R403，且Δ404≤d_face/2≤Δ403；因此本轮确实同时缩小剩余积分和所显示的局部费用。不是仅凭余项缩小推断总账改善。

欲局部Δ404≤δ，可取L≥max(4,S/(2δ))。若改变L须在R398完整母分拆中替换P_L和高/低rank域；不能免费重调。还必须核64ΛΔ404的全局可用吸收余额。低维继续用既有直接界替换整个core槽，不与高维账叠加。

未解决：(7)的联合远位移硬层、原入口选择与soft/crossing/entry、重尾/宽距离/低pe/极端尺度补集、初始/删除跳跃/未来被删来源、全尺度聚合和极限，以及全部旧吸收费的总余额。本轮没有证明整个这些费用≤εX+Cε√n log^A(n+2)W。

## 6. 实际计算证据、工具与下一步约束

本机标准库Fraction运行r404_body_check.py：40组Minkowski体积多项式系数检查（初步20，边界10，扩大10）及45组保守费用/旧近域包含检查通过。精确指数上界来自(3)解析证明，不来自有限检查。

实际连接MATLAB运行r404_matching_check.m：完整连续f=1_[0,2]，A=[0,2]，m_A=2，R_w=1，接收域q_min≤m_w<2/e，q_w=m_w。将原来源积分与真实中心积分分别数值积分，140组（初步4，边界16，扩大120）通过；最大两序积分差2.2204460492503131e-16。普通浮点求积，不是区间证书，不声称这些低维诊断实现高维完整历史核心。默认Python无SciPy，本轮未使用或安装它。

作者r404_geometry_check.py另有747项Fraction检查（45真实中心fixture、486完整来源取消、24stage、192费用），父代理与独审复跑以最终结果为准。重新运行相同案例不计为新增实验。本轮沿用64项工具的A02正支配/完整费用与L03证据边界；不把skill私有接口当作定理。没有实际逐模型扣额数据。

辅助全坐标包络见r404_aux.md：保留任意位移向量和严格mass半径截止。它本身的最坏费用仍线性，不作为本轮付款定理前提或新增费用。其作用是精确说明后续远域需要继续利用真实质量匹配，而不是仅对任意半径选择器取包络。

下一步从(7)原积分继续攻坚，特别保留真实质量匹配与原端点来源平均；不能重新只对单源最坏几何包络取平方后宣称全局根阶。所有档案只保存LaTeX源与必要复现材料，不编译PDF。
