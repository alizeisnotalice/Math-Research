# R408 independent audit — FINAL PASS (late fraction and temporal budget; early remainder unresolved)

FINAL PASS for the actual late density fraction, exact feedback ledger, and optimal temporal-Hellinger source budget in the stated frozen field. No bound for the complete early same-stage switching cost or general marked core is certified. Only this audit file was edited. The independent screens below were derived before author proofs; full post-review and final byte bindings follow. No author/repository bytes or original fields were changed.

## 1. Exact measure lemma and optimal constant

Let alpha_i be finite nonnegative measures on one common receiver space, alpha_{i+1}<=alpha_i, D_i=alpha_i(E). For D_i>0 let p_i=alpha_i/D_i. Fix one additional isolated cemetery point dagger. At D_i=0 define p_i=delta_dagger; positive-D_i probabilities have zero mass at dagger. Nesting ensures all later alpha are zero after the first such stage. Squared Hellinger here is the unhalved norm ||sqrt(p)-sqrt(q)||^2, taking values in [0,2].

For D_i,D_{i+1}>0 use alpha_0 as common dominating finite measure (or any dominating measure). Nested densities a_{i+1}<=a_i imply sqrt(a_i a_{i+1})>=a_{i+1}; hence

    affinity(p_i,p_{i+1})>=sqrt(D_{i+1}/D_i),
    H^2(p_i,p_{i+1})<=2[1-sqrt(D_{i+1}/D_i)],
    sqrt(D_i) H^2(p_i,p_{i+1})
       <=2[sqrt(D_i)-sqrt(D_{i+1})].

If D_i>0 and D_{i+1}=0, the cemetery law is orthogonal and H^2=2, so the same final inequality is equality. If D_i=0, its weighted contribution is defined to be0, without any 0/0. The universal constant is exactly2.

For every finite N, positive summation therefore gives

    sum_{i=0}^{N}sqrt(D_i)H^2(p_i,p_{i+1})
       <=2[sqrt(D_0)-sqrt(D_{N+1})].

Monotone convergence of the nonnegative left side and D_i down to D_infinity give

    sum_{i>=0}sqrt(D_i)H^2(p_i,p_{i+1})
       <=2[sqrt(D_0)-sqrt(D_infinity)]<=2sqrt(D_0).

The stronger first form includes a nonzero limiting core. If alpha_i are dominated by alpha_0, their decreasing densities also define the true limiting measure alpha_infinity with mass D_infinity by dominated convergence. No claim that the actual core becomes empty is required. A virtual extra jump to the cemetery may be added only as an explicitly artificial extra term; it is not a proof of termination/payment of the actual original process.

Constant2 is optimal. Retain smaller and smaller subsets of alpha_0 without changing the density on what remains, and eventually delete all support. Every affinity bound above is then equality. For example choose D_i=((N-i)/N)^2 through i=N; one may realize these masses by removing disjoint atoms of masses D_i-D_{i+1}. Each weighted increment is2/N and the total is exactly2sqrt(D_0)=2. More generally letting a single retained mass tend to0 also approaches2 without a finite zero terminal. This optimality is a finite measure fact, not a geometric fixture.

## 2. Does the actual gamma nesting supply the required measure nesting?

Yes, provided alpha_i uses the actual UNMARKED endpoint occupation from gamma_i, not the individual b_i-weighted switching terms. Keep the frozen original field and

    gamma_i=gamma_0 restricted to A_i x A_i,
    A_{i+1} subset A_i,
    nu_i=gamma_i,out+gamma_i,in.

Positive restriction implies nu_{i+1}<=nu_i as measures. The original outgoing/incoming capacities give nu_i<=S sigma, sigma=q_w dw. Let s_i=dnu_i/dsigma; for this countable sequence choose common measurable RN versions with

    0<=s_{i+1}<=s_i<=S, sigma-almost everywhere.

For each source z the actual endpoint occupation measure is

    alpha_i^z(dw)=c_w(z)nu_i(dw)/m_w
                =s_i(w)c_w(z)dw/R_w^n,
    D_i(z)=alpha_i^z(E)=T_R^*s_i(z).

The weight c_w(z)/m_w and original q,m,R are fixed across stages, so alpha_{i+1}^z<=alpha_i^z. This is not a new probability resampling and requires no assignment of old history to the witness receiver. The actual selector center envelope gives

    D_i(z)<=S integral c_w(z)dw/R_w^n<=S A_n=M,
    A_n=1+n log(b/a).

No q factor is missing: q_w/m_w=R_w^{-n} is used exactly. Original matching gives the further exact source identity

    integral f(z)D_i(z)dz=nu_i(E)=2G_i.

If instead one inserts a varying source-stage mark b_i(z) into alpha_i before normalization, nesting need not hold. The original b_i are not being assumed monotone. That would be a different lemma with an additional hypothesis, not this consequence of nested gamma_i.

Joint measurability is available from the displayed density s_i(w)c_w(z)/R_w^n and the original measurable field. Dividing only where D_i(z)>0 and using a fixed cemetery elsewhere gives measurable probability kernels on E union {dagger}. Hellinger squared is a nonnegative measurable integral relative to dw plus the cemetery atom. Countable-stage null sets can be chosen simultaneously; no source-dependent uncountable RN selection or measurable optimizer is needed.

## 3. The genuinely proved source budget

Applying the pointwise measure lemma, then positive Tonelli, yields the actual temporal-energy estimate

    integral f(z) sum_i sqrt(D_i(z))H^2(p_i^z,p_{i+1}^z)dz
       <=2 integral f(z)sqrt(D_0(z))dz
       <=2 sqrt(M) W.

Since M=S A_n, this is root-order in n at fixed S and octave ratio. A sharper data-dependent bound is also valid:

    2 integral f sqrt(D_0)<=2sqrt(W integral fD_0)
                         =2sqrt(2G_0 W).

Both may be used via their minimum. Zero input or zero occupation is harmless. For infinitely many stages no dominated exchange of signed terms is invoked; finite partial sums and monotone convergence suffice. The estimate is a real bounded temporal quantity of the same actual nested endpoint measures. It is not an old full spatial Hellinger-energy bound: the normalizations and pair directions are different.

## 4. What still has to be proved to pay the original bill

The original switching bill uses same-stage source-density increments and occupation D_i, including b_i(z)=[Delta min(f,T_i)/f](1-s/D_i)_+ and the full old/new labels. The temporal energy instead measures change from p_i^z to p_{i+1}^z; it is not that bill. Increasing a source-density threshold while a fixed endpoint occupation profile is unchanged can leave this temporal increment zero. Thus the measure lemma alone cannot identify either sum with the other.

A useful new bridge must exhibit a true positive decomposition or drift/source inequality for the ORIGINAL marked stage bill, bounded by this temporal energy plus separately priced telescoping/terminal terms. All coefficients, source-density increments, initial term, residual core, clock/history restrictions and direction of inequalities must remain explicit. In particular one cannot declare that the actual core is zero by attaching a cemetery point, charge private W at every stage, use a different normalized endpoint measure while keeping this budget, or drop a positive threshold-switch contribution. No such bridge is proved by this independent screen. No original R406/R407 receipt is deducted a second time.

## 5. Actual bounded local calculation

Ran a standard-library Python Fraction calculation with certified rational square-root enclosures:130 assertions across28 finite nested-measure chains. Twenty-four nonconstant-density chains checked nesting and the complete cemetery-ended sum using rational upper bounds for the left side; four pure support-deletion chains with D_i=((N-i)/N)^2 for N=2,4,8,16 attained constant2 exactly. These are finite measure/algebra certificates, not a native cube or original-history fixture and not a proof of the missing same-stage bridge. No separate script file was saved; this reviewer count is not pooled with future author checks.

The independent prefilter passed for constant2, actual endpoint nesting, source budget and infinite/zero conventions. The later frozen late-fraction argument is reviewed below; the general early-geometry budget remains unresolved.


## Independent late-fraction proof, completed before author reading

For a fixed original edge whose last active stage is j, let a_i(z)=(1-s/D_i(z))_+ in [0,1]. In its actual density integral restrict every i<=j to the same interval [(1-delta)T_j,T_j]. Since the original thresholds are nondecreasing, the adjacent [T_{i-1},T_i] intervals overlap only at dt-null endpoints. Consequently, for f(z)>0,

    sum_{i<=j}b_i^late,j(z)
       <= |[0,f(z)] intersect [max(T_0,(1-delta)T_j),T_j]|/f(z)
       <=delta.

The last inequality holds separately when f lies below, inside or above the last density interval; it does not require a stage-ratio bound and includes repeated thresholds or arbitrarily large jumps. At f=0 the original marks are zero. Both actual full source posteriors are probabilities, hence each edge's summed two-end late cost is <=2delta. Positive first-deletion disintegration then gives B_late<=2delta G0. Original R406 spatial, old/new-source, rank, soft, clock and history factors only restrict this positive bill. The posthoc j label settles a fixed original edge; it does not modify the process or grant descendants a historical qualification.

For a finite horizon the survivor gamma_N must remain, with full accumulated source cost <=2G_N. Only the original R397 density schedule and clearing result allow G_N down to0 in the infinite limit. Neither the formal cemetery used by the normalized-measure lemma nor a freshly chosen deletion schedule proves this clearing. Under the actual clearing contract, R406=R_early+R_late, R_late<=2delta G0, so the entering mother inequality

    G0<=16R406+16C406 Xq+16V406 W

implies exactly

    (1-32delta)G0<=16R_early+16C406 Xq+16V406 W.

Solving requires 0<delta<1/32. This is a small-coefficient payment for a positive actual fraction, not a claim that the full right side decreases or that a positive fraction of every input is paid. Original stages, f and h are unchanged. The same-stage fine-mesh or last-k alternatives are not charged in addition.

## Complete frozen author post-review

Read r408_aux.md fully. Its RN nesting, exact full-f endpoint joint measure, source marginal fD_i, endpoint marginal s_i sigma, M=S A_n and factor2 source conservation are correct. Both stated source bounds are alternatives/minimum, not an added pair of W fees. The cemetery is solely a convention for normalized laws; alpha itself has no new mass there. The finite/infinite terminal credit, crossing-threshold original jump and optional formal closure are explicit. Constant2 is sharp. No source density cap, new receiver history or automatic same-stage fee bridge is assumed.

Read the final r408_geometry.md fully. The added log time bound, D-weight bound and nonnormalized Hellinger identity are correct with the unified zero-mass convention. The logarithmic sum stops only on D_{i+1}>=s and remains a separate source-priced quantity; its D weights cannot replace s or sqrt(D) in an original bill without proof. Its candidate (3?) is explicitly unproved. The late density interval proof, first-deletion indexing, positive finite decomposition and original clearing limit agree with the independent screen above. It retains two endpoint costs, all survivor terms and the complete early density increments. There is no free owner cancellation, missing non-owner cost, or claim that the remaining defect has a fixed positive multiple of edge cost. The earlier finer-stage/last-k remarks require their actual schedules and do not secretly rebuild the frozen stage table.

The exact finite terminal and delayed-mark formulas keep all old accumulated marks at the eventual deletion edge. In particular the note does not identify them with the normalized time-energy increment: density thresholds can change at unchanged endpoint laws, and proportional occupation loss is not normalized-law variation. Those are the correct limitations of this approach, not a claimed original-contract counterexample family.

## Final main report, feedback and scope

Read the final r408_main.md and r408_readme.md fully. PASS: they use R406's adopted square-root-old-source remainder, not the optional linear alternative as a free extra gate. C406=chi_n+Delta404+eta and V406=s+P_L+D_eta s remain the same entering complete mother fees. The new factor F_delta=(1-32delta)^(-1) multiplies the full G0 mother RHS, including C406 and V406. The BH outer terms E387 Xq+(S390+8s)W are correctly outside that mother multiplication. The original entrance therefore has coefficient64F_delta on R408,2E387+64F_delta C406 on Xq, and2S390+16s+64F_delta V406 on W, with the old H/entry terms unchanged. delta=1/128 indeed gives F_delta=4/3. No enlarged X coefficient is presumed absorbable; the global remaining budget must be checked.

The report does not claim an overall pointwise improvement of complete RHS, original early cost domination by the temporal energy, or a general root-order maximal theorem. Existing near/common/negative-square/deletion credits remain once. The temporal root source estimate is valid but is not inserted as payment for R408. The old H entrance, all other historical/source/scale limits and total absorption remain explicit. The PDF/skill reading statements are parent provenance, not mathematical inputs independently reread or invoked by this reviewer; the entering old reductions are not re-proved wholesale here.

## Actual delivered-code review and executions

Read all three delivered Python scripts and actually reran them locally, all PASS:

- parent:108 Fraction models,36 per initial/large-jump/expanded stage,105 positive late costs. These prescribe arbitrary nested edge/death labels; they are not actual weak-deletion/native-cube/history fixtures. Some delta values test only the positive split (including delta>=1/32); feedback division is checked only where delta<1/32.
- geometry:2136 Fraction assertions in groups300,84,24,1296,432. The last432 check nonuniform density jumps and all possible first-deletion labels. The finite incidence/receiver measure is not a native continuous original-history field. Log bounds are proved analytically, not fitted numerically.
- auxiliary:144 rational atom certificates and36 exact sharp square-mass chains, plus4 finite endpoint/source models. The4 models verify Fraction conservation identities, but their normalized irrational Hellinger sum is only a70-digit Decimal diagnostic with tolerance, not an outward interval certificate.

Thus the delivered evidence is2424 exact/rational checks plus4 mixed exact-identity/ordinary-Decimal diagnostic models. It must NOT be summarized as2428 exact Hellinger certificates. Reviewer and parent reruns are the same cases, not extra experiments. The independent130 rational/enclosure checks in the prefilter are separately scoped and not added to that delivered total. No numerical count or fixture certifies the missing continuous early-geometry theorem.

FINAL PASS in this bounded range: the actual late fraction has the displayed small G0 coefficient and exact mother/entry feedback; the temporal normalized-law budget has optimal constant2 and a genuine once-only root source price. These are distinct statements. The complete early marked remainder and its bridge to temporal energy remain unproved, and the general weak-type bound is not closed. No author, script, result or repository file was edited by the reviewer. Audit is frozen at the bindings below.

## Final SHA-256 bindings
- `/tmp/r408_main.md`: `29e41de32db722d89962f3f3593155b7e298bb02350e50cdab4a2a4fd12f3253`
- `/tmp/r408_readme.md`: `5e53ad4b5f6e54c7484a0186e7d7ddf48d8e94fc44cf7e6026893beb3415f73d`
- `/tmp/r408_aux.md`: `112a1a3709e32f2274b8cab31dc2811a8c3d74e2b2c642fce66e1ded8635f547`
- `/tmp/r408_geometry.md`: `69d0764345ae9fa6d09953583ab6ca495c93fde3080e7248ba4c48f6d38fa642`
- `/tmp/r408_parent_check.py`: `13ca1e743811f7e312d14c49373814eff27f993e5984f7cf73fd16a5bcc28af1`
- `/tmp/r408_parent.result.txt`: `02593c319420ec142750983118a38345ff32e727dd5e11af300d4f1428dc2357`
- `/tmp/r408_aux_check.py`: `fbfec6ea3d3e345901329b45a62e7563c7ec8332739c1ada80dd98fb71f4ac6c`
- `/tmp/r408_aux.result.txt`: `61e4e045b05aff00fe5dd322e922d53e133922ce050aa6ff909df4aa4e778ac6`
- `/tmp/r408_geometry_check.py`: `43c4e96bd10b37a5590db59cf9c885ade73d4ced0925154701d7dcef32e376e4`
- `/tmp/r408_geometry.result.txt`: `cfc4eca11dfe4a53a54564bb38ca52e6768f89f5bc21917c485f18f666abed35`
- `/tmp/r406_main.md`: `433f82a68430e2de4459c16214364bfacbd699c88652049713aeda5a8dce70f4`
- `/tmp/r404_main.md`: `d4914c5995deaa1b692ebb3c09928771e36cee8ca6a4b5c2604c85daad440b77`
