# R244: receiver resource and the unused negative ledger

This note owns only this file. It resolves the hard-band qualification
needed to integrate the R243 shared column against the original hard
source. It does not prove a new general root payment. The resource is
an original receiver cost, not an input-mass cost; the remaining source
moment and the original signed gates must still be paid.

## RL1. The inherited hard band is an all-scale band

The decisive ancestor is
[GENERAL_CURRENT_REDUCTION.md:5–13](/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md:5).
It defines `G_s=sup_{a<=L<=b}P_s,L*f`, restricts the original receiver
event to `2lambda<G_0<=4lambda`, and retains the common
`3lambda/4<=q<=lambda`. Since `P_0,R=h_R`, this gives, on that same
original event E,

    (h_R*f)(x)<=4lambda<=C0 q for every R in [a,b],
    C0=16/3.                                           (RL1)

The selected-scale display in
[R107 integration.md:9–17](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/integration.md:9)
is a weaker consequence, not a replacement of the ancestor event.
In particular a rounded node R_i in [a,b] does inherit RL1. This is
not inferred from `h_R(x)f<=4lambda` by pointwise kernel comparison:
that inference alone would have the wrong direction. No additional
physical-rounding factor is required for this use of the hard band.
The original event must remain present. RL1 grants no cap at a receiver
added by enlarging E or at a scale outside [a,b].

## RL2. Integrating the genuine R243 column

Freeze the original common octave, q and input f. For each probability
seed and retained leaf V, let Omega_{V,i} be the source-independent
physical receiver partition of R243, with both orientations included,
R_i in [a,b], and let

    O_{V,i}(z)=integral_{Omega_{V,i}}h_Ri(x-z)dx,
    w_i=(a/R_i)^{alpha n},
    S_{V,alpha}(z)=sum_i w_i O_{V,i}(z), alpha>0.

The sets Omega_{V,i} are disjoint within V. Across V, at most one
original leaf row is nonzero for a receiver. The latter qualification
is original [R107:109–120](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/integration.md:109),
not a count of auxiliary sources. Retain original E throughout. For
the original hard submeasures `nu_V<=f dx`, put

    W_nu=E sum_V ||nu_V||, X=lambda |E|.

Then the two simultaneously valid budgets are

    E sum_V integral S_{V,alpha} dnu_V
      <= min{[1+(1-(a/b)^{alpha n})/alpha] W_nu,
              C0 q |E|}
      <= min{(1+1/alpha)W_nu,C0 X}.                    (RL2)

Proof of the first arm: R243's disjoint receiver-column calculation
gives `S_{V,alpha}(z)<=1+(1-(a/b)^{alpha n})/alpha` pointwise.
For the second arm, Tonelli, RL1, `w_i<=1`, and the unique original
leaf give

    E sum_{V,i} integral_{Omega_Vi}w_i(h_Ri*nu_V)(x)dx
      <= C0 q E sum_{V,i} integral_{Omega_Vi}w_i dx
      <= C0 q |E|.

The seed expectation is a probability average, not a sum over seeds.
The actual-kernel version with `h_R(x)` satisfies the same two arms:
for its column use `w_i<=(a/R(x))^{alpha n}` in the original radial
supremum argument. Both versions are legitimate. They must not be
mixed inside one overlap identity without checking that identity.

The original mass bound `W_nu<=W_beta<=W_hi<=||f||_1` is
[R237 source_ledger.md:81–99](/Users/zhengzhihao/Desktop/T/output/centered_cube_round237_20261017_final_checkpoint/source_ledger.md:81).
It pays the first arm. The second arm is paid by X. Neither statement
identifies `q|E|` with W, and neither bounds a moment of H(z) merely
because H is defined on the same sources. In particular `H(z)^2nu_V`
need not be dominated by f.

## RL3. Exact absorption constant, and why it is not a new payment

Here is a precise consequence of RL2 and the already proved R243 SR4,
on its same source restriction F_z and original gates. Fix, globally,
`p=r=1/2`, `theta=1/8`, `alpha=1/4`. Let

    rho(z)=(qa^n)^-1 integral_{F_z} exp[-J(y-z)/2]beta_V(dy),
    M=E sum_V integral rho(z)nu_V(dz),
    N=ceil(pi sqrt n), B=eN, A=4480/e^2,
    D=(3/2)Lambda e^4 (K/3)^{1/8}sqrt(BA), Lambda=128/119.

R243 SR4–5, restoring its stated three-leg/physical/original prefactor,
give the positive majorant

    P_F^+ <=D E sum_V integral sqrt(rho S_{V,1/4})dnu_V
           <=D sqrt(M C0 X).                          (RL3)

The A above already includes both orientations and the independent
capped endpoint. There is no second factor two for orientations.
RL3 is for the R243 positive traffic with its original restrictions;
it does not replace the unestimated part of FULL by that restriction.
If M is infinite, it grants no finite payment. Otherwise, for every
epsilon>0, scalar Young gives exactly

    P_F^+ <=epsilon X
       +[13440 Lambda^2 e^7 (K/3)^{1/4}N/epsilon] M
      <=epsilon X
       +[13440 Lambda^2 e^7 (K/3)^{1/4}(pi+1)/epsilon]
            sqrt(n) M.                                (RL4)

Thus `M<=C W` would suffice for an absorbable root input price, with
all constants displayed. It is an additional source-moment estimate,
not an inherited consequence of the unweighted source ledger. For
general fixed r, an estimate `P<=D_r integral rho^r S^{1-r}dnu`
has the exact receiver-Young price

    P<=epsilon X
       +r D_r^{1/r}[(1-r)C0/epsilon]^{(1-r)/r}
          integral rho dnu.                            (RL5)

In particular choosing `r~1/H` does not permit suppressing its
epsilon-dependent exponential price.

RL4 is recorded as an accounting test, not as progress over R243.
Indeed, with `L=1+log B+log_+K`, its existing H^2 source price obeys

    integral (L+log_+rho)^2 dnu
      <=2L^2 W_nu+(8/e^2)M,

because `(log_+u)^2<=4u/e^2`. Hence merely assuming `M<=C W` already
allows a stronger existing logarithmic source price. The receiver
capacity by itself has not supplied the missing source estimate.

## RL4. Which negative credits remain, and their first mismatch

The exact mother is
[R128 proof.md:604–633](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:604):

    dT_I=1_I 1_{j(x)=j}q^-1 p(x,y)h_R(x)(x-z)a_omega
                      dx beta_V(dy)nu_V(dz),
    pending slot=2Lambda(P_I^rem-N_{I,Z^c}-N_{I,del}).  (RL6)

The two auxiliary measures are the same complete `Pi_t tensor Pi_t`,
including both original e_t denominators. With good v and bad u,
the positive score is `(k_t(v)-k_t(u))_+`. The surviving negative
uses the reversed score and original Psi, but has no positive FA or
capture-rho gate. `N_del` is the original continuous deletion credit,
not the boundary atoms of a newly chosen test potential.

These two unused credits each occur once with coefficient 2Lambda.
The suffix credit already used to obtain this mother cannot be
reclaimed; initial/suffix/jump test costs do not become fresh negative
money. The checked detailed mapping is
[R223 negative_contract.md:44–75,134–153](/Users/zhengzhihao/Desktop/T/output/centered_cube_round223_20261016_final_checkpoint/negative_contract.md:44).
R116's original high/low representation also retains the hard z and
all original row gates: [integration.md:18–33](/Users/zhengzhihao/Desktop/T/output/centered_cube_round116_20261014/integration.md:18).

The first obstruction to subtracting RL6 from RL3 is concrete: RL3
has enlarged the positive density to fractional three-leg kernels,
rounded nodes and a source-Holder/receiver majorant. The original
negative still carries its original p h_R a_omega and its own gates.
An upper bound on a positive coefficient does not give the lower
bound on a negative coefficient needed to paste the same majorant
onto both signs. Hardband (an upper cap) supplies no such lower bound.
Nor can one credit be assigned to every leg or physical index.
One must either retain the common original coefficient in a new
signed argument or pay its mismatch. No such payment is proved here.

## RL5. Bounded local arithmetic check

The following local Python/mpmath algebra check was actually run at
60 decimal digits: 27 checks passed (24 general-Young values and
three exact RL4 coefficient checks, n=2,512,10000). This verifies
arithmetic only, not FULL/history or a new source budget.

```python
import mpmath as m
m.mp.dps=60
checks=0
for r in [m.mpf(1)/8,m.mpf(1)/4,m.mpf(1)/2]:
 for D in [m.mpf(1)/3,m.mpf(7)]:
  for M in [m.mpf(1)/100,m.mpf(11)]:
   for X in [m.mpf(1)/20,m.mpf(19)]:
    eps=m.mpf(1)/7; C=m.mpf(16)/3
    lhs=D*M**r*(C*X)**(1-r)
    rhs=eps*X+r*D**(1/r)*(((1-r)*C)/eps)**((1-r)/r)*M
    assert lhs<=rhs
    checks+=1
for n in [2,512,10000]:
 K=m.mpf(1); Lam=m.mpf(128)/119; eps=m.mpf(1)/7
 N=m.ceil(m.pi*m.sqrt(n)); B=m.e*N; A=4480/m.e**2
 D=m.mpf(3)/2*Lam*m.e**4*(K/3)**(m.mpf(1)/8)*m.sqrt(B*A)
 exact=13440*Lam**2*m.e**7*(K/3)**(m.mpf(1)/4)*N/eps
 assert m.almosteq(m.mpf(16)/3*D**2/(4*eps),exact)
 checks+=1
print('PASS',checks)
```

**Delivery status.** RL2 certifies the real receiver resource, including
rounded nodes under the actual all-scale ancestor band. RL4–5 expose
the exact missing source payment and are not registered as a new
paid branch. RL6 preserves the unused negative ledger without lending
it to the positive fractional majorant. No general closure is claimed.
