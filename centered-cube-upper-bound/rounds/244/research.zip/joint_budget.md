# R244：原 receiver/source 双容量的 Schur 界及交通嵌入的精确阻断

本轮证明一条常数完全显式、允许保留原 source/history mask 的联合 L² 容量。它同时使用真实 receiver hardband 与 R243 的实际分区列容量。将它嵌入原正交通后，具体尚未支付的是下文 JB4–5 的 receiver 平方响应和外层来源/score 平方预算；本轮没有由此取得新的交通 root 付款，也不改变 R243 的低 J 补域。

## JB1. 原对象、X 与双容量资格

保 R243 的同一有限截断、原 β,ν≤f、真实 source-independent 物理 partition Ω_{V,i}、节点 R_i∈[a,b]、完整 ν-posterior、FIRST/FULL/history/capture 及原低 J 来源集 N_z。固定原 λ，q∈[3λ/4,λ]，X=λ|E|。每个 receiver 至多有一个正的原 terminal leaf V（R107:109–120）；概率 seed 只作平均，不按数量相加。

原 hardband 是所有尺度的约束：GENERAL_CURRENT_REDUCTION.md:5–13 定义 G0=sup_(a≤R≤b)h_R*f，并在原 E 上保 G0≤4λ。因此在同一个原 receiver 域，对全部 rounded R_i∈[a,b]，

\[
 (h_{R_i}*\nu_V)(x)\le4\lambda\le C_0q,
 \qquad C_0=16/3. \tag{JB1.1}
\]

这里无需把 rounded hard 核换回 selected hard 核。单凭 selected-scale 简写不能推出此式，但原 all-scale 祖定义确实授予它。不得将 receiver 扩到 E 外或将尺度扩到 [a,b] 外后继续使用。

对 α>0 令

\[
 w_i=(a/R_i)^{\alpha n},\qquad
 C_\alpha=1+\frac{1-(a/b)^{\alpha n}}\alpha\le1+1/\alpha.
\]

R243 实际不交分区给 Σ_iw_iO_i(z)≤Cα，O_i(z)=∫Ω_i h_Ri(x−z)dx。同轮 receiver_ledger.md RL2 已完整证明

\[
 \mathbb E\sum_{V,i}\int_V w_iO_i(z)\nu_V(dz)
 \le\min\{C_\alpha W_\nu,C_0X\}. \tag{JB1.2}
\]

第二个右端是 receiver 预算，不是 Wν；没有把它的 C0 系数自动视为可吸收小量。

## JB2. 新的一般联合 L² 容量，保原 mask

固定一叶的原资料。令 κ(x,z) 为任意可测 0≤κ≤1 的原正 mask，可以包含 N_z(y)、原 source-pair/history/capture 条件；其它参数必须先固定。定义

\[
 T_{\alpha,\kappa}F(x)
 =\sum_i1_{\Omega_i}(x)w_i^{1/2}
       \int_V h_{R_i}(x-z)\kappa(x,z)F(z)\nu(dz).
\]

对任何 F∈L²(ν)，

\[
 \boxed{\|T_{\alpha,\kappa}F\|_{L^2(dx)}^2
 \le C_0q C_\alpha\|F\|_{L^2(\nu)}^2.} \tag{JB2.1}
\]

证明先对简单 F，由同一 hard-source 测度上的 Cauchy，

\[
 \left|\int h_{R_i}\kappa F\,d\nu\right|^2
 \le\left(\int h_{R_i}\kappa\,d\nu\right)
       \left(\int h_{R_i}\kappa|F|^2d\nu\right)
 \le C_0q\int h_{R_i}|F|^2d\nu.
\]

乘 w_i，在真实 Ω_i 积分，Tonelli 后用 R243 列容量，即得 JB2.1。由密度延拓到 L²。没有要求 κ 对称、可分解或不依固定的外参数，也没有将 hard z 当作 posterior 槽。

归一化 q^−1/2T 的范数至多 sqrt(C0Cα)。量纲核对：若 F 无量纲，T 的量纲是 source 质量/体积；两侧平方积分均为质量平方/体积。

其 adjoint 为

\[
 T_{\alpha,\kappa}^*G(z)=\sum_i\int_{\Omega_i}
 w_i^{1/2}h_{R_i}(x-z)\kappa(x,z)G(x)dx,
\]

且 ||T*G||²_(L²ν)≤C0qCα||G||²_(L²dx)。这是明确已证的算子界，不是引入一个未付 operator norm 作为假设。

跨叶形式为

\[
 \mathbb E\sum_Vq_V^{-1}\|T_{V,\alpha,\kappa_V}F_V\|_2^2
 \le C_0C_\alpha\mathbb E\sum_V\int_V|F_V|^2d\nu_V.
 \tag{JB2.2}
\]

原 receiver 唯一叶使左侧可解释为真实 receiver 的分叶平方资源；种子仍只平均。若 α 随原外资料变，使用对应 Cα，不能提出一个未经控制的共同常数。

## JB3. full posterior 可作为外参数，但不会自动付平方预算

固定 j,y,t,v,u 后，原 full-ν Π_t 及 δ_t(v,u) 不依 receiver x、hard z。因而 κ 可取该原行 mask，JB2 可逐外参数应用。对任何非负外参数测度 μ，Tonelli 给

\[
 \int\|T_{\alpha,\kappa_\xi}F_\xi\|_2^2\mu(d\xi)
 \le C_0qC_\alpha\int\!\int|F_\xi(z)|^2\nu(dz)\mu(d\xi).
 \tag{JB3}
\]

特别 μ 可以保原 β(dy)dt/t·Π_t(dv)Π_t(du)，连同合法的有限截断和 j。它并不因此变成总质量一的测度。若把 sqrt(δ_t) 放入 Fξ，右侧仍包含真实 δ_t 的积分；同后验 Gini 仅给每时刻 n/4，而不是无条件根阶时钟预算。

也不能令 Fξ(z)=某个辅助 v 的密度后把 hard ν 积分认作 Π_t：hard z 的原门、分母及角色与辅助槽不同。JB3 保持这种区别，没有使用未消费负信用。

## JB4. 直接嵌入原母式：具体 F 与第一个未付平方项

先不使用 fractional-good 放大。固定 j,y,t,v,u，令

\[
 N^y=\{z\in V:y\in N_z\},\qquad F_y(z)=1_{N^y}(z).
\]

把 N 门从其余 κ 分开，其余原 history/good/capture/high 等仍是 0≤κ≤1。在已认证物理覆盖后，原母式的相应 receiver/source 列为

\[
 \mathcal C_y=q^{-1}\sum_{i:j_i=j}\int_{\Omega_i}
 p_{i,y}(x)\int h_{R_i}(x-z)\kappa(x,z)F_y(z)\nu(dz)dx,
 \quad p_{i,y}(x)=P_{s(x),L_i}(x-y).
\]

物理覆盖的 e⁴ 仍只在母式外一次，不包含在此列定义中。令

\[
 G_y(x)=\sum_{i:j_i=j}1_{\Omega_i}(x)w_i^{-1/2}p_{i,y}(x).
\]

则准确有 C_y=q^−1〈G_y,TκF_y〉，因此

\[
 \boxed{\mathcal C_y\le
 \sqrt{C_0C_\alpha\,\nu(N^y)/q}\;
 \left[\sum_{i:j_i=j}\int_{\Omega_i}
       w_i^{-1}p_{i,y}(x)^2dx\right]^{1/2}.} \tag{JB4.1}
\]

source F_y 的平方积分恰为 ν(N^y)，不是一个新测度。但它尚须按原 β(dy)及正 score/clock 积分，不能每个 y 都将这份质量当成同一 Wν 只付一次。

receiver 侧的平方项也不是 FIRST 已付响应。原 FIRST 授 ∫p_i,yβ(dy)≤q；结合 p_i,y≤L_i^−n 最多直接给

\[
 \int\|G_y\|_2^2\beta(dy)
 \le q\sum_{i:j_i=j}L_i^{-n}
                 \int_{\Omega_i}w_i^{-1}dx. \tag{JB4.2}
\]

这仍是含逆尺度和逆权的真实 receiver 体积。粗化为 qa^−n(b/a)^(αn)|E| 没有得到所需 input/source 预算，也不能免费换为 Wν。与外层 ν(N^y)、score 及 clock 配合需要新的共同几何估计。这个明确的平方项是直接应用 Schur 的第一处阻断，不是只笼统地说算子“尚未可用”。

## JB5. half-column 的平方项与原分母

若用一个在 hard z 积分前固定的 θ=1/2 对原 fractional-good 三腿作同样尝试，receiver 因子变成

\[
 G_{y,v}^{(1/2)}(x)=
 \sum_{i:j_i=j}1_{\Omega_i}(x)
 \frac{\sqrt{p_{i,y}(x)Q_i(x,v)}}
      {\sqrt{w_i\,\bar w_{c g_i^*}(y,v)}}.
\]

因此其**确切平方范数**为

\[
 \sum_{i:j_i=j}\int_{\Omega_i}
 \frac{p_{i,y}(x)Q_i(x,v)}
      {w_i\,\bar w_{c g_i^*}(y,v)}dx. \tag{JB5.1}
\]

不得把 R243 随 z 优化的 θ_z 从 hard 积分中直接提出；这里固定 θ 只是检验该合法 half-column 嵌入。JB5.1 的完整 Π_t(v) 平均仍包含

\[
 \frac1{e_t(y)}\int_{Z_t(y)}
 Q_i(x,v)\frac{w_t(y,v)}{\bar w_{c g_i^*}(y,v)}\nu(dv).
 \tag{JB5.2}
\]

它不是概率质量一。目标 FIRST 容量即便适用，也先有真实 w_t/w* 比与 e_t(y)；e_t 不能在 β(y) 积分后当作共同分母。若再附 δ_t，所得仍是原两槽正 score 平方预算，而不是 hard-source 的 F_y² 质量。由此既不能把 square 根阶付款，也不能将原负项系数贴到已经上放的正列上。

## JB6. 原 source Hölder 的精确剩余因子

为把下一步所需的共同几何定位到可计算原量，保 R243 的每纤维 I_i(y,z)，定义

\[
 a_i(z)=\int_{N_z}I_i(y,z)\beta(dy)\le qO_i(z),\quad
 m=m_N(z)=\int_{N_z}e^{-J_z(y)/2}\beta(dy),\quad
 K_i=BM_i^{-n}e^{2j_ih}.
\]

若 a_i=0 或 m=0，该正 source 行先置零。其余相对于 β|N_z 定义概率密度

\[
 p_i(y)=I_i(y,z)/a_i(z),\quad
 q_z(y)=e^{-J_z(y)/2}/m,\quad
 \tau_i(y,z)=I_i(y,z)e^{J_z(y)}/K_i\in[0,1].
\]

对 R243 的 0<r≤1/2，令

\[
 L_{i,r}(z)=\int_{N_z}p_i(y)^{1-r}q_z(y)^r
                         \tau_i(y,z)^{r/2}\beta(dy).
\]

直接相乘给准确恒等式

\[
 \boxed{\int_{N_z}I_i^{1-r/2}d\beta
       =K_i^{r/2}a_i^{1-r}m^r L_{i,r},\qquad
       0\le L_{i,r}\le1.} \tag{JB6.1}
\]

后一界是概率密度 Hölder 与 τ≤1。令 η_i=a_i/(qO_i)∈[0,1]，R243 的真实正节点上界可以加强为

\[
 \frac {X_i}4(B\rho_N)^rO_i^{1-r}e^{-r(j_ih+X_i)}
                 \eta_i^{1-r}L_{i,r}. \tag{JB6.2}
\]

这里 X_i=nlog(M_i/M_{0,i}) 是 R243 的节点坐标，与外 receiver 预算 X=λ|E|不同。JB6.1 仅在那个 source-power 步骤是恒等式，**不是**已经过 fractional/QG/Gini 上界的整个母式恒等式。

这精确指出高 ρ_N 收费是在把 actual FIRST 利用率 η_i、同来源响应/加权质量的 affinity，以及真实窗口包络 slack τ_i 一并放成一时发生的。它们仍取自同一原 β、同一 hard z、同一 receiver 纤维，不能各自独立最坏化后再声称保留相关性。

## JB7. 本轮结论与最短尚缺步骤

JB2 是已证、常数可支付的联合 L² 几何工具；JB4–5 实际尝试了原母式及 half-column 嵌入。没有因此获得新的原交通付款。

具体尚缺的共同几何步骤有明确原变量表达：必须控制 JB4.1 的外层 β/clock/score 加权平方乘积，或在 JB5.2 原分母保留时支付其 paired-density 平方项；等价的 source-Hölder 路径必须定量利用 JB6.2 的 η_i^(1−r)L_{i,r} 与高 ρ_N 的共同依赖。只用它们≤1会精确退回 R243，不能削减高 H 尾。

同轮 receiver_ledger RL3 已给出仅用双总容量后作 Young 的完整收费：εX 的源项包含原一阶 ρ 矩；r≈1/H 时还出现 ε^−(1−r)/r。这个步骤没有给新 root 付款，亦不优于既有 H² 界。因此本稿不重写它为成果，不把 q|E|当W，不借原未匹配负信用，也不新增一个来源门。

## JB8. 本机数学工具检查

本机 numpy 实际做3个一维 hard-operator 离散检查：receiver 网格为 [−2,2] 的步长 .025 中点，source 网格为 [−3,3] 的同样中点，ν=.5dz，q=1，R(x)=1 当x<0、否则2，α∈{.1,.5,1}。矩阵条目为 sqrt(dx)sqrt(w_i)h_Ri(x−z)sqrt(.5dz)，其最大奇异值平方依次为

    0.4804759849537857, 0.4614894135436945, 0.4507327181097621.

对应 C0qCα 为8.904907118036938、8.457527667343491、8，全部检查通过。离散中点不是区间认证；这些只是实际核和量纲的有限数值检查，不是 FULL/history 或 root 预算证据。严格算子证明为 JB2。

作者仅创建/修改 joint_budget.md，不变更其它责任文件、来源、posterior 或母账，不提交仓库；本轮到此有界交付。
