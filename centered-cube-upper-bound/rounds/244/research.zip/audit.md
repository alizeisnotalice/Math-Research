# R244 独立审查

## 命题先行检查点（尚未读本轮作者稿）

已实读本轮task_contract；此前首次访问尚未落盘，未据缺失文本推断资格。沿R243真实Ω_{V,i}、同一β/ν和完整Π，只审准确新接口，不另开反例探索。仅写audit.md，不Git/PDF/spawn或改他人文件。

### 1. 原ALL-R资格：已纠正初始疑问并独立核明

独立实读master GENERAL_CURRENT_REDUCTION.md §1原文：`Work on 2lambda<G0<=4lambda, G_s=sup_(a<=L<=b)P_s,L*f`。s=0为hard核，所以原G0确是全部合法hard尺度的sup；当前原E继承该band。R128 RT1只显示selected R(x)的简写，单靠它不能推出上取整尺度帽，但它没有否定master的全band。R231/R239已核的ALL-R资格与本轮contract一致，不能将初步“仅selected R”的疑问改写成旧证明缺陷。

每个合法node R_i仍在[a,b]，故在原E上 `h_{R_i}ν_V≤h_{R_i}f≤4λ≤C₀q`，C₀=16/3。这来自原全band，**不是**由e⁴ upward覆盖反向推出：若真的只有selected R帽，h_actual≤e³h_node的方向不能给node convolution上帽。

### 2. 真正可合并的receiver预算

R107的实际完整硬赢家唯一终端leaf、R243 source-independent Ω_{V,i}互斥，确保每个receiver x至多一个原V/i。Tonelli对同一原ν给

`A_α=EΣ_{V,i}∫(a/R_i)^{αn}O_i(z)ν_V(dz)`

`=EΣ_{V,i}∫_{Ω_{V,i}}(a/R_i)^{αn}h_{R_i}ν_V(x)dx`

`≤4λ EΣ_V|E_V|≤4X≤C₀X`。

同时由R243精确weighted column，`A_α≤C_α Wν`，`C_α=1+[1−(a/b)^{αn}]/α`。因此已知真实共同预算是 `A_α≤min(C_α Wν,4X)`。外种子为原概率平均，不另乘一次Λ；q若固定于原外资料仍保该资料内的常数。若将Ω放大出原E、或将源依门投影成互斥Ω，则此回代不再获授权。

actual-hard替代桥也可成立，但当前主路线无需重做它：保h_actual，半列比较与pointcap分别付e^{2θd_h}、e^{ηd_h}，只合e^{r d_h}；软覆盖损失d_s与硬损失d_h在两朝向为(1,3)/(3,1)，总d_s+rd_h≤4 (r≤1)。可以沿用一份e⁴，不能再叠收e³r与旧全物理e⁴。此仅作初筛资格记录，不扩大本轮主命题。

### 3. 新正算子工具：通过，但它是已知两容量的直接推论

对固定outer及leaf的共同源函数 F_V(z)∈L²(ν_V)，在Ω_{V,i}定义

`(T_α F)(x)=sqrt(w_i)∫h_{R_i}(x−z)F_V(z)ν_V(dz)`，`w_i=(a/R_i)^{αn}`。

逐x的真实同源Cauchy给

`|T_αF(x)|²≤C₀q∫w_i h_{R_i}(x−z)|F_V(z)|²ν_V(dz)`。

随后真实dx积分与R243 exact C_α列帽给

`||T_α F||²_{L²(dx)}≤C₀q C_α Σ_V||F_V||²_{L²(ν_V)}`。

唯一receiver leaf使左端是原联合receiver范数而非重复域；先对有限截断证明，再正单调延拓。外概率种子平均可同样保留；q为该原固定资料的共同常数，不跨不同q资料无价提出。实/复/有符号F均可用绝对平方Cauchy，未假设来源独立。

这确是R243 column与原ALL-R row帽的直接推论，不是新的交通付款。F必须是receiver/index无关的共同source函数（可依预冻结外资料/V）。若实际响应为F_i(z)、F(x,z)、或依不同j/y/t的posterior，再用同一个source L²范数需要另证向量/共同能量预算；不能自行取消这些标签。

真正足以形成原付款的最小接口例是：先证明原量被 `C E∫G(x)T_αF(x)dx` 支配，且原完整资料上的 `EΣ∫|F|²ν≤cW`、`E∫|G|²dx≤c'X/q`均已付款。这样才得 `C sqrt(C₀C_α cc' XW)`并可Young吸收。由于T_α含sqrt(w_i)≤1，原hard交通没有这个衰减时必须支付相应w_i^{-1/2}，通常进入receiver G²或source能量；不能因算子范数小就将它免费加入。原half-density/Π到这种F²的确切嵌入是目前最早未证步骤之一。

### 4. Young吸收的精确代价，不是假root

对A,B,C≥0和0<r<1，直接最大化A得

`C A^{1−r}B^r≤εA+r(1−r)^{(1−r)/r}C^{1/r} ε^{−(1−r)/r}B`。

若只知A≤C_X X，欲付εX须取左式Young参数ε/C_X，故余价含 `(C_X/ε)^{(1−r)/r}C^{1/r}`。当r=1/H时，这正是 `(C_X/ε)^{H−1}C^H`，不能藏进维数无关常数。r_z随原源变化时，应在共同正测度上逐点用同一可积receiver预算，不能先把不同r_z当一个全局指数。A≤C₀X只是可用容量，不等于εX或Wν。

### 5. 同源Holder真正可保的slack与KL方向

对固定实际列I_i(y,z)、A_i=∫_F I_iβ>0、m_p=∫_F e^{-pJ}β>0，定义同一β上的概率密度 `a_i=I_i/A_i`、`b=e^{-pJ}/m_p`。则Holder保留的affinity是 `Aff_r=∫a_i^{1−r}b^rβ≤1`，而Jensen严格给

`Aff_r≥exp(−r KL(a_i||b))`。

所以“大KL ⇒ 小affinity”的方向不获授权。对有限真实几何分区可用 `Aff_r≤Σ a_i(E_k)^{1−r}b(E_k)^r`，或初等加权AMGM的 `1−Aff_r≥min(r,1−r)Σ(√a_i(E_k)−√b(E_k))²`。需要这些概率来自同一原I_i/β，而不是独立拟合来源。

若点帽为I_i≤C_i e^{-J}，η=pr、r=2θ+η，则source Holder部分精确保留

`C_i^η A_i^{1−r}m_p^r ∫a_i^{1−r}b^r[I_i/(C_i e^{-J})]^ηβ`。

因此原node majorant可保FIRST slack `(A_i/(qO_i))^{1−r}`、该affinity及点帽亏损。A_i=0/O_i=0/m_p=0的实际行先置零。仅有不等式严格或一个未定量的entropy名称不够；还必须在原节点、clock、原来源系数下证明可付错配，足以抵消上述Young指数价格。当前没有这样的普遍错配或原F²预算证明。

### 6. 实际工具核验与初筛状态

实际执行42项有界本机诊断：9项Fraction连续一维Schur/Cauchy例（ν=1_[−3,3]、F在两半分别1/−2，receiver两纤维取R1/2，α=1,2,3）；24项Young最优点等式与9项KL-affinity方向普通浮点检查，全部通过。这些是临时未归档工具例，不列正式receipt、非区间/FULL。解析依据见上，不从有限例推一般闭合。

当前准确初筛结论：两种容量、Schur几何工具和精确slack/Young接口成立；它们均未自动支付原完整低J交通的root目标。尚未读本轮作者稿，待准确新原量嵌入后审核。


## 同轮新增嵌入的独立筛查（未读作者推导）

固定y，`F_y(z)=1_{y∈N_z}`确为receiver/index无关的共同source函数，`||F_y||²_ν=ν{z:y∈N_z}`。它保真实原source gate；但再积β得到 `∫β||F_y||²ν=∫νβ(N_z)`，不是已付Wν。若其它依hardz的原history/capture等χ被正放以实现此factorization，不能随后当作仍保留的half-QG支持使用。

对应原kernel若用 `G_y(x)=w_i^{-1/2}P_{s(x),L_i}(x-y)`，逐点 `P²≤L_i^{-n}P` 与原actual FIRST只能给

`∫β||G_y||²_dx ≤ qΣ_i L_i^{-n}∫_{Ω_i}w_i^{-1}dx`。

这个显示的inverse-weight/密度/receiver-volume费用未自动变为X/q或W。half-density版本的G²含 `pQ/(w_i w_star)`，再带完整Π会出现实际w_t/w_star和e_t等来源权，仍须在同y的真实测度下支付；不得在β积分后将Π当作共同概率。

允许source-only α(z)>0时，定义kernel `sqrt(w_i(z))h_{R_i}`、w_i(z)=(a/R_i)^{α(z)n}，同一逐x Cauchy及逐z column严格给 `||T F||²≤C₀q∫C_{α(z)}|F|²ν`。这是有价source能量界，不能无价取其sup或把该能量当input mass；嵌回原traffic时inverse sqrt(w_i(z))还依i,z，分离进一个receiver函数需另证。故目前真正完成的是几何Schur工具与精确嵌入/费用定位，非一般原交通root预算。


## 作者稿后终审与冻结结论

**通过本轮所声明的工具、费用定位与有限证据范围；不认证新增原交通付款或一般根阶闭合。** 已完整审核 joint_budget.md、receiver_ledger.md、主 proof.tex.txt，并核最终 report.md/reproduce.py。最终主稿的 source-only α(z) 权明确放在ν积分内，保留 ∫C_{α(z)}|F|²ν；不是把依z的权移到积分外。

- JB2 的 masked Schur 对任意原正门0≤κ(x,z)≤1成立，不要求κ分离；共同源函数与实际不交receiver纤维、q的外资料位置均正确。其来源是R243列资源与原ALL-R行帽的直接推论。放松κ后不得再利用已丢捕获门声称额外QG。
- JB4 的 F_y=1_{N_z}(y) 和 G_y=w_i^{-1/2}P 的原量配对合法，但 ∫β||F_y||²ν、逆权receiver平方均未付。JB5 保固定half指数及 pQ/(w_i wstar)，完整Π仍含 w_t/wstar/e_t(y)，没有把hard-z替换为辅助后验槽。JB6 的 FIRST利用率、同源affinity和点帽slack是准确source-power恒等式；先半列majorant、同y的Gini/time，再β积分的次序可用，不是整个原母式等式或已经足够的亏损预算。
- receiver_ledger 的固定r=.5混合桥及Young系数 13440Λ²e⁷(K/3)^{1/4}N/ε 核对通过；未知来源矩M保留。一般r的ε^{−(1−r)/r}亦保留，未伪称维数无关吸收。原两负信用只可按同一signed母账各用一次；正majorant不能无价套到负项。RL6为其实际公式编号，不是缺失的第六节。
- 本人已实际独立执行 receiver_ledger 内嵌27项，输出PASS 27。初筛42项仅临时未归档诊断，不列正式复现证据。joint_budget作者三项矩阵诊断不冒称本人重跑。

### 最终数值与驱动静审

最终 numeric_checks.py/JSON/notes 已静审，读取原始JSON计数和全部14项证书摘要：8种真实连续正L1盒几何、23算子配置、14个Fraction LDL/Rayleigh配置，源码及合同内置hash与实际文件一致。每对source/receiver盒以精确端点作全包含/全排除，最小正margin为3/32；来源密度上界给全部R行帽，另算selected行帽，二者未混。真实核在每对盒上常值，任意F只经source-cell均值影响输出，cell内零均值分量映至零，因此矩阵确给该连续输入的完整L²算子范数。精确PSD矩阵为 diag(√μ)(L Id−AᵀA)diag(√μ)，Fraction消元保零pivot剩余列为零的守卫；不是仅核几个测试向量。

mp40/70谱计算为普通高精度诊断，主要字段最大相对变化5.81135921869955e−41；enc50不等于50位正确数字。Fraction几何/14项PSD与普通特征值证据分开。小盒稀疏性导致的小绝对范数不作普遍几何增益；未构造原FULL/history或交通F²预算。最后本人只作代码/JSON/notes静审，完整数值重放的执行证据属于数值作者；冻结包外全JSON与27项重放由主代理随后执行，不能在本审核提前宣称该回执已完成。

reproduce.py 将源码和合同复制至包外新目录，比较完整JSON，提取ledger内嵌27项并核PASS 27，执行前后核manifest；输入输出位置不混，回执外置。报告对未付平方项、Young价格、无新增交通付款及数值非FULL范围与证明一致。文献阅读仅外部背景，不是本轮证明依赖。

### 最终受审版本（SHA256）

以下九文件在最终静审时冻结；不绑定audit自身、未来manifest或外置回执。

| 文件 | SHA256 |
|---|---|
| task_contract.md | `28c225ebece5c2e7868a0b4fe75e3429e4ec02d9d9c551a40e8b541f197ad507` |
| proof.tex.txt | `b2ff2a118b7790c7464891ef99b0afb136de7b3e1643a372a8e772c2ab653c72` |
| joint_budget.md | `f78a8191ef94fc8c0040af1b69273b23a33d4f2708b6da3f673460e2f6d30c65` |
| receiver_ledger.md | `d9c586f84fcd518784b21f620a09591c8d0c6f91aed9525e932f89e7425c34a3` |
| numeric_checks.py | `015ca341bf24ad3a2c75db8562f0406c3404721174421492f165d2541cea1aea` |
| numeric_checks.json | `afae3727b466464b3386ddda1fe6939cac3f6a8316bb602dd0b810c5a1b1657b` |
| numeric_notes.md | `348e0ac130fdbec5955874185cab75919d511054ecca8cf9206ba932a7e04094` |
| report.md | `ca8dda04b69df6ae1ea2c843fb079c58a7387eb02e36cdc1dea40448b4747ac8` |
| reproduce.py | `55c193b85aca584e6ea6c137c3aca4d1c1a305a87b343ba00bac2a9254e2a3ff` |

审核文件至此冻结。剩余实质缺口仍是原完整Π及来源门下共同source/receiver平方能量或量化slack预算，不能由本轮算子范数、正容量或有限模型代付。
