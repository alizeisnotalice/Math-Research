#!/usr/bin/env python3
"""Exact box incidences for true continuous L1 kernel operator, not FULL."""
import argparse,hashlib,itertools,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
ROOT=Path(__file__).resolve().parent

def mf(v):return mp.mpf(v.numerator)/v.denominator if isinstance(v,F) else mp.mpf(v)
def enc(v):return mp.nstr(v,50)
def prod(xs):
 out=F(1)
 for x in xs:out*=x
 return out

def geometry(name,n,shape,count=0,C=F(1),equal=False,zero=False,tensor=False):
 if shape=='grid':centers=[list(map(lambda x:F(x,4),p)) for p in itertools.product((-1,0,1),repeat=n)]
 elif shape=='corner':centers=[list(map(lambda x:F(x,4),p)) for p in itertools.product((-1,1),repeat=n)]
 else:centers=[[F(2*k-count+1,8)]+[F(0)]*(n-1) for k in range(count)]
 half=[F(1,64)]+([F(1,8)]*(n-1) if tensor else [F(1,64)]*(n-1));receivers=[[x+F(1,8)+(F(10) if zero and i==0 else 0) for i,x in enumerate(c)] for c in centers];sourcevol=prod(2*h for h in half);volumes=[sourcevol]*len(receivers);densities=[C/F(j%3+1) for j in range(len(centers))];masses=[sourcevol*d for d in densities];Rs=[F(1) if equal else (F(1),F(3,2),F(2))[i%3] for i in range(len(receivers))];b=F(1) if equal else F(2);inc=[];margins=[]
 for coll in (centers,receivers):
  for j,k in itertools.combinations(range(len(coll)),2):assert any(abs(coll[j][d]-coll[k][d])>=2*half[d] for d in range(n))
 for x,R in zip(receivers,Rs):
  row=[]
  for z in centers:
   maxdist=[abs(u-v)+2*h for u,v,h in zip(x,z,half)];mindist=[max(F(0),abs(u-v)-2*h) for u,v,h in zip(x,z,half)];inside=all(t<=R/2 for t in maxdist);outside=any(t>=R/2 for t in mindist);assert inside!=outside
   row.append(int(inside));margins.append(min(R/2-t for t in maxdist) if inside else max(t-R/2 for t in mindist))
  inc.append(row)
 rows=[sum(mu*flag for mu,flag in zip(masses,row))/R**n for R,row in zip(Rs,inc)];assert max(rows)<=C and min(margins)>0
 return dict(name=name,n=n,C=C,q=3*C/16,b=b,centers=centers,receivers=receivers,half=half,volumes=volumes,densities=densities,masses=masses,Rs=Rs,inc=inc,row_masses=rows,min_margin=min(margins))
def serialize_geometry(g):
 return dict(n=g['n'],source_centers=[[str(x) for x in p] for p in g['centers']],receiver_centers=[[str(x) for x in p] for p in g['receivers']],halfwidths=list(map(str,g['half'])),nu_densities=list(map(str,g['densities'])),nu_masses=list(map(str,g['masses'])),receiver_volumes=list(map(str,g['volumes'])),R=list(map(str,g['Rs'])),incidence=g['inc'],selected_row_hard_masses=list(map(str,g['row_masses'])),density_allR_cap=str(g['C']),q=str(g['q']),C0='16/3',a='1',b=str(g['b']),strict_pair_margin=str(g['min_margin']),source_count=len(g['masses']),receiver_count=len(g['Rs']),allR_reason='Disjoint continuous source boxes with nu density<=C; every normalized h_R average<=C for all x,R, not just selected nodes.',operator_reduction='Kernel incidence constant on each source/receiver pair; dependence on arbitrary F only through its cell means. Orthogonal within-cell zero-mean F maps tozero, so finite matrix gives exact full operator norm.')

def ldl_nonnegative(D):
 A=[row[:] for row in D];piv=[];n=len(A)
 for k in range(n):
  p=A[k][k];assert p>=0;piv.append(p)
  if p==0:assert all(A[i][k]==0 for i in range(k+1,n));continue
  for i in range(k+1,n):
   for j in range(i,n):A[i][j]=A[j][i]=A[i][j]-A[i][k]*A[j][k]/p
 return dict(nonnegative=True,positive_pivots=sum(p>0 for p in piv),zero_pivots=sum(p==0 for p in piv),minimum_positive_pivot=str(min([p for p in piv if p>0],default=F(0))),pivot_sha256=hashlib.sha256('|'.join(map(str,piv)).encode()).hexdigest())
def exact_certificate(g,alpha):
 exponent=alpha*g['n']
 if exponent.denominator!=1:return dict(rational_PSD_branch=False,scope='Geometry exact but this certificate branch requires alpha*n integer; noninteger cases use ordinary mpmath even if a special equal-band case has rational weights.')
 n=g['n'];weights=[R**(-exponent.numerator) for R in g['Rs']];mu=g['masses'];vol=g['volumes'];inc=g['inc'];rows=g['row_masses'];columns=[sum(w*v/R**n*row[j] for w,v,R,row in zip(weights,vol,g['Rs'],inc)) for j in range(len(mu))];col=max(columns);row=max(rows);L=row*col;Cap=1+(1-g['b']**(-exponent.numerator))/alpha;assert col<=Cap
 B=[[mu[j]*mu[k]*sum(w*v/R**(2*n)*flags[j]*flags[k] for w,v,R,flags in zip(weights,vol,g['Rs'],inc)) for k in range(len(mu))] for j in range(len(mu))];D=[[(L*mu[j] if j==k else F(0))-B[j][k] for k in range(len(mu))] for j in range(len(mu))];cert=ldl_nonnegative(D);ray=[]
 vectors=[[F(1)]*len(mu),[F((-1)**j) for j in range(len(mu))],[F(1,j+1) for j in range(len(mu))]]
 for vec in vectors:
  den=sum(m*f*f for m,f in zip(mu,vec));num=sum(w*v*(sum(m*f*flag for m,f,flag in zip(mu,vec,flags))/R**n)**2 for w,v,R,flags in zip(weights,vol,g['Rs'],inc));Q=num/den;assert Q<=L;ray.append(str(Q))
 assert L<=g['C']*Cap
 return dict(rational_PSD_branch=True,theorem_bound_exact=str(g['C']*Cap),selected_schur_le_theorem=True,weighted_column_exact=str(col),selected_row_exact=str(row),finite_Calpha_exact=str(Cap),finite_schur_bound_exact=str(L),Rayleigh_exact=ray,LDL_psd_defect_certificate=cert,scope='Exact Fraction finite true-geometry upper certificate (row*column) for all cell-mean F; not a proof of general theorem by samples.')

def evaluate(g,alpha,dps):
 with mp.workdps(dps):
  n=g['n'];a=mf(alpha);ws=[mf(R)**(-a*n) for R in g['Rs']];mus=list(map(mf,g['masses']));vs=list(map(mf,g['volumes']));Rs=list(map(mf,g['Rs']));rows=list(map(mf,g['row_masses']));columns=[sum(w*v/R**n*flags[j] for w,v,R,flags in zip(ws,vs,Rs,g['inc'])) for j in range(len(mus))];col=max(columns);row=max(rows);Calpha=1-mp.expm1(-a*n*mp.log(mf(g['b'])))/a;G=mp.matrix(len(mus))
  for j in range(len(mus)):
   for k in range(len(mus)):G[j,k]=mp.sqrt(mus[j]*mus[k])*sum(w*v/R**(2*n)*flags[j]*flags[k] for w,v,R,flags in zip(ws,vs,Rs,g['inc']))
  eigen=mp.eigsy(G,eigvals_only=True);norm=max(mp.mpf(0),eigen[eigen.rows-1]);tight=row*col;theorem=mf(g['C'])*Calpha;tol=mp.mpf(10)**(-dps+8)
  ones=sum(w*v*rr*rr for w,v,rr in zip(ws,vs,rows))/sum(mus)
  assert norm>=max(G[j,j] for j in range(len(mus)))*(1-tol) and norm>=ones*(1-tol)
  assert col<=Calpha*(1+tol) and norm<=tight*(1+tol)+tol*mp.mpf('1e-50') and tight<=theorem*(1+tol)
  return {k:enc(v) for k,v in dict(alpha=a,operator_norm=mp.sqrt(norm),norm_squared=norm,all_ones_Rayleigh=ones,selected_row_cap=row,density_allR_cap=mf(g['C']),actual_weighted_column_on_nu=col,finite_Calpha=Calpha,coarse_1_plus_1_over_alpha=1+1/a,selected_schur_bound=tight,theorem_bound=theorem,norm_over_selected_schur=norm/tight if tight else mp.mpf(0),norm_over_theorem=norm/theorem).items()}

def main(output,contract):
 gs=[geometry('line1',1,'line',5),geometry('grid2',2,'grid'),geometry('corner3',3,'corner'),geometry('equal_band',1,'line',8,equal=True),geometry('zero',2,'line',3,zero=True),geometry('expanded3',3,'line',12,tensor=True),geometry('tensor8',8,'line',12,tensor=True),geometry('scaled_density',2,'grid',C=F(3))];menu=[]
 for g in gs:
  alphas=[F(1,g['n']),F(1),F(1,10**6)] if g['name'] not in ('equal_band','zero') else [F(1),F(1,10**6),F(10)] if g['name']=='equal_band' else [F(1,2),F(1,10**6)]
  if g['name']=='line1':alphas=[F(1),F(1,10),F(1,10**6)]
  for alpha in alphas:menu.append((g,alpha))
 results=[];maximum=mp.mpf(0)
 for g,alpha in menu:
  low=evaluate(g,alpha,40);high=evaluate(g,alpha,70)
  with mp.workdps(100):
   fields=['norm_squared','actual_weighted_column_on_nu','finite_Calpha','selected_schur_bound'];diffs={k:abs(mf(low[k])-mf(high[k]))/(abs(mf(high[k])) if mf(high[k]) else 1) for k in fields};err=max(diffs.values());assert err<mp.mpf('1e-25');maximum=max(maximum,err)
  results.append(dict(geometry=g['name'],stage='initial' if g['name'] in ('line1','grid2','corner3') else 'pressure' if g['name'] in ('equal_band','zero') else 'expanded',alpha_exact=str(alpha),mp40=low,mp70=high,relative_precision_differences={k:enc(v) for k,v in diffs.items()},relative_precision_max=enc(err),exact_rational_check=exact_certificate(g,alpha)))
 payload=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),contract_sha256=hashlib.sha256(Path(contract).read_bytes()).hexdigest(),geometries={g['name']:serialize_geometry(g) for g in gs},operator_cases=results,counts=dict(true_L1_geometries=len(gs),operator_cases=len(results),exact_rational_PSD_cases=sum(r['exact_rational_check']['rational_PSD_branch'] for r in results)),maximum_precision_relative_difference=enc(maximum),matrix_definition='A_ij=sqrt(receiver_volume_i*w_i*nu_mass_j)/R_i^n incidence_ij. eigmax(A^T A) gives squared true L2nu->L2dx operator norm, since all sourcecell zero-mean components are killed.',scope='True continuous finite box sources and disjoint receiver boxes; exact selected geometry/ALLR density cap, finite operator evidence and certificates; not FULL/history/general root or original traffic payment.',precision='mp40/70 spectral arithmetic,enc50 preserves40dps rounding; not interval eigenvalue certificate. Exact Fraction LDL/Rayleigh only when alpha*n integer. Source-supported weighted column is actual nu-essential supremum; no claim its value equals supremum outside nu support.')
 Path(output).write_text(json.dumps(payload,indent=2,sort_keys=True)+'\n');print(payload['counts'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',default=str(ROOT/'numeric_checks.json'));p.add_argument('--contract',default=str(ROOT/'task_contract.md'));a=p.parse_args();main(a.output,a.contract)
