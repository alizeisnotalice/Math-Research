# R244 finite true-box operator notes

Final actual scope:23 operator cases on8 true continuous L1 geometries;14 exact Fraction PSD certificates. Complete separate-output replay matches byte-for-byte.

Planned23 cases on8 continuous L1 geometries: n1 line5, n2 grid9, n3 corner8; equal-band and zero-incidence pressure; n3/n8 line12 tensor enlargement; n2 density scaling. Source centers use step1/4, receiver centers shift1/8. Small disjoint source/receiver boxes have enough margin that every pair is wholly inside or outside the assigned hard cube; exact Fraction checks reject ambiguous pairs. Thus finite matrices are actual continuous hard-kernel operators, not arbitrary matrices. Nu's piecewise density is bounded byC_density, proving an all-R hardcap; selectedrow is computed independently and never relabeled as that all-R cap. General FULL/history/source traffic is not constructed.

## Actual final counts and three stages

Actually ran23 operator parameter cases on8 true continuous L1 geometries;14 cases use the implemented exact Fraction PSD branch. Initial geometries are n1 line5, n2 grid9 and n3 corner8. Each uses alpha1/n,1,1e-6, except n1 replaces the duplicate1/n=1 byalpha.1. Pressure has n1 equal band a=b=1 with8cells andalpha1,1e-6,10, plus n2 positive-source/positive-receiver geometry with no incidences atalpha.5/1e-6. Expanded has n3 andn8 tensor line12 sources/receivers, and n2 grid density scaled by3, each alpha1/n,1,1e-6. There is no repeatedR243 radial selector or old soft-kernel menu.

Source cells have positive Lebesgue volume and positive piecewise-constant densities C_density/(j mod3+1); no source is an atom. Source and receiver centers use the fixed step1/4 grid with a1/8 receiver shift; small halfwidths are1/64. In tensor line models the additional coordinates instead have halfwidth1/8, while first-coordinate separation still makes all cells disjoint. Selected R cycles1,3/2,2, or is1 in the equal-band endpoint. The zero-incidence receiver geometry translates the first coordinate by10; its source measure is still positive. All centers, halfwidths, R, densities, volumes and incidences are saved as exact rational parameters.

## Geometry and the two actual capacities

Every sourcebox/receiverbox pair is checked with exact coordinate endpoint maxima/minima. It is wholly inside the selected hard cube or has a coordinate wholly outside. Ambiguous pairs are rejected. All eight geometries have strictly positive pair margins, with global minimum3/32; this is not a center-only incidence approximation. Source boxes and receiver boxes are independently checked disjoint. The hard-kernel matrix is derived from these exact geometry tests, not chosen arbitrarily.

Nu has density<=C_density everywhere. Hence for EVERY x and EVERY positiveR, integral h_R(x-z)nu(dz)<=C_density by normalization of h_R, proving the all-R upper-cap part by construction. C0=16/3 and q=3C_density/16 are explicitly recorded. This argument does not supply original lower-band, FIRST, leaf/history or FULL qualification. The selected-row masses are also computed exactly as sum_j incidence_ij nu_mass_j/R_i^n; their maximum C_selected is often much smaller thanC_density. The script never relabels C_selected as an all-R cap.

The actual source-supported weighted column is sum_i w_i receiver_volume_i/R_i^n incidence_ij on sourcecellj, with w_i=R_i^(-alpha n). Its maximum is the true nu-essential supremum. The code does not claim that this value equals the supremum outside nu's support, which the operator norm does not need. It checks this actual column against finite C_alpha=1+[1-b^(-alpha n)]/alpha and separately records the weaker1+1/alpha. Stable expm1 evaluates smallalpha. At b=a the exact finite bound is1 for allalpha, while1+1/alpha can still be large; no limiting cost is silently discarded.

## Exact finite matrix is the full L2 operator, not just sampled F

On each receiver cell, the hard incidence is constant over every source cell. Thus TF depends only on the actual source-cell mean F_j=(1/nu_mass_j)integral_cell Fdnu. Replacing F by these cell means preserves its output and weakly decreases its L2(nu) norm, with equality for cell-constant functions. The orthogonal within-cell zero-mean part is killed by T. Consequently the matrix

    A_ij=sqrt(receiver_volume_i*w_i*nu_mass_j)/R_i^n incidence_ij

has EXACTLY the full continuous L2(nu)->L2(dx) operator norm for this input, not merely the norm of a sampled restriction. Its largest singular value and squared value are computed via the largest eigenvalue of A^T A. The spectral value is cross-checked against diagonal and all-ones Rayleigh lower bounds. These numerical eigenvalues are not interval certificates.

For the14 cases withalpha*n integral, allw_i andC_alpha are rational. The independent exact routine forms the full quadratic form B_jk=nu_mass_j nu_mass_k sum_i w_i volume_i R_i^(-2n)incidence_ij incidence_ik and checks

    (C_selected*column_max) diag(nu_mass)-B >=0

by Fraction LDL congruence, including zero pivots only when the remaining pivot column vanishes. Explicitly D=diag(sqrt(mu)) [L Id-A^T A] diag(sqrt(mu)), L=C_selected*column_max, and all mu_j>0. Thus the rational LDL certificate is congruent to the Euclidean cell-mean operator bound; the within-cell zero-mean L2 part maps tozero. This is an exact finite-input upper certificate for ALL L2 functions by the cell-mean reduction above, not only three trial vectors. Three additional all-ones/alternating/rational-decay Rayleigh quotients are also evaluated exactly. The exact selected bound is checked<=C_density*C_alpha. Only pivot summaries/hash are saved to avoid a bulky full matrix dump; rerunning recomputes every rational pivot. The implemented rational branch requiresalpha*n integer; a noninteger equal-band case can have trivial rational weights but is intentionally not counted as an exact certificate.

## Actual numerical results and limits

All inequalities pass. Nonzero norm_squared/(C_selected*actual_column) ranges approximately.3605128971 to.7570441031. Actual column/C_alpha is at most.125. For n1 line5, alpha1 the squared norm is.00377133503921; for n2 grid alpha1/2 it is1.5574127578621e-5; the corresponding density-times3 case gives4.6722382735863e-5. Equal-band norm_squared is.00837874332868 at all threealpha, as weights are1. Zero-incidence cases correctly have zero operator despite positive source/receiver volume. Expanded n8 tensor values are about9.74e-12 to9.77e-12.

The small source/receiverboxes intrinsically suppress absolute operator norms. Those small values are NOT attributed to a universal geometric gain or interpreted as root-order traffic payment. The informative local comparison is with the actual selected row and weighted column; the global density Schur bound is deliberately looser in these sparse-support models. No original source-response function F from traffic/Π is constructed, and no bound on its source L2 norm is supplied. The original remaining payment step is not solved by merely knowing this operator norm.

All23 cases are independently evaluated at40/70dps with50 displayed digits preserving actual40dps rounding, rather than truncating both to32digits. Major-field relative differences are computed at100dps and retained percase. Maximum observed relative precision change is about5.81135921869955e-41. Extra displayed digits do not turn the40dps run into50 correct digits; spectral agreement remains an ordinary refinement diagnostic, not a rigorous error bar. Geometry and the14 rational PSD cases are exact arithmetic as separately labeled, with no numerical quadrature or omitted source/receiver integration tails.

The sourceHolder slack identity supplied later by peak was not turned into another numerical menu, per the parent's explicit stop-scope instruction. This script supports the actual Schur tool only and does not reclassify the whole original traffic identity or certify FULL/nonempty-history/root conclusions.

## Reproduction

Use the existing Python3.12.14 executable and vendor mpmath1.3.0; no NumPy/install/Git action. Run from the extracted package directory containing numeric_checks.py and task_contract.md, or the final checkpoint directory once created:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
numeric_checks.py \
--output /tmp/r244_numeric_replay.json \
--contract task_contract.md
```

The source and contract content hashes are stored in JSON; --output/--contract accept relocated paths. Runtime and output paths are absent from JSON. Only the three owned numeric files were changed.

## Frozen final replay

Complete JSON replay is byte-identical: 103560 bytes, actual wall.24s,user.23s,system.00s. Counts: true_L1_geometries8, operator_cases23, exact_rational_PSD_cases14. Maximum observed40/70 relative precision change 5.8113592186995496067158582442613745816973998183207e-41. SHA256 source `015ca341bf24ad3a2c75db8562f0406c3404721174421492f165d2541cea1aea`; JSON `afae3727b466464b3386ddda1fe6939cac3f6a8316bb602dd0b810c5a1b1657b`; contract `28c225ebece5c2e7868a0b4fe75e3429e4ec02d9d9c551a40e8b541f197ad507`.
