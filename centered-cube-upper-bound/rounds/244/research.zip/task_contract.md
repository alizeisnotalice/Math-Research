# R244：保原实际硬核的双容量与来源—接收联合预算
2026-10-17，main开工1d244e2e23d36fbe3aaae962fd8de9c017e95663，git状态干净。上一轮已独审并提交推送，为实际进展。目标不变：一般正L1的根阶弱型上界，继续全局极值几何及重尾joint付款。

## 精确任务
R243全低J补域仍有未付∫H_N²ν。试图跨z用hardband时必须区分roundedR_i与原R(x)：仅selected R简写不自动推出向上帽；但随后独审窄读master GENERAL_CURRENT_REDUCTION §1确认G0是全部[a,b] hard尺度的上确界，原E在2λ<G0≤4λ。因此本项目当前原资格实际授ALL-R帽，向上R_i∈[a,b]亦合法。不得把初步疑问写成已证缺陷。允许原R107 X=λ|E|、q≤λ、每receiver原完整赢家唯一leaf；R237sourceledger、R239、R243已审估计保持来源与完整posterior。
本轮准确候选：Oact_i(z)=∫Ω_i h_R(x)(x−z)dx，与Iact同底，保原actual hard直到跨z积分。节点权w_i=(a/R_i)^(αn)≤(a/R(x))^(αn)所以Σw_i Oact≤1+1/α；又原band给EΣ_Vi∫w_i Oact ν≤C0X（若唯一leaf和原E资格核实）。只能在满列/pointcap步骤用h_R(x)≤γ^(3n)h_Ri≤e³h_Ri。候选半列+sourceHolder额外e^(6θ+3η)=e^(3r)；需审核soft节点和三腿fee是否重复。成功是能同时使用两种真正容量的原量界，不能把未知source矩改名为付款。
即使双容量成立，C0X也不是εX或W。常规Young对r≈1/H产生ε^−H损失，必须如实保留。可保同源Holder精确affinity，但不能因KL大直接断言affinity小或免费降低H。

## 分工
peak:joint_budget.md，保actualhard的新主界与根阶缺口；compare:receiver_ledger.md，原X/未消费负项/rounding资格；audit:audit.md，先独筛命题再作者，核真实dx、halfcolumn、sourceFIRST、capture与完整Π次序；numeric稍后按已确立候选分配本机实现；heat_literature.md由Luna窄核2609.05377，不能单独认证关键迁移引理。主代理推导、合同、LaTeX、复现与逐轮独立提交推送。每人仅改责任文件，互不覆盖，不自行Git/spawn，交付后停止。

D04技能只用于真实共同源条件概率和零质量条件的审查；不借邻近论文证明未核验接口。ball/heat新论文结果不能转称cube已证。本轮不追求新易付gate，不复用已耗负项，不把有限数值当FULL或一般维数阶证明。重要方案三阶段实跑；仅两个新tracked归档文件加总索引，不编译PDF。

## 同轮确认后的主路线
原ALL-R帽使R243 rounded O也有receiver预算。无须为恢复已有效资格重复重做actualhard。保α>0，w_i=(a/R_i)^(αn)，定义(TαF)(x)=1Ω_i(x) sqrt(w_i)∫h_Ri(x−z)F(z)ν(dz)，跨叶分别用各自原ν。候选一般Schur几何容量：||TαF||²_{L²(dx)}≤C0q[1+(1−(a/b)^(αn))/α]||F||²_{L²(ν)}。从原hardband逐x Cauchy与真实weightedadjoint直接推，须明确跨leaf、可测及费用。目标是在原source-response/Π构造上找可付F²，未成功则不把此operator bound当作交通付款。sourceHolder精确slack与Young ε^−H只是定位最早未付步骤，不作为已闭合。
