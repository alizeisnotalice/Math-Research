from pathlib import Path
import json,sys,platform
import numpy as np
import scipy
from scipy.stats import qmc
from flint import arb,ctx
ctx.prec=160
source=np.array([[-.25,-.25],[-.25,.25],[.25,-.25],[.25,.25]])
volumes=np.arange(1,5)/4
radii=np.sqrt(volumes)
def roots(x):
 distances=2*np.max(np.abs(x[:,None,:]-source[None,:,:]),axis=2)
 valid=np.sum(distances[:,:,None]<=radii[None,None,:],axis=1)>=np.arange(1,5)[None,:]
 v=np.max(valid*volumes[None,:],axis=1)
 r=np.sqrt(v);captured=distances<=r[:,None]
 return v,r,captured
results=[]
for power in [17,19]:
 rows=[]
 for seed in [53701,53702,53703,53704]:
  xy=1.5*qmc.Sobol(4,scramble=True,seed=seed).random_base2(power)-.75
  b,c=xy[:,:2],xy[:,2:];vb,rb,ab=roots(b);vc,rc,ac=roots(c)
  sep=np.abs(b-c)
  overlap=np.prod(np.maximum(0,np.minimum(rb[:,None],np.minimum(rc[:,None],(rb[:,None]+rc[:,None])/2-sep))),axis=1)
  valid=(vb>0)&(vc>vb)&(rc>np.exp(1/(4*np.sqrt(2)))*rb)&(rc<=3*rb)&(overlap<vb/np.sqrt(2))&(2*np.max(sep,axis=1)>rc)
  inter=np.sum(ab&ac,axis=1)/4
  z=np.zeros(len(vb));z[valid]=2*inter[valid]/(vb[valid]*vc[valid])*np.log(vc[valid]/vb[valid])
  rows.append(dict(seed=seed,E_area_estimate=float(np.mean(vb>0)*2.25),Elog_exterior_estimate=float(np.mean(z)*2.25**2)))
 results.append(dict(power=power,points_per_scramble=2**power,rows=rows));print(power,rows,flush=True)
# Four single-atom receiving squares form [-1/2,1/2]^2.
# Adjacent pairs contribute four disjoint exterior strips of area 2*a*a each,
# a=(sqrt(2)-1)/4; all other subsets add only interior centers.
exact_area=arb(5)/2-arb(2).sqrt()
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(scope='Lebesgue center integration with a fixed four-atom source. Sobol values are floating numerical estimates, no certified error bound, no L1-source theorem. E area has a separate elementary exact union calculation.',executable=sys.executable,python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,exact_E_area='5/2-sqrt(2)',exact_E_area_arb160=str(exact_area),results=results),indent=2))
