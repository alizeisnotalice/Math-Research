from fractions import Fraction as F
from pathlib import Path
from itertools import product
import json,sys,platform
import numpy as np
import scipy
from scipy.optimize import linprog
from flint import arb,ctx
import flint
ctx.prec=192

def ar(q):return arb(q.numerator)/q.denominator
def inside(x,box):return all(l<=v<=u for v,(l,u) in zip(x,box))
def solve(n,delta,N,internal=False):
 if internal:
  boxes=[[(F(0),F(1)),(F(0),F(1))],[(1-delta,F(5,2)-delta),(F(0),F(3,2))],[(F(1,2),F(5,2)),(1-delta,3-delta)]]
 else:
  signs=([(1,1),(-1,1),(1,-1),(-1,-1)] if n==2 else [(1,1,1),(-1,-1,1),(-1,1,-1),(1,-1,-1)])[:N]
  boxes=[]
  for i,ss in enumerate(signs):
   r=F(1)+F(i,2);c=[s*(r/2-delta) for s in ss];boxes.append([(v-r/2,v+r/2) for v in c])
 centers=[[(l+u)/2 for l,u in box] for box in boxes];radii=[box[0][1]-box[0][0] for box in boxes];vol=[r**n for r in radii];weights=[F(1,4)]*N
 axes=[sorted({v for box in boxes for v in box[d]}) for d in range(n)]
 mids=[[(a+b)/2 for a,b in zip(ax[:-1],ax[1:])] for ax in axes]
 pts=[p for p in product(*mids) if any(inside(p,b) for b in boxes)]
 roots=[[int(inside(p,b)) for p in pts] for b in boxes]
 pairs=[]
 for i in range(N):
  for j in range(i+1,N):
   ov=F(1)
   for d in range(n):ov*=max(F(0),min(boxes[i][d][1],boxes[j][d][1])-max(boxes[i][d][0],boxes[j][d][0]))
   # strict low-overlap and scale band checked with Arb
   if not (ar(radii[j]/radii[i])>(arb(1)/(4*arb(n).sqrt())).exp() and radii[j]/radii[i]<=n+1 and ar(ov/vol[i])<1/arb(n).sqrt()):continue
   if inside(centers[i],boxes[j]):continue
   pairs.append((i,j,2*weights[i]*weights[j]/(vol[i]*vol[j]),vol[j]/vol[i]))
 cb=[sum((ar(k)*ar(v).log() for i,j,k,v in pairs if roots[i][t] and roots[j][t]),arb(0)) for t in range(len(pts))]
 caps=[];rhs=[];labels=[]
 for i,c in enumerate(centers):
  ds=[2*max(abs(x-y) for x,y in zip(p,c)) for p in pts]
  for radius in sorted(set(ds)):
   if radius<=radii[i]:continue
   caps.append([int(d<=radius) for d in ds]);rhs.append(radius**n);labels.append((i,str(radius)))
 outs=[]
 for full,strict in [(False,False),(True,False),(True,True)]:
  rhs_used=[v-F(1,1000)*(v-vol[labels[i][0]]) if strict else v for i,v in enumerate(rhs)]
  A=np.array(roots,float);U=np.array(caps,float) if full else None
  sol=linprog(-np.array([float(z.mid()) for z in cb]),A_ub=U,b_ub=list(map(float,rhs_used)) if full else None,A_eq=A,b_eq=list(map(float,vol)),bounds=(0,None),method='highs')
  assert sol.success,sol.message
  primal=[F(float(x)).limit_denominator(10**9) for x in sol.x]
  assert all(x>=0 for x in primal)
  assert all(sum(F(a)*x for a,x in zip(row,primal))==v for row,v in zip(roots,vol))
  if full:assert all(sum(F(a)*x for a,x in zip(row,primal))<=v for row,v in zip(caps,rhs_used))
  equal_expanded=[labels[i] for i,(row,v) in enumerate(zip(caps,rhs)) if sum(F(a)*x for a,x in zip(row,primal))==v]
  if strict:assert not equal_expanded
  y=[F(float(-v)).limit_denominator(10**10) for v in sol.eqlin.marginals]
  z=[F(float(-v)).limit_denominator(10**10) for v in sol.ineqlin.marginals] if full else []
  assert all(v>=0 for v in z)
  # Certified outward correction; every support point lies in at least one root.
  eta=F(1,10**9);y=[v+eta for v in y]
  for t,cost in enumerate(cb):
   bound=sum((ar(v)*roots[i][t] for i,v in enumerate(y)),arb(0))
   if full:bound+=sum((ar(v)*caps[i][t] for i,v in enumerate(z) if v),arb(0))
   assert bound>cost
  lb=sum((ar(x)*v for x,v in zip(primal,cb)),arb(0))
  ub=sum((ar(x*v) for x,v in zip(y,vol)),arb(0))+sum((ar(x*v) for x,v in zip(z,rhs_used)),arb(0))
  assert ub-lb<arb('0.000001')
  outs.append(dict(all_expanded_caps=full,strict_margin=str(F(1,1000)) if strict else None,equality_expanded=equal_expanded,lower=str(lb),upper=str(ub),gap=str(ub-lb),primal=[[i,str(v)] for i,v in enumerate(primal) if v],dual_roots=list(map(str,y)),dual_caps=[[labels[i],str(v)] for i,v in enumerate(z) if v]))
 return dict(n=n,depth=str(delta),parents=N,internal=internal,points=len(pts),expanded_caps=len(caps),exterior_pairs=[[i,j] for i,j,k,v in pairs],X=str(sum(weights)),results=outs)
results=[]
for n,d,N,internal in [(2,F(1,8),3,False),(2,F(1,16),4,False),(2,F(1,16),3,True),(2,F(1,32),4,False),(3,F(1,8),4,False),(3,F(1,16),4,False),(3,F(1,32),4,False)]:
 r=solve(n,d,N,internal);results.append(r);print(n,str(d),N,internal,[(a['lower'],a['dual_caps']) for a in r['results']],flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(scope='Finite atomic source support and finite weighted centers. Every expanded-radius cap at each support distance is enforced exactly; outside jump radii monotonic s^n proves other caps. These are neither L1-source nor continuous-center certificates. LP primal checked rationally, dual checked with Arb outward correction. No all-dimensional conclusion.',executable=sys.executable,python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,flint=flint.__version__,precision_bits=192,results=results),indent=2))
