from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json,sys,platform
import numpy as np
import scipy
from scipy.optimize import linprog
from flint import arb,ctx
ctx.prec=160
def ar(x):return arb(x.numerator)/x.denominator
def dist2(x,y):return (2*max(abs(a-b) for a,b in zip(x,y)))**2
seed=list(product([F(-1,4),F(1,4)],repeat=2))
points=list(product([F(i,8) for i in range(-4,5)],repeat=2))
results=[]
for den in [4,8,16]:
 centers=[];V=[]
 for c in product([F(i,den) for i in range(-den,den+1)],repeat=2):
  dd=sorted(dist2(c,x) for x in seed)
  valid=[F(k,4) for k in range(1,5) if dd[k-1]<=F(k,4)]
  if valid:centers.append(c);V.append(max(valid))
 N=len(V);w=F(1,den**2);roots=[[int(dist2(c,x)<=v) for x in points] for c,v in zip(centers,V)]
 cost=[F(0)]*len(points);paircount=0;uncertain=0
 for i in range(N):
  for j in range(N):
   if V[j]<=V[i] or dist2(centers[i],centers[j])<=V[j]:continue
   ri=ar(V[i]).sqrt();rj=ar(V[j]).sqrt();ov=arb(1)
   for d in [0,1]:
    ci=ar(centers[i][d]);cj=ar(centers[j][d]);lo=(ci-ri/2).max(cj-rj/2);hi=(ci+ri/2).min(cj+rj/2);ov*=(hi-lo).max(arb(0))
   gap=ar(V[i])/arb(2).sqrt()-ov
   if gap<0:continue
   if not gap>0:uncertain+=1;continue
   ratio=V[j]/V[i];assert ratio in [F(2),F(4)]
   k=1 if ratio==2 else 2;paircount+=1
   for t in range(len(points)):
    if roots[i][t] and roots[j][t]:cost[t]+=2*w*w*k/(V[i]*V[j])
 caps=[];rhs=[];labels=[]
 for i,c in enumerate(centers):
  ds=[dist2(c,x) for x in points]
  for v in sorted(set(ds)):
   if v<=V[i]:continue
   caps.append([int(d<=v) for d in ds]);rhs.append(v);labels.append((i,v))
 out=[]
 for mode in ['roots','caps','strict_caps']:
  full=mode!='roots';bb=[v-F(1,1000)*(v-V[i]) if mode=='strict_caps' else v for i,v in labels]
  res=linprog(-np.array(list(map(float,cost))),A_eq=np.array(roots,float),b_eq=list(map(float,V)),A_ub=np.array(caps,float) if full else None,b_ub=list(map(float,bb)) if full else None,bounds=(0,None),method='highs')
  assert res.success,res.message
  x=[F(float(t)).limit_denominator(10**9) for t in res.x]
  assert all(t>=0 for t in x)
  assert all(sum(a*t for a,t in zip(row,x))==v for row,v in zip(roots,V))
  if full:assert all(sum(a*t for a,t in zip(row,x))<=v for row,v in zip(caps,bb))
  if mode=='strict_caps':assert all(sum(a*t for a,t in zip(row,x))<v for row,v in zip(caps,rhs))
  y=[F(float(-t)).limit_denominator(10**9) for t in res.eqlin.marginals];z=[F(float(-t)).limit_denominator(10**9) for t in res.ineqlin.marginals] if full else []
  assert all(t>=0 for t in z)
  for k,cost_k in enumerate(cost):assert sum(row[k]*t for row,t in zip(roots,y))+sum(row[k]*t for row,t in zip(caps,z))>=cost_k
  primal=sum(a*b for a,b in zip(cost,x));dual=sum(a*b for a,b in zip(V,y))+sum(a*b for a,b in zip(bb,z));assert primal==dual
  out.append(dict(mode=mode,optimal_log2_coefficient=str(primal),objective_ball=str(ar(primal)*arb(2).log()),active_cap_dual=sum(t!=0 for t in z),primal=[[i,str(t)] for i,t in enumerate(x) if t],dual_root=[[i,str(t)] for i,t in enumerate(y) if t],dual_cap=[[i,str(t)] for i,t in enumerate(z) if t]))
 r=dict(denominator=den,centers=N,source_points=len(points),caps=len(caps),exterior_pairs=paircount,uncertain_pairs=uncertain,X=str(N*w),results=out);results.append(r)
 print(den,N,len(caps),uncertain,[(o['mode'],o['optimal_log2_coefficient'],o['active_cap_dual']) for o in out],flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(scope='Atomic sources, finite weighted receiving grid derived from seed roots. Selected center constraints do not cover every center in actual E. All three LP optima certified by exact rational primal/dual with common factor log2. Not a continuous-center or L1 theorem.',executable=sys.executable,python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,arb_bits=160,results=results),indent=2))
