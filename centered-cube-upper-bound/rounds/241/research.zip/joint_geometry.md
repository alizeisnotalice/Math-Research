# R241：共同 hard 窗口的全 soft 缺口与新增近来源付款

本轮没有闭合全部近来源的根阶预算。新增的可审核结果是一个对所有物理尺度、所有共同 soft 参数成立的 **source y–hard z 窗口缺口**。它在 R240 距离量为零时仍能产生指数衰减；接回原 FIRST、原完整 posterior 和全部节点求和后，得到包含 R240 来源门、在几何参数层面可严格扩大的已付门，且合并门只使用一份来源预算。本文不证明实际新增正交通非空。

K 的费用在本文始终显示。是否可预固定原 K、以及原其它交通分支的付款，以母账为准；不由工具模型推定。

## JG1. 范围与原对象

采用 R238–240 已独审的同一有限截断、原外资料 (ω,V)、0<a≤b≤2a、q,K>0、ν≤β≤f、原 actual s(x)、原 receiver Ω 与 source-pair 集

\[
 D(z)=V\cap\{\|y-z\|_1\le17na\}
       \cap\{\|y-z\|_\infty\le b(5\log n+1/2)\}.
\]

所有原 large-n、history、capture、FIRST 资格保留。硬来源 z 不是 posterior 变量。两辅助槽、Π_t、e_t、Z_t 始终由完整原 ν 定义。β,ν,a,b,q,D 跨 j 共同。

F_z⊂D(z) 为固定 hard z 后、receiver、来源积分、辅助槽、j/M/t 之前确定的可测来源子集。本文只限制原正母式的 β(dy) 积分，不对 posterior 作相应限制。记

\[
 m_D(z)=\beta(D(z)),\quad\rho_D=m_D/(qa^n),\quad
 B=e\lceil\pi\sqrt n\rceil,\quad C_0=16/3.
\]

对于所有物理节点，允许使用任一已经证明的共同 receiver 上界

\[
 O_{R^*}(z)=\int_\Omega h_{R^*}(x-z)dx\le\Delta(z)\le1.
\]

可取 Δ=1 或 R239 的 δ_base、δ_W、覆盖上界及其合法最小值。Δ=0 的原行先置零；其余取 Δ>0。没有对 β 授 ν 的 rank 或出生行资格。

## JG2. 固定尺度的一维严格 soft 缺口

原核为 h=1_[−1/2,1/2]、w(u)=∫_0^1e^{−|u|/r}dr、φ=h*w、f_s=(1−s)h+sφ。定义明确常数

\[
 \varepsilon_0=\tfrac12 e^{-3}.
\]

φ 是质量一的偶函数，并在正半轴递减：w 具有该性质，且 φ'(x)=w(x+1/2)−w(x−1/2)≤0 (x≥0)。端点及零点按连续性处理。

取 L,R∈[a,b]、M=max(L,R)、m=min(L,R)、d∈R。定义一维归一化窗口响应

\[
 H_{L,R}(d)=\frac M{RL}\int_{-R/2}^{R/2}h((x-d)/L)dx,
 \quad V_{L,R}(d)=\frac M{RL}\int_{-R/2}^{R/2}\phi((x-d)/L)dx.
\]

有

\[
 H_{L,R}(d)=1-\min\{1,(|d|-(M-m)/2)_+/m\}.
\]

令

\[
 g(d)=\min\{1,(|d|-(b-a)/2)_+/b\}.
\]

因 M−m≤b−a、m≤b，H_{L,R}(d)≤1−g(d)。此外

\[
 \boxed{V_{L,R}(d)\le1-\varepsilon_0.} \tag{JG2.1}
\]

证明分两种尺度朝向。若 R≥L，归一化响应是 φ 在长度 R/L≤2 的某区间上的质量。对称单峰性给其不超过 ∫_[−1,1]φ。又 w(t)≥(1/2)e^{−2|t|}，所以

\[
 \phi(u)\ge\tfrac12e^{-2|u|-1},\qquad
 \int_{|u|>1}\phi(u)du\ge\tfrac12e^{-3}=\varepsilon_0.
\]

若 L≥R，V 是 φ 在长度 R/L≤1 区间上的平均，故 V≤φ(0)。用 w(t)≤e^{−|t|}，将 [−1/2,1/2] 分成 |t|≤1/4 与其补集，得

\[
 \phi(0)\le\tfrac12(1+e^{-1/4})\le1-\tfrac12e^{-3}.
\]

最后一步可由 e^{1/4}≥5/4、e^3>5 推出 e^{−1/4}+e^{−3}<1。故 JG2.1 对全部位移和两朝向成立。

## JG3. 全共同 soft 的 source–hard 窗口缺口

对任意 y,z∈R^n 定义

\[
 G_z(y)=\sum_i g(y_i-z_i),\qquad
 \Psi_z(y)=\max_{0\le s\le1}\prod_i[1-g(y_i-z_i)+s(g(y_i-z_i)-\varepsilon_0)],
 \quad A_z(y)=-\log\Psi_z(y). \tag{JG3.1}
\]

这里 A 是新的窗口缺口，不是原 hard-source 测度或任何 source selector。Ψ 是显式的一维共同 soft 优化，不涉及未知 receiver 或来源预算。其最大值在紧区间取得；s=1 给 Ψ≥(1−ε0)^n>0，所以 A 有限非负。连续函数在可数稠密参数集上的 supremum 证明其关于 y,z 的可测性。固定同一个 s∈[0,1]，逐坐标窗口响应满足

\[
 (1-s)H_i+sV_i\le1-(1-s)g_i-s\varepsilon_0
 \le e^{-(1-s)g_i-s\varepsilon_0}.
\]

因此精确张量分解给

\[
 \boxed{\int_{\mathbb R^n}h_R(x-z)P_{s,L}(x-y)dx
 \le M^{-n}\prod_i[1-g_i+s(g_i-\varepsilon_0)]
 \le M^{-n}e^{-A_z(y)},\quad
 A_z(y)\ge\min\{G_z(y),\varepsilon_0n\}.} \tag{JG3.2}
\]

这是共同 s 下的直接证明，没有给各坐标独立选择 soft。严格 soft 缺口正是利用同一 hard 接收窗口内的真实归一化响应；只用 φ≤1 无法给它。

正因子的 log 之和是 s 的凹函数，其二阶导数为

\[
 -\sum_i\frac{(g_i-\varepsilon_0)^2}{[1-g_i+s(g_i-\varepsilon_0)]^2}\le0.
\]

所以 Ψ 可由端点或单个一维导数零点计算；端点零因子按连续极限处理。这里优化的是已经证明的上包络，不声称实际 φ overlap 达到等号。

一个解析强化：若 k 个 g_i=1，其余为零，0<k≤ε0n，则最优 s*=k/(ε0n)，且

\[
 \Psi=\left[\frac{(1-\varepsilon_0)k}{\varepsilon_0n}\right]^k
       (1-k/n)^{n-k}.
\]

若 k>ε0n，最优 s*=1、Ψ=(1−ε0)^n；k=0 时 Ψ=1。稀疏 k 的精确 A 因而保有 klog(n/k) 项，而粗 min(G,ε0n) 只保 k。这是所有 g 均适用的一维优化公式的特例，不是对输入形状作新假设。

## JG4. 实际自适应 s(x)：只用已经付费的共同菜单

固定合法物理节点 L*,R*，令 M=max(L*,R*)，

\[
 I_0(y,z)=\int_\Omega h_{R^*}(x-z)P_{s(x),L^*}(x-y)dx.
\]

R234/R238 已证的同一 softness 菜单给点态 P_s,L*≤e∑_{r∈S_n}P_r,L*，|S_n|=⌈π√n⌉。先用该正支配再积分，JG3.2 对每个固定 r 成立，故

\[
 \boxed{I_0(y,z)\le B M^{-n}e^{-A_z(y)}.} \tag{JG4.1}
\]

不能直接将固定 s 的积分上界用于 s(x)，也没有交换 sup 与积分。B 的全部费用保留。

同时，原 actual FIRST（仍用实际 s(x)，不是菜单 r）给

\[
 \int_{F_z} I_0(y,z)\beta(dy)\le q O_{R^*}(z). \tag{JG4.2}
\]

JG4.1 为非负 I0 包络而释放其 receiver 域；JG4.2 仍在原 Ω 上。下面半阶 QG 所需的原 capture 支持始终保留，不能因 JG4.1 而一并删除。

## JG5. 窗口加权来源与原节点界

定义

\[
 m_A(F,z)=\int_{F_z}e^{-A_z(y)/2}\beta(dy),\qquad
 \rho_A=m_A/(qa^n).
\]

对 0<θ≤1/4，将 I0^(1−2θ)=I0^(1−4θ)I0^(2θ)，由 JG4.1–2 和同一来源测度上的 Hölder，

\[
 \int_F I_0^{1-2\theta}d\beta
 \le(BM^{-n})^{2\theta}(qO_{R^*})^{1-4\theta}
 m_A^{4\theta}. \tag{JG5.1}
\]

θ=1/4 直接按端点解释；零来源/零 receiver 行先置零。原半阶列插值为

\[
 J_\theta\le(BM^{-n})^{2\theta}I_0^{1-2\theta}.
\]

右侧与辅助槽一致，故可在 **原同一完整 Π_t⊗Π_t** 下使用 ∫δ_t dΠ_t²≤n/4。仍记

\[
 \gamma=1+1/n,\ c=\gamma^{-j},\ M_0=a/c^2,\
 \xi=n\log(M/M_0),\ Z=(\xi-U)_+.
\]

原 clock 长度≤Z/n，原列分母 q。合并得到

\[
 \boxed{\mathcal T^F_{jM,z}\le\frac Z4
 (B\rho_A)^{4\theta}\Delta^{1-4\theta}
 c^{8\theta n}e^{-4\theta\xi}.} \tag{JG5.2}
\]

量纲为 q^−1(qO)^(1−4θ)m_A^(4θ)M^−4nθ =ρ_A^(4θ)O^(1−4θ)(a/M)^(4nθ)。未改原 ν，未将 hard z 当作 posterior，未调用 heavy floor 或任何已耗负信用。

## JG6. 新指数的全部节点求和

这里直接证明新范围，不把旧引理的参数域默认为任意大。令 h=nlogγ∈[log2,1]、p=4θ∈(0,1]。正规节点 ξ=kh 的和满足

\[
 \sum_{k\ge0}kh e^{-pkh}
 =\frac h{4\sinh^2(ph/2)}\le\frac1{p^2h}.
\]

独立 capped endpoint 至多 sup_(x≥0)xe^−px=1/(pe)。因 1/log2+1/e<2，

\[
 \sum_M\xi e^{-4\theta\xi}\le\frac1{8\theta^2}.
\]

又 1/(1−e^−x)≤1+1/x、h≥2/3、p≤1，故

\[
 \sum_{j\ge0}c^{8\theta n}
 \le1+\frac1{2ph}\le\frac7{4p}=\frac7{16\theta}.
\]

空节点不贡献；把 cap 即使重复也独立上计只增正项。因 Z≤ξ，对于每腿/朝向，

\[
 \sum_{j,M}(K/3)^\theta\mathcal T^F_{jM,z}
 \le\frac7{512\theta^3}\Delta(K/3)^\theta
 (B\rho_A)^{4\theta}\Delta^{-4\theta}. \tag{JG6.1}
\]

令 H_A=1+log_+ρ_A+log B+log_+K+log(1/Δ)，固定 hard z 后取 θ_z=1/(4H_A)。指数乘子≤e。恢复原 2Λe^4、三腿和两朝向，得到

\[
 \boxed{P_{\rm farclock}^{F}(U)\le\frac{21}{2}\Lambda e^5
 \mathbb E\sum_V\int_V\Delta(z)H_A(F,z)^3\nu_V(dz).} \tag{JG6.2}
\]

参数 θ 在所有 receiver、来源/辅助积分、节点和 clock 之前冻结；跨 j 的共同来源资格是求和前提。U≥0 任意，U=0 仅覆盖当前原 far-clock 分支，不恢复其它分支。

## JG7. 与 R240 距离门合并：一份来源预算扩大已付域

沿 R240 记 E_z(y)=∑_i(|y_i−z_i|/b−1)_+，其已证包络 I0≤a^−n e^−E O。令

\[
 T_z(y)=\max\{E_z(y),A_z(y)\},\qquad
 m_T(F,z)=\int_F e^{-T_z(y)/2}\beta(dy),\quad
 \rho_T=m_T/(qa^n).
\]

由 B≥1、M≥a、O≤1，两条真实包络联合给

\[
 I_0(y,z)\le B a^{-n}e^{-T_z(y)}. \tag{JG7.1}
\]

重复一次 JG5 的同源 Hölder，而不分别计两支交通，得到节点界

\[
 \mathcal T^F_{jM,z}\le\frac Z4 B^{4\theta}\rho_T^{4\theta}
 \Delta^{1-4\theta}c^{4\theta n}e^{-2\theta\xi}.
\]

R238 原节点和给 7/(64θ³)，适用于此处 0<θ≤1/4。定义

\[
 H_T=1+\log_+\rho_T+\log B+\log_+K+\log(1/\Delta),
 \quad\theta_z=1/(4H_T),
\]

于是

\[
 \boxed{P_{\rm farclock}^{F}(U)\le84\Lambda e^5
 \mathbb E\sum_V\int_V\Delta H_T(F,z)^3\nu_V(dz).} \tag{JG7.2}
\]

此处一般 Δ 的 log 系数为一，不能冒称继承 R240 更尖的 1/2。对于同一原交通可与 R240 强 Δ 界及 JG6.2 取合法较小者，不把这些上界当成额外信用。

现在仅作一次来源分割：

\[
 F_z^*=\{y\in D(z):T_z(y)\ge2\log_+\rho_D(z)\},
 \qquad N_z^*=D(z)\setminus F_z^*.
\]

有 ρ_T(F*,z)≤e^−log_+ρ_Dρ_D≤1。取 Δ=1，若 K 在 outer data 间共同，

\[
 \boxed{P_{\rm farclock}^{F^*}(U)\le84\Lambda e^5
 [1+\log_+K+\log(e\lceil\pi\sqrt n\rceil)]^3 W_\nu.} \tag{JG7.3}
\]

Wν=E∑_Vν_V(V) 是同一原来源预算。若 K 随外资料变化，方括号须保在 E∑∫ν 内。没有逐距离层或逐菜单重领 Wν。若原 K 已合法预固定为绝对常数，则这支是 O(log³(n+1))Wν；不需要猜 K 的 n 依赖。

JG7.3 包含 R240 来源门，并在几何参数层面可严格扩大。新增部分正是

\[
 E_z(y)<2\log_+\rho_D(z)\le A_z(y).
\]

这不是更换交通来源，而是原 β 积分中此前未由 E 门支付的实际子集。其非空比例不在本文证明范围。

## JG8. 确实不同于旧远距离的几何与精确未付域

例如 b=2a 且每坐标 |y_i−z_i|=b/2，则 E=0、g_i=1/4、A=−nlog(1−ε0)≥ε0n。对 1<ρ_D≤exp(ε0n/2)，这样的位移满足新增门而不满足旧 E 门。它也不违反 D 的两项距离上界。此仅验证新门与旧门不同、参数距离约束相容，**不是** FULL/history、出生行或原正交通非空构造。

完整近来源目标仍未闭合。经过一次 JG7 分割，准确剩余是

\[
 y\in D(z),\quad E_z(y)<2\log_+\rho_D(z),\quad
 A_z(y)<2\log_+\rho_D(z), \tag{JG8}
\]

与原 receiver/capture/history/full-posterior/clock 条件的交。由 Ψ≥(1−ε0)^n 可知 A≤−nlog(1−ε0)；若门槛超过这个值，本次窗口缺口不能单独支付该行。如果很多位移落在 |d_i|≤(b−a)/2 的 plateau 内，hard 部分也不给 g_i。

因此没有声称 ∫δH³ν≤n^(1/2+o(1))||f||1 对所有原输入已经成立。最早未证步骤是：在 JG8 的同一真实来源上，利用原 receiver 排斥或实际 s(x) 的非零 soft 份额，控制仍高的 ρ_T 与 Δ 的共同积分。仅由 Δ≤1、ρ_T≤ρ_D 或窗口缺口已知下界不能完成它。本轮不把这个未付共同积分的新记号当作付款；已付内容是 JG7.3 的明确扩大来源子交通。

## JG9. 本机数学工具核验

本机 Python/mpmath 40 位精度实际计算了 45 个真实一维窗口：a=.5、b=1；L,R 各取 {.5,.75,1}，d 取 {0,.25,.5,1,2}。按原 φ 的 expint(3,·) 解析式，quadrature 在落于 [−R/2,R/2] 内的 d−L/2、d、d+L/2 分段。

所有 H≤1−g、V≤1−ε0 均通过。另对每个窗口取 s∈{0,.01,.5,1}，180 个共同 mixture 检查均满足 (1−s)H+sV≤exp[−(1−s)g−sε0]；最大比值为 1.0（包含 hard 完全重叠的等号情形）。实际数值为

\[
 \varepsilon_0=0.02489353418393197148967121,
 \quad\phi(0)=0.5567912714496430852614012,
 \quad\int_{-1}^1\phi=0.7615282982119028131864259.
\]

这些只验证原一维核与常数，非大维 FULL 或原 history 的证据；证明由 JG2–7 给出。本作者仅写 joint_geometry.md，不修改其它责任文件或原 source/posterior，不提交仓库。
