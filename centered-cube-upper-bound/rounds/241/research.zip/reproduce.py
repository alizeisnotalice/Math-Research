#!/usr/bin/env python3
"""R241 relocated replay and complete manifest verification."""
import argparse,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    hashes=json.loads((ROOT/'manifest.json').read_text())
    for name,h in hashes.items():assert digest(ROOT/name)==h,name
    return len(hashes)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--output-dir',type=Path);a=ap.parse_args();count=verify()
    if a.verify_only:print('verified',count,'manifest entries');return
    if a.output_dir is None:ap.error('--output-dir required')
    out=a.output_dir.resolve()
    if out==ROOT or ROOT in out.parents:ap.error('output must be outside package')
    out.mkdir(parents=True,exist_ok=False)
    for name in ['task_contract.md','numeric_checks.py','extremum_checks.py']:shutil.copyfile(ROOT/name,out/name)
    runs=[]
    for script,result,extra in [('numeric_checks.py','numeric_checks.json',['--contract',str(out/'task_contract.md')]),('extremum_checks.py','extremum_checks.json',[])]:
        start=time.monotonic()
        r=subprocess.run([sys.executable,str(out/script),'--output',str(out/result)]+extra,env=os.environ.copy(),check=True,capture_output=True,text=True)
        assert (out/result).read_bytes()==(ROOT/result).read_bytes(),result+' entire JSON mismatch'
        runs.append({'script':script,'entire_json_byte_identical':True,'sha256':digest(out/result),'stdout':r.stdout.strip(),'elapsed_seconds':time.monotonic()-start})
    code=(ROOT/'k_qualification.md').read_text().split('```python\n',1)[1].split('```',1)[0]
    p=out/'k_checks.py';p.write_text(code)
    r=subprocess.run([sys.executable,str(p)],check=True,capture_output=True,text=True)
    assert '192 exact parameter/split checks PASS' in r.stdout
    runs.append({'script':'k_qualification.md embedded','checks':192,'stdout':r.stdout.strip()})
    assert verify()==count
    receipt={'complete_replay':True,'manifest_hashes_before_and_after':count,'runs':runs,'python':sys.executable,'scope':'Finite actual kernels, scalar envelope extrema and exact source/threshold checks. Not FULL certification or general root closure; high precision is not interval arithmetic.'}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
