#!/usr/bin/env python3
"""R241 actual window-loss kernel tests and exact common-X L1 geometry."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp
ROOT=Path(__file__).resolve().parent

def enc(x):return mp.nstr(x,32)
def phi(x):
 x=abs(x);h=mp.mpf('.5')
 def E3(t):return h if t==0 else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
 return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def psoft(x,s):return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi(x)
CACHE={}
def scalar(c,dps):
 key=(c['L'],c['R'],c['d'],c['s'],dps)
 if key in CACHE:return CACHE[key]
 with mp.workdps(dps):
  L=mp.mpf(c['L']);R=mp.mpf(c['R']);d=mp.mpf(c['d']);a=min(L,R);b=max(L,R);M=b;eps=mp.exp(-3)/2;g=min(mp.mpf(1),max(mp.mpf(0),abs(d)-(b-a)/2)/b);G=min(g,eps);E=max(mp.mpf(0),abs(d)/b-1);N=int(mp.ceil(mp.pi));B=mp.e*N
  cuts=sorted(set([-R/2,R/2]+[t for t in (mp.mpf(0),d-L/2,d+L/2) if -R/2<t<R/2]));I=mp.mpf(0)
  if c['s']=='adaptive':
   for u,v in zip(cuts,cuts[1:]):I+=mp.quad(lambda x:psoft((x-d)/L,mp.mpf('.2') if x<0 else mp.mpf('.8'))/(L*R),[u,v])
   multiplier=B
  else:
   s=mp.mpf(c['s']);overlap=max(mp.mpf(0),min(R/2,d+L/2)-max(-R/2,d-L/2));I=(1-s)*overlap/(L*R)
   if s:
    for u,v in zip(cuts,cuts[1:]):I+=s*mp.quad(lambda x:phi((x-d)/L)/(L*R),[u,v])
   multiplier=mp.mpf(1)
  normalized=M*I;bound=multiplier*mp.exp(-G);assert normalized<=bound*(1+mp.mpf(10)**(-dps+5))
  out={k:enc(v) for k,v in dict(I1=I,M=M,a=a,b=b,g=g,G=G,old_E=E,epsilon=eps,normalized_M_I=normalized,menu_multiplier=multiplier,bound=bound,ratio=normalized/bound).items()};CACHE[key]=out;return out

def product(n,s,dps):
 with mp.workdps(dps):
  # One actual common scalar L,R and one fixed s for all coordinates.
  cs=[dict(L='1' if s=='.2' else '2',R='2' if s=='.2' else '1',d='1',s=s)];ss=[scalar(c,dps) for c in cs];counts=[n];lognorm=mp.mpf(0);gsum=mp.mpf(0);Esum=mp.mpf(0)
  for count,r in zip(counts,ss):
   lognorm+=count*mp.log(mp.mpf(r['normalized_M_I']));gsum+=count*mp.mpf(r['g']);Esum+=count*mp.mpf(r['old_E'])
  G=min(gsum,n*mp.exp(-3)/2);assert lognorm<=-G
  return dict(n=n,s=s,counts=counts,coordinate_configs=cs,log_Mproduct_In=enc(lognorm),G=enc(G),old_E_sum=enc(Esum),log_ratio_to_new_bound=enc(lognorm+G),scope='Actual fixed one common s product kernel; no independently adaptive coordinate softness, no FULL input. Logs avoid underflow.')

def mass(x,slab):
 lo,hi,d=slab;return d*max(F(0),min(x+F(1,2),hi)-max(x-F(1,2),lo))
def pieces(slabs):
 pts=sorted(set([F(-1,2),F(1,2),F(0)]+[t for lo,hi,_ in slabs for t in (lo-F(1,2),lo+F(1,2),hi-F(1,2),hi+F(1,2)) if -F(1,2)<t<F(1,2)]));rows=[];means=[F(0)]*len(slabs);seconds=[[F(0)]*len(slabs) for _ in slabs];joint=F(0);full=F(0)
 for lo,hi in zip(pts,pts[1:]):
  u=[mass(lo,s) for s in slabs];v=[mass(hi,s) for s in slabs];width=hi-lo
  for i in range(len(slabs)):
   means[i]+=width*(u[i]+v[i])/2
   for j in range(len(slabs)):seconds[i][j]+=width*(2*u[i]*u[j]+u[i]*v[j]+v[i]*u[j]+2*v[i]*v[j])/6
  def allowed(constraints):
   left=lo;right=hi
   for A,B in constraints:
    if A==B:
     if A>1:return F(0)
    elif B>A:right=min(right,lo+width*(1-A)/(B-A))
    else:left=max(left,lo+width*(1-A)/(B-A))
   return max(F(0),min(hi,right)-max(lo,left))
  ja=allowed(list(zip(u,v)));fa=allowed([(sum(u),sum(v))]);joint+=ja;full+=fa;rows.append(dict(xlo=str(lo),xhi=str(hi),mass_vector_lo=list(map(str,u)),mass_vector_hi=list(map(str,v)),joint_allowed_length=str(ja),full_f_allowed_length=str(fa)))
 cov=[[seconds[i][j]-means[i]*means[j] for j in range(len(slabs))] for i in range(len(slabs))];return rows,means,seconds,cov,joint,full

def Phi(r,slabs):
 out=F(0)
 for lo,hi,d in slabs:
  pts=sorted(set([lo,hi]+[t for t in (-r,F(0),r) if lo<t<hi]))
  for a,b in zip(pts,pts[1:]):out+=d*(b-a)*(max(F(0),1-abs(a)/r)+max(F(0),1-abs(b)/r))/2
 return out

def deltaW(slabs):
 if Phi(F(1),slabs)<1:return dict(empty=True,upper='1')
 lo=F(0);hi=F(1)
 for _ in range(80):
  mid=(lo+hi)/2
  if Phi(mid,slabs)>=1:hi=mid
  else:lo=mid
 assert (lo==0 or Phi(lo,slabs)<1) and Phi(hi,slabs)>=1
 return dict(empty=False,lower=str(lo),upper=str(hi),Phi_lower=str(Phi(lo,slabs)) if lo else '0',Phi_upper=str(Phi(hi,slabs)))
def delta2(means,cov):
 d=means[1]-1;e=means[0]-means[1];A=cov[0][0]-2*cov[0][1]+cov[1][1];B=2*(cov[0][1]-cov[1][1]);C=cov[1][1];candidates=[F(0),F(1)]
 if 2*A*d-B*e:candidates.append((2*C*e-B*d)/(2*A*d-B*e))
 if A:candidates.append(-B/(2*A))
 out=[]
 for t in candidates:
  gap=d+e*t;var=A*t*t+B*t+C
  if 0<=t<=1 and gap>0:
   assert var>=0;out.append((var/(var+gap*gap),t,var,gap))
 best=min(out) if out else (F(1),None,None,None)
 return dict(value=str(best[0]),weight_first=str(best[1]) if best[1] is not None else None,variance=str(best[2]) if best[2] is not None else None,positive_gap=str(best[3]) if best[3] is not None else None,scope='Exact two-witness quadratic/linear-ratio stationary candidates plus boundaries; convex weights, positive mean gap required.')
def geometric(density,overlap=False):
 slabs=[(F(-3,4),F(1,4),F(density)),(F(-1,4),F(3,4),F(density))] if overlap else [(F(-3,4),F(-1,4),F(density)),(F(1,4),F(3,4),F(density))];rows,means,sec,cov,joint,full=pieces(slabs);dw=deltaW(slabs);d2=delta2(means,cov);q=F(3,16);rho=sum((b-a)*d for a,b,d in slabs)/q
 assert joint<=F(d2['value']) and full<=F(dw['upper']);return dict(density=density,overlapping_sources=overlap,a_b='1',z='0',H='1',q=str(q),beta_f='sum of the two continuous densities, nu need not be specified for geometric tool',source_slabs=[[str(t) for t in s] for s in slabs],joint_distribution_cells=rows,means=list(map(str,means)),second_moments=[list(map(str,r)) for r in sec],covariance=[list(map(str,r)) for r in cov],true_joint_allowed=str(joint),true_f_allowed=str(full),deltaW_full_f=dw,delta2=d2,rho_D=str(rho),rho_w=str(rho),E_on_support='0',scope='Exact true n1 L1 common receiver; high nearby beta mass, no FULL history/source-flow claim.')
def geometric2():
 # 2D diagonal/opposite corner witnesses; each box density18 and side1/2.
 unit=[(F(-3,4),F(-1,4),F(1)),(F(1,4),F(3,4),F(1))];cells,um,us,uc,_,_=pieces(unit)
 assert all(F(row['mass_vector_lo'][0])+F(row['mass_vector_lo'][1])==F(1,2) and F(row['mass_vector_hi'][0])+F(row['mass_vector_hi'][1])==F(1,2) for row in cells)
 mean=18*(um[0]**2+um[1]**2);second=18**2*(us[0][0]**2+us[1][1]**2+2*us[0][1]**2);var=second-mean**2;cross=2*18**2*us[0][1]*(us[0][0]+us[1][1]);assert cross-mean**2==-var and mean==F(9,4) and var==F(9,4)
 corner=dict(name='symmetric_four_corner_boxes',dimension=2,boxes='all products of [-3/4,-1/4] and [1/4,3/4], density18; witness1 diagonal pair, witness2 opposite pair',witness_mass='9 each',means=[str(mean)]*2,variances=[str(var)]*2,crossmoment=str(cross),independent_computed_secondmoment=str(second),unit_overlap_moments=[list(map(str,r)) for r in us],covariance='-9/4',common_X_identity='m1+m2=9/2 for every X in Q1(0)',true_joint_allowed='0',true_f_allowed='0',delta2='0',deltaW_full_sigma_upper='27/34',deltaW_scope='full-sigma fraction upper bound only, not optimized deltaW',rho_w='96',E_on_support='0',derivation='1D overlap moments E[l]=1/4,E[l²]=5/48,E[lr]=1/48; tensor products compute moments using same X, not independent witnesses.')
 with mp.workdps(50):
  weight_y=2+4*(1-mp.exp(-mp.mpf('.5')));weighted_mass=6*weight_y;rhow=weighted_mass/(mp.mpf(3)/16)
 anis=dict(name='anisotropic_long_slabs',dimension=2,boxes='density6 on [-3/4,-1/4]x[-2,2] and [1/4,3/4]x[-2,2]',witness_mass='12 each',means=['3/2','3/2'],variances=['3/2','3/2'],covariance='-3/2',common_X_identity='m1+m2=3; every coordinate2 receiver window is contained in [-2,2], so actual mass reduces to coordinate1',true_joint_allowed='0',true_f_allowed='0',delta2='0',rho_D='128',rho_w=enc(rhow),weighted_mass=enc(weighted_mass),deltaW_full_sigma_upper='21/23',deltaW_scope='full-sigma fraction upper bound only',scope='True continuous anisotropic 2D L1 sources; exact commonreceiver reduction and analytic distance integral, not generic high-dimensional realization.')
 return [corner,anis]
def main(output,contract):
 menu=[]
 for L,R in [('0.5','1'),('1','0.5')]:
  for stage,d in [('initial','0'),('boundary','0.25')]:
   for s in ('0','.2','1'):menu.append(dict(stage=stage,L=L,R=R,d=d,s=s))
 for L,R in [('1','2'),('2','1')]:
  for s in ('0','.2','1'):menu.append(dict(stage='old_E_zero',L=L,R=R,d='1',s=s))
  for s in ('.2','1'):menu.append(dict(stage='far',L=L,R=R,d='4',s=s))
  for d in ('1','4'):menu.append(dict(stage='adaptive_menu_only',L=L,R=R,d=d,s='adaptive'))
 rows=[]
 for c in menu:
  a=scalar(c,30);b=scalar(c,50)
  with mp.workdps(70):diff=abs(mp.mpf(a['I1'])-mp.mpf(b['I1']));assert diff<mp.mpf('1e-25');diff=enc(diff)
  rows.append(dict(configuration=c,mp30=a,mp50=b,absolute_precision_difference=diff))
 prods=[dict(n=n,s=s,mp40=product(n,s,40),mp70=product(n,s,70)) for n in (2,16,512,1000000) for s in ('.2','1')];geom=[geometric(c) for c in (4,6,8)]+[geometric(4,True)];g2=geometric2()
 payload=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),contract_sha256=hashlib.sha256(Path(contract).read_bytes()).hexdigest(),scope='Finite true kernels and continuous L1 commonreceiver geometry; original FULL/history and general root bound are not certified.',kernel_definition='phi=h*integral0to1 exp(-|u|/r)dr, P_s,L=L^-1[(1-s)h+sphi], h_R=R^-1 1_QR, M=maxL,R, a=minL,R,b=maxL,R',window_definition='g=min(1,(abs(d)-(b-a)/2)+/b), G=min(sumg,.5exp(-3)n), fixeds normalized product<=exp(-G); adaptive n1 uses B=eceilpi sqrt1',scalar_kernel_rows=rows,fixed_soft_product_rows=prods,common_receiver_1D=geom,common_receiver_2D=g2,counts=dict(actual_scalar_kernels=len(rows),fixed_common_soft_products=len(prods),exact_1D_L1_families=len(geom),continuous_2D_L1_structures=len(g2)),precision_scope='Scalar mp30/50 split ordinary quadrature, products40/70 log arithmetic from32-digit serialized actual scalar integrals (not40/70-digit original integration; large n amplifies serialization limits); not intervals. 1D moments/Phi/covariance exact Fractions. 2D sources use exact product/reduction identities; no invented independent receiver events.')
 Path(output).write_text(json.dumps(payload,indent=2,sort_keys=True)+'\n');print(payload['counts'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',default=str(ROOT/'numeric_checks.json'));p.add_argument('--contract',default=str(ROOT/'task_contract.md'));a=p.parse_args();main(a.output,a.contract)
