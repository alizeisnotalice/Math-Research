# R241 bounded execution plan, revised to window loss

Final actual menu:40 configurations =26 true scalar kernels +8 fixed-common-soft products +4 exact1D L1 families +2 exact2D structures. All ran; complete JSON replay is byte-identical.

The initial more elaborate nine-family optimization plan was reduced before execution when the parent supplied the new window-loss proposition. Planned actual menu:26 true one-dimensional kernel integrals,8 fixed-common-soft product checks,3 exact common-receiver slab families and2 exact two-dimensional continuous L1 structures. New kernel checks take priority; old covariance geometry is retained only in compact exact examples. All are tools, not original FULL/history instances or a general input closure.

## Actual window-loss menu (priority result)

Executed26 one-dimensional actual-kernel cases. Initial/boundary: both(L,R)=(.5,1),(1,.5), at d=0 and d=(b-a)/2=.25, each s=0,.2,1 (twelve). Old-E-zero pressure: both(1,2),(2,1), d=1, each s=0,.2,1 (six). Far: the latter two orientations,d=4,s=.2/1 (four). Adaptive-menu-only: those two orientations, d∈{1,4},actual s(x)=.2 forx<0,.8 otherwise (four). Each case declares its own a=min(L,R),b=max(L,R), so b=2a; no invalid common band a=.5,b=2 is asserted.

The true phi=h*integral_0^1 exp(-|u|/r)dr uses the stable E3 formula. Fixed-soft integrals compute the hard overlap analytically and split the soft quadrature at x=0,d±L/2 and receiver endpoints. Adaptive cases integrate one common measurable s(x) on the same split receiver domain. M=max(L,R), g=min(1,(|d|-(b-a)/2)+/b), G=min(g,epsilon), epsilon=.5exp(-3). Fixeds checks M I1<=exp(-G); adaptive checks only M I1<=Bexp(-G), B=e ceil(pi)=4e. They do not assume a free common-soft maximum or a dimension-independent adaptive column normalization.

Every scalar case was actually evaluated at30/50dps. Maximum saved absolute difference is1.1e-31. These are ordinary split quadratures, not interval certificates; no infinite receiver tails are omitted because the hard column is compact. At the containment boundary g=0 the test retains exact endpoint behavior. At d=1,(a,b)=(1,2), oldE=(d/b-1)+=0 but g=.25 and G=.02489353418393197. Fixeds0/.2/1 yield M I1=.5/.4935550433526219/.4677752167631094 in orientationL1R2 and .5/.4775997085418905/.3879985427094524 inL2R1. Thus the newly covered region has positive actual overlap as well as positive window loss, rather than only hard-disjoint examples. No claim is made that this finite evidence proves the universal envelope.

Eight product cases use n=2,16,512,10^6, one fixed s=.2 or1, the SAME scalar L,R in every coordinate, and homogeneous d_i=1. s=.2 uses(L,R)=(1,2); s=1 uses(2,1). They evaluate the genuine tensor integral through its actual one-coordinate integral in the log domain, then check log(M^n I_n)<=-min(sum g_i,epsilon n). There is no alternating coordinate scale and no independently adaptive softness in these products. At n=10^6 G=24893.53418393197 while oldE_sum=0; recorded log-ratios to the new bound are about-681227.3555 and-921860.1611. This is finite product evidence, not an order fit, extremal search or FULL instance. The parent independently owns the sharper common-soft extremum file; this script intentionally keeps the coarse G and does not repeat that optimization.

## Exact continuous L1 common-receiver geometry

Four1D families retain true piecewise-constant L1 source witnesses and the SAME X uniform[-.5,.5]. Three have eta1=c1_[-.75,-.25],eta2=c1_[.25,.75], c=4,6,8. The fourth has density4 on the overlapping intervals[-.75,.25] and[-.25,.75]. f=beta=eta1+eta2, a=b=1,z=0,H=1,q=3/16. Each witness is<=f; overlap densities are added as genuine f, not subtracted or treated as independent sources. No original nu/history/posterior realization is asserted.

Every receiver cell stores the exact affine vector(m_eta1(X),m_eta2(X)), so it represents the joint mass distribution as a pushforward of the same uniform receiver. Means, all crossmoments and covariance are exact Fraction integrals of these joint cells. Two allowed sets are carefully separated: joint event eta1(Q1(X))<=H AND eta2(Q1(X))<=H, and the stronger full-f event f(Q1(X))<=H. Delta2 bounds the former; deltaW(full f) is compared with the latter, not implicitly applied to an unrelated joint event.

For c=6,8 the covariance is negative and the half-mixture has zero variance with strictly positive mean gap; exact two-witness optimization gives delta2=0. True joint and full-f allowed lengths are0. Their rho_w equals rho_D=32 and128/3 because all source supports have oldE0: distance weighting alone does not make this nearby mass small. For c=4 the mean gap is0, so the positive-gap Cantelli family correctly gives delta2=1, while exact joint receiver length is still0 (the simultaneous equality location has measure zero). This endpoint is retained as a limitation of that moment certificate, not a failure of its inequality. In the overlapping family the true allowed lengths are again0, but delta2=5/152 from equal weights, variance5/48 and mean gap7/4; its covariance entries are37/48 on the diagonal and-9/16 offdiagonal. No witness independence is used.

Delta2 is actually optimized for the two-witness family: the convex variance is quadratic and the mean gap linear, so the stationary derivative of V/gap^2 is linear. The script checks rational stationary candidates, zero-variance candidates and simplex endpoints subject to positive gap. It is not merely a coarse grid over mixtures. Exact Phi(r) for fullf uses tent-piece integration and80-step rational threshold brackets; fullf deltaW upper endpoints are approximately.6545084972,.5538126093,.5 in the three symmetric families. They remain positive even when the joint covariance certificate vanishes. The code does not equate a firstmoment-optimal price with the exact receiver probability.

## Two true2D structures, exact reductions

The four-corner example consists of all products of the intervals[-.75,-.25] and[.25,.75], density18 on each box. Eta1 is the diagonal pair,eta2 the opposite pair. On the SAME X uniformQ1(0), m1+m2=9/2 for every receiver, so the jointH1 event is empty. The unit-density one-coordinate overlap moments are independently computed from exact cells: E l=1/4,E l^2=5/48,E(lr)=1/48. Tensor integration in the two independent receiver COORDINATES then computes each witness mean9/4, variance9/4, crossmoment45/16 and witness covariance-9/4. This coordinate product measure is not independence of the witnesses. The half mixture has positive mean gap and zero variance, hence delta2=0. Beta=f has rho_w=96, with oldE0 throughout its source support. The recorded27/34 is only a full-sigma fraction upper bound on deltaW, not its optimized value.

The anisotropic case uses density6 on[-.75,-.25]x[-2,2] and[.25,.75]x[-2,2]. Every coordinate2 receiver window is entirely inside[-2,2], so the actual common-source mass reduces exactly to the first-coordinate slab mass. Means3/2,variances3/2,covariance-3/2 give delta2=0; true joint/fullf receiver areas are0. Beta mass is24 and rho_D128. Analytic distance integration gives m_w=6[2+4(1-exp(-.5))],rho_w approximately114.3640755568. It is still a large near-source parameter. The reported21/23 is again only the full-sigma fraction upper bound. These are two finite continuous2D examples with exact geometry, not numerical2D grids or generic high-dimensional conclusions.

The actual final count is40 configurations:26 scalar kernels,8 products,4 exact1D families,2 exact2D structures. The initial plan's three1D families became four to retain the explicitly requested overlapping-source pressure case; no further families were searched. The examples show conditional/local zero-traffic structures, while no general source moment, positive fraction of surviving hard sources, or root-order closure is established.

## Reproduction and precision

Existing Python3.12.14 plus vendor mpmath1.3.0 only; no package installed. Products use actual scalar outputs retained to32 digits and40/70dps log arithmetic; they are ordinary numerical evidence, not interval certificates or more accurate than their scalar data. Exact L1 moments/Phi brackets use Fraction and no sampled receiver distribution. All compact hard-domain integration and exact cell boundaries are retained.

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/241/work/numeric_checks.py \
--output /tmp/r241_numeric_replay.json \
--contract /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/241/work/task_contract.md
```

Script and contract may be relocated together. Runtime/path strings are excluded from JSON; source and contract hashes bind the result.

## Frozen final replay

Final JSON uses the frozen updated contract and matches the complete separate-output replay byte-for-byte: 53919 bytes. SHA256 source `0616a5d02c35c56aef6a1a7fb925eb2ee09190164c002cdefdbe984af47afe7d`; JSON `cc0cccfce548e532eec2c236080cad9d98a7635ab84223839addc3c961dbef1c`; contract `58523f5ecfa0bd1dd7cd8aa32b1e1be3d3269dfff127fc2854c2f3b4cb3b61a5`. Runtime is excluded from JSON. Interface: `--output PATH --contract PATH`; paths may be relocated. No further cases were added after the bounded menu.

Actual timed replay: wall0.63s,user0.61s,system0.01s. The product40/70 arithmetic uses32-digit serialized scalar integrals, so large n amplifies that input limitation; both this note and JSON precision_scope explicitly retain it.
