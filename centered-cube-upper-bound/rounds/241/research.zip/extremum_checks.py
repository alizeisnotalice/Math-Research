#!/usr/bin/env python3
"""Finite checks of the common-soft scalar envelope; not general closure."""
import argparse,json
import mpmath as mp

def solve(groups,dps):
    with mp.workdps(dps):
        eps=mp.exp(-3)/2
        gs=[(int(m),mp.mpf(g)) for m,g in groups if m]
        def logval(s):
            ans=mp.mpf(0)
            for m,g in gs:
                v=1-g+s*(g-eps)
                if v<=0:return mp.ninf
                ans+=m*mp.log(v)
            return ans
        def deriv(s):
            ans=mp.mpf(0)
            for m,g in gs:
                v=1-g+s*(g-eps)
                if v==0:return mp.inf
                ans+=m*(g-eps)/v
            return ans
        if deriv(0)<=0:s=mp.mpf(0)
        elif deriv(1)>=0:s=mp.mpf(1)
        else:
            lo,hi=mp.mpf(0),mp.mpf(1)
            for _ in range(4*dps):
                mid=(lo+hi)/2
                if deriv(mid)>0:lo=mid
                else:hi=mid
            s=(lo+hi)/2
        n=sum(m for m,g in gs); G=-logval(s)
        coarse=min(sum(m*g for m,g in gs),eps*n)
        assert G+mp.mpf('1e-40')>=coarse
        assert G<=-n*mp.log(1-eps)+mp.mpf('1e-40')
        for j in range(101):assert logval(mp.mpf(j)/100)<=-G+mp.mpf('1e-40')
        if all(g in [0,1] for m,g in gs):
            k=sum(m for m,g in gs if g==1)
            exact_s=min(mp.mpf(1),k/(eps*n)) if k else mp.mpf(0)
            assert abs(s-exact_s)<mp.mpf('1e-40')
        return s,G,coarse

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);args=p.parse_args()
    rows=[]
    for n in [1,2,16,512,1000000]:
        for label,groups in [('zero',[(n,'0')]),('all',[(n,'1')]),('sparse',[(1,'1'),(n-1,'0')]),('partial',[(1,'.99999'),(n-1,'0')]),('mixed',[(n//2,'.1'),(n-n//2,'.9')])]:
            a=solve(groups,50);b=solve(groups,80)
            with mp.workdps(90):
                err=max(abs(x-y) for x,y in zip(a,b));assert err<mp.mpf('1e-40')
                rows.append({'n':n,'pattern':label,'groups':groups,'s_star':mp.nstr(b[0],32),'G_sharp':mp.nstr(b[1],32),'G_coarse':mp.nstr(b[2],32),'precision_difference':mp.nstr(err,8)})
    out={'scope':'25 finite common-soft envelope optimizations; analytic concavity supplies global maximizer, finite checks do not certify actual FULL traffic or general root budget. Ordinary high precision, no interval certificates.','precision':[50,80],'rows':rows,'count':len(rows)}
    from pathlib import Path
    Path(args.output).write_text(json.dumps(out,indent=2)+'\n')
    print('PASS',len(rows),'scalar extrema; 101-point stress each; 50/80 digit comparison')
if __name__=='__main__':main()
