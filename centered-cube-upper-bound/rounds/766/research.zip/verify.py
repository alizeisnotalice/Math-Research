"""R766 exact sparse-axis repair, true owner near-face bands, and scalar costs."""

import argparse
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from math import comb, prod
from pathlib import Path
from platform import python_version

from flint import arb, ctx, fmpq, __version__ as flint_version


ctx.prec = 256


def ball(x):
    q = Q(x)
    return arb(fmpq(q.numerator,q.denominator))


def interval(c,s):
    return c-s,c+s


def intersect(*intervals):
    return max(a for a,b in intervals),min(b for a,b in intervals)


def length(I):
    return max(Q(0),I[1]-I[0])


def contains(I,x):
    return I[0]<=x<=I[1]


def interval_contains(outer,inner):
    return outer[0]<=inner[0]<=inner[1]<=outer[1]


def polynomial(slices):
    values = [Q(1)]
    for a,b in slices:
        updated = [Q(0)]*(len(values)+1)
        for i,coefficient in enumerate(values):
            updated[i] += coefficient*a
            updated[i+1] += coefficient*b
        values = updated
    return values


def repair_axis_mass(T,I):
    return length(intersect(I,T))/(2*length(T))+Q(sum(contains(I,x) for x in T),4)


def repair_case(k,delta,r,kinds):
    n = len(kinds)
    ratio = Q(r,n)
    T = (Q(-1),Q(1))
    assert 0<delta<=min(Q(1,2),k) and 0<ratio<=Q(1,2)
    templates = {
        "inside_missing":(Q(0),Q(0),(1+k)/2),
        "inside_endpoint":(Q(0),Q(0),k),
        "partial_missing":(Q(1),1-k/2,Q(0)),
        "partial_kept":(Q(1),1-k/2,Q(1)),
        "touch_missing":(1+k,Q(1),Q(0)),
        "touch_kept":(1+k,Q(1),Q(1)),
        "equal":(Q(0),Q(0),Q(1)),
    }
    axis_new = []
    old = []
    for kind in kinds:
        center,z,zprime = templates[kind]
        I = interval(center,k)
        assert contains(T,z) and contains(I,z) and contains(T,zprime)
        repaired = repair_axis_mass(T,I)
        assert repaired >= delta/2
        if kind.startswith("inside") and k==delta:
            assert repaired==delta/2
        if kind.startswith("touch"):
            assert length(intersect(I,T))==0 and repaired==Q(1,4)
        axis_new.append(repaired)
        old.append(Q(contains(I,zprime)))
    d = n-sum(old)
    assert d<=r
    success = prod((1-ratio)*o+ratio*p for o,p in zip(old,axis_new))
    expanded = sum(coef*ratio**j*(1-ratio)**(n-j)
                   for j,coef in enumerate(polynomial(zip(old,axis_new))))
    event = ratio**d*(1-ratio)**(n-d)*prod(p for o,p in zip(old,axis_new) if not o)
    lower = (ratio*delta/2)**r*(1-ratio)**n
    assert success==expanded>=event>=lower>0
    if n<=8:
        direct = sum(ratio**sum(bits)*(1-ratio)**(n-sum(bits))
                     *prod(p if b else o for o,p,b in zip(old,axis_new,bits))
                     for bits in product((0,1),repeat=n))
        assert direct==success
    return {"n":n,"s_k":str(k),"delta":str(delta),"r":r,"missed_axes":int(d),
            "axis_layout":dict(Counter(kinds)),"smallest_chi":str(min(axis_new)),
            "repair_success":ball(success).str(13),"repair_lower":ball(lower).str(13)}


def pressure_case(n,r,d,R):
    assert 0<r<d<=n
    a = 32*n
    h = 1+Q(1,a)
    s0 = ball(R)*(-arb(2).log()/n).exp()
    # The rational s_lower lies below the true dyadic left radius.
    s_lower = R*(1-Q(7,10*n))
    s_k = R*(1-Q(1,4*n))
    assert ball(s_lower)<s0<ball(s_k)<ball(R)
    assert Q(1,2)<(s_k/R)**n<1
    eps = s_lower*r/(8*d)
    signs = [(1 if i%2==0 else -1) if i<d else 0 for i in range(n)]
    zprime = [sgn*eps for sgn in signs]
    y = [-sgn*(s_k-eps/2) for sgn in signs]
    parents = [interval(c,s_k) for c in y]
    E = [interval(c,s_k/a) for c in y]
    E_t = interval(Q(0),Q(1,a))
    assert any(length(intersect(I,E_t))==0 for I in E)
    assert all(interval_contains(interval(Q(0),Q(1)),I) for I in parents)
    assert all(interval_contains(I,interval(Q(0),eps/8)) for I in parents)
    assert all(interval_contains(interval(Q(0),Q(1)),interval(x,eps/8)) for x in zprime)
    miss = [not contains(I,x) for I,x in zip(parents,zprime)]
    assert sum(miss)==d
    assert all(length(intersect(I,interval(x,eps/8)))==0
               for I,x,is_missed in zip(parents,zprime,miss) if is_missed)

    ref = interval(Q(0),h*R)
    widths = []
    for I,x,is_missed in zip(E,zprime,miss):
        width = min(2*h*R,h*R-(1-Q(1,a))*s_lower+abs(x))
        border = (ref[1]-width,ref[1]) if x<0 else (ref[0],ref[0]+width)
        assert interval_contains(ref,I)
        if is_missed:
            assert interval_contains(border,I)
        widths.append(width)
    p = [w/(2*h*R) for w in widths]
    truncated_drift = sum(ball(abs(x))/s0 for x in zprime)
    assert all(abs(x)<s_lower for x in zprime)
    mean = sum(p)
    assert truncated_drift<ball(Q(r,8))
    assert ball(mean)<truncated_drift+arb(1)/2
    masses = polynomial([(1-q,q) for q in p])
    probability = sum(masses[r+1:])
    assert sum(masses)==1 and sum(j*w for j,w in enumerate(masses))==mean
    p1,p0 = p[0],p[-1]
    grouped = sum(comb(d,i)*p1**i*(1-p1)**(d-i)*comb(n-d,j)*p0**j*(1-p0)**(n-d-j)
                  for i in range(d+1) for j in range(n-d+1) if i+j>r)
    assert grouped==probability
    if n<=8:
        direct = sum(prod(p[i] if gate else 1-p[i] for i,gate in enumerate(mask))
                     for mask in product((0,1),repeat=n) if sum(mask)>r)
        assert direct==probability
    true_owner_relative_volume = (s_k/(a*h*R))**n
    assert 0<true_owner_relative_volume<probability
    # Chernoff for a Poisson-binomial sum with mean mean and threshold r+1.
    poisson_log = (r+1)*(1+(ball(mean)/(r+1)).log())-ball(mean)
    assert ball(mean)<r+1 and ball(probability).log()<poisson_log
    return {
        "n":n,"r":r,"d":d,"dyadic_upper_R":str(R),"s_k":str(s_k),"s0":s0.str(13),
        "true_D":truncated_drift.str(13),"exact_wider_band_mean":ball(mean).str(13),
        "poisson_binomial_more_than_r":ball(probability).str(13),
        "poisson_chernoff_log_upper":poisson_log.str(13),
        "actual_owner_relative_volume":ball(true_owner_relative_volume).str(13),
        "enlarged_band_uses_rational_lower_s0":str(s_lower),
    }


def same_label_capacity():
    n,a,h,R = 2,64,Q(65,64),Q(1)
    labels = (
        ((Q(-1,4),Q(0)),Q(3,4)),
        ((Q(1,4),Q(0)),Q(7,8)),
        ((Q(3,4),Q(1,4)),Q(3,4)),
    )
    z,zp = (Q(-1,8),Q(0)),(Q(1,4),Q(1,8))
    reference = [intersect(interval(x,h*R),interval(y,h*R)) for x,y in zip(z,zp)]
    shared = []
    raw = Q(0)
    owner_boxes = []
    for index,(center,s) in enumerate(labels):
        A = [interval(x,s) for x in center]
        E = [interval(x,s/a) for x in center]
        assert (2*R)**n/2 <= (2*s)**n < (2*R)**n
        owner_boxes.append(E)
        if all(contains(I,p) and contains(I,q) for I,p,q in zip(A,z,zp)):
            shared.append(index)
            assert all(interval_contains(I,X) for I,X in zip(reference,E))
            raw += (2*s/a)**n/(2*(2*s)**n)  # mu=2 dx on all parent cubes.
    assert shared==[0,1]
    assert all(any(length(intersect(X,Y))==0 for X,Y in zip(E1,E2))
               for E1,E2 in combinations(owner_boxes,2))
    overlap_volume = prod(map(length,reference))
    bound = 2*h**n*prod(1-abs(x-y)/(2*h*R) for x,y in zip(z,zp))
    assert raw<=bound==2*overlap_volume/(2*R)**n
    s0,delta,r = Q(1,8),Q(1,8),1
    D = sum(min(Q(1),abs(x-y)/s0) for x,y in zip(z,zp))
    assert D>Q(r,8) and R<=2*s0/delta
    large_pair_bound = ball(2*h**n)*(-ball(delta*r/(16*h*2))).exp()
    assert ball(bound)<=large_pair_bound
    return {"n":n,"shared_actual_owner_labels":shared,"excluded_one_price_label":2,
            "sum_v_over_m":str(raw),"exact_overlap_capacity":str(bound),
            "D":str(D),"r":r,"exponential_bound":large_pair_bound.str(13)}


def certified_ceil(x):
    integer = x.ceil().unique_fmpz()
    assert integer is not None
    return int(integer)


def large_costs():
    result = []
    for k in (40,80,256,1024):
        ctx.prec = max(256,k+256)
        n,m = 2**k,2**(k//2)
        assert m*m==n
        log2 = arb(2).log()
        logn = log2*k
        ell = arb(n+2).log()
        delta = (logn/n).sqrt()/64
        assert 0<delta<arb(1)/2
        r = certified_ceil(m*ell**2)
        N = 4+certified_ceil(2*n*(-delta.log())/log2)
        assert 0<r<=n//2
        p = ball(Q(r,n))
        L = m*ell**3
        logh = (arb(1)/(32*n)).log1p()
        log_prefactor = log2+n*logh+arb(N).log()
        logH = (log_prefactor-L.log()).max(arb(0))
        hit_log = r*(p*delta/2).log()+n*(-p).log1p()
        B = r*(2+(2/(p*delta)).log())
        assert 0<-hit_log<B
        obs = m*logH+arb(N).log()+m-ball(Q(r,2))
        common = log_prefactor-delta*r/(16*(logh+2*log2/n).exp())
        assert common>0 or common<0
        rho_upper = ball(Q(r,8)+Q(1,2))
        tail_log = (r+1)*(1+(rho_upper/(r+1)).log())-rho_upper
        assert tail_log<0
        result.append({
            "log2_n":k,"arb_bits":ctx.prec,"m_exact":m,"r_exact":r,"N_exact":N,
            "r_over_n":p.str(15),"B_r":B.str(15),"negative_log_repair_success_floor":(-hit_log).str(15),
            "B_r_over_L":(B/L).str(15),"log_H":logH.str(15),
            "m_log_H_plus_log_N_plus_m_minus_r_half":obs.str(15),
            "common_large_label_bound_log":common.str(15),"common_log_sign":1 if common>0 else -1,
            "poisson_binomial_chernoff_log_upper":tail_log.str(15),
        })
    ctx.prec = 256
    return result


def private_price_allocation():
    """Finite proxy scales for a fixed context whose parents share z=0."""
    A = [(Q(-2),Q(1)),(Q(-1),Q(2)),(Q(-1,2),Q(3,4))]
    price = [((Q(-3),Q(3)),Q(1)),((Q(-7,4),Q(-5,4)),Q(4)),
             ((Q(1,2),Q(3,2)),Q(2))]
    labels = range(len(A))

    def mu(I):
        return sum(w*length(intersect(I,P)) for P,w in price)

    m = [mu(I) for I in A]
    E = [interval((x+y)/2,(y-x)/64) for x,y in A]
    assert all(contains(I,0) and mass>=length(I) for I,mass in zip(A,m))
    assert all(length(intersect(I,J))==0 for I,J in combinations(E,2))
    actual_owner_weights = [length(I)/mass for I,mass in zip(E,m)]
    pi = [w/sum(actual_owner_weights) for w in actual_owner_weights]
    v_proxy = [1,2,3]
    q = [p*s for p,s in zip(pi,v_proxy)]
    assert sum(pi)==1
    edges = sorted({x for I in A for x in I}|{x for P,w in price for x in P})
    J = [Q(0)]*len(A)
    eta_numerator = [Q(0)]*len(A)
    cells = []
    union_mass = Q(0)
    for x,y in zip(edges,edges[1:]):
        mass = mu((x,y))
        active = tuple(j for j in labels if contains(A[j],(x+y)/2))
        psi = sum(q[j] for j in active)
        shares = [q[j]/psi if j in active else Q(0) for j in labels]
        assert 0<=sum(shares)<=1
        assert sum(shares)==bool(active)
        union_mass += mass*bool(active)
        cells.append((active,mass))
        for j in labels:
            J[j] += shares[j]*mass
            if j in active:
                eta_numerator[j] += psi*mass
    assert union_mass<sum(length(P)*w for P,w in price)
    eta = [r/mj for r,mj in zip(eta_numerator,m)]
    lower = [q[j]*m[j]/eta[j] for j in labels]
    assert all(eta[j]==sum(q[k]*mu(intersect(A[j],A[k])) for k in labels)/m[j] for j in labels)
    assert all(a>=b for a,b in zip(J,lower))
    assert J[0]>lower[0] and J[1]>lower[1] and J[2]==lower[2]
    assert sum(J)==union_mass
    subfamilies = []
    for size in range(1,len(A)+1):
        for subset in combinations(labels,size):
            maximum = max(eta[j] for j in subset)
            capacity = sum(mass for M,mass in cells if any(j in M for j in subset))
            lhs = sum(q[j]*m[j] for j in subset)
            restricted_private = sum(J[j] for j in subset)
            assert lhs<=maximum*restricted_private<=maximum*capacity
            subfamilies.append([subset,str(lhs),str(restricted_private),str(capacity),str(maximum*capacity)])
    return {
        "fixed_context_shared_price":"0","v_finite_proxy":v_proxy,"pi_true_receiver_weights":list(map(str,pi)),
        "q":list(map(str,q)),"m":list(map(str,m)),"eta":list(map(str,eta)),
        "J":list(map(str,J)),"J_lower":list(map(str,lower)),
        "total_private_capacity_and_parent_union_mu":[str(sum(J)),str(union_mass)],
        "subfamily_qm_private_mu_union_and_eta_mu_bound":subfamilies,
    }


def report():
    delta_outside = Q(3,4)
    contact = repair_axis_mass((Q(-1),Q(1)),interval(1+delta_outside,delta_outside))
    assert contact==Q(1,4)<delta_outside/2
    return {
        "scope":(
            "Finite true Euclidean parent/owner geometry with closed boundaries; the reference near-face volumes are Lebesgue. "
            "The pressure models can use ordinary Lebesgue price in a larger cube. The very large dimensions are scalar cost checks."
        ),
        "python":python_version(),"python_flint":flint_version,
        "source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "sparse_repairs":[
            repair_case(Q(1,2),Q(1,2),1,["touch_missing","inside_endpoint"]),
            repair_case(Q(1,8),Q(1,8),1,["inside_missing","partial_kept","touch_kept","inside_endpoint"]),
            repair_case(Q(1,4),Q(1,4),2,["partial_missing","touch_missing","partial_kept",
                                         "inside_endpoint","touch_kept","inside_endpoint"]),
            repair_case(Q(1),Q(1,2),1,["equal","equal"]),
            repair_case(Q(1,8),Q(1,8),8,["inside_missing"]*6+["touch_missing"]*2+["partial_kept"]*24),
            repair_case(Q(1,2),Q(1,2),16,["touch_missing"]*7+["inside_missing"]*5+["inside_endpoint"]*52),
        ],
        "outside_delta_range_contact": {"delta":str(delta_outside),"true_chi":str(contact),
                                        "would_be_delta_over_two":str(delta_outside/2)},
        "true_owner_near_faces":[pressure_case(n,r,d,R) for n,r,d,R in
                                 [(4,1,2,Q(1,4)),(16,4,7,Q(1,8)),(64,8,13,Q(1,32))]],
        "actual_same_label_overlap":same_label_capacity(),
        "private_source_allocation":private_price_allocation(),
        "large_scalar_costs":large_costs(),
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out",type=Path)
    group.add_argument("--check",type=Path)
    args = parser.parse_args()
    result = report()
    data = (json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data,"certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    print(f"{len(result['sparse_repairs'])} repair cases, {len(result['true_owner_near_faces'])} actual near-face cases, "
          f"{len(result['large_scalar_costs'])} large scalar checks")


if __name__=="__main__":
    main()

