"""R347 diagnostics: actual interval kernel/flow, rank columns, and algebra.
Fraction checks are exact. Decimal logarithm checks are numerical diagnostics.
"""
from fractions import Fraction as F
from decimal import Decimal, localcontext
N=0; D=0

def check(v):
    global N
    assert v
    N+=1

def dec(x):return Decimal(x.numerator)/Decimal(x.denominator)

# Actual positive-volume 1-D geometry, constant capture on each receiver block.
source=[(F(-1,200),F(1,200),F(1)),(F(3,5),F(61,100),F(2,5)),(F(9,10),F(91,100),F(3,5))]
centers=[(F(-3,100),F(-2,100)),(F(-1,100),F(0)),(F(2,100),F(3,100))]
radii=[F(1),F(7,5),F(2)]
inc=[[1,0,0],[1,1,0],[1,1,1]]
length=F(1,100)
masses=[sum((s[2]*inc[i][j] for j,s in enumerate(source)),F(0)) for i in range(3)]
for i,((l,r),R) in enumerate(zip(centers,radii)):
    check(r-l==length)
    check(masses[i]/R==1)
    for j,(sl,sr,_) in enumerate(source):
        if inc[i][j]: check(r-R/2<=sl and l+R/2>=sr)
        else: check(r+R/2<=sl or l-R/2>=sr)
q=[m/R for m,R in zip(masses,radii)]
rho=[length/m for m in masses]
A=[sum((q[i]*rho[i]*inc[i][j] for i in range(3)),F(0)) for j in range(3)]
P=[[sum((source[j][2]*inc[i][j]/masses[i]*q[k]*rho[k]*inc[k][j]/A[j] for j in range(3)),F(0)) for k in range(3)] for i in range(3)]
for i in range(3):
    check(sum(P[i])==1)
    for k in range(3):check(q[i]*length*P[i][k]==q[k]*length*P[k][i])
check(sum(source[j][2]*A[j] for j in range(3))==sum(q[i]*length for i in range(3)))

# Original reciprocal-J clock mechanics for middle endpoint at first source.
# Diagnostic K,h,epsilon; outside-center gate omitted, so this is not hard G.
K=F(11,8); eps=F(1,10); h=length/2
Jprefix=rho[0]+rho[1]; Jfull=sum(rho)
check(masses[1]>K*masses[0] and masses[2]>K*masses[1])
check(rho[0]>h and rho[2]>eps*Jfull)
omega_prefix=(masses[1]-masses[0])*rho[0]/(masses[1]*Jprefix)
omega_terminal=(masses[1]-masses[0])*rho[0]/(masses[1]*Jfull)
check(omega_prefix==F(1,6)); check(omega_terminal==F(4,31))
omega=radii[1]*(omega_prefix*(1/radii[1]-1/radii[2])+omega_terminal/radii[2])
check(omega==F(87,620))
G=source[0][2]*q[1]*rho[1]*omega
check(G==F(87,86800))
top=[i for i,m in enumerate(masses) if m>=max(masses)/K]
check(top==[2])
share=sum(rho[i] for i in top if masses[i]>K*masses[1])/rho[2]
check(share==1)
incoming=q[1]*rho[1]*omega/rho[2]
check(source[0][2]*rho[2]*incoming==G)

# Atomic rank diagnostics satisfying the window-cap and high-past hypotheses.
# These scalar measures are not substitutes for actual receiver geometry.
with localcontext() as ctx:
    ctx.prec=70
    for count in (32,64,96):
        ws=[F(1,2) if i%3==0 else F(1) if i%3==1 else F(3,2) for i in range(count)]
        B=F(3,2); J=sum(ws)
        for epsilon in (F(1,4),F(1,8),F(1,16)):
            if J<=B/epsilon: continue
            L=Decimal(1)+(Decimal(1)/dec(epsilon)).ln()
            past=[sum(ws[:i]) for i in range(count)]
            upper=[sum(ws[i+1:]) for i in range(count)]
            active=[past[i]>B/epsilon and upper[i]>epsilon*J for i in range(count)]
            for target in range(count):
                col=sum((ws[i]/upper[i] for i in range(target) if active[i]),F(0))
                assert dec(col)<=L; D+=1
                for beta in (F(1,20),F(1,10),F(1,2)):
                    selected=[i for i in range(target) if active[i] and ws[-1]/upper[i]>=beta]
                    # The top contains the final mass atom; only its column receives.
                    topcol=sum((ws[i]/ws[-1] for i in selected),F(0)) if target==count-1 else F(0)
                    assert dec(topcol)<=L/dec(beta); D+=1
                    check(sum((ws[i] for i in selected),F(0))<=topcol*ws[-1] if target==count-1 else True)

# Complete receiver ledger remains unchanged by the source-only joint branch.
eps=F(119,3072); outer=F(128,119)
check(2*outer*F(13,3)*eps==F(13,36))
check(F(13,36)+F(1,256)==F(841,2304))
print(f'PASS: {N} exact Fraction assertions; {D} 70-digit Decimal inequality diagnostics. No original root-hard simulation or global closure is claimed.')
