"""R347 finite-atomic shifted Hardy checks; standard library only.
Numerical log comparisons are diagnostics, not substitutes for the proof.
All shifted tails are strict, and window capacities include both endpoints.
"""
from fractions import Fraction as F
from decimal import Decimal, getcontext
from itertools import product
import json

getcontext().prec = 80
tol = Decimal("1e-65")
def dec(x):
    x = F(x)
    return Decimal(x.numerator) / Decimal(x.denominator)

def rank_integral(lo, hi, a, B):
    """Integral_lo^hi 1/max(a,t-B) dt, with lo >= a."""
    if hi <= lo:
        return Decimal(0)
    cut = a + B
    ans = Decimal(0)
    if lo < cut:
        end = min(hi, cut)
        ans += dec(end-lo)/dec(a)
        lo = end
    if hi > lo:
        ans += (dec(hi-B)/dec(lo-B)).ln()
    return ans

counts = dict(measures=0, hardy_cases=0, restricted_columns=0,
              active_atom_exact_tests=0, active_atom_rank_tests=0,
              high_occupancy_specializations=0, endpoint_windows=0)
masses = tuple(map(F, (1,2,4,8)))
Ks = (F(3,2), F(2), F(3))
thetas = (F(1,10), F(1,4), F(1,2), F(3,4))
largest_ratio = Decimal(0)
for weights0 in product(range(3), repeat=4):
    if not any(weights0):
        continue
    weights = tuple(map(F, weights0))
    J = sum(weights)
    counts["measures"] += 1
    for K in Ks:
        candidates = sorted(set(masses + tuple(m/K for m in masses)))
        B = max(sum(w for m,w in zip(masses,weights) if t <= m <= K*t)
                for t in candidates)
        for t in candidates:
            assert sum(w for m,w in zip(masses,weights) if t <= m <= K*t) <= B
            counts["endpoint_windows"] += 1
        U = lambda t: sum(w for m,w in zip(masses,weights) if m > t)
        V = lambda t: sum(w for m,w in zip(masses,weights) if m >= t)
        for theta in thetas:
            a = theta*J
            active = [i for i,m in enumerate(masses) if weights[i] and U(K*m)>a]
            C = sum((weights[i]/U(K*masses[i]) for i in active), F(0))
            rhs = rank_integral(a,J,a,B)
            if B <= J-a:
                closed = dec(B/a)+(dec((J-B)/a)).ln()
            else:
                closed = dec((J-a)/a)
            assert abs(rhs-closed) <= tol
            assigned = Decimal(0)
            for i in active:
                m,wt = masses[i],weights[i]
                assert V(m)-U(K*m) <= B
                assert U(m)>a and U(K*m)>=max(a,V(m)-B)
                counts["active_atom_exact_tests"] += 1
                atomrank = rank_integral(U(m),V(m),a,B)
                assert dec(wt/U(K*m)) <= atomrank+tol
                assigned += atomrank
                counts["active_atom_rank_tests"] += 1
            assert dec(C) <= assigned+tol
            assert assigned <= rhs+tol
            assert dec(C) <= rhs+tol
            assert rhs <= dec(B/a)+(Decimal(1)/dec(theta)).ln()+tol
            if rhs:
                largest_ratio=max(largest_ratio,dec(C)/rhs)
            counts["hardy_cases"] += 1
            for mw in masses:
                restricted = sum((weights[i]/U(K*masses[i]) for i in active
                                  if masses[i] < mw/K), F(0))
                assert restricted <= C
                assert dec(restricted) <= rhs+tol
                counts["restricted_columns"] += 1
            if B < theta*J:
                simple=Decimal(1)+(Decimal(1)/dec(theta)).ln()
                assert rhs <= simple+tol
                if theta <= F(1,2):
                    sharp=Decimal(1)+(dec((1-theta)/theta)).ln()
                    assert rhs <= sharp+tol
                counts["high_occupancy_specializations"] += 1

# Long atomic strings test the small-theta regime and exact K*m endpoint.
long_cases = 0
for N in (16,32,64):
    ms = [F(2)**i for i in range(N)]
    for K in (F(3,2),F(2)):
        B = F(1) if K < 2 else F(2)
        J = F(N)
        for theta in (F(1,10),F(1,5),F(1,4)):
            a=theta*J
            U=lambda t: sum(F(1) for m in ms if m>t)
            C=sum((1/U(K*m) for m in ms if U(K*m)>a),F(0))
            rhs=rank_integral(a,J,a,B)
            assert dec(C)<=rhs+tol
            if B<theta*J:
                assert rhs<=Decimal(1)+(dec((1-theta)/theta)).ln()+tol
            long_cases += 1
counts["long_atomic_cases"] = long_cases
print(json.dumps({"status":"PASS", "counts":counts,
                  "largest_finite_case_C_over_Hardy_bound":str(largest_ratio),
                  "decimal_precision":getcontext().prec}, indent=2))
