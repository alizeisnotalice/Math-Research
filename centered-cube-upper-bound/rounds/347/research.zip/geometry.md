# R347 — A real upper-witness column pays repeated capture into a top mass window

This note combines the new dimension-independent upper-witness column estimate with a real sourcewise mass-window capacity. It pays an additional joint source–receiver branch of the exact R346 residual, with no new receiver fee. The remaining branch has a majority of its upper capture outside the sourcewise top window. Neither that condition nor the reversible kernel below proves a global root-order bound.

## Frozen traffic and theorem

Retain the complete R346 contract: f≥0 in L¹, actual finite receiver set E with Lebesgue du, a≤R_u≤b≤2a, m_u=∫Q_u f=q_uR_uⁿ, q_-=3λ/4≤q_u≤λ, dμ=du/m_u, c_u(y)=1Q_u(y), ρ_y(du)=c_u(y)dμ(u), J_y(r)=ρ_y{R_u≤r}, J_b=ρ_y(E), and U_y(t)=ρ_y{m_u>t}. The clock is the original ell=b^(-n)δ_b+n r^(-n-1)dr, with ell([R,b])=R^(-n). Keep K=e^(√n), h=(1+√n)/(εq_-), original H, high-past, outside-center and far-mass gates. All fields remain computed from full f.

Let G_rel[g] be the exact original traffic with outer source 0≤g≤f and the additional R346 relative-upper condition U_y(Km_u)>εJ_b(y). As in R346 core, its clock-integrated form is

    G_rel[g]=∫g(y)∫ q_u ω_y(u)1_{U_y(Km_u)>εJ_b(y)}ρ_y(du)dy,  (1)

where 0≤ω_y(u)≤1 is the integral of the original reciprocal-J, lower endpoint, high-past and outside-center factors against the original clock, multiplied by R_uⁿ. In particular ω=0 unless the original high-past gate holds. No gate is evaluated at a transported receiver or at a new clock time.

Define the actual essential mass maximum

    M(y)=ess sup_{ρ_y} m_u,

with M=0 on zero-capture rows. It is measurable: for t≥0, {M>t}={U_y(t)>0}. On J_b>0 it lies in [q_-aⁿ,λbⁿ]. Define the sourcewise top window

    Top_y={w:M(y)/K≤m_w≤M(y)}.

Essential-supremum null sets are discarded only under ρ_y and then under the original source integral by Tonelli. Define the fraction of the real upper capture lying in that window by

    p_y(u)=ρ_y{w:m_w>Km_u, w∈Top_y}/U_y(Km_u),       (2)

on U>0, and zero otherwise. This is a measurable fraction in [0,1].

For any 0<β≤1, the complete original branch with p_y(u)≥β satisfies

    G_{rel, p≥β}[g]≤[λ L_ε B/β]∫g,
    B=(1+logK)/q_-=(1+√n)/q_-,
    L_ε=1+log(1/ε).                                  (3)

Thus with β=1/2,

    C_hit,n,ε=2(λ/q_-)(1+√n)[1+log(1/ε)]             (4)

is a source-only fee. For the existing excess source g_ex, the fee is C_hit W_ex with W_ex=∫g_ex. This use of W_ex is justified by a pointwise-in-source top-window capacity; it is not a replacement of full f in the definitions of masses or geometry.

## Real closed mass-window capacity

For any t>0 and any fixed source y, the actual capture measure satisfies

    ρ_y{u:t≤m_u≤Kt}≤(1+logK)/q_-=B.                (5)

To prove it, write d=2||u-y||∞. Capture implies R_u≥d. On the window, R_u≤(Kt/q_-)^(1/n) and

    1/m_u≤min{1/t, 1/(q_-dⁿ)}.

Integrate this envelope over actual center space. Put L=(t/q_-)^(1/n) and B_radius=(Kt/q_-)^(1/n). The inner cube contributes Lⁿ/t=1/q_-. Cubic shells from L to B_radius contribute

    (n/q_-)∫_L^B_radius dr/r=logK/q_-.

Dropping the receiver set and original radius restrictions only enlarges the integral. This proves (5), including atoms at either mass endpoint. It uses no source-density cap and no λ factor. In particular

    ρ_y(Top_y)≤B.                                  (6)

## Dimension-independent source-column bound, including atoms

For completeness, the column input from R347 core has the following precise form. At fixed y set J=J_b(y), V_y(t)=ρ_y{m_u≥t}. If any original high-past row is active, then J>h=B/ε. For every mass m,

    U_y(Km)≥V_y(m)-B,                               (7)

because V_y(m)-U_y(Km)=ρ_y{m≤m_u≤Km}≤B by (5).

On the active relative-upper domain U_y(Km)>εJ, therefore

    1/U_y(Km)≤1/max{εJ,V_y(m)-B}.

To integrate in m without losing mass atoms, assign an atom at m its descending-rank interval [U_y(m),V_y(m)], whose length is precisely the atom mass. The function t↦1/max{εJ,t-B} is nonincreasing. Its value at V_y(m) is no greater than its average over that rank interval. The same statement for the nonatomic part follows by the tail quantile transformation (equivalently, spread each atom uniformly over its rank interval). Since U_y(m)≥U_y(Km)>εJ on the active set, all these intervals lie in [εJ,J]. Hence

    ∫_{active}ρ_y(du)/U_y(Km_u)
       ≤∫_{εJ}^J dt/max{εJ,t-B}
       ≤1+log(1/ε)=L_ε.                            (8)

For the last bound, if J≤εJ+B the integral is ≤B/(εJ)<1. Otherwise it equals B/(εJ)+log((J-B)/(εJ)), which is ≤1+log(1/ε). Rows without original high past have zero traffic and need no estimate. This is the closed-window/shifted-rank argument; it is stronger than the elementary 1/ε column bound.

All incoming densities below are relative to ρ_y(dw) at fixed y. They are not asserted to be densities relative to unweighted dw before the source is integrated.

## Conservative routing of the entire hit branch

On the branch p_y(u)≥β, define the real conditional upper-witness probability

    Π_y^Top(u,dw)=1(m_w>Km_u)1_{Top_y}(w)ρ_y(dw)
                  /[p_y(u)U_y(Km_u)].              (9)

Its denominator is positive and at least βU_y(Km_u), and its row integral is exactly one. Insert (9) into (1), restricted to p≥β. This preserves the original total and the common source y. It does not change ω or require upper witnesses to lie inside the old physical prefix.

The resulting incoming density relative to ρ_y(dw) is

    k_y^Top(w)=1_{Top_y}(w)
      ∫ q_uω_y(u)1_{rel}1_{p≥β}1(m_w>Km_u)
                          ρ_y(du)/[p_y(u)U_y(Km_u)].

Use q_u≤λ, ω≤1, p≥β and (8):

    0≤k_y^Top(w)≤(λL_ε/β)1_{Top_y}(w).             (10)

Now conservation, (6) and Tonelli give

    G_{rel,p≥β}[g]
       =∫g(y)∫k_y^Top(w)ρ_y(dw)dy
       ≤(λL_ε/β)∫g(y)ρ_y(Top_y)dy
       ≤(λL_εB/β)∫g.

This proves (3). It pays the entire original branch satisfying a quantitative upper-hit condition, not just an unnormalized portion selected from that branch. All original lower receivers, gates and physical-clock weights remain inside ω before routing. The repeated use of the same top receiver by many original large endpoints is precisely what the column cap (10) pays.

## Relation to the older receiver covering route

There is also a full-W receiver-set version. Let

    A_good={w:m_w≥K^(-1)∫Q_{(1+√n)b}(w) f}.

The proved R342 covering theorem gives

    X_q(A_good)≤C_cover,n W,
    C_cover,n=2[1+3√n+log(8/3)].

If p_good(y,u)=ρ_y{m_w>Km_u,w∈A_good}/U_y(Km_u)≥β, the same conditional routing gives an incoming density relative to actual dw bounded by

    (λL_ε/β) [∫g(y)c_w(y)dy/m_w]1_{A_good}(w).

Consequently

    G_{rel,p_good≥β}[g]
       ≤(λ/q_-)L_ε C_cover,n W/β.                  (11)

The last source budget is full W, because the cited receiver covering theorem uses full f. It must not be changed to W_ex merely because g=g_ex.

For n≥4, any w∈A_good capturing y belongs to Top_y: every receiver z capturing y has Q_z⊂Q_{3b}(w)⊂Q_{(1+√n)b}(w), hence M(y)≤K m_w. Therefore p_good≤p, and the top-window theorem covers at least the branch in (11), with a sharper sourcewise fee. For n≤3 the original high-past gate is empty at the actual ε=119/3072. Formula (11) is an independent explanatory consequence, not a second fee added to (3).

## New exact residual and replacement ledger

Use β=1/2. The new residual G_new[g_ex] is exactly the original R346 residual with the additional gate p_y(u)<1/2. The disjoint identity is

    G_rel[g_ex]=G_{rel,p≥1/2}[g_ex]+G_new[g_ex].     (12)

Every nonzero new contribution still has original lower occupancy >h, relative terminal upper occupancy U_y(Km_u)>εJ_b, excess source g_ex, original far/outside/H gates and physical ell. Moreover

    ρ_y{w:Km_u<m_w<M(y)/K}
      >U_y(Km_u)/2>εJ_b(y)/2.                      (13)

Thus a majority of the real upper capture remains outside the top window. In particular m_u<M(y)/K²; for each w counted in (13), the essential maximum supplies larger same-source witnesses, but no uniform additional occupancy is asserted for them. There is no proof that p≥1/2 must occur, and no free recursive application of (3) is claimed.

The R346 ledger has

    B_H≤G_rel[g_ex]+(13/3)εX_q+C_{ε,n}W+D_top,n W_ex.

Replace only its residual using (3),(12):

    B_H≤G_new[g_ex]+(13/3)εX_q+C_{ε,n}W
                         +[D_top,n+C_hit,n,ε]W_ex. (14)

The two W_ex fees in (14) pay different pieces of the exact source–endpoint split: the old relative-low branch and the new relative-high/top-hit branch. They are added legitimately; no claim is made that one fee pays both. The R342 fee and the old R345 absolute-future fee are not added again.

The entrance becomes

    T_entrance≤8λHW+2d_eff A_nW_ν/H+2G_new[g_ex]
       +(26/3)εX_q+2C_{ε,n}W
       +2[D_top,n+C_hit,n,ε]W_ex.                   (15)

No receiver fee is added this round. At ε=119/3072 and Λ=128/119, the outer receiver coefficient remains 13/36; adding the historical 1/256 only when it belongs to the same certified ledger gives 841/2304. The remaining 1463/2304 is unallocated. Other unresolved slots remain due.

## Correct reversible common-source kernel and its limitation

The following kernel is a useful exact auxiliary structure, not the reason for the new payment. Put

    A_y=∫q_uρ_y(du),   σ(du)=q_u du,
    P_q(u,dw)=∫[f(y)c_u(y)/m_u]
                    [q_w c_w(y)/(m_w A_y)]dy dw.   (16)

The contribution with A_y=0 is zero. Since

    ∫f(y)A_y dy=X_q=σ(E),

Tonelli shows that for σ-almost every u its source posterior gives zero mass to {A_y=0}; hence P_q is Markov almost everywhere. It can be defined as the identity kernel on the exceptional σ-null receiver set. Its symmetric joint measure is

    σ(du)P_q(u,dw)
       =∫ [f(y)/A_y][q_uρ_y(du)][q_wρ_y(dw)]dy.     (17)

Thus σ is invariant and P_q is reversible. For any square-integrable receiver test φ, its exact Dirichlet form is

    (1/2)∫σ(du)P_q(u,dw)[φ(u)-φ(w)]²
       =∫f(y)A_y Var_{qρ_y/A_y}(φ)dy.              (18)

The original relative-upper condition implies a same-source q-weighted upper probability at least (q_-/λ)ε. However, normalizing that probability back to one costs up to λ/(q_-ε). Reversibility alone supplies no absorbable coefficient for the original Ω-weighted traffic, and (18) is not a source-only root budget. In particular old Ω and its physical clock do not become a symmetric pair factor under (17). The payment above uses the proved incoming column and the actual top-window capacity, rather than silently absorbing this normalization or clock change.

## Executed local diagnostics

`python3 /tmp/r347_geometry_checks.py` passed 1,767 exact Fraction assertions and 2,304 separate 70-digit Decimal inequality diagnostics. Decimal logarithm comparisons are numerical checks, not exact certificates. The exact checks include normalized routing, qdu detailed balance, real source/receiver capture and mass identities, clock integration and ledger arithmetic.

The real positive-volume one-dimensional fixture has three source intervals of mass 1, 2/5 and 3/5, and three disjoint receiver intervals of length 1/100 with radii/masses 1, 7/5 and 2, so q=1. Source capture is constant on each receiver interval and is checked across its full range. At diagnostic K=11/8, ε=1/10 and small h, the middle receiver at the first source packet has lower and upper capture; its exact clock-averaged Ω is 87/620. The lifted branch mass is 87/86800, and all of that upper flow lands in its top mass window. The outside-center gate is explicitly omitted in this diagnostic, and its parameters are not the original root ones; it is not a simulation of hard G.

Separate scalar rank tests satisfy the stated closed-window and high-past algebraic hypotheses and verify the column inequalities. They do not replace the real geometric proof of (5). No finite check proves that the remaining branch (13) has an absorbable receiver fee or a source-only root budget.
