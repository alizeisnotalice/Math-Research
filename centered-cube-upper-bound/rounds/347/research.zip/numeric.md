# R347 — finite-atomic shifted-survival Hardy column

This is a finite positive-measure diagnostic, **not an actual-cube receiver construction**, not receiver dx, and not a certificate of global source funding. Large total J and active columns here do not establish a high-crowding branch for actual cubes. The optional actual-cube extension was not undertaken.

## Exact contract

For positive locations m_i and nonnegative atomic weights a_i, let J=sum a_i, U(t)=rho{m>t}, V(t)=rho{m>=t}, and let

`B=sup_{t>0} rho[t,Kt]`, K>=1,

where the window is closed at both ends. Repeated locations are grouped for rank bookkeeping, while the original ungrouped atomic column is separately recomputed. Zero-weight atoms remain in the input but add no rank mass. For epsilon=119/3072,1/8,1/4 the column is

`C=sum_{U(Km)>epsilon J} rho{m}/U(Km)`.

The strict active cutoff excludes U(Km)=epsilon J, which is explicitly checked. There is no division by a zero future. J=0 is separately assigned C=0, with no normalized log expression evaluated.

The script enumerates every critical window endpoint `t=m_i` and `t=m_i/K`. Between consecutive critical points membership is constant; it also checks midpoint windows and the two exterior ranges. This certifies the exact finite supremum B, including atoms on both window boundaries. It does not replace closed windows with a half-open convention.

## Rank bridge and integral

For each positive grouped atom at m, the original rank interval is `(U(m),V(m)]`, of length rho{m}. Exact enumeration verifies

`V(m)-U(Km)=rho[m,Km] <= B`.

If active, `epsilon J<U(Km)<=U(m)<V(m)<=J`. Therefore for every rank t in its interval,

`max(epsilon J,t-B) <= U(Km)`.

The atomic column is bounded by the integral over these disjoint active rank intervals, hence by the full interval integral

`I=integral_(epsilon J)^J dt/max(epsilon J,t-B)`.

Numerically, the script also computes the lower Riemann sum over the active rank blocks, with denominator `max(epsilon J,V(m)-B)`. Each atomic term is no larger than that block's sum, and the aggregate block sum is certified no larger than the outward rational lower bound on I. This independently checks the entire finite inequality, not just individual window capacities.

The exact integral is piecewise:

- if `B<=(1-epsilon)J`, `I=B/(epsilon J)+log((J-B)/(epsilon J))`;
- otherwise, `I=(1-epsilon)/epsilon`.

At equality the log argument is1 and both branches coincide. Logarithms are enclosed by positive atanh series, with power-of-two reduction and an exact geometric remainder. The checks use a **lower** bound on I to certify C<=I. If B<=epsilon J, they additionally verify the **upper** bound on I is below the lower bound on `1+log(1/epsilon)`. No float comparison certifies either result.

## Registered stages and results

Two fresh Python processes passed **12,014 exact rational/interval checks**: the original Hardy stages have 8,175 checks (initial544, boundary1,336, expanded6,295), and the added Top-conditioned joint module has 3,839 checks. The original Hardy evidence is unchanged. There are 11 finite models and three epsilons each. Decimal values below are display diagnostics only.

Initial models: zero measure; one atom; four unequal atoms; 32 equal-weight locations 2^i with K=3/2. Boundary models: 64 locations 2^i, each split into repeated weights1/3+2/3 and K=2; an exact integral-branch equality model with J4,B3 at epsilon1/4; a heavy atom; and 32 locations (3/2)^i with K=3/2. Expanded models: 128 separated equal-weight locations; 256 locations10^i with K100; and 128 unequal-weight locations with K8 plus explicit zero-weight atoms. All inputs are stored in the result.

At epsilon=119/3072:

| Model | J | exact B | B<=epsilon J? | active grouped atoms | C | I |
|---|---:|---:|---|---:|---:|---:|
|separated32|32|1|yes|30|3.027245195|4.025934592|
|repeated64, exact K boundary|64|2|yes|60|3.212392888|4.025934592|
|exact K ratios32|32|2|no|29|2.994987131|4.799867458|
|separated128|128|1|yes|123|3.342001259|3.444798096|
|wide256|256|3|yes|244|3.283611882|3.541693654|
|unequal128|255/8|9/8|yes|119|3.125489709|4.126150688|
|heavy atom|115|101|no|10|17.073181222|23.817500855|

The small-window models have genuinely nonempty active columns in the stated atomic sense. They demonstrate that the strengthened log bound is nonvacuous at the small epsilon. The heavy-atom model confirms why its small-window hypothesis matters: its C is much larger, while the general piecewise integral bound remains valid. The exact K-ratio model also shows that closing the window at both endpoints changes B from a single atom to two; that change cannot be dropped in the rank bridge.

At the separate integral-branch boundary J4,B3,epsilon1/4, both displayed formulas give I=3 exactly. Repeated atoms and active-cutoff equalities are retained throughout. No extrapolated dimension exponent or original root parameter is inferred from these finite examples.

## Added Top-conditioned joint transport

On the same frozen atomic models, define the **closed** Top set `{m>=Mmax/K}` using the maximal positive-measure mass location. Its total measure is bounded by B because it is exactly a closed K-window. Empty measure has empty Top. Keep the original strict relative-active gate `U(Km)>epsilon J` and set beta=1/2. For each active row u,

`Utop(u)=rho{w in Top:m_w>K m_u}`, `pTop=Utop/U(Km_u)`.

Select rows with pTop>=beta, including equality. Their conditioned target kernel has density `1{w in Top,m_w>K m_u}/Utop(u)` relative to the **unchanged** target measure rho. The code independently verifies its integral is1 and retains the original row multiplier omega: either1 or nonuniform `1/(2+rank mod3)`, always in (0,1]. It does not delete row mass after conditioning or replace the target measure by a rescaled Top distribution.

For each model and epsilon, exact outgoing `sum_selected rho_u omega_u` equals incoming `sum_Top rho_w column_density(w)`. The column density is at most C/beta, then at most the certified Hardy I/beta. Thus total outgoing is at most `I*rho(Top)/beta <= I*B/beta`. When B<=epsilon J, the extra `L_epsilon=1+log(1/epsilon)` bound is certified for every column and for the total. For models failing that hypothesis, the module uses the general actual I bound and does not assert L_epsilon.

Nonempty examples at epsilon119/3072:

| Model | rho(Top) | selected pTop | outgoing= incoming, omega1 | outgoing= incoming, nonuniform omega |
|---|---:|---|---:|---:|
|separated32|1|1/2|1|1/4|
|repeated64 exact-K-edge|2|1/2,2/3|2|7/12|
|unequal128|1|8/15,4/7,2/3|3/4|23/96|

In separated32 the selected row has mass location 2^29, original future2, target future1, and strict activity2>epsilon*32. This is the requested pTop=1/2 boundary with nonzero outgoing traffic. Empty selected rows in other parameter cases are kept in the result, not presented as nonempty demonstrations. The module is a finite atomic conditional-transport certificate, not an original highpast/clock or actual-cube payment theorem.

## Reproduce and scope

Only the three owned files are needed: `r347_numeric.py`, `r347_numeric_result.json`, and this note. Standard library, no optimizer, no historical /tmp imports:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /path/to/r347_numeric.py
```

The JSON is written beside the script and includes exact source atoms, capacities, active rank blocks, strict-threshold equalities, rational log enclosures, and all conditioned Top transport rows/columns. The mathematical rank argument is finite and exact; the computations support that argument's normalization and boundary conventions, without asserting geometric realization of the input measures.
