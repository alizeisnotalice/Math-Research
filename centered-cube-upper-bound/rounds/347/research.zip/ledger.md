# 第347轮完整替换总账

原合同/入口与历史外乘按既有记录承接；本轮不声称重新认证全部历史归约。W=W_beta=∫f，ν≤f dx，W_nu=ν(Rⁿ)，Xq=∫E q_u du≤X=λ|E|，A_n=1+nlog(b/a)。
\[
T_{\rm entrance}\le8\lambda HW+2d_{\rm eff}A_nW_\nu/H+2B_H.
\]
保持ε=119/3072，原K、h、α、H及所有时钟门。g_ex=(f−T_clip)_+，W_ex=∫g_ex，T_clip为第344轮冻结阈值。定义
\[
C_{\varepsilon,n}=\tfrac\lambda{q_-}[(2+3\sqrt n+2e^{-\sqrt n})/\varepsilon+1+\sqrt n],
\quad C_{\rm top,n}=1+\sqrt n+\log(4/3),
\]
\[
L_\varepsilon=1+\log(1/\varepsilon),\qquad
C_{\rm hit,n}=2\tfrac\lambda{q_-}(1+\sqrt n)L_\varepsilon.
\]

将346余项按来源—大端的目标窗占比p≥1/2、p<1/2精确拆分。前者按真实共同来源列容量支付C_hit,n W_ex。令G_rem为后者，完整槽成为
\[
B_H\le G_{\rm rem}[g_{\rm ex}]+\tfrac{13}{3}\varepsilon X_q
+C_{\varepsilon,n}W+(C_{\rm top,n}+C_{\rm hit,n})W_{\rm ex}.
\]
更精确的接收费用仍可保留3εXq+λε∫g_exJ_b。新C_hit是与原已付相对低未来分支不重叠的交通费用，不再次叠加342或345的旧覆盖付款。目的地旧增长好集推论若列出，也不另外计费。

入口为
\[
T_{\rm entrance}\le8\lambda HW+2d_{\rm eff}A_nW_\nu/H+2G_{\rm rem}[g_{\rm ex}]
+\tfrac{26}{3}\varepsilon X_q+2C_{\varepsilon,n}W
+2(C_{\rm top,n}+C_{\rm hit,n})W_{\rm ex}.
\]
本轮无新增X费用。历史Λ=128/119下仍13/36；若CZ的1/256属于认证同一X外账，仍合计841/2304，余1463/2304未分配。剩余吸收空间不等于其他项已付。

完整未付清单：

1. G_rem：原相对高未来交通且p<1/2，多数上尾落在sourcewise Top窗外；跨尺度与多步入列费用未闭合。一次流的列帽不能直接用于任意迭代输入。
2. 一般软密集C_H−S_H、越阈I_H、hard合同外质量可比重尾交通及未嵌入hard项。
3. 宽距离、低pe、极端尺度比及全部阈值补集，高度折扣和逆尺度比费用同时保留。
4. 历史初始I_time、删除跳跃J_time、未来被删来源D_time独立预算；物理b原子不替代它们。
5. 后缀P/Phi_next负信用只使用一次；H、层、物理尺度、来源、外积分与极限费用均未自动求和。

单独维度无关Hardy列界的常数>1，不算另一项可吸收付款。一般n^(1/2+o(1))一致上界仍未闭合。
