# R347 final independent audit

**PASS for the frozen statements and their stated scope.** The sharp actual-receiver mass window and atom-safe shifted-Hardy bound are valid. Their combination with the sourcewise Top destination capacity pays a genuine additional positive branch of the original R346 residual by a source-only root-order fee. No new receiver absorption is charged. The remaining original branch and the general problem are not closed.

This reviewer first derived the two propositions independently in `/tmp/r347_audit_pre.md`, then read the complete frozen main, ledger, core, geometry, numerical note and three scripts. Only owned audit files were changed. No author file, Git state, numerical output or old contract was modified. The final main's added execution/scope paragraphs were read at the bound hash below. Historical reductions have not been comprehensively reaudited.

## 1. True receiver volume and complete rank atoms

For fixed source y and t>0, captured receivers in the closed mass band [t,Kt] obey

    1/m_u≤1/max(t,q_-(2||u-y||∞)^n),
    (2||u-y||∞)^n≤Kt/q_-.

The exact volume coordinate z=(2||u-y||∞)^n gives band capacity B_K=(1+logK)/q_-. Restricting the actual receiver set, physical radii or any positive original gate reduces the integral. This is actual du geometry, not a source density estimate or a volume ratio applied to f. The mass band is closed at both endpoints, including receiver mass atoms.

Writing U(m)=ρ{m_u>m} and V(m)=ρ{m_u≥m}, the exact difference V(m)-U(Km) is the closed band [m,Km]. On the relative-active domain U(Km)>θJ, the whole atom-rank interval (U(m),V(m)] lies above θJ. The reciprocal shifted tail is bounded by the decreasing function 1/max(θJ,v-B) throughout that interval. The generalized-quantile/randomized-rank proof in core covers both atoms and nonatomic mass, without removing a physical atom or changing the actual receiver distribution. An additional original endpoint restriction only deletes nonnegative terms.

The integral has the stated two regimes:

    F(θ,β)=β/θ+log((1-β)/θ), β≤1-θ;
    F(θ,β)=(1-θ)/θ, β≥1-θ,   β=B/J.

It is continuous at the regime boundary and nondecreasing in β. On original nonzero source rows J>h=B_K/ε, β<ε, so it is bounded by L_ε=1+log(1/ε). The optional sharper bound 1+log((1-ε)/ε), for ε≤1/2, is also valid. Neither the main nor its fee requires that sharpening. Zero-J rows are zero and no inverse is evaluated there.

The sourcewise estimate used in the joint payment is therefore

    ∫_{relative-active, m_u<m_w/K}ρ_y(du)/U_y(Km_u)≤L_ε.

The original high-past source support must remain when invoking J>h. It does remain: the exact old factor ω is zero off that support. The source-integrated density relative to dw in core (3),(10) is a valid auxiliary consequence, but is not substituted as a fixed-y bound in the Top proof.

## 2. Top routing pays the entire stated original branch

The actual capturing essential maximum M(y) is measurable through {M>t}={U_y(t)>0}, with M=0 on zero-capture rows. For J>0 it is finite and positive. Its essential upper bound holds ρ_y-almost everywhere and passes through the source integral by Tonelli. The source-dependent closed window

    Top_y={M(y)/K≤m_w≤M(y)}

has ρ_y-mass at most B_K. Empty rows have no Top traffic. Every quantity remains computed from the full original f.

After the original physical clock and small endpoint are integrated, the exact original R346 cost measure is

    g(y)q_uω_y(u)1_relative ρ_y(du)dy,  0≤ω≤1.

All original prefix/H/high-past/outside/far/source gates are retained inside that expression. On the branch with p_top(y,u)≥β>0, conditional routing to genuine upper witnesses in Top has denominator p_top U≥βU and row mass exactly one. Thus it conserves the ENTIRE restricted original cost. It does not merely route and pay an unnormalized p_top fraction.

At each fixed y, the incoming density relative to ρ_y(dw), supported in Top, is at most λL_ε/β. This follows directly from the fixed-y shifted-rank estimate, positively bounding q_uω≤λ. Integrating the true destination capacity gives

    G_{relative,p_top≥β}[g]≤(λ/q_-)(1+√n)L_ε∫g/β.

For β=1/2 and g=g_ex, the new fee is exactly C_hit,n W_ex, where

    C_hit,n=2(λ/q_-)(1+√n)[1+log(1/ε)].

This is a genuine positive original-traffic payment. The destination is an auxiliary representation of cost, not new original qualified traffic: no original mask is evaluated at w, and w need not lie in the old current physical prefix. The proof does not require those assertions. It also does not replace the full-f masses/q/J by fields built from g_ex.

The separate older A_good receiver-covering consequence has its stated full-W price; replacing that W by W_ex would not be justified there. For n≥4 its destinations are contained in Top_y on capture by the same-source halo inclusion. This alternative is not charged in addition to the sourcewise Top theorem. The main proof does not require that comparison or an advantageous population of destinations.

The new residual is the exact p_top<1/2 complement of the relative-high original traffic. Since m_w>M(y) is a ρ_y-null set and m_w=M(y)/K is included in Top, its lower-than-Top strict upper capture satisfies

    ρ_y{Km_u<m_w<M(y)/K}>U_y(Km_u)/2>εJ_b(y)/2.

The strict endpoints, current prefix and physical atoms are preserved. There is no proof that a hit branch must occur for every source/input. Repeating the routing would change the incoming multiplier and does not automatically preserve q_uω≤λ or the original clock/outside qualifications. No free iterative closure is claimed.

## 3. Ledger and reversible auxiliary kernel

The disjoint split G_rel=G_hit+G_rem is inserted only into the R346 residual slot. The inherited relative-low branch and the newly paid relative-high/top-hit branch are different original positive pieces, so their source fees legitimately add:

    B_H≤G_rem[g_ex]+(13/3)εX_q+C_{ε,n}W
                     +(D_top,n+C_hit,n)W_ex.

Neither the R342 cover, the R345 absolute-future fee, nor the A_good alternative is added again. The inherited entrance multiplies this slot by two. No additional X_q coefficient arises from the new payment. Under the supplied Λ=128/119, ε=119/3072, the receiver coefficient remains 13/36. Only if the historical CZ 1/256 is in the same authenticated X account is the combined total 841/2304, with 1463/2304 unallocated. Remaining room is not certification that other terms are paid or absorbable.

The auxiliary qdu kernel in geometry (16)–(18) has correct normalization and reference measure. With A_y=∫qρ_y, the identity ∫fA_y=X_q shows that the exceptional A_y=0 source set has zero posterior mass for qdu-almost every receiver. The stated identity extension on the null exceptional set is legitimate. Its symmetric joint measure proves invariance/reversibility for σ=qdu. The Dirichlet form is exactly ∫f A_y Var_{qρ_y/A_y}. The upper-tail probability conversion costs the stated q-normalization factor; no original Ω or physical-clock symmetry is inferred. This auxiliary structure adds no separate payment, square credit or absorption.

The ledger retains the unpaid G_rem joint source/mass/clock geometry; general soft/crossing/innovation and hard-contract complements; wide/extreme-scale/height/threshold slots; chronological initialization/deletion/future-deleted-source atoms; and outer/layer/source/limit aggregation. Negative suffix/square credit is used only once. This round does not establish the general n^(1/2+o(1)) bound or reduce the open work to constants/logarithms.

## 4. Code, actual evidence and limits

The primary reports fresh successful execution of all frozen scripts. This reviewer read the full scripts and parsed the saved numeric result, without repeating the full pipeline.

- Numeric: 12,014 exact rational/outward-rational-log comparisons; stages 544+1,336+6,295 and Top module 3,839. The saved JSON records these values and PASS. Log bounds use a positive atanh series with power-of-two reduction and an exact tail remainder; floating conversions are display only. Exact grouping preserves repeated atom columns, closed-window endpoints, strict survival and threshold equalities. Top conditioning retains the original row multiplier and independently checks kernel normalization and outgoing=incoming. These models are finite atomic measures, not actual receiver dx or historical cube fields.
- Geometry: 1,767 Fraction assertions and separately 2,304 ordinary 70-digit Decimal inequality diagnostics. The true positive-volume 1D fixture checks all capture/noncapture bounds over entire receiver intervals and actual q=1, original clock integration, routing mass and qdu balance. It uses diagnostic parameters and omits the original outside gate; it is not a nonempty original root-hard traffic certificate. Scalar rank examples remain separate from actual geometry.
- Core: the listed 80 measures, 960 Hardy cases, 3,840 restricted columns, atom/window and longer-string cases mix exact Fraction tail decisions with 80-digit Decimal logarithm comparisons and tolerance 1e-65. They must not be aggregated as an all-exact certificate count. The main's latest evidence paragraph makes this distinction correctly.

The independent pre-author scratch checks recorded in audit_pre are separate diagnostics, not new primary check totals. The analytic actual-du window and sourcewise routing proofs carry the general result; no finite tests establish its remaining global budget. No old optimizer or historical pipeline was rerun or newly certified here.

## 5. Frozen SHA256 bindings
- `/tmp/r347_main.md` — `42faa3932c4e16ec9d0355b34f79b104cc82ad0af8145a3d3c64b6b97f2115df`
- `/tmp/r347_ledger.md` — `86aec6e92a658fb7d45fcd5447313816d643ad843768938d3bf8e2219e6437b9`
- `/tmp/r347_core.md` — `d176f8b75bbfe4a28ed41ce942ad5e51b7dbd109a8a299a62e61b89fe36184a1`
- `/tmp/r347_geometry.md` — `ac4e9b38400df1591d4f77bd289d13b08dc106167e7a173cc5daa0cb04c5d509`
- `/tmp/r347_numeric.md` — `a5424845f6db17807e68be7ebf56c15d14f4ab64408e9360ed5d8c71b8d59fc5`
- `/tmp/r347_core_checks.py` — `e2dac47b2cfcf402a14f8c80c21ca6e1c4a3a676ff59bca820c0e17ff5f8af7c`
- `/tmp/r347_geometry_checks.py` — `97cf41bde6a01fa81d48d2af23b6e622b49afe98a5c467a8a7d188fafc3e9748`
- `/tmp/r347_numeric.py` — `d1559e4985f61d8fefec89ec74c3598a9199502e723e48d7cef30a01cc956ad0`
- `/tmp/r347_numeric_result.json` — `3604b5202d7831521d0e996454d6d8290b62d2ffda68e93ca0b65c0687fc91a1`
- `/tmp/r347_audit_pre.md` — `ec7843e9a1678b51d763a4ca558e37041389d263f2a335c1cf30095abd02e80c`
- `/tmp/r346_geometry.md` — `54c86eed5a889c94fc6568c455dd43ffd979894b82acf1c2b9772def18d26570`
- `/tmp/r346_core.md` — `6536c1eccf98ab90e7160022f3140e83f505d23010987421fa95cd1c54e604ed`
- `/tmp/r346_audit.md` — `6b10f559f2004d0962c4a59de4a1c1dab9a9130a52db0a7ac7fee3872b3f8e12`
- `/tmp/r344_geometry.md` — `d5b2f2d4468367dc53dbaf927e7cf1be57d1e7f31c777f87c51794a8b9c6b90a`
- `/tmp/r342_geometry.md` — `d8d62f1ad59e894ed936fdd64328e608a1b6b682190dbc3b45aed826571dd983`
- `/tmp/r340_core.md` — `f030035399e805bb1a6a5f369d9c499bbf1500f74de02b53471d58107bc3ee90`

The R346 contract, clipping/covering predecessors and original hard-traffic contract are bound as necessary inherited interfaces; this is not a fresh complete audit of their historical derivations. The preliminary file is preserved as the independent-before-author screen. This final receipt binds the current final bytes above.
