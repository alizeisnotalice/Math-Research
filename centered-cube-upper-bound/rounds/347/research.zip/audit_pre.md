# R347 independent pre-author screen

PASS for the proposed improved real receiver-column estimate and the later independently screened top-destination payment. No R347 author proof has been read. The column bound alone is auxiliary; the extension at the end proves a genuine new source-root payment for its explicitly restricted original branch. It adds no receiver absorption and does not close the general residual.

## Fixed field and true closed mass-band capacity

Keep the full hard field and all original gates: m_u=q_uR_u^n, q_-≤q_u≤λ, a≤R_u≤b, actual receiver measure du, dμ=du/m_u, ρ_y=c_u(y)dμ, J=J_b(y), K=exp(√n)>1. The notation q below means the fixed positive lower bound q_-, not a receiver-dependent replacement. E has finite volume and m≥q_-a^n, so every ρ_y is finite.

For each fixed y and t>0, the actual closed mass band satisfies

    ρ_y{t≤m_u≤Kt}≤B=(1+log K)/q_-.

Indeed set z=(2||u-y||∞)^n, the volume coordinate for centered receiver cubes. Capture and m≤Kt imply z≤Kt/q_-. On this band 1/m_u≤min(1/t,1/(q_-z)). Integrating the real du radial majorant gives

    ∫_0^{Kt/q_-}min(1/t,1/(q_-z))dz
       =1/q_-+log(K)/q_-.

The true a,b restriction and E can only reduce it. Closed mass endpoints cause no loss: they remain in the majorized density. The volume integration is over receiver centers, not source density or a measure of source annuli. No factor λ/q_- or 2^n is needed in this lemma.

## Strict tails and inclusive randomized ranks

Let U(t)=ρ_y{m>t}, V(t)=ρ_y{m≥t}. Then

    V(m)-U(Km)=ρ_y{m≤m_u≤Km}≤B.

On the active relative upper branch U(Km)>εJ, one has U(m)≥U(Km)>εJ. Thus the WHOLE rank interval [U(m),V(m)] for a mass atom lies inside (εJ,J]. In particular this is not a rule that discards the lower side of a large atom at the threshold.

Put φ(v)=1/max(εJ,v-B). The preceding band estimate gives

    1/U(Km)≤φ(V(m)).

The function φ is nonincreasing. For an atom of mass a_m=V(m)-U(m),

    a_m φ(V(m))≤∫_[U(m),V(m)]φ(v)dv.

For a general finite mass distribution the randomized descending rank U(m)+ξa_m, ξ uniform on [0,1], has Lebesgue law on [0,J]. On the nonatomic part the rank is U(m)=V(m). This is an integration device, not a new favorable actual receiver law or a source reallocation. It proves, also after any positive restriction such as m<m_w/K,

    F_y(w)=∫_{m_u<m_w/K, U(Km_u)>εJ}
                         ρ_y(du)/U(Km_u)
       ≤∫_(εJ,J] dv/max(εJ,v-B).

All zero-J rows are zero. No inverse is evaluated there.

## Integral and original high-past support

The original incoming density is zero unless the SAME source y has J_b(y)>h. Since h=(1+logK)/(εq_-)=B/ε, such a source satisfies b=B/J<ε. Rescale the last integral by J. If ε+b≥1, its value is (1-ε)/ε≤1 because ε>1/2 in this case. If ε+b<1, its exact value is

    b/ε+log((1-b)/ε)≤1+log(1/ε).

Consequently F_y(w)≤C_ε=1+log(1/ε) for all source rows where the original incoming flow can be nonzero. This proof also works at B=εJ, but the original gate supplies the strict inequality. Outside that support, one must retain the original zero contribution rather than apply the high-past hypothesis to an artificially enlarged kernel.

## Source-integrated column and its precise limitation

Use the exact R346 conservative one-step incoming density relative to actual dw:

    κ(w)=1/m_w ∫g(y)c_w(y)
         ∫_{m_u<m_w/K} q_u ω_y(u)
            1_{relative-high}ρ_y(du)/U_y(Km_u)dy,

where 0≤ω≤1 carries every original high-past/physical/other gate. For 0≤g≤f, apply the bound above only on its nonzero source support, then q_u≤λ. It follows that

    κ(w)≤λC_ε [∫Q_w g/m_w]≤λC_ε.

The bracket is the original captured source fraction, not a field computed from g. The previous O(√n) real-center column bound is therefore improved to a dimension-independent constant at fixed ε. The estimate is for the SOURCE-INTEGRATED density with respect to dw, not a pointwise-in-y qρ column bound for arbitrary incoming iterates.

Integrating gives only

    G=∫κ(w)dw≤λC_ε∫_E[∫Q_w g/m_w]dw
                  ≤(λ/q_-)C_ε X_q.

At the stated ε this is not a small absorbable receiver fee, and it is not a root source fee. The remaining iterate/terminal/source-inflow or negative-credit estimate is still required. No free iteration or multiplication/collapse of root-order terminal bills is justified. No new contribution is added to the R346 absorption ledger; its conditional 841/2304 total and other unpaid slots are unchanged by this auxiliary estimate.

## Actually executed diagnostics

A local Python Fraction run checked 9,595 nonvacuous atomic-rank ordering assertions on 1,919 active terms of finite scalar mass measures with masses 3^i (i=0,...,5), K=2, and varied positive atomic weights and ε. A separate 12 exact checks validated the two cases of the rescaled integral comparison; its initial four-mass active loop had no admissible B<εJ cases and contributes no nonvacuous traffic evidence. These are scalar diagnostics, not actual cube/history simulations and not a substitute for the analytic proof. No author or primary R347 pipeline has been read or rerun for this pre-screen.

## Necessary inherited bindings

- `/tmp/r346_geometry.md` — SHA256 `54c86eed5a889c94fc6568c455dd43ffd979894b82acf1c2b9772def18d26570`
- `/tmp/r346_core.md` — SHA256 `6536c1eccf98ab90e7160022f3140e83f505d23010987421fa95cd1c54e604ed`
- `/tmp/r346_audit.md` — SHA256 `6b10f559f2004d0962c4a59de4a1c1dab9a9130a52db0a7ac7fee3872b3f8e12`

## Independent extension screen: a genuine top-destination branch is paid

Before reading the forthcoming R347 author proof, independently audit the strengthened primary proposal as follows. Define the measurable actual capturing essential maximum M(y)=esssup_{ρ_y}m, with M=0 on J=0, and

    Top_y={w:M(y)/K≤m_w≤M(y)}.

For J>0, M∈[m0,m1]. The essential maximum is measurable through rational superlevels of ∫c_w(y)1_{m_w>t}dw; ρ_y and c_wdy receiver measures are equivalent on capture because m is bounded above/below. Values m_w≤M(y) hold ρ_y-almost everywhere, which is sufficient after Tonelli. The true closed-band estimate gives

    ρ_y(Top_y)≤B=(1+log K)/q_-.

For the original relative-high input put

    U_top(y,u)=ρ_y{w∈Top_y:m_w>Km_u},
    p_top(y,u)=U_top(y,u)/U_y(Km_u).

Denominators are positive on that input; elsewhere define the ratio as zero. Fix 0<β≤1 and restrict original input to p_top≥β. After the old physical clock and small endpoint have been integrated, its original cost measure is g(y)a_y(u)ρ_y(du)dy with 0≤a_y(u)=q_uω_y(u)≤λ. It remains zero unless the original source has J>h.

Route this restricted input by the SAME-source normalized probability

    1_{Top_y}(w)1_{m_w>Km_u}ρ_y(dw)/U_top(y,u).

It conserves exactly the restricted original cost, and uses U_top≥βU. Its incoming density relative to ρ_y at each fixed source is at most

    (λ/β)∫_{m_u<m_w/K, U_y(Km_u)>εJ}
                           ρ_y(du)/U_y(Km_u)
       ≤λL_ε/β,    L_ε=1+log(1/ε).

Thus the ENTIRE accepted input branch costs at most

    (λ/β)L_ε ρ_y(Top_y)≤(λ/q_-)(1+√n)L_ε/β

pointwise in y. Integrating the unchanged g=g_ex proves the new source-only root fee

    C_hit W_ex,    C_hit=2(λ/q_-)(1+√n)L_ε

at β=1/2. This is a genuine payment of a positive part of the original residual, not merely a dimension-free column diagnostic. Unlike the earlier source-integrated dw bound, it uses the independently proved fixed-y rank estimate and is therefore valid for this y-dependent destination set. No receiver absorption term is added.

The remaining exact branch has p_top<1/2 and U_y(Km_u)>εJ, hence its original upper tail OUTSIDE Top_y has mass >εJ/2. Original prefixes, current J, physical clocks, source g_ex and every original gate remain fixed. The routing is an auxiliary representation after clock integration; the destination is not asserted to be original qualified traffic or active at the old clock. Uppergood need not exist: when U_top=0 the accepted branch is simply empty.

This C_hit W_ex is added to the R346 source account, with its receiver coefficient unchanged at 13/36 (plus the same-account CZ conditional total 841/2304). It replaces any contemplated A_good-destination alternative, rather than being counted along with that alternative. For n≥4 the earlier R342 good receiver set is indeed contained in Top_y on capture: any other receiver capturing y has Q_v⊂Q_{3b}(w)⊂the old good halo, so M(y)≤halo mass≤Km_w. This is a compatibility observation, not needed for the top-window proof or an extra covering fee.

A fresh local Python Fraction run passed 642 scalar conditional-top routing assertions with 32 accepted input terms, including exact conservation, incoming density and total top-capacity comparisons. Logarithms were bounded above by a rational atanh-series remainder. These finite mass measures are mechanics diagnostics only, not actual cube/history fixtures or a primary run count. The proof of the source-root payment is the analytic estimate above. The remaining below-top future traffic is still unpaid.
