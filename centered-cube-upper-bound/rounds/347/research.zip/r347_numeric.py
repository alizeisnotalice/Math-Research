#!/usr/bin/env python3
"""Exact finite-atomic shifted-survival Hardy column checks (not actual cubes)."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json
BASE=Path(__file__).resolve().parent
C=Counter()
def ck(k,v):C[k]+=1;assert v,k
def logbounds(x,N=64):
 if x==1:return F(0),F(0)
 if x<1:
  a,b=logbounds(1/x,N);return -b,-a
 exponent=0
 while x>2:x/=2;exponent+=1
 t=(x-1)/(x+1);lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0));hi=lo+2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
 if exponent:
  a,b=logbounds(F(2),N);lo+=exponent*a;hi+=exponent*b
 return lo,hi

def fixtures():
 return [('initial','zero_measure',F(3,2),[(F(1),F(0))]),('initial','one_atom',F(1),[(F(1),F(3))]),('initial','small_unequal',F(3,2),[(F(1),F(1)),(F(3,2),F(1,2)),(F(2),F(3,2)),(F(4),F(1))]),('initial','separated32',F(3,2),[(F(2**i),F(1)) for i in range(32)]),('boundary_stress','repeated64_exact_K_edge',F(2),[(F(2**i),w) for i in range(64) for w in [F(1,3),F(2,3)]]),('boundary_stress','integral_branch_equality',F(1),[(F(1),F(1)),(F(3),F(3))]),('boundary_stress','heavy_atom',F(2),[(F(2**i),F(100) if i==8 else F(1)) for i in range(16)]),('boundary_stress','exact_K_ratios',F(3,2),[(F(3,2)**i,F(1)) for i in range(32)]),('expanded','separated128',F(3,2),[(F(2**i),F(1)) for i in range(128)]),('expanded','wide256',F(100),[(F(10**i),F(1)) for i in range(256)]),('expanded','unequal128',F(8),[(F(2**i),F(1+i%3,8)) for i in range(128)]+[(F(1),F(0)),(F(2**129),F(0))])]

def prepare(stage,name,K,atoms):
 before=sum(C.values());ck('positive_atom_locations_nonnegative_weights',K>=1 and all(m>0 and w>=0 for m,w in atoms));groups={}
 for m,w in atoms:
  if w:groups[m]=groups.get(m,F(0))+w
 masses=sorted(groups);J=sum(groups.values(),F(0));critical=sorted(set([m for m in masses]+[m/K for m in masses]));window=lambda t:sum((w for m,w in groups.items() if t<=m<=K*t),F(0));windows=[window(t) for t in critical];B=max(windows,default=F(0));witness=critical[windows.index(B)] if critical else None
 for t in critical:ck('closed_window_all_critical_endpoints',window(t)<=B)
 probes=[(a+b)/2 for a,b in zip(critical,critical[1:])]
 if critical:probes+=[critical[0]/2,critical[-1]*2]
 for t in probes:ck('closed_window_between_breakpoints',window(t)<=B)
 ck('closed_window_capacity_within_total',0<=B<=J)
 survival={m:sum((w for x,w in groups.items() if x>m),F(0)) for m in masses};inclusive={m:survival[m]+groups[m] for m in masses};future={m:sum((w for x,w in groups.items() if x>K*m),F(0)) for m in masses}
 for m in masses:
  ck('closed_window_rank_difference',inclusive[m]-future[m]==window(m)<=B)
  ck('strict_survival_and_inclusive_rank',inclusive[m]-survival[m]==groups[m])
 rows=[]
 for eps in [F(119,3072),F(1,8),F(1,4)]:
  if not J:
   ck('zero_measure_column_convention',B==0 and not masses);rows.append(dict(epsilon=str(eps),J='0',B='0',column='0',bound_lower='0',bound_upper='0',active_blocks=0));continue
  threshold=eps*J;active=[m for m in masses if future[m]>threshold];column=sum((groups[m]/future[m] for m in active),F(0));direct=sum((w/future[m] for m,w in atoms if w and future[m]>threshold),F(0));ck('repeated_atoms_preserved_column',column==direct)
  lower_riemann=F(0);blocks=[]
  for m in active:
   U=survival[m];V=inclusive[m];den=max(threshold,V-B)
   ck('active_rank_interval_inside_integration',threshold<U<V<=J)
   ck('shifted_survival_denominator_order',0<den<=future[m])
   ck('atom_column_below_rank_riemann',groups[m]/future[m]<=groups[m]/den)
   lower_riemann+=groups[m]/den;blocks.append(dict(m=str(m),weight=str(groups[m]),rank_U=str(U),rank_V=str(V),future_U_Km=str(future[m]),rank_endpoint_denominator=str(den)))
  ordered=sorted((survival[m],inclusive[m]) for m in active)
  ck('active_rank_blocks_disjoint',all(b<=c for (a,b),(c,d) in zip(ordered,ordered[1:])))
  if B<=(1-eps)*J:
   a,b=logbounds((J-B)/threshold);Ilo=B/threshold+a;Ihi=B/threshold+b;branch='constant_then_log'
  else:Ilo=Ihi=(1-eps)/eps;branch='all_constant'
  ck('column_below_full_hardy_integral',column<=Ilo<=Ihi)
  ck('riemann_blocks_below_full_hardy_integral',column<=lower_riemann<=Ilo)
  ck('active_threshold_equality_excluded',all(m not in active for m in masses if future[m]==threshold))
  small=B<=threshold;strength=None
  if small:
   a,b=logbounds(1/eps);strength=(1+a,1+b)
   ck('small_window_implies_log_bound',Ihi<=strength[0])
   ck('nonvacuous_small_window_has_active',bool(active))
  rows.append(dict(epsilon=str(eps),J=str(J),B=str(B),B_over_J=str(B/J),B_le_epsilonJ=small,active_blocks=len(active),at_strict_active_threshold=sum(future[m]==threshold for m in masses),column_exact=str(column),column_decimal=float(column),rank_riemann_exact=str(lower_riemann),bound_branch=branch,bound_lower=str(Ilo),bound_upper=str(Ihi),bound_decimal=float((Ilo+Ihi)/2),small_window_strength_lower=str(strength[0]) if strength else None,small_window_strength_upper=str(strength[1]) if strength else None,active_rank_blocks=blocks))
 return dict(stage=stage,name=name,K=str(K),atoms=[[str(m),str(w)] for m,w in atoms],input_atom_count=len(atoms),positive_mass_blocks=len(masses),J=str(J),B_exact=str(B),closed_window_witness=str(witness) if witness else None,rows=rows,exact_checks=sum(C.values())-before,scope='Abstract finite positive atomic measure only, not realized receiver cubes or actual du. Repeated locations are grouped only after preserving original atomic column.')

def top_joint_module(models):
 before=sum(C.values());records=[];beta=F(1,2)
 for model in models:
  atoms=[tuple(map(F,a)) for a in model['atoms']];groups={}
  for m,w in atoms:
   if w:groups[m]=groups.get(m,F(0))+w
  masses=sorted(groups);K=F(model['K']);B=F(model['B_exact']);J=sum(groups.values(),F(0));Top=[m for m in masses if m>=masses[-1]/K] if masses else [];topmass=sum((groups[m] for m in Top),F(0))
  ck('joint_Top_closed_window_capacity',topmass<=B)
  for row in model['rows']:
   eps=F(row['epsilon']);threshold=eps*J;Ilo=F(row['bound_lower']);Ihi=F(row['bound_upper']);active=[m for m in masses if sum((w for x,w in groups.items() if x>K*m),F(0))>threshold]
   for mode in ['one','nonuniform']:
    outgoing=F(0);incoming_density={m:F(0) for m in Top};accepted=[];fullcolumn=F(0)
    for index,m in enumerate(masses):
     future=sum((w for x,w in groups.items() if x>K*m),F(0))
     if m not in active:continue
     fullcolumn+=groups[m]/future;target=sum((groups[w] for w in Top if w>K*m),F(0));pTop=target/future;omega=F(1) if mode=='one' else F(1,2+index%3)
     ck('joint_original_row_multiplier_retained',0<omega<=1)
     if pTop<beta:continue
     ck('joint_conditioned_target_denominator',target>=beta*future>0)
     outgoing+=groups[m]*omega;accepted.append(dict(m=str(m),weight=str(groups[m]),future=str(future),Utop=str(target),pTop=str(pTop),omega=str(omega)))
     normalization=sum((groups[w]/target for w in Top if w>K*m),F(0));ck('joint_conditioned_kernel_mass_one',normalization==1)
     for w in Top:
      if w>K*m:incoming_density[w]+=groups[m]*omega/target
    incoming=sum((groups[w]*incoming_density[w] for w in Top),F(0));ck('joint_outgoing_equals_incoming',outgoing==incoming)
    for w,density in incoming_density.items():
     ck('joint_column_below_original_Hardy_over_beta',density<=fullcolumn/beta)
     ck('joint_column_certified_Hardy_integral',density<=Ilo/beta)
    ck('joint_Top_total_integral_budget',outgoing<=Ilo*topmass/beta<=Ilo*B/beta)
    small=row.get('B_le_epsilonJ',False)
    if small:
     Llo=F(row['small_window_strength_lower']);ck('joint_small_window_log_total_budget',outgoing<=Llo*B/beta)
     for density in incoming_density.values():ck('joint_small_window_log_column',density<=Llo/beta)
    records.append(dict(model=model['name'],epsilon=str(eps),omega_mode=mode,beta=str(beta),q='1',Top_masses=list(map(str,Top)),Top_measure=str(topmass),closed_window_B=str(B),accepted_rows=accepted,outgoing=str(outgoing),incoming=str(incoming),incoming_density_on_Top={str(w):str(d) for w,d in incoming_density.items()},Hardy_integral_lower=str(Ilo),Hardy_integral_upper=str(Ihi),Top_budget_certified_lower=str(Ilo*B/beta),small_window_log_bound_available=small,scope='Pure atomic conditioned transport with original active tail and multiplier; not actual cubes, highpast traffic, or physical clock.'))
 return dict(exact_checks=sum(C.values())-before,records=records)

def main():
 models=[];stages=[]
 for stage in ['initial','boundary_stress','expanded']:
  before=sum(C.values())
  for args in fixtures():
   if args[0]==stage:models.append(prepare(*args))
  stages.append(dict(name=stage,exact_checks=sum(C.values())-before))
 joint=top_joint_module(models)
 out=dict(joint_Top_module=joint,status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),stages=stages,models=models,scope='Finite atomic shifted-survival Hardy support only. Closed windows, strict future, inclusive rank and active thresholds retained. All comparisons exact rational/outward rational log bounds, no float certification; display decimals diagnostic. No global source funding or actual-cube/root realization claimed.')
 (BASE/'r347_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),stages=stages,joint_Top_checks=joint['exact_checks']),sort_keys=True))
if __name__=='__main__':main()
