#!/usr/bin/env python3
"""Exact two-axis positive-width strip geometry for the Bridge height band."""
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
from contextlib import redirect_stdout
from io import StringIO
import platform

ZERO, ONE = F(0), F(1)
LAMBDA = ONE
EXPANSION = F(33, 32)
LONG = (-F(2), F(2))
TRANSVERSE = ((-F(3, 8), -F(1, 4)), (F(1, 4), F(3, 8)))
STRIPS = (tuple((LONG, transverse) for transverse in TRANSVERSE),
          tuple((transverse, LONG) for transverse in TRANSVERSE))
DENSITY = F(4)
H_RECEIVERS = ((-F(1, 8), F(1, 8)), (-F(1, 16), F(1, 16)))
V_RECEIVERS = ((-F(1, 16), F(1, 16)), (-F(1, 8), F(1, 8)))
NARROW = (-F(1, 64), F(1, 64))
POS = (F(3, 32), F(1, 8))
NEG = (-F(1, 8), -F(3, 32))
CORES = {
    "A": ((POS, NARROW), F(1)),
    "B": ((NEG, NARROW), F(5, 4)),
    "C": ((NARROW, POS), F(3, 2)),
    "X": ((NARROW, NARROW), F(1)),
}
ANCHOR = ((F(1, 4), F(9, 32)),) * 2
PARTNER = ((-F(9, 32), -F(1, 4)),) * 2


def intersect(a, b):
    return tuple((max(lo, left), min(hi, right))
                 for (lo, hi), (left, right) in zip(a, b))


def area(rect):
    value = ONE
    for lo, hi in rect:
        value *= max(ZERO, hi - lo)
    return value


def inside(inner, outer):
    return all(lo <= left <= right <= hi
               for (left, right), (lo, hi) in zip(inner, outer))


def source_mass(rect, group=None):
    strips = STRIPS if group is None else (STRIPS[group],)
    return DENSITY * sum(area(intersect(rect, strip))
                         for directions in strips for strip in directions)


def square(center, length):
    return tuple((x - length / 2, x + length / 2) for x in center)


def all_centers_common_square(rect, length):
    return tuple((hi - length / 2, lo + length / 2) for lo, hi in rect)


def corners(rect):
    return tuple(product(*rect))


def abs_distance_bounds(a, b):
    return max(ZERO, a[0] - b[1], b[0] - a[1]), max(a[1] - b[0], b[1] - a[0])


def overlap_length(radius_a, radius_b, distance):
    return max(ZERO, min(2 * radius_a, 2 * radius_b, radius_a + radius_b - distance))


def ratio_bounds(left, right):
    centers_a, length_a = CORES[left]
    centers_b, length_b = CORES[right]
    radius_a = length_a / 2
    radius_b = length_b * EXPANSION / 2
    widths = []
    for axis_a, axis_b in zip(centers_a, centers_b):
        low_dist, high_dist = abs_distance_bounds(axis_a, axis_b)
        widths.append((overlap_length(radius_a, radius_b, high_dist),
                       overlap_length(radius_a, radius_b, low_dist)))
    # Every actual square on these cores contains both transverse
    # strip intervals in either coordinate. Their intersections do too.
    return tuple(sum(width[i] for width in widths) / (2 * length_a) for i in (0, 1))


def direct_ratio(left, right, center_a, center_b):
    length_a = CORES[left][1]
    length_b = CORES[right][1]
    a = square(center_a, length_a)
    b = square(center_b, length_b * EXPANSION)
    return source_mass(intersect(a, b)) / source_mass(a)


def dyadic_bin(length):
    volume = length**2
    return next(D for D in (1, 2, 4) if D <= volume < 2 * D)


def report():
    print("Replay: python -B strips842.py")
    print("Python:", platform.python_version())
    print("All assertions use fractions.Fraction; no random sampling.")
    total_width = sum(hi - lo for lo, hi in TRANSVERSE)
    total_mass = DENSITY * sum(area(box) for group in STRIPS for box in group)
    assert total_width == F(1, 4) and total_mass == 8
    assert 2 * DENSITY * total_width == 2 * LAMBDA
    print("Initial: four actual positive strips on [-2,2]^2, two per axis.")
    print("  Horizontal and vertical widths each add to 1/4; density 4 on each strip, additive at crossings.")
    print(f"  sigma total mass={total_mass}; any square of side l in [1,2] has sigma mass <= 2l, so M_[1,2] <= 2.")
    common = intersect(H_RECEIVERS, V_RECEIVERS)
    assert area(common) == F(1, 64)
    for rect, scales in ((H_RECEIVERS, (F(1), F(5, 4))), (V_RECEIVERS, (F(3, 2),))):
        for side in scales:
            common_square = all_centers_common_square(rect, side)
            for interval in TRANSVERSE:
                assert inside((interval, interval), common_square)
            for center in corners(rect):
                assert inside(square(center, side), (LONG, LONG))
                assert all(source_mass(square(center, side), o) == side for o in (0, 1))
            assert 2 / side > LAMBDA
    print(f"  Candidate H and V receiving rectangles overlap with area={area(common)}.")
    print("  On the overlap both nominations are strict true witnesses; each orientation has positive contribution.")
    print("  The chosen root selector gives X, in the shared rectangle, only one witness.")
    assert inside(CORES["A"][0], H_RECEIVERS)
    assert inside(CORES["B"][0], H_RECEIVERS)
    assert inside(CORES["C"][0], V_RECEIVERS)
    assert inside(CORES["X"][0], common)
    for first, second in combinations(CORES, 2):
        assert area(intersect(CORES[first][0], CORES[second][0])) == 0
    assert source_mass(ANCHOR) == source_mass(PARTNER) == F(1, 128)
    assert area(intersect(ANCHOR, PARTNER)) == 0
    print("  One common true anchor cell and one disjoint true partner cell each have mass=1/128.")

    print("Stress: directed coverage uses each covered square's own source mass.")
    expected = {
        ("A", "B"): (F(485, 512), F(501, 512)),
        ("B", "A"): (F(123, 160), F(127, 160)),
        ("A", "C"): (F(1), F(1)),
        ("C", "A"): (F(11, 16), F(11, 16)),
    }
    for (left, right), interval in expected.items():
        assert ratio_bounds(left, right) == interval
        assert all(interval[0] <= direct_ratio(left, right, a, b) <= interval[1]
                   for a, b in product(corners(CORES[left][0]), corners(CORES[right][0])))
        print(f"  {left} -> {right}^+ at dilation {EXPANSION}, bins "
              f"{dyadic_bin(CORES[left][1])}->{dyadic_bin(CORES[right][1])}: {interval[0]} <= ratio <= {interval[1]}")
    print("  Cross-bin A -> C^+ equals 1 even though C -> A^+ equals 11/16.")

    print("Extension on the same input: four disjoint receiver cores and both actual endpoint cells.")
    print("  eta=sigma; one witness length per core; tau core/G/H = |core| eta(G) eta(H)/(lambda*l^4).")
    total_core, total_flow = ZERO, ZERO
    for name, (rect, side) in CORES.items():
        common_square = all_centers_common_square(rect, side)
        assert inside(ANCHOR, common_square) and inside(PARTNER, common_square)
        for interval in TRANSVERSE:
            assert inside((interval, interval), common_square)
        assert all(inside(square(center, side * EXPANSION), (LONG, LONG))
                   for center in corners(rect))
        center_mass = 2 * side
        threshold = center_mass / side**2
        assert LAMBDA < threshold <= 2 * LAMBDA
        flow = area(rect) * source_mass(ANCHOR) * source_mass(PARTNER) / (LAMBDA * side**4)
        total_core += area(rect)
        total_flow += flow
        print(f"  {name}: l={side}, D={dyadic_bin(side)}, |core|={area(rect)}, "
              f"s_y={center_mass}, avg={threshold}, tau core/G/H={flow}")
    print(f"  Core area sum={total_core}; real ordered G/H arm mass sum={total_flow}.")
    for left, right in product(CORES, repeat=2):
        if left == right:
            continue
        lo, hi = ratio_bounds(left, right)
        for a, b in product(corners(CORES[left][0]), corners(CORES[right][0])):
            assert lo <= direct_ratio(left, right, a, b) <= hi
    print("  All 12 ordered core-pair ratio bounds checked by exact rectangle integrals at all corner pairs.")
    print("These are finite positive-density geometric diagnostics, without a high-dimensional or residual-history claim.")


def main():
    report_text = StringIO()
    with redirect_stdout(report_text):
        report()
    contents = report_text.getvalue()
    Path(__file__).with_suffix(".txt").write_text(contents, encoding="utf-8")
    print(contents, end="")


if __name__ == "__main__":
    main()
