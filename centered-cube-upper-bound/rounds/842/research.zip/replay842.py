"""Exact frozen endpoint reference and dilated witness geometry for R842."""
from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction as F
from itertools import combinations, product
from math import prod
import sys


PACKET_HALF = F(1, 4096)
CORE_HALF = F(1, 1024)
DELTAS = (F(0), F(1, 32), F(1, 16), F(1, 8), F(1, 2))


def show(a, b=None):
    b = a if b is None else b
    assert a <= b
    with localcontext() as c:
        c.prec = 15
        c.rounding = ROUND_FLOOR
        lo = Decimal(a.numerator)/Decimal(a.denominator)
        c.rounding = ROUND_CEILING
        hi = Decimal(b.numerator)/Decimal(b.denominator)
    return f"[{lo}, {hi}]"


def ceil(x):
    return -(-x//1)


def log_series(x):
    t = (x-1)/(x+1)
    assert 0 <= t <= F(1, 3)
    lo = 2*sum(t**(2*j+1)/(2*j+1) for j in range(24))
    return lo, lo+2*t**49/(49*(1-t*t))


LN2 = log_series(F(2))


def log_bounds(x):
    assert x >= 1
    k = x.numerator.bit_length()-x.denominator.bit_length()
    k -= x < F(2)**k
    assert F(2)**k <= x < F(2)**(k+1)
    a, b = log_series(x/(F(2)**k))
    return a+k*LN2[0], b+k*LN2[1]


def interval(center, half):
    return center-half, center+half


def intersection_length(a, b):
    return max(F(0), min(a[1], b[1])-max(a[0], b[0]))


@dataclass(frozen=True)
class Source:
    label: str
    at: F
    mass: F

    @property
    def support(self):
        return interval(self.at, PACKET_HALF)

    def on(self, box):
        return self.mass*intersection_length(box, self.support)/(2*PACKET_HALF)


@dataclass(frozen=True)
class Witness:
    center: F
    L: F

    @property
    def X(self):
        return interval(self.center, CORE_HALF)

    def mask(self, sources, delta=F(0)):
        lo, hi = self.X
        radius = self.L*(1+delta)/2
        chosen = set()
        for name, pkt in sources.items():
            a, b = pkt.support
            inside = hi-radius < a and b < lo+radius
            outside = b < lo-radius or hi+radius < a
            assert inside != outside
            if inside:
                chosen.add(name)
        return frozenset(chosen)


def actual_family():
    sources = {label: Source(label, pos, mass) for label, pos, mass in (
        ("a", F(0), F(1, 4)), ("b", F(-35, 64), F(7, 8)), ("c", F(35, 64), F(7, 8)),
        ("u", F(21, 32), F(1, 4)), ("v", F(-29, 32), F(1, 2)), ("e", F(33, 32), F(1, 4)))}
    assert all(not intersection_length(a.support, b.support) for a, b in combinations(sources.values(), 2))
    rows = (Witness(F(0), F(5, 4)), Witness(F(1, 64), F(7, 4)), Witness(F(-1, 64), F(2)))
    assert all(not intersection_length(a.X, b.X) for a, b in combinations(rows, 2))
    assert all(abs(a.center-b.center)+2*CORE_HALF+a.L/2 < b.L/2
               for a, b in combinations(rows, 2))
    masks = tuple(w.mask(sources) for w in rows)
    assert masks == tuple(map(frozenset, (("a", "b", "c"), ("a", "b", "c", "u"),
                                         ("a", "b", "c", "u", "v"))))
    masses = tuple(sum(sources[name].mass for name in mask) for mask in masks)
    assert masses == (F(2), F(9, 4), F(11, 4))
    assert all(r.L < m for r, m in zip(rows, masses, strict=True))
    extreme = max(abs(x) for w in rows for x in w.X)
    assert sources["u"].support[0] - extreme > F(5, 8)
    assert -sources["v"].support[1] - extreme > F(3, 4)
    assert sources["e"].support[0] - extreme > F(3, 4)
    assert sum(p.mass for p in sources.values()) == 3
    # Thus on all cores: for L<=5/4 mass <=2, in (5/4,3/2]
    # mass <=9/4, and for larger L the bound is 3. The height cap is 2.
    assert max(F(2), F(9, 4)/F(5, 4), F(3)/F(3, 2)) == 2
    caps = tuple(2*CORE_HALF*sources["b"].mass/r.L**2 for r in rows)
    print("Same actual f; centers, lengths, true witness masses, original conditional a-receipt caps:")
    print(" ", [(r.center, r.L, m, c) for r, m, c in zip(rows, masses, caps, strict=True)])
    print("  packets (position,mass), halfwidth", PACKET_HALF, [(s.at, s.mass) for s in sources.values()])
    print("  common positive a packet and b partner, disjoint positive cores, height 1<M_[1,2]<=2.")
    return sources, rows, masks, masses, caps


def sampling_test(sources, rows, masks, masses, caps):
    c = F(1, 4096)
    raw = tuple(tuple(c*x for x in j) for j in ((1, 1, F(7, 4)), (F(1, 4), 0, F(7, 4)), (0, 0, 1)))
    assert all(0 <= q <= cap for row in raw for q, cap in zip(row, caps, strict=True))
    assert all(all(y <= x for x, y in zip(a, b, strict=True)) for a, b in zip(raw, raw[1:]))
    r = tuple(sum(j) for j in raw)
    assert r == (F(15, 4)*c, 2*c, c)
    assert 2*c <= r[1] <= r[0] < 4*c and c <= r[2] < 2*c
    representative = (0, 0, 2)
    K = tuple(tuple(x/v for x in j) for j, v in zip(raw, r, strict=True))
    assert all(x <= 2*y for outside, idx in zip(K, representative, strict=True)
               for x, y in zip(outside, K[idx], strict=True))
    print("  nested true intensities r_j", r, "K_j on (small,mid,large) receiver core", K, "frozen", representative)
    P = []
    for law in K:
        P.append({name: sum(k*p.mass/m for k, mask, m in zip(law, masks, masses, strict=True)
                           if name in mask) for name, p in sources.items()})
    for profile, idx in zip(P, representative, strict=True):
        assert sum(profile.values()) == 1
        assert all(v <= 2*P[idx][name] for name, v in profile.items())
    print("  actual source laws P_j through common true kernel:", P)
    source_pool_check(sources, rows, masks, masses, raw[0], K[0], P[0])

    def test_ball(z, B):
        box = interval(z, B)
        return tuple(sum(profile[name]*pkt.on(box)/pkt.mass for name, pkt in sources.items())
                     for profile in P)

    hits = test_ball(sources["v"].at, F(1, 512))
    assert hits == (F(14, 165), F(7, 44), F(2, 11))
    half_hits = test_ball(sources["v"].at, PACKET_HALF/2)
    assert half_hits == tuple(h/2 for h in hits)
    assert test_ball(F(20), F(1)) == (0,)*3 and test_ball(F(0), F(3)) == (1,)*3
    print("  positive ball hits full/half packet:", hits, half_hits,
          "disjoint/containing ball probabilities 0/1 exactly")
    for current, alpha, probability in ((1, F(5, 16), hits), (1, F(5, 32), half_hits),
                                         (2, F(9, 25), hits)):
        base = representative[current]
        p, frozen = probability[current], probability[base]
        M = ceil(16/alpha)
        assert p > alpha/2 and frozen >= p/2 > alpha/4
        miss = (1-frozen)**M
        log_miss = tuple(M*x for x in log_bounds(1/(1-frozen)))
        assert log_miss[0] > 4
        print("   row", current, "alpha", alpha, "M", M, "current/frozen ball probability", (p, frozen),
              "exact hit enclosure", show(1-miss), "minus ln miss", show(*log_miss))
    M = ceil(16/F(9, 25))
    obsolete = tuple(M*x for x in log_bounds(1/(1-hits[0])))
    assert obsolete[1] < 4
    both = 1-((1-hits[0])*(1-hits[2]))**M
    print("  for late row using old-only reference, minus ln miss", show(*obsolete),
          "; two reference bins, samples", 2*M, "union menu hit enclosure", show(both))


def source_pool_check(sources, rows, masks, masses, raw, K, P):
    D = F(1)
    selected = tuple(i for i, witness in enumerate(rows) if D <= witness.L < 2*D)
    assert selected == (0, 1)
    r_a = sum(raw)
    r_aD = sum(raw[i] for i in selected)
    L_D = min(F(2), 2*D)
    assert L_D == 2
    # Q=[-1/2,1/2], so a+2*L_D*Q has radius L_D.
    a_lo, a_hi = sources["a"].support
    assert all(a_hi-L_D < p.support[0] < p.support[1] < a_lo+L_D
               for p in sources.values())
    Lambda = sum(p.mass for p in sources.values())
    assert Lambda == 3
    U, V = [], []
    for y in selected:
        raw_intersections = [sum(sources[p].mass for p in mask & masks[y]) for mask in masks]
        U.append(sum(k*overlap/masses[y] for k, overlap in zip(K, raw_intersections, strict=True)))
        V.append(sum(P[p] for p in masks[y]))
    assert U == [F(1), F(131, 135)] and V == [F(1252, 1485), F(151, 165)]
    alpha = max(U)
    integral = sum(D*raw[y]/masses[y] for y in selected)
    constraint_left = D*r_aD**2
    constraint_right = 2*alpha*r_a*Lambda
    assert integral == F(17, 73728) <= 2 and constraint_left <= constraint_right
    print("  solid source pool at volume band D", D, "with actual witnesses", selected,
          "L_D", L_D, "Lambda", Lambda, "r_a, r_aD", (r_a, r_aD))
    print("   directional U with own denominator:", U, "alpha_num", alpha,
          "reverse V=P_a(A_y):", V, "integral (lambda D/s_y) dmu_aD", integral)
    print("   lambda D r_aD^2 <= 2 alpha r_a Lambda:", constraint_left, "<=", constraint_right)


def receiving_length(a, w, ell, L, delta):
    assert 0 < ell <= L <= 2 and delta >= 0
    true = interval(a, ell/2)
    enlarged = interval(w, (1+delta)*ell/2)
    actual = intersection_length(true, enlarged)
    d = abs(a-w)
    full = L*min(F(1), max(F(0), 1+delta/2-d/L))
    assert actual == ell*min(F(1), max(F(0), 1+delta/2-d/ell))
    assert actual <= full
    return actual, full


def expansions(sources, rows, masks, masses):
    for delta in DELTAS:
        expanded = tuple(w.mask(sources, delta) for w in rows)
        assert all(a <= b for a, b in zip(masks, expanded, strict=True))
        private = tuple(sum((sources[s].mass for s in masks[i]-expanded[j]), F(0))/masses[i]
                        for i, j in ((1, 0), (2, 0), (2, 1)))
        missed = sum(p.mass for name, p in sources.items() if name not in expanded[2])
        for w, tags in zip(rows, expanded, strict=True):
            for j in tags:
                for a, b in product(sources["a"].support, sources[j].support):
                    actual, upper = receiving_length(a, b, w.L, F(2), delta)
                    assert actual >= 2*CORE_HALF and upper >= actual
        print("  dilation", delta, "private fractions target truth minus rival dilation; denominators fixed",
              private, "out-of-largest-expanded mass", missed)
    print("  first private tuple is undilated; ordered comparisons (mid|small,large|small,large|mid).")


def stress_receivers():
    for n, L, delta in ((1, F(1), F(1, 16)), (3, F(3, 2), F(1, 4)), (16, F(2), F(1, 2))):
        ell = L*F(3, 4)
        # Exact contained, overlap, tangency and disjoint cases (including at ell=L).
        for use in (ell, L):
            cut = (1+delta/2)*use
            values = tuple(receiving_length(F(0), d, use, L, delta) for d in
                           (F(0), delta*use/2, use/2, cut, cut+F(1, 4096)))
            assert values[0][0] == values[1][0] == use
            assert 0 < values[2][0] < use and values[3][0] == values[4][0] == 0
            branch = tuple(values[i % 3] for i in range(n))
            actual = prod(u for u, _ in branch)
            upper = prod(v for _, v in branch)
            assert 0 < actual <= upper
            print("geometric pressure dim", n, "L", L, "ell", use, "delta", delta,
                  "actual contain to disjoint lengths", tuple(x for x, _ in values),
                  "positive product actual/upper", show(actual/upper))
    print("  zero-length cases hold coordinatewise; a single disjoint axis gives no receivers.")


def main():
    print("Replay:", sys.executable, "-B replay842.py > numbers842.txt")
    print("Python", sys.version.split()[0], "exact Fraction; rigorous 24-term log tail.")
    sources, rows, masks, masses, caps = actual_family()
    sampling_test(sources, rows, masks, masses, caps)
    expansions(sources, rows, masks, masses)
    stress_receivers()
    print("Finite actual sources and witness pressure; no general historical claim.")
    print("PASS")


if __name__ == "__main__":
    main()
