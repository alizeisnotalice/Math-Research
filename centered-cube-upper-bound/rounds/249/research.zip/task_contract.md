# R249 task contract

Objective remains the arbitrary-positive-L1 centered-cube weak bound n^(1/2+o(1)). This round tests complementary genuine source-budget mechanisms, not an alternative definition of completion.

Allowed tools: R248 fixed-global-reference weighted Gram bound (all F factors retained), its actual hard/soft extracted-source comparison, original all-scale hard band M f<=4 lambda on actual receiver E, and the proved cube maximal L2 bound. No residual source inherits a density cap. Fixed extracted source submeasures and required coupled components must be preserved in any rerouting. A changed extraction requires rebuilding original residual/cut qualifications.

Deliverables and ownership:
- Astra peak: concentration_geometry.md, arbitrary-source low-cell smoothing plus concentrated entropy comparison, explicitly retaining unpaid aggregation and soft concentration.
- Sol compare: flow_budget.md, exact finite PSD tangent certificate and typed-profile capacity mechanism, with its actual Hall qualifications.
- Sol numeric: numeric_checks.py/json, numeric_notes.md and necessary MATLAB script/output; genuine finite grid instances, actual MATLAB solve and exact rational certificate checks in initial/pressure/expanded phases. Finite grids are not FULL instances.
- Sol audit: audit.md, statement-first independent checking of source/receiver qualifications, signs, constants and generality; then version-bound review.
- Main: proof.tex.txt, localized entropy numerical check, report and packaging. Main's added support-local entropy claim must be independently reviewed.

Success: an audited new estimate or checkable source-price mechanism, with actual numerical evidence affecting subsequent choices. General closure requires all original double-posterior traffic and every cost; none of these auxiliary interfaces alone certifies it. Preserve failures only insofar as they identify the next geometric obligation; do not duplicate historical counterexample searches.

Use B01 and L04 only within their finite weak-certificate / actual post-solve verification scope. Do not infer strong duality from solver status. No PDF compilation. Only final README and research.zip plus project overview are committed after review; one independent commit/push for this round.
