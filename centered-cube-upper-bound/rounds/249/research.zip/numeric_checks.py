#!/usr/bin/env python3
"""R249 MATLAB candidates, independent Fraction primal/weak-dual certificates."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product,combinations
from math import comb
import argparse,hashlib,json,subprocess,tempfile
import mpmath as mp

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dec(x):
    with mp.workdps(70): return mp.nstr(mp.mpf(x.numerator)/x.denominator,40)
def rounded(x): return F(round(float(x)*10**12),10**12)
def dot(a,b): return sum((x*y for x,y in zip(a,b)),F())
def menu():
    return [
      ('initial','binary_n2_k1',2,1,list(product(range(2),repeat=2)),[F(1,2)]*4,set(),'binary'),
      ('initial','binary_n3_k1',3,1,list(product(range(2),repeat=3)),[F(1)]*8,set(),'binary'),
      ('pressure','asymmetric_n2_r1',2,1,[(0,0),(1,0),(0,1)],[F(1),F(1,2),F(1,4)],set(),'full'),
      ('pressure','zero_row_n2_r2',2,2,[(0,0),(1,1),(2,0)],[F(1),F(0),F(3,4)],set(),'full'),
      ('pressure','concentrated_n2_r1',2,1,[(0,0)],[F(3)],set(),'full'),
      ('expanded','asymmetric_n3_r1',3,1,[(0,0,0),(1,0,0),(0,1,1)],[F(1),F(1,2),F(1,8)],set(),'full'),
      ('expanded','reference_n3_r2',3,2,[(0,0,0),(1,1,0),(0,1,1)],[F(1),F(3,4),F(1,4)],{0},'full'),
      ('expanded','concentrated_n3_r1',3,1,[(0,0,0),(1,0,0)],[F(2),F(2)],set(),'full')]

def geometry(spec):
    phase,name,n,r,sources,density,B,kind=spec; v=F(1,n**n); b=[x*v for x in density]; tau=F(1)
    pairs=[]
    if kind=='binary':
        targets=list(product(range(2),repeat=n))
        for i,s in enumerate(sources):
            for t in targets:
                I={j for j in range(n) if s[j]!=t[j]}
                if len(I)==r:pairs.append((i,t,I))
    else:
        for i,s in enumerate(sources):
            for count in range(r+1):
                for I in combinations(range(n),count):
                    for jumps in product([z for z in range(-n,n+1) if z],repeat=count):
                        t=list(s)
                        for j,z in zip(I,jumps):t[j]+=z
                        pairs.append((i,tuple(t),set(I)))
        targets=sorted({t for _,t,_ in pairs})
    target_index={t:j for j,t in enumerate(targets)}
    edges=[{'source':i,'target':target_index[t],'I':I,'F':(F(3)+F(2,n))**len(I)*(1+F(2,n))**(n-len(I))} for i,t,I in pairs]
    edges.sort(key=lambda e:(e['source'],e['target']))
    blocks=[[] for _ in targets]
    for j,e in enumerate(edges):blocks[e['target']].append(j)
    K=[{} for _ in edges];features=0; exact_kernel_checks=0
    for block in blocks:
        js={frozenset(J) for e in block for k in range(len(edges[e]['I']^B)+1) for J in combinations(sorted(edges[e]['I']^B),k)}
        features+=len(js)
        for e in block:
            for f in block:
                cross=(edges[e]['I']^B)&(edges[f]['I']^B)
                value=edges[e]['F']*edges[f]['F']*26**len(cross)/v
                expanded=edges[e]['F']*edges[f]['F']*sum((25**len(J) for J in js if J<=cross),F())/v
                assert value==expanded;exact_kernel_checks+=1
                K[e][f]=value
    A=[[int(e['source']==i) for e in edges] for i in range(len(sources))]
    C=[[int(e['target']==i) for e in edges] for i in range(len(targets))];d=[tau*v]*len(targets)
    if kind=='binary':f=[b[e['source']]/comb(n,r) for e in edges]
    elif max(density)<=tau:f=[b[e['source']] if sources[e['source']]==targets[e['target']] else F() for e in edges]
    else:
        f=[F() for _ in edges];remaining=d.copy()
        for i,supply in enumerate(b):
            left=supply
            for j,e in enumerate(edges):
                if e['source']!=i:continue
                take=min(left,remaining[e['target']]);f[j]=take;left-=take;remaining[e['target']]-=take
            assert left==0
    assert [sum((f[j] for j,e in enumerate(edges) if e['source']==i),F()) for i in range(len(sources))]==b
    assert all(sum((f[j] for j in block),F())<=d[i] for i,block in enumerate(blocks))
    return {'phase':phase,'name':name,'n':n,'r':r,'source_indices':sources,'target_indices':targets,'v':v,'b':b,'d':d,'B':B,'edges':edges,'blocks':blocks,'K':K,'A':A,'C':C,'f':f,'features':features,'kernel_checks':exact_kernel_checks,'kind':kind}

def multiply(g,h):return [sum((v*h[j] for j,v in row.items()),F()) for row in g['K']]
def energy(g,h):return dot(h,multiply(g,h))
def feature_energy(g,h):
    total=F()
    for block in g['blocks']:
        js={frozenset(J) for e in block for k in range(len(g['edges'][e]['I']^g['B'])+1) for J in combinations(sorted(g['edges'][e]['I']^g['B']),k)}
        for J in js:
            z=sum((g['edges'][e]['F']*h[e] for e in block if J<=g['edges'][e]['I']^g['B']),F())
            total+=25**len(J)*z*z/g['v']
    return total

def certificate(g,raw):
    vector=lambda v:v if isinstance(v,list) else [v]
    h=[rounded(x) for x in vector(raw['x'])];alpha=[rounded(x) for x in vector(raw['alpha'])];mu=[max(F(),rounded(x)) for x in vector(raw['mu'])]
    kh=multiply(g,h);grad=[2*x for x in kh]
    residual=[grad[j]-alpha[e['source']]+mu[e['target']] for j,e in enumerate(g['edges'])]
    repairs=[]
    for i in range(len(alpha)):
        repair=max(F(),-min(residual[j] for j,e in enumerate(g['edges']) if e['source']==i));repairs.append(repair);alpha[i]-=repair
    residual=[grad[j]-alpha[e['source']]+mu[e['target']] for j,e in enumerate(g['edges'])]
    assert all(x>=0 for x in residual) and all(x>=0 for x in mu)
    known=g['f'];f=known;mix=F()
    if g['kind']!='binary':
        row_sums=[sum((max(F(),h[j]) for j,e in enumerate(g['edges']) if e['source']==i),F()) for i in range(len(g['b']))]
        assert all(z>0 or not g['b'][i] for i,z in enumerate(row_sums))
        rowfixed=[max(F(),h[j])*g['b'][e['source']]/row_sums[e['source']] if g['b'][e['source']] else F() for j,e in enumerate(g['edges'])]
        degree=[sum(e['source']==i for e in g['edges']) for i in range(len(g['b']))]
        strict=[g['b'][e['source']]/degree[e['source']] for e in g['edges']]
        for i,block in enumerate(g['blocks']):
            col=sum((rowfixed[j] for j in block),F()); sc=sum((strict[j] for j in block),F()); assert sc<g['d'][i]
            if col>g['d'][i]: mix=max(mix,(col-g['d'][i])/(col-sc))
        f=[(1-mix)*x+mix*y for x,y in zip(rowfixed,strict)]
        assert all(x>=0 for x in f)
        assert [sum((f[j] for j,e in enumerate(g['edges']) if e['source']==i),F()) for i in range(len(g['b']))]==g['b']
        assert all(sum((f[j] for j in block),F())<=g['d'][i] for i,block in enumerate(g['blocks']))
    U=energy(g,f);L=dot(alpha,g['b'])-dot(mu,g['d'])-energy(g,h)
    z=[x-y for x,y in zip(f,h)];square=feature_energy(g,z);assert square==energy(g,z) and square>=0
    slack=[g['d'][i]-sum((f[j] for j in block),F()) for i,block in enumerate(g['blocks'])]
    rf=dot(residual,f);ms=dot(mu,slack);assert U-L==square+rf+ms and U>=L
    assert energy(g,h)==feature_energy(g,h) and U==feature_energy(g,f)
    result={'phase':g['phase'],'name':g['name'],'n':g['n'],'r':g['r'],'tau':'1','volume_exact':str(g['v']),'fixed_reference_B':sorted(g['B']),'source_indices':g['source_indices'],'target_indices':g['target_indices'],'source_rows_exact':[str(x) for x in g['b']],'target_caps_exact':[str(x) for x in g['d']],'graph_scope':('binary target cube truncation: outside binary reachable targets omitted; finite benchmark only' if g['kind']=='binary' else 'all integer-grid targets reachable from listed sources with <=r changed coordinates and each integer difference <=n, including identity'),'edges':[{'source':e['source'],'target':e['target'],'I':sorted(e['I']),'F_exact':str(e['F'])} for e in g['edges']],'known_original_primal_exact':[str(x) for x in known],'known_original_upper_exact':str(energy(g,known)),'known_original_upper_decimal':dec(energy(g,known)),'rational_primal_repair_mix_exact':str(mix),'primal_repair_scope':'nonbinary: clip rounded anchor, normalize exact source rows, mix with strict feasible uniform reachable-edge flow; binary: exact uniform flip plan','primal_feasible_exact':[str(x) for x in f],'anchor_rounded_exact':[str(x) for x in h],'alpha_repaired_exact':[str(x) for x in alpha],'mu_nonnegative_exact':[str(x) for x in mu],'source_alpha_repairs_exact':[str(x) for x in repairs],'residual_exact':[str(x) for x in residual],'lower_exact':str(L),'upper_exact':str(U),'gap_exact':str(U-L),'gap_terms_exact':{'feature_square':str(square),'residual_dot_primal':str(rf),'mu_dot_capacity_slack':str(ms)},'lower_decimal':dec(L),'upper_decimal':dec(U),'gap_over_upper':dec((U-L)/U) if U else '0','solver':{'exitflag':raw['exitflag'],'algorithm':raw['algorithm'],'objective_significant10':format(raw['objective'],'.10g')},'counts':{'edges':len(g['edges']),'sources':len(g['b']),'targets':len(g['d']),'feature_squares':g['features'],'kernel_feature_identity_pairs':g['kernel_checks']}}
    if g['kind']=='binary':
        gradient=[2*x for x in multiply(g,f)];assert len(set(gradient))==1
        exactalpha=[gradient[0]]*len(g['b']);exactL=dot(exactalpha,g['b'])-U;assert exactL==U
        G=sum((F(25**j*comb(g['r'],j)**2,comb(g['n'],j)) for j in range(g['r']+1)),F());b0=g['b'][0]/g['v'];FK=g['edges'][0]['F'];expected=FK**2*b0*G*sum(g['b'])
        assert U==expected
        result['symmetric_exact_optimality']={'gradient_exact':str(gradient[0]),'mu':'0','residual':'0','lower_exact':str(exactL),'upper_exact':str(U),'gap':'0','G_exact':str(G),'physical_factor_convention':'original worst F retained; not one-step improved determinant'}
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));ap.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md'));ap.add_argument('--matlab',default='/Applications/MATLAB_R2026a.app/bin/matlab');args=ap.parse_args()
    models=[geometry(c) for c in menu()];helper=Path(__file__).with_name('numeric_solver.m')
    inp={'cases':[{'name':g['name'],'K':[[float(row.get(j,F())) for j in range(len(g['edges']))] for row in g['K']],'A':g['A'],'C':g['C'],'b':[float(x) for x in g['b']],'d':[float(x) for x in g['d']]} for g in models]}
    with tempfile.TemporaryDirectory(prefix='r249_numeric_') as temp:
        ip,op=Path(temp)/'input.json',Path(temp)/'output.json';ip.write_text(json.dumps(inp))
        quote=lambda p:str(p).replace("'","''")
        code=f"addpath('{quote(helper.parent)}'); numeric_solver('{quote(ip)}','{quote(op)}');"
        subprocess.run([args.matlab,'-batch',code],check=True)
        raw=json.loads(op.read_text())
    rs=raw['results'];rs=[rs] if isinstance(rs,dict) else rs
    rows=[certificate(g,r) for g,r in zip(models,rs)]
    assert all(g['name']==r['name'] for g,r in zip(models,rs))
    toolbox=raw['optimization_toolbox']
    out={'scope':'Actual finite Lebesgue grid-cell plans with full physical determinants; solver outputs only candidates. Fraction verifies fixed source feasibility, feature PSD and repaired weak dual. No FULL, history qualification, general root budget or infinite graph conclusion.','source_sha256':sha(__file__),'matlab_source_sha256':sha(helper),'contract_sha256':sha(args.contract),'dependencies':{'python':'3.12.14','mpmath':mp.__version__,'MATLAB':raw['matlab_version'],'MATLAB_release':raw['release'],'Optimization_Toolbox':toolbox['Version']},'rounding':'anchors and multipliers nearest 1e-12; mu clamped >=0; per-source alpha lowered exactly to repair all residuals','cases':rows,'counts':{'cases':len(rows),'initial':2,'pressure':3,'expanded':3,'exact_primal_certificates':len(rows),'exact_weak_dual_certificates':len(rows),'exact_gap_decompositions':len(rows),'symmetric_zero_gap_certificates':2,'kernel_feature_identity_pairs':sum(r['counts']['kernel_feature_identity_pairs'] for r in rows),'edges':sum(r['counts']['edges'] for r in rows)}}
    args.output.write_text(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    for r in rows:print(r['name'],r['lower_decimal'],r['upper_decimal'],r['gap_over_upper'],flush=True)
    print(out['counts'])
if __name__=='__main__':main()
