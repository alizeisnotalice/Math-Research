# R249：真实有限grid flow QP与精确弱对偶证书

最终实际运行8例：初探2、压力3、扩大3。全部8例有独立Fraction原始可行上界、修复后弱对偶下界和完整非负gap恒等式。2个binary对称例另有解析构造的精确零gap证书。8例合计619条真实几何边、27个source rows、414个target cells、1105个kernel/feature pair恒等检查和1524个非负feature squares。有限图不是FULL实例，不认证原history、所有coupled分量或一般root预算。

## 方案、原几何与覆盖范围

先读flow_budget.md FB1–7，核对符号r=2Kh-A^T alpha+C^T mu、L=alpha.b-mu.d-hKh，然后设计两个binary基准和四个非对称整格图。父级指出density<=tau且identity可行的四图不涵盖必须运输的浓集来源，故在同一策略内补两个必要独立例，总8例。没有额外广域搜索。

源和target cells均是P_i=product_j[i_j/n,(i_j+1)/n)，真Lebesgue体积v=n^-n；源eta_i在该cell上常密度b_i/v，零row取零测度。每条edge真实label I={j:i_j!=l_j}，不是自由指定label。固定全局B，保原worst物理F_I=(3+2/n)^|I|(1+2/n)^(n-|I|)，没有用更小的one-step determinant替换。

初探binary n2/n3：sources和targets均为{0,1}^n，恰好flip一个坐标，source density分别1/2和1，target共享tau=1。这两个是明确截断的binary finite graph：省略binary cube外的可达整格targets，不能说保留了原图全部targets。

其余六图全部保留从声明sources可达的integer targets：changed coordinates<=r，每个integer coordinate difference<=n，并包含identity。除这些声明的edge条件外，没有额外隐藏耦合约束。具体范围：

|阶段/配置|n,r|source density|B|edges/targets|
|---|---|---|---|---:|
|初探binary_n2_k1|2,1|四源均1/2|空|8/4|
|初探binary_n3_k1|3,1|八源均1|空|24/8|
|压力asymmetric_n2_r1|2,1|1,1/2,1/4|空|27/18|
|压力zero_row_n2_r2|2,2|1,0,3/4|空|75/40|
|压力concentrated_n2_r1|2,1|单源3|空|9/9|
|扩大asymmetric_n3_r1|3,1|1,1/2,1/8|空|57/49|
|扩大reference_n3_r2|3,2|1,3/4,1/4|{0}|381/254|
|扩大concentrated_n3_r1|3,1|相邻双源均2|空|38/32|

全部坐标、edge labels、F、固定rows和target caps逐项在JSON。每edge按(f_e/b_i)eta_i(dy)1_Pl(u)du/v定义正Lebesgue plan，故每个source row不仅保总质量，还原样保留该声明source子测度。零row无须除以0。这里不声称这些人为声明的eta为原最大流/history所产生的提取。

## MATLAB候选与严格Fraction核验

实际用本机quadprog，H=2K/scale，scale=max(1,min diag K)，interior-point-convex，ConstraintTolerance/OptimalityTolerance均1e-12。所有8例exitflag=1。早期maxdiag缩放让B={0}例在缩放后的绝对容差下过早停止；正式版改用上述缩放。单source乘子被MATLAB JSON编码为scalar的读取问题也已修复。两个问题均不改变有限可行域。

MATLAB数值只给anchor h和multiplier候选；不能以exitflag或浮点objective声称证书。最终h、alpha、mu取最近1e-12有理数，mu截到非负；每个source统一降低alpha_i，直到其所有edges的r>=0。无须h可行、K可逆或QP强对偶。

原始已知有理flow：binary均匀flip；density<=1的其余图用identity；两个浓集图按source顺序及target容量精确贪心分配，断言每row完整运出。浓集单源b=3v和双源各b=2v均大于一个target容量v，不能用identity作为可行plan。

正式upper进一步由现QP anchor修复：先clip非负并逐source精确归一到b_i，再按需要与每source均匀分配其全部reachable edges的strict-feasible有理flow混合。该六图的strict flow每target严格低于v。用精确最大必要mix参数使所有caps成立。最终只有concentrated_n3_r1需要非零mix，参数19/158730158734；其余mix=0。始终保存原已知upper作对照。

K(e,e')=F_e F_e'26^|(I_e△B)∩(I_e'△B)|/v（同target）逐pair核等于J feature展开。对h、feasible f和f-h各自检查quadratic等于sum_J25^|J|/v*(sum_{e:J subset I_e△B}F_e x_e)^2。由这些精确有理平方直接保证PSD，不把浮点eig或quadprog接受Hessian当PSD证明。

最终精确核Af=b、Cf<=d、f>=0、mu>=0、r>=0，并核

upper-lower=(f-h)K(f-h)+r.f+mu.(d-Cf)。

三个右项独立非负并逐项保JSON。fixed source alpha修复量和完整r也保留，可单独重算。这里严格证书来自Fraction代数，mpmath只输出可读小数。

## 正式结果

|配置|精确lower的小数|精确upper的小数|gap/upper|
|---|---:|---:|---:|
|binary_n2_k1|215.999999995424|216|2.12e-11|
|binary_n3_k1|286.880387474809056884735|286.880387474809056884960|7.84e-22|
|asymmetric_n2_r1|4.96643496923953|4.96643496966482|8.56e-11|
|zero_row_n2_r2|5.86964205967489|5.86964216906026|1.86e-8|
|concentrated_n2_r1|211.999999999998|212|9.43e-15|
|asymmetric_n3_r1|0.890161271950775|0.890161272798937|9.53e-10|
|reference_n3_r2|0.935396902208170|0.935398484601150|1.69e-6|
|concentrated_n3_r1|14.9071110382760|14.9071110442418|4.00e-10|

两个binary例另用原有理均匀flow h=f，精确constant gradient作alpha、mu=0、r=0，得到真正lower=upper而非上表舍入后的小gap。uniform k-type的hypergeometric G和E=F_k² b0 G W也独立Fraction核验。

浓集单源baseline upper=1248，最终212；浓集双源baseline约399.58339684，最终14.90711104。固定B={0}例baseline identity上界约33.53941218，正式可行upper降至0.93539848，且精确gap由早期粗舍入版13%降至约1.69e-6。故改善是可行primal成本的真实有限模型改善，不能只引用dual下界代替支付。最终各图E/(tau W)仍约11至968；本数值不说明任意原来源都有低profile、一般维数阶或全部交通已付款。

## 版本、实际运行与完整迁移复现

本机MATLAB 26.1.0.3312084 (R2026a) Update 4，Optimization Toolbox 26.1；实际通过/Applications/MATLAB_R2026a.app/bin/matlab -batch运行。Python3.12.14用bundled executable；mpmath1.3.0来自vendor，仅用于展示Fraction小数，不需要numpy/scipy。

完成了初始6例、primal有理修复版、补浓集8例及正式1e-12舍入版的实际求解；未增大本轮最终8例菜单，未作额外timing replay。单source JSON读入失败那次未生成8例JSON，最终证据只计最终成功8例。根代理用独立实现的 reproduce.py 核验已保存的全部有理证书、原始基线和完整网格边，并在包外复算局部熵实验；不要求再次求解器输出逐字节一致。

在解压后的同一目录（numeric_checks.py、numeric_solver.m、task_contract.md齐全）运行：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 numeric_checks.py --contract task_contract.md --output replay.json --matlab /Applications/MATLAB_R2026a.app/bin/matlab
python3 reproduce.py --verify-only
```

重新求解可能产生不同浮点候选；replay.json 应按同一精确证书条件验收，不能把候选字节差异当作数学失败。脚本只向临时目录写MATLAB输入/输出，退出清理；不重置MATLAB路径，只加同目录helper。JSON不含临时路径/时间戳/runtime，绑定Python、MATLAB源码和合同SHA；CLI --output、--contract、--matlab均可迁移。默认输出相邻numeric_checks.json、合同相邻task_contract.md。完整anchors、dual与可行flow均保最终JSON，不需未归档的solver临时文件。

冻结Python SHA256：9d189506a463411bc4aad010c098ecba6055dc62f993c2305a4c6937936b211f；MATLAB源码SHA256：4ac56e50f72824560f0fcf7794e127fa93785a606857264036391718f633a647；JSON211636字节，SHA256：bdf8c7502cad4c72d7c1b2dbee06260865ca1935631a8c6d70cfbf00467ada47；合同SHA256：5eb0dfae9973c875392ccc64f693f8f240b809f53766d1d8f9d61f3ddb981ad9。
