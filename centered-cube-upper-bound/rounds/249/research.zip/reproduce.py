"""Independent exact replay of stored R249 flow certificates; no solver needed.

python3 reproduce.py --verify-only
python3 reproduce.py --output-dir /absolute/new/replay/directory
Actual MATLAB regeneration: python3 numeric_checks.py --output new.json
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations, product
import argparse, hashlib, json, shutil, subprocess, sys

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dot(x,y): return sum((a*b for a,b in zip(x,y)),F())

def check_case(c):
    n,r=c['n'],c['r']; B=set(c['fixed_reference_B']);v=F(c['volume_exact'])
    assert v==F(1,n**n)
    sources=[tuple(x) for x in c['source_indices']]
    targets=[tuple(x) for x in c['target_indices']]
    edges=c['edges']; b=list(map(F,c['source_rows_exact']));d=list(map(F,c['target_caps_exact']))
    assert len(b)==len(sources) and len(d)==len(targets)
    assert all(x==v for x in d)
    recorded=set(); blocks=[[] for _ in targets]
    for j,e in enumerate(edges):
        i,l=e['source'],e['target']; s,t=sources[i],targets[l]
        I={k for k in range(n) if s[k]!=t[k]}
        assert I==set(e['I']) and len(I)<=r and all(abs(x-y)<=n for x,y in zip(s,t))
        assert F(e['F_exact'])==(F(3)+F(2,n))**len(I)*(1+F(2,n))**(n-len(I))
        assert (i,l) not in recorded
        recorded.add((i,l));blocks[l].append(j)
    expected=set()
    if c['graph_scope'].startswith('all integer'):
        ti={t:j for j,t in enumerate(targets)}
        for i,s in enumerate(sources):
            for k in range(r+1):
                for I in combinations(range(n),k):
                    for jumps in product([q for q in range(-n,n+1) if q],repeat=k):
                        t=list(s)
                        for dim,q in zip(I,jumps):t[dim]+=q
                        assert tuple(t) in ti
                        expected.add((i,ti[tuple(t)]))
    else:
        assert set(targets)==set(product(range(2),repeat=n))
        expected={(i,l) for i,s in enumerate(sources) for l,t in enumerate(targets)
                  if sum(x!=y for x,y in zip(s,t))==r}
    assert expected==recorded
    f=list(map(F,c['primal_feasible_exact']));h=list(map(F,c['anchor_rounded_exact']))
    alpha=list(map(F,c['alpha_repaired_exact']));mu=list(map(F,c['mu_nonnegative_exact']))
    assert len(f)==len(h)==len(edges) and len(alpha)==len(b) and len(mu)==len(d)
    assert all(x>=0 for x in f+mu)
    assert [sum((f[j] for j,e in enumerate(edges) if e['source']==i),F()) for i in range(len(b))]==b
    slack=[d[l]-sum((f[j] for j in js),F()) for l,js in enumerate(blocks)]
    assert min(slack)>=0
    def mult(z):
        out=[F() for _ in edges]
        for js in blocks:
            for j in js:
                for k in js:
                    ej,ek=edges[j],edges[k]
                    overlap=(set(ej['I'])^B)&(set(ek['I'])^B)
                    out[j]+=F(ej['F_exact'])*F(ek['F_exact'])*26**len(overlap)*z[k]/v
        return out
    def feature(z):
        ans=F()
        for js in blocks:
            subsets=set()
            for j in js:
                typ=set(edges[j]['I'])^B
                subsets.update(frozenset(q) for k in range(len(typ)+1) for q in combinations(typ,k))
            for q in subsets:
                s=sum((F(edges[j]['F_exact'])*z[j] for j in js if q<=set(edges[j]['I'])^B),F())
                ans+=25**len(q)*s*s/v
        return ans
    kh=mult(h);res=[2*kh[j]-alpha[e['source']]+mu[e['target']] for j,e in enumerate(edges)]
    assert min(res)>=0 and res==list(map(F,c['residual_exact']))
    U=dot(f,mult(f));L=dot(alpha,b)-dot(mu,d)-dot(h,kh)
    known=list(map(F,c['known_original_primal_exact']))
    assert len(known)==len(edges) and min(known)>=0
    assert [sum((known[j] for j,e in enumerate(edges) if e['source']==i),F()) for i in range(len(b))]==b
    assert all(sum((known[j] for j in js),F())<=d[l] for l,js in enumerate(blocks))
    assert dot(known,mult(known))==F(c['known_original_upper_exact'])
    z=[x-y for x,y in zip(f,h)];sq=feature(z)
    assert U==feature(f) and dot(h,kh)==feature(h)
    assert U-L==sq+dot(res,f)+dot(mu,slack)>=0
    assert (U,L,U-L)==(F(c['upper_exact']),F(c['lower_exact']),F(c['gap_exact']))
    assert c['gap_terms_exact']=={'feature_square':str(sq),'residual_dot_primal':str(dot(res,f)),
                                'mu_dot_capacity_slack':str(dot(mu,slack))}
    if 'symmetric_exact_optimality' in c:
        g=[2*x for x in mult(f)];assert len(set(g))==1
        assert dot([g[0]]*len(b),b)-U==U
    return {'name':c['name'],'edges':len(edges),'exact_gap':str(U-L)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true')
    ap.add_argument('--output-dir',type=Path);args=ap.parse_args();root=Path(__file__).resolve().parent
    manifest=json.loads((root/'manifest.json').read_text())
    for name,digest in manifest['sha256'].items():assert sha(root/name)==digest,name
    data=json.loads((root/'numeric_checks.json').read_text())
    assert len(data['cases'])==8 and len({c['name'] for c in data['cases']})==8
    assert data['source_sha256']==sha(root/'numeric_checks.py')
    assert data['matlab_source_sha256']==sha(root/'numeric_solver.m')
    assert data['contract_sha256']==sha(root/'task_contract.md')
    result={'exact_certificates':[check_case(c) for c in data['cases']], 'manifest_files':len(manifest['sha256'])}
    if not args.verify_only:
        assert args.output_dir is not None,'specify --verify-only or --output-dir'
        out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
        shutil.copy2(root/'local_entropy_checks.py',out/'local_entropy_checks.py')
        subprocess.run([sys.executable,str(out/'local_entropy_checks.py')],check=True,capture_output=True)
        assert (out/'local_entropy_checks.json').read_bytes()==(root/'local_entropy_checks.json').read_bytes()
        result['local_entropy_json_byte_identical']=True
        (out/'receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    for name,digest in manifest['sha256'].items():assert sha(root/name)==digest,name
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__': main()
