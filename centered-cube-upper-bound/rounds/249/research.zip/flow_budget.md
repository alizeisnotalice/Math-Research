# R249: certified fixed-source flow cost and type-profile extraction

This file owns only this auxiliary route. It gives an algebraic
primal/dual certificate for the R248 finite Gram cost, and a constructive
typed-capacity mechanism that can upper-bound that cost. A small primal
cost pays an actual source extraction; a dual lower bound alone does
not pay it. The typed Hall condition is not asserted for every original
input. Its failure gives a typed residual cut, whose missing spatial
qualification is made explicit below.

## FB1. Exact finite data and preservation of the original sources

Use the finite original allowed edges e=(i,l), positive target volumes
v_l=|P_l|, and the TRUE coordinate type I_e of that edge. Fix one
reference B subset [n] for the entire estimate. Keep the physical
determinants F_I of R248 TC8, including any certified true displacement
improvement; do not set them to one. Define the block-diagonal matrix

    K_B(e,e')=1_{l(e)=l(e')} F_Ie F_Ie'
        26^{|(I_e triangle B) intersect (I_e' triangle B)|}/v_l.

For a flow f the cost is E_B(f)=f^T K_B f. The family is finite and
K_B is positive semidefinite: its feature indexed by target l and
coordinate subset A is

    v_l^-1/2 5^{|A|}F_Ie
          1_{l(e)=l}1_{A subset I_e triangle B}.

For rational data one can equivalently verify the sum of squares
with factor 1/v_l, without computing its square root.

Write all required original linear equalities as Af=b and all original
upper inequalities as Cf<=d; also f>=0. A includes the fixed source
piece rows and any fixed component/coupled subflows. C includes the
one shared target capacity sum_{e to l} f_e<=tau v_l and every extra
linear constraint actually needed for the original construction.
The original plan is the feasible witness; no omitted coupled
constraint is inferred from equal total flow value.

More explicitly, freeze the complete extracted submeasure eta_i on
each source piece, of mass b_i. For ordinary rows a feasible f defines
the positive plan on edge e=(i,l) by

    pi_e(dy,du)=(f_e/b_i)eta_i(dy)1_Pl(u)du/v_l.

Zero b_i rows are zero. Summing its source marginal returns eta_i
exactly. If the original coupled identity requires several source
components, freeze and index those components separately. This is
the pointwise source preservation needed to keep beta/nu, not merely
an equality of their total masses. Zero-volume target cells are removed.

## FB2. Weak certificate and an exact nonnegative gap

Take any anchor h in the edge space (it need not be feasible), let
g=2K_B h, and take alpha free and mu>=0. Suppose the finite residual

    r=g-A^T alpha+C^T mu>=0.

Then every original feasible f satisfies the certified lower bound

    E_B(f)>=L(alpha,mu,h)
       :=alpha.b-mu.d-h^T K_B h.                    (FB1)

In fact the complete identity is

    E_B(f)-L=(f-h)^T K_B(f-h)+r.f+mu.(d-Cf)>=0.      (FB2)

Proof: expand the quadratic at h, substitute
`g=A^T alpha-C^T mu+r`, and use Af=b. The three remaining terms are
nonnegative by the feature representation, f>=0, and Cf<=d.
No Slater condition, nonsingularity, QP strong duality, or existence
of multipliers is used. If a feasible anchor h also has
`r.h=0` and `mu.(d-Ch)=0`, its primal value equals L and is globally
minimal for this finite constrained model.

A certified feasible primal f gives an UPPER bound E_B(f) on the
optimal cost; FB1 gives a LOWER bound. A solver's small dual value
does not prove a cheap source flow. Conversely L>A tau W proves that
this particular fixed-source/constraint model cannot meet that budget;
it is not a FULL counterexample or a lower bound for the original
weak theorem. Any numerical primal/dual candidates must have their
constraints and gap checked exactly or by justified directed bounds.

## FB3. A constructive type-profile source-budget certificate

Fix nonnegative profile numbers p_I,l with sum_I p_I,l<=1. Add the
typed target capacities

    f_I,l:=sum_{e to l, I_e=I}f_e<=tau v_l p_I,l.      (FB3)

These imply the one original shared target cap. They do not grant
tau separately to every type. Put

    c_I,l=sum_J F_I F_J
       26^{|(I triangle B) intersect (J triangle B)|}p_J,l.

Every feasible original flow satisfying FB3 has the explicit cost

    E_B(f)<=tau sum_e c_Ie,l(e) f_e.                  (FB4)

Indeed s_I,l=f_I,l/v_l<=tau p_I,l. In the nonnegative target-cell
Gram, replace just its second density by this cap. Multiply by v_l
and sum. In particular, if the actual used edges have c_I,l<=A,

    E_B(f)<=A tau W, W=sum_i b_i.                     (FB5)

This is a finite, checkable source mechanism, rather than an assumed
unknown Gram norm. A profile can be selected from frozen input data,
but its feasibility must be established. If no such flow exists,
FB5 cannot be applied to the original fixed-source extraction.

More locally, one may assign pre-receiver source-piece prices a_i and
seek a flow using only original allowed edges with c_Ie,l(e)<=a_i.
If those fixed source rows can be routed, FB4 gives the actual
source-marginal budget `E_B<=tau sum_i a_i b_i`. The same typed Hall
test below applies to this reduced edge set. The numbers c_I,l are
explicit from the profile and true geometric types; no operator norm
is hidden in a_i. This still requires the certified cheap-edge routing
and, for an input-uniform theorem, a bound on the displayed source
mass sum. Deleting transport edges is a choice of artificial plan,
not deletion of original FULL traffic.

The authentic R248 costs then give, for epsilon>0,

    hard extracted traffic <=epsilon X
                     +C5^2 A tau W/(4epsilon lambda),
    actual soft subtraffic <=epsilon X
              +C_h^2 Csoft5(n)^2 A tau W/(4epsilon lambda), (FB6)

with C5=1+42log2, C_h=16/3 and
`Csoft5(n)=1+44log2+(1+46log2)(1+log n)`.
The second line is R112 J21--22's real hard-cap factor, squared.
All original running-maximum network shares, row-split and recovery
charges remain. Neither line is a direct bound on the current
double-posterior remainder.

## FB4. Exact typed Hall criterion and the partial-flow alternative

First suppose all needed component constraints are represented by
source/component rows and the original allowed edges. Form a finite
network with source nodes i and typed target nodes (I,l); edge i to
(I,l) exists precisely for its original allowed edge with that type.
Its source supply is b_i and typed target capacity is tau v_l p_I,l.
Writing N_type(S) for its typed neighbors, complete routing exists iff

    b(S)<=tau sum_{(I,l) in N_type(S)}v_l p_I,l
                                  for every source set S. (FB7)

Necessity is conservation. For sufficiency, maximize transported mass
on the compact flow polytope. A submaximal value W cannot have an
augmenting path, because its positive residual bottleneck would
increase the value. The residual reachable cut then has capacity
`W-b(S)+tau sum_N v_l p_I,l`. FB7 makes every such cut at least W,
a contradiction. This proves the finite criterion directly; no QP
strong-duality theorem is invoked.

If arbitrary additional coupled linear constraints remain, FB7 is
only the criterion for the relaxed typed network. They must still be
checked on the chosen flow. It is not a substitute for those original
constraints or for the full fixed-source feasible set in FB1.

For the typed network without those extra constraints the exact
maximum partial extraction is

    M=W-delta,
    delta=max_S [b(S)-tau sum_{N_type(S)}v_l p_I,l]_+. (FB8)

At a maximizing flow the residual reachable source set S carries all
unextracted source mass. Its typed neighbors are saturated, and no
positive flow from a source outside S enters those neighbors (its
reverse residual edge would make that source reachable). Hence

    extracted mass from S=tau sum_{N_type(S)}v_l p_I,l,
    residual mass on S=b(S)-that capacity=delta.       (FB9)

The partial flow defines eta_part,i=(row_i/b_i)eta_i and
eta_res,i=eta_i-eta_part,i, preserving these exact submeasures.
If FB7 fails in a fixed-source rerouting task, this partial flow is
NOT a feasible replacement for the original full extraction. It can
serve as a partial comparison/source mechanism, or as a proposal
for a new extraction construction. Any latter use must rebuild the
running maximum, residual beta/nu and all downstream cut/rank/row
qualifications. Equal maximum-flow value in a different network does
not avoid that reconstruction.

## FB5. The earliest missing spatial implication of a typed cut

Let N_plain(S) be the target cells geometrically neighboring S, with
the original true edge labels, and define its profile coverage

    pi_S(l)=sum_{I: (I,l) in N_type(S)}p_I,l.

The actual saturated quantity in FB9 is
`tau sum_l v_l pi_S(l)`, not `tau |N_plain(S)|`.
Thus a typed residual cut alone does not inherit the old uniform
target-density witness tau 1_N. A sufficient extra geometric fact is

    pi_S(l)>=kappa_S>0 on N_plain(S),

which would give the genuine volume estimate

    |N_plain(S)|<=b(S)/(tau kappa_S).                 (FB10)

Without such a fact, only the weighted-neighborhood sum is controlled.
For a uniform k-type profile, a cell seen by just one type from S
can have pi_S(l)=1/binom(n,k), even though it is a full geometric
neighbor. Neither ordinary target capacity nor original maxflow
feasibility makes this coverage one. This is exactly where a general
low-neighborhood/root payment still needs new original geometry;
the Hall obstruction is not automatically spatial concentration.

## FB6. Uniform-profile corollary with its exact geometric price

For B empty, all k-subsets, F_I=F_k and
p_I,l=1/binom(n,k), the linear price in FB4 is constant:

    c_I,l=F_k^2 G_nk,
    G_nk=sum_{j=0}^k25^j binom(k,j)^2/binom(n,j)
         <=(1+25k/n)^k<=exp(25k^2/n).                (FB11)

To prove the identity expand `26^{|I intersect J|}` over its subsets.
For a fixed j-subset of I, the fraction of k-subsets J containing it
is `(k)_j/(n)_j=binom(k,j)/binom(n,j)`. Moreover
`(k)_j/(n)_j<= (k/n)^j` term by term, proving both upper bounds.
For k=0 use the single empty type and G_n0=1.

Unlike exact equality of all target densities, FB3 only requires
each type density <=tau/binom(n,k). Targets may be partially filled.
Provided the original fixed-source typed flow is feasible, the real
budget is therefore E_B<=F_k^2 G_nk tau W. This is strictly conditional
on that feasibility/profile certificate, not a consequence of the
one shared target cap. The physical F_k^2, potentially of order 9^k,
still rules out inferring a macroscopic sqrt(n)-coordinate budget
merely from the favorable symbol bound in FB11.

## FB7. A genuine finite-grid primal/dual construction for checking

Take source and target cells indexed by {0,1}^n of equal volume v.
Allowed edges flip exactly k coordinates: l=i triangle I, |I|=k.
These are true neighboring grid cells, not freely assigned labels.
Fix identical source rows b_i=b0 v, 0<=b0<=tau, and put

    f_i,l=b0 v/binom(n,k) on every allowed edge.

Every row is b0 v. Every target receives one edge of each k-type,
each of mass b0 v/binom(n,k), so its shared cap and profile cap hold.
The source submeasure on each piece is preserved by the explicit
edge plan of FB1. Choose the genuine physical F_k; for one-grid-step
edges it may be `(1+4/n)^k(1+2/n)^{n-k}` by R248 TC8, or the original
larger determinant may be retained with its stated cost.

With B empty the exact objective and gradient are

    E=F_k^2 b0 G_nk W,
    (2K_B f)_e=2F_k^2 b0 G_nk on every edge.

Set every source multiplier alpha_i to that last constant and all
target multipliers mu_l=0. Then r=0 and FB2 has zero gap at this f:
`L=alpha.b-E=E`. This is an explicit globally optimal finite
primal/dual certificate, even if some target capacities are slack.
It is a check of the finite mechanism, not an assertion of FULL,
source-history gates, or a general macroscopic transport theorem.

## FB8. Skills and computation status

The explicitly invoked
[B01](/Users/zhengzhihao/.codex/skills/math-b01-lagrange-farkas/SKILL.md)
and [L04](/Users/zhengzhihao/.codex/skills/math-l04-mathematical-programming-workflow/SKILL.md)
skills are used only for their
finite weak-certificate and post-solve verification boundaries. The
proof of FB2 is given here directly. No infinite-dimensional or QP
strong-duality statement is imported, and no solver API is certified
by the skills. The local numerical author has received FB1--7 and
the exact certificate signs. Its separate assigned computation covers
finite grid primal/dual candidates, including the binary calibration
and asymmetric original allowed graphs. No execution result is asserted
in this analytic file before that independent record is delivered.
