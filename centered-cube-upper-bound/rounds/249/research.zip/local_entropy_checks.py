"""Finite counting-measure evidence for LG1; not continuous/FULL certification."""
from fractions import Fraction as Q
import hashlib, json, random
from pathlib import Path
import mpmath as mp

def check(rows, dps):
    mp.mp.dps = dps
    rows = [r for r in rows if any(r)]
    if not rows:
        return {'checks': 0, 'max_ratio': '0.0'}
    a = [max(Q(t)*sum(x >= t for x in r) for t in set(r) if t) for r in rows]
    support = [{j for j,x in enumerate(r) if x} for r in rows]
    neighbor = [[j for j in range(len(rows)) if support[i]&support[j]] for i in range(len(rows))]
    A = [sum((a[j] for j in ns), Q(0)) for ns in neighbor]
    conv = lambda q: mp.mpf(q.numerator)/q.denominator
    budget = sum(conv(ai)*(3+2*mp.log(2*conv(Ai/ai))) for ai,Ai in zip(a,A))
    sums = [sum(row[j] for row in rows) for j in range(len(rows[0]))]
    # >= at positive breakpoints is the limit of the strict superlevel bound.
    ratios = [mp.mpf(t)*sum(v>=t for v in sums)/budget for t in set(sums) if t]
    assert all(v<=1 for v in ratios)
    global_budget = sum(conv(ai)*(3+2*mp.log(2*conv(sum(a)/ai))) for ai in a)
    assert budget <= global_budget + mp.mpf(10)**(-dps+5)
    return {'checks':len(ratios), 'max_ratio':mp.nstr(max(ratios, default=0),30)}

def run():
    rng=random.Random(249)
    families=[[[1,0,0,0]],[[1,0,0,0],[0,1,0,0]],
       [[1,2,3,4],[4,3,2,1]],[[8,1,0,2],[1,7,2,0],[0,1,6,3]],
       [[2,2,2,2],[1,1,1,1],[0,0,0,0]],
       [[1,3,9,27,81],[81,27,9,3,1],[2,4,8,16,32]]]
    phases=[('initial',families[:2]),('pressure',families[2:])]
    expanded=[]
    for k in range(120):
        n=1+k%17; m=2+k%29
        expanded.append([[rng.randrange(1,200) if rng.random()<(.08+.8*(k%5)/4) else 0
                          for _ in range(m)] for _ in range(n)])
    phases.append(('expanded',expanded))
    output=[]
    for phase, cases in phases:
        vals=[]
        for case in cases:
            lo,hi=check(case,50),check(case,80)
            assert lo==hi, 'reported digits changed with precision'
            vals.append(hi)
        output.append({'phase':phase,'families':len(vals),'breakpoint_checks':sum(v['checks'] for v in vals),
                       'max_ratio':str(max(mp.mpf(v['max_ratio']) for v in vals))})
    # Equal, disjoint replicas: local entropy is identically zero, globally log K.
    replicas=[]
    for count in (1,2,8,64,1024):
        W=Q(count); local_entropy=Q(0)
        assert local_entropy==0
        replicas.append({'replicas':count,'local_entropy_per_mass':'0',
                         'global_entropy_per_mass':mp.nstr(mp.log(count),25)})
    return {'scope':'Finite support-function tests, ordinary multiprecision, not interval proof or FULL.',
            'mpmath_version':mp.__version__,'seed':249,'precisions':[50,80],
            'phases':output,'separated_replicas':replicas,
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}

if __name__=='__main__':
    result=run()
    out=Path(__file__).with_name('local_entropy_checks.json')
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))
