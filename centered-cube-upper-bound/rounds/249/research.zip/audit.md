# R249 独立审核

## 命题先行筛查（未读作者证明）

首次仅见两作者文件，尚无合同；先独立审主代理给定命题，不读取作者证明后倒填筛查。仅audit.md负责，共享目录不改他人、不Git/PDF/spawn。

### 1. 任意L1源的冻结piece平滑

取d=a/n网格C及m_C=η(C)，η≤f，阈值σ>0须先于receiver/尺度选择冻结。低组m_C≤σd^n用完整网格胞均匀化 barη_C=m_C1_C/d^n，哪怕原piece为C∩V也可在正上界中铺到完整C；低组总密度≤σ，总质量不变。对R≥a和同C任意两点，|y−u|∞≤d，所以

`h_R*η_low≤c^n h_{cR}*barη_low`，`c=1+2/n`。

由已授cube L2最大常数C2得∫E h_Rη_low≤c^n C2 sqrt(|E| σW_low)。分给低组ε/2·X的Young余价正为C2² c^{2n}σW_low/(2ελ)。真实source只是用正核majorant比较，并没有变更原η、ν或Π。若σ随x/后验重选则不属于这个固定平滑证明。

### 2. 高块weak-L1/entropy：条件性待核常数

单块还可先对其网格中心z_C作point-source几何上放：若x−y∈Q_R且y∈C，则x−z_C∈Q_{R+d}，R≥a给体积费≤(1+1/n)^n。因centered-point cube最大核有精确weak-L1 norm1，故单piece原局部scale最大响应有显式常数c1 m_C的弱帽；不能直接引用尚未授予的一般cube弱(1,1)或假定uniform cube另有同价弱帽。

从单块弱帽到多块entropy弱帽必须有完整非负求和证明及常数，不能普通L1三角。再结合原actual η_high≤f的hardband h_Rη_high≤4λ，可按一个receiver level截断：低level花εX，超level集合用entropy弱帽支付。作者所报8c1 L W/ε是否已分配低/高各ε/2，取决于entropy引理本身常数和level选择；此处先保留待稿核验，不凭名称认证8。

同一原plan的high源限制仍给合法target类型密度，故已认证的high Gram价和weak-entropy价可对同一个high交通取min。必须保完整FI、原分组时点及X误差份额，不能拿两个独立更换source的计划价格无价拼接。高thresholdσd^n>0使高块个数有限，L为质量熵型数据费，不自动由总mass给根阶；若无可付entropy/Gram结构，仍未闭合。soft路线不继承hard单piece中心point weak帽，必须另证其真实soft上放/容量及费用。

### 3. PSD弱对偶与typed profile

对有限PSD K，primal能量E=f^TKf、Af=b、Cf≤d、f≥0。可用显式g/y/μ≥0证书避免奇异K伪逆资格：若`2Kg≥A^Ty−C^Tμ`逐坐标，则

`E≥b^Ty−d^Tμ−g^TKg`。

依据是E≥2g^TKf−g^TKg及原线性约束；这是下界，不能据它证明付款上界。廉价费用须给可行primal或其上界。若采用Lagrange伪逆形式，另需linear coefficient在range K，否则不能写有限inf。

对同一actual target上非负profile帽s_I≤τπ_I（Σπ≤1），因Gram逐项非负有`E≤τ∫Σ_I (Kπ)_I s_I`，若行价≤A才得E≤AτW。更一般profile可分target piece使用，但所有profile/类型容量是额外明确约束，不是shared cap自动推出均匀/集中。

typed target-slot最大流的Hall割首先给typed邻域容量或饱和slot，不直接给物理目标并上的τ1_N或原残余source的几何浓集。投影忘记类型时可能丢价格/饱和度，不能追授原β/ν更强cut。重新优化仍须固定完整source提取子测度与coupled子流，不能只固定maxflow总值。

初筛状态：低piece平滑、条件取min与PSD方向通过；高entropy常数8及真实回代待作者正文核；一般root预算不认证。


## 新增LG1–3命题先行独筛（未读主证明）

固定非负weak-L1函数f_i，weak帽a_i，support相交的无向图包含self，A_i=Σ_{j∼i}a_j。对每x实际active集合J_x，所有active互为邻居，故A_i≥Σ_{j∈J_x}a_j，进而Σ_{i∈J_x}a_i/A_i≤1。用label静态阈值u a_i/(2A_i)作低段，总和≤u/2；big段f_i>u的并集费用Σa_i/u；中段积分≤a_i[1+log(2A_i/a_i)]，Markov给

`u |{Σf_i>u}|≤Σ_i a_i[3+2log2+2log(A_i/a_i)]`。

零a_i项先零，A_i≥a_i>0；不需要各support不交，但须图覆盖每个实际同时active对。Ai静态于receiver，不是逐x免费重算阈值。此局部熵命题通过。

对原有界尺度M(μ|C)，support包含完整Q_{b+d}(z_C)，故可用center距离∞≤b+d构造保守相交图。d=a/n、b≤2a给每点含self邻居数≤(4n+3)^n。若局部质量M_i=Σ邻居m_j，Jensen给 Σm_i log(M_i/m_i)≤W logDmax，因为Σ_i M_i≤Dmax W。故统一价最多O(n logn)W，非root。若多个source族间粗support完全分离，Ai只见自身邻居，没有远距复制的全局log份数罚；这是可证的局部化，不宣称原所有高块总有低degree。

原E截断仍须Mμ_c≤4λ，以u=ελ/2得到ε/2 X+8c1 Bloc/ε（Bloc为不含c1的质量加权局部熵和）。与低块ε/2相加或与同源Gram取min的误差份额须保留。等主证明后核。


## 作者稿与LG主证明稿后数学审核

task_contract.md现已完整读取，与已筛资格一致。concentration_geometry.md、flow_budget.md及主proof.tex.txt已全文审。严格状态：低块平滑、高块显式entropy/局部entropy弱和与同源Gram比较、有限PSD弱对偶及typed-profile条件付款通过；一般root预算未由此获得。

### 任意块内L1来源与费用常数

CG2证明只用source support在完整边d块内：Mζ>u给m>uR^n及center盒Q_{R+d}，超level体积正得c1m/u，c1=(1+1/n)^n；没有把任意密度换成原子或假授一般cube weak1。CG3去big并集、低段up_i/2和中段layercake，weak常数恰为Lc=3+2ln2+2Σπln(1/π)。取level ελ/2后原E上cap4λ给高组ε/2 X+8c1LcWc/ε，故所报8不是省略entropy引理常数。CG4低组另花ε/2 X，余价C2²c^{2n}σWd/(2ελ)，两份误差相加一次εX。

CG4允许真实piece为C∩V但分析平滑到完整C，正kernel majorant不改actual η或Π。cR octave、共享L2及thresholdσ冻结于source都正确。同一认证plan按high来源正限制后，target densities/共同cap仍保留，CG4高组的weak价与Gram价取min合法；多个network时须用真实组合L2价，不能逐网络免费重复半份εX。soft仅低组经共同正K_s,L可用，保c^{2n}及原Ch²；集中soft没有假声称同价support弱帽。η≤f的硬响应cap不偷换成soft全族cap。

### 局部支持图的真正改进与限制

LG1正文以A(x)=Σ_{x∈Si}ai作中间阈值，利用A(x)≤Ai使remaining terms被固定gi支配，方向正确。countable族用共同nullset及Tonelli/单调部分和，零weak常数先删；没有有限multiplicity假设。原compact-scale硬块support⊂Q_{b+d}，使用保守grid邻接而非source独立假设。LG2/3保4λ cap、半εX及8c1Bloc/ε，optional Gram必须同一certified source-restricted plan；没有为任意µ凭空造plan。Jensen与对称degree计数得D=(4n+3)^n，上界只O(nlogn)W；局部化确消除分离复制的global log数量罚，但不称局部熵一般root小。

local_entropy_checks.py已静审。126族/1554正breakpoints来自2+4+120固定菜单，support graph是同计数空间的实际support交，不是任意图。50/80比较只核报告30位字串一致，非精度包围。5个replica规模段为解析local_entropy=0的标量记录，直接赋零，未构建真实source盒几何；应按校准/记录而非额外实际几何验证理解。父级已获此范围提示。

### 有限流证书与typed residual

FB2的r=2Kh−Aᵀα+Cᵀµ≥0、µ≥0给精确gap E−L=(f−h)ᵀK(f−h)+r·f+µ·(d−Cf)，无Slater/可逆K/强对偶假设。已核lower与feasible primal upper角色，不接受solver status代替exact约束和gap。固定source component的edge plan source边缘确回原η_i，不只保mass；target体积因子1/v_l及FI均保留。

FB3/4的typed cap只替Gram第二个非负密度，得到τΣc_e f_e的真实线性价；便宜profile/cheap-edge routing是额外可行性证书。FB7 Hall当且仅当仅覆盖可表示为source/component rows及允许边的typed网络；任意额外coupled线性约束仍须核，稿中已明示relaxation。最大partial extraction的deficiency及residual reachable set、typed邻居饱和/无外流入关系正确。该partial flow若不足原提取，不是保持原β/ν的完整feasible替代，后续须重建。

FB5饱和的是τΣv_lπ_S(l)，不是τ|N_plain|；只有另证coverage下界κ_S才得空间体积帽。没有从Hall失败伪推出几何集中。uniform profile行价FB11的G及binary真格FB7常梯度零gap校准正确，FI可能用单步几何改进但保其完整determinant；原source/cut/FULL资格不由有限例生成。

### 本人实际小工具诊断

本轮本人另实际执行7项Fraction PSD gap检查：K=diag(1,4)，Af=f1+f2=1，f1≤3/4，h=(3/4,1/4)，α=2、µ=1/2，r=0，dual/primal值13/16。枚举f=(k/8,1−k/8),k=0,…,6，逐点exact核E−L=(f−h)ᵀK(f−h)+µ(3/4−f1)≥0，全部PASS。只是证书方向的有限代数诊断，不算FULL、真实flow或主正式QP运行。父级/数值作者的MATLAB/正式脚本执行结果须另按交付源码/JSON/receipt审，不冒称本人已运行。


## 新增互补机制的独立命题审核（先于主稿整合）

固定原µ≤f及实际hardband E，且被估计的原交通已合法正支配于∫E Mµ（原外常数另保）。对固定B/profile/允许边的任意有限typed partial flow z，row t_i≤b_i，定义µpart_i=(t_i/b_i)µ_i（b_i=0行零），µres=µ−µpart。总source仍精确原µ，actual后验/βν未改；正kernel次可加性给Mµ≤Mµpart+Mµres。

共享typed target cap使part的同一actual-target Gram≤τA(z)，A(z)=Σ_e c_e z_e，全部FI与target体积已在c_e。分配part εX/2得C5²τA(z)/(2ελ)；res的单块weak/支持图local熵不要求它先属高mass组，且µres≤f保hardband，分配res εX/2得8c1Bloc(µres)/ε。因此

`∫E Mµ≤εX+C5²τA(z)/(2ελ)+8c1Bloc(µres)/ε`。

此是对同一个原µ的真实互补费用，不需将partial计划伪作原算法新maxflow提取，也不向旧β/ν授新cut。它只用于已获得上述Mµ正松弛的量，当前完整Π余项若尚无该松弛仍不能使用。空flow合法但只退回全res熵价，空res则只剩transport价，零块按0log0约定处理。soft res缺同价弱型工具，不由本式覆盖。

固定finite数据可对可行z择优，因为每个feasible给同一左端upper；这不证明uniformroot预算。该联合目标含Bloc(res)，不能自动宣称仍是凸QP或把FB的PSDdual当作该非二次目标最优upper证书；严格上界用实际可行z的显式值即可。一般根阶仍须证明显示的共同目标可被控制，而不是另命名为已付矩。


## 主稿最终三项互补式与有限流LaTeX复核

proof.tex.txt最新完整稿已复读，含LG1–3、有限PSD/type-profile/Hall及CB1。有限流主整合的1/v_l、完整FI、固定source/coupled组件、lower/feasible-upper区别、额外coupled约束下Hall仅relaxedcriterion、typed覆盖κ才给物理volume，均与作者准确链一致。

CB1将原µ先低/高分组，high再按任意feasible partial z分为µp+µr，保持每piece内部原密度且三者总和仍µ。独立误差份额εd,εp,εr给low系数C2²c^{2n}σ/(4εdλ)、part系数C5²τA(z)/(4εpλ)、res系数4c1Bloc(µr)/εr；res取cutoff εrλ而非此前半ε版本，系数正确。三个receiver误差只加一次各自份额，不因同一E重复藏ε。

res不必继续超过初始σd^n，local weak工具本来对任意piece质量成立。声明只在原交通已经合法正支配于hard ∫E Mµ以后应用，无需将分析计划z安装成原maxflow算法；若改原算法仍须重建所有下游β/ν/cut。后验normalizer、runningmax、negative信用、actual selectors未改变，也不让当前未证的双Π量自动获得Mµ上界。目标含res日志非宣称凸QP或PSDdual已给它upper。数学整合通过，最终正式数字/报告待交付版本绑定。


## 最终数值、报告与复现静审

numeric_checks.py、numeric_solver.m、numeric_checks.json、numeric_notes.md最终已静审。真实cells为整数grid side1/n，vol=n^−n，label是实际不同坐标；两个binary图明确截断于{0,1}^n，另外六图枚举所有declared sources在≤r changed coordinates且每坐标差≤n的可达targets，含identity。单源3v与相邻双源各2v必须运输，避免仅用density≤τ的identity平凡可行例；不授FULL/history/一般coupled资格。8QP主体使用原source rows与共享target cap，uniform typed附加校准仅两个binary图；未把它们声称为CB1联合优化已经执行。

MATLAB实际H=(K+Kᵀ)/scale=2K/scale、α=−λ_eq·scale、µ=λ_ineq·scale符号准确。求解器只给anchor及乘子候选；rounded h可不feasible。µ截非负后，逐source降低α的exact修复使所有r≥0；没有以exitflag作数学证书。primal upper由clip h、exact source row归一与strict-feasible均匀reachable-edge flow的必要mix构造，后者在六图逐target严格低于cap；该全局mix保全部rows并修cap。upper不是直接取有约束误差的h。baseline feasible flow保留作对照。

K和J feature逐pair相等，正体积使PSD平方结构准确；对f、h、f−h分别核feature能量和FB2三个非负项。JSON保存全部anchors/feasible flows/乘子/r/约束及gap，足以不调用solver独立复核。两binary另有constant gradient exact零gap，舍入后的微小gap没有冒称精确optimal。浮点objective/说明小数只作展示。实际更低费用来自feasible primal，而不是dual lower；B={0}约1.69e−6认证相对间隙不外推维数阶。

本人未重启MATLAB或重跑正式8例。实际MATLAB执行属于数值作者；主代理已报告运行独立reproduce.check_case核8组原始/修复primal、全几何edges及exact gap，执行归属不冒称本人。本人本轮实际执行仅上文7项小Fraction dual-gap诊断。为可重放性，完整等价代码如下，不混入8QP正式证据：

```python
from fractions import Fraction as F
K=((F(1),F(0)),(F(0),F(4)))
h=(F(3,4),F(1,4)); alpha=F(2); mu=F(1,2); d=F(3,4)
def Q(x):
    return sum(x[i]*K[i][j]*x[j] for i in range(2) for j in range(2))
g=tuple(2*sum(K[i][j]*h[j] for j in range(2)) for i in range(2))
r=(g[0]-alpha+mu,g[1]-alpha)
assert r==(0,0)
L=alpha-mu*d-Q(h)
for k in range(7):
    f=(F(k,8),1-F(k,8))
    gap=Q(tuple(f[i]-h[i] for i in range(2)))+sum(r[i]*f[i] for i in range(2))+mu*(d-f[0])
    assert Q(f)-L==gap and gap>=0
assert L==F(13,16)
print('PASS 7')
```

读取原始JSON的8/619/1105/8 certificates/2 zero-gap计数与notes一致，源码/Matlab/合同内置SHA与实文件一致；三个Python脚本AST通过。local_entropy JSON也绑定当前源码，126族与1554断点实际为2+4+120、2+10+1542；其5个解析分离复制记录不当额外真实几何模拟。数字只检查已声明的有限机制，连续LG定理依据前述证明。

report最终正确记原μ的互补分析分解、soft集中未覆盖、local最坏nlogn、typed≠physical cut、QP lower/upper、未付Π余项及source算法不变的适用边界。reproduce.py独立从JSON重建网格允许边/全F/vol/K/feature/source/cap及gap，核原baseline和binary对称证书；它是stored-witness离线核验，不宣称重复MATLAB浮点JSON字节一致。包外只完整重算local_entropy JSON并字节比对，执行前后核manifest.sha256。正式receipt由主代理随后外置生成，不在本审核提前声称完成。要重新求解MATLAB候选，可另运行numeric_checks，仍须验其exact证书而非字节相等。

## 最终结论与版本冻结

**通过：CG任意L1块内平滑/显式熵费用、LG真实支持局部化、有限PSD/type-profile/Hall资格以及CB1同一source互补硬预算。** 它们给可检查的真实source价格和明确局部化改善；未证明显示的整体目标一般root小，未给集中soft同价弱界，也未支付当前完整双Π重尾补域。所有原λ、体积FI、网络/来源/receiver/旧负账费用仍保留。不存在把solver成功、lower证书或typed residual当一般闭合的认证。

| 文件 | SHA256 |
|---|---|
| task_contract.md | `5eb0dfae9973c875392ccc64f693f8f240b809f53766d1d8f9d61f3ddb981ad9` |
| proof.tex.txt | `11e2304a8043aea11fffc7b1d2310a4a7f7c130a551198d31224cd08aee6973d` |
| concentration_geometry.md | `1cb8943c6938c2a6c056a34bae3f4da5c859e948e05aa52613ab00dbd55d99cd` |
| flow_budget.md | `d615fcef4f8932b626da20e50979a585fedea51d8b147c338ef780a0f4bfa8dc` |
| numeric_checks.py | `9d189506a463411bc4aad010c098ecba6055dc62f993c2305a4c6937936b211f` |
| numeric_solver.m | `4ac56e50f72824560f0fcf7794e127fa93785a606857264036391718f633a647` |
| numeric_checks.json | `bdf8c7502cad4c72d7c1b2dbee06260865ca1935631a8c6d70cfbf00467ada47` |
| numeric_notes.md | `eece30ed4a0e449db6c93a81abd7eb0c4673c303f97d96f3fbbb3cdd0af8c6a3` |
| local_entropy_checks.py | `58735fc6cc160ce08d33314ff8fd78759eca09cbfdd0925d0e506792834bc3d7` |
| local_entropy_checks.json | `0a2e7ba56ad64154b50d4a3a42e3cb3cfc05fee77f64c46272d256d1cbdeb0f9` |
| report.md | `972cbfac5174ecc587f0f545dd4ff1b0cef5cad903cdbc4d0c456894f78a186f` |
| reproduce.py | `61931431b244240171520f90c6e53e6b8f7681380fb12b03c567a559255bc508` |

审核文件至此最终冻结，停止写入。未来manifest、包外回执与提交由主代理负责，不追认未执行结果。
