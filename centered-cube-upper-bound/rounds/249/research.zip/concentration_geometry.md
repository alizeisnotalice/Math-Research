# R249：任意来源的块内平滑与集中弱型账

本稿得到一个可替代 R248 体积平方价的**硬提取来源**比较，允许每个网格块内为任意非负 L1 密度。它不是点源外推，也不免费相加弱 L1 范数。分解覆盖任意来源，但集中部分的熵费用尚无一般根阶控制；原双后验余交通仍未付。

## CG1　命题及原资格

固定原 seed/leaf，记真实接收域为 \(E\)，\(X_E=\lambda|E|\)。只用原完整输入的 all-scale hard band
\[
 \sup_{a\le R\le b}h_R*f(x)\le4\lambda\quad(x\in E),
 \qquad 0<a\le b\le2a.
 \tag{1}
\]
来源 \(0\le\mu\le f\,dx\) 可取原已经认证的硬提取来源。这里不切掉原后验中的任何来源，也不对 \(\mu\) 重算 FIRST。令
\[
 M\mu(x)=\sup_{a\le R\le b}h_R*\mu(x).
\]
按原全空间网格的完整边长 \(d=a/n\) 立方体 \(C\) 记 \(m_C=\mu(C)\)。原真实 piece 若为 \(C\cap V\)，仍使用包含它的完整 \(C\) 作为下述分析用平滑盒。冻结任意 \(\sigma>0\)，定义
\[
 \mu_d=\sum_{m_C\le\sigma d^n}\mu|_C,
 \quad \mu_c=\sum_{m_C>\sigma d^n}\mu|_C,
 \quad W_d=\|\mu_d\|,\quad W_c=\|\mu_c\|.
\]
该分组只依来源，先于接收点和物理尺度。若 \(W_c>0\)，置
\[
 \pi_C=m_C/W_c\quad(C\text{ 属于集中组}),
 \quad L_c=3+2\log2+2\sum_C\pi_C\log(1/\pi_C).
 \tag{2}
\]
若 \(W_c=0\)，所有带 \(L_cW_c\) 的项约定为零；熵也允许为无穷。令 \(C_2\) 为已证 centered-cube maximal L2 常数，\(c=1+2/n\)、\(c_1=(1+1/n)^n\)。则对任意 \(\varepsilon>0\)，
\[
 \boxed{\int_E M\mu\,dx\le\varepsilon X_E+
 \frac{C_2^2c^{2n}\sigma}{2\varepsilon\lambda}W_d
 +\frac{8c_1L_c}{\varepsilon}W_c.}
 \tag{3}
\]
特别 \(c^{2n}\le e^4\)、\(c_1\le e\)。没有 \(F_I^2\)、来源个数或无价弱型求和隐藏在 (3) 中；真实分组费用就是 (2)。

若 \(\mu\) 属于 R248 TC1–TC9 的同一个认证计划，将该计划按来源 \(\mu_c\) 正限制，记其真实类型目标密度为 \(s_I^c\)，则共享帽仍成立。对于任一全局固定 reference \(H\)，(3) 的最后一项可替为
\[
 \min\left\{\frac{8c_1L_c}{\varepsilon}W_c,
       \frac{C_5^2\mathcal E_H(s^c)}{2\varepsilon\lambda}\right\},
 \qquad C_5=1+42\log2.
 \tag{4}
\]
\(\mathcal E_H\) 保 R248 全部真实 \(F_I F_J\) 和中心化类型交叠因子。取最小值是对同一来源响应的两个已证标量上界择一，不是改变来源或计划。

## CG2　任意单块密度的弱型界

设非零 \(\zeta\) 支撑于完整边长 \(d\) 的 \(C=Q_d(z_C)\)，质量 \(m\)。若 \(M\zeta(x)>u>0\)，则存在 \(R\in[a,b]\) 满足
\[
 m>uR^n\ge ua^n,
 \qquad x\in Q_{R+d}(z_C).
\]
故该超水平集包含于边长 \((m/u)^{1/n}+d\) 的中心盒，并有
\[
 u|\{M\zeta>u\}|\le
 m\left(1+d(u/m)^{1/n}\right)^n
 \le (1+d/a)^n m.
 \tag{5}
\]
若 \(m\le ua^n\)，超水平集为空。证明不要求块内密度上界，也不把来源换成块中心点质量。

## CG3　明确支付熵的弱型求和

一般地，设 \(f_i\ge0\) 且 \(u|\{f_i>u\}|\le a_i\)，\(A=\sum a_i>0\)，\(p_i=a_i/A\)。零 \(a_i\) 项可删。对固定 \(u\)，先去掉 \(\bigcup_i\{f_i>u\}\)，其测度至多 \(A/u\)。每项的低段 \(f_i\le up_i/2\) 总和至多 \(u/2\)。中段 \(g_i=f_i\mathbf1_{up_i/2<f_i\le u}\) 满足
\[
 \int g_i\le a_i\left(1+\log\frac2{p_i}\right),
\]
因为截断 layer cake 给下端质量项 \(a_i\) 加 \(\int_{up_i/2}^u a_i/t\,dt\)。因此
\[
 u\left|\left\{\sum_i f_i>u\right\}\right|
 \le A\left[3+2\log2+2\sum_i p_i\log(1/p_i)\right].
 \tag{6}
\]
可数族用单调极限；有限右侧时相应极限合法，否则仅保无穷上界。将 (5) 代入 (6)，并用 \(M\mu_c\le\sum_C M(\mu|_C)\)，得到
\[
 u|\{M\mu_c>u\}|\le c_1L_cW_c.
 \tag{7}
\]
在原 \(E\) 上 \(M\mu_c\le4\lambda\)。取 \(u=\varepsilon\lambda/2\)，直接按低、高响应分割真实接收积分：
\[
 \int_E M\mu_c\le\frac\varepsilon2X_E+
 4\lambda|\{M\mu_c>\varepsilon\lambda/2\}|
 \le\frac\varepsilon2X_E+\frac{8c_1L_c}{\varepsilon}W_c.
 \tag{8}
\]
这一步不假设各块接收支持互斥。熵正是没有无价相加弱型时保留的费用。

## CG4　小质量块的精确平滑

仅为分析定义
\[
 g=\sum_{m_C\le\sigma d^n}\frac{m_C}{d^n}\mathbf1_C,
 \qquad \|g\|_1=W_d,\quad\|g\|_2^2\le\sigma W_d.
\]
若 \(Q_R(x)\) 与 \(\mu|_C\) 的支撑相交，则完整 \(C\) 包含于 \(Q_{R+2d}(x)\subset Q_{cR}(x)\)。因而逐块且逐尺度有
\[
 h_R*\mu_d(x)\le c^n h_{cR}*g(x).
 \tag{9}
\]
\(g\) 不是新的实际来源；其可能越过 \(V\) 的部分只用于全空间正核上界。\([ca,cb]\) 仍为一 octave，所以已证 cube maximal L2 界及 Young 给
\[
 \int_E M\mu_d\le C_2c^n\sqrt{|E|\sigma W_d}
 \le\frac\varepsilon2X_E+
 \frac{C_2^2c^{2n}\sigma}{2\varepsilon\lambda}W_d.
 \tag{10}
\]
(8)+(10) 证明 (3)。对同一集中来源另用 R248 TC9，分配同一个 \(\varepsilon X_E/2\)，即得 (4)。

## CG5　原来源及组合费用

实际硬提取交通若已由原正松弛支配为 \(\int_Eh_{R(x)}*\mu\)，即可使用 (3)–(4)。原外乘系数、行分割系数仍原样相乘；本稿不把它们置一。固定 seed 的原叶接收域不交，故逐叶分配相同 \(\varepsilon X_{E_V}\) 后相加只有一次 \(\varepsilon X\)，各叶自己的 \(L_{c,V}\) 和质量仍须求和，再按原 seed 平均。

若提取由多个运行最大值增量网络组成，应先对最终的同一提取源 \(\mu\) 做本稿来源分组。熵和平滑比较直接作用于这个 \(\mu\)，不逐网络重新计它的质量。备选 Gram 则必须用实际组合的 L2 价；例如增量的界为 \(C_j\sqrt{\mathcal E_j}\) 时，可用 \((\sum_j C_j\sqrt{\mathcal E_j})^2\)，或原 R109/R112 已证更精确组合账。不能把每个网络的 TC9 都免费各领一次 \(\varepsilon X\)。

只对分散组，(9) 经同一个正卷积 \(K_{s,L}\) 仍给
\[
 P_{s,L}*\mu_d\le c^n K_{s,L}*h_{cL}*g.
\]
R248 TC6 的固定比例、共同 soft/scale L2 工具因此可用，把 (10) 的 \(C_2\) 换成 \(C_{\rm soft5}(n)\)。原 soft 提取交通另有 \(C_h=16/3\) 时，其平方系数相应为 \(C_h^2c^{2n}C_{\rm soft5}(n)^2\)。本稿没有对集中组声称 (5) 的全 soft 类比：软核无有限支撑，不能使用同一盒子超水平集论证。

## CG6　真正改善的范围与尚未支付之处

取 \(\sigma=\lambda\sqrt n\)，分散硬组的来源价至多
\[
 \frac{C_2^2e^4}{2\varepsilon}\sqrt n\,W_d;
\]
分散 soft 组相应为 \(O_\varepsilon(\sqrt n\log^2 n)W_d\)，保上述 \(C_h^2\)。这是任意块内密度的结论，未借来源 rank。

集中硬组可选 (8) 而不付 \(F_I^2\)。例如其来源块熵已具有 \(L_c\le A\sqrt n\operatorname{polylog}(n)\) 的实际证书时，(3) 给全硬提取源相应预算；不要求来源是点质量或只有一种运输标签。也可直接与原集中 Gram 比较择小。这里的条件不是普遍结论。

一般路线仍在以下具体处停止：以阈值 \(m_C>\sigma d^n\) 选出的高质量块，可以有许多块；这些下质量阈值不授予其归一化质量熵 \(\sum\pi_C\log(1/\pi_C)\) 的根阶上界。原 \(\nu\) 的 piece-rank 是另一种上质量条件，没有 \(\beta\) 的点态或块内密度资格，也没有此集中熵结论。若为去掉全局熵而再按空间邻接分组，就必须证明组间接收超水平集的重叠预算，不能再次免费弱型相加。这个共同接收重叠预算目前未得。

此外，集中 soft 组仍只能回到已经付费的 soft Gram 等原比较；硬核弱型证明不能移植。因此 (3) 是硬提取的可比较、条件改善费用，不是原 \(\beta,\nu,\Pi_t\) 双后验补域的总支付，也没有给旧残余来源更强 cut。R249 的一般根阶目标尚未完成。

## CG7　本机检查范围

实际运行 Python 标准库检查了六个有限非负函数族的 (6) 与五个维数 \(n=1,2,16,512,10000\) 下 \(n\log(1+1/n)\le1\)、\(2n\log(1+2/n)\le4\)，共 24 项通过。有限函数族（每个向量是计数测度上的一项函数）为

```
[[1,0,0,0]]
[[1,0,0,0],[0,1,0,0]]
[[1,2,3,4],[4,3,2,1]]
[[8,1,0,2],[1,7,2,0],[0,1,6,3]]
[[2,2,2,2],[1,1,1,1],[0,0,0,0]]
[[1,3,9,27,81],[81,27,9,3,1],[2,4,8,16,32]]
```

每项弱常数取 \(\max_{u\in\operatorname{range}(f)}u\#\{f\ge u\}\)，再在所有非零和函数值检验 (6)（零值也安全保留）。计算是普通浮点有限代数核查，不是区间证书、连续定理的替代或 FULL 实例。连续结论由 CG2–CG4 的证明给出。
