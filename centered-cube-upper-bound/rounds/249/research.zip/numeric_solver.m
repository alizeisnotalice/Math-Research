function numeric_solver(input_path, output_path)
% R249 numerical candidates only; Python checks rational primal/weak dual.
s = jsondecode(fileread(input_path));
opts = optimoptions('quadprog','Display','off','Algorithm','interior-point-convex', ...
    'ConstraintTolerance',1e-12,'OptimalityTolerance',1e-12,'MaxIterations',400);
results = cell(numel(s.cases),1);
for j=1:numel(s.cases)
    c=s.cases(j); K=double(c.K); scale=max(1,min(diag(K)));
    H=(K+K')/scale;
    [x,obj,flag,info,lambda] = quadprog(H,zeros(size(K,1),1), ...
        double(c.C),double(c.d(:)),double(c.A),double(c.b(:)), ...
        zeros(size(K,1),1),[],[],opts);
    assert(flag>0,'quadprog did not converge');
    results{j}=struct('name',c.name,'x',x,'alpha',-lambda.eqlin*scale, ...
        'mu',lambda.ineqlin*scale,'exitflag',flag,'iterations',info.iterations, ...
        'objective',obj*scale,'algorithm',info.algorithm);
end
out=struct('matlab_version',version,'release',version('-release'), ...
    'optimization_toolbox',ver('optim'),'results',{results});
fid=fopen(output_path,'w'); assert(fid>=0); cleanup=onCleanup(@()fclose(fid));
fwrite(fid,jsonencode(out),'char');
end
