"""R391 real interval posteriors, diagnostic joint-edge cascade.
Exact Fraction only; self-contained; edge measure is not native filtered traffic.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json
COUNT={'geometry_capacity':0,'joint_round':0,'conservation':0}
def ck(x,k):
 assert x,k
 COUNT[k]+=1

def geometry(N,h,eta):
 # Sources S_j=[j-h,j+h], mass1 each; E_i around i+.5, sideeta, R2.
 ck(0<h<F(1,4) and h+eta/2<F(1,2),'geometry_capacity')
 for i in range(N):
  L=F(i)+F(1,2)-eta/2;U=L+eta
  ck(U-1<=F(i)-h and L+1>=F(i+1)+h,'geometry_capacity')
  ck(F(i-1)+h<L-1 and F(i+2)-h>U+1,'geometry_capacity')
  ck(eta<1 and F(2)/2==1,'geometry_capacity')
 return F(1,2*h)

def makeedges(N,kind,eta):
 if kind in ['path','parallel_path']:base=[(i,i+1) for i in range(N-1)]
 elif kind=='cycle':base=[(i,i+1) for i in range(N-1)]+[(N-1,0)]
 elif kind=='star':base=[(0,i) for i in range(1,N)]
 else:raise ValueError(kind)
 deg=[0]*N
 for u,v in base:deg[u]+=1;deg[v]+=1
 g=eta/max(deg) # combined endpoint marginal<=qdu, q=1
 edges=[]
 for k,(u,v) in enumerate(base):
  if kind=='parallel_path':
   edges.extend([(2*k,u,v,g/2),(2*k+1,u,v,g/2)])
  else:edges.append((k,u,v,g))
 for i in range(N):ck(sum(e[3] for e in edges if i in e[1:3])<=eta,'geometry_capacity')
 return edges,g

def potential(D,s,clipratio):
 # Each source packet mass1, f=1/(2h), source length=1/f.
 return sum((min(x,s)+clipratio*max(F(0),x-s) for x in D),F(0))

def fields(N,edges,active,s,c):
 kept=[e for e in edges if e[1] in active and e[2] in active]
 deg=[F(0)]*N
 for _,u,v,g in kept:deg[u]+=g;deg[v]+=g
 D=[F(0)]*(N+1)
 for i in range(N):D[i]+=deg[i]/2;D[i+1]+=deg[i]/2
 e=[c if z>s else F(0) for z in D] # product indicator*(1-T/f)+
 p=[(e[i]+e[i+1])/2 for i in range(N)]
 return kept,D,e,p

def simulate(N,edges,s,c,theta,stale=False):
 active=set(range(N));seen=set();rounds=[];initial_cost=sum(e[3] for e in edges)
 original,D0,e0,p0=fields(N,edges,active,s,c)
 Phi0=potential(D0,s,1-c)
 while True:
  kept,D,e,p=fields(N,edges,active,s,c)
  if not kept:break
  ptest=p0 if stale else p
  weak={i for i in active if ptest[i]<=1-theta}
  dead=[ee for ee in kept if ee[1] in weak or ee[2] in weak]
  if not dead:break
  nextactive=active-weak
  nextkept,Dnext,enext,pnext=fields(N,edges,nextactive,s,c)
  deleted=sum((ee[3] for ee in dead),F(0));before=potential(D,s,1-c);after=potential(Dnext,s,1-c)
  # Diagnostic stale test is legal only at first step; never claim later theorem.
  if not stale:
   ck(all(z>=zz for z,zz in zip(D,Dnext)),'joint_round')
   ddirect=[F(0)]*(N+1)
   for _,u,v,g in dead:
    ddirect[u]+=g/2;ddirect[u+1]+=g/2
    ddirect[v]+=g/2;ddirect[v+1]+=g/2
   ck([z-zz for z,zz in zip(D,Dnext)]==ddirect,'joint_round')
   derivative=sum(((1-ee)*dz for ee,dz in zip(e,ddirect)),F(0))
   edge_derivative=sum((g*((1-p[u])+(1-p[v])) for _,u,v,g in dead),F(0))
   ck(derivative==edge_derivative and derivative>=theta*deleted,'joint_round')
   ck(before-after>=derivative,'joint_round')
   # Same edge with two weak endpoints is charged once, not once per endpoint.
   endpoint_count=sum((g*((u in weak)+(v in weak)) for _,u,v,g in dead),F(0))
   both=sum((g for _,u,v,g in dead if u in weak and v in weak),F(0))
   ck(endpoint_count-deleted==both,'joint_round')
   ck(not (seen & {ee[0] for ee in dead}),'conservation')
  seen.update(ee[0] for ee in dead)
  rounds.append({'round':len(rounds)+1,'weak_nodes':sorted(weak),'deleted_edge_ids':[ee[0] for ee in dead],
   'deleted_cost':str(deleted),'Phi_before':str(before),'Phi_after':str(after),
   'potential_drop':str(before-after),'actual_D_minmax':[str(min(D)),str(max(D))],
   'tested_weak_p_minmax':[str(min(ptest[i] for i in weak)),str(max(ptest[i] for i in weak))],
   'stale_used_potential_drop':'0' if stale else None})
  active=nextactive
 kept,D,e,p=fields(N,edges,active,s,c)
 remaining=sum((ee[3] for ee in kept),F(0));deletedtotal=sum((F(r['deleted_cost']) for r in rounds),F(0))
 ck(initial_cost==deletedtotal+remaining,'conservation')
 if not stale:
  drops=sum((F(r['potential_drop']) for r in rounds),F(0))
  ck(drops==Phi0-potential(D,s,1-c) and theta*deletedtotal<=drops,'conservation')
  ck(len(seen)+len(kept)==len(edges),'conservation')
 return {'nonempty_edge_rounds':len(rounds),'initial_edge_cost':str(initial_cost),'deleted_edge_cost':str(deletedtotal),
  'remaining_edge_cost':str(remaining),'initial_Phi':str(Phi0),'final_actual_Phi':str(potential(D,s,1-c)),
  'theta_times_deleted_cost':str(theta*deletedtotal),'source_potential_drop':str(Phi0-potential(D,s,1-c)),
  'actual_weak_nodes_at_halt':sum(p[i]<=1-theta for i in active),'rounds':rounds}

def case(name,N,kind,h,eta,sfactor,c,theta):
 f=geometry(N,h,eta);edges,g=makeedges(N,kind,eta);s=sfactor*g;T=(1-c)*f
 ck(0<=T<=f and 0<theta<1 and s>0,'geometry_capacity')
 dynamic=simulate(N,edges,s,c,theta)
 stale=simulate(N,edges,s,c,theta,True)
 # Native fixed R2 and mass2 makes original strict massfar empty; explicit.
 return {'name':name,'N_receivers':N,'source_packet_count':N+1,'source_halfwidth':str(h),'receiver_width':str(eta),
  'f_density_on_support':str(f),'W_full_f':str(N+1),'Xq':str(N*eta),'R':'2','m':'2','q':'1',
  'edge_kind':kind,'base_edge_mass':str(g),'s_diagnostic':str(s),'T_clip_diagnostic':str(T),'theta':str(theta),
  'native_massfar_nonempty':False,'dynamic':dynamic,'stale':stale}

def main():
 stage1=[case('single_edge',2,'path',F(1,10),F(1,5),F(7,4),F(9,10),F(1,2)),
         case('path8',8,'path',F(1,10),F(1,5),F(7,4),F(9,10),F(1,2))]
 stage2=[case('strict_threshold_'+str(sf),8,'path',F(1,20),F(1,5),sf,F(1),F(1,2)) for sf in [F(5,4),F(3,2),F(7,4),F(2)]]
 stage2 +=[case('clip_pressure',12,'path',F(1,10),F(1,10),F(7,4),F(3,4),F(1,2)),case('cycle8',8,'cycle',F(1,10),F(1,5),F(7,4),F(9,10),F(1,2))]
 stage3=[case('long_path32',32,'path',F(1,10),F(1,5),F(5,4),F(9,10),F(1,4)),
         case('long_path128',128,'path',F(1,10),F(1,5),F(7,4),F(9,10),F(1,2)),
         case('cycle32',32,'cycle',F(1,20),F(1,10),F(7,4),F(9,10),F(1,2)),
         case('star16',16,'star',F(1,10),F(1,5),F(7,4),F(9,10),F(1,2)),
         case('parallel_path',16,'parallel_path',F(1,10),F(1,5),F(7,4),F(9,10),F(1,2))]
 allcases=stage1+stage2+stage3
 ck(stage1[1]['dynamic']['nonempty_edge_rounds']>=2,'conservation')
 # Compress long detailed round lists but retain exact digest and perround totals.
 for c in allcases:
  for key in ['dynamic','stale']:
   rr=c[key]['rounds'];c[key]['round_detail_digest']=hashlib.sha256(json.dumps(rr,sort_keys=True).encode()).hexdigest()
   if c['N_receivers']>16:
    c[key]['rounds']=[{k:r[k] for k in ['round','deleted_cost','potential_drop','tested_weak_p_minmax']} for r in rr]
 result={'scope':'Actual positive L1 packet source and genuine positive-volume receiver intervals, actual hard R2/m2/q1 posteriors. Joint edge kernel deliberately selected on pair rectangles, combined endpoint marginal<=qdu, not the original filtered/far/history edge measure. All original masses are equal, so native strict massfar is empty. Small s/T/theta are diagnostic, not synchronized. No universal Lp constant is assumed; initial source potential is computed exactly.',
  'fraction_assertions':COUNT,'total_assertions':sum(COUNT.values()),'stages':{'initial':stage1,'threshold_pressure':stage2,'expanded_graph_source_overlap':stage3}}
 Path(__file__).with_suffix('.result.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',COUNT,'total',sum(COUNT.values()))
 for c in allcases:print(c['name'],'dynamic rounds',c['dynamic']['nonempty_edge_rounds'],'stale rounds',c['stale']['nonempty_edge_rounds'],'stale remaining',c['stale']['remaining_edge_cost'])
if __name__=='__main__':main()
