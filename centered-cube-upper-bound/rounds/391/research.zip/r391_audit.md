# R391 independent audit — FINAL PASS

Scope: only this file; no author/repository edits. The proposed joint-edge cascade was checked independently before reading a new R391 author proof. Final author proofs/scripts, numeric result/notes, sources/tools and main/ledger/readme have now been reviewed. PASS applies to the exact relative-cascade receipt and accounting below. This is a paid deletion branch with a changed remaining-core coefficient, not a full general source budget.

## 1. Original actual edge measure and incidence

Fix the entire original full-f field/marks/clock and actual R390 cold kernel. Let sigma=q_u du and gamma(du,dv)=sigma(du)K_cold(u,dv). This is the actual positive one-edge cost measure, not a newly resampled history law. Its row marginal is <=beta sigma and column marginal <=C_col sigma. Put S=beta+C_col>0 and G=gamma(E^2)<infinity. Zero total G is trivial.

For a measurable kept receiver set A, gamma_A=gamma restricted to A x A. Its two-end incidence i_A=out(gamma_A)+in(gamma_A) is dominated by S sigma. Define s_A=di_A/dsigma, 0<=s_A<=S. Then

    integral s_A qdu=2G_A,
    D_A(z)=integral gamma_A(du,dv)[c_u(z)/m_u+c_v(z)/m_v]
          =integral_E s_A(u)c_u(z)du/R_u^n=T_R^*s_A(z),
    integral f(z)D_A(z)dz=2G_A.

The factor TWO is genuine: each edge contributes both endpoint source posteriors. Nevertheless each deleted edge's cost is counted once. There is no assertion that the two source posteriors are independent, or that incidence is only one marginal. All densities use sigma=qdu, while the adjoint's function space uses Lebesgue du. Null-set versions cause no edge ambiguity because both gamma marginals are dominated by sigma.

## 2. Exact fourth-moment price from the known maximal interface

Use the already established dimension-free centered-cube L^(4/3) maximal bound C4, with actual selector fixed. T_R:L^(4/3)(dz)->L^(4/3)(du|E) has norm <=C4, so its adjoint has L^4 norm <=C4. Extend s_A by zero outside E. Thus

    integral D_A^4 dz<=C4^4 integral s_A^4 du
       <=C4^4 S^3 integral s_A du
       <=(2C4^4 S^3/q_-)G_A.

In particular the initial G rather than an unrelated X_q controls this fourth moment. This duality does not require f itself to belong to L^4; f only enters later matching/potential identities. The theorem uses the same known C4 as the prior literature contract, not a newly estimated numerical value. This audit does not re-prove that external maximal theorem.

## 3. Dynamic source test and single-cost deletion

For s,T>0, theta in(0,1), define at each stage

    e_A(z)=1_{D_A(z)>s}(1-T/f(z))_+,
    p_A(w)=integral e_A d pi_w,
    pi_w=f c_w dz/m_w.

Use e_A=0 on f=0, and harmless versions on the Lebesgue-null set of nonfinite f. Delete endpoints w in A with p_A(w)<=1-theta; retain A_next=A intersect{p_A>1-theta}. Do NOT delete those receivers from original matching/J/T or recompute gamma. Only the two-ended restriction gamma_A changes.

Every newly removed edge has at least one deleted endpoint and therefore at least theta posterior missing-source mass at that endpoint. For R=G_A-G_A_next,

    theta R <=integral f(z)(1-e_A(z))[D_A(z)-D_A_next(z)]dz.

This follows exactly by integrating the TWO endpoint posteriors of each removed edge. If both endpoints are deleted, the left edge cost remains R once; the right side may have two deficits and only increases. The identity integral f(D_A-D_next)=2R is preserved. No finite-generation arrival or predictable-history assumption is needed for this posthoc restriction of a fixed one-edge measure.

## 4. One common concave source potential and constants

Define for each source z

    Psi_z(d)=f(z)min(d,s)+min(f(z),T)(d-s)_+.

It is increasing and concave in d. For D_old>=D_new,

    f(1-e_old)(D_old-D_new)<=Psi(D_old)-Psi(D_new).

At D_old>s the left coefficient is min(f,T), no greater than all intervening potential slopes. At D_old<=s it equals f, giving equality. D_old=s is handled by the strict gate and the below-threshold slope; crossing the threshold has the correct inequality direction. f<T also causes no issue because both slopes are f.

Sum these positive deletions and telescope the SAME potential, rather than charging W every round. The initial value obeys

    integral Psi(D_0)
       <=sW+T integral D_0 1_{D_0>s}
       <=sW+(T/s^3)integral D_0^4
       <=sW+[2T C4^4 S^3/(q_-s^3)]G.

With T=rho theta q_- s^3/(2C4^4S^3), rho in(0,1), the total deletion satisfies

    G-G_core<=rho G+sW/theta,
    G<=[G_core+sW/theta]/(1-rho).

Hence rho=1/2,theta=1/4,s=1+sqrt(n) gives G<=2G_core+8(1+sqrt(n))W. This changes the unpaid core coefficient; it is not a uniform fixed fraction of actual traffic paid for every input and not a general root bound for G_core.

## 5. Infinite deletion and the precise surviving test

Finite gamma and decreasing A_j give gamma|A_j^2 down to gamma|A_infinity^2 and G_j down to G_core. D_j also decreases to the actual D_infinity computed from that edge core. It is finite, for example by bounded radii and finite E, and integral fD_0=2G makes the potential integrable. Monotone/dominated convergence makes the telescoping limit legitimate. Only countably many sigma-null modifications are used and gamma does not charge their endpoints.

For each surviving endpoint, all finite-stage p_j>1-theta. The decreasing limit is >=1-theta, NOT necessarily strict. The strict source gate also closes at the limit: D_j>s can tend to D_infinity=s while remaining true at every finite stage. The valid final statement is

    integral pi_w(dz)1_{D_infinity(z)>=s}(1-T/f(z))_+
       >=1-theta

for sigma-a.e surviving w. One may not assert D_infinity>s, strict posterior >, or a strict fixed point for the original weak-deletion rule. Any ensuing density concentration consequence must retain these nonstrict boundary conventions. Original q/f/m/J/clock/history fields remain frozen; D_infinity is a new incidence occupancy, not the old J.

## 6. Ledger and exact limitation

If the entering bound is BH<=G+E_old X_q+S_old W, the update is

    BH<=2G_core+E_old X_q+[S_old+8(1+sqrt(n))]W

for the displayed parameters. Only the G slot is rearranged by 1/(1-rho). Old X/source coefficients are NOT all multiplied by two. In the original entrance this becomes 4G_core and an added 16(1+sqrt(n))W before multiplication by Lambda. There is no new X coefficient, target-cap/template/h change, old-square subtraction or free repeated witness credit.

The core is an exact positive restriction of the old actual one-edge measure. It does not inherit new outgoing/next-history eligibility or define a conservative multi-step original process. Its new self-supporting occupancy remains generally unbudgeted. All original H-entry, soft/crossing/entry, source/history/scale aggregation and limit obligations remain; the external C4 constant is not an explicit numeric threshold unless a verified value is supplied.

## 7. Bounded reviewer mathematical-tool evidence

Reviewer actually ran 166 standard-library Fraction finite joint-edge potential checks. They verify that removed edges are counted once while both endpoint source incidences enter Delta D, the potential crossing direction, telescoping, and the exact factor-two incidence identity. These are bounded finite-incidence diagnostics, not native cube/history realizations or a proof of the external maximal theorem. They are separate from any future author/parent counts; no author pipeline was repeated.

PASS for the stated joint-cascade payment, constants and infinite-limit conventions. Final author and integrated reviews follow.


## 8. Author joint-cascade proof and check script: reviewed

Read r391_geometry.md and r391_geometry_check.py completely after the independent screen. The actual incidence definition, exact decrement for ALL removed crossing edges, count-once cost, concave potential inequality and factor-two fourth-moment price agree with Sections 1--4. The proof retains terminal potential in its exact telescoping identity and uses it only once. The original gamma, pi, masses, ranks, physical clock and history marks remain frozen; deleting a receiver from A is not deletion from matching or an original history event.

The infinite limit correctly has a closed occupancy gate and non-strict posterior bound, and its concentration consequence is at least half mass at {D_core>=s,f>2T} for theta=1/4. It does not falsely infer strict fixed-point or endpoint-transition qualification. The price G<=2G_core+8sW is a RELATIVE cascade absorption: it does not separately prove that the deleted part alone is bounded by 8sW, nor that any fixed fraction of all inputs is removed. The coefficient two of the exact unpaid core is indispensable.

The 2012 Fraction checks distinguish actual interval/source incidences with receiver quadrature from the original exponential-far flow. Their equal-mass directed diagnostic edges do not realize the strict-far gate, and the text expressly says so. The moment check in a diagnostic uses its explicitly supplied finite bound, not an invented numeric value of the universal C_*. Positive later-round, crossing-deletion and nonzero-core cases are tracked honestly. No whole author pipeline was repeated.

## 9. Auxiliary rank-deletion premium: reviewed, no payment booked

Independently checked and then read r391_aux.md and its entire check script. The atom-averaged w_A is a DISTINCT observable from R388's right-CDF witness. Generalized inverse rank gives integral_A w_A rho=Phi(J_A) exactly. After B subset A,

    integral_(A outside B) w_A rho
      =Phi(J_A)-Phi(J_B)+integral_B(w_B-w_A)rho,

and the last restoration premium is nonnegative. The pair formula correctly uses coefficient one on removed masses strictly below a surviving mass and coefficient t for equal-mass ties; partial atom deletion is not discarded. Differentiation and positive Tonelli are justified by finite rank mass and h>0. The extra physical-denominator increment formula is valid on the original live positive-J terms; no artificial zero-denominator identity is used in the actual flow.

Its target-deletion estimate preserves the fixed actual incoming marginal and disjoint target sets. The summed restoration premium remains unpaid, as do gate changes if one recomputed the original ranks. Nothing in this auxiliary note supplies the main cascade's price or a new negative credit. Main joint-edge D_A is a different dynamic incidence and uses original fixed ranks; it does not silently omit that rank-recomputation debit.

The auxiliary execution has 252 counted checks, ONLY 84 of which are exact Fraction pair checks. The other 168 logarithmic/derivative checks use 60-digit Decimal and a 10^-55 tolerance; they are numerical residual diagnostics rather than rational certificates. Parent records them separately. The original analytic calculus identities do not rely on Decimal residuals.

## 10. External theorem and initial integrated proof review

Read r391_sources.md, current main/ledger/tools and the MATLAB script. Independently reopened the original [Bourgain cube-maximal paper](https://arxiv.org/pdf/1212.2661), checking its first-page centered averaging definition and page-three theorem for each fixed p>1. This supports the fixed p=4/3 contract used here. No numeric C_* value, endpoint weak(1,1) consequence, or uniform near-p=1 dependence is claimed. The full 20-page proof was not freshly re-audited. The selector domination and Banach-adjoint L4 action spaces are direct deductions and do not assume f in L4.

The current ledger applies 1/(1-rho) ONLY to the G slot: original 2Lambda G_cold becomes 4Lambda G_core+16Lambda sW. Old X/source prices and H terms are not doubled. No new X coefficient, source reset, reused old square or parameter retuning is present. Source threshold T here is explicitly distinguished from previous high-source/template parameters despite the generic letter. The final self-supported core and every old unbudgeted interface remain open.

The MATLAB script has four chain sizes and floating assertions with tolerance, using actual interval-posterior incidence but synthetic equal-mass edges. It does not realize strict mass-far or the current native core, and its tool record correctly calls it diagnostic. No failed symbolic call is represented as successful evidence. Final numeric notes/code/result and complete byte bindings are reviewed below.


## 11. Final real-posterior numeric mechanism and scope

Read r391_numeric.md, the entire r391_numeric.py and its saved result. Sources are actual disjoint positive-width mass-one intervals and receiver centers actual positive-width intervals. The explicit margin hsrc+eta/2<1/2 makes every receiver cube capture exactly its two adjacent full source packets. Thus the normalized posterior is exactly one half on each packet and m=2,q=1 for every actual center, not values at sample points. Source gaps have f=0 and no posterior cost.

The deliberately chosen edge mass on each pair rectangle is a genuine du dv measure. Its constant density yields the declared combined endpoint capacity relative to qdu, including parallel edge labels and high-degree stars. The potential D and its decrements can therefore be integrated exactly by source packet labels; they are not receiver quadrature. The code explicitly tracks all edge IDs, both endpoint incidence decrements, head-only/tail-only/both-deleted events and exact source-potential drops. A star can end with an isolated retained node but zero edge measure; stopping that diagnostic early does not falsely certify a positive edge core or its posterior property.

The stale-comparison scheme deliberately freezes its original tests. Its stored old potential has no valid drop to fund later deletions; actual updated potential is separately reported. It is not a second claimed theorem. The path8 and path128 differences are consistent with the actual block posterior and strict threshold: dynamic edges disappear over 2 and 32 rounds respectively, while every original edge cost is counted once. Detailed long lists are compressed only after their exact round digest and totals are recorded.

All diagnostic masses are equal, so the original strict mass-far gate is EMPTY. The fixed graph edges and small s/T/theta are not the actual R390 cold measure or the main theorem's synchronized thresholds. They verify source/potential/crossing-edge accounting, not a native hard-family example, a numeric universal C_*, general root initial-potential bound, or disappearance of the general core. The final main/readme and saved result retain that distinction explicitly.

The script has 1703 Fraction assertions, split 1170 geometry/capacity, 400 joint-round and 133 conservation. Source and receiver geometry reduce to finite labels because indicators are constant on whole positive-volume products, not because points replace integrals. The reported 80 nonempty rounds do not create 80 initial-source charges. The code is self-contained and writes JSON beside itself; no optimizer, old /tmp dependency or float-derived proof is used.

## 12. Final complete ledger and execution counts

Read final main, ledger, readme, sources/tools and all scripts. Only the current G_cold slot is substituted:

    BH<=2G_core+E387 X_q+[S390+8(1+sqrt(n))]W.

The original entrance retains 8lambda H W and 2d_eff A_n W_nu/H, and has 4G_core, 2E387 X_q and [2S390+16(1+sqrt(n))]W before the entire expression is multiplied by Lambda. Thus the old source/receiver/H fees are not doubled, and the exact unpaid core has coefficient 4Lambda at the entrance. There is no new X allocation, old-square reuse, hidden rank recomputation or frozen-field parameter retuning. The terminal potential is dropped only to relax this bound; it is not subsequently reused as an independent negative credit.

The new density threshold depends explicitly on C_* and S, even though those constants cancel from the relative final source coefficient. No numerical value for C_* is certified by the synthetic examples or MATLAB diagnostics. The core has only closed D_core>=s and non-strict posterior>=1-theta; its at-least-half high-density consequence is correct and does not grant original next-history qualifications. New receiver deletion is auxiliary one-edge restriction, not an original temporal history event or payment of historical deletion atoms.

The exact actual G_core still has no general source budget. The original H entry/choice, soft/crossing/entry, heavy-tail/wide-distance/low-pe/extreme-scale complements, initial/deleted/future-deleted history atoms, source/all-scale aggregation, truncation and limits remain open. The auxiliary restoration premium is also unbudgeted and not entered as a new fee or credit.

Parent reports successful actual runs: 2012 Fraction main-proof checks, 84 Fraction auxiliary pair checks and 1703 Fraction numeric checks, totaling 3799 exact rational assertions. The additional 168 auxiliary checks are 60-digit Decimal residual tests with tolerance, and the four MATLAB cascade configurations are floating diagnostics. These categories are not merged as exact assertions. Reviewer bounded evidence is the separate 166 Fraction tests in Section 7; no complete parent pipeline was repeated. The external PDF check covered definition/theorem scope, not its entire proof; no endpoint or near-p=1 estimates were inferred. This audit does not certify LaTeX layout/compilation or freshly re-prove the entire historical reduction.

FINAL PASS: no outstanding correction found in the relative joint-edge cascade, constants, boundary/limit conventions, final accounting or numerical scope. The general root bound remains unproved because the self-supported actual core and inherited slots remain unpaid.

## 13. Final byte bindings

| File | SHA256 |
| --- | --- |
| `/tmp/r391_main.md` | `6672c923f261ce28e0dead26e0168d0f932cf393fe39c62f9bb092a40669de44` |
| `/tmp/r391_ledger.md` | `80bc308daa41ce6792dd9a3fe01664c747071607218e8c5866cb4efd1c2842d5` |
| `/tmp/r391_readme.md` | `f30166271ba6f68fcf48f178dce58a92f698b68ea1aea006a6d3e9bb6f19abc8` |
| `/tmp/r391_geometry.md` | `1ccdc3446df5d157fcf6700f32d3790d65c98c48127318a5acd951a110290c23` |
| `/tmp/r391_geometry_check.py` | `e585b5aa807515ade92e219ea87916b15b0a417a1aa7c73061f5a99c4d1b6250` |
| `/tmp/r391_aux.md` | `b2c45b957974244f657f96c030b712200adef41f9f9f857adda7800be2640e6d` |
| `/tmp/r391_aux_check.py` | `f070d84602b61de5057334b0d37199085ba2025b994a2f3fb8ac6dea6c240296` |
| `/tmp/r391_numeric.md` | `d592d3adcd0588d3c2a39d09fe30969d70e95a15ec81ccd7730f4bfc8e13eb28` |
| `/tmp/r391_numeric.py` | `5e69ea7dd53d0bab813416651cd5cf7eb9b30fa8d09cdedbdc54305ecfb1b82a` |
| `/tmp/r391_numeric.result.json` | `77ddb56cf4858b844a614533766ebbac742ef1b130ff9cea812d61786b14c224` |
| `/tmp/r391_sources.md` | `c3a10ad7d838de7d3543e894094b67e7fe4fb35c7d5fb6f0c711790b2380f0f1` |
| `/tmp/r391_tools.md` | `c0cb2a1556ca77455884205de1496af5dfb5b42a242df0c093611aae56e6e8e9` |
| `/tmp/r391_cascade.m` | `80649a3673aa750c6523ff34b13282ca762855ef314190639f4b727f67b9bf93` |
| `/tmp/r390_ledger.md` | `fea0ea4fb0134ff61ca69de3c2bce51e6d28013fe0a82d448857b2fa6dffb42b` |
| `/tmp/r389_ledger.md` | `10f4145bbc83290f6482ef6ac3b4289ff2d59921e74cb9ff011685c53c9bb7d6` |
| `/tmp/r390_aux.md` | `9b32a470d47ca8c874bb7e1aed1a62dc6b56a31a0e296f6e1de7e9337270dd36` |
| `/tmp/r351_geometry.md` | `c8d688467593892e84608eb40774d62d61112284b40c18c261dee54f8effe4a3` |
