# R391: dynamic joint-edge occupancy and a real-posterior cascade

This implements the parent's revised joint-cascade task, replacing the earlier rank-deletion-order exploration. It uses an actual positive L1 source and **genuine positive-volume receiver intervals**, not receiver point quadrature. Their full hard-kernel posteriors are exact. The frozen joint edge measure is deliberately selected on receiver pair rectangles and has endpoint marginals bounded by actual q du; it is **not** the original filtered/far/history edge measure. All receiver masses are equal, so original strict mass-far is empty. This is a source-potential/deletion mechanism diagnostic, not a native hard-branch or general closure certificate.

## Actual source and receiver geometry

For N receivers let source packets S_j=[j-hsrc,j+hsrc], j=0,...,N, each have mass 1 and common density f0=1/(2hsrc). Source f is zero off these disjoint intervals, giving full W=N+1. Receiver centers range over E_i=[i+1/2-eta/2,i+1/2+eta/2], i=0,...,N-1, with actual R=L=2 and hard softness zero.

The exact geometric condition hsrc+eta/2<1/2 ensures that **every actual center in E_i** captures the whole of S_i and S_(i+1), and excludes every other packet. Thus actual full-f matching gives m_i=2,q_i=m_i/R=1=lambda, with same-full-f cap <=lambda<4lambda. The actual normalized posterior pi_i puts mass 1/2 on each of its two source packets. The source and receiver integrations reduce to finite labels because capture indicators are constant on whole positive-volume products, not because source/receiver points substitute for integrals. Source gaps have f=0 and contribute zero potential/posterior mass.

Choose a graph of oriented receiver-block pairs. Each edge of integrated weight gamma_e is the genuine du dv measure with constant density gamma_e/(eta^2) on its pair rectangle. The orientation is frozen; the potential counts both endpoints. A base edge weight g=eta/(maximum graph degree), split across parallel labels when present, gives

sum_(edges incident i) gamma_e <=eta=q_i |E_i|.

Hence even the combined endpoint marginal is <=q du, and this remains true after deletion. This capacity check does not turn the chosen kernel into original mass-far traffic. It only keeps the diagnostic measure compatible with the actual receiver-volume budget.

## Exact joint potential and deletion rule

For active receiver blocks A, retain an edge iff **both** its endpoints belong to A. Set

D_A(z)=sum_(active edges) gamma_uv [c_u(z)/m_u+c_v(z)/m_v],
e_A(z)=1_(D_A(z)>s)*(1-T/f(z))_+,
p_A(i)=integral e_A d pi_i.

The indicator and positive part are multiplied; the positive part is not part of the threshold. At D=s the indicator is zero. The field f, original masses, posteriors, edge weights and s/T/theta remain frozen. Only the active endpoint restriction and its D/p are recomputed.

The baseline uses hsrc=.1,eta=.2,g=.1,s=7g/4=7/40,T=.5 and theta=.5. Thus (1-T/f0)=.9. Delete all current weak receivers p_A<=1-theta synchronously, and remove their incident active edges, charging each original edge once even if both endpoints are weak.

On each source packet, D is constant and its exact integrated potential is

Psi_A =sum_packets [min(D,s)+(T/f0)(D-s)_+].

This is exactly the integral of f min(D,s)+min(f,T)(D-s)_+, since each source packet has mass 1 and length 1/f0. No universal C4 value, Lp bound, or native synchronized s/T relation is assumed; the initial potential is calculated exactly for this field.

For each step the script independently checks the source increment by summing **both endpoint posteriors of every deleted edge**, then verifies

DeltaPsi >= integral f(1-e_A)(D_A-D_next)
          =sum_deleted gamma_uv [(1-p_A(u))+(1-p_A(v))]
          >=theta*sum_deleted gamma_uv.

This remains valid at D=s and weak-p equality. Each deleted edge has a weak endpoint; a second weak endpoint strengthens the derivative charge but never causes the edge cost to be counted twice. Exact edge IDs prove disjoint deletion sets and original cost=deleted+remaining. The source drops telescope to initial minus final Psi, without a factor equal to the number of rounds.

## What changes when occupancy follows the actual surviving edges

The competing stale diagnostic deletes nodes using the initial D/e/p forever, while the real surviving edge set is still restricted to both active endpoints. It is intentionally not the proposed algorithm. Once source occupancy changes, those old tests can fail to expose newly weak endpoints. Its stored old-potential drop is zero; that unchanged stored quantity cannot be used to fund positive deleted-edge cost. Actual potential is separately recomputed for reporting, so the code does not confuse a stale bookkeeping value with the proved source-potential drop.

Baseline path with N=8:

| round | weak receivers | deleted edge cost | true source-potential drop |
|---|---|---:|---:|
| 1 | 0,1,6,7 | 2/5 | 71/100 |
| 2 | 2,3,4,5 | 3/10 | 231/400 |

Total original edge cost is 7/10, deleted once in full. Initial Phi=103/80, final Phi=0, and theta times total deleted cost=7/20<=103/80. Only one initial source potential is used. The stale initial tests stop after the first round with edge cost 3/10 still present and four receivers that are weak under the **actual** new occupancy. Its initial tests miss them.

A long path with N=128 has 32 nonempty dynamic rounds. Total edge cost 127/10 is deleted once, and all round drops sum exactly to initial Phi=1807/80; theta total deleted=127/20. The stale scheme stops after one round and retains 123/10 edge cost. This is a concrete cascade/one-budget distinction, not merely a repeated scalar identity or a claim about general hard traffic.

## Three bounded stages

| stage/example | dynamic nonempty edge rounds | stale remaining cost |
|---|---:|---:|
| initial single edge | 1 | 0 |
| initial path8 | 2 | 3/10 |
| strict threshold path8, s=5g/4 | 4 | 1/2 |
| strict threshold path8, s=3g/2 | 2 | 3/10 |
| strict threshold path8, s=7g/4 | 2 | 3/10 |
| strict threshold path8, s=2g | 1 | 0 |
| clip/source-density pressure path12 | 3 | 7/20 |
| cycle8 | 3 | 1/2 |
| long path32 | 16 | 29/10 |
| long path128 | 32 | 123/10 |
| cycle32 | 9 | 29/20 |
| star16 | 1 | 0 |
| parallel-labelled path16 | 4 | 11/10 |

The three stages contain 2,6,5 fields. Threshold pressure includes T=0, exact D=s and exact weak p=1-theta cases. Other changes include source widths .05/.1, receiver widths .1/.2, clip ratios, theta=.25/.5, graph overlaps and parallel edge labels. The star verifies that deleting weak endpoints removes their edges even when the surviving hub is strong; isolated receivers with zero incident cost need not be deleted to finish the edge ledger. No claim is made that every graph must cascade or that local stationarity is a global hard-budget bound.

The constructive evidence favors recomputing D from the same surviving joint edge measure, with both endpoints present. Testing weak nodes against a frozen initial edge occupation is a materially different procedure and can leave a large unpaid edge set. These statements concern this exactly computed diagnostic family only. All masses m=2 imply native mass-far emptiness; the chosen small s/T are not the main theorem's synchronized parameters, and no new source/kernel is substituted for original marked traffic.

## Reproduction and evidence scope

Run `python3 r391_numeric.py`. Python standard library only; no old /tmp imports, optimizer, Monte Carlo or third-party library. The script writes `r391_numeric.result.json` beside itself. Exact full details are kept for small fields; long fields retain per-round exact totals plus a digest of reconstructible edge-ID details, avoiding a large redundant archive.

**1,703 exact Fraction assertions** passed: 1,170 geometry/capacity, 400 joint-round checks, 133 conservation checks. The executed dynamic fields have 80 nonempty edge-removal rounds in total; they do not create 80 copies of the initial source charge. A second fresh process reproduced result bytes. Decimal descriptions are displays of rational quantities. Only owned R391 files changed; no repository/Git operations. This checks the cascade mechanism and shared source accounting; it does not certify its original high-dimensional historical applicability or an initial-potential general root bound.
