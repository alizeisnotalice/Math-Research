from fractions import Fraction as F
from itertools import product
counts={'potential':0,'deletion_steps':0,'edge_accounting':0,'moment':0,'relative_price':0}
features={'strict_second_rounds':0,'tail_only_edges':0,'head_only_edges':0,'both_removed_edges':0,'surviving_core_cases':0}
for f,T,s,x,y in product((F(0),F(1,2),F(1),F(3)),(F(1,10),F(1),F(4)),(F(1,2),F(1),F(2)),(F(0),F(1,4),F(1),F(3)),(F(0),F(1,4),F(1),F(3))):
    if y>x: continue
    def psi(d): return f*min(d,s)+min(f,T)*max(d-s,0)
    e=max(1-T/f,F(0)) if f and x>s else F(0)
    assert f*(1-e)*(x-y)<=psi(x)-psi(y)
    counts['potential']+=1

def run_case(support,edges,f,s,theta,rho,C4fourth):
    N=len(support); masses=[sum(f[z] for z in support[u]) for u in range(N)]
    # q=1, du mass 1, R_u^n=m_u: receiver/source incidence diagnostic.
    def current(A): return {(u,v):g for (u,v),g in edges.items() if u in A and v in A}
    def degrees(E):
        d=[F(0)]*N
        for (u,v),g in E.items(): d[u]+=g; d[v]+=g
        return d
    def occ(E):
        d=degrees(E)
        return [sum(d[u]/masses[u] for u in range(N) if z in support[u]) for z in range(len(f))]
    G=sum(edges.values(),F(0)); S=max(degrees(edges),default=F(0))
    if not G: return
    T=rho*theta*s**3/(2*C4fourth*S**3)
    def pot(D): return sum(f[z]*min(D[z],s)+min(f[z],T)*max(D[z]-s,0) for z in range(len(f)))
    active=set(range(N)); initial=occ(edges); total_removed=F(0); round_no=0
    while True:
        E=current(active); D=occ(E)
        deg=degrees(E)
        assert sum(D[z]*f[z] for z in range(len(f)))==2*sum(E.values(),F(0))
        assert sum(x**4 for x in D)<=C4fourth*sum(x**4 for x in deg)
        assert sum(x**4 for x in deg)<=2*S**3*sum(E.values(),F(0))
        counts['moment']+=1
        e=[max(1-T/f[z],F(0)) if f[z] and D[z]>s else F(0) for z in range(len(f))]
        posterior={u:sum(f[z]*e[z] for z in support[u])/masses[u] for u in active}
        removed={u for u in active if posterior[u]<=1-theta}
        if not removed: break
        new_active=active-removed; new_E=current(new_active); new_D=occ(new_E)
        lost={edge:g for edge,g in E.items() if edge not in new_E}
        loss=sum(lost.values(),F(0))
        # All incident old edges, including outgoing to retained receivers, are charged.
        for (u,v),g in lost.items():
            assert u in removed or v in removed
            features['tail_only_edges']+=bool(u in removed and v not in removed)
            features['head_only_edges']+=bool(v in removed and u not in removed)
            features['both_removed_edges']+=bool(u in removed and v in removed)
            counts['edge_accounting']+=1
        for z in range(len(f)):
            direct=sum(g*((F(int(z in support[u]),1)/masses[u])+(F(int(z in support[v]),1)/masses[v])) for (u,v),g in lost.items())
            assert D[z]-new_D[z]==direct
        charge=sum(f[z]*(1-e[z])*(D[z]-new_D[z]) for z in range(len(f)))
        assert theta*loss<=charge<=pot(D)-pot(new_D)
        total_removed+=loss; active=new_active; round_no+=1
        counts['deletion_steps']+=1
        if round_no>1 and loss: features['strict_second_rounds']+=1
    core=sum(current(active).values(),F(0)); final=occ(current(active))
    assert G-core==total_removed
    assert theta*total_removed<=pot(initial)-pot(final)
    assert pot(initial)<=s*sum(f)+2*T*C4fourth*S**3*G/s**3
    assert G-core<=rho*G+s*sum(f)/theta
    assert (1-rho)*G<=core+s*sum(f)/theta
    if core: features['surviving_core_cases']+=1
    counts['relative_price']+=1

# Actual interval/source incidences with receiver quadrature: Q_j=[j,j+2], f=1.
# Directed edge marks are algebraic; equal masses do not meet original far gates.
for N,w,scale in product(range(4,15),(F(1,4),F(1,2),F(3,4)),(F(7,5),F(8,5),F(9,5))):
    support=[{j,j+1} for j in range(N)]
    edges={(j,j+1):w for j in range(N-1)}
    run_case(support,edges,[F(1)]*(N+1),scale*w,F(1,4),F(1,2),F(1))
# A nonempty self-supported core; no universal emptiness is asserted.
N=4
support=[{0,1} for _ in range(N)]
edges={(u,v):F(1,8) for u in range(N) for v in range(u+1,N)}
run_case(support,edges,[F(1),F(1)],F(1,4),F(1,4),F(1,2),F(8))
print('PASS',counts,'total',sum(counts.values()))
print('features',features)
