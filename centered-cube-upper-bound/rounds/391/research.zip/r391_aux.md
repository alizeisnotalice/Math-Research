# R391 — Exact rank deletion audit, including partially deleted mass atoms

This is a fee audit, not a new root-order receipt. Deleting actual receiver subsets while recomputing their mass-prefix ranks creates a nonnegative survivor-restoration premium. Below that premium is an exact genuine common-source overlap integral. No available estimate pays its sum over a cascade. Keeping the original marked edge measure frozen avoids introducing this particular recomputation cost; it does not by itself prove a cascade theorem.

## 1. Frozen actual field and the two-variable potential

Keep full f, selected actual cubes, all original physical-clock and history marks, and

m_u=∫f c_u=q_uR_u^n, q_-≤q_u≤λ, μ(du)=du/m_u,
π_u(dy)=f(y)c_u(y)dy/m_u, ρ_y(du)=c_u(y)μ(du).

Only actual measurable receiver subsets B⊂A⊂E are deleted; write R=A\B. These are common receiver sets, not source-private choices. Put, for source y and mass level x,

T_C(y,x)=∫_C1_{m_u≤x}ρ_y(du), J_C(y)=ρ_y(C),
a_C(y,x)=ρ_y(C∩{m=x}), T_C^-=T_C−a_C.

All masses, π, μ and q remain those of the full field. The two-variable source/mass potential is

V_C(y,x)=Φ(T_C(y,x)), Φ(t)=h log(1+t/h), h>0.                 (1)

T_C≤J_max is finite under the original center envelope. Define the atom-averaged witness

w_C(y,x)=∫_0^1 h/[h+T_C^-(y,x)+t a_C(y,x)]dt.                (2)

When a_C>0 this is h/a_C times log[(h+T_C)/(h+T_C^-)]; when a_C=0 it is h/(h+T_C). In particular w_C≥h/(h+T_C). Generalized inverse ranks, splitting a mass atom over its entire rank interval, give exactly

∫_C w_C(y,m_u)ρ_y(du)=Φ(J_C(y)).                            (3)

This includes singular continuous mass distributions and crossing atoms. All functions are measurable: the inclusive/strict cumulative integrals and atom masses are jointly measurable in (y,x). No ordering of a dense countable atom set is required.

The units of Φ and all sourcewise quantities below are receiver-rank units, the same as h and J. Multiplication by λ∫f converts them into the original source-price units; Φ itself is not an unscaled W fee.

## 2. Continuous deletion parameter and exact positive premium

Fix y temporarily. Let ρ_s=ρ_B+sρ_R, 0≤s≤1; thus the actual subsets are the endpoints, and the intervening measures are only an analytic interpolation. Write

l_s(x)=T_B^-(x)+sT_R^-(x), a_s(x)=a_B(x)+s a_R(x),
w_s(x)=∫_0^1 h/[h+l_s(x)+t a_s(x)]dt.

Direct differentiation under the bounded integral gives

−∂_s w_s(x)=∫_0^1 h[T_R^-(x)+t a_R(x)]/
                    [h+l_s(x)+t a_s(x)]² dt ≥0.             (4)

The denominator is always at least h, so the parameter derivative and all positive Tonelli exchanges are justified by finite rank mass. Set

P_y(A,B)=∫_B[w_B(y,m_v)−w_A(y,m_v)]ρ_y(dv)≥0.               (5)

Then the exact deletion identity is

∫_R w_A(y,m_u)ρ_y(du)
 =Φ(J_A(y))−Φ(J_B(y))+P_y(A,B).                             (6)

In particular it is incorrect to upper-bound the left side by the potential drop alone. The potential drop is a lower bound. Equation (6) follows by subtracting (3) at A and B, and (4) explicitly accounts for its extra term, including deletion of only part of a mass atom.

For completeness, differentiation of (3) for ρ_s gives the local identity

∫_R w_s dρ_y − ∫(−∂_s w_s)dρ_s
 =h J_R/[h+J_B+sJ_R].                                      (7)

Thus even during infinitesimal deletion the restored witness of all surviving traffic is a genuine positive debit.

## 3. Exact common-source pair kernel of restoration

For x=m_v define

L_y(u,v;s,t)=1_{m_u<m_v}+t 1_{m_u=m_v},
H_y(v;s,t)=h/[h+T_B^-(y,m_v)+sT_R^-(y,m_v)
                         +t(a_B(y,m_v)+s a_R(y,m_v))]².

Equations (4)–(5) give exactly

P_y(A,B)=∫_Bρ_y(dv)∫_Rρ_y(du)∫_0^1∫_0^1
                    L_y(u,v;s,t)H_y(v;s,t)dt ds.            (8)

Consequently ∫f(y)P_y dy is an actual two-receiver overlap integral with source density

f(y)c_u(y)c_v(y)/(m_um_v),

not a volume estimate for f and not an independent posterior model. The coefficient t on equal-mass pairs is necessary. Replacing it by zero would discard partial-atom restoration. At non-atomic mass levels the kernel is simply the ordered overlap h/(h+T_s)². Equation (8) does not contain the original sparse edge mark, strict mass gap, physical-clock factor or middle-rank gate. The full-prefix premium therefore cannot be declared a negative credit available from the original G_cold. No old capture square is reused here.

## 4. What this would cost for the actual frozen incoming flow

Let γ be the exact R390 current marked edge measure, already multiplied by (1−F_v/t_cold)_+. Its incoming marginal is κ_cold(v)q_vdv with 0≤κ_cold≤C_col. This is the same original flow, not a rebuilt kernel. Define the full-source averaged witness on an actual receiver subset A by

Fbar_A(v)=∫π_v(dy)w_A(y,m_v), v∈A.

It uses the unchanged π_v. Suppose a finite nested deletion scheme A_0=E⊃A_1⊃...⊃A_N removes R_i=A_i\A_{i+1}, with Fbar_{A_i}(v)≥t>0 for v∈R_i. The cost of the original γ edges whose target lies in ∪R_i satisfies

γ{target∈∪R_i}
 ≤(C_col/t)∑_i∫_{R_i}q_v Fbar_{A_i}(v)dv
 ≤(C_col λ/t)∫f(y){Φ(J_E(y))−Φ(J_{A_N}(y))
                            +∑_i P_y(A_i,A_{i+1})}dy.       (9)

The first line uses only the existing incoming-column bound on disjoint target sets. The second uses the exact full-f identity q_vdv π_v(dy)=q_v f(y)dy ρ_y(dv), q_v≤λ, and (6). This is valid with arbitrary original source/time/history marks because they stay inside γ throughout. All edges ending in A_N remain unchanged and unpaid. In particular no current-source condition is transferred to a witness source.

The first term is at most

(C_col λh/t) log(1+J_max/h)W,                               (10)

the already known root-logarithmic witness scale. The genuinely additional unpaid term in this deletion scheme is

(C_col λ/t)∫f(y)∑_iP_y(A_i,A_{i+1})dy.                      (11)

This is not a fee paid once by (10). No bound for (11) at the scale (10) has been proved. Coarse use of 0≤w≤1 only gives ∑removed-witness≤J_E, hence an order λJ_max W bound, which loses the desired root scale.

If instead one changes the original kernel ranks after deletion, there is a second issue: even on surviving endpoints and frozen marks, replacing 1/T_A by 1/T_B introduces the positive increment (T_A−T_B)/(T_AT_B). With the original physical clock denominator the exact increment is

1/max(J,T_B)−1/max(J,T_A)=∫_{T_B}^{T_A}1_{s>J}ds/s²≥0.       (12)

Recomputing middle-rank gates additionally creates gate-entry and gate-exit terms of uncontrolled sign. Equations (9)–(11) deliberately avoid these changes: they audit deletion of the actual old flow only. They neither establish a new qualified transition nor justify any repeated kernel construction.

## 5. Verification and scope

`/tmp/r391_aux_check.py` uses standard-library Fraction and 60-digit Decimal arithmetic. It checks partial tied-mass deletion, the exact pair numerator in (8), the local derivative conservation (7), and the endpoint difference (6). Counts and actual output are recorded after execution below. These are finite algebraic diagnostics, not native continuum fixtures. The proof above covers actual du, arbitrary full f and all mass atoms. This note supplies an exact missing-cost identity, not a new global payment or a general cascade closure.

Actual local run:

`PASS {'partial_atom_pair': 84, 'local_derivative': 84, 'endpoint_difference': 84} total 252`

The pair-kernel check is exact Fraction arithmetic. The logarithmic endpoint and derivative checks use 60-digit Decimal evaluation with error tolerance 10^−55; those numerical checks do not replace the exact calculus identities.
