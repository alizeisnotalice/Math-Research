# R391 — A single shared-source budget for a dynamic two-endpoint traffic cascade

## 1. Exact theorem on the current original traffic

Freeze the actual R390 cold kernel, including every original clock, source/target, strict-far, spatial, middle-rank and fractional mark. Write

 σ(du)=q_u du,
 γ(du,dv)=σ(du)K_cold(u,dv),
 G=γ(E×E)=G_cold.

This is the endpoint projection of the original fully labeled positive cost measure. Every restriction below is applied to that measure through its existing u,v labels; none of its old fields or transition marks is recomputed.

The certified current row and column bounds are

 K_cold1≤β,  K_cold†1≤C_col,
 β=(1+d)^−1,
 C_col=(λ/q_-)[1−β+log(β/α)],  α=τ/2,
 S=β+C_col.                                                (1)

For A⊂E restrict both endpoints:

 γ_A=1_{A×A}γ,   G_A=γ_A(E×E).

Let s_A be the sum of the outgoing and incoming densities of γ_A relative to σ. Then

 0≤s_A≤S,    ∫s_A dσ=2G_A.                                (2)

Define the **dynamic actual-edge occupancy**

 D_A(z)=∫γ_A(du,dv)[c_u(z)/m_u+c_v(z)/m_v]
       =∫_E s_A(w)c_w(z)R_w^(−n)dw.                       (3)

It counts the two endpoints of current surviving edges, with their actual cost weights. It is not the unweighted receiver occupancy or the fixed incidence density of the original full graph. In particular, edges already removed no longer contribute to D_A even at a surviving endpoint.

Fix s>0, 0<θ<1 and 0<ρ<1. Let C_* be the audited dimension-independent centered-cube maximal L^(4/3) constant described in §4, and put

                T=ρ θ q_- s³/(2 C_*^4 S³).                (4)

If G=0 there is no traffic to settle. Otherwise all constants are positive. Define, with zero value on f=0,

 e_A(z)=1_{D_A(z)>s}(1−T/f(z))_+,
 p_A(w)=∫e_A(z)π_w(dz),  π_w(dz)=f(z)c_w(z)dz/m_w,
 A_0=E,
 A_{j+1}={w∈A_j:p_{A_j}(w)>1−θ},
 A_∞=intersection_j A_j,
 γ_core=γ_{A_∞},  G_core=γ_core(E×E).                       (5)

Then the entire possibly infinite cascade is paid at one relative/source price:

 G−G_core≤ρG+(s/θ)W,
 G≤[G_core+(s/θ)W]/(1−ρ).                                 (6)

For the fixed choice ρ=1/2, θ=1/4, s=1+√n this gives

                   G_cold≤2G_core+8(1+√n)W.               (7)

No new X_q fee or change to the original h is required. The final core remains unpaid. The substantive new payment is the entire cascade of edges incident to recursively weak endpoints, including old flow going out of a newly deleted vertex into a retained one. The dynamic definition (3) prevents already deleted edges from continuing to protect the eventual core.

## 2. Every removed original edge is accounted for once

Set R_j=A_j\A_{j+1}. Define the newly removed edge set

 ℛ_j=(A_j×A_j)\(A_{j+1}×A_{j+1}).

These edge sets are disjoint over j. Every edge of ℛ_j has at least one endpoint in R_j. This includes edges from R_j into A_{j+1}, edges from A_{j+1} into R_j, and edges with both endpoints in R_j. Their exact cost is

                       γ(ℛ_j)=G_{A_j}−G_{A_{j+1}}.        (8)

The occupation decrement is the exact positive identity

 D_{A_j}(z)−D_{A_{j+1}}(z)
 =∫_{ℛ_j}[c_u(z)/m_u+c_v(z)/m_v]γ(du,dv).                  (9)

Write e_j=e_{A_j}. Each w∈R_j satisfies π_w(1−e_j)≥θ. By full-f matching and Tonelli,

 ∫f(z)(1−e_j(z))[D_{A_j}(z)−D_{A_{j+1}}(z)]dz
 =∫_{ℛ_j}[π_u(1−e_j)+π_v(1−e_j)]γ(du,dv)
 ≥θ γ(ℛ_j).                                               (10)

If both endpoints are weak, the sum in (10) contains two defects, but the edge's cost in (8) is still charged only once. The unused second defect merely improves the inequality. There are no new arrivals, no deleted flow omitted from (8), and no replacement of an old endpoint by a newly qualified successor.

## 3. One positive source potential pays all rounds

For each source z define

 Ψ_z(x)=f(z)min(x,s)+min(f(z),T)(x−s)_+,  x≥0.               (11)

For x≥y≥0,

 f(z)(x−y)[1−1_{x>s}(1−T/f(z))_+]
                      ≤Ψ_z(x)−Ψ_z(y),                    (12)

using the zero convention when f=0. The slopes of Ψ are f below s and min(f,T) above s. If the interval [y,x] crosses s, the lower segment has the larger slope; this proves (12), including x=s.

Apply (12) to the exact decrement (9) and then (10):

 θ[G_{A_j}−G_{A_{j+1}}]
 ≤∫[Ψ_z(D_{A_j}(z))−Ψ_z(D_{A_{j+1}}(z))]dz.               (13)

Summing telescopes. Since γ is finite and A_j decreases, γ_{A_j} decreases to γ_{A_∞}; the same nonnegative integral representation gives D_{A_j}↓D_{A_∞}. The potential is continuous and increasing, so monotone convergence for the nonnegative potential differences yields

 θ(G−G_core)
 ≤∫[Ψ_z(D_E(z))−Ψ_z(D_{A_∞}(z))]dz.                       (14)

All fields are measurable by the original cube/receiver measurability and nonnegative parameter integration. The uniform bound s_A≤S and the bounded-radius actual-center envelope make D_A finite; null-set versions can be chosen consistently. Thus no nonmeasurable optimization or limiting field reconstruction is used.

Equation (14) is the joint saving: one shared source potential pays outgoing, incoming, and crossing deletions over every round. The final potential is retained in the exact formula. It is a newly constructed positive potential decrement, not a second use of the old BH capture square.

## 4. Initial potential price, with the correct action spaces

Use the already audited centered-cube maximal estimate from R351:

 ||M_cube g||_{L^(4/3)(dz)}≤C_*||g||_{L^(4/3)(dz)}.

For this fixed actual measurable radius field, the linear averaging operator

 (T_R g)(w)=R_w^(−n)∫_{Q_w}g(z)dz,  w∈E,

maps L^(4/3)(R^n,dz) to L^(4/3)(E,dw) with norm at most C_*, because |T_R g|≤M_cube|g| on E. Its Banach adjoint is

 (T_R^*b)(z)=∫_E b(w)c_w(z)R_w^(−n)dw,

and maps L^4(E,dw) to L^4(R^n,dz) with the same norm. By (3), D_E=T_R^*s_E. This is a Lebesgue L^4 bound on the dynamic center occupancy, not an L^4 bound on f.

Using (2) and the true q-band,

 ∫D_E(z)^4 dz
 ≤C_*^4∫s_E(w)^4dw
 ≤C_*^4S³∫s_E(w)dw
 ≤(2C_*^4S³/q_-)G.                                       (15)

The factor 2 is the two-endpoint incidence total. In particular the moment is priced by the actual current traffic G, not by an incorrectly assumed unit incoming density. The C_col dependence remains explicitly in S³.

From (11),

 ∫Ψ_z(D_E(z))dz
 ≤sW+T∫(D_E−s)_+dz
 ≤sW+T s^(−3)∫D_E^4 dz
 ≤sW+[2T C_*^4 S³/(q_-s³)]G.                             (16)

Insert (4) into (14)–(16), divide by θ, and obtain (6). The terminal potential in (14) may be kept for a sharper exact bound, but is not spent again elsewhere. The full source W occurs once; there is no source-density cap and no price proportional to the number of rounds.

The dimension-independent maximal constant is used solely in (15), in the same action spaces and cube family as the audited R351 tool. Its value changes the explicit density threshold T in (4). It does not disappear from that threshold even though the final source coefficient in (6) is independent of C_* and C_col.

## 5. Precise surviving core and the unchanged original fields

The decreasing occupancy gives e_j↓e_* pointwise. At a threshold limit one can only assert

 e_*≤1_{D_{A_∞}≥s}(1−T/f)_+.

For every w∈A_∞, bounded convergence under its actual π_w yields

 π_w(e_*)≥1−θ,
 π_w[1_{D_{A_∞}≥s}(1−T/f)_+]≥1−θ.                       (17)

The closed occupancy gate and non-strict posterior inequality are intentional. The eventual set need not be a strict-threshold fixed point.

Let S_∞={z:D_{A_∞}(z)≥s, f(z)>2T}. Outside S_∞ the weight on the right in (17) is at most 1/2. Hence

                         π_w(S_∞)≥1−2θ.                  (18)

For θ=1/4, both endpoints of every retained core edge capture at least half of their full-f mass in S_∞, up to the original receiver null sets. Crucially D_{A_∞} is supplied by the actual remaining edge measure γ_core, not by deleted receivers, old edge incidence or unrelated frozen occupancy.

All original f,m,q,J,T_y,Z, physical clock, source/target labels, strict far mass, R387 intermediate ranks, R388 witness retentions and R390 cold-end factors remain unchanged. The new D_A is an auxiliary potential occupancy only. No statement is made that a retained endpoint inherits a new original history or outgoing eligibility beyond the original retained edges it actually has. The nonempty core satisfying (17)–(18) has not been given a general root-order budget.

## 6. Complete incremental ledger

If the entering same-slot bound is

                    BH≤G_cold+E_old X_q+S_old,

then the general relative form gives

 BH≤G_core/(1−ρ)+E_old X_q+S_old
                       +sW/[θ(1−ρ)].                    (19)

No additional εX_q is silently inserted: E_old, the original h and all prior allocations stay fixed. With ρ=1/2, θ=1/4, s=1+√n,

 BH≤2G_core+E_old X_q+S_old+8(1+√n)W.                     (20)

At the original outer factor 2Λ, the old 2ΛG_cold slot becomes

                  4ΛG_core+16Λ(1+√n)W.                  (21)

All other entrance terms are unchanged. One must retain the doubled coefficient of the unpaid core; it cannot be relabeled as a coefficient-one remainder for free. This is the price of using a relative G absorption while leaving the old X_q allocation intact.

Compared with direct transport of R351's receiver deletion criterion, the new construction uses dynamic edge incidence, pays every removed original edge at either end, and prices its fourth moment by the actual G with the true column constant. Merely replacing an old κ≤1 by κ≤C_col would neither give (9) for both endpoints nor prevent deleted crossing edges from supporting later tests.

## 7. Reproducible exact checks and their limits

Executed locally:

    python3 /tmp/r391_geometry_check.py

    PASS {'potential': 360, 'deletion_steps': 330,
          'edge_accounting': 792, 'moment': 430,
          'relative_price': 100} total 2012
    features {'strict_second_rounds': 198, 'tail_only_edges': 231,
              'head_only_edges': 231, 'both_removed_edges': 330,
              'surviving_core_cases': 1}

All arithmetic is Fraction. Scalar checks verify (12), including f=0 and threshold equalities. The cascade checks use actual interval/source incidences Q_j=[j,j+2] with f=1 and positive receiver quadrature, and exactly track their original directed edge costs. They verify (9), both endpoint defects, the finite moment estimate, the total deleted cost and the relative final price. Later rounds delete positive cost in 198 checks; the 231 tail-only and 231 head-only cases specifically guard against dropping flow across a deletion boundary. A separate case retains a nonzero core.

These directed finite edge marks are algebraic diagnostics; equal cube masses do not satisfy the original exponential-far condition, and receiver integration in the examples is quadrature. The tests therefore certify the cascade accounting, not a native full-history realization. The actual-field theorem follows analytically from (8)–(16), with the already audited geometric L^(4/3) estimate in precisely the role stated above. No numeric example is used to claim that the final core is empty.
