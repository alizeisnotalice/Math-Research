# R351 — Shared-source peeling with one telescoping overlap budget

## Statement screened and proved

The R350 rank kernel and all original traffic marks remain fixed. Its incoming actual receiver density satisfies 0≤κ(w)≤q_w and ∫κ=G_late[g_ex]. This note pays every receiver removed by a countable cascade of source-concentration tests, with the same single budget that R350 used for only its first test. No factor for the number of peeling rounds occurs.

In particular, the R350 remaining set {p_w>3/4} can be reduced to a core that is still source-concentrated with respect to its own receiver occupancy. This is a new actual joint payment: earlier deleted receivers can no longer artificially provide the high occupancy needed to protect later receivers. The general budget for the final core remains open.

## 1. Frozen full-f field and measurable cascade

Keep f≥0 in L¹, W=∫f, true centered cubes Q_w with a≤R_w≤b≤2a, and

    c_w(z)=1_{Q_w}(z),  m_w=∫fc_w=q_w R_w^n,
    q_-=3λ/4≤q_w≤λ,  X_q=∫_E q_w dw.

The original late flow carries the old source g_ex(y), old u and small endpoint, full J_y(r), physical clock ell including its b atom, ηΩ, original high-past/outside/relative-upper and late-prefix gates. The R350 qρ rank kernel supplies an actual terminal witness w and gives κ≤q_w. None of these choices or fields is recomputed in this note. We only restrict the already marked traffic by deterministic measurable sets of its existing w label.

For any measurable receiver set A⊂E define its actual occupancy

    D_A(z)=∫_A c_w(z)R_w^{-n}dw.

For s,T>0 define a source weight and its true full-f posterior average:

    e_A(z)=1_{D_A(z)>s}(1−T/f(z))_+,
    p_A(w)=∫e_A(z)π_w(dz),   π_w(dz)=f(z)c_w(z)dz/m_w,

with e_A=0 on f=0. These are measurable. Fix 0<θ<1 and set

    E_0=E,
    E_{j+1}={w∈E_j:p_{E_j}(w)>1−θ},
    R_j=E_j\E_{j+1},
    E_∞=intersection_{j≥0} E_j,
    D_j=D_{E_j},  e_j=e_{E_j}.

The sets decrease and R_j are disjoint. Their actual occupancy increments satisfy the exact identity

    D_j(z)−D_{j+1}(z)=∫_{R_j} c_w(z)R_w^{-n}dw.       (1)

At j=0 and s=1+√n, T=εq_-s³/(64C⁴), θ=1/4, the first surviving set E_1 is exactly the R350 concentrated receiver set. Subsequent rounds use the same f and the same receiver cubes; only the set contributing to occupancy decreases.

The theorem is

    θ X_q(E\E_∞)
       ≤∫[Ψ_z(D_E(z))−Ψ_z(D_{E_∞}(z))]dz
       ≤sW+TC⁴ X_q/(q_-s³),                           (2)

where X_q(A)=∫_A q_w dw and the nonnegative source potential is

    Ψ_z(d)=f(z)min(d,s)+min(f(z),T)(d−s)_+,   d≥0.     (3)

C is the already audited dimension-independent fixed L^{4/3} centered-cube maximal constant. Thus for T=βθq_-s³/C⁴,

    G_late[g_ex]≤G_core+βX_q+(s/θ)W,
    G_core=∫_{E_∞}κ(w)dw.                             (4)

All original traffic gates remain present in G_core. It is not a fresh traffic problem with source e_∞f.

## 2. Exact source potential decrement

Fix z and write f=f(z). For x≥y≥0 define

    e(x)=1_{x>s}(1−T/f)_+

with the zero convention at f=0. The function Ψ_z is continuous, increasing and piecewise linear, with slopes f below s and min(f,T) above s. Its slope is nonincreasing. Consequently

    f(x−y)(1−e(x))≤Ψ_z(x)−Ψ_z(y).                    (5)

For x≤s this is equality. For x>s and y≥s it is also equality. If y<s<x, the right side equals

    min(f,T)(x−s)+f(s−y)
       ≥min(f,T)(x−y),

which is the left side. This proves (5), including x=s and f=0. It is a positive, explicitly priced potential decrement; no variance or unproved negative credit is invoked.

Every removed w satisfies 1−p_{E_j}(w)≥θ. Tonelli and (1) give

    θ X_q(R_j)
       ≤∫_{R_j}q_w(1−p_{E_j}(w))dw
       =∫f(z)(1−e_j(z))(D_j(z)−D_{j+1}(z))dz
       ≤∫[Ψ_z(D_j(z))−Ψ_z(D_{j+1}(z))]dz.            (6)

The equality uses q_w/m_w=R_w^{-n}; it is the same real posterior and actual receiver measure as in the original field. It is not an estimate by a boundary volume or an independently chosen source distribution.

Summing (6) from j=0 to N−1 telescopes exactly:

    θ X_q(E\E_N)≤∫[Ψ_z(D_0)−Ψ_z(D_N)]dz.             (7)

Because E_j decreases, monotone continuity of the actual capture integral gives D_j↓D_∞=D_{E_∞} pointwise, after choosing harmless null-set versions. Ψ_z is continuous. The integrand in (7) increases to its limit and is nonnegative. Monotone convergence proves the first inequality of (2), without a number-of-rounds loss.

This is the shared-source saving. After a source's occupancy has dropped to at most s, all later deleted receiver occupancy at that source sums to at most s. Before that crossing it is charged only at slope min(f,T). Equation (3) records both parts in one potential, and the terminal potential is retained in (2).

## 3. Full cost, using the audited geometric adjoint moment

For D_0=D_E, the fixed-exponent adjoint estimate on the actual averaging operator gives

    ∫D_0^4 dz≤C⁴|E|≤C⁴X_q/q_-.                      (8)

As in R350, D_0=T_R^*1_E. No moment of f is assumed. From (3),

    ∫Ψ_z(D_0)dz
       ≤sW+T∫(D_0−s)_+ dz
       ≤sW+T s^{-3}∫D_0^4 dz
       ≤sW+TC⁴X_q/(q_-s³).                           (9)

Equations (7)–(9) prove (2). Since κ≤q_w, the mass of all removed original marked traffic is at most X_q(E\E_∞); this proves (4). More precisely the available traffic bound retains the terminal potential:

    G_late−G_core
       ≤(1/θ)∫[Ψ_z(D_E)−Ψ_z(D_{E_∞})]dz.             (10)

The source cost is full W. The fixed field has not been rebuilt from g_ex or from a new source subset. Nothing in the proof creates an extra copy of the original R344 clipping fee.

A version starting at any fixed measurable E_0⊂E has exactly the same proof with its D_0 and ∫D_0^4≤C⁴|E_0|. For the main application it is better to start at E itself, so the R350 first deletion and every later deletion share one budget.

## 4. Honest limiting concentration guard

The strict high-occupancy indicator requires care. We have

    e_j(z)↓e_*(z):=lim_j 1_{D_j(z)>s}(1−T/f(z))_+,
    0≤e_*≤1_{D_∞≥s}(1−T/f)_+.                        (11)

The limit need not equal 1_{D_∞>s}(1−T/f)_+: occupancy can decrease to s from above. For every w∈E_∞, all finite tests satisfy p_{E_j}(w)>1−θ; bounded convergence under the actual posterior gives only

    π_w(e_*)≥1−θ,
    π_w[1_{D_{E_∞}≥s}(1−T/f)_+]≥1−θ.                (12)

Both the closed occupancy gate and the non-strict posterior inequality in (12) are intentional. We do not claim E_∞ is a strict-threshold fixed point. It is a receiver core whose members satisfy the stated closed concentration test using their own occupancy.

For θ=1/4, let S_∞={D_{E_∞}≥s, f>2T}. On its complement the final weight in (12) is at most 1/2, and everywhere at most one. Thus

    π_w(S_∞)≥1/2  for every retained w,                (13)

up to the standard receiver null sets. This is non-strict; the first-round R350 conclusion was strict. Unlike the original concentration condition based on D_E, the high occupancy here must be supplied by the surviving core itself.

Equations (12)–(13) are necessary properties of the actual remaining flow, not a proof that it is empty. Large-density sources can still be repeatedly captured by this core. A general root budget for G_core is not established. The new proved payment is the entire, possibly arbitrarily long cascade R_0∪R_1∪⋯ with a single source fee.

## 5. Exact R350 parameter choice and replacement ledger

Use

    s=1+√n,  θ=1/4,  β=ε/16,
    T=βθq_-s³/C⁴=εq_-(1+√n)³/(64C⁴).

Then (4) becomes

    G_late[g_ex]≤G_core+(ε/16)X_q+4(1+√n)W.          (14)

This replaces the R350 one-round inequality at exactly the same cost; it is not added on top of it. In particular, if C_top=1+√n+log(4/3), C_hit=2λB[1+log(1/ε)] and all old constants retain their archived meanings,

    B_H≤G_core+[(13/3)ε+γ_eff+ε/16]X_q
        +[C_{ε,n}+4(1+√n)]W
        +(C_top+C_hit)W_ex.                           (15)

Entrance and external multipliers are unchanged. Relative to the already recorded R350 ledger, this note adds zero new X_q fee and zero new W fee; it replaces G_conc by the smaller G_core. No claim is made that this shrinkage has a uniform positive size for every input.

The old global task still includes all other archived unpriced terms. Only the present marked late-flow slot is improved here.

## 6. Executed reproducible exact diagnostics

The following Python code was actually run using fractions.Fraction. It passed 270 potential inequalities, and a finite incidence cascade that deletes two receiver rows in each of three rounds. That cascade has removed q-mass 9, accumulated source defect 99/20, and initial potential 27/4. It tests the telescoping and threshold mechanics with exact arithmetic. It is not represented as a centered-cube realization or as a test of the original high-past gate; those geometric facts enter the proof through the actual identities (1), (6), and the audited moment (8).

```python
from fractions import Fraction as F
from itertools import product
count=0
for f,T,s,x,y in product(
    [F(1,2),F(1),F(3)], [F(1,10),F(1),F(4)],
    [F(1,2),F(1),F(2)],
    [F(0),F(1,4),F(1),F(3)], [F(0),F(1,4),F(1),F(3)]):
 if y>x: continue
 def phi(d): return f*min(d,s)+min(f,T)*max(d-s,0)
 e=(max(1-T/f,0) if x>s else 0)
 assert f*(x-y)*(1-e)<=phi(x)-phi(y)
 count+=1
N=7; supports=[{j,j+1} for j in range(N-1)]
f=[F(1)]*N; mass=[F(2)]*(N-1)
receiverweight=[F(3,2)]*(N-1)
s=F(1); T=F(1,10); theta=F(1,4)
active=set(range(N-1)); removed=[]; defect=F(0)
def occ(A):
 return [sum(receiverweight[j]/mass[j] for j in A if i in supports[j])
         for i in range(N)]
def potential(D):
 return sum(f[i]*min(D[i],s)+min(f[i],T)*max(D[i]-s,0)
            for i in range(N))
D0=occ(active)
while active:
 D=occ(active)
 e=[max(1-T/f[i],0) if D[i]>s else F(0) for i in range(N)]
 p={j:sum(f[i]*e[i] for i in supports[j])/mass[j] for j in active}
 dead={j for j in active if p[j]<=1-theta}
 if not dead: break
 new=active-dead; Dnew=occ(new)
 d=sum(f[i]*(D[i]-Dnew[i])*(1-e[i]) for i in range(N))
 assert theta*sum(receiverweight[j] for j in dead)<=d
 assert d<=potential(D)-potential(Dnew)
 defect+=d; removed.append(len(dead)); active=new
assert removed==[2,2,2] and not active
assert defect<=potential(D0)
print('PASS',count,'exact potential inequalities; cascade',removed,
      'removed qmass',sum(receiverweight),'defect',defect,
      'initial potential',potential(D0))
```

Only /tmp/r351_geometry.md was authored. The theorem pays shared-source peeling without per-round fees; it does not prove a general bound for the final self-supported concentration core.
