# R390 — A genuine incoming-column receipt for the current middle-rank flow

**Result.** The actual R389 kernel has a dimension-independent incoming column bound, including the first crossing mass atom. This pays a new positive portion of the **current** G_order using the full-source witness at the small endpoint. The remaining incoming endpoints have a quantitative full-f high-rank posterior. There is no new X_q fee, no repeated use of an old negative square, and no claim of a global closure or a history-preserving multi-step process.

## 1. The exact current kernel, not a rebuilt flow

Freeze full f, actual Lebesgue receivers E, selected cubes and matched masses

m_u=∫f c_u=q_uR_u^n,   q_-≤q_u≤λ,   a≤R_u≤b≤2a,
μ(du)=du/m_u,   π_u(dy)=f(y)c_u(y)dy/m_u,
T_u(y)=∫_E c_w(y)1_{m_w≤m_u}μ(dw).

Use the original h,H, physical clock ell including its b atom, and every existing spatial, source, target, fractional and history mark. Let χ(y,u,v) be the exact R389 clock-averaged mark, including (1−m_v/m_u) and T_u/max(J,T_u). Explicitly it is the average of the old positive mark times those factors against the original probability R_u^n ell|_[R_u,b]. Thus 0≤χ≤1 and

K(u,dv)=μ(dv)∫π_u(dy)c_v(y)χ(y,u,v)/T_u(y),
G_order=∫_E q_u(K1)(u)du.                                    (1)

This is the actual retained cost equality, not the larger mass-prefix domination. Zero ranks give zero contributions. In addition to strict far mass m_u>K_0m_v, K_0=exp(√n), the current mark retains

α<T_v(y)/T_u(y)<β,
α=τ/2,   β=(1+d)^−1,   T_v(y)>2h,                            (2)

with exactly the already fixed R387 d,τ. Assume 0<α<β<1; if this interval is empty, the corresponding flow is zero. The source quantity K_0 is distinct from the operator K.

Put dσ(u)=q_u du and X_q=σ(E). The actual incoming density relative to σ is

κ(v)=(K†1)(v)
=∫π_v(dy)∫_E [q_u/q_v] c_u(y)χ(y,u,v)μ(du)/T_u(y).            (3)

Consequently ∫κ dσ=G_order exactly. Formula (3) follows by positive Tonelli from (1) with the same full-f matching; it is not a reversibility assertion.

## 2. Sharp universal atomic strip bound

For a fixed source y, let ρ_y(du)=c_u(y)μ(du), and let T be its inclusive mass CDF. Fix an exit v with c=T_v(y)>0. Any permitted u has m_u>m_v, hence its complete mass-rank interval lies above c. The middle gate says

A<T_u(y)<B,   A=c/β,   B=c/α.

Under generalized-inverse ranks s, each such atom or non-atomic point has endpoint T_u≥max(A,s), with s∈(c,B). Therefore

∫ρ_y(du) 1_{m_u>m_v}1_{α<T_v/T_u<β}/T_u
≤∫_c^B ds/max(A,s)
=1−β+log(β/α)=:C_rank.                                      (4)

This proof includes mass atoms and singular continuous distributions. The part of a first atom lying below A is charged at its inclusive endpoint, not discarded. Its possible contribution is precisely accounted for by 1−β. A bare log(β/α) bound would in general omit this crossing contribution. Strict endpoint gates can only reduce (4). The set c=0 is absent from the actual current support T_v>2h; if needed its marked contribution is zero.

Using q_u/q_v≤λ/q_- and the true probability π_v in (3) yields

0≤κ(v)≤C_col,
C_col=(λ/q_-)[1−β+log(β/α)]                                  (5)

for σ-almost every v. This proves a real incoming-column capacity relative to q_v dv. There is no factor J_b(y), no integration over n mass bands, and no replacement of the original source measure by volume.

A useful optional geometric refinement: each actual mass atom satisfies

ρ_y{u:m_u=t}≤1/q_-.

Indeed capture and m_u=t imply 2||u−y||∞≤(t/q_-)^(1/n), while the density of ρ_y on that atom is exactly 1/t. Integrating this center envelope in real du proves the claim. Only the first atom crossing A can contribute ranks below A in (4); its contribution there is bounded both by 1−β and by (1/q_-)/A. Hence the sourcewise bound can be sharpened to

log(β/α)+min(1−β, β/(q_-T_v)).

On the current support T_v>2h it is at most log(β/α)+min(1−β,β/(2q_-h)). The main receipt below uses the simpler constant C_col in (5); these are alternative constants, not separate payments. The refinement is a bound on receiver-center mass atoms, not on the density of f.

## 3. A new soft incoming payment on this same G_order

Use the full-source R388 witness at the actual small endpoint,

F_v=∫π_v(dz) h/[h+T_v(z)]∈[0,1],
S_F=∫_E q_vF_v dv.

The variable z here is integrated only to define a certificate from the full source captured by v. The original transported source y and all original labels in (1) remain unchanged.

Fix 0<t≤1. Multiply each original current edge ending at v by

p_in(v)=min(1,F_v/t).

Let P_in be the paid actual cost and G_cold the complementary actual cost. Then exactly

G_order=P_in+G_cold,
P_in=∫κ(v)min(1,F_v/t)dσ(v),
G_cold=∫κ(v)(1−F_v/t)_+dσ(v),                               (6)

where the latter is also the cost of the original fully marked measure multiplied by (1−F_v/t)_+. The current incoming density κ is computed from (1); it is not an old pre-window or pre-clock density.

By (5),

P_in≤(C_col/t)S_F
≤(C_col/t)λh∫f(y)log(1+J_b(y)/h)dy
≤(C_col/t)λh log(1+J_max/h)W.                                (7)

The second inequality is the established full-f source-exact Stieltjes receipt for F. It is used here for an additional, explicitly priced positive branch. If that witness already paid earlier outgoing traffic in R388, the price (7) is still a new fee for the present distinct remainder; it is not a free second deduction of that earlier price.

All incoming traffic with F_v≥t is cleared completely. Moreover every incoming endpoint with 0<F_v<t pays the positive fraction F_v/t. Thus (6) is at least as strong as the hard high-F endpoint split, with the same displayed source upper bound, and has a smaller exact remaining cost. No uniform positive fraction of all G_order is asserted.

## 4. What the retained small endpoint now satisfies

Positive incoming G_cold at v implies F_v<t. For every s≥0,

π_v{z:T_v(z)≤s h}≤(1+s)F_v<(1+s)t.                           (8)

For t≤1/2, choosing s=1/(2t)−1 gives the concrete full-source statement

f({z∈Q_v:T_v(z)>h[1/(2t)−1]})>m_v/2.                         (9)

For example t=1/4 clears the incoming branch at price 4C_col S_F and leaves endpoints for which more than half of their entire f mass has T_v(z)>h. The stronger general threshold in (9) is retained when t is smaller. This is a statement about all full-f witness sources of v, not just the original traffic source y.

The present edge still has all old current-source conditions, including α<T_v(y)/T_u(y)<β, strict far mass and past, original geometry and original history. Equations (8)–(9) do not assert that v has a large outgoing original row, that its next target plan passes the old tests, or that the original source y may be replaced freely by a new witness z. They therefore do not license a new history step. They supply the promised quantitative common-source endpoint constraint while paying the complementary incoming branch.

For a purely auxiliary frozen-field process, (5) also says that an injection with density at most A relative to σ has next incoming density at most A C_col. This quantifies possible resampling crowding; repeated applications would carry the corresponding factors and require their own source/terminal budget. No such repeated price or process is used in (6)–(7).

## 5. Full incremental ledger and parameter dependence

If the entering same-field ledger is

BH≤G_order+E_389 X_q+S_389,

then the valid update is

BH≤G_cold+E_389 X_q+S_389
 +(C_col/t)λh log(1+J_max/h)W.                               (10)

There is no additional X_q coefficient, target-cap multiplier, plan replacement, or negative-square credit. The full original outer factor 2Λ applies to the new price in (10). All old source prices remain, including the original R388 witness payment and R389 clock-ordering price; no old flow is silently substituted for the current one.

With the original synchronized h=(1+√n)/(ε_0q_-) and J_max=A_n/q_-, the added price is exactly

[C_col λ(1+√n)/(t ε_0q_-)]
 log[1+ε_0 A_n/(1+√n)] W,

C_col=(λ/q_-)[1−1/(1+d)+log(2/[τ(1+d)])].                    (11)

Thus for fixed old absorption parameters and fixed t this is a root-order source fee with the displayed logarithm and all q,ε_0,d,τ,t dependencies. It is a new paid incoming branch, not a proof that the remaining G_cold has a root budget. No source-density cap or finite-band summation has been inserted.

## 6. Actual local verification and its limits

`/tmp/r390_aux_check.py` was executed with Python Fraction arithmetic and certified rational lower bounds for the positive logarithms:

`PASS {'atomic_column': 7776, 'matched_incoming': 16, 'soft_receipt': 216, 'native_atom': 387} total 8395 positive_atomic_columns 1114 positive_incoming 6 strict_soft_cases 30`

The first stage checks (4), its first-crossing correction and the optional capped-atom improvement on 1,114 nonempty atomic columns. The matched tests use actual interval/source incidences, exact full-f matching and variable q in the specified band. They verify both current marginals, the true qdu incoming bound, the exact positive split (6), its fee, and the endpoint posterior claim. Receiver integration in that stage is finite positive quadrature, not a native continuum receiver field or a realization of all historical gates. There are six positive incoming configurations and thirty cases where the soft payment is strictly greater than the hard endpoint payment.

The final stage uses genuine one-dimensional Lebesgue receiver intervals and fixed-radius/mass atoms to verify the center-capacity mechanism directly. These finite checks are algebra and geometric diagnostics; the proofs above cover real du, general mass atoms and the unchanged full physical-clock representation. No sampled model is used to claim coverage of all G_cold.
