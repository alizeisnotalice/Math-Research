from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from itertools import product

def dec(x):
    x=F(x)
    return D(x.numerator)/D(x.denominator)

def witness(l,a,h):
    if not a: return h/(h+l)
    return h/a*((h+l+a)/(h+l)).ln()

counts={'partial_atom_pair':0,'local_derivative':0,'endpoint_difference':0}
cases=list(product(range(3),repeat=4))
cases += [(0,0,3,2),(2,3,0,0),(1,3,2,1)]
with localcontext() as ctx:
    ctx.prec=60
    for b0,b1,r0,r1 in cases:
        bs=list(map(F,(b0,b1))); rs=list(map(F,(r0,r1)))
        h=F(3,2); s=F(2,5); t=F(3,7)
        l=F(0); rl=F(0)
        pair=F(0); direct=F(0)
        deriv=D(0)
        for j,(b,r) in enumerate(zip(bs,rs)):
            a=b+s*r
            num=rl+t*r
            den=h+l+t*a
            direct += b*h*num/den**2
            pair += sum((b*rs[i]*h*((1 if i<j else t) if i<=j else 0)/den**2 for i in range(2)),F(0))
            L,A,H,R,RL=map(dec,(l,a,h,r,rl))
            w=witness(L,A,H)
            if a:
                dw=H*(-R/A**2*((H+L+A)/(H+L)).ln() + ((RL+R)/(H+L+A)-RL/(H+L))/A)
            else:
                # a=0 at interior s forces both b=r=0; term a*dw is zero.
                dw=D(0)
            deriv += R*w+A*dw
            l+=a; rl+=r
        assert direct==pair
        counts['partial_atom_pair']+=1
        exact=dec(h*sum(rs)/(h+sum(bs)+s*sum(rs)))
        assert abs(deriv-exact)<D('1e-55')
        counts['local_derivative']+=1
        la=lb=F(0); rem=D(0); premium=D(0)
        for b,r in zip(bs,rs):
            wa=witness(dec(la),dec(b+r),dec(h))
            wb=witness(dec(lb),dec(b),dec(h))
            rem+=dec(r)*wa
            premium+=dec(b)*(wb-wa)
            la+=b+r; lb+=b
        drop=dec(h)*((dec(h+la))/(dec(h+lb))).ln()
        assert premium>=-D('1e-55')
        assert abs(rem-drop-premium)<D('1e-55')
        counts['endpoint_difference']+=1
print('PASS',counts,'total',sum(counts.values()))
