% Finite edge-cascade diagnostic using real interval posterior incidences.
% Equal masses => original strict-far flow is empty: diagnostic edge weights only.
r391_results=[];
for r391_N=[8,16,32,64]
 r391_active=true(1,r391_N); r391_prev=0; r391_total=0; r391_round=0;
 r391_s=7/4; r391_T=1/2; r391_theta=1/2;
 while true
  r391_edges=r391_active(1:end-1)&r391_active(2:end);
  r391_deg=[r391_edges,0]+[0,r391_edges];
  r391_D=([r391_deg,0]+[0,r391_deg])/2;
  r391_phi=sum(min(r391_D,r391_s)+0.1*max(r391_D-r391_s,0));
  if r391_round==0, r391_init=r391_phi; end
  r391_e=0.9*(r391_D>r391_s);
  r391_p=(r391_e(1:end-1)+r391_e(2:end))/2;
  r391_remove=r391_active & (r391_p<=1-r391_theta);
  if ~any(r391_remove), break; end
  r391_new=r391_active & ~r391_remove;
  r391_newedges=r391_new(1:end-1)&r391_new(2:end);
  r391_loss=sum(r391_edges)-sum(r391_newedges);
  r391_newdeg=[r391_newedges,0]+[0,r391_newedges];
  r391_Dnew=([r391_newdeg,0]+[0,r391_newdeg])/2;
  r391_phinew=sum(min(r391_Dnew,r391_s)+0.1*max(r391_Dnew-r391_s,0));
  r391_defect=sum((1-r391_e).*(r391_D-r391_Dnew));
  assert(r391_theta*r391_loss<=r391_defect+1e-12);
  assert(r391_defect<=r391_phi-r391_phinew+1e-12);
  assert(abs(sum(r391_D-r391_Dnew)-2*r391_loss)<1e-12);
  r391_total=r391_total+r391_loss; r391_round=r391_round+1;
  r391_active=r391_new;
 end
 assert(r391_total==r391_N-1);
 assert(r391_theta*r391_total<=r391_init-r391_phi+1e-12);
 r391_results(end+1,:)=[r391_N,r391_round,r391_total,r391_init,r391_phi];
end
disp('N, rounds, removed edge cost, initial potential, terminal potential');disp(r391_results);
