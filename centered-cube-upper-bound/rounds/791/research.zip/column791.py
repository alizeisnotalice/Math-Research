"""R791 exact conditional owner projection, Gram trace, and lens moment certificates."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform
import sys

import flint
from flint import arb, fmpq, ctx

import common791 as geom


ctx.prec = 256
ETA, AMP = F(3, 4), F(1, 2)


def ar(x):
    z = F(x)
    return arb(fmpq(z.numerator, z.denominator))


def total(xs):
    return sum(xs, F(0))


def prod(xs):
    v = F(1)
    for x in xs:
        v *= x
    return v


def source_representatives(parents, n):
    # All parent memberships are constant on these genuine open price cells.
    x = sorted({-F(4), F(4)} | {p.c + sign*p.s for p in parents for sign in (-1, 1)})
    r = sorted({F(0), F(4)} | {p.s for p in parents})
    points = {}
    for (lo, hi), (a, b) in product(zip(x,x[1:]), zip(r,r[1:])):
        member = tuple(i for i,p in enumerate(parents)
                       if p.c-p.s <= lo < hi <= p.c+p.s and b <= p.s)
        point = ((lo+hi)/2, (a+b)/2) + (F(0),)*(n-2)
        points.setdefault(member, point)
    return points


def raw_labels(parents, J, degree):
    down = {}
    for v,p in enumerate(parents):
        down[v] = {i:parents[i].owner * J[v,i] / (p.m*parents[i].m)
                   for i in range(len(parents)) if parents[i].m < p.m
                   and 0 < J[v,i] <= ETA*parents[i].m}
        assert total(down[v].values()) <= degree[v]
    return down


def gram_case(parents, J, degree, records, p):
    H, rho = defaultdict(F), defaultdict(F)
    for i,j,v,mass in records:
        H[i,j] += mass*parents[v].m
        rho[i,j] += mass
    G = defaultdict(F)
    c = {v:par.m*par.owner/degree[v] for v,par in enumerate(parents) if p[v]}
    for v, coeff in c.items():
        for (i, u), (j, w) in product(p[v].items(), repeat=2):
            G[i,j] += coeff*u*w
    assert all(0 <= H.get(pair,0) <= amount for pair,amount in G.items())
    assert H.keys() <= G.keys()
    trace = total(val/parents[i].owner for (i,j),val in G.items() if i == j)
    prod_trace = total(c[v]*total(w*w/parents[i].owner for i,w in terms.items())
                       for v,terms in p.items() if v in c)
    eta_budget = ETA*total(parents[v].owner*total(p[v].values())/degree[v] for v in c)
    assert trace == prod_trace <= eta_budget
    rho_near = {}
    for (i,j), w in rho.items():
        assert rho[j,i] == w
        if J[i,j] > 0 and max(parents[i].m,parents[j].m) <= 2 * min(parents[i].m,parents[j].m):
            rho_near[i,j] = w
    assert 0 < len(rho_near) < len(rho)

    def collision(rho_used):
        left, right = defaultdict(F), defaultdict(F)
        for (i,j), mass in rho_used.items():
            left[i] += mass
            right[j] += mass
        assert left == right
        terms = [(i,j,ar(mass)/ar(parents[i].owner*parents[j].owner*left[i]*right[j]).sqrt())
                 for (i,j),mass in rho_used.items()]
        true = sum(ar(H[i,j])*f for i,j,f in terms)
        lifted = sum(ar(G[i,j])*f for i,j,f in terms)
        # Per-middle Gram vector: a_i b_j <= (a_i^2+b_j^2)/2.
        by_edge = total(
            coeff * total(mass * ((p[v].get(i,0)**2/(parents[i].owner*left[i])) +
                                  (p[v].get(j,0)**2/(parents[j].owner*right[j]))) / 2
                          for (i,j),mass in rho_used.items()) for v,coeff in c.items()
        )
        by_marginal = total(
            coeff * total(w*w / parents[i].owner * (int(i in left)+int(i in right)) / 2
                          for i,w in p[v].items()) for v,coeff in c.items()
        )
        assert by_edge == by_marginal <= trace
        assert 0 < true < lifted < ar(by_marginal)
        return dict(positive_edges=len(rho_used), actual_rho_sum=total(rho_used.values()),
                    row_masses=dict(left), column_masses=dict(right),
                    true_weighted_collision_Arb=true, lifted_G_before_trace_Arb=lifted,
                    rational_am_gm_certificate=by_marginal,
                    true_over_normalized_G_trace_Arb=true/ar(trace))

    return dict(entrywise_pairs_checked=len(G),
                strict_H_less_than_G_pairs=sum(H.get(pair,0) < amount for pair,amount in G.items()),
                actual_H_total=total(H.values()), gram_upper_total=total(G.values()),
                normalized_Gram_trace=trace, eta_times_true_down_over_full_owner_budget=eta_budget,
                normalized_trace_over_budget=trace/eta_budget,
                full_original_graph=collision(rho),
                near_true_positive_intersection_and_size_ratio_le_2=collision(rho_near))


def contains_source(par, y):
    return abs(y[0]-par.c) <= par.s and all(abs(t) <= par.s for t in y[1:])


def contained_box(center, radius, middle, owner):
    p0 = middle.c
    return abs(center[0]-p0)+owner <= radius and all(abs(t)+owner <= radius for t in center[1:])


def overlap_box(a, r, b, s):
    return prod(max(F(0), min(x+r,y+s)-max(x-r,y-s)) for x,y in zip(a,b))


def projection_case(n, parents, cells, J, B, down, floor):
    # Model density relative to the original left arm alpha and true Lebesgue w.
    a0 = 32*n
    h = 1 + F(1,a0)
    label_bin = [floor(x.m) for x in parents]
    R = {d:max(p.s for i,p in enumerate(parents) if label_bin[i] == d) for d in set(label_bin)}
    points = source_representatives(parents,n)
    down_support = {i for dd in down.values() for i in dd}
    right_cells = {g:[] for g in down_support}
    left = defaultdict(F)
    reps = {}
    for S,mass in sorted(cells.items()):
        for u in S:
            vtuple = tuple(v for v in S if u in down[v])
            if not vtuple:
                continue
            mark = (u,vtuple)
            left[mark] += parents[u].keep*parents[u].owner*mass/parents[u].m
            reps.setdefault(mark,points[S])
            if u in right_cells:
                right_cells[u].append((vtuple,mass))
    # At fixed g right price integrates its own admissibility, old keep and two-arm screen.
    mass_check = defaultdict(F)
    candidates = {}
    for (u, possible), alpha in sorted(left.items()):
        for g, family in right_cells.items():
            by_bin = defaultdict(F)
            dropped = defaultdict(F)
            for v in possible:
                if g not in down[v]:
                    continue
                d = label_bin[v]
                with_v = [(eligible,mass) for eligible,mass in family if v in eligible]
                assert total(w for _,w in with_v) == J[v,g]
                quiet = total(weight * F((u+g+v+len(possible)*len(eligible))%5,4)
                              for eligible,weight in with_v)
                factor = parents[v].owner/parents[v].m * parents[g].keep/parents[g].m
                by_bin[d] += factor*quiet
                dropped[d] += factor*J[v,g]
            for d, true in by_bin.items():
                assert 0 <= true <= dropped[d]
                mass_check[u,g] += true * alpha * parents[g].owner
                if true:
                    key = d,label_bin[g],g
                    if key not in candidates or true > candidates[key][0]:
                        candidates[key] = (true,dropped[d],u,possible,reps[u,possible])
    assert B.keys() <= mass_check.keys()
    assert all(mass == B.get(pair,0)*parents[pair[0]].m*parents[pair[1]].m
               for pair,mass in mass_check.items())
    assert {g for d,G,g in candidates} == down_support
    all_probes = 0
    best = None
    count_strict = 0
    samples = []
    max_cost_ratio = F(0)
    for (d,G,g),(real,ungated,u,possible,y) in sorted(candidates.items()):
        s,t = h*R[d],h*R[G]
        D = F(2)**d
        assert (2*s)**n / D <= 2*h**n
        eligible = [v for v,p in enumerate(parents) if label_bin[v] == d
                    and contains_source(p,y) and J[v,g]>0]
        upper = ETA*total(parents[v].owner/parents[v].m for v in eligible)
        assert real <= ungated <= upper
        g0 = parents[g]
        for offset in (F(-1,2),F(0),F(1,2)):
            w = (g0.c + offset*g0.s/a0,) + (F(0),)*(n-1)
            assert all(abs(t)<g0.s/a0 for t in (w[0]-g0.c,)+w[1:])
            for v in eligible:
                E_v_r = parents[v].s/a0
                assert contained_box(y,s,parents[v],E_v_r)
                assert contained_box(w,s+t,parents[v],E_v_r)
            body = overlap_box(y,s,w,s+t)
            psi = prod(max(F(0),1-max(F(0),abs(z-x)-t)/(2*s)) for z,x in zip(y,w))
            assert body == (2*s)**n * psi
            assert total(parents[v].owner for v in eligible) <= body
            cap = ETA*body/D
            assert 0 < real <= ungated <= upper <= cap <= 2*h**n*ETA*psi
            ratio = real/cap
            max_cost_ratio = max(max_cost_ratio,ratio)
            if psi < 1 and real < ungated:
                count_strict += 1
                witness = (psi, d,G,g,u,possible,y,w,real,ungated,upper,cap,ratio)
                if best is None or (psi, d,G,g) < best[:4]:
                    best = witness
            if offset == 0:
                samples.append((d,G,g,psi,real,ungated,cap))
            all_probes += 1
    assert best and count_strict > 0
    return dict(
        distinct_actual_volume_pairs=sorted({(d,G) for d,G,g in candidates}),
        right_small_parents_tested=sorted(down_support),
        original_projection_aggregate_weight=total(mass_check.values()),
        independent_original_projection_closed_out_agrees=True,
        fixed_source_types_and_true_right_owner_choices=len(candidates),
        interior_w_probes=all_probes, sides_of_w_sampling=[F(-1,2),F(0),F(1,2)],
        nontrivial_psi_and_strict_screen_probes=count_strict,
        max_true_density_over_actual_geometric_cap=max_cost_ratio,
        actual_middle_probe_rows_with_dG_g_psi_true_ungated_cap=samples,
        witness_keys_psi_dG_g_u_possible_y_w_real_ungated_upper_cap_ratio=best)


def ceil_exact(q):
    return -(-q.numerator//q.denominator)


def moment_case(n,L):
    q = ceil_exact(F(16*n)/L)
    p = F(q+1,2)
    ratio = (ar(-L)/n + arb(2).log()/n).exp()
    term = ratio + 2/ar(p+1)
    direct_log = arb(n)*term.log()
    # Independently integrate one ramp using its three actual affine pieces.
    intervals = [F(0),F(1,4),F(3,4),F(1)]

    def power(x):
        if x==0:
            return arb(0)
        return (ar(x).log()*ar(p+1)).exp()

    one_ramp = sum((power(1-a)-power(1-b))/ar(p+1) for a,b in zip(intervals,intervals[1:]))
    # Each side contributes one_ramp in units 2s. Joint law factors by coordinates.
    from_integral = arb(n)*(ratio+2*one_ramp).log()
    assert from_integral.overlaps(direct_log)
    assert direct_log < -ar(L/2)
    return dict(n=n,L=L,L_over_n=L/n,q=q,p=p,t_over_s_Arb=ratio,
                log_normalized_Psi_moment_Arb=direct_log,
                log_volume_moment_over_L_Arb=direct_log/ar(L),
                checked_strictly_below_exp_minus_L_over_2=True)


def case(n, stage, merges):
    parents = merges.instances(n,stage)
    cells, _ = geom.cells_on_box(n,parents,AMP)
    J,d,records,B,_ = geom.marks_and_coefficients(n,parents,cells,AMP)
    down = raw_labels(parents,J,d)
    return dict(n=n,real_parents=len(parents),actual_two_arm_records=len(records),
                phase_amplitude=AMP,hard_eta=ETA,
                unweighted_original_R=total(r[3] for r in records),
                projection=projection_case(n,parents,cells,J,B,down,merges.floor_log2),
                gram=gram_case(parents,J,d,records,down))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--geometry-dir",type=Path)
    out = p.add_mutually_exclusive_group()
    out.add_argument("--output",type=Path)
    out.add_argument("--check",type=Path)
    args = p.parse_args()
    if args.geometry_dir:
        sys.path.insert(0,str(args.geometry_dir))
    import merges789 as merges
    data = dict(
        python={"executable":sys.executable,"version":platform.python_version(),
                "machine":platform.machine(),"python_flint":flint.__version__},
        arithmetic="Fraction exact and 256-bit Arb outward intervals",
        command="python -B column791.py --check column791.json",
        dependencies={name:sha256(Path(module.__file__).read_bytes()).hexdigest()
                      for name,module in (("common791.py",geom),("merges789.py",merges))},
        scope=("R791 true finite phase-cube records, all real down arms and full old d. "
               "Owner density is relative to actual left alpha and Lebesgue on E_g. "
               "For each positive D,G,g, test a true left price type and three actual "
               "interior w in the physical E_g. Use h times each actual maximal radius "
               "in the dyadic bin as the exact rational t_D and t_G. "
               "The larger theoretical half-widths and high-dimensional proof assumptions "
               "are modeled only by the separately specified lens integral parameters."),
        cases=[case(n,s,merges) for s,n in enumerate((4,8,16),1)],
        whole_space_Psi_moments=[
            moment_case(64,F(64,5)),moment_case(4096,F(128)),
            moment_case(2**20,F(512))])
    result=(json.dumps(data,sort_keys=True,indent=2,default=str)+"\n").encode()
    if args.output:
        args.output.write_bytes(result)
    elif args.check:
        if args.check.read_bytes()!=result:
            raise SystemExit("certificate differs")
        print("column791: true owner projection, normalized Gram trace and lens moments agree")
    else:
        print(result.decode(),end="")


if __name__=="__main__":
    main()

