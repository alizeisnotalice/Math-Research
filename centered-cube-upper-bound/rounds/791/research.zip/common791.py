"""R791: one common physical source coupling versus separately optimized parent pairs."""

import argparse
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform
import sys


HALF = F(1, 16)
PERIOD = 2 * HALF
PROBE_RADIUS = F(4)


def total(xs):
    return sum(xs, F(0))


def phase_primitive(x, amp):
    q = x // PERIOD
    r = x - q * PERIOD
    return q * PERIOD + r + amp * (min(r, HALF) - max(F(0), r - HALF))


def mu1(lo, hi, amp):
    return phase_primitive(hi, amp) - phase_primitive(lo, amp) if lo < hi else F(0)


def parent_overlap(n, p, r, amp):
    lo = max(p.c - p.s, r.c - r.s)
    hi = min(p.c + p.s, r.c + r.s)
    return mu1(lo, hi, amp) * (2 * min(p.s, r.s))**(n - 1)


def cells_on_box(n, parents, amp):
    # Both margins live on the same finite phase-aligned physical cube.
    R = PROBE_RADIUS
    absolute = sorted({-R, R} | {p.c + k * p.s for p in parents for k in (-1, 1)})
    shell = sorted({F(0), R} | {p.s for p in parents})
    actual, ordinary = defaultdict(F), defaultdict(F)
    for lo, hi in zip(absolute, absolute[1:]):
        for a, b in zip(shell, shell[1:]):
            covers = tuple(i for i, p in enumerate(parents)
                           if p.c - p.s <= lo < hi <= p.c + p.s and b <= p.s)
            rad = (2 * b)**(n - 1) - (2 * a)**(n - 1)
            actual[covers] += mu1(lo, hi, amp) * rad
            ordinary[covers] += (hi - lo) * rad
    assert total(actual.values()) == total(ordinary.values()) == (2 * R)**n
    for i, p in enumerate(parents):
        assert abs(p.c) + p.s < PROBE_RADIUS
        assert total(w for mark, w in actual.items() if i in mark) == p.m
        for r in (p.s, p.s / 3, p.s / (32 * n), F(1, 37)):
            assert mu1(p.c - r, p.c + r, amp) * (2 * r)**(n - 1) == (2 * r)**n
    return actual, ordinary


def marks_and_coefficients(n, parents, cells, amp):
    labels = range(len(parents))
    J = {(i, j): parent_overlap(n, parents[i], parents[j], amp)
         for i, j in product(labels, repeat=2)}
    for (i, j), overlap in J.items():
        assert total(w for group, w in cells.items() if i in group and j in group) == overlap
    K = {(v, u): mass / (parents[v].m * parents[u].m)
         for (v, u), mass in J.items() if parents[v].m != parents[u].m
         and 0 < mass <= F(3, 4) * min(parents[v].m, parents[u].m)}
    degree = {v: total(k * parents[u].owner for (i, u), k in K.items() if i == v) for v in labels}
    marks = defaultdict(F)
    for group, mass in sorted(cells.items()):
        for i in group:
            p = parents[i]
            eligible = tuple(v for v in group if (v, i) in K and p.m < parents[v].m)
            marks[i, eligible] += p.keep * p.owner * mass / p.m
    for i, p in enumerate(parents):
        assert total(w for (u, _), w in marks.items() if u == i) == p.keep * p.owner
    d_minus = {v: total(w for (_, inds), w in marks.items() if v in inds) / parents[v].m
               for v in labels}
    unfiltered = total(parents[v].owner * d_minus[v]**2 / degree[v]
                       for v in labels if d_minus[v])
    records = []
    by_original = defaultdict(F)
    total_original_models = F(0)
    for (a, pa), (b, pb) in product(marks.items(), repeat=2):
        i, j = a[0], b[0]
        for v in sorted(set(a[1]) & set(b[1])):
            h = parents[v]
            inherited_gate = F((i + j + v + len(a[1]) * len(b[1])) % 5, 4)
            base = h.owner * pa * pb / (degree[v] * h.m**2)
            total_original_models += base
            if inherited_gate:
                r = base * inherited_gate
                records.append((i, j, v, r))
                coefficient = h.m * degree[v] * r / (parents[i].m * parents[j].m)
                # Twice the actual one-arm integration; only then cancel full d_v.
                by_original[i, j] += h.owner * pa * pb * inherited_gate / (
                    h.m * parents[i].m * parents[j].m)
                assert coefficient == h.owner * pa * pb * inherited_gate / (
                    h.m * parents[i].m * parents[j].m)
    assert total_original_models == unfiltered > total(r[3] for r in records) > 0
    return J, degree, records, dict(by_original), unfiltered


@dataclass
class Edge:
    at: int
    rev: int
    capacity: F
    cost: F


def max_transport(rows, cols, reward):
    """Exact transportation and independent feasibility/complementarity certificate."""
    nr, nc = len(rows), len(cols)
    flow_required = total(rows)
    assert flow_required == total(cols) > 0
    source, sink = nr + nc, nr + nc + 1
    G = [[] for _ in range(sink + 1)]

    def add(s, t, cap, cost):
        f = Edge(t, len(G[t]), cap, cost)
        r = Edge(s, len(G[s]), F(0), -cost)
        G[s].append(f)
        G[t].append(r)
        return r

    for i, mass in enumerate(rows):
        add(source, i, mass, F(0))
    for j, mass in enumerate(cols):
        add(nr + j, sink, mass, F(0))
    residual = {(i, j): add(i, nr + j, 2 * flow_required, -reward[i][j])
                for i, j in product(range(nr), range(nc))}
    pending, augmentations = flow_required, 0
    while pending:
        dist = [None] * len(G)
        previous = [None] * len(G)
        dist[source] = F(0)
        for _ in range(len(G) - 1):
            changed = False
            for i, arcs in enumerate(G):
                if dist[i] is None:
                    continue
                for edge in arcs:
                    if edge.capacity:
                        alt = dist[i] + edge.cost
                        if dist[edge.at] is None or alt < dist[edge.at]:
                            dist[edge.at] = alt
                            previous[edge.at] = i, edge
                            changed = True
            if not changed:
                break
        assert dist[sink] is not None and dist[source] == 0
        k, path = sink, []
        followed = set()
        while k != source:
            assert k not in followed
            followed.add(k)
            i, edge = previous[k]
            path.append(edge)
            k = i
        step = min(edge.capacity for edge in path)
        assert 0 < step <= pending
        for edge in path:
            edge.capacity -= step
            G[edge.at][edge.rev].capacity += step
        pending -= step
        augmentations += 1

    transport = {(i, j): e.capacity for (i, j), e in residual.items() if e.capacity}
    assert [total(v for (i, j), v in transport.items() if i == k) for k in range(nr)] == list(rows)
    assert [total(v for (i, j), v in transport.items() if j == k) for k in range(nc)] == list(cols)

    # Construct independent dual potentials from the final affordable residual arcs.
    d = [F(0)] * (nr + nc)
    constraints = [(i, nr + j, -reward[i][j]) for i, j in residual]
    constraints += [(nr + j, i, reward[i][j]) for i, j in transport]
    for _ in range(len(d)):
        changed = False
        for i, j, c in constraints:
            if d[i] + c < d[j]:
                d[j] = d[i] + c
                changed = True
        if not changed:
            break
    assert not changed
    phi, psi = d[:nr], [-x for x in d[nr:]]
    assert all(phi[i] + psi[j] >= c for i, row in enumerate(reward) for j, c in enumerate(row))
    assert all(phi[i] + psi[j] == reward[i][j] for i, j in transport)
    value = total(amount * reward[i][j] for (i, j), amount in transport.items())
    assert value == total(x * y for x, y in zip(rows, phi)) + total(x * y for x, y in zip(cols, psi))
    return value, transport, phi, psi, augmentations


def projection(cells, labels):
    out = defaultdict(F)
    for members, mass in cells.items():
        projected = tuple(i for i in members if i in labels)
        out[projected] += mass
    return dict(sorted(out.items()))


def from_real_records(transport, X, Z, parents, rec, degree):
    reached = defaultdict(F)
    for (i, j), money in transport.items():
        for u, w in product(X[i], Z[j]):
            reached[u, w] += money
    return total(r * parents[v].m * degree[v] * reached[i, j] /
                 (parents[i].m * parents[j].m) for i, j, v, r in rec)


def source_transport(parents, left_mu, right_mu, records, degree, B, diagonal=False):
    first = projection(left_mu, {i for i, j in B})
    second = projection(right_mu, {j for i, j in B})
    X, Z = list(first), list(second)
    costs = [[total(B.get((i,j), 0) for i, j in product(x, z)) for z in Z] for x in X]
    optimum, plan, phi, psi, n_steps = max_transport(list(first.values()), list(second.values()), costs)
    assert optimum == from_real_records(plan, X, Z, parents, records, degree)
    separate = total(B[i,j] * min(parents[i].m, parents[j].m) for i,j in B)
    assert 0 < optimum < separate
    identity = None
    if diagonal:
        assert first == second
        identity = total(first[x] * costs[i][i] for i, x in enumerate(X))
        diag_plan = {(i, i): first[x] for i, x in enumerate(X)}
        assert identity == from_real_records(diag_plan, X, Z, parents, records, degree)
        assert 0 < identity <= optimum
    return dict(
        common_coupling_fee=optimum, same_true_price_diagonal_fee=identity,
        independent_each_pair_optima_sum=separate,
        common_over_independent_pair_optima_sum=optimum/separate,
        diagonal_over_independent_pair_optima_sum=identity/separate if diagonal else None,
        primal_plan=[(i, j, flow) for (i, j), flow in sorted(plan.items())],
        cell_left_marginal=list(first.items()), cell_right_marginal=list(second.items()),
        dual_left=phi, dual_right=psi, exact_primal_dual_gap=0,
        rational_augmenting_paths=n_steps)


def owner_limits(parents, rec):
    # One fixture suffices: actual owner capacities are true disjoint |E_i|.
    U, raw = defaultdict(F), defaultdict(F)
    for i, j, v, r in rec:
        raw[i, j] += r
        U[i, j] += parents[v].m * r
    left = sorted({i for i, j in U})
    right = sorted({j for i, j in U})
    # In these fixture records the two families have identical physical labels.
    assert left == right
    mass = [parents[i].owner for i in left]
    reward = [[U.get((i, j), 0) / (parents[i].owner * parents[j].owner) for j in right]
              for i in left]
    optimum, plan, phi, psi, _ = max_transport(mass, mass, reward)
    by_record = total(r * parents[v].m * plan.get((left.index(i), right.index(j)), 0)
                      / (parents[i].owner * parents[j].owner) for i, j, v, r in rec)
    assert by_record == optimum
    column_max = {j: max((U.get((i, j), 0) / parents[i].owner, i) for i in left) for j in right}
    right_only = total(amount for amount, i in column_max.values())
    reuse = total(u / parents[i].owner for (i,j),u in U.items())
    both_pair_caps = total(u * min(parents[i].owner, parents[j].owner) /
                           (parents[i].owner * parents[j].owner) for (i,j),u in U.items())
    assert optimum <= right_only <= reuse and optimum <= both_pair_caps <= reuse
    return dict(physical_labels=left, true_C_owner_masses=mass,
                p_ij_and_U_ij_by_actual_label=[(i,j,raw[i,j],v) for (i,j),v in sorted(U.items())],
                simultaneous_two_owner_marginal_fee=optimum,
                genuine_right_capacity_with_unconstrained_left_fee=right_only,
                all_pairs_reusing_each_right_capacity_fee=reuse,
                individual_two_owner_cap_per_pair_optima_sum=both_pair_caps,
                column_argmax_and_fee=[(j, i, fee) for j,(fee,i) in sorted(column_max.items())],
                simultaneous_transport_plan=[(left[i], right[j], mass) for (i,j),mass in sorted(plan.items())],
                exact_dual=[phi,psi])


def case(n, stage, geom):
    parents = geom.instances(n, stage)
    comparison = []
    actual = {}
    owner_result = None
    overlap_shift = None
    for amp in (F(0), F(1,2), F(3,4)):
        source, leb = cells_on_box(n, parents, amp)
        J, degree, records, B, base = marks_and_coefficients(n, parents, source, amp)
        actual[amp] = (J, degree)
        model = source_transport(parents, source, source, records, degree, B, diagonal=True)
        assert model["same_true_price_diagonal_fee"] == total(c*J[i,j] for (i,j),c in B.items())
        mixed = None
        if n == 8 and amp == F(1,2):
            mixed = source_transport(parents, source, leb, records, degree, B)
            owner_result = owner_limits(parents, records)
            assert (owner_result["simultaneous_two_owner_marginal_fee"] <
                    owner_result["genuine_right_capacity_with_unconstrained_left_fee"] <
                    owner_result["all_pairs_reusing_each_right_capacity_fee"])
        if amp and overlap_shift is None:
            examples = [(i,j) for i,j in B if J[i,j] != actual[F(0)][0][i,j]]
            if examples:
                i,j = min(examples)
                overlap_shift = i,j
        comparison.append(dict(amplitude=amp, full_true_degrees=degree,
                               raw_original_peak_mass_before_marking=base,
                               raw_R_mass_after_nonproduct_cut=total(r[3] for r in records),
                               actual_original_record_count=len(records),
                               B_ij_coefficients_from_old_true_record=[(i,j,c) for (i,j),c in sorted(B.items())],
                               common_mu_to_mu=model, optional_mu_to_Lebesgue=mixed))
    assert overlap_shift is not None
    i,j = overlap_shift
    overlap_record = dict(labels=[i,j], centers=[parents[i].c,parents[j].c],
                          centered_parent_masses_at_each_amplitude=[parents[i].m,parents[j].m],
                          true_pair_overlap_at_each_amplitude=[o[0][i,j] for o in actual.values()],
                          tested_inner_centered_radii=[parents[i].s/3,parents[j].s/3])
    assert any(actual[F(0)][1][v] != actual[F(3,4)][1][v] for v in range(len(parents)))
    assert any(row["common_mu_to_mu"]["same_true_price_diagonal_fee"] <
               row["common_mu_to_mu"]["common_coupling_fee"] for row in comparison)
    return dict(n=n, parent_count=len(parents),
                actual_parent_center_radius_m_owner_markkeep=[
                    (p.c,p.s,p.m,p.owner,p.keep) for p in parents],
                equal_centered_profiles_but_real_pair_overlap_changes=overlap_record,
                cases_by_amplitude=comparison, actual_owner_column_stress=owner_result)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--geometry-dir", type=Path)
    out=parser.add_mutually_exclusive_group()
    out.add_argument("--output",type=Path)
    out.add_argument("--check",type=Path)
    args=parser.parse_args()
    if args.geometry_dir:
        sys.path.insert(0,str(args.geometry_dir))
    import merges789 as geom
    result=dict(
        arithmetic="Exact Fraction with primal and dual equality, no numerical tolerances",
        python={"executable":sys.executable,"version":platform.python_version(),
                "architecture":platform.machine()},
        command="python -B common791.py --check common791.json",
        dependency={"merges789.py":sha256(Path(geom.__file__).read_bytes()).hexdigest()},
        scope=("Reuse the R789/R790 real cube centers, radii and disjoint actual owners. "
               "The density on the first axis is 1+a,1-a on alternating half-periods of length 1/16; "
               "other axes are Lebesgue. All old full degree and nonproduct marking definitions apply, "
               "with true intersections, degrees and both old price marks recomputed for each amplitude. "
               "The common transport uses exact membership cells in Q(0,4), including the empty cell. "
               "Cell flows lift by conditional true price products. The benchmark for each pair uses "
               "both original centered masses. The full high-dimensional entrance is outside this finite fixture."),
        cases=[case(n,s,geom) for s,n in enumerate((4,8,16),1)])
    data=(json.dumps(result, sort_keys=True, indent=2, default=str)+"\n").encode()
    if args.output:
        args.output.write_bytes(data)
    elif args.check:
        if args.check.read_bytes()!=data:
            raise SystemExit("certificate differs")
        print("common791: true phase marks, common transport and owner capacities agree")
    else:
        print(data.decode(),end="")


if __name__=="__main__":
    main()

