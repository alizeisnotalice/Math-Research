"""Exact physical merge tests for round 789. The first coordinate carries a periodic price."""
import argparse
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
from math import isqrt
import json
from pathlib import Path


@dataclass(frozen=True)
class Parent:
    c: F
    s: F
    m: F
    owner: F
    keep: F


def total(items):
    return sum(items, F(0))


def floor_log2(x):
    assert x > 0
    power = x.numerator.bit_length() - x.denominator.bit_length()
    return power - (F(2)**power > x)


def mu1_primitive(x):
    period = F(1, 16)
    k = x // period
    t = x - k * period
    return k * period + min(t, period / 2) / 2 + max(F(0), t - period / 2) * F(3, 2)


def price(l, r):
    return mu1_primitive(r) - mu1_primitive(l) if l < r else F(0)


def instances(n, stage):
    # All side endpoints lie on true price periods. Label weights include a nonconstant old survival.
    locations = [(-36, 16), (36, 16), (-31, 17), (31, 18), (-1, 20), (2, 23), (-4, 29)]
    if stage >= 2:
        locations += [(-34, 17), (33, 17), (4, 25)]
    if stage >= 3:
        locations += [(-27, 17), (27, 17), (-9, 21), (7, 26)]
    out = []
    for i, (c0, s0) in enumerate(locations):
        c, s = F(c0, 16), F(s0, 16)
        m = (2 * s)**n
        out.append(Parent(c, s, m, m / (32*n)**n, F(4 - (i % 3), 4)))
        assert price(c-s, c+s) * (2*s)**(n-1) == m
    for a, b in combinations(out, 2):
        assert abs(a.c-b.c) > (a.s+b.s)/(32*n)
    # W_a=Q(c_a,6R) contains every participating physical cube in these cases.
    assert all(abs(a.c-b.c)+b.s <= 6 for a, b in product(out, repeat=2))
    return out


def intersection(x, y, n):
    return price(max(x.c-x.s, y.c-y.s), min(x.c+x.s, y.c+y.s)) * (2*min(x.s,y.s))**(n-1)


def cells_and_marks(parents, n, down):
    xs = sorted({p.c+sign*p.s for p in parents for sign in (-1,1)})
    rs = sorted({F(0)} | {p.s for p in parents})
    weighted = defaultdict(F)
    positive = 0
    for l, r in zip(xs, xs[1:]):
        for a, b in zip(rs, rs[1:]):
            t = (l+r)/2
            labels = {i for i,p in enumerate(parents) if abs(t-p.c)<p.s and b<=p.s}
            mass = price(l,r)*((2*b)**(n-1)-(2*a)**(n-1))
            if labels and mass:
                positive += 1
                for u in labels:
                    p = parents[u]
                    mids = tuple(v for v in sorted(labels) if u in down[v])
                    weighted[u,mids] += p.keep*p.owner*mass/p.m
    for u,p in enumerate(parents):
        assert total(w for (i,_),w in weighted.items() if i==u) == p.keep*p.owner
    return weighted, positive


def component_table(parents, intersects, n, bin_width, fine):
    nodes = set(range(len(parents)))
    def key(i):
        ratio = parents[i].m / F(2)**n
        return (parents[i].m, i) if fine else floor_log2(ratio)//bin_width
    keys = sorted({key(i) for i in nodes})
    active, answer = set(), {}
    for step in keys:
        active.update(i for i in nodes if key(i)==step)
        pool = set(active)
        while pool:
            comp = {min(pool)}
            pending = list(comp)
            while pending:
                u = pending.pop()
                new = {i for i in active-comp if intersects[u,i]>0}
                comp.update(new)
                pending.extend(new)
            pool.difference_update(comp)
            mass = total(parents[i].owner*parents[i].keep for i in comp)
            for u in comp:
                new = [i for i in comp if (u,i) not in answer]
                inc = total(parents[i].owner*parents[i].keep for i in new)
                for i in new:
                    answer[u,i] = (step, mass, inc)
    return keys, answer


def median(values):
    seq = sorted(values)
    return seq[len(seq)//2]


def case(n, stage):
    parents = instances(n,stage)
    labels = range(len(parents))
    inter = {(i,j):intersection(parents[i],parents[j],n) for i,j in product(labels,repeat=2)}
    degrees, down = {}, {}
    for v in labels:
        p=parents[v]
        edges={u:inter[v,u]*parents[u].owner/(p.m*parents[u].m) for u in labels
               if p.m!=parents[u].m and 0<inter[v,u]<=F(3,4)*min(p.m,parents[u].m)}
        degrees[v]=total(edges.values())
        down[v]={u for u in edges if parents[u].m<p.m}
    marks, numcells = cells_and_marks(parents,n,down)
    width = max(1,n//4)
    levels,coarse=component_table(parents,inter,n,width,False)
    fine_levels,fine=component_table(parents,inter,n,width,True)
    m0=F(2,32*n)**n
    Y=total(p.owner for p in parents)
    survived=total(p.owner*p.keep for p in parents)
    records=[]
    norm=total(pa*pb/coarse[u,g][2] for (u,ma),pa in marks.items()
               for (g,mb),pb in marks.items() if (u,g) in coarse)
    assert norm<=len(levels)*survived
    # Independent ordered enumeration of the original two prices and full degree.
    for (u,ma),pa in marks.items():
        for (g,mb),pb in marks.items():
            both=set(ma).intersection(mb)
            if not both:
                continue
            cap=total(parents[v].owner/parents[v].m for v in both)
            level,mass,inc=coarse[u,g]
            _,fw,_=fine[u,g]
            floor= max(m0,fw)
            # Integer majorant of sqrt(1+log_2^+(fw/m0)), for an exact admissible smaller test.
            lg=max(0,1+floor_log2(floor/m0))
            rank=floor*(1+isqrt(lg))
            for v in both:
                p=parents[v]
                weight=pa*pb*p.owner/(p.m*p.m*degrees[v])
                M=p.m*degrees[v]
                rec=(weight,M/cap,inc,mass,rank,u,g,v,level,inter[u,g]==0)
                records.append(rec)
    raw=total(r[0] for r in records)
    byrow=F(0)
    for v,p in enumerate(parents):
        if degrees[v]:
            arm=total(w for (_,ms),w in marks.items() if v in ms)
            byrow+=p.owner*arm**2/(p.m**2*degrees[v])
    assert raw==byrow and raw>0
    # The comparison is exact with F on original edges, no dust from inactive pairs.
    weighted_norm=total(w*budget/inc for w,budget,inc,*_ in records)
    assert weighted_norm<=norm
    bypairs=total(pa*pb/coarse[u,g][2] for (u,ma),pa in marks.items()
                  for (g,mb),pb in marks.items() if set(ma).intersection(mb))
    assert weighted_norm==bypairs
    rank_norm=total(parents[u].owner*parents[u].keep*parents[g].owner*parents[g].keep/
                    (max(m0,ss[1])*(1+isqrt(max(0,1+floor_log2(max(m0,ss[1])/m0)))))
                    for (u,g),ss in fine.items())
    assert rank_norm>0
    quota=median([inc/budget for w,budget,inc,*_ in records])
    def paid(index, q):
        return total(r[0]*min(1,q*r[1]/r[index]) for r in records)
    regular=paid(2,F(1))
    by_inc, by_total, by_rank=(paid(i,quota) for i in (2,3,4))
    assert regular==raw and 0<by_total<by_inc<raw
    cross=total(r[0] for r in records if r[9])
    first_here=total(r[0] for r in records
                     if r[9] and r[8]==floor_log2(parents[r[7]].m/F(2)**n)//width)
    assert cross>0 and first_here>0
    return dict(n=n,parents=len(parents),price_cells=numcells,mark_types=len(marks),
                ordered_peak_records=len(records),positive_middle_rows=sum(bool(s) for s in down.values()),
                true_Y=Y,surviving_one_arm_mass=survived,unfiltered_residual_product_Q=raw,
                recomputed_by_original_row=byrow,coarse_epochs_observed=len(levels),
                fine_steps=len(fine_levels),max_coarse_epochs_in_octave=1+(n+width-1)//width,
                geometrically_disjoint_original_labels_share=cross/raw,
                joined_in_actual_middle_epoch_disjoint_share=first_here/raw,
                real_capacity_paid_share=regular/raw,fine_floor=m0,
                true_reference_total_over_Y=norm/Y,marked_pair_reference_with_eligible_middle_over_Y=bypairs/Y,
                fine_reference_total_over_Y=rank_norm/Y,
                diagnostic_quota=quota,new_mass_paid_share_at_diagnostic=by_inc/raw,
                cumulative_mass_paid_share_at_diagnostic=by_total/raw,
                fine_mass_rank_paid_share_at_diagnostic=by_rank/raw)


def main():
    ps=argparse.ArgumentParser(description=__doc__)
    opt=ps.add_mutually_exclusive_group(required=True)
    opt.add_argument("--output",type=Path)
    opt.add_argument("--check",type=Path)
    args=ps.parse_args()
    doc={"cases":[case(n,j) for j,n in enumerate((4,8,16),1)],
         "scope":"Finite physical cubes in a single octave with exact nonuniform absolutely continuous source. Diagnostics use weak edge cuts and a finite coarse layer width. Full first crossings and extremal cut not imposed.",
         "input":"Periodic density on first coordinate 1/2 and 3/2 on equal halves of period 1/16. Constant on others. Truncate outside a box containing all parents. I_i=|E_i|. Arm keep fractions depend on label but full d_v always used.",
         "arithmetic":"Exact fractions. Diagnostic quota is the upper median of the finite sorted incidence ratios with multiplicity on mark types, fixed for all subsequent comparisons."}
    data=(json.dumps(doc,sort_keys=True,indent=2,default=str)+"\n").encode()
    if args.output:
        args.output.write_bytes(data)
    else:
        assert args.check.read_bytes()==data
        print("merges789: source cells, full-degree peak sums, two-arm capacity and merge costs agree in dimensions 4, 8, 16.")


if __name__=="__main__":
    main()
