"""Control a common actual price cell and check the asymptotic constants at the project's L(n)."""
from fractions import Fraction as F
from pathlib import Path
import argparse
import json
import platform
import sys
from flint import arb, ctx
import flint

ctx.prec = 256


def shared_source(n):
    # Centers are (0,+/-1/2,...,+/-1/2). Two physically disjoint cube slabs
    # have source masses 2^n and 2^(n-1). Formula uses their exact intersections.
    d = F(1, 16*n)
    m = F(2**n)
    def mass(r):
        inner = min(d, max(F(0), r-(1-d))) / d
        outer = min(d, max(F(0), r-1)) / d
        tangential = min(d, max(F(0), r-(F(1,2)-d/2))) / d
        return m * (inner + outer/2) * tangential**(n-1)
    radii = sorted({F(1,3), F(1,2), 1-d, 1-2*d/3, 1-d/4, F(1), 1+d/8, 1+d, 2})
    checks = [(str(r), str(mass(r) / (2*r)**n)) for r in radii]
    assert all(mass(r) < (2*r)**n for r in radii if r < 1)
    assert mass(1) == m and mass(1+d) > (2*(1+d))**n
    assert all(mass(r)/(2*r)**n <= F(3,2) for r in radii)
    assert mass(2) == 3*m/2
    return dict(n=n, common_fathers=2**(n-1), fixed_radius=1, price_cell_mass=str(m),
                price_cell_Lebesgue_volume=str(d**n), concentration_ratio=str(m/d**n),
                true_radii_and_means=checks,
                reference_cell_bound_over_price_mass=str(F(3,2)*(1+d)**n))


def project_scale(power, log_power):
    n = 2**power
    ell = arb(n+2).log()
    L = arb(n).sqrt()*ell**log_power
    x = L/n
    assert 0 < x < arb(1)/4
    log_single = n*((-x).exp() + x/8).log()
    log_combined = log_single + L/4
    assert log_single < -L/2 and log_combined < -L/4
    q = int((16*n/L).ceil().unique_fmpz())
    p = arb(q+1)/2
    relative = n*(((-L+arb(2).log())/n).exp() + 2/(p+1)).log()
    assert relative < -L/4
    return dict(n=str(n), log_power=log_power, gap_by_n=str(x), q=q,
                log_single_relative_to_L=str(log_single/L),
                log_with_exp_L_over_4_cells_relative_to_L=str(log_combined/L),
                log_owner_moment_relative_to_L=str(relative/L))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    opts = parser.add_mutually_exclusive_group(required=True)
    opts.add_argument("--output", type=Path)
    opts.add_argument("--check", type=Path)
    args = parser.parse_args()
    result = dict(python=sys.executable, version=platform.python_version(), flint=flint.__version__,
                  precision_bits=ctx.prec, finite_geometry=[shared_source(n) for n in (4,8,16,64)],
                  actual_asymptotic_parameters=([project_scale(k,3) for k in (32,48,80,120)]
                                                + [project_scale(k,8) for k in (112,128,160,224)]),
                  scope="The shared cube slab gives a genuine centered first crossing for all its small fathers. It does not simulate the old cut or the steep full path. The eight large n cases use the project scales sqrt(n) log(n+2)^3 and sqrt(n) log(n+2)^8 and check only the scalar inequalities.")
    data = (json.dumps(result, sort_keys=True, indent=2) + "\n").encode()
    if args.output:
        args.output.write_bytes(data)
    else:
        assert args.check.read_bytes() == data, "certificate mismatch"
        print("prices791: shared first crossings and eight project gap certificates agree")


if __name__ == "__main__":
    main()
