# R636 完整插值账与近极值回代独审

按主代理冻结公式先独立推导，随后读取作者 `/tmp/ccu_r636/joint_geometry.md` 对照。结论：**完整 D_t 恒等式、同 μ 合法性、端点 J 符号、作者新增全程 J 上界、零方差分支与 near-family 回代均正确；没有得到完整定量净增益。** 不改他人文件、仓库，不启动代理或数值扫描。

## 1. 准确量词与合法插值族

固定 n≥1、a≥32n、H、ε、完整有限旧族、正增量 v_j>0，以及旧 regularized 最优 λ_j>0。全部旧量和参数固定。对同一份实际 L1 KKT 来源 μ，有

\[
q_j=\lambda_jd_j>0,\quad z_j=v_j/q_j,\quad
Q=\sum_jq_j,\quad V=\sum_jq_jz_j,\quad R=V/Q,
\]

\[
m_j=d_j(1+\epsilon z_j),\qquad M=Q+\epsilon V.
\]

对每个 t∈[0,1]，令

\[
d_j(t)=d_j(1+t\epsilon z_j),\quad
A_j(t)=Q(y_j,ar_j[1+t\epsilon z_j]^{1/n}),\quad B_j(t)=A_j(t)/a.
\]

A_j(t) 包含原 A_j，且 d_j(t)≤m_j，所以全部 rows **同时对同一 μ** 满足

\[
\mu(A_j(t))\ge m_j\ge d_j(t).
\]

t<1 时第二个不等式严格；t=1 不保证严格，甚至不保证 μ(A_j(1))=m_j。非严格端点只按已有严格恢复工具处理，不能借等号制造正增益。

这些路径几何仅依赖旧 family、λ 与固定旧矩；它们对整个旧 KKT 来源类相同。改变 cell 内来源不能改变 D_t，虽可改变 canonical D(μ)。不需要 μ 产品性。

## 2. 真实 gross、overlap、fill 及完整恒等式

设

\[
E_j(t)=y_j+[1+t\epsilon z_j]^{1/n}(I_j-y_j),\quad
V_t=|\cup_jB_j(t)|,
\]

\[
O_t=\sum_j|E_j(t)|-|\cup_jE_j(t)|,
\quad C_t=V_t-|\cup_jE_j(t)|\ge0.
\]

合法包含是 `E_j(t)⊂B_j(t)`。不同 t 的 E_j(t) 不必嵌套，因为 I_j 非星形。每行 Jacobian 为 `1+tεz_j`，所以

\[
\mathcal A_t:=\sum_j|E_j(t)|
=V+t\epsilon\sum_jq_jz_j^2,
\quad V_t=\mathcal A_t-O_t+C_t.
\]

令 Qlin(t) 是该完整实际新族的 linear packing 最优值，并定义

\[
J_t=Q_{\rm lin}(t)-(Q+t\epsilon V),
\qquad\mathcal V=\sum_jq_j(z_j-R)^2
=\sum_jq_jz_j^2-V^2/Q\ge0.
\]

则逐项相减准确得到

\[
\boxed{D_t:=V_t-RQ_{\rm lin}(t)
=t\epsilon\mathcal V-O_t+C_t-RJ_t.}
\]

所有 gross、overlap 和 fill 都是全族真实量；没有用旧 I_j 冒充新族的不交 increments。t=0 时 O_0=C_0=0，此处下标 0 指路径起点，不是 R635 的 raw-fill 记号。

作者等价记号 `K_t=mathcal A_t−V_t=O_t−C_t` 可以有符号，不可默认为非负。其式 `D_t=tεmathcal V−K_t−RJ_t` 正确。

## 3. J 的符号与全程上界

旧 λ 在 t=0 可行，所以

\[
J_0=Q_{\rm lin,old}-Q\ge0.
\]

对所有 t，同 μ 为新族 linear packing 的可行 dual：任意新可行 ν 有

\[
\sum_j\nu_jd_j(t)\le\sum_j\nu_j\mu(A_j(t))\le M.
\]

故 Qlin(t)≤M，特别 `J_1=Qlin(1)−M≤0`。

作者新增的更强式也通过：

\[
\boxed{J_t\le(1-t)J_0\quad(0\le t\le1).}
\]

证明：星随 t 增长，故实际 packing polytopes 满足 P_t⊂P_0。对 ν∈P_t⊂P_0，分别有 `ν·d≤Qlin,old` 与 `ν·m=∫Lνdμ≤M`。由于 `d(t)=(1−t)d+tm`，

\[
Q_{\rm lin}(t)\le(1-t)Q_{\rm lin,old}+tM;
\]

减去 `(1−t)Q+tM=Q+tεV` 即得。

这不是 J 的下界，也不保证一般 J_t≤0。旧 λ 在增大的 stars 上可能不再 packing；不能把参考值 Q+tεV 当作实际 capacity 的上界或最优值。若旧 λ 恰在 P_t 内仍可行，才另有 J_t≥0。

正体积 clique 在所有坐标严格相交时才生效。容量可能在新 clique 出生后跳变；无需且不能未经证明用 J_t 连续性或 intermediate-value argument 选择 J_t=0。上述上界不依赖连续性。

## 4. 零方差分支的独立证明及限度

因全部 q_j>0，mathcal V=0 当且仅当所有 z_j=R。此时

\[
m_j=c d_j,\quad M=cQ,\quad c=1+\epsilon R,
\quad e_j=\beta.
\]

对任意旧 linear-feasible ν，

\[
\sum_j\nu_jd_j
=c^{-1}\int L_\nu d\mu\le M/c=Q.
\]

旧 λ 本身达到 Q，因此 **λ 是旧 linear 最优解，J0=0**。这是一份独立 primal/dual 证明，不依赖近极值性。

第 3 节遂给该特殊分支全部 J_t≤0。然而

\[
D_t=-O_t+C_t+R|J_t|
\]

仍没有统一正 cV 下界。非负方差或旧 λ linear 最优不证明 growth overlap 已付款，也不排除困难族。任何只以严格正方差作收益的候选，都还欠 near-zero/zero variance 的完整分支。

## 5. near-family 回代：正确上界与不能省略的对象

使用合同已证有限 S_N。选完整旧 family 的 `R>S_N−δ`，不假设 supremum 达到、来源极限或驻点。

对每个 μ 和每个 t，新完整族 B_j(t) 至多 N 标签且由同 μ 合法。新 regularized ratio 必须用**新实际顺序 increments**，删零行后记其 linear part 为 Qeps,new。它满足

\[
Q_{\epsilon,\rm new}\le Q_{\rm lin,reduced}(t)
\le Q_{\rm lin,complete}(t)\le M.
\]

其 receiver union 测度仍为 V_t，按 S_N 定义 `V_t/Qeps,new≤S_N<R+δ`。因此

\[
\boxed{D_t<\delta Q_{\rm lin}(t)\le\delta M.}
\]

这里没有使用旧 regularized λ 作为新最优，也没有用旧 v_j 作为新 regularizer 的增量。旧 v_j 只用于插值辅助 pieces 与恒等式。

代入完整账只能得到

\[
O_t+RJ_t-C_t>t\epsilon\mathcal V-\delta M.
\]

这是近极值族必须满足的 loss/capacity 障碍，不是反向付款。特别起点 `D_0=−RJ0≤0`，一般 baseline 并非 0。

near-family 量词对所有合法 μ、所有这些更新都成立；若另证对每个困难族存在一份 μ 和合法更新的统一正增益，则可选 δ 小于该已知净 margin/M 导致矛盾。当前恒等式与 near 上界本身没有提供这份正增益。

## 6. 路径端点与完整 canonical D 的回代

t=1 是 raw **完整小方体族**，未必是 canonical 完整族。记其 union/capacity 为 V1,Q1；R635 raw increment union 的 loss 为 Oraw，填充 `C1=V1−|unionEraw|≥0`，则 `K1=Oraw−C1`。

由于 B_j(1)⊂B_j*，V*−V1≥0；但扩大 stars 同时改变 objective 体积与 packing polytope，因此 Q*−Q1 无固定符号。准确回代必须是

\[
\boxed{D(\mu)=D_1+(V^*-V_1)-R(Q^*-Q_1).}
\]

不能据 V*≥V1 就断言 D(μ)≥D1。

作者端点 source slack 分解也正确：若 ν^(1) 为 raw 新族完整最优，

\[
M-Q_1=\int(1-L_{\nu^{(1)}})d\mu
+\sum_j\nu_j^{(1)}[\mu(A_j(1))-m_j]\ge0.
\]

两项都以同一 μ、同一 raw 最优 ν 一次支付；其价格不等于 owner lost-volume 价格。raw→canonical 的全项回代恰给

\[
D(\mu)=\epsilon\mathcal V-O_{\rm raw}
+C_{\rm raw\to canonical}(\mu)+R[M-Q^*(\mu)].
\]

这里 C 是 V* 减 raw increment union，而非路径起点 C_0。

## 7. 作者的具体 cube 捕获及真正未付全局比较

作者逐坐标接触式是合法的：两个 axis-aligned open cubes 正体积相交，当且仅当每个坐标中心差严格小于半径和。只作闭集接触记录时可用≤，不能提前给容量收费。有限 box cliques 的 Helly 条件与这一坐标合同相容。

若端点 raw small cubes 相交、R_k^raw≤R_j^raw 且 e_k≥1/3，则原 source star A_k 位于 raw A_j(1)，余量系数 13/(48n) 正确。该捕获可以进入上节 ν^(1)-加权的 source surplus，但 owner 损失价格是 `(m_k/d_k)(v_k−u_k)`，捕获价格是 `ν_j^(1)`；owner 的 ν 权可能为零。当前没有共同列容量把前者付给后者，不能逐 owner 重领 M 或用第三方 blocker 的角部交替代整块包含。

**真正仍需的新全局估计**，对 canonical 路线，精确是存在同一合法 μ 使

\[
O_{\rm raw}-C_{\rm raw\to canonical}(\mu)
-R[M-Q^*(\mu)]
\le\epsilon\mathcal V-cV+C L_nM.
\]

对直接路径更新，等价需求是存在合法 t 使

\[
O_t+RJ_t-C_t\le t\epsilon\mathcal V-cV+C L_nM.
\]

这些式子在本报告中只是**完整未付目标**，不是由恒等式得到的新定理。要算推进，必须给实际 cube 几何/optimal-capacity 的统一比较，尤其在零/小方差时仍产生独立正 cV；“overlap≤fraction variance”即使成立也不能独自覆盖该分支。新 J 上界与一次 source slack 分解尚不提供这一比较。

## 8. 实际工具与最终判定

本机 math venv、SymPy 1.14.0，轻量以三行独立符号 q_j,z_j 核验完整 interpolation identity 和 weighted-variance 展开，两个残差为 0。几何包含、packing/dual 方向与 near-family 量词以上述解析论证核验；没有数值扫描或反复计算旧例。

**最终：主代理完整账及作者 joint_geometry.md 的新增精确式均通过；near-family 的正向矛盾入口合法，但未证所需统一净增益。未将身份改名、路径或零方差特殊最优性登记为预算突破。完成 bounded 独审，停止待命。**

## 9. 附审：零方差且单时刻 packing 平台时，真实 D_t≤0

**该条件命题成立，而且只需给定这个 t 的 P_t=P_0，不需预先假设整个 [0,t] 恒定。** 它不声称困难族中存在这种平台，也不是全局反例。

零方差时，令 `c_t=1+tεR`、`s=c_t^(1/n)`。第 4 节已独立证明 Qlin,old=Q；全部 d_j(t)=c_t d_j。若该 t 的真实 packing polytope 与旧者相同，则

\[
Q_t=\max_{\nu\in P_0}\sum_j\nu_jc_td_j=c_tQ.
\]

完整小方体同时变成 `B_j(t)=Q(y_j,sr_j)`。对任意有限轴平行 cubes、任意不等半径，确有

\[
\boxed{|\cup_jQ(y_j,sr_j)|\le s^n|\cup_jQ(y_j,r_j)|\quad(s\ge1).}
\]

以下给出所需 center-contraction 证明，避免默用未知的一般凸体结论。缩放全空间后，左侧为 `s^n|∪Q(y_j/s,r_j)|`。固定一个坐标，把所有中心的该坐标共同乘 c∈[0,1]，其余坐标与半径不变。按其余坐标作 Fubini，每条截线上的 active 标签固定，问题成为有限区间 `[cx_j−r_j,cx_j+r_j]` 的并长。

该并长随 c 非减：端点均为仿射函数，仅在有限个 c 改变排序；在每个固定排序区间，每个 union 连通分量的左端来自某区间 j、右端来自某区间 k。由左端最小、右端最大，分别有

\[
cx_j-r_j\le cx_k-r_k,\qquad
cx_k+r_k\ge cx_j+r_j.
\]

相加给 `x_k≥x_j`（c>0），所以这个分量并长对 c 的导数为 `x_k−x_j≥0`。有限并长关于端点连续，故穿过全部 breakpoints 后仍非减；c=0 由连续性处理。逐坐标依次收缩至 1/s，得到 `|∪Q(y_j/s,r_j)|≤|∪Q(y_j,r_j)|`。

因此 `V_t≤c_tV`，并且

\[
\boxed{D_t=V_t-RQ_t\le c_tV-Rc_tQ=0.}
\]

这个结论使用完整 cube union，未以 pieces 的 gross volume 代替物理 V_t。

准确含义是：在零方差分支，若 raw uniform-radius 路径某时刻取得 D_t>0，则该时刻必须已发生真正的 packing-polytope 改变；更强地必须使真实目标 `Q_t<c_tQ`，因为仅出现不影响最优面的新 clique 仍不足以产生正 D_t。这不证明 clique 改变必发生，也不证明其容量降幅足以付款。

raw 路径对整个旧 KKT 来源类固定，故只改变 cell 内来源不能改变这一平台结论。若使用 finite 共同选源去改变 canonical V*、Q*，仍需全量重算并保留第 6 节的 raw→canonical 两项差；不能把条件平台限制当成该全局更新的反例。

**附审通过，停止待命。**
