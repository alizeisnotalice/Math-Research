# R636 正则 packing 的真实 Q 响应独审（Sol high）

独立依据：本轮 CONTRACT、R619 正则目标与 finite packing KKT；先推导后向 outer 作者发送公式，未先读取作者稿。固定 a、ε；不选择或假定最优 μ，不改仓库、不重算终端。

**关键公式：** 稳定旧 incidence polytope 和稳定正则最优 face 内，令 W=εdiag(v_j/λ_j²)、Z 为该 face 切空间的基、K=Z(ZᵀWZ)^{-1}Zᵀ，则

    dotλ=K[dotd+ε dotv/λ],
    dotQ=λ·dotd+d·dotλ,

而正则最优目标的 envelope 是

    dotJ=λ·dotd+ε(logλ)·dotv.

后式不是 dotQ。下列给出完整范围、可用的 signed 简化与近极值接口；尚无完整 D 的正付款。

## 1. 固定 polytope、稳定 face 的推导

令 P={λ≥0:Aλ≤1} 是固定 finite packing polytope，v_j>0。正则最优点 λ 唯一且全正。取稳定最小 face 的独立活动行 B，Bλ=1；Z 的列为 ker B 的任意基。face 为单点时取 K=0。沿 C1 数据 d(t)、v(t)>0，假定 λ(t) 在同一 face 的相对内部，且其余 packing 约束保持非活动。

KKT 为

    d+ε v/λ=Bᵀz.

记 b=dotd+ε dotv/λ，逐分量除法。微分得

    W dotλ+Bᵀdotz=b,   B dotλ=0.

因此 dotλ=K b。独立活动行的选择不影响 K；原 KKT source multipliers 即使不唯一，也不影响这一 primal 响应。

准确导数是

    dotQ=λ·dotd+dᵀK(dotd+ε dotv/λ).                  (Q1)

用 KKT 与 B dotλ=0，亦可写

    dotQ=λ·dotd−ε(v/λ)·dotλ.                        (Q2)

没有理由删掉 d·dotλ。另一方面 J(d,v)=max[d·λ+εΣv logλ] 的 envelope 确是 dotJ=λ·dotd+ε(logλ)·dotv。即便 dotλ=0，只要 dotv≠0，该 envelope 仍一般不同于 dotQ；即便 dotv=0，dotQ 也一般仍有 λ 响应项。

## 2. signed w 简化及实际已获控制

K Bᵀ=0、Wλ=εv/λ，故 Kd=−KWλ。定义

    w=λ−KWλ=λ+Kd.

则主代理提出的简化准确为

    dotQ=w·dotd+εΣ_j(w_j/λ_j−1)dotv_j.             (Q3)

有 Bw=1，且 Ww 与 ker B 正交；因此 w 是

    min{½xᵀWx:Bx=1}

的唯一**无非负约束**解。它不是正则最优 packing，不能自动认为 w≥0、L_w≤1 或其标签权为概率。当前真实 cube active-incidence 合同未提供这样的正性结论，本审也不声称已经构造了 actual cube/KKT 的负权反例。

可保留一个不含隐藏常数的真实投影控制。令 r_j=w_j/λ_j。由 λ=w+(λ−w) 的 W-正交分解，

    Σv_j r_j²=Σv_j r_j∈[0,V],
    Σv_j(r_j−1)²=V−Σv_jr_j²≤V.                    (W)

特别 Σv|r|≤V、Σv|r−1|≤V，但没有逐标签 r 界；tiny v 标签仍可能带大响应。由此只能得到带真实价格的

    |w·dotd|≤√V [Σ λ_j² dotd_j²/v_j]^{1/2},
    ε|Σ(r_j−1)dotv_j|≤ε√V [Σ dotv_j²/v_j]^{1/2}.

这里 inverse-v、λ 和几何速度不能删掉。尚无已证 cube 几何把右端结算成完整 receiver/root 预算；不能因 K 正半定、KW 是 W-正交投影就说 K 或 KW 保逐点正性，也不能把 (W) 直接命名成 D 付款。

## 3. face 或 incidence 改变时

固定 polytope 但活动 face 改变时，不能沿用旧 Z 公式。对单侧方向，在相应方向可导的固定 polytope 敏感度框架中，应使用临界锥

    C={h∈T_P(λ):(d+εv/λ)·h=0},
    h=argmin_{h∈C}[½hᵀWh−b·h].

稳定 face 时 C 对所用响应退化为切子空间，才回到上述 K。退化活动约束或零乘子不允许直接忽略；若不证明单侧响应及其范围，就应使用实际有限重新优化比较。

若几何变化使 packing clique 出生/消失，A 本身变了，以上固定-polytope 公式不适用。开 stars 从仅接触转为正体积相交就可能新添 packing 约束，不能因 d、v 连续而假定 Q、λ 沿用旧 face。应分别核新的 incidence 与一侧 family，或保留完整有限最优化差。

## 4. 真实 dotv 不是自由数据

固定 a 的真实半径扰动满足

    d_j=(2ar_j)^n,   dotd_j=n d_j dotr_j/r_j.

v_j 则是有序真实 receiver 增量 |B_j\∪_{i<j}B_i|，不能任意独立指定，也不能恒取 dotv=dotd/a^n（只有小 B_j 不交等特例才成立）。

在 receiver coordinate-face 顺序不变的几何 chamber 内，把所有 elementary boxes C(t) 分给其最早所属标签。若其边长为 ℓ_Ci(t)，则

    v_j(t)=Σ_{owner(C)=j}Π_iℓ_Ci(t),
    dotv_j=Σ_{owner(C)=j}Σ_i dotℓ_Ci Π_{l≠i}ℓ_Cl.

每个端点速度来自同一组中心/半径速度。该式保留其他旧 cubes 移动造成的捕获/释放费用；packing-star incidence 稳定与 receiver chamber 稳定须分别检查。遇到端点 ties 用合法单侧 chamber 或实际有限变化，不能把两侧不一致的导数拼接。

## 5. 用于全局 near-family 的准确有限桥

设当前 R0=V0/Q0>S_N−δ。对任何仍在相同≤N完整几何类的合法扰动 family F(t)，重新算实际 increments 和 Qε(t)，全局权限直接给

    V(t)−R0Qε(t)<δ Qε(t).                           (NF)

它不要求新族由旧 μ 见证；若另用 μ 见证得到 Qlin≤M，则沿用相应更强有限 cap，但不能混淆 Qlin 与 Qε。

本文件的 Q 是每个扰动 family 重新正则化后的 Qε，不是 D 中新 canonical family 的线性 packing Qlin*。后者须按其自己的线性最优集合及新 incidence 作有限比较；不能将 (Q1) 换一个星号就当作 dotQlin*。若只在固定旧 family 内改变 KKT μ，则旧 d、v、λ、Qε 全不变，本节旧 Q 的导数为0，而 canonical Qlin*、V*仍可能变化或跳跃。

稳定条件下，(NF) 左侧的真正一阶项是

    t[dotV−R0 dotQ]+o(t),
    dotV=Σdotv_j,

其中 dotQ 必须用 (Q1)–(Q3)。固定 δ>0 时不能令 t→0 推出 dotV−R0dotQ≤0，因为右侧含 δQ0，除以 t 后是 δQ0/t。若候选要用近似驻点，必须选择实际有限 t 并支付 δ/t 与 Taylor 余项；或沿 δ_k→0 的 near-family 序列同时证明足够统一的合法邻域、响应/remainder 控制。λ_min、v_min、face slack 可能使该邻域和常数退化，不能仅凭每个实例局部可微省掉它们。

一个完整有限正增量若大于 δQε(t) 才能直接冲破 (NF)。单独 envelope、一个符号方向导数，或未经定价的投影 L2 控制，都尚未给出这个完整增量。

## 6. 实际 finite cube 控制：三种导数确实不同

本审独立构造并用本机 SymPy 1.14.0 精确核验一个实际一维局部 family：n=1、a=H=32、ε=1/66，

    B1(t)=Q(0,(2+t)/64), B2=Q(1/32,1/64).

|t|足够小时 stars 固定为 nested/common-clique incidence，packing face λ1+λ2=1；真实增量给

    d=(2+t,1), v=((2+t)/32,(1−t)/64), dotV=1/64.

显式解 λ1 的标量 KKT 根后，投影公式的 dotλ、dotQ 与直接微分的两个精确残差均为0。t=0 时

    λ·dotd≈0.999763481604497810,
    dotQ≈1.00023640638125746,
    dotJ_envelope≈1.00174004682184301.

运行约0.21秒；这是保留真实 dotv 的 sensitivity 控制，不在 hard 分支，不是根阶证据。

主代理/Terra 另提出小 B_j 不交而所有 A_j 共交的控制。独立核验：其 packing 为 simplex、v=d/a^n；记 c0=ε/a^n，唯一 Γ>max d 满足

    c0Σ_j d_j/(Γ−d_j)=1,
    λ_j=c0 d_j/(Γ−d_j), Q=Γ−c0Σ_jd_j.

任意真实半径方向有

    dotΓ=Γ [Σ dotd_j/(Γ−d_j)²]/[Σ d_j/(Γ−d_j)²],
    dotQ=dotΓ−c0Σdotd_j,
    dotJ=Σ[λ_j+c0 logλ_j]dotd_j.

三者与冻结 λ 的价格不同。根函数严格递减；N≥2 时可用 (1+c0)dmax 与 dmax+2c0Σd 构成正分母严格括区间。N=1 时下端恰为显式根 Γ=(1+c0)d1，不能称为严格下括。两标签时亦可取 Γ²−(1+c0)(d1+d2)Γ+(1+2c0)d1d2=0 中大于 dmax 的根。已直接发 Terra 相应几何/根/导数证书要求，未代其声称数值结果。

单标签 p 扰动的扩展式也通过代数审核：

    dotQ−λ_p dotd_p
      = c0 Γ dotd_p ·Σ_{i≠p} d_i(d_p−d_i)/(Γ−d_i)²
        /[(Γ−d_p)² Σ_jd_j/(Γ−d_j)²].

p 是最大标签且 dotd_p>0 时该差非负，有更小标签则严格正；最大并列项为0但保留全分母。若所有 d_i=d 并共同 dotd_i=nd，则 λ不变、dotQ=nd，而 dotJ−dotQ=−c0 nd NlogN。这些仍只是非hard有限响应控制。

## 7. 作者最终稿定点验收

已只读对照 `/tmp/ccu_r636/regularized_capacity.md`，不重复整个全局审核。**验收通过，未发现本次指定公式/对象范围中的实质错误。**

作者 §1 对 raw 径向数据 d(t)=d+tεv/λ 使用真实新 increments v(t)，并明确固定 packing polytope、两端及区间同一相对活动面、v_j(t)>0 的额外假设。记 u=λ(t)/λ、A=Σv(u−1)、E=Σv(u−1)²/u、T=ΣΔv(1−1/u)，独立两次 KKT 核算给

    tA+T=E,
    Qε(t)=Q+tεV−ε(1−t)A.

具体地，旧 KKT 给 d·(λ(t)−λ)=−εA；新旧梯度之差与 λ(t)−λ 配对给 tA−E+T=0。这与作者(1)–(2)准确一致，没有把 v(t) 换成旧 v。

由实际 expanded pieces 的总量和完整 fill/overlap，得作者(3)

    V_t−RQε(t)
      =tεΣ_jq_j(z_j−R)²−O_t+C_t+εR(1−t)(E−T)/t,   t>0.

q_j=λ_jd_j 是**未归一**权，Σq=Q；因此首项没有漏 Q。若改写为概率权 q/Q 的 variance，必须相应乘 Q。作者(4)的价格 |T|≤√E·[Σ(Δv)²/(v u)]^{1/2} 正确，inverse-v/u 未删。E≥0 不使完整右侧自动非负，作者对此判断准确。

作者(5)是线性完整账，用 J_t=Qlin(t)−(Q+tεV) 精确保留 −RJ_t；J0≥0、J1≤0 的两端符号没有被升级为全路径符号。同面正则式不跨越新 clique/face 改变，也没有代替实际线性容量变化。

作者 §2 正确保留

    Dlin=Dε−R(Qlin′−Qε′),  0≤Qlin′−Qε′≤εV′.

正则 deficit 的正项不能免费当作主线性 D 的正项；hard 区域仅用粗 gap 不是小费用。其 entropy 界 Hbar≤V[log(1/β)+H(η)]≤Vlog(N/β) 亦通过：由 λ_j≥βη_j、λ_j≤1 逐项求和即可。该真实 N 费用未被改成维数多对数。

作者 §3 的稳定-face响应、signed w 与带价平方控制逐项符合本报告§1–4；§5仍保留 δQ/t 及真实有限步/remainder 条件，没有从 near-optimal family 偷推驻点。固定旧族只换 μ 时旧 Qε 不变，canonical Qlin* 是另一变化 incidence 的线性最大值，作者明确区分。

平台 §4 的对象明确为 Qlin(t) 与 V_t−RQlin(t)，不是 Qε。其 Var=0 推旧 λ 线性最优、Pt=P0 给 Qlin(t)=(1+tεR)Q 的容量部分核对无误；union 几何不等式(13)由本轮 core 独审负责，本审未重复其证明。作者没有把平台条件当作存在的 hard-family 反例。

**最终状态：** 有限同face式、signed响应、转换费与对象声明通过；没有完整正 D 估计。可作为必要且范围明确的独立附录保存，不能计为本轮完整预算突破。已将验收意见发给主代理；唯一写入文件为本报告，完成停止。
