# R636：正则容量响应与完整净预算的终点

本稿只处理 CONTRACT 中同一完整 family 的容量侧；不改来源量词、不新增标签。结论是：**尚未得到决定完整净预算的新估计。** 下列有限正则比较、signed 投影响应和熵比较均可严格保留，但没有把真实 receiver 变化、新 packing incidence 和全部费用结算成

\[
D(\mu)=V^*-R Q^*\ge cV-C\sqrt n\log^B(n+2)M.
\]

因此本轮不把局部正则式作为新路线或突破。本稿的 \(Q_\epsilon(t)\) 是改变几何后重新正则化的旧类型容量；它不是 canonical 新族的线性容量 \(Q^*\)。固定旧族只换 KKT 来源时，旧 \(Q_\epsilon\) 完全不变。

## 1. 一条完整但未付清的有限正则式

沿主代理给出的 raw 径向族，记

\[
q_j=\lambda_jd_j,\quad z_j=v_j/q_j,\quad
R=\frac{\sum q_jz_j}{Q},\qquad
d_j(t)=d_j+t\epsilon v_j/\lambda_j\quad(0\le t\le1).
\]

实际 receiver 半径为 \(r_j(t)=r_j(1+t\epsilon z_j)^{1/n}\)，所有 \(v_j(t)\) 都必须重新取真实有序增量，不能独立指定。原 \(\mu\) 对全路径均给合法质量下界，因为 \(A_j(t)\supset A_j\) 且 \(\mu(A_j)=d_j+\epsilon v_j/\lambda_j\ge d_j(t)\)。

以下**额外假设**仅用于有限比较：所考察区间内完整 packing polytope 不变，正则最优点 \(\lambda(t)\) 留在同一相对活动面 \(B\lambda=\mathbf1\)，所有实际 \(v_j(t)>0\)。定义

\[
u_j=\lambda_j(t)/\lambda_j,\quad \Delta v_j=v_j(t)-v_j,
\quad E_t=\sum_jv_j\frac{(u_j-1)^2}{u_j},\quad
T_t=\sum_j\Delta v_j(1-u_j^{-1}).
\]

两端 KKT 与 \(B(\lambda(t)-\lambda)=0\) 给出精确有限等式

\[
t\sum_jv_j(u_j-1)+T_t=E_t,                                      \tag{1}
\]
\[
Q_\epsilon(t)=Q+t\epsilon V-\epsilon(1-t)\sum_jv_j(u_j-1).       \tag{2}
\]

证明不使用包络：旧 KKT 先给
\(d\cdot(\lambda(t)-\lambda)=-\epsilon\sum v_j(u_j-1)\)，直接展开 \(d(t)\cdot\lambda(t)\) 得 (2)。新旧 KKT 之差与 \(\lambda(t)-\lambda\) 配对，逐标签化简即得 (1)。

令 \(E_j(t)\) 是旧 \(I_j\) 以自身中心按上述比例放大后的 pieces，

\[
A_t=\sum_j|E_j(t)|=V+t\epsilon\sum_jq_jz_j^2,\quad
O_t=A_t-|\cup_jE_j(t)|,\quad
C_t=V_t-|\cup_jE_j(t)|\ge0.
\]

则对 \(t>0\)，完整正则 deficit 为

\[
\boxed{
V_t-RQ_\epsilon(t)
=t\epsilon\sum_jq_j(z_j-R)^2-O_t+C_t
 +\frac{\epsilon R(1-t)}t(E_t-T_t).
}                                                               \tag{3}
\]

交叉项的准确 Cauchy 价格是

\[
|T_t|\le\sqrt{E_t}
\left(\sum_j\frac{(\Delta v_j)^2}{v_ju_j}\right)^{1/2}.          \tag{4}
\]

这里没有把 \(\Delta v\) 当自由扰动，也没有删 \(v_ju_j\) 的逆价格。当前未证的是：真实 cube 变化能将 (4) 的第二因子与 \(O_t\)、实际 fill 和新容量变动一起支付。\(E_t\ge0\) 自身不决定 (3) 的符号。活动面或新 clique 一旦改变，(1)–(3) 的同面假设即告终止，不能无成本拼接。

主代理的全路径**线性**账没有该局部假设：若
\(J_t=Q_{\rm lin}(t)-(Q+t\epsilon V)\)，则

\[
V_t-RQ_{\rm lin}(t)
=t\epsilon\sum_jq_j(z_j-R)^2-O_t+C_t-RJ_t.                       \tag{5}
\]

\(J_0\ge0\)、\(J_1\le0\) 不给中间点统一符号。式 (3) 也不能消掉 (5) 中实际的新 incidence 价格。

## 2. 正则势与线性容量的转换费

任一正增量有限族满足

\[
0\le Q_{\rm lin}-Q_\epsilon\le\epsilon V.                       \tag{6}
\]

左边来自正则解可行；右边来自 KKT：对任一线性可行 \(\nu\)，
\(\nu\cdot d\le\nu\cdot m\le M=Q_\epsilon+\epsilon V\)。因此旧线性基线是

\[
V-RQ_{\rm lin}=-R(Q_{\rm lin}-Q_\epsilon),
\]

并非零。仅用 (6) 时该费用尺度为 \(R\epsilon V\)；hard 中 \(R\epsilon>3\)，故不能将它作为小余项。新族也有精确转换

\[
D^{\rm lin}=D^\epsilon-R(Q_{\rm lin}'-Q_\epsilon').              \tag{7}
\]

若直接证明了可迭代的统一正则 ratio 增量，它可以走同一有限 \(N\) 终端；目前没有这样的增量。(7) 表明局部正则正项本身不等于本合同的完整线性 \(D\) 正项。

再记真正的 barrier 最优值

\[
\mathcal F=Q_\epsilon-\epsilon\mathcal H,\qquad
\mathcal H=\sum_jv_j\log(1/\lambda_j).
\]

令 \(\eta_j=v_j/V\)、\(\beta=\epsilon V/M\)。由
\(\lambda_j=\epsilon v_j/(m_j-d_j)\ge\epsilon v_j/M=\beta\eta_j\)，有

\[
0\le\mathcal H\le V\bigl[\log(1/\beta)+H(\eta)\bigr]
\le V\log(N/\beta).                                             \tag{8}
\]

这是带真实标签数的上界；未得到只含维数多对数的熵费。将 \(\mathcal F\) 换回 \(Q_\epsilon\) 必须恢复 \(\epsilon\mathcal H\)，在 frozen-ratio deficit 中是 \(R\epsilon\) 倍的相应熵变化。不能使用 barrier envelope 却省掉这笔转换。

## 3. 真实敏感度与 signed 投影的范围

在固定 packing polytope、固定相对活动面且真实几何可微的区间内，令 \(Z\) 张成 \(\ker B\)，

\[
W=\epsilon\operatorname{diag}(v_j/\lambda_j^2),\quad
K=Z(Z^TWZ)^{-1}Z^T.
\]

顶点面取 \(K=0\)。准确公式为

\[
\dot\lambda=K(\dot d+\epsilon\dot v/\lambda),\qquad
\dot Q=\lambda\cdot\dot d+d^TK(\dot d+\epsilon\dot v/\lambda).    \tag{9}
\]

只有 \(\mathcal F\) 的包络是
\(\dot{\mathcal F}=\lambda\cdot\dot d+\epsilon\log\lambda\cdot\dot v\)，它一般不同于 \(\dot Q\)。

定义 \(w=\lambda-KW\lambda=\lambda+Kd\)、\(\xi_j=w_j/\lambda_j\)。则

\[
\dot Q=w\cdot\dot d+\epsilon\sum_j(\xi_j-1)\dot v_j,            \tag{10}
\]
\[
\dot V-R\dot Q
=\sum_j(1+R\epsilon-R\epsilon\xi_j)\dot v_j
 -R\sum_jw_j\dot d_j.                                           \tag{11}
\]

\(w\) 是 \(Bx=\mathbf1\) 下最小 \(x^TWx/2\) 的**无符号限制**解，未获 \(w\ge0\) 或 packing 可行性。投影确实给

\[
\sum v_j\xi_j^2=\sum v_j\xi_j\in[0,V],\qquad
\sum v_j(\xi_j-1)^2\le V,
\]

但相应可用费用仍是

\[
|w\cdot\dot d|\le\sqrt V\Bigl(\sum_j\lambda_j^2\dot d_j^2/v_j\Bigr)^{1/2},
\quad
\epsilon\left|\sum_j(\xi_j-1)\dot v_j\right|
\le\epsilon\sqrt V\Bigl(\sum_j\dot v_j^2/v_j\Bigr)^{1/2}.        \tag{12}
\]

真实半径变化给 \(\dot d_j=nd_j\dot r_j/r_j\)。真实 \(\dot v_j\) 还含其他 boxes 的捕获与释放：在坐标面顺序稳定的 chamber 内，把 elementary cells 分给最早标签后，对其各边长乘积求导。不能设 \(\dot v_j=\dot d_j/a^n\) 或忽略 tiny-increment 标签。当前没有将 (12) 的逆 \(v\) 几何费用付成 source-once/root 预算的估计。

固定 polytope 的 face 改变需改用相应临界锥或有限重新优化；packing clique 改变则必须重建可行域。固定旧族选 \(\mu\) 时，以上旧 \(Q\) 导数为零；新 canonical \(Q^*\) 是另一线性最大值且其 incidence 可改变，禁止给 (9) 加星号代用。

## 4. 一个严格的径向平台限制

若 \(\sum q_j(z_j-R)^2=0\)，则 \(z_j=R\)，故 \(m_j=(1+\epsilon R)d_j\)。旧 KKT 对任一旧线性可行 \(\nu\) 给

\[
(1+\epsilon R)\nu\cdot d=\nu\cdot m
\le M=(1+\epsilon R)Q,
\]

所以旧 \(\lambda\) 本身线性最优。raw 径向族现在将所有体积同乘
\(c_t=1+t\epsilon R\)，所有半径同乘 \(s_t=c_t^{1/n}\)。如果 packing clique polytope 在该区间不变，就有
\(Q_{\rm lin}(t)=c_tQ\)。

轴平行 boxes 的共同半径放大满足

\[
\left|\bigcup_jQ(y_j,sr_j)\right|
\le s^n\left|\bigcup_jQ(y_j,r_j)\right|\qquad(s\ge1).             \tag{13}
\]

证明：全体缩放 \(1/s\) 后只剩中心由 \(y_j\) 收缩为 \(y_j/s\)。逐坐标收缩，每条一维截线是固定半长区间的共同中心收缩，其并集长度不增加。其有限 piecewise-linear 证明是：每个连通分量右端所属区间的中心不小于左端所属区间中心，否则左区间也会越过右端；故分量长度关于中心扩张参数的斜率非负。截线积分并逐坐标应用即得 (13)。

因此在上述稳定 packing 区间内

\[
V_t\le c_tV,\qquad V_t-RQ_{\rm lin}(t)\le0.                    \tag{14}
\]

这**不是 hard-family 反例**：没有声称存在满足 hard 及此平台条件的近极值族。它定位了局部径向估计的限制：仅靠方差项、正则势换写和稳定-face 响应不能强迫完整正 \(D\)。必须使用真正的全局几何限制、发生的 clique 改变或同一合法来源的有限共同更新。

## 5. 全局近极值权限没有消去有限步费用

若 \(R>S_N-\delta\)，每个实际至多 \(N\) 标签几何族满足

\[
V(t)-RQ_\epsilon(t)<\delta Q_\epsilon(t).                        \tag{15}
\]

在基线处左边为零，但除以 \(t\) 后，右边保留 \(\delta Q/t\)。固定 \(\delta>0\) 时不能令 \(t\downarrow0\) 声称 (11) 非正。选择随 \(\delta\) 变化的实际有限步还需统一控制合法 chamber、最小 \(v_j\)、最小 \(\lambda_j\)、face slack 与 Taylor 余项；目前没有这些统一控制。canonical last-bad 的远端分支跳跃更不能由局部导数覆盖。

要完成本路，仍须对一次合法有限完整更新证明大于 \(\delta Q_\epsilon'\) 的统一正增量，或直接证明合同的完整 \(D\) 下界。现有 (3)、(5)、(11) 各自保留了其真实费用；没有一式已获得所需统一符号。

## 6. 实际计算与停止点

本机 Python/SymPy 1.14.0 对 (1) 的逐标签 KKT 化简及 (2) 的完整展开作精确符号检查，两残差均为零；实际 elapsed 0.0121 秒，进程 max RSS 68,009,984 bytes。这仅验证代数，不验证 hard 或全局付款。独立敏感度核查及真实小样本几何控制见同目录 `regularized_audit.md`；其控制样本不在 hard 分支。

最终缺口仍是一笔完整费用：怎样利用全局近极值族的实际 cube 几何，使真实 receiver 变化/重叠、有限新 clique 容量变化及正则转换费共同产生统一正净增益。尚无可提交数值判别的、有理由足以支付该费用的普适不等式。本文件保留这一缺口后停止，不继续添加无价格局部工具。
