# R636 numerical certificate archive

Run from this directory with Python 3.12:

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python verify.py

For this machine, the Python executable is /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python. The verifier removes old SUMMARY.json and old result files before running the two primary batches and then the independent audit. It raises on failure and writes SUMMARY.json only on success. Each stage uses min(os.cpu_count(), number of tasks) single-thread workers, with the stages sequential. The exact deterministic parameters are defined by check.py and multi.py; their hashes, output hashes, interpreter, command, actual worker counts and CPU count are recorded in SUMMARY.json.

The two primary JSONs contain 88 two-label and 45 multi-label controls. The independent Fraction audit checks all 133 for the actual common positive-volume cube intersection and disjoint small cubes, strict root-bracket residual signs, derivative and weight-change signs, common-perturbation identities and near-face/near-tie classifications. The true Q derivative includes changing weights, while the regularized envelope includes an additional logarithmic term; neither can generally be replaced by the frozen-weight term.

The independent audit did not reconstruct or compare every author log-bound endpoint hash: primary output retains hashes rather than explicit endpoint values. It proves required log signs via 0<lambda<1 and checks the strict root brackets and derivative signs by rational intervals. This is finite same-intersection KKT geometry, not a proof of a hard-family estimate or general dimension bound.

The stored summary is a successful local run using Python 3.12.14, with 15 workers in each sequential stage. /usr/bin/time -l reported wall 3.13s, total user 18.48s and maximum RSS 28,590,080 bytes; worker-specific resource data are in primary results. The four scripts, two primary JSONs, independent JSON and SUMMARY.json are the complete archive; no external source paths are needed by the scripts.
