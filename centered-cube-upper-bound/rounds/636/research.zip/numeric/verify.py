#!/usr/bin/env python3
"""Run two primary batches and independent rational audit; fail closed."""
import hashlib,json,os,platform,resource,shlex,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent
summary=P/'SUMMARY.json';summary.unlink(missing_ok=True)
for name in ('two_results.json','multi_results.json','independent_results.json'):(P/name).unlink(missing_ok=True)
if not __debug__:raise RuntimeError('Run without python -O')
start=time.monotonic();cpu=time.process_time();env=os.environ.copy();env.update({'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'})
def run(script,destination=None):
 t=time.monotonic();x=subprocess.run([sys.executable,str(P/script)],cwd=P,env=env,capture_output=True,text=True,check=True)
 if destination:(P/destination).write_text(x.stdout)
 return {'wall_s':time.monotonic()-t,'command':shlex.join([sys.executable,script])}
stages=[run('check.py','two_results.json'),run('multi.py','multi_results.json'),run('audit.py')]
two=json.loads((P/'two_results.json').read_text());multi=json.loads((P/'multi_results.json').read_text());ind=json.loads((P/'independent_results.json').read_text());assert two['cases']==88 and multi['cases']==45 and ind['status']=='PASS' and ind['cases']==133
files=[P/x for x in ('check.py','multi.py','audit.py','verify.py','two_results.json','multi_results.json','independent_results.json')]
result={'status':'PASS','scope':'finite common-intersection KKT geometry; not a hard-family theorem; independent audit does not match author log-bound endpoint hashes','cases':{'two':88,'multi':45,'independent':133},'workers':{'two':two['workers'],'multi':multi['workers'],'independent':ind['workers']},'cpu_count':os.cpu_count(),'interpreter':sys.executable,'python':sys.version,'platform':platform.platform(),'command':shlex.join([sys.executable,*sys.argv]),'environment':{x:os.environ.get(x) for x in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','PYTHONDONTWRITEBYTECODE')},'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'stages':stages,'wall_s':time.monotonic()-start,'cpu_parent_s':time.process_time()-cpu,'max_rss_parent_platform_units':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
summary.write_text(json.dumps(result,indent=2)+'\n');print('PASS two 88 + multi 45 + independent 133')
