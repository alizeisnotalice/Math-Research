#!/usr/bin/env python3
from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from hashlib import sha256
import os,sys,json,time,resource,platform
sys.set_int_max_str_digits(0)
def digest(x):return sha256(str(x).encode()).hexdigest()
def chk(task):
 start=time.perf_counter();cpu=time.process_time();n,s,k=task;a=32*n;P=F(a+1,a)**n;eps=F(1,64)/P;c=eps/a**n;d1=F(2**n);d2=(2*s)**n;dd=n*2**n*s**(n-1);maxd=max(d1,d2)
 assert F(1,2)>F(1+s,a) and F(3,4)<=s<=F(5,4)
 if s==1:
  assert d1==d2
  return {'n':n,'s':str(s),'precision':0,'z_lo':'2','z_hi':'2','correction':'0','Qprime':str(dd/2),'regularized_envelope':'Qprime - c*d2prime*log(2)','strict_envelope_difference':True,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
 def residual(z):
  G=maxd*(1+c*z)
  return sum((c*d/(G-d) for d in (d1,d2)),F(0))-1
 lo=F(1);hi=F(2);assert residual(lo)>0 and residual(hi)<0
 for _ in range(k):
  mid=(lo+hi)/2
  if residual(mid)>0:lo=mid
  else:hi=mid
 assert residual(lo)>0 and residual(hi)<0
 L=maxd*(1+c*lo);U=maxd*(1+c*hi)
 def denom(G):return d1*(G-d2)**2+d2*(G-d1)**2
 # lambda2' = c Γ d2' d1/[d1(Γ-d2)^2+d2(Γ-d1)^2] > 0.
 lower=c*L*dd*d1/denom(U);upper=c*U*dd*d1/denom(L)
 assert 0<lower<=upper
 diff=d2-d1;edge1=diff*lower;edge2=diff*upper;corrlo=min(edge1,edge2);corrhi=max(edge1,edge2)
 assert (corrlo>0 and s>1) or (corrhi<0 and s<1)
 lamlo=c*d2/(U-d2); lamhi=c*d2/(L-d2)
 Qlo=dd*lamlo+corrlo; Qhi=dd*lamhi+corrhi
 # Exact log bounds 1-1/x <= log(x) <= x-1 for x>0.
 Elo=dd*lamlo+c*dd*(1-1/lamlo); Ehi=dd*lamhi+c*dd*(lamhi-1)
 assert Qlo<=Qhi and Elo<=Ehi
 return {'n':n,'s':str(s),'precision':k,'z_lo':str(lo),'z_hi':str(hi),'Qprime_sign':'positive' if Qlo>0 else ('negative' if Qhi<0 else 'undetermined'), 'Qprime_interval_sha256':[digest(Qlo),digest(Qhi)], 'frozen_interval_sha256':[digest(dd*lamlo),digest(dd*lamhi)], 'envelope_interval_sha256':[digest(Elo),digest(Ehi)], 'correction_sign':'positive' if s>1 else 'negative','correction_lo_sha256':digest(corrlo),'correction_hi_sha256':digest(corrhi),'correction_lo_num_bits':abs(corrlo.numerator).bit_length(),'correction_lo_den_bits':corrlo.denominator.bit_length(),'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
if __name__=='__main__':
 t=time.perf_counter();N=[1,2,4,8,16,32,64,128];spec=[]
 for n in N:
  for s in (F(3,4),F(1),F(5,4)):spec.append((n,s,64))
  for k in (8,32,128,512):
   for sign in (-1,1):spec.append((n,F(1)+sign*F(1,2**k),64))
 workers=min(os.cpu_count() or 1,len(spec));
 with ProcessPoolExecutor(max_workers=workers) as pool:res=list(pool.map(chk,spec))
 out={'n':N,'cases':len(spec),'workers':workers,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'platform':platform.platform(),'wall_s':time.perf_counter()-t,'results':res}
 print(json.dumps(out,indent=2))
