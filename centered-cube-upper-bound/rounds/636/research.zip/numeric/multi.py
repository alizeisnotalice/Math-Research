#!/usr/bin/env python3
from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor
from hashlib import sha256
from pathlib import Path
import json,os,sys,time,resource,platform
sys.set_int_max_str_digits(0)
def digest(x):return sha256(str(x).encode()).hexdigest()
def work(task):
 t=time.perf_counter();cpu=time.process_time();n,N,k,typ=task;a=32*n;eps=F(1,64)/F(a+1,a)**n;c=eps/a**n
 assert N<=2**n and F(1,2)>F(5,2*a)
 if typ=='common':
  # Equal cubes with different centers: all radii 1 and all equal variation.
  d=F(2**n);lam=F(1,N); Q=d; Qprime=n*d
  return {'n':n,'N':N,'mode':typ,'Qprime':str(Qprime),'lambda_correction':'0','envelope_correction_sign':'negative','root_z':str(N),'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-t,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
 h=F(1,2**k);s=1-h;d=F(2**n);sm=(2*s)**n;dd=n*d
 ties=1 if typ=='single' else N//2;lowerN=N-ties
 assert F(3,4)<=s<1 and 1<=ties<N
 relgap=(d-sm)/d
 regime='near_face' if relgap>100*N*c else ('near_tie' if relgap<c/100 else 'intermediate')
 # Aggregate identical d_i, but keep all label multiplicities and simplex capacity.
 def residual(z):
  G=d*(1+c*z);return ties*c*d/(G-d)+lowerN*c*sm/(G-sm)-1
 lo=F(1) if ties==1 else F(ties);hi=F(N)
 assert residual(lo)>0 and residual(hi)<0
 for _ in range(64):
  mid=(lo+hi)/2
  if residual(mid)>0:lo=mid
  else:hi=mid
 assert residual(lo)>0 and residual(hi)<0
 L=d*(1+c*lo);U=d*(1+c*hi)
 # One max label varied: Q'−λ_p d_p' = c Γ d_p' Σ_i≠p d_i(d_p−d_i)/(Γ−d_i)^2 / ((Γ−d_p)^2 Σ_i d_i/(Γ−d_i)^2).
 # Equal-max labels contribute zero to numerator but remain in denominator.
 def B(G):return ties*d+lowerN*sm*((G-d)/(G-sm))**2
 Bmin=ties*d;Bmax=ties*d+lowerN*sm
 poslo=lowerN*sm*(d-sm)/(U-sm)**2;poshi=lowerN*sm*(d-sm)/(L-sm)**2
 corrlo=c*L*dd*poslo/Bmax;corrhi=c*U*dd*poshi/Bmin
 assert 0<corrlo<=corrhi
 lamlo=c*d/(U-d);lamhi=c*d/(L-d)
 Qlo=lamlo*dd+corrlo;Qhi=lamhi*dd+corrhi
 Elo=dd*lamlo+c*dd*(1-1/lamlo);Ehi=dd*lamhi+c*dd*(lamhi-1)
 return {'n':n,'N':N,'mode':typ,'k':k,'regime':regime,'relative_gap_over_c_sha256':digest(relgap/c),'ties':ties,'smaller':lowerN,'z_lo':str(lo),'z_hi':str(hi),'correction_sign':'positive','lambda_correction_bounds_sha256':[digest(corrlo),digest(corrhi)],'Qprime_sign':'positive' if Qlo>0 else ('negative' if Qhi<0 else 'undetermined'),'Qprime_bounds_sha256':[digest(Qlo),digest(Qhi)],'envelope_bounds_sha256':[digest(Elo),digest(Ehi)],'lambda_max_bounds_sha256':[digest(lamlo),digest(lamhi)],'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-t,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
if __name__=='__main__':
 t=time.perf_counter(); tasks=[]
 for n,N in [(1,2),(2,4),(7,128),(16,256),(64,256)]:
  tasks.append((n,N,0,'common'))
  for k in (8,32,512,16*n+512):
   for typ in ('single','ties'):tasks.append((n,N,k,typ))
 workers=min(os.cpu_count() or 1,len(tasks));
 with ProcessPoolExecutor(max_workers=workers) as p:out=list(p.map(work,tasks))
 print(json.dumps({'cases':len(tasks),'workers':workers,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'platform':platform.platform(),'wall_s':time.perf_counter()-t,'results':out},indent=2))
