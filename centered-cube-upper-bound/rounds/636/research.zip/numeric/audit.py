#!/usr/bin/env python3
import json,sys,platform,time,resource,hashlib,itertools,collections,concurrent.futures,os
from pathlib import Path
from fractions import Fraction as F
sys.set_int_max_str_digits(0)
P=Path(__file__).resolve().parent; SRC=P
def param(n):
 a=32*n;c=F(1,64)*F(a,a+1)**n/a**n;return a,c

def plus(a,b):return a[0]+b[0],a[1]+b[1]
def mul(a,b):
 v=[x*y for x in a for y in b];return min(v),max(v)
def div(a,b):
 assert b[0]>0
 return mul(a,(1/b[1],1/b[0]))
def sign(a):return 'positive' if a[0]>0 else 'negative' if a[1]<0 else 'unknown'
def calculate(case):
 typ,z=case;n=z['n'];a,c=param(n);d=F(2**n); mode=z.get('mode');is_common=mode=='common';is_two=typ=='two';count=2 if is_two else z['N']
 assert 0<F(1,8)<F(3,4)-F(1,2) and F(5,2)/a<F(1,2)
 # Explicitly produce all distinct cube centers and compare L-infinity separations.
 centers=([tuple([F(0)]*n),tuple([F(1,2)]+[F(0)]*(n-1))] if is_two else list(itertools.islice(itertools.product((F(0),F(1,2)),repeat=n),count)))
 assert len(centers)==count and len(set(centers))==count
 assert all(max(abs(u-v) for u,v in zip(x,y))>=F(1,2) for x,y in itertools.combinations(centers,2))
 if is_two:
  s=F(z['s']);dp=(2*s)**n;other=d;ties=1;groups=[(1,other),(1,dp)]; deriv=n*dp/s
 elif is_common:
  assert z['root_z']==str(count) and z['lambda_correction']=='0'
  actual=n*d # r_j all 1 and all r_j'=1; Q=sum d_j/N=d
  assert F(z['Qprime'])==actual and z['envelope_correction_sign']=='negative'
  return {'type':typ,'n':n,'N':count,'mode':'common','status':'pass','root':str(count),'qprime':str(actual)}
 else:
  k=z['k'];s=1-F(1,2**k);dp=d;other=(2*s)**n;ties=z['ties'];groups=[(ties,dp),(count-ties,other)];deriv=n*dp
  assert count==ties+z['smaller'] and 1<=ties<count and F(3,4)<=s<=F(5,4)
 assert all(F(3,4)<=F(r)<=F(5,4) for r in ([s] if is_two else [s,1]))
 D=max(x for _,x in groups);zl=F(z['z_lo']);zh=F(z['z_hi']); exact=zl==zh
 def residual(t):return sum(F(m)*c*x/(D*(1+c*t)-x) for m,x in groups)-1
 if exact: assert is_two and s==1 and zl==2 and residual(zl)==0
 else:assert residual(zl)>0 and residual(zh)<0
 gl=D*(1+c*zl);gh=D*(1+c*zh);gi=(gl,gh)
 I=(F(0),F(0))
 for mult,x in groups:I=plus(I,div((mult*x,mult*x),((gh-x)**2,(gl-x)**2)))
 p_lo,p_hi=gl-dp,gh-dp
 assert p_lo>0
 inv=div((deriv,deriv),(p_lo*p_lo,p_hi*p_hi)); qprime=plus(div(mul(gi,inv),I),(-c*deriv,-c*deriv))
 qs=sign(qprime)
 if exact:
  assert F(z['Qprime'])==deriv/2 and z['correction']=='0' and z['strict_envelope_difference']
 elif qs=='unknown':raise AssertionError(('Q prime unresolved',typ,n,s,k if not is_two else ''))
 else:assert qs==z['Qprime_sign'],(typ,n,z,qs)
 # Differentiate weights directly: dQ-frozen = Σ_i d_i λ_i'; group-cancellation exact.
 # For single perturbed p, Γ*c*d'_p /(Γ-d_p)^2/S × Σ_{i≠p}d_i(d_p-d_i)/(Γ-d_i)^2.
 difference=dp-other
 correction='positive' if difference>0 else 'negative' if difference<0 else 'zero'
 if not exact:assert correction==z['correction_sign']
 if not is_two:
  ratio=(d-other)/d/c
  regime='near_face' if ratio>100*count else 'near_tie' if ratio<F(1,100) else 'intermediate'
  assert z['regime']==regime,(z['regime'],regime)
 # λ_j>0 and Σλ_j=1 for true Γ; at least 2 labels makes λ_p<1.
 # Hence log λ_p<0 and Fopt' is strictly less than frozen, not equal to Q'.
 return {'type':typ,'n':n,'N':count,'mode':mode or 'two','s':str(s),'status':'pass','Qprime_sign':qs,'weight_correction':correction,'root_z':str(zl) if exact else 'strict bracket','regime':z.get('regime')}
if __name__=='__main__':
 start=time.monotonic();cpu=time.process_time(); inputs=[SRC/'two_results.json',SRC/'multi_results.json'];jobs=[]
 for tag,p in zip(('two','multi'),inputs):
  d0=json.loads(p.read_text());assert d0['cases']==len(d0['results']);jobs.extend((tag,x) for x in d0['results'])
 workers=min(os.cpu_count() or 1,len(jobs))
 with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:out=list(pool.map(calculate,jobs))
 assert len(out)==133
 R={'status':'PASS','cases':len(out),'outputs':out,'python':sys.version,'interpreter':sys.executable,'platform':platform.platform(),'workers':workers,'wall_s':time.monotonic()-start,'cpu_parent_s':time.process_time()-cpu,'max_rss_parent_platform_units':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'finite common-intersection KKT geometry; not a hard-family theorem; source bound hashes not independently matched'}
 (P/'independent_results.json').write_text(json.dumps(R,indent=2)+'\n');print('PASS',len(out))
