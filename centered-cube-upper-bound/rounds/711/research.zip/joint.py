"""R711: original high loss simultaneously with small total normalized depth.

Local rigorous backend: python-flint Arb 384 bits. Remote crosscheck: existing
MacBook Python Decimal via stdin, no remote files and no package installation.
"""
from pathlib import Path
import hashlib
import json
import platform
import socket
import subprocess
import sys
from flint import arb,ctx

BASE=Path(__file__).resolve().parent
ns={'__name__':'r711_readonly_family'}
exec(compile((BASE/'family.py').read_text(),str(BASE/'family.py'),'exec'),ns)
compute=ns['compute'];floor_unique=ns['floor_unique']


def text(x):
    return x.str(38)


def calculate(b,bits=384):
    raw=compute(b,bits);ctx.prec=bits
    n=1<<b;a=32*n;k=1<<(b//2);m=b//4;C=65536
    A=arb;L=A(n).log();log2=A(2).log();t=A(k)/log2
    R=A(raw['R']);d=A(raw['d'])/4;r=A(1)/a
    J=int(raw['full_layer_count_J']);Wp=A(raw['W_prime']);W=A(raw['W'])
    threshold=3*b//16+1
    nf=max(0,floor_unique(A(a)/2*((d-r)/R-A(6)/n)-1))
    p=A(nf)/a;B=k//2
    mass=(B*(-p).log1p()).exp();tail=mass
    for j in range(1,threshold):
        mass*=A(B+1-j)/j*p/(1-p);tail+=mass
    high_count_probability=(1-tail)**2
    # All early s_i>2. Only active coordinates contribute to depth.
    mean_depth=k*(d+r)**2/16
    cutoff=L/(384*C)
    markov=mean_depth/cutoff
    inactive_boundary=-((n-k)*(-A(2)/a).log1p()).expm1()
    joint_probability=high_count_probability-markov
    full_mass=-(-J*Wp/t).expm1()
    layer_min_weight=(-Wp/t).exp()
    joint_lower=full_mass*layer_min_weight*(inactive_boundary/W)*joint_probability if joint_probability>0 else A(0)
    beta=(-n*A(a).log()).exp()
    receiving_clock=(A(k//2)*log2-n*A(a).log()).exp()
    missing=(receiving_clock+beta)/t
    all_pool_lower=joint_lower-missing if joint_lower>missing else A(0)
    high_lower=full_mass*layer_min_weight*(inactive_boundary/W)*high_count_probability
    logVT=A(n+k//2)*log2-n*A(a).log()
    logratio=A(raw['log_D_over_VT'])
    logD=logVT+logratio
    VT=logVT.exp();D=logD.exp()
    norm_upper=(-logratio-A(4*k).log())/A(10).log()
    # This lower bound is optional: eta_H=1/4 and A=0; positive part only.
    excess=all_pool_lower-A('0.25')
    log10_excess_lower=(excess.log()-A(k).log()-logratio)/A(10).log() if excess>0 else None
    assert d>r and d+r<1 and A(3)/4-r>0
    assert 2/a>r  # inactive tiny coordinates lie inside all early parent intervals
    assert joint_lower>=0 and joint_lower<=high_lower and high_lower<A('0.5')
    assert cutoff>0 and mean_depth>=0 and markov>0
    assert all(x.is_finite() for x in [VT,D,logVT,logD,norm_upper,all_pool_lower])
    return {'b':b,'n':f'2^{b}','precision_bits':bits,'receiver_offset_d_over_4':text(d),
            'favorable_digits':str(nf),'mean_favorable_per_sign':text(B*p),'m0':threshold,
            'high_count_probability_lower':text(high_count_probability),
            'expected_depth_upper':text(mean_depth),'depth_cutoff':text(cutoff),
            'Markov_deep_probability_upper':text(markov),
            'inactive_boundary_over_full_boundary':text(inactive_boundary/W),
            'fixed_origin_high_weight_lower':text(high_lower),
            'fixed_origin_joint_weight_lower':text(joint_lower),
            'fixed_origin_joint_weight_upper':'1/2',
            'every_qualified_pool_joint_weight_lower':text(all_pool_lower),
            'late_plus_trigger_weight_upper':text(missing),
            'VT':text(VT),'D':text(D),'log10_VT':text(logVT/A(10).log()),
            'log10_D':text(logD/A(10).log()),'log_D_over_VT':text(logratio),
            'log10_VT_over_4sqrt_n_D':text(norm_upper),
            'log10_positive_excess_over_sqrt_n_D_lower':text(log10_excess_lower) if log10_excess_lower is not None else None,
            '_crosscheck':(joint_lower,high_lower,logratio,norm_upper),
            '_remote_values':[float(joint_lower),float(high_lower),float(logratio),float(norm_upper)]}


REMOTE_CODE=r'''
from decimal import Decimal as D,localcontext
import json,socket,sys
with localcontext() as c:
 c.prec=110
 rows=[]
 for b in [64,72,80]:
  n=1<<b;a=32*n;k=1<<(b//2);m=b//4;C=65536
  ln2=D(2).ln();L=D(n).ln();t=D(k)/ln2
  g=(1-D(2)/a).ln();W=1-(D(n)*g).exp();Wp=W/D(1<<m)
  # beta0 is omitted only in this approximate remote crosscheck: it is
  # far below Decimal's exponent range; the local Arb calculation keeps it.
  J=int(D(k)/Wp);e=D(k)-J*Wp
  logR=ln2-D(J+1)*g;R=logR.exp();d=D(2)/(D(C)*k).sqrt()/4;r=D(1)/a
  nf=max(0,int(D(a)/2*((d-r)/R-D(6)/n)-1));p=D(nf)/a;B=k//2;m0=3*b//16+1
  mass=(D(B)*(1-p).ln()).exp();tail=mass
  for j in range(1,m0):
   mass*=D(B+1-j)/j*p/(1-p);tail+=mass
  highprob=(1-tail)**2
  mean=D(k)*(d+r)**2/16;cutoff=L/(384*C);markov=mean/cutoff
  complement=1-(D(n-k)*g).exp()
  full=D('0.5') # omitted partial tail is below 1e-20 here
  # Retain exact finite-J full-clock value, unlike the negligible beta0.
  full=1-(-D(J)*Wp/t).exp()
  high=full*(-Wp/t).exp()*complement/W*highprob
  joint=full*(-Wp/t).exp()*complement/W*max(D(0),highprob-markov)
  logP=D(n)*g-Wp/t
  # P^J<exp(-1000), deliberately omitted in this numerical crosscheck.
  assert D(J)*logP < -1000
  logearly=D(n)*logR+((1-(-Wp/t).exp())/(1-logP.exp())).ln()
  logVTnorm=-D(n)*D(a).ln()+D(k//2)*ln2
  logratio=logearly-logVTnorm
  norm=(-logratio-D(4*k).ln())/D(10).ln()
  rows.append({'b':b,'J':str(J),'favorable_digits':str(nf),'values':[str(joint),str(high),str(logratio),str(norm)]})
 print(json.dumps({'host':socket.gethostname(),'python':sys.version,'backend':'Decimal110 approximate independent crosscheck; beta0 and exponentially small D corrections omitted','rows':rows}))
'''


def main():
    results=[]
    for b in [64,72,80]:
        low=calculate(b,256);high=calculate(b,384)
        assert low['favorable_digits']==high['favorable_digits']
        for x,y in zip(low['_crosscheck'],high['_crosscheck']):
            assert x.overlaps(y)
        del high['_crosscheck'];results.append(high)
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math',
             '/Users/zhengzhihao/.venv/bin/python -B -']
    remote=subprocess.run(command,input=REMOTE_CODE,text=True,capture_output=True,timeout=30)
    remote_record={'command':command,'exit_code':remote.returncode,'stderr':remote.stderr}
    if remote.returncode==0:
        remote_data=json.loads(remote.stdout);remote_record['result']=remote_data
        for local,other in zip(results,remote_data['rows']):
            assert local['b']==other['b'] and local['favorable_digits']==other['favorable_digits']
            for x,y in zip(local['_remote_values'],other['values']):
                assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        remote_record['crosscheck_passed']=True
    else:
        remote_record['stdout']=remote.stdout
    for row in results:
        del row['_remote_values']
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'source_family_sha256':hashlib.sha256((BASE/'family.py').read_bytes()).hexdigest(),
            'local_backend':'Arb256 and384 bits; all displayed bounds from384-bit enclosures',
            'rows':results,'remote':remote_record,
            'precise_target':'H_joint(j,x,z)=sum_{i in original high mask, e_i(x)<=log(n)/(384*65536)} theta_i, e_i=sum_k dist(x_k,[y_ik-s_i,y_ik+s_i])/s_i',
            'input_scope':['Same finite clock, radii, trigger, owner volumes and receiver sign count as R710; active receiver offset reduced to d/4.',
                           'Every receiver owner is a full tiny core and all points of every owner satisfy the reported bounds; no point sampling.',
                           'VT=2^n*a^(-n)*2^(sqrt(n)/2). D is the full original greedy value and is unchanged by reducing receiver offsets.'],
            'bound_derivation':['For inactive nonpassive coordinates |x_k|<=1/a<s_i/a, so their parent intervals contain x_k. Positive-folded passive intervals contain x_k near3/4. Only active coordinates contribute to e_i.',
                               'The positive-part distance is convex in each source midpoint coordinate. Uniform midpoint-grid averaging is bounded above by its continuous uniform integral, giving E e_i<=k(d/4+1/a)^2/(4s_i^2)<=k(d/4+1/a)^2/16.',
                               'The inactive boundary event has probability1-rho^(n-k) and is independent of both active high-count events and active total depth. Hence the joint count probability is at least inactive_boundary/W times ((1-binomial_lower_tail)^2-Markov)_+.',
                               'Every source counted has at least m0 positive and m0 negative conflicts, hence original B>=2*m0*log2>(3/8)log n; all source radii remain in the original near range and u=h.',
                               'Multiply joint count probability by the full-layer mass1-exp(-J W_prime/t) and conservative actual-weight factor exp(-W_prime/t). Partial last layer and trigger are omitted from this lower bound.',
                               'Any later qualified pool can omit at most late-plus-trigger weight from early sources, since its total weight is>=1/2 while total early weight is<1/2. Subtract the stated missing upper to obtain a common lower for every qualified pool.',
                               'Integrating multiplies the pointwise lower by actual VT. Fixed-origin upper is VT/2. For a menu containing origin, the same upper and every-pool lower bound the minimum over the whole menu.'],
            'scope':['Markov and midpoint convexity are conservative bounds, not an exact joint probability evaluation.',
                     'The reported original normalization upper VT/(4sqrt(n)D) and positive-excess lower use full D once; no source budget is repeated.',
                     'Remote CPU Decimal run is an approximate crosscheck, not the rigorous certificate; beta0 and negligible D corrections are retained locally by Arb.',
                     'MacBook data mount absent; remote computation runs through stdin without creating remote files or caches. No GPU backend is relevant to Arb or Decimal scalar arithmetic.']}
    output=Path(__file__).with_name('joint.json')
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'remote_exit':remote.returncode,'remote_crosscheck':remote_record.get('crosscheck_passed',False),
                      'rows':[{k:r[k] for k in ['b','fixed_origin_joint_weight_lower','every_qualified_pool_joint_weight_lower','Markov_deep_probability_upper','log10_VT_over_4sqrt_n_D']} for r in results]},indent=2))


if __name__=='__main__':
    main()
