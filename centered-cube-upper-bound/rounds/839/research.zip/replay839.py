"""Round 839 simultaneous deletion in a positive-width two-arm conditional library."""

from collections import Counter
from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction as F
from itertools import pairwise
import sys


LOG_TERMS = 30
LOG_BITS = 80
CASES = ((4, 2, F(1, 2), F(1)), (16, 4, F(1, 4), F(7, 5)),
         (64, 8, F(1, 2), F(5, 8)))


def series_log(x):
    assert 1 <= x <= 2
    t = (x-1)/(x+1)
    lo = 2*sum(t**(2*j+1)/(2*j+1) for j in range(LOG_TERMS))
    remainder = 2*t**(2*LOG_TERMS+1)/((2*LOG_TERMS+1)*(1-t*t))
    return lo, lo+remainder


LN2 = series_log(F(2))


def log_bounds(x):
    assert x >= 1
    power = x.numerator.bit_length() - x.denominator.bit_length()
    power -= x < F(2)**power
    lo, hi = series_log(x/(F(2)**power))
    low, high = lo+power*LN2[0], hi+power*LN2[1]
    denominator = 1 << LOG_BITS
    bounds = F(low*denominator//1, denominator), F(-(-high*denominator//1), denominator)
    assert bounds[0] <= low <= high <= bounds[1]
    return bounds


def phi_bounds(reference, load):
    assert reference > 0 and load > 0
    lo, hi = log_bounds(max(reference/load, load/reference))
    return 1/(load*(2+hi)**2), 1/(load*(2+lo)**2)


def primitive_bounds(reference, load):
    if load == 0:
        return F(0), F(0)
    lo, hi = log_bounds(max(reference/load, load/reference))
    if load <= reference:
        return 1/(2+hi), 1/(2+lo)
    return 1-1/(2+lo), 1-1/(2+hi)


def display(bounds):
    lo, hi = bounds
    assert lo <= hi
    with localcontext() as ctx:
        ctx.prec = 17
        ctx.rounding = ROUND_FLOOR
        lower = Decimal(lo.numerator)/Decimal(lo.denominator)
        ctx.rounding = ROUND_CEILING
        upper = Decimal(hi.numerator)/Decimal(hi.denominator)
    return f"[{lower}, {upper}]"


@dataclass(frozen=True)
class Packet:
    label: str
    axes: tuple
    mass: F

    def child(self):
        assert all(0 < low < high < 2 for low, high in self.axes)
        bits = tuple(lo//1 for lo, _ in self.axes)
        assert all(bit+1 > hi for bit, (_, hi) in zip(bits, self.axes, strict=True))
        return bits


@dataclass(frozen=True)
class Row:
    left: str
    right: str
    theta: F
    K: F
    H: int
    mass: F
    receiver_left: tuple
    receiver_right: tuple


def packets(left, right, dimensions, mass):
    labels = left + right
    denominator = 8*(len(labels)+1)
    width = F(1, denominator)
    patterns = ((0,)*dimensions, (1,)*dimensions, (1, 1)+(0,)*(dimensions-2))
    result = {}
    for index, label in enumerate(labels):
        bits = patterns[(index + index//5) % len(patterns)]
        offsets = ((2*index+1)*width,) + (F(1, 8),)*(dimensions-1)
        lo = tuple(bit + offset for bit, offset in zip(bits, offsets, strict=True))
        box = Packet(label, tuple((x, x+width) for x in lo), mass)
        assert box.child() == bits
        result[label] = box
    first_axes = sorted(packet.axes[0] for packet in result.values())
    assert all(first[1] < second[0] for first, second in pairwise(first_axes))
    for labels_at_end in (left, right):
        bit_pairs = {result[label].child()[:2] for label in labels_at_end}
        assert bit_pairs == {(0, 0), (1, 1)}
    return result, width


def instance(depth, dimensions, rho, packet_mass):
    assert depth >= 4 and depth % 2 == 0 and 0 < rho < 1
    chain_left = tuple(f"L{i}" for i in range(depth))
    chain_right = tuple(f"R{i}" for i in range(depth-1))
    hub = "Rshared"
    left = chain_left + ("Lcycle0", "Lcycle1", "Lisolated")
    right = chain_right + (hub, "Rcycle", "Risolated")
    source, width = packets(left, right, dimensions, packet_mass)
    w = packet_mass*rho**dimensions/2
    incidence = {}
    for i, v in enumerate(chain_right):
        incidence[chain_left[i], v] = w
        incidence[chain_left[i+1], v] = w
    incidence.update({(v, hub): w/2 for v in chain_left})
    cycle = frozenset((v, u) for v in ("Lcycle0", "Lcycle1") for u in (hub, "Rcycle"))
    incidence.update({edge: w for edge in cycle})
    incidence["Lisolated", "Risolated"] = w
    rows = {}
    receiver_cursor = F(0)
    for (first, second), frozen_weight in sorted(incidence.items()):
        first_bits, second_bits = source[first].child(), source[second].child()
        H = sum(x != y for x, y in zip(first_bits, second_bits, strict=True))
        K = rho**H
        assert source[first].mass == source[second].mass == packet_mass
        theta = frozen_weight/(K*packet_mass)
        assert 0 < theta <= 1
        original = theta*source[first].mass*source[second].mass
        # On the receiver rectangle each slot has marginal exactly Lebesgue:
        # use joint density 1/original and disjoint equal-length intervals.
        next_cursor = receiver_cursor + original
        first_interval = receiver_cursor, next_cursor
        second_interval = 1+receiver_cursor, 1+next_cursor
        rows[first, second] = Row(first, second, theta, K, H, original,
                                  first_interval, second_interval)
        assert (first_interval[1]-first_interval[0]) * (second_interval[1]-second_interval[0]) / original == original
        receiver_cursor = next_cursor
    for attr in ("receiver_left", "receiver_right"):
        intervals = sorted(getattr(row, attr) for row in rows.values())
        assert all(a[1] <= b[0] for a, b in pairwise(intervals))
    assert len(rows) == 3*depth+3
    return source, rows, cycle, hub, w, width


def loads(active, source, rows):
    at_anchor = dict.fromkeys(source, F(0))
    for key in active:
        row = rows[key]
        at_anchor[row.left] += row.K*row.theta*source[row.right].mass
        at_anchor[row.right] += row.K*row.theta*source[row.left].mass
    return at_anchor


def raw_mass(active, rows):
    return sum((rows[key].mass for key in active), F(0))


def gate_thresholds(source, w):
    return {label: F(7, 4)*w if label.startswith("L") else F(3, 2)*w for label in source}


def failed_edges(active, before, gates, rows):
    return {key for key in active
            if before[rows[key].left] < gates[rows[key].left]
            or before[rows[key].right] < gates[rows[key].right]}


def remove_simultaneously(depth, source, rows, cycle, hub, w):
    active = set(rows)
    removed = set()
    gates = gate_thresholds(source, w)
    history = [loads(active, source, rows)]
    initial_mass = raw_mass(active, rows)
    deletion_log = []
    while active:
        before = history[-1]
        delete = failed_edges(active, before, gates, rows)
        if not delete:
            break
        assert not delete & removed
        next_active = active - delete
        after = loads(next_active, source, rows)
        delta = loads(delete, source, rows)
        for anchor in source:
            assert before[anchor] - after[anchor] == delta[anchor] >= 0
        mass_lost = raw_mass(delete, rows)
        assert raw_mass(active, rows) == raw_mass(next_active, rows) + mass_lost
        both_fail = sum(before[rows[key].left] < gates[rows[key].left]
                        and before[rows[key].right] < gates[rows[key].right] for key in delete)
        left_below = sorted(mark for mark in source if mark.startswith("L") and 0 < before[mark] < gates[mark])
        right_below = sorted(mark for mark in source if mark.startswith("R") and 0 < before[mark] < gates[mark])
        deletion_log.append((len(delete), mass_lost, both_fail, left_below, right_below))
        removed.update(delete)
        active = next_active
        history.append(after)
    assert len(deletion_log) == depth-1
    assert deletion_log[0][2] == 1 and deletion_log[0][3] == ["L0", f"L{depth-1}", "Lisolated"]
    assert deletion_log[1][4] == ["R0", f"R{depth-2}"]
    assert history[0]["L0"] == F(3, 2)*w and history[1]["R0"] == w
    assert active == cycle and len(removed) == 3*depth-1
    assert set(rows) == active | removed and not active & removed
    stable_load = loads(active, source, rows)
    assert history[-1] == stable_load and stable_load[hub] == 2*w
    assert not failed_edges(active, stable_load, gates, rows)
    assert initial_mass == raw_mass(active, rows) + sum(out[1] for out in deletion_log)
    return history, deletion_log, active


def certify_costs(source, history, reference):
    costs, unbumped = {}, {}
    for label in sorted(source):
        values = [snapshot[label] for snapshot in history]
        cost_lo = cost_hi = plain = F(0)
        for before, after in pairwise(values):
            assert 0 <= after <= before
            delta = before - after
            if delta > 0:
                f_lo, f_hi = phi_bounds(reference, before)
                cost_lo += delta*f_lo
                cost_hi += delta*f_hi
                plain += delta/before
        if values[0] != values[-1]:
            start = primitive_bounds(reference, values[0])
            end = primitive_bounds(reference, values[-1])
            assert cost_hi <= start[0] - end[1] <= 1
        assert 0 <= cost_lo <= cost_hi <= 1
        costs[label] = cost_lo, cost_hi
        unbumped[label] = plain
    return costs, unbumped


def verify_case(depth, dimensions, rho, packet_mass):
    source, rows, cycle, hub, w, width = instance(depth, dimensions, rho, packet_mass)
    history, deletion_log, stable = remove_simultaneously(depth, source, rows, cycle, hub, w)
    reference = 4*w
    costs, plain = certify_costs(source, history, reference)
    assert plain[hub] == sum(F(1, i) for i in range(3, depth//2+3))
    hub_loads = [history[0][hub]/w] + [
        after[hub]/w for before, after in pairwise(history) if before[hub] != after[hub]
    ]
    assert hub_loads == list(range(depth//2+2, 1, -1))
    max_lo = max(lo for lo, _ in costs.values())
    max_hi = max(hi for _, hi in costs.values())
    print("case depth", depth, "n", dimensions, "rho", rho, "packet mass", packet_mass,
          "packet side", width, "shared parent [0,2)^n")
    print("  actual H counts", dict(sorted(Counter(row.H for row in rows.values()).items())),
          "K=probability of independent rho successes on differing axes")
    print("  theta0 min/max", min(row.theta for row in rows.values()),
          max(row.theta for row in rows.values()), "nonproduct first two child bits 00/11")
    print("  one complete route: small event L<7w/4 or R<3w/2; w", w, "phi reference", reference)
    print("  rounds", len(deletion_log), "distinct deletions", sum(x[0] for x in deletion_log),
          "stable rows", len(stable), "stable original mass", raw_mass(stable, rows))
    print("  exact first step and next step positive endpoints below gate",
          deletion_log[0][3:], deletion_log[1][3:], "overlapping gate failure removed once", deletion_log[0][2])
    print("  original mass initial", raw_mass(rows, rows),
          "removed", sum(x[1] for x in deletion_log))
    print("  hub physical load levels L_k/w", [int(x) for x in hub_loads])
    print("  max anchored bumped cost", display((max_lo, max_hi)),
          "hub bumped cost", display(costs[hub]), "hub unbumped exact", plain[hub],
          "decimal", display((plain[hub], plain[hub])))
    print("  stable hub load with its own theta_k", history[-1][hub],
          "other stable anchor load", 2*w)
    print("  last deleting step original mass", deletion_log[-1][1],
          "final nonempty K2,2 passes both gates with its own density")


def route_h(left, right, cut):
    bit_indexes = []
    for source in (left, right):
        child = tuple((lo+1-cut)//1 for lo, _ in source.axes)
        assert all((hi+1-cut)//1 == bit for (_, hi), bit in zip(source.axes, child, strict=True))
        bit_indexes.append(child)
    first, second = bit_indexes
    assert tuple(v//2 for v in first) == tuple(v//2 for v in second)
    return sum(a != b for a, b in zip(first, second, strict=True))


def verify_routed_boundary():
    cuts = (F(0), F(1, 4), F(1, 2))
    weights = (F(1, 2), F(1, 6), F(1, 3))
    assert sum(weights) == 1
    rho, theta, threshold = F(1, 2), F(1, 2), F(1, 4)
    epsilon = F(1, 2048)
    locations = (
        ("A", (F(-1, 8), F(-1, 8)), (F(3, 8), F(1, 8)), (2, 1, 0)),
        ("B", (F(-1, 8), F(-1, 8)), (F(5, 8), F(3, 8)), (2, 2, 1)),
        ("C", (F(-1, 8), F(5, 8)), (F(5, 8), F(3, 4)), (1, 1, 1)),
    )
    by_key = {}
    print("Three actual shifted 2D absolute routes; E includes all routes on every row.")
    print("  fine cuts", cuts, "route weights", weights, "strict L<T at either end, T", threshold)
    for idx, (key, a, b, expected) in enumerate(locations):
        row_sources = []
        for site, coords in enumerate((a, b)):
            x, y = coords
            x += 4*idx
            axes = ((x, x+epsilon), (y, y+epsilon))
            row_sources.append(Packet(f"{key}:{site}", axes, F(1)))
        h = tuple(route_h(*row_sources, cut) for cut in cuts)
        assert h == expected
        by_key[key] = h, row_sources
    active = set(by_key)
    snapshots = []
    for step in (0, 1):
        probabilities = {}
        for key, (h, source) in sorted(by_key.items()):
            if key not in active:
                continue
            left_load = tuple(theta*source[1].mass*rho**i for i in h)
            right_load = tuple(theta*source[0].mass*rho**i for i in h)
            probabilities[key] = sum(weight for weight, u, v in zip(weights, left_load, right_load, strict=True)
                                     if u < threshold or v < threshold)
            print("  step", step, "row", key, "H", h, "actual both loads", left_load, right_load,
                  "small-library probability", probabilities[key])
        delete = {row for row, prob in probabilities.items() if prob > F(1, 2)}
        snapshots.append((probabilities, delete))
        active -= delete
    assert snapshots[0] == ({"A": F(1, 2), "B": F(2, 3), "C": F(0)}, {"B"})
    assert snapshots[1] == ({"A": F(1, 2), "C": F(0)}, set())
    assert active == {"A", "C"}
    print("  p=1/2 retained, p=2/3 deleted, all L=T retained; remaining rows recomputed.")


def verify_unit_window():
    print("Independent positive L1 input for the direct [1,2] last-root window.")
    epsilon = F(1, 2048)
    centers = (F(-1, 4), F(1, 4))
    sources = tuple(Packet(f"packet {j}", ((c-epsilon/2, c+epsilon/2),), F(3, 4))
                    for j, c in enumerate(centers))
    x_left, x_right = F(-1, 8), F(1, 8)
    x_length = x_right-x_left
    support_left = sources[0].axes[0][0]
    support_right = sources[1].axes[0][1]
    assert x_right - F(1, 2) < support_left < support_right < x_left + F(1, 2)
    m = sum(packet.mass for packet in sources)
    # Every length >= 1 contains the whole input on X, so the average is m/L.
    last_length, D, A2 = m, F(1), m/2
    assert 1 < last_length < 2 and D <= m < 2*D and A2 < 1
    assert support_right-support_left < 1
    print("  uniform packet width", epsilon, "centers", centers, "masses 3/4 each")
    print("  X", (x_left, x_right), "lambda=1; m_x and last true length", m,
          last_length, "D", D, "A_2", A2, "global {A_2 >= 1} measure 0 by total mass")
    a = (1+F(1, 32))*2
    cproj = a/D
    b_test = F(1, 8)
    tau_parts = dict.fromkeys(("same", "different"), F(0))
    diagnostic_parts = dict.fromkeys(("below", "above"), F(0))
    pair_ranges = {}
    for j, z in enumerate(sources):
        for k, q in enumerate(sources):
            tau = x_length*z.mass*q.mass/m**2
            category = "same" if j == k else "different"
            tau_parts[category] += tau
            zlo, zhi = z.axes[0]
            qlo, qhi = q.axes[0]
            distances = [abs(zp-qp) for zp in (zlo, zhi) for qp in (qlo, qhi)]
            if category == "same":
                distances.append(F(0))
            distance_min, distance_max = min(distances), max(distances)
            t_bounds = distance_min/a, distance_max/a
            if category == "same":
                assert t_bounds[1] < b_test
                diagnostic_parts["below"] += tau
            else:
                assert b_test < t_bounds[0]
                diagnostic_parts["above"] += tau
            p_bounds = 1-t_bounds[1], 1-t_bounds[0]
            assert 0 < p_bounds[0] <= p_bounds[1] <= 1
            theta = x_length/(cproj*m*p_bounds[1]), x_length/(cproj*m*p_bounds[0])
            assert 0 < theta[0] <= theta[1] <= 1
            assert tau == F(1, 16)
            pair_ranges[j, k] = p_bounds
            if j == 0:
                print(" ", category, "exact T_a bounds", t_bounds, "P_D", p_bounds,
                      "theta", theta, "theta decimal", display(theta), "ordered pair tau", tau)
    assert tau_parts == {"same": F(1, 8), "different": F(1, 8)}
    assert diagnostic_parts == {"below": F(1, 8), "above": F(1, 8)}
    assert sum(tau_parts.values()) == F(1, 4)
    print("  a_D and C_proj", a, cproj, "b_test", b_test, "h=floor(b_test/16)=0")
    print("  exact same/different tau", tau_parts, "below/above diagnostic", diagnostic_parts,
          "total tau", sum(tau_parts.values()))
    print("  finite diagnostic; no high-dimensional long-jump gate is asserted.")
    verify_strict_witness(sources, x_length, m, D, a, pair_ranges)


def verify_strict_witness(sources, x_length, m, D, a, pair_ranges):
    length, lam = F(5, 4), F(1)
    witness_average = m/length
    maximal_window_average = m
    assert 1 <= length <= 2 and witness_average == F(6, 5) > lam
    assert maximal_window_average == F(3, 2)
    pairs = {(j, k): x_length*z.mass*q.mass/(lam*length**2)
             for j, z in enumerate(sources) for k, q in enumerate(sources)}
    cut_square = pairs[0, 0]
    all_cut_square = sum(pairs.values())
    short_square = pairs[0, 0] + pairs[1, 1]
    long_square = pairs[0, 1] + pairs[1, 0]
    assert cut_square == pairs[0, 1] == pairs[1, 0] == F(9, 100)
    assert all_cut_square == F(9, 25)
    assert short_square == long_square == F(9, 50)
    cproj = 2*a/D
    coefficient = m*x_length/(lam*length**2*cproj)
    assert cproj == F(33, 8) and coefficient == F(16, 275)
    print("Same two packets and X, Bridge section 5 with a fixed strict witness.")
    print("  L", length, "m", m, "A_L", witness_average,
          "M_[1,2]", maximal_window_average, "lambda", lam)
    print("  J(left cut)", cut_square, "J(full cut)", all_cut_square,
          "ordered crossing terms", (pairs[0, 1], pairs[1, 0]))
    print("  full cut J short/long at b_test=1/8", (short_square, long_square))
    print("  C_proj=2*a_D/D", cproj, "true conditional projected density", coefficient, "/ P_D")
    for (j, k), (p_lo, p_hi) in pair_ranges.items():
        bounds = coefficient/p_hi, coefficient/p_lo
        assert 0 < bounds[0] <= bounds[1] <= 1
        if j == 0:
            print(" ", "same packet" if j == k else "different packets",
                  "strict-witness projected density", bounds)


def main():
    print("Replay:", sys.executable, "-B replay839.py > numbers839.txt")
    print("Python", sys.version.split()[0], "; exact Fraction, log series terms", LOG_TERMS,
          "dyadic endpoint bits", LOG_BITS)
    print("At each step all failing rows are deleted together; theta_k is theta0 on surviving rows.")
    print("Both receiver intervals are disjoint per slot, with exact Lebesgue marginals.")
    for case in CASES:
        verify_case(*case)
    verify_routed_boundary()
    verify_unit_window()
    print("Pure factor N^2*2^-h at N=64, h in (8,12,24):",
          [F(64)**2*F(2)**(-h) for h in (8, 12, 24)], "; unknown multipliers excluded.")
    print("Scope: finite dyadic two-arm conditional library with disjoint receiver marginals.")
    print("R813 history and admission conditions are outside this test.")
    print("PASS")


if __name__ == "__main__":
    main()
