from fractions import Fraction as F
import csv,math,json

def Lceil(x):
    L=0
    while F(2)**L<x:L+=1
    return L

def log_interval(x):
    assert x>=1
    k=0
    while x>=2:x/=2;k+=1
    def base(y):
        t=(y-1)/(y+1);N=80
        lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0))
        hi=lo+2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
        return lo,hi
    l2,u2=base(F(2));lx,ux=base(x)
    return k*l2+lx,k*u2+ux
counts={}
profiles={'initial':[F(3,2),F(2),F(3),F(4),F(8)],
 'atoms_boundary':[F(1),F(1)+F(1,1024),F(2)-F(1,1024),F(2)+F(1,1024),F(4)-F(1,1024),F(4)+F(1,1024)],
 'expanded':[F(2)**k+u for k in [8,16,24] for u in [F(-1,1024),F(0),F(1,1024)]]}
log2lo,log2hi=log_interval(F(2))
for stage,Ms in profiles.items():
 counts[stage]=0
 for M in Ms:
    if M<=1:
        assert M==1
        counts[stage]+=1;continue
    L=Lceil(M)
    # Represent Psi by exact coefficients of log M, log 2, and 1.
    summed=(F(L),-F(L*(L-1),2),sum((1-F(2)**(-k) for k in range(L)),F(0))+2*(M-1)*F(2)**(-L))
    closed=(F(L),-F(L*(L-1),2),F(L)-2+2*M*F(2)**(-L))
    assert summed==closed
    ell=L-1 if M<F(2)**L else L
    floor_form=(F(ell+1),-F(ell*(ell+1),2),F(ell-1)+M*F(2)**(-ell))
    if ell==L:
        # Difference = log M - L log 2; exactly zero at the power-of-two boundary.
        assert tuple(floor_form[k]-closed[k] for k in range(3))==(F(1),-F(L),F(0))
        assert M==F(2)**L
    else:assert floor_form==closed
    lmlo,lmhi=log_interval(M)
    plo=closed[0]*lmlo+closed[1]*log2hi+closed[2]
    phi=closed[0]*lmhi+closed[1]*log2lo+closed[2]
    assert plo>=0
    assert phi<=L*(1+lmhi)+2
    # Exact mother-account substitution with a rational certified upper price.
    S=F(7,3);r=F(4,3);s=F(13);W=F(5,9);X=F(11,7)
    Omega=2*S*r*s*(2*lmhi+phi)
    PA=Omega*W*F(4,7);rem=F(2,3);C=F(1,20);V=F(7,5)
    raw=PA+rem;Fhat=F(8,7);Lam=F(128,119)
    for multiplier in [16,32,64*Lam]:
        old=multiplier*Fhat*(raw+C*X+V*W)
        new=multiplier*Fhat*(rem+C*X+(V+Omega)*W)
        assert new-old==multiplier*Fhat*(Omega*W-PA)>=0
    counts[stage]+=1
print('PASS exact Psi coefficient/endpoint, rational-log and account checks',json.dumps(counts,sort_keys=True))
# Independently sum I_k + exact geometric tail to cross-check local MATLAB CSV.
rows=list(csv.DictReader(open('r429_matlab_parameters.csv',newline='')))
for row in rows:
 n=float(row['n']);eps=float(row['epsilon0']);s=1+math.sqrt(n)
 M=eps*(1+n*math.log(2))/s
 if M<=1:psi=0.0;Omega=0.0
 else:
  cut=math.ceil(math.log2(M))+20
  psi=sum((math.log(M/(2.0**k))+1-2.0**(-k)) if 2.0**k<=M else (M-1)*2.0**(-k) for k in range(cut))
  psi+=2*(M-1)*2.0**(-cut)
  Omega=4*s*(2*math.log(M)+psi)
 for field,val in [('M',M),('Psi',psi),('Omega',Omega)]:
  actual=float(row[field]);assert abs(actual-val)<=2e-12*max(1,abs(val)),(row,field,val)
print('PASS 27 MATLAB parameter rows independently cross-checked by I_k series and geometric tail.')
print('Mathematical certificate checks use Fraction; MATLAB/Python parameter comparisons are floating diagnostics only, not native full-history evidence.')
