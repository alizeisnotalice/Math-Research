"""R429 bounded native-center checks.
They verify exact matched parent mass layers and geometric compatibility.
They do not certify actual stage/history, low terminal ranks or a root budget.
"""
from fractions import Fraction as F


def check_layers(cells, lower, upper):
    """cells = (Lebesgue volume, matched mass, q) in disjoint center cells."""
    assert all(lower < m <= upper for _, m, _ in cells)
    knots = sorted(set([lower, upper] + [m for _, m, _ in cells]))
    total = sum((vol*q for vol, m, q in cells), F(0))
    one = total/upper
    two = total/upper**2
    for lo, hi in zip(knots, knots[1:]):
        vq = sum((vol*q for vol, m, q in cells if m <= lo), F(0))
        one += vq*(1/lo-1/hi)
        two += vq*(1/lo**2-1/hi**2)
    actual_one = sum((vol*q/m for vol, m, q in cells), F(0))
    actual_two = sum((vol*q/m**2 for vol, m, q in cells), F(0))
    assert one == actual_one > 0
    assert two == actual_two > 0


# Stage 1: f=1_[-4,4]+packet P on [-.1,.1].
# Parent side R=2 and centers [-.02,.02]. Children have side 1,
# centers in small blocks around +/-1.05: their full masses are exactly 1.
# Selected parent/source/child boxes all lie in the background support.
for packet in [F(1,20), F(1,10), F(1,5)]:
    radius_side = F(2)
    mass = radius_side + packet
    q = mass/radius_side
    assert 1 <= q <= F(4,3)
    # Actual centers are farther than alpha*Rchild/2, alpha=3/2.
    assert F(21,20)-F(1,50)-F(1,1000) > F(3,4)
    # Both source points +/- .7 are in every parent and the corresponding child.
    assert F(7,10)+F(1,50) < radius_side/2
    assert abs(F(21,20)-F(7,10))+F(1,1000) < F(1,2)
    check_layers([(F(1,25), mass, q)], F(3,2), 2*q)
print("Stage 1 PASS: 3 nonuniform-f native parent-cell layer integrals")


# Stage 2: one selector with three disjoint parent center intervals,
# selected sides 1.6,1.8,2. All contain the same packet.
count = 0
for packet in [F(1,50), F(1,10), F(1,5)]:
    for scale in [F(1,2), F(3,4), F(1)]:
        cells = []
        for side in [F(8,5), F(9,5), F(2)]:
            mass = side+packet
            cells.append((F(1,100)*scale, mass, mass/side))
        lam = 1+packet/F(8,5)
        assert lam <= F(4,3)
        # Centers can occupy disjoint intervals inside [-.03,.03].
        assert F(7,10)+F(3,100) < F(8,5)/2
        check_layers(cells, F(3,2), 2*lam)
        count += 1
print("Stage 2 PASS:", count, "nonuniform-f variable-selector mass-atom cases")


# Stage 3: native tensor center blocks and actual q=1 matching.
# f=1_[-4,4]^n; children terminal side 1, initial side 6/5,
# centers around +/-1.05 in the first coordinate. Sources +/- .7.
# Parent selected sides 8/5,9/5,2 on three disjoint tiny center blocks.
# Only source-containing geometry and R425 soft conditions are checked.
for d in [16, 24, 32]:
    n = d*d
    s = 1+d
    ri = F(6,5)
    distance = F(51,50)  # conservative center distance after block widths
    # Three disjoint parent intervals fit in [-.015,.015];
    # terminal/initial center half-width is at most .001.
    assert F(21,20)-F(3,200)-F(1,1000) > distance
    # e<3: conservative enclosures for actual alpha_0 and alpha_1.
    assert (2*distance/ri)**n > s*9**d
    assert (2*distance)**n > s*36**d
    assert F(8,5)**n > 36**d
    assert ri**n > 3**d
    # Original e^2 mass soft sum is strictly below this upper bound.
    assert 18*((ri/F(8,5))**d+(F(1)/F(8,5))**d) < 1
    # R425 Phi soft positivity: rational lower bound for log(x).
    phi_sum = F(0)
    for child_side in [ri, F(1), ri, F(1)]:
        ratio = F(8,5)/child_side
        log_lower = 2*(ratio-1)/(ratio+1)
        r_lower = n*log_lower-d
        assert r_lower > 0
        phi_sum += (1+r_lower/3)**-3
    assert phi_sum < 1
    vol = F(1,100)*F(1,50)**(n-1)
    cells = [(vol, side**n, F(1))
             for side in [F(8,5), F(9,5), F(2)]]
    check_layers(cells, F(3,2)**n, F(2)**n)
print("Stage 3 PASS: 3 native tensor center-block cases, n=256,576,1024")
print("All checks use exact Fraction arithmetic; e<3 is used only as a rigorous upper bound.")
print("No current D/stage, initial own-high, terminal own-low or full-history claim.")
print("R429 screening only: no new general root-scale payment proved.")
