from fractions import Fraction as F
from pathlib import Path
import json

def log_interval(x,terms=180):
    assert x>=1
    a=(x-1)/(x+1);p=a;lo=F(0)
    for j in range(terms):lo+=2*p/F(2*j+1);p*=a*a
    tail=2*p/F((2*terms+1))/(1-a*a) if a else F(0)
    return lo,lo+tail

def profile_sum_lower(M):
    if M<=1:return F(0)
    L=0
    while F(2)**(L+1)<=M:L+=1
    lm,_=log_interval(M);_,l2=log_interval(F(2))
    return (L+1)*(1+lm)-l2*F(L*(L+1),2)-2+M/F(2)**L

def case(N,K,base,mode,h):
    masses=[base**(j//2 if mode=='repeated' else j) for j in range(N)]
    weights=[F((j%4)+1,4) if mode!='flat' else F(1,2) for j in range(N)]
    # Merge true mass atoms before all CDF calculations.
    atoms={}
    for m,w in zip(masses,weights):atoms[m]=atoms.get(m,F(0))+w
    masses=sorted(atoms);weights=[atoms[m] for m in masses];N=len(masses)
    J=sum(weights);T=[sum(weights[:j+1]) for j in range(N)]
    left=[T[j]-weights[j] for j in range(N)]
    Z=[sum(weights[k] for k in range(N) if masses[k]<m/K) for m in masses]
    active=[z>h for z in Z]
    for j in range(N):
        if active[j]:assert left[j]>h
    P=[[weights[k]/Z[j] if active[j] and masses[k]<masses[j]/K else F(0) for k in range(N)] for j in range(N)]
    density_checks=moment_checks=multi=starts=0
    for j in range(N):
        if not active[j]:continue
        starts+=1
        for theta in [1,2,3]:
            assert sum(P[j][k]*Z[k]**theta for k in range(N))<=Z[j]**theta/F(1+theta)
            moment_checks+=1
        state=[F(int(k==j)) for k in range(N)]
        green=[F(0)]*N;visited_active=F(0);generation=0
        while any(state[k] and active[k] for k in range(N)):
            generation+=1
            nxt=[sum(state[l]*P[l][k] for l in range(N)) for k in range(N)]
            for k in range(N):
                green[k]+=nxt[k];d=max(h,T[k]);dens=nxt[k]/weights[k]
                assert dens<=1/d
                for theta in [1,2,3]:
                    assert dens<=Z[j]**theta/(d**(1+theta)*F(1+theta)**(generation-1))
                    density_checks+=1
                assert dens<=min(F(1),J/(d*F(2)**(generation-1)))/d
                if nxt[k]:assert masses[k]*K**generation<masses[j]
            visited_active+=sum(nxt[k] for k in range(N) if active[k])
            state=nxt
        if generation>1:multi+=1
        assert all(green[k]<=weights[k]/max(h,T[k]) for k in range(N))
        assert visited_active<=profile_sum_lower(J/h)
    # Check summed active-target rank envelope independently of actual transition.
    partial=F(0)
    for k in range(2*N+5):
        atom_sum=sum(weights[j]/T[j]*min(F(1),J/(T[j]*F(2)**k)) for j in range(N) if active[j])
        partial+=atom_sum
    assert partial<=profile_sum_lower(J/h)
    # Initial exclusive E=Z-C>h, C<h yields density <=2/T(target).
    initial_checks=0
    for j in range(N):
        for C in [F(0),h/3,2*h/3]:
            E=Z[j]-C
            if E<=h:continue
            for k in range(N):
                if active[k] and masses[k]<masses[j]/K:
                    assert 1/E<=2/T[k];initial_checks+=1
    return {'atoms':N,'K':str(K),'base':str(base),'mode':mode,'h':str(h),'starts':starts,'multi_generation_starts':multi,'density_checks':density_checks,'moment_checks':moment_checks,'initial_checks':initial_checks}

stages={'initial':[case(10,F(2),F(3,2),m,F(1)) for m in ['flat','varying','repeated']],
 'atom_boundary':[case(12,K,F(2),m,h) for K,m,h in [(F(2),'flat',F(1)),(F(2),'repeated',F(1)),(F(3),'varying',F(2)),(F(2),'varying',F(3,2)),(F(3),'repeated',F(1,2)),(F(2),'flat',F(100))]],
 'expanded':[case(N,K,F(3,2),m,F(2)) for N,K,m in [(18,F(2),'flat'),(18,F(3),'varying'),(20,F(2),'repeated'),(24,F(2),'varying'),(24,F(3),'flat'),(28,F(2),'repeated')]]}
flat=[r for rows in stages.values() for r in rows]
summary={'stages':{k:len(v) for k,v in stages.items()},'models':len(flat),**{k:sum(r[k] for r in flat) for k in ['starts','multi_generation_starts','density_checks','moment_checks','initial_checks']},'PASS':True}
Path(__file__).with_name('r429_aux_result.json').write_text(json.dumps({'summary':summary,'results':stages},indent=2)+'\n')
print(summary)
print('Exact atomic rank chains, including repeated mass atoms and strict K equality. Not native cube/full-history fixtures. Log bounds use rational interval certificates.')
print('r429_aux_result.json')
