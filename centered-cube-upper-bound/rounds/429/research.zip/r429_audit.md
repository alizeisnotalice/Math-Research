# R429 independent audit — FINAL PASS (bounded scope)

FINAL PASS for the actual initial/nonterminal parent-proximity union payment, its rank–generation budget and inherited mother account, together with the stated diagnostic limits. The complete double-far remainder and final absorption balance remain unproved; no full-history numerical fixture is certified. Only this audit file was edited, with no Git/author edits.

Sections 1–4 preserve the independent pre-author screen. Section 5 records final author/main/code review and isolated execution; section 6 binds the final bytes.

## 1. Correct occupation measure and initial atom

Fix the original source x, original full matched field and original active initial node v. Let Q_{x,j}(v,db) be the unfiltered, stopped-path SUBPROBABILITY of the actual node at step j≥1, including the terminal once if stopping occurs at that step. After stopping do not repeat or pad the node. Its sum over j≥1 is the proper-descendant Green kernel G_x(v,db), not a probability kernel. The available R423 bound is

    G_x(v,db)≤1_{m_b<m_v/K}ρ_x(db)/max(h,T_b(x)),

where T_b is the FULL inclusive mass CDF. It includes proper terminal visits but excludes the starting Dirac. The original active initial exclusive law ξ_r already has a density, and its actual total is at most one; the complete occupation is ξ_r+ξ_rG_x. An arbitrary starting Dirac may not be absorbed into the ρ-density statement.

On current original tickets the initial exclusive denominator is E_A=Z_A−C_A>h, C_A<h, with initial support m_b<m_A/K. Thus T_b≤Z_A=E_A+C_A<2E_A, and h<E_A. After dropping only positive exclusive restrictions,

    ξ_r(db)≤2ρ_x(db)/max(h,T_b).

This handles the initial node without a false terminal or history qualification. Sharper inherited high-rank constants are possible but not required here. All original entering weights/stage labels are retained. For arbitrary mixtures of original initial records, total occupation mass can be larger than one; the kernel estimates do not normalize it away.

For a fixed terminal-independent expansion α^n=sK², the original R425 support m_A>K²m_b at every node permits parent-center integration against the unlabelled Green bound. Since ∫ρ/max(h,T)≤1+log_+(J/h), that yields a root-log W price for that uniform-radius all-node event. In contrast an event with varying α_j cannot simply be paired with the UNLABELLED Green bound and charged once: its j-dependent geometric test must be retained in the occupation measure. The next section provides a labelled bound that does permit such a sum.

## 2. Independently derived sharper generation/rank kernel

The stopped active-rank moment is E[Z_{j−1}1_active]≤J(x)2^{-(j−1)}. This follows from the exact prefix left-CDF identity, including whole atoms, as in R428. Fix a target b. A previous state contributing to Q_{x,j}(v,db) has m_b<m_prev/K, so its strict prefix contains the ENTIRE inclusive mass prefix up to m_b. Hence

    Z_prev≥T_b(x),  Z_prev>h,  d_b=max(h,T_b(x)).

The exact density is the integral of 1_allowed/Z_prev against the actual surviving previous-state subprobability. Therefore

    Q_{x,j}(v,db)/ρ_x(db)
    ≤P(allowed)/d_b
    ≤[1/d_b]min(1,J(x)/(2^{j−1}d_b))
    ≤[1/d_b]min(1,J_max/(2^{j−1}d_b)).

The first cap uses only probability≤1 and the second uses Markov on the actual rank moment; no product of unrelated marginal bounds or integration of ρ/Z is used. In particular this proof does not need to infer a generation-labelled statement from the total Green kernel. It holds for active and terminal targets, although the new proposed branch should retain active targets only because R428 already paid the terminal event.

For an active target b, the full strict LEFT rank obeys T_b^-(x)≥Z_b(x)>h. Thus its entire mass-atom rank interval lies above h. For any nonincreasing nonnegative rank test g,

    ∫1_{Z_b>h}g(T_b)ρ_x(db)≤∫_h^{J(x)}g(t)dt.

There is no crossing-h atom base term: an active atom cannot cross h. Closed CDF endpoints are crucial. For the initial active law this gives the source rank factor 2log_+(J/h), using §1's 2/T bound.

For proper step j let k=j−1 and M=J_max/h. The corresponding source-rank factor is

    I_k(M)=∫_1^M dt/t min(1,M/(2^k t)),  M>1.

If c=M2^(-k)>1, I_k=log c+1−2^(-k); if c≤1, I_k=(M−1)2^(-k). The cases agree at c=1. In particular I_0=log M. With L=ceil(log_2 M), the exact sum is

    Σ_{k≥0}I_k
    =L(log M+1)−(log2)L(L−1)/2−2+2M2^(-L),

and it is at most L(1+log M)+2=O((1+log M)^2). If M≤1 there is no active source input; define this candidate active-node source factor as zero there. This is different from normalizing on survival.

## 3. Candidate actual geometric event and once-only stage price

Work on Π428, with all existing labels, R427 clip and R428 terminal complement unchanged. At active node b=v_j define j=0 for the initial node and j≥1 for proper nonterminal nodes. The retained original R425 B support gives

    m_A>κ_jm_b,  κ_j=[e²Σ_{r=0}^j e^r]^ℓ,
    α_j^n=sκ_j,  κ_0=K²,  ℓ=√n.

The generation kernel remains the original strict-K kernel; this larger mass gap is only an inherited retained-ticket support. For each j and fixed source/target, the actual parent-center integral satisfies

    ∫q_A c_A(x)/m_A 1_{m_A>κ_jm_b,A∈α_jQ_b}dA
    ≤(λ/q_-)α_j^n/κ_j = r s.

Delete the other original generated path's future positive restrictions and integrate its total to at most one; then use the uniform labelled bound of §2 and the unchanged same-source Σ_i b_i≤1 to combine old deletion stages. For either source direction the original stage caps combine once to S. Hence the proposed union that some INITIAL OR ACTIVE INTERMEDIATE node satisfies A∈α_jQ_b has the safe candidate price

    Ω_active W,
    Ω_active=2Sr s[2log M+Σ_{k≥0}I_k(M)]  (M>1),
    Ω_active=0 for M≤1.

The outer 2 is the two source paths only; inner 2 is the initial exclusive-law envelope, not another stage factor. The geometric event may occur at several nodes, but the actual positive union is deleted only once and its upper bound uses the positive sum. It does not give a fixed removed fraction. Initial active and proper active targets are disjoint from own-low terminal targets, so this price would be NEW on the R428 remainder, with the already-paid terminal Ω428 retained. On Π428 any terminal occurrence with the same α_j is already absent; it must not be charged again.

This argument keeps original source, full parent posterior, initial mass and history labels until upper bounds justify dropping positive factors. No future-conditioned chain is regenerated or made independent, and no original history is assigned to intermediate nodes. If adopted formally, the new split would change only the W slot from V428 to V428+Ω_active, keep C427 and all feedback multipliers, and give an entry increment 64ΛFhatΩ_active W. This was the independent candidate before post-author review; section 5 confirms the final adopted version.

## 4. Actual local arithmetic and limits

Executed nine finite atomic profiles (N=6,9,12; three rational mass-ratio/K choices), 45 active starts and 450 generation rows. The unlabelled Green bounds, generation survival caps and 231 initial envelope entries passed exactly. A separate direct test of the stronger pointwise generation/rank formula gave 4716 Fraction target-density comparisons and 2820 active atom-left-rank comparisons, all passing. These are temporary reviewer mass-axis diagnostics, not native full matching/history fixtures; they are not added to any later author/parent count.

Countably many deletion stages retain their original nonnegative measures, and all stage/generation exchanges are Tonelli. Actual path depth is uniformly finite by the fixed positive mass range; proper terminal atoms occur once. Positive infinite scalar series are only dominating upper sums. Zero rows never divide by rank; M≤1 implies no active initial node. The claimed W bound concerns a specified all-active-node geometric branch only, not the full unweighted R428 remainder or a complete absorption balance. The independent PRE ended here; the completed post-author audit follows.


## 5. Final post-author review, actual accounts and evidence

Read the complete final main, README, auxiliary, geometric analysis attachment and all three Python scripts, plus the MATLAB parameter script, CSV and final nonempty recorded output. The independent §2 kernel bound agrees with the author proof. Its general θ>0 moment version is valid: a reachable previous state has both rank at least T_b and positive transition denominator >h, and Markov on its actual killed θ-moment supplies the extra d_b power. The simple first density cap 1/d_b also follows directly from probability≤1; the cited Green cap is consistent but unnecessary. No generation-labelled claim is inferred merely from unlabelled Green occupation.

Initial exclusive law is treated separately. The unchanged original R413 support gives C_A<h, E_A=Z_A−C_A>h, and Z_A/E_A<2 for both directions (old Z_A>(4−ε_0)h; new Z_A>(L_old−ε_0)h with L_old≥4). The whole initial target mass atom is in the parent's strict mass prefix, so T_b≤Z_A. On initial active targets its left rank is >h. This proves 2ρ/T and the source factor 2log_+(J/h); it neither discards an initial Dirac nor gives a post-survival probability a new normalization.

The author auxiliary uses the floor expression for Ψ and the main uses the ceil expression. Both are exact, including M=2^L, because their difference there is log M−Llog2=0. The parent script checks this coefficient identity and power-of-two boundary condition explicitly. I_k and Ψ are nondecreasing in M; replacing J(x)/h by J_*/h is therefore valid. For M≤1 no active input exists and the defined zero price is safe. With the unchanged octave bound A_n≤s², the stated O(s log²(n+2)) order holds when the displayed inherited S,r,ε_0 dependence is retained/fixed as indicated. No input-dependent parameter is retroactively retuned.

The actual event is a UNION on the same Π428 of initial and proper ACTIVE targets A∈α_jQ_{v_j}; union overlaps are removed only once. Each j retains its inherited m_A>κ_jm_{v_j} support. The parent center integral really has weight q_Ac_A(x)/m_A and is bounded by rs after actual m_b=q_bR_b^n matching. Uniform target-rank/generation envelopes can be used before summing the unchanged deletion stages, with same-source Σ_i b_i≤1 and original two-endpoint cap S exactly once. The other original generated path is integrated to at most one only after dropping future positive restrictions for an upper bound; the actual retained paths are not asserted independent. No additional τ, stage count, second S or maximum path depth is charged.

The final approved split/account is

    R428=P429+R429,
    P429≤Ω429 W,
    Ω429=2Sr s[2log_+M+Ψ(M)], M=ε_0A_n/s,
    C429=C427, V429=V428+Ω429.

Terminals are excluded and their identical α_{T} event was already removed/paid in R428. The old R427 and R428 costs are retained, neither refunded nor recharged. The current G0/BH/entry residual multipliers remain 16Fhat/32Fhat/64ΛFhat; the entry source increment is exactly 64ΛFhatΩ429W. All old X coefficients, feedback Fhat, exterior/source/atom/full-scale slots are unchanged. The final remainder has father-far at EVERY actually generated node; its source-displacement consequence applies only to that actual fixed path source, not the entire π_A posterior. No general budget for that remainder is claimed.

The geometric analysis attachment's no-payment statement concerns its separate unfinished far-kernel route. Its actual matching weighted V(r), top base term plus positive layercake tail, strict mass gate and exclusion of the expanded terminal boxes are correct. Its single-endpoint mass-window bound and source-specific geometric consequence do not supply an additional receipt or change the formal main account. Thus there is no contradiction between that attachment's limitation and the main/auxiliary proved union payment.

### Actual isolated computation and its scope

Copied the final three Python scripts, with the unchanged MATLAB CSV required by the parent script, to a fresh temporary directory and actually ran all three. All stdout files are byte-identical to the saved final outputs; the auxiliary JSON is byte-identical as well. Confirmed the CSV has 27 rows. Reviewer temporary checks in §4 are excluded from all author/parent counts.

- Auxiliary: 15 finite atomic rank models (3/6/6), 121 active starts, 91 multi-generation starts, 19986 θ=1,2,3 density comparisons, 363 moments and 1477 initial-envelope comparisons. Repeated masses are combined into whole atoms; strict K equality is excluded; zero-active and crossing-atom cases are present. Rational atanh-series bounds certify the finite logarithmic comparisons. These are not native cube or full-history fixtures.
- Parent: 20 exact coefficient/power-of-two/rational-log/mother-account configurations (5/6/9). The same script independently recomputes I_k sums and the exact geometric tail for all 27 MATLAB parameter rows, using floating tolerance only for those numerical CSV comparisons. The exact and floating parts remain explicitly separate.
- Geometric attachment: 3 nonuniform complete-f continuous parent-cell integrals, 9 variable-selector mass-atom cases and 3 native tensor center-block cases. Complete matching and positive center volumes/Layercake terms are checked, while original own-high/own-low, D_i, stage, history and positive R427 retained-ticket mass are NOT certified. The general payment is analytic, not inferred from these models.

MATLAB scope: the parent reports actual MATLAB R2026a Update 4 execution. I reviewed the .m calculations, generated CSV and recorded table, and independently ran the Python CSV comparison; I did not launch an additional MATLAB execution. The first diary artifact was found empty during this review and was not accepted as evidence. The parent reran the script after replacing diary capture by evalc plus byte output; the final recorded output is nonempty (2817 bytes), contains the actual 27-row table/version/pass text, and corresponds to the reviewed 27-row CSV. These are ordinary floating parameter evaluations for specified S=2,r=1,b/a=2, n=16 through 2^40 and ε_0=1/2,1/8,1/32. They are neither outward-rounded certificates, native hard-core samples, nor a proof of order by fitting. The order follows from the exact analytic Ψ series.

Within this bounded scope no required correction remains. The main and README correctly retain the unpaid full remainder, absorption and scale-completion obligations. FINAL PASS applies to this round's stated theorem/account and evidence scope only.

## 6. SHA-256 final byte bindings

- `r429_main.md`: `109cdc56c65592bbdf6f6cf2f4facff892193221a451890afed2e0842323cc83`
- `r429_readme.md`: `b444e22dbaa3a5a62d71e990cdb1f27d7d882cb439d6710f789e69c8c2ddab6c`
- `r429_aux.md`: `4a6b81ce29fd739ab5862e91bd6dcbf3c1238ca1c9306a28d21e644e6a0cc7a6`
- `r429_geometry.md`: `7ff562f13426931ab200fa90d88bf7de8ff5b6bc72a26aed0899287a3b588ce4`
- `r429_parent_check.py`: `80bd50baf679d07b1222c8032383eb33996e13fef16fea9a049917c451287821`
- `r429_aux_check.py`: `51f6c7daaa89956ba56e81601da42bdeaa1495c8320b36f6798172917a2dcde3`
- `r429_geometry_check.py`: `70a0da006f0166fa887304dca6a84dea092e95423be28fc802665a62b2dcc68f`
- `r429_parent.result.txt`: `df2058ce716be6f28cc66c394b8ea8279d8dac44357a55c7ac8db480b95646aa`
- `r429_aux.result.txt`: `34aa7459063cc8c4611f736460684e310092a1bc483dc0f49270735c70a41c47`
- `r429_geometry.result.txt`: `0f2cfa4ba59b6181dec9fbbb748f8d058a3f4384a45150963517f8535c74f10f`
- `r429_aux_result.json`: `83541aed2a02926447656c97508b26a9873e83520c599a3b48b0774a5760fb29`
- `r429_parameters.m`: `ed27720b1a8fa5dea9e45c77537e9357d8b0d7e745f894244301190c71313b4c`
- `r429_matlab_parameters.csv`: `65d3b88cffa586e193bc505e109b58bc526a08b87cabfefc3176bc086cc8b3f3`
- `r429_matlab.result.txt`: `fe6531da2c262cd4e3b8af92e3c28b4410cb23341fd5f7f379b82a67c1b15e3c`

These bindings cover the reviewed final bytes only. Substantive proof/scope/code changes require corresponding re-audit; archive assembly is outside this audit. FINAL PASS; bounded task complete.
