% R429 floating-point parameter exploration only, not interval certificates.
% General order follows from the analytic formulas; zero M<=1 means no active field.
r429Rows=[];
for r429eps=[0.5,0.125,0.03125]
 for r429n=[16,64,256,1024,4096,65536,1048576,2^30,2^40]
  r429s=1+sqrt(r429n); r429An=1+r429n*log(2);
  r429M=r429eps*r429An/r429s;
  r429L=0; r429Psi=0; r429B=0;
  if r429M>1
   r429L=ceil(log2(r429M));
   r429Psi=r429L*(log(r429M)+1)-log(2)*r429L*(r429L-1)/2-2+2*r429M*2^(-r429L);
   r429B=2*log(r429M)+r429Psi;
  end
  r429Omega=4*r429s*r429B; % S=2, r=1
  r429Ratio=r429Omega/(r429s*log(r429n+2)^2);
  assert(r429Psi>=0 && r429Omega>=0 && isfinite(r429Ratio));
  r429Rows(end+1,:)=[r429n,r429eps,r429M,r429L,r429Psi,r429Omega,r429Ratio];
 end
end
r429Table=array2table(r429Rows,'VariableNames',{'n','epsilon0','M','L','Psi','Omega','Omega_over_s_log2'});
writetable(r429Table,'/tmp/r429_matlab_parameters.csv');
r429Output=sprintf('%s\n%s\nPASS 27 floating parameter evaluations; not a proof or outward-rounded certificate.\n',version,evalc('disp(r429Table)'));
r429File=fopen('/tmp/r429_matlab.result.txt','w');
assert(r429File>=0);
fwrite(r429File,uint8(r429Output),'uint8');
fclose(r429File);
disp(r429Output);
