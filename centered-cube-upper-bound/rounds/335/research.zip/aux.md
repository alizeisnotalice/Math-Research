# R335 — available-union source coalescence and forced overlap

**New finite-model estimate.** For two disjoint REAL source signatures whose union is also realized by a positive-volume source cell, there is an explicit capacity-preserving source coalescence. Its feature curvature is comparable, with dimension-free constants, to a computable full-prefix cross-receiver capacity. Insufficient cross-capturing source mass yields a certified increase of the actual finite ratio. A positive ratio extremizer therefore satisfies the quantitative overlap law (8). No union-closure of cube signatures is assumed, and no continuum/root theorem is inferred.

## 1. Preserve the finite actual field

Use `/tmp/r334_fractional.md`: the finite actual receivers have positive weights `w_i`, radii `R_i∈[a,b]`, matched cube masses `m_i=q_iR_i^n`, and `μ_i=w_i/m_i`. Every source column `s` is its COMPLETE cube signature; only positive-volume realized nonzero signatures are listed. Keep all original physical prefixes and the terminal Stieltjes atom:

\[
 J_s(r)=\sum_{R_i\le r}\mu_i s_i,\quad
 V_s(r)=\sum_{R_i\le r}w_i s_i,\quad
 \ell=b^{-n}\delta_b+nr^{-n-1}1_{[a,b]}dr,
\]
\[
 a_H(s)=\int\ell(dr)V_s(r)1_{J_s(r)\ge H},\qquad
 \Phi_s(r,i,j)=\frac{s_is_j}{\sqrt{J_s(r)}}
 \quad(i,j\text{ active at }r).
\]

The feature norm uses `ell(dr)μ_iμ_j`; zero rows contribute zero. These are the completed FULL-row pair features, not newly gated/reset features. Let
`F(x)=a_H·x−||Φx||²`, `W=Σx_s`, with `x≥0,Cx=m`. The field and its `J,Φ` stay fixed when `x` varies. Bounds for this finite relaxation convert to the original `B_H` only through its previously established ledger.

Assume two listed signatures `P,Q` are nonempty and disjoint as receiver-index sets, and their UNION `U=P∪Q` is another listed positive-volume signature. This availability is an explicit geometry test. The source direction

\[
 z=e_U-e_P-e_Q
\]

satisfies `Cz=0` and `Σz=−1`. If `x_P,x_Q>0`, every `0≤t≤min(x_P,x_Q)` gives a genuine feasible source `x+tz`. Total source mass decreases by `t`; it is NOT a mass-preserving four-cell swap. This decrease is essential in a fractional objective.

For each prefix put `p(r)=J_P(r)`, `q(r)=J_Q(r)`, `s=p+q=J_U`. Define

\[
 B=\int\ell(dr)\frac{2pq}{p+q}>0,
\quad A_P=\int\ell(dr)p\left(1-\sqrt{p/(p+q)}\right),
\quad A_Q=\int\ell(dr)q\left(1-\sqrt{q/(p+q)}\right).          \tag{1}
\]

Terms with a zero group are zero. `B>0` follows from the actual terminal atom and the two nonempty positive-weight receiver groups. All dimension and scale dependence remains in the displayed original `ell` and actual prefix masses.

## 2. Exchange curvature and a real source-overlap bound

Write `ΔΦ=Φ_U−Φ_P−Φ_Q`, `D²=||ΔΦ||²`, and `I_x=⟨Φx,ΔΦ⟩`. Let

\[
 W_{\rm cross}(x)=\sum_{s:\,s\cap P\ne\varnothing,\ s\cap Q\ne\varnothing}x_s
\]

be the actual source mass that captures at least one receiver from EACH group. Then for every nonnegative source vector,

\[
 \boxed{\quad I_x\le B W_{\rm cross}-A_Px_P-A_Qx_Q
       \le B\left(W_{\rm cross}-\frac{x_P+x_Q}{4}\right).\quad} \tag{2}
\]

Furthermore

\[
 D²=2\int\ell(dr)\left[p+q-
               \frac{p^{3/2}+q^{3/2}}{\sqrt{p+q}}\right],
 \qquad\boxed{B\le D²\le\tfrac32 B.}                        \tag{3}
\]

These are geometric feature estimates, not KKT identities. To prove (2), for an arbitrary source column `t` let `p_t,q_t` be its captured prefix masses within the two groups. Put
`M_PQ=Σ_t x_t p_tq_t/√J_t`, and similarly `M_PP,M_QQ`. Direct expansion on the actual ordered receiver coordinates gives

\[
 I_x=\int\ell\left[
 \frac{2M_{PQ}}{\sqrt{p+q}}-
 (p^{-1/2}-(p+q)^{-1/2})M_{PP}-
 (q^{-1/2}-(p+q)^{-1/2})M_{QQ}\right].                      \tag{4}
\]

A term with a zero receiver group is assigned zero. Since `J_t≥p_t+q_t`, and `ab/√(a+b)` increases in either nonnegative variable,
`M_PQ≤W_cross pq/√(p+q)`. The two particular real source columns give
`M_PP≥x_P p^(3/2)` and `M_QQ≥x_Q q^(3/2)`. This proves the first inequality in (2). Finally `A_P≥B/4` pointwise under the integral: the equivalent square-root bound follows by squaring
`√(p/(p+q))≤(2p+q)/(2(p+q))`; its squared difference is nonnegative `q²`. The other group is identical.

For (3), the norms of `Φ_P,Φ_Q` are `∫ell p,∫ell q`, their inner product is zero, and their inner products with `Φ_U` are the corresponding `p^(3/2)/√(p+q)` expressions. The ordered exclusive coordinates `P×Q` and `Q×P` alone contribute exactly `B` to `||ΔΦ||²`, proving the lower bound. For the upper bound set `u=p/(p+q)`: the elementary inequality
`u^(3/2)+(1−u)^(3/2)≥1−(3/2)u(1−u)` gives it. One proof is to sum `x^(3/2)≥(3/2)x²−(1/2)x³` for `x=u,1−u`; after `t=√x`, this scalar inequality factors as `t(t−1)²(t+2)/2≥0` before multiplication by `x`.

## 3. All original high gates and an explicit improving step

Crucially, for EVERY original `H≥0`,

\[
 \Delta_H:=a_H(U)-a_H(P)-a_H(Q)\ge0.                         \tag{5}
\]

Indeed `V_U=V_P+V_Q`, and at every actual prefix
`(V_P+V_Q)1_(p+q≥H)−V_P1_(p≥H)−V_Q1_(q≥H)≥0`.
At `H=0`, `a_0·x=X_q` is constant on `Cx=m` and `Δ_0=0`, but (5) avoids restricting the result to that case.

For any candidate put `c_x=F(x)/W`. The EXACT fractional residual on the feasible coalescence is

\[
 F(x+tz)-c_xW(x+tz)
 =t(\Delta_H+c_x-2I_x)-t²D².                               \tag{6}
\]

Set the computable lower bound

\[
 \Theta_x=\Delta_H+c_x-2B\left(W_{\rm cross}-\frac{x_P+x_Q}{4}\right).
\]

If `Θ_x>0` and both removed source masses are positive, ANY

\[
 0<t\le\min\{x_P,x_Q,\Theta_x/(3B)\}
\]

strictly improves the finite ratio, with the quantitative guarantee

\[
 \frac{F(x+tz)}{W-t}-c_x\ge\frac{t\Theta_x}{2(W-t)}>0.        \tag{7}
\]

This uses (2)–(3); it is a constructive source move, rather than merely stationarity. Feasibility gives `t≤W/2`, so the denominator stays positive. A rational certified lower bound on `Θ_x` may be used in the step.

At a positive global ratio extremizer `x_*`, for every AVAILABLE pair with `x_{*,P},x_{*,Q}>0`, (7) forces

\[
 \boxed{\quad W_{\rm cross}(x_*)\ge
 \frac{x_{*,P}+x_{*,Q}}4+\frac{c_*+\Delta_H}{2B}.\quad}       \tag{8}
\]

For a candidate within `δ` of the proved optimal ratio, the lower increase in (7) is at most `δ`. This gives an explicit stability test using available removable source mass and real cross-capture mass. No condition is inferred for a pair whose removed source mass is zero.

There is no free summation over exchanges. For a finite family `e` to which (8) applies, let `N_s` be the number of its cross-capture sets containing actual source column `s`. Summing gives exactly

\[
 \sum_e\left[\frac{x_{P_e}+x_{Q_e}}4+
                   \frac{c_*+\Delta_{H,e}}{2B_e}\right]
 \le\sum_sN_sx_s.                                         \tag{9}
\]

A useful global consequence requires an actual availability/multiplicity bound. Neither union-closure nor a dimension-uniform bound on these `N_s` is proved for arbitrary cube fields. Nonempty-intersection four-cell exchanges have additional common-group feature terms and are not silently substituted for this theorem.

## 4. A real positive-volume cube execution, without a new optimization

The self-contained `/tmp/r335_aux_checks.py` uses the exact `n=2` R334 receiver cubes, with centers/radius/receiver weight

`((-1/2,0),1,1/10)`, `((0,-1/2),1,1/10)`, `((1/2,1/2),3/2,1/5)`, `((0,0),2,1/10)`.

It constructs the COMPLETE rectangular face partition of `Q4`, with no source probes. The signatures
`P=0010`, `Q=1101`, `U=1111`, `Z=0001` have positive areas `11/16,3/16,1/16,1`. Put continuous source mass `9/4,1,0,3` on these respective signature regions, constant within each region and zero elsewhere. This is an explicit compact positive `L¹` source. Its four actual cube masses are exactly `R_i²`, so all receiver means are `q_i=λ=1`. The original weights and full physical prefixes `1,3/2,2` are kept.

At `H=0`, its finite relaxed ratio is exactly `1/250`. Here `W=25/4`, `W_cross=0`, `B=3688/66105`, and (7) supplies the rational feasible step `t=296519/524288`. After the actual source coalescence, the complete-source ratio is rigorously GREATER than `1/100`. The script checks exact mean matching and nonnegativity after the move. Thus an effective union exchange occurs on genuine positive-volume cube signatures; it is not only an abstract incidence calculation. The finite receivers are still quadrature receivers, not the original continuum `dx` field. This demonstrates the source theorem, not an extremizer or a lower bound for the original `B_H`.

Additional executions use `H=1/32,1/8`; the latter has exact threshold gain `4/45`. Their ratios also strictly improve, though their starting ratios are negative and are not used as positive-extremizer evidence. No optimization solver or new finite optimum is invoked.

Two fresh executions passed **554 exact assertions**, using rational arithmetic and outward rational square-root intervals of 100 bits. The printed ratio intervals are further rounded outward to 60-bit dyadics. Checks include the scalar curvature constants, positive-volume cell realization, all local means, the feature-inner-product bound, all-H gate gains, and the actual ratio-increase guarantee. Run:

```sh
python3 /tmp/r335_aux_checks.py
```

The bounded conclusion is (2)–(8), with the real source move above. The missing global step is plentiful realized exchanges with controlled cross-source multiplicity (or another genuine cube-geometric substitute); no root estimate for `c_*` is asserted. Only `/tmp/r335_aux.md` and the explicitly requested `/tmp/r335_aux_checks.py` are authored; no other research file or Git state is changed.
