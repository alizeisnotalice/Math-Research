# R335 — actual source overlap, local-J disparity and reciprocal credit

Run the bundled Python on `r335_numeric.py`. Only the standard library is used; all paths are relative to the script. It writes the small `r335_numeric_result.json`. The exact R334 repaired source masses and their provenance hash are embedded, so no earlier data/script is required at runtime. This round performs no optimization.

## Models and three stages

Keep the actual cube geometries in n1/2/3, their mixed physical radii1,3/2,2, positive receiver quadrature weights, m_i=R_i^n and q=λ=1. Source support lies in Q4, partitioned at every cube face and merged only by identical COMPLETE incidence signatures. All patterns, zero-J rows, physical prefixes/ties and the terminal ell atom are retained. Receiver integration remains FINITE QUADRATURE; it is not Lebesgue dx or complete original history.

1. Baseline: original f=1_Q4, three models.
2. Existing ratio-source candidates: both R334 H0 and H1/8 exactly repaired sources, six models. The H1/8 candidates are not asserted positive-relaxed maximizers when that objective's positive part vanishes. This stage only evaluates their actual geometry.
3. Endpoint stress: from original nonzero-pattern masses, take the first exact incidence nullspace direction and move to each of its two nonnegative endpoints. Both preserve Cx=m. Choose the endpoint with larger reciprocal mismatch; exact square-root enclosures certify its ordering against the other endpoint. This is a bounded TWO-point variation, not a new optimizer or a claimed worst input.

Pattern masses are distributed proportionally across their positive-volume source boxes. Thus all compared sources are compact positive L1 inputs with exactly the same selected receiver means. W varies, and unused-source mass is reported rather than normalized away.

## Quantities and identities

For each actual prefix compute exact rational J_y,J_z,A_yz and D=J_y+J_z−2A. For full source g let

Q=∫ell ∫g_y g_z A²/√(J_y J_z),
E=∫ell ∫g_y g_z A²/J_y,
Def=∫ell ∫g_y g_z A(1−A/√(J_y J_z))=X−Q,
Mismatch=∫ell ∫g_y g_z [A²/2](1/√J_y−1/√J_z)²=E−Q.

Zero-J pairs have A=0 and all displayed A-weighted terms are0. The code independently sums the reciprocal-difference expression and the one-sided square, checking

B_all=X−Q−Mismatch=Def−Mismatch=X−E.

Hence mismatch is a **nonnegative CREDIT**, not a new unpaid loss. Original B_H at H1/8 is integrated separately with the original inclusive source-row gate. Its low first moment and low completion bound H W are retained; no symmetric pair category is substituted for this asymmetric original gate.

The pointwise proposed inequality is valid:

A(1−A/√(J_yJ_z)) ≤ D/2.

Indeed with p=A/√(J_yJ_z)≤1, 2p−p²≤1≤(J_y+J_z)/(2√(J_yJ_z)). Each finite pattern pair is additionally checked exactly by rational squaring: when 2A−(J_y+J_z)/2>0, require A⁴≥[2A−(J_y+J_z)/2]²J_yJ_z. This includes equality/zero cases without a floating comparison.

A separate exact identity exposes the size of the integrated crude bound:

∫ell ∫g_y g_z D/2 = W Σ_i w_i/R_i^n − X.

Thus zero-capture or disjoint source pairs can make this bound large even though their A-weighted deficit is0. The diagnostic also reports the same D/2 sum restricted to J_y,J_z>0 and to A>0. These restrictions are observations, not a claimed paid geometric estimate.

Square roots and the identities involving irrational Q are evaluated at ordinary Decimal80/100 precision, with exact rational square-root enclosures separately giving mismatch lower/upper values. This is not interval arithmetic for every displayed decimal. Tiny negative roundoff in a mathematically nonnegative pointwise deficit is clamped to0; precision agreement and all identities are checked at the stated tolerances.

## Main numerical evidence

For the H0 ratio-source candidates:

|n|Def=X−Q|Mismatch credit|credit/Def|Def from J-ratio>2|Mismatch from J-ratio>2|
|---|---:|---:|---:|---:|---:|
|1|.04832296|.00805774|16.67%|76.05%|83.81%|
|2|.11859475|.01552657|13.09%|34.66%|68.44%|
|3|.13979824|.02541543|18.18%|58.68%|79.67%|

Thus comparable-J pairs dominate the deficit in n2 but do not dominate n1/3. Disparate-J pairs carry most reciprocal credit in all three. Dropping that credit or assuming comparable J would miss a material part of the tested geometry.

For H1/8 source candidates, n3 has Def≈.12585288, Mismatch≈.02958267 (23.51% credit), and actual B_all≈.09627021. Approximately69.48% of the deficit and85.39% of credit come from J-ratio>2. Source pairs with exactly one high row carry67.87% of deficit; both-high pairs carry7.30%. These are symmetric deficit categories, not claimed fractions of original B_H. The actual B_H is separately≈.07043221.

The D/2 bound relative to Def for H0 candidates is:

|n|all source pairs|only A>0 pairs|
|---|---:|---:|
|1|3.8655×|1.9060×|
|2|6.3709×|2.7006×|
|3|11.9749×|3.3523×|

For original uniform sources the all-pair factors are19.43×,47.26×,137.79× because zero/disjoint source mass is retained. For the H1/8 n3 candidate, even the A>0 factor is3.9157×. The inequality is useful algebraically, but an unrestricted D bill is much wider than the actual deficit in these inputs.

The endpoint stress preserves all means but changes the credit and its distribution. Selected endpoints have Mismatch≈.00600395,.01553313,.02300777; their disparate-J shares are100%,79.17%,79.64%. This variation confirms that the discrepancy is not just a change of unused total source mass. These are bounded finite models, with no dimensional exponent fit.

The exact final-J source-mass histograms are in the result. The H0 candidate high-row fractions at final radius H1/8 are1,.40523,.19812. Their actual low first moments are0,.21808,.29084, versus coarse H W bounds≈.22005,.50000,1.00000. Completion remains a separate account and cannot be dropped merely because a relaxed source ratio is small.

## Decision and reproducibility limits

The finite evidence favors retaining the common-capture support A>0, separating comparable and disparate local J, and exploiting reciprocal mismatch as a credit. It does not support charging all source symmetric differences uniformly, or dropping disparity without another payment. It supplies no general geometric receipt, continuum receiver conclusion or root-size theorem.

Two fresh standalone processes pass **23,072 exact rational/integer checks** and **7,852 ordinary Decimal diagnostics**, reported separately. Stages baseline/ratio-source/endpoint-stress have9,222/10,845/10,857 total assertions. Geometric checks are deliberately repeated when rebuilding each stage; counts are not numbers of independent examples. Twelve final model evaluations are reported, with additional two-endpoint assessments. The small complete replay set is the Python source, this note and the result JSON; no MATLAB solver or prior multi-megabyte data is required.
