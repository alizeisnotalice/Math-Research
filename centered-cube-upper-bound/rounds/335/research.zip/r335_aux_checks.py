#!/usr/bin/env python3
"""Exact interval checks for available-union source coalescence; no solver."""
from fractions import Fraction as F
from itertools import product
from math import isqrt
import json,hashlib
BITS=100;count=0

def check(ok):
 global count
 assert ok
 count+=1

def sqrtbox(x):
 if x==0:return F(0),F(0)
 scale=1<<BITS;k=isqrt((x.numerator*scale*scale)//x.denominator)
 lo=F(k,scale)
 return (lo,lo) if k*k*x.denominator==x.numerator*scale*scale else (lo,F(k+1,scale))

def invsqrt(x):
 lo,hi=sqrtbox(x)
 return 1/hi,1/lo

def add(a,b):return a[0]+b[0],a[1]+b[1]
def sub(a,b):return a[0]-b[1],a[1]-b[0]
def times(a,b):
 vals=[x*y for x in a for y in b]
 return min(vals),max(vals)
def scal(a,t):return times(a,(t,t))

# Scalar full-clock curvature and quarter constants, exact outward intervals.
for p0 in range(1,9):
 for q0 in range(1,9):
  p,q=F(p0),F(q0);s=p+q;B=2*p*q/s
  sp=sqrtbox(p/s);sq=sqrtbox(q/s)
  norm=(2*(s-p*sp[1]-q*sq[1]),2*(s-p*sp[0]-q*sq[0]))
  check(norm[0]>=B);check(norm[1]<=3*B/2)
  check((2*p+q)**2>=4*p*(p+q))
  check((2*q+p)**2>=4*q*(p+q))

# Actual positive-volume n=2 cube field, full face partition of Q4.
n=2
recv=[((F(-1,2),F(0)),F(1),F(1,10)),
      ((F(0),F(-1,2)),F(1),F(1,10)),
      ((F(1,2),F(1,2)),F(3,2),F(1,5)),
      ((F(0),F(0)),F(2),F(1,10))]
axes=[sorted(set([F(-2),F(2)]+[c[d]+sgn*r/2
       for c,r,w in recv for sgn in [-1,1]])) for d in range(n)]
vol={}
for ids in product(*[range(len(ax)-1) for ax in axes]):
 box=[(axes[d][i],axes[d][i+1]) for d,i in enumerate(ids)]
 v=F(1)
 for lo,hi in box:v*=hi-lo
 sig=tuple(int(all(lo>=c[d]-r/2 and hi<=c[d]+r/2
       for d,(lo,hi) in enumerate(box))) for c,r,w in recv)
 for bit,(c,r,w) in zip(sig,recv):
  check(bool(bit) or any(hi<=c[d]-r/2 or lo>=c[d]+r/2
                         for d,(lo,hi) in enumerate(box)))
 vol[sig]=vol.get(sig,F(0))+v
check(sum(vol.values())==16)
sigs=sorted(s for s in vol if any(s));index={s:i for i,s in enumerate(sigs)}
P=(0,0,1,0);Q=(1,1,0,1);U=(1,1,1,1);Z=(0,0,0,1)
check(all(s in index and vol[s]>0 for s in [P,Q,U,Z]))
x=[{P:F(9,4),Q:F(1),Z:F(3)}.get(s,F(0)) for s in sigs]
m=[r**n for c,r,w in recv];mu=[w/mm for (c,r,w),mm in zip(recv,m)]
check(all(sum(v*s[i] for v,s in zip(x,sigs))==m[i] for i in range(4)))
rs=sorted(set(r for c,r,w in recv));prefix=[]
for k,r in enumerate(rs):
 ell=r**(-n)-(rs[k+1]**(-n) if k+1<len(rs) else 0)
 active=[i for i,(c,t,w) in enumerate(recv) if t<=r]
 J=[sum(mu[i]*s[i] for i in active) for s in sigs]
 V=[sum(recv[i][2]*s[i] for i in active) for s in sigs]
 prefix.append((ell,active,J,V))

def qbox(xx):
 lo=hi=F(0)
 for ell,active,J,V in prefix:
  for i in active:
   for j in active:
    h=(F(0),F(0))
    for v,s,jj in zip(xx,sigs,J):
     if v and s[i] and s[j] and jj:h=add(h,scal(invsqrt(jj),v))
    lo+=ell*mu[i]*mu[j]*h[0]**2
    hi+=ell*mu[i]*mu[j]*h[1]**2
 return lo,hi

def abox(H):
 a=[F(0)]*len(sigs)
 for ell,active,J,V in prefix:
  for j in range(len(sigs)):
   if J[j]>=H:a[j]+=ell*V[j]
 return a

z=[F(0)]*len(x)
for s,v in [(U,1),(P,-1),(Q,-1)]:z[index[s]]=F(v)
check(all(sum(v*s[i] for v,s in zip(z,sigs))==0 for i in range(4)))
check(sum(z)==-1)
B=F(0);norm=(F(0),F(0));I=(F(0),F(0))
for ell,active,J,V in prefix:
 p=J[index[P]];q=J[index[Q]];ss=p+q
 if ss:
  B+=ell*2*p*q/ss
  sp=sqrtbox(p/ss);sq=sqrtbox(q/ss)
  norm=add(norm,(2*ell*(ss-p*sp[1]-q*sq[1]),
                 2*ell*(ss-p*sp[0]-q*sq[0])))
 for i in active:
  for j in active:
   h=(F(0),F(0));delta=(F(0),F(0))
   for v,s,jj in zip(x,sigs,J):
    if v and s[i] and s[j] and jj:h=add(h,scal(invsqrt(jj),v))
   for v,s,jj in zip(z,sigs,J):
    if v and s[i] and s[j] and jj:delta=add(delta,scal(invsqrt(jj),v))
   I=add(I,scal(times(h,delta),ell*mu[i]*mu[j]))
check(B>0);check(norm[0]>=B);check(norm[1]<=3*B/2)
W=sum(x);cross=sum(v for v,s in zip(x,sigs)
 if any(a*b for a,b in zip(s,P)) and any(a*b for a,b in zip(s,Q)))
check(cross==0)
check(I[1]<=B*(cross-(x[index[P]]+x[index[Q]])/4))
oldq=qbox(x);out=[]
Qexact=F(0)
for ell,active,J,V in prefix:
 for vs,ss,js in zip(x,sigs,J):
  for vt,tt,jt in zip(x,sigs,J):
   if not vs or not vt:continue
   aa=sum(mu[i]*ss[i]*tt[i] for i in active)
   if not aa:continue
   zroot=js*jt;rn=isqrt(zroot.numerator);rd=isqrt(zroot.denominator)
   check(rn*rn==zroot.numerator and rd*rd==zroot.denominator)
   Qexact+=ell*vs*vt*aa*aa/F(rn,rd)

for H in [F(0),F(1,32),F(1,8)]:
 a=abox(H);gain=sum(aa*zz for aa,zz in zip(a,z));check(gain>=0)
 linear=sum(aa*v for aa,v in zip(a,x))
 cold=((linear-oldq[1])/W,(linear-oldq[0])/W)
 qsafe=cold[0]+gain-2*B*(cross-(x[index[P]]+x[index[Q]])/4)
 check(qsafe>0)
 tbound=min(x[index[P]],x[index[Q]],qsafe/(3*B))
 t=F((tbound.numerator*(1<<20))//tbound.denominator,1<<20)
 check(t>0)
 xx=[v+t*zz for v,zz in zip(x,z)]
 check(all(v>=0 for v in xx));check(sum(xx)==W-t)
 check(all(sum(v*s[i] for v,s in zip(xx,sigs))==m[i] for i in range(4)))
 newq=qbox(xx);newlin=sum(aa*v for aa,v in zip(a,xx))
 cnew=((newlin-newq[1])/(W-t),(newlin-newq[0])/(W-t))
 guaranteed=t*qsafe/(2*(W-t))
 check(cnew[0]-cold[1]>=guaranteed)
 if H==0:
  check((linear-Qexact)/W==F(1,250))
  check(cnew[0]>F(1,100))
  check(cold[0]>0 and cnew[0]>cold[1])
 scale=1<<60
 def coarse(iv):
  return [str(F(iv[0].numerator*scale//iv[0].denominator,scale)),
          str(F(-((-iv[1].numerator*scale)//iv[1].denominator),scale))]
 out.append(dict(H=str(H),t=str(t),old_ratio_interval=coarse(cold),
                 new_ratio_interval=coarse(cnew),
                 guaranteed_increase_lower=str(F(guaranteed.numerator*scale//guaranteed.denominator,scale)),
                 gate_gain=str(gain)))
print(json.dumps(dict(status='PASS',checks=count,fixture='actual_n2_full_face_partition',
 positive_volumes={''.join(map(str,s)):str(vol[s]) for s in [P,Q,U,Z]},
 B=str(B),W=str(W),cases=out,
 scope='Exact finite actual-cube receiver quadrature/source coalescence; no new optimization or continuum/root claim'),sort_keys=True))
