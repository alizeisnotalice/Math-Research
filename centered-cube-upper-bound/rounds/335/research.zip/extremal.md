# R335 — canonical continuum extremal capture geometry without source attainment

## Exact scope and fixed data

This is a theorem on the actual continuous hard-matched receiver field, not a receiver quadrature limit. It constructs the extremal capture feature and a quantitative deficit decomposition. It does not prove a root-sized extremal coefficient or existence of an L1 extremizing source.

Fix a positive finite-measure E, positive a≤R(u)≤b≤2a, q(u)∈[3λ/4,λ], m_u=q(u)R(u)^n, dμ=du/m_u, and the original inclusive prefix measure ell=b^(-n)δ_b+nr^(-n-1)dr on [a,b]. All data are measurable. Let c_u(y)=1_{Q_R(u)(u)}(y), E_r={R≤r}, J_y(r)=∫_{E_r}c_u(y)dμ(u), and V_y(r)=∫_{E_r}c_u(y)du. Fix H≥0. Put
\[
 a_H(y)=\int\ell(dr)1_{J_y(r)\ge H}V_y(r),\quad
 d\xi=\ell(dr)1_{E_r^2}d\mu(u)d\mu(v),\quad
 \varphi_y=\frac{c_u(y)c_v(y)}{\sqrt{J_y(r)}}.
\]
Zero-J features are zero. The Hilbert space is the real L²(dξ). For a source g define Φg=∫g(y)φ_y dy, as the nonnegative measurable kernel integral. Its L² finiteness is proved below.

The shared feasible class is
\[
 \mathcal C=\{g\in L^1_+(\mathbb R^n):\int g(y)c_u(y)dy=m_u\text{ for a.e. }u\in E\}.
\]
Assume it is nonempty. Put X_q=∫_E qdu>0, W(g)=∫g, A_H(g)=∫a_Hg, Q(g)=||Φg||², F(g)=A_H(g)−Q(g), M=esssup_E m_u>0. The source cone includes mass outside every receiver cube; it is not silently removed.

## Uniform bounds from actual matching

For every g∈C, W(g)≥M. Positive Fubini and the exact prefix tail give
\[
 A_0(g)=\int\ell(dr)\int_{E_r}m_u\,du=X_q,
 \qquad 0\le A_H(g)\le X_q.
\]
Define I_uv=∫g c_uc_v and S^G_uv=∫g c_uc_v/J at each prefix. The latter has exact row marginal ∫_{E_r}S^G_uv dμ(v)=m_u for μ-a.e. u∈E_r; the zero-J exceptional part has zero joint receiver-source measure. Cauchy and I_uv≤min(m_u,m_v) give
\[
 (\Phi g)_{uv}^2\le I_{uv}S^G_{uv}
 \le\tfrac12(m_u+m_v)S^G_{uv}.
\]
Integrating and using symmetry yields Q(g)≤∫ell∫_{E_r}m_u²dμ=X_q. Thus all displayed integrals are finite and 0≤Q(g)≤X_q. No source density cap, source compactness, or receiver discretization is used.

Define the extremal ratio
\[
 c=\sup_{g\in\mathcal C}\frac{F(g)}{W(g)}.
\]
For the theorem below assume c>0. It is finite since c≤X_q/M. We do not estimate its dimension dependence. If c≤0, F(g)≤0 already, but the positive-extremal conclusions are not asserted by dividing by c. The empty/zero-measure receiver case is separately trivial.

## The continuum theorem

There exists a unique h_*∈L²(dξ) such that EVERY sequence g_k∈C with F(g_k)/W(g_k)→c has Φg_k→h_* strongly. For every g∈C,
\[
 \boxed{cW(g)-F(g)\ge\|\Phi g-h_*\|^2.}                 \tag{1}
\]
More precisely the affine moment slack
\[
 R(g)=cW(g)-A_H(g)+2\langle h_*,\Phi g\rangle-\|h_*\|^2
\]
is nonnegative, and
\[
 cW(g)-F(g)=R(g)+\|\Phi g-h_*\|^2.                     \tag{2}
\]
This is an integral separating inequality on the full matching class, not a claimed pointwise receiver-multiplier representation of R. A continuum Farkas theorem is not assumed.

For 0≤δ<c and a source with F(g)/W(g)≥c−δ,
\[
 W(g)\le\frac{X_q}{c-\delta},\qquad
 \|\Phi g-h_*\|^2\le\delta W(g)
 \le\frac{\delta X_q}{c-\delta}.                        \tag{3}
\]
No Euclidean localization or strong L1 convergence follows from this feature estimate alone.

### Proof

Write d(g)=cW(g)−F(g)≥0. For an extremizing sequence, eventually its ratio exceeds c/2, so W(g_k)≤2X_q/c and d(g_k)→0. The class is convex; for g,h∈C the exact Hilbert identity is
\[
 d((g+h)/2)=\tfrac12d(g)+\tfrac12d(h)
                       -\tfrac14\|\Phi g-\Phi h\|^2\ge0.
\]
Consequently every extremizing feature sequence is Cauchy. Completeness gives h_*. Interleaving any two extremizing sequences gives the same limit. This proves uniqueness without extracting a tight subsequence of sources.

For a fixed g∈C and 0<t<1, apply nonnegativity of d to (1−t)g_k+tg. Exact expansion gives
\[
 0\le(1-t)d(g_k)+td(g)-t(1-t)\|\Phi g_k-\Phi g\|^2.
\]
First let k→∞ with t fixed, giving d(g)≥(1−t)||h_*−Φg||². Then let t↓0, obtaining (1). Expansion of (1) yields (2), and A_H(g)≤X_q yields (3). No exchange of unbounded infima or limits is needed.

## Mass and cutoff consequences, with quantifiers preserved

At H=0, A_0(g)=X_q for the whole class. Every extremizing sequence therefore has
\[
 W(g_k)\longrightarrow W_*=
       \frac{X_q-\|h_*\|^2}{c}\ge M>0.
\]
This follows from cW(g_k)=X_q−Q(g_k)+d(g_k). For a δ-near-extremizer the explicit estimate
\[
 |cW(g)-(X_q-\|h_*\|^2)|
 \le2\sqrt{X_q}\sqrt{\delta W(g)}+\delta W(g)
\]
uses ||Φg||,||h_*||≤√X_q. Thus all H=0 maximizing sequences share the same limiting total mass and capture feature, but can still differ in source location or distribution inside a common capture class.

At H>0, write L_H(g)=X_q−A_H(g)≥0. Only the COMBINED quantity
\[
 cW(g_k)+L_H(g_k)\to X_q-\|h_*\|^2
\]
is forced; separate convergence of W and L_H is not asserted. For every fixed measurable receiver-pair-prefix subset B, (3) also implies ∫_B|Φg−h_*|²dξ≤δW(g); this is restriction of the same norm, not a new branch budget.

## What this changes, and what remains

The general continuous problem can now be analyzed through a uniquely determined extremal capture geometry even when the source extremizer does not exist. The conclusion holds for the original receiver dx and every positive matched L1 source, including escape mass, at each fixed full hard field. It is stronger in scope than a finite KKT certificate and does not require arbitrary pointwise multipliers to exist.

The unknown coefficient c is still the extremal ratio being studied. To pay the original slot we still need a dimension-uniform estimate c≤C_ε√n log^A(n+2), or an appropriate εX allowance with the same original inputs and all complementary terms. Formula (1) alone cannot supply this estimate: it controls departure from an unknown extremal feature, not the size of that extremum. The original B_H conversion also retains its λH W completion and all outer entrance, time and scale fees. No global weak-type closure is claimed.
