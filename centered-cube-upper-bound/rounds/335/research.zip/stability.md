# Finite certificate consequences of the continuum feature theorem

The standalone `r335_stability.py` embeds the three R334 H=0 exact certificate triples (lower ratio, upper ratio, feasible source W). Xq is 2/5,1/2,1/2 from those receiver weights. These are previously certified finite models, not a fresh receiver-dx approximation.

If l≤c*≤u and F(g)/W≥l, the R335 theorem gives ||Φg−h*||²≤(u−l)W=:β. Since c*≥l>0 and H=0, its mass consequence gives |W−W*|≤(2√Xq√β+β)/l. Integer square roots rounded upward give rational upper bounds, retaining all large exact fractions in the output. Nine rational assertions check the interval order and square-root enclosure directions. These bounds depend on the R334 certificates already audited, not on solver status.

Actual local Python run gives feature norm error upper bounds 0.000160483283,0.000043400805,0.000169075799. The mass error upper bounds are 0.007396001,0.002070240,0.013684743 respectively. These are rigorous finite-model consequences, not proof of a general dimension rate, source spatial localization, or L1 convergence. The source feature Φg, rather than the separately rationalized dual h, is the object being compared with the canonical feature.
