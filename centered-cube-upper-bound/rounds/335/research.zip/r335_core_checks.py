from fractions import Fraction as F
from itertools import combinations
blocks=[(F(-3,2),F(-5,4)),(F(-1,4),F(1,4)),(F(1,2),F(3,4)),(F(3,2),F(7,4))]
h=F(1); checks=0
# Exact continuous receiver blocks, common cube length 2. Source-grid cells
# are split at every possible endpoint of a core or expanded receiver block.
breaks=sorted(set([x+s*h for block in blocks for x in block for s in (-1,1)]))
for bits in range(1,16):
 active=[i for i in range(4) if bits>>i&1]
 lo=max(blocks[i][1]-h for i in active)
 hi=min(blocks[i][0]+h for i in active)
 for l,r in zip(breaks,breaks[1:]):
  y=(l+r)/2
  direct=True
  for i,(a,b) in enumerate(blocks):
   captured=max(F(0), min(b,y+h)-max(a,y-h))
   direct &= (captured==b-a if i in active else captured==0)
  predicted=lo<=y<=hi and all(not(a-h<y<b+h) for i,(a,b) in enumerate(blocks) if i not in active)
  assert direct==predicted
  checks+=1
print({'exact_continuous_receiver_interval_checks':checks,'scope':'essential-box signature criterion only; no high-row or root claim'})
