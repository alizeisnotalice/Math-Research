#!/usr/bin/env python3
"""Frozen-source overlap/mismatch geometry diagnostics, no optimization."""
from fractions import Fraction as F
from decimal import Decimal,localcontext
from itertools import product
from math import isqrt
from pathlib import Path
from collections import Counter
import json,hashlib
BASE=Path(__file__).resolve().parent
CHECKS=Counter()
def ck(k,v):CHECKS[k]+=1;assert v,k
def D(x):return Decimal(x.numerator)/Decimal(x.denominator)
def sqrtbox(x,bits=100):
 scale=1<<bits;q=isqrt((x.numerator*scale*scale)//x.denominator);return F(q,scale),F(q+1,scale)
def fixtures():
 return [('n1',1,[((F(-1,4),),F(1),F(1,5)),((F(1,4),),F(3,2),F(1,5))]),('n2',2,[((F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(-1,2)),F(1),F(1,10)),((F(1,2),F(1,2)),F(3,2),F(1,5)),((F(0),F(0)),F(2),F(1,10))]),('n3',3,[((F(-1,2),F(0),F(0)),F(1),F(1,10)),((F(0),F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(0),F(1,2)),F(3,2),F(1,10)),((F(1,2),F(1,2),F(0)),F(3,2),F(1,10)),((F(0),F(0),F(0)),F(2),F(1,10))])]
def groups(n,recv):
 axes=[sorted(set([F(-2),F(2)]+[x[a]+sign*r/2 for x,r,w in recv for sign in [-1,1]])) for a in range(n)];out={}
 for ids in product(*[range(len(p)-1) for p in axes]):
  box=[(axes[a][i],axes[a][i+1]) for a,i in enumerate(ids)];mass=F(1)
  for lo,hi in box:mass*=hi-lo
  c=tuple(int(all(lo>=x[a]-r/2 and hi<=x[a]+r/2 for a,(lo,hi) in enumerate(box))) for x,r,w in recv)
  for ci,(x,r,w) in zip(c,recv):ck('exact_source_cell_incidence',ci or any(hi<=x[a]-r/2 or lo>=x[a]+r/2 for a,(lo,hi) in enumerate(box)))
  out[c]=out.get(c,F(0))+mass
 ck('exact_complete_source_mass',sum(out.values())==4**n)
 return sorted(out),out

def geometry(n,recv,sigs):
 mi=[r**n for x,r,w in recv];w=[w for x,r,w in recv];mu=[a/b for a,b in zip(w,mi)];rs=sorted(set(r for x,r,w in recv));prefix=[]
 for kk,r in enumerate(rs):
  ell=r**(-n)-(rs[kk+1]**(-n) if kk+1<len(rs) else 0);active=[i for i,(x,t,w) in enumerate(recv) if t<=r];J=[sum(mu[i]*c[i] for i in active) for c in sigs];A=[[sum(mu[i]*c[i]*v[i] for i in active) for v in sigs] for c in sigs]
  for iy,jy in enumerate(J):
   for iz,jz in enumerate(J):
    a=A[iy][iz];ck('exact_capture_overlap_bounds',0<=a<=min(jy,jz));rhs=2*a-(jy+jz)/2
    ck('exact_deficit_vs_symdiff',rhs<=0 or a**4>=rhs**2*jy*jz)
  prefix.append((ell,J,A))
 return mi,w,prefix

def endpoint_sources(sigs,original,mi):
 non=[i for i,c in enumerate(sigs) if any(c)];cols=[sigs[i] for i in non];N=len(mi);A=[[F(c[i]) for c in cols] for i in range(N)];rr=0;piv=[]
 for col in range(len(cols)):
  found=next((i for i in range(rr,N) if A[i][col]),None)
  if found is None:continue
  A[rr],A[found]=A[found],A[rr];p=A[rr][col];A[rr]=[v/p for v in A[rr]]
  for i in range(N):
   if i!=rr:
    p=A[i][col];A[i]=[v-p*u for v,u in zip(A[i],A[rr])]
  piv.append(col);rr+=1
  if rr==N:break
 free=next(i for i in range(len(cols)) if i not in piv);direction=[F(0)]*len(cols);direction[free]=1
 for row,col in enumerate(piv):direction[col]=-A[row][free]
 base=[original[i] for i in non];out=[]
 for sign in [-1,1]:
  v=[sign*x for x in direction];distance=min(-a/b for a,b in zip(base,v) if b<0);x=[a+distance*b for a,b in zip(base,v)];full=[F(0)]*len(sigs)
  for i,a in zip(non,x):full[i]=a
  ck('exact_endpoint_nonnegative',all(a>=0 for a in full))
  ck('exact_endpoint_preserves_means',all(sum(a*c[i] for a,c in zip(full,sigs))==mi[i] for i in range(N)))
  out.append((f'first_nullspace_endpoint_sign_{sign}',full))
 return out

def analyze(n,recv,sigs,masses,prefix,source_name,precision=80):
 with localcontext() as ctx:
  ctx.prec=precision;tol=Decimal(10)**(-(precision-15));H=F(1,8);mi=[r**n for x,r,w in recv];X=sum(w for x,r,w in recv);W=sum(masses)
  ck('exact_source_mean_constraints',all(sum(m*c[i] for m,c in zip(masses,sigs))==mi[i] for i in range(len(mi))))
  Q=deficit=mismatch=Decimal(0);E=Ball=BH=lowfirst=F(0);halfD=activeD=positiveJD=F(0);Qlo=Qhi=F(0);categories={k:[Decimal(0),Decimal(0)] for k in ['J_ratio_le2','J_ratio_gt2','both_high','one_high','both_low']}
  for ell,J,A in prefix:
   source_first=F(0)
   for iy,jy in enumerate(J):
    for iz,jz in enumerate(J):
     a=A[iy][iz];weight=ell*masses[iy]*masses[iz];source_first+=weight*a;halfD+=weight*(jy+jz-2*a)/2
     if jy and jz:positiveJD+=weight*(jy+jz-2*a)/2
     if not a:continue
     activeD+=weight*(jy+jz-2*a)/2;lo,hi=sqrtbox(jy*jz);q=D(a*a)/(D(jy)*D(jz)).sqrt();d=max(Decimal(0),D(a)-q);v=D(a*a)/2*(1/D(jy).sqrt()-1/D(jz).sqrt())**2;e=a*a*(1/jy+1/jz)/2
     ck('decimal_pointwise_deficit_bound',d>=-tol and d<=D((jy+jz-2*a)/2)+tol)
     Q+=D(weight)*q;deficit+=D(weight)*d;mismatch+=D(weight)*v;E+=weight*e;Qlo+=weight*a*a/hi;Qhi+=weight*a*a/lo
     Ball+=weight*(a-a*a/jy)
     if jy>=H:BH+=weight*(a-a*a/jy)
     else:lowfirst+=weight*a
     keys=['J_ratio_le2' if max(jy,jz)<=2*min(jy,jz) else 'J_ratio_gt2','both_high' if min(jy,jz)>=H else 'one_high' if max(jy,jz)>=H else 'both_low']
     for key in keys:categories[key][0]+=D(weight)*d;categories[key][1]+=D(weight)*v
   ck('exact_prefix_source_first',source_first==ell*sum((recv[i][2]*mi[i] for i,(x,r,w) in enumerate(recv) if r<=sorted(set(t for x,t,w in recv))[prefix.index((ell,J,A))]),F(0)))
  ck('exact_original_Ball',Ball==X-E)
  ck('exact_total_symdiff_account',halfD==W*sum(w/r**n for x,r,w in recv)-X)
  ck('decimal_Ball_deficit_mismatch',abs(D(Ball)-(deficit-mismatch))<=tol)
  ck('decimal_square_identity',abs(D(X)-Q-mismatch-D(Ball))<=tol)
  ck('decimal_mismatch_independent',abs(mismatch-(D(E)-Q))<=tol)
  ck('exact_low_completion',0<=lowfirst<=H*W and 0<=BH<=Ball)
  Qhi=min(Qhi,E);ck('exact_Q_interval',Qlo<=Qhi<=E)
  for first,second in [('J_ratio_le2','J_ratio_gt2')]:ck('decimal_category_completion',abs(categories[first][0]+categories[second][0]-deficit)<=tol)
  ck('decimal_high_category_completion',abs(sum(categories[k][0] for k in ['both_high','one_high','both_low'])-deficit)<=tol)
  finalJ=prefix[-1][1];bins={'J=0':F(0),'0<J<1/16':F(0),'1/16<=J<1/8':F(0),'1/8<=J<1/4':F(0),'J>=1/4':F(0)}
  for m,j in zip(masses,finalJ):
   key='J=0' if not j else '0<J<1/16' if j<F(1,16) else '1/16<=J<1/8' if j<H else '1/8<=J<1/4' if j<F(1,4) else 'J>=1/4';bins[key]+=m
  ck('exact_J_histogram',sum(bins.values())==W)
  def fraction(x):return float(x/deficit) if deficit else 0.0
  return dict(_exact_mismatch_bounds=(E-Qhi,E-Qlo),n=n,source=source_name,precision=precision,W_exact=str(W),X_exact=str(X),Ball_exact=str(Ball),BH_H1over8_exact=str(BH),low_first_exact=str(lowfirst),low_completion_bound_exact=str(H*W),original_E_exact=str(E),Q_symmetric=float(Q),deficit_X_minus_Q=float(deficit),mismatch_E_minus_Q=float(mismatch),mismatch_fraction_of_deficit=float(mismatch/deficit) if deficit else 0.0,half_D_all=float(halfD),half_D_positive_J_pairs=float(positiveJD),half_D_captured_pairs=float(activeD),D_bound_looseness_all=float(D(halfD)/deficit) if deficit else 0.0,D_bound_looseness_captured=float(D(activeD)/deficit) if deficit else 0.0,category_deficit_fraction={k:fraction(v[0]) for k,v in categories.items()},category_mismatch_fraction={k:float(v[1]/mismatch) if mismatch else 0 for k,v in categories.items()},J_final_mass_exact={k:str(v) for k,v in bins.items()},J_high_final_mass_fraction=float(sum(m for m,j in zip(masses,finalJ) if j>=H)/W),mismatch_interval_width=float(Qhi-Qlo),mismatch_lower=float(E-Qhi),mismatch_upper=float(E-Qlo))

def main():
 models=[];stages=[]
 for stage in ['baseline','ratio_source','endpoint_stress']:
  before=sum(CHECKS.values())
  for label,n,recv in fixtures():
   sigs,g=groups(n,recv);orig=[g[c] for c in sigs];mi,w,prefix=geometry(n,recv,sigs)
   if stage=='baseline':selected=[('original_full_uniform_Q4',orig)]
   elif stage=='ratio_source':
    selected=[]
    for Hname in ['H0','H1over8']:
     snapshot=RATIO_SOURCES[str(n)+'_'+Hname];by={tuple(c):F(m) for c,m in zip(snapshot['signatures'],snapshot['x'])};selected.append(('R334_'+Hname+'_ratio_candidate',[by.get(c,F(0)) for c in sigs]))
   else:
    endpoints=endpoint_sources(sigs,orig,mi);assessed=[(analyze(n,recv,sigs,m,prefix,name,80),m) for name,m in endpoints];chosen=max(assessed,key=lambda p:p[0]['mismatch_E_minus_Q']);other=next(v for v in assessed if v is not chosen);ck('exact_endpoint_mismatch_order',chosen[0]['_exact_mismatch_bounds'][0]>=other[0]['_exact_mismatch_bounds'][1]);selected=[(chosen[0]['source'],chosen[1])]
   for name,masses in selected:
    r=analyze(n,recv,sigs,masses,prefix,name,80);r2=analyze(n,recv,sigs,masses,prefix,name,100);ck('two_precision_diagnostics',all(abs(r[k]-r2[k])<1e-13 for k in ['Q_symmetric','deficit_X_minus_Q','mismatch_E_minus_Q']))
    r.pop('_exact_mismatch_bounds');r2.pop('_exact_mismatch_bounds');models.append(r2)
  stages.append(dict(stage=stage,dimensions=[1,2,3],checks=sum(CHECKS.values())-before))
 exact=sum(v for k,v in CHECKS.items() if k.startswith('exact_'));ordinary=sum(CHECKS.values())-exact
 out=dict(status='PASS',exact_rational_checks=exact,ordinary_decimal_checks=ordinary,check_counts=dict(CHECKS),stages=stages,models=models,provenance=SNAPSHOT_PROVENANCE,scope='Full compact source partition with actual cubes and finite receiver quadrature; all physical prefixes/ell atoms. No optimizer, dimension fit, original history or continuum receiver claim.')
 (BASE/'r335_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',exact_rational_checks=exact,ordinary_decimal_checks=ordinary,models=len(models),stages=stages),sort_keys=True))
# Frozen exact source snapshot from R334; no external file needed at execution.
RATIO_SOURCES = {'1_H0': {'signatures': [[0, 1], [1, 0], [1, 1]], 'x': ['110927627/145885118', '18992534/72942559', '53950025/72942559']}, '1_H1over8': {'signatures': [[0, 1], [1, 0], [1, 1]], 'x': ['110927627/145885118', '18992534/72942559', '53950025/72942559']}, '2_H0': {'signatures': [[0, 0, 0, 1], [0, 0, 1, 0], [0, 0, 1, 1], [0, 1, 0, 1], [0, 1, 1, 1], [1, 0, 0, 1], [1, 0, 1, 1], [1, 1, 0, 1], [1, 1, 1, 1]], 'x': ['152192675345354542508815/111014552212439362614092', '85979941608203/117492357305350462170218', '67636281/67089491', '111931209459059/150777896946455508989764', '56578442/91119697', '111931209459059/150777896946455508989764', '56578442/91119697', '32636771/86095918', '41/38439068']}, '2_H1over8': {'signatures': [[0, 0, 0, 1], [0, 0, 1, 0], [0, 0, 1, 1], [0, 1, 0, 1], [0, 1, 1, 1], [1, 0, 0, 1], [1, 0, 1, 1], [1, 1, 0, 1], [1, 1, 1, 1]], 'x': ['41124905712548/19183577004021', '172102783108485012209/437079922942850737428', '15498842/54211263', '47/4031264895478', '6497413/11392034', '47/4031264895478', '6497413/11392034', '0', '152040/353867']}, '3_H0': {'signatures': [[0, 0, 0, 0, 1], [0, 0, 0, 1, 0], [0, 0, 0, 1, 1], [0, 0, 1, 0, 0], [0, 0, 1, 0, 1], [0, 0, 1, 1, 1], [0, 1, 0, 0, 1], [0, 1, 0, 1, 1], [0, 1, 1, 0, 1], [0, 1, 1, 1, 1], [1, 0, 0, 0, 1], [1, 0, 0, 1, 1], [1, 0, 1, 0, 1], [1, 0, 1, 1, 1], [1, 1, 0, 0, 1], [1, 1, 0, 1, 1], [1, 1, 1, 0, 1], [1, 1, 1, 1, 1]], 'x': ['4427208217662176873923899605435104719801910732720069/1553012758086789705933097045293926421416243062528368', '9069628557741113471982278370985520477352474076753/557011166154917661470830900804615459045965902613581936376', '109951249/78606499', '23420327782968043843502544128714838662811557718256213/1438359231874780692476777865308294502211726654579517026236012', '96607821/69066997', '45726070/59629773', '242612854204622554633088594081394238046139619/1754261154533557326602070738752568555842629427839248', '6977014/83064919', '6133347/73020632', '4845835/11622246', '888386820965112287087277719689633629120072089351/6423660010772338539841551689887334583782197006626170928', '7651719/91097627', '7436688/88537573', '39714235/95250583', '11/98616464', '10016407/48264251', '19364335/93307423', '5/18827343']}, '3_H1over8': {'signatures': [[0, 0, 0, 0, 1], [0, 0, 0, 1, 0], [0, 0, 0, 1, 1], [0, 0, 1, 0, 0], [0, 0, 1, 0, 1], [0, 0, 1, 1, 1], [0, 1, 0, 0, 1], [0, 1, 0, 1, 1], [0, 1, 1, 0, 1], [0, 1, 1, 1, 1], [1, 0, 0, 0, 1], [1, 0, 0, 1, 1], [1, 0, 1, 0, 1], [1, 0, 1, 1, 1], [1, 1, 0, 0, 1], [1, 1, 0, 1, 1], [1, 1, 1, 0, 1], [1, 1, 1, 1, 1]], 'x': ['1102263955985462639645696207051/322408913886015672509181343095', '898238076882875450257393373195/4847202747846505250602092260232', '48470485/34833957', '1296683457332360839897830014461/6997351569953595983890100052920', '69971289/50285795', '39958693/72919309', '220646/238537049318033', '0', '0', '23647347/94501669', '220646/238537049318033', '0', '0', '23647347/94501669', '0', '0', '0', '1892532/2524157']}}
SNAPSHOT_PROVENANCE = {'file': 'r334_data_lp.json', 'sha256': '442ec3f5c66af3716ccc2d9c5f1ece3d24b7279fd80f06cac61b042e88b6fa14', 'note': 'Exact repaired H0 and H1/8 candidate masses embedded; runtime independent of R334 files.'}
if __name__=='__main__':main()
