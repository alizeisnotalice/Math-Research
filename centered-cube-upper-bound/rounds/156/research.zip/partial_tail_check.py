#!/usr/bin/env python3
"""Finite exact/interval R156 partial-capture binomial/Gamma certificates."""
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import argparse,hashlib,json,math,sys
from decimal import Decimal,localcontext
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent

def enc(x):
    if isinstance(x,F):return f'{x.numerator}/{x.denominator}'
    if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x

def sqrtbox(q,digits=100):
    assert q>=0;s=10**digits;k=math.isqrt(q.numerator*s*s//q.denominator);lo=F(k,s)
    hi=lo if lo*lo==q else F(k+1,s)
    assert lo*lo<=q<=hi*hi
    return lo,hi

def sqrt_interval(iv):return sqrtbox(iv[0])[0],sqrtbox(iv[1])[1]
def add(x,y):return x[0]+y[0],x[1]+y[1]
def mul(x,y):
    assert min(*x,*y)>=0
    return x[0]*y[0],x[1]*y[1]
def scale(x,c):return mul(x,(c,c))

@lru_cache(None)
def logbox(x,N=96):
    assert x>0
    if x==1:return F(0),F(0)
    if x<1:
        l,u=logbox(1/x,N);return -u,-l
    j=0;y=x
    while y>=2:y/=2;j+=1
    def atanh(v):
        s=F(0);term=v
        for i in range(N):s+=term/(2*i+1);term*=v*v
        return 2*s,2*s+2*term/((2*N+1)*(1-v*v))
    l,u=atanh((y-1)/(y+1));l2,u2=atanh(F(1,3));return l+j*l2,u+j*u2

@lru_cache(None)
def pibox(N=80):
    def atan(x):
        s=sum(((-1)**j*x**(2*j+1)/(2*j+1) for j in range(N)),F(0));t=(-1)**N*x**(2*N+1)/(2*N+1)
        return min(s,s+t),max(s,s+t)
    a,b=atan(F(1,5)),atan(F(1,239))
    return 16*a[0]-4*b[1],16*a[1]-4*b[0]

def tail_test(n,k,m,R,z,label):
    assert 0<=R<m<=k<=n and 0<=z<=1
    if z==0:T=F(0)
    else:T=sum((F(math.comb(k,j))*(1-z)**j*z**(k-j) for j in range(R+1)),F(0))
    assert 0<=T<=1
    if z in (0,1):
        assert T==z
        return dict(label=label,status='PASS_ENDPOINT',n=n,k=k,m=m,R=R,z=z,T=T)
    # An exact intermediary requires neither logarithms nor exp.
    P=lambda x:sum((x**j/math.factorial(j) for j in range(R+1)),F(0))
    exact_env=z**(k-R)*P(k*(1-z));assert T<=exact_env
    sl,su=logbox(1/z);assert sl>=1-z
    log_env=z**(k-R)*P(k*sl),z**(k-R)*P(k*su)
    assert T<=log_env[0]
    # sqrt(T)<=z^((m-R)/2)*sum_j (n*s)^(j/2)/sqrt(j!).
    prefix=sqrtbox(z**(m-R));poly=(F(1),F(1))
    if R>=1:poly=add(poly,sqrt_interval((n*sl,n*su)))
    if R>=2:
        sq2=sqrtbox(F(2));poly=add(poly,(n*sl/sq2[1],n*su/sq2[0]))
    bound=mul(prefix,poly);rt=sqrtbox(T)
    symbolic_equality=R==0 and m==k
    if not symbolic_equality:assert rt[1]<=bound[0]
    return dict(label=label,status='PASS',n=n,k=k,m=m,R=R,z=z,T=T,exact_binomial_envelope=exact_env,log_interval=[sl,su],log_envelope=log_env,sqrt_T=rt,uniform_sqrt_envelope=bound,symbolic_equality=symbolic_equality,log_terms=96,root_digits=100)

def Sbox(q,R):
    assert q>0 and R in (0,1,2)
    s=(1+q,1+q)
    if R>=1:s=add(s,scale(sqrt_interval(scale(pibox(),q)),F(1,2)+3*q/4))
    if R>=2:
        sq2=sqrtbox(F(2));s=add(s,(q*(1+2*q)/sq2[1],q*(1+2*q)/sq2[0]))
    return s

def closed_case(n,m,R,label):
    assert 0<=R<m<=n
    q=F(2*n,m-R);S=Sbox(q,R);rootn=sqrtbox(F(n));pi=pibox()
    six=scale(mul(add((F(1),F(1)),mul(pi,rootn)),scale(S,q)),F(6))
    exterior=scale(six,F(32,3))
    assert exterior==scale(mul(add((F(1),F(1)),mul(pi,rootn)),scale(S,q)),F(64))
    return dict(label=label,status='PASS_CLOSED_INTERVAL',n=n,m=m,R=R,q0=q,S=S,source_time_bound=six,exterior_coefficient_over_Lambda_eta_inverse=exterior,normalized_by_sqrt_n=(exterior[0]/rootn[1],exterior[1]/rootn[0]),Gamma_coefficients='j0:1,1; j1:sqrt(pi)/2,3sqrt(pi)/4; j2:1,2',integer_k_enumerated=False)

def scope_audit(detail=None,template=None,scope_json=None,scope_source=None):
    # Independent aggregation of saved pair records; no call/import of producer.
    pointpath=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json')
    srcpath=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/active_traffic_v2.json')
    pointpath=Path(detail) if detail else pointpath;srcpath=Path(template) if template else srcpath
    scope_json=Path(scope_json) if scope_json else ROOT/'partial_capture_scope.json';scope_source=Path(scope_source) if scope_source else ROOT/'partial_capture_scope.py'
    pb=pointpath.read_bytes();sb=srcpath.read_bytes()
    assert hashlib.sha256(pb).hexdigest()=='6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9'
    assert hashlib.sha256(sb).hexdigest()=='1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de'
    saved=json.loads(scope_json.read_bytes());assert saved['producer_sha256']==hashlib.sha256(scope_source.read_bytes()).hexdigest()
    points=json.loads(pb)['point_records'];src=next(x for x in json.loads(sb)['cases'] if x['id']=='I1');pos=[[F(t) for t in a['position']] for a in src['atoms']];th=[[F(t) for t in a['thresholds']] for a in src['atoms']];half=F(src['parameters']['L'])/2
    segs=src['score_segments'];ks=[]
    for ss in segs:
        t=(F(ss['lo'])+F(ss['hi']))/2;ks.append([[a<t for a in tt] for tt in th]);assert list(map(sum,ks[-1]))==ss['k']
    hist={str(r):dict(count=0,I=F(0),pI=F(0),rows=0,p_volume=F(0),segments={str(i):[0,F(0)] for i in range(len(segs))}) for r in range(5)};grids={};rows_count=0;row_sum_discrepancy=F(0)
    for grid,rs in points.items():
        gh={str(r):dict(count=0,I=F(0),pI=F(0),rows=0,p_volume=F(0)) for r in range(5)}
        for row in rs:
            rows_count+=1;x=list(map(F,row['xq']));w=F(row['dx_weight_corrected']);p=F(str(row['p']));present=set();summed=F(0)
            for t in row['pair_terms']:
                si,v,u=int(t['segment']),int(t['v']),int(t['u']);mask=ks[si][v];k=sum(mask);ku=sum(ks[si][u]);assert k==4 and k>ku and t['delta']==k-ku
                assert row['good'][v] and not row['good'][u] and row['rho'][v]>0
                r=str(sum(mask[j] and abs(x[j]-pos[v][j])>half for j in range(4)));value=F(str(t['I']));assert value>0;summed+=value;present.add(r)
                for dest in [hist[r],gh[r]]:dest['count']+=1;dest['I']+=value;dest['pI']+=w*p*value
                hist[r]['segments'][str(si)][0]+=1;hist[r]['segments'][str(si)][1]+=value
            if row['I'] is not None:row_sum_discrepancy=max(row_sum_discrepancy,abs(F(str(row['I']))-summed))
            for r in present:
                for dest in [hist[r],gh[r]]:dest['rows']+=1;dest['p_volume']+=w*p
        grids[grid]=gh
    checks=0
    for r,hh in hist.items():
        old=saved['by_R'][r]
        for a,b in [('count','pair_term_count'),('I','I_sum'),('pI','p_weighted_saved_I_sum'),('rows','rows_with_pair_term'),('p_volume','p_weighted_cell_volume')]:
            assert hh[a]==F(str(old[b]));checks+=1
        for si,(count,value) in hh['segments'].items():assert count==old['by_segment'][si]['pair_term_count'] and value==F(old['by_segment'][si]['I_sum']);checks+=2
    for grid,gh in grids.items():
        for r,hh in gh.items():
            for a,b in [('count','pair_term_count'),('I','I_sum'),('pI','p_weighted_saved_I_sum'),('rows','rows_with_pair_term'),('p_volume','p_weighted_cell_volume')]:assert hh[a]==F(str(saved['by_grid_R'][grid][r][b]));checks+=1
    assert rows_count==saved['grid_totals']['point_rows'] and sum(v['count'] for v in hist.values())==saved['grid_totals']['pair_term_count']
    return dict(status='PASS_SAVED_DIAGNOSTIC_ONLY',producer_json_sha256=hashlib.sha256(scope_json.read_bytes()).hexdigest(),rows=rows_count,pair_terms=sum(v['count'] for v in hist.values()),field_checks=checks,by_outside_count=hist,by_grid=grids,row_I_sum_max_decimal_discrepancy=row_sum_discrepancy,weights='Exactly reaggregated saved corrected weights; continuous midpoint error not certified',scope='Saved pair entries and saved binary64 roles/I/p only, no eta or FULL certificate')

def dec(q):
    with localcontext() as c:c.prec=35;return str(Decimal(q.numerator)/q.denominator)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(ROOT/'partial_tail_check.json'));ap.add_argument('--detail');ap.add_argument('--template');ap.add_argument('--scope-json');ap.add_argument('--scope-source');args=ap.parse_args()
    stages={};initial=[]
    for n in [1,2,4,8]:
        for k in range(1,n+1):
            for R in range(min(2,k-1)+1):
                for m in sorted({R+1,k}):
                    for z in [F(1,4),F(1,2),F(3,4)]:initial.append(tail_test(n,k,m,R,z,f'initial:{n}:{k}:{m}:{R}:{z}'))
    stages['initial_binomial']=initial
    near=[]
    for k in [3,8,32]:
        for R in [0,1,2]:
            for q in [4,16,64]:
                for z in [F(1,2**q),1-F(1,2**q)]:near.append(tail_test(k,k,R+1,R,z,f'near:{k}:{R}:{q}:{z}'))
            for z in [F(0),F(1)]:near.append(tail_test(k,k,R+1,R,z,f'endpoint:{k}:{R}:{z}'))
    stages['threshold_and_endpoints']=near
    expanded=[]
    for k in [16,64,128]:
        for R in [0,1,2]:
            for m in sorted({R+1,k}):
                for z in [F(1,16),F(1,2),F(15,16)]:expanded.append(tail_test(2*k,k,m,R,z,f'expanded:{k}:{m}:{R}:{z}'))
    stages['expanded_binomial']=expanded
    closed=[]
    for n in [4,8,16,100,10**4,10**6]:
        for R in [0,1,2]:
            for m in sorted({R+1,(n+1)//2,n}):
                if R<m<=n:closed.append(closed_case(n,m,R,f'closed:{n}:{m}:{R}'))
    # R=1,m=ceil(n/2),n>=4 has q<=8 and root-normalized factor <=pi+1/2.
    q=F(8);p=pibox();S=Sbox(q,1);universal=scale(mul(add(p,(F(1,2),F(1,2))),scale(S,q)),F(64))
    ceil=(universal[1].numerator+universal[1].denominator-1)//universal[1].denominator
    assert universal[1]<78000
    for n in [4,5,6,7,8,16,100,10**4,10**6]:
        m=(n+1)//2;assert 4*(m-1)>=n and F(2*n,m-1)<=8
    family=[]
    for n in [3,4,5,6,7,8,16,100,10**4,10**6]:
        m=max(3,(n+1)//2);q2=F(2*n,m-2);assert q2<=12
        family.append(closed_case(n,m,2,f'R2_half:{n}:{m}'))
    S2=Sbox(F(12),2);assert S2[1]<380 and p[1]+1<5
    r2bound=128*12*380*5;assert r2bound<2**22
    audit=scope_audit(args.detail,args.template,args.scope_json,args.scope_source)
    result=dict(status='PASS',scope='Finite binomial and closed Gamma interval certificates; conditional geometry/source-time price only, not FULL',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),seed=None,execution=dict(actual_producer_invocations=3,prior_failed_invocations=1,new_kernel_evaluations=0,new_receiver_points=0,space_grid_points=0),stage_counts={k:len(v) for k,v in stages.items()},finite_tail_tests=sum(map(len,stages.values())),tail_stages=stages,closed_count=len(closed),closed_cases=closed,R2_half_family=dict(cases=family,q0_upper=12,S2_at_12=S2,S2_upper=380,eta=F(1,2),simple_root_coefficient=r2bound,power_two_root_coefficient=2**22,statement='Conditional exterior <=2^22 Lambda sqrt(n) for R2,m=max(3,ceil(n/2)),n>=3,eta=1/2'),saved_scope_independent_audit=audit,pi_interval=p,universal_R1_half_n=dict(n_min=4,m='ceil(n/2)',q0_upper=8,S1_at_8=S,root_constant_interval=universal,integer_ceiling=ceil,simple_constant=78000,display=[dec(x) for x in universal],statement='Conditional exterior <=78000 Lambda eta^-1 sqrt(n); eta is original approved source-retention parameter, not optimized here'),certification=dict(log='Fraction atanh N96 with explicit remainder',pi='Machin arctan N80 alternating remainder',roots='isqrt outward 100 decimal digits; perfect squares exact',Gamma='exact integer/half-integer identities for R<=2, pi interval propagated',display_only='Decimal35'),limitations=['No actual kernels/receiver integration','m>R mandatory; rejects m<=R rather than dividing by zero','Large n cases use closed forms only, no million-k enumeration','Theory supplying coordinate probability, soft TV, selectors and commonization remains separately audited','Price carries one eta^-1, not eta^-2'])
    Path(args.output).write_text(json.dumps(enc(result),ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],stage_counts=result['stage_counts'],tail_tests=result['finite_tail_tests'],closed_count=len(closed),root_constant_display=result['universal_R1_half_n']['display'],root_constant_ceiling=ceil)))
if __name__=='__main__':main()
