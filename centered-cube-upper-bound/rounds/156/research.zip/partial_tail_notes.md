# R156 partial-tail 有限区间证书与旧条目核验

结果：partial_tail_check.json status=PASS。303条有限二项尾测试、52条R=0/1/2通用闭式参数、10条指定R2半维族全部通过。未新增kernel、receiver或空间网格；a=0矩方案保留暂停，不实现x0矩/空间扫描。

## 有限公式独立核对

对0<=R<m<=k<=n，z∈(0,1)，令s=log(1/z)，

    T=Σ_(j=0)^R binom(k,j)(1−z)^j z^(k−j).

实现先严格Fraction核0<=T<=1，以及

    T<=z^(k−R) Σ_(j=0)^R [k(1−z)]^j/j!
      <=z^(k−R) Σ_(j=0)^R (k s)^j/j!.

第二步用严格log区间的下端认证1−z<=s。再以有理根式区间核

    sqrt(T)<=z^((m−R)/2) Σ_(j=0)^R (n s)^(j/2)/sqrt(j!).

R=0且m=k的精确根式等号单独登记symbolic_equality，避免同根式两个区间相减误作失败。z=0/1按R<k的精确极限T=0/1处理，不算log0。m<=R不会计算q0或Gamma价；原输入域是必要条件。

由T<=sqrt(T)，候选soft+scale权 `3(2+2ns)(T+pi sqrt(n) sqrt(T))` 乘score的k<=n，并用ds=−dz/z，得到

    6n(1+pi sqrt(n)) ∫_0^infty (1+ns)e^(−(m−R)s/2)
      Σ_(j=0)^R (ns)^(j/2)/sqrt(j!) ds
    =6q0(1+pi sqrt(n)) S_R(q0), q0=2n/(m−R).

这核清了n、2、6及Gamma系数，未把尚需几何/selector条件的过程当本程序独立证明。外乘32Lambda/(3eta)得64Lambda eta^(−1)(1+pi sqrt(n))q0 S_R；只有一份eta^(−1)，没有eta^(−2)。

R<=2的闭式明确为

    S0(q)=1+q,
    S1(q)=1+q+sqrt(pi q)(1/2+3q/4),
    S2(q)=S1(q)+q/sqrt(2)(1+2q).

对应Gamma(1)=Gamma(2)=1、Gamma(3)=2、Gamma(3/2)=sqrt(pi)/2、Gamma(5/2)=3sqrt(pi)/4。大n只计算这些闭式，不逐个枚举百万个k。

## 三阶段精确菜单及运行结果

1. 初探177条：n∈{1,2,4,8}，k=1..n，R=0..min(2,k−1)，m∈去重{R+1,k}，z∈{1/4,1/2,3/4}。
2. 近阈值/端点72条：k=n∈{3,8,32}，R∈{0,1,2}，m=R+1；z=2^(−q)、1−2^(−q)，q∈{4,16,64}，并各加z=0和1。原严格事件的边界极限与内部测试分开记。
3. 扩大54条：k∈{16,64,128}、n=2k，R∈{0,1,2}，m∈{R+1,k}，z∈{1/16,1/2,15/16}。

闭式52条：n∈{4,8,16,100,10^4,10^6}，R∈{0,1,2}，m从去重{R+1,ceil(n/2),n}选取且严格m>R。另R2指定族10条，n∈{3,4,5,6,7,8,16,100,10^4,10^6}，m=max(3,ceil(n/2))；因此显式包括旧正条目可用的n4/m3/R2，不只测试无旧覆盖的R1。

全部菜单确定性，seed=null，未根据结果追加接收点或质量。有限测试不是一般证明；binomial概率至T、soft-TV、scale包络及原source/time回代条件依本轮解析独审。

## 显式根阶常数（有条件）

R1、m=ceil(n/2)、n>=4：q0<=8，S1递增，(1+pi sqrt(n))/sqrt(n)<=pi+1/2。因此root-normalized外价系数的严格区间约为

    77537.21974507794982387479744759 < 77538.

可写条件价 `77538 Lambda eta^(−1) sqrt(n)`，亦可使用宽常数78000。该常数来自闭式上界，不是拟合n曲线。

R2、m=max(3,ceil(n/2))、n>=3：n=3..6直接q0<=12；n>=6由m−2>=n/6得同界。独立区间算得S2(12)≈283.4616567089141<380，pi+1<5。若**原eta=1/2条件已成立**，则

    128*12*380*5=2918400 < 2^22=4194304,

所以候选条件外价<=2^22 Lambda sqrt(n)。程序同时保存较精细的闭式价，不因宽常数通过就暗称最优。旧pair非空、k4或R2覆盖不自动给eta>=1/2，也不认证FULL或所有未付域。

## 旧partial_capture_scope独立核验

阅读实现后另写独立读取/聚合函数，没有调用或import其程序。核固定151 detail SHA `6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9` 与136 SHA `1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de`，并核partial_capture_scope源码/JSON绑定SHA。逐segment用threshold和lo/hi的有理中点重建坐标score，与原segment k吻合；逐条另核v good/rho>0、u bad、delta=kv−ku>0、saved I>0。盒边界严格outside为|x_i−v_i|>L/2，等号归inside；只在该segment的scored坐标中计outside。

8376旧行、5342 saved pair条目全部kv=4；按outside数计：

| outside数 | saved pair条目 | 有该类条目的行数 |
|---|---:|---:|
| 0 | 0 | 0 |
| 1 | 0 | 0 |
| 2 | 40 | 32 |
| 3 | 459 | 315 |
| 4 | 4843 | 1269 |

R2的40条全来自segment0，segment1/2为0。R类行数可能交叠，不能相加称不同receiver数量。105个分组字段（含segment和各grid）与Luna保存结果精确一致。此处R2“覆盖”指at-most2的几何/score条目非空；并未认证eta、原history或真实接收费用。

权重方面只独立复算了**保存的**corrected权重与保存p/I十进制的有限加权和，结果逐字段相同；没有重新认证cell/orbit几何权重来源或midpoint误差，因此主结论只报告saved条目counts。JSON中的pI/p-volume只能作为saved诊断，不是连续积分证书，也不能由此推有限dx收益。saved pair I合计与row.I的最大小数差约2.32e−17，属于旧浮点字段舍入尺度，本轮未重算原核/FA的真实值或反演rho。

## 证书精度、复现与真实账本

只用Python标准库，实际解释器 `/opt/homebrew/opt/python@3.14/bin/python3.14`，PYTHONPATH未设置：

    /opt/homebrew/opt/python@3.14/bin/python3.14 partial_tail_check.py

log用96项atanh有理级数、二进制约化及显式正尾；pi用Machin公式16atan(1/5)−4atan(1/239)和80项交错余项；根式用math.isqrt给100位十进制格的有理向外端点，并精确核端点平方方向，完全平方根返回等号。Gamma半整数的pi区间传播严格；Decimal35只作显示，不用于通过判定。JSON约1.94MB，保存全部有限参数、尾/根式/闭式区间及独立scope核验。

本程序实际调用3次：首次manifest把n4/R2的m=ceil(n/2)=2送入assert，违反m>R，进程exit1；修正为明确域筛选（不修改参数制造原合法性），第二次完整运行exit0并保存PASS。Luna随后只补portable路径接口并重绑其scope JSON后，本程序也补--detail/--template/--scope-json/--scope-source路径参数，第三次完整复现PASS，105字段结果不变，并核其新源码SHA `7b25d0891249bf981ced8dca95e227571e34af423fec2ed90d849e1a1d5105ae` 与新JSON SHA `3cdebc74d62dd94e7a00002ccc69f591299b61893c5f8c548163a30d91618623`。共1次失败、2次成功，无核/空间网格调用；只读摘要不算producer执行。

冻结SHA256：

- partial_tail_check.py：`6c482bfde04961498ebcaddef6c86d80bc6fa1dfd316ebd67b6ff3729eb8b7df`
- partial_tail_check.json：`c72a20ebb10e5bd931b6b17a3440e0273fbb6d087b466f9e9f8eac129c10927d`

原moment_numeric_plan仍暂停；有限交付完成后停止，不补原x0或其它点核。
