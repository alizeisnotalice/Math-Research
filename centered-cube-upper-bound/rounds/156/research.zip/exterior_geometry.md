# R156：盒外来源的少量 score 坐标失捕获预算

状态：本文证明一个明确包含盒外来源的条件接收估计；不要求 v∈Q_L(x)。它保留真实产品核位移与来源 score 的联合关系，并支付实际 soft/尺度选择、来源、time、唯一 j 和 β 外费。条件是已激活 score 坐标中失去捕获的个数至多固定 R，score 总数 k≥m>R，原删源保留比例 η≥η0。固定 R、m 为 n 的固定比例时为根阶费用。尚不支付多失捕获、低 score、低 η 补集；有限旧点覆盖须由独立数值报告确认，不由定理自动宣称。

## EG1. 原对象、共同变元与盒外子支

沿本轮原合同：p=P_{s,L}(x−y)，Q* 为同一 x 上三核原平均，原 good-v/bad-u 门为 KQ*(u)/w_g(u)<p≤KQ*(v)/w_g(v)。ρ_v(x) 使用原共同 α、K0、J、TΔ，资格外为零。本文不冻结、重新选择或独立优化这些量；只在正上界末步使用 0≤ρ≤1。

原接收交通已在合法 hard 条件下按16/3放松，外系数为32Λ/3。保留本轮 v∉Q_L(x) 和原未付 history、窗口及其余门。原 L,R_scale∈[a,b]、t≤g=√(L R_scale)、c_j≤1；这里 R_scale 是原尺度，与下文整数 R 无关。

按已审 R155 变元设

\[
 z=c_jt/b,\quad C_i(v)=C(|y_i-v_i|/b),\quad
 w_z(v)=\prod_i\min\{1,C_i(v)/z\},\quad
 I_z(v)=\{i:C_i(v)<z\},\quad k_z(v)=|I_z(v)|.
 \tag{EG1}
\]

实际窗口内 0<z≤1、dt/t=dz/z，w_t=w_z、k_t=k_z。固定底集 D_V(y)∩T0(y) 与 j 无关，而原 Z_{j,t} 的删块一般依 j。令

\[
 E_z=\int_{D_V(y)\cap T0(y)}w_z\,d\nu_V,
 \qquad d\widehat\Pi_z=E_z^{-1}1_{D_V(y)\cap T0(y)}w_z\,d\nu_V,
 \qquad\eta_j(z)=e_{j,bz/c_j}/E_z.
\]

E_z=0 时无原交通；合法时间且 η_j>0 时

\[
 d\Pi_{j,bz/c_j}
 =\eta_j(z)^{-1}1_{Z_{j,bz/c_j}}d\widehat\Pi_z.
 \tag{EG2}
\]

非法时间不新定义删源，只保持原窗口为零。完成来源比较后才扩大 z 域。

对接收尺度 H，定义失捕获个数

\[
 N_H(x;y,v,z)=\#\{i\in I_z(v):|x_i-v_i|>H/2\}.
\]

这是只数 **已激活 score 坐标**。未激活坐标可任意盒外；即使 N_H=0，也不推出 v∈Q_H(x)。对固定整数 0≤R<m≤n、0<η0≤1，目标子支为

\[
 \mathcal E_{R,m,\eta_0}:
 \quad v\notin Q_L(x),\quad k_z(v)\ge m,\quad
 N_L(x;y,v,z)\le R,\quad\eta_j(z)\ge\eta_0.
 \tag{EG3}
\]

上述条件再交原未付域，不替换原 good/bad 或储备资格。

## EG2. 新命题与全部常数

记

\[
 q_0=\frac{2n}{m-R},\qquad
 S_R(q)=\sum_{j=0}^R\frac{q^{j/2}}{\sqrt{j!}}
 \{\Gamma(1+j/2)+q\Gamma(2+j/2)\},
\]

其中 Γ(a)=∫_0^∞u^{a−1}e^{−u}du。要证且以下证明

\[
 \boxed{2\Lambda P(\mathcal E_{R,m,\eta_0})
 \le64\Lambda\eta_0^{-1}(1+\pi\sqrt n)
       q_0S_R(q_0)W_\beta.}
 \tag{EG4}
\]

若 R 固定，m≥θn 且 n≥2R/θ，则 q0≤4/θ。因而

\[
 2\Lambda P(\mathcal E_{R,m,\eta_0})
 \le64\eta_0^{-1}(1+\pi)\frac4\theta
 S_R(4/\theta)\,\Lambda\sqrt n\,W_\beta.
 \tag{EG5}
\]

这是一份明确条件费用，不是全盒外付款。常数未作数值优化，随着允许失捕获数 R 增大会增长。

例如 R=1、n≥2、m=max{2,⌈n/2⌉} 时 q0≤8，且

\[
 8S_1(8)=72+104\sqrt{2\pi}.
\]

因此 η0=1/2 时该盒外子支费用至多

\[
 128(1+\pi)(72+104\sqrt{2\pi})\,
 \Lambda\sqrt n\,W_\beta.
 \tag{EG6}
\]

EG6 只为展示无隐含维数费用；实际使用应保留 EG4 的更锐原参数。

本轮与既有盒外点更相关的默认族取 R=2、n≥3、m=max{3,⌈n/2⌉}、η0=1/2。此时 q0≤12，且

\[
 S_2(q)=1+q+\sqrt{\pi q}(1/2+3q/4)
             +\frac q{\sqrt2}(1+2q)\le380\quad(q\le12).
\]

最后一个粗界用 π<4、√48<7、1/√2≤1 即可。故

\[
 \boxed{2\Lambda P(\mathcal E_{2,\max\{3,\lceil n/2\rceil\},1/2})
 <2^{22}\Lambda\sqrt n\,W_\beta\qquad(n\ge3).}
 \tag{EG6a}
\]

准确粗系数为128·12·380·5=2918400<2²²。R=1、R=2 是不同参数选择，各自适用 EG4；不把两份不同分支的并集免费登记为一次同价。默认只登记 EG6a 一支。

还有一个允许 R 缓慢增长的直接推论。Cauchy–Schwarz 给 Γ(1+j/2)≤√(j!)，Gamma 递推给 Γ(2+j/2)≤(1+j/2)√(j!)。因此

\[
 S_R(q)\le(R+1)\max\{1,q^{R/2}\}\{1+q(1+R/2)\}.
 \tag{EG6b}
\]

固定 θ>0，若 m≥θn、R≤θn/2、R=o(log n)、η0^{-1}=n^{o(1)}，则 EG4 的费用为 Λ n^{1/2+o(1)}Wβ。该结论仍限于 EG3；不因此支付任意 R 或低 score 的盒外剩余。


## EG3. 真核捕获概率与二项尾：来源 score 真正进入 receiver 积分

原 F=max(h1,φ) 是偶且径向非增、0≤F≤1；C(d)=∫_{−1/2}^{1/2}F(u−d)du 也径向非增且 C(0)=1。对任意固定合法 s∈[0,1]、H≤b，真实 receiver 产品概率 P_{s,H}(x−y)dx 下，各接收坐标独立。对每个 i∈I_z(v)，

\[
 \Pr_{s,H}\{|x_i-v_i|\le H/2\}
 =\int_{-1/2}^{1/2}p_s(u+(v_i-y_i)/H)du
 \le C(|y_i-v_i|/H)\le C_i(v)<z.
 \tag{EG7}
\]

这利用了 x−y 与 x−v 在同一个一维积分中的相对位移 y−v。独立性只属于此处固定参数下的 **receiver 产品概率**，与 ν 或 Π 的坐标无关。

独立 Bernoulli 捕获指标的成功概率均≤z，所以对 k=k_z(v)>R，单调耦合给

\[
 \Pr_{s,H}\{N_H\le R\}\le
 T_{k,R}(z):=\sum_{j=0}^R{ k\choose j}(1-z)^jz^{k-j}.
 \tag{EG8}
\]

T 是至少 k−R 次捕获的二项尾。保留整个尾而不是仅以组合数乘 z^{k−R}，避免丢掉近端点失捕获因子。该事件允许 v 在全 n 维盒外；这与 R155 的全部坐标捕获条件不同。

## EG4. 连续 soft 选择器的实际费用

固定 H 与事件 A_H={N_H≤R}，它不依 s。对 0<s<1，原混合核每坐标 Fisher 信息满足

\[
 \int\frac{(\phi-h_1)^2}{p_s}\le\frac1{s(1-s)}.
\]

例如逐点 (φ−h1)²/p_s≤φ/s+h1/(1−s)，再用两者积分为1。每坐标 score 均值为零；产品核因而给

\[
 \int\frac{|\partial_sP_{s,H}|^2}{P_{s,H}}dx
 \le\frac n{s(1-s)}.
\]

用 EG8 与 Cauchy–Schwarz，

\[
 \int_{A_H}|\partial_sP_{s,H}|dx
 \le\sqrt{\frac{nT_{k,R}(z)}{s(1-s)}}.
\]

点态 sup_s P_s≤P_0+∫_0^1|∂sP_s|ds，故

\[
 \boxed{\int_{A_H}\sup_{s\in[0,1]}P_{s,H}(x-y)dx
 \le T_{k,R}(z)+\pi\sqrt n\sqrt{T_{k,R}(z)}.}
 \tag{EG9}
\]

这一步明确支付 soft selector，包含 hard 端点；并未以固定参数概率质量代替选择费用。

## EG5. 时间限制缩短尺度带，向上网格不改变原三核

原 t≤√(L R_scale)、R_scale≤b 给 L≥t²/b≥bz²。因此固定 z 时，只需 L∈[ell_z,b]，ell_z=max{a,bz²}。取独立的 **分析用** 向上尺度网格，比例 exp(1/n)，最后加入 b；不改变原 Q* 中 L^+=min(b,(1+1/n)L)。每个合法 L 有网格 H≥L 且 H/L≤exp(1/n)，于是径向单调性给

\[
 P_{s,L}(x-y)\le eP_{s,H}(x-y)\le3P_{s,H}(x-y).
\]

N_H 随 H 增大不增，故 A_L⊂A_H。网格点数至多

\[
 2+n\log(b/ell_z)\le2+2n\log(1/z).
\]

因此，由 EG9，

\[
 \boxed{\int\sup_{s\in[0,1],\ L\in[ell_z,b]}
 P_{s,L}(x-y)1_{\{N_L\le R\}}dx
 \le3\{2+2n\log(1/z)\}
 \{T_{k,R}(z)+\pi\sqrt n\sqrt{T_{k,R}(z)}\}.}
 \tag{EG10}
\]

这是完整实际 soft/尺度包络。没有使用错误方向 1/log(1+1/n)≤n；原 c_j 与 Lplus 不变，网格只为证明上界。

## EG6. 共同来源、唯一 j 与完整时间累计

从原32Λ/3母式出发，在子支 EG3 上保持原 actual gate。先用 δ(v,u)≤k_t(v)，将 bad u 的原后验积分按概率≤1放松；于是只剩一份 good Π_j。再用 η_j≥η0 和 EG2 比较 Π_j≤η0^{-1}widehatΠ_z，并逐 j 变元到同一 z。此时 k_z、widehatΠ_z 与 j 无关，原 1_{j(x)=j} 仍在。窗口保持到比较完成，再扩展为0<z≤1；于是唯一 j 可在同一 receiver 积分前合并。

保留原 ρ 后用ρ≤1，只对其余非负门作≤1放松，用 EG10 得

\[
\begin{split}
2\Lambda P(\mathcal E_{R,m,\eta_0})
\le{}&\frac{32\Lambda}{\eta_0}
\mathbb E\sum_V\int d\beta_V(y)
\int_0^1\frac{dz}{z}\int 1_{k_z\ge m}k_z\,
 \{2+2n\log(1/z)\}\\
&\times\{T_{k_z,R}(z)+\pi\sqrt n\sqrt{T_{k_z,R}(z)}\}
 d\widehat\Pi_z(v).
\end{split}
 \tag{EG11}
\]

原外 hard16/3 只使用一次。此处 η 是一次而非平方；β 从未替换为 ν。widehatΠ_z 随 z 变化可以任意，只用其概率质量。

令 u=log(1/z)，λ=(m−R)/2>0。由 sqrt(Σa_j)≤Σsqrt(a_j)、1−e^{−u}≤u、k≤n 与 k−j≥m−R，得到

\[
 \sqrt{T_{k,R}(e^{-u})}
 \le\sum_{j=0}^R\sqrt{{n\choose j}}u^{j/2}e^{-\lambda u}
 \le\sum_{j=0}^R\frac{n^{j/2}}{\sqrt{j!}}
               u^{j/2}e^{-\lambda u}.
 \tag{EG12}
\]

又 0≤T≤1，故 T+π√n√T≤(1+π√n)√T。将 k≤n 及 EG12 代入完整时间积分，不需假定 k 在时间上恒定，得到

\[
\begin{split}
&\int_0^\infty\sup_{m\le k\le n}
 k(2+2nu)\sqrt{T_{k,R}(e^{-u})}\,du\\
&\quad\le2n\sum_{j=0}^R\frac{n^{j/2}}{\sqrt{j!}}
 \left\{\frac{\Gamma(1+j/2)}{\lambda^{1+j/2}}
       +n\frac{\Gamma(2+j/2)}{\lambda^{2+j/2}}\right\}
 =2q_0 S_R(q_0).
\end{split}
 \tag{EG13}
\]

将 EG13 代入 EG11，证明 EG4。没有额外时间 log2，没有未列出的 j 个数或 selector 因子。

## EG7. 原盒外补集与本轮边界

本稿只支付原盒外余部中的 EG3。按以下顺序保留互斥未付部分：

1. η_j(z)<η0；
2. η_j(z)≥η0，但 k_z(v)<m；
3. η_j(z)≥η0、k_z(v)≥m，但 N_L(x;y,v,z)>R。

全部仍交原 v∉Q_L(x) 与此前未付域。未来若让 R 随 n 增大，必须带上 S_R(q0) 的真实费用；不能称任意盒外来源都获得固定常数根阶付款。若 m≤R，EG12 的正指数衰减丢失，本文定理不适用。

共同 α 始终原位，未冻结或优化；但证明仅用其产生的合法 0≤ρ≤1，尚未取得额外储备增益。故本稿不自动支付那些多个已激活 score 坐标都在盒外、且ρ有正量的关键来源。少量未激活坐标盒外的情形被本稿允许，这是比全盒捕获更宽的真正 receiver 几何分支；实际旧模型是否进入，必须逐点核原 score 与位置，不能由‘全部旧点盒外’一语判断。

### 已有盒外点的有限覆盖检查

本稿已读同轮 `partial_capture_scope.md`。其在旧8376个接收点保存的5342条正 pair terms 中核到：k=4；score坐标盒外数恰为2的有40条、为3的459条、为4的4843条，R=0/1无条目。R=2对应的正保存I和为0.7970184812。该检查没有新增receiver点或kernel评估，坐标盒判定用原保存有理数。

这些40条满足 EG6a 的几何/score 条件（n=4 应选 m=3，不能用 m=2 去套 m>R 的本定理）。它们说明新子支与上一轮全盒捕获的空旧样本不同。但原 η 前提、FULL树历史与连续dx交通都尚未认证；上述计数与保存I不能称为完整已付交通份额，尤其不能把全部5342条视为被 EG6a 覆盖。R=3、4 的主要样本仍留在本稿默认分支外。

此处不将 prior_pair_moments 的未审张量/分数矩当作已证工具。EG7–EG13 都由真实核、固定 receiver 产品结构和原参数范围直接推导。没有改变相反三核条件以制造有利事件，也没有把连续receiver概率的固定参数归一化当完整付款。

本稿作者未新增核评估、未更改原 α/ρ 或数据；独立旧点几何核对结果由主级整合。全部极限固定原 ν、e、ρ、gate 和 history，只截断非负积分，不重算归一后声称单调。只写本文件，不改他人或 Git；完成有界交付后停止等审。
