# R156 partial source-box capture on saved pair terms

## Finding

The relaxed capture condition is nonempty on the existing R151 pressure data. On both saved grids, there are FA pair terms whose scored good source `v` has all four coordinates activated at the segment midpoint (`k=4`, so `k>=m=ceil(sqrt(4))=2`) while at most two activated coordinates lie outside `Q_L(x)`. Thus the fixed `R=2` branch has observed positive saved traffic terms. No R151 kernel or receiver point was recomputed.

For every saved pair term, the script verifies that its `segment` index selects the corresponding R136 `score_segments[segment]` interval and that the pair source's coordinate activation count from the four R136 thresholds at the interval's arithmetic midpoint equals the stored segment `k[v]`. This follows the R151 producer: it loops over `model['profiles']` (built from `template['score_segments']`) and stores that segment index; pair terms are added only when the source is good, has saved `rho>0`, and `kv==4`. The midpoint is inside the segment, so it fixes the same threshold activation pattern throughout that open interval; endpoint behavior is not inferred from the midpoint.

The exact cube test uses the saved rational receiver coordinate `xq`, the R136 rational source position, and `L=9/10`: coordinate `j` is inside iff `|xq[j]-position[v][j]|<=9/20`. `R` counts outside coordinates only among score-activated coordinates. In these pair terms all four coordinates are activated, so R ranges over 0–4.

## Pair-term counts by outside-coordinate count

`I` values below are the saved pair-term binary64 numbers frozen through their JSON decimal representations and summed exactly as decimal Fractions. `p-weighted cell volume` sums `p(x_mid) * dx_weight_corrected` once per row represented in that R bin. `p-weighted saved-I` sums `p(x_mid) * dx_weight_corrected * I` per pair term. The overlap correction is exact for the cell's `1/k` geometry, but these are still midpoint quadrature diagnostics, not integral enclosures.

| R | Pair terms, all 8,376 points | Saved I sum | p-weighted cell volume | p-weighted saved-I |
|---:|---:|---:|---:|---:|
| 0 | 0 | 0 | 0 | 0 |
| 1 | 0 | 0 | 0 | 0 |
| 2 | 40 | 0.7970184812 | 0.0005734531 | 0.00001555921 |
| 3 | 459 | 19.7411597366 | 0.0325854022 | 0.00245491170 |
| 4 | 4,843 | 44.3262279662 | 0.1173727940 | 0.00662299918 |

The observed `R=2` pair terms split into 14 on m=4 (saved I sum 0.2877486574) and 26 on m=8 (0.5092698237). The complete per-grid and per-segment counts are in the JSON. This shows a nonempty finite sampled branch for `R=2`; it does not show how much of the continuous R155 transport integral that branch pays.

## Segment times and limitations

The three R136 intervals are `[0.5, 0.6280349911...]`, `[0.6280349911..., 0.7892964896...]`, and `[0.7892964896..., 0.9463145520...]`. Their arithmetic midpoints produce source `k` vectors `[4,4,4,0,4,0]`, `[4,4,4,4,4,0]`, and `[4,4,4,4,4,4]`. The saved pair terms have R counts `R=2: 40`, `R=3: 459`, `R=4: 4,843`; there are no R=0 or R=1 terms. These are only score-activated coordinates; unactivated coordinates are not counted as outside.

The producer saved pointwise good/rho masks and pair-term `I`, not certified kernel intervals. It lacks the full fixed-`(omega,V,j,y,t)` outer factors, history, and a continuous-in-x integral for `C_t`. Therefore the p-weighted quantities above are finite midpoint quadrature, not certified actual traffic shares. This check establishes a nonempty sampled branch, not a general payment bound or FULL coverage; it does not establish any universal `eta` premise or FULL tree blocks.

## Reproducibility

- Producer: [partial_capture_scope.py](partial_capture_scope.py), standard-library only.
- Output: [partial_capture_scope.json](partial_capture_scope.json).
- Input point file SHA-256: `6c2180637b013ccfb255b25de7af9070c62a8077c8716e91aa0574b5bfa07df9`.
- R136 source/template SHA-256: `1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de`.
- Producer SHA-256: `7b25d0891249bf981ced8dca95e227571e34af423fec2ed90d849e1a1d5105ae`.
- JSON SHA-256: `3cdebc74d62dd94e7a00002ccc69f591299b61893c5f8c548163a30d91618623`.
- The JSON binds the producer hash and records three successful script invocations, zero failed invocations, zero new kernel evaluations, and zero new receiver points. The final run followed the portable interface: `python3 partial_capture_scope.py --detail <R151-json> --template <R136-json> --output <result-json>`; all three arguments are `Path` values and default to the paths above and the adjacent JSON.

The producer passed `py_compile` and asserts segment activation counts, pair-term source good/rho masks, and exact coordinate membership for every saved pair term.
