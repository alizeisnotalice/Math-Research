#!/usr/bin/env python3
"""Finite R156 location check on saved R151 pair terms; no kernels evaluated."""
from collections import Counter, defaultdict
from fractions import Fraction as F
from pathlib import Path
import argparse, hashlib, json

HERE = Path(__file__).resolve().parent
R151 = Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json')
R136 = Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/active_traffic_v2.json')
OUT = HERE / 'partial_capture_scope.json'

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def frac(x): return x if isinstance(x, F) else F(str(x))
def fs(x): return f'{x.numerator}/{x.denominator}'

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--detail',type=Path,default=R151,help='R151 receiver_probe_points.json')
    parser.add_argument('--template',type=Path,default=R136,help='R136 active_traffic_v2.json')
    parser.add_argument('--output',type=Path,default=OUT,help='destination JSON path')
    args=parser.parse_args()
    points = json.loads(args.detail.read_text())
    case = next(x for x in json.loads(args.template.read_text())['cases'] if x['id'] == 'I1')
    atoms = case['atoms']; L = frac(case['parameters']['L']); half = L/2
    pos = [[frac(q) for q in a['position']] for a in atoms]
    thresholds = [[frac(q) for q in a['thresholds']] for a in atoms]
    segments = case['score_segments']
    segment_data=[]
    for si,sg in enumerate(segments):
        lo,hi=frac(sg['lo']),frac(sg['hi']); mid=(lo+hi)/2
        active=[[q<mid for q in thresholds[v]] for v in range(6)]
        counts=[sum(mask) for mask in active]
        assert counts==[int(k) for k in sg['k']], (si,counts,sg['k'])
        segment_data.append({'segment':si,'lo':fs(lo),'hi':fs(hi),'midpoint':fs(mid),'k_by_source':counts})

    by_R={r:{'pair_term_count':0,'I_sum':F(0),'p_weighted_saved_I_sum':F(0),
             'p_weighted_cell_volume':F(0),'rows_with_pair_term':0,
             'by_segment':{str(i):{'pair_term_count':0,'I_sum':F(0)} for i in range(len(segments))}}
          for r in range(5)}
    grid_by_R={m:{r:{'pair_term_count':0,'I_sum':F(0),'p_weighted_saved_I_sum':F(0),
                    'p_weighted_cell_volume':F(0),'rows_with_pair_term':0}
                   for r in range(5)} for m in points['point_records']}
    pair_n=0; point_rows=0; active_source_point_pairs=0
    role_counts=Counter(); source_counts=Counter(); outside_hist=Counter()
    total_I=F(0); total_pI=F(0)
    for m,rows in points['point_records'].items():
        for row in rows:
            point_rows+=1
            x=[frac(q) for q in row['xq']]
            wt=frac(row['dx_weight_corrected'])
            p=frac(row['p'])
            active=[bool(row['good'][v]) and float(row['rho'][v])>0 for v in range(6)]
            active_source_point_pairs+=sum(active)
            categories=defaultdict(list)
            for term in row['pair_terms']:
                pair_n+=1
                segi=int(term['segment']); v=int(term['v']); u=int(term['u'])
                mask=[[q<frac((frac(segments[segi]['lo'])+frac(segments[segi]['hi']))/2) for q in thresholds[v]]][0]
                # Pair producer only stores scored v sources (k=4); validate the
                # segment's source role and use coordinatewise scores at its midpoint.
                assert sum(mask)==int(segments[segi]['k'][v])==4
                outside=sum(mask[j] and abs(x[j]-pos[v][j])>half for j in range(4))
                assert 0<=outside<=4
                assert active[v], (m,row['index'],segi,v)
                categories[outside].append(term)
                source_counts[(m,v)]+=1
                outside_hist[(m,outside)]+=1
                role_counts[(m,v,'active')]+=1
                val=frac(term['I'])
                total_I+=val; total_pI+=p*wt*val
            for r,terms in categories.items():
                z=by_R[r];z['rows_with_pair_term']+=1
                z['p_weighted_cell_volume']+=p*wt
                gz=grid_by_R[m][r];gz['rows_with_pair_term']+=1;gz['p_weighted_cell_volume']+=p*wt
                for term in terms:
                    val=frac(term['I']);segi=int(term['segment'])
                    z['pair_term_count']+=1;z['I_sum']+=val
                    z['p_weighted_saved_I_sum']+=p*wt*val
                    gz['pair_term_count']+=1;gz['I_sum']+=val;gz['p_weighted_saved_I_sum']+=p*wt*val
                    z['by_segment'][str(segi)]['pair_term_count']+=1
                    z['by_segment'][str(segi)]['I_sum']+=val

    serial_grid={m:{str(r):{k:(fs(v) if isinstance(v,F) else v) for k,v in vals.items()} for r,vals in rr.items()} for m,rr in grid_by_R.items()}
    out={'status':'completed_finite_saved_pair_scope','scope':'existing R151 I1 point grids only; source v coordinate classification from saved R136 thresholds at each R136 score-segment arithmetic midpoint; no kernels or grids added','producer_sha256':sha(Path(__file__)),'inputs':{'R151_receiver_probe_points_sha256':sha(args.detail),'R136_active_traffic_sha256':sha(args.template)},'geometry':{'dimension':4,'L':fs(L),'cube_half_side':fs(half),'membership':'coordinate j is inside iff abs(xq[j]-source_position[v][j]) <= L/2; outside counted only among score-activated coordinates threshold[v][j] < segment_midpoint','segments':segment_data},'grid_totals':{'point_rows':point_rows,'active_good_rho_positive_source_point_pairs_saved_float_masks':active_source_point_pairs,'pair_term_count':pair_n,'saved_pair_I_sum':fs(total_I),'p_weighted_saved_pair_I_sum_using_dx_weight_corrected':fs(total_pI),'outside_coordinate_histogram':{f'm{m}_R{r}':outside_hist[(m,r)] for m in ('4','8') for r in range(5)}},'by_grid_R':serial_grid,'by_R':{str(r):{k:({sk:{'pair_term_count':sv['pair_term_count'],'I_sum':fs(sv['I_sum'])} for sk,sv in v.items()} if k=='by_segment' else (fs(v) if isinstance(v,F) else v)) for k,v in vals.items()} for r,vals in by_R.items()},'execution':{'producer_invocations_total':3,'failed_invocations':0,'final_completed_invocation':3,'new_kernel_evaluations':0,'new_receiver_points':0},'limitations':['good and rho>0 role masks are saved R151 float64 diagnostics','I and p are saved binary64 values frozen by their JSON decimal strings; p-weighted sums use corrected cell weights but remain midpoint quadrature, not error bounds','pair_terms are finite inner FA/profile contributions and do not encode the full C_t outer factors, history, or continuous x-integral','this does not establish general capture/payment or FULL coverage']}
    args.output.write_text(json.dumps(out,separators=(',',':'))+'\n')
    print('rows',point_rows,'pair_terms',pair_n,'sha256',sha(args.output),'bytes',args.output.stat().st_size)

if __name__=='__main__': main()
