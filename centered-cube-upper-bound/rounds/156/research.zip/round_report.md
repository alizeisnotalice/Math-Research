# 第156轮：盒外来源的部分坐标捕获预算

一般n^(1/2+o(1))一致弱型目标仍未闭合。本轮从155全盒捕获扩展到盒外：只要求k个已激活score坐标中，至多R个落在当前接收盒外；未激活坐标不限制。原相反三核、共同alpha/合法rho、实际输入类别不变。完整证明见research.tex及exterior_geometry.md，Sol先盲审再逐式核两稿通过。

## 新估计及真实费用

固定实际参数的捕获概率受T_kR(z)=Σj≤R binom(k,j)(1−z)^j z^(k−j)支配。通过产品核Fisher信息支付连续soft选择，辅助e^(1/n)向上尺度网格支付原L≥bz²的剩余范围；不改变原Q*的Lplus。来源比较只用一次eta^-1，保持原唯一j，score随z变化无须冻结。原外hard16/3和总外因子32Λ/3完整保留。

条件支完整价：64Λ eta0^-1(1+π√n)q0 S_R(q0)Wβ，q0=2n/(m−R)，m>R。固定R、m≥θn给根阶；R=o(log n)、eta0^-1=n^o(1)且m≥θn、R≤θn/2给条件n^(1/2+o(1))，所有增长费用显式保留。这不是全函数类上界闭合。

具体R2族：m=max(3,ceil(n/2)),n≥3,eta0=1/2，q0≤12、S2≤380，外价<2^22Λ√nWβ。粗常数维数一致，未作拟合；精确qS公式保留。原盒外未付域按eta<eta0、eta≥eta0且k<m、eta≥eta0且k≥m而N_L>R作严格互斥补集。负账/history/futurebad/Ndel等不吞并。

## 与主要压力的关联及限制

原8376点、5342 saved pair terms的k均为4，scored盒外数恰为2者40条（32行），为3者459条，为4者4843条。n4/R2时必须m3，不能m2。40条证明几何和score条件的离散非空；没有树eta与FULL历史证书，不认证完整付款支的实际连续交通份额。大量失捕获的剩余仍占主要条目，本轮不把少量失捕获当全域。数值保存pI只为诊断，不由之断言连续接收费用减少。

## 实际检验及复现

- 三阶段有理/区间二项尾检查303条：初探177、阈值及端点72、扩大54；52个R0/1/2通用闭式参数与10个R2指定族通过。大维至10^6仅闭式，不爆量枚举整数k。
- log用atanh显式余项、π用Machin交错余项、根式用整数平方根向外包围；Gamma整数/半整数用解析式。Decimal仅显示，有限检查不替代一般证明。
- Luna先完成旧点几何分类，Sol另实现独立读取与聚合，105分组字段精确一致。保留原float角色/保存I限制；没有重建空间求积误差或FULL。
- 数值作者首次误把m=R送入域断言，进程失败；改为明确合法域筛选后通过。原非法参数未被默认为合法。完整账见partial_tail_notes.md。scope程序只加便携路径参数，运行账3次成功；没有新kernel、receiver或空间网格。
- 主代理实际完整新目录复现：`python3 reproduce.py --rounds /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds --detail /Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json --destination /Users/zhengzhihao/Desktop/T/output/r156_parent_replay_20261015_a`，退出0，两份JSON逐字节同最终产物，独立105字段PASS。

## 辅助路线和下一瓶颈

真实rho已限制在good资格上，因此a=1联合矩逐点被a=0坏侧矩支配。只用简短证明确定此点，未投入Bernstein张量展开或新核扫描；moment_audit记录PM1–8及实际g(x)变系数必须留积分内部的边界。该短审不是partial定理依赖，也不领取额外空间付款。

下一步仍是大量已激活坐标均在盒外、低保留质量和低score的共同费用，尤其要利用原alpha/三核在这些域的实际作用。不能靠继续扩大固定R常数来声称任意盒外来源已覆盖。原总目标保持不变。

本轮只用自含核/Fisher/二项/Gamma推导；此前K04技能核查的高斯反集中条件仍不具备，没有引用不适用外部定理。实际扣额数据不可得，不猜模型比例。详细LaTeX保留，不编译PDF。解压后以同一reproduce.py命令、139轮归档及151轮可重建detail复现；仅Python标准库，输出目录必须不存在。
