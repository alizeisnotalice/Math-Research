#!/usr/bin/env python3
"""Portable R156 finite proofs and saved-grid diagnostics; no kernel evaluations."""
from pathlib import Path
import argparse,zipfile,shutil,subprocess,sys,json
p=argparse.ArgumentParser();p.add_argument('--rounds',type=Path,required=True);p.add_argument('--detail',type=Path,required=True);p.add_argument('--destination',type=Path,required=True);a=p.parse_args()
src=Path(__file__).resolve().parent;dst=a.destination.resolve()
if dst.exists():raise SystemExit('Use a new destination')
dst.mkdir(parents=True)
for n in ['partial_capture_scope.py','partial_tail_check.py']:shutil.copy2(src/n,dst/n)
with zipfile.ZipFile(a.rounds/'139/research.zip') as z:
 names=[n for n in z.namelist() if Path(n).name=='active_traffic_v2.json'];assert len(names)==1
 (dst/'active_traffic_v2.json').write_bytes(z.read(names[0]))
def run(args):
 r=subprocess.run([sys.executable,*map(str,args)],cwd=dst,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stderr+r.stdout)
 print(r.stdout.strip())
base=['--detail',a.detail,'--template',dst/'active_traffic_v2.json']
run(['partial_capture_scope.py',*base,'--output',dst/'partial_capture_scope.json'])
run(['partial_tail_check.py',*base,'--scope-json',dst/'partial_capture_scope.json','--scope-source',dst/'partial_capture_scope.py','--output',dst/'partial_tail_check.json'])
for n in ['partial_capture_scope.json','partial_tail_check.json']:assert (src/n).read_bytes()==(dst/n).read_bytes(),n
j=json.loads((dst/'partial_tail_check.json').read_text());assert j['status']=='PASS';assert j['saved_scope_independent_audit']['field_checks']==105
print('REPLAY_PASS; both JSON byte-identical; independent 105-field saved-scope audit; no new kernel/receiver')
