#!/usr/bin/env python3
"""Round57 centered-cube spectral one-u-step energy, standard library only.
Full axis energy uses the closed formula, avoiding high-frequency time-grid
alias. Other directions use log-low/phase-resolved-linear-high Simpson
refinements, with separately displayed analytic omitted-tail envelopes.
No interior interval certification, fitted exponent, or weak-type inference.
"""
from decimal import Decimal,localcontext
from pathlib import Path
import json
import math
import random
import time

LOW=2.**-16

def axis_energy(n,precision):
    with localcontext() as ctx:
        ctx.prec=precision;r=(Decimal(1)/n).exp()
        def F(z):return z*z*z.ln()/2-3*z*z/4 if z else Decimal(0)
        E=n*(4/r*(F((r+1)/2)-F((r-1)/2))-r.ln()+3)
        return E,Decimal(n)*E/Decimal(n+2).ln()


def axis_entropy_formula(n,precision):
    with localcontext() as ctx:
        ctx.prec=precision;s=Decimal(1)/(2*n)
        sinh=(s.exp()-(-s).exp())/2;x=sinh*sinh
        # At120digits, x>=1/(4*4096^2), so Decimal log(1+x)
        # retains over110 meaningful digits without a separate log1p API.
        return n*((1+x)*(1+x).ln()-x*x.ln())


def axis_guards():
    rows=[]
    for n in (1,2,4,8,16,32,64,128,256,512,1024,2048,4096):
        a,_=axis_energy(n,80);b,ratio=axis_energy(n,120)
        err=abs(a-b)/b;assert err<Decimal('1e-60')
        alternate80=axis_entropy_formula(n,80);alternate120=axis_entropy_formula(n,120)
        ferr=abs(b-alternate120)/b;assert ferr<Decimal('1e-105')
        aerr=abs(alternate80-alternate120)/alternate120;assert aerr<Decimal('1e-68')
        with localcontext() as ctx:
            ctx.prec=120
            leading=(Decimal(n).ln()/2+Decimal(1)/4+Decimal(2).ln()/2)/n
            remainder=b-leading
        rows.append(dict(n=n,axis_entropy_formula_decimal=str(alternate120),entropy80_vs120_relative_error=str(aerr),F_vs_entropy_formula_relative_error=str(ferr),asymptotic_leading_decimal=str(leading),asymptotic_remainder_decimal=str(remainder),full_axis_energy_decimal=str(b),nE_over_log_n_plus2_decimal=str(ratio),decimal80_vs120_relative_error=str(err),precision_digits=[80,120]))
    return rows


def normalize(raw):
    length=math.sqrt(math.fsum(v*v for v in raw));theta=[abs(v/length) for v in raw if v]
    assert abs(math.fsum(v*v for v in theta)-1)<3e-15
    return theta


def directions(n):
    raw=[('axis',[1.],None)]
    if n>=2:raw.append(('sparse2',[1.]*2,None))
    if n>=4:raw.append(('sparse4',[1.]*4,None))
    if n>=16:raw.append(('sparse16',[1.]*16,None))
    raw.extend((('equal',[1.]*n,None),('dyadic',[2.**(-i) for i in range(n)],None),('strong_anisotropic',[1.]+[2.**(-20-i) for i in range(n-1)],None)))
    for offset in (0,1):
        seed=570000+10*n+offset;rng=random.Random(seed)
        raw.append((f'random_signed_{offset}',[rng.uniform(-1,1) for _ in range(n)],seed))
    for name,v,seed in raw:yield name,normalize(v),seed


class Product:
    def __init__(self,theta):
        counts={}
        for v in theta:counts[v]=counts.get(v,0)+1
        self.groups=sorted(counts.items(),reverse=True)
        self.maxcoord=self.groups[0][0]
        self.l1=math.fsum(v*k for v,k in self.groups)
        self.s2=math.fsum(v*v*k for v,k in self.groups)
        self.suffix=[]
        for i in range(len(self.groups)):
            self.suffix.append(tuple(math.fsum(k*v**p for v,k in self.groups[i:]) for p in (2,4,6,8)))
    def sign_log(self,t):
        sign=1;terms=[];approx_bound=0.
        for i,(v,k) in enumerate(self.groups):
            z=t*v
            if abs(z)<1e-3:
                s2,s4,s6,s8=self.suffix[i]
                terms.append(-t*t*s2/6-t**4*s4/180-t**6*s6/2835)
                # For |z|<=1e-3, log(sinc z) remainder after z^6 is
                # bounded by z^8/37000, using its convergent Bernoulli series.
                approx_bound=t**8*s8/37000
                break
            value=math.sin(z)/z
            if value==0:return 0,-math.inf,approx_bound
            if value<0 and k%2:sign=-sign
            terms.append(k*math.log(abs(value)))
        return sign,math.fsum(terms),approx_bound
    def difference(self,t,r):
        a,la,ea=self.sign_log(t);b,lb,eb=self.sign_log(r*t)
        if a==b:
            high,low=max(la,lb),min(la,lb)
            answer=math.exp(high)*(-math.expm1(low-high)) if high>-745 else 0.
        else:answer=a*math.exp(la)-b*math.exp(lb)
        return answer,ea+eb
    def derivative(self,t):
        sign,lg,_=self.sign_log(t)
        if lg<-745:return 0.
        terms=[]
        for v,k in self.groups:
            z=t*v
            if abs(z)<1e-3:terms.append(k*(-z*z/3-z**4/45-2*z**6/945))
            else:terms.append(k*(z*math.cos(z)/math.sin(z)-1))
        return sign*math.exp(lg)*math.fsum(terms)


def squared_product_tail(theta,start,factor,precision=80):
    """Exact analytic envelope integral of product min(1,1/(factor*t*|theta_i|))^2 dt/t, Decimal evaluated."""
    with localcontext() as ctx:
        ctx.prec=precision
        vals=sorted((factor*Decimal.from_float(v) for v in theta),reverse=True)
        k=0;logc=Decimal(0);low=Decimal.from_float(start);answer=Decimal(0)
        for v in vals:
            threshold=1/v
            if threshold<=low:k+=1;logc-=2*v.ln()
            else:
                if k:answer+=(logc-2*k*low.ln()).exp()*(1-(low/threshold)**(2*k))/(2*k)
                else:answer+=(threshold/low).ln()
                low=threshold;k+=1;logc-=2*v.ln()
        answer+=(logc-2*k*low.ln()).exp()/(2*k)
        assert answer>=0
        return +answer


def tail_bounds(theta,n,high,precision=80):
    with localcontext() as ctx:
        ctx.prec=precision;r=(Decimal(1)/n).exp();s2=sum((Decimal.from_float(v)**2 for v in theta),Decimal(0))
        low=Decimal(n)*(r*r-1)**2*s2*s2*Decimal.from_float(LOW)**4/144
        upper=2*n*(squared_product_tail(theta,high,Decimal(1),precision)+squared_product_tail(theta,high,r,precision))
        return +low,+upper


def choose_high(theta,n,name):
    if name in ('axis','strong_anisotropic'):return float(max(64,16*n))
    high=8.
    target=Decimal.from_float(2e-5*math.log(n+2)/n)
    while tail_bounds(theta,n,high)[1]>target:high*=2
    return high


def simpson(function,left,right,steps):
    if steps%2:steps+=1
    h=(right-left)/steps;terms=[];approx=0.
    for i in range(steps+1):
        value,error=function(left+i*h)
        weight=1 if i in (0,steps) else 4 if i%2 else 2
        terms.append(weight*value);approx=max(approx,error)
    return math.fsum(terms)*h/3,steps,approx


def quadrature(product,n,high,refinement):
    r=math.exp(1/n);split=min(high,8./product.l1)
    low_steps=math.ceil(math.log(split/LOW)*32*refinement)
    def logf(u):
        d,err=product.difference(math.exp(u),r)
        return n*d*d,err
    low,ls,err=simpson(logf,math.log(LOW),math.log(split),low_steps)
    linear=0.;ts=0
    if high>split:
        # Product sine frequencies have sum |theta_i|; this controls the
        # maximum phase increment of the linear-t mesh. r included.
        steps=math.ceil((high-split)*r*product.l1*4*refinement)
        def linear_f(t):
            d,error=product.difference(t,r)
            return n*d*d/t,error
        linear,ts,e=simpson(linear_f,split,high,steps);err=max(err,e)
    return dict(refinement=refinement,low_log_steps=ls,high_linear_steps=ts,split_t=split,max_linear_product_phase_increment=(high-split)*r*product.l1/ts if ts else 0.,interior_energy=low+linear,small_argument_log_product_remainder_upper=err)


def naive_product(theta,t):
    return math.prod(math.sin(t*v)/(t*v) if t*v else 1. for v in theta)


def scalar_product_guards():
    rows=[]
    for n in (2,16,128,1024):
        for name,theta,seed in directions(n):
            P=Product(theta)
            for t in (.01,.5,2.,8.):
                sign,lg,err=P.sign_log(t);a=sign*math.exp(lg);b=naive_product(theta,t)
                assert abs(a-b)<2e-13
                rows.append(dict(n=n,direction=name,t=t,compressed_minus_naive=a-b,small_argument_log_remainder_bound=err))
    return rows


def direction_guards():
    rows=[]
    for n in (1,2,4,8,16,32,64,128,256,512,1024):
        for name,theta,seed in directions(n):
            if n==1 and name!='axis':continue
            P=Product(theta);high=choose_high(theta,n,name)
            refinements=[quadrature(P,n,high,k) for k in (1,2,4)]
            lowtail,hightail=tail_bounds(theta,n,high)
            _,tail120=tail_bounds(theta,n,high,120)
            if hightail:
                terr=abs(hightail-tail120)/tail120;assert terr<Decimal('1e-60')
            else:terr=Decimal(0)
            last=refinements[-1]['interior_energy'];previous=refinements[-2]['interior_energy']
            derivative=max(abs(P.derivative(2.**(k/2))) for k in range(-16,25))
            assert derivative<=2+1e-10
            closed=None
            if name=='axis':
                E,_=axis_energy(n,120)
                error=abs(last-float(E))
                assert error<=float(lowtail+hightail)+1e-6*float(E)
                closed=dict(full_energy_decimal=str(E),interior_minus_closed=last-float(E),difference_minus_displayed_tail_allowance=error-float(lowtail+hightail))
            ratio=n*last/math.log(n+2)
            axisE,_=axis_energy(n,120)
            assert last<=float(axisE)*(1+1e-6)
            rows.append(dict(n=n,direction=name,random_seed=seed,theta_absolute_float=theta,theta_L2_squared=P.s2,projection_variance=P.s2/3,nonzero_coordinates=len(theta),compressed_groups=len(P.groups),high_t=high,low_t=LOW,refinements=refinements,interior_nE_over_log_n_plus2=ratio,omitted_tail_nE_over_log_n_plus2_upper=str(Decimal(n)*(lowtail+hightail)/Decimal(n+2).ln()),low_tail_analytic_upper_decimal=str(lowtail),high_tail_analytic_upper_decimal=str(hightail),tail_decimal80_vs120_relative_error=str(terr),last_refinement_energy_difference=abs(last-previous),sampled_max_abs_t_multiplier_derivative=derivative,axis_closed_crosscheck=closed,interior_energy_over_axis_kappa=last/float(axisE),omitted_tail_over_axis_kappa_upper=str((lowtail+hightail)/axisE),last_refinement_difference_over_axis_kappa=abs(last-previous)/float(axisE)))
            print('done',n,name,'nE/log(n+2)',round(ratio,9),'tail',float(hightail),'refdiff',abs(last-previous),flush=True)
    return rows


def main():
    start=time.monotonic();axes=axis_guards();products=scalar_product_guards();directions_data=direction_guards()
    result=dict(round=57,status='PASS',standard_library_only=True,counts=dict(axis_closed_cases=len(axes),direction_quadrature_cases=len(directions_data),product_compression_guards=len(products),quadrature_refinements=3*len(directions_data)),definition='m_theta(t)=product sinc(t theta_i), ||theta||2=1; E_n(theta)=n integral_0^infinity |m_theta(exp(1/n)t)-m_theta(t)|^2 dt/t. Cube[-1,1]^n Fourier convention; radial rescaling leaves energy unchanged.',scope=dict(axis='Fullscale axis closed formula at80/120digits; numerical highfrequency integration is only an auxiliary check.',quadrature='Three refinements of log-low/linear-high Simpson quadrature. Linear steps resolve total product sine phase with maximum increments1/4,1/8,1/16radian; interior quadrature not interval-certified. Exact zeros and oscillations remain genuine integrand features.',normalization='Unit L2 direction means independent uniform[-1,1] projection variance1/3. This keeps variance and any separately proved isotropic log-concave density constant uniform in direction.',tails='Separately proved sinc-envelope high tail and variance small-t low tail, Decimal evaluated. Bounds do not certify interior Simpson error.',small_argument='Grouped identical coordinates plus log-sinc series through z6 for |z|<1e-3. Displayed analytic remainder applies to this series only; floating arithmetic is not outward-rounded.',derivative='Finite sampled |t mprime| guards do not prove the uniform derivative bound; that bound requires a separate even-unimodal projection-density argument.',fitting='Raw nE/log(n+2) comparisons, no exponent or arbitrary-direction maximum fits.',goal='Numerical support for sharper general L2 spectral-step energy; no source-independent capped weak-L1 result or height-nH regularization conclusion asserted.'),sharp_comparison='Separate even-unimodal centered-uniform mixture/Jensen argument proves general spectral energy<=axis kappa_n and the sharp L2 squared constant=kappa_n. Numerical direction comparisons are guards, not the proof.',axis_entropy_formula='kappa_n=n*((1+x)*log(1+x)-x*log(x)), x=sinh(1/(2n))^2; algebraically equivalent to F formula.',axis_asymptotic='kappa_n=(log(n)/2+1/4+log(2)/2)/n+O(log(n+2)/n^3); displayed finite remainders are not fits.',axis_closed_formula='E_axis=n*(4/r*(F((r+1)/2)-F((r-1)/2))-log(r)+3), r=exp(1/n), F(z)=z^2 log(z)/2-3z^2/4, F(0)=0.',axis_closed=axes,direction_energy=directions_data,product_compression_checks=products)
    Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('PASS',result['counts'],'runtime seconds',time.monotonic()-start)

if __name__=='__main__':main()
