# R375 independent audit — FINAL PASS

Status: FINAL PASS for the bounded claims and final bytes bound below. Owner scope: only this audit file; no repository/author edits. The initial independent screen preceded author-proof reading; author proofs, final integration and numerical evidence are now reviewed. No general root closure, uniform quantitative improvement or full historical reduction audit is certified.

## Exact row problem and atoms
Freeze actual R374 full-f fields and its aggregated kernel0<=K_v(y,z)<=L_v(y)<=B. For a fixed(v,y) write C(z)=L-K(z) in[0,L], U=U_v and finite t>=1. Among probability row measures R(dz)=w(z)U(dz) with0<=w<=t, the exact minimum is

V_t(v,y)=integral_0^L [1-t U{C<=s}]_+ ds
=t integral_0^(1/t) Q_C(r)dr.

Here Q is the increasing quantile, with the usual atom randomization/fractional fill. Define c*=inf{s:U(C<=s)>=1/t}, F_< =U(C<c*),a=U(C=c*). A minimizing density is t on C<c*, gamma=(1-tF_<)/a on the tie when a>0, and0 above. If a=0 take gamma0; then tF_<=1. In every case0<=gamma<=t and the total row mass is1. Zero-cost ties and atoms at L are treated by the same rule, not by taking a fraction of a physical receiver atom. Inclusive versus strict CDF at finitely/more generally countably many atoms does not alter the ds integral; the cutoff tie must nevertheless be filled explicitly in the plan. For L=0 the value is0. For t=1 the only row density is1 U-a.e and this reduces to E_U(L-K), not a free nonproduct coupling.

The formula follows either by exact nearest-low-cost fill or layer cake: each row's probability of C>s is at least(1-tU{C<=s})_+, and the cutoff plan attains all these tails except irrelevant boundary conventions. It is not an unconstrained source/target transport optimum.

## Joint measurability and actual admissible class
For measurable bounded C(v,y,z), its conditional CDF is jointly measurable in(v,y,s). Define c* by rational-level tests in[0,B]; source-dependent L causes no difficulty. The mass strictly below and exactly at c* are measurable kernel integrals, making the tie-density plan jointly measurable without postulating a measurable optimizer. With P_v=mu_v^+/d_v, integrate the row measures to obtain tau=d_v P_v(dy)R_(v,y)(dz). The source marginal is exactly mu_v^+ and the target is <=t d_v U_v. d_v=0 has plan/contribution0. It is one plan per ACTUAL v based on the already aggregated all-u K, not a different transport for each large u; original omega/J/past/clock remain at source y and all masses stay from full f.

The broader target-cap class constrains only the integrated target<=t dU and does NOT impose every conditional row<=tU. It contains this row class. Therefore V_row is a feasible UPPER bound for the broader minimum, never its general lower certificate. At t=1 this distinction is immediate: the row class has only the product plan, while the broader cap1 class permits nonproduct plans with exactly the old uniform target and can strictly improve. Any final proof/numeric interpretation must preserve that direction.

## Sharp floor-plus-good envelope and complete price
At each actual pair p=U_v(Q_u), d=d_v, floor a<=min(p,1-d). Any feasible plan in this row class has total target<=t dU and source mass d, so good<=min(d,t d p). The exact maximum allowed by these scalar constraints is

E_t(p)=p+(1-p)min(1,t p)
      =min(1,(t+1)p-t p^2).

For p<=1/t the maximizing d is1-p and the value is(t+1)p-tp^2; for p>=1/t it is1, also attained by that d. Thus E_t<= (t+1)p. Endpoints p=0,1 are covered; no source mass is charged on a Lebesgue-null overlap for L1 f. This is sharp as a scalar/single-pair unmarked bound, not a realization of all original matched constraints simultaneously.

R370's actual center template consequently prices floor plus the row plan's captured-good traffic by(t+1)Gamma_n|E|/h*, converted to epsilon0(t+1)Gamma_nXq/(1+sqrt(n)). The preferred hard-slot coefficient, IF this plan is used from the original positive G, is

epsilon0[2+(Cplus_n+(t+1)Gamma_n)/(1+sqrt(n))].

It REPLACES the old2Gamma or3Gamma template/gain choice, not adds another fee. Taking L_n^(t)=2+(72+(t+1)Gamma_n)/(1+sqrt(n)),epsilon0=eta/L_n^(t) must synchronize h* and C338 as before. The original entrance2,outerLambda,8lambda H W and2d_eff A_clockWnu/H remain. The exact integrated E_t(p) template may be kept instead, but its polynomial saving is not an extra old-square credit. At t=1 this recovers R371's product/joint split; at t=2 the R374 row tilt is an admissible conditional-density plan, so the new row optimum has no larger residual at those SAME fields and same3Gamma price. It still need not reach the broader cap2 optimum. Cross-t/epsilon comparisons must retain entire changed fees and gates.

## Missing genuine geometric parameter, rather than strictness-as-rate
R374 real-cube continuity at the source implies essinf_(U_v)(L-K)=0 on almost every positive source row. Hence for every delta>0 and L>0 the actual target mass

b_delta(v,y)=U_v{L-K<=delta L}

is positive. No uniform positive lower bound or source-weighted distribution estimate for it has been proved. For t>=1, filling up to t b_delta low-cost mass and putting the rest elsewhere yields the rigorous bound

V_t<=delta L+(1-delta)L(1-t b_delta)_+.

Thus a sufficient quantitative condition for a small residual is b_delta>=1/t on enough source-weighted rows, or a budget for the weighted deficit integral of L(1-t b_delta)_+. In particular a uniform bound b_delta>=b0 with modest1/b0 and t>=1/b0 would give integrated residual<=delta integral mu_v^+ L<=delta Xq on the frozen field, at its actual(t+1)Gamma price. This is a CONDITIONAL interface, not an established hypothesis.

A concrete sufficient geometric version requires most of the actual weighted capturing-u mass to have y a common positive distance from its cube boundaries, AND a certified proportion of Qv in the corresponding target neighborhood. Positive interior distance exists rowwise by the existing DCT argument but may have no certified input/dimension-uniform volume. Arbitrary f can charge the unquantified bad rows. No source independence, density ceiling or coordinate-volume-to-source-mass substitution is permitted. As t tends to infinity for a FIXED field the quantile value decreases to0 by this qualitative support fact and dominated convergence; its template price grows with t and the needed t is uncontrolled, so this gives no dimension-uniform root budget or bounded-cost iteration.

## Actual local arithmetic evidence
A standard-library Fraction exercise actually passed252 grouped scalar checks:216 finite atomic-row/cap configurations matched exact greedy tie fill to the layer-cake formula, and36(t,p) configurations checked the sharp envelope against all nine d values plus equality at d=1-p. It included zero target masses, atoms at0/L and t=1,3/2,2,4. These are finite scalar data, not original native hard-field evidence; they are separate from author/parent totals. No author proof was read before this independent screen; completed author review follows.

## Capacity author review
After the independent screens, read /tmp/r375_capacity.md in full, including its complete embedded code. PASS for its stated ROW-class result. The explicit cutoff a_t,strict-below mass and fractional tie density give a probability row in[0,t],including atoms0/L,e=0,t=1 and L=0. Joint measurability follows from rational-level quantile tests and parameterized measurable kernel integrals; no measurable optimizer is assumed. Its exact tail formula and source-preserving common plan agree with the independent screen. The wider aggregate target-cap optimum is never identified with the row value.

The sharp scalar envelope E_t and replacement(t+1)Gamma ledger are correct, with full original fields,source y marks and physical clock kept. The exact capacity difference identity(10) follows directly from the two positive-part tails. The actual template difference(11) is nonnegative and bounded by(t-s)Gamma|E|/h; comparing total gain against total additional template price is a valid SAME-field sufficient criterion, not an automatic net gain after retuning parameters.

The extra local normalization also passes. With M=max(r,L-r),0<=K<=L gives|K-r|<=M<=L<=B. M=0 implies L=K=0 on that row; select density1 and credit0. For M>0,the affine row1+(K-r)/M lies in[0,2] and gains V/M. The bound V<=r(L-r) makes V/M<=min(r,L-r),so no inverse-M integrability issue occurs. Orthogonality and the previous B-credit give exact additional E=integral dP V(1/M-1/B)>=0. If V>0,0<r<L so M<L<=B and this extra credit is strictly positive. Under the already-proved actual-cube R374 nullspace, Gjoint>0 indeed forces positive integrated V and hence a STRICT same-price improvement at t=2 over the old affine-B receipt. No dimension/input-uniform rate or root budget follows. This comparison is at the same h and masks; the general-cap optimum may still be lower.

The4542 exact tests are finite atomic box-simplex/threshold and scalar-envelope diagnostics,with117 atomic rows and108 strict affine cases. They are not actual native highpast geometry and do not replace its continuity proof. The final saved version corrects an earlier harness list/tuple issue; the parent reports the corrected standalone block actually rerun successfully. No review-driven formula correction found.

## Frozen numeric subblock and ledger review
Read /tmp/r375_numeric.md,.py,_input.json,_output.json,_result.json and /tmp/r375_lp.m, together with the current ledger. PASS within their finite scope; final integration and byte binding are completed below. The source and receiver data are the frozen R374 all-matching sources,NOT the old relaxed shell-price lower sources. Current code independently rebuilds all full J,global strict past,clock interval weights and b atom,then all-u L/K before selecting one plan per v. Recovered source/W,omega and per-v cost matrices are explicitly compared to saved data. q=1 makes the code's m_u factors equal R_u^n as required. It does not use artificial source marks or private per-u couplings.

Old t1/t2 primal/dual certificates are rechecked and labeled inherited,not counted as new LP calls. For t1,target upper margins plus exact equal source/target totals imply the original column equalities,so unrestricted old column dual prices are legitimate. For t2/4/8,column dual prices must be nonpositive. The new four LPs are only the two nonzero-cost 2D v at t4,t8. Exact support/margin reconstruction,source equalities,ALL target caps,nonnegative plans and every dual cell-pair inequality are checked. Negative column-price/slack0 conditions and exact primal/dual equality have the correct minimization orientation; a float support/saturation choice cannot be accepted without the subsequent exact feasibility/gap checks. The four supplied primal values0 match valid lower certificates0. Existing1D cap2 zero plans remain feasible at4/8 and nonnegative costs prove optimum0 without fabricated new calls.

The rowwise greedy module fills exact cell costs with capacity t*rowmass*U. Its threshold theta and beta=min(cost-theta,0) give the correct lower dual rowmass*theta+sum caps*beta,attained by its feasible fractional tie fill. Source rows are positive by the positive-surplus cell construction,so theta is defined even for zero-cost rows. All500 row/cap problems and168 per-v/cap sums are certified; row values are correctly >=the broader shared-cap optima. Thus positive rowcap4 cost with zero sharedcap4 cost is not a solver artifact or a general lower bound for the shared class. Actual floor+good in the numeric tables is G-bad,not the analytic(t+1)Gamma fee.

The code/result record1952 exact grouped checks (278 transport/interface plus1674 rowcap modules),with four new MATLAB LPs. Reused old optimizer data is not new execution. Receiver integration remains finite QUADRATURE and lowered diagnostic gates,although source and transported measures are actual positive-volume L1 cell integrals. The2D sharedcap4/8 zero optimum and rowcap4 positive fraction9515/30144 do not certify a general capacity4 theorem,native high-dimensional gates or a dimension exponent. Input provenance and standalone paths are explicit. No full pipeline was duplicated by this reviewer.

The ledger(t+1)Gamma coefficient,L_n,t allocation,h/C338 synchronization,unchanged entrance2/outerLambda and same-field t2 comparison agree with the proofs. At t>2,the displayed sufficient cost-difference test must be applied to complete prices; changing h invalidates an isolated same-row residual comparison. Current independent unpaid slots are retained. Final geometry and main/readme review are completed below.

## Additional independent screen: common near-box clipping and refill
Before reading the forthcoming geometry proof, the proposed plan passes as a genuine AGGREGATE-cap construction. For each(v,y) take a jointly measurable positive-U_v-volume box B_y inside Qv with cost C(y,z)<=s_y on B_y and0<=C<=L_y globally. Let rho0=1_B/U(B), H(z)=E_P rho0(y,z), and finite t>=1. Then H is nonnegative, integral_U H=1, and finite U-a.e. Define a(z)=min(1,t/H(z)),with a=1 at H=0 and any harmless convention on its U-null infinite set. Row lost mass b_y=1-E_U(rho0 a) lies in[0,1]. Positive Tonelli gives

delta=E_P b_y=1-E_U min(H,t)=E_U(H-t)+ in[0,1].

The filled-back row rho=rho0 a+b_y is nonnegative with row mass1 and target density

E_P rho=min(H,t)+delta<=t+delta<=t+1.

Its exact source marginal is unchanged and its cost is bounded by E_P[s_y(1-b_y)+L_y b_y]. The lost mass is filled with the UNIFORM row, not another unbudgeted concentrated target. All weights remain at the original source y. Null/zero congestion conventions do not change any joint mass because the original rho0 kernel integrates to1.

At t=1 this supplies a target-cap2 common plan and hence the SAME3Gamma template price as R374/R375 rowcap2. It need not itself satisfy conditional row density<=2U, so it can exploit the larger joint capacity class. One may choose the better COMPLETE v-plan against the row-optimal candidate using a finite measurable v tie rule. Switching candidates separately by y does NOT automatically retain the aggregate target cap and is not licensed by this statement. No uniform bound for delta or its actual source-weighted L loss follows from the construction; that is the explicit missing congestion budget, not a free price saving.

Reviewer-local Fraction arithmetic actually checked147 finite box/cap cases for row mass, exact delta and min(H,t)+delta target identity. These are scalar arrays,not actual geometry or congestion estimates. Combined reviewer count is399 grouped scalar checks,not included in author/parent totals. Final geometry proof and final-byte review follow.


## Final actual-geometry review and explicit shrinking-box selection

Read final geometry in full, including its embedded test, and rechecked the added §5(16) against the final main. PASS. The weighted essential lower-face suprema and upper-face infima produce the exact zero-loss box. The finite-coordinate/rational-level argument removes ONE receiver-null exceptional set, so the proof does not exchange an uncountable collection of pointwise null sets. Parameterized essential endpoints and their box volumes are measurable. The omission-box inequalities, anchored [y,z] identity and orthant downward closure retain the actual receiver measure. A positive source row need not have a positive-volume common zero-loss box. The finite chosen-box Hall inequalities are necessary conditions for that chosen relation; no infinite Hall sufficiency or free availability of selector cubes is assumed. The actual external-source resource lower bound does not remove its explicitly retained aggregate multiplicity.

The shared-box plan (13) preserves every source row exactly. Its target is exactly min(j,t)+delta and is at most t+1. The tight refill cost is beta(y)(L-r), not beta(y)L. At t=1 this is a feasible aggregate cap-2 plan, with the same 3Gamma price, even though individual rows can exceed the row-cap class. Finite measurable choice of an ENTIRE plan per v is legitimate; arbitrary per-source-row choice is not. General-t shared-box plans require their separate (t+2)Gamma allocation, not the t=1 ledger appended to another estimate.

The added concrete family also passes. Fix xi in(0,1),g=L-r. For g>0 the clipped shrinking boxes Q_k=Q_v intersect (y+[-2^-k R_v,2^-k R_v]^n) have positive U_v volume for P_v-almost every y. The original actual-cube boundary Fubini/DCT statement supplies a common f-null exceptional source set, independently of v, outside which theta_(v,y)-almost every capturing cube contains y as an interior point. Therefore the omitted receiver weight e(Q_k) decreases to0. Its joint measurability follows from finite box endpoint containment and measurable kernel integration; the first integer k satisfying e<=xi*g is a measurable finite selection almost everywhere. Uniform fallback on the joint-source-null exceptional set is harmless. When g=0,nonnegative C=L-K has zero U mean, so uniform refill already has zero cost; choosing Q_v with s=0 is lawful without falsely asserting all receiver cubes contain Q_v.

Using this explicit choice in the tight refill inequality gives exactly

R_box <= xi G_joint +(1-xi) D_xi,
D_xi=integral dv d_v E_P[beta(y)(L-r)], 0<=D_xi<=G_joint.

This supplies an actual measurable feasible cap-2 plan for every fixed field. It does NOT bound D_xi, selected k, box volume or congestion by the desired root budget. No optimizer existence, common positive margin, source density cap or uniform contraction was introduced.

## Final integration, evidence and limitations

Final main, ledger and readme are consistent with the proofs. Main explicitly defines the M=0 credit summand as0. The exact row-class envelope E_t, replacement (t+1)Gamma, synchronized epsilon0/h/C338, original entrance factor2 and outer Lambda are correct. At t=2 row-optimal, local-M tilt and shared-box candidates can be compared at identical full fields and 3Gamma price. Retuning t or h requires comparison of complete bounds; no isolated residual comparison across different gates is licensed. The geometric shared-box alternative is retained with tight refill cost and whole-v selection. Neither strict same-price credit nor finite cap4 zero optima are described as a general root payment.

The general residual R_t (or smaller certified aggregate-cap plan cost), weighted source congestion, original hard entrance/soft and crossing interfaces, contract-external scales/threshold complements, historical initial/deletion/future-source time atoms, source/physical-scale aggregation, H optimization, outer integration and truncation/limit obligations remain unpaid as listed. Physical b atoms have not been confused with historical time atoms. This audit checks this round and the necessary frozen interfaces, not every historic coefficient or the full original reduction.

Execution records are kept separate: parent actually reran capacity4542 exact finite assertions; numeric1952 grouped exact checks with FOUR new MATLAB LPs (old t1/t2 optimizer evidence reused and reverified); geometry14400 Fraction assertions; shared clip/refill2547 grouped Fraction cases checking BOTH tight and coarse cost bounds. Finite receiver quadrature and actual positive-volume source-cell measures do not constitute original high-dimensional native-gate evidence. Reviewer-local399 grouped scalar Fraction checks are separate, not added to parent counts. This final pass did not duplicate the full pipeline. The standalone capacity/geometry scripts were checked byte-for-byte against their unique embedded Python blocks after whitespace stripping; both match. No numerical count is used as a substitute for the analytic proof.

## Final SHA256 bindings

The following hashes bind the bytes reviewed at finalization. Any mathematical modification requires re-audit; this audit does not bind later generated TeX/PDF layout.

```text
69c16a20ff8fb214cfedcd54307ae145ff0ffe859d581bf80ba544642b40773f  /tmp/r375_main.md
930aea90f1d8a991090a3d3a4d5c93b8f999e389e8f7d1ca9c2071995199044c  /tmp/r375_ledger.md
2982a7222329b86614603b00e1f5664da45c61f60ddb9c353b4b8f0abed84248  /tmp/r375_readme.md
3c432638efddd308e7f433ac079ebd539e587e7a899994aad8eb83ebd81df8c5  /tmp/r375_capacity.md
b703ec31eee5018d417b115ec7642b9768c91f72472077a0c23460ae27431502  /tmp/r375_geometry.md
4118cf24c715c3d8428c0dcc3f92317d5523baee34bf6de4db6b0ef5867191d3  /tmp/r375_numeric.md
dce2983b8a3818043e63141d4ca506dee79b5ad1d31a2f467b92774e88fc30c4  /tmp/r375_capacity_check.py
ce2c0177d8ce3ea1309f4847879e36d34d49bb53d3adb1655b0c2753ce9b53f8  /tmp/r375_geometry_check.py
1ae9d1b8049a087436bdda17abacc4ca2cd07d6401ec6c6d0f9a62536abda9a2  /tmp/r375_shared_check.py
e1b5d67b645f883dc5721beae0aa747f613959a68cecd78a456d1624fd176c26  /tmp/r375_numeric.py
0a9561559a99ac29702fdbf8c504fc8dd8904a5941387303a676d364633397d7  /tmp/r375_lp.m
a389ed36d0ba113e1f0a146e824d9fab5dadfddfcc11df6191c6eba06eab6644  /tmp/r375_numeric_input.json
51afc1228df85d0930758fdb0ea969539097cbffd99550cc8d1cfdbc4d82421c  /tmp/r375_numeric_output.json
36817ecd7c06b902735ae58429e463090e43660fca82157a75155088fd0d43cc  /tmp/r375_numeric_result.json
384a4ae6f3a1c6611b3ddeb81cd7a4a6c4b5a9b24b0f0ce48d3a0bfd63b2406d  /tmp/r374_geometry.md
f23edd4d1f99dd6eafd8e029c4758484d57dbc5de228dfff21c04a20b6777231  /tmp/r374_ledger.md
70e45352dee59ca6bb2989be5fef188ca074c481c372e52858856ad5a35b0e64  /tmp/r374_main.md
86cd6f7bce61dc82c75b8f7ff65ee1d14fa285f159d19f859eb30418f48c2e82  /tmp/r374_audit.md
1d1cc4c717b8b30b479dde15ea40b03f7fff1bd1fc3e034f38d94539f51bc0c4  /tmp/r374_input.json
18a6c0483c26838b04ce79a35a2e56aeb7405d1fb68659ce6b5b8d0e2778ba80  /tmp/r374_result.json
fac02a43e18ed5dc3d5be7ef67a8ac9e34cbd4dd1e69912d6e29dffda597d81a  /tmp/r370_geometry.md
```

Final decision: PASS for the stated constructed plans, exact row optimality, finite certificates, final accounting and explicitly conditional geometry. No unresolved correction within this bounded audit. The full arbitrary-input root-budget problem remains open in the retained residual and other listed slots.
