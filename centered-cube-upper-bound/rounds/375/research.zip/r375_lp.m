% Only the four genuinely new 2D common-plan LPs; old capacities are reused.
r375_base=fileparts(mfilename('fullpath'));r375_data=jsondecode(fileread(fullfile(r375_base,'r375_numeric_input.json')));
r375_options=optimoptions('linprog','Display','none');r375_results={};r375_count=0;
for r375_i=1:numel(r375_data.cases)
 r375_case=r375_data.cases(r375_i);if r375_case.n~=2,continue;end
 for r375_j=1:numel(r375_case.plans)
  r375_p=r375_case.plans(r375_j);if ~r375_p.nonzero_cost,continue;end
  r375_cost=double(r375_p.cost_numeric);r375_rows=double(r375_p.row_numeric(:));r375_cols=double(r375_p.col_numeric(:));r375_nr=numel(r375_rows);r375_nc=numel(r375_cols);r375_f=reshape(r375_cost',[],1);
  r375_Ar=kron(speye(r375_nr),ones(1,r375_nc));r375_Ac=kron(ones(1,r375_nr),speye(r375_nc));
  for r375_cap=[4,8]
   [r375_x,r375_val,r375_flag,r375_info,r375_mult]=linprog(r375_f,r375_Ac,r375_cap*r375_cols,r375_Ar,r375_rows,zeros(numel(r375_f),1),[],r375_options);
   r375_res=struct('name',r375_case.name,'v',r375_p.v,'capacity',r375_cap,'plan',r375_x,'exitflag',r375_flag,'value',r375_val);
   r375_count=r375_count+1;r375_results{r375_count}=r375_res;
  end
 end
end
r375_fid=fopen(fullfile(r375_base,'r375_numeric_output.json'),'w');fwrite(r375_fid,jsonencode(struct('plans',[r375_results{:}])),'char');fclose(r375_fid);
fprintf('R375 completed %d new 2D common transport LPs.\n',r375_count);
