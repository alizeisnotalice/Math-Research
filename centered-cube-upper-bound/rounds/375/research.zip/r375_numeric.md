# R375 — target capacity 1, 2, 4, 8 on the frozen R374 fields

## Result that changes the next decision

Capacity **4** already removes the remaining 2D bad cost in this fixed source/marginal class. Capacity 8 has no further effect. The two 1D cases were already at zero bad cost at capacity 2. Thus the positive R374 capacity-2 residual is not persistent under this bounded further enlargement. This supports investigating bounded target-capacity mechanisms rather than treating the old fixed-target optimum as an unavoidable source cost.

This is a statement about these frozen finite-receiver examples, not a general constant-capacity theorem, native hard-gate realization, or dimension exponent.

| Frozen field | Capacity t | Optimal bad / original G | Actual (floor + good) / G |
|---|---:|---:|---:|
| Equal 15 intervals | 1 | 1/4 | 3/4 |
| Equal 15 intervals | 2, 4, 8 | 0 | 1 |
| Weighted 15 intervals | 1 | 1/4 | 3/4 |
| Weighted 15 intervals | 2, 4, 8 | 0 | 1 |
| Twelve 2D cubes | 1 | 39121/60288 | 21167/60288 |
| Twelve 2D cubes | 2 | 661/1884 | 1223/1884 |
| Twelve 2D cubes | 4, 8 | 0 | 1 |

The table uses **actual sample floor+transported-good integrals**, not tΓ or any other coarse template fee. Larger feasible target capacity changes the split of the same original diagnostic G; it does not change G, f, q, captures, ω or the original physical clock.

## Frozen sources and exact common objective

The three inputs are the same actual compact piecewise-constant L1 sources and receiver quadrature fields as R374: two 1D models with 15 receiver intervals and 16 full source cells, followed by a 2D model with 12 true cubes and 208 full source cells. The actual source masses are 4,4,33/4; all receiver matching remains m_u=R_u^n, q_u=1. Receiver weights are finite positive quadrature, not dx. The complete source partition includes the regions where f=0.

The full original finite diagnostic marks are rederived from the frozen sources and fields:

    ω_u(y)=h R_u^n Σ_{r≥R_u}ell_r
      1{J_y(r)≥H}1{Z_y(m_u/κ−)>h}/J_y(r).

The code retains strict past, physical prefix clock and terminal atom, diagnostic κ=6/5, H=h=1/16 in 1D and 1/64 in 2D. It verifies equality to every saved ω. It then rederives L_v and K_v from the sum over **all u**, with both original u and v weights retained, and checks every saved per-v cost L_v−K_v. No private coupling is chosen for different u.

For each v, the source marginal is exactly μ_v^+=(f−1)_+c_v dy/m_v. The target cap is t d_vU_v where d_v=μ_v^+(Q_v), U_v is uniform on the actual Q_v. The capacity LP fixes source rows and permits columns≤t d_vU_v. At t=1, total mass equality forces the target to be exactly d_vU_v.

Every plan on positive-volume source/target cell products defines an absolutely continuous coupling. Hence the source/target integrals and all means are exact; only receiver integration is quadrature. No source density or receiver mass is refitted.

## Three bounded stages and actual execution

1. **Inherited capacities:** R374's exact t=1 and t=2 plans/potentials are copied with provenance and rechecked. Their LPs are not rerun. Reused evidence is identified as such, not counted as new optimization discovery.
2. **Shared-source/full-mark interface:** matching, actual total source mass, every ω/J/past/clock, every marginal and the single common all-u objective are independently reconstructed in the current script.
3. **Expanded capacities:** only the two nonzero-cost 2D v require new work. MATLAB actually runs their t=4 and t=8 LPs: **four new LPs total**. All four give feasible rational plans with exact zero objective. Exact dual potentials certify the matching zero lower bound. In 1D, the already-zero t=2 plan is feasible for t=4,8, and cost nonnegativity gives the exact zero lower bound without further solver calls.

The four new optimal bad costs are all zero. Both marginals/source constraints and every target cap are checked using Fraction, as are pointwise dual inequalities and primal/dual equality. Rational margin corrections are zero in every new LP. The final script passed **1,952 exact grouped assertions**: 278 transport/interface checks and 1,674 additional row-cap threshold/feasibility/comparison checks, including revalidation of inherited certificates. This is not 1,952 new optimizations. No floating solver flag or display approximation is counted as proof. A fresh prepare→MATLAB-four-LP→verify rerun passed before the row-cap addition; the final added exact row-cap module was then rerun in a fresh Python process without additional LP calls.

The actual template accounts are:

- Equal 1D: G=41/4224; floor=41/8448. At t=1 good=41/16896 and bad=41/16896; at t≥2 good=41/8448 and bad=0.
- Weighted 1D: G=143287/11128320; floor=143287/22256640. At t=1 good=143287/44513280 and bad=143287/44513280; at t≥2 good=143287/22256640 and bad=0.
- 2D: G=1099/310080; floor=3731/19845120. At t=1 floor+good=148169/119070720; at t=2 it is 8561/3720960; at t=4,8 it is exactly G, with good=13321/3969024 and zero bad.

All cases verify G=floor+good+bad at every capacity. This exact accounting is the requested comparison; a hypothetical tΓ bound is neither substituted nor certified by this experiment.

## Stronger per-row capacity: independently certified comparison

A per-source-row restriction T_i(dz)≤t μ_i^+ U_v(dz) implies the shared target cap after summing i, but the converse need not hold. It disallows capacity sharing between different original source cells. No per-u choice is introduced: this row constraint is on the old-source y coordinate of the same already aggregated all-u cost.

For each row i and capacity t, the code fills target columns in increasing exact cost (target index breaks ties), with cap t μ_i^+ U_j and total mass μ_i^+. Fractional filling at the threshold is allowed. If θ_i is the last filled cost, the exact weak-dual potentials are

    α_i=θ_i,  β_ij=min(cost_ij−θ_i,0)≤0,
    lower_i=μ_i^+ θ_i + Σ_j t μ_i^+ U_j β_ij.

The plan satisfies every row cap and source equality, and plan cost equals this dual value exactly. This is a finite fractional-knapsack optimum certificate, not a floating ranking heuristic. All 500 row/capacity problems (including zero-cost rows) pass exact feasibility, pointwise dual and zero-gap checks. Their 168 per-v/capacity sums also satisfy the implied shared target cap. These require no new MATLAB LP.

The independently reproduced row-cap optimal bad fractions are:

| Field | t=1 | t=2 | t=4 | t=8 |
|---|---:|---:|---:|---:|
| Equal 1D | 1129/2952 | 391/1476 | 11/369 | 0 |
| Weighted 1D | 1310023/3438888 | 450301/1719444 | 10220/429861 | 0 |
| 2D | 47575/60288 | 9515/15072 | 9515/30144 | 0 |

At t=1 row-cap transport is exactly the product coupling, as verified. At t=2 shared-cap optimal bad is already zero in 1D while row-cap bad is positive. At t=4 shared-cap bad is zero in 2D while row-cap bad still equals 9515/30144 of G. Thus row-wise domination is materially stronger than the joint target contract and can hide the gain from sharing target capacity across sources. The displayed row values independently match the proposed comparison values without using those values as test inputs.

The saved summary gives actual row-cap floor+good=G−row_bad as well as actual shared-cap floor+good, with the same frozen floor. `rowwise_exact_threshold_certificates` saves every row threshold and exact row value, and the deterministic tie/filling rule reconstructs the complete feasible plans from the input. No separate row optimizer is invoked. This is the principal additional decision evidence: do not silently replace a joint target cap by pointwise row domination when designing the next coupling.

## Portable reproduction and scope

Minimum standalone materials are `r375_numeric.py`, `r375_lp.m`, and `r375_numeric_input.json`. The input snapshot contains frozen fields plus the inherited exact certificates. Run the MATLAB script in the same directory, then:

    /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r375_numeric.py

`r375_numeric_output.json` preserves four actual MATLAB candidates; `r375_numeric_result.json` preserves the four new rational plans/duals, row-wise exact threshold certificates, and all exact comparison accounts. Optional `prepare` mode regenerates the snapshot from frozen `r374_input.json` and `r374_result.json`, with their SHA256 recorded. Verify has no dependency on old temporary scripts or files beyond the standalone snapshot. MATLAB does not clear the global workspace or change global paths.

These are genuine positive-volume L1 source/coupling calculations on complete cells, with original matching and full frozen diagnostic marks. They are not native high-dimensional hard traffic, actual Lebesgue receiver fields, a proof of general capacity-four sufficiency, or evidence of a dimension rate. Within the tested fields, capacity growth is effective and saturates by four; controlling its general template price remains a separate analytic question.
