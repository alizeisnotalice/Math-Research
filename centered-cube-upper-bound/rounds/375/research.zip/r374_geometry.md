# R374 — Full-row common transport, mean-load gain, and the actual-cube nullspace

## 1. Exact general receipt

Keep the same full f, actual E, m/q, J, strict past, masks, physical clock and terminal atom. In the R373 notation,
\[
 \mu_v^+(dy)=\frac{(f(y)-q_v)_+c_v(y)}{m_v}dy,\quad
 d_v=\mu_v^+(Q_v),\quad P_v=\mu_v^+/d_v,\quad
 U_v(dz)=c_v(z)dz/R_v^n.
\]
Use P_v=U_v when d_v=0. All coupling and gain contributions carrying d_v are zero for that v; K_v, L_v and B need not vanish. Let
\[
 K_v(y,z)=\frac1h\int_E\frac{du}{R_u^n}A_{uv}\omega_u(y)c_u(y)c_u(z),
 \qquad
 L_v(y)=\frac1h\int_E\frac{du}{R_u^n}A_{uv}\omega_u(y)c_u(y),
\]
with exactly the original A_uv=S(u,v)(1-m_v/m_u) and original ω_u. Put
\[
 B=\frac{1+n\log(b/a)}h,\quad
 r_v(y)=E_{U_v}K_v(y,z),\quad
 c_v^K(z)=E_{P_v}K_v(y,z),\quad
 \bar k_v=E_{P_vU_v}K_v.
\]
The actual-center envelope gives 0≤K_v≤L_v≤B. No source-density bound is used.

The new common surplus coupling is
\[
 \boxed{\widehat\tau_v(dy,dz)=
 d_v\left[1+\frac{K_v(y,z)-r_v(y)}B\right]P_v(dy)U_v(dz).} \tag{1}
\]
It is constructed from the fully aggregated receiver kernel before choosing a coupling. Thus the same coupling serves every actual large receiver u.

Its source marginal is exactly μ_v^+. Its target marginal is
\[
 \widehat\sigma_v(dz)=
 d_v\left[1+\frac{c_v^K(z)-\bar k_v}B\right]U_v(dz),
 \qquad 0\le\widehat\sigma_v\le2d_vU_v\le2U_v. \tag{2}
\]
Indeed −B≤K_v−r_v≤B, giving nonnegativity; integrating in z gives one in each source row. All functions are measurable integrals of the actual bounded kernels, so no measurable optimizer or additional receiver is assumed.

Define
\[
 \widehat\Delta_v=\frac{d_v}{B}
 E_{P_v}\operatorname{Var}_{U_v}(K_v(y,\cdot)),
 \qquad \widehat\Delta=\int_E\widehat\Delta_v\,dv. \tag{3}
\]
Then the exact bad-source remainder of (1) is
\[
 \boxed{\widehat G=G_{\rm joint}-\widehat\Delta\ge0.} \tag{4}
\]
To prove it, the source marginal keeps ∫L_v unchanged, while the captured reward increases by
\[
 \frac{d_v}B E[K_v(K_v-r_v)]
 =\frac{d_v}B(EK_v^2-Er_v^2).
\]
The bad integrand L_v−K_v is nonnegative. This proves both (3) and the lower bound in (4), without subtracting an unearned square.

## 2. The gain includes the previously unchanged mean

Let D_v be R373's double-centered kernel. The orthogonal decomposition is
\[
 K_v-r_v=D_v+(c_v^K-\bar k_v).
\]
The cross term vanishes because E_{P_v}D_v(·,z)=0. Hence
\[
 \boxed{\widehat\Delta
 =2\Delta+\mathcal M,\qquad
 \mathcal M=\int_E\frac{d_v}{B}
       \operatorname{Var}_{U_v}(c_v^K)\,dv\ge0.} \tag{5}
\]
This comparison uses the SAME frozen parameters and fields for both gains.

When every relevant ω_uc_u is constant P_v-almost everywhere, the old D_v vanishes. Formula (5) can still be strictly positive through the spatial variation of the aggregate c_v^K(z). Thus (1) acts on the actual mean load that was invariant under fixed-target couplings. It changes the allowed target marginal, rather than tuning the previous double-centered tilt.

The remaining exact object is (4), with every original sourcewise gate retained. The result does not show a dimension-independent fraction of G_joint is removed.

## 3. Joint template price and original ledger

For each pair write its exact marked floor mass as
\[
 a_{uv}=\frac1{m_v}\int_{Q_u\cap Q_v}\min(f,q_v)\omega_u.
\]
Then a_uv≤p_uv and a_uv≤1−d_v, where p_uv=U_v(Q_u). Its new good transport mass satisfies
\[
 g_{uv}=\iint\omega_u(y)c_u(y)c_u(z)\,\widehat\tau_v(dy,dz)
 \le2d_vp_{uv}\le2p_{uv}.
\]
Therefore
\[
 a_{uv}+g_{uv}\le3p_{uv}. \tag{6}
\]
One can retain the stronger bound
a_uv+g_uv≤min(1,3p_uv−2p_uv²), by also using g_uv≤d_v and maximizing over d_v; no separate credit from this refinement is charged here.

The SAME original positive G is now decomposed into floor, new good transport and (4). R370's selector theorem gives
\[
 G_{\rm floor}+G_{\rm good}(\widehat\tau)
 \le\frac3h\int_E\frac{du}{R_u^n}\int_E A_{uv}p_{uv}\,dv
 \le\frac{3\Gamma_n|E|}h
 \le\frac{3\varepsilon_0\Gamma_n}{1+\sqrt n}X_q. \tag{7}
\]
Only the real center Lebesgue integral is estimated by Γ_n.

Consequently a replacement hard-slot ledger is
\[
 \boxed{B_H(f,\nu)\le G_{\rm joint}-\widehat\Delta+
 \varepsilon_0\left[2+\frac{C_n^++3\Gamma_n}{1+\sqrt n}\right]X_q
 +C_{338}W,\qquad \nu\le f.} \tag{8}
\]
Here C_n^+<72 and the exact old source fee is
\[
 C_{338}=\frac{\lambda}{q_-}
 \left\{\frac{2+3\sqrt n+2e^{-\sqrt n}}{\varepsilon_0}+1+\sqrt n\right\}.
\]
For a desired hard-slot coefficient η choose
\[
 \mathcal L_n=2+\frac{72+3\Gamma_n}{1+\sqrt n},\quad
 \varepsilon_0=\eta/\mathcal L_n,\quad
 h=\frac{(1+\sqrt n)\mathcal L_n}{\eta q_-}.
\]
Use this SAME ε0 in C338 and rebuild all h-dependent gates and marks. Then the source fee remains O_η(√(n log(n+2)))W. A comparison with an old run using a different h is not a same-field comparison.

The original entrance terms 8λHW and 2d_eff A_n W_ν/H, its factor 2 on the hard slot, and the outer factor Λ=128/119 remain. Thus the new gain appears as 2Λ widehatΔ there. All other unpaid slots remain unpaid.

Equation (8) REPLACES the R373 template/gain choice. It does not add widehatΔ to a ledger already charged for the previous coupling, and does not reuse the original negative square, recapture fee or T2 refinement. At fixed fields it is valid to retain the better of the complete R373 and R374 right sides; their gains and template prices must not be mixed.

## 4. Actual cube geometry eliminates the new gain's nonzero nullspace

There is a qualitative strengthening specific to the actual capture kernel:
\[
 \boxed{\widehat\Delta=0\quad\Longleftrightarrow\quad G_{\rm joint}=0.} \tag{9}
\]
This does not give a quantitative ratio.

Here is the needed geometric argument. By Fubini, for Lebesgue-almost every source point y, y is on ∂Q_u for a du-null set of receivers u. The relevant receiver weights are integrable, since E has finite measure, R_u≥a and Aω≤1. Fix such a y. Whenever the weight
A_uv ω_u(y)c_u(y)/R_u^n is positive, y is an interior point of Q_u for almost every u. For every sequence z→y, c_u(z)→1 for those u. Dominated convergence gives
\[
 \lim_{z\to y}K_v(y,z)=L_v(y). \tag{10}
\]
This holds for every v for which the displayed kernel is defined, outside harmless joint null sets. Also P_v is absolutely continuous relative to Lebesgue measure and P_v-almost every y is interior to Q_v.

If Var_{U_v}K_v(y,·)=0, that row is a constant k for U_v-almost every z. Since y is interior to Q_v, choose z_j→y outside the exceptional null set. Equation (10) forces k=L_v(y). Therefore
\[
 L_v(y)-E_{U_v}K_v(y,\cdot)=0
\]
on every such zero-variance row. Integrating with d_vP_v and dv proves the forward implication of (9). The reverse implication follows already from 0≤widehatΔ≤G_joint.

This is a strictness statement using the true cube interiors and the L1 source. It would be invalid to infer it for arbitrary unrelated measurable kernels by evaluating a diagonal of product-null measure. The continuity-at-the-source proof above supplies the missing step.

The still-unpaid quantitative issue is that the neighborhood on which K_v(y,z) is close to L_v(y) may have arbitrarily small U_v mass. Full matching and the present argument give no lower bound relating that neighborhood mass, or the row variance, to the full integrated bad load. No thin source layer is bounded by its volume. Hence (9) does not prove contraction by a fixed fraction, repeated-iteration convergence at bounded cost, or the requested final root budget.

## 5. Exact local checks and scope

The embedded Python Fraction code is run locally. It uses actual interval capture matrices on complete positive-length cells, full f-derived small-receiver q_v and surplus, and bounded marks. It verifies both marginals, the target cap, row gain, the decomposition 2Δ+M, bad positivity, the template price, and the discrete actual-capture nullspace. It includes uniform-source/zero-surplus and zero-kernel cases, and an explicit mean-only case D=0 with positive new gain. These are finite source/quadrature diagnostics; the marks do not claim to realize the native high-past hard slot.

~~~python
from fractions import Fraction as F
from itertools import product

xs=[F(2*i+1,16)-F(1,2) for i in range(8)]
U=[F(1,8)]*8
profiles=((4,0,0,0,0,0,0,4),(2,0,2,0,2,0,2,0),
          (0,0,1,3,0,0,1,3),(1,1,1,1,1,1,1,1),
          (4,4,0,0,0,0,0,0))
receivers=((F(-3,4),F(3,2)),(F(3,4),F(3,2)),
           (F(0),F(2)),(F(1,2),F(5,4)))
cap=[[F(int(abs(x-c)<=R/2)) for x in xs] for c,R in receivers]
weight_cases=((F(1),F(1),F(1),F(1)),
              (F(1,3),F(2,5),F(1,7),F(3,4)),
              (F(1),F(1),F(0),F(0)),
              (F(1),F(0),F(0),F(0)))
checks=strict=mean_only=0
for raw in profiles:
 f=list(map(F,raw));q=sum(U[i]*f[i] for i in range(8))
 plus=[U[i]*max(f[i]-q,F(0))/q for i in range(8)]
 dv=sum(plus);P=[x/dv for x in plus] if dv else U[:]
 for weights in weight_cases:
  B=sum(weights)
  for mode in range(4):
   om=[[F(1) if mode==0 else (F(0) if mode==1 else
        F((i+2*k+mode)%5,4)) for i in range(8)] for k in range(4)]
   aa=[[om[k][i]*cap[k][i] for i in range(8)] for k in range(4)]
   K=[[sum(weights[k]*aa[k][i]*cap[k][j] for k in range(4))
       for j in range(8)] for i in range(8)]
   L=[sum(weights[k]*aa[k][i] for k in range(4)) for i in range(8)]
   assert all(0<=K[i][j]<=L[i]<=B for i,j in product(range(8),repeat=2))
   assert all(K[i][i]==L[i] for i in range(8));checks+=1
   row=[sum(U[j]*K[i][j] for j in range(8)) for i in range(8)]
   col=[sum(P[i]*K[i][j] for i in range(8)) for j in range(8)]
   mean=sum(P[i]*row[i] for i in range(8))
   D=[[K[i][j]-row[i]-col[j]+mean for j in range(8)] for i in range(8)]
   T=[[dv*P[i]*U[j]*(1+(K[i][j]-row[i])/B)
       for j in range(8)] for i in range(8)]
   assert all(t>=0 for rr in T for t in rr)
   assert [sum(rr) for rr in T]==plus;checks+=1
   target=[sum(T[i][j] for i in range(8)) for j in range(8)]
   assert target==[dv*U[j]*(1+(col[j]-mean)/B) for j in range(8)]
   assert all(0<=target[j]<=2*dv*U[j] for j in range(8));checks+=1
   energy=sum(P[i]*U[j]*(K[i][j]-row[i])**2
              for i,j in product(range(8),repeat=2))
   gain=dv*energy/B
   delta=dv*sum(P[i]*U[j]*D[i][j]**2
                for i,j in product(range(8),repeat=2))/(2*B)
   mean_gain=dv*sum(U[j]*(col[j]-mean)**2 for j in range(8))/B
   assert gain==2*delta+mean_gain;checks+=1
   reward=sum(T[i][j]*K[i][j] for i,j in product(range(8),repeat=2))
   assert reward==dv*mean+gain;checks+=1
   old=sum(dv*P[i]*U[j]*(L[i]-K[i][j])
           for i,j in product(range(8),repeat=2))
   new=sum(T[i][j]*(L[i]-K[i][j])
           for i,j in product(range(8),repeat=2))
   assert 0<=new==old-gain
   assert (gain==0)==(old==0);checks+=1
   for k in range(4):
    p=sum(U[j]*cap[k][j] for j in range(8))
    floor=sum(U[i]*min(f[i],q)*aa[k][i]/q for i in range(8))
    good=sum(T[i][j]*aa[k][i]*cap[k][j]
             for i,j in product(range(8),repeat=2))
    assert floor+good<=3*p
    assert floor+good<=min(F(1),3*p-2*p*p)
   checks+=1
   strict+=gain>0
   mean_only+=gain>0 and delta==0
assert strict>0 and mean_only>0
print('PASS',checks,'aggregate Fraction checks;',strict,
      'strict gains;',mean_only,'mean-only strict gains')
~~~

Execution record: saved code actually returned: PASS 560 aggregate Fraction checks; 47 strict gains; 4 mean-only strict gains (exit status 0). Inner pointwise assertions are not separately counted.
