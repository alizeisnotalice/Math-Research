from fractions import Fraction as F
from itertools import product
counts={}
for stage,U in [('initial',[F(1,2)]*2),('overlap',[F(1,6),F(1,3),F(1,2)]),('expanded',[F(1,10),F(1,5),F(3,10),F(2,5)])]:
 N=len(U);masks=[tuple(i for i in range(N) if bits>>i&1) for bits in range(1,2**N)];count=0
 for S,T in product(masks,repeat=2):
  for p,t in product([F(1,5),F(1,2),F(4,5)],[F(1),F(3,2),F(2)]):
   P=[p,1-p];sets=[S,T];L=[F(1),F(3,4)];s=[F(1,7),F(1,8)]
   R=[[F(i in A)/sum(U[k] for k in A) for i in range(N)] for A in sets]
   H=[sum(P[j]*R[j][i] for j in range(2)) for i in range(N)]
   a=[min(F(1),t/h) if h else F(1) for h in H]
   b=[1-sum(U[i]*R[j][i]*a[i] for i in range(N)) for j in range(2)]
   delta=sum(P[j]*b[j] for j in range(2))
   new=[[R[j][i]*a[i]+b[j] for i in range(N)] for j in range(2)]
   assert all(0<=x<=1 for x in b)
   assert delta==sum(U[i]*max(F(0),H[i]-t) for i in range(N))
   assert all(sum(U[i]*new[j][i] for i in range(N))==1 for j in range(2))
   assert all(sum(P[j]*new[j][i] for j in range(2))==min(H[i],t)+delta<=t+delta for i in range(N))
   C=[[s[j] if i in sets[j] else L[j] for i in range(N)] for j in range(2)]
   cost=sum(P[j]*U[i]*new[j][i]*C[j][i] for j in range(2) for i in range(N))
   old=[sum(U[i]*C[j][i] for i in range(N)) for j in range(2)]
   assert cost<=sum(P[j]*(s[j]*(1-b[j])+old[j]*b[j]) for j in range(2))
   assert cost<=sum(P[j]*(s[j]*(1-b[j])+L[j]*b[j]) for j in range(2))
   count+=1
 counts[stage]=count
print('PASS shared truncation/refill exact cases',counts,'total',sum(counts.values()))
print('Finite algebra only; no actual hard-field or congestion bound certification.')
