# R375 — Actual common-capture boxes and the outstanding shared-source budget

**Bounded outcome.** This note freezes the exact geometry needed for joint-capacity transport. It proves the essential-intersection box description, measurable weighted omission certificates for near-capture boxes, and the exact orthant structure. It establishes no new root-order payment and does not treat a small per-row capacity as a necessary obstruction to a jointly capped plan. The base fields remain unchanged; optional new plans use the same cap-2 / 3Γ_n ledger with their actual remaining costs.

## 1. The actual row measure and all quantifiers

Fix the frozen input and the R374 notation. For each actual small receiver v and source y define the finite nonnegative receiver measure
\[
 \theta_{v,y}(du)=\frac{A_{uv}\omega_u(y)c_u(y)}{hR_u^n}\,du.
\]
This keeps the original far-mass/outside/not-Bplus mask, original y-dependent J and strict past, full f matching and physical clock. Its mass is L_v(y)≤B, and
\[
 K_v(y,z)=\int c_u(z)\,\theta_{v,y}(du).
\]
No receiver atoms or freely translated cubes are inserted.

Use closed cube representatives. This does not change any source or target integral: for each actual receiver its boundary is Lebesgue null, and positive Fubini applies to the actual du-weighted source/target integrals. Let
\[
 a_i(u)=u_i-R_u/2,\qquad b_i(u)=u_i+R_u/2.
\]
If L_v(y)>0, define
\[
 \ell_i(v,y)=\operatorname*{ess\,sup}_{\theta_{v,y}}a_i(u),\qquad
 r_i(v,y)=\operatorname*{ess\,inf}_{\theta_{v,y}}b_i(u).
\]
These are weighted essential extrema, not extrema over an exceptional individual receiver. They obey
\[
 y_i-b\le\ell_i(v,y)\le y_i\le r_i(v,y)\le y_i+b.
\]
When L=0 set ℓ_i=−∞ and r_i=+∞. Every relevant statement below is for actual v and P_v-almost every y∈Q_v, with the zero-surplus convention from R374.

The endpoints are jointly measurable. For example
\[
 \{\ell_i>t\}=
 \left\{\int1_{\{a_i(u)>t\}}\theta_{v,y}(du)>0\right\}
\]
for rational t; analogous tests handle essential infima and the L=0 convention. This relies on the actual jointly measurable kernel and parameter integration, not a separate-measurability assertion about an abstract capture σ-field.

## 2. Exact zero-loss box

Put
\[
 C_v(y)=Q_v\cap\prod_{i=1}^n[\ell_i(v,y),r_i(v,y)].
\]
Then
\[
 \boxed{\{z\in Q_v:K_v(y,z)=L_v(y)\}=C_v(y).} \tag{1}
\]
With other harmless cube boundary conventions the identity holds up to U_v-null sets.

Indeed L−K is the θ-mass of receivers not containing z. That mass vanishes exactly when every coordinate of z lies above the essential lower-face supremum and below the essential upper-face infimum. For each coordinate, a_i≤ℓ_i and b_i≥r_i hold outside θ-null sets, by the defining essential extrema and countable rational approximation. Removing these finitely many exceptional sets gives ONE θ-full receiver family containing the entire box simultaneously. Conversely a point outside the box violates a coordinate bound on a positive-θ set. Thus no uncountable union of point-dependent null sets, or unproved uncountable-intersection assertion, is used. In particular y belongs to the box. Its exact uniform capacity is
\[
 U_v(C_v(y))=\frac1{R_v^n}
 \prod_i\left[\min(v_i+R_v/2,r_i)-\max(v_i-R_v/2,\ell_i)\right]_+ . \tag{2}
\]
The box can have zero volume. Although almost every active cube contains almost every relevant y in its interior, the essential infimum of these individual interior margins can be zero. R374's continuity-at-y argument does not supply a positive uniform common margin.

## 3. Quantitative near-capture boxes from weighted omissions

Let T_{v,y} be any jointly measurable retained receiver set, with omitted ACTUAL row weight
\[
 e_{v,y}=\theta_{v,y}(E\setminus T_{v,y})\le s_{v,y}.
\]
Form the box C^T_v(y) by replacing θ in §2 by its restriction to T. Then
\[
 \boxed{C^T_v(y)\subset
 \{z\in Q_v:K_v(y,z)\ge L_v(y)-s_{v,y}\}.} \tag{3}
\]
Every retained receiver captures z, so all loss comes from the omitted receiver measure. This is a weighted omission, not a count of receivers or omitted coordinates.

Equivalently, for a measurable axis-parallel box Q_v⊃Q containing y, define
\[
 e_{v,y}(Q)=\int 1_{\{Q\not\subset Q_u\}}\theta_{v,y}(du).
\]
Then
\[
 e_{v,y}(Q)\le s\quad\Longrightarrow\quad
 Q\subset\{K_v(y,\cdot)\ge L_v(y)-s\}. \tag{4}
\]
Thus the source-row near-capture capacity has the rigorous lower bound
\[
 U_v\{K_v(y,\cdot)\ge L_v(y)-s\}
 \ge \sup_{\substack{Q\subset Q_v,\ y\in Q\\e_{v,y}(Q)\le s}}
          |Q|/R_v^n. \tag{5}
\]
Formula (5) is a geometric lower bound, not a claim that this capacity is generally large.

There is an exact simplification for an anchored box Q=[y,z] inside one orthant:
\[
 \boxed{e_{v,y}([y,z])=L_v(y)-K_v(y,z).} \tag{6}
\]
A cube containing y contains [y,z] exactly when it contains z. For a general box containing y the corresponding identity with a single corner is false. The valid finite-corner bounds are
\[
 \max_{z\in{\rm corners}(Q)}(L-K(y,z))
 \le e_{v,y}(Q)
 \le\sum_{z\in{\rm corners}(Q)}(L-K(y,z)). \tag{7}
\]
Different receivers may fail at different corners; their weights cannot be replaced by just one maximal corner loss.

Consequently, within every orthant with vertex y, K_v(y,z) is nonincreasing in each coordinate distance from y. Every high-reward set is an orthant lower set and contains [y,z] whenever it contains z. It need not be globally convex. The essential-intersection box is special to exact zero loss or an explicitly retained receiver family.

## 4. The necessary budget is shared across source rows

For a joint plan with first marginal d_vP_v and target bounded by t d_vU_v, a family of source rows S must fit jointly into the UNION of their allowed target neighborhoods. In particular a zero-loss plan must satisfy the necessary inequalities
\[
 P_v(S)\le t\,U_v\!\left(\bigcup_{y\in S}C_v(y)\right), \tag{8}
\]
whenever the union is measurable; finite source partitions and their finitely many common boxes avoid any measurable-union ambiguity. In general one uses the corresponding measurable transport relation/capacity formulation. This note invokes no infinite-dimensional Hall-attainment theorem.

For a finite measurable source partition S_j with boxes Q_j satisfying (4) for P_v-almost every y∈S_j, the explicit quantities that must be checked are
\[
 \sum_{j\in I}P_v(S_j)
 \quad\hbox{and}\quad
 t\,U_v\!\left(\bigcup_{j\in I}Q_j\right)
 \quad\text{for EVERY subfamily }I. \tag{9}
\]
They are common-source union capacities. Requiring every individual source row to have capacity at least 1/t is stronger and can discard legitimate joint plans. The parent's existing complete-matching finite diagnostics establish that this distinction is material; no additional toy fixture is constructed here.

The matching equations do give a large external source resource for every active far-mass pair:
\[
 I_{uv}=\int f c_uc_v\le m_v,\qquad
 f(Q_u\setminus Q_v)=m_u-I_{uv}
 \ge m_u-m_v>(1-K^{-1})m_u. \tag{10}
\]
They do not make these external resources disjoint for different u, v or source rows. To see the exact accounting, for any fixed row the nonnegative measure
\[
 \mathcal R_{v,y}(dz)=f(z)\int
   \frac{c_u(z)(1-c_v(z))}{m_u-I_{uv}}\,\theta_{v,y}(du)\,dz \tag{11}
\]
has total mass L_v(y). The denominators are strictly positive by the original mass gap. Thus a proposed settlement through large-cube external sources necessarily encounters the aggregate external-source load
\[
 \mathcal H(z)=\int_E dv\int\mu_v^+(dy)
 \int \frac{c_u(z)(1-c_v(z))}{m_u-I_{uv}}\,\theta_{v,y}(du). \tag{12}
\]
The exact total is ∫f(z)H(z)dz=∫dv∫μ_v^+(dy)L_v(y). A useful settlement must bound the actual weighted multiplicity in (12), or a demonstrably smaller assigned subload. Summing the lower bounds (10) as if they were independent sources would be invalid.

No bound is proved here that controls the source mass side of (9) by the target union capacity plus a root-cost external-source bill. Equations (1)–(7) identify the genuine geometry; (9) and (12) identify the missing joint matching budget. They do not close it or rename it as an already paid quantity.

## 5. A feasible shared-box plan, with every truncation and refill cost retained

The geometry also gives a concrete feasible common plan. This is a conditional quantitative receipt, not a bound on its remaining congestion term.

Choose jointly measurable boxes Q_{v,y}⊂Q_v with U_v(Q_{v,y})>0 and losses
\[
 L_v(y)-K_v(y,z)\le s_v(y)\quad
 \text{for }U_v\text{-a.e. }z\in Q_{v,y},
 \qquad 0\le s_v(y)\le L_v(y).
\]
Equations (3) or (4) certify such choices. Where no useful positive-volume box has been selected, the lawful fallback is Q_{v,y}=Q_v and s_v(y)=L_v(y). No optimizer or measurable selection of an uncountable maximizing family is required; any explicitly measurable family suffices.

Set, for fixed t≥1,
\[
 \rho_v^0(y,z)=\frac{1_{Q_{v,y}}(z)}{U_v(Q_{v,y})},
 \quad j_v(z)=E_{P_v}\rho_v^0(y,z),\quad
 a_v(z)=\min\{1,t/j_v(z)\},
\]
using a_v=1 when j_v=0. Since ∫j_v dU_v=1, j_v is finite U_v-almost everywhere. Put
\[
 \beta_v(y)=1-\int\rho_v^0(y,z)a_v(z)U_v(dz),\qquad
 \delta_v^\Box=E_{P_v}\beta_v
              =\int(j_v-t)_+\,dU_v\in[0,1].
\]
The common plan
\[
 \boxed{\tau_v^\Box(dy,dz)=
 d_v[\rho_v^0(y,z)a_v(z)+\beta_v(y)]P_v(dy)U_v(dz)} \tag{13}
\]
has exactly the source marginal μ_v^+. Its target is exactly
\[
 d_v[\min(j_v(z),t)+\delta_v^\Box]U_v(dz)
 \le d_v(t+\delta_v^\Box)U_v(dz)
 \le(t+1)d_vU_v(dz). \tag{14}
\]
All source rows share the same target cutoff a_v. This allows a row's initial density to exceed t wherever the average occupancy j_v does not. It is therefore weaker than imposing a density cap separately on every row.

Let r_v(y)=E_{U_v}K_v(y,·). The exact bad cost of the uniformly refilled part is d_v E_P[β_v(L_v−r_v)], not d_v E_P[β_v L_v]. The complete bound is
\[
 \boxed{\operatorname{Bad}_v(\tau^\Box)
 \le d_v E_{P_v}\!\left[
 s_v(y)(1-\beta_v(y))+
 \beta_v(y)(L_v(y)-r_v(y))\right]
 \le d_v E_{P_v}s_v+d_v B\delta_v^\Box.} \tag{15}
\]
The retained part lies in the certified box and has row mass 1−β_v; the added part is exactly uniform. This proves (15), including the actual original marked product-row bad cost on refill. No lost row mass is discarded.

For t=1 the target bound is at most 2d_vU_v, so the floor plus good transport is paid by precisely the R374 3Γ_n template bound, with the same original parameters and source fee. One may select, per v, the lowest actual bad cost among (13) and any other certified measurable cap-2 candidates, including R374 or the separately certified row-optimal plan. Select the ENTIRE plan for that v, with a fixed finite tie rule. Every candidate has the same source marginal and target≤2d_vU_v, so this selection preserves the cap and cannot worsen the corresponding complete-plan cost. Selecting different candidates separately for each y is not licensed: their target densities could add beyond the cap. No uniform positive improvement is established.

For general t the crude corresponding joint template fee is (t+2)Γ_n, since floor≤p and good≤(t+1)d_v p. That alternative requires its own synchronized ε0/h/source-fee allocation; it is not appended to the t=1 ledger.

The precise additional unpaid quantity is the actual source-weighted right side of (15), or its smaller exact bad integral. In particular the shared congestion δ_v^Box is a defect of this chosen box plan, not automatically the optimal Hall deficit. No estimate here proves that ∫dv d_v E_P s_v plus the true refilling cost has the desired εX_q+root-W bound. Equations (9)–(12) explain the matching information still needed.

### An explicit measurable near-box family for every input

There is also a concrete choice avoiding an unspecified geometric optimizer. Fix 0<ξ<1 and write g_v(y)=L_v(y)−r_v(y)≥0. On g>0, let
\[
 Q_k(v,y)=Q_v\cap\bigl(y+[-2^{-k}R_v,2^{-k}R_v]^n\bigr),\quad k=1,2,\ldots.
\]
For f-almost every y, the R374 Fubini argument gives that y is an interior point of Q_u for du-almost every capturing u. This common f-null exceptional set also has μ_v^+-measure zero for every v. Since θ_{v,y}≪du and is finite, the indicators of Q_k not being contained in Q_u decrease to zero θ-almost everywhere. Dominated convergence gives e_{v,y}(Q_k)→0. Choose the first k with e_{v,y}(Q_k)≤ξg_v(y). This countable choice is jointly measurable and finite on the full source-measure set; each Q_k has positive U_v volume for y in the interior of Q_v, which holds P_v-almost everywhere. On the negligible exceptional set use the harmless uniform fallback. On g=0 simply choose Q_v and s=0: nonnegative C has zero U mean, so C=0 U-almost everywhere there. Thus all the box assumptions in this section hold with s_v(y)=ξg_v(y), without imposing a density cap or a uniform positive side length.

Use this chosen family in (13) with t=1. The actual original row cost g on refill yields the quantitative receipt
\[
 \operatorname{Bad}(\tau^\Box)
 \le \xi G_{\rm joint}+(1-\xi)\mathcal D_\xi,
 \qquad
 \mathcal D_\xi=\int_E d_v E_{P_v}[\beta_v(y)g_v(y)]\,dv,
 \quad0\le\mathcal D_\xi\le G_{\rm joint}. \tag{16}
\]
This is an explicit measurable feasible cap-2 plan with the same 3Γ template fee. The countable shrinking uses no limiting transport optimizer. It supplies no uniform bound on the selected k, box volume, j_v or the weighted congestion term D_ξ. In particular (16) does not assert that D_ξ is paid or small; that is the remaining joint geometric budget. All original source-dependent fields and receiver measure stay unchanged.

## 6. Three-stage local verification, without new fixture search

The following saved code uses only the existing R373 interval/source profiles and bounded mark patterns. Stage 1 verifies exact intersection-box/zero-loss equality. Stage 2 verifies every retained-receiver omission bound and the anchored-box identity. Stage 3 verifies orthant monotonicity. It uses the actual capture geometry in that finite diagnostic, not an arbitrary incidence matrix. These checks do not prove native hard-branch admissibility or the missing source budget.

~~~python
from fractions import Fraction as F
from itertools import product

xs=[F(2*i+1,16)-F(1,2) for i in range(8)]
U=[F(1,8)]*8
profiles=((4,0,0,0,0,0,0,4),(2,0,2,0,2,0,2,0),
          (0,0,1,3,0,0,1,3),(1,1,1,1,1,1,1,1))
receivers=((F(-3,4),F(3,2)),(F(3,4),F(3,2)),
           (F(0),F(2)),(F(1,2),F(5,4)))
intervals=[(c-R/2,c+R/2) for c,R in receivers]
cap=[[F(int(l<=x<=r)) for x in xs] for l,r in intervals]
weights_cases=((F(1),F(1),F(1),F(1)),
               (F(1,3),F(2,5),F(1,7),F(3,4)),
               (F(1),F(1),F(0),F(0)))
counts={'zero_box':0,'omission_box':0,'anchored_identity':0,'orthant_order':0}
for raw in profiles:
 f=list(map(F,raw));q=sum(U[i]*f[i] for i in range(8))
 plus=[U[i]*max(f[i]-q,F(0))/q for i in range(8)]
 for weights in weights_cases:
  for mode in range(4):
   om=[[F(1) if mode==0 else (F(0) if mode==1 else
        F((i+2*k+mode)%5,4)) for i in range(8)] for k in range(4)]
   for i,y in enumerate(xs):
    if not plus[i]:continue
    w=[weights[k]*om[k][i]*cap[k][i] for k in range(4)]
    L=sum(w)
    K=[sum(w[k]*cap[k][j] for k in range(4)) for j in range(8)]
    active=[k for k in range(4) if w[k]>0]
    lo=max([F(-1,2)]+[intervals[k][0] for k in active])
    hi=min([F(1,2)]+[intervals[k][1] for k in active])
    for j,z in enumerate(xs):
     assert (K[j]==L)==(lo<=z<=hi)
     counts['zero_box']+=1
    for keep in product((0,1),repeat=4):
     retained=[k for k in active if keep[k]]
     omission=sum(w[k] for k in range(4) if not keep[k])
     blo=max([F(-1,2)]+[intervals[k][0] for k in retained])
     bhi=min([F(1,2)]+[intervals[k][1] for k in retained])
     for j,z in enumerate(xs):
      if blo<=z<=bhi:
       assert K[j]>=L-omission
       counts['omission_box']+=1
    for j,z in enumerate(xs):
     qlo,qhi=min(y,z),max(y,z)
     omission=sum(w[k] for k,(l,r) in enumerate(intervals)
                  if not(l<=qlo and qhi<=r))
     assert omission==L-K[j]
     counts['anchored_identity']+=1
    for j,z in enumerate(xs):
     for k,x in enumerate(xs):
      if (z-y)*(x-y)>=0 and abs(z-y)<=abs(x-y):
       assert K[j]>=K[k]
       counts['orthant_order']+=1
print('PASS',counts,'total',sum(counts.values()))
~~~

Execution record: the embedded geometry script was actually run and passed 14,400 Fraction assertions by the four reported categories (768 zero-box, 9,888 omission-box, 768 anchored identity, 2,976 orthant order). The existing parent-owned /tmp/r375_shared_check.py was independently executed read-only and returned PASS with 81 initial, 441 overlap and 2,025 expanded shared truncation/refill cases, 2,547 total. That script certifies finite algebra, not the missing hard-field congestion estimate; the final parent-rerun script checks both the tight bound using the original row mean cost and its coarser L bound. These finite checks do not replace the general proof of (15).
