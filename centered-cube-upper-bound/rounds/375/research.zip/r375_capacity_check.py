from fractions import Fraction as F
from itertools import product

checks = cases = strict = 0
Ts = [F(1), F(4,3), F(2), F(3)]

def optimal(weights, costs, t):
    left = F(1)
    rho = [F(0)] * len(weights)
    for c in sorted(set(costs)):
        ids = [i for i,x in enumerate(costs) if x == c]
        mass = sum(weights[i] for i in ids)
        b = min(t, left / mass)
        for i in ids:
            rho[i] = b
        left -= b * mass
    assert left == 0
    return rho

def vertex_min(weights, costs, t):
    vals = []
    for free in range(len(weights)):
        others = [i for i in range(len(weights)) if i != free]
        for bits in product((0,1), repeat=len(others)):
            rho = [F(0)] * len(weights)
            for i,b in zip(others,bits):
                rho[i] = t*b
            rho[free] = (1-sum(weights[i]*rho[i] for i in others))/weights[free]
            if 0 <= rho[free] <= t:
                vals.append(sum(w*c*r for w,c,r in zip(weights,costs,rho)))
    return min(vals)

def cdf_integral(weights, costs, L, t):
    cuts = sorted(set([F(0), L] + list(costs)))
    return sum((b-a)*max(F(0),1-t*sum(w for w,c in zip(weights,costs) if c<=a))
               for a,b in zip(cuts,cuts[1:]))

for weights in ([F(1,2),F(1,2)], [F(1,6),F(1,3),F(1,2)],
                [F(1,10),F(1,5),F(3,10),F(2,5)]):
    for costs in product((F(0),F(1,3),F(1)), repeat=len(weights)):
        L = max(costs)
        K = [L-c for c in costs]
        r = sum(w*k for w,k in zip(weights,K))
        V = sum(w*(k-r)**2 for w,k in zip(weights,K))
        M = max(r,L-r)
        aff = [1+(k-r)/M for k in K] if M else [F(1)]*len(K)
        assert all(0<=x<=2 for x in aff) and sum(w*x for w,x in zip(weights,aff))==1
        checks += 1
        gain = V/M if M else F(0)
        assert sum(w*k*x for w,k,x in zip(weights,K,aff))-r == gain
        assert gain >= V  # B=1
        if V:
            assert gain > V
            strict += 1
        checks += 1
        vals = []
        for t in Ts:
            rho = optimal(weights,costs,t)
            val = sum(w*c*x for w,c,x in zip(weights,costs,rho))
            assert all(0<=x<=t for x in rho) and sum(w*x for w,x in zip(weights,rho))==1
            assert val == vertex_min(weights,costs,t)
            assert val == cdf_integral(weights,costs,L,t)
            if t==1:
                assert rho == [F(1)]*len(weights)
            if t==2:
                assert val <= sum(w*c for w,c in zip(weights,costs))-gain
            vals.append(val)
            checks += 3
        assert all(x>=y for x,y in zip(vals,vals[1:]))
        checks += 1
        cuts = sorted(set([F(0),L]+list(costs)))
        for j,(s,t) in enumerate(zip(Ts,Ts[1:])):
            dif = F(0)
            for a,b in zip(cuts,cuts[1:]):
                prob = sum(w for w,c in zip(weights,costs) if c<=a)
                dif += (b-a)*min((t-s)*prob,max(F(0),1-s*prob))
            assert vals[j]-vals[j+1] == dif
            checks += 1
        cases += 1

for t in Ts:
    for p in (F(i,20) for i in range(21)):
        env = p+(1-p)*min(F(1),t*p)
        assert env == min(F(1),(t+1)*p-t*p*p)
        assert env <= (t+1)*p
        checks += 2
        for d in [F(i,20) for i in range(21)] + [1-p]:
            bound = min(p,1-d)+min(d,t*d*p)
            assert bound <= env
            if d == 1-p:
                assert bound == env
            checks += 1
        for s in Ts:
            if s <= t:
                es = p+(1-p)*min(F(1),s*p)
                assert env-es == (1-p)*(min(F(1),t*p)-min(F(1),s*p))
                assert 0 <= env-es <= (t-s)*p
                checks += 2
print('PASS', checks, 'checks;', cases, 'atomic row cases;', strict, 'strict affine improvements')
