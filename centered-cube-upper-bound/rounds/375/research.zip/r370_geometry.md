# R370 — A global uniform-overlap selector bound and a paid source component of the actual remainder

**Outcome.** A new unconditional center-geometry theorem is proved: for a fixed cube of side R, the uniform-overlap templates over ALL smaller side lengths have an integrable supremum with O(sqrt(n log(n+2))) total mass. There is no log(R/a) scale loss. Applied to the precise R369 remaining G, this pays its source component min(f(y),q_v), with all masses and original gates still computed from full f. The complementary (f(y)-q_v)_+ component remains unpaid.

The exact marked balance is

    G_rem=T+D_plus-D_minus=G_floor+D_plus,
    G_floor=T-D_minus>=0,
    G_floor<=T<=epsilon_0 C_oct,n X_q/(1+sqrt(n)).       (1)

The definitions preserve the true y-dependent J, strict past, and complete clock. D_minus is an explicit negative source-deviation term; no quantitative credit is proved for it, and it is not a reused square credit or a fee that can be spent twice. No full root bound is claimed for D_plus.

## 1. Fixed original contract

Retain the R369 ledger. E is the actual measurable Lebesgue receiver set of finite measure; f>=0 is in L1; a<=R_u<=b<=2a are actual cube SIDE LENGTHS, and

    m_u=f(Q_u)=q_u R_u^n, q_-=3lambda/4<=q_u<=lambda,
    mu(du)=du/m_u, c_u(y)=1_(Q_u)(y), E_r={u:R_u<=r},
    J_r(y)=integral_(E_r)c_u(y)mu(du),
    X_q=integral_E q_u du, W=integral f,
    ell=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr.

The inclusive clock tail is ell([R,b])=R^(-n). All parameters are the frozen contract's

    K=exp(sqrt(n)), h*=(1+sqrt(n))/(epsilon_0 q_-),
    alpha=(1+sqrt(n))^(1/n),
    Z_y(t-)=integral_E c_w(y)1_(m_w<t)mu(dw).

Let S(u,v) be precisely the y-independent remaining pair mask:

    m_u>K m_v,
    2||u-v||_infinity>alpha R_u,
    sum_i e_i(u,v)>
      n[(1+beta)max(a,R_v/beta)-R_u]^2
           /[4 beta max(a,R_v/beta)],
    beta=1+1/n, e_i=(2|u_i-v_i|-(R_u-R_v))_+.

Thus S retains outside-center and not Bplus, and K>lambda/q_- implies R_v<R_u. The exact object studied is

    G_rem=integral ell(dr) integral f(y)1_(J_r(y)>=H)/J_r(y)
      integral_(E_r^2) S(u,v)c_u(y)c_v(y)(m_u-m_v)
        1_(Z_y(m_u/K-)>h*)mu(du)mu(dv)dy.              (2)

Zero-J rows are zero. No old N/A/C/D/Bplus pair is reintroduced.

## 2. New global geometric theorem

For a fixed centered cube Q_R of side R and 0<a<=R, put

    p_s(x)=|Q_R intersection (x+Q_s)|/(R^n s^n),
          a<=s<=R.

Each p_s is a probability density on real center space. Define

    a_score,n=sqrt(1/4+(1/2)log(1+sqrt(n))),
    C_n(eta)=1+n(1-eta)/[2(sqrt(n)+1)]
                +2sqrt(n)a_score,n(1-sqrt(eta)), 0<=eta<=1.

Then

    integral_(R^n) sup_(a<=s<=R) p_s(x) dx
       <=C_n(a/R)<=C_n(0),                             (3)

where

    C_n(0)=1+n/[2(sqrt(n)+1)]+2sqrt(n)a_score,n
          =O(sqrt(n log(n+2))).

Consequently, for EVERY measurable actual radius selector a<=s(v)<=R,

    integral |Q_R intersection (v+Q_(s(v)))|/s(v)^n dv
       <=R^n C_n(a/R).                                (4)

Restricting the real center integration to E or additional actual masks only decreases this bound. The theorem also holds with the supremum over all 0<s<=R and constant C_n(0), by monotone convergence as a decreases to zero. It imposes no assumption on f.

In the original octave band R<=2a, use the smaller uniform constant

    C_oct,n=C_n(1/2)
       =1+n/[4(sqrt(n)+1)]
          +2sqrt(n)a_score,n(1-1/sqrt(2)).                   (5)

This global result does not discretize the actual radius field as an independent ds variable. The derivative integral below is a pointwise majorant for its supremum, with its full scale cost explicitly bounded.

## 3. One-dimensional score, genuine center independence, and Winsorization

The one-coordinate density of p_s is a trapezoid. Set r=s/R. It is 1/R on |x|<=(R-s)/2, and on each ramp is

    p_(s,1)(x)=d/(Rs), d=(R+s)/2-|x| in (0,s).

It vanishes outside |x|<=(R+s)/2. Its logarithmic derivative multiplied by s is

    X=0 on the plateau,
    X=s/(2d)-1 on a ramp.                              (6)

Under this CENTER density, the plateau mass is 1-r and w=d/s in (0,1) has ramp measure 2r w dw. Thus

    E X=0, X>=-1/2,
    P(X>t)=r/[4(t+1)^2], t>=0.                         (7)

For example E X=r integral_0^1(1-2w)dw=0. These are facts about Lebesgue-normalized trapezoids. The product density p_s makes its n center coordinates independent; nothing here asserts independence of f, an actual source posterior, or the receiver selector.

Fix L>=1. Use WINSORIZATION, not deletion of the tail:

    Y=min(X,L), Z=(X-L)_+, X=Y+Z.

Then

    E Z=integral_L^infinity P(X>t)dt=r/[4(L+1)],
    E Y=-E Z,
    E Y^2<=r[1/4+(1/2)log(1+L)].                       (8)

For the last inequality, the negative second moment is at most r/4, and the capped positive second moment is
2 integral_0^L t P(X>t)dt <=(r/2)log(1+L).
The exact second moment, useful for diagnostics, is

    E Y^2=r[(1/2)log(2(L+1))-3/4+1/(2(L+1))].

For independent coordinates X_i under p_s,

    E|sum_i X_i|
      <=sqrt(n E Y^2)+2n E Z
      <=sqrt(nr)*sqrt(1/4+(1/2)log(1+L))
            +nr/[2(L+1)].                             (9)

This follows by centering sum Y_i, applying its variance bound, and retaining both n|EY| and the positive tail sum. In particular no infinite-variance Fisher-information estimate is asserted. The uncapped X actually has a logarithmically divergent second moment.

Taking L=sqrt(n), the product derivative satisfies

    ||s partial_s p_s||_1
       =E|sum_i X_i|
       <=sqrt(n s/R) a_score,n+ns/[2R(sqrt(n)+1)].           (10)

## 4. Supremum domination with no scale-log loss

For each fixed center x, s -> p_s(x) is continuous and piecewise continuously differentiable on [a,R]; the trapezoid boundary values match. Products retain absolute continuity. Therefore

    sup_(a<=s<=R)p_s(x)
       <=p_a(x)+integral_a^R |partial_s p_s(x)|ds.

Tonelli and (10) give

    integral sup p_s
      <=1+integral_a^R [sqrt(ns/R)a_score,n
                        +ns/(2R(sqrt(n)+1))]ds/s
      =1+2sqrt(n)a_score,n(1-sqrt(a/R))
           +n(1-a/R)/[2(sqrt(n)+1)].

This proves (3), and (4) follows by selecting the actual s(v). The retained factor r=s/R in the score distribution is what removes the logarithmic scale loss. Dropping it before integrating would give the weaker log(R/a) bound. The derivative calculation is solely for a fixed reference family of center densities, not a re-selection of the actual receiver radii.

## 5. Exact preservation of the original source-dependent marks

Define for each actual u

    omega_u(y)=h* R_u^n integral_[R_u,b] ell(dr)
       1_(J_r(y)>=H)1_(Z_y(m_u/K-)>h*)/J_r(y),         (11)

with the quotient zero when J=0. This does NOT replace any source-weighted mark by an unweighted intersection.

Every w counted in Z_y(m_u/K-) satisfies

    R_w^n=m_w/q_w<m_u/(Kq_-)
        <=[lambda/(Kq_-)]R_u^n<R_u^n.

Thus on the original past gate and r>=R_u, J_r(y)>h*. Using the inclusive tail in (11) proves

    0<=omega_u(y)<=1.                                 (12)

Since S implies R_v<R_u, the original pair-clock starts exactly at R_u. Positive Fubini in (2), with mu and m canceled only algebraically, gives the EXACT identity

    G_rem=(1/h*) integral_E du/R_u^n integral_E dv
       S(u,v)(1-m_v/m_u)
       integral_(Q_u intersection Q_v)
            omega_u(y) f(y)/m_v dy.                   (13)

The actual y dependence of J and strict past, and the terminal atom, are all inside omega_u. It must remain inside every signed source integral below.

## 6. Template payment and the exact marked source-defect balance

Let A(u,v)=S(u,v)(1-m_v/m_u), so 0<=A<=1. Define the nonnegative template

    T=(1/h*) integral du/R_u^n integral dv A(u,v)
        integral_(Q_u intersection Q_v)
                         omega_u(y)/R_v^n dy.          (14)

Using omega<=1, actual R_v<R_u, and (4),

    T<= (1/h*) integral_E C_n(a/R_u)du
      <= C_oct,n |E|/h*
      <= C_oct,n X_q/(q_-h*)
       = epsilon_0 C_oct,n X_q/(1+sqrt(n)).            (15)

Only REAL receiver-center Lebesgue integration is bounded geometrically. No thin source layer is bounded by volume, and no pointwise density cap is assumed.

Now use the full matching equation m_v=q_v R_v^n to write, pointwise in the actual source,

    f(y)/m_v=1/R_v^n+(f(y)-q_v)/m_v.

Define D_plus and D_minus by replacing 1/R_v^n in (14) with, respectively,

    (f(y)-q_v)_+/m_v,    (q_v-f(y))_+/m_v.

All factors A, omega_u(y), the cube intersections and normalizations stay EXACTLY as in (14). Then

    G_rem=T+D_plus-D_minus.                            (16)

This is a marked identity, not an inference from an unweighted I_uv decomposition. Neither omega_u nor its original source-dependent gates are removed from D_plus or D_minus.

There is also a particularly transparent positive decomposition. Let G_floor be (13) with f(y) in the integrand replaced by min(f(y),q_v), while every mass, q_v, past, J, and radius remains computed from the ORIGINAL FULL f. Then

    G_floor=T-D_minus>=0,
    G_rem=G_floor+D_plus,
    0<=G_floor<=T, 0<=D_minus<=T, 0<=D_plus<=G_rem.      (17)

Thus (15) pays an unconditional, explicitly specified part of the actual remaining source integral. It does not assume f<=q_v, replace the original input by a capped function, or renormalize a receiver posterior. The positive concentration-excess D_plus is still unpaid.

All terms are finite in the finite-measure contract. The original row bound gives G_rem<=X_q, hence D_plus<=X_q, and (15) bounds T and D_minus. No undefined infinity-minus-infinity operation is used.

## 7. Exact remaining source correlation and updated conditional ledger

For each receiver v, matching gives the genuine mean-zero identity

    integral_(Q_v)(f(y)-q_v)dy=0.

It does NOT cancel (16), because its test weight depends on y. More explicitly, put

    F_v(y)=(1/h*) integral_E du/R_u^n
          A(u,v)omega_u(y)c_u(y).

Then the signed defect is exactly

    D_plus-D_minus
       =integral_E dv/m_v integral_(Q_v)
                       (f(y)-q_v)F_v(y)dy.             (18)

F_v is bounded by |E|/(h*a^n) in this contract. One may subtract any finite constant from F_v on Q_v without changing (18). What remains missing is a general bound on this actual source-oscillation correlation, or on the stronger positive D_plus. The common full-f matching does not itself make F_v constant or independent of f.

Let Cplus_n be the frozen R369 capacity (<72). Combining its ledger with (15),(17), at the unchanged epsilon_0 and h*, yields

    B_H(f,nu)<=D_plus
      +epsilon_0[2+(Cplus_n+C_oct,n)/(1+sqrt(n))]X_q
      +C338(epsilon_0,n)W.                            (19)

No old geometry fee or source-past fee is repeated. Equivalently one can keep D_plus-D_minus and the paid template T bound, but its negative term cannot also be used as a second credit after using G_floor=T-D_minus.

The coefficient added to X_q is O(epsilon_0 sqrt(log(n+2))). If one chooses the parameters BEFORE instantiating the contract, the safe allocation

    A_total,n=2+(72+C_oct,n)/(1+sqrt(n)),
    epsilon_0=epsilon/A_total,n

makes the coefficient in (19) at most epsilon. The inherited source fee must simultaneously be evaluated at this same epsilon_0:

    C338=(lambda/q_-)
        [(2+3sqrt(n)+2exp(-sqrt(n)))/epsilon_0+1+sqrt(n)].

It is then O_epsilon(sqrt(n log(n+2)))W. This is only a consistent parameter specialization; one cannot change epsilon_0 while pretending the old h* or D_plus integral stayed numerically unchanged.

Equation (19) does not close the general estimate: D_plus is the original outside-center, high-total-excess, far-mass, high-past integral with source factor (f-q_v)_+ and all original weights retained. A sufficient next result would pay D_plus at the requested scale. Alternatively a sharp signed estimate could control D_plus-D_minus in (18), with the negative term used only once. No such general estimate is established here.

## 8. Actual local computation and limits of its evidence

The default local Python had no SymPy installed (import failed), so the checks use built-in Fraction and 80-digit Decimal. The code below was actually executed and returned

    PASS {'score_mean':4,'winsor_tail_bounds':24,
          'winsor_second_moment_diagnostics':24,
          'ratio_constant_diagnostics':25,
          'marked_decomposition':75,'zero_mass_defects':18} total 170

The Decimal comparisons are high-precision diagnostics, not interval certificates. The general score and envelope inequalities are proved above.

The final block uses finite source cells with full matching masses, a true volume-valued discrete clock including its terminal atom, and y-dependent high-J/strict-past marks. It checks (11)–(17) exactly in Fraction arithmetic. Receiver weights are quadrature weights; the incidence arrays are not claimed to realize the high-dimensional cube geometry or the current hard remainder. The arbitrary positive pair mask tests the algebra without claiming it is outside-center/not Bplus.

~~~python
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
counts={'score_mean':0,'winsor_tail_bounds':0,'winsor_second_moment_diagnostics':0,'ratio_constant_diagnostics':0,'marked_decomposition':0,'zero_mass_defects':0}
def dec(x):return D(x.numerator)/D(x.denominator)
for r in [F(1,4),F(1,2),F(3,4),F(1)]:
 assert r*(F(1)-F(1))==0
 counts['score_mean']+=1
 for L in [F(1),F(3,2),F(2),F(4),F(10),F(100)]:
  w0=1/(2*(L+1))
  tailprob=r*w0*w0
  rawtail=r*(w0-w0*w0)
  excess=rawtail-L*tailprob
  assert tailprob==r/(4*(L+1)**2)
  assert excess==r/(4*(L+1))
  capmean=-rawtail+L*tailprob
  assert capmean==-excess
  counts['winsor_tail_bounds']+=1
  with localcontext() as ctx:
   ctx.prec=80
   rawsecond=dec(r)*(D('0.5')*(2*(dec(L)+1)).ln()-1+2*dec(w0)-dec(w0)**2)
   capsecond=rawsecond+dec(L*L*tailprob)
   formula=dec(r)*(D('0.5')*(2*(dec(L)+1)).ln()-D('0.75')+1/(2*(dec(L)+1)))
   bound=dec(r)*(D('0.25')+D('0.5')*(1+dec(L)).ln())
   assert abs(capsecond-formula)<D('1e-75')
   assert 0<=capsecond<=bound
   counts['winsor_second_moment_diagnostics']+=1
with localcontext() as ctx:
 ctx.prec=80
 for n in [1,4,16,64,256]:
  N=D(n);root=N.sqrt();A=(D('0.25')+D('0.5')*(1+root).ln()).sqrt()
  universal=1+N/(2*(root+1))+2*root*A
  for ratio in [F(1),F(3,4),F(1,2),F(1,4),F(1,100)]:
   eta=dec(ratio)
   exact=1+N*(1-eta)/(2*(root+1))+2*root*A*(1-eta.sqrt())
   assert 1<=exact<=universal
   counts['ratio_constant_diagnostics']+=1
sets=[{0,1},{1,2,3},set(range(8)),set(range(4,12)),set(range(12)),{0,2,4,6,8,10}]
V=[F(len(A)) for A in sets]
du=[F(i+1,3) for i in range(len(sets))]
levels=sorted(set(V))
clock=[1/levels[k]-(1/levels[k+1] if k+1<len(levels) else F(0)) for k in range(len(levels))]
for phase in range(3):
 f=[F(6+(y+phase)%3,8) for y in range(12)]
 m=[sum(f[y] for y in A) for A in sets]
 q=[m[i]/V[i] for i in range(6)]
 mu=[du[i]/m[i] for i in range(6)]
 for v in range(6):
  assert sum(f[y]-q[v] for y in sets[v])==0
  counts['zero_mass_defects']+=1
 K=F(2)
 J=[[sum(mu[u] for u in range(6) if V[u]<=R and y in sets[u]) for y in range(12)] for R in levels]
 past=[[sum(mu[v] for v in range(6) if m[v]<m[u]/K and y in sets[v]) for y in range(12)] for u in range(6)]
 for H in [F(0),F(1,4),F(1,2),F(1),F(2)]:
  for h in [F(1,8),F(1,4),F(1,2),F(1),F(2)]:
   omega=[[F(0) for y in range(12)] for u in range(6)]
   original=F(0)
   for k,R in enumerate(levels):
    for u in range(6):
     if V[u]>R:continue
     for y in range(12):
      if J[k][y] and J[k][y]>=H and past[u][y]>h:
       assert J[k][y]>h
       omega[u][y]+=h*V[u]*clock[k]/J[k][y]
     for v in range(6):
      if V[v]>R or not(m[u]>K*m[v]) or (u+2*v)%3==0:continue
      for y in sets[u]&sets[v]:
       if J[k][y] and J[k][y]>=H and past[u][y]>h:
        original+=clock[k]*f[y]*(m[u]-m[v])*mu[u]*mu[v]/J[k][y]
   assert all(0<=z<=1 for row in omega for z in row)
   template=F(0);plus=F(0);minus=F(0);floor=F(0)
   for u in range(6):
    for v in range(6):
     if not(m[u]>K*m[v]) or (u+2*v)%3==0:continue
     assert V[v]<V[u]
     coeff=du[u]*du[v]*(1-m[v]/m[u])/(h*V[u])
     for y in sets[u]&sets[v]:
      template+=coeff*omega[u][y]/V[v]
      plus+=coeff*omega[u][y]*max(F(0),f[y]-q[v])/m[v]
      minus+=coeff*omega[u][y]*max(F(0),q[v]-f[y])/m[v]
      floor+=coeff*omega[u][y]*min(f[y],q[v])/m[v]
   assert original==template+plus-minus==floor+plus
   assert floor==template-minus and 0<=minus<=template and 0<=plus<=original
   counts['marked_decomposition']+=1
print('PASS',counts,'total',sum(counts.values()))
~~~

Only /tmp/r370_geometry.md is written. This bounded result stops at the new template theorem, the paid original source component and the exact remaining source-concentration balance.
