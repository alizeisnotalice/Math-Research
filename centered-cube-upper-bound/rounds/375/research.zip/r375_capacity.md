# R375 — Measurable row-capped common plans and an exact selectable gain

## 1. Frozen actual field and scope

Keep precisely the R374 full source f≥0 in L1, actual receiver measure du on E of finite measure, cubes Q_u of side a≤R_u≤b≤2a, and m_u=f(Q_u)=q_uR_u^n with q_-≤q_u≤λ and q_-=3λ/4. Write W=||f||_1 and X_q=∫_E q_u du. All original J, H, strict-past gates, far-mass masks, physical clock (including its terminal atom) and original source labels remain frozen. In particular put

\[
 A_{uv}=S(u,v)(1-m_v/m_u)\in[0,1],\qquad
 \omega_u(y)=hR_u^n\int_{[R_u,b]}\ell(dr)
 \frac{1_{J_y(r)\ge H}1_{Z_y(m_u/K-)>h}}{J_y(r)}\in[0,1],
 \quad h=\frac{1+\sqrt n}{\epsilon_0q_-}.
\]

Here S and K=e^{√n} are the original masks/threshold, and A>0 implies R_v<R_u. Define, with all v integrals using actual dv,

\[
 \mu_v^+=\frac{(f-q_v)_+1_{Q_v}}{m_v}dy=d_vP_v(dy),\quad
 U_v(dz)=1_{Q_v}(z)dz/R_v^n,\quad 0\le d_v\le1.
\]

When d_v=0 set P_v=U_v and every plan/credit carrying d_v to zero. Define the common, already receiver-aggregated kernel

\[
 K_v(y,z)=\frac1h\int_E\frac{du}{R_u^n}A_{uv}\omega_u(y)1_{Q_u}(y)1_{Q_u}(z),\quad
 L_v(y)=\frac1h\int_E\frac{du}{R_u^n}A_{uv}\omega_u(y)1_{Q_u}(y).
\]

The actual-center envelope gives 0≤K_v≤L_v≤B, where B=[1+n log(b/a)]/h>0. No bound on f's pointwise density is used. Let C_v(y,z)=L_v(y)−K_v(y,z), and r_v(y)=E_{U_v}K_v(y,·). The R371 product-plan remainder is

\[
 G_{\rm joint}=\int_E d_v\,dv\int P_v(dy)[L_v(y)-r_v(y)]. \tag{1}
\]

We construct an actual feasible common plan for every finite t≥1. The optimization below is only over the stronger **row cap** 0≤ρ(v,y,z)≤t and E_Uρ=1. This implies target≤td_vU_v; it is not a claim of optimality among all plans satisfying that aggregate target cap.

## 2. Explicit measurable threshold and exact row value

Fix (v,y). Write F(s)=U_v{C_v(y,·)≤s}. Let

\[
 a_t(v,y)=\inf\{s\in[0,B]:F(s)\ge1/t\},\quad
 F_-=U_v\{C<a_t\},\quad e=U_v\{C=a_t\}.
\]

Then a_t≤L_v(y), F_-≤1/t≤F_-+e. Set

\[
 b_t=\begin{cases}(1-tF_-)/e,&e>0,\\0,&e=0,\end{cases}
 \qquad
 \rho_t=t1_{C<a_t}+b_t1_{C=a_t}. \tag{2}
\]

If e=0, F_-=1/t. Thus 0≤b_t≤t, 0≤ρ_t≤t and E_Uρ_t=1 in all cases. For t=1, ρ_t=1 U-almost everywhere. For L=0 the construction gives a_t=0, b_t=1 and ρ_t=1. The maps are jointly measurable: C is jointly measurable, parameterized integration makes F(s) measurable, and the quantile can be tested on rational s by right continuity of F. Integration of the measurable variable-threshold indicators gives F_- and e. Hence

\[
 \tau_{v,t}(dy,dz)=d_vP_v(dy)\rho_t(v,y,z)U_v(dz) \tag{3}
\]

has exact source marginal μ_v^+ and target marginal at most td_vU_v. This one plan serves all actual u; it is not selected separately for each receiver pair.

The exact optimal row bad cost in this row-cap class is

\[
 \boxed{V_t(v,y)=\int_0^{L_v(y)}
 \left(1-tU_v\{K_v(y,z)\ge L_v(y)-s\}\right)_+ds.} \tag{4}
\]

Proof: for any feasible ρ, layer cake and the cap give

\[
 \int C\rho\,dU=\int_0^L\int_{C>s}\rho\,dU\,ds
 \ge\int_0^L(1-tF(s))_+ds.
\]

For (2), when s<a_t its mass on {C≤s} is tF(s); when s≥a_t all its mass is on {C≤s}. Equality follows (the single cutoff value is immaterial). This proves both feasibility and an attained row minimum, rather than using a dual lower bound as an upper construction. Replacing ≥ by > in (4) changes only the at-most-countable set of atom levels and leaves the integral unchanged. Such a replacement is **not** legitimate in (2) without allocating the threshold atom.

Put

\[
 G_t=\int_E d_v\,dv\int P_v(dy)V_t(v,y),\quad
 \Delta_t=G_{\rm joint}-G_t\ge0. \tag{5}
\]

Then G_1=G_joint and G_t decreases with t. All these quantities are finite, bounded by B|E|. Original surplus traffic decomposes exactly into good transport plus G_t by writing 1_{Q_u}(y)=1_{Q_u}(y)1_{Q_u}(z)+1_{Q_u}(y)(1−1_{Q_u}(z)) under (3). The original ω stays on y in both pieces.

## 3. Sharp scalar joint template and complete price

For p=p_uv=U_v(Q_u), the marked floor a_uv and transported good mass g_uv satisfy

\[
 a_{uv}\le\min(p,1-d_v),\qquad
 g_{uv}\le\min(d_v,td_vp).
\]

The latter uses both the total plan mass and its capped target marginal. Maximizing this scalar bound over d∈[0,1] gives exactly

\[
 \boxed{E_t(p)=p+(1-p)\min(1,tp)
 =\min\{1,(t+1)p-tp^2\}.} \tag{6}
\]

Indeed, set c=min(1,tp). On d≤1−p the expression is p+cd and is increasing; on d≥1−p it is 1−(1−c)d and is decreasing. Equality holds at d=1−p. This is the best envelope from the stated scalar constraints, not a claim that every actual marked field attains it. E_t(p)≤(t+1)p, with the linear coefficient sharp as p↓0.

Retain the exact template

\[
 T_t=\frac1h\int_E\frac{du}{R_u^n}\int_E A_{uv}E_t(p_{uv})\,dv.
\]

R370's actual-overlap selector theorem gives

\[
 G_{\rm floor}+G_{\rm good}(\tau_t)\le T_t
 \le\frac{(t+1)\Gamma_n|E|}{h}
 \le\frac{\epsilon_0(t+1)\Gamma_n}{1+\sqrt n}X_q. \tag{7}
\]

Thus, rebuilding the same original positive G decomposition (not altering an old upper bound solely by comparison of remainders), the hard-slot receipt is

\[
 \boxed{B_H(f,\nu)\le G_t+
 \epsilon_0\left[2+\frac{C_n^++(t+1)\Gamma_n}{1+\sqrt n}\right]X_q
 +C_{338}W,\quad \nu\le f,} \tag{8}
\]

where C_n^+<72 and

\[
 C_{338}=\frac\lambda{q_-}
 \left[\frac{2+3\sqrt n+2e^{-\sqrt n}}{\epsilon_0}+1+\sqrt n\right].
\]

One may instead retain T_t in (8), replacing its displayed Γ contribution. For a prescribed coefficient η use

\[
 \mathcal L_{n,t}=2+\frac{72+(t+1)\Gamma_n}{1+\sqrt n},\qquad
 \epsilon_0=\eta/\mathcal L_{n,t}.
\]

All h-dependent gates and marks must then be rebuilt consistently. Using the established Γ_n=O(√(n log(n+2))), the source price is O_η((t+1)√(n log(n+2)))W. Fixed t preserves the previous order; t≤C log^A(n+2) preserves a root-times-polylog order. This only prices the template, not G_t. The original entrance terms 8λHW and 2d_eff A_nW_ν/H, the hard-slot factor 2, and outer 128/119 remain unchanged. Equation (8) replaces the preceding coupling receipt; floor and transport prices are not added a second time.

## 4. A definite choice t=2 gives a strict same-price improvement

This is more than naming a row optimum. Write V=Var_U K, r=E_U K and M=max(r,L−r). When M>0 the explicit affine competitor

\[
 \rho_{\rm aff}=1+(K-r)/M
\]

lies between 0 and 2, has mean one, and increases reward over the product row by V/M. When M=0 take ρ_aff=1 and V/M=0. Hence row optimality gives

\[
 \boxed{G_2\le G_{\rm joint}-\int_E d_v\,dv\int P_v(dy)\frac{V}{M}
 =\widehat G-\mathcal E,\quad
 \mathcal E=\int_E d_v\,dv\int P_v(dy)V\left(\frac1M-\frac1B\right)\ge0.} \tag{9}
\]

Here widehat G is the R374 affine-B remainder, and the summand is zero when M=0. Since 0≤K≤L, V≤r(L−r); thus V/M≤min(r,L−r)≤B, so (9) is integrable without an inverse-M singularity. If V>0, then 0<r<L and M<L≤B, making its extra credit strictly positive. Therefore whenever the R374 integrated variance is positive, (9) strictly improves its remainder **at the same 3Γ_n template price**. R374's actual-cube nullspace theorem further implies G_joint>0 ⇒ that integrated variance is positive. Consequently t=2 is a concrete universally feasible strict improvement over that receipt whenever its original joint remainder is nonzero. There is no uniform fraction: neither M nor the integrated variance supplies a dimension-controlled lower ratio to G_joint.

For other choices 1≤s<t, all comparisons below are at the SAME frozen h and field. With F(s')=U{C≤s'},

\[
 G_s-G_t=\int_Ed_v\,dv\int P_v(dy)\int_0^L
 \min\{(t-s)F(s'),(1-sF(s'))_+\}\,ds'. \tag{10}
\]

The exact template increase is

\[
 T_t-T_s=\frac1h\iint\frac{du\,dv}{R_u^n}A_{uv}(1-p_{uv})
 [\min(1,tp_{uv})-\min(1,sp_{uv})]
 \le\frac{(t-s)\Gamma_n|E|}h. \tag{11}
\]

Thus (10) exceeding (11) is an actual computable net-improvement certificate for the complete receipt. A sufficient certificate uses the last explicit bound in (11). One can evaluate finitely many fixed capacities and choose the smallest entire right side. No measurable infinite-dimensional optimizer or free increase of t is asserted. In particular the t=2 versus R374 comparison in (9) needs no added template price at all.

The unpaid issue is a quantitative integrated upper bound on G_t (or lower bound on the displayed gain) from the original matching constraints. Threshold plans can select a tiny high-reward neighborhood only with a correspondingly large t and price. No density cap, fresh negative capture-square credit, uniform contraction, or bounded-cost iteration has been proved here.

## 5. Reproducible finite exact checks

The following standard-library Fraction script checks finite atomic row distributions, including cutoff atoms and zero costs, against exhaustive box-simplex vertices. It also verifies the layer-cake formula, affine-M credit, strict extra credit, capacity nesting, the exact gain difference, and the scalar best template. These are exact finite checks of the construction, not a realization of the native high-past receiver field.

```python
from fractions import Fraction as F
from itertools import product

checks = cases = strict = 0
Ts = [F(1), F(4,3), F(2), F(3)]

def optimal(weights, costs, t):
    left = F(1)
    rho = [F(0)] * len(weights)
    for c in sorted(set(costs)):
        ids = [i for i,x in enumerate(costs) if x == c]
        mass = sum(weights[i] for i in ids)
        b = min(t, left / mass)
        for i in ids:
            rho[i] = b
        left -= b * mass
    assert left == 0
    return rho

def vertex_min(weights, costs, t):
    vals = []
    for free in range(len(weights)):
        others = [i for i in range(len(weights)) if i != free]
        for bits in product((0,1), repeat=len(others)):
            rho = [F(0)] * len(weights)
            for i,b in zip(others,bits):
                rho[i] = t*b
            rho[free] = (1-sum(weights[i]*rho[i] for i in others))/weights[free]
            if 0 <= rho[free] <= t:
                vals.append(sum(w*c*r for w,c,r in zip(weights,costs,rho)))
    return min(vals)

def cdf_integral(weights, costs, L, t):
    cuts = sorted(set([F(0), L] + list(costs)))
    return sum((b-a)*max(F(0),1-t*sum(w for w,c in zip(weights,costs) if c<=a))
               for a,b in zip(cuts,cuts[1:]))

for weights in ([F(1,2),F(1,2)], [F(1,6),F(1,3),F(1,2)],
                [F(1,10),F(1,5),F(3,10),F(2,5)]):
    for costs in product((F(0),F(1,3),F(1)), repeat=len(weights)):
        L = max(costs)
        K = [L-c for c in costs]
        r = sum(w*k for w,k in zip(weights,K))
        V = sum(w*(k-r)**2 for w,k in zip(weights,K))
        M = max(r,L-r)
        aff = [1+(k-r)/M for k in K] if M else [F(1)]*len(K)
        assert all(0<=x<=2 for x in aff) and sum(w*x for w,x in zip(weights,aff))==1
        checks += 1
        gain = V/M if M else F(0)
        assert sum(w*k*x for w,k,x in zip(weights,K,aff))-r == gain
        assert gain >= V  # B=1
        if V:
            assert gain > V
            strict += 1
        checks += 1
        vals = []
        for t in Ts:
            rho = optimal(weights,costs,t)
            val = sum(w*c*x for w,c,x in zip(weights,costs,rho))
            assert all(0<=x<=t for x in rho) and sum(w*x for w,x in zip(weights,rho))==1
            assert val == vertex_min(weights,costs,t)
            assert val == cdf_integral(weights,costs,L,t)
            if t==1:
                assert rho == [F(1)]*len(weights)
            if t==2:
                assert val <= sum(w*c for w,c in zip(weights,costs))-gain
            vals.append(val)
            checks += 3
        assert all(x>=y for x,y in zip(vals,vals[1:]))
        checks += 1
        cuts = sorted(set([F(0),L]+list(costs)))
        for j,(s,t) in enumerate(zip(Ts,Ts[1:])):
            dif = F(0)
            for a,b in zip(cuts,cuts[1:]):
                prob = sum(w for w,c in zip(weights,costs) if c<=a)
                dif += (b-a)*min((t-s)*prob,max(F(0),1-s*prob))
            assert vals[j]-vals[j+1] == dif
            checks += 1
        cases += 1

for t in Ts:
    for p in (F(i,20) for i in range(21)):
        env = p+(1-p)*min(F(1),t*p)
        assert env == min(F(1),(t+1)*p-t*p*p)
        assert env <= (t+1)*p
        checks += 2
        for d in [F(i,20) for i in range(21)] + [1-p]:
            bound = min(p,1-d)+min(d,t*d*p)
            assert bound <= env
            if d == 1-p:
                assert bound == env
            checks += 1
        for s in Ts:
            if s <= t:
                es = p+(1-p)*min(F(1),s*p)
                assert env-es == (1-p)*(min(F(1),t*p)-min(F(1),s*p))
                assert 0 <= env-es <= (t-s)*p
                checks += 2
print('PASS', checks, 'checks;', cases, 'atomic row cases;', strict, 'strict affine improvements')
```

Actual local execution: **PASS 4542 checks; 117 atomic row cases; 108 strict affine improvements.** The first execution exposed a Python list/tuple concatenation in the check harness; after converting costs to a list, the exact embedded version above ran successfully. No native high-past realization or global root closure is inferred from these finite checks.
