# 第374轮完整优先账：允许目标容量二倍的共同来源结算

固定同一完整f、实际Lebesgue接收集E、原选择器、m/q、J、strictpast、far/outside/notBplus门，以及包含末端原子的物理时钟。沿用R373 K_v,L_v,mu_v^+,d_v,P_v,U_v，B=(1+n log(b/a))/h，r_v(y)=E_U K_v(y,z)。d_v=0时贡献取0。

新实际耦合
\[
\widehat\tau_v=d_v[1+(K_v-r_v)/B]P_v\otimes U_v
\]
保持来源边缘mu_v^+，目标边缘不再固定为d_vU_v，而满足0≤sigma_v≤2d_vU_v。所有u共用它，完整输入和所有原标记不变。新扣减
\[
\widehat\Delta=\int_E\frac{d_v}{B}E_{P_v}\operatorname{Var}_{U_v}K_v\,dv
=2\Delta+\mathcal M,\qquad
\mathcal M=\int_E\frac{d_v}{B}\operatorname{Var}_{U_v}(E_{P_v}K_v)\,dv\ge0.
\]
等式中的旧Delta必须在同一参数、同一场上计算。精确新剩余widehatG=G_joint−widehatDelta≥0。

新联合floor/good费用≤3T0≤3Gamma_n |E|/h，替换旧2Gamma_n，不再叠加旧扣减或旧模板。更细min(1,3p−2p²)只属于这一模板内部，未取出重复信用。因此
\[
B_H(f,\nu)\le\widehat G+
\varepsilon_0\left[2+\frac{C_n^++3\Gamma_n}{1+\sqrt n}\right]X_q+C_{338}W,
\quad \nu\le f,\quad C_n^+<72,
\]
\[
C_{338}=\frac\lambda{q_-}\{(2+3\sqrt n+2e^{-\sqrt n})/\varepsilon_0+1+\sqrt n\},
\quad\Gamma_n=1+\frac{n}{4(\sqrt n+1)}+
2\sqrt n\sqrt{1/4+\tfrac12\log(1+\sqrt n)}(1-1/\sqrt2).
\]
给定本硬槽可用系数eta，设
\[
\mathcal L_n=2+(72+3\Gamma_n)/(1+\sqrt n),\quad
\varepsilon_0=\eta/\mathcal L_n,\quad
h=(1+\sqrt n)\mathcal L_n/(\eta q_-).
\]
同步使用这个epsilon_0、h及C338，包括所有h相关原门。来源费仍为O_eta(sqrt(n log(n+2)))W；改变h后不能直接比较两次运行的剩余。

入口完整保持
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H
+2\widehat G
+2\varepsilon_0[2+(C_n^++3\Gamma_n)/(1+\sqrt n)]X_q+2C_{338}W,
\quad A_n=1+n\log(b/a).
\]
全式再乘Lambda=128/119。新信用为2Lambda widehatDelta，使用一次；本硬槽贡献接收系数至多2Lambda eta。保留R373完整旧式作替代时，可以比较两套完整右端，不能把新扣减与旧2Gamma费用拼合。新剩余较小不表示增加模板费后的整个右端逐输入必然更小。

**严格性不等于定量闭合。** 真实立方体内点和L1来源给出widehatDelta=0当且仅当G_joint=0；没有统一比例、迭代速率或维数一致预算。当前仍缺widehatG的根阶估计。一般soft、crossing、入口连接、硬合同外重尾、宽距离/低pe/极端比例及补集、初始/删除/未来被删来源、H选择、来源与物理尺度聚合、外积分、截断与极限仍保留。辅助壳流费用定理没有实际覆盖原load，不进入本优先账。有限诊断的cap2最优值不替代上述缺口。
