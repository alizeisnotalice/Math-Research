from fractions import Fraction as F
from itertools import product

xs=[F(2*i+1,16)-F(1,2) for i in range(8)]
U=[F(1,8)]*8
profiles=((4,0,0,0,0,0,0,4),(2,0,2,0,2,0,2,0),
          (0,0,1,3,0,0,1,3),(1,1,1,1,1,1,1,1))
receivers=((F(-3,4),F(3,2)),(F(3,4),F(3,2)),
           (F(0),F(2)),(F(1,2),F(5,4)))
intervals=[(c-R/2,c+R/2) for c,R in receivers]
cap=[[F(int(l<=x<=r)) for x in xs] for l,r in intervals]
weights_cases=((F(1),F(1),F(1),F(1)),
               (F(1,3),F(2,5),F(1,7),F(3,4)),
               (F(1),F(1),F(0),F(0)))
counts={'zero_box':0,'omission_box':0,'anchored_identity':0,'orthant_order':0}
for raw in profiles:
 f=list(map(F,raw));q=sum(U[i]*f[i] for i in range(8))
 plus=[U[i]*max(f[i]-q,F(0))/q for i in range(8)]
 for weights in weights_cases:
  for mode in range(4):
   om=[[F(1) if mode==0 else (F(0) if mode==1 else
        F((i+2*k+mode)%5,4)) for i in range(8)] for k in range(4)]
   for i,y in enumerate(xs):
    if not plus[i]:continue
    w=[weights[k]*om[k][i]*cap[k][i] for k in range(4)]
    L=sum(w)
    K=[sum(w[k]*cap[k][j] for k in range(4)) for j in range(8)]
    active=[k for k in range(4) if w[k]>0]
    lo=max([F(-1,2)]+[intervals[k][0] for k in active])
    hi=min([F(1,2)]+[intervals[k][1] for k in active])
    for j,z in enumerate(xs):
     assert (K[j]==L)==(lo<=z<=hi)
     counts['zero_box']+=1
    for keep in product((0,1),repeat=4):
     retained=[k for k in active if keep[k]]
     omission=sum(w[k] for k in range(4) if not keep[k])
     blo=max([F(-1,2)]+[intervals[k][0] for k in retained])
     bhi=min([F(1,2)]+[intervals[k][1] for k in retained])
     for j,z in enumerate(xs):
      if blo<=z<=bhi:
       assert K[j]>=L-omission
       counts['omission_box']+=1
    for j,z in enumerate(xs):
     qlo,qhi=min(y,z),max(y,z)
     omission=sum(w[k] for k,(l,r) in enumerate(intervals)
                  if not(l<=qlo and qhi<=r))
     assert omission==L-K[j]
     counts['anchored_identity']+=1
    for j,z in enumerate(xs):
     for k,x in enumerate(xs):
      if (z-y)*(x-y)>=0 and abs(z-y)<=abs(x-y):
       assert K[j]>=K[k]
       counts['orthant_order']+=1
print('PASS',counts,'total',sum(counts.values()))
