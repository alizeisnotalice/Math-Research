#!/usr/bin/env python3
"""R375: frozen R374 source fields; certified larger target capacities."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter,deque
import json,sys,hashlib
BASE=Path(__file__).resolve().parent;COUNTS=Counter()
def ck(k,v):
 COUNTS[k]+=1
 assert v,k
def dot(a,b):return sum((F(x)*y for x,y in zip(a,b)),F(0))
def rat(v):return F(0) if abs(v)<1e-10 else F(str(v)).limit_denominator(10**9)
def read(p):return json.loads((BASE/p).read_text())
def sha(p):return hashlib.sha256((BASE/p).read_bytes()).hexdigest()
def prepare():
 old=read('r374_input.json');cert=read('r374_result.json')
 data=dict(cases=old['cases'],inherited_summary=cert['summary'],inherited_certificates=cert['optimal_transport_certificates'],provenance={p:sha(p) for p in ['r374_input.json','r374_result.json']},scope='Frozen real compact positive-L1 matching sources and full original finite diagnostic marks; finite receiver quadrature, not native hard gates. Capacities 1,2 reuse certified results; only four 2D capacity4/8 LPs are new.')
 (BASE/'r375_numeric_input.json').write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
 print('PREPARED three frozen cases; four new 2D common LPs only')
def solve_equalities(A,b):
 M=[list(map(F,row))+[F(v)] for row,v in zip(A,b)];nr=len(M);nc=len(M[0])-1;i=0;piv=[]
 for j in range(nc):
  k=next((k for k in range(i,nr) if M[k][j]),None)
  if k is None:continue
  M[i],M[k]=M[k],M[i];v=M[i][j];M[i]=[x/v for x in M[i]]
  for k in range(nr):
   if k!=i:
    v=M[k][j]
    if v:M[k]=[x-v*y for x,y in zip(M[k],M[i])]
  piv.append(j);i+=1
  if i==nr:break
 assert all(any(row[:nc]) or row[nc]==0 for row in M),'inconsistent support margin reconstruction'
 x=[F(0)]*nc
 for k,j in enumerate(piv):x[j]=M[k][-1]
 return x

def rational_transport(p,raw,capacity):
 cap2=True
 rows=list(map(F,p['row']));cols=list(map(F,p['col']));cost=[list(map(F,row)) for row in p['cost']];nr=len(rows);nc=len(cols)
 vals=[rat(x) for x in raw['plan']];edges=[(i,j) for i in range(nr) for j in range(nc) if vals[i*nc+j]>0]
 eq=[[int(a==i) for a,b in edges] for i in range(nr)]+[[int(b==j) for a,b in edges] for j in range(nc)]
 vv=[vals[i*nc+j] for i,j in edges];rhs=rows+cols
 if cap2:
  approxcol=[sum(vals[i*nc+j] for i in range(nr)) for j in range(nc)];sat=[j for j in range(nc) if abs(float(approxcol[j]-capacity*cols[j]))<1e-9]
  eq=eq[:nr]+[eq[nr+j] for j in sat];rhs=rows+[capacity*cols[j] for j in sat]
 res=[b-dot(a,vv) for a,b in zip(eq,rhs)];corr=solve_equalities(eq,res);vv=[a+b for a,b in zip(vv,corr)];T=[[F(0)]*nc for i in range(nr)]
 for (i,j),a in zip(edges,vv):T[i][j]=a
 ck('optimal_plan_nonnegative',all(a>=0 for row in T for a in row));colused=[sum(T[i][j] for i in range(nr)) for j in range(nc)]
 ck('expanded_capacity_exact_source_and_column_upper' if cap2 else 'optimal_plan_both_exact_marginals',[sum(row) for row in T]==rows and (all(a<=capacity*b for a,b in zip(colused,cols)) if cap2 else colused==cols))
 # Exact weak-dual certificate from positive support: component offsets solve difference inequalities.
 adj=[[] for _ in range(nr+nc)]
 for i in range(nr):
  for j in range(nc):
   if T[i][j]>0:adj[i].append((nr+j,cost[i][j]));adj[nr+j].append((i,cost[i][j]))
 comp=[None]*(nr+nc);base=[F(0)]*(nr+nc);cc=0
 for start in range(nr+nc):
  if comp[start] is not None:continue
  comp[start]=cc;q=deque([start])
  while q:
   u=q.popleft()
   for v,c in adj[u]:
    if comp[v] is None:comp[v]=cc;base[v]=c-base[u];q.append(v)
    else:ck('dual_tight_support_consistency',base[u]+base[v]==c)
  cc+=1
 constraints=[(comp[i],comp[nr+j],cost[i][j]-base[i]-base[nr+j]) for i in range(nr) for j in range(nc)]
 if cap2:
  root=cc;cc+=1
  for j in range(nc):
   constraints.append((root,comp[nr+j],-base[nr+j])) # beta_j<=0
   if colused[j]<capacity*cols[j]:constraints.append((comp[nr+j],root,base[nr+j])) # slack implies beta_j=0
 offset=[F(0)]*cc
 for _ in range(cc):
  changed=False
  for a,b,c in constraints:
   if offset[a]>offset[b]+c:offset[a]=offset[b]+c;changed=True
  if not changed:break
 ck('dual_component_difference_constraints',all(offset[a]-offset[b]<=c for a,b,c in constraints))
 if cap2:
  anchor=offset[root];offset=[v-anchor for v in offset]
 rp=[base[i]+offset[comp[i]] for i in range(nr)];cp=[base[nr+j]-offset[comp[nr+j]] for j in range(nc)]
 if cap2:ck('expanded_capacity_dual_columns_nonpositive_and_slack_complementary',all(b<=0 for b in cp) and all(b==0 or u==capacity*c for b,u,c in zip(cp,colused,cols)))
 ck('exact_transport_dual_all_cell_pairs',all(rp[i]+cp[j]<=cost[i][j] for i in range(nr) for j in range(nc)))
 primal=sum(T[i][j]*cost[i][j] for i in range(nr) for j in range(nc));dual=dot(rows,rp)+dot([capacity*c for c in cols] if cap2 else cols,cp);ck('expanded_capacity_exact_primal_dual_zero_gap' if cap2 else 'exact_transport_primal_dual_zero_gap',primal==dual)
 return primal,dict(v=p['v'],capacity=capacity,plan=[list(map(str,row)) for row in T],row_potential=list(map(str,rp)),column_potential=list(map(str,cp)),value=str(primal),margin_repair_nonzero=any(corr),exitflag=raw['exitflag'])
def check_stored(p,cert,cap):
 T=[list(map(F,row)) for row in cert['plan']];rows=list(map(F,p['row']));cols=list(map(F,p['col']));C=[list(map(F,row)) for row in p['cost']];nr=len(rows);nc=len(cols);rp=list(map(F,cert['row_potential']));cp=list(map(F,cert['column_potential']));used=[sum(T[i][j] for i in range(nr)) for j in range(nc)]
 ck('reused_plan_nonnegative_and_source_exact',all(a>=0 for row in T for a in row) and [sum(row) for row in T]==rows)
 ck('reused_plan_target_capacity',all(a<=cap*b for a,b in zip(used,cols)))
 ck('reused_exact_dual_all_pairs',all(rp[i]+cp[j]<=C[i][j] for i in range(nr) for j in range(nc)) and (cap==1 or all(b<=0 for b in cp)))
 val=sum(T[i][j]*C[i][j] for i in range(nr) for j in range(nc));lower=dot(rows,rp)+dot([cap*b for b in cols],cp);ck('reused_exact_zero_gap',val==lower==F(cert['value']))
 return val

def fullmarks(c):
 n=c['n'];N=len(c['receivers']);A=c['A'];vol=list(map(F,c['volumes']));x=list(map(F,c['source_mass']));f=[a/b for a,b in zip(x,vol)];R=[F(r['R']) for r in c['receivers']];w=[F(r['weight']) for r in c['receivers']];centers=[list(map(F,r['center'])) for r in c['receivers']];m=[r**n for r in R];mu=[a/b for a,b in zip(w,m)];radii=sorted(set(R));h=F(c['h']);H=F(c['H']);kap=F(c['kappa']);omega=[list(map(F,row)) for row in c['omega']]
 ck('stage2_full_source_same_all_actual_matching',all(dot(row,x)==mass for row,mass in zip(A,m)) and sum(x)==F(c['actual_W']))
 expected=[[F(0)]*len(x) for _ in range(N)]
 for u in range(N):
  for y in range(len(x)):
   past=sum(mu[t]*A[t][y] for t in range(N) if m[t]<m[u]/kap)
   if past<=h:continue
   for l,r in enumerate(radii):
    if r<R[u]:continue
    J=sum(mu[t]*A[t][y] for t in range(N) if R[t]<=r)
    if J>=H:
     ell=r**(-n)-(radii[l+1]**(-n) if l+1<len(radii) else 0)
     expected[u][y]+=h*m[u]*ell/J
 ck('stage2_reconstructed_full_omega_J_past_clock',expected==omega)
 for p in c['plans']:
  v=p['v'];src=p['source_cells'];tgt=p['target_cells'];d=F(p['d']);rows=list(map(F,p['row']));cols=list(map(F,p['col']));K=[list(map(F,row)) for row in p['K']];L=list(map(F,p['L']));C=[list(map(F,row)) for row in p['cost']]
  ck('stage2_original_source_and_uniform_target_marginals',rows==[vol[y]*(f[y]-1)/m[v] for y in src] and cols==[d*vol[z]/m[v] for z in tgt] and sum(rows)==sum(cols)==d)
  Lv=[];Kv=[]
  for y in src:
   aa=[]
   for u in range(N):
    S=m[u]>kap*m[v] and 2*max(abs(a-b) for a,b in zip(centers[u],centers[v]))>R[u]
    aa.append(mu[u]*(1-m[v]/m[u])/h*omega[u][y]*A[u][y] if S else F(0))
   Lv.append(sum(aa));Kv.append([sum(aa[u]*A[u][z] for u in range(N)) for z in tgt])
  ck('stage2_one_common_objective_all_u_and_original_marks',Lv==L and Kv==K and C==[[L[i]-a for a in row] for i,row in enumerate(K)])
 return True

def rowwise_optimum(p,capacity):
 rows=list(map(F,p['row']));U=list(map(F,p['U']));C=[list(map(F,row)) for row in p['cost']];nr=len(rows);nc=len(U);T=[];total=F(0);thresholds=[];rowvalues=[]
 for i,r in enumerate(rows):
  caps=[capacity*r*u for u in U];plan=[F(0)]*nc;left=r;theta=None
  for j in sorted(range(nc),key=lambda j:(C[i][j],j)):
   take=min(left,caps[j]);plan[j]=take;left-=take
   if take:theta=C[i][j]
   if not left:break
  ck('rowcap_greedy_exact_source_and_pointwise_caps',left==0 and sum(plan)==r and all(0<=a<=b for a,b in zip(plan,caps)))
  beta=[min(cost-theta,F(0)) for cost in C[i]]
  ck('rowcap_threshold_dual_feasible',all(b<=0 and theta+b<=cost for b,cost in zip(beta,C[i])))
  value=dot(C[i],plan);dual=r*theta+dot(caps,beta)
  ck('rowcap_exact_primal_dual_zero_gap',value==dual)
  total+=value;T.append(plan);thresholds.append(str(theta));rowvalues.append(str(value))
 d=F(p['d']);ck('rowcap_implies_shared_target_cap',all(sum(T[i][j] for i in range(nr))<=capacity*d*U[j] for j in range(nc)))
 return total,dict(v=p['v'],capacity=capacity,value=str(total),row_thresholds=thresholds,row_values=rowvalues,plan_rule='Fill increasing (exact cost,target index), splitting the threshold cell as needed; input marginals determine all amounts.')

def verify():
 data=read('r375_numeric_input.json');raw=read('r375_numeric_output.json')['plans'];raw=[raw] if isinstance(raw,dict) else raw;lookup={(p['name'],p['v'],p['capacity']):p for p in raw};inherited={(p['name'],p['v'],p['mode']):p for p in data['inherited_certificates']};certs=[];summ=[];rowcerts=[]
 ck('only_four_new_2d_lps',len(raw)==4)
 for c,oldsum in zip(data['cases'],data['inherited_summary']):
  fullmarks(c);G=F(c['original_diagonal']);floor=F(c['floor']);S=F(c['surplus_diagonal']);vals={cap:F(0) for cap in [1,2,4,8]};rowvals={cap:F(0) for cap in [1,2,4,8]}
  for p in c['plans']:
   for cap in [1,2,4,8]:
    rowval,rowcert=rowwise_optimum(p,cap);rowcert['name']=c['name'];rowcerts.append(rowcert);rowvals[cap]+=F(p['weight'])*rowval
   if not p['nonzero_cost']:continue
   wv=F(p['weight']);val1=check_stored(p,inherited[(c['name'],p['v'],'fixed')],1);val2=check_stored(p,inherited[(c['name'],p['v'],'cap2')],2);vals[1]+=wv*val1;vals[2]+=wv*val2
   for cap in [4,8]:
    if c['n']==2:
     val,cert=rational_transport(p,lookup[(c['name'],p['v'],cap)],cap);cert['name']=c['name'];certs.append(cert)
    else:
     oldcert=inherited[(c['name'],p['v'],'cap2')];T=[list(map(F,row)) for row in oldcert['plan']];rows=list(map(F,p['row']));cols=list(map(F,p['col']));C=[list(map(F,row)) for row in p['cost']];nr=len(rows);nc=len(cols)
     ck('stage3_1d_zero_plan_still_feasible_at_larger_cap',all(sum(T[i][j] for i in range(nr))<=cap*cols[j] for j in range(nc)) and all(sum(T[i][j] for j in range(nc))==rows[i] for i in range(nr)))
     val=sum(T[i][j]*C[i][j] for i in range(nr) for j in range(nc));ck('stage3_1d_zero_lower_bound_matches_reused_plan',val==0 and all(a>=0 for row in C for a in row))
    vals[cap]+=wv*val
  ck('stage1_inherited_aggregate_same',vals[1]==F(oldsum['optimal_common_bad']) and vals[2]==F(oldsum['cap2_optimal_bad']))
  ck('stage3_capacity_monotonicity',vals[1]>=vals[2]>=vals[4]>=vals[8]>=0)
  ck('rowcap_product_at_one',rowvals[1]==F(oldsum['product_Gjoint']))
  ck('rowcap_stronger_than_shared_cap_every_capacity',all(rowvals[cap]>=vals[cap] for cap in [1,2,4,8]))
  capacities=[]
  for cap,val in vals.items():
   paid=S-val;template=floor+paid;ck('stage3_actual_template_positive_account',paid>=0 and G==template+val and 0<=rowvals[cap]<=S and G==floor+(S-rowvals[cap])+rowvals[cap])
   capacities.append(dict(capacity=cap,optimal_bad=str(val),bad_fraction_of_G=str(val/G),rowwise_cap_optimal_bad=str(rowvals[cap]),rowwise_bad_fraction_of_G=str(rowvals[cap]/G),rowwise_actual_floor_plus_good=str(G-rowvals[cap]),shared_extra_gain_over_rowwise=str(rowvals[cap]-val),actual_floor=str(floor),actual_good=str(paid),actual_floor_plus_good=str(template),actual_template_fraction_of_G=str(template/G),provenance='R374 exact certificates reused' if cap<=2 else ('new 2D exact LP certificate' if c['n']==2 else 'zero cap2 plan reused, zero dual lower bound')))
  summ.append(dict(name=c['name'],n=c['n'],actual_source_W=c['actual_W'],original_diagonal=str(G),floor=str(floor),capacities=capacities))
 out=dict(status='PASS',exact_grouped_checks=sum(COUNTS.values()),check_counts=dict(COUNTS),summary=summ,new_exact_certificates=certs,rowwise_exact_threshold_certificates=rowcerts,provenance=data['provenance'],scope=data['scope'])
 (BASE/'r375_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['new_exact_certificates','rowwise_exact_threshold_certificates']},sort_keys=True,indent=2))
if __name__=='__main__':prepare() if len(sys.argv)>1 and sys.argv[1]=='prepare' else verify()
