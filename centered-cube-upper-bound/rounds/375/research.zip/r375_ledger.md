# R375 完整账与容量选择

保留 R374 同一完整 f、真实 Lebesgue 接收 E、边长选择器、m/q、J、strictpast、far/outside/notBplus 门和完整物理时钟。所有改变均只涉及同一 v 的共同来源耦合，不能按 u 独立选择。

设 t≥1 预先固定，τ_v 的来源边缘为 d_v P_v，目标边缘≤t d_v U_v。对任何已构造的这样的可测共同计划，定义真实非负剩余
\[
R_t=\int_E\int (L_v(y)-K_v(y,z))\,d\tau_v(y,z)\,dv.
\]
R375 capacity 中逐行分位数计划给出一个无条件可测可行构造，但它不是整个目标容量类的最优解。更好的共同计划可代入同一账。

原 floor 与新 captured-good 联合上界为
\[
\min(p,1-d)+\min(d,tdp)\le E_t(p)
=p+(1-p)\min(1,tp)=\min(1,(t+1)p-tp^2)\le(t+1)p.
\]
所以新模板费为 (t+1)Γ_n，替换 R374 的 3Γ_n；不能重复保留旧 floor/credit。
\[
B_H(f,\nu)\le R_t+\varepsilon_0[2+(C_n^++(t+1)\Gamma_n)/(1+\sqrt n)]X_q+C_{338}W.
\]
原 C_n^+<72,Γ_n 与 C338 的定义完全沿用 R374。给定本槽系数 η，预先设
\[
\mathcal L_{n,t}=2+\frac{72+(t+1)\Gamma_n}{1+\sqrt n},\quad
\varepsilon_0=\eta/\mathcal L_{n,t},\quad
h=\frac{(1+\sqrt n)\mathcal L_{n,t}}{\eta q_-},
\]
\[
C_{338}=\frac\lambda{q_-}\{(2+3\sqrt n+2e^{-\sqrt n})/\varepsilon_0+1+\sqrt n\}.
\]
于是来源费 O_η((t+1)√(n log(n+2)))W。固定或固定幂次对数 t 兼容根阶多对数目标，但仅在 R_t 得到相应真实预算后才有意义。h 相关门和 ω 必须同步；不同 t 重新选参数后的余项不可直接比较。

入口保持
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H+2R_t
+2\varepsilon_0[2+(C_n^++(t+1)\Gamma_n)/(1+\sqrt n)]X_q+2C_{338}W,
\]
其中 A_n=1+n log(b/a)，整式再乘 Λ=128/119。本硬槽系数至多2Λη，不声称其他槽总和可吸收。

同一冻结场下 t=2 的逐行最优计划不劣于 R374 tilt，费用完全同为3Γ。这是同费用的实际估计改进。t>2 的净改善必须与新增模板费一起比较：若两计划的剩余差至少 ε0(t−2)Γ X_q/(1+√n)，粗账新右端才不更大；它是充分条件，非统一已证性质。

未付：R_t 的一般根阶预算；真实共同目标容量的跨来源分配；原入口/soft/crossing接口；合同外重尾、宽距离、低pe、极端尺度比及阈值补集；初始/删除/未来被删来源的历史时间原子；H优化、全尺度聚合、外积分、截断与极限。物理末端原子不代替历史时间原子。有限cap4零余项不能消去上述任何槽。

同cap2的共享近捕获盒计划见geometry：(13)源边缘保持，目标min(j,1)+δ≤2；(15)保留真实紧补流β(L−r)。可用其实际R^box或rowcap G2在每个v整计划择优后代入t=2上式，仍是3Γ，不能按来源y混选。省略损失与来源加权拥挤均未付，不能只保留其有利截流而丢失补回。
