# R360: shared boundary coordinates have a small actual kernel

**Proved addition.** In the proposed R360 process with BOTH endpoint high-face gates, the shell-to-shell common-source kernel splits into a shared-coordinate part B and a disjoint-coordinate part D. With p=min(n,m-1), the former satisfies

    ||B||_(L2(sigma)->L2(sigma)) <= r_p
       :=min(1,Lambda_p(alpha)/w),
    Lambda_p(alpha)=1-alpha^p+[n-(n-p)alpha^p]log(b/a).       (0.1)

For the actual shrink and m=1+ceil(8log(n+2)), this is O(log^2(n+2)/sqrt(n)). There is no binomial or 2^p combination fee. This is a positive global estimate for actual receiver Lebesgue measure and full f. It does not estimate the remaining disjoint-coordinate kernel D, so it does not close the root bound.

The new high-face stopping payment 2N C_m W is assumed to be established separately by the parent's audit. This note neither proves nor adds that payment. Its estimate applies exactly when the continued edge really has both endpoint face counts below m. Origin-only low-face gating does NOT imply the target condition after source resampling.

## 1. Actual labelled process and the event being bounded

Keep all notation and the actual original late injection from R359_potential. In particular

    sigma(du)=q_u du,  pi_u(dz)=f(z)c_u(z)dz/m_u,
    xi_z(du)=c_u(z)R_u^(-n)du,
    sigma(du)pi_u(dz)=f(z)dz xi_z(du),
    Qbar_z(u,dv)=k_z(u,v)xi_z(dv),  0<=k_z(u,v)<=1/w,
    w=1+sqrt(n)-log(4/3),
    k_z(u,v)=0 unless m_v>exp(sqrt(n))m_u.

The original atom-safe rank window, full f, clocks and histories remain fixed. Write alpha for the spatial shrink, and for z in Q_u set

    F_z(u)={j: 2|u_j-z_j|>alpha R_u},
    d(z,u)=|F_z(u)|.

Boundary conventions may be consistently replaced by half-open ones; the center envelopes below remain valid with non-strict inequalities. Use 0<alpha<1; alpha=1 has no shell-to-shell part and can be handled as zero directly.

For the rebuilt process, all states counted in G=g sigma are nonrich, I=i sigma is its actual entrance, and G=I+GK. Let T(du,dz,dv) be the sum of actual continued source-labelled traffic. As in R359, disintegration with respect to G gives

    T <= G(du)pi_u(dz)Qbar_z(u,dv),                         (1.1)

with its actual source, history, and both endpoint high-face gates retained. Set all resulting kernels to zero on {g=0}. Origins of continued edges obey 1<=d(z,u)<=p. Split target-inner traffic as C. On the remaining target-shell traffic S, the additional genuine target gate gives 1<=d(z,v)<=p.

Partition S into the actual positive subkernels

    B: F_z(u) intersect F_z(v) is nonempty,
    D: F_z(u) intersect F_z(v) is empty.

Thus K=C+B+D. This partition is made before forgetting the actual common-source mark. It imposes no directional dispersion or future-terminal property on g.

## 2. Exact center capacity for any specified coordinate union

For a fixed source z and a fixed coordinate set A of cardinality k, define

    V_A(z)=integral_E R_v^(-n)1_{z in Q_v}
                1_{exists j in A: 2|v_j-z_j|>alpha R_v}dv.

Then, uniformly in the measurable actual radius assignment R_v in [a,b],

    V_A(z)<=Lambda_k(alpha)
      :=1-alpha^k+[n-(n-k)alpha^k]log(b/a).                 (2.1)

Proof. Put x=v-z and t=2||x||_infinity. The smallest geometrically allowable radius is r0=max(a,t). If the actual radius R_v realizes the event, then t<=b, R_v>=r0, and some j in A satisfies 2|x_j|>alpha r0. Hence the integrand is bounded by

    r0^(-n)1_{t<=b}1_{max_(j in A)2|x_j|>alpha r0}.

For t<=a, the domain is the centered cube of side a with the simultaneous coordinate core |2x_j|<=alpha a, j in A removed. Its volume is a^n(1-alpha^k), giving the first term of (2.1).

For a<t<=b, decompose into the 2n faces on which a signed coordinate realizes t. Ties have Lebesgue measure zero. If the maximal coordinate lies in A (fraction k/n of these radial faces), the event is automatic. If it does not (fraction (n-k)/n), the remaining A coordinates are uniform box coordinates in [-t/2,t/2], and the event occupies fraction 1-alpha^k. Thus the angular fraction is exactly

    k/n + (n-k)(1-alpha^k)/n
      =1-(n-k)alpha^k/n.

The full max-radial shell has volume derivative n t^(n-1)dt. Multiplying by t^(-n) and integrating from a to b gives the second term in (2.1).

This is a Lebesgue-center envelope and never bounds f by shell volume. It uses no optimizer for R_v.

In particular, with

    L_alpha=(1-alpha)+[1+(n-1)(1-alpha)]log(b/a),

this L_alpha is exactly R356_geometry's B_1(alpha), since 1+(n-1)(1-alpha)=n(1-alpha)+alpha. The argument above reproves its actual-center envelope and extends it to a specified coordinate union. One has

    Lambda_k<=k L_alpha.                                  (2.2)

This follows either from the union bound on the k coordinate events, or from 1-alpha^k<=k(1-alpha). A specified SINGLE signed-coordinate face has exactly half this envelope by reflection; the bound is L_alpha/2. The union of positive and negative target signs gives L_alpha. No independence across receiver events is asserted.

## 3. Both kernel sides retain the same small coefficient

For a fixed origin u and sampled source z, its actual face set F_z(u) has at most p coordinates. Apply (2.1) with A=F_z(u). Dropping positive history gates and the strict mass/rank support only to form an upper envelope, (1.1) yields

    B1(u)
      <= (1/w)integral pi_u(dz)
             integral xi_z(dv)1_{F_z(u) intersects F_z(v)}
      <= Lambda_p/w.                                     (3.1)

The source restriction d(z,u)<=p is retained in the first line; outside it the actual contribution is zero. The last step uses the actual full-f pi_u as a probability. Monotonicity in k follows directly from the underlying coordinate-union envelope.

For the column bound, use the true incidence identity before integrating origins. At a fixed target v and source z, its actual face set has at most p coordinates, so apply (2.1) with A=F_z(v). This gives the density estimate

    d(sigma B)/d sigma(v)
      <= (1/m_v)integral f(z)c_v(z)
                  [(1/w)integral xi_z(du)
                       1_{F_z(u) intersects F_z(v)}]dz
      <= Lambda_p/w.                                     (3.2)

Here both endpoint low-face gates and common-source capture are retained until their corresponding capacity step. The last matched-mass equality is integral f c_v=m_v. It is not an independent copy of W. Since also B<=K<=Pbar, native row and column bounds are at most one. Row Cauchy--Schwarz therefore proves (0.1).

The geometric event is symmetric in its endpoints, but the actual kernel is not: it still has strict forward mass growth. We did not symmetrize the actual kernel or claim that k is constant. In particular no unjustified factor 1/2 is inserted in (3.1) or (3.2).

All coordinate-combination costs are accounted for by Lambda_p, or more coarsely by p L_alpha. There is no summation over all subsets of size p: at each source/origin pair its already realized face set supplies ONE test set A. For (3.2), the already realized target face set supplies ONE test set. Choosing all signs independently would unnecessarily introduce 2^p; (2.1) includes both signs exactly.

## 4. Dimension scale and an explicitly priced elimination

For the R355 shrink d=alpha^n=min(1,s/(N A_n)), s=1+sqrt(n), A_n=1+n log(b/a), the established N A_n/s<=3n gives d>=1/(3n). Thus

    1-alpha <= log(3n)/n,
    L_alpha <= log(3n)/n+[1+log(3n)]log 2,
    p<=8log(n+2)+1,
    r_p <= min(1, (8log(n+2)+1)
              *{log(3n)/n+[1+log(3n)]log 2}/w).            (4.1)

The exact displayed constants prove the claimed O(log^2(n+2)/sqrt(n)). For moderate n this upper bound can exceed one; only the native bound r_p<=1 is then available. Smallness is not asserted for all n.

A completely explicit universal threshold is n>=2^32, on which r_p<=1/8. Here is a proof using only the weaker d>=1/(3n), rather than needing the sharper nonempty-branch shrink estimate. Put L=log n. Then L>=16 (log 2>1/2), log 3<11/10, log 2<7/10, and (L+11/10)/n<=1. Consequently

    L_alpha<=1+(7/10)(1+L+11/10)
           =(7/10)L+247/100<=L,
    p<=8log(n+2)+1<=8L+9<=9L,
    Lambda_p/w<=9 L^2 exp(-L/2).

The last function is decreasing for L>=4, because its logarithmic derivative is 2/L-1/2. At n0=2^32, log n0<32*(7/10)=112/5, and sqrt(n0)=2^16. Therefore, exactly,

    r_p<=9(112/5)^2/65536=441/6400=0.06890625<1/8.         (4.1a)

The fraction in (4.1a) was checked with Fraction arithmetic. Since c_*<=1/2, for these dimensions c_*+r_p<=5/8 and the resolvent constant in (4.3) below is at most 8/3.

For n<2^32, the already available crude terminal estimate Fbar_low<=N Delta W, N<=3sqrt(n), Delta<=4sqrt(n), gives

    Fbar_low<=12n W<=786432 sqrt(n)W.                      (4.1b)

This is a finite absolute-constant treatment of this residual in the bounded-dimensional range. It does not assert B contraction there, and it does not settle the disjoint-coordinate residual for unbounded n or any other unpaid ledger slot.

The target-inner component retains R359's

    ||C||<=c_*:=sqrt(theta min(1,d A_n/w)), theta=1/4.

Put A=C+B. Then ||A||<=c_*+r_p. Whenever the explicit condition

    eta:=1-c_*-r_p>0                                      (4.2)

holds, its actual aggregate resolvent R_A=(Id-A)^(-1) exists on L2 and has norm at most eta^(-1). From the ACTUAL balance,

    g=i+A^*g+D^*g,
    J=<i,R_A^*i>+<g,D R_A i>
      <=eta^(-1)||i||_2^2+<g,D a>, a=R_A i,
    ||a||_2<=eta^(-1)||i||_2.                              (4.3)

Thus all target-inner and shared-coordinate excursions have an explicit receiver-energy price eta^(-1)Xq. This is algebraic elimination of actual aggregate sectors; it does not create new routes or erase source resets. It is not a pointwise bound on a. The remaining mixed term has the exact positive geometric envelope

    <g,D a>
      <=(1/w)integral f(z)dz integral xi_z(du)xi_z(dv)
          g(u)a(v)1_{1<=d(z,u),d(z,v)<=p}
          1_{F_z(u) intersects F_z(v) is empty}
          1_{m_v>exp(sqrt(n))m_u}.                         (4.4)

One may keep the actual k and gates instead for a sharper version; (4.4) displays the residual support that is now genuinely available. This is different from merely relabelling S: the shared-coordinate sector has already been bounded at a quantitative small operator cost in (3.1)--(4.3).

If the remaining actual mixed term is bounded by B0 Xq, then

    J<=(eta^(-1)+B0)Xq,
    Fbar_low<=epsilon Xq+
       b_*(eta^(-1)+B0)W/(2epsilon), b_*=(D0+Delta)/2.      (4.5)

The R360 native selected terminal cap and energy identity are the ones to use here. No estimate of B0 is proved in this note. In particular stopping all B-edges and charging their total traffic directly would introduce an unproved occupation bound; we do NOT make that charge. Existing high-face source payments remain separate and are not spent a second time.

## 5. Local computation actually run

Standard-library Python Fraction arithmetic verified 5,580 exact coefficient identities/inequalities for n=1,...,30, alpha in {1/2,3/4,15/16,99/100}, and k=1,...,n:

```python
from fractions import Fraction as F
count=0
for n in range(1,31):
    for alpha in [F(1,2),F(3,4),F(15,16),F(99,100)]:
        for k in range(1,n+1):
            inner=1-alpha**k
            angular=1-F(n-k,n)*alpha**k
            face_sum=F(k,n)+F(n-k,n)*(1-alpha**k)
            assert angular==face_sum
            assert inner<=k*(1-alpha)
            assert n*angular<=k*(1+(n-1)*(1-alpha))
            count+=3
print(count, 'PASS')
endpoint=F(9)*(F(32)*F(7,10))**2/F(2**16)
assert endpoint==F(441,6400)<F(1,8)
assert 1/(1-F(1,2)-F(1,8))==F(8,3)
```

This checks algebra in the center-envelope proof; it is not a replacement for that proof or a simulation of the original process. Floating evaluation of the exact envelope using the conservative alpha=(3n)^(-1/n), b/a=2 gave Lambda_p/w approximately 8.4874 at n=1024, 3.1414 at n=65536, 0.4247 at n=2^24, and 0.04571 at n=2^32. Values above one are truncated by native capacity; these numbers are only illustrative and are not certified threshold claims.

## 6. Next decision supported by the result

Provided the audited process has BOTH common-source endpoint high-face gates, shared boundary coordinates admit the explicit elimination (4.3) whenever (4.2) is satisfied. Further geometry may therefore concentrate on edges whose sparse boundary coordinate sets are disjoint. No terminal directional-uniformity hypothesis is imported into this residual. Its original matched masses and actual rank window may still be crucial; they were retained in the process, even where discarded in positive upper estimates.

The root budget for the whole process remains open. This note adds the unconditional kernel estimate (0.1), the full coordinate-combination calculation, and the conditional but explicitly priced sector elimination. It does not claim a new unconditional terminal payment beyond the separately audited high-face stops.
