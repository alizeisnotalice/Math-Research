# R360 — Pay high face counts at both ends of actual continuation

## 1. Statement and the new original-B_H ledger

Start from the ORIGINAL crossing entrance rebuilt with Qbar in R359, not from its already selected terminal Fbar_low. Freeze the same full f, actual receiver measure du, m_u=integral f c_u=q_uR_u^n, q_-<=q_u<=lambda, a<=R_u<=b<=2a, original g_ex, J, eta Omega and physical ell including its endpoint atom. Let

    x=sqrt(n), s=1+x, K=exp(x), A_n=1+n log(b/a),
    N=max(1,ceil(log[(lambda/q_-)(b/a)^n]/x)),
    alpha^n=min(1,s/(N A_n)), theta=1/4,
    L_n=log(n+2), m=1+ceil(8L_n), t=1-alpha,
    d(z,u)=#{i:|u_i-z_i|>alpha R_u/2} for z in Q_u.

Here alpha is the same spatial shrink scalar as R355/R359, not the original row mask. Set

    C_m=P{Bin(n,t)>=m}+n log(b/a)P{Bin(n-1,t)>=m-1},
    C_path,n=2N C_m,
    B_1=(1-alpha)+[n(1-alpha)+alpha]log(b/a),
    C_dir,n=N B_1 L_n.                                      (1)

The binomial tails are real CENTER-VOLUME coefficients, not probabilities for source coordinates. Tails beyond the number of trials are zero. Rebuilding the process below gives the SAME original B_H the bound

    B_H <= F_low^(360)
       +[(13/3)epsilon+gamma_eff+beta+alpha_rec+c_eff]X_q
       +[C_epsilon,n+8s+C_dir,n+C_path,n]W
       +(D_top,n+C_hit,n+s)W_ex.                            (2)

All old constants retain their R359 definitions. In particular beta=epsilon/16, epsilon=119/3072, and no new X_q fee is used. The old terminal C_multi,n=4N C_m is NOT charged in (2). The new current/target stops together cost at most 2N C_m W, and already eliminate high-face NORMAL terminals. The new remainder is a different marked measure; it is not equated with or assumed smaller than R359 Fbar_low.

Every actual continued edge (u,z,v) of the new process has

    1<=d(z,u)<m,  0<=d(z,v)<m.                              (3)

On its shell-to-shell component both counts are between 1 and m-1. After the terminal direction-source split, every positive final terminal source column satisfies the stronger, unrenormalized threshold

    L_(i,low)^(360)(z)<L_low^(360)(z)/L_n.                   (4)

There is no later high-face terminal deletion requiring the previous factor 4/3. Neither (3) nor (4) gives a general bound for F_low^(360).

## 2. Entrance and all original labels remain fixed

Use the newly extended R359 pre-witness original late measure and its original probability insertion Qbar_y(u_old,dw_0). Retain the full old marks (y_old,v_old,u_old,r_old,w_0), all history/rank marks, and all original full-field gates. Its peeling, initial clock-near and initial old-source-inner splits are as in R359; denote the remaining crossing measure by Rbar. Their proofs precede the path process and are unchanged. In particular its receiver marginal I<=q dw, |Rbar|<=X_q, and every entrance tuple satisfies

    m_(w_0)>K m_(u_old)>K^2 m_(v_old),
    r_old<sigma_353 R_(w_0), y_old notin sigma_353 Q_(w_0),
    sigma_353^n=min(1,s/A_n).

The new face tests below apply to fresh source draws AFTER w_0, not retrospectively to the old source or to its original witness edge. Old time and old J never migrate to later receivers. The initial w_0 still belongs to the full-field peeling core, but later receivers need not.

Keep the COMPLETE averaged rank kernel Qbar_z, averaging shifts in (D0,Delta), where D0=1+x+log(4/3), Delta=2s and w=Delta-D0. Its contract is

    xi_z(du)=q_uc_u(z)du/m_u,
    xi_z Qbar_z<=xi_z,
    Qbar_z(u,E)<=1, and surviving edges m_v>K m_u,
    pi_u(dz)=f(z)c_u(z)dz/m_u,
    Pbar(u,dv)=integral pi_u(dz)Qbar_z(u,dv),
    sigma(du)=q_u du,  sigma Pbar<=sigma.                    (5)

No old positive-row qualification is assigned to a new source. The missing rank probability remains a genuine terminal event.

## 3. The exact new chronological order

At each actual current receiver u=w_j, with all previous marks retained:

1. If pi_u(alpha Q_u)>=theta, stop as first rich visit.
2. Otherwise draw z_j from the UNCHANGED full-f pi_u.
3. If z_j belongs to alpha Q_u, stop as first inner-source visit.
4. If d(z_j,u)>=m, stop as first current-source high-face visit.
5. If z_j belongs to Q_(v_old) union Q_(u_old) union union_(i<j)Q_(w_i), stop as first ancestor recapture.
6. Apply Qbar_(z_j)(u,dv), keeping its actual shift/rank marks. Missing mass stops normally.
7. On a successful target v, if d(z_j,v)>=m, stop as first target-source high-face visit. Otherwise v becomes w_(j+1).

A target high-face stop occurs BEFORE the next target rich test, even if that target would have been rich. It is counted only in step 7. The current high-face stop precedes ancestor recapture; an overlapping event is counted only in step 4. No probability is conditioned on passing later tests or renormalized after any test.

Every surviving jump has strict mass increase K. Thus there are at most N visits and no N-edge surviving path. The last termination, if reached, is actual missing-rank termination; no artificial horizon stop is introduced. Since all new gates are positive restrictions of (5), the actual arrival density at every generation obeys kappa_j<=q.

Let B_joint denote rich plus inner-source stops, B_cur the new current stops, B_rec ancestor stops, B_tar new target stops, and F_term normal rank terminals after these tests. They give the exact positive partition

    |Rbar|=B_joint+B_cur+B_rec+B_tar+F_term.                  (6)

No R359 terminal direction or high-face threshold is reused inside this process.

## 4. Source-consistent payment of both high-face stops

The R357 real-center bound, at the SAME alpha and m, is

    integral_E c_u(z)1_{d(z,u)>=m}R_u^(-n)du<=C_m             (7)

for every fixed z, up to the standard harmless null versions. It follows by separating the central cube and radial center shells; the coefficients are exactly those in (1). No density bound on f is involved.

At generation j, before the current source tests, the true joint draw is dominated by

    kappa_j(u)du pi_u(dz)<=f(z)dz xi_z(du).

Dropping earlier positive restrictions in the current-stop bound and using (7) gives

    B_cur,j<=integral f(z)integral xi_z(du)1_{d(z,u)>=m}dz
             <=C_m W.                                      (8)

For the target stop, retain the SAME actual sampled z through Qbar. The joint successful source-target measure, after all prior history/current/ancestor restrictions, is bounded by

    f(z)dz integral xi_z(du)Qbar_z(u,dv)
        <=f(z)dz xi_z(dv).                                  (9)

Now apply (7) at v. This proves B_tar,j<=C_m W. A receiver-only arrival bound would not justify (9); the sourcewise column is essential. At most N generations contribute, hence the two disjoint stop types obey

    B_cur+B_tar<=2N C_m W=C_path,n W.                       (10)

There are actually at most N-1 successful-edge generations, but the safe common 2N coefficient is kept. No independent selection of coordinates or face subsets is made; (7) already includes their complete combinatorial cost.

On the unchanged nonempty original high-past branch, N<=sqrt(n) and the old geometric tail bound C_m<=A_n/(n+2)^4 remain applicable. Therefore

    C_path,n<=2sqrt(n)A_n/(n+2)^4<=2sqrt(n).                  (11)

If m>n the two stop events are empty and C_m=0. If alpha=1, the rich stop ends every arrival before these tests and F_term=0. Necessary-original-high-past failure makes the entire original late branch empty, as before.

## 5. Existing rich, inner and recapture fees are used once

The new gates only delete probability. At each still-live visit, the rich and inner conditional combined stop probability is exactly

    1_{p>=theta}+p1_{p<theta}<=p/theta,
    p=pi_u(alpha Q_u).

Their actual joint price is therefore still

    B_joint<=N alpha^n A_n W/theta<=4sW.                     (12)

A draw at a current nonrich receiver is the full pi_u before source tests. The ancestor union has posterior at most the sum of the masses of all earlier receivers divided by m_u, which is strictly less than 1/(K-1). Preceding inner and current-high-face tests only restrict this event; they do not change the conditional law used to bound its unconditioned probability. Thus

    B_rec<=[N/(K-1)]|Rbar|<=alpha_rec X_q.                   (13)

A target high-face stop may remove paths before any later rich/recapture event; it adds no copy of either old fee. The new process, rather than the old residual, is used to obtain (6),(12),(13).

All visits in F_term pass the current rich test, so their full posterior shell mass exceeds 3/4. All actual sampled sources on those paths lie in the current shell, have current face count below m, and avoid earlier ancestor cubes. Successful edges retained on those paths also have target face count below m. A target source may be INNER at its target; its face count is then zero. No target-inner event has been prohibited or incorrectly charged.

## 6. Recompute terminal columns; no terminal-high-face payment remains

The generation-j NORMAL-terminal joint marginal has the genuine representation

    dT_j(z,u)=f(z)c_u(z)k_j(z,u)dz du/m_u,
    0<=k_j(z,u)<=kappa_j(u)<=q_u.                            (14)

Here k_j includes the earlier chronological tests and the native missing Qbar probability. Every tuple in (14) already satisfies 1<=d(z,u)<m because steps 3–4 occur before rank termination. The high-face terminal density H is therefore identically zero; there is no R357 H/L source split to perform and no C_multi fee.

Define NEW terminal source densities from (14):

    L(z)=sum_(j<N)integral c_u(z)k_j(z,u)du/m_u,
    L_i(z)=sum_(j<N)integral c_u(z)k_j(z,u)
                             1_{|u_i-z_i|>alpha R_u/2}du/m_u.

Then F_term=integral f L, 0<=L_i<=L<=sum_i L_i, and by the same real one-face envelope L_i<=N B_1. Define from THIS new flow

    S_dir={z:L(z)>0,max_i L_i(z)>=L(z)/L_n}.

The exact remaining split is

    F_term=F_dir+F_low^(360),
    F_dir=integral_(S_dir)f L<=C_dir,n W.                    (15)

On its complement, all positive columns satisfy L_i<L/L_n. Restricting by a WHOLE source set leaves these within-source ratios unchanged. There is no subsequent tuple deletion, so (4) follows without a 4/3 loss. These ratios remain terminal-source conditional statements, not whole-path or full-posterior statements. The high-face exclusion on each continuation instead follows causally from steps 4 and 7.

## 7. Exact substitution into the original fee chain

The complete reconstruction of the ORIGINAL G_late is

    G_late=Gbar_del+Gbar_clock+Gbar_inner
             +B_joint+B_cur+B_rec+B_tar+F_dir+F_low^(360).     (16)

The first three are the R359 new-witness pieces, still priced by
beta X_q+4sW, c_eff X_q, and sW_ex. Combining (10),(12),(13),(15) with the original pre-witness bound proves (2). In particular the combined high-face price is C_path,n=2N C_m IN PLACE OF the R359 terminal price 4N C_m. Their residuals come from different processes; (16), not a monotonicity assertion about residuals, justifies this substitution.

For reference the unchanged constants are

    C_epsilon,n=(lambda/q_-)[(2+3sqrt(n)+2exp(-sqrt(n)))/epsilon+1+sqrt(n)],
    D_top,n=s+log(4/3),
    C_hit,n=2(lambda/q_-)s[1+log(1/epsilon)],
    gamma_eff=2(lambda/q_-)exp(-sqrt(n)),
    c_eff=(lambda/q_-)exp(-sqrt(n))max(1,A_n/s),
    alpha_rec=N/(exp(sqrt(n))-1), beta=epsilon/16.

The three effective small coefficients are zero when the original high-past gate is necessarily empty; otherwise each of gamma_eff,c_eff,alpha_rec is <epsilon/16. Exact C_dir,n is retained, with the same bound 3sqrt(n)log^2(n+2) on the original nonempty branch.

Entrance T_entrance<=8lambda H W+2d_eff A_n W_nu/H+2B_H and exterior Lambda=128/119 are unchanged. Every source term in (2) is multiplied by 2Lambda. The receiver coefficient is unchanged; ONLY under the same certified-X placement of historical CZ 1/256 is it

    853/2304+2Lambda(gamma_eff+alpha_rec+c_eff)<889/2304.

All unrelated soft/crossing/hard-contract, distance/low-pe/aspect/threshold, original chronological initial/deleted/future-source time atoms, source/scale/layer/outer-integral and limiting fees remain. Native rank termination does not settle a historical time atom. No native terminal Delta W bill or old capture-square credit is added again.

## 8. Legal energy and the genuinely improved edge support

Let A={u:pi_u(alpha Q_u)<theta}. For THIS new process, let I_A and G_A be its initial injection and cumulative arrivals restricted by the CURRENT deterministic nonrich test, not by eventual terminal success. Write I_A=i sigma, G_A=g sigma. Aggregate only continued edges that pass step 7 and have target in A. The exact causal balance is

    G_A=I_A+G_A K_A,  K_A<=Pbar,  sigma K_A<=sigma.

An edge into a rich target is an effective row loss. A target-high stop is already a different earlier stop, not an arrival to be charged rich. Both are excluded from K_A; neither is relabelled native termination. The source-labelled actual continuation satisfies

    T(du,dz,dv)<=G_A(du)pi_u(dz)
          H_m(z,u) Qbar_z(u,dv)1_{d(z,v)<m}1_A(v),
    H_m(z,u)=1_{z in Q_u, 1<=d(z,u)<m}.                      (17)

Actual history/ancestor/rank acceptance remains in the left side; (17) only dominates it positively. This is the legal all-continuation low-face property newly supplied by the two paid stops. It is not imported from a terminal restriction.

Disintegrate T relative to G_A. Split its receiver kernel K_A=C+S by whether z is in alpha Q_v or in Q_v\alpha Q_v. On C the target face count is zero; on S both endpoint counts belong to {1,...,m-1}. The R359 target-inner proof applies to this further restricted actual component:

    C1<=r_*=min(1,alpha^n A_n/w),  sigma C<=theta sigma,
    ||C||_(2->2)<=c_*=sqrt(theta r_*)<=1/2,
    w=1+sqrt(n)-log(4/3).                                  (18)

The column inequality uses the unchanged full-f target posterior on A and sourcewise xi Qbar<=xi; the geometric row inequality uses k<=1/w and the actual inner-center envelope. No multiplier theta is inserted into an unrelated row bound.

For the selected NORMAL-terminal F_low^(360), write its receiver reward as beta_A G_A. Then beta_A<=bbar_native and beta_A<=1-K_A1. Set C_term=(D0+Delta)/2. The actual averaged-rank capacity gives integral beta_A d sigma<=C_term W. The same exact three-term energy identity consequently gives

    2J_A=integral sigma(du)K_A(u,dv)[g(u)-g(v)]^2
          +integral(1-K_A1)g^2d sigma
          +integral g^2 d(sigma-sigma K_A),
    J_A=integral i g d sigma,
    (F_low^(360))^2<=2 C_term W J_A.                        (19)

All quantities in (19) are NEW aggregate fields of the new process. Define the now legitimate low-face shell source map

    (T_m g)(z)=integral H_m(z,u)g(u)xi_z(du).

Using (17), k_z(u,v)+k_z(v,u)<=1/w, and only positive symmetrization yields

    <g,Sg>_sigma <=(1/(2w)) integral f(z)[T_m g(z)]^2dz,
    J_A>=(1-c_*)||g||_2^2-(1/(2w))integral f(T_m g)^2.        (20)

Thus the original target-inner elimination remains legitimate, while the shell-square envelope now has a true low-face mask at BOTH endpoints. No bound for this remaining square or J_A is proved here. Terminal direction dispersion still cannot be granted to g or all sources along its paths. Equations (19)-(20) do not add another ledger fee or spend original B_H negative-square credit.

## 9. Local exact verification: three scopes, no continuum inference

The embedded test uses finite common-source incidence with m_u computed from that source, a smoothed rank strip, full source draws, retained ancestors, and the exact new stopping order. Its rational diagnostic K,D0,Delta are NOT the original root parameters. The finite receiver weights are not asserted to be a real original Lebesgue field, and face labels in these tests are synthetic. The tests verify conservation, priority, sourcewise current/target capacities, aggregate energy and terminal classification; the real center-volume estimate C_m is supplied by the analytic proof (7).

~~~python
from fractions import Fraction as F
from itertools import product
counts={'initial':0,'interface':0,'expanded':0}
def ck(ok,stage):
    assert ok
    counts[stage]+=1
# Initial algebra: ordered rich/inner and new merged source bill.
for j in range(41):
    p=F(j,40);rich=int(p>=F(1,4));inner=(1-rich)*p
    ck(rich+inner<=4*p,'initial')
    for L in [F(0),F(1),F(7,3)]:
        current=L*F(j,40);target=L-current
        ck(current+target==L,'initial')
pos=lambda x:max(F(0),x)
def area(a,b,c,d,h):
    return (pos(d-a-h)**2-pos(d-b-h)**2-pos(c-a-h)**2+pos(c-b-h)**2)/2

def run(n,seed,stage):
    fm=[F(1)]*n;mass=[F(u+1) for u in range(n)]
    sig=[mass[u]/100 for u in range(n)]
    xi=lambda z,u:F(1,100) if z<=u else F(0)
    D0=F(1,100);Delta=F(3,200);width=Delta-D0;Kgap=F(21,20)
    Q=[[[F(0)]*n for u in range(n)] for z in range(n)]
    for z in range(n):
        for u,v in product(range(z,n),repeat=2):
            a=F(u-z,100);b=a+F(1,100);c=F(v-z,100);d=c+F(1,100)
            strip=area(a,b,c,d,D0)-area(a,b,c,d,Delta)
            Q[z][u][v]=strip/(width*F(1,100))
            if Q[z][u][v]:ck(mass[v]>Kgap*mass[u],stage)
        for v in range(n):
            ck(sum((xi(z,u)*Q[z][u][v] for u in range(n)),F(0))<=xi(z,v),stage)
    P=[[sum((Q[z][u][v]/mass[u] for z in range(u+1)),F(0)) for v in range(n)] for u in range(n)]
    ck(all(sum((sig[u]*P[u][v] for u in range(n)),F(0))<=sig[v] for v in range(n)),stage)
    ndim=7;threshold=3
    faces={}
    for u in range(n):
        for z in range(u+1):
            d=0 if (z+2*u+seed)%9==0 else 1+(z+3*u+seed)%4
            start=(2*z+u+seed)%ndim
            faces[z,u]={(start+k)%ndim for k in range(d)}
    rich=[sum((F(len(faces[z,u])==0) for z in range(u+1)),F(0))/mass[u]>=F(1,4) for u in range(n)]
    native=[1-sum(P[u]) for u in range(n)]
    cap=max((sum((xi(z,u) for u in range(z,n) if len(faces[z,u])>=threshold),F(0)) for z in range(n)),default=F(0))
    incoming=[F(0) if u<2 else sig[u]*F(1+(u%2),2) for u in range(n)]
    initial=sum(incoming);live={(u,(u,)):incoming[u] for u in range(n) if incoming[u]}
    cats={k:F(0) for k in ['rich','inner','current','ancestor','target','normal']}
    G=[F(0)]*n;T=[[F(0)]*n for _ in range(n)];terms=[]
    for gen in range(n):
        arrivals=[sum((v for (origin,hist),v in live.items() if hist[-1]==u),F(0)) for u in range(n)]
        ck(all(arrivals[u]<=sig[u] for u in range(n)),stage)
        nxt={};cur=tar=F(0)
        for (origin,hist),amount in live.items():
            u=hist[-1];G[u]+=amount
            if rich[u]:cats['rich']+=amount;continue
            for z in range(u+1):
                val=amount/mass[u];dcur=len(faces[z,u])
                if dcur==0:cats['inner']+=val;continue
                if dcur>=threshold:cats['current']+=val;cur+=val;continue
                if z<=max((0,1)+hist[:-1]):cats['ancestor']+=val;continue
                loss=val*(1-sum(Q[z][u]));cats['normal']+=loss
                if loss:terms.append((z,u,loss));ck(1<=dcur<threshold,stage)
                for v in range(n):
                    jump=val*Q[z][u][v]
                    if not jump:continue
                    if len(faces[z,v])>=threshold:cats['target']+=jump;tar+=jump;continue
                    ck(1<=dcur<threshold and 0<=len(faces[z,v])<threshold,stage)
                    T[u][v]+=jump
                    key=(origin,hist+(v,));nxt[key]=nxt.get(key,F(0))+jump
        ck(cur<=cap*sum(fm) and tar<=cap*sum(fm),stage)
        live=nxt
    ck(not live and sum(cats.values())==initial,stage)
    ck(cats['current']+cats['target']<=2*n*cap*sum(fm),stage)
    # New direction-source split; no high-face terminal can survive.
    L=[F(0)]*n;Li=[[F(0)]*ndim for _ in range(n)]
    for z,u,val in terms:
        L[z]+=val
        for face in faces[z,u]:Li[z][face]+=val
        ck(len(faces[z,u])<threshold,stage)
    pay=[L[z]>0 and max(Li[z])>=L[z]/3 for z in range(n)]
    selected=[F(0)]*n;paid=low=F(0)
    for z,u,val in terms:
        if pay[z]:paid+=val
        else:low+=val;selected[u]+=val
    ck(paid+low==cats['normal'],stage)
    for z in range(n):
        if L[z] and not pay[z]:ck(all(v<L[z]/3 for v in Li[z]),stage)
    # Causal nonrich aggregate energy; target-high stops are not native rewards.
    GA=[F(0) if rich[u] else G[u] for u in range(n)]
    IA=[F(0) if rich[u] else incoming[u] for u in range(n)]
    Keff=[[T[u][v]/GA[u] if GA[u] and not rich[v] else F(0) for v in range(n)] for u in range(n)]
    ck(all(GA[v]==IA[v]+sum((GA[u]*Keff[u][v] for u in range(n)),F(0)) for v in range(n)),stage)
    ck(all(sum((sig[u]*Keff[u][v] for u in range(n)),F(0))<=sig[v] for v in range(n)),stage)
    g=[GA[u]/sig[u] for u in range(n)];i=[IA[u]/sig[u] for u in range(n)]
    J=sum((sig[u]*i[u]*g[u] for u in range(n)),F(0))
    E=sum((sig[u]*Keff[u][v]*(g[u]-g[v])**2 for u,v in product(range(n),repeat=2)),F(0))
    E+=sum((sig[u]*(1-sum(Keff[u]))*g[u]**2 for u in range(n)),F(0))
    E+=sum(((sig[v]-sum((sig[u]*Keff[u][v] for u in range(n)),F(0)))*g[v]**2 for v in range(n)),F(0))
    ck(E==2*J,stage)
    beta=[selected[u]/GA[u] if GA[u] else F(0) for u in range(n)]
    ck(all(beta[u]<=native[u] and beta[u]<=1-sum(Keff[u]) for u in range(n)),stage)
    B0=sum((sig[u]*beta[u] for u in range(n)),F(0))
    ck(low**2<=2*B0*J,stage)
    return cats
seen={k:F(0) for k in ['rich','inner','current','ancestor','target','normal']}
for seed in range(1,6):
    cat=run(6,seed,'interface')
    for k in seen:seen[k]+=cat[k]
for n in [8,10,12]:
    for seed in range(1,9):
        cat=run(n,seed,'expanded')
        for k in seen:seen[k]+=cat[k]
ck(all(v>0 for v in seen.values()),'expanded')
print('PASS three-stage checks',counts,'total',sum(counts.values()))
print('All six chronological stop categories occurred with positive exact mass.')
~~~

Actual local execution passed 6,766 exact assertions: initial algebra 164, interface pressure 470, enlarged finite models 6,132. All six chronological stop categories occurred with positive exact mass. The script is self-contained. These checks do not realize the original high-past/native cube entrance and do not certify an asymptotic bound; their finite scope is specified above. Only `/tmp/r360_migration.md` was written; no other-author files or Git state were modified.
