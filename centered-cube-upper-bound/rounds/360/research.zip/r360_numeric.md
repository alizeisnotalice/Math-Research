R360 current/target high-face ordered-stop diagnostic

Fresh local standard-library Python processes returned PASS 3,164 exact Fraction assertions. Kernel/source-atom construction checks: 779 (67,99,613). Ordered-path checks: 2,385. Stage totals are 143,247,2774 for initial 1D, same-mass pressure, and expanded 2D. Reproduce:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r360_numeric.py
```

The self-contained script writes r360_numeric_result.json beside itself. It imports no old temporary code. Source/cube parameters and the empty-high-face reference totals are embedded explicitly. Earlier frozen files are unchanged.

Important limitation first: these are n=1 and n=2 diagnostics. The native high-face threshold from the main theorem exceeds these dimensions, so its actual high-face events are empty here. Face-count thresholds m=1,2,n+1 are diagnostic, and m=0 is an additional artificial all-bad limit. None of the positive receipts below demonstrates the native high-dimensional threshold or a root payment.

Actual geometry. The full f consists of positive-volume source boxes, side 1/50, with the actual masses and cube-generated incidences of the R359 fixtures. The initial/tie-pressure sources have centres 0,1 and masses 1,2. The 2D source has unit-square corners with masses 1,2,3,5. Exact full-cube endpoints are checked, and m,q, posterior and atom-safe smoothed rank kernel are recomputed. Receiver weights remain finite QUADRATURE, not actual receiver dx. Diagnostic smoothing windows are (1/8,1/4) or (1/10,1/5); they do not exceed native D0 and cannot test native strict K gap, availability or hard entrance.

Inner and face geometry use the SAME alpha=1/100, as agreed with the parent. Each original source box is cut by every contracted-cube coordinate plane for every possible receiver. There are 6,7,60 positive sub-box atoms. A source atom has constant inner status and exact signed face set for every current and target cube. The program verifies that face count genuinely varies inside original source boxes; therefore replacing the actual new source by a packet centre would change these tests. Strict face boundaries are source-null endpoints of the positive-L1 boxes, not an added mass.

The preserved order is full posterior source draw; inner stop; CURRENT-high stop; ancestor stop; rank normal loss or successful target; TARGET-high stop; continue or unfinished. Target-high is tested before a next arrival (and hence before any next-arrival rich test). Original source labels and all previous receiver labels remain attached. The original posterior is never renormalized after exclusions.

All current/target tests refer to the SAME actual new-source sub-box. In particular, the target face mask is not independently sampled or evaluated at a source centre. Every continued successful edge has both current and target face counts below m. Every remaining normal terminal has current face count below m. First stops are disjoint, all other branches are retained, and horizon unfinished is an explicit separate slot.

Exact source-column costs. At a source point z define

Cm_disc(z)=sum_v xi_z(v) 1{facecount(v,z)>=m}.

The result records its f-weighted average within each original source box, integrating all actual sub-box masks. Every generation's current-high and target-high source masses are EACH bounded by integral_box f Cm_disc. Thus each whole-path receipt is at most N integral f Cm_disc. The script gives only the safe sum 2N integral f Cm_disc for their combination; it does not silently merge the two bounds. These are finite discrete receiver-column caps, not the continuum C_m theorem.

Some actual costs and retained mass:

| Fixture | m | New current+target receipt / initial mass | Unfinished mass |
|---|---:|---:|---:|
| Initial 1D | 1 | 43/50 | 0 |
| Same-mass 1D | 1 | 47/56 | 0 |
| 2D | 1 | 7060/7207 | 0 |
| 2D | 2 | 2420260804/2815234375 = 0.859701354 | 0 |
| Initial 1D | 2>n | 0 | 1837/8640 |
| Same-mass 1D | 2>n | 0 | 5549/102400 |
| 2D | 3>n | 0 | 705159/55000000 |

The complement of each new receipt is output as other stops or unfinished, not dropped or declared newly paid. The 2D m=2 case has current-high mass 1055847857/787500000 and target-high mass 3428501/17500000. Its current-high/ancestor overlap has positive mass 2226281/10937500, assigned ONLY to current-high because it precedes ancestor. This makes the ordering test nonvacuous. Its per-receipt cap N integral f Cm_disc is 1111/60, a coarse bound larger than the actual fees; no sharp price improvement is claimed.

Limits and independent aggregation. For m=0, all sources surviving inner are current-high; later categories vanish. For m=1 the same exhaustion holds because every contracted-shell source has a face. For m>n, both high events and Cm_disc vanish, and all original R359 first-stop totals, including positive unfinished, are recovered exactly from embedded frozen reference fractions. A second age/set propagation independently agrees with ordered-history enumeration in every first-stop category and original-source label. Every generation's receiver marginal remains below sigma=q dx.

Scope. Actual positive-L1 source/cube endpoints, exact source sub-box masks and rank strip integrals are separated from finite receiver quadrature and diagnostic parameters. No native large shift/gap, high-dimensional high-face event, continuous receiver du, original historical admissibility, general path-source bound, or root theorem is established. The numerical contribution is the complete marked event/cap accounting, especially same-source target masks, current-before-ancestor overlap, low-low continued edges, and explicit unfinished recovery.
