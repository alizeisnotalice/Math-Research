# 第360轮完整总账：全路径筛选及首次不交前付款

本账对应原始 \(B_H\)。完整迁移见 migration；新增 noD 正常终端付款及方向重算见 terminal。高维剩余 F_D 为至少发生一次不交续跳且重做终端方向筛选的真实正常终端，仍未付。
设 \(x=\sqrt n,s=1+x,W=\int f,W_{ex}=\int g_{ex},X_q=\int_Eq\le X=\lambda|E|\)，\(\varepsilon=119/3072,\Lambda=128/119,\beta=\varepsilon/16,q_-=3\lambda/4\)。
\[
B_H\le F_D+
[(13/3)\varepsilon+\gamma_{eff}+\beta+\alpha_{rec}+c_{eff}]X_q
+[C_{\varepsilon,n}+8s+C_{dir}^{eff}+C_{path}+C_{terminal}]W
+(D_{top}+C_{hit}+s)W_{ex}.
\]
这里
\[
C_{\varepsilon,n}=\frac\lambda{q_-}\left[\frac{2+3x+2e^{-x}}\varepsilon+1+x\right],\quad
D_{top}=s+\log(4/3),\quad C_{hit}=2(\lambda/q_-)s(1+\log(1/\varepsilon)).
\]
保留 \(A_n=1+n\log(b/a)\)、\(N=\max(1,\lceil\log[(\lambda/q_-)(b/a)^n]/x\rceil)\)、\(\alpha^n=\min(1,s/(NA_n))\)、\(L_n=\log(n+2)\)，
\[
C_{dir}=N[(1-\alpha)+(n(1-\alpha)+\alpha)\log(b/a)]L_n,
\]
\[
C_{path}=2NC_m,\quad C_m=\Pr\{\operatorname{Bin}(n,1-\alpha)\ge m\}
+n\log(b/a)\Pr\{\operatorname{Bin}(n-1,1-\alpha)\ge m-1\},
\quad m=1+\lceil8L_n\rceil.
\]
这些binomial项来自真实接收体积，不是实际来源独立性。非空原highpast分支上，
\[
\gamma_{eff}=2(\lambda/q_-)e^{-x}<\varepsilon/16,\quad
c_{eff}=(\lambda/q_-)e^{-x}\max(1,A_n/s)<\varepsilon/16,\quad
\alpha_{rec}=N/(e^x-1)<\varepsilon/16,
\]
且 \(C_{dir}\le3\sqrt n L_n^2\)，\(C_{path}\le2\sqrt n\)。原必要条件使入口为空时相应新流与这些有效分支系数置零，不给后续新来源重新授予原资格。

终端费用采用分段定义：n≥2^32 时，C_terminal=b_*/(1−c_col)≤(8/5)b_*，c_col=1/4+r_p≤3/8，C_dir^eff=C_dir；n<2^32 时，C_terminal=N b_*≤786432√n，C_dir^eff=0，F_D=0。原困难入口为空则新增实际分支费用为零。有限维付款仅限本硬余项。

高维十项实际正分解及费用：

|新流部分|费用|
|---|---|
|级联删除|β X_q+4sW|
|初始旧clock近端|c_eff X_q|
|初始旧来源inner|s W_ex|
|首次rich或实际inner来源联合停止|4sW|
|首次当前来源高面|N C_m W|
|首次祖先回捕|α_rec X_q|
|首次成功目标高面|N C_m W|
|首次D续跳之前正常终止|C_terminal W|
|至少一次D后，重新计算的方向来源删除|C_dir W|
|剩余正常终端|F_D，未付|

本轮不增加接收吸收系数。不逐代再收费正常终止；首次D之后不能重新授予原入口或重复已有来源预算。C+B 的L2预解是估计工具，不能冒充全部相关路径的实际付款。

原始入口与外乘不变：
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H+2B_H.
\]
入口2和外乘 \(\Lambda\) 作用于全体新旧费用。接收系数为
\[
13/36+2\Lambda(\beta+\gamma_{eff}+\alpha_{rec}+c_{eff}).
\]
仅当历史CZ项 \(1/256\) 属于同一认证 \(X\) 账时，合计才有
\[
853/2304+2\Lambda(\gamma_{eff}+\alpha_{rec}+c_{eff})<889/2304.
\]
其余 \(1415/2304\) 以上的吸收空间不是任何未付积分的预算。若未来以 \(F_D\le\delta X_q+b_*W/(2\gamma\delta)\) 回代，新增接收系数将是 \(2\Lambda\delta\)，新增来源费是 \(\Lambda b_*W/(\gamma\delta)\)；本轮仍没有证明条件 \(\gamma>0\) 对实际来源平方成立，因此没有插入该项。

独立未付槽：一般软层 \(C_H-S_H\)、越阈 \(I_H\)、硬层合同之外的质量可比重尾；宽距离、低pe、极端尺度比及全部阈值补集；原初始时间原子、删除跳跃、未来被删来源；H选择、来源及物理尺度分层、外积分、截断和极限。旧物理时钟末端原子完整保留，新秩核正常终止不替代任何历史时间原子。

一般一致弱型上界与整个 \(B_H\) 仍未闭合。

本轮新增 noD 来源费用回代原入口及外乘后为 2Λ C_terminal W，不能漏掉因子2；终端方向费用取上述分段版本。首次D来源入口的列界不是其后缀根阶预算。
