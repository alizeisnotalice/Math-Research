#!/usr/bin/env python3
"""Smoothed marked chain with actual current/target source high-face first stops."""
from fractions import Fraction as F
from collections import Counter,defaultdict
from itertools import product
from pathlib import Path
import json
BASE=Path(__file__).resolve().parent;C=Counter()
DATA=[{'name': 'distinct_masses_small_shift', 'n': 1, 'Delta': '1/4', 'source_masses': ['1', '2'], 'source_centres': [['0'], ['1']], 'source_box_side': '1/50', 'receivers': [{'R': '2/5', 'centre': ['0'], 'm': '1', 'q': '5/2', 'quadrature_dx': '1/10'}, {'R': '2/5', 'centre': ['1'], 'm': '2', 'q': '5', 'quadrature_dx': '1/10'}, {'R': '6/5', 'centre': ['1/2'], 'm': '3', 'q': '5/2', 'quadrature_dx': '1/5'}], 'input_I': ['1/8', '1/6', '1/8']}, {'name': 'same_mass_atom_and_selfloops', 'n': 1, 'Delta': '1/4', 'source_masses': ['1', '2'], 'source_centres': [['0'], ['1']], 'source_box_side': '1/50', 'receivers': [{'R': '2/5', 'centre': ['0'], 'm': '1', 'q': '5/2', 'quadrature_dx': '1'}, {'R': '1/2', 'centre': ['1/100'], 'm': '1', 'q': '2', 'quadrature_dx': '3/4'}, {'R': '2/5', 'centre': ['1'], 'm': '2', 'q': '5', 'quadrature_dx': '1'}, {'R': '6/5', 'centre': ['1/2'], 'm': '3', 'q': '5/2', 'quadrature_dx': '1'}], 'input_I': ['5/4', '1/2', '5/4', '1/2']}, {'name': 'two_dimensional_full_source', 'n': 2, 'Delta': '1/5', 'source_masses': ['1', '2', '3', '5'], 'source_centres': [['0', '0'], ['1', '0'], ['0', '1'], ['1', '1']], 'source_box_side': '1/50', 'receivers': [{'R': '2/5', 'centre': ['0', '0'], 'm': '1', 'q': '25/4', 'quadrature_dx': '1/20'}, {'R': '2/5', 'centre': ['1', '0'], 'm': '2', 'q': '25/2', 'quadrature_dx': '1/20'}, {'R': '2/5', 'centre': ['0', '1'], 'm': '3', 'q': '75/4', 'quadrature_dx': '1/20'}, {'R': '2/5', 'centre': ['1', '1'], 'm': '5', 'q': '125/4', 'quadrature_dx': '1/20'}, {'R': '6/5', 'centre': ['1/2', '0'], 'm': '3', 'q': '25/12', 'quadrature_dx': '1/2'}, {'R': '6/5', 'centre': ['1/2', '1'], 'm': '8', 'q': '50/9', 'quadrature_dx': '1/2'}, {'R': '3/2', 'centre': ['1/2', '1/2'], 'm': '11', 'q': '44/9', 'quadrature_dx': '1/2'}], 'input_I': ['5/32', '5/24', '15/64', '5/16', '25/144', '25/63', '11/36']}]
def ck(k,v):
 C[k]+=1
 assert v,k
def pos(x):return max(F(0),x)
def tailarea(a,b,c,d,h):return (pos(d-a-h)**2-pos(d-b-h)**2-pos(c-a-h)**2+pos(c-b-h)**2)/2
def loss(D,l,h):return D if D<=l else (l+h)/2 if D>=h else D-(D-l)**2/(2*(h-l))
def build(stage,data,N):
 before=sum(C.values());n=data['n'];f=list(map(F,data['source_masses']));centres=[list(map(F,z)) for z in data['source_centres']];h=F(data['source_box_side'])/2;rec=[(list(map(F,r['centre'])),F(r['R']),F(r['quadrature_dx'])) for r in data['receivers']];nr=len(rec);nz=len(f);upper=F(data['Delta']);lower=upper/2;window=upper-lower;inner=F(1,100)
 inc=[];m=[];sig=[]
 for x,R,dx in rec:
  row=[]
  for z in centres:
   inside=all(abs(a-b)+h<=R/2 for a,b in zip(x,z));outside=any(abs(a-b)-h>=R/2 for a,b in zip(x,z));ck('actual_whole_source_box_capture',inside or outside);row.append(int(inside))
  mm=sum(a*b for a,b in zip(f,row));inc.append(row);m.append(mm);sig.append(mm*dx/R**n)
 pi=[[f[z]*inc[u][z]/m[u] for z in range(nz)] for u in range(nr)];xi=[[F(inc[u][z])*rec[u][2]/rec[u][1]**n for u in range(nr)] for z in range(nz)];Q=[[[F(0) for v in range(nr)] for u in range(nr)] for z in range(nz)];D=[];groups=[]
 for z in range(nz):
  gs=[];block={};a=F(0)
  for mass in sorted(set(m[u] for u in range(nr) if inc[u][z])):
   ids=[u for u in range(nr) if inc[u][z] and m[u]==mass];b=a+sum(xi[z][u] for u in ids);gs.append((a,b,ids))
   for u in ids:block[u]=(a,b)
   a=b
  D.append(a);groups.append(gs)
  for u in block:
   aa,b=block[u]
   for v in block:
    c,d=block[v];area=tailarea(aa,b,c,d,lower)-tailarea(aa,b,c,d,upper)
    knots=sorted(set([lower,upper]+[t for t in [c-b,c-aa,d-b,d-aa] if lower<t<upper]));overlap=lambda t:pos(min(b+t,d)-max(aa+t,c));independent=sum(((y-x)*(overlap(x)+overlap(y))/2 for x,y in zip(knots,knots[1:])),F(0))
    ck('strip_area_independent_exact_integral',area==independent>=0);k=area/(window*(b-aa)*(d-c));Q[z][u][v]=xi[z][v]*k;ck('smoothed_density_bound',k<=1/window)
  primitive=lambda t:(pos(t-lower)**2-pos(t-upper)**2)/(2*window)
  for u in block:
   aa,b=block[u];expected=(primitive(D[z]-aa)-primitive(D[z]-b))/(b-aa)
   ck('exact_smoothed_row_survival',sum(Q[z][u])==expected)
   for v in block:ck('paired_density_direction_bound',Q[z][u][v]/xi[z][v]+Q[z][v][u]/xi[z][u]<=1/window)
  for aa,b,ids in gs:
   if len(ids)>1:ck('same_mass_whole_atom_kernel',all(Q[z][u]==Q[z][ids[0]] for u in ids))
  ck('exact_source_averaged_rank_loss',sum(xi[z][u]*(1-sum(Q[z][u])) for u in range(nr))==loss(D[z],lower,upper))
  for v in range(nr):
   col=sum(xi[z][u]*Q[z][u][v] for u in range(nr));expected=F(0)
   if v in block:
    aa,b=block[v];expected=xi[z][v]*(primitive(b)-primitive(aa))/(b-aa)
   ck('smoothed_source_column_subinvariance',col==expected<=xi[z][v])
 P=[[sum(pi[u][z]*Q[z][u][v] for z in range(nz)) for v in range(nr)] for u in range(nr)];nativeb=[1-sum(r) for r in P]
 for v in range(nr):ck('full_matched_reference_subinvariance',sum(sig[u]*P[u][v] for u in range(nr))<=sig[v])
 B0=sum(sig[u]*nativeb[u] for u in range(nr));ck('full_source_smoothed_loss_fee',B0==sum(f[z]*loss(D[z],lower,upper) for z in range(nz))<=(lower+upper)/2*sum(f))
 # Complete source-box partition by all contracted-cube coordinate faces.
 atoms=[]
 for z,centre in enumerate(centres):
  cuts=[]
  for j in range(n):
   lo=centre[j]-h;hi=centre[j]+h;cuts.append(sorted(set([lo,hi]+[t for x,R,dx in rec for t in [x[j]-inner*R/2,x[j]+inner*R/2] if lo<t<hi])))
  total=F(0)
  for intervals in product(*[list(zip(c,c[1:])) for c in cuts]):
   volume=F(1)
   for a,b in intervals:volume*=b-a
   mass=f[z]*volume/(2*h)**n;total+=mass;ins=[];faces=[]
   for x,R,dx in rec:
    inside=all(a>=x[j]-inner*R/2 and b<=x[j]+inner*R/2 for j,(a,b) in enumerate(intervals));fl=[]
    for j,(a,b) in enumerate(intervals):
     if b<=x[j]-inner*R/2:fl.append((j,-1))
     elif a>=x[j]+inner*R/2:fl.append((j,1))
    ck('source_atom_exact_inner_or_face_partition',inside or bool(fl));ins.append(inside);faces.append(fl)
   atoms.append((z,mass,ins,faces))
  ck('positive_source_atom_partition_mass_once',total==f[z])
 return locals()
BASELINE_R359={'distinct_masses_small_shift': {'inner': '7/120', 'normal': '1259/8640', 'unfinished': '1837/8640'}, 'same_mass_atom_and_selfloops': {'ancestor': '3824991/1638400', 'inner': '1610529/1638400', 'normal': '13131/102400', 'unfinished': '5549/102400'}, 'two_dimensional_full_source': {'ancestor': '491585089/346500000', 'inner': '6559/120000', 'normal': '115983177/385000000', 'unfinished': '705159/55000000'}}
def flow(env,threshold):
 start=sum(C.values());data=env['data'];n=env['n'];N=env['N'];f=env['f'];nr=env['nr'];nz=env['nz'];pi=env['pi'];xi=env['xi'];Q=env['Q'];P=env['P'];atoms=env['atoms'];sig=env['sig'];inc=env['inc'];m=env['m'];D=env['D'];lower=env['lower'];upper=env['upper'];I=list(map(F,data['input_I']))
 Cm=[sum((mass/f[z]*sum(xi[z][v] for v in range(nr) if len(faces[v])>=threshold) for zz,mass,ins,faces in atoms if zz==z),F(0)) for z in range(nz)];cap=sum(f[z]*Cm[z] for z in range(nz))
 states={(u,tuple(),orig):I[u]*pi[u][orig] for u in range(nr) for orig in range(nz) if pi[u][orig]};totals=Counter();marked=Counter();generations=[];overlap=F(0);Sedge=F(0);sourcecurrent=[F(0)]*nz;sourcetarget=[F(0)]*nz
 for age in range(N):
  new=defaultdict(F);incoming=[F(0)]*nr;g=Counter();curz=[F(0)]*nz;tarz=[F(0)]*nz
  def stop(kind,orig,value):g[kind]+=value;marked[(kind,orig)]+=value
  for (u,hist,orig),weight in states.items():
   incoming[u]+=weight
   for z,mass,ins,faces in atoms:
    if not inc[u][z]:continue
    w=weight*mass/m[u];oldhit=any(inc[a][z] for a in hist);currentbad=len(faces[u])>=threshold
    if ins[u]:stop('inner',orig,w);continue
    if currentbad:
     stop('current_high',orig,w);curz[z]+=w
     if oldhit:overlap+=w
     continue
    if oldhit:stop('ancestor',orig,w);continue
    stop('normal',orig,w*(1-sum(Q[z][u])))
    ck('remaining_normal_has_low_current_face_count',len(faces[u])<threshold)
    for v in range(nr):
     e=w*Q[z][u][v]
     if not e:continue
     if len(faces[v])>=threshold:stop('target_high',orig,e);tarz[z]+=e;continue
     ck('continued_success_both_endpoints_low_face',len(faces[u])<threshold and len(faces[v])<threshold)
     Sedge+=e
     if age+1==N:stop('unfinished',orig,e)
     else:new[(v,hist+(u,),orig)]+=e;g['continue']+=e
  ck('ordered_current_before_ancestor_full_conservation',sum(g.values())==sum(incoming))
  for u in range(nr):ck('generation_receiver_cap',incoming[u]<=sig[u])
  for z in range(nz):
   ck('current_high_source_column_cap',curz[z]<=f[z]*Cm[z]);ck('target_high_same_source_column_cap',tarz[z]<=f[z]*Cm[z]);sourcecurrent[z]+=curz[z];sourcetarget[z]+=tarz[z]
  for k,val in g.items():
   if k!='continue':totals[k]+=val
  generations.append(dict(age=age,incoming=list(map(str,incoming)),branches={k:str(v) for k,v in g.items()},current_high_source=list(map(str,curz)),target_high_source=list(map(str,tarz))))
  states=new
 ck('all_first_stops_and_unfinished_conserve',not states and sum(totals.values())==sum(I))
 ck('each_high_receipt_N_integrated_Cm_disc',totals['current_high']==sum(sourcecurrent)<=N*cap and totals['target_high']==sum(sourcetarget)<=N*cap)
 ck('both_receipts_not_merged_without_factor',totals['current_high']+totals['target_high']<=2*N*cap)
 if threshold>n:
  ck('empty_high_face_limit',cap==totals['current_high']==totals['target_high']==0)
  base=BASELINE_R359[data['name']];ck('empty_threshold_recovers_frozen_R359_stops',all(totals[k]==F(v) for k,v in base.items()) and all(totals[k]==0 for k in totals if k not in base))
 if threshold==1:ck('one_face_current_first_exhausts_shell',totals['inner']+totals['current_high']==sum(I) and totals['ancestor']==totals['normal']==totals['target_high']==totals['unfinished']==0)
 if n==2 and threshold==2:ck('nonempty_new_current_target_and_priority_overlap',totals['current_high']>0 and totals['target_high']>0 and overlap>0)
 if threshold==0:ck('all_bad_after_inner_limit',totals['normal']==totals['target_high']==totals['unfinished']==0 and totals['inner']+totals['current_high']==sum(I))
 # Independent age/set aggregation, still retaining original source labels.
 dist={(u,frozenset(),o):I[u]*pi[u][o] for u in range(nr) for o in range(nz) if pi[u][o]};other=Counter();omarked=Counter()
 for age in range(N):
  nxt=defaultdict(F)
  for (u,history,orig),weight in dist.items():
   for z,mass,ins,faces in atoms:
    if not inc[u][z]:continue
    w=weight*mass/m[u]
    if ins[u]:kind='inner'
    elif len(faces[u])>=threshold:kind='current_high'
    elif any(inc[a][z] for a in history):kind='ancestor'
    else:
     val=w*(1-sum(Q[z][u]));other['normal']+=val;omarked[('normal',orig)]+=val
     for v in range(nr):
      e=w*Q[z][u][v]
      if not e:continue
      if len(faces[v])>=threshold:kind2='target_high'
      elif age+1==N:kind2='unfinished'
      else:nxt[(v,history|{u},orig)]+=e;continue
      other[kind2]+=e;omarked[(kind2,orig)]+=e
     continue
    other[kind]+=w;omarked[(kind,orig)]+=w
  dist=nxt
 ck('independent_age_set_marked_distribution_agrees',all(other[k]==totals[k] for k in set(other)|set(totals)) and all(omarked[k]==marked[k] for k in set(omarked)|set(marked)))
 original=sum(I);paid=totals['current_high']+totals['target_high']
 return dict(name=data['name'],n=n,N=N,face_threshold=threshold,alpha_inner_and_face=str(env['inner']),initial_mass=str(original),first_stop_mass={k:str(v) for k,v in totals.items()},stops_by_original_source={str(k):str(v) for k,v in marked.items()},new_high_receipts=str(paid),new_high_fraction=str(paid/original),other_stops_or_unfinished=str(original-paid),Cm_disc_average_within_source_box=list(map(str,Cm)),integrated_f_Cm_disc=str(cap),each_receipt_budget_N_int_f_Cm=str(N*cap),current_high_by_current_source=list(map(str,sourcecurrent)),target_high_by_current_source=list(map(str,sourcetarget)),current_high_ancestor_overlap_assigned_only_current=str(overlap),successful_low_low_edge_mass=str(Sedge),generations=generations,exact_checks=sum(C.values())-start)
def main():
 rows=[];construction=[]
 for stage,data,N in zip(['initial','ties_stress','expanded_2D'],DATA,[1,2,3]):
  start=sum(C.values());env=build(stage,data,N)
  ck('actual_face_counts_vary_inside_original_source_box',any(len({len(faces[v]) for zz,mass,ins,faces in env['atoms'] if zz==z})>1 for z in range(env['nz']) for v in range(env['nr']) if env['inc'][v][z]))
  construction.append(dict(stage=stage,exact_checks=sum(C.values())-start,source_atoms=len(env['atoms'])))
  for threshold in sorted(set([0,1,2,env['n']+1])):
   rows.append(flow(env,threshold))
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),construction_checks=construction,models=rows,scope='Actual positive source-box and cube geometry with finite receiver quadrature. Same alpha=1/100 for inner and face planes. Smoothed diagnostic shifts do not exceed native D0 and native high-face m>small n is empty. Current-high precedes ancestor, target-high precedes next arrival/unfinished. No native hard/core/root claim.')
 (BASE/'r360_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),construction=construction,models=[dict(name=x['name'],m=x['face_threshold'],paid=x['new_high_fraction'],unfinished=x['first_stop_mass'].get('unfinished','0'),checks=x['exact_checks']) for x in rows]),sort_keys=True))
if __name__=='__main__':main()
