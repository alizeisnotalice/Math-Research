# R360 — Exact remaining disjoint-coordinate bilinear geometry

This note gives the next precise geometric target after the NEW first-high-face stopping process and its shared-coordinate contraction. It is not an estimate of that target. All quantities refer to that rebuilt process, not to R359's old remainder.

Use sigma=q du and the current nonrich arrival aggregate G=g sigma, with its actual injection I=i sigma and effective continuation K. Keep every original history/clock/source mark when constructing the effective labelled kernel. Let alpha be the fixed common shrink and

    A_z(u)={j: |u_j-z_j|>alpha R_u/2},
    H_m(z,u)=1_{z in Q_u, 1<=|A_z(u)|<m}.

The first-current-high and first-successful-target-high stops imply the following for actual continuation: the source is in H_m at the source endpoint; at the target it is either inner or in H_m. Split actual K=C+B+D into target-inner C, outer/outer with overlapping coordinate sets B, and outer/outer with disjoint coordinate sets D. These are disjoint positive parts of the SAME source-labelled effective kernel. They are not independent receiver choices or a terminal posterior modification.

The proved R360 bounds give

    ||C+B||_2 <= a_*=c_*+min(1,(m-1)B1/w).

For n>=2^32 in a nonempty original high-past branch, a_*<=5/8 is valid. More generally the argument below applies whenever a_*<1. Put

    V=C+B, R_V=(Id-V)^(-1), a=R_V i, L_*=(1-a_*)^(-1).

The geometric resolvent exists in L2(sigma), is positive and obeys

    ||a||_2<=L_*||i||_2, L_*<=8/3 at the above threshold.

There is no asserted pointwise bound for a. The resolvent is algebra of the actual aggregate kernel, not an assertion that repeated effective edges reproduce the original conditional history law.

Retain the normalized ACTUAL rank-strip kernel

    vartheta_z(u,v)=w k_z(u,v)
      =integral R_z(u,ds)R_z(v,dt)1_{D0<t-s<Delta}.

It obeys 0<=vartheta<=1, vartheta(u,v)+vartheta(v,u)<=1, and vanishes unless m_v>K m_u. For nonnegative h,k define

    Phi_z(h,k)=integral xi_z(du)xi_z(dv) h(u)k(v)
       H_m(z,u)H_m(z,v)1_{A_z(u) intersection A_z(v)=empty}
       vartheta_z(u,v).

This retains BOTH the actual rank window and the strict forward mass gap; it does not replace the window by every far pair. The coordinate-set indicator is also retained, not expanded into unpriced combinatorial choices. Phi is directed. Define the symmetric quadratic expression

    Q_z(h)=integral xi_z(du)xi_z(dv) h(u)h(v)
       H_m(z,u)H_m(z,v)1_{A_z(u) intersection A_z(v)=empty}
       [vartheta_z(u,v)+vartheta_z(v,u)].

Thus Q_z(h)=2 Phi_z(h,h). Its rank factor lies in [0,1] and still vanishes outside the symmetric strict mass gap. By source-labelled positive domination of the actual history acceptance,

    <h,Dk>_sigma <= (1/w) integral f(z) Phi_z(h,k)dz,       (1)
    <h,Dh>_sigma <= (1/(2w)) integral f(z)Q_z(h)dz.        (2)

These are upper comparisons, not lower capture bounds. Only actual history restrictions are dropped here. One may additionally omit vartheta to get the coarser disjoint-coordinate product envelope, but that further relaxation is NOT required as the next geometric target. This avoids unnecessarily strengthening the unproved estimate by forgetting the actual rank window.

From the exact arrival identity g=i+K^*g, let J=integral i g d sigma. Rearranging with V gives

    g=R_V^* i+R_V^*D^*g,
    J=<a,i>_sigma+<g,Da>_sigma.

Hence (1) yields the injection-anchored target

    J <= L_*||i||_2^2 + (1/w) integral f(z)Phi_z(g,a)dz.    (3)

Only the true original injection i appears in a. The last term has coefficient 1/w, not 1/(2w). A sufficient UNPROVED assertion is

    integral f Phi_z(g,a)dz <= C w log^A(n+2) X_q.         (4)

Then J<=(L_*+C log^A(n+2))X_q. With the actual selected normal terminal F_new and native source terminal capacity b_*W, b_*=(D0+Delta)/2, the exact energy estimate implies

    F_new <= delta X_q
          + [b_*(L_*+C log^A(n+2))/(2delta)]W.             (5)

This would have the required root-polylog scale for THIS hard remainder; entrance factor 2 and exterior Lambda multiply both costs. All other independently unpaid slots would still need settlement. Neither (4) nor a bound for those slots is established here.

There is also a sufficient quadratic coercivity condition:

    Q_D(g):=integral f(z)Q_z(g)dz <= rho w||g||_2^2.

Using (2) gives

    J >= (1-a_*-rho/2)||g||_2^2.

If gamma=1-a_*-rho/2>0, Cauchy implies J<=||i||_2^2/gamma<=X_q/gamma and F_new<=delta X_q+b_*W/(2gamma delta). No claim is made that the actual Q_D satisfies this condition. The injection-anchored mixed assertion (4) may be a weaker route than a uniform operator inequality; neither is assumed.

The complete finite-dimensional exception is explicit. For 1<=n<2^32, the selected normal terminals of the rebuilt process satisfy F_new<=N Delta W<=12nW<=786432 sqrt(n) W, using N<=3sqrt(n) and Delta<=4sqrt(n). This only closes this hard remainder in that bounded dimension interval. It does not settle high-dimensional D, the soft slots, scale summation, or the overall weak-type statement, and it is not used to infer any dimension asymptotic.

The change in the next geometric task is genuine: on every actual D edge the shared source is low-face at both endpoints and the two active coordinate sets are nonempty and disjoint. These are now paid/selected path conditions, not borrowed terminal facts. Source-direction dispersion remains a terminal-column statement and is not asserted for g or a. The full f source integral and actual receiver measure in Phi remain; no arbitrary source density cap has been introduced.
