# R360 — Actual no-disjoint-jump terminal payment and the new route advice

## 1. Scope and adoption of the user-provided advice

The six-page user PDF, Pro第355轮后攻坚路线建议_20261018 2, was read in full by text extraction; pages 2–5 were also rendered and visually checked for the formulas, scope qualifiers and validation requirements. It is a research suggestion based on rounds through R355, not a new theorem or an instruction to discard independently checked later results. Its source bytes are identified below.

The recommendation to prioritize the actual normal-terminal source marginal over total visits is adopted here. Its requested full-f source load and conservation are already explicit in R356/R359 and reconstructed in R360; merely renaming that load is not counted as progress. The new result below is a direct bound on actual terminated paths, using a common reference column contraction rather than a per-generation root charge. No additional counterexample campaign is undertaken. The alternative return to original B_H capture squares remains available if the path relaxation proves too expensive; no square credit is reused here.

Low-dimensional source-box examples remain algebra/geometric mechanism diagnostics with receiver quadrature. They do not certify the original hard high-past gate, positive-volume receiver realizability in that gate, or an asymptotic exponent. The original entrance, soft/scale complements and historical time atoms remain separate, as requested by the advice.

## 2. A canonical reference kernel, before history acceptance

Keep the R360 process with actual first-current-high and first-target-high stops, its real nonrich entrance I<=sigma=q du, and full source/rank/history marks. Use p=min(n,m-1), and the actual face set F_z(u) defined in r360_geometry.md. Define a canonical SOURCE-LABELLED continuation envelope on nonrich receiver endpoints, retaining the current-source shell gate and both endpoint low-face gates:

    M(du,dz,dv)=sigma(du) pi_u(dz) Qbar_z(u,dv)
       1_nonrich(u)1_nonrich(v)
       1_{1<=|F_z(u)|<=p}1_{|F_z(v)|<=p}.

Here a continued edge connects two counted nonrich states. A successful rank edge into a rich target is an already charged rich stop and is not an A/D continuation in this state space. Every actual continued edge in this sense is dominated by this envelope after its real history acceptance. Partition its source-labelled events into

    C0: F_z(v) is empty (source inner at target),
    B0: F_z(v) is nonempty and meets F_z(u),
    D0edge: F_z(v) is nonempty and disjoint from F_z(u).

D0edge denotes an event, not the numerical rank width D0. Project and disintegrate relative to sigma at u to obtain reference receiver kernels C0,B0,D0edge. They are mutually exclusive parts of the same source-marked envelope. Write A0=C0+B0.

The same REAL source-column proofs as R359–360 give

    sigma C0<=theta sigma, theta=1/4,
    sigma B0<=r_p sigma, r_p=min(1,Lambda_p/w),
    sigma D0edge<=sigma.

Thus

    sigma A0<=c_col sigma, c_col=theta+r_p.                (1)

For n>=2^32, the independently proved r_p<=1/8 yields c_col<=3/8<1. This column statement is for the canonical envelope, not only for an aggregate kernel averaged with all future histories. That distinction is essential for the following genuine first-event argument.

## 3. Original-history first-D decomposition and its source fee

Do NOT change the actual process. Mark each continued edge by its actual source event A0 or D0edge. Let G_j^0 be its alive nonrich arrival measure at generation j along paths that have never previously made a D0edge continuation. Retain all original old source, clock, ancestor and new rank/source marks on these paths. Other already charged stopping events simply remove mass. Initially G_0^0=I<=sigma.

Given any current history, its next A0 continuation is a positive restriction of the canonical A0 envelope. Induction from (1) therefore proves

    G_j^0<=c_col^j sigma.                                 (2)

No posterior is renormalized after selection and no independence across histories is needed. In particular this is not the unsupported assertion that the SUM of all arrivals is <=sigma.

Let bbar(u) be the ordinary native missing-rank probability of the full smoothed kernel, before additional kills. Its exact source capacity is

    integral bbar d sigma = integral f(z) E_h min(D(z),h)dz
      <= b_* W, b_*=(D0+Delta)/2.                         (3)

The actual normal-terminal measure at generation j, restricted to no earlier D0edge, is a submeasure of G_j^0(du)pi_u(dz)bbar_z(u). All history and stopping restrictions only reduce its mass. Consequently

    T_j^0<=c_col^j b_*W.

There are at most N actual visits, hence

    F_noD=sum_(j<N) T_j^0
      <=b_* W sum_(j<N)c_col^j
      <=C_noD W,
    C_noD=b_*/(1-c_col)<= (8/5)b_*.                      (4)

F_noD here includes ALL normal terminals of the new R360 path before its final terminal direction-source split. It is a directly paid portion of the original marked traffic. It does not require a favourable terminal face-coordinate distribution, an a priori source load bound, or an estimate of cumulative g. There is no guaranteed positive or fixed fraction of terminal mass in F_noD for every input; such a claim is not needed for (4).

This is one source bill for all generations before the first D0edge. It does not assert that the corresponding bill can be charged again after every disjoint jump. Existing rich, inner, recapture, high-face and earlier entrance fees are unchanged and are not charged a second time.

## 4. First-disjoint-edge flux retains its actual source and history

Let V_j^D be the source-labelled measure of a path's FIRST D0edge continuation from its j-th nonrich arrival. Its current source is the genuine full-f posterior. From (2), after projecting earlier histories but retaining u,z,v,

    V_j^D(du,dz,dv)
      <=c_col^j sigma(du)pi_u(dz)Qbar_z(u,dv)1_D0edge.

Therefore the complete first-D flux obeys

    V^D <= (1-c_col)^(-1)
             f(z)dz xi_z(du)Qbar_z(u,dv)1_D0edge,          (5)
    (V^D)_target<=sigma/(1-c_col).                         (6)

Its full history can be carried by the original conditional disintegration; no claim is made that (5) identifies that conditional law. The mass after the first D can undergo further D jumps and all old source/history tests. Equations (5)–(6) do NOT grant new initial-cross or core qualifications at that target and do not authorize repeating earlier payments. They supply a priced common-source entrance for the still-unpaid suffix.

## 5. Recompute terminal source direction columns after this payment

Let F_norm be the total new normally terminated flow (after the all-path high-face stops, before terminal direction deletion). The actual normal paths split exactly as

    F_norm=F_noD+F_atleastD_raw.

Only NOW define L_D(z), L_D,i(z) from the actual terminal source marginal of F_atleastD_raw. Its per-generation source/receiver density remains a positive restriction of f(z)c_u(z)q_u/m_u, so the old one-coordinate capacity proves L_D,i<=N B1. Delete whole terminal source columns where max_i L_D,i>=L_D/log(n+2). This has fee at most C_dir W=N B1 log(n+2)W. Define the remaining actual terminal mass as F_D. Then

    F_norm = F_noD + F_D,dir + F_D,
    F_D,dir<=C_dir W,
    L_D,i,new < L_D,new/log(n+2) on every positive column.

This reordering is necessary. Removing noD paths AFTER fixing the old terminal direction source set could destroy the direction ratio of the new remaining columns. We make no such inference. All remaining tuples still have 1<=face count<m; every remaining path has at least one actual D0edge continuation.

For n>=2^32, the R360 migration ledger is thus modified by replacing its terminal direction split with the three terms above. It adds only C_noD W and replaces its old unpaid normal-direction remainder by the newly defined F_D. There is still no X_q absorption addition. The normal-source rank capacity (3) is paid once here, not at every visit.

For 1<=n<2^32, one may instead pay the entire F_norm directly by N b_*W<=12nW<=786432 sqrt(n)W, and omit the terminal direction split entirely. This bounded-dimensional treatment concerns only this hard remainder, not all the other global slots. For a unified conservative written inequality retaining C_dir W, that unused positive fee may remain; it is not a charge for a second real event.

The first-D suffix F_D remains unbounded at root order in unbounded dimensions. It is not paid by (5), which bounds its initial density but not the total terminal source expense. A source-shared terminal potential or an estimate using the original capture square is still needed; the user PDF explicitly cautions against confusing these two statements.

## 6. Reproducible exact first-event checks

The following standard-library Fraction code checks the proof mechanism on finite substochastic DAGs. It independently enumerates paths, labels the first D, and compares whole-terminal/noD/afterD masses and first-D target flux to their matrix sums. It checks geometric column occupation and the terminal sum bound, including D empty, nonempty, horizon endpoints and nonuniform input. These are finite algebra diagnostics, NOT actual cube hard-branch realizations.

```python
from fractions import Fraction as F
from itertools import product
count=0
for n,aa,dd in product(range(2,10),[F(1,8),F(1,4),F(3,8)],[F(0),F(1,8),F(1,4)]):
    A=[[F(0)]*n for _ in range(n)];D=[[F(0)]*n for _ in range(n)]
    for u in range(n):
        if u+1<n:A[u][u+1]=aa
        if u+2<n:D[u][u+2]=dd
    K=[[A[u][v]+D[u][v] for v in range(n)] for u in range(n)]
    i=[F(u+1,n+1) for u in range(n)]
    beta=[(1-sum(K[u]))/F(u+2) for u in range(n)]
    b=sum(beta)
    ga=i[:];f0=F(0);first=[F(0)]*n
    for j in range(n):
        assert all(0<=x<=aa**j for x in ga);count+=1
        f0+=sum(ga[u]*beta[u] for u in range(n))
        for v in range(n):first[v]+=sum(ga[u]*D[u][v] for u in range(n))
        ga=[sum(ga[u]*A[u][v] for u in range(n)) for v in range(n)]
    assert all(x==0 for x in ga);count+=1
    assert f0<=b/(1-aa);count+=1
    assert all(x<=1/(1-aa) for x in first);count+=1
    value=[F(0)]*n
    for u in reversed(range(n)):
        value[u]=beta[u]+sum(K[u][v]*value[v] for v in range(u+1,n))
    assert all(0<=x<=1 for x in value);count+=1
    actual=[F(0),F(0)];first2=[F(0)]*n
    def walk(u,mass,seen):
        actual[int(seen)]+=mass*beta[u]
        for v in range(u+1,n):
            if A[u][v]:walk(v,mass*A[u][v],seen)
            if D[u][v]:
                if not seen:first2[v]+=mass*D[u][v]
                walk(v,mass*D[u][v],True)
    for u in range(n):walk(u,i[u],False)
    assert actual[0]==f0;count+=1
    assert first2==first;count+=1
    assert actual[1]==sum(first[v]*value[v] for v in range(n));count+=1
    assert sum(actual)==sum(i[u]*value[u] for u in range(n));count+=1
print('PASS first-D terminal column checks',count)
```

The code is embedded to avoid redundant archive files. The finite simulations certify no independence or geometric realization beyond their declared DAG model. The full marked-process proof is (1)–(6).

Source PDF SHA256: `7e3b8945aedcdb2526f307d86aec049fc9e1b90c9ecb123ff98f170d1cea4863`; 6 pages; supplied by user during R360. Source path: /tmp/codex-remote-attachments/01a0f8e4-abcb-79c0-ad4a-6f6c81ce2ed5/959F08EC-DB03-4826-9E2F-3C7795BA2F58/1-Pro第355轮后攻坚路线建议_20261018-2.pdf
