"""Run the five independent R829 certificates on the unmodified R814 archive."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import platform
import re
import subprocess
import sys
import flint

ROOT = Path(__file__).resolve().parent
PIN = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"

def run(job):
    script, arguments = job
    result = subprocess.run([sys.executable, "-E", "-B", str(ROOT / script), *arguments],
                            cwd=ROOT, stdout=subprocess.PIPE, text=True, check=True)
    # Elapsed seconds is the only machine-dependent measurement in this script.
    output = re.sub(r"; seconds=\s+[\d.]+(?=\s*$)", "", result.stdout.rstrip())
    return script, output

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--r814", required=True, type=Path)
    parser.add_argument("--jobs", type=int, default=5, choices=range(1,6))
    options = parser.parse_args()
    archive = options.r814.resolve()
    assert sha256(archive.read_bytes()).hexdigest() == PIN
    path = str(archive)
    jobs = [("dualcell829.py", ["--archive", path, "--rows"]),
            ("exterior829.py", ["--r814", path, "--full"]),
            ("shares829.py", ["--archive", path]),
            ("joint829.py", ["--r814", path, "--full"]),
            ("cover829.py", ["--compact"])]
    print("Python", platform.python_version(), "python-flint", flint.__version__,
          "FLINT", flint.__FLINT_VERSION__, "input R814", PIN)
    with ThreadPoolExecutor(max_workers=options.jobs) as workers:
        for script, results in workers.map(run, jobs):
            print(script, results, sep="\n")
    print("PASS R829 original source capacity, receiver geometry and hard-cut replay")

if __name__ == "__main__":
    main()
