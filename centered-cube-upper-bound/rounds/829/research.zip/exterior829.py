"""Exact true-source exterior sums and radial gates on both R814 cross fixtures."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import json
from math import factorial, prod
from pathlib import Path
import platform
from zipfile import ZipFile

from flint import arb, ctx
import flint


PIN = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
CUTS = tuple(map(F, ("0", "1/128", "1/32", "1/8", "1/4", "1/2", "1", "2")))
RADIAL = tuple(map(F, ("1/128", "1/32", "1/4", "1/2", "3/4", "1", "5/4", "3/2", "2")))
DIMS = (32, 512, 8192, 2**19, 2**22, 2**26)
TILTS = tuple(map(F, ("1/4", "1/2", "1", "2", "4", "8")))
GRID = 10**6
ZERO = F(0)
ONE = F(1)


def read_models(path):
    assert sha256(path.read_bytes()).hexdigest() == PIN
    with ZipFile(path) as archive:
        mod = {"__name__": "pinned814"}
        exec(compile(archive.read("comb811.py"), "comb811.py", "exec"), mod)
        original = mod["fixture"](*mod["FIXTURES"][-1])
        rebuilt = json.loads(archive.read("comb814-rebuilt.json"))["stages"][0]
    return mod, (("original", original), ("rebuilt", rebuilt))


def clipped_mass_parts(domain, density):
    lo, hi = domain
    a, b = map(F, density["support"])
    lo, hi = max(lo,a), min(hi,b)
    assert lo < hi
    phase = F(density["bump_center_mod_period"])
    period = F(density["period"])
    width = F(density["bump_half_width"])
    floor = F(density["density_floor_one_axis"])
    height = F(density["density_peak_one_axis"])-floor
    intervals = [(lo,hi,floor)]
    for j in range(lo//period-1, hi//period+2):
        a = max(lo, j*period+phase-width)
        b = min(hi, j*period+phase+width)
        if a < b:
            intervals.append((a,b,height))
    return intervals


def exterior_law(domain, center, radius, density, primitive):
    """Map the normalized one-axis comb to its exterior excess, with a real atom at 0."""
    weights = defaultdict(F)
    base = sum((b-a)*h for a,b,h in clipped_mass_parts(domain,density))
    assert base == primitive(*domain) > 0
    left, right = center-radius, center+radius
    for a,b,h in clipped_mass_parts(domain,density):
        if a < left:
            endpoint = min(b,left)
            weights[(left-endpoint)/radius, (left-a)/radius] += (endpoint-a)*h/base
        inside = min(b,right)-max(a,left)
        if inside > 0:
            weights[(ZERO,ZERO)] += inside*h/base
        if b > right:
            endpoint = max(a,right)
            weights[(endpoint-right)/radius, (b-right)/radius] += (b-endpoint)*h/base
    assert sum(weights.values()) == 1
    law = tuple((lo,hi,mass) for (lo,hi),mass in sorted(weights.items()) if mass)
    assert all(0 <= lo <= hi and mass > 0 for lo,hi,mass in law)
    return base, law


def convolution_signature(axes):
    """Signed shifted powers evaluating the exact sum CDF, including zero atoms."""
    old = {(0,ZERO): ONE}
    for law in axes:
        primitive = defaultdict(F)
        for lo, hi, w in law:
            if lo == hi:
                primitive[0,lo] += w
            else:
                h = w/(hi-lo)
                primitive[1,lo] += h
                primitive[1,hi] -= h
        new = defaultdict(F)
        for (i,a), x in old.items():
            for (j,b), y in primitive.items():
                if y:
                    new[i+j,a+b] += x*y
        old = {key: x for key,x in new.items() if x}
    return tuple(sorted(old.items()))


def cdf_sum(signature, cutoff, integral=False):
    offset = int(integral)
    return sum((coefficient*(cutoff-shift)**(degree+offset)/factorial(degree+offset)
                for (degree,shift),coefficient in signature if shift <= cutoff), ZERO)


def cdf_axis(law, cutoff):
    return sum((mass*(int(cutoff >= lo) if lo == hi
                      else max(ZERO,min(cutoff,hi)-lo)/(hi-lo))
                for lo,hi,mass in law), ZERO)


def cdf_radial(axes, cutoff):
    return prod(cdf_axis(axis,cutoff) for axis in axes)


def exact_sanity():
    unit = ((ZERO,ONE,ONE),)
    mix = ((ZERO,ZERO,F(1,2)), (ZERO,ONE,F(1,2)))
    all_uniform = convolution_signature((unit,)*4)
    all_mixed = convolution_signature((mix,)*4)
    assert tuple(cdf_sum(all_uniform,F(j)) for j in range(5)) == (
        0,F(1,24),F(1,2),F(23,24),1
    )
    assert cdf_sum(all_mixed,ZERO) == F(1,16)
    assert cdf_sum(all_mixed,F(1)) == (1+4+F(6,2)+F(4,6)+F(1,24))/16
    assert 4-cdf_sum(all_mixed,F(4),integral=True) == 1


def as_box(parent):
    return tuple(tuple(map(F,interval)) for interval in parent["box"])


def row_model(t, u, density, primitive):
    small = as_box(u)
    radius = F(t["radius"])
    center = tuple(map(F,t["center"]))
    axes_raw = [exterior_law(domain,c,radius,density,primitive) for domain,c in zip(small,center)]
    assert prod(base for base,_ in axes_raw) == F(u["m"])
    axes = tuple(axis for _,axis in axes_raw)
    sig = convolution_signature(axes)
    mean = sum(mass*(lo+hi)/2 for axis in axes for lo,hi,mass in axis)
    sup = tuple(max(hi for _,hi,_ in axis) for axis in axes)
    assert cdf_sum(sig,sum(sup)) == 1
    # Independent first moment from the integrated full joint CDF.
    assert sum(sup)-cdf_sum(sig,sum(sup),integral=True) == mean
    values = tuple(cdf_sum(sig,x) for x in CUTS)
    radial_same = tuple(cdf_radial(axes,x) for x in CUTS)
    radial_split = tuple(cdf_radial(axes,x/4) for x in CUTS)
    assert all(0 <= a <= b <= c <= 1 for a,b,c in zip(radial_split,values,radial_same))
    assert all(a <= b for a,b in zip(values,values[1:]))
    for h,p in zip((*CUTS,*RADIAL),(*radial_same,*(cdf_radial(axes,x) for x in RADIAL))):
        expanded = prod(primitive(max(a,c-radius*(1+h)), min(b,c+radius*(1+h)))
                        for (a,b),c in zip(small,center))
        assert p == expanded/F(u["m"])
    original_overlap = prod(primitive(max(a,c-radius),min(b,c+radius))
                            for (a,b),c in zip(small,center))
    assert values[0] == original_overlap/F(u["m"])
    return {"axes":axes,"signature":sig,"mean":mean,"sup":sup,"sum":values,
            "same":radial_same,"split":radial_split}


def exact_models(mod, stages, digest, full):
    out = {}
    print("CUTS", *CUTS)
    for name, stage in stages:
        assert stage["dimension"] == 4
        density = stage["density"]
        width = F(density["bump_half_width"])
        assert F(density["period"]) == mod["PERIOD"]
        assert F(density["density_floor_one_axis"]) == mod["FLOOR"]
        assert F(density["density_peak_one_axis"]) == mod["comb_density_peak"](width)
        def primitive(a,b):
            return mod["interval_mass"](a,b,width)
        parents = {p["id"]:p for p in stage["parents"]}
        total = F(stage["benchmarks"]["cross"]["mother"])
        rows = {}
        geom = {}
        for root in stage["roots_cross"]:
            key = tuple(root[x] for x in ("t","u","g"))
            t,u,g = key
            if (t,u) not in geom:
                geom[t,u] = row_model(parents[t],parents[u],density,primitive)
            model = geom[t,u]
            weight = F(root["root_mass"])/total
            coeff = F(root["coefficient"])
            def overlap(p,q):
                return prod(primitive(max(a,b), min(c,d))
                            for (a,c),(b,d) in zip(as_box(p),as_box(q)))
            assert weight*total == coeff*overlap(parents[t],parents[u])*overlap(parents[t],parents[g])
            rows[key] = (weight, model)
            digest.update(repr((name,key,weight,model)).encode("ascii"))
            if full:
                print("ROW", name, *key, "weight", show(weight), "mean", show(model["mean"]),
                      "radial_sup", show(max(model["sup"])), "sum", *map(show,model["sum"]),
                      "radial", *map(show,model["same"]))
        assert len(rows) == 34 and sum(w for w,_ in rows.values()) == 1
        minimum = min(data["mean"] for _,data in rows.values())
        maximum = max(data["mean"] for _,data in rows.values())
        print("MEAN", name, "mean4", show(sum(w*data["mean"] for w,data in rows.values())),
              "min4", minimum, show(minimum), "max4", show(maximum),
              "zero-mean-rows", sum(data["mean"] == 0 for _,data in rows.values()), flush=True)
        min_support = min(max(data["sup"]) for _,data in rows.values())
        max_support = max(max(data["sup"]) for _,data in rows.values())
        print("RADIAL-SUPPORT", name, "minmax", min_support, max_support)
        for label in ("sum","same","split"):
            print("WEIGHTED-CDF", name, label, *(show(sum(w*data[label][i] for w,data in rows.values()))
                                                 for i in range(len(CUTS))))
        print("RADIAL-LIMIT", name, *(f"{h}:{show(sum(w for w,data in rows.values() if max(data['sup'])<=h))}"
                                         for h in RADIAL))
        out[name] = rows
    assert set(out["original"]) == set(out["rebuilt"])
    for label in ("sum","same"):
        change = [max(abs(out["original"][key][1][label][i]-out["rebuilt"][key][1][label][i])
                      for key in out["original"]) for i in range(len(CUTS))]
        print("PAIRED MAX-CHANGE", label, *map(show,change))
    return out


def show(value):
    return format(float(value), ".11g")


def ar(value):
    return arb(value.numerator)/value.denominator


def laplace_axis(axis, tilt):
    s = ar(tilt)
    result = arb(0)
    for lo,hi,mass in axis:
        low = (-s*ar(lo)).exp()
        if lo == hi:
            result += ar(mass)*low
        else:
            step = s*ar(hi-lo)
            result -= ar(mass)*low*(-step).expm1()/step
    return result


def laplace_signed(signature, tilt):
    s = ar(tilt)
    return sum((ar(weight)*(-s*ar(shift)).exp()/s**degree
                for (degree,shift),weight in signature), arb(0))


def log_upper(x):
    return int((x*GRID).upper().ceil().unique_fmpz())


def analytic_bounds(models, digest):
    for name, rows in models.items():
        distinct = list(dict.fromkeys(tuple(data.items()) for _,data in rows.values()))
        distinct = [dict(items) for items in distinct]
        approx = {}
        for bits in (192,320):
            ctx.prec = bits
            laps = []
            for data in distinct:
                row = []
                for tilt in TILTS:
                    l = prod(laplace_axis(axis,tilt) for axis in data["axes"])
                    assert l.overlaps(laplace_signed(data["signature"],tilt))
                    assert 0 < l < 1
                    row.append(l.log())
                laps.append(tuple(row))
            bounds = {}
            for n in DIMS:
                for c in (1,4,16):
                    B = c*arb(n+2).log()**4
                    worst = max(min(log_upper(ar(s)*B+(n//4)*logM) for s,logM in zip(TILTS,row))
                                for row in laps)
                    bounds[n,c] = min(0,worst)
            approx[bits] = bounds
        for n in DIMS:
            lower_tail = tuple(min(approx[192][n,c],approx[320][n,c]) for c in (1,4,16))
            assert all(a <= b for a,b in zip(lower_tail,lower_tail[1:]))
            print("SUMLOG", name, n, *lower_tail, flush=True)
            digest.update(repr((name,n,lower_tail)).encode("ascii"))
            radial_logs = []
            for h in RADIAL:
                pmax = max(cdf_radial(data["axes"],h) for data in distinct)
                value = None if pmax == 0 else log_upper((n//4)*ar(pmax).log())
                radial_logs.append(value)
            print("RADIALLOG", name, n, *radial_logs)
            digest.update(repr((name,n,radial_logs)).encode("ascii"))
    print("SUMLOG upper bounds for ln Pr(E_n <= c log^4(n+2)) at c=1,4,16,",
          "RADIALLOG upper bounds for ln Pr(max exterior <= listed RADIAL-LIMIT cut), scaled by 10^6;",
          "worst conditional row, None means exact zero. Four independent original-coordinate laws per repeated copy.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--r814", type=Path, required=True)
    parser.add_argument("--full", action="store_true")
    args = parser.parse_args()
    assert __debug__, "Run with assertions enabled"
    print("Python", platform.python_version(), "python-flint", flint.__version__,
          "FLINT", flint.__FLINT_VERSION__, "pinned R814", PIN)
    exact_sanity()
    mod, stages = read_models(args.r814)
    digest = sha256()
    models = exact_models(mod,stages,digest,args.full)
    analytic_bounds(models,digest)
    print("PASS exterior source flow, transcript SHA-256", digest.hexdigest())


if __name__ == "__main__":
    main()
