"""Round 829. Exact q-blind L1 grid cover, true R819 blocks, and Arb early gate.

Run with python-flint installed. Output is deterministic JSON on stdout.
The late-source tests use the essential infimum over the stated receiver set.
The eligibility flag h <= n is reported separately from the scalar inequality.
"""
import argparse
import json
from fractions import Fraction as Q
from itertools import product
from math import comb, factorial, prod

import flint
from flint import arb, ctx


def ball_count(n, cutoff):
    return sum(2**j * comb(n, j) * comb(cutoff, j)
               for j in range(min(n, cutoff) + 1))


def code_index(q, ref, width):
    # int on a Fraction truncates toward zero, including both signs at zero.
    return tuple(int((a - b) / width) for a, b in zip(q, ref))


def exact_grid_tests():
    count_rows = {}
    total_points = 0
    for n in range(1, 6):
        rows = []
        for k in (0, 1, 2, 3, 4, 6):
            counts = [0] * (min(k, n) + 1)

            def visit(prefix, left):
                if len(prefix) == n:
                    counts[sum(v != 0 for v in prefix)] += 1
                    return
                for v in range(-left, left + 1):
                    visit(prefix + (v,), left - abs(v))

            visit((), k)
            expected = [2**j * comb(n, j) * comb(k, j) for j in range(len(counts))]
            assert counts == expected and sum(counts) == ball_count(n, k)
            total_points += sum(counts)
            rows.append([k, sum(counts)])
        count_rows[n] = rows
    xvals = [Q(i, 4) for i in range(-16, 17)]
    assert [int(x) for x in (Q(-1), Q(-3, 4), Q(0), Q(3, 4), Q(1))] == [-1, 0, 0, 0, 1]
    cells = {}
    for v in product(xvals, repeat=2):
        if sum(map(abs, v)) <= Q(7, 2):
            j = code_index(v, (0, 0), Q(1))
            assert sum(map(abs, j)) <= 3
            cells.setdefault(j, []).append(v)
    assert len(cells) == ball_count(2, 3)
    for j, entries in cells.items():
        for i in range(2):
            diameter = max(v[i] for v in entries) - min(v[i] for v in entries)
            assert diameter <= (1 if j[i] else 2)
    return {"counts_by_dimension": count_rows, "enumerated_indices": total_points,
            "fractional_cutoff": "7/2", "fractional_positive_grid_cells": len(cells)}


def box_ball_volume(center, delta, ref, radius):
    # An exact integral over true (Lebesgue, constant-density) q in a cube.
    # Partition into signed orthants about ref, then clip each simplex.
    n = len(center)
    if any(abs(a - b) > delta for a, b in zip(ref, center)):
        if sum(max(Q(0), abs(a - b) - delta) for a, b in zip(ref, center)) > radius:
            return Q(0)
        raise ValueError("non-disjoint external reference in this fixture")
    ans = Q(0)
    for bits in product((-1, 1), repeat=n):
        lengths = [delta + sign * (c - r) for c, r, sign in zip(center, ref, bits)]
        for mask in range(1 << n):
            d = sum((v for i, v in enumerate(lengths) if mask >> i & 1), Q(0))
            ans += (-1)**mask.bit_count() * max(Q(0), radius - d)**n
    return ans / factorial(n)


def array_point(center, delta, numerators, denominator):
    return tuple(c + Q(numerators[i % len(numerators)], denominator) * delta
                 for i, c in enumerate(center))


def positive_fixture(n):
    # Same positive blocks and disjoint true receivers as R819 recapture819.py.
    delta, side = Q(1, 100*n), Q(2)
    blocks = {j: (Q(3*j, 2),) + (Q(0),) * (n-1) for j in (-1, 0, 1)}
    block_mass = 2**(n-1)
    assert (3-2*delta)**n > 3*block_mass and (side-2*delta)**n < 2*block_mass
    tested = accepted = rejected = zero_cells = 0
    mass_rows = []
    for pair in ((-1, 0), (0, 1)):
        x = tuple((a+b)/2 for a, b in zip(blocks[pair[0]], blocks[pair[1]]))
        for j in pair:
            assert max(abs(a-b)+delta for a,b in zip(blocks[j], x)) <= side/2-delta
        far = next(j for j in blocks if j not in pair)
        assert 2*(max(abs(a-b) for a,b in zip(blocks[far], x))-delta) > 3-2*delta
        assert 2*block_mass == side**n
        for anchor in pair:
            p = array_point(blocks[anchor], delta, (-1, 1, 0), 3)
            other = next(j for j in pair if j != anchor)
            # This complete menu is chosen from x and p before sampling q.
            refs = (p, array_point(blocks[other], delta, (1, -1), 2))
            for size in (1, 2):
                for kind, u in (("partial", delta/2), ("full", Q(1, 100))):
                    rho = delta/4
                    width, budget = rho*side, u*side
                    k = u // rho
                    # The two positive blocks and their reference balls are disjoint.
                    assert 2*budget < abs(blocks[pair[0]][0]-blocks[pair[1]][0])-2*delta
                    volume = sum((box_ball_volume(blocks[j], delta, r, budget)
                                  for j in pair for r in refs[:size]), Q(0))
                    probability = volume / (2*(2*delta)**n)
                    if kind == "full":
                        assert probability == Q(size, 2)
                    else:
                        assert 0 < probability < Q(size, 2)
                    mass_rows.append({"branch": list(pair), "anchor_block": anchor,
                                      "M": size, "budget": kind, "cutoff": k,
                                      "true_conditional_fraction": str(probability)})
                    for j in pair:
                        for numerators in ((0,), (1,-1), (-2,1,0), (2,-2,1)):
                            q = array_point(blocks[j], delta, numerators, 3)
                            assert max(abs(a-b) for a,b in zip(q, blocks[j])) < delta
                            for r in refs[:size]:
                                tested += 1
                                code = code_index(q, r, width)
                                if sum(abs(a-b) for a,b in zip(q,r)) <= budget:
                                    accepted += 1
                                    zero_cells += int(not any(code))
                                    assert sum(map(abs, code)) <= k
                                    assert all(abs(a-b-val*width) < width
                                               for a,b,val in zip(q,r,code))
                                else:
                                    rejected += 1
    assert accepted and rejected and zero_cells
    return {"n": n, "true_side": str(side), "source_halfside": str(delta),
            "point_reference_memberships": tested, "inside": accepted, "outside": rejected,
            "accepted_zero_code": zero_cells, "true_q_mass_rows": mass_rows}


def late_test():
    # R819 variable-price data. The declared F consists only of these two boxes.
    delta = Q(1, 10000)
    pos, mass = (Q(-3,2), Q(0), Q(7,4)), (Q(1), Q(1), Q(3,2))
    roots = []
    for indices, side in (((0,1), Q(2)), ((1,2), Q(5,2))):
        lo = max(pos[j] for j in indices) - side/2 + 2*delta
        hi = min(pos[j] for j in indices) + side/2 - 2*delta
        far = next(j for j in range(3) if j not in indices)
        assert sum(mass[j] for j in indices) == side
        assert all(max(abs(lo-pos[j]),abs(hi-pos[j]))+delta <= side/2-delta
                   for j in indices)
        assert 2*(max(lo-pos[far],pos[far]-hi)-delta) > sum(mass)
        roots.append((indices, side, hi-lo))
    tau = tuple(min(t for ids,t,_ in roots if j in ids) for j in range(3))
    assert tau == (Q(2), Q(2), Q(5,2))
    result = []
    for multiplier in (Q(9,8), Q(5,4), Q(3,2)):
        rows = []
        for subset in range(1,8):
            one_late = two_late = nonlate = Q(0)
            cut_mass = sum(mass[j] for j in range(3) if subset >> j & 1)
            for ids,t,area in roots:
                in_cut = [j for j in ids if subset >> j & 1]
                p_cut = sum((mass[j] for j in in_cut), Q(0))/t
                p_late = sum((mass[j] for j in in_cut if t < multiplier*tau[j]), Q(0))/t
                one_late += area*p_late
                two_late += area*p_cut*p_late
                nonlate += area*(p_cut-p_late)
            assert two_late <= one_late <= cut_mass
            rows.append((subset, one_late, two_late, nonlate, cut_mass))
        worst = max(r[1]/r[4] for r in rows)
        result.append({"exp_h": str(multiplier), "cuts_verified": len(rows),
                       "whole_cut_late": str(rows[-1][1]), "whole_cut_nonlate": str(rows[-1][3]),
                       "maximum_late_per_cut_mass": str(worst)})
    assert result[0]["whole_cut_nonlate"] == result[1]["whole_cut_nonlate"] == "937/3125"
    assert result[2]["whole_cut_nonlate"] == "0"
    return {"tau_over_selected_receivers": [str(t) for t in tau], "cases": result}


def A(x):
    z = Q(x)
    return arb(z.numerator)/z.denominator


def profile(label, L):
    n = L*L
    if label == "small_menu":
        return n, Q(1,L), Q(3,2*L), 1
    if label == "polynomial_menu":
        return n, Q(1,L), Q(7,2*L), n+2
    if label == "fixed_radius":
        return n, Q(1,L), Q(1,4), n+2
    if label == "ineligible_control":
        return n, Q(1,16), Q(1,8), 1
    raise ValueError(label)


def sign_cert(value):
    if value > 0:
        return 1
    if value < 0:
        return -1
    if value.is_zero():
        return 0
    raise ArithmeticError("Arb interval touches a decision boundary")


def gate(label, L):
    n, rho, u, M = profile(label, L)
    K = u // rho
    N = ball_count(n, K)
    logMN = A(M*N).log()
    logn = A(n+2).log()
    r = A(rho)
    cost = n*r + logMN
    h = 16*n*r + 8*logMN + 64*logn
    log_scaled_gate = logMN + n*((-h/n).exp()+4*r).log() + 4*logn
    eligible = sign_cert(h-n) <= 0
    passes = sign_cert(log_scaled_gate) <= 0
    if eligible:
        crude = logMN - h/2 + 4*n*r + 4*logn
        assert log_scaled_gate < crude and crude < 0 and passes
    return {"n": n, "rho": str(rho), "u": str(u), "M": M, "K": K,
            "Ncover_bits": N.bit_length(), "Ncover": str(N) if N.bit_length() <= 100 else None,
            "cost": cost.str(16), "h_over_n": (h/n).str(16),
            "log_gate_over_target": log_scaled_gate.str(16),
            "h_le_n": eligible, "actual_scalar_gate": passes,
            "eligible_and_gate": eligible and passes}


def gate_tests(precision):
    ctx.prec = precision
    profiles = ("small_menu", "polynomial_menu", "fixed_radius", "ineligible_control")
    tested_L = (4, 8, 16, 32, 64, 128, 256, 512, 1024)
    details = {name:[gate(name,L) for L in tested_L] for name in profiles}
    thresholds = {}
    for name in profiles:
        flags = [gate(name,L)["eligible_and_gate"] for L in range(2,129)]
        position = next((i for i,flag in enumerate(flags) if flag), None)
        if position is None:
            assert not any(flags)
        else:
            assert all(flags[position:]) and not any(flags[:position])
        thresholds[name] = None if position is None else (position+2)**2
    return {"precision_bits": precision, "threshold_scan_all_L": [2,128],
            "first_eligible_square_in_scan": thresholds, "parameter_rows": details}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compact", action="store_true",
                        help="summarize the two-precision checks after verifying all rows")
    args = parser.parse_args()
    exact = exact_grid_tests()
    boxes = [positive_fixture(n) for n in (2,3,4)]
    late = late_test()
    low = gate_tests(192)
    high = gate_tests(320)
    assert low["first_eligible_square_in_scan"] == high["first_eligible_square_in_scan"]
    for mode in low["parameter_rows"]:
        for u,v in zip(low["parameter_rows"][mode], high["parameter_rows"][mode]):
            for key in ("n","Ncover_bits","actual_scalar_gate","h_le_n","eligible_and_gate"):
                assert u[key] == v[key]
    if args.compact:
        print(json.dumps({
            "exact_grid": exact, "positive_block_tests":
                [{"n": r["n"], "inside": r["inside"], "outside": r["outside"],
                  "zero": r["accepted_zero_code"],
                  "q_fractions": sorted({row["true_conditional_fraction"] for row in r["true_q_mass_rows"]})}
                 for r in boxes],
            "late": late, "arb_bits": [192,320], "gate_thresholds": high["first_eligible_square_in_scan"],
            "gate_examples": {name:[row for row in values if row["n"] in (16,1024,4096,1048576)]
                              for name,values in high["parameter_rows"].items()}
        }, ensure_ascii=False, indent=2))
    else:
        print(json.dumps({"exact_grid": exact, "real_positive_blocks": boxes, "real_late_flow": late,
                          "gate_192": low, "gate_320": high, "python_flint":flint.__version__},
                         ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
