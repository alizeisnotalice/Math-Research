"""Exact finite R814 source-share potential and peeling-order diagnostics.

j is the archived history weight (not substituted by owner volume). G_u=A_u;
mu is the true product-comb source measure. All 120 old-parent orders are
computed in Fraction; only the entropy logarithm uses outward Arb balls.
"""

import argparse, hashlib, json, zipfile
from collections import defaultdict
from fractions import Fraction as F
from itertools import permutations
from flint import arb, ctx
import flint

PIN = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
EPS = F(1, 2**30)


def arb_fraction(x):
    return arb(x.numerator) / x.denominator


def run(name, stage):
    parents = {p["id"]: p for p in stage["parents"]}
    old = tuple(sorted(p["id"] for p in stage["parents"] if p["role"] == "old"))
    middle = tuple(sorted(p["id"] for p in stage["parents"] if p["role"] == "middle"))
    cells = {c["mask"]: F(c["mass"]) for c in stage["cells"]}
    assert len(old) == 5 and len(middle) == 3
    mass = {u: F(parents[u]["m"]) for u in old}
    j = {u: F(parents[u]["j"]) for u in old}
    for u in old:
        assert mass[u] == sum(
            (v for mask, v in cells.items() if mask & parents[u]["bit"]), F(0)
        )
    load = defaultdict(F)
    for root in stage["roots_cross"]:
        load[root["u"]] += F(root["root_mass"])
    Gamma = sum(load.values(), F(0))
    J = sum(j.values(), F(0))
    assert (
        Gamma == F(stage["benchmarks"]["cross"]["mother"])
        and len(stage["roots_cross"]) == 34
    )

    def field(active, mask):
        return sum((j[u] / mass[u] for u in active if mask & parents[u]["bit"]), F(0))

    def share(u, active, excluded_t=None):
        return (
            sum(
                (
                    v / (EPS + field(active, mask))
                    for mask, v in cells.items()
                    if mask & parents[u]["bit"]
                    and (excluded_t is None or not mask & parents[excluded_t]["bit"])
                ),
                F(0),
            )
            / mass[u]
        )

    base = {u: share(u, old) for u in old}
    frozen = sum((j[u] * base[u] for u in old), F(0))
    # Total potential on the entire source support; zero-field cells add 0.
    ctx.prec = 256
    entropy = arb(0)
    for mask, mu in cells.items():
        f = field(old, mask)
        if f:
            entropy += arb_fraction(mu) * (1 + arb_fraction(f / EPS)).log()
    assert entropy > arb_fraction(frozen)
    # Simultaneous one-stage deletion equals the once-frozen charge. A separate
    # two-round batch demonstrates updating between batches.
    first = old[:2]
    second = old[2:]
    batch = sum((j[u] * share(u, old) for u in first), F(0)) + sum(
        (j[u] * share(u, second) for u in second), F(0)
    )
    assert frozen <= batch and entropy > arb_fraction(batch)
    print(
        "\nFIXTURE",
        name,
        "34 true rows, 230 source-cell pairs",
        "epsilon=",
        EPS,
        "Gamma=",
        Gamma,
        "j_sum=",
        J,
    )
    print(
        "source-count=",
        len(old),
        "entropy_Arb=",
        entropy.str(25),
        "frozen=simultaneous=",
        frozen,
        "~",
        float(frozen),
        "two_round_batch=",
        batch,
        "~",
        float(batch),
        "batch_partition=",
        first,
        second,
    )
    print(
        "parent diagnostics: archived j and |E| are reported separately; external = min over actual middle t"
    )
    chosen = []
    for u in old:
        external = min((share(u, old, t), t) for t in middle)
        # Both sides are dimensionless. The gate is a deterministic finite
        # heuristic, not an assertion of a high-dimensional theorem.
        relative_load = (load[u] / Gamma) / (j[u] / J)
        normalized_share = (j[u] / mass[u]) * base[u]
        gate = relative_load >= normalized_share
        if gate:
            chosen.append(u)
        print(
            "PARENT",
            u,
            "j=",
            j[u],
            "owner_volume=",
            parents[u]["owner_volume"],
            "Gamma_u/Gamma=",
            float(load[u] / Gamma),
            "h=",
            base[u],
            "h_external=",
            external[0],
            "external_attained_t=",
            external[1],
            "relative_load=",
            float(relative_load),
            "normalized_share=",
            float(normalized_share),
            "gate=",
            gate,
        )
    print(
        "HEURISTIC_GATE threshold relative_load >= (j_u/m_u)h_u; kept identities=",
        chosen,
        "kept_original_fraction=",
        float(sum((load[u] for u in chosen), F(0)) / Gamma),
        "no high-dimensional claim",
    )
    results = []
    for order in permutations(old):
        active = list(old)
        cost = F(0)
        remaining = []
        for u in order:
            cost += j[u] * share(u, active)
            active.remove(u)
            remaining.append(sum((load[x] for x in active), F(0)) / Gamma)
        assert frozen <= cost and entropy > arb_fraction(cost)
        results.append((cost, order, remaining))
        print(
            "ORDER",
            order,
            "cost~",
            float(cost),
            "remaining_Gamma_fraction=",
            *[float(x) for x in remaining],
            "exact_cost=",
            cost
        )
    assert len(results) == 120
    lo = min(results)
    hi = max(results)
    print(
        "ORDER_RANGE count=",
        len(results),
        "min=",
        lo[1],
        float(lo[0]),
        "max=",
        hi[1],
        float(hi[0]),
        "entropy~",
        float(entropy.mid()),
        "frozen~",
        float(frozen),
        "two_round~",
        float(batch),
    )
    print(
        "All entropy comparisons use 256-bit Arb enclosures. n=4 high-dimensional R813 gate is empty."
    )


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True)
args = parser.parse_args()
with open(args.archive, "rb") as f:
    assert hashlib.sha256(f.read()).hexdigest() == PIN
with zipfile.ZipFile(args.archive) as z:
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    ns = {"__name__": "archived_comb811"}
    exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
    name, n, h, middle, old = ns["FIXTURES"][-1]
    original = ns["fixture"](name, n, h, middle, old)
    print("python-flint=", flint.__version__, "FLINT=", flint.__FLINT_VERSION__)
    run("original", original)
    run("rebuilt", rebuilt)
print("\nPASS finite true-mu source-share and entropy checks; no asymptotic claim")
