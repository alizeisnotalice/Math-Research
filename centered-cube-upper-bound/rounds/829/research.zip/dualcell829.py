"""R814 exact new-p/old-z random translated-box discount comparison.

Each axis integrates the actual product-comb density; zero is retained.
The random centers are independent uniforms on lengths B,b. The whole-row
product follows from conditional independence of physical source coordinates.
"""

import argparse, json, zipfile, hashlib, time
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import prod, isqrt

PIN = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"


def positive4(x):
    return max(F(0), x) ** 4


def directional(a, b, c, d, h):
    """Integral over [a,b]x[c,d] of (x-y-h)_+²."""
    return (
        positive4(b - c - h)
        - positive4(a - c - h)
        - positive4(b - d - h)
        + positive4(a - d - h)
    ) / 12


def rectangle_abs_moment(a, b, c, d, h):
    val = directional(a, b, c, d, h) + directional(c, d, a, b, h)
    assert val >= 0
    return val


@lru_cache(None)
def parts(interval, period, phase, width, base, peak):
    a, b = interval
    edges = {a, b}
    for j in range(a // period - 2, b // period + 3):
        for point in (j * period + phase - width, j * period + phase + width):
            if a < point < b:
                edges.add(point)
    out = []
    xs = sorted(edges)
    for l, r in zip(xs, xs[1:]):
        mid = (l + r) / 2
        k = (mid - phase) // period
        ispeak = any(abs(mid - (phase + period * j)) < width for j in (k, k + 1))
        density = peak if ispeak else base
        out.append((l, r, density))
    return tuple(out)


@lru_cache(None)
def expected_F(I, J, B, b, period, phase, width, base, peak):
    assert B > 0 and b > 0
    left = parts(I, period, phase, width, base, peak)
    right = parts(J, period, phase, width, base, peak)
    ml = sum(((v - u) * rho for u, v, rho in left), F(0))
    mr = sum(((v - u) * rho for u, v, rho in right), F(0))
    assert ml > 0 and mr > 0
    total = F(0)
    for a, c, rho in left:
        for d, e, sigma in right:
            total += (
                rho
                * sigma
                * (
                    rectangle_abs_moment(a, c, d, e, F(0))
                    - rectangle_abs_moment(a, c, d, e, B)
                    - rectangle_abs_moment(a, c, d, e, b)
                    + rectangle_abs_moment(a, c, d, e, B + b)
                )
                / (2 * B * b)
            )
    result = total / (ml * mr)
    assert 0 <= result <= 1
    return result


def fourth_root_bracket(value):
    """Outward dyadic-rational bracket for an integer positive fourth root."""
    assert value.denominator == 1 and value > 0
    S = 2**20
    target = value.numerator * S**4
    k = isqrt(isqrt(target))
    assert k**4 <= target < (k + 1) ** 4
    return F(k, S), F(k, S) if k**4 == target else F(k + 1, S)


def directional_one(a, b, c, d, h):
    def P(x):
        return max(F(0), x) ** 3

    return (P(b - c - h) - P(a - c - h) - P(b - d - h) + P(a - d - h)) / 6


def abs_first_moment(a, b, c, d, h):
    return directional_one(a, b, c, d, h) + directional_one(c, d, a, b, h)


@lru_cache(None)
def expected_tent(I, J, B, period, phase, width, base, peak):
    """E[(1-|z-q|/B)_+] under the exact 1D source laws."""
    left = parts(I, period, phase, width, base, peak)
    right = parts(J, period, phase, width, base, peak)
    ml = sum(((b - a) * rho for a, b, rho in left), F(0))
    mr = sum(((b - a) * rho for a, b, rho in right), F(0))
    value = F(0)
    for a, b, rho in left:
        for c, d, sigma in right:
            cost = abs_first_moment(a, b, c, d, F(0)) - abs_first_moment(a, b, c, d, B)
            value += rho * sigma * ((b - a) * (d - c) - cost / B)
    result = value / (ml * mr)
    assert 0 <= result <= 1
    return result


def intersection(*spans):
    return (max(x[0] for x in spans), min(x[1] for x in spans))


def ceil_dyadic(x):
    k = x.numerator.bit_length() - x.denominator.bit_length()
    while F(2) ** k < x:
        k += 1
    while F(2) ** (k - 1) >= x:
        k -= 1
    return F(2) ** k


def run(name, stage):
    parents = {p["id"]: p for p in stage["parents"]}
    roots = stage["roots_cross"]
    den = stage["density"]
    assert (
        len(roots) == 34
        and sum(len(r["z_masks"]) * len(r["q_masks"]) for r in roots) == 230
    )
    M = sum((F(r["root_mass"]) for r in roots), F(0))
    assert M == F(stage["benchmarks"]["cross"]["mother"])
    args = tuple(
        F(den[k])
        for k in (
            "period",
            "bump_center_mod_period",
            "bump_half_width",
            "density_floor_one_axis",
            "density_peak_one_axis",
        )
    )
    acc = {
        mode: {"new": F(0), "old": F(0), "new_axes": [F(0)] * 4, "old_axes": [F(0)] * 4}
        for mode in ("physical", "owner_h", "bin_h_side_lower", "bin_h_side_upper")
    }
    positive_only = 0
    new_greater = 0
    sample = None
    direct_encounter = F(0)
    bin_bracket_verified = True
    for root in roots:
        t, u, g = (parents[root[k]] for k in ("t", "u", "g"))
        wt = F(root["root_mass"]) / M
        Bt = 2 * F(t["radius"])
        bu = 2 * F(u["radius"])
        assert Bt >= bu
        tbox = [tuple(map(F, v)) for v in t["box"]]
        ubox = [tuple(map(F, v)) for v in u["box"]]
        gbox = [tuple(map(F, v)) for v in g["box"]]
        qs = [intersection(tbox[j], gbox[j]) for j in range(4)]
        zs = [intersection(tbox[j], ubox[j]) for j in range(4)]
        assert all(a < b for a, b in qs + zs)
        h = F(129, 128)
        BTlo, BThi = fourth_root_bracket(2 * F(t["volume_bin"]))
        Bulo, Buhi = fourth_root_bracket(2 * F(u["volume_bin"]))
        assert BTlo <= BThi and Bulo <= Buhi
        assert BTlo**4 <= 2 * F(t["volume_bin"]) <= BThi**4
        assert Bulo**4 <= 2 * F(u["volume_bin"]) <= Buhi**4
        modes = {
            "physical": (Bt, bu),
            "owner_h": (Bt * h, bu * h),
            "bin_h_side_lower": (BTlo * h, Bulo * h),
            "bin_h_side_upper": (BThi * h, Buhi * h),
        }
        direct = prod(expected_tent(zs[j], qs[j], Bt, *args) for j in range(4))
        direct_encounter += wt * direct
        if CLI.rows:
            print(
                "DIRECT_ROW",
                name,
                (root["t"], root["u"], root["g"]),
                "old_original_center_encounter=",
                direct,
            )
        for mode, (B, b) in modes.items():
            ne = [expected_F(ubox[j], qs[j], B, b, *args) for j in range(4)]
            oe = [expected_F(zs[j], qs[j], B, b, *args) for j in range(4)]
            ncost = 1 - prod(1 - x for x in ne)
            ocost = 1 - prod(1 - x for x in oe)
            d = acc[mode]
            d["new"] += wt * ncost
            d["old"] += wt * ocost
            for j in range(4):
                d["new_axes"][j] += wt * ne[j]
                d["old_axes"][j] += wt * oe[j]
            if mode == "physical":
                positive_only += int(ncost > 0 and ocost == 0)
                new_greater += int(ncost > ocost)
                if sample is None and 0 < ne[0] < 1:
                    sample = (root["t"], root["u"], root["g"], Bt, bu, ne[0])
            if CLI.rows:
                print(
                    "ROW",
                    name,
                    (root["t"], root["u"], root["g"]),
                    "mode=",
                    mode,
                    "B,b=",
                    B,
                    b,
                    "weight=",
                    root["root_mass"],
                    "new_axis=",
                    *[str(v) for v in ne],
                    "old_axis=",
                    *[str(v) for v in oe],
                    "new_cost=",
                    ncost,
                    "old_cost=",
                    ocost
                )
    print(
        "\nSUMMARY",
        name,
        "roots=",
        len(roots),
        "positive_records=230",
        "true_original_mass=",
        M,
        "only_new_positive_rows=",
        positive_only,
        "new_gt_old_rows=",
        new_greater,
    )
    for mode, d in acc.items():
        print(
            "MODE",
            name,
            mode,
            "discount_new=",
            float(d["new"]),
            "discount_old=",
            float(d["old"]),
            "survival_new=",
            float(1 - d["new"]),
            "survival_old=",
            float(1 - d["old"]),
            "axis_new=",
            *[float(v) for v in d["new_axes"]],
            "axis_old=",
            *[float(v) for v in d["old_axes"]],
            "exact_new_old=",
            d["new"],
            d["old"]
        )
    # Larger lengths decrease F pointwise, hence upper/lower endpoints
    # enclose the exact irrational bin-expanded discount.
    assert acc["bin_h_side_upper"]["new"] <= acc["bin_h_side_lower"]["new"]
    assert acc["bin_h_side_upper"]["old"] <= acc["bin_h_side_lower"]["old"]
    print(
        "BIN_H_CERT",
        name,
        "new_discount_interval~",
        float(acc["bin_h_side_upper"]["new"]),
        float(acc["bin_h_side_lower"]["new"]),
        "old_discount_interval~",
        float(acc["bin_h_side_upper"]["old"]),
        float(acc["bin_h_side_lower"]["old"]),
        "side_bracket_width=2^-20 before factor h",
    )
    print(
        "OLD_DIRECT_ENCOUNTER",
        name,
        "exact=",
        direct_encounter,
        "approx=",
        float(direct_encounter),
    )
    # Independent 4D blocks enlarged to 8/16/32 coordinates: a diagnostic
    # product using one actual row's first-axis source law, not R814 high n.
    t, u, g, B, b, e = sample
    print(
        "BLOCK",
        name,
        "from actual row=",
        (t, u, g),
        "physical B,b=",
        B,
        b,
        "axis E[F]=",
        e,
    )
    for n in (4, 8, 16, 32):
        print(
            " BLOCK_n=",
            n,
            "survival=",
            (1 - e) ** n,
            "discount=",
            1 - (1 - e) ** n,
            "approx=",
            float(1 - (1 - e) ** n),
        )


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True)
parser.add_argument("--rows", action="store_true", help="print exact per-row results")
CLI = parser.parse_args()
assert rectangle_abs_moment(F(0), F(1), F(0), F(1), F(0)) == F(1, 6)
# Independent uniform-law checks: E F_1,1(|U-V|)=1/12 and E(1-|U-V|)=2/3.
unit_args = (F(2), F(0), F(1, 4), F(1), F(1))
assert expected_F((F(0), F(1)), (F(0), F(1)), F(1), F(1), *unit_args) == F(1, 12)
assert expected_tent((F(0), F(1)), (F(0), F(1)), F(1), *unit_args) == F(2, 3)
start = time.monotonic()
with open(CLI.archive, "rb") as f:
    assert hashlib.sha256(f.read()).hexdigest() == PIN
with zipfile.ZipFile(CLI.archive) as z:
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    ns = {"__name__": "archived_comb811"}
    exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
    name, n, h, middle, old = ns["FIXTURES"][-1]
    original = ns["fixture"](name, n, h, middle, old)
    run("original", original)
    run("rebuilt", rebuilt)
print(
    "\nPASS exact rational physical source integration; n=4 high-J gate empty; seconds=",
    round(time.monotonic() - start, 3),
)
