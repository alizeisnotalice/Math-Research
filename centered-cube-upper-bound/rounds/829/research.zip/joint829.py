"""Exact piecewise three-parent kernel and archived far-gate support checks."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import json
from math import factorial, isqrt
from pathlib import Path
import platform
from zipfile import ZipFile

from flint import arb, ctx
import flint


PIN = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
HALF = F(1,2)
ZERO = F(0)
GRID = 10**12


def profile(a,x):
    return max(ZERO,1-max(ZERO,abs(x)-HALF)/a)


def kernel(a,c,delta):
    knots = {-HALF-a,-HALF,HALF,HALF+a}
    knots.update(delta+x for x in (-HALF-c,-HALF,HALF,HALF+c))
    cuts = sorted(knots)
    total = ZERO
    for lo,hi in zip(cuts,cuts[1:]):
        f0,f1 = profile(a,lo), profile(a,hi)
        g0,g1 = profile(c,lo-delta), profile(c,hi-delta)
        total += (hi-lo)*(2*f0*g0+f0*g1+f1*g0+2*f1*g1)/6
    return total


def kernel_checks(digest):
    ratios = tuple(map(F,("1/64","1/16","1/8","1/4","1/3","1/2","3/4","1")))
    counts = [0,0,0]
    assert kernel(F(1),F(1),ZERO) == F(5,3)
    for a in ratios:
        for c in ratios:
            first = 1+max(a,c)
            far = 1+a+c-min(a,c)/2
            last = 1+a+c
            shifts = set(F(j,32) for j in range(0,129))
            shifts.update((first-F(1,4096),first,far,last-F(1,4096),last,last+F(1,4096)))
            for d in sorted(shifts):
                k = kernel(a,c,d)
                assert k == kernel(c,a,d) == kernel(a,c,-d)
                assert 0 <= k <= F(5,3)
                counts[0] += 1
                if d >= first:
                    assert k == max(ZERO,last-d)**3/(6*a*c)
                    counts[1] += 1
                if d >= far:
                    assert k <= F(1,48)
                    counts[2] += 1
                digest.update(repr((a,c,d,k)).encode("ascii"))
    print("KERNEL",*counts,"exact piecewise bounds, far cubic identities, and 1/48 tests")


def ar(x):
    return arb(x.numerator)/x.denominator


def grid_inside(x):
    lo=int((x*GRID).lower().floor().unique_fmpz())
    hi=int((x*GRID).upper().ceil().unique_fmpz())
    return lo,hi


def constant_check(digest):
    intervals = []
    for bits in (160,256):
        ctx.prec = bits
        lhs = arb(21)*(-arb(48).log()*5/6+ar(F(5,3)).log()/6).exp()
        rhs = (-arb(1)/12).exp()
        assert lhs < rhs
        intervals.append((*grid_inside(lhs),*grid_inside(rhs)))
    cert = tuple((max(row[j] for row in intervals) if j%2==0
                  else min(row[j] for row in intervals)) for j in range(4))
    assert cert[0] <= cert[1] < cert[2] <= cert[3]
    power6 = 21**6*F(5,3)/48**5
    taylor_lower = sum(((-HALF)**j/factorial(j) for j in range(6)),ZERO)
    assert power6 < taylor_lower
    print("CONSTANT 1e-12-grid lhs and rhs",*cert,
          "plus exact sixth-power comparison to degree-five alternating Taylor lower bound")
    digest.update(repr((cert,power6,taylor_lower)).encode("ascii"))


def read_models(path):
    assert sha256(path.read_bytes()).hexdigest() == PIN
    with ZipFile(path) as archive:
        module = {"__name__":"pinned814"}
        exec(compile(archive.read("comb811.py"),"comb811.py","exec"),module)
        original = module["fixture"](*module["FIXTURES"][-1])
        rebuilt = json.loads(archive.read("comb814-rebuilt.json"))["stages"][0]
    return (("original",original),("rebuilt",rebuilt))


def rational_root(x):
    p,q = isqrt(isqrt(x.numerator)), isqrt(isqrt(x.denominator))
    return F(p,q) if (p**4,q**4)==(x.numerator,x.denominator) else None


def far_support(t,u,g,h):
    widths = tuple(2*F(p["radius"]) for p in (t,u,g))
    bins = tuple(F(p["volume_bin"]) for p in (t,u,g))
    assert all(d <= b**4 < 2*d for d,b in zip(bins,widths))
    assert widths[1]<=widths[0] and widths[2]<=widths[0]
    assert bins[1]<=bins[0] and bins[2]<=bins[0]
    largest, smallest = max(widths[1:]), min(widths[1:])
    actual = widths[0]+largest+smallest/2
    Dmax,Dmin=max(bins[1:]),min(bins[1:])
    radicands = (2*bins[0],2*Dmax,2*Dmin)
    roots = tuple(rational_root(d) for d in radicands)
    exact_dyadic = h*(roots[0]+roots[1]+roots[2]/2) if None not in roots else None
    bu = tuple(tuple(map(F,ab)) for ab in u["box"])
    bg = tuple(tuple(map(F,ab)) for ab in g["box"])
    sups = tuple(max(hi_u-lo_g,hi_g-lo_u) for (lo_u,hi_u),(lo_g,hi_g) in zip(bu,bg))
    actual_signs = tuple(int(s>actual)-int(s<actual) for s in sups)
    dyadic_signs = []
    cells = []
    for bits in (160,256):
        ctx.prec = bits
        w0,w1,w2 = (ar(d).sqrt().sqrt() for d in radicands)
        boundary = ar(h)*(w0+w1+w2/2)
        row = []
        for s in sups:
            delta = ar(s)-boundary
            if exact_dyadic is not None:
                sign = int(s>exact_dyadic)-int(s<exact_dyadic)
                if sign:
                    assert delta>0 or delta<0
                else:
                    assert delta.contains(0)
            else:
                # A nontrivial positive sum of dyadic fourth-root monomials
                # cannot equal rational s (Eisenstein x^4-2).
                assert delta>0 or delta<0, "increase interval precision"
                sign = 1 if delta>0 else -1
            row.append(sign)
        cells.append(tuple(row))
    assert cells[0]==cells[1]
    dyadic_signs = cells[1]
    assert all(d<=a for a,d in zip(actual_signs,dyadic_signs))
    return actual_signs,dyadic_signs,sups,actual,radicands


def support_check(path,digest,full):
    all_models = {}
    for name,stage in read_models(path):
        assert stage["dimension"]==4 and F(stage["density"]["density_floor_one_axis"])>0
        support_lo,support_hi = map(F,stage["density"]["support"])
        parents = {p["id"]:p for p in stage["parents"]}
        for parent in parents.values():
            assert all(support_lo < F(a) < F(b) < support_hi for a,b in parent["box"])
        total = F(stage["benchmarks"]["cross"]["mother"])
        records = {}
        hist = [[0]*5 for _ in range(2)]
        masses = [[ZERO]*5 for _ in range(2)]
        ties = [0,0]
        axis_winners = [[0]*4 for _ in range(2)]
        for row in stage["roots_cross"]:
            key = tuple(row[x] for x in ("t","u","g"))
            t,u,g = (parents[s] for s in key)
            record = far_support(t,u,g,F(stage["h"]))
            mass = F(row["root_mass"])/total
            records[key] = (mass,record)
            for i in range(2):
                signs = record[i]
                j = signs.count(1)
                ties[i] += signs.count(0)
                hist[i][j] += 1
                masses[i][j] += mass
                for axis,sign in enumerate(signs):
                    axis_winners[i][axis] += sign==1
            digest.update(repr((name,key,mass,record)).encode("ascii"))
            if full:
                print("ROW",name,*key,"signs_physical",record[0],"signs_dyadic",record[1])
        assert len(records)==34 and all(sum(row)==1 for row in masses)
        for mode,i in (("physical",0),("dyadic-owner",1)):
            print("SUPPORT",name,mode,"row-counts-0-to-4",hist[i],
                  "weight",",".join(f"{float(v):.10g}" for v in masses[i]),
                  "axis-wise positive",axis_winners[i],"critical equalities",ties[i],
                  "any 5/6-positive-probability repeated row",bool(hist[i][4]))
        all_models[name] = records
    assert set(all_models["original"])==set(all_models["rebuilt"])
    assert all(all_models["original"][key][1]==all_models["rebuilt"][key][1]
               for key in all_models["original"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--r814",type=Path,required=True)
    parser.add_argument("--full",action="store_true")
    args=parser.parse_args()
    assert __debug__, "Run with assertions enabled"
    print("Python",platform.python_version(),"python-flint",flint.__version__,
          "FLINT",flint.__FLINT_VERSION__,"pinned",PIN)
    digest = sha256()
    kernel_checks(digest)
    constant_check(digest)
    support_check(args.r814,digest,args.full)
    print("PASS joint kernel/support exact transcript SHA-256",digest.hexdigest())


if __name__=="__main__":
    main()
