# R210 independent premise audit

## 1. Order and exact original account

Read `task_contract.md` before any new R210 proof. This section records independent calculations from the stated candidates and the already reviewed original RT1/R209 interfaces. Only this audit is edited; no Git, spawning, numeric execution or PDF compilation is performed. Arbitrary positive L1 inputs, actual receiver Lebesgue integration, the original beta/nu dependence, high/far/history/unique-j/window and shared reserve qualifications remain. The original signed J-share may consume the available negative credit only once, with all other positive shares retained.

Write s=log t, n_t=1_Zt w_t nu, e_t=n_t(V)>0, Pi_t=n_t/e_t, k_t in {0,...,n}, and m_t=Pi_t k_t. Physical w is continuous with w'=-kw; k is a nondecreasing sourcewise threshold staircase. The real two-source reweighting Omega is retained on return to Pi tensor Pi. Neither probability mass one nor sourcewise monotonicity bounds the total posterior-weighted threshold production by n.

## 2. Mean-score production and removal, screened before proof

With no deletion, the exact measure identity is

    dm_t=Theta(dt)-Var_Pi_t(k_t) ds,
    Theta(dt)=integral Pi_t(dz) dk_t(z)>=0.

On a threshold atom w/e is continuous, so Delta m=Pi(Delta k). Between threshold events k is fixed and m'=-Var. For a finite interval this yields energy=m_start-m_end+Theta(interval), not a bound by the initial score alone. The production uses the actual changing posterior at each threshold. Although every source has total dk<=n, replacing that family of different posterior weights by one fixed probability is unjustified. Finite cutoff bounds involving nu(V)/inf e may be valid but do not give the required uniform source price.

At an actual deletion of posterior fraction d<1, with current deleted-source mean k_D,

    Delta m=d(m_minus-k_D)/(1-d).

This can have either sign. Continuous removal contributes (m dL(V)-integral k dL)/e, likewise without a fixed sign. At simultaneous threshold/deletion events a consistent exact order is threshold first with the pre-deletion posterior, then deletion using the updated current scores and updated intermediate mean. Using post-delete production with a pre-delete correction would miss their cross term. Joint source/time versions must also specify these traces when exits coincide with individual thresholds, including continuous pushforwards of source exits. A death row is handled before division.

Consequently the full integrated mean-score ledger retains initial/final m, the actual posterior threshold-production measure, all genuine deletion mean changes and any continuous singular removal. None of these deletion changes is original N_del, whose object remains a reverse-score dt density on E_t x B.

## 3. Exact pair-energy factors and the original weights

The relevant normalizations are

    1/2 integral (k_v-k_u)^2 dPi^2=Var_Pi(k),
    integral (k_v-k_u)_+^2 dPi^2=Var_Pi(k),
    integral (k_v-k_u)^2 dPi^2=2 Var_Pi(k).

The full ordered R209 Omega-weighted pair energy without one-half is the last quantity. An unordered-pair or half-symmetrized convention gives the first; these cannot be silently interchanged. Raw positive/negative score gaps are first powers and on specific original source blocks and gates, not all-pair squares. Restricting and positively discarding A/H may bound an energy by an unweighted variance but loses the original target/source weight and cannot close its original source column.

The only available original reverse credits here are Psi Dminus on G x B and Dminus on E_t x B, with their actual common outer measure. The internal G/G, G/E and E/E reverse terms of an unrestricted variance identity are not additional original credits. The R209 exact internal/gate balance or a proved common allocation is needed before using them. Already consumed N_Z does not return; P_other cannot spend the N assigned to the J-share. A one-sided hard cap of positive traffic cannot be imposed on the signed account without proving the corresponding common comparison.

## 4. Fixed target tests and necessary exchange terms

Independently verified the parent's additional accurate fixed-f candidate. Let F=Pi f, C=Cov_Pi(f,k), f fixed along the auxiliary time. Away from threshold/deletion events,

    F'=-C,
    C'=-Cov_Pi(f,(k-m)^2).

At a pure threshold event with the same Pi,

    Delta C=Pi(f Delta k)-F Pi(Delta k).

For nonnegative f, the full ordered single-f pair energy is

    integral f_v(k_v-k_u)^2 dPi^2
      =Pi[f(k-m)^2]+F Var_Pi(k).

The same expression results with symmetric weight (f_v+f_u)/2. An additional overall one-half would halve it. None of these identities removes weighted threshold production or supplies a sign for the weighted central covariance. For the actual terminal A the auxiliary-time test is fixed, but deletion still renormalizes its moments even when its own support survives. If one instead introduces an A-tilted posterior, its normalizer and its one-leg relation to the original Pi must be retained; it is not the original pair measure.

Actual time-dependent single-source tests add their test-variation pairing, while pair gates produce their full two-leg finite products. At threshold/delete/gate coincidence the entire finite state difference, or an explicit consistent update order, is required. A BV derivative statement needs actual BV representatives and total-variation integrability, including diffuse/Cantor parts. Arbitrary measurable suffix/history gates support only finite identities or positive estimates, not a free integration by parts.

If a scalar BV multiplier is used to weight the mean ledger, its genuine product/test variation remains, with post-state multiplier for a mean jump and pre-state mean for a multiplier jump under one consistent finite-product convention. Receiver/current/alpha selection changes are not frozen merely because the original auxiliary-time A is terminal fixed. Original RT1 is time-fixed only within the prescribed row; endpoint/domain changes and all common outer source/high/history measures remain on global integration. Nonnegative Tonelli or finite absolute-integrability truncation is needed before exchanging these integrals.

Stage status: independent premise screen complete. Mean, covariance and pair-energy identities pass with the explicit factors, traces and unpaid production/removal/test terms above. No source/root budget or newly usable negative credit is certified. Await author manuscripts; do not expand into an independent counterexample project.

## 5. Full aggregate-ledger review after the screen

Read the complete current `aggregate_threshold_ledger.md` only after the independent calculations above. Its finite-source/finite-threshold mean ledger, threshold-before-delete intermediate state, signs of actual deletion mean changes, half-pair variance normalization, fixed-test covariance derivative and symmetrized nonnegative-test energy agree with the screen. The d=0, death and continuous-deletion guards are present. No necessary revision was found.

The manuscript calls this an exact accounting interface, not a proved global root budget. Its finite sum of threshold events generalizes to the actual posterior-weighted positive production measure, with consistent source/time traces and integrable limiting arguments; it does not become a free count n. All original RT1 receiver/source/gate costs and original credit restrictions remain. In particular a safe sign for a fixed-f potential's deletion does not imply the same sign for its covariance's deletion.

## 6. Persistent capture-clock candidate, independently screened before proof

The auxiliary author supplied a new accurate candidate and then clarified its persistent support before any proof was read. Compare actual nested capture states with common nu,J,K0,a,T,g,h, original clock/posterior, terminal G/B/E and common gates/outer measure. Let the persistent eligible set be C=G intersect Ecap-minus intersect {a>0}, further restricted to common real qualifications. Do not assume all G is persistent. Let Hminus-Hplus=Gcap=Q_J(alpha-minus-alpha-plus)>=0 and Splus>=Sminus>=J. On C,

    Delta A=zplus Delta rho-(zminus-zplus)rho-minus,

so the denominator term retains its actual nonpositive contribution. Since the original reverse credits are unchanged under this comparison, the original signed density's change from this weight alone is exactly integral_GB Psi hgate Delta A Dplus dPi^2. Bounding its recovery by zplus Delta rho, integrating the genuine bad probability, using target survival and e_t>=e_g, and positively enlarging the actual far subset to [tau,h] gives

    recovery <=(1/e_g) integral_C zplus Delta rho(w_tau-w_h)dnu
              =(1/(T e_g)) integral_C zplus a Delta rho dnu
              <=Gcap/(T e_g).

Here the physical identity a=T(w_tau-w_h), with one row scalar T, is essential. The sharper exact capacity after FTC is Gcap/(T e_g Q_J) times integral_C zplus J dnu minus the same nonnegative zplus-weighted inactive-alpha slack divided by T e_g. T>0, e_g>0 and a nonempty tau<h interval qualify the divisions; zero/empty cases are handled first. There is no inverse a, inverse alpha or factor n in this persistent recovery estimate.

The bookkeeping weight Astar=Aminus+1_C(Aplus-Aminus) need not be asserted to be a new physical state; it is only a finite decomposition under the same actual data. New capture/active/qualification entries on G minus C remain. This estimate controls the change of the full common-weight signed functional, hence its exact combined R209 balance, not separately the nonlinear positive insufficiency, Gamma_pos or the baseline. Any changing outer density, source, clock, gate, S-support or receiver state needs its full finite exchange. The remaining actual outer integral of Gcap/(T e_g) has no established root-order source price. This is accepted as a constructive conditional clock/capacity candidate pending the author's full proof, not as general closure.

Stage status: independent premise screen and full main-ledger review complete. Await the two author manuscripts and bounded evidence for subsequent full review. No final byte binding or freeze is made at this stage.

## 7. Remaining-time physical pair candidate, screened before proof

Before reading the main raw author's manuscript, independently checked its accurate new candidate. In log time s in [0,T], write a=T-s, b=w_v/(w_v+w_u), l=log(w_v/w_u), d=k_u-k_v=l'. With b continuous and d a physical threshold BV path,

    integral a b(1-b)d^2 ds
      =-T(b_0-1/2)d_0-integral a(b-1/2)dd
        +logcosh(l_T/2)-logcosh(l_0/2).

The sign of the last term is not fixed. Its derivative is (b-1/2)d. The initial plus threshold absolute cost is at most half of L_u+L_v, because T|d_0|+integral a(dk_u+dk_v)<=L_u+L_v. The last term is at most half of integral|d|<=half of L_u+L_v. Thus the energy is at most L_u+L_v, where L_z=integral k_z ds=log(w_ell/w_g).

At the actual endpoint g with 0<xi_ell<=xi_g<=1, L_z equals the sum of log_+[xi_g/max(xi_ell,C_i)]. The established whole-domain log-C Lipschitz bound and C(0)=1 imply L_z<=-log w_g<=18||y-z||_1/b. The initial activated-score term must remain in its exact remaining-time threshold decomposition. This geometric estimate does not alter the original source measure.

With actual Omega, the same finite product yields the boundary term, the post-Omega threshold integral, minus the pre-score Omega-variation integral, plus integral Omega(b-1/2)d ds. These signs and the simultaneous-jump cross term were checked before the proof. The resulting weight a cannot be divided away for free; a positive common cutoff pays its true inverse-square-root factor and leaves the terminal short window. No bare posterior-production or original root budget follows.

## 8. Full capture-clock manuscript review

Read the complete 283-line `capture_threshold_budget.md` after the candidate screen. CT1–10 retain original persistent support, common actual capture/clock data, positive denominator and empty-window guards. The real far FTC precedes the single-source capture capacity and cancels a exactly as screened; the original denominator decrease stays actual and nonpositive. The bookkeeping intermediate Astar does not reselect alpha or claim a new physical state.

CT11 was checked independently: binary Psi gives the exact change in the same-target lower/upper work; the positive-part Lipschitz bound and exchange of the same G source leave the complement score n-k_v, not k_v. It therefore cannot borrow the target's k_v w FTC. The combined signed change, individual nonlinear insufficiency and baseline are correctly distinguished.

CT12's one positive hard reduction has the original 32Lambda/3 coefficient. CT13's beta/e_g column bound does not pay the p_y-weighted column. CT14's K/3 inverse-w_g weighted kernel and CT15's remaining J^2/w_g are correct, including their stated y/receiver/capture dependence. CT16's fixed-clock nested chain spends each actual capture gain once and has no capture-layer fee. CT17's variable-clock Abel identity is exact but retains positive coefficient variation and actual baseline/geometric exchanges. The three proposed complete clock-derived models were checked by hand, including the third model's smaller J required by Jnu<=q and its negative net target change.

No mathematical revision was necessary. One internal locator was flagged to the owner: CT2's reference to the complete finite exchange should point to CT7, not the CT11 complement-score formula. Final binding will use the owner's corrected actual file. The remaining outer integral, baseline, entries, inverse-w_g column, changes of background/selector and all original source/window costs are explicitly unproved.

## 9. Full remaining-time joint-source manuscript review

Read complete `joint_source_geometry.md` after section 7's independent screen. JS1–18 agree with that derivation. JS9 retains the initial threshold count; JS11 includes the signed logcosh difference and has the correct whole-domain geometric loss bound. JS12 bounds the sqrt-remaining-time flux only. In JS14 the threshold term uses post-state Omega and the Omega term pre-state score, retaining simultaneous threshold/deletion products and continuous singular normalization. JS15's coefficient 9/b is correct after |b-1/2|<=1/2 and the log-C bound 18.

JS17 is read with a common fixed positive cutoff h for the full integral; a row-dependent h would have to stay in the actual weight and cannot be pulled outside without another bound. The terminal short window and the source/selector fee are retained. Full bad sources are given only their actual variable kappa_u; the manuscript does not import the reciprocal branch's uniform overlap into nonreciprocal traffic. Bare production, source-column payment and original N_del remain distinct. No necessary mathematical revision was found, and no general raw/root source budget is certified.

Stage status: main and both author mathematical manuscripts reviewed within their precise scopes. Await final numerical evidence and TeX/report integration for later byte binding; do not run scripts or freeze an obsolete numeric checkpoint.

## 10. Original far-domain remaining-time interface

Independently checked the added accurate candidate, then read the aggregate manuscript's new far-interface section. The original far restriction t<=h_far=g exp(-u0/n) gives log(g/t)>=u0/n pointwise, with u0>0 fixed before the sources. This is the existing actual domain, not a new freely discarded cutoff or a new window menu. On the common nonnegative measure M Omega vartheta(1-vartheta) times original far/RT1/source/high factors, Cauchy–Schwarz gives

    Iplus^2<=B0 integral_far M Omega vartheta(1-vartheta)d^2
            <=(n/u0) B0 Brem.

The factors and direction are correct. All positive integrals are first localized to the finite common account, with zero measure handled first. A row-dependent u0 remains in its actual weight instead of being taken outside the global integral. The existing near segment and its cost are separate. The conditional future assumptions B0<=C W_A and Brem<=C u0(log n)^c W_A would imply the displayed root-polylog bound, but both budgets and Omega/threshold/initial/selector costs remain unproved. The manuscript correctly does not certify them by this interface.

Also verified the capture manuscript's sole internal-reference repair: CT2 now refers to CT7's complete finite exchange. No mathematical formula changed. Await the final integrated material and numerical scope; no scripts were executed and no final hash table is yet frozen.

## 11. Final numerical evidence, report and driver static review

Read the entire final `threshold_production_checks.py`, final notes, JSON metadata and relevant exact records, current report and reproducer, without running the numerical script. The actual numeric file hashes agree with the final owner delivery: script `208afddbed8f482cfbc6fcf459056c2e6d0b490e6675a97275c6da033791a764`, JSON `9029eff5a133fb1f2509e2713c7ab386cdf28f013fc63fcae6a6c4d7abb79a2f`, notes `435be3106c5033840ab33e9f14c5008564d37799e875c12231b9d51ad7e99661`.

The nine aggregate models use full actual mu*w normalization, correct right-inner start/left-inner end scores, distinct internal thresholds and threshold-before-delete current scores. Each segment's variance equals both its centered square and unordered-pair calculation, and its exact integral is the mean decrease. Actual signed deletion jumps of both signs and zero remain. The 30 segments and 21 events are finite diagnostics, not a general energy/source bound; the observed production exceeding n is not claimed as an asymptotic energy conclusion.

The three capture models reconstruct a from the same min-product clock, then compute actual U/H/alpha/Gcap. The zero-a row is not divided, the alpha-plus-zero case is legal, and the third uses J=1/48 to keep QJ<=q. Its actual recovery 1/990 and signed net -1/990 retain the true negative denominator term. All use e_g=7/4 in the FTC chain, with original source and outer costs explicitly outside the finite certificate.

For the three reused remaining-time pairs, independently checked the exact segment primitive d[b_R log(1/R)-b_L log(1/L)]+log[(1+odds_R)/(1+odds_L)]. It agrees with the globally assembled JS11 expression after exact prime-log expansion. Dyadic reduction q=2^k r with 1<=r<2 and the forty-term atanh expansion have rigorous tail 2z^81/[81(1-z^2)]. Negative exponents and negative coefficients correctly reverse interval endpoints. These are genuine exact rational enclosures for the specified log expressions, not floating precision diagnostics. The stronger finite comparisons lower(E)>=0 and upper(E)<=lower(L_v+L_u) certify only these three bare pair paths, not Omega or the original full geometry.

The owner reports actual isolated whole-JSON byte-identical replay, exit 0, 0.050 seconds; the parent separately reports an actual pre-archive replay. Neither was performed by this auditor. The report preserves all conditional/global distinctions and the full ordered 2Var convention. The standard-library relocated-copy driver covers the correct R210 CLI, manifest confinement/required entries, fresh output, whole-JSON byte comparison and post-run hash verification. Static acceptance does not pre-report the parent's future manifest driver or archive result.

## 12. Final complete TeX review

Read the complete 745-line detailed TeX, including all aggregate, CT and JS proofs, the original far interface, and all final 9+3+3 evidence. It agrees with the reviewed mathematical manuscripts. General threshold production and continuous removal use actual measures/traces; finite event ordering, factor two, fixed-f covariance and the symmetric energy normalization are correct. The persistent-capture FTC, its exact inactive-alpha slack and denominator negative term, the complement-score obstruction, K/3 and 32Lambda/3 return coefficients, fixed-clock chain and variable-clock exchange are faithfully transcribed. New entries and baseline insufficiency do not borrow the persistent gain.

The remaining-time energy preserves the initial score, signed logcosh difference and complete post-Omega/pre-score threshold/deletion products. The new far inequality retains its common u0 and both unproved budgets, with near/source/selector fees explicit. The finite log interval formula, exact model endpoints and the negative third capture net match the script/notes. No finite certificate is promoted to an original physical/FULL realization or general root budget.

The author made one final transcription repair to the capture model's literal set braces. Re-read that repaired line in the actual final file: all three sets now use escaped braces. Final TeX SHA256 is `bbbc36f4c2d4e5bb96bb1f8063ed1e4d9ee8c048299e1e29f2234481e3289ae8`; static inspection found 745 physical lines, 50 unique labels, 39 references with none missing, and no abnormal ASCII control characters. No further necessary mathematical or transcription revision remains. No PDF compilation was performed.

## 13. Final mathematical decision and limits

Accepted in their precise scopes: the aggregate threshold/removal ledger; the persistent same-source capture-clock increment and same-clock chain; the remaining-time physical pair-energy estimate and its exact original Omega return; and the original far-domain Cauchy interface. The latter still requires the actual B0/Brem budgets. The first general unpaid quantities remain the common original weighted inverse-overlap capture column, threshold-position reuse, Omega variation, entry/baseline, near and receiver/source/selector/window account. General centered-cube root-order weak-type closure is not certified.

The auditor edited only this audit and performed read-only mathematical/static inspection elsewhere. No numerical script, parent driver, Git operation, subagent or PDF compiler was run. The parent's later manifest, driver, archive and repository actions are outside this audit's execution claims.

## 14. Frozen final byte bindings

The following ten reviewed files are bound to their actual final bytes. This audit does not hash itself or a future manifest.

| File | SHA256 |
| --- | --- |
| `aggregate_threshold_ledger.md` | `7e433e22e03bfd7f0550580134f7e09eb0f263c5ad3e30a8ddb5acb81514e34f` |
| `capture_threshold_budget.md` | `8368fc136681efbb9433eaedc24ed4678aeeb5a8b33fe76b70acc80f233aaab4` |
| `joint_source_geometry.md` | `11bcde38642c7ecc0204926bd4b11058a79b6bead1bc8f415f3dbe153a3454bb` |
| `numeric_notes.md` | `435be3106c5033840ab33e9f14c5008564d37799e875c12231b9d51ad7e99661` |
| `proof.tex.txt` | `bbbc36f4c2d4e5bb96bb1f8063ed1e4d9ee8c048299e1e29f2234481e3289ae8` |
| `report.md` | `d495e4015675068ea6b9570f0b7d98a8b9a153fd83c1ae5bb2f5bb5836af0841` |
| `reproduce.py` | `d0a55caa54e6abcc6dd70a21f70611593bd8de3c6e7bc180fa7786e8a389828d` |
| `task_contract.md` | `be2f79303e6e5f4822106df9907f09d8b772b722945d81c677c8556b1d854a35` |
| `threshold_production_checks.json` | `9029eff5a133fb1f2509e2713c7ab386cdf28f013fc63fcae6a6c4d7abb79a2f` |
| `threshold_production_checks.py` | `208afddbed8f482cfbc6fcf459056c2e6d0b490e6675a97275c6da033791a764` |

Status: final review accepted within the exact scope above and frozen; no further audit work is pending for this checkpoint. General source/raw/root closure remains open.
