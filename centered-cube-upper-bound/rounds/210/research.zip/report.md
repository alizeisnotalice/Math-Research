# 第210轮：捕获时钟与剩余时间几何预算

目标是一般中心立方体极大算子的 n^(1/2+o(1)) 一致弱型上界。本轮没有完成一般上界；推进的是原始共同来源下可核验的两项构造性估计。详细定义、量词和证明见 proof.tex.txt、capture_threshold_budget.md、joint_source_geometry.md；审查见 audit.md。

## 已证明的估计与适用范围

固定原窗口、共同来源及物理时钟，捕获幅度必须是 a_v=mathsfT(w_tau(v)-w_h(v))。对嵌套捕获且持续合格的目标集合，真实恢复费用满足 R_per<=G_cap/(mathsfT e_g)。其证明先保留原后验及原far域，用非负未归一化时钟积分支付 a_v，再用共同alpha的层积分支付恢复。分母增长的负份额单独精确保留。该结果消去此前点态估计里的逆a、逆alpha和score n；不包含新增目标或变化时钟的免费结算。

同一时钟下有限捕获链的总恢复费用至多 (H_0-H_m)/(mathsfT e_g)，不乘捕获次数。变化权重只有实际Abel恒等式，正变差费用尚须支付。反射不足中的互补score n-k不能直接使用k时钟的捕获积分支付。

任意两条物理乘积阈值路径，定义vartheta=w_v/(w_v+w_u)、d=k_u-k_v、Tlog=log(g/ell)，则剩余时间加权能量
Erem=integral_0^Tlog (Tlog-s) vartheta(1-vartheta)d^2 ds <= L_v+L_u，
其中 L_z=log(w_ell(z)/w_g(z))。实际重叠核满足 L_z<=18||y-z||_1/b。证明保留初始活跃坐标、全部阈值原子和端点logcosh差。回到原双后验必须乘Omega，完整Stieltjes公式保留dOmega费用；未证明原来源重用的免费控制。

原far域的定义 h_far=g exp(-u0/n)直接给log(g/t)>=u0/n。在相同原RT1接收测度、全部门及来源权下，Cauchy给 Iplus^2<=(n/u0)B0 Brem。u0须共同固定才能外提。原near费用另存；B0与Brem的全局目标预算均未证明。

## 保留的真实费用与未完成部分

原high列估计只支付 integral beta/e_g<=1/(2K)，不能丢掉额外p_y。postgood之后仍有J/w_g和捕获权的相关积分；这正是当前质量可比重尾联合交通的剩余来源预算。原接收点、尺度、j、窗口、选择器、支持和门均须保留。固定行的捕获结算、两来源能量及上述far比较都不能直接替代一般全局闭合。

聚合score恒等式是 Eglob=m_left-m_right+Kthr+Jdel；完整有序pair平方差为2Var。它揭示阈值生产和删除的实际代价，但本身不是新的根预算。数值例中n=4的后验阈值生产大于4，不意味着能量超线性；两者有端点抵消。停止把单来源最多n次阈值穿越直接当作聚合生产上界。

## 数值范围与复现

本机Python标准库Fraction完成三个阶段的9个聚合时钟模型，含30段、21阈值事件、3删除批次；3个由实际时钟定义a的捕获模型；3个复用pair的严格有理log区间证书。log用dyadic归约、40项atanh级数及显式余项；没有以浮点近似替代区间界。捕获模型含alpha落至0和分母增长负份额。有限模型并非完整物理几何一般实现，更不能覆盖任意L1输入；具体限制见numeric_notes.md。

解压后运行 python3 reproduce.py --verify-only，然后运行 python3 reproduce.py --output-dir <全新目录>。驱动检查清单，迁移脚本和契约至临时目录，实际重放并比较完整JSON字节，随后再次检查清单。只用标准库，不编译PDF。清单和重放认证文件一致性与所列有限计算，不认证一般定理。

## 下一项全局攻坚

需要联合处理原high与postgood约束、终端逆w_g和真实receiver几何，而非将它们分别取上确界。优先寻找能在同一外测度结算B0、Brem及持续目标捕获恢复的共同来源容量；任何新的全局结论须保留near、变化时钟、来源重用和自适应选择费用。本轮不把该待证预算改名为已成立的几何理论。
