# R210：真实 far 时钟对持续捕获恢复的联合预算

状态：在两态真实共同来源/几何/时钟及持续 target 上，先做原 far 时间积分，再用同一 capture 增益 G_cap，得到不含倒 a、倒 alpha 或 score n 的增量价 G_cap/(T e_g)，同时保真实分母负项。它控制 LP 完整合计账的共同捕获恢复，而非单独静态 cut 正部。原 high/β 回代后仍有明确的逆 w_g 加权列、入口及 selector 费用；一般目标未闭合。未读本轮 Astra 草稿。

按合同使用 D04 的同一真实联合测度、条件对象及有限性纪律；本稿不调用熵链式文献定理，不改原 posterior，不设来源独立或 nu<=beta。

## CT1　窄读到的实际 far 与 capture 条件

实际读取 R128 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md` 637--675 行（RT4--6），并使用冻结 R208 `linear_capture_increment.md` LC1--21 与 R209 `layer_potential.md` LP1--9。没有读取本轮新来源预算作者稿。

固定原 `(omega,V,j,x,y)` 终端行，保同一硬源及原外测度
\[
 d\mathcal T_I=1_I1_{j(x)=j}q^{-1}p_yh_{R(x)}(x-z)
 a_\omega(x,y,z)\,dx\,\beta_V(dy)\nu_V(dz).
 \tag{CT1}
\]
硬源 z 不等于后验 bad 源 u。原期望/V/j/window、high/far/history、真实 dx 不删。原负信用 N 只归 J 子份额一次，其它 share 不再领 N。

原参数满足
\[
 \gamma=1+1/n,\quad c_j=\gamma^{-j},\quad
 \tau_j=a_{win}/c_j,\quad g=\sqrt{LR},\quad
 h=g\exp(-u_0/n)\le g,
\]
\[
 J_{far}=I_{j,V,y}\cap[\tau_j,h],\qquad u_0>0
 \text{ 在来源之前固定。} \tag{CT2}
\]
这里 a_win 是尺度窗下端，不是下面 source target 的 a_v。h<=tau_j 时 far 积分先零。

同一实际 source 时钟是
\[
 w_t(v)=\prod_i\min(1,\alpha_i(y,v)/t),\quad
 k_t(v)=\#\{i:\alpha_i(y,v)<t\},\quad -dw_t=k_tw_t\,dt/t,
\]
\[
 \Pi_t(dv)=1_{Z_t}(v)w_t(v)\nu(dv)/e_t,
 \qquad G\cup B=Z_g\subset Z_t\ (t\le g),\quad e_t\ge e_g>0.
 \tag{CT3}
\]
G、B互斥且终端存活。C⊂G的每个 target 在整个实际 far 时间存活。阈值仅使 k 跳，w 连续 AC；没有把原 N_del 时间密度当删除原子。

真实 capture 参数为
\[
 \Delta_v=w_{\tau_j}(v)-w_h(v)\ge0,\quad
 a_v=T\Delta_v,\quad
 T={c_j^{n/2}\over g^n\sqrt{1+\log n}}>0,
 \quad\kappa_v=DK_{0v}\ge0,
\]
\[
 J_v=P_{1,b}(x-v),\quad Q_J=\int J\,d\nu,\quad
 U=1_{E_{cap}}\min(a,\kappa),\quad
 H=Dq-\int U\,d\nu=\alpha Q_J\ge0.
 \tag{CT4}
\]
特别 a_v 不能被任意自由正数替换。原 K0、Hhat 与 D保持；D>=1。FIRST 给 ∫K0ν<=q、∫Jν<=q，故 U<=D K0 保 alpha 非负，但不提供低核域反向来源帽。QJ0 行先零，不形成alpha除式。

## CT2　两态真正共同的背景与持续范围

比较两实际合法 capture 状态，要求共同 nu,J,K0,Dq,T,tau_j,h,g、原 w/Z/Pi、原 row 外测度与所研究共同门。真实 capture 迹 Ecap−⊂Ecap+，
\[
 H_\pm=Dq-\int1_{Ecap_\pm}\min(a,\kappa)d\nu
 =\alpha_\pm Q_J\ge0,
\quad G_{cap}=H_--H_+=Q_J(\alpha_--\alpha_+)\ge0.
 \tag{CT5}
\]
这是实际同一 U 积分，不自由指定 G_cap。alpha 比对所有 source 共同，不按 target 重选。

只对 C⊂G∩Ecap−∩{a>0} 的持续 target 应用 LC。可以再交两态真实共同 good/capture/history 资格；不假整个 G 属于 Ecap−，也不以纯 good 阈值代替完整 capture 迹。

令
\[
 \rho_v^\pm=(1-\kappa_v/a_v-\alpha_\pm J_v/a_v)_+,
 \quad S_v^+\ge S_v^-\ge J_v>0,\quad z_v^\pm=J_v/S_v^\pm,
 \quad A_v^\pm=z_v^\pm\rho_v^\pm \quad(v\in C).
\]
原 target 的 a0、J0、e_g0、QJ0 先按实际零支隔离，不能使用相应比值。h<=tau先空；双alpha0强制G_cap0，恢复为零；alpha+0可正常保留。

改变 A 时仅使用记账中间终端权
\[
 A^*=A^-+1_C(A^+-A^-). \tag{CT6}
\]
它不用于重算 alpha 或 capture。G\C 的新捕获/新active/资格入口另记。若几何、时钟、来源或外测度不共同，用CT7节的完整有限交换，不能将本比较当作原路径全部变化。

## CT3　原 signed 交通的准确持续增量

令原 score 差 D_t(v,u)=k_t(v)−k_t(u)。固定同一 Psi 与 h_gate，R209 的 signed 密度中负项不依 A，故
\[
 \mathcal S_t(A^*)-\mathcal S_t(A^-)
 =\int_{C\times B}\Psi h_{gate}(A_v^+-A_v^-)D_t^+\,d\Pi_t^2.
 \tag{CT7}
\]
只在相同原负信用和测度下成立，不能将分别放松后的正负值相减。

共同几何给精确变化
\[
 A_v^+-A_v^-=z_v^+(\rho_v^+-\rho_v^-)
 -(z_v^--z_v^+)\rho_v^-.
\]
记恢复与真实分母负项
\[
 R_{per}=\int_{Jfar}\!\int_{C\times B}
 \Psi h_{gate}z_v^+(\rho_v^+-\rho_v^-)D_t^+\,d\Pi_t^2\,{dt\over t},
\]
\[
 N_S=\int_{Jfar}\!\int_{C\times B}
 \Psi h_{gate}(z_v^--z_v^+)\rho_v^-D_t^+\,d\Pi_t^2\,{dt\over t}\ge0.
 \tag{CT8}
\]
于是持续 signed 增量精确为 R_per−N_S。N_S用实际值保留，不用其正上界冒作负信用。某 target 自身 S+−S−=0仍可由共同 alpha 下降恢复。

## CT4　真实 far-FTC 消去 capture 的倒 a

因为0<=Psi,hgate<=1、D+<=k_t(v)、bad槽的实际Pi概率质量<=1、e_t>=e_g，以及C target始终存活，Tonelli直接给
\[
 R_{per}\le{1\over e_g}\int_Cz_v^+(\rho_v^+-\rho_v^-)
 \int_{Jfar}k_t(v)w_t(v){dt\over t}\,d\nu(v).
\]
原 Jfar⊂[tau_j,h]，未归一非负FTC因此有
\[
 \int_{Jfar}k_t(v)w_t(v){dt\over t}
 \le w_{\tau_j}(v)-w_h(v)=\Delta_v.
\]
这里仅扩大非负 source 时钟的积分，不在实际未定义辅助域外虚构 Pi；不需要Psi/hgate的BV。
利用真实 a=TDelta，得到
\[
 \boxed{R_{per}\le {1\over T e_g}
 \int_C z_v^+a_v(\rho_v^+-\rho_v^-)d\nu(v).} \tag{CT9}
\]
顺序重要：先做实际far时间积分，再用capture，而非先用LC去掉a后把1/a留在source矩中。

同一实际alpha变化的LC精确式为
\[
 a_v(\rho_v^+-\rho_v^-)
 ={G_{cap}\over Q_J}J_v
 -\int_{\alpha_+}^{\alpha_-}J_v1_{\{a_v-\kappa_v\le\lambda J_v\}}d\lambda.
\]
定义L_z为后项再乘z_v+并在C上积分，则L_z>=0。因为0<=z+<=1，
\[
 \boxed{R_{per}\le {G_{cap}\over T e_g Q_J}
 \int_C z_v^+J_vd\nu-{L_z\over T e_g}
 \le {G_{cap}\over T e_g}.} \tag{CT10}
\]
这确实消去旧LC换权中的倒a、倒alpha和score n；连续阈值/并发阈值均已在真实w FTC内，完整删除只通过真正e_t>=e_g进入。没有再借用N_del。

因此CT7的持续全signed增量满足CT10右侧减去实际N_S。这个新价是实际同源capture/物理clock的联合增量预算，而不是单独静态反射cut上界。

## CT5　为何须合并LP合计账，而不是逐项取正

固定c同时盖住A−和A*，同一Pi下R209给精确
\[
 \mathcal S_t(A)=\operatorname{Cov}(f_{c,A},k)
 +\int_G(l_v(A)-h_v(A))\Pi_t(dv)
 +\Gamma_{pos}(A)-\mathfrak P_t(A),
\]
其中L_v=(c−A_v)Pi|E+(A_w−A_v)+Pi|G，l_v为其向下scoregap，
\[
 h_v(A)=\int_B(\Psi(v,u)-A_v)_+(k_u-k_v)_+\Pi_t(du),
\]
Gamma_pos为(A−Psi)+D−，P为全部准确有利项。把A*与A−代入相减，左侧精确为CT7，所以CT10支付的是这些项的联合恢复。不得同时将每个项的正部各收一次G_cap。

可直接看到独立控制cut不足的障碍。仅取共同S、故deltaA>=0，Psi是实际二值门。记
\[
 e_v^{low}=\int_E(k_v-k_w)_+\Pi(dw),\quad
 b_v^{open}=\int_B\Psi(v,u)(k_u-k_v)_+\Pi(du),
\quad X_v(A)=l_v(A)-h_v(A).
\]
精确有
\[
 X_v(A^*)-X_v(A^-)
 =\delta A_v(b_v^{open}-e_v^{low})
 +\int_G[(A_w^*-A_v^*)_+-(A_w^--A_v^-)_+]
 (k_v-k_w)_+\Pi(dw).
\]
用正部单调Lipschitz并交换同一G来源，得到
\[
 \int_G[\Delta X_v]_+\Pi(dv)
 \le\int_G\delta A_v\left[(b_v^{open}-e_v^{low})_+
 +\int_G(k_w-k_v)_+\Pi(dw)\right]\Pi(dv)
 \le\int_G\delta A_v(n-k_v)\Pi(dv). \tag{CT11}
\]
同样支配∫G[(X_v(A*))_+−(X_v(A−))_+]_+。最后一步只用k∈[0,n]和互斥G/B；不是假排序。

CT11需要的却是补score n−k_v；真实capture时钟FTC控制k_v w_t。对尚未跨自身阈值的target，k_v可零而补score不零。原a>0来自整个[tau,h]的future loss，不能据此在每个t断言k_v>0。故不能把CT10搬到单独(l−h)+或逐cut正部；LP其余势/有利项的共同抵消是必要的。也不能令G_cap=0便断言baseline反射不足为零：原辅助时间里alpha沿行固定，G_cap本就不是逐t的新容量。

## CT6　原RT1回代与high/β的实际缺口

在CT1共同外测度下可将CT10−N_S逐行积分。该正增量才可依R208已核正交通reduction使用一次hard帽，得到其已经定义的post-hard接收形式
\[
 \Delta Raw_{J,per}
 \le {32\Lambda\over3}\,\mathbb E\sum_{V,j}\int dx\,1_{j(x)=j}
 \int\beta_V(dy)\,{p_y\over T e_g}
 \int_Cz_v^+a_v\Delta\rho_vd\nu_V(v),
 \tag{CT12}
\]
并可再正上放为同式G_cap/(T e_g)。这是正增量的合法上界，不分别对原正负raw取帽后相减；若仍保hard源，则只用CT1而不再重复该帽。所有high/far/共同history资格保持。

原high/current真实列是
\[
 p_y e_g\ge2Kq,\qquad\int p_y\,d\beta\le q
 \quad\Longrightarrow\quad
 \int_{high}{d\beta\over e_g}\le{1\over2K}. \tag{CT13}
\]
不能因此直接付CT12的p_y beta/e_g。

在共同后态原good上，p_y w_g(v)<=K S_v+/3，故
\[
 p_yz_v^+\le{KJ_v\over3w_g(v)}.
\]
不丢z/slack而回代CT12，准确得到的正量为
\[
 {K\over3}\,\mathbb E\sum_{V,j}\int dx\,1_{j(x)=j}
 \int{\beta_V(dy)\over T e_g}
 \int_C{J_v\over w_g(y,v)}a_v\Delta\rho_v\,d\nu_V(v).
 \tag{CT14}
\]
其外前系数仍乘原32Lambda/3；CT14只显示内部接收/source费用。进一步用LC逐target正界aΔrho<=G_cap J/QJ，仅可得
\[
 {K\over3}\,\mathbb E\sum_{V,j}\int dx\,1_{j(x)=j}
 \int{\beta_V(dy)\over e_g}
 {G_{cap}\over TQ_J}\int_C{J_v^2\over w_g(y,v)}d\nu_V(v). \tag{CT15}
\]
这份实际系数依y、x、capture、terminalclock；CT13的无权列不能将它免费提出。真实1/wg仍在，Pi概率与共同父支配不支付该weighted列。此处是尝试结合high/source后精确留下的第一处物理费用，未另命名为已付范数或添加未知门当一般分支。

另一路直接用G_cap<=Dq和CT13点态high，只得
\[
 {p_yG_{cap}\over T e_g}\le{D p_y^2\over2KT}.
\]
原current平方核和T尺度以及receiver-adaptive s,L仍在；固定尺度的∫p=1不能支付此式。未将它当root来源价。

## CT7　不同背景与完整入口交换

CT5--10仅在共同实际clock/几何/外测度的持续部分使用。实际原路径若改变g/h/T/a/K0/J、Pi或prior，先在共同支配测度下保其真实密度和有限系数交换。对实际门H，
\[
 H_+V_+-H_-V_-
 =\min(H_-,H_+)(V_+-V_-)
 +(H_+-H_-)_+V_+-(H_--H_+)_+V_-.
\]
不同Psi也保原负信用的真实变化，不以正门交换公式掩盖signed差。

G\C的新capture target另有a rho+入口，不能凭持续G_cap预算删除；kappa0端点可该入口正而新U增益零，strictsoft正kappa仍无统一下界。A*只有限记账，不重构原history或alpha；若P/current和CT1外密度改变，也必须单列外measure交换。

沿同一固定T/clock/e_g/nu/a/kappa/J/Dq的任意有限nested capture链，H0>=...>=Hm>=0，令Gi=H_{i−1}−Hi。每步保真实持续集合Ci和CT2的共同资格，CT10相加严格给
\[
 \boxed{\sum_{i=1}^m R_{per,i}\le
 {1\over T e_g}\sum_{i=1}^m G_i
 ={H_0-H_m\over T e_g}.} \tag{CT16}
\]
没有capture层数费。不同Ci不重复领同一step增量；原真实denominator负项仍可逐步保留。若一step几何/current不满足共同资格，该step不能仅凭本链形式使用本式。

几何变化时，若已分别证明各step全部CT资格，令b_i=1/(T_i e_{g,i})，只可保实际加权价
\[
 \sum_{i=1}^m b_i(H_{i-1}-H_i)
 =b_1H_0-b_mH_m+\sum_{i=1}^{m-1}H_i(b_{i+1}-b_i). \tag{CT17}
\]
最后一项的正变差尚未支付，且使用共同H链本身也需同一实际储备定义；若Dq/Q或a/kappa等变化使H变化另含几何/基准，先留对应真实交换，不将它全部称capture gain。不同clock、窗口、重新充入H的recharge和独立j/time菜单完整保留，不能把同钟CT16免费迁移到实际变钟selector。

## CT8　三组可执行的完整有理clock-capture校准

只作为条件来源数组/真实min-product clock证书，不声称共同空间phi/K0/FIRST/history/FULL实现。n1,tau1,g2,cj1,T1/2；三源(v,u,z)的nu各1，阈值β=(1,2,1/2)，w_t=min(1,β/t)，Z全，Gterminal={v,z},B={u},Et空，e_g=7/4。a每次由T(w_tau−w_h)实际计算，u的a0不除。Ecap−={v},Ecap+={v,z}，持续C={v}。

初探：h3/2，a=(1/6,0,1/12)，kappa=(1/12,1/24,1/24)，Dq1/6，J各1/24,QJ1/8。从U重算H−1/12,H+1/24，alpha−2/3,alpha+1/3,G_cap1/24。S_v±=2Jv，rho−1/3,rho+5/12，恢复z+Δrho1/24。

alpha+0边界：同h/a/J，只改kappa_u0、Dq1/8，其余kappa不变。于是alpha−1/3,alpha+0,G_cap1/24，S同初探。bad的零kappa是辅助边界，不宣称strictsoft物理实现。

压力：h5/4，a=(1/10,0,1/20)，kappa=(1/20,1/40,1/40)，Dq1/10；J各1/48,QJ1/16。于是alpha−4/5,alpha+2/5,G_cap1/40。S_v−2J、S_v+3J，rho−1/3,rho+5/12；恢复z+Δrho1/36、denominator负量1/18、净ΔA=−1/36。三组均Σkappa=Dq，且D=1,q=Dq时Jν<=q。

实际bad u score0、v score1在(tau,h)内，故同一Pi的clock积分精确为
\[
 \int_1^hD_t^+\Pi_t(v)\Pi_t(u){dt\over t}
 ={1\over1+3/2}-{1\over h+3/2},
 \qquad{\Pi_t(v)\Pi_t(u)\over t}={1\over(t+3/2)^2}.
\]
数值可分别直接算净ΔA交通、正恢复、实际denominator负值，并核
恢复<=z+Δrho Δ_v/e_g=z+a_vΔrho/(T e_g)<=G_cap/(T e_g)。新z入口另记，不扣持续容量。不得用第三组旧J1/24，否则违Jν<=q；本稿给定的第三J已为1/48。

本稿不预报数字执行；实际Fraction证据由数值责任文件说明。该有限模型不授免费selector或原空间核资格。

## CT9　本轮可证改进和后续实质需求

CT9--10以原真实far loss恰为a/T的关系，改变了R208先点态capture换权后遗留1/a的费用结构。它在原持续J增量上是真实可用的联合预算，保negative denominator，不只重命名LP cut不足。CT11同时解释为何单独不足不能借此容量：它产生补score，而完整原positive增长只产生可积分的target score。

仍未证明CT12/14--15在原RT1/β/source/receiver selector下为epsilon接收价或root-polylog来源价，也未控制baseline反射不足、入口/geometry及recharge。准确下一步是利用原same-alpha/capture和真实空间几何支付CT14中J aΔrho/wg的共同加权列，而非以CT13无权high列或ν<=beta代替。一般n^(1/2+o(1))弱型目标未闭合。
