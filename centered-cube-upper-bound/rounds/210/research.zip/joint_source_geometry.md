# R210：实际阈值的剩余时间、两源加权能量与来源重用账

状态：本稿给出一个全物理阈值路径成立的加权能量估计，并将其精确接回原双后验的来源重用项。它不假定 bad 槽具有统一终端权下界，不重做已付互反子支；没有取得原一般 signed J-share 的根阶来源预算。新增估计控制的是带剩余时间权的两源能量，不能将它直接替换裸后验阈值生产。

## 1. 原对象、出处及适用量词

固定原合法行 `(omega,V,j,x,y,硬源z,history)`，沿其辅助时间取闭区间 `[ell,g]`；若只用原 far 子区间，可先在该区间应用下述公式，或正放至同一合法 `[ell,g]`。记 `s=log(t/ell)`、`T=log(g/ell)`。本文中的 s 仅为辅助对数时间，不是当前核软度。所有当前软度、L、R、g、同一个捕获 alpha 在这条行上固定。

原定义直接见 R128 冻结 `proof.md` RT1–6（约610–667行）：
\[
 d\mathcal T_I=1_I1_{\{j(x)=j\}}q^{-1}p_yh_R(x-z)a_\omega
 \,dx\,\beta_V(dy)\nu_V(dz),
 \qquad p_y=P_{s_{\rm soft},L}(x-y).
\tag{JS1}
\]
期望、V/j 求和以及 high 门均保留。终端 `G=S_g`、`B=D_g` 包含于 `Z_g`；实际 target 权
\[
 A_v=1_G(v)\rho_v\frac{J_v}{S_v},\qquad
 S_v=p_v+p_v^++J_v=3Q_x^*(v)
\tag{JS2}
\]
沿辅助时间固定。实际正门还含 `Psi`、`chi_FA` 和原 history。原正 score 为 `(k_v-k_u)_+`，原存活负 score 为 `(k_u-k_v)_+` 且没有正项的 rho/FA 系数；后来删除槽另有原 `N_del`。本文不消费这些负信用。

同 RT4，固定 `(omega,V,j,y,t)` 的 `nu,Z_t,w_t,e_t,Pi_t` 独立 x，但终端 g、A、high、good/bad 以及选择器依 x：
\[
 C_i(v)=C(|y_i-v_i|/b),\quad a_i(v)=\frac b{c_j}C_i(v),\quad
 w_t(v)=\prod_i\min(1,a_i(v)/t),\quad
 k_t(v)=\#\{i:a_i(v)<t\},\quad
 \Pi_t(dv)=\frac{1_{Z_t}(v)w_t(v)}{e_t}\nu(dv).
\tag{JS3}
\]
零 e 行先按原定义取零，后面的归一式只用于正 e 行。原 far 时钟满足 `xi_t=c_jt/b` 在 `[1/2,1]` 内；特别 `xi_g<=1`。若扩时间，必须保留这项上端资格及原可定义域，不能将任意更晚 g 填入本稿几何界。

**bad 的准确范围。** RT5 仅给
\[
 p_yw_g(u)>KQ_x^*(u),\qquad
 w_g(u)>\kappa_u:=KQ_x^*(u)/p_y.
\tag{JS4}
\]
这里 kappa_u 依 x、u。全 bad 不具有固定正 kappa。只有额外互反 bad 子支才可推出旧的统一下界；本稿不将该子支扩成一般来源。FIRST 的 `int Q*nu<=q` 不给低 Q 域的反向质量帽。

## 2. 全域 C 控制及阈值的真实剩余时间

R181 冻结 `normalized_joint_bridge.md` NB4–5（约34–59行）已自证
\[
 |\log C(d)-\log C(d')|\le18|d-d'|\quad(d,d'\in\mathbb R).
\tag{JS5}
\]
该证明对全 d 有效：内部用 `|C'|<=1,C(1)>1/18`，尾部用 `C=h*phi` 及 phi 的对数斜率界。它不只适用于核心内。原 `h=1_{[-1/2,1/2]}`、`phi=h*w<=1`，故在该区间 `max(h,phi)=1`，直接有 `C(0)=1`；亦有 `0<C<=1`。

对任一固定来源 v 定义真实时钟耗散
\[
 L_v:=\int_0^T k_t(v)\,ds
 =\log\frac{w_\ell(v)}{w_g(v)}
 =\sum_i\left[\log\frac{\xi_g}{\max(\xi_\ell,C_i(v))}\right]_+.
\tag{JS6}
\]
因此
\[
 0\le L_v\le-\log w_g(v)
 \le\sum_i-\log C_i(v)
 \le\frac{18}{b}\|y-v\|_1.
\tag{JS7}
\]
最后两步用 `xi_g<=1` 和 JS5，而非来源概率归一。

若坐标阈值 `t_i=a_i(v)` 位于 `(ell,g)`，其剩余对数时间满足
\[
 g_i:=\log(g/t_i)=\log(\xi_g/C_i(v))
 \le-\log C_i(v)\le18|y_i-v_i|/b.
\tag{JS8}
\]
更准确的完整账包括起点已激活的坐标：
\[
 T k_{\ell+}(v)+\sum_{\ell<t_i<g}\log(g/t_i)=L_v.
\tag{JS9}
\]
同一来源的同时阈值按坐标重数计；起点阈值归入右内迹，末端阈值不贡献时间。JS8 不能用于丢掉 JS9 的初始 score 项。

## 3. 两源剩余时间加权能量

固定 v,u，暂不含实际后验重用系数。所有物理 w 均正。设
\[
 b_s=\frac{w_t(v)}{w_t(v)+w_t(u)},\quad
 l_s=\log\frac{w_t(v)}{w_t(u)},\quad
 d_s=k_t(u)-k_t(v),\quad a_s=T-s.
\tag{JS10}
\]
则 l、b 连续且绝对连续，`l'=d`、`b'=b(1-b)d`。d 是有限整数阶梯。采用起点右内迹、末点左内迹，阈值测度只含开区间 `(0,T)`。T=0 时全部积分为零。

**命题。** 对所有这些真实物理阈值，无需坐标独立或来源质量条件，
\[
\begin{split}
 E^{\rm rem}_{vu}
 &:=\int_0^T (T-s)b_s(1-b_s)d_s^2\,ds\\
 &=-T(b_0-\tfrac12)d_0
   -\int_{(0,T)}(T-s)(b_s-\tfrac12)\,dd_s
   +\log\cosh(l_T/2)-\log\cosh(l_0/2)\\
 &\le L_v+L_u
 \le\frac{18}{b}(\|y-v\|_1+\|y-u\|_1).
\end{split}
\tag{JS11}
\]
证明：对 `(T-s)(b-1/2)d` 作 Stieltjes 分部。末端权为零；权导数产生 `int(b-1/2)d ds`，其准确原函数为 `log cosh(l/2)`，不能把这一项省去。再用
\[
 |dd|\le dk_u+dk_v,\quad |d|\le k_u+k_v,\quad |b-1/2|\le1/2
\]
以及 JS9，前两项绝对上界至多 `(L_u+L_v)/2`，最后一项至多 `(L_u+L_v)/2`，得到结论。logcosh 差本身可以为负，证明未把它误当非负耗散。

加权交换的直接推论为
\[
 \int_0^T\sqrt{T-s}\,b(1-b)|d|\,ds
 \le\frac12\sqrt{T(L_u+L_v)}.
\tag{JS12}
\]
它来自 Cauchy 与 `int b(1-b)<=T/4`。这与 R209 WR13–14 的无权 `E<=N_pair, TV b<=sqrt(TN_pair)/2` 不同：它把晚发生的阈值按实际剩余时间收费。它并不改善所有来源对；当两来源远离 y 时 JS7 可仍为线性维数。

## 4. 乘回原双 e：几何与重用项必须同时保留

定义原重用系数
\[
 \Omega_s(v,u)=\frac{1_{Z_t}(v)1_{Z_t}(u)(w_t(v)+w_t(u))^2}{e_t^2}.
\]
精确地
\[
 d\Pi_t(v)d\Pi_t(u)=\Omega_s b_s(1-b_s)\,d\nu(v)d\nu(u),
 \qquad(k_v-k_u)_+=(-d_s)_+.
\tag{JS13}
\]
本式没有把 nu² 或 `1/e²` 当成概率。对有限正 e 截断及 BV 的原重用路径，带权式变为
\[
\begin{split}
 E^{\rm rem}_{vu}[\Omega]
 &=\int_0^T a_s\Omega_s b_s(1-b_s)d_s^2\,ds\\
 &=-T\Omega_0(b_0-\tfrac12)d_0
 -\int_{(0,T)}a_s\Omega_s(b_s-\tfrac12)\,dd_s\\
 &\quad-\int_{(0,T)}a_s d_{s-}(b_s-\tfrac12)\,d\Omega_s
 +\int_0^T\Omega_s(b_s-\tfrac12)d_s\,ds.
\end{split}
\tag{JS14}
\]
阈值原子中的 Omega 取后态，`dOmega` 原子中的 d 取前态，故同时阈值/删除的交叉项不漏。连续奇异删除包含在 `dOmega` 中；一般可测 history 不自动成为 BV 权，不能将它直接并入后声称分部有效。未来被删除 pair 也可保完整支持写本式，其负移除和正归一重标都须保留。原终端 G×B pair 始终存活，只承受其它来源删除引起的重标。

JS8 只能将 JS14 的阈值项正放为
\[
 \frac9b\sum_{z\in\{v,u\}}\sum_{\ell<t_i(z)<g}
 |y_i-z_i|\,\Omega_{t_i(z)}(v,u).
\tag{JS15}
\]
初始项、最后的连续权导数项、以及有符号重用交换仍在。这里 Omega 恰在实际阈值处取样，不能以无权 JS11 消掉。特别不能从单来源 `k<=n` 推出全来源后验阈值生产 `<=n`。

非删除段，对终端 pair 有
\[
 d\log\Omega/ds=2(\Pi_t k-k_t^{\rm pair}),\quad
 k_t^{\rm pair}=b_sk_t(v)+(1-b_s)k_t(u).
\tag{JS16}
\]
若同一事件删除比例为 delta，终端 pair 的 Omega 乘 `(1-delta)^{-2}`。这是实际双后验重标，不是 RT2/RT3 的某笔负信用原子；不得直接以 N_del 抵消它。

## 5. 原积分回代与最早仍需的联合估计

在 JS1 的同一外测度、原 high、原 source 标签与 `nu²` 下，令 `0<=M<=1` 保持实际 A、Psi、FA 和需要的正门。设 a=T-s。原正交通在 `a>=h>0` 的部分满足
\[
 \int_{a\ge h}M\Omega b(1-b)(-d)_+
 \le h^{-1/2}
 \left(\int_{a\ge h}M\Omega b(1-b)\right)^{1/2}
 \left(\int_{a\ge h}M a\Omega b(1-b)d^2\right)^{1/2}.
\tag{JS17}
\]
所有积分均同时包含 `ds dnu² dT_I`、期望与原求和。这里没有省掉 p_y、q、硬源 z 或源质量；h 的倒平方根是真实费用。余下 `a<h` 的交通必须另付。JS12 本身只支付带 `sqrt a` 的通量，不能免费除去该权或把末端短窗删除。

若为使用 JS14 正放 M，必须仍保原来源标签、接收域和能保证有限性的截断。最早未付关系现在具体为：在同一个原来源/接收积分中，JS15 的**阈值位置重用权**与 JS14 的
\[
 -\int a_s d_{s-}(b_s-1/2)d\Omega_s
 \quad\hbox{及}\quad
 \int\Omega_s(b_s-1/2)d_s\,ds
\tag{JS18}
\]
能否连同初始项，被同 alpha 的 A 抑制及原尚未消费的反向交通联合控制，并支付 JS17 的 h 费与末端短窗。这里需要的是带 `p_y A,high,good/bad,Psi` 的真实列预算，而非新的裸后验能量单调性。

具体而言，原 bad 只给 JS4 的可变 kappa_u；在 nonreciprocal、低 `Q_u/p_y` 的 heavy 交通上，没有统一 `w_g(u)>kappa` 可将上述列化成旧互反预算。同 alpha 仍是原 `alpha=(Dq-int U nu)/int Jnu`，未重选；本稿未证明它对 JS15 的阈值取样有额外可求和容量。因此未将必要几何位移上界登记为来源付款。

原 signed J-share 必须恢复 RT2 的两笔负项及 R209 WR6 的 suffix/FA 差；本稿没有消费任何一笔，不能将 JS14 里的负移除当作已识别的原 N_del。若最终按原 high 行取得统一接收界，才可保唯一 j 合并；当前逐 pair/逐窗工具不免除实际 j/time 和独立窗口费用。没有来源独立、nu<=beta、免费选择器或 source mass cap 假设。

结论：JS11–12 是本轮严格新增的剩余时间加权物理路径估计，JS14–18 把其不能直接变成原根价的第一处障碍完整保留。它将下一步需控制的生产位置落实为真实 C 阈值和实际 Omega 取样；一般 nonreciprocal/低终端权来源预算仍未闭合。
