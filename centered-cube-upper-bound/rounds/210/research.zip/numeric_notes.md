# R210 exact aggregate threshold-production checks

Nine prescribed product-clock source models, three complete clock-derived capture certificates and three reused remaining-time pair checks were actually evaluated in three stages, with no random parameter search or floating integration. Algebraic quantities and certificate endpoints use standard-library Fraction; the irrational remaining-time energies are stored as exact rational-linear log expressions with rigorous rational enclosures. These are finite actual min-product clocks and their complete source posterior, not a realization of original physical overlap geometry, capture/high/FIRST, original negative credit or FULL history. No general O(n) energy or asymptotic order is inferred.

## Definitions and exact calculation

Source i has fixed positive rational mass mu_i and n fixed thresholds C_ij in (0,1]. Its actual clock is w_i(tau)=product_j min(1,C_ij/tau). The active posterior is Pi_i=1_alive mu_i w_i/e using the full e=sum_alive mu_i w_i; masses are not independently normalized by source. Scores k_i count C_ij<tau. All rows are retained with their actual shared mu and thresholds, including perfectly correlated coordinates and permutations of identical coordinate multisets.

The interval is tau in [1/2,1], with derivative in log tau. Start scores use right interior traces #{C_ij<=1/2}; terminal scores use left interior traces #{C_ij<1}. Endpoint threshold jumps are not included as interior production. All interior thresholds and deletion times are sorted and deduplicated. On each open segment the scores are constant, actual endpoint weights satisfy w(right)=w(left)(left/right)^k, and the independent midpoint derivative verifies m'=-Var(Pi k). Variance is calculated both as sum Pi(k-m)^2 and the unordered pair sum sum_{i<j}Pi_iPi_j(ki-kj)^2, without a missing factor two.

Thus the segment's exact integral of Var dlog tau is m(left+)-m(right-), a rational number. At a shared threshold all active score increments are combined once; production is sum Pi_i Delta k_i. Its value is independently checked by the actual mean jump, using the same pre-deletion posterior and all simultaneous post-threshold scores.

Optional deletions remove only designated E-eligible sources. Every event uses threshold updates first, then one simultaneous deletion batch. For its complete current posterior mass d<1 and removed score mass r, the directly recomputed survivor posterior gives Delta m=(d*m_before-r)/(1-d). Here m_before uses the post-threshold scores. The combined event jump equals threshold production plus this deletion jump. There is no claim that deleting a source is a time density or that original negative credit is automatically consumed.

The complete exact identity is

Eglobal=m_start-m_end+threshold_production+sum deletion_mean_jumps.

All three contributions remain in JSON, along with the incorrect expressions obtained by omitting production or deletion, for transparent comparison. A source's k being monotone does not remove its posterior-weighted threshold production.

## Three finite stages

Initial models are n=1 identical three-source thresholds at 3/4, with an E deletion at that same time; the two-source endpoint configuration C=1/2,D=1; and n=2 staggered C=(1/2,3/4),D=(5/8,1). Independently hardcoded expected energies are respectively 0,1/6,1/8, and threshold productions are 1,0,1. The first has mean endpoint contribution -1 and simultaneous threshold/deletion mean jump parts +1 and 0, leaving energy zero. These are direct hand calibrations of signs and endpoint conventions.

Pressure uses n=4 three-source repeated thresholds (5/8)^4,(3/4)^4,(7/8)^4 with masses 1,3,1/2; n=4 sources with coordinate-permuted equal multisets plus a repeated-threshold row; and n=8 heavy masses with two E sources deleted concurrently at 3/4, where threshold updates also occur. Equal threshold multisets are checked to yield identical clocks irrespective of coordinate ordering. Heavy source masses include 2^-20 and 2^20; no source-independence or independent-coordinate distribution is assumed.

Expanded models use n=8 dense thresholds with a rare mass 2^-40; n=16 thresholds 2^-100 with mass 2^50 alongside two competing clocks; and n=16 deletion of a low-score E source with mass 2^20 at 7/8. Extremely small weights remain nonzero Fraction values. The last deletion makes a large positive mean jump because normalization removes a low-score dominant source; that jump is fully retained.

The final menu has 9 models, 30 constant-score segments and 21 internal events. Three actual deletion batches have mean jumps positive, negative and zero once each. This is a deliberately small diagnostic set, not a counterexample library or a fitted n trend.

## Observed aggregate costs

In the n=4 repeated-threshold model, production is approximately 4.742723955, exceeding n=4, while the endpoint contribution is -4 and energy is approximately .742723955. The exact rational production and energy are retained; this finite observation explains why the production cannot simply be discarded, rather than proving a general superlinear energy order.

The n=8 concurrent-deletion model has energy approximately 1.60320e-6, production 3.48307e-6, endpoint contribution 1.27157e-6 and deletion mean jump -3.15144e-6. The n=16 low-score deletion model has energy approximately 2.92203e-5, production 1.52588e-5, endpoint contribution -15.9999847412 and deletion jump +15.9999987027. The cancellation is computed exactly, so no rounded large-number subtraction decides positivity. Omitting either sign of deletion mean jump would break the exact identity.

The D04 skill was used only for the discipline of retaining the true joint source/posterior and conditional normalization, with all quantities finite. No source product reference, entropy chain-rule theorem, infinite limit or literature constant is invoked. Original pair reweighting, source reuse and receiver/selector costs remain unpriced by these identities.

## Three complete clock-derived capture certificates

These are explicitly conditional arrays, not a common spatial phi/K0 realization. Source labels (v,u,z) have nu=(1,1,1), all remain alive, terminal target labels {v,z}, and bad label {u}. Absolute thresholds beta=(1,2,1/2) give w_i(t)=min(1,beta_i/t). Equivalently the script's normalized C=(1/2,1,1/4) is evaluated at tau=t/2, so the same actual clock helper is used. Start time is 1, future g=2, Tcap=1/2, and e_g=1+1/2+1/4=7/4. Here Tcap is the fixed coefficient in a=Tcap(w_start-w_h), not the log-window length.

In the initial and boundary cases h=3/2 and a=(1/6,0,1/12); J_i=1/24 and QJ=1/8. Initial capture kappa=(1/12,1/24,1/24),Dq=1/6, while boundary kappa=(1/12,0,1/24),Dq=1/8. In expanded pressure h=5/4, a=(1/10,0,1/20),kappa=(1/20,1/40,1/40),Dq=1/10, and J_i=1/48,QJ=1/16. This final J is necessary to retain QJ<=q with D=1. Capture kappa is not the integer clock score k.

Every a is recalculated from the actual clock endpoints. For Ecap-minus={v},Ecap-plus={v,z}, U=1_Ecap min(a,kappa), H=Dq-sum U nu and alpha=H/QJ are recomputed from the full common source. The script checks sum kappa nu=Dq, QJ<=q, nonnegative H and Gcap=sum Delta U nu=Hminus-Hplus. The three alpha changes are 2/3→1/3,1/3→0,4/5→2/5; Gcap is 1/24,1/24,1/40. The a_u=0 row uses its direct zero-target branch without division by a. Only persistent {v} recovery is charged to Gcap; new-entry z's a rho is recorded separately and not declared paid.

The v shares are zminus=zplus=1/2 in the first two cases, and zminus=1/2,zplus=1/3 in the third. All S are explicitly positive multiples of J and nondecreasing. The exact actual change Delta A=zplus*rho_plus-zminus*rho_minus is decomposed into zplus Delta rho minus (zminus-zplus)rho_minus. Third-case recovery coefficient is 1/36, actual denominator-negative coefficient is 1/18 and net Delta A=-1/36. That actual negative is retained, not replaced by a positive upper estimate or offered as original raw negative credit.

For 1<t<h<2 the full clock scores are (1,0,1), actual weights are (1/t,1,1/(2t)) and e_t=(t+3/2)/t. The script directly evaluates the full posterior and verifies Pi_v Pi_u/t=1/(t+3/2)^2, with positive-score difference one. There is no omitted dt/t factor. The exact pair kernel is consequently 1/(1+3/2)-1/(h+3/2), equal to 1/15,1/15,2/55. As an independent aggregate check, m_start-m_h=(3/2) times this pair kernel on the fixed-score prefix.

The actual recovery costs are 1/360,1/360,1/990. They are bounded by the full-e_g endpoint FTC expressions 1/126,1/126,1/315, equal to sum_persistent zplus a Delta rho nu/(Tcap e_g), and then by Gcap/(Tcap e_g)=1/21,1/21,1/35. Weighted and unweighted a Delta rho capacities are checked separately. The third actual signed net is -1/990, while its recovery cost remains positive. These are exact conditional clock/capture certificates with no inverse-a or inverse-alpha upper payment. The original e_g, common source, actual geometry/capture qualifications, entry, selector and full outer-measure costs remain; e_g is not removed by this calculation.

## Three remaining-time pair checks with rigorous rational logs

Only source rows 0 and 1 of the first three existing clock models are reused: identical n=1 thresholds at 3/4, n=1 endpoint thresholds 1/2 versus 1, and the n=2 staggered pair. No new C arrays are introduced. The relative pair is bpair=wv/(wv+wu), without source mass factors mu; those belong to the original outer source measure and reuse coefficient, not this bare pair energy. In particular the first aggregate model's third-source deletion changes its full normalizer but does not change the equal-weight relative pair. Its reuse exchange is not silently paid here.

The window is [1/2,1]. On each constant d=ku-kv segment, remaining time is a(tau)=log(1/tau), odds=wv/wu, and the exact primitive is

Eseg=d[b_R log(1/R)-b_L log(1/L)]+log[(1+odds_R)/(1+odds_L)].

A d=0 segment is returned as zero directly. The exact endpoint odds power law is verified. All log arguments are positive rationals. As an independent identity, the code constructs the global JS11 Stieltjes expression: the initial term, all interior d-jumps weighted by remaining time, and the log-cosh endpoint difference. The latter is expressed as log[(1+odds_end)/(1+odds_start)]-(1/2)log(odds_end/odds_start). Prime factorization converts both formulas to the same rational coefficients of log primes, which match exactly. Endpoint threshold jumps are not included as interior jumps.

For q>0, the log enclosure first writes q=2^k r,1<=r<2. With z=(r-1)/(r+1), it uses 40 positive atanh terms and the explicit remaining bound

0<=log(r)-2sum_{j=0}^{39}z^(2j+1)/(2j+1)<=2z^81/[81(1-z^2)].

The same formula at r=2 encloses log 2. Negative dyadic exponents and negative coefficients swap interval endpoints. Every endpoint operation is Fraction arithmetic; no floating log, directed-rounding software assumption or uncertified quadrature enters this group. The series tail is a mathematically explicit truncation bound. It certifies these finite log expressions, not the general theorem from the examples.

The three Erem expressions are exactly 0; log 3-(3/2)log 2; and (37/18)log 2-(4/9)log 3-(5/9)log 5. Their values are approximately 0,.05889151783,.04239823595 (display only). The nonzero interval widths are below 2.27e-40. The source dissipations Lv+Lu are separately enclosed from log(wv_start/wv_end)+log(wu_start/wu_end). Each case passes the stronger rational comparisons lower(Erem)>=0 and upper(Erem)<=lower(Lv+Lu). Thus 0<=Erem<=Lv+Lu is certified for these three fixed paths. The original Omega=(wv+wu)^2/e^2, outer nu squared measure, current/capture qualifications and receiver/selector budget remain outside this bare relative-pair certificate.

## Reproduction

Only standard-library Python is required:

```sh
python3 threshold_production_checks.py --output threshold_production_checks.json
```

The script and local task_contract.md suffice for relocation; the latter is hash-bound by portable filename in JSON. All source masses, threshold arrays, endpoint conventions and event order are explicit. Runtime and absolute execution paths are excluded from JSON. The additional capture linkage below uses a computed from the stated actual clocks and a shared full-source capture definition; no free alpha or free gain is substituted.


The final script and contract were actually copied to a fresh temporary directory and run with subprocess exit 0. Complete JSON matched byte-for-byte. Isolated replay took 0.050 seconds (notes only). Directory: /var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r210_final_remaining_ecndjm4b. Actual local interpreter: /opt/homebrew/opt/python@3.14/bin/python3.14.
