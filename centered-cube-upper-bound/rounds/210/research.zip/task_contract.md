# R210：原来源重用与阈值生产的联合几何预算

原一般目标不变，前轮R209已完整提交5a2b28d。使用R209外部最终备份 /Users/zhengzhihao/Desktop/T/output/centered_cube_round209_20261016_final_checkpoint。

准确原对象：同RT1外测度，G=Sg,B=Dg终端存活，Et后来删除，A=1G rho J/S沿辅助t固定，Pi=1Z wnu/e，w=prod min(1,alpha_i/t)，k=#alpha_i<t。正Psi A h D+，负Psi D− onG×B与D− onEt×B。所有high/far、原负余额、beta/nu、dx、唯一j和selector保留。N只能用一次。

唯一核心瓶颈：R209两源energy<=Npair<=n和TV<=sqrt(Npair T)/2乘回Omega=1Zv1Zu(wv+wu)^2/e²后，dOmega引入其它来源/删除重用。本轮寻找其与原负项和来源几何的可支付联合控制；不再独立按supOmega粗放。

允许工具：R208 FO真实一阶面核与LC捕获容量、R209完整LP删除势/反射cut、WR物理两源能量及严格带权恒等式。来源位置见备份各稿。不允许nu<=beta、R单调、任意source独立性、免费selector或重复负信用。一般score能量不能仅由每源k单调就称O(n)；必须保后验阈值生产。

主代理研究聚合后的后验均值/阈值生产恒等及其几何接合。Astra负责唯一核心实际Omega/共同来源几何付款；Sol辅助负责不重复的捕获/负信用耦合；Sol独审先独立量词检查，再读稿；数值Sol运行最小精确阈值与几何方案，先方案后执行。各自仅写指定文件，不能改其他文件/git，不自行扩展。

使用D04熵链式技能的真实联合律/条件核/有限性纪律，未引用未经核验的文献定理。当前源完全保留相关性。有限模型或附条件支不称一般闭合；有意义的结果必须改变全局费用，而非只重命名余项。

交付需逐项写定义、推导、常数和量词、原测度回代、数值三阶段范围和缺口。轮末完整审核后精简归档并独立提交origin/main，不编译PDF。
