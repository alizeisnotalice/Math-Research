#!/usr/bin/env python3
"""Exact aggregate threshold production and posterior mean ledger, finite only."""
import argparse,hashlib,json
from fractions import Fraction as F
from itertools import combinations
from functools import lru_cache
from pathlib import Path
HERE=Path(__file__).resolve().parent
LO=F(1,2);HI=F(1)

def enc(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple,set)):return [enc(v) for v in x]
    return x

def weights(C,tau):
    values=[]
    for row in C:
        value=F(1)
        for c in row:value*=min(F(1),c/tau)
        values.append(value)
    return values

def state(C,mu,tau,k,alive):
    w=weights(C,tau);raw=[mu[i]*w[i] if i in alive else F(0) for i in range(len(mu))]
    e=sum(raw);assert e>0
    Pi=[x/e for x in raw];m=sum(Pi[i]*k[i] for i in range(len(mu)))
    variance=sum(Pi[i]*(k[i]-m)**2 for i in range(len(mu)))
    pair_variance=sum((Pi[i]*Pi[j]*(k[i]-k[j])**2 for i,j in combinations(range(len(mu)),2)),F(0))
    Pidot=[Pi[i]*(m-k[i]) for i in range(len(mu))]
    mdot=sum(k[i]*Pidot[i] for i in range(len(mu)))
    assert variance==pair_variance==-mdot and sum(Pi)==1 and sum(Pidot)==0
    return dict(w=w,active_raw_mass=raw,e=e,Pi=Pi,k=k,mean=m,variance=variance,pair_variance=pair_variance,Pidot=Pidot,mean_derivative=mdot)

def check_case(stage,label,C,mu,deletions=None,E_allowed=None):
    deletions={} if deletions is None else deletions;E_allowed=set() if E_allowed is None else set(E_allowed)
    M=len(C);n=len(C[0]);assert M==len(mu) and M>=2 and n>=1
    assert all(len(row)==n and all(0<c<=1 for c in row) for row in C) and all(x>0 for x in mu)
    assert all(LO<t<HI and set(D)<=E_allowed for t,D in deletions.items())
    cuts=sorted({LO,HI}|{c for row in C for c in row if LO<c<HI}|set(deletions))
    alive=set(range(M));kstart=[sum(c<=LO for c in row) for row in C];kend=[sum(c<HI for c in row) for row in C]
    initial=state(C,mu,LO,kstart,alive);current=initial
    energy=production=delete_mean_total=F(0);segments=[];events=[]
    for left,right in zip(cuts,cuts[1:]):
        mid=(left+right)/2;k=[sum(c<mid for c in row) for row in C]
        left_state=state(C,mu,left,k,alive);right_state=state(C,mu,right,k,alive);mid_state=state(C,mu,mid,k,alive)
        assert left_state['mean']==current['mean'] and left_state['Pi']==current['Pi']
        wl=weights(C,left);wr=weights(C,right)
        for i in range(M):assert wr[i]==wl[i]*(left/right)**k[i]
        part=left_state['mean']-right_state['mean'];assert part>=0
        energy+=part
        segments.append(dict(left=left,right=right,alive=sorted(alive),k=k,left_state=left_state,right_state_left_trace=right_state,midpoint_state=mid_state,exact_variance_integral=part,exact_weight_power_law=True))
        current=right_state
        if right==HI:
            assert k==kend
            continue
        kplus=[sum(c<=right for c in row) for row in C]
        jumps=[kplus[i]-k[i] for i in range(M)]
        assert all(j>=0 for j in jumps)
        threshold=sum(right_state['Pi'][i]*jumps[i] for i in range(M))
        after_threshold=state(C,mu,right,kplus,alive)
        assert threshold==after_threshold['mean']-right_state['mean']
        production+=threshold
        deleted=set(deletions.get(right,()))
        assert deleted<=alive and deleted<=E_allowed
        d=sum(after_threshold['Pi'][i] for i in deleted)
        removed_k=sum(after_threshold['Pi'][i]*kplus[i] for i in deleted)
        assert 0<=d<1
        survivors=alive-deleted;after_delete=state(C,mu,right,kplus,survivors)
        deletion_jump=after_delete['mean']-after_threshold['mean']
        deletion_formula=(d*after_threshold['mean']-removed_k)/(1-d)
        assert deletion_jump==deletion_formula
        assert after_delete['e']==after_threshold['e']*(1-d)
        assert after_delete['mean']-right_state['mean']==threshold+deletion_jump
        delete_mean_total+=deletion_jump
        events.append(dict(tau=right,alive_before=sorted(alive),raw_threshold_jumps=jumps,active_threshold_jumps=[jumps[i] if i in alive else 0 for i in range(M)],before_threshold=right_state,after_all_thresholds=after_threshold,threshold_production=threshold,deleted_E=sorted(deleted),deleted_mass=d,removed_score_mass=removed_k,actual_delete_mean_jump=deletion_jump,delete_formula=deletion_formula,after_delete=after_delete,combined_mean_jump=after_delete['mean']-right_state['mean']))
        alive=survivors;current=after_delete
    final=current
    identity=initial['mean']-final['mean']+production+delete_mean_total
    assert energy==identity
    groups={tuple(sorted(C[i])) for i in range(M)}
    # Identical threshold multisets have identical clocks even if coordinates
    # are permuted; neither coordinate nor source independence is assumed.
    equal_clock_pairs=[]
    for i,j in combinations(range(M),2):
        if sorted(C[i])==sorted(C[j]):
            for tau in cuts:
                ww=weights(C,tau);assert ww[i]==ww[j]
            equal_clock_pairs.append([i,j])
    return dict(stage=stage,label=label,n=n,source_count=M,C=C,mu=mu,E_allowed_to_delete=sorted(E_allowed),deletion_schedule=[dict(tau=t,indices=sorted(D)) for t,D in sorted(deletions.items())],cuts=cuts,initial=initial,final=final,segments=segments,events=events,equal_clock_pairs=equal_clock_pairs,total_energy=energy,total_threshold_production=production,total_delete_mean_jump=delete_mean_total,start_mean=initial['mean'],end_mean=final['mean'],endpoint_contribution=initial['mean']-final['mean'],complete_ledger_rhs=identity,energy_over_n=energy/n,production_over_n=production/n,wrong_rhs_omitting_production=initial['mean']-final['mean']+delete_mean_total,wrong_rhs_omitting_delete_mean=initial['mean']-final['mean']+production,status='PASS_FINITE_EXACT')

def clock_capture_checks():
    specifications=[('initial','positive_capture',F(3,2),[F(1,12),F(1,24),F(1,24)],F(1,6),F(1,24),F(2),F(2)),('stress','alpha_plus_zero',F(3,2),[F(1,12),F(0),F(1,24)],F(1,8),F(1,24),F(2),F(2)),('expanded','denominator_negative_net',F(5,4),[F(1,20),F(1,40),F(1,40)],F(1,10),F(1,48),F(2),F(3))]
    rows=[]
    for stage,label,h,kappa,Dq,Jvalue,Sfactor_minus,Sfactor_plus in specifications:
        C=[[F(1,2)],[F(1)],[F(1,4)]];nu=[F(1)]*3;J=[Jvalue]*3;QJ=sum(J)
        tstart=F(1);g=F(2);Tcap=F(1,2);alive=set(range(3));clock_scores=[1,0,1]
        assert tstart==1 and tstart<h<g==2
        assert not any(tstart/2<c<h/2 for row in C for c in row)
        wstart=weights(C,tstart/2);wh=weights(C,h/2);wg=weights(C,g/2)
        a=[Tcap*(wstart[i]-wh[i]) for i in range(3)]
        Eminus={0};Eplus={0,2};persistent={0}
        Uminus=[min(a[i],kappa[i]) if i in Eminus else F(0) for i in range(3)]
        Uplus=[min(a[i],kappa[i]) if i in Eplus else F(0) for i in range(3)]
        Hminus=Dq-sum(Uminus);Hplus=Dq-sum(Uplus)
        Gcap=sum(Uplus[i]-Uminus[i] for i in range(3))
        assert sum(kappa)==Dq and QJ<=Dq and QJ>0 and Hminus>=Hplus>=0
        assert Hminus-Hplus==Gcap and Eminus<=Eplus
        alpha_minus=Hminus/QJ;alpha_plus=Hplus/QJ
        def rho(i,alpha):
            if a[i]==0:return F(0)
            return max(F(0),1-(kappa[i]+alpha*J[i])/a[i])
        rm=[rho(i,alpha_minus) for i in range(3)];rp=[rho(i,alpha_plus) for i in range(3)]
        assert a[1]==0 and rm[1]==rp[1]==0
        Sminus=Sfactor_minus*J[0];Splus=Sfactor_plus*J[0]
        assert Splus>=Sminus>=J[0]>0
        zminus=J[0]/Sminus;zplus=J[0]/Splus;gain_rho=rp[0]-rm[0]
        delta_A=zplus*rp[0]-zminus*rm[0]
        recovery=zplus*gain_rho;denominator_negative=(zminus-zplus)*rm[0]
        assert delta_A==recovery-denominator_negative and gain_rho>=0
        weighted_capacity=sum((zplus*a[i]*(rp[i]-rm[i])*nu[i] for i in persistent),F(0))
        plain_capacity=sum((a[i]*(rp[i]-rm[i])*nu[i] for i in persistent),F(0))
        assert 0<=weighted_capacity<=plain_capacity<=Gcap
        eg=sum(wg[i]*nu[i] for i in range(3));assert eg==F(7,4)
        density_checks=[]
        for t in (tstart,(tstart+h)/2,h):
            actual=state(C,nu,t/2,clock_scores,alive)
            assert actual['w']==[1/t,F(1),F(1,2)/t]
            density=actual['Pi'][0]*actual['Pi'][1]/t
            closed=1/(t+F(3,2))**2
            assert actual['e']>=eg and density==closed
            density_checks.append(dict(t=t,full_e=actual['e'],Pi=actual['Pi'],positive_score_difference=F(1),actual_pair_density_dt=density,closed_pair_density_dt=closed))
        kernel=1/(tstart+F(3,2))-1/(h+F(3,2))
        prefix_start=state(C,nu,tstart/2,clock_scores,alive)
        prefix_end=state(C,nu,h/2,clock_scores,alive)
        aggregate_prefix_energy=prefix_start['mean']-prefix_end['mean']
        assert aggregate_prefix_energy==F(3,2)*kernel
        endpoint_delta=wstart[0]-wh[0]
        assert 0<=kernel<=endpoint_delta/eg
        recovery_actual=kernel*recovery
        endpoint_FTC_upper=endpoint_delta*recovery/eg
        middle=weighted_capacity/(Tcap*eg);upper=Gcap/(Tcap*eg)
        assert 0<=recovery_actual<=endpoint_FTC_upper==middle<=upper
        signed_net_actual=kernel*delta_A
        assert signed_net_actual==recovery_actual-kernel*denominator_negative
        if label=='alpha_plus_zero':assert alpha_plus==0
        if label=='denominator_negative_net':
            assert Jvalue==F(1,48) and alpha_minus==F(4,5) and alpha_plus==F(2,5)
            assert delta_A==F(-1,36) and recovery==F(1,36) and denominator_negative==F(1,18) and signed_net_actual<0
        new_entry=sum((a[i]*rp[i]*nu[i] for i in Eplus-Eminus),F(0))
        rows.append(dict(stage=stage,label=label,nu=nu,normalized_threshold_C=C,absolute_threshold_beta=[F(1),F(2),F(1,2)],time_start=tstart,h=h,g=g,Tcap=Tcap,w_start=wstart,w_h=wh,w_g=wg,a_from_actual_clock=a,capture_kappa=kappa,D=F(1),q=Dq,Dq=Dq,J=J,QJ=QJ,Ecap_minus=sorted(Eminus),Ecap_plus=sorted(Eplus),persistent_targets=sorted(persistent),terminal_G=[0,2],terminal_B=[1],Uminus=Uminus,Uplus=Uplus,Hminus=Hminus,Hplus=Hplus,alpha_minus=alpha_minus,alpha_plus=alpha_plus,Gcap=Gcap,rho_minus=rm,rho_plus=rp,a_zero_branch_indices=[1],Sminus=Sminus,Splus=Splus,zminus=zminus,zplus=zplus,delta_A=delta_A,recovery_coefficient=recovery,actual_denominator_negative_coefficient=denominator_negative,weighted_capture_capacity=weighted_capacity,plain_capture_capacity=plain_capacity,eg=eg,actual_kernel_density_checks=density_checks,exact_pair_kernel=kernel,aggregate_prefix_energy=aggregate_prefix_energy,actual_recovery_cost=recovery_actual,endpoint_FTC_upper=endpoint_FTC_upper,capture_over_Teg_upper=upper,actual_signed_net_cost=signed_net_actual,excluded_entry_a_rho_plus=new_entry,status='PASS_FINITE_EXACT'))
    return dict(cases=rows,status='PASS_FINITE_EXACT',scope='Three clock-derived a and common-source capture certificates only. kappa is a separate capture array, not clock score k. J/kappa are not certified common spatial phi/K0 values; no original geometry/FIRST/FULL realization or new-entry payment is claimed. Actual full e_g remains in the endpoint/FTC bound, with no inverse-a or inverse-alpha payment.')


def factor_integer(value):
    out={};prime=2
    while prime*prime<=value:
        while value%prime==0:
            out[prime]=out.get(prime,0)+1;value//=prime
        prime+=1
    if value>1:out[value]=out.get(value,0)+1
    return out

def add_log_term(terms,coefficient,argument):
    argument=F(argument);coefficient=F(coefficient);assert argument>0
    for sign,value in ((1,argument.numerator),(-1,argument.denominator)):
        for prime,power in factor_integer(value).items():
            terms[prime]=terms.get(prime,F(0))+coefficient*sign*power
            if terms[prime]==0:del terms[prime]

def atanh_log_interval(r,terms=40):
    assert 1<=r<=2
    z=(r-1)/(r+1)
    low=2*sum((z**(2*j+1)/F(2*j+1) for j in range(terms)),F(0))
    tail=2*z**(2*terms+1)/(F(2*terms+1)*(1-z*z))
    return low,low+tail

@lru_cache(maxsize=None)
def rational_log_interval(argument):
    argument=F(argument);assert argument>0
    exponent=argument.numerator.bit_length()-argument.denominator.bit_length()
    r=argument/F(2)**exponent
    while r<1:r*=2;exponent-=1
    while r>=2:r/=2;exponent+=1
    assert 1<=r<2 and argument==F(2)**exponent*r
    rl,rh=atanh_log_interval(r);ll,lh=atanh_log_interval(F(2))
    return (rl+exponent*ll,rh+exponent*lh) if exponent>=0 else (rl+exponent*lh,rh+exponent*ll)

def log_expression_interval(terms):
    low=high=F(0)
    for prime,coefficient in terms.items():
        lo,hi=rational_log_interval(F(prime))
        if coefficient>=0:low+=coefficient*lo;high+=coefficient*hi
        else:low+=coefficient*hi;high+=coefficient*lo
    return dict(low=low,high=high,width=high-low)

def remaining_pair_checks(aggregate_rows):
    rows=[]
    for stage,source in zip(('initial','stress','expanded'),aggregate_rows[:3]):
        C=source['C'][0];D=source['C'][1];n=len(C)
        cuts=sorted({LO,HI}|{c for c in C+D if LO<c<HI})
        def w(row,tau):return weights([row],tau)[0]
        def odds(tau):return w(C,tau)/w(D,tau)
        def b(tau):
            o=odds(tau);return o/(1+o)
        Eterms={};pieces=[]
        for left,right in zip(cuts,cuts[1:]):
            mid=(left+right)/2;d=sum(c<mid for c in D)-sum(c<mid for c in C)
            seg={}
            if d:
                add_log_term(seg,d*b(right),HI/right)
                add_log_term(seg,-d*b(left),HI/left)
                add_log_term(seg,F(1),(1+odds(right))/(1+odds(left)))
            assert odds(right)/odds(left)==(right/left)**d
            for prime,coefficient in seg.items():
                Eterms[prime]=Eterms.get(prime,F(0))+coefficient
                if Eterms[prime]==0:del Eterms[prime]
            enclosure=log_expression_interval(seg);assert enclosure['low']>=0
            pieces.append(dict(left=left,right=right,d=d,b_left=b(left),b_right=b(right),odds_left=odds(left),odds_right=odds(right),energy_log_prime_coefficients=seg,energy_interval=enclosure))
        # Independent JS11 global Stieltjes identity; log cosh endpoint change
        # is log[(1+odds_end)/(1+odds_start)]-.5 log(odds_end/odds_start).
        global_terms={}
        add_log_term(global_terms,-(b(LO)-F(1,2))*pieces[0]['d'],HI/LO)
        for previous,current in zip(pieces,pieces[1:]):
            tau=previous['right'];dd=current['d']-previous['d']
            add_log_term(global_terms,-(b(tau)-F(1,2))*dd,HI/tau)
        add_log_term(global_terms,F(1),(1+odds(HI))/(1+odds(LO)))
        add_log_term(global_terms,F(-1,2),odds(HI)/odds(LO))
        assert global_terms==Eterms
        dissipation={}
        add_log_term(dissipation,F(1),w(C,LO)/w(C,HI));add_log_term(dissipation,F(1),w(D,LO)/w(D,HI))
        energy=log_expression_interval(Eterms);upper=log_expression_interval(dissipation)
        assert 0<=energy['low']<=energy['high']<=upper['low']
        rows.append(dict(stage=stage,aggregate_input_label=source['label'],source_indices=[0,1],n=n,C=C,D=D,cuts=cuts,pieces=pieces,energy_log_prime_coefficients=Eterms,independent_JS11_log_prime_coefficients=global_terms,energy_interval=energy,dissipation_log_prime_coefficients=dissipation,Lv_plus_Lu_interval=upper,certified_nonnegative=True,certified_energy_le_dissipation=True,relative_pair_excludes_source_mass_mu=True,status='PASS_FINITE_RATIONAL_LOG_INTERVAL'))
    return dict(cases=rows,log_series_terms=40,log2_interval=dict(zip(('low','high'),rational_log_interval(F(2)))),log_method='Exact Fraction dyadic reduction q=2^k r with 1<=r<2; log(r)=2 sum_{j<40} z^(2j+1)/(2j+1)+tail, 0<=tail<=2 z^81/[81(1-z^2)], z=(r-1)/(r+1). Negative coefficients swap enclosure endpoints.',status='PASS_FINITE_RATIONAL_LOG_INTERVAL',scope='Three existing source pairs only, relative b=wv/(wv+wu) without source masses or original Omega. Log expressions and rigorous rational truncation bounds certify these finite cases, not a general source-reuse/selector estimate.')


def run():
    table=[('initial','n1_same_threshold_and_E_deletion',[[F(3,4)]]*3,[F(1),F(2),F(3)],{F(3,4):{2}},{2}),('initial','n1_opposite_endpoints',[[F(1,2)],[F(1)]],[F(1),F(1)],{},set()),('initial','n2_staggered',[[F(1,2),F(3,4)],[F(5,8),F(1)]],[F(1),F(1)],{},set()),('stress','n4_correlated_repeated',[[F(5,8)]*4,[F(3,4)]*4,[F(7,8)]*4],[F(1),F(3),F(1,2)],{},set()),('stress','n4_coordinate_permutations',[[F(1,2),F(5,8),F(7,8),F(1)],[F(1),F(7,8),F(5,8),F(1,2)],[F(1,2),F(1,2),F(3,4),F(3,4)]],[F(2),F(1),F(3)],{},set()),('stress','n8_heavy_mass_concurrent_E_delete',[[F(1,2)]*8,[F(1)]*8,[F(5,8),F(5,8),F(3,4),F(3,4),F(7,8),F(7,8),F(1),F(1)],[F(1,2),F(3,4)]*4],[F(1,2**20),F(2**20),F(1),F(1,3)],{F(3,4):{2,3}},{2,3}),('expanded','n8_dense_and_rare_source',[[F(8+i,16) for i in range(8)],[F(1)]*8,[F(1,2),F(1)]*4],[F(1),F(1,2**40),F(1,8)],{},set()),('expanded','n16_tiny_threshold_mass',[[F(1,2**100)]*16,[F(1)]*16,[F(1,2),F(1)]*8],[F(2**50),F(1),F(1,3)],{},set()),('expanded','n16_delete_low_score_heavy_E',[[F(1,2)]*16,[F(3,4)]*16,[F(1)]*16],[F(1),F(1),F(2**20)],{F(7,8):{2}},{2})]
    rows=[check_case(*values) for values in table]
    assert rows[0]['total_energy']==0 and rows[0]['total_threshold_production']==1 and rows[0]['total_delete_mean_jump']==0
    assert rows[1]['total_energy']==F(1,6) and rows[1]['total_threshold_production']==0
    assert rows[2]['total_energy']==F(1,8) and rows[2]['total_threshold_production']==1
    assert rows[3]['total_threshold_production']>rows[3]['n']
    deletion_jumps=[event['actual_delete_mean_jump'] for row in rows for event in row['events'] if event['deleted_E']]
    assert any(x>0 for x in deletion_jumps) and any(x<0 for x in deletion_jumps)
    captures=clock_capture_checks()
    summary=dict(models=len(rows),auxiliary_clock_capture_models=len(captures['cases']),remaining_time_pair_models=3,stage_counts={stage:sum(row['stage']==stage for row in rows) for stage in ('initial','stress','expanded')},segments=sum(len(row['segments']) for row in rows),internal_events=sum(len(row['events']) for row in rows),actual_deletion_batches=len(deletion_jumps),positive_delete_mean_jumps=sum(x>0 for x in deletion_jumps),negative_delete_mean_jumps=sum(x<0 for x in deletion_jumps),zero_delete_mean_jumps=sum(x==0 for x in deletion_jumps))
    return dict(schema='r210_aggregate_threshold_production_v1',arithmetic='Python stdlib Fraction exact',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},window=dict(left=LO,right=HI,log_length='log(2)'),endpoint_convention='Right interior score at 1/2 counts Ci<=1/2; left interior score at 1 counts Ci<1. Endpoint threshold jumps are not included as interior production.',event_convention='All active threshold score jumps at one tau are simultaneous; then one concurrent E-only deletion batch, using post-threshold scores. Entire combined jump is verified directly.',cases=rows,summary=summary,clock_capture=captures,remaining_time_pairs=remaining_pair_checks(rows),status='PASS_FINITE_EXACT',scope=['Finite actual min-product clock and posterior models, not original source geometry, capture/high/FIRST/history or FULL qualification.','No coordinate/source independence is assumed; all posterior masses are normalized from the same mu_i w_i and full active e.','Energy is the complete aggregate posterior variance integral, not a sum of unweighted source monotonicities. Production and signed deletion mean jumps are retained.','No O(n), asymptotic dimension order, source-reuse payment or uniform receiver/selector budget is inferred from these finite models.'])

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=HERE/'threshold_production_checks.json');args=parser.parse_args()
    result=run();args.output.write_text(json.dumps(enc(result),indent=2,sort_keys=True)+'\n');print(json.dumps(result['summary'],sort_keys=True));print(result['status'])
