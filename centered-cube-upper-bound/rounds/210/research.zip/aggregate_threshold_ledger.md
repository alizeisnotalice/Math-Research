# 聚合来源阈值账：待独审接口，不是全局根预算

固定原RT1行，s=log t，Pi=1Z w nu/e，w'=-kw，0<=k<=n；先有限来源、有限阈值、e>0。令m=Pi k,V=Var_Pi(k)。无删除且阈值之间Pi'=(m-k)Pi，所以m'=-V。一般阈值间积分后
Eglob=∫V ds=m_l-m_r+ΣΔm。

只发生阈值跳时w和Pi连续，Δm=Pi Δk；同时多个坐标跳只记总Δk一次。只删除来源集合D、d=Pi_-(D)<1时，用当前score记kD=d^-1∫D k Pi_-，则Δm=d(m_--kD)/(1-d)。d=0先零，不除零；d=1死亡行终止。阈值与删除同刻可约定先改变score、再删源：前Pi乘Δk，删除项用改变后的score，二者合计为实际mean跳，避免遗漏交叉项。

有限正窗内由此精确得到
Eglob=m_l-m_r+Kthr+Jdel，
Kthr=Σevents Pi_predelete Δk，Jdel=Σevents d(m_beforedelete-kD)/(1-d)。
连续删除部分另加∫(m dλ-∫k dL)/e，保其实际符号。Kthr在一般来源上是后验加权的阈值生产，不等于把每来源最多n次交叉直接平均一次；归一化Pi会改变。

同原Π下1/2∫∫(kv-ku)^2Pi²=V，故R209带Omega的全部source pair能量真正汇总后，问题在Kthr与Jdel，不是每个pair无权energy<=n的无费求和。原A/gates不能随意删除；本接口只解释完整双腿权的归一化代价。

## 固定目标权的内部账
令f固定有界（例如原A，或R209 f_c），F=Pi f，C=Cov_Pi(f,k)。阈值之间F'=-C，且
C'=-Cov_Pi(f,(k-m)^2)。
发生阈值跳且Pi连续时ΔC=Pi(f Δk)-F Pi Δk。若f_c沿来源固定而只删E，F的删除项已由R209LP给出；C的删除仍须逐事件计算，不能继承F非正符号。

全配对的非负f能量还满足
1/2∫∫(f(v)+f(u))(kv-ku)^2Pi²
=Pi[f(k-m)^2]+F V。
这提示需要同时控制同一目标权下的阈值生产与中心化平方偏差，不能只乘一个无权n能量。

当前未证明Kthr、Jdel或加f版本在原RT1外测度的目标费用。真正的几何要求是将实际阈值alpha_i=(b/cj)C(|y_i-v_i|/b)与A=rho J/S及真实receiver门联合使用，不能仅凭有限阈值数或Pi概率性推根阶。此稿为精确费用接口，不能单独作为本轮实质闭合成果。


## 原far分割对剩余时间权的准确接口（新增待审）
原CT2的far域为I∩[tau_j,h_far]，h_far=g exp(-u0/n)，u0>0在来源之前固定。因此原far内r(t)=log(g/t)>=u0/n，不必另造任意的剩余时间cut。为空域先零。

取JS13同一Omega、vartheta、score差d及原非负门0<=M<=1，所有积分都带原RT1外测度、high、nu²和原far指示。记
B0=∫far M Omega vartheta(1-vartheta)，
Brem=∫far M log(g/t) Omega vartheta(1-vartheta)d²，
Iplus=∫far M Omega vartheta(1-vartheta)(-d)+。
则Cauchy给准确原far比较
Iplus² <= (n/u0) B0 Brem。

这只合并了原已有far时间截断与JS加权能量，没有使用新的可自由丢弃门，也不额外生成独立窗口菜单。u0若依行变化，必须留1/u0在相应积分内；本文外提只在同一维度的共同固定u0下。

原[h_far,g]近端费用仍属原分割账，不能称已由本比较支付；此处只说明JS17的末端限制在原far支上已有确定来源。Brem中的Omega重用、阈值取样、初始score及门/来源全部保留。若未来在同一原外测度证明B0<=C WA、Brem<=C u0 (log n)^c WA，才可由本式给Iplus<=C sqrt(n)(log n)^(c/2) WA。这两项联合预算当前均未证明，本式不认证一般闭合。
