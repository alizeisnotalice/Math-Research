# R463：cross-avoid 删除误差的有界代数核验

结论：给定作者真实cap、matching及一阶load估计后，cross-avoid删除的绝对误差可统一付为O((S/ζ)W)，无额外维数因子。这里仅核有限代数接口与解析常数，不证明这些条件在原history中的实现，也不支付剩余L_A²主项。

## 一般算式与费用

固定父，π为概率，0≤l_y≤c，0≤c_yz≤l_y，且E_z c_yz≤l_y/K²。令L=E l_y，

F=E_yz[(l_y−c_yz)(l_z−c_zy)]。

展开为L²−N1−N2+P，其中P≥0，两负项交换y,z相等。因l_z≤c，

N1=E_yz l_z c_yz≤c E_y E_z c_yz≤cL/K²。

所以L²−2cL/K²≤F≤L²。上界还使用每个因子在[0,l_y]内；matching行均值本身不能代替该逐点条件。若lower为负，仍是合法下界，不将其截断误作等式。

给定c=(1+eps)h和∫σL≤c An W，乘原系数S/(ζh²)后的总绝对误差至多

2S(1+eps)² An exp(−2√n)W/ζ。

SymPy精确核对h²消去，未遗漏原S、ζ。对n≥1、b/a≤2、eps≤1/2，令t=√n≥1，An≤1+nlog2。有

(t²e^(−2t))'=2t(1−t)e^(−2t)≤0，

((1+t²log2)e^(−2t))'=−2e^(−2t)[1+(log2)t(t−1)]<0。

于是n e^(−2√n)≤e^(−2)，且统一系数可取

C0=(9/2)(1+log2)e^(−2)=1.03114148959058584085787575269326870715…<26/25。

最终误差<26S W/(25ζ)。这是保留S/ζ的uniform O(W)结算；若ζ或S随维数/母入口变化，必须回代，不能隐藏后声称无条件维度常数。

## 实际有限核验

三个阶段共6个确定性有理输入：初步两个非对称2×2；边界为零load与全部row matching预算饱和的3×3；扩大为5×5、7×7不同源权矩阵。π、l、c_yz均为Fraction，K²抽象取8、16或64。这些是NON-NATIVE容量矩阵，未伪装成原f/真实cube或原K值的几何实例。

| 输入 | L | lower | F | upper |
|---|---|---|---|---|
| small_asymmetric | 7/6 | 133/144 | 2533/2304 | 49/36 |
| small_unequal | 25/32 | 475/1024 | 1385365/2359296 | 625/1024 |
| zero_capacity | 0 | 0 | 0 | 0 |
| saturated_row_budgets | 3/2 | 27/16 | 441/256 | 9/4 |
| bounded_5 | 1 | 13/16 | 77923/81920 | 1 |
| bounded_7 | 1 | 61/64 | 25326445/25690112 | 1 |

实际106项断言包括归一、逐点capacity、matching行均值、展开、负项、sandwich及符号/常数检查；不是106个独立样本。所有矩阵及中间量在JSON。一般sandwich来自上述解析不等式，有限样本仅核实现和边界。

## 工具与复现

实际命令：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r463_numeric.py
```

Python3.12.14，SymPy1.14.0；Fraction精确有理矩阵，SymPy精确代数/导数，Arb192bit常数包围：

[1.03114148959058584085787575269326870715119908330333659098 ±5.36e−57]。

程序严格验证1<C0<26/25。wall约0.11秒；仅计时浮点，数学量均精确有理或有误差包围。输入自含、输出至脚本同目录，无旧轮依赖。无扫描、无原history认证。

冻结白名单：r463_numeric.py、r463_numeric.json、r463_numeric.md。已完成停止。
