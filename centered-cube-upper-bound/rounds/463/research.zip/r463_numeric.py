from fractions import Fraction as Q
from pathlib import Path
import json,sys,platform,time
import sympy as sp
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
start=time.perf_counter();checks=0
ctx.prec=192
def ck(z):
 global checks
 assert z
 checks+=1
def case(name,phase,pi,l,k,weights,cap=Q(3,2)):
 pi=list(map(Q,pi));l=list(map(Q,l));k=Q(k);cap=Q(cap);N=len(pi)
 ck(sum(pi)==1 and min(pi)>0);ck(k>1);ck(all(0<=z<=cap for z in l));ck(len(weights)==N and all(len(row)==N for row in weights))
 C=[[l[i]*Q(weights[i][j])/k for j in range(N)] for i in range(N)]
 for i in range(N):
  ck(all(0<=v<=l[i] for v in C[i]));ck(sum(pi[j]*C[i][j] for j in range(N))<=l[i]/k)
 L=sum(pi[i]*l[i] for i in range(N))
 F=sum(pi[i]*pi[j]*(l[i]-C[i][j])*(l[j]-C[j][i]) for i in range(N) for j in range(N))
 neg1=sum(pi[i]*pi[j]*l[j]*C[i][j] for i in range(N) for j in range(N))
 neg2=sum(pi[i]*pi[j]*l[i]*C[j][i] for i in range(N) for j in range(N))
 pos=sum(pi[i]*pi[j]*C[i][j]*C[j][i] for i in range(N) for j in range(N))
 ck(F==L*L-neg1-neg2+pos);ck(neg1==neg2);ck(neg1<=cap*L/k);ck(pos>=0)
 ck(L*L-2*cap*L/k<=F<=L*L)
 return dict(name=name,phase=phase,pi=pi,l=l,K_squared=k,cap=cap,c_yz=C,L=L,F=F,
  lower=L*L-2*cap*L/k,upper=L*L,cross_negative_each=neg1,cross_positive=pos,error=L*L-F)
rows=[]
rows.append(case('small_asymmetric','initial',[Q(1,3),Q(2,3)],[Q(1,2),Q(3,2)],8,[[1,0],[Q(1,2),1]]))
rows.append(case('small_unequal','initial',[Q(1,4),Q(3,4)],[Q(1,8),1],16,[[Q(1,3),1],[1,Q(1,4)]]))
rows.append(case('zero_capacity','boundary',[Q(1,3)]*3,[0]*3,8,[[1]*3 for _ in range(3)]))
rows.append(case('saturated_row_budgets','boundary',[Q(1,5),Q(1,5),Q(3,5)],[Q(3,2)]*3,8,[[1]*3 for _ in range(3)]))
for N,k in ((5,16),(7,64)):
 pi=[Q(i+1,N*(N+1)//2) for i in range(N)]
 l=[Q(3*i,2*(N-1)) for i in range(N)]
 w=[[Q((2*i+3*j)%5,4) for j in range(N)] for i in range(N)]
 rows.append(case('bounded_'+str(N),'expanded',pi,l,k,w))
# General scalar proof checks: cross errors are nonnegative and each <=cap L/k.
L,c,k,B=sp.symbols('L c k B',positive=True)
a,b,P=sp.symbols('a b P',nonnegative=True)
ck(sp.expand((L**2-a-b+P)-(L**2-2*c*L/k)-((c*L/k-a)+(c*L/k-b)+P))==0)
# All n>=1: set t=sqrt(n)>=1; An<=1+n log2.
t=sp.symbols('t',positive=True)
f=t**2*sp.exp(-2*t)
g=(1+t*t*sp.log(2))*sp.exp(-2*t)
ck(sp.simplify(sp.diff(f,t)-2*t*(1-t)*sp.exp(-2*t))==0)
ck(sp.simplify(sp.diff(g,t)+2*sp.exp(-2*t)*(1+sp.log(2)*t*(t-1)))==0)
# Both derivatives nonpositive for t>=1. eps<=1/2 gives coefficient 9/2.
coef=arb(9)/2*(1+arb(2).log())*arb(-2).exp()
ck(coef>arb(1));ck(coef<arb(104)/100)
# Individual inequalities used by the less sharp sum-of-two estimate.
e2=arb(-2).exp();ck(e2>0);ck(e2<arb(14)/100)
# Explicit integrated normalization: c=(1+eps)h, int sigma L<=c An W.
eps,h,An,W,S,zeta=sp.symbols('eps h An W S zeta',positive=True)
expr=(S/(zeta*h*h))*(2*((1+eps)*h)/k)*((1+eps)*h*An*W)
ck(sp.simplify(expr-2*S*(1+eps)**2*An*W/(zeta*k))==0)
out=dict(scope='NON-NATIVE finite weighted algebra and analytic coefficient certificates; no f/history or canonical realization',
 executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,flint_precision_bits=ctx.prec,checks=checks,
 fixtures=rows,analytic=dict(assumptions='n>=1, b/a<=2, eps in [0,1/2], zeta>0',
 derivative_n_exp='d[t^2 exp(-2t)]/dt=2t(1-t)exp(-2t)<=0 for t>=1',
 derivative_An_exp='d[(1+t^2 log2)exp(-2t)]/dt=-2exp(-2t)[1+log2*t*(t-1)]<0 for t>=1',
 coefficient_exact='(9/2)*(1+log(2))*exp(-2)',coefficient_arb=str(coef),certified_rational_interval=['1','26/25'],
 total_error_bound='error <= (9/2)(1+log2)e^-2 * (S/zeta) W < (26/25)(S/zeta)W',
 original_parameter_bound='error <=2 S(1+eps)^2 An exp(-2sqrt(n)) W/zeta',
 caveat='Uniform O(W) retains S/zeta; cannot hide dimension-dependent zeta or input-dependent S'),
 compute_index=dict(status='complete',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r463_numeric.py',
 arithmetic='Fraction finite matrices, SymPy exact identities, Arb192-bit constant enclosures',seconds=time.perf_counter()-start))
(ROOT/'r463_numeric.json').write_text(json.dumps(out,default=str,indent=2)+'\n')
print(sys.executable,'Python',platform.python_version(),'SymPy',sp.__version__)
for row in rows:print(row['name'],'L',row['L'],'lower',row['lower'],'F',row['F'],'upper',row['upper'])
print('coefficient Arb:',coef,'certified 1 < coefficient < 26/25')
print('PASS',checks,'assertions;',len(rows),'fixed nonnative matrices')
