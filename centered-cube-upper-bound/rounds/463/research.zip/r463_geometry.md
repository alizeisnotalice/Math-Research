# R463：双端点共同父的首次边界进入测度

**范围。** 本附件给一个准确的几何分配及其完整列上界，未证明新的全局根阶价格。所有父和终端仍为 R462 的实际接收者；插值立方体仅用于标记真实来源，不赋予新历史。原 \(P\) 的接受权始终保留。

## 1. 父内嵌套是实际几何性质

对实际 \(A,u\)，置
\[
 Q_u(t)=Q\big((1-t)u+tA,(1-t)R_u+tR_A\big),
 \quad F_u(t)=Q_A\cap Q_u(t),\quad 0\le t\le1.
\]
这里 \(Q(c,R)\) 的 \(R\) 是边长。即使 \(u\notin Q_A\)，\(F_u(t)\) 仍递增：固定 \(x\in Q_A\)，每个带符号坐标约束是关于 \(t\) 的线性不等式，且 \(t=1\) 可行，故可行参数是以1为右端点的区间。

具体令（\(e\in\{-1,1\}\)）
\[
 a_{ie}=R_u/2-e(x_i-u_i),\qquad b_{ie}=R_A/2-e(x_i-A_i)\ge0,
\]
\[
 T_u(x)=\max_{i,e:a_{ie}<0}\frac{-a_{ie}}{b_{ie}-a_{ie}},
\tag{1}
\]
空最大值取0。分母严格正，\(0\le T_u\le1\)，并且
\(x\in F_u(t)\iff T_u(x)\le t\)。所有映射可测；无需 \(f\) 连续或有上界。

两端的并集首次进入参数为 \(T_\cup=\min(T_u,T_v)\)，交集为 \(T_\cap=\max(T_u,T_v)\)。将 \(f(x)1_{Q_A}(x)dx\) 分别推前为 \(\nu_u,\nu_v,\nu_\cup,\nu_\cap\)，则作为 \([0,1]\) 上完整有限测度，
\[
 \boxed{\nu_\cup=\nu_u+\nu_v-\nu_\cap.} \tag{2}
\]
证明逐来源使用 \(\delta_{\min(a,b)}+\delta_{\max(a,b)}=\delta_a+\delta_b\)。这保留真正的负交叠节省；对同一端点对，每份父内来源在并集分配中只出现一次。

**零点不能删除：**
\[
 \nu_\cup\{0\}=f(Q_A\cap(Q_u\cup Q_v)),\qquad
 \nu_\cup([0,1])=m_A.
\]
该0原子来自已经捕获的正来源质量，并非边界零测集。原严格质量门给
\[
 \nu_\cup\{0\}/m_A\le(m_u+m_v)/m_A<2/K^2. \tag{3}
\]
所以真正后续进入的来源比例大于 \(1-2/K^2\)，但这本身不是全局费用。

## 2. 保实际接受权后的完整结算

对原 \(P\) 每条记录附加真实 \(x\sim\pi_A\) 和 (1) 的首入标签。该联合测度总质量严格为 \(R=|P|\)，并保留原 \(y,z\)、active、clock、阶段、路径与接受权；\(x\) 不继承任何旧门。

其来源列密度 \(\mathfrak B(x)\) 满足
\[
 \int f(x)\mathfrak B(x)dx=R.
\tag{4}
\]
只为上界使用 R462 的 \(S/(\zeta h^2)\) 支配。令
\[
 L_A=\int\pi_A(dy)\int\beta_y^*(du)
       1_{\{u\notin Q_A,K^2m_u<m_A\}},\quad
 c=(1+\varepsilon_0)h.
\]
其中 \(\beta_y^*\) 含原 active mask，\(L_A\le c\)。正删除交叉排斥后得到
\[
 \mathfrak B(x)\le\frac S{\zeta h^2}
 \int\sigma(dA)\frac{c_A(x)}{m_A}L_A^2
 \le\frac{S(1+\varepsilon_0)^2}{\zeta}D(x),
 \quad D(x)=\int c_A(x)R_A^{-n}dA. \tag{5}
\]
没有将受历史筛选的终端重新归一，也无核族计数。于是仅有
\(R\le S(1+\varepsilon_0)^2X/\zeta\le S(1+\varepsilon_0)^2A_nW/\zeta\)，并不优于已知粗账。只保首入参数正值的部分，其质量至少 \((1-2/K^2)R\)，但列上界仍是 (5)，不能因此消去父重复。

**唯一缺口。** (2) 已把同一父、同一双端点的共同边界来源完全去重；同一 \(x\) 仍可被许多实际父按 \(c_A(x)/R_A^n\) 重复使用。尚无原接受权与父外、low-rank 几何共同给出的列平均节省，能替代 (5) 的 \(D(x)\) 因子。\(x\) 不具备原 \(y,z\) 的高秩/低共同捕获资格，不能转用其历史付款。本附件不要求更强点态 Schur 界，也不将 (4) 换名作为突破。Sol 的原 crossavoid 信用估计是另一项已证夹逼，不由此处插值交集信用重复计收。

## 3. 本机核验

指定 Python 实跑 **57项 Fraction 断言**。\(n=9,16,25\)，连续来源小盒中心首坐标为 \(-.8,0,.8\)，半边长 \(10^{-3}\)，质量 \(1,2^n-2,1\)；父为中心0、边长2，双child中心首坐标 \(\pm1.1\)、边长1。逐径向区间严格核对父内嵌套和 (2)。正进入来源质量依次为510、65534、33554430；被扣的交集增长分别为512、65536、33554432。即使局部交叠节省很大，也未验证跨父价格。该原生连续来源几何可以有正体积匹配中心块，但其原高rank门失败；不是实际非零 \(P\) 的历史样本。

```python
from fractions import Fraction as F
checks=0;e=F(1,1000)
grid=[F(0),F(1,8),F(1,4),F(1,2),F(3,4),F(1)]
for n in (9,16,25):
 M=F(2)**n;sources=[(F(-4,5),F(1)),(F(0),M-2),(F(4,5),F(1))]
 def cap(c,R,x):
  d=max(F(0),min(x+e,c+R/2)-max(x-e,c-R/2))
  return d*min(2*e,R)**(n-1)/(2*e)**n
 def both(cu,R,cv,x):
  lo=max(cu-R/2,cv-R/2);hi=min(cu+R/2,cv+R/2)
  d=max(F(0),min(x+e,hi)-max(x-e,lo))
  return d*min(2*e,R)**(n-1)/(2*e)**n
 prev=None;tu=tv=tc=tw=F(0)
 for t in grid:
  R=1+t;cu=-F(11,10)*(1-t);cv=-cu
  U=sum(m*cap(cu,R,x) for x,m in sources)
  V=sum(m*cap(cv,R,x) for x,m in sources)
  C=sum(m*both(cu,R,cv,x) for x,m in sources);W=U+V-C
  assert 0<=C<=min(U,V)<=W<=M;checks+=1
  if prev is not None:
   du,dv,dc,dw=[a-b for a,b in zip((U,V,C,W),prev)]
   assert min(du,dv,dc,dw)>=0;checks+=1
   assert dw==du+dv-dc;checks+=1
   tu+=du;tv+=dv;tc+=dc;tw+=dw
  prev=U,V,C,W
 assert tu==tv==M-1;checks+=1
 assert tc==M and tw==M-2;checks+=1
 assert tw==tu+tv-tc;checks+=1
print('PASS',checks)
```
