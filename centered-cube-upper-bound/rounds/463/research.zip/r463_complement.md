# R463：共享来源交叉信用的有价比较

结论限于 R462 的正包络：交叉排斥与“父外 own-low 负载二阶矩”之间的差可用一次 \(O(S\zeta^{-1}W)\) 支付，且精确系数含 \(K^{-2}\)。未取得原完整余项的根阶预算。以下始终固定原 \(f\)、真实中心、匹配质量、边长选择器；不重新生成历史。

## 1. 来源先积分的准确补集

沿用 R462：\(K=e^{\sqrt n}\)、\(A_n=1+n\log(b/a)\)、\(c=(1+\epsilon_0)h\)，\(\beta_y^*=\rho_y|_{B_y}\) 在非 active 来源上置零，故其总量
\(\tau(y)\le c\)。对实际父 \(A\) 定义
\[
 V_A=\{u:u\notin Q_A,\ K^2m_u<m_A\},\quad
 l_A(y)=\beta_y^*(V_A),\quad d_A(y)=\tau(y)-l_A(y).
\]
删除量有不交分解
\[
 d_A(y)=\beta_y^*(\{u\in Q_A\})
       +\beta_y^*(\{u\notin Q_A,\ K^2m_u\ge m_A\}).          \tag{1}
\]
严格质量边界归入第二项，不漏原子。令
\[
 C_A^*(y,z)=\int_{V_A}c_u(z)\beta_y^*(du).
\]
它一般不对称，因为 own-low 标记依来源。原 R462 的
\(t_A^y(z)=l_A(z)-C_A^*(z,y)\)；所以双端包络在父 \(A\) 下的积分为
\[
 Q_A=\int\pi_A(dy)\pi_A(dz)
 [l_A(y)-C_A^*(y,z)][l_A(z)-C_A^*(z,y)].                    \tag{2}
\]
这保留两端 cross-avoid、父外及严格质量门。

点态地，(2) 的乘积等于
\[
 \tau(y)\tau(z)
 -[d_A(y)\tau(z)+d_A(z)\tau(y)-d_A(y)d_A(z)]
 -[l_A(y)C_A^*(z,y)+l_A(z)C_A^*(y,z)
                         -C_A^*(y,z)C_A^*(z,y)].           \tag{3}
\]
两个方括号均非负：分别是 eligibility 删除的并集费用及交叉捕获的并集费用。不能只保负交叉项而遗漏末尾正的共同捕获项，也没有对协方差预设符号。

## 2. 完整匹配使交叉信用很小

记 \(L_A=\int l_A(y)\pi_A(dy)\)。共享的完整 \(f\) 给出
\[
 \int C_A^*(y,z)\pi_A(dz)
 =\int_{V_A}\frac{f(Q_A\cap Q_u)}{m_A}\,\beta_y^*(du)
 \le K^{-2}l_A(y).                                         \tag{4}
\]
这里用的是 \(f(Q_A\cap Q_u)\le m_u<m_A/K^2\)，不是交叠体积或来源密度帽。

令 \(E_A=L_A^2-Q_A\)。交换 \(y,z\) 仅针对对称的基底 \(\pi_A^2\)，由 (3) 得
\[
 E_A=2\int\pi_A^2\,l_A(z)C_A^*(y,z)
                  -\int\pi_A^2 C_A^*(y,z)C_A^*(z,y),
\]
从而
\[
 \boxed{0\le E_A\le \frac{2cL_A}{K^2},\qquad
 L_A^2-\frac{2cL_A}{K^2}\le Q_A\le L_A^2.}                 \tag{5}
\]
左侧即使为负也合法。没有推断原接受权对称。

若保留任意原静态标记 \(0\le F(A,y,z)\le1\)，可定义
\(Q_{A,F}\) 为 (2) 加该标记、\(B_{A,F}=\int\pi_A^2F l_A(y)l_A(z)\)。
同样有
\[
 0\le B_{A,F}-Q_{A,F}\le 2cL_A/K^2.                         \tag{6}
\]
故原 high-rank/low-common 等来源门可以保留；但 \(F\) 不对称时不能把 \(B_{A,F}\) 写成 \(L_A^2\)。完整端点、阶段和路径接受系数未必只依 \(A,y,z\)，不能从 (6) 擅自得到原流等式。

## 3. 该比较的完整来源价格

用实际 \(\sigma=q_A\,dA\) 和 \(\pi_A=f c_A/m_A\)，Tonelli 给
\[
 \int\sigma(dA)L_A
 =\int f(y)\int \frac{c_A(y)l_A(y)}{R_A^n}\,dA\,dy
 \le cA_nW.                                                \tag{7}
\]
最后一步仅用真实中心径向包络。于是
\[
 0\le\int\sigma L_A^2-\int\sigma Q_A
 \le \frac{2c^2A_n}{K^2}W.                                 \tag{8}
\]
记 R462 包络价格
\[
 \mathcal Q=\frac{S}{\zeta h^2}\int\sigma Q_A,\qquad
 \mathcal B=\frac{S}{\zeta h^2}\int\sigma L_A^2.
\]
则
\[
 \boxed{0\le\mathcal B-\mathcal Q
 \le\frac{2S(1+\epsilon_0)^2A_n}{\zeta K^2}W.}               \tag{9}
\]
\(n\ge1\)、\(b/a\le2\) 时
\[
 A_n/K^2\le(1+\log2)n e^{-2\sqrt n}
 \le(1+\log2)e^{-2};
\]
因此误差确为维度一致的一次来源费。相同误差也适用于 (6) 积分。

(9) 是有价比较，不是支付 \(\mathcal B\) 或 \(\mathcal Q\)。当前仅知
\(\int\sigma L_A^2\le c^2A_nW\)。要由此得到完整目标，仍须把这个实际父外负载二阶矩降至
\(O(h^2\sqrt n\,\mathrm{polylog}(n+2)W)+O(\eta\zeta h^2X/S)\)，或直接利用未放掉的原接受权。交叉信用本身至多为 (9)，不能被当成足以消掉线性 \(A_nW\) 的免费负项。

只有 \(|\Xi_{\rm can}|\le\mathcal Q\)，不是等号。因此包络与二阶矩之间有价等价，并不使二阶矩成为原余项根阶估计的必要条件；原历史可能继续大幅减小需求。R458 母账及入口倍率照保。本轮没有新增原余项的根阶付款。

## 4. 有界本机核验

以下 Fraction 代码已实际运行，三组有限匹配入射/源权模型，共 69 项点态及积分断言通过。它核 (3)–(6) 的方向、非对称 own-low 标记、质量阈值等号和共同捕获项；不是实际连续中心、原 active/history 或全几何合同的实现。

~~~python
from fractions import Fraction as F
p=[F(1,10),F(2,10),F(3,10),F(4,10)]
caps=[{0},{1},{2},{3},{0,1},{1,2}]
mass=[sum(p[j] for j in U) for U in caps]
mu=[F(1,2),F(2,3),F(1,3),F(3,4),F(1,4),F(2,5)]
checks=0
for stage,K2 in enumerate([F(3,2),F(2),F(3)]):
    B=[[mu[u] if y in caps[u] and (y+u+stage)%3 else F(0)
        for u in range(len(caps))] for y in range(4)]
    eligible=[mass[u]*K2<1 and (u+stage)%4!=0 for u in range(len(caps))]
    tau=[sum(row) for row in B];c=max(tau)
    l=[sum(B[y][u] for u in range(len(caps)) if eligible[u]) for y in range(4)]
    d=[tau[y]-l[y] for y in range(4)]
    C=[[sum(B[y][u] for u in range(len(caps)) if eligible[u] and z in caps[u])
        for z in range(4)] for y in range(4)]
    for y in range(4):
        for z in range(4):
            prod=(l[y]-C[y][z])*(l[z]-C[z][y])
            delete=d[y]*tau[z]+d[z]*tau[y]-d[y]*d[z]
            cross=l[y]*C[z][y]+l[z]*C[y][z]-C[y][z]*C[z][y]
            assert prod==tau[y]*tau[z]-delete-cross and delete>=0 and cross>=0
            checks+=1
    L=sum(p[y]*l[y] for y in range(4))
    Q=sum(p[y]*p[z]*(l[y]-C[y][z])*(l[z]-C[z][y]) for y in range(4) for z in range(4))
    assert 0<=L*L-Q<=2*c*L/K2;checks+=1
    for y in range(4):
        assert sum(p[z]*C[y][z] for z in range(4))<=l[y]/K2
        checks+=1
    for mode in range(2):
        mark=lambda y,z: F(y<=z) if mode==0 else F((2*y+z)%3,2)
        base=sum(p[y]*p[z]*mark(y,z)*l[y]*l[z] for y in range(4) for z in range(4))
        value=sum(p[y]*p[z]*mark(y,z)*(l[y]-C[y][z])*(l[z]-C[z][y]) for y in range(4) for z in range(4))
        assert 0<=base-value<=2*c*L/K2;checks+=1
print("PASS",checks,"Fraction assertions; finite incidence only, no original-history claim")
~~~
