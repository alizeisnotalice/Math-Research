# R463 FINAL PASS（限定范围）

先独立 PRE，后核冻结作者稿。PASS 认证同一真实场的 relaxed 双端包络比较、统一差额常数、辅助首入测度及下列有限复现。**不认证完整父外二阶矩的根阶预算、不将包络变成原实际 \(P\) 的等式或必要条件；没有新增完整余项付款或跨 octave 免费求和。**

严格质量边界在 eligibility 的失败域中，质量原子未丢。固定父的 \(l_A\)、非对称 \(C_A^*\) 及双端乘积展开正确，末尾共同捕获项须加回。匹配给
\(\int C_A^*(y,z)\pi_A(dz)\le l_A(y)/K^2\)，故
\(0\le L_A^2-Q_A\le2cL_A/K^2\)。
来源/终端始终使用同一个 \(f\)、真实 \(m_u\) 与 \(\pi_A\)，没有以体积代替来源质量。任意非对称静态 \(F\in[0,1]\) 的加权比较也成立，但基项不因式分解；完整端点接受权不能据此免费延拓或消除。

Tonelli 与真实径向容量给 \(\int\sigma L_A\le cA_nW\)。保原系数后差额至多
\(2S(1+\varepsilon_0)^2A_nW/(\zeta K^2)\)。
在 \(n\ge1,\ b/a\le2,\ \varepsilon_0\le1/2\) 下，\(t^2e^{-2t}\) 对 \(t\ge1\) 非增，得到
\(C_0=(9/2)(1+\log2)e^{-2}<26/25\)。
因此统一差额 \(<26SW/(25\zeta)\) 正确，仍保 \(S/\zeta\) 及原入口参数；这是两个 relaxed 量之间一次有价比较，不是已支付它们的二阶矩主项。原 \(R_{433}\) 分拆和母槽保持。

geometry 的父内交集插值确实嵌套：对每个父内来源点，各线性约束在 \(t=1\) 可行，首入阈值公式分母为正。min/max 推前的完整有限测度恒等式成立，保零时已捕获质量；strict mass 给零原子占比 \(<2/K^2\)。附第三源 \(x\sim\pi_A\) 后总量仍为原 \(R\)，但 \(x\) 不继承旧来源历史。正上放列仍含 \(D(x)\)，局部去重不能消除此跨父重复；没有把虚拟插值或交集负项与主比较重复记费。

指定 Python 在隔离目录
`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r463_audit_uynmlgk8`
实际重放冻结 geometry/complement 两代码块及 numeric 脚本：分别 `PASS 57`、`PASS 69`、`PASS 106`。三 stdout 与 replay 逐字一致，numeric JSON 仅运行 seconds 不同。57 是三个连续来源固定 cube 场的有限几何断言，原 high-rank 失败；69 是有限入射代数；106 是六个明确 NON-NATIVE 容量矩阵、符号恒等式及 Arb192 常数证书。均不认证原完整 active/history 或一般维数价格。PRE 临时检查不计归档覆盖。没有修改作者文件/仓库，没有编译 PDF。

最终七输入 SHA256：

- `r463_main.md`: `3312bb3ee7734ff206bdbe1821d1d75bc75fc78049e596e248e0ebc1ce470ec5`
- `r463_geometry.md`: `04203c139317316c673f342a9b3936ed624c526b94351f79686ad9c0892b7a27`
- `r463_complement.md`: `e210c297003c5a4af768ca717981aa992239488b482a027dcba6f6d3ca488ab7`
- `r463_numeric.md`: `f449c4fe7662a321bf31fcca489ffaa3fd40c82ad9f21e4a5a85446680347868`
- `r463_numeric.py`: `56c22fecee4b00a10607f14418127473d24068a64e9cd6ee8d902f2eed4e0ca6`
- `r463_numeric.json`: `6482082789f4134c8d32d7456797a7094966ddead00dedac41b120d2fe0a8c52`
- `r463_replay.json`: `18656cbc2a73bee04148ad54152babba8691554b263bd8eb10cc7b975604127b`
