#!/usr/bin/env python3
"""R599 full exterior profile midpoint quadrature; NOT certified integration."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,hashlib,json,math,platform,resource,shlex,signal,sys,time
from fractions import Fraction
from pathlib import Path
import numpy as np
from flint import arb,ctx
REGRESSION=[{'model': 'product', 'tag': 'frozen_anchor_51/100_(1, 0)', 'x': ['251/100', '2'], 'H_exact': ['17321683/16729419', '-4402691/50188257']}, {'model': 'product', 'tag': 'frozen_anchor_51/100_(1, 1)', 'x': ['251/100', '251/100'], 'H_exact': ['5221/5928', '101/2223']}, {'model': 'product', 'tag': 'frozen_anchor_21/40_(1, 0)', 'x': ['101/40', '2'], 'H_exact': ['81138/72569', '-148543/653121']}, {'model': 'product', 'tag': 'frozen_anchor_21/40_(1, 1)', 'x': ['101/40', '101/40'], 'H_exact': ['736/1023', '328/3069']}, {'model': 'product', 'tag': 'frozen_anchor_11/20_(1, 0)', 'x': ['51/20', '2'], 'H_exact': ['36443/26979', '-13517/26979']}, {'model': 'product', 'tag': 'frozen_anchor_11/20_(1, 1)', 'x': ['51/20', '51/20'], 'H_exact': ['47/96', '7/36']}, {'model': 'product', 'tag': 'frozen_anchor_3/5_(1, 0)', 'x': ['13/5', '2'], 'H_exact': ['27479/11067', '-48268/33201']}, {'model': 'product', 'tag': 'frozen_anchor_3/5_(1, 1)', 'x': ['13/5', '13/5'], 'H_exact': ['7/51', '352/1071']}, {'model': 'product', 'tag': 'final_matched_probe', 'x': ['11/4', '149/100'], 'H_exact': ['11/9', '-7/24']}, {'model': 'diagonal', 'tag': 'frozen_anchor_51/100_(1, 0)', 'x': ['851/100', '8'], 'H_exact': ['478/579', '808/12159']}, {'model': 'diagonal', 'tag': 'frozen_anchor_51/100_(1, 1)', 'x': ['851/100', '851/100'], 'H_exact': ['5221/5928', '101/2223']}, {'model': 'diagonal', 'tag': 'frozen_anchor_21/40_(1, 0)', 'x': ['341/40', '8'], 'H_exact': ['436/723', '328/2169']}, {'model': 'diagonal', 'tag': 'frozen_anchor_21/40_(1, 1)', 'x': ['341/40', '341/40'], 'H_exact': ['736/1023', '328/3069']}, {'model': 'diagonal', 'tag': 'frozen_anchor_11/20_(1, 0)', 'x': ['171/20', '8'], 'H_exact': ['22/71', '56/213']}, {'model': 'diagonal', 'tag': 'frozen_anchor_11/20_(1, 1)', 'x': ['171/20', '171/20'], 'H_exact': ['47/96', '7/36']}, {'model': 'diagonal', 'tag': 'frozen_anchor_3/5_(1, 0)', 'x': ['43/5', '8'], 'H_exact': ['-13/141', '176/423']}, {'model': 'diagonal', 'tag': 'frozen_anchor_3/5_(1, 1)', 'x': ['43/5', '43/5'], 'H_exact': ['7/51', '352/1071']}, {'model': 'diagonal', 'tag': 'final_matched_probe', 'x': ['31/4', '186/25'], 'H_exact': ['764701/677151', '-60800/225717']}, {'model': 'diagonal', 'tag': 'superseded_risk_probe_not_final_match', 'x': ['31/4', '749/100'], 'H_exact': ['57920402/59049279', '-3333404/59049279']}]
def geometry(name):
 a=math.sqrt(2)-1
 if name=='product':
  z=np.array([(i,j) for i in range(3) for j in range(3)],dtype=float);rects=[[-.5,2.5,-.5,2.5]]
  # Eight disjoint outer strips, each a by a/2; exact endpoints use sqrt2.
  for k in (0,1):
   lo=k+1-math.sqrt(2)/2;hi=k+math.sqrt(2)/2
   rects.extend([[lo,hi,-math.sqrt(2)/2,-.5],[lo,hi,2.5,2+math.sqrt(2)/2],[-math.sqrt(2)/2,-.5,lo,hi],[2.5,2+math.sqrt(2)/2,lo,hi]])
  domain=(-6.,8.)
 else:
  z=np.array([(i,i) for i in range(9)],dtype=float);rects=[[i-.5,i+.5,i-.5,i+.5] for i in range(9)]
  for i in range(8):
   lo=i+1-math.sqrt(2)/2;hi=i+math.sqrt(2)/2;mid=i+.5
   rects.extend([[lo,mid,mid,hi],[mid,hi,lo,mid]])
  domain=(-6.,14.)
 return z,np.array(rects),domain

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args();start=time.perf_counter();ctx.prec=512
 def stop(*_):raise TimeoutError('60-second guard; no partial results called full integration')
 signal.signal(signal.SIGALRM,stop);signal.alarm(60)
 q=(21-8*math.sqrt(2))/9;kappa=1/q;qa=(arb(21)-8*arb(2).sqrt())/9
 assert qa>1 and qa<2 and 9*qa/(qa-1)<144
 def profile(x,z,B):
  radii=np.sort(2*np.max(np.abs(x[:,None,:]-z[None,:,:]),axis=2),axis=1)
  inside=np.any((x[:,0,None]>=B[:,0])&(x[:,0,None]<=B[:,1])&(x[:,1,None]>=B[:,2])&(x[:,1,None]<=B[:,3]),axis=1)
  H=np.zeros(len(x));Hs=np.zeros(len(x))
  for j in range(9):
   r=radii[:,j];r2=r*r;m=(radii<=r[:,None]).sum(axis=1);h=r/2
   wx=np.maximum(0,np.minimum(x[:,0,None]+h[:,None],B[:,1])-np.maximum(x[:,0,None]-h[:,None],B[:,0]))
   wy=np.maximum(0,np.minimum(x[:,1,None]+h[:,None],B[:,3])-np.maximum(x[:,1,None]-h[:,None],B[:,2]))
   I=(wx*wy).sum(axis=1);holes=np.maximum(0,r2-I);deficit=r2-m
   T=np.divide(q*deficit,holes,out=np.full_like(r,np.inf),where=holes>0)
   Ts=np.divide(q*deficit,r2,out=np.full_like(r,np.inf),where=r2>0)
   H=np.maximum(H,1-T);Hs=np.maximum(Hs,1-Ts)
  H[inside]=0;Hs[inside]=0
  return np.clip(H,0,1),np.clip(Hs,0,1)
 def integrate(name,N):
  z,B,(lo,hi)=geometry(name);step=(hi-lo)/N;h_sum=h2_sum=s_sum=0.;active=0
  for first in range(0,N*N,4096):
   ids=np.arange(first,min(first+4096,N*N));x=np.column_stack((lo+(ids%N+.5)*step,lo+(ids//N+.5)*step));H,Hs=profile(x,z,B)
   h_sum+=float(H.sum());h2_sum+=float((H*H).sum());s_sum+=float(Hs.sum());active+=int(np.count_nonzero(H))
  return {'N_per_axis':N,'sample_count':N*N,'domain':[lo,hi,lo,hi],'cell_area':step*step,'integral_H_midpoint':h_sum*step*step,'integral_H_squared_midpoint':h2_sum*step*step,'source_only_integral_H_midpoint':s_sum*step*step,'positive_H_center_count':active}
 # Phase1: initial complete spatial grid. No scale sampling at any center.
 initial={name:integrate(name,64) for name in ('product','diagonal')}
 # Phase2: compare float kernel to all 19 inherited exact/Arb event certificates.
 regression=[]
 for p in REGRESSION:
  z,B,_=geometry(p['model']);x=np.array([[float(Fraction(v)) for v in p['x']]]);H,_=profile(x,z,B)
  exact=float(Fraction(p['H_exact'][0]))+float(Fraction(p['H_exact'][1]))*math.sqrt(2);err=abs(float(H[0])-exact);assert err<2e-12
  regression.append({**p,'computed_H_float':float(H[0]),'absolute_difference_from_radical_float':err,'evidence':'Floating regression against inherited exact coefficients; tolerance is not an integral error bound.'})
 # Phase3: nested resolutions; all centers and all nine events evaluated.
 results={name:[initial[name]] for name in initial}
 for N in (128,256,512,1024,2048,4096):
  for name in results:
   row=integrate(name,N);prev=results[name][-1];row['change_in_integral_H_from_previous_grid']=row['integral_H_midpoint']-prev['integral_H_midpoint'];results[name].append(row)
  if time.perf_counter()-start>45:break
 proof='If H>0, some theta<1 gives m>(1-theta/q)r^2+(theta/q)I >=(1-1/q)r^2. Hence r^2<9q/(q-1)<144, so r<12; the cube must contain a source, and x is within 6 in each coordinate of some source. Product domain[-6,8]^2 and diagonal[-6,14]^2 therefore contain all support. Each entry ties all closed-cube labels; between entries the theta-deficit strictly decreases for theta<1. Thus all positive H comes from the nine entering events (duplicates harmless).'
 d={'scope':'Two frozen 9-source n2 models, complete E, full exterior positive-part H; no theta or radius grid. Spatial midpoint quadrature only.','q_exact':'(21-8*sqrt(2))/9','q_Arb512':qa.str(65),'kappa_exact':'9/(21-8*sqrt(2))','E_volume_exact':'21-8*sqrt(2)','E_structure':'Inherited R597 all511-subset verified disjoint representations: product9 rectangles, diagonal25 rectangles. Reconstructed analytically, no old file dependency.','provenance_R597_raw_sha256':'37ad3d25c0845dfb956a245b5cc5b263fa703d2b75b926abc18397d7774103d2','provenance_R598_minimal_input_sha256':'a70f09898b9ef6a664f662bef96d18257900e36559a85c4da20dfab1aece2e09','truncation_and_scale_proof':proof,'cutoff_r_squared_upper_Arb512':(9*qa/(qa-1)).str(65),'arithmetic':'NumPy float64 quadrature; Arb512 only scalar cutoff certification. Exact inherited radicals used for 19-point regression. No rigorous integral enclosure.','boundary_scope':'E and event boundaries zero Lebesgue measure; midpoint hits classified by closed bounds. No unbounded support omitted by analytic cutoff.','regression':regression,'results':results,'decision_limit':'Matched point contrast does not determine complete integrals. q<2; neither model certifies difficult near-extremal global lower bound. Grid changes are observations, not certified errors or upper/lower bounds.','execution':{'python':platform.python_version(),'numpy':np.__version__,'interpreter':sys.executable,'processes':1,'block_size':4096,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'command':shlex.join([sys.executable,*sys.argv]),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
 args.output.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n');print(json.dumps({'results':results,'execution':d['execution']}))
if __name__=='__main__':main()
