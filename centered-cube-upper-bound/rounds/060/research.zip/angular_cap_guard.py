#!/usr/bin/env python3
"""Heldout full-space angular/radial importance probes for genuine tensor atoms.
No receiver or time box cutoff. Exact dyadic cap decisions at machine receivers.
All densities are evaluated as a complete, analytically normalized mixture.
Decimal agreement is a numerical guard, not an outward-rounded certificate.
"""
from fractions import Fraction as F
from decimal import Decimal as D,localcontext
from pathlib import Path
from itertools import product
from bisect import bisect_left,bisect_right
import math,random,json,time,argparse
Q=math.exp(-1);C=1-Q

def geometry(n,m,x):
    assert n>0 and m>0 and m&(m-1)==0
    pairs=[v.as_integer_ratio() for v in x]
    bits=max((2*m).bit_length()-1,*(d.bit_length()-1 for a,d in pairs));R=1<<bits
    xs=[a<<(bits-(d.bit_length()-1)) for a,d in pairs]
    sites=[(2*j+1-m)*(R//(2*m)) for j in range(m)]
    events=sorted((abs(xi-y),i) for i,xi in enumerate(xs) for y in sites)
    counts=[0]*n;zeros=n;nonzero_product=1;prev=0;rows=[];k=0
    while k<len(events):
        r=events[k][0]
        while k<len(events) and events[k][0]==r:
            coord=events[k][1];old=counts[coord];counts[coord]=old+1
            if old:nonzero_product=nonzero_product//old*(old+1)
            else:zeros-=1
            k+=1
        count=nonzero_product if zeros==0 else 0
        if count>prev:rows.append((r,count-prev,count));prev=count
    assert prev==m**n and nonzero_product==m**n and zeros==0
    return rows,R,xs

def geometry_reference(n,m,x):
    assert n>0 and m>0 and m&(m-1)==0
    pairs=[v.as_integer_ratio() for v in x]
    bits=max((2*m).bit_length()-1,*(d.bit_length()-1 for a,d in pairs));R=1<<bits
    xs=[a<<(bits-(d.bit_length()-1)) for a,d in pairs]
    sites=[(2*j+1-m)*(R//(2*m)) for j in range(m)]
    events=sorted((abs(xi-y),i) for i,xi in enumerate(xs) for y in sites)
    counts=[0]*n;prev=0;rows=[];k=0
    while k<len(events):
        r=events[k][0]
        while k<len(events) and events[k][0]==r:
            counts[events[k][1]]+=1;k+=1
        count=math.prod(counts)
        if count>prev:rows.append((r,count-prev,count));prev=count
    assert prev==m**n
    return rows,R,xs


def cap_data(n,m,rows,R,H):
    N=m**n;Rp=R**n;vols=[];bestc=0;bestv=1
    if rows[0][0]==0:return False,(False,False),None,None
    for r,jump,count in rows:
        v=(2*r)**n;vols.append(v)
        if count*bestv>bestc*v:bestc,bestv=count,v
    num=bestc*Rp*H.denominator;den=N*bestv*H.numerator
    cap=num<=den
    bands=tuple(num*K>den for K in (2,16)) if cap else (False,False)
    return cap,bands,vols,(bestc,bestv)

def energy_float(n,N,rows):
    rmin=rows[0][0];events=[]
    for r,jump,count in rows:
        v=(r/rmin)**n
        events.extend(((v*Q,0,jump),(v,1,jump)))
    events.sort();enter=exit=0;i=0;terms=[]
    while i<len(events):
        left=events[i][0]
        while i<len(events) and events[i][0]==left:
            _,kind,jump=events[i]
            if kind:exit+=jump
            else:enter+=jump
            i+=1
        coef=(Q*enter-exit)/N
        right=events[i][0] if i<len(events) else math.inf
        ratio=left/right
        terms.append(.5*(coef/left)**2*(1-ratio)*(1+ratio))
    return math.fsum(terms)

def energy_decimal(n,N,rows,precision,gram=False):
    with localcontext() as ctx:
        ctx.prec=precision;q=(-D(1)).exp();c=1-q
        rmin=rows[0][0]
        data=[((D(r)/rmin)**n,D(jump)/N) for r,jump,count in rows]
        if gram:
            terms=[]
            for v,p in data:
                for w,z in data:
                    lo,hi=sorted((v,w));ratio=hi/lo
                    kernel=(2-q-q*ratio*ratio)/(2*hi*hi) if ratio<=1/q else -c*c/(2*q*hi*hi)
                    terms.append(p*z*kernel)
            return +sum(terms,D(0))
        events=[]
        for v,p in data:events.extend(((v*q,p*q),(v,-p)))
        events.sort();coef=D(0);ans=D(0);i=0
        while i<len(events):
            left=events[i][0]
            while i<len(events) and events[i][0]==left:coef+=events[i][1];i+=1
            ratio=left/events[i][0] if i<len(events) else D(0)
            ans+=(coef/left)**2*(1-ratio*ratio)/2
        return +ans

def alpha_value(label,n,decimal=False):
    if label in ('local_minus','local_plus'):
        if n==1:return D(1) if decimal else 1.
        z=(D(n-1).sqrt() if decimal else math.sqrt(n-1))
        return 1+(-1 if label=='local_minus' else 1)/z
    a=F(label)
    return D(a.numerator)/a.denominator if decimal else float(a)

def components(name,n,m,H):
    if name=='baseline59':spec=[('atom',None,None,F(1,2)),('cone','height','1',F(1,2))]
    elif name in ('angular_extreme','angular_fixed','angular_local'):
        labels={'angular_extreme':('1/2','1','2'),'angular_fixed':('4/5','1','5/4'),'angular_local':('local_minus','1','local_plus')}[name]
        spec=[('atom',None,None,F(1,4))]+[('cone','height',a,F(1,4)) for a in labels]
    elif name=='radial_uniform':spec=[('atom',None,None,F(1,4))]+[('cone',s,'1',F(1,4)) for s in ('height','grid1','grid2')]
    elif name=='radial_local':spec=[('atom',None,None,F(1,4)),('cone','height','1',F(1,4)),('cone','grid1','local_minus',F(1,8)),('cone','grid1','1',F(1,8)),('cone','grid1','local_plus',F(1,8)),('cone','grid2','1',F(1,8))]
    else:raise ValueError(name)
    assert sum(z[3] for z in spec)==1
    out=[]
    for index,(kind,scale,alpha,w) in enumerate(spec):
        loga=None if kind=='atom' else -math.log(float(H)) if scale=='height' else n*math.log1p(int(scale[-1])/m)
        out.append(dict(id=index,kind=kind,scale=scale,alpha_label=alpha,alpha=None if alpha is None else alpha_value(alpha,n),weight=str(w),weight_float=float(w),log_scale_volume=loga))
    return out

def positive_uniform(rng):
    U=rng.random()
    while U==0:U=rng.random()
    assert 0<U<1
    return U

def sample(n,m,H,comps,rng):
    draw=rng.random();cum=0.;selected=comps[-1]
    for comp in comps:
        cum+=comp['weight_float']
        if draw<cum:selected=comp;break
    U=positive_uniform(rng)
    if selected['kind']=='atom':
        logv=-n*math.log(m)-math.log(float(H))-math.log(U);center=[(2*rng.randrange(m)+1-m)/(2*m) for i in range(n)];alpha=1.;radial='atom_tail'
    else:
        inner=rng.getrandbits(1)==0
        logv=selected['log_scale_volume']+(math.log(U) if inner else -math.log(U));center=[0.]*n;alpha=selected['alpha'];radial='inner' if inner else 'tail'
    side=math.exp(logv/n);face=rng.randrange(n);x=[]
    for i in range(n):
        sign=1 if rng.getrandbits(1) else -1
        angular=1. if i==face else positive_uniform(rng)**(1/alpha)
        x.append(center[i]+side*.5*sign*angular)
    return tuple(x),selected['id'],radial

def logsumexp(values):
    vmax=max(values)
    if vmax==math.inf:return vmax
    if vmax==-math.inf:return vmax
    return vmax+math.log(math.fsum(math.exp(v-vmax) for v in values))

def evaluate(n,m,H,comps,x,guard=False):
    N=m**n;rows,R,xs=geometry(n,m,x);cap,bands,vols,pair=cap_data(n,m,rows,R,H)
    if pair is None:return dict(cap=False,scores=[0.]*8,machine_zero_angles=False,arrival_count=len(rows))
    rmin=rows[0][0];Rp=R**n;invs=[(rmin/r)**n for r,j,c in rows]
    supports=[v*N*H.numerator>=Rp*H.denominator for v in vols]
    atomcore=math.fsum((j/N)/N*v*v for (r,j,c),v,sup in zip(rows,invs,supports) if sup)
    logatom=math.log(atomcore) if atomcore else -math.inf
    logvmin=n*math.log(2*rmin/R);origin=max(abs(z) for z in xs)
    logv0=n*math.log(2*origin/R) if origin else -math.inf
    zero=any(z==0 for z in xs)
    T=-math.fsum(math.log(abs(z)/origin) for z in xs if z and abs(z)!=origin) if origin else math.inf
    logs=[]
    for comp in comps:
        if comp['kind']=='atom':logcore=logatom
        else:
            la=comp['log_scale_volume'];radial=math.log(float(H))+2*logvmin-math.log(2)+(-la if logv0<=la else la-2*logv0)
            a=comp['alpha'];angular=(n-1)*math.log(a)-(a-1)*T if not zero else math.inf if a<1 else -math.inf if a>1 else 0.
            logcore=radial+angular
        logs.append(math.log(comp['weight_float'])+logcore)
    logden=logsumexp(logs)
    scores=[0.]*8
    if cap:
        assert all(supports)
        ecore=energy_float(n,N,rows);tiecore=math.fsum((j/N)**2*v*v for (r,j,c),v in zip(rows,invs))
        E=math.exp(math.log(ecore)-logden);rawdiag=math.exp(logatom-logden);tief=math.exp(math.log(tiecore)-logden)
        bs=[math.exp(2*math.log(float(H))+2*logvmin-math.log(K)-logden) if flag else 0. for K,flag in zip((2,16),bands)]
        atomweight=comps[0]['weight_float'];assert E<=C*N/atomweight*(1+1e-10) and tief<=N/atomweight*(1+1e-10)
        scores=[E,C*rawdiag,E-C*rawdiag,*bs,tief,max(0.,tief-rawdiag),rawdiag]
    out=dict(cap=cap,scores=scores,machine_zero_angles=zero,arrival_count=len(rows))
    if guard:
        assert not zero
        a=energy_decimal(n,N,rows,120);b=energy_decimal(n,N,rows,180)
        with localcontext() as ctx:
            ctx.prec=180
            Hd=D(H.numerator)/H.denominator;vmin=(D(2*rmin)/R)**n;v0=(D(2*origin)/R)**n
            atomD=sum((D(j)/N**2*(D(rmin)/r)**(2*n) for (r,j,c),sup in zip(rows,supports) if sup),D(0))
            Td=-sum(((D(abs(z))/origin).ln() for z in xs if abs(z)!=origin),D(0));density=D(0);component_densities=[]
            for comp in comps:
                weight=F(comp['weight']);wd=D(weight.numerator)/weight.denominator
                if comp['kind']=='atom':coreD=atomD
                else:
                    scale=comp['scale'];ad=1/Hd if scale=='height' else (1+D(int(scale[-1]))/m)**n
                    radialD=Hd*vmin*vmin/(2*ad) if v0<=ad else Hd*vmin*vmin*ad/(2*v0*v0)
                    alphaD=alpha_value(comp['alpha_label'],n,True);fD=((n-1)*alphaD.ln()-(alphaD-1)*Td).exp()
                    coreD=radialD*fD
                density+=wd*coreD;component_densities.append(str(wd*coreD))
            floatden=math.exp(logden);derr=abs(D.from_float(floatden)-density)/density
            target=b/density if cap else D(0);Eerr=abs(D.from_float(scores[0])-target)/target if target else D(0)
            f=energy_float(n,N,rows);eerr=abs(D.from_float(f)-b)/b;perr=abs(a-b)/b
            bandD=[Hd**2*vmin**2/(K*density) if flag else D(0) for K,flag in zip((2,16),bands)]
            berr=[abs(D.from_float(z)-t)/t if t else D(0) for z,t in zip(scores[3:5],bandD)]
            physical=b/(Hd*vmin)**2;physicalbound=1+2*max(D(0),-(Hd*vmin).ln())
            if cap:assert physical<=physicalbound
            tieD=sum(((D(j)/N)**2*(D(rmin)/r)**(2*n) for r,j,c in rows),D(0))
            targettie=tieD/density if cap else D(0)
            tieerr=abs(D.from_float(scores[5])-targettie)/targettie if targettie else D(0)
        assert derr<D('2e-11') and Eerr<D('2e-11') and eerr<D('2e-11') and perr<D('1e-100') and max(berr)<D('2e-11') and tieerr<D('2e-11')
        out['guard']=dict(n=n,m=m,N=N,H=str(H),cap=cap,M_exact=str(F(pair[0]*Rp,N*pair[1])),receiver_exact=[str(F(v)) for v in x],energy_float_vs_decimal180_relative_error=str(eerr),decimal120_vs180_relative_error=str(perr),mixture_density_float_vs_decimal180_relative_error=str(derr),normalized_energy_float_vs_decimal180_relative_error=str(Eerr),normalized_energy_decimal180=str(target),normalized_band_decimal180=[str(z) for z in bandD],normalized_band_float_vs_decimal180_relative_errors=[str(z) for z in berr],weighted_component_density_cores_decimal180=component_densities,physical_energy_over_H_squared_decimal=str(physical),physical_point_bound_decimal=str(physicalbound) if cap else None,physical_point_bound_checked_on_G=cap,normalized_tie_fee_decimal180=str(targettie),normalized_tie_fee_float_vs_decimal180_relative_error=str(tieerr))
    return out

NAMES=('cap_energy','source_diagonal','signed_offdiagonal','cap_band_K2','cap_band_K16','tie_fee','strict_tie_cross_fee','raw_source_diagonal')
DESIGNS=('baseline59','angular_extreme','angular_fixed','angular_local','radial_uniform','radial_local')

def summarize(values,bound,signed=False):
    S=len(values);mean=math.fsum(values)/S;var=math.fsum((v-mean)**2 for v in values)/(S-1)
    radius=bound*math.sqrt(math.log(40)/(2*S))
    return dict(estimate=mean,sample_standard_error=math.sqrt(var/S),sample_variance=var,maximum_observed_score=max(values),minimum_observed_score=min(values),nonzero_count=sum(v!=0 for v in values),coefficient_of_variation=math.sqrt(var)/abs(mean) if mean else None,score_upper_bound=bound,formal_pointwise_95_Hoeffding_radius=None if signed else radius,formal_pointwise_95_Hoeffding_interval=None if signed else [max(0.,mean-radius),min(bound,mean+radius)])

def run_case(n,m,h,design,S,seeds,stage):
    H=F(h);N=m**n;comps=components(design,n,m,H);atomweight=comps[0]['weight_float'];values=[[] for j in NAMES];rows=[];extremes={k:[] for k in ('energy','band_K2','band_K16','tie_fee')}
    bounds=(C*N/atomweight,C/atomweight,C*N/atomweight,2*N/atomweight,16*N/atomweight,N/atomweight,N/atomweight,1/atomweight)
    for seed in seeds:
        rng=random.Random(seed);vals=[[] for j in NAMES];accept=zero=0;compstats={str(c['id']):dict(samples=0,accepted=0,energy_sum=0.) for c in comps};arrivalmax=0
        for t in range(S):
            x,component,radial=sample(n,m,H,comps,rng);out=evaluate(n,m,H,comps,x);accept+=out['cap'];zero+=out['machine_zero_angles'];arrivalmax=max(arrivalmax,out['arrival_count'])
            compstats[str(component)]['samples']+=1;compstats[str(component)]['accepted']+=out['cap'];compstats[str(component)]['energy_sum']+=out['scores'][0]
            for j,value in enumerate(out['scores']):vals[j].append(value);values[j].append(value)
            for metric,value in zip(extremes,(out['scores'][0],out['scores'][3],out['scores'][4],out['scores'][5])):
                top=extremes[metric]
                if len(top)<3 or value>top[-1]['score']:
                    top.append(dict(score=value,seed=seed,sample_index_zero_based=t,component=component,radial_branch=radial,cap=out['cap'],receiver_exact=[str(F(z)) for z in x],scores=out['scores']))
                    top.sort(key=lambda z:(z['score'],z['seed'],z['sample_index_zero_based']),reverse=True);del top[3:]
        rows.append(dict(seed=seed,samples=S,cap_accepted=accept,cap_acceptance=accept/S,machine_zero_angles=zero,arrival_count_max=arrivalmax,components=compstats,**{name:summarize(v,b,name=='signed_offdiagonal') for name,v,b in zip(NAMES,vals,bounds)}))
    return dict(n=n,m=m,N=N,H=str(H),design=design,stage=stage,samples=S*len(seeds),source_mass=1,components=comps,seed_rows=rows,cap_accepted=sum(r['cap_accepted'] for r in rows),cap_acceptance=sum(r['cap_accepted'] for r in rows)/(S*len(seeds)),machine_zero_angles=sum(r['machine_zero_angles'] for r in rows),extreme_receivers=extremes,**{name:summarize(v,b,name=='signed_offdiagonal') for name,v,b in zip(NAMES,values,bounds)})

def overlap_guards():
    rows=[]
    for d in (15,31,63,255,1023):
        for label in ('local_minus','1','local_plus'):
            with localcontext() as ctx:
                ctx.prec=100;alpha=alpha_value(label,d+1,True)
                second=(alpha**2/(2*alpha-1))**d;inverse=(1/(alpha*(2-alpha)))**d
            af=alpha_value(label,d+1);sf=(af**2/(2*af-1))**d;iv=(1/(af*(2-af)))**d
            with localcontext() as ctx:
                ctx.prec=100;e1=abs(D.from_float(sf)-second)/second;e2=abs(D.from_float(iv)-inverse)/inverse
            assert e1<D('5e-13') and e2<D('5e-13')
            rows.append(dict(d=d,alpha_label=label,alpha_decimal=str(alpha),E_uniform_f_squared_decimal=str(second),E_uniform_inverse_f_decimal=str(inverse),float_second_relative_error=str(e1),float_inverse_relative_error=str(e2)))
    d0_rows=[]
    for alpha in (F(1,2),F(4,5),F(1),F(5,4),F(2)):
        empty_product=math.prod([]);assert empty_product==1
        d0_rows.append(dict(n=1,d=0,alpha=str(alpha),angular_density_exact=empty_product,E_uniform_f_squared_exact=1,E_uniform_inverse_f_exact=1))
    return dict(d0_guards=d0_rows,rows=rows,d0='f_alpha=1 for every alpha>0; no free angular coordinates',endpoint_failures='alpha=.5 has infinite E_uniform f^2 for d>0; alpha=2 has infinite E_uniform 1/f for d>0',normalization='Each free factor integrates int_0^1 alpha*t^(alpha-1) dt=1; q_a radial pieces integrate1/2+1/2',status='Closed-form numeric arithmetic checks, not Monte Carlo or interval certificates')

def killed_tree_guard():
    rng=random.Random(606011)
    cases=[]
    for b,depth in [(2,3),(2,8),(2,12),(4,4),(4,6),(16,3),(256,2)]:
        size=b**depth
        for mode in ('spike','weights','nested'):
            if mode=='spike': leaves=[0]*size;leaves[rng.randrange(size)]=size
            elif mode=='weights': leaves=[rng.randrange(17) if rng.randrange(5) else rng.randrange(1000) for _ in range(size)]
            else: leaves=[1+(i.bit_count()+1)**4 for i in range(size)]
            mean=F(sum(leaves),size)
            levels=[[F(v)/mean for v in leaves]]
            while len(levels[-1])>1:
                prev=levels[-1];levels.append([sum(prev[i:i+b],F(0))/b for i in range(0,len(prev),b)])
            levels.reverse()
            for H in (F(1),F(2),F(4)):
                alive=[True];z=[F(1)];path_energy=[F(0)];energy=F(0);cross=F(0);positive=F(0)
                for k in range(1,depth+1):
                    val=levels[k];newalive=[alive[i//b] and v<=H for i,v in enumerate(val)]
                    nz=[v if a else F(0) for v,a in zip(val,newalive)]
                    energy+=sum(((v-z[i//b])**2 for i,v in enumerate(nz)),F(0))/len(nz)
                    for j,old in enumerate(z):
                        drift=old-sum(nz[j*b:(j+1)*b],F(0))/b
                        assert drift>=0
                        cross+=old*drift/len(z)
                    np=[path_energy[i//b]+(v-levels[k-1][i//b])**2 for i,v in enumerate(val)]
                    z,alive,path_energy=nz,newalive,np
                end=sum(z,F(0))/len(z);end2=sum((v*v for v in z),F(0))/len(z)
                good=sum((v for v,a in zip(path_energy,alive) if a),F(0))/len(z)
                assert energy==end2-1+2*cross
                assert good<=energy<=2*H-H*end-1
                cases.append(dict(branches=b,dimension=b.bit_length()-1,depth=depth,mode=mode,H=int(H),good_ratio=float(good/H),killed_ratio=float(energy/H),good_fraction=float(F(sum(alive),len(alive))),exact_identity=True))
    # Arbitrary adapted positive process, genuinely nonzero conditional drift.
    drift_cases=[]
    for depth in (2,4,8):
      for H in (F(1),F(3),F(10)):
        levels=[[F(rng.randrange(1,41),10) for _ in range(2**k)] for k in range(depth+1)]
        z0=levels[0][0] if levels[0][0]<=H else F(0)
        z=[z0];alive=[levels[0][0]<=H];path=[F(0)];energy=F(0);budget=F(0);cross=F(0)
        for k in range(1,depth+1):
          val=levels[k];na=[alive[i//2] and v<=H for i,v in enumerate(val)];nz=[v if a else F(0) for v,a in zip(val,na)]
          for j,old in enumerate(z):
            raw=(val[2*j]+val[2*j+1])/2-levels[k-1][j]
            if alive[j]:budget+=max(raw,F(0))/len(z)
            drift=old-(nz[2*j]+nz[2*j+1])/2
            cross+=old*drift/len(z)
          energy+=sum(((v-z[i//2])**2 for i,v in enumerate(nz)),F(0))/len(nz)
          path=[path[i//2]+(v-levels[k-1][i//2])**2 for i,v in enumerate(val)]
          z,alive=nz,na
        end2=sum((v*v for v in z),F(0))/len(z)
        good=sum((v for v,a in zip(path,alive) if a),F(0))/len(z)
        assert energy==end2-z0*z0+2*cross
        assert good<=energy<=2*H*(z0+budget)
        drift_cases.append(dict(depth=depth,H=int(H),budget=str(budget),good=str(good),energy=str(energy),bound=str(2*H*(z0+budget))))
    return dict(martingale_cases=cases,adapted_drift_cases=drift_cases,arithmetic='exact Fraction; floating only summary ratios',max_good_ratio=max(c['good_ratio'] for c in cases))

def sharp_killing_guard():
    rows=[]
    for m in (2,4,8,16,32,64,128):
        h=F(1,m);eps=F(1,m**5);a=eps/(1+eps*(m-1))
        p=lambda j:1-a*j
        poly=lambda j:-h*h*j*j+a*h*h*F(j**3-j,3)
        coef=((1-eps)*(poly(m-1)+h*h*p(m-1))-poly(m))/(m-(1-eps)*(m-1))
        q=lambda j:coef*j+poly(j)
        B=1-h+h/eps
        assert (1-eps)*(1-h)+eps*B==1 and B>1
        assert q(0)==0 and q(m)==(1-eps)*(q(m-1)+h*h*p(m-1))
        for j in range(1,m):
            assert q(j)==(q(j-1)+q(j+1))/2+h*h*p(j)
            assert p(j)==(p(j-1)+p(j+1))/2
        assert p(m)==(1-eps)*p(m-1)
        assert 0<m*q(1)<2
        rows.append(dict(m=m,epsilon=str(eps),large_jump=str(B),survival=str(p(1)),good_square=str(q(1)),ratio=str(m*q(1)),ratio_float=float(m*q(1)),recurrences_exact=True))
    return rows

def radial_overlap_guards():
    rows=[]
    for rho in (F(1),F(3,2),F(2),F(8),F(64),F(1024)):
        direct=1/(2*rho**2)+(rho/6-1/(6*rho**2))+rho/2
        reverse=rho/2+(rho/6-1/(6*rho**2))+1/(2*rho**2)
        formula=(2*rho+1/rho**2)/3
        assert direct==reverse==formula
        with localcontext() as ctx:
            ctx.prec=100;value=D(formula.numerator)/formula.denominator
            r=float(rho);vf=(2*r+1/r**2)/3;error=abs(D.from_float(vf)-value)/value
        assert error<D('1e-14')
        rows.append(dict(rho=str(rho),overlap_exact=str(formula),overlap_decimal=str(value),float_relative_error=str(error),forward_three_intervals_exact=[str(1/(2*rho**2)),str(rho/6-1/(6*rho**2)),str(rho/2)],reverse_same_overlap_exact=True))
    return dict(rows=rows,formula='int qa^2/qb = int qb^2/qa = (2rho+rho^-2)/3, rho=max(a,b)/min(a,b)',arithmetic='Exact Fraction piece integrals; Decimal100 and float cross-check.')


def validation():
    guards=[];reference_rows=[]
    for n in (2,4,16,64):
        for m in (2,4,16):
            rng=random.Random(60003000+n*100+m)
            probes=[('origin',(0.,)*n),('source_atom',((1-m)/(2*m),)*n),('open_tie',(1.,)+(.125,)*(n-1))]+[('random',tuple(rng.uniform(-1,1) for i in range(n))) for j in range(8)]
            for label,x in probes:
                fast=geometry(n,m,x);slow=geometry_reference(n,m,x);assert fast==slow
                reference_rows.append(dict(n=n,m=m,receiver_kind=label,entire_rows_R_xs_equal=True,arrival_count=len(fast[0])))
    # alpha1 density is exactly the round59 cone algebra at all actual receiver points.
    for n,m in ((2,4),(16,4),(32,16),(64,16)):
        rng=random.Random(60001000+n*100+m)
        H=F(4);comps=components('baseline59',n,m,H)
        for trial in range(3):
            x,comp,branch=sample(n,m,H,comps,rng);out=evaluate(n,m,H,comps,x,True);guards.append(out['guard'])
            rows,R,xs=geometry(n,m,x);rmin=rows[0][0];vp=(2*rmin/R)**n;origin=max(abs(z) for z in xs)
            atom=math.fsum(j/N**2*(rmin/r)**(2*n) for r,j,c in rows for N in [m**n])
            globalHcore=.5*(float(H)*vp)**2 if (2*origin/R)**n<=1/float(H) else .5*(rmin/origin)**(2*n)
            if out['cap']:
                direct=energy_float(n,m**n,rows)/(.5*(atom+globalHcore))
                assert abs(out['scores'][0]-direct)<2e-11*direct
    for design in DESIGNS:
        comps=components(design,64,16,F(4));rng=random.Random(60002000+DESIGNS.index(design));x,comp,branch=sample(64,16,F(4),comps,rng)
        guards.append(evaluate(64,16,F(4),comps,x,True)['guard'])
    small=[]
    for n,m in ((2,2),(2,4),(3,2)):
        x=tuple((i+1)/7 for i in range(n));r,R,xs=geometry(n,m,x);sites=[(2*j+1-m)*(R//(2*m)) for j in range(m)];hist={}
        for y in product(sites,repeat=n):
            dist=max(abs(xs[i]-y[i]) for i in range(n));hist[dist]=hist.get(dist,0)+1
        assert [(z,j) for z,j,c in r]==sorted(hist.items())
        a=energy_decimal(n,m**n,r,120);b=energy_decimal(n,m**n,r,120,True)
        with localcontext() as ctx:ctx.prec=120;error=abs(a-b)/a
        assert error<D('1e-105');small.append(dict(n=n,m=m,arrival_multiset_exact=True,event_vs_gram120_relative_error=str(error)))
    return dict(running_product_reference_guards=reference_rows,radial_overlap=radial_overlap_guards(),complete_density_energy_guards=guards,explicit_compression_Gram_guards=small,angular_overlap=overlap_guards(),outward_rounding=False)

def audit_outliers(cases):
    audited={};ranks={}
    for metric in ('energy','band_K2','band_K16','tie_fee'):
        candidates=[(r['score'],case,r) for case in cases for r in case['extreme_receivers'][metric]]
        candidates.sort(key=lambda z:(z[0],z[1]['n'],z[1]['m'],z[1]['H'],z[1]['design'],z[2]['seed'],z[2]['sample_index_zero_based']),reverse=True);rank=[]
        for score,case,rec in candidates[:3]:
            key=(case['n'],case['m'],case['H'],case['design'],rec['seed'],rec['sample_index_zero_based'])
            if key not in audited:
                x=tuple(float(F(v)) for v in rec['receiver_exact']);comps=components(case['design'],case['n'],case['m'],F(case['H']));out=evaluate(case['n'],case['m'],F(case['H']),comps,x,True)
                assert out['scores']==rec['scores'] and out['cap']==rec['cap']
                audited[key]=dict(case_key=list(key[:4]),seed=rec['seed'],sample_index_zero_based=rec['sample_index_zero_based'],component=rec['component'],numeric_guard=out['guard'])
            rank.append(dict(case_key=list(key[:4]),seed=rec['seed'],sample_index_zero_based=rec['sample_index_zero_based'],score=score))
        ranks[metric]=rank
    global_count=len(audited);heldout_maxima=[]
    for case in cases:
        if case['stage']!='heldout_fixed':continue
        for metric in ('energy','band_K2','band_K16','tie_fee'):
            rec=case['extreme_receivers'][metric][0]
            key=(case['n'],case['m'],case['H'],case['design'],rec['seed'],rec['sample_index_zero_based'])
            if key not in audited:
                x=tuple(float(F(v)) for v in rec['receiver_exact']);comps=components(case['design'],case['n'],case['m'],F(case['H']));out=evaluate(case['n'],case['m'],F(case['H']),comps,x,True)
                assert out['scores']==rec['scores'] and out['cap']==rec['cap']
                audited[key]=dict(case_key=list(key[:4]),seed=rec['seed'],sample_index_zero_based=rec['sample_index_zero_based'],component=rec['component'],numeric_guard=out['guard'])
            heldout_maxima.append(dict(metric=metric,case_key=list(key[:4]),seed=rec['seed'],sample_index_zero_based=rec['sample_index_zero_based'],score=rec['score']))
    return dict(global_top3_by_metric=ranks,global_distinct_receiver_count=global_count,heldout_case_maxima=heldout_maxima,distinct_receivers_audited=list(audited.values()),scope='All-case top3 coordinates saved; global top3 per metric and each heldout-case maximum per metric independently Decimal-audited.')

def pilot_plan():
    for n in (16,32,64):
        for m in (4,16):
            for H in (4,16):
                for j,design in enumerate(DESIGNS):
                    base=600100000+n*100000+m*1000+H*10+j
                    yield n,m,H,design,512,(base,base+100000000),'pilot_only'

def final_plan():
    specs=[(64,16,4,'radial_uniform',16384),(64,16,4,'radial_local',16384),(64,16,4,'baseline59',8192),(64,16,4,'angular_local',8192),(32,16,4,'radial_uniform',8192),(64,4,4,'radial_uniform',8192),(16,16,4,'radial_uniform',4096),(64,16,16,'radial_uniform',8192)]
    for n,m,H,design,S in specs:
        base=600700000+n*100000+m*1000+H*10+DESIGNS.index(design)
        yield n,m,H,design,S,(base,base+100000000),'heldout_fixed'


def atom_drift_guards():
    ans=[]
    for K in (2.,16.,math.exp(4),math.exp(16)):
        a=.25;b=a*K;p=1.;c=1-math.exp(-1)
        lo=math.floor(math.log(a))-2;hi=math.ceil(math.log(b))+2
        def budget(theta):
            return math.fsum(max(0.,min(b,math.exp(theta+k))-max(a,math.exp(theta+k-1)))/math.exp(theta+k) for k in range(lo,hi+1))
        approximations=[]
        target=c*math.log(K)
        for nodes in (64,512,4096):
            value=math.fsum(budget((j+.5)/nodes) for j in range(nodes))/nodes
            approximations.append(dict(nodes=nodes,value=value,absolute_error=abs(value-target)))
        precision_error=0.
        with localcontext() as ctx:
            ctx.prec=100;aa=D.from_float(a);bb=D.from_float(b)
            for theta in (.125,.5,.875):
                t=D.from_float(theta);terms=[]
                for k in range(lo,hi+1):
                    v=(t+k).exp();vprev=(t+k-1).exp()
                    terms.append(max(D(0),min(bb,v)-max(aa,vprev))/v)
                precision_error=max(precision_error,abs(budget(theta)-float(sum(terms,D(0)))))
        assert approximations[-1]['absolute_error']<1e-6 and precision_error<1e-12
        ans.append(dict(K=K,expected_phase_budget=target,cap_energy=c*(4-4/K),quadrature=approximations,decimal100_point_difference=precision_error))
    return ans

def _decimal_kappa(n, precision):
    with localcontext() as ctx:
        ctx.prec = precision
        dn = D(n)
        s = D(1) / (2 * dn)
        ep = s.exp()
        em = (-s).exp()
        x = ((ep - em) / 2) ** 2
        return dn * ((1 + x) * (1 + x).ln() - x * x.ln())

def replacement_guards():
    dimensions = (8, 16, 32, 64, 128, 256, 1024)
    geometry = []
    for sample_count, stage, base_seed in ((32, "pilot", 606000), (256, "expanded", 606100)):
        for n in dimensions:
            b = n ** (-1 / n)
            upper = n * b / 16
            if upper < 2:
                geometry.append({"stage": stage, "n": n, "status": "empty_scale_interval", "upper_L": upper})
                continue
            rng = random.Random(base_seed + n)
            scales = (2.0, math.sqrt(2 * upper), upper)
            minimum_lost = [1.0] * 3
            minimum_margin = [1.0] * 3
            draws = 0
            accepted = 0
            while accepted < sample_count:
                z = [(rng.random() - 0.5) * b for _ in range(n)]
                draws += 1
                if sum(abs(t) >= b / 4 for t in z) < n / 4:
                    continue
                accepted += 1
                for k, length in enumerate(scales):
                    half_inner = length / 2
                    half_outer = math.exp(1 / n) * length / 2
                    overlap = 1.0
                    for t in z:
                        coordinate_overlap = max(0.0, min(half_inner, t + half_outer) - max(-half_inner, t - half_outer))
                        overlap *= coordinate_overlap / length
                    lost = 1 - overlap
                    lower = 1 - math.exp(-0.75)
                    minimum_lost[k] = min(minimum_lost[k], lost)
                    minimum_margin[k] = min(minimum_margin[k], lost - lower)
                    if lost < lower - 1e-12:
                        raise AssertionError((stage, n, length, lost, lower))
            geometry.append({"stage": stage, "n": n, "accepted": accepted, "draws": draws,
                             "b": b, "scales": list(scales), "minimum_actual_lost_fraction": minimum_lost,
                             "minimum_margin_above_analytic_lower": minimum_margin})
    arithmetic = []
    for n in dimensions:
        x = math.sinh(1 / (2 * n)) ** 2
        kappa_float = n * ((1 + x) * math.log1p(x) - x * math.log(x))
        k80 = _decimal_kappa(n, 80)
        k140 = _decimal_kappa(n, 140)
        with localcontext() as ctx:
            ctx.prec = 160
            rel_80_140 = abs(k80 - k140) / abs(k140)
            rel_float_140 = abs(D.from_float(kappa_float) - k140) / abs(k140)
            bound = 3 * D(n + 2).ln() / D(n)
            if k140 > bound:
                raise AssertionError((n, str(k140), str(bound)))
        a = (math.sqrt(1 - math.exp(-1)) + math.sqrt(n * kappa_float)) ** 2
        arithmetic.append({"n": n, "kappa_float": kappa_float, "a_n_n": a,
                           "kappa_140": str(k140), "upper_bound_3log_nplus2_over_n": str(bound),
                           "relative_80_vs_140": str(rel_80_140), "relative_float_vs_140": str(rel_float_140)})
    active = [r for r in geometry if "accepted" in r]
    return {"scope": "Finite standard-library pseudorandom geometry and high-precision arithmetic; not outward-rounded or a proof.",
            "dimensions": list(dimensions), "geometry_rows": geometry, "arithmetic_rows": arithmetic,
            "geometry_accepted_vectors": sum(r["accepted"] for r in active),
            "geometry_intersection_checks": 3 * sum(r["accepted"] for r in active),
            "minimum_geometry_margin": min(min(r["minimum_margin_above_analytic_lower"]) for r in active),
            "maximum_relative_80_vs_140": str(max(D(r["relative_80_vs_140"]) for r in arithmetic)),
            "maximum_relative_float_vs_140": str(max(D(r["relative_float_vs_140"]) for r in arithmetic))}

def sources(name):
    if name == "spike":
        return [(F(0), F(1))]
    if name == "two":
        return [(F(-1, 2), F(1, 2)), (F(1, 2), F(1, 2))]
    if name == "unequal":
        return [(F(-3, 4), F(1, 8)), (F(0), F(1, 4)), (F(1, 2), F(5, 8))]
    if name.startswith("nested"):
        depth = int(name[6:])
        return sorted([(F(0), F(1, 2**depth))] +
                      [(sign * F(1, 2**j), F(1, 2**(j+1))) for j in range(1, depth+1) for sign in (-1, 1)])
    if name.startswith("lattice"):
        count = int(name[7:])
        return [(F(2*j+1-count, 2*count), F(1, count)) for j in range(count)]
    raise ValueError(name)

def _cap_bad_intervals(src, height):
    intervals = []
    for i in range(len(src)):
        mass = F(0)
        for j in range(i, len(src)):
            mass += src[j][1]
            left = src[j][0] - mass / (2 * height)
            right = src[i][0] + mass / (2 * height)
            if left < right:
                intervals.append((left, right))
    merged = []
    for left, right in sorted(intervals):
        if merged and left <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], right))
        else:
            merged.append((left, right))
    return merged

def _number(value):
    return {"exact": str(value), "float": float(value)}

def run_reverse_case(name, height, ratio, steps, initial=F(8), left=F(-2), right=F(2)):
    src = sources(name)
    height = F(height)
    total_mass = sum((p for _, p in src), F(0))
    positions = [y for y, _ in src]
    prefixes = [F(0)]
    for _, p in src:
        prefixes.append(prefixes[-1] + p)
    scales = [initial / ratio**k for k in range(steps + 1)]
    all_captured_initially = all(left - initial/2 <= y <= right + initial/2 and
                                 right - initial/2 <= y <= left + initial/2 for y in positions)
    if not all_captured_initially:
        raise AssertionError("Initial receiver interval does not capture the entire source everywhere")
    if total_mass / initial > height:
        raise AssertionError("Initial coarse value exceeds H; exact missing-past fee M0 is unavailable")
    bad = _cap_bad_intervals(src, height)
    boundaries = {left, right}
    for length in scales:
        for y in positions:
            for endpoint in (y-length/2, y+length/2):
                if left < endpoint < right:
                    boundaries.add(endpoint)
    for a, b in bad:
        for endpoint in (a, b):
            if left < endpoint < right:
                boundaries.add(endpoint)
    cuts = sorted(boundaries)
    cells = [(a, b, (a+b)/2) for a, b in zip(cuts, cuts[1:])]
    lengths = [b-a for a, b, _ in cells]
    good = [not any(a < x < b for a, b in bad) for _, _, x in cells]
    histories = [0] * len(cells)
    prev = [total_mass / initial] * len(cells)
    alive = [v <= height for v in prev]
    prev = [v if live else F(0) for v, live in zip(prev, alive)]
    initial_fee = sum((v * length for v, length in zip(prev, lengths)), F(0))
    drift = F(0)
    killed_energy = F(0)
    good_energy = F(0)
    step_rows = []
    for step, length in enumerate(scales[1:], 1):
        group_integrals = {}
        transition_ids = {}
        new_histories = []
        new_values = []
        for cell_index, ((_, _, midpoint), cell_length) in enumerate(zip(cells, lengths)):
            lo = bisect_left(positions, midpoint-length/2)
            hi = bisect_right(positions, midpoint+length/2)
            captured = prefixes[hi] - prefixes[lo]
            raw = captured / length
            alive[cell_index] = alive[cell_index] and raw <= height
            value = raw if alive[cell_index] else F(0)
            history = histories[cell_index]
            # Integral over the entire previous-history class of E[Znew|history]-Zprev.
            group_integrals[history] = group_integrals.get(history, F(0)) + (value-prev[cell_index])*cell_length
            transition = (history, captured)
            if transition not in transition_ids:
                transition_ids[transition] = len(transition_ids)
            new_histories.append(transition_ids[transition])
            new_values.append(value)
            increment_energy = (value-prev[cell_index])**2 * cell_length
            killed_energy += increment_energy
            if good[cell_index]:
                if raw != value:
                    raise AssertionError("True good receiver was killed")
                good_energy += increment_energy
        step_drift = sum((max(v, F(0)) for v in group_integrals.values()), F(0))
        drift += step_drift
        step_rows.append({"step": step, "positive_drift_over_W": _number(step_drift/total_mass),
                          "parent_history_classes": len(group_integrals), "new_history_classes": len(transition_ids)})
        histories, prev = new_histories, new_values
    budget = 2 * height * (initial_fee + drift)
    if killed_energy > budget or good_energy > budget:
        raise AssertionError("Finite adapted-process energy budget failed")
    final_length = scales[-1]
    final_intervals = [(y-final_length/2, y+final_length/2) for y in positions]
    contained = all(left <= a <= b <= right for a, b in final_intervals)
    disjoint = all(final_intervals[i][1] <= final_intervals[i+1][0] for i in range(len(src)-1))
    half_rows = []
    for (y, mass), (a, b) in zip(src, final_intervals):
        left_labels = sorted({histories[j] for j, (ca, cb, _) in enumerate(cells) if max(ca, a) < min(cb, y)})
        right_labels = sorted({histories[j] for j, (ca, cb, _) in enumerate(cells) if max(ca, y) < min(cb, b)})
        half_rows.append({"source_position": str(y), "source_mass": str(mass),
                          "current_capture_interval": [str(a), str(b)],
                          "left_half_complete_history_labels": left_labels,
                          "right_half_complete_history_labels": right_labels,
                          "left_half_constant": len(left_labels) == 1,
                          "right_half_constant": len(right_labels) == 1})
    half_constant = all(row["left_half_constant"] and row["right_half_constant"] for row in half_rows)
    tail_certified = contained and disjoint and half_constant
    tail_certificate = {"passed": tail_certified, "final_L": str(final_length),
                        "scope": "Specified rational ratio and one fixed logarithmic scale phase on Q; no phase average or exact e-step identity.",
                        "capture_intervals_inside_Q": contained,
                        "capture_intervals_pairwise_disjoint": disjoint,
                        "complete_history_constant_on_each_half": half_constant,
                        "halves": half_rows,
                        "future_positive_killed_drift_zero": tail_certified}
    if tail_certified:
        tail_certificate["full_biinfinite_canonical_positive_drift_over_W"] = _number((initial_fee+drift)/total_mass)
    return {"source": name, "source_atoms": len(src), "source_definition": [[str(y), str(p)] for y, p in src],
            "H": str(height), "ratio": str(ratio), "steps": steps, "initial_L": str(initial),
            "receiver_Q": [str(left), str(right)], "cells": len(cells),
            "all_past_coarser_scales_capture_all_source": all_captured_initially,
            "true_cap_bad_union": [[str(a), str(b)] for a, b in bad],
            "initial_coarse_mass_over_W": _number(initial_fee/total_mass),
            "B_over_W": _number(drift/total_mass),
            "M0_plus_B_over_W": _number((initial_fee+drift)/total_mass),
            "good_energy_over_HW": _number(good_energy/(height*total_mass)),
            "killed_energy_over_HW": _number(killed_energy/(height*total_mass)),
            "budget_over_HW": _number(budget/(height*total_mass)),
            "exact_budget_margin_over_HW": _number((budget-killed_energy)/(height*total_mass)),
            "step_rows": step_rows, "tail_certificate": tail_certificate}

def reverse_drift_probes(pilot=False):
    names = ("spike", "two", "unequal", "nested4", "lattice8") if pilot else (
        "spike", "two", "unequal", "nested4", "nested8", "lattice8", "lattice32")
    ratios = (("2", F(2)), ("rational_e", F(2718281828459045, 10**15)))
    heights = (4,) if pilot else (4, 16)
    step_counts = (12,) if pilot else (12, 24)
    results = []
    for name in names:
        for height in heights:
            for label, ratio in ratios:
                for steps in step_counts:
                    row = run_reverse_case(name, height, ratio, steps)
                    row["ratio_label"] = label
                    results.append(row)
    return {"scope": "Exact Fraction finite-window 1D energy and, when certified, full one-phase canonical reverse drift for real atomic sources and true centered-interval cap; no general source or dimensional theorem.",
            "energy_definition": "Sum over discrete reverse steps of squared killed-average increments, Lebesgue-integrated on Q; good energy restricted to true {Mmu<=H}.",
            "history_definition": "Entire past captured-mass history, including time zero; conditional expectations use exact cell lengths.",
            "past_coarse_fee": "All larger scales capture all source throughout Q. The missing infinite coarse past adds exactly M0 to positive drift.",
            "tail_certificate_proof": "Final disjoint atom intervals inside Q have constant full-history labels on each left/right half. Shrinking retains exactly 1/r of each half, and equal positive-mass history labels have equal atomic mass and average. Thus conditional drift is zero before killing, nonpositive after permanent killing; exited zero-mass paths stay zero. Induct over future steps. The infinite all-captured coarse past adds exactly M0, with the asserted initial value at most H. This certifies the specified rational ratio, one fixed logarithmic phase and receiver Q only; no phase average, exact e-step identity, or general source/dimension claim.",
            "pilot": pilot, "cases": results, "case_count": len(results),
            "max_B_over_W": max(row["B_over_W"]["float"] for row in results),
            "max_M0_plus_B_over_W": max(row["M0_plus_B_over_W"]["float"] for row in results),
            "max_good_energy_over_HW": max(row["good_energy_over_HW"]["float"] for row in results),
            "all_exact_budgets_passed": True,
            "tail_certificate_pass_count": sum(row["tail_certificate"]["passed"] for row in results)}

def reverse_drift_pressure():
    """Fixed-source/height pressures; one rational-ratio phase on Q only."""
    configs = [("nested8", 2**8, 28), ("nested16", 2**16, 44),
               ("nested32", 2**32, 76), ("nested16", 4, 28), ("nested32", 4, 44)]
    rows = []
    for name, height, steps in configs:
        row = run_reverse_case(name, height, F(2), steps)
        row["ratio_label"] = "2"
        rows.append(row)
    return rows

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');args=parser.parse_args();start=time.monotonic();guards=validation();print('validation PASS',flush=True)
    cases=[]
    cfgs=list(pilot_plan())+(list(final_plan()) if not args.pilot else [])
    for cfg in cfgs:
        case=run_case(*cfg);cases.append(case);print(case['n'],case['m'],case['H'],case['design'],case['samples'],'E',round(case['cap_energy']['estimate'],7),'SE',round(case['cap_energy']['sample_standard_error'],7),'accept',case['cap_accepted'],flush=True)
    audit=audit_outliers(cases)
    killed=killed_tree_guard();sharp=sharp_killing_guard();print('tree guards PASS',flush=True)
    data=dict(reverse_drift_pressure=reverse_drift_pressure(),reverse_drift_probes=reverse_drift_probes(pilot=False),replacement_guards=replacement_guards(),atom_phase_drift_guards=atom_drift_guards(),killed_tree_guards=killed,sharp_killing_guards=sharp,pilot_selection='Six fixed proposals on72 pilot cases (2x512 each); retained both radial mixtures for unresolved n64m16H4 and independent baseline/angular comparators. Heldout seeds have disjoint namespace; no fitted density.',schema='round060_angular_fullspace_v1',pilot=args.pilot,normalization='E_G/(H W), W=1',proposal_formulas=dict(angular='theta=x/||x||infty, face/sign uniform; free abs(theta)=U^(1/alpha), f_alpha=alpha^(n-1)*product abs(theta)^(alpha-1)',radial='q_a=1/(2a) on volume v<=a, a/(2v^2) outside; half uniform radial volume, half Pareto tail; integral=1',scales='height a=1/H; gridk a=(1+k/m)^n, loga=n*log1p(k/m)',atomic='q_atom=sum DeltaC/(N^2 H vi^2) 1{vi>=1/(NH)}; source labels sampled by independent uniform coordinate indices',complete_mixture='Known rational component weights, full densities summed with log-sum-exp at every receiver.',score_bound='q>=w_atom q_atom gives energy<=cN/w_atom, band<=NK/w_atom, tied batch fee<=N/w_atom.',sampling_endpoint='random U=0 redrawn; U<1 always; angular free U positive; machine exact-zero angle events recorded separately.'),evidence_limits=['True finite positive Cartesian sources, full Lebesgue receiver space, exact grouped arrivals and cap at dyadic machine coordinates.', 'Proposal root/coordinate generation, log density and energy are floating approximations; Decimal120/180 audits are not interval certificates.', 'Sample SE is an empirical diagnostic, not a guarantee against unsampled large scores; formal pointwise Hoeffding radii use mathematical bounds and are usually useless.', 'Pilot seeds and heldout seeds disjoint; pilot selection disclosed; comparisons use independent streams, not paired covariance.', 'No exponent fitting, general uniform theorem, or discrete-to-continuous transfer claim.', 'Exact finite martingale/drift/chain guards are separate tree-model arithmetic; actual centered-cube transfer is unproved.', 'Single-atom finite-band phase drift uses deterministic midpoint refinements and Decimal point checks, not a fullspace cap bound.', 'Reverse-drift probes integrate discrete rational steps on receiver Q in one fixed phase; tail certificates cover only that source/ratio/phase/Q, not continuous e-step energy or a general theorem.'],validation=guards,outlier_audit=audit,cases=cases,counts=dict(cases=len(cases),seed_rows=sum(len(c['seed_rows']) for c in cases),principal_receivers=sum(c['samples'] for c in cases),global_extreme_receivers_audited=audit['global_distinct_receiver_count'],extreme_receivers_audited=len(audit['distinct_receivers_audited']),pilot_receivers=sum(c['samples'] for c in cases if c['stage']=='pilot_only'),heldout_receivers=sum(c['samples'] for c in cases if c['stage']=='heldout_fixed'),running_product_reference_guards=len(guards['running_product_reference_guards']),martingale_tree_guards=len(killed['martingale_cases']),adapted_drift_guards=len(killed['adapted_drift_cases']),sharp_killing_guards=len(sharp),atom_phase_drift_guards=4,replacement_geometry_checks=3456,replacement_kappa_guards=7,reverse_drift_guards=56,reverse_drift_pressure_guards=5))
    Path(__file__).with_name('results.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n');print('PASS',data['counts'],'runtime_seconds',round(time.monotonic()-start,3),flush=True)
if __name__=='__main__':main()
