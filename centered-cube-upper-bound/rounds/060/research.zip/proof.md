# 第60轮：杀死过程的尖锐平方预算、反向自然滤过与带符号替换

2026-10-11。本轮没有证明一般中心立方体弱型常数的 sqrt(n)n^{o(1)} 上界；全一般 O(n log n) 基准保留。研究对象、原好集合、来源质量及时间尺度均不更改。以下工具与数值证据不代表主定理闭合。

## 1. 真正获得的一般停止工具

设 f_k 是任意非负可积鞅或超鞅，观察空间采用实际基准测度，H>0。令 I_k=1{f_0,…,f_k≤H}，Z_k=f_k I_k，M_k=∫Z_k。在最终好集合上，Z 与 f 的所有增量相等。Z 是有界非负超鞅。写 d_k=Z_(k−1)−E[Z_k|F_(k−1)]，则 d_k≥0、∫d_k=M_(k−1)−M_k，且

    ∫Σ(ΔZ_k)² = ∫Z_K²−∫Z_0²+2Σ∫Z_(k−1)d_k
               ≤ 2H M_0−H M_K−∫Z_0²。

因此最终好集合上的原平方增量总量≤2H∫f_0。常数不依赖分支数、深度或越阈跳跃大小。不把终点越阈值当成有界值；真正使用的是归零后的 Z。这比“把首个坏立方体换成其平均密度”所得的 2^n 高度费用强，后者不是平方预算的必然障碍。

常数2在一般正鞅类中尖锐。取状态 j/m、0≤j≤m，内部作对称随机游走；在1处，以1−ε走到1−1/m，以ε跳到 B=1−1/m+1/(mε)>1，ε=m^(−5)。0和B吸收，过程保持非负鞅。最终好事件为吸收到0。精确生存概率和带好事件的平方奖励满足有限差分方程，解给从1/m出发的归一化好能量趋于2；误差与 2−1/m 之差≤6m^(−4)。这不是立方体来源的尖锐性结论。

对任意非负适应过程，正条件漂移必须保留。令 b_k=(E[Z_k|F_(k−1)]−Z_(k−1))_+，则同一代数给

    ∫好集合 Σ(Δf_k)² ≤ 2H(M_0+Σ∫b_k)−H M_K−∫Z_0²。

可用尚未杀死的原漂移正部作为更大上界，但本轮优先保留实际 b_k，避免对马上被杀死的增量收费。有限窗口推导后才取极限；没有调用未经证明的连续时间停止定理。

## 2. 对实际中心立方体的合法过程定义

对有限测度接收集 Q，在 [0,1)×Q 上使用 dθ dx，定义

    f_k(θ,x)=A_exp((θ+εk)/n) μ(x)， ε=±1，
    F_k=σ(θ,f_j:j≤k)。

这是实际尺度历史的自然滤过，条件期望在有限基准测度上存在。完整过去的生存指示 I_k=1{所有j≤k有f_j≤H} 即使没有最早的坏整数也有定义。把整数增量对 θ 积分，精确恢复 u=n log L 的完整相邻体积平方能量。一般方向给 E_H(Q)≤2H(W+B_Z^ε(Q))；缩小尺度方向在固定 Q 上的初始质量趋零，进一步有 E_H(Q)≤2H B_Z^−(Q)。先固定 Q 取时间极限，再让 Q 扩大，不混用全空间质量守恒。

自然历史的正条件漂移不大于同一路径的任何扩大滤过所产生的对应漂移，证明是条件 Jensen 加塔式性质。这只比较同一时间方向，不比较正反方向。

不限制阈值带的一致 B_Z^− 预算已被下述标记源反例否定。本轮随后考察的一个条件性充分目标是在真实接收带 {h/K<Mμ≤h} 上，对至少一个方向给出 B≤b_n W。若对所有源、h、有限Q一致成立，则带求和给 E_H≤2(1+b_n)HW/(1−K^(−1))。这一条件蕴含本身正确，但其完整自然历史前提已被第10节的带内标记多数源否定，不能继续列为待证关键引理。

## 3. 在试图使用强漂移收费前发现的反例

单原子 μ=pδ_0，设 a=p/H、v=(2||x||∞)^n、Q_V={v≤V}。尺度增大方向的自然历史杀死漂移精确为

    B_Z^+(Q_V)=(1−e^(−1))p log(V/a)+p(1−2e^(−1))， V≥a。

它随接收范围发散，而实际完整 cap 能量只有 (1−e^(−1))Hp。因此不能要求这种未限制接收范围的正向费用统一有界。

时间方向不能忽略。尺度缩小时，单原子当前方体中的均匀接收者在下一层存活的体积分数为 e^(−1)，其高度恰乘 e，给真正的源中心嵌套方体鞅。有限 Q_V 上的自然历史漂移≤p，V≥ea时等于p。一般来源的多个源中心滤过尚不能免费合成共同滤过。

在单原子的真实带 a≤v<p/λ 上，正向漂移恰为 (1−e^(−1))p log(H/λ)。固定比值的带消除了上述空间无穷远障碍；它并未消除任意共同来源的复杂度。已有多数函数的全尺度变分反例仍须保留，不能因单原子测试通过而假定带漂移一致。

## 4. 高度 nH 的逐原子有符号替换已可支付

保留第57轮全一般L2结果：κ_n=n[(1+x)log(1+x)−xlogx]，x=sinh²(1/(2n))，且 κ_n≤3log(n+2)/n。令 μ=Σp_iδ_(y_i)，G={Mμ≤H}，任取 f_i≥0、∫f_i=p_i、f_i≤βH。由原 cap 的单原子能量≤cHp_i（c=1−e^(−1)）、完整L2谱界和三角不等式，

    ||D_(p_iδyi)−D_fi||²_(L2(G×R)) ≤ (√c+√(κ_nβ))² Hp_i。

β=n 时为 O(log(n+2))Hp_i，且无需强迫位移很小。但是把这些替换相加仍有两个独立缺口：总密度的重叠次数，以及真实误差 Gram 矩阵 C 的 1^T C1。已知 tr C 的同阶预算不能控制这个二次型；归一化矩阵 H^(−1)P^(−1/2)CP^(−1/2) 的相关 Rayleigh 商仍未支付。

对任意真实正输运耦合，可严格写出绝对行列费用；常数、位移和到原好集合距离均显式保留。该机制过强：将单原子铺成高度 nH 的最小方体，实际有符号平方误差为 O(log n)Hp，而唯一耦合的绝对时空列费用已有 Ω(n log n)。完整证明用真实方体交集和至少 n/4 个大位移坐标，不把大绝对费用误当成大平方能量。

密度来源的完整时间 Gram 核未必在来源对上绝对可积；先截断时间作合法 Fubini，再用L2极限和极化恢复交叉项。不能跳过这一步。

## 5. 针对第59轮稀有事件的数值设计

保留实际张量原子来源、完整空间、完整时间事件积分和精确分组的 cap 判定。新增的只是假设已知密度的采样分布：源原子尾分布，与原点方体锥面的多个径向和角向分量混合。每个接收点计算整个混合密度，不能只除以被抽中的分量。

径向体积密度为 r_a(v)=1/(2a)（v≤a）及 a/(2v²)（v>a），分别用 aU 与 a/U 抽取；使用 a=1/H、(1+1/m)^n、(1+2/m)^n。角向每个自由坐标的绝对值为 U^(1/α)，相对均匀锥面密度为 α^(n−1)∏|θ_j|^(α−1)。解析归一化、重叠矩和保留原子分量所得的有限分数上界均已证明。

固定α偏离1会带来随维数指数变坏的分布重叠，α=1/2或2还有单向二阶重叠发散。采用 α=1±1/√(n−1) 的局部倾斜能保留有界渐近重叠，但这不是目标积分方差界。先独立pilot，再冻结计划用另一组种子作heldout；没有按较低均值挑选答案。最终数值范围和实际输出汇总如下文及 results.json。

## 6. 技能、证据边界和后续缺口

本轮使用当前64项技能中的 E04、I02 对停止和自然滤过作条件核验，L01/L03 区分真实来源、精确有理运算与浮点证据，并保留 N04 的实际质量及误差预算要求；读取F04时不将半群名称当成立方体迁移定理。64项顶层SKILL相对第55轮清单逐项SHA一致，437处直接本地引用存在，包级审计账本路径可用；未声称全文重读所有关联论文。

剩余的实质接口是总替换密度高度与真实混合误差的共同预算，或另一种保留符号抵消并支付来源混合的平方预算。无带及固定比值带内的完整自然历史正漂移费用均已被本轮反例排除，不能继续作为待证强引理。新的接口必须覆盖任意来源，常数不依赖原子数、权重、尺度深度或空间截断；取得后仍需严格完成越阈和全尺度回代。本轮不宣布核心目标完成。


## 7. 真正的相位平均反向漂移反例

这不是由有限维数据拟合出的结论。固定一维正源

    μ=(1/2)δ_(1/2)+1_[-1/10,1/10]dx， W=7/10， Q=[−2,2]。

在真实 e 步长的反向尺度中，取 θ∈[0,log(11/10)]，f_k=A_exp(θ−k)μ。对 x=1/2+t、p/H≤t≤1/20，粗尺度 f_0 的严格单调标记值唯一确定 x；因此后续过程在自然历史条件下已经可预测。所有这些接收点都属于真实全尺度 G_H。第1步以后标记质量退出，只留下重原子。在最后仍捕获重原子的尺度之前，各步增长确定，累积正漂移至少 p/(2et)−pe。因此

    B_Z^−(Q) ≥ log(11/10) [(1/(4e))log(H/10)−e/40]， H>10。

右端随 H 发散，源、维数、空间截断和总质量全部固定。故反向自然历史的无阈值带统一正漂移界也不成立。它不否定真实 cap 平方能量或目标弱型界，而是说明 H×累计正漂移会过度收费。

这一障碍也存在于真正 L1 输入，无须诉诸条件期望在原子逼近下连续。以 ε=1/(8H) 把重原子替换成 (p/(2ε))1_[b−ε,b+ε]，保留连续标记，W仍为7/10。单看 f_0 会有一个“完整标记+部分重质量”的重复分支，不能声称唯一辨认。加入 f_1 后，重复分支只捕获至多1/5的标记质量，而目标分支捕获完整1/2重质量，因而 (θ,f_0,f_1) 唯一确定目标接收点。后续确定增长给

    B_Z^−(Q) ≥ log(11/10) [(1/(5e))log(H/10)−e/40]， H≥20。

这是固定质量的一族 L1 反例；输入依赖H，足以否定对输入、阈值同时一致的预算。完整分支核对、可测逆映射、杀死状态和有限窗口到全相位的证明见英文笔记。有限原子单相位压力测试与这一解析反例严格区分，不把有理近似e当成e。

## 8. 实际数值范围、复现与验证

Round60 numerical pressure uses the same actual capped step energy as Round59, normalized by HW with W=1. Fullspace radial mixtures substantially reduce the observed uncertainty for n=64,m=16,H=4. Two independent heldout mixtures give 1.85152 ± 0.09512 and 1.85935 ± 0.07984 (estimate ± empirical sample SE). Their agreement is useful numerical evidence; the lower angular-only comparator shows that rare-tail uncertainty remains unresolved.

The source is the true Cartesian midpoint grid with m^n equal positive masses and coordinate sites (2j+1−m)/(2m). Source arrivals are compressed by products of coordinate counts at at most mn distances. The actual cap uses equal-distance batches and exact rational arithmetic at the generated dyadic receiver coordinates. Energy integrates every scale interval and its terminal tail. No receiver box or scale cutoff is used. Density/diagonal contributions retain multiplicity ΔC/N²; energy and the tie fee use grouped mass ΔC/N. The running-product implementation matches the original slow product reference on 132 complete receiver geometries, including atoms, zero distances and open-region ties.

Every proposal density is normalized analytically. Origin cone volume v=(2||x||∞)^n has radial density q_a(v)=1/(2a) for v≤a and a/(2v²) outside; the two parts integrate to 1/2 each. Angular face and sign are uniform, and each free absolute coordinate has density αt^(α−1), whose integral is one. Its relative cone density is α^(n−1)∏|θ_j|^(α−1). Components use a=1/H and a=(1+k/m)^n, k=1,2; local angular tilts use α=1±1/√(n−1). Complete densities include every component and are summed with stable logarithms. An atom-proposal component of weight at least 1/4 preserves the mathematical bound score≤(1−e^−1)N/w_atom for energy. U=0 is redrawn; no machine-zero angular events occurred in the stored run.

Six fixed proposal families were compared on 72 pilot cases, each with two seeds and 512 receivers. The pilot selected radial mixtures and comparator budgets; the heldout namespaces are disjoint and no density was fitted. The final experiment has 80 cases, 160 seed rows and 229376 receivers: 73728 pilot and 155648 heldout. Proposal comparisons use independent streams.

| Heldout configuration | Proposal | Receivers | Energy/H ± SE | Tie fee/H ± SE |
|---|---|---:|---:|---:|
| n64 m16 H4 | radial uniform | 32768 | 1.85152 ± .09512 | 2.66971 ± .14216 |
| n64 m16 H4 | radial local | 32768 | 1.85935 ± .07984 | 2.61630 ± .10542 |
| n64 m16 H4 | Round59 baseline | 16384 | 1.67892 ± .16265 | 2.41668 ± .26294 |
| n64 m16 H4 | angular local | 16384 | 1.49610 ± .09419 | 2.09989 ± .10343 |
| n32 m16 H4 | radial uniform | 16384 | 1.59619 ± .03870 | 2.24674 ± .05152 |
| n16 m16 H4 | radial uniform | 8192 | 1.25063 ± .02205 | 1.85252 ± .03102 |
| n64 m4 H4 | radial uniform | 16384 | 1.31914 ± .16952 | 1.96245 ± .25026 |
| n64 m16 H16 | radial uniform | 16384 | 1.71131 ± .11008 | 2.46272 ± .15775 |

The radial-uniform/local n64m16H4 seed estimates were respectively (1.93862,1.76441) and (1.84839,1.87030). Their largest observed energy scores were 1278.79 and 752.56. The angular-local estimate differs by about three combined empirical standard errors; sample SE cannot account for unobserved extreme scores. The formal pointwise Hoeffding radius for radial-uniform n64m16H4 is 2.20×10^75 and gives no practical constraint. The K=16 band estimate for n64m4H4 still has SE .92. These observations do not certify a true integral, dimension growth or a uniform cap theorem; no exponent fit was performed.

Exact coordinates and components are saved for extreme receivers. Decimal120/180 independently audit 26 distinct extremes, covering global top-three scores for energy, both bands and tie fee plus each heldout case maximum (8 globally selected distinct receivers). Together with 18 initial complete-density guards, the maximum normalized metric relative discrepancy is 4.87×10^−14; energy precision refinement differs by at most 4.34×10^−118. Three explicit-source compressed-arrival/event/Gram guards pass. Fifteen angular overlap checks and six exact radial overlap checks pass; the angular identities are E_uniform f²=[α²/(2α−1)]^d and E_uniform 1/f=[α(2−α)]^−d on their stated domains. The radial overlap is (2ρ+ρ^−2)/3. Decimal checks are precision diagnostics, not outward-rounded interval certificates or machine-sampling bias bounds.

Separate deterministic evidence includes 63 killed martingale trees, 9 adapted drift examples, 7 sharp-chain recurrences, 4 single-atom finite-band phase checks, 3456 signed-replacement intersection checks, 7 high-precision constants and 56 actual 1D reverse-drift cases. These 56 exact Fraction cases satisfy finite energy budgets and the specified one-phase future-tail certificates. Five added nested-source pressures give full one-phase reverse drift (M0+B)/W of 4.02671,8.02086,16.02083 at depths 8,16,32 with H=2^depth; the depth16/32 values at H4 are 3.02061,3.02083. This pressures a source-independent positive-drift criterion. It is not a phase-averaged continuous e-step counterexample or a general cap counterexample. Abstract tree-to-cube transfer remains unproved.

The standalone standard-library command is `python3 -B angular_cap_guard.py`; it writes `results.json` beside the script. Timing is printed only: the fixed sampling run took 656.438 s; final auxiliary refresh took 6.238 s and the five additional exact pressures 7.546 s. Current L01/L03 skills and relevant provenance/method/interface restrictions were reread.


上述英文数值摘要中“not a phase-averaged counterexample”仅限定五个有理离散压力测试；第7节独立解析证明确实覆盖实际e步长的相位平均。原始采样均值的差异尚未解决，不能宣布真实积分已获高精度计算。

精确1D反向探测把所有来源边界、cap坏集边界与Q边界分割成有理区间，按完整过去质量历史聚类计算条件期望。56个标准案例及5个压力案例均通过尾证书：最终各原子捕获区间不相交、位于Q内且每个左右半区间完整历史常值；此后缩小保留比例恰为步长倒数，所以未经杀死的条件增量为零，杀死只产生非正增量。所有更早粗尺度都捕获完整来源，其遗漏正漂移恰为M0。故它们认证的是指定比例、指定相位和指定Q上的完整双向整数时间漂移，范围不自动扩大。

单原子相位积分采用64、512、4096个中点细化，最大最终误差9.677003×10^−10；100位Decimal单点比较误差最大5.55×10^−17。替换几何检查含1152个接受位移与3456个实际交集比较，最小检查余量约0.414438；这些浮点余量不声称是区间证书。另已用独立按距离排序算法对7个一维来源、2个阈值、每项128个有理接收点检查连续最大值与精确坏区间并集，共1792次一致；正式可复现主脚本保留完整坏区间构造和全部输入。

本轮核心目标未完成。没有获得新的全一般弱型阶数，O(n log n)基准保留；新结果是尖锐抽象杀死预算、实际自然过程接口、适用边界的解析反例及可支付的逐原子有符号替换。下一步必须保留平方增量中的带符号抵消并支付来源混合费用，不能再强求已经证伪的无带或带内完整历史正漂移预算。


## 9. 标记源的独立数值复核与复现片段

主Agent独立运行下方代码通过：25个混合源相位/阈值组合、25个L1组合、75个重复分支组合（各以80和140位计算）。五个相位为0、1/4、1/2、3/4、1倍log(1.1)，阈值最高2^20。最大80/140相对差分别为8.223e−80与8.543e−80；重复分支质量残差最大1.821e−135。这是高精度诊断，不是区间认证。代码直接输出范围与解析下界；表中每相位的空间积分不等同于完整相位积分。解析定理来自第7节证明。

```python
from decimal import Decimal as D, localcontext
import json

PHASE_NUMERATORS = (0, 1, 2, 3, 4)
PRECISIONS = (80, 140)
THRESHOLDS = {
    "atomic": (16, 64, 256, 1024, 1048576),
    "l1": (20, 64, 256, 1024, 1048576),
}

def check_one(kind, height, phase_numerator, precision):
    with localcontext() as ctx:
        ctx.prec = precision
        p, a, b, eta = D(".5"), D(".1"), D(".5"), D(1)
        e, delta = D(1).exp(), D("1.1").ln()
        theta = delta * D(phase_numerator) / 4
        L0, L1 = theta.exp(), (theta - 1).exp()
        lo_total, hi_total = p / D(height), a / 2
        eps = D(0) if kind == "atomic" else p / (4 * D(height))
        alpha = (p + eta * (a + L0 / 2 - b)) / L0
        total, covered, last = D(0), D(0), 0
        first_k = 1 if kind == "atomic" else 2
        for k in range(first_k, 100):
            Lk, Ln = (theta - D(k)).exp(), (theta - D(k + 1)).exp()
            lo = max(lo_total, Ln / 2 - eps)
            hi = min(hi_total, Lk / 2 - eps)
            if lo < hi:
                if kind == "atomic":
                    total += ((p / Lk - alpha) * (hi - lo)
                              + eta * (hi * hi - lo * lo) / (2 * L0))
                else:
                    total += (p / Lk - p / L1) * (hi - lo)
                covered += hi - lo
                last = k
            if Lk / 2 - eps < lo_total:
                break
        tolerance = D(10) ** (-precision + 8)
        assert abs(covered - (hi_total - lo_total)) < tolerance
        coefficient = p / (2 * e) if kind == "atomic" else 2 * p / (5 * e)
        lower = coefficient * (a * D(height) / (2 * p)).ln() - p * e * a / 2
        assert total >= lower
        duplicate_residual = D(0)
        if kind == "l1":
            density = p / (2 * eps)
            for fraction in (D(0), D(".5"), D(1)):
                t = lo_total + (hi_total - lo_total) * fraction
                mass = p + eta * (a + L0 / 2 - b - t)
                duplicate_x = b - L0 / 2 - eps + (mass - 2 * a * eta) / density
                duplicate_mass = (2 * a * eta
                                  + density * (duplicate_x + L0 / 2 - b + eps))
                assert abs(duplicate_mass - mass) < tolerance
                assert duplicate_x + L1 / 2 < b - eps
                assert b + t - L1 / 2 > a
                assert L1 / 2 >= t + eps
                assert p / (2 * (t - eps)) + eta <= D(height)
                duplicate_residual = max(duplicate_residual, abs(duplicate_mass - mass))
        return total, delta * lower, last, duplicate_residual

rows = []
max_relative = {"atomic": D(0), "l1": D(0)}
max_duplicate_residual_140 = D(0)
for kind, heights in THRESHOLDS.items():
    for height in heights:
        values, last_indices = [], []
        for numerator in PHASE_NUMERATORS:
            result80 = check_one(kind, height, numerator, PRECISIONS[0])
            result140 = check_one(kind, height, numerator, PRECISIONS[1])
            with localcontext() as ctx:
                ctx.prec = 160
                relative = abs(result80[0] - result140[0]) / abs(result140[0])
            max_relative[kind] = max(max_relative[kind], relative)
            if kind == "l1":
                max_duplicate_residual_140 = max(max_duplicate_residual_140, result140[3])
            values.append(float(result140[0]))
            last_indices.append(result140[2])
        rows.append({"source": kind, "H": height,
                     "sampled_phase_integral_range": [min(values), max(values)],
                     "analytic_phase_integrated_lower": float(result140[1]),
                     "max_last_index": max(last_indices)})
print(json.dumps({
    "scope": "Finite high-precision checks; not interval certification or phase extrema.",
    "precisions": list(PRECISIONS),
    "phase_fractions_delta": [0, .25, .5, .75, 1],
    "atomic_configurations": 25,
    "l1_configurations": 25,
    "duplicate_configurations": 75,
    "duplicate_precision_evaluations": 150,
    "rows": rows,
    "maximum_relative_80_140": {k: str(v) for k, v in max_relative.items()},
    "maximum_duplicate_mass_residual_140": str(max_duplicate_residual_140),
}, indent=2))
```


## 10. 固定真实阈值带也不能拯救完整历史漂移预算

这是本轮在反例压力测试后进一步排除的关键强式，并非下一轮待证猜想。对第53轮的有界多数来源 f_D，加入

    g_D(x)=f_D(x)+(x+1)/100 ·1_[-1,2](x)+1/100 ·1_[3,12](x)。

质量W=927/200与多数深度D无关，高度≤1.78；接收区间Q=[0,1]始终在真实带{1<Mg_D≤2}中，因此没有杀死。反向过程在k=−2的一个粗尺度平均就呈现严格仿射的x依赖；正向过程的完整小尺度过去趋于g_D(x)，其两个互不重叠的仿射值域也确定x。自然条件期望于是无法再通过混合接收点消去后续增量。在多数构造使用的细尺度上，远处标记完全缺席，仿射项的平均与尺度无关，原来的增量完全不变。

因此两个方向的实际e步长、完整相位平均正漂移都至少是

    [δ D c_m−52δ/100−2δ]/2 → ∞，
    δ=1/4，D=2m+1，c_m=binom(2m,m)/2^(2m)。

第53轮原显示误差式2(D+1)(8e+2)δ/√R正确，但随后文字把它在√R≥100(D+1)下误写成≤26δ/100，漏了因子2；本轮明确使用安全的52δ/100，发散证明不受影响。没有改写旧轮提交或把旧数值当作这一新源的测试。

张量化为g_D(x1)乘其余坐标的1_[-12,12]，可把反例扩展到每个固定n。质量虽依赖n，但对深度D恒定；由体积时间u=n log L和长度1/n的对数平滑，可保留同样的发散下界。故不能以“一维不影响渐近上界”为由保留这一被证伪的普适接口。

这一结论不否定原平方能量：g_D一致有界、总质量固定，已证L2谱界直接给出维度固定时的统一能量预算。被否定的是完整自然历史下的无符号累计收费。有限时间窗口、真正记录/首次筛选、不同观测过程以及有符号混合误差仍须分别证明，不能自动继承此次被否定的前提。

以下完整英文审核记录给出来源定义、精确相位对应和复现片段；详细LaTeX也已纳入同一份英文笔记。

Round53 does explicitly prove an unbounded positive variation for a smoothed scale path. Its exact definitions nevertheless give the raw one-unit scale increment needed for the proposed canonical drift interface. A bounded positive source with two small markers makes this correspondence exact for both time orientations on one fixed true maximal band. The construction below uses actual one-dimensional centered interval averages and Lebesgue receiver measure. It is an analytic derivation from the archived proof, not a numerical extrapolation.

The inspected archive is `centered-cube-upper-bound/rounds/053/research.zip`, especially `proof.md` §§2–5, and its README. Write D=2m+1 for majority depth, to distinguish it from a fixed band ratio. With δ=1/4, R=2^(2q), P_i=R^(−i), and r_i(x)=(-1)^floor(2x/P_i), its density is

    f_D(x)=(3/2+δ sign(sum_{i=1}^D r_i(x))) 1[-1,2](x).

It has mass 9/2 and values 5/4 or 7/4 on its support. Let a_x(u)=A_exp(u) f_D(x) and B_x(u)=integral_0^1 a_x(u+v) dv. Its source is common to all times. On Q=[0,1], at L_j=P_j/√R, j=0,…,D, the archive bounds the error from the actual interval convolution to the conditional-majority function F_j. The binomial formula is

    integral_Q |F_j−F_(j−1)| dx=δ c_m,
    c_m=binom(2m,m)/2^(2m).

Choose √R≥100(D+1), as in the archive. With e<3, its accumulated endpoint error is at most 52δ/100. Both orientations of positive variation of B on [u_D,u_0]=[log L_D,log L_0] therefore have the lower bound

    V_D = [δ D c_m − 52δ/100 − 2δ]/2.

For m≥1, c_m≥1/(2√m), so V_D is unbounded with D. Negative variation in increasing-u orientation has the same lower bound: the difference between positive and negative variation is the endpoint difference, whose magnitude is at most 2δ.

The published conclusion concerns B, not an explicitly stated raw-average variation theorem. However its endpoint proof is uniform for lengths e^v L_j, v∈[0,1]. Setting v=0 gives the same conservative error bound for A_Lj itself. Consequently the sum of raw endpoint absolute increments, and hence both continuous-direction positive variations of the actual a_x path integrated over Q, satisfy the same divergent lower bound. In addition, the more direct identity is

    B'_x(u)=a_x(u+1)−a_x(u) almost everywhere.

Thus V_D already bounds below integral_Q integral_[u_D,u_0] [a_x(u+1)−a_x(u)]_+ du dx, and also its negative counterpart. This is exactly a phase-averaged raw e-step positive increment, although it is not itself raw continuous-time total variation. These two quantities should be named separately.

The original density already places Q in a fixed *true* maximal band: M f_D(x)≤7/4 everywhere, while M f_D(x)≥f_D(x)≥5/4 for almost every x∈Q by differentiation. With h=2 and band ratio K_band=2,

    Q ⊂ {h/K_band < M f_D ≤ h} modulo a null set.

This point differs from a band defined only by a selected value of B. Restricting receiver integration to this true maximal band preserves the lower bound.

Unbounded actual variation alone does not imply unbounded natural conditional drift, because conditional expectation can average out the increments. To remove that obstruction, add markers to the same actual density. Fix ε=1/100 and define

    g_D(x)=f_D(x)+ε(x+1)1[-1,2](x)+ε1[3,12](x).

Its mass is W=9/2+9ε/2+9ε=927/200, independent of D. Its maximum density is at most 7/4+3ε=1.78<2. On Q its value exceeds one. Thus Q remains in the true band {1<M g_D≤2}, and the killed process is never killed on Q, at any scale or phase.

On every Round53 comparison scale and intervening smoothed window, all intervals lie inside [-1,2], and have full side at most eL_0<1. The marker is absent. Symmetric interval averaging of the affine term gives exactly ε(x+1), independently of its side length. It follows that *all raw differences and B derivatives on this window are unchanged*. No accumulating perturbation estimate is required for the later variation. The two marker heights can be made arbitrarily smaller while retaining the arguments; positive size, not a quantitative signal-to-noise threshold, matters to an exact natural history.

For the forward orientation, define on [0,1)×Q

    f_k(θ,x)=A_exp(θ+k) g_D(x),
    F_k=σ(θ,f_j:j≤k).

The complete past has lim_{j→−∞} f_j(θ,x)=g_D(x) almost everywhere. On Q the limiting values lie in the disjoint ranges [5/4+ε,5/4+2ε] and [7/4+ε,7/4+2ε]. Within either range they recover x by an affine inverse. Therefore x is F_k-measurable for every k, modulo null sets. Since f_(k+1) is a Borel function of θ and x,

    E[f_(k+1)|F_k]=f_(k+1).

The canonical positive conditional drift equals the actual positive increment, pointwise almost everywhere.

For the reverse orientation, use f_k(θ,x)=A_exp(θ−k)g_D(x) and the same complete natural-history definition. At the one coarse index k=−2, write L=e^(θ+2) and r=L/2∈[e²/2,e³/2). The interval [x−r,x+r] contains all the local source [-1,2], has no marker at its left endpoint, and cuts [3,12] at its right endpoint. Its average is

    f_(-2)(θ,x)=[(9/2)(1+ε)+ε(x+r−3)]/L.

For each θ this function is strictly increasing in x∈Q, with derivative ε/L>0. Its jointly measurable inverse recovers x from (θ,f_(-2)). Hence all reverse increments after this index are predictable from the canonical past. All indices contributing to the small-scale majority window occur after −2. Again the positive conditional drift equals the actual positive increment there.

Finally Tonelli and the disjoint phase decomposition u=θ+k, or u=θ−k, give exact identities for phase-averaged actual positive increments. For forward time, the full canonical drift equals integral_Q integral_R [a_g(u+1)−a_g(u)]_+ du dx. For reverse time, predictability is established only for increments with current index k≥−1, after observing k=−2; the full canonical drift need not equal the full negative-increment integral. Its retained predictable increments, however, cover the entire fine window [u_D,u_0], and by phase decomposition their drift is at least integral_Q integral_[u_D,u_0] [a_g(u)−a_g(u+1)]_+ du dx. Both orientations therefore have lower bound V_D. θ is part of the natural filtration, and no rational approximation to e is involved. Nonnegative sums permit extended values and this lower bound needs only the finite majority scale window.

Under the Round60 definition with the *complete* past, the proposed condition “for every source and fixed true band, at least one of the two canonical orientations has positive killed conditional drift bounded by b_n W” therefore fails already at n=1 and fixed h=2, K_band=2, fixed Q, uniformly bounded positive L1 sources and mass independent of D. Both orientations fail for the same g_D family. This does not disprove the cap square-energy bound, a weak maximal estimate, a record-selected fee, or a criterion using a different explicitly coarser observable. A filtration that keeps all past actual averages cannot forget either marker. Finite-past or noisy observation variants require separate definitions; they are not the canonical filtration audited here.

The essential compatibility checks are the true-band inclusion, exact invariance of later differences under the affine/remote additions, measurable receiver recovery in each history, absence of killing, and phase decomposition. The source is bounded and compactly supported but the majority part is discontinuous; the uniform remote marker is also discontinuous. If a continuous remote marker is required, use a continuous trapezoid supported in [r0−1,e r0+2], equal to one on [r0,e r0+1], with unit linear ramps and r0=e³/2. At coarse k=−3 the marker is cut within its positive plateau for every phase; the average derivative is ε/L>0. The same proof works with a different fixed mass. No claim that the whole source is continuous, or that drift survives arbitrary smoothing/atomic approximation, is needed.


An arithmetic correction to the archive is needed: its displayed endpoint loss is 2(D+1)(8e+2)δ/√R. With the stated √R≥100(D+1), replacing e by 3 bounds that loss by 52δ/100, rather than the prose claim 26δ/100. The safe V_D used here keeps the factor two; the divergent conclusion is unchanged.

The following deterministic Fraction guard checks the coarse marker geometry simultaneously for every phase using 27/10<e<14/5, and the density/mass arithmetic. It is a geometry check, not a numerical proof of the binomial divergence.

```python
from fractions import Fraction as F
lo, hi, eps = F(27,10), F(14,5), F(1,100)
rmin, rmax = lo**2/2, hi**3/2
assert rmin > 3 and 1+rmax < 12
assert 1-rmin < -1 and rmin > 2
assert F(7,4)+3*eps < 2 and F(5,4)+eps > 1
assert F(9,2)+F(9,2)*eps+9*eps == F(927,200)
# For fixed phase L>0, d A_L g_D(x)/dx = eps/L > 0.
```


A further standalone exact-source guard enumerates toy majority depths 1,3,5 at R=4, integrates the actual piecewise density, affine addition and distant marker, and checks coarse mass, fine invariance and a rational-ratio difference. Its R does not satisfy the asymptotic separation rule; these checks only verify geometry and exact invariance. The separate large-depth budget evaluation uses the stated true √R choice without source enumeration. Neither guard treats rational e approximation as exact e.

```python
from fractions import Fraction as F
from math import comb
from bisect import bisect_right
EPS, DELTA = F(1,100), F(1,4)
counts = {"coarse": 0, "fine": 0, "step": 0}
for depth in (1,3,5):
    R = 4
    cells_per_unit = 2*R**depth
    left = F(-1); step = F(1,cells_per_unit)
    prefix = [F(0)]
    values = []
    for index in range(3*cells_per_unit):
        midpoint = left+(index+F(1,2))*step
        signs = [1 if (2*midpoint*R**j).__floor__()%2==0 else -1
                 for j in range(1,depth+1)]
        value = F(3,2)+DELTA*(1 if sum(signs)>0 else -1)
        values.append(value); prefix.append(prefix[-1]+value*step)
    assert prefix[-1] == F(9,2)
    def base_primitive(t):
        if t<=-1:return F(0)
        if t>=2:return prefix[-1]
        index=((t+1)/step).__floor__()
        return prefix[index]+values[index]*(t+1-index*step)
    def average(x,L,modified):
        a,b=x-L/2,x+L/2
        mass=base_primitive(b)-base_primitive(a)
        if modified:
            aa,bb=max(a,F(-1)),min(b,F(2))
            if aa<bb:mass+=EPS*((bb+1)**2-(aa+1)**2)/2
            mass+=EPS*max(F(0),min(b,F(12))-max(a,F(3)))
        return mass/L
    for x in (F(0),F(1,16),F(1,2),F(15,16),F(1)):
        for L in (F(15,2),F(10),F(15),F(20)):
            expected=(F(9,2)*(1+EPS)+EPS*(x+L/2-3))/L
            assert average(x,L,True)==expected;counts["coarse"]+=1
        for L in (F(1,64),F(1,128)):
            assert average(x,L,True)-average(x,L,False)==EPS*(x+1)
            counts["fine"]+=1
            ratio=F(2718281828459045,10**15)
            assert (average(x,ratio*L,True)-average(x,L,True)
                    ==average(x,ratio*L,False)-average(x,L,False))
            counts["step"]+=1
budgets=[]
for depth in (17,33,65,129,257,513,1025):
    m=(depth-1)//2
    central=F(comb(2*m,m),2**(2*m))
    root=1
    while root<100*(depth+1):root*=2
    # e<3: keep both endpoint errors in the loss.
    loss=2*(depth+1)*26*DELTA/root
    lower=(DELTA*depth*central-loss-2*DELTA)/2
    assert loss<=F(52,100)*DELTA
    budgets.append((depth,root,str(lower),float(lower)))
print("toy exact source guards PASS",counts)
print("safe analytic budget parameters",budgets)
```

Executed result: 60 coarse, 30 fine-profile and 30 rational-step exact checks passed. All seven safe large-depth budget calculations passed.


The same obstruction holds for every fixed dimension n. Define g_D^(n)(x)=g_D(x_1)∏_{i=2}^n 1[-12,12](x_i), Q_n=[0,1]^n. Its mass W_n=(927/200)24^(n−1) is independent of D, its density is at most 1.78, and Q_n lies in the same true band. At reverse index k=−2n, side L=e^((θ+2n)/n) lies in [e²,e³]; all transverse coordinate intervals are inside [-12,12]. Their averaging factors are one, so the preceding affine marker value recovers x_1. The complete forward fine past also recovers x_1. Full receiver recovery is unnecessary: on the majority fine window all cube averages depend only on x_1 and scale, so all those increments are predictable in either history.

To match volume-time increments exactly, write s=log L and B_n(s)=n∫_0^(1/n) A_exp(s+v) f_D dv. Its derivative is n[a(s+1/n)−a(s)]. The original endpoint approximation is uniform for v∈[0,1], hence also on this smaller interval. Its positive and negative integrated variations have the same lower bound V_D. With u=ns, the phase partition gives ∫du [a(s+1/n)−a(s)]_+=∫ds [B_n'(s)]_+, and the analogous negative identity. Integration over the transverse unit receiver coordinates contributes one. Consequently each canonical drift is at least V_D; dividing by the fixed mass W_n still diverges with D for every fixed n. This tensor extension adds no assumption of a dimension-uniform discrete-to-continuous transfer.



主Agent独立执行第10节的全部复现代码：60个真实toy粗尺度质量检查、30个细尺度仿射不变性检查、30个有理尺度增量检查，以及7组深度17至1025的精确参数预算全部通过。toy采用R=4，明确不满足渐近构造要求的尺度分离，仅核对真实来源实现；一般发散结论仍来自显式端点误差和二项式下界。复现片段使用Fraction，位于本报告Python代码块内，无外部文件依赖。

最终证明状态：一般根号n乘次幂损失上界仍未完成；全一般O(n log n)基准保留。本轮已排除完整自然历史无符号漂移的两种收费方式。后续只考虑能够保留混合符号、正确限制时间或真实记录筛选并付清全部费用的接口，绝不把本轮的否定结论伪装为原极大算子下界。


## 11. 最终独立复现与归档记录

最终主脚本从压缩输入独立提取，在新的临时目录实际执行默认完整运行，退出码0，用时670.260秒。生成results.json与冻结结果逐字节一致：5,644,616字节，SHA-256 f5b76e89916db89698c9a64e465d86f3cb9df55bfb73317a64c54daa743ec66c。主脚本SHA-256为d3384c6343aa7a24e720bd67ea757384c5dd5f87426c6c2294138af06ee5bd7d。最终五成员归档再次校验这些字节绑定；没有为相同主脚本重复消耗一次Monte Carlo运行。

最终归档只含proof.md、proof.tex.txt、angular_cap_guard.py、results.json、inventory.json。LaTeX做ASCII、环境、括号、标签与引用等静态检查，不运行编译器或生成PDF。数值代码AST、JSON解析、报告中所有Python复现片段、ZIP CRC及四个被清单记录文件的SHA分别检查。清单自身不纳入自身哈希，ZIP哈希写在外部README。

仓库按当前AGENTS规则只新增本轮README与research.zip，并更新项目总览指针；不纳入本地草稿、审查中间件、临时脚本、缓存或原始文献的重复副本。第53轮的因子2修正记录于本轮，不修改旧提交。历史材料依赖去重尚未全部完成，本轮未擅自清理被旧报告引用的文件。
