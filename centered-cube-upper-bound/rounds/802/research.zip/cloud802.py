#!/usr/bin/env python3
"""Exact public and private redraws from the two original old-price slots."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform


ROWS_SHA="04bbd600cd68bd2bb371559590a1902b97a345c02404ffc759a1147fb4b2bae9"
KS=(2,3,4)


def gate(left,right):
    u,i,below=left
    v,j,other_below=right
    return (u==v and i==j) or (u!=v and i==0 and j==1 and below and not other_below)


def paired_comparison(profiles,weights,cells,base):
    """Same hidden original parent for both iid draws versus mixing it away."""
    assert base.total(weights)==1
    combined=[base.total(w*q[j] for w,q in zip(weights,profiles)) for j in range(len(cells))]
    support=[i for i,w in enumerate(combined) if w]
    same,independent,absolute=F(0),F(0),F(0)
    witness_positive,witness_negative=None,None
    expected=defaultdict(F)
    for a,b in product(support,repeat=2):
        joint=base.total(w*q[a]*q[b] for w,q in zip(weights,profiles))
        mixed=combined[a]*combined[b]
        assert joint-mixed==base.total(w*(q[a]-combined[a])*(q[b]-combined[b])
                                      for w,q in zip(weights,profiles))
        expected[a]+=joint
        if a==b:
            same+=joint
            independent+=mixed
            assert joint>=mixed
        diff=joint-mixed
        absolute+=abs(diff)
        evidence=dict(price_first=cells[a],price_second=cells[b],
                      same_parent=joint,independent_mixed=mixed,signed_difference=diff)
        if diff>0 and (witness_positive is None or diff>witness_positive["signed_difference"]):
            witness_positive=evidence
        if diff<0 and (witness_negative is None or diff<witness_negative["signed_difference"]):
            witness_negative=evidence
    assert all(expected[a]==combined[a] for a in support)
    assert base.total(expected.values())==1==base.total(combined)
    assert same>=independent
    return dict(same_physical_price_cell_under_same_parent=same,
                same_physical_price_cell_after_independent_mixing=independent,
                same_cell_excess=same-independent,total_variation_on_exact_price_cells=absolute/2,
                positive_witness=witness_positive,negative_witness=witness_negative)


def k_fold_table(profiles,sector_bits,base):
    N=len(profiles)
    hits=[]
    counts={}
    for w,law in enumerate(profiles):
        masses=defaultdict(F)
        for b,p in zip(sector_bits,law):
            masses[b]+=p
        sectors=[(b,p) for b,p in masses.items() if p]
        assert base.total(p for _,p in sectors)==1
        first=[base.total(p for b,p in sectors if b&(1<<u)) for u in range(N)]
        assert first[w]==1
        hits.append(first)
        for k in KS:
            separate=[F(0)]*N
            for seq in product(sectors,repeat=k):
                active=(1<<N)-1
                mass=F(1)
                for b,p in seq:
                    active &= b
                    mass*=p
                for u in range(N):
                    if active&(1<<u):
                        separate[u]+=mass
            assert separate==[x**k for x in first]
            counts[w,k]=separate
    return hits,counts


def mixture_hit(profiles,table,p,sector_bits,base):
    n=len(p)
    P=[base.total(w*q[j] for w,q in zip(p,profiles)) for j in range(len(sector_bits))]
    target=[base.total(v for v,b in zip(P,sector_bits) if b&(1<<u)) for u in range(n)]
    assert target==[base.total(p[w]*table[w][u] for w in range(n)) for u in range(n)]
    single=base.total(q*v for q,v in zip(p,target))
    assert single==base.total(p[u]*p[w]*table[w][u] for u,w in product(range(n),repeat=2))
    examples={}
    for k in KS:
        independent=base.total(p[u]*target[u]**k for u in range(n))
        one_hidden_candidate=base.total(p[u]*p[w]*table[w][u]**k for u,w in product(range(n),repeat=2))
        assert 0<=independent<=one_hidden_candidate<=1
        examples[k]=dict(independently_redraw_from_mixture=independent,
                         one_candidate_shared_by_all_k_draws=one_hidden_candidate,
                         gap=one_hidden_candidate-independent)
    same_label=base.total(x*x for x in p)
    distinct_hit=base.total(p[u]*p[w]*table[w][u] for u,w in product(range(n),repeat=2) if u!=w)
    assert single==same_label+distinct_hit
    return dict(single_hit_with_all_parent_choices=single,
                same_parent_label_probability=same_label,
                hit_and_distinct_parent_labels=distinct_hit,
                hit_given_distinct_actual_parent_labels=distinct_hit/(1-same_label) if same_label<1 else None,
                capture_by_target=target,by_k=examples)


def stage(name,T,A,shares,amplitude,source_mark,base):
    E=[base.owner(B,q) for B,q in zip(T,shares)]
    e=[base.owner(B,F(1)) for B in A]
    all_receivers=sorted(E+e)
    assert all(x[1]<y[0] for x,y in zip(all_receivers,all_receivers[1:]))
    mT=list(map(base.length,T))
    mA=list(map(base.length,A))
    I=list(map(base.length,E))
    j=list(map(base.length,e))
    mu=lambda b:base.real_mass(b,amplitude)
    assert list(map(mu,T+A))==mT+mA
    N=len(A)
    cuts=sorted({*base.SOURCE,F(2),F(49,16),*(F(i,4) for i in range(-32,33)),
                 *(p for B in T+A for p in B)})
    cells=list(zip(cuts,cuts[1:]))
    marks=[k for k,B in enumerate(cells) if B[0]<source_mark<B[1]]
    assert len(marks)==1
    a0=marks[0]
    cmu=list(map(mu,cells))
    assert min(cmu)>0
    recv=[[(B[0],base.point(B)),(base.point(B),B[1])] for B in e]
    sectors=[sum(1<<u for u,B in enumerate(A) if base.inside(q,B)) for q in cells]
    D=[base.volume_bucket(m) for m in mT]
    d_by_t=[]
    left={D0:defaultdict(F) for D0 in sorted(set(D))}
    right={D0:defaultdict(F) for D0 in sorted(set(D))}
    explicit_left={D0:defaultdict(F) for D0 in sorted(set(D))}
    explicit_right={D0:defaultdict(F) for D0 in sorted(set(D))}
    anchor_true_slots=defaultdict(list)
    repeated=F(0)
    all_screen=F(0)
    asymmetry=F(0)
    repetitions=[]
    nonproduct=None
    per_middle=[]
    for t,T0 in enumerate(T):
        neigh={}
        for u,B in enumerate(A):
            overlap=base.clip(T0,B)
            q=mu(overlap)
            if mA[u]<mT[t] and q:
                neigh[u]=overlap,q,q/(mT[t]*mA[u])
        d=base.total(j[u]*q[2] for u,q in neigh.items())
        assert d>0
        d_by_t.append(d)
        factor=I[t]/d
        buckets=defaultdict(list)
        for u,(Iu,total_price,K) in neigh.items():
            for a,h in product(range(len(cells)),range(2)):
                if not base.inside(cells[a],Iu):
                    continue
                value=j[u]*K*cmu[a]/total_price*base.length(recv[u][h])/j[u]
                assert value==cmu[a]*base.length(recv[u][h])/(mT[t]*mA[u])>0
                sig=(u,h,cells[a][1]<=2)
                buckets[sig].append((u,h,a,value))
        S={sig:base.total(q[3] for q in marks_in_bucket) for sig,marks_in_bucket in buckets.items()}
        assert base.total(S.values())==d
        if nonproduct is None:
            options=[a for a in S if a[1]==0]
            for first in options:
                other=next((b for b in options if b[0]!=first[0]),None)
                if other is None:
                    continue
                assert gate(first,first) and gate(other,other)
                assert not (gate(first,other) or gate(other,first))
                nonproduct=dict(t=t,true_d=d,source_and_owner_signatures=(first,other),
                                positive_unmarked_diagonal_and_cross_weights=[
                                   factor*S[first]**2,factor*S[other]**2,factor*S[first]*S[other]],
                                kept_diagonals=True,kept_crosses=False)
                break
        left_allow={a:base.total(w for b,w in S.items() if gate(a,b)) for a in S}
        right_allow={b:base.total(w for a,w in S.items() if gate(a,b)) for b in S}
        original_screen=factor*base.total(S[a]*w for a,w in left_allow.items())
        assert original_screen==factor*base.total(S[a]*w for a,w in right_allow.items())
        assert 0<original_screen<I[t]*d
        for sig,items in buckets.items():
            for u,h,a,value in items:
                left[D[t]][u,a]+=factor*value*left_allow[sig]
                right[D[t]][u,a]+=factor*value*right_allow[sig]
        checked=F(0)
        for (s,X),(q,Y) in product(buckets.items(),repeat=2):
            if not gate(s,q):
                continue
            if not gate(q,s):
                asymmetry+=factor*S[s]*S[q]
            for (u,h,a,w),(v,k,b,vw) in product(X,Y):
                old_path=factor*w*vw
                checked+=old_path
                explicit_left[D[t]][u,a]+=old_path
                explicit_right[D[t]][v,b]+=old_path
                if u==v:
                    repeated+=old_path
                    if not repetitions and a==a0 and b==a0:
                        repetitions.append(dict(t=t,u=u,price_z=cells[a],price_q=cells[b],
                                                actual_U=recv[u][h],actual_V=recv[v][k],
                                                weight_in_true_original_path=old_path,
                                                both_slots_together=2*old_path,d=d))
                if a==a0:
                    anchor_true_slots[D[t]].append((u,old_path))
                if b==a0:
                    anchor_true_slots[D[t]].append((v,old_path))
        assert checked==original_screen
        all_screen+=original_screen
        per_middle.append(dict(t=t,true_d=d,volume_bin=D[t],I=I[t],original_clean_first_times_second_mass=I[t]*d,
                               truly_screened_complete_mass=original_screen,owner_half_price_signature_sizes=len(S)))
    assert left==explicit_left and right==explicit_right
    assert len(repetitions)==1 and repeated>0 and asymmetry>0 and nonproduct is not None
    lam_d={D0:{(u,a):left[D0][u,a]+right[D0][u,a]
                 for u,a in product(range(N),range(len(cells)))}
           for D0 in left}
    lam=[[base.total(block[u,a] for block in lam_d.values()) for a in range(len(cells))] for u in range(N)]
    J=list(map(base.total,lam))
    M=base.total(J)
    assert min(J)>0 and M==2*all_screen
    pi=[[x/J[u] for x in row] for u,row in enumerate(lam)]
    assert all(base.total(q)==1 for q in pi)
    assert all(not w or sectors[a]&(1<<u) for u,q in enumerate(pi) for a,w in enumerate(q))
    rho=[[w/mA[u] if sectors[a]&(1<<u) else F(0) for a,w in enumerate(cmu)] for u in range(N)]
    assert all(base.total(q)==1 for q in rho)
    true_hit,redraw_count=k_fold_table(pi,sectors,base)
    rho_hit=[[mu(base.clip(A[u],A[v]))/mA[u] for v in range(N)] for u in range(N)]
    assert all(rho_hit[w][u]==base.total(q for q,b in zip(rho[w],sectors) if b&(1<<u))
               for w,u in product(range(N),repeat=2))

    global_pair=paired_comparison(pi,[x/M for x in J],cells,base)
    global_pair.update(unnormalized_mass=M,
                       unnormalized_same_cell_same_parent=global_pair["same_physical_price_cell_under_same_parent"]*M,
                       unnormalized_same_cell_independent=global_pair["same_physical_price_cell_after_independent_mixing"]*M,
                       unnormalized_same_cell_excess=global_pair["same_cell_excess"]*M,
                       unnormalized_total_variation=global_pair["total_variation_on_exact_price_cells"]*M)
    assert global_pair["unnormalized_same_cell_excess"]>0

    records={}
    for D0,block in lam_d.items():
        posterior_num=[block[u,a0] for u in range(N)]
        a_mass=base.total(posterior_num)
        assert a_mass>0 and a_mass==base.total(w for _,w in anchor_true_slots[D0])
        p=[v/a_mass for v in posterior_num]
        admissible=[u for u,v in enumerate(p) if v]
        forecasts={}
        assert all(base.total(w for v,w in anchor_true_slots[D0] if v==u)==posterior_num[u] for u in range(N))
        for k in KS:
            numerator=[base.total(x*true_hit[w][u]**k for u,x in enumerate(posterior_num)) for w in range(N)]
            winner=max(admissible,key=lambda w:(numerator[w],-w))
            global_best=max(range(N),key=lambda w:(numerator[w],-w))
            # The list is of true old slots of complete records. Both slots
            # persist even when the physical old label and price cell match.
            direct=base.total(w*redraw_count[winner,k][u] for u,w in anchor_true_slots[D0])
            assert direct==numerator[winner]
            assert 0<direct<=numerator[global_best]<=a_mass
            hidden_oracle=base.total(w*redraw_count[u,k][u] for u,w in anchor_true_slots[D0])
            assert hidden_oracle==a_mass
            forecasts[k]=dict(chosen_public_old_parent=winner,also_allowing_global_candidate=global_best,
                              positive_original_density=direct/cmu[a0],
                              true_fraction_paid=direct/a_mass,true_uncovered_mass=a_mass-direct,
                              whole_price_cell_mass_after_redraw=direct,explicit_original_records_replay=direct,
                              oracle_if_reading_hidden_parent=hidden_oracle,
                              maximum_if_allowing_global_candidate=numerator[global_best]/a_mass,
                              actual_all_candidate_fractions=[w/a_mass for w in numerator])
        conditional=paired_comparison(pi,p,cells,base)
        if name!="initial" and D0==4:
            assert len(admissible)>1 and conditional["total_variation_on_exact_price_cells"]>0
            assert all(0<x["true_uncovered_mass"]<a_mass for x in forecasts.values())
        records[str(D0)]=dict(observed_price=source_mark,observed_true_price_cell=cells[a0],
                              price_cell_actual_mu=cmu[a0],summed_true_old_price_density=a_mass/cmu[a0],
                              exact_l_u_density=[v/cmu[a0] for v in posterior_num],posterior_old_parent=p,
                              true_original_slot_count=len(anchor_true_slots[D0]),public_selection=forecasts,
                              at_this_source_row_same_vs_mixed=conditional,
                              conditional_P_using_frozen_pi=mixture_hit(pi,true_hit,p,sectors,base),
                              same_comparison_with_actual_source_rho=mixture_hit(rho,rho_hit,p,sectors,base))
    return dict(stage=name,physical_middle=T,physical_old=A,true_middle_owners=E,true_old_owner=e,
                source_amplitude=amplitude,true_original_d=d_by_t,actual_middle_bins=D,per_middle=per_middle,
                original_screened_true_path_total=all_screen,
                directed_only_screen_mass=asymmetry,same_real_old_parent_path_total=repeated,
                actual_nonproduct_whole_path_screen_witness=nonproduct,
                same_parent_both_slots_counted_example=repetitions[0],true_price_atoms=cells,
                normalized_cloud_pi_u=pi,original_combined_J_u=J,all_frozen_real_pi_hits=true_hit,
                physical_parent_source_rho_hits=rho_hit,global_unnormalized_private_pair_check=global_pair,
                routes_at_fixed_actual_z=records)


def suite(base):
    T=[base.iv(0,4),base.iv("1/4","17/4"),base.iv("1/2","9/2")]
    A=[base.iv(-1,1),base.iv(3,5),base.iv("9/8","25/8")]
    return [
      stage("initial",[T[0],T[2]],[A[0],base.iv("5/2","9/2")],[F(1),F(3,4)],F(1,4),F(9,16),base),
      stage("pressure",T,A,[F(1),F(3,4),F(1,2)],F(1,2),F(97,32),base),
      stage("expanded",T+[base.iv("3/8","27/8"),base.iv("7/8","31/8")],
            A+[base.iv("1/2",3),base.iv(2,"9/2")],
            [F(1),F(3,4),F(1,2),F(7,8),F(5,8)],F(3,4),F(97,32),base),
    ]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--rows-dir",type=Path,default=Path(__file__).resolve().parent)
    a=p.add_mutually_exclusive_group()
    a.add_argument("--output",type=Path)
    a.add_argument("--check",type=Path)
    args=p.parse_args()
    dep=args.rows_dir/"rows798.py"
    assert sha256(dep.read_bytes()).hexdigest()==ROWS_SHA
    spec=importlib.util.spec_from_file_location("rows798",dep)
    base=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    data=suite(base)
    obj=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
             dependency={"rows798.py":ROWS_SHA},command="python -B cloud802.py --check cloud802.json",
             scope=dict(precision="standard-library exact Fraction",
                        source="true positive compact periodic piecewise constant source; all physical parent masses equal their lengths",
                        screen="same old and same actual owner half, or different olds with first owner lower, second owner upper, and first true price below 2, second above 2",
                        combined="both actual original price/receiving slots enter frozen J_u and pi_u, including two slots on the same original old father",
                        public="one w fixed for the observed z,D and chosen before the hidden old label, then k conditionally iid draws from its frozen real pi",
                        private="compare the unnormalized same-parent law sum J_u pi_u tensor pi_u with the product of the full original price projection divided by its mass. Repeat conditionally with actual p_(z,D). Same-cell does not mean equality of two continuous prices.",
                        range="finite one-dimensional true geometry and stated diagnostic screen, with full genuine original d"),
             stages=data)
    text=json.dumps(obj,sort_keys=True,indent=2,default=str)+"\n"
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for row in data:
            S=row["routes_at_fixed_actual_z"]["4"]
            print(row["stage"],"posterior",list(map(str,S["posterior_old_parent"])),
                  "public k=2/3/4",[str(S["public_selection"][k]["true_fraction_paid"]) for k in KS],
                  "private minus independent same-cell",S["at_this_source_row_same_vs_mixed"]["same_cell_excess"])
        if args.check:
            print("byte-identical")
    else:
        print(text,end="")


if __name__=="__main__":
    main()
