#!/usr/bin/env python3
"""Two complete directed slots with the same hidden old parent and real four-price geometry."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform


ROWS_SHA="04bbd600cd68bd2bb371559590a1902b97a345c02404ffc759a1147fb4b2bae9"
CLOUD_SHA="36f7170fef276bb5924e6b73dbc04a9b2803215248e1c43cc7852db7e62223fe"
RADIUS=F(1,2)


def gate(A,B):
    u,h,below=A
    g,w,other_below=B
    return (u==g and h==w) or (u!=g and h==0 and w==1 and below and not other_below)


def gap(I,J):
    return max(F(0),I[0]-J[1],J[0]-I[1])


def uniform_near(I,J,r,base):
    """Exact continuous strip area by positive-part squares and by slices."""
    def outside(A,B):
        a,b=A
        c,d=B
        def ramp(t):
            return (max(F(0),t-a)**2-max(F(0),t-b)**2)/2
        return ramp(d-r)-ramp(c-r)
    rectangular=base.length(I)*base.length(J)
    area=rectangular-outside(I,J)-outside(J,I)
    a,b=I
    c,d=J
    knots=sorted({a,b,*(x for x in (c-r,c+r,d-r,d+r) if a<x<b)})
    def width(x):
        return max(F(0),min(d,x+r)-max(c,x-r))
    via_slices=base.total((hi-lo)*(width(lo)+width(hi))/2 for lo,hi in zip(knots,knots[1:]))
    assert 0<=area==via_slices<=rectangular
    return area/rectangular


def dot(x,y,base):
    return base.total(v*y.get(k,F(0)) for k,v in x.items())


def smooth(hist,kernel,q_first=False):
    """Exchange independently the two actual interval-pair integrations."""
    mid=defaultdict(F)
    out=defaultdict(F)
    if q_first:
        for (z,q),v in hist.items():
            for j,p in kernel[q]:
                mid[z,j]+=p*v
        for (z,q),v in mid.items():
            for i,p in kernel[z]:
                out[i,q]+=p*v
    else:
        for (z,q),v in hist.items():
            for i,p in kernel[z]:
                mid[i,q]+=p*v
        for (z,q),v in mid.items():
            for j,p in kernel[q]:
                out[z,j]+=p*v
    return out


def histograms(maps,n):
    data=[[defaultdict(F) for _ in range(n)] for _ in range(n)]
    for u,law in enumerate(maps):
        for (a,b,g,w),v in law.items():
            data[u][g][a,b]+=v
    return data


def weighted_exchange(direct,other,upper,J,cells,base):
    n=len(J)
    K=[[uniform_near(I,B,RADIUS,base) for B in cells] for I in cells]
    for i,j in product(range(len(cells)),repeat=2):
        assert K[i][j]==K[j][i]
    kernel=[[(j,w) for j,w in enumerate(row) if w] for row in K]
    X=histograms(direct,n)
    Y=histograms(other,n)
    H=histograms(upper,n)
    original=[[F(0)]*n for _ in range(n)]
    near=[[F(0)]*n for _ in range(n)]
    price_mixed=defaultdict(F)
    upper_near=F(0)
    for u in range(n):
        tmp=defaultdict(F)
        for h in range(n):
            for pair,value in X[u][h].items():
                price_mixed[pair]+=value
            for pair,value in H[u][h].items():
                tmp[pair]+=value
        upper_near+=dot(tmp,smooth(tmp,kernel,True),base)/J[u]
        for h in range(n):
            from_first_coord=smooth(X[u][h],kernel)
            from_second_coord=smooth(Y[u][h],kernel,True)
            assert from_first_coord==from_second_coord
            for g in range(n):
                first=dot(X[u][g],from_first_coord,base)/J[u]
                assert first==dot(Y[u][g],from_second_coord,base)/J[u]
                near[g][h]+=first
                original[g][h]+=base.total(X[u][g].values())*base.total(X[u][h].values())/J[u]
    total_J=base.total(J)
    assert total_J==base.total(w for row in original for w in row)
    target=[base.total(row) for row in original]
    assert target==[base.total(row[h] for row in original) for h in range(n)]
    actual_near=base.total(v for row in near for v in row)
    wrong_geo=dot(price_mixed,smooth(price_mixed,kernel),base)/total_J
    assert 0<actual_near<total_J and actual_near<=upper_near
    assert all(0<=near[g][h]==near[h][g]<=original[g][h] for g,h in product(range(n),repeat=2))
    assert actual_near!=wrong_geo
    independent=[[a*b/total_J for b in target] for a in target]
    signed=[[original[g][h]-independent[g][h] for h in range(n)] for g in range(n)]
    assert any(v for row in signed for v in row)
    return dict(actual_two_slot_mass=total_J,max_price_displacement_near_radius=RADIUS,
                actual_near_joint=actual_near,actual_far_tail=total_J-actual_near,
                actual_fraction_near=actual_near/total_J,actual_fraction_far=(total_J-actual_near)/total_J,
                independent_hidden_parent_mixed_near=wrong_geo,
                center_supported_same_u_upper_near=upper_near,
                opposite_old_pair_joint=original,opposite_old_pair_marginals=target,
                incorrectly_independent_opposite_labels=independent,
                true_label_pair_difference_from_independent=signed,
                opposite_label_pair_variation_distance=base.total(abs(w) for row in signed for w in row)/2,
                actual_near_projection_g_h=near,
                actual_far_projection_g_h=[[original[g][h]-near[g][h] for h in range(n)] for g in range(n)])


def stage(name,T,U,shares,amplitude,cloud,base):
    ET=[base.owner(A,s) for A,s in zip(T,shares)]
    EU=[base.owner(A,F(1)) for A in U]
    sorted_E=sorted(ET+EU)
    assert all(x[1]<y[0] for x,y in zip(sorted_E,sorted_E[1:]))
    m=list(map(base.length,T))
    sm=list(map(base.length,U))
    I=list(map(base.length,ET))
    j=list(map(base.length,EU))
    mu=lambda x:base.real_mass(x,amplitude)
    assert list(map(mu,T+U))==m+sm
    n=len(U)
    cut=sorted({*base.SOURCE,F(2),F(49,16),*(F(i,4) for i in range(-32,33)),
                *(v for box in T+U for v in box)})
    cells=list(zip(cut,cut[1:]))
    cmu=list(map(mu,cells))
    assert all(w/base.length(b) in (1+amplitude,1-amplitude) for b,w in zip(cells,cmu))
    recv=[[(E[0],base.point(E)),(base.point(E),E[1])] for E in EU]
    true=[defaultdict(F) for _ in U]
    alt=[defaultdict(F) for _ in U]
    kcap=[defaultdict(F) for _ in U]
    factor_for=[{} for _ in U]
    central=defaultdict(list)
    witnesses={}
    screened_total=F(0)
    old_same=F(0)
    both_slots=None
    ds=[]
    for t,A in enumerate(T):
        legs=[]
        d=F(0)
        for u,B in enumerate(U):
            X=base.clip(A,B)
            mx=mu(X)
            if not mx or sm[u]>=m[t]:
                continue
            K=mx/(m[t]*sm[u])
            d+=j[u]*K
            for a,h in product(range(len(cells)),range(2)):
                if not base.inside(cells[a],X):
                    continue
                f=base.length(recv[u][h])/j[u]
                r=K*j[u]*cmu[a]/mx*f
                assert r==cmu[a]*base.length(recv[u][h])/(m[t]*sm[u])>0
                legs.append((u,a,h,r,(u,h,cells[a][1]<=2)))
        ds.append(d)
        assert base.total(v[3] for v in legs)==d>0
        root=I[t]/d
        t_coefficient=I[t]/(m[t]**2*d)
        for L,R in product(legs,repeat=2):
            if not gate(L[4],R[4]):
                continue
            u,z,h,w,_=L
            g,q,v,h1,_=R
            weight=root*w*h1
            a=(z,q,g,v)
            b=(q,z,u,h)
            screened_total+=weight
            true[u][a]+=weight
            true[g][b]+=weight
            if u==g:
                old_same+=weight
                if a==b and both_slots is None:
                    both_slots=dict(u=u,coordinate=a,true_d=d,one_path=weight,both_ordered_contributions=2*weight)
            for x,y,own,other,orientation in ((u,a,L,R,"first"),(g,b,R,L,"second")):
                if (x,y) not in witnesses:
                    witnesses[x,y]=dict(actual_central=t,d=d,ordered_orientation=orientation,
                          own_old=x,own_true_price=cells[own[1]],own_actual_owner=recv[x][own[2]],
                          other_old=other[0],other_true_price=cells[other[1]],
                          other_actual_owner=recv[other[0]][other[2]],original_complete_record_weight=weight)
        # Independent density expansion, grouping only the own receiving half
        # and keeping every actual opposite father, price, and receiver.
        own=sorted({(u,z) for u,z,h,r,s in legs})
        for (u,z),(g,q,w,k,s) in product(own,legs):
            theta=[base.total(base.length(recv[u][h])/j[u] for h in range(2)
                              if (gate((u,h,cells[z][1]<=2),s) if side==0
                                  else gate(s,(u,h,cells[z][1]<=2)))) for side in (0,1)]
            if not any(theta):
                continue
            a=(z,q,g,w)
            actual_fund=j[u]*cmu[z]/sm[u]*cmu[q]*base.length(recv[g][w])/sm[g]
            assert 0<actual_fund
            alt[u][a]+=actual_fund*t_coefficient*base.total(theta)
            kcap[u][a]+=t_coefficient*sum(x>0 for x in theta)
            factor_for[u][a]=actual_fund
            central[u,a].append(dict(t=t,d=d,physical_m=m[t],original_center_coefficient=t_coefficient,
                                    own_receiver_fractions_by_orientation=theta))
    assert true==alt and both_slots is not None
    J=list(map(lambda d:base.total(d.values()),true))
    M=base.total(J)
    assert M==2*screened_total and old_same>0
    assert [F(x) for x in cloud["original_combined_J_u"]]==J
    for u,v in enumerate(true):
        assert [base.total(w for a,w in v.items() if a[0]==z)/J[u] for z in range(len(cells))]==[
                      F(w) for w in cloud["normalized_cloud_pi_u"][u]]
    assert ds==[F(q) for q in cloud["true_original_d"]]
    upper=[{a:kcap[u][a]*factor_for[u][a] for a in law} for u,law in enumerate(true)]
    assert all(v<=upper[u][a] for u,law in enumerate(true) for a,v in law.items())
    geometry=weighted_exchange(true,alt,upper,J,cells,base)
    assert geometry["actual_two_slot_mass"]==M

    marginal=defaultdict(F)
    support=defaultdict(set)
    for u,v in enumerate(true):
        for a,w in v.items():
            marginal[a]+=w
            support[a].add(u)
    independent_totals=[base.total(v.values()) for v in alt]
    for a,value in marginal.items():
        left=base.total(true[u].get(a,F(0))*independent_totals[u]/J[u] for u in range(n))
        right=base.total(J[u]*alt[u].get(a,F(0))/independent_totals[u] for u in range(n))
        assert left==right==value
    assert base.total(marginal.values())==M
    coarse=defaultdict(set)
    for a,V in support.items():
        coarse[a[0]].update(V)
    a0=next(i for i,b in enumerate(cells) if b[0]<F(97,32)<b[1])
    possible=[]
    for a,X in support.items():
        if a[0]!=a0 or len(X)>=len(coarse[a0]):
            continue
        for b,Y in support.items():
            if X&Y or not coarse[a0]&Y:
                continue
            far=max(gap(cells[a[0]],cells[b[0]]),gap(cells[a[1]],cells[b[1]]))
            if far>RADIUS:
                possible.append((int(a[2]==1),far,marginal[a]*marginal[b],a,b))
    assert possible
    _,geo_gap,_,a,b=max(possible)
    active=coarse[a[0]]
    lz=[base.total(w for row,w in law.items() if row[0]==a[0]) for law in true]
    assert {u for u,x in enumerate(lz) if x}==active
    a0mass=base.total(lz)
    true_same=base.total(true[u].get(a,F(0))*true[u].get(b,F(0))/J[u] for u in range(n))
    assert true_same==0 and min(marginal[a],marginal[b])>0
    exact_z_only=base.total(lz[u]/a0mass*true[u].get(b,F(0))/J[u] for u in range(n))
    real_cond_donor_mass=base.total(true[u].get(a,F(0))/marginal[a]*true[u].get(b,F(0))/J[u] for u in range(n))
    wrong_independent=marginal[a]*marginal[b]/M
    assert real_cond_donor_mass==0<exact_z_only and wrong_independent>0

    fine={q for q,V in support.items() if support[a]&V}
    broad={q for q,V in support.items() if active&V}
    assert fine < broad and b in (broad-fine)
    ranked=[kcap[u].get(a,F(0)) for u in range(n)]
    other=[kcap[u].get(b,F(0)) for u in range(n)]
    common_sup=max(x*y for x,y in zip(ranked,other))
    wrong_sup=max(ranked)*max(other)
    assert common_sup==0<wrong_sup
    actual_same_u_envelope=base.total(upper[u].get(a,F(0))*upper[u].get(b,F(0))/J[u] for u in range(n))
    assert actual_same_u_envelope==0

    def describe(A):
        z,q,g,w=A
        return dict(own_z=cells[z],opposite_q=cells[q],actual_opposite_small=g,
                    actual_opposite_owner_cell=recv[g][w],true_marginal_mass=marginal[A],
                    true_possible_hidden_old=sorted(support[A]),z_only_hidden_old=sorted(coarse[z]),
                    actual_center_and_real_owner_witnesses={u:witnesses[u,A] for u in sorted(support[A])},
                    original_center_support_menu={u:central[u,A] for u in sorted(support[A])})
    example=dict(first=describe(a),would_be_donor=describe(b),minimum_true_max_price_separation=geo_gap,
                 actual_shared_old_joint_weight=true_same,wrong_independence_joint_mass=wrong_independent,
                 actual_conditional_donor_probability_given_full_a=real_cond_donor_mass,
                 altered_conditional_donor_probability_when_only_z_known=exact_z_only,
                 number_of_full_observation_donors=len(fine),number_of_z_only_donors=len(broad),
                 common_same_u_k_product_sup=common_sup,wrong_separate_k_product_sup=wrong_sup,
                 actual_first_k_u=ranked,actual_donor_k_u=other,
                 same_u_envelope_including_J_and_physical_factors=actual_same_u_envelope)
    return dict(stage=name,middle_parents=T,old_parents=U,middle_owners=ET,old_owners=EU,
                density_amplitude=amplitude,original_d=ds,common_mass_per_old=J,
                positive_complete_observations=len(marginal),
                actual_complete_pair_marginals_left_right=[base.total(marginal.values())]*2,
                both_marginals_verified_on_every_complete_atom=True,true_two_arm_screen_mass=screened_total,
                true_same_old_screen_mass=old_same,two_slots_same_actual_view_counted=both_slots,
                four_price_geometry=geometry,concrete_forbidden_far_donor=example,
                actual_price_cells=cells,
                max_k_density_envelope_slack=max(upper[u][a]-w for u,law in enumerate(true) for a,w in law.items()))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    here=Path(__file__).resolve().parent
    p.add_argument("--rows-dir",type=Path,default=here)
    p.add_argument("--cloud-dir",type=Path,default=here)
    action=p.add_mutually_exclusive_group()
    action.add_argument("--output",type=Path)
    action.add_argument("--check",type=Path)
    args=p.parse_args()
    cloud=args.cloud_dir/"cloud802.json"
    rows=args.rows_dir/"rows798.py"
    assert sha256(rows.read_bytes()).hexdigest()==ROWS_SHA
    assert sha256(cloud.read_bytes()).hexdigest()==CLOUD_SHA
    spec=importlib.util.spec_from_file_location("rows798",rows)
    base=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    frozen={x["stage"]:x for x in json.loads(cloud.read_text())["stages"]}
    T=[base.iv(0,4),base.iv("1/4","17/4"),base.iv("1/2","9/2")]
    U=[base.iv(-1,1),base.iv(3,5),base.iv("9/8","25/8")]
    data=[
       stage("pressure",T,U,[F(1),F(3,4),F(1,2)],F(1,2),frozen["pressure"],base),
       stage("expanded",T+[base.iv("3/8","27/8"),base.iv("7/8","31/8")],
             U+[base.iv("1/2",3),base.iv(2,"9/2")],[F(1),F(3,4),F(1,2),F(7,8),F(5,8)],
             F(3,4),frozen["expanded"],base)]
    out=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
             command="python -B pair802.py --check pair802.json",
             dependencies={"rows798.py":ROWS_SHA,"cloud802.json":CLOUD_SHA},
             scope=dict(precision="standard-library exact Fraction",
                        physical_pair="two independent complete original views conditionally on the same actual hidden old parent, both original orientations included and the real directional screen frozen",
                        observation="own true price, opposite true price, opposite physical old, and that opposite's actual receiving half",
                        kernel="near is max(|z-z'|, |q-q'|)<=1/2. Both coordinate pair integrals use exact continuous interval area, and g,h are kept joint. The cutoff is a one-dimensional diagnostic.",
                        center_support="k_u is the sum of actual supported center coefficients per orientation when the original screen admits any own receiver half. The exact formula averages that genuine half; replacing the average with one gives the upper.",
                        sign="the near and far projected g,h use one shared hidden old; the displayed independent old or independent opposite-label products are wrong comparators"),
             stages=data)
    text=json.dumps(out,sort_keys=True,indent=2,default=str)+"\n"
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for a in data:
            g=a["four_price_geometry"]
            q=a["concrete_forbidden_far_donor"]
            print(a["stage"],"near/far",g["actual_near_joint"],g["actual_far_tail"],
                  "coarse extra donor",q["altered_conditional_donor_probability_when_only_z_known"],
                  "true",q["actual_conditional_donor_probability_given_full_a"])
        if args.check:
            print("byte-identical")
    else:
        print(text,end="")


if __name__=="__main__":
    main()
