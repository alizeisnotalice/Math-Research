"""Optimize public source menus on the exact continuous piecewise-constant price laws of R802."""
from argparse import ArgumentParser
from fractions import Fraction as F
from hashlib import sha256
from importlib.util import spec_from_file_location, module_from_spec
from pathlib import Path
import json
import platform

import flint
from flint import arb, ctx

ctx.prec = 384
CLOUD_HASH = "36f7170fef276bb5924e6b73dbc04a9b2803215248e1c43cc7852db7e62223fe"
ROWS_HASH = "04bbd600cd68bd2bb371559590a1902b97a345c02404ffc759a1147fb4b2bae9"


def optimal(weights, costs, budget):
    """Primal measurable subset fractions and dual cutoff for one source menu."""
    order = sorted(range(len(weights)), key=lambda j: (-weights[j] / costs[j], j))
    remaining = budget
    shares = [F(0)] * len(costs)
    cutoff = F(0)
    for j in order:
        if not remaining or not weights[j]:
            break
        shares[j] = min(F(1), remaining / costs[j])
        remaining -= costs[j] * shares[j]
        cutoff = weights[j] / costs[j] if not remaining else F(0)
    primal = sum(x * w for x, w in zip(shares, weights))
    dual = cutoff * budget + sum(max(F(0), w - cutoff * c) for w, c in zip(weights, costs))
    assert primal == dual and all(0 <= x <= 1 for x in shares)
    assert sum(x * c for x, c in zip(shares, costs)) <= budget
    return primal, cutoff, shares


def compare(stage, base):
    cells = [tuple(map(F, cell)) for cell in stage["true_price_atoms"]]
    mass = [base.real_mass(cell, F(stage["source_amplitude"])) for cell in cells]
    labels = [tuple(map(F, interval)) for interval in stage["physical_old"]]
    parents = [base.volume_bucket(base.length(interval)) for interval in labels]
    amounts = list(map(F, stage["original_combined_J_u"]))
    forecasts = [list(map(F, row)) for row in stage["normalized_cloud_pi_u"]]
    assert all(sum(row) == 1 for row in forecasts)
    assert sum(amounts) == 2 * F(stage["original_screened_true_path_total"])
    aggregate = [F(0)] * 3
    witnesses = []
    for D in sorted(set(parents)):
        indices = [u for u, bucket in enumerate(parents) if bucket == D]
        budget = D / F(4)
        column = [sum(amounts[u] * forecasts[u][i] for u in indices) for i in range(len(cells))]
        fixed = optimal(column, mass, budget)[0]
        adaptive = F(0)
        private = sum(amounts[u] * optimal(forecasts[u], mass, budget)[0] for u in indices)
        for i, anchor_mass in enumerate(column):
            if not anchor_mass:
                continue
            joint = [sum(amounts[u] * forecasts[u][i] * forecasts[u][j] for u in indices)
                     for j in range(len(cells))]
            assert sum(joint) == anchor_mass
            value, cutoff, fractions = optimal(joint, mass, budget)
            direct = sum(amounts[u] * forecasts[u][i] *
                         sum(x * p for x, p in zip(fractions, forecasts[u])) for u in indices)
            assert direct == value
            oracle = sum(amounts[u] * forecasts[u][i] * optimal(forecasts[u], mass, budget)[0]
                         for u in indices)
            assert value <= oracle
            adaptive += value
            if value < oracle and not witnesses:
                witnesses.append(dict(anchor=list(map(str, cells[i])), small_volume_bin=str(D),
                                      conditional_public=str(value / anchor_mass),
                                      conditional_private=str(oracle / anchor_mass),
                                      dual_cut_price=str(cutoff)))
        assert fixed <= adaptive <= private
        aggregate = [a + b for a, b in zip(aggregate, (fixed, adaptive, private))]
    return dict(stage=stage["stage"], small_volume_bins=sorted(set(map(str, parents))),
                budget="D/4", original_two_slot_mass=str(sum(amounts)),
                best_fixed_menu=str(aggregate[0] / sum(amounts)),
                best_public_menu_by_anchor=str(aggregate[1] / sum(amounts)),
                observing_private_parent=str(aggregate[2] / sum(amounts)),
                strict_private_witness=witnesses)


def marked_lists(stage, base, helper):
    """Compute the best hidden-parent list with real source union cost in every true row."""
    cells = [tuple(map(F, c)) for c in stage["true_price_atoms"]]
    small = [tuple(map(F, c)) for c in stage["physical_old"]]
    middle = [tuple(map(F, c)) for c in stage["physical_middle"]]
    degrees = list(map(F, stage["true_original_d"]))
    js = [base.length(tuple(map(F, row))) for row in stage["true_old_owner"]]
    jt = [base.length(tuple(map(F, row))) for row in stage["true_middle_owners"]]
    mass = [base.real_mass(cell, F(stage["source_amplitude"])) for cell in cells]
    bins = [base.volume_bucket(base.length(A)) for A in small]
    assert len(set(bins)) == 1
    D = bins[0]
    cap = 5 * D / 4
    nlabels = len(small)
    subsets = []
    for mask in range(1 << nlabels):
        ids = [u for u in range(nlabels) if mask & (1 << u)]
        used = sum(w for c, w in zip(cells, mass) if any(base.inside(c, small[u]) for u in ids))
        if used <= cap:
            subsets.append(ids)
    assert all([u] in subsets for u in range(nlabels))
    coarse = {}
    detailed = {}
    for t, A in enumerate(middle):
        arms = []
        for u, U in enumerate(small):
            if base.length(U) >= base.length(A):
                continue
            for i, c in enumerate(cells):
                if base.inside(c, U) and base.inside(c, A):
                    weight = mass[i] * js[u] / (2 * base.length(A) * base.length(U))
                    for k in range(2):
                        arms.append((u, i, k, weight))
        assert sum(x[-1] for x in arms) == degrees[t]
        for u, i, k, wu in arms:
            sig1 = (u, k, cells[i][1] <= 2)
            for g, j, h, wg in arms:
                sig2 = (g, h, cells[j][1] <= 2)
                ways = int(helper.gate(sig1, sig2)) + int(helper.gate(sig2, sig1))
                if not ways:
                    continue
                amount = ways * jt[t] * wu * wg / degrees[t]
                detailed.setdefault((t, i, g, j, h), [F(0)] * nlabels)[u] += amount
                coarse.setdefault(i, [F(0)] * nlabels)[u] += amount
    totals = [sum(v[u] for v in detailed.values()) for u in range(nlabels)]
    assert list(map(F, stage["original_combined_J_u"])) == totals
    def capture(v):
        return max(sum((v[u] for u in ids), F(0)) for ids in subsets)
    full = sum(totals)
    fixed, own_price, all_marks = (capture(totals), sum(map(capture, coarse.values())),
                                   sum(map(capture, detailed.values())))
    assert fixed <= own_price <= all_marks <= full == 2 * F(stage["original_screened_true_path_total"])
    ambiguous = sum(1 for weights in detailed.values() if capture(weights) < sum(weights))
    return dict(stage=stage["stage"], public_union_budget=str(cap), small_parent_bin=str(D),
                admissible_subfamilies=len(subsets), public_marked_rows=len(detailed),
                unresolved_rows_at_this_budget=ambiguous, fraction_without_marks=str(fixed / full),
                fraction_with_own_price=str(own_price / full), fraction_with_all_public_marks=str(all_marks / full),
                private_informed_fraction="1", combined_actual_J=list(map(str, totals)))


def parameter(q):
    n = arb(2)**q
    ell = (n + 2).log()
    root = n.sqrt()
    L = root * ell**3
    Hmodel = 1 + (root + 1) / ell**2
    omega_lower = ell**4 / arb(8192)**2
    omega_upper = (root * ell**2 + 1)**2 / (arb(8192)**2 * n)
    upper_log = 2 * Hmodel.log() + 3 * ell + ell.log() - L.log() - omega_lower / 2048
    # 64/M divided by tau. M >= exp(r/4096), including after row pruning.
    upper_small = arb(64).log() + (omega_upper - root * ell**2) / 4096
    assert upper_small < -arb(2).log()
    assert upper_log < 0 or upper_log > 0
    return dict(n_power_of_two=q, upper_model_log_fee=upper_log.str(22),
                upper_bound_sign="negative" if upper_log < 0 else "positive",
                upper_log_64_over_M_tau=upper_small.str(22))


def main():
    p = ArgumentParser(description=__doc__)
    p.add_argument("--rows-dir", type=Path, default=Path(__file__).resolve().parent)
    cli = p.add_mutually_exclusive_group(required=True)
    cli.add_argument("--output", type=Path)
    cli.add_argument("--check", type=Path)
    opt = p.parse_args()
    dep = opt.rows_dir / "rows798.py"
    assert sha256(dep.read_bytes()).hexdigest() == ROWS_HASH
    spec = spec_from_file_location("base798", dep)
    base = module_from_spec(spec)
    spec.loader.exec_module(base)
    cloud = Path(__file__).resolve().parent / "cloud802.json"
    assert sha256(cloud.read_bytes()).hexdigest() == CLOUD_HASH
    rows = json.loads(cloud.read_text())["stages"]
    stages = [compare(s, base) for s in rows]
    helper_path = cloud.with_name("cloud802.py")
    assert sha256(helper_path.read_bytes()).hexdigest() == "4c0740bf8f5e125fad3c1ffaa999b92a8f3ed9ea24690494eb24595b7fa22d14"
    helper_spec = spec_from_file_location("cloud802_local", helper_path)
    helper = module_from_spec(helper_spec)
    helper_spec.loader.exec_module(helper)
    marks = [marked_lists(s, base, helper) for s in rows]
    assert all(F(s["best_fixed_menu"]) < F(s["best_public_menu_by_anchor"]) for s in stages)
    assert all(F(s["best_public_menu_by_anchor"]) < F(s["observing_private_parent"]) for s in stages[1:])
    scalar = [parameter(q) for q in (32, 128, 512, 2048, 8192, 32768, 65536)]
    out = dict(experiment="Nonatomic source-measure menus. Finite diagnostics use D/4; the analytic theorem uses exp(omega/4096) D.",
               certification="exact equality of fractional-knapsack primal and dual on each constant-density cell; "
                             "cell fractions realizable by intervals; separately 384-bit Arb at seven dimensions",
               python=platform.python_version(), flint=flint.__version__, arb_bits=ctx.prec,
               cloud_sha256=CLOUD_HASH, rows_sha256=ROWS_HASH, diagnostics=stages, marked_list_diagnostics=marks, parameter_rows=scalar)
    encoded = (json.dumps(out, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()
    if opt.output:
        opt.output.write_bytes(encoded)
    else:
        assert opt.check.read_bytes() == encoded
        print("menu802 byte-identical")


if __name__ == "__main__":
    main()
