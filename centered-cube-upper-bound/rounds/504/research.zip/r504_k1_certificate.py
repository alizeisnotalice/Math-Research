from fractions import Fraction as F
from math import comb
from pathlib import Path
import json,sys,platform
from flint import arb,ctx
import flint
ctx.prec=384

def aa(x):
 x=F(x);return arb(x.numerator)/x.denominator

def integ(k,l,u):
 return (u/l).log() if k==0 else (u**k-l**k)/k

def cert(n):
 h=F(1,n*n);q=F(2,3)**n
 # x=q R^n crosses 1/2,1,2 at these radii, respectively.
 r0=aa(F(3,2))*(-arb(2).log()/n).exp();r1=aa(F(3,2));r2=aa(F(3,2))*(arb(2).log()/n).exp()
 assert r0>1 and r0<r1 and r1<2
 if r2>2:r2clip=arb(2)
 else:assert r2<2;r2clip=r2
 # L1=l0+l1*x, L2=m0+m2*x^2 for weighted V-interval lengths.
 pieces=[(arb(1),r0,0,2,0,F(9,2)),(r0,r1,1,0,1,F(1,2)),(r1,r2clip,2,-1,2,F(-1,2))]
 total=arb(0)
 for l,u,l0,l1,m0,m2 in pieces:
  value=arb(0)
  for j in range(n):
   c=F(comb(n-1,j))*(-h)**j
   value+=aa(n*c*l0)*integ(-j,l,u)
   value+=aa(n*c*l1*q)*integ(n-j,l,u)
   value-=aa(n*n*h*c*m0)*integ(-j-1,l,u)
   value-=aa(n*n*h*c*m2*q*q)*integ(2*n-j-1,l,u)
  assert value>0
  total+=value
 assert total>0 and total<3*arb(2).log()+aa(F(n-1,n))
 return total
rows=[]
for n in [2,8,32,128]:
 value=cert(n)
 row={'n':n,'h':str(F(1,n*n)),'q':str(F(2,3)**n),'K1_strict_arb':str(value)}
 if n==128:
  assert value>aa(F(2057,1000)) and value<aa(F(2059,1000))
  # Rounded published refined mean, treated only as a rational diagnostic.
  assert value>aa(F(1914,1000))
  row['exact_diagnostic_bracket']=['2.057','2.059']
 rows.append(row)
out={'scope':'strict finite K=1 lower contribution for uniform cube h=1/n^2,q=(2/3)^n,r=2,R in[1,2]; not arbitrary f','python':platform.python_version(),'python_flint':flint.__version__,'executable':sys.executable,'precision_bits':ctx.prec,'method':'exact rational binomial coefficients, piecewise elementary antiderivatives, outward Arb algebraic endpoints; no quadrature','rows':rows}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
for row in rows:print(row['n'],row['K1_strict_arb'])
print('PASS 4 rigorous K1 intervals; n128 in (2.057,2.059), exceeds refined diagnostic 1.914')
