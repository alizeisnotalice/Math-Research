import sympy as s
from fractions import Fraction as F

R,n=s.symbols('R n',positive=True)
x,y,z,dx,dy,dz=s.symbols('x y z dx dy dz',positive=True)
U=x+y+z;K=x*y/(R**n*U)
der=s.diff(K,R)+s.diff(K,x)*dx+s.diff(K,y)*dy+s.diff(K,z)*dz
p=x/U;q=y/U
candidate=R**(-n)*(q*(1-p)*dx+p*(1-q)*dy-p*q*dz)-n*K/R
assert s.simplify(der-candidate)==0
# Whole finite binary tree, leaves x,y,z: root (x+y,z), child (x,y).
tree=(x+y)*z/U+x*y/U
assert s.simplify(tree-(U**2-x*x-y*y-z*z)/(2*U))==0
# Layercake qband identity before use of any maximal estimate.
for vals in [[F(1),F(2),F(3)],[F(2),F(2)],[F(1)]]:
    q0=F(1);cuts=sorted(set([q0]+vals))
    integral=sum((hi-lo)*sum(v>lo for v in vals)
                 for lo,hi in zip(cuts,cuts[1:]))
    assert sum(vals)==q0*len(vals)+integral
print('PASS 5 symbolic/Fraction derivative, finite-tree and qband-layercake identities; not a maximal weak estimate')
