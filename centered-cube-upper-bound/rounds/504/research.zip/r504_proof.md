# R504：原尺度窗内最后穿越与真实有符号边界通量

结论：最后穿越可在不改变真实中心集合、来源测度和原费用的条件下实施；固定尺度端点只需 \(SrW\)。完整通量公式保留一个负边界项，但现有 matching 与穿越方向不足以把其净费用从 \(n\log(b/a)W\) 降至根阶。本稿没有新增一般根阶付款，也没有把窗外 outermost 尺度假作同 octave 接收者。

## 1. 量词及合法尺度选择

固定 \(\mu=f\,dx\)、\(f\ge0\)、\(W=\int f<\infty\)，真实可测中心集合 \(E\) 及其原选择器 \(a\le R_A\le b\le2a\)、\(a>0\)。原完整质量满足
\[
m_A=\mu(Q(A,R_A))=q_AR_A^n,\quad q\le q_A\le\lambda,
\quad \nu(dA)=t(A)q_A\,dA,\quad0\le t\le S,
\quad r=\lambda/q.
\]
这里所有 \(R\) 是边长。定义连续函数
\[
U(A,R)=\mu(Q(A,R)),\qquad g(A,R)=U(A,R)/R^n.
\]
联合连续性来自 \(f\in L^1\) 与盒的平移、尺度变化；盒边界是 \(\mu\)-零集。分成不交集合
\[
E_b=\{A\in E:g(A,b)\ge q\},\qquad E_c=E\setminus E_b.
\]
对 \(A\in E_c\)，集合 \(\{R\in[a,b]:g(A,R)\ge q\}\) 非空且紧，令其最大元为 \(\rho(A)\)。则
\[
a\le\rho(A)<b,\quad g(A,\rho(A))=q,
\quad g(A,R)<q\quad(\rho(A)<R\le b).\tag{1}
\]
\(\rho\) 可测：其上水平集可由紧区间上连续函数最大值的可测性表示。允许 \(\rho=a\)、触碰阈值后下降和阈值平台，不要求横截性。仅在光滑且穿越点可微时才有局部右导数非正；不假定 \(\rho\) 之后一直单调。

这保留同一个真实中心 \(A\)，交叉群的新盒在同一尺度窗内且质量恰为 \(q\rho^n\)。原费用通过
\[
w(A)=t(A)q_A/q\le Sr
\]
精确保留为 \(\nu|_{E_c}=qw(A)\,dA\)。它只是比较原正中心费用的辅助选择器，不能把原路径、rank、void 或接受 history 迁到新盒。\(E_b\) 不保证存在窗内 q-level 穿越；必须另结算。令
\[
w_b(A)=t(A)q_A/g(A,b)\le Sr\quad(A\in E_b),
\]
则 \(\nu|_{E_b}=w_b(A)g(A,b)\,dA\)。此处没有断言 \(g(A,b)\le\lambda\)，也不把末端盒认作新的 qband 场。

## 2. 完整来源的边界通量及原费用恒等式

先对光滑非负 \(f\) 写
\[
\mathcal B(A,R)=R^{1-n}\partial_R U(A,R)
=\frac1{2R^{n-1}}\sum_{j=1}^n\sum_{\epsilon=\pm1}
\int_{[-R/2,R/2]^{n-1}}
 f(A+\epsilon R e_j/2+y_{\perp j})\,dy_{\perp j}.
\]
因此
\[
\partial_{\log R}g=\mathcal B-ng,
\qquad \int_{\mathbb R^n}g(A,R)\,dA=W,
\qquad \int_{\mathbb R^n}\mathcal B(A,R)\,dA=nW.\tag{2}
\]
这些是实际完整来源积分，不以边界体积推测来源质量。对每个 crossing 父，基本微积分给
\[
q=g(A,b)+\int_{\rho(A)}^b[ng(A,R)-\mathcal B(A,R)]\,\frac{dR}{R}.\tag{3}
\]
于是原总费用准确为
\[
\begin{aligned}
R_\tau
={}&\int_{E_b}w_b(A)g(A,b)\,dA
+\int_{E_c}w(A)g(A,b)\,dA\\
&+\int_a^b\int_{E_c\cap\{\rho(A)\le R\}}
 w(A)[ng(A,R)-\mathcal B(A,R)]\,dA\,\frac{dR}{R}.
\end{aligned}\tag{4}
\]
两项末端来源费用合计至多 \(SrW\)，因为中心集合不交，两个权都不超过 \(Sr\)。尺度项的两个非负部分各至多 \(Sr n\log(b/a)W\)，故 (4) 不涉及 \(\infty-\infty\)。舍弃其中负边界项仅得
\[
\boxed{R_\tau\le Sr[1+n\log(b/a)]W.}\tag{5}
\]
这与已知尺度包络同阶，不是新的改进。\(a=b\) 时 \(E_c\) 为空，完整费用只需 \(SrW\)。

对任意 \(L^1\) 来源，不必通过光滑化后猜测最后穿越点收敛。对固定中心，径向层积分直接使 \(R\mapsto U(A,R)\) 绝对连续；(2) 的面公式在几乎处处尺度成立。Tonelli 给全中心、全尺度的 \(\mathcal B\) 可积性，并有
\[
\int_a^b\int |\partial_{\log R}g|\,dA\,dR/R
\le2n\log(b/a)W.
\]
故 (3) 对实际 \(\rho(A)\) 仍成立，随后由上述绝对可积性得到 (4)。不要求穿越唯一或稳定，也不改变 \(\mu\) 后重新匹配。

## 3. 穿越没有自动支付的具体环节

设 \(w_R(A)=w(A)1_{E_c}(A)1_{\rho(A)\le R}\)。将 (4) 的尺度项换序到来源 \(x\)，其被积函数恰为
\[
\begin{aligned}
\int f(x)\Bigg[&\frac n{R^n}\int_{Q(x,R)}w_R(A)\,dA\\
&-\frac1{2R^{n-1}}\sum_{j,\epsilon}
\int_{[-R/2,R/2]^{n-1}}
 w_R(x-\epsilon R e_j/2-y_{\perp j})\,dy_{\perp j}\Bigg]dx.
\end{aligned}\tag{6}
\]
括号是同一实际停止中心集的“内部平均减面平均”，不是两份可独立收费的来源。\(w_R\) 由完整 \(f\)、原 \(t,q_A\) 与最后穿越共同决定，不能当作独立于 \(x\) 的随机选择；它也没有已证的平滑性或面/体平均比较。局部下降只约束穿越瞬间，不能证明整个停止区间上的 (6) 足够小。即便 \(g(A,R)<q\) 对所有 \(R>\rho(A)\) 成立，该函数仍可多次上升下降。

若只分别用 \(0\le w_R\le Sr\)，(6) 的正部分重新产生式 (5) 的 \(n\) 费用。要改善全预算，必须对这里**同一停止中心集、同一来源权下的净通量**建立额外可积抵消；本稿没有这样的比较。第一穿越改写为起点加正通量也有同样问题：原起点已高于 q 的父须先保留，之后正通量由 \(\mathcal B\) 控制，积分仍带 \(nW\)。这不是另一个已获付款的分支。

## 4. 本机精确连续中心核验

取 \(n=1\)、\(f=1_{[-1,1]}\)、\(a=1,b=2\)、\(q=\lambda=3/4\)、\(t=1\)，原中心 \(A\in[1/2,3/4]\)，原选择器就取 \(R_A=4(1-A)\)。这是单值、正 Lebesgue 中心、完整匹配的场。在相关尺度内
\[
g(A,R)=\tfrac12+(1-A)/R,\quad
\mathcal B(A,R)=\tfrac12,\quad \rho(A)=4(1-A).
\]
原费用 \(R_\tau=3/16\)；末端项为 \(11/64\)，尺度内部正项为 \(9/64-(\log2)/8\)，负边界项为 \(1/8-(\log2)/8\)，净通量为 \(1/64\)。这检查真实分母和负项，而不是一般高维预算证据；未实现原历史。

以下完整代码已使用本机数学 Python 实际运行：

```python
import sympy as s
x,R=s.symbols('x R',positive=True)
rho=4*(1-x)
g=s.Rational(1,2)+(1-x)/R
face=s.Rational(1,2)
assert s.simplify(R*s.diff(g,R)-(face-g))==0
terminal=s.integrate(g.subs(R,2),(x,s.Rational(1,2),s.Rational(3,4)))
bulk=s.integrate(s.integrate(g/R,(R,rho,2)),
                 (x,s.Rational(1,2),s.Rational(3,4)))
boundary=s.integrate(s.integrate(face/R,(R,rho,2)),
                     (x,s.Rational(1,2),s.Rational(3,4)))
assert s.simplify(terminal+bulk-boundary-s.Rational(3,16))==0
print('terminal=',terminal,'bulk=',s.simplify(bulk),
      'boundary=',s.simplify(boundary),'flux=',s.simplify(bulk-boundary))
print('2 exact crossing/flux assertions PASS')
```

实际 stdout：

```text
terminal= 11/64 bulk= 9/64 - log(2)/8 boundary= 1/8 - log(2)/8 flux= 1/64
2 exact crossing/flux assertions PASS
```

有界结论：尺度重选与有符号边界通量均合法，但尚未改变可用的整体维数预算。没有把式 (6) 的命名、末端固定尺度付款或选择器存在性作为根阶闭合。
