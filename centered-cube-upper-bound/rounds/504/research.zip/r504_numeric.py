#!/usr/bin/env python3
"""R504 finite-family Sobol/quadrature diagnostic, not rigorous integration."""
from pathlib import Path
from fractions import Fraction
import sys,platform,time,json
import numpy as np
import scipy
from scipy.integrate import quad
from scipy.special import roots_legendre
from scipy.stats import qmc
import sympy as sp
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0

def ck(v):
 global checks
 assert bool(v)
 checks+=1

def symbolic():
 v=sp.symbols('v',positive=True);h,R=sp.symbols('h R',positive=True)
 ck(sp.integrate(2*v,(v,0,1))==1)
 inv=sp.integrate(2,(v,0,1));ck(inv==2)
 ck(sp.simplify((1-h/R)+h/R-1)==0)
 ck(sp.simplify(-1+(h/R)*(R/(2*h))*inv)==0)
 ck(sp.integrate(2/v,(v,0,1))==sp.oo)
 # 1D actual g integral: central length R-h at density1/R, two edge ramps.
 ell=sp.symbols('ell',positive=True)
 ck(sp.simplify((R-h)/R+2*sp.integrate(ell/(h*R),(ell,0,h))-1)==0)
 lo,hi,nn=sp.symbols('lo hi n',positive=True)
 ck(sp.simplify(sp.integrate(2*v*(R/(2*h*v)-nn),(v,lo,hi))-(R/h*(hi-lo)-nn*(hi**2-lo**2)))==0)
 rr=sp.symbols('r',positive=True)
 xx=sp.symbols('x',positive=True)
 ck(sp.simplify(sp.integrate(2/xx,(xx,v,2*v))+sp.integrate(1/xx,(xx,v/rr,v))-(2*sp.log(2)+sp.log(rr)))==0)
 ck(3*arb(2).log()+1<arb(308)/100)
 zz=sp.symbols('z',nonnegative=True)
 ck(sp.expand((1-(nn-1)*zz)*(1-nn*zz)-(1-(2*nn-1)*zz)-nn*(nn-1)*zz**2)==0)
 return {'weighted_law':'independent coordinate: central prob 1-h/R, edge prob h/R; V density 2v','normalization':'1','mean_Z':'0','second_moment_edge':'infinity','scope':'symbolic exact; numerical integrals below diagnostic only'}

def integrate(n,h,logq,seed,power,order):
 # Identical deterministic scrambled point set throughout this R-integral.
 pts=qmc.Sobol(2*n,scramble=True,seed=seed).random_base2(power)
 event=pts[:,:n]; logv=np.log(np.sqrt(pts[:,n:]))
 invv=np.exp(-logv)
 nodes,weights=roots_legendre(order)
 def at(t):
  radius=np.exp(t);edge=(event<h/radius)
  sums=np.sum(np.where(edge,invv,0),axis=1)
  zp=np.maximum(-n+radius/(2*h)*sums,0)
  logg=-n*t+np.sum(np.where(edge,logv,0),axis=1)
  if logq is None:return float(np.mean(zp))
  # phi' is two below q, one on [q,2q], zero outside [q/2,2q].
  fac=np.where((logg>logq-np.log(2))&(logg<logq),2.,np.where((logg>=logq)&(logg<=logq+np.log(2)),1.,0.))
  return float(np.mean(zp*fac))
 upper=np.log(2.) if logq is None else min(np.log(2.),max(0.,(np.log(2.)-logq)/n))
 if upper==0:return 0.
 breaks=[0.,upper]
 if logq is not None:
  for loglevel in [logq,logq+np.log(2.)]:
   point=-loglevel/n
   if 0<point<upper:breaks.append(point)
 breaks=sorted(set(breaks));ans=0.
 for a,b in zip(breaks,breaks[1:]):
  ts=(a+b)/2+(b-a)*nodes/2
  ans+=(b-a)/2*float(np.dot(weights,[at(t) for t in ts]))
 return ans

def k1_integral(n,h,logq):
 # Conditional K=1 integral over V is exact; only outer logR quadrature is diagnostic.
 def fun(t):
  R=np.exp(t);prob=n*(h/R)*(1-h/R)**(n-1)
  vmax=min(1.,R/(2*h*n))
  if logq is None:return prob*(R/h*vmax-n*vmax*vmax)
  qscaled=np.exp(logq+n*t)
  ans=0.
  for lo,hi,weight in [(qscaled/2,qscaled,2.),(qscaled,2*qscaled,1.)]:
   lo=max(0.,lo);hi=min(vmax,hi)
   if hi>lo:ans+=weight*(R/h*(hi-lo)-n*(hi*hi-lo*lo))
  return prob*ans
 value,heuristic_error=quad(fun,0.,np.log(2.),epsabs=1e-9,epsrel=1e-9,limit=200)
 return {'value':value,'quad_error_estimate_not_certificate':heuristic_error}

def summary(vals):
 return {'mean':float(np.mean(vals)),'replicate_min':float(min(vals)),'replicate_max':float(max(vals)),'replicates':vals}

def main():
 start=time.perf_counter();sym=symbolic();rows=[];rawrows=[]
 seeds=[1701,2903]
 for n in [2,8,32,128]:
  for htag,h in [('1',1.),('1/n',1./n),('1/n^2',1./n**2)]:
   raw=[integrate(n,h,None,seed,12,16) for seed in seeds]
   ck(all(np.isfinite(x) and x>=0 for x in raw))
   rawrows.append({'n':n,'h':htag,'raw_logR_integral':summary(raw),'raw_over_n':float(np.mean(raw)/n)})
   for qtag,logq in [('2^-n',-n*np.log(2.)),('1',0.),('1.5^-n',-n*np.log(1.5))]:
    band=[integrate(n,h,logq,seed,12,16) for seed in seeds]
    ck(all(np.isfinite(x) and 0<=x<=2*max(raw)*1.5 for x in band))
    rows.append({'phase':'initial/moderate + shrinking-h pressure + expanded-n','n':n,'h':htag,'q':qtag,'logq':float(logq),'lambda_over_q':2,'band_logR_integral':summary(band),'band_over_raw':float(np.mean(band)/np.mean(raw)),'band_over_n':float(np.mean(band)/n)})
 refine=[]
 for htag,h in [('1',1.),('1/n',1./128),('1/n^2',1./128**2)]:
  band=[integrate(128,h,-128*np.log(1.5),s,13,32) for s in [1701,2903,4111,5821]]
  old=next(r for r in rows if r['n']==128 and r['h']==htag and r['q']=='1.5^-n')
  ck(all(np.isfinite(x) and x>=0 for x in band))
  refine.append({'n':128,'h':htag,'q':'1.5^-n','samples_per_replicate':8192,'order_per_interval':32,'band_logR_integral':summary(band),'initial_mean':old['band_logR_integral']['mean'],'refined_minus_initial':float(np.mean(band)-old['band_logR_integral']['mean'])})
 rare=[]
 for n in [2,8,32,128]:
  h=1./n**2
  bands=[]
  for qtag,logq in [('2^-n',-n*np.log(2.)),('1',0.),('1.5^-n',-n*np.log(1.5))]:
   bands.append({'q':qtag,'K1':k1_integral(n,h,logq)})
  rare.append({'n':n,'h':'1/n^2','raw_K1':k1_integral(n,h,None),'raw_analytic_lower':'n*log(2)-1','raw_analytic_lower_arb':str(n*arb(2).log()-1),'band_K1':bands,'band_Kge2_integral_upper_exact':str(Fraction(n-1,n)), 'full_band_upper_exact':'3*log(2)+(n-1)/n','full_band_upper_arb':str(3*arb(2).log()+arb(n-1)/n),'bound_scope':'analytic rigorous family bound; K1 outer quadrature diagnostic, not certified interval'})
 out={'scope':'actual continuous uniform source cube; g-weighted Sobol/quadrature diagnostic; no rigorous numerical errorbar, arbitrary-f bound, history or root theorem','environment':{'executable':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'command':f'{sys.executable} r504_numeric.py','checks':checks,'checks_meaning':'ten symbolic identities/guards plus nonnegativity/finite-value guards, not sample count or confidence claims','symbolic':sym,'settings':{'initial_samples_per_replicate':4096,'initial_replicates':2,'initial_order_per_interval':16,'initial_seeds':seeds,'refinement_seeds':[1701,2903,4111,5821],'integration':'dlogR on R[1,2]; exact max-density cuts; Gauss-Legendre in each subinterval','randomness':'scrambled Sobol deterministic given recorded seeds; across-R common point sets','error':'replicate ranges and selected refinement differences only; no variance CI because edge inverse-square moment diverges'},'raw':rawrows,'cases':rows,'selected_refinement':refine,'rare_edge_guard':rare,'diagnostic_warning':'Initial n128 h1/n^2 q1.5^-n estimate exceeds analytic upper; refined estimate is below separately quadrature-estimated K1 contribution. Neither Sobol/refinement nor quad error estimates are rigorous certificates.','compute_index':{'seconds':time.perf_counter()-start}}
 (ROOT/'r504_numeric.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print(f'PASS {checks} symbolic/finite-value guards;36 initial band cases +3 selected refinements;diagnostic only')
 for r in rawrows:
  subset=[x for x in rows if x['n']==r['n'] and x['h']==r['h']]
  print(r['n'],r['h'],'raw',format(r['raw_logR_integral']['mean'],'.7g'),'band',[round(x['band_logR_integral']['mean'],7) for x in subset])
 print('refined',[(r['h'],r['band_logR_integral']['mean'],r['refined_minus_initial']) for r in refine])
if __name__=='__main__':main()
