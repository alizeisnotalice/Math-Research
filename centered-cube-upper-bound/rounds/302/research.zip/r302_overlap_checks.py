#!/usr/bin/env python3
"""R302 exact finite overlap splitting on true FIRST-coupled positive-cell models."""
import json,random,hashlib,sys
if hasattr(sys,"set_int_max_str_digits"):sys.set_int_max_str_digits(0)
from fractions import Fraction as F
from pathlib import Path
R=random.Random(30120261018);COUNTS={};FAIL=[]
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'data':data})
def cellvol(h,n):return F(2*h,32)**n
def make(name,n,kind):
 if kind=='disjoint':
  X=[(0,0),(128,0),(256,0)];eh=[1,2,1];ls=[32]*3;rs=[32]*3
  Y=[(v,4) for v in [4,132,260,452]];Z=list(Y)
 elif kind=='chain':
  X=[(-16,0),(0,0),(16,0)];eh=[1,2,1];ls=[32,48,64];rs=[32,32,48]
  Y=[(v,4) for v in [-28,-12,4,20,36,100]];Z=list(Y)
 else:
  X=[(0,0),(16,0),(0,16),(16,16)];eh=[1,2,2,1] if n>=8 else [1,2,1,2]
  ls=[32,48,64,32];rs=[48,32,64,48]
  if kind=='tied':ls=rs=[32]*4
  Y=[(x,y) for x in [-12,4,20,36] for y in [-12,4,20,36]]
  Z=[(-12,-12),(4,4),(20,4),(4,20),(20,20),(36,20),(100,100)]
 if n==1:X=[[x] for x,y in X];Y=[[x] for x,y in Y];Z=[[x] for x,y in Z]
 else:X=[list(v)+[0]*(n-2) for v in X];Y=[list(v)+[4]*(n-2) for v in Y];Z=[list(v)+[4]*(n-2) for v in Z]
 def incidence(points,sides,label):
  A=[]
  for i,(x,s,h) in enumerate(zip(X,sides,eh)):
   row=[]
   for j,z in enumerate(points):
    inside=all(2*(abs(a-b)+h+1)<=s for a,b in zip(x,z));outside=any(2*(abs(a-b)-h-1)>s for a,b in zip(x,z))
    ck(inside or outside,label,{'case':name,'receiver':i,'source_cell':j});row.append(int(inside))
   A.append(row)
  return A
 soft=incidence(Y,ls,'exact_soft_pair_whole_inside_or_outside');hard=incidence(Z,rs,'exact_hard_pair_whole_inside_or_outside')
 for tag,points,hs in [('E',X,eh),('Y',Y,[1]*len(Y)),('Z',Z,[1]*len(Z))]:
  ck(all(any(abs(z[k]-w[k])>=hs[j]+hs[l] for k in range(n)) for j,z in enumerate(points) for l,w in enumerate(points[:j])),'positive_cells_disjoint_'+tag,{'case':name})
 vol=[cellvol(h,n) for h in eh];L=[F(s,32) for s in ls];rr=[F(s,32) for s in rs]
 br=[F(R.randint(1,10),R.randint(1,10)) for _ in Y];vr=[F(R.randint(1,10),R.randint(1,10)) for _ in Z]
 bresp=[sum(v*a for v,a in zip(br,row))/l**n for row,l in zip(soft,L)];bscale=1/max(bresp);beta=[bscale*v for v in br]
 vresp=[sum(v*a for v,a in zip(vr,row))/r**n for row,r in zip(hard,rr)];vscale=4/max(vresp);nu=[vscale*v for v in vr]
 first=[sum(v*a for v,a in zip(beta,row))/l**n for row,l in zip(soft,L)];hardresp=[sum(v*a for v,a in zip(nu,row))/r**n for row,r in zip(hard,rr)]
 for i,(f,h) in enumerate(zip(first,hardresp)):
  ck(f<=1,'actual_FIRST_q1',{'case':name,'receiver':i,'response':str(f)})
  ck(h<=4,'actual_same_radius_hardcap_lambda1',{'case':name,'receiver':i,'response':str(h)})
 I=[sum(vol[i]*soft[i][j]/L[i]**n for i in range(len(X))) for j in range(len(Y))]
 pi=[[vol[i]*soft[i][j]/L[i]**n/ij if ij else F(0) for i in range(len(X))] for j,ij in enumerate(I)]
 ck(sum(b*ij for b,ij in zip(beta,I))==sum(v*f for v,f in zip(vol,first))<=sum(vol),'FIRST_integrated_rowI_identity',{'case':name})
 return {'name':name,'n':n,'X':X,'Ehalf':eh,'Y':Y,'Z':Z,'L':L,'R':rr,'soft':soft,'hard':hard,'vol':vol,'beta':beta,'nu':nu,'first':first,'hardresp':hardresp,'I':I,'pi':pi}

def shell(n):
 delta=F(1,100*n);m=4*n;rr=[1+F(i,m) for i in range(m+1)];vol=[];prev=F(0)
 for r in rr:
  v=(r-2*delta)**n;vol.append(v-prev);prev=v
 ck(all((r-2*delta)/2+delta==r/2 for r in rr),'shell_actual_full_source_inclusion',{'n':n})
 return {'name':'concentric_shell_n'+str(n),'n':n,'vol':vol,'L':rr,'R':rr,'soft':[[1] for r in rr],'hard':[[1] for r in rr],'beta':[F(1)],'nu':[F(4)],'first':[r**(-n) for r in rr],'hardresp':[4*r**(-n) for r in rr],'geometry':{'type':'centered_disjoint_shells','delta':delta,'m':m,'source_side':2*delta,'source_center':0,'receiver_shell_sides':'E0=Q_(1-2delta); Ei=Q_(Li-2delta) minus Q_(L_(i-1)-2delta); Li=Ri=1+i/m'}}

def verify(c):
 n=c['n'];name=c['name'];radii=sorted(set(c['R']+[F(2)]));weights=[r**(-n)-(radii[k+1]**(-n) if k+1<len(radii) else 0) for k,r in enumerate(radii)]
 layers=[];Wbeta=sum(c['beta']);Wnu=sum(c['nu']);Cmenu=sum(w*r**n for w,r in zip(weights,radii))
 for i,(f,h) in enumerate(zip(c['first'],c['hardresp'])):ck(f<=1 and h<=4,'true_FIRST_and_sameR_caps',{'case':name,'receiver':i})
 for j,beta in enumerate(c['beta']):
  u=[v*c['soft'][i][j]/c['L'][i]**n for i,v in enumerate(c['vol'])]
  for r,w in zip(radii,weights):
   ids=[i for i,rr in enumerate(c['R']) if rr<=r];J=sum((u[i] for i in ids),F(0));A=[sum((u[i]*c['hard'][i][z] for i in ids),F(0)) for z in range(len(c['nu']))];M1=sum(v*a for v,a in zip(c['nu'],A))
   # Direct pair definition, separate from the moment identity.
   Q=F(0)
   for t,i in enumerate(ids):
    for k in ids[:t]:
     distance=sum(v*abs(c['hard'][i][z]-c['hard'][k][z]) for z,v in enumerate(c['nu']))
     if distance:Q+=u[i]*u[k]*distance
   ck(Q==J*M1-sum(v*a*a for v,a in zip(c['nu'],A)),'exact_direct_Qpair_equals_moment_gap',{'case':name,'row':j,'r':str(r)})
   ck(Q>=0 and all(0<=a<=J for a in A),'exact_overlap_ranges',{'case':name,'row':j})
   ck(M1<=4*sum(u[i]*c['R'][i]**n for i in ids),'exact_layer_source_cap_ledger',{'case':name,'row':j})
   layers.append({'j':j,'r':r,'w':w,'beta':beta,'J':J,'A':A,'M1':M1,'Q':Q})
 for r,w in zip(radii,weights):
  for z in range(len(c['nu'])):
   coupled=sum(l['beta']*l['A'][z] for l in layers if l['r']==r)
   ck(coupled<=r**n,'exact_FIRST_coupled_column_volume_bound',{'case':name,'r':str(r),'z':z})
 totalM1=sum(l['beta']*l['w']*l['M1'] for l in layers)
 ck(totalM1<=Cmenu*Wnu,'exact_discrete_An_replacement_without_Wbeta',{'case':name})
 js=sorted(set(l['J'] for l in layers if l['J']));mid=js[len(js)//2]
 Hs=sorted(set([F(1,16),F(1),F(16),js[0],mid,js[-1],mid*F(99,100),mid*F(101,100)]));records=[]
 for d in [F(1,16),F(1),F(16)]:
  O=F(0)
  for l in layers:
   clip=sum(v*min(d,a) for v,a in zip(c['nu'],l['A']));l['clip']=clip;O+=l['beta']*l['w']*clip
   bound=min(l['M1'],(d*l['M1']+l['Q'])/l['J']) if l['J'] else 0
   ck(clip<=bound,'exact_single_layer_clipped_overlap_inequality',{'case':name,'d':str(d),'row':l['j'],'r':str(l['r'])})
  for H in Hs:
   small=sum(l['beta']*l['w']*l['clip'] for l in layers if l['J']<H)
   smallM1=sum(l['beta']*l['w']*l['M1'] for l in layers if l['J']<H)
   large=sum(l['beta']*l['w']*l['clip'] for l in layers if l['J']>=H)
   BH=sum(l['beta']*l['w']*l['Q']/l['J'] for l in layers if l['J']>=H)
   ck(small+large==O,'exact_atomic_branch_partition',{'case':name,'H':str(H),'d':str(d)})
   if H in js:ck(any(l['J']==H and l['J']>=H for l in layers),'exact_H_equals_J_atom_in_large_branch',{'case':name,'H':str(H),'d':str(d)})
   largeM1=sum(l['beta']*l['w']*l['M1'] for l in layers if l['J']>=H)
   ck(small<=smallM1<=4*H*Wbeta,'exact_small_J_layer_global_budget',{'case':name,'H':str(H),'d':str(d)})
   for j,beta in enumerate(c['beta']):
    rowSmall=sum(l['w']*l['M1'] for l in layers if l['j']==j and l['J']<H)
    ck(rowSmall<=4*H,'exact_small_J_per_source_row_budget',{'case':name,'row':j,'H':str(H)})
   ck(large<=d/H*largeM1+BH,'exact_large_J_overlap_split',{'case':name,'H':str(H),'d':str(d)})
   rhs=4*H*Wbeta+d/H*Cmenu*Wnu+BH
   ck(O<=rhs,'exact_full_global_overlap_split',{'case':name,'H':str(H),'d':str(d)})
   records.append({'d':d,'H':H,'H_equals_some_positive_J':H in js,'O':O,'small_J_cost':small,'large_J_cost':large,'B_H':BH,'global_RHS':rhs,'O_over_RHS':O/rhs})
 geometry=c.get('geometry',{'coordinate_denominator':32,'receiver_centers_num':c['X'],'receiver_halfwidth_num':c['Ehalf'],'beta_centers_num':c['Y'],'nu_centers_num':c['Z'],'source_halfwidth_num':1}) if 'geometry' not in c else c['geometry']
 return {'name':name,'n':n,'receiver_count':len(c['vol']),'beta_rows':len(c['beta']),'nu_cells':len(c['nu']),'Wbeta':Wbeta,'Wnu':Wnu,'Cmenu':Cmenu,'total_layer_linear_traffic':totalM1,'geometry':geometry,'L':c['L'],'R':c['R'],'receiver_volumes':c['vol'],'beta_masses':c['beta'],'nu_masses':c['nu'],'soft_incidence':c['soft'],'hard_incidence':c['hard'],'layer_count':len(layers),'zero_J_layers':sum(not l['J'] for l in layers),'positive_Qpair_layers':sum(l['Q']>0 for l in layers),'max_J':max(js),'records':records}
def encode(x):
 if isinstance(x,F):return str(x)
 raise TypeError(type(x).__name__)
settings=[('initial',[('disjoint_n1',1,'disjoint'),('overlap_chain_n1',1,'chain')]),('atomic_H_boundary',[('cross_n4',4,'cross'),('tied_n4',4,'tied')]),('expanded',[('cross_n8',8,'cross'),('cross_n16',16,'cross')])]
stages=[{'name':stage,'cases':[verify(make(name,n,kind)) for name,n,kind in specs]} for stage,specs in settings]
stages[-1]['cases'] += [verify(shell(n)) for n in [16,32]]
out={'status':'PASS' if not FAIL else 'FAIL','scope':'Exact Fraction diagnostics only on genuine positive-volume cell/shell source and receiver models with actual s=0 kernels and FIRST<=1,same-radius hardresponse<=4. Original full maximal-hardcap and low-m/e_g histories are not implemented. No abstract incidence model is included. No general dimension-order or FULL closure claim.','layer_definition':'For fixed beta row j,r: u_i=|Ei|Li^-n soft_ij, restrict Ri<=r; J=sumu,A_z=sumu_i hard_iz,M1=sum nu_z A_z; Qpair=1/2 sum_ik u_i u_k sum_z nu_z |c_iz-c_kz|. w_r=r^-n-next^-n, endpoint b^-n, b=2.','full_split':'O=sum_j,r beta_j w_r sum_z nu_z min(d,A_z) <=4H Wbeta +(d/H) Cmenu Wnu+B_H; Cmenu=sum_r w_r r^n; B_H=sum_(J>=H)beta_j w_r Qpair/J. Equality J=H belongs to large branch.','why_no_Wbeta_in_middle_term':'FIRST<=1 gives sum_j beta_j A_jz(r)<=r^n for every z, so sum beta_j w_r M1_j(r)<=Cmenu Wnu.','seed':30120261018,'check_counts':COUNTS,'failures':FAIL,'stages':stages}
base=Path(__file__);base.with_suffix('.json').write_text(json.dumps(out,default=encode,sort_keys=True,indent=2)+'\n')
lines=['# R302 exact overlap splitting diagnostics','',out['scope'],'',out['full_split'],'',out['why_no_Wbeta_in_middle_term'],'','|model|n|layers|positive Q layers|max J|best tested O/RHS|','|---|---:|---:|---:|---:|---:|']
for s in stages:
 for c in s['cases']:lines.append(f"|{c['name']}|{c['n']}|{c['layer_count']}|{c['positive_Qpair_layers']}|{float(c['max_J']):.6g}|{float(max(x['O_over_RHS'] for x in c['records'])):.6g}|")
lines += ['','All comparisons are exact Fraction. H menus include positive cumulative atoms exactly, plus adjacent 99%/101% values. d=1/16,1,16. Whole-cell geometry and frozen source masses are retained in JSON; cells are uniform L1 densities, not point masses. Repeated real-cell generation logic is copied into this standalone script; frozen earlier scripts are not imported or modified.']
base.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':out['status'],'counts':COUNTS,'failures':FAIL,'cases':[{'name':c['name'],'max_J':float(c['max_J']),'positive_Qpair_layers':c['positive_Qpair_layers']} for s in stages for c in s['cases']]},indent=2));assert not FAIL,FAIL
