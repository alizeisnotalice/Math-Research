# R302 independent proposition screen

Own only /tmp/r302_scale_audit.md; no R302 author proof was read before saving this independent screen. This concerns the AUXILIARY global separation kernel, not arbitrary original receiver-selected convolution. Physical 0<a<=b<infinity, n>=1 integer; fixed scale r in [a,b]. No source or outer ledger is implicitly paid.

## 1. Triangular scale envelope — PASS

Let tau(x)=(1-|x|)_+ and K_r(z)=r^-n product_i tau(z_i/r). Tau is a probability density. Under its law, Z=1-|X| has density 2z on (0,1). The dilation score is S=1/Z-2. It is integrable, ES=0, and its variance is infinite; a finite-variance estimate cannot be applied without truncation.

For B>=1 set T=1/Z and Y=min(T,B). Direct integration gives

    E Y=2-1/B,
    E Y^2=1+2 log B,
    Var(Y)=V(B)=2 log B-3+4/B-1/B^2>=0,
    E(T-B)_+=1/B.

Write sum_i S_i=sum_i(Y_i-EY_i)+sum_i[(T_i-B)_+-1/B]. Independence bounds the first absolute mean by sqrt(n V(B)); positivity and the exact tail mean bound the second by 2n/B. Since the full score sum has mean zero,

    E(sum_i S_i)_+ <=(1/2)[sqrt(n V(B))+2n/B].

For each fixed z, r->K_r(z) is continuous and absolutely continuous on [a,b]. Each triangular factor has only finitely many derivative breakpoints and vanishes continuously at its moving support face; there is no delta boundary term. For almost every r,z,

    partial_r K_r(z)=(K_r(z)/r)sum_i S_i(z_i/r),

with zero-density boundary values ignored. The absolute derivative is jointly integrable on the physical interval by the finite first score moment. Positive variation gives sup_r K_r<=K_a+integral_a^b(partial_r K_r)_+dr. Integrate and change variables to obtain precisely

    integral sup_(a<=r<=b) K_r(z)dz
       <=1+[log(b/a)/2][sqrt(n V(B))+2n/B].

Continuity allows the supremum over rational r plus endpoints, establishing measurability. The formula includes a=b and B=1. For B=sqrt(n), V(B)<=log n, so on b/a<=2 this is O(sqrt(n log(n+2))), with n=1 handled directly rather than a zero log asymptotic.

In fact for n=1 the exact envelope is 1+(1/2)log(b/a): on the positive ray the maximizing radius is clip(2z,a,b), so a direct three-interval integral gives that value. The proposed truncation bound is conservative and valid at n=1.

## 2. Fixed common softness convolution extension — PASS

Define w(t)=integral_0^1 exp(-|t|/u)du. It is normalized because integral_R w=integral_0^1 2u du=1. Equivalently it is the Laplace(scale u) probability mixture with mixing density 2u du. For one FIXED s in [0,1], let g_s=tau*((1-s)delta_0+s w), and tensorize/dilate the same g_s in all n coordinates.

A rigorous latent model uses independent triangular X_i, independent Bernoulli(s) flags, and when active independent U_i with density 2u and Laplace(scale U_i) noise Y_i; inactive noise is the scale-invariant zero atom. Dilation of the full latent pair (X_i,noise_i) has score S_i plus the active-noise score |Y_i|/U_i-1. The latter is centered with variance s because |Y_i|/U_i is Exp(1). The n-coordinate latent score therefore has absolute mean at most

    sqrt(n V(B))+2n/B+sqrt(n s).

The observed Z_i=X_i+noise_i dilation density is g_s, and its marginal derivative is the conditional projection/integral of the latent derivative. Positive-part/L1 contraction gives the same positive-variation envelope bound. The explicit safe result is

    integral sup_r r^-n product_i g_s(z_i/r)dz
       <=1+[log(b/a)/2]
                 [sqrt(n V(B))+2n/B+sqrt(n s)]
       <=1+[log(b/a)/2]
                 [sqrt(n V(B))+2n/B+sqrt(n)].

The zero-noise stratum contributes no extra dimension/Jacobian score; Laplace mixing parameters are not receiver-selected. Joint latent absolute derivative integrability and the continuous observed dilation curves justify derivative integration and the rational-scale measurable supremum. The bound includes s=0,1 and n=1.

## 3. Quantifiers and forbidden transfers

The extension is for EACH fixed COMMON s. A uniform constant in s does not bound the integral of a supremum over s, nor any field in which s is independently selected by the integration receiver. The scale supremum here acts on the actual globally translated separation kernel with one common scalar r; it is not automatically an arbitrary selected convolution of original responses, a source-weighted endpoint theorem, or a payment of the full original traffic. Any original kernel domination, common-selector reduction, actual cap/FIRST transfer, source ledger and outer factors must be proved independently. No density/source-order assumption or missing original qualification has been supplied by this lemma.

## 4. Actual bounded diagnostics

An actual local mpmath run at 50 digits checked the mean/variance integrals for B=1,1.25,2,10,1000; four exact n=1 scale-envelope integrals for b/a=1,1.25,1.5,2; and centered Laplace score mean/variance. All passed at 1e-45 tolerance. These are finite numerical diagnostics, separate from the strict analytic moment/variation derivation above. No author proof was read before this screen, and no other files or Git were changed.

Independent verdict: PASS for both stated auxiliary envelope bounds with the exact fixed-s and scale-selector scope above. Await author proof for bounded comparison and hash receipt; no original global closure follows from this screen.

## 5. Additional independent global disagreement-budget screen

Before reading the new author proof, screened the following original-field mechanism. Let U_y be a legitimate original z-independent row weight, mu_y its pushforward by R, J_y(r)=mu_y([a,r]), A_yz(r) its cumulative capture, M_y(r)=integral A_yz(r)nu(dz), and ell(dr)=b^-n delta_b(dr)+n r^-n-1 dr. For J>0 and 0<=A<=J,

    min(d,A)<=(d/J)A+A(1-A/J).

For A<=d the excess is A(d-A)/J>=0; for A>=d it is (A-d)(1-A/J)>=0. Positive Tonelli over two actual receiver indicators gives the EXACT disagreement identity

    Q_y(r)=(1/2)integral_{Ru,Rv<=r}U_y(u)U_y(v)
                          nu(Q_Ru(u) symmetric_difference Q_Rv(v))du dv
          =J_y(r)M_y(r)-integral A_yz(r)^2 nu(dz)>=0.

For H>0 put B_H=integral beta(dy)ell(dr)1{J_y(r)>=H}Q_y(r)/J_y(r), with the zero-J ratio set to zero outside this high gate. Then the clipped cost O_d satisfies

    O_d<=4lambda H W_beta+(d/H)A_n W_nu+B_H,
    A_n=1+n log(b/a).

The low-J proof uses SAME-radius original hardcaps M(r)<=4lambda integral_[a,r]s^n mu(ds). Positive exchange gives an inner ell([s,b])=s^-n. If J(s)>=H, the strict low gate is empty for every r>=s. Otherwise use this full inner mass; then mu{s:J(s)<H}<=H. Thus a large CDF atom crossing H is excluded whole from the low side, and contributes only to the high side. No continuous-CDF assumption, open-endpoint shortcut, or missing terminal atom is used.

For the high first term, original FIRST exactly gives integral beta ell M=integral_E f(x)(h_R*nu)(x)dx<=A_n W_nu. Hence the d/H term has one shared source fee. The balanced threshold H=sqrt(d A_n/(4lambda)) yields

    O_d<=2sqrt(lambda d A_n)(W_beta+W_nu)+B_H,
    ORIGINAL T_target<=4sqrt(lambda d A_n)(W_beta+W_nu)+2B_H

using the independently screened R301 common-rate oracle T<=2O_d. This threshold balances the two coefficients; it need not minimize the expense for a particular unequal source-mass pair. B_H is the true nonnegative double-receiver symmetric-difference fee and is bounded by A_n W_nu, but no root-order bound for it is established. The original target aspect and outer ledgers remain. Verdict: PASS, including atoms, terminal layer and source quantifiers; no global closure claim.

## 6. Additional independent full-soft pair-envelope screen

For the previously defined full common-soft positive profile Q_n=sum_k a_nk Q_k, assume the already established shape definition: each Q_k is a probability mixture of tensor products of h=1_[-1/2,1/2] and phi=h*w, with all coefficients nonnegative and total mass Csoft<=1+(pi/2)sqrt(n). Every coordinate density is a probability with height <=1. These are the actual original soft shapes; no arbitrary density is substituted.

Let mu(dL)=delta_b(dL)+n 1_[a,b](L)dL/L, K=integral Q_L mu(dL), H=integral h_R mu(dR), A_n=mu([a,b]). The ray-nonincreasing profile scale envelope supplies a common positive majorant for actual selected soft/hard kernels. At a fixed scale pair every tensor coordinate overlap is <=min(1/L,1/R)=1/max(L,R). Therefore

    (K*H)(delta)<=Csoft integral integral max(L,R)^-n mu(dL)mu(dR)
                   =Csoft(2a^-n-b^-n).

The equality includes both b atoms: the continuous double triangle contributes 2[a^-n-b^-n(1+n log(b/a))], the two endpoint cross terms contribute 2n b^-n log(b/a), and the atom pair contributes b^-n. Thus no A_n^2 point-height fee is needed.

For the actual clipped pair oracle J_d(y,z)=integral ell(dr)min(d,A_yz(r)), both positivity bounds are valid:

    J_d(y,z)<=min(d a^-n, q_-^-1(K*H)(z-y)).

The first uses ell total mass a^-n. The second uses the actual U<=p/q_- bound, removes the admissible row restriction positively, applies the common full-soft profile envelope and hard scale envelope BEFORE convolution, and retains the original finite physical scale endpoints. This is an upper majorant, not an equality for arbitrary receiver-selected scales.

The distance refinement is also valid with these actual shapes. If |delta_i|>b, a hard-hard coordinate overlap vanishes. For a soft coordinate phi_L=h_L*w_L, write the overlap with h_R either as 1/L or as 1/R times a probability involving the OTHER hard uniform plus the same noise W_L. The overlap event forces W_L>=s=|delta_i|-(L+R)/2>=|delta_i|-b (or the symmetric negative tail). The normalized w_L noise has tail

    P(W_L>=s)=integral_0^1 u exp(-s/(Lu))du
                       <=(1/2)exp(-s/L)
                       <=(1/2)exp[-(|delta_i|-b)/b].

Taking both prefactors gives the coordinate bound [2max(L,R)]^-1 exp[-(|delta_i|-b)/b]. Tensoring yields the additional factor 2^-m exp(-D), where m counts coordinates |delta_i|>b and D=sum_i(|delta_i|-b)_+/b. Positive shape mixing and double-scale integration preserve it, multiplying the preceding Csoft(2a^-n-b^-n) bound.

The L1 mass of K*H remains A_n^2 Csoft. Neither its improved amplitude nor the distance factor pays its integral against arbitrary original beta(dy)nu(dz). All source convolution, concentration and outer fees remain. This statement was independently screened before reading the new author pair-kernel proof; no global closure follows.

## 7. Scale author-file comparison — PASS

Read /tmp/r302_scale_geometry.md after the independent screen. Its exact triangular moments, heavy-tail truncation, centered latent noise variance ns, signed derivative projection and positive-variation factor one-half agree with the independent derivation. Moving triangular support faces have no first-derivative atoms because the density vanishes continuously; L1 product differentiation and mixing are integrable even as latent Laplace scale tends to zero. The explicit continuous kernels justify the countable measurable scale supremum and the almost-everywhere AC representative. The stated slightly weaker B=sqrt(n) simplification is valid at n=1. No correction is needed.

The fixed equal-scale pair convolution representation is exact for the original P_s,r, but the author explicitly preserves the receiver-selection and arbitrary-source-integration gaps. It correctly bounds a partitioned receiver menu by a sum of fixed convolutions, not their supremum. The global separation-space envelope is not treated as an original full-source theorem.

Provisional scale-proof SHA256: 346f9cb3adad4d5c0a208ade073aecda90486da11afe25d2d90b832c02f99543

## 8. Global disagreement author-file comparison — PASS

Read /tmp/r302_geometry.md after the independent screen. Its clip/overlap identity, strict low-cumulative-layer proof and high-layer shared FIRST budget agree exactly with the independently derived argument, including all CDF atoms and the terminal ell atom. The source-balanced H* yields 4sqrt(lambda d A_n W_beta W_nu) and correctly evaluates B at that SAME threshold; the text explicitly optimizes only the two source terms, not the retained boundary fee. Zero source cases avoid division.

The added quantitative large-J disagreement alternative follows directly by rearranging (9). The pairwise agreement sufficient condition integrates to Q<=epsilon JM with no missing factor two. The symmetric-difference boundary-layer inclusion (18) is valid by the infinity-distance triangle inequality in both membership directions; it does not turn source mass into volume. The receiver-budget substitution gives H=16d coefficient 1/2 exactly, with original finite matching entry still required. B_H<=F1 is only a coarse bound and is not promoted to root order. All aspect and outer fees remain. No correction is required.

Global disagreement proof SHA256: a66a045f1917a426e816ca137607290090bd40865c6309e5e25be3a795916d6e

## 9. Pair-kernel author-file comparison — PASS

Read final /tmp/r302_pair_kernel.md. Its two actual selector envelopes, positive full-common-soft profile and exact double-scale normalization agree with the independent screen. The stronger forced-soft coefficient C_(n,m) is the exact subset coefficient: C_(n,1)=Csoft/2 follows from symmetry, C_(n,n)=1, and monotonicity follows from imposing more specified coordinates. Both one-sided soft-coordinate overlap bounds are valid, using actual phi=h*w and the normalized one-sided noise tail; tensoring and positive shape/scale mixing prove (8). The extra C_(n,1) factor justifies the sharper Csoft/(2a^n) far amplitude in (13). The integrated far tail (9) is a Lebesgue probability/union bound and is correctly not a source-weighted endpoint result.

The direct actual traffic estimate (2) uses both receiver-dependent selector envelopes before extending dx. Its light-local-column price (3) needs NO Poisson factor two: the frozen near-column beta mass condition b_D(z)<=q_-a^n L0 cancels the amplitude/q_- directly, giving Csoft[2-(a/b)^n]L0 nu(Z_light). The exact far/near-heavy complement remains. The clipped pair upper kernel first clips the layer majorant a_r and only then integrates r; its two upper bounds in (12) have the correct direction. No arbitrary-source integration fee is inferred from its root point amplitude or L1 mass. No correction is required.

## 10. Final README and evidence integration — PASS and frozen

Read final /tmp/r302_README.md. Its global root-priced source contributions, true remaining B_H, threshold/source-mass-balanced qualifications, direct light-column condition/price, fixed-common-softness auxiliary scope, source/selector bridges and original aspect/outer gaps match all three proofs. It does not label B_H as an already paid original traffic allocation or infer arbitrary-source root price from point amplitude. No final formula/scope correction is needed.

Inspected frozen evidence outputs: overlap JSON is PASS with no failures and count sum 6011, including 396 direct disagreement identities, 186 global splits and 72 exact H=J branch checks. Its eight true positive-cell/shell models retain their stated actual FIRST/same-radius caps, while original full histories and all-radius maximal qualifications are not inferred. Scale numeric JSON has PASS, no failures, 25 checks and exactly 196608 generated samples; it expressly treats boundedized intervals as nominal iid/PRNG diagnostics, states raw infinite variance, and does not claim an ordinary raw standard-error or interval-certified result. Main JSON records 34 PASS checks at 60 digits and 1e-45 comparison tolerance, explicitly not interval arithmetic. Parent reports actually rerunning these scripts and the extracted geometry 24/264/108/108 and pair 6 scale/6 exact coefficient/27 actual-phi checks; their reproducible script bytes and embedded proof evidence are bound below. Auditor did not repeat those full runs. The auditor independently executed the five exact-moment quadratures, four n=1 envelope integrals and two Laplace moment checks documented in Section 4. Numerical diagnostics remain separate from analytic proof and do not certify a dimension exponent.

Final SHA256 bindings (superseding any earlier provisional binding):
- /tmp/r302_README.md: e925efb74698401f355ad6d5e26d3b2155d88330560f84610732fa9d8fba8521
- /tmp/r302_scale_geometry.md: 346f9cb3adad4d5c0a208ade073aecda90486da11afe25d2d90b832c02f99543
- /tmp/r302_geometry.md: a66a045f1917a426e816ca137607290090bd40865c6309e5e25be3a795916d6e
- /tmp/r302_pair_kernel.md: 65550dced7d5a047d89becd070a43ba674f1467bfb5b2a3491724085611419e4
- /tmp/r302_main_checks.py: da31a56510497b2574201aef139e2afc93c82ff01516d104205091e71abc087e
- /tmp/r302_main_checks.json: 21acf0f6700fc38cc1e38917d2e67b0578a127f687816663b80e4a150247029d
- /tmp/r302_scale_numeric.py: 6de8464a6f3fd7511d5009c185c081e23a781b4ba801b626c8facff6f30a7c61
- /tmp/r302_scale_numeric.json: c55a524df8174dddf983ac097a54136787e491421d53326807bf1024a4d7b9ca
- /tmp/r302_scale_numeric.md: 125388434a7cdfd7da87028c6f4cc64bff1a13cf70f1fb49d9039578dca6ac66
- /tmp/r302_overlap_checks.py: 84fac8cf481983d67cb89c948d70317b877fa8d420411c185e95d59bece882fd
- /tmp/r302_overlap_checks.json: f9a31b4693a50706ad335f4d099a9cc24b58bad74ca7ca0e868ffe78ece35420
- /tmp/r302_overlap_checks.md: 9efdeabbfd80569bf5df6d720c84c0c34974145339eed12b0eb6ebbdb6eb3b07
- /tmp/r302_geometry_checks.py: 23612de9c609dc00a2ea62132eee4be1cc553ba3726ec109cecbea9da84e246c
- /tmp/r302_pair_checks.py: a8e3cba9908453d4496b9a5208f817059383c338b85288743977488fc7a544c8

Final bounded verdict: PASS. The general original-input root bound for the high-cumulative-row source-weighted disagreement fee B_H, the near-heavy/far source costs beyond the explicit light regime, the arbitrary receiver-selector/source-integration bridges for the auxiliary fixed-s envelope, extreme aspect complement and original outer/history/clock ledgers remain unproved. No source density/order premise or free independent softness/selector replacement was introduced. Audit frozen; no repository/Git/PDF or other author file changed.
