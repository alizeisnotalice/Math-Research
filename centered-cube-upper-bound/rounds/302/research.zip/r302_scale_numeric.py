#!/usr/bin/env python3
"""R302 bounded tensor-overlap dilation-score diagnostics; standard-library sampling."""
import math,random,json,sys
from pathlib import Path
from fractions import Fraction as F
try:import mpmath as mp
except ImportError:
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
 import mpmath as mp
CHECKS={};FAIL=[];SEED=30220261018;BATCHES=8;PER_BATCH=4096;M=BATCHES*PER_BATCH;DELTA=0.01/6

def check(ok,label,data):
 CHECKS[label]=CHECKS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'data':data})
def mm(x):return mp.mpf(x.numerator)/x.denominator

def case(n):
 root=math.isqrt(n);assert root*root==n
 T=32*root;tailprob=F(1,(T+2)**2);tailmean=F(2,T+2)-F(2,(T+2)**2);meanW=-F(1,T+2)
 vals=[]
 for dp in [40,60]:
  with mp.workdps(dp):
   m2=2*mp.log(T+2)+mp.mpf(8)/(T+2)-mp.mpf(4)/(T+2)**2-4
   direct=mp.quad(lambda s:2*s*s/(s+2)**3,[-1,0,1,T])
   check(abs(m2-direct)<mp.mpf('1e-32'),'truncated_second_moment_formula_vs_quad',{'n':n,'precision':dp})
   ew2=m2+mp.mpf(T*T)/(T+2)**2
   var=ew2-mm(meanW)**2
   bound=mp.sqrt(n*var)+2*n*mm(tailmean)
   vals.append((m2,ew2,var,bound))
 with mp.workdps(70):
  refinement=max(abs(a-b)/max(1,abs(b)) for a,b in zip(*vals))
  check(refinement<mp.mpf('1e-30'),'moment_40_60_refinement',{'n':n})
  m2,ew2,var,bound=vals[1]
  # The diagnostic sqrt(n log n) upper bound uses uncapped-at-T truncation:
  # E|sum S| <= sqrt(n Var(S 1_{S<=T}))+2n E[S 1_{S>T}].
  truncMean=-mm(tailmean);truncVar=m2-truncMean**2
  analytic=mp.sqrt(n*truncVar)+2*n*mm(tailmean)
  scale=mp.sqrt(n*mp.log(n+2));C=float(64*scale)
  bscore=mp.mpf(n)/(T+2)
  esumW2=n*ew2+n*(n-1)*mm(meanW)**2
  bcap=esumW2/(4*C)
 rng=random.Random(SEED+n);rawbatch=[];bounded=[];maxraw=0.0
 for batch in range(BATCHES):
  rawsum=0.0
  for _ in range(PER_BATCH):
   s=w=0.0
   for i in range(n):
    u=rng.random()
    # Resample exactly zero to avoid an artificial infinity from the discrete PRNG.
    while u==0:u=rng.random()
    x=1/math.sqrt(u)-2;s+=x;w+=min(x,T)
   y=abs(s);rawsum+=y;maxraw=max(maxraw,y);bounded.append(min(abs(w),C))
  rawbatch.append(rawsum/PER_BATCH)
 mean=sum(bounded)/M;sv=sum((x-mean)**2 for x in bounded)/(M-1)
 logterm=math.log(4/DELTA)
 radius=math.sqrt(2*sv*logterm/M)+7*C*logterm/(3*(M-1))
 low=max(0,mean-radius-float(bscore));high=mean+radius+float(bscore+bcap)
 raw=sum(rawbatch)/BATCHES
 if n==1:check(low<=1<=high,'n1_exact_absolute_mean_in_nominal_interval',{'interval':[low,high]})
 check(0<raw and 0<=mean<=C,'sample_sanity',{'n':n})
 with mp.workdps(60):
  return {'n':n,'samples':M,'batches':BATCHES,'seed':SEED+n,'T':T,'score_tail_probability_exact':str(tailprob),'score_tail_first_moment_exact':str(tailmean),'capped_score_mean_exact':str(meanW),'truncated_second_moment':mp.nstr(m2,50),'truncated_second_moment_over_log_T':mp.nstr(m2/mp.log(T),30),'analytic_truncation_upper_bound':mp.nstr(analytic,50),'upper_bound_over_sqrt_n_log_nplus2':mp.nstr(analytic/scale,30),'moment_relative_40_60_error':mp.nstr(refinement,12),'raw_sample_mean_absolute_sum':raw,'raw_batch_means':rawbatch,'raw_maximum_absolute_sum':maxraw,'raw_mean_over_sqrt_n':raw/math.sqrt(n),'raw_mean_over_sqrt_n_log_nplus2':raw/float(scale),'bounded_estimator_mean':mean,'bounded_range_C':C,'bounded_sample_variance':sv,'nominal_empirical_Bernstein_radius':radius,'score_cap_analytic_L1_bias_bound':float(bscore),'sum_cap_analytic_bias_bound':float(bcap),'nominal_iid_interval_for_true_L1':[low,high],'nominal_iid_interval_normalized_by_sqrt_n_log_nplus2':[low/float(scale),high/float(scale)]}
stages=[{'name':name,'cases':[case(n) for n in ns]} for name,ns in [('initial',[1,4]),('truncation_stress',[16,64]),('expanded',[256,1024])]]
out={'status':'PASS' if not FAIL else 'FAIL','scope':'Auxiliary pair kernel k_r(z)=r^-n product(1-|z_i|/r)_+. Its r derivative has L1 norm r^-1 E|sum S_i|. No general selector integration or full-source conclusion.','distribution':'U_i has density2(1-u),0<u<1; S=-1+u/(1-u)=1/sqrt(V)-2 for uniform V. Support[-1,infinity); tail P(S>x)=(x+2)^-2 for x>=-1. ES=0,E|S|=1,ES^2=infinity.','exact_truncation_formulas':'E[S 1{S>T}]=2/(T+2)-2/(T+2)^2; E[S^2 1{S<=T}]=2log(T+2)+8/(T+2)-4/(T+2)^2-4. Thus truncated second moment grows as2logT; using T comparable sqrt n gives an O(sqrt(n log n)) upper bound via centering/truncation, without establishing a matching lower bound here.','confidence_scope':'Fixed Python random seeds and floating inverse-CDF sampling. Raw estimator has infinite variance, so batch spread is descriptive and no raw standard-error CI is claimed. Displayed nominal 99% simultaneous six-case iid intervals use a bounded estimator Z=min(|sum min(S,T)|,C), two-sided empirical Bernstein bound with log(4/delta), delta=.01/6, plus deterministic bias bounds. This probabilistic interpretation assumes ideal iid uniforms; PRNG, quadrature and ordinary mpmath are not interval-certified.','bias_formula':'|E|sum S|-E|sum min(S,T)||<=n/(T+2). For Y=|sum min(S,T)|, E(Y-C)+<=E Y^2/(4C), E Y^2=n EW^2+n(n-1)(EW)^2.','sample_parameters':{'batches':BATCHES,'per_batch':PER_BATCH,'T':'32sqrt(n)','C':'64sqrt(n log(n+2))'},'check_counts':CHECKS,'failures':FAIL,'stages':stages}
base=Path(__file__);base.with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
lines=['# R302 tensor-overlap dilation-score diagnostics','','The actual local script ran three stages. These are auxiliary pair-kernel diagnostics; they do not justify general selector integration.','','For S=1/sqrt(V)-2, ES=0 and E|S|=1, but ES² is infinite. The exact truncated second moment is 2log(T+2)+8/(T+2)-4/(T+2)²-4. Centering the truncation with T proportional to sqrt(n) yields an O(sqrt(n log n)) upper bound. This run does not establish a matching lower bound.','','|n|raw mean|mean/sqrt(n)|mean/sqrt(n log(n+2))|nominal iid interval|analytic upper bound|','|---:|---:|---:|---:|---:|---:|']
for stage in stages:
 for c in stage['cases']:lines.append(f"|{c['n']}|{c['raw_sample_mean_absolute_sum']:.6g}|{c['raw_mean_over_sqrt_n']:.6g}|{c['raw_mean_over_sqrt_n_log_nplus2']:.6g}|[{c['nominal_iid_interval_for_true_L1'][0]:.6g}, {c['nominal_iid_interval_for_true_L1'][1]:.6g}]|{float(c['analytic_truncation_upper_bound']):.6g}|")
lines+=['',out['confidence_scope'],'','Each dimension uses 32768 draws in eight reproducible batches. Raw batch means and maxima, capped estimator, analytic bias terms, and 40/60-digit quadrature comparisons are in the JSON. Numerical samples are evidence only.']
base.with_suffix('.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'status':out['status'],'check_counts':CHECKS,'cases':[{k:c[k] for k in ['n','raw_sample_mean_absolute_sum','raw_mean_over_sqrt_n','raw_mean_over_sqrt_n_log_nplus2','nominal_iid_interval_for_true_L1','analytic_truncation_upper_bound']} for s in stages for c in s['cases']]},indent=2))
assert not FAIL,FAIL
