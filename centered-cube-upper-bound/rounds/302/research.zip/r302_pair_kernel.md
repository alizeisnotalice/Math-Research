# R302 — integrable pair localization with a root point amplitude

## 1. Precise theorem and actual source payments

Keep the exact original fields, row gate alpha(x,y), p_y=P_(s(x),L(x))(x-y), q>=q_-=3lambda/4, a<=L,R<=b, sources beta,nu and capture intensity A_yz(r) from /tmp/r301_common_rate.md. All original aspect, low/m and history qualifications stay on the left side. Put

    A_n=1+n log(b/a), Csoft_n=sum_(k=0)^n c_(n,k),
    c_(n,k)=max_(0<=s<=1) binom(n,k)s^k(1-s)^(n-k),
    Csoft_n<=1+(pi/2)sqrt(n).

There is an explicit nonnegative translation kernel P on R^n, defined in Section 2, with

    integral P=A_n^2 Csoft_n,
    P(delta)<=Csoft_n(2a^(-n)-b^(-n)).                   (1)

Thus its POINT amplitude has the root Csoft fee, with no A_n^2 amplitude. Its integrable mass still has A_n^2; that cost is not hidden.

For any measurable FROZEN pair allocation 0<=omega(y,z)<=1, the actual raw receiver traffic, with its old masks, obeys the direct estimate

    T_omega<=(1/q_-) integral omega(y,z)P(z-y)beta(dy)nu(dz). (2)

This uses actual dx and actual scale selectors before positive domination. It needs no new FIRST, no source density, no source ordering and no replacement posterior. It is valid in particular on the stated aspect-qualified branch, and even without that qualification. No additional aspect improvement is claimed for the upper envelope.

Here is a genuine paid local-mass branch on arbitrary original sources. Fix D>0, define

    b_D(z)=beta(Q_(2Db)(z)),
    Z_light={z:b_D(z)<=q_-a^n L0}, L0>=0,
    omega_light=1{|y-z|_infinity<=Db}1_(Z_light)(z).

Then (1)-(2) prove the actual source-linear receipt

    T_light<=Csoft_n[2-(a/b)^n]L0 nu(Z_light)
             <=2 Csoft_n L0 nu(Z_light).               (3)

So polylog L0 gives a root-polylog price, with full shared softness and actual selected scales. No assertion that all hard-source columns are light is made. The exact remaining original masks are the far pairs |y-z|_infinity>Db and the near pairs with b_D(z)>q_-a^n L0. Existing independently paid far estimates can be combined with this split, but are not reproved here. Splitting many allocations does not make their nu charges free.

A simpler global conditional receipt is: if W_beta<=q_-a^n L0, then the whole target obeys T<=2 Csoft_n L0 W_nu. It is a priced source-mass regime, not a universal mass assumption.

## 2. A legitimate two-selector envelope

Let h=1_[-1/2,1/2], phi=h*w be the ACTUAL R292 density, w(x)=integral_0^1 exp(-|x|/t)dt, and f_s=(1-s)h+s phi. For a subset S of coordinates let q_S be the product density using phi on S and h otherwise. Let q_k be the average of q_S over |S|=k, and define

    Q_n=sum_k c_(n,k)q_k.

The original common-s expansion is

    product_i f_s(u_i)=sum_k binom(n,k)s^k(1-s)^(n-k)q_k(u)
                       <=Q_n(u).                      (4)

Every q_k is a probability density, and Q_n is ray-decreasing with mass Csoft_n. This is one common-softness expansion; it is NOT a product of independently optimized coordinate softnesses.

For any nonnegative ray-decreasing profile Q, positive layer cake over its star-shaped superlevel sets gives the pointwise envelope

    sup_(a<=L<=b) L^(-n)Q(x/L)
       <=b^(-n)Q(x/b)+n integral_a^b L^(-n)Q(x/L)dL/L. (5)

For one indicator level, the right side is exactly the smallest admissible normalized scale at which that ray enters the level; integrating levels permits only an upper bound for a general Q. Thus (5) applies without a false smoothness or fixed-selector assumption.

Write

    mu(dL)=delta_b(dL)+n1_(a,b)(L)dL/L,
    K(x)=integral L^(-n)Q_n(x/L)mu(dL),
    H(x)=integral h_R(x)mu(dR),
    P=K*H.

Here H is the exact hard point-scale envelope, and mu has total mass A_n. Equations (4)-(5) give p_y(x)<=K(x-y) at every actual selected s,L, and h_(R(x))(x-z)<=H(x-z). Keep the old masks and q bound until these inequalities are applied, then extend dx positively. This proves (2). Nonnegative convolution gives integral P=A_n^2 Csoft_n.

The full costs of arbitrary receiver-dependent scale selection are the TWO positive mu measures. A fixed-scale convolution has not been substituted for the actual selector. Positive envelopes used outside E are not assigned FIRST or hard caps there.

For explicit computation, fixed-scale convolutions are tensor products. Let

    h_(L,R)(d)=(h_L*h_R)(d),
    s_(L,R)(d)=(phi_L*h_R)(d),

in one dimension. Then

    P(delta)=integral mu(dL)mu(dR) sum_k [c_(n,k)/binom(n,k)]
       sum_(|S|=k) product_(i in S)s_(L,R)(delta_i)
                          product_(i notin S)h_(L,R)(delta_i). (6)

The inner coefficients can be evaluated from the polynomial product_i(h_i+t s_i). This retains the same common-softness costs for every n.

## 3. Exact normalization cancellation and off-diagonal decay

Every one-dimensional density h_L*h_R or phi_L*h_R is <=1/max(L,R), since convolution is bounded both by 1/L and by 1/R. Hence (6) is at most

    Csoft_n integral max(L,R)^(-n)mu(dL)mu(dR).

That double scale integral is EXACTLY

    integral max(L,R)^(-n)mu(dL)mu(dR)=2a^(-n)-b^(-n).   (7)

For a direct verification put U=L^n,V=R^n. Then mu becomes delta_(b^n)+dU/U. Splitting the continuous square by its larger coordinate gives

    b^(-n)[1+2log((b/a)^n)]
       +2 integral_(a^n)^(b^n) log(V/a^n)dV/V^2
       =2a^(-n)-b^(-n).

This proves the point bound in (1). Bounding max(L,R)^(-n) prematurely by a^(-n) would have incorrectly charged A_n^2 in the point amplitude.

For the sharper distance bound let

    m(delta)=#{i:|delta_i|>b},
    D_b(delta)=sum_i (|delta_i|-b)_+/b,
    C_(n,m)=sum_(k=m)^n c_(n,k)
                      binom(n-m,k-m)/binom(n,k).

Then C_(n,0)=Csoft_n, C_(n,1)=Csoft_n/2, C_(n,n)=1, and C_(n,m) decreases in m. The first-coordinate identity follows from c_(n,k)=c_(n,n-k).

For ALL delta, with m=m(delta),

    P(delta)<=[2a^(-n)-b^(-n)] C_(n,m) 2^(-m)exp(-D_b(delta)). (8)

Proof: if |delta_i|>b, its hard-hard factor is zero because (L+R)/2<=b. That coordinate must therefore be soft in (6). The actual soft density satisfies phi(1/2+t)<=exp(-t)/2 for t>=0. If gap=|delta_i|-(L+R)/2>0, its convolution factor has BOTH bounds

    s_(L,R)(delta_i)<=exp(-gap/L)/(2L),
    s_(L,R)(delta_i)<=exp(-gap/L)/(2R).

The first is the point-density bound; the second follows by integrating the one-sided phi tail and dividing by R. Thus it is <=[2max(L,R)]^(-1)exp(-(|delta_i|-b)/b). Other coordinates cost at most 1/max(L,R). The total common-soft coefficient of subsets containing all m forced coordinates is exactly C_(n,m). Apply (7), proving (8).

The TRUE kernel P is integrable with the polynomial mass in (1). Its useful integrated far tail is

    integral_(|delta|_infinity>b+s) P(delta)ddelta
       <=A_n^2 Csoft_n min{1,(n/2)exp(-s/b)}, s>=0.     (9)

For fixed L,R and k soft coordinates, a hard coordinate cannot reach b+s, and each soft coordinate has two-sided tail <=exp(-s/b). Union bound gives k exp(-s/b). Now sum coefficients, using sum_k k c_(n,k)=(n/2)Csoft_n, and integrate the two mu measures. The total-mass bound gives the other term in the minimum. Equation (9) is a Lebesgue tail estimate, not a license to integrate against arbitrary beta as though it had a density cap.

## 4. Localizing the actual clipped coupling before source masses

The actual capture intensity satisfies

    A_yz(r)<=a_r(z-y),
    a_r(delta)=(1/q_-)(K*1_(Q_r))(delta).               (10)

Indeed keep actual U_y dx and its capture/R<=r condition; the latter implies x in Q_r(z). Then use q>=q_- and (4)-(5), and only afterwards extend the receiver integral. FIRST remains an original qualification, not a newly asserted source or envelope cap.

For the original d from the common-rate note, define the explicit clipped pair kernel

    J_d(delta)=b^(-n)min(d,a_b(delta))
             +n integral_a^b r^(-n-1)min(d,a_r(delta))dr. (11)

Thus the clipped coupling localized by ANY frozen source-pair weight obeys

    O_d(omega)<=integral omega(y,z)J_d(z-y)beta(dy)nu(dz),
    J_d(delta)<=min{d a^(-n),P(delta)/q_-}.             (12)

The second inequality follows by integrating the cap d, or by removing the cap and observing that the r-layer integral of K*1_Qr equals K*H=P. In particular J_d is integrable with norm <=A_n^2 Csoft_n/q_-. Formula (11), rather than its coarser bound (12), keeps clipping BEFORE the r integral. It is directly computable from the tensor overlaps in (6), with the hard cube at scale r multiplied by r^n.

For the full common-rate target, the verified estimate T<=2O_d remains available. The direct actual bound (2) is stronger for the light-local-mass receipt (3) and avoids an unnecessary factor two there. No favorable pairwise Poisson rate is inserted into the original field.

For an explicit far price, if |delta|_infinity>b+s, then m>=1 and C_(n,m)<=Csoft_n/2. Equation (8) gives

    P(delta)<=Csoft_n exp(-s/b)/(2a^n).                (13)

Consequently the ACTUAL traffic on any frozen far-pair allocation omega has

    T_omega<=Csoft_n exp(-s/b)/(2q_-a^n)
                                   integral omega beta(dy)nu(dz). (14)

The corresponding contribution to 2O_d is bounded by twice (14), or by its minimum with 2d a^(-n) integral omega beta nu. These are true paid source-product receipts with an explicit separation gain. For example (14) is <=L1(W_beta+W_nu) if its displayed normalized pair mass and separation satisfy that numerical inequality. It is not made source-linear for arbitrary concentrated inputs by its Lebesgue L1 tail (9).

## 5. Scope and remaining source payment

The new useful payment is the root point amplitude (7), hence the actual light-local-mass branch (3). The same construction localizes the clipped coupling by an integrable, explicitly decaying kernel before either source mass is substituted. Full shared softness, the true phi tail, all physical scales and both actual scale selectors are accounted for.

The near heavy columns, any unpaid far contribution, and the original outer/aspect complements remain explicit. A single frozen allocation with beta column mass <=q_-a^n L0 is paid by the same point bound, but applying it to many allocations and repeating the full W_nu is not free. No claim that all original source geometry supplies such an allocation or that the integrable mass A_n^2 Csoft_n is root-order is made.

## 6. Actual bounded diagnostics and reproduction

A local run at 40 digits passed six double-scale normalization identities through log((b/a)^n)=1000, six EXACT Fraction common-soft coefficient profiles through n=32, and 27 real-phi off-diagonal convolution bounds. These are finite checks of the analytic ingredients, not tests of a global source-cover claim. Only this Markdown file was written.

```python
from fractions import Fraction as F
from math import comb
import sys
try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
    import mpmath as mp
mp.mp.dps=40
scales=0
for T in [mp.mpf(0),mp.mpf('.1'),mp.log(2),mp.log(1024),mp.mpf(100),mp.mpf(1000)]:
    pts=sorted(set([mp.mpf(0),min(T,1),min(T,10),min(T,100),T]))
    value=mp.exp(-T)*(1+2*T)+2*sum(
        mp.quad(lambda t:t*mp.exp(-t),[p,q]) for p,q in zip(pts,pts[1:]))
    assert abs(value-(2-mp.exp(-T)))<mp.mpf('1e-30')
    scales+=1
coeffs=0
for n in [1,2,3,8,16,32]:
    a=[F(comb(n,k))*F(k,n)**k*F(n-k,n)**(n-k) for k in range(n+1)]
    C=sum(a)
    Xi=[sum(a[k]*F(comb(n-m,k-m),comb(n,k)) for k in range(m,n+1))
        for m in range(n+1)]
    assert Xi[0]==C and Xi[1]==C/2 and Xi[-1]==1
    assert all(x>=y for x,y in zip(Xi,Xi[1:]))
    coeffs+=1
def phi(x):
    x=abs(x)
    if x<=mp.mpf('.5'):
        return 1-mp.expint(3,mp.mpf('.5')-x)-mp.expint(3,mp.mpf('.5')+x)
    return mp.expint(3,x-mp.mpf('.5'))-mp.expint(3,x+mp.mpf('.5'))
soft=0
for L in map(mp.mpf,['1','1.5','2']):
    for R in map(mp.mpf,['1','1.5','2']):
        for delta in map(mp.mpf,['2.01','3','10']):
            actual=mp.quad(lambda x:phi(x/L)/L,[delta-R/2,delta+R/2])/R
            gap=delta-(L+R)/2
            bound=mp.exp(-gap/L)/(2*max(L,R))
            assert actual<=bound+mp.mpf('1e-32')
            soft+=1
print('PASS selector-normalization identities=',scales)
print('PASS exact shared-soft coefficient profiles=',coeffs)
print('PASS actual-phi off-diagonal overlaps=',soft)
```
