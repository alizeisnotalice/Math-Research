import sys,json
from pathlib import Path
try:
 import mpmath as m
except ImportError:
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
 import mpmath as m
m.mp.dps=60
checks=[]
for b in [1,2,4,16,100,10000]:
 B=m.mpf(b)
 mean=m.quad(lambda z:2/z**2,[1,B])+1/B
 second=m.quad(lambda z:2/z,[1,B])+1
 err=max(abs(mean-(2-1/B)),abs(second-mean**2-(2*m.log(B)-3+4/B-1/B**2)))
 assert err<m.mpf('1e-45')
 checks.append({'kind':'truncated moments','B':b,'error':str(err)})
for n in [1,2,4,16,64,256,1024]:
 for ratio in ['1','1.0001','1.1','2']:
  T=n*m.log(m.mpf(ratio))
  knots=sorted(set([m.mpf(0),T]+[m.mpf(x) for x in [1,4,16,64,256] if x<T]))
  lhs=m.exp(-T)*(1+2*T)+m.quad(lambda t:2*t*m.exp(-t),knots)
  err=abs(lhs-(2-m.exp(-T)))
  assert err<m.mpf('1e-45')
  checks.append({'kind':'double scale cancellation','n':n,'ratio':ratio,'error':str(err)})
result={'checks':len(checks),'pass':True,'precision':60,'tolerance':'1e-45','scope':'quadrature diagnostic, not interval certificate','records':checks}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
print('PASS',len(checks),'moment / double-scale identities')
