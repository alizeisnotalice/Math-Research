from fractions import Fraction as F
from math import comb
import sys
try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
    import mpmath as mp
mp.mp.dps=40
scales=0
for T in [mp.mpf(0),mp.mpf('.1'),mp.log(2),mp.log(1024),mp.mpf(100),mp.mpf(1000)]:
    pts=sorted(set([mp.mpf(0),min(T,1),min(T,10),min(T,100),T]))
    value=mp.exp(-T)*(1+2*T)+2*sum(
        mp.quad(lambda t:t*mp.exp(-t),[p,q]) for p,q in zip(pts,pts[1:]))
    assert abs(value-(2-mp.exp(-T)))<mp.mpf('1e-30')
    scales+=1
coeffs=0
for n in [1,2,3,8,16,32]:
    a=[F(comb(n,k))*F(k,n)**k*F(n-k,n)**(n-k) for k in range(n+1)]
    C=sum(a)
    Xi=[sum(a[k]*F(comb(n-m,k-m),comb(n,k)) for k in range(m,n+1))
        for m in range(n+1)]
    assert Xi[0]==C and Xi[1]==C/2 and Xi[-1]==1
    assert all(x>=y for x,y in zip(Xi,Xi[1:]))
    coeffs+=1
def phi(x):
    x=abs(x)
    if x<=mp.mpf('.5'):
        return 1-mp.expint(3,mp.mpf('.5')-x)-mp.expint(3,mp.mpf('.5')+x)
    return mp.expint(3,x-mp.mpf('.5'))-mp.expint(3,x+mp.mpf('.5'))
soft=0
for L in map(mp.mpf,['1','1.5','2']):
    for R in map(mp.mpf,['1','1.5','2']):
        for delta in map(mp.mpf,['2.01','3','10']):
            actual=mp.quad(lambda x:phi(x/L)/L,[delta-R/2,delta+R/2])/R
            gap=delta-(L+R)/2
            bound=mp.exp(-gap/L)/(2*max(L,R))
            assert actual<=bound+mp.mpf('1e-32')
            soft+=1
print('PASS selector-normalization identities=',scales)
print('PASS exact shared-soft coefficient profiles=',coeffs)
print('PASS actual-phi off-diagonal overlaps=',soft)
