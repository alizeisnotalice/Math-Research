# R302 — large cumulative rows force source-weighted cube disagreement

## 1. Exact target and a new unconditional geometric estimate

Fix one full original outer-data/clock instance. Keep arbitrary finite positive L1 sources beta,nu; the actual full-soft p_y=P_(s(x),L(x))(x-y); a<=L,R<=b<=2a; q_-=3lambda/4<=q<=lambda; the original accepted set E, FIRST and SAME-receiver/SAME-radius hard caps. Fix the original low-pe,m>M target and an actual aspect branch v(L,R)=min(1,(L/R)^(n/2))>=v0>0. All original source/history masks, full e_g,m and unique bands remain.

Choose an original z-independent row gate 0<=alpha(x,y)<=1 which dominates the target mask. It may retain the original low-pe,m>M and target aspect qualifications; these are evaluated from the ORIGINAL full sources. Define

    U_y(x)=alpha(x,y)1_E(x)p_y(x)/q(x),
    I_y=integral U_y dx,
    A_yz(r)=integral_{R(x)<=r}1{z in Q_(R(x))(x)}U_y(x)dx.

Here Q_r(x) has side length r. The full-soft bound I_y<=S/q_-, with S=(1+n log(b/a))Csoft_n, ensures finiteness. It is not used as a price in the estimate below. Let

    ell_n(dr)=b^(-n)delta_b(dr)
                         +n r^(-n-1)1_(a,b)(r)dr,
    d=kappa0 psi_inf/(q_-v0)>0,
    kappa0=2K/(ell M), psi_inf=3-2/(3gamma^n), gamma=1+1/n.

The already proved common-rate bridge gives T_target<=2 O_d, where

    O_d=integral beta(dy) ell_n(dr) nu(dz) min(d,A_yz(r)). (1)

The layer measure ell_n is an auxiliary positive identity, not a replacement for the original receiver dx.

For each y,r introduce the cumulative ACTUAL row mass and first source moment

    J_y(r)=integral_{R(x)<=r}U_y(x)dx,
    M_y(r)=integral A_yz(r)nu(dz).

Define the double-receiver cube-disagreement quantity

    Q_y(r)=(1/2) integral_{R(u),R(w)<=r} U_y(u)U_y(w)
               nu(Q_(R(u))(u) symmetric_difference Q_(R(w))(w)) du dw.
                                                               (2)

For H>0 let the remaining boundary fee be

    B_H=integral beta(dy) ell_n(dr) 1{J_y(r)>=H} Q_y(r)/J_y(r).
                                                               (3)

There is no division on zero rows. The following unconditional estimate is proved below:

    O_d <=4lambda H W_beta +(d/H) A_n W_nu+B_H,
    A_n=1+n log(b/a).                                      (4)

In fact the middle term can be replaced by

    (d/H)min{A_n W_nu,4lambda integral I_y beta(dy)},        (5)

and, when useful, by (d/H)4lambda|E| through original FIRST.

Taking H=sqrt(d A_n/(4lambda)) in (4) gives

    O_d<=2sqrt(lambda d A_n)(W_beta+W_nu)+B_H,
    T_target<=4sqrt(lambda d A_n)(W_beta+W_nu)+2B_H.         (6)

When both source masses are positive, the source-mass-balanced choice

    H*=sqrt(d A_n W_nu/(4lambda W_beta))

also gives

    O_d<=4sqrt(lambda d A_n W_beta W_nu)+B_(H*),
    T_target<=8sqrt(lambda d A_n W_beta W_nu)+2B_(H*).

This optimizes the two explicit source terms, not the whole bound: the retained boundary fee is evaluated at that same H*. If either source mass is zero, the original traffic and clipped capacity are zero and no division by its mass is made.

Since lambda d=(4/3)kappa0 psi_inf/v0, the displayed source term is root order in A_n=O(n), with all original constants and aspect fees retained. This is a genuinely paid source contribution. It does not prove that the explicit physical source-boundary fee B_H is root order. B_H is not named as an original residual allocation: it is the precise auxiliary geometric fee in the upper bound (6).

## 2. Exact overlap identity and the clipping inequality

For fixed y,r write J=J_y(r), M=M_y(r), A(z)=A_yz(r). Then 0<=A(z)<=J. Expanding the indicators of the two actual hard cubes in (2), positive Tonelli gives the EXACT identity

    Q_y(r)=J M-integral A(z)^2 nu(dz).                    (7)

Indeed for two 0-1 capture indicators a,b one has |a-b|=a+b-2ab. Thus the first two terms of their double integral contribute 2JM and the last contributes 2 integral A^2. Source overlap is counted with its true nu mass, not replaced by Euclidean intersection volume or an assumed density.

For J>0 and 0<=A<=J,

    min(d,A)<= (d/J)A + A(J-A)/J.                        (8)

If A<=d, subtracting A from the right side gives A(d-A)/J>=0. If A>=d, subtracting d gives (A-d)(1-A/J)>=0. This verifies both regimes and their endpoints. Integrating (8) and using (7) gives

    integral min(d,A_yz(r))nu(dz)
        <=min{M_y(r), (d/J_y(r))M_y(r)+Q_y(r)/J_y(r)}.   (9)

If J=0 then A,M,Q all vanish. Inequality (9) is the required link between a large original cumulative row and geometric overlap: when J is large relative to d, clipping is inexpensive unless the actual receiver cubes disagree on substantial original hard-source mass.

More quantitatively, suppose at a layer with M>0 that

    integral min(d,A)nu>=theta M, and J>=2d/theta,
    0<theta<=1.

Then (9) forces

    Q>= (theta/2) J M.                                  (10)

Under the normalized restricted receiver law U_y1_{R<=r}dx/J,
its expected nu-weighted symmetric difference is 2Q/J^2, while its mean captured source mass is M/J. Hence (10) says that the former is at least theta times the latter. At r=b, J=I_y, so this is a direct quantitative statement about the requested large original I_y rows. It supplies the actual alternative: cheap clipping, or significant source-weighted spatial/radius disagreement. It does not infer that all large rows have overlapping captures.

## 3. Small cumulative layers cost only 4lambda H, with no scale factor

Let mu_y be the pushforward of U_y(x)dx by actual R(x); its inclusive CDF is J_y(r). For every layer, the original hard cap at those SAME accepted receivers gives

    M_y(r)=integral_{R(u)<=r}U_y(u)nu(Q_(R(u))(u))du
                  <=4lambda integral_[a,r] s^n mu_y(ds). (11)

This is not a cap at a source center or at an unselected smaller radius.

The exact layer identity, including the atom at b, is

    ell_n([s,b])=s^(-n), a<=s<=b.                        (12)

Since J is nondecreasing, J(r)<H and r>=s imply J(s)<H. Consequently positive Tonelli yields

    integral ell_n(dr)1{J_y(r)<H}M_y(r)
      <=4lambda integral s^n mu_y(ds)
                      integral_[s,b] ell_n(dr)1{J_y(r)<H}
      <=4lambda integral 1{J_y(s)<H}mu_y(ds)
      <=4lambda H.                                     (13)

The last inequality is the elementary inclusive-CDF mass fact: the total mu mass of the initial set where its inclusive CDF is below H is at most H. If an atom jumps across H, the whole crossing atom is excluded. An atom landing exactly at H is likewise excluded from the strict low layer. This treats endpoints a,b, empty low sets, and a large first atom without pretending a continuous crossing exists.

Since min(d,A)<=A, (13) pays ALL low cumulative layers J<H by 4lambda H per beta row. This is stronger than applying 4lambda I_y to the entire row or paying once per physical scale. A row with large final I_y still has its low cumulative prefix paid at this single price.

## 4. High cumulative layers, original FIRST and the full budget

On J>=H, (9) bounds the clipped layer by (d/H)M+Q/J. Integrate this and combine it with (13). It remains to price the one global first moment

    F1=integral beta(dy)ell_n(dr)M_y(r).

Tonelli and (12) give the ORIGINAL receiver expression

    F1=integral_E f(u)h_(R(u))*nu(u)du,
    f(u)=integral alpha(u,y)p_y(u)beta(dy)/q(u)<=1.        (14)

The inequality is original FIRST, with alpha<=1. It is applied at true accepted receivers before any receiver extension. Therefore

    F1<=4lambda integral I_y beta(dy),
    F1<=integral nu(dz)integral du sup_(a<=R<=b)h_R(u-z)
       =A_n W_nu.                                      (15)

The exact hard envelope integral is 1+n log(b/a), obtained from its central Q_a block and shells a<R<=b. The extension here is positive and made only after using FIRST. If |E| is useful, (14) also gives F1<=4lambda|E|. Substitution proves (4)-(5), and the displayed choice of H proves (6).

Every step has kept both original source integrations and the actual receiver U_y dx. The full-soft profile was not replaced by a product of independent coordinate maxima. Its true alpha,p_y,q enter J,M,Q throughout. No assumption nu<=beta or source density cap has been made, and no source fee is repeated per j or radius layer.

## 5. A checkable agreement condition, a physical boundary description, and the gap

A concrete sufficient geometric hypothesis on high layers is

    Q_y(r)<=epsilon J_y(r)M_y(r)
       for beta(dy)ell_n(dr)-almost every (y,r) with J_y(r)>=H.
                                                               (16)

Then B_H<=epsilon F1<=epsilon A_n W_nu. Thus (6) becomes a genuine complete source payment on the stated target branch:

    T_target<=4sqrt(lambda d A_n)(W_beta+W_nu)
                                      +2epsilon A_n W_nu. (17)

For example epsilon<=A_n^(-1/2) gives a root-order final term too. Hypothesis (16) is verifiable from the actual double-receiver/source geometry. One stronger sufficient condition is the pairwise bound

    nu(Q_(R(u))(u) symmetric_difference Q_(R(w))(w))
       <=epsilon[nu(Q_(R(u))(u))+nu(Q_(R(w))(w))]

for almost every pair under each relevant restricted U_y product measure; integration proves (16). Neither condition is claimed from hard caps alone.

For a purely spatial interpretation, put

    h(u,w)=|u-w|_infinity+|R(u)-R(w)|/2.

The symmetric difference of the two cubes is contained in the source boundary layer

    {z: abs(|z-u|_infinity-R(u)/2)<=h(u,w)}.             (18)

The inclusion follows from the 1-Lipschitz property of distance in the infinity norm and the two cube radii. Thus (3) can be bounded by the corresponding actual nu masses of these boundary layers. No Euclidean volume estimate for (18) is multiplied by an invented source density. Original hard caps bound whole accepted receiver cubes; without additional information they do not give a factor proportional to the thickness of this boundary layer.

The receiver-budget alternative is also explicit. From (4)-(5),

    T_target<=8lambda H W_beta+(8d/H)lambda|E|+2B_H.     (19)

For instance H=16d makes the receiver coefficient 1/2. To absorb it one still needs a separately established original entry inequality using this SAME finite X_E=lambda|E|, and a bound on B_H. If (16) holds, its receiver bound is 2B_H<=8epsilon X_E. No matching entry or finiteness-preserving truncation is invented here.

From (7), 0<=Q_y(r)/J_y(r)<=M_y(r) on positive rows. Thus the unconditional coarse boundary bound is only B_H<=F1<=A_n W_nu (also B_H<=4lambda integral I_y beta). It does not improve the dimension order to root by itself.

The new unconditional result is (4), with its root-priced first two contributions and exact source-weighted cube-disagreement fee. The actual missing hypothesis is a useful bound on (3), or an agreement estimate such as (16), on the original accepted row measures. Merely high I_y, FIRST and same-radius hard caps have not been shown here to imply it. The aspect complement v<v0 and all original outer terms remain as before. For an outer parameter xi, the original positive Lambda(xi) multiplies (4),(6) or (19) inside the existing source/clock ledger; there is no free new outer integration.

## 6. Actual finite geometry checks

An actual local exact-Fraction run tested three stages: separated one-dimensional receivers; overlapping two-dimensional cubes with equal-radius atoms; and a three-dimensional menu with boundary source points. It passed 24 exact overlap identities, 264 clipping inequalities, 108 cumulative-low-layer budgets and 108 combined budgets. These finite atomic source patterns are algebra/geometry diagnostics, not a proof of (16) for arbitrary original L1 inputs. The analytic proof above handles those inputs. The exact code follows and writes no files.

```python
from fractions import Fraction as F
from itertools import product
counts={'layer_identity':0,'clipping':0,'small_cumulative':0,'joint_budget':0}
stages=[(1,[(F(0),),(F(1,2),),(F(3),)],[F(1),F(3,2),F(2)]),
 (2,[(F(0),F(0)),(F(1,2),F(0)),(F(1),F(1))],[F(1),F(1),F(2)]),
 (3,[(F(0),)*3,(F(1),)*3,(F(-1),)*3],[F(1),F(3,2),F(2)])]
for n,centers,rs in stages:
 zs=centers+[tuple(c[k]+r/2 for k in range(n)) for c,r in zip(centers,rs)]
 mass=[F(1,len(zs))]*len(zs)
 cap=[[int(all(abs(z[k]-c[k])<=r/2 for k in range(n))) for z in zs] for c,r in zip(centers,rs)]
 for us in [[F(1,4),F(1,2),F(1,4)],[F(1),F(2),F(3)],[F(0),F(1),F(0)]]:
  cuts=sorted(set([F(1),F(2)]+rs));layers=[]
  for k,r in enumerate(cuts):
   weight=r**(-n)-(cuts[k+1]**(-n) if k+1<len(cuts) else F(0))
   active=[i for i in range(3) if rs[i]<=r];J=sum((us[i] for i in active),F(0))
   Az=[sum((us[i]*cap[i][z] for i in active),F(0)) for z in range(len(zs))]
   M=sum(m*A for m,A in zip(mass,Az)); Q=J*M-sum(m*A*A for m,A in zip(mass,Az))
   pair=sum((us[i]*us[j]*sum(m*abs(cap[i][z]-cap[j][z]) for z,m in enumerate(mass)) for i in active for j in active),F(0))/2
   assert Q==pair and Q>=0;counts['layer_identity']+=1
   layers.append((weight,J,Az,M,Q))
  first=sum(w*M for w,J,Az,M,Q in layers)
  direct=sum(us[i]*rs[i]**(-n)*sum(m*c for m,c in zip(mass,cap[i])) for i in range(3))
  assert first==direct
  for d,H in product([F(1,10),F(1),F(4)],[F(1,4),F(1),F(3),F(6)]):
   O=low=B=F(0)
   for w,J,Az,M,Q in layers:
    clip=sum(m*min(d,A) for m,A in zip(mass,Az));O+=w*clip
    if J:
     assert clip<=d*M/J+Q/J
     counts['clipping']+=1
    if J<H:low+=w*M
    else:B+=w*Q/J
   assert low<=4*H;counts['small_cumulative']+=1
   assert O<=4*H+d*first/H+B;counts['joint_budget']+=1
print('PASS',counts)
```

Only /tmp/r302_geometry.md was written. Earlier proofs, other author files and Git state were not changed.
