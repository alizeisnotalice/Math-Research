# R302 exact overlap splitting diagnostics

Exact Fraction diagnostics only on genuine positive-volume cell/shell source and receiver models with actual s=0 kernels and FIRST<=1,same-radius hardresponse<=4. Original full maximal-hardcap and low-m/e_g histories are not implemented. No abstract incidence model is included. No general dimension-order or FULL closure claim.

O=sum_j,r beta_j w_r sum_z nu_z min(d,A_z) <=4H Wbeta +(d/H) Cmenu Wnu+B_H; Cmenu=sum_r w_r r^n; B_H=sum_(J>=H)beta_j w_r Qpair/J. Equality J=H belongs to large branch.

FIRST<=1 gives sum_j beta_j A_jz(r)<=r^n for every z, so sum beta_j w_r M1_j(r)<=Cmenu Wnu.

|model|n|layers|positive Q layers|max J|best tested O/RHS|
|---|---:|---:|---:|---:|---:|
|disjoint_n1|1|8|0|0.125|0.0459667|
|overlap_chain_n1|1|18|7|0.177083|0.0821375|
|cross_n4|4|48|11|0.000308578|4.56904e-05|
|tied_n4|4|32|10|0.000518799|0.000133287|
|cross_n8|8|48|11|3.02417e-09|8.85124e-10|
|cross_n16|16|48|11|5.57142e-18|3.9173e-18|
|concentric_shell_n16|16|65|0|10.9942|0.119168|
|concentric_shell_n32|32|129|0|20.9993|0.0705266|

All comparisons are exact Fraction. H menus include positive cumulative atoms exactly, plus adjacent 99%/101% values. d=1/16,1,16. Whole-cell geometry and frozen source masses are retained in JSON; cells are uniform L1 densities, not point masses. Repeated real-cell generation logic is copied into this standalone script; frozen earlier scripts are not imported or modified.
