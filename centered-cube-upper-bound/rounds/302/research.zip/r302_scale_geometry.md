# R302: a global separation-kernel dilation envelope with the boundary tail retained

## Scope and exact statement
Let tau(x)=(1-|x|)_+ be the probability density obtained by convolving two unit centered interval indicators. Let w(x)=integral_0^1 exp(-|x|/u)du, a probability density, and rho_s=(1-s)delta_0+s w(x)dx for 0<=s<=1. Define g_s=tau*rho_s and, for n>=1 and r>0,
 K_(s,r)(z)=r^(-n) product_(i=1)^n g_s(z_i/r).
The value s is common to all coordinates and is fixed in the following scale supremum. For every B>=1 set
 V(B)=2log B-3+4/B-1/B^2,
 D_n(B)=sqrt(n V(B))+2n/B.
Then for every 0<a<=b<infinity,
 integral_R^n sup_(a<=r<=b) K_(s,r)(z) dz
 <=1+(log(b/a)/2)[D_n(B)+sqrt(ns)].                 (1)
In particular B=sqrt(n) gives D_n(B)<=sqrt(n(1+log n))+2sqrt(n), uniformly in n>=1. Thus (1) is root order with a square-root logarithmic loss on a bounded scale window, uniformly in the fixed common softness s. This is a global Lebesgue envelope on source SEPARATION space, not a source-weighted weak endpoint bound.

This theorem concerns the actual fixed-parameter pair convolution P_(s,r)*h_r. It neither replaces arbitrary receiver-dependent parameters by constants nor establishes a bound against arbitrary beta(dy)nu(dz). Its use in the original problem requires separately paid selection and source-integration bridges. The full original low/high/history conditions have not been discarded to claim a general theorem.

## Proof: the exact triangular boundary score
If X has density tau and V=1-|X|, V has density 2v on (0,1). The dilation score of tau is
 S=-1+|X|/(1-|X|)=1/V-2.
Put Z=1/V. Its density is 2z^(-3), z>=1, E Z=2, and E Z^2=infinity. In particular ordinary finite-variance tensor arguments are not available.
For Y=min(Z,B), layer integration gives
 E Y=2-1/B, E Y^2=1+2log B, Var(Y)=V(B).
Let H=Z-Y. Then H>=0, E H=1/B. Independent copies satisfy
 E|sum_i (Z_i-2)|
 <= E|sum_i(Y_i-EY_i)|+E|sum_i(H_i-EH_i)|
 <= sqrt(n V(B))+2n/B=D_n(B).                       (2)
V(B) is a genuine variance, including V(1)=0. No guessed asymptotic exponent is used. The upper bound V(B)<=1+2log B gives the stated B=sqrt(n) simplification.

## Proof: adding the full fixed-softness noise
The density w is the mixture of centered Laplace densities of scale u with mixing probability density 2u du on (0,1). Sample J~Bernoulli(s), U with that density and L a unit Laplace variable, all independent of X. Then X+JUL has density g_s. Under a common dilation r, the latent triangular coordinate has score S. If J=1, the noise coordinate has dilation score |L|-1; if J=0 its mass remains at zero and has score zero. Thus the total latent score in n coordinates is
 sum_i S_i + sum_i J_i(|L_i|-1).
The second sum is centered, has variance ns, and has expected absolute value at most sqrt(ns). These facts hold before conditioning on the sum X+JUL; no artificial independent softness per coordinate is optimized. Independent Bernoulli labels here represent exactly the product of the fixed common-s mixture.

For completeness the output derivative bound follows without invoking a density-score identity at zeros. Differentiate the latent product measure under simultaneous dilation of its triangular and nonzero Laplace variables. Its finite signed derivative has total variation at most (D_n(B)+sqrt(ns))/r by (2). Pushing this derivative forward under coordinatewise addition cannot increase total variation: for every measurable |f|<=1 the integral of f after the pushforward is an integral of a function bounded by one before it. This gives
 integral |partial_r K_(s,r)(z)| dz <=[D_n(B)+sqrt(ns)]/r. (3)
The triangular density is continuous and vanishes at its support endpoints. Its distributional first scale derivative therefore has no boundary atom. Its derivative is integrable by E|S|<infinity. Laplace dilation likewise has an integrable derivative; the delta component is constant. Product differentiation and positive mixing are justified in L1, uniformly on compact positive scale intervals. These observations justify the finite signed derivative just used, including s=0 and s=1.

## Proof: positive variation, not total variation twice
The kernels are nonnegative and integrate to one, so their scale derivative has integral zero. Hence the integral of its positive part is half its L1 norm. Absolute continuity in scale (with an almost-everywhere jointly measurable representative) gives
 sup_(a<=r<=b)K_(s,r)(z)
 <=K_(s,a)(z)+integral_a^b [partial_r K_(s,r)(z)]_+ dr.
The continuous explicit kernels agree with this representative and the supremum can be taken over a countable dense set. Tonelli and (3) prove (1). The singleton interval a=b gives exactly one.

## Actual selector and source-integration costs remain
For equal scales and fixed s, the identity
 integral P_(s,r)(x-y)h_r(x-z) dx=K_(s,r)(y-z)
holds on the full receiver space. If r=r(x) or s=s(x), the left side is generally not a fixed-parameter convolution. Even for a finite menu r_j and a receiver partition E_j, the legitimate enlargement is
 sum_j integral_(E_j) P_(s,r_j)(x-y)h_(r_j)(x-z)dx
 <=sum_j K_(s,r_j)(y-z),
not sup_j K_(s,r_j)(y-z). The number of menu terms cannot be erased. Also an L1(d(y-z)) bound does not bound its integral against arbitrary beta by nu. Neither a density cap nor beta/nu domination is assumed here. The theorem can serve only as a geometric ingredient after these two bridges are proved with their actual prices.

The present result does not close O_d from R301. The companion general overlap investigation retains the original selected receiver field. The utility of this derivation is an explicit root-log scale-variation mechanism and its boundary-tail cost, replacing the n-cost positive radial envelope only where the pair convolution representation is genuinely available.

## Numerical status
Computations, separate from this proof, are recorded in r302_scale_numeric.*. Their finite scope does not establish a general upper endpoint. The exact truncated moments and all numerical checks must be audited before archiving.
