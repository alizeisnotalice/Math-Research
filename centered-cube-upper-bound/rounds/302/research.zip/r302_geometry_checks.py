from fractions import Fraction as F
from itertools import product
counts={'layer_identity':0,'clipping':0,'small_cumulative':0,'joint_budget':0}
stages=[(1,[(F(0),),(F(1,2),),(F(3),)],[F(1),F(3,2),F(2)]),
 (2,[(F(0),F(0)),(F(1,2),F(0)),(F(1),F(1))],[F(1),F(1),F(2)]),
 (3,[(F(0),)*3,(F(1),)*3,(F(-1),)*3],[F(1),F(3,2),F(2)])]
for n,centers,rs in stages:
 zs=centers+[tuple(c[k]+r/2 for k in range(n)) for c,r in zip(centers,rs)]
 mass=[F(1,len(zs))]*len(zs)
 cap=[[int(all(abs(z[k]-c[k])<=r/2 for k in range(n))) for z in zs] for c,r in zip(centers,rs)]
 for us in [[F(1,4),F(1,2),F(1,4)],[F(1),F(2),F(3)],[F(0),F(1),F(0)]]:
  cuts=sorted(set([F(1),F(2)]+rs));layers=[]
  for k,r in enumerate(cuts):
   weight=r**(-n)-(cuts[k+1]**(-n) if k+1<len(cuts) else F(0))
   active=[i for i in range(3) if rs[i]<=r];J=sum((us[i] for i in active),F(0))
   Az=[sum((us[i]*cap[i][z] for i in active),F(0)) for z in range(len(zs))]
   M=sum(m*A for m,A in zip(mass,Az)); Q=J*M-sum(m*A*A for m,A in zip(mass,Az))
   pair=sum((us[i]*us[j]*sum(m*abs(cap[i][z]-cap[j][z]) for z,m in enumerate(mass)) for i in active for j in active),F(0))/2
   assert Q==pair and Q>=0;counts['layer_identity']+=1
   layers.append((weight,J,Az,M,Q))
  first=sum(w*M for w,J,Az,M,Q in layers)
  direct=sum(us[i]*rs[i]**(-n)*sum(m*c for m,c in zip(mass,cap[i])) for i in range(3))
  assert first==direct
  for d,H in product([F(1,10),F(1),F(4)],[F(1,4),F(1),F(3),F(6)]):
   O=low=B=F(0)
   for w,J,Az,M,Q in layers:
    clip=sum(m*min(d,A) for m,A in zip(mass,Az));O+=w*clip
    if J:
     assert clip<=d*M/J+Q/J
     counts['clipping']+=1
    if J<H:low+=w*M
    else:B+=w*Q/J
   assert low<=4*H;counts['small_cumulative']+=1
   assert O<=4*H+d*first/H+B;counts['joint_budget']+=1
print('PASS',counts)
