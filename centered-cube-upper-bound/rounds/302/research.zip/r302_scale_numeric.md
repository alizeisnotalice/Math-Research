# R302 tensor-overlap dilation-score diagnostics

The actual local script ran three stages. These are auxiliary pair-kernel diagnostics; they do not justify general selector integration.

For S=1/sqrt(V)-2, ES=0 and E|S|=1, but ES² is infinite. The exact truncated second moment is 2log(T+2)+8/(T+2)-4/(T+2)²-4. Centering the truncation with T proportional to sqrt(n) yields an O(sqrt(n log n)) upper bound. This run does not establish a matching lower bound.

|n|raw mean|mean/sqrt(n)|mean/sqrt(n log(n+2))|nominal iid interval|analytic upper bound|
|---:|---:|---:|---:|---:|---:|
|1|1.02061|1.02061|0.973733|[0.870913, 1.10164]|1.92562|
|4|2.58067|1.29033|0.963967|[2.3049, 2.81324]|4.48078|
|16|6.37522|1.5938|0.937472|[5.77492, 6.92907]|10.1186|
|64|14.8937|1.86171|0.909541|[13.5369, 16.0845]|22.3602|
|256|33.611|2.10068|0.891453|[30.3638, 35.8292]|48.6359|
|1024|73.6718|2.30224|0.874334|[67.2837, 79.0532]|104.545|

Fixed Python random seeds and floating inverse-CDF sampling. Raw estimator has infinite variance, so batch spread is descriptive and no raw standard-error CI is claimed. Displayed nominal 99% simultaneous six-case iid intervals use a bounded estimator Z=min(|sum min(S,T)|,C), two-sided empirical Bernstein bound with log(4/delta), delta=.01/6, plus deterministic bias bounds. This probabilistic interpretation assumes ideal iid uniforms; PRNG, quadrature and ordinary mpmath are not interval-certified.

Each dimension uses 32768 draws in eight reproducible batches. Raw batch means and maxima, capped estimator, analytic bias terms, and 40/60-digit quadrature comparisons are in the JSON. Numerical samples are evidence only.
