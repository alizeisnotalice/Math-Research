# R172：正残余的全软度接收支撑及物理 C 层消元

## 1. 原量词与捕获倍数

固定一条原完整行及其共同接收参数、同一实际来源 ν、外源中心 y 与 same-α。本文不改变 good/high、FIRST、历史、Zt、et 或实际 Πt，不把 ν 或 β 概率化。本文只处理接收源 v 的几何，未证明一般根阶付款或新的 FULL/L1 正覆盖。

原捕获倍数并非任意正数。R125 `proof.md` AC2（归档 `rounds/125/research.zip`，原稿第71–89行；概述第11–16行）给出

\[
D=D_n=\max\left\{1,\frac{\varepsilon_{RC}\sqrt{\mathcal L}}{8\Lambda}
-\frac{16}{3\sqrt{\mathcal L}}\right\}\ge1,
\qquad \mathcal L=1+\log n,\quad\Lambda=128/119.
\tag{G1}
\]

εRC 是已经全局固定的份额，不能随本行、v 或辅助时间调节。R128 `proof.md` RT6 第660–667行明确继承 D≥1。本稿亲读 R125/R128 冻结原稿；独审另核 R125/R126/R127 继承。这里只用 D≥1，不使用未核定的数值 K，也不把有限模型 D=1 当成一般定义。

记

\[
f_s(r)=(1-s)1_{\{|r|\le1/2\}}+s\phi(r),\qquad
b_s=1-s+s\phi(1/2)>0,
\]
\[
H_0=g c_j^{-1/2}b_s\mathcal L^{1/(2n)},\quad
H=\widehat H=\max(a,\min(b,H_0)),\quad
T=\frac{c_j^{n/2}}{g^n\sqrt{\mathcal L}}
=\frac{b_s^n}{H_0^n}.
\tag{G2}
\]

H 是本行共同合法 K0 尺度，K0(v)=H^{-n}∏f_s((x_i−v_i)/H)，J(v)=b^{-n}∏φ((x_i−v_i)/b)。定义原物理层

\[
\xi_\tau=a/b,\quad \xi_h=c_jh/b,\quad
C_i=C((y_i-v_i)/b),\quad
W_\tau=\prod_i\min(1,C_i/\xi_\tau),\quad
W_h=\prod_i\min(1,C_i/\xi_h),\quad \Delta=W_\tau-W_h.
\tag{G3}
\]

这里只在非空 far 行 h>τ、Δ>0上写残余比值；h=τ时Δ=0，无正残余，h<τ的 far 窗为空。原 same-α≥0（由 U≤DK0、K0ν≤q 得 αQJ=Dq−∫Uν≥0），且

\[
\rho(v)=\left[1-\frac{DK_0(v)+\alpha J(v)}{T\Delta(v)}\right]_+.
\tag{G4}
\]

QJ=0的零来源行沿原约定跳过；不构造0/0。实际正接收项还乘 good 等原门；以下都是其必要条件或上包络，没有把它们称为充分资格。

## 2. 全软度硬立方体排除，含全部截断情形

逐坐标 Wh/Wτ 的因子在 [τ/h,1] 内，故

\[
0<\Delta\le\delta_{\max}W_\tau\le\delta_{\max},\qquad
\delta_{\max}=1-(\tau/h)^n<1.
\tag{G5}
\]

该全域上界准确：物理 C 的值域为(0,1]，所有 Ci=ξτ 时取到。它比仅用 Δ≤1 更强。

令 r_i=|x_i−v_i|/H。闭硬坐标 r_i≤1/2 满足 f_s(r_i)≥bs。因此在整个闭立方体 QH(x) 上

\[
\frac{DK_0(v)}{T}\ge q_H:=D(H_0/H)^n.
\tag{G6}
\]

**一般几何结论。** 若 qH≥δmax，则 ρ 在闭 QH(x) 上恒为0；包含所有硬面，等号亦排除。更细地，若 qH<δmax，则仍有

\[
\rho(v)\le[1-q_H/\delta_{\max}]_+
\quad(v\in Q_H(x)).
\tag{G7}
\]

没有删除 αJ：因其非负，忽略它只给较弱的上界。三种 H0 情形必须分开：

| 原尺度情形 | 实际 H | 一般必要几何 |
|---|---|---|
| H0<a | H=a，qH=D(H0/a)^n | 只有 qH≥δmax 时才能排除整个闭 core；否则保留内部残余，使用(G7)或下节更细层。不能把 H0 当作合法测试尺度。 |
| a≤H0≤b | H=H0，qH=D≥1>δmax | 全闭 core 零残余；故 ρ>0 强制至少一坐标 |x_i−v_i|>H/2。 |
| H0>b | H=b，qH=D(H0/b)^n≥1>δmax | 同样排除全闭 core，且具有额外严格尺度裕度。不能用 H0>b 的核替换原 K0。 |

这是真正适用于所有 s∈[0,1] 的结论，因而也适用于最新实际严格软度门；没有借用已经为空的 s=0 子支。H0<a 的未排除内部仍是原 middle 的一部分。

在下截断 H=a 的情形，排除门还可直接写成原软度/尺度条件

\[
b_s\ge \frac ag\sqrt{c_j}\left(\frac{\delta_{\max}}{D\sqrt{\mathcal L}}\right)^{1/n},
\quad\text{即}\quad
s\le\frac{1-(a/g)\sqrt{c_j}(\delta_{\max}/(D\sqrt{\mathcal L}))^{1/n}}
{1-\phi(1/2)}.
\tag{G6a}
\]

这里只与 s∈[0,1] 及原实际门取交；右端大于1时覆盖全部软度，小于0时为空。该显式全软度门也覆盖部分 H0<a，不要求另立纯硬模型。


### 2.1 内立方体、外延及各向异性硬层

上述结论不止限于硬面 r=1/2。任取有限非负半径 r1,…,rn，定义真实接收盒

\[
\mathcal Q(r)=\{v:|x_i-v_i|\le Hr_i\ \forall i\}.
\]

由于 fs 偶递减（硬面采用闭端点值），若

\[
D(H_0/H)^n\prod_i\frac{f_s(r_i)}{b_s}\ge\delta_{\max},
\tag{G8}
\]

则该整个闭盒零残余；不成立时同式左端除 δmax 给统一的 ρ 衰减上界。它允许任意混合的内层/硬面/外软坐标。对 s>0 可以有严格超出 H/2 的零残余盒；对 s=0 任何外坐标使乘积为0，不能假借软尾延伸。

保留实际 same-α 后，更强的充分门为

\[
D H^{-n}\prod_i f_s(r_i)+\alpha b^{-n}\prod_i\phi(Hr_i/b)
\ge T\delta_{\max}.
\tag{G8a}
\]

两种接收核的盒内最小值同时在角点达到；上式仍保守地把 Δ用全域帽替代，未声称三点共同极值也在角点。特别是 H0<a且(G6)未排除的内部，仍可被实际 αJ进一步排除，不能反过来将其全称为正残余。


均匀 r 的门为

\[
f_s(r)\ge b_s(H/H_0)(\delta_{\max}/D)^{1/n}.
\tag{G9}
\]

由 fs 的单调性，(G9)直接确定此方法保证的最大中心立方体。设该阈值为 q：q>fs(0)时无此中心孔；s>0且 bs<q≤fs(0)时得到严格内 core（q=fs(0)时可退化为中心点）；q≤bs时含全闭 core。严格向硬面外延须 q<sφ(1/2)；q=sφ(1/2)时不包含任何严格外点。s=0按硬核分段处理，不能跨跳作连续反演。这里是对所有物理 C/Δ 的统一保证，不声称结合 good/FIRST 后它最优。

## 3. 混合硬/外坐标的准确乘积必要式

令 I={i:ri≤1/2}，O={i:ri>1/2}；硬面全部归 I。对 s>0，ρ>0 强制

\[
\sum_{i\in O}\log\frac{b_s}{s\phi(r_i)}
>
\log D+n\log(H_0/H)-\log\Delta
+\sum_{i\in I}\log\frac{1-s+s\phi(r_i)}{b_s}.
\tag{G10}
\]

右侧内部坐标项非负；每个外坐标项为正。它保留 outside 的 log s，不把软尾与硬内核当成同一连续公式。可用 −logδmax 替换 −logΔ 得到较弱、只依 x−v 的必要条件；(G5)还给

\[
\Delta=W_\tau(1-W_h/W_\tau),
\tag{G11}
\]

故 −logΔ准确包含 −logWτ 与 −log(1−Wh/Wτ)，不能在来源 C 很小时把二者删掉。这反映“外尾令 K0 小”和“同一来源的 Δ 也小”的共同约束。若 O=∅，(G10)与(G6)一致；s=0 时不用 log s，外硬坐标使 K0=0，仍须满足 αJ<TΔ；不能将 K0=0 当作实际正资格。

(G10)是忽略非负 αJ 后的必要式，并非等价于 ρ>0。准确的(G4)及其 α 仍随整条原行保留。

## 4. 消去接收方向：同一 x,y,v 的物理 C 层几何

仅知 x−v 出 core，不能推出 y−v 的 source score；必须显式控制同坐标 x−y。以下给出这种控制，不把 C 数组与核位置独立指定。

首先 0<φ(r)<1，且 φ 偶递减，所以 F在硬内为1、硬外为φ。于是 C=h*F 满足 C(0)=1、C(r)>0、r>0时严格递减并趋于0。证明可直接用

\[
C'(r)=F(r+1/2)-F(r-1/2)<0\quad\text{a.e. }r>0
\]

与 F 的偶性；即使跨硬跳，C仍绝对连续。故对 c∈(0,1]，反函数 d(c)=C^{-1}(c) 有唯一有限非负值，d(1)=0。

固定 di=|x_i−y_i|，物理 Ci 唯一给 ri^C=d(Ci)=|y_i−v_i|/b。三角关系与偶单调给

\[
K_0(v)\ge K_{out}(d,C):=H^{-n}\prod_i f_s\!\left(\frac{d_i+b\,d(C_i)}H\right),
\]
\[
J(v)\ge J_{out}(d,C):=b^{-n}\prod_i\phi\!\left(\frac{d_i+b\,d(C_i)}b\right).
\tag{G12}
\]

因此每个真实正残余接收源必满足下列只依 x−y 与同一个物理 C 层的约束：

\[
DK_{out}(d,C)+\alpha J_{out}(d,C)<T\Delta(C),
\tag{G13}
\]

且把左侧代入(G4)给有效 ρ 上包络。裸核下界在每个 y_i−v_i 与 x_i−y_i 同号的外向取向同时达到，所以在固定 |y−v|、|x−y|而仅忘掉坐标符号的意义下，这是最强的单调方向消元；没有宣称改变位置后 same-α、good、FIRST 或原来源也可重实现。

它已经是三点而非两点支撑：接收 hard 盒与源 C 层之间的平移量是实际 di。没有小 di 控制时，(G13)可能完全不排除任何 source score；这个补集必须保留。

### 4.1 可直接核整块来源的零支撑/衰减过滤器

给定任意 ci∈(0,1]，取原物理来源盒

\[
\mathcal S_y(c)=\{v:C((y_i-v_i)/b)\ge c_i\ \forall i\}
=\{v:|y_i-v_i|\le b\,d(c_i)\ \forall i\}.
\tag{G14}
\]

令

\[
K_{box}=H^{-n}\prod_i f_s\!\left(\frac{d_i+b\,d(c_i)}H\right),\quad
J_{box}=b^{-n}\prod_i\phi\!\left(\frac{d_i+b\,d(c_i)}b\right),
\]
\[
\delta_{box}=1-\prod_i\min\!\left(1,\frac{\max(c_i,\xi_\tau)}{\xi_h}\right).
\tag{G15}
\]

**物理源盒命题。** 在整个 S_y(c) 上，

\[
\Delta\le\delta_{box},\qquad
\rho\le\eta_{box}:=
\left[1-\frac{DK_{box}+\alpha J_{box}}{T\delta_{box}}\right]_+.
\tag{G16}
\]

δbox=0时该盒Δ=0，按约定ηbox=0，不除零。特别地

\[
DK_{box}+\alpha J_{box}\ge T\delta_{box}
\quad\Longrightarrow\quad
\rho\equiv0\text{ on }\mathcal S_y(c).
\tag{G17}
\]

证明：Kbox、Jbox由(G12)及 d 递减直接下界原核。最大 Δ 不是把 Wτ和 Wh分别极值后相减：固定其他坐标，Ci<ξτ时 Δ随 Ci 非减；ξτ<Ci<ξh 时非增；Ci≥ξh 时不变。因此在 Ci≥ci 的完整物理层盒上，可逐坐标取 Ci=max(ci,ξτ)（高于ξh者任取其允许值），得到(G15)。各坐标独立的空间盒可达到这些 Ci，故 δbox是准确最大值。Kbox与δbox一般不在同一 v 达到，(G16)是保守上包络，未冒称最优共同极值。

例如若任意 ci 的盒满足(G17)，正残余必落在明确并集 ∪i{Ci<ci}。若 ci全等于原score阈值 ξ，则它强制 kξ(v)≥1；等号 Ci=ξ不计入严格score。此 score推论必须连同(G17)的实际 di 条件使用，不能从接收 overflow 单独推出。盒的全部尺度 a/H、b/H、s、same-α都保留，没有 special s0 假设。

## 5. 原账中的零费缩减与未付款补集

这是可作用于一般实际来源的几何必要性与衰减，不是给未付量重命名。对任意有限物理 C 分层，取互斥 ownership cells；它们只划分原积分，绝不把冻结ν替换成新的receiver依赖来源。 每个 cell 用其坐标下端点得到一个包含它的 S_y(c)，端点为0者留作未过滤尾格。对(G17)通过的格，原正接收项的 ρ确实为0，可零费删除；对其他格使用(G16)，所有原来源与权重仍原样积分，且格外/未通过格保留ρ≤1。

例如原正 boundary

\[
\mathcal B_y[A]=\int 1_G\rho\chi_J\left[\int w_t(y,v)\,d\kappa_y(t)\right]d\nu(v)
\]

准确得到

\[
\mathcal B_y[A]\le
\sum_Q\eta_Q\int_Q1_G\chi_J\left[\int w_t(y,v)\,d\kappa_y(t)\right]d\nu(v),
\tag{G18}
\]

未过滤格取ηQ=1；通过零支撑门者ηQ=0。该式保留实际 κ 的初始/删除事件及逆 et，而非固定时间列替换。互斥 cells 只作逐点一次上界，不增加格数费、维数因子、时间费或外测度价格；它本身也不宣称右端已经由 Wβ 或 εX支付。实际 raw 的其余非负因子亦可逐点保留后作相同ρ上界。

整个 signed 行不因此重拆借款：原 C_GG、C_GE、H_Z、R_rev、Rη、删除负项均留在原行；ρ=0接收源没有原正项，却可能仍提供原反向信用，不能在别的 source分支再领取。对(G18)的正 boundary过滤不能自动推出 signed 总缺陷非负。

明确剩余：

- H0<a且 qH<δmax 的内 core；(G8)/(G17)仍未排除者全部保留。
- 至少一个外硬坐标的混合尾，尤其 s>0 时不能用 hard零来消去；仅有(G10)/(G13)必要条件。
- source层盒之外、含任意小 Ci 的尾格、平移 di太大的格、以及(G17)失败的实际正残余格。
- ηQ>0的真实外测度总价、大的 terminal权重比 Xi、high/eg的共同逆数和全部 source/receiver/history相关性。
- R171容量条件失败的signed缺陷；本文没有把已消费suffix重新借出，也没有证明一般bad上尾质量足够。

因此本轮将原一般middle严格缩减到显式的接收混合硬层与物理 C层允许集合，覆盖所有 s与三种截断尺度；没有认证这些剩余集合的统一根阶交通预算。

## 6. 有界检查与状态

阶段一：定位实际 D≥1，核 H0三种截断和全部硬面；阶段二：用 Δ的准确全域帽强化原core排除，并处理混合坐标、s=0零核和 Δ=0退化；阶段三：共享三点坐标消去符号，给准确Δbox与可执行整来源盒过滤器。未做新有限扫描或重复 allfuture/平滑证书。

候选在长证明前送独审；独审已确认(G1)–(G11)的量词、严格边界与D来源。三点盒命题随后单独送审，最终审计意见另由父级文件记录。本稿仅写责任文件，不Git、不spawn、不改他人文件；交付后停止，不以条件几何外推FULL覆盖或一般定理闭合。
