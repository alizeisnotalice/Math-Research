# R172 bounded physical three-point diagnostic

Status: exact implementation plan and scope contract. Goal: locate constructive geometric mechanisms linking terminal amplification to both receiver prices and the residual support. No receiver integral, exponent fit, independent C array, or FULL claim is part of this diagnostic.

## Primary discriminator

Translate the receiver to x=0. Choose actual vectors y,v first; evaluate C_i=C((y_i-v_i)/b), p_y=P_s,L(-y), J_v=P_1,b(-v), Kstar_v=P_s,b(-v), Kstar_y=P_s,b(-y), and K0_v=P_s,Hhat(-v). Preserve the sign of y,v when forming y-v. Even kernels permit abs only AFTER this difference is formed.

For xi(t)=c_j t/b define W_t=product min(1,C_i/xi(t)). Use initial ell=tau=a/c_j unless explicitly comparing a later legal ell. Freeze g=sqrt(LR), hscale=g exp(-u/n), tau<=ell<hscale<g, and xi_g=c_j g/b. Record

    amplification A=log(W_ell/W_g),
    inner price S_v=log(Kstar_v/J_v),
    outer price S_y=log(Kstar_y/p_y),
    Delta=W_tau-W_hscale,
    Dcrit=T Delta/K0_v, when K0_v>0,
    actual_good=(p_y W_g <= K Q_v).

Here Q_v=(P_s,L(-v)+P_s,Lplus(-v)+J_v)/3, Lplus=min(b,(1+1/n)L), T=c_j^(n/2)/(g^n sqrt(1+log n)), Hhat=clip(g c_j^-1/2 (1-s+s phi(1/2))(1+log n)^(1/(2n)),a,b). If K0=0, report Dcrit=+infinity only when Delta>0, otherwise residual is absent. Never take log of a nonpositive value; report zero-kernel cases distinctly.

The informative joint cell has A>0, actual_good, positive Delta and Dcrit above the ACTUAL inherited D, while S_v is below the known fully-paid n log 2 + h branch and S_y is smaller than the terminal amplification. These are candidate geometric pressure cells, not counterexamples or unpaid FULL rows. Report the entire signed triple (A,S_v,S_y), not only a single pass/fail. A sharper useful discriminator is A-S_v and A-S_y together with log Dcrit. This asks where amplification outgrows both simple receiver prices without escaping the residual support. The known inner paid branch uses the uniform Xi<=2^n, so A>S_v alone does not negate that branch.

Authoritative correction from geometry_contract_locators.md: D_n=max{1,epsilon_G sqrt(1+log n)/(8 Lambda)-16/(3 sqrt(1+log n))}, 0<epsilon_G<=1, Lambda=128/119. For every scanned n<=16 the second branch is below1 even at epsilon_G=1, so actual D=1 throughout this bounded range. Retain Dcrit, but the D=1 residual test is now an actual-D necessary test in these dimensions. Actual strict softness is s>1-2^(-1/n), s<=1; record valid_soft separately. Baseline n1,s=.25 fails it and is only scalar analytic geometry. K=1 remains a diagnostic good gate, with theorem-level K unresolved. No actual FULL conclusion follows.

## Legal parameter construction

Normalize b=1,a=1/2; no homogeneity inference beyond this diagnostic. For every n and exact rational L,R in [a,b], g=sqrt(LR) and c_j=(1+1/n)^(-j) must satisfy

    c_(j+1)g <= min(L,R) <= c_j g,
    tau=a/c_j <= g <= b c_j,
    tau < hscale=g exp(-u/n) < g.

Check these numerically with margins, then interval-certify selected cells. Do not use c_j=1 for a geometry assigned j>0. For repeated-coordinate or mixed-coordinate tensors, use physical vector entries and evaluate ALL n-dimensional products from those entries. j is a scale-bin label, not an independent coordinate mixture label. K=1 is the frozen diagnostic value and does not certify all theorem constants. u=1/100 is frozen before source vectors for the baseline, giving h=g exp(-1/(100n)). Initial xi=a/b=1/2; terminal xi=c_j g/b; legal constraints put both in [1/2,1].

## Three bounded stages

Stage 1 — scalar map. n=1,j=0,a=1/2,b=1,L=9/10,R=1,s=1/4,u=1/100,K=1,ell=tau. On the physical signed square (y,v) in [-3/2,3/2]^2 use exact rational spacing 1/8 (25 by 25). Include the two center lines y=0,v=0, the diagonal y=v, inner face lines |v|=19/40,1/2, and kernel support jumps |y|=L/2,|v|=L/2,Lplus/2,Hhat/2,b/2 via separate one-sided samples rather than smoothing across jumps. The mandatory output is a compact scalar map/table of (A,S_v,S_y,log Dcrit,good), plus counts and top joint cells sorted by min(A-S_v,A-S_y) conditional on good and positive residual sensitivity. Do not sort solely by A. Report exact coordinates of selected extrema. A plot is optional; no new plotting software.

Stage 2 — known physical pressure control. Translate the frozen R169/R171 geometry by x0=(51/100,2/5,2/5,2/5), so receiver=0. Inner v are the original three nu locations minus x0. Outer y are ALL four actual beta=f locations minus x0, including completion r=x0+(9/20,...,9/20). Keep n=4,s=1/4,L=9/10,R=1,j=0,u=1/100,K=1. Beta/nu masses may be imported from frozen exact data and reported, but this pair diagnostic does not require mass normalization. All 12 physical pairs must be output, not only favorable pairs. The original fixed q and high flags at x0 may be retained as inherited finite-row context; no new receiver grid, current q(x), or 3/5/7 integral. Reproduce the known two actual high outer rows y=0 and y=(9/20)^4 and state their average-future point comparison separately if reusing it. A pair passing good and Dcrit>D still lacks the same-alpha rho and complete history qualifications.

Stage 3 — wider legal parameter/motif check and selected interval validation. Do not expand the whole 25^2 grid into every dimension. Take the 8 highest Stage1 joint-cell candidates, 4 face/core controls, and all Stage2 pairs. For scalar repeated-coordinate tensors use n in {2,4,8,16}, and s in {1/100,1/10,1/4,1/2,9/10}; L,R pairs from {(9/10,1),(3/4,1),(1/2,4/5)}. For each tuple find the actual admissible integer j in {0,1,2}; reject invalid tuples and count reasons. Also test the baseline n=4 mixed motif with two coordinates from a selected scalar cell and two from its reflected or core control; these are concrete vectors, never independent C values. This is at most a few thousand product evaluations with cached scalar kernels. Do not guess an n-exponent or infer universality from the winners.

Select at most 6 cells: two largest joint-discriminator cells that pass actual_good, two closest residual-threshold cells, and two known-pressure controls. Recompute using existing frozen directed Decimal interval tools at N64 and128; g and c_j are exact interval/rational, Hhat uses interval clipping, and hscale uses the frozen certified exponential. Enclose A,S_v,S_y,Delta,Dcrit,good margin and all scale-bin margins. Where interval logarithm is inconvenient, certify the corresponding positive ratios and store log only as float display. Zero-crossing gates are unresolved, not rounded. Stage3 D=1 is valid on this moderate-dimensional range, but residual classification must still mark strict-soft validity and diagnostic K; a gate crossing an interval endpoint remains unresolved.

## Output and decision discipline

Implementer owns joint_geometry_probe.py/json/md; Sol owns this plan and independent verification. Store parameters, actual y,v,y-v, all scalar coordinate C values, product kernels, W_ell/W_g, W_tau/W_h, TDelta, K0, Dcrit, good margin KQ-pWg, and legal-scale checks. For every main conclusion retain raw quantities as well as logs, source hashes and cached-kernel provenance. Separate accepted, rejected, and ambiguous parameter gates.

Meaningful outcomes: (i) inner/outer price or residual support systematically separates the selected large-amplification cells: a candidate constructive discriminator for Astra; (ii) a nonempty good/residual-sensitive intersection with both prices weak: a concrete physical mechanism requiring additional same-input geometry; (iii) interval uncertainty, unknown D, or invalid legal bin: no mathematical decision. None proves a theorem. The primary deliverable is a small physical list and the geometric reason for its shape, not a catalogue of failed bounds.

No arbitrary Z/deletions, source history, alpha/rho, common f/FIRST or positive-dx construction is synthesized. Their absence is stated once in scope and preserved in interpretation. Existing R165/R166/R168 interval/kernel runtime only; no install, Git, spawning, numerical exponent fitting, or repeated R171 receiver integration.

## Independent scalar distance certificate (Astra request)

The bounded auxiliary script `scalar_distance_certificate.py` writes original directed intervals to its JSON sibling, using N128/256 and only four d values. Its derivation is analytic: w is even and strictly decreasing on positive arguments, phi<1, and phi'(z)=w(z+1/2)-w(z-1/2)<0 for z>1/2. Thus F=1 on the hard core and phi outside. For 0<d<1,

    C'(d)=phi(d+1/2)-1<0,
    C''(d)=phi'(d+1/2)<0.

C(0)=1, so f=-log C is convex on [0,1] with f(0)=0; f(d)/d is nondecreasing. C is strictly decreasing globally. The interval signs at .6501 and .6503 enclose the unique C(d*)=1/2 root within that subinterval of (0,1). Therefore psi(d)=log min(2,1/C(d)) has psi(d)/d nondecreasing until d*, and equals log2/d afterwards, which decreases. The exact global maximum is log2/d*, enclosed by

    1.06588832932484285624 <= max_(d>0) psi(d)/d <= 1.06621624451614414616.

This excludes the simple pointwise unit-rate distance payment psi(d)<=d, while identifying the precise transition geometry. It does not exclude a joint integrated payment or license dropping the hard carrier z, original common FIRST, or 16/3 budget. Both numerator/denominator functions and the maximizer are physical scalar-kernel quantities; no C array was chosen independently.

Authoritative cube discriminator: record H0<a and whether v belongs to the closed Hhat cube. If H0>=a, K0>=T in that cube, so with D>=1 and Delta<=1 the strict residual DK0<TDelta is impossible. For H0<a, that support inference is unavailable; retain the actual ratio Dcrit and scale margins. No numeric row is allowed to override this analytic invariant.

## Final probe audit checkpoint

The physical probe's core product formulas, scale-bin construction, good margin and Dcrit expressions were independently read against this contract. Its final output separates strict softness, Dactual, H0 clipping and cube membership, and retains K=1 as diagnostic. Stage1's scalar leading cell is y=-5/8,v=3/2 (plus reflection): separated outer/inner soft tails allow large amplification with weak receiver prices, while v is outside the Hhat cube. The baseline n1,s=.25 is not actual strict-soft; the selected n16,s=.1/.25 tensor versions are strict-soft.

For the n16,s=.1,L=.9,R=1,j0 repeated-coordinate selected cell, an independent direct call to the frozen interval kernels verifies C(17/8)<.5. Both weight clips are inactive, so cancellation gives R_initial=(2g)^16 exactly, and logR=16 log(2 sqrt(.9)) lies in [10.2474707636965145408557060966163227026600,10.2474707636965145408557060966163227028288]. Since v=1.5 lies outside the b hard cube in every coordinate, S_v=16 log(.1) lies in [-36.8413614879047309442878632749498273216180,-36.8413614879047309442878632749498273216176]. Also S_y=16 log[.9 phi(5/8)/phi(25/36)], which is independent of s. These exact cancellation checks overlap the probe's independently propagated N128 intervals. They explain the selected motif rather than infer an exponent from finite fitting.

This triple mechanism survives the displayed necessary soft/good/residual gates, but it has no same-input high/source-mass or carrier/history construction. The constructive next discriminator must therefore involve those common-input quantities; neither scalar separation nor the cube-support exclusion alone establishes a general bound. The 45-cell affinity trial is reported separately in affinity_trial.md and is explicitly numerical quadrature, not an interval proof.
