# R172 bounded scalar affinity trial

The 45 prescribed scalar cells do not show a uniform contraction for any of the three tested fixed theta values. This is numerical quadrature evidence for the displayed conditional scalar formula, not an interval proof, FULL construction, or receiver/source payment.

For n=512, b=1, a=1/2, d=.6502, the script uses original Hhat and Troot, with t=g exp(-1/n), xi_t=c_j t and initial xi=.5. Equal L,R pairs have j=0. Both mixed pairs (.6,.99),(.99,.6) have the legal j=128; the bin, tau/g and tau/t constraints are checked before integration. All s=.1,.5,1 values satisfy actual strict softness in this dimension.

| theta | Number of cells with numerical Q_theta below 1 | Relevant outcome |
|---|---:|---|
| 0 | 11 of 15 | Four cells already exceed 1 |
| 1/8 | 1 of 15 | Only s=.1,L=.6,R=.99; Q approximately .9653030362 |
| 1/4 | 0 of 15 | All cells exceed 1 |

The largest observed Q is approximately 2.5058300403 at s=1,L=R=.99,theta=1/4. These finite values do not exclude every possible theta or a further restricted source set. They show that this 45-cell list does not support a uniform Q<1 assertion at any tested fixed theta.

The integral is

    Q_theta = Troot^theta min(1,C(d)/.5)^theta
              / sqrt(min(1,C(d)/xi_t))
              * int_R sqrt(P_s,L(x-d) phi(x)) P_s,Hhat(x)^(-theta) dx.

The implementation uses the physical phi expressed through E3=expint(3) and the exact analytic E4 formula for C. It splits at x=±.5, x=d±L/2 and x=±Hhat/2 before Gauss–Legendre integration. The two routine refinements are mp30 order32 on [-48,48] and order64 on [-64,64]. The largest observed absolute Q change is 3.6573e-5. This difference is a convergence diagnostic, not a rigorous quadrature-error enclosure.

The parent-supplied analytic tail comparison is evaluated for each cell. For |x|>B>max(d+L/2,Hhat/2,.5), it gives

    integrand <= C_theta exp(-a_theta |x|),
    a_theta=1/(2L)+1/2-theta/(.9 Hhat) >=4/9,
    C_theta=sqrt(s/(4L)) exp(.5+d/(2L))
            * (s*.09*(1-exp(-1))/Hhat)^(-theta) exp(-theta/1.8).

The omitted integral is at most 2 C_theta exp(-a_theta B)/a_theta, multiplied by the displayed Q prefactor. Its largest displayed value at B64 is below 3.468e-12. The analytic bound is valid as stated; its numeric evaluation here uses mpmath rather than directed intervals. This tail control does not certify the finite-interval quadrature.

Two cells closest to Q=1 were independently recomputed at mp50, order96 on [-72,72]. At s=.1,L=R=.99,theta=0, Q is approximately .9903031133, differing from the routine fine rule by 1.30e-7. At s=1,L=.99,R=.6,theta=0, Q is approximately 1.0114025878, differing by 3.21e-7. Their displayed analytic tail upper bounds are below 1e-31.

Reproduce with `python3 centered-cube-upper-bound/rounds/172/work/affinity_trial.py`. It uses the existing local mpmath installation, writes its JSON beside the script through HERE, records dependency hash and all 45 raw refinements, and installs nothing. No hardcarrier z, original history, common FIRST or actual source measure is discarded or priced by this scalar calculation.
