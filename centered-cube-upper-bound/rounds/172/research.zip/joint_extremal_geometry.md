# R172: fixed-support common decay and the actual J-share positive pair budget

Status: proved geometric comparison and explicit paid branches; the general weak bound remains open. The correlation-aware clock and the direct positive-traffic integration were sharpened jointly with the parent. No new source, posterior, scale selector, or history normalization is introduced.

## 1. Fixed original row and conventions

Fix an original row, including x, y, V, j and every original outer selector. Write ell for its initial far clock and g for its terminal clock. The actual integration interval is a measurable subset of [ell,g]; extending a nonnegative integral to this whole interval is permitted. Put S=Z_{ell+}, with the original finite measure nu on S. S includes bad sources and all sources deleted later. It is never replaced by the support of A or by a currently surviving support.

For ell<=t<=g set

    xi_t=c_j t/b,
    k_t(z)=#{i:C((y_i-z_i)/b)<xi_t},
    w_t(z)=product_i min(1,C((y_i-z_i)/b)/xi_t),
    e_t=int_{Z_t} w_t dnu,   Pi_t=1_{Z_t} w_t nu/e_t.

Endpoint threshold equalities have no effect on any logarithmic-time integral. The physical C is positive at finite arguments; hence all weights on the finite-clock interval are positive. We work on original high rows, where e_g>0. Empty or zero-mass rows contribute zero. Throughout, A is the original fixed terminal mask

    A_v=1_good rho_v J_v/(3Q_v),   0<=A<=1,   {A>0} subset Z_g.

Any sourcewise restriction of A below is fixed throughout the time integration. Original alpha, rho, high, good and Pi are retained. The original boundary is its initial posterior integral plus all actual deletion increments. This manuscript addresses the current original J-share, whose slot is A=1_good rho chi_J with chi_J=J/(3Q). A root source price for the earlier mother remainder without chi_J is not asserted; its K1/K2 reduction ledger remains separate. Section 6 proves only a small-relative-loss receiver absorption branch for that mother traffic. The positive J-share pair integrand is bounded by

    int int A_v delta_+(v,u) Pi_t(dv) Pi_t(du),                 (JG1)

because the remaining original pair gates lie in [0,1]. Here the audited original orientation is delta_+(v,u)=(k_t(v)-k_t(u))_+, with v the A-bearing good slot. The coarser range bound is orientation independent, but the sourcewise bound below uses this precise slot orientation. No signed defect is used to prove the positive estimate.

## 2. Correlation-aware common clock

Define essential extrema with respect to the fixed measure nu restricted to S:

    m(t)=essinf_S k_t,   M(t)=esssup_S k_t,
    d(t)=M(t)-m(t),
    c(t)=exp(-int_ell^t m(r) dr/r),   c(ell)=1,
    v_t(z)=w_t(z)/c(t),   E_t=e_t/c(t).

The letter c here denotes a continuous common clock, not the original constant c_j. Define the score oscillation and the terminal relative loss

    Omega=int_ell^g d(t) dt/t,
    Gamma(z)=int_ell^g [k_t(z)-m(t)] dt/t.                    (JG2)

For nu-almost every z in S, 0<=Gamma(z)<=Omega<=n log(g/ell)<=n log 2.

**Measurability and a common null set.** Since k is jointly measurable and takes values in {0,...,n},

    m(t)=min{a in {0,...,n}:int_S 1_{k_t<=a} dnu>0}

is measurable; the analogous finite formula gives M. For each t, k_t>=m(t) and k_t<=M(t) almost everywhere on S. Tonelli on S times the finite logarithmic-time interval gives one nu-null set outside which these inequalities hold for almost every t. For every remaining z, log w_t(z) is absolutely continuous in log t, with derivative -k_t(z). Therefore log v_t has derivative -(k_t-m)<=0 and v_t is nonincreasing at all times, using its continuous version. Nestedness of Z_t implies E_t is nonincreasing, including every actual deletion. No moving-support essential extrema are used.

All these objects are also measurable in the original outer parameters: the formulas for m and M are measurable integrals of the original jointly measurable indicators and kernels, and integration over [ell,g] is implemented by its measurable interval indicator. Essential suprema of Gamma on {A>0} can equivalently be defined through the countable rational superlevel tests int 1_{A>0}1_{Gamma>r} dnu>0. Thus the row gates below are measurable before integration in x. This uses the original measure-kernel measurability and introduces no selector.

The original posterior is unchanged, exactly:

    Pi_t=1_{Z_t} v_t nu/E_t.                                 (JG3)

The pair score is also unchanged: (k_t(v)-m(t))-(k_t(u)-m(t))=k_t(v)-k_t(u). This is an algebraic normalization, not an alteration of the physical source or of FIRST.

## 3. Exact endpoint and deletion settlement

At each original deletion time t the common clock is continuous, and therefore

    w_t(z) Delta(1/e_t)=v_t(z) Delta(1/E_t).                  (JG4)

Here Delta means the right value minus the left value. Since A vanishes on every source deleted before g, its numerator has no deletion jump. Thus

    B[A]=int A v_ell dnu/E_ell
         +sum_actual_deletions (int A v_t dnu) Delta(1/E_t).

Every increment in this expression is nonnegative. For an infinite deletion sequence use finite partial sums and monotone convergence. Continuous decay of E only enlarges the available total inverse-mass increment, so

    1/E_ell+sum_actual_deletions Delta(1/E_t)<=1/E_g.

Since v_t(z)<=v_ell(z)=v_g(z) exp Gamma(z), pointwise integration gives the stronger sourcewise bound

    B[A]<= (1/e_g) int A_z w_g(z) exp Gamma(z) nu(dz).         (JG5)

In particular, with C_A=int A w_g dnu,

    B[A]<=exp(esssup_{A>0} Gamma) C_A/e_g <=e^Omega C_A/e_g.  (JG6)

There is no deletion count, no additional time-length factor, and no minimum-mass logarithm. An x-dependent clock is used only inside its fixed row; after (JG5) the denominator is the original e_g. This is why the original outer high/FIRST estimate remains applicable.

## 4. Sourcewise direct positive traffic: exp Gamma minus one

For terminal sources define the remaining relative loss

    Gamma_t(z)=int_t^g [k_r(z)-m(r)] dr/r,
    D_t=int_t^g d(r) dr/r.

Monotonicity E_t>=E_g gives

    w_t(z)/e_t <= [w_g(z)/e_g] exp Gamma_t(z).

For a fixed v in Z_g, both posterior slots remain in the full initial support S, and

    int (k_t(v)-k_t(u))_+ Pi_t(du) <= k_t(v)-m(t).

The present theorem uses precisely the audited original J-share orientation stated in (JG1). Let H(v) be any measurable terminal source gate in [0,1], fixed throughout this row's time integration. Tonelli, the preceding two inequalities, and the exact derivative of exp Gamma_t(v) give

    int_actual int int H(v) A_v (k_t(v)-k_t(u))_+ Pi_t² dt/t
      <= (1/e_g) int_{Z_g} H(v) A_v w_g(v)
             int_ell^g [k_t(v)-m(t)] exp Gamma_t(v) dt/t nu(dv)
      = (1/e_g) int_{Z_g} H(v) A_v w_g(v)
                                      [exp Gamma(v)-1] nu(dv).       (JG7)

Other original pair gates can be retained on the left and dropped positively. No new source measure replaces either posterior. The original good condition gives p_y A_v w_g(v)<=K J_v/3. Apply all score inequalities on Z_g subset S before enlarging a positive source integral. Therefore the original J-share obeys

    p_y int_actual pairpositive_J,H dt/t
      <= K/(3e_g) int_{Z_g} H(v) J_v [exp Gamma(v)-1] nu(dv). (JG8)

This is an actual sourcewise inequality, not an unknown-moment hypothesis. The coarser complete-row consequence is K Jnu (exp Omega-1)/(3e_g), because Gamma<=Omega. In particular, when Omega=0 the original pair scores coincide and all such positive traffic vanishes. This entire argument consumes none of the original signed defects or deletion credit.

## 5. Joint source and receiver prices with the exact remaining region

Let W_beta=E sum_V ||beta_V|| and Lambda=128/119. Let Kstar=P_{s,b} and S_v=log(Kstar(x-v)/J(x-v)); Kstar is the common legal future kernel. Fix M>=0 and h real. Split the original terminal sources into these disjoint time-fixed pieces:

    P={Gamma<=M},
    Q={Gamma>M and S-Gamma>=h},
    R={Gamma>M and S-Gamma<h}.                              (JG9)

Gamma may depend on y,V,x,j. Its source gate is legal because it is fixed during this row's time integration and does not change Pi, alpha or the original source. On P, exp Gamma-1<=exp M-1. On Q,

    J(exp Gamma-1)<=J exp Gamma<=exp(-h) Kstar.

Original high p_y e_g>=2Kq, beta<=f and complete FIRST yield

    int_high beta(dy)/e_g
       <= (2Kq)^(-1) int p_y beta(dy) <=1/(2K).

After using (JG8), drop the source indicators only in the positive integrands. The per-V bounds are (exp M-1)Jnu_V/6 and exp(-h)Kstar nu_V/6 respectively. Use the original hard-source cap 16/3 exactly once and the original factor 2Lambda. Retain the unique original j indicator until these bounds have removed all j dependence; only then sum j. The kernel J=P_{1,b} is common in the original a,b window and integrates to one in x. Thus

    RawPositive_Jshare[P]
       <= (16Lambda/9)(exp M-1) W_beta.                      (JG10)

For Q, sum V before integrating x: sum_V nu_V<=f and complete FIRST imply sum_V Kstar nu_V<=q. Hence

    RawPositive_Jshare[Q]
       <= (16Lambda/9)exp(-h) E int_D q dx.                  (JG11)

Combining the exact source partition,

    RawPositive_Jshare[all]
       <= (16Lambda/9)(exp M-1) W_beta
          +(16Lambda/9)exp(-h) E int_D q dx
          +RawPositive_Jshare[R].                          (JG12)

Choose M=(log n)/2+log L_n with L_n>=1, and h=log(16Lambda/(9epsilon)). The first two prices are then at most (16Lambda/9)sqrt(n)L_n W_beta and epsilon E int_D q dx. The remaining source region is exactly Gamma>M and S<Gamma+h; no estimate for that remaining traffic is asserted.

All original history factors remain under their established original domination; no separate sum-of-histories contract is asserted. Common a,b precede V in this window as documented in R171. No free aggregation across distinct windows is claimed. Source restrictions have not duplicated negative credit: (JG10)--(JG12) concern the nonnegative original J-share itself.

Since Gamma<=Omega<=nlog2, this strictly strengthens the geometric threshold used in the R171 boundary argument. The Q gate contains the old condition S>=nlog2+h except for its part already assigned to P. It may reach the previously unamplified region S<nlog2+h when the actual relative loss Gamma is smaller. No positive-measure FULL instance of that intersection is certified here.

## 6. Boundary counterpart and the small-oscillation mother receiver price

For the original boundary, (JG5) yields the same partition with exp M in place of exp M-1 in (JG10), and the unchanged receiver price (JG11). In particular

    RawBoundary[A] <= (16Lambda/9)exp M W_beta
        +(16Lambda/9)exp(-h) E int_D q dx
        +RawBoundary[A 1_R].

This is a separate estimate, not an additional price to add to (JG12). Splitting a boundary does not authorize duplicating signed credit.

There is also a useful distinction for the earlier mother positive traffic, before its J share: its terminal slot is A0=1_good rho rather than A=1_good rho J/(3Q). The same sourcewise proof applies to this [0,1]-valued slot and good gives p_y A0_v w_g(v)<=K Q_v. Consequently

    p_y int pairpositive_mother dt/t
       <= K/e_g int_{Z_g intersect {A0>0}} Q_v [exp Gamma(v)-1] nu(dv).

On the complete-row gate esssup_{A0>0} Gamma<=M0, high yields (exp M0-1)Qnu_V/2. Each K1,K2,J constituting Q is a common legal original future kernel; hence sum_V Qnu_V<=q by FIRST. The same hard and outer factors give

    RawPositive_mother{esssup_{A0>0}Gamma<=M0}
       <= (16Lambda/3)(exp M0-1) E int_D q dx.               (JG12a)

Taking M0=log(1+3epsilon/(16Lambda)) absorbs this complete mother branch with receiver price epsilon E int_D q dx. This is a receiver absorption result, not a root W_beta estimate for the missing K1/K2 shares. For (JG12a) the source-to-source score orientation and other mother pair gates must be the original ones dominated by A0_v(k_v-k_u)_+ as in (JG1); no version with an unrelated slot is asserted. All support bounds are applied before extending Qnu to the whole source.

## 7. Physical and correlation geometry of the paid parameter

For each coordinate use the full initial support to define

    c_i^-=essinf_S C((y_i-z_i)/b),
    c_i^+=esssup_S C((y_i-z_i)/b),
    Omega_coord=sum_i length([log xi_ell,log xi_g]
                                      intersect [log c_i^-,log c_i^+]).

Allow c_i^-=0 and interpret log0=-infinity. The upper extremum is positive on a nonzero row. For almost every t, all coordinates with c_i^+<xi_t are soft for every source, while only coordinates with c_i^-<xi_t can be soft. Hence

    0<=Gamma(z)<=Omega<=Omega_coord<=nlog2.                 (JG13)

The middle inequality may be strict: m and M retain correlation between the coordinates of each actual source. In particular if every source has the same total score k_t at almost every time, Omega=0 even when no individual coordinate has a common threshold. If every source is soft in m0 fixed coordinates already at ell, those coordinates contribute zero to Omega_coord although their uncancelled endpoint weight ratio is (g/ell)^{m0}.

This removes precisely common physical decay, rather than paying an exponential dimensional factor for it. The equal-score cases illustrate the mechanism and do not certify the original high/history constraints. For a genuine source container S subset product_i[l_i,r_i], monotonicity of physical C gives computable bounds

    c_i^+<=C(dist(y_i,[l_i,r_i])/b),
    c_i^->=C(max(|y_i-l_i|,|y_i-r_i|)/b).

The container must contain the whole initial support. Discarding remote or subsequently deleted sources to improve these bounds is not permitted.

## 8. Optimality in the precise common-clock class

Among positive clocks a(t) with a(ell)=1 and log a absolutely continuous in log t, require w_t(z)/a(t) to be nonincreasing for nu-almost every initial z. Let r(t)=-dlog a/dlog t. The same product-measure argument gives r(t)<=k_t(z) for almost every (t,z), and therefore r(t)<=m(t) almost everywhere. It follows that a(g)>=c(g). The reduced endpoint ratio is

    [w_ell(z)/w_g(z)] a(g),

so c minimizes it simultaneously for every source. This proves optimality only within continuous common clocks retaining monotonicity on the full initial support. Updating the support after deletion can make a proposed clock jump downward and its reduced mass jump upward; the telescoping argument would then need an additional variation charge. No such extension is asserted.

## 9. Coverage, checks and remaining bottleneck

(JG10)--(JG12) pay actual positive J-share traffic on a sourcewise partition, including every deletion pattern on each row, and identify the remaining set Gamma>M, S-Gamma<h. The complete-row Omega<=M branch is a sufficient physical criterion for the entire row to lie in P. (JG12a) separately absorbs the small-relative-loss mother branch. On the still unpaid complement Omega>M, the obstacle is genuine source-to-source threshold heterogeneity, not common exponential decay. Neither original FIRST nor the same alpha has yet been proved to bound this complement or force its reverse capacity to dominate its negative load. Beyond the receiver absorption branch (JG12a), root source prices for the other kernel shares and their original reductions remain outside the claim. The desired general epsilon q plus root-source budget is therefore still open.

The independently implemented common_clock_check.py/json/md verifies the normalization, endpoint bound and deletion cancellation in exact rational finite models. Its common-score permutation examples distinguish Omega from the coordinate envelope. These checks are algebraic evidence only; they are not physical-kernel, FIRST, history or FULL certification. The continuous proof above supplies the general fixed-support statement.

No numerical restricted-affinity experiment is used in (JG1)--(JG13). No sourcewise supremum is substituted for an actual source integral in (JG5), (JG7), (JG8) or (JG11). The hard-source carrier is capped only when converting an established row bound to the stated raw price, and its 16/3 cost is counted once.
