#!/usr/bin/env python3
"""Verify archived bytes; replay the four final checks without changing bundle."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys
BASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=Path);args=p.parse_args()
manifest=json.loads((BASE/'inventory.json').read_text())
for name,digest in manifest['files'].items():
    assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==digest,name
print('Archive bytes verified')
if args.verify_only:sys.exit(0)
if args.output_dir is None: p.error('--output-dir is required for replay')
out=args.output_dir.resolve();assert out!=BASE
out.mkdir(parents=True,exist_ok=True)
assert not any(out.iterdir()),'Use an empty output directory'
for name in manifest['files']:shutil.copy2(BASE/name,out/name)
for name in ('common_clock_check','scalar_distance_certificate','joint_geometry_probe','affinity_trial'):
    with (out/(name+'.log')).open('w') as log:
        subprocess.run([sys.executable,str(out/(name+'.py'))],check=True,stdout=log,stderr=subprocess.STDOUT)
    actual=json.loads((out/(name+'.json')).read_text());expected=json.loads((BASE/(name+'.json')).read_text())
    for key in ('runtime','python'):actual.pop(key,None);expected.pop(key,None)
    assert actual==expected,name
    print(name+': all mathematical fields reproduce')
print('PASS; finite evidence only; no PDF compiled')
