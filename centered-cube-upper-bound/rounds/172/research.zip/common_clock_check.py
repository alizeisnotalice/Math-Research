#!/usr/bin/env python3
"""Exact rational finite checks for a common-support clock envelope lemma.

This checks algebra only; it does not model physical kernels, FIRST, or history gates.
"""
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
XI_L = F(1, 2)
XI_G = F(9, 10)


def frac(s):
    return F(s)


def m(c, xi):
    return min(F(1), c / xi)


def wt(Cs, xi):
    out = F(1)
    for c in Cs:
        out *= m(c, xi)
    return out


def bclock(cplus, xi):
    return wt(cplus, xi)


def r(c):
    return m(c, XI_L) / m(c, XI_G)


def asrat(x):
    return f"{x.numerator}/{x.denominator}"


def make_rows(base, nrows, pattern):
    rows = []
    for j in range(nrows):
        if pattern == 3:
            Cs = tuple(base[(i * 3 + j * 2 + (i * j) % 5) % len(base)] for i in range(len(base)))
        else:
            Cs = tuple(base[(i + j * (2 if pattern == 1 else 1)) % len(base)] for i in range(len(base)))
        mass = F((j * 3 + 2) % 11 + 1, j % 5 + 2)
        keep = (j % (3 if pattern == 1 else 4)) != 0
        A = F((j * 5 + 1) % 13 + 1, j % 7 + 2)
        rows.append((mass, A if keep else F(0), keep, Cs))
    return tuple(rows)


def scenarios():
    # Stage 1: every Ci<1/2 in many coordinates; raw endpoint ratio is 1.8^n, E=1.
    for n in (2, 8, 32):
        base = tuple(F(1, 10 + i % 7) for i in range(n))
        yield f"all_below_half_n{n}", make_rows(base, 8, 1), (1, 3, 6)

    # Stage 2: common-soft, common-hard, and transition coordinates; A is unsorted.
    bases = (
        (F(1, 5), F(2, 5), F(3, 5), F(4, 5), F(1), F(7, 10)),
        (F(1, 2), F(9, 10), F(3, 10), F(6, 5), F(4, 5), F(1, 10), F(3, 5), F(2)),
        (F(2, 5), F(1, 2), F(7, 10), F(9, 10), F(11, 10), F(1, 5), F(4, 5), F(3, 5), F(3, 2), F(1, 10)),
    )
    for k, base in enumerate(bases):
        yield f"mixed_{k+1}", make_rows(base, 10, 2), (1, 4, 7)

    # Stage 3: endpoint Ci=.5/.9 and varied rational data, through n=64.
    endpoints = (F(1, 2), F(9, 10), F(1, 3), F(1), F(3, 2), F(1, 5), F(4, 5))
    for n in (1, 3, 7, 16, 31, 48, 64):
        for k in range(2):
            base = tuple(endpoints[(i * (k + 2) + n + i // 3) % len(endpoints)] for i in range(n))
            yield f"wide_n{n}_v{k+1}", make_rows(base, 9, 3), (1, 3, 6)


def run_case(name, rows, delete_after):
    # Each row is one source in the fixed initial support: mass, terminal A, survive flag, rational Ci-vector.
    nrows = len(rows)
    masses = tuple(row[0] for row in rows)
    A = tuple(row[1] for row in rows)
    Crows = tuple(row[3] for row in rows)
    n = len(Crows[0])
    assert all(len(Cs) == n and all(c > 0 for c in Cs) for Cs in Crows)
    assert all((A[i] > 0) == rows[i][2] for i in range(nrows))
    cplus = tuple(max(Cs[j] for Cs in Crows) for j in range(n))
    cminus = tuple(min(Cs[j] for Cs in Crows) for j in range(n))
    all_ids = set(range(nrows))
    stages = [all_ids]
    remaining = set(all_ids)
    delete_groups = []
    deletable = [i for i in range(nrows) if A[i] == 0]
    already = set()
    for j, _ in enumerate(delete_after):
        candidates = [i for i in deletable if i not in already]
        group = candidates[:max(1, (len(candidates) + len(delete_after) - 1) // len(delete_after))]
        already.update(group)
        remaining -= set(group)
        delete_groups.append(group)
        stages.append(set(remaining))
    assert all(A[i] == 0 or i in stages[-1] for i in range(nrows))

    Ecoord = F(1)
    for cmn, cmx in zip(cminus, cplus):
        Ecoord *= r(cmn) / r(cmx)
    oldmax = (XI_G / XI_L) ** n
    assert Ecoord <= oldmax

    # Correlation-aware optimum common clock, computed from the fixed full initial support.
    # m(xi)=min_source #{coordinate Ci<xi}; b(xi)=exp(-integral m dlog xi).
    opt_knots = sorted({XI_L, XI_G} | {c for Cs in Crows for c in Cs if XI_L < c < XI_G})
    opt_segments = []
    for left, right in zip(opt_knots, opt_knots[1:]):
        mid = (left + right) / 2
        mscore = min(sum(c < mid for c in Cs) for Cs in Crows)
        opt_segments.append((left, right, mscore))

    def bopt(xi):
        val = F(1)
        for left, right, mscore in opt_segments:
            stop = min(xi, right)
            if stop > left:
                val *= (stop / left) ** (-mscore)
            if xi <= right:
                break
        return val

    Eopt = max(wt(Cs, XI_L) / wt(Cs, XI_G) * bopt(XI_G) for i, Cs in enumerate(Crows) if A[i] > 0)
    assert Eopt <= Ecoord <= oldmax

    def e(active, xi):
        return sum((masses[i] * wt(Crows[i], xi) for i in active), F(0))

    def ca(active, xi):
        return sum((A[i] * masses[i] * wt(Crows[i], xi) for i in active), F(0))

    def bval(xi):
        return bclock(cplus, xi)

    def kval(Cs, xi):
        return sum(c < xi for c in Cs)

    def dspan(xi):
        ks = [kval(Cs, xi) for Cs in Crows]  # always the fixed initial support
        return max(ks) - min(ks)

    def osc_tail(xi):
        val = F(1)
        for left, right in zip(opt_knots, opt_knots[1:]):
            start = max(xi, left)
            if right > start:
                mid = (left + right) / 2
                ks = [kval(Cs, mid) for Cs in Crows]
                d = max(ks) - min(ks)
                val *= (right / start) ** d
        return val

    # Pi invariance under common b at both endpoints and every deletion support.
    checks = 0
    for xi in (XI_L, XI_G):
        b = bval(xi)
        for active in stages:
            et = e(active, xi) / b
            for i in active:
                assert masses[i] * wt(Crows[i], xi) / e(active, xi) == masses[i] * (wt(Crows[i], xi) / b) / et
                eopt = e(active, xi) / bopt(xi)
                assert masses[i] * wt(Crows[i], xi) / e(active, xi) == masses[i] * (wt(Crows[i], xi) / bopt(xi)) / eopt
                checks += 2

    knots = {XI_L, XI_G}
    for Cs in Crows:
        for c in Cs:
            if XI_L < c < XI_G:
                knots.add(c)
    knots = sorted(knots)
    grid = sorted(set(knots) | {(x + y) / 2 for x, y in zip(knots, knots[1:])})
    monotone_checks = 0
    for i, Cs in enumerate(Crows):
        prev = prevopt = None
        for xi in grid:
            z = wt(Cs, xi) / bval(xi)
            zopt = wt(Cs, xi) / bopt(xi)
            if prev is not None:
                assert z <= prev
                assert zopt <= prevopt
            prev, prevopt = z, zopt
            monotone_checks += 2
    for xi in grid:
        b = bval(xi)
        for before, after in zip(stages, stages[1:]):
            assert e(after, xi) / b <= e(before, xi) / b
            assert e(after, xi) / bopt(xi) <= e(before, xi) / bopt(xi)
            monotone_checks += 2

    # Boundary term: initial normalized A-mass and every reciprocal-normalizer deletion jump.
    B = ca(stages[0], XI_L) / e(stages[0], XI_L)
    Bopt = B
    jump_terms = []
    delete_times = [XI_L + (XI_G - XI_L) * F(ix + 1, len(stages)) for ix in range(len(stages) - 1)]
    for ix, after in enumerate(stages[1:]):
        xi = delete_times[ix]
        before = stages[ix]
        delta = 1 / e(after, xi) - 1 / e(before, xi)
        assert delta >= 0
        # Deleted sources have A=0, so A-mass is unchanged at the deletion event.
        assert ca(after, xi) == ca(before, xi)
        # Common b cancellation at a shared clock: Δ(1/e_tilde)=b(ξ) Δ(1/e).
        b = bval(xi)
        assert (1 / (e(after, xi) / b) - 1 / (e(before, xi) / b)) == b * delta
        bo = bopt(xi)
        assert (1 / (e(after, xi) / bo) - 1 / (e(before, xi) / bo)) == bo * delta
        term = delta * ca(after, xi)
        B += term
        Bopt += term
        jump_terms.append(term)

    eg = e(stages[-1], XI_G)
    CA = ca(stages[-1], XI_G)
    assert eg > 0 and CA > 0
    assert B <= Ecoord * CA / eg
    assert Bopt <= Eopt * CA / eg
    actual_ratio = max(wt(Cs, XI_L) / wt(Cs, XI_G) for Cs in Crows)
    assert actual_ratio <= oldmax

    # Direct positive pair budget for abstract J_v=A_v*w_g(v), p=1, K=3.
    # Test every threshold, midpoint, and actual deletion time with post-deletion support.
    test_times = sorted(set(grid) | set(delete_times))
    positive_rows = []
    for xi in test_times:
        n_deleted = sum(t <= xi for t in delete_times)
        active = stages[n_deleted]
        exi = e(active, xi)
        pis = {i: masses[i] * wt(Crows[i], xi) / exi for i in active}
        ks = {i: kval(Crows[i], xi) for i in range(nrows)}
        P = sum((pis[v] * pis[u] * A[v] * max(ks[v] - ks[u], 0)
                 for v in active for u in active), F(0))
        PiA = sum((pis[v] * A[v] for v in active), F(0))
        d = dspan(xi)
        Etail = osc_tail(xi)
        simple_cap = d * PiA
        rhs = d * (CA / eg) * Etail
        assert P >= 0 and P <= simple_cap and PiA <= (CA / eg) * Etail and P <= rhs
        positive_rows.append({
            "xi": asrat(xi), "active_support_size": len(active), "d_initial_support": d,
            "Pi_A": asrat(PiA), "d_Pi_A_simple_cap": asrat(simple_cap),
            "Eosc_tail": asrat(Etail), "Pi_A_envelope": asrat((CA / eg) * Etail),
            "P_positive_pair_budget": asrat(P),
            "rhs": asrat(rhs), "margin": asrat(rhs - P),
        })
    return {
        "name": name, "dimension": n, "initial_support_size": nrows,
        "deletions_per_event": [len(g) for g in delete_groups],
        "xi_initial": asrat(XI_L), "xi_terminal": asrat(XI_G),
        "E_coordinate_envelope": asrat(Ecoord), "E_optimal_common_clock": asrat(Eopt), "Eosc_full": asrat(osc_tail(XI_L)), "old_maxratio_(xi_g/xi_l)^n": asrat(oldmax),
        "integrated_positive_majorant_factor_Eosc_minus_1": asrat(osc_tail(XI_L) - 1),
        "actual_max_well_over_wg": asrat(actual_ratio),
        "B": asrat(B), "B_opt_clock": asrat(Bopt), "C_A_over_e_g": asrat(CA / eg),
        "Ecoord_C_A_over_e_g": asrat(Ecoord * CA / eg), "Eopt_C_A_over_e_g": asrat(Eopt * CA / eg),
        "boundary_margin_coordinate": asrat(Ecoord * CA / eg - B), "boundary_margin_optimal": asrat(Eopt * CA / eg - Bopt),
        "cplus_fixed_coordinatewise": [asrat(x) for x in cplus],
        "cminus_coordinatewise": [asrat(x) for x in cminus],
        "all_A_support_survives": all(A[i] == 0 or i in stages[-1] for i in range(nrows)),
        "endpoint_Pi_checks": checks, "monotonicity_checks": monotone_checks,
        "common_b_jump_checks": len(jump_terms),
        "positive_budget_time_checks": len(positive_rows),
        "positive_budget_strictly_positive_checks": sum(F(row["P_positive_pair_budget"]) > 0 for row in positive_rows),
        "positive_budget_rows": positive_rows,
    }

def main():
    results = []
    for case in scenarios():
        results.append(run_case(*case))
    out = {
        "title": "Exact rational common-clock/support envelope checks",
        "scope": "finite algebra only; no physical kernel, FIRST, history, or theorem certification",
        "positive_budget_model": "abstract J_v=A_v*w_g(v), p=1, K=3; checks P=sum Pi_v Pi_u A_v (k_v-k_u)_+ against d(xi)*(C_A/e_g)*Eosc_tail(xi)",
        "xi_initial": asrat(XI_L), "xi_terminal": asrat(XI_G),
        "case_count": len(results), "cases": results,
        "all_pass": True,
        "identities_checked": [
            "Pi_i = nu_i wt_i/e = nu_i wt_tilde_i/e_tilde",
            "wt_tilde coordinatewise nonincreasing across threshold/midpoint cells",
            "e_tilde nonincreasing at deletions of terminal-A-zero sources",
            "Delta(1/e_tilde)=b(xi) Delta(1/e) at a common deletion clock",
            "B <= E_coordinate * C_A/e_g and E_coordinate <= (xi_g/xi_ell)^n",
            "fixed-initial-support optimal clock b=exp(-integral min_source k_xi dlogxi); B <= E_opt * C_A/e_g <= E_coordinate * C_A/e_g",
            "P(xi) <= d(xi)*Pi_xi(A) and Pi_xi(A) <= (C_A/e_g)*Eosc_tail(xi), with d=max_initial k-min_initial k",
            "P(xi) <= d(xi)*(C_A/e_g)*Eosc_tail(xi), Eosc_tail=exp(integral_xi^g d(s)dlogs)",
            "FTC finite formula: integral_ell^g d(s)dlogs is the sum d_mid*log(right/left) over all initial-C breakpoints; integrated majorant factor is Eosc-1",
        ],
    }
    (HERE / "common_clock_check.json").write_text(json.dumps(out, indent=2) + "\n")
    print(f"cases={len(results)} all_pass=True endpoint_Pi={sum(x['endpoint_Pi_checks'] for x in results)} monotonicity={sum(x['monotonicity_checks'] for x in results)} jumps={sum(x['common_b_jump_checks'] for x in results)} positive_times={sum(x['positive_budget_time_checks'] for x in results)} positive_nonzero={sum(x['positive_budget_strictly_positive_checks'] for x in results)}")

if __name__ == "__main__":
    main()
