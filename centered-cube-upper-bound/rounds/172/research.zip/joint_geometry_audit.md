# R172 独立联合几何审计

责任范围仅本文件；无 Git、无额外代理，不改作者文件。以下先只读 R172 task_contract，未读本轮作者证明。一般根阶弱型上界仍开放。

## 1. 作者前独立核查：低核归一化与完整硬立方体

记

    m_s=1−s+s phi(1/2)>0,    l_n=1+log n,
    H0=g c_j^(−1/2) m_s l_n^(1/(2n)),
    H=Hhat=clip(H0,a,b),
    T=c_j^(n/2)/(g^n sqrt(l_n)).

直接消去参数有准确恒等式

    T=m_s^n/H0^n,
    K0(x−v)/T=(H0/H)^n product_i [f_s((x_i−v_i)/H)/m_s],
    f_s=(1−s)h+s phi.

phi 偶且正轴递减，h 取原闭 core。因此在整个 n 维闭立方体 `|x_i−v_i|≤H/2 for every i` 上，每个 f_s≥m_s，给

    K0(x−v)≥T(H0/H)^n.

若 H0≥a，则 H=min(H0,b)≤H0，故 K0≥T，包括 H0=a、H0=b 与所有硬面等号。上界 b clipping 只加强该结论。

假定原 D≥1 且 alpha≥0，活跃 rho>0 必须

    T Delta>DK0+alpha J≥DK0≥T

才能发生在此 cube，而 Delta=wtau−wh≤1，矛盾。故在 H0≥a 的实际行，rho>0 强制至少一个坐标严格溢出 H/2。这个结论针对整坐标乘积的闭立方体；它不表示 K0 在整空间≥T，也不是对逐个 overflow 坐标分别套一个 n 维 T。

这里 D≥1 是必须核实的原继承条件，不能由本轮希望如此就补造。alpha≥0 还需原 U≤D K0、同一 K0nu≤q、QJ>0；零来源行沿原约定不造商。当前仅从本轮合同取得定义，D 的实际公式将在必要原定位中单独核验；尚不把它登记为已核原事实。

## 2. H0<a 的例外及整乘积必要条件

若 H0<a，则 H=a>H0。上述 cube 下界仅为 `T(H0/a)^n`，一般小于 T；即使 D≥1，不能把这一行的整个硬 cube 从 rho 支持删掉。一个进一步足够的删除条件是 `D(H0/a)^n≥1`；原合同未自动给这个条件。

在实际 s>0 时，置 `r_i=|x_i−v_i|/H`，令 I={r_i≤1/2}、O={r_i>1/2}。定义

    G_core=sum_I log[f_s(r_i)/m_s]≥0,
    L_out=sum_O log[m_s/(s phi(r_i))]≥0.

实际活跃余项必满足

    log D+n log(H0/H)+G_core−L_out < log Delta≤0.

也就是

    L_out>log D+n log(H0/H)+G_core−log Delta.

此式只忽略非负 alpha J，因而是必要条件，不是 rho>0 的充分条件。若要保留 alpha，应使用 `Delta−alpha J/T>0` 和其对数，不能把该差直接丢掉后称等价。

这准确显示：外坐标的损失须与所有内部坐标的增益一起结算。一个坐标越过硬面不会保证整核已经小于 T；反之 H0<a 时右侧可含负项，不保证存在任何 overflow。s=0 的外坐标 log 无定义，且原实际 soft 下门仍保留，不用纯硬端点生成 FULL 实例。

## 3. 三点几何只允许三角比较，不免费换 score

原 threshold k_t 使用 y−v；低核支持排除使用 x−v；当前 p 使用 x−y。这三个差不能互换。逐坐标唯一直接通用的关系是

    |y_i−v_i|≥||x_i−v_i|−|x_i−y_i||,
    |x_i−v_i|≤|x_i−y_i|+|y_i−v_i|.

所以 `|x_i−v_i|>H/2` 并不单独推出 C((y_i−v_i)/b)<xi_t，也不推出原 delta 正差。要由此迫使某个 source threshold 跨越，还需在同一坐标控制 x−y：例如 `|x_i−y_i|≤r` 且 `H/2−r≥b r_(xi_t)`，利用低核的严格 overflow 才给 `|y_i−v_i|>b r_(xi_t)`。这里 r_xi 是原严格递减 C 的逆，等号方向不能省略。

p_s,L 在 s>0 时没有硬支撑，不能从 p_y>0 推出每个 |x_i−y_i|≤L/2。一般 Hhat≥L 也不在本轮合同中；旧 s=0 特殊支的尺度排序不能迁移。即使拿到不少 overflow 坐标，仍须按同一来源对、原 Pi 和原外测度积分，不生成独立 masks 或自由坐标 Bernoulli。

## 4. 本轮目标边界价的量词与费用义务

目标是实际正边界≤`epsilon E integral_D q dx+C_epsilon sqrt(n)polylog(n)W_beta`，它是待证中间估计，不是完整 signed 解必需的先验性质。不得从一般 signed 解的可能性反推该正边界已经受控。

原 kappa_y 含 y 依赖的初始与真实删除原子，不能用固定 t 的列界逐 y 混合后免价。任何共同 future 对偶包络须在同一输入 f、同一 x 的共同未来菜单上对正在积分的全部 y 成立，或支付其真实连续菜单容量；不得逐 y 另选测试再领同一个 q。

若对 source-v 分割 A，只能免费线性分开正边界；原负项不复制。要声明整个 signed 分支支付，仍须用辅助时间独立的完整行指示同时分配原正项与两类未消费负项，各一次，并处理原 CGG、CGE、HZ 及同 alpha 的 Rrev。H0 支持观察本身不控制这些项。

固定 b、跨 V 共同 s(x) 和 sum nu_V≤f 的原共同窗口允许同一 K*=P_s,b 合并来源；不得免费跨额外窗口。hard16/3一次、signed2Lambda、unique j、真实 J dx 与 W_beta 总质量仍须显示。任何新增按时间分段、源槽选择或尺度菜单，须列出相应端点/总质量/菜单价格。

作者前检查点已保存；下一步只核实实际 D 的必要原定位，然后等指定作者成稿，不扩展历史或反例搜索。


## 5. D 的原实际继承已核：不是本轮新增假设

保存作者前检查点之后，仅为 D 定位实读以下原段（未读 R172 作者稿）：

- R125 `research.zip:proof.md` 62–88，AC1–AC3：实际放大倍数为

      D_n=max{1,epsilon sqrt(l_n)/(8Lambda)−16/(3sqrt(l_n))},
      0<epsilon≤1.

  原行与时间辅助来源积分前固定该倍数，只依 n 和预定 epsilon，明确 D_n≥1。
- R126 `research.zip:proof.md` 62–91：SC 实际行继续采用原 AC2 的同一个 D，原深余权为 `(1−D K0/(T Delta))_+`。回收 RC 系数仍用该实际倍数，不重新逐时间选择。
- R127 `research.zip:proof.md` 244–257：epsilon_RC、epsilon_B 须事先分账，RC 的 D、alpha、b_rec 均按 epsilon_RC 固定；不能定价后重调。与本轮冻结 R170/R171 继承一致。

因此当前原实际 D≥1 有准确原定义支持。原 source contract 的 K0nu≤q 与 U≤D K0 也使 alpha≥0；第1节支持排除可作为原实际行上的定理使用，但仍严格限 H0≥a（或第2节额外 D(H0/a)^n≥1 条件）。该核验未重新领 epsilon 吸收费用，D 的 n 依赖没有变成免费可调参数。

D 必要原定位完成，停等本轮指定作者稿。以上检查点没有将仅一处 overflow 升级为 root 数量或正 delta 付款。


## 6. residual-support 作者准确命题的先行筛查（尚未读长证明）

作者单独送审的增强门加入 `delta_max=1−(tau/hscale)^n`。非零 far 行必须 hscale>tau；逐坐标有 `w_h/w_tau≥tau/hscale`，所以

    Delta=w_tau−w_h
          ≤[1−(tau/hscale)^n]w_tau≤delta_max<1.

因此闭 H hard cube 的更强排除条件确为

    D(H0/H)^n≥delta_max.

含等号也排除，因为 rho>0 要求严格 `D K0/T<Delta`。这比第2节显示的充分门≥1更宽；H0≥a 时仍自动满足，H0<a 时不能免去增强门。hscale=tau 时 Delta=0；hscale<tau 时原 far 窗为空，都不得继续取 log Delta 或将 delta_max 当正数使用。

作者同时提出的混合坐标 log 必要式与本审计第2节一致；whole-coordinate product、inside闭面和 outside严格面方向正确。它只在活跃 Delta>0 上用，忽略 alpha J 后是必要条件而非 rho>0 的等价刻画。共享三点的 `Delta=W_tau(1−W_h/W_tau)` 是恒等式；source C 层与 receiver 硬层可交叉作同一行的几何门，但并不自动给付款。

已把以上范围与 hscale/tau 退化、三点 triangle 限制直接告知作者。此处只认证准确候选及必要不等式，没有预先认证尚未读取的作者成稿。


## 7. 作者前共同时间因子候选：独立数学筛查

以下先核父级准确命题，尚未读 `joint_extremal_geometry.md`。始终固定完整原行和初始右侧支持 Z_initial；原 nu、Pi、A、same-alpha 和原 Delta 均不变。

### 7.1 坐标范围构造

在整个 Z_initial 上取 `cplus_i=esssup_nu C_i`、`cminus_i=essinf_nu C_i`。非零 high 行有 nu(Z_initial)>0；C_i>0，所以每个 cplus_i>0，允许 cminus_i=0。有限个坐标的本质界可在同一个 nu 满测集上同时满足，不要求取到极值。

对 xi∈[xi_initial,xi_g] 定义

    b(xi)=product_i min(1,cplus_i/xi)>0.

对任意 C_i≤cplus_i，比例 `min(1,C_i/xi)/min(1,cplus_i/xi)` 在 xi≤C_i 时为1，在 C_i<xi<cplus_i 时为C_i/xi，在 xi≥cplus_i 时为C_i/cplus_i，故连续且非增。因此 `tildewt=wt/b` 在每个初始来源上非增；结合原 Z_t 递减，`tildee_t=e_t/b(t)` 按测度序/质量非增，包括真实删除。

精确初终比值有

    log(tildew_initial/tildew_g)
      =sum_i length([log xi_initial,log xi_g]
                     intersect [log C_i,log cplus_i])
      ≤Omega_coord
      :=sum_i length([log xi_initial,log xi_g]
                     intersect [log cminus_i,log cplus_i]).

log0 解释为−infinity，再与有限实际时间段相交；Omega_coord有限且≤n log2。闭/开面只影响零长度端点，clipped权在这些面连续。cplus=cminus 时该坐标贡献0。

必须用全部初始 Z 支持确定 cplus；若仅在 G 或 A>0 上取上界，初始 normalizer 中其他来源的 tildewt 可能上升，不能再使用倒数跳望远镜。cminus 的本候选也取同一初始支持，保持声明一致。

### 7.2 原初始项和所有删除的精确抵消

b 连续，删除时

    Delta(1/tildee_t)=b(t) Delta(1/e_t).

于是 tildewt乘新初始/删除倒数原子，逐项恰为原 wt乘原 kappa；Pi和F也精确不变。终端有 `tildeC_A=C_A/b_g`、`tildee_g=e_g/b_g`。应用已经独立验证的单调分子/倒数跳引理，得到

    B_y[A]≤exp(Omega_coord) tildeC_A/tildee_g
           =exp(Omega_coord) C_A/e_g.

连续 b 不能制造额外删除事件；原端点单侧值仍分配一次。多次及同时删除按原合并事件求和，恒等式不受次数影响。需要 b>0，而非对 b 作未核定量正下界。

这只是共同因子消去，原来源和 posterior 均未改变。尤其不能将原捕获定义中的 Delta=wtau−wh 换为 `tildewtau−tildewh`；两者不是共同常数倍，改了会改变 rho、alpha 和原已消费账。此候选保留原 A，所以无需这种替换。

### 7.3 父级最小 score 共同因子的更强版本

在同一整个初始支持取

    m(xi)=essinf_nu k_xi(z),
    b(xi)=exp(−integral_(log xi_initial)^(log xi) m(exp(r))dr).

m 是0,…,n间的可测整数函数：例如 `m≥j` 等价于初始来源上 `nu{k_xi<j}=0`。原联合可测来源核足够，不需要选择最小来源点。Fubini 给 nu-a.e. z 在几乎每个 r 有 k_r(z)≥m(r)；每个 log wt 对 r 绝对连续且导数−k，故这些来源的 log(wt/b) 导数−k+m≤0，得到全时间非增。

若另一个正、对数绝对连续共同因子写成 `b'/b=−mu`，并要求全部初始来源权重除以它之后仍非增，则 mu≤m 几乎处处。因此 m 在这一准确类别内给最大可消去连续速率；这里不声称对只约束当前未删除支持、或另允跳时改因子的更大类别最优。

对活跃集 A>0 的 nu 质量非零时，定义

    E_A=exp[esssup_(A>0) log(w_initial/w_g)
             −integral_(log xi_initial)^(log xi_g) m(exp(r))dr].

其指数非负、有限。它准确等于所构造 tilde 权的最小统一初终比值上界，不是说真实边界积分必取到此费用。活跃集 nu 质量为0时边界为0，可约定 E_A=1，避开空集 esssup。

由 esssup 积分≤积分 esssup，且活跃集包含在初始支持，

    1≤E_A≤exp integral(kmax−kmin)dlogxi
            ≤exp(Omega_coord).

最后一步逐坐标用 `kmax≤sum 1_{cminus_i<xi}`、`kmin≥sum 1_{cplus_i<xi}`；严格面差只在有限坐标端点改变面值，积分方向不受影响。不同坐标间的来源相关性完整保留，因此 score 差范围确可比坐标 box 范围小。

若说“相同 score 导致 E_A=1”，准确条件是整个初始来源支持在整个实际时间段几乎处处具有同一个 k_xi；只在一个时刻 score 相同，或仅活跃来源之间相同，而 initial normalizer 中其余来源不同，均不够。

E_A 的行参数可测性可由计数/有理阈值恢复：令 L(z)=log(w_initial/wg)，则 `esssup_(A>0)L≤r` 等价于 `integral 1_{A>0,L>r}dnu=0`；m 使用上述整数阈值，再作有界积分。原 ell/g、Z_initial 与 nu 的可测核接口保持。没有把 esssup 当作可任意取到的来源选择器。

### 7.4 实际外价与证据定位

同一证明给 `B_y[A]≤E_A C_A/e_g`。在完整行、辅助时间独立的共同分支 E_A≤exp(M) 上，原 good、high/FIRST、一次 hard16/3、signed2Lambda、unique j、固定 b 的 J 真 dx 与原来源总质量沿 R170 原顺序给

    RawBoundary≤(16Lambda/9)exp(M) W_beta.

M≤log(n)/2 时为根阶；坐标 Omega≤log(n)/2 是一个更强的充分门。共同因子可以依整个原行和初始支持；它是逐行恒等重写，不赋予新的 x-independent 来源核性质，也不将此因子移出真实 dx。q、f 与 original Pi 保持原值。

F、pair差 k(v)−k(u) 及 covariance 在减去共同 m 后不变，所以没有额外 score/时间/删除费用。原 signed 缺陷不会因此消失；该式只改进正边界的条件费用。母账分支仍须同时切原正项及两类未消费负项一次。

“除去共同因子不改变归一 posterior”是初等已有归一化恒等式。这里可新增的是把全初始支持的真实 score 共同部分消去，得到明确 E_A/score范围/Omega 的条件几何估计；它严格区别于原裸比值 exp(n) 费用，但尚未推出一般原输入满足小 E_A，也不认证原 history 迭代链或一般根阶闭合。

共同时间因子准确候选先行筛查通过，待成稿后再绑定其最终声明与证明。


## 8. 父级 direct-positive 命题的独立核验与逐来源强化

本节先按准确新命题独立推导，再核作者是否忠实落稿。沿上节同一完整初始支持 S、m(t)，定义

    a_t(v)=k_t(v)−m(t)≥0,
    Gamma_t(v)=integral_t^g a_r(v)dr/r,
    Gamma(v)=Gamma_ell(v),
    D_t=integral_t^g d(r)dr/r.

这些不等式对一个共同 nu 满测集的来源、几乎每个时间成立。原当前和终端 Pi 仍完全不变。

### 8.1 original J-share 正交通可直接结算，无需 signed 假设

`tildee_t≥tildee_g` 严格给

    wt(v)/e_t≤[wg(v)/e_g] exp(Gamma_t(v)).

对原 A=1_good rho chiJ，good 给 `p A wg≤KJ/3`。必须先在原活跃集 G⊂Zg⊂S 上使用 `Gamma_t(v)≤D_t`，然后才能把正 J 积分扩大到全部 nu；若先对初始支持之外的来源也宣称 score 范围界，则量词不成立。

整对原正差有 `delta_plus≤d(t)`，第二份 Pi 总质量为1，Psi/FA/其他原正门均≤1，所以

    p integral_actual pairpositive dt/t
      ≤K Jnu/(3e_g) integral_ell^g d(t) exp(D_t)dt/t
      =K Jnu/(3e_g)(exp(Omega)−1).

最后是绝对连续 exp(D_t) 的准确 FTC；d 可有阈值跳，仍无导数原子。真实删除被共同质量单调 `tildee_t≥tildee_g` 包含，未删除任何 Pi 因子或改变原支持。此直接正积分不需要边界 kappa 重新混合，也未动用原 signed 删除/反向/suffix 信用。

更强地，保留每个活跃 v：原 bad 对 u 仍在 S，k_t(u)≥m(t)，故

    integral_bad delta_plus(v,u)Pi_t(du)≤a_t(v).

由同一 pointwise good 估计及 Tonelli，

    p integral_actual pairpositive_v dt/t
      ≤K/(3e_g) integral_active J_v
                    [integral_ell^g a_t(v) exp(Gamma_t(v))dt/t]nu(dv)
      =K/(3e_g) integral_active J_v [exp(Gamma(v))−1]nu(dv).

这是逐来源准确 FTC，不是把一个 sup 换名为预算。任何对辅助时间冻结的来源子集 `Gamma(v)≤M` 都可在此正项上单独限制，因此其原 raw J-share 价为

    (16Lambda/9)(exp(M)−1)W_beta.

只需 M≥0；M=log(n)/2 给不超过 `(16Lambda/9)(sqrt(n)−1)W_beta`。完整行 Omega≤M 或 E_A≤exp(M) 是更强的充分门；不必要求 R171 signed 上尾容量或排序条件。原负信用全部未用。此点显著区别于仅估计正边界后仍有未付 signed 缺陷的旧结论。

实际代价顺序：先固定完整行与活跃源作原正上界，再 high 下 `integral beta/e_g≤1/(2K)`，然后一次 hard16/3、外 signed2Lambda，得到16Lambda/9；保持唯一 j 到一致行帽后合并，固定 b 的 J 在真实 dx 上积分，原期望 sum||nu||≤W_beta。没有额外 n、log2、删除数或坐标 masks。

### 8.2 J-share 放大来源同样可付 direct-positive 接收价

由逐来源式，若在一个时间固定来源子集中 `S_v−Gamma(v)≥h`，其中 `S_v=log(Kstar_v/J_v)`、Kstar=P_s,b为原共同 future，则

    J_v[exp(Gamma(v))−1]≤J_v exp(Gamma(v))≤exp(−h)Kstar_v.

之后与上轮同样先对完整 beta 作 high 配对，再 sum_V Kstar nu_V≤Kstar f≤q，得到

    RawPositive_Jshare(source subset)
      ≤(16Lambda/9)exp(−h) E integral_D q dx.

这里可以与 `Gamma≤M` 作互斥来源分解；只支付正项，负信用始终原位，没有 sourcewise 分配负信用的问题。价格仍是 q dx，吸收须使用已有原预算；其补集必须保留。这个估计也不移除 J-share 限制。

### 8.3 原无 chiJ 母正项的 epsilon q dx 子支

另为父级准确母式扩展，复核已实读的 R128 `research.zip:proof.md` RT2（613–630）：原 P_rem 对 Sg 的余权是辅助时间冻结的 `rho_r=1−b_rec`，没有 chiJ；FA/Psi 及后续正门只缩小。B=0、Delta>0 的实际余支上它就是当前 rho，其他零交通约定沿原定义。不能仅将 J-share 的系数照抄过去。

原 good 允许

    p rho wg≤K Q rho,

因此对这个母正项同样保留活跃来源后，有

    p I_mother≤K/e_g integral_(active source subset)
                              Q_v rho_v[exp(Gamma(v))−1]nu(dv).

在来源子集 Gamma(v)≤M 上放 rho≤1，得 `K(exp(M)−1)Qnu/e_g`。这里 Q 是该 x 的同一三测试混合，不依正在积分的 y、V；每个组成均为合法 current/future。原共同窗口与 sum nu_V≤f 给

    sum_V Qnu_V≤Qf≤q.

high/FIRST 再付1/(2K)，一次 hard16/3 与外2Lambda合成

    RawPositive_mother{active Gamma≤M}
      ≤(16Lambda/3)(exp(M)−1) E integral_D q dx.

取 `M=log(1+3epsilon/(16Lambda))` 恰为 epsilon E integral q dx，继而≤epsilon lambda|D|，不凭空增加可吸收预算。这个结论对当前原剩余母正项的 sourcewise 子集成立，原其余正门/history/source仍按原合同；不重算 alpha、rho、g，不把早已付部分重新登记覆盖。

Q 的归一化使用的是同一 receiver 上的完整 FIRST，不能把 receiver 自适应的 Q 当作对 x 的概率积分。这里最终是 q dx 价，故不需也未声称 `integral_x Qnu=||nu||`。保持 unique j 后合并，不跨另一个 a,b 窗口。只有 J-share 的 W_beta 价才用固定 J 的空间归一化。

母子支和 J-share 是不同显示价格，若在一个总账中并用须对正来源子集作不交归属，不能把重叠部分当两次新覆盖；全部未消费负项依旧在原完整行。Gamma>M 的母交通、未放大的高 Gamma J-share 与一般全局根阶预算均未证明。


## 9. residual_support_geometry 成稿后审

已先审准确命题、再实读 G1–G18 全稿。首次全稿绑定 SHA256：

    dbce951e347e1ea65166d8c14762bb3d854bcd6f2d7f5e2d92f8c5caad83bc4b

G1–G11 与本审计 §§1–6 一致。G6a 在 H=a 时由 `D(g/a)^n c_j^(−n/2)b_s^n sqrt(l_n)≥delta_max` 取正 n 次根得到，bs 和 s 门的方向正确，须与 H=a 的实际行及全部原 soft 门取交。G8/G8a 的闭接收盒裸 K/J 最小值可在共同角点达到，但其 Delta 只取全域帽；作者未将两者称作同时三点最优。

### 9.1 G12–G13 的三点方向消元

C 的逆存在性由 C 连续、严格偶递减、C0=1、正且趋0取得；并非只从 F 非增未经严格性就猜测逆。d(C_i)=|y_i−v_i|/b 唯一有限，含 C_i=1 的 d=0。

逐坐标 `|x_i−v_i|≤d_i+b d(C_i)`，fs、phi 偶且径向非增，包含 fs 的硬跳，所以 G12 同时下界原 K0 与 J。每个 y_i−v_i 与 x_i−y_i 取相同方向可达到和距离；若某项为0，任意使绝对距离达和的方向都可。这仅是在固定距离而忘掉符号的裸核集合上同时取最小，不是重选原 nu/alpha/good/FIRST 的实现性声明。

alpha≥0 使 `DKout+alpha Jout` 仍是 numerator 下界；正 rho 要求它严格小于 TDelta，给 G13，反之不成立不保证正 rho。保持同一 x,y,v 的真实物理 C 而非独立填写数组，这部分是有效几何收缩。

### 9.2 G14–G17 的准确 Delta_box 最大值

固定其余 C，写 A_other=其他 Wtau 因子乘积、B_other=其他 Wh 因子乘积，0<B_other≤A_other。单坐标 C<xi_tau 时，Delta 对 C 的斜率为

    A_other/xi_tau−B_other/xi_h≥0;

xi_tau<C<xi_h 时斜率为 `−B_other/xi_h≤0`；C≥xi_h 后为常数。因此在 C_i≥c_i 的物理层盒上，可逐坐标取 max(c_i,xi_tau)，使 Wtau 全部因子为1，得到准确

    delta_box=1−product_i min(1,max(c_i,xi_tau)/xi_h).

每个选定值属于(0,1]，可由物理 C 的逆逐坐标实现于完整盒，故这里确是该盒的准确最大，而非分开极值 Wtau 和 Wh 相减。原 nu 支持未必含最大点，不需要它包含。

Kbox/Jbox 在下端 c_i 通过三角距离给原 kernel 下界；一般与 Delta_box 不同点取极值。故 G16 是保守但严格的 rho 上界，G17 的≥包含零 rho 等号。delta_box=0 意味盒上 Delta=0，按原零交通约定置 eta_box=0，不造0/0。

若 c_i=score 阈值，G17 排除整个闭上层盒后，剩余必有一个 C_i<c_i，严格 k 计数方向正确；必须同时使用实际 d_i 与全 kernel 价格，不能由 receiver overflow 单独推出。

### 9.3 G18 的原账范围

互斥 ownership cells 对正 boundary 作一次逐点 rho≤eta_Q 后求和，无独立 cell 预算，所以不产生格数或2^n费。零 rho 格可以删的是该正积分，不是从原 nu、Z_t、e_t 或 Pi 中移除来源。c_i=0 的尾格保留eta=1；原未覆盖格、实际 kappa 初始/删除原子和其他非负外门原位保留。

因此 G18 只是有效的正积分过滤；没有证明其右端 W_beta/qdx 总价，亦没有消除一般大 Gamma/Xi 或不利 signed 缺陷。rho=0 来源仍可能提供原反向信用，不能因正项消失又向别的 source 分支复制负账。正文对此范围清楚。

结论：G12–G18 通过，G1–G11 的核/截断/实际 D 继承通过。G9 展示不等式本身正确；已要求作者把说明中的端点补明为：阈值不高于bs包含全闭 core，bs<阈值≤fs(0)是内 core（s>0），严格外延要求阈值<sphi(1/2)。等号不能经硬跳连续反演。该文字补正不影响 G12–G18 或主要不等式。


## 10. joint_extremal_geometry 成稿后审（整合版）

已实读初稿及整合逐来源 direct-positive、母式的版本。整合版首次全读 SHA256：

    8effb72ab449109a514c430cd5380b25e0be00bf57792239a644ce4f68f6fb0b

JG1–JG13 的数学内容与本审计 §§7–8 独立推导一致，以下按最终主张分类。

1. 全初始 S 的 m、M 通过有界整数阈值测度定义，共同 nu-null 集由 Tonelli 得到。log wt 对 log t 的绝对连续性把几乎处处导数控制提升为连续版本全时单调。E_t=e_t/c(t) 连原删除也非增。原 Pi、score对差、rho/alpha/good 均未改变；未将 c 当作独立于 x 的原来源对象。
2. JG4 的删除倒数原子恰抵消共同因子；JG5 是原正边界的逐来源 exp Gamma 上界，JG6 可用本质上确界。初始、终端和所有删除均计一次，不增时间、层数、最小 e 或删除次数费用。
3. JG7–JG8 明确采用原 `delta=(k_good(v)−k_bad(u))_+`。sourcewise FTC 因为 A 固定于终端而成立，直接支付原正 J-share；不是对 signed 缺陷或无权列收缩的改名。只同一时刻 score 范围、或相反未核 orientation，均不足以推出逐来源式；最终稿已写清原方向。
4. JG9 的 P/Q/R 是互斥、辅助时间固定的来源分区。Gamma 虽依 y/V/x，仍可作为同一正积分门；不改变 nu、Pi、捕获或 FIRST。P 给 `16Lambda/9(exp M−1)W_beta`；Q 给 `16Lambda/9 exp(−h)E integral qdx`。Q 的 y 依赖门是在点态 JexpGamma≤exp(−h)Kstar 后才正上放，故 future 测试保持共同，不是逐 y 自选核。
5. JG12 的剩余恰为 Gamma>M、S−Gamma<h；作者未给它一般总价。取 M=log(n)/2+log L_n、L_n≥1 与显示 h 后，根阶乘 L_n 的常数及 epsilon qdx 正确。原已付吸收额若有限，epsilon仍须原预分，不能由此凭空增加。
6. 边界对应式不是在 JG12 正交通价格之外另加的一笔必要费用。原无 chiJ 母式 JG12a 只给小 Gamma 完整行的 epsilon qdx 价格，不宣称原 K1/K2 份额有 W_beta 根阶价格；其来源下标须保留活跃 A0，先用其 Gamma 门再扩到 Qnu。
7. JG13 的 Gamma≤Omega≤Omega_coord、cminus=0、cplus>0、容器 C 极值及共同连续时钟最优类别均通过。共同 decay 可全部消去并不意味异质来源 decay 也受根阶控制；主稿仍保留这个一般缺口。

初读整合母式显示积分提早扩大到全 Zg，随后只用 esssup_(A0>0)Gamma，已要求保留 `{A0>0}` 下标至应用门后再扩到 Qnu。该处有直接正确的源积分证明（本审计§8.3），但最终稿须明示这一量词，不能仅凭已扩大的显示式推出其后价格。最终 SHA 待这一处与 residual G9 端点修正后追加绑定。

本次一般数学判定来自完整解析证明与原合同。common_clock_check 的有限有理模型、物理网格和 affinity 探索没有被用于推导这些一般界；没有将未查的新数值摘要认证为 FULL 或一般指数证据。


## 11. 最终修正、SHA 绑定与停止

已亲读两处最终修正并重新计算 SHA256：

- `joint_extremal_geometry.md`：

      d99dd1f7583e686ae7073d13611c73965c2924ab84e6bd22f78d48751ff92127

  母式现保留 `Z_g intersect {A0>0}` 到应用 `esssup_(A0>0) Gamma≤M0` 之后，才扩大为 Qnu。第10节所指出的显示量词问题已解决。JG1–JG13、逐来源正交通 JG7–JG12、共同窗口真实来源/接收价格及母式 JG12a 在最终声明范围内全部通过。

- `residual_support_geometry.md`：

      9f29a17b2326c32b23f0d20a8abf45425abddabbad225b638ccf57c7efd87ad1

  G9 已补明阈值≤bs包括全闭 core，s>0且 bs<阈值≤fs(0)为内 core，严格外延须阈值<sphi(1/2)，等号不含严格外点，s=0不跨跳反演。第9节端点修正要求已落实。G1–G18 在必要条件/零支持/正 boundary 过滤的明确范围内全部通过。

最终认证的原实际付款是：J-share 的时间固定来源集 Gamma≤M 有 `16Lambda/9(exp(M)−1)W_beta` 正交通价；其放大来源槽 S−Gamma≥h 有 `16Lambda/9 exp(−h)E integral qdx` 价；原无 chiJ 母正项的小 Gamma 完整行有 `16Lambda/3(exp(M0)−1)E integral qdx` 价。均保留同一原输入、原来源、原 et/Pi、receiver、same-alpha 和所有实际外费，完全未消费 signed 负信用。

没有认证一般高 Gamma 补集预算、全部 K1/K2 份额的根阶来源价、FULL 正体积新实现，或一般弱型上界闭合。必要残余支持几何也没有被当作补集付款。数值证据只保留有限边界，不代替本次解析与原合同审计。

只更新责任文件。指定最终独审完成，停止，不再扩展研究。
