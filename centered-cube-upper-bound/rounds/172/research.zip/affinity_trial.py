#!/usr/bin/env python3
"""45 bounded scalar conditional affinity trials; numerical quadrature, not intervals."""
from pathlib import Path
from fractions import Fraction as F
import sys,math,json,hashlib,time
HERE=Path(__file__).resolve().parent
VENDOR=Path('/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
sys.path.insert(0,str(VENDOR))
import mpmath as mp
mp.mp.dps=30
N=512;D=F(3251,5000);LR=[(F(3,5),F(3,5)),(F(3,4),F(3,4)),(F(99,100),F(99,100)),(F(3,5),F(99,100)),(F(99,100),F(3,5))]
SS=[F(1,10),F(1,2),F(1)];TH=[F(0),F(1,8),F(1,4)]

def M(q):q=F(q);return mp.mpf(q.numerator)/q.denominator
def phi(z):
 z=abs(mp.mpf(z));E=lambda a:mp.mpf('.5') if a==0 else mp.expint(3,a)
 return 1-E(mp.mpf('.5')-z)-E(mp.mpf('.5')+z) if z<=mp.mpf('.5') else E(z-mp.mpf('.5'))-E(z+mp.mpf('.5'))
def C(d):return 1-d+mp.mpf(1)/3-mp.expint(4,1)-mp.expint(4,d)+mp.expint(4,d+1)
def parameters(s,L,R):
 sm,l,r=M(s),M(L),M(R);g=mp.sqrt(l*r);gam=1+mp.mpf(1)/N
 j=int(mp.floor(-mp.log(min(l,r)/g)/mp.log(gam)))
 cj=gam**(-j);cnext=cj/gam;t=g*mp.exp(-mp.mpf(1)/N);xi=cj*t
 ell=1+mp.log(N);Troot=mp.sqrt(cj)/g*ell**(-mp.mpf(1)/(2*N))
 H0=g/mp.sqrt(cj)*(1-sm+sm*phi(mp.mpf('.5')))*ell**(mp.mpf(1)/(2*N));H=max(mp.mpf('.5'),min(1,H0))
 margins=[min(l,r)-cnext*g,cj*g-min(l,r),g-mp.mpf('.5')/cj,cj-g,t-mp.mpf('.5')/cj]
 assert all(z>=-mp.mpf('1e-28') for z in margins)
 return dict(s=sm,L=l,R=r,g=g,j=j,cj=cj,t=t,xi=xi,Troot=Troot,H0=H0,H=H,scale_margins=margins)

def quadrature(par,order,B):
 # All hard and phi formula faces are split before a smooth Gauss-Legendre rule.
 cuts=sorted(set([-mp.mpf(B),mp.mpf(B),-mp.mpf('.5'),mp.mpf('.5'),M(D)-par['L']/2,M(D)+par['L']/2,-par['H']/2,par['H']/2]))
 nodes,weights=mp.gauss_quadrature(order,'legendre');out=[mp.mpf(0)]*3
 for a,b in zip(cuts[:-1],cuts[1:]):
  for z,w in zip(nodes,weights):
   x=(a+b)/2+(b-a)*z/2
   py=((1-par['s'])*(abs(x-M(D))<par['L']/2)+par['s']*phi((x-M(D))/par['L']))/par['L']
   jx=phi(x);k0=((1-par['s'])*(abs(x)<par['H']/2)+par['s']*phi(x/par['H']))/par['H']
   base=mp.sqrt(py*jx)*(b-a)*w/2
   for k,theta in enumerate(TH):out[k]+=base*k0**(-M(theta))
 return out

def tail(par,theta,B):
 t=M(theta);c0=mp.mpf('.09')*(1-mp.exp(-1));l=par['L'];h=par['H'];s=par['s']
 rate=1/(2*l)+mp.mpf('.5')-t/(mp.mpf('.9')*h)
 const=mp.sqrt(s/(4*l))*mp.exp(mp.mpf('.5')+M(D)/(2*l))*(s*c0/h)**(-t)*mp.exp(-t/mp.mpf('1.8'))
 assert B>max(M(D)+l/2,h/2,mp.mpf('.5')) and rate>=mp.mpf(4)/9
 return 2*const*mp.exp(-rate*B)/rate,rate,const

def text(z):return mp.nstr(z,28)
def main():
 start=time.monotonic();cd=C(M(D));rows=[]
 for s in SS:
  for L,R in LR:
   p=parameters(s,L,R);vals=[quadrature(p,order,B) for order,B in ((32,48),(64,64))]
   for k,theta in enumerate(TH):
    t=M(theta);pref=p['Troot']**t*min(1,cd/mp.mpf('.5'))**t/mp.sqrt(min(1,cd/p['xi']))
    q=[pref*z[k] for z in vals];tails=[pref*tail(p,theta,B)[0] for B in (48,64)]
    rows.append(dict(s=str(s),L=str(L),R=str(R),theta=str(theta),n=N,j=p['j'],c_j=text(p['cj']),g=text(p['g']),xi_t=text(p['xi']),tau_xi='1/2',Troot=text(p['Troot']),H0=text(p['H0']),Hhat=text(p['H']),
      scale_margins=[text(z) for z in p['scale_margins']],strict_soft_pass=bool(p['s']>1-mp.power(2,-mp.mpf(1)/N)),C_d=text(cd),prefactor=text(pref),
      refinements=[dict(order=o,B=B,integral_truncated=text(vals[i][k]),Q_theta_truncated=text(q[i]),analytic_Q_tail_upper=text(tails[i])) for i,(o,B) in enumerate(((32,48),(64,64)))],
      quadrature_abs_change=text(abs(q[1]-q[0])),Q_theta_numerical=text(q[1]),Q_theta_numeric_plus_analytic_tail=text(q[1]+tails[1]),
      tail_rate=text(tail(p,theta,64)[1]),numerical_decision=('below_one' if q[1]+tails[1]<1 else 'at_or_above_one')))
 # Selected independent mp50 rule at order96/B72, chosen by closeness to Q=1.
 selected=sorted(rows,key=lambda z:abs(mp.mpf(z['Q_theta_numerical'])-1))[:2]
 checks=[]
 for row in selected:
  with mp.workdps(50):
   p=parameters(F(row['s']),F(row['L']),F(row['R']));theta=F(row['theta']);k=TH.index(theta)
   v=quadrature(p,96,72)[k];cd50=C(M(D));pref=p['Troot']**M(theta)*min(1,cd50/mp.mpf('.5'))**M(theta)/mp.sqrt(min(1,cd50/p['xi']))
   checks.append(dict(parameters={k:row[k] for k in ('s','L','R','theta','j')},dps=50,order=96,B=72,Q_theta=text(pref*v),absolute_difference_from_mp30_order64=text(abs(pref*v-mp.mpf(row['Q_theta_numerical']))),analytic_Q_tail_upper=text(pref*tail(p,theta,72)[0])))
 out=dict(scope='45 conditional physical scalar affinity trials; numerical quadrature with analytic tail bound, not an interval proof or FULL/source/history/carrier payment.',
  formula='Troot^theta min(1,C(d)/.5)^theta /sqrt(min(1,C(d)/xi_t)) int sqrt(P_s,L(x-d) phi(x)) P_s,Hhat(x)^(-theta) dx',
  parameters=dict(n=N,a='1/2',b='1',d=str(D),u='1',s=list(map(str,SS)),LR_pairs=[[str(l),str(r)] for l,r in LR],theta=list(map(str,TH))),
  arithmetic='mpmath 30-digit expint(3)/expint(4), split Gauss-Legendre orders32/64; two selected independent mp50 order96 checks. No directed interval quadrature.',
  dependencies={str(Path(mp.__file__)):hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()},
  tail_derivation=dict(phi_upper='phi(r)<=.5 exp(-(r-.5))',phi_lower='phi(r)>=.09(1-exp(-1)) exp(-(r-.5)/.9)',domain='r>=.5; tails |x|>B>max(d+L/2,Hhat/2,.5)',rate='a_theta=1/(2L)+.5-theta/(.9Hhat)>=4/9',bound='2 C_theta exp(-a_theta B)/a_theta; C_theta as parent formula, multiplied by prefactor for Q'),
  rows=rows,selected_mp50_checks=checks,
  summary=dict(cell_count=len(rows),below_one=sum(z['numerical_decision']=='below_one' for z in rows),max_Q=max(float(z['Q_theta_numerical']) for z in rows),max_quadrature_change=max(float(z['quadrature_abs_change']) for z in rows)),
  limitations=['Quadrature errors are observations, not rigorously enclosed.','Tail bound is analytic; its displayed numeric evaluation uses mpmath, not directed intervals.','No receiver/source integral, hardcarrier z, same-input FIRST/history or FULL claim.','Legal j is chosen separately for each mixed L,R pair.'],
  runtime=dict(seconds=round(time.monotonic()-start,3),python=sys.version,mpmath=mp.__version__))
 (HERE/'affinity_trial.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['summary'],indent=2))
if __name__=='__main__':main()
