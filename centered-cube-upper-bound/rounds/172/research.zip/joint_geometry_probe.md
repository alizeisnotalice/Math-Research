# R172 physical three-point geometry probe

This is a finite diagnostic of the physical kernel triple at receiver (x=0). For each row, the signed vector difference (y-v) is formed before evaluating the even (C)-kernel. It does not establish a receiver integral, common-source history, FIRST, or FULL coverage.

## Stage 1: scalar geometry

The baseline (n=1,j=0,s=1/4,L=9/10,R=1,u=1/100) fails the required strict softness condition (s>1-2^{-1/n}). This stage is therefore scalar analytic geometry only. The signed (25\times25) grid on ([-3/2,3/2]^2), with spacing (1/8), found 474 actual-good cells, 600 positive-(\Delta) cells, and 226 cells simultaneously actual-good, positive-(\Delta), and (D_{crit}>1).

The leading pair is (y=-5/8,v=3/2), with its reflected partner. It has (A=\log(W_\ell/W_g)=0.6405520), (S_v=\log(K^*_v/J_v)=-1.3862895), (S_y=\log(K^*_y/p_y)=0.0177212), and (\log D_{crit}=0.8867836). Its actual-good margin is enclosed by ([0.0359933,0.0361596]). Here (H_0\ge a=1/2), but (v\notin\widehat H), so the cube implication (K_0\ge T\Rightarrow D_{crit}\le\Delta\le1) does not apply. One-sided controls around the support and scale faces are retained in the JSON.

## Stage 2: translated R169 source pairs

All 12 pairs from the three original source atoms and the actual completion atom were translated by (x_0) and evaluated at the baseline (n=4,j=0,s=1/4,L=9/10,R=1). The coarse screen used the frozen directed interval kernel at subdivision parameter (N=16); six pairs passed the high-ratio test (p_y e_g/(2q)>1). The detailed pairs, interval masses and gates are in `stage2.rows`. The R171 point-certificate comparison is attached as a source record rather than recomputed as a separate theorem.

## Stage 3: legal motifs and refinements

The screen checked 2,745 parameter/candidate combinations. There were 855 legal scale rows and 537 rows passing strict softness; the baseline (n=4,s=1/4) is strict-soft. Repeated-coordinate candidates, physical face/core controls, all 12 actual four-vector pairs, and one mixed motif were included. The top valid-soft, actual-good, positive-residual screen rows are separately listed, with (H_0\) versus (a\), cube membership, and residual gates. Six selected cells received (N=64,128) interval refinements. The screen uses (N=16), and φ range for (\widehat H\) is fixed at 64 subdivisions for all rows; these are finite diagnostics, not a convergence claim for every row.

For every (n\le16), the inherited formula

\[
D_n=\max\left\{1,\frac{\varepsilon_G\sqrt{1+\log n}}{8\Lambda}-\frac{16}{3\sqrt{1+\log n}}\right\},\qquad 0<\varepsilon_G\le1,\quad\Lambda=128/119,
\]

has upper correction below 1, so (D_n=1). The code records this interval check per row. (K=1) remains diagnostic. Whenever (H_0\ge a) and (v\in\widehat H), the code checks (K_0/T\ge1), (\Delta\le1), and (D_n\ge1); such a row cannot be an actual positive residual. The full finite outputs preserve ambiguous or failing gates rather than treating them as successes.

## Reproduction and limits

Run from the repository root with:

```sh
python3 centered-cube-upper-bound/rounds/172/work/joint_geometry_probe.py
```

The script imports the installed frozen R168 kernel and R166 interval runtime and reads the R169 completion and R171 point certificates. Their absolute paths and SHA-256 hashes are stored in `joint_geometry_probe.json`. No packages are installed. The JSON is the reproducibility record, including stage maps, actual source coordinates, intervals, gates, runtime and selected refinements.

This probe does not construct (\alpha/\rho), a common (f/FIRST), a (Z)-history or deletion boundary, or a positive receiver measure. It does not integrate over receivers and makes no FULL or theorem claim.
