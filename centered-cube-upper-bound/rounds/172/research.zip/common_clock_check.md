# Common support-clock finite exact check

This artifact checks the fixed-support normalization algebra with exact rational arithmetic. It does not check physical kernels, FIRST, any history gate, or the full theorem.

The finite model has an initial finite support (S), source weights ν_z, rational coordinate data (C_{z,i}>0), and
\[
w_\xi(z)=\prod_i\min(1,C_{z,i}/\xi),\qquad e_\xi=\sum_{z\in Z_\xi}\nu_z w_\xi(z),\qquad \Pi_\xi(z)=\nu_z w_\xi(z)/e_\xi.
\]
Only sources with terminal (A_z=0) are removed, so the fixed (A>0) support survives. At a fixed clock, the deletion jump in the boundary sum is
\[
\bigl(e_{+}^{-1}-e_{-}^{-1}\bigr)\sum_{z\in Z_+} A_z\nu_z w_\xi(z).
\]

Two common clocks were checked. The coordinate envelope uses fixed initial-support extrema (c_i^- = \min_{z\in S}C_{z,i}), (c_i^+=\max_{z\in S}C_{z,i}), (b_{\rm coord}(\xi)=\prod_i\min(1,c_i^+/\xi)), and
\[
E_{\rm coord}=\prod_i\frac{r(c_i^-)}{r(c_i^+)},\qquad r(c)=\frac{\min(1,c/\xi_\ell)}{\min(1,c/\xi_g)}.
\]
The correlation-aware clock keeps the *entire initial support* fixed: (k_\xi(z)=\#\{i:C_{z,i}<\xi\}), (m(\xi)=\min_{z\in S}k_\xi(z)), and (b_{\rm opt}(\xi)=\exp(-\int_{\xi_\ell}^{\xi}m(s)\,ds/s)). On rational breakpoints this is a finite product of rational powers. Its exact envelope is
\[
E_{\rm opt}=\max_{z:A_z>0}\frac{w_{\xi_\ell}(z)}{w_{\xi_g}(z)}b_{\rm opt}(\xi_g)\le E_{\rm coord}\le(\xi_g/\xi_\ell)^n.
\]
At every deletion clock the common (b(\xi)) cancels exactly:
\[
\Delta(1/(e/b))=b(\xi)\,\Delta(1/e).
\]
For either clock the normalized source weights (w/b) and total (e/b) are nonincreasing between breakpoints and across the permitted deletions, while Π is unchanged. The checked boundary sum obeys (B[A]\le E_{\rm opt}\,C_A/e_g\), where (C_A=\sum_{Z_g}A_z\nu_z w_g(z)).

The script ran 20 cases with ξℓ=1/2 and ξ_g=9/10: three all-soft cases at dimensions 2, 8, and 32; three mixed cases with source vectors that are coordinate permutations of a common score multiset; and fourteen varied finite cases through dimension 64 including endpoint values (C=1/2,9/10). Cases include unsorted positive (A), multiple deletions of (A=0) sources, and full initial-support extrema held fixed throughout.

All exact assertions passed: 2,400 Π-invariance identities, 2,240 monotonicity checks on threshold/midpoint cells and deletion supports, and 60 exact common-clock jump cancellations. In the all-soft cases, (E_{\rm coord}=E_{\rm opt}=1) even though the uncancelled worst-case endpoint ratio is ((9/5)^n). In the permutation-correlated cases (E_{\rm opt}=1), while (E_{\rm coord}>1); this demonstrates why retaining the common source correlation can improve the envelope. The output preserves exact rational (B), (C_A/e_g), both envelopes, and margins case by case.

Run with `python3 common_clock_check.py`; machine-readable exact outputs are in [common_clock_check.json](common_clock_check.json). A passing finite check is evidence only for these rational finite models and the encoded identities, not certification of the general lemma or its application to the original problem.

## Direct positive pair budget extension

The same cases now also check the positive quantity for the abstract calibration (J_v=A_vw_g(v)), (p=1), (K=3):
\[
P(\xi)=\sum_{v,u\in Z_\xi}\Pi_\xi(v)\Pi_\xi(u)A_v\,(k_\xi(v)-k_\xi(u))_+.
\]
Here (k_\xi(z)=\#\{i:C_{z,i}<\xi\}) and both extrema defining (d(\xi)=\max_{z\in S}k_\xi(z)-\min_{z\in S}k_\xi(z)) are over the **fixed initial support**, including already deleted sources. At a deletion clock the computation uses the post-deletion support. (A=0) on every removed source, and all (A>0) sources remain in (Z_g).

For each sampled threshold, interval midpoint, and deletion time, exact fractions verify
\[
P(\xi)\le d(\xi)\Pi_\xi(A),\qquad \Pi_\xi(A)\le \frac{C_A}{e_g}E_{\rm osc,tail}(\xi),\qquad
E_{\rm osc,tail}(\xi)=\exp\!\left(\int_\xi^{\xi_g}d(s)\,\frac{ds}{s}\right).
\]
The integral is evaluated as an exact rational product over the initial-(C) breakpoints; no quadrature is used. The integrated majorant has the finite FTC identity
\[
\int_{\xi_\ell}^{\xi_g}d(\xi)E_{\rm osc,tail}(\xi)\,\frac{d\xi}{\xi}=E_{\rm osc}-1.
\]
Thus the exact integrated majorant is ​( E_{\rm osc}-1 )C_A/e_g for this normalized model. The FTC identity is reported as a breakpoint product calculation, not as numerical integration certification. Across the suite, 126 sampled positive-budget checks passed; 71 had (P>0), and all 71 had strictly positive exact slack. The other 55 had (d=P=0). Each row and its exact margin are preserved in the JSON.

These finite checks test the direct positive algebra and its proposed envelope on selected rational models. They do not prove the all-time inequality or its application to physical kernels, FIRST/history constraints, or the full theorem.
