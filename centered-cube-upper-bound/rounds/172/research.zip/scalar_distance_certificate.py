#!/usr/bin/env python3
"""Bounded C(d)=1/2 and capped logarithmic slope certificate; stdlib interval runtime."""
from pathlib import Path
from fractions import Fraction as F
import importlib.util, hashlib, json, sys
HERE=Path(__file__).resolve().parent
DEP=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round168_20261016_final_checkpoint/lp_candidate_certificate.py')
s=importlib.util.spec_from_file_location('r172_scalar_frozen',DEP);ct=importlib.util.module_from_spec(s);s.loader.exec_module(ct)
I=ct.I
LEFT=F(6501,10000);RIGHT=F(6503,10000)

def run(N):
    points=[F(1,2),LEFT,RIGHT,F(1)]
    cells=[dict(d=str(d),C=ct.iv.C(d,N).out()) for d in points]
    lo=ct.iv.C(LEFT,N);hi=ct.iv.C(RIGHT,N)
    assert lo.lo>F(1,2) and hi.hi<F(1,2)
    ln2=ct.log2_interval()
    # Use monotonicity of reciprocal d: the exact maximizer d* is in [LEFT,RIGHT].
    maximum=I((ln2/I(RIGHT)).lo,(ln2/I(LEFT)).hi)
    assert maximum.lo>1
    return dict(subdivisions=N,cells=cells,root_bracket=[str(LEFT),str(RIGHT)],
        log2_interval=ln2.out(),global_max_psi_over_d=maximum.out(),
        decisions=dict(root_strictly_between_endpoints=True,global_max_exceeds_unit_rate=True))

def main():
    proof=[
      'w is even, positive, strictly decreasing on (0,infinity), and has integral 1. Thus phi(z)=int_(z-1/2)^(z+1/2)w(r)dr is strictly below 1, and phiprime(z)=w(z+1/2)-w(z-1/2)<0 for z>1/2.',
      'F is even and nonincreasing on [0,infinity), equals 1 on [0,1/2], and equals phi outside that interval. Consequently C is strictly decreasing for d>0 (piecewise derivative of its moving-window integral).',
      'For 0<d<1, C(d)=int_(d-1/2)^(d+1/2) F(r)dr, so Cprime(d)=phi(d+1/2)-1<0 and Csecond(d)=phiprime(d+1/2)<0.',
      'C(0)=1. Therefore f(d)=-log C(d) is convex on [0,1], with f(0)=0, and f(d)/d is nondecreasing for 0<d<=1.',
      'The interval signs put the unique root C(d*)=1/2 inside (LEFT,RIGHT), a subset of (1/2,1).',
      'For d<=d*, psi(d)=-log C(d), and psi(d)/d is nondecreasing. For d>=d*, monotonicity of C gives psi(d)=log2, hence psi(d)/d decreases.',
      'Consequently the global maximum over d>0 is exactly log2/d*. This is a scalar physical-kernel statement, not a FULL/history/carrier bound.'
    ]
    out=dict(scope='Scalar physical C kernel certificate only; no triple/source/FIRST or hardcarrier conclusion.',
       definition='psi(d)=log(min(2,1/C(d))), d>=0; psi(0)/0 interpreted by right limit only.',
       analytic_derivation=proof,
       inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [DEP,Path(ct.DEP)]},
       arithmetic='Frozen directed Decimal interval C and rational Taylor log2; no float bounds.',
       refinements=[run(128),run(256)],python=sys.version,
       consequence='A unit scalar distance-tail exponent does not pointwise dominate psi(d) for all d: max psi(d)/d>1. This does not decide a joint integrated estimate.')
    target=HERE/'scalar_distance_certificate.json';target.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(output=str(target),final=out['refinements'][-1]),indent=2))
if __name__=='__main__':main()
