# 第172轮：共同衰减消去与逐来源正交通的极值几何预算

日期：2026-10-16。一般 n^(1/2+o(1)) 一致弱型上界仍未闭合。本轮主要成果是直接支付原正交通的几何估计，不把反例排除或新命名的余项当作闭合。

## 原合同及证明范围

使用任意正 L1 共同输入 f、原 FIRST、同一窗口 a≤L,R≤b≤2a、原来源 nu_V≤beta_V、sum beta_V≤f dx。q 为共同 current 值，全部合法 future 值≤q。原 high 为 p_y e_g≥2Kq，good 为 p_y w_g≤KQ，Q=(K1+K2+J)/3，J=P_{1,b}。保留同一 alpha、rho、真实接收 dx、原 hard-source h_R f/q≤16/3、外系数2Lambda，Lambda=128/119。详细定义和历史定位见 task_contract.md 与 geometry_contract_locators.md。

原初始支持 S=Z_{ell+} 包括所有后来删除和坏来源；不可用活跃或幸存来源代替。令 k_t(z) 为原严格软坐标数，m(t)=essinf_S k_t，c(t)=exp(-int_ell^t m(r)dr/r)。所有本轮结论在原合同内成立，没有提供独立的新 FIRST 或历史求和定理。

## 本轮严格结果

1. w_t/c(t) 对每个初始来源单调，e_t/c(t) 包括删除也单调。原 Pi 完全不变，删除原子满足 w_t Delta(1/e_t)=(w_t/c)Delta(c/e_t)。定义 Gamma(v)=int_ell^g(k_t(v)-m(t))dt/t。原边界≤e_g^{-1}int A w_g exp(Gamma)dnu。共同衰减被精确消去；所有来源共享同一分数轨迹时 Gamma=0，即便逐坐标不共享同一阈值。
2. 关键直接正估计：对原 good v 槽、任意时间固定来源门 H，原非负 pair 由 H(v)A_v(k_t(v)-k_t(u))_+ Pi² 控制，其时间积分≤e_g^{-1}int HA w_g(exp(Gamma)-1)dnu。证明使用 k_t(v)-m(t) 以及 exp(剩余Gamma) 的准确导数，没有先付 n 再积分，也不消耗任何原负项信用。
3. 对 J-share，令 S_v=log(P_{s,b}(x-v)/J(x-v))。互斥分支 P={Gamma≤M}，Q={Gamma>M,S_v-Gamma≥h}，R 为余集。则正交通≤(16Lambda/9)(exp(M)-1)W_beta +(16Lambda/9)exp(-h)E int_D q dx +原R正交通。取 M=(log n)/2 得第一项≤(16Lambda/9)(sqrt(n)-1)W_beta；h=log(16Lambda/(9epsilon)) 得第二项 epsilon E int q dx。这是原 J 分量的有效分支预算，不是全部母交通的根阶证明。
4. 无 chi_J 的原母正项，在完整行 esssup_{A0>0}Gamma≤M0 上，费用≤(16Lambda/3)(exp(M0)-1)E int q dx。M0=log(1+3epsilon/(16Lambda)) 给 epsilon 接收吸收。独审还证明对应来源子集版本，主稿采取更保守的完整行表述。Q 依接收点自适应，故这里只用 sum Qnu≤q，不声称其空间积分等于来源质量。
5. 物理三点过滤：残差 rho 的 core 排除必须检查 H0 截断。C 严格径向递减可逆，固定真实 |x-y| 与 C(y-v)，三角不等式同时给 K0、J 的准确方向最小值。在 C_i≥c_i 盒上，Delta 的准确最大值为 1-product min(1,max(c_i,xi_tau)/xi_h)。因此得到保守但严格的零/衰减残差盒。一般并非 K、J、Delta 在同一点同时极值，不能声称完整极值实现。见 residual_support_geometry.md G1–G18。

主证明、独审和详细 LaTeX 分别见 joint_extremal_geometry.md、joint_geometry_audit.md、proof.tex.txt。common clock 的最优性仅限初始全支持上保持所有归一权单调、log clock绝对连续的共同钟类；移动支持钟可能产生新的变差费用，不在本定理内。

## 全部费用及剩余问题

逐来源时间积分的费用是 exp(Gamma)-1，无额外 n、log2、删除次数、质量下限或格子数费用。high 配对提供1/(2K)，good 提供K/3或K，原 hard16/3与外2Lambda各用一次。保留唯一j指示直至所得上界不依j，再合并；不同a,b窗口没有免费相加。来源门不修改nu/Z/Pi/alpha，所有未使用负信用留在原完整行。母式与J式若合并，必须先作互斥归属，不能重复记账。

未付的是一般来源异质性：J-share中 Gamma>M 且 S_v-Gamma<h；母式还包括较大Gamma以及K1/K2缺乏来源质量根阶预算的部分。物理盒过滤未证明其积分可付，原共同 FIRST、高列亏损和同一alpha尚未给出这些补集的统一根阶控制。跨窗口、原全部函数类最终回代也未完成。没有宣称FULL正测度新实例或一般上界闭合。

## 数值探路与决策

- 初步物理网格25×25：474 good诊断、600正Delta、226共同通过good/Delta/Dcrit。n1,s=.25不满足实际strictsoft，明确仅作标量几何。K=1始终是诊断，不替代定理K。
- 历史压力测试：12个翻译后的R169真实来源对，粗N16；保留全部合法门，6个high-ratio通过。没有合成共同alpha/history。
- 扩大：2745候选检查，855尺度合法、537strictsoft；6个选择单元用N64/128区间细化。真实外尾三点说明独立距离或core排除不够；共同钟揭示共享软衰减应抵消而非指数付款。有限探路不是阶数拟合。
- 精确钟证书：20个有理模型，n2至64；2400个Pi恒等式、2240个单调检查、60次删除消去，126个正交通检查，其中71个严格正。包括同分数置换、不同分数、阈值等号及删除。它们验证代数实现，不合成物理核/FIRST；一般结论由连续证明给出。
- 标量区间证书N128/256：C(d*)=1/2的d*在(.6501,.6503)，准确全局最大log2/d*在[1.0658883293,1.0662162446]。仅排除单位率逐点距离付款，不否定联合积分路线。
- 45个条件亲和积分试验：n512，3个s、5对L/R、3个theta；32/64点分段积分、2个50位96点复核。12/45数值<1；最大2.50583。theta=1/4全>1，因此不采纳该统一收缩策略。尾部有解析上界，内部求积误差未区间认证，不充当定理。

## 复现、人员和规模

四个最终脚本由 reproduce.py 在空输出目录重放；比较JSON全部数学字段，仅排除runtime/python。依赖已有冻结R165/166/168核、R169/171数据和本机mpmath，其路径/哈希在证书内；非独立便携包。不安装新软件、不编译PDF。主代理实际结果见 parent_verification.md。

本轮使用1 Astra high、2 Sol high、1 Sol medium及2 Luna medium，各自有互不冲突文件责任；没有为凑满8人创建重复任务。Sol独审先审命题后读稿，Luna不认证关键引理。使用64项工具中共同几何核/两赢家范围审计等已加载工具；未借用缺失的私有GP-BRANCH定理。可见累计goal计数是跨轮总量，缺少按模型真实扣额，本轮不猜成本比或节省金额。

只新增本轮README及research.zip，更新项目索引。所有工作文件在清理前逐字节备份仓库外，包内有inventory哈希。阶段性有限失败保留必要结论与复现，未扩张反例目录。
