#!/usr/bin/env python3
"""R172 finite physical three-point geometry probe; no receiver/FULL claim."""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal
from functools import lru_cache
import hashlib, importlib.util, json, math, platform, sys, time

HERE=Path(__file__).resolve().parent
R168=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round168_20261016_final_checkpoint')
R169=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round169_20261016_final_checkpoint')
R170=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round170_20261016_final_checkpoint')
R171=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round171_20261016_final_checkpoint')
TOOL=R168/'lp_candidate_certificate.py'
COMPLETION=R169/'completion_certificate.json'
POINT171=R171/'numeric_point_certificate.json'
spec=importlib.util.spec_from_file_location('r172_frozen_kernel',TOOL)
ct=importlib.util.module_from_spec(spec);spec.loader.exec_module(ct)
iv=ct.iv; I=ct.I
NU=[F(3,25),F(2749,3125),F(1,3125)]
Q=F(9,2500); K=F(1); LAMBDA=F(128,119); A_SCALE=F(1,2); B_SCALE=F(1); U=F(1,100); EPS=F(1,1000)
X0=[F(51,100),F(2,5),F(2,5),F(2,5)]
POS=[[F(53,50)]+[F(19,20)]*3,[F(-3,5)]*4,X0]
RPOS=[x+F(9,20) for x in X0]

@lru_cache(None)
def Cval(d,N): return iv.C(abs(F(d)),N)
def mid(x): return float((x.lo+x.hi)/2)
@lru_cache(None)
def log_rational_cached(q): return ct.log_rational(F(q))
def logI(x):
    if x.lo<=0: return None
    return I(log_rational_cached(str(x.lo)).lo,log_rational_cached(str(x.hi)).hi)
def logmid(x):
    if x.lo<=0:return None
    return math.log(mid(x))
def prod(xs):
    z=I(1)
    for x in xs:z=z*x
    return z
def W(Crow,xi): return prod([(z/I(xi)).capped_one() for z in Crow])
def exp_pos(x):
    """Directed interval exp(x) from the frozen certified exp(-x) runtime."""
    assert x.lo>=0
    lo=F(x.lo);hi=F(x.hi)
    return I((I(1)/ct.iv.exp_neg(hi)).lo,(I(1)/ct.iv.exp_neg(lo)).hi)
def exp_any(x):
    def endpoint(z):
        zz=F(z)
        if zz>=0:
            e=ct.iv.exp_neg(zz)
            return I((I(1)/e).lo,(I(1)/e).hi)
        return ct.iv.exp_neg(-zz)
    return I(endpoint(x.lo).lo,endpoint(x.hi).hi)
def log_pos(x): return ct.log_interval(x)
def pow_pos(x,r): return exp_any(log_pos(x)*r)
def clip_interval(x,lo,hi):
    return I(max(I(lo).lo,min(I(hi).lo,x.lo)),max(I(lo).hi,min(I(hi).hi,x.hi)))
@lru_cache(None)
def _kernel_cached(s,slo,shi,deltas,N): return ct.kern(F(s),I(Decimal(slo),Decimal(shi)),list(deltas),N)
def kernel(s,scale,deltas,N):
    z=I(scale)
    return _kernel_cached(str(F(s)),str(z.lo),str(z.hi),tuple(F(d) for d in deltas),N)
def vec_sub(a,b): return tuple(F(x)-F(y) for x,y in zip(a,b))
def vec_str(v): return [str(x) for x in v]
def ivstatus(x,positive=False):
    if positive:
        if x.lo>0:return 'pass'
        if x.hi<=0:return 'fail'
        return 'ambiguous'
    if x.lo>=0:return 'pass'
    if x.hi<0:return 'fail'
    return 'ambiguous'
def interval_float(x): return {'interval':x.out(),'mid':mid(x)}

@lru_cache(None)
def legal_scales(n,s,L,R,j,u=U):
    cj=F(n,n+1)**j; cjp=F(n,n+1)**(j+1)
    g=(I(L)*I(R)).sqrt(); ell=I(1)+I(log_rational_cached(str(F(n))).lo,log_rational_cached(str(F(n))).hi)
    ph=ct.phi_range(I(F(1,2)),64)
    factor=I(1-s)+I(s)*ph
    ellroot=pow_pos(ell,F(1,2*n))
    H0=g*(I(1)/I(cj).sqrt())*factor*ellroot
    Hhat=clip_interval(H0,A_SCALE,B_SCALE)
    h0_vs_a='ge_a' if H0.lo>=I(A_SCALE).hi else ('lt_a' if H0.hi<I(A_SCALE).lo else 'ambiguous')
    soft_margin=I(s)-I(1)+exp_any(-log_pos(I(2))/F(n))
    valid_soft=ivstatus(soft_margin,positive=True)
    # Inherited D_n is max{1, eps_G sqrt(ell)/(8 Lambda)-16/(3 sqrt(ell))}, 0<eps_G<=1.
    d_upper=ell.sqrt()/(I(8)*I(LAMBDA))-I(16)/(I(3)*ell.sqrt())
    Dactual=I(1) if d_upper.hi<I(1).lo else I(1,d_upper.hi if d_upper.hi>I(1).hi else I(1).hi)
    tau=A_SCALE/cj; hscale=g*ct.iv.exp_neg(u/F(n))
    m=min(L,R)
    margins={
      'bin_lower':I(m)-I(cjp)*g,
      'bin_upper':I(cj)*g-I(m),
      'tau_to_g':g-I(tau),
      'g_to_b_cj':I(B_SCALE*cj)-g,
      'tau_to_h':hscale-I(tau),
      'h_to_g':g-hscale}
    legal=all(v.lo>=0 for v in margins.values())
    rejected=any(v.hi<0 for v in margins.values())
    status='pass' if legal else ('fail' if rejected else 'ambiguous')
    T=exp_any(log_pos(I(cj))*F(n,2)-log_pos(g)*F(n)-log_pos(ell)/2)
    Lplus=min(B_SCALE,(F(1)+F(1,n))*L)
    return dict(n=n,s=F(s),L=F(L),R=F(R),j=j,cj=cj,cjp=cjp,g=g,tau=tau,hscale=hscale,
        Lplus=Lplus,H0=H0,H0_vs_a=h0_vs_a,Hhat=Hhat,T=T,ell=ell,margins=margins,legal_status=status,
        soft_margin=soft_margin,valid_soft=valid_soft,Dactual=Dactual,d_upper=d_upper)

def compute(n,s,L,R,j,y,v,N=32,u=U,keep_raw=True,cert_logs=False):
    par=legal_scales(n,F(s),F(L),F(R),j,u)
    # Physical y-v difference is formed with sign before the even C kernel is evaluated.
    diff=vec_sub(y,v); Ccoord=[Cval(abs(d),N) for d in diff]
    cj=I(par['cj']); ell0=par['tau']; g=par['g']; hscale=par['hscale']
    xi_tau=cj*I(ell0)/I(B_SCALE); xi_h=cj*hscale/I(B_SCALE); xi_g=cj*g/I(B_SCALE)
    Wtau=W(Ccoord,xi_tau); Wh=W(Ccoord,xi_h); Wg=W(Ccoord,xi_g); Well=W(Ccoord,cj*I(A_SCALE/cj)/I(B_SCALE))
    delta=vec_sub([F(0)]*len(y),y); deltav=vec_sub([F(0)]*len(v),v)
    py=kernel(s,I(L),delta,N)
    Jv=kernel(F(1),I(B_SCALE),deltav,N)
    Kstarv=kernel(s,I(B_SCALE),deltav,N)
    Kstary=kernel(s,I(B_SCALE),delta,N)
    K0v=kernel(s,par['Hhat'],deltav,N)
    K1v=kernel(s,I(L),deltav,N)
    K2v=kernel(s,I(par['Lplus']),deltav,N)
    Qv=(K1v+K2v+Jv)/I(3)
    goodmargin=I(K)*Qv-py*Wg
    Delta=Wtau-Wh
    cube_margin=par['Hhat']/I(2)-I(max(abs(F(z)) for z in v))
    K0_over_T=K0v/par['T']
    cube_no_residual=('certified' if par['H0_vs_a']=='ge_a' and ivstatus(cube_margin) == 'pass' and K0_over_T.lo>=1 and Delta.hi<=1 and par['Dactual'].lo>=1 else 'not_applicable_or_unresolved')
    if K0v.hi==0:
        Dcrit=float('inf') if Delta.lo>0 else None
        Dcrit_status='positive_delta_zero_K0_infinite' if Delta.lo>0 else 'residual_absent_zero_K0'
    elif K0v.lo<=0:
        Dcrit=None; Dcrit_status='unresolved_zero_K0_interval'
    else:
        Dcrit=par['T']*Delta/K0v; Dcrit_status='finite'
    if isinstance(Dcrit,float) and math.isinf(Dcrit): actual_residual_status='pass'
    elif Dcrit is None: actual_residual_status=None
    else: actual_residual_status=('pass' if (Dcrit-par['Dactual']).lo>0 else ('fail' if (Dcrit-par['Dactual']).hi<=0 else 'ambiguous'))
    Wratio=None if Wg.lo<=0 else Well/Wg
    rv=None if Jv.lo<=0 else Kstarv/Jv
    ry=None if py.lo<=0 else Kstary/py
    Aiv=None if not cert_logs or Wratio is None or Wratio.lo<=0 else logI(Wratio)
    Sviv=None if not cert_logs or rv is None or rv.lo<=0 else logI(rv)
    Syiv=None if not cert_logs or ry is None or ry.lo<=0 else logI(ry)
    logA=logmid(Wratio) if Wratio is not None else None
    logSv=logmid(rv) if rv is not None else None
    logSy=logmid(ry) if ry is not None else None
    actual_good=ivstatus(goodmargin)
    residual='absent' if Delta.hi<=0 else ('positive' if Delta.lo>0 else 'ambiguous')
    out=dict(n=n,j=j,s=str(F(s)),L=str(F(L)),R=str(F(R)),u=str(F(u)),y=vec_str(y),v=vec_str(v),y_minus_v=vec_str(diff),
        C_coordinates=[z.out() for z in Ccoord],
        c_j=str(par['cj']),g=par['g'].out(),tau=str(par['tau']),hscale=par['hscale'].out(),H0=par['H0'].out(),H0_vs_a=par['H0_vs_a'],Hhat=par['Hhat'].out(),Lplus=str(par['Lplus']),
        valid_soft=par['valid_soft'],strict_soft_margin=par['soft_margin'].out(),D_actual=par['Dactual'].out(),D_upper_for_epsilonG_le_1=par['d_upper'].out(),
        xi_tau=xi_tau.out(),xi_h=xi_h.out(),xi_g=xi_g.out(),W_ell=Well.out(),W_g=Wg.out(),W_tau=Wtau.out(),W_h=Wh.out(),
        Delta=Delta.out(),T=par['T'].out(),TDelta=(par['T']*Delta).out(),K0_v=K0v.out(),Dcrit=('+inf' if isinstance(Dcrit,float) and math.isinf(Dcrit) else (None if Dcrit is None else Dcrit.out())),Dcrit_status=Dcrit_status,
        p_y=py.out(),J_v=Jv.out(),Kstar_v=Kstarv.out(),Kstar_y=Kstary.out(),K1_v=K1v.out(),K2_v=K2v.out(),Q_v=Qv.out(),
        good_margin=goodmargin.out(),actual_good=actual_good,residual_sensitivity=residual,
        Dcrit_gt_1_sensitivity=('pass' if isinstance(Dcrit,float) and math.isinf(Dcrit) else (None if Dcrit is None else ivstatus(Dcrit-I(1),positive=True))),actual_residual_gate=actual_residual_status,
        cube_margin=cube_margin.out(),K0_over_T=K0_over_T.out(),cube_no_residual_check=cube_no_residual,
        log_A=logA,log_Sv=logSv,log_Sy=logSy,
        A_minus_Sv=None if logA is None or logSv is None else logA-logSv,
        A_minus_Sy=None if logA is None or logSy is None else logA-logSy,
        scale_gate_status=par['legal_status'],scale_margins={k:z.out() for k,z in par['margins'].items()},
        log_Dcrit=None if Dcrit is None or (isinstance(Dcrit,float) and math.isinf(Dcrit)) or Dcrit.lo<=0 else logmid(Dcrit),
        log_intervals=None if not cert_logs else {'A':None if Aiv is None else Aiv.out(),'Sv':None if Sviv is None else Sviv.out(),'Sy':None if Syiv is None else Syiv.out()})
    if keep_raw:
        out['_intervals']={'A':None if Aiv is None else Aiv,'Sv':None if Sviv is None else Sviv,'Sy':None if Syiv is None else Syiv}
    return out

def strip_private(x):
    if isinstance(x,dict):return {k:strip_private(v) for k,v in x.items() if not k.startswith('_')}
    if isinstance(x,list):return [strip_private(z) for z in x]
    return x

def main():
    start=time.monotonic()
    # Stage 1 exact scalar grid, with explicit one-sided controls at physical support faces.
    n,s,L,R,j=1,F(1,4),F(9,10),F(1),0
    par1=legal_scales(n,s,L,R,j)
    grid=[F(-3,2)+F(k,8) for k in range(25)]
    base=[]
    for y in grid:
        for v in grid:
            base.append(compute(n,s,L,R,j,(y,),(v,),N=24))
    hhat1=(F(par1['Hhat'].lo)+F(par1['Hhat'].hi))/2
    Lp1=par1['Lplus']; thresholds=sorted(set([F(19,40),F(1,2),L/2,Lp1/2,hhat1/2,B_SCALE/2]))
    one_sided=[]
    for threshold in thresholds:
        vals=sorted(set([-threshold,-threshold-EPS,-threshold+EPS,threshold,threshold-EPS,threshold+EPS]))
        for coord in vals:
            if abs(coord)>F(3,2):continue
            for y,v in [(coord,F(0)),(F(0),coord),(coord,coord)]:
                one_sided.append(dict(face=str(threshold),sample_type='one_sided_or_exact',**compute(n,s,L,R,j,(y,),(v,),N=24)))
    def eligible_row(r):
        # Stage 1 is explicitly scalar analytic geometry; n=1,s=1/4 fails actual strict softness.
        return r['actual_good']=='pass' and r['residual_sensitivity']=='positive' and r['Dcrit_gt_1_sensitivity']=='pass' and r['log_A'] is not None
    joint=[r for r in base if eligible_row(r)]
    joint.sort(key=lambda r:min(r['A_minus_Sv'] if r['A_minus_Sv'] is not None else -math.inf,
                               r['A_minus_Sy'] if r['A_minus_Sy'] is not None else -math.inf),reverse=True)
    counts={'grid_total':len(base),'actual_good':sum(r['actual_good']=='pass' for r in base),
        'Delta_positive':sum(r['residual_sensitivity']=='positive' for r in base),
        'A_positive':sum(r['log_A'] is not None and r['log_A']>0 for r in base),
        'Dcrit_gt_1_sensitivity':sum(r['Dcrit_gt_1_sensitivity']=='pass' for r in base),
        'joint_good_Delta_positive_Dcrit_gt_1':len(joint)}
    print(json.dumps({'stage':'stage1 discriminator before widening','counts':counts,'top_joint_cells':[{'y':r['y'],'v':r['v'],'A':r['log_A'],'Sv':r['log_Sv'],'Sy':r['log_Sy'],'log_Dcrit':r['log_Dcrit'],'good_margin':r['good_margin'],'H0_vs_a':r['H0_vs_a'],'cube_no_residual_check':r['cube_no_residual_check']} for r in joint[:12]],'valid_soft_baseline':base[0]['valid_soft']},indent=2),flush=True)
    # Stage 2 all 12 physical R169 source pairs at receiver x=0 after translating x0 to zero.
    x0=[F(51,100),F(2,5),F(2,5),F(2,5)]
    inners=[tuple(a-b for a,b in zip(p,x0)) for p in POS]
    outers=[tuple(a-b for a,b in zip(p,x0)) for p in POS+[RPOS]]
    comp=json.loads(COMPLETION.read_text()); mlo,mhi=map(Decimal,comp['refinements'][-1]['exact_added_mass_interval'])
    # Interval mass is imported unchanged; actual mass formula provenance is the frozen R169 certificate.
    beta_mass_intervals=[[str(z),str(z)] for z in NU]+[[str(mlo),str(mhi)]]
    stage2=[]
    for yi,y in enumerate(outers):
        for vi,v in enumerate(inners):
            # All actual source pairs are screened coarsely; selected rows are refined below.
            r=compute(4,F(1,4),F(9,10),F(1),0,y,v,N=16)
            wg=[]
            Cpair=[Cval(abs(a-b),64) for a,b in zip(y,v)]
            gg=I(r['g'][0],r['g'][1])
            wgv=W(Cpair,I(F(1))*gg)
            # e_g(y): sum nu(v) W_g(y,v) over all original inner atoms.
            for vv in inners:
                cc=[Cval(abs(a-b),64) for a,b in zip(y,vv)]
                wg.append(W(cc,gg))
            eg=sum((I(m)*z for m,z in zip(NU,wg)),I(0))
            py=I(r['p_y'][0],r['p_y'][1]); highratio=py*eg/I(2*Q)
            r.update(source_index=yi,inner_index=vi,beta_mass_interval=beta_mass_intervals[yi],
                e_g=eg.out(),high_ratio=highratio.out(),high_status=ivstatus(highratio-I(1),positive=True),
                x0_original_source_position=vec_str((POS+[RPOS])[yi]),inner_original_position=vec_str(POS[vi]),
                translated_y=vec_str(y),translated_v=vec_str(v),translated_y_minus_v=vec_str(vec_sub(y,v)))
            stage2.append(r)
    print(json.dumps({'stage':'stage2 actual translated source-pair screen','rows':len(stage2),
        'high_pairs':sum(r['high_status']=='pass' for r in stage2),'softness':'baseline n=4,s=1/4 status '+legal_scales(4,F(1,4),F(9,10),F(1),0)['valid_soft']},indent=2),flush=True)
    # Independent average-future versus old-sup comparison on the two actual high rows.
    point=json.loads(POINT171.read_text())
    prior_rows=point['refinements'][-1]['rows']
    high_comparison={'source':'frozen R171 numeric_point_certificate.json at same x0; N=128 directed intervals',
        'rows':[{'source_index':r['source_index'],'position':r['position'],'beta_mass':r['beta_mass'],
                 'high_ratio':r['high_ratio'],'average_gate':r['average_gate'],'old_sup_gate':r['old_sup_gate'],
                 'decisions':r['decisions']} for r in prior_rows]}
    # Stage 3 candidate bank: eight scalar discriminators, four physical face/core controls, and all stage-2 pairs.
    # A scalar candidate list is selected by joint discriminator, then filled by positive-Delta/good score if needed.
    all_disc=[r for r in base if r['actual_good']=='pass' and r['residual_sensitivity']=='positive' and r['log_A'] is not None]
    all_disc.sort(key=lambda r:min(r['A_minus_Sv'] if r['A_minus_Sv'] is not None else -math.inf,
                                   r['A_minus_Sy'] if r['A_minus_Sy'] is not None else -math.inf),reverse=True)
    scalar8=all_disc[:8]
    if len(scalar8)<8:
        extra=[r for r in base if r not in scalar8 and r['actual_good']=='pass' and r['log_A'] is not None]
        extra.sort(key=lambda r:r['log_A'],reverse=True); scalar8+=extra[:8-len(scalar8)]
    controls=[(F(0),F(0)),(F(0),F(19,40)),(L/2-EPS,F(0)),(hhat1/2+EPS,F(0))]
    control_rows=[compute(1,s,L,R,0,(y,),(v,),N=24) for y,v in controls]
    scalar_candidates=[]
    for k,r in enumerate(scalar8):scalar_candidates.append(dict(label=f'scalar_{k}',y=F(r['y'][0]),v=F(r['v'][0]),category='stage1_top'))
    for k,r in enumerate(control_rows):scalar_candidates.append(dict(label=f'face_core_{k}',y=controls[k][0],v=controls[k][1],category='face_core_control'))
    screen=[]
    stage3_legal_counts={'pass':0,'fail':0,'ambiguous':0}; stage3_soft_counts={'pass':0,'fail':0,'ambiguous':0}
    param_LR=[(F(9,10),F(1)),(F(3,4),F(1)),(F(1,2),F(4,5))]
    dimensions=[2,4,8,16]; s_values=[F(1,100),F(1,10),F(1,4),F(1,2),F(9,10)]
    for cand in scalar_candidates:
        for nn in dimensions:
            yy=(cand['y'],)*nn; vv=(cand['v'],)*nn
            for ss in s_values:
                for LL,RR in param_LR:
                    for jj in range(3):
                        par=legal_scales(nn,ss,LL,RR,jj)
                        stage3_legal_counts[par['legal_status']]+=1
                        if par['legal_status']!='pass':continue
                        stage3_soft_counts[par['valid_soft']]+=1
                        r=compute(nn,ss,LL,RR,jj,yy,vv,N=16)
                        r.update(candidate=cand['label'],candidate_category=cand['category'],motif='repeated_coordinate')
                        screen.append(r)
    # All 12 physical pairs are tested at the actual n=4 mixed source positions across legal parameter tuples.
    for pidx,(y,v) in enumerate([(y,v) for y in outers for v in inners]):
        for ss in s_values:
            for LL,RR in param_LR:
                for jj in range(3):
                    par=legal_scales(4,ss,LL,RR,jj)
                    stage3_legal_counts[par['legal_status']]+=1
                    if par['legal_status']!='pass':continue
                    stage3_soft_counts[par['valid_soft']]+=1
                    r=compute(4,ss,LL,RR,jj,y,v,N=16)
                    r.update(candidate=f'stage2_pair_{pidx}',candidate_category='stage2_physical_pair',motif='actual_four_vector')
                    screen.append(r)
    # One n=4 concrete mixed motif: two coordinates from the best scalar candidate, two from the core (0,0) control.
    if scalar_candidates:
        mc=scalar_candidates[0]; ym=(mc['y'],mc['y'],F(0),F(0)); vm=(mc['v'],mc['v'],F(0),F(0))
        for ss in s_values:
            for LL,RR in param_LR:
                for jj in range(3):
                    par=legal_scales(4,ss,LL,RR,jj)
                    stage3_legal_counts[par['legal_status']]+=1
                    if par['legal_status']!='pass':continue
                    stage3_soft_counts[par['valid_soft']]+=1
                    r=compute(4,ss,LL,RR,jj,ym,vm,N=16)
                    r.update(candidate='mixed_top2_core2',candidate_category='mixed_motif',motif='two_selected_scalar_coordinates_plus_two_core_coordinates')
                    screen.append(r)
    def jointscore(r):
        a=r.get('A_minus_Sv');b=r.get('A_minus_Sy')
        if a is None or b is None:return -math.inf
        return min(a,b)
    good_screen=[r for r in screen if r['valid_soft']=='pass' and r['actual_good']=='pass' and r['residual_sensitivity']=='positive' and r['actual_residual_gate']=='pass' and r['Dcrit'] not in (None,'+inf')]
    selected=[]
    for r in sorted(good_screen,key=jointscore,reverse=True)[:2]:selected.append(('largest_joint_discriminator',r))
    residual_pool=[r for r in screen if r['valid_soft']=='pass' and r['Dcrit'] not in (None,'+inf') and r['residual_sensitivity']=='positive']
    for r in sorted(residual_pool,key=lambda z:abs(z['log_Dcrit'] if z['log_Dcrit'] is not None else math.inf)):
        if len(selected)>=4:break
        if all((z[1]['candidate'],z[1]['n'],z[1]['s'],z[1]['L'],z[1]['R'],z[1]['j'],z[1]['y'],z[1]['v'])!=(r['candidate'],r['n'],r['s'],r['L'],r['R'],r['j'],r['y'],r['v']) for z in selected):selected.append(('closest_Dcrit_to_1',r))
    # Two known pressure controls: the two high outer y rows paired with inner v=0 at the baseline.
    for yidx in (2,3):
        r=next((z for z in stage2 if z['source_index']==yidx and z['inner_index']==2),None)
        if r is not None:selected.append(('known_pressure_control',r))
    selected=selected[:6]
    refined=[]
    for tag,r in selected:
        y=tuple(F(z) for z in r['y']);v=tuple(F(z) for z in r['v'])
        vals=[]
        for N in (64,128):
            z=compute(r['n'],F(r['s']),F(r['L']),F(r['R']),r['j'],y,v,N=N,u=F(r['u']),cert_logs=True)
            vals.append(strip_private(z))
        refined.append({'selection_reason':tag,'candidate':r.get('candidate'),'parameters':{k:r[k] for k in ('n','j','s','L','R','u','y','v','motif') if k in r},'refinements':vals})
    # Stage 1 compact map plus controls; reserve full rows separately for raw reproducibility.
    scalar_map=[{k:r.get(k) for k in ('y','v','y_minus_v','log_A','log_Sv','log_Sy','log_Dcrit','Dcrit','actual_good','residual_sensitivity','Dcrit_gt_1_sensitivity','A_minus_Sv','A_minus_Sy')} for r in base]
    dependencies=[TOOL,Path(ct.DEP),COMPLETION,POINT171,R170/'task_contract.md',HERE/'joint_geometry_numeric_design.md']
    inputs={(p.name if p.parent==HERE else str(p)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dependencies}
    actual_good_screen=[r for r in screen if r['valid_soft']=='pass' and r['actual_good']=='pass' and r['residual_sensitivity']=='positive' and r['actual_residual_gate']=='pass']
    actual_good_screen.sort(key=jointscore,reverse=True)
    out=dict(scope='Finite physical three-point kernel diagnostic only. Inherited D_n=1 is certified for n<=16 under eps_G<=1; K=1 is diagnostic and no same-alpha rho, source history, common FIRST, positive receiver measure, or FULL claim is provided.',
       arithmetic='Frozen R166/R168 directed Decimal interval kernel and exp/log/sqrt tools. Display logs use interval midpoints; decisions use interval signs.',
       inputs=inputs,
       stage1=dict(name='n=1 scalar physical signed grid',parameters=dict(n=1,j=0,s='1/4',L='9/10',R='1',a='1/2',b='1',u='1/100',ell='tau',K='1'),
          legal_scale={k:(v.out() if hasattr(v,'out') else str(v)) for k,v in par1.items() if k in ('g','tau','hscale','Hhat','T','ell','legal_status')},
          grid=dict(y_v_values=vec_str(grid),spacing='1/8',base_pair_count=len(base),domain='[-3/2,3/2]^2'),
          counts=counts,scalar_map=scalar_map,raw_grid=base,one_sided_face_controls=one_sided,
          top_joint_cells=[strip_private(r) for r in joint[:12]],
          discriminator='sorted by min(A-Sv,A-Sy), descending, among actual_good, Delta>0, Dcrit>1 sensitivity; inherited D_n=1 is certified for n<=16, while K=1 remains diagnostic'),
       stage2=dict(name='12 translated frozen R169 physical source pairs',parameters=dict(n=4,j=0,s='1/4',L='9/10',R='1',x0=vec_str(x0),nu=list(map(str,NU)),q=str(Q),
          completion_mass_interval=[str(mlo),str(mhi)],beta_mass_intervals=beta_mass_intervals),rows=stage2,known_high_outer_row_point_comparison=high_comparison),
       stage3=dict(name='wider legal parameter/motif screen and selected interval refinements',
          screen_parameters=dict(n=dimensions,s=list(map(str,s_values)),LR_pairs=[[str(a),str(b)] for a,b in param_LR],j_candidates=[0,1,2],u=str(U),screen_subdivisions=16,
             scalar_candidates=len(scalar_candidates),stage2_pairs=12,mixed_motifs=1,legal_screen_rows=len(screen)),
          invalid_legal_tuples_count='see rejected/ambiguous counts below',
          legal_gate_counts={**stage3_legal_counts,'valid_soft_counts':stage3_soft_counts,'screen_accepted':len(screen),'screen_total_candidate_tuple_checks':(len(scalar_candidates)*len(dimensions)*len(s_values)*len(param_LR)*3+12*len(s_values)*len(param_LR)*3+len(s_values)*len(param_LR)*3)},
          selected_refinements=refined,selected_cell_count=len(refined),
          top_screen_summary=[{k:r.get(k) for k in ('candidate','motif','n','s','L','R','j','y','v','valid_soft','actual_good','actual_residual_gate','H0_vs_a','cube_no_residual_check','residual_sensitivity','Dcrit_gt_1_sensitivity','log_A','log_Sv','log_Sy','log_Dcrit','A_minus_Sv','A_minus_Sy')} for r in sorted(screen,key=jointscore,reverse=True)[:20]],
          top_actual_good_soft_residual=[{k:r.get(k) for k in ('candidate','motif','n','s','L','R','j','y','v','valid_soft','actual_good','actual_residual_gate','H0_vs_a','cube_no_residual_check','log_A','log_Sv','log_Sy','log_Dcrit','A_minus_Sv','A_minus_Sy')} for r in actual_good_screen[:2]]),
       decisions=dict(actual_inherited_D='certified D_n=1 for all n<=16 under eps_G<=1 from the inherited formula; K=1 is diagnostic',
          stage1_joint_cell_count=counts['joint_good_Delta_positive_Dcrit_gt_1'],
          stage2_high_outer_sources=[r['source_index'] for r in stage2 if r['inner_index']==0 and r['high_status']=='pass'],
          limitations=['K=1 remains diagnostic; strict-softness and other legal gates must be checked per row.','No alpha/rho, common f/FIRST, Z/deletion history, or actual receiver measure is synthesized.',
            'Stage 1 and 3 finite grids are diagnostics, not exponent fits or universal claims.','Only selected Stage-3 cells receive N64/128 interval refinement; stage-1 map uses N24 and screening uses N16.',
            'No continuous receiver integration, FULL coverage, or theorem follows from these physical triples.']),
       runtime=dict(python=sys.version,platform=platform.platform(),wall_seconds=round(time.monotonic()-start,3)))
    out=strip_private(out)
    target=HERE/'joint_geometry_probe.json';target.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(output=str(target),stage1_counts=counts,stage2_rows=len(stage2),stage3_screen_rows=len(screen),refined_cells=len(refined),
       best=[{k:r.get(k) for k in ('candidate','n','s','L','R','j','actual_good','Dcrit_gt_1_sensitivity','A_minus_Sv','A_minus_Sy')} for r in sorted(screen,key=jointscore,reverse=True)[:5]],seconds=out['runtime']['wall_seconds']),indent=2))
if __name__=='__main__': main()
