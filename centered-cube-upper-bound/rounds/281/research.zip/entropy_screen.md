# R281 independent countable weak-profile entropy screen

**PASS.** This proof was derived before reading the latent-soft author draft. On any measure space, let K_i>=0 be a countable measurable family with |{K_i>t}|<=1/t for every t>0. Let fixed weights w_i>=0 sum to 1, and H=sum_i w_i log(1/w_i)<infinity (zero weights omitted). Then

|{sum_i w_i K_i>t}| <= [3+2 log 2+2H]/t <=5(1+H)/t.

In particular the proposed safe constant 8 works. No independence of the functions, coordinates, sources, or profiles is used.

## Self-contained proof

Put f_i=w_i K_i, so its weak constant is w_i. At the fixed target t>0 choose the lower thresholds ell_i=t w_i/2. The pointwise low sum is at most sum ell_i=t/2. Remove the union of high events {f_i>t}; its measure is at most sum w_i/t=1/t. Outside that union, if sum f_i>t, the middle sum sum f_i 1_{ell_i<f_i<=t} exceeds t/2. For each i, Tonelli gives

integral f_i 1_{ell_i<f_i<=t}
 <= ell_i |{f_i>ell_i}| + integral_{ell_i}^t |{f_i>u}|du
 <= w_i[1+log(t/ell_i)]
 =w_i[1+log 2+log(1/w_i)].

Markov on the middle sum therefore gives 2[1+log 2+H]/t. Adding the high union proves the formula. The threshold layers are the complete family; one must not discard small weights before paying their middle layers.

For a finite subfamily, the total weight is at most 1, so the same low, high, and entropy upper bounds hold with the full-family constants. The increasing partial sums have measurable limit. The strict superlevel set {sum f_i>t} is the increasing union of the finite-partial strict superlevel sets. Continuity from below proves the countable result; Tonelli gives the same direct proof. In particular the mixture is finite almost everywhere: the bound for its infinite-value set is at most C/t for every t. No division by a common carrier mass occurs.

For weights summing to a finite v>0, normalization gives weak constant v[3+2log2+2H(w/v)]; v=0 is trivial. If each profile has its own finite weak constant c_i, first absorb c_i into its weight and normalize the resulting total mass. A subprobability family can alternatively be completed by a zero profile.

## Precise application qualifications

- The weights and the profile family must be fixed as functions of the receiver variable being integrated. A receiver-dependent soft/scale selector is not itself a fixed mixture. It needs a previously proved common positive envelope or a finite/countable domination.
- A continuous radius mixture is not automatically covered by differential entropy. A rigorous countable discretization with its domination cost, or a separate continuous proof, is required.
- A per-cell family may depend on the frozen cell, source masses, outer data, or fixed source anchor, provided the asserted weak constants and normalized entropy bound are uniform in the variable of integration. Any later source averaging must use the actual original source law.
- This lemma grants no component FIRST. To combine it with the two-cap lemma one separately retains the cap on the *actual allocated sum*, plus a weak bound on a common positive profile dominating that same sum. Replacing the allocated source by an envelope must not silently replace the original cap.
- If the actual input allocated response has weak constant L m_rho/q_- and the hard cut has weak constant kappa m_nu/(4lambda), the two-cap price remains I(L m_rho/q_-, kappa m_nu/(4lambda)). Taking L>=1 and kappa>=1, the earlier linear estimate gives, for example, an upper bound (16/3)L(1+log kappa)m_rho+m_nu. Thus polylog L and polynomial kappa can indeed yield a polylog linear source price. This statement is conditional on the actual soft profile construction, not a certification of it or of the remaining source branch.

## Finite diagnostic actually run

I ran six finite weak-profile toys on N=5,17,64 unit-measure atoms, with uniform or geometric probability weights. Each K_i is a cyclic permutation of the values 1,1/2,...,1/N, so it has weak constant 1. Fraction arithmetic computed the mixture weak constant exactly; 50-digit ordinary mpmath evaluated entropy and the comparison constant. All six passed; maximum ratio weak/C was 0.373415326014. These are finite algebra diagnostics, not the proof, not interval arithmetic, and not FULL physical inputs.

Reproduce:
```python
from fractions import Fraction as F
import mpmath as m
m.mp.dps=50
checks=0; maxratio=m.mpf(0)
for N in (5,17,64):
 for geometric in (False,True):
  raw=[F(1,2**j) if geometric else F(1) for j in range(N)]
  w=[x/sum(raw) for x in raw]
  H=-sum(m.mpf(x.numerator)/x.denominator*m.log(m.mpf(x.numerator)/x.denominator) for x in w)
  vals=[sum(w[i]*F(1,((j+i)%N)+1) for i in range(N)) for j in range(N)]
  weak=max(v*sum(t>=v for t in vals) for v in vals)
  C=3+2*m.log(2)+2*H
  weakmp=m.mpf(weak.numerator)/weak.denominator
  assert weakmp <= C
  assert C<=5*(1+H)
  maxratio=max(maxratio,weakmp/C); checks+=1
print('PASS',checks,'finite weak-profile toys; maxratio',m.nstr(maxratio,12))
```

This screen stops at the requested general lemma and its application conditions. No latent-soft proof or R281 author proof has been read here.
