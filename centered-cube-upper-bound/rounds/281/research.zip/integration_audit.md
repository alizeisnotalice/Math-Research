# R281 final integration audit

**PASS. No necessary correction.** This is a bounded consistency/accounting audit of the already independently audited inputs; it is not a new proof of their geometric lemmas.

## Bound versions

- Integration `/tmp/r281_integration.md`: SHA256 `d18c7c4d821b7049e3eb1c28baa935048dd61340417c4aecbc256fa45f60de53`.
- Single-cut author `/tmp/r281_cut.md`: `87ddf1ce43138ea41745771526ced33cc79a630266f8e10fdbd35ac213b9f454`.
- Single-cut independent final audit `/tmp/r281_cut_audit.md`: `16a6096ee6666543add7f58a35a9e7810cb2abfac4bd9953220968a5b12f6934`.
- Latent-soft author `/tmp/r281_soft.md`: `e5e04dfc7d21a7cdb5f1495eb81df78c77e1a3e3ae590acf926bf84a342f3681`.
- Latent-soft independent final audit `/tmp/r281_soft_audit.md`: `3f58b9c60f3fb3471ac7d61973986d2ee637c3110496ee5bde53261fd2a0fdb1`.
- R280 integration input `/tmp/r280_integration.md`: `af9d5e94dc4b841b9921714f9a5e84143d9028a2972ccc6b2e716457e7b1d667`.
- R280 cell-geometry independent audit `/tmp/r280_interior_audit.md`: `421305ce5838e9e7a86fbdec8ecab02b7081e0577160f27331ffebc9ec609534`.

The three current integration/author hashes were actually rechecked at the start of this audit. The parent has confirmed that the soft author's e5e04d version is final. No repository/author file was changed.

## Exact positive priorities

1. The actual original top/middle clock split is performed first. Its top price is the existing 5Lambda sqrt(n)W_nu. All subsequent allocations are applied only to the original middle clock.

2. For the same probability-one random shifted grid, A0 is the old both-full allocation. A_sc=A10+A01 is the sum of disjoint one-full grid states, with the original input-core indicator on A01. Consequently 0<=A_sc<=Ab=1-A0 on near. This inequality is valid at the level of the exact normalized expectations divided by P_d, not just their factor-two majorants.

3. The displayed identity

1=A0+A_sc+(Ab-A_sc)A_lat+(Ab-A_sc)(1-A_lat)

is exact, nonnegative, and accounts for the original pair measure once. It resolves the potential overlap between the standalone single-cut and latent-soft paid branches: the new latent portion is only (Ab-A_sc)A_lat, whose price is bounded by the independently proved full A_lat price. No assertion that A_sc and A_lat are themselves disjoint is needed.

4. Near is the original source-pair condition on (y,z), not the auxiliary posterior pair (v,u). These allocation weights depend only on the original receiver/source pair and static physical selectors at fixed x. The full auxiliary posteriors and their normalization are unchanged.

## Constants and source/clock fees

- The old middle both-full interior bound is exactly (128Lambda/sqrt3)sqrt(nD)sqrt(W_rho W_nu), as bound in the R280 inputs. Bounding its middle clock by the full positive clock estimate is legitimate and does not put an actual top term back into the residual.
- The single-cut term is exactly the safe C14 price: 16Lambda sqrt(nD)(2+log kappa)[(16/3)W_rho+W_nu]. The factor-two same-cell estimate and original outside 2Lambda are already included.
- The remaining-latent portion has at most the S4 price 16Lambda sqrt(nD)[(16/3)L_(n,D)(1+log kappa)W_rho+W_nu]. It likewise includes the same-cell factor and the original outside 2Lambda once. Pricing a smaller actual allocation by this larger positive upper bound is valid.
- All kappa and L constants match the audited definitions. The integration's clarification of the soft-node factor e is correct: it multiplies a sum over M nodes; the M factor remains in the weak constant. Radius mass inflation contributes the second e. Only the actual allocated sum has FIRST; individual latent components or envelope profiles do not.

The surviving original mask ns(x)+R2(y,v)<=D implies ns(x)<=D at every nonzero contributing point. Restricting the receiver set by ns<=D preserves the actual FIRST and hard band; retaining the full original coupled mask as well can only decrease the paid bounds. The same D also gives the already proved good-upper score-clock estimate. It is not a statement that k_t equals a latent label count.

For a common frozen D the source prices combine exactly as displayed. If D varies over outer data, its B_D and L_(n,D) factors must remain within the corresponding seed/terminal-leaf sums until a proved uniform bound is applied. The note says this explicitly. No new j menu, ancestor duplication, seed factor, or extra Lambda occurs.

The source conversion uses the SAME original terminal-leaf collection: W_rho<=W_beta<=||f||_1 and W_nu<=||f||_1. It does not infer source disjointness from arbitrary repeated leaves and does not assume nu<=rho or nu<=beta. With the already established uniform D=C0+C1log(n+2), L=O(log(n+2)^3); the largest displayed coefficient is consequently sqrt(n)log(n+2)^(9/2), with all inherited constants retained. This is a sum of paid positive restrictions, not the complete weak-(1,1) theorem.

## Exact unpaid remainder

P_rem retains the original middle clock, actual dx rho(dy)nu(dz), both full auxiliary posteriors, original unspent masks and the nonnegative exact factor (Ab-A_sc)(1-A_lat). This is precisely the remaining positive restriction after the three middle allocations. It includes remaining simultaneous-cut and soft latent-face failures; there is no assertion that it is small, is only far-source traffic, or is a new independent moment already paid. No negative credit has been reused or spent in this integration.

No extra numerical experiment was required for this algebraic integration check. The prior receipts contain their actual bounded replays (cut PASS70, soft PASS314); numerical diagnostics were not used in place of the analytic allocation and cap proofs. Audit complete and frozen.
