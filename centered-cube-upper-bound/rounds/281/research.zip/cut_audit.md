# R281 single-cut author final audit

**PASS. No necessary mathematical correction.** This review follows the frozen independent statement-screen `/tmp/r281_cut_screen.md` (SHA256 `60c83d050c9764edb5d6e4a2a1649b751ee5f80cfd1610ec2b436227e2e1a124`). It does not certify any still-unread latent-soft author construction.

## Bound version

Author `/tmp/r281_cut.md` SHA256:
`87ddf1ce43138ea41745771526ced33cc79a630266f8e10fdbd35ac213b9f454`.
The file hash was checked before reading and again before extracting its unique executable block. No author or repository file was modified.

## Mathematical review

1. **Historical source qualification.** I independently read R251 frozen `proof.tex.txt` CW1-CW2 for the screen, then read the cited `signed_variation.md` lines 173-235 for this review. SV12 explicitly treats an arbitrary finite nonnegative L1 source supported in a full-side-d cube, d<=a, with no flatness, FIRST, receiver cap, source rank, or coordinate-product assumption. It covers the whole original [a,b] scale window, including empty and degenerate localized windows. Thus it applies to the true restrictions rho|C and nu|C used in C4, without changing their distributions. Its constant is exactly kappa=2+n log(1+d/a), hence kappa<=2+sqrt(n)/8 at the current d. The cap remains on actual R(x) in [a,b]; the proof does not demand a cap at R+d.

2. **Two-layer integral and log amplification.** C5's split integration equals I(A,B)=min(A,B)[2+log(max/min)] for every positive A,B. The bounded-function formulation is sufficient for all applications. Zero mass forces the corresponding function to vanish almost everywhere and is handled continuously. The derivative formula in C6 is correct on both sides of A=B; integrating B partial_B I<=A gives the claimed two linear bounds. No alignment, independence, or balanced-mass assumption is hidden here. The exact I can legitimately be retained as a potentially sharper price.

3. **Actual normalized caps.** In C7, I_L implies L>=2||x-z_C||_infinity+d; weakening this to r_C=2||x-z_C||_infinity gives a radial weak constant m_C/q_-. The point r_C=0 is a null receiver point and can be assigned the usual infinite envelope when m_C>0. F_C/q<=1 is actual FIRST for the positive source restriction. G_C/(4lambda)<=1 is the actual all-scale hard band for nu|C<=nu. The partial response is exactly the intersection expression C8 and is bounded by its restricted-source maximal function. Consequently C9 is valid for variable q(x), not only constant q. The coefficient 4lambda/q_-=16/3 is correct.

4. **Symmetric application has the right core.** C10 uses F_C^circ, for which the pointwise inequality P_s,L 1_core<=h_L is valid even for s=1. Hence the input partial cell has the R251 cluster weak bound. The hard-full side supplies the radial weak constant without kappa. The same argument does not cover F_C-F_C^circ; the author expressly excludes it. There is no componentwise artificial FIRST and no use of nu<=rho.

5. **Exact allocation and clock.** C11's numerators are disjoint fixed-grid states. Dividing by the same positive P_d on the original near set produces [0,1] allocations and preserves A_int+A10+A01<=1. The input-core indicator only reduces A01. These weights depend on actual receiver/physical scales and the original source pair (y,z); they do not depend on the auxiliary posterior pair or auxiliary time at fixed x. The factor 2 enters only when majorizing 1/P_d<=2. Source sums then use countable partition additivity, not a sum of independently capped constants. C12 adds the two distinct linear prices correctly.

6. **Original full positive price.** The original R2<=D score bound is applied pointwise before replacing the complete two posterior averages by a scalar row bound. Its orientation is good-upper `(k_v-k_u)_+`; no smallness restriction is added to bad u. B_D<=min(n log2,4sqrt(nD)) and B_0=0 give exactly C14 after the outside 2Lambda once. Unique j is not charged as a source copy. Frozen outer-data variation in D is retained as specified. With the original uniform D=C0+C1log(n+2), this is an actual root-polylog source price for these allocations, not a certification of all current near traffic.

7. **Complement and accounting.** C15 is an exact algebraic decomposition of the original fixed-grid positive response. It displays the hard-full/soft-offcore term and the both-cut term separately. The both-cut source-core fallback really has I(kappa A,kappa B)=kappa I(A,B), so it does not inherit the new logarithmic improvement without additional geometry. The R280 both-full allocation, these single-cut allocations, and their explicit complement can be assigned disjointly; the top/middle split must still be performed first if using the R280 top payment. No negative credit is consumed or restored. Original terminal source-ledger inequalities remain a separate already-bound input; arbitrary overlapping leaf/source families would not acquire them from this note.

## Actual local-tool verification

After SHA verification I extracted the sole Python block to `/tmp/r281_cut_checks.py` and actually ran it. Output:

`PASS 70 single-cut positive allocation lower 3/524288`

The Fraction part verifies the stated one-dimensional positive-volume source/cell geometry and its positive lower bound. Scalar integrals/logarithms use ordinary 55-digit mpmath; these diagnostics are not interval certificates, not FULL original histories, and do not replace C5-C10's proof. The geometry check is a nonempty permissible reduced source configuration; it does not assert positive coverage of the current original remainder. No unrelated tests were run.

Audit complete; no required revision and no new global-closure claim.
