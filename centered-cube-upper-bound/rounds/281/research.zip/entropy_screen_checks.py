from fractions import Fraction as F
import mpmath as m
m.mp.dps=50
checks=0; maxratio=m.mpf(0)
for N in (5,17,64):
 for geometric in (False,True):
  raw=[F(1,2**j) if geometric else F(1) for j in range(N)]
  w=[x/sum(raw) for x in raw]
  H=-sum(m.mpf(x.numerator)/x.denominator*m.log(m.mpf(x.numerator)/x.denominator) for x in w)
  vals=[sum(w[i]*F(1,((j+i)%N)+1) for i in range(N)) for j in range(N)]
  weak=max(v*sum(t>=v for t in vals) for v in vals)
  C=3+2*m.log(2)+2*H
  weakmp=m.mpf(weak.numerator)/weak.denominator
  assert weakmp <= C
  assert C<=5*(1+H)
  maxratio=max(maxratio,weakmp/C); checks+=1
print('PASS',checks,'finite weak-profile toys; maxratio',m.nstr(maxratio,12))
