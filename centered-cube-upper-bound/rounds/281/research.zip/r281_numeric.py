#!/usr/bin/env python3
"""Actual uniform-interval mixture diagnostics; no interval/FULL certification."""
import argparse,hashlib,json,math
from pathlib import Path
from fractions import Fraction as F
import mpmath as m

def enc(x):return m.nstr(x,90)
def phi(x):
 x=abs(x);return 1-m.expint(3,m.mpf('.5')-x)-m.expint(3,m.mpf('.5')+x) if x<=m.mpf('.5') else m.expint(3,x-m.mpf('.5'))-m.expint(3,x+m.mpf('.5'))
def prim(x):
 return x-m.expint(4,m.mpf('.5')-x)+m.expint(4,m.mpf('.5')+x) if x<=m.mpf('.5') else m.mpf('.5')-m.expint(4,x-m.mpf('.5'))+m.expint(4,x+m.mpf('.5'))
def w(x):
 x=abs(x);return m.mpf(1) if x==0 else m.exp(-x)-x*m.expint(1,x)
def density(r):return r/2*(w(r/2-m.mpf('.5'))-w(r/2+m.mpf('.5')))
def cdf(r):return 2*prim(r/2)-r*phi(r/2)
def tail(r):
 # Positive E3/E4 expression avoids 1-CDF cancellation for r>=1.
 x=r/2;return 2*(m.expint(4,x-m.mpf('.5'))-m.expint(4,x+m.mpf('.5')))+r*phi(x)
MENU=[('initial',0),('initial',1),('initial',4),('stress',16),('stress',64),('expanded',256)]
def run(dps):
 with m.workdps(dps):
  normal=m.quad(density,[0,m.mpf('.5'),1,2,8,32,m.inf]);moment=m.quad(lambda r:abs(m.log(r))*density(r),[0,m.mpf('.5'),1,2,8,32,m.inf]);tol=m.mpf(10)**(-dps+12)
  assert abs(normal-1)<tol
  independent=[]
  for r in map(m.mpf,['.25','.5','1','2','4','8']):
   pts=sorted(set([m.mpf(0),r]+[x for x in [m.mpf('.5'),m.mpf(1),m.mpf(2)] if 0<x<r]));q=sum(m.quad(density,[a,b]) for a,b in zip(pts,pts[1:]));v=cdf(r)
   assert abs(q-v)<tol;independent.append({'r':enc(r),'cdf_formula':enc(v),'density_integral':enc(q),'difference':enc(abs(q-v))})
  rows=[]
  for phase,D in MENU:
   zeta=1+1/m.mpf(D+1);h=m.log(zeta);jlo=int(m.floor(m.log(m.mpf('1e-4'))/h));jhi=int(m.ceil(m.log(64)/h));rlo=m.exp(jlo*h);rhi=m.exp(jhi*h)
   # Included bins j=jlo+1,...,jhi; omitted r<=rlo or r>rhi.
   prev=cdf(rlo);mass=m.mpf(0);entropy=m.mpf(0);minp=m.inf
   for j in range(jlo+1,jhi+1):
    r=m.exp(j*h);cur=cdf(r) if r<1 else 1-tail(r);p=cur-prev
    assert p>=-tol
    if p>0:entropy-=p*m.log(p)
    mass+=p;minp=min(minp,p);prev=cur
   low=cdf(rlo);high=tail(rhi);omitted=low+high
   assert abs(mass+omitted-1)<tol and low>=0 and high>=0
   # g(r)<=r/2 globally; large phi<=.5e^(-(r-1)/2), one-sided tail<=1/3e^(-(r-1)/2).
   small_log=-m.log(rlo)*low+rlo*rlo/8
   large_log=m.log(rhi)*high+(1+4/(3*rhi))*m.exp(-(rhi-1)/2)
   logtail=small_log+large_log
   Z=(1+m.exp(-h))/(1-m.exp(-h))
   enttail=logtail+(h+m.log(Z))*omitted-omitted*m.log(omitted)
   totalupper=entropy+enttail;candidate=m.log(2*D+3)+15
   assert entropy<=totalupper and totalupper<=candidate
   row={'phase':phase,'D':D,'included_bin_count':jhi-jlo,'first_included_j':jlo+1,'last_included_j':jhi}
   for key,val in [('zeta',zeta),('log_zeta',h),('r_low',rlo),('r_high',rhi),('included_mass',mass),('omitted_small_mass',low),('omitted_large_mass',high),('omitted_mass',omitted),('finite_entropy',entropy),('omitted_abslog_moment_upper',logtail),('omitted_entropy_upper',enttail),('whole_entropy_upper',totalupper),('whole_entropy_candidate',candidate),('candidate_margin',candidate-totalupper),('minimum_included_bin_mass',minp)]:row[key]=enc(val)
   rows.append(row);print('completed',dps,D,jhi-jlo,flush=True)
  return {'normalization_density_quad':enc(normal),'absolute_log_moment_density_quad':enc(moment),'independent_CDF_checks':independent,'bins':rows}
def exact_nodes():
 rows=[];powers=[];e_lower=sum((F(1,math.factorial(k)) for k in range(9)),F(0))
 for n in [1,8,64,1024]:
  gamma=F(n+1,n);assert gamma**n<=e_lower
  powers.append({'n':n,'e_lower_minus_power_exact':str(e_lower-gamma**n)})
  for D in sorted(set([0,1,min(4,n),n])):
   for s in sorted(set([F(0),F(min(D,n),2*n),F(min(D,n),n)])):
    # k=max(1,ceil(ns)), including s0 at the first interior node.
    ns=n*s;k=max(1,(ns.numerator+ns.denominator-1)//ns.denominator);sigma=F(k,n+1)
    assert 1<=k<=n and 0<sigma<1 and n*sigma<=D+1 and s<=F(D,n)
    rows.append({'n':n,'D':D,'s_exact':str(s),'k':k,'sigma_exact':str(sigma),'n_sigma_exact':str(n*sigma),'n_sigma_bound_exact':str(D+1)})
 return {'cases':rows,'exact_gamma_powers':powers,'gamma_power_rational_upper':str(e_lower),'gamma_power_e_scope':'Finite gamma^n<=sum_{k=0}^8 1/k!<e is checked exactly; strict upper to e follows from positive omitted Taylor terms. General inequality uses nlog(1+1/n)<=1.'}
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();lo=run(40);hi=run(60);ex=exact_nodes()
 with m.workdps(110):
  diffs={}
  for i,(x,y) in enumerate(zip(lo['bins'],hi['bins'])):
   for k,v in x.items():
    if not isinstance(v,str) or k=='phase':continue
    diffs[str(i)+'/'+k]=abs(m.mpf(v)-m.mpf(y[k]))/max(1,abs(m.mpf(y[k])))
  for k in ['normalization_density_quad','absolute_log_moment_density_quad']:diffs[k]=abs(m.mpf(lo[k])-m.mpf(hi[k]))
  for i,(x,y) in enumerate(zip(lo['independent_CDF_checks'],hi['independent_CDF_checks'])):
   for k in x:diffs['cdf/'+str(i)+'/'+k]=abs(m.mpf(x[k])-m.mpf(y[k]))/max(1,abs(m.mpf(y[k])))
  worst=max(diffs,key=diffs.get);maximum=enc(diffs[worst]);assert diffs[worst]<m.mpf('1e-27')
 out={'schema':'R281-actual-uniforminterval-mixture-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'D_cases':6,'stages':{'initial':3,'stress':2,'expanded':1},'CDF_checks_per_precision':6,'bin_evaluations_per_precision':sum(x['included_bin_count'] for x in hi['bins']),'softnode_Fraction_cases':len(ex['cases']),'precision_fields':len(diffs)},'mp40':lo,'mp60':hi,'exact_softnodes':ex,'precision_max_scaled_difference':maximum,'precision_worst_field':worst,'scope':['Actual phi E3/E4 and interval-mixture density; ordinary40/60mp, not outward intervals. Actual infinite density quadrature for normalization and absolute log moment, and six independent fixed-radius CDF checks.','Finite included bins plus explicit positive omitted CDF/tail masses, and analytical reference-entropy upper bound retain both infinite tails. Finite entropy is not called full entropy.','D1024 omitted as permitted; expanded actual case D256. No dimension-order fit, FULL, original FIRST/history/source-payment or global theorem certified.','Exact finite softnode coefficients separately Fraction; gamma^n<=e uses analytic log inequality, not a rational numerical comparison to e.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':maximum,'worst':worst}))
if __name__=='__main__':main()
