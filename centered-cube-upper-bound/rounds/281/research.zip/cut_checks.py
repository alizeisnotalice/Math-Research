import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
from fractions import Fraction as F
mp.mp.dps=55
checks=0
def I(a,b):
    lo,hi=min(a,b),max(a,b)
    return lo*(2+mp.log(hi/lo))
for aa,bb in [(1,1),(1,2),(2,1),(1,1000),(1000,1),(3,7)]:
    a,b=mp.mpf(aa),mp.mpf(bb)
    # Independent exact evaluation of the two elementary integration regions.
    lo,hi=min(a,b),max(a,b)
    z=lo/hi
    num=mp.quad(lambda u:hi*(1+mp.log(lo/(hi*u))),[0,z])
    if z<1:num+=mp.quad(lambda u:lo/u,[z,1])
    assert abs(num-I(a,b))<mp.mpf('1e-48');checks+=1
    for kk in (1,2,10,10000):
        k=mp.mpf(kk)
        assert I(a,k*b)<=(1+mp.log(k))*a+b+mp.mpf('1e-45')
        assert I(k*a,b)<=a+(1+mp.log(k))*b+mp.mpf('1e-45')
        checks+=2
# a=1,b=2,d=1/8,lambda=q=1,L=2,R=1,s=1/4.
# Both sources have density one on [-1/32,1/32].
a,b,d=F(1),F(2),F(1,8)
source=(-F(1,32),F(1,32));E=(F(31,64),F(33,64))
# For all shifts with the common cell's left face c in [-3/32,-1/32],
# C=[c,c+d] contains both sources, input L fully contains C, hard R cuts C.
cs=(-F(3,32),-F(1,32))
for c in cs:
    assert c<=source[0] and c+d>=source[1]
    for x in E:
        assert x-F(1)<=c and c+d<=x+F(1) # C subset Q_L(x)
        assert c<x-F(1,2)<c+d          # hard window cuts the actual cell
        G=source[1]-(x-F(1,2))
        assert F(1,64)<=G<=F(3,64)
        checks+=3
mass=source[1]-source[0]
assert mass/a<=4 and mass/F(2)<=1 # allhard cap and input FIRST globally
assert (cs[1]-cs[0])/d==F(1,2)
# Whole source interval has l1 diameter d/2, so every pair is near.
assert source[1]-source[0]==d/2
# Actual p >=(1-s)/L on input core; shift probability at least 1/2.
positive_lower=F(1,2)*(E[1]-E[0])*F(3,8)*mass*F(1,64)
assert positive_lower==F(3,524288)
checks+=4
print('PASS',checks,'single-cut positive allocation lower',positive_lower)
