# R281 independent cut screen

Verdict: **PASS for the general two-cap lemma and the stated two distinct cut-cell applications**, subject to retaining the actual caps and the explicit source-core restriction in the symmetric application. This screen preceded reading either R281 author proof. It does not certify full soft offcore or global closure.

## General measure lemma

Let F,G be nonnegative measurable functions on Lebesgue space, with finite A,B>=0 and |{F>t}|<=A/t, |{G>t}|<=B/t for every t>0. For A,B>0 set

I(A,B)=min(A,B)[2+log(max(A,B)/min(A,B))].

At a zero argument define I=0. Tonelli on the two truncated layers gives

integral min(1,F)min(1,G) <= integral_0^1 integral_0^1 min(A/s,B/t) ds dt = I(A,B).

Equivalently the extremal decreasing profiles are A/r,B/r on r>0. Thus this bound is sharp under only the two weak hypotheses. No common law or independence is required.

For finite kappa>=1,

I(A,kappa B) <= (1+log kappa)A+B.

Proof: I(A,B)<=A+B (log x<=x-1). For x>0, differentiation in x shows d I(A,xB)/dx<=A/x: when xB>=A equality holds; otherwise use z(1+log(1/z))<=1 for z=xB/A<=1. Integrate x from 1 to kappa. Zero cases follow separately. The linear inequality is itself attained at A=B for every kappa>=1. By symmetry I(kappa A,B)<=A+(1+log kappa)B.

## Exact historical cluster dependency

I read the frozen R251 proof at
/Users/zhengzhihao/Desktop/T/output/centered_cube_round251_20261017_final_checkpoint/proof.tex.txt, CW1-CW2 (lines 1-29).
It proves, for every finite nonnegative L1 source mu supported in a cube of full side d, any 0<a<=b, and every t>0,

t |{M_[a,b] mu>t}| <= kappa_d ||mu||,
kappa_d=2+n log(1+d/a).

No flatness, FIRST, density bound, or product-source hypothesis is needed. The support is a full-side-d cube; its actual source can occupy any measurable subset, by zero extension. The proof uses a threshold-frozen short window and the exact strong envelope 1+n log(B/A), including A=B. I am invoking this proved L1 statement, not extending it without proof to arbitrary singular measures. Original restricted L1 sources satisfy its domain. At d=a/(8 sqrt n), kappa_d<=2+sqrt n/8. Hence log kappa_d=O(log(n+2)).

## Input-full, hard-cut cell

Fix a shifted cell C, centre z_C, side d. Let m_rho=rho(C), m_nu=nu(C), r_C(x)=2||x-z_C||_infinity+d. Retain the allocation C subset Q_L(x). Since every coordinate f_s<=1, the actual cell input F_C obeys

F_C/q(x)<=min(1, m_rho/[q_- r_C(x)^n]), q_-=3 lambda/4.

The first cap is actual FIRST for rho_C<=rho; the second retains the normalization F_C/q before using q(x)>=q_-. The radial profile on the right has weak constant A=m_rho/q_-: its superlevel volume is ( (A/t)^(1/n)-d )_+^n <=A/t. Arbitrary receiver restrictions only lower it.

For the actual hard cell response G_C=h_R(x)*nu_C, with the original physical R(x) in [a,b], actual E gives G_C<=4 lambda from nu_C<=nu<=f and the ALL-scale receiver band. Extending by zero outside E,

G_C/(4 lambda)<=1,  weak constant <= kappa_d m_nu/(4 lambda).

This uses the maximal function of the actual restricted source, without replacing its internal distribution. Two-cap integration therefore gives the cell source price

integral (F_C/q) G_C <= (16/3)(1+log kappa_d)m_rho+m_nu.

The hard cut needs no whole-cell hard containment. The actual hard cap is a cap on each positive restricted response, not an assertion that the sum of its per-cell cap constants is 4 lambda.

## Hard-full, input-cut cell: core is mandatory

Retain C subset Q_R(x), and retain the original per-y input-core gate x in Q_L(y). On this gate p_s,L(x-y)<=h_L(x-y), because f_s<=1. Thus the input cell response is dominated by the hard maximal function of rho_C, with weak constant kappa_d m_rho/q_-, and its actual FIRST cap is still 1 after division by q(x). The hard-full response has weak constant m_nu/(4 lambda) by the same radial profile and actual cap. Symmetry yields

integral (F_C^core/q) G_C <= (16/3)m_rho+(1+log kappa_d)m_nu.

This does NOT bound the full soft input without its core gate. In particular one cannot add the core after integrating y, regard every soft latent component as FIRST capped, or replace a genuine soft halo by a hard kernel.

## Grid and full original score-clock fees

On the original near pair (y,z), the normalized independent shift has same-cell probability P_d>=1/2. Exact allocations should retain numerator/P_d. Only for estimating them may one use 1/P_d<=2. Per shifted grid the countable cell masses sum to the original source masses; these linear prices have no cell-count or entropy fee.

For the input-full/hard-cut allocation the resulting raw source price is at most

2[(16/3)(1+log kappa_d)W_rho+W_nu].

For hard-full/input-core-cut it is at most

2[(16/3)W_rho+(1+log kappa_d)W_nu].

With the original good-slot R2<=D, the complete posterior score-clock row is at most 4 sqrt(nD). It is bounded before eliminating the original posterior; no bad-slot restriction is introduced. Outside 2 Lambda occurs once. Thus the first complete positive allocation costs at most

16 Lambda sqrt(nD)[(16/3)(1+log kappa_d)W_rho+W_nu],

and the symmetric allocation has the corresponding exchanged log factor. If D or other parameters vary with outer data, retain their weighted source sums until a legitimate uniform bound is applied. These are source prices, conditional on the original terminal source ledger; source disjointness must not be inferred for ancestors or copied j rows.

After R280 already paid both-full cells, classify the remaining exact grid allocation once: (i) input-full and hard-not-full; (ii) input-not-full, hard-full, and the original input-core gate; (iii) the remainder. The first two are disjoint; their upper estimates can drop the exclusions. Their original posterior and source laws remain unchanged. The remainder includes genuine input soft offcore and neither-full cells. A separate certificate for full soft offcore is still required. No negative credit is used.

## Actual finite arithmetic diagnostic

I ran 60-digit mpmath, using the local installed vendor path. Nine A/B pairs and three kappa values checked the linear inequality (27 assertions), plus nine quadratures of the exact extremal profile. Result: PASS 27; max exact-profile quadrature discrepancy 9.72346137166e-63. This ordinary numerical diagnostic does not replace the proof and is not interval/FULL evidence.

Reproduce:
```python
import mpmath as m
m.mp.dps=60
N=0; err=m.mpf(0)
for A in [m.mpf('0.01'),m.mpf(1),m.mpf(17)]:
 for B in [m.mpf('0.03'),m.mpf(1),m.mpf(23)]:
  lo,hi=sorted((A,B)); I=lo*(2+m.log(hi/lo))
  val=m.quad(lambda x: min(1,A/x)*min(1,B/x),[0,lo,hi,m.inf])
  err=max(err,abs(I-val)); assert abs(I-val)<m.mpf('1e-55')
  for k in [m.mpf(1),m.mpf('1.2'),m.mpf(100)]:
   l,h=sorted((A,k*B)); Ik=l*(2+m.log(h/l))
   assert Ik <= (1+m.log(k))*A+B+m.mpf('1e-55')
   N+=1
print('PASS',N,'linear-cap checks; 9 exact-profile quadratures; maxerr',m.nstr(err,12))
```
