# R281 latent-soft author final audit

**PASS for the displayed latent-interior allocation and its stated source price. No necessary mathematical revision.** This review follows the independent `/tmp/r281_entropy_screen.md` (SHA256 `93b57da432cb9c6685dc0333ff4529bce205f76a88f180b5d2406860bc7b2bfa`) and `/tmp/r281_cut_screen.md` (SHA256 `60c83d050c9764edb5d6e4a2a1649b751ee5f80cfd1610ec2b436227e2e1a124`). Those statement proofs preceded author reading.

## Actual version binding

The fully read and actually replayed author file `/tmp/r281_soft.md` has SHA256

`e5e04dfc7d21a7cdb5f1495eb81df78c77e1a3e3ae590acf926bf84a342f3681`.

The task initially named `1a20e04f8416b273ad31f91fb3b7369963dae791fbe2d125c66761970c5f628f`; the initial hash check instead found the hash above. I immediately reported the mismatch. The author confirmed that the only subsequent change was appending the actual execution output at the end. This receipt binds the actual complete bytes above, not the superseded hash. No author/repository file was modified.

## 1. Exact probability mixture and its moments

S5 has the correct factor: mu_phi(dr)=-(r/2)phi'(r/2)dr, so integrating its normalized interval kernels gives -1/2 integral_[2|x|,infinity] phi'(r/2)dr=phi(x). Evenness and monotonicity give a positive law; Tonelli and integral phi=1 give total mass one. The underlying w also has mass one, since integral_0^1 2u du=1. Its second moment is integral_0^1 4u^3du=1; convolving with the unit interval adds 1/12. A normalized interval of side r has second moment r^2/12, so the mixture second moment is exactly 13. This is a kernel product construction, not independence of the original sources.

The density bound mu_phi/dr<=r/2 on (0,1) follows from |phi'|<=1. Its contribution to absolute log moment is 1/8. On r>=1, log r<=r^2 gives the remaining bound 13. Thus S6 is valid for the full infinite soft tail; it does not truncate the actual soft kernel.

## 2. Exact original positive allocation

S8 is measurable and satisfies 0<=p_C^lat<=p_y with the actual receiver-dependent s(x),L(x). If its latent rectangle contains the whole cell, its normalized density is constant for every y in that cell, which proves S10 for arbitrary nonuniform original rho|C. The grid same-cell probability and its near lower bound 1/2 are the actual probability-one shift formulas. S9's numerator is at most P_d p_y. Zero p_y carries no original traffic, so its zero definition is legitimate. No auxiliary posterior slot or clock enters this allocation.

Crucially S11 uses only F_C^lat<=integral_C p_y rho<=q(x), and the actual all-scale hard band for nu|C<=nu. It assigns no FIRST cap to a latent component, soft node, or rounded aspect profile. The hard window may genuinely cut C. There is no comparison between rho and nu.

## 3. Fixed-weight domination of all actual selectors

For n>=1 and D>=0, the stated node k=min(n,floor(ns)+1) lies in 1,...,M, including s=0, s=1 when allowed, integer D, and clipped k=n. Both Bernoulli coefficients obey the gamma comparison with gamma=(n+1)/n. Consequently the entire product law is dominated coefficient by coefficient even after inserting any nonnegative latent mask. This is stronger than comparing only the unmasked physical kernel and is the needed step here.

Rounding the soft side upward preserves whole-cell containment and enlarges its normalized density upper bound by at most zeta per soft coordinate. The weighted product total mass is Z_sigma=[1+(zeta-1)sigma]^n<=e, since n sigma<=D+1. Normalizing it produces exactly the stated tilted soft probability, with n tilde_sigma<=D+2. Radius rounding weights, normalized label law, and soft nodes are fixed in x; they are not receiver-selected mixing weights in the entropy theorem.

For each fixed aspect R, t_R(x)^n product R_i has sublevel volume exactly v. Hence g_R has weak constant one for every aspect, without an aspect-ratio or dimension factor. Whole-cell containment implies L>=t_R, so the fixed positive envelope S14 is valid. Values at the cell center are harmless null sets for each fixed grid. Countably many cells and all positive shape/shift integrals are handled by Tonelli.

Editorial precision: S12's sentence “summing the M fixed nodes costs at most e” is imprecise if read as removing the M factor. The proved domination is e times the sum of the M fixed-node integrals. S14 explicitly has that sum, and S17 and the final L retain M, so the displayed mathematics and result are correct. A final restatement should use the precise wording above.

## 4. Countable entropy bound and finite constant

S15 is exactly the independently derived full-threshold weak-sum estimate: remove the union f_i>u, pay the low sum at u a_i/(2A), and use Tonelli on every middle layer before Markov. Its coefficient A(3+2log2)+2 sum a_i log(A/a_i) is correct. It applies to fixed countably many nonnegative profiles; no profile/source independence is needed. Finite partial sums followed by increasing superlevel sets justify the limit.

For the rounded radius law, eta|j|<=|log r|+eta. The reference probabilities proportional to exp(-eta|j|) have normalizer (zeta+1)/(zeta-1)=2D+3. Their finite cross-entropy is bounded by the moment above. Gibbs' inequality can be applied to finite partitions including the tail, and then passed to the countable entropy, giving S16 without assuming the conclusion H(p)<infinity in advance. The rough constant 15 exceeds 13+1/8+log2.

The independent coordinate *label law* has entropy n h2(tilde_sigma)+n tilde_sigma H(p). With v=n tilde_sigma<=min(n,D+2), h2(t)<=t log(e/t) gives the asserted H_* bound; the maximization v log(en/v) on [0,n] also covers small v and n=1. Distinguishing a hard side-1 label from a soft rounded side-1 label only overcounts entropy and is safe. Applying S15 to M probability laws incurs M log M plus M H_*, and the two e factors give exactly S2/S17. No component FIRST, source entropy, or cell-count fee has been introduced.

## 5. Actual hard cut, two caps, and original source payment

R251 CW1-CW2 was independently read in its frozen proof and SV12 for the prior cut audit. It applies to arbitrary actual restricted L1 nu|C with the original [a,b] window. Its weak constant is kappa_d n_C, and its height cap here remains only on actual E at actual R(x). Together with S14 and q(x)>=q_-, the actual capped functions have weak constants L m_C/q_- and kappa_d n_C/(4lambda). The exact two-layer product integral and the logarithmic amplification bound from the independent screen give precisely S20. Variable q(x) is valid because the actual ratio F_C^lat/q(x) is retained before normalization by q_-.

The normalized near allocation uses 1/P_d<=2 only for its upper estimate. For every shift, the true restricted cell masses add to W_rho and W_nu. S20 then proves S3 without a number of cells or adjacency degree. This is a genuine source price for the declared actual positive allocation, including some possible input soft offcore. It makes no assertion that a fixed positive fraction of original traffic has this allocation.

The optional additional hard-full allocation has raw price 16/sqrt(3) sqrt(L W_rho W_nu), with the shift factor two already included; it is a smaller allocation, as stated. It is not an extra price used in the main proof.

## 6. Clock, asymptotic order, and accounting boundary

The original good-upper score is bounded pointwise under R2(y,v)<=D by min(n,D/(1-u)^2), before integrating either complete posterior. The original clock lies in u in [1/2,1] and has the proved bound B_D<=min(nlog2,4sqrt(nD)), with B_0=0. A_lat is static in that clock. The actual j(x) remains unique until this bound; it is not copied into the source ledger. Outside 2Lambda is counted once, proving S4 exactly. No latent label count is identified with k_t.

When D<=C log(n+2), M=O_C(log(n+2)), H_*=O_C(log(n+2)^2), L=O_C(log(n+2)^3), and log kappa_d=O(log(n+2)). Multiplying by sqrt(nD) gives the stated sqrt(n) log(n+2)^(9/2) coefficient, including the actual source masses. D=0 has zero score-clock price even though the positive kernel envelope itself is nonzero. Varying outer parameters and D must be retained in their source sums unless uniformly bounded. The original same terminal-leaf ledger is required to compare these source sums with input mass; arbitrary overlapping source collections do not inherit it.

S21 is an exact split after the old R280 A_int allocation. Its residual is the original positive measure multiplied by (1-A_int^old)(1-A_lat), not a replacement posterior or a new norm. If the package also registers the separate R281 single-cut A10/A01 payments, they must be removed before using A_lat on the remaining original positive allocation: e.g. multiply A_lat by the already-unpaid remainder. The source upper bound is unchanged because this only decreases A_lat. The separate cut and latent receipts do not by themselves license charging overlapping left-hand allocations twice. This integration qualification was sent to the parent.

No signed negative credit is consumed. The latent-containment failure, full complementary soft response, and general global closure remain unpaid. The low-soft restriction ns<=D is an explicit theorem hypothesis, inherited only on the original surviving domain where it was actually established; the theorem does not certify an unrestricted all-s mother.

## Actual diagnostic replay

After checking SHA `e5e04d...`, I extracted the unique Python block to `/tmp/r281_soft_checks.py` and actually ran it. Output:

`PASS 314 checks; mixture moments ['1.0', '13.0']`

These cover ordinary 45-digit moment quadratures, exact Fraction coefficient/grid/tilt inequalities on the listed finite parameters, and ordinary scalar capped-product checks. They are not interval certificates, do not prove the countable entropy/profile statements, do not construct an original FULL instance, and do not certify coverage of the residual. The analytic proof above is the basis of this PASS.

Audit complete; no repository changes and no wider task claim.
