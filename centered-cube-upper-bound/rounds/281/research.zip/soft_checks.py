import sys
sys.path.insert(0, '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
from fractions import Fraction as F
import mpmath as mp
mp.mp.dps=45
checks=0

def w(x):
    x=abs(x)
    return mp.mpf(1) if x==0 else mp.exp(-x)-x*mp.e1(x)

def density(r):
    return r/2*(w(abs(r/2-mp.mpf('.5')))-w(r/2+mp.mpf('.5')))

mom=[]
for power,expected in [(0,1),(2,13)]:
    val=mp.quad(lambda r:r**power*density(r),[0,1,2,4,8,16,mp.inf])
    assert abs(val-expected)<mp.mpf('1e-32')
    mom.append(mp.nstr(val,35)); checks+=1

for n in [1,2,8,64,512]:
    for D in [F(0),F(1,4),F(1),F(5,2),F(10)]:
        M=min(n,D.numerator//D.denominator+1)
        zeta=1+1/(D+1)
        top=min(F(1),D/n)
        for s in [F(0),top/2,top]:
            k=min(n,(n*s).numerator//(n*s).denominator+1)
            sigma=F(k,n+1); gamma=F(n+1,n)
            assert k<=M and s<=gamma*sigma and 1-s<=gamma*(1-sigma)
            assert n*sigma<=D+1
            tilted=zeta*sigma/(1+(zeta-1)*sigma)
            assert n*tilted<=D+2
            z=1+(zeta-1)*sigma
            zmp=mp.mpf(z.numerator)/z.denominator
            assert n*mp.log(zmp)<=1+mp.mpf('1e-40')
            checks+=4

def I(a,b):
    if a==0 or b==0:return mp.mpf(0)
    return min(a,b)*(2+mp.log(max(a,b)/min(a,b)))

for aa,bb,kk in [(1,1,2),(1,1000,2),(1000,1,2),
                 (3,7,mp.mpf('1.01')),(7,3,100),
                 (mp.mpf('1e-12'),10,mp.mpf('1e6'))]:
    a,b,k=mp.mpf(aa),mp.mpf(bb),mp.mpf(kk)
    assert I(a,k*b)<=(1+mp.log(k))*a+b+mp.mpf('1e-30')
    assert I(a,b)<=2*mp.sqrt(a*b)+mp.mpf('1e-30')
    checks+=2
print('PASS',checks,'checks; mixture moments',mom)
