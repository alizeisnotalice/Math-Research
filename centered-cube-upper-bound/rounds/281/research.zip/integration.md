# R281 final integration: exact positive priorities and unpaid latent faces

Start with the original currently unpaid near positive traffic after the R277/R279 large-geometry payments. Retain ns(x)+R2(y,v)≤D, so any contributing receiver has ns(x)≤D. Restricting the receiver set to that condition preserves its original FIRST/hardcap. D is a uniform bound for the frozen outer block; otherwise keep its weighted source prices inside the original seed/leaf sum.

Use the R280 disjoint physical top/middle split, with ξ=c_jt/b and δ_n=(1/2)n^(-3/4). The top price remains 5Λ√n Wν. On the middle clock, write A0=A_int^old, Ab=1−A0, and A_sc=A10+A01 from R281 C11. The exact random-grid states and the input-core qualification of A01 give 0≤A_sc≤Ab. Finally let A_lat be the actual kernel-weighted latent allocation in R281 S9, with 0≤A_lat≤1.

The following is the exact pointwise positive identity on original near:

1 = A0 + A_sc + (Ab−A_sc)A_lat + (Ab−A_sc)(1−A_lat).

Thus first charge the old fullcell interior, then the single-cut allocation, then only the remaining allocation times A_lat. There is no assertion that A_sc and A_lat themselves are disjoint. For pricing, the third actual weight is bounded by A_lat; this only enlarges its upper estimate, not its actual charged positive portion.

Let κ=2+n log(1+1/(8√n)), and let L_{n,D} be the explicit constant in proof_soft.tex.txt S2. With B_D≤4√(nD), the original current positive quantity satisfies

P_current ≤ 5Λ√n Wν
 + (128Λ/√3)√(nD)√(WρWν)
 + 16Λ√(nD)(2+logκ)[(16/3)Wρ+Wν]
 + 16Λ√(nD)[(16/3)L_{n,D}(1+logκ)Wρ+Wν]
 + P_rem.

P_rem is the original middle-clock positive integrand, in the original dx ρ(dy)ν(dz) and full auxiliary posteriors, with all current unspent masks including near and ns+R2≤D, multiplied by (Ab−A_sc)(1−A_lat). This definition is an exact nonnegative restriction; it is not a replaced measure, signed residual or independent source moment. It includes simultaneous hard/core cuts and those soft off-core contributions for which the latent input rectangle fails whole-cell containment. No proof here bounds this remainder at root order.

On the SAME original disjoint terminal-leaf collection, Wρ≤Wβ≤||f||1 and Wν≤||f||1. For fixed K,epsilon, R279 supplies D=C0+C1log(n+2). L_{n,D}=O((log(n+2))^3), so each displayed paid term is at most C√n (log(n+2))^(9/2)||f||1 with the full, potentially enormous inherited constants. This is a bound for the listed positive allocations, not the general maximal-operator weak bound. No lower coverage fraction is asserted.

In S12's narrative, the factor e is the coefficientwise domination of EACH actual soft selector by e times the SUM of M fixed nodes. Its total weak cost includes M, explicitly in S14/S17 and L_{n,D}; it is not a dimension-free replacement of the entire sum by one probability node. The radius inflation costs the second e. No component obtains FIRST: only the actual allocated sum does.

No old negative credit, no ancestor copy of sources, no new j sum and no additional 2Λ occurs. The original actual posterior is untouched. The remaining research target is a source-paid estimate of the specified latent-face remainder, preserving both caps and avoiding a product of two cluster losses.
