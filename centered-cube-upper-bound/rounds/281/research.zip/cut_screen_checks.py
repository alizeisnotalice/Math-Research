import mpmath as m
m.mp.dps=60
N=0; err=m.mpf(0)
for A in [m.mpf('0.01'),m.mpf(1),m.mpf(17)]:
 for B in [m.mpf('0.03'),m.mpf(1),m.mpf(23)]:
  lo,hi=sorted((A,B)); I=lo*(2+m.log(hi/lo))
  val=m.quad(lambda x: min(1,A/x)*min(1,B/x),[0,lo,hi,m.inf])
  err=max(err,abs(I-val)); assert abs(I-val)<m.mpf('1e-55')
  for k in [m.mpf(1),m.mpf('1.2'),m.mpf(100)]:
   l,h=sorted((A,k*B)); Ik=l*(2+m.log(h/l))
   assert Ik <= (1+m.log(k))*A+B+m.mpf('1e-55')
   N+=1
print('PASS',N,'linear-cap checks; 9 exact-profile quadratures; maxerr',m.nstr(err,12))
