# 依赖与来源
R251胞内弱界：本项目rounds/251已有归档，原本地centered_cube_round251_20261017_final_checkpoint/proof.tex.txt CW1–CW2及signed_variation.md SV12；κ=2+nlog(1+d/a)，不能更换为膨胀帽。
R279已付大几何门及D的完整常数，R280原末端/中间时钟、共同胞和原后验消去顺序，均见相应已提交轮次。来源总账回查R112 proof.tex.txt:508及R273 proof.tex.txt:9。这里不复制历史ZIP。
本轮作者稿含LaTeX公式，保持最终审核字节，不编译PDF。文件内/tmp路径是当时审查来源；归档内的对应文件由manifest及审计SHA绑定。
本机运行：Python /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3；PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor。其它机器安装mpmath1.3.0即可尝试复现。
