# R281 actual uniform-interval mixture diagnostics

The final bounded run completed six D cases, three phases: initial D0,1,4; stress16,64; expanded256. D1024 was omitted as explicitly permitted to keep the menu modest. At each of40/60 working digits there are4683 included geometric-bin evaluations and six independent CDF checks;34 distinct Fraction soft-node cases and four exact gamma-power bounds are separate. Maximum scaled difference across116 numerical comparison fields is1.21585249637704e-38, at the expanded r_high endpoint. Ordinary multiprecision is not interval certification, and none of these checks certifies FULL, source payment or a dimension order.

## Physical mixture and independent normalization

The actual density phi=h*w is evaluated using E3 and its primitive using E4. For r>0, g(r)=-(r/2)phi'(r/2)=(r/2)[w(r/2-.5)-w(r/2+.5)], w(x)=exp(-|x|)-|x|E1(|x|), with w(0)=1. It is nonnegative by unimodality. The interval-mixture CDF is M(r)=2 int_0^(r/2)phi(x)dx-r phi(r/2). The code checks this against direct g integration at r.25,.5,1,2,4,8, splitting the cusp at1 as necessary. It independently integrates g and |logr|g over[0,.5,1,2,8,32,infinity]. The outputs at60digits are mass1 and

E|logr|=.899271856790816821050035560606264177449825383465025082159297.

Infinite quadrature tails are evaluated, not omitted, in these two moment diagnostics. Their error evidence is precision refinement only, not a certified quadrature bound.

## Finite bins and retained infinite tails

For each D,zeta=1+1/(D+1),h=logzeta. Let jlo=floor(log(1e-4)/h),jhi=ceil(log64/h). Included bins are (zeta^(j-1),zeta^j] for jlo<j<=jhi. Endpoints are computed separately at each precision. Masses use the CDF below1 and the positive E3/E4 survival expression above1, avoiding subtraction of an almost unit CDF. The omitted masses M(rlo) and 1-M(rhi) are explicitly saved; included plus omitted mass equals1 at the tested precision. No cutoff is called the complete spectrum.

|D|included bins|finite entropy|omitted mass (approx)|omitted entropy upper (approx)|
|---:|---:|---:|---:|---:|
|0|20|1.45729509818116|4.69e-14|4.68e-10|
|1|34|1.96490253655183|6.60e-14|9.95e-10|
|4|74|2.75078840382965|8.00e-14|1.05e-9|
|16|235|3.90745423838267|9.70e-14|1.14e-9|
|64|877|5.22721370219967|1.09e-13|1.23e-9|
|256|3443|6.59617656668038|1.18e-13|1.25e-9|

The missing entropy is bounded rather than discarded. For the small side, g(r)<=r/2 implies M(r)<=r²/4; integration by parts yields

int_0^rlo |logr|g(r)dr <= -log(rlo) M(rlo)+rlo²/8.

For r>=1 the analytic bounds phi(r/2)<=.5exp(-(r-1)/2) and its one-sided integral<=1/3exp(-(r-1)/2) give

1-M(r)<= (2/3+r/2)exp(-(r-1)/2).

The exact survival expression is2[E4(r/2-.5)-E4(r/2+.5)]+r phi(r/2). Hence

int_rhi^infinity logr g(r)dr
 <=log(rhi)[1-M(rhi)]+[1+4/(3rhi)]exp(-(rhi-1)/2).

Call the sum of these two tail-log bounds Ltail, and the exact omitted mass m0. Use a geometric reference distribution q_j=exp(-h|j|)/Z on all integer j, Z=(1+exp(-h))/(1-exp(-h)). Within each bin h|j|<=|logr|+h. Conditional Gibbs on the omitted bins therefore gives

H_omitted <= Ltail+(h+logZ)m0-m0 logm0.

This is the saved omitted_entropy_upper; finite entropy plus this upper is below log(2D+3)+15 in every tested row. The bound retains all infinite bins, but its numerical evaluation is ordinary40/60. The six passing instances do not prove the candidate for every D.

## Exact soft nodes

For n1,8,64,1024, take distinct D in{0,1,min(4,n),n} and s in{0,min(D,n)/(2n),min(D,n)/n}, deduplicated. Select k=max(1,ceil(ns)),sigma=k/(n+1), so the actual positive interior grid is used even at s0. All34 Fraction cases verify s<=D/n,1<=k<=n,0<sigma<1,n sigma<=D+1. The four rational powers gamma^n,gamma=1+1/n, are compared exactly against sum_(k=0)^8 1/k!=109601/40320. This sum is strictly below e by positive omitted Taylor terms, so finite gamma^n<=e is established without comparing a Fraction to a floating e. The general analytic inequality nlog(1+1/n)<=1 is recorded separately; finite checks do not prove it universally.

## Reproduction and scope

Python3.12.14, mpmath1.3.0, plus standard library only:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
r281_numeric.py --output r281_numeric.json
```

The script is self-contained and the deterministic JSON binds its SHA256, with no time or output path. Ninety-digit output strings preserve40/60 working results, not90-digit accuracy. The final full menu was actually rerun after compacting/deduplicating the exact-node records. No old menu, repository file, Git operation, PDF or external source was used. This is actual mixture computation plus separately identified exact coefficient arithmetic; no original branch or source-budget qualification is claimed.
