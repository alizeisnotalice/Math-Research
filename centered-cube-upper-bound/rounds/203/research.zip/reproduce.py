#!/usr/bin/env python3
"""Hash verification and numerical replay; not a proof assistant."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--verify-only', action='store_true')
parser.add_argument('--output-dir', type=Path)
parser.add_argument('--numeric-python', default=sys.executable)
args = parser.parse_args()
manifest = json.loads((root / 'manifest.json').read_text())
for name, digest in manifest.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
print('Verified', len(manifest), 'file hashes', flush=True)
if not args.verify_only:
    if args.output_dir is None:
        parser.error('--output-dir required')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    result = args.output_dir / 'scale_entropy_checks.json'
    if result.exists():
        parser.error('Use a fresh output path')
    subprocess.run([args.numeric_python, str(root / 'scale_entropy_checks.py'),
                    '--output', str(result)], check=True, env=os.environ.copy())
    assert result.read_bytes() == (root / result.name).read_bytes(), (
        'JSON differs; inspect actual environment and numerical results')
    print('Complete numerical JSON byte-identical', flush=True)
