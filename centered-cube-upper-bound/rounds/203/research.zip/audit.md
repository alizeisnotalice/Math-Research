# R203 independent audit

## 1. Independent premise screen

Read `task_contract.md` before new author manuscripts. Only this audit file is owned by the auditor; no Git, delegation, numerical execution or PDF compilation is authorized. The following checks precede full author-proof review.

For H uniform on [-1/2,1/2], its canonical Stein coefficient is 1/8-H^2/2. For Laplace(t), it is t^2+t|W|. The physical w is the mixture with prior density 2t, and the conditional t density at W=w is proportional to exp(-|w|/t) dt. Since t^2 and this weight are increasing, the elementary covariance inequality gives E(t^2|W=w)>=1/3. Therefore 1/3<=tau_w(w)<=1+|w|. Conditional convolution of the two integration-by-parts identities gives
\[
\tau_\phi(r)=\mathbb E[\tau_H(H)+\tau_w(W)\mid H+W=r],
\qquad \frac13\le\tau_\phi(r)\le\frac{13}{8}+|r|.
\]
The upper bound uses |W|<=|r|+1/2 and tau_H<=1/8. The resulting flux has the proper vanishing tail, so it agrees with the canonical coefficient N(r)/phi(r), N(r)=integral_r^infinity u phi(u)du. Evenness and mean zero also give positivity on the negative half-line.

The physical regularity needed here is phi C1, N C2 and tau_phi C1. The formula phi'=w(r+1/2)-w(r-1/2) does not assert a finite phi'' at the seam. The exact flux identity N'=-r phi yields, for the auxiliary positive scale b and fixed source v,
\[
\partial_{\log b}J_{b,v}
=\sum_i\partial_{ii}[b^2\tau_\phi((x_i-v_i)/b)J_{b,v}].
\]
This is a family identity, not proof of a common Markov semigroup. Changing this auxiliary b does not change the original fixed-window b without paying all parameter/qualification exchanges.

## 2. Mixture generator and measure scope

For fixed finite nu of mass m>0, let Q=J_b*nu, p=Q/m and H_i=integral b^2 tau_i J_v dnu. Then A_i=H_i/Q=b^2 E_pi tau_i. Locally in x and b in a compact positive interval, physical exponential tails give uniform-in-v bounds for the integrands and the required first/second spatial and first scale derivatives. No source position moment is required. In particular
\[
\partial_iH_i=-\int(x_i-v_i)J_vd\nu,
\quad \partial_{ii}H_i=-\int[1+r_i\ell(r_i)]J_vd\nu,
\quad \partial_{\log b}Q=\sum_i\partial_{ii}H_i.
\]
Tonelli and the physical noise moments give integral H_i=b^2(13/12)m, L1 norm of partial_i H_i<=b(11/12)m, and L1 norm of partial_ii H_i<=sqrt(V_scale)m. A_i>=b^2/3; its linear posterior-noise upper bound is pointwise, not a uniform bound over x. The weighted mixture with fixed eta in [0,1], e=integral eta dnu>0, has its own A_wi. Equal integrated full/weighted noise moments do not eliminate their pointwise coefficient difference. Zero mass/dead rows must be removed before normalization.

The actual original eta=1_Z w_t is frozen when constructing this auxiliary b-family. Recomputing the physical source weight, support, tree/window or posterior at a different b adds genuine source-measure and normalizer changes. The auxiliary p_w=Q_w/e is not the original Pi, and all original J Pi/target/source return qualifications from R202 remain.

## 3. Entropy commutator independently screened

Let g=grad log p, g_w=grad log p_w, delta g=g_w-g, and m_i=E_pi v_i, m_wi=E_pi_w v_i. Pointwise these conditional means are finite even for a finite source without first moment, because |v_i|J_v(x) has a uniform-in-v bound at fixed x. The exact Stein flux gives partial_i(A_i p)=p(m_i-x_i), with the weighted analogue. Consequently
\[
E_i=\partial_i(A_{wi}-A_i)+(A_{wi}-A_i)g_i
=(m_{wi}-m_i)-A_{wi}\delta g_i.
\]
Under justified entropy differentiation and integration by parts,
\[
K'=-\int p_w\sum_i A_{wi}(\delta g_i)^2
-\int p_w\sum_iE_i\delta g_i
=-\int p_w(m_w-m)\cdot\delta g.
\]
The positive diffusion term is canceled by a matching part of the actual commutator. The lower bound tau>=1/3 therefore does not by itself imply entropy dissipation. Global mean differences should be written (m_w-x)-(m-x), rather than separately assuming integrability of m_w or m. The domination p_w<=exp(H)p, H=log(m/e), gives coarse finite posterior-noise integrability when needed, but its cost must remain. Translation Fisher in this formula is not an X_y-material or original weighted traffic estimate.

## 4. Quantitative fixed-prior scale-entropy candidate

For fixed nu,eta and auxiliary b, K=KL(p_w||p)<=H=log(m/e). The component scale score L_v=-sum_i[1+r_i ell(r_i)] has mean zero, variance <=9n/4 and the already proved two-sided subgamma bound (v=2048n,c=16). Conditional Jensen preserves that MGF for the full mixture scale score L; the weighted scale score L_w has variance <=9n/4 under p_w. Exact differentiation is
\[
K'=\mathbb E_{p_w}[L_w\log(p_w/p)]-\mathbb E_{p_w}L.
\]
For 0<r<=exp(H), the scalar inequality r(log r)^2<=(H+2)(r log r-r+1) is valid: use the coefficient 2 on log r<=0, and log r+2 on log r>=0, then enlarge to H+2. Integrating gives E_pw log^2(p_w/p)<=(H+2)K. Entropy variation and the full-score MGF give |E_pw L|<=64sqrt(nK)+16K. Thus the proposed improved bound
\[
|K'|\le[(3/2)\sqrt{H+2}+64]\sqrt{nK}+16K
\]
passes, as does its log-scale window variation bound obtained from K<=H. H=0 and K=0 have zero right side. The older negative log-likelihood tail is useful only for integrability. The forthcoming proof must justify absolute continuity and differentiation/limit passages with actual uniform integrability, not merely name a truncation. No source position moment is needed for this noise-score route. Its entropy-scale fee is not an original material/target/capture payment.

## 5. Parent signed-material bridge candidate

For fixed nu,eta,y,b, r=p_w/p and ell=log r, a compactly supported C1 test coefficient C satisfies the exact integration-by-parts identity
\[
I_C=\int p_w C X_y\cdot\nabla\ell
=-\int p_w\ell[X_y\cdot\nabla C+C S_w],
\qquad S_w=n+X_y\cdot\nabla\log p_w.
\]
Consequently, if |C|<=B,
\[
|I_C|\le\sqrt{(H+2)K}
\left[\|X_y\cdot\nabla C\|_{L^2(p_w)}
+B\sqrt{nV_{\rm sc}+I_{\rm loc}C_w}\right],
\quad C_w=\int|(v-y)/b|^2\Pi(dv).
\]
The second norm follows by conditional Jensen for S_w using the actual selected prior. Compact support makes the integration by parts legitimate; noncompact extensions require justified cutoff removal and integrability. For bounded compact BV C, the derivative term is instead the real signed measure pairing -integral ell p_w X_y dot DC, including its jumps. Arbitrary measurable actual target coefficients do not acquire these derivatives. In a return to the original covariance/bias, a coefficient such as alpha E_pi_w C_v contains its actual alpha, posterior and qualification derivatives; its norm and gradient/variation are not paid by the entropy bound. This candidate is an exact signed interface, not a new full raw payment.

## 6. Full author reviews

Read complete `stein_kernel_geometry.md`, 265 lines, version `61661d9a0c5ff19d37b08b8cacb2406984cc34ef75a9cae2afec3ebdc22b4b72`, after the independent screen. SK1–24 pass. The internal N closed form differentiates to -r phi; its constant 5/8 and common r=1/2 value 5/12-E4(1)/2-E5(1) are correct. The convolution Stein proof, regularity, finite-source derivative exchanges, three global flux bounds and fixed-prior L1 scale-density bound match the independent checks. No false phi'' seam value, uniform posterior upper bound, source position moment, common-semigroup implication or original-b qualification is introduced. No necessary revision was found.

Read complete `parent_material_bridge.md` MB1–7. The likelihood scalar inequality, compact smooth signed pairing, its C=1 bounded noncompact extension, and the actual coefficient C_eff return are correct. The cutoff error tends to zero under the displayed L2 and moment assumptions; the left integral is absolutely integrable there. The BV convention DC=(C_plus-C_minus)n has the correct sign and retains the real smooth-measure pairing, rather than applying a Lebesgue estimate to the singular part. Its quantitative price requires a finite actual sup bound and actual gradient/variation costs. No arbitrary measurable original coefficient is asserted to meet these hypotheses. No necessary revision was found; this signed interface does not pay the original joint capture/hard-face boundary terms.

Read complete `diffusion_joint_budget.md` DJ1–24. The principal mathematics passes: exact posterior-noise probability flux, entropy commutator cancellation, the strengthened likelihood-square bound, fixed-prior entropy derivative and quantitative variation, and the concrete tangent-cutoff argument establishing absolute continuity without source position moments. The tangent below exp(-N) has h_N-z h_N'=-exp(-N); the two displayed derivative errors vanish uniformly by the stated noise-score and negative-likelihood tails. The explicit integrability bounds I<=832n/3 and T<=13n(1+exp H)/2 are correct; X=I+T+2K' and the material Cauchy factor are exact. Three narrow revisions were requested before binding: specify k>=1 for the posterior Jensen moment claim, explicitly retain a uniform/sup auxiliary log-length when extracting it from the global source sum, and repair isolated display-closing brackets. None changes the principal theorem or licenses an original raw payment.

Reread all three corrections in final DJ version `2fe3e1aefb9298c7ffd7a44ec4a01fbb6f0d85e375bb74a64961486758057899`: Jensen is explicitly k>=1 with uses 1,2,4; the global return uses a verified common lambda_star or retains individual lengths; display closings are repaired. No necessary revision remains.

## 7. Numerical and integration static checkpoint

Read complete `scale_entropy_checks.py`, without running it. Stein closed forms, seam derivative identities and independent finite N quadratures match the accepted formulas. The mixture derivative retains the normalization term kappa_w-kappa_full; prior and eta are fixed at both perturbed auxiliary scales. The finite-source log-likelihood bound and entropy/derivative analytic tail constants have the correct direction. The two signed C=1 diagnostics retain the finite cutoff boundary I+E(logratio S_w)=boundary, with correct tail terms and selected-source C_w/b^2. They are not integrals of absolute material bias. The stable scalar denominator series is correct and explicitly noninterval. Read final `numeric_notes.md` version `104be077e7ac4656eb27a212b900b00dae389c98314593027e83b22c9b155bc0`: six mixture cases, seven tau radii (three independent N quadratures), sixteen scalar cases at each precision, and two signed-material reuses are accurately labeled. Analytic tails do not certify finite quadrature or rounding. Parent's final independent driver is not prematurely reported. No necessary numerical revision remains.

Read the report and reproducer. The report keeps the material test derivative/variation, actual coefficient C_eff, source cap, H, outer source/time/window and selector costs, and distinguishes the auxiliary b entropy from the original selected scale. The driver's manifest verification, actual --output interface, explicit numerical interpreter, inherited environment, fresh output guard and complete JSON byte comparison are consistent. A future total-driver execution is not prematurely certified by this static review. No external unread theorem was used by this auditor.

Read the mathematical content of the complete 740-line initial `proof.tex.txt` integration. Its Stein, parent-material and final DJ formulas agree with the accepted manuscripts, including eta frozen before auxiliary b, C=1/BV qualifications, tangent-cutoff/UI, the exact square ledger, retained original material direction and the global lambda_star restriction. No necessary mathematical transcription correction was found. Then reread the updated introduction and final numerical subsection in the 797-line final version `c0812c2ce92e29420309e44bce4262c518eb6eba0153a1baa3b8ec48a455a4f0`. The finite evidence and execution labels agree with final notes. The final report's numerical paragraph was also reread; no necessary revision remains.

## 8. Final conclusion and freeze

All assigned author, integration, code and evidence reviews are complete. Actual JSON metadata confirms six mixture cases, seven tau points and sixteen scalar points at each precision; two existing cases carry the signed-material check. The auditor performed static review only, without numerical execution or TeX compilation. The author-reported run and the parent's future manifest-bound independent replay are kept distinct.

Accepted results: canonical physical Stein coefficient and its bounds, exact scale-family generation for finite sources without source position moments, the fixed-prior scale-entropy variation estimate with its AC/UI proof and full coefficient exchange, and the signed actual-material test identity with explicit radial derivative/BV interface costs. Three narrow DJ revisions were requested and verified. No common-semigroup assertion, free original-b deformation, unconditional entropy dissipation, or general original raw root-order payment is accepted. Actual target/capture/selector joint interfaces and original source/time/window costs remain. This audit is frozen with the ten other work files bound below; itself and future manifest are excluded.

## 9. Final SHA-256 binding

| File | SHA-256 |
|---|---|
| diffusion_joint_budget.md | `2fe3e1aefb9298c7ffd7a44ec4a01fbb6f0d85e375bb74a64961486758057899` |
| numeric_notes.md | `104be077e7ac4656eb27a212b900b00dae389c98314593027e83b22c9b155bc0` |
| parent_material_bridge.md | `0af18d587e925f4c12b620e1615464900d0d4c7db25e14ec1c8ad754d768793a` |
| proof.tex.txt | `c0812c2ce92e29420309e44bce4262c518eb6eba0153a1baa3b8ec48a455a4f0` |
| report.md | `d2ffc1b46b4dabdfb371c193533cd68709a78fdbb5251e65a80cfa5be4dca8bd` |
| reproduce.py | `a4d294e35ccc29cbd9f409938de552e550b05db0fc5847f7b3e671ef0ffa2ccb` |
| scale_entropy_checks.json | `85e92294c5fcdec06471ded69516f451bd8ab282100f509c9c4aeb834c5c4ffa` |
| scale_entropy_checks.py | `d638b38a307f8b999687a698d605e3bf56dc5c3e08f0f9575a5804a347802c9d` |
| stein_kernel_geometry.md | `61661d9a0c5ff19d37b08b8cacb2406984cc34ef75a9cae2afec3ebdc22b4b72` |
| task_contract.md | `4c518b0076df3cdc4dbf85b834cd5bf4237e253a4a4a0959edf06fb7b2e21179` |
