# R203 fixed-prior scale entropy diagnostics

Six actual one-dimensional finite-source phi mixtures were evaluated at 25 and 40 decimal digits. Initial cases are equal capture (zero entropy) and mixed capture; stress cases are rare selected source at displacement 2 and a farther displacement 8; expanded cases vary b to 1/2 and 2 and the capture weights. All priors and capture weights are fixed before varying the auxiliary b; no original terminal weight is recomputed. The JSON retains all rational positions, priors, capture weights, b and e.

## Physical entropy and scale derivative

For J_i=b^-1 phi((x-v_i)/b), the smooth scale score is kappa_i=-1-r_i phi'(r_i)/phi(r_i). The selected and full posterior scores are computed separately. Direct integration uses

K=integral pw log(pw/p),
D=integral pw [kappa_w log(pw/p)+kappa_w-kappa_full].

The zero-integral derivative terms are retained in D rather than silently discarded pointwise. K, D and selected mass are independently integrated with cached kernel values and explicit source/core/tail seams. Both priors sum to one after their respective normalization. The six 40-digit results are approximately:

| Case | K | Analytic dK/dlogb |
| --- | ---: | ---: |
| Equal capture | 0 | 0 |
| Mixed capture, shift 1/4, b=1 | 0.01318596134 | -0.02563026289 |
| Rare selected, shift 2, b=1 | 1.77026439004 | -2.24174857558 |
| Far rare selected, shift 8, b=1 | 4.51058786301 | -0.44375931257 |
| Narrow scale b=1/2 | 0.11759774561 | -0.09892794559 |
| Broad scale b=2, small capture | 0.17628596328 | -0.31535300241 |

Every finite test satisfies the supplied n=1 expression [64+1.5sqrt(H+2)]sqrt(K)+16K. The derivative is independently compared with a central difference in log b, using steps 1e-5 and 1e-6. The largest observed discrepancies are below 7.70e-11 and 7.70e-13, respectively. The largest 25/40 difference for K or analytic D is below 5.08e-26. The zero-entropy branch gives zero exactly in the computed expressions; no numerical negative K is clamped into a false certificate.

For these finite sources, the supplied log-Lipschitz constant Lphi=2/(1-exp(-1)) gives abs(log(pw/p))<=Lphi*diam(v)/b. Cutoffs X=max|v|+70b or +100b and phi(r)<=exp(1/2-r) yield the recorded entropy and derivative tail expressions. The latter uses the bound (logratio_bound+2)*2exp(1/2+(max|v|-X)/b)[9+8(X+max|v|)/b]. These control analytic truncation, not finite quadrature or floating rounding. Central-difference truncation allowances are also recorded. None is a directed interval enclosure.

## Stein kernel

The E4/E5 closed formula for N(r)=integral_r^infinity u phi(u)du was supplied by the author and used with tau=N/phi. Seven radii 0,1/4,1/2,3/4,2,8,32 are tested at both precisions. The code checks N'=-r phi and N''=-phi-r phi', including the seam N value. N is twice differentiable here; no finite phi''(1/2) is asserted or tested.

At radii 0,1/2,2, an independent finite integral of u phi(u) is compared with the closed N formula; its omitted tail is at most (X+1)exp(1/2-X). Maximum observed derivative-identity and closed-vs-integral residuals are below 3.24e-27 and 6.47e-27. All listed tau values satisfy 1/3<=tau<=13/8+r. For example tau(0) is about 0.65203137 and tau(32) about 32.05054284. This finite menu does not certify global extrema or replace the analytic Stein-kernel proof.

## Stable scalar entropy inequality

Sixteen scalar cases at each precision examine r(log r)^2<=(H+2)(r log r-r+1), with H=log(1/e), e=1,1/100,1/10000, and r<=exp(H). Zero r is handled by its exact endpoint convention, and r=1 gives both sides zero. Near one the input is x=log r=+-1e-20, with the positive side used only when H>0. The denominator is evaluated as the stable series sum_{k>=2}(k-1)x^k/k!, rather than cancellation of nearly equal terms. Other points use x exp(x)-expm1(x). This is finite high-precision numerical evidence for the nonrational values, not an exact Fraction certificate or a proof of the scalar inequality.

## Signed material reuse

Only the already computed mixed and rare shift-2 cases add I=integral pw x(g_w-g_full) and ElogSw=integral pw log(pw/p)(1+x g_w), with y=0. The finite-cut check is I+ElogSw=[x pw log(pw/p)] at the endpoints. Mixed/rare I values are about 0.027098227 and 1.560375911; ElogSw is their negative to reported precision, with boundary terms around 1e-45 and 1e-44. Both material truncation expressions are recorded.

The C=1 signed bound sqrt((H+2)K[9/4+64 Cw]) is evaluated with exact source Cw=5/104 and 4. The conservative bounds are about 0.46843007 and 54.95171333. This checks the absolute value of a signed whole integral only. It does not estimate integral pw abs(x(g_w-g_full)), nor the original weighted material error, and it is not a root-order payment.

## Actual execution and reproduction

The final local full run completed in about 36.2 seconds and reported PASS_FINITE_DIAGNOSTICS. Only standard Python and existing mpmath 1.3.0 are required. Actual local command:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 scale_entropy_checks.py --output scale_entropy_checks.json
```

The default local interpreter is /opt/homebrew/opt/python@3.14/bin/python3.14. The source uses normal import mpmath with no hardcoded runtime path. Relocation needs only the script and local task_contract.md; JSON binds its filename hash and records the mpmath version/entry hash. Timing and execution paths are omitted from JSON. The parent's manifest driver is responsible for the final independent isolated byte-for-byte replay; at the parent's request no additional redundant numerical run was started after this final execution.

These are finite actual scalar-kernel data with noninterval precision/difference controls, plus stable scalar diagnostics. There is no statistical sampling, multidimensional experiment, asymptotic fit, original alpha/history/FIRST/FULL source qualification or general-budget closure. No other agent's files were edited. Independent static review of the script passed without a required correction.
