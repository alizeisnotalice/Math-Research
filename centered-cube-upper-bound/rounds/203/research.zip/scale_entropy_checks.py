#!/usr/bin/env python3
"""Finite physical Stein-kernel and fixed-prior scale-entropy diagnostics."""
import argparse,hashlib,json,time
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent


def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [encode(v) for v in x]
    return x


def kernels(dps):
    mp.mp.dps=dps;half=mp.mpf('.5')
    def phi(x):
        r=abs(x)
        return 1-mp.expint(3,half-r)-mp.expint(3,half+r) if r<=half else mp.expint(3,r-half)-mp.expint(3,r+half)
    def derivative(x):
        r=abs(x)
        return mp.sign(x)*(mp.expint(2,r+half)-mp.expint(2,abs(r-half)))
    def N(x):
        r=abs(x)
        if r<=half:
            return mp.mpf(5)/8-r*r/2+r*(mp.expint(4,half-r)-mp.expint(4,half+r))-mp.expint(5,half-r)-mp.expint(5,half+r)
        return r*(mp.expint(4,r-half)-mp.expint(4,r+half))+mp.expint(5,r-half)-mp.expint(5,r+half)
    return phi,derivative,N


def tau_checks(dps):
    phi,dp,N=kernels(dps);out=lambda x:mp.nstr(x,dps+5);rows=[]
    for rq in (F(0),F(1,4),F(1,2),F(3,4),F(2),F(8),F(32)):
        r=mp.mpf(rq.numerator)/rq.denominator;n=N(r);p=phi(r);tau=n/p
        first=mp.diff(N,r);second=mp.diff(N,r,2)
        err1=abs(first+r*p);err2=abs(second+p+r*dp(r))
        assert mp.mpf(1)/3<=tau<=mp.mpf(13)/8+r and err1<mp.mpf('1e-16') and err2<mp.mpf('1e-16')
        row={'r':str(rq),'N':out(n),'phi':out(p),'tau':out(tau),'lower':out(mp.mpf(1)/3),'upper':out(mp.mpf(13)/8+r),
            'Nprime_identity_residual':out(err1),'Nsecond_identity_residual':out(err2)}
        if rq in (0,F(1,2),2):
            X=mp.mpf(80 if dps==25 else 110)
            cuts=sorted(set([r,X]+[a for a in map(mp.mpf,('.5','1','2','4','8','16','32','64')) if r<a<X]))
            integral=mp.quad(lambda x:x*phi(x),cuts);tail=(X+1)*mp.exp(mp.mpf('.5')-X)
            assert abs(n-integral)<mp.mpf('1e-16')
            row.update({'independent_N_finite_integral':out(integral),'N_integral_cutoff':out(X),'analytic_N_tail_upper':out(tail),'N_closed_vs_integral_difference':out(abs(n-integral))})
        rows.append(row)
    half=mp.mpf('.5')
    seam=mp.mpf(5)/12-half*mp.expint(4,1)-mp.expint(5,1)
    assert abs(N(half)-seam)<mp.mpf('1e-16')
    return {'dps':dps,'points':rows,'seam_N_formula_residual':out(abs(N(half)-seam)),
        'scope':'N is C2; no finite value of phi second derivative at the seam is asserted.'}


def entropy_integral(dps,priorq,etaq,vq,b,derivatives=True,material=False):
    phi,dp,_=kernels(dps);out=lambda x:mp.nstr(x,dps+5)
    val=lambda x:mp.mpf(x.numerator)/x.denominator
    prior=list(map(val,priorq));eta=list(map(val,etaq));v=list(map(val,vq));e=sum(p*w for p,w in zip(prior,eta))
    selected=[p*w/e for p,w in zip(prior,eta)];V=max(abs(a) for a in v)
    X=V+(70 if dps==25 else 100)*b;Lphi=2/(1-mp.exp(-1));log_bound=Lphi*(max(v)-min(v))/b
    @lru_cache(maxsize=65536)
    def point(x):
        r=[(x-a)/b for a in v];p=[phi(a)/b for a in r]
        full=sum(a*z for a,z in zip(prior,p));weighted=sum(a*z for a,z in zip(selected,p));ell=mp.log(weighted/full)
        K=weighted*ell
        if not derivatives:return (K,)
        gradient=[dp(a)/(b*phi(a)) for a in r];kappa=[-1-a*b*g for a,g in zip(r,gradient)]
        kfull=sum(prior[i]*p[i]*kappa[i] for i in range(len(v)))/full
        kw=sum(selected[i]*p[i]*kappa[i] for i in range(len(v)))/weighted
        D=weighted*(kw*ell+kw-kfull)
        gf=sum(prior[i]*p[i]*gradient[i] for i in range(len(v)))/full
        gw=sum(selected[i]*p[i]*gradient[i] for i in range(len(v)))/weighted
        return K,D,weighted,weighted*x*(gw-gf),weighted*ell*(1+x*gw)
    cuts=sorted(set([-X,X]+[a+b*z for a in v for z in map(mp.mpf,('-.5','0','.5'))]+[a+b*z for a in v for z in map(mp.mpf,('-16','-8','-4','-2','-1','1','2','4','8','16')) if -X<a+b*z<X]))
    K=mp.quad(lambda x:point(x)[0],cuts)
    tail_mass=2*mp.exp(mp.mpf('.5')+(V-X)/b)
    result={'K':K,'K_tail':log_bound*tail_mass,'cutoff':X}
    if derivatives:
        D=mp.quad(lambda x:point(x)[1],cuts);mass=mp.quad(lambda x:point(x)[2],cuts)
        assert K>=0 and abs(mass-1)<mp.mpf('1e-16')
        H=-mp.log(e);bound=(64+mp.mpf('1.5')*mp.sqrt(H+2))*mp.sqrt(K)+16*K
        assert abs(D)<=bound
        result.update({'D':D,'H':H,'bound':bound,'selected_mass':mass,
            'D_tail':(log_bound+2)*tail_mass*(9+8*(X+V)/b),'seams':cuts})
        if material:
            I=mp.quad(lambda x:point(x)[3],cuts);ES=mp.quad(lambda x:point(x)[4],cuts)
            endpoint=X*point(X)[0]-(-X)*point(-X)[0]
            assert abs(I+ES-endpoint)<mp.mpf('1e-16')
            Cwq=sum(p*w*a*a for p,w,a in zip(priorq,etaq,vq))/sum(p*w for p,w in zip(priorq,etaq))
            Cw=(mp.mpf(Cwq.numerator)/Cwq.denominator)/(b*b)
            material_bound=mp.sqrt((H+2)*K*(mp.mpf(9)/4+64*Cw))
            assert abs(I)<=material_bound
            result['material']={'signed_I':out(I),'E_logratio_Sw':out(ES),'sum':out(I+ES),
                'finite_boundary':out(endpoint),'identity_residual_after_boundary':out(I+ES-endpoint),
                'Cw':out(Cw),'Vsc_bound':'9/4','Iloc_bound':64,'signed_C1_bound':out(material_bound),
                'analytic_signed_I_absolute_tail_upper':out(16*tail_mass*(X+b)/b),
                'analytic_E_logratio_Sw_absolute_tail_upper':out(log_bound*tail_mass*(1+8*(X+b)/b)),
                'scope':'Absolute value of the signed integral only, not an integral of absolute material bias.'}
    return result


def mixture_case(dps,label,prior,eta,v,bq,material):
    mp.mp.dps=dps;b=mp.mpf(bq.numerator)/bq.denominator
    central=entropy_integral(dps,prior,eta,v,b,True,material)
    h=mp.mpf('1e-5' if dps==25 else '1e-6')
    plus=entropy_integral(dps,prior,eta,v,b*mp.exp(h),False)
    minus=entropy_integral(dps,prior,eta,v,b*mp.exp(-h),False)
    difference=(plus['K']-minus['K'])/(2*h);error=abs(difference-central['D'])
    assert error<mp.mpf('1e-5')
    out=lambda x:mp.nstr(x,dps+5)
    result={'dps':dps,'K':out(central['K']),'H':out(central['H']),
        'analytic_scale_derivative':out(central['D']),'theorem_bound_n1':out(central['bound']),
        'central_difference_step_logb':out(h),'central_difference_derivative':out(difference),
        'analytic_vs_central_difference':out(error),'selected_mass':out(central['selected_mass']),
        'cutoff_X':out(central['cutoff']),'analytic_entropy_tail_upper':out(central['K_tail']),
        'analytic_derivative_tail_upper':out(central['D_tail']),
        'central_difference_entropy_tail_upper':out((plus['K_tail']+minus['K_tail'])/(2*h)),
        'finite_seams':[out(x) for x in central['seams']]}
    if material:
        result['signed_material_bridge']=central['material']
        result['signed_material_bridge']['Cw_exact']=str(sum(p*w*a*a for p,w,a in zip(prior,eta,v))/(sum(p*w for p,w in zip(prior,eta))*bq*bq))
    return result


def scalar_log_check(dps):
    mp.mp.dps=dps;out=lambda x:mp.nstr(x,dps+5);rows=[]
    for mass in (F(1),F(1,100),F(1,10000)):
        H=-mp.log(mp.mpf(mass.numerator)/mass.denominator)
        rows.append({'source_mass':str(mass),'H':out(H),'log_r_label':'r_zero','log_r':'negative infinity','r':'0','numerator':'0','stable_denominator':'1','rhs':out(H+2),'margin':out(H+2),'method':'exact zero-r convention','equality_r1':False})
        xs=[('minus_one',mp.mpf(-1)),('near_one_below',-mp.mpf('1e-20')),('at_one',mp.mpf(0))]
        if H:xs += [('near_one_above',mp.mpf('1e-20')),('upper_endpoint',H)]
        for label,x in xs:
            if abs(x)<mp.mpf('.1'):
                denominator=mp.fsum((k-1)*x**k/mp.factorial(k) for k in range(2,100))
                method='stable power series in log(r)'
            else:
                denominator=x*mp.exp(x)-mp.expm1(x);method='expm1 log-coordinate expression'
            numerator=mp.exp(x)*x*x;rhs=(H+2)*denominator
            assert denominator>=0 and numerator<=rhs
            rows.append({'source_mass':str(mass),'H':out(H),'log_r_label':label,'log_r':out(x),
                'r':out(mp.exp(x)),'numerator':out(numerator),'stable_denominator':out(denominator),
                'rhs':out(rhs),'margin':out(rhs-numerator),'method':method,'equality_r1':x==0})
    return {'dps':dps,'cases':rows,'scope':'Finite noninterval stability diagnostics; zero/one endpoint conventions do not certify nonrational logarithms.'}


def run():
    specs=[
        ('initial','equal_capture_zero_entropy',[F(1,2),F(1,2)],[F(1),F(1)],[F(0),F(1)],F(1),False),
        ('initial','mixed_capture',[F(3,4),F(1,4)],[F(1,10),F(1)],[F(0),F(1,4)],F(1),True),
        ('stress','rare_selected',[F(99,100),F(1,100)],[F(0),F(1)],[F(0),F(2)],F(1),True),
        ('stress','far_rare_selected',[F(99,100),F(1,100)],[F(0),F(1)],[F(0),F(8)],F(1),False),
        ('expanded','narrow_scale',[F(1,2),F(1,2)],[F(1,4),F(1)],[F(0),F(1)],F(1,2),False),
        ('expanded','broad_scale_small_capture',[F(9999,10000),F(1,10000)],[F(1,10000),F(1)],[F(0),F(2)],F(2),False),
    ]
    rows=[]
    for stage,label,p,eta,v,b,material in specs:
        runs=[mixture_case(dps,label,p,eta,v,b,material) for dps in (25,40)]
        differences={k:abs(mp.mpf(runs[0][k])-mp.mpf(runs[1][k])) for k in ('K','analytic_scale_derivative')}
        assert all(d<mp.mpf('1e-16') for d in differences.values())
        rows.append({'stage':stage,'label':label,'prior':p,'capture_weights_fixed_for_all_b':eta,'positions':v,'b':b,
            'e':sum(a*w for a,w in zip(p,eta)),'runs':runs,'precision_differences':{k:mp.nstr(d,12) for k,d in differences.items()}})
    return {'schema':'r203_scale_entropy_v1','inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'dependencies':{'mpmath_version':mp.__version__,'mpmath_entry_sha256':hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()},
        'n':1,'mixture_case_count':len(rows),'stage_counts':{'initial':2,'stress':2,'expanded':2},
        'derivative_formula':'integral pw [kappa_w log(pw/p)+kappa_w-kappa_full], kappa_i=-1-r_i phi_prime(r_i)/phi(r_i)',
        'bound':'[64+1.5sqrt(H+2)]sqrt(nK)+16K','precision_dps':[25,40],
        'mixture_cases':rows,'tau_checks':[tau_checks(25),tau_checks(40)],
        'scalar_log_checks':[scalar_log_check(25),scalar_log_check(40)],'status':'PASS_FINITE_DIAGNOSTICS',
        'limitations':['Actual finite-source one-dimensional phi kernels only; no original alpha/history/FIRST/FULL construction.',
            'Priors and capture weights are fixed before varying auxiliary b; original terminal weights are not recomputed.',
            'Analytic tail expressions bound truncation only, not mpmath quadrature, differentiation or rounding.',
            'Central difference and precision comparisons are finite diagnostics, not interval or general theorem certificates.',
            'The material addition is a signed C=1 integral for two existing cases, not an absolute-integral or general root budget.',
            'No dimension-order fit or arbitrary-source/multidimensional conclusion.']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'scale_entropy_checks.json');args=ap.parse_args()
    start=time.monotonic();r=run();args.output.write_text(json.dumps(encode(r),indent=2,sort_keys=True)+'\n')
    print('PASS: 6 physical mixtures, tau checks and stable scalar diagnostics; seconds='+str(round(time.monotonic()-start,3)))
