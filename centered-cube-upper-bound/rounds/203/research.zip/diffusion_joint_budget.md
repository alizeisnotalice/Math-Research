# R203：两种真实混合的尺度熵、扩散系数交换与原预算边界

状态：证明固定原来源权下的精确尺度相对熵公式，以及无需全来源位置矩的定量尺度熵变差界。后者保留 log(ν(V)/e) 的实际费用，控制的是共同来源先积分后的熵曲线，不是逐来源上确界。原材料方向、target 权、capture 与 selector 的联合根阶预算仍未完成。

## DJ1　固定来源与辅助尺度的量词

固定一个原 `(ω,V,j,y,t)` 状态及其原窗口，ν=νV 是有限正测度，
\[
 \eta(v)=1_{Z_t(y)}(v)w_t(y,v),\quad e=\int\eta\,d\nu,
 \quad m=\nu(\mathbb R^n),\quad \Pi=\eta\nu/e.
\]
只在 e>0 行定义 Π；e=0 原行先置零。这里不假设 ν≤β。η 是原来源权，包含原 carrier、删除和软衰减，不是新选来源概率。

为了研究生成元，将这一**已经固定的 ν、η**与同一个 φ 形成辅助尺度族
\[
 J_{b,v}(x)=b^{-n}\prod_i\phi((x_i-v_i)/b),\quad
 p_b(x)={1\over m}\int J_{b,v}(x)\nu(dv),\quad
 p_{w,b}(x)={1\over e}\int J_{b,v}(x)\eta(v)\nu(dv).
 \tag{DJ1}
\]
以下令 r=log b。原状态的参考 b 记为 b0；只有 b=b0 时这些密度直接等于原 full/Π 混合。沿辅助 b 改变时，η仍冻结在原 b0，不能擅自替换成另一窗口、另一森林或重新计算的 wt。由 η≤1，
\[
 0<p_w\le e^H p,\qquad H=\log(m/e)\ge0. \tag{DJ2}
\]
ν 可无密度、无梯度、无一阶或二阶位置矩。b 始终限于紧正区间时，后述局部微分及全空间积分不需要补这些假设。

## DJ2　真实生成元及两种后验扩散系数

本轮辅助 `stein_kernel_geometry.md` SK10–SK11、SK18–SK22 从原 φ 证明
\[
 (\tau_\phi\phi)'(z)=-z\phi(z),\qquad
 {1\over3}\le\tau_\phi(z)\le{13\over8}+|z|,
 \qquad \int\tau_\phi\phi=\int z^2\phi(z)dz={13\over12}.
 \tag{DJ3}
\]
因此单一核及固定来源混合的真实生成元为
\[
 \partial_rJ_{b,v}=\sum_i\partial_{ii}\{b^2\tau_\phi((x_i-v_i)/b)J_{b,v}\},
\]
\[
 \partial_rp=\sum_i\partial_{ii}(A_ip),\qquad
 \partial_rp_w=\sum_i\partial_{ii}(A_{wi}p_w), \tag{DJ4}
\]
其中
\[
 \pi_x(dv)={J_{b,v}(x)\nu(dv)\over mp(x)},\quad
 \pi_{w,x}(dv)={J_{b,v}(x)\eta(v)\nu(dv)\over ep_w(x)},
\]
\[
 A_i=b^2\mathbb E_{\pi_x}\tau_\phi((x_i-v_i)/b),\quad
 A_{wi}=b^2\mathbb E_{\pi_{w,x}}\tau_\phi((x_i-v_i)/b).
 \tag{DJ5}
\]
两种系数一般不同。它们不是一条共同热半群的扩散系数。每坐标有
\[
 A_i,A_{wi}\ge b^2/3,\quad
 \int pA_i dx=\int p_w A_{wi}dx=13b^2/12. \tag{DJ6}
\]
第二个等式各自属于自己的混合密度；不能据此把 A_i 在 p_w 下的费用免费换成 13b²/12。

## DJ3　概率流的精确简化：源位置只以条件噪声出现

记 g=∇logp、gw=∇logpw、δg=gw−g，以及
\[
 \mu_i(x)=\mathbb E_{\pi_x}v_i,\qquad
 \mu_{wi}(x)=\mathbb E_{\pi_{w,x}}v_i.
\]
任意有限 ν 下这些点态后验均值存在：固定 x,b 后，|v_i|Jb,v(x) 对 v 有界，故不需全 ν 一阶矩。由 Stein 一阶式，
\[
 \boxed{\partial_i(A_ip)=p(\mu_i-x_i),\qquad
 \partial_i(A_{wi}p_w)=p_w(\mu_{wi}-x_i).} \tag{DJ7}
\]
于是 DJ4 也写成两条概率连续性方程
\[
 \partial_rp+\nabla\cdot(pV)=0,\quad V=x-\mu,
 \qquad
 \partial_rp_w+\nabla\cdot(p_wV_w)=0,\quad V_w=x-\mu_w.
 \tag{DJ8}
\]
所有全空间估计均将 μw−μ 写成 `(μw−x)−(μ−x)`。不能分别要求或提取 ∫|x|p 与 ∫|μ|p，它们可能无限。

条件 Jensen 和真实噪声矩给
\[
 \int p|V|^k dx\le\int J_{b,0}|x|^k dx<\infty,\qquad
 \int p_w|V_w|^k dx\le\int J_{b,0}|x|^k dx
 \tag{DJ9}
\]
对每个有限 k≥1 成立（下文只需 k=1,2,4）；不将该 Jensen 方向延伸到 0<k<1。另由 DJ2，∫pw|V|k≤e^H∫p|V|k。这些可能昂贵但有限的中间界足以使下述积分分部合法；不把 e^H 当作最终新熵估计的费用。

## DJ4　尺度相对熵与完整系数交换

设
\[
 \ell_b(x)=\log(p_w/p),\qquad
 \mathcal K(b)=\int p_w\ell_b\,dx.
\]
Jensen 的来源边缘化给
\[
 0\le\mathcal K(b)\le D(\Pi\Vert\nu/m)\le H. \tag{DJ10}
\]
对每个正紧 b 区间，K 是绝对连续函数，几乎处处满足
\[
 \boxed{\mathcal K'
 =-\int p_w\sum_i A_{wi}(\delta g_i)^2dx
  -\int p_w\sum_i E_i\delta g_i dx,} \tag{DJ11}
\]
\[
 E_i=\partial_i(A_{wi}-A_i)+(A_{wi}-A_i)g_i.
\]
这是两个实际不同生成元的公式，第二项不能删去。

进一步，DJ7 逐点给
\[
 \boxed{E_i=(\mu_{wi}-\mu_i)-A_{wi}\delta g_i.} \tag{DJ12}
\]
代入后得到更强的精确联合表达
\[
 \boxed{\mathcal K'=-\int p_w(\mu_w-\mu)\cdot\delta g\,dx.} \tag{DJ13}
\]
正扩散项与系数交换内的一整份相反项精确抵消。故不能仅凭 τφ≥1/3 就声称 K 沿尺度耗散、或用 K 端点差控制 Fisher。实际尚待几何利用的是**同一两种后验的均值差与得分差的联合量**。

证明 DJ13 可直接对 DJ8 积分分部。紧 receiver 截断后边界项含 pw Vwℓ、pw V；DJ9、下节的 ℓ 矩及 Hölder 使它们可积，截断半径趋无穷时边界项消失。δg 每坐标绝对值≤16/b，所以右端绝对可积。再用 DJ12 即得 DJ11。不存在 ∞−∞；下节给独立的熵 AC 与微分极限论证。

## DJ5　关键似然平方估计

对任意 0<z≤e^H，
\[
 \boxed{z(\log z)^2\le(H+2)(z\log z-z+1).} \tag{DJ14}
\]
这是全区间的初等不等式，保留 H 的真实价格。证明令 t=logz、Ψ=e^t(t−1)+1。t≤0 时
\[
 2\Psi-e^tt^2=2-e^t(t^2-2t+2)\ge0;
\]
因为右端在 t≤0 随 t 减小而不减，t=0 为零。0≤t≤H 时
\[
 (t+2)\Psi-e^tt^2=e^t(t-2)+t+2\ge0,
\]
其二阶导数为 te^t≥0，函数及一阶导数在零处均为零。用 t+2≤H+2 即得。

取 z=pw/p 并积分，∫p(z−1)=0，得到
\[
 \boxed{\int p_w\ell_b^2dx\le(H+2)\mathcal K(b).} \tag{DJ15}
\]
因此 K=0 时真实似然及该平方量均为零；不留下人为的常数误差。

## DJ6　无全来源矩的定量尺度熵变差定理

单个物理 J 的尺度 score 为
\[
 L_v=\partial_r\log J_{b,v}
 =-\sum_i\{1+r_i\phi'(r_i)/\phi(r_i)\},\qquad r_i=(x_i-v_i)/b.
\]
引用 R201 `signed_transport_budget.md` ST4–ST-A 已证噪声矩与双侧 score 指数矩：
\[
 E_{J_v}L_v=0,\qquad E_{J_v}L_v^2\le9n/4,
\]
\[
 \log E_{J_v}e^{tL_v}\le{2048n\,t^2\over2(1-16|t|)},\qquad |t|<1/16. \tag{DJ16}
\]
这些常数沿所有 b,v 一致。令 L=EπLv、Lw=EπwLv，则
\[
 \partial_rp=pL,\quad\partial_rp_w=p_wL_w,
\]
\[
 \boxed{\mathcal K'=\int p_wL_w\ell_b\,dx-\int p_wL\,dx.} \tag{DJ17}
\]
注意最后一项的中心是 full p；不能删成 weighted 均值零。

**定理。** 任意 DJ1 的有限来源与固定 η，沿任意正紧辅助 b 区间，
\[
 \boxed{|\mathcal K'(b)|\le
 \left[64+\tfrac32\sqrt{H+2}\right]\sqrt{n\mathcal K(b)}
 +16\mathcal K(b)\quad\text{a.e. in }\log b.} \tag{DJ18}
\]
因而设 λb=log(b1/b0)，
\[
 \boxed{\operatorname{Var}_{[\log b_0,\log b_1]}\mathcal K
 \le\lambda_b\left\{
 [64+\tfrac32\sqrt{H+2}]\sqrt{nH}+16H\right\}.} \tag{DJ19}
\]
H=0 时 η=1 ν-a.e.、pw=p，全部取零。K=0 的导数式按零支解释。

证明：Jensen 给 ∫pwLw²≤9n/4。配合 DJ15，DJ17 第一项绝对值≤(3/2)√[n(H+2)K]。

对第二项，条件 Jensen 及 DJ16 给 full 混合 score 的 ±t 指数矩同一上界。以下只用有限 tilted KL 的直接非负性：若 v=2048n、c=16、0<t<1/c，则
\[
 t\,|E_{p_w}L|\le\mathcal K+{vt^2\over2(1-ct)}.
\]
这里 E_pw|L| 有限，由 pw≤e^Hp 和 score 二阶矩直接保证；不引用未核的外部变分定理。当 K>0 取
\[
 t={\sqrt{2K/v}\over1+c\sqrt{2K/v}},
\]
即得 |E_pwL|≤√(2vK)+cK=64√(nK)+16K。K=0 用 pw=p 及 E_pL=0。两项相加为 DJ18，积分并用 K≤H 得 DJ19。

DJ19 是一项新的共同来源、全 receiver 熵曲线变差预算：没有 m/e 的裸指数倍数，也没有 full ν 位置矩；它支付全部尺度符号变化而非只控制端点差。但 H 可以很大，且该熵不是原 companion，不能称原一般根阶付款。

## DJ7　绝对连续性及通极限的具体控制

本节补齐 DJ17–19 对任意有限 ν 的适用性。取 b 的正紧区间。单核的所有有限阶噪声 score 矩一致有限，因而混合 L、Lw 在各自概率下也有一致四阶矩。密度 p、pw 作为 L1(dx) 值函数对 logb 绝对连续，导数分别为 pL、pwLw；可由单核 L1 微分及正来源 Tonelli 证明。

DJ2 给 ℓ≤H，且对 s≥0，
\[
 \Pr_{p_w}\{\ell<-s\}\le e^{-s}. \tag{DJ20}
\]
所以 E_pw|ℓ|k≤Hk+k!，特别四阶一致有限。p_w≤e^Hp 还给 E_pw L²≤e^H(9n/4)。因此 DJ17 两项的绝对积分沿该紧区间一致有限。

更精确地，对 zlogz 在 z<e^-N 处用该点的切线延拓，记凸 C1 函数 hN；取 N>H，不需上端截断。hN′ 等于截断后的 1+logz，且在 z<e^-N 上 hN−zhN′=−e^-N。对 ∫p hN(pw/p) 可直接使用 L1 密度链式法则，导数为
\[
 \int p_w L_w h_N'(pw/p)
 +\int pL\{h_N(pw/p)-(pw/p)h_N'(pw/p)\}.
\]
首项趋于 ∫pwLw(1+ℓ)：在低似然层的误差由 score 四阶矩、DJ20 和 ℓ 的四阶尾积分趋零，且沿紧 b 区间一致。第二项趋于 −∫pwL；其低似然层误差至多
\[
 e^{-N}E_p|L|+
 (E_{p_w}L^2)^{1/2}\Pr_{p_w}(\ell<-N)^{1/2},
\]
一致趋零。函数积分本身也收敛至 K，因为切线延拓误差受 e^-N 的 p 积分控制。故截断链式法则可在时间积分后取极限，给 K 的绝对连续性和 DJ17。

若还需先做空间紧截断，两种来源概率是有限测度，b 位于紧区间时卷积族一致 tight；以上高阶矩与 Hölder 令空间尾误差一致趋零。此处用 tightness，不是假设来源位置矩。DJ7–9 的概率流边界同理按条件噪声矩与 log 似然尾处理，故 DJ11/13 与 DJ17 属于同一个真实熵导数。

## DJ8　扩散交换与 Fisher 的精确平方账

为避免误把 DJ19 当作 Fisher 估计，定义同一 b 下的有限量
\[
 \mathcal I=\int p_w\sum_i A_{wi}\delta g_i^2,
 \quad \mathcal T=\int p_w\sum_i{(\mu_{wi}-\mu_i)^2\over A_{wi}},
 \quad \mathcal X=\int p_w\sum_i{E_i^2\over A_{wi}}.
\]
DJ6 与 |δgi|≤16/b 给
\[
 \mathcal I\le{832\over3}n.
\]
DJ9、pw≤e^Hp 及 Awi≥b²/3 给一个合法但昂贵的有限界
\[
 \mathcal T\le{13\over2}n(1+e^H),\qquad
 \mathcal X\le2\mathcal T+2\mathcal I.
\]
这几个粗界仅用来保证平方代数可积，不作为本轮期望的源付款。DJ12 的完整平方恰给
\[
 \boxed{\mathcal X=\mathcal I+\mathcal T+2\mathcal K'.} \tag{DJ21}
\]
因此，对交换项先作 Young 并把 X 当小余项，会把同一份 I 隐藏到 X 中。即使 K′ 很小，DJ21 也不迫使 I 很小。不能凭 τ 椭圆性、熵端点或 DJ19 单独丢掉交换。

## DJ9　回到原材料偏差的真实价格

在原 b=b0，令 Xy=x−y。原 R202 的中心偏差是
\[
 \mathfrak b_t=X_y\cdot\delta g,
\]
与 DJ13 中的 μw−μ 方向不同。Cauchy 和 Awi≥b²/3 给
\[
 \boxed{\int p_w|\mathfrak b_t|dx
 \le\sqrt{3(13n/12+C_w)}\,\sqrt{\mathcal I},\qquad
 C_w=\int\|(v-y)/b\|_2^2\Pi(dv).} \tag{DJ22}
\]
证明把 |X·δg|≤√(ΣXi²/Awi)√(ΣAwiδgi²) 后在 pw 下积分。真实 Π carrier 给 Cw≤17n(a/b)(5logn+1/2)，只用于 weighted 来源，不能套到全 ν。

DJ18–19 没有提供 DJ22 所需的 I 小价。用 DJ8 粗界代入仍至多 O(n√log n) 的材料一阶费用，不是根阶。

原 active capture 上 ζv=αJv/av、ρv+ζv≤1，因此 R202 的 normalization 项为
\[
 -2\rho_v\zeta_v z_v^2F_v\,\mathfrak b_t,
 \qquad 2\rho_v\zeta_v\le\tfrac12.
\]
在实际 Bv≤B* 对 x、target 统一的资格下，其一槽绝对价至多 B*²/2 乘 DJ22。变 Bv、原 H、good/bad、另一 Πu 槽必须保留；不能将 B0/Wg 的 tiny-Wg 费用取出后称常数。辅助熵是 signed 共同来源量，任意 target 截取不再继承 DJ18 的净补偿。

父稿 `parent_material_bridge.md` 独立研究直接以真实 log 似然积分分部支付 signed 材料项的路线。本稿不重复该证明。即使采用那条路线，实际 target 系数的导数、硬跳与资格入口仍须付，不能默认 good/history 为 BV。

## DJ10　原 α、窗口、来源及选择器账

原归一化依旧是
\[
 \alpha Q_J=Dq-M_U,
\]
\[
 \mathcal D_y(\alpha J_v)
 ={J_v\over Q_J}\{\mathcal D_y(Dq)-\mathcal D_yM_U\}
 +\alpha J_v X_y\cdot\nabla\log(J_v/Q_J).
 \tag{DJ23}
\]
这里 \(\mathcal D_y=\partial_{\log L}+X_y\cdot\nabla_x\)，原参考 b 固定。DJ18 控制的是**另一个**固定来源的 ∂logb 熵族，不把 DJ23 的材料方向替成尺度方向。改变原 b 的窗口、当前 s/L/R 或 η 时还存在真实状态交换。

若仅对 DJ19 这个辅助熵价按原 β、j/time 累计，合法账是
\[
 \mathbb E\sum_{V,j}\int_{I_j}{dt\over t}\int\beta_V(dy)\,
 \lambda_b\{[64+\tfrac32\sqrt{H_{V,j,y,t}+2}]\sqrt{nH_{V,j,y,t}}
 +16H_{V,j,y,t}\}, \tag{DJ24}
\]
其中 H=log(νV(V)/et)，e=0 原行零，λb 是实际使用的辅助 b 区间长度。完整 Ij、T* 及独立窗口账均保留。只有获得 H 的真实来源加权费用后才能将此式压成 WA；本稿没有均匀 leaf mass cap，也没有把 ν/e 当概率。

若有合法统一 H≤H*，并且所有被计费窗口的辅助对数长度均≤同一 λ*，DJ24 可被 λ* T*Φn(H*)Wβ≤λ* T*Φn(H*)WA 控制。不同窗口不能无价共用一个未核验的 λb；没有有限统一 λ* 时保留 DJ24 的逐窗长度。这是明确费用的推论，不登记为新的原 raw 子支：H* 尚非一般合同，且辅助熵到原平方 companion 的桥仍未证明。

## DJ11　首个实质未付关系

新结果是 DJ18–19：真实原核的 fixed-prior 混合尺度熵，拥有无全来源矩、只付对数质量比的定量总变差界。精确概率流 DJ12/13 和平方账 DJ21 同时说明，不能由此免费得到 Fisher 耗散。

下一步实际需要联合的不是任意新范数，而是以下同点几何：原 capture 权乘在 target 上时，full 与 selected 后验的条件来源位移 `μw−μ`，能否同真实 `Xy` 方向及 active capture 的空间变化共同结算。原 reserve 只控制 K0 加权的缺捕获值，不给此方向关系或 target 导数。若继续使用 diffusion，须在原权重下支付 DJ12 的系数交换；若采用 signed 材料分部，须支付父稿中的实际 target 输运项。两者都必须保原 Π、α、QJ full 来源与 receiver 域。

本稿不把原核称热半群，不导入未经核验的 de Bruijn 定理，不把辅助 b 的熵总变差当成原 L(x) selector 的正变差。即使某个核级费用为 √n，作为 companion 与 E_J≤nWA/(2K) 合并仍可能只得 n^(3/4)，未证明一般原 raw 根阶。
