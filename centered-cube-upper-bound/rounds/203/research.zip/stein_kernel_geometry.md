# R203：物理软核的 Stein 系数与真实尺度生成元

状态：辅助物理核证明检查点。本文自洽证明 φ=h*w 的 canonical Stein 系数、上下界、接口正则性与精确尺度生成元；固定任意有限来源的混合可无源位置矩交换局部导数，并保留其真实后验系数。本文不是主相对熵预算，没有证明 full/weighted 系数交换或原 raw 根阶价，不引入外部文献定理。

## SK1　概率表示、正则性与尾部

固定 h=1[-1/2,1/2]，其积分为1。令
\[
 \ell_t(u)={1\over2t}e^{-|u|/t}\quad(0<t\le1),\qquad
 w(u)=\int_0^1e^{-|u|/t}dt=\int_0^1 2t\ell_t(u)dt,
 \qquad\phi=h*w. \tag{SK1}
\]
因此 T 具有密度2t，W|T=t服从 Laplace_t，H独立服从h，H+W的密度为φ。这里只是物理核的概率表示，绝不假原来源坐标或历史独立。w、φ均严格正、偶且积分1。

w 连续且局部绝对连续。u≠0时
\[
 w'(u)=-\operatorname{sgn}(u)\int_0^1t^{-1}e^{-|u|/t}dt.
\]
右侧在u=0有对数奇性，但可积；例如∫0^R∫0^1t^-1e^-u/t dtdu=∫0^1(1−e^-R/t)dt≤1。于是w′∈L1，无0处跳 delta。

\[
 \phi'(r)=w(r+1/2)-w(r-1/2) \tag{SK2}
\]
连续，故φ∈C1且φ>0。φ″仅需按局部L1导数理解，在±1/2可有对数奇性；本文不声称这两点φ″有限。φ′本身连续，故没有虚构的φ″原子。

对|r|≥1/2，w(u)≤e^-|u|给
\[
 0<\phi(r)\le e^{1/2-|r|}. \tag{SK3}
\]
所有多项式矩有限。已证 logφ Lipschitz 界也可沿用R201 TI6，但下面的 Stein 核构造不依赖来源梯度。

## SK2　两个组成核的 Stein 身份

uniform 核的系数为
\[
 \tau_H(u)={1/4-u^2\over2}\quad(|u|\le1/2).
\]
系数在两端为0，故分布式
\[
 (\tau_Hh)'=-u h,
 \qquad\mathbb E[Hf(H)]=\mathbb E[\tau_H(H)f'(H)] \tag{SK4}
\]
对紧支撑C1测试成立，没有端点delta。且0≤τH≤1/8。

对Laplace_t，置
\[
 \tau_t(u)=t(t+|u|).
\]
其乘密度等于 (t+|u|)e^-|u|/t /2，在0两侧连续且一阶导数均为0；逐侧微分得
\[
 (\tau_t\ell_t)'=-u\ell_t,
 \qquad\mathbb E[Wf(W)\mid T=t]
 =\mathbb E[\tau_t(W)f'(W)\mid T=t]. \tag{SK5}
\]
此处同样没有0处delta。

按T混合可得w的系数
\[
 \tau_w(u)=\mathbb E[T^2+|u|T\mid W=u]
 ={\int_0^1(t^2+|u|t)e^{-|u|/t}dt\over w(u)}. \tag{SK6}
\]
条件T权是 e^-|u|/t dt /w(u)，不是先验2t dt。令
\[
 N_w(u)=\tau_w(u)w(u)=\int_{|u|}^\infty z w(z)dz.
\]
对u≥0可交换正积分直接算出SK6分子；偶性与均值0处理u<0。Nw∈C1且Nw′=−u w(u)，0处导数为0。τw在0不必C1，本文只使用其乘积的合法导数与局部AC性质。

## SK3　w的定量界

对a=|u|≥0，F_a(t)=e^-a/t在(0,1]非减。均匀dt下
\[
 \int t^2F_a(t)dt-{1\over3}\int F_a(t)dt
 ={1\over2}\int_0^1\!\int_0^1
 (t^2-z^2)(F_a(t)-F_a(z))\,dt\,dz\ge0.
\]
故E[T²|W=u]≥1/3，结合0<T≤1得
\[
 \boxed{\frac13\le\tau_w(u)\le1+|u|.} \tag{SK7}
\]
u=0时τw(0)=1/3。该证明使用显式同增积分，不引用新的关联性定理。所有混合Stein积分可用τw≤1+|W|与物理有限矩合法化。

## SK4　卷积的条件系数与canonical积分核

对紧支撑C1测试f，分别固定另一独立变量，在SK4、SK5及混合身份中使用f(H+W)。各项绝对可积，得到
\[
 \mathbb E[(H+W)f(H+W)]
 =\mathbb E[(\tau_H(H)+\tau_w(W))f'(H+W)]. \tag{SK8}
\]
条件系数的逐点密度表达为
\[
 N_c(r)=\int_{-1/2}^{1/2}
 [\tau_H(u)w(r-u)+N_w(r-u)]du.
\]
用SK4及Nw′的分布导数，
\[
 N_c'=(\tau_Hh)'*w+h*N_w'
 =-(u h)*w-h*(u w)=-r\phi(r). \tag{SK9}
\]
τHh的端点值为0；Nw在0为C1；所以此卷积微分没有0或±1/2处原子。

由SK7及|W|≤|r|+1/2，条件下
\[
 {1\over3}\le\tau_H(H)+\tau_w(W)\text{ 的条件均值}
 \le{1\over8}+1+|r|+{1\over2}={13\over8}+|r|.
\]
故0≤Nc(r)≤(13/8+|r|)φ(r)，在+∞趋0。SK9和此边界确定唯一的canonical解
\[
 \boxed{N_\phi(r):=\int_r^\infty u\phi(u)du=N_c(r),
 \qquad\tau_\phi(r)={N_\phi(r)\over\phi(r)}
 =\mathbb E[\tau_H(H)+\tau_w(W)\mid H+W=r].} \tag{SK10}
\]
均值0及偶性给Nφ(r)=Nφ(|r|)>0。于是对全部有限实数r，
\[
 \boxed{\frac13\le\tau_\phi(r)\le{13\over8}+|r|,\qquad
 (\tau_\phi\phi)'=-r\phi.} \tag{SK11}
\]
条件均值使用上面明确的逐点密度版本，不只是未指定的a.e.版本。

φ∈C1且严格正、Nφ′=−rφ为C1，因此Nφ∈C2、τφ∈C1，
\[
 N_\phi''=-\phi-r\phi' \tag{SK12}
\]
连续。τφ为偶函数，τφ′(0)=0，在±1/2也没有一阶跳。无需对τφ″或φ″在该处指定有限值。Nφ及rφ的指数尾使紧测试的Stein分部积分合法；多项式测试也可由截断与SK3、SK11通过极限。

一致性矩为
\[
 \int\tau_\phi\phi
 =\mathbb E\tau_H+\mathbb E\tau_w
 ={1\over12}+\mathbb E_T[2T^2]
 ={1\over12}+1={13\over12}
 =\int r^2\phi(r)dr. \tag{SK13}
\]
这里EτH=1/12，Laplace_t的E|W|=t。也可用Stein测试f(r)=r验证；上界与指数尾保证该截断合法。

## SK5　可复现的一维闭式与接缝

定义标准广义指数积分
\[
 E_k(a)=\int_1^\infty e^{-at}t^{-k}dt
 =\int_0^1t^{k-2}e^{-a/t}dt\quad(a\ge0,k>1),
 \qquad E_k(0)={1\over k-1}.
\]
对r≥0、h0=1/2，
\[
 \phi(r)=\begin{cases}
 E_3(r-h_0)-E_3(r+h_0),&r\ge h_0,\\
 1-E_3(h_0-r)-E_3(h_0+r),&0\le r\le h_0.
 \end{cases} \tag{SK14}
\]
canonical分子是
\[
 N_\phi(r)=r[E_4(r-h_0)-E_4(r+h_0)]
 +E_5(r-h_0)-E_5(r+h_0),\quad r\ge h_0, \tag{SK15}
\]
\[
 N_\phi(r)={5\over8}-{r^2\over2}
 +r[E_4(h_0-r)-E_4(h_0+r)]
 -E_5(h_0-r)-E_5(h_0+r),\quad0\le r\le h_0. \tag{SK16}
\]
证明：E_k′=−E_{k−1}在正参数成立，外式导数为−rφ；外式∞端为0。内式微分同样为−rφ。在h0匹配所需常数为h0²/2+2E5(0)=1/8+1/2=5/8。两分支在h0值均为
\[
 {5\over12}-{1\over2}E_4(1)-E_5(1).
\]
一、二阶N导数按SK12匹配；这不使用E1(0)的有限值。r=0时
\[
 N_\phi(0)={5\over8}-2E_5(1/2),\quad
 \phi(0)=1-2E_3(1/2),\quad\tau_\phi(0)=N_\phi(0)/\phi(0)>0.
\]
负r用偶性。这组闭式已直接核过微分、边界和接缝，可用于本机有限数值；数值不替代上述证明。

## SK6　n维真实尺度生成元

对b>0、来源v，设
\[
 J_{b,v}(x)=b^{-n}\prod_i\phi(r_i),\quad r_i=(x_i-v_i)/b,
 \quad H_{i,b,v}(x)=b^2\tau_\phi(r_i)J_{b,v}(x).
\]
直接把τφφ写成Nφ，得到
\[
 \partial_iH_{i,b,v}=-(x_i-v_i)J_{b,v},
\]
\[
 \partial_{ii}H_{i,b,v}
 =-[1+r_i\phi'(r_i)/\phi(r_i)]J_{b,v}. \tag{SK17}
\]
故精确物理恒等式为
\[
 \boxed{\partial_{\log b}J_{b,v}
 =\sum_{i=1}^n\partial_{ii}[b^2\tau_\phi((x_i-v_i)/b)J_{b,v}].} \tag{SK18}
\]
系数无额外1/2；若用diffusion协方差的约定，相应协方差是2b²τ。它与尺度continuity ∂logbJ=−div((x−v)J)完全一致。

SK18在经典相关单坐标导数及分布意义均成立：H_i对xi二阶连续，SK12已消去潜在φ″接口奇性。0、±1/2及其尺度像不产生额外delta。将它称为精确尺度族生成元，不称φ一个共同时间的热半群。

## SK7　任意有限来源：无需源位置矩的交换

令ν有限正，M=ν(Rn)>0，
\[
 Q_b(x)=\int J_{b,v}(x)\nu(dv),\quad
 H_{i,b}(x)=\int H_{i,b,v}(x)\nu(dv),\quad
 \pi_{b,x}(dv)=J_{b,v}(x)\nu(dv)/Q_b(x).
\]
在任意紧正b区间，SK3、SK11及已证|φ′|≤Lφφ使
H_i、∂iH_i、∂iiH_i和∂logbJ对全部v有共同有限上界：它们只是有界的b幂乘以(1+|ri|)φ(ri)及其余有界φ因子。x变化的局部连续支配由相同上界给出。故有限ν即可交换相应局部微分，不需∫|v|ν或∫|v|²ν。

精确得到
\[
 \partial_iH_{i,b}=-\int(x_i-v_i)J_{b,v}\nu(dv),\quad
 \partial_{ii}H_{i,b}=-\int[1+r_i\phi'/\phi]J_{b,v}\nu(dv),
\]
\[
 \boxed{\partial_{\log b}Q_b=\sum_i\partial_{ii}H_{i,b}
 =\sum_i\partial_{ii}[A_iQ_b],\qquad
 A_i=b^2\mathbb E_{\pi_{b,x}}\tau_\phi(r_i).} \tag{SK19}
\]
Q_b>0且Ai点态有限，
\[
 {b^2\over3}\le A_i(x)
 \le{13b^2\over8}+b\mathbb E_{\pi_{b,x}}|x_i-v_i|. \tag{SK20}
\]
posterior相对位移矩在每个x有限，由|ri|J的公共界及Q_b(x)>0给出。该式不提供统一x或来源的上界。

## SK8　全空间通量密度的精确质量与L1导数

正Tonelli和单核Stein矩给
\[
 \boxed{\int H_{i,b}(x)dx={13b^2\over12}M.} \tag{SK21}
\]
从SK17及物理Eφ|r|≤11/12，已证Vsc=Eφ(1+rφ′/φ)²≤9/4，
\[
 \|\partial_iH_{i,b}\|_1\le {11b\over12}M,\qquad
 \|\partial_{ii}H_{i,b}\|_1\le M\sqrt{V_{\rm sc}}. \tag{SK22}
\]
上述全空间量均不需来源位置矩，因为kernel矩是相对各自v的噪声矩。
此外，引用R201的乘积score正交可得
\[
 \|\partial_{\log b}Q_b\|_1\le M\sqrt{nV_{\rm sc}}. \tag{SK23}
\]
这是固定prior、共同辅助尺度的密度L1路径工具，沿[b0,b1]还须付log(b1/b0)。它不支持适应b(x)或把sup交换出dx；也不是新的原raw来源预算。

对紧C2测试ψ，SK19弱式为 ∂logb∫Q_bψ=Σ∫H_i ∂iiψ，双分部积分符号为正。全空间质量∫Q_b=M亦直接由Tonelli恒定。
虽然H_i∈L1，Q_b的全空间|x−y|²矩仍可能无限；不能用全局二次测试或材料方向而不保实际源矩/截断条件。相对熵、log比及其梯度若不紧支撑，还需各自尾与边界证明；SK21不自动授予它们。

## SK9　full/weighted系数不同与原范围

对固定外部η(v)∈[0,1]，令νw=ην、e=νw(Rn)>0、Qw,b=J_b*νw。完全相同的局部交换给
\[
 \partial_{\log b}Q_{w,b}=\sum_i\partial_{ii}[A_{w,i}Q_{w,b}],
 \quad A_{w,i}=b^2\mathbb E_{\pi_{w,b,x}}\tau_\phi(r_i),
\]
\[
 \int A_{w,i}Q_{w,b}dx={13b^2\over12}e,
 \qquad\int A_iQ_bdx={13b^2\over12}M. \tag{SK24}
\]
这是各自joint下的均值。它不推出Ai=Awi，也不推出∫Qw(Awi−Ai)=0。原R202 ΠJ=Qwπw/e依旧保原测度，不能把πw换成fullπ以丢系数交换。

若η取原1Zt wt，应先在原固定window、(ω,V,j,y,t)下算好并冻结，再变化参考核的辅助b。重算wt、改变窗口或source/support时，会额外出现prior/η导数或真实measure交换，不能仍套fixedprior SK19–24。e=0/ν=0行先按原零约定去除。

辅助b族不自动等于原当前L、原固定参考b或原time clock。改变参考b若影响实际capture、J/S、帽、原α、history/FIRST、receiver selector，都另有交换。uniform正下界Ai≥b²/3和均值SK24也不支付Awi−Ai及其梯度与原target相关的费用；材料方向X=x−y仍需保R202的真实来源矩/重叠接缝。

## SK10　数值接口与停止范围

有限验证可用SK14–16直接计算τ及解析导数N′、N″，点应包含r=0、1/2及两侧、远尾，并保φ与N的小数消差/精度比较；不能将φ″(1/2)设为有限输入。也可按明确有限prior核SK19左右及full/weighted后验系数的区别。数值Agent的实际运行另记其责任材料，本稿不把建议说成已执行或区间证书。

严格成果是canonical Stein身份及全r上下界、无虚构接口delta的物理生成元、有限ν无源矩的局部交换，以及真实flux密度的全空间有限质量。它们为主混合熵微分提供合法系数，但没有支付系数交换、原capture/资格、材料方向、source/βΠ²或selector/window费用。无一般根阶闭合声明；本稿到此停止，等待全文审和整合。
