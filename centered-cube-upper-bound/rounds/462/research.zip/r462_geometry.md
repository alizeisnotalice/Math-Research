# R462：pair-tail 后的 canonical 中心结算

**结论：未得到新根阶付款。** 本轮核准一次父积分与 canonical 容量的连接，未将 envelope 上放后的更强目标冒充原目标的必要条件。以下上界只删除正限制；原 \(P\) 自身保留全部接受权、stage、clock 和历史。

## 1. 无核族计数的真实支配

记 \(B_y=\{u:Z_u(y)\le h\}\)，以 \(\mathbf1_{\mathrm{act}}(y)\) 表示来源有原 active 起点的固定指示，定义 \(\beta_y^*=\mathbf1_{\mathrm{act}}(y)1_{B_y}\rho_y\)。inactive 来源的辅助核置零；实际流只使用 active 来源。R458 原记录上
\(\sum_jc_{y,j}\le h^{-1}\)、\(\beta_{y,\ell_j}\le\beta_y^*\)，安全概率 \(a_y,a_z\ge b_*\ge\zeta\)。故
\[
 \frac{b_*}{a_ya_z}\sum_{j,k}c_{y,j}c_{z,k}
       \beta_{y,\ell_j}^{\rm safe}\otimes\beta_{z,\ell_k}^{\rm safe}
 \le\frac1{\zeta h^2}\beta_y^*\otimes\beta_z^*.
\]
结合原去 soft 静态帽，实际投影满足
\[
 dP\le\frac S{\zeta h^2}\sigma(dA)\pi_A(dy)\pi_A(dz)
 \beta_y^*(du)\beta_z^*(dv)\,1_{\mathcal G}.
\tag{1}
\]
\(\mathcal G\) 保 \(u,v\notin Q_A\)、\(m_A>K^2\max(m_u,m_v)\)、\(c_u(z)=c_v(y)=0\)。无 \(N^2\)，也没有把筛后的路径称为独立概率；(1) 是实际系数的正支配。

定义原生 low-source 子后验
\[
 \lambda_u(dy)=\frac{f(y)c_u(y)}{m_u}\mathbf1_{\mathrm{act}}(y)1_{B_y}(u)dy,
 \quad a(u)=\lambda_u(1)\le1.
\]
真实 matching 和 Tonelli 给
\[
 \int a(u)du=\int f(y)\mathbf1_{\mathrm{act}}(y)\rho_y(B_y)dy
 \le(1+\varepsilon_0)hW. \tag{2}
\]
定义保真实父场的核
\[
 \mathscr K(y,z;u,v)=\int_E\frac{q_Ac_A(y)c_A(z)}{m_A^2}
 1_{\{u,v\notin Q_A,\ m_A>K^2\max(m_u,m_v)\}}dA.
\]
则
\[
 R\le\frac S{\zeta h^2}\int du\,dv\int\lambda_u(dy)\lambda_v(dz)
 (1-c_v(y))(1-c_u(z))\mathscr K(y,z;u,v). \tag{3}
\]
R461 证明该核不超过 \(E_{2n}(\{y,z\},\{u,v\};L,b)/q\)，其中
\(L=\max(a,(K^2\max(m_u,m_v)/\lambda)^{1/n})\)；严格门不可能时核为零。特别
\(\mathscr K\le2r/(K^2\max(m_u,m_v))\)。这是父积分之前后量纲一致的连接，**不是**已经支付双来源。

## 2. 唯一候选：将父截面计给 (2) 一次

令 \(T(u,y)\) 为 (3) 固定 \((u,y)\) 后对 \((v,z)\) 的截面。优先保 \(\mathscr K\)，避免 envelope 忘记父的完整质量约束。固定真实 \(A\)，只在上界中放松另一端门，有
\[
 \int_{Q_A} f(z)\mathbf1_{\mathrm{act}}(z)\!\int 1_{B_z}(v)\frac{c_v(z)}{m_v}dv\,dz
 \le(1+\varepsilon_0)h\,m_A.
\]
因此严格得到
\[
 T(u,y)\le(1+\varepsilon_0)h
 \int_E c_A(y)R_A^{-n}dA
 \le(1+\varepsilon_0)hA_n. \tag{4}
\]
这避免 \(W^2\) 与 \(3^n\)，但把 (2) 代回仍仅得
\(R\le S(1+\varepsilon_0)^2 A_nW/\zeta\)，不改善原线性价。更早保来源积分也只给同系数 \(X\) 上界。

若真实截面在 \(\lambda_u(dy)du\) 平均下能由 \(C A_n/q\) 控制，(2)–(3) 才会给
\[
 R\le\frac{CS(1+\varepsilon_0)A_n}{\zeta qh}W
 =\frac{CS(1+\varepsilon_0)\varepsilon_0A_n}{\zeta s}W.
\tag{5}
\]
这是本机制所需的约 \(qh\asymp\sqrt n\) 改进，不要求每个截面的过强点态界。**未证步骤**恰是：共同 matching、互排斥和父外几何，能否降低 (4) 中另一端 own-low 占用的实际平均，而不先丢这些门。点态 pair-tail 的 \(K^{-2}\) 不能替代该空间求和；先消父 matching 的 envelope 可能更难，故不把其全局界当必经目标。

本轮没有证明 (5) 的前提，不增加或退还任何母账费用；亦不以此另命名余项。

## 3. 实际小算及范围

指定 Python 实跑60个 Fraction/128-bit Arb 断言。三个原生正体积场取 \(n=9,16,25\)：来源盒半边长 \(e=10^{-3}\)，中心首坐标 \(-.8,0,.8\)，质量 \(1,2^n-2,1\)；接收中心块同半边长，首坐标 \(-1.1,0,1.1\)，选定边长 \(1,2,1\)。完整匹配均为 \(q_A=1\)，父外、交叉排斥及 \(2^n>K^2\) 均成立。设中心块体积 \(v=(2e)^n\)，未加 active mask 的 raw-low/static 核双积分恰为 \(2v^3/(2^n)^2\)。全部来源均无 active 起点且原高 rank 门失败；加入本文 active mask 后，canonical 核及双积分均为零。上述非零值仅检验未加 mask 的原生 raw-low/static 匹配、中心积分与归一，**不是实际 masked canonical 积分，也不是完整原历史样本**。一次 Fraction/Arb 类型混乘报错后改为先作有理比较；公式未改。

```python
from fractions import Fraction as F
from flint import arb,ctx
ctx.prec=128
checks=0
for d in (3,4,5):
 n=d*d;e=F(1,1000);vol=(2*e)**n;M=F(2)**n;h=F(2*(1+d))
 src=[(F(-4,5),F(1)),(F(0),M-2),(F(4,5),F(1))]
 rec=[(F(-11,10),F(1)),(F(0),F(2)),(F(11,10),F(1))]
 capture=[]
 for cx,R in rec:
  row=[]
  for sx,ms in src:
   yes=abs(cx-sx)+2*e<R/2 and 2*e<R/2
   no=abs(cx-sx)-2*e>R/2
   assert yes or no;checks+=1
   row.append(int(yes))
  capture.append(row)
 masses=[sum(ms*c for (_,ms),c in zip(src,row)) for row in capture]
 assert masses==[1,M,1];checks+=1
 for mass,(_,R) in zip(masses,rec):assert mass==R**n;checks+=1
 assert arb(n)*arb(2).log()>arb(2*d);checks+=1
 assert all(sum(vol*row[k]/mass for row,mass in zip(capture,masses))<h
            for k in range(3));checks+=1
 assert F(11,10)-2*e>1;checks+=1
 T=vol**2/M**2
 assert 2*vol*T==2*vol**3/M**2;checks+=1
 assert 3*vol<=h*M;checks+=1
 assert arb(2).log()>arb(1)/2;checks+=1
 assert T<=h*(1+F(n,2));checks+=1
print('PASS',checks)
```
