# 第462轮：精确父包络接入双终端积分

## 目标与状态

本轮将R461几何核接回同一实际R458终端流P，而非继续变更R460选择公式。目标仍为完整R<=eta X+C_eta sqrt(n)polylog(n)W。联合正支配及精确几何上放建立后，来源/终端的共享Schur预算仍未闭合；不得把新的积分表达视为完成目标。

## 同一原流的联合帽与单位

固定b>=zeta的原record。两端未归一保留终端核是sum_j c_xj beta_x,ell_j^safe，sum_j c_xj<=1/h；安全概率s_x>=b。原P的双端系数为b/(s_y s_z)，因此<=1/zeta。每个bin正分量受beta_x^*=1_active(x) rho_x|B_x支配。把原Pi0的静态帽S sigma pi_A²用于正上放，得到
\[
P_{A,y,z,u,v}\le\frac S{\zeta h^2}\,
 \sigma(dA)\pi_A(dy)\pi_A(dz)\beta_y^*(du)\beta_z^*(dv)\,
 1_{\{y\notin Q_v,z\notin Q_u,u,v\notin Q_A,
 m_A>K^2\max(m_u,m_v)\}}.
\]
右侧只是上界；不声称原两个filtered终端独立。其他接受权被外放的损失没有退款。混合权先求和再上界，所以不产生N²或额外stage数；S仅一次。

定义未归一低rank来源测度
\[
\lambda_u(dy)=\pi_u(dy)1_{\{y\ active,\ u\in B_y\}},
\quad a(u)=\lambda_u(1),\quad \omega(du)=a(u)du.
\]
Tonelli给 f(y)dy beta_y^*(du)=du lambda_u(dy)，无额外1/m_u；质量分母已在pi_u中。原低rank容量给
\[
0\le a\le1,\qquad \omega(E)\le(1+\varepsilon_0)hW.
\]
不能把omega直接视为实际终端边缘。

## 保留完整父核，再用几何包络

对固定四点设
\[
\mathcal K(y,z;u,v)=\int_E\frac{q_A}{m_A^2}
 1_{\{y,z\in Q_A;\ u,v\notin Q_A;
 m_A>K^2\max(m_u,m_v)\}}dA.
\]
于是严格有
\[
R\le\frac S{\zeta h^2}\int du\,dv\int\lambda_u(dy)\lambda_v(dz)
 1_{\{y\notin Q_v,z\notin Q_u\}}\mathcal K(y,z;u,v).
\]
这里保持同一f、同一实际E与边长场，先前来源/终端的质量分母完全保留。

R461给父核 <= E_{2n}(Y={y,z},Z={u,v};L,b)/q，其中L保两端strict质量下限；质量下限超过b时取零。进一步裸尾父核 <= 2r/[K²max(m_u,m_v)]只是可选的较粗界。若丢空间再把双积分换成两份总质量，会留下W²并失去目的，不能如此入账。用exactE也会放大共同selector的可行类；其改善必须在真实来源权下验证。

## 能够闭合的共享行费用与目前实际所得

a(u)>0时令k_u=lambda_u/a(u)。将该父核及两交叉排除按k_u k_v平均得非负对称核\overline{\mathcal K}(u,v)。联合帽只使用一次omega总量；若能够证明
\[
\int \overline{\mathcal K}(u,v)\omega(dv)\le C_\eta h\sqrt n
\]
或足够的实际omega加权平均版本，便可得到所需根阶费用，常数保留S/zeta等依赖。这是未证的充分条件，不是已知Schur定理自动提供的行价。

现有工具的可证行上界仅为(1+eps0)h A_n：先积另一终端low-rank总量，再积真实父中心D(y)<=A_n。与omega总量合并只给S(1+eps0)^2 A_n W/zeta，仍为线性价。行列容量和严格质量门均没有自动消去所缺的平方根因子。必须保父外、crossavoid与共同匹配来改善这一行/平均预算，不能以核命名或有限数值取代它。

## 完整总账

原R433<=[S zeta+2S eps0/s+2S delta]X+R保持。当前联合帽新增的1/zeta代价须始终显式保留；不是R460单端选择中的无1/zeta帽。N虽未进入此联合上放，原rounding费用和所有母入口、宽距离、低pe、初始/删除、极端尺度费用不退还。一般目标未闭合。

## 实验任务与证据标准

数值任务限定为：在相同质量、终端中心体积与q-band的连续立方体模型中，只改变分离坐标数，比较保空间的fixed-side精确核与裸mass-tail。它旨在判断提前删除空间几何会损失多少，而不是构造通过全部history的实际非零canonical流。active/B未认证时只可使用lambda的正上放，不称lambda本身；详细门覆盖、实际结果与复现见numeric附件。未从少量维数拟合阶数。

本轮复用1 Astra high、2 Sol high、1 Sol medium，Luna无新独立任务未启用。使用此前已读A02规范核集合放松与目标方向；实际数学计算使用指定独立Python环境。无实际扣额数据，不估算成本。保详细LaTeX源与必要复现，不编译PDF。

## 实际复核与下一步决策

主代理在独立临时目录用指定Python复跑：geometry内嵌60项Fraction/Arb断言、complement内嵌27项系数断言、numeric自含脚本58项精确断言；stdout一致，完整数值JSON除计时外逐项一致，见r462_replay.json。这些数量是断言数，不能当作一般参数覆盖。

固定n=16的三个连续来源模型保质量、真实终端体积及q-band不变，分离坐标数1、2、16时，精确固定边长核/同一裸尾界分别为0.0010040890002379985176、0.000020548393887766260613、2.4086502721046758568e-29。完整源积分、整cube排除容斥及真实中心块积分均保留。原active为空，实际canonical积分为零；非零表格属于未加active的正上放诊断。

决策是保留实际父的质量匹配和几何交叠，下一步集中估计complement式(7)方括号与父径向占用的相关性。不能把uniform模型的坐标乘积因子移植到任意集中f，也不能要求每行强界；允许在同一omega下平均并保留eta X例外预算。第462轮没有取得新的根阶付款，完整目标保持开放。
