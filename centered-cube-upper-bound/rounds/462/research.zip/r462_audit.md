# R462 FINAL PASS（限定范围）

先独立完成 PRE，再阅读冻结作者稿。PASS 仅覆盖双终端正支配、真实共同父核的换序/单位、现有线性 Schur 结算和明确限定的空间诊断。**没有认证未证的根阶 Schur 平均价、实际有效交叠费用或完整一般预算；原母账保持。**

逐原记录有 \(b/(s_y s_z)\le1/\zeta\)、\(\sum c_{x,j}\le1/h\)、\(\beta_{x,\ell_j}\le\beta_x^*\)，故最终联合帽 \(S/(\zeta h^2)\) 正确，无 \(N^2\)、额外 stage 或第二次 \(S\)。终端 crossavoid、父外、strict \(m_A>K^2\max(m_u,m_v)\) 可在正支配中保留。原接受权已被上放而非退款；筛后实际两端不被假定独立。active 起点排除了 successor 帽中混入初始 Dirac。

来源换序 \(f(y)dy\,\beta_y^*(du)=du\,\lambda_u(dy)\) 正确，无额外 \(1/m_u\)；\(\lambda_u\) 是未归一且含 active/own-low 的真实子后验。父核 \(q_A/m_A^2\) 及其 \(E_{2n}/q\)、\(2r/[K^2\max m]\) 上界单位正确，strict 质量空域与固定边长 base 未混淆。envelope selector 不获得原 matching/history。

complement (7) 是保全部显示几何门的包络行积分；用 \(q_A/m_A=R_A^{-n}\) 与 low-rank 总容量只得到 \((1+\varepsilon_0)hA_n\)。一次 \(\omega\) 总质量给 \(S(1+\varepsilon_0)^2A_nW/\zeta\)，不是新根价。geometry (5) 与 complement (9) 均是明确未证的充分平均条件，不要求过强逐行界，也不把行列容量当其证明。所有 \(S,\zeta,h,q,N\) 和原入口/旧费用依赖保留。

数值场为完整 \(f=1_{[-5,5]^{16}}\)，共同 selector 的 parent 块与两个 terminal 块互不冲突，实际 cubes 全在来源支持，质量与 q 精确匹配。所有贡献父在指定 parent 块内；两 terminal 整 cube 排除由张量容斥处理，未误改成每个坐标各排斥。真实 \(\pi_u,\pi_v\) 在完整 unit cubes 积分；terminal 中心体积及 fixed-side tail 归一在三配置间不变。SymPy 折点积分、独立 Fraction 分段积分以及 center-pair 两种积分路径相符。\(2^{16}>3^8>e^8\) 保 strict gap。原 active 确实为空：\(J(y)<1<h\)，故实际 masked canonical 量为零。报告的非零 raw-low 上放仅说明删除空间结构的损失，不认证 canonical 非零流、一般维数阶数或原 history。geometry 的三个高维块例也已明确同一 mask 限制。

指定 Python 在隔离目录
`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r462_audit__bz7bi9p`
实际重放冻结 md 的两个代码块与复制后的 numeric 脚本，分别通过 60、27、58 项断言；三份 stdout 与 replay 逐字一致，JSON 仅运行 seconds 不同。这些是断言数，非独立场数量；不作 full-history 认证。PRE 的 27 项临时代数检查不并入归档统计。未改作者文件或仓库，未编译 PDF。

最终七输入 SHA256：

- `r462_main.md`: `c4f1265c3338b0a744563145d0f3c2b88ee7b3f980c6bcecf6b95005994e72c6`
- `r462_geometry.md`: `a427d5e3e636464b8079b21649d245bb2328f700583004ce12848acf069eaaaf`
- `r462_complement.md`: `422391fd670cec4c59adc507dcdcac31e74edd9764c18848b7268019062877a7`
- `r462_numeric_plan.md`: `9462c699fd916e4b08d12515ba2f834103b2e38c913216dd978371c95044f094`
- `r462_numeric_check.py`: `6e1c297e6b9c3562c0775155594a051f3984f6a2e17ccf2cfd1f5b38bb06343a`
- `r462_numeric_check.json`: `7ea949e4e4dee1978f89b012a2df4c7495a44224c26b36ff17a19e93031925ef`
- `r462_replay.json`: `cf9a84b33a09cee5a8411e73c0b164c856781ea95db9e2a95de8260c58819190`
