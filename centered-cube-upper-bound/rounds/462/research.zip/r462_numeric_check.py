from fractions import Fraction as F
from pathlib import Path
import sys,platform,time,json
import sympy as s
ROOT=Path(__file__).resolve().parent
start=time.perf_counter();checks=0
x,d,u,v=s.symbols('x d u v',real=True)
def ck(z):
 global checks
 assert z
 checks+=1
def rat(z):return s.Rational(z.numerator,z.denominator) if isinstance(z,F) else s.Rational(z)
def FF(z):return F(int(s.numer(z)),int(s.denom(z)))
def overlap_expr(center,sample):
 # On an interval of A=x bounded by all child/parent overlap breakpoints.
 diff=sample-center
 ds=diff.subs(d,current_sample)
 if ds<=-s.Rational(3,2) or ds>=s.Rational(3,2):return s.Integer(0)
 if ds<-s.Rational(1,2):return s.Rational(3,2)+x-center
 if ds<=s.Rational(1,2):return s.Integer(1)
 return s.Rational(3,2)-x+center
polys={}
for label,current_sample in [('coincident',s.Rational(1,100)),('separated',s.Rational(121,50))]:
 # x is parent center minus u; v-u=d>=0. l(x)=source mass in unit child captured by side2 parent.
 for kind in ('none','u','uv'):
  lo=-s.Rational(3,2);hi=d+s.Rational(3,2)
  if kind in ('u','uv'):lo=-1;hi=1
  if kind=='uv':lo=d-1
  ends=[s.sympify(z) for z in (lo,hi,-s.Rational(3,2),-s.Rational(1,2),s.Rational(1,2),s.Rational(3,2),d-s.Rational(3,2),d-s.Rational(1,2),d+s.Rational(1,2),d+s.Rational(3,2))]
  if s.sympify(lo).subs(d,current_sample)>=s.sympify(hi).subs(d,current_sample):poly=s.Integer(0)
  else:
   ends=sorted(set(z for z in ends if s.sympify(lo).subs(d,current_sample)<=z.subs(d,current_sample)<=s.sympify(hi).subs(d,current_sample)),key=lambda z:z.subs(d,current_sample))
   poly=0
   for l,r in zip(ends,ends[1:]):
    sample=(l+r)/2
    poly+=s.integrate(overlap_expr(s.Integer(0),sample)*overlap_expr(d,sample),(x,l,r))
   poly=s.expand(poly)
  polys[label,kind]=poly
# Independent Fraction A integration, at all actual piecewise overlap breakpoints.
def L(A,c):return max(F(0),min(A+1,c+F(1,2))-max(A-1,c-F(1,2)))
def direct_b(dist,kind):
 lo=F(-3,2);hi=dist+F(3,2)
 if kind in ('u','uv'):lo=F(-1);hi=F(1)
 if kind=='uv':lo=dist-1
 if lo>=hi:return F(0)
 bs=sorted({lo,hi,*[z for c in (F(0),dist) for z in (c-F(3,2),c-F(1,2),c+F(1,2),c+F(3,2)) if lo<z<hi]})
 total=F(0)
 for l,r in zip(bs,bs[1:]):
  fn=lambda A:L(A,F(0))*L(A,dist)
  total+=(r-l)*(fn(l)+4*fn((l+r)/2)+fn(r))/6
 return total
for label,values in [('coincident',(F(0),F(1,200),F(1,100),F(1,50))),('separated',(F(12,5),F(241,100),F(121,50),F(61,25)))]:
 for kind in ('none','u','uv'):
  for dist in values:
   ck(FF(polys[label,kind].subs(d,rat(dist)))==direct_b(dist,kind))
# Actual Lebesgue terminal blocks: side length w in every center coordinate.
a=s.Rational(6,5);b=s.Rational(61,50);w=b-a;eps=w/2
means={};raws={}
for label in ('coincident','separated'):
 for kind in ('none','u','uv'):
  poly=polys[label,kind]
  if label=='coincident':
   # Difference density and independent direct triangular (u,v)-integration.
   raw=2*s.integrate((w-d)*poly,(d,0,w))
   direct=2*s.integrate(s.integrate(poly.subs(d,v-u),(v,u,eps)),(u,-eps,eps))
  else:
   raw=s.integrate((d-2*a)*poly,(d,2*a,a+b))+s.integrate((2*b-d)*poly,(d,a+b,2*b))
   direct=s.integrate(s.integrate(poly.subs(d,v-u),(v,a,b)),(u,-b,-a))
  ck(s.simplify(raw-direct)==0)
  raw=s.factor(raw);mean=s.factor(raw/w**2);ck(mean>=0)
  raws[label,kind]=raw;means[label,kind]=mean
# One-dimensional reflection x->d-x proves u and v capture costs equal.
# Additional direct Fraction reflection check avoids silently dropping a distinct term.
for dist in (F(0),F(1,100),F(12,5),F(61,25)):
 lo=dist-1;hi=dist+1;bs=sorted({lo,hi,*[z for c in (F(0),dist) for z in (c-F(3,2),c-F(1,2),c+F(1,2),c+F(3,2)) if lo<z<hi]})
 val=sum(((r-l)*(L(l,0)*L(l,dist)+4*L((l+r)/2,0)*L((l+r)/2,dist)+L(r,0)*L(r,dist))/6 for l,r in zip(bs,bs[1:])),F(0))
 ck(val==direct_b(dist,'u'))
n=16;vol=w**n;W=10**n
# Parent field: EP=[-.31,.31] x [-2,2]^15; terminal blocks U,V disjoint from EP.
parentvol=s.Rational(31,50)*4**(n-1);X=parentvol+2*vol
ck(2**n>3**8) # e<3 certifies mA>K^2*mterminal, K^2=e^8.
ck(s.Rational(3,10)<s.Rational(31,100)<a) # all contributing parents disjoint terminal center blocks.
ck(s.Rational(151,100)<2 and 2+1<5 and b+s.Rational(1,2)<5)
ck(2*a>1) # Q_u and Q_v disjoint already in first separated coordinate: source crossavoid.
# All side2 parents have q=1, all side1 terminals q=1 on f=1[-5,5]^16.
# Original h>=10 for eps0<=1/2; J(y)<=.31+2vol<1, hence no actual own-high start here.
Jbound=s.Rational(31,100)+2*vol;ck(Jbound<1)
rows=[]
for j in (1,2,16):
 terms={k:s.factor(means['separated',k]**j*means['coincident',k]**(n-j)) for k in ('none','u','uv')}
 retained=s.factor(terms['none']-2*terms['u']+terms['uv']);ck(retained>0);ck(terms['uv']==0)
 normalized=s.factor(retained/s.Integer(2)**(2*n))
 T=s.factor(vol**2*normalized);tail=s.factor(vol**2/s.Integer(2)**n);ratio=s.factor(T/tail)
 ck(0<ratio<1);ck(T==ratio*tail)
 # Relative comparison must not include a hidden center-volume change.
 rows.append(dict(n=n,separated_coordinates=j,terminal_mass=1,parent_mass=2**n,q=1,
  terminal_center_volume=str(vol),capacity_integral_a_bar=str(2*vol),W=str(W),X=str(X),
  averaged_tensor_terms={k:str(z) for k,z in terms.items()},
  T=str(T),T_per_terminal_pair_volume=str(normalized),pair_tail=str(tail),exact_over_pair_tail=str(ratio),
  ratio_decimal=s.N(ratio,20).__str__(),T_decimal=s.N(T,20).__str__()))
ck(s.Rational(rows[0]['exact_over_pair_tail'])>s.Rational(rows[1]['exact_over_pair_tail'])>s.Rational(rows[2]['exact_over_pair_tail']))
out=dict(scope='Three actual uniform-f fixed-side Lebesgue geometry diagnostics with lambda_bar=pi_u upper relaxation; no canonical active/B/history or root payment',
 executable=sys.executable,python=platform.python_version(),sympy=s.__version__,checks=checks,
 model=dict(n=n,f='1 on [-5,5]^16',parent_centers='[-31/100,31/100] x [-2,2]^15',parent_side=2,
 terminal_center_coordinate_width=str(w),separated_U='[-61/50,-6/5]',separated_V='[6/5,61/50]',other_U_V='[-1/100,1/100]',terminal_side=1,
 massgap_certificate='2^16>3^8>e^8=K^2',qband='q=lambda=1; all actual cubes inside f support',
 source_crossavoid='Q_u cap Q_v empty in first separated coordinate',parent_selector_conflict='common-source parents have |A1|<=3/10, disjoint from U,V center blocks',
 actual_own_high='empty for original h>=10: J(y)<=31/100+2|U|<1',J_upper=str(Jbound)),
 one_dimensional_polynomials={label:{k:str(polys[label,k]) for k in ('none','u','uv')} for label in ('coincident','separated')},
 one_dimensional_center_pair_integrals={label:{k:str(raws[label,k]) for k in ('none','u','uv')} for label in ('coincident','separated')},
 one_dimensional_center_pair_means={label:{k:str(means[label,k]) for k in ('none','u','uv')} for label in ('coincident','separated')},
 fixtures=rows,compute_index=dict(status='complete',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r462_numeric_check.py',
 arithmetic='Fraction partition/Simpson for exact quadratic pieces, SymPy exact polynomial/center-block integration; decimal diagnostics only',seconds=time.perf_counter()-start))
(ROOT/'r462_numeric_check.json').write_text(json.dumps(out,indent=2)+'\n')
print('Python',platform.python_version(),'SymPy',s.__version__,sys.executable)
for label in ('coincident','separated'):
 print(label,'polys=',{k:str(polys[label,k]) for k in ('none','u','uv')},'means=',{k:str(means[label,k]) for k in ('none','u','uv')})
for row in rows:print('j',row['separated_coordinates'],'exact/tail',row['ratio_decimal'],'T',row['T_decimal'])
print('PASS',checks,'exact assertions, three fixed geometry configurations; no scan')
