# R462：双 canonical 支配及一次实际父核 Schur 结算

本稿没有得到根阶全余预算。已核准无核族数损失的双端正支配，并把唯一 Schur 尝试结算到线性 \(A_nW\)；这一价格不替换旧账。\(q\le q_A\le\lambda\)、\(m_A=q_AR_A^n\)、\(a\le R_A\le b\le2a\)，\(A_n=1+n\log(b/a)\)。cube 参数为边长，中心积分是真实 Lebesgue 测度。

## 1. 原记录到包络：只有一个 \(\zeta^{-1}\)

使用 R458_geometry §§2–4 的准确原记录 \(\xi\)。记唯一原 soft 为 \(b_*=1-C_A(y,z)/h\ge\zeta>0\)，去 soft 的原流为 \(\Pi^0\)，其静态投影不超过 \(S\sigma\pi_A^2\)。两条 killed 路径的成功概率 \(s_{\xi,y},s_{\xi,z}\ge b_*\)，最后 active 系数满足 \(\sum_jc_{\xi,x,j}\le h^{-1}\)。
在 active 来源上令
\[
 \beta_x^*=\rho_x|_{B_x},\qquad B_x=\{u:Z_u(x)\le h\},\qquad
 h\le\beta_x^*(E)\le(1+\epsilon_0)h.
\]
无 active 来源时将本辅助核置零。R458 的实际保留端点律是
\[
 \Pi^0(d\xi)b_*\sum_{j,k}
 \frac{c_{\xi,y,j}c_{\xi,z,k}}{s_{\xi,y}s_{\xi,z}}
 \beta_{y,\ell_j}^{\bar z}(du)\beta_{z,\ell_k}^{\bar y}(dv)
 1_{\{u,v\notin Q_A\}}.                                      \tag{1}
\]
每个非零 bin 另有严格 \(m_u,m_v<m_A/K^2\)。由于
\[
 \frac{b_*}{s_{\xi,y}s_{\xi,z}}\le\zeta^{-1},\qquad
 \sum_jc_{\xi,x,j}\beta_{x,\ell_j}\le h^{-1}\beta_x^*,
\]
(1) 的静态端点投影受
\[
 \frac{S}{\zeta h^2}\,\sigma(dA)\pi_A(dy)\pi_A(dz)
 \beta_y^*(du)\beta_z^*(dv)\,
 1_{\{c_u(z)=c_v(y)=0,\ u,v\notin Q_A,\
                  K^2\max(m_u,m_v)<m_A\}}                     \tag{2}
\]
支配。没有 \(N_\delta^2\)，也没有重复使用 soft。分位原子按原比例截取，零系数无需定义条件核。(1) 保留全历史；(2) 是正上放测度，已经放掉原接受权及其余原门，绝不是新的实际流。

## 2. 父中心先积分

写 \(\chi_u(x)=1_{\mathrm{active}_x}1_{B_x}(u)\)，则
\(\beta_x^*(du)=c_u(x)\chi_u(x)du/m_u\)。
固定 \(y,z,u,v\)，令
\[
 L=\max\{a,(K^2\max(m_u,m_v)/\lambda)^{1/n}\}.
\]
若 \(K^2\max(m_u,m_v)\ge\lambda b^n\)，父核为零；其余由 R461_envelope (4) 得
\[
 \int_{\rm eligible\ A}\frac{q_Ac_A(y)c_A(z)}{m_A^2}\,dA
 \le q^{-1}E_{2n}(\{y,z\},\{u,v\};L,b).                       \tag{3}
\]
因此 (2) 的总量不超过
\[
 \frac{S}{\zeta h^2q}\int
 \frac{f(y)f(z)c_u(y)c_v(z)\chi_u(y)\chi_v(z)}
      {m_um_v}\,
 1_{\{c_u(z)=c_v(y)=0\}}E_{2n}\,dy\,dz\,du\,dv.               \tag{4}
\]
固定边长 \(L=b\) 保留基项；严格质量空域按上面的判据处理。\(E_{2n}\) 的最优化选择器不必匹配原 \(f\)，故 (3) 只用于上界，不能回推实际接受率。虽然 \(E_{2n}\le2L^{-n}\)，直接把这个尾界代入双源积分仍没有共享来源预算。

## 3. 唯一 Schur 尝试：保真实父，不先取 \(E_{2n}\)

定义真实 canonical 使用率及条件来源
\[
 a(u)=\int\pi_u(dx)\chi_u(x),\qquad
 k_u(dx)=\pi_u(dx)\chi_u(x)/a(u).
\]
在 \(a(u)=0\) 上任取概率核且下式置零。Tonelli 给
\[
 \int a(u)\,du=\int f(x)\beta_x^*(E)\,dx
 \le(1+\epsilon_0)hW,\qquad
 \int q_u a(u)\,du\le\lambda(1+\epsilon_0)hW.                 \tag{5}
\]
令 \(K_{\rm act}(u,v)\) 为 \(k_u(dy)k_v(dz)\) 对 (3) 左侧的平均，保留 (2) 全部几何门。它非负、对称；(2) 的总量恰为
\[
 \frac{S}{\zeta h^2}\int a(u)a(v)K_{\rm act}(u,v)\,du\,dv.    \tag{6}
\]
这只是包络总量的等式，不是原余项等式。

以下行积分还保留真实来源交叠。定义
\[
 t_A^y(z)=\int\rho_z(dv)\chi_v(z)
 1_{\{v\notin Q_A,\ K^2m_v<m_A,\ c_v(y)=0\}}.
\]
则准确地
\[
 \begin{split}
 (\mathcal T1)(u)
 &:=\int a(v)K_{\rm act}(u,v)\,dv\\
 &=\int k_u(dy)\int
 \frac{c_A(y)1_{\{u\notin Q_A,\ K^2m_u<m_A\}}}{R_A^n}
 \left[\int\pi_A(dz)(1-c_u(z))t_A^y(z)\right]dA.             \tag{7}
 \end{split}
\]
证明仅交换非负积分并用 \(q_A/m_A=R_A^{-n}\)。它没有以来源质量代替中心体积。

现有容量给 \(t_A^y(z)\le(1+\epsilon_0)h\)，实际中心径向界给
\(\int c_A(y)R_A^{-n}dA\le A_n\)。所以
\[
 \mathcal T1\le(1+\epsilon_0)hA_n,\qquad
 |\Xi_{\rm can}|
 \le\frac{S(1+\epsilon_0)^2}{\zeta}A_nW.                    \tag{8}
\]
(8) 使用一次 (5)，没有 \(W^2\)，但仍是线性维度来源费，通常也不优于既有粗界，不能列为新付款。

本路线唯一未证步骤是改善 (7) **在 \(a(u)du\) 下的平均**：若能保其实际父外、交叉排斥和质量门证明
\[
 \int a(u)(\mathcal T1)(u)\,du
 \le C h^2\sqrt n\,\log^A(n+2)W,                            \tag{9}
\]
则 (6) 可给来源价 \(CS\zeta^{-1}\sqrt n\log^A(n+2)W\)。不要求每行都满足根阶界。当前推导在把方括号替成总 canonical 秩时丢掉了其与父中心径向占用的关联；(5) 自身不能恢复这个关联。(9) 未证明，不能将 \(E_{2n}\) 尾界、单列容量或静态匹配分别成立视为它成立。

## 4. 实际本机检查范围

下面小型 Fraction 检查已实际运行：三组系数/部分质量原子及零系数压力，27 项逐端点支配检查通过。它只核第1节的代数系数和无 \(N^2\) 方向；不模拟原 cube 场、历史或证明 (9)。解析证明不依赖有限测试。

~~~python
from fractions import Fraction as F
checks=0
for h in map(F,[1,2,3]):
    star=[h*F(1,4),h*F(1,2),h*F(3,4)]
    def beta(ell):
        out=[]
        for x in star:
            take=min(x,ell);out.append(take);ell-=take
        assert ell==0
        return out
    bins=[beta(h),beta(h*F(5,4)),beta(h*F(3,2))]
    cy=[F(1,4)/h,F(1,4)/h,F(0)]
    cz=[F(0),F(1,8)/h,F(3,8)/h]
    b=F(1,3);zeta=F(1,4);sy=F(3,4);sz=F(4,5)
    assert sum(cy)<=1/h and sum(cz)<=1/h
    assert b>=zeta and sy>=b and sz>=b
    for u in range(3):
        for v in range(3):
            lhs=b/(sy*sz)*sum(cy[j]*bins[j][u] for j in range(3))*sum(cz[j]*bins[j][v] for j in range(3))
            rhs=star[u]*star[v]/(zeta*h*h)
            assert 0<=lhs<=rhs
            checks+=1
print("PASS",checks,"Fraction endpoint domination checks; no native-history claim")
~~~

母账仍为 R458_main 的
\([S\zeta+2S\epsilon_0/s+2S\delta]X+|\Xi_{\rm can}|\)，原入口倍率和旧费用照保。本辅助没有新增吸收或根阶付款。
