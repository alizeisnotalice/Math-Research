# R489：同一次成功流的配置方向比较

**结论。** 本稿只研究 R481 的一次长边功。对实际后验方向均值可证明一个完整的矩阵预算，不需逐配置的 \(\chi^2\) 上帽；但当前低 Gram 门没有给相应的原父—最大父方向矩阵价格。因此没有得到新的根阶付款，以下比较不能作为已闭合的几何引理使用。

## 1. 同流和唯一候选

保留 \(\mu=f\,dx\)、真实 \(m_A=\mu(Q_A)=q_AR_A^n\)、\(a\le R_A\le b\le2a\)、\(\sigma=q_A\,dA\)、\(\nu=t\sigma\)、\(t\le S\)。\(\Omega_0\) 是原 \(\Omega_\ell\) 再限制全部 raw 父均不捕获旧 \(y,z\) 的实际流。原门、旧来源、最大父和所有历史保持不变。

记
\[
w_0=\frac1n\int_{\Omega_0}
 \frac{x-A}{R_A}\cdot\frac{B-A}{R_A}.
\]
已有同流差额是
\[
|w_\ell-w_0|\le\frac{3rS^2}{2T}X.
\tag{1}
\]
若本轮能支付 \(w_0\)，仍须将 (1) 及旧母账回填；本稿不转到累计占用功。

固定原父 \(A\)，把实际成功流分解为
\[
\Omega_0(dA,d\xi,dx)
=\nu(dA)\lambda_A(d\xi)q_{A,\xi}(dx).
\tag{2}
\]
\(\xi\) 包含最大父 \(B\)、marks、raw 配置、旧记录及成功标签，但不包含人工来源 \(x\) 的数值。\(\lambda_A\) 是次概率，\(q_{A,\xi}\) 是正规条件概率；它支持实际共同核心，绝不替换为 \(\pi_A\) 或 \(\pi_B\)。实际初始人工来源为 \(\pi_A\)，成功只作正限制，所以
\[
\int\lambda_A(d\xi)q_{A,\xi}(dx)\le\pi_A(dx).
\tag{3}
\]
本次候选是利用 (3) 与低 Gram 族共同控制以下两个**同一实际配置**的方向矩阵，而不是分别选择有利来源或父。

## 2. 已证明的后验方向预算

置
\[
u_A(x)=\frac{x-A}{R_A},\quad
m_\xi=\int u_A\,dq_{A,\xi},\quad
d_\xi=\frac{B-A}{R_A},
\]
\[
\Sigma_A=\int u_Au_A^{\mathsf T}\,d\pi_A,
\quad G_A=\int m_\xi m_\xi^{\mathsf T}\,d\lambda_A,
\quad D_A=\int d_\xi d_\xi^{\mathsf T}\,d\lambda_A.
\]
对每个确定向量 \(v\)，条件 Jensen 和 (3) 给
\[
v^{\mathsf T}G_Av
\le\int\lambda_A(d\xi)\int(v\cdot u_A)^2dq_{A,\xi}
\le v^{\mathsf T}\Sigma_Av.
\]
因此
\[
\boxed{G_A\preceq\Sigma_A.}\tag{4}
\]
这同时结算全部配置后验；无需对每个共同核心的归一化因子单独收费。

任意正定矩阵 \(L\) 给
\[
2\left|\int m_\xi\cdot d_\xi\,d\lambda_A\right|
\le\operatorname{tr}(LG_A)+\operatorname{tr}(L^{-1}D_A)
\le\operatorname{tr}(L\Sigma_A)+\operatorname{tr}(L^{-1}D_A).
\]
对 \(L\) 优化，奇异情形用正则化取极限，得到一般有限维矩阵 Cauchy 界
\[
\boxed{|w_0|\le\frac1n\int\nu(dA)
\operatorname{tr}\sqrt{\Sigma_A^{1/2}D_A\Sigma_A^{1/2}}.}
\tag{5}
\]
该式保实际最大父的全部选择权在 \(D_A\)，并非任意 incidence 图假设。它是合法的比较上界，但没有来源价格；它也可能比原有符号目标更强，不将其宣布为下一轮必须证明的目标。

## 3. 低 Gram 的作用范围与未证的决定步骤

实际 \(F_0\) 给
\[
\sum_{C\in F_0\setminus\{B\}}
\frac{\mu(Q_B\cap Q_C)}{\sqrt{m_Bm_C}}\le\tfrac12.
\tag{6}
\]
它控制同族来源向量的 Gram 矩阵及核心质量。它不直接控制 (5) 中的 \(D_A\)：原父 \(A\) 不是该低 Gram 族的一员，而且 \(B\) 的方向与来源后验及完整成功筛选共同变化。不能将 (6) 当成 \(d_\xi\) 的正交、各向同性或独立性。

保共同核心的逐配置 Cauchy 也不解决这一步：它引入 \(\chi^2(q_{A,\xi}\Vert\pi_A)\)，而小核心提供的是该量的下界。式 (4) 避开了这一额外上帽要求，但没有使实际方向矩阵变小。

现有一般几何只给
\[
\operatorname{tr}\Sigma_A\le n/4,
\quad \operatorname{tr}D_A\le(9n/4)\lambda_A(E).
\]
代 (5) 至多得 \(|w_0|\le3R/4\)。R488 的径向方差控制 \(\operatorname{tr}\Sigma_A/n\) 围绕 \(1/12\) 的偏差；它不控制 (5) 的方向配对，更不能将其全部乘积变成 \(O(W)\)。因此未证的具体几何步骤是：**在相同实际配置和原来源列下，用低 Gram 共同核心与真实中心选择，支付 \(D_A\) 相对于 \(\Sigma_A\) 的自适应方向配对**。当前没有证明此步，没有删除 maxrank void、把后验刷新为均匀来源，或将族内质量收益跨父重复计作一次 \(W\)。

本稿不新增收据或余项标签。完整长边功目标仍未付；(4)—(5) 只说明下一次若使用配置后验均值，可以直接保矩阵列预算，而不必先要求无法取得的逐配置 \(\chi^2\) 上帽。

## 4. 有限本机接口核验

下列三组有限来源/配置模型实际运行通过18项精确检查。它们有真实二维点—立方体捕获关系，但来源是有限点模型，不是非负 \(L^1\) 连续场，也没有原高秩/低 Gram/历史资格；只核 (3)—(5) 的代数和捕获条件。不据此声称原目标反例或付款。首次执行因 SymPy 不接受 `Rational*bool` 报类型错误；改为显式 `int` 后，下列完整版本成功运行。

```python
import sympy as s
xs=[s.Matrix([s.Rational(i,4),s.Rational(j,4)])
    for i,j in [(1,1),(1,-1),(-1,1),(-1,-1)]]
ds=[s.Matrix(v) for v in [(s.Rational(2,5),0),(0,s.Rational(2,5)),
                         (-s.Rational(2,5),0),(0,-s.Rational(2,5))]]
Sig=sum((x*x.T/4 for x in xs),s.zeros(2));checks=0
profiles=[(s.Rational(1,4),)*4,
          (s.Rational(1,2),s.Rational(1,4),s.Rational(1,4),s.Rational(1,2)),
          (s.Rational(1,2),)*4]
for cs in profiles:
    G=s.zeros(2);D=s.zeros(2);work=s.Rational(0)
    cap=[[all(abs(x[k]-d[k])<=s.Rational(1,2) for k in range(2))
          for x in xs] for d in ds]
    for i in range(4):
        assert sum(cs[j]*int(cap[j][i]) for j in range(4))<=1
        checks+=1
    for j,d in enumerate(ds):
        weights=[cs[j]/4 if cap[j][i] else s.Rational(0) for i in range(4)]
        mass=sum(weights)
        m=sum((w*x for w,x in zip(weights,xs)),s.zeros(2,1))/mass
        G+=mass*m*m.T;D+=mass*d*d.T
        work+=sum(w*x.dot(d)/2 for w,x in zip(weights,xs))
    P=Sig-G
    assert P[0,0]>=0 and P[1,1]>=0 and P.det()>=0;checks+=1
    exactbound=(s.trace(Sig*D)+2*s.sqrt(Sig.det()*D.det()))/4
    assert s.simplify(exactbound-work**2)>=0;checks+=1
print('PASS 3 finite source/configuration models; '
      '18 exact rational/PSD/work checks')
```
