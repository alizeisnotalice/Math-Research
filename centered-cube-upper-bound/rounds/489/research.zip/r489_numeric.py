from pathlib import Path
from fractions import Fraction as F
import json,sys,platform,time
import sympy as sp
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
ctx.prec=256
start=time.perf_counter();checks=0

def ck(x):
 global checks
 assert x
 checks+=1

def ar(x):
 x=F(x);return arb(x.numerator)/x.denominator

def zero(x):
 ck(x.is_finite());ck(x.contains(0))
# Independent symbolic box moments and ordered kernel integration.
a,b,r,d,T,l,h=sp.symbols('a b r d T l h',positive=True)
z=sp.symbols('z',real=True)
n=sp.symbols('n',positive=True,integer=True)
mean=sp.integrate((d-z)/r,(z,a,b))/(b-a)
second=sp.integrate(((d-z)/r)**2,(z,a,b))/(b-a)
ck(sp.factor(mean-(d-(a+b)/2)/r)==0)
ck(sp.factor(second-mean**2-(b-a)**2/(12*r*r))==0)
dc=(1+r)/4;ell=2*d+(r-1)/2
ck(sp.simplify(mean.subs({a:sp.Rational(1,2)-d,b:d+r/2})-(d-dc)/r)==0)
ck(sp.simplify((ell/r).subs(d,sp.Rational(1,4))-sp.Rational(1,2))==0)
ck(sp.simplify(((d-dc)/r).subs(d,sp.Rational(1,4))+sp.Rational(1,4))==0)
ck(sp.simplify((ell/r).subs(d,dc)-1)==0)
v,w=sp.symbols('v w',nonnegative=True)
same=sp.integrate(sp.integrate(sp.exp(-(v-w)/T)/T,(w,0,v)),(v,0,l))
cross=sp.integrate(sp.integrate(sp.exp(-(v-w)/T)/T,(w,0,l)),(v,l,l+h))
ck(sp.simplify(same-(l-T*(1-sp.exp(-l/T))))==0)
ck(sp.simplify(cross-T*(1-sp.exp(-l/T))*(1-sp.exp(-h/T)))==0)
void=T*(1-sp.exp(-(l+h)/T))
ck(sp.simplify(same+h-T*(1-sp.exp(-h/T))+cross+void-l-h)==0)
# Named cases use their exact branch formulas: no interval decisions at ties.
records=[]
for nn in (1,2,4,8,16,32):
 rr=(-arb(2).log()/nn).exp()
 zero(rr**nn-ar(F(1,2)))
 for name in ('small','mid','critical'):
  if name=='small':
   dd=(1-rr)/8;L1=arb(0);m1=arb(0);s1=arb(0)
   L2=1-2*dd;m2=dd;s2=(L2*L2+nn-1)/12
   first_absent=True
  elif name=='mid':
   dd=ar(F(1,4));L1=L2=ar(F(1,2));m1=-dd;m2=dd
   s1=s2=ar(F(4*nn-3,48));first_absent=False
  else:
   dd=(1+rr)/4;L1=arb(1);L2=(1-rr)/2;m1=arb(0);m2=dd
   s1=ar(F(nn,12));s2=(L2*L2+nn-1)/12;first_absent=False
  U=L1+L2
  ck(U>0);ck(U<ar(F(5,4)) if not(nn==1 and name=='critical') else (U-ar(F(5,4))).contains(0))
  # Actual receiver volume = 2*(r^n L1) + L2 = source rho mass U.
  zero(2*(rr**nn)*L1+L2-U)
  if not first_absent:
   ck(L1>0);ck(s1>0)
  ck(s2>0)
  energies=[]
  for tq in (F(1,4),F(1),F(4)):
   tt=ar(tq)
   def same_mass(ll):return ll-tt*(1-(-ll/tt).exp())
   A1=same_mass(L1) if not first_absent else arb(0)
   A2=same_mass(L2)
   C=tt*(1-(-L1/tt).exp())*(1-(-L2/tt).exp()) if not first_absent else arb(0)
   V=tt*(1-(-U/tt).exp());nonempty=U-V
   diff=m2-m1
   emean=C*diff*diff
   evar=2*s1*A1+2*s2*A2+C*(s1+s2)
   E=emean+evar
   for val in (V,nonempty,E,evar,emean,A1,A2,C):ck(val.is_finite())
   ck(V>0);ck(V<U);ck(E>0);ck(A2>0)
   zero(A1+A2+C-nonempty)
   zero(E-emean-evar)
   if name=='mid':zero(evar-ar(F(4*nn-3,24))*nonempty)
   energies.append(dict(T=str(tq),same_level1=str(A1),same_level2=str(A2),cross_level=str(C),void_mass=str(V),void_fraction=str(V/U),nonempty_mass=str(nonempty),energy=str(E),energy_variance=str(evar),energy_mean_difference=str(emean),energy_per_n=str(E/nn),energy_per_n_sqrt_n=str(E/(nn*arb(nn).sqrt())),variance_per_n=str(evar/nn)))
  records.append(dict(n=nn,geometry=name,R1=str(rr),R2='1',d=str(dd),mass_levels=['1/2','1'],source_weights=['1/2','1/2'],q='1',t='1',L1=str(L1),L2=str(L2),U=str(U),receiver_Lebesgue_measure_X=str(U),positive_source_mean_sign='+; minus source has opposite means',mean_z1=None if first_absent else str(m1),mean_z2=str(m2),variance_trace1=None if first_absent else str(s1),variance_trace2=str(s2),second_moment1=None if first_absent else str(s1+m1*m1),second_moment2=str(s2+m2*m2),level1_absent=first_absent,energies=energies))
result=dict(scope='Atomic-source, actual Lebesgue receiver selector, static q=1 geometry only; no L1-source/history/high-rank/success claim.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r489_numeric.py',seconds=time.perf_counter()-start),checks=checks,geometric_configurations=len(records),energy_parameter_cases=sum(len(z['energies']) for z in records),formulas=dict(selector='R2=1 if both atoms captured; else R1=2^(-1/n) if exactly one captured; otherwise center excluded',E2='[d-1/2,1/2-d] times [-1/2,1/2]^(n-1)',E1plus='([d-r/2,d+r/2] times [-r/2,r/2]^(n-1)) minus E2',d_small='(1-r)/8',d_mid='1/4',d_critical='(1+r)/4',rank='mass 1/2 length L1 then mass 1 length L2; independent uniform mass-atom marks',same='l-T(1-exp(-l/T))',cross='T(1-exp(-L1/T))(1-exp(-L2/T))',energy='2*s1*Same(L1)+2*s2*Same(L2)+Cross*((mean2-mean1)^2+s1+s2)',void='T(1-exp(-U/T))',mid_exact='L1=L2=1/2, means -1/4,+1/4, s1=s2=(n-3/4)/12; Evar=(n-3/4)*nonempty/6'),records=records,errors='Symbolic identities exact; reported algebraic/exponential values are 256-bit Arb enclosures. No floating optimization, lattice, Monte Carlo, or large scan.',decision='The target is E/n <= sqrt(n)*W, not E <= sqrt(n)*W. This two-atom family has U <= 5/4 and bounded E/n, so it is compatible with the target and does not distinguish the general angular root-budget question. It only identifies a non-negligible angular fiber variance term which retaining void does not automatically remove; no original history claim.')
(ROOT/'r489_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'symbolic/Arb assertions;18 real-center geometries,54 T probes;atomic static scope only')
