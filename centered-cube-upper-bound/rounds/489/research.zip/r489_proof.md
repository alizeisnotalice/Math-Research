# R489：保最大点 void 的同源秩向量能量与原一次功

本稿只研究 R481 原一次长边功 \(w_\ell\)，不改原接受权，不读或使用另一作者本轮新稿。结论是带明确可付边界项的正向比较(5)，以及保真实中心条件纤维的 Volterra 能量式(7)。尚未证明其中角向能量的根阶源价；没有用累计 signed 功替换原一次功。

## 1. 原实际秩与中心条件纤维

沿 R479 main §§1–3，\(\mu=f dx\)、\(\nu=t\sigma\)、\(0\le t\le S\)，父附 uniform mark，在每个原质量带 \(j\) 内
\[
 \rho_{x,j}(d\widehat A)=1_j(A)c_A(x)\nu(dA)ds_A/m_A,
 \quad U_j(x)=|\rho_{x,j}|,
 \quad v_x(\widehat A)\in[0,U_j(x)].
\]
增广秩将 \(\rho_{x,j}\) 推为 Lebesgue \(dv\)。它**不**把给定秩的中心纤维压成唯一中心。对 \(\mu(dx)dv\) 几乎处处作实际可测条件分解，记
\[
 z_A=(x-A)/R_A,\quad
 \bar z(v)=E[z_A\mid x,j,v],\quad
 \mathfrak q(v)=E[|z_A|^2\mid x,j,v],\quad
 \mathfrak v(v)=\mathfrak q(v)-|\bar z(v)|^2\ge0.
\]
有 \(|z_A|^2\le n/4\)。这些条件量都保完整来源和真实 Lebesgue 中心；质量原子内仍平均实际中心及 mark，而非任意选一个代表。

未筛 raw 最大点联合律是
\[
 d\mathcal G_{\rm raw}
 =\mu(dx)\sum_j\rho_{x,j}(d\widehat A)\rho_{x,j}(d\widehat B)
 1_{w<v}\frac{e^{-(v-w)/T}}T. \tag{1}
\]
这是最大点 Palm 公式，不是把成功后的配置假定为独立。原 \(\Omega_\ell\) 在包含原记录、lower raw 配置等标签的共同空间上是该 raw 试验的正限制；投影后(1)只作非负上界。其余历史从未移到 \(B\)。原质量 \(R=\int\nu=\int\mu\sum_jU_j\)，raw 非空质量不超过 \(R\)。零秩行取零。

## 2. 原功的 void-preserving 正上放与完整费用

定义一个具体未筛**向量差分能量**
\[
 \mathcal E_{\rm rank}
 =\int|z_A-z_B|^2d\mathcal G_{\rm raw}.
\]
它仍含(1)的指数 void 与同源条件纤维。真实半径误差满足
\[
 \frac{z_A\cdot(B-A)}{nR_A}
 =\frac{|z_A-z_B|^2+|z_A|^2-|z_B|^2}{2n}
 +(1-R_B/R_A)\frac{z_A\cdot z_B}{n}.
\]
由于单 octave，最后一项绝对值至多 \(|\log(R_A/R_B)|/2\)。只对此误差使用 R481 已付半径账。

固定 \(x,j\)，raw 范数差可精确换序：
\[
 \mathcal B_{x,j}
 =\int_0^U\mathfrak q(v)
 [e^{-(U-v)/T}-e^{-v/T}]dv. \tag{2}
\]
方括号积分为零，其正部积分恰为
\(T(1-e^{-U/(2T)})^2\)。因此
\[
 |\mathcal B_{x,j}|\le\frac{nT}{4}(1-e^{-U/(2T)})^2.
 \tag{3}
\]
这包含两端边界，没有用无穷区间近似，也未丢质量原子。

令 \(\Delta_\ell=R-|\Omega_\ell|\)，\(\mathcal L_\ell=\int_{\Omega_\ell}|\log(R_A/R_B)|\)，\(\mathcal M=\int\#\{j:U_j(x)>0\}d\mu\le NW\)。raw 到 \(\Omega_\ell\) 的删除质量不超过 \(\Delta_\ell\)，每条被删范数差在 \([-n/4,n/4]\)。而平方差非负，可直接上放。因此
\[
 \boxed{w_\ell\le\frac{\mathcal E_{\rm rank}}{2n}
 +\frac T8\int\sum_j(1-e^{-U_j/(2T)})^2d\mu
 +\frac{\Delta_\ell}{8}+\frac{\mathcal L_\ell}{2}.} \tag{4}
\]
这是直接作用于原一次功的比较，不是累计到达费用或新父历史。没有另收 raw 空样本价；它已通过 \(\Delta_\ell\) 上界包含在原失败账中。

R481 原账给 \(\Delta_\ell\le\alpha X+\kappa TNW\) 及 \(\mathcal L_\ell\le C_LW\)，其中
\[
 C_L=T(\log r+\log2)+S\log r(1+\log2),\quad
 N\le1+\log r/\sqrt n+\sqrt n\log2.
\]
\(\alpha,T,\kappa\) 必须沿原同一成功合同取值，不重新优化或漏门。由(4)，
\[
 \boxed{w_\ell\le\frac{\mathcal E_{\rm rank}}{2n}
 +\frac\alpha8X+
 \left[\frac{T(1+\kappa)N}{8}+\frac{C_L}{2}\right]W.} \tag{5}
\]
全部显式附加项为可吸收 \(X\) 加根阶源价，系数代入 R481 的 \(2/\eta^2\) 时仍须一起调参；这不证明第一项已付。若将来能对这个**实际**能量证明 \(\mathcal E_{\rm rank}/n\le\varepsilon'X+C_{\varepsilon'}\sqrt n\,\operatorname{polylog}(n+2)W\)，(5)才能回代原 \(w_\ell\) 目标。

## 3. 一个保全部中心方差的精确 Volterra 公式

由(1)的秩纤维条件独立分解，
\[
 \mathcal E_{\rm rank}=\int\mu(dx)\sum_j
 \int_{0<w<v<U}\frac{e^{-(v-w)/T}}T
 [|\bar z(v)-\bar z(w)|^2+\mathfrak v(v)+\mathfrak v(w)]dw\,dv. \tag{6}
\]
条件独立只来自未筛 raw 最大点的 rank-only void；没有对成功门内的两父作此断言。

置
\[
 g(v)=T^{-1}\int_0^v e^{-(v-w)/T}\bar z(w)dw,
 \quad Tg'=\bar z-g,\quad g(0)=0,
\]
以及 \(a_U(v)=2-e^{-v/T}-e^{-(U-v)/T}\)。由于 \(\bar z\) 有界、\(U<\infty\)，\(g\) 绝对连续，以下分部积分合法。每纤维能量精确等于
\[
 \boxed{\begin{aligned}
 E_{x,j}={}&\int_0^U a_U(v)\mathfrak v(v)dv
 +2T^2\int_0^U|g'(v)|^2dv+T|g(U)|^2\\
 &-\int_0^U[e^{-v/T}+e^{-(U-v)/T}]|\bar z(v)|^2dv.
 \end{aligned}} \tag{7}
\]
证明：均值部分先展开为
\(\int a_U|\bar z|^2-2\int\bar z\cdot g\)。由
\(\bar z=g+Tg'\)，
\(\int\bar z\cdot g=\int|g|^2+T|g(U)|^2/2\)，再展开 \(\int|\bar z|^2\) 即(7)。最后负边界项必须保留；不能把(7)仅当一个无边界导数能量。

还得到安全但不足的粗界：\(\int\bar z\cdot g\ge0\)，故
\[
 0\le\mathcal E_{\rm rank}
 \le\int\mu\sum_j\int a_U\mathfrak q
 \le\frac n4\int\mu\sum_jU_j\min(2,U_j/T)
 \le\frac n2 R. \tag{8}
\]
(8)最多给线性维数源价，不能把 \(\int U_j^2d\mu\) 默认当已知根阶矩。它准确显示 void 对低秩的抑制以及高秩部分尚无衰减。

## 4. 唯一缺步及本轮决策

R488 控制的是原父来源后验下的 **标量** \(|z_A|^2/n\) 方差；(6)包含固定来源、固定质量秩下的 **中心向量** 方差 \(\mathfrak v\)，以及秩方向变化 \(g'\)。二者条件测度相反，常范数也不强制角向差为零。当前完整匹配、原接受门和已证径向价没有给出
\(\int\mu\sum_j E_{x,j}=O(\varepsilon nX+n^{3/2}\operatorname{polylog}(n+2)\,W)\)
这一联合比较。若直接去掉(7)的负边界只会加强未证要求，本文不这样声称付款。

须特别指出：平方差从实际成功流正上放至 raw 时，原成功权 \(\chi\) 已被丢掉；所以 raw 能量预算是充分而可能过强的目标，不是原 \(w_\ell\) 根价的必要条件。是否继续采用此 raw 目标应另经保持完整匹配的数值范围判断。本轮没有取得核心角向根阶价格。

因此本轮保留(4)–(7)作为明确的同源 void 能量接口：边界、半径、一次删门已全部定价；真正还需控制的是(6)中保实际中心条件方差的角向能量。未证明这一控制，也未把它定义出来当作完整预算进展。没有展开匹配反例搜索。

## 5. 实际本机核验及范围

指定 Python/SymPy 实际输出：
```text
26 exact SymPy assertions PASS; 8 rank-profile cases plus one atom-fiber diagnostic.
constant-norm two-direction fiber energy = exp(-2)/8 + 1/8
Rank-fiber algebra only, not a native matching/history model.
```
八组覆盖 \(T,U\in\{1,2\}\)、常均值及线性均值／正条件方差，核 ODE、(2)、(7)。最后的同质量纤维等概率向量 \(\pm1/4\)、\(T=1,U=2\) 有恒定平方范数但正角向能量，说明径向量不能在纯算子代数层面替代角向量；它不是原生 qband/history 反例。

```python
import sympy as s
v,w=s.symbols('v w', real=True)
checks=0
for T in (s.Integer(1),s.Integer(2)):
 for U in (s.Integer(1),s.Integer(2)):
  for mean,var in [(s.Rational(1,8),s.Integer(0)),
                   ((v-U/2)/8,s.Rational(1,64))]:
   kernel=s.exp(-(v-w)/T)/T
   a=2-s.exp(-v/T)-s.exp(-(U-v)/T)
   g=s.simplify(s.integrate(kernel*mean.subs(v,w),(w,0,v)))
   assert s.simplify(T*s.diff(g,v)-(mean-g))==0;checks+=1
   direct=s.integrate(s.integrate(
       kernel*((mean-mean.subs(v,w))**2+2*var),(w,0,v)),(v,0,U))
   formula=(s.integrate(a*var,(v,0,U))
       +2*T*T*s.integrate(s.diff(g,v)**2,(v,0,U))+T*g.subs(v,U)**2
       -s.integrate((s.exp(-v/T)+s.exp(-(U-v)/T))*mean**2,(v,0,U)))
   assert s.simplify(direct-formula)==0;checks+=1
   q=mean**2+var
   boundary=s.integrate(s.integrate(
       kernel*(q-q.subs(v,w)),(w,0,v)),(v,0,U))
   edge=s.integrate(q*(s.exp(-(U-v)/T)-s.exp(-v/T)),(v,0,U))
   assert s.simplify(boundary-edge)==0;checks+=1
T=s.Integer(1);U=s.Integer(2)
energy=s.integrate(s.integrate(s.exp(-(v-w))/8,(w,0,v)),(v,0,U))
assert s.simplify(energy-(1+s.exp(-2))/8)==0;checks+=1
assert energy.is_positive is True;checks+=1
print(f'{checks} exact SymPy assertions PASS; 8 rank-profile cases plus one atom-fiber diagnostic.')
print('constant-norm two-direction fiber energy =',energy)
print('Rank-fiber algebra only, not a native matching/history model.')
```
