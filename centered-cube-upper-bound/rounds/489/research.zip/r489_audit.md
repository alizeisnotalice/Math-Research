# R489 独立终审

FINAL PASS（限定范围）。认证原一次长边功到保 void 的真实秩向量差分能量的充分比较、相应一次边界／删除／半径费用、精确 Volterra 恒等式与实际后验 PSD 接口；不认证核心角向能量的根阶价格、原 w_l 付款或一般上界闭合。

独立 PRE 在读取 R489 作者稿前形成并保留于 r489_audit_pre.md。终审核对所有八项冻结输入。增广质量原子秩的真实中心条件核不能压成代表中心；未筛 raw 端点条件独立只在 rank-only void 参考上使用，实际成功后不作此假设。对 signed 功先作准确几何分解，仅正平方差可正放；范数差的原接受删除误差为 Δ_l/8，保 void 的双端边界价格为 T∫Σ(1−e^{−U/(2T)})²dμ/8，半径价格为 ℒ_l/2，均保原 T、S、带数及母账回代系数。该 raw 能量只是充分而可能过强的目标，非原预算的必要条件。

Volterra 式保留秩均值变化、真实中心纤维方差以及两份负端点项，符号与系数正确。实际后验 Jensen 给 G_A≼Σ_A，矩阵 Cauchy 亦合法；低 Gram 族没有自动控制原父—最大父方向配对，未形成新付款。一次费用没有转作累计 V 费用，原历史及全部未付母账保留。

独立隔离重放 geometry 18、proof 26、numeric 1035 项，共 1079 项精确／区间断言通过；三份 stdout 与 replay 完全一致。numeric JSON 仅删除 compute_index.seconds 后全字段一致，canonical SHA256 为 `974d7f670f3d50cca7ec2f696edfbe34826b8ebafa5313ee79ae674d2784f836`。54 能量参数例来自 18 个有限原子来源、真实 Lebesgue 接收中心配置；不是 L¹／原高秩／成功历史认证。终稿正确区分 E 与 E/n：此族 E/n 有界且 U≤5/4，与 E/n≤C√nW 相容；E∼n 不能否定该目标或排除 raw 路线。模型索引只作后续历史定位，不作为本轮新增证明或计算。

## 冻结输入 SHA256

- `r489_main.md`: `bf38d770c338d2047b8f68da2b46b731777e15fe3a9a3efa4b8e4ebc27b7bce4`
- `r489_geometry.md`: `0948c96f60376d8df8be91463422cf84c82dcb93e66028ac9032d1deb8c4fafb`
- `r489_proof.md`: `d96985287b66aad7b4b1c6cb658c1231684dd19ce5a6358c104e01506ea97724`
- `r489_numeric.md`: `69ff1804e2827f87dd0f903423f18c4d55be2381aa6b8174432c287a793350cb`
- `r489_numeric.py`: `5a0b176297dd3e530271c05ffed0f3bc617e2038cf4a13c2267608e6a2b344b5`
- `r489_numeric.json`: `d058136e90b827d86535f342a203e031aaa4422e637e272bdd1ab4005a0a7159`
- `r489_model_index.md`: `6e26db0d37c17ee6098553abc74f31c6553ad8644843dd4d2bb4cab364a6a7b2`
- `r489_replay.json`: `fd6c41ffe2219187f9700d48d484c4642a8f7d93f2e02baccaa6dd8d7a485155`
