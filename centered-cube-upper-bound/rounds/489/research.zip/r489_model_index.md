# R489 可计算模型索引（历史定位，未作新计算）

**优先下一轮：真实中心 + 多质量层的 B41 型模型。**

1. [原空间临界 source-tail 合同](/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/critical_source_tail_arrival_20261007.md:5) §1–2（第5、23–33行）：
\[
\mu=\sum_{k\in\{1,2,4,8\}}w_k\,\mathrm{UnifGrid}(q_k)^{\otimes n},\quad A=16n,\quad q_k=2Ak+1,
\quad w=(1/2,1/6,1/6,1/6),\quad W=1.
\]
重合原子按完整正混合质量相加；接收中心是真实 Lebesgue x；边长连续取 [1,2]，用所有到达半径精确算 full-mixture winner。故可按实际 \(q_A=m_A/R_A^n\) 后分 q-band，并计算真实 \(U\) 所需的中心/来源量。它有4个分辨率层，但不是 R433 原历史或 high-rank 条件证书；报告明确仅有有限有理 receiver probes、未做总体中心/来源矩积分，且未实现 A13/A14（第5、19、49–53行）。适合作为下一轮解析/数值能量探路基底，不能把现存 probes 当作 U 结果。

2. [B41/B62 受限真实空间模型族](/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/source_occupation_tail_geometry_20261007.md:82) §5（第84–94行）：完整来源分别为 B41-inspired 的 n维有限 tensor grids 正混合（2/4/8层，正权；重合质量相加）和 B62-inspired 的 n维均匀盒 log-width 混合（宽度从 \(n^{-1/2}\) 到 \(n^{1/2}\)，正权）。实际 receiver 为 Lebesgue 中心；grid 响应用各维闭区间计数乘积，盒源用真实交体积；完整有限节点 winner、source replicas 与 I₂/I₁ profiles 已记录（第96–126行）。可从完整输入筛 q-band、按原始定义求高 source-rank 指标；历史资格：**未知/未实现**，文件明确不称完整 B41/B62/A13/A14 下界资格，且现有尾置信界无界（第126、130行）。因此可以用来挑选/压力测量 U，但现存 profile 数字不能作为严格能量证据。

3. **用户24步宽窗口 cluster**：[原输入](/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/inputs/centered_cube_wide_window_cluster_lower_bound_20261001(1).txt:35) §1–2、[R418 复核记录](/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/418/research.zip) 内 `r418_main.md:28–53`。原对象是一维周期来源 \(\rho_{U,K}=K/(K+20)\mu_U+(20+h_0/\sqrt{3D})/(K+20)dx\)，其中 \(\mu_U=K^{-1}\sum_{j=1}^K\delta_{(j+U_j)/K}\)，对24步长度窗计算单行平均与 size-biased log-moments。它保留同一 U 下的跨长度相关性，适合验证多尺度 cluster 单行分布；**不具备**实际 n维立方体接收中心、winner/q-band 或原历史 rank 字段，且不是全空间 L¹ cube 场。因此不能直接拿它测当前 rawrank U；也不能把 R418 单行数值当高秩能量结果。

索引判断：下轮若只选一项，先从候选1的完整 B41 层混合做真实中心 q-band 及高源层 rank 的 U 分解；候选2用于改变层结构交叉核对。候选3只作共享宽窗口相关性校准。上述“高 source-rank/原 history 资格”在各报告中都未认证，须由目标的准确 rank 定义另行标注。
