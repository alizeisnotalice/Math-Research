# R267 final independent integrated audit

**PASS. No necessary correction found.**

Audited main: `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/267/work/proof.tex.txt`

SHA256: `66d96323ff8a1726f95aa6d009b90bb2dce911e47fa3c391e738716fe5e70b2a`.

The statement screens preceded the author proof and final integration. Supporting independent notes are `/tmp/r267_screen.md` (the separate FIRST/core/collar route) and `/tmp/r267_local_audit.md` (actual localized-response extraction and the later same-θ J extension). The latter has SHA256 `41187f6138c24d21af6c7ed307a539a20f785a121eaad6450aaf37269e15185a`. This final review did not repeat their completed arithmetic checks or modify any repository file.

## Integrated findings

1. **Original inputs and support: PASS.** The main imports the audited R266 complete fixed-original-time auxiliary-posterior response estimates, rather than only a bare fixed kernel norm. The actual good-upper-score direction, all positive history masks, full ν posteriors and original soft off-core values remain. Actual near support gives Q_(b+d)(y) without reinserting a hard source or spending a second cap. The common-leaf receiver gate and unique j(x) masks are explicitly kept; receiver disjointness is not inferred merely from disjoint source leaves.

2. **Source extraction and local response Gram: PASS.** With full-side-w support, the source Gram vanishes beyond infinity-distance w. The relevant source neighborhood is exactly Q_(2w)(y). The symmetric estimate (5) has no hidden factor two, covering count or independent-source assumption. θ=min(1,τ/m) is measurable, chosen from the frozen original β_V before x,j,t,v,u, and only allocates the original positive source slot. It does not rebuild ν, Π, forbidden sets or original qualifiers.

3. **Same θ for all p and J: PASS.** For every actual or auxiliary receiver center x, Q_w(x)⊂Q_(2w)(y) whenever y∈Q_w(x). Therefore the extracted βθ has the proved pointwise cap βθ(Q_w(x))≤τ, including zero-window cases. Pointwise Holder and Tonelli yield (7) exactly, and disjoint j masks give (8) with J0 rather than an invented probability over j. This establishes the same source extraction for moving p=2 and J p=3/2, while keeping their different receiver norms.

4. **Actual three-leg allocation: PASS.** The weights λ_i=√K_i/(√K1+√K2+√J) are the correct positive allocation for the original good-based half-density inequality. Multiplying the SAME θ(y) through the actual source slot makes the three allocated quantities cover precisely the θ fraction of the current original positive flow. Old paid subtraffic remains excluded by the definition of current responses. No negative ledger is split or copied. The shared C_out includes the original tree/high/hardcap/weight fees once.

5. **Constants (9)–(12): PASS.** The receiver and seed/leaf Holder exponents are correct. The scalar Young constant is c_p=(p−1)^(p−1)/p^p. The moving source coefficient (11) is C_out²/4 times D Bα² and J0τ/(ελa^n), giving 256Λ²Kγ^n/27. With τ=λa^n/√J0, its remaining scale factor is √J0. For J, A_J^(3/2) contributes a^(−n/2), exactly canceled by (τ/λ)^(1/2), and the remaining j factor is J0^(3/4). The full M, c_n, nlog2/4, κ and collar exponent in (12) are correct. Equivalently c_(3/2)·(3/2)=1/√3, matching the independently derived coefficient. No dimensionful factor has been lost.

6. **One total receiver error: PASS.** The proof explicitly chooses ε_mov=ε_J=ε/2, so the two group applications of Young cost one total εX, not two copies. The actual common-leaf receiver mask supports the single |E|; the manuscript correctly requires an explicit receiver-multiplicity price if that mask is enlarged later.

7. **Asymptotic and unpaid complement: PASS.** Under the stated fixed legitimate K and fixed low-soft constant C*, D=O(log(n+2)), Bα=O(log(n+2)), J0≤n+2. The moving coefficient is root times log³. The J coefficient is explicitly a polynomial times exp[−c_Jn/2+O_C*(√log(n+2))], so it admits the same asymptotic envelope with a constant depending on the tiny audited c_J. No practical finite-n exponential suppression is asserted. Formula (13) is the exact entire three-leg complement; its traffic, total mass fraction and general root payment remain unproved. The full Wβ connection is kept under its original proved source ledger, not replaced by an unrelated source mass.

8. **Separate core route and signed scope: PASS.** The main does not use the fixed-parameter core-window lemma to infer an actual adaptive target column or a free near-collar bound. Those missing interfaces are explicitly separate from the successful Gram extraction. The original signed mother, R262 paid boundary and once-only negative credits remain unchanged. The result is a genuine newly paid explicit source fraction of the existing low-soft near positive branch, not general closure or a uniform lower bound on the extracted fraction.

## Evidence boundary

The earlier author L6 Fraction block was independently extracted and executed: 48 checks passed (24 extraction and 24 finite response-Gram configurations), with reported exact ratios 1 and 37/45. No physical kernel model or numerical full-traffic instance was rerun in this final audit. The additional same-θ all-p theorem and constants are verified analytically above; parent reproduction may add finite local-cap algebra without changing that proof status. No FULL/source instance, interval certificate or general completion is inferred from finite checks.

Only this /tmp final audit was written. No Git, PDF, repository changes or further exploratory task was performed.


---
## 独立先审命题记录（先于作者稿）

# R267 independent statement screening

## Verdict

The FIRST-weighted Cauchy step is valid in the original GOOD-upper-score direction. The proposed **fixed-parameter core-window lemma is valid**, with β0=(1−σ)min(c0,1/4), in its stated interior ξ≤1−2/n. It does not by itself prove the actual adaptive receiver column. More strongly, enlarging the core to the true near-support ℓ1 halo using only support can require an exp(c n^(1/4)) factor. The exact collar and selector resources therefore remain mandatory. This is a narrow kernel screening result, not a FULL/source counterexample or a global impossibility claim.

No R267 author proof was used. Only this /tmp note is written; no repository, Git or PDF changes.

## 1. The genuine FIRST-weighted Cauchy inequality

At a fixed actual receiver x, retain the original target good slot v and δ=(k_v−k_u)+. Integrating the other slot and positive masks gives δ contribution at most k_v. With H_t(y,v)=exp[−αΣ_(C_i<ξ)(1−C_i)], ξ=c_jt/b, the original weighted-score estimate gives

\[
 \int_{I_y}k_tH_t\,d\Pi_t\,dt/t\le\mathcal B_\alpha(n),
 \qquad\mathcal B_\alpha=\frac2{e\alpha}[1+\log_+(e\alpha n)].
\]

For a single good-based half-kernel, Cauchy under the actual nonnegative measure β(dy) dlogt Π_(y,j,t)(dv) splits k sqrt(p_y K_target/barw_L) into sqrt(p_y k H_t) times sqrt(k K_target/(barw_L H_t)). The original same-x FIRST ∫p_y β≤q therefore yields exactly

\[
 I(x)^2\le q\mathcal B_\alpha(n)
 \int\beta(dy)\int_{I_y}\int
 \frac{k_t(v)K_{target}(x-v)}{\bar w_{L(x)}(y,v)H_t(y,v)}
 \,d\Pi_t(v)\,dt/t.
\]

Original finite truncation, empty positive-degree rows, actual j(x) and remaining positive masks are handled before the relaxation. No future-node FIRST is asserted. This is a legitimate linear-β target-column objective, not yet its payment. Original outside constants, source identity and any prior hardcap remain.

## 2. Core lemma: exact domain and proof

Scale b=1. Let 0<l=L/b≤a′=A/b≤1, ξ∈(0,1−2/n], and l≥ξ/γ, γ=1+1/n. Put C=C(r), Ω=min(1,C/l), q0=1−C. The fixed target mass over the core is

\[
 m_\sigma=\int_{-1/2}^{1/2}(a')^{-1}f_\sigma((x-r)/a')dx.
\]

For every coordinate, mσ/Ω≤1 by the usual target mass/min-clamp bound. For ACTIVE C<ξ the stronger statement is

\[
 \boxed{m_\sigma/\Omega\le1-(1-\sigma)\min(c_0,1/4)(1-C),
 \quad c_0=\phi(3/2).}
\]

If Ω<1, radial enlargement to b gives

\[
 m_\sigma/\Omega\le(l/a')[(1-\sigma)A_0(r)+\sigma V(r)]/C(r)
 \le1-c_0(1-\sigma)(1-C).
\]

Use the established A0/C gap, with r≥1 handled by A0=0. If Ω=1, the soft part has probability mass at most one. For the hard part, C<ξ gives q0≥1−ξ≥2/n, while

\[
 C-a'\le\xi-\xi/\gamma\le1/n\le q_0/2.
\]

Also r≥q0, using C≥(1−r)+. Since a′≤1 and r≥0, the hard target can spill only through the right core boundary. Its overhang is

\[
 r-(1-a')/2\ge q_0/2-(C-a')/2\ge q_0/4.
\]

The missing hard probability is min(1,overhang/a′)≥q0/4. Thus mσ≤1−(1−σ)q0/4. Combining the two clamp cases proves the lemma. The condition ξ≤1−2/n is essential in this proof; for small n the nonempty interior may simply be absent. This lemma does not silently treat its complementary terminal strip.

Tensorization for FIXED L,A,σ gives

\[
 \int_{Q_b(y)}\frac{P_{\sigma,A}(x-v)}{\bar w_L(y,v)}dx
 \le\exp[-\beta_0\sum_{C_i<\xi}(1-C_i)].
\]

If α≤β0, division by H_t can be absorbed on this fixed core (with residual gap if strict). It remains a fixed-parameter integrated statement.

## 3. Actual selectors are a separate unproved step

In the desired objective L(x), A(x), σ(x) vary inside dx. A fixed-parameter probability mass bound cannot be inserted under that integral as a pointwise inequality. For A=L, the target-only amplitude is L^(−n)/barw_L, with profile nondecreasing. Its column estimate has scale power zero; the R264 Abel argument with a strictly positive decay exponent does not immediately give a dimension-free constant. For the clipped target an additional scale-regime distinction is needed. No uniform actual-selector column is established by the core lemma alone. Any scale/menu factor must be proved and retained.

## 4. The exact necessary near-collar term

The original near support after hard-source relaxation gives only

\[
 \mathcal H_r=\{x:\operatorname{dist}_{\ell^1}(x,Q_b(y))\le r\},
 \qquad r=d/2=a/(16\sqrt n).
\]

The target column is the core term plus the positive collar

\[
 \mathcal C_{collar}=\int_{\mathcal H_r\setminus Q_b(y)}
 \frac{P_{\sigma,A}(x-v)}{\bar w_L(y,v)H_t(y,v)}dx.
\]

This term cannot be dropped. It is not legitimate to replace the integral over a union of translated cubes by the supremum of their separate integrals. The exact ℓ1 halo has a mixed-face expansion; the box Q_(b+d)(y) is a further relaxation, not an equality or a cost-free transfer of the core gap.

A single explicit boundary layer demonstrates why support alone does not preserve a polynomial-cost version of the core gap. Set b=2a, y=0, s=σ=0, and take the same dimensionless displacement

\[
 v_i/b=r_n=\frac1{16}n^{-3/4},\quad C=C(r_n),\quad
 \xi=C+\frac1{2n},\quad l=L/b=\xi/\gamma,\quad A=L.
\]

For n^(1/4)≥200, C<ξ≤1−2/n, l≥1/2 and l≤C, so EVERY coordinate is active and every Ω=1. Indeed 1−C≥r_n/5, using φ(1/2)≤φ(0)<4/5 and C(r)=1−r+∫_(1/2)^(1/2+r)φ for r≤1. Also 1−C≤r_n. These imply all claimed parameter inequalities.

Let X be uniform in the genuine target cube Q_L(v). In one coordinate the right overhang above Q_b(0) has length u=(b r_n+(L−b)/2)+≤b r_n. The expected ℓ1 distance is

\[
 \mathbb E\operatorname{dist}_{\ell^1}(X,Q_b(0))
 =\frac{nb\,[r_n+(l-1)/2]_+^2}{2l}
 \le nb r_n^2=\frac b{256\sqrt n}.
\]

The actual support radius is r=b/(32√n). Markov therefore gives target probability in the true ℓ1 halo at least 7/8. At the same time

\[
 \sum_{active}(1-C)=n(1-C)\ge n^{1/4}/80.
\]

Consequently the normalized target column WITH reciprocal H satisfies

\[
 \boxed{\int_{\mathcal H_r}\frac{P_{0,L}(x-v)}{\bar w_L H_t}dx
 \ge\frac78\exp(\alpha n^{1/4}/80).}
\]

This is already a fixed-parameter, nonatomic probability-kernel statement. It rules out deriving a polylogarithmic uniform bound on this enlarged support column from the core lemma and the near-support condition alone. It does NOT construct the original FULL FIRST/cube/ν/β instance and does not rule out a genuine joint estimate retaining the actual conditional hard-source weight. The missing resource is precisely such a joint collar/receiver/source bound, rather than an independent support envelope. This is a targeted diagnosis of the required collar term, not a broad counterexample search.

## 5. Actual bounded diagnostics

Executed locally: 27 exact Fraction saturated-active geometry cases, all PASS. Also ordinary mp100 evaluation of the actual C at n=2^32,2^40,2^64 for the boundary layer above confirmed all inequalities. The analytic target-halo lower bounds were approximately .9711400, .9701360, .9698029, respectively; the corresponding actual active deficits were approximately 9.75507, 39.02029, 2497.29830. These are evaluations of the explicit geometric formulas, not full high-dimensional quadrature or FULL qualification. The general conclusions use the analytic proofs above, not numerical sampling.


---
## 同份额全 p 延伸的先审记录

# R267 independent audit: localized actual moving response

**PASS. No necessary correction found.**

Audited `/tmp/r267_localization.md`, SHA256 `1f1da3f3fc0e29f740d9a79b9167d285c17f84258d135e8cce0afbaa3e5dd0d9`.

The statement was independently screened before reading the author proof. This note concerns the actual positive moving-leg source extraction only; it does not certify the FIRST-CS/core-to-halo route discussed separately in `/tmp/r267_screen.md`, the J allocation, or general closure.

## 1. Independent measure-theoretic proof

Fix the complete original outer seed and leaf, retain the actual common-leaf receiver mask and original unique j(x) masks. By the already independently audited R266 result, H_yj≥0 is jointly measurable, supported in E∩V∩{j(x)=j}∩Q_w(y), w=b+d, and has norm at most A=√D a^(−n/2)Bα. The original two Π factors and score-clock have been included before this step.

Define U_y=Σ_j H_yj. Since the receiver j masks are disjoint (the original j(x) is not chosen by y),

\[
 \|U_y\|_2^2\le J_0A^2.
\]

Its true Lebesgue Gram kernel K(y,y′)=∫U_y(x)U_y′(x)dx is nonnegative, ≤J0A², and vanishes if ||y−y′||∞>w. Boundary-only intersections have zero dx measure; including equality in the upper indicator is safe. Thus for any measurable θ∈[0,1], Tonelli gives

\[
 \left\|\int\theta(y)U_y\,d\beta(y)\right\|_2^2
 \le J_0A^2\iint1_{\|y-y'\|_\infty\le w}\theta(y)\theta(y')\,d\beta(y)d\beta(y').
\]

This is the actual compact response Gram, not an invented independent-scale source kernel.

Let m(y)=β(Q_(2w)(y)), where Q_(2w) has FULL side 2w, and θ=min(1,τ/m), setting θ=1 when m=0. Parameterized Borel integration gives measurability. All quantities are finite for finite β; the zero case causes no division issue. By symmetry and 2θθ′≤θ²+θ′²,

\[
 \iint1_{\|y-y'\|_\infty\le w}\theta\theta'\,d\beta d\beta
 \le\int\theta(y)^2m(y)\,d\beta(y)
 \le\tau\int\theta\,d\beta.
\]

Hence the displayed extraction energy is valid for arbitrary finite positive Borel measures, in particular the authentic finite positive L1 soft sources. No density cap, β rank, β=ν, source-coordinate independence, graph-cover count or replacement posterior is used.

## 2. Exact original positive allocation and payment

Apply θ ONLY in the actual original soft-source y slot of the still-unpaid moving allocated positive subquantity. It is fixed by β_V, the outer seed and original global a,b,n,λ before x,j,t,v,u. The full original ν and both posteriors remain unchanged. Original good/high/history and all receiver masks remain inside H_yj. Current/future FIRST for θβ is inherited by positive restriction, but no new FIRST is needed to prove this Gram algebra.

The new partial traffic is at most C_out times the integral of U_y against θβ. With the original receiver qualification retained, E_(ω,V)⊂E∩V and Σ_V|E_(ω,V)|≤|E|. This is a genuine receiver support condition established upstream and explicitly kept here, not a consequence inferred from disjoint source leaves. Receiver Cauchy and seed/leaf Cauchy give

\[
 P_\theta\le C_{out}\sqrt{J_0D}\,a^{-n/2}B_\alpha
 \sqrt{\tau|E|W_\theta}.
\]

The scalar Young inequality therefore yields precisely

\[
 \boxed{P_\theta\le\epsilon_Y X+
 \frac{256\Lambda^2K\gamma^nDB_\alpha^2}{27\epsilon_Y}
 \frac{J_0\tau}{\lambda a^n}W_\theta.}
\]

Indeed C_out=(32Λ/3)√(K/3)γ^(n/2), so C_out²/4=256Λ²Kγ^n/27. This includes the same original hardcap and physical-weight comparison exactly once. It introduces no extra q or hard source. If the common-leaf receiver support is relaxed later, the first term must revert to ελ EΣ|E_(ω,V)|; the manuscript explicitly says so.

Choose τ=λa^n/√J0. Then J0τ/(λa^n)=√J0. For the original finite menu J0=O(n), legitimate fixed K, and s0=C logn/n≤1/2 with fixed C, D=O_C(log(n+2)), Bα=O(log(n+2)), and γ^n<e. Thus this explicit actual positive fraction costs

\[
 \epsilon_YX+O_{C,K,\epsilon_Y}(\sqrt{n+2}\log^3(n+2))W_\theta,
 \qquad W_\theta\le W_\beta.
\]

Keeping the parameter K explicit is correct. This is a real branch payment and a stronger statement than merely naming the local moment ∫mβ: the constructed θ actually makes the current response energy linear in the extracted source mass.

## 3. Remaining scope and unpaid terms

The exact complementary source multiplier is (1−τ/m(y))+, supported where m>τ. The theorem does not bound the size or traffic of this complement, give a dimension-independent extracted mass fraction, or assert that θ≈1. J's allocation is untouched. Both pieces retain all original soft off-hardcore values and full ν posteriors; the source split is not a hard-core truncation or a reconstruction of β/ν.

No signed negative credit is transferred to the half-density baseline. Previously paid positive subbranches must remain excluded in the definition of the current H_yj; the proof applies to any such retained current subtraffic. It neither reopens those branches nor consumes their prices twice.

Iteration is not free: distinct extracted responses have cross-Gram terms, and separately invoking Young spends a new receiver error. The manuscript explicitly retains those issues. Actual FIRST/hardband at receiver centers does not imply the source-centered local mass m(y)≤τ. Therefore this result pays the stated new moving-source fraction while leaving the general root goal unresolved.

## 4. Actual independent arithmetic replay

After the independent proof screen, I extracted and actually executed the author's L6 standard-library Fraction block from the audited Markdown. Exit 0 and exact output:

`PASS 48 extraction_cases 24 Gram_cases 24 max_energy_ratio 1 max_Gram_ratio 37/45`.

These are 24 finite symmetric-extraction configurations and 24 finite response-Gram checks, not 48 FULL/source geometric histories or evidence of a general uniform extracted fraction. The general proof is the Tonelli/Cauchy/symmetric inequality above. No broader test or original traffic reconstruction was run. Only this /tmp audit file was written; no repository/Git/PDF changes.


## 5. Additional independent statement screen: the SAME extraction also pays J

The following additional parent statement was independently checked before its author append. It is valid; the earlier moving-only result above is retained as its special case.

For S_x=Q_w(x), every y∈S_x satisfies S_x⊂Q_(2w)(y). If b_x=β(S_x)>0, then m(y)≥b_x throughout S_x and θ(y)≤τ/b_x. Consequently

\[
 \boxed{\beta_\theta(Q_w(x))\le\tau\quad\text{for EVERY receiver }x.}
\]

If b_x=0 the assertion is immediate. This new cap is proved for the extracted source; it is not falsely assigned to the original β.

Let actual nonnegative responses H_yj have the same compact support and unique-j receiver masks as above, but now satisfy ||H_yj||_p≤A_p for p>1. Put U_y=Σ_jH_yj. Its support implies U_y(x)≠0 only when y∈S_x. Pointwise Holder, followed by positive Tonelli and disjoint j masks, gives

\[
 \left|\int U_y(x)\,d\beta_\theta(y)\right|^p
 \le\tau^{p-1}\int U_y(x)^p\,d\beta_\theta(y),
\]
\[
 \boxed{\left\|\int U_y\,d\beta_\theta\right\|_p^p
 \le J_0A_p^p\tau^{p-1}W_\theta.}
\]

No source-coordinate independence or new posterior is introduced. For p=2 it recovers the already audited moving-source energy without an extra constant.

Retaining the actual common-leaf receiver mask, Holder in dx and the original C_out yield the general Young bound

\[
 \boxed{P_{\theta,p}\le\epsilon_pX+
 c_p C_{out}^pJ_0A_p^p
 \frac{\tau^{p-1}}{(\epsilon_p\lambda)^{p-1}}W_\theta,
 \quad c_p=\frac{(p-1)^{p-1}}{p^p}.}
\]

The constant follows by maximizing a s^((p−1)/p)−b s. Seed/leaf Holder is legitimate with the retained receiver support and the total extracted source mass. If that support is enlarged later, the actual receiver multiplicity must remain.

For J, R266 G12 supplies p=3/2 and A_p=A_J nlog2/4, uniformly in y,j. It includes the authentic fixed-time posterior/clock and inherits the same W_y support from the actual near mask. With the SAME θ and τ=λa^n/√J0, the J source coefficient can be written explicitly as

\[
 \frac{C_{out}^{3/2}}{\sqrt3\sqrt{\epsilon_J}}
 c_n^{3/4}M\left(\frac{n\log2}{4}\right)^{3/2}J_0^{3/4}
 \exp\left[-\frac{c_Jn}{2}+\frac{n\varepsilon}{2}
 (e^{c_J}\sqrt{2s_0}+s_0)\right].
\]

All powers of a cancel here: A_J^(3/2) contributes a^(−n/2), and (τ/λ)^(1/2) contributes a^(n/2)J0^(−1/4). The original C_out remains once, not another hardcap or weight comparison.

For fixed legitimate K, fixed low-soft constant C, s0=C logn/n≤1/2 and J0=O(n), this explicit coefficient is asymptotically smaller than the moving root-polylog coefficient. The tiny absolute c_J still governs a potentially enormous finite threshold; no numerical dominance at modest n is claimed. The explicit formula should be retained and any uniform asymptotic constant allowed to depend on the audited κ and fixed C,K.

Thus the SAME original soft-source θ allocation pays the two moving parts and J, so it pays the corresponding entire three-leg allocated current positive θ fraction. Its exact (1−θ) complement remains in ALL three parts. No negative credit is changed. The common error budget is essential: choose ε_mov+ε_J≤ε (for example ε/2 each); two separate Young applications each written as εX would instead cost 2εX. No further physical-kernel run was made for this additional analytic screen.
