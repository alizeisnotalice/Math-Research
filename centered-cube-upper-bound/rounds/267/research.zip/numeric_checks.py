#!/usr/bin/env python3
"""R267 target-only core / actual collar, finite exact source fraction checks."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp

def enc(x):return mp.nstr(x,80)
def mm(x):
 q=F(str(x));return mp.mpf(q.numerator)/q.denominator
def phi(u):
 u=abs(u)
 if u<=mp.mpf('.5'):return 1-mp.expint(3,mp.mpf('.5')-u)-mp.expint(3,mp.mpf('.5')+u)
 return mp.expint(3,u-mp.mpf('.5'))-mp.expint(3,u+mp.mpf('.5'))
def C(r):
 r=abs(r)
 if r<=1:return 1-r+mp.mpf(1)/3-mp.expint(4,r)-mp.expint(4,1)+mp.expint(4,r+1)
 return mp.expint(4,r-1)-2*mp.expint(4,r)+mp.expint(4,r+1)
def P(s,L,x):return ((1-s)*(1 if abs(x)<L/2 else 0)+s*phi(x/L))/L
def qint(f,a,b,knots):
 pts=sorted(set([a,b]+[k for k in knots if a<k<b]));return sum(mp.quad(f,[x,y]) for x,y in zip(pts,pts[1:]))
def menu():
 # l=xi/gamma is encoded by 'lower'; A='plus' means min(gamma*l,1).
 return [(8,'5/8','5/8','same','3/5','0','1/100'),(8,'5/8','9/16','plus','11/20','1/2','1/5'),(8,'3/4','3/4','plus','11/10','1/100','1/100'),(8,'5/8','1','same','0','1/2','1/5'),(64,'9/10','lower','same','root_minus','1/2','1/100'),(64,'9/10','lower','plus','root_plus','1/100','1/5'),(64,'31/32','1','same','1/1000000','0','1/100'),(64,'3/4','3/4','plus','2','1/2','1/5'),(512,'99/100','lower','plus','root_plus','1/2','1/100'),(512,'99/100','1','same','1/1000000','1/100','1/5'),(4096,'99/100','99/100','same','4','1/2','1/100'),(4096,'3/4','3/4','plus','3/5','0','1/5')]

def actual(dps,pilot=False):
 with mp.workdps(dps):
  c0=phi(mp.mpf('1.5'));rows=[]
  for n,xis,ls,As,rs,sigs,ss in menu()[:4] if pilot else menu():
   gamma=1+mp.mpf(1)/n;xi=mm(xis);l=xi/gamma if ls=='lower' else mm(ls);A=l if As=='same' else min(gamma*l,mp.mpf(1));sig,s=mm(sigs),mm(ss)
   if rs.startswith('root_'):
    root=mp.findroot(lambda r:C(r)-xi,(0,mp.mpf('.4')));r=root+(-1 if rs=='root_minus' else 1)*mp.mpf('1e-10')
   else:r=mm(rs)
   assert mp.mpf('.5')<=xi<=1-mp.mpf(2)/n and l>=xi/gamma and l<=A<=1
   epsilon=mp.mpf('.5')/(8*mp.sqrt(n));h=(1+epsilon)/2;cr=C(r);omega=min(mp.mpf(1),cr/l);active=cr<xi
   target=lambda x:P(sig,A,x-r);knots=[r-A/2,r+A/2]
   core=qint(target,-mp.mpf('.5'),mp.mpf('.5'),knots);collar=qint(target,-h,-mp.mpf('.5'),knots)+qint(target,mp.mpf('.5'),h,knots)
   sourcecollar=qint(lambda x:P(s,l,x),-h,-mp.mpf('.5'),[-l/2,l/2])+qint(lambda x:P(s,l,x),mp.mpf('.5'),h,[-l/2,l/2])
   T=core/omega;expanded=(core+collar)/omega;bound=1-(1-sig)*min(c0,mp.mpf('.25'))*(1-cr) if active else mp.mpf(1)
   assert T<=bound+mp.mpf('1e-30')
   rows.append({'stage':'initial' if n==8 else 'stress' if n==64 else 'expanded','n':n,'xi':enc(xi),'gamma':enc(gamma),'l':enc(l),'A':enc(A),'r_input':rs,'r':enc(r),'sigma':sigs,'source_s':ss,'epsilon':enc(epsilon),'C_r':enc(cr),'Omega':enc(omega),'active':active,'saturated':cr>=l,'target_core_integral':enc(core),'target_collar_integral':enc(collar),'source_anchor_collar_mass':enc(sourcecollar),'T_core':enc(T),'T_expanded':enc(expanded),'T_expanded_over_T_core':enc(expanded/T) if T else None,'core_bound':enc(bound),'core_margin':enc(bound-T),'tensor_log_T_core':enc(n*mp.log(T)) if T else '-inf','tensor_log_T_expanded':enc(n*mp.log(expanded)) if expanded else '-inf','tensor_log_core_bound':enc(n*mp.log(bound))})
  return {'c0':enc(c0),'cases':rows}

def source_fraction():
 beta=[F(0),F(1,10),F(2),F(10)];profiles=[('identity',[[F(i==j) for j in range(4)] for i in range(4)]),('common',[[F(1)] for _ in range(4)]),('mixed',[[F(1),F(0)],[F(0),F(1)],[F(1),F(1)],[F(1,2),F(1,2)]])];rows=[]
 for name,features in profiles:
  Adj=[[sum(a*b for a,b in zip(x,y)) for y in features] for x in features]
  assert all(Adj[i][j]==Adj[j][i]>=0 for i in range(4) for j in range(4))
  m=[sum(Adj[i][j]*beta[j] for j in range(4)) for i in range(4)]
  for tau in [F(1,100),F(1,2),F(2),F(10)]:
   theta=[min(F(1),tau/mi) if mi else F(1) for mi in m];lhs=sum(theta[i]*theta[j]*beta[i]*beta[j]*Adj[i][j] for i in range(4) for j in range(4));rhs=tau*sum(t*b for t,b in zip(theta,beta));assert lhs<=rhs
   rows.append({'profile':name,'tau':str(tau),'beta':list(map(str,beta)),'Gram_features':[[str(x) for x in row] for row in features],'Adj':[[str(x) for x in row] for row in Adj],'m':list(map(str,m)),'theta':list(map(str,theta)),'energy_exact':str(lhs),'bound_exact':str(rhs),'margin_exact':str(rhs-lhs)})
 return rows

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and k not in ['stage','r_input','sigma','source_s']:
    try:
     z=mp.mpf(v)
     if mp.isfinite(z):out[path+k]=z
    except ValueError:pass
   elif isinstance(v,(dict,list)):out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();low=actual(40);high=actual(70);exact=source_fraction()
 with mp.workdps(100):
  x=fields(low);y=fields(high);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);print('precision_diagnostic',worst,md,flush=True);assert diff[worst]<mp.mpf('1e-20')
 out={'schema':'R267-target-only-core-collar-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'actual_target_cases_per_precision':12,'actual_stages':{'initial':4,'stress':4,'expanded':4},'active_cases':sum(r['active'] for r in high['cases']),'saturated_cases':sum(r['saturated'] for r in high['cases']),'exact_source_fraction_cases':len(exact),'precision_fields_compared':len(diff)},'mp40':low,'mp70':high,'precision_max_relative_difference':md,'precision_worst_field':worst,'source_fraction_exact':exact,'scope':['Actual target-only continuous kernel integrals, b1,y0,L=l,A>=l,xi in[.5,1-2/n],l>=xi/gamma. Omega=min(1,C(r)/l). Explicit target hard jumps split core and collar integrals.','Active C(r)<xi uses core bound1-(1-sigma)min(phi(1.5),1/4)(1-C(r)); inactive tests only T<=1. These finite passing examples are ordinary40/70 mpmath, not directed intervals or universal proof.','Expanded window side1+epsilon,epsilon=.5/(8sqrt n), is measured separately: its target collar and source-anchor soft collar are paid outputs, never assumed to inherit core bound. Repeated n-dimensional log products are tools, not FULL qualifications.','Exact source-fraction checks use symmetric nonnegative Gram kernels on finite slots; they certify only the displayed thinned energy inequality. They do not pay the dense complement or claim a genuine continuous source construction/history/root bound.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst}))
if __name__=='__main__':main()
