#!/usr/bin/env python3
"""Exact finite diagnostics plus optional replay; no numerical proof claims."""
import argparse, hashlib, json, subprocess, sys, tempfile
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def exact():
    ys=[F(i,2) for i in range(4)]
    xs=[F(j,8) for j in range(-8,25)]; dx=F(1,8)
    masses=[[F(1),F(2),F(0),F(1)],[F(1,3)]*4,[F(0)]*4,[F(2),F(1,2),F(3),F(1,4)]]
    counts=dict(configurations=0,extraction=0,gram=0,local_cap=0,pointwise_holder=0,integrated_holder=0)
    for w in [F(1,2),F(1),F(3,2)]:
        kernel=[[F(abs(y-z)<=w) for z in ys] for y in ys]
        H=[[F(abs(x-y)<=w/2) for x in xs] for y in ys]
        A2=max(sum(dx*h*h for h in row) for row in H)
        for mass in masses:
            local=[sum(k*z for k,z in zip(row,mass)) for row in kernel]
            for tau in [F(1,4),F(2)]:
                theta=[min(F(1),tau/z) if z else F(1) for z in local]
                selected=[z*t for z,t in zip(mass,theta)]
                W=sum(selected); counts['configurations']+=1
                energy=sum(selected[i]*selected[j]*kernel[i][j] for i in range(4) for j in range(4))
                assert energy<=tau*W; counts['extraction']+=1
                response=[sum(selected[i]*H[i][j] for i in range(4)) for j in range(len(xs))]
                gram=sum(dx*u*u for u in response)
                assert gram<=A2*energy; counts['gram']+=1
                for j,x in enumerate(xs):
                    assert sum(selected[i] for i,y in enumerate(ys) if abs(x-y)<=w/2)<=tau
                    counts['local_cap']+=1
                    for p in (2,3):
                        assert response[j]**p<=tau**(p-1)*sum(selected[i]*H[i][j]**p for i in range(4))
                        counts['pointwise_holder']+=1
                for p in (2,3):
                    lhs=sum(dx*u**p for u in response)
                    rhs=tau**(p-1)*sum(selected[i]*sum(dx*h**p for h in H[i]) for i in range(4))
                    assert lhs<=rhs; counts['integrated_holder']+=1
    return counts

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--check-only', action='store_true'); args=parser.parse_args()
    manifest=json.loads((ROOT/'manifest.json').read_text())
    for name, digest in manifest['sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest, name
    counts=exact(); assert counts==manifest['exact_counts']
    print('Exact finite diagnostics PASS:',json.dumps(counts,sort_keys=True))
    if not args.check_only:
        with tempfile.TemporaryDirectory(prefix='r267-replay-') as td:
            target=Path(td)/'numeric.json'
            subprocess.run([sys.executable,str(ROOT/'numeric_checks.py'),'--output',str(target)],check=True)
            assert target.read_bytes()==(ROOT/'numeric_checks.json').read_bytes(), 'numerical replay differs'
        print('Stored numeric JSON: byte-identical replay PASS')
    else:
        print('Hashes and exact finite checks only; floating replay not run.')
if __name__=='__main__': main()
