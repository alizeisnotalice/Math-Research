r334_base=fileparts(mfilename('fullpath'));
r334_data=jsondecode(fileread(fullfile(r334_base,'r334_data.json')));
r334_candidates=struct('id',{},'exitflag',{},'x',{},'ratio',{},'iterations',{},'converged',{},'equality_residual',{},'lambda_equality',{});
r334_options=optimoptions('quadprog','Display','none');
for r334_k=1:numel(r334_data.cases)
    r334_case=r334_data.cases(r334_k);r334_c=0;r334_x=r334_case.x0(:);r334_converged=false;
    r334_K=(r334_case.K+r334_case.K')/2;
    for r334_iter=1:30
        [r334_x,~,r334_exit,~,r334_lambda]=quadprog(2*r334_K,-r334_case.a(:)+r334_c,[],[],r334_case.Aeq,r334_case.beq(:),zeros(numel(r334_case.a),1),[],r334_x,r334_options);
        if isempty(r334_x) || r334_exit<=0;break;end
        r334_F=r334_case.a(:)'*r334_x-r334_x'*r334_K*r334_x;
        r334_new=max(0,r334_F/sum(r334_x));
        if abs(r334_new-r334_c)<=1e-11*max(1,r334_new)
            r334_converged=true;r334_c=r334_new;break;
        end
        r334_c=r334_new;
    end
    r334_result=struct();r334_result.id=r334_case.id;r334_result.exitflag=r334_exit;
    r334_result.x=r334_x';r334_result.ratio=r334_c;r334_result.iterations=r334_iter;r334_result.converged=r334_converged;
    if isempty(r334_x);r334_result.equality_residual=NaN;else;r334_result.equality_residual=max(abs(r334_case.Aeq*r334_x-r334_case.beq(:)));end
    r334_result.lambda_equality=r334_lambda.eqlin';
    r334_candidates(end+1)=r334_result;
end
r334_file=fopen(fullfile(r334_base,'r334_solve_ratio_results.json'),'w');fwrite(r334_file,jsonencode(struct('candidates',r334_candidates)),'char');fclose(r334_file);
disp(struct('status','RATIO_CANDIDATES_WRITTEN','cases',numel(r334_candidates)));
