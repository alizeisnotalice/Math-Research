# R334 independent preauthor screen — two-way credit and finite fractional duality

Ownership only /tmp/r334_audit.md; no Git/other-author edits. Initial screen was completed before any R334 author proof/code was read. Original hard shared fields, same-source Tg=q, actual m=qR^n,dmu=du/m, full prefixes/ell and theta1 are fixed.

## 1. Joint two-direction allocation of the same edge credit

On the ordered region m_v>m_u set rho=m_v/m_u and d(rho)=(sqrt(rho)-1)^2/2. Choose measurable a,b in[0,1] JOINTLY satisfying a+rho b<=d. The small receiver potential integrates aS/q_u toward larger neighbors; the large receiver potential integrates bS/q_v toward smaller neighbors. Adding them gives one receiver function. At each receiver its two neighbor classes are disjoint and the coefficient on either class is<=1; row subcapacity and inclusive R^-n tail give0<=zeta<=1, not an unjustified sum bound2. It is L1 on finite E and independent of the tested source point.

Its exact bill P=integral ell ordered S[m_u a+m_v b]dmu_udmu_v<=D, where D=integral ell ordered m_u d(rho)S. Its adjoint is the TWO oriented cut fractions a c_u(1-c_v)+b c_v(1-c_u), plus the common-capture coefficient(a+b)c_uc_v. The common coefficient a+b may exceed1, which is allowed because both actual receiver potentials are billed; the cut fractions themselves remain<=1 in their respective directions. Equal-mass pairs have zeroD and are left unpaid.

For a=min(1,d), b=(d-a)/rho, b>=0 and b<1/2<1. If d<=1 only the old small-capture orientation is paid fractionally; above that threshold a1 and the former residual credit pays reverse fractionb. a+rho b=d EXACTLY, so P=D over all unequal-mass edges. Thus new bill-L-D+P=-L, and the available further credit is onlyL, not oldD. The overlap and reverse improvements are not free or extra disjoint original-traffic charges. This is a settlement within the auxiliary full-square source defect; fit/ties/remaining reverse fraction and original entry/source/history/general-soft obligations remain. Full-feature application retains the existing lambda H source-completion fee once.

## 2. Finite ratio cone, compactness and zero pattern

For a finite actual source-face incidence model let C be binary receiver-vs-source-PATTERN matrix, with every retained column nonzero. Preserve original selected receiver means Cx=m>0, x>=0. Each x_j<=min_(i:Cij1)m_i<=maxm, and maxm<=W=sumx<=summ because every column contains at least one1. The feasible set is a nonempty compact polytope if the original source is feasible; ratio F(x)/W is continuous and attains a maximum. Here F=a_H*x-x^T K_all x, with the original FULL normalized Gram K and high linear coefficient, not the original one-sided BH itself. Every column must correspond to a positive-volume actual source pattern to reconstruct an L1 source; the real receiver measure remains finite quadrature unless separately certified as dx.

Deleting the allzero pattern is legitimate for positive-ratio maximization: it changes neither F nor Cx and only increases W when included. If ALL nonzero-pattern ratios are negative, the full cone with arbitrary zero-pattern mass has supremum0 approached from below, NOT that negative maximum. The desired nonnegative coefficient is max(0,active ratio maximum); c0 case can use maxF<=0 as below. No claim the zero-pattern mass should be silently discarded when evaluating a fixed original input's W.

For candidatec, phi(c)=max_(polytope)(F-cW) has its unique zero at the active ratio maximum. Exact feasible sources give primal ratio lower bounds; certified source/potential inequalities give upper bounds. A floating parametric QP objective/termination is not such a proof. The parametric QP is convex minimization of xKx-(a_H-c1)x with fixed means and variableW; there is no fixed-W equality. No infinite-dimensional optimization theorem or continuum convergence follows from the finite model.

## 3. Exact finite optimizer-to-zero-bill potential bridge

If c*>0 and x* maximizes F/W, then it maximizes F-c*W with value0. First-order concavity and the finite polytope normal cone (equivalently finite LP dual of the gradient) yield a row multiplier vector lambda with

 a_H-2Kx*-c*1<=C^T lambda,
 equality on every positive x*_j.

Multiplying by x* gives lambda*m=F(x*)-c*W-Q(x*)=-Q(x*). This is a finite differentiable/LP argument, not infinite strong duality. For GENERAL receiver q_i, the corresponding physical potential is

 psi_i=lambda_i/(mu_i q_i)=lambda_i R_i^n/w_i,

since T*psi= sum_i(w_i/R_i^n)psi_i C_i=C^Tlambda and sum_iw_iq_i psi_i=lambda*m. The simpler psi=lambda/mu is valid ONLY in the current q1 numeric fixtures. Therefore Q(x*)+sum wq psi=0 exactly. With h=Phi x*, this is the original zero-X-budget tangent certificate. If using R333 d_h=a_H+T*1-2hphi, the LP variable is zeta=1+psi, not psi. Outside all cubes/pattern0, a_H=0 and(Kx*)_zero=0, so -c*<=0 closes the missing source complement.

If active optimal ratio<=0, maximize F instead. Its maximum is<=0 and a finite normal-cone multiplier gives lambda*m=F(x*)-Q(x*), so Q+sumwqpsi=F(x*)<=0 and c0 is feasible. This covers the zero/negative case without pretending a negative active ratio is the full cone optimum. At actual numerical candidates, exact primal repair and pointwise/budget repair remain necessary; optimizer existence does not certify a floating candidate. The resulting relaxed coefficientc plus lambda H completion bounds BH; actual one-sided BH/W and relaxed F/W must be reported as DIFFERENT primal quantities if both are computed.

## 4. Actual independent bounded diagnostics

Reviewer executed209 Fraction assertions: {'two_way': 56, 'source_directions': 112, 'ratio_identity': 33, 'KKT': 4, 'physical_potential': 4}. Exact unequal square masses verify both directions and joint credit; an explicit finite PSD fractional example has F-cW=-3(t-1/2)^2 and optimumc7/8, with exact finite normal-cone multipliers. A nonconstant q=(3/4,1) checks the CORRECT physical multiplier factor1/(mu*q). These are algebra models, not actual cube/history/continuum or general-root evidence. At that independent-screen stage no author R334 file/code had been read.

Initial verdict PASS with the nonnegative-coefficient/zero-pattern and general-q mapping qualifications above. Await authors.

## 5. Finite fractional theorem comparison

Read complete /tmp/r334_fractional.md after independent screen. PASS. The nonzero positive-volume signature domain is a nonempty compact polytope, and ratio denominator is bounded below. The full cone's nonnegative optimum c*=max(0,r*) correctly handles free zero-signature mass; the zero pattern is still constrained by the final pointwise certificate. Parametric residual signs are correct. The finite gradient-LP/normal-cone argument requires no infinite strong duality or Slater premise. At r*>0 it yields lambda*m=-Q(x*); when r*<=0, maxF<=0 yields the stated nonpositive receiver bill atc0. The general-q physical multiplier map is correctly lambda/(mu*q), not the earlier q1-only simplification.

The weak certificate lower/upper directions and exact gap are correct: cW-F=sum s_jx_j+||Phi x-h||²-bill. Every term is nonnegative for a feasible zero-budget certificate. Its near-extremizer interpretation applies on the compact nonzero-pattern polytope, or whenever the actual ABSOLUTE gap is small; adding unbounded zero-pattern mass to approach a nonpositive full-cone ratio does not create a new Euclidean/source-concentration theorem. The text asserts no dimension-uniform stability.

Primal ratio lower bound uses F_lower/W and max0, not a numerical optimum; repaired common-potential certificates give upperc. These bracket the FINITE RELAXED coefficient, not the exact original BH optimum. Original one-sided BH must be separately evaluated, and the lambda H completion remains when converting a relaxed upperc to the original traffic. Each pattern mass must retain an actual positive-volume L1 realization and selected receiver means; finite receivers remain quadrature. No generally root coefficient follows from this equivalence.

SHA256 /tmp/r334_fractional.md: d9494d7b55d45569d2d71429ddb43086ee324eda25d82c2c9b71c0008b833697


## 6. Frozen two-direction author comparison

Read the complete final `/tmp/r334_aux.md`, including its priority clarification. PASS. The combined receiver function is bounded by ONE via disjoint neighbor orientation classes; it is not a sum of two separately bounded functions. The ordered/unordered Dirichlet factors, general-q adjoint, exact P bill, cut/overlap, equal-mass complement and remaining L+D-P are correct. Canonical a-first spends all unequal-edge D while retaining the old directed cut and adding a reverse fraction. Reverse-only versus a-first trades integrated cut against exactly the same overlap, with no net free full-source credit. The prescribed-priority optimizer maximizes its integrated objective only; it need not dominate each source point or preserve payments outside that priority region. Final wording now states this correctly. Its 2,068 reported author Fraction checks are algebra diagnostics, not literal-cube or root evidence; they are not added to the reviewer's independent 209 checks.

## 7. Complete finite numerical pipeline and result review

Read ALL of `/tmp/r334_numeric.py`, both MATLAB scripts, the frozen numeric notes, and checkpoint summary/results metadata. PASS for the stated finite receiver-quadrature model. The complete positive-volume source face partition is enumerated, all nonzero signatures are retained for the variable-mass ratio problem, and the zero signature remains in the final pointwise constraints. The mean matrix contains Cx=m ONLY, with no old fixed-W constraint. The exact RREF correction preserves all receiver means; mixing with the positive original nonzero-pattern masses removes any corrected negative masses while preserving means. W is recomputed and is not silently restored to the old input mass.

The floating parametric QPs minimize xKx-a*x+cW with correct sign and produce candidates only. The common-potential LP also has correct constraint and budget signs. Exact sqrt enclosures construct a rational h below the true source feature coordinatewise, evaluate its norm exactly, and bound source coverage from below, so d_upper really dominates the source defect. A distinct norm upper bound gives F_lower for the repaired actual source. The common rational potential is shifted DOWN uniformly when its receiver bill exceeds credit; then c is the maximum exact source residual over ALL source signatures and zero. This repairs both the common budget and every source point constraint, not just the optimized source's support. The exact integrated inequalities, original one-sided BH computation, and lambda H completion have the correct directions.

The checkpoint summary records 114 exact postrepair assertions for six cases after the parent's actual independent replay of 18 QPs plus 6 LPs. I reviewed code/results without repeating that full replay. At H0 the finite RELAXED ratio gaps are approximately 1.4631e-8, 4.7091e-10, 3.5734e-9 in dimensions 1,2,3. These are not optimality gaps for the original BH ratio; its separately evaluated values are smaller. At H1/8 the near-zero upper relaxed coefficients in dimensions 2,3 are positive rational certificates, not an exact proof that the relaxed optimum is nonpositive. The original BH upper retains completion H. Finite source L1 realization does not turn receiver quadrature into true dx or certify old history/lowpe/root scope.

The appended weighted near-extremizer corollary in `/tmp/r334_fractional.md` is valid: cW-F<=delta W and the nonnegative exact gap components imply mass of {s>=tau} <=delta W/tau and feature distance squared <=delta W. Zero-pattern residual is c. It does not authorize dropping any original source mass, infer Euclidean concentration, or give a dimension-uniform stability theorem.

## 8. Current binding; awaiting the separate main core/ledger

The preceding reviews find no material mathematical or certificate-direction error in these frozen files. This is not the final all-input root budget; the comparable-mass/main core and final integration are not yet reviewed in this receipt.

SHA256 bindings (read-only; parent replay evidence distinguished above):

- `/tmp/r334_aux.md`: `cd48b0ba5794cb69ec616116c9b8f4f647ef0b18a97f97b302733bf3fd38207e`
- `/tmp/r334_fractional.md`: `d9494d7b55d45569d2d71429ddb43086ee324eda25d82c2c9b71c0008b833697`
- `/tmp/r334_numeric.py`: `b0970a1ea2fe5890bb951baca54737b3d5e297c4254042b11f03010b6f699ae6`
- `/tmp/r334_numeric.md`: `f10bde3f601b31f4be87d799a6c8a356ef9ad9cfb2d826d4ad135b7ec150b070`
- `/tmp/r334_solve_ratio.m`: `aea2a8ced36b790f7955b172eb316a37b213f8b87cda89c6c2d95f05972baa96`
- `/tmp/r334_solve_lp.m`: `f8d0d88cd372a4f199b131f73dd741c8883a0c25d41f9656e3a5d88188f3e851`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round334_20261018_final_checkpoint/r334_numeric_summary.json`: `a34ab35b3d75f6eb107dd2a41ac08e304d0c2b0bd154a2805636babdbc5ef186`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round334_20261018_final_checkpoint/r334_numeric_verified.json`: `8a54dad260e8f3f5fa4ffff976763ef02bc9c88487b4ea8dbabc2441578c8a64`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round334_20261018_final_checkpoint/r334_solve_ratio_results.json`: `05c520a0802082fae0d5b5b0ce00807768ae79201b739f2ba7b42fab012b2ad0`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round334_20261018_final_checkpoint/r334_solve_lp_results.json`: `6fa145f2911a08bac656de15d4785c7a8d6b14292283350bbd675606929f5436`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round334_20261018_final_checkpoint/r334_data.json`: `03f85a16acd1d83ba9b61225a584fe59145464fbfa65bab7a944470e564462b1`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round334_20261018_final_checkpoint/r334_data_lp.json`: `442ec3f5c66af3716ccc2d9c5f1ece3d24b7279fd80f06cac61b042e88b6fa14`


## 9. Main ledger comparison before core completion

Read complete `/tmp/r334_ledger.md` against the preceding frozen R333 ledger/contract. The original positive entrance coefficients 8lambda H Wbeta+2d_eff An/H Wnu+2BH match. The new full-slot weak-dual bound must replace the ENTIRE BH, retaining these explicit entrance terms and its lambda H completion; neither an H0 experiment nor a paid old subblock authorizes removing them. With Lambda128/119 and epsilon_CZ119/65536 the recorded 2Lambda epsilon_CZ=1/256 is exact. The stated condition1/256+2Lambda sum epsilon_j<1 is only a remaining budget check, not a proved total absorption. A core fit reduction must recompute its reference bill and compatible edge payments, rather than add their separately optimized receipts.

The ledger explicitly retains continuous/small hard innovations, dense general-soft whole crossing and later innovations, near-equal/reverse cuts and fit, heavy-source joint geometry, broad-distance/lowpe/extreme-aspect complements, chronological I_time/J_time/D_time, suffix/Phi_next credits, and all physical-scale/outer source ledgers. It makes no general closure claim. This bounded review checks continuity with the previous frozen ledger, not an independent reconstruction of every historical coefficient. Recommended editorial contract clarification: state Tf=q, q range, finiteE and finite octave explicitly; the same-source order alone is not the symmetric hard Gram contract. Await final core and the final ledger bytes before final binding.


## 10. Final occupancy-adapted core review

Read complete final `/tmp/r334_core.md` after the independent screen, with the R331 feature/decomposition checked directly. PASS. The actual row occupancy k is the essential supremum against the ORIGINAL ell restricted to [R(u),b], including its terminal atom. Its measurable construction yields one r-independent theta=sqrt(k), so the inclusive-tail receiver budget remains valid. The Cauchy step bounds the inner sqrt(S) capture integral by sqrt(J*a_r(u)); multiplying by eta*sqrt(m) and using a_r<=k*m gives <h_eta,phi_y><=T*(eta*sqrt(k)). Zero source rows contribute zero and joint exceptional sets are controlled by positive Fubini. The exact perturbation then gives d_theta-d_1<=-T*(eta²). This is an upper Cauchy fit comparison, not an assumed lower correlation. The same-S escape and l_H are unchanged, so the asserted integrated fit decrease follows.

The comparable-mass orientation by theta, min(1,(theta_v sqrt(m_v)-theta_u sqrt(m_u))²/(2m_u)), correctly pays its actual directed cut and positive overlap with ONE common receiver potential. Its transpose is disjoint, so its bill P<=D_theta has the correct factor. Equal masses can be paid only when actual theta contrast exists. No quantitative prevalence of that contrast is proved. Saturated couplings, zero essential slack infimum, or equal occupancies can remove the gain.

Crucially, formula(10) has ALL bills: the original full-row square via the Hilbert tangent, the recomputed -L_theta-D_theta+P, and the existing low-row completion lambda H W_f ONCE. It does not preserve the old theta1 negative credit. The source-profile improvement is therefore a valid particular-candidate improvement, not an improvement of the exact integrated quadratic optimum for the fixed source, a general root bound, or permission to add the aux allocation again. The same-source S0+tX family is feasible; h_t>=G gives the stated additional nonnegative Delta_t, with no unproved target-activation claim. Its 720 reported 70-digit Decimal diagnostics remain distinct from exact assertions and from actual cube/receiver-dx evidence; I did not rerun them or count them in primary114.

## 11. Final ledger and bounded audit verdict

Read the final ledger bytes after the explicit hard-matched interface was added. The editorial contract concern in section9 is resolved: Tf=q, actual du, q range, finite E, finite octave, beta=f and nu<=f are now stated; the text expressly says source order alone does not give the hard Gram identity. Main core and aux use the same available credits and are choices/recomputed joint constructions, never mechanically additive. Finite ratio gaps remain gaps for the PSD RELAXATION, with original BH separately evaluated and lambda H completion retained. No constant-size/root claim is inferred from the dimensions1/2/3 experiments.

FINAL BOUNDED VERDICT: PASS for the specified analytic statements, finite code/certificate scope, and continuity of this ledger with the preceding frozen account. No outstanding correction was found in the reviewed final files. The complete general weak-type root bound remains UNPROVED, for the explicit unpaid terms retained in the ledger. This audit is not a re-certification of every older historical lemma or coefficient, and does not claim a TeX/PDF compilation or a word-for-word review of subsequently typeset research.tex. No Git or other author's files were modified. No full numerical pipeline was repeated by this reviewer.

Execution attribution: reviewer209 independent exact algebra assertions; parent18 QP+6 LP and114 exact rational postrepair assertions; aux2068 exact algebra and core720 Decimal checks reported by their authors. These are separate evidence scopes, not a combined actual-kernel test count.

Final additional SHA256 bindings:

- `/tmp/r334_core.md`: `8faeab080801cb46f7c8012a5f864c3d867164b5f5c060904361bfdda8a838c0`
- `/tmp/r334_aux.md`: `cd48b0ba5794cb69ec616116c9b8f4f647ef0b18a97f97b302733bf3fd38207e`
- `/tmp/r334_fractional.md`: `d9494d7b55d45569d2d71429ddb43086ee324eda25d82c2c9b71c0008b833697`
- `/tmp/r334_ledger.md`: `807f37a96e59cc7e1d713516962b52da7707149899ea9a87241f67eb706903a0`
- `/tmp/r334_numeric.py`: `b0970a1ea2fe5890bb951baca54737b3d5e297c4254042b11f03010b6f699ae6`
- `/tmp/r334_numeric.md`: `f10bde3f601b31f4be87d799a6c8a356ef9ad9cfb2d826d4ad135b7ec150b070`
- `/tmp/r334_solve_ratio.m`: `aea2a8ced36b790f7955b172eb316a37b213f8b87cda89c6c2d95f05972baa96`
- `/tmp/r334_solve_lp.m`: `f8d0d88cd372a4f199b131f73dd741c8883a0c25d41f9656e3a5d88188f3e851`

Final receipt frozen after the above file-level review; previous awaiting-core wording is historical and superseded by sections10–11.
