#!/usr/bin/env python3
"""Portable finite actual-source ratio search and exact shared-potential certificate."""
from fractions import Fraction as F
from pathlib import Path
from itertools import product
from math import isqrt,sqrt
import json,sys,hashlib
BASE=Path(__file__).resolve().parent

def sqrtbox(x,bits=80):
 scale=1<<bits;k=isqrt((x.numerator*scale*scale)//x.denominator);return F(k,scale),F(k+1,scale)
def load(name):return json.loads((BASE/name).read_text())
def save(name,value):(BASE/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def fixtures():
 return [('initial',1,[((F(-1,4),),F(1),F(1,5)),((F(1,4),),F(3,2),F(1,5))]),('stress',2,[((F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(-1,2)),F(1),F(1,10)),((F(1,2),F(1,2)),F(3,2),F(1,5)),((F(0),F(0)),F(2),F(1,10))]),('expanded',3,[((F(-1,2),F(0),F(0)),F(1),F(1,10)),((F(0),F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(0),F(1,2)),F(3,2),F(1,10)),((F(1,2),F(1,2),F(0)),F(3,2),F(1,10)),((F(0),F(0),F(0)),F(2),F(1,10))])]
def source_groups(n,recv):
 axes=[sorted(set([F(-2),F(2)]+[x[a]+sign*r/2 for x,r,w in recv for sign in [-1,1]])) for a in range(n)];groups={};cells=0
 for ids in product(*[range(len(p)-1) for p in axes]):
  B=[(axes[a][i],axes[a][i+1]) for a,i in enumerate(ids)];mass=F(1)
  for lo,hi in B:mass*=hi-lo
  sig=tuple(int(all(lo>=x[a]-r/2 and hi<=x[a]+r/2 for a,(lo,hi) in enumerate(B))) for x,r,w in recv)
  for c,(x,r,w) in zip(sig,recv):assert c or any(hi<=x[a]-r/2 or lo>=x[a]+r/2 for a,(lo,hi) in enumerate(B))
  groups[sig]=groups.get(sig,F(0))+mass;cells+=1
 assert sum(groups.values())==4**n
 return sorted(groups),groups,cells

def prefix_data(recv,sigs,H):
 n=len(recv[0][0]);mi=[r**n for x,r,w in recv];w=[w for x,r,w in recv];mu=[a/b for a,b in zip(w,mi)];rs=sorted(set(r for x,r,w in recv));out=[];a=[F(0)]*len(sigs)
 for k,r in enumerate(rs):
  ell=r**(-n)-(rs[k+1]**(-n) if k+1<len(rs) else 0);active=[i for i,(x,t,w) in enumerate(recv) if t<=r];J=[sum(mu[i]*c[i] for i in active) for c in sigs];V=[sum(w[i]*c[i] for i in active) for c in sigs]
  for j,(jj,v) in enumerate(zip(J,V)):
   if jj>=H:a[j]+=ell*v
  out.append((ell,active,J,V))
 return mi,w,mu,out,a

def actual_B(recv,sigs,masses,H):
 mi,w,mu,prefix,a=prefix_data(recv,sigs,H);answer=F(0)
 for ell,active,J,V in prefix:
  I={(i,j):sum(m*c[i]*c[j] for m,c in zip(masses,sigs)) for i in active for j in active}
  answer+=ell*sum(m*(v-sum(mu[i]*mu[j]*c[i]*c[j]*I[i,j] for i in active for j in active)/jj) for m,c,jj,v in zip(masses,sigs,J,V) if jj and jj>=H)
 return answer

def prepare():
 cases=[]
 for name,n,recv in fixtures():
  sigs,groups,cells=source_groups(n,recv);nonzero=[c for c in sigs if any(c)];original=[groups[c] for c in nonzero];N=len(recv)
  for H in [F(0),F(1,8)]:
   mi,w,mu,prefix,a=prefix_data(recv,nonzero,H);features=[[] for c in nonzero]
   for ell,active,J,V in prefix:
    for k,c in enumerate(nonzero):features[k].extend([sqrt(float(ell*mu[i]*mu[j]))*c[i]*c[j]/sqrt(float(J[k])) if J[k] else 0.0 for i in active for j in active])
   K=[[sum(x*y for x,y in zip(row,col)) for col in features] for row in features]
   for i in range(N):assert sum(m*c[i] for m,c in zip(original,nonzero))==mi[i]
   assert all(any(c) for c in nonzero) and sum(original)>=max(mi)
   cases.append(dict(id=f'{name}_H{H}',n=n,H=str(H),receivers=[dict(center=list(map(str,x)),radius=str(r),weight=str(ww)) for x,r,ww in recv],source_cell_count=cells,all_signatures=[list(c) for c in sigs],all_original_masses=[str(groups[c]) for c in sigs],signatures=[list(c) for c in nonzero],original_nonzero_masses=list(map(str,original)),m_i=list(map(str,mi)),K=K,a=list(map(float,a)),a_exact=list(map(str,a)),Aeq=[[float(c[i]) for c in nonzero] for i in range(N)],beq=list(map(float,mi)),x0=list(map(float,original)),original_BH=str(actual_B(recv,sigs,[groups[c] for c in sigs],H)),original_W=str(4**n),ratio_polytope='Cx=m only; no fixed W, zero signature excluded only in ratio variables'))
 save('r334_data.json',dict(cases=cases,scope='Actual compact L1 source full face partition; discrete receiver quadrature. Full source signatures including0 remain for subsequent certificate.'))
 print(json.dumps(dict(status='PREPARED',cases=len(cases),nonzero_patterns=[len(c['signatures']) for c in cases])))

def repair_source(raw,sigs,original,mi):
 x=[F(str(max(0.0,float(v)))).limit_denominator(10**8) for v in raw];N=len(mi);A=[[F(c[i]) for c in sigs] for i in range(N)];aug=[row+[m-sum(a*v for a,v in zip(row,x))] for row,m in zip(A,mi)];rr=0;piv=[]
 for col in range(len(x)):
  found=next((i for i in range(rr,N) if aug[i][col]),None)
  if found is None:continue
  aug[rr],aug[found]=aug[found],aug[rr];factor=aug[rr][col];aug[rr]=[v/factor for v in aug[rr]]
  for i in range(N):
   if i!=rr:
    factor=aug[i][col];aug[i]=[u-factor*v for u,v in zip(aug[i],aug[rr])]
  piv.append(col);rr+=1
  if rr==N:break
 for row in aug[rr:]:assert row[-1]==0
 for i,col in enumerate(piv):x[col]+=aug[i][-1]
 mix=max([F(0)]+[-v/(o-v) for v,o in zip(x,original) if v<0]);mix=min(F(1),mix+F(1,2**40)) if mix else F(0);x=[(1-mix)*v+mix*o for v,o in zip(x,original)]
 assert all(v>=0 for v in x)
 for i in range(N):assert sum(v*c[i] for v,c in zip(x,sigs))==mi[i]
 assert sum(x)>=max(mi)>0
 for v,c in zip(x,sigs):assert v<=min(m for m,ci in zip(mi,c) if ci)
 return x,mix

def prepare_lp():
 data=load('r334_data.json');raw=load('r334_solve_ratio_results.json');by={c['id']:c for c in raw['candidates']};cases=[];sourcecert=[]
 for old in data['cases']:
  cand=by[old['id']];assert cand['exitflag']>0
  recv=[(tuple(map(F,r['center'])),F(r['radius']),F(r['weight'])) for r in old['receivers']];sigs=[tuple(c) for c in old['signatures']];orig=list(map(F,old['original_nonzero_masses']));mi=list(map(F,old['m_i']));x,mix=repair_source(cand['x'],sigs,orig,mi);W=sum(x);allc=[tuple(c) for c in old['all_signatures']];fullorig=list(map(F,old['all_original_masses']));xby=dict(zip(sigs,x));allx=[xby.get(c,F(0)) for c in allc];H=F(old['H']);mi,w,mu,prefix,a=prefix_data(recv,allc,H);T1=[sum(mu[i]*c[i] for i in range(len(recv))) for c in allc];coverage=[F(0)]*len(allc);norm=normU=F(0)
  for ell,active,J,V in prefix:
   h={(i,j):sum((v*c[i]*c[j]/sqrtbox(jj)[1] for v,c,jj in zip(allx,allc,J) if jj),F(0)) for i in active for j in active};hu={(i,j):sum((v*c[i]*c[j]/sqrtbox(jj)[0] for v,c,jj in zip(allx,allc,J) if jj),F(0)) for i in active for j in active};norm+=ell*sum(mu[i]*mu[j]*h[i,j]**2 for i in active for j in active);normU+=ell*sum(mu[i]*mu[j]*hu[i,j]**2 for i in active for j in active)
   for k,(c,jj) in enumerate(zip(allc,J)):
    if jj:coverage[k]+=ell*2*sum(mu[i]*mu[j]*c[i]*c[j]*h[i,j]/sqrtbox(jj)[1] for i in active for j in active)
  linear=sum(v*z for v,z in zip(allx,a));Flo=linear-normU;Fhi=linear-norm;lower=max(F(0),Flo/W);upper=max(F(0),Fhi/W);d=[z+t-c for z,t,c in zip(a,T1,coverage)];X=sum(w);credit=X-norm;BH=actual_B(recv,allc,allx,H)
  assert all(t-z<=H for t,z in zip(T1,a))
  cases.append(dict(id=old['id'],n=old['n'],H=str(H),weights=list(map(str,w)),credit=str(credit),norm=str(norm),X=str(X),source=[dict(signature=list(c),mass_original=str(m),d_upper=str(v),T_coeff=[str(mu[i]*c[i]) for i in range(len(w))]) for c,m,v in zip(allc,fullorig,d)],solver_weights=list(map(float,w)),solver_credit=float(credit),solver_d=list(map(float,d)),solver_T=[[float(mu[i]*c[i]) for i in range(len(w))] for c in allc]))
  sourcecert.append(dict(id=old['id'],x_exact=list(map(str,x)),signatures=[list(c) for c in sigs],mi=list(map(str,mi)),W_exact=str(W),source_mix=str(mix),F_lower_exact=str(Flo),F_upper_exact=str(Fhi),positive_ratio_lower_exact=str(lower),positive_ratio_at_candidate_upper_exact=str(upper),actual_BH_exact=str(BH),actual_BH_over_W_exact=str(BH/W),original_BH_exact=old['original_BH'],original_W=old['original_W'],numerical_ratio_candidate=cand['ratio'],iterations=cand['iterations'],numerical_converged=cand['converged'],scope='Exact source Cx=m and nonnegative; W free. F/W bracket concerns PSD relaxation, not actual BH/W.'))
 save('r334_data_lp.json',dict(cases=cases,source_certificates=sourcecert));print(json.dumps(dict(status='LP_PREPARED',cases=len(cases),all_patterns_including_zero=[len(c['source']) for c in cases])))

def verify():
 data=load('r334_data_lp.json');by={c['id']:c for c in load('r334_solve_lp_results.json')['candidates']};certby={c['id']:c for c in data['source_certificates']};out=[];checks=0
 for case in data['cases']:
  raw=by[case['id']];assert raw['exitflag']>0
  z=[F(str(float(v))).limit_denominator(10**8) for v in raw['zeta']];w=list(map(F,case['weights']));credit=F(case['credit']);budget=sum(a*b for a,b in zip(w,z));delta=max(F(0),(budget-credit)/sum(w));z=[v-delta for v in z];budget=sum(a*b for a,b in zip(w,z));assert budget<=credit;checks+=1
  c=max([F(0)]+[F(s['d_upper'])-sum(F(a)*b for a,b in zip(s['T_coeff'],z)) for s in case['source']]);assert c>=0;checks+=1
  for s in case['source']:assert F(s['d_upper'])<=c+sum(F(a)*b for a,b in zip(s['T_coeff'],z));checks+=1
  sc=certby[case['id']];x=list(map(F,sc['x_exact']));sigs=[tuple(s) for s in sc['signatures']];mi=list(map(F,sc['mi']));W=F(sc['W_exact']);H=F(case['H']);xm=dict(zip(sigs,x));integrated=sum(xm.get(tuple(s['signature']),F(0))*F(s['d_upper']) for s in case['source']);assert integrated<=c*W+budget;checks+=1
  assert F(sc['F_lower_exact'])<=integrated-credit<=c*W;checks+=1
  assert F(sc['actual_BH_exact'])<=(c+H)*W;checks+=1
  # Complete source-cone mean identity used by the budget, no fixed mass equation.
  assert all(sum(v*s[i] for v,s in zip(x,sigs))==mi[i] for i in range(len(mi)));checks+=1
  lower=F(sc['positive_ratio_lower_exact']);assert lower<=c;checks+=1
  zero=[s for s in case['source'] if not any(s['signature'])];assert len(zero)==1 and F(zero[0]['d_upper'])==0;checks+=1
  out.append(dict(id=case['id'],n=case['n'],H=case['H'],c_upper_exact=str(c),positive_F_over_W_lower_exact=str(lower),gap_exact=str(c-lower),c_upper=float(c),positive_F_over_W_lower=float(lower),gap=float(c-lower),actual_BH_over_W_exact=sc['actual_BH_over_W_exact'],actual_BH_over_W=float(F(sc['actual_BH_over_W_exact'])),completion_H=float(H),BH_ratio_certificate_upper=float(c+H),source_W_exact=sc['W_exact'],source_mix=sc['source_mix'],zeta_exact=list(map(str,z)),budget_exact=str(budget),credit_exact=str(credit),repair_delta=str(delta),iterations=sc['iterations'],numerical_converged=sc['numerical_converged'],scope='Relaxed positive F/W lower versus common-potential upper c; not lower/upper for original BH/W.'))
 summary=dict(status='PASS',exact_postrepair_checks=checks,cases=out,source_data_sha256=hashlib.sha256((BASE/'r334_data_lp.json').read_bytes()).hexdigest(),scope='Finite actual-cube receiver quadrature. Original physical prefixes retained; source cone Cx=m,Wfree; zero pattern excluded only from ratio variables and included in certificate. No general root/history/continuum receiver proof.')
 save('r334_numeric_verified.json',summary)
 small=dict(status='PASS',exact_postrepair_checks=checks,verified_certificate_sha256=hashlib.sha256((BASE/'r334_numeric_verified.json').read_bytes()).hexdigest(),cases=[{k:v[k] for k in ['id','n','H','positive_F_over_W_lower','c_upper','gap','actual_BH_over_W','completion_H','BH_ratio_certificate_upper','iterations','numerical_converged']} for v in out],scope=summary['scope'])
 save('r334_numeric_summary.json',small);print(json.dumps(small,sort_keys=True))
if __name__=='__main__':
 if '--prepare-lp' in sys.argv:prepare_lp()
 elif '--verify' in sys.argv:verify()
 else:prepare()
