# R334 — jointly funded two-direction edge allocation

**Paid scope.** The R333 one-direction allocation extends to a single two-direction receiver potential. A specific allocation retains every old paid point and spends the old unused edge credit on a positive fraction of the reverse cut. The remaining scalar credit is reduced accordingly. Actual source-overlap masses also give an explicit measurable optimal orientation for a prescribed source-priority region. These are paid portions of the same full-square defect, not a general root bound. Equal-mass edges and the fit error remain unclosed.

## 1. Actual contract and admissible joint allocation

Use the unchanged hard-matched R333 core contract and its actual symmetric row-subcapacity coupling `S_r(u,v)`. In particular

\[
 m_u=q(u)R(u)^n,\quad d\mu(u)=1_E(u)du/m_u,\quad
 a_r(u)=\int_{E_r}S_r(u,v)d\mu(v)\le m_u,
\]

`q∈[3λ/4,λ]`, `E_r=E∩{R≤r}`, and the full original
`ell=b^-nδ_b+nr^-n-1dr`. Write `dξ=ell(dr)1_(u,v∈E_r)dμ(u)dμ(v)`. Preserve all original prefixes and selector masks. No new source or history reset is introduced.

Orient unequal edges by

\[
 \Omega=\{(u,v):m_u<m_v\},\quad \rho=m_v/m_u>1,\quad
 d(\rho)=\tfrac12(\sqrt\rho-1)^2.
\]

Choose jointly measurable `a=a(r,u,v), b=b(r,u,v)` on `Ω` satisfying

\[
 0\le a,b\le1,\qquad a+\rho b\le d(\rho).                   \tag{1}
\]

Here `a` is paid at the smaller endpoint and `b` at the larger endpoint. These edge coefficients are unrelated to the physical lower radius `a` in the contract. Equal-mass edges receive zero coefficients.

On ordered receiver arguments define `κ_r(u,v)=a(r,u,v)` for `m_u<m_v`, `κ_r(u,v)=b(r,v,u)` for `m_v<m_u`, and zero on ties. Set the ONE common potential

\[
 \zeta(u)=\frac1{q(u)}\int_{[R(u),b]}\ell(dr)
                    \int_{E_r}\kappa_r(u,v)S_r(u,v)d\mu(v).  \tag{2}
\]

The upper integration endpoint in (2) is the original physical `b`, not an edge coefficient. Since `κ≤1`, actual row capacity and the inclusive tail give

\[
 0\le\zeta(u)\le\frac{m_u}{q(u)}\ell([R(u),b])=1.             \tag{3}
\]

This bound applies to the COMBINED potential, rather than bounding two potentials separately and adding them. Thus `ζ∈L¹(E)` and `ψ=−1+ζ∈[-1,0]` is an admissible signed receiver potential.

## 2. Exact price, overlap, and all complements

The existing R333 Dirichlet credit and the new bill are

\[
 D=\tfrac14\int d\xi S_r(u,v)(\sqrt{m_u}-\sqrt{m_v})^2
   =\int_\Omega d\xi S_r(u,v)m_ud(\rho),
\]
\[
 P=\int_E\zeta q\,du
   =\int_\Omega d\xi S_r(u,v)m_u(a+\rho b)\le D,              \tag{4}
\]
\[
 D-P=\int_\Omega d\xi S_r(u,v)m_u[d(\rho)-a-\rho b]\ge0.      \tag{5}
\]

With the unchanged R331/R333 reference
`h=√S(√m_u+√m_v)/2` and row-slack credit `L`, its budget is exactly

\[
 \|h\|^2+\int_E(-1+\zeta)q=-L-(D-P).                        \tag{6}
\]

Define the genuinely paid two-direction cut and its overlap credit by

\[
 \Gamma(y)=\int_\Omega d\xi S_r(u,v)
 [a\,c_u(y)(1-c_v(y))+b\,c_v(y)(1-c_u(y))],
\]
\[
 O(y)=\int_\Omega d\xi S_r(u,v)(a+b)c_u(y)c_v(y)\ge0.
\]

The actual adjoint identity is

\[
 T^*\zeta(y)=\Gamma(y)+O(y).                                \tag{7}
\]

Positive Fubini proves (4),(7); signed expressions are subsequently absolutely integrable because `−1≤ψ≤0`, `Tf=q`, and `E` is finite. No signed positive-Fubini step or density bound occurs.

For the original complete coupling cut
`C_S=½∫dξ S(c_u−c_v)²`, its FULL unpaid complement is

\[
 C_S-\Gamma=
 \int_\Omega d\xi S[(1-a)c_u(1-c_v)+(1-b)c_v(1-c_u)]
 +\tfrac12\int_{m_u=m_v}d\xi S(c_u-c_v)^2.                    \tag{8}
\]

In R333 core notation the precise remaining source profile is therefore

\[
 L_S+(C_S-\Gamma)+R_{\rm fit}-l_H-O.                         \tag{9}
\]

The scalar credit available to a further signed receiver potential is `L+D−P`, not the old `L+D−P_old`. If (9) is at most `c+T*η` with `η∈L¹(E)` and `∫ηq≤L+D−P+εX`, the SAME final potential `−1+ζ+η` proves the old full-slot conclusion `B_H(f,ν)≤εX+(c+λH)W_f`. All outer multiplicative factors, if present, multiply this entire receipt. It is an alternative full-slot settlement and is not added to separately paid innovation blocks.

## 3. Retain the old orientation and pay some reverse traffic

Put

\[
 a_0(\rho)=\min(1,d(\rho)),\qquad
 b_0(\rho)=\frac{d(\rho)-a_0(\rho)}\rho.                       \tag{10}
\]

This is admissible, and `a_0+ρb_0=d`. Furthermore

\[
 0\le b_0\le d/\rho=\tfrac12(1-\rho^{-1/2})^2<\tfrac12.
\]

For `d≤1` this is exactly the old one-direction payment. For `d>1`, it retains its full smaller-captures/larger-misses orientation and pays fraction `(d−1)/ρ` of the reverse orientation. Thus `Γ_new≥Γ_old` and `O_new≥O_old` POINTWISE. The strict new reverse term occurs when `ρ>(1+√2)²`; its fraction tends to `1/2` for large ratios. For example, at `ρ=9` it is `1/9`.

This allocation consumes ALL `D` on every unequal edge where `S` contributes: `P=D`, so `D−P=0`. The old unused credit has been spent, not preserved. Integrating the added potential against the same full source gives exactly `P−P_old`, by `Tf=q`. This is the source-conservation check preventing a second use of that credit.

## 4. Actual overlap determines the useful orientation

There is a precise geometric distinction between maximizing overlap credit and maximizing paid cut. Let

\[
 t_{uv}=\int f(y)c_u(y)c_v(y)dy,\qquad0\le t_{uv}\le m_u.
\]

For a full-budget allocation `a+ρb=d`, the edge's full-source paid cut is

\[
 a(m_u-t)+b(m_v-t)=m_ud-t(a+b),                              \tag{11}
\]

while its overlap credit is `t(a+b)`. Since `a+b=d/ρ+a(1−1/ρ)`, the choice (10) MAXIMIZES overlap credit; the reverse-only choice

\[
 a_{\rm rev}=0,\qquad b_{\rm rev}=d/\rho<1/2                 \tag{12}
\]

MAXIMIZES the paid cut integrated against the actual full `f`. The latter gains

\[
 t_{uv}a_0(1-1/\rho)                                        \tag{13}
\]

over (10) in that integrated cut whenever the overlap is positive. It loses exactly the same integrated overlap credit. Thus with the full overlap term retained there is no net full-source budget gain merely from renaming which part is cut and which part is overlap.

A nontrivial source-geometry choice is nevertheless available for a prescribed priority region. Freeze one `σ(y)dy≤f(y)dy`, for example `σ=f1_B` for an actual measurable source region `B`; it is not copied per edge. Put

\[
 x_u=\int\sigma(y)c_u(y)dy,\quad x_v=\int\sigma(y)c_v(y)dy.
\]

Among ALL allocations (1), the priority potential coverage `a x_u+b x_v` is maximized measurably by

\[
 (a,b)=\begin{cases}(a_0,b_0),&x_u\ge x_v/\rho,\\
                    (0,d/\rho),&x_u<x_v/\rho.
       \end{cases}                                         \tag{14}
\]

If both coefficients vanish one may use `(0,0)` and keep that edge's credit. Proof: because `d/ρ<1/2`, the larger-end box constraint never binds; on the full-budget edge, the objective is `d x_v/ρ+a(x_u−x_v/ρ)`, with `0≤a≤a_0`. All data are measurable cube-source integrals. Independent edge maximization is legitimate within this coefficient class because (1) implies the combined row bound (3) for ANY collection of edge choices.

The same rule, with `x_u=σ(Q_u\Q_v)` and `x_v=σ(Q_v\Q_u)`, maximizes the paid cut on that actual priority source measure. Formula (13) is its full-`f` specialization. This supplies a constructive way to direct existing credit toward a specified remaining geometric source region, rather than a fixed orientation. It can strictly increase the paid priority integral/objective, not guarantee pointwise dominance on that region, and may sacrifice old payments elsewhere; replace the allocation in (8)–(9), do not add two independently optimized receipts. No source-priority criterion is asserted to solve the remaining root certificate.

Equal-mass edges have `d=0`, hence `a=b=0` under (1); their full cut remains in (8). Near equality the paid fractions are small. Neither the fit term nor the equal-mass bottleneck is controlled by this allocation theorem.

## 5. Exact finite checks

Two local standard-library Python `Fraction` runs passed **2,068 exact assertions**: 1,988 allocation/vertex/overlap identities at 28 rational-square mass ratios, and 80 common-potential/prefix-budget assertions with all 16 binary capture patterns and two row-subcapacity factors. The priority rule strictly improved the chosen priority objective in 112 tested cases. These are finite algebra checks, not literal-cube fixtures, a continuum optimization claim, or root evidence. Reproduction is included below; the analytical proof is independent of it.

```python
from fractions import Fraction as F
checks=0; strict=0
for den in range(1,8):
    for num in range(den+1,9):
        root=F(num,den); rho=root**2; d=(root-1)**2/2
        a=min(F(1),d); b=(d-a)/rho; rev=(F(0),d/rho)
        assert 0<=a<=1 and 0<=b<F(1,2); checks+=1
        assert a+rho*b==d; checks+=1
        assert rev[1]<F(1,2); checks+=1
        vertices=[(F(0),F(0)),(a,F(0)),rev]
        if d>=1: vertices.append((F(1),(d-1)/rho))
        for t in [F(0),F(1,4),F(1,2),F(1)]:
            ca=a*(1-t)+b*(rho-t); cr=rev[1]*(rho-t)
            assert cr-ca==t*a*(1-1/rho); checks+=1
            assert a+b>=rev[1]; checks+=1
            for f10,f01,f11 in [(F(1),F(0),F(1,2)),
                               (F(0),F(1),F(1,2)),(F(1),F(1),F(1))]:
                x=(1-t)*f10+t*f11; y=(rho-t)*f01+t*f11
                best=(a,b) if x>=y/rho else rev
                val=best[0]*x+best[1]*y
                assert val==max(v[0]*x+v[1]*y for v in vertices); checks+=1
                if val>a*x+b*y: strict+=1
                for cu,cv in [(0,0),(1,0),(0,1),(1,1)]:
                    aa,bb=best
                    assert aa*cu+bb*cv==(aa*cu*(1-cv)+bb*cv*(1-cu)
                                        +(aa+bb)*cu*cv)
                    checks+=1
assert checks==1988
m=[F(1),F(4),F(9),F(16)]; roots=[F(1),F(2),F(3),F(4)]
mu=[F(1,2),F(1,3),F(1,4),F(1,5)]
r=[F(1),F(5,4),F(3,2),F(2)]; q=[m[u]/r[u] for u in range(4)]
for alpha in [F(1,2),F(1)]:
    z=[F(0)]*4; P=D=L=hnorm=F(0); records=[]
    for k in range(4):
        ell=1/r[k]-(1/r[k+1] if k<3 else 0)
        M=sum(m[u]*mu[u] for u in range(k+1))
        for u in range(k+1):
            L+=ell*mu[u]*m[u]**2*(1-alpha)
            for v in range(k+1):
                S=alpha*m[u]*m[v]/M
                hnorm+=ell*mu[u]*mu[v]*S*(roots[u]+roots[v])**2/4
                if u>=v: continue
                rho=m[v]/m[u]; d=(roots[v]/roots[u]-1)**2/2
                aa=min(F(1),d); bb=(d-aa)/rho
                if k%2==0: aa,bb=F(0),d/rho
                if k==1: aa/=2; bb/=2
                w=ell*mu[u]*mu[v]*S; records.append((u,v,w,aa,bb))
                z[u]+=ell*S*aa*mu[v]/q[u]
                z[v]+=ell*S*bb*mu[u]/q[v]
                P+=w*m[u]*(aa+rho*bb); D+=w*m[u]*d
    for zz in z: assert 0<=zz<=1; checks+=1
    assert sum(z[u]*q[u]*m[u]*mu[u] for u in range(4))==P; checks+=1
    assert P<=D; checks+=1
    X=sum(q[u]*m[u]*mu[u] for u in range(4))
    assert hnorm-X==-L-D; checks+=1
    assert hnorm+sum((-1+z[u])*q[u]*m[u]*mu[u]
                     for u in range(4))==-L-(D-P); checks+=1
    for pattern in range(16):
        c=[(pattern>>u)&1 for u in range(4)]
        potential=sum(z[u]*c[u]*q[u]*mu[u] for u in range(4))
        G=O=C=rest=F(0)
        for u,v,w,aa,bb in records:
            G+=w*(aa*c[u]*(1-c[v])+bb*c[v]*(1-c[u]))
            O+=w*(aa+bb)*c[u]*c[v]
            C+=w*(c[u]*(1-c[v])+c[v]*(1-c[u]))
            rest+=w*((1-aa)*c[u]*(1-c[v])+(1-bb)*c[v]*(1-c[u]))
        assert potential==G+O; checks+=1
        assert C-G==rest; checks+=1
print('PASS',checks,'strict_priority_cases',strict)
```

Only `/tmp/r334_aux.md` is authored. No other research file or Git state is changed.
