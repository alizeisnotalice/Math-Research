# R334 — positive source ratio and zero-X shared potential

## Portable pipeline

Keep these four source files in one directory: `r334_numeric.py`, `r334_solve_ratio.m`, `r334_solve_lp.m`, this note. Paths are resolved by Python `__file__` and MATLAB `mfilename('fullpath')`. Use the bundled interpreter `/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`.

1. Python `r334_numeric.py` prepares deterministic ratio data.
2. MATLAB `run('r334_solve_ratio.m')` produces bounded Dinkelbach/quadprog candidates.
3. Python `r334_numeric.py --prepare-lp` exactly repairs the source, builds rational h, complete defect uppers and zero-X shared-potential data.
4. MATLAB `run('r334_solve_lp.m')` produces common signed receiver potentials.
5. Python `r334_numeric.py --verify` exactly repairs and checks every source pattern and budget; writes the small final summary.

MATLAB output is a numerical candidate only. The later rational feasibility and upper certificate do not assume Dinkelbach convergence or solver optimality. No previous round is imported or modified.

## Physical finite model and the correct ratio domain

Keep the R333 actual centered cube geometries in dimensions1/2/3, compact initial source1_Q4, mixed radii1,3/2,2 and their explicitly specified positive rational receiver quadrature weights. The COMPLETE source partition at all receiver faces has5/64/900 positive-volume boxes; merge their identical full incidence signatures to4/10/19 patterns. This is an exact source integration, not source sampling. The receiver field remains a FINITE QUADRATURE, not positive Lebesgue dx or an original-history proof.

Actual receiver masses m_i=R_i^n, μ_i=w_i/m_i and q=λ=1 are fixed. Every receiver kernel cube is contained in Q4. Source mass x on nonzero patterns is free under Cx=m and x≥0; there is NO constraint Σx=4^n. Each pattern has at least one captured receiver, hence x_j≤min_(i:Cij=1)m_i≤max m_i, while W=Σx≥max m_i>0. The polytope is nonempty and compact. Original nonzero-pattern masses supply an exactly feasible point.

The zero pattern is removed ONLY from the ratio variables: it changes neither receiver means, aH nor features and can only increase W, so it cannot improve a positive F/W. It is retained in every subsequent source certificate with d=Tζ=0 and c≥0. Source complement outside Q4 is also covered by this same zero condition. When the best F is nonpositive, the positive-ratio objective is0 (adding arbitrary zero-pattern mass also makes negative ratios approach0); no root improvement is inferred from that case.

All actual physical prefixes, ties and the final ell atom are retained. Original J depends only on the fixed selected receiver means m, so it stays unchanged across this source cone. H0 is the main all-row diagnostic; H1/8 retains the mandatory completion charge.

## Candidate ratio optimization and exact reconstruction

Frozen Hilbert features give a positive-semidefinite numerical Gram K and fixed aH. Define F(x)=aH·x−xᵀKx. MATLAB solves at most30 parametric convex QPs minimizing xᵀKx−aH·x+cΣx under Cx=m,x≥0. It updates c=max(0,F/W) and records convergence, equality residual and equality multipliers. This is a bounded numerical candidate search, not a proof of continuum attainment, ratio optimality or QP strong duality.

Python rationalizes x, restores ONLY Cx=m by exact elimination, and if necessary mixes with the original positive nonzero-pattern masses to restore x≥0. It checks each coordinate bound and W≥max m>0. W is then the actual reconstructed source mass. It does not restore the old4^n mass. A pattern's mass is spread proportionally over the actual source boxes with that signature, yielding a compact positive L1 source with the exact selected receiver means and actual q1.

Exact integer-square-root intervals give rational lower/upper h≈Φ_x. They enclose F(x) and therefore give a genuine feasible lower bound max(0,F_lower/W) on the positive relaxed ratio supremum. The exact original BH(x,x)/W is separately computed with the one-sided A²/J square. These are different quantities: the relaxed F/W bracket is NOT a lower/upper pair for original BH/W.

## Zero-X certificate

Using rational nonnegative lower h, compute its norm and credit X−||h||² EXACTLY. For every FULL source pattern, construct the rational UPPER

d=aH+T*1−2Σell μ_iμ_j c_i c_j h_ij/sqrt_upper(J).

Then MATLAB searches c≥0 and one signed ζ per receiver with d≤c+T*ζ everywhere and Σwζ≤credit. Python rationalizes ζ; if over budget it subtracts the SAME rational amount from all ζ, then recomputes c as the maximum exact source residual and0. No solver residual tolerance is relied on.

The exact checked common-potential inequalities, actual Cx=m and the mean identity imply F(x)/W≤c over the full source cone. The candidate ratio lower and c upper may therefore bound the **positive relaxed ratio**; they do not bracket original BH/W. Original BH/W is only separately evaluated and bounded above by c+H, including the completion fee.

For positive finite ratio maximizers the supporting KKT algebra explains why this objective matches zero-X credit: if d=a−2Kx−c1≤Cᵀλ with support equality, multiplying by x yields λ·m=−Q. In the current q1 fixtures the potential ψ_i=λ_i/μ_i has Q+Σw_iψ_i=0. For a general finite model with receiver q_i the mapping is ψ_i=λ_i/(μ_i q_i), yielding Q+Σw_i q_i ψ_i=0; this round does not test varying q. This is motivation in a finite polytope only; final evidence uses the independently repaired LP certificate, not numerical multipliers.

## Execution status

The primary agent actually ran all six bounded ratio searches and all six shared-potential LPs in MATLAB. The positive cases used four Dinkelbach QPs each; the two nonpositive candidate cases used one each (18 parametric QP calls in total). All numerical searches reported convergence; this status is not used as a certificate. Python exact source reconstruction succeeded with no mixing required. The final common-potential repair passed **114 exact post-repair assertions**, checking all66 full-source pattern rows, signed budgets, repaired means, source integral accounts, zero pattern, candidate lower versus upper and the original BH completion. Preparation contains additional uncounted exact geometric and source-feasibility assertions. No Decimal-only or previous-round checks are added to114.

For H0 the genuinely matched relaxed ratio brackets are:

|n|feasible positive F/W lower|common-potential upper c|exact-bound gap (decimal)|repaired source actual BH/W|
|---|---:|---:|---:|---:|
|1|.0274503545489720|.0274503691792985|1.46303e−8|.0228730739163446|
|2|.0296486876569701|.0296486881278775|4.70907e−10|.0257670443012396|
|3|.0174747801353979|.0174747837087261|3.57333e−9|.0142978513757184|

Every listed gap is computed from exact rational lower/upper bounds. The small gaps concern the FINITE positive relaxed-ratio problem; solver multipliers or a strong-duality assertion are not needed to certify these bounds. They do not bracket the original BH/W, whose value is separately displayed. Reconstructed source masses are approximately1.76037658,4.00000000073,8.00000003257, not the old4,16,64. This confirms that W was actually freed.

The R333 fixed-W candidate references gave zero-X upper c≈.0332164,.0305101,.0175234; the R333 original-source references gave≈.0282260,.0440091,.0237824. The present ratio target improves these finite upper certificates and, more decisively, produces near-matching feasible source lower bounds. This supports the change of optimization objective. It gives no dimension-rate or general root conclusion.

For H1/8, n1 has the same positive relaxed bracket as H0, but the original BH ratio certificate is c+H≈.15245037. In n2/3 the feasible positive-part lower is0 and the certified c upper is approximately3.10084e−18/4.64990e−17. These tiny nonnegative uppers are not reported as an exact proof that Fmax≤0; rational repair and enclosure leave a tiny gap. Actual repaired-source BH/W remains≈.01986660/.00841422, and its certificate still includes H=.125. Near-zero c alone does not pay that completion or prove a root estimate.

The results are in the small `r334_numeric_summary.json`; full rational potentials, budgets, gaps and repaired source ratios are in `r334_numeric_verified.json`. The numerical Gram and candidate optimization remain floating-point stages. Exact integer-square-root enclosures, nonnegative source reconstruction and common-potential repair supply the reported finite certificates independently.

## Minimal replay material and frozen scope

The four regenerating source files are `r334_numeric.py`, `r334_solve_ratio.m`, `r334_solve_lp.m`, this note. Preserve the two small actual MATLAB candidate outputs `r334_solve_ratio_results.json` and `r334_solve_lp_results.json` for exact candidate replay, plus the small summary (and optionally the full rational verified output). The generated data files are deterministic and need not be archived. All paths are portable to a common directory. The primary agent completed an independent-checkpoint FULL portable replay: preparation, ratio MATLAB searches, exact source/reference preparation, shared-potential MATLAB LPs and verification, PASS114. All intervals agree with the `/tmp` run; positive cases used four QPs, nonpositive candidate cases one (18 QPs+6 LPs). Code and these notes are frozen.

Precisely, the lower/upper bracket encloses the positive supremum of the FINITE FROZEN PSD-relaxation ratio F(g)/W_g under the selected receiver mean constraints. It does not bracket a general original BH extremum. The exactly repaired common-potential inequalities do apply to ANY nonnegative L1 source g in this fixed finite receiver mean class, since every possible source incidence pattern, including0, is covered. Candidate source feasibility supplies the lower witness; the common potential supplies the class-wide upper. Complete original history, continuum receiver dx and a dimension-uniform root budget remain outside this evidence. No previous round or another author's file is edited.
