# R334 — finite extremal source ratio and the zero-X-budget certificate

This is an exact finite-model optimization statement, not a continuum maximal-operator theorem. The underlying source cells are complete cube-incidence cells; only the receivers in the experiment are discretized. It identifies the correct numerical objective for the existing Hilbert upper bound and does not prove that its value has root order in dimension.

## Definitions and domain

Freeze positive receiver weights w_i, cube volumes R_i^n, actual matched masses m_i=q_i R_i^n>0, and μ_i=w_i/m_i. Let C_ij be the full capture signature of source cell j. Every listed nonzero signature has a positive-volume realization. Merge identical signatures, since all original prefix J, high-row a_H and pair features coincide. Keep every positive-volume signature, not sampled source points. Source cell mass is x_j≥0 and exact mean matching is Cx=m. At least one matching source exists by construction.

Remove only the all-zero signature from the optimization domain P={x≥0:Cx=m}. This does not remove it from the final pointwise certificate. For every remaining column j there is i with C_ij=1, so x_j≤m_i≤max_i m_i. P is a nonempty compact polytope. W(x)=Σ_jx_j≥max_i m_i>0 on P. Thus no division by a vanishing denominator is possible.

Let Φ_j be the original full-row pair feature, including all radius prefixes and the terminal atom. Its Gram matrix K=Φ*Φ is positive semidefinite. Define
\[
F(x)=a_H^T x-x^T Kx,\qquad
r_* =\max_{x\in P}\frac{F(x)}{W(x)},\qquad c_* =\max(0,r_*).
\]
The maximum over P is attained by compactness and the positive denominator. Adding arbitrary source mass to the zero signature does not change F or Cx, but increases W. Hence the supremum on the FULL source cone is c_*: for positive ratios removal improves them; for negative ratios, outside mass makes the ratio approach zero. At zero the supremum need not be attained in the enlarged cone. This is why the source certificate explicitly imposes c≥0.

## Parameter residual, with directions preserved

For any real c let G(c)=max_{x∈P}[F(x)−cW(x)]. Since W is positive, G(c)>0 iff c<r_*, G(c)=0 iff c=r_*, and G(c)<0 iff c>r_*. No exchange of an infinite supremum or unproved strong duality is used. Maximizing F−cW is a concave quadratic problem on this finite polytope; floating-point solutions remain candidates until separately certified.

## Why a ratio extremizer matches the desired receiver budget

Assume r_*>0 and let x_* attain it, c=r_*. Then x_* maximizes F−cW with value zero. Its gradient at x_* is d=a_H−2Kx_*−c1. For every feasible x, first-order optimality yields d·(x−x_*)≤0. Equivalently x_* maximizes the linear functional d·x over the finite polytope.

The finite-dimensional Farkas/linear-program normal-cone theorem gives a common real multiplier λ with C^Tλ≥d and x_{*,j}[(C^Tλ)_j−d_j]=0. This is a finite polyhedral statement; no Slater condition or infinite-dimensional strong-duality assertion is substituted. Multiplying by x_* and using F(x_*)=cW(x_*) gives
\[
\lambda^Tm=a_H^Tx_*-2Q(x_*)-cW(x_*)=-Q(x_*).
\]
Choose h=Φx_* and the common receiver potential
\[
\psi_i=\lambda_i/(\mu_iq_i)=\lambda_iR_i^n/w_i.
\]
Then
\[
a_H(j)-2\langle h,\Phi_j\rangle\le c+\sum_i\mu_iq_i\psi_iC_{ij},
\qquad
\|h\|^2+\sum_iw_iq_i\psi_i=Q(x_*)+\lambda^Tm=0.
\]
The source adjoint coefficient is μ_iq_i=w_i/R_i^n, and w_iq_i/(μ_iq_i)=m_i. In the experiments q_i=1, but that simplification is not used in this general finite statement.

If r_*≤0, choose x_* maximizing F (without the mass penalty). Its maximum is ≤0. The same finite normal-cone calculation with c=0 gives Q(x_*)+λ^Tm=F(x_*)≤0. Thus a zero-source-coefficient weak-dual certificate exists in this finite relaxation. The zero signature has a_H=Φ=T*=0, so c≥0 covers it exactly in both cases.

## Weak certificate, exact gap, and numerical scope

For any common h, c≥0 and ψ satisfying the two displayed inequalities with correct adjoint coefficients and nonpositive receiver bill, every x∈P obeys F(x)≤cW(x). This follows directly from ||Φx−h||²≥0 and Cx=m; no numerical optimality status enters. The same certificate covers arbitrary added zero-signature mass. Therefore the smallest feasible source coefficient in this finite weak-dual class is exactly c_*.

For an arbitrary feasible certificate define the nonnegative source residual
\[
s_j=c+(C^T\lambda)_j-a_H(j)+2\langle h,\Phi_j\rangle,
\quad b=\|h\|^2+\lambda^Tm\le0.
\]
The exact gap for any matching x is
\[
cW(x)-F(x)=\sum_j s_jx_j+\|\Phi x-h\|^2-b.
\]
This describes the finite extremal geometry: a near-extremizer must concentrate mass on cells with small residual and be close in the same pair-feature norm, while all true prefix costs remain. It does not assert concentration in Euclidean space or a dimension-uniform bound on c_*.

In actual computation, a repaired nonnegative matching x and rational enclosures of Q give a lower bound max(0,F_lower(x)/W(x)) for c_*. A rationally repaired h/ψ certificate gives an upper bound. Their difference certifies a finite relaxation gap; it is not a two-sided estimate of the ORIGINAL B_H optimum, since F uses the symmetric full-row completion. Original B_H(x,x) is separately evaluated with its one-sided square and its λH completion fee is retained when converting the upper certificate to B_H.

For a certificate with positive c and a matching source satisfying F(x)/W(x)≥c−δ, the exact gap implies
\[
\sum_{j:s_j\ge\tau}x_j\le\delta W(x)/\tau\quad(\tau>0),\qquad
\|\Phi x-h\|^2\le\delta W(x).
\]
The zero signature has residual s_0=c, so its mass is at most δW/c for such a near-extremizer. This explains why an arbitrary large unused-source mass in a fixed-W experiment is not neutral for the desired ratio. It is a statement about candidates near a proved finite certificate, not permission to omit any mass from the original input or its final account.
