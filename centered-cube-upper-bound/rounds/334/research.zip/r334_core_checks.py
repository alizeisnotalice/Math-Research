from decimal import Decimal as D, getcontext
from random import Random
getcontext().prec=70
tol=D('1e-55'); checks=0; nonzero=0; worst=D(0)
for seed in range(20):
 rng=Random(seed); N=4
 m=[D(1)]*N if seed<10 else [D(1),D(1),D('1.5'),D(2)]
 mu=[D(1)/D(i+2) for i in range(N)]
 R=[D(1),D('1.1'),D('1.3'),D('1.6')]
 ell=[1/R[i]**2-1/R[i+1]**2 for i in range(N-1)]+[1/R[-1]**2]
 S=[]; rows=[]
 for p in range(1,N+1):
  z=[[D(0)]*N for _ in range(N)]
  for i in range(p):
   for j in range(i,p): z[i][j]=z[j][i]=D(rng.randint(1,9))/10
  raw=[sum(z[i][j]*mu[j] for j in range(p)) for i in range(p)]
  fac=max(raw[i]/m[i] for i in range(p))*D('1.1')
  z=[[x/fac for x in row] for row in z]
  S.append(z); rows.append([sum(z[i][j]*mu[j] for j in range(p)) for i in range(N)])
 k=[max(rows[p][i]/m[i] for p in range(i,N)) for i in range(N)]
 th=[x.sqrt() for x in k]; eta=[1-x for x in th]; x=[th[i]*m[i].sqrt() for i in range(N)]
 norm=slack=energy=P=D(0); load=[D(0)]*N
 for p in range(N):
  for i in range(p+1):
   slack+=ell[p]*mu[i]*th[i]**2*m[i]*(m[i]-rows[p][i])
   for j in range(p+1):
    base=ell[p]*mu[i]*mu[j]*S[p][i][j]
    norm+=base*(x[i]+x[j])**2/4; energy+=base*(x[i]-x[j])**2/4
    if th[i]<th[j] and D('0.5')<=m[j]/m[i]<=2:
     w=min(D(1),(x[j]-x[i])**2/(2*m[i]))
     load[i]+=ell[p]*mu[j]*S[p][i][j]*w
     P+=base*m[i]*w
     if m[i]==m[j] and w>0: nonzero+=1
 bill=norm-sum(th[i]**2*m[i]**2*mu[i]/R[i]**2 for i in range(N))
 err=abs(bill+slack+energy); worst=max(worst,err); assert err<tol; checks+=1
 assert P<=energy+tol; checks+=1
 for i in range(N):
  assert load[i]*R[i]**2/m[i]<=1+tol; checks+=1
 for mask in range(1,16):
  c=[D(bool(mask&(1<<i))) for i in range(N)]
  fit1=fitth=teta=Gamma=Overlap=Tz=D(0)
  for p in range(N):
   J=sum(mu[i]*c[i] for i in range(p+1))
   if J:
    for i in range(p+1):
     teta+=ell[p]*mu[i]*m[i]*c[i]*eta[i]**2
     for j in range(p+1):
      base=ell[p]*mu[i]*mu[j]*c[i]*c[j]
      fit1+=base*(m[i].sqrt()/J.sqrt()-S[p][i][j].sqrt())**2
      fitth+=base*(x[i]/J.sqrt()-S[p][i][j].sqrt())**2
      if th[i]<th[j] and D('0.5')<=m[j]/m[i]<=2:
       w=min(D(1),(x[j]-x[i])**2/(2*m[i]))
       z=ell[p]*mu[i]*mu[j]*S[p][i][j]*w
       Gamma+=z*c[i]*(1-c[j]); Overlap+=z*c[i]*c[j]
  Tz=sum(mu[i]*c[i]*load[i] for i in range(N))
  assert fitth<=fit1-teta+tol; checks+=1
  err=abs(Tz-Gamma-Overlap); worst=max(worst,err); assert err<tol; checks+=1
print({'checks':checks,'cases':20,'source_patterns_per_case':15,'nonzero_equal_mass_oriented_prefix_edges':nonzero,'max_identity_error':str(worst),'arithmetic':'Decimal 70 digits','tolerance':str(tol),'scope':'finite incidence algebra only; not actual cube fixtures or root evidence'})
