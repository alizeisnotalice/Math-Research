# R334 — occupancy-adapted θ with a paid comparable-mass cut

**Bounded conclusion.** A common receiver function θ is constructed from actual row-capacity occupancy. Its change in the source fit is proved nonpositive, with an explicit decrease. The resulting genuine Dirichlet credit pays an oriented part of comparable-mass cuts, including equal masses whenever these occupancy amplitudes differ. The potential and its price use the same actual receivers and all original prefixes. There is no established uniform amount of occupancy contrast on the target high rows, and hence no general root estimate is claimed. In particular, saturated couplings give no improvement by this construction.

## 1. Frozen contract and the precise fit-safe choice

Use the R331 hard matched slot: f≥0 in L¹, β=f dx, ν≤f dx, finite E, actual a≤R≤b≤2a, q=h_R*f∈[3λ/4,λ]. Put

\[
 m_u=q(u)R(u)^n,\quad d\mu(u)=1_E(u)du/m_u,\quad
 E_r=\{u\in E:R(u)\le r\},\quad c_u(y)=1_{Q_{R(u)}(u)}(y),
\]
\[
 J_y(r)=\int_{E_r}c_u(y)d\mu(u),\quad
 \ell=b^{-n}\delta_b+nr^{-n-1}1_{[a,b]}dr,\quad
 d\xi=\ell(dr)1_{E_r^2}(u,v)d\mu(u)d\mu(v).
\]

All these are original quantities. Let S_r≥0 be jointly measurable and symmetric, with actual row marginal

\[
 a_r(u)=\int_{E_r}S_r(u,v)d\mu(v)\le m_u.
\]

Here a_r is not the high-source coefficient a_H. Define, with essential supremum taken against the restriction of the ORIGINAL ell to [R(u),b],

\[
 k(u)=\mathop{\mathrm{ess\,sup}}_{r\in[R(u),b]}\frac{a_r(u)}{m_u},
 \qquad \theta(u)=\sqrt{k(u)},\qquad \eta(u)=1-\theta(u).       \tag{1}
\]

Thus 0≤k,θ,η≤1, and θ is independent of r. The b atom is included. Measurability follows, for each rational t, from testing whether
`∫_[R(u),b] 1_{a_r(u)/m_u>t} ell(dr)>0`. The ratio is defined on E_r; exceptional null sets may be set to zero.

Recall the R331 features and references

\[
 \varphi_y(r,u,v)=\frac{c_u(y)c_v(y)}{\sqrt{J_y(r)}},\quad
 h_\theta=\frac{\sqrt S}{2}(\theta_u\sqrt{m_u}+\theta_v\sqrt{m_v}),
\]

with zero rows contributing zero. Write
`dθ(y)=a_H(y)+T*(θ²)(y)−2⟨hθ,φy⟩`. For this SAME S,

\[
 \boxed{d_\theta(y)\le d_1(y)-T^*(\eta^2)(y)\quad\text{a.e. }y.} \tag{2}
\]

This includes the full fit cost. Indeed symmetry and Cauchy give

\[
 \begin{aligned}
 \langle h_\eta,\varphi_y\rangle
 &=\int\ell(dr)\frac1{\sqrt J}
   \int_{E_r}\eta_u\sqrt{m_u}c_u(y)d\mu(u)
   \int_{E_r}c_v(y)\sqrt{S_r(u,v)}d\mu(v)\\
 &\le\int\ell(dr)\int_{E_r}\eta_u c_u(y)\sqrt{m_u a_r(u)}d\mu(u)
 \le T^*(\eta\sqrt{k})(y).
 \end{aligned}                                                \tag{3}
\]

The last step uses the exact inclusive tail `ell([R(u),b])=R(u)^{-n}`. Linearity of h gives the exact perturbation identity

\[
 d_\theta-d_1=-2\{T^*\eta-\langle h_\eta,\varphi_y\rangle\}
                         +T^*(\eta^2).
\]

Since θ=√k and 1−θ=η, the braces are at least T*(η²), proving (2).

In the R331 decomposition `dθ=∫ell(e_S+R_{S,θ})−l_H`, the escape e_S and l_H do not change with θ. Consequently (2) is equivalently the actual fit estimate

\[
 \int\ell R_{S,\theta}(y,r)
 \le\int\ell R_{S,1}(y,r)-T^*(\eta^2)(y).                    \tag{4}
\]

This is an upper Cauchy estimate, not a lower correlation assertion. No density bound or boundary-volume-to-source-mass comparison is used.

## 2. One common potential pays an oriented comparable-mass cut

Fix K≥1, for example K=2, and choose the measurable oriented set

\[
 \Omega_K=\{(u,v):\theta_u<\theta_v,\ K^{-1}\le m_v/m_u\le K\}.
\]

Its transpose is disjoint; ties are left unpaid. Let x_u=θ_u√m_u and define on this set

\[
 w(u,v)=\min\{1,(x_v-x_u)^2/(2m_u)\},
\]
\[
 \zeta(u)=\frac1{q(u)}\int_{[R(u),b]}\ell(dr)
             \int_{E_r}1_{\Omega_K}(u,v)w(u,v)S_r(u,v)d\mu(v). \tag{5}
\]

This is a SINGLE receiver potential, independent of the source being tested. Row capacity and the exact tail give 0≤ζ≤1. Its price is exactly

\[
 P=\int_E\zeta q\,du
   =\int_{\Omega_K}d\xi\,m_u wS
   \le\frac12\int_{\Omega_K}d\xi\,S(x_v-x_u)^2
   \le D_\theta,\quad
 D_\theta=\frac14\int d\xi\,S(x_v-x_u)^2.                    \tag{6}
\]

The last factor follows by symmetry and the disjoint orientation. Define the actual source terms

\[
 \Gamma(y)=\int_{\Omega_K}d\xi\,wS c_u(y)(1-c_v(y)),\qquad
 O(y)=\int_{\Omega_K}d\xi\,wS c_u(y)c_v(y).
\]

Positive Fubini gives the exact shared-source cover

\[
 T^*\zeta(y)=\Gamma(y)+O(y).                                  \tag{7}
\]

Thus Γ is a paid part of the cut `C_S=(1/2)∫dξ S(cu−cv)²`; O≥0 is the accompanying overlap credit. Both receiver directions, including the unselected reverse cut, remain in C_S−Γ. Since w≤1, this remainder is nonnegative.

For exactly equal masses,

\[
 w(u,v)=\tfrac12(\theta_v-\theta_u)^2.
\]

In particular, on actual equal-mass pairs with θ_v−θ_u≥δ>0 the construction pays at least δ²/2 of the oriented cut weight. More generally the paid proportion is at least `min{1,δ²/2}` whenever `|θ_v√(m_v/m_u)−θ_u|≥δ`. These are measurable occupancy/mass conditions, not assumptions about the target defect. No uniform positive δ is asserted.

## 3. Complete bill, original square, and a genuine same-source instantiation

Use the JOINT potential ψ=−θ²+ζ. All its terms are integrable because |ψ|≤1 on finite E. The R331 exact identity yields

\[
 \boxed{\|h_\theta\|_2^2+\int_E\psi q
       =-L_\theta-D_\theta+P\le0,}
\]
\[
 L_\theta=\int\ell(dr)\int_{E_r}\theta_u^2m_u(m_u-a_r(u))d\mu(u).
                                                                    \tag{8}
\]

Both Lθ and Dθ are recomputed for this θ and S. Old θ=1 credits cannot be retained. Nor may another allocation spend the same Dθ again. Equations (2) and (7) give

\[
 d_\theta-T^*\zeta\le d_1-T^*(\eta^2)-\Gamma-O.              \tag{9}
\]

The Hilbert inequality and the already proved low-row completion therefore give the valid full-slot bound

\[
 B_H(f,\nu)\le B_H(f,f)
 \le\int f(y)[d_\theta(y)-T^*\zeta(y)]dy
       +\lambda H W_f-L_\theta-D_\theta+P.                   \tag{10}
\]

This retains Q_all through its Hilbert reference and charges the low-row completion only λH W_f. It replaces the full original slot; previously paid crossing or atom costs are not added to it. All original J, prefixes, source positions and ell atoms are retained. There is no new factor An, 2^n, or scale ratio in (2)–(10). General outer-slot multipliers must multiply the entire bound as usual.

An explicit same-source family is available without introducing a private coupling. Use the R332 quantities

\[
 G_r(u,v)=\int f(z)c_u(z)c_v(z)/\sqrt{J_z(r)}\,dz,\quad
 S^0_r=4G_r^2/(\sqrt{m_u}+\sqrt{m_v})^2,
\]

`s_r(u)=m_u−∫S⁰_r(u,v)dμ(v)`, `Z_r=∫s_r dμ`, and `X_r(u,v)=s_r(u)s_r(v)/Z_r` when Z_r>0, zero otherwise. For one common t∈[0,1], take

\[
 S^t=S^0+tX,\quad a^t_r(u)=m_u-(1-t)s_r(u),\quad
 k_t(u)=1-(1-t)\mathop{\mathrm{ess\,inf}}_{r\in[R(u),b]}s_r(u)/m_u.
\]

These are feasible actual row capacities. R332 identifies s through true source-boundary mass and the intersection-posterior variance of J^{-1/2}; it is not a volume proxy. With θ=1 the corresponding h_t≥G, so, writing
`Δ_t=2⟨h_t−G,φ_y⟩≥0` and `d0=a_H+T*1−2K_all f`, (9) becomes

\[
 d_{\theta_t}-T^*\zeta
 \le d_0-\Delta_t-T^*(\eta_t^2)-\Gamma-O.                   \tag{11}
\]

This is a quantified source-profile improvement of that particular tangent candidate, with the complete new bill (8). It is not an improvement of the original integrated quadratic optimum for fixed f; lost old negative-bill credit must still be accounted for.

## 4. Exact scope and the remaining bottleneck

The newly paid component is the oriented comparable-mass cut Γ under the common occupancy-adapted θ, with fit certified to decrease by (4). For t<1 the equal-mass branch is strict wherever the full-prefix slack infima differ and the relevant actual cut has positive weight. No claim is made that this happens on a fixed proportion of target high-row traffic.

At t=1, or whenever k is constant across the relevant equal-mass pairs, this comparable-mass gain vanishes; saturation gives k=θ=1 and η=0. An essential infimum of slack equal to zero at some prefixes can also remove the gain even when other prefixes have substantial slack. Thus the construction does not resolve balanced saturated overlap geometry.

The unpaid terms are the complementary/reverse cut C_S−Γ, the actual fit R_{S,θ}, the capacity leak, and the source complement not reached by the selected pairs, with the original negative l_H retained. The particular improvement (11) has no proved root-sized global upper bound. A substantive next estimate would need actual high-row overlap to force useful variation of these full-prefix occupancies, or a different common θ whose fit increase is explicitly covered when the occupancies are equal. Increasing Dθ by itself is insufficient, precisely because the perturbation identity preceding (4) also changes the fit.

Local verification actually run: Python Decimal at 70 digits checked 20 symmetric finite-incidence subcapacity systems, each with four nested prefixes and all 15 nonempty receiver-incidence source patterns. The 720 assertions checked the signed bill, price≤Dθ, 0≤ζ≤1, fit decrease (4), and cover (7), at tolerance 10^-55; maximum checked identity error was 9.23×10^-70. There were 101 nonzero equal-mass oriented prefix edges. These are algebra diagnostics, not positive-volume cube fixtures, a guaranteed target-active branch, or numerical evidence for a general root bound. The analytic proof is independent of them.

Only `/tmp/r334_core.md` is authored. Bounded delivery stops here.
