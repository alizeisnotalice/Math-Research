r334_base=fileparts(mfilename('fullpath'));
r334_data=jsondecode(fileread(fullfile(r334_base,'r334_data_lp.json')));
r334_candidates=struct('id',{},'exitflag',{},'c',{},'zeta',{});
r334_options=optimoptions('linprog','Display','none');
for r334_k=1:numel(r334_data.cases)
    r334_case=r334_data.cases(r334_k);r334_N=numel(r334_case.weights);r334_rows=numel(r334_case.source);
    r334_A=[-ones(r334_rows,1),-r334_case.solver_T;0,r334_case.solver_weights(:)'];r334_b=[-r334_case.solver_d(:);r334_case.solver_credit];
    [r334_x,~,r334_exit]=linprog([1;zeros(r334_N,1)],r334_A,r334_b,[],[],[0;-inf(r334_N,1)],[],r334_options);
    r334_result=struct();r334_result.id=r334_case.id;r334_result.exitflag=r334_exit;
    if isempty(r334_x);r334_result.c=NaN;r334_result.zeta=zeros(1,r334_N);else;r334_result.c=r334_x(1);r334_result.zeta=r334_x(2:end)';end
    r334_candidates(end+1)=r334_result;
end
r334_file=fopen(fullfile(r334_base,'r334_solve_lp_results.json'),'w');fwrite(r334_file,jsonencode(struct('candidates',r334_candidates)),'char');fclose(r334_file);
disp(struct('status','LP_CANDIDATES_WRITTEN','cases',numel(r334_candidates)));
