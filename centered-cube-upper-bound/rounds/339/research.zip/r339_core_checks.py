from fractions import Fraction as F
from decimal import Decimal as D, getcontext
from random import Random
getcontext().prec=70
def dec(x): return D(x.numerator)/D(x.denominator)
checks=0; worst=D(0); q=F(3,4)
for seed in range(40):
 rng=Random(seed); N=1+seed%5; windows=[]; cursor=F(1+seed%3,2)
 for j in range(N):
  a=cursor; b=a+F(rng.randint(0,8),3)
  windows.append((a,b)); cursor=b+F(rng.randint(1,7),4)
 logs=sum((dec(b/a).ln() for a,b in windows),D(0))
 gap=sum((F(1)-windows[j-1][1]/windows[j][0] for j in range(1,N)),F(0))
 C=1+logs+dec(gap); naive=D(N)+logs
 saving=sum((windows[j-1][1]/windows[j][0] for j in range(1,N)),F(0))
 err=abs(naive-C-dec(saving)); worst=max(worst,err); assert err<D('1e-60'); checks+=1
 assert 1<=C<=naive; checks+=1
 integral=dec(windows[0][0]/q/windows[0][0])
 for j,(a,b) in enumerate(windows):
  integral+=dec(b/a).ln()/dec(q)
  if j: integral+=dec((a-windows[j-1][1])/(q*a))
 err=abs(integral-C/dec(q)); worst=max(worst,err); assert err<D('1e-60'); checks+=1
 testm={F(0),windows[-1][1]+1}
 for j,(a,b) in enumerate(windows):
  testm.update((a,b,(a+b)/2))
  testm.add(a/2 if j==0 else (windows[j-1][1]+a)/2)
 for x in testm:
  candidates=[max(a,x) for a,b in windows if max(a,x)<=b]
  direct=1/min(candidates) if candidates else F(0)
  piece=F(0)
  for a,b in windows:
   if x<=a: piece=1/a; break
   if a<x<=b: piece=1/x; break
  assert direct==piece; checks+=1
 for a,b in windows:
  for n in (1,2,8,64):
   L=(dec(a/q).ln()/n).exp(); U=(dec(b/q).ln()/n).exp()
   err=abs(D(n)*(U/L).ln()-dec(b/a).ln()); worst=max(worst,err)
   assert err<D('1e-60'); checks+=1
 # Splitting one nondegenerate interval into touching windows must merge for free.
 a=F(2); b=F(3+seed,2); b=max(b,a+1); mid=(a+b)/2
 merged=1+dec(b/a).ln()
 split=1+dec(mid/a).ln()+dec(b/mid).ln()
 err=abs(merged-split); worst=max(worst,err); assert err<D('1e-60'); checks+=1
print({'window_families':40,'assertions':checks,'max_identity_error':str(worst),'arithmetic':'Fraction plus Decimal 70 digits','tolerance':'1e-60','scope':'shared radial majorant and union-cost algebra only; no actual-source root inference'})
