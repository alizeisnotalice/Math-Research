# R339 — exact center-outside crowded-shell diagnostic

This is an actual receiver-Lebesgue-volume calculation for one compact positive-L1 input, not a finite receiver quadrature. It does not certify the full original selector history or a general root budget. It evaluates the massgap branch, not the full reverse loss. The source subset used for the lower bound is explicitly retained.

Run with the standard library only:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /path/to/r339_numeric.py
```

The script writes `r339_numeric_result.json` beside itself. No previous /tmp script or data is imported.

## Actual field and exact integration

Let n=k², k=2,3,4,5,6,8,10, a=λ=q=1, b=2, f=β=ν=1_{Q4}, δ=1/(4n), r_i=1+i/n. Assign R=L=r_i, s=0 on E_i=Q_{r_i−δ} minus the preceding cube (the initial preceding cube is empty). All physical hard cubes stay inside Q4, so q=1 exactly. For every y in the positive-volume Qδ, every receiver captures y; thus U_y(u)=r_i^-n on E_i. Write h_i=|E_i|/r_i^n and J_i=Σ_{j≤i}h_j. The full source mass is W=4^n, whereas the central source mass is δ^n.

For each large endpoint i, retain small endpoints j with r_i^n>e^k r_j^n; Z_i is their full past mass. The strict gate is Z_i>h, with h=4k/3 (R337), 4(k+1)/3 (R338 ε=1), or 8(k+1)/3 (ε=1/2). Exponential Taylor lower/upper bounds certify every strict endpoint comparison. The layer weights are ell_i=r_i^-n−r_{i+1}^-n, with the full terminal atom ell_n=2^-n. The computed future clock is Σ_{l≥i}ell_l/J_l, without an explicit H gate. **Each threshold row is valid for H=h or any H≤that row’s h.** Indeed, each retained endpoint satisfies J_i>Z_i>h, and every future prefix has J_l≥J_i, so its H gate is automatic. These values are not asserted for H>h. This H condition applies separately to the old337, ε=1, and ε=1/2 rows.

The center split is ||u−v||∞≤αr_i/2 versus its complement, first α=1, then α^n=1+k. Fixed-denominator rational bounds of width 2^-48 enclose α. For centered intervals of lengths S,T, the difference density is (B−|x|)_+−(A−|x|)_+, where B=(S+T)/2 and A=|S−T|/2. Its integral over |x|≤c is exactly

`2B min(c,B) − min(c,B)^2 − 2A min(c,A) + min(c,A)^2`.

Taking the n-th power and four shell inclusion-exclusion terms gives the exact center pair volume. No point sampling replaces an integral. Root-alpha inside is monotone in α, yielding exact outside lower/upper bounds. Every pair satisfies inside+outside=full volume. Weighted total G independently equals the R338 prefix expression with its small-mass correction; it is not replaced by the first-moment primitive. The same center pair calculation applies to every y∈Qδ, not just y=0.

## Results

Two fresh process runs passed **11,920 exact rational/integer assertions**: initial n4/9/16:76; onset n25/36:1,002; expanded n64/100:10,842. Check counts and exact values/digests are in JSON. Display decimals and logarithms are ordinary float diagnostics, not interval certificates; the positivity, partition, gates, and enclosures are exact.

| n | old337 G outside lower | outside/all G lower | ε=1 outside lower | ε=1/2 outside lower |
|---:|---:|---:|---:|---:|
|4,9,16|0|empty gate|0|0|
|25|0.914611514|0.972245202|0|0|
|36|2.748949115|0.995966647|2.001204790|0|
|64|8.593915032|0.999966443|7.767603817|0|
|100|17.761143421|0.999999897|16.891014085|5.254913091|

The root-alpha enclosures certify strictly positive outside volume for all 4,707 evaluated shell pairs. The new ε=1 gate is empty through n25 and nonempty at n36,64,100; ε=1/2 is nonempty only at n100 among tested dimensions. The global outside massgap integral is at least δ^n times each central value. For ε=1, the log10 of this lower bound divided by W is −99.073918, −191.768910, −319.184343 at n36,64,100; ε=1/2 at n100 gives −319.691433. These are lower bounds from an exponentially small source subset, not estimates of the full integral or an extremal ratio.

## Source concentration versus crowding

A cheap additional exact past-gate scan reuses the actual field with δ∈{1/(4n),1/n,2/n,4/n,1/8} for n25,64,100. It recomputes physical shell volumes and J, but deliberately does not recompute G or center volumes at changed δ.

| n | max past at δ=1/(4n) | at 1/n | at 2/n | at 4/n | at 1/8 |
|---:|---:|---:|---:|---:|---:|
|25|7.481108|4.128191|1.851238|0.360982|0.741806|
|64|21.586056|12.280481|5.825567|1.338546|0.075379|
|100|35.130697|20.162830|9.710024|2.323060|0.007185|

At n25 the old gate disappears already at δ=1/n. At n64/100, both the old and ε=1 gates survive δ=1/n but disappear at δ=2/n. At n100 the ε=1/2 gate disappears at δ=1/n. For example, changing δ from 1/(4n) to 1/n raises the central source/W fraction by 4^n, yet leaves that fraction about 10^-154.13 for n64 and 10^-260.21 for n100. Thus this fixture genuinely reaches the center-outside, high-past branch, while enlarging its shared source region suppresses crowding. It motivates studying the cost of shared-source concentration, rather than treating high crowding as impossible or treating this tiny-region lower bound as a global obstruction.

All source support remains Q4. No full-source F or reverse loss is inferred from the central-source calculation; no dimension asymptotic is fitted. The tested new h values are ε=1 and 1/2, not an arbitrarily small absorption ε.
