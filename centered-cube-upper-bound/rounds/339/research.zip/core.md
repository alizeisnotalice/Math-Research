# R339 — one shared overlap envelope for selected outer mass windows

**Status.** This note proves a joint-window receipt for a specified part of the actual G_out. It uses the real overlap I_uv and one receiver envelope for the UNION of the selected mass windows, instead of adding a separate envelope per window. It is a limited application of the existing real-dx mass-envelope method, not a new global root proof. Adjacent windows covering the entire old mass range still have order-n total logarithmic cost. No quadratic window saving or universal source-overlap sparsity is proved.

## 1. Original target and a source-independent window choice

Keep exactly the R338 hard contract and G_out: f≥0 in L¹, actual receiver du on finite E, m_u=∫_{Q_u}f=q_uR(u)^n, q_u∈[q_-,λ], q_-=3λ/4, a≤R≤b≤2a, dμ=du/m, original c_u, E_r, J_y(r), H, and ell. Let

\[
 K=e^{\sqrt n}>\lambda/q_-,\quad
 h=\frac{1+\sqrt n}{\varepsilon q_-},\quad
 \alpha^n=1+\sqrt n,\quad X_q=\int_Eq_u du.
\]

The original gates in G_out are m_u>K m_v, strict global past
`Z_y(m_u/K−)>h`, and `‖v−u‖∞>αR(u)/2`, as well as all original physical prefixes and H. None is reset.

For each u select a measurable finite union of disjoint closed mass windows

\[
 S_u=\bigcup_{j=1}^{N(u)}[a_j(u),b_j(u)],\qquad
 0<a_1\le b_1<a_2\le b_2<\cdots<a_N\le b_N.
\]

Touching or overlapping intervals are first merged. The selection may depend on u and the frozen field, but not on y or the running physical clock r. Empty S_u is allowed. Let G_{out,S} be the original G_out with the extra gate m_v∈S_u. The exact positive complement is G_{out,S^c}. Endpoints in S_u belong to the selected part; the original strict far-mass and strict past gates stay strict.

Define the dimensionless union capacity

\[
 \mathcal C(S)=1+\sum_{j=1}^N\log(b_j/a_j)
       +\sum_{j=2}^N(1-b_{j-1}/a_j),\qquad
 \mathcal C(\varnothing)=0.                                 \tag{1}
\]

## 2. A joint real-dx envelope, including gap sharing

For every fixed y and u,

\[
 \boxed{\int_E c_v(y)1_{m_v\in S_u}d\mu(v)
             \le\mathcal C(S_u)/q_-.}                      \tag{2}
\]

To prove this, set t=(2‖v−y‖∞)^n, whose sublevel cube has volume t. Capture implies m_v≥q_-t. If m_v∈S, the density 1/m_v is at most

\[
 w_S(t)=\frac1{\min\{m\in S:m\ge q_-t\}},
\]

with value zero when that set is empty. At t=0 use 1/a_1. This is one majorant for the entire union, not a sum of window majorants. Its exact integral is

\[
 \begin{aligned}
 \int_0^\infty w_S(t)dt
 &=\frac1{q_-}
   +\sum_j\frac1{q_-}\log(b_j/a_j)
   +\sum_{j\ge2}\frac{a_j-b_{j-1}}{q_-a_j}\\
 &=\mathcal C(S)/q_-.
 \end{aligned}                                             \tag{3}
\]

The first term is the central interval [0,a_1/q_-]. On a mass window the majorant is 1/(q_-t); on the gap from b_{j-1}/q_- to a_j/q_- it is the constant 1/a_j. This also handles point windows a_j=b_j and all receiver mass atoms. Only receiver Lebesgue measure is bounded. The formula is an exact integral of this majorant, not a claim that it is optimal among matched actual fields.

The common-source identity gives the corresponding weighted center-volume estimate

\[
 \begin{aligned}
 \int_{m_v\in S_u}\frac{I_{uv}}{m_v}dv
 &=\int_{Q_u}f(y)
          \int_{m_v\in S_u}c_v(y)d\mu(v)dy\\
 &\le\frac{\mathcal C(S_u)}{q_-}m_u,
 \qquad I_{uv}=\int f c_uc_v.                              \tag{4}
 \end{aligned}
\]

This controls actual overlap-weighted receiver volume even when the unweighted outer-center set is large. There is no substitution of boundary volume for f-mass and no f-density cap.

## 3. Receipt for the original outer integral

On the original high-past gate J_y(r)>h: the strict small-mass receivers are already present because K>λ/q_- implies R(v)<R(u). Use 1/J≤1/h BEFORE dropping that gate, then positively drop the other gates when taking an upper bound and use m_u−m_v≤m_u. Applying (4) and finally the original inclusive ell tail gives

\[
 \begin{aligned}
 G_{out,S}
 &\le\frac1h\int_Edu\,R(u)^{-n}
      \int_{m_v<m_u/K,\,m_v\in S_u}\frac{I_{uv}}{m_v}dv\\
 &\le\boxed{\frac1{q_-h}\int_Eq_u\mathcal C(S_u)du.}       \tag{5}
 \end{aligned}
\]

The first line retains the necessary radius ordering when integrating the physical tail. The upper estimate may then enlarge the v domain to the windows. All original physical atoms and H are retained on the left; none is split. The exact partition is

\[
 G_{out}=G_{out,S}+G_{out,S^c}.                              \tag{6}
\]

At the specified h, (5) becomes

\[
 G_{out,S}\le\frac{\varepsilon}{1+\sqrt n}
                  \int_Eq_u\mathcal C(S_u)du.              \tag{7}
\]

In particular any single remote old window [s(u),K s(u)] costs at most εX_q, regardless of how far it lies below m_u/K and including all its outer centers. More generally a union with `C(S_u)≤1+√n` has the same receipt. This does not require the window to be near m_u, nor the small center to lie inside the large cube. It also does not guarantee that a selected window carries a fixed fraction of G_out.

## 4. Exact multiple-window cost and the unresolved global issue

The independently charged window sum would be
`Σ_j[1+log(b_j/a_j)]`. Formula (1) subtracts exactly

\[
 \sum_{j=2}^N b_{j-1}/a_j
\]

from that naive fee. This is a valid shared-envelope saving, not orthogonality or a quadratic source gain. Adjacent windows merge: a partition of [s,K^Ns] has total capacity `1+N log K`, not `N(1+log K)`. Thus N≈√n consecutive windows of width K=e^{√n} still cost order n, so (7) alone does not pay the whole old range at root size.

A simple full-old-range majorant, for a given u with m_u/K>q_-a^n, is the single interval
`[q_-a^n,m_u/K]`. Its capacity is

\[
 1+\log\frac{m_u}{Kq_-a^n}
 \le1+n\log(b/a)+\log(\lambda/q_-)-\log K,                 \tag{8}
\]

which is still order n in the worst octave case. Strict upper endpoints only decrease the true traffic and do not change this numerical majorant.

There is also an important nonemptiness check. If S_u contains ALL actually capturing old masses for every y and its capacity is at most 1+√n, then (2) would give
`Z_y(m_u/K−)≤(1+√n)/q_-`. For 0<ε≤1 this is at most h, so the high-past gate is empty. Therefore a low-capacity cover of the entire old spectrum cannot be advertised as a nontrivial full solution of the current high-past problem. Selected low-capacity windows can carry traffic precisely because other old windows still supply the high occupancy.

Replacing linear window weights by their squares is not licensed by (4). The positive traffic and this envelope are homogeneous of degree one in a common weight. A putative purely quadratic-weight receipt with no additional debit would already violate that scaling whenever the selected traffic is nonzero. This does not rule out a proof using the original coupled square and a fully accounted cross term; no such cross-term estimate is obtained here.

Accordingly (5)–(7) give a limited paid selected-window component with an exact union fee and actual complement. The general G_out root budget remains unproved. The unresolved step is a genuine joint-source improvement beyond the linear capacity of a full old spectrum, rather than another arbitrary subdivision or a claim that the O(log n) posterior column upper bound supplies coverage.

## 5. Ledger and verification

The receipt adds no source-mass fee and no λH completion for the selected part: its cost is the explicit receiver term (5). It is an alternative to applying the R338 center-volume bound on the same traffic; any combination must first make the pair gates disjoint. For an outer multiplier M, (7) is multiplied by M; it does not absorb M for free. The source and entrance fees already in the R338 ledger remain unchanged, as does G_{out,S^c}.

Local verification actually run: `/tmp/r339_core_checks.py` checked 40 finite window families, including point windows, genuine gaps and adjacent subdivisions. All 1,178 assertions passed. Exact Fraction checks verified the pointwise shared majorant, and 70-digit Decimal checks verified its integrated capacity, the exact saving relative to separate windows, merge invariance and dimension cancellation for n=1,2,8,64, at tolerance 10^-60. The largest identity discrepancy was 7.72×10^-68. These are envelope/algebra diagnostics, not actual-source high-past traffic measurements or evidence of a global root bound.

Only `/tmp/r339_core.md` and `/tmp/r339_core_checks.py` are authored; no other files or Git state are changed. Bounded delivery stops here.
