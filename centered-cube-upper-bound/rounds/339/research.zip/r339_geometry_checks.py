import math, random
random.seed(339)
checks=0
maxerr=0.0
for n in [1,2,4,8,16,32,64,128]:
 for j in range(100):
  a=math.exp(random.uniform(-2,2)); b=a*random.uniform(1,2)
  lam=math.exp(random.uniform(-1,1)); qm=.75*lam
  x=random.uniform(0,1); z=random.uniform(x,1)
  rl=a*(b/a)**x; rh=a*(b/a)**z
  L=lam*rl**n; U=qm*rh**n
  if U<L: continue
  lo=max(a,(L/lam)**(1/n)); hi=min(b,(U/qm)**(1/n))
  if hi<lo*(1-1e-12): continue
  # Physical b atom plus continuous ell above hi, for A(r)=hi**n.
  terminal=(hi/b)**n + (1-(hi/b)**n)
  assert abs(terminal-1)<1e-12
  C=terminal+n*math.log(hi/lo)
  bound=1+math.log(lam*U/(qm*L))
  assert C<=bound+1e-10
  # Stable log-coordinate quadrature of A(r) n r^{-n-1} dr on [lo,hi].
  steps=127
  quad=sum(n*math.log(hi/lo)/steps for _ in range(steps))
  maxerr=max(maxerr,abs((1+quad)-C));checks+=3
for n in [1,2,4,8,16,32,64,128]:
 eta=math.exp(-math.sqrt(n))
 assert abs((1+math.log(1/(.75*eta)))-(1+math.sqrt(n)+math.log(4/3)))<1e-12
 checks+=1
print({'passed':checks,'max_quadrature_error':maxerr,'note':'scalar tail and log-window checks only; no proof by numerics'})
