# R339 auxiliary: reverse actual-center packing, and its missing bound

This is a short route record, not a new unconditional payment. Use the full matched hard-slot contract and G_{K,>h} of `/tmp/r338_main.md`, with K>λ/q_-, h>0, arbitrary finite nonnegative L1 f, true receiver du, q_u∈[q_-,λ], m_u=q_u R_u^n, and the unchanged full J, H, and ell. In particular ell([R,b])=R^{-n}, including the b atom. The original domination from ν≤f to this full f-slot is the one already justified in R337; no arbitrary source mask is moved through that matching identity.

## Exact reverse packing receipt

Let D(u,v) be a measurable ordered receiver gate independent of source y and physical prefix r. Define

    C_D(v)=∫_{u∈E:m_u>K m_v} D(u,v)
       1_{||u-v||∞≤(R_u+R_v)/2} R_u^{-n} du.

For the exact positive subtraffic G_D of G_{K,>h},

(1)  G_D≤(1/h)∫_E C_D(v)dv.

Thus, if an actual receiver-geometry argument certifies C_D(v)≤L for almost every v, then

(2)  G_D≤L|E|/h≤L X_q/(q_-h).

The integral in (1), rather than a uniform bound, is also a valid heterogeneous bill. The same receiver dv is charged once. A union of gates must use its actual union indicator, rather than retain each coverage while omitting its multiplicity.

**Proof.** Strict m_v<m_u/K implies R_v<R_u, so the global strict small-mass past has fully entered every active original prefix. On its high-past gate J>h. Set I_uv=∫f c_uc_v. Using 1/J≤1/h before dropping that gate, then integrating the actual physical tail and the common source, gives

    G_D≤(1/h)∬_{m_u>K m_v} D(u,v) R_u^{-n}
                (1-m_v/m_u) I_uv/m_v du dv.

Here I_uv/m_v≤1, and I_uv=0 unless the two physical cubes intersect. Their possible-center intersection condition is precisely the indicator in C_D. Positive Tonelli proves (1). No source density, fixed-scale convolution, independent source, or receiver outside-radius cap is used. All physical radius atoms are included through the original tail identity, and H is unchanged. The genuine complement is exactly G_{K,>h}-G_D, a positive original integral with D^c.

## Why this has not supplied an additional root budget

Equation (1) is the reverse ordering of the heterogeneous center-volume bill already present in R338. Merely naming C_D or assuming it small is not a new estimate. Its possible use would require an independent, checkable upper bound on this actual local receiver packing, especially after restricting D to the genuine R338 outside region

    ||u-v||∞>αR_u/2,  α=(1+√n)^{1/n}.

No general root-order bound on that packing has been established here. Actual q caps control f(Q_u), not the density of f on the overlap cap, so they do not justify replacing I_uv by a geometric volume fraction.

Literal reverse center inclusion u∈Q_v yields no new region: R_v<R_u implies ||u-v||∞≤R_v/2<R_u/2, hence it was already in the R338 paid region. A uniform reverse dilation also supplies no enlargement at the same uniform volume budget. Indeed, let β_K=(λ/(Kq_-))^{1/n}<1. The mass gap gives R_v<β_K R_u, so u∈tQ_v implies ||u-v||∞<tβ_KR_u/2. A budget t^n β_K^n≤L therefore puts this whole region inside the forward dilation with side multiplier L^{1/n}, already paid by R338. A local actual-E packing estimate could improve on this uniform comparison, but one has not been proved.

For a source-dependent center gate D_y(u,v), the legal intermediate expression instead retains

    ∫f(y)c_u(y)c_v(y)D_y(u,v)dy / m_v.

A volume condition holding separately for each y cannot be substituted for C_D after this integration. This is exactly the additional three-point/source-overlap estimate still needed; it cannot be obtained by silently treating D_y as one receiver-only gate.

A local Python Fraction run checked 60 reverse/forward dilation budget identities in n=1,2,4,8,16. This was scalar algebra only, not evidence for the missing packing estimate. No new fixture, operator counterexample, or root closure is claimed. The bounded conclusion is the valid reverse actual-packing receipt (1), together with the precise absence of a new unconditional bound for the genuine outside-center complement.
