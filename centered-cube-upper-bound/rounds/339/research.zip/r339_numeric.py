#!/usr/bin/env python3
"""Certified center/outside tensor pair volumes for genuine dx crowded shells."""
from fractions import Fraction as F
from math import factorial,lcm,log10
from pathlib import Path
from collections import Counter
import json,hashlib
BASE=Path(__file__).resolve().parent
C=Counter()
def ck(k,v):C[k]+=1;assert v,k
def expbounds(k):
 lo=sum((F(k**j,factorial(j)) for j in range(161)),F(0));return lo,lo+F(k**161,factorial(161))/(1-F(k,162))
def brief(x):
 a=abs(x.numerator)
 if max(a.bit_length(),x.denominator.bit_length())<1200:return str(x)
 raw=(str(x<0)+':'+str(a.bit_length())+':').encode()+a.to_bytes((a.bit_length()+7)//8,'big')+b'/'+x.denominator.to_bytes((x.denominator.bit_length()+7)//8,'big')
 return dict(decimal=float(x),sha256=hashlib.sha256(raw).hexdigest(),encoding='negative:numerator_bitlength:unsigned_numerator_bytes/unsigned_denominator_bytes')
def rootbounds(k,n):
 den=1<<48;lo=den;hi=2*den;target=(k+1)*den**n
 while lo<hi:
  mid=(lo+hi+1)//2
  if mid**n<=target:lo=mid
  else:hi=mid-1
 ck('root_alpha_enclosure',lo**n<=target<(lo+1)**n)
 return lo,lo+1,den

def cap_raw(S,T,U,anum,aden):
 # Receiver sides S/(4n),T/(4n); center threshold alpha*Ri/2, Ri=U/n.
 # All breakpoints have unit1/(8n*aden), so this is exact length^2 numerator.
 b=(S+T)*aden;a=abs(S-T)*aden;c=4*anum*U;q=min(c,b);p=min(c,a)
 return 2*b*q-q*q-(2*a*p-p*p)
def shell_inside(Vi,Vim,Vj,Vjm,U,anum,aden,n):
 return cap_raw(Vi,Vj,U,anum,aden)**n-cap_raw(Vim,Vj,U,anum,aden)**n-cap_raw(Vi,Vjm,U,anum,aden)**n+cap_raw(Vim,Vjm,U,anum,aden)**n

def field(k,delta=None):
 n=k*k;delta=F(1,4*n) if delta is None else delta;rs=[1+F(i,n) for i in range(n+1)];mi=[r**n for r in rs];side=[r-delta for r in rs];vol=[s**n-(side[i-1]**n if i else 0) for i,s in enumerate(side)];w=[v/m for v,m in zip(vol,mi)];J=[];acc=F(0)
 for i in range(n+1):
  acc+=w[i];J.append(acc)
  ck('actual_dx_q1_and_commoncapture',0<delta<1 and side[i]/2+rs[i]/2<2 and side[i]/2+delta/2==rs[i]/2 and 0<w[i]<=1)
 lo,hi=expbounds(k);p=-1;past=[];indices=[]
 for i in range(n+1):
  while p+1<=n and mi[i]>hi*mi[p+1]:p+=1
  ck('strict_mass_boundary',p<i and (p==n or mi[i]<=lo*mi[p+1]))
  past.append(J[p] if p>=0 else F(0));indices.append(p)
 return delta,rs,mi,side,vol,w,J,past,indices

def delta_scan(k):
 n=k*k;out=[]
 for delta in [F(1,4*n),F(1,n),F(2,n),F(4,n),F(1,8)]:
  d,rs,mi,side,vol,w,J,past,p=field(k,delta);z=past[-1];thresholds=[('old337',F(4*k,3)),('new338_eps1',F(4*(k+1),3)),('new338_eps1over2',F(8*(k+1),3))]
  out.append(dict(delta=str(delta),central_source_log10_fraction=n*log10(float(delta)/4),maxpast=brief(z),maxpast_decimal=float(z),gates={name:bool(z>h) for name,h in thresholds},scope='Only strict past gate scan, no center volume or G computation at changed delta.'))
 return out

def case(k):
 n=k*k;delta,rs,mi,side,vol,w,J,past,indices=field(k);thresholds=[('old337',F(4*k,3)),('new338_eps1',F(4*(k+1),3)),('new338_eps1over2',F(8*(k+1),3))];alo,ahi,D=rootbounds(k,n);Rscale=D**(2*n);S=[4*(n+i)-1 for i in range(n+1)];Vnum=[s**n-(S[i-1]**n if i else 0) for i,s in enumerate(S)]
 # Exact axis checks at full support; outer+inner recovery is also checked per pair.
 for i,j in [(0,0),(n,0),(n,n)]:
  raw=cap_raw(S[i],S[j],n+i,4*D,D)
  ck('axis_full_support_recovery',raw==4*S[i]*S[j]*D*D)
 active=[i for i,z in enumerate(past) if z>thresholds[0][1]];stats=Counter();rows=[]
 if active:
  ell=[mi[i]**-1-(mi[i+1]**-1 if i<n else 0) for i in range(n+1)];tau=[e/j for e,j in zip(ell,J)];clockden=lcm(*(t.denominator for t in tau));tn=[t.numerator*(clockden//t.denominator) for t in tau];suffix=[0]*(n+1);acc=0
  for i in range(n,-1,-1):acc+=tn[i];suffix[i]=acc
  L=lcm(*range(n,2*n+1));Lp=L**n;Lp_over=[(L//(n+i))**n for i in range(n+1)];denbase=(8*n)**(2*n)*Lp*Lp*clockden
  # Numerators for each endpoint: total, alpha1 inside, root-alpha lo/hi inside.
  endpoint={}
  for i in active:
   vals=[0,0,0,0]
   for j in range(indices[i]+1):
    total=Vnum[i]*Vnum[j]*2**(2*n);in1=shell_inside(S[i],S[i-1] if i else 0,S[j],S[j-1] if j else 0,n+i,1,1,n);inlo=shell_inside(S[i],S[i-1] if i else 0,S[j],S[j-1] if j else 0,n+i,alo,D,n);inhi=shell_inside(S[i],S[i-1] if i else 0,S[j],S[j-1] if j else 0,n+i,ahi,D,n)
    ck('true_shell_center_volume_enclosure',0<=in1<=total and in1*Rscale<=inlo<=inhi<=total*Rscale)
    out1=total-in1;outlo=total*Rscale-inhi;outhi=total*Rscale-inlo
    ck('inner_outer_pair_recovery',in1+out1==total and inhi+outlo==total*Rscale and inlo+outhi==total*Rscale)
    coefficient=n**n*((n+i)**n-(n+j)**n)*Lp_over[i]*Lp_over[j]
    for a,v in enumerate([total,in1,inlo,inhi]):vals[a]+=coefficient*v
    stats['actual_shell_pairs']+=1;stats['root_outside_positive_certified_pairs']+=outlo>0
   endpoint[i]=[v*suffix[i] for v in vals]
  for name,h in thresholds:
   nums=[sum(v[a] for i,v in endpoint.items() if past[i]>h) for a in range(4)];total,I1,Il,Iu=nums;out1=total-I1;outlo=total*Rscale-Iu;outhi=total*Rscale-Il
   ck('center_partition_restores_total_G',0<=outlo<=outhi<=out1*Rscale and I1+out1==total and Iu+outlo==total*Rscale)
   # Independent exact R338 prefix gap formula in the same integer ring.
   Zden=4**n*Lp;hnums=[(v*Zden).numerator for v in w];pnums=[];acc=0
   for v in hnums:acc+=v;pnums.append(acc)
   running=direct=0
   for i in range(n+1):
    p=indices[i];gap=hnums[i]*((n+i)**n*(pnums[p] if p>=0 else 0)-(S[p]**n if p>=0 else 0)*Lp)
    if past[i]>h:running+=gap
    direct+=tn[i]*running
   # G denominator from R338 is Zden^2*n^n*clockden.
   den338=Zden*Zden*n**n*clockden
   ck('recovers_original_338_gap_exact',total*den338==direct*denbase)
   G=F(total,denbase);A1=F(out1,denbase);lo=F(outlo,denbase*Rscale);hi=F(outhi,denbase*Rscale);insideLo=F(Il,denbase*Rscale);insideHi=F(Iu,denbase*Rscale)
   ck('positive_gate_outside_nonempty',(lo>0)==any(z>h for z in past))
   rows.append(dict(gate=name,h=str(h),central_Gtotal=brief(G),central_Gtotal_decimal=float(G),alpha1_outside_exact=brief(A1),alpha1_outside_decimal=float(A1),root_alpha_inside_lower=brief(insideLo),root_alpha_inside_upper=brief(insideHi),root_alpha_outside_lower=brief(lo),root_alpha_outside_upper=brief(hi),root_alpha_outside_lower_decimal=float(lo),root_alpha_outside_upper_decimal=float(hi),root_outside_fraction_lower=float(lo/G) if G else 0.0,root_outside_fraction_upper=float(hi/G) if G else 0.0,outside_genuine_central_source_nonempty=lo>0,log10_global_Goutside_lower_over_W=log10(float(lo))+n*log10(float(delta)/4) if lo else None,full_source_outside_lower=brief(delta**n*lo)))
 else:
  for name,h in thresholds:rows.append(dict(gate=name,h=str(h),central_Gtotal_decimal=0.0,root_alpha_outside_lower_decimal=0.0,root_alpha_outside_upper_decimal=0.0,outside_genuine_central_source_nonempty=False,globally_empty_by_past_max=True))
 out=dict(n=n,k=k,source_delta=str(delta),central_source_volume=str(delta**n),full_source_W=str(4**n),alpha_root_lower=str(F(alo,D)),alpha_root_upper=str(F(ahi,D)),alpha_root_power_target=1+k,past_max=brief(past[-1]),past_max_decimal=float(past[-1]),pair_stats=dict(stats),gates=rows,delta_past_scan=delta_scan(k) if n in [25,64,100] else [],scope='TRUE receiver dx, true uniform source; same pairvolume for every source y in Qdelta, not only zero. Full source outside integral is lower-bounded by this subset, not evaluated.')
 print(json.dumps(dict(n=n,done=True,old_gate_Gout_lower=rows[0]['root_alpha_outside_lower_decimal'])))
 return out

def main():
 rows=[];stages=[]
 for stage,ks in [('empty',[2,3,4]),('onset',[5,6]),('expanded',[8,10])]:
  before=sum(C.values());rows.extend(case(k) for k in ks);stages.append(dict(stage=stage,dimensions=[k*k for k in ks],exact_checks=sum(C.values())-before))
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),stages=stages,models=rows,scope='Exact tensor center split with rational alpha enclosures; highpast/J/ell/massgap intact. Each threshold row is valid only for H<=that row h (including H=h): retained endpoints have J>past>h, so all future H gates are automatic. Not valid for H>h. Positive central source lower bounds only; no full extremizer/root/history claim.')
 (BASE/'r339_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),stages=stages),sort_keys=True))
if __name__=='__main__':main()
