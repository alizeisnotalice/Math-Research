# R339 independent preauthor screen — exact center-gated shell geometry

Owned only /tmp/r339_audit.md; no Git/other-author edits. Derived before reading any R339 numeric/author proof. Actual source f=1_Q4, q1 shell receiver field with side radii r_i and nested outer sides A_i=r_i-delta, central source Q_delta. Full J/H/global-past/ell/mass gates stay original; this is a computation of their central positive-source contribution, not a general root receipt.

## Formula and source contract: PASS

For centered intervals of nonnegative SIDE lengths A,B and d>=0, the rectangle measure |{(u,v):u inI_A,v inI_B,|u-v|<=d}| is

 F(A,B,d)=AB-[( (A+B)/2-d )_+²-( (|A-B|)/2-d )_+²].

This subtracts the two symmetric outside-corner pieces; there is no missing1/2 or2. It gives0 atd0, AB for d>=(A+B)/2, and handles zero side lengths by cancellation. For cubes and an infinity-norm center gate with a SINGLE constant d on this receiver pair, the full pair measure is F(A,B,d)^n by coordinate factorization. For actual shells S_i=Q_Ai minusQ_A(i-1), S_j analogously, their center-INSIDE measure is EXACTLY

 I_ij(d)=F(A_i,A_j,d)^n-F(A_(i-1),A_j,d)^n-F(A_i,A_(j-1),d)^n+F(A_(i-1),A_(j-1),d)^n.

The i0/j0 inner sides are0. Its total pair measure is T_ij=(A_i^n-A_(i-1)^n)(A_j^n-A_(j-1)^n); outside= T_ij-I_ij(d). This is a genuine measurable nested-shell pair integral, so0<=I_ij<=T_ij and it is nondecreasing in d, notwithstanding its signed expansion. For d_i=alpha*r_i/2, actual R_i is constant on shelli, so d_i is independent of the centers being integrated and the factorization applies. If radius varied within a shell this direct single-F product would not apply without another partition/integration.

## Interval direction and cancellation guards

For certified rational alpha_lo<=alpha<=alpha_hi, compute the COMPLETE signed shell expression at d_lo=alpha_lo*r_i/2 and separately at d_hi. Monotonicity of the actual shell event gives

 I_ij(d_lo)<=I_ij(d_true)<=I_ij(d_hi),
 T_ij-I_ij(d_hi)<=O_ij(d_true)<=T_ij-I_ij(d_lo).

Use one common endpoint d per full signed expression; do not silently choose endpoints on individual terms and then treat the cancellation as if all were evaluated at that d. Ordinary interval arithmetic with correct negative-coefficient endpoint reversal can give a wider valid bound, but is not the tight monotonic full-expression bracket. Exact rational evaluation controls catastrophic cancellation; a lower bound may legitimately be0 when the alpha interval is too wide to certify positivity. Exact bounds0 andT_ij can be intersected afterward because the geometric range is proved.

For n=k², alpha^n=1+k has exact rational root enclosures certified by alpha_lo^n<=1+k<=alpha_hi^n. For other n a separate certified sqrt(n) enclosure is needed. A floating root or decimals cannot decide a strict positive/empty outside classification. Center-boundary equalities have receiver-pair Lebesgue measure0 here; nevertheless inside uses<= and outside> consistently.

## Actual central-source integral and limitations

For every y inQ_delta, every receiver shell point captures y, because A_i/2+delta/2=r_i/2. Thus all central y have the same full J_r, global strict mass past and original high gate. With m_i=r_i^n, high-past eligibility of the large endpoint and strict mass gate fixed BEFORE center integration, its exact central outside contribution is delta^n times

 sum_r ell_r/J_r *1{J_r>=H} sum_(i,j active,m_i>K m_j,oldpast_i>h)
       (m_i-m_j)/(m_i m_j) * O_ij(alpha*r_i/2).

There is no1/2 in this ordered G formula and no additional source-volume factor elsewhere. All factors are nonnegative, so outside endpoint brackets propagate in their own reversed-alpha direction. Source f=1_Q4 really supplies q1 for all actual receivers because their whole selected cubes lie inQ4. The source-z integration underlying G uses the FULL f; only the remaining outer source-y integral is restricted to centralQ_delta. This is a positive lower contribution to full-source Goutside, not equality with that full integral, not a representative-source average, and not a root/extremal lower bound. W=4^n and the actual central volume must remain in normalized claims.

Parameters h,alpha,K,H must match the target being reported. Old337 threshold computations do not automatically compute the new338 gate; a nonempty high-past branch without center classification does not establish an outside contribution. Empty gates from one-octave mass range or threshold occupancy are valid emptiness facts, not new paid geometry. Later numerical checks must retain all original physical prefixes/ties, terminal atom and exact smaller-mass subtraction.

## Local actual execution

Reviewer used exact Fraction polygon clipping as an independent1D area algorithm for125 interval cases, including zero sides and gate thresholds, then checked189 nested-shell monotonicity/range cases in n1,2,4. All314 exact assertions passed. These are bounded formula diagnostics, not the high-dimensional original G computation or a general proof. No R339 author numeric/proof has been read. Await assigned files for final comparison.

Actual reviewer exact assertion count: 314.


## Short auxiliary reverse-packing comparison

Before reading its proof, independent change of integration order gives exactly the same valid intermediate receipt: after high-past1/J<=1/h and the inclusive Ru tail, G_D<=h^(-1)integral du dv Ru^(-n)(1-mv/mu)Iuv/mv*D. Thus retaining possible cube intersection and Iuv/mv<=1 yields the stated reverse packing C_D(v). This is not a new root estimate merely by naming that density.

Read complete `/tmp/r339_aux.md`. PASS. The source-overlap ratio is retained before upper bounding, the field/gate is y/r-independent, all original H/J/ell remain, and reverse/forward mass roles are correct. Uniform reverse inclusion or its displayed uniform dilation budget lies inside an already paid R338 forward band, so no new region is double counted. The text retains the possibility of a genuinely sharper LOCAL actual-E packing bound without claiming one. It expressly excludes source-dependent center gates from this receiver-only Tonelli simplification unless the three-point source-overlap integral is kept. Its60 reported Fraction identities are scalar diagnostics only, not evidence of the missing packing bound.

Auxiliary SHA256: `ef418e2e4cdcbb330ff746656e56e4694887837d71b6d3830b74848e8fb25f4c`.

Await final main/numeric scope; no new target payment or root closure follows from this route record.


## Independent source-heavy endpoint payment screen (before author proof)

PASS for0<eta<=1, W=integral f>0, and the SAME original hard-matched G_out. If W0 the selected positive-q receiver field is empty/trivial. Restrict only the large actual endpoint by m_u>=eta W. Dropping the nonnegative outside/high-past/high-H gates AFTER using the original ratio form, (m_u-m_v)<=m_u and the actual smaller endpoint posterior fraction/J<=1 give

 G_heavy<=integral f(y)ell(dr)V_y^heavy(r)dy.

The ORIGINAL mass m_u=f(Q_u) obeys eta W<=m_u<=W and q_u in[q_-,lambda]. Hence actual heavy radii lie in[A,B], A^n=eta W/lambda, B^n=W/q_-. Intersect with[a,b]; no new averaging radius or cap at A/B is being asserted. For each y, the capturing receiver centers at prefix r are contained in Q_min(r,B)(y), and no heavy receiver exists below A. With a'=max(a,A), b'=min(b,B), the original full ell integral is at most1+nlog(b'/a') when a'<=b', and0 otherwise. The leading1 is essential: it contains the full tail above b', including original b atom, and also covers a'=b' singleton-radius fields. Therefore it is at most1+log(lambda/(eta q_-)), and

 G_heavy<=[1+log(lambda/(eta q_-))]W.

The argument is actual receiver CENTER volume integrated against the SAME f, with no source-density cap, no private source, no extra epsilon X_q and no A_n factor. It applies to the original G_out subdomain by positive domination and preserves every remaining original factor in the light complementary subdomain. eta=exp(-sqrt(n)) gives1+log(lambda/q_-)+sqrt(n), a root source price. This is a genuine additional LOCAL mass/W gate; the fixed physical octave range for m alone does not say every endpoint is heavy. Existing broad uniform-source shell examples may have no such endpoint; no usefulness/coverage fraction is inferred.

The source-heavy part and light part must be a positive PARTITION of the residual AFTER the R338 payments, not a second bound added to the same entire G. The original2epsilon X_q receipt and its source coefficient/outer fees remain; the present source-only payment adds no absorption epsilon.

Component caution: an already legal source-isolated block with source f_j, W_j and matched ORIGINAL captured masses m_u<=W_j permits the same window proof and pays its source mass once. Mere source partition sum W_j<=W does NOT prove m_u<=W_j for original full-f cubes. If only the outer source-y measure is restricted to f_j while m_u is still full-f mass, the upper radius remains(W/q_-)^(1/n) and the block bound has the extra log(W/W_j), not the claimed isolated-block constant. Such terms cannot be dropped by selecting a favourable partition. A component application therefore needs a genuine prior allocation/matching or separately verified original mass upper bound per block; original J and q must not be reset. The global full-W theorem requires none of that decomposition.

No global root closure or estimate of the still-light outside-center shared-source traffic is implied. Await author source-heavy proof and final integration bytes for comparison.


## Final author comparison and scope review — PASS

The earlier “await” statements record the independent preauthor stages. They are superseded by this final review. Read the final complete geometry, core, auxiliary, numeric code/notes/result, main and ledger; only this audit file was modified. No Git or other-author edits, no repeat full numeric pipeline, no TeX compilation or typesetting certification.

### New source-heavy receipt

The final geometry proof agrees with the independent screen above. For a general positive window [L,U], the selected actual radii are in [max(a,(L/lambda)^(1/n)),min(b,(U/q_-)^(1/n))]. The original small endpoint is absorbed using its full original J before the center-volume estimate. The actual inclusive ell tail equals the inverse n-th power at the clipped upper radius, including singleton windows and the terminal b atom. Consequently the coefficient is exactly 1+n log(R_+/R_-), with no missing tail constant or multiplicative lambda/q_- loss. The source is the same full f and m_u=f(Q_u), not an independently selected source. Optional positive restrictions of outer y do not alter original mass endpoints. The component statement requires the displayed real source-isolation hypothesis; no favorable partition is asserted to exist. This is a valid generally applicable positive subdomain payment, leaving light outside-center traffic unbounded.

The final geometry diagnostic disclosure is accurate: the saved script's reported 1415 consists of 946 ordinary floating-point assert evaluations and 469 recorded quadrature errors, not 1415 exact assertions. The parent reports actual replay and maximum recorded error 1.7763568394002505e-15. The analytic receipt does not depend on these finite diagnostics.

### Selected-window core and reverse auxiliary

Read full core proof and reproduction script. The joint-window radial density majorant has central cost 1/q_-, logarithmic window costs and constant-density gap costs. Its exact integrated capacity is the displayed C(S); point windows and mass atoms are allowed. Window choice must be measurable and independent of y and the running clock. The overlap I_uv is integrated against the same f before receiver-volume domination. Radius ordering is retained until the original inclusive Ru tail is used. Formula (5) is therefore valid. It is a separate selected-pair receipt, not an extra free absorption budget in the main conclusion. Full old-spectrum coverage retains order-n cost; a low-capacity cover of all actual past captures would instead contradict the retained high-past gate. The reverse auxiliary is the same heterogeneous center-packing bill reordered, not a new general packing bound.

Parent replay scope: core 1178 = 538 exact Fraction assertions + 640 ordinary 70-digit Decimal comparisons; no interval certification is inferred from the latter. Auxiliary 60 Fraction identities remain author-reported scalar diagnostics and are not counted as a primary replay or evidence of the missing packing estimate.

### Actual shell numeric code and final H correction

Read the complete numeric script, notes and final result metadata. The implementation uses actual receiver Lebesgue shell volumes, a full compact L1 source 1_Q4 and the retained positive source box Q_delta. Exact integer scaling implements the interval-pair formula, tensor power and complete four-term shell inclusion-exclusion. It evaluates all four terms at the SAME rational alpha endpoint; the outside bound reverses the inside endpoints. Root bisection inequalities are exact. Small-mass subtraction is retained, the complete future ell/J clock is used, and an independent prefix expression recovers the original total G. Source factor delta^n occurs once. The source-boundary sets are Lebesgue null; the strict mass/past comparisons are separately certified.

One scope clarification was requested and has been incorporated into the final code/result/notes and ledger: the computed future clock has no explicit high-H indicator. Each threshold row is valid for its H=h, or any H<=that row's h, because a retained endpoint already satisfies J>past>h and all future J are larger. The same displayed numeric values are NOT asserted for H>h. This correction changes disclosure, not the executed arithmetic. The analytic main theorem still allows arbitrary original H.

The parent reports completed local replay of 11920 exact rational/integer assertions, stages 76/1002/10842, and final result metadata independently reads PASS with those counts. Display floats/logarithms are not interval estimates. The computation certifies a central positive-source lower contribution to full G_out, not the full-source integral, the full reverse loss or a global extremal ratio. Epsilon=1 and 1/2 scans do not certify nonemptiness at final absorption epsilon=119/2048. Changed-delta scans only recompute crowding/past, not changed center-gated traffic. The uniform source model may lie entirely in the new light complement; neither its small central source fraction nor its large local traffic settles the general budget.

### Final main and complete ledger

Read /tmp/r339_main.md and /tmp/r339_ledger.md at the hashes below. PASS. Heavy/light is an exact positive partition of the SAME R338 residual; the new heavy source price 1+sqrt(n)+log(4/3) multiplies W once. The original 2epsilon X_q receipt and C_{epsilon,n} remain unchanged. The original entrance doubles this slot, giving the displayed 2G_light+4epsilon X_q and doubled source fee. No additional slot-internal lambda H completion is introduced. The original entrance 8lambda H W_beta and 2d_eff A_n W_nu/H remain. In this hard-matched contraction W is the full matched source (beta=f); domination nu<=f precedes the f-source residual calculation and does not reset its q or J.

The exact outer arithmetic is 4*(128/119)*(119/2048)=1/4, and 1/4+1/256=65/256. This replaces the previous same-slot allowance; it is not accumulated once per research round. The remaining 191/256 is unallocated, not evidence of absorption of the listed unpaid terms. X_q aggregation still needs the same authentic receiver/source/scale ledger; no sum of arbitrary leaf volumes is assumed. The optional selected-window receipt is not additionally charged in the main epsilon ledger. Historical time atoms, general soft crossing/post-crossing terms, full scale/outer/source integration, and especially light high-past far-mass outside-center traffic remain unproved. No general root theorem or closure is certified.

## Frozen final file bindings

The SHA256 values below were computed from local final bytes during this review. The numeric code/notes metadata correction is included. Parent replay reports are recorded as reports of actual execution; the reviewer did not repeat the full pipelines. Reviewer's separate 314 exact formula diagnostics above are not added to the parent's counts.

| File | SHA256 |
|---|---|
| /tmp/r339_aux.md | `ef418e2e4cdcbb330ff746656e56e4694887837d71b6d3830b74848e8fb25f4c` |
| /tmp/r339_core.md | `1add433b5a1ecf46c8ba960789799838c5a18a89a7e2d883b52e3dcb45d4392a` |
| /tmp/r339_core_checks.py | `37408d453b98693a68e6bb5b698361aca932adb905a0baea09cd8ba29a0e09fc` |
| /tmp/r339_geometry.md | `e2771d2b147cfd9378179fc8896f17bd1a2509743c01f5d389706334a3e9a6e7` |
| /tmp/r339_geometry_checks.py | `d5221c2630a7bd8fddf848ac5afb6a223078916d746286dc00ef28bde5f7f7cf` |
| /tmp/r339_numeric.py | `8f2e7ea7797ceae4b9cbdc7e412feffa79d98b998b4f844701a2ed7e5a9dcc53` |
| /tmp/r339_numeric_result.json | `9c250bd4d120754c57650eb8c18c9b1809e80dc384d12897b8fcd0d12ceac970` |
| /tmp/r339_numeric.md | `cd94926c1070b233dffb5e1c9598ca25802daa6c88fc406d4776340dd8b545d8` |
| /tmp/r339_main.md | `0cf564a8ec812548e667be9a90a3506f7f95628e8277adeb846dd048d0dff499` |
| /tmp/r339_ledger.md | `b84737f6451f800dadd0909dbab7bc294aa55310bc141d0c295a318aa0bcf654` |

Final disposition: PASS for these exact contracts, scope disclosures and ledger replacement; no outstanding correction requested. Frozen after final byte binding. Any later content change requires a new binding. No claim of a completed general root budget.
