# R339: a global source-mass window pays a genuine outer branch

## Exact scope and new receipt

Use precisely `/tmp/r338_main.md` and `/tmp/r338_aux.md`: actual Lebesgue receiver set E, arbitrary nonnegative L1 source f, W=∫f, q_-=3λ/4≤q_u≤λ, m_u=q_uR_u^n, a≤R_u≤b≤2a, dμ=du/m_u, the original prefixes J_y(r), and ell=b^{-n}δ_b+n r^{-n-1}dr on [a,b]. All original high-J, strict mass-gap m_u>K m_v, high global past, common-source, and outer-center gates remain in the traffic being estimated. Zero J rows contribute zero. Assume W>0; W=0 admits no positive-measure admissible receiver field.

Let G_out[L,U] denote the original G_out with the additional large-endpoint gate L≤m_u≤U, where 0<L≤U<∞. Define

    R_- = max(a,(L/λ)^(1/n)),
    R_+ = min(b,(U/q_-)^(1/n)).

If R_->R_+, this traffic vanishes. Otherwise

    G_out[L,U] ≤ [1+n log(R_+/R_-)] W
               ≤ [1+log(λ U/(q_- L))] W.                 (1)

The first coefficient retains the physical endpoint improvement. The factor λ/q_- occurs only inside the logarithm in the second coefficient; there is no multiplicative λ/q_- loss here. Formula (1) also holds for any positive restriction of the original source y, with the W on its right replaced by the actual mass of that restricted source. The endpoint masses defining L,U remain the original full-f masses.

Since m_u≤W always, take L=ηW, U=W, 0<η≤1. This gives the exact positive partition and receipt

    G_out = G_out^{heavy(η)} + G_out^{light(η)},
    heavy(η) = {m_u≥ηW},       light(η) = {m_u<ηW},
    G_out^{heavy(η)} ≤ [1+log(λ/(ηq_-))] W.              (2)

In particular, with η=exp(-√n),

    G_out ≤ G_out^{light} + [1+√n+log(4/3)] W.          (3)

This pays all outer centers, all source configurations, and all original gates on the global-heavy branch. It requires neither a density cap for f nor a center-volume bound relative to a particular u. It does not control G_out^{light}.

## Proof, including the original terminal atom

At fixed y,r,u, the inner small-endpoint integral is bounded as follows. Write D(u,v) for the original outer-center gate; all gates below only reduce a nonnegative integral. On a nonzero row,

    (1/J_y(r)) ∫_{E_r:m_v<m_u/K} c_v(y)(m_u-m_v)
                    D(u,v) dμ(v)
      ≤ m_u (1/J_y(r)) ∫_{E_r} c_v(y)dμ(v)
      = m_u.

The high-past and high-J indicators can be deleted positively for this upper bound. Multiplying by c_u(y)dμ(u) leaves exactly c_u(y)du. Consequently

    G_out[L,U] ≤ ∫ f(y)dy ∫ell(dr) A_y(r),
    A_y(r) = |{u∈E : L≤m_u≤U, R_u≤r, y∈Q_u}|.       (4)

There is no resetting of J and no replacement source posterior. Every u counted in (4) has R_-≤R_u≤R_+. For fixed y, a cube Q_u of side at most s capturing y has its actual center in y+[-s/2,s/2]^n. Thus

    A_y(r)=0                         if r<R_-,
    A_y(r)≤r^n                       if R_-≤r<R_+,
    A_y(r)≤R_+^n                     if r≥R_+.

This source-centered box bound is distinct from the R338 bound on v-centers relative to each large u: it is used only after the small endpoint is absorbed into the unchanged original J.

The original physical ell gives

    ∫ell(dr) A_y(r)
      ≤ ∫_{R_-}^{R_+} n dr/r + R_+^n ell([R_+,b])
      = n log(R_+/R_-)+1.                              (5)

For R_+<b the tail term is explicitly

    R_+^n [b^{-n} + ∫_{R_+}^b n r^{-n-1}dr] = 1.

For R_+=b it consists precisely of the actual b atom and is still 1. For R_-=R_+, the continuous middle integral is zero and the tail remains 1; no artificial atom was added at R_+. Actual radius atoms at a or an interior value are already included through A_y(r) and the inclusive physical tail. If R_+=a, the same tail formula remains valid. Tonelli applies to the nonnegative quantities throughout.

Finally,

    n log(R_+/R_-) ≤ log((U/q_-)/(L/λ))
                   = log(λ U/(q_-L)),

which proves (1), and m_u=∫_{Q_u}f≤W proves (2)–(3). The argument does not use the special values of K,h or α, so it applies to the R338 choices without changing them.

## Optional source-isolated components, without a new denominator

A legal localization is available only when a suitable partition is actually supplied. Suppose E is partitioned into a countable measurable family E_j and there are pairwise disjoint measurable source sets S_j such that, for almost every u∈E_j,

    ∫_{Q_u\S_j} f = 0,
    W_j = ∫_{S_j}f > 0,
    Σ_j W_j ≤ W.

These hypotheses mean real source isolation. They are not assumed to follow merely from spatial proximity or a desired grouping of receivers. For u∈E_j, m_u≤W_j, and for f-a.e. y∈Q_u one has y∈S_j. Apply the proof of (1) with u∈E_j, y∈S_j, and mass window [ηW_j,W_j]. Crucially, the inner v integral is still divided by the original full J_y(r); it is bounded by J_y(r) as before, and no component denominator is introduced. This proves

    Σ_j G_out restricted to {u∈E_j, m_u≥ηW_j}
      ≤ [1+log(λ/(ηq_-))] Σ_jW_j
      ≤ [1+log(λ/(ηq_-))] W.                           (6)

The complement is the original traffic with m_u<ηW_j on its actual supplied component. Without a supplied favorable source-isolated partition, only the global W version is asserted. No witness-selection theorem or bounded-reuse theorem is proved here.

## Direct insertion into the R338 result

Retain the R338 choices K=e^{√n}, h=(1+√n)/(εq_-), α=(1+√n)^{1/n}, and its exact C_{ε,n}. Equation (3) gives

    B_H(f,ν) ≤ G_out^{light} + 2ε X_q
              + [C_{ε,n}+1+√n+log(4/3)] W.             (7)

Thus (7) is a strictly enlarged paid part of the same complete hard slot. It is not a general centered-cube weak-(1,1) theorem, and it leaves the root target for the light outer branch unproved. The source-isolated version can replace this light branch only under the explicit hypotheses above.

## Numerical audit and remaining geometric gap

A local Python run, using deterministic seed 339, checked the scalar receipt for randomly sampled admissible windows in dimensions 1,2,4,8,16,32,64,128. It separately checked the original b-atom plus continuous upper tail, the clipped-window logarithmic inequality, log-coordinate quadrature of the middle term, and η=e^{-√n}. The original run reported 1,415 scalar checks, with maximum quadrature discrepancy 1.7763568394002505e-15. These were ordinary Python floating-point diagnostics, not exact-arithmetic certificates and not evidence replacing the measure-theoretic proof above. The unchanged executed code is now saved as `/tmp/r339_geometry_checks.py`; reproduce with `python3 /tmp/r339_geometry_checks.py`. Its counter includes the computed quadrature comparison: there are 946 actual `assert` evaluations and 469 quadrature diagnostics, for 1,415 reported checks; the quadrature discrepancy is recorded rather than asserted.

The parent agent's uniform-Q4 diagnostic has m_max/W≤2^{-n}. In dimensions n≥3, 2^{-n}<e^{-√n}, so this entire diagnostic can lie in the light complement. This receipt therefore does not settle that diagnostic. Its X_q/W is also small according to the parent diagnostic, so the example is not by itself a hard obstruction to a contraction-plus-W estimate.

More broadly, many large endpoints may each capture only an exponentially small fraction of total W, and the contract provides no favorable source-isolated partition. The mass-window proof cannot sum arbitrary windows while charging only one copy of W. To remove the remaining branch, one needs a new quantitative statement such as a true shared-source witness cover whose large-witness source mass has controlled total reuse. Neither high global past nor the outer-center condition has been proved here to supply that statement. In particular, this note does not infer small source mass from a small boundary volume and does not substitute an independent source for the common y.
