"""Round 21: exact geometric/path checks, then finite Poisson expectations.
Python standard library only. Decimal checks are NOT interval certificates.
"""
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from itertools import product
from math import factorial, comb
import json
from pathlib import Path


def exact_checks():
    cases = paths = abel = transfers = 0
    for n, depth, mode in product([1, 2, 4, 16, 64, 256], [0, 12], [0, 1, 2]):
        d = F(1, 32*n)
        a, b, c = F(1), F(4), F(4)-2*d
        ys = [F(0), -d/4, -d/2] if mode < 2 else [F(0), -d/4, F(1)]
        x = F(1, 2) if mode != 1 else -F(1, 2)
        masses = [F(1), F(1, 2**depth), F(3, 7)]
        W = sum(masses)
        cells = [(y+3*d/4)//d for y in ys]
        weights = [sum(m for m,j in zip(masses,cells) if j == i) for i in cells]
        rs = [max(a, 2*abs(x-y)) for y in ys]
        times = sorted(set([a, c]+[r for r in rs if r <= c]))
        full = sorted(set([a, b]+[r for r in rs if r <= b]))
        original = {s: sum(m for m,r in zip(masses,rs) if r <= s)/s**n for s in full}
        M = max(original.values())
        R = min(s for s in full if original[s] == M)
        tau = M*F(3, 4)
        C = (1+2*d/a)**n  # exact bound, no exponential rounding
        for r,w in zip(rs,weights):
            if r <= c:
                assert M*r**n >= w/C
                assert M*r**n >= tau*r**n
        # Exact radial integration: each of two pieces is C.
        for w in weights:
            pivot = w/(C*tau)
            assert tau*w*(pivot/(w/C)**2+1/(tau*tau*pivot)) == 2*C
        for counts in product([0, 1, 4], repeat=3):
            # Atomic Poisson thinning: count j has mean m_j / w_j (kappa=1).
            increments = [w*k-m for w,k,m in zip(weights,counts,masses)]
            X = {s: sum(z/(M*r**n) for z,r in zip(increments,rs) if r <= s) for s in times}
            H = {s: sum(z for z,r in zip(increments,rs) if r <= s)/(M*s**n) for s in times}
            sx = max(map(abs,X.values()))
            assert max(map(abs,H.values())) <= 2*sx
            # Include interior scales; integrate the step process exactly.
            probes = times + [(u+v)/2 for u,v in zip(times,times[1:])]
            for L in probes:
                knots = sorted(set([a,L]+[r for r in rs if a < r < L]))
                integral = sum((v**n-u**n)*sum(z/(M*r**n) for z,r in zip(increments,rs) if r <= u)
                               for u,v in zip(knots,knots[1:]))
                XL = sum(z/(M*r**n) for z,r in zip(increments,rs) if r <= L)
                HL = sum(z for z,r in zip(increments,rs) if r <= L)/(M*L**n)
                assert HL == XL-integral/L**n
                abel += 1
            if R <= c:
                noise = sum(z for z,r in zip(increments,rs) if r <= R)/(M*R**n)
                if abs(noise) <= F(1,2):
                    newM = max(sum(w*k for w,k,r in zip(weights,counts,rs) if r <= s)/s**n for s in full)
                    assert newM > tau/2
                    transfers += 1
            paths += 1
        cases += 1
    return dict(geometry_cases=cases, exact_paths=paths, abel_identities=abel,
                nonvacuous_weak_implications=transfers, dimensions=[1,2,4,16,64,256])


def decimal_checks(precision):
    rows = []
    states = 0
    with localcontext() as ctx:
        ctx.prec = precision
        def dec(q):
            q = F(q)
            return D(q.numerator)/D(q.denominator)
        def tail(lam,j):
            assert j > lam
            return (-lam).exp()*lam**j/D(factorial(j))/(1-lam/D(j+1))
        for n,kappa,depth in product([2,16,256],[1,4],[1,12]):
            lam = D(kappa)
            d = F(1,32*n)
            radii = [F(1),F(1)+d/2]
            p = F(1)-F(1,2**depth)
            ms = [p,1-p]
            Mq = max(p,1/radii[1]**n)
            M = dec(Mq)
            coeff = [1/(M*dec(r)**n) for r in radii]
            Aparts = [dec(m)*v*v/lam for m,v in zip(ms,coeff)]
            A = sum(Aparts)
            J = 6*kappa+32
            ex = eh = et = eat = D(0)
            threshold = A.sqrt()/2
            pN = (-lam).exp()
            pd = dec(p)
            for N in range(J+1):
                if N:
                    pN *= lam/D(N)
                for i in range(N+1):
                    prob = pN*D(comb(N,i))*pd**i*(1-pd)**(N-i)
                    z0 = D(i)/lam-pd
                    z1 = D(N-i)/lam-(1-pd)
                    x0 = z0*coeff[0]
                    x1 = x0+z1*coeff[1]
                    h0 = x0
                    h1 = (z0+z1)*coeff[1]
                    xs = max(abs(x0),abs(x1))
                    hs = max(abs(h0),abs(h1))
                    assert hs <= 2*xs+D(10)**(-precision+10)
                    ex += prob*xs*xs
                    eh += prob*hs*hs
                    stopfirst = abs(x0) > threshold
                    et += prob*(x0*x0 if stopfirst else x1*x1)
                    eat += prob*(Aparts[0] if stopfirst else A)
                    states += 1
            # Bound (N/kappa+1)^2 / M^2 on N>J using factorial moments.
            tail2 = (lam**2*tail(lam,J-1)+(lam+2*lam**2)*tail(lam,J)+lam**2*tail(lam,J+1))/(lam**2*M*M)
            assert ex+tail2 < 4*A
            assert eh+tail2 < 16*A
            assert abs(et-eat) <= tail2+A*tail(lam,J+1)+D(10)**(-precision+15)
            fmt = lambda v: format(v,'.18g')
            rows.append(dict(n=n,kappa=kappa,depth=depth,cutoff=J,
                             terminal_variance=fmt(A),expected_Xsup2_truncated=fmt(ex),
                             expected_Hsup2_truncated=fmt(eh),square_tail_bound=fmt(tail2),
                             stopping_residual= format(abs(et-eat),'.4E')))
    return rows,states


def main():
    exact = exact_checks()
    lo,states = decimal_checks(70)
    hi,states2 = decimal_checks(110)
    # Tiny subtraction residuals depend on precision; compare substantive values.
    for x,y in zip(lo,hi):
        assert {k:v for k,v in x.items() if k != 'stopping_residual'} == {k:v for k,v in y.items() if k != 'stopping_residual'}
    assert states == states2
    result = dict(status='finite tests passed; not a uniform weak-type proof',exact=exact,
                  decimal_precisions=[70,110],count_states_per_precision=states,
                  poisson_cases=hi,rounding='Decimal repetition, not outward-rounded certification')
    path = Path(__file__).with_name('results.json')
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(exact=exact,count_states_per_precision=states,poisson_cases=len(hi)),ensure_ascii=False))


if __name__ == '__main__':
    main()
