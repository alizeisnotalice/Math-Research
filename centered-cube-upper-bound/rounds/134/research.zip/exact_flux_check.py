#!/usr/bin/env python3
"""Frozen R134 Fraction-only scalar/source interface check; no FULL model."""
from fractions import Fraction as F
from pathlib import Path
import hashlib, json
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
EXPECTED_PROTOCOL = '221fb48fe685ad420ce08353635d9fe2c2c07ca37c00e4843526106f124b5c65'
EXPECTED_FA = 'd60f2a676a6527e0d77e6c1180ee0aa9d41657a676a233420de464b5e119a050'
def sha(name):
    return hashlib.sha256((BASE / name).read_bytes()).hexdigest()
assert sha('numeric_protocol.md') == EXPECTED_PROTOCOL
assert sha('fa_time_geometry.md') == EXPECTED_FA
assert not (BASE/'exact_flux_check.json').exists(), 'Recovery output already exists'
FIRST_RUN_FAILURE = dict(run_number=1,exit_code=1,script_sha256='7bde163a46bd4e8b523e88afd0d8d6eefeea4464963137655c6b0fa43b7ef471',
    actual_output='Traceback (most recent call last):\n  File \"/Users/zhengzhihao/Desktop/T/output/centered_cube_round134_20261014/exact_flux_check.py\", line 81, in <module>\n    if cid in (\'I1\',\'I2\',\'I4\'): assert positive_flux>0\n                                       ^^^^^^^^^^^^^^^\nAssertionError\n',
    failed_expectation='I4 was expected nonzero, but observed zero',
    recovery_authorized_by_parent=True,menu_unchanged=True,math_assertions_unchanged=True)
def fs(x): return str(x.numerator) if x.denominator == 1 else f'{x.numerator}/{x.denominator}'
def weight(a,t):
    out=F(1)
    for x in a: out *= min(F(1),x/t)
    return out
alphas = [
    [F(1,1000000)]*64, [F(1)]*64, [F(2)]*64, [F(4)]*64,
    [F(1,2) if i%2==0 else F(3,2) for i in range(64)],
    [F(2)**(i%8-4) for i in range(64)],
]
nu = [F(i,21) for i in range(1,7)]
assert sum(nu)==1
menu = [
('initial','I1',1,F(1),F(2),F(2)),
('initial','I2',2,F(1),F(3,2),F(3,2)),
('initial','I3',4,F(2),F(2),F(1)),
('initial','I4',4,F(1,2),F(1),F(2)),
('known_pressure','P1',16,F(1),F(2),F(2)),
('known_pressure','P2',64,F(1),F(2),F(4)),
('known_pressure','P3',64,F(2),F(4),F(2)**64),
('known_pressure','P4',16,F(3,2),F(2),F(4,3)),
('expanded','E1',64,F(1,2000000),F(1,1000000),F(2)),
('expanded','E2',64,F(4),F(8),F(2)**32),
('expanded','E3',32,F(1),F(17,16),F(17,16)),
('expanded','E4',8,F(1,2),F(1),F(256)),
]
results=[]
for stage,cid,n,t,g,cap in menu:
    aa=[a[:n] for a in alphas]
    wt=[weight(a,t) for a in aa]; wg=[weight(a,g) for a in aa]
    kt=[sum(x<t for x in a) for a in aa]; kg=[sum(x<g for x in a) for a in aa]
    ratio=[wt[i]/wg[i] for i in range(6)]
    et=sum(w*mass for w,mass in zip(wt,nu)); pi=[w*mass/et for w,mass in zip(wt,nu)]
    q=g/t
    assert sum(pi)==1
    atoms=[]
    for i in range(6):
        assert 0<wg[i]<=wt[i]<=1
        assert q**kt[i]<=ratio[i]<=q**n
        atoms.append(dict(name=chr(65+i),alpha=[fs(x) for x in aa[i]],nu=fs(nu[i]),
            wt=fs(wt[i]),wg=fs(wg[i]),kt=kt[i],kg=kg[i],ratio=fs(ratio[i]),
            pi_t=fs(pi[i]),layer=ratio[i]<=cap,
            exact_lower_rhs=fs(q**kt[i]),exact_upper_rhs=fs(q**n),
            threshold_equal_t=sum(x==t for x in aa[i]),threshold_equal_g=sum(x==g for x in aa[i])))
    pairs=[]; positive_count=0; positive_mass=F(0); positive_flux=F(0)
    delta_mean=F(0); abs_half=F(0)
    for i in range(6):
        for j in range(6):
            delta=max(kt[i]-kt[j],0); mass=pi[i]*pi[j]; layer=ratio[i]<=cap
            assert delta<=kt[i]
            assert ratio[i]>=q**delta
            if delta>0: assert kt[i]>=1
            implication_checked=delta>0 and layer
            if implication_checked:
                assert q**delta<=cap
                assert q<=cap
                positive_count+=1; positive_mass+=mass; positive_flux+=mass*delta
            delta_mean+=mass*delta; abs_half+=mass*abs(kt[i]-kt[j])/2
            pairs.append(dict(v=chr(65+i),z_prime=chr(65+j),delta=delta,
                pair_probability=fs(mass),v_ratio=fs(ratio[i]),layer=layer,
                positive_layer=implication_checked,weighted_layer_delta=fs(mass*delta if layer else F(0)),
                delta_power=fs(q**delta),all_applicable_checks_passed=True))
    mu=sum(pi[i]*kt[i] for i in range(6)); middle=mu-mu*mu/n
    assert delta_mean==abs_half
    assert delta_mean<=middle<=F(n,4)
    predicted_nonzero = cid in ('I1','I2','I4')
    prediction_passed = positive_flux>0 if predicted_nonzero else None
    cov=None
    if n>=2:
        indicators=[(int(a[0]<t),int(a[1]<t)) for a in aa]
        m1=sum(pi[i]*indicators[i][0] for i in range(6))
        m2=sum(pi[i]*indicators[i][1] for i in range(6))
        m12=sum(pi[i]*indicators[i][0]*indicators[i][1] for i in range(6))
        cov=fs(m12-m1*m2)
    results.append(dict(stage=stage,id=cid,n=n,t=fs(t),g=fs(g),B=fs(cap),
        D_representation='log(B)',eta_representation='log(g/t)',g_over_t=fs(q),
        endpoint_t_equals_g=t==g,et=fs(et),atoms=atoms,pairs=pairs,
        initial_nonzero_prediction=predicted_nonzero,initial_nonzero_prediction_passed=prediction_passed,
        positive_layer_pair_count=positive_count,positive_layer_pair_probability=fs(positive_mass),
        positive_layer_weighted_delta=fs(positive_flux),mean_score=fs(mu),expected_delta=fs(delta_mean),
        expected_abs_score_difference_half=fs(abs_half),mu_minus_mu_squared_over_n=fs(middle),n_over_4=fs(F(n,4)),
        first_two_score_indicator_covariance=cov,all_checks_passed=True))
    (BASE/'exact_flux_check.json').write_text(json.dumps(dict(status='recovery_in_progress',run_count=2,
        first_run_failure=FIRST_RUN_FAILURE,protocol_sha256=EXPECTED_PROTOCOL,fa_sha256=EXPECTED_FA,
        samples=results),ensure_ascii=False,indent=2)+'\n')
report=dict(protocol_sha256=sha('numeric_protocol.md'),fa_sha256=sha('fa_time_geometry.md'),
    script_sha256=sha('exact_flux_check.py'),run_time_utc=datetime.now(timezone.utc).isoformat(),
    run_count=2,recovery_run_number=2,first_run_failure=FIRST_RUN_FAILURE,
    recovery_exit_status='success',frozen_prediction_failures=['I4'],
    arithmetic='fractions.Fraction; no floating-point logarithm or numerical integration',
    scope='Finite scalar weights and actual normalized Pi_t only; no phi/C/FA/receiver/history/FULL implementation',
    static_time_price_check=dict(status='symbolic derivation checked',
      formula='D*(1+log_+(n/4))',reason='Integrate min(n/4,D/eta) to L<=D. If n<=4 use nL/4<=D; if n>4, first branch<=D and second branch uses nL/(4D)<=n/4.',
      no_external_budget_verification=True),
    common_nu=[fs(x) for x in nu],common_alpha_64=[[fs(x) for x in a] for a in alphas],
    sample_count=len(results),pair_count=sum(len(r['pairs']) for r in results),
    all_checks_passed=True,samples=results)
(BASE/'exact_flux_check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for r in results:
    print(r['id'], 'positive_layer_pairs='+str(r['positive_layer_pair_count']),
          'positive_layer_weighted_delta='+r['positive_layer_weighted_delta'])
print('PASS: 12 cases; 432 fully recorded pairs; no log approximations')
