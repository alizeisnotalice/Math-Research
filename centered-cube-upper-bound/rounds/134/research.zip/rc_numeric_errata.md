# R134 RC 数值复核勘误

本文件记录首轮脚本分母错误及恢复后的第二次运行。原冻结菜单协议 `rc_numeric_protocol.md` 未作改写。

## 首轮记录（作废，不作为 PASS）

首轮运行时间：2026-10-14T14:53:40.038286+00:00。

- 首轮 `rc_exact_check.py` SHA-256：`c0afbdda417f03b9fbb0c8704e6753db6834a1b8dff6d21dcbceced61dba9b55`
- 首轮 `rc_exact_check.json` SHA-256：`87ea46f82390d7bce53bbb7b8072438ee5543af4b1c1c6f6f40d520df8cd8694`
- 冻结协议 SHA-256：`b0a32a1bf7ada6e6f42452a7105fcd7188374a1f1f5d9abaa8744a2a5fccf87e`

首轮实现把 `intQ=∫Q dν` 错当作 `QJ=∫J dν`，用于 `alpha=(Dq-∫U dν)/QJ`、`Mr=3D min{p/(KTC),2κq/QJ}`、以及 `alpha_lower=DT eg κ/QJ` 三处的分母。因此首轮 JSON 的全断言 PASS 无效；其结果不能作为这些 RG 公式的核验结论。首轮输出 JSON 已由修正后的第二轮结果替换，上述散列保留其可核验身份。

## 修正和第二轮

脚本现以 `QJ=ints["J"]` 用于上述三式，独立保留 `intQ=∫Q dν`，只在定义 `q` 和检查 `q≥∫Qdν` 时使用。菜单与冻结协议均不变。按主代理复核要求恢复第二次运行；第二轮结果及其断言以当前 `rc_exact_check.json` 为准。第二轮输出不可称为“单次运行成功”。

菜单 P4 保留原值 `D=1/10`，但它不满足原参数假设 `D≥1`，仅作扩展标量代数测试，不计入原参数域案例。其余有限标量结果仍不认证真实位置核、原 `Hhat`、FA 门、FULL 交通或一般结论。
