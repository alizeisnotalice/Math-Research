#!/usr/bin/env python3
"""Exact scalar checks of RG13--24. This is a pressure experiment, not a proof."""
from fractions import Fraction as F
import hashlib, json
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent

# Frozen two-atom menu. Each row is (name, phase, A_good, K0_bad, D, T, C, p, K).
# The good atom has A=the listed value; the bad atom has A=0. Both atoms have
# K1=K2=J=K0=.01 except for the explicitly varied bad K0 rows.
MENU = [
    ("I1", "初探", F(1,100), F(1,100), F(1), F(1), F(2), F(1), F(1)),
    ("I2", "初探", F(1,10), F(1,100), F(1), F(1), F(2), F(1), F(1)),
    ("I3", "初探", F(9,10), F(1,100), F(1), F(1), F(2), F(1), F(1)),
    ("I4", "初探", F(1,10), F(1,10000), F(1), F(1), F(2), F(1), F(1)),
    ("P1", "已知压力", F(1,100), F(1,10000), F(1), F(1), F(2), F(1), F(1)),
    ("P2", "已知压力", F(1,10), F(1,1000000), F(1), F(1), F(2), F(1), F(1)),
    ("P3", "已知压力", F(9,10), F(1,100000000), F(1), F(1), F(2), F(1), F(1)),
    ("P4", "已知压力", F(1,10), F(1,100), F(1,10), F(1), F(2), F(1), F(1)),
    ("E1", "扩大", F(1,10), F(1,100), F(1), F(10), F(2), F(1), F(1)),
    ("E2", "扩大", F(9,10), F(1,10000), F(2), F(1), F(4), F(1), F(1)),
    ("E3", "扩大", F(1,10), F(1,1000000), F(1), F(2), F(8), F(1), F(1)),
    ("E4", "扩大", F(9,10), F(1,100), F(2), F(3), F(2), F(1), F(1)),
]
NU = (F(1,2), F(1,2))
KERNEL = {"good": {"K0": F(1,100), "K1": F(1,100), "K2": F(1,100), "J": F(1,100)},
          "bad": {"K0": None, "K1": F(1,100), "K2": F(1,100), "J": F(1,100)}}

def s(x):
    return f"{x.numerator}/{x.denominator}"

def run_case(row):
    name, phase, A_good, K0_bad, D, T, C, p, K = row
    atoms = ["good", "bad"]
    values = {"good": dict(KERNEL["good"]), "bad": dict(KERNEL["bad"])}
    values["bad"]["K0"] = K0_bad
    values["bad"]["K1"] = K0_bad
    values["bad"]["K2"] = K0_bad
    Q = {a: (values[a]["K1"] + values[a]["K2"] + values[a]["J"]) / 3 for a in atoms}
    wg = {"good": F(1,100), "bad": F(1)}
    A = {"good": A_good, "bad": F(0)}
    ints = {key: sum((NU[i] * values[a][key] for i, a in enumerate(atoms)), F(0))
            for key in ("K0", "J")}
    intQ = sum((NU[i] * Q[a] for i, a in enumerate(atoms)), F(0))
    q = max(ints["K0"], ints["J"], intQ)
    eg = sum((NU[i] * wg[a] for i, a in enumerate(atoms)), F(0))
    good = {a: p * wg[a] <= K * Q[a] for a in atoms}
    bad = {a: not good[a] for a in atoms}
    high = p * eg >= 2 * K * q
    E = {a for a in atoms if good[a] and A[a] > 0}
    U = {a: min(T * A[a], D * values[a]["K0"]) if a in E else F(0) for a in atoms}
    intU = sum((NU[i] * U[a] for i, a in enumerate(atoms)), F(0))
    QJ = ints["J"]
    alpha = (D * q - intU) / QJ
    badK0 = sum((NU[i] * values[a]["K0"] for i, a in enumerate(atoms) if bad[a]), F(0))
    kappa = badK0 / (T * eg)
    Cr = C
    Mr = 3 * D * min(p / (K * T * Cr), 2 * kappa * q / QJ)
    per_atom = {}
    for a in atoms:
        rhoA = max(A[a] - (U[a] + alpha * values[a]["J"]) / T, F(0))
        rhs = max(A[a] - Mr * wg[a], F(0))
        per_atom[a] = {"good_gate": good[a], "bad": bad[a], "A": s(A[a]),
                       "K0": s(values[a]["K0"]), "J": s(values[a]["J"]),
                       "Q": s(Q[a]), "U": s(U[a]), "rhoA": s(rhoA),
                       "bound_rhs": s(rhs), "bound_holds": rhoA <= rhs,
                       "K1_plus_K2_le_CK0": values[a]["K1"] + values[a]["K2"] <= C * values[a]["K0"]}
    alpha_lower = D * T * eg * kappa / QJ
    checks = {
        "q_dominates_integrals": q >= ints["K0"] and q >= ints["J"] and q >= intQ,
        "high": high,
        "E_is_good_positive_A": all(good[a] and A[a] > 0 for a in E),
        "alpha_nonnegative": alpha >= 0,
        "alpha_lower_holds": alpha >= alpha_lower,
        "mixture_comparison_all_atoms": all(v["K1_plus_K2_le_CK0"] for v in per_atom.values()),
        "rho_bound_all_atoms": all(v["bound_holds"] for v in per_atom.values()),
    }
    return {"id": name, "phase": phase, "inputs": {"nu": [s(x) for x in NU], "p": s(p), "K": s(K), "D": s(D), "T": s(T), "C": s(C), "wg": {a:s(wg[a]) for a in atoms}, "A": {a:s(A[a]) for a in atoms}},
            "integrals": {"K0":s(ints["K0"]),"J":s(ints["J"]),"Q":s(intQ),"eg":s(eg),"q":s(q),"bad_K0":s(badK0)},
            "derived": {"alpha":s(alpha),"alpha_lower":s(alpha_lower),"kappa":s(kappa),"Cr":s(Cr),"Mr":s(Mr),"E":sorted(E),"QJ_denominator":s(QJ)},
            "atoms":per_atom,"checks":checks,"all_checks_pass":all(checks.values())}

def main():
    results = [run_case(row) for row in MENU]
    script_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    protocol = ROOT / "rc_numeric_protocol.md"
    out = {"scope":"finite scalar pressure only; no certification of RG13--24 or full-kernel theorem",
           "protocol_sha256":hashlib.sha256(protocol.read_bytes()).hexdigest(),
           "script_sha256":script_sha,
           "run_time_utc":datetime.now(timezone.utc).isoformat(),
           "assertions":{"case_count_is_12":len(results)==12,"all_checks_pass":all(r["all_checks_pass"] for r in results)},
           "cases":results}
    (ROOT / "rc_exact_check.json").write_text(json.dumps(out, ensure_ascii=False, indent=2)+"\n")
    assert out["assertions"]["case_count_is_12"] and out["assertions"]["all_checks_pass"]

if __name__ == "__main__":
    main()
