<!-- SOURCE main_integration.md SHA256 d73392441ded8441a4dfed6a9068a58919e87688ccd5f8c60c7364bd8109b132 -->
# 第134轮：真实行的面积子层支付与RC双来源质量耦合

一般n^(1/2+o(1))一致弱型上界仍未证明。本轮保留原接收点、history、双门、high、FIRST和RC，不将删门后的来源矩重新当作可付常数。

## 实质结果与登记边界

**FT8–11：真实自适应子层的有价删除。** 令η=log(g/t)、Δ_t(v)=log(w_t(v)/w_g(v))=∫_t^g k_u(v)du/u。因为k_u非减，Δ≥k_tη；在δ_t>0时，整数score给k_t≥1。因此Δ≤d的正交通只发生于η≤d，并且逐个实际行
\[
 \mathscr F_d\le d[1+\log_+(n/4)].
 \tag{M134-1}
\]
这里d是面积阈值，避免与RC放大常数D混用。此式不冻结s/L/R/g，不收费参数覆盖；同一Π_t的两份样本只用于∫δ≤n/4。保留RT1原外测度后，T_small≤4X，signed外2Λ给
\[
 2\Lambda P^{rem}_{\Delta\le d}\le8\Lambda d[1+\log_+(n/4)]X.
 \tag{M134-2}
\]
任选新的独立误差槽ε_d>0，取d=ε_d/[8Λ(1+log_+(n/4))]，该子项≤ε_dX。这里只说明可按此收费；没有声称历史误差总和仍有任意余额，最终总账必须明确分配此新槽。N_Z不返回，N_Zc/Ndel原位各一次；不在raw价格8Λ外重复乘16/3。只从已经不交化的当前正余项删除此层，不重新收费旧FA/RC/SP/MA部分。

此为全实际选择器上的子层上界，不是一般根阶闭合；没有证明该层在原FULL交通中有正质量。符号权重模型说明它可在far门内出现，不替代原核/history实例认证。Δ>d仍完整保留。

**RG13–24：同一接收点上的bad→good余额耦合。** 记Q_J=∫Jν，κ_r=(Te_g)^(-1)∫DgK0ν。原RC余额满足α_rec≥DTe_gκ_r/Q_J。若Hhat≥L+，真实核给
\[
 K_1+K_2\le C_rK_0,\qquad C_r=(\widehat H/L)^n+(\widehat H/L^+)^n.
\]
在原good及high门上，得到
\[
 \rho_{rec}(v)A(v)\le[A(v)-M_rw_g(v)]_+,\qquad
 M_r=3D\min\{p/(KTC_r),\,2\kappa_r q/Q_J\}.
 \tag{M134-3}
\]
这是实际bad来源质量通过共同余额控制good余量，未把ν总质量换成q。比例常数C_r不能一般省略；在Hhat≤H0且y∈Q_L(x)的明示核心条件下，精确TH0^n=(1-s+sφ(1/2))^n给p/(TC_r)≥1/2。若bad核心wg质量另满足RG23，M_r≥3D/(2K)，可准确识别被原RC完全捕获的来源层。

这条核心推论没有新增捕获容量；ρ本来已扣除了该捕获。它提供真实核几何与bad比较质量的联合约束，不把识别ρ=0层宣称成独立新付款。Hhat<L+、核心外、κ_r很小和A/wg很大的交通均未支付；κ无输入无关正下界。

**SB1：严格余额的范围澄清。** 实际strict-soft high行中K0>0且bad的wg质量至少e_g/2，因此α_rec>0。这是严格正性，不是可将1/α视作常数的量化下界，也不删除旧辅助/扩展α=0材料。此推论的证明及全部假设单列，RC独审亦核实同一事实。

## 本轮并未完成的根阶账

在Δ>d且Hhat≥L+部分可采用M134-3，但需要估计实际联合尾：bad的K0比较质量不足与good的A/wg很大同时出现时，真实接收dx、两份Π_t、χFA/Ψ/history和ρ如何共同限制来源通量。不能分别取κ下确界和A/wg上确界再线性求和。另一尺度分支Hhat<L+仍保留原公式。全部β−ν、硬z、V/j、尺度与soft选择、T、K、D、q/QJ及原负项账均保留。

M134-2可作为一次明确ε_d收费纳入主证明，M134-3是新的几何约束；二者没有给出高面积重尾的n^(1/2+o(1))总价。目标不改为这些子结果。

## 三阶段数值及真实失败记录

1. 面积权重检查：12例、每例同一六原子ν产生的36个Π_t配对，共432对；三阶段验证原乘积权重、整数score、Δ下界与B层（用B=e^d的有理形式），没有浮点对数。第一次运行因I4的“预计非零”断言失败且未完成JSON；恢复时只将该预测改为观测记录，原菜单和数学检查未改。第二次完成所有432对，数学断言通过，I4仍如实为零。I1/I2有非零层内正量；I3为t=g端点，不称far实例。首轮退出1、traceback和脚本SHA保留。仅条件阈值模型，未认证φ/C、FA/history/FULL。
2. RC精确标量检查：三阶段12例。主代理审查发现Luna首轮把∫Q*ν误作Q_J用于三个分母，首轮PASS已作废。修复后的第二次运行保留原菜单，12例代数断言通过；P4的D=1/10在原D≥1范围外，只有11例属于该参数范围。均不认证原位置核/Hhat或FULL。独立errata保留首轮哈希与错误；Sol再静态复核并按已有数据独立精确重算，详见numeric_final_audit.md。

上述有限检查辅助核对界的方向与费用，没有猜测维数阶，也不作为一般证明。每项关键解析结论由Sol独立先审/后审，Luna只做索引和实现，不能独立认证。

## 技能、文献与复现

本轮实际重新读取D02 Gibbs熵对偶SKILL、cube-interface与来源记录。技能限定有限域恒等式，要求指数可积和KL费用；本轮未获得这些费用，因而没有借用广义变分原理消去来源矩，也未声称新读完外部原文。L03精确代数与有限样本边界继续保持。

两套最终脚本仅使用Python标准库Fraction。解压后，应将所需脚本、协议及fa_time_geometry.md复制到一个不含旧结果JSON的空目录再运行exact_flux_check.py；脚本为防重复会拒绝覆盖已有输出。RC脚本可在另一空目录运行。恢复运行metadata记的是本轮原执行历史，重放时不得把内嵌run_count解释成全会话实际次数；比较数学样本而非时间戳。归档保留错误，不将修复过程改写成单次成功。不编译PDF。

协作采用最新最多8人的1Astra/3Sol/4Luna配置，本轮按独立任务启停。没有可归因到Agent的扣额数据，不猜模型成本比例。

## 主代理最终复现核验

归档前另在空临时目录用python3 -I运行最终交付的面积脚本一次，退出0，全部12例/432配对的samples与冻结JSON解析后完全一致；这是在原失败/恢复两次之后的额外隔离重放，不伪称仍只有两次执行。最终脚本与恢复运行脚本仅首轮traceback转录文本不同，JSON同时保存两个SHA。原冻结结果未覆盖。收据见main_replay_receipt.json；RC结果另由Sol以Fraction独立重建264字段。


<!-- SOURCE fa_time_geometry.md SHA256 d60f2a676a6527e0d77e6c1180ee0aa9d41657a676a233420de464b5e119a050 -->
# R134：保留 FA 与真实接收点的未来 score 面积层

状态：仅处理同一真实接收行上的 FA/good 与时间几何；不重复第三测试或 Hellinger。先写准确命题和量词，再逐节给证明、可付范围及未覆盖费用。只写本文件，不操作 Git/PDF，不修改其他文件。

## 1. 准确候选与量词

固定任意原合法有限交通截断和完整实际行 \(r=(\omega,V,j,x,y,z,\mathrm{history})\)。在该行的原 high 域，\(p=p_x(y)>0\)，同一 \(Q=Q_x^*\)、\(g=g(x)\)、\(B=B_{FA}>0\) 保持实际值。对任意原 far 时间 \(t\le g\)，保留两份同一真实概率 \(\Pi_t\)，并定义
\[
 k_t(v)=\#\{i:\alpha_i(y,v)<t\},\qquad
 \delta_t(v,z')=[k_t(v)-k_t(z')]_+,
\]
\[
 \eta=\log(g/t),\quad
 \Delta_{t,g}(v)=\log\frac{w_t(v)}{w_g(v)}
 =\int_t^g k_u(v)\frac{du}{u},\quad
 L_g(v)=\frac{Q(v)}{p w_g(v)}.
\tag{FT1}
\]
所有原 bad/good、\(\Psi\)、\(\chi_{FA}\)、\(\rho_{rec}\)、来源支持和 history 均按实际值保留。来源向量无需坐标独立；\(\Pi_t\) 可以随 t 改变。

候选 A（精确夹层）：在 good(v) 与原正 FA 门同时成立时，
\[
 \frac1K\le L_g(v)<B\delta_t(v,z')e^{\Delta_{t,g}(v)}.
\tag{FT2}
\]
这给 \(\delta_t e^\Delta>1/(KB)\)，但其方向不是 \(e^\Delta\) 或 \(\delta_t\) 的上界。

候选 B（新增可计价面积层）：对任意预先指定的 \(D\ge0\)，将真实正项限制到明确可测层
\[
 E_D(r,t,v)=\{\Delta_{t,g(x)}(v)\le D\}.
\tag{FT3}
\]
不对来源作新归一化。定义该行的原来源/时间因子
\[
 \mathscr F_D(r)=\int_{J_{far}(r)}\frac{dt}{t}\iint
 1_{D_g}(z')1_{S_g}(v)\Psi\chi_{FA}\rho_{rec}(v)
 \delta_t1_{E_D}\,d\Pi_t(v)d\Pi_t(z').
\]
则候选价格为
\[
 \mathscr F_D(r)\le\Phi_n(D)
 :=\min\left\{\frac n4\log2,
 D\left[1+\log_+\frac{n\log2}{4D}\right]\right\},\quad D>0;
 \qquad \Phi_n(0)=0.
\tag{FT4}
\]
该候选是行内联合积分上界，尚不宣称其外真实接收质量有输入无关预算。它将该层的时间价格从 \(O(n)\) 改成 \(O(D[1+\log_+(n/D)])\)，不要求 \(\delta_t=k_t(v)\)，也不改变来源概率。

## 2. 精确夹层的方向与 score 面积

逐坐标积分 \(\log\min(1,\alpha_i/u)\) 得 FT1，且 \(k_u(v)\) 随 u 非减。于是对 \(t<g\)，
\[
 0\le\Delta_{t,g}(v)\le n\eta,
 \qquad \Delta_{t,g}(v)\ge k_t(v)\eta\ge\delta_t(v,z')\eta.
\tag{FT5}
\]
严格 score 定义 \(\alpha_i<t\) 在等号处只会减小 \(k_t\)，不影响此式。关键是最后一步仅使用 \(\delta_t\le k_t(v)\)，没有把两者等同。

FA 分母仍是原 \(w_t\)：\(\ell_t=L_g e^{-\Delta}\)。good 给 \(L_g\ge1/K\)，FA 给 \(L_g e^{-\Delta}<B\delta_t\)，从而得到 FT2。反向不等式 \(e^\Delta\delta_t\le C\) 不成立；即便 \(L_g=1/K\)，增大 \(\Delta\) 只会让原不足门更容易成立。以此夹层直接“支付”高 \(\Delta\) 或 WJ 的重尾费用，方向错误。

在 FT3 层，FT5 给 \(\delta_t\le D/\eta\)。同一 \(\Pi_t\) 下，若 \(X=k_t(v)\)、\(Y=k_t(z')\)，两份抽样独立同分布，则
\[
 \mathbb E\delta_t=\tfrac12\mathbb E|X-Y|
 \le\mu_t-\mu_t^2/n\le n/4.
\tag{FT6}
\]
中间不等式来自 \(|X-Y|\le X+Y-2XY/n\)。来源向量坐标是否独立与此无关。保留原门和余权只减小非负积分，所以每个实际 t 的完整来源因子至多 \(\min(n/4,D/\eta)\)。原 \(a/c_j\le t\le g\)、\(a/c_j\ge g/2\) 给 \(0<\eta\le\log2\)（原 far 端点还给 \(\eta\ge u_{old}/n>0\)），且 \(|dt/t|=d\eta\)。在 \(\eta=4D/n\) 切分，得 FT4；如果切点在时间窗外，积分为 \((n/4)\log2\)，FT4 仍有效。

## 3. 整数 score 与 FA 提供的进一步时间支持

原 score 是整数。因此 \(\delta_t>0\Rightarrow k_t(v)\ge1\)，由 FT5，FT3 层的正项必满足
\[
 \eta\le D.
\tag{FT7}
\]
这比只套 \(\delta\le n\) 更有效：面积帽 D 不仅限制 score，还限制其可出现的时间长度。再联用 FT2，
\[
 \frac1K<B\delta_t e^D\le B\frac D\eta e^D,
 \qquad \eta<KBDe^D.
\]
所以定义
\[
 L_D=\min(\log2,D,KBDe^D),
\]
正项在 \(\eta>L_D\) 上为零。边界上的单个时间点不影响 dt 积分。更细的实际位置版本为 \(L_D(v)=\min(\log2,D,BDe^D/L_g(v))\)；不得先把随 v 变化的版本提出来源积分而省略其层质量。

对于 D>0，令
\[
 \Psi_n(D,L)=
 \begin{cases}
 nL/4,&L\le4D/n,\\
 D\,[1+\log(nL/(4D))],&L>4D/n.
 \end{cases}
\]
则保留所有原门的行内时间/来源积分满足
\[
 \boxed{\mathscr F_D(r)\le\Psi_n(D,L_D)
 \le D\,[1+\log_+(n/4)].}
\tag{FT8}
\]
最后一步使用 \(L_D\le D\)。D=0 时 \(\eta>0\) 上 \(k_t=0\)，所以 \(\mathscr F_0=0\)。原 far 门还给 \(\eta\ge u_{old}/n\)；若 \(L_D<u_{old}/n\)，该层严格为空，可在 FT8 中进一步按实际端点积分。不能删除原 far 下端点后声称实际层非空。

当 \(KB e^D\ge1\) 时 FA 不再缩短 FT7 的时间支持。特别，原已付 FA 分支常用 \(KB=4\Lambda\log2/\varepsilon_{FA}\)，此时不能宣称 FA 总能额外省一个大常数。FT8 的普遍改善来自精确未来 score 面积；FA 的进一步作用及其适用条件已经显式列出。

## 4. 保全真实接收积分的局部误差付款

令 \(P_{I,D}^{rem}\) 为 RT2 的原正余泛函仅新增 \(1_{\{\Delta\le D\}}\) 后所得的子项。保留原 RT1 的完整外测度 \(d\mathcal T_I\)，不先删除实际 x、选择器或 history。逐个实际行应用 FT8，Tonelli 给
\[
 P_{I,D}^{rem}\le\Psi_n(D,L_D)
 \mathbb E\sum_{V,j}\int1_{A_{hi}}d\mathcal T_I
 \le4\Psi_n(D,L_D)X.
\tag{FT9}
\]
第二步只调用原完整行总账 \(T_{small}=\mathbb E\sum_{V,j}\int d\mathcal T\le4X\)，不是 FIRST 测试核容量，也不是把来源概率误称为容量。原唯一 j、真实 \(dx\)、\(\beta-\nu\)、硬 z 和 s/L/R/g 选择器都在该外测度中原样保留；逐行标量上界不需要对它们作固定块覆盖。它同样不使用已付 RC 捕获容量。

signed 外系数仍为 \(2\Lambda\)，所以
\[
 2\Lambda P_{I,D}^{rem}
 \le8\Lambda D[1+\log_+(n/4)]X.
\tag{FT10}
\]
对任意 \(\varepsilon_D>0\)，预先选定
\[
 D_{n,\varepsilon_D}
 =\frac{\varepsilon_D}{8\Lambda[1+\log_+(n/4)]}
\tag{FT11}
\]
即可将当前余项的实际 \(\Delta\le D_{n,\varepsilon_D}\) 子支支付为 \(\varepsilon_D X\)。\(\varepsilon_D\) 仅表示本轮新分配的独立可吸收槽；本稿不声称核验过任何历史未消费误差余额，也不取用旧额度。主代理须将该新槽纳入最终总 \(\varepsilon\) 分配。这是一条可执行的局部分割，不是原 FA 定义的重复改写：它把此前 FT4 的 D log(n/D) 改善成 D log n，并保全真实接收积分，直接给出了选择 D 与新误差价格的关系。无需另两测试、来源分母下界或免费跨 j 包络来支付**这个已明确限制的子支**。

FT11 不重新支付已经删去的 near/FA/RC 子支：仅对当前 RT2/SI5 余项加指示。数学结论为任意 \(\varepsilon_D>0\) 时相应子项不超过 \(\varepsilon_DX\)；最终总账必须另作这个新槽的分配，不能登记为免费。\(\Delta>D\) 部分原位保留；全部负项原位各一次，\(N_Z\) 不返还，\(N_{Z^c}\) 与 \(N_{del}\) 没有附上本层门。

FT9--10 使用 RT1--2 的原未硬来源积分形式。若从 SI5 的 \((16/3)c_\xi\) 形式出发，需要还原同一外行测度，不能在 FT10 的 \(8\Lambda\) 上再额外乘 \(16/3\)。这不是省略硬来源费，而是原 \(q^{-1}h_R\nu\) 已在 \(d\mathcal T_I\) 中，最后只用一次 \(T_{small}\le4X\)。

## 5. 与旧 near 门的区别，以及夹层无法支付的部分

FT11 的面积门不是旧 \(\eta<u_{old}/n\) 的重述。旧门只看时间；新门还看从 t 到真实 g 的全部原 score。举一个仅验证阈值/时间接口相容性的符号情形：一个坐标的 \(\alpha_i<t\)，其余 \(\alpha_i\ge g\)，而配对来源所有 \(\alpha_i\ge g\)。则整个 \([t,g]\) 上 \(k_u(v)=1\)，\(\delta_t=1\)，\(\Delta=\eta\)。如果 \(D>u_{old}/n\)，存在 \(u_{old}/n<\eta<D\) 的 far 时间落入面积层；若 \(KB>1\)、\(L_g=1/K\)，FA 也成立。它说明面积层在标量接口上可以超出旧 near 窗，并不认证真实核、FULL/history 或 RC 余量在该情形实际非空。反之，如果所选 FT11 的 D 太小，层为空仍是合法但没有额外交通增益的结果。

对于高面积补集，FT2 仍不提供小质量。固定 \(0<\eta\le\log2\)，选所有 \(\alpha_i(v)<t\)、所有 \(\alpha_i(z')\ge g\)，即可使 \(\delta_t=n\)、\(\Delta=n\eta\)。取标量 \(L_g(v)=1/K\)，则 FA 的条件仅为 \(e^{-n\eta}/K<Bn\)，对足够大 n 成立。原门允许的 \(\Delta\) 仍可为线性 n；此符号压力不涉及数值，也不是原核/FULL 反例。它严格排除“只由 FA、good 与 score 面积恒等式自动得到 \(\Delta=O(\log n)\) 或一般根阶价格”的推理。

因此下一步有两个具体选择：先从当前余项不交删除 FT11 的已明确收费子层，随后在 \(\Delta>D\) 上利用实际核/RC/history；或者保留 FT8 的行依赖更尖时间价，建立真实行的 D 分布预算。将所有 D 壳分别套 \(T_{small}\le4X\) 后重复收取同一总行质量，会丢失分层收益；不得这样做。若使用接收/来源重尾变换，WJ 的 R_h 仍须实付，FA 的低比门方向无法将它自动抵消。

## 6. 证据与最终状态

本稿直接读取：R128 `joint_receiver_tail.md` RT1--6，R131 `source_integrability.md` SI1--5，R133 `source_weight_joint.md` WJ1--15；为核验原完整行总质量及 FA 参数，读取 R119 `quantitative_future.md` FA1、FA9--15。未重审全部历史，未新增数值实验。

实际读取来源的 SHA-256：

- R128 `joint_receiver_tail.md`：`0a58c8eca0b2ad48cb8f03486b9e6f72b379dc711fac3b0fc70e8706bff791ca`；
- R131 `source_integrability.md`：`c55beae1830e38d16661cfe173eeb96253f8e9d96e67496e3d18f67180145894`；
- R133 `source_weight_joint.md`：`69c89c1d6d99072a52192c34077fbed7aad466db591fbd6184ac28599316f2b5`；
- R119 `quantitative_future.md`：`4976623b47ae0b13896820187e74c372c8bbf1d156d932bbcb3912b6778fb085`。

新结果是 FT8--11 的真实行内面积层价格及明确误差槽条件；它改变下一步可删除的正余子层，保全同一 \(\Pi_t\)、真实 x、原 \(\chi_{FA}\) 与 \(\rho_{rec}\)。FT2 的夹层本身仅给下界，不能承担高面积补集。所有外层费用在 FT9 的完整行总账中只使用一次；未消费任何负项或已付 RC 容量。一般根阶目标仍 UNPROVED。交付后停止。


<!-- SOURCE fa_time_audit.md SHA256 35f6914bb3f29d8128c89bc5381d55fb505ebe2f90c19c851f15a2bcda84825e -->
# R134 FA未来面积层冻结后审

本审实读冻结 `fa_time_geometry.md`，SHA-256=`d60f2a676a6527e0d77e6c1180ee0aa9d41657a676a233420de464b5e119a050`。重点审实际自适应行的面积帽、时间价、raw外层8ΛX及独立ε_D；不重复核/Hellinger历史。只写本审文件，不修改作者，不git/PDF。

## FTA1. 实际行上Δ、FA门及概率价格

FT1的Δ=log(w_t/w_g)=∫_t^g k_u du/u准确：每个坐标log min(1,α_i/t)在尺度变量上导数为−1_{α_i<t}，再对坐标求和。α_i=t处的严格score约定不影响尺度Lebesgue积分，亦未改变原门定义。k_u随u非减，故Δ≥k_tη≥δ_tη。

原good是pwg≤KQ，给Lg=Q/(pwg)≥1/K；原FA是Q/(pwt)<Bδ，且wt/wg=e^Δ，故Lg<Bδe^Δ。FT2的方向完全正确，只约束δe^Δ的下方，不支付高Δ上尾。

对每个实际t，Π_t是同一真实概率的两份独立抽样，来源向量内坐标可相关。对0≤X,Y≤n，有|X−Y|≤X+Y−2XY/n；两份抽样给Eδ≤EX−(EX)²/n≤n/4。面积层Δ≤D另有点态δ≤D/η。所有额外门及ρ处于[0,1]，所以完整来源因子至多min(n/4,D/η)。无需把δ=k_t，无需让Π_t固定不随t变化。FT4的一次标量积分及其min形式正确。

整数δ>0蕴含k_t≥1，故该层正交通只在η≤D出现；FA还给η<KBDe^D。于是实际时间支持包含于(0,L_D]，L_D=min(log2,D,KBDe^D)。实际far另有η≥u_old/n；扩大积分至0只给上界，不认证层非空。FT7及其端点处理正确。

## FTA2. FT8的D(1+log_+(n/4))及自适应量词

直接积分得

\[
\int_0^L\min(n/4,D/\eta)d\eta=
\begin{cases}nL/4,&L\le4D/n,\\D[1+\log(nL/(4D))],&L>4D/n.\end{cases}
\]

因为L_D≤D，两支均≤D[1+log_+(n/4)]：第一支若n≥4则至多D，若n<4则nL_D/4≤D；第二支存在时nL_D/(4D)>1，且该比值≤n/4。D=0时η>0而Δ≤0强制k_t=0，原正项为零。故FT8没有隐藏log(1/D)费用。

该界是在每个完整实际行r=(ω,V,j,x,y,z,history)上推导。g(x)、Δ_(t,g(x))、原门及ρ保持同一实际接收点计算；对所有实际行使用**预先指定的同一个D**，标量上界只依赖n,D,K,B。没有把接收依赖集合移出x积分，没有作固定s,L,R块的亲和归一化，也不需要先覆盖连续选择器。若改用作者的v依赖L_D(v)，必须留在来源积分；作者对此已明确限制。

**FT1–8 PASS。** 新面积层确实给D log n行内时间价，但尚不保证本层在FULL/RC余项中有正质量；作者对空层及阈值符号情形的边界声明适当。

## FTA3. X/Tsmall的合法raw回代及独立误差槽

为核定义，实读R128 `joint_receiver_tail.md` RT1–2、R131 `source_integrability.md` SI1–5及R119 `quantitative_future.md` FA1（仅使用所需原接口，不重审完整历史）。原raw外测度是

\[
d\mathcal T=1_{\{j(x)=j\}}q^{-1}p(x,y)h_{R(x)}(x-z)
 a_\omega(x,y,z)\,dx\,d\beta_V(y)d\nu_V(z),
\]

且R119 FA1原定义为

\[
T_{small}=\mathbb E\sum_{V,j}\int d\mathcal T\le4X,
\qquad X=\lambda|E_0|<\infty.
\]

作者的d𝒯_I只是原合法有限截断1_I，保留同一个唯一j指示、实际x、硬z、全部history、β−ν及连续参数选择器；high的额外指示≤1。逐行套FT8，再Tonelli，确有

\[
P^{rem}_{I,D}\le D[1+\log_+(n/4)]
\mathbb E\sum_{V,j}\int1_{Ahi}d\mathcal T_I
\le4D[1+\log_+(n/4)]X.
\]

原signed外2Λ只乘一次，给

\[
2\Lambda P^{rem}_{I,D}\le8\Lambda D[1+\log_+(n/4)]X.
\]

因此FT9–10的4与8Λ正确。这里用的是完整原行总账Tsmall≤4X，非FIRST的测试核容量；它没有先丢掉x后再用high/FIRST。SI5的16/3来自先积分硬z所得cξ；若已经还原raw d𝒯，硬核与q⁻¹都在外测度，不能再将16/3乘在8Λ上。作者已明确这一点。

对任意新的ε_D>0，预先选

\[
D=\frac{\varepsilon_D}{8\Lambda[1+\log_+(n/4)]}
\]

使当前余项的面积子支≤ε_DX，是合法局部吸收条件。该ε_D不是来自既有near/FA/RC付款的余额证明：作者明确其为本轮**另分配的新槽**，主总账必须真实纳入总ε，并在已经删去的子支补集上应用当前层指示。本文不认证历史尚有多少未消费ε，也不将总行容量重复计成免费误差槽。

当前层为正项的不交细分，Δ>D补集原位保留。原N_Z已消费不返还，N_Zc/Ndel各一次且不附ρ、χ_FA或面积指示；FT11没有借它们付款。若对多个D壳逐个用4X而重复收取同一个完整行总质量，会丢失费用分配；作者最后一节已明确禁止这一做法。

**FT9–11 PASS（新误差槽的条件支付）。** 实际自适应行上Δ≤D层的时间价D[1+log_+(n/4)]及raw外8ΛX回代正确，X/Tsmall来源合法；独立ε_D仍须在主总账显式分配。高面积补集、真实重尾来源及一般根阶总预算仍未支付。作者冻结稿未将局部层身份登记为完整一般支付，未发现需修改的数学错误。


<!-- SOURCE receiver_rc_geometry.md SHA256 b607181be49d271827b98af50901990272bbbdb85c0094c32c85889b0c376526 -->
# R134：实际接收点的 RC 余量与核几何审计

状态：完成。同一实际行上得到RG20的bad余额—good余量耦合；一般联合尾未付。只处理原同一实际 x 上的 RC 余量；不删除 good/high/χ_FA 后再调用 FIRST。目标是判断实际 K₀/J 几何是否能支付余量，而非把未付来源矩换名。

## 1. 原余额归一化只给什么

固定完整实际行 r=(ω,V,j,x,y,z,history)，保留原 Π_t²、δ、Ψ、χ_FA、终端 good/bad 与 ρ。J=P_{1,b}(x−v)>0，Q_J=∫Jdν；Q_J=0 是零来源行。Q_J>0 时令

\[
d\sigma(v)=J(v)d\nu(v)/Q_J,\quad
X(v)=TA(v)/J(v),\quad Y(v)=DK_0(v)/J(v),\quad
c=Dq/Q_J.
\tag{RG1}
\]

E=S_g∩{B=0,A>0}，α=α_rec=c−E_σ[1_E min(X,Y)]，于是 α≥0，且 E 上有准确恒等式

\[
\rho(v)A(v)=\frac{J(v)}T[X(v)-Y(v)-\alpha]_+.
\tag{RG2}
\]

证明：X≤Y 时 U=TA 且ρ=0；X>Y 时 U=DK₀，余量为 (TA−DK₀−αJ)_+/T。原 RC 捕获容量是 ∫F_rec dν=Dq，不能把它再认作 RG2 正部的预算。

原时间 FTC 的已审上界仅允许

\[
\int\rho\,d\mu_r\le\frac{Q_J}{Te_g}
 E_\sigma\{1_E[X-Y-\alpha]_+\}.
\tag{RG3}
\]

这里 μ_r 是包含原来源对/时间正交通的测度，已审 μ_r≤1_S Aν/e_g；使用该正放松不改变负项的门。RG1–3 本身不登记为新估计。FIRST 给 E_σY≤c，但没有给 X 的超过一次矩，更没有给余量正部的预算。

## 2. H₀ 核心区域：旧事实及质量尾的精确推论

记 m_s=1−s+sφ(1/2)，ℓ=1+log n。原参数是

\[
H_0=g c_j^{-1/2}m_s\ell^{1/(2n)},\quad
\widehat H=\max\{a,\min(b,H_0)\},\quad
T=c_j^{n/2}/(g^n\sqrt\ell),\quad T H_0^n=m_s^n.
\tag{RG4}
\]

在 Q_{\widehat H}(x)={v:||x−v||_∞≤\widehat H/2} 内，每坐标 p_s((x_i−v_i)/\widehat H)≥m_s，故

\[
\frac{K_0(v)}T\ge\kappa:=\left(\frac{H_0}{\widehat H}\right)^n.
\tag{RG5}
\]

若 H₀≥a，则κ≥1，D≥1、A≤1 使ρ=0。这一核心全捕获已包含于 R122 `kernel_superlevel.md` 的超水平集合及 R125 放大捕获，**不是 R134 新成果**。旧硬 B 精确为 1_{R≤L}1_{Q_R}；RG5 一般属于旧软捕获，不应误称只来自 B。

上钳位 H₀<a 时κ=(H₀/a)^n<1，不能宣称整个 Q_a 均已捕获。令 τ=a/c_j、h=g e^{-u/n}，假定原非空时间区间 τ<h≤g，并设 η_A=1−(τ/h)^n∈(0,1)。逐坐标 wh≥(τ/h)^n wτ，因此

\[
A=w_\tau-w_h\le\eta_A w_\tau,
\qquad w_\tau\le(g/\tau)^n w_g.
\tag{RG6}
\]

于是真实余量在核心内的必要条件是

\[
\boxed{\rho(v)>0,\ v\in Q_{\widehat H}(x)
\ \Longrightarrow\
W_g(v)<H_{\rm core}:=
 n\log(g/\tau)+\log\eta_A-\log D
 +n\log(\widehat H/H_0).}
\tag{RG7}
\]

因为ρ>0要求 TA>DK₀+αJ≥DK₀，结合 RG5–6 得 wg>Dκ(τ/g)^n/η_A。若 H_core≤0，则核心内余量为空。等号层也被捕获，因原余量为严格正部。RG7 将核心中的大 Wg 层归入原已付捕获；它是旧捕获的显式推论，不能据此登记核心外重尾已经付款。实际 τ<h、α、g、Hhat 全取原行值，未重选来源参数。

## 3. 核心外的真实几何：能证明的范围及其费用

原严格软度给 s>0。设

\[
d(v)=\#\{i:|x_i-v_i|>\widehat H/2\},\quad
r(v)=\sum_i\left(\frac{|x_i-v_i|}{\widehat H}-\frac12\right)_+,\quad
\chi_s=\frac{s\phi(1/2)}{m_s}\in(0,1].
\tag{RG8}
\]

由原 logφ 的 4-Lipschitz 界，每个核心外坐标
sφ(|x_i−v_i|/Hhat)≥sφ(1/2)exp[−4(|x_i−v_i|/Hhat−1/2)]；核心内坐标仍≥m_s。因此真实点态下界及其余量必要条件是

\[
\frac{K_0(v)}T\ge\kappa\chi_s^{d(v)}e^{-4r(v)},
\]
\[
\boxed{\rho(v)>0\ \Longrightarrow\
W_g(v)<H_{\rm core}+d(v)\log(1/\chi_s)+4r(v).}
\tag{RG9}
\]

这些式子不使用来源独立或接收参数冻结，不改变任何原门。它们将超出 RG7 的重尾限于足够大的实际几何偏离；但 ν 可有相关坐标，FIRST 没有给 σ=Jν/Q_J 下 d 或 r 的普适尾，所以 **RG9 不是已付交通价格**。s 接近下门时 log(1/χ_s) 也须按实际值付费。

以下检验为何仅靠 K₀ 与 J 的位置比不会自动把 RG9 的区域截断。令 k=2sinh(1/2)。由原
w(r)=∫₀¹e^{-r/t}dt，经代换 u=1/t 可得 r e^r w(r)→1；两次固定长度卷积遂给

\[
\phi(r)\sim k\,e^{-r}/r,\qquad
C(r)\sim k^2 e^{-r}/r\quad(r\to\infty).
\tag{RG10}
\]

第二式使用 r>1 时 F(u−r)=φ(u−r)，故 C 是该尾上的又一次 h₁ 卷积。以上由有界区间上的尾比收敛和支配收敛推出，不是数值拟合。

在同一固定实际行中，取所有坐标沿方向 ε_i∈{−1,1} 趋于无穷的来源位置 v。所有 α_i 最终小于τ，故 A=(b/c_j)^n(τ^{-n}−h^{-n})∏C(|y_i−v_i|/b)。于是

\[
\lim X(v)=T b^n(b/c_j)^n(\tau^{-n}-h^{-n})k^n
 \exp\{\varepsilon\cdot(y-x)/b\}=:X_\infty(r,\varepsilon).
\tag{RG11}
\]

若 Hhat<b，真实 Y=DK₀/J 满足 Y(v)→0，因为每个尾坐标 φ(|x_i−v_i|/Hhat)/φ(|x_i−v_i|/b) 具有严格负的指数率；若 Hhat=b，则该尾上精确 Y=Ds^n。故 K₀ 的自身几何并不使 X−Y 在远来源位置趋于负值。α≥X∞（或在 Hhat=b 时 α+Ds^n≥X∞）足以排除该方向的渐近正余量，但原余额恒等式尚未给出这个逐方向比较，也没有给剩余尾的来源质量预算。

RG11 是对原实际核的解析检验，**不是一个满足原 good/high/FIRST/χ_FA/history/RC 全部资格的反例**；这里只说明真实核比的渐近行为，未替任何远来源点授予 live 或正交通资格。实际门仍可能进一步限制该区域，且正是目前需要使用的额外共同信息。

作为另一项费用核验，已审 C≤4e²φ 和 logφ 的 4-Lipschitz 性仅给

\[
X(v)\le T b^n(b/a)^n(4e^2)^n
 \exp\{4\|x-y\|_1/b\}.
\tag{RG12}
\]

这确为 ν-位置无关的真实核上界，因为 A≤wτ≤(b/a)^n∏C；但维数价格是指数级，且对合法 L=b、s>0，删门后的 p(x,y) 乘 exp(4||x−y||₁/b) 在真实 dx 下不可积。因此不能把 RG12 当成可积分测试核比较。改成小于一次的分数矩虽可改善接收积分，却本身不控制 RG2 的一次正部尾，缺少的来源费用仍在。没有以此推出对保留实际门的交通不可积。

## 4. 实际 bad 来源对共同余额的付款：双来源耦合

以下全在原同一实际 x 上，不先删除双门或 χ_FA。令 D_g={v∈Z_g:pwg(v)>KQ*(v)}，S_g为其在Z_g内的非严格good补集。因E⊂S_g，FIRST与U≤1_E DK₀给

\[
\boxed{\alpha Q_J=Dq-\int U\,d\nu
\ge D\int_{E^c}K_0\,d\nu
\ge D\int_{D_g}K_0\,d\nu.}
\tag{RG13}
\]

high/FIRST又给∫_{D_g}wg dν≥e_g/2。因此非零实际高支行上，s>0使K₀严格正，ν(D_g)>0，故**α>0**；不能在这些完整实际条件下使用α=0的压力模型。但这没有给α的统一正下界。

定义真实 bad 比较质量

\[
\kappa_r=\frac1{T e_g}\int_{D_g}K_0(v)\,d\nu(v)
=\frac1{e_g}\int_{D_g}\frac{K_0(v)}{T w_g(v)}w_g(v)d\nu(v).
\tag{RG14}
\]

不取bad位置的下确界。原high与RG13精确给

\[
\alpha\ge \frac{DT e_g}{Q_J}\kappa_r,\qquad
\frac{p\alpha}{KT}\ge 2D\kappa_r\frac q{Q_J}.
\tag{RG15}
\]

若需按可检查层付款，对任意u>0，令
b_r(u)=e_g^{-1}∫_{D_g}1_{K_0/(Tw_g)≥u}wg dν，则κ_r≥u b_r(u)；层蛋糕还给κ_r=∫₀∞b_r(u)du。没有将bad来源改成独立测度，也没有取来源总质量/q常数。

下面使用真实K₀/J几何，把这笔bad余额送回good余量。考虑原实际参数分支

\[
\widehat H\ge L^+:=\min(b,\gamma L).
\tag{RG16}
\]

偶单调φ及硬支持包含给每坐标p_s(u/L)/L≤(Hhat/L)p_s(u/Hhat)/Hhat；整维乘积遂有

\[
K_1+K_2\le C_rK_0,\qquad
C_r=(\widehat H/L)^n+(\widehat H/L^+)^n.
\tag{RG17}
\]

这是真实共同混合核的全位置比较，不是来源/接收积分后补一个sup。good门于是给C_rK₀+J≥3pwg/K，且任意非负K₀,J满足

\[
DK_0+\alpha J\ge\min(D/C_r,\alpha)(C_rK_0+J)
\ge\frac{3p}K\min(D/C_r,\alpha)w_g.
\tag{RG18}
\]

结合RG15，定义完全由原行决定的阈值

\[
\boxed{M_r=3D\min\left\{\frac{p}{KTC_r},\,
2\kappa_r\frac q{Q_J}\right\}.}
\tag{RG19}
\]

在RG16分支的**原实际good来源**上，得到严格余量估计

\[
\boxed{\rho(v)A(v)\le[A(v)-M_rw_g(v)]_+,\qquad
\rho(v)=0\quad\text{若 }A(v)/w_g(v)\le M_r.}
\tag{RG20}
\]

证明在E上直接将RG18代入ρA=(A−(DK₀+αJ)/T)_+；E外原捕获或零交通按约定处理。它与原χ_FA、δ、Π_t²及history同时成立；乘任何这些原正因子都保留方向。因此相应质量可比层确实在**原RC已付捕获内**，没有花第二份Dq，也没有改负项的门。这是本稿区别于RG1–3重命名的实质核几何耦合。

RG19的维数比也有一个真实无指数损失分支。若同时

\[
\widehat H\le H_0,\qquad y\in Q_L(x),
\tag{RG21}
\]

则p≥m_s^n/L^n，而TC_r≤m_s^n(L^{-n}+(L^+)^{-n})≤2m_s^n/L^n，故p/(TC_r)≥1/2，得到

\[
M_r\ge3D\min\{1/(2K),\,2\kappa_r\},
\tag{RG22}
\]

这里还用了q/Q_J≥1。若bad来源位于Q_Hhat(x)的wg质量为β_r e_g，则RG5及Hhat≤H₀给κ_r≥β_r。因此实际可测分支

\[
\text{RG16、RG21成立，}\quad
\beta_r\ge1/(4K)
\tag{RG23}
\]

上，全部A/wg≤3D/(2K)的good来源都有ρ=0。更一般可直接用u b_r(u)替代κ_r；RG23不是新增模型假设，而是对原行可检查的充分捕获条件。**尚未证明所有剩余实际行满足这些条件，也未证明该分支在主账有统一的正覆盖量。** 因此只把RG20登记为有准确适用域的新联合上界，不登记一般根阶闭合。

## 5. 唯一剩余缺口与停点

本稿得到RG20：在Hhat≥L⁺分支，真实bad来源的K₀比较质量通过共同α余额转化为good来源A/wg的已付阈值。RG22–23进一步在真实核核心参数分支去掉指数尺度比。该捕获沿用原RC总价格，不重复消费容量；无需e_t的输入无关下界。

**一般预算唯一仍欠缺的是：原剩余行的bad比较质量κ_r与good质量比A/wg的联合尾，能否在真实门及全部外交通下可积支付。** RG20把它明确收缩为A/wg>M_r的部分；Hhat<L⁺分支尚无RG17的比较，仍属于这个联合几何缺口。原high只确保bad的wg质量≥e_g/2，并未确保其中有固定比例满足K₀≥uTwg；RG10–11已显示为何这个比较不能仅由核严格正推断。此处没有再添加标量反例。

若使用原时间FTC上包络，RG16分支的剩余可进一步控制为

\[
\int\rho\,d\mu_r\le\frac1{e_g}
\int_{S_g}[A(v)-M_rw_g(v)]_+d\nu(v),
\tag{RG24}
\]

它明确保存了坏端对好端阈值的依赖；RG24本身仍不是已付预算。若这个FTC放松过粗，应在保留χ_FA、真实δ及同一Π_t²的原交通上继续使用RG20，不能由RG24未付推断原任务不可能。

最终付款仍需对完整真实d𝒯=q^{-1}p h_R a_history dx dβ(y)dν(z)取期望、唯一j/种子求和，并乘2Λ。若先用SI2积分硬z，则外16/3及含实际接收依赖的cξ按SI4–5保留；两种次序不能同时领取两份硬帽。β−ν、时间与选择器费用均未删除。N_Z不返回，N_Zc/Ndel各留原位一次。未作数值试验，未作git/PDF。到这一缺口停止。


<!-- SOURCE rc_audit.md SHA256 53e22589d92bc51fbe77d0093b5b430055935a9afd37d67cfd698a6e3034b46e -->
# R134 RC余额独立先审

本先行稿读取本轮 `TASK_CONTEXT.md` 后，独立审计给定RC定义，尚未读取作者 `receiver_rc_geometry.md`。只写本文件，不修改作者，不git/PDF。下列是精确恒等式与明确条件的标量不等式，不能单独登记为原模型的一般支付。

## RCA1. 固定接收点与规范

固定一个实际接收点及其共同参数。令ν为有限、非零正测度，E可测，A≥0、K0≥0、J>0可测，T>0、D≥0、q有限。须有

\[
0<Q_J:=\int J\,d\nu<\infty,\qquad \int K_0\,d\nu\le q.
\]

原FIRST另有Q_J≤q；前一条件已足以保证本节RC非负。令

\[
U=1_E\min(TA,DK_0),\quad
\alpha=\frac{Dq-\int U\,d\nu}{Q_J},\quad
F_{rec}=U+\alpha J.
\tag{RCA1}
\]

因U≤DK0，α≥0且有限；∫F_rec dν=Dq准确成立。α是**整份当前来源ν**及当前E、A、K0、J、T、D、q的函数。仅在这一固定对象内部可把它当标量；更换来源、接收点或参数后必须重算。有限ν本身不保证∫Aν有限，下文不用∞−∞；涉及有限一阶矩的凸性/差分结论会明确附加条件。

定义概率μ=Jν/Q_J及无量纲变量

\[
X=TA/J,\quad Y=DK_0/J,\quad
b=Dq/Q_J,\quad
u_0=\mathbb E_\mu[1_E\min(X,Y)].
\tag{RCA2}
\]

此处ν₀是标量名，与来源测度ν不同。有ν₀=(∫Uν)/Q_J≤b，α=b−ν₀。μ不要求来源坐标独立；J>0保证除法合法。

## RCA2. 剩余ρA的准确尾公式

在E上原定义ρA=(A−F_rec/T)_+，故

\[
\rho A=\frac JT\big[X-\min(X,Y)-\alpha\big]_+
=\frac JT\big[(X-Y)_+-\alpha\big]_+
=\frac JT(X-Y-\alpha)_+.
\tag{RCA3}
\]

最后一步严格使用α≥0。定义V=1_E(X−Y)_+。则全E余量准确为

\[
\boxed{\int_E\rho A\,d\nu
=\frac{Q_J}{T}\mathbb E_\mu(V-\alpha)_+
=\frac{Q_J}{T}\int_\alpha^\infty\mu(V>t)\,dt.}
\tag{RCA4}
\]

这里积分和等式允许+∞，均只用非负Tonelli。也可写∫₀^∞μ(E∩{X−Y>α+t})dt；t≥0时事件已经使X−Y>0。严格或非严格尾门只差至多可数原子阈值，对Lebesgue阈值积分无影响，但实际模型中的严格bad/非严格good不得因此改定义。

RCA4是**截断一阶尾**，不是单点尾概率。仅有μ(V>α)或Markov的O(1/t)控制不自动支付其积分；无需另外制造反例才能识别这一逻辑边界。

## RCA3. 全局q容量如何进入截断阈值

由FIRST的全局K0上界而非局部假设，定义

\[
S=b-\mathbb E_\mu Y
=\frac D{Q_J}\left(q-\int K_0\,d\nu\right)\ge0.
\]

令U₀=1_E min(X,Y)，W=Y−U₀≥0。则

\[
\boxed{\alpha=S+\mathbb E_\mu W
=S+\mathbb E_\mu[1_E(Y-X)_+]
+\mathbb E_\mu[1_{E^c}Y].}\tag{RCA5}
\]

这完整列出q的作用：全局K0容量松弛、E内对向缺口与E外K0质量，三者合成当前截断阈值。不能把E外质量删掉后仍声称α等于原值。删除任一非负项只给α的下界，继而给余量的上界，不再是身份。

若再用原FIRST的Q_J≤q，只能推出b≥D（D≥0），不能由此推出α≥D。实际α=b−ν₀，已付的捕获ν₀必须扣除。对相同固定ν、E、A、K0、J、T、D增大q，α线性增加，余量非增；但不同来源的Q_J、ν₀及μ也变化，不能只比较各来源的q/Q_J就冻结全局α。

若∫_E Aν<∞，则EV<∞，可使用

\[
\mathbb E(V-\alpha)_+
\ge(\mathbb EV-\alpha)_+
=\left(\mathbb E[1_EX]-b\right)_+.
\]

换回原量，得到

\[
\boxed{\int_E\rho A\,d\nu\ge
\left(\int_E A\,d\nu-\frac{Dq}{T}\right)_+.}\tag{RCA6}
\]

这是总容量对剩余量的**下界**，不能反向当成余量上界。相应朴素上界为

\[
0\le\int_E\rho A\,d\nu
\le\frac1T\int_E(TA-DK_0)_+\,d\nu
\le\int_E A\,d\nu,
\tag{RCA7}
\]

允许无穷。q只是截断阈值的一部分；仅有FIRST的三个质量上界，没有给出V的可积截断尾价格。已付捕获U与剩余αJ不能当成两份独立Dq容量再次领取。

## RCA4. 可用的凸性、加权尾与不可冻结的量词

对固定V及同一概率μ，截断尾函数L(a)=Eμ(V−a)_+在a≥0上非增且凸。若EV<∞，L还为1-Lipschitz，任意a,b≥0有|L(a)−L(b)|≤|a−b|。每个点的(X−Y−a)_+在固定E上的(X,Y,a)中为凸函数，且对Y、a非增；因此取均值时Jensen的通常方向是**平均余量≥均值余量**，不是一个消除随机尾的上界。

RCA5还给一个确实合法的Jensen上界。W=Y−U₀≥0且EW有限，S≥0。对每个固定来源v，函数t↦(V(v)−S−t)_+凸，故

\[
(V(v)-\alpha)_+=(V(v)-S-\mathbb EW)_+
\le\int(V(v)-S-W(z'))_+\,d\mu(z').
\]

非负Tonelli得

\[
\boxed{\int_E\rho A\,d\nu
\le\frac{Q_J}{T}\iint(V(v)-S-W(z'))_+
\,d\mu(v)d\mu(z').}\tag{RCA8}
\]

这是上界而非身份；两份μ的产品是此标量Jensen步骤的数学实现，不证明来源坐标独立，不把实际双门或δ变成这里的V−W。舍去S只会继续放大右侧，不能说全局q松弛无费用。

若保留额外任意非负可测接收/来源权G，准确加权尾为

\[
\boxed{\int_E G\rho A\,d\nu
=\frac{Q_J}{T}\int_\alpha^\infty
\int G\,1_{\{V>t\}}\,d\mu\,dt.}\tag{RCA9}
\]

无独立性假设，允许+∞。G可包含实际χ_FA、history、门指示或已经保持原定义的来源权；它们不能在变换后自行消失。若G还依赖第二来源，先在原第二来源上保留非负积分即可，不能将G重加权后的来源当新ν并沿用旧α身份。

量词要求如下：所有公式先固定实际接收点、当前来源ν及共同参数，再定义Q_J、μ、U、α。对来源分壳可用**同一个全局α**把RCA4按壳指示精确相加；若在每壳用各自ν重算α，则得到不同RC机制，其捕获容量也改变，不等于原ρ。对接收点x积分必须使用α(x)、μ_x及原cξ、χ_FA、history、β−ν、j、尺度/soft选择的实际依赖，不能先把α冻结为跨x常数。上述点态凸性不自动给出“来源测度混合后余量凸”的定理，因为α、μ和Q_J同时依赖来源。

**先行判定：PASS（准确余额恒等式与明确凸性方向）。** RCA1–9已独立推导并保存；FIRST全局q保证α≥0并进入真实截断阈值，但尚无V加权尾的一般积分付款。原高门、FIRST与双门只可在实际接收点及原依赖下调用，不能在删掉接收积分后续用。本稿未重新领取捕获容量，未调用已消费N_Z，亦未把负项附上ρ或χ_FA。等待作者冻结后追加实读后审。

## RCA5. 冻结RC作者稿的实读绑定与旧余额/核心范围

先行RCA1–9完整落盘后才读取本轮 `receiver_rc_geometry.md`，实读SHA-256为 `b607181be49d271827b98af50901990272bbbdb85c0094c32c85889b0c376526`。本后审只追加，不修改先行稿。本审另已完成独立 `fa_time_audit.md`，两文件责任分离。

RG1–3与先行余额规范一致：σ就是μ，c就是b；在E上的ρA=J(X−Y−α)_+/T准确。作者没有把∫F_rec=Dq重新用于余量支付，亦未冻结α跨来源/接收点。为确认RG3/24所用既有FTC接口，实读R126 `recycled_capacity_private.md` RC1–9：原完整行上μ_r≤1_S Aν/e_g、S外及A=0无该正交通、B=1原捕获保持，且实际余权为1_E(1−F/(TA))_+。因此将当前ρ乘在该非负测度支配上是合法上界，负项不附ρ。

RG4–9的TH0ⁿ=m_sⁿ、核心K0/T≥(H0/Hhat)ⁿ、A≤η_Awτ及wτ≤(g/τ)ⁿwg均正确。H0≥a时Hhat≤H0，D≥1、A≤1使核心全捕获；H0<a时必须保留κ<1。严格余量门对应Wg严格小于Hcore，等号层也被捕获。核心外χ_s的d及r费用完整保留，没有证明真实来源的这两个量具有可积尾。作者明确将初期核心事实及其推论列为旧捕获，不登记为R134新付款。

RG10–12的核尾检验与点态粗比只记录能力边界：k=2sinh(1/2)、φ(r)~ke⁻ʳ/r、C(r)~k²e⁻ʳ/r的常数及RG11方向平移系数正确；Hhat<b尾比Y趋0、Hhat=b尾比Y=Dsⁿ正确。它们没有被授予全部good/high/FA/history资格，亦未被用于声称原交通不可能或新预算。后审重点以下真实same-x耦合。

## RCA6. RG13–20的同接收点bad余额—good余量耦合

E⊂S_g且D_g⊂Eᶜ，FIRST给∫K0ν≤q。于是

\[
\alpha Q_J=Dq-\int U\nu
\ge D\left(\int K_0\nu-\int_E K_0\nu\right)
\ge D\int_{D_g}K_0\nu.
\]

RG13准确；这是原共同α的余额下界，不向bad端另付第二份Dq。good与FIRST给∫_Sg wgν≤Kq/p，高门p e_g≥2Kq从而∫_Dg wgν≥e_g/2。非零实际高支行上e_g>0、s>0且K0严格正，因此α>0；但没有来源无关的正下界，作者未偷换这一量词。

κ_r=(Te_g)⁻¹∫_DgK0ν等价于bad端K0/(Twg)的wg加权质量；wg>0使商合法。RG14层蛋糕κ_r=∫₀∞b_r(u)du及κ_r≥u b_r(u)正确。RG15由RG13再用实际高门得到

\[
\alpha\ge DT e_g\kappa_r/Q_J,
\qquad p\alpha/(KT)\ge2D\kappa_r q/Q_J.
\]

所有量保持同一接收点与整份当前ν。没有删除接收积分后再调用high/FIRST，没有把κ_r替成bad点的下确界。

在**Hhat≥L⁺**分支，共同s的真实混合形状p_s在绝对坐标上非增，故每个L_i≤Hhat有
L_i⁻¹p_s(u/L_i)≤(Hhat/L_i)Hhat⁻¹p_s(u/Hhat)。乘积给K1+K2≤C_rK0，C_r=(Hhat/L)ⁿ+(Hhat/L⁺)ⁿ，RG17正确。这个比较不适用于Hhat<L⁺，作者保留了该补集。

同一actual good门3pwg/K≤K1+K2+J≤C_rK0+J，继而

\[
DK_0+\alpha J\ge\min(D/C_r,\alpha)(C_rK_0+J)
\ge(3p/K)\min(D/C_r,\alpha)w_g.
\]

因此真实余量阈值系数至少

\[
\frac{3p}{KT}\min(D/C_r,\alpha)
\ge3D\min\{p/(KTC_r),\,2\kappa_r q/Q_J\}=M_r.
\]

正部函数对被减阈值非增，给ρA≤[A−M_rwg]_+。在E上这是RG2与真实核比较的直接组合；E外actual good正交通余权按原约定为0，所以RG20完整成立。乘原χ_FA、δ、Π_t²、Ψ、history等非负因子保持方向，未将它们移植到负项。

**RG13–20 PASS。** 这是有准确尺度分支的实际same-x双端耦合，确实收缩当前原RC余量支持；它沿用已付捕获的共同余额，而非把早期标量恒等式登记为新支付。

## RCA7. RG21–24核心常数、未支付联合尾与最终判定

除Hhat≥L⁺外，若还满足Hhat≤H0和y∈Q_L(x)，则原混合核p≥m_sⁿ/Lⁿ，而

\[
TC_r=T\widehat H^n(L^{-n}+(L^+)^{-n})
\le TH_0^n(L^{-n}+(L^+)^{-n})
\le2m_s^n/L^n.
\]

于是p/(TC_r)≥1/2；FIRST给Q_J≤q且Q_J>0，故q/Q_J≥1，得到RG22

\[
M_r\ge3D\min\{1/(2K),2\kappa_r\}.
\]

若bad位于Q_Hhat(x)的wg质量为β_r e_g，核心K0/T≥(H0/Hhat)ⁿ≥1及wg≤1给

\[
\kappa_r=\frac1{e_g}\int_{D_g}\frac{K_0}{Tw_g}w_g\nu
\ge\frac1{e_g}\int_{D_g\cap Q_{\widehat H}}w_g\nu=\beta_r.
\]

β_r≥1/(4K)时2κ_r≥1/(2K)，所以M_r≥3D/(2K)，全部actual good且A/wg≤3D/(2K)来源余ρ=0。核心系数3、2及1/(4K)均正确；不是仅由α>0推断固定捕获比例。上述三个额外可测分支必须共同保留，不能把该常数阈值推广到全部实际行。

RG24以已审μ_r≤1_S Aν/e_g及RG20得到

\[
\int\rho\,d\mu_r\le e_g^{-1}\int_{S_g}[A-M_rw_g]_+\,d\nu.
\]

这是具有真实bad质量κ_r依赖的good余量上界，未支付其在完整raw d𝒯、β−ν、唯一j、种子、尺度/soft选择和真实dx下的联合尾。当前审计只认证Hhat≥L⁺时RG20，以及附加核心分支的RG22–23。Hhat<L⁺补集与A/wg>M_r尾均原位留账；不能靠“κ_r>0”或核处处严格正将其免费删除。

作者最终外层若用raw d𝒯只乘2Λ；若先积分硬z则用SI4–5的16/3与实际cξ，两次序不双领硬帽。原捕获Dq不重复使用，已消费N_Z不返还，N_Zc/Ndel各一次并保持原门。本后审没有否定路线或新增抽象压力例，没有将FTC放松后的尾未付误读为原交通不可付。

**最终判定：PASS（余额恒等式、实际same-x条件耦合及正确边界）。** 冻结作者RG1–24未发现需修改的数学错误。初期核心事实是旧捕获；本轮新增RG20收缩了原RC余量支持，核心RG22–23常数正确，但一般bad比较质量κ_r与good比A/wg的联合尾及全自适应根阶总预算仍未证明。


<!-- SOURCE strict_balance_corollary.md SHA256 31a84ac6c4ee22a241d4988d06d893d3b6bd7b1925f8f8a09eb95616da39460b -->
# R134 实际high行的RC余额严格正性（主代理推导，待审核）

假设同一合法行满足s>0、ν非负、e_g=∫Zg wgν>0、FIRST ∫Q*ν≤q、high p e_g≥2Kq，且q>0,K>0,p>0。令Sg={pwg≤KQ*}，Dg为其严格补集；E为实际RC集合，E⊂Sg。J,K0为原strict-soft测试，故它们在有限来源位置严格正。所有相关积分有限，QJ=∫Jν>0。

原good门给∫Sg∩Zg wgν≤Kq/p≤e_g/2，故∫Dg∩Zg wgν≥e_g/2>0。因为wg>0、K0>0，推出∫Dg K0ν>0。

RC余额精确满足
\[
 \alpha_{rec}Q_J=Dq-\int_E\min(TA,DK_0)d\nu
 \ge D\int_{E^c}K_0d\nu
 \ge D\int_{D_g}K_0d\nu>0.
 \tag{SB1}
\]
因此实际合法high行有α_rec>0。这里FIRST仅在第一步使用q≥∫K0ν，未消费额外容量；SB1不提供输入无关的正下界，也不允许把1/α_rec当常数。

结论不删除旧α_rec=0边界工具或数值记录。那些材料可以属于非high行、非严格软核、给定零核表或辅助扩展接口；在未核完整前提时不能授予实际high身份。也不声称所有历史α0构造无效，本式只限定此处明确列出的前提。


<!-- SOURCE rc_tool_index.md SHA256 0e0f81eb9de19460237e6e44e39f066e994268bd681179059c517fcf9b1b4ebd -->
# R134 RC 历史与费用索引

范围：依 R134 TASK_CONTEXT.md，仅在相邻 R125/R126/R127 中用 rg 定位与 RC 容量、预算份额、硬触发及后续余项相关的记录。以下是出处索引，不构成新数学认证。行号均为相对所列文件。

## RC 的原定义与已证明界

| 对象 | 出处 | 已写明的定义/结论 | 适用范围与容量状态 |
|---|---|---|---|
| D 与原硬帽 | R126 recycled_capacity_private.md:12–17，公式 AC2/RC1 接口 | D=max{1, ε√ℓ/(8Λ)−16/(3√ℓ)}；非零高支行用 μ_r≤1_S Aν_V/e_g、硬 B 行质量≤16/(3ℓ)、∫K₀dν_V≤q。R126 RC 的 D 沿用 AC2。 | D≥1；硬项已按原 16/(3ℓ) 计入行价。行 116–127 的 RC8–9 说明此回收保持 AC 原同价。R127 的 ε_RC 预算选择见下表；R126 原式仍记 ε。 |
| 作用域和最低保留底座 | R126 recycled_capacity_private.md:20–31，RC2 与命题一/二 | E=S∩{B=0,A>0}，U=1_E min(TA,DK₀)，Q_U=∫U dν_V≤D Q₀≤Dq，Q₀=∫K₀dν_V。原软测试 J=P_{1,b}(x−v)>0，Q_J=∫Jdν_V≤q。 | 固定完整实际行后定义，之后对 v,t 不重选。B=1 的部分按原硬帽处理；A=0 不形成实际 μ_r 质量。该范围不是全来源空间的捕获比较。 |
| RC 共同系数及新增核 | R126 recycled_capacity_private.md:35–55，RC3–4 | C_rec=Dq−Q_U；α_rec=C_rec/Q_J（Q_J>0），Q_J=0 时置 α_rec=0；F_rec=U+α_rec J，且 ∫F_rec dν_V=Dq（正交通分支）。 | 同一原行固定的共同 α，非按来源/时间调参。若 Q_J=0，因 J 全正可得 ν_V=0，这是零交通退化分支。α 可为零：包括零测度分支；正测度分支若 C_rec=0 也不应擅自假设为正。 |
| 回收余量分解 | R126 recycled_capacity_private.md:57–69，RC5 | C_rec=D(q−Q₀)+D∫_{E^c}K₀dν_V+∫_E(DK₀−TA)_+dν_V。 | 三项分别是原容量余量、E 外可回收容量、E 内饱和超额；非负且总量≤Dq。已证明即使 Q₀=q 后两项仍可使 C_rec>0，但不保证每行严格正。 |
| B 的硬触发与捕获定义 | R126 recycled_capacity_private.md:20, 27, 73–89，RC2/RC6 | 新捕获在 E 上用 b_F=min(1,F/(TA))；E 外保留旧 b_D，A=0 依原约定取 1。由 F≥U，在 E 上保留旧捕获；B=1 由原硬帽支付、不加入 E 的软底座。 | 已证明的是实际 S 内 ν_V-几乎处处、继而实际 μ_r 下不降低旧捕获；不是全域 F≥DK₀ 或全域支配。RC 审计亦确认此限域：R126 recycled_capacity_proof_audit.md:37–45。 |
| RC 同价界与已消费账 | R126 recycled_capacity_private.md:91–130，RC7–9；recycled_capacity_proof_audit.md:47–69 | RC8 行费用仍为 16/(3ℓ)+D/√ℓ；D>1 时 X 系数精确 ε，D=1 的剩余小维分支回原有限维母核。RC9 是原 C_G(ε)，不另加捕获、节点或时间费。 | RC9 替换旧 AC11 捕获付款，不与 AC4 或 SC5 相加。原 −N_{Z^c}、−N_del 各保留一次；已消费的 N_Z 不返还。时间/来源积分顺序仍保留原 z′,t,ν³/e_t²、门、完整 d𝒯、唯一 j 与种子求和。 |
| TA 与 K₀/J 的剩余关系 | R126 recycled_capacity_private.md:78–89, 137–169，RC6/10–12 | RC 余项精确写为 1_E(1−F_rec/(TA))_+。令 Δ_E=1_E(TA−DK₀)_+；固定 RC3 的 J 要点态全覆盖需 Δ_E≤α_rec J 于 E。允许任意形状 H 的完整 E 覆盖当且仅当 M_E=T∫_E A dν_V≤Dq，取 F†=1_E TA 可达；这不同于固定 J 自动覆盖。 | M_E≤Dq 是 ν_V-全 E 核覆盖条件，可能强于只对实际 μ_r 付清；RC 材料未证明所有实际行满足。无新余项免付结论。 |

## R127 的 ε_RC、α_rec=0 与后续筛选账

- R127 soft_partition_route.md:11,24：预先在总吸收额内固定 ε_RC, ε_B>0，ε_RC≤1；RC 的 D、α_rec、b_rec 都按 ε_RC 构造并冻结。若总槽为 ε_tot，需先满足 ε_RC+ε_B≤ε_tot。ε_B 是新分支明列预算，不能从已用吸收槽追加；RC 替换 SC 仍是原同价，不产生第三笔预算。
- R127 soft_partition_route.md:53–63：重列 U,Q_U,C_rec=Dq−Q_U, α_rec=C_rec/Q_J,Q_J,Q₀；限定正 α 的 CDF 论证处明写 Q_J>0,C_rec>0。Q_J=0 是零来源交通；α_rec=0 单独留给 SP18，不套用任何除 α 的公式。此限制只适用于正 α 的后续分支，不把 RC 的零值定义删除。
- R127 soft_partition_route.md:236–244：α_rec=0 行保留真实残项 R₀(r)≤(Te_g)⁻¹∫_E(TA−U)_+dν_V=(Te_g)⁻¹∫_E(TA−DK₀)_+dν_V，仍须对原 d𝒯 积分；α_rec=0 且 K₀=0 时相应下降加权来源质量完整留账。SCα_SC=0、但回收后 α_rec>0 的行可进入正 α 路线，不能把“回收必正”当作前提。
- R127 soft_partition_route.md:101,129,148–153：被认证清除的块可在同一 b_rec 下剔除；失败块不自动付款。坏端 K_m(z′)=0 是 CDF 在零处的原子，保留；共享 K₀(v)=0 在正 α 分支不破坏使用 J 的 SP8。余权仍是原 1−b_rec，时间权仍保留 w_t/e_t 与 1_{Z_t}。

## H₀、Hhat 与命名核对

- 在限定的 R126 RC 原稿/审计和 R127 soft_partition_route.md 中，未找到明确定义为 H₀ 的对象；索引不按字面猜造。
- R127 joint_geometry_route.md:22 明确说原共同低核为 K₀=P_{s,Hhat}(x−v)，并注明它不是另选的 K 或 Q*。此处找到的是 Hhat 在 K₀ 中的用途；限定材料未显示可将其独立替换/重选的 RC 结论。
- R127 soft_partition_route.md:148–153,236 使用阈值名 U_H，与上述 Hhat 不同；α_rec=0 时明确“不定义 U_H/γ”。不要把 U_H、Hhat、未找到定义的 H₀合并解释。

## R125 触发层的边界提示

R125 joint_geometry_payment_statement_audit.md:12–18 的原捕获为 b=B+(1−B)min{1,K₀/(TA)}（A>0）；需要新增付款的层只能是 B=0,A>0,T>0,0≤K₀<TA（PS1）。同文件 :62–75 说明低门上原余权为 1−K₀/(TA)，并列出 PS3–5 额外条件；:68 明确 PS2 全正性不覆盖真实 K₀=0 低门交通。该 R125 证明只作用于实际原 K₀ 与满足原比较资格的集合，不将包络核自动替代原核。

索引内的 RC 证明边界：R126 recycled_capacity_private.md:3,199–201 明说未证明所有行全覆盖或一般根阶闭合；R127 research_checkpoint.md:9 记载采用 ε_RC 预定参数并预留 ε_RC+ε_B。这里仅定位历史的已证上界与剩余账，不认证 R134 总目标。


<!-- SOURCE numeric_final_audit.md SHA256 65f11685f99a0356caf5138481e114b7328017031621b3a6166c56c1d71debbe -->
# R134 数值最终独立静态审计

本审计仅新增本文件，不修改其他代理文件；未运行或导入 `rc_exact_check.py` producer，也未改其 JSON。读取修复脚本、JSON、冻结协议、勘误和 RG13–20 稿。随后从现有 JSON 输入及冻结协议的 K1=K2=K0，在独立内存代码中以 Fraction 重建全部 12 行。有限标量通过不认证真实位置核、Hhat/FA/FULL、外交通或一般结论。

## 身份与分母

- 修复脚本 SHA：`e5bd9cf17fa1a7650bbf5c86078f181475dfdf4a9e18f99de5a200e6e8fa2d7c`。
- 复核 JSON SHA：`0ae8d2890ee92e69674f3f05e6069f1ebd01832447cba4418f49dac6be95dda6`。

两者与主代理给定 SHA 一致，JSON 内 script_sha 也与修复脚本一致。静态实现中 `QJ=ints["J"]`，以下三式均使用此 QJ：alpha=(Dq−∫Uν)/QJ，Mr=3D min(p/(KTC),2κq/QJ)，alpha_lower=DT eg κ/QJ。`intQ=∫Qν` 仅参与 q=max 三积分及 q 的支配检查，没有混入这三个分母。所有样本 QJ=1/100。

## 全样本独立重建

独立重建 ∫K0ν、∫Jν、∫Qν、eg、q、bad_K0、E、U、alpha、kappa、Mr、alpha_lower、rhoA、bound_rhs，逐一比较 264 个有理字段，并比较全部逐原子 gate/bound/mixture 布尔、逐行检查和总断言。12 行均与修复 JSON 相符，全部所列标量检查为真。独立重建使用严格 bad 补集与非严格 good，不猜测真实核门；bad 原子 A=0 的零余量保留。未计算浮点 log。

|行|D|QJ|alpha|Mr|alpha_lower|标量检查|
|---|---|---|---|---|---|---|
|I1|1|1/100|1/2|6/101|1/2|通过|
|I2|1|1/100|1/2|6/101|1/2|通过|
|I3|1|1/100|1/2|6/101|1/2|通过|
|I4|1|1/100|1/2|3/5050|1/200|通过|
|P1|1|1/100|1/2|3/5050|1/200|通过|
|P2|1|1/100|1/2|3/505000|1/20000|通过|
|P3|1|1/100|1/2|3/50500000|1/2000000|通过|
|P4|1/10|1/100|1/20|3/505|1/20|通过|
|E1|1|1/100|1/2|3/505|1/2|通过|
|E2|2|1/100|1|3/2525|1/100|通过|
|E3|1|1/100|1/2|3/1010000|1/20000|通过|
|E4|2|1/100|1|4/101|1|通过|

## P4 范围与首轮错误记录

P4 冻结 D=1/10，确实不满足原 D≥1 的参数域，只能列为扩展标量代数测试；本次逐式一致不将其算入原参数域通过案例。其余 11 行 D≥1，但也只认证各自有限标量接口。

`rc_numeric_errata.md` 明确写出首轮分母误用、三处影响、首轮脚本/JSON SHA 与运行时间，并明确“首轮 JSON 的全断言 PASS 无效”，以及“第二轮输出不可称为单次运行成功”。首轮 JSON 已被覆盖，只留下身份散列；本审计没有读取被覆盖的首轮字节，不能独立重验其 SHA 或恢复其完整结果。当前修复 JSON 没有内嵌首轮错误或运行次数，失败史须连同勘误文件阅读。此限制不影响当前 12 行的独立精确一致性核验。

## 时间价格与 flux 运行史

FT8 的 D[1+log_+(n/4)] 时间价已经静态核对：L≤D，n≤4 时 nL/4≤D；n>4 时第一支≤D，第二支由 nL/(4D)≤n/4 与 log 单调性得到界。无需数值 log。

本代理 flux 协议冻结后首轮在 I4 非零预期断言失败，按主代理授权作第二次恢复，菜单和数学断言不变。恢复 JSON 全记录 12×36=432 配对、首轮实际 traceback/退出状态/脚本 SHA、恢复运行身份；I4 原预期失败如实保留。I1、I2 的正面积层加权 δ 非零；I3 t=g 仅为端点代数例。未把恢复称为一次成功。

结论：修复 RC 的 QJ 分母及全部 12 个现有标量结果一致；P4 属扩展范围，首轮 PASS 无效且已明确记载。一般结论和实际核实现没有由这些数据认证。完成后停止。
