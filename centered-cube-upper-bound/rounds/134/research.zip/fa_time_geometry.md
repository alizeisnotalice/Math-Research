# R134：保留 FA 与真实接收点的未来 score 面积层

状态：仅处理同一真实接收行上的 FA/good 与时间几何；不重复第三测试或 Hellinger。先写准确命题和量词，再逐节给证明、可付范围及未覆盖费用。只写本文件，不操作 Git/PDF，不修改其他文件。

## 1. 准确候选与量词

固定任意原合法有限交通截断和完整实际行 \(r=(\omega,V,j,x,y,z,\mathrm{history})\)。在该行的原 high 域，\(p=p_x(y)>0\)，同一 \(Q=Q_x^*\)、\(g=g(x)\)、\(B=B_{FA}>0\) 保持实际值。对任意原 far 时间 \(t\le g\)，保留两份同一真实概率 \(\Pi_t\)，并定义
\[
 k_t(v)=\#\{i:\alpha_i(y,v)<t\},\qquad
 \delta_t(v,z')=[k_t(v)-k_t(z')]_+,
\]
\[
 \eta=\log(g/t),\quad
 \Delta_{t,g}(v)=\log\frac{w_t(v)}{w_g(v)}
 =\int_t^g k_u(v)\frac{du}{u},\quad
 L_g(v)=\frac{Q(v)}{p w_g(v)}.
\tag{FT1}
\]
所有原 bad/good、\(\Psi\)、\(\chi_{FA}\)、\(\rho_{rec}\)、来源支持和 history 均按实际值保留。来源向量无需坐标独立；\(\Pi_t\) 可以随 t 改变。

候选 A（精确夹层）：在 good(v) 与原正 FA 门同时成立时，
\[
 \frac1K\le L_g(v)<B\delta_t(v,z')e^{\Delta_{t,g}(v)}.
\tag{FT2}
\]
这给 \(\delta_t e^\Delta>1/(KB)\)，但其方向不是 \(e^\Delta\) 或 \(\delta_t\) 的上界。

候选 B（新增可计价面积层）：对任意预先指定的 \(D\ge0\)，将真实正项限制到明确可测层
\[
 E_D(r,t,v)=\{\Delta_{t,g(x)}(v)\le D\}.
\tag{FT3}
\]
不对来源作新归一化。定义该行的原来源/时间因子
\[
 \mathscr F_D(r)=\int_{J_{far}(r)}\frac{dt}{t}\iint
 1_{D_g}(z')1_{S_g}(v)\Psi\chi_{FA}\rho_{rec}(v)
 \delta_t1_{E_D}\,d\Pi_t(v)d\Pi_t(z').
\]
则候选价格为
\[
 \mathscr F_D(r)\le\Phi_n(D)
 :=\min\left\{\frac n4\log2,
 D\left[1+\log_+\frac{n\log2}{4D}\right]\right\},\quad D>0;
 \qquad \Phi_n(0)=0.
\tag{FT4}
\]
该候选是行内联合积分上界，尚不宣称其外真实接收质量有输入无关预算。它将该层的时间价格从 \(O(n)\) 改成 \(O(D[1+\log_+(n/D)])\)，不要求 \(\delta_t=k_t(v)\)，也不改变来源概率。

## 2. 精确夹层的方向与 score 面积

逐坐标积分 \(\log\min(1,\alpha_i/u)\) 得 FT1，且 \(k_u(v)\) 随 u 非减。于是对 \(t<g\)，
\[
 0\le\Delta_{t,g}(v)\le n\eta,
 \qquad \Delta_{t,g}(v)\ge k_t(v)\eta\ge\delta_t(v,z')\eta.
\tag{FT5}
\]
严格 score 定义 \(\alpha_i<t\) 在等号处只会减小 \(k_t\)，不影响此式。关键是最后一步仅使用 \(\delta_t\le k_t(v)\)，没有把两者等同。

FA 分母仍是原 \(w_t\)：\(\ell_t=L_g e^{-\Delta}\)。good 给 \(L_g\ge1/K\)，FA 给 \(L_g e^{-\Delta}<B\delta_t\)，从而得到 FT2。反向不等式 \(e^\Delta\delta_t\le C\) 不成立；即便 \(L_g=1/K\)，增大 \(\Delta\) 只会让原不足门更容易成立。以此夹层直接“支付”高 \(\Delta\) 或 WJ 的重尾费用，方向错误。

在 FT3 层，FT5 给 \(\delta_t\le D/\eta\)。同一 \(\Pi_t\) 下，若 \(X=k_t(v)\)、\(Y=k_t(z')\)，两份抽样独立同分布，则
\[
 \mathbb E\delta_t=\tfrac12\mathbb E|X-Y|
 \le\mu_t-\mu_t^2/n\le n/4.
\tag{FT6}
\]
中间不等式来自 \(|X-Y|\le X+Y-2XY/n\)。来源向量坐标是否独立与此无关。保留原门和余权只减小非负积分，所以每个实际 t 的完整来源因子至多 \(\min(n/4,D/\eta)\)。原 \(a/c_j\le t\le g\)、\(a/c_j\ge g/2\) 给 \(0<\eta\le\log2\)（原 far 端点还给 \(\eta\ge u_{old}/n>0\)），且 \(|dt/t|=d\eta\)。在 \(\eta=4D/n\) 切分，得 FT4；如果切点在时间窗外，积分为 \((n/4)\log2\)，FT4 仍有效。

## 3. 整数 score 与 FA 提供的进一步时间支持

原 score 是整数。因此 \(\delta_t>0\Rightarrow k_t(v)\ge1\)，由 FT5，FT3 层的正项必满足
\[
 \eta\le D.
\tag{FT7}
\]
这比只套 \(\delta\le n\) 更有效：面积帽 D 不仅限制 score，还限制其可出现的时间长度。再联用 FT2，
\[
 \frac1K<B\delta_t e^D\le B\frac D\eta e^D,
 \qquad \eta<KBDe^D.
\]
所以定义
\[
 L_D=\min(\log2,D,KBDe^D),
\]
正项在 \(\eta>L_D\) 上为零。边界上的单个时间点不影响 dt 积分。更细的实际位置版本为 \(L_D(v)=\min(\log2,D,BDe^D/L_g(v))\)；不得先把随 v 变化的版本提出来源积分而省略其层质量。

对于 D>0，令
\[
 \Psi_n(D,L)=
 \begin{cases}
 nL/4,&L\le4D/n,\\
 D\,[1+\log(nL/(4D))],&L>4D/n.
 \end{cases}
\]
则保留所有原门的行内时间/来源积分满足
\[
 \boxed{\mathscr F_D(r)\le\Psi_n(D,L_D)
 \le D\,[1+\log_+(n/4)].}
\tag{FT8}
\]
最后一步使用 \(L_D\le D\)。D=0 时 \(\eta>0\) 上 \(k_t=0\)，所以 \(\mathscr F_0=0\)。原 far 门还给 \(\eta\ge u_{old}/n\)；若 \(L_D<u_{old}/n\)，该层严格为空，可在 FT8 中进一步按实际端点积分。不能删除原 far 下端点后声称实际层非空。

当 \(KB e^D\ge1\) 时 FA 不再缩短 FT7 的时间支持。特别，原已付 FA 分支常用 \(KB=4\Lambda\log2/\varepsilon_{FA}\)，此时不能宣称 FA 总能额外省一个大常数。FT8 的普遍改善来自精确未来 score 面积；FA 的进一步作用及其适用条件已经显式列出。

## 4. 保全真实接收积分的局部误差付款

令 \(P_{I,D}^{rem}\) 为 RT2 的原正余泛函仅新增 \(1_{\{\Delta\le D\}}\) 后所得的子项。保留原 RT1 的完整外测度 \(d\mathcal T_I\)，不先删除实际 x、选择器或 history。逐个实际行应用 FT8，Tonelli 给
\[
 P_{I,D}^{rem}\le\Psi_n(D,L_D)
 \mathbb E\sum_{V,j}\int1_{A_{hi}}d\mathcal T_I
 \le4\Psi_n(D,L_D)X.
\tag{FT9}
\]
第二步只调用原完整行总账 \(T_{small}=\mathbb E\sum_{V,j}\int d\mathcal T\le4X\)，不是 FIRST 测试核容量，也不是把来源概率误称为容量。原唯一 j、真实 \(dx\)、\(\beta-\nu\)、硬 z 和 s/L/R/g 选择器都在该外测度中原样保留；逐行标量上界不需要对它们作固定块覆盖。它同样不使用已付 RC 捕获容量。

signed 外系数仍为 \(2\Lambda\)，所以
\[
 2\Lambda P_{I,D}^{rem}
 \le8\Lambda D[1+\log_+(n/4)]X.
\tag{FT10}
\]
对任意 \(\varepsilon_D>0\)，预先选定
\[
 D_{n,\varepsilon_D}
 =\frac{\varepsilon_D}{8\Lambda[1+\log_+(n/4)]}
\tag{FT11}
\]
即可将当前余项的实际 \(\Delta\le D_{n,\varepsilon_D}\) 子支支付为 \(\varepsilon_D X\)。\(\varepsilon_D\) 仅表示本轮新分配的独立可吸收槽；本稿不声称核验过任何历史未消费误差余额，也不取用旧额度。主代理须将该新槽纳入最终总 \(\varepsilon\) 分配。这是一条可执行的局部分割，不是原 FA 定义的重复改写：它把此前 FT4 的 D log(n/D) 改善成 D log n，并保全真实接收积分，直接给出了选择 D 与新误差价格的关系。无需另两测试、来源分母下界或免费跨 j 包络来支付**这个已明确限制的子支**。

FT11 不重新支付已经删去的 near/FA/RC 子支：仅对当前 RT2/SI5 余项加指示。数学结论为任意 \(\varepsilon_D>0\) 时相应子项不超过 \(\varepsilon_DX\)；最终总账必须另作这个新槽的分配，不能登记为免费。\(\Delta>D\) 部分原位保留；全部负项原位各一次，\(N_Z\) 不返还，\(N_{Z^c}\) 与 \(N_{del}\) 没有附上本层门。

FT9--10 使用 RT1--2 的原未硬来源积分形式。若从 SI5 的 \((16/3)c_\xi\) 形式出发，需要还原同一外行测度，不能在 FT10 的 \(8\Lambda\) 上再额外乘 \(16/3\)。这不是省略硬来源费，而是原 \(q^{-1}h_R\nu\) 已在 \(d\mathcal T_I\) 中，最后只用一次 \(T_{small}\le4X\)。

## 5. 与旧 near 门的区别，以及夹层无法支付的部分

FT11 的面积门不是旧 \(\eta<u_{old}/n\) 的重述。旧门只看时间；新门还看从 t 到真实 g 的全部原 score。举一个仅验证阈值/时间接口相容性的符号情形：一个坐标的 \(\alpha_i<t\)，其余 \(\alpha_i\ge g\)，而配对来源所有 \(\alpha_i\ge g\)。则整个 \([t,g]\) 上 \(k_u(v)=1\)，\(\delta_t=1\)，\(\Delta=\eta\)。如果 \(D>u_{old}/n\)，存在 \(u_{old}/n<\eta<D\) 的 far 时间落入面积层；若 \(KB>1\)、\(L_g=1/K\)，FA 也成立。它说明面积层在标量接口上可以超出旧 near 窗，并不认证真实核、FULL/history 或 RC 余量在该情形实际非空。反之，如果所选 FT11 的 D 太小，层为空仍是合法但没有额外交通增益的结果。

对于高面积补集，FT2 仍不提供小质量。固定 \(0<\eta\le\log2\)，选所有 \(\alpha_i(v)<t\)、所有 \(\alpha_i(z')\ge g\)，即可使 \(\delta_t=n\)、\(\Delta=n\eta\)。取标量 \(L_g(v)=1/K\)，则 FA 的条件仅为 \(e^{-n\eta}/K<Bn\)，对足够大 n 成立。原门允许的 \(\Delta\) 仍可为线性 n；此符号压力不涉及数值，也不是原核/FULL 反例。它严格排除“只由 FA、good 与 score 面积恒等式自动得到 \(\Delta=O(\log n)\) 或一般根阶价格”的推理。

因此下一步有两个具体选择：先从当前余项不交删除 FT11 的已明确收费子层，随后在 \(\Delta>D\) 上利用实际核/RC/history；或者保留 FT8 的行依赖更尖时间价，建立真实行的 D 分布预算。将所有 D 壳分别套 \(T_{small}\le4X\) 后重复收取同一总行质量，会丢失分层收益；不得这样做。若使用接收/来源重尾变换，WJ 的 R_h 仍须实付，FA 的低比门方向无法将它自动抵消。

## 6. 证据与最终状态

本稿直接读取：R128 `joint_receiver_tail.md` RT1--6，R131 `source_integrability.md` SI1--5，R133 `source_weight_joint.md` WJ1--15；为核验原完整行总质量及 FA 参数，读取 R119 `quantitative_future.md` FA1、FA9--15。未重审全部历史，未新增数值实验。

实际读取来源的 SHA-256：

- R128 `joint_receiver_tail.md`：`0a58c8eca0b2ad48cb8f03486b9e6f72b379dc711fac3b0fc70e8706bff791ca`；
- R131 `source_integrability.md`：`c55beae1830e38d16661cfe173eeb96253f8e9d96e67496e3d18f67180145894`；
- R133 `source_weight_joint.md`：`69c89c1d6d99072a52192c34077fbed7aad466db591fbd6184ac28599316f2b5`；
- R119 `quantitative_future.md`：`4976623b47ae0b13896820187e74c372c8bbf1d156d932bbcb3912b6778fb085`。

新结果是 FT8--11 的真实行内面积层价格及明确误差槽条件；它改变下一步可删除的正余子层，保全同一 \(\Pi_t\)、真实 x、原 \(\chi_{FA}\) 与 \(\rho_{rec}\)。FT2 的夹层本身仅给下界，不能承担高面积补集。所有外层费用在 FT9 的完整行总账中只使用一次；未消费任何负项或已付 RC 容量。一般根阶目标仍 UNPROVED。交付后停止。
