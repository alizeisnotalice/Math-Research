# R652 reproduction and evidence boundaries

General root-order weak bound: **unproved**. The main proved construction is in REPORT.tex; final geometry and ledger audits bind its exact SHA-256. The independent numerical review binds eighteen numeric artifacts. No PDF was compiled.

Use the installed environment:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py --replay
```

Run these commands in the extracted archive directory. The second command copies numeric files to a temporary directory, so scripts that write JSON do not overwrite archived evidence. It reproduces six bounded scripts, comparing exact/rational/Arb outputs and testing stated tolerances for the floating owner-program outputs. These tolerances are reproducibility diagnostics, not interval certificates of optimality. MATLAB is not rerun by this verifier; its actual recorded one-point command/output is in numeric/MATLAB_contact.txt. The numerical README files retain original execution paths; substitute the extracted numeric directory when running individually.

Recorded environment: Python 3.12.14, SymPy 1.14.0, python-flint 0.9.0 with Arb at 256 bits, NumPy 2.5.4, SciPy 1.18.1, CVXPY 1.9.3 and Clarabel; MATLAB R2026a. The exact Fraction geometry and rational KKT bracket certificates are separate from floating solver/integral results. See NUMERIC_PLAN.md and NUMERIC_REVIEW.md for precise frozen parameter ranges and corrected intermediate failures. Unlogged discovery searches are not accepted evidence.

Actual local resources checked: 15 logical CPUs and 25,769,803,776 bytes of RAM. Three Astra proof contexts, three Sol contexts and three Terra computation contexts were reused, with three Luna contexts on bounded history/normalization/provenance work. Contexts delivered and stopped when their assignments ended. No assertion of continuous full occupancy or full CPU utilization is made. The solver replays restrict BLAS threads to prevent redundant thread oversubscription. No per-model debit data was available, so no token-price or model-cost ratios are inferred.

Workflow skills used: installed E03 and N04 for same-budget/terminal discipline, L03 for exact and interval evidence boundaries. No unverified external dimension-uniform Bellman or stability theorem is invoked. The new convex selection, capture inclusion and invasion inequalities are proved directly in REPORT.tex and independently reviewed.

Archive policy: only final report, exact audits, frozen numeric plan/review, minimal scripts/results/notes, this reproduction guide and integrity manifest. No intermediate proof drafts, full raw scans, caches, images or PDFs. GitHub's published repository limits were checked on 2026-10-29 at https://docs.github.com/en/repositories/creating-and-managing-repositories/repository-limits: directory width recommendation 3,000, enforced single-object limit 100 MB and push limit 2 GB. This round adds only one small research archive and its round README, plus the project overview update.
