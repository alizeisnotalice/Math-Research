# R652 final capture/owner geometry audit

Audited report: /tmp/ccu_r652_final/REPORT.tex
Actual SHA256: bee6e6a49871f3572eb4b6deeee3e7bdea2b037b6a4f0dff283da64f4177ba71
Requested SHA256: bee6e6a49871f3572eb4b6deeee3e7bdea2b037b6a4f0dff283da64f4177ba71

Verdict: PASS for the scoped capture, low-growth, joint-owner/actual-alpha, measurable purification, bottleneck and source-column mechanisms. No decisive error or required report repair was found. The final source matches the requested SHA. No uniform physical loss/new-source payment is certified.

## Scope and review order

I independently checked the report's main capture/low-growth and joint-convex owner propositions, then read /tmp/ccu_r652/WEIGHTED_COVER.md to compare the author implementation and identify the exact inputs. The report's explicit regularization-based Borel selector supplies the detail beyond the author's earlier brief secondary-tie statement. This is not a repetition of the near-active audit or a certification of the entire full-ledger analysis/numerical work being reviewed separately.

No report or other author's file was changed, and no PDF, Git action, scan or previously passed computation was run for this final audit.

## Capture uses expanded halfsides rho, not old radii

For every actual admissible anchor X_k in A_k,

    |x-c_k|_infinity<=sigma_k s_k=q_k rho_k for x in A_k,
    rho_k=t_k s_k, q_k=sigma_k/t_k.

Receiver intersection gives |c_j-c_k|_infinity<=(rho_j+rho_k)/a. Therefore

    |x-c_j|_infinity<=q_k rho_k+(rho_j+rho_k)/a.

For u_k>=1/2, the convex chord bound (3/2)^(-1/n)<=1-1/(3n) gives q_k<=1-1/(6n). The remaining radius is exactly

    (1-1/a)(rho_j-rho_k)+(1-q_k-2/a)rho_k,

which is at least 5rho_k/(48n) when rho_j>=rho_k and a=32n. Hence the reported uniform strict source containment is correct, including unequal old radii and all scales. It uses only a supported half-action and receiver intersection, not crosseligibility, source swap optimality or coordinate independence. The larger-object order is the EXPANDED rho order.

The inherited A_j subset C_j fact alone would not give this cross-label containment; the new statement is a quantitative compatible extension. I do not claim a complete-history novelty search. Comparing the supplied current author material found the same lemma, with the report explicitly retaining the nonnegative (rho_j-rho_k) term.

## Low-growth part is a complete actual-loss branch

For 0<u_k<=1/2 and kappa>=7/2,

    ell_k/e_k=u_k(1+u_k)/(kappa-u_k)^2<=1/12,
    e_k=v_k(u_k-kappa)^2/u_k.

The ratio increases in u on this range and decreases in kappa; the endpoint is (1/2)(3/2)/3^2=1/12. Since o_k<=ell_k for every actual image-priority partition, O_low<=E_low/12. Thus

    D>=(11/12)E_low+E_high-O_high+F+RS

is a direct all-old-row consequence of the exact D identity. It needs no near-R hypothesis, old low-input cleanup, source density bound or assumption about the new alpha. The report consistently takes low<=1/2 and high>1/2, while allowing capture at the shared boundary as an extra valid statement. No old deleted row is dropped from its incoming growth/loss.

## Capture eligibility and actual available-label deletion

At an image point, a largest-rho covering image label captures every active high child's old A_k by the proved containment. Thus the report's capture-eligible set is nonempty. On fill the covering new receivers supply nonempty eligibility. The rule is image-priority and all eligible image owners are source-capturing, including owners not of largest rho.

The finite positive-volume eligibility atoms yield the Minkowski-sum ownership polytope P=sum_T |T| Delta_{J(T)}. Lebesgue nonatomicity realizes each atom allocation. A label with zero eligible measure has zero ownership under EVERY such allocation; removing it is genuine NEW zero-owner deletion. A finite union of these zero-measure eligibility sets cannot erase a positive-volume receiver region, so available labels still cover the entire receiver union a.e. Their baseline p_j^0, obtained by equal fractional eligibility weights per point, is positive exactly on the available labels and sums to W.

For fixed delta in (0,1), P_delta=delta p^0+(1-delta)P is nonempty compact and every available p_j is positive. No other row is artificially deleted, and no positive floor is assigned to an unavailable row. This is fully compatible with the actual deleted-label entropy problem: alpha=0 there, and no 0/0 u' or source demand is attached to deleted labels. Their old images and losses remain in the old ledger.

## Joint convex minimization really yields the actual entropy optimizer

Each term p log[p/(m alpha)] is jointly convex on p,alpha>0, with the reported positive semidefinite rank-one Hessian. The remaining term -m alpha/epsilon is linear. The packing polytope is compact (each available coordinate is <=1) and has a positive feasible vector. The l.s.c. objective is finite somewhere, while p_j>=delta p_j^0>0 makes it diverge if any available alpha_j approaches zero. Thus an attained positive minimizer exists.

For fixed final p, minimization over alpha is exactly the maximization of sum m_j alpha_j+epsilon sum p_j log alpha_j. Strict concavity with positive p gives the unique ACTUAL entropy optimizer. The construction does not compare owners using a trial alpha or pretend an independently chosen alpha survives an ownership change.

At a joint minimizer, varying the free ownership q while holding that minimizing alpha fixed is a legitimate first-order test. Since the total free mass is fixed, the derivative 1+log(u'_j/epsilon) has the same linear minimizers as log u'_j. Therefore the free allocation minimizes the actual final u'_j pointwise among capture-eligible labels. Any positive flow to a higher-price label would raise the atom's linear objective, so all positive free allocations are supported on its minimum-price labels. Ties can be split according to the selected minimizing flow without changing p.

All baseline allocations also use the capture-eligible sets. Reserving delta of EACH eligibility atom for that baseline and allocating the rest by the selected free flows realizes the exact final p. The baseline portion is exactly delta W in owned receiver area; it is not a delta loss in the entropy problem and no delta->0 continuity is invoked.

## Borel selector: report's regularization repair is valid

For one fixed old state choose Borel representatives of the old Lebesgue-measurable owners; this changes no owner/image volume. The joint indicators of their affine images, the receivers and the capture-containment tests are Borel in the anchor tuple and point. Hence eligibility-atom volumes and positive packing-incidence patterns are measurable. There are finitely many availability/eligibility/packing-incidence strata.

On a fixed stratum, parameterize allocations by FRACTIONS on the fixed finite atom simplices, rather than moving amount constraints. The free p and p^0 are linear functions of atom volumes and allocation fractions, and the packing polytope is fixed. In a neighborhood of a positive-volume parameter vector, each available p_j>=delta p_j^0 has a positive lower bound. Comparing to a fixed positive feasible alpha bounds minimizing alpha locally away from zero; the remaining objective terms are uniformly bounded below there. This applies also to the regularized minimizers for k>=1.

Adding k^(-1) times squared norm of all independent flow and packing variables (with p included if desired) gives a strictly convex objective on the fixed compact convex domain. It has a unique minimizer. The local lower bound excludes alpha=0 along convergent parameter/minimizer sequences, so compact subsequences and uniqueness give continuity in the volume parameters on that stratum. For fixed parameters, as k tends to infinity these minimizers converge to the unique least-norm primary minimizer. Thus their pointwise limit is a Borel primary selection. Composing with the measurable volume parameters and joining the finite strata gives a Borel choice for the actual action.

The finite-k alpha need not itself be the original entropy optimizer; only the LIMIT primary minimizer is used for the actual partition. The report explicitly keeps this order and does not alter the final primary objective. No global lower bound on alpha or p^0, no inter-stratum continuity and no physical delta->0 limit is required.

For purification, each bounded eligibility atom has a continuous first-coordinate cumulative Lebesgue-volume function: a coordinate hyperplane has zero n-dimensional Lebesgue measure. The cumulative function is jointly measurable in the parameters. Inverting it by rational-threshold infima, with the trivial zero/full cuts handled directly, gives measurable threshold cuts of the prescribed baseline/free volumes. The finite atom/label order therefore produces a genuine Borel partition with the selected exact row totals. Nonrectangular image atoms cause no obstruction. Consequently the selected actual D is measurable and may be averaged. No optimizing AC-source kernel is needed for this owner selection.

## Bottleneck identity and baseline area

Read R_t as a subset of the receiver union, which is the domain of J(x). A free owner has u'>t exactly when every eligible option has u'>t. This equivalence includes ties at the threshold because both use the strict inequality >t. R_t is a union of whole eligibility atoms, and each atom has free fraction 1-delta. Therefore

    sum_{u'_j>t}p_j
       =delta sum_{u'_j>t}p_j^0+(1-delta)|R_t|

is exact. The nested family gives one geometric obstruction description, not separate budgets for every t. The positive baseline allows free high-growth volume even outside R_t only through its explicitly retained delta part.

Under eta<=L, R>=64L and kappa<=4, the legitimate near-SCORE bound gives R'<=R+5L<=69R/64. Together with Q'<=M<=5Q this gives W<=345V/64, and delta=1/100 gives delta W<0.054V. These are correctly scoped receiver-AREA exceptions. Many different lost child images may lie over the same baseline area; neither the area estimate nor the bottleneck identity controls that multiplicity. The report repeatedly preserves this limitation.

## One global actual-alpha source column

For an actual owner j, every high child with positive lost volume assigned to it has A_k subset C_j by eligibility. Thus U_j, the UNION of these old cubes, is contained in C_j. Deleted owners have no positive owned volume and alpha_j=0; deleted old incoming child labels still count in the union/loss derivation when appropriate.

For the same actual alpha and old AC mu,

    sum_j alpha_j mu(U_j\A_j)
       <=sum_j alpha_j mu(C_j\A_j)<=M-Q'=S,
    sum_j alpha_j 1_Uj<=L_alpha^C<=1 mu-a.e.

The final inequality uses old mu<<dx to transfer actual new packing to the old source, not a new-source stationarity claim. It charges a SOURCE UNION within each owner, not a sum of overlapping child masses. With nonnegative row weights whose sum per owner is <=K, summation gives KS and KM once globally; no sum of rowwise coordinate suprema is substituted. This remains valid for outcome-dependent row weights because the comparison is pathwise for the fixed realized action.

These identities do not replace the physical old/expanded u/epsilon exposure, do not remove small alpha conversion prices, and do not convert an owner-source union into lost-copy multiplicity. The report accurately leaves this comparison unproved.

## Report claim boundaries and remaining gap

The opening correctly calls the result an actual simultaneous owner/price construction and leaves the general weak bound and full lost-copy payment open. The report states the geometric E D>=cV-CLM estimate as still unproved. Its single global next-potential allowance is not multiplied by labels/channels. The quantitative invaded-owner-area estimates and successor-growth debit are explicitly alternatives/remaining costs, not a second physical-loss credit; their full scalar ledger is outside this focused geometry audit and is reviewed separately.

The actual unresolved geometric step is a joint estimate of bottleneck receiver regions, physical high-loss multiplicity and actual source/owner conversion, with all low/high-growth and successor-growth terms retained. The new existence/minimum-price theorem removes an incompatibility in owner choice; it does not prove that estimate. No claim of a uniform positive Gamma increment or controlled terminal recursion appears in the scoped statements.

Final certification: PASS for the actual SHA256 above, limited to the capture, low-growth, joint actual-owner/entropy optimizer, measurable selection/purification, bottleneck, baseline-area and weighted source-column integration. No numerical experiment, general physical multiplicity bound, full Gamma payment or original dimension improvement is certified here.

## Separately bound continuation note: mass growth on a blocking chain

Additional file: /tmp/ccu_r652_final/NEXT_TARGET.md
Actual SHA256: 9a89f63ce0a823ee26e8f5de5de00a652268a298007b0f1a14459b75d4e4fa01

PASS for this note's stated scalar chain observation only; REPORT.tex remains bound to its unchanged SHA above. At a fixed image point, if candidate owner j is blocked by an active high child k with A_k not contained in C_j, the same receiver-intersection bound implies

    (q_k+1/a)rho_k>(1-1/a)rho_j.

Using q_k<=1-1/(6n) gives

    rho_k/rho_j>(96n-3)/(96n-13)>1+5/(48n),
    m_k/m_j=(rho_k/rho_j)^n>53/48.

The last step is the elementary Bernoulli bound. Along a directed chain every mass therefore grows strictly by more than 53/48. The finite graph is acyclic, and a chain extended until no blocking edge remains ends at a capture-eligible label (the note's path-termination wording is read in this maximal-path sense). The usual a.e. exclusion of zero-measure availability exceptions remains necessary.

For such a chain ending at mass m_terminal, each earlier mass is bounded by its corresponding power of 48/53 times m_terminal. Summing the finite geometric series yields sum_chain m_j<=(53/5)m_terminal. This is a bound on ONE chain, not a bound on sums over overlapping paths or branching children. It gives no source disjointness, no physical lost-copy multiplicity estimate and no payment of u/epsilon, baseline or successor-growth prices. The continuation note expressly retains those gaps and does not claim a global improvement.
