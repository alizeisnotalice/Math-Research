# Same-route continuation: the source-capturing bottleneck

The report proves an actual policy; it does not estimate its complete lost-copy integral. Next work should keep that policy, its actual entropy optimizer, the same Eulerian law and the full D/Gamma account. Do not begin another unrelated local mechanism or repeat finite contact scans.

One further exact observation was checked independently by the geometry reviewer after the report was frozen. Fix an image point x outside null eligibility exceptions. If an incoming label j is excluded from capture eligibility, some high incoming k at that same x satisfies A_k not contained in C_j. With the report's definitions,

```
(q_k + 1/a) rho_k > (1 - 1/a) rho_j,
q_k <= 1 - 1/(6n),    a=32n,
rho_k/rho_j > (96n-3)/(96n-13) > 1+5/(48n),
m_k/m_j = (rho_k/rho_j)^n > 53/48.
```

Proof: if the first strict inequality failed, receiver intersection and the actual half-action bound would put every point of A_k in C_j, contradicting exclusion. The bound on q_k is the already proved capture inequality. The last step is Bernoulli's inequality. Here m_j is the genuine old source row mass and simultaneously the volume of C_j; it is not a proxy distance or a freely assigned weight.

Consequently the finite graph of such blocking edges has no cycles and every path ends at a capture-eligible label. Along a path, the sum of its m_j is at most (53/5) times the terminal mass. This says nothing by itself about the number of branching children or the pointwise lost-image multiplicity. No source budget has been spent or saved by merely writing this graph.

The decisive next question is whether real old disjoint I_j, these geometrically growing source-mass paths, actual Euler columns and the minimum-u' eligible owner can jointly pay the branching and physical u/epsilon prices. The receiver bottleneck regions R_t and their exact baseline relation in REPORT.tex are frozen. Required conclusion remains E D >= c V - C L M (or the original positive full Gamma, or a true controlled recursion), with no budget per path, scale, child or threshold. Successor E'/kappa', weak invasion, baseline multiplicity, fill and all slack terms remain present. A path-sum bound is not a branching bound.

This is a concrete continuation target, not a new proof of the general weak bound.
