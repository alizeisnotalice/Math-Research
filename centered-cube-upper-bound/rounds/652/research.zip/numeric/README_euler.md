# Packing-contact exact diagnostic

This is the approved replacement for the proposed Euler-law numerical experiment, not an Euler-action realization. Run:

```
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r652/numeric/euler_action.py
```

The run used Python 3.12.14 and exact `fractions.Fraction` arithmetic; no random seed, solver, numeric tolerance, or floating numerical error applies. JSON is written alongside the script. The list of t values is a finite check; the exact formulas hold for every 0<t≤1/8 and every −1/16≤t≤0.

Let C1=[−1,1], C2=[1−t,3−t]. Each has volume d=2, and each owns its complete disjoint center receiver of half-length 1/32, hence p1=p2=1/16 and W=1/8. E-priority is automatic because receivers do not overlap. Fix epsilon=56 and scalar R=1/16. This construction does not provide an old state or show that its cube paths arise from Euler anchors near an old source minset.

For t>0, the joint cell has positive length t and forces alpha1+alpha2≤1; strict concavity of the objective and the exact KKT system give alpha=(1/2,1/2), joint multiplier 9, Q'=2 and D=W−RQ'=0. At t≤0, the joint cell has zero volume and is not a packing constraint. The two singleton constraints yield alpha=(1,1), multipliers (11/2,11/2), Q'=4 and D=−1/8. Both p entries are strictly positive and W is constant; kappa'=7/2 on the overlap side and 7/4 on the contact/disjoint side.

At contact Q' is **upper** semicontinuous in this path, not lower semicontinuous; D is **lower** semicontinuous, not upper semicontinuous. For an independently established general lower-semicontinuity theorem, a lower bound holding at the limit would propagate to the liminf of nearby values. A lower bound on nearby values alone does not imply one at the limit. This example does not prove either general semicontinuity, near-minset realizability, or any critical-state global bound.

## Three-interval chain

A second fixed exact probe takes d=(9/2,17/200,1), C1=[−9/2,0], C2=[−1/25,9/200], and C3=[9/200−t,209/200−t], with t=1/1000 on the overlap side and t=0 at contact. Its true centered receivers have half-length d_i/64, are pairwise disjoint, and are entirely owned, so p_i=d_i/32 and W=sum(p). The positive-volume incidences 12 and 23 exist for t>0, while 23 becomes a null point at contact and 13 never occurs. At both parameter values the owners remain disjoint, their volumes are constant, and epsilon=56.

The entropy KKT solution has alpha=(1−x,x,1−x) before contact and (1−y,y,1) at contact. In each case the relevant scalar derivative is strictly decreasing and has opposite endpoint signs, proving the unique solution; the two multipliers before contact and the two multipliers at contact are positive. The JSON contains rational 100-step bisection enclosures for x,y and for Q'(contact)−Q'(overlap): it is positive, approximately 0.000194670205535057. With fixed R, D has the opposite jump. This is one real family, not a general semicontinuity theorem.

For comparison only, the same chain with abstract p=(1/250,1/1250,1/1000) has a negative Q jump of about −0.0000359449511879553, also enclosed by exact rational bisection. Those values sum to 29/5000, while the true receiver union has volume 1117/6400; they therefore cannot represent the full E-priority receiver ownership in this geometry. This algebraic example is not an actual cube/receiver counterexample.

Exploratory numerical searches were not saved with reproducible scripts or raw logs and are not part of the evidence. The accepted evidence comprises the five exact two-interval cases and the fixed exact three-interval chain above.
