"""R652 fixed-parameter contact arithmetic; no proof of source-to-volume transfer."""
import json, platform
import sympy as sp
from flint import arb, ctx
import flint
ctx.prec=256
t=sp.symbols('t',positive=True); b=(t-1)/2; sigma=(t+1)/2
candidate_lo=sp.factor(sigma*b/t**2); candidate_hi=sp.factor(sigma/t**2)
sharp=sp.factor(2*b/t**2)
assert sp.simplify(candidate_lo-(1-t**-2)/4)==0
assert sp.simplify(sharp-candidate_lo-(t-1)*(3-t)/(4*t**2))==0
assert sp.simplify(sharp-candidate_hi-(t-3)/(2*t**2))==0
assert sp.limit(candidate_lo,t,1)==0
# Exact Young completion of square for any J>=0, K>=0, rho>0, h>0.
x,z,lam=sp.symbols('x z lam',positive=True)
assert sp.expand(lam*x*x+z*z/(4*lam)-z*x-lam*(x-z/(2*lam))**2)==0
# Uniform bound in u cannot ignore u: along t=(1+u)^(1/n), c~u/(2n).
u,n=sp.symbols('u n',positive=True)
expr=(1-(1+u)**(-2/n))/4
assert sp.limit(expr/u,u,0,dir='+')==1/(2*n)
sharp_u=((1+u)**(1/n)-1)/(1+u)**(2/n)
assert sp.limit(sharp_u/u,u,0,dir='+')==1/n
# Fixed range per independent audit; update list only by frozen plan.
rows=[]
for dimension in [2,7,32,4096]:
 for text in ['1/1000','1','7/2','4','1000']:
  un=arb(text); z=(1+un).log()/dimension; tt=z.exp(); bb=(tt-1)/2
  c=2*bb/tt**2
  cold=((tt+1)/2)*(bb if tt<=3 else arb(1))/tt**2
  assert c>0 and (c-cold>=0 or (c-cold).contains(0))
  h=arb(1)/(32*dimension); K=1/(un*c*h)
  def display(a): return a.str(28,more=True)
  rows.append({'n':dimension,'u':text,'h':'1/'+str(32*dimension),'r0':'1','c_sharp':display(c),'c_candidate':display(cold),'inverse_u_c':display(1/(un*c)),'K_flat':display(K),'young_fee_lambda_1':display(K/4)})
print(json.dumps({'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec,'scope':'conditional scalar Young algebra; NOT a physical-volume bound','sympy':{'candidate_t_le_3':str(candidate_lo),'candidate_t_ge_3':str(candidate_hi),'sharp':str(sharp),'young_square':'lambda*x^2+z^2/(4lambda)-z*x=lambda*(x-z/(2lambda))^2','low_u_candidate_limit':'1/(2n)','low_u_sharp_limit':'1/n'},'rows':rows},indent=2))
