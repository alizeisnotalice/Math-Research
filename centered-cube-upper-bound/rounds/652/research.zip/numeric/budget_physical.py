"""Frozen R652 contract 3: optimal scalar residual with outward Arb balls."""
import json, platform
from flint import arb,ctx
import flint
ctx.prec=256
u=arb(7)/2; r0=arb(1)/2; eta=arb(1)/4
fmt=lambda x:x.str(30,more=True)
rows=[]
for n in [2,7,32,4096]:
 L=arb(n).sqrt(); z=(1+u).log()/n; t=z.exp(); c=(t-1)/t**2; q=(1+1/t)/2
 assert c>0 and c<arb(1)/4 and q>=arb(1)/2
 hs=[('1/(32n)',arb(1)/(32*n)),('1/n',arb(1)/n),('min(1/2,1/sqrt(n))', min(arb(1)/2,1/L))]
 for hname,h in hs:
  cut=u*c*r0*h; cap=u*q*q
  assert cut<cap
  for eptext in ['1','1/16','1/256']:
   ep=arb(eptext); stationary=u/(4*ep**2*c*r0*h*L**2)
   # cut<cap proves only the two branches below can minimize.
   if stationary < cut: j=stationary; branch='stationary'
   elif stationary > cut: j=cut; branch='saturated'
   else: raise ArithmeticError('undecidable branch')
   if branch=='saturated': B=u/ep
   else: B=u/ep*(j/cut).sqrt()
   V=u/(ep*(1+u)); raw=B-L*j-eta*V
   if raw>0: R=raw
   elif raw<0: R=arb(0)
   else: raise ArithmeticError('undecidable positive part')
   rows.append({'n':n,'h':hname,'epsilon':eptext,'branch':branch,'j_star':fmt(j),'R':fmt(R),'root_coefficient':fmt(R/L)})
# all 36 root coefficients have disjoint enclosures sufficiently far for exact ordering
best=worst=rows[0]
for row in rows[1:]:
 val=arb(row['root_coefficient']); lo=arb(best['root_coefficient']); hi=arb(worst['root_coefficient'])
 if val<lo: best=row
 elif not val>lo:
  assert row['n']==best['n']==2 and row['epsilon']==best['epsilon'] and {row['h'],best['h']}=={'1/n','min(1/2,1/sqrt(n))'}
 if val>hi: worst=row
 elif not val<hi:
  assert row['n']==worst['n']==2 and row['epsilon']==worst['epsilon'] and {row['h'],worst['h']}=={'1/n','min(1/2,1/sqrt(n))'}
print(json.dumps({'python':platform.python_version(),'flint':flint.__version__,'precision_bits':ctx.prec,'scope':'fixed scalar upper-bound relaxation; not a realized KKT family','input':{'u':'7/2','r0':'1/2','eta':'1/4','M':'1','n':[2,7,32,4096],'epsilon':['1','1/16','1/256']},'epsilon_small_exact_residual':'(119/36)/epsilon - sqrt(n)*u*c*r0*h','threshold':'epsilon <= 1/(2*c*r0*h*sqrt(n))','epsilon_small_root_asymptotic':'119/(36*sqrt(n)*epsilon) - u*c*r0*h','rows':rows,'min_root_coefficient':best,'max_root_coefficient':worst},indent=2))
