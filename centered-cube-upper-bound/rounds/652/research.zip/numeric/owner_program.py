"""Bounded joint owner optimizer on three actual cube/receiver families."""
from fractions import Fraction as F
from itertools import combinations
from math import log
import json,platform
from pathlib import Path
import numpy as np, cvxpy as cp, scipy
from scipy.optimize import brentq

EPS=56.; DELTA=.01

def subsets(n):
    return [tuple(c) for k in range(1,n+1) for c in combinations(range(n),k)]

def intersection(centers,radii,ids,dim):
    volume=F(1)
    for k in range(dim):
        low=max(centers[i][k]-radii[i] for i in ids)
        high=min(centers[i][k]+radii[i] for i in ids)
        volume*=max(F(0),high-low)
    return volume

def atoms(centers,radii,dim):
    subs=subsets(len(centers)); exclusive={}
    for ids in sorted(subs,key=len,reverse=True):
        exclusive[ids]=intersection(centers,radii,ids,dim)-sum(v for sup,v in exclusive.items() if set(ids)<set(sup))
        assert exclusive[ids]>=0
    return [(ids,exclusive[ids]) for ids in subs if exclusive[ids]>0]

def independent_alpha(p,m):
    W=sum(p); x=p/W; imax=int(np.argmax(m)); D=m[imax]-m
    if max(D)<1e-12:return p/sum(p)
    def f(z):return sum(EPS*x[i]/z if i==imax else W*EPS*x[i]/(D[i]+W*z) for i in range(len(p)))-1
    low=max(EPS*x[imax],1e-300); high=max(1.,low*2)
    while f(high)>0:high*=2
    z=brentq(f,low,high,xtol=1e-14,rtol=1e-14)
    return np.array([EPS*x[i]/(z if i==imax else D[i]+W*z)* (1 if i==imax else W) for i in range(len(p))])

def run(dim, xs, radii):
    n=len(xs); centers=[[xs[i]]+[F(0)]*(dim-1) for i in range(n)]
    recv=[r/F(32*dim) for r in radii]
    actual=atoms(centers,recv,dim); Wq=sum((v for _,v in actual),F(0)); W=float(Wq)
    oldr=F(1,8)
    assert all(all(abs(c[k])+oldr<r for k in range(dim)) for c,r in zip(centers,radii))
    assert intersection(centers,radii,tuple(range(n)),dim)>0
    m=np.array([float((2*r)**dim) for r in radii]); imax=int(np.argmax(m)); D=m[imax]-m
    base=np.zeros(n); vs=[]; terms=[]
    for ids,vol in actual:
        frac=float(vol/Wq); base[list(ids)]+=frac/len(ids)
        v=cp.Variable(len(ids),nonneg=True); vs.append(v)
        M=np.zeros((n,len(ids)))
        for k,j in enumerate(ids):M[j,k]=1
        terms.append(M@v)
    x=DELTA*base+(1-DELTA)*sum(terms)
    cons=[cp.sum(v)==float(vol/Wq) for v,(_,vol) in zip(vs,actual)]
    if max(D)<1e-12:
        alpha=cp.Variable(n,pos=True); cons += [cp.sum(alpha)<=1]
        objective=cp.sum(cp.rel_entr(x,cp.multiply(m,alpha)))-m@alpha/(EPS*W)
        beta=None
    else:
        other=[i for i in range(n) if i!=imax]; beta=cp.Variable(n-1,pos=True)
        am=1-W*cp.sum(beta); cons += [am>=0]
        objective=sum(cp.rel_entr(x[j],m[j]*beta[k]) for k,j in enumerate(other))
        objective+=cp.rel_entr(x[imax],m[imax]*am)+x[imax]*log(W)
        objective+=sum(D[j]*beta[k]/EPS for k,j in enumerate(other))
    prob=cp.Problem(cp.Minimize(objective),cons)
    prob.solve(solver='CLARABEL',tol_gap_abs=1e-10,tol_gap_rel=1e-10,tol_feas=1e-10,max_iter=500)
    if prob.status not in ('optimal','optimal_inaccurate'):raise RuntimeError(prob.status)
    xv=np.asarray(x.value); pv=W*xv
    if beta is None:av=np.asarray(alpha.value)
    else:
        bv=np.asarray(beta.value);av=np.zeros(n)
        for k,j in enumerate(other):av[j]=W*bv[k]
        av[imax]=1-W*sum(bv)
    aa=independent_alpha(pv,m); uv=EPS*pv/(m*av); ur=EPS*pv/(m*aa)
    alloc=[np.asarray(v.value) for v in vs]; per=[]
    for (ids,vol),v in zip(actual,alloc):
        gaps=uv[list(ids)]-min(uv[list(ids)]); gaps_ref=ur[list(ids)]-min(ur[list(ids)])
        per.append({'labels':ids,'volume_exact':str(vol),'free_fraction_of_W':v.tolist(),
                    'u':uv[list(ids)].tolist(),'u_ref':ur[list(ids)].tolist(),'weighted_price_excess_over_W':float((1-DELTA)*np.dot(v,gaps)),
                    'weighted_price_excess_ref_over_W':float((1-DELTA)*np.dot(v,gaps_ref))})
    recon=DELTA*base.copy()
    for (ids,_),v in zip(actual,alloc):recon[list(ids)]+=(1-DELTA)*v
    residual={'p_reconstruction_over_W':float(max(abs(xv-recon))), 'allocation_negative_over_W':float(max(0,-min(float(min(v)) for v in alloc))), 'sum_alpha':float(abs(sum(av)-1)), 'minimum_alpha':float(min(av)),
      'atom_fraction':float(max(abs(sum(v)-float(vol/Wq)) for v,(_,vol) in zip(alloc,actual))),
      'total_p_over_W':float(abs(sum(xv)-1)), 'baseline_lower_over_W':float(max(0,np.max(DELTA*base-xv))),
      'alpha_fixed_p_max_abs':float(max(abs(av-aa))),
      'alpha_fixed_p_max_relative':float(max(abs(av-aa)/aa)),
      'weighted_free_price_excess_over_W':float(sum(q['weighted_price_excess_over_W'] for q in per)),
      'weighted_free_price_excess_ref_over_W':float(sum(q['weighted_price_excess_ref_over_W'] for q in per))}
    return {'dim':dim,'centers':[[str(z) for z in c] for c in centers],'radii':[str(z) for z in radii],
      'receiver_radii':[str(z) for z in recv],'old_A_radius':'1/8','W_exact':str(Wq),'W':W,'m':m.tolist(),
      'baseline_p0_over_W':base.tolist(),'baseline_volume_over_W':DELTA,'free_volume_over_W':float((1-DELTA)*sum(map(sum,alloc))),
      'p_over_W':xv.tolist(),'p':pv.tolist(),'alpha':av.tolist(),'independent_alpha':aa.tolist(),
      'u_prime':uv.tolist(),'u_prime_ref':ur.tolist(),'atoms':per,'residuals':residual,'status':prob.status}

if __name__=='__main__':
    fixtures=[(1,[F(0),F(1,32)],[F(1),F(1)]),
              (2,[F(0),F(1,64),F(1,25)],[F(9,10),F(1),F(11,10)]),
              (7,[F(0),F(1,64),F(1,25)],[F(9,10),F(1),F(11,10)])]
    out={'versions':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'cvxpy':cp.__version__},
         'epsilon':EPS,'delta':DELTA,'cases':[run(*f) for f in fixtures],
         'scope':'approximate owner-program test, no old KKT or full SAME action'}
    Path(__file__).with_name('owner_program.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'versions':out['versions'],'cases':[{'dim':c['dim'],'W':c['W'],'p_over_W':c['p_over_W'],'alpha':c['alpha'],'u_prime':c['u_prime'],'residuals':c['residuals']} for c in out['cases']]},indent=2))
