"""Exact two-interval packing-contact diagnostic; not an old Euler action."""
from fractions import Fraction as F
import json,platform
from pathlib import Path

r=F(1,32); eps=F(56); p=[2*r,2*r]; W=sum(p); R=F(1,16); d=[F(2),F(2)]

def case(t):
    C=[(F(-1),F(1)),(1-t,3-t)]
    centers=[(x+y)/2 for x,y in C]
    B=[(x-r,x+r) for x in centers]
    overlap=max(F(0),min(C[0][1],C[1][1])-max(C[0][0],C[1][0]))
    receiver_overlap=max(F(0),min(B[0][1],B[1][1])-max(B[0][0],B[1][0]))
    assert receiver_overlap==0 and all(C[i][0]<B[i][0]<B[i][1]<C[i][1] for i in range(2))
    if overlap:
        alpha=[F(1,2)]*2; dual={'joint':d[0]+eps*p[0]/alpha[0], 'single_1':F(0),'single_2':F(0)}
    else:
        alpha=[F(1),F(1)]; dual={'joint':F(0),'single_1':d[0]+eps*p[0], 'single_2':d[1]+eps*p[1]}
    loads={'single_1':alpha[0], 'single_2':alpha[1], 'joint':sum(alpha)}
    grad=[d[i]+eps*p[i]/alpha[i] for i in range(2)]
    residual=[grad[0]-dual['joint']-dual['single_1'],grad[1]-dual['joint']-dual['single_2']]
    comp=[dual[k]*(1-loads[k]) for k in ('single_1','single_2')]
    if overlap: comp.append(dual['joint']*(1-loads['joint']))
    assert residual==[0,0] and all(x==0 for x in comp) and all(alpha[i]>0 for i in range(2))
    Q=sum(d[i]*alpha[i] for i in range(2)); D=W-R*Q
    return {'t':t,'cubes':C,'receiver_intervals':B,'owner_intervals':B,'joint_positive_length':overlap,
            'positive_memberships':[[0],[0,1],[1]] if overlap else [[0],[1]],
            'p':p,'W':W,'alpha':alpha,'gradient':grad,'multipliers':dual,'stationarity_residual':residual,
            'complementarity_residual':comp,'Q_prime':Q,'kappa_prime':eps*W/Q,'D_W_minus_RQ':D}

def chain_probe():
    # Fixed exact three-interval chain; 23 disappears at t=0, 12 remains.
    d=[F(9,2),F(17,200),F(1)]; a=F(1,25); t=F(1,1000)
    C=[(-d[0],F(0)),(-a,d[1]-a),(d[1]-a-t,d[1]-a-t+d[2])]
    centers=[(u+v)/2 for u,v in C]
    B=[(centers[i]-d[i]/64,centers[i]+d[i]/64) for i in range(3)]
    assert B[0][1]<B[1][0] and B[1][1]<B[2][0]
    p=[v/32 for v in d]
    def bounds(xp,joint23):
        # F(x) = derivative wrt alpha2; strictly decreasing on (0,1).
        def f(x):
            return d[1]-d[0]-(d[2] if joint23 else 0)+eps*xp[1]/x-eps*(xp[0]+(xp[2] if joint23 else 0))/(1-x)
        lo,hi=F(0),F(1)
        for _ in range(100):
            mid=(lo+hi)/2
            if f(mid)>0:lo=mid
            else:hi=mid
        return lo,hi
    def q_gap(xp):
        xl,xh=bounds(xp,True); yl,yh=bounds(xp,False)
        # Qlimit-Qnear = (d2-d1)*y -(d2-d1-d3)*x.
        lower=(d[1]-d[0])*yh-(d[1]-d[0]-d[2])*xl
        upper=(d[1]-d[0])*yl-(d[1]-d[0]-d[2])*xh
        return {'near_alpha2_interval':[xl,xh],'limit_alpha2_interval':[yl,yh],
                'Q_limit_minus_near_enclosure':[lower,upper],
                'Q_limit_minus_near_decimal':[float(lower),float(upper)]}
    actual=q_gap(p); assert actual['Q_limit_minus_near_enclosure'][0]>0
    # Algebra-only coefficients deliberately fail full receiver union ownership.
    fake=[F(1,250),F(1,1250),F(1,1000)]
    abstract=q_gap(fake); assert abstract['Q_limit_minus_near_enclosure'][1]<0
    return {'t_positive':t,'C_positive':C,'C_contact':[C[0],C[1],(d[1]-a,d[1]-a+d[2])],
            'receiver_intervals':B,'receiver_positive_owners':p,'epsilon':eps,'actual_KKT_Q_gap':actual,
            'KKT_explanation':'alpha=(1-x,x,1-x) near; (1-y,y,1) at contact; positive duals d_i+eps p_i/alpha_i',
            'abstract_coefficients_not_ownership':{'p':fake,'W':sum(fake),'true_W':sum(p),'KKT_Q_gap':abstract},
            'scope':'one real chain family; abstract coefficients are not receiver ownership; no near-minset old action'}

def conv(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:conv(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [conv(v) for v in x]
    return x

if __name__=='__main__':
    ts=[F(-1,16),F(0),F(1,128),F(1,16),F(1,8)]
    result={'python':platform.python_version(),'model':'two real equal 1D cubes; independent nonoverlapping full receiver owners',
       'parameters':{'epsilon':eps,'R':R,'receiver_halfwidth':r,'d':d},'cases':[case(t) for t in ts], 'three_interval_chain':chain_probe(),
       'limit':{'Q_at_contact':F(4),'Q_positive_overlap_limit':F(2),'D_at_contact':-F(1,8),'D_positive_overlap_limit':F(0)},
       'scope':'strictly concave exact new-entropy KKT; no old state, no old Euler law, no near-minset path, no dimensional conclusion'}
    Path(__file__).with_name('euler_action.json').write_text(json.dumps(conv(result),indent=2)+'\n')
    print(json.dumps(conv({'cases':[(x['t'],x['Q_prime'],x['D_W_minus_RQ']) for x in result['cases']],'limit':result['limit'],'chain_Q_gap':result['three_interval_chain']['actual_KKT_Q_gap']['Q_limit_minus_near_decimal'],'abstract_Q_gap':result['three_interval_chain']['abstract_coefficients_not_ownership']['KKT_Q_gap']['Q_limit_minus_near_decimal']})))
