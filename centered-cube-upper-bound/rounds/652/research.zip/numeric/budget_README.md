# R652 physical-exposure scalar check

This tests contract 3 of `../NUMERIC_PLAN.md`; it is an optimistic scalar relaxation of an upper estimate, not a realizable KKT family, counterexample, or lower bound on actual physical loss. Low-radius cost, real cone thickening, source-gap/modulus and signed joint growth/source terms remain unpaid.

For `u=7/2`, `r0=1/2`, `eta=1/4`, `L=sqrt(n)`, `c=(t-1)/t²` and `t=(1+u)^(1/n)`, put `d=u c r0 h`, `C=u q²`, `q=(1+t^-1)/2`. The tested upper expression is `u/epsilon min(1,sqrt(j/d))-L*j-eta*u/[epsilon(1+u)]` for `0<=j<=C`, and R is the positive part of its maximum. On `0<j<d` its derivative vanishes at `j0=u/(4 epsilon² c r0 h L²)`; on `j>d` it decreases. Thus `j*=min(j0,d,C)` exactly. No numerical optimization is involved.

For every stipulated case, `c<=1/4`, `r0 h<=1/4`, and `q²>=1/4`; hence `d<=u/16<u/4<=C`. Moreover, as epsilon tends to zero the stationary point exceeds d, and for `epsilon <= 1/[2 c r0 h sqrt(n)]`, `j*=d`. In that regime the positive-part input is exactly

`119/(36 epsilon) - sqrt(n) u c r0 h`.

Consequently `R/sqrt(n) = 119/[36 sqrt(n) epsilon] - u c r0 h` once this expression is positive, and diverges like `1/epsilon` for each fixed stipulated n and h. Thus this isolated sufficient scalar absorption cannot give a uniform epsilon-independent root-order payment, even granting the entire `L*j` and `eta*V` credits and suppressing other errors. A joint physical-geometric argument remains possible; a bound on an upper estimate is not a constructed violation.

Actual reproduction: `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r652/numeric/budget_physical.py > /tmp/ccu_r652/numeric/budget_physical.json`. Python 3.12.14, python-flint 0.9.0, Arb 256-bit outward enclosures. Inputs are exactly n=2,7,32,4096; h=1/(32n),1/n,min(1/2,1/sqrt(n)); epsilon=1,1/16,1/256. All 36 cases are saturated branch `j*=d`. Across these cases the minimum `R/sqrt(n)` is enclosed by `[0.0516392702846628613823260661191 +/- 2.24e-32]` at n=4096, h=1/sqrt(n), epsilon=1; the maximum is `[598.362658145606391987067627585 +/- 2.93e-28]` at n=2, h=1/(32n), epsilon=1/256. Each case and its branch, j*, R and R/sqrt(n) are in the JSON. Arb comparisons decide all non-identical values; at n=2, h=1/n and h=min(1/2,1/sqrt(n)) coincide exactly.

An initial run's min/max ordering rejected this exact duplicate as undecidable; the comparator was corrected to recognize the algebraically identical choices and the complete run then passed. The saved output is from that successful run.
