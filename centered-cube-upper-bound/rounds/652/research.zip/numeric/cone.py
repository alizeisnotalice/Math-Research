"""Frozen uniform-cube volume model, not a bound on arbitrary source μ."""
from fractions import Fraction as F
import json, math, platform, sys
import sympy as sp
import scipy
from scipy.integrate import quad

# Exact derivation with n an arbitrary positive integer and a=h/2+δ.
n=sp.symbols('n',integer=True,positive=True)
a,h,d=sp.symbols('a h d',nonnegative=True)
u=sp.symbols('u',positive=True)
integ=(1-a**n)/n
formula=sp.Rational(1,2)*(h+2*d+integ)
assert sp.simplify(sp.integrate(u**(n-1),(u,a,1))-integ)==0
assert sp.simplify(formula.subs(a,d+h/2)-((h+2*d)+(1-(d+h/2)**n)/n)/2)==0

def calc(N,mode):
    D=F(1,32*N)
    H=F(0) if mode=='zero' else F(1,N) if mode=='inverse_n' else None
    if H is not None:
        A=D+H/2
        exact=(H+2*D+(1-A**N)/N)/2
        hs=sp.Rational(H.numerator,H.denominator)
        exact_expression=(f'{exact.numerator}/{exact.denominator}' if N<=32 else f'({H}+2*{D}+(1-({A})**{N})/{N})/2')
    else:
        hs=1/sp.sqrt(N)
        exact_expression=f'(1/sqrt({N})+1/{16*N}+(1-(1/{32*N}+1/(2*sqrt({N})))**{N})/{N})/2'
    dd=1/(32*N); hv=float(hs); aa=dd+hv/2
    assert 0<=aa<=1
    closed=(hv+2*dd+(1-aa**N)/N)/2
    # Numerically integrate the exact one-coordinate cross section, in stable scaled coordinates.
    # x1 intervals: [-h/2-δ, 1-h-2δ] power, then plateau up to 1.
    power,err=quad(lambda z:z**(N-1),aa,1,epsabs=1e-13,epsrel=1e-13,limit=100)
    direct=(power+hv+2*dd)/2
    assert abs(direct-closed)<=max(5e-13,err)
    return {'n':N,'mode':mode,'h_exact':str(hs),'delta_exact':str(D),
            'formula_exact':exact_expression,'closed_float':closed,'quadrature_float':direct,
            'quadrature_error_estimate':err/2,'relative_to_one_signed_cone':2*N*closed}

if __name__=='__main__':
    Ns={'initial':[2,7,32],'boundary':[128,512],'expanded':[1024,4096]}[sys.argv[1]]
    rows=[calc(N,mode) for N in Ns for mode in ('zero','inverse_n','inverse_sqrt_n')]
    print(json.dumps({'stage':sys.argv[1],'python':platform.python_version(),'sympy':sp.__version__,
      'scipy':scipy.__version__,'model':'normalized Lebesgue on [-1,1]^n; cube-clipped L-infinity thickening of fixed signed near-active coordinate',
      'formula':'(h + 2 delta + [1-(delta+h/2)^n]/n)/2',
      'assumptions':'n>=2; delta=1/(32n); h>=0; delta+h/2<=1',
      'results':rows},indent=2))
