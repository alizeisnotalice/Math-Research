"""R652: exact low-growth algebra and bounded Arb capture-margin checks.

The proof is in REPORT.tex. These finite checks do not prove arbitrary n.
"""
import json
import platform
import sympy as sp
import flint
from flint import arb, ctx

ctx.prec = 256
u, k = sp.symbols('u k', positive=True)
ratio = u*(1+u)/(k-u)**2
assert sp.simplify(sp.diff(ratio, u) - (k+(2*k+1)*u)/(k-u)**3) == 0
assert sp.simplify(sp.diff(ratio, k) + 2*u*(1+u)/(k-u)**3) == 0
assert ratio.subs({u: sp.Rational(1,2), k: sp.Rational(7,2)}) == sp.Rational(1,12)
z, q, a = sp.symbols('z q a', positive=True)
margin = z-q-(z+1)/a
assert sp.expand(margin-((1-1/a)*(z-1)+(1-q-2/a))) == 0
rows=[]
for phase, dimensions in [('initial',[1,2,7]), ('boundary',[32,128]), ('expanded',[512,4096])]:
    for n in dimensions:
        for us in ['1/2','7/2','4','1000']:
            tt=((arb(1)+arb(us)).log()/n).exp()
            qq=(1+1/tt)/2
            for zs in ['1','101/100','2','1000000']:
                zz=arb(zs)
                mm=zz-qq-(zz+1)/(32*n)
                certified=(mm-arb(5)/(48*n))
                exact_boundary = False
                if n == 1:
                    tr=1+sp.Rational(us)
                    qr=(1+1/tr)/2
                    zr=sp.Rational(zs)
                    exact_surplus=zr-qr-(zr+1)/32-sp.Rational(5,48)
                    assert exact_surplus >= 0
                    exact_boundary = exact_surplus == 0
                if exact_boundary:
                    assert certified.contains(0)
                else:
                    assert certified>0
                rows.append({'phase':phase,'n':n,'u':us,'rho_owner_over_child':zs,
                             'margin_over_child':mm.str(26,more=True),
                             'surplus_over_5_div_48n':certified.str(26,more=True),
                             'exact_rational_boundary':bool(exact_boundary)})
print(json.dumps({'python':platform.python_version(),'sympy':sp.__version__,
                  'python_flint':flint.__version__,'arb_precision_bits':ctx.prec,
                  'scope':'exact identities and finite interval signs, not arbitrary-dimensional proof',
                  'low_growth_ratio_max':'1/12','symbolic_checks':4,
                  'interval_cases':len(rows),'rows':rows},ensure_ascii=False,indent=2))
