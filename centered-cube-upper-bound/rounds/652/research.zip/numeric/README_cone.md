# Fixed signed cone: finite-volume diagnostic

Freeze n≥2 and x uniform with normalized Lebesgue measure on the cube [−1,1]^n. Let S_h={y in cube: y1≥||y||∞−h}, for a *single specified positive signed coordinate*. Take its L∞ δ-neighborhood clipped to the cube, δ=1/(32n). This is a model of receiver thickening, not an assertion that actual half-action receivers are exactly these neighborhoods. Suppose 0≤h and δ+h/2≤1.

For a given x1, moving y1 by at most δ, the self-coordinate condition y1≥|y1|−h requires x1≥−h/2−δ. Each remaining coordinate can be shifted toward zero by δ. Hence the allowed remaining cross-section fraction is min(1,x1+h+2δ)^(n−1) on x1∈[−h/2−δ,1−h−2δ], then 1 until 1. Therefore the exact cube volume fraction is

 P_n(h,δ) = 1/2 [ h+2δ + ∫_(δ+h/2)^1 z^(n−1) dz ]
          = 1/2 [ h+2δ + (1−(δ+h/2)^n)/n ].

SymPy independently evaluated the displayed power integral symbolically. For δ=1/(32n), h=0 gives P∼(17/16)/(2n); h=1/n gives P∼(33/16)/(2n), so an absolute tolerance of order 1/n preserves the 1/n volume order for one signed direction. For h=1/√n, P∼1/(2√n), so its ratio to the original signed-cone fraction 1/(2n) grows like √n. These are general consequences of the formula, not extrapolations from the finite computations.

At n=4096, the three fractions are approximately 0.0001296997, 0.0002517700, and 0.0079421997, respectively. The model does **not** imply any source-mass estimate: an arbitrary AC μ may concentrate on any positive-volume region. It also supplies no simultaneous-cover, budget, or full-action bound; scale choices must still pay their actual near-active errors.

# Reproduce

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r652/numeric/cone.py STAGE` with STAGE `initial` (n=2,7,32), `boundary` (128,512), `expanded` (1024,4096). Each tests h=0,1/n,1/√n. Results from all three actual runs are in `cone.json`. Python 3.12.14, SymPy 1.14.0 and SciPy 1.18.1; the rational/symbolic formula is exact and SciPy quad's recorded error estimates concern only its floating check, not rigorous interval enclosures. All stages ran sequentially, approximately 1.2 seconds in total. The first attempted run hit Python's integer-to-string digit limit at n=4096; the final script stores large exact expressions in unevaluated compact form and all recorded stages succeeded.

SHA-256: cone.py `650ea7fe4b728208f4fe4e4410dc60f1ffcf8709a0e3e542b3a85ccb95cd2eef`; cone.json `2f6b2ec56abfd1778fb48ccfbc21ab23bed92421db2e1a99dbc4b2ce87f8454c`.
