# R652 numerical acceptance and integration review

**Accepted within the stated finite models; no root-order global estimate follows from these computations.** The three responsibilities in `NUMERIC_PLAN.md` are complete. The obsolete minimizing-gamma/Euler two-source rerun was not executed for this round. Root subsequently supplied a fourth, decision-relevant capture-margin certificate; it is accepted only as algebra and finite interval evidence, with its general geometric proof left to the separate Sol audit.

In accordance with the instruction not to recompute, this reviewer did not rerun the first three research scripts, scans, quadrature or MATLAB. I read the final scripts, raw outputs and scope notes, independently checked the geometric/optimization arguments below, and initially ran only a read-only JSON inventory and SHA-256 binding. Root later authorized the new three-fixture owner program; section 7 records its bounded independent postchecks, without replaying prior tasks. The original mathematical tool executions quoted here belong to their actual recorded owners, not to a fictitious reviewer replay. No other worker file, Git state or PDF was changed.

## 1. Cone thickening: correct exact volume, no source-mass implication

For the specified signed coordinate, the event is `y1>=||y||_infinity-h`, including the self-sign constraint `y1>=-h/2`. After cube-clipped infinity-neighborhood thickening delta, put `z=h/2+delta`. Existence of an admissible y is equivalent to the scalar lower bound `x1>=-z` and the transverse cross-section bound. On `[-z,1-2z]` the cross-section fraction is `(x1+h+2delta)^(n-1)`; on `[1-2z,1]` it is one. Integrating gives exactly
\[
P_n(h,\delta)=\frac12\left[h+2\delta+\frac{1-z^n}{n}\right]
\quad(0\le z\le1).
\]
For z>=1 the fraction is one; at z=1 the formulas coincide. This derivation confirms the formula in `cone.py`, including the previously corrected self-coordinate endpoint. No coordinate or sign is silently discarded.

With delta=1/(32n), the conclusions are analytic consequences of that formula:

- h=0: `P~(17/16)/(2n)`;
- h=1/n: `P~(33/16)/(2n)`;
- h=1/sqrt(n): `P~1/(2sqrt(n))`.

The saved runs contain 21 scalar outputs: n={2,7,32} initial, {128,512} boundary, {1024,4096} expanded, three h choices per dimension. The plan's earlier abbreviated n-list was corrected to reflect the already executed n=1024 entries; no additional run was requested. SymPy certifies the power integral; SciPy checks the same one-dimensional integral numerically. SciPy error estimates are not outward interval certificates.

**Decision:** absolute tolerance of order 1/n preserves the single-cone volume order; order 1/sqrt(n) changes that order. But these are normalized Lebesgue volumes. Arbitrary AC mu may concentrate in any positive-volume portion. Neither the sqrt(2n) summed channel source cap nor this volume formula supplies a physical lost-volume bound by itself. Varying row coefficients t_je, actual old/new scales and the u/epsilon exposure remain required. No source/receiver density assumption or sup-row replacement is accepted.

## 2. Contact KKT: sign directions certified only in the actual finite families

The replacement file `euler_action.py` is explicitly a packing-contact diagnostic, not an Euler-action realization. For its equal two-interval family, the actual centered receivers are disjoint, fully owned and of length 1/16 each. W=1/8 and both owners are strictly positive. With epsilon=56, the complete new entropy KKT systems are:

| Geometry | Actual alpha | Q' | Positive multipliers | D at R=1/16 |
|---|---|---:|---|---:|
| positive common-cell length | (1/2,1/2) | 2 | joint 9 | 0 |
| null contact or separation | (1,1) | 4 | singletons 11/2 each | -1/8 |

The exact scripts verify positive-volume memberships, actual receiver intervals, packing, stationarity and complementary slackness. Boundary-only common intersections are correctly excluded from a.e. packing. Positive dual masses can be spread on the corresponding positive-volume saturated cells to give AC new KKT sources. No common-cell source atom is allowed at the null contact.

The semicontinuity signs are therefore
\[
Q'(0)=4\ge\limsup Q'(z)=2,
\qquad D(0)=-1/8\le\liminf D(z)=0.
\]
This supports Q' **upper** semicontinuity and D **lower** semicontinuity along this path; it refutes the opposite directions. The first informal reversed sign statement was corrected before acceptance.

The fixed real three-interval chain has positive-volume cells 12,23 before contact and 12 plus singleton 3 at contact. Its actual full disjoint receivers have p=d/32 and W=1117/6400. The entropy derivative is strictly decreasing from +infinity to -infinity, so rational 100-step bisection encloses a unique root before and after contact. The coefficients of Q in those roots have the signs used by the interval enclosure. The exact interval for `Q_contact-Q_overlap` is positive, about 0.000194670205535057. Thus this additional actual receiver family has the same direction. Receiver disjointness persists at contact as well as at the displayed positive-overlap parameter.

The script also saves a negative-jump algebraic example with abstract p=(1/250,1/1250,1/1000). Its total weight is 29/5000, not the true receiver-union volume 1117/6400; it is **not** an E-priority ownership and is rejected as an actual geometry/entropy counterexample. Its only permissible use is a warning that arbitrary log weights or an abstract polytope enlargement are not the full receiver contract.

**Decision:** if a general D-lower-semicontinuity theorem with the required coefficient/owner stability and an integrable uniform lower bound were independently established, a lower bound at the true physical limit could transfer to a nearby liminf. Lower bounds on approximants do not transfer backwards to this smaller limit value. These finite examples prove neither general Q' upper semicontinuity nor reachability by genuine old near-source-optimal/minset Euler paths. They do not provide an actual old state or critical R>1 input.

The final README explicitly excludes earlier discovery searches lacking saved reproducible scripts/logs. Their unsupported counts were removed. No such search was rerun or admitted into this review's evidence; only the five frozen two-row cases, the fixed actual chain and the explicitly invalid-owner warning are retained.

## 3. Near-active constant: source Young and physical payment are different

The geometric lower bound is independently proved in `NEAR_CONTACT_AUDIT.md`; the arithmetic script does not replace that proof. Its correct all-h coefficient is
\[
c=(t-1)/t^2=2b/t^2.
\]
The branchwise comparisons in `contact_certificate.py` are exact:
\[
c-c_{old}=(t-1)(3-t)/(4t^2)\quad(1<t\le3),
\qquad c-c_{old}=(t-3)/(2t^2)\quad(t\ge3).
\]
Thus the old coefficient is dominated in its proper branches. The low-u limits in the script are correct: the old candidate is asymptotic to u/(2n), whereas c is asymptotic to u/n. In particular `1/(u c)~n/u^2` and must not be treated as a uniform constant.

The 20 saved coefficient probes use n={2,7,32,4096}, u={1/1000,1,7/2,4,1000}. Their r0=1,h=1/(32n) source-Young table is explicitly a dimensional probe. For an actual AC source inside a normalized cube, r0=1 can leave the entire source in the unpaid low-radius region. Its lambda=1 Young additive costs do not automatically describe a dimension-dependent L credit or physical volume.

The actual source-exception expression and its completion-of-square calculation are valid under their stated hypotheses, but the physical expanded-image exposure is u/epsilon. The physical contract correctly switches to the balanced scalar relaxation
\[
B_{phys}(j)=\frac u\epsilon
 \min\left(1,\sqrt{j/(u c r_0h)}\right),
\quad 0\le j\le uq^2.
\]
For varying u the directly priced Cauchy coefficient uses `sum a_j u_j/c_j`; it is not the unweighted source coefficient `sum a_j/(u_j c_j)`. The plan and budget files retain that distinction.

On the square-root branch the stationary point is
\[
j_0=u/(4\epsilon^2 c r_0h L^2).
\]
On the capped branch the objective decreases. Therefore `j*=min(j0,u c r0h,u q^2)` is the exact maximizer, without a numerical optimizer. All 36 frozen budget probes have `u c r0h<uq^2` and select the capped transition. For u=7/2,eta=1/4,M=1,L=sqrt(n), the positive-part input in this branch simplifies exactly to
\[
\frac{119}{36\epsilon}-\sqrt n\,u c r_0h.
\]
The coefficient 119/36 follows from `u-eta*u/(1+u)=7/2-7/36`; no physical factor was dropped. The branch threshold is exactly `epsilon<=1/(2 c r0h sqrt(n))`. Thus for fixed permitted n,h the required residual divided by sqrt(n) diverges as epsilon decreases.

The 36 actual Arb 256-bit outputs report minimum root coefficient about 0.05163927028466286138 and maximum about 598.36265814560639199. The exact duplicate h choices at n=2 were correctly recognized as identical, rather than forcing an interval strict-order test. The script's branch tests and positive-part direction are appropriate for the displayed balls.

**Decision:** this optimistic scalar exception upper bound, even after spending one entire L*j credit and one eta*V allowance and setting all other costs to zero, does not independently furnish an epsilon-uniform root payment. This is an obstruction to that sufficient absorption certificate, not an actual loss lower bound, not a realizable KKT example, and not an impossibility theorem for the full geometric route. It does not invalidate root's separately proposed low-u/capture whole-family branch. Low-radius mass, physical cone thickness, source-gap/modulus and the signed joint remainder remain outside this scalar model.

## 4. Root's additional capture-margin certificate

I read the subsequently supplied `capture_certificate.py/json`. The four symbolic checks are correctly scoped:

1. derivative in u of `u(1+u)/(kappa-u)^2`;
2. derivative in kappa of the same ratio;
3. endpoint value 1/12 at u=1/2,kappa=7/2;
4. the exact decomposition
   `z-q-(z+1)/a=(1-1/a)(z-1)+(1-q-2/a)`.

On the stated low-u domain u<=1/2,kappa>=7/2, the derivative signs give the intended scalar 1/12 maximum. This is a low-copy-volume certificate; it does not, by relabeling, pay every earlier signed incoming-return score or permit duplicate use of growth credit.

The saved capture table has 112 actual Arb 256-bit cases: 48 initial, 32 boundary and 32 expanded, using n={1,2,7,32,128,512,4096}, four u values and four owner/child radius ratios per dimension. Its margin compares against `5/(48n)`. The unique boundary equality at n=1,u=1/2,ratio=1 is checked exactly with rational arithmetic, while other entries require a strict positive outward interval. This is the correct repair of the initial failed universal strict test; an equality must not be certified as strict by shrinking tolerance.

The table is finite consistency evidence. The exact factorization and the underlying capture geometry must still be used in the separately audited proof for arbitrary n. This review neither substitutes 112 checks for that proof nor certifies the resulting full-family integration or final D estimate.

## 5. Actual commands, arithmetic and non-replay boundary

The following are the execution owners' recorded reproduction commands, **not** reviewer reruns:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r652/numeric/cone.py initial
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r652/numeric/cone.py boundary
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r652/numeric/cone.py expanded
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r652/numeric/euler_action.py
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r652/numeric/contact_certificate.py
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r652/numeric/budget_physical.py
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r652/numeric/capture_certificate.py
```

Actual recorded environments are Python 3.12.14, SymPy 1.14.0, SciPy 1.18.1 where used, and python-flint 0.9.0 / Arb 256 bits for interval signs. Fraction geometry and bisection are exact. SciPy cone quadrature and the saved MATLAB R2026a contact single-point result are corroboration only, not certified rounding bounds. I inspected but did not rerun MATLAB. The owners preserve the initial assertion/type/order failures and successful corrected runs in their respective notes; installation is not counted as execution evidence.

For the three original contracts and capture addition, this reviewer executed only the following class of read-only inventory/hash command (the actual file list included the final capture certificate), without invoking a mathematical research script:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python - <<'PY'
from pathlib import Path
import json,hashlib
root=Path('/tmp/ccu_r652/numeric')
for name in ['cone.json','euler_action.json','contact_certificate.json',
             'budget_physical.json','capture_certificate.json']:
    obj=json.loads((root/name).read_text())
    print(name,type(obj).__name__)
for p in sorted(root.iterdir()):
    if p.is_file():
        print(p.name,hashlib.sha256(p.read_bytes()).hexdigest())
PY
```

The inventory confirmed 21 cone rows, five two-interval cases plus the chain object, 20 contact rows, 36 budget rows and capture counts 4 symbolic/112 interval. No unsupported discovery scan was repeated or certified.

## 6. Final artifact binding

| File in numeric/ | SHA-256 |
|---|---|
| cone.py | 650ea7fe4b728208f4fe4e4410dc60f1ffcf8709a0e3e542b3a85ccb95cd2eef |
| cone.json | 2f6b2ec56abfd1778fb48ccfbc21ab23bed92421db2e1a99dbc4b2ce87f8454c |
| README_cone.md | 8dbe60fd99fe6d9af9e02001a78fb1f60aa12a555a8fd04673a1b58300848e85 |
| euler_action.py | 1d40ef5c7bbd7548a99de2099570986cfac3651ee722f4e4ec4e5705b4a3906f |
| euler_action.json | 32f5f7717ecd6619fa598a5f19703094e2b8ceef95a8dc6a8088e63e18756396 |
| README_euler.md | 9259ea1e6b88ee5847bb6defc49a31a2b1231251ea1c60ee501adcc4d8ba547f |
| contact_certificate.py | 5ec320b997cdcfa9d1e6ebaf5a7050a0f5c97284c03a3d82d2b1a2cc7a619824 |
| contact_certificate.json | 2150478915bbc44e5fa4b63c2ff7c8d4312bea417905a96df67b25bf1feba804 |
| README_contact.md | 19293ca963155145ef5577ca82ccf7c4fb01d2fd0a42b53c2e75594d0fad4d62 |
| MATLAB_contact.txt | 80cbb431f1e86b117f2c436993fc615121affa62dce8a4c83709eb4a5d66d31d |
| budget_physical.py | 389e353e1061a13767151d37fc92e5a2c66f7fe0d350672d1455b0f1d5089514 |
| budget_physical.json | 859fef95ec58c3ba096c9cb217d4a40613727a8f999adfde0cfa05299b5bf568 |
| budget_README.md | ef01a7b701d5dea90e36fa23a2917ce10731d2c1e96daaf3d83633d706ba4510 |
| capture_certificate.py | 6ba581324f20631197dcff701e3c8cbe882aaf5319cfc1ab823ee6549e263e9c |
| capture_certificate.json | 245ac07dfccb1982f8075164dddefe0567692a12a6643c8ed4188b0021e06be8 |

The bounded numerical work stops here. It distinguishes valid volume geometry, actual KKT contact behavior, a failing isolated scalar absorption, and the new capture certificate without combining them as unpaid income. No general dimension claim or whole-family theorem has been established by these computations.

## 7. Root-added joint owner-program validation

After the preceding contracts ended, root authorized the three owner files below and no other new model. I received and froze the revised three fixtures before acceptance: n=1 is an equal-m tie control; n=2 has unequal radii and overlapping competing receivers; n=7 has those radii but disjoint receivers and very small W, so it is a forced-owner/scaling control. There is no claim that the last case tests free selection.

The common test A_j=Q(0,1/8) is contained in every selectable C_j, and E_j=B'_j. Thus each eligible receiver owner is geometrically source-capturing in these examples. The models do **not** supply a compatible old AC source, disjoint old I, old KKT state or full half-action realization. They validate a finite owner program, not automatic implementation of the original global KKT or the unresolved global bottleneck payment.

### Program and numerical residuals

The code uses exact Fraction cube intersections and inclusion-exclusion for eligibility-atom volumes. Each C family has a positive common intersection, so the full packing is exactly sum alpha<=1. A baseline of delta=1/100 splits every atom evenly; free allocation uses the same eligible labels. All available row volumes are positive. The objective is the joint convex relative-entropy B, and fixed-p minimization over alpha is equivalent to the actual entropy maximization.

For unequal m, I checked the scaling substitution: alpha_j=W beta_j off the maximum-m row, alpha_max=1-W sum beta. Dividing B by W and removing `-m_max/(epsilon W)` leaves the retained `x_max log W` term. That owner-dependent term is present; omitting it would alter the program. The fixed-p comparison is an independent SciPy scalar KKT solution, rather than another call to the joint CVXPY program.

The final JSON uses reference prices `u'_ref=epsilon p/(m alpha_ref)` for its primary free-price residual. Trial-CVXPY prices are separately retained. This correction matters: equal-m actual prices are exact ties, whereas the trial optimizer produced an artificial normalized excess about 1.64e-6. The fixed-p reference excess is zero in that control. In the nontrivial n=2 fixture the normalized reference excess is about 3.68e-12. The n=7 forced case has zero free-price excess by eligibility, not by an observed optimization benefit.

The maximum relative joint-alpha versus fixed-p-alpha discrepancies are about 1.88e-6, 4.14e-6, and 1.02e-9 for n=1,2,7. These are disclosed numerical errors. Solver status `optimal`, feasibility tolerances and a small residual do not certify an exact optimum. The accepted conclusion is numerical support for the procedure on these examples, with an exact special-case reference described next.

### Independent exact geometry/policy and bounded math postcheck

I independently reconstructed all receiver atoms from the exact input centers/radii, without importing author functions, checked W and capture containment, reconstructed the baseline and reference policies, and checked the recorded reference-price residuals. For the common-cell family the exact entropy multiplier equation is
\[
\sum_j\epsilon p_j/(z-m_j)=1,\quad z>\max m_j,
\qquad u'_j=z/m_j-1.
\]
Thus the free minimum price is precisely the largest eligible m. In n=1 all m are equal and every feasible owner is a tie. In n=7 all owners are forced. In n=2 the exact rational minimizing free policy gives
\[
W=469/204800,\quad
p=(16281/40960000,\ 29173/40960000,\ 24173/20480000).
\]
The joint solver's normalized p differs from this exact policy by at most about 1.06e-11. An independent 80-digit scalar solve at that exact p gave prices approximately
\[
(0.515464417730175795,\ 0.227526178361442394,\ 0.0144844449268118956),
\]
with strict ordering agreeing with the free choices. This is one bounded postcheck of the three new owner fixtures; it is not a new geometry, optimizer scan, replay of the old tasks, or interval certification of CVXPY output.

The actual postcheck used the installed math Python with Fraction and mpmath at 80 digits. It enumerated at most seven nonempty receiver subsets per fixture, checked the exact atom volumes/positive baseline, then performed 220 scalar bisection steps only for the exact n=2 reference. No CVXPY optimizer was rerun by the reviewer. Its output was:

```text
PASS owner geometry/baseline/reference-price model 1 exact_W 3/32
PASS owner geometry/baseline/reference-price model 2 exact_W 469/204800
n2_CVX_normalized_p_error_vs_exact_policy 1.0553974361116047e-11
n2_independent_80digit_actual_prices
  [0.515464417730175795,0.227526178361442394,0.0144844449268118956]
PASS owner geometry/baseline/reference-price model 7
  exact_W 1713507/110534070370304000000
PASS 3 fixed owner-program postchecks; no optimizer or old experiment rerun
```

The execution owner's reproducible command is

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r652/numeric/owner_program.py
```

It used Python 3.12.14, NumPy 2.5.4, SciPy 1.18.1, CVXPY 1.9.3 and CLARABEL. The solver outputs are floating approximations. Delta-positive exact feasible references establish the intended geometry/volume structure in these special cases; they do not remove the disclosed numerical errors or prove the general owner theorem.

Final added SHA-256 bindings:

| File in numeric/ | SHA-256 |
|---|---|
| owner_program.py | 9a3783fbc80c7faddcc659f59a9aae536f2e74304367370c8f615e205a9d56f1 |
| owner_program.json | c6775669f9b8eda4b576e36470d230ee8b1dca03b3f36df2c0fa257ea2a1387c |
| README_owner.md | 083a196b7b7efa9edb4521386611a2877779256eaf5e29e9fa713851b7448ced |

Only these three owner artifacts were added. The previous fifteen bindings remain in force. The remaining source-capturing bottleneck geometry and complete physical budget are not certified by these examples. No further numerical expansion is authorized.
