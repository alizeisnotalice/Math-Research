# R652 final joint-ledger integration audit

**Result: PASS for the integrated ledger and stated scopes, after the local notation/domain clarifications listed below. The full D/Gamma target remains unproved.**

Bound report: `/tmp/ccu_r652_final/REPORT.tex`

SHA-256: `bee6e6a49871f3572eb4b6deeee3e7bdea2b037b6a4f0dff283da64f4177ba71`

Scope: full same-family Euler ledger, one global potential allowance, source-capturing ownership interfaces, invasion/KL and 69/236 price, two-step boundary fees, and sharp-contact/scalar evidence scope. The main owner construction and numerical artifacts have separate audits; this review checks their integration and does not rerun numerical experiments. Only this file is edited.

## Corrections reported before completion

The draft scalar maximization formula needed an explicit saturation-endpoint condition, not only 'epsilon sufficiently small.' The report now restricts its statement to 0<h<=1/2, gives epsilon<=[2c r0 h sqrt(n)]^(-1), and verifies uc r0 h<=u/16<uq^2. Its exact maximizing endpoint and formula are valid on that stated domain.

The sharp-contact opposite-vector example now explicitly uses the cube vertex v=r0(1,...,1)=-w, so its near-active sets remain disjoint as h approaches 2r0 from below. The old row growth in the low-loss ratio is now e_k, explicitly defined, rather than the image-set symbol E_k. These were clarity/domain repairs; the retained coefficients were correct.

## 1. Full target, actual owners and deleted rows

The report keeps the actual old entropy/KKT state and one Euler product law. Old I_j are merely disjoint subsets of their receivers. New owners follow image priority and cover the whole new receiver union. Alpha is recomputed for the genuine resulting p; no fixed-alpha ownership variation is used.

The exact D=E-O+F+RS=W-RQ' account includes all old incoming/image/growth/loss rows. A deleted new owner has zero p, but its old image loss is still present. New u', row demands and probabilities are only defined on retained positive owners. No p/alpha=0/0 term or deleted source demand is introduced.

The main pending target remains E D>=cV-C L M, equivalently E[O-F-RS]<=E-cV+C L M. The report does not claim that source capture, min-price owners, bottleneck regions or invasion volume already prove it.

## 2. The global next-potential cost is spent once

For any actual next AC source, its normalized conditional h'_j is in [0,1], and H_next=eps sum p_j h'_j<=eps W=kappa'Q'. Same-class calibration gives kappa'<=4, so the actual score numerator is at least D-4LQ'. There is no extra g, AC attainment or optimizing-source kernel assumption.

The expectation direction is correct: Q'<=M gives E(D-4LQ')>=cV-(C+4)L M. The near-score T/eta thresholds match GLOBAL_LEDGER_AUDIT.md. This is a valid conditional reduction with a single O(LM) allowance. It is neither a per-channel payment nor a new geometric lower bound for D. It requires no quantitative lower bound on Q' and no successor critical lower endpoint.

Near score maximality retains only R'<=R+4L+eta. The forbidden raw-near-ratio inequality D<=eta Q' is explicitly rejected. Any additional H0 threshold is still required uniformly for root-order restoration.

## 3. Low-copy absorption and source capture

The capture proof uses the actual half action and receiver intersection. Its radius comparison and margin 5rho_k/(48n) have the stated direction. It covers high k at any scale whenever the owner radius is at least the child radius.

For u<=1/2 and old kappa>=7/2, ell_k/e_k<=1/12, so the split D>=11E_low/12+E_high-O_high+F+RS is valid. This is a use of raw E in the complete D branch. It is not combined with an already-derived R647 low-incoming residual as a second budget; nor does it pay the entire earlier signed incoming-return score merely by renaming it low overlap.

The eligibility set contains a largest-radius covering image, so it is nonempty. Every eligible owner, including its baseline portion, captures ALL high source cubes corresponding to images at that point. The final selection therefore keeps source capture even when its free min-price choice has smaller radius.

## 4. Joint actual owner program and its ledger interface

The convex objective B(p,alpha) has the stated PSD Hessian. Positive baseline floors and the alpha logarithmic barrier permit a genuine positive optimizer; fixed-p alpha minimization is exactly the actual new entropy optimum. The free first-order price is log u', so its minimizing eligible labels are precisely the lowest actual u' labels. Splitting ties according to the optimized allocations preserves the final p instead of silently changing alpha afterwards.

The baseline/free allocation and nested obstruction identity use the same actual prices. The bottleneck relation sum_(u'>t)p=delta sum_(u'>t)p0+(1-delta)|R_t| is consistent: a free point goes to a price above t exactly when every eligible price is above t. It is one nested family, not a separate capacity allowance at each threshold.

The finite atom/packing strata and deterministic secondary selection/slicing provide the intended measurable-policy interface; expectation statements do not rely on unproved attainment of the nonlinear full Gamma owner optimum. This construction optimizes its stated convex B, not the full Gamma objective.

The baseline bound delta W<=(345delta/64)V follows from R'<=69R/64, Q'<=M<=5Q. At delta=1/100 its coefficient is 69/1280. This is an exception AREA only; the report explicitly does not multiply it by an unproved unit incoming multiplicity.

## 5. Captured source columns are not physical-copy budgets

For each actual owner the union U_j of captured high source cubes is contained in C_j. Consequently sum alpha_j mu(U_j\A_j)<=S and sum alpha_j 1_Uj<=1 mu-a.e. are valid, and the row-dependent channel-weight extensions use sum_e w_je<=K in the correct order. No sup-row replacement or additional label/scale count is inserted.

The union prevents repeated source charges within an owner. It does not bound the sum of all child copy volumes: their factors u_k/eps and the actual owner weight still have to be priced. The report preserves this distinction and does not promote a source-column capacity into a bound on O_high.

## 6. Actual invasion, the 69/236 variant and one S reserve

The retained probabilities nu=a'/Q', P=p/W have P/nu=u'/kappa'. I=sum a'z<=S is the correct actual old-source invasion quantity. Entropy variational inequality gives the stated nonlinear log(I) bound, and W KL(P||nu)<=E'/kappa' uses the actual next variance and its exact mean constraint. Adaptive alpha/p cause no independence issue because these formulas are pathwise.

For z>=4, A_star<=S/4 and weighted Cauchy give owned volume <=R'A_star+sqrt[(E'/kappa')R'A_star]. Under r=R'/R<=69/64, the exact scalar reservation yields RS/2+(69/236)E'/kappa'. The logarithmic price is correctly an ALTERNATIVE. Their costs are not added.

This controls the disjoint actual owners I'_j of invaded rows, not the union of their full B'_j and not old lost-copy multiplicity over those points. A negative term priced at C copies of this owner volume would multiply BOTH charges by C. The report makes this barrier explicit.

Reserving RS/2 from the actual full Gamma slack is consistent with R-LH/M>=15R/16 in the calibrated regime, leaving 7RS/16 only if that reserve is actually debited once. No cited R645 cleanup supplies the new E' payment. The old growth or LJ_mix credit is not silently used again.

## 7. Two-step boundaries remain open

The stated two-step formula uses the genuine normalization M1=Q'_0, M2=Q'_1 and has the correct mass ratio M2/M1 on D0. It spends the bounded potential only at the final endpoint.

The conversion E'_0=(1+kappa1)E1 is retained. The 69/236 successor coefficient need not be <=1; kappa1>=69/167 is only a sufficient scalar compatibility condition when M2/M1<=1. No successor lower critical endpoint or mass drop is presumed.

Even if that coefficient is compatible, substituting the next full D ledger retains its O1,F1,S1 terms, especially the unpriced next overlap. The report therefore does not claim a two-step closure, summable variance or controlled terminal recursion.

## 8. Sharp near-contact proof and finite evidence limits

The improved chi coefficient 2b/t^2 is correct. If the chosen maximizing signed coordinate has deficit p>h, then p+bq<=r+bs and the monotone square-loss function gives at least h(2r+2bs-h)>=2bsh; the q>h branch gives at least 2brh. The extra b(r-s)^2 term is nonnegative. Opposite cube vertices with h approaching 2r0 show the asserted uniform coefficient is sharp. No strong convexity or source-coordinate independence is used.

The physical scalar model retains the factor u/epsilon and its j cap. With the corrected h and epsilon conditions, j=uc r0h lies in the interval and gives the stated 119/(36epsilon)-sqrt(n)uc r0h maximum. This is an obstruction to that scalar UPPER-BOUND absorption strategy, not an actual loss lower bound, a realized critical KKT counterexample or an impossibility theorem for the joint route.

The cone formula is normalized Lebesgue geometry, with the self-sign lower endpoint included. It is not applied as an arbitrary-source probability bound. The report also keeps finite entropy-contact topology examples separate from any actual old near-minimum Euler path and excludes incompatible-owner/unlogged searches as physical evidence.

I read NUMERIC_PLAN.md, the physical-budget README and NUMERIC_REVIEW.md. The counts/scopes of the accepted capture, cone, contact and scalar checks agree with the mathematical statements. Floating solver, SciPy and MATLAB outputs are corroboration only. The new finite owner program checks receiver/capture eligibility and its stated optimizer residuals; it does not realize the full old KKT/half action or certify the global theorem. No numerical experiment was rerun by this audit.

## 9. Final scope

The report establishes a genuine compatible owner policy and actual invaded-owner partial price, while keeping source capacity, area and copy multiplicity distinct. It does not reuse a withdrawn minimizing-gamma property, duplicate low growth, count one source reserve repeatedly, or equate finite solver evidence with proof of the old full contract.

The remaining task is the full joint bottleneck/multiplicity estimate on all actual near-score critical families, including weak invasion, genuine u/epsilon prices, all scales and source histories. The abstract/conclusion correctly leave the general weak-type bound, uniform positive full increment and terminal recursion unproved.
