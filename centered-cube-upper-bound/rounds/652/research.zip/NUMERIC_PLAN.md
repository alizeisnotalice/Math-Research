# R652 frozen numerical contracts and acceptance gates

This plan addresses the current **Eulerian** law and complete physical/score budgets. It does not rerun the R651 minimizing-gamma two-source experiment. Root assigns three existing Terra workers; no new agent, CPU-filling scan, Git operation, PDF, or modification of other worker files is authorized. The plan/review owner writes only this file and `NUMERIC_REVIEW.md`.

## The decision and the three independent responsibilities

The target remains a uniform full Gamma margin, or a geometric estimate `E D >= c V - C sqrt(n) polylog(n) M`, with the full `D=E-O+fill+RS`. In a separately verified calibrated successor-closed class with kappa'<=4, the actual next-potential allowance `H_next<=epsilon W<=4Q'` can be spent once globally; it is not another allowance per channel, row or iteration. None of the contracts below presumes the D estimate or converts a source cap into receiver volume for free.

1. **Cone/near-active thickening:** `/root/r647_far_certificate`, files with prefix `cone` under `numeric/`. Exact signed max-coordinate cone volume under genuine receiver-scale thickening. This task has no KKT or source-probability claim.
2. **Actual entropy contact limit:** `/root/r650_entropy_terra`, current `euler_action` files retained as filenames but containing only the replacement packing-contact test. Actual cubes, actual receiver ownership and exact KKT; decide semicontinuity directions relevant to transferring a lower bound. The old proposed Euler two-source integration is closed and is not executed.
3. **One-time exception-credit price:** `/root/r650_certificate_terra`, `contact`/`budget` files. Use the audited stronger near-active coefficient and actual exposure `u/epsilon`; compute the exact worst residual of the proposed exception bound after one mixing-credit payment. This is an explicitly scalar relaxation, not a geometrically realized KKT family.

The review owner is the common acceptance gate. Results must keep all three model scopes separate. No task can cite success of another finite model as proof of the missing source-to-physical bridge.

## 1. Signed cone volume with real receiver thickening

Freeze uniform Lebesgue volume on [-1,1]^n and the actual signed near-active event
\[
S_h=\{y:y_1\ge\|y\|_\infty-h\}.
\]
Use the L_infinity delta-neighborhood within the cube, delta=1/(32n): `x` is covered iff there is `y in S_h cap [-1,1]^n` with `||x-y||_infinity<=delta`. The event includes the self-coordinate restriction `y1>=-h/2`; dropping it gives the wrong volume.

For `z=h/2+delta<=1`, exact cross-sections give
\[
P_n(h,\delta)
=\frac12\left[h+2\delta+\frac{1-z^n}{n}\right].
\]
For z>=1 the covered cube is full and P=1. At z=1 the formulas agree. The derivation must record the lower x1 endpoint -z, plateau start 1-2z, and cross-section `min(1,x1+h+2delta)^(n-1)`. Boundary measure is zero; no density cap on an arbitrary AC mu follows.

The worker's already executed bounded parameter list is n in {2,7,32,128,512,1024,4096}; h in {0,1/n,1/sqrt(n)}, 21 scalar outputs. The original handoff abbreviated the expanded list; inspection of the saved output confirmed the already executed n=1024 entries. This corrects the record and does not request a new run. No expansion. Exact identities plus stable numerical integration may crosscheck the scalar cross-section, with actual versions/error convention recorded. The deciding distinctions are h~1/n preserving order 1/n versus h~1/sqrt(n) enlarging to order 1/sqrt(n), and the additional sqrt(2n) cover mass factor. These statements concern Lebesgue volume only. They cannot be applied to mu probabilities, actual arbitrary I_j densities, or adaptive receiver loss without a proved transfer.

In particular the current actual channel measures are `Tau_e=sum_j lambda_j t_je 1_Aj 1_contact mu` and satisfy the existing summed mass cap. This task does not replace varying t_je by sup_j t_je, assume pathwise channel balance, or give a weighted Carleson estimate.

## 2. Actual entropy Q' at loss of a positive-volume intersection

Freeze n=1,a=32,epsilon=56 and two actual new intervals
\[
C_1=[-1,1],\qquad C_2=[1-z,3-z],
\]
with z close to zero on both sides. Their real receivers have halfside 1/32 about the respective centers, remain disjoint throughout |z|<=1/8, and are fully owned: p1=p2=1/16,W=1/8. Their new linear volumes are m1=m2=2. Use scalar comparison R=1/16 solely to display D; no genuine old-source/half/near-minset path is asserted.

For z>0 the common cell has positive volume and actual packing includes alpha1+alpha2<=1. Actual entropy gives alpha=(1/2,1/2),Q'=2, common positive multiplier 9, new demands 9 each, and D=0. For z<=0 the common intersection has zero volume or is absent: the constraint must disappear from a.e. packing. Actual alpha=(1,1),Q'=4, independent multipliers 11/2, row demands 11/2, D=-1/8. The source masses have genuine AC representatives in their positive-volume saturated cells; no source atom at the contact point is permitted.

**Sign convention is part of acceptance.** At contact, `Q'(0)=4 >= limsup_{z->0+} Q'(z)=2`, so this example supports **upper** semicontinuity of Q'. Likewise `D(0)=-1/8 <= liminf D(z)=0`, so it supports **lower** semicontinuity of D. It refutes the opposite semicontinuities. A first informal description with these signs reversed was corrected before acceptance.

The direction matters: a true physical limit lower bound `D_limit>=B`, together with D lower semicontinuity and an appropriate integrable uniform lower bound, can transfer to nearby inputs in the liminf direction. Lower bounds already known only on nearby AC inputs do not transfer backwards to that smaller limit value. No general Q' upper semicontinuity is established by this example. Nor does it realize old source near-optimality, a minset-limit path, or the entire actual Euler law.

Root additionally authorized a bounded three-interval chain direction probe, not an arbitrary polytope scan:
\[
C_1=[-d_1,0],\quad C_2=[-a_0,d_2-a_0],\quad
C_3=[d_2-a_0-z,d_2-a_0-z+d_3].
\]
Use actual positive lengths, full disjoint actual receivers p_i=d_i/32, epsilon=56, and only geometries for which the positive-volume cells are exactly 12,23 before contact and 12 plus singleton 3 at contact. Freeze any proposed rational parameters before a run; provide exact KKT, not an optimizer status. For z>0, alpha1=alpha3=1-alpha2 and alpha2 solves
\[
d_2-(d_1+d_3)+\frac\epsilon{32}
 [d_2/\alpha_2-(d_1+d_3)/(1-\alpha_2)]=0.
\]
At contact alpha3=1 and the two-row equation uses d1 in place of d1+d3. Check actual receiver disjointness and every membership cell. If a few deterministic choices give no new direction information, stop; no broader family is authorized by this plan. An actual reversed jump would require a rational/algebraic KKT certificate before use. In all cases this is a local contact/KKT diagnostic; general semicontinuity or sufficient hypotheses belong to the proof audit.

## 3. Strong near-active constant and physical exception payment

Use the proof-audited stronger coefficient
\[
c(u,n)=2b/t^2=(t-1)/t^2,
\quad t=(1+u)^{1/n},\ b=(t-1)/2.
\]
Do not silently use the old weaker `sigma min(1,b)/t^2`, or describe a numerical table as proof that the new coefficient is globally optimal. The norm defect is exactly the current Euler chi, and `J_mix=sum a_j u_j E chi_j`.

The worker's already performed coefficient table at n={2,7,32,4096}, u={1/1000,1,7/2,4,1000} may be retained as bounded diagnostic evidence. Its `1/(u c)` and source-exception Young calculations are **source** bounds; they must not be relabeled as the physical exception cost. In particular r0=1 was only a dimension probe: for a genuine AC law inside a cube, choosing that radius can leave the entire source in the unpaid low-radius part.

The physical expanded-image exposure is u/epsilon, not one. For a balanced single-u scalar relaxation with M=1 and j=J_mix, the current near-active bound can charge at most
\[
B_{phys}(j)=\frac u\epsilon
 \min\left(1,\sqrt{\frac{j}{u c r_0 h}}\right).
\]
This follows by applying the row bound to the actual exposure, not by multiplying a source exception by an arbitrary uniform constant. For varying u the appropriate direct Cauchy expression involves `sum a_j u_j/c_j`, whereas the unweighted source bound involves `sum a_j/(u_j c_j)`; keep these distinct.

Test the exact one-credit scalar residual
\[
\mathcal R=\left[\max_{0\le j\le u q^2}
 (B_{phys}(j)-L j-\eta V)\right]_+,
\quad q=(1+t^{-1})/2,\ V=\frac{u}{\epsilon(1+u)},
\]
with eta=1/4,L=sqrt(n). This generously spends one fraction of V and one entire L J_mix credit, while granting all other errors zero. It does not assume that arbitrary j is realized by a near-optimal KKT source. An obstruction is therefore an obstruction to this scalar absorption certificate, not a counterexample to the geometric target.

The maximizing point is obtained without scanning: let `A^2=u/(epsilon^2 c r0 h)` and evaluate at
\[
j_* = \min\{A^2/(4L^2),\ u c r_0 h,\ u q^2\}.
\]
Report R and the required root coefficient R/sqrt(n), retaining epsilon. Freeze only u=7/2, n={2,7,32,4096}, r0=1/2, h={1/(32n),1/n,min(1/2,1/sqrt(n))}, epsilon={1,1/16,1/256}: 36 small scalar evaluations, not a physical/KKT sweep. Symbolic optimization and the epsilon->0 direction carry more decision value than the table; do not expand it. Any low-radius term, cone-thickening physical cost, old-source gap/modulus, and signed joint growth/source remainder remain explicitly unpaid and are not hidden in eta V.

The possible conclusion is precise: if this already optimistic scalar certificate needs more than root order or blows up as epsilon shrinks, the current exception estimate plus an isolated one-time Young absorption is insufficient. This does not show that a **joint geometric** estimate using the same prices cannot work. Conversely bounded values in this table do not prove a uniform budget. No repetition of the old scalar growth-Cauchy obstruction is needed.

## Acceptance, reproduction and stop

Each owner records exact model assumptions, actual command/environment, raw output, arithmetic direction/error convention and final hashes. Exact fractions/algebraic relations or outward Arb intervals certify stated signs; MATLAB/scipy floating integrals are diagnostic only. No sample graph or optimizer success flag becomes KKT or a general theorem. The review will bind accepted files without rewriting other owners' outputs.

The intended decision after these three tasks is whether the current **specific** thickening/near-active certificate can possibly close the true exposure budget, and what exact topology is needed before passing to old-source minsets. If not, stop at that obstruction and retain the full global target. No further Euler toy, more dimensions, or new source-LP existence exercise is authorized merely to keep processors busy.

## Root-added bounded owner-program validation

Root subsequently authorized only three additional owner-program files, `numeric/owner_program.py`, `owner_program.json`, `README_owner.md`, handled by the existing entropy Terra. The three fixtures are frozen: n=1 with centers (0,1/32), radii (1,1); n=2 and n=7 with centers (0,1/64,1/25) in the first coordinate, zero elsewhere, and radii (9/10,1,11/10). Receivers have halfside rho/(32n), E=B', epsilon=56, baseline delta=1/100. The capture-test A_j are all Q(0,1/8) and lie in every C. This is actual cube/receiver/capture eligibility geometry, but does not specify consistent disjoint old I, old KKT/source or a full old half action.

Compute exact positive-volume eligibility atoms by rational intersections and inclusion-exclusion. Solve the joint convex objective `sum p log[p/(m alpha)]-Q'/epsilon` with p=delta p0+(1-delta)free, then independently reoptimize alpha at the resulting fixed p and check the free min-u' rule using this reference actual alpha, not merely the trial joint solver alpha. Keep all residuals as numerical residuals.

The n=1 fixture is a price-tie control. The n=2 fixture has overlapping competing receivers and unequal m, so it tests a nontrivial price choice. At n=7 the specified receivers are actually disjoint; it is a forced-owner/small-scale conditioning control, not an ownership-gain example. Do not change its geometry to create additional competition.

All C have a positive common cell, reducing packing to sum alpha<=1. At the exact fixed-p optimizer, `m_j+epsilon p_j/alpha_j=z` and `u'_j=z/m_j-1`; thus in the unequal-m examples the exact free choice is the largest eligible m. This gives an independent rational owner-volume reference and a scalar KKT equation for alpha. For tiny W, normalize p by W, and for nonmaximal m write alpha_j=W beta_j. Dividing the objective by W and removing the common constant is allowed only if the owner-dependent `x_max log W` term is retained.

No prior numerical task is rerun. Acceptance is finite numerical support for this owner selection procedure, not a proof of the full original global KKT realization, bottleneck bound, ED estimate or Gamma margin. Final scripts/results/README hashes and the three bounded reviewer postchecks are appended to NUMERIC_REVIEW.md.
