"""Package integrity; optional bounded reproduction, never TeX compilation."""
import argparse, hashlib, json, os, re, shutil, subprocess, sys, tempfile
from pathlib import Path

root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--replay',action='store_true')
args=parser.parse_args()
manifest=json.loads((root/'MANIFEST.json').read_text())
for name, digest in manifest.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest, name
tex=(root/'REPORT.tex').read_text()
labels=re.findall(r'\\label\{([^}]+)\}',tex)
assert len(labels)==len(set(labels))
assert set(re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',tex))<=set(labels)
review=(root/'NUMERIC_REVIEW.md').read_text()
bindings=re.findall(r'^\| ([^|]+?) \| ([a-f0-9]{64}) \|$',review,re.M)
for name, digest in bindings:
    assert hashlib.sha256((root/'numeric'/name).read_bytes()).hexdigest()==digest, name
assert len(bindings)==18
for name in ['FINAL_GEOMETRY_AUDIT.md','FINAL_LEDGER_AUDIT.md']:
    assert manifest['REPORT.tex'] in (root/name).read_text(), name
result={'manifest_files':len(manifest),'latex_labels':len(labels),'numeric_bindings':len(bindings),
        'tex_compiled':False,'replay':[]}
if args.replay:
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    with tempfile.TemporaryDirectory(prefix='r652-replay-') as tmp:
        scratch=Path(tmp)
        shutil.copytree(root/'numeric',scratch/'numeric')
        def run(name,*extra):
            cp=subprocess.run([sys.executable,str(scratch/'numeric'/name),*extra],
                              cwd=scratch,env=env,capture_output=True,text=True,check=True,timeout=120)
            return cp.stdout
        cones=[json.loads(run('cone.py',stage)) for stage in ['initial','boundary','expanded']]
        assert cones==json.loads((root/'numeric/cone.json').read_text())
        result['replay'].append('cone: 21 frozen outputs matched')
        for name in ['contact_certificate','budget_physical','capture_certificate']:
            actual=json.loads(run(name+'.py'))
            assert actual==json.loads((root/'numeric'/f'{name}.json').read_text()), name
            result['replay'].append(name+': JSON matched')
        run('euler_action.py')
        assert json.loads((scratch/'numeric/euler_action.json').read_text())==json.loads((root/'numeric/euler_action.json').read_text())
        result['replay'].append('entropy contact: exact model JSON matched')
        run('owner_program.py')
        fresh=json.loads((scratch/'numeric/owner_program.json').read_text())
        old=json.loads((root/'numeric/owner_program.json').read_text())
        assert [c['dim'] for c in fresh['cases']]==[1,2,7]
        for a,b in zip(fresh['cases'],old['cases']):
            assert a['W_exact']==b['W_exact']
            r=a['residuals']
            for key in ['p_reconstruction_over_W','allocation_negative_over_W','sum_alpha',
                        'atom_fraction','total_p_over_W','baseline_lower_over_W']:
                assert abs(r[key])<1e-7,(a['dim'],key,r[key])
            assert r['alpha_fixed_p_max_relative']<1e-4
            assert r['weighted_free_price_excess_ref_over_W']<1e-7
        result['replay'].append('owner program: 3 exact geometries, floating residual gates passed')
print(json.dumps(result,indent=2))
