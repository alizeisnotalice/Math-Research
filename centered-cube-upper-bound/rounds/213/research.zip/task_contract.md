# R213：跨越前高比值交通的实际联合预算

一般目标不变：任意正L1输入的中心立方体 n^(1/2+o(1)) 一致弱型上界，真实receiver dx及全部来源/尺度/窗口费用。R212已提交 d4e0eac192fa5c112b32aa55327231bab2a68c20；只读冻结目录 /Users/zhengzhihao/Desktop/T/output/centered_cube_round212_20261016_final_checkpoint/。

准确对象：R212 BG23–24原RT1有限signed截断，P_early是完整rho0正交通在 p_y w_t(v)>L J_v 的限制，原N_avail完整只留此处一次。R212已付其补域16ΛL/(3K)Wν；共同L=Ksqrt n。不重新定义门/来源/删除/selector，不更改真实两槽Pi。原high p eg≥2Kq；FIRST ∫pβ≤q，∫Jν≤q；共同窗口固定J=P1,b及uniquej；最后Wν≤WA只属同一共同父构造，独立窗口另计。

重点尝试构造共同来源/receiver几何使高比值signed费用可付。可筛查的目标形式是 C(nK/L)W_A+epsilon X（K≤L≤Kn，常数与参数关系须明确），与已付低支平衡；这只是候选，不能当作已证或强行成立。若该形式无法直接证明，必须交付实际更弱但能改善整体费用的估计或准确不可省去的额外成本。不把势重命名、旧FTC重新推导或再列常数反例当成果。

原工具：R212动态cap精确损失、constant-good旧signed账、BC8缺陷容量与BC13–18联合clock限制；R181共同父来源；必要时读原R128 RT1–6/R170原势来源。已知障碍：good/bad不强制逐点score排序；终端Pi_g(B)≥1/2不向早时推广；pi=Jν/Q不等于Pi_t，小J/w_t尾无Markov价；nu≤beta不成立；suffix负信用不能重领；单位端点仅O(X)。数值只提供固定条件模型，不能认证FULL。

分工与责任：Astra复用r166_raw_budget，唯一核心 early_signed_geometry.md；Sol r166_exact_certificate 辅助 capped_potential.md，负责连续截断payoff的精确协方差/删除/跨越账以消掉人为阈值端点，并判断是否能给实际共享费用，不与Astra空间推导重复；Sol r164_audit audit.md先独筛准确命题再读稿；Sol medium r171_numeric_design在公式形成后实施本机数值/精确证书。主代理receiver接口、整合、LaTeX、报告及提交。各人仅改自己责任文件，不是独自编辑，不覆盖他人，不Git/编译PDF/自启代理；交付后停止。

策略检验分三阶段：初步小参数、已有门/删除/排序压力、扩大维数/阈值范围；只以实际运行作证，不猜阶数。终轮只归档经过独审的最终成果，逐轮commit并push；未结束不提交草稿。
