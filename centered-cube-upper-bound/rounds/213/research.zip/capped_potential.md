# R213：连续截断势、真实删除与双端低比值的一次来源预算

状态：证明同一实际时钟的连续截断势及完整signed交换式。阈值跨越无势原子，原删除仍导致真实归一上跳；内部G层与Et、suffix信用不能丢。进一步以同一reciprocal clock证明bad-low来源价，并将其与target-low的互斥G/B来源合账：两端至少一端low的原正交通只使用一次LQ/(p eg)来源预算。尚未支付两端均high的signed余项、势入口/active-E/suffix；不称一般目标闭合。

只改本稿，未读本轮Astra空间稿。旧工具仅用冻结R212 BG1--10、BG23--24，及R170 soft_threshold_energy §§1--3的原正负项。旧Wnu≤Wbeta排序不继承；最终只用原共同父Wnu≤WA。以下先固定同一原RT1行，所有source/selector/gate共同，nu与beta不要求互相支配。

## CP1　准确原对象、固定阈值及端点

原完整外测度保留
\[
 d\mathcal T=1_I1_{\{j(x)=j\}}q^{-1}p_yh_R(x-z)
 a_\omega\,dx\,\beta_V(dy)\nu_V(dz),
 \qquad p=p_y=P_{s,L_{cur}}(x-y).
 \tag{CP1}
\]
空间current尺度写Lcur，下面阈值参数写mathsf L，二者不能混用。本稿mathsf L>0在来源/辅助时间积分前共同预选。J_v=P1,b(x−v)是原固定窗口b的核，不是自由概率；QJ=∫Jν≤q。

终端G=Sg、B=Dg互斥，G⊔B=Zg，Et=Zt\Zg只删除。完整原Pi、clock为
\[
 n_t(dv)=1_{Z_t}(v)w_t(v)\nu(dv),\quad e_t=n_t(V),\quad
 \Pi_t=n_t/e_t,\quad -d w_t/d\log t=k_t w_t,
 \quad0\le k_t\le n.
 \tag{CP2}
\]
G、B均存活至g；不假定G/B与score排序。原rho0、Hrem、Ψ、FA及全部history/current/receiver资格保持实际原值，0≤rho0≤1；不重算alpha或捕获，也不以Psi为整行常数。

在非零p>0、0<eg<infinity的合法有限far段[ell,r]、r≤g上，定义
\[
 H_v=\mathsf L J_v/p,\quad
 \mathcal A_t=G\cap\{w_t>H\},\quad
 \mathcal C_t=G\setminus\mathcal A_t=G\cap\{w_t\le H\}.
 \tag{CP3}
\]
H依真实x,y,v和原参数，但不依辅助t；不得逐时刻另选最优门。p0/q0/eg0、空far按原零支先隔离。H0可在标量退化支直接使用正部，无除H。QJ0有效J来源按原零支处理。

端点统一为右起态ell、闭端右末态r，实际删除计(ell,r]。若原far上端开放，则用r−并排除r事件，不能左末态同时计末端删除。时间积分不受单一端点影响。若讨论多个实际时间段，势恒等式逐段保端点；下面非负预算可一次扩大到共同[ell,r]，不复制source价。

## CP2　连续截断势及阈值跨越

定义未归一payoff与势
\[
 N_H(t)=\int_G(w_t(v)-H_v)_+\nu(dv),\qquad
 F_H(t)=N_H(t)/e_t,
\]
\[
 I_t(v)=1_{\mathcal A_t}(v),\quad
 c_H(t)=e_t^{-1}\int_{\mathcal A_t}H_v\nu(dv),\quad
 F_H=\Pi_t(\mathcal A_t)-c_H\in[0,1].
 \tag{CP4}
\]
固定G和H时，w连续且非增，每来源至多向low跨越一次；(w−H)+为连续Lipschitz组合。阈值k的阶梯跳不使w跳，w=H的孤立时刻无时间原子；若在一段时间w=H，则kw=0 a.e.，不能凭此平台添通量。因此
\[
 \frac{dN_H}{d\log t}=-\int_{\mathcal A_t}k_t(v)w_t(v)\nu(dv)
 \quad\text{a.e.}
 \tag{CP5}
\]
nu有限或实际有限来源截断时，由k≤n、w≤w_ell和正eg给一般来源的AC/BV合法性；不需要空间输入梯度，也不假来源独立。

无删除的AC段，记kbar=∫k dPi，原商法则精确给
\[
 \boxed{-F_H'
 =\int_{\mathcal A_t}k_t\,d\Pi_t-F_H\bar k_t
 =\operatorname{Cov}_{\Pi_t}(I_t,k_t)+c_H\bar k_t.}
 \tag{CP6}
\]
prime对logt，不对普通t；这是时间变化的I与连续payoff推导，不是对I应用无跳链式法则。

等价地令f_t=1_G(1−H/w_t)+，在有效正w支有f'_t=−1_A k_t H/w_t，故
\[
 -F_H'=\operatorname{Cov}_{\Pi_t}(f_t,k_t)
       +\int_{\mathcal A_t}k_t H/w_t\,d\Pi_t.
 \tag{CP7}
\]
第二项是实际测试函数变化，不能因截断连续而删去。CP6的indicator covariance与CP7的fractional covariance不同，不将对前者的内部层费用误授后者全部G×G项。

## CP3　完整删除测度与上跳

实际未归一来源满足
\[
 dn_t=-k_t n_t\,d\log t-d\mathcal L_t,\quad
 d\lambda_t=d\mathcal L_t(V)\ge0,
 \quad d\mathcal L_t\text{仅移除原Et来源}.
 \tag{CP8}
\]
一般nested来源可由每点实际退出时刻推前构造；有限森林禁块是原子特例。以下连续删除包含AC及Cantor部分，不只有限跳。

G终端固定，所以删除不改变N_H。若同刻删去未归一质量d_t，令delta_t=d_t/e_{t-}<1，则
\[
 F_{H,t}-F_{H,t-}
 =F_{H,t-}\frac{\delta_t}{1-\delta_t}\ge0.
 \tag{CP9}
\]
连续删除贡献为dF_H|del,c=F_H dλc/e≥0。死亡delta1行先终止，不延续概率分母。阈值与删除同刻，N_H用同一连续w值；CP9用真实pre-delete和post-delete的e。这里的删除上跳不是原Ndel行密度，不能领第二份信用。

完整积分式为
\[
 \begin{split}
 \int_\ell^r\{\operatorname{Cov}(I_t,k_t)+c_H\bar k_t\}\frac{dt}{t}
 =F_H(\ell)-F_H(r)+\sum_{\ell<t\le r}\Delta F_{H,t}
 +\int_{(\ell,r]}F_H\frac{d\lambda^c_t}{e_t}.
 \end{split}\tag{CP10}
\]
最后两项真实非负，不能说连续截断使删除免费消失。有限截断先成立；去截断需要原可积控制，不以∞−∞定义signed量。H或G若随运行时间改变，还须实际test-exchange，本式不涵盖免费重选。

## CP4　与原negative的完整交互

令D_t(v,u)=k_t(v)−k_t(u)，D±为正负部，0≤h_t≤1收集原其它正门。准确high-target signed行密度为
\[
 \mathcal S_H=\int_{G\times B}\Psi\{\rho_0 h_t I_t(v)D_+-D_-\}\,d\Pi_t^2
             -\int_{E_t\times B}D_-\,d\Pi_t^2.
 \tag{CP11}
\]
CP11显示式按其中所示完整负份仍可使用的共同截断解释；已消费suffix负项不重新加入。若实际N_avail较少，必须显式加回其余已消费负份的差额，下面suffix项不自动涵盖其它消费。暂将正门放到1且保完整负项，记
\[
 C_{AC}=\int_{\mathcal A_t\times\mathcal C_t}D\,d\Pi_t^2,\quad
 C_{AE}=\int_{\mathcal A_t\times E_t}D\,d\Pi_t^2,
\]
\[
 N_{CB}=\int_{\mathcal C_t\times B}D_-\,d\Pi_t^2,\qquad
 N_{EB}=\int_{E_t\times B}D_-\,d\Pi_t^2.

\]
按I的二值分区，Cov(I,k)=C_AB+C_AC+C_AE，A×B的D+−D−=D，而C×B只剩负项。由CP6精确得到
\[
 \boxed{\mathcal S_H=-F_H'-c_H\bar k_t-C_{AC}-C_{AE}-N_{CB}-N_{EB}
             +\mathcal E_{gate},}
\]
\[
 \mathcal E_{gate}
 =-\int_{G\times B}I_t(v)(1-\Psi\rho_0h_t)D_+\,d\Pi_t^2
   +\int_{G\times B}(1-\Psi)D_-\,d\Pi_t^2.
 \tag{CP12}
\]
CP12中的F_H'只取CP6的clock导数/非删除密度，不是包含AC删除在内的总a.e.导数；积分时统一用CP10并保留全部连续与原子删除贡献。这保留真实gate差：第一项非正，第二项是可能已消费的suffix反向信用回加，不能免费丢弃。Psi依pair/time也不影响这一点态代数；本稿不微分它。

CP10代入CP12时，入口F_H(ell)、末端、删除上跳、C_AE及gate差全部原位。c_H kbar有利，但不能单独据此删除内部A×C或A×E。特别Et未来删除虽不出现在N_H分子，仍在kbar和真实后验里。

## CP5　reciprocal clock的正测度预算

由CP8，连续部分和原子分别给
\[
 d(1/e_t)=\frac{\bar k_t}{e_t}\,d\log t
           +\frac{d\lambda_t^c}{e_t^2}
           +\sum_t\left(\frac1{e_t}-\frac1{e_{t-}}\right)\delta_t^{time},
 \tag{CP13}
\]
删除两类项均非负；这里δtime是时间Dirac而非CP9概率delta。于是无需删除次数费用，
\[
 \boxed{\int_\ell^r\frac{\bar k_t}{e_t}\frac{dt}{t}
 \le\frac1{e_r}-\frac1{e_\ell}\le\frac1{e_g}.}
 \tag{CP14}
\]
完整连续删除只加强这一上界；不把其随机退出当成dt密度。它要求同一实际clock/来源和正终端eg，不按不同selector或不同window免费复制。

## CP6　内部G层交通确有可付的单次cap价

设M_G=∫G Hν<infinity，Ccap(t)=e_t^-1∫G min(w_t,H)ν。因Ccap≥Pi(C_t)，
\[
 (C_{AC})_+\le\int_{A\times C}(k_v-k_u)_+d\Pi^2
 \le\Pi(C_t)\bar k_t\le Ccap(t)\bar k_t
 \le M_G\bar k_t/e_t.
 \tag{CP15}
\]
危险方向更直接：
\[
 (C_{AC})_-\le\int_{A\times C}(k_u-k_v)_+d\Pi^2
 \le\int_{C_t}k_t(u)\,d\Pi_t(u)=:B_{low}(t).
\]
每个G来源终端存活，单调w的完整low尾FTC给
\[
 \int_\ell^r1_{\{w_t\le H\}}k_tw_t\frac{dt}{t}
 =[\min(w_\ell,H)-w_r]_+\le H,
 \quad\int_\ell^r B_{low}(t)\frac{dt}{t}\le M_G/e_g.
 \tag{CP16}
\]
CP14--16于是证明
\[
 \int_\ell^r(C_{AC})_-\frac{dt}{t}\le M_G/e_g,
 \qquad\int_\ell^r\int_{A\times C}|D|\,d\Pi_t^2\frac{dt}{t}\le2M_G/e_g.
 \tag{CP17}
\]
不用n次score跨越逐项收费，也不作逐时刻独立的最坏来源选择。若只需要CP12的危险方向，可用第一式而不先取绝对值；第二式用于确需双向控制的场合。它只支付该内部G层项，未支付active-E、入口和suffix，也不授CP7全部fractional-GG项同价。

一次原hard帽、high列及固定J真实dx后，CP17分别给16Lambda mathsfL/(3K)Wnu与32Lambda mathsfL/(3K)Wnu的来源价。下面给更直接的原正交通用途，并说明同一来源如何避免两端重复收费。

## CP7　实际bad-low与双端low的共享来源预算

对全实际来源定义low_t(z)={w_t(z)≤H_z}。任意固定来源子集D有
\[
 \Pi_t(D\cap low_t)\le e_t^{-1}\int_DH_z\nu(dz).
 \tag{CP18}
\]
特别M_B=∫B Hν沿辅助时间固定。因此原target-high、bad-low正交通（保Hrem/rho0/FA等原门）满足
\[
 \begin{split}
 P_{HL}^{row}
 &\le\int_\ell^r\Pi_t(B\cap low_t)
             \left(\int_{G\cap\{w>H\}}k_t(v)d\Pi_t(v)\right)\frac{dt}{t}\\
 &\le M_B\int_\ell^r\frac{\bar k_t}{e_t}\frac{dt}{t}
 \le M_B/e_g.
 \end{split}\tag{CP19}
\]
没有用bad在早时有统一概率下界，也没有另换后验或source。

R212的target-low FTC实际只使用G来源，准确保为
P_LL+P_LH≤M_G/e_g，而非一开始就用全nu。与CP19的正域不交，且同一真实G⊔B=Zg，所以
\[
 \boxed{P_{\{\text{至少一端low}\}}^{row}
 \le\frac{M_G+M_B}{e_g}
 =\frac1{e_g}\int_{Z_g}H_z\nu(dz)
 \le\frac{\mathsf L}{p e_g}Q_J.}
 \tag{CP20}
\]
标签G/B可依真实x,y等数据；只需沿辅助clock固定且互斥，不要求source独立。必须先合账再扩大Zg到全nu：若每支先用全M=mathsfL QJ/p再相加，就多出一倍；若分别给它们同一source帽后再把常数删掉，也不合法。

这是对R212已付target-low的可证明扩展：额外bad-low使用其原本未使用的B端cap来源，同一总J列价即可覆盖两端low的union。没有为严格physical非空扩大给新实例证书，也不将该union当成全部far。原负余额完整留在两端均high的signed补集一次。

## CP8　原receiver/high/J列与实际费用

在同一固定窗口b，CP20先乘原CP1；原hard源只用一次q^-1 h_R nu≤16/3，aomega≤1。high与同current FIRST给
\[
 \int_{high}\frac{\beta_V(dy)}{e_g(y)}
 \le\frac1{2Kq}\int p_y\beta_V(dy)\le1/(2K).
 \tag{CP21}
\]
故固定J、原uniquej保到求和时，
\[
 \boxed{2\Lambda\,\mathbb E\sum_{V,j}\int_{high}
 P_{\{\text{至少一端low}\}}^{row}d\mathcal T
 \le\frac{16\Lambda\mathsf L}{3K}
 \mathbb E\sum_V\int J\nu_V(x)dx
 =\frac{16\Lambda\mathsf L}{3K}W_\nu
 \le\frac{16\Lambda\mathsf L}{3K}W_A.}
 \tag{CP22}
\]
这里J已不依j才使用sum_j1j(x)=1；之后只在非负固定核列扩大接收域，∫Jνdx=νmass。未把原自适应p_y的核归一免费拿来积分，也不假nu≤beta。mathsfL=Ksqrt n给(16Lambda/3)sqrt n WA。共同原窗口/父来源账必须成立；独立窗口重跑须累加自身费用，不免费复用WA。

本源价不领任何原negative或epsilon恢复槽。它不自动支付CP17再加一次同交通；内部项的来源价与CP22是不同分析接口，若用于同一original positive份，必须说明合账或只择一使用，不能重复登记覆盖。

## CP9　剩余与有限检验接口

截断势解决人为的阈值势原子，并给CP6/10/12精确账；它不使F_H入口自动有J空间价格。F_H≤1仅给可能O(X)的receiver端点价，不是一般selector下的来源可积常数；删除上跳也真实保留。阈值H、rho0、Et或原门随新的参数重选时，须相应有限交换/变差，不由本固定H路径退款。

本轮实际可付项为CP20--22双端low；尚余同一original remaining far中target和bad两端均满足p w_t>mathsfL J的signed交通，保全部original negative余额、active-E交互、suffix资格与来源/receiver/selector依赖。没有证明其候选nK/mathsfL价，不能据mathsfL=Ksqrt n就称整个baseline已付。

最小数值接口：有限min-product时钟、G/B终端互斥、Et仅删除、固定H，逐普通段独立核−tFdot=Cov(I,k)+c kbar及CP12；在w=H处直接核N_H连续且不记时间原子；在每个实际并发E删除核CP9，不将跳写成dt。另核完整reciprocal ledger（AC clock、连续/原子删除分别列）以及CP19--20的M_G/M_B真实标签合账。有限模型不证空间phi/FIRST/history实现，不猜维数阶；已运行范围以最终numeric_notes为准，不在本稿预报尚未执行补项。
