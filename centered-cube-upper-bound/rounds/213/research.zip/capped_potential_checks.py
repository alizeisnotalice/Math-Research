#!/usr/bin/env python3
"""Exact finite capped-potential clock diagnostics; not FULL physical data."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
Z=F(0)
def dot(a,b):return sum((x*y for x,y in zip(a,b)),Z)
def w(c,t):
    ans=F(1)
    for ci in c:ans*=min(F(1),ci/t)
    return ans

def potential(nu,cs,h,good,alive,t):
    ws=[w(c,t) for c in cs];e=sum((nu[v]*ws[v] for v in alive),Z)
    numerator=sum((nu[v]*max(Z,ws[v]-h[v]) for v in good if v in alive),Z)
    assert e>0
    return numerator/e,numerator,e,ws

def diagnostic(nu,cs,h,good,bad,exitset,t):
    alive=set(range(len(nu)));value,num,e,ws=potential(nu,cs,h,good,alive,t)
    # Only ordinary nonthreshold/noncrossing points are differentiated.
    assert all(ci!=t for c in cs for ci in c)
    assert all(ws[v]!=h[v] for v in good)
    k=[sum(ci<t for ci in c) for c in cs]
    pi=[nu[v]*ws[v]/e for v in alive]
    active={v for v in good if ws[v]>h[v]}
    c=sum((nu[v]*h[v]/e for v in active),Z)
    kbar=dot(pi,k);pactive=sum((pi[v] for v in active),Z)
    assert 0<=value<=1 and value+c==pactive
    ndot=-sum((nu[v]*k[v]*ws[v]/t for v in active),Z)
    edot=-sum((nu[v]*k[v]*ws[v]/t for v in alive),Z)
    minus_t_direct=-t*(ndot*e-num*edot)/(e*e)
    cov=sum((pi[v]*k[v] for v in active),Z)-pactive*kbar
    # Separate independently enumerated pair covariance, ordered full sum /2.
    paircov=sum((pi[v]*pi[u]*(F(v in active)-F(u in active))*(k[v]-k[u])/2 for v in alive for u in alive),Z)
    cross={}
    for label,target in [('A_cross_B',bad),('A_cross_G_inactive',good-active),('A_cross_E',exitset)]:
        cross[label]=sum((pi[v]*pi[u]*(k[v]-k[u]) for v in active for u in target),Z)
    assert cov==paircov==sum(cross.values(),Z)
    correction=c*kbar
    mcap=dot(nu,h)
    mg=sum((nu[v]*h[v] for v in good),Z)
    mb=sum((nu[v]*h[v] for v in bad),Z)
    me=sum((nu[v]*h[v] for v in exitset),Z)
    assert mg+mb+me==mcap and mg+mb<=mcap
    badlow={u for u in bad if ws[u]<=h[u]}
    lowmass=sum((pi[u] for u in badlow),Z)
    positive=sum((pi[v]*pi[u]*max(0,k[v]-k[u]) for v in active for u in badlow),Z)
    price=mcap*kbar/e
    assert lowmass<=mb/e<=mcap/e and positive<=mb*kbar/e<=price
    inverse_derivative=-t*edot/(e*e)
    assert inverse_derivative==kbar/e
    assert minus_t_direct==cov+correction
    # Delete all E concurrently, using actual posterior mass d.
    d=sum((pi[v] for v in exitset),Z)
    after,after_num,after_e,_=potential(nu,cs,h,good,alive-exitset,t)
    assert d<1 and after_num==num and after_e==e*(1-d) and 1/after_e-1/e>=0
    jump=after-value
    assert jump==value*d/(1-d) and jump>=0 and 0<=after<=1
    return {'t':t,'w':ws,'k':k,'e':e,'Pi':pi,'active_A':sorted(active),'F':value,'c':c,'kbar':kbar,
        'c_kbar':correction,'direct_negative_logtime_derivative':minus_t_direct,'covariance':cov,
        'full_pair_covariance':paircov,'signed_cross_terms':cross,
        'badlow_source_set':sorted(badlow),'M_G':mg,'M_B':mb,'M_E':me,'M_G_plus_M_B':mg+mb,'M_group_sum':mg+mb+me,'M_all_H_nu':mcap,'Pi_badlow':lowmass,'badlow_posterior_upper':mcap/e,
        'positive_A_badlow_double_posterior':positive,'M_kbar_over_e':price,'badlow_posterior_group_upper':mb/e,'M_B_kbar_over_e':mb*kbar/e,'inverse_clock_log_derivative':inverse_derivative,
        'inverse_e_delete_jump':1/after_e-1/e,'delete_E_batch':sorted(exitset),
        'deleted_posterior_mass':d,'F_after_delete':after,'F_delete_jump':jump,'delete_formula':value*d/(1-d),'passed':True}

def case(name,stage,n,nu,cs,cap_mode='cross'):
    good={0,1};bad={2};exitset={3};alive=good|bad|exitset
    assert all(len(c)==n for c in cs) and all(x>0 for x in nu)
    stars=[F(3,5),F(4,5)]
    h=[w(cs[0],stars[0]),w(cs[1],stars[1]),F(1),F(1)]
    if cap_mode=='empty':h[:2]=[F(2),F(2)]
    if cap_mode=='all_active':h[:2]=[min(w(cs[i],F(1))/2,F(1,2**32)) for i in (0,1)]
    probes=[]
    for t in (F(11,20),F(13,20),F(17,20)):
        if any(ci==t for c in cs for ci in c) or any(w(cs[v],t)==h[v] for v in good):continue
        probes.append(diagnostic(nu,cs,h,good,bad,exitset,t))
    assert probes
    crosses=[]
    if cap_mode=='cross':
        for v,star in enumerate(stars):
            assert w(cs[v],star)==h[v]
            # Evaluate the two piece formulas at their common endpoint. The vanished
            # term is zero, so including or excluding the crossing source is exact.
            val,num,e,ws=potential(nu,cs,h,good,alive,star)
            including=sum((nu[u]*(ws[u]-h[u]) for u in good if ws[u]>h[u] or u==v),Z)/e
            excluding=sum((nu[u]*(ws[u]-h[u]) for u in good if ws[u]>h[u] and u!=v),Z)/e
            assert val==including==excluding
            crosses.append({'v':v,'t_star':star,'w_at_crossing':ws[v],'H':h[v],'F_including_zero_term':including,'F_excluding_zero_term':excluding,'jump_atom':Z,'passed':True})
    ledger=inverse_clock_ledger(nu,cs,exitset)
    grouped={label:sum((nu[v]*h[v] for v in ids),Z) for label,ids in [('M_G',good),('M_B',bad),('M_E',exitset)]}
    grouped['M_all']=dot(nu,h)
    assert grouped['M_G']+grouped['M_B']+grouped['M_E']==grouped['M_all']
    grouped['two_disjoint_source_price_numerator']=grouped['M_G']+grouped['M_B']
    assert grouped['two_disjoint_source_price_numerator']<=grouped['M_all']
    return {'name':name,'stage':stage,'n':n,'nu':nu,'C':cs,'H':h,'partition':{'G':sorted(good),'B':sorted(bad),'E':sorted(exitset)},'cap_mode':cap_mode,'disjoint_source_cap_budgets':grouped,'inverse_clock_FTC_ledger':ledger,'probes':probes,'crossings':crosses,'passed':True}

def inverse_clock_ledger(nu,cs,exitset):
    alive=set(range(len(nu)));l=F(1,2);delete=F(13,20);r=F(1)
    def e(t,ids):return sum((nu[v]*w(cs[v],t) for v in ids),Z)
    terms=[]
    for left,right,ids in ((l,delete,alive),(delete,r,alive-exitset)):
        cuts=sorted(set([left,right]+[ci for v in ids for ci in cs[v] if left<ci<right]))
        for a,b in zip(cuts,cuts[1:]):
            # d(1/e)/dlogt=kbar/e verified independently at ordinary probes.
            # Apply exact FTC on each fixed-score smooth interval.
            value=1/e(b,ids)-1/e(a,ids)
            mid=(a+b)/2;emid=e(mid,ids)
            kmid={v:sum(ci<mid for ci in cs[v]) for v in ids}
            polynomial_derivative=sum((nu[v]*kmid[v]*w(cs[v],mid) for v in ids),Z)/(emid*emid)
            kbar_mid=sum((nu[v]*w(cs[v],mid)*kmid[v]/emid for v in ids),Z)
            assert polynomial_derivative==kbar_mid/emid
            assert value>=0
            terms.append({'left':a,'right':b,'alive':sorted(ids),'integral_kbar_over_e_dlogt_via_FTC':value,'midpoint_inverse_clock_log_derivative':polynomial_derivative,'midpoint_kbar_over_e':kbar_mid/emid})
    cont=sum((x['integral_kbar_over_e_dlogt_via_FTC'] for x in terms),Z)
    jump=1/e(delete,alive-exitset)-1/e(delete,alive)
    diff=1/e(r,alive-exitset)-1/e(l,alive)
    assert jump>=0 and cont+jump==diff and cont<=diff
    return {'l':l,'r':r,'delete_time':delete,'delete_E_batch':sorted(exitset),'segments':terms,
            'continuous_integral':cont,'inverse_e_delete_jump':jump,'full_endpoint_inverse_e_difference':diff,'passed':True}

def two_source_badlow_integral():
    # Exact n2 model, no deletions. target high throughout, low bad starts at5/8.
    cv=[F(1,4),F(1,4)];cu=[F(1,2),F(1)];h=[F(1,20),F(4,5)]
    l=F(1,2);r=F(1);start=F(5,8);eg=w(cv,r)+w(cu,r);m=sum(h,Z)
    assert w(cu,start)==h[1] and w(cv,r)>h[0]
    # For t>.5: kv-ku=1, Pi_v Pi_u/t=(1/32)/(1/16+t/2)^2.
    actual=F(1,16)*(1/(F(1,16)+start/2)-1/(F(1,16)+r/2))
    for t in (start,F(3,4),F(7,8)):
        a=w(cv,t);b=w(cu,t);e=a+b
        assert a*b/(e*e*t)==F(1,32)/(F(1,16)+t/2)**2
        assert a>h[0] and b<=h[1]
    assert actual==F(1,18) and actual<=m/eg
    return {'n':2,'nu':[F(1),F(1)],'C_v':cv,'C_u':cu,'H':h,'l':l,'r':r,'badlow_start':start,
            'e_g':eg,'M_all_H_nu':m,'exact_time_integrated_positive_double_Pi':actual,'M_over_e_g':m/eg,
            'scope':'Complete stated two-source conditional clock; rational primitive, not discrete time approximation or FULL.', 'passed':True}

def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,list):return [encode(v) for v in x]
    return x

def run():
    base=[[F(9,20)],[F(7,10)],[F(1)],[F(1,4)]]
    rows=[case('one_dimensional_crossings','initial',1,[F(1)]*4,base),
          case('one_dimensional_unequal_mass','initial',1,[F(1),F(2),F(1),F(1,2)],base),
          case('one_dimensional_reversed_E_score','initial',1,[F(1)]*4,[[F(9,20)],[F(7,10)],[F(1,4)],[F(1)]]),
          case('heavy_exit_mass','stress',1,[F(1),F(1),F(1),F(2**20)],base),
          case('empty_active_zero_potential','stress',2,[F(1)]*4,[c*2 for c in base],'empty'),
          case('all_good_active_tiny_caps','stress',2,[F(1),F(1,1024),F(4),F(1,2)],[c*2 for c in base],'all_active')]
    for n in (4,16,64):
        cs=[[F(1,4) if j%3==0 else F(9,10) for j in range(n)],
            [F(7,10) if j%2==0 else F(1) for j in range(n)],
            [F(1) if j%3 else F(1,2) for j in range(n)],
            [F(1,2**(j%8+1)) for j in range(n)]]
        rows.append(case('multisource_dynamic_range_n'+str(n),'expanded',n,[F(1,2**20),F(3),F(1024),F(1,16)],cs))
    return {'schema':'R213_capped_potential_Fraction_v1','inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'definition':'F=sum_G nu(w-H)+/e; A={v in G:w>H}; c=sum_A nu H/e; derivatives ordinary in t, displayed -t Fdot',
        'counts':{'models':len(rows),'ordinary_probes':sum(len(r['probes']) for r in rows),'crossing_checks':sum(len(r['crossings']) for r in rows)},
        'models':rows,'exact_two_source_badlow_integral':two_source_badlow_integral(),'all_passed':True,'scope':['Exact finite min-product source clocks and full stated G/B/E posterior; not spatial kernels/high/FIRST/history/FULL.',
        'Cross continuity is endpoint agreement of exact piece formulas; no artificial atom is charged. No global positive-variation bound is inferred.',
        'All signed cross interactions and c*kbar are retained; deleting E creates a positive normalization jump and is not free.']}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'capped_potential_checks.json');args=ap.parse_args()
    result=run();args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(encode(result),sort_keys=True,indent=2)+'\n')
    print(json.dumps(result['counts'],sort_keys=True)+' PASS')
