# R213：两端高比值基线的实际 K0 空间缺陷

状态：本稿证明原 baseline 活跃目标的精确逐坐标缺陷公式、闭核排除及带内部增益的外部必要成本，保留同一 alpha0、时钟损失和真实尺度夹断。它缩小下一步 receiver/source 预算的实际几何支撑，但不提供新的根阶付款。本轮两端至少一低的实付价格由父稿 `two_ended_cap.md` TC4 给出；本稿不重复领取该来源价。一般 HH signed 预算仍开放。

## 1. 对象、来源及本稿不改变的测度

只使用 R212 冻结 `baseline_geometry.md` BG1–5、BG15、BG23–24，`baseline_coupling.md` BC1–18，以及原 R128 RT4–6 的物理核/尺度。R212 冻结目录为
`/Users/zhengzhihao/Desktop/T/output/centered_cube_round212_20261016_final_checkpoint/`。
原核的准确定位为 R128
`/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md` 约637–667行。

固定原合法窗口和有限 signed 截断，保留实际完整行
`(omega,V,j,x,y,硬源z,history)`。以下 `L` 是当前物理尺度，`mathsf L` 才是预定动态比值阈值。令
\[
 p_y=P_{s,L}(x-y),\quad J_v=P_{1,b}(x-v),\quad
 Q_v^*=(P_{s,L}(x-v)+P_{s,L^+}(x-v)+J_v)/3,
 \quad L^+=\min(b,\gamma L),\quad\gamma=1+1/n.
\tag{ES1}
\]
原共同 q、FIRST、high、remaining、FA、suffix、唯一 j、真实 hard 来源、dx 和全部来源标签不变。特别仍用
\[
 d\mathcal T=1_I1_{\{j(x)=j\}}q^{-1}p_yh_R(x-z)a_\omega
 \,dx\,\beta_V(dy)\nu_V(dz),
\quad d\Pi_t(v)=\frac{1_{Z_t}(v)w_t(v)}{e_t}\,d\nu_V(v).
\tag{ES2}
\]
`nu<=beta` 不成立也不需要。固定 `(omega,V,j,y,t)` 时 Pi 不依 x；其终端、当前尺度、capture 和以下空间门依 x，不能一并移出 receiver 积分。

终端 `G=S_g,B=D_g`、实际 capture 集 E、共同归一
\[
 Q_J=\int J_vd\nu(v)>0,\quad \alpha_0=Dq/Q_J,
 \quad a_v=T\Delta_v,\quad\Delta_v=w_\tau(v)-w_h(v)
\]
保持 R211–212 的原定义。只在 E 上定义非零基线
\[
 \rho_{0v}=\left(1-\frac{DK_{0v}+\alpha_0J_v}{T\Delta_v}\right)_+.
\tag{ES3}
\]
E 外取零；`Delta=0`、空 far、零分母等先按原零行约定处理。原 strict-soft 条件保证 `0<s<=1`，因此本文所有有限距离处 `K0,J,f_s` 严格正。本文不把含除 s 或 log s 的公式延伸至 s=0。

父稿 TC4 合并了同一终端 good/bad 的不交来源质量，支付两端至少一低的正片，只领一份
\[
 \frac{16\Lambda\mathsf L}{3K}W_A.
\]
其后真正剩余为
\[
 \mathcal H_H(t)=
 \{p_yw_t(v)>\mathsf L J_v,\quad p_yw_t(u)>\mathsf L J_u\},
 \quad v\in G,\ u\in B,
\tag{ES4}
\]
与原所有正门相交；`N_avail` 完整仅留这个剩余一次。取 `mathsf L=K sqrt(n)` 是已付低片的根阶选择，不赋予 HH 任何独立概率或来源帽。

## 2. 实际尺度归一：保留上下夹断

一维记
\[
 h_1=1_{[-1/2,1/2]},\quad
 \varphi=h_1*w,\quad w(r)=\int_0^1e^{-|r|/a}\,da,
 \quad f_s=(1-s)h_1+s\varphi.
\]
定义
\[
 a_s:=f_s(1/2)=1-s+s\varphi(1/2)>0,
\]
\[
 H_0=g c_j^{-1/2}a_s\ell^{1/(2n)},\qquad
 \widehat H=\max(a_{win},\min(b,H_0)),\qquad
 T=\frac{c_j^{n/2}}{g^n\sqrt\ell}.
\tag{ES5}
\]
这里 `ell=1+log n`，`a_win<=L,R<=b<=2a_win`；`a_win` 不与目标 capture 量 a_v 混用。原公式精确给
\[
 H_0^nT=a_s^n.
\tag{ES6}
\]
令
\[
 r_i(v)=|x_i-v_i|/\widehat H,\qquad
 F_s(r)=\log\frac{a_s}{f_s(r)},\qquad
 \mathcal D_s(x,v)=\sum_{i=1}^nF_s(r_i(v)).
\]
则实际 K0 核满足
\[
 \boxed{\frac{K_{0v}}T
  =\left(\frac{H_0}{\widehat H}\right)^n
    \exp[-\mathcal D_s(x,v)].}
\tag{ES7}
\]
证明只需将 `K0=Hhat^-n product f_s(r_i)` 代入 ES6。式中夹断比例不能丢弃：未夹断比例为1，上夹断大于等于1，下夹断小于等于1。

## 3. 同一 alpha0/J 的精确缺陷关系

固定 `0<eta<=1`，只讨论原目标 `rho0>1-eta`。eta=1 正好包含全部正基线支，而不是一个额外的高残余假设。写
\[
 \zeta_v=\frac{\alpha_0J_v}{T\Delta_v},\qquad
 \eta_{eff,v}=\eta-\zeta_v.
\]
原活跃支强制 `eta_eff>0`，并给严格必要条件
\[
 \boxed{\mathcal D_s(x,v)>
 \log\frac D{\eta_{eff,v}}
 +n\log\frac{H_0}{\widehat H}-\log\Delta_v
 =:\Theta_v.}
\tag{ES8}
\]
其中真实 `Delta_v`、J、alpha0 与 K0 属于同一行，不分别取极值。证明为
`DK0/(T Delta)<eta-zeta` 后取正分母对数。

还可不引入 eta，在每个正基线目标上写精确式
\[
 \mathcal D_s(x,v)
 =\log D+n\log(H_0/\widehat H)-\log\Delta_v
 -\log(1-\rho_{0v}-\zeta_v).
\tag{ES9}
\]
最后一个对数的参数恰为 `DK0/(T Delta)>0`。它不是一个待独立估计的自由变量，也不能在高 rho 分支将其换成 eta 后忘掉实际 J 的费用。

## 4. 闭核排除与下夹断例外

phi 偶对称且随非负距离单调不增。若 `r<=1/2`，原闭硬面约定给 `f_s(r)>=a_s`，所以 `F_s(r)<=0`。因此对闭 cube
\[
 \mathcal Q_{\widehat H}(x)=\{v:|x_i-v_i|\le\widehat H/2\ \forall i\}
\]
有 `K0v/T>=(H0/Hhat)^n`。若
\[
 D(H_0/\widehat H)^n\ge1,
\tag{ES10}
\]
则整个闭 cube 上 `DK0>=T>=T Delta`，与正基线条件矛盾。于是
\[
 \rho_{0v}>0\quad\Longrightarrow\quad
 v\notin\mathcal Q_{\widehat H}(x)
 \qquad\text{在 ES10 下。}
\tag{ES11}
\]
这是实际零交通支撑结论，不把它单独记成来源根价。

ES10 对未夹断及上夹断自动成立，因为 D>=1。若 `H0<a_win`，则 `Hhat=a_win`，ES10 未必成立，不能沿用上述排除。该下夹断闭 cube 若仍有正基线，必须满足更具体的原联合必要式
\[
 D(H_0/a_{win})^n+\alpha_0J_v/T<\Delta_v\le1.
\tag{ES12}
\]
保 J 项后这一必要式可能进一步排空，但本稿没有由它推导新的全局质量帽。所有等号面均按原 closed h 处理；不因原 nu 为 L1 就把自适应 x/L 的面事件删掉。

如果 ES10 成立且 `Hhat>=L`，ES11 还排除该目标在当前 L 的整个闭 hard cube；若 `Hhat>=Lplus`，则同时排除另一个 current 核的闭 hard cube。特别相应 tensor 展开中的纯全硬项
\[
 (1-s)^nL^{-n}\prod_i h_1((x_i-v_i)/L)
\]
在正基线支恒为零。更精确地，任何非零 mixed 项必须将所有满足 `|x_i-v_i|>L/2` 的坐标选为 soft。这是同一物理核的逐点展开，不是独立来源假设。

不能由纯全硬项为零推断整个 mixed current 核为零，也不能把这一静态支持结论当成 capture/selector 改变时的所有面交换已付。s=1 时纯硬项本来为零，而 ES7–12 仍成立。

## 5. 外部距离与内部增益的定量竞争

定义原 Hhat cube 的外部坐标集、越界量和内部增益
\[
 O_v=\{i:r_i(v)>1/2\},\quad m_v=|O_v|,\quad
 V_{out,v}=\sum_{i\in O_v}(r_i(v)-1/2),
\]
\[
 J_s=\log\frac{a_s}{s\varphi(1/2)}\ge0,\qquad
 D_{in,v}=\sum_{i\notin O_v}\log\frac{f_s(r_i(v))}{a_s}\ge0.
\tag{ES13}
\]
外侧没有 h 项，因此有准确分解
\[
 \mathcal D_s(x,v)=m_vJ_s
 +\sum_{i\in O_v}\log\frac{\varphi(1/2)}{\varphi(r_i(v))}
 -D_{in,v}.
\tag{ES14}
\]
J_s 是跨原硬面的真实对数跳跃。s=1 时 J_s=0；闭面 r_i=1/2 属于内部，不能把这层多领一次外跳。

这里可取安全的一维尾斜率界
\[
 1\le-\frac{d}{dr}\log\varphi(r)\le8\quad(r>1/2).
\tag{ES15}
\]
为自含核验，写 `z=r-1/2>=0`，
`phi(r)=int_0^1 a(1-e^{-1/a})e^{-z/a} da`。
其负对数斜率是这个正权下 `1/a` 的均值，所以至少1；对 z>0 它的导数是负方差，故不增。边界的一阶分子、分母可积，斜率连续延至 z=0。该分子<=1，分母严格大于
`int_{1/2}^1 a(1-e^{-1}) da>3/16`，故边界斜率<16/3<8。没有声称边界二阶矩有限。

积分 ES15 得
\[
 m_vJ_s+V_{out,v}-D_{in,v}
 \le\mathcal D_s(x,v)
 \le m_vJ_s+8V_{out,v}-D_{in,v}.
\tag{ES16}
\]
所以原高残余支的真正必要几何成本是
\[
 \boxed{m_vJ_s+8V_{out,v}>\Theta_v+D_{in,v}.}
\tag{ES17}
\]
这比只说目标离开某个 cube 保留更多信息：深处 current/K0 核内的坐标给正的内部成本，必须由其它坐标的硬面跨越或尾位移共同补足。所有坐标始终来自同一个 v，不可独立抽样。

例如固定 `0<=r0<1/2`，若 q_deep 个坐标满足 `r_i<=r0`，则
\[
 D_{in,v}\ge q_{deep}\log\frac{f_s(r_0)}{a_s},\qquad
 m_vJ_s+8V_{out,v}>\Theta_v+
 q_{deep}\log\frac{f_s(r_0)}{a_s}.
\tag{ES18}
\]
右侧若为负，这个式子当然不给正的外部成本。原下夹断可使 `n log(H0/Hhat)` 为负，不能为获得一个漂亮的正阈值而删掉它。若右侧为正，ES17 只迫使硬跨越与尾位移至少一项够大；没有提供它们在原 receiver 测度下的概率价。

## 6. 原两腿 high / good-bad 关系仍保在同一点

这些空间限制只作用于正基线 target v；bad u 并不属于 E，不能对 u 免费施加 ES3 或 ES8。仍须联合保留
\[
 p_yw_g(v)\le KQ_v^*,\quad p_yw_g(u)>KQ_u^*,\quad
 p_yw_t(v)>\mathsf L J_v,\quad p_yw_t(u)>\mathsf L J_u,
\tag{ES19}
\]
以及同一 `(x,y,v,u)` 的原 score 差 `d_t=kv-ku`。其中两端高只分别给 J/clock 上界，不给两来源 J 比值的顺序。

BG19 的原物理关系在此仍准确：
\[
 \log\frac{Q_v^*/w_t(v)}{Q_u^*/w_t(u)}
 =\log\frac{Q_v^*/w_g(v)}{Q_u^*/w_g(u)}
   -\int_t^g(k_s(v)-k_s(u))\frac{ds}{s}.
\tag{ES20}
\]
终端右边第一项严格正，但它不强迫当前 score 同序。ES17 也不消去该 signed clock 积分。不能把 current/Hhat cube 的坐标跨越数 m_v 误认成 min-product 时钟的 k_t(v)。两者的中心、尺度和阈值不同。

## 7. 真实回代与第一处仍缺的几何积分

在已付至少一低片以后，原待估对象准确为
\[
 \mathfrak R_{HH}=2\Lambda\,\mathbb E\sum_{V,j}
 \int1_{high}\,d\mathcal T\left[
 \int_l^r\iint_{G\times B}\Psi M_t\rho_{0v}
 1_{\mathcal H_H(t)}(k_t(v)-k_t(u))_+
 d\Pi_t(v)d\Pi_t(u)\frac{dt}{t}
 -N_{avail}^{row}\right].
\tag{ES21}
\]
此式中的正支已经必然满足 ES7–9、ES17；可以无价加上这些已证明必要支持指示，但不能据此宣称其质量小。`M_t` 保留 original remaining/FA/history，真实负余额仅此一次；source/window/j 也没有被消去。

要将本稿空间信息变成目标 `C nK/mathsf L WA+epsilon X`，第一处还缺的是 **在同一个 ES2 外测度上** 对 ES21 中
\[
 1_{\{m_vJ_s+8V_{out,v}>\Theta_v+D_{in,v}\}}
 1_{\mathcal H_H(t)}\rho_{0v}(k_t(v)-k_t(u))_+
\tag{ES22}
\]
与尚可用反向/删除交通的共同 receiver 积分控制。不能单独用 FIRST 的 `int K0 nu<=q` 给 ES22 一个尾概率，因为 ES8 是 K0 的低密度条件，FIRST 控制的是相反方向的大核质量；原 target 后验的密度仍是 `1_Z wt/e`，而不是 K0 归一来源。也不能把外部越界量视作对 receiver 的薄层：Hhat、s、当前 L 和原门均受同一实际 selector 约束，闭面的贡献须保留。

若先将 ES21 的有符号账改写成 R212 BG15，仍必须保实际 `(l,r)` 内侧端点、全部删除变差、suffix 泄漏及已消费负余额差。它们不因 ES17 成为非负或可忽略。本文没有将这些项单独取绝对值后重复领取来源预算。

因此本稿提供的是带真实 scale clamp、alpha0/J 和内部坐标成本的可计算空间约束；原两端高核心尚无新的全局根阶预算。下一步必须证明 ES22 的共同来源/receiver 支付或其与原负余额的实际抵消，而非再从无权 h 质量、辅助概率归一或逐点 score 符号推出不存在的容量。
