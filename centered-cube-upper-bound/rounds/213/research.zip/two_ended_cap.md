# R213 主推导：真实归一化时钟与双端低比值交通预算

准确对象和来源合同见task_contract.md。本稿只结算原remaining正泛函中新增的坏端低比值部分，原负余额完整留在两端都高的补域。该结论不支付补域，也不解除其它原块。

## 1. 真实倒分母时钟

固定原合法行及有限正窗[l,r]⊂[tau,h]。令e(t)=∫Zt w_tν≥eg>0，kbar(t)=∫k_t dΠ_t。来源删去历程Zt递减；w_t为原min-product时钟，−dlog w_t=k_t dlog t，0≤kt≤n。

在没有删源的时间，e的clock导数为−e kbar。一般删除给额外非负损失测度；因此在有限窗的BV测度意义，

    d(1/e) ≥ (kbar/e) dlog t.

一批删掉质量d*e_minus，其中0≤d<1，其倒分母上跳为d/[(1−d)e_minus]≥0。连续与奇异连续删除同样只增加倒分母。端点的一侧约定必须一致；含端点删除时，右侧总变差只增不减。因此

    ∫_[l,r] kbar/e dlog t ≤ 1/e_r−1/e_l ≤ 1/eg.           (TC1)

论证可先对有限来源/有限删除分段直接链式求导，再以原正测度截断和单调性推广；更直接对e的正下界使用BV链式规则。一般来源的clock绝对连续性在有限正窗由kt≤n与e_l<∞给出。这里没有把后验变成固定概率，也没有假e独立于接收点。

## 2. 坏端低比值交通及共同来源合账

共同预定L>0；原p>0、J=P1,b、QJ=∫Jν。置H_v=LJ_v/p，M=∫H_vν=LQJ/p。在原完整Pi_t上，不论该来源属于终端good、bad或待删除，

    Π_t({w_t≤H}) = e_t^-1∫Zt∩{w≤H} wν ≤ M/e_t.          (TC2)

现在只取原正交通中target高而bad端低的部分：

    p w_t(v)>LJ_v,     p w_t(u)≤LJ_u,     v∈G,u∈B.

全部原remaining/FA/suffix/rho0门仍保留到正放松。由D+=(kv−ku)+≤kv、rho0≤1和TC2，完整两腿正密度至多

    Π_t(B_low)∫G_high kv dΠ_t ≤ (M/e_t) kbar(t).

坏端B为终端固定集合，因此TC2实际可保更小的M_B=∫B Hν，得到R_HL≤M_B/eg。特别也有 p R_HL≤LQJ/eg。与R212相同但只使用一次完整外积费用，先hard帽16/3、再high列∫β/eg≤1/(2K)，保唯一j与固定窗口J至最后dx积分：

    2Λ P_HL ≤ 16Λ L/(3K) Wν ≤ 16Λ L/(3K) WA.             (TC3)

同一共同父构造内叶质量求和；独立窗口菜单仍逐窗按实际来源预算累加，不免掉原尺度费用。ν≤β没有使用。

R212已经支付target低的全部原正片，记P_L*；它与本稿P_HL不交。剩余P_HH同时满足两端比值高。因此在原有限signed截断上精确

    P_rem−N_avail = (P_HH−N_avail)+P_L*+P_HL,

此处应先在同一行合并来源预算，而不能分别放大成全ν再相加。R212逐目标FTC可保R_L*≤M_G/eg，M_G=∫G Hν；新坏端片保R_HL≤M_B/eg。G与B是同一终端Zg的不交划分，因此

    R_L*+R_HL≤(M_G+M_B)/eg=∫Zg Hν/eg≤LQJ/(p eg).

统一作一次外积分后有

    2Λ(P_rem−N_avail)
      ≤2Λ(P_HH−N_avail)+16Λ L/(3K) WA.                  (TC4)

取L=K sqrt n，已付联合片为(16Λ/3)sqrt n WA。R212旧付款不能再额外重复记一次；TC4中的共同来源费用已经包含它。相比先各自放大成M的32Λ价格，这保留了原good/bad的来源不交性，以同一预算覆盖两端至少一低的更大域。此前已付正子集继续删除。负余额没有用于TC3，完整只留P_HH一次。

两端高不是充分证明：原终端good/bad按Q*划分而不是J，不能将HH门直接推成相同score，或将其输入来源独立化。一般上界尚未闭合。

## 3. 连续截断势的可用内部交互价

为辅助真实signed估计，令G终端固定，A_t=G∩{w_t>H}、C_t=G\A_t，

    C_H(t)=e_t^-1∫G min(w_t,H)ν,
    B_low(t)=∫C_t k_t dΠ_t,    M_G=∫G Hν.

分子≤M_G，TC1立即给∫C_H kbar≤M_G/eg。另一方面逐源R212截断FTC给∫B_low≤M_G/eg。逐时

    ∫A×C |kv−ku|dΠ²
      ≤Π(C)∫A kv dΠ+Π(A)∫C ku dΠ
      ≤C_H kbar+B_low.

故其时间积分≤2M_G/eg。若只需危害方向(k_u−k_v)+，直接≤B_low，费用可降至M_G/eg。这些费用经TC3同一外积分变成相应的L来源价，无额外n因子。

它支付跨阈值的终端内部交互；不自动支付A×Et、F_H的初始端点或旧suffix信用。F_H=e^-1∫G(w−H)+ν的完整精确账由辅助稿保留。不能把这些已付正项又作可消费negative。

## 4. 证明/计算状态

本稿给出自含解析论证，最终独立审核范围与版本绑定见audit.md。数值由本机Fraction脚本另核clock导数、删源跳跃、帽交叉连续性及两腿低比值正上界。有限参数证书不认证原FULL空间/history。原一般目标及HH带原负余额的receiver/source预算仍开放。
