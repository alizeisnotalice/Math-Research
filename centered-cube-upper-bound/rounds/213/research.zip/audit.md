# R213 independent premise checkpoint

## 1. Order and actual target

Read `task_contract.md` before any new R213 author manuscript. This checkpoint derives the stated capped potential and screens the subsequently supplied accurate candidates independently. Only this file is edited. No Git, PDF compilation, agent spawning or numerical execution is performed; no old history is reread without a specific current-source need.

The target C(nK/L)W_A+epsilon X for the original high-ratio signed remainder is a proposed theorem, not an inherited bound. The original complete RT1 measure, actual remaining far domain, two posterior slots, hard source, history, receiver selector and all still-available negative credit remain fixed. R212's paid target-low piece is not paid again as a new independent piece. The threshold L is common and preselected; distinguish it from the physical receiver-kernel scale.

Use a finite actual legal window and write s=log t, w'_s=-k_t w_t, e_t=int_Zt w_t dnu>0, Pi_t=1_Zt w_t nu/e_t and m_t=E_Pi k_t. Z_t only deletes, and e_t>=e_g>0. G,B are fixed terminal surviving sets and E_t=Z_t\\Z_g. The score mean m_t uses every actual live source, including E_t; no sign or ordering of good/bad scores is assumed.

## 2. Exact capped-surplus potential: clock, covariance and internal terms

Freeze H_v=L J_v/p_y in auxiliary time, with p_y>0 and the original fixed-window J. Let

    A_t=G intersect {w_t>H},  C_t=G\\A_t,
    N_t=int_G(w_t-H)_+dnu,  F_t=N_t/e_t,
    c_t=int_A H dnu/e_t.

At a time with no deletion,

    N'_s=-int_A k_t w_t dnu,
    -F'_s=E_Pi[1_A k_t]-m_t F_t
       =Cov_Pi(1_A,k_t)+c_t m_t.

This is also obtained from the source payoff f_t=1_G(1-H/w_t)_+: F=E_Pi f and

    -F'_s=Cov_Pi(f,k_t)+E_Pi[1_A k_t H/w_t].

These are equivalent formulas with different covariance test functions. One cannot use the indicator covariance while omitting c_t m_t, or use the surplus payoff covariance and forget its own time derivative. The indicator covariance splits exactly into A cross B, A cross C and A cross E_t. The within-A term cancels, but both internal cross terms remain signed and cannot be discarded by calling the potential continuous.

The numerator is continuous at a cap crossing because the departing payoff is zero. Physical score-threshold crossings likewise leave w and F continuous. They can change one-sided derivatives but create no new potential atom. For merely measurable original positive gates, keep finite/algebraic exchanges or the genuine integrability assumptions; no BV of those gates is granted here.

If H is actually changed during auxiliary time, the continuous numerator derivative additionally contains -int_A dH dnu; simultaneous jumps require the full positive-part finite difference. The frozen original-row formula does not authorize such changes of physical parameters, alpha, support or selector.

## 3. Deletion and the genuine entrance cost

Only E_t is deleted, so the terminal-G numerator has no removal jump. If a deleted batch has pre-deletion posterior fraction d, then

    F_plus=F_minus/(1-d),
    Delta F=F_minus d/(1-d)>=0.

For continuous deletion mass dLambda, dF_del=F dLambda/e>=0; AC, singular-continuous and jump parts must all be kept with consistent endpoint states. Threshold and deletion updates at one time do not turn this jump into an original N_del time atom. Positive e_g prevents complete death on a legal nonzero row.

The initial plus positive deletion contribution has the valid bound

    F_l+int dF_del<=N_l/e_g,

because N_t<=N_l and reciprocal e has nonnegative total variation. Here N_l is the actual clipped initial numerator int_G(w_l-H)_+dnu. It is not automatically a J-source cost or an epsilon row fee. A unit bound on F is only a receiver-type row bound; no C(nK/L) source theorem follows from it. For a gated or rho0-weighted source potential, retain its true within-good covariance and any test exchanges as well.

## 4. Complementary capped mass and a finite internal budget

The parent supplied the complementary potential before an author proof. Put

    V_t=int_G min(w_t,H)dnu/e_t,
    M_G=int_G H dnu,
    B_low(t)=int_C k_t dPi_t.

Its clock identity is V'_s=V_t m_t-B_low(t), with a nonnegative deletion contribution. The sharper useful bound does not require estimating V_t itself by its endpoint identity:

    int V_t m_t ds
      <=M_G int d(1/e_t)_clock
      <=M_G(1/e_r-1/e_l)<=M_G/e_g.

Indeed d(1/e)_clock=(m_t/e_t)ds and all deletion contributions to 1/e are nonnegative. Separately the R212 clipped clock loss yields int B_low ds<=M_G/e_g.

For the actual A cross C traffic,

    int_AxC(k_v-k_u)_+dPi^2<=Pi(C)int_A k_vdPi<=V_t m_t,
    int_AxC(k_u-k_v)_+dPi^2<=B_low(t).

Thus each integrated direction is at most M_G/e_g and the absolute traffic is at most 2M_G/e_g. This verifies the parent's improved constant two, not the earlier weaker constant three. It pays this particular cross-threshold internal term. It does not control A cross E_t, the actual entrance numerator, suffix leakage or the original full high-ratio signed remainder.

## 5. Direct two-leg low-likelihood positive budget

The parent then supplied a stronger accurate candidate. Define the cap over the full original nu,

    H_v=LJ_v/p_y,  M=int H_vdnu=L Q_J/p_y.

At every actual t,

    Pi_t(B intersect {w_t<=H})<=M/e_t.

For the original remaining positive traffic with target high p_y w_t(v)>LJ_v and bad source low p_y w_t(u)<=LJ_u, all original positive weights are at most one. D^+<=k_t(v), and the target posterior mean is at most the full m_t. Hence

    R_high,low<=M int_far m_t/e_t dlog t
       <=M int d(1/e_t)_clock
       <=M(1/e_r-1/e_l)<=M/e_g.

The derivative uses the original complete posterior. Both normalization factors have been retained before the one-leg cap and full mean estimate. e_t may depend on the actual receiver/source row; no independence is used. A time domain with holes is only positively enlarged. Deletion contributes positively to reciprocal e and therefore cannot invalidate this upper bound; none of those jumps is identified with a dt negative credit.

Multiplying the same original p_y outside factor, using one hard 16/3 cap, then the original high/current column int beta/e_g<=1/(2K), and preserving unique j until the fixed-window J column is formed gives

    2Lambda P_high,low<=16Lambda L/(3K) W_nu
       <=16Lambda L/(3K) W_A.

The latter common-parent source estimate applies to the same original construction; independent windows retain their own source budgets and coefficients. No source count, time length, j menu or receiver envelope has been erased. Zero p, empty far or zero-source objects are dispatched before H or e ratios.

This piece is disjoint from R212's target-low piece, whose bound is the same 16Lambda L/(3K)W_A. The initial screen therefore gave the safe but subsequently improved union price 32Lambda L/(3K)W_A by separately enlarging each source set to all nu. Section 7 below retains the actual source labels before combining and replaces that factor two. The second piece does not require a terminal-good bound on the bad source or rho0's particular support; it uses only the actual positive weights bounded by one.

## 6. Exact remaining signed domain and acceptance boundary

The two paid positive pieces are target-low, and target-high with bad-low. Their strict complement is both p_y w_t(v)>LJ_v and p_y w_t(u)>LJ_u, on the same original remaining domain and all original gates. All still-available original negative credit stays with this both-high complement once. No negative credit was used to prove either positive budget, and previously paid positives or consumed negatives are not restored.

The direct two-leg budget is a concrete payment and stronger localization of the unproved domain. It does not prove the proposed C(nK/L)W_A+epsilon X bound for that remaining signed domain, construct a new FULL nonempty-coverage example, pay near/other untouched blocks or close the general weak-type target. The capped potential is an exact interface, not a substitute for those missing entrance/internal/suffix/source budgets.

Checkpoint status: the definitions, both equivalent F identities, deletion formulas, internal two-direction budget and new direct high-low source payment were screened independently before reading any R213 author proof. No new R213 manuscript or numerical code has yet been reviewed. Await the promised complete proofs and evidence before full audit or byte binding; no independent counterexample search or competing strong-conjecture project is started.

## 7. Final common-source union refinement, screened before its proof

The auxiliary author and parent then supplied a stronger source accounting candidate. Retain terminal labels in the two bounds:

    M_G=int_G H dnu,  M_B=int_B H dnu,
    R_target-low<=M_G/e_g,
    R_target-high,bad-low<=M_B/e_g.

The second inequality uses Pi_t(B intersect low)<=M_B/e_t, followed by the same complete reciprocal-normalizer clock integral. Since G disjoint-union B=Z_g on this actual row,

    R_union<=(M_G+M_B)/e_g
       =int_Zg H dnu/e_g<=LQ_J/(p_y e_g).

Only after this row-level sum may one enlarge to the full nu and use the shared high/J column. G,B may depend on x,y: their dependence is not removed or normalized separately before this exact disjoint sum. This yields the final positive source price

    2Lambda P_union<=16Lambda L/(3K) W_nu
       <=16Lambda L/(3K) W_A.

At the common choice L=K sqrt(n), the union price is (16Lambda/3)sqrt(n)W_A. This is a replacement of the earlier factor-two upper bound, not another allowance for R212's already identified target-low piece. It requires the same preselected L, same window, same original remaining domain and same terminal source partition. Independent windows still use their actual separate source accounts. The constant is verified for this source certificate; optimality across all physical inputs is not asserted.

The unpaid signed complement is still both-high with the original negative balance once. Neither the final union refinement nor the internally paid A cross C terms proves C(nK/L)W_A+epsilon X for that complement. The accurate candidate has been screened before either new author proof; full manuscripts and numerical evidence remain for the next review stage.

## 8. Full manuscript and evidence review

Read `capped_potential.md` in full after the independent screens. CP1--22 correctly distinguishes indicator and fractional payoff covariances, keeps c_H*kbar, all A-cross-C/A-cross-E terms and genuine deletion normalization, and uses the complete full-source mean. One necessary scope clarification was requested and completed: CP12's prime is its clock density, not the total a.e. derivative when AC deletion is present; integration uses CP10 with all continuous and atomic deletion contributions. CP11 now explicitly requires the displayed negative portions still be available and adds any other consumed difference back. These are interpretation guards, not an altered formula or a new negative allowance. The final 246-line version was reread at those clauses and passes.

Read the complete `two_ended_cap.md` and 149-line `proof.tex.txt`. Their shared-source proof matches section 7: retain M_G and M_B until the actual row-level sum, then enlarge terminal Z_g to the original full nu. One hard cap, the actual high/current column, unique j and fixed-window J normalization give the stated 16Lambda L/(3K)W_nu. With L=K sqrt(n) the joint union has (16Lambda/3)sqrt(n)W_A price. It includes R212's target-low allowance rather than adding another one. All negative credit is assigned only to the strict both-high complement. Independent windows retain their actual separate common-parent source accounts. The reciprocal-e argument includes AC, singular-continuous and jump deletion and does not turn deletion into a dt negative atom. No necessary correction remains in the primary proof.

Read all of `early_signed_geometry.md` after its exact support candidates were screened. ES5--9's normalization H0^n T=a_s^n, exact K0/T, strict eta_eff condition and the actual alpha0/J term are correct. The eta=1 case retains strict rho0>0. Closed-core exclusion requires D(H0/Hhat)^n>=1; the manuscript now explicitly retains that condition when removing pure all-hard current terms. Lower clamping does not automatically satisfy it, and the displayed lower-clamp necessary condition keeps the J term. The outer log-density decomposition retains the internal gain and hard jump, and the tail-slope proof is self-contained: exponential-mixture slopes decrease only away from the boundary, whose first moments are separately integrable; no finite boundary variance is assumed. The deep-core inequality and all lower-clamp signs are correct. These statements constrain actual support but do not pay its original receiver/source probability, the bad source or the both-high signed traffic. No new source budget is certified from this geometry alone.

Read the complete 169-line `capped_potential_checks.py`, JSON and final notes. The nine conditional models, 27 ordinary probes and 14 crossing checks use complete source normalization. Direct quotient derivatives agree with the separately enumerated ordered covariance and its three signed cross terms, with c*kbar retained. Deletion recomputes the actual denominator, cap crossings have zero payoff jumps, and the complete reciprocal clock ledger separates continuous FTC segments from its positive E deletion jump. The extra two-source n=2 integral is an exact rational primitive 1/18, not time-grid quadrature. The final M_G/M_B/M_E supplementation checks disjoint source numerators and the sharper bad-low posterior bound without adding a new physical model or claiming that the original joint spatial integral was simulated. The JSON counts and local contract hash were statically inspected and match the delivered evidence. No numerical script was run by this auditor.

Read the complete final report and reproduction driver. They accurately distinguish the newly paid union, the auxiliary internal budget and the unpriced spatial support. Numerical finite-model and FULL limitations match the notes. The driver validates its manifest's digest syntax/path containment, refuses reference overwrites, runs a relocated script plus contract, compares the entire JSON and rechecks package hashes. Its final execution is the parent's subsequent step, not a result certified by this audit. There is no PDF compilation claim.

## 9. Final conclusion and SHA256 bindings

Accepted result: within the original remaining far positive domain, the two disjoint pieces target-low and target-high/bad-low jointly cost at most 16Lambda L/(3K)W_nu<=16Lambda L/(3K)W_A, with the same original source account. At L=K sqrt(n) this is root order. No negative credit is used for this positive source estimate. The actual both-high signed complement, its entrance/active-E/suffix/source geometry and original untouched blocks remain open; the proposed C(nK/L)W_A+epsilon X estimate and the general weak-type goal are not proved. No strict new FULL nonempty-coverage example or global optimality of the source constant is asserted.

The following ten files are bound to actual final bytes. This audit and the future manifest are excluded to avoid a hash cycle.

| File | SHA256 |
|---|---|
| `capped_potential.md` | `47ffb8ec9317620416b39ff305783f04d82b1bd212fff1dc6484512bb6d62b88` |
| `capped_potential_checks.json` | `60caa4cf90ceba3e07eac64d3c910a0cea625b4cf83dab6273eab3763381d551` |
| `capped_potential_checks.py` | `8c1a748ca0d27f3bfeaa39cb94df49d2f5c60aca84dc961e7d58be7e4006a3e2` |
| `early_signed_geometry.md` | `56ad059d098abe45e80d3b3ec97d2d4f1da0ac9af4c5f7dd1d086c54fddebb58` |
| `numeric_notes.md` | `6f248d35ba4385afc808da39e0f9ea50bbe986f4836bea504f30150bd3788bfb` |
| `proof.tex.txt` | `d8252508fe8593297ee640deb0d9907539d69f606502329080ff7897fc926969` |
| `report.md` | `a8149b069ada2f7c13f5309f777142b2d8b5844fadadfe0c756ff1fa483439b9` |
| `reproduce.py` | `954199a0193158f0140e43f95e3c67cd0211213ba9b7753198ba6ebe7c14f685` |
| `task_contract.md` | `6707ca2b977e8e291a520bccaa993463273f8200223f9e1e740c4ef00930d8e2` |
| `two_ended_cap.md` | `dfb4a849f4e451a0469074cce4a07acb61e4d20202d8e99e34f7b32a018f7b2d` |

Final status: accepted in exactly the above scope and frozen for parent archiving. Only audit.md was modified. This auditor did not run the numeric script or parent driver, compile a PDF, use Git or spawn an agent. Manifest generation, complete migrated reproduction, archive and commit status remain subsequent parent work.
