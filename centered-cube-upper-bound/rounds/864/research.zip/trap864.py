"""Certified many-group periodic obstruction for a calibrated physical cube."""

from fractions import Fraction as F
from itertools import product
from math import comb, factorial
from sys import version

from flint import __version__ as flint_version
from flint import arb, ctx

ctx.prec = 320
LOG2 = arb(2).log()
PI = arb.pi()


def fmt(value):
    return value.str(9)


def audit_small_fourier():
    """Exact orbit moments for cos of summed quarter-period phases."""
    cosine = (1,0,-1,0)
    for d in (2,3):
        phases = tuple(product(range(4),repeat=d))
        raw = [cosine[sum(s)%4] for s in phases]
        tilt = [1+F(x,2) for x in raw]
        assert sum(raw) == 0
        assert sum(x*x for x in raw)/F(len(raw)) == F(1,2)
        assert sum(tilt) == len(phases)
        assert sum(x*w for x,w in zip(raw,tilt))/len(phases) == F(1,4)
        for axis in range(d):
            for value in range(4):
                assert sum(w for s,w in zip(phases,tilt) if s[axis]==value) == F(len(phases),4)
    print("Quarter-period Fourier audit d=2,3 confirms Haar mean 0, variance 1/2, tilted mean 1/4 and uniform single-axis marginals.")
    print("The same moments are exact for continuous Haar on integer-period intervals by Fourier orthogonality.")


def audit_exterior_formula():
    # n=2: two axis choices of signed rectangular strips, plus four triangles.
    for a in (F(1,4), F(2), F(7,5)):
        shell = [F(comb(2,j),factorial(j))*a**j for j in range(3)]
        assert shell == [1,2*a,a*a/2]
        assert 4*sum(shell) == 4+8*a+2*a*a
    print("The exact j-face volume relative to the original cube is binom(n,j)*a^j/j!, where a is the L1 radius.")


def exercise(k,multiplier):
    n = 2**(12*k)
    groups = 2**(8*k)
    axes = 2**(3*k)
    frequency = 2**(6*k)
    assert groups*axes == n//2**k and frequency**2 == n
    assert groups%32 == 0
    log_n = arb(n+2).log()
    move = multiplier*log_n
    j0 = groups//32

    # Disjoint groups make the phase functional 2*pi/h Lipschitz in L1.
    displacement_ratio = 2*PI*frequency*move/(groups//16)
    movement_ok = displacement_ratio<=1

    # Haar on every untouched full group has independent zero-mean cosines.
    # At most j groups are spoiled by a j-face cell; when j<=m/32 the
    # remaining groups must contribute at least m/32 in T'.
    minkowski_log = 2*(arb(n)*move).sqrt()
    main_log = minkowski_log-arb(groups)/2048
    # The count-times-simplex formula and j! >= (j/e)^j give rho^j.
    rho = arb(2).exp()*n*move/j0**2
    print(f"  k={k}, n=2^{12*k}, m=2^{8*k}, d=2^{3*k}, h=2^-{6*k}, md/n=2^-{k}")
    print(f"    displacement/(m/16) {fmt(displacement_ratio)}, T to T' {'certified' if movement_ok else 'unproved here'}")
    print(f"    Minkowski log-volume upper/m {fmt(minkowski_log/groups)}, low-face log upper/m {fmt(main_log/groups)}")
    print(f"    high-face geometric ratio rho {fmt(rho)}")
    if not rho<1:
        assert not movement_ok
        print("    The geometric tail test gives no decay certificate for this scale.")
        return movement_ok,False
    tail_log=(j0+1)*rho.log()-(-rho).log1p()
    land_log=main_log.max(tail_log)+LOG2
    volume_ok=land_log<0
    print(f"    high-face log upper/m {fmt(tail_log/groups)}, combined territory log upper/m {fmt(land_log/groups)}")
    if movement_ok:
        # One marginal alone suffices for the obstruction with a fixed cap n^B.
        # Set B to the listed displacement multiplier for this numerical test.
        complement_log=-arb(groups)/128
        cap_log=multiplier*arb(n).log()
        payable_log=complement_log.max(cap_log+land_log)+LOG2
        assert payable_log < -arb(groups)/4096
        print(f"    cap n^{multiplier}: log of payable source fraction / m <= {fmt(payable_log/groups)}")
    return movement_ok,volume_ok


if __name__ == "__main__":
    print(f"Python {version.split()[0]}, python-flint {flint_version}, Arb {ctx.prec} bits plus exact rational identities.")
    print("R=1, physical parent [-1,1]^n, compact input on [-2,2]^n, carrier period h=1/sqrt(n).")
    print("f is the product of 1+(1/2)cos over disjoint groups. Both boxes have exact mean f=1.")
    print("In particular integral over the parent equals its actual Lebesgue volume.")
    print("T uses sum cos>=m/8, T' uses sum cos>=m/16. Hoeffding log upper/m:")
    print(f"  tilted source outside T: {-F(1,128)}, parent Lebesgue of T': {-F(1,512)}, untouched-group upper: {-F(1,2048)}")
    audit_small_fourier()
    audit_exterior_formula()
    print("a=A*log(n+2). Bounds are logged before exponentiation and relative to the original physical parent.")
    for a in (1,2**16):
        print(f"DISPLACEMENT MULTIPLIER A={a}")
        results={k:exercise(k,a) for k in (2,4,10,12,15,30)}
        assert results[2]==results[4]==(False,False)
        assert results[15]==results[30]==(True,True)
        if a==1:
            assert results[10]==(True,True)
        else:
            assert results[10]==(False,False) and results[12]==(False,True)
    print("Only the mass of this real single-parent periodic family was priced. There is no full historical realization.")
