"""Exact finite stripe stocks and certified real Lebesgue face tails."""

from fractions import Fraction as F
from sys import version

from flint import __version__ as flint_version
from flint import arb, ctx

ctx.prec = 320
A0 = F(1, 2**96)
R = F(1, 2)
ACTIVE_LENGTH = F(8)
TAU_GEOM = F(2)
LOG2 = arb(2).log()


def ball(value):
    return arb(value.numerator)/value.denominator


def fmt(value):
    return value.str(9)


def ceil_fraction(value):
    return -((-value.numerator)//value.denominator)


def stripe_area(x,width,ramp):
    """Mass of the height-one continuous trapezoid between 0 and x."""
    if x<=ramp:
        return x*x/(2*ramp)
    if x<=width-ramp:
        return x-ramp/2
    if x<=width:
        return width-ramp-(width-x)**2/(2*ramp)
    return width-ramp


def primitive(t,period,width,ramp):
    """Integral of the periodic stripe profile from 0 to t."""
    cells=t//period
    return cells*(width-ramp)+stripe_area(t-cells*period,width,ramp)


def mass_in_stripes(a,b,period,width,ramp):
    return primitive(b,period,width,ramp)-primitive(a,period,width,ramp) if b>a else F(0)


def finite_density(x,period,width,ramp):
    lo,hi=max(F(0),x-period/2),min(ACTIVE_LENGTH,x+period/2)
    return mass_in_stripes(lo,hi,period,width,ramp)/(width-ramp)


def integrate_quadratics(fun,grid):
    return sum((hi-lo)*(fun(lo)+4*fun((lo+hi)/2)+fun(hi))/6
               for lo,hi in zip(grid,grid[1:]))


def small_exact_audit(period,width,ramp):
    # The finite convolution is continuous and piecewise quadratic. Enumerate
    # the true knots only in the prototype; the same formula covers all scales.
    cells=int(ACTIVE_LENGTH/period)
    knots=(0,ramp,width-ramp,width)
    support_edges={period*j+end for j in range(cells) for end in knots}
    shifted_edges={end+sign*period/2 for end in support_edges for sign in (-1,1)}
    grid=sorted(shifted_edges|{F(0),ACTIVE_LENGTH})
    fn=lambda x: finite_density(x,period,width,ramp)
    assert max(map(fn,grid))==1
    assert integrate_quadratics(fn,grid)==ACTIVE_LENGTH
    inside=[x for x in grid if 0<=x<=ACTIVE_LENGTH]
    assert ACTIVE_LENGTH-integrate_quadratics(fn,inside)==(period-width)/2


def grid_centers_in(a,b,offset,g):
    """Half-open interval center count for the exact translated old-parent grid."""
    return ceil_fraction((b-offset)/g)-ceil_fraction((a-offset)/g)


def actual_parent_audit(n,period,width,ramp,density):
    # A_i has half-side R=1/2 and A_t has half-side 3/4, both within [R,2R).
    # Both lower active faces are b, halfway through the stripe at 2.
    b = 2+width/2
    g = F(1,64*n)
    edge_center = b+R
    for axis_len,offset,z in ((ACTIVE_LENGTH,edge_center,b+F(1,3)),
                              (64*n,F(2),F(33,16))):
        assert 1<=z<=axis_len-1
        assert R+ramp<=z-R and z+R<=axis_len-R-ramp
        assert grid_centers_in(z-R,z+R,offset,g)*g == 1
    assert grid_centers_in(b,b+1,edge_center,g)*g == 1
    # On each axis length 1 is an integer number of old lattice steps. The
    # receivers retain the central half of their grid interval on axis 3.
    assert 1/g == 64*n and g/2 <= R/(32*n)
    assert g/2 < F(1,4)  # moving A_t's third center preserves A_i subset A_t
    assert g/16 < g/4    # E_t can lie in the gaps between old E_i
    assert 0<b and b+F(3,2)<ACTIVE_LENGTH
    assert density*mass_in_stripes(b,b+1,period,width,ramp)==1
    assert density*mass_in_stripes(b,b+F(3,2),period,width,ramp)==F(3,2)
    # A test center can be displaced within its actual E_i. The side-one
    # window loses at most density*g/2 in the active direction, and at most
    # g/2 of length in every transverse direction. Every side <=2 sees
    # at most one block and has average <=1+P from the periodic primitive.
    assert (1-density*g/2)*(1-(n-1)*g/2)>F(3,4)
    assert 1+period<F(3,2)
    return g


def stripe_exercise(label,n,period,r,tau,formal,p=None):
    width=period/(8*tau)
    ramp=r/16
    density=period/(width-ramp)
    assert 0<ramp<r<width/2
    trans = F(64*n)
    assert int(ACTIVE_LENGTH/period)*period == ACTIVE_LENGTH
    assert int(width/r)*r == width and int(period/r)*r == period
    assert int(1/r)*r == 1 and int(trans/r)*r == trans
    assert 0 < r < width < period/2 and width+2*r<period
    assert density*(width-ramp)==period
    g = actual_parent_audit(n,period,width,ramp,density)
    ln_n = arb(n+2).log()
    cap = ball(A0*R)*ln_n
    cost_ratio = ball(period/2)/cap
    if formal:
        assert n==2**p and p%24==0
        assert r==R*F(1,2**(5*p//6)) and tau==2**(p//8)
        assert 0<cost_ratio<=1 and cap<ball(R)
    else:
        assert cost_ratio>1
        small_exact_audit(period,width,ramp)

    # The deep rectangle uses margin 1+P/2. All active endpoints align
    # with old grid faces and its length is an integer number of stripe periods.
    # The inactive coordinates have a continuous linear taper of width ramp
    # at each finite outer face. There is no taper in this deep rectangle.
    assert (period/2)%r==0 and (1+period/2)>1+ramp
    active_deep=6-period
    inactive_deep=trans-2-period
    assert active_deep%period==0
    theta_bulk=2*tau/density
    theta_edge=theta_bulk/(1-ramp/(2*r))
    assert theta_bulk< F(1,4)<theta_edge<F(1,3)
    retained_total=2*tau*width/period
    assert retained_total==F(1,4)
    interior_fraction_floor=active_deep/ACTIVE_LENGTH*(1-F((2+period)*(n-1),trans))
    assert interior_fraction_floor>F(7,10)
    transverse_expansion=(ball(2*r/inactive_deep).log1p()*(n-1)).exp()
    arbitrary_short=ball(2*tau*(width+2*r)/period)*transverse_expansion
    assert ball(retained_total)<arbitrary_short<arb("0.27")

    # The two blocks are separated on axis 3. On each block the correct
    # sign mixture spreads a source uniformly through a physical period.
    # A single fixed active direction leaves one block's stripes intact.
    taper_factor=((-ball(ramp/trans)).log1p()*(-(n-1))).exp()
    raw_fixed_axis=ball(TAU_GEOM*width/period*(1+2*R/trans))*taper_factor
    assert raw_fixed_axis<arb("0.25")
    assert finite_density(period,period,width,ramp)==1
    assert finite_density(-period/2,period,width,ramp)==0
    assert finite_density(ACTIVE_LENGTH,period,width,ramp)==0
    assert TAU_GEOM-1==1

    # The first stripe is the only source whose image may leave the finite block.
    marginal_leak=(period-width)/(2*ACTIVE_LENGTH)
    either_slot_leak=3*(period-width)/(4*ACTIVE_LENGTH)
    assert either_slot_leak==F(3,2)*marginal_leak
    # In the right half of the true continuous stripe, integrate powers of
    # the distance from its midpoint. The triangular missing piece is explicit.
    half=width/2
    half_area=(width-ramp)/2
    edist=(half**2/2-half*ramp/2+ramp**2/6)/half_area
    edist2=(half**3/3-half**2*ramp/2+half*ramp**2/3-ramp**3/12)/half_area
    # A common U and independent signs on the actual lower edge give 1/4+3E[d]/(2P).
    edge_pair=F(1,4)+3*edist/(2*period)
    independent_amp=F(1,4)+edist/period+edist2/period**2
    assert F(1,4)<independent_amp<edge_pair
    # In all of A_i the upper face restricts only the small-parent slot.
    # The two partial stripes have mass P/2 and the same distance distribution.
    full_pair=1-5*period/8+5*edist/4
    assert full_pair>1-period
    raw_source_edge=density*half_area
    assert raw_source_edge==period/2

    dim = f"2^{p}" if formal else str(n)
    print(f"{label} n={dim}, physical radius window [1/2,1), period={period}, raw peak density {fmt(ball(density))}")
    print(f"  actual old centers step {g}, j_i/|E_i|=1, m_i=1, and k_O=1/2 on the deep source crop")
    print(f"  deep crop mass fraction >7/10 in each finite block. All occupied old cells are overloaded.")
    print(f"  old aligned bulk/edge theta {fmt(ball(theta_bulk))} / {fmt(ball(theta_edge))}, total retained={retained_total}")
    print(f"  arbitrary short displacement with same old cap pays <= {fmt(arbitrary_short)} of deep weighted mass")
    print(f"  max u/(a0 R log(n+2)) = {fmt(cost_ratio)}. Target budget {'passes' if formal else 'fails in this rescaled prototype'}.")
    print("  pooled output densities <=1 for raw source and <=1/2 for k_O-weighted source. Target geometric cap is 2.")
    print(f"  if one axis is fixed globally, retained raw fraction in the other block <= {fmt(raw_fixed_axis)}")
    print(f"  finite truncation leakage, one slot {fmt(ball(marginal_leak))}, either slot {fmt(ball(either_slot_leak))}")
    print(f"  actual edge packet joint hit {fmt(ball(edge_pair))}, using independent amplitudes {fmt(ball(independent_amp))}")
    print(f"  exact shared-amplitude hit advantage {fmt(ball(edge_pair-independent_amp))}")
    print(f"  full true A_i intersection hit loss {fmt(ball(1-full_pair))}; edge packet source mass (P/2)*4^(-(n-1))")
    return ln_n


def binomial_tail(trials, p, need):
    """True binomial tail with a geometric remainder on the decreasing terms."""
    if need<=0:
        return arb(1)
    if need>trials:
        return arb(0)
    p_ball=ball(p)
    q=p_ball/(1-p_ball)
    term=((-p_ball).log1p()*trials).exp()
    for j in range(1,need+1):
        term *= (trials-j+1)*q/j
    acc=term
    last=min(trials,need+80)
    for j in range(need+1,last+1):
        term *= (trials-j+1)*q/j
        acc += term
    if last<trials:
        ratio=(trials-last)*q/(last+1)
        assert 0<ratio<1
        geometric=term*ratio/(1-ratio)
        acc=acc.union(acc+geometric)
    return acc


def ceiling_rank(log_n):
    value=(log_n/8).ceil().unique_fmpz()
    assert value is not None
    return int(value)


def chernoff_rate(log_n,k):
    mean=2+ball(A0)*log_n
    return (1+(mean/k).log())/LOG2


def face_tails(n,period,log_n,formal):
    k=ceiling_rank(log_n)
    p0=F(2,n)
    p1=min(F(1),p0+period/(2*R))
    assert 0<p0<p1<1
    actual=(1-ball(p1))*binomial_tail(n-1,p0,k)+ball(p1)*binomial_tail(n-1,p0,k-1)
    assert 0<actual<1
    log2_actual=actual.log()/LOG2
    if not formal:
        assert actual.contains(ball(F(61,64)))
    rate=chernoff_rate(log_n,k)
    if formal:
        assert ball(2-p0+p1)<=2+ball(A0)*log_n
        assert log2_actual<k*rate
    print(f"  Lebesgue face count k={k}, actual log2(tail) {fmt(log2_actual)}")
    if formal:
        both_ok = 1+k*rate <= -2*k
        print(f"  formal log2(Chernoff)/k {fmt(rate)}. Two-parent union <=4^-k: {'yes' if both_ok else 'no'}.")
    else:
        print("  finite prototype uses its own amplitude budget; no claim for the target asymptotic tail bound.")


def symbolic_tail():
    p=2**110
    base=p*LOG2
    # log(2^p+2)-p log 2 lies in [0,2^(1-p)] ⊂ [0,2^-256].
    log_n=base.union(base+arb(2)**-256)
    k=ceiling_rank(log_n)
    mean=2+ball(A0)*log_n
    rate=chernoff_rate(log_n,k)
    limiting=(1+(8*ball(A0)).log())/LOG2
    assert mean>1000 and 1+k*rate<-2*k
    print(f"SYMBOLIC HEIGHT log2(n)=2^110, true log(n+2) enclosed without building n, k={k}")
    print(f"  mean bound {fmt(mean)}, log2(Chernoff)/k {fmt(rate)}, limiting rate {fmt(limiting)}")
    print("  Even the two-parent union bound is <=4^-k. No finite-binomial summation is used here.")


if __name__=="__main__":
    print(f"Python {version.split()[0]}, python-flint {flint_version}, exact geometry and Arb {ctx.prec} bits.")
    print("Two disjoint finite blocks: active coordinate 1 in the first and 2 in the second, separated on coordinate 3.")
    print("The finite positive L1 stripes have linear ramps and continuous inactive-coordinate cutoff.")
    print("A true source is positive in an interior stripe. The density is continuous across the exterior boundary.")
    print("The true old parents use the finite lattice of side-one cubes inside each block. Their actual E_i are disjoint half-cells.")
    print("G_i=A_i intersect the common true source Y_O. All old parents have physical mass 1 and the actual height band uses lambda=3/4.")
    print("A true source chooses its block coordinate and one U uniform on [0,P/2], then uses two independent signs and the same U.")
    print("The same output-density cap holds on the mixture of both blocks, including leaked boundary mass.")
    print("The active-axis shell uses p1=2/n+P/(2R), others 2/n, for uniform Lebesgue in the true cube.")
    print("Formal scales use r=R n^(-5/6), tau=n^(1/8), k=ceil(log(n+2)/8), and a0=2^-96.")
    print("This is a physical one-window and one-source-signature test, with no R813 full history imposed.")
    n=4
    period=F(1,8)
    ln_n=stripe_exercise("INITIAL RESCALED",n,period,F(1,4096),F(2),False)
    face_tails(n,period,ln_n,False)
    for label,p,period_power in (("PRESSURE",144,90),("CHECK",192,89),("EXPANDED",384,88)):
        n=2**p
        period=F(1,2**period_power)
        ln_n=stripe_exercise(label,n,period,R*F(1,2**(5*p//6)),F(2**(p//8)),True,p)
        face_tails(n,period,ln_n,True)
    symbolic_tail()
