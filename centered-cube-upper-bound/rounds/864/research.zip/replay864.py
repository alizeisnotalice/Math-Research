"""Verify the R864 release and reproduce three stdout files in separate clean directories.

The reference environment uses CPython 3.12.14, python-flint 0.9.0, NumPy 2.5.4, SciPy 1.18.1 and SymPy 1.14.0.
Each experiment uses the interpreter running this driver. All input paths are supplied
on the command line, so the driver's working directory may be empty.
"""
import argparse
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


# Six archives are opened by records864. R813, R857 and R862 are mathematical references.
PARENTS = {
    "813": "ea1d253254a846c58f0c3b6ed50db37f34739cb7da6e7ae5acc2cc9d979c8d2f",
    "814": "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    "856": "16496077ed6ce4e48816dfb70d93a8251885db6ff03e033a3109eaa6e2f13fbb",
    "857": "8ef43e82e2905f5f95f685eda948fbee0a5b447ae68b0866708ebc0fb448e07f",
    "858": "7224b3ca13f4f5293676e5fa520e4230369c10e0453bfee6f348b0b20edb20da",
    "859": "1e48d2b533ef52375172f5202d86fafcce52608f1d24226e99220692bd2d700a",
    "860": "2b530fd04c0f05f81e7c52cf4c644b07ce25103d96967927820f011c27c9ae39",
    "862": "c0eb21f523c96c0db91ab37cfcbaeddbaa0aa65c2e100f5cb68f84f454c3cce2",
    "863": "88a1819012871f487f3a96c308cc7e6f4d3ef5e0aeaa9ac69a12eb15adbcbffc",
}
RUNS = {
    "records864": True,
    "highdim864": False,
    "trap864": False,
}
MEMBERS = {"REPORT.tex", "README.md", "replay864.py"} | {
    f"{name}.{extension}" for name in RUNS for extension in ("py", "txt")
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return sha256(data).hexdigest()


def distinct_keys(pairs):
    fields = dict(pairs)
    require(len(fields) == len(pairs), "duplicate manifest key")
    return fields


def read_release(data):
    with ZipFile(BytesIO(data)) as archive:
        names = archive.namelist()
        require(len(names) == len(MEMBERS) + 1 and set(names) == MEMBERS | {"MANIFEST.json"},
                "unexpected, duplicate or missing archive member")
        require(archive.testzip() is None, "archive CRC mismatch")
        manifest = json.loads(archive.read("MANIFEST.json"), object_pairs_hook=distinct_keys)
        files = {name: archive.read(name) for name in MEMBERS}
    require(set(manifest) == {"round", "parents", "sha256"} and type(manifest["round"]) is int
            and manifest["round"] == 864 and manifest["parents"] == PARENTS,
            "unexpected manifest or parent hashes")
    require(manifest["sha256"] == {name: digest(content) for name, content in files.items()},
            "archive member SHA-256 mismatch")
    return files


def verify_parents(rounds):
    for number, expected in PARENTS.items():
        path = rounds / number / "research.zip"
        require(digest(path.read_bytes()) == expected, f"parent SHA-256 mismatch at {path}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rounds", required=True, type=Path)
    parser.add_argument("--work", required=True, type=Path, help="existing temporary directory, e.g. /Volumes/data/CodexTemp")
    parser.add_argument("--archive", required=True, type=Path)
    options = parser.parse_args()
    rounds = options.rounds.resolve(strict=True)
    work = options.work.resolve(strict=True)
    data = options.archive.read_bytes()
    verify_parents(rounds)
    files = read_release(data)
    require(Path(__file__).read_bytes() == files["replay864.py"], "running driver differs from archive")
    print("Python", sys.version.split()[0], "archive SHA-256", digest(data), flush=True)
    print("Nine parent archive hashes verified. The records experiment reads R814, R856, R858, R859, R860 and R863. The report also uses R813, R857 and R862. Recorded environment uses CPython 3.12.14, python-flint 0.9.0, NumPy 2.5.4, SciPy 1.18.1 and SymPy 1.14.0.", flush=True)
    env = dict(os.environ)
    for key in ("PYTHONHOME", "PYTHONPATH", "PYTHONOPTIMIZE"):
        env.pop(key, None)
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
        env[key] = "1"
    for name, needs_rounds in RUNS.items():
        script = f"{name}.py"
        with TemporaryDirectory(prefix=f"replay864-{name}-", dir=work) as tmp:
            clean = Path(tmp)
            local = clean / script
            local.write_bytes(files[script])
            command = [sys.executable, "-B", "-s", script]
            if needs_rounds:
                command.extend(["--rounds", str(rounds)])
            result = subprocess.run(command, cwd=clean, env=env, capture_output=True, timeout=180)
            require(result.returncode == 0 and not result.stderr,
                    f"{name} exit {result.returncode}, stderr {result.stderr.decode(errors='replace')}")
            expected = files[f"{name}.txt"]
            require(result.stdout == expected,
                    f"{name} stdout SHA-256 {digest(result.stdout)}, expected {digest(expected)}")
            require(list(clean.iterdir()) == [local] and local.read_bytes() == files[script],
                    f"{name} modified its script or wrote unexpected files")
        require(not clean.exists(), f"temporary directory survived for {name}")
        print(f"{name} exited 0 and matched all {len(expected)} stdout bytes", flush=True)
    verify_parents(rounds)
    print("Three exact stdout matches. All subprocesses exited and all temporary directories were removed.")


if __name__ == "__main__":
    main()
