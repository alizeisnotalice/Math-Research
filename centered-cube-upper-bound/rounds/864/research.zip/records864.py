"""R864: true-source common displacement shapes, two independent sign draws."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from math import prod
from pathlib import Path
from zipfile import ZipFile
import json
import sys

PIN863="88a1819012871f487f3a96c308cc7e6f4d3ef5e0aeaa9ac69a12eb15adbcbffc"
AMPLITUDES=(F(1,2048),F(1,32),F(1,8))


def load(rounds):
    archive=rounds/"863"/"research.zip"
    assert sha256(archive.read_bytes()).hexdigest()==PIN863
    with ZipFile(archive) as z:
        manifest=json.loads(z.read("MANIFEST.json"))["sha256"]
        def execute(name):
            code=z.read(name)
            assert sha256(code).hexdigest()==manifest[name]
            ns={"__name__":"records864_archive","__file__":name}
            exec(compile(code,name,"exec"),ns)
            return ns
        actual,weighted=map(execute,("actual863.py","weighted863.py"))
    comb=actual["archive_member"](rounds,814,"comb811.py")
    public=actual["archive_member"](rounds,860,"public860.py")
    stage=comb["fixture"](*comb["FIXTURES"][-1])
    parents,src,raw,hard,fmt,pin,cut=public["load"](rounds)
    R,radii=actual["physical_octave"](parents,raw)
    assert R==1 and len(raw)==920 and len(hard)==848
    assert len(parents)==8 and sum(hard.values())==cut[2]
    assert weighted["PIN_ACTUAL"]==manifest["actual863.py"]
    return actual["Source"](comb,stage),parents,src,raw,hard,fmt,R,manifest


def translations(shape):
    return tuple(tuple(sign*a for sign,a in zip(choice,shape))
                 for choice in product(*((1,) if d==0 else (-1,1) for d in shape)))


def combine(rows,mask):
    out={mask:F(1)}
    for row in rows:
        nxt=defaultdict(F)
        for (a,x),(b,y) in product(out.items(),row.items()):
            if x and y:
                nxt[a&b]+=x*y
        out=nxt
    return out


def arms(raw):
    by=defaultdict(set)
    for t,l,r in raw:
        for i,m,j in (l,r):
            by[t,i].add(m)
    return by


def arm_hits(source,parents,src,arm_table,shape):
    """Integral over original price strata of separate-roll and same-roll gates."""
    result={}
    full=sum(p["bit"] for p in parents.values())
    for (t,i),used in sorted(arm_table.items()):
        pieces=[[],[]]
        for axis,d in enumerate(shape):
            H,I=parents[t]["box"][axis],parents[i]["box"][axis]
            lo,hi=max(H[0],I[0]),min(H[1],I[1])
            assert lo<hi
            plane={lo,hi}
            for p in parents.values():
                plane.update(v for v in p["box"][axis] if lo<v<hi)
            for box in (H,I):
                plane.update(v+s*d for v in box for s in (-1,1) if lo<v+s*d<hi)
            row=[defaultdict(F),defaultdict(F)]
            knots=sorted(plane)
            for a,b in zip(knots,knots[1:]):
                m=(a+b)/2
                bits=sum(p["bit"] for p in parents.values()
                         if p["box"][axis][0]<m<p["box"][axis][1])
                left=[H[0]<m+s*d<H[1] for s in (-1,1)]
                right=[I[0]<m+s*d<I[1] for s in (-1,1)]
                mu=source.mass(a,b)
                row[0][bits]+=mu*sum(left)*sum(right)/4
                row[1][bits]+=mu*sum(a and b for a,b in zip(left,right))/2
            for side in (0,1):
                pieces[side].append(row[side])
        vals=[combine(p,full) for p in pieces]
        for m in used:
            assert m&(parents[t]["bit"]|parents[i]["bit"])==(parents[t]["bit"]|parents[i]["bit"])
            result[t,i,m]=tuple(v.get(m,F(0))/src[m] for v in vals)
            assert all(0<=x<=1 for x in result[t,i,m])
    return result


def axis_walls(source,parents):
    marks={source.low,source.high}
    for cycle in range(source.low//source.period,source.high//source.period):
        middle=source.phase+cycle*source.period
        marks.update((middle-source.bump,middle+source.bump))
    return tuple(tuple(sorted(marks|{x for p in parents.values() for x in p["box"][j]}))
                 for j in range(source.n))


def point_mask(parents,y):
    return sum(p["bit"] for p in parents.values()
               if all(a<v<b for (a,b),v in zip(p["box"],y)))


def one_density(source,x):
    if not source.low<x<source.high:
        return F(0)
    v=x%source.period
    return source.peak if abs(v-source.phase)<source.bump else source.floor


def representatives(source,parents,walls,src):
    # Max-product representatives are inside an explicit open atom.
    full=sum(p["bit"] for p in parents.values())
    potential={full:(F(1),())}
    for j,mark in enumerate(walls):
        row={}
        for a,b in zip(mark,mark[1:]):
            x=(a+b)/2
            m=sum(p["bit"] for p in parents.values() if p["box"][j][0]<x<p["box"][j][1])
            d=one_density(source,x)
            if d>row.get(m,(F(0),None))[0]:
                row[m]=(d,x)
        nxt={}
        for (p,(a,point)),(q,(b,x)) in product(potential.items(),row.items()):
            m=p&q
            if a*b>nxt.get(m,(F(0),None))[0]:
                nxt[m]=(a*b,point+(x,))
        potential=nxt
    assert set(potential)==set(src)
    assert all(point_mask(parents,x)==m for m,(_,x) in potential.items())
    return {m:x for m,(_,x) in sorted(potential.items()) if m}


def periodic_distance(x,period):
    v=x%period
    return min(v,period-v)


def axis_max(source,d):
    distance=periodic_distance(2*d,source.period)
    if distance<2*source.bump:
        return source.peak
    return (source.peak+source.floor)/2


def mixed_density_bound(source,axial,spread,beta):
    amax=tuple(axis_max(source,d) for d in axial)
    bmax=tuple(axis_max(source,d) for d in spread)
    ua,ub=prod(amax),prod(bmax)
    separated=all(periodic_distance(s*d-t*e,source.period)>=2*source.bump
                  for d,e in zip(axial,spread) for s,t in product((-1,1),repeat=2))
    if separated:
        # If the axial density has every axis at a peak, the dispersed
        # density has every axis at its floor. Otherwise one axial axis
        # has at most its floor, while the dispersed density gets its cap.
        bound=max(beta*ua+source.floor**source.n,
                  beta*ua*source.floor/min(amax)+ub)
        return bound,True
    return beta*ua+ub,False


def peak_witnesses(source,parents,src,walls,reps,steps,fraction):
    moves=sorted({a for opts in steps for a in opts})
    # A positive rational perturbation avoids every preimage wall of
    # every evaluated mode. Each sampled density is an essential lower bound.
    shifted=[sorted({a+s[j] for a in axis for s in moves}) for j,axis in enumerate(walls)]
    points=set()
    for y,s in product(reps,moves):
        x=tuple(a+b for a,b in zip(y,s))
        def inside(v,axis):
            gap=min((u-v for u in axis if u>v),default=F(1))
            out=v+min(gap/2,F(1,2**24))
            assert out not in axis
            return out
        points.add(tuple(inside(v,axis) for v,axis in zip(x,shifted)))
    peaks=[F(0)]*(len(steps)+1)
    for x in sorted(points):
        cache={}
        for s in moves:
            y=tuple(u-v for u,v in zip(x,s))
            m=point_mask(parents,y)
            d=prod(one_density(source,z) for z in y)
            assert not d or m in src
            cache[s]=(m,d if m else F(0))
        for slot,opts in enumerate(steps):
            peaks[slot]=max(peaks[slot],sum(cache[s][1] for s in opts)/len(opts))
        # slot 1 uses x4 and slot 2 uses the all-axis shape.
        axial=sum(fraction.get(cache[s][0],F(0))*cache[s][1] for s in steps[1])/len(steps[1])
        dispersed=sum((1-fraction.get(cache[s][0],F(0)))*cache[s][1] for s in steps[2])/len(steps[2])
        peaks[-1]=max(peaks[-1],axial+dispersed)
    return tuple(peaks),len(points)


def fixed_source_point(initial,walls,parents,source,R):
    moves={tuple(F(0) for _ in range(source.n))}
    for amp in AMPLITUDES:
        a=amp*R
        for shape in ((a,F(0),F(0),F(0)),(F(0),F(0),F(0),a),(a/4,)*4):
            moves.update(translations(shape))
    q=[]
    gaps=[]
    for j,(x,axis) in enumerate(zip(initial,walls)):
        planes=sorted({a+s[j] for a in axis for s in moves})
        next_gap=min((u-x for u in planes if u>x),default=F(1))
        v=x+min(next_gap/2,F(1,2**24))
        assert v not in planes
        q.append(v)
        gaps.append(min(abs(v-u) for u in planes)/2)
    q=tuple(q)
    assert point_mask(parents,q)==95
    mass=prod(source.mass(x-d,x+d) for x,d in zip(q,gaps))
    assert mass>0
    return q,tuple(gaps),mass


def fixed_arm_hits(q,table,parents,signs):
    result={}
    for t,g in table:
        if 95 not in table[t,g]:
            continue
        flags=[]
        for s in signs:
            x=tuple(a+b for a,b in zip(q,s))
            m=point_mask(parents,x)
            flags.append(tuple(bool(m&parents[i]["bit"]) for i in (t,g)))
        r,take=(sum(pair[j] for pair in flags) for j in (0,1))
        result[t,g]=F(r*take,len(signs)**2),F(sum(a and b for a,b in flags),len(signs))
    return result


def capture(raw,hits,parents,factor,fixed_right=None):
    mass=[F(0)]*4
    marks=[defaultdict(F),defaultdict(F)]
    old=[defaultdict(F),defaultdict(F)]
    for (t,l,r),w in raw.items():
        hL,sL=hits[t,l[0],l[1]]
        hR,sR=hits[t,r[0],r[1]] if fixed_right is None else fixed_right[t,r[0]]
        receipt=w*hL*hR*factor**2
        mass[0]+=w*hL*factor
        mass[1]+=w*hR*factor
        mass[2]+=receipt
        mass[3]+=w*sL*sR*factor**2
        for j,(i,y,k) in enumerate((l,r)):
            old[j][i,k]+=w
            marks[j][i,k]+=receipt
    assert all(sum(m.values())==mass[2] for m in marks)
    assert all(0<=x<=old[j][i,k]<=parents[i]["owner_volume"]/2
               for j,m in enumerate(marks) for (i,k),x in m.items())
    peak=tuple(max(2*x/parents[i]["owner_volume"] for (i,k),x in m.items()) for m in marks)
    return mass,peak


def main(rounds):
    source,parents,src,raw,hard,outward,R,files=load(rounds)
    table=arms(raw)
    active={x for masks in table.values() for x in masks}
    k={y:sum(p["j"]/p["m"] for p in parents.values() if p["bit"]&y) for y in src}
    reference=sorted({k[y] for y in active})[-2]
    fraction={y:(min(F(1,2),reference/(2*k[y])) if y in active else F(0)) for y in src}
    assert max(fraction.values())==F(1,2)
    assert len({fraction[y] for y in active})>=2
    q95={key:w for key,w in raw.items() if key[2][1]==95}
    diets=(("full",raw),("R859 hard",hard),("shared q-mask 95",q95))
    assert q95
    walls=axis_walls(source,parents)
    reps=representatives(source,parents,walls,src)
    q,q_radius,q_mass=fixed_source_point(reps[95],walls,parents,source,R)
    def fmt(x,y=None):
        return "0" if x==0 and (y is None or y==0) else outward(x,y)
    print("Python",sys.version.split()[0],"; Fraction shape matching, exact geometric capture, rigorous density brackets.")
    print("Pinned R863",PIN863,"; actual863.py",files["actual863.py"],"; weighted863.py",files["weighted863.py"])
    print("Full, hard and q95 original records:",tuple((name,len(d),fmt(sum(d.values()))) for name,d in diets))
    print("One physical R=1 window; admissible source law is original unweighted mu on Y_O=union of all 8 actual A_i.")
    print("True mu(Y_O):",sum(v for m,v in src.items() if m),"; archived real j_i:",tuple((i,p["j"]) for i,p in parents.items()))
    print("The whole window shares the output cap. Each selected shape emits both sign draws with the same marginal law.")
    print("Adaptive x4 probability = min(1/2, k_ref/(2k(y))) on the 10 active true masks, and 0 elsewhere.")
    print("Only selection uses k(y)=sum j_i/m_i; the output peak uses no k weighting. k_ref =",reference)
    print("Exact original scores use the same shape within an arm and two independent sign draws into real A_t and A_i.")
    print("Each original row uses two actual prices. Same-point both is an additional geometric control.")
    print("One common actual right source q in mask 95:",q,"; coordinate neighborhood radii",q_radius,
          "; positive mass",q_mass)
    print("Every right-arm gate and shape decision is constant throughout this certified q neighborhood.")
    print("Fixed-q scores condition the same original rows on this neighborhood, without an additional capacity reset.")
    for amplitude in AMPLITUDES:
        a=amplitude*R
        thin=(a,F(0),F(0),F(0))
        trans=(F(0),F(0),F(0),a)
        spread=(a/4,)*4
        shapes=(thin,trans,spread)
        step=tuple(translations(s) for s in shapes)
        assert all(sum(abs(v) for v in d)==a for opts in step for d in opts)
        real=[arm_hits(source,parents,src,table,s) for s in shapes]
        real.append({key:tuple(fraction[key[2]]*x+(1-fraction[key[2]])*y
                               for x,y in zip(real[1][key],real[2][key])) for key in real[1]})
        right=[fixed_arm_hits(q,table,parents,s) for s in step]
        b=fraction[95]
        right.append({key:tuple(b*v+(1-b)*w for v,w in zip(right[1][key],right[2][key]))
                      for key in right[1]})
        cap=[prod(axis_max(source,d) for d in s) for s in shapes]
        mixed,separated=mixed_density_bound(source,trans,spread,max(fraction.values()))
        cap.append(mixed)
        lower,count=peak_witnesses(source,parents,src,walls,tuple(reps.values()),step,fraction)
        assert all(0<d<=u for d,u in zip(lower,cap))
        tau=cap[2]
        print(" a =",a,"; common unweighted tau =",fmt(tau),"(all-axis rigorous density upper); witness atoms",count,
              "; separable peak supports between adaptive modes:",separated)
        for label,score,qscore,l,u in zip(("one axis x1","one axis x4","all axes","price-adaptive x4/all"),
                                           real,right,lower,cap):
            s=min(F(1),tau/u)
            assert s*u<=tau
            print("  ",label,"true density max lower/upper",fmt(l,u),
                  "; bounds equal exactly",l==u,"; certified admission",fmt(s))
            for name,group in diets:
                M=sum(group.values())
                values,_=capture(group,score,parents,F(1))
                paid,peak=capture(group,score,parents,s)
                print("    ",name,"raw L,R,both; same-point both:",*(fmt(x/M) for x in values),
                      "; both under cap",fmt(paid[2]/M),
                      "; certified U/W weight / true half Lebesgue",tuple(fmt(x) for x in peak))
            fixed,_=capture(q95,score,parents,s,fixed_right=qscore)
            print("     actual fixed q: certified L,R,both over same conditional q95 row mass:",
                  *(fmt(x/sum(q95.values())) for x in fixed[:3]))
    print("All assertions passed. Finite geometric marks under one window's shared density capacity; no old-contract payment claim.")


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--rounds",type=Path,required=True)
    main(parser.parse_args().rounds)

