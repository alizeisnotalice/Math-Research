# R488 主代理：任意自适应中心半径的平方距离方差源价

## 准确命题

n≥1，0<a≤b<∞，可测中心域E⊂R^n及任意可测半径R_A∈[a,b]。Q_A=A+[-R_A/2,R_A/2]^n，μ为有限正测度，W=μ(R^n)，m_A=μ(Q_A)，π_A=1_Q μ/m_A（m_A=0项取零）。设ν(dA)≤S m_A R_A^{-n}dA。定义
φ_A(x)=|x−A|²/(nR_A²)，c=1/12。
则
\[
\int ν(dA)\operatorname{Var}_{π_A}(φ_A)
\le \int ν(dA)\int(φ_A-c)^2dπ_A
\le S C_n(b/a)W,
\]
\[
C_n(t)=\frac1{180n}+\log t\left[\frac{2n+4}{180n}+4\sqrt{\frac{1/144+1/(180n)}{180n}}\right]
\le\frac1{180}+\frac{\log t}{15}.
\]
uniform marks与自然PPP配置条件概率积分为1，不增加价格。原ν=t(A)σ、σ=q_A dA、q_A=m_A/R_A^n、t≤S满足此假设。所有来源质量保留；结果比仅对固定尺度成立更强。没有使用来源密度帽。

## 逐来源尺度变差证明

固定y=x−A，令
k_R(y)=R^{-n}1_{2||y||∞≤R} (|y|²/(nR²)−c)^2。
对每个y，R↦k_R(y)在进入阈值t_y=2||y||∞处有一个非负跳跃，在R>t_y可微。于是
\[
\sup_{a≤R≤b}k_R(y)\le k_a(y)
+1_{a<t_y≤b}k_{t_y}(y)
+\int_a^b1_{t_y<R}|\partial_R[R^{-n}(φ_R(y)-c)^2]|dR.
\tag{1}
\]
阈值等于端点无需多算，等面积面上的多坐标最大值并列为Lebesgue零集。各项非负，Tonelli可用；这也给包络可测性（每段连续并保跳跃，或取可数稠密尺度逼近）。

令U_i独立uniform[-1/2,1/2]，Φ=n^{-1}ΣU_i²。精确矩为
EΦ=c，E(Φ-c)²=1/(180n)，EΦ²=1/144+1/(180n)。因此∫k_a dy=1/(180n)。

内部导数是
\[
\partial_R[R^{-n}(φ_R-c)^2]
=R^{-n-1}[-n(φ_R-c)^2-4φ_R(φ_R-c)].
\]
变量代换y=Ru及Cauchy给
\[
\int_{t_y<R}|\partial_R k_R|dy
\le\frac1R\left[\frac1{180}+4\sqrt{(1/144+1/(180n))/(180n)}\right].\tag{2}
\]
这里k_R导数不包含边界delta；边界已在(1)单列。

以t=2||y||∞径向分解，立方壳体积为n t^{n-1}dt，面方向均匀：一个坐标为±1/2，其他n−1坐标独立uniform[-1/2,1/2]。定义Φ_face=1/(4n)+n^{-1}Σ_{i<n}U_i²，则
E(Φ_face-c)=1/(6n)，VarΦ_face=(n−1)/(180n²)，
E(Φ_face-c)²=(n+4)/(180n²)。故跳跃积分恰为
\[
\int1_{a<t_y≤b}k_{t_y}(y)dy
=\frac{n+4}{180n}\log(b/a).\tag{3}
\]
n=1时无自由面坐标，上式仍成立。

合并(1)—(3)即∫sup_R k_R≤C_n。一般中心selector满足k_{R_A}(x−A)≤sup_R k_R(x−A)，所以平移不变性与Tonelli给
∫μ(dx)∫_E k_{R_A}(x−A)dA≤C_n W。
最后条件均值是平方误差的最优常数，故方差≤以c为中心的二次矩，结论成立。

粗常数：n≥1时(2n+4)/(180n)≤1/30，4sqrt((1/144+1/(180n))/(180n))≤1/30（因1/144+1/180=1/80）；总系数≤1/15。不需优化常数或采用有限n外推。

## 同一真实来源偏差的支付接口

沿R487自然M、来源投影Z及父/mark投影Q，φ0=φ−Qφ。上述定理给||φ0||_M²≤S C_n W。对h=J*v，源零阶方差V0(h)=||(Z−Q)h||²，
\[
|\langle h,φ0\rangle|²\le S C_n W\,V0(h),
\quad |\langle h,φ0\rangle|\le uV0(h)+\frac{S C_nW}{4u}\quad(u>0).
\]
这是同一h真实来源偏差的W价，不是假来源和配置独立。对一次输入v=1，V0(h)≤R，结合原R≤S A_n W可给|偏差|≤S sqrt(C_n A_n)W=O(√n W)（单octave）。对累计V，必须保V0(J*V)及其实际能量，不能重复用一次R。

这些界没有直接控制长边平移功中的正位移能量、父条件相关与一次到累计的有符号修正。因此不宣称原w_l或一般上界已闭合。
