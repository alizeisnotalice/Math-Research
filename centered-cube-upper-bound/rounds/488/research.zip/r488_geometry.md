# R488：二次来源势的全中心方差与实际功的范围

本稿给任意真实边长选择器、任意非负 \(L^1\) 来源一个全来源 \(O(W)\) 方差界，并将它接到实际 \(J\) 的单次来源刷新偏差。累计停止预算仍未闭合；配置波动收缩不能删除父到达权。

## 1. 原长边流到实际成功核的差额

沿 R481—R487：\(\mu=f\,dx\)，\(m_A=q_AR_A^n\)，\(a\le R_A\le b\le2a\)，\(q\le q_A\le\lambda\)，\(r=\lambda/q\)，\(\sigma=q_A\,dA\)，\(\nu=t\sigma\)，\(0\le t\le S\)，\(R=\nu(E)\)，\(X=\sigma(E)\)。自然状态参考为 \(\mathsf M=\nu(dA)ds_A\pi_A(dx)\operatorname{PPP}_{<A,x}(dF)\)。

R481 的 \(\Omega_\ell\) 已有长边、双中心外置及原成功门；R482 进一步删去任何 raw 父命中旧 \(y\) 或 \(z\) 的整配置，得到 \(\Omega_0\)，正是本轮 \(J\) 的初始成功边流。已证
\[
F_{\rm hit}=|\Omega_\ell|-|\Omega_0|
\le \frac{2rS^2}{T}X.
\tag{1}
\]
在共同捕获来源 \(x\) 的两父上，\(|x-A|_2\le\sqrt nR_A/2\)，\(|B-A|_2\le3\sqrt nR_A/2\)。因此归一化 work 被积函数
\[
\omega(A,B,x)=\frac{(x-A)\cdot(B-A)}{nR_A^2}
\]
绝对值至多 \(3/4\)，从而
\[
|w_\ell-w_0|\le\frac34F_{\rm hit}
\le\frac{3rS^2}{2T}X.
\tag{2}
\]
也可直接使用 R482 在 \(\Omega_0\) 上重新证明的恢复式，不能仅按有符号功的正限制单调性替换。后文不将 (1) 或旧核的一次失败价逐步免费迁移到 \(\mathcal P=JH\)。

## 2. 新几何引理：归一化二次势的全中心方差

定义
\[
\phi_A(x)=\frac{|x-A|_2^2}{nR_A^2},\quad c=\frac1{12},
\quad A_n=1+n\log(b/a),
\quad C_{\rm sl}=\frac1{n+1}
 +\left(\frac n{n+1}\right)^{n+1}\log(b/a).
\]
对任意可测选择器 \(R_A\in[a,b]\) 和每个固定 \(x\)，有
\[
\boxed{\int_E c_A(x)R_A^{-n}(\phi_A(x)-c)^2\,dA
\le C_{\rm ang}:=
\frac{A_n(n+4)}{90n^2}+\frac{C_{\rm sl}}{18}
\le\frac{1+\log2}{9}.}
\tag{3}
\]

**证明。** 在真实中心 Lebesgue 积分中令 \(u=2\|A-x\|_\infty\)、\(\vartheta=2(A-x)/u\)。除了零测度的并列最大坐标，方向有一个坐标等于 \(\pm1\)，其余 \(n-1\) 个坐标独立均匀于 \([-1,1]\)；这是立方体径向分解，不是关于来源 \(f\) 的乘积假设。径向体积元为 \(nu^{n-1}du\)。若
\[
Z(\vartheta)=\frac{|\vartheta|_2^2}{4n},
\]
则
\[
\mathbb EZ=\frac1{12}+\frac1{6n},\quad
\operatorname{Var}Z=\frac{n-1}{180n^2},\quad
\mathbb E(Z-c)^2=\frac{n+4}{180n^2}.
\tag{4}
\]
在捕获域令 \(\zeta=u/R_A\in[0,1]\)，于是 \(\phi_A=\zeta^2Z\)。逐点
\[
(\phi_A-c)^2
\le2(Z-c)^2+\frac{(1-\zeta^2)^2}{72}
\le2(Z-c)^2+\frac{1-\zeta}{18}.
\tag{5}
\]
实际 \(R_A\) 可以依赖全部方向；仅在正上界中用
\(c_A R_A^{-n}\le1_{u\le b}\max(a,u)^{-n}\)，不改变任何原选择器。其径向积分恰为 \(A_n\)。第一项由 (4) 给 (3) 的第一项。第二项恰是 R481 已证真实径向松弛量，价格 \(C_{\rm sl}/18\)。最后用 \(n+4\le5n\)、\(C_{\rm sl}\le1/(n+1)+\log(b/a)\) 得统一常数。证毕。

由 \(\sigma/m_A=R_A^{-n}dA\)、\(t\le S\) 及 Tonelli，
\[
\boxed{\|\phi-c\|_{L^2(\mathsf M)}^2\le SC_{\rm ang}W.}
\tag{6}
\]
令 \(\bar\phi(A)=\int\phi_A\,d\pi_A\)，\(\psi=\phi-\bar\phi\)。条件均值最小化平方误差，所以
\[
\|\psi\|^2\le SC_{\rm ang}W,
\qquad \|\bar\phi-c\|_{L^2(\nu)}^2\le SC_{\rm ang}W.
\tag{7}
\]
这不是逐父薄壳方差断言；\(\pi_A\) 可以任意集中。(3) 使用的是全体真实中心的 Lebesgue 结构。

## 3. 实际单次来源刷新偏差已有根阶价格

记 \(Q_s\) 为给定父、标记、来源后对自然配置取均值，\(Q\) 为父与标记均值。R486 的零阶公式给 \(Q_sH=Q\)，因而 \(H\psi=0\)。对任意 \(h\in L^2(\mathsf M)\)，正交混沌与 \(H\) 收缩给
\[
E_0(h):=\|(Q_s-Q)h\|^2
\le\|h\|^2-\|Hh\|^2,
\quad
|\langle h,\psi\rangle|
\le\sqrt{SC_{\rm ang}W\,E_0(h)}.
\tag{8}
\]
对初始实际成功输出 \(h_0=J^*1\)，由实际列支配有 \(0\le h_0\le1\)，且 \(\Delta_0=R-|\Omega_0|\)。正交投影 \(Q_s-Q\) 消去常数，所以
\[
E_0(h_0)\le\|h_0-1\|^2\le\int(1-h_0)\,d\mathsf M=\Delta_0,
\]
故
\[
\boxed{|\langle J^*1,\phi-\bar\phi\rangle|
\le\sqrt{SC_{\rm ang}W\Delta_0}
\le S\sqrt{C_{\rm ang}A_n}\,W.}
\tag{9}
\]
最后只用 \(\Delta_0\le R\le SA_nW\)。这是原 \(\Omega_0\) 输出来源相对 \(\pi_B\) 的**二次势偏差**的根阶来源价，无新增 \(X\) 费；它不是整个 work 的价格，也不另作原成功流质量删支。

## 4. 累计流的精确桥及唯一未消权

真实自然链占用密度为 \(V=\sum_{j\ge0}(\mathcal P^*)^j1\)，由已有两参考界有界且属 \(L^2\)。设 \(a=QV\)、\(h=J^*V\)、\(e=1-J1\)。由于每个非初始项均经 \(H\)，
\[
Q_sV=QV=a,\qquad Qh=a-1,
\qquad \int Ve\,d\mathsf M=R.
\tag{10}
\]
第一式仅说来源边缘为 \(a(A,s)\pi_A\)；配置仍与来源相关。

在同一个累计成功边流 \(V\mathsf M J\) 上，准确势差是
\[
\boxed{\int[\phi_B(x)-\phi_A(x)]\,d(V\mathsf M J)
=\langle h,\psi\rangle
 +\int Ve(\phi-c)\,d\mathsf M
 -\int(\phi-c)\,d\mathsf M.}
\tag{11}
\]
证明只需对到达端用 \(Qh=a-1\)，对出发端用 \(Q_sV=a\)，再以停止总量 \(R\) 消掉两份常数 \(cR\)。没有来源刷新或历史替换。

若 \(\mathcal O=\int V\,d\mathsf M\)，则
\[
E_0(h)\le\|V\|^2-\|\mathcal P^*V\|^2
=2\mathcal O-R,
\qquad
|\langle h,\psi\rangle|
\le\sqrt{SC_{\rm ang}W(2\mathcal O-R)}.
\tag{12}
\]
这里不能把右端换成一次 \(\Delta_0\)。停止项也只有例如
\[
\left|\int Ve(\phi-c)\,d\mathsf M\right|
\le\sqrt{SC_{\rm ang}W}\,\|Ve\|_2,
\tag{13}
\]
其实际来源列尚未获根阶控制。将 (3) 用于带父到达权 \(a\) 时，\(t\le S\) 已变为 \(a\,t\)，不能再免费套用同一个 \(O(W)\) 常数。R487 的 \(0.51\) 收缩控制配置波动，不控制这个父权。

最后，即便 (11) 的势差得到价格，平移功还含实际二端位移相关。累计功并非初始功：若 \(\omega_J\) 是给定状态对实际成功转移的 \(\omega\) 积分，则
\[
w_0=\langle1,\omega_J\rangle,
\quad w_V=\langle V,\omega_J\rangle,
\quad w_V-w_0=\langle V-1,\omega_J\rangle,
\quad |w_V-w_0|\le\tfrac34(\mathcal O-R).
\tag{14}
\]
它不是零项，也没有已证的正号。因此本轮的新付款是 (9)，新的全几何工具是 (3)—(7)；原完整 work/root 目标还需控制**同一父到达权下的停止来源列与位移相关**，不能靠 (10) 的单源边缘或波动逆算子直接关闭。

## 5. 自含实际本机核验

以下代码已在指定本机 Python 运行。输出为 `PASS 1 angular-moment identity; 45 Fraction pointwise checks; 5 Arb constant bounds`。它核角向矩、逐点分解及有限维常数，不认证原历史场；一般证明是上面的真实中心积分。

```python
from fractions import Fraction as F
import sympy as s
from flint import arb,ctx
ctx.prec=192
n=s.symbols('n', positive=True)
mean=(1+(n-1)/3)/(4*n)
var=(n-1)*s.Rational(4,45)/(16*n*n)
assert s.simplify(var+(mean-s.Rational(1,12))**2
                 -(n+4)/(180*n*n))==0
for dim in (1,2,8):
 for tail in (F(0),F(1,3),F(1)):
  ang=(1+(dim-1)*tail*tail)/F(4*dim)
  for z in (F(0),F(1,4),F(1,2),F(3,4),F(1)):
   phi=z*z*ang
   assert (phi-F(1,12))**2<=2*(ang-F(1,12))**2+(1-z)/18
for dim in (1,2,8,32,256):
 log2=arb(2).log();d=arb(dim)
 An=1+d*log2
 slack=1/(d+1)+(d/(d+1))**(dim+1)*log2
 C=An*(d+4)/(90*d*d)+slack/18
 assert C<(1+log2)/9
print('PASS 1 angular-moment identity; 45 Fraction pointwise checks; '
      '5 Arb constant bounds')
```
