# R488：实际来源投影、累计几何功与一次功的转换账

同一 R486 自然参考 \(\mathsf M\)、成功核 \(J\)、来源／配置刷新 \(H\) 及 \(\mathcal P=JH\)。本文证明累计密度的来源条件均值恰为父均值，并把几何功中的 incoming 来源偏差接到 R487 的真实源零阶耗散。结合本轮任意中心 selector 的方差界，该偏差获得 \(W\) 价格；尚未支付完整 R481 的一次长边功。

## 1. 投影恒等式不要求配置独立

令 \(Q\) 为给定增广父 \((A,s_A)\) 的条件期望，\(Z\) 为给定 \((A,s_A,x)\) 的条件期望。二者均相对于自然相关参考 \(\mathsf M\)，所以 \(QZ=ZQ=Q\)。R486 main §2 的混沌公式表明 \(Z\) 保留且仅保留 Poisson 零阶；该阶的 \(H\) 把来源函数平均。因此对全部 \(L^2(\mathsf M)\) 函数，
\[
 ZH=HZ=Q. \tag{1}
\]
先在有限混沌和上验证，再由条件期望收缩及 R486 稠密性延拓。此式没有把 \(x,F\) 的自然联合分布替成产品。

实际累计密度及停止率为
\[
 V=\sum_{j\ge0}(\mathcal P^*)^j1\in L^\infty(\mathsf M),\qquad
 V=1+HJ^*V,\quad e=1-J1,\quad \int Ve\,d\mathsf M=R=\mathsf M(1).
\]
其有限性使用 R486 普通／质量加权双列界，不用旧 \(K\) 行价。由(1)，
\[
 \boxed{ZV=QV,\qquad QJ^*V=QV-1.} \tag{2}
\]
这只是累计密度的来源条件均值约束，绝不说明累计配置独立，亦不说明 \(Ve\) 具有原来源后验。

## 2. Incoming 偏差的实际源价

记
\[
 \phi(A,x)=\frac{|x-A|^2}{nR_A^2}\in[0,1/4],\quad
 q=Q\phi,\quad \phi_0=\phi-q.
\]
因 \(Z\phi_0=\phi_0\)、\(Q\phi_0=0\)，有 \(H\phi_0=0\)。对 \(h=J^*V\)，定义实际 incoming 偏差
\[
 \mathcal B_V=\langle h,\phi_0\rangle
 =\langle (Z-Q)h,\phi_0\rangle.
\]
R487 的来源零阶量正是 \(V_0(h)=\|(Z-Q)h\|_2^2\)，故
\[
 |\mathcal B_V|^2\le V_0(h)\|\phi_0\|_2^2. \tag{3}
\]

本轮主代理方差引理 `/tmp/r488_root_geometry.md` 给出（其必要矩与微分方向已独立核验）
\[
 \|\phi_0\|_{\mathsf M}^2\le S C_n(b/a)W,
\]
\[
 C_n(t)=\frac1{180n}+\log t\left[
 \frac{2n+4}{180n}
 +4\sqrt{\frac{1/144+1/(180n)}{180n}}\right]
 \le \frac1{180}+\frac{\log t}{15}. \tag{4}
\]
适用量词为任意可测 \(R_A\in[a,b]\)、完整任意正来源 \(\mu\)，以及 \(\nu\le Sm_AR_A^{-n}dA\)，故包括当前 \(\nu=t\sigma\)。它不要求坐标来源独立。简核：均匀标准立方体上 \(\Phi=n^{-1}\sum U_i^2\) 满足 \(E\Phi=1/12\)、\(\operatorname{Var}\Phi=1/(180n)\)；一个面上 \(E(\Phi-1/12)^2=(n+4)/(180n^2)\)。尺度核
\(R^{-n}1_{2\|x-A\|_\infty\le R}(\phi_R-1/12)^2\)
的内部绝对导数积分为至多
\([1/180+4\sqrt{(1/144+1/(180n))/(180n)}]/R\)，进入面的非负跳跃另计 \((n+4)/(180nR)\)。积分尺度变差后再对真实 \(\mu\) Tonelli，得到(4)。特别没有遗漏可变 selector 的进入面跳跃。

由(3)–(4)，对任意 \(u>0\)，
\[
 \boxed{|\mathcal B_V|\le\sqrt{S C_nW\,V_0(J^*V)}
 \le uV_0(J^*V)+\frac{S C_nW}{4u}.} \tag{5}
\]
这是同一累计输入的带能量来源付款，不是把累计输入改为一次输入。R487 同参考总耗散确含 \(V_0(h)\) 系数 1，故亦有
\[
 |\mathcal B_V|^2\le S C_nW\left(2\int Vd\mathsf M-R\right). \tag{6}
\]
右边仍是累计占用。对于**一次**输入 \(h_1=J^*1\)，有 \(0\le h_1\le1\)。由于 \(Z-Q\) 为正交投影且消去常数，
\[
 V_0(h_1)\le\|h_1-1\|^2\le\int(1-h_1)d\mathsf M
 =:\Delta_0=R-\mathsf M J1.
\]
因此更强的一次可付款式为
\[
 \boxed{|\mathcal B_1|\le\sqrt{SC_nW\Delta_0}
 \le u\Delta_0+\frac{SC_nW}{4u}.} \tag{7}
\]
沿原同一 \(J\) 的完整一次失败账 \(\Delta_0\le\alpha X+\kappa TNW\)，其中 \(\alpha\) 必须包括该核全部实际删除门，(7)给
\[
 |\mathcal B_1|\le u\alpha X+
 \left(u\kappa TN+\frac{SC_n}{4u}\right)W.
\]
固定参数下 \(N=O_{r}(\sqrt n)\)，故选择 \(u\alpha\) 在所需吸收额内即可得到一次偏差的可吸收加根阶价格。不得向累计 \(h=J^*V\) 再套 \(h\le1\) 或重复收该一次费。另由 \(V_0(h_1)\le R\le SA_nW\) 仍有粗但不需失败账的 \(|\mathcal B_1|\le S\sqrt{C_nA_n}W\)。这些都只支付明确的 incoming 偏差，不等于支付原长边功。

## 3. 同一累计成功边上的几何恒等式

对实际 \(J\) 边从 \(\xi=(A,s_A,x,F)\) 到 \(\xi'=(B,s_B,x,F')\)，来源 \(x\) 在该边不变；\(H\) 的来源刷新随后发生。记
\[
 d\mathcal G_V(\xi,\xi')=V(\xi)\mathsf M(d\xi)J(\xi,d\xi'),
\quad z=(x-A)/R_A,\ d=(B-A)/R_A,\ \rho=R_A/R_B.
\]
以下均含原实际成功权：
\[
 \mathcal W_V=\int\frac{z\cdot d}{n}d\mathcal G_V,\quad
 \mathcal E_V=\int\frac{|d|^2}{n}d\mathcal G_V,\quad
 \mathcal T_V=\int(\rho^{-2}-1)\phi(B,x)d\mathcal G_V.
\]
由(2)，\(\langle V,\phi_0\rangle=0\) 及
\(\langle h,\phi\rangle=\langle V-1,q\rangle+\mathcal B_V\)。因此
\[
 \boxed{\int[\phi(B,x)-\phi(A,x)]d\mathcal G_V
 =\mathcal B_V+\langle Ve,\phi\rangle-\langle1,\phi\rangle.} \tag{8}
\]
逐点 R481 §3 的二次恒等式给
\[
 \boxed{2\mathcal W_V=\mathcal E_V-\mathcal B_V
 -\langle Ve,\phi\rangle+\langle1,\phi\rangle-\mathcal T_V.} \tag{9}
\]
所有积分有限：\(V\) 有界、\(\mathsf M\) 有限、单 octave 下边函数有界。故无无穷差相消。停止项 \(\langle Ve,\phi\rangle\) 不能改成 \(\langle1,\phi\rangle\)；只知道停止总质量为 \(R\)，二者分别在 \([0,R/4]\)。同理，\(\mathcal T_V\) 的绝对值至多累计的 \(2\int|\log\rho|d\mathcal G_V\)，不能套一次半径费用。

(5)可在(9)中给出
\[
 2\mathcal W_V\le\mathcal E_V+uV_0(h)+\frac{SC_nW}{4u}
 +\langle1,\phi\rangle-\langle Ve,\phi\rangle-\mathcal T_V. \tag{10}
\]
这里仍有正位移能量和父停止项；总 \(L^2\) 耗散本身没有给这些项与原工作量的吸收关系。

## 4. 原一次长边功的不可省转换

\(\Gamma_1=\mathsf M(d\xi)J(\xi,d\xi')\) 是初始一次成功流。若按 R486 原合同继续保长边、全 raw no-hit 等门，它是 R481 \(\Omega_\ell\) 的正限制；定义其实际删去量 \(d_J=|\Omega_\ell-\Gamma_1|\)。这只关第一次输入，后续父没有继承旧记录。

令 \(c_J(\xi)=\int(z\cdot d/n)J(\xi,d\xi')\)。则精确
\[
 \boxed{w_\ell=\mathcal W_V-\langle V-1,c_J\rangle
 +\int_{\Omega_\ell-\Gamma_1}\frac{z\cdot d}{n}.} \tag{11}
\]
共源捕获及单 octave 给逐边 \(-1/4\le z\cdot d/n\le3/4\)：写成每坐标 \(z_i^2-(R_B/R_A)z_i z'_i\)，其中 \(|z_i|,|z'_i|\le1/2\)、\(R_B/R_A\le2\)。故删除项上界 \(3d_J/4\)，应沿既有第一次删除账计，不能又收一次。未来修正则仅有
\[
 -\langle V-1,c_J\rangle
 \le\langle V-1,(c_J)_-\rangle
 \le\tfrac14\langle V-1,J1\rangle. \tag{12}
\]
右边是额外累计成功次数，未有根阶源价。即使把(5)的来源偏差全部吸收，(9)的正位移能量及(11)的 signed 修正仍在。不能以累计 signed 功替换原一次功，也不能把 \(ZV=QV\) 当来源刷新后的旧历史继承。

当前精确缺口是：对**同一实际成功边**证明(9)–(11)中正位移能量、停止／尺度项与未来 signed 修正的联合上界足以支付原 \(w_\ell\)，而非分别套一次价格。本文未证明该联合比较；新增的实际源价仅为(5)、(7)，不宣称原剩余全局闭合。

## 5. 本机精确核验

指定本机 Python/SymPy 最终实跑 13 个精确断言：两项 uniform/face 矩，四条逐边二次恒等式，以及来源投影、停止、偏差、累计功、一次转换和 Cauchy。初次临时运行因 Python 整数除法引入浮点而未通过精确等号，以下最终版本统一 sympify 后通过；只报告最终实际证据。

输出：
```text
13 exact SymPy assertions PASS
first_work= -11/17280 cumulative_work= -49/51840 future_signed_difference= -1/3240 bias= 1763/725760
Finite source-preserving operator ledger only; not native matched-center/history certification.
```
该有限例只检查原子来源、同源边与刷新核的算子账，不满足一般原生中心／qband／原历史认证。负未来 signed 差说明不能仅由这些算子性质删去(11)修正；不据此否定完整原几何可能提供额外比较。

```python
import sympy as s
n=s.symbols('n', positive=True, integer=True)
v=1/(180*n)
assert s.simplify((s.Rational(1,80)-s.Rational(1,144))/n-v)==0
assert s.simplify((n-1)/(180*n**2)+1/(36*n**2)-(n+4)/(180*n**2))==0
N=6; H=s.zeros(N);J=s.zeros(N)
for a in range(3):
 for i in range(2):
  for j in range(2):H[2*a+i,2*a+j]=s.Rational(1,2)
for a,rates in enumerate([(s.Rational(1,3),s.Rational(1,5)),
                         (s.Rational(1,4),s.Rational(1,7))]):
 for i,rate in enumerate(rates):J[2*a+i,2*(a+1)+i]=rate
one=s.ones(N,1); E=H*J.T;V=(s.eye(N)-E).inv()*one
h=J.T*V;e=one-J*one
centers=list(map(s.sympify,[0,s.Rational(1,8),s.Rational(1,4)]))
sides=list(map(s.sympify,[1,s.Rational(3,4),s.Rational(1,2)]))
xs=list(map(s.sympify,[0,s.Rational(1,8)]))
phi=s.Matrix([((x-centers[a])/sides[a])**2 for a in range(3) for x in xs])
q=H*phi;phi0=phi-q
ip=lambda a,b:(a.T*b)[0]/N
beta=ip(h,phi0);stop=ip(V,s.diag(*list(e))*phi);initial=ip(one,phi)
work=s.zeros(N,1);pot=s.zeros(N,1);geom=s.zeros(N,1);rad=s.zeros(N,1)
checks=2
for a in range(3):
 for i,x in enumerate(xs):
  src=2*a+i
  for b in range(3):
   dst=2*b+i;rate=J[src,dst]
   if rate:
    z=(x-centers[a])/sides[a];d=(centers[b]-centers[a])/sides[a]
    rho=sides[a]/sides[b]
    work[src]+=rate*z*d;pot[src]+=rate*(phi[dst]-phi[src])
    geom[src]+=rate*d*d;rad[src]+=rate*(rho**(-2)-1)*phi[dst]
    assert s.simplify(d*d-2*z*d-(phi[dst]-phi[src])
                      -(rho**(-2)-1)*phi[dst])==0;checks+=1
assert H*V==V;checks+=1
assert ip(V,e)==1;checks+=1
assert ip(V,pot)==beta+stop-initial;checks+=1
assert 2*ip(V,work)==ip(V,geom)-beta-stop+initial-ip(V,rad);checks+=1
assert ip(one,work)==ip(V,work)-ip(V-one,work);checks+=1
assert ip(V-one,work)<0;checks+=1
assert beta**2<=ip(h-H*h,h-H*h)*ip(phi0,phi0);checks+=1
print(f'{checks} exact SymPy assertions PASS')
print('first_work=',ip(one,work),'cumulative_work=',ip(V,work),
      'future_signed_difference=',ip(V-one,work),'bias=',beta)
print('Finite source-preserving operator ledger only; not native matched-center/history certification.')
```
