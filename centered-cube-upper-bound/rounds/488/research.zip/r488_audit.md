# R488 独立终审

FINAL PASS（限定范围）。通过的是任意有限正来源测度、任意可测中心边长选择器的全中心二次势方差预算，以及同一实际成功核的一次来源偏差付款与累计准确账；不认证原长边功 w_l、累计父停止预算或一般根阶弱型目标闭合。

独立 PRE 在读取 R488 作者证明前保存。随后逐式核对 main、两份几何异证及 proof：BV 包络包含基项、内部尺度绝对导数和进入面非负跳跃，面常数 (n+4)/(180n) 与 n=1 均正确；中心 Lebesgue 积分后 Tonelli 可用于任意有限 μ，不需来源薄壳、密度帽或 selector 独立性。所得 C_n≤1/180+log2/15 正确。角向加径向松弛的异证同样保实际中心结构。

ZH=HZ=Q、ZV=QV 均相对于同一自然相关参考成立。偏差与真实源零阶耗散的配对准确；一次 J*1≤1 给 E0≤Δ0，故有一次 O(√nW) 来源价。累计 J*V 不套该一次帽，仍保 2∫V−R。累计势恒等的初始、实际 Ve 停止、尺度修正及一次到累计 signed 功差额均未丢；原全 raw no-hit 的第一次功差额仅计一次。主稿保留这些未付项及完整母目标，未把辅助偏差付款当成全部 w_l 付款。

实际独立隔离复现：geometry 51 项（1 符号、45 有理、5 Arb）、proof 13 项精确算子账、numeric 50 项精确/区间检查通过，共 114 项；另 62 项浮点诊断单列。三份 stdout 与冻结 replay 一致；numeric JSON 只删除 compute_index.seconds 后全字段一致，canonical SHA256 为 `2fb84eb85cc75453703f8a0e74c1124b4cf4a6cc164a9e758fc39f103d64a424`。SciPy bounded 优化与自适应积分误差非严格区间，不作为一般包络证明；有限算子与低维模型不认证完整 receiver/history。PRE 临时核验不另计覆盖。

## 冻结输入 SHA256

- `r488_main.md`: `243d16705c5bd8a3d6e315b82c7e928bf514fde81794262c66a78bf6b43f8e56`
- `r488_root_geometry.md`: `b8474f4ee634950a3402816817f11a9d58bb4f1dbcf0dec4b9fba77e8f0b7332`
- `r488_geometry.md`: `48a8a83e1b4bc3331ee4bfead6079cecaaf12033fee38f0fc6a91ea0eb413ba6`
- `r488_proof.md`: `2e1f0a6e189f8255f8d4ee31e4c2827e780609867921fe7707df8d46760f54a2`
- `r488_numeric.md`: `b99de66a8010ecd3bfe9cb52feb85f2c6618c9d4d630ad62ab1387c93d4b08ae`
- `r488_numeric.py`: `51cdea5ec8ab1f01ae9fcd01c9d1db1f5552f775cb074a3ce5178a95bbe5ea6f`
- `r488_numeric.json`: `e34e73979b86ae8798816e68bcca6dfba473c63ae3dcde5f38643e05a588dae7`
- `r488_replay.json`: `e56723b3d9e7bd997a4a5d277019c5fa0cca613fa9f53030ba40f1ba6ef66ca1`
