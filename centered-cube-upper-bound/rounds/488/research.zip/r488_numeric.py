from fractions import Fraction as F
from pathlib import Path
import sys,platform,json,time,math,warnings
import sympy as sp
from flint import arb,ctx
import scipy
from scipy.integrate import quad,IntegrationWarning
from scipy.optimize import minimize_scalar
ROOT=Path(__file__).resolve().parent;ctx.prec=256
start=time.perf_counter();checks=0;floating_checks=0

def ck(v,floating=False):
 global checks,floating_checks
 assert v
 if floating:floating_checks+=1
 else:checks+=1

def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator
# Exact one-coordinate moments and all-n cube/face identities.
x=sp.symbols('x',real=True);n=sp.symbols('n',positive=True,integer=True)
e2=sp.integrate(x*x,(x,-sp.Rational(1,2),sp.Rational(1,2)))
e4=sp.integrate(x**4,(x,-sp.Rational(1,2),sp.Rational(1,2)))
ck(e2==sp.Rational(1,12));ck(e4==sp.Rational(1,80));ck(e4-e2**2==sp.Rational(1,180))
mean=e2;var=(e4-e2**2)/n
face_second=(n-1)*(e4-e2**2)/n**2+(sp.Rational(1,4)-e2)**2/n**2
ck(sp.cancel(face_second-(n+4)/(180*n*n))==0)
ck(sp.cancel(n*face_second+n*var-(2*n+4)/(180*n))==0)
R,A,a=sp.symbols('R A a',positive=True);c=sp.Rational(1,12)
f=R**(-n)*(A/R**2-c)**2
factor=-(A-c*R**2)*((n+4)*A-n*c*R**2)*R**(-n-5)
ck(sp.simplify(sp.diff(f,R)-factor)==0)
ck(sp.simplify(a**n*(a*R)**(-n)*(a*a*A/(a*R)**2-c)**2-f)==0)
# Rational uniform constant: first radial terms <=1/30 and cross<=1/30.
ck(F(1,144)+F(1,180)==F(1,80));ck((F(1,80)*F(1,180))==F(1,120)**2)
ck(F(1,30)+4*F(1,120)==F(1,15))

def Cn(nn,beta):
 v=F(1,180*nn);E=F(1,144)+v
 bracket=ar(F(2*nn+4,180*nn))+4*(ar(E*v)).sqrt()
 return ar(v)+ar(beta).log()*bracket,bracket
uniform=ar(F(1,180))+arb(2).log()/15
moments=[]
for nn in (1,2,4,8,16,64,256,1024):
 vv=F(1,180*nn);ef=F(nn+4,180*nn*nn);E=F(1,144)+vv
 bound,bracket=Cn(nn,F(2))
 ck(vv<=F(1,180));ck(F(2*nn+4,180*nn)<=F(1,30));ck(E*vv<=F(1,14400))
 if nn==1:ck((bound-uniform).contains(0));ck((bracket-ar(F(1,15))).contains(0))
 else:ck(bound<uniform);ck(bracket<ar(F(1,15)))
 moments.append(dict(n=nn,cube_mean='1/12',cube_variance=str(vv),cube_second_moment=str(E),face_squared_deviation=str(ef),scale_bracket=str(bracket),C_n_beta2=str(bound),uniform_upper=str(uniform)))
# All-radius supremum: endpoints and one nonzero local maximum suffice.
def value(nn,A,R):return R**(-nn)*(A/R**2-1/12)**2
def analytic_sup(nn,t,u,beta):
 A=t*t/4 if nn==1 else t*t*(1+u*u)/8
 lo=max(1.,t);hi=beta
 candidates=[(value(nn,A,lo),lo),(value(nn,A,hi),hi)]
 if A>0:
  rstar=math.sqrt((nn+4)*A/(nn*(1/12)))
  if lo<=rstar<=hi:candidates.append((value(nn,A,rstar),rstar))
 return max(candidates),A,lo,hi

def scipy_sup(nn,t,u,beta):
 exact,A,lo,hi=analytic_sup(nn,t,u,beta)
 if hi-lo<1e-14:return exact[0],exact[0],0
 cuts=[lo,hi]
 if A>0:
  zero=math.sqrt(12*A)
  if lo<zero<hi:cuts.append(zero)
 cuts=sorted(cuts);best=max(value(nn,A,lo),value(nn,A,hi));calls=0
 for left,right in zip(cuts,cuts[1:]):
  opt=minimize_scalar(lambda rr:-value(nn,A,rr),bounds=(left,right),method='bounded',options={'xatol':1e-12});calls+=opt.nfev
  best=max(best,-opt.fun)
 return exact[0],best,calls
lowdim=[]
for nn in (1,2):
 for betaQ in (F(1),F(3,2),F(2)):
  beta=float(betaQ);maxerr=0.;calls=0;points=0
  for tQ in sorted(set([F(0),F(1,4),F(1,2),F(1),betaQ])):
   if tQ>betaQ:continue
   for uQ in ([F(0)] if nn==1 else [F(0),F(1,3),F(1)]):
    exact,opt,ncall=scipy_sup(nn,float(tQ),float(uQ),beta);maxerr=max(maxerr,abs(exact-opt));calls+=ncall;points+=1
    ck(abs(exact-opt)<1e-10,floating=True)
  inner_errors=[]
  with warnings.catch_warnings(record=True) as caught:
   warnings.simplefilter('always',IntegrationWarning)
   if nn==1:
    integral,err=quad(lambda t:analytic_sup(1,t,0.,beta)[0][0],0,beta,points=[1.] if beta>1 else None,epsabs=2e-11,epsrel=2e-10,limit=250)
   else:
    def outer(u):
     val,ee=quad(lambda t:2*t*analytic_sup(2,t,u,beta)[0][0],0,beta,points=[1.] if beta>1 else None,epsabs=2e-10,epsrel=2e-9,limit=250)
     inner_errors.append(ee);return val
    integral,err=quad(outer,0,1,epsabs=2e-9,epsrel=2e-8,limit=200)
  bound,_=Cn(nn,betaQ);ck(integral<float(bound),floating=True) if betaQ>1 else ck(abs(integral-1/(180*nn))<1e-10,floating=True)
  lowdim.append(dict(n=nn,beta=str(betaQ),a_rescaled_to='1',criterion='Direct all-radius sup integral, float diagnostic only',quadrature_value=integral,scipy_error_estimate=err,max_inner_error_estimate=max(inner_errors) if inner_errors else None,integration_warnings=[str(w.message) for w in caught],analytic_C_n_Arb=str(bound),ratio_to_C_n=integral/float(bound),floating_margin_C_n_minus_integral=float(bound)-integral,optimization_points=points,bounded_optimizer_nfev=calls,max_analytic_vs_optimizer_discrepancy=maxerr,n1_measure='dt' if nn==1 else None,n2_measure='2*t dt du, t=2||y||inf, u=|tangential|/||y||inf' if nn==2 else None))
result=dict(scope='Exact moment/derivative/uniform-constant arithmetic and separate low-dimensional floating direct-sup diagnostics. No new full-field/history theorem.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,scipy=scipy.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r488_numeric.py',seconds=time.perf_counter()-start),rigorous_checks=checks,floating_diagnostic_checks=floating_checks,formula=dict(phi='|y|^2/(n R^2)',c='1/12',C_n='1/(180n)+log(beta)*[(2n+4)/(180n)+4sqrt((1/144+1/(180n))/(180n))]',uniform='1/180+log(2)/15',rescaling='y=a*z,R=a*r gives exact a^n cancellation; only beta=b/a remains',sup_candidates='Rlow=max(1,2||y||inf), beta, Rstar=sqrt((n+4)A/(n*c)) if feasible, A=|y|^2/n; R=sqrt(A/c) is zero/minimum'),moments_and_Arb_bounds=moments,lowdim_diagnostics=lowdim,errors='Moment/rational/symbolic and Arb entries rigorous. SciPy bounded optimizer and adaptive-quadrature error estimates are FLOAT diagnostics, not certified enclosures or general proof. Deterministic fixed points, no Monte Carlo.')
(ROOT/'r488_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact/Arb checks and',floating_checks,'floating diagnostics;6 lowdim sup integrals,8 moment dimensions; no general theorem from samples')
