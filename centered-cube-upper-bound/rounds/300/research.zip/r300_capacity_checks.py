from fractions import Fraction as F
atomic=potential=0
for n in [1,2,4]:
    for masses in [[F(1,10)]*3,[F(1,5),F(3,10),F(1,2)],
                   [F(0),F(1,4),F(1,4)]]:
        rs=[F(1),F(3,2),F(2)]
        def B(k):
            if not k:return F(0)
            f=v=F(0)
            for r,m in zip(rs,masses):
                old=f;f+=m
                v+=r**(-n)*((1-old)**k-(1-f)**k)
            return v
        def J(k):
            f=v=F(0)
            for r,m in zip(rs,masses):
                f+=m;v+=r**(-n)*(1-f)**k*m
            return v
        for N in [0,1,2,8,32]:
            f=gap=F(0)
            g=lambda u:(1-(1-u)**(N+1))/(N+1)
            for r,m in zip(rs,masses):
                old=f;f+=m
                gap+=r**(-n)*(g(f)-g(old)-(1-f)**N*m)
            assert B(N+1)/(N+1)-J(N)==gap and gap>=0
            atomic+=1
        vals=[B(k) for k in range(18)]
        inc=[v-u for u,v in zip(vals,vals[1:])]
        assert all(u>=0 for u in inc)
        assert all(u>=v for u,v in zip(inc,inc[1:]))
        for k in range(18):
            assert 0<=B(k+1)-B(k)<=J(k)
            potential+=1
        for tau in [F(1,10),F(1,100)]:
            sharp=next(k for k in range(10000) if J(k)<=tau/2)
            stop=next(m for m in range(1,10000) if B(m)/m<=tau)-1
            assert B(stop)<=2*B(sharp)+tau/2
            potential+=1
print('PASS exact atomic identities=',atomic)
print('PASS exact increment/potential comparisons=',potential)
