# R300 independent preauthor screen

Scope: same original fixed-field low-pe,m>M positive traffic as R299, arbitrary original softness and both scale orientations, with original e_g,m, FIRST, hardcaps, q, history and source masks unchanged. Own only this audit file. No R300 author proof was read before saving this independent screen. Write q_-=3lambda/4, kappa0=2K/(ell M), chi_r as in R299, and psi_inf=3-2/(3gamma^n). Raw prices retain original Lambda once and all original outer ledgers.

## 1. Exact weighted maximum and actual disjoint source costs

For each fixed actual L,R, chi_r(L,R)=min(1,(L/r)^(n/2)min(1,(R/r)^(3n/2))) is nonincreasing in the witness side r. For a FINITE common configuration of actual accepted witnesses u_i,r_i=R(u_i), assign each captured source z to its smallest containing radius, breaking ties by finite index. The resulting measurable frozen source pieces D_i are disjoint and lie in their actual capped cubes. With M_N(z) the minimum capturing radius and uncaptured sources assigned zero contribution,

    max_i chi_ri(L,R)1_Qri(ui)(z)
      =chi_MN(L,R)1_captured
      =sum_i chi_ri(L,R)1_Di(z).

The single-witness R299 theorem therefore pays this maximum by the EXACT configuration fee

    (kappa0/q_-)sum_i r_i^-n Psi_G((b/r_i)^n)nu(D_i).

This can improve the earlier union-bound fee charging whole overlapping witness cubes. It is bounded by (kappa0 psi_inf/q_-)sum_i r_i^-n nu(D_i), and then by (16/3)kappa0 psi_inf N. The exact source masses, rather than a new unsupported cap on smaller cubes, are what is saved. Across different beta rows the full displayed beta-source integral is still paid.

For N iid witnesses under the actual pi_y=U_y dx/I_y, define

    B_N(y)=E integral M_N(z)^-n 1_captured nu(dz).

Then the averaged weighted maximum costs at most (kappa0 psi_inf/q_-)integral B_N(y)beta(dy), or the sharper average retaining Psi. B_N<=min(4lambda N,a^-n W_nu), so it is finite. Its upper cap 4lambda N follows from the actual same-radius caps on the disjoint source pieces. Field-dependent constructions are legal only conditional on the original complete field; averaging uses finite product kernels, not a selection of a new original source or receiver.

The weighted maximum is NOT the R299 soft-union. Its exact expectation may be represented by layercake over chi levels and the corresponding iid coverage probabilities; it is not generally 1-(1-D)^N for D=E chi1_capture. Such a substitution would change the allocation.

## 2. Rank-to-minimum identity and the role of atoms

Fix y,z and push the capturing subprobability under pi_y forward by its actual radius. Let mu be this measure, F(r)=mu([a,r]) its INCLUSIVE CDF, and mass m<=1. The minimum of N+1 iid witnesses has sub-CDF

    P(M_(N+1)<=r)=1-(1-F(r))^(N+1).

Hence its expected inverse-volume is the Stieltjes integral of r^-n against this sub-CDF. At an atom of mass d, with F_-=F(r-),

    [(1-F_-)^(N+1)-(1-F)^(N+1)]/(N+1)
       =integral_(F_-)^F (1-t)^N dt
       >=d(1-F)^N.

The nonatomic part has exact derivative (N+1)(1-F)^N dF. Therefore, for N>=1,

    integral_[a,b] r^-n(1-F(r))^N dF(r)
       <= E[M_(N+1)^-n1_captured]/(N+1).

Integrating ORIGINAL nu gives the proposed J_N(y)<=B_(N+1)(y)/(N+1). Equality holds when mu is nonatomic for nu-almost every z; atoms contribute a nonnegative explicitly weighted deficit. For N=0 the equality is automatic, but the finite-cover statements here use N>=1. All endpoints and no-capture probability are included. No assumption of a radius density or source density is needed.

## 3. What residual this rank bound controls

On L>=R, every capturing witness r<=R has chi_r=1. Therefore failure of the weighted maximum is at most the event that none of the N witnesses captures z with radius <=R, with probability (1-F_yz(R))^N. Consequently the ORIGINAL weighted-max residual on that orientation satisfies

    T_res,L>=R<=integral I_y J_N(y)beta(dy)
       <=integral I_y B_(N+1)(y)/(N+1) beta(dy).

No original mask is dropped before identifying this actual receiver relation. The same rank comparison is valid on any other actual subset for which the same domination is independently shown.

Caution: R299's SOFT-UNION residual bound on the aspect gate v>=v0 is not inherited for free by the weighted MAX. From chi>=v0 on witnesses r<=R, the generic maximum argument only gives failure <=1-v0+v0(1-F(R))^N. It does not justify the stronger soft-union expression (1-v0 F(R))^N. A new comparison or extra structure is needed for a comparable small L<R maximum residual. Thus replacing the allocation must preserve the relevant residual rather than copying the prior union formula.

## 4. Adaptive sample number, FIRST and remaining fee

A sample count N(y) may depend measurably on the ORIGINAL full row/field, sources and capture profiles, provided it is a fixed positive integer before the current receiver x integration. Countably splitting by {N=k} and using product kernels makes this legal. It cannot be chosen separately for each current x or source z and then treated as the same common N-witness construction. Any additional outer dependence must be jointly measurable and its source fee explicitly integrated.

For such N(y), the exact displayed cost remains (kappa0 psi_inf/q_-)integral B_N(y)beta(dy). If B_(N(y)+1)/(N(y)+1)<=4lambda epsilon uniformly on the rows being charged, original FIRST gives the residual receiver bound 4epsilon lambda|E|, on the SAME actual accepted set E. Absorption requires finite lambda|E| and a separately proved matching original entry inequality, with 4epsilon<1. This is not a conclusion from FIRST alone.

Since B_N<=a^-n W_nu, a sufficiently large deterministic or measurable count can make the rank coefficient small. This does NOT bound the simultaneous source price by root-polylog: the remaining B_N integral, count choice, and L<R residual still require actual geometry. Choosing N adaptively can trade residual against source price, but cannot erase either of them. No original beta<=Lebesgue or nu<=beta premise is available or used.

## 5. Actual local diagnostics and verdict

Before author-proof reading, an actual Python Fraction run checked 48 finite atomic capture patterns/counts (three witness radii, N=1,...,6): it verified the exact iid minimum inverse-volume expectation and the weighted rank inequality. It also checked 72 finite scalar configurations for monotonicity of chi and equality of the maximum to the minimum-radius source assignment. All PASS. These are finite algebra diagnostics; the measure proof above supplies the general result.

Independent-screen verdict: PASS for the weighted maximum source receipt and J_N<=B_(N+1)/(N+1), with the atom convention and exact costs above. Adaptive FIRST absorption is conditional and source fees remain. The L<R maximum/soft-union residual distinction is a material scope constraint. Await final author proofs before file/hash integration; no repository, Git or other author file was changed.

## 6. Additional independently screened joint budget on both orientations

The maximum-residual caution in Section 3 does not rule out a useful positive majorant. Let Hbar_N be the averaged weighted maximum. On the actual aspect gate v=min(1,(L/R)^(n/2))>=v0, every capturing witness r<=R has chi_r>=v0, so

    Hbar_N>=v0[1-(1-F_yz(R))^N],
    1<=Hbar_N/v0+(1-F_yz(R))^N.

Thus the entire original traffic on this aspect subset has the valid JOINT upper budget

    T_branch <=(kappa0 psi_inf/(q_-v0))integral B_N beta
                       +integral I_y J_N(y)beta(dy).

This is a positive majorant with an amplified covered term, not an equality or a changed exact residual. It does not assume the stronger soft-union residual formula. The second term is a rank integral evaluated at the actual HARD radius R, so after this new inequality it works on both orientations; its derivation does not need the old min(L,R)=R relation.

The iid minimum CDF also gives the exact layercake

    B_N=b^-n integral f_N(F(b))dnu
           +n integral_a^b t^-n-1 integral f_N(F(t))dnu dt,
    f_N(s)=1-(1-s)^N.

For every s in [0,1], f_N(s)/N is nonincreasing in positive integer N (it is the average of 1,(1-s),...,(1-s)^(N-1), multiplied by s). Positive layercake therefore proves B_(N+1)/(N+1)<=B_N/N. Together with Section 2 this proves the rank term bound integral I_y B_N(y)/N beta(dy).

Under the EXPLICIT uniform geometric premise B_N<=4lambda C, the joint budget is

    T_branch <=(16/3)kappa0 psi_inf C/v0 W_beta
                             +(4C/N)lambda|E|.

Original FIRST is used once on the actual E. Original caps alone give C=N, which does not make the receiver coefficient small. Genuine shared redundancy, controlled source cost C/v0, finite E and a proved matching original entry remain necessary for absorption. A variable N(y) gives the corresponding explicit B_N(y)/N(y) receiver coefficient; it is not an automatic bound.

Finally B_N=N B_1 minus the expected integral of the nonnegative excess sum of all inverse-volume capture weights over their maximum. This is an exact geometric redundancy identity; it is not a free improvement of the actual cap. This additional statement screen was saved before reading any R300 author proof.

## 7. Main stopping-file comparison — PASS

Read /tmp/r300_stopping.md after the independent statement screen. Its b_N=B_N/(4lambda) is nondecreasing, bounded by min(N,W_nu/(4lambda a^n)), and b_N/N is nonincreasing. These establish measurable finite N_* and first-dyadic N_d, including zero-source and zero-row cases. The explicit uniform finite dyadic search bound is valid. For the first dyadic d>=N_*, d<2N_* except the unit case; monotonicity of b and its ratio gives b_Nd<=b_d<=(d/N_*)b_N*<=2b_N*. Thus its factor-two certificate compares the actual sampled-capacity cost within the SAME fixed witness law and sufficient rank criterion, as stated.

The N(y)-dependent joint budget is applied rowwise before beta integration; original FIRST gives exactly 4epsilon lambda|E|. Absorption uses the same finite receiver set and separately proved matching original entry, with explicit complement, v0, kappa0 and outer fees. Stopping existence does not bound the resulting source integral by root-polylog. No mathematical correction is needed.

Provisional main-file SHA256: 6e8f9760c46a6fdb2af0c0d7cdc1797efe281c84570d6853611ea8bc915e7d9a

## 8. Geometry author-file comparison — PASS

Read /tmp/r300_geometry.md after the independent screen. Its exact B_N profile, discrete concavity and ratio monotonicity follow from the positive minimum-CDF layercake. The repeated-source saving in (6) charges the actual inverse-volume maximum and is exact. Equation (7) is the correct weighted atom deficit, not an atom-free derivative used at jumps. The frozen minimum-radius pieces and monotonic chi give the actual weighted maximum allocation and exact nu(D_i) receipt; no product-union formula is substituted.

The BOTH-orientation budget (12) is the separately screened positive majorant, retaining 1/v0 only on the paid maximum term; it is explicitly not an asserted bound on the actual maximum residual. Rowwise FIRST and the conditional finite-set matching entry are stated correctly. The original aspect complement, all original low/high masks, fixed-field measurability and outer source/clock costs remain. No correction is needed.

Geometry SHA256: 5845a016b4726244324ed35d58aa228bbad6b2ecc64252deed53c6ed8574ceb0

## 9. Independent marginal-cost screen before the capacity author file

The additional candidate B_(N+1)-B_N<=J_N is valid, including atoms. Conditional on the new witness capturing z with radius r, the inverse-volume maximum can increase only when the preceding N witnesses have NO capturing radius <=r; equal-radius old captures cause zero increment. This probability is (1-F(r))^N with the inclusive CDF. On that event the increment is at most r^-n. Integrate the new capture-radius law and original nu to obtain precisely the J_N upper bound. An equivalent layercake proof uses F(t)(1-F(t))^N<=integral_[a,t](1-F(r))^N dF(r). This statement does not compare different stopping criteria without an additional argument. Await the capacity author's exact sharp-stopping comparison.

## 10. Capacity-file final comparison — PASS

The final /tmp/r300_capacity.md has the independently screened atom-corrected identity, ratio/concavity bounds and marginal potential inequality. The inclusive-CDF strict-increase event in (7) correctly excludes radius ties. Sharp N_J permits zero samples with the explicitly stated empty-cover power convention; its measurability, finite existence and minimal true B-cost within that rule are valid. Its Section 3 uses the OLD ORDERED allocation H, so its stated L>=R residual comparison is legitimate; it does not identify H with the new chi maximum or transfer that exact residual to L<R.

The conservative rule's indices N_B=m_B-1 correctly match B_(N+1)/(N+1). For the new fee comparison (12), with n=N_J(tau/2), increments from n onward are <=tau/2. The choice m=max(n+1,ceil(2B_n/tau)) makes B_m/m<=tau; splitting its two cases yields <=2B_n+tau/2, including n=0. The theorem compares the stated sharp criterion at half tolerance, not an unqualified same-tolerance optimum. Its source fee, original finite matching-entry requirement, and complementary orientation remain explicit. The final evidence-only revision to Section 6 states precisely the reproducible 45 atomic and 180 potential checks; no mathematics changed.

## 11. Final README, evidence and hash receipt — PASS and frozen

Read /tmp/r300_README.md. Its main both-orientation positive budget, B_N shared fee and atom correction, first-dyadic criterion and factor-two cost scope, 4epsilon receiver coefficient, finite-set entry/absorption conditions, v<v0 complement and exact remaining source-cost gap all match the three proofs. It explicitly distinguishes the weighted maximum from the previous product union and does not copy its residual formula. No global root or weak-type closure is claimed. No README correction is needed.

Inspected frozen evidence: main JSON is PASS with no failures and exactly 7742 check-count sum; its 576 marginal-potential and 37 dyadic-cost counts agree with README. Geometry log records 36 cost/rank, 36 redundancy, 9720 max-mask PASS. Capacity log records 45 exact atomic and 180 exact potential PASS. Parent reports the actual reruns; auditor inspected these outputs and did not repeat full scripts. Auditor's independently executed 48 minimum/rank and 72 monotone-maximum Fraction cases are separately documented in Section 5. Finite models establish their stated positive-cell/finite-witness algebra and actual witness caps only, not full original continuous histories or a dimension exponent. Search thresholds not reached inside finite N<=64 are explicitly not impossibility claims.

Final SHA256 bindings:
- /tmp/r300_README.md: 0b1aa3b1e85833ac25477134d0657e9987eae9897696808dd7012779a20c8145
- /tmp/r300_geometry.md: 5845a016b4726244324ed35d58aa228bbad6b2ecc64252deed53c6ed8574ceb0
- /tmp/r300_stopping.md: 6e8f9760c46a6fdb2af0c0d7cdc1797efe281c84570d6853611ea8bc915e7d9a
- /tmp/r300_capacity.md: 04674e697320fd0794010cc925cbeb6a4450f4d4beb1edea3a153a4ff3438b24
- /tmp/r300_checks.py: 3727c056c8549c78265c7f8361c4ae60d3a5fe637fda75a88ef85a357b85c361
- /tmp/r300_checks.json: a549bd04b1c829c62f2cb9630e60b11bf1ea33dca4550d2bc727f306258eeb34
- /tmp/r300_checks_run.log: 0a163fcb7f1dd8920a75c5e26d39b460334fb997784166983ec1172558050e6d
- /tmp/r300_geometry_checks.py: daf338ed22dc055b168e43367d507efebd062804832c90dbdaaa434f303a3955
- /tmp/r300_geometry_checks.log: 494fcfc8d049087d661b07350321f72456c5dbf77636deee462cf58e78878a69
- /tmp/r300_capacity_checks.py: 14023b6db21674d93ade9a4eb139133d3c59823d275136fb6f35135a73132fd6
- /tmp/r300_capacity_checks.log: 732f83866bf20eb33fc51c091d26e88376aa673d06791ae65382ca7f9bc85fc6

Final bounded verdict: PASS. The source integral after stopping, a useful original bound on its dimension growth, the complementary extreme aspect branch, and original global/outer entry/clock ledgers remain unproved. Stopping/atom savings/potential comparison do not erase those costs. Audit frozen; no repository/Git/PDF or other author files changed, and no additional work is proposed.
