#!/usr/bin/env python3
"""R300 exact iid minimum-radius ledger for real positive-volume source cells."""
import json
from pathlib import Path
from fractions import Fraction as F
from itertools import product
FAIL=[];COUNTS={};NS=[1,2,4,8,16,32,64];EPS=[F(1,2),F(1,4),F(1,8),F(1,10),F(1,100)]
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'exact_data':data})
def geom(name,n,kind):
 if kind=='full':xs=[(0,0)]*3;rs=[32]*3;zs=[(2,2),(10,2),(-6,2)];pi=[F(1,2),F(1,3),F(1,6)]
 elif kind=='shift':xs=[(0,0),(16,0),(8,0)];rs=[32]*3;zs=[(v,2) for v in [-14,-6,2,10,18,26,34,100]];pi=[F(1,2),F(1,3),F(1,6)]
 elif kind in ['disjoint','disjoint_nonconstant','rare']:
  xs=[(0,0),(128,0),(256,0)];rs=([32,48,64] if kind=='disjoint_nonconstant' else [32]*3)
  zs=[(v,2) for v in ([2,450] if kind=='rare' else [2,130,258,450])]
  pi=[F(1,1000),F(499,1000),F(1,2)] if kind=='rare' else [F(1,2),F(1,3),F(1,6)]
 else:
  xs=[(0,0),(16,0),(0,16)];rs=[32,48,48 if kind=='tied' else 64];zs=[(2,2),(10,2),(18,2),(26,2),(-14,2),(2,26),(50,50)];pi=[F(1,2),F(1,3),F(1,6)]
  if kind=='redundant':xs.append((0,0));rs.append(32);pi=[F(1,4)]*4
 centers=[list(x)+[0]*(n-2) for x in xs];targets=[list(z)+[2]*(n-2) for z in zs];radii=[F(r,32) for r in rs]
 A=[]
 for i,(x,s) in enumerate(zip(centers,rs)):
  row=[]
  for j,z in enumerate(targets):
   inside=all(2*(abs(u-v)+1)<=s for u,v in zip(x,z));outside=any(2*(abs(u-v)-1)>s for u,v in zip(x,z))
   ck(inside or outside,'whole_cell_inside_or_strictly_outside',{'case':name,'witness':i,'cell':j});row.append(int(inside))
  A.append(row)
 raw=[F((j%5)+1,(j%3)+1) for j in range(len(targets))]
 masses=[sum(v*h for v,h in zip(raw,row)) for row in A]
 scale=min(4*r**n/m for r,m in zip(radii,masses) if m)
 nu=[v*scale for v in raw];rowmass=[sum(v*h for v,h in zip(nu,row)) for row in A]
 for i,(r,m) in enumerate(zip(radii,rowmass)):ck(m<=4*r**n,'same_radius_witness_hardcap',{'case':name,'witness':i,'mass':str(m),'radius':str(r),'n':n})
 # Cells have side1/16 and disjoint interiors; incidence is constant throughout each cell.
 ck(all(any(abs(z[k]-w[k])>=2 for k in range(n)) for j,z in enumerate(targets) for w in targets[:j]),'positive_source_cells_disjoint_interiors',{'case':name})
 groups=[]
 for z in range(len(targets)):
  by={}
  for i,r in enumerate(radii):
   if A[i][z]:by[r]=by.get(r,F(0))+pi[i]
  f=F(0);g=[]
  for r,delta in sorted(by.items()):g.append((r,f,f+delta,delta));f+=delta
  ck(f<=1,'capture_cdf_probability',{'case':name,'cell':z,'F':str(f)});groups.append(g)
 return {'name':name,'n':n,'centers':centers,'side_num':rs,'targets':targets,'pi':pi,'radii':radii,'A':A,'nu':nu,'rowmass':rowmass,'groups':groups}

def verify(case):
 name=case['name'];n=case['n'];nu=case['nu'];pi=case['pi'];radii=case['radii'];A=case['A'];groups=case['groups'];B={};J={}
 onecost=sum(p*m/r**n for p,m,r in zip(pi,case['rowmass'],radii));ck(onecost<=4,'one_draw_mean_cost_cap',{'case':name,'cost':str(onecost)})
 for N in range(1,66):
  b=j=F(0)
  for z,(mass,g) in enumerate(zip(nu,groups)):
   for r,left,right,delta in g:
    diff=(1-left)**N-(1-right)**N;b+=mass*r**(-n)*diff
    j+=mass*r**(-n)*(1-right)**N*delta
    if N<=64:ck((N+1)*(1-right)**N*delta<=(1-left)**(N+1)-(1-right)**(N+1),'termwise_J_B_integral_bound',{'case':name,'N':N,'cell':z,'radius':str(r),'Fleft':str(left),'Fright':str(right)})
  B[N]=b;J[N]=j
  ck(b<=N*onecost<=4*N,'actual_B_cost_le_4N',{'case':name,'N':N,'B':str(b)})
  if N>1:
   ck(B[N]>=B[N-1] and B[N]/N<=B[N-1]/(N-1),'cost_monotone_and_average_decreasing',{'case':name,'N':N})
 for N in range(1,65):
  ck(J[N]<=B[N+1]/(N+1),'J_le_Bnext_over_Nnext',{'case':name,'N':N,'J':str(J[N]),'Bnext':str(B[N+1])})
  ck(0<=B[N+1]-B[N]<=J[N],'actual_cost_increment_le_sharp_J',{'case':name,'N':N,'increment':str(B[N+1]-B[N]),'J':str(J[N])})
 # Direct iid enumeration validates the formula and the per-configuration hard-cap ledger.
 configs=0
 for N in [1,2,4]:
  direct=F(0)
  for tup in product(range(len(pi)),repeat=N):
   prob=F(1)
   for i in tup:prob*=pi[i]
   ledger=[F(0)]*N
   for z,mass in enumerate(nu):
    hits=[k for k,i in enumerate(tup) if A[i][z]]
    if hits:
     k=min(hits,key=lambda k:radii[tup[k]]);ledger[k]+=mass/radii[tup[k]]**n
   ck(all(v<=4 for v in ledger) and sum(ledger)<=4*N,'configuration_min_radius_assignment_cap',{'case':name,'N':N,'tuple':list(tup)})
   direct+=prob*sum(ledger);configs+=1
  ck(direct==B[N],'B_formula_equals_exact_iid_enumeration',{'case':name,'N':N,'direct':str(direct),'formula':str(B[N])})
 table=[{'N':N,'B_N':str(B[N]),'B_N_over_4N':str(B[N]/(4*N)),'J_N':str(J[N]),'B_Nplus1_over_Nplus1':str(B[N+1]/(N+1)),'J_over_Bnext_budget':str(J[N]/(B[N+1]/(N+1))) if B[N+1] else '0'} for N in NS]
 stops=[]
 for eps in EPS:
  cap=next((N for N in range(1,65) if B[N]/(4*N)<=eps),None)
  dyad=next((N for N in NS if B[N]/(4*N)<=eps),None)
  jstop=next((N for N in range(1,65) if B[N+1]/(N+1)<=4*eps),None)
  sharpstop=next((N for N in range(1,65) if J[N]<=4*eps),None)
  if cap is not None and dyad is not None:
   ck(B[cap]<=B[dyad]<=2*B[cap],'first_dyadic_cost_two_approx',{'case':name,'epsilon':str(eps),'Nstar':cap,'Ndyadic':dyad,'Bstar':str(B[cap]),'Bdyadic':str(B[dyad])})
  stops.append({'epsilon':str(eps),'capacity_stop_first_integer_N':cap,'capacity_stop_first_dyadic_N':dyad,'capacity_cost_b_Nstar':str(B[cap]/4) if cap else None,'capacity_cost_b_Ndyadic':str(B[dyad]/4) if dyad else None,'J_budget_stop_first_integer_N':jstop,'J_budget_is_not_sharp_J':True,'sharp_J_stop_first_integer_N':sharpstop,'sharp_J_at_stop':str(J[sharpstop]) if sharpstop else None,'sharp_stop_true_cost_b_N':str(B[sharpstop]/4) if sharpstop else None,'search_limit':64,'unmet_label':'not_met_through_64' if cap is None or jstop is None else 'both_met'})
 return {'name':name,'dimension':n,'witnesses':len(pi),'source_cells':len(nu),'source_cell_volume':str(F(1,16)**n),'uncovered_positive_cells':sum(not g for g in groups),'radius_values':[str(r) for r in radii],'pi':[str(p) for p in pi],'source_cell_masses':[str(m) for m in nu],'exact_witness_hard_responses':[str(m/r**n) for m,r in zip(case['rowmass'],radii)],'direct_iid_configurations':configs,'specified_N_table':table,'adaptive_stops':stops,'geometry':{'coordinate_denominator':32,'source_cell_halfwidth_num':1,'witness_center_num':case['centers'],'witness_side_num':case['side_num'],'source_cell_center_num':case['targets'],'witness_by_cell_incidence':A}}
settings=[('same_scale_overlap',[('full_overlap',4,'full'),('shifted_overlap',4,'shift'),('disjoint_equal',4,'disjoint')]),('unequal_tied_separated',[('heterogeneous_n4',4,'heterogeneous'),('tied_radii_n8',8,'tied'),('redundant_witness_n8',8,'redundant')]),('expanded',[('heterogeneous_n16',16,'heterogeneous'),('separated_nonconstant_n16',16,'disjoint_nonconstant'),('rare_capture_n16',16,'rare')])]
stages=[{'name':stage,'cases':[verify(geom(name,n,kind)) for name,n,kind in specs]} for stage,specs in settings]
out={'status':'PASS' if not FAIL else 'FAIL','scope':'Exact Fraction finite actual closed cubes and disjoint positive-volume source cells, each wholly contained or strictly outside each witness; therefore incidence and the displayed min-radius integrals hold for arbitrary L1 densities with these cell masses. Checks certify same-radius hard caps at the finite witness centers only, not the full continuous maximal-cap/original history hypotheses. No general dimension-order, universal dense-case, original-operator, or FULL closure claim.','lambda':'1','N_table':NS,'adaptive_search':'Every integer N=1..64; dyadic menu1,2,4,8,16,32,64. Null stop means condition not met within search, not impossibility.','check_counts':COUNTS,'failures':FAIL,'definitions':{'B_N':'sum_z mass_z sum_r r^-n[(1-F(r-))^N-(1-F(r))^N]','J_N':'sum_z mass_z sum_r r^-n (1-F(r))^N DeltaF(r)','J_budget':'B_(N+1)/(N+1) is an upper bound for J_N, not the sharp J_N itself','sharp_J_stop':'first N>=1 with exact J_N<=4epsilon','increment':'0<=B_(N+1)-B_N<=J_N','capacity_stop':'first N with b_N/N<=epsilon, b_N=B_N/4','J_stop':'first N with B_(N+1)/(N+1)<=4epsilon'},'stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'status':out['status'],'check_counts':COUNTS,'failures':FAIL,'cases':sum(len(s['cases']) for s in stages),'adaptive_epsilon_1_over_8':[{'name':c['name'],'stops':next(x for x in c['adaptive_stops'] if x['epsilon']=='1/8')} for s in stages for c in s['cases']]},indent=2))
