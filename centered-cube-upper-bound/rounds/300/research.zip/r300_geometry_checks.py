from fractions import Fraction as F
from itertools import product
ct={'cost_rank':0,'redundancy':0,'maxmask':0}
stages=[([F(1),F(1),F(1)],[F(1,3)]*3,[[1,1,1],[0,0,0]]),
 ([F(1),F(3,2),F(2)],[F(1,2),F(1,3),F(1,6)],[[1,0,1],[1,1,0],[0,1,1]]),
 ([F(1),F(5,4),F(2)],[F(1,10),F(3,10),F(6,10)],[[1,0,0],[0,1,0],[0,0,1],[1,1,1]])]
for n in [2,4,8]:
 for rs,pp,caps in stages:
  BB=[F(0)]; mm=[F(1,len(caps))]*len(caps)
  for N in range(1,5):
   B=red=F(0)
   for inds in product(range(3),repeat=N):
    prob=F(1)
    for i in inds:prob*=pp[i]
    for capture,mass in zip(caps,mm):
     ww=[rs[i]**(-n)*capture[i] for i in inds]
     B+=prob*mass*max(ww);red+=prob*mass*(sum(ww)-max(ww))
     for L,R in [(F(1),F(2)),(F(2),F(1)),(F(3,2),F(3,2))]:
      chis=[min(F(1),(L/rs[i])**(n//2)*min(F(1),(R/rs[i])**(3*n//2)))*capture[i] for i in inds]
      v=min(F(1),(L/R)**(n//2))
      ordered=int(any(capture[i] and rs[i]<=R for i in inds))
      assert max(chis)>=v*ordered;ct['maxmask']+=1
   B1=sum(m*sum(p*r**(-n)*c for p,r,c in zip(pp,rs,cap)) for cap,m in zip(caps,mm))
   assert B==N*B1-red;ct['redundancy']+=1
   J=rhs=F(0)
   for cap,m in zip(caps,mm):
    cdf=F(0); prev=F(0)
    for r in sorted(set(rs)):
     atom=sum(p*c for p,r0,c in zip(pp,rs,cap) if r0==r)
     cdf+=atom
     J+=m*r**(-n)*(1-cdf)**N*atom
     f=1-(1-cdf)**N
     rhs+=m*r**(-n)*(f-prev);prev=f
   assert B==rhs and J<=B/N
   BB.append(B)
   if N>1:assert B/N<=BB[N-1]/(N-1)
   if N>1:assert BB[N]-BB[N-1]<=BB[N-1]-BB[N-2]
   ct['cost_rank']+=1
print('PASS',ct)
