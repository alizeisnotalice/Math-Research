# R300: measurable capacity stopping with a factor-two cost certificate

This is a constructive consequence of the R300 joint minimum-witness theorem. It is NOT a proof of a general root bound on the cost selected below. All original sources, low,m>M, FIRST, actual receiver set E, e_g,m,q, history masks and Lebesgue receiver measure are retained. Fix one outer field with lambda>0, q_-=3lambda/4, a>0, b<=2a, finite positive L1 sources beta,nu and 0<v0<=1. The target branch is the original traffic with v(L,R)=min(1,(L/R)^(n/2))>=v0. The original outer multiplier is not omitted.

For the canonical original receiver row probability pi_y, let M_N(y,z) be the smallest actual hard radius of N iid accepted witnesses capturing z. Its reciprocal is zero if no witness captures z. Define

 B_N(y)=E integral M_N(y,z)^(-n)1_{M_N finite}nu(dz),
 b_N(y)=B_N(y)/(4lambda),   N=1,2,... .

Zero rows I_y=0 have zero traffic and receive b_N=0. Positive Tonelli and finite product kernels make B_N measurable in y. The R300 geometry/capacity notes prove

 0<=b_N<=min(N,W_nu/(4lambda a^n)),
 b_N nondecreasing, b_N/N nonincreasing,
 T_{v>=v0}<= (16/3)psi_inf kappa0/v0 integral b_N(y)beta(dy)
                    +4lambda integral I_y b_N(y)/N beta(dy). (1)

The last formula is also valid for measurable positive-integer N(y), fixed before the actual x integral. The theorem is applied rowwise and then Tonelli; there is no common random-field selection assumption. It is a positive majorant estimate, not an identity for the soft-union residual.

## 1. A finite stopping rule for every row

Fix epsilon in (0,1/4). Let

 N_*(y)=min{N>=1:b_N(y)/N<=epsilon},
 N_d(y)=min{2^k:k>=0, b_(2^k)(y)/2^k<=epsilon}.          (2)

Both are measurable: their level sets are finite intersections of inequalities between measurable functions. They exist for all rows because b_N<=W_nu/(4lambda a^n), and hence b_N/N tends to zero. A uniform finite dyadic search bound is the first 2^k>=max(1,W_nu/(4lambda a^n epsilon)). No numerical finiteness is used to justify this assertion. When W_nu=0 all traffic and capacities vanish, and N_*=N_d=1; division by W_nu is never required.

Among all deterministic integers N satisfying the row residual criterion b_N/N<=epsilon, N_* minimizes the true cost b_N since b_N is nondecreasing. The dyadic rule has the exact approximation certificate

 b_(N_*) <= b_(N_d) <= 2 b_(N_*).                       (3)

Indeed take d to be the first power of two with d>=N_*. Then d<2N_* unless N_*=1, and b_d/d<=b_(N_*)/N_*<=epsilon. Thus N_d<=d. Monotonicity of b and of b_N/N gives b_(N_d)<=b_d<=(d/N_*)b_(N_*)<=2b_(N_*). This also handles b_(N_*)=0 without division by it.

More generally (3) yields b_(N_d)<=2b_K for ANY measurable feasible integer rule K(y). This is optimality only within this fixed canonical witness law and the stated rank-budget criterion. It is not optimality over other witness probabilities, all geometry covers, or all estimates of the actual residual. The criterion itself is sufficient and may be conservative.

## 2. Original receiver budget, not a source-product bound

Inserting N_d into (1) and applying original FIRST at the same receivers gives

 T_{v>=v0} <= (16/3)psi_inf kappa0/v0 integral b_(N_d)beta
                       +4epsilon lambda|E|,           (4)

since integral I_y beta(dy)=integral_E [integral p_y beta/q]dx<=|E|. The receiver measure is not replaced by a probability. For a finite receiver truncation X=lambda|E|, IF the original argument separately has the matching entry

 X<=P_paid+T_{v>=v0}+R_complement,

then

 (1-4epsilon)X <= P_paid+R_complement
                    +(16/3)psi_inf kappa0/v0 integral b_(N_d)beta. (5)

The actual entry and payment of R_complement, including v<v0, remain requirements. At epsilon=1/8 the residual coefficient is exactly1/2. One cannot absorb an infinite X or a different extended receiver set. Outer integration likewise requires the original source/clock ledger, retaining all lambda, kappa0 and v0 dependencies.

## 3. What remains to prove geometrically

The selected source price is an explicit finite-sampling maximum of actual inverse cube volumes. It no longer contains a fresh W_nu charge per radius or the full-soft envelope S multiplying a source-product remainder. The stopping exists for arbitrary finite original sources, with no cumulative-support cover or short-radius-span premise.

Nevertheless the only automatic universal upper bound is b_(N_d)<=W_nu/(4lambda a^n), which can be much larger than sqrt(n). Thus (4) is a valid all-input conditional-branch capacity budget, NOT the requested uniform root estimate. The central missing geometric theorem is a bound for integral b_(N_d)beta/v0 in the original source ledger, or a complementary geometry that makes this price unnecessary on expensive rows. Merely giving that price a new symbol would not pay it; this note contributes the constructive finite stopping rule, its quantified approximation guarantee and the actual receiver absorption, not a claimed estimate of its dimension growth.

The fractional-normalization skill is used only to check positivity, homogeneity and zero-mass branches. No external strong-duality or transport theorem is invoked. Numerical checks of finite configurations belong to the separate R300 checker and do not certify the all-input cost bound.
