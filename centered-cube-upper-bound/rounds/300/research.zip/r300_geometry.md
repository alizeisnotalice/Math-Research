# R300 — one actual witness-mass ledger for coverage and weighted rank

## 1. Precise unconditional theorem and the conditional success criterion

Retain exactly the original setting of R298/R299: arbitrary finite positive L1 beta,nu; physical scales a<=L,R<=b<=2a; q_-=3lambda/4<=q<=lambda; original accepted receivers E with original FIRST and maximal hard cap; and complete original positive low-pe,m>M traffic dT=I0 p_y h_R/q dx beta(dy)nu(dz). All original masks, full e_g,m, common s,L,R, unique bands and outer prices remain. Write

    kappa0=2K/(ell M), gamma=1+1/n,
    psi_inf=3-2/(3gamma^n),
    U_y(u)=1_E(u)p_y(u)/q(u), I_y=integral U_y du,
    pi_y(du)=U_y(u)du/I_y when I_y>0.

Zero rows have zero traffic and all quantities below are zero there. I_y<=S/q_-, S=(1+n log(b/a))Csoft_n, as already proved; this is only used when explicitly stated.

Sample N>=1 common dummy receivers u_1,...,u_N from pi_y. Set r_i=R(u_i). For a hard source z put r_min=min{r_i:z in Q_(r_i)(u_i)} if any such witness exists. Define its weight to be zero if none exists. The TRUE expected normalized source cost is

    B_N(y)=E integral r_min(y,z)^(-n)1_union(z)nu(dz)
          =E integral max_i[r_i^(-n)1_(Q_(r_i)(u_i))(z)]nu(dz).
                                                               (1)

It is a concrete finite-sample source integral, not a renamed original traffic remainder. No original soft source mass appears inside B_N, except through the actual receiver probability pi_y. In particular nu is never compared to beta.

Let

    v(L,R)=min(1,(L/R)^(n/2)), 0<v0<=1,
    T_v0=T restricted to the actual gate v(L,R)>=v0.

Then the unconditional joint budget is

    T_v0 <= [kappa0 psi_inf/(q_-v0)] integral B_N(y)beta(dy)
                  +(1/N)integral I_y B_N(y)beta(dy).     (2)

The SAME B_N controls both the covered source price and the residual receiver price. In particular the second term has NO factor 1/v0. This is valid on both orientations; v0=1 includes all L>=R traffic. There is no per-scale W_nu payment.

A sufficient geometric success condition is B_N(y)<=4lambda C for beta-almost every relevant row. Then ORIGINAL FIRST gives the actual source-plus-receiver receipt

    T_v0 <=(16/3)psi_inf kappa0(C/v0)W_beta
                           +(4C/N)lambda|E|.           (3)

Thus C/v0 root-polylog, together with 4C/N<1, would provide a root-polylog source cost and a potentially absorbable receiver term. Absorption additionally requires a proved original entry inequality with this SAME finite receiver measure; section 6 states that interface exactly. Neither the geometric premise nor the entry inequality is asserted automatically.

The original hard cap alone gives B_N<=4lambda N. Substituting that bound in (3) gives receiver coefficient 4, not an absorption. A useful proof must exploit the TRUE cost or establish additional geometry reducing it. No counterexample or exclusion campaign is needed for this limitation: it is visible in the constants of the proved ledger.

## 2. Explicit source-cost profile and actual repetition savings

For fixed y,z, push the capture subprobability

    1{z in Q_(R(u))(u)}pi_y(du)

forward by R(u), obtaining mu_yz on [a,b]. Its inclusive CDF is

    F_yz(t)=mu_yz([a,t]), m_yz=F_yz(b)<=1.

For f_N(t)=1-(1-t)^N, the minimum-witness distribution has CDF f_N(F_yz(t)). By the positive identity r^(-n)=b^(-n)+n integral_r^b t^(-n-1)dt,

    B_N(y)=b^(-n)integral f_N(m_yz)nu(dz)
             +n integral_a^b t^(-n-1)
                         integral f_N(F_yz(t))nu(dz)dt. (4)

This formula includes atoms at a,b and noncapture mass. It is computable from the original actual capture profile without constructing a measurable global random choice of row witnesses.

Since f_N(t) is increasing and concave as a sequence in N, B_N is increasing and discretely concave, with B_0=0. Also

    B_(N+1)/(N+1)<=B_N/N.                               (5)

Indeed f_N(t)/N is the average of the decreasing sequence t(1-t)^k, 0<=k<N. Integrating the positive expression (4) proves (5).

The first-witness cost is B_1=integral R(u)^(-n)nu(Q_(R(u))(u))pi_y(du)<=4lambda. More precisely define the nonnegative repeated-source savings

    R_N(y)=E integral [sum_i r_i^(-n)1_cube_i(z)
                           -max_i r_i^(-n)1_cube_i(z)]nu(dz).

Then EXACTLY

    B_N=N B_1-R_N.                                     (6)

Thus both underfilled original witness cubes and genuine repeated source mass can reduce the price. This is an explicit geometric saving, rather than a declaration that disjoint source pieces make all repetition free. Adding one witness raises the configuration cost by at most its own r^(-n)nu(Q_r), so also B_(N+1)-B_N<=4lambda. Shared sources at different radii are charged using their actual maximum reciprocal-volume weight.

Equation (6) gives an equivalent checkable sufficient condition for (3): N B_1-R_N<=4lambda C. To obtain C much smaller than N, the actual mass must be sufficiently underfilled or redundant. The proof does not assume this on all inputs.

## 3. Weighted rank is bounded by that SAME source cost

Define the actual weighted rank integral

    J_N(y)=integral nu(dz)integral_[a,b]
                        r^(-n)(1-F_yz(r))^N mu_yz(dr).

Put g_N(t)=[1-(1-t)^(N+1)]/(N+1). At an atom r of mu_yz with mass d and CDF endpoints F-,F, set

    delta_(N,yz,r)=g_N(F)-g_N(F-)-(1-F)^N d>=0.

The sign follows by integrating the decreasing function (1-t)^N over the atom interval. Quantile substitution on the nonatomic part, together with these atom intervals, gives the EXACT identity

    J_N(y)=B_(N+1)(y)/(N+1)
              -integral nu(dz)sum_(r atom) r^(-n)delta_(N,yz,r).
                                                               (7)

The nonnegative series is justified by Tonelli; all weights are bounded by a^(-n) and nu is finite. Equality without the deficit holds for every nonatomic capture-radius measure, including singular continuous ones. No tie randomization or missing endpoint convention is required.

Combining (7) and (5) gives the key unconditional joint estimate

    J_N(y)<=B_(N+1)(y)/(N+1)<=B_N(y)/N.                 (8)

Unlike the earlier replacement by a^(-n)W_nu/(N+1), this retains actual source overlap, the full radius distribution and the hard-source mass measured by the finite witness cover. It does not itself prove B_N/N is small. The same B_N is now available in both parts of the original traffic calculation.

## 4. Minimum-radius source pieces and the paid max mask

For each finite witness configuration assign every source z in its union to a containing witness of smallest radius, breaking ties by index. The measurable pieces D_i are disjoint and lie in their own witness cubes. Use the R299 penalty

    chi_r(L,R)=min{1,(L/r)^(n/2)min[1,(R/r)^(3n/2)]}.

It is nonincreasing in r. Hence the configuration mask

    H_config^max=sum_i 1_(D_i)(z)chi_(r_i)(L,R)
                 =max_i[chi_(r_i)(L,R)1_cube_i(z)]      (9)

is in [0,1]. Its averaged mask is Hbar_N^max=E H_config^max. It is generally DIFFERENT from the R299 product-union mask 1-(1-D)^N; no such identity is claimed here.

For completeness, R299's single-witness estimate uses the actual low/high heights p<=kappa0(LR)^(-n/2) and p<=kappa0 gamma^(n/2)L^(-n/4)R^(-3n/4). For R<r, the penalized product is bounded by kappa0 r^(-2n)1_Qr, the central block of the own-scale envelope. For R>=r, chi absorbs the two soft-scale factors and gives the same own-scale envelope. Its integral is r^(-n)Psi_G((b/r)^n)<=psi_inf r^(-n). This applies to a frozen source subset D_i with its original nu mass; it imposes no actual minscale>=r gate.

Apply that rowwise estimate to each D_i before averaging. Positive Tonelli gives

    T_(Hbar_N^max)
      <=(kappa0/q_-)integral beta(dy) E sum_i
                   r_i^(-n)Psi_G((b/r_i)^n)nu(D_i)
      <=(kappa0 psi_inf/q_-)integral B_N(y)beta(dy).     (10)

The first displayed term is the exact available fee, retaining Psi_G if desired. The second is a clean comparison with the same B_N in (8). This proves actual savings over charging N maximum caps whenever the true normalized source mass is smaller.

The source pieces are frozen for each row and configuration throughout the x integral. Dependence of chi and the resulting average mask on actual L,R is justified by the already proved single-witness penalty theorem. No receiver-dependent mask is incorrectly inserted into a source-only theorem. Finite product integrals give measurability, and zero rows are handled as in section 1.

## 5. The L<R interface: only the covered price pays 1/v0

For EVERY witness with r<=R, elementary comparison in chi gives

    chi_r(L,R)>=v(L,R)=min(1,(L/R)^(n/2)).

Therefore, for any actual edge,

    Hbar_N^max(x,y,z)
        >=v(L,R)[1-(1-F_yz(R))^N].                     (11)

Indeed the bracket is exactly the probability that at least one of the N common witnesses captures z at radius at most the actual hard radius R. On that event its chi is at least v, hence so is the maximum. This argument remains true when L<R; it does not assert the old rank formula for the full Hmax residual.

On v>=v0, (11) gives the POINTWISE positive domination

    1<=Hbar_N^max/v0+(1-F_yz(R))^N.                     (12)

Multiply (12) by the ORIGINAL traffic density and integrate only on that actual aspect branch. The first term is bounded by (10)/v0. For the second term, retain the original kernels until writing U_y dx=I_y pi_y; then drop remaining nonnegative masks and use the original hard support and normalization. It is at most

    integral I_y J_N(y)beta(dy)
                  <=(1/N)integral I_y B_N(y)beta(dy).  (13)

This proves (2). The rank term in (12)-(13) is NOT divided by v0. In particular we do not bound the actual Hmax residual by the old ordered residual on L<R, which would be false as a general inference. Instead (12) is a direct domination of the entire qualified traffic, absorbing the mismatch algebraically into the paid cover term.

The exact identity T=T_(Hbar_N^max)+T_(1-Hbar_N^max) remains valid on all edges. Equation (2) controls all traffic on v>=v0 without needing a new capture threshold there. The complementary aspect branch v<v0 is still explicit unless another argument pays it. For v0=1 this complementary branch is L<R; smaller v0 extends coverage at exactly the stated price.

## 6. FIRST, source qualification and the remaining global gap

Under B_N<=4lambda C on the relevant beta rows,

    integral I_y B_N beta(dy)<=4lambda C integral I_y beta(dy)
        =4lambda C integral_E [integral p_y beta(dy)/q(x)]dx
        <=4lambda C |E|.                               (14)

This uses original FIRST at true accepted receivers, not on an enlarged spatial envelope or a changed source. Combining with (2) proves (3). If the premise holds only on a measurable row set Y, the same argument pays the original traffic restricted to y in Y; restricted FIRST is bounded by the original FIRST. The y-not-in-Y traffic must then remain explicitly in the complement.

The sharper nonuniform budget (2) is always valid. One may use the exact integral integral I_y B_N beta instead of a uniform C bound if that joint original quantity is known. Replacing it by (S/q_-)integral B_N beta gives a source price with factor S/N, but this can be large; it is not silently called root order.

For a receiver absorption statement, restrict to a setting with X_E=lambda|E|<infinity and require a separately proved matching original entry

    X_E<=P_paid+T_v0+R_other.

Only then, if 4C/N<1, (3) implies

    (1-4C/N)X_E
       <=P_paid+(16/3)psi_inf kappa0(C/v0)W_beta+R_other. (15)

No finite truncation preserving that entry is invented here. The original outer factor Lambda(xi) multiplies (2) or (3) inside the original xi ledger. All beta/nu copies and clock fees remain as displayed conditional quantities; a scale decomposition cannot restart them for free.

The completed improvement is the common mass ledger (2), including the exact repetition saving (6), atom-corrected rank identity (7), and the asymmetric mismatch absorption (12). The concrete missing geometry is to bound B_N, or its displayed beta- and I_y beta-weighted integrals, at a useful level on the original inputs while also controlling v<v0 and the original outer/entry ledger. Original hard caps give only B_N<=4lambda N. They do not imply the redundancy needed for a source-linear root estimate with small receiver coefficient. No additional source density, nu<=beta comparison, or automatic union-cover hypothesis is used.

## 7. Actual finite checks

A local exact-Fraction run passed three stages: equal-radius shared witnesses including noncapture; unequal-radius overlapping capture patterns; and predominantly disjoint patterns with a shared source. Across n=2,4,8 and N=1,...,4 it passed 36 cost/rank/profile and concavity checks, 36 exact repetition-savings identities, and 9720 max-mask/mismatch checks. These finite capture patterns test the algebra, not the existence of a root budget for all original inputs. Exact reproducible code follows and writes no files.

```python
from fractions import Fraction as F
from itertools import product
ct={'cost_rank':0,'redundancy':0,'maxmask':0}
stages=[([F(1),F(1),F(1)],[F(1,3)]*3,[[1,1,1],[0,0,0]]),
 ([F(1),F(3,2),F(2)],[F(1,2),F(1,3),F(1,6)],[[1,0,1],[1,1,0],[0,1,1]]),
 ([F(1),F(5,4),F(2)],[F(1,10),F(3,10),F(6,10)],[[1,0,0],[0,1,0],[0,0,1],[1,1,1]])]
for n in [2,4,8]:
 for rs,pp,caps in stages:
  BB=[F(0)]; mm=[F(1,len(caps))]*len(caps)
  for N in range(1,5):
   B=red=F(0)
   for inds in product(range(3),repeat=N):
    prob=F(1)
    for i in inds:prob*=pp[i]
    for capture,mass in zip(caps,mm):
     ww=[rs[i]**(-n)*capture[i] for i in inds]
     B+=prob*mass*max(ww);red+=prob*mass*(sum(ww)-max(ww))
     for L,R in [(F(1),F(2)),(F(2),F(1)),(F(3,2),F(3,2))]:
      chis=[min(F(1),(L/rs[i])**(n//2)*min(F(1),(R/rs[i])**(3*n//2)))*capture[i] for i in inds]
      v=min(F(1),(L/R)**(n//2))
      ordered=int(any(capture[i] and rs[i]<=R for i in inds))
      assert max(chis)>=v*ordered;ct['maxmask']+=1
   B1=sum(m*sum(p*r**(-n)*c for p,r,c in zip(pp,rs,cap)) for cap,m in zip(caps,mm))
   assert B==N*B1-red;ct['redundancy']+=1
   J=rhs=F(0)
   for cap,m in zip(caps,mm):
    cdf=F(0); prev=F(0)
    for r in sorted(set(rs)):
     atom=sum(p*c for p,r0,c in zip(pp,rs,cap) if r0==r)
     cdf+=atom
     J+=m*r**(-n)*(1-cdf)**N*atom
     f=1-(1-cdf)**N
     rhs+=m*r**(-n)*(f-prev);prev=f
   assert B==rhs and J<=B/N
   BB.append(B)
   if N>1:assert B/N<=BB[N-1]/(N-1)
   if N>1:assert BB[N]-BB[N-1]<=BB[N-1]-BB[N-2]
   ct['cost_rank']+=1
print('PASS',ct)
```

Only /tmp/r300_geometry.md was written. No other author file, earlier frozen proof or Git state was changed.
