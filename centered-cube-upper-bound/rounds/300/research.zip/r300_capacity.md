# R300 — true minimum-radius capacity, exact atomic rank correction, and sharp row stopping

## 1. Exact capacity/rank theorem

Use the ORIGINAL row law pi_y from R298/R299, proportional to 1_E(u)p_y(u)/q(u), with I_y its normalizing integral. All original e_g,m, kernels, FIRST and source/history masks remain unchanged. Zero I_y rows have zero traffic and all capacities zero. For a nonzero row, take N independent witnesses U_i with law pi_y and define

    M_N(z)=min{R(U_i): z in Q_(R(U_i))(U_i), i<=N},

with M_N(z)=infinity if none captures z. Let M_0=infinity and

    B_N(y)=E integral M_N(z)^(-n)1{M_N(z)<infinity}nu(dz),
    J_N(y)=integral nu(dz)integral_[a,b]
                     r^(-n)(1-F_yz(r))^N mu_yz(dr),

where mu_yz is the captured-radius subprobability and F_yz its inclusive CDF from R299. Here N>=0 is an integer and B_0=0. At N=0 all zero-th powers are interpreted as one, consistently with an empty cover. These definitions include all samples, not a union restricted to an independently chosen source subset.

For each z,

    P{M_N(z)<=t}=1-(1-F_yz(t))^N.                       (1)

Consequently, with g_N(u)=[1-(1-u)^(N+1)]/(N+1),

    B_(N+1)(y)/(N+1)-J_N(y)=E_N^atom(y)>=0,             (2)

where the EXACT correction is

    E_N^atom(y)=integral nu(dz) sum_(s:mu_yz({s})>0) s^(-n)
       [g_N(F_yz(s))-g_N(F_yz(s-))
                   -(1-F_yz(s))^N mu_yz({s})].         (3)

Thus the guessed inequality J_N<=B_(N+1)/(N+1) is correct. Equality holds if mu_yz is nonatomic for nu-almost every z, including arbitrary singular continuous parts. More generally equality holds exactly when the nonnegative weighted correction (3) vanishes. At N=0 it always vanishes. No tie randomization is used.

Proof: the law in (1) follows from independence of the witnesses. Its Lebesgue–Stieltjes measure is d[1-(1-F)^N]. Therefore B_(N+1)/(N+1) is integral r^(-n)d(g_N(F)), then integrated against nu. R299's exact inclusive-CDF chain rule says d(g_N(F)) differs from (1-F)^N dF only by the displayed nonnegative atomic measure. Integrating it proves (2)-(3). Equivalently the R299 quantile proof covers all continuous/atomic mixtures without a differentiability assumption.

A directly computable cumulative formula is

    B_N(y)=b^(-n) integral [1-(1-F_yz(b))^N]nu(dz)
       +n integral_a^b t^(-n-1)
                      integral[1-(1-F_yz(t))^N]nu(dz)dt. (4)

This also proves measurability in y. It retains the complete physical radii rather than replacing them by a.

## 2. Concavity and a stronger capacity-potential relation

The sequence B_N is increasing and discretely concave:

    B_(N+1)-B_N>=0,
    B_(N+2)-B_(N+1)<=B_(N+1)-B_N,
    B_N/N is nonincreasing for N>=1.                    (5)

These follow from (4), since 1-(1-F)^N has those properties, with B_0=0. The actual original witness hard cap gives

    B_N(y)<=min{4lambda N, a^(-n)W_nu}.                 (6)

To prove the first bound, assign each captured source z to a smallest-radius capturing witness, breaking ties by index. Its assigned pieces D_i are disjoint, and

    integral M_N(z)^(-n)nu(dz)=sum_i R(U_i)^(-n)nu(D_i)
       <=sum_i R(U_i)^(-n)nu(Q_(R(U_i))(U_i))<=4lambda N.

Every cap is used at the SAME actual accepted witness and its SAME legal radius. Averaging proves (6).

The useful additional potential inequality is

    0<=B_(N+1)(y)-B_N(y)<=J_N(y).                       (7)

Proof: for fixed z put W_i=R(U_i)^(-n)1{witness i captures z}. Its capacity is E max_(i<=N) W_i. An additional sample of captured radius r increases this maximum by (r^(-n)-max_old W_i)_+. This is <=r^(-n) times the event that every old W_i is STRICTLY less than r^(-n). That event has probability (1-F_yz(r))^N, including all radius ties in F. Integrate the new sample against mu_yz and then nu. This proves (7). It is not the generally false reverse inequality J_N<=B_(N+1)-B_N.

For each fixed finite source instance, B_N is bounded and B_N/N tends to zero. This is only a nonuniform eventual fact, not a uniform useful sublinear rate at N~sqrt(n). Indeed the limit is

    B_infinity(y)=integral r_*(y,z)^(-n)1{mu_yz([a,b])>0}nu(dz),
    r_*(y,z)=inf support(mu_yz),

and it can be large. Monotone convergence of sample minima proves this formula, with 0<=B_infinity<=a^(-n)W_nu. Also J_N decreases to zero by dominated convergence; (6)-(2) already give a finite uniform-in-row envelope for each fixed instance.

## 3. Measurable sharp stopping and its exact actual cost

Fix tau>0 in capacity units (later tau=epsilon lambda). Define

    N_J(y;tau)=min{N>=0: J_N(y)<=tau}.                  (8)

It is finite on every relevant row and measurable, since J_N are measurable and decrease to zero. This is a deterministic choice from the original row law before its witness configuration is averaged, not an unproved optional-sampling argument. Row-dependent finite sample products are legal by their countable decomposition over {N_J=N}.

The original covered allocation is

    H(y,x,z)=1-[1-C_y(min(L(x),R(x)),z)]^(N_J(y;tau)).

R298/R297's rowwise source payment, averaged with this row-dependent law, gives its TRUE capacity expense

    T_H<=(kappa0 psi_inf/q_-) integral B_(N_J(y;tau))(y)beta(dy),
    kappa0=2K/(ell M), psi_inf=3-2/(3gamma^n).           (9)

The exact source envelope could retain Psi_G((b/M_N)^n) inside the expectation; (9) bounds it by psi_inf. It is the expectation of the minimum-radius capacity itself, rather than the crude sample-count bound 4lambda N_J. No cap on B_N beyond those proved in Section 2 is assumed.

On the L>=R remainder, R299 gives

    T_((1-H),L>=R)<=integral I_y J_(N_J(y;tau))(y)beta(dy)
       <=tau integral I_y beta(dy)<=tau|E|.            (10)

The final inequality is precisely original FIRST at original receivers. Thus tau=epsilon lambda gives epsilon lambda|E|. For finite X_E=lambda|E|, a separately proved matching entry X_E<=paid+this residual+other would allow (1-epsilon)X_E<=paid+other. This note does not assume that entry or the finiteness truncation has already been supplied. The L<R part does not acquire a rank formula merely from this stopping construction.

Because B_N increases, (8) minimizes TRUE B_N among integer sample counts satisfying the POINTWISE row target J_N<=tau. This is the exact optimal row capacity cost for this deterministic sample-count rule. FIRST bounds integral I_y beta, but does not bound the independent source fee integral B_(N_J)beta in (9).

## 4. Sharp J-stop versus the conservative capacity stop

Define the conservative rule with the indices made explicit:

    m_B(y;tau)=min{m>=1:B_m(y)/m<=tau},
    N_B(y;tau)=m_B(y;tau)-1.                            (11)

Equation (2) implies N_J(y;tau)<=N_B(y;tau). For nonatomic mu_yz they are identical. Atoms can make the sample counts very different because (3) is a genuine positive saving.

There is also a useful TRUE-fee comparison, not just a comparison of sample counts:

    B_(N_B(y;tau))(y)
       <=2 B_(N_J(y;tau/2))(y)+tau/2.                  (12)

Proof: let n=N_J(tau/2), b_n=B_n. For k>=n, (7) and decreasing J give B_(k+1)-B_k<=tau/2. Choose

    m=max{n+1,ceil(2b_n/tau)}.

Then B_m<=b_n+(m-n)tau/2 and m>=2b_n/tau, hence B_m/m<=tau. Thus m_B<=m and B_(N_B)<=B_m. If m=n+1 its fee is <=b_n+tau/2; otherwise it is <=2b_n+tau/2. This proves (12), including n=0. So a capacity-only stop is within a factor two plus a small additive capacity of the sharp rule with half the residual tolerance. This result uses actual diminishing capacity increments; it requires no guessed early sublinearity. The separate dyadic implementation in the main stopping note need not be repeated here.

A one-radius capture atom shows the possible sample-count saving: if every witness captures a fixed source portion at the same radius, with total normalized capacity w, then B_N=w for N>=1 while J_N=0 for N>=1. For tau<w, the sharp count is one, whereas the conservative count is ceil(w/tau)-1. Their TRUE main capacity fee is nevertheless the same w. A dramatic sample-count saving alone does not make the source expense disappear.

## 5. What stopping does, and what it does not pay

There is real progress without assuming a small cumulative cover: the sharp rule always gives the rank residual budget (10), and (9) records its exact main cost. However no uniform root/source-linear upper bound on that cost follows merely from FIRST, concavity or (6)-(7).

One brief capture-capacity ledger example makes the distinction precise. Take K equally likely disjoint capture blocks, each of normalized hard-source mass 4lambda, with common radius a and capture probability 1/K for each block. Then

    B_N=4lambda K[1-(1-1/K)^N],
    J_N=4lambda(1-1/K)^N.

To achieve J_N<=epsilon lambda necessarily B_N>=4lambda K(1-epsilon/4). This is a budget example for the stated capture profiles and hard-cap scale; it is NOT asserted to realize the full original soft law, low/m history and common-source qualifications, and is not an original-operator counterexample. It shows why those scalar capacity facts alone cannot certify a small true stopping expense.

A sufficient remaining premise is a proved bound on the actual integral in (9), or a direct original geometric/source argument that supplies it. One may use the exact atomic correction to shorten stopping or the potential comparison (12) to implement it conservatively, but neither substitutes for that source budget. The complementary L<R rank mismatch remains unless an independent comparison such as R299's qualified v0 transfer has been proved.

## 6. Actual bounded checks and self-contained reproduction

The self-contained reproduction below covers 45 exact-Fraction atomic capacity/rank identities with concavity checks, and 180 exact increment/potential comparisons. These checks were actually run and passed. They are finite diagnostics, not tests of a full original history. Only this Markdown deliverable was written. The following compact exact-arithmetic reproduction checks the core new identities, increment inequality and fee comparison without external libraries:

```python
from fractions import Fraction as F
atomic=potential=0
for n in [1,2,4]:
    for masses in [[F(1,10)]*3,[F(1,5),F(3,10),F(1,2)],
                   [F(0),F(1,4),F(1,4)]]:
        rs=[F(1),F(3,2),F(2)]
        def B(k):
            if not k:return F(0)
            f=v=F(0)
            for r,m in zip(rs,masses):
                old=f;f+=m
                v+=r**(-n)*((1-old)**k-(1-f)**k)
            return v
        def J(k):
            f=v=F(0)
            for r,m in zip(rs,masses):
                f+=m;v+=r**(-n)*(1-f)**k*m
            return v
        for N in [0,1,2,8,32]:
            f=gap=F(0)
            g=lambda u:(1-(1-u)**(N+1))/(N+1)
            for r,m in zip(rs,masses):
                old=f;f+=m
                gap+=r**(-n)*(g(f)-g(old)-(1-f)**N*m)
            assert B(N+1)/(N+1)-J(N)==gap and gap>=0
            atomic+=1
        vals=[B(k) for k in range(18)]
        inc=[v-u for u,v in zip(vals,vals[1:])]
        assert all(u>=0 for u in inc)
        assert all(u>=v for u,v in zip(inc,inc[1:]))
        for k in range(18):
            assert 0<=B(k+1)-B(k)<=J(k)
            potential+=1
        for tau in [F(1,10),F(1,100)]:
            sharp=next(k for k in range(10000) if J(k)<=tau/2)
            stop=next(m for m in range(1,10000) if B(m)/m<=tau)-1
            assert B(stop)<=2*B(sharp)+tau/2
            potential+=1
print('PASS exact atomic identities=',atomic)
print('PASS exact increment/potential comparisons=',potential)
```
