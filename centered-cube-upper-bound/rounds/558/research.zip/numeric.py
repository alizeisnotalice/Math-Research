"""Real vertex-spectrum alpha=1 cutoff finite-volume calibration.
No target theorem or pointwise lower-bound certificate is asserted.
"""
import argparse, itertools, json, math, platform, time
import numpy as np
import scipy
from scipy.integrate import quad
from scipy.sparse import csr_matrix, diags
from scipy.sparse.linalg import spsolve


def primitive(poly, r):
    ans = 0.0
    for k,c in enumerate(poly):
        if k == 0: ans -= c/r
        elif k == 1: ans += c*math.log(abs(r))
        else: ans += c*r**(k-1)/(k-1)
    return ans


def ray_weight(delta, eps, a, rho):
    """Integral overlap/r^2, divided by cell volume; no direction factor."""
    b=np.asarray(delta)*np.asarray(eps)
    lo,hi=max(b-a),min(b+a)
    if lo>=hi: return 0.0
    cuts=sorted(set([float(lo),float(hi)]+[float(x) for x in b if lo<x<hi]+[x for x in [-rho,rho] if lo<x<hi]))
    total=0.0
    for l,u in zip(cuts[:-1],cuts[1:]):
        mid=(l+u)/2
        if abs(mid)<rho: continue
        poly=np.array([1.0])
        for c in b:
            # a-|r-c| = a-c+r to left, a+c-r to right
            fac=[a-c,1.0] if mid<c else [a+c,-1.0]
            poly=np.polynomial.polynomial.polymul(poly,fac)
        total+=primitive(poly,u)-primitive(poly,l)
    # Only roundoff-sized negative values may be clipped.
    if total < -1e-10*a**len(delta): raise ArithmeticError((delta,eps,total))
    return max(total/a**len(delta),0.0)


def rate(delta, directions, a, rho):
    return sum(ray_weight(delta,e,a,rho) for e in directions)/len(directions)


def pilot(n=2,m=9,a=0.5,rho=0.25,lam=1.,h=4.,dhalf=1.25):
    if n!=2 or m>11: raise ValueError('Calibration scope is n=2,m<=11 only')
    start=time.perf_counter()
    directions=np.array([(1,)+e for e in itertools.product([-1,1],repeat=n-1)])
    indices=np.array(list(itertools.product(range(m),repeat=n)))
    centers=(indices-(m-1)/2)*a
    weights={}
    for off in itertools.product(range(1-m,m),repeat=n):
        weights[off]=rate(np.array(off)*a,directions,a,rho)
    rows=[];cols=[];vals=[]
    for i,idx in enumerate(indices):
        for j,jdx in enumerate(indices):
            w=weights[tuple(jdx-idx)]
            if w: rows.append(i);cols.append(j);vals.append(w)
    W=csr_matrix((vals,(rows,cols)),shape=(len(indices),)*2)
    totalrate=2/rho
    outside=totalrate-np.asarray(W.sum(axis=1)).ravel()
    # q cell average: uniform-volume fraction in open D cube, exact for boxes.
    overlap=np.maximum(0,np.minimum(centers+a/2,dhalf)-np.maximum(centers-a/2,-dhalf))
    frac=np.prod(overlap/a,axis=1)
    q=lam+h*(1-frac)
    B=diags(q+totalrate)-W
    source=np.zeros(len(indices)); source[np.all(indices==(m-1)//2,axis=1)]=a**(-n)
    g=spsolve(B,source)
    target=np.all((centers+a/2>-1)&(centers-a/2<1),axis=1)
    # Independent adaptive quadrature on a nontrivial offset, split at kinks.
    delta=np.array([a,0]);eps=directions[0]; b=delta*eps
    lower,upper=max(b-a),min(b+a)
    knots=sorted(set([lower,upper]+[x for x in [*b,-rho,rho] if lower<x<upper]))
    quadrature=sum(quad(lambda r: np.prod(np.maximum(a-np.abs(r-b),0))/r**2/a**n,l,u,epsabs=1e-12)[0] for l,u in zip(knots[:-1],knots[1:]) if abs((l+u)/2)>=rho)
    analytic=ray_weight(delta,eps,a,rho)
    return dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,parameters=dict(n=n,m=m,a=a,rho=rho,lam=lam,h=h,dhalf=dhalf),directions=directions.tolist(),matrix_size=len(indices),nnz=W.nnz,total_jump_rate=totalrate,minimum_exterior_rate=float(min(outside)),symmetry_error=float(abs(W-W.T).max()),ray_analytic=analytic,ray_quadrature=quadrature,ray_error=abs(analytic-quadrature),minimum_g=float(min(g)),mass=float(sum(g)*a**n),minimum_Q_overlapping_cell_average=float(min(g[target])),linear_residual=float(np.max(abs(B@g-source))),mass_balance_error=float(abs(sum((q+outside)*g)*a**n-1)),elapsed_seconds=time.perf_counter()-start,interpretation='Cutoff chain, uniform origin-cell source, zero exterior box: calibration only; not true delta Green, not essinf_Q, not target ratio.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--calibrate',action='store_true');args=p.parse_args()
    if not args.calibrate: p.error('Only --calibrate is currently authorized')
    print(json.dumps(pilot(),indent=2))
