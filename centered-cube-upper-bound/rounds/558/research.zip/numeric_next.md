# Fixed q negative-moment decision pilot

Owner g558_numeric_sol. Parent authorized one bounded scalar selection, no dimension or shape scan. Frozen choice: **s=3/4, q=40**.

Define

    w_q(r)=exp(−q r²)|cos(πr)cos(2πr)|^(−3/4),
    I_.5(q)=∫_0^.5 (w_q(r)−1)/r² dr,
    I_∞(q)=∫_0^∞ (w_q(r)−1)/r² dr,
    E w_q(R)= (1/2)∫_.5^∞ w_q(r)/r² dr.

The last density integrates to one. The useful exact relation is I∞=I_.5+2(Ew−1). The calculations below are numerical evidence, not strict sign certificates. The frozen q and all splits were sent to g558_certificate_sol, which independently has a coarse analytic q512 certificate.

## Singularities and tail

The zero set is Z={1/4,1/2,3/4}+Z. All zeros are simple and disjoint between the two cosine factors, so each local singularity is |r−z|^(−3/4), integrable. At z half-integral the absolute product has derivative magnitude π; at z an odd quarter it has magnitude √2 π. No principal value is involved. At r=0 the apparent r^−2 singularity cancels, with continuous integrand value −q+15π²/8.

The first run uses SciPy QUADPACK algebraic endpoint weights: exponent −3/4 at each zero. On [0,.25], the regular factor is (.25−r)^(3/4)(w−1)/r² with its exact endpoint limits; other pieces integrate w/r² and subtract ∫1/r² analytically. The exact split points are

    0, .25, .5, .75, 1.25, 1.5, 1.75, 2.

The second, independent numerical representation uses r=z±u^4 at each singular endpoint. The factor u³ from dr cancels |r−z|^−3/4 exactly. Evaluating sin(cd)/d at d=u^4 avoids rounding a nearby sample onto the zero. It uses mpmath tanh-sinh at 50 decimal places. Agreement across these representations tests implementation, not interval rigor.

There is a simple analytic tail bound beyond L=2. Let h(r)=|cosπr cos2πr|^−3/4 and d(r)=dist(r,Z). Distances d1,d2 to the two individual cosine zero sets have d1+d2≥1/4, and |cosπr|≥2d1, |cos2πr|≥4d2. Thus their product ≥d(r), and h≤d^−3/4. Splitting a period into six one-sided zero neighborhoods gives H=∫_0^1 h≤24. By periodicity,

    ∫_2^∞ w_40(r)/r² dr
      ≤ 24 Σ_(m≥2) exp(−40m²)/m²
      ≤ 6 exp(−160)/(1−exp(−200)) < 2×10^−69.

The exact exponential expression is the tail bound; the decimal last bound can be replaced by elementary exponential comparisons. This tail adds positively to I∞ and half as much to Ew. It does not affect I_.5. This analytic tail control does not convert the finite-range numerical integrals into rigorous enclosures.

## Actual run results

Interpreter `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`; Python3.12.14, SciPy1.18.1. mpmath high precision, 50 dps. Both runs used one process and <1 s wall each, <1 GB. Full implementation: numeric_next.py. Logs: COMPUTE_INDEX.md.

| Quantity | SciPy weighted quadrature | Independent mpmath |
|---|---:|---:|
| I_.5(40) | −4.731777548642816 | −4.7317775486043872186 |
| I∞(40), w-tail beyond2 omitted | −6.731669547570801 | −6.7316695475323727293 |
| Ew_40(R), tail beyond2 omitted | .000054000536007245104 | .000054000536007244674181 |

SciPy estimates absolute errors 3.01e−10, 3.01e−10, 9.34e−16 respectively. The two I estimates differ by 3.84e−11, within that error estimate; Ew differs by 4.3e−19. These estimates are not rigorous bounds. Conservative **candidate enclosure targets for independent certification** are

    −4.732 < I_.5(40) < −4.731,
    −6.732 < I∞(40) < −6.731,
    0 < Ew_40(R) < .000055.

They have ample numerical margin for the requested signs. No further q search is useful for this decision.

The individual first-run pieces are ∫_0^.25(w−1)/r²≈−3.419572663839395; ∫_.25^.5 w/r²≈.6877951151965795; ∫_.5^.75 w/r²≈.00010800094676137211; ∫_.75^1.25 w/r²≈1.2525311810532352e−10. Later pieces are smaller. All genuine singularities were included, including the endpoint at r=.5 in both neighboring integrals.

Decision supported: q40 is a well-separated candidate to freeze for independent analytic/interval validation. No strict sign assertion is claimed from quadrature, and no dimensional conclusion follows from this experiment alone.
