# 第558轮研究包复现

先读 REPORT.tex、AUDIT.md 和 ledger_next.md；详细 LaTeX 不编译 PDF。
继承第555—557轮的已证工具只按所列适用条件使用，不重复复制旧 ZIP。

解释器：/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python
实际版本 Python3.12.14、SymPy1.14.0、python-flint0.9.0；浮点依赖版本见输出。

解压后在同目录运行：
```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python certificate_next.py
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python numeric_next.py
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python -c "import numeric_next as m; print(m.crosscheck_mpmath())"
```
第一项为全部连续积分的解析/有理/Arb证书；后两项只是单个q=40两种浮点方法，不能外推一般命题。主代理实际独立重跑，输出在 reproduction_result.json。
早期有限体积试验仅n=2及三档cutoff；numeric.py、numeric.md、certificate.py、certificate.md足以复现。未截断cell权发散；cell均值不是η，δ源/网格误差未付，因此已停止扩大该试验。其25cell全量JSON可重生，不重复归档。
文献定位见 sources_next.md：只将实际原文条件作为来源，不把没有找到当作不存在。NIST sinc公式不认证新的1D gap，后者由完整解析证明与独审认证。
旧脚本工作路径仅记录实际来源；同名必要文件已在包内。__pycache__、所有旧轮解压目录、重复分审全文和中间稿不入包。
