# R558 续派：cube-cone 多跳与均匀随机级数的原始来源定位

范围：只核 `generator.tex` 的 \(\nu_\alpha(dz)=\alpha(n2^n)^{-1}\|z\|_\infty^{-n-\alpha}dz\) 与 generator 随后发来的 uniform-cube mixture/一维均匀卷积拟式。没有重读其他历史。检索日期 2026-10-23；仍按 academic-literature-search 技能核源。以下不认证 generator 新提出的 \(q=2047/2048\) 引理或其最终 resolvent upper。

## 结论先行

本次六个精确 query 内，未定位到 cube-cone 稳定过程的、可支付根阶维数预算的多跳或势密度定理。确实可用的文献输入是无维数损失的 Poisson/LePage 级数表示，以及官方 Euler sinc 乘积公式；它们不自动给接收下界。随机二进制卷积的新原始定理只给一维 a.s. regularity，也没有所需 floor。generator 随后已将其任务改为 corner upper，要求不再寻找二进制下界来源；本稿据此保留来源条件和停止边界。

## 1. Poisson/LePage 表示：保全生成元，但不支付密度预算

Youri Davydov, Ilya Molchanov, Sergei Zuyev, *Strictly stable distributions on convex cones*, 原始预印本 [math/0512196v1](https://arxiv.org/pdf/math/0512196)。实际阅读：Theorem 3.3、3.6及证明，printed pp.12–14（PDF pp.12–14）；过程版本 Theorem 3.10，printed p.15（PDF第15页）。不使用其摘要替代定理。

设 \(\Gamma_j=E_1+\cdots+E_j\)，\(E_j\) iid Exp(1)，\(\Theta_j\) iid、独立于 \(\Gamma\)，分布为单位范数球面上的有限谱概率。Theorem 3.3 给出稳定 Poisson 点过程的径向次序表示；Theorem 3.6 在范数 sub-invariant、\(0<\alpha<1\) 时给绝对收敛级数。对本题 \((\mathbb R^n,\|\cdot\|_\infty)\)、cube cone 概率谱，按本文径向归一化可写为
\[
 X_t\overset d=t^{1/\alpha}\sum_{j\ge1}\Gamma_j^{-1/\alpha}\Theta_j.\tag{S1}
\]
这里没有隐藏 \(c_n\)，因为 \(\nu(r>b)=b^{-\alpha}\) 已冻结径向时钟。定理是表示与收敛结论；没有 \(\inf_Qp_t\)、\(\inf_QR_\lambda\) 或有限截断的点态误差界。因此，Poisson尺度环境可以合法保留，但仅把 series 改写为 uniform convolution 不能视为接收成本已经支付。

generator 新拟式用独立 uniform cube marks，写作
\[
 \nu_\alpha(dz)=\kappa\alpha\int_0^\infty r^{-1-\alpha}\operatorname{Unif}(rQ)(dz)\,dr,
 \qquad\kappa=1+\alpha/n.
\]
这是该 Lévy 测度的直接 layer-cake 恒等式，不是 S1 原文：密度系数为 \(\kappa\alpha/[2^n(n+\alpha)]=\alpha/(n2^n)\)。它与 cone marks 的方向表示是两种不同的 Poisson标记方式。\(\alpha<1\) 确保小跳的 \(\ell_\infty\) variation 可求和；给定所有半径后，各坐标 uniform变量独立同分布。此条件化事实需保留共同半径环境，不能另换成无条件坐标独立。

## 2. 均匀卷积的 Fourier 输入：官方公式有条件，常数10仍是本地引理

NIST DLMF 官方 [§4.22, Eq.4.22.1](https://dlmf.nist.gov/4.22.E1)，实际打开公式页；它给复数变量的 Euler sine product。若 \(U_j\) iid Unif[−1,1]、\(\sum r_j<\infty\)，独立性与该公式给合法输入
\[
 \widehat g(t)=\prod_j\operatorname{sinc}(r_jt),
 \qquad
 \operatorname{sinc}z=\prod_{m\ge1}\left(1-\frac{z^2}{m^2\pi^2}\right).\tag{S2}
\]
第一式是均匀分布 Fourier积分及独立性，不是 DLMF 的概率定理。实 \(|z|<\pi\) 时每个因子为正，可取实对数；接近或越过零点时不可无条件取该实对数。有限/绝对收敛级数的极限应单独处理。S2 的常数完全显式、不依赖维数；它没有声明 \(\widehat g(\pi)\ge\widehat g(\pi/2)^{10}\)，更没有声明 \(2g(1)\le2047/2048\)。这些属于 generator 的新证明责任，需独立审计，不能写成“文献定理”。

已即时将官方公式及这一边界发给 generator。

## 3. 随机二进制展开的相关原始定理：regularity不能当均匀 floor

Simon Baker, Henna Koivusalo, Sascha Troscheit, Xintian Zhang, *On the Fourier transform of random Bernoulli convolutions*, JLMS 113(4), e70515, 2026；原刊 [DOI 10.1112/jlms.70515](https://londmathsoc.onlinelibrary.wiley.com/doi/full/10.1112/jlms.70515)。实际阅读：§1定义、Theorems 1–3及相邻解释；不是只读摘要。

其输入为 \(\lambda_k\) iid，均匀分布于固定闭区间 \(W\subset(0,1)\)，在给定 \(\omega=(\lambda_k)\) 后，二进制 digits \(a_j\) 独立公平；相应随机测度是 \(\sum_{j\ge1}a_j\prod_{k\le j}\lambda_k\) 的条件分布。令 \(\lambda_g=\exp E\log\lambda_1\)。原始定理给
\[
 \lambda_g>2/\pi\ \Longrightarrow\ \widehat\mu_\omega\in L^1(\mathbb R)
 \quad\text{a.s.},\tag{S3}
\]
故有连续密度，支撑有非空内部。Theorem 3另给 Fourier幂次衰减，指数 \(\rho\) 可不依赖环境，但前置常数 \(C\) 可依赖环境。论文没有在指定整个区间给正密度 floor，也没有给 \(n\) 次乘积的 polynomial预算。其 iid uniform收缩条件不等于 Poisson有序半径的比值结构；不能直接迁移。\(\lambda_g\) 接近1/2时也不满足 S3 的阈值。已将条件即时发给 nonradial。

相关但不当作新增下界来源：Erdős 1939原文 [*On a family of symmetric Bernoulli convolutions*](https://users.renyi.hu/~p_erdos/1939-05.pdf)，实际阅读 printed pp.974–976，特别 §2 的代数整数/共轭条件。它证明 reciprocal Pisot 参数可产生奇异测度；因此，单凭二进制恰好均匀不能将几何参数变化当作普遍保正则性的操作。本文未核定一个任意小邻域的参数稳定性结论，未找到满足本题条件的定量 perturbation定理，也未借此判定 generator 的 uniform卷积模型。

## 已执行 query（本轮恰6个）与受阻记录

1. `"stable" "Levy density" "cube" potential kernel`
2. `"uniform" "random series" "density" "geometric" convolution stability`
3. `"Bernoulli convolution" "uniform distribution" perturbation binary expansion density`
4. `Erdos 1939 "On a family of symmetric Bernoulli convolutions" pdf Pisot`
5. `LePage Woodroofe Zinn 1981 stable law series representation Gamma uniform sphere theorem pdf`
6. `"infinite convolutions" "uniform distributions" density theorem`

只在这些 query 后沿原文/官方页面链接打开条件页，没有追加 query。LePage–Woodroofe–Zinn 1981 Project Euclid全文入口只返回 iframe；2001 variation论文的 CiteSeer PDF抓取超时；未从搜索片段抄成可用定理。另打开 Świątkowski 2017原刊 Theorem 4.2条件页：它仅给一维 affine perpetuity的绝对连续性，不给 floor，故不列为建设性输入。没有把这些 qualitative结果包装成全维预算。

轻量实跑：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`，SymPy 1.14.0，输入 `simplify((1+a/n)*a/(2**n*(n+a)))` 得 `a/(2**n*n)`；输入 `integrate(exp(I*t*r),(r,-m,m))/(2*m)` 得 `sin(m*t)/(m*t)`。这些为精确符号恒等式检查；未跑新q引理、未做数值证据或多跳批量实验。

停止点：此限域内没有定位到能替代新关键接收引理的既有定量来源。S1/S2可用作结构输入；S3只用于说明 regularity来源的适用条件和不足。新corner upper或新的全维接收机制是否成立，交回 generator及独立审计角色。
