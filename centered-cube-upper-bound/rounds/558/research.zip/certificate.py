#!/usr/bin/env python3
"""Independent n=2 truncated cell-average certificate; stdlib exact rationals.
No solver or author-side assembly functions are imported. Logarithms are held
symbolically as rational combinations of log(prime), then rigorously enclosed.
"""
from fractions import Fraction as F
from math import prod
import json, sys, platform

TERMS=128

def factors(q):
    q=F(q); out={}
    for n,sgn in [(q.numerator,1),(q.denominator,-1)]:
        p=2
        while p*p<=n:
            while n%p==0:
                out[p]=out.get(p,0)+sgn; n//=p
            p+=1
        if n>1: out[n]=out.get(n,0)+sgn
    return {p:e for p,e in out.items() if e}

class Expr:
    def __init__(self,c=0,logs=None): self.c=F(c); self.logs=logs or {}
    def add(self,b):
        d=self.logs.copy()
        for p,v in b.logs.items(): d[p]=d.get(p,F(0))+v
        return Expr(self.c+b.c,{p:v for p,v in d.items() if v})
    def scale(self,c): return Expr(self.c*c,{p:v*c for p,v in self.logs.items() if v*c})
    def interval(self):
        lo=hi=self.c
        for p,c in self.logs.items():
            l,h=log_bounds(p)
            lo+=c*(l if c>=0 else h); hi+=c*(h if c>=0 else l)
        return lo,hi
    def serial(self):
        l,h=self.interval()
        return {'rational':str(self.c),'log_prime_coefficients':{str(p):str(c) for p,c in sorted(self.logs.items())},'exact_lower':str(l),'exact_upper':str(h),'enclosure_decimal_display':[format(float(l),'.17g'),format(float(h),'.17g')],'exact_width':str(h-l)}

def log_bounds(p):
    # log(p)=2 atanh((p-1)/(p+1)); positive series and geometric tail.
    t=F(p-1,p+1)
    s=2*sum((t**(2*k+1)/F(2*k+1) for k in range(TERMS)),F(0))
    tail=2*t**(2*TERMS+1)/(F(2*TERMS+1)*(1-t*t))
    return s,s+tail

def mul(a,b):
    c=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j]+=x*y
    return c

def integrate(poly,l,h):
    out=Expr()
    for k,c in enumerate(poly):
        if k==0: out=out.add(Expr(c*(1/l-1/h)))
        elif k==1: out=out.add(Expr(0,{p:c*e for p,e in factors(h/l).items()}))
        else: out=out.add(Expr(c*(h**(k-1)-l**(k-1))/F(k-1)))
    return out

def rate(offset,rho=F(1,2)):
    # a=1; epsilon=(1,1),(1,-1); N=2. Integrate both signed rays.
    total=Expr()
    for eps in [(1,1),(1,-1)]:
        for sign in [-1,1]:
            b=[F(sign*eps[j]*offset[j]) for j in range(2)]
            lo=max([rho]+[x-1 for x in b]); hi=min(x+1 for x in b)
            if hi<=lo: continue
            cuts=sorted(set([lo,hi]+[x for x in b if lo<x<hi]))
            for l,h in zip(cuts,cuts[1:]):
                mid=(l+h)/2; poly=[F(1)]
                for x in b:
                    # 1-|r-x|, valid on support intersection.
                    poly=mul(poly,[1+x,F(-1)] if mid>x else [1-x,F(1)])
                total=total.add(integrate(poly,l,h).scale(F(1,2)))
    return total

def main():
    rho=F(1,2); patch=range(-2,3)
    rates={(i,j):rate((i,j),rho) for i in patch for j in patch}
    summed=Expr()
    for z in rates.values(): summed=summed.add(z)
    tail=Expr(2/rho).add(summed.scale(-1))
    assert tail.interval()[0]>0
    for key,z in rates.items():
        assert z.interval()[0]>=0
        assert z.add(rates[(-key[0],-key[1])].scale(-1)).c==0
        assert z.add(rates[(-key[0],-key[1])].scale(-1)).logs=={}
    expected={(0,0):Expr(3,{2:F(-4)}),(1,0):Expr(F(-1,2),{2:F(1)}),(1,1):Expr(F(7,4),{2:F(-2)})}
    for key,z in expected.items():
        diff=z.add(rates[key].scale(-1)); assert diff.c==0 and not diff.logs
    out={'python':sys.executable,'version':platform.python_version(),'parameters':{'n':2,'a':1,'rho':'1/2','patch':'[-2,2]^2','log_series_terms':TERMS},'full_jump_mass':'8','rates':{str(k):v.serial() for k,v in rates.items()},'patch_tail_absorption':tail.serial(),'source_cell_density':'1','source_cell_integral':'1','certification_scope':'Truncated generator, uniform source cell; no certificate of true delta-source resolvent or continuum essinf.'}
    print(json.dumps(out,indent=2))

if __name__=='__main__': main()
