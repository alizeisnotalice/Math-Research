# Real vertex-spectrum finite-volume design and calibrated limitations

Owner g558_numeric_sol, 2026-10-23. Scope: only `numeric.py`, `numeric.md`, `COMPUTE_INDEX.md`. No repo change, PDF compilation, dimension scan, or claimed target theorem. Independent coefficient checks: g558_certificate_sol.

## Precise question and stop rule

Can positive finite-volume approximations of the **actual** vertex generator reliably distinguish bounded killing sets D through M/(2^n η)? Definitions are those in CONTRACT: N=2^(n−1), ε=(1,±1,…,±1), jump measure (1/N)Σ dr/r², q=λ+h1_Dc. The following small computations calibrate a cut-off approximation only. They do **not** determine the true delta Green function or η=essinf_Q G. No candidate shape or dimension parameter is chosen from them. Missing pointwise/source error control is the stop condition.

## Exact ray/cell geometry

Take equal axis-aligned cells C_i of side a, centers x_i, volume a^n. Put Δ=x_j−x_i and b_l=ε_l Δ_l. For a fixed direction,

    |C_i ∩ (C_j−r ε)| = Π_l (a−|r−b_l|)_+.

Its support is [max_l b_l−a, min_l b_l+a]. If the interval is empty there is no edge. Split the interval at every b_l and at ±ρ. On each retained segment |r|≥ρ the numerator is a polynomial p(r)=Σ c_k r^k. Its exact primitive after division by r² is

    −c_0/r + c_1 log|r| + Σ_(k≥2) c_k r^(k−1)/(k−1).

Thus the **complete** cell rate is

    w_ij^ρ = (1/(N a^n)) Σ_ε ∫_(|r|≥ρ) Π_l (a−|r−b_l|)_+ dr/r².

Each contribution is nonnegative; changing r to −r proves w_ij=w_ji. The program uses all true vertex directions in n=2, rather than coordinate jumps. Its `ray_weight` excludes 1/N; `rate` performs the direction average. Coefficients are rational plus rational logarithms for rational grid/cutoff inputs; the production implementation uses float and is independently checked with rational/log enclosures and Arb. Floating residuals themselves are not certificates.

Untruncated face-neighbor coefficients diverge logarithmically. Therefore the finite matrix is explicitly for |r|≥ρ. Taking ρ→0 at fixed a is not a legitimate finite-matrix limit.

## Positive symmetric matrix and tails

The total retained jump intensity is exactly tρ=2/ρ, independent of n. On a finite cell union Ω define w_i,out=tρ−Σ_(j in Ω)w_ij, including w_ii in that sum. The matrix

    B=diag(q_i+tρ)−W

has nonpositive off-diagonal entries, positive diagonal dominance by q_i+w_i,out≥λ, and is a symmetric positive definite M-matrix. Source vector s_i=1_(i=origin cell)/a^n has total mass one. The computed nonnegative g solves Bg=s. Its exact algebraic mass identity is

    a^n Σ_i (q_i+w_i,out)g_i = 1.

No far-jump tail is discarded: jumps out of Ω appear through the exact intensity remainder. This imposes immediate killing on exit Ω. For finite h, it differs from the original problem, which allows returns from all D^c. An exact continuum killed-domain Green function is below the full finite-h Green function, but this ordering does not automatically transfer from this projected cutoff chain to the target. The computed mass is not an upper bound for target M. The generic target bound M≤1/λ is available independently; one would still need a rigorous lower bound for true η to use it.

q_i is the exact cell average of λ+h1_Dc, calculated by box intersection. Cells crossing ∂D introduce a multiplication/projection error. Aligning ∂D to cell faces removes that specific term, not the other errors.

## Error budget and angular sparsity

For a bounded C² test function f, the omitted symmetric small jumps satisfy

    ||(A−Aρ)f||∞ ≤ nρ ||D²f||op,∞.

This follows from the symmetric second difference and |ε|²=n. It does not apply to δ, cell indicators, or an unproved regularity class for G. Let P_a be cell averaging, extended piecewise constantly. The crude global Lipschitz estimate ||P_af−f||∞≤a√n Lip(f) gives

    ||P_a Aρ(P_af−f)||∞ ≤ 4a√n Lip(f)/ρ.

Consequently a directly justified *test-function* consistency regime is ρ→0 and a/ρ→0, e.g. ρ≈√a in fixed units and dimension, with combined error at most the preceding two terms. My initial suggestion ρ=θa is **not justified by this bound**; a sharper cancellation argument would be needed for it. No test-function consistency result here implies Green-function convergence in essinf.

The overlap support criterion gives sparse ray bands in a large rectangular grid: an offset is reached by ε only if max_l(ε_lΔ_l)−min_l(ε_lΔ_l)<2a. This sparsity saves edges, but does not eliminate the N=2^(n−1) vertex-spectrum cost. Sampling directions would change A; a certificate would need an explicit uniform angular quadrature error in a relevant function class. Covariance/isotropy matching alone does not suffice. No angular sampling is used in these pilots.

For a simple radial parameter truncation |r|>R the total missing intensity would be 2/R. The present matrix includes those events as exterior killing, with no such neglected tail. Converting exterior killing to finite-h return requires another bound, not a relabeling of 2/R as a solution error.

## Source and receiver audit

The initial cell vector represents a **uniform origin-cell source**, not the continuum δ source. Its weak discrepancy on Lipschitz tests is bounded by (a√n/2)Lip(f), but no quantitative Green or η discrepancy is established. A point source startup or positive-time kernel with an explicit remainder could replace it; neither is supplied here.

The matrix uses genuine source-cell and target-cell overlap averages, rather than values at cell centers. Nevertheless the minimum receiving-cell mean, even over every cell intersecting Q, does not lower-bound essinf_Q G. A within-cell modulus/Harnack estimate for the actual full Green function, with tracked constants and source error, is necessary. Using cell-center values or interpolation would not repair this gap.

## Actual calibrated results

Interpreter `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`: Python 3.12.14, NumPy 2.5.4, SciPy 1.18.1. One process, 81 cells, m=9,a=.5, λ=1,h=4,D=(−1.25,1.25)^2, Ω=(−2.25,2.25)^2. Every pilot took <.02 s internally; process <1 s. No optimization performed.

| ρ | cutoff-chain mass | min mean over cells meeting Q |
|---:|---:|---:|
| .125 | .320648003899780 | .016106501897538 |
| .25 | .344325664442539 | .016295909150594 |
| .5 | .373630904563612 | .006061313883125 |

At ρ=.25 the matrix has 2529 W entries, symmetry error zero, linear residual 2.22e−15, mass balance error 4.44e−16. A face-ray integral gave .38629436111989035 versus independent scipy quadrature .3862943611198906. The certificate role independently enclosed the complete rate 2log2−1 using 256-bit Arb as .3862943611198906188344642429163531361510002687205105082413600189867872439394 ±1.11e−77.

Increasing ρ from .25 to .5 changes the minimum receiving mean by approximately 63%. This rejects using a single coarse cutoff for shape selection. The smaller two cutoffs being closer does not prove convergence, especially at fixed a where the face rates diverge. The true target ratio is not reported. All experiments and other roles' reported auxiliary runs are recorded in COMPUTE_INDEX.md.

Next meaningful computational gate: supply rigorous δ-source and pointwise receiver error controls, or a monotone continuum subsolution with a certified residual. Until then, larger solves would refine a surrogate rather than answer the proof decision.
