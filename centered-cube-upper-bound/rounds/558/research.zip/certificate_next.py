#!/usr/bin/env python3
"""Analytic whole-domain certificate for s=3/4, q=512; no quadrature.
All theorem-sign bounds are rational; Arb independently displays exp bounds.
"""
from fractions import Fraction as F
from math import factorial
import json,sys,platform
import flint
from flint import arb,ctx
ctx.prec=256
s=F(3,4);a=F(1,8);q=F(512)
pi_sq_upper=F(22,7)**2
cos_exponent_upper=5*s*pi_sq_upper
assert cos_exponent_upper<38
c_lower=q-38
near_exponent_lower=c_lower*(a/2)**2
assert near_exponent_lower>1
# exp(1)>5/2, so exp(-near_exponent)<2/5<1/2.
near_w_upper=F(2,5)
assert near_w_upper<F(1,2)
period_h_upper=F(24)
# first [a,1] plus [m,m+1], m>=1; sum m^-2 <=2.
h_over_r2_upper=period_h_upper*(a**-2+2)
assert h_over_r2_upper==1584
exp8_lower=sum((F(8)**k/F(factorial(k)) for k in range(17)),F(0))
positive_tail_upper=h_over_r2_upper/exp8_lower
negative_near_upper=-1/(2*a)
i_upper=negative_near_upper+positive_tail_upper
ew_upper=positive_tail_upper/2
assert i_upper<0 and ew_upper<1
arb_tail=1584*(-arb(8)).exp()
arb_i=-4+arb_tail
arb_ew=arb_tail/2
out={'scope':'Whole-domain analytic upper certificates; no numerical quadrature; no general root theorem.',
'python':sys.executable,'python_version':platform.python_version(),'python_flint_version':flint.__version__,'arb_precision_bits':ctx.prec,
'parameters':{'s':str(s),'a':str(a),'q':str(q),'exp_taylor_lower_terms':'k=0..16'},
'exact_rational_bounds':{'pi_squared_upper':str(pi_sq_upper),'5s_pi_squared_upper':str(cos_exponent_upper),'near_exponent_lower':str(near_exponent_lower),'near_w_upper':str(near_w_upper),'period_h_integral_upper':str(period_h_upper),'unweighted_tail_integral_upper':str(h_over_r2_upper),'exp8_strict_lower':str(exp8_lower),'positive_tail_upper':str(positive_tail_upper),'I_half_upper':str(i_upper),'I_infinity_upper':str(i_upper),'Ew_R_upper':str(ew_upper)},
'decimal_display_only':{'positive_tail_upper':float(positive_tail_upper),'I_upper':float(i_upper),'Ew_upper':float(ew_upper)},
'arb_cross_check_actual_analytic_expressions':{'1584_exp_minus8':str(arb_tail),'minus4_plus1584_exp_minus8':str(arb_i),'792_exp_minus8':str(arb_ew)},
'passed':True}
print(json.dumps(out,indent=2))
