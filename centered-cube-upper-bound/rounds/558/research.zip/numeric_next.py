"""Bounded q pilot. Quadrature errors are estimates, not rigorous bounds."""
import math, json, platform, time
import scipy
from scipy.integrate import quad
S=.75

def zeros_to(L):
    return sorted(k+x for k in range(math.ceil(L)) for x in [.25,.5,.75] if k+x<L)

def deriv(z):
    return math.pi if abs((z%1)-.5)<1e-12 else math.sqrt(2)*math.pi

def logw(r,q):
    # Near zero log1p avoids loss in cos−1.
    if abs(r)<.1:
        lc=math.log1p(-2*math.sin(math.pi*r/2)**2)+math.log1p(-2*math.sin(math.pi*r)**2)
    else: lc=math.log(abs(math.cos(math.pi*r)))+math.log(abs(math.cos(2*math.pi*r)))
    return -q*r*r-S*lc

def integrate_first(q,eps):
    b=.25
    def f(r):
        if r==0:return (-q+5*math.pi**2*S/2)*b**S
        if r==b:return math.exp(-q*b*b)*deriv(b)**(-S)/b**2
        return (b-r)**S*math.expm1(logw(r,q))/r**2
    return quad(f,0,b,weight='alg',wvar=(0,-S),epsabs=eps,epsrel=eps,limit=200)

def weighted_w(a,b,q,leftzero,rightzero,eps):
    def f(r):
        if leftzero and r==a:
            return math.exp(-q*r*r)*deriv(r)**(-S)*(b-a)**(S if rightzero else 0)/r**2
        if rightzero and r==b:
            return math.exp(-q*r*r)*deriv(r)**(-S)*(b-a)**(S if leftzero else 0)/r**2
        extra=(S*math.log(r-a) if leftzero else 0)+(S*math.log(b-r) if rightzero else 0)
        return math.exp(logw(r,q)+extra)/r**2
    return quad(f,a,b,weight='alg',wvar=(-S if leftzero else 0,-S if rightzero else 0),epsabs=eps,epsrel=eps,limit=200)

def pilot(q=40.,eps=1e-10,L=2.):
    st=time.perf_counter(); first,e0=integrate_first(q,eps)
    pts=[.25]+[x for x in zeros_to(L) if x>.25]+[L]
    low=first; tailw=0.; errlow=e0; errtail=0.
    segments=[dict(a=0,b=.25,minus_one_integral=first,error_estimate=e0)]
    for a,b in zip(pts[:-1],pts[1:]):
        val,err=weighted_w(a,b,q,True,b!=L,eps)
        segments.append(dict(a=a,b=b,w_over_r2_integral=val,error_estimate=err))
        if b<=.5: low+=val-(1/a-1/b);errlow+=err
        if a>=.5: tailw+=val;errtail+=err
    # Integral from .5 to L of -1/r² plus exact -1/r² tail beyond L.
    ew_trunc=.5*tailw
    iinf_trunc=low+tailw-2.
    return dict(q=q,s=S,L=L,eps=eps,I_half=low,I_half_error_estimate=errlow,Ew_truncated=ew_trunc,Ew_error_estimate=.5*errtail,I_infinity_truncated=iinf_trunc,I_infinity_error_estimate=errlow+errtail,segments=segments,elapsed_seconds=time.perf_counter()-st,versions=dict(python=platform.python_version(),scipy=scipy.__version__),warning='Positive Gaussian w tail beyond L omitted; numerical error estimates only; no rigorous sign certificate.')

if __name__=='__main__':
    print(json.dumps(pilot(),indent=2))


def crosscheck_mpmath(q=40,dps=50,L=2):
    """Independent quartic endpoint removal, high precision, still not proof."""
    import mpmath as mp
    mp.mp.dps=dps
    ss=mp.mpf(3)/4;qq=mp.mpf(q)
    def ww(r): return mp.exp(-qq*r*r)/abs(mp.cos(mp.pi*r)*mp.cos(2*mp.pi*r))**ss
    def regular_first(r):
        if not r:return -qq+5*mp.pi**2*ss/2
        return mp.expm1(-qq*r*r-ss*(mp.log(mp.cos(mp.pi*r))+mp.log(mp.cos(2*mp.pi*r))))/r**2
    def fromzero(z,sign,length,subtract=False):
        z=mp.mpf(z)
        half=(z%1)==mp.mpf('.5')
        def transformed(u):
            d=u**4;r=z+sign*d
            if half: ratio=(mp.sin(mp.pi*d)/d if d else mp.pi)*abs(mp.cos(2*mp.pi*d))
            else: ratio=(mp.sin(2*mp.pi*d)/d if d else 2*mp.pi)*abs(mp.cos(mp.pi*z)*mp.cos(mp.pi*d)-sign*mp.sin(mp.pi*z)*mp.sin(mp.pi*d))
            val=4*mp.exp(-qq*r*r)*ratio**(-ss)/r**2
            return val-4*u**3/r**2 if subtract else val
        return mp.quad(transformed,[0,mp.mpf(length)**mp.mpf('.25')])
    first=mp.quad(regular_first,[0,mp.mpf('.125')])+fromzero('.25',-1,'.125',True)
    part=fromzero('.25',1,'.125')+fromzero('.5',-1,'.125')
    low=first+part-2
    pts=[mp.mpf(str(x)) for x in [.5,.75,1.25,1.5,1.75,L]]
    tail=mp.mpf(0)
    for a,b in zip(pts[:-1],pts[1:]):
        mid=(a+b)/2
        tail+=fromzero(a,1,mid-a)
        tail+=fromzero(b,-1,b-mid) if b!=L else mp.quad(lambda r:ww(r)/r**2,[mid,b])
    return dict(q=q,dps=dps,I_half=str(low),I_infinity_truncated=str(low+tail-2),Ew_truncated=str(tail/2),method='mpmath quartic endpoint removal, tanh-sinh; nonrigorous cross-check')
