"""Exact algebra for the first-large-jump switched occupation candidate."""
from pathlib import Path
import sympy as s,json,sys,hashlib
k,a,j=s.symbols('k a j',positive=True)
# a=small-jump exponent; j=Fourier transform of the positive large jump measure.
psi=a+4-j
pre=1/(k+4+a);post=j/((1+psi)*(k+4+a));total=pre+post
checks={
'full_distribution':s.factor(-psi*total-(k*pre+post-1)),
'combined_multiplier':s.factor(total-(5+a)/((1+psi)*(k+4+a))),
'resolvent_difference':s.factor(total-(1/(1+psi)-(k-1)/((1+psi)*(k+4+a)))),
'mass':s.factor(total.subs({a:0,j:4})-5/(k+4)),
'positive_measure_mass':s.factor((k*pre+post).subs({a:0,j:4})-1),
}
n,r=s.symbols('n r',positive=True)
checks['small_jump_variance_rate']=s.integrate(2,(r,0,s.Rational(1,2)))-1
checks['concentration_margin']=s.factor((s.Rational(1,2)-n**3/(2*n**3+4))-1/(n**3+2))
t,L=s.symbols('t L',positive=True)
m=s.symbols('m',integer=True,nonnegative=True)
checks['poisson_window_time_integral']=s.simplify(s.integrate(t**m*s.exp(-(1+L)*t),(t,0,s.oo))-s.factorial(m)/(1+L)**(m+1))
R,eta=s.symbols('R eta',positive=True)
for depth in [1,2,3,4,8]:
    h=R/s.Integer(2)**depth;w=eta*h/depth
    ell=s.prod(2*w/((R/s.Integer(2)**j)**2-w*w) for j in range(1,depth+1))
    relaxed=s.factorial(depth)*2**depth*ell/(4/h)**(depth+1)
    cm=s.factorial(depth)*(eta/depth)**depth*s.Integer(2)**(-depth**2)*s.prod(1/(1-(eta*s.Integer(2)**(j-depth)/depth)**2) for j in range(1,depth+1))
    checks[f'window_cost_depth_{depth}']=s.factor(relaxed-R*cm/4)
assert all(v==0 for v in checks.values())
out=dict(python=sys.version,sympy=s.__version__,command=f'{sys.executable} {__file__}',residuals={key:str(v) for key,v in checks.items()},script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Algebra only. Positivity and adapted killing distribution identity require the probabilistic proof; no receiver lower bound.')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
