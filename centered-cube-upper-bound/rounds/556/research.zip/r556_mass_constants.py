"""Arb endpoint checks accompanying the analytic monotonicity argument, not a process proof."""
from pathlib import Path
import sys,json,hashlib
import flint
from flint import arb,ctx
ctx.prec=160
checks={
 'small_jump_rate_margin':2-2*(arb(1).cosh()-1),
 'large_n_endpoint_k257':arb(257)-32*arb(514).log(),
 'small_n_endpoint_k256':64*arb(512).log()/256-1,
 'log2_minus_half':arb(2).log()-arb(1)/2,
 'seven_minus_log514':7-arb(514).log(),
 'large_k_derivative_at257':1-arb(32)/257,
}
assert all(v>0 for v in checks.values())
rows=[]
for n in [2,9,33,129,255,256,1024,1000000]:
    v=64*arb(2*n+2).log()/(n+1)
    rows.append({'n':n,'mass_upper_raw_interval':str(v),'trivial_upper':1})
result={'command':f'{sys.executable} {__file__}','python':sys.version,'python_flint':flint.__version__,'precision_bits':ctx.prec,'strict_positive_interval_checks':{k:str(v) for k,v in checks.items()},'sample_bounds':rows,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Arb enclosures for endpoint constants; full n range uses analytic monotonicity. Does not certify the Levy-process proof or receiver minimum.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
