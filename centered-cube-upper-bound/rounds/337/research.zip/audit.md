# R337 independent preauthor screen — reverse radius decomposition and low global past

Owned only /tmp/r337_audit.md; no Git/other-author edits. Derived before reading R337 author proofs. Fixed actual hard-matched receiver dx, finite E, q in[q_-,lambda], q_-=3lambda/4, m=qR^n=integral_Q f, beta=f, and the ORIGINAL full mu/J/prefix/ell. For exact reverse-minus-favourable identities nu=f is essential. A target nu<=f may first be positively dominated by the full-f slot; its two directed source-set differences do not individually have mass difference m_u-m_v without that domination.

## A. Quantitative q-variation receipt, not payment of radius gap

On ordered m_u>K m_v with K>lambda/q_-, actual R_u>R_v. After swapping the favourable endpoints, the difference of the full-f positive original reverse and favourable integrals is G_K, with source-set mass difference f(Q_u\Q_v)-f(Q_v\Q_u)=m_u-m_v and the SAME J/H/source clock. There is no hidden factor1/2. Expand exactly

 m_u-m_v=q_u(R_u^n-R_v^n)+(q_u-q_v)R_v^n.

The first term defines a nonnegative actual physical-radius remainder D_K. The absolute second term is at most eta*m_v, eta=(lambda-q_-)/q_-=1/3. Hence |G_K-D_K|<=eta*T_fav,K, where T_fav,K is the source-integrated SMALL capturing-mass first-moment primitive after swapping. R336 gives eta[delta X_q+lambda W/(Kq_-delta)]. Choosing delta=3epsilon yields |G-D|<=epsilon X_q+4W/(27Kepsilon). Likewise reverse<=D+(1+eta)T_fav, and choosing delta=3epsilon/4 gives reverse<=D+epsilon X_q+64W/(27Kepsilon). These constants follow by combining the coefficient BEFORE Young; they do not reuse a prior epsilon allocation.

D_K is still unpaid and may be large. The q-variation error is a real bounded perturbation of the original full-f integral, not a root estimate for all reverse pairs. In the WHOLE BH, favourable pairs already occur once; replacing reverse by favourable+G means the favourable cost occurs a SECOND time. The comparison cannot silently reuse the old favourable payment once for both appearances. Original high gates, prefixes, scale atoms and source order remain; this has no automatic general-soft migration.

## B. Global mass-clock low-past payment with whole atoms

For fixed y let gamma_y be the pushforward of cu(y)dmu(u) by t=m_u, and F_y(s-)=gamma_y((0,s)). The gate is F_y(m_u/K-)<=h, h>=0. Define the original G_K subintegral with this gate on its capturing/big endpoint u. Since m_u-m_v<=m_u and the smaller-endpoint fraction divided by original J is at most1, positive Fubini and the inclusive ell tail give

 G_lowpast<=integral f(y) integral q_u cu(y)1{F_y(m_u/K-)<=h}dmu(u)dy
           <=lambda integral f(y)gamma_y{t:F_y(t/K-)<=h}dy.

For ANY fixed massband[s,Ks], actual receiver capture and q>=q_- give gamma_y([s,Ks])<=(1+logK)/q_-. This follows from density<=min(1/s,1/[q_-d^n]) on d^n<=Ks/q_-, with d=2dist_infinity and geometric volume variable d^n. It is a receiver-dv bound, never an arbitrary source-density bound.

If h>=gamma_y total, the desired measure is at mosth. Otherwise choose s*=inf{s:gamma_y((0,s])>h}. Then gamma_y((0,s*))<=h, and any admitted t satisfies t<=K*s*. This remains true if the crossing is continuous or F(s*)=h: for t>K*s*, an intermediate value below t/K has cumulative mass>h. Therefore the WHOLE crossing atom is kept in[s*,Ks*], and

 gamma_y{t:F_y(t/K-)<=h}<=h+(1+logK)/q_-.

No crossing atom is split/discarded, including K1 and endpoint equalities. Under the finite-band contract s*>0. The resulting genuine source-only receipt is

 G_lowpast<=lambda[h+(1+logK)/q_-]W_f.

The quantile/massband argument itself works for K>=1. K>lambda/q_- additionally ensures every smaller-mass receiver in the global past has R_v<R_u and is already active when u appears, useful for exact later decompositions. This is not needed to justify the coarse fraction<=1 upper bound. The complement with global smaller-mass clock>h remains an original positive G subdomain; no density, independence, source lower overlap, or root payment for that complement has been assumed.

## Bounded local actual execution

Reviewer executed exact Fraction checks on q-variation/radius decompositions and inclusive finite mass-clock atom examples. These are algebra/quantile checks, not an actual continuum cube/history fixture, not the analytical proof, and not part of primary/author counts. Analytical conclusions above do not rely on them. Await author proofs and final ledger for file-level comparison; no full closure is certified.

Actual reviewer exact assertion count: 95.


## Independent combined P/G screen

For the displayed FULL hard scalar with nu=f, endpoint exchange gives BH=BH_near+2BH_fav+G_K EXACTLY. Pointwise in the source clock(r,y), G has nonnegative weightm_u-m_v, so P=BH_near+2BH_fav<=BH<=V_y. Therefore splitting P at ONE auxiliary clock T charges the strict low side by lambda T W only ONCE, while the high side is at most[C_near+2/(Kq_-)]X_q/T. The joint Young bound is

 P<=epsilon X_q+lambda/(q_-epsilon)(1+2logK+2/K)W.

After the source-only low-past G receipt, BH(f,nu)<=BH(f,f) is at most G_largepast+epsilon X_q plus source coefficient lambda/(q_-epsilon)(1+2logK+2/K)+lambda h+lambda/q_-(1+logK). Thus K=exp(sqrt(n)),h=sqrt(n)/q_- give root source price for the stated paid parts. The remaining G_largepast is the original positive mass-gap integrand on strict GLOBAL past>h with original H/J/ell. There is no need to add the separate radius approximation/error fee when retaining G itself. If a more qualified target has endpoint/z-dependent masks, the exact reverse-minus-favourable mass cancellation requires either a common compatible mask or first positive domination by this displayed unqualified full scalar; those masks cannot be silently carried through the source-z integration.

## Author core comparison

Read complete frozen `/tmp/r337_core.md`. PASS. The exact f-source reverse/favourable difference, large-endpoint q_u radius expansion, eta1/3 error bound, and epsilon constants4/(27Kepsilon) and64/(27Kepsilon) match the independent proof. Its physical radius gap remains nonnegative and unpaid; the stated layer-cake dt does not erase physical prefix atoms. Every smaller-mass receiver is genuinely earlier in radius for K>lambda/q_-, so the diagnostic posterior identity preserves the same original prefix support. The p_u probability, Z_H and P_K factors have the correct q/R/m units; the factorization of D_K is exact, and Z_H P_K<=1 gives only X_q. Outer scaling M costs M² in the optimized source coefficient, as correctly recorded.

The authors'79 exact interval-source/finite-receiver checks are algebra evidence and do not prove the receiver-dv estimate they import from R336. No automatic general-soft or masked-history transfer, no independent posterior copy, and no bound for the remaining D_K correlation is claimed. This is an ALTERNATIVE reverse accounting; its favourable/error fees are not added to the separate direct-G/low-past branch.

Core SHA256: `65c2bd14f7c454218aa2409dfd231ca211846a412735273bdf3eec13361ac345`.

Await auxiliary mass-clock proof and final integration/numeric scope for the final receipt; no full pipeline repeated.


## Final auxiliary mass-clock/CDF file comparison

Read COMPLETE `/tmp/r337_aux.md` and its2448-check script. PASS. The sharp closed-band estimate uses actual receiver dv/m and includes the whole mass atom, with optional physical-band improvement and min(A_n,1+logK) constant correctly charged. The quantile argument is valid even when the infimum crossing has value exactly h: any admitted mass strictly above K*tau would contain an intermediate cumulative value>h in its strict past. Whole atoms at both tau and K*tau remain in the closed band. Finite-band positive m and finite mu cover zero/past/never-crossing endpoints. The global mass gate is measurable, original J and H remain, and the positive posterior fraction is at most1 before integrating the inclusive physical tail. No source-density bound or new favourable source is inserted.

The exact occupation identity(8) has the correct two terms; its Stieltjes term MUST use J-F(Kt) and does. The Jeffreys identity(9) has no missing factor2: the single ordered(a>b) contribution equals V times the two KL divergences. Its double scale-occupation rectangle also matches(a-b)log(a/b). The only proved entropy budget is log(mmax/mmin)*min(X_q,A_nW), hence source ordern² in an octave. It is an identity/rough bound, not an O(nW) or root payment. The real-dx central slab calculation3/104 is a genuine positive high-original-J contribution; it is explicitly not a full-source total. Code handles strict-ratio equality and exact interval overlap, and does not masquerade finite source-position row checks as a full source integral.

## Final main proof and total ledger comparison

Read COMPLETE `/tmp/r337_main.md` and `/tmp/r337_ledger.md`. PASS with no required revision. First nu<=f gives one positive domination by the full source f; the exact reverse/favourable difference is applied only THERE. Main explicitly warns that arbitrary endpoint or source-z qualification masks cannot be carried through the mass cancellation, and permits first positive domination of such a target by the displayed full scalar. No double source reset is made.

At each(r,y), the coefficient P=near+2favourable is at most the full row boundary coefficient, since reverse-favourable is nonnegative after endpoint exchange. That full coefficient is at most V_y. Thus the low-J part of P has ONE lambda T W charge, not separate charges for its apparent summands. On high J the sharp near envelope plus TWO favourable terms give(1+2logK+2/K)X_q/(q_-T). The chosen T=(1+2logK+2/K)/(q_-epsilon) is valid for every epsilon>0 and gives exactly the displayed F. Adding the disjoint low-global-past G charge yields the specified remaining original positive G_largepast with strict Z>h. The q-oscillation/physical-radius core route is an ALTERNATIVE and is not billed here again.

K=exp(sqrt(n)) is the exponential parameter, not e*sqrt(n); h=sqrt(n)/q_- gives the claimed F bound. Original H is positive where the entrance contains1/H, while the standalone BH theorem permits H0. This direct full-positive route has no additional slot-internal lambda H completion; original8lambda H W and all outer terms stay. The ledger explicitly REPLACES the corresponding336 estimate, so another1/4 is not cumulatively added. Exact Fraction arithmetic gives2Lambda*(119/1024)=1/4, old1/256 yields65/256 and remainder191/256. The same-X/M3/source/scale aggregation is explicitly required; no sum of arbitrary unweighted leaf volumes or automatic remaining absorption is asserted.

The unpaid list correctly targets the exact G_largepast in this hard slot rather than re-listing the already paid near/equal-mass/favourable portions as unpriced here. General-soft dense crossing/later traffic, other hard slots not embedded in this scalar, broad-distance/lowpe/extreme-aspect complements, historical I_time/J_time/D_time, suffix/Phi_next credits, all H/scale/outer fees remain. No full uniform-root closure is claimed.

## Complete numeric-code/result scope review

Read ALL `/tmp/r337_numeric.py`, full notes/result scope, and both author verification scripts. PASS. Complete actual source face partitions, exact mean matching, true shared Iuv and ALL original physical prefixes are preserved in the finite receiver-quadrature stages. Original BH is exactly checked against the ordered source-set loss. The favourable partner and G mass gap retain the correct orientation and strict mass-ratio inequalities; equal-mass contributions do not acquire an artificial logarithmic price. The exact positive atanh logarithm bounds include an explicit geometric remainder; signed rational/log combinations switch enclosure endpoints correctly. Decimal80 log checks are ordinary diagnostics, kept separate.

The supplementary REAL receiver-dx model has selected cubes entirely inside Q4 with q1. All breakpoints for the two interval-overlap trapezoids are present, high-J affine crossings are split before integration, and polynomial division plus signed log coefficients correctly integrates j_a*j_b/(j_a+j_b). The source± factor2 cancels terminal ell1/2. The code computes the continuous mass gap and entropy, NOT its complete Iuv-weighted BH, as the notes state. Neither its finite models nor this exact1D integral provides a general entropy estimate or dimension fit. The numeric observation that entropy alone does not pay equal-mass/favourable contributions does not undo their independent analytic payment in main.

Reviewer additionally ran10 exact provenance/budget comparisons: final336 numeric source SHA and all6 embedded sources match, and the3 budget equalities match exactly. No full pipeline was repeated. Primary actual79 core+2448 aux+14902 numeric exact assertions and30 ordinary Decimal checks remain separate from reviewer95 preliminary algebra/quantile assertions and these10 metadata/budget assertions. Counts are not independent-input counts and do not extend stated model scopes.

## Final bounded verdict and bindings

FINAL PASS for core q-variation alternative, aux original small-global-past payment, main combined full-slot inequality, all reviewed numerical/code/result scope, and the final ledger. No outstanding substantive correction in reviewed bytes. Genuine new paid hard-pair portions are present, but G_largepast/D_K alternatives and all listed global complements remain UNPROVED at root price. No Git/other-author edits, no full rerun and no TeX/PDF compilation or word-for-word audit of later typesetting are claimed. Earlier awaiting-author statements are historical and superseded by this receipt.

- `/tmp/r337_core.md`: `65c2bd14f7c454218aa2409dfd231ca211846a412735273bdf3eec13361ac345`
- `/tmp/r337_core_checks.py`: `cb47ea43403ddecb53d7010d4afbf63788899446c73100d9cd6cf09952a5a43e`
- `/tmp/r337_aux.md`: `0a323620f8b628815a3af62d412fb604629ef917c2fa8209ef2add8c02f5805e`
- `/tmp/r337_aux_checks.py`: `4ead5ce8bd0c6d59ddb0d56ef5a93348c30b0fece7b5435a070286d21d10ce18`
- `/tmp/r337_main.md`: `e7ae785f3a751e5fcd9e45521e78b2103b3e79ecee67ba0be17822fb31b98768`
- `/tmp/r337_ledger.md`: `685e20c20e1aba02e792d18df681804622eb7374473ded0694170eff63061754`
- `/tmp/r337_numeric.py`: `0dfbad0cbbe969c0e9ab6cfc800d4ed5e76ee7b33137952ec87fc1df19095885`
- `/tmp/r337_numeric.md`: `35b44b902f84a2056d1c7160aacbaa59613c94c13005c8dc77cd92e45bc40391`
- `/tmp/r337_numeric_result.json`: `8806fd5802e6890b2e2ae088048288df03509e54961037d17de4ff1111ef329d`
