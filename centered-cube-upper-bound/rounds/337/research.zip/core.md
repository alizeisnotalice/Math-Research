# R337 — a paid q-oscillation error in the reverse mass-gap term

**Bounded conclusion.** The reverse–favorable difference is verified exactly. A directional expansion then pays all q-oscillation in that difference, at a source price proportional to K^{-1}; the remaining positive term is a physical-radius layer integral with the ORIGINAL q_u, μ, f, J, H and ell. No root bound for that radius-gap term is obtained. The layer-cake identity alone is not counted as a new payment. The source-bundle and near-mass branches are not reopened.

## 1. Contract, orientation, and exact cancellation

Use the R336 hard matched slot: f≥0 in L¹, ν≤f dx, finite actual E, a≤R≤b≤2a, q=h_R*f∈[q_-,λ], q_-=3λ/4, m_u=q(u)R(u)^n, dμ(u)=1_E(u)du/m_u, c_u(y)=1_{Q_u}(y). Keep every original prefix E_r, J_y(r), and `ell=b^{-n}δ_b+nr^{-n-1}dr`. Set X_q=∫_E q, W=∫f. Let

\[
 \Omega_K=\{(u,v):m_u>K m_v\},\qquad K>\lambda/q_-=4/3,
\]
\[
 S_H(r,u,v)=\int f(y)\frac{1_{J_y(r)\ge H}}{J_y(r)}c_u(y)c_v(y)dy,
 \quad I(u,v)=\int f(y)c_u(y)c_v(y)dy,
\]

with zero rows zero, and `dξ=ell(dr)1_{E_r²}dμ(u)dμ(v)`.
In this notation u is the LARGE-mass receiver. Define the original f-source boundary pieces

\[
 B_{\rm rev}(f,f)=\int_{\Omega_K}d\xi\,S_H(m_u-I),\qquad
 B_{\rm fav}(f,f)=\int_{\Omega_K}d\xi\,S_H(m_v-I).
\]

The second expression is the favorable ordered part after interchanging the receiver labels. Therefore

\[
 \boxed{B_{\rm rev}(f,f)-B_{\rm fav}(f,f)
       =G_K:=\int_{\Omega_K}d\xi\,S_H(m_u-m_v).}             \tag{1}
\]

The intersection mass cancels exactly. For the actual ν≤f,
`B_rev(f,ν)≤B_rev(f,f)` by positivity; no identity replaces ν by f inside its original pair loss.

## 2. A directional expansion with a genuinely paid error

The far-mass gate implies

\[
 R(u)^n/R(v)^n=(m_u/m_v)(q(v)/q(u))>Kq_-/\lambda>1.
\]

Thus R(u)>R(v) on Ω_K. Expand using the q of the LARGE receiver:

\[
 m_u-m_v=q(u)[R(u)^n-R(v)^n]+[q(u)-q(v)]R(v)^n.              \tag{2}
\]

Define

\[
 D_K=\int_{\Omega_K}d\xi\,S_H q(u)[R(u)^n-R(v)^n]\ge0,
\]
\[
 E_q=\int_{\Omega_K}d\xi\,S_H[q(u)-q(v)]R(v)^n,\qquad
 T_{\rm fav,H}=\int_{\Omega_K}d\xi\,S_Hm_v.
\]

Then G_K=D_K+E_q exactly. With η=(λ−q_-)/q_-=1/3,

\[
 \boxed{|E_q|\le\eta T_{\rm fav,H}.}                         \tag{3}
\]

Indeed `|q(u)−q(v)|R(v)^n≤ηm_v` pointwise. Expanding instead at q(v) would leave an error proportional to the expensive m_u; that substitution is not used.

The R336 favorable real-dx estimate, with the original gate retained, gives for every δ>0

\[
 T_{\rm fav,H}\le\delta X_q+\frac{\lambda}{Kq_-\delta}W.     \tag{4}
\]

Its receiver-volume argument and stopped original-J argument apply to this positive primitive, not just to the boundary difference. Consequently the entire q-oscillation error has the explicit receipt

\[
 |E_q|\le\varepsilon X_q+
                \frac{\eta^2\lambda}{Kq_-\varepsilon}W
 =\varepsilon X_q+\frac4{27K\varepsilon}W.                 \tag{5}
\]

Combining (1)–(4), and using B_fav≤T_fav,H, yields the valid reverse-slot upper bound

\[
 \boxed{B_{\rm rev}(f,\nu)
 \le D_K+\varepsilon X_q+
       \frac{(1+\eta)^2\lambda}{Kq_-\varepsilon}W
 =D_K+\varepsilon X_q+\frac{64}{27K\varepsilon}W.}           \tag{6}
\]

This pays a specific error and the favorable contribution. It does not pay D_K. It is an alternative accounting of those contributions; their R336 receipts must not be added again.

## 3. Exact radius layer and where the shared-source argument stops

The remaining positive term has the literal layer-cake representation

\[
 D_K=n\int_a^b t^{n-1}dt
 \int\ell(dr)\int f(y)\frac{1_{J_y(r)\ge H}}{J_y(r)}
 \iint_{E_r^2}1_{\Omega_K}1_{R(v)<t<R(u)}
       q(u)c_u(y)c_v(y)d\mu(u)d\mu(v)dy.                    \tag{7}
\]

Positive Fubini justifies this identity. Endpoint choices in the dt integral are immaterial; physical receiver-radius atoms still enter E_r and the ORIGINAL J exactly as before.

There is a precise shared-source description of the outstanding dependence. For each actual u put

\[
 J_{<u,K}(y)=\int_{m_v<m_u/K}c_v(y)d\mu(v),
\]
\[
 P_K(u,y)=\int_{m_v<m_u/K}c_v(y)
              [1-(R(v)/R(u))^n]d\mu(v),
\]
\[
 Z_H(u,y)=R(u)^n\int_{[R(u),b]}\ell(dr)
                    \frac{1_{J_y(r)\ge H}}{J_y(r)}.
\]

All receivers in these two cumulative integrals have R(v)<R(u), by the actual mass gate. They therefore remain in every later prefix in Z_H. In particular,

\[
 (1-\lambda/(Kq_-))J_{<u,K}\le P_K(u,\cdot)\le J_{<u,K}
                                      \le J_{\cdot}(R(u)). \tag{8}
\]

The actual local-mean constraint supplies the probability measure
`p_u(dy)=f(y)c_u(y)dy/m_u`. Rearranging (7) with no independence assumption gives

\[
 \boxed{D_K=\int_E q(u)du\int p_u(dy)\,
                    Z_H(u,y)P_K(u,y).}                     \tag{9}
\]

This formula is a diagnostic of the missing geometry, not a new budget. The exact elementary bounds are
`0≤Z_H P_K≤1` and `Z_H P_K≤J_{<u,K}/H`. The first follows from P_K≤J_y(r) for every later r and the inclusive ell tail. It gives only D_K≤X_q. The second preserves the high-row cutoff but the currently available narrow-mass occupancy estimate, summed over every older mass layer, loses the desired root scale. Neither bound uses a second independent copy of the posterior; such a copy cannot be inserted for free.

Thus the unresolved correlation is between the true posterior p_u on a large cube, the full OLD low-mass occupancy J_{<u,K}, and the later original inverse clock Z_H. The cancellation of I in (1) removes the immediate intersection-mass saving, and the expansion (2) only makes the bounded q oscillation cheap. A root estimate still needs a quantitative overlap/clock-growth estimate under these SAME p_u, not merely a scalar layer count, replacing J by J_max, or declaring small boundary volume to have small f-mass. No such estimate is established here.

## 4. Fees and verification

The only additional source fee proved here is (5), or the combined reverse accounting (6). All J, high-row masks and ell atoms are original. The entire nonnegative D_K is retained. There is no extra λH completion in this direct positive-pair route. Original entrance terms and other hard/soft/history slots remain unchanged. If an outer factor M multiplies this slot, choosing the absorption parameter ε/M in (6) gives `M D_K+εX_q+64M²W/(27Kε)`; the original outer costs also remain.

A reproducible exact-arithmetic check is saved in `/tmp/r337_core_checks.py`. It uses six cube intervals and a positive piecewise-constant continuum source, computes their masses and q values exactly (all in [3/4,1]), and tests finite receiver sums with full physical prefixes and inclusive Stieltjes weights. Across nine choices of K,H, its 79 Fraction assertions verified (1), (2), (3), ν domination, radius ordering, and the comparison (8) after integration. All passed exactly; 33 far prefix-pair occurrences were present. This is an algebra check using exact continuum-source cube masses, not a real-dx envelope theorem, a high-dimensional extremizer, or root evidence. The real-dx estimate (4) is the proved R336 receipt, not inferred from these finite receiver sums.

Only `/tmp/r337_core.md` and its necessary check `/tmp/r337_core_checks.py` are authored. Bounded delivery stops here; the general reverse root budget remains unproved.
