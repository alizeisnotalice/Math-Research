# R337 — original reverse loss, true shared overlap and entropy price

Run `r337_numeric.py` with the bundled Python. Standard library only; paths are relative to the source. It writes `r337_numeric_result.json` (about120KiB). Exact R334 sources and geometry are embedded with provenance, so no old data or optimizer is needed.

## Scope and original quantities

The main three stages retain actual centered cube receivers in n1/2/3, their physical radii1,3/2,2, q=λ=1 and positive finite receiver quadrature weights w. Full source space is partitioned at every receiver face, including zero-J patterns. Sources are compact positive L1 inputs, not point masses; each pattern mass is distributed over its actual positive-volume source cells. This main model is FINITE RECEIVER QUADRATURE, not Lebesgue dx or complete original history.

Stages are baseline uniform1_Q4 (three sources), the existing exactly repaired R334 H0/H1/8 sources (six), and both existing exact nullspace endpoints (six). Each is evaluated at gates H0 and1/8, yielding30 finite evaluations. All source means Cx=m are checked exactly; m_u=R_u^n, dμ_u=w_u/m_u. No new optimization or dimensional fit is performed.

The hard source is the SAME f as the outer source. Its actual joint captured mass is

I_uv=∫f(z)c_u(z)c_v(z)dz=Σ_source_cells x_s c_u(s)c_v(s),

not0, a density proxy or an independently chosen capacity. For the ordered original capture/miss term, source-z integration gives m_u−I_uv. The script checks that summing ALL these ordered terms reproduces the original B_H exactly, including the source-y high/J factor and final ell atom.

For K>1 and the single unordered domain m_u>K m_v, define

R_K=∫ell∫f_y1_high/J_y Σ c_u(y)c_v(y)(m_u−I_uv)dμ_u dμ_v,
P_K=∫ell∫f_y1_high/J_y Σ c_u(y)c_v(y)(m_v−I_uv)dμ_u dμ_v,
G_K=∫ell∫f_y1_high/J_y Σ c_u(y)c_v(y)(m_u−m_v)dμ_u dμ_v.

Thus R_K=P_K+G_K exactly, with R_K an actual part of the original B_H. Favorable P_K is the opposite original orientation on the SAME large/small pair domain. It is not an arbitrary favorable remainder defined by subtracting a mass primitive.

The unordered log-weighted price is

Elog=∫ell∫f_y1_high/J_y Σ_(m_u>m_v)c_u(y)c_v(y)(m_u−m_v)log(m_u/m_v)dμ_u dμ_v.

There is no factor2. K=5/4,3/2,2,4 are tested with STRICT m_u>K m_v. Since log(m_u/m_v)>logK on that domain,

G_K≤Elog/logK,
R_K≤P_K+Elog/logK.

The second statement still retains favorable P_K. Neither inequality says that entropy alone pays the whole original B_H.

## Exact and ordinary computation

All source moments, I, B_H, R/P/G and source means are exact fractions. Logarithms have rigorous rational lower/upper bounds from120 positive atanh terms and the explicit geometric tail. Exact checking uses Elog_lower≥G_K logK_upper. Thirty ordinary Decimal80 log evaluations cross-check the enclosures; these are separately counted, not called exact certificates. Strict equality boundary cases matter: n1 mass ratio3/2 gives G_(3/2)=0, and n2 maximum ratio4 gives G_4=0, while Elog need not vanish.

## Finite source results

For H0 ratio-source candidates:

|n|Elog/W|actual B_H/W|Elog/B_H|all unequal-pair G|
|---|---:|---:|---:|---:|
|1|.00454284|.02287307|.1986|.01972329|
|2|.01416171|.02576704|.5496|.06178728|
|3|.01050345|.01429785|.7346|.06713373|

Original uniform-source Elog/W is approximately.00202733,.00299438,.00108758. Removing unused mass and changing actual overlaps materially changes the normalized entropy fee, so those baseline values cannot be carried over to the repaired sources.

At K2, the n3 candidate has original reverse R≈.07127545, favorable P≈.00414172 and G≈.06713373. The entropy upper is about1.806G. Elog/log2 is about1.06 times the complete original B_H, illustrating a genuine positive fee rather than an automatically cheap bound. At n2,K2 the factor is1.719G. Near K1 the log denominator can make the bound much wider; n3,K5/4 gives5.609G. No optimizing K or asymptotic conclusion is asserted.

There is an important coverage limitation. Equal-mass receiver pairs contribute approximately22.20% and34.07% of original B_H in the n2/n3 H0 candidates. Their log-weighted mass gap is EXACTLY0. The code verifies the exact split B_H=equal-mass loss+both unequal orientations (all unequal ratios here exceed5/4). A complete proof would still have to pay that equal-mass traffic and the favorable orientation. This round only tests the proposed reverse-gap payment.

For matched H1/8 sources, Elog/W is approximately.00454284,.01335962,.00782422, versus actual B_H/W.02287307,.01986660,.00841422. Gates and source overlaps remain original; no primitive reverse or cherry-picked source support replaces them.

## Separate genuine receiver-dx model

A supplementary n1 model uses full f=β=ν=1_Q4, λ=q=1. Actual receivers are E_a=Q_(3/4) assigned R_a=1 and E_b=Q_(7/4) minus Q_(3/4) assigned R_b=2. Their kernel cubes stay inside Q4 for EVERY receiver point, so actual FIRST and selected hard caps hold throughout a positive-volume receiver field.

For source y, let

j_a(y)=|Q_(3/4)∩Q_1(y)|,
j_b(y)=[|Q_(7/4)∩Q_2(y)|−|Q_(3/4)∩Q_2(y)|]/2.

The only cross-mass gap is (2−1)j_a j_b/(j_a+j_b). Its source integral at the terminal ell weight1/2 is computed exactly as a piecewise rational-plus-log integral. Trap breakpoints and the high-J crossing are split explicitly. The source ±y factor2 cancels terminal1/2. No receiver samples, source samples or numerical quadrature are used. The entropy is exactly G log2.

|H|true-dx G|true-dx Elog/W, W4|
|---|---:|---:|
|0|.163547326|.028340592|
|1/8|.163547326|.028340592|
|1/2|.144369024|.025017246|

K<2 captures this gap; K≥2 excludes it by the strict gate. Exact log enclosures verify the same entropy threshold bound. Original full B_H in this continuous receiver model is NOT computed, since its I_uv-weighted loss requires additional receiver-pair integration. This model certifies a nonzero genuine-dx reverse difference and entropy price, not a whole original-traffic budget or full history.

## Execution and decision

Two fresh standalone runs pass **14,902 exact rational/integer checks** plus **30 ordinary Decimal diagnostics**, kept separate. Main-stage exact counts are4,884/4,999/4,999; the remaining20 checks cover true-dx source integrals and threshold endpoints. Geometry is rebuilt per stage; counts are not numbers of independent examples.

The evidence supports the algebraic entropy payment of G_K with all actual overlaps preserved. Its numerical cost is material, depends on K, and leaves favorable/equal-mass traffic. Nothing here proves a dimension-uniform bound for Elog/W or converts finite receiver quadrature into a continuum receipt. Minimal replay files are this Python source, note and small result JSON; no regenerated large input is needed.
