#!/usr/bin/env python3
"""Exact checks for mass-CDF layercake and a real-dx small-past G branch."""
from fractions import Fraction as F
import json
count=0

def check(ok):
 global count
 assert ok
 count+=1

def logbox(x,N=60):
 check(x>=1)
 z=(x-1)/(x+1);lo=2*sum((z**(2*k+1)/F(2*k+1) for k in range(N)),F(0))
 hi=lo+2*z**(2*N+1)/(F(2*N+1)*(1-z*z))
 return lo,hi

def length_intersect(lo,hi,a,b):return max(F(0),min(hi,b)-max(lo,a))

r=[F(1),F(3,2),F(2)]
regions=[[(F(-1,4),F(1,4))],[(F(-1,2),F(-1,4)),(F(1,4),F(1,2))],
         [(F(-3,4),F(-1,2)),(F(1,2),F(3,4))]]
ell=[1/r[i]-(1/r[i+1] if i<2 else 0) for i in range(3)]
Ks=[F(1),F(4,3),F(3,2),F(2)];qlo=F(3,4);H=F(1)
Cupper={K:(1+logbox(K)[1])/qlo for K in Ks}
Anupper=1+logbox(F(2))[1]

def row(y):
 return [sum((length_intersect(lo,hi,y-R/2,y+R/2) for lo,hi in E),F(0))/R
         for R,E in zip(r,regions)]

def CDF(g,t,strict=False):
 return sum((v for v,m in zip(g,r) if m<t or (not strict and m==t)),F(0))

def pair(g,K):
 return sum((a*b*(ma-mb) for a,ma in zip(g,r) for b,mb in zip(g,r) if ma>K*mb),F(0))

def layer(g,K):
 J=sum(g);upper=max(r)
 knots=sorted(set([F(0),upper]+[z for m in r for z in [m,K*m] if 0<z<upper]))
 one=sum(((b-a)*CDF(g,(a+b)/(2*K))*(J-CDF(g,(a+b)/2)) for a,b in zip(knots,knots[1:])),F(0))
 two=(K-1)*sum((m*v*(J-CDF(g,K*m)) for m,v in zip(r,g)),F(0))
 return one+two

for yint in range(-16,17):
 y=F(yint,4);g=row(y)
 # Actual full receiver field: q=1 since all its cubes lie in source [-4,4].
 check(all(-4<=lo-R/2 and hi+R/2<=4 for R,E in zip(r,regions) for lo,hi in E))
 for k in range(3):
  gg=g[:k+1]+[F(0)]*(2-k);J=sum(gg)
  for K in Ks:check(pair(gg,K)==layer(gg,K))
  if J:
   V=sum(m*v for m,v in zip(r,gg));coeff=[F(0)]*3
   for i in range(3):
    for j in range(3):
     if r[i]>r[j]:
      v=gg[i]*gg[j]*(r[i]-r[j])/J
      coeff[i]+=v;coeff[j]-=v
   check(coeff==[gg[i]*(r[i]-V/J) for i in range(3)])
 for K in Ks:
  for h in [F(0),F(1,8),F(1,2),F(1)]:
   allowed=[CDF(g,m/K,strict=True)<=h for m in r]
   mass=sum(v for v,ok in zip(g,allowed) if ok)
   check(mass<=h+Cupper[K])
   G=F(0)
   for k in range(3):
    J=sum(g[:k+1])
    if not J or J<H:continue
    inner=sum((g[i]*g[j]*(r[i]-r[j]) for i in range(k+1)
       for j in range(k+1) if r[i]>K*r[j] and allowed[i]),F(0))
    G+=ell[k]*inner/J
   check(G<=mass)
   check(G<=h+Cupper[K])
 # Closed mass bands test actual atoms, including singleton mass bands.
 for lo in r:
  for hi in r:
   if hi<lo:continue
   check(sum(v for v,m in zip(g,r) if lo<=m<=hi)
         <=(1+logbox(hi/lo)[1])/qlo)

central=[]
for y in [F(-1,8),F(0),F(1,8)]:
 g=row(y);check(g==[F(1,2),F(1,3),F(1,4)])
 K=F(3,2);h=F(1,2);G=F(0)
 for k in range(3):
  J=sum(g[:k+1])
  if J<H:continue
  G+=ell[k]*sum((g[i]*g[j]*(r[i]-r[j]) for i in range(k+1)
    for j in range(k+1) if r[i]>K*r[j] and CDF(g,r[i]/K,strict=True)<=h),F(0))/J
 check(G==F(3,52));central.append(str(G))
check(F(1,2)*F(3,52)==F(3,104))
print(json.dumps(dict(status='PASS',checks=count,
 fixture='actual_1d_Lebesgue_receiver_shells_q1_source_indicator[-4,4]',
 central_row_G=central,positive_central_source_contribution='3/104',
 strict_ratio='K=3/2 excludes equality m_i=K*m_j',
 scope='Exact CDF/row algebra and constant positive-source slab; not full-source G integration or root evidence'),sort_keys=True))
