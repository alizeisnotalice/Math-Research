#!/usr/bin/env python3
"""Original reverse-loss mass gap and log-weighted fee on actual cube patterns."""
from fractions import Fraction as F
from decimal import Decimal,localcontext
from functools import lru_cache
from collections import Counter
from itertools import product
from pathlib import Path
import json,hashlib
BASE=Path(__file__).resolve().parent
C=Counter();DCOUNTS=Counter()
def ck(k,v):C[k]+=1;assert v,k
def dck(k,v):DCOUNTS[k]+=1;assert v,k
def dec(x):return Decimal(x.numerator)/Decimal(x.denominator)
@lru_cache(None)
def logbounds(r):
 if r==1:return F(0),F(0)
 if r<1:
  a,b=logbounds(1/r);return -b,-a
 t=(r-1)/(r+1);lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(120)),F(0));return lo,lo+2*t**241/(241*(1-t*t))
def brief(x):
 a=abs(x.numerator)
 if max(a.bit_length(),x.denominator.bit_length())<700:return str(x)
 raw=(str(x<0)+':'+str(a.bit_length())+':').encode()+a.to_bytes((a.bit_length()+7)//8,'big')+b'/'+x.denominator.to_bytes((x.denominator.bit_length()+7)//8,'big')
 return dict(decimal=float(x),sha256=hashlib.sha256(raw).hexdigest(),encoding='negative:numerator_bitlength:unsigned_numerator_bytes/unsigned_denominator_bytes')
def groups(n,recv):
 axes=[sorted(set([F(-2),F(2)]+[x[a]+s*r/2 for x,r,w in recv for s in [-1,1]])) for a in range(n)];g={}
 for ids in product(*[range(len(a)-1) for a in axes]):
  box=[(axes[a][i],axes[a][i+1]) for a,i in enumerate(ids)];mass=F(1)
  for lo,hi in box:mass*=hi-lo
  c=tuple(int(all(lo>=x[a]-r/2 and hi<=x[a]+r/2 for a,(lo,hi) in enumerate(box))) for x,r,w in recv)
  for v,(x,r,w) in zip(c,recv):ck('actual_complete_source_incidence',v or any(hi<=x[a]-r/2 or lo>=x[a]+r/2 for a,(lo,hi) in enumerate(box)))
  g[c]=g.get(c,F(0))+mass
 ck('original_source_total',sum(g.values())==4**n)
 return sorted(g),g

def analyze(n,recv,sigs,x,H,name):
 mi=[r**n for y,r,w in recv];w=[w for y,r,w in recv];mu=[a/b for a,b in zip(w,mi)];N=len(mi);W=sum(x);X=sum(w);I=[[sum(v*c[i]*c[j] for v,c in zip(x,sigs)) for j in range(N)] for i in range(N)]
 ck('actual_receiver_mean_q1',all(I[i][i]==mi[i] for i in range(N)))
 ck('true_shared_source_overlap',all(0<=I[i][j]<=min(mi[i],mi[j]) for i in range(N) for j in range(N)))
 radii=sorted(set(r for y,r,w in recv));Ks=[F(5,4),F(3,2),F(2),F(4)];amounts={K:[F(0),F(0),F(0)] for K in Ks};entropy={};Ball=BH=reverse_first=gap_all=equal_mass_loss=F(0)
 for k,radius in enumerate(radii):
  ell=radius**(-n)-(radii[k+1]**(-n) if k+1<len(radii) else 0);active=[i for i,(y,r,w) in enumerate(recv) if r<=radius];J=[sum(mu[i]*c[i] for i in active) for c in sigs]
  ordered=F(0)
  for i in active:
   for j in active:
    # Original source-z capture/miss loss is m_i-I_ij, not a primitive mass.
    coefficient=ell*mu[i]*mu[j]*sum((v*c[i]*c[j]/jj for v,c,jj in zip(x,sigs,J) if jj and jj>=H),F(0));loss=coefficient*(mi[i]-I[i][j]);ordered+=loss
    if mi[i]==mi[j]:equal_mass_loss+=loss
    if mi[i]>mi[j]:
     ratio=mi[i]/mi[j];gap=coefficient*(mi[i]-mi[j]);gap_all+=gap;entropy[ratio]=entropy.get(ratio,F(0))+gap
     for K in Ks:
      if mi[i]>K*mi[j]:
       amounts[K][0]+=loss;amounts[K][1]+=coefficient*(mi[j]-I[i][j]);amounts[K][2]+=gap
  direct=F(0)
  for v,c,jj in zip(x,sigs,J):
   if jj:
    V=sum(w[i]*c[i] for i in active);square=sum(mu[i]*mu[j]*c[i]*c[j]*I[i][j] for i in active for j in active)/jj;Ball+=ell*v*(V-square)
    if jj>=H:direct+=ell*v*(V-square);reverse_first+=ell*v*V
  ck('original_BH_ordered_loss_identity',ordered==direct)
  BH+=direct
 ck('high_loss_within_all_loss',0<=BH<=Ball<=X)
 ck('equal_unequal_original_loss_partition',BH==equal_mass_loss+amounts[F(5,4)][0]+amounts[F(5,4)][1])
 if H==0:ck('all_row_reverse_first',reverse_first==X)
 Elo=Ehi=F(0)
 for ratio,coeff in entropy.items():
  lo,hi=logbounds(ratio);Elo+=coeff*lo;Ehi+=coeff*hi
 with localcontext() as ctx:
  ctx.prec=80;numeric=sum((dec(c)*dec(r).ln() for r,c in entropy.items()),Decimal(0));dck('ordinary_log_diagnostic',dec(Elo)-Decimal('1e-65')<=numeric<=dec(Ehi)+Decimal('1e-65'))
 results=[]
 for K,(R,favorable,G) in amounts.items():
  ck('original_reverse_favorable_massgap',R==favorable+G and min(R,favorable,G)>=0)
  kl,ku=logbounds(K);ck('certified_entropy_threshold',G*ku<=Elo)
  ck('reverse_is_original_traffic_part',R<=BH)
  results.append(dict(K=str(K),strict_gate=True,reverse_original_loss=float(R),favorable_swapped_original_loss=float(favorable),G_massgap=float(G),reverse_exact=brief(R),favorable_exact=brief(favorable),G_exact=brief(G),G_over_W=float(G/W),entropy_over_logK_lower=float(Elo/ku),entropy_over_logK_upper=float(Ehi/kl),bound_over_G=float(Ehi/kl/G) if G else None))
 return dict(n=n,source=name,H=str(H),W_exact=str(W),X_exact=str(X),BH_exact=brief(BH),Ball_exact=brief(Ball),BH=float(BH),Ball=float(Ball),BH_over_W=float(BH/W),BH_equal_receiver_mass=float(equal_mass_loss),BH_equal_receiver_mass_fraction=float(equal_mass_loss/BH) if BH else None,raw_all_massgap=float(gap_all),Elog_lower=brief(Elo),Elog_upper=brief(Ehi),Elog_mid=float((Elo+Ehi)/2),Elog_over_W_lower=float(Elo/W),Elog_over_W_upper=float(Ehi/W),Elog_over_BH=float(Ehi/BH) if BH else None,reverse_first=float(reverse_first),thresholds=results)

def trap(a,r,y):return max(F(0),min(a,r,(a+r)/2-abs(y)))
def true_dx(H):
 # Actual concentric positive-dx receivers: side3/4 at R1 and Q7/4\Q3/4 at R2.
 points=sorted(set([F(0),F(2),F(1,8),F(7,8),F(5,8),F(11,8),F(15,8)]));rational=F(0);logs={}
 for a,b in zip(points,points[1:]):
  def vals(y):return trap(F(3,4),F(1),y),(trap(F(7,4),F(2),y)-trap(F(3,4),F(2),y))/2
  aa,bb=vals(a);ae,be=vals(b);slope=((ae+be)-(aa+bb))/(b-a);cuts=[a,b]
  if slope and a<(cross:=a+(H-aa-bb)/slope)<b:cuts.insert(1,cross)
  for l,u in zip(cuts,cuts[1:]):
   av,bv=vals(l);au,bu=vals(u);L=u-l;c0=av+bv;c1=((au+bu)-c0)/L
   if not c0 and not c1:continue
   if (c0+c1*L/2)<H:continue
   a1=(au-av)/L;b1=(bu-bv)/L;p0=av*bv;p1=av*b1+a1*bv;p2=a1*b1
   if c1==0:
    rational+=(p0*L+p1*L*L/2+p2*L**3/3)/c0
   else:
    q1=p2/c1;q0=(p1-q1*c0)/c1;rem=p0-q0*c0;rational+=q1*L*L/2+q0*L
    if rem:
     ck('true_dx_log_positive_arguments',c0>0 and c0+c1*L>0);arg=(c0+c1*L)/c0;logs[arg]=logs.get(arg,F(0))+rem/c1
 # Full source ±y factor2 cancels terminal ell=1/2; m_big-m_small=1.
 lo=hi=rational
 for r,c in logs.items():
  a,b=logbounds(r);lo+=c*(a if c>=0 else b);hi+=c*(b if c>=0 else a)
 ck('true_dx_positive_massgap',0<lo<=hi)
 l2,u2=logbounds(F(2))
 for K in [F(5,4),F(3,2),F(2),F(4)]:
  kl,ku=logbounds(K);gated_upper=hi if K<2 else F(0);ck('true_dx_entropy_threshold',gated_upper*ku<=lo*l2)
 return dict(H=str(H),true_receiver_dx=True,receiver_small_side='3/4',receiver_outer_side='7/4',actual_radii=['1','2'],f='uniform1 on Q4, source mass4; q1 for all actual receiver points',G_terminal_cross_lower=brief(lo),G_terminal_cross_upper=brief(hi),G_decimal=float((lo+hi)/2),Elog_lower=brief(lo*l2),Elog_upper=brief(hi*u2),Elog_over_W_lower=float(lo*l2/4),scope='Exact piecewise rational+log integral of block massgap and entropy, not original full BH. No receiver/source sampling or quadrature error.')

def main():
 models=[];stages=[]
 for stage in ['baseline','ratio_sources','endpoint_stress']:
  before=sum(C.values())
  for label,n,recv in fixtures():
   sigs,g=groups(n,recv);orig=[g[c] for c in sigs];mi=[r**n for y,r,w in recv]
   if stage=='baseline':sources=[('original_uniform_Q4',orig)]
   elif stage=='ratio_sources':
    sources=[]
    for gate in ['H0','H1over8']:
     snap=SOURCE_SNAPSHOT[str(n)+'_'+gate];by={tuple(c):F(v) for c,v in zip(snap['signatures'],snap['x'])};sources.append(('R334_'+gate,[by.get(c,F(0)) for c in sigs]))
   else:sources=endpoint_sources(sigs,orig,mi)
   for name,x in sources:
    for H in [F(0),F(1,8)]:models.append(analyze(n,recv,sigs,x,H,name))
  stages.append(dict(stage=stage,exact_checks=sum(C.values())-before))
 dx=[true_dx(F(0)),true_dx(F(1,8)),true_dx(F(1,2))]
 out=dict(status='PASS',total_exact_checks=sum(C.values()),exact_check_counts=dict(C),ordinary_decimal_checks=sum(DCOUNTS.values()),ordinary_decimal_check_counts=dict(DCOUNTS),stages=stages,finite_models=models,true_dx_models=dx,provenance=SNAPSHOT_PROVENANCE,scope='Original reverse capture/miss loss with true Iuv, full source patterns, actual cubes. Finite receiver quadrature in main stages; separate n1 TRUEdx massgap/entropy integral. No optimizer, dimension fit, general entropy receipt or full history claim.')
 (BASE/'r337_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',exact_checks=sum(C.values()),ordinary_decimal_checks=sum(DCOUNTS.values()),finite_evaluations=len(models),true_dx_evaluations=len(dx),stages=stages),sort_keys=True))

def fixtures():
 return [('n1',1,[((F(-1,4),),F(1),F(1,5)),((F(1,4),),F(3,2),F(1,5))]),('n2',2,[((F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(-1,2)),F(1),F(1,10)),((F(1,2),F(1,2)),F(3,2),F(1,5)),((F(0),F(0)),F(2),F(1,10))]),('n3',3,[((F(-1,2),F(0),F(0)),F(1),F(1,10)),((F(0),F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(0),F(1,2)),F(3,2),F(1,10)),((F(1,2),F(1,2),F(0)),F(3,2),F(1,10)),((F(0),F(0),F(0)),F(2),F(1,10))])]
def endpoint_sources(sigs,orig,mi):
 non=[i for i,c in enumerate(sigs) if any(c)];cols=[sigs[i] for i in non];N=len(mi);A=[[F(c[i]) for c in cols] for i in range(N)];rr=0;piv=[]
 for col in range(len(cols)):
  found=next((i for i in range(rr,N) if A[i][col]),None)
  if found is None:continue
  A[rr],A[found]=A[found],A[rr];v=A[rr][col];A[rr]=[x/v for x in A[rr]]
  for i in range(N):
   if i!=rr:
    v=A[i][col];A[i]=[x-v*y for x,y in zip(A[i],A[rr])]
  piv.append(col);rr+=1
  if rr==N:break
 free=next(i for i in range(len(cols)) if i not in piv);d=[F(0)]*len(cols);d[free]=1
 for row,col in enumerate(piv):d[col]=-A[row][free]
 out=[];base=[orig[i] for i in non]
 for sign in [-1,1]:
  v=[sign*x for x in d];t=min(-x/y for x,y in zip(base,v) if y<0);full=[F(0)]*len(sigs)
  for i,x,y in zip(non,base,v):full[i]=x+t*y
  out.append((f'null_endpoint_sign_{sign}',full))
 return out
SOURCE_SNAPSHOT = {'1_H0': {'signatures': [[0, 1], [1, 0], [1, 1]], 'x': ['110927627/145885118', '18992534/72942559', '53950025/72942559']}, '1_H1over8': {'signatures': [[0, 1], [1, 0], [1, 1]], 'x': ['110927627/145885118', '18992534/72942559', '53950025/72942559']}, '2_H0': {'signatures': [[0, 0, 0, 1], [0, 0, 1, 0], [0, 0, 1, 1], [0, 1, 0, 1], [0, 1, 1, 1], [1, 0, 0, 1], [1, 0, 1, 1], [1, 1, 0, 1], [1, 1, 1, 1]], 'x': ['152192675345354542508815/111014552212439362614092', '85979941608203/117492357305350462170218', '67636281/67089491', '111931209459059/150777896946455508989764', '56578442/91119697', '111931209459059/150777896946455508989764', '56578442/91119697', '32636771/86095918', '41/38439068']}, '2_H1over8': {'signatures': [[0, 0, 0, 1], [0, 0, 1, 0], [0, 0, 1, 1], [0, 1, 0, 1], [0, 1, 1, 1], [1, 0, 0, 1], [1, 0, 1, 1], [1, 1, 0, 1], [1, 1, 1, 1]], 'x': ['41124905712548/19183577004021', '172102783108485012209/437079922942850737428', '15498842/54211263', '47/4031264895478', '6497413/11392034', '47/4031264895478', '6497413/11392034', '0', '152040/353867']}, '3_H0': {'signatures': [[0, 0, 0, 0, 1], [0, 0, 0, 1, 0], [0, 0, 0, 1, 1], [0, 0, 1, 0, 0], [0, 0, 1, 0, 1], [0, 0, 1, 1, 1], [0, 1, 0, 0, 1], [0, 1, 0, 1, 1], [0, 1, 1, 0, 1], [0, 1, 1, 1, 1], [1, 0, 0, 0, 1], [1, 0, 0, 1, 1], [1, 0, 1, 0, 1], [1, 0, 1, 1, 1], [1, 1, 0, 0, 1], [1, 1, 0, 1, 1], [1, 1, 1, 0, 1], [1, 1, 1, 1, 1]], 'x': ['4427208217662176873923899605435104719801910732720069/1553012758086789705933097045293926421416243062528368', '9069628557741113471982278370985520477352474076753/557011166154917661470830900804615459045965902613581936376', '109951249/78606499', '23420327782968043843502544128714838662811557718256213/1438359231874780692476777865308294502211726654579517026236012', '96607821/69066997', '45726070/59629773', '242612854204622554633088594081394238046139619/1754261154533557326602070738752568555842629427839248', '6977014/83064919', '6133347/73020632', '4845835/11622246', '888386820965112287087277719689633629120072089351/6423660010772338539841551689887334583782197006626170928', '7651719/91097627', '7436688/88537573', '39714235/95250583', '11/98616464', '10016407/48264251', '19364335/93307423', '5/18827343']}, '3_H1over8': {'signatures': [[0, 0, 0, 0, 1], [0, 0, 0, 1, 0], [0, 0, 0, 1, 1], [0, 0, 1, 0, 0], [0, 0, 1, 0, 1], [0, 0, 1, 1, 1], [0, 1, 0, 0, 1], [0, 1, 0, 1, 1], [0, 1, 1, 0, 1], [0, 1, 1, 1, 1], [1, 0, 0, 0, 1], [1, 0, 0, 1, 1], [1, 0, 1, 0, 1], [1, 0, 1, 1, 1], [1, 1, 0, 0, 1], [1, 1, 0, 1, 1], [1, 1, 1, 0, 1], [1, 1, 1, 1, 1]], 'x': ['1102263955985462639645696207051/322408913886015672509181343095', '898238076882875450257393373195/4847202747846505250602092260232', '48470485/34833957', '1296683457332360839897830014461/6997351569953595983890100052920', '69971289/50285795', '39958693/72919309', '220646/238537049318033', '0', '0', '23647347/94501669', '220646/238537049318033', '0', '0', '23647347/94501669', '0', '0', '0', '1892532/2524157']}}
SNAPSHOT_PROVENANCE = {'file': 'r336_numeric.py', 'sha256': '059175ebf2c90dfcb321e50b3ea2bb8e0fc30d42db018f0dcae69c15c0e14de0', 'note': 'Exact sources and standalone geometry helpers copied; no runtime dependency.'}
if __name__=='__main__':main()
