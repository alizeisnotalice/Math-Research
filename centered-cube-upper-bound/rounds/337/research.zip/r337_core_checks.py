from fractions import Fraction as F
from itertools import product
centers=[F(-2),F(-1),F(-3,10),F(7,10),F(8,5),F(23,10)]
radii=[F(1),F(2),F(6,5),F(9,5),F(7,5),F(2)]
ends=sorted(set([F(-4),F(4)]+[u+sgn*r/2 for u,r in zip(centers,radii) for sgn in (-1,1)]))
cells=list(zip(ends,ends[1:])); ys=[(l+r)/2 for l,r in cells]
dens=[F(3,4),F(4,5),F(19,20),F(1)]
f=[(r-l)*dens[j%4] for j,(l,r) in enumerate(cells)]
nu=[v*F(j%4,3) for j,v in enumerate(f)]
c=[[int(abs(y-u)<=r/2) for y in ys] for u,r in zip(centers,radii)]
m=[sum(v*b for v,b in zip(f,row)) for row in c]
q=[v/r for v,r in zip(m,radii)]; mu=[F(1,5)/v for v in m]
assert all(F(3,4)<=v<=1 for v in q)
rs=sorted(set(radii)); ell=[1/rs[i]-1/rs[i+1] for i in range(len(rs)-1)]+[1/rs[-1]]
eta=F(1,3); checks=1; max_error=F(0); nonzero=0
for K,H in product([F(3,2),F(2),F(5,2)],[F(0),F(1,5),F(3,5)]):
 rev=fav=gap=radial=qerror=tfav=revnu=oldclock=F(0)
 for r,lweight in zip(rs,ell):
  active=[u for u in range(len(m)) if radii[u]<=r]
  J=[sum(mu[u]*c[u][y] for u in active) for y in range(len(ys))]
  for u in active:
   for v in active:
    if m[u]<=K*m[v]: continue
    assert radii[u]>radii[v]; checks+=1; nonzero+=1
    SG=sum(f[y]*c[u][y]*c[v][y]/J[y] for y in range(len(ys)) if J[y]>0 and J[y]>=H)
    I=sum(f[y]*c[u][y]*c[v][y] for y in range(len(ys)))
    Nd=sum(nu[y]*c[u][y]*(1-c[v][y]) for y in range(len(ys)))
    wt=lweight*mu[u]*mu[v]*SG
    rev+=wt*(m[u]-I); fav+=wt*(m[v]-I); gap+=wt*(m[u]-m[v])
    radial+=wt*q[u]*(radii[u]-radii[v]); qerror+=wt*(q[u]-q[v])*radii[v]
    tfav+=wt*m[v]; revnu+=wt*Nd
    oldclock+=wt*m[u]
 assert rev-fav==gap; checks+=1
 assert gap==radial+qerror; checks+=1
 assert abs(qerror)<=eta*tfav; checks+=1
 assert revnu<=rev; checks+=1
 assert (1-F(4,3)/K)*oldclock<=radial<=oldclock; checks+=1
print({'exact_assertions':checks,'cases':9,'far_prefix_pair_occurrences':nonzero,'scope':'finite receiver algebra with exact continuum-source cube masses; not a real-dx envelope or root test'})
