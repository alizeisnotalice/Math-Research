# R337 — mass-CDF occupation and a source-paid small-past branch

**New paid portion.** Keeping the real receiver `dx` and all original prefixes, the part of `G_K` whose smaller-mass past has cumulative receiver load at most `h` is paid by (6). The price is source-linear and logarithmic in `K`, not a product of source masses. Whole quantile atoms are included. Large-past traffic remains explicitly unpaid. The entropy identity is independently verified, but no `O(nW_f)` entropy budget is asserted.

## 1. Original field and the new subgate

Use the hard real-`dx` matched field: `f≥0` in `L¹`, `Tf=q`, `q_-≤q≤λ`, `q_-=3λ/4`, `a≤R(u)≤b≤2a`, finite `E`,

\[
 m_u=q(u)R(u)^n,\quad d\mu(u)=1_E(u)du/m_u,\quad c_u(y)=1_{Q_{R(u)}(u)}(y),
\]
\[
 E_r=E\cap\{R\le r\},\quad J_y(r)=\int_{E_r}c_u(y)d\mu(u),\quad
 \ell=b^{-n}\delta_b+nr^{-n-1}1_{[a,b]}dr.
\]

Keep the SAME full `J` and original gate `J≥H`. All zero rows contribute zero. The given positive residue is

\[
 G_K=\int\ell(dr)\int f(y)\frac{1_{J_y(r)\ge H}}{J_y(r)}
 \iint_{E_r²:m_u>Km_v}c_u(y)c_v(y)(m_u-m_v)d\mu(u)d\mu(v)dy.
\]

Define the GLOBAL mass-clock CDF of the same real receiver field,

\[
 Z_y(t)=\int_E c_u(y)1_{m_u\le t}d\mu(u),\qquad
 Z_y(t-)=\int_Ec_u(y)1_{m_u<t}d\mu(u).                       \tag{1}
\]

It is measurable, finite and right-continuous in `t`; `Z_y(∞)≤A_n/q_-`, `A_n=1+n log(b/a)`. For `h≥0`, define `G_(K,≤h)` by adding ONLY the positive subgate `Z_y(m_u/K−)≤h` to the original integrand. The complementary `G_(K,>h)` uses `>`; these sum exactly to the given `G_K`. Other original positive masks, if present, may remain on both subbranches and in the left side of the receipt. Nothing is reset in the denominator.

For the scale-predictable application take `K>λ/q_-`. Indeed

\[
 m_v<m_u/K\Longrightarrow
 R(v)^n\le m_v/q_-<\lambda R(u)^n/(Kq_-)<R(u)^n.              \tag{2}
\]

Thus every receiver in the strict global past at the larger endpoint already has strictly smaller physical radius. The global CDF is not an anticipative replacement in this regime. The analytic bound below also holds for `K≥1` as a frozen-field subgate; this does not supply predictability for smaller `K`.

## 2. Sharp mass-band row capacity, using real receiver density

For every `s>0,K≥1` and every source position,

\[
 \boxed{\quad Z_y([s,Ks])\le\frac{1+\log K}{q_-}.\quad}       \tag{3}
\]

To prove this, set `v=(2||u−y||∞)^n`. When `c_u(y)=1` and `m_u∈[s,Ks]`, the actual density satisfies

\[
 \frac1{m_u}\le\min\{s^{-1},(q_-v)^{-1}\},\qquad
 v\le Ks/q_-.
\]

The Lebesgue volume of `{u:v≤t}` is exactly `t`. Integrating this REAL receiver majorant gives

\[
 \int_0^{Ks/q_-}\min(s^{-1},(q_-v)^{-1})dv
       =\frac{1+\log K}{q_-}.
\]

No bound on source density is used. In particular a whole mass-clock atom has load at most `1/q_-`. This is a mass-clock statement, not an unproved physical-radius atom assertion. Keeping the physical band yields the further computable majorant

\[
 \int_0^{\min(b^n,Ks/q_-)}
       \min\{s^{-1},[q_-\max(a^n,v)]^{-1}\}dv.
\]

In particular use

\[
 C_K:=q_-^{-1}\min\{A_n,1+\log K\}                          \tag{4}
\]

as a uniform closed-band bound. Formula (3) requires the true `du/m_u` density; it is not inherited by an arbitrary finite receiver quadrature.

## 3. Quantile occupation pays the entire small-past subbranch

At fixed `y`, let `L_y={u:c_u(y)=1,Z_y(m_u/K−)≤h}`. Then

\[
 \int_{L_y}d\mu(u)\le h+C_K.                                \tag{5}
\]

If the total CDF load is at most `h`, this is immediate. Otherwise let `τ=inf{t:Z_y(t)>h}`. The strict-past definition gives `Z_y(τ−)≤h`; if `Z_y(t/K−)≤h`, monotonicity implies `t≤Kτ`. Hence all allowed larger endpoints lie below `τ` or in the CLOSED band `[τ,Kτ]`. The first part has load at most `h`, and (3) pays the entire second part, including the whole crossing atom and the upper endpoint atom. There is no artificial rank split of an atom. The argument also covers a continuous crossing with value exactly `h`.

Now integrate the ORIGINAL physical `r` before source masses. For each allowed larger endpoint, drop only `m_u−m_v≤m_u` and use the actual smaller-endpoint posterior fraction

\[
 J_y(r)^{-1}\int_{E_r:m_v<m_u/K}c_v(y)d\mu(v)\le1.
\]

The inclusive tail is `∫_[R(u),b]ell=R(u)^−n`, so `m_uR(u)^−n=q(u)≤λ`. Combining with (5) and then integrating the same `f(y)dy` ONCE gives

\[
 \boxed{\quad G_{K,\le h}\le\lambda(h+C_K)W_f.\quad}          \tag{6}
\]

The original high-`J` gate has only been dropped as a positive upper bound, not replaced by a low-`J` gate. One may retain the additional pointwise cap `Z_y(∞)≤A_n/q_-`, or use a measurable source-dependent threshold `h(y)` with the explicitly charged price `λ∫f h(y)+λC_KW_f`; neither choice is free.

For `λh=O(√A_n polylog(n+2))` and `log K=O(√A_n polylog(n+2))`, (6) is a genuine root/polylog source price for this specified part of the original residue. The exact unpaid complement is

\[
 G_{K,>h}=\int\ell\int f(y)\frac{1_{J\ge H}}J
 \iint_{E_r²:m_u>Km_v}c_uc_v(m_u-m_v)
                 1_{Z_y(m_u/K-)>h}d\mu(u)d\mu(v)dy.          \tag{7}
\]

No claim is made that it is empty or paid. Choosing `h=A_n/q_-` covers everything but merely recovers an order-`A_n` source bound. Near-ratio and favorable-orientation receipts remain their separate original pieces; their budgets are not reused here. The new use is the global MASS-past window of the remaining `G_K`, including traffic at original high outer `J`; its ingredients are the old stopping idea and the real-density mass-band estimate.

## 4. Exact CDF and entropy identities; the remaining budget

These identities locate, but do not pay, the large-past occupation. At a fixed original `(y,r)`, let `γ` be the pushforward of `c_u(y)dμ(u)` on `E_r` under `m_u`, with CDF `F(t)=γ((0,t])`, total `J`, and first moment `V=∫m dγ=V_y(r)`. Then, with all atoms retained,

\[
 \iint_{a>Kb}(a-b)d\gamma(a)d\gamma(b)
 =\int_0^\infty F(t/K)[J-F(t)]dt
 +(K-1)\int_0^\infty t[J-F(Kt)]dF(t).                       \tag{8}
\]

It follows from `a−b=(a−Kb)+(K−1)b`. The first integral is Lebesgue in `t`, so its endpoint convention is immaterial. The SECOND tail must be `J−F(Kt)`, which excludes equality and is essential for strict-ratio atoms.

For `J>0`, define actual posterior `p=dγ/J` and its size bias `π=m dγ/V`. The mass-log energy is

\[
 E_{y,r}=\frac1J\iint_{a>b}(a-b)\log(a/b)d\gamma(a)d\gamma(b)
 =V[\mathrm{KL}(\pi\Vert p)+\mathrm{KL}(p\Vert\pi)].          \tag{9}
\]

It also equals the exact scale-occupation integral

\[
 \frac1J\int_0^\infty\!\int_0^\infty
 \frac{F(\min(s,t))[J-F(\max(s,t))]}{t}\,ds\,dt.
\]

For `K>1`, `G_K≤E_total/log K`, where `E_total` retains `f`, `ell`, and the original high gate. The available elementary estimate is only

\[
 E_{\rm total}\le
 \log\!\left(\frac{\lambda b^n}{q_-a^n}\right)
           \min\{X_q,A_nW_f\},\qquad X_q=\int_Eq.            \tag{10}
\]

Indeed `E_(y,r)≤log(m_max/m_min)G_1(y,r)`, and `G_1(y,r)≤V_y(r)`. The original matching identity gives `∫f∫ell V=X_q`, while the real hard band envelope gives `∫ell V_y≤A_n` pointwise. For one octave, the source side of (10) is order `n²`, not the needed order `n`. No better general entropy budget is proved, and (9) is not counted as a new paid portion. A useful improvement needs actual geometric control of the large-past threshold occupation in (7)/(8), beyond the mass range and marginal matching alone.

## 5. Reproducible real-dx check

The self-contained `/tmp/r337_aux_checks.py` actually ran twice and passed **2,448 exact assertions** using `Fraction` and rational logarithm enclosures. It uses source `f=1_[-4,4]`, true Lebesgue receiver shells

`E0=[−1/4,1/4]`, `E1=[−1/2,−1/4]∪[1/4,1/2]`, `E2=[−3/4,−1/2]∪[1/2,3/4]`,

with selected radii `1,3/2,2` and `q=λ=1`. All actual receiver cubes lie inside that source, so no sampled local-mean surrogate is used. Exact row loads are interval-intersection lengths divided by the corresponding radius. Checks cover (8), strict ratio atoms, the formal log coefficients in (9), closed mass bands, and (5)–(6) at finitely many source positions. These row checks are diagnostics, not a substituted whole-source integral.

There is also an exact positive-measure verification: for ALL `y∈[−1/4,1/4]`, every receiver is captured, with mass-CDF atom loads `(1/2,1/3,1/4)`. At `H=1`, only the original terminal outer clock is high. For `K=3/2>λ/q_-` and `h=1/2`, the paid subbranch is nonzero and equals `3/52` per source row, hence contributes exactly `3/104` from this source interval. This demonstrates that (6) includes original HIGH-`J` traffic rather than merely relabeling the low-`J` slot. No complete-source value of `G_K` or extremal/root evidence is inferred from that slab.

Run `python3 /tmp/r337_aux_checks.py`. Only `/tmp/r337_aux.md` and its necessary check script are authored; no other research file or Git state is changed. The paid delivery is (6); (7) is the precise remaining component.
