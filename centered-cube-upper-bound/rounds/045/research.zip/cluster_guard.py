#!/usr/bin/env python3
"""Round 45: atomic cluster macro/micro decomposition guards.
Standard library only. Higher-dimensional checks are finite-threshold interval
guards; dimension one uses exact all-threshold endpoint crossings. Rational
root intervals and exact rectangle volumes use Fraction.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations, product
import json
import time
from pathlib import Path


def fs(q):
    return str(q)


def merge(points, weights):
    d = {}
    for p, w in zip(points, weights):
        p = tuple(map(F, p)); w = F(w)
        assert w > 0
        d[p] = d.get(p, F(0)) + w
    mass = sum(d.values(), F(0))
    return tuple(sorted(d)), tuple(d[p] / mass for p in sorted(d)), mass


def families(points, weights):
    n = len(points[0]); N = len(points); ans = []
    for mask in range(1, 1 << N):
        ids = [j for j in range(N) if mask >> j & 1]
        lo = tuple(min(points[j][i] for j in ids) for i in range(n))
        hi = tuple(max(points[j][i] for j in ids) for i in range(n))
        mass = sum((weights[j] for j in ids), F(0))
        close = sum(1 << j for j, p in enumerate(points)
                    if all(lo[i] <= p[i] <= hi[i] for i in range(n)))
        ans.append((mask, mass, lo, hi, close))
    return tuple(ans), tuple(a for a in ans if a[0] == a[4])


@lru_cache(None)
def root_interval(q, n, bits):
    """Monotone dyadic brackets: roots <=1 use [0,1]; larger roots use
    [2^k,2^(k+1)]. Within a bin the fixed-bit dyadic grid is shared;
    adjacent bins share an endpoint. Thus both enclosure endpoints are
    nondecreasing in q. Exact roots at dyadic grid points are collapsed.
    """
    assert q > 0
    if n == 1:
        return q, q
    hi = F(1)
    while hi ** n < q:
        hi *= 2
    if hi ** n == q:
        return hi, hi
    lo = F(0) if hi == 1 else hi / 2
    for _ in range(bits):
        mid = (lo + hi) / 2
        v = mid ** n
        if v == q:
            return mid, mid
        if v < q:
            lo = mid
        else:
            hi = mid
    assert lo ** n <= q <= hi ** n
    return lo, hi


def prune(boxes):
    boxes = sorted(set(b for b in boxes if all(l < h for l, h in b)))
    return tuple(b for k, b in enumerate(boxes)
                 if not any(k != j and all(c[i][0] <= b[i][0] and b[i][1] <= c[i][1]
                                            for i in range(len(b)))
                            for j, c in enumerate(boxes)))


@lru_cache(maxsize=100000)
def union_volume(boxes):
    boxes = prune(boxes)
    if not boxes:
        return F(0)
    cuts = sorted(set(z for b in boxes for z in b[0]))
    total = F(0)
    for l, h in zip(cuts, cuts[1:]):
        mid = (l + h) / 2
        active = tuple(b for b in boxes if b[0][0] < mid < b[0][1])
        if active:
            section = F(1) if len(boxes[0]) == 1 else union_volume(tuple(b[1:] for b in active))
            total += (h - l) * section
    return total


def inclusion_exclusion(boxes):
    boxes = prune(boxes); total = F(0)
    for k in range(1, len(boxes) + 1):
        for group in combinations(boxes, k):
            v = F(1)
            for i in range(len(boxes[0])):
                width = min(b[i][1] for b in group) - max(b[i][0] for b in group)
                v *= max(F(0), width)
            total += v if k % 2 else -v
    return total


def envelope(fam, lam, n, bits):
    inner = []; outer = []
    for _, mass, lo, hi, _ in fam:
        rl, ru = root_interval(mass / lam, n, bits)
        inner.append(tuple((hi[i] - rl / 2, lo[i] + rl / 2) for i in range(n)))
        outer.append(tuple((hi[i] - ru / 2, lo[i] + ru / 2) for i in range(n)))
    inner = prune(inner); outer = prune(outer)
    vl, vu = union_volume(inner), union_volume(outer)
    assert vl <= vu
    return vl, vu, inner, outer



def weighted_merge(points, weights):
    d = {}
    for point, weight in zip(points, weights):
        p, w = tuple(map(F, point)), F(weight)
        assert w > 0
        d[p] = d.get(p, F(0)) + w
    return tuple(sorted(d)), tuple(d[p] for p in sorted(d))


def containing(a, b):
    """a contains b, even if a or b has not been pruned."""
    return all(a[i][0] <= b[i][0] and b[i][1] <= a[i][1] for i in range(len(a)))


def raw_boxes(fam, lam, n, bits, offset=F(0)):
    lower, upper = {}, {}
    for mask, mass, lo, hi, _ in fam:
        rl, ru = root_interval(mass / lam, n, bits)
        lower[mask] = tuple((hi[i] - rl/2 - offset, lo[i] + rl/2 + offset) for i in range(n))
        upper[mask] = tuple((hi[i] - ru/2 - offset, lo[i] + ru/2 + offset) for i in range(n))
    return lower, upper


def value(fam, lam, n=1, bits=24):
    lo, hi, _, _ = envelope(fam, lam, n, bits)
    return lam*lo, lam*hi


def crossings_1d(fam):
    lines = []
    for _, mass, lo, hi, _ in fam:
        lines += [(hi[0], -mass/2), (lo[0], mass/2)]
    ts = set()
    for (a,b),(c,d) in combinations(lines,2):
        if b != d:
            t = (c-a)/(b-d)
            if t > 0: ts.add(t)
    return tuple(sorted(ts))


def exact_k1(fam):
    total = max(x[1] for x in fam)
    vals = [(total, None)]
    for t in crossings_1d(fam):
        L,U = value(fam,1/t)
        assert L == U
        vals.append((L,1/t))
    return max(x[0] for x in vals), tuple(lam for v,lam in vals if v == max(x[0] for x in vals)), len(vals)-1


def exact_h1(weighted_profiles, floor=F(0)):
    thresholds = set()
    for fam in weighted_profiles:
        thresholds.update(1/t for t in crossings_1d(fam))
    if floor > 0: thresholds.add(floor)
    candidates = [(F(1),None)]  # high-threshold limit for atomic probabilities
    for tau in sorted(thresholds):
        if tau < floor: continue
        values = [value(fam,tau) for fam in weighted_profiles]
        assert all(a==b for a,b in values)
        candidates.append((sum(a for a,b in values),tau))
    best = max(v for v,tau in candidates)
    return best, tuple(tau for v,tau in candidates if v == best), len(candidates)-1


def instance(n,k,eps,variant):
    # Coordinates are strongly correlated; all sources and all profile weights positive.
    centers = [tuple(F(8*j*(i+1)) for i in range(n)) for j in range(k)]
    rawp = [1,3] if k == 2 else [1,2,5]
    if variant == 1: rawp = [3,2] if k == 2 else [5,1,2]
    p = [F(w,sum(rawp)) for w in rawp]
    profiles = []
    for j in range(k):
        if variant == 0:
            pts = [tuple(F(0) for i in range(n)),tuple(F(1) for i in range(n))]
            ws = [F(1,2),F(1,2)]
        else:
            pts = [tuple(F(-1) if (i+j)%2 else F(1) for i in range(n)),
                   tuple(F(1) if (i+j)%2 else F(-1) for i in range(n))]
            ws = [F(j+1,j+3),F(2,j+3)]
        profiles.append((tuple(pts),tuple(ws)))
    return centers,p,profiles,F(eps),F(1)


def build(centers,p,profiles,eps,R):
    n=len(centers[0]); pts=[]; weights=[]; labels=[]; members=[]
    for j,(local,ws) in enumerate(profiles):
        ids=[]
        for y,w in zip(local,ws):
            assert max(abs(x) for x in y)<=R
            ids.append(len(pts)); labels.append(j)
            pts.append(tuple(centers[j][i]+eps*y[i] for i in range(n)))
            weights.append(p[j]*w)
        members.append(tuple(ids))
    assert sum(weights)==1 and len(set(pts))==len(pts)
    d=min(max(abs(a[i]-b[i]) for i in range(n)) for a,b in combinations(centers,2))
    h=eps*R; assert 2*h<d
    Lambda=(d-2*h)**(-n)
    Eh=(2**len(centers)-1)*((d/(d-2*h))**n-1)
    coarse=families(centers,p)[0]; actual=families(pts,weights)[0]
    weighted=[families(local,tuple(p[j]*w for w in ws))[0] for j,(local,ws) in enumerate(profiles)]
    return dict(n=n,k=len(centers),points=pts,weights=weights,labels=labels,members=members,
                d=d,h=h,Lambda=Lambda,Eh=Eh,coarse=coarse,actual=actual,weighted=weighted,
                centers=centers,profiles=profiles,p=p,eps=eps,R=R)


def macro_guard(s,lam,bits):
    assert lam <= s['Lambda']
    n,h=s['n'],s['h']
    Delta=s['d']-2*h
    plower=root_interval(min(s['p']),n,bits)[0]
    minimum_radius=min(Delta*plower,root_interval(min(s['p'])*Delta**n,n,bits)[0])
    assert minimum_radius>0
    A=1+2*h/minimum_radius
    inner,_=raw_boxes(s['coarse'],lam,n,bits,-h)
    _,outer=raw_boxes(s['coarse'],lam,n,bits,h)
    actualL,actualU=raw_boxes(s['actual'],lam,n,bits)
    def scaled_boxes(fam):
        lower,upper={},{}
        for mask,mass,lo,hi,_ in fam:
            rl,ru=root_interval(mass/lam,n,bits)
            lower[mask]=tuple((hi[i]-A*rl/2,lo[i]+A*rl/2) for i in range(n))
            upper[mask]=tuple((hi[i]-A*ru/2,lo[i]+A*ru/2) for i in range(n))
        return lower,upper
    coarseL,coarseU=raw_boxes(s['coarse'],lam,n,bits)
    scaledActualL,_=scaled_boxes(s['actual'])
    _,scaledCoarseU=scaled_boxes(s['coarse'])
    # All-cluster mass matches exactly: use identical root intervals.
    for mask,box in inner.items():
        fullmask=sum(1<<j for i,ids in enumerate(s['members']) if mask>>i&1 for j in ids)
        assert containing(actualL[fullmask],box)
        assert containing(scaledActualL[fullmask],coarseL[mask])
    for mask,box in actualU.items():
        cluster_mask=sum(1<<i for i in set(s['labels'][j] for j in range(len(s['points'])) if mask>>j&1))
        assert containing(outer[cluster_mask],box)
        assert containing(scaledCoarseU[cluster_mask],box)
    iv=union_volume(tuple(inner.values())); ov=union_volume(tuple(outer.values()))
    tl,tu,_,_=envelope(s['actual'],lam,n,bits)
    cl,cu,_,_=envelope(s['coarse'],lam,n,bits)
    assert iv<=tl<=tu<=ov
    # This verifies a stronger interval version of both one-sided errors at
    # this threshold. Root uncertainty is included, not subtracted by fiat.
    upgap=lam*(ov-cl); downgap=lam*(cu-iv)
    assert max(upgap,downgap)<=s['Eh']
    return dict(stage='macro_sandwich',n=n,k=s['k'],epsilon=fs(s['eps']),lambda_value=fs(lam),
                root_bits=bits,inner_volume=fs(iv),true_lower=fs(tl),true_upper=fs(tu),outer_volume=fs(ov),
                coarse_lower=fs(cl),coarse_upper=fs(cu),error_budget=fs(s['Eh']),
                multiplicative_A_upper=fs(A),scaled_threshold=fs(lam/A**n),
                multiplicative_guard='both correlated-root box containments PASS',
                certified_upper_gap=fs(upgap),certified_lower_gap=fs(downgap),status='PASS')


def high_guard(s,lam,bits):
    assert lam>=s['Lambda']; n=s['n']; eps=s['eps']
    mixed=0; connected=[]
    for mask,mass,lo,hi,close in s['actual']:
        ids=set(s['labels'][j] for j in range(len(s['points'])) if mask>>j&1)
        if len(ids)>1:
            assert mass<=lam*max(hi[i]-lo[i] for i in range(n))**n
            mixed+=1
        else: connected.append((mask,mass,lo,hi,close))
    # Independent evaluation of both sides: intervals must overlap.
    leftL,leftU,_,_=envelope(s['actual'],lam,n,bits)
    tau=lam*eps**n
    rightL=F(0);rightU=F(0)
    for fam in s['weighted']:
        a,b,_,_=envelope(fam,tau,n,bits)
        rightL+=eps**n*a;rightU+=eps**n*b
    assert leftL<=rightU and rightL<=leftU
    # Correlate root brackets through actual radii/epsilon. Translation and
    # dilation then give an exact rational union-volume identity, separately
    # for both lower and upper enclosures. No floating equality is used.
    rawL,rawU=raw_boxes(connected,lam,n,bits)
    clusterL=[];clusterU=[];microL=[];microU=[]
    for i,center in enumerate(s['centers']):
        masks=[mask for mask,*_ in connected if all(s['labels'][j]==i for j in range(len(s['points'])) if mask>>j&1)]
        bl=tuple(rawL[m] for m in masks);bu=tuple(rawU[m] for m in masks)
        clusterL.extend(bl);clusterU.extend(bu)
        def unscale(box):return tuple(((a-center[j])/eps,(b-center[j])/eps) for j,(a,b) in enumerate(box))
        ml=union_volume(tuple(unscale(b) for b in bl));mu=union_volume(tuple(unscale(b) for b in bu))
        assert union_volume(bl)==eps**n*ml and union_volume(bu)==eps**n*mu
        microL.append(ml);microU.append(mu)
    # Rational root-upper envelopes may cross a touching cluster boundary by
    # their tiny uncertainty. Exact geometry gives disjointness; use the
    # individual sum for upper bounds and exact lower envelopes for equality.
    assert union_volume(tuple(clusterL))==eps**n*sum(microL)
    correlated_upper=eps**n*sum(microU)
    assert union_volume(tuple(clusterU))<=correlated_upper
    return dict(stage='high_threshold_identity',n=n,k=s['k'],epsilon=fs(eps),lambda_value=fs(lam),
                tau=fs(tau),root_bits=bits,mixed_subsets_certified_empty=mixed,
                left_interval=[fs(lam*leftL),fs(lam*leftU)],
                independent_micro_interval=[fs(lam*rightL),fs(lam*rightU)],
                correlated_lower_exact=fs(lam*eps**n*sum(microL)),
                correlated_upper_bound=fs(lam*correlated_upper),status='PASS')


def main():
    start=time.monotonic(); rows=[]
    specs=[(n,k,eps,v) for n,k in ((1,2),(2,2),(3,2),(4,2),(1,3),(2,3))
           for eps in (F(1,8),F(1,32)) for v in (0,1)]
    for n,k,eps,v in specs:
        s=build(*instance(n,k,eps,v))
        for factor,bits in ((F(1,8),16),(F(1,2),24),(F(1),24)):
            row=macro_guard(s,factor*s['Lambda'],bits);row['profile_variant']=v;rows.append(row)
        for factor,bits in ((F(1),24),(F(2),16),(F(8),24)):
            row=high_guard(s,factor*s['Lambda'],bits);row['profile_variant']=v;rows.append(row)
    # Empty coarse boxes must be expanded before emptiness is tested.
    fam=families([(F(0),),(F(1),)],[F(1,2),F(1,2)])[0]
    _,outside=raw_boxes(fam,F(1),1,8,F(1,8))
    full=outside[3]
    assert full[0][0]<full[0][1] and full[0][1]-full[0][0]==F(1,4)
    rows.append(dict(stage='empty_box_expansion',original_full_box_width='0',expanded_full_box_width='1/4',
                     note='Unpruned coarse full-subset box expands before pruning',status='PASS'))
    _,negative_outside=raw_boxes(fam,F(4,3),1,8,F(1,4))
    assert negative_outside[3][0][1]-negative_outside[3][0][0]==F(1,4)
    rows.append(dict(stage='empty_box_expansion',original_full_box_width='-1/4',expanded_full_box_width='1/4',
                     note='Negative-width endpoint pair is expanded before pruning',status='PASS'))
    # Exact all-threshold 1D: endpoint crossings, with no interior critical point.
    for k,v in ((2,0),(2,1),(3,0),(3,1)):
        for eps in (F(1,8),F(1,16),F(1,64)):
            s=build(*instance(1,k,eps,v))
            K0,where0,c0=exact_k1(s['coarse']);Ke,wheree,ce=exact_k1(s['actual'])
            H,whereh,ch=exact_h1(s['weighted']);Hdelta,whered,cd=exact_h1(s['weighted'],eps*s['Lambda'])
            low=max(K0-s['Eh'],Hdelta);up=max(K0+s['Eh'],Hdelta)
            assert low<=Ke<=up and Hdelta<=H
            A=1+2*s['h']/((s['d']-2*s['h'])*min(s['p']))
            multlow=max(K0/A,Hdelta);multup=max(A*K0,Hdelta)
            assert multlow<=Ke<=multup
            # The difference of the two exact weak ratios is piecewise affine
            # in lambda; use every relevant crossing and both boundary limits.
            macro_thresholds={s['Lambda']}
            for fam in (s['coarse'],s['actual']):
                macro_thresholds.update(1/t for t in crossings_1d(fam) if 1/t<=s['Lambda'])
            worst=F(0)
            for ml in macro_thresholds:
                al,au=value(s['actual'],ml);cl,cu=value(s['coarse'],ml)
                assert al==au and cl==cu
                worst=max(worst,abs(al-cl))
            assert worst<=s['Eh']
            rows.append(dict(stage='exact_1d_all_macro_thresholds',k=k,profile_variant=v,epsilon=fs(eps),
                             scope='every 0<lambda<=Lambda; piecewise-affine differences and zero-threshold limit',
                             maximum_absolute_error=fs(worst),error_budget=fs(s['Eh']),
                             examined_thresholds=len(macro_thresholds),status='PASS'))
            # Separate individual profiles optimize separately: this is only an upper bound for H.
            separate=sum(s['p'][i]*exact_k1(families(*s['profiles'][i])[0])[0] for i in range(k))
            assert H<=separate
            rows.append(dict(stage='exact_1d_global',k=k,profile_variant=v,epsilon=fs(eps),
                             coarse_K=fs(K0),true_K=fs(Ke),common_micro_H=fs(H),restricted_micro_H=fs(Hdelta),
                             separately_optimized_micro_upper=fs(separate),cluster_bracket=[fs(low),fs(up)],
                             error_budget=fs(s['Eh']),multiplicative_A=fs(A),
                             multiplicative_bracket=[fs(multlow),fs(multup)],coarse_crossings=c0,true_crossings=ce,micro_crossings=ch,
                             restricted_micro_crossings=cd,status='PASS'))
    for eps in (F(1,16),F(1,32),F(1,64),F(1,256)):
        s=build(*instance(1,2,eps,0))
        K0,_,_=exact_k1(s['coarse']);Ke,we,_=exact_k1(s['actual']);H,wh,_=exact_h1(s['weighted'])
        Hd,_,_=exact_h1(s['weighted'],eps*s['Lambda'])
        assert K0==F(9,8) and H==Hd==Ke==F(19,16)
        assert F(9,16) in wh and F(9,16)/eps in we
        assert s['Eh']<F(1,16) and eps*s['Lambda']<=F(9,16)
        assert max(K0+s['Eh'],Hd)==Ke
        rows.append(dict(stage='exact_oracle',epsilon=fs(eps),coarse_K=fs(K0),common_H=fs(H),true_K=fs(Ke),
                         separate_micro_K='5/4',micro_peak_tau='9/16',error_budget=fs(s['Eh']),
                         micro_threshold_floor=fs(eps*s['Lambda']),status='PASS'))
    counts={}
    for row in rows:counts[row['stage']]=counts.get(row['stage'],0)+1
    result=dict(round=45,status='PASS',total_cases=len(rows),counts=counts,
                arithmetic='standard-library Fraction; rational root enclosures and exact rectangular union volumes',
                dimensions=[1,2,3,4],cluster_counts=[2,3],actual_atom_counts=[4,6],
                epsilon_values=sorted(set(fs(r['epsilon']) for r in rows if 'epsilon' in r)),root_bits=[16,24],
                limitations=['Checks finite atomic positive profiles and the general decomposition; not a special-family upper-bound theorem.',
                             'Dimensions above one use certified root intervals; independent intervals overlap and correlated lower volumes scale exactly.',
                             'Exact all-threshold K/H optimization and all-macro-threshold error certification are implemented only in dimension one.',
                             'Empty subset boxes are expanded before pruning.',
                             'A common threshold is used in H; it is not the sum of separately optimized profile constants.'],cases=rows)
    Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(dict(status=result['status'],total_cases=len(rows),counts=counts,runtime_seconds=time.monotonic()-start)))


if __name__=='__main__':main()
