"""One exact source-column rejection of the uniform-field Poisson candidate.
This is not a search and not an optimum certificate.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json
ROOT=Path(__file__).resolve().parent
raw=json.loads((ROOT/'r436_cutlp_pressure_matlab.json').read_text())[1]
cent=[tuple(map(int,x)) for x in raw['centers']];high=raw['high_group']
base=59;offset=29;v=F(49,500)**2
index=lambda x:(x[0]+offset)+base*(x[1]+offset)
lo=list(map(int,raw['klo']));hi=list(map(int,raw['khi']))
tau=[F(a*361,a*361+b*121) if a+b else F(0) for a,b in zip(lo,hi)]
probe=(8,7);j=index(probe);price=F(0);count=0
for row,H in zip(cent,high):
 rad=9 if H else 5
 if max(abs(row[d]-probe[d]) for d in range(2))>rad:continue
 mi=F(19 if H else 11,10)**2
 total=sum((tau[index((row[0]+a,row[1]+b))]
            for a,b in product(range(-rad,rad+1),repeat=2)),F(0))
 Pl=total/(100*mi)
 lam=v*(F(not H)-Pl)/mi
 price+=lam;count+=1
cc=F(49**2*lo[j]*hi[j],lo[j]*950**2+hi[j]*550**2)
res=cc-price;zero=F(21609,88750)
assert res>F(29,100)>F(25,100)>zero
scale=10**12;floor=res.numerator*scale//res.denominator
certificate={'probe':list(probe),'capturing_parent_count':count,
 'exact_residual_interval':[str(F(floor,scale)),str(F(floor+1,scale))],
 'exact_zero_multiplier_beta':str(zero),
 'exact_residual_exceeds_zero':True,
 'scope':'Uniform field only; one source column proves this unscaled Poisson candidate is worse than zero dual in this finite model.'}
(ROOT/'r437_numeric_poisson_check.json').write_text(json.dumps(certificate,indent=2)+'\n')
print('uniform Poisson probe',probe,'residual in',certificate['exact_residual_interval'],
      'zero beta=',float(zero),'PASS exact one-column rejection')
