from fractions import Fraction as F
from decimal import Decimal as D, localcontext
import json
n=16
eta=F(1,1000); v=eta**n
a=[F(1),F(3,2),F(2)]
m=[x**n for x in a]
w=[m[0],m[1]-m[0],m[2]-m[1]]
x=[F(0),F(5,8),F(7,8)]
# Positive center blocks: side eta, centers ((0),(i+1)/100,0,...).
# Positive source blocks: side eta, centers (x[k],0,...), mass w[k].
for i,R in enumerate(a):
 for k in range(3):
  inside=abs(x[k])+eta<R/2 and F(i+1,100)+eta<R/2
  outside=abs(x[k])-eta>R/2
  assert inside if k<=i else outside
J=[sum((v/m[l] for l in range(k,3)),F(0)) for k in range(3)]
rows=[]; edges={}
for i in range(3):
 for j in range(i):
  assert m[i]/m[j]>64  # also > actual K=e^4.
  edge=v*v/(m[i]*m[j])*sum((w[k]/J[k] for k in range(j+1)),F(0))
  edges[i,j]=edge
  Om=[edge*w[k]/m[i] if k<=i else F(0) for k in range(3)]
  De=[edge*w[k]/m[i] if k<=j else F(0) for k in range(3)]
  Re=[edge*w[k]*m[j]/(m[i]*(m[i]-m[j])) if j<k<=i else F(0) for k in range(3)]
  Tr=[edge*w[k]/(m[i]-m[j]) if j<k<=i else F(0) for k in range(3)]
  assert sum(Om)==sum(Tr)==edge
  assert sum(De)==sum(Re)==edge*m[j]/m[i]
  assert all(Tr[k]==Om[k]-De[k]+Re[k] for k in range(3))
  rows.append({'i':i,'j':j,'edge_over_v':str(edge/v),'alpha':str(m[j]/m[i]),
     'exact_export_conservation':True,'exact_deleted_equals_renormalized':True})
# Fixed threshold t=16, exp(d)=8: low<2, high>128.
t=F(16)
export=[F(0)]*3
for (i,j),edge in edges.items():
 if m[j]<t/8 and m[i]>8*t:
  for k in range(j+1,i+1):export[k]+=edge*w[k]/(m[i]-m[j])
for k in range(3):
 H=sum((v/m[i] for i in range(k,3) if m[i]>8*t),F(0))
 assert export[k]/w[k]<=F(64,63)*H
with localcontext() as c:
 c.prec=70
 def dec(x):return D(x.numerator)/D(x.denominator)
 far=D(0); correction=D(0)
 for (i,j),edge in edges.items():
  width=dec(m[i]/m[j]/64).ln()
  far+=dec(edge/v)*width
  correction+=dec(edge/v*m[j]/m[i])*width
 # alpha(log ratio-log64) <= 1/(64e) <3/512;
 # oriented edge mass <= |E|/2 =3v/2.
 assert correction < D(9)/D(1024)
 numeric={'integrated_far_flux_over_v':str(far),'integrated_deleted_correction_over_v':str(correction),
          'integrated_renormalized_correction_over_v':str(correction),'rational_upper_correction_over_v':'9/1024'}
print(json.dumps({'n':n,'q':1,'side_ratio':2,'center_block_volume':str(v),'W':str(m[-1]),
 'rows':rows,'numeric':numeric,
 'scope':'Exact Fraction continuous-cube incidence, reversible edge masses, export columns and cancellation; 70-digit Decimal only for log-weighted totals. Does not certify original high-rank/history gates or the unpaid whole occupation budget.'},indent=2))
