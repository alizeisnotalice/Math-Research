% One fixed native-model spatial restricted-dual experiment; no generic claim.
outdir=fileparts(mfilename('fullpath'));
old=jsondecode(fileread(fullfile(outdir,'r436_cutlp_pressure_matlab.json')));a=old(2);
n=a.n;c=a.c;Ic=a.centers;Js=a.sources;high=a.high_group;
M=size(Ic,1);N=size(Js,1);v=.098^n;rn=(1.1+.8*high).^n;
dist=zeros(M,N);
for d=1:n;dist=max(dist,abs(Ic(:,d)-Js(:,d)'));end
C=sparse((~high & dist<=5)|(high & dist<=9));clear dist
idx=1+sum((Ic+c+9).*((2*c+19).^(0:n-1)),2);
lo=full(sum(C(~high,idx),1))'/11^n;hi=full(sum(C(high,idx),1))'/19^n;
bdist=(c-max(abs(Ic),[],2))/c;
features=[ones(M,1),high,bdist,high.*bdist,lo,hi,high.*lo,high.*hi];
B=v*features;
hlo=(.098/1.1)^n*a.klo;hhi=(.098/1.9)^n*a.khi;
coeff=zeros(N,1);good=hlo+hhi>0;coeff(good)=hlo(good).*hhi(good)./(hlo(good)+hhi(good));
Aineq=[-C'*B,-ones(N,1);rn'*B,0];bineq=[-coeff;0];
opts=optimoptions('linprog','Display','none','Algorithm','dual-simplex-highs');
tic;[x,fval,flag,output]=linprog([zeros(8,1);1],Aineq,bineq,[],[],-Inf(9,1),[],opts);elapsed=toc;
assert(flag==1);
cor=zeros(8,1);h=a.dual_eqlin(1:M)/v;
for j=1:8
 if std(features(:,j))==0;cor(j)=0;else;cc=corrcoef(h,features(:,j));cor(j)=cc(1,2);end
end
result=struct('n',n,'c',c,'pattern',a.pattern,'alpha',x(1:8),'beta',x(9),...
'original_float_optimum',a.objective,'pearson_existing_h_vs_features',cor,...
'feature_names',{{'one','high','boundary_distance_over_c','high_boundary','localLo','localHi','high_localLo','high_localHi'}},...
'residual_max',max(Aineq*x-bineq),'elapsed_seconds',elapsed,'flag',flag);
fid=fopen(fullfile(outdir,'r437_numeric_fit_matlab.json'),'w');fwrite(fid,jsonencode(result),'char');fclose(fid);
disp(result);
% One explicit Poisson candidate diagnostic, no additional optimization.
poisson=cell(2,1);tau=hlo./(hlo+hhi);tau(~isfinite(tau))=0;
for zz=1:2
 if zz==1;mu=a.weights/a.t;tag='original_float_optimal_weights';
 else;mu=ones(N,1)/10^n;tag='exact_uniform_density';end
 Pl=(C*(mu.*tau))./rn;lam=v*((~high)-Pl)./rn;
 [beta0,jj]=max(coeff-C'*lam);
 poisson{zz}=struct('tag',tag,'beta_float',beta0,'zero_beta_float',max(coeff),...
 'mass_pairing_float',sum(lam.*rn),'actual_mass_residual_inf',norm(C*mu-rn,inf),...
 'lambda',lam,'max_source_matlab_index',jj,'max_source_coordinates',Js(jj,:));
end
fid=fopen(fullfile(outdir,'r437_numeric_poisson_matlab.json'),'w');fwrite(fid,jsonencode(poisson),'char');fclose(fid);
