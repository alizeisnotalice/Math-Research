from fractions import Fraction as F
f=[F(2),F(5),F(3)]; cap=[[1,1,0],[1,0,0],[0,1,1]]
m=[sum(f[j]*cap[i][j] for j in range(3)) for i in range(3)]
q=[F(1),F(2),F(3,2)];checks=0
for vb in [F(1,6),F(1,3),F(1,2),F(1)]:
 v=[F(1),vb,F(1,2)];sigma=[q[i]*v[i] for i in range(3)]
 J=[sum(v[i]*cap[i][j]/m[i] for i in range(3)) for j in range(3)]
 chi=[sum(sigma[i]*cap[i][j]/m[i] for i in range(3)) for j in range(3)]
 assert sum(f[j]*chi[j] for j in range(3))==sum(sigma)
 h=[-F(1),F(1,2),F(1,4)]
 sourcepair=sum(f[j]*sum(v[i]*h[i]*cap[i][j] for i in range(3)) for j in range(3))
 assert sourcepair==sum(v[i]*h[i]*m[i] for i in range(3))
 # A0,y0,z1 is the only retained atom. K=3,t=3: only parent1 lies in the accepted past.
 p=F(7,11);Z=vb/m[1];C=F(0)
 pi_y=f[0]/m[0];pi_z=f[1]/m[0]
 R=sigma[0]*pi_y*pi_z*p
 g_source=sigma[0]/m[0]*pi_z*p/(Z-C)*(vb/m[1])
 assert f[0]*g_source==R
 assert (Z-C)/J[0]>=F(1,4)
 checks+=1
print(f'PASS: {checks} Fraction matching/X-price/signed-pairing/direct-accepted-cut models')
print('Scope: finite matched-incidence algebra only; no native cube/history admissibility or global dual certificate proved.')
