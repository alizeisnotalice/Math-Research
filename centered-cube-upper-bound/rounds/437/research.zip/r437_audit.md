FINAL PASS（仅限下列解析恒等式、弱对偶条件与有限证书；不认证原整体预算）。

已先独立预审，再阅读全文及32项冻结输入。必要措辞修订已完成：main和complement明确O(nW/q_-)出口误差仅为未加权L1/TV，或|测试函数|≤1；乘未控occupation/势函数后不能继承此价。原R433及完整母账保持不变，无新付款、退款或收缩。扩大参数范围的三阶段泛化复核未完成；没有非空原strict-K支的高维验证。

核验结论：

1. 有符号弱对偶的充分量词与符号正确：必须有∫|h|m_A dA<∞、∫hm_A dA≤0，并在真实完整μ上证明来源不等式。完整matching给绝对源配对等式，Fubini合法。整体-t证书可比逐t CUT更弱；未调用强对偶、达值或免费可测选择。bridge的直接原Qex保留Z−C与p≤S，严格loggap给Eacc≥√nR，ε√n q_A/m_A的中心价恰为ε√nX。上放到J核仍保Sr/[c_*θ_y]，不漏rank因子或重收stage。
2. 实际端点export满足T=Ω−D+R，∫D=∫R；删交叠不是净损失。令Δ=log(m_A/m_u)、α=I_Au/m_A≤e^−Δ，则阈值积分为∫Φ α(Δ−2d)_+≤e^(−2d−1)Φ{m_A>m_u}≤e^(−2d−1)|E|/2。完整匹配及J≤A_n/q_-给各修正项≤e^(−2d−1)A_nW/(2q_-)，两项合计的L1界为其两倍。原接受正权只减小该上界，q_A加权至多乘λ。此为有限误差界，未排除父后验重采样的leading Ω仍恰有原far总流，尚无平均预算。高质量尾式仅在非空far阈值范围内使用，空范围取0。
3. 两种零成本价格的费用与符号一致：log接受流divergence价格h=j/m有∫hm=0、∫|h|m≤2F_q；逐边负部与正部均为1−I_Au/m_A，反价在原exclusive源上为−B。其补偿价仍是原通量级，不能凭零配对付款。Poisson价格(l−Pl)/m对dA核有零matching成本，来源残差精确为J[Ra−a²−ae]，质量原子e项保留；统一残差界未证。
4. 固定n=2,c=20场的8维basis有严格可复现的有限对偶证书。h在整个父块上常值，λ_i=v h_i；不能把代表点卷积特征当作任意实际A处的统一连续公式。完整网格、条纹pattern、捕获计数及全部3481源列已重建。Fraction修复仅下移α0，保持basis；非正matching成本与逐列弱对偶严格成立。β≈0.202290815283低于零价≈0.243481690141，却高于继承不受basis限制的严格上界≈0.133379834509。这不证明一般几何证书、最优达值或维数阶。
5. Poisson单列核使用精确uniform来源质量1/100和完整matching，在源列(8,7)严格得到残差∈[0.297812546296,0.297812546297]，高于零对偶最大余项。它仅关闭这个固定幅值候选的改善声明，不否定其他幅值/价格，也不是原历史反例。原float最优来源的质量残差已明确只作诊断，未用作精确匹配证据。

实际复现：在独立目录 /var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r437_audit_repro_fsidt5nw，复制本轮32输入（含两个R436依赖），运行四核心check及numeric_certify、numeric_poisson_check共6脚本，均退出0；六份stdout逐字节一致，两个重新生成的JSON亦逐字节一致。额外核对冻结fit的8维系数/特征、候选状态及已认证三种上界的大小顺序。

证据分型：mainproof为6个完整L1来源与固定区间pair的Fraction积分；geometry为54个系数重排断言；bridge为4个有限matching-incidence模型；complement为n16正体积块场的有理incidence/质量守恒及Decimal70对数诊断。后者不把小数计算当区间证书，也未认证原高秩/阶段/history。数值证书只对应继承n2场全部匹配source列；其原strict-K支为空。隔离复跑不计新实验或新增几何样本。

未重新运行MATLAB优化；只读取冻结候选、源码与运行记录，实际执行的是Python精确证书重建。资源记录是已有运行事实，不是定理或本审查的MATLAB RSS测量。未修改作者脚本、其他角色文件或仓库，未安装软件/编译PDF。原接受flow的全输入几何对偶、INFO、远端CUT及一般弱型闭合均未证明；既有原子、终端、吸收与全尺度条件不删减。

最终字节绑定（32输入；审计自身不自绑定）：

- `r437_bridge.md`: `b98c5947cded9d347310909745452cd5e62e287741063f1bfd8840d5252fab10`
- `r437_bridge_check.py`: `23e7e27aab2e9410130959fecef3ce206fb9ba7128e18d8c1d84812ceedd48f0`
- `r437_bridge_check.stdout`: `a36b2464a57a467d945eb3af96cf0354833704ee98b2d00f04c76a3bbfe401c7`
- `r437_complement.md`: `6ffef33f19b0b8130cdf79787b5efebe2fb3c9a5394577c291021abe17c411f0`
- `r437_complement_check.py`: `4cfbec18f8e32096ed12816833a368090a1d2fdfa78905d5f9a17e4d56198278`
- `r437_complement_check.result.json`: `47a5f0c8ed3e27a961e29e46a1525630bb0cac57f08a9cc87ccf28f064765938`
- `r437_contract.md`: `021a30b4e2c2f960ebd54a17d91056456723343c1ce58f0dbb3d5779730d97f8`
- `r437_geometry.md`: `876993be089a45f7583b1cd1255b2715a51f91f8348d67a3e8e4cb33bc67edc8`
- `r437_geometry.result.txt`: `54388797d394b09b61c4699776786a699fbb8fd560a28a555d339985f4f27b46`
- `r437_geometry_check.py`: `e5693f36696a485bec9ffea6d6f49de313f8e35fdb3a6d0295264fcdb52722ce`
- `r437_main.md`: `56c3e3c3d099fadbce6f39dbcad6e811b349f3f6b914f8922e43265f78047a07`
- `r437_mainproof.md`: `077aceb36def20303617736f3b66d9b8a7da92458d760853b194f943cf2de30a`
- `r437_mainproof.result.txt`: `cd47372d124eab287fcea30acbbd9223af5bce415afdd4cbfa6d7b5fdd51c93d`
- `r437_mainproof_check.py`: `1d852934f155239cd3cff38429c05b5689196349bc0e12d7bf4b8bb5fded2e74`
- `r437_numeric.md`: `eb6a53d0ee5834a55d3022dca393e25261c579154cc628e81f3bdff0c69ec96c`
- `r437_numeric_certificate.json`: `058750ab2f97c947c4c645f7a9e05d344aaa1a678a767d0f060db982f7313d8d`
- `r437_numeric_certify.py`: `6a8c3634353d9da1018c2f624ff1e9544fe994de6246215c0e56319be290a599`
- `r437_numeric_fit.m`: `9bbed0055eac040b6f17fef3a29577643358b2b6b7411e98c829de1b77df6124`
- `r437_numeric_fit_matlab.json`: `c441e54a6025fb259ae0c8c6fe5c4a1804f79b16979d57a029087aab4ad44e17`
- `r437_numeric_poisson_check.json`: `0ca2451c48ef3e6478927b1872e50f99eccae6eef0e69cab6b3382eb132235bb`
- `r437_numeric_poisson_check.py`: `b53f4dd6a1542b0b493ab4def5c479ee64e68f3fd59a0fabc175dca841c561e3`
- `r437_numeric_poisson_check.txt`: `db2c09e98cba85c8e413d546e30b8c0e8ac26074f21e2d346c9b86280993f2f9`
- `r437_numeric_poisson_matlab.json`: `4f5ce56d68b12bb5c1ab55eaa3cba9bbf727eb5b2b26fa37667636f592d28ba2`
- `r437_numeric_poisson_resources.txt`: `356e15b53713bb32d3eed72c0da319312e5c778f3ffb64563bbb08e544d405f4`
- `r437_numeric_resources.txt`: `30b0d147dc057744348798a4170032a826b3db8c2293dd4b319850ffaeda98d2`
- `r437_numeric_run.txt`: `b6dc9d6a9a3f2bd12d359a729e79e3e21a0dcad17d6a8827312fdf9fef16d8f3`
- `r437_prescreen.md`: `add13592a284d7aace52e29e54eea4d6aa5d868500da490b1d210a07bb66ea3e`
- `r436_cutlp_pressure_matlab.json`: `ddee4bad6d212a2ba5f79f015dc4e20c5ff32f07ba07693bf1b92b82d02f1759`
- `r436_cutlp_pressure_certificate.json`: `7ba0564bcf510ce03416c781f9fe1662b2db5ccaf09216e1c523992e871b1447`
- `r436_contract.md`: `2db5be8f60c96065f8949d122c08298ad26632f627b63a3a9aef6f6c0c86041f`
- `r435_contract.md`: `02906c27e31bd24a95264197f0dc18946434b790dd70868e3670354fbb3203f3`
- `r436_main.md`: `5ee5347dcb1a4a7fe6edfbd77756a7d2bb9ac3a23d985d7c595124ec51a4551b`
