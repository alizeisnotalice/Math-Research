"""Certify one eight-feature spatial dual, preserving the prescribed basis."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import lcm
import json
ROOT=Path(__file__).resolve().parent
raw=json.loads((ROOT/'r436_cutlp_pressure_matlab.json').read_text())[1]
fit=json.loads((ROOT/'r437_numeric_fit_matlab.json').read_text())
old=json.loads((ROOT/'r436_cutlp_pressure_certificate.json').read_text())[1]
n,c=raw['n'],raw['c'];assert n==2 and c==20
cent=[tuple(x) for x in raw['centers']];src=[tuple(x) for x in raw['sources']]
assert all(all(a==int(a) for a in row) for row in cent+src)
cent=[tuple(map(int,x)) for x in cent];src=[tuple(map(int,x)) for x in src]
assert set(cent)==set(product(range(-c,c+1),repeat=n))
assert set(src)==set(product(range(-c-9,c+10),repeat=n))
high=[bool(x) for x in raw['high_group']];assert high==[(x[0]//3)%2!=0 for x in cent]
M=len(cent);N=len(src);base=2*c+19;v=F(49,500)**n
index=lambda row:sum((row[d]+c+9)*base**d for d in range(n))
assert all(index(row)==j for j,row in enumerate(src))
lo=[0]*N;hi=[0]*N
for i,row in enumerate(cent):
 rad=9 if high[i] else 5
 for dd in product(range(-rad,rad+1),repeat=n):
  j=index(tuple(row[d]+dd[d] for d in range(n)))
  (hi if high[i] else lo)[j]+=1
assert lo==list(map(int,raw['klo'])) and hi==list(map(int,raw['khi']))
features=[]
for row,H in zip(cent,high):
 j=index(row);d=F(c-max(map(abs,row)),c);p=F(lo[j],11**n);q=F(hi[j],19**n)
 features.append([F(1),F(H),d,H*d,p,q,H*p,H*q])
alpha_int=[int(round(x*10**6)) for x in fit['alpha']]
rnum=[(19 if H else 11)**n for H in high]
def lambdas(ai):return [v*sum((F(a,10**6)*b for a,b in zip(ai,row)),F(0)) for row in features]
lam=lambdas(alpha_int);dot=sum((a*r for a,r in zip(lam,rnum)),F(0))
repair_need=max(F(0),dot/(v*sum(rnum))*10**6)
shift=-(-repair_need.numerator//repair_need.denominator)
alpha_int[0]-=shift
lam=lambdas(alpha_int)
assert sum((a*r for a,r in zip(lam,rnum)),F(0))<=0
D=lcm(*(x.denominator for x in lam));ints=[x.numerator*(D//x.denominator) for x in lam]
lsum=[0]*N
for i,row in enumerate(cent):
 rad=9 if high[i] else 5
 for dd in product(range(-rad,rad+1),repeat=n):
  j=index(tuple(row[d]+dd[d] for d in range(n)));lsum[j]+=ints[i]
coeff=[F(49**n*a*b,a*950**n+b*550**n) if a+b else F(0) for a,b in zip(lo,hi)]
zero=max(coeff)
beta=max(cc-F(ll,D) for cc,ll in zip(coeff,lsum))
assert all(beta+F(ll,D)>=cc for cc,ll in zip(coeff,lsum))
oldbeta=F(old['certified_dual_upper_beta'])
report={'model':'R436 pressure n2 c20 stripe','basis':fit['feature_names'],
 'v':str(v),'alpha_common_denominator':10**6,'repaired_alpha_integers':alpha_int,
 'alpha0_integer_repair':shift,'lambda_common_denominator':D,'lambda_integers':ints,
 'lambda_dot_Rn':str(sum((a*r for a,r in zip(lam,rnum)),F(0))/10**n),
 'certified_beta':str(beta),'certified_zero_multiplier_beta':str(zero),
 'certified_previous_unrestricted_beta':str(oldbeta),
 'beta_display':float(beta),'zero_multiplier_beta_display':float(zero),
 'saving_from_zero_exact':str(zero-beta),'saving_fraction_from_zero_exact':str((zero-beta)/zero),
 'restricted_over_previous_upper_display':float(beta/oldbeta),
 'pearson_existing_h_vs_features':fit['pearson_existing_h_vs_features'],
 'float_original_optimum':raw['objective'],'float_restricted_beta':fit['beta'],
 'geometry_and_all_source_columns_checked':True,
 'strict_original_branch':'empty: 2 log(19/11)<sqrt(2)',
 'scope':'Only a fixed native n2 field dual, not a generic certificate or original-history test.'}
(ROOT/'r437_numeric_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print('zero multiplier exact beta=',zero,'display=',float(zero))
print('restricted repaired beta=',float(beta),'previous unrestricted strict beta=',float(oldbeta))
print('saving from zero=',float(zero-beta),'fraction=',float((zero-beta)/zero))
print('restricted / previous upper=',float(beta/oldbeta),'lambda dot Rn=',report['lambda_dot_Rn'])
print('alpha repaired=',[float(F(a,10**6)) for a in alpha_int])
print('feature correlations=',fit['pearson_existing_h_vs_features'])
print('PASS exact basis, full geometry and all-column dual inequalities; no original strict branch.')
