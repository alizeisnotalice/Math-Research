# R437 单次空间basis对偶构造

只复用R436真实n=2,c=20,stripe场；没有重解原LP、没有新增几何case。原场中心1681块、source3481包，v=.098²，q=1，R∈{1.1,1.9}。所有n≤3旧例的原strict-K分支为空；本例亦因(1.9/1.1)²<3<exp(√2)而空。以下是有限静态cut对偶，不是原history压力测试。

## 预先指定basis与一次运行

令H_i为大side指示，d_i=20−||i||∞。在实际父块中心A_i处计算actual selected-center捕获数klo(A_i),khi(A_i)，定义

`p_i=klo(A_i)/11², q_i=khi(A_i)/19²`。

这不是任意关联特征：若Hlo/Hi为连续父块给出的实际ρ占用，则p_i=Hlo(A_i)/(10²v)、q_i=Hhi(A_i)/(10²v)，是局部选父体积卷积的归一量。

预先提出并仅拟合一次

`h_i=α0+α1 H_i+α2 d_i/20+α3 H_i d_i/20+α4 p_i+α5 q_i+α6 H_i p_i+α7 H_i q_i`,

`λ_i=v h_i`，h在每个正体积父块上取常数。MATLAB restricted dual仅9变量（8个有符号α加β），保留全部3481个source列及Σλ_iR_i²≤0；实际求解约.021秒，浮点最大残差7.11e−15。

## 构造与严格修复

α四舍五入至10^6公共分母，随后只减小α0，以保持整个8维basis而使ΣλR²≤0。最终系数为

`(-.744297,.744492,-.082847,.126243,1.443893,1.676040,-1.553719,-2.018422)`。

所有feature、λ及c_j均由Fraction重建；验证完整整数网格、pattern/capture计数、实际source列。取

`β=max_j(c_j−Σ_iλ_i Cij)`。

实际ΣλR²=−595833114692823/21840500000000000000<0；全部3481列β+ΣλC≥c精确成立。因此该场中cut/W≤β是严格有限证书。整数α、公共λ分母及全部λ、精确β保存在`r437_numeric_certificate.json`；脚本`r437_numeric_certify.py`独立验证。实际Python.44秒、RSS约21.3MB，详见resources输出。

## 与零乘子及原dual比较

- 零乘子精确β0=max c_j=21609/88750≈.243481690141。
- 当前restricted repaired β≈.202290815283。
- 节省β0−β≈.0411908748575，占零乘子16.9174424712%。
- R436 unrestricted strict dual β≈.133379834509，浮点最优≈.133374477647。
- restricted β是原strict上界的1.51665217倍，仍贵约51.665%。所以basis有真实改进，但未得到接近unrestricted的简单几何证书。

原unrestricted归一乘子h=λ/v与feature的Pearson相关（仅观察，不是证明）：H .02672，d/20 .04646，H d/20 .06790，p .10122，q .06492，Hp .05638，Hq .05440。常数列相关未定义，输出0只作占位。原dual可能退化，低相关不能否定局部卷积策略；本次判断依赖上面实际restricted可行值而非相关性。

## 效果及剩余缺桥

有限实验确实给出一条有符号、由actual局部卷积和边界距离组成的h，并比零乘子节省约17%。它并未在本场逼近最优，更不能推广为对所有维数、所有实际selector和完整f成立的点态列控制。全几何需要证明统一`g_t(y)≤B/q+∫h_t(A)c_A(y)dA`以及非正质量pairing；当前只在固定场的有限source支撑上验证。没有把稀疏source包之间或支撑外的点态界当成已证，没有给辅助父任何原history，不能付款R433。

代码与输出：`r437_numeric_fit.m`、`r437_numeric_fit_matlab.json`、`r437_numeric_certify.py`、`r437_numeric_certificate.json`、`r437_numeric_run.txt`、`r437_numeric_resources.txt`。已有R436原数据只读，原文件未改。本次basis和结果已发Astra／mainproof，按有界合同停止。


## 指定Poisson候选附加轻量筛选

未解新LP。按Astra指定取l=1_small、实际P，h=(l−Pl)/m，故LP乘子λ=v h。一般使用此公式还须保证绝对配对∫|h|m<∞；当前有限场自动满足，且完整匹配时Σλm=0由dA列守恒成立。

同一原float最优f给βfloat≈.297122607288，但其还原质量残差4.06e−12，故仅作浮点诊断，不认证真实匹配。精确uniformf的每包质量为1/100，完整匹配m=R²；该候选βfloat≈.297812546296，反而高于零乘子β0≈.243481690141。

为避免只凭浮点拒绝，额外仅在已指明的source索引坐标(8,7)计算完整源和局部父积分，Fraction严格核得

`g_j−Σ_iλ_iCij ∈ [.297812546296,.297812546297] > .29 > .25 > β0`。

因此这个固定幅值Poisson候选在此一个精确uniform场上不能改善零dual。未否定其他l或幅值，也未把依f构造的h冒充对所有LP可行f固定的统一dual。原候选代数的零配对仍然成立，失败发生在sourcewise余项上界。可复现单列证书见`r437_numeric_poisson_check.py`、`.json`、`.txt`；完整浮点诊断在`r437_numeric_poisson_matlab.json`。全部附加只复用已加载模型，没有扫描／新优化。
