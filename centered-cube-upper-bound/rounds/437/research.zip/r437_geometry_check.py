from fractions import Fraction as F
from itertools import product
# Algebra-only check of the reported, strictly repaired spatial certificate.
# The native field and source-column feasibility are checked by the numeric agent.
a=list(map(lambda z:F(z,10**6),[-744297,744492,-82847,126243,1443893,1676040,-1553719,-2018422]))
lo=(a[0],a[2],a[4],a[5])
hi=(a[0]+a[1],a[2]+a[3],a[4]+a[6],a[5]+a[7])
count=0
for H,d,p,q in product((0,1),(F(0),F(1,2),F(1)),(F(0),F(1,2),F(1)),(F(0),F(1,2),F(1))):
 old=a[0]+a[1]*H+a[2]*d+a[3]*H*d+a[4]*p+a[5]*q+a[6]*H*p+a[7]*H*q
 b=hi if H else lo
 new=b[0]+b[1]*d+b[2]*p+b[3]*q
 assert old==new
 count+=1
print('low coefficients (constant, normalized boundary distance, low occupancy, high occupancy):',lo)
print('high coefficients:',hi)
print('PASS',count,'exact Fraction algebra checks. Not a new geometry or native-history test.')
