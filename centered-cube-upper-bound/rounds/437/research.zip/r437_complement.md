# R437互补：实际端点的源质量export；small-overlap修正有nW预算，主occupation未付

仅读R437合同及所需既有定义，未读本轮主作者新稿。以下只用实际Q_A、Q_u与完整μ=f dx；不造中间q-band cube，不刷新原历史。没有付掉新的Π433分支。唯一机制是将共同来源质量守恒地输到实际大cube中、小cube外。

## 1. 实际端点export

令Φ(dA,du)=ν为合同的可逆中心流，I_Au=μ(Q_A∩Q_u)。固定d>0，在far cut

F_t={m_u<te^{−d}, m_A>te^d}

上有I_Au≤m_u<e^{−2d}m_A，故M_Au:=m_A−I_Au>0。每条(A,u)流携带的共同来源y可按完整μ再输到

η_Au(dξ)=c_A(ξ)(1−c_u(ξ))μ(dξ)/M_Au.

这是概率核，严格支撑实际Q_A\Q_u。ξ只是付款用辅助标签（不同于原新来源z），不得取得y或u的原stage、时钟或首次删除历史。可保任意原接受权0≤ω(A,u,y)≤1；下面先写裸Φ，接受版只减小非负上界。

令T_t(ξ)为export后的来源密度（相对μ），则

T_t(ξ)=∫_{F_t} Φ(dA,du)c_A(ξ)(1−c_u(ξ))/(m_A−I_Au),
∫T_t dμ=Φ(F_t)=C_far(t).                            (1)

完整matching保证守恒，不存在一份新W。

## 2. 排除small cube与重新归一的精确抵消

定义相对μ的三个非负密度

Ω_t(ξ)=∫_{F_t}Φ(dA,du)c_A(ξ)/m_A,
D_t(ξ)=∫_{F_t}Φ(dA,du)c_A(ξ)c_u(ξ)/m_A,
R_t(ξ)=∫_{F_t}Φ(dA,du)c_A(ξ)(1−c_u(ξ))I_Au/[m_A(m_A−I_Au)].

分母恒等式给

T_t=Ω_t−D_t+R_t,
∫D_t dμ=∫R_t dμ=∫_{F_t}Φ(dA,du) I_Au/m_A.           (2)

所以“排除原小cube”删去的质量被outside归一**等量补回**，不能把D_t当净收缩。Ω_t是直接按实际大cube后验π_A重新取辅助source；它也严格保存总流。

**严格新估计（联合small-overlap与log价格）。** 写Δ=log(m_A/m_u)，α=I_Au/m_A≤e^{−Δ}。对所有t换序，

∫dt/t ∫D_t dμ
 =∫_{m_A>m_u}Φ(dA,du) α(Δ−2d)_+
 ≤e^{−2d−1} Φ{m_A>m_u}
 ≤e^{−2d−1}|E|/2
 ≤e^{−2d−1}A_nW/(2q).                               (3)

用的是max_{x≥0}xe^{−x}=1/e、实际可逆Φ的正反方向等重，以及|E|=∫Jdμ≤A_nW/q。R_t具有同一积分。因而

∫dt/t ∫|T_t−Ω_t|dμ≤e^{−2d−1}A_nW/q=O(nW/q).         (4)

保留接受ω时(2)仍逐边成立，(3)(4)由正支配保持；q_A加权版至多再乘λ。原余流回代最多再乘S/(c_*θ_y√n)，所以该修正会是O(Sr√nW/(c_*θ_y))阶。它仅是export与未排除parent-source核之间的修正价格。未将它单独入母账，未称全余已付。

## 3. 主occupation的精确未付价格

将Φ的共同source fibre展开，设

p_A(t)=∫π_A(dy) ρ_y{m_u<te^{−d}}/J(y)∈[0,1].

未排除的export列准确为

Ω_t(ξ)=∫_{m_A>te^d} c_A(ξ)p_A(t)dA/m_A.              (5)

(2)并没有缩小∫Ω_t dμ；该总量仍恰是C_far(t)。当前只能令p_A≤1。设κ=(1−e^{−2d})^{−1}，实际端点分母还给

T_t(ξ)≤κ Ω_t(ξ)≤κ H_ξ(te^d).

真实中心尺度积分对阈值T给H_ξ(T)≤[1+log(m_max/T)]/q，m_max=λb^n。若D_n=logr+nlog(b/a)、B=(D_n−2d)_+，则

∫dt/t T_t(ξ)≤κ[B+B²/2]/q.                           (6)

完整μ积分仍为O(n²W/q)，不足。丢掉p_A(t)恰是未付的occupation损失：稀少的小cube可能使p_A很小，而(6)按每个大cube在所有可用阈值都收一次价。

要闭合同一个R433，仍需证明(5)保留p_A及实际空间支持后的平均价格∫μ(dξ)∫Ω_t(ξ)dt/t≤C_r n polylog(n)W/q，或带可吸收X误差的版本。此式当前未证且其总量等于原far对数通量；不能把写出(5)本身冒充新付款。真正新增可用的是：若后续几何机制能处理Ω，则强制ξ∉Q_u所引入的全部删除/重归一误差已由(3)(4)以nW/q支付。此处只指未加权L1总变差，或绝对值不超过1的测试；未受控occupation或势函数加权后不自动继承该预算。

ξ在Q_A\Q_u只表明离开当前实际小cube，不保证其ρ低秩势或局部密度下降；f可集中在任意薄边界。故没有已证的occupation收缩。原source帽不能转借给ξ，反方向可逆也不能抵消一个正向export费用。

## 4. 实际局部验算

`/tmp/r437_complement_check.py`实跑n=16的三层真实连续cube场：边长1、3/2、2，中心各为正体积不交小盒；三个来源小盒沿第一坐标置于0、5/8、7/8，完整质量为1、(3/2)^16−1、2^16−(3/2)^16。所有几何incidence恒定，q_A=1，b/a=2，下降质量比均>64>e^4。

Fraction精确核每条可逆edge、T=Ω−D+R、两项修正质量相等、守恒及固定far阈值的列界；70位Decimal仅算log积分。所有断言通过，结果在`/tmp/r437_complement_check.result.json`。该小场不满足原高rank/history，不测试原R433或未付occupation平均界。无大扫描。

结论：得到实际端点、完整源matching的守恒机制，以及小交叠修正的O(nW/q)联合对数预算；leading occupation仍未付。无新余流、收缩或母账变动，按界限停止。
