# R437 bridge：直接原 accepted cut 的 integrated dual

唯一候选：对原 exclusive 概率提升的**直接**有向 cut 建立 integrated dual，允许通过完整中心 matching 付 εX。以下是精确弱对偶合同，不是已证一般证书或闭合结论。只读 R437/R436 合同及本职责所需接口。

## 1. 原 accepted cut，不先丢 rank 分母

Π=Π433，R=|Π|。其静态投影相对 `σ(dA)π_A(dy)π_A(dz)` 有 RN 密度 p，`0≤p≤S`；p 保留原 full-history 平均，不是任意新后验。在 p>0 处，

`Qex(A,y,z;du)=1_{m_u<m_A/K}ρ_y(du)(1−c_u(z))/(Z_A(y)−C_A(y,z))`

为概率核。零 p 行取零，不能给新 u 原历史。定义

`Cacc(t)=∫Π(drecord)∫Qex(du)1_{m_u<t<m_A}`。

质量全在 `I=[qa^n,λb^n]`，故非负 Tonelli 精确给

`Eacc:=∫_I Cacc(t)dt/t=∫Π∫Qex log(m_A/m_u)≥√n R`。  (1)

这里不漏 θ：直接核仍含 Z−C，故 (1)本身不除 θ；若随后上放到可逆 J 核，θ 会明确进入常数。

对 μ-a.e. y，写 `Cacc(t)=∫μ(dy)gacc(t,y)`，其中

`gacc(t,y)=∫σ(dA)c_A(y)1_{m_A>t}/m_A`

` ×∫π_A(dz) p(A,y,z)/(Z_A(y)−C_A(y,z))`

` ×∫ρ_y(du)1_{m_u<t,m_A>K m_u}(1−c_u(z))`。  (2)

(2)的后两行在 z 积分内相乘；C_A(y,z)依赖 z，**不能**先将分母移出 z 积分。零 p 行比值置零。令 `Γ(y)=∫_I gacc(t,y)dt/t`，则 `Eacc=∫Γdμ`。

## 2. 直接 integrated dual 与 εX 的具体系数

需要证明的量词是：对每 ε>0、每个 admissible 原输入及其原 Π，存在可测有符号中心函数 H(A)，使

`∫_E |H(A)|m_A dA<∞`，  (3)

`Γ(y)≤Bε n log^A(n+2)+∫_E H(A)c_A(y)dA`，μ-a.e.，  (4)

`∫_E H(A)m_A dA≤ε√n X_q`。  (5)

Bε须独立于 f、stage数、尺度位置、n；其对原冻结 r,S,θ_y,ε0 等参数的依赖必须受控。证书可依赖实际几何、质量及原 p，但必须对**每个**原输入构造并证明(3)–(5)，不是选一例LP。

由(3)及完整匹配，绝对源 pairing 恰为

`∫μ(dy)∫|H(A)|c_A(y)dA=∫|H(A)|m_A dA`，

所以有符号 Fubini 合法。积分(4)，再用(1)(5)，严格得到

`R≤ε X_q+Bε √n log^A(n+2)W`。  (6)

一个明确实现 ε中心价格的写法是

`H(A)=K(A)+ε√n q_A/m_A`，

`χ(y)=∫q_A c_A(y)dA/m_A`，`∫χdμ=X_q`。

若 `∫|K|m<∞`、`∫Km≤0`，并证明

`Γ(y)≤Bε n log^A+ε√n χ(y)+∫K(A)c_A(y)dA`，

便满足上述合同。ε√n这项的中心 pairing **恰好**是 ε√n X_q；它不是把未知大 X 系数称作可吸收。依然缺的是此源点态/μ-a.e.几何不等式。

若按 t 构造 h_t，充分条件是 `∫_I∫|h_t(A)|m_A dA dt/t<∞`，使 H=∫h_tdt/t；允许仅证明 integrated (4)，不强求每个 cut 都有同价点态证书。切勿在只条件可积时形式相消正负无穷。

## 3. 与充分 unmarked dual 的准确比较

在原 p>0 支上，原 `Z_A(y)≥θ_yJ(y)`、`C_A<h`、`Z_A>(4−ε0)h` 给

`Z_A−C_A≥d*J`，`d*=θ_y[1−1/(4−ε0)]>0`。

删去接受/历史正门并只用 p≤S，有

`gacc(t,y)≤(Sλ/d*) g_t(y)`，`g_t=L_tH_t/J`。  (7)

这是充分上放，非等价。σ=dA·q_A 变为 dA 时付 λ；不把原 σ 核误称可逆。不额外乘stage数或两来源因子，S已包含父两方向。

因此若 unmarked integrated 证书对每个几何给

`∫g_t(y)dt/t≤(B_r n log^A)/q+∫H0(A)c_A(y)dA`，

`∫|H0|m<∞`，`∫H0m≤0`，

则取 H=(Sλ/d*)H0，直接 (6) 的 W 常数是

`Bdirect=Sr B_r/d*`。

这里 θ_y、exclusive常数、S、r 均保留。unmarked路线零 X 付款但量词更强、不含原 p；直接证书允许 ε中心价，并可用原 p/soft/early几何，因而弱于把所有原历史删掉后找普遍证书。两者目前均无一般构造。

## 4. 数值 basis 的验收边界

有限实例的 dual 只证明该已固定 geometry/mass/support 的所有来源列不等式；要迁移成原 full-flow 证明，basis公式必须对任意真实连续选择器及所有原 p，证明(3)–(5)或充分的(7)后 unmarked不等式。必须覆盖 μ-a.e.全来源支撑、非均匀 q、原质量原子与所有 cut，且 integrated 常数不能随格子数/维数指数增长。数值 stationarity、少数 t 的精确证书或一组参数拟合都不完成这些量词。

此前 n≤3 两边长 q=1 LP 的原 strict-K 支为空，其 dual 可作为固定 unmarked cut 数据，不能单独检测本稿 Γ 的非空原分母。等待数值作者的具体 basis 后，仅作此合同对照，不重跑昂贵LP。

## 5. 实际本机计算及结论

已实际运行 `/tmp/r437_bridge_check.py`，stdout `/tmp/r437_bridge_check.stdout`：4个 Fraction matched-incidence 配置核原 σπ² RN权、直接 accepted cut 的源 disintegration、`∫χdμ=X` 与有符号中心 pairing。只是有限代数，非真实 cube/原历史实例，更非(4)的证据。

精确化之后，缺口仍是一项：构造满足(3)–(5)的全输入几何 H（或更强 unmarked H0）。本稿没有把弱对偶重述计作新预算、分支或收缩。

## 6. 数值8维 signed spatial basis 的有界迁移筛选

已按主代理指定仅读 `/tmp/r437_numeric.md`，未另计算、未读写数值脚本或证书。该有限证书给出实际新信息：在固定 n=2,c=20,stripe 的全部3481个来源包上，一项由真实局部占用特征组成的 signed h 比零乘子降低约17%的最坏列余项，同时严格保持非正中心质量 pairing。它证明此固定几何里存在空间补偿，未证明这种补偿的尺度、维度或全输入稳定性。

可继续的结构只保留“高低父标签与其局部 overlap 占用的交叉项”：H、p、q、Hp、Hq。p_i、q_i 是真实中心占用卷积在父块代表点 A_i 的值；数值 h 在整个父块上常值。这不等于已构造每个实际 A 处由 L_t(A)、H_t(A)生成的连续局部公式，后者在父块内一般会变化。要走一般几何，须明确采用哪一个实际可测局部函数，并证明源 pairing；不能把代表点特征的列验证直接延伸到所有连续来源或 selector。

两个边界距离特征 d_i/20、H_i d_i/20 依赖此矩形索引窗口。它们不是原 E 的一般边界距离：当前 E 本来是有间隙的正体积块并。一般可测 E 可高度碎裂，无原始“20”或统一外窗口；若保留这两项，要另证其全场覆盖、尺度归一和非正 pairing 代价，否则会把任意 E 的形状/格数常数带入 B。原两个 side 标签还须换成真实 mass-cut 标签，q变化时不能仅按R大小替代质量大小。

从有限 basis 到第2节或第3节证书，仍缺一个明确的 analytic estimate：对任意原输入，以真实局部 L_t、H_t（及允许的几何量）构造有符号 h_t，使 **同一** μ-a.e.源余项和中心 pairing 同时可控。总体形式可以保局部交叉项，但必须给正确的长度/质量归一，例如 unmarked h 的自然量纲是 m_A^−1 乘无量纲局部函数；原实验常数不能不随整体空间缩放而照抄。必须同时控制 ∫|h_t|m 和 integrated-t 预算。只把α0向下移动，虽在固定场可修复中心 pairing，却会增加各源列余项；其代价没有一般界。

因而当前8维结果适合保留为**局部 overlap 的 signed补偿线索**。它不直接给原 accepted Γ 的不等式；若先证明其通用 unmarked 版本，仍须按(7)支付 `Sr/[θ_y(1−1/(4−ε0))]`，不得漏原rank因子。若改做直接原 Γ 版本，则basis须看见原p及Z−C分母，且满足第2节ε中心价合同。两条迁移都未完成。

附加 Poisson 数据的判断也有界：`h=(l−Pl)/m` 的零中心 pairing来自dA列守恒，确实自动处理一项dual约束；指定 l、指定幅值的源余项在一个精确uniform场的单列已严格高于零dual，故这一固定公式没有产生所需源上界。它不否定其它 l/幅值，也不证明局部overlap basis无效；它明确说明“零pairing”本身不是新几何机制。当前数值场原strict-K支为空，不能据此宣布原全流有新预算。保留空间局部交叉项作为后续构造方向，本轮没有达到可付款的全输入几何证书。
