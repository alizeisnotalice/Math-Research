# R436: one whole-budget target, actual reversible father/source flux

Frozen original target remains R433 <= eps X_q + Ceps sqrt(n) log^A(n+2) W. No new remainder/payment. Authoritative last commit e149d8105e547f4afd3b629b002016b8a46c683b; repo /Users/zhengzhihao/Math-Research-centered-cube-work clean main. Read /tmp/r435_contract.md for actual full f, selected single-valued cubes, sigma, pi, high ranks, low common capture, sourcewise original-history cap, cumulative entropy, static moments and all prohibitions. R435 main proof and geometry add only conditional-information and exact-deletion identities, not any paid whole budget.

This round main geometric idea to screen: use common-source transport and strict mass decrease as an oriented flux, retaining actual reversible measure so opposite flows cannot be independently charged. This is not already a contraction theorem.

Let rho_y(dA)=c_A(y)dA/m_A, J(y)=integral rho_y. Define unweighted-center measure dA (q-band sigma=q_A dA comparable, q<=q_A<=lambda). Full father kernel P(A,du)=integral pi_A(dy) rho_y(du)/J(y), zero J rows irrelevant. By Tonelli its pair flux dA P(A,du) is symmetric: integral f(y)c_A(y)c_u(y)/(m_A m_u J(y))dy dA du. Both row/column=dA, for actual matched m_A. Thus q-weighted flow has column<=r sigma, r=lambda/q, but is not exactly sigma-reversible when q varies.

Original exclusive flow has conditional kernel 1_{m_u<m_A/K}rho_y/Z_A * B_Au(y), B=integral pi_A(dz)L(A,y,z)(1-c_u(z)), K=exp(sqrt n). On support L, Z_A(y)>=theta_y J(y), theta_y inherited fixed positive, so accepted flow dA k can be upper-bounded by (1/theta_y)dA pi_A rho_y/J. This domination loses L and may be overstrong; don't call it equivalent. Source old/new history not assigned to u. Eex and original R433 relate as in R435.

Candidate quantity to analyze, NOT known bounded:
Dlog = integral dA P(A,du) [log(m_A/m_u)]^2,
or oriented mass-drop log flux Flog = integral dA P(A,du) 1_{m_A>K m_u} log(m_A/m_u) with retained B or L if necessary. If a genuine q-scaled Flog<=C n polylog n W plus eps sqrt n X were proved, the strict drop can pay original R433. Bare Dlog budget might be far stronger; screen quickly then retain original accepted flux if needed. Symmetry alone gives opposite orientation equality, not cancellation of a positive one-way cost; any proposed potential telescope must retain boundary/occupation defect.

R435 accepted info I_A>=sqrt n E_A with original full pi_A prior and cemetery. Gated prefix adds <=log2 info for acceptance bit, but average cross-father info bound still missing. Exact deletion identity retains cumulative v_i multiplier and terminal. Don't merely repeat these reductions.

All users require actual local math tools and strict distinction between general proof and finite evidence. Bounded tasks, no wide counterexample scans; 1-2 candidates maximum. Files only /tmp/r436_ROLE*, no repo writes, no other edits, no new agents. Shared filesystem, don't revert others. Each deliver accurate proposition, proof or single exact gap, actual reproducible calculation if relevant, and effect on whole target. Stop after delivery. Constants/scales/source weights/cemetery/real centers/history must stay. Main final integration/audit and per-round compact commit/push; no PDF.
