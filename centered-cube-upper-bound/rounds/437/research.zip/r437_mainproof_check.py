from fractions import Fraction as F

checks=0
for bump in [F(0),F(1,8),F(1,4)]:
 for small in [(F(1),F(2)),(F(7,2),F(9,2))]:
    big=(F(0),F(4));cuts=sorted({F(0),F(8),F(1),F(3),F(2),*big,*small})
    cells=[]
    for lo,hi in zip(cuts,cuts[1:]):
        x=(lo+hi)/2
        if not 0<x<8:continue
        cells.append(((hi-lo)*(1+bump if 1<x<3 else 1),big[0]<x<big[1],small[0]<x<small[1],F(1,3) if x<2 else F(2,3)))
    ma=sum(m for m,a,u,l in cells if a);mu=sum(m for m,a,u,l in cells if u)
    I=sum(m for m,a,u,l in cells if a and u)
    assert ma>2*mu and I>0
    qa=ma/4;qu=mu/(small[1]-small[0]);assert min(qa,qu)>=3*max(qa,qu)/4
    pos=neg=total=F(0);exclusive=F(0);B=F(0)
    for m,a,u,L in cells:
        k=F(a)/ma-F(u)/mu
        total+=m*k;pos+=m*max(k,F(0));neg+=m*max(-k,F(0))
        if a and u:assert k<0
        if a and not u:
            exclusive+=m*L*(-k);B+=m*L/ma
    assert total==0 and pos==neg==1-I/ma
    assert pos>F(1,2)
    assert exclusive==-B
    checks+=1
    print(f'pair {checks}: mA={ma}, mu={mu}, I={I}, positive=negative={pos}, opposite-price exclusive={exclusive}')
print('PASS 6 exact complete-L1 source/actual interval-pair matching checks; all common intersections positive.')
print('Fixed cube-pair algebra only, not positive-center flow or original stage/history realization.')
