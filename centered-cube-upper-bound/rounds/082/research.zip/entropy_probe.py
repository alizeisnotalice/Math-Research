"""R82: common-law KL identities, with actual L1 first-hit interval fixture.
Finite probabilities use exact Fractions; logarithms/quadrature are diagnostics.
No test certifies a general maximal weak estimate.
"""
from fractions import Fraction as F
from math import log
import json, random
from pathlib import Path

def kl(p,q):
    return sum(float(a)*log(float(a/b)) for a,b in zip(p,q) if a)

def joint_check(weights, prior, masks):
    assert sum(weights)==sum(prior)==1
    rows=[]; captures=[]
    for w,mask in zip(weights,masks):
        c=sum(p for p,m in zip(prior,mask) if m)
        assert c>0
        captures.append(c)
        rows.append([w*p/c if m else F(0) for p,m in zip(prior,mask)])
    marginal=[sum(row[i] for row in rows) for i in range(len(prior))]
    assert sum(marginal)==1
    flat=[v for row in rows for v in row]
    product=[w*p for w in weights for p in prior]
    independent=[w*p for w in weights for p in marginal]
    lhs=kl(flat,product); source=kl(marginal,prior); mutual=kl(flat,independent)
    direct=-sum(float(w)*log(float(c)) for w,c in zip(weights,captures))
    assert abs(lhs-direct)<1e-11 and abs(lhs-source-mutual)<1e-11
    return dict(total=lhs,source=source,mutual=mutual)

def simpson(fun,a,b,N):
    assert N%2==0
    h=(b-a)/N
    return h/3*(fun(a)+fun(b)+sum((4 if j%2 else 2)*fun(a+j*h) for j in range(1,N)))

def actual(N):
    # f=4 1_[0,1], lambda=1, x=-d, 3/8<d<1/2.
    # First global hard hit r=2d; full side L=4d in (3/2,2).
    # Posterior y|d uniform [0,d], d uniform (a,b).
    a=3/8;b=1/2
    def rho(y): return log(b/max(a,y))/(b-a) if y<b else 0.
    def integrand(y):
        v=rho(y);return v*log(v) if v else 0.
    mass=a*rho(0)+simpson(rho,a,b,N)
    source=a*integrand(0)+simpson(integrand,a,b,N)
    total=-((b*log(b)-b)-(a*log(a)-a))/(b-a)
    mutual=total-source
    assert abs(mass-1)<1e-10 and source>=0 and mutual>=0
    return dict(panels=N,mass=mass,total=total,source=source,mutual=mutual)

def main():
    rng=random.Random(820411)
    finite=[]
    # Three ranges; exact normalized joint probabilities, float log comparison.
    for N,M,trials in ((2,3,20),(5,7,40),(12,16,60)):
        for _ in range(trials):
            aa=[rng.randint(1,50) for _ in range(N)];bb=[rng.randint(1,50) for _ in range(M)]
            weights=[F(v,sum(aa)) for v in aa];prior=[F(v,sum(bb)) for v in bb]
            masks=[]
            for __ in range(N):
                row=[rng.randrange(2) for ___ in range(M)]
                if not any(row):row[rng.randrange(M)]=1
                masks.append(row)
            finite.append(joint_check(weights,prior,masks))
    branches=[]
    for D in (16,64,256):
        for j in range(1,D):
            d=F(3,8)+F(j,8*D);r=2*d;L=2*r
            assert F(3,2)<L<2 and 4*(r-d)/(2*r)==1
            assert 4*(F(1,2)-d)<F(1,2)
            # On first partial overlap A_s=2-2d/s, monotone and <1 for d<s<2d.
            for q in (F(1,4),F(1,2),F(3,4)):
                s=d+q*d
                assert 2-2*d/s<1
            branches.append(dict(d=str(d),r=str(r)))
    quadrature=[actual(k) for k in (128,512,2048,8192)]
    assert abs(quadrature[-1]['source']-quadrature[-2]['source'])<1e-8
    replications=[]
    base=joint_check([F(1,3),F(2,3)],[F(1,4),F(1,2),F(1,4)],[[1,1,0],[0,1,1]])
    for m in (1,2,4,8,16):
        weights=[w/m for _ in range(m) for w in (F(1,3),F(2,3))]
        prior=[w/m for _ in range(m) for w in (F(1,4),F(1,2),F(1,4))]
        masks=[]
        for j in range(m):
            for mask in ([1,1,0],[0,1,1]):
                masks.append([v if k==j else 0 for k in range(m) for v in mask])
        out=joint_check(weights,prior,masks)
        assert abs(out['source']-base['source'])<1e-10
        assert abs(out['mutual']-base['mutual']-log(m))<1e-10
        replications.append(dict(copies=m,**out))
    out=dict(status='PASS',seed=820411,exact_branch_cases=len(branches),finite_joint_cases=len(finite),max_chain_residual='asserted < 1e-11; floating logs',actual_l1_quadrature=quadrature,replications=replications,scope='Exact algebra and rational first-hit geometry; KL log arithmetic and continuum quadrature are numerical. Dense interval fixture does not assert smooth-gate membership. No general weak bound.')
    Path(__file__).with_name('entropy_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
