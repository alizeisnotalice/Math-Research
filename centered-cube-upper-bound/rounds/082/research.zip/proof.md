# 中心立方体第82轮：共同来源运输、极低平滑背景分支与剩余几何

日期：2026-10-11。**一般目标未完成。** 本轮没有证明 $C_n^\square\le\sqrt n\,n^{o(1)}$；全一般保留基准仍为 $O(n\log n)$。第81轮已提交并推送 `20a1b6b59254daccdfb13bf0c0c4063420dc8d87`，本轮在其真实共同硬首次接触与已核验全尺度返回上继续。

## 一般路线的实质进展

保留第81轮窗口 `[1,2]` 的两个已付例外：初始硬平均大于等于 `lambda/2`，或整个窗口的真实 E2 平滑最大值大于 `lambda/2`。它们的总费用为 `[4+2(log2)sqrt(7n/3)]||f||1`。其余接收点使用同一个真实硬首次接触，硬平均等于 `lambda`。

本轮新增一项适用于任意正 L1 输入的支付。令 `ell_1(t)=-log phi(t)`，`ell_edge=ell_1(1/2)`，`mu` 为 `ell_1` 在 `[-1/2,1/2]` 上的积分，`d=ell_edge-ell_1(0)`。对 `n>=2` 取

    s_n=ell_edge+(n-1)mu+(d/2)sqrt((n-1)log(n+2)).

在任意选定的实际尺度上，若 `A>=lambda` 且 `P_1/A<=exp(-s_n)/2`，则这些接收点的 `lambda` 加权体积至多为

    2(1+n log2)||f||1/sqrt(n+2).

证明先从真实同源似然得到至少一半捕获质量进入高似然损失区域，再由包含该区域的立方体方向锥收费。独立性只用于均匀立方体的参考方向分布，不用于任意输入的来源坐标。Hoeffding 型界在正文直接证明。**`s_n` 为线性维数量级，故这只支付极低平滑背景分支；普通低背景区域尚未解决。**

现在剩余共同事件可进一步写为：原两个门槛均通过、真实硬首次接触处

    exp(-s_n)/2 < P_1/lambda <=1/2.

若其一致弱费用为 `D_mid(n)`，则第81轮的原文核验给出条件转移

    C_n^square <= C_loc log(n+2) *
      [4+2(log2)sqrt(7n/3)+2(1+n log2)/sqrt(n+2)+D_mid(n)].

这里 `D_mid(n)` 仍待证明，不能把已付的根号项当成主定理。n=1 可直接保留固定窗口常数界，不影响维数渐近目标。

## 为什么继续使用共同来源重分配

固定捕获后验的某个来源可能承担过大费用。本轮给出真实正 L1、多尺度首达族：即使只保留新鲜来源，旧来源的固定后验负担仍随深度增长；但显式重分配到互不重叠的本地来源区间后，共同容量可以统一取 `1/15`。这是实际可行的重分配，不是给每个接收点另复制一份来源。该族跨越多个全局尺度，未冒充固定窗口障碍。

一般共同运输由来源容量、接收需求和真实捕获关系定义。有限情形的最优值等于全部 Hall 割比值，并有精确最大流证书；紧致正则情形的连续实现另有完整证明。新鲜来源约束与弱型问题之间的比较保留所有系数。该优化语言尚未证明一般 Hall 割具有根号阶界。

## 不可忽略的剩余结构

一个真实高维正 L1 输入在上述**未支付的中间比值区域**，仍可具有任意大的方向信息和坐标相关性；该现象在正体积接收邻域持续。邻域大小没有统一下界，因而这不是主弱型目标的反例，而是排除了直接从门槛推断独立或小熵的做法。

另一个真实立方体密度在每个 `n>=2` 都通过锚点和整个连续窗口的平滑门槛，却使几乎所有捕获来源的首达雅可比方向为负。符号抵消必须保留负方向费用、重心导数费用及首达分支边界。本轮给出准确恒等式和有理数连续平滑包络；仅计算完整来源射线的有向次数不能支付原来的逆雅可比占用量。

父稿核验同一接收—来源联合律的熵链式恒等式，并明确不相交复制产生的标签互信息费用。它没有假设一般输入具有有限微分熵，也没有从归一化来源 KL 反推未知弱比例。

## 复现、技能与交付范围

本轮主数值模型计算17个实例、123599个完整原始 dx 空间单元、34个有理 Hall/最大流最优值和1402个非空来源子集条件。保留首次有限网格越阈的超调量，不把它写成连续首次接触。另有小盒 L1 近似的定性极限说明，不能替代连续选择器证明。

父稿的熵探测包含120个有限联合律、333个真实 L1 有理首达点和四档积分复核。有限精确证书、浮点对数、求积及抽样均明确分开。每个主要论证有分阶段检验；详细范围、失败机制和实际输出在后文及 `inventory.json`。

本轮复核64个技能入口及437个直接引用，内容相对第81轮未变化。入口哈希与链接可读性核验不表示全部论文都已阅读或所有工具都已认证；实际使用的技能边界分别写在各节。覆盖、软层与硬面工作使用 Astra medium，数值实现和独立审计使用 Sol high。LaTeX 以 `.tex.txt` 保存，只作静态检查，不编译或生成 PDF。归档仅保留合并报告、必要复现程序、结果及清单，继续逐轮单独提交推送。

下文依次包含：共同来源运输；同源似然及极低背景支付；首达方向与欠缺费用；父稿熵归一化；完整空间分区数值笔记；独立审计及可复现核验代码。


# R82 transport: actual first-hit Hall allocation and a strict improvement over the fixed posterior

**Status.** We prove the exact finite Hall/dual problem, a compact regular continuum realization, and its precise relation to the original weak bound. Fresh-annulus transport has the same order of difficulty as the weak theorem; this equivalence is not a closure. We also give a genuine positive L1 first-hit family on which the fixed posterior has unbounded per-source load even after fresh truncation, while an explicit common transport has capacity at most 1/15. The latter is a structural gain for reallocation, not a general dimension bound. The target sqrt(n)n^{o(1)} remains unproved.

Read R81 hardface.md and parent_radial.md; applied D01, B01 and L03 only with their stated boundaries. Positive transport, not vector-measure transport, is used. The continuum realization is proved below on a compact closed relation rather than inferred from a generic OT theorem. Finite rational flow and cut witnesses are exact; no floating interval library is assumed. Only these two owned files are written, with one embedded stdlib guard; no Git or TeX compilation.

## 1. The same hard first hit, source, and receiver measure

Let mu=f(y)dy with f>=0 in L1, and use full side L. Let X be a set of actual hard first-hit receivers at level lambda, with measurable L(x)>0 and

    mu(Q(x,L(x)))=lambda L(x)^n.

For a global first hit all smaller scales have averages <=lambda. The usual paid {f>lambda/2} branch guarantees positive first scales at almost every remaining receiver. No private soft-layer selector is substituted. Define receiver demand nu(dx)=lambda 1_X dx and source capacity K mu(dy). A positive measure gamma on X times source space is feasible when

    gamma_X=nu,   gamma_Y<=K mu,

and gamma is supported on one of the actual relations

    R_capture: |x-y|_infinity<=L(x)/2,
    R_fresh: q L(x)/2<=|x-y|_infinity<=L(x)/2,
    q=8^(-1/n).

Closed boundary conventions do not affect mu-sections because mu is L1. These are source capacities shared by all receivers, not a copy of the source for every x. A successful capacity bound immediately gives lambda|X|<=K W by taking total mass.

The first-hit age inequality gives

    mu(R_fresh(x)) >=(7/8)lambda L(x)^n                     (A)

at a global hit. For a first contact only in [1,2], it gives (A) when qL(x)>=1. On the retained window set with A_1<lambda/2, the remaining early case qL(x)<1 still has

    mu(R_fresh(x))>=lambda L(x)^n-lambda/2
                         >=(1/2)lambda L(x)^n.            (B)

Indeed the old cube is inside the unit-scale cube at the SAME receiver. The parent truncated-recent relation with inner side max(qL(x),1) also obeys (B), with (A) on late hits. No claim about untested smaller scales is used. The additional retained smooth gate only shrinks X and leaves these conclusions valid.

## 2. Exact finite transportation LP and Hall dual

Let receiver rows i have demand d_i>0 and source columns j have mass p_j>0. An edge i~j means the original common capture or fresh relation holds throughout the corresponding finite cell. There is no change of selector during optimization. The primal is

    K*=min K,
    z_ij>=0 on edges, sum_(j~i) z_ij=d_i,
    sum_(i~j) z_ij<=K p_j, K>=0.                           (P)

An isolated positive-demand row makes K*=infinity. Otherwise the exact value is

    K*=max_(nonempty A subset rows) d(A)/p(N(A)).           (H)

A direct LP dual is

    maximize sum_i d_i u_i,
    u_i>=0, v_j>=0, u_i<=v_j for every edge,
    sum_j p_j v_j<=1.                                    (D)

Weak duality follows by multiplying the row and capacity constraints. For optimal v one may use v_j=max_(i~j)u_i. Layer cake gives

    sum_i d_i u_i=integral_0^infinity d({u>t})dt,
    sum_j p_j v_j=integral_0^infinity p(N({u>t}))dt.

Consequently every dual objective is bounded by the right side of (H). Conversely the indicator u=1_A/p(N(A)), v=1_N(A)/p(N(A)) attains each Hall ratio. Thus only cut potentials are needed to obtain the best dual value.

For completeness, Hall sufficiency can be proved without importing an infinite-dimensional dual theorem. At fixed K form the finite network: start-to-row capacities d_i, row-to-adjacent-source capacity D=sum_i d_i, and source-to-end capacities Kp_j. A maximum flow exists in its compact finite capacity box. If it fails to have value D, use vertices reachable from the start through positive residual capacity. The associated cut has capacity below D; its unsaturated receiver subset gives d(A)>Kp(N(A)). Conversely such an A forbids a full flow. This proves (H), primal attainment and the finite dual equality. Rational input allows rational augmenting flows and rational cut witnesses; floating residuals alone are not certificates.

## 3. A continuum realization with checked topological assumptions

Initially let X be compact, L:X->(0,infinity) continuous, and mu a finite L1 measure. Restrict the source space to a compact Y containing all selected capture cubes; sources outside it cannot help. The relation R_capture or R_fresh is closed in X times Y. For compact A subset X its neighborhood N(A) is compact. Then a coupling of demand nu=lambda 1_X dx into capacity Kmu exists if and only if

    nu(A)<=Kmu(N(A)) for every compact A subset X.          (CH)

Necessity is immediate. Here is a proof of sufficiency. Partition X and Y into finitely many Borel cells of diameter at most epsilon, with compact closures relative to X,Y. Put an edge between cells whenever the product of their closures meets R. For any subset of receiver cells, the union A of their closures is compact. Their total demand is at most nu(A), and N(A) is contained in the union of the adjacent source cells UP TO their boundaries. Choose all cell boundaries null for nu and mu, so these boundary additions have zero mass. Such partitions follow from coordinate grids whose finitely many slicing levels avoid the countably many positive-mass coordinate slices. Thus (CH) supplies every finite Hall condition.

Use Section 2 to construct a finite flow, and spread each edge flow by the product of the normalized restrictions of nu and mu to its two cells. Zero-mass cells carry no flow. This gives exact receiver marginal nu and source marginal <=Kmu; its support lies within O(epsilon) of R. Compactness of finite measures on the compact product gives a weakly convergent subsequence. Its limit has the same receiver marginal, the capacity inequality, and support in R because R is closed. This proves (CH). The capacity objective therefore equals sup_compactA nu(A)/mu(N(A)), with the zero-denominator convention from the finite problem. The same compactness gives attainment at finite K*.

This statement is deliberately not asserted for every arbitrary Borel relation without topological hypotheses. For the regular smooth-input/generic-level class established in R81, the actual first-hit radius is locally C1 off a null set. Compact receiver subsets inside that regular domain satisfy the assumptions. Uniform estimates on all such subsets would give the receiver-volume bound by compact exhaustion; R81 then returns a uniform weak estimate to general L1 inputs. We do not need to assert that arbitrary chosen optimizing couplings converge across every L1 approximation. The numerical finite-cell source model is another separate setting covered directly by Section 2.

## 4. Relation to the weak theorem: useful equivalence, not closure

Suppose C is any already proved hard maximal weak constant, either for all scales or for the physical window under consideration. More generally assume every selected receiver has

    mu(R(x)) >= c lambda L(x)^n, 0<c<=1,

and R(x) is contained in its actual selected hard cube. Then every compact receiver subset A obeys

    lambda |A| <= (C/c) mu(N(A)).                          (W->H)

Proof: let g=f 1_N(A). For every x in A, its selected cube has g mass at least c lambda L(x)^n. Hence its hard maximal average is at least c lambda. Apply the strict weak theorem at c lambda-epsilon, then send epsilon down to zero. The same L(x) remains a legal scale. It need not remain a first hit for the restricted input g; the weak theorem requires no such property. This proves (W->H), and Section 3 realizes the capacity when its hypotheses apply.

Consequently

    K_capture*<=C,
    K_fresh*<=8C/7 for global or late window hits,
    K_fresh*<=2C for all anchor-retained window hits.

Conversely a uniform transport capacity bound on the actual retained set pays its lambda-volume immediately; add precisely the previously paid branches to recover the weak theorem. For global first hits outside {f>lambda/2}, this gives C_weak<=K+2. For the R81 window with the anchor and smooth gates it gives the retained capacity plus the already proved coefficient 4+2 log(2)sqrt(7n/3), followed only by the conditional all-scale localization. Thus the missing dimension-uniform Hall estimate is of the same order as the missing weak estimate. Restricting to fresh sources does not cause an additional uncontrolled existence obstruction, but (W->H) cannot be used with the desired C before C is proved.

There is also an explicit O(n) window baseline. The canonical captured plan is

    dgamma=1_X(x)L(x)^(-n)1_capture f(y) dxdy.

Its source density relative to mu is bounded by the hard window envelope 1+n log2. For fresh transport normalize the actual fresh section:

    dgamma_fresh=lambda 1_X(x)1_fresh f(y)/mu(R_fresh(x)) dxdy.

Using (A) or (B) and the exact shell envelope from R81 gives capacity at most

    (8/7)(7/8+n log2) for global/late hits with L in [1,2],
    2(7/8+n log2) for all anchor-retained window hits.

For the truncated-recent relation its kernel is bounded by the same fixed-q shell, so the second estimate still holds. These are genuine feasible flows but retain linear dimension dependence. Across unrestricted scales the analogous fixed-posterior envelope need not be finite; the next example shows that this is a real defect even in dimension one, not just a bad estimate.

### 4.1 Capture cuts inherit the retained gates, with a necessary strictness repair

There is a sharper closure fact for CAPTURE neighborhoods. Let A be compact, let its actual first-hit L(x) be continuous, and assume that each selected contact has strict crossings arbitrarily close immediately afterward (in particular this holds at the regular positive-derivative first hits). Write N_0=union_(x in A)Q(x,L(x)). For g_0=f1_N0, every average at the same x and every scale <=L(x) is EXACTLY preserved, not merely bounded above: those cubes are contained in its selected cube. The selected level and first contact therefore remain unchanged. The anchor and smooth upper gates also decrease.

However exact cutting may remove the subsequent sources needed for a STRICT crossing. For instance f=4 1_[0,1], x=-a, 0<a<1/2 has first radius 2a at level one, but truncating the source to [0,a] makes its maximum at x equal to one with no strict excess. Thus an argument using the strict retained event must not directly infer membership after exact cutting merely from preservation of the level equation.

Repair this by setting

    N_epsilon=union_(x in A)Q(x,(1+epsilon)L(x)),
    g_epsilon=f1_Nepsilon.

For window receivers L(x)<2 because the original target has a strict crossing within the window. Every x retains its whole original average history up to (1+epsilon)L(x), including a strict witness before min((1+epsilon)L(x),2). The first selector is unchanged on A and both original R81 upper gates are preserved. The sets N_epsilon are compact, decrease to N_0 by compactness of A and continuity of L, and mu(N_epsilon) decreases to mu(N_0).

Let D_ret be the supremum of lambda|E_ret(f,lambda)|/||f||_1 for the ORIGINAL R81 retained window event with the anchor and smooth UPPER gates. Applying its defining bound to g_epsilon gives

    lambda|A|<=D_ret mu(N_epsilon) -> D_ret mu(N_0).

Apply the same argument to every compact subset of the receiver set. Hence K_capture* on every such regular compact original retained set is at most D_ret: this uses the retained bound itself, rather than an external full weak constant. If the supremum is instead defined over regular compact receiver triples (positive L1 input, continuous actual selector, immediate post-contact strict crossings, retained upper gates), the class is stable under this inflated cut: the selector on A is unchanged, and the same nearby strict crossings are preserved. Taking the supremum of total-mass lower bounds gives the exact equality between the supremal capture-transport capacity and the supremal retained volume ratio within that class. No equality between this regular compact supremum and every arbitrary L1 retained event is asserted without a separate approximation argument.

The new middle branch has an additional LOWER bound on P_1/A. This is not inherited: source restriction can lower P_1. A safe combined statement is conditional on a proved extreme-branch fee C_ext and the middle retained supremum D_mid. Apply the old retained partition to each actual g_epsilon at its preserved hard selector; then

    lambda|A|<= (D_mid+C_ext) mu(N_epsilon),
    K_capture*(A)<=D_mid+C_ext.

The freshly truncated input must actually be repartitioned; the original receiver's middle label cannot simply be reused. This still is a capacity/weak-bound relation, not a new estimate for D_mid. No such hereditary statement is claimed for a fresh-neighborhood cut, which can remove old captured mass and move the contact itself.

## 5. Actual positive L1 family: fresh posterior load unbounded, reallocated capacity <=1/15

Work in n=1 and lambda=1. For N>=1 let

    R_k=100^k,
    f_N=4 1_[0,1]+4 sum_(k=1)^N 1_[R_k,2R_k],
    B_k=R_k-(1+sum_(j<k)R_j)=(98 R_k+1)/99,
    E_k=[4B_k/9,6B_k/11], E=union E_k.

The receivers lie in empty gaps, so f_N(x)=0 and the local paid-density exception does not remove them. Their actual global first-hit half-radius is

    r(x)=2(B_k-x), x in E_k.                               (FH)

To verify it, before the kth interval begins entering, the average is at most M_(k-1)/[2(x-end_previous)]<1, where M_(k-1)=4(R_k-B_k) and end_previous is 1 for k=1 or 2R_(k-1) otherwise. After entry, the average is bounded above by

    [M_(k-1)+4(x+r-R_k)]/(2r)=2-2(B_k-x)/r,

which is strictly below one for r<2(B_k-x). At (FH), the left endpoint 3x-2B_k is negative, so all earlier intervals are captured; the right endpoint 2B_k-x is between R_k and 2R_k, so the upper bound is attained and equals one. Later sources are absent. A small increase of r gives a strict crossing, establishing the actual first hit, not just a level equation. All interval and earlier-average inequalities follow from R_k=100^k and B_k/R_k>=98/99; the guard checks them as exact rational inequalities.

At q=1/8 every captured source is fresh on E. The previous source intervals end below x-r/8, while the kth interval starts above x+r/8. Indeed

    x-r/8=(5x-B_k)/4 >=11B_k/36,
    x+r/8=(3x+B_k)/4 <=29B_k/44<R_k,

and every previous source endpoint is at most max(1,R_k/50)<11B_k/36. Thus neither the hard posterior nor its normalized fresh version loses any captured source here.

For every old source y in [0,1], its canonical load relative to f_N(y)dy is exactly

    integral_E 1/(2r(x)) dx
      = (N/4) log(11/9).                                  (OLD)

This tends to infinity on a positive source-measure set. It is an actual common-source posterior load, not a receiver probability substituted for dx.

Nevertheless let the fixed local source interval be

    J_k=[R_k,7B_k/5].

It is nonempty; it is inside the captured kth interval for EVERY x in E_k because 7B_k/5<16B_k/11=min_x(2B_k-x); and it is fresh by the preceding gap inequalities. Define the common product transport on each rectangle E_k times J_k by

    dgamma_k=1_Ek(x)dx * [f_N(y)1_Jk(y)dy / mu(J_k)].

Every receiver gets demand dx exactly. The source intervals J_k are disjoint, and source density relative to mu on J_k is

    |E_k|/mu(J_k)
       =(10B_k/99)/[4(7B_k/5-R_k)]
       <=1225/18909 <1/15.                                (NEW)

Here R_k/B_k<=99/98. Summing the gamma_k therefore gives a single feasible capture AND fresh transport with K<=1/15, for every N. No receiver-private source copy appears and no mass is reused across k. This is a concrete source reallocation that removes the unbounded canonical load in (OLD).

The family spans many global scales. It is not presented as an unbounded-posterior example inside one fixed [1,2] window, where Section 4 already gives an O(n) bound. Its total input mass grows with N and its weak receiver fee is small; it does not give a lower bound against the target maximal theorem. The general lesson is narrow but rigorous: a per-source bound on the fixed posterior, even after a fresh cutoff, is strictly stronger than the existence of an efficient common transport.

## 6. Remaining geometric problem and executable next step

The exact remaining finite obstruction is a receiver subset A with large ratio lambda|A|/mu(N_fresh(A)), not a source with a large canonical posterior load. The continuum analogue uses actual first-hit cubes/annuli and their common-source neighborhood union. The rowwise age inequality controls individual fresh masses; the Hall condition requires a bound for ALL unions. No disjointness, angular independence or tree mass flow follows from the age law alone.

A non-tautological next theorem must bound those union ratios at sqrt(n) times subpolynomial cost directly from geometry, or split off high-ratio subsets with a separately proved payment. The explicit local-J_k repair above shows what such a source allocation can accomplish in one real pressure family, but supplies no general packet rule. The implementation agent tests exact full-cell Hall ratios and primal flows, compares optimized capacity with canonical loads, and records its finite-scale/atomic limitations separately. No general cheap-capacity existence theorem is inferred from those finite examples.

## 7. Embedded exact guard

The guard verifies finite Hall cut ratios against exact augmenting flows, then checks actual L1 first-hit inequalities and the common fresh product allocation for increasing N. It uses rational arithmetic for every claimed inequality; the logarithm in (OLD) is proved analytically and its displayed decimal is only diagnostic. The first finite-graph stage is an algebra guard, not a geometric theorem. The later stages use the actual positive L1 family in Section 5; independent complete-cell dimension tests belong to the implementation report.

```python
from fractions import Fraction as Q
from collections import deque
from random import Random
from math import log
rng=Random(82041)
checks=0

def hall(d,p,edges):
    best=Q(0);witness=0
    for mask in range(1,1<<len(d)):
        ns={j for i in range(len(d)) if mask>>i&1 for j in edges[i]}
        mass=sum((p[j] for j in ns),Q(0))
        assert mass>0
        ratio=sum((d[i] for i in range(len(d)) if mask>>i&1),Q(0))/mass
        if ratio>best:best,witness=ratio,mask
    return best,witness

def flow(d,p,edges,K):
    m,n=len(d),len(p);s=m+n;t=s+1;D=sum(d)
    cap={};adj=[set() for _ in range(t+1)]
    def add(a,b,c):
        cap[a,b]=c;cap[b,a]=Q(0);adj[a].add(b);adj[b].add(a)
    for i,di in enumerate(d):add(s,i,di)
    for i,ns in enumerate(edges):
        for j in ns:add(i,m+j,D)
    for j,pj in enumerate(p):add(m+j,t,K*pj)
    val=Q(0)
    while True:
        prev={s:None};todo=deque([s])
        while todo and t not in prev:
            a=todo.popleft()
            for b in sorted(adj[a]):
                if b not in prev and cap[a,b]>0:prev[b]=a;todo.append(b)
        if t not in prev:break
        path=[];b=t
        while b!=s:a=prev[b];path.append((a,b));b=a
        z=min(cap[e] for e in path)
        for a,b in path:cap[a,b]-=z;cap[b,a]+=z
        val+=z
    return val

# Stage 1: exact finite Hall dual cuts and independent augmenting flows.
for m,n in ((2,2),(4,3),(6,5),(8,6)):
    for trial in range(12):
        d=[Q(rng.randrange(1,10),7) for _ in range(m)]
        p=[Q(rng.randrange(1,10),11) for _ in range(n)]
        edges=[{j for j in range(n) if rng.randrange(3)} for i in range(m)]
        for ns in edges:
            if not ns:ns.add(rng.randrange(n))
        K,A=hall(d,p,edges)
        assert flow(d,p,edges,K)==sum(d)
        ns={j for i in range(m) if A>>i&1 for j in edges[i]}
        lhs=sum(d[i] for i in range(m) if A>>i&1)
        assert lhs==K*sum(p[j] for j in ns)
        assert flow(d,p,edges,K*Q(99,100))<sum(d)
        checks+=1
print('stage1 exact Hall/flow cases',checks)

def actual_family(N,separation=100):
    global checks
    old=Q(1);previous_end=Q(1);totald=Q(0);maxcap=Q(0)
    for k in range(1,N+1):
        R=Q(separation**k);B=R-old
        a=4*B/9;b=6*B/11
        assert 0<previous_end<a<b<R
        M=4*old
        assert M/(2*(a-previous_end))<1
        for x in (a,(a+b)/2,b):
            r=2*(B-x)
            assert x-r<0<R<x+r<2*R
            assert M+4*(x+r-R)==2*r
            # Every earlier post-entry upper envelope is below level one.
            for t in (Q(1,2),Q(3,4),Q(9,10),Q(99,100)):
                rr=t*r
                if rr>=R-x:
                    assert (M+4*(x+rr-R))/(2*rr)<1
            assert previous_end<x-r/8
            assert x+r/8<R
            assert x-r<=0 and 1<=x+r
            assert R<7*B/5<x+r
        assert previous_end<11*B/36 and 29*B/44<R
        Jmass=4*(7*B/5-R)
        demand=b-a
        K=demand/Jmass
        assert K<=Q(1225,18909)<Q(1,15)
        # Fixed common product plan: receiver density one, exact source load K.
        assert K*Jmass==demand
        totald+=demand;maxcap=max(maxcap,K)
        old+=R;previous_end=2*R
        checks+=1
    return totald,maxcap

# Stage 2: actual positive L1 first hits, all sources fresh, common allocation.
for N in (1,2,4,8):
    demand,K=actual_family(N)
    print('stage2 N',N,'max source capacity',float(K),'old posterior load',N*log(11/9)/4)

# Stage 3: input depth growth and wider separations, exact same geometry.
for sep in (100,200,1000):
    for N in (12,24,48):
        demand,K=actual_family(N,sep)
        assert K<Q(1,15)
        # Density and threshold scaled together leave geometry/capacity unchanged.
        for lam in (Q(1,7),Q(1),Q(13,3)):
            assert lam*demand/(lam*4*(1+sum(Q(sep)**k for k in range(1,N+1))))<K
            checks+=1
        print('stage3 separation,N',sep,N,'capacity<=',float(K),'posterior=',N*log(11/9)/4)
# Strict-level repair: the exact cut loses strict excess; inflation restores it.
for a in (Q(1,4),Q(2,5),Q(9,20)):
    for eps in (Q(1,100),Q(1,20)):
        r=2*a;witness=r*(1+eps/2)
        assert 4*a/(2*r)==1 and 4*a/(2*witness)<1
        assert a+2*a*eps<1
        assert 4*(witness-a)/(2*witness)>1
        assert witness<r*(1+eps)
        checks+=1
print('strict-cut/inflation repair passed six exact instances')
print('PASS',checks,'case groups; all inequalities rational; log displays diagnostic')
```

Execution passed **348 case groups**: 48 exact finite Hall/flow instances, 267 actual L1 source-interval verification instances, 27 density/threshold scaling checks, and six strict-cut/inflation repairs. At N=48 the old-source posterior load is approximately 2.4080483, while the explicit shared-source capacity remains below 0.064784 (and below the proved 1/15 bound). Arbitrarily larger N is covered analytically. The finite graph tests are algebra checks; the L1 source family supplies the geometric proof. Independent analytic audit of Sections 1–6 passed without a mathematical correction.


# R82: the actual smooth likelihood, a paid extreme branch, and an angular obstruction

**Status.** A new general, adaptive-scale branch is paid at O(sqrt(n)) on the fixed window [1,2]: the branch where the actual smooth-to-hard ratio is exponentially below its reference angular mean. The ordinary R81 ratio bound P_1/A<=1/2 does not give this branch. A genuine L1 construction satisfying the R81 first-hit, anchor and full-window smooth conditions permits arbitrarily large angular information and coordinate dependence on a positive-volume receiver neighborhood. The general residual event and the centered-cube goal remain unproved.

D02 is used only with finite log likelihoods explicitly checked below. D04 is used with the same joint source law and its true conditional reference kernels. No independent source-coordinate law or finite entropy of arbitrary f is assumed. The concentration calculation is proved directly for a geometric reference distribution, not transferred to the source posterior.

## 1. Same-input hard and smooth posterior identity

Let h=1_{[-1/2,1/2]}, H=h^tensor n, w(x)=integral_0^1 exp(-|x|/r)dr, phi=h*w and Phi=phi^tensor n. For f>=0 in L1, W=||f||1, a receiver x and actual scale L in [1,2], put A=f*H_L(x)>0 and P=f*Phi_L(x). In displacement coordinates z=(x-y)/L define two probability densities on R^n:

    pi(z)=f(x-Lz) H(z)/A,
    sigma(z)=f(x-Lz) Phi(z)/P.                       (1)

They come from the SAME source and receiver. P is finite and positive. On Q=[-1/2,1/2]^n put

    ell(z)=sum_j ell_1(z_j), ell_1(t)=-log phi(t),
    m=phi(1/2)>1/3, M=phi(0)<3/4.

The scalar bounds are the actual E2 bounds proved in R80. In particular ell lies between -n log M and -n log m. Direct cancellation of the common f in the Radon–Nikodym derivative gives the FINITE identity

    D(pi||sigma)=log(P/A)+E_pi ell.                  (2)

This is meaningful even if D(pi||uniform Q) is infinite: the log density ratio in (2) is bounded on the support of pi. Since sigma is positive wherever f is, absolute continuity holds.

Let Z=E_pi exp(-ell), so that the captured-source part of P/A is Z and 0<Z<=P/A. The conditional smooth posterior inside Q is sigma_Q=exp(-ell)pi/Z. Thus

    D(pi||sigma_Q)=E_pi ell+log Z,
    D(pi||sigma)=D(pi||sigma_Q)-log sigma(Q),
    sigma(Q)=AZ/P.                                  (3)

These are actual same-law identities. The coordinate chain rule uses sigma's CONDITIONAL distributions given preceding coordinates. In general sigma is not a product: the common f couples its coordinates. Replacing those conditionals by phi's independent marginals would change the joint law.

On P/A<=1/2, (2) gives the valid but only linear bound

    0<=D(pi||sigma)<=n log(1/m)-log 2.                (4)

This is not an upper bound for angular KL against uniform cone measure or for D(pi||product of pi's marginals). The reference sigma itself may have the same severe angular concentration as pi. In particular the latter information quantities may be arbitrarily large despite (4).

## 2. A new all-input paid extreme-likelihood branch

For a real s, suppose at the selected actual scale

    A>=lambda,  P/A<=(1/2)exp(-s).                  (5)

Since E_pi exp(-ell)<=P/A, elementary Markov on exp(-ell) gives

    pi{ell<=s}<=exp(s) P/A<=1/2,
    f*(H 1_{ell>s})_L(x)>=A/2>=lambda/2.            (6)

This is the correct lower duty from an upper likelihood expectation. It does not reverse Markov or infer a KL upper bound from the expectation alone.

For z!=0 define its cube direction omega=z/(2||z||_infinity), lying on the boundary of Q. Because phi decreases with |t|, ell(z)<=ell(omega) on Q. Therefore the ray-decreasing cone kernel

    K_s(z)=H(z) 1_{ell(omega)>s}                     (7)

dominates H 1_{ell>s}. The value at zero is immaterial. Let sigma_cone be normalized cone measure on the cube boundary and delta_s=sigma_cone{ell(omega)>s}. Then integral K_s=delta_s. Its fixed-window radial envelope satisfies

    integral sup_(1<=L<=2)(K_s)_L <=(1+n log 2)delta_s.

One may prove this by integrating along each ray: its indicator occupies an initial radial interval, so the dilation envelope has the usual endpoint mass plus n log 2 times that mass. No convexity of the angular set is required.

For ANY common-source measurable selected scale L(x) in [1,2], (6)-(7), positivity and Tonelli now prove

    lambda |{A_(L(x))>=lambda,
             P_(L(x))/A_(L(x))<=(1/2)exp(-s)}|
       <=2(1+n log 2)delta_s W.                     (8)

The same statement holds for the existence event over all scales by direct domination with the integrable sourcewise kernel envelope. Its measurability follows from joint continuity of A and P and compactness of [1,2]: the joint conditions A>=lambda and P<=exp(-s)A/2 are closed and their projection along the compact scale parameter is closed. No assertion that a non-strict inequality is attained on a dense scale subset is needed. This is a genuine all-input dx payment, not conditional weak-norm averaging or a claim restricted to the numerical sources. It applies in particular at the actual hard first hit A=lambda.

## 3. Compute the angular threshold using only reference geometry

Under cube cone measure a face index and sign are uniform, and the other n-1 coordinates are independent uniform variables on [-1/2,1/2]. Thus EXACTLY

    delta_s=Pr{ell_edge+sum_(j=1)^(n-1) ell_1(U_j)>s},
    ell_edge=-log m, mu=integral_(-1/2)^(1/2) ell_1(t)dt,
    d=ell_edge-ell_1(0)=log(M/m)<=log(9/4).           (9)

This independence is a fact about normalized Lebesgue cone geometry. It is not asserted for pi or for arbitrary f.

For n>=2 let

    s_n=ell_edge+(n-1)mu
                    +(d/2)sqrt((n-1)log(n+2)).      (10)

A direct bounded-mgf argument gives delta_(s_n)<=(n+2)^(-1/2). Indeed a variable in an interval of length d has log-mgf second derivative equal to a tilted variance at most d^2/4. After centering, integrating twice yields log E exp(t(X-EX))<=t^2 d^2/8. Apply this to the independent reference variables and optimize Markov, obtaining exp(-2u^2/[(n-1)d^2]) at deviation u. Substitution of (10) proves the claim. There is no source-posterior concentration assumption.

Combining (8) and (10) pays the actual branch

    P/A<=(1/2)exp(-s_n)

at cost at most 2(1+n log 2)W/sqrt(n+2)=O(sqrt(n))W. For n=1 one may use the exact deterministic cone value in (9); a dimension-independent fixed-window cost is already enough.

The limitation is quantitative and substantial: s_n is of order n, so the threshold is exponentially smaller than the R81 condition P/A<=1/2. At the ordinary threshold s=0, ell is positive on every direction, delta_0=1, and (8) gives only O(n). The unproved intermediate ratio branch is not being declared paid.

## 4. Actual low-smooth first-hit sources with arbitrary angular law

Here is a counterpressure family satisfying the REAL retained minimal R81 conditions. It is not merely a posterior chosen independently of a source. Assume n>=10, fix lambda>0, and use cube polar coordinates y=r omega, r=2||y||_infinity, omega on boundary Q. Lebesgue measure disintegrates as

    dy=n r^(n-1) dr sigma_cone(domega).

Let g be any bounded probability density relative to sigma_cone. Set

    L_0=2^(1/n), L_1=3^(1/n),
    f(r omega)=(3lambda/4) r^(2n) g(-omega) 1_{r<=L_1}. (11)

This is a nonnegative L1 density, with total mass W=27lambda/4. At receiver x=0,

    A(L)=lambda L^(2n)/4 for L<=L_1,
    A(1)=lambda/4, A(L_0)=lambda, A(L_1)=9lambda/4.  (12)

Thus L_0 is the actual first level contact in [1,2], and the maximal event is strict after it. The source is not an atom or a fictitious conditional law. Moreover the smooth bound is uniform in ALL receivers and in ALL L in [1,2]:

    P_1(L,x)<=M^n L^(-n)W
       <(27/4)(3/4)^n lambda<lambda/2, n>=10.       (13)

Hence the actual minimal anchor and full-window smooth gate hold with strict margins. At the hard first contact, the posterior cube direction has density g, independently of its radius rho=2||z||_infinity, whose density is 3n rho^(3n-1), 0<rho<1. Its hard source age -log rho is Exp(3n), satisfying the first-hit age domination without restricting the angle.

For this construction the actual hard posterior density relative to uniform Q is 3rho^(2n)g(omega), so exactly

    D(pi||uniform Q)=log 3-2/3+D(g||sigma_cone).      (14)

This quantity has no input-uniform upper bound even at fixed n>=10. The finite same-source likelihood KL in (2) is not contradicted: the smooth posterior also contains the same angular concentration.

For the principal correlated example choose 0<delta<=1/8 and g uniform on the INTERIOR-FACET patch

    omega_1=1/2,  omega_j in [1/8,1/8+delta], j>=2.

Its cone measure is delta^(n-1)/(2n), so its angular KL is log(2n)+(n-1)log(1/delta). This patch deliberately stays away from the corners: concentrating at a corner could fall in the extreme branch already paid above. Here |Z_j-Z_1/4|<=delta under pi. Each coordinate marginal has a density bounded by 24n, since conditional on omega_j>=1/8 it is the scaled radius with density at most 3n/omega_j. Under the PRODUCT of these actual marginals the near-line event has probability at most (48n delta)^(n-1). Data processing to this event gives

    D(pi||product_j pi_j)>=(n-1)log(1/(48n delta))    (15)

when the right side is positive.

This remains arbitrarily large as delta tends to zero. Crucially the captured-source likelihood itself is too LARGE to satisfy the new extreme cutoff. On (-1/2,1/2), phi is positive and concave: phi''(x)=w'(x+1/2)-w'(x-1/2)<0. Therefore ell_1=-log phi is convex. Jensen on [0,1/2] gives mu>=ell_1(1/4). Every captured z in this patch has

    ell(z)<=ell_edge+(n-1)ell_1(1/4)
           <=ell_edge+(n-1)mu<s_n.

Consequently, without ignoring outside-source contributions,

    P/A>=E_pi exp(-ell)
       >=exp[-ell_edge-(n-1)mu]>(1/2)exp(-s_n).      (16)

Thus this actual first-hit construction lies in the unproved intermediate likelihood range, with arbitrary angular KL AND arbitrary coordinate dependence. The strict lower likelihood margin in (16), as well as the ordinary upper gate, persists on a sufficiently small receiver neighborhood by continuity. This blocks an automatic entropy closure even after the extreme branch has been legitimately removed.

## 5. Positive-volume persistence and what the example does not refute

The construction is not confined to a null receiver. Fix n and any finite desired information level, then choose a sufficiently small positive delta in the preceding patch construction. At x=0 the anchor and smooth margins are strict. Translation continuity of f in L1 implies uniform continuity of A_x(L) in x for L in the compact window. The strictly increasing profile (12) brackets its first contact on both sides of L_0; therefore the actual first contacts L_x converge to L_0 as x tends to zero, with the anchor and strict maximal event persisting. The smooth gate (13) already holds globally in x.

In displacement coordinates, pi_x(z)=f(x-L_x z)H(z)/lambda converges to pi_0 in total variation, by strong continuity of translations and dilations on L1. Products of its marginals converge in total variation as well. For the wider near-line event |Z_j-Z_1/4|<=2delta, pi_0 assigns mass one, while its product marginal probability is at most (96n delta)^(n-1). On a sufficiently small open receiver neighborhood, the first probability remains, say, at least 0.99, and the second is at most twice that bound. Binary KL is at least p log(1/q)-log 2, so any fixed finite lower target in (15) persists after making delta sufficiently small and then taking that neighborhood. The same argument with an enlarged angular patch preserves arbitrarily large angular KL against cone measure. The same neighborhood can retain the strict intermediate likelihood condition (16), by continuity of P/A at the continuous selected first contact.

The neighborhood has positive Lebesgue measure but no uniform lower size is asserted. It can shrink sharply as delta decreases. Consequently this example does NOT disprove the desired weak estimate or a paid exceptional-angle theorem; it disproves pointwise or automatic conditional-information bounds from the stated gates. No exact scaling law equating receiver volume with angular patch mass has been proved. Establishing such a mass-weighted geometric payment is one of the remaining tasks.

## 6. Numerical evidence and remaining work

The guard has three true E2 stages. It computes the scalar likelihood mean/range and the paid angular threshold by quadrature; checks the exact first-hit source profile and strict full-window smooth upper bound; and probes the actual correlated cone source using its radial/angular sampling law. Machine sampling and Simpson quadrature are diagnostics, not exact probabilities or interval certificates. The analytic proofs establish (8), (10) and the counterpressure family independently.

The new general paid branch is (8)-(10). What remains is the ratio range between exp(-s_n)/2 and 1/2, together with the geometric receiver budget. Neither the same-source KL identity nor the arbitrary-angle examples resolve that range.


For the three reference-tail counts, the reported conservative Hoeffding intervals are clipped to [0,1] and use radius sqrt(log(2/(0.05/3))/(2*192)); Bonferroni makes their simultaneous confidence at least 95% under independent ideal draws. For the 12 smooth means, each sample lies in [0,B_L], B_L=(27/4)(3/4)^n L^(-n). Their clipped intervals use radius B_L sqrt(log(2/(0.05/12))/(2*96)), again with simultaneous confidence at least 95% for that family. Independence between different stages or scales is not needed for the union bound. These broad intervals quantify sampling uncertainty of the quadrature-defined observables, not quadrature bias, machine-randomness certification, or uncertainty in the analytic proofs. In particular 0/192 is not evidence of a zero tail probability.

```python
import math, random
from fractions import Fraction
from functools import lru_cache

@lru_cache(None)
def phi(x,N=400):
    x=abs(x)
    def g(t):
        if t==0: return 0.
        if x<=.5:
            return t*(2-math.exp(-(x+.5)/t)-math.exp(-(.5-x)/t))
        return t*(math.exp(-(x-.5)/t)-math.exp(-(x+.5)/t))
    return (g(0)+g(1)+sum((4 if j%2 else 2)*g(j/N) for j in range(1,N)))/(3*N)
def simpson(f,a,b,N=400):
    return (b-a)*(f(a)+f(b)+sum((4 if j%2 else 2)*f(a+(b-a)*j/N) for j in range(1,N)))/(3*N)
M=phi(0); m=phi(.5)
mu=simpson(lambda x:-math.log(phi(x)),-.5,.5)
d=math.log(M/m); edge=-math.log(m)
assert 1/3<m<M<3/4 and 0<d<math.log(9/4)
checks=1
print('E2_quad','M',format(M,'.10g'),'m',format(m,'.10g'),'mu',format(mu,'.10g'),'range',format(d,'.10g'))
rng=random.Random(8201)
# Bonferroni-Hoeffding sampling intervals: simultaneous 95% within each family.
alpha_tail=.05/3
alpha_mean=.05/12
rad_tail=math.sqrt(math.log(2/alpha_tail)/(2*192))
rad_mean_unit=math.sqrt(math.log(2/alpha_mean)/(2*96))
print('sampling_CI_radii','tail_probability',format(rad_tail,'.8g'),
      'mean_fraction_of_known_range',format(rad_mean_unit,'.8g'))
for n in [10,16,32]:
    L0=2**(1/n); L1=3**(1/n); lam=1.; W=27/4
    # Exact rational all-receiver, all-window smooth upper certificate.
    bound=Fraction(27,4)*Fraction(3,4)**n
    assert bound<Fraction(1,2)
    assert abs(L0**(2*n)/4-1)<1e-12
    assert abs(L1**(2*n)/4-9/4)<1e-12
    assert .25<.5 and L0<L1<2
    checks+=4
    s=edge+(n-1)*mu+(d/2)*math.sqrt((n-1)*math.log(n+2))
    u=s-edge-(n-1)*mu
    tailbound=math.exp(-2*u*u/((n-1)*d*d))
    assert abs(tailbound-1/math.sqrt(n+2))<1e-12
    checks+=1
    delta=1/(192*n)
    angle_KL=math.log(2*n)+(n-1)*math.log(1/delta)
    TC_lower=(n-1)*math.log(1/(48*n*delta))
    assert TC_lower>0 and angle_KL>TC_lower
    assert mu>=-math.log(phi(.25))-1e-10
    assert m*phi(.25)**(n-1)>.5*math.exp(-s)
    checks+=3
    # Actual continuous source law: radial power 3n, uniform facet patch.
    source_values={L:[] for L in [1.,L0,L1,2.]}
    likelihoods=[]
    for j in range(96):
        omega=[.5]+[.125+delta*rng.random() for _ in range(n-1)]
        radial=L1*rng.random()**(1/(3*n))
        for L,values in source_values.items():
            values.append(math.prod(phi(radial*z/L) for z in omega))
        # Actual hard posterior radial law on the captured unit cube.
        rho=rng.random()**(1/(3*n))
        likelihoods.append(math.prod(phi(rho*z) for z in omega))
    smooth_diag={format(L,'.6g'):W*sum(vals)/len(vals)/(L**n) for L,vals in source_values.items()}
    for value in smooth_diag.values():
        assert 0<value<float(bound)
        checks+=1
    # Finite empirical same-law Gibbs identity; not a continuous-KL certificate.
    Z=sum(likelihoods)/len(likelihoods)
    meanell=sum(-math.log(v) for v in likelihoods)/len(likelihoods)
    empiricalKL=sum(math.log(Z/v) for v in likelihoods)/len(likelihoods)
    assert abs(empiricalKL-(meanell+math.log(Z)))<1e-12 and empiricalKL>=-1e-12
    checks+=1
    reference_tail=0
    for j in range(192):
        v=edge+sum(-math.log(phi(rng.uniform(-.5,.5))) for _ in range(n-1))
        reference_tail+=v>s
    phat=reference_tail/192
    tail_CI=(max(0.,phat-rad_tail),min(1.,phat+rad_tail))
    mean_CI={}
    for L in source_values:
        key=format(L,'.6g')
        known_range=float(bound)/(L**n)
        radius=known_range*rad_mean_unit
        mean_CI[key]=(max(0.,smooth_diag[key]-radius),
                      min(known_range,smooth_diag[key]+radius))
    print('stage',n,'exact_global_smooth_bound',format(float(bound),'.8g'),
          's_quad',format(s,'.8g'),'paid',format(2*(1+n*math.log(2))/math.sqrt(n+2),'.8g'),
          'angle_KL',format(angle_KL,'.8g'),'TC_lower',format(TC_lower,'.8g'),
          'reference_tail_MC',str(reference_tail)+'/192','tail_95pct_simultaneous_CI',tail_CI)
    print('actual_cone_source_MC_P1_over_lambda',smooth_diag,
          'posterior_Gibbs_MC',format(empiricalKL,'.8g'))
    print('smooth_mean_95pct_simultaneous_sampling_CI',mean_CI)
print('PASS',checks,'assertions; exact rational bounds separated from E2 quadrature/MC diagnostics')
```

Actual stdout:

```text
E2_quad M 0.5567912714 m 0.3903080328 mu 0.6870745341 range 0.3552541775
sampling_CI_radii tail_probability 0.11165763 mean_fraction_of_known_range 0.17931853
stage 10 exact_global_smooth_bound 0.38011622 s_quad 7.9645018 paid 4.5792374 angle_KL 71.036456 TC_lower 12.476649 reference_tail_MC 1/192 tail_95pct_simultaneous_CI (0.0, 0.1168659636749043)
actual_cone_source_MC_P1_over_lambda {'1': 0.01052002586390729, '1.07177': 0.0057864357488304225, '1.11612': 0.004064565595704202, '2': 1.671320555443856e-05} posterior_Gibbs_MC 0.00064045701
smooth_mean_95pct_simultaneous_sampling_CI {'1': (0.0, 0.07868190923431738), '1.07177': (0.0, 0.03986737743403548), '1.11612': (0.0, 0.026785193385840914), '2': (0.0, 8.327754478335465e-05)}
stage 16 exact_global_smooth_bound 0.067652521 s_quad 12.416522 paid 5.699448 angle_KL 123.917 TC_lower 20.794415 reference_tail_MC 0/192 tail_95pct_simultaneous_CI (0.0, 0.11165763034157097)
actual_cone_source_MC_P1_over_lambda {'1': 0.00029462398703381, '1.04427': 0.00015769998641564718, '1.07108': 0.00010921349436007608, '2': 7.640993632094604e-09} posterior_Gibbs_MC 0.00048406147
smooth_mean_95pct_simultaneous_sampling_CI {'1': (0.0, 0.012425974811503768), '1.04427': (0.0, 0.006223375398650634), '1.07108': (0.0, 0.004152997102516724), '2': (0.0, 1.9275071690586717e-07)}
stage 32 exact_global_smooth_bound 0.00067805387 s_quad 24.097307 paid 7.9509179 angle_KL 274.57905 TC_lower 42.975125 reference_tail_MC 0/192 tail_95pct_simultaneous_CI (0.0, 0.11165763034157097)
actual_cone_source_MC_P1_over_lambda {'1': 1.9982358660371435e-08, '1.0219': 1.045683207899166e-08, '1.03493': 7.154597954756255e-09, '2': 9.376908896804806e-18} posterior_Gibbs_MC 0.00010782878
smooth_mean_95pct_simultaneous_sampling_CI {'1': (0.0, 0.00012160760766617523), '1.0219': (0.0, 6.080426948583652e-05), '1.03493': (0.0, 4.053636303379295e-05), '2': (0.0, 2.8318701969591018e-14)}
PASS 40 assertions; exact rational bounds separated from E2 quadrature/MC diagnostics
```

Guard SHA256: `6470bb790624b35cba4f0fb1187c2a58a4de83f3a4dfa10b92451fbb6c56aec8`.


# R82: oriented first-hit sheets, their debts, and a retained negative-orientation cube

**Status.** The general square-root weak (1,1) bound remains unproved. This component gives two exact orientation-debt identities and a genuine fixed-window counterexample to positive orientation or free signed cancellation. The example passes BOTH the anchor and the full-continuum smooth gate in every dimension n>=2. A global lacunary example is separately scoped: it rules out unqualified signed-degree bounds, but not a fixed-window degree theorem. A valid source-ray root-count payment costs order n and does not pay inverse Jacobians.

Updated E01 occupation-flow and M04 selection skills were read; their warnings are retained. No occupation-LP equivalence, fictional source martingale, or general selection theorem is imported. The proofs below are direct identities. R81 supplies the same actual selector's generic-level regularity and its positive source-occupation formula.

## 1. The actual common window selector and what first crossing says

Use half-side radius r, A_r f(x)=(2r)^(-n) integral_(x+[-r,r]^n) f, with f>=0 in L1 and W=||f||_1. The physical side-length window is [1,2], hence r in [a,b]=[1/2,1]. On receivers with A_a f<lambda/2 and sup_[a,b] A_r f>lambda, let

    r(x)=inf{s in [a,b]:A_s f(x)>lambda}.

Retain any additional measurable smooth gate, in particular sup_[a,b] P_1 f<=lambda/2. Initially use smooth compact inputs and generic lambda; as justified in R81, the selector is locally C1 at almost every retained receiver, A_r f=lambda, and the partial radial derivative A_r'>0. The strict anchor and compact root gap ensure this is the same first branch, not a private source-ray first crossing. The explicit box examples below are locally smooth in their overlap variables, so these formulas apply directly there without invoking an approximation.

For captured source y, set z=(x-y)/r, D_y=1-z dot grad r. Implicit differentiation gives

    grad r=-(grad_x A_r f)/(partial_r A_r f),
    D_y=[partial_r A_r f+z dot grad_x A_r f]/partial_r A_r f.   (1)

The denominator is positive at a regular first crossing. The numerator is the derivative of A_s f(y+s z) at s=r, which moves the receiver as well as its radius. First crossing at a fixed receiver does not fix this numerator's sign. Likewise A_a f(x)<lambda/2 does not say A_a f(y+a z)<lambda/2: these are different physical receivers.

## 2. Two exact orientation debts; degree is not inverse-Jacobian occupation

Let E be a measurable subset of regular selected receivers. Start on finitely many bounded regular patches with r bounded below and grad r bounded. All identities are then absolutely integrable. Positive quantities pass to exhaustion; signed identities require absolute integrability, or explicit separate positive/negative terms. All preimage sums omit D_y=0. Their omitted source-weighted domain is null by the R81 affine-hyperplane/Tonelli argument.

Write pi_x(dy)=f(y)1_capture dy/[lambda(2r)^n], and m_x=integral z pi_x(dy). The positive target is T=lambda|E|. Define

    S=2^(-n) integral f(y) integral_Q sum_(x in E: x=y+r(x)z) 1/D_y(x) dz dy,
    N=lambda integral_E pi_x{D_y<0} dx,        Q=[-1,1]^n.

Using the signed change of variables on each noncritical chart gives the exact budget

    T=S+2N.                                                   (2)

Here S is SIGNED inverse-Jacobian occupation, not topological degree. A bound on a signed sum alone is useless until N is paid. In particular N can equal the whole T even on the retained fixed-window event (Section 4).

For genuine oriented degree, define d_E(y,z)=sum_preimages sign(D_y). Multiplying the R81 area identity by D_y gives

    G=2^(-n) integral f(y) integral_Q d_E(y,z) dz dy
      =lambda integral_E integral D_y pi_x(dy) dx,
    T=G+lambda integral_E grad r(x) dot m_x dx.                (3)

This second debt is a barycentric derivative term. A degree bound concerns G, not T. Replacing 1/|D| by sign(D) silently discards precisely the extra term in (3). Finite source mass does not assign its sign or a square-root payment.

There is also an exact divergence interpretation. For fixed y,

    div_x[(x-y)/(n r(x)^n)]=r(x)^(-n)D_y(x).                   (4)

On a bounded piecewise C1 capture domain A_y=E intersect {|x-y|_infty<r(x)}, the integral of the right side is the boundary flux of this vector field. The boundary includes receiver-event boundaries, capture boundaries, and cuts between first-hit branches. For piecewise selector branches, internal boundaries contribute the jump in the vector field; those terms do not cancel unless the traces agree. A divergence argument which keeps only the two radius endpoints has omitted these actual boundaries. No finite-perimeter assertion is made for an arbitrary L1 selector; (4) is used on regular patches, with all cut terms retained.

## 3. What a full source-ray degree actually controls

For fixed y and z in Q define B(s)=A_s f(y+s z). The sets y+s(z+Q) are nested as s increases, because z+Q is convex and contains the origin. Thus their captured mass M(s)=(2s)^n B(s) is nondecreasing. For smooth input,

    B'(s)>=-n B(s)/s.                                        (5)

Suppose a level nu has only simple roots on [a,b] and neither endpoint is at level nu. Its complete ray level set has finite oriented root count

    sum_(B(s)=nu) sign B'(s)=1_{B(b)>nu}-1_{B(a)>nu}.            (6)

A selected first-hit root satisfies sign B'=sign D_y by (1). But the selected first sheet is only a subset of the complete ray level set. Exactly,

    selected degree = endpoint difference - omitted-root degree. (7)

The omitted roots include crossings whose receiver already crossed earlier at a fixed center, and roots removed by the anchor or smooth gate. Paying the anchor at selected x does not remove omitted roots at the different ray receiver y+a z. Formula (7), not a free degree-one theorem for the selected sheet, is the correct completion identity.

A valid coarse payment follows by one-dimensional level coarea. For any lambda>0,

    integral_lambda^(2lambda) N_ray^-(nu) dnu
      <= integral_a^b n B(s)/s 1_{lambda<B(s)<2lambda} ds
      <=2n lambda log(b/a).

The complete upward count has integral at most lambda+2n lambda log(b/a), by (6). Counts of either sign on the selected sheet are bounded by the corresponding complete counts. After integrating f(y)dy and normalized dz/2^n, these bounds acquire only the factor W. They are all-input statements on this regular class, but cost order n on [1/2,1]. More importantly, these are root COUNTS. The occupation has weights 1/|D_y|. Level coarea for those weights leaves partial_r A_r, because |B'|=partial_r A_r |D_y| on the selected sheet. Thus (5) does not provide a free inverse-Jacobian payment. This is a repaired, explicit root-count interface, not a weak maximal estimate.

## 4. Actual dense cube with negative orientation after both full-window gates

Take lambda=1, L=41/100, d=2/5, and

    f_n=4^n 1_[0,L]^n,       x_0=(-d,...,-d),       n>=2.

For r<=d there is no captured mass. In the partial-overlap range d<r<d+L,

    A_r f_n(x_0)=[2(r-d)/r]^n.

Its actual global first strict hit is r_*=2d=4/5, so it is also the first-window hit. The anchor is A_(1/2)=(2/5)^n<1/2. The input mass is W=(41/25)^n; this is a genuine positive L1 input, with no atomic source or receiver law.

More generally write x_j=-d_j near x_0, so every selected cube still partially intersects every input coordinate interval. Put

    D_rad=sum_j 1/(r-d_j)-n/r =sum_j d_j/[r(r-d_j)]>0.

Implicit differentiation of 4^n product_j(r-d_j)/(2r)^n=1 gives

    partial_(x_j)r=-1/[(r-d_j)D_rad],
    D_y=-sum_j y_j/[r(r-d_j)D_rad]<0                           (8)

for almost every captured source y in product_j[0,r-d_j]. This is an exact open-neighborhood formula, not a claim only at a diagonal receiver. At x_0, grad_j r=-2/n and D_y=-(sum_j y_j)/(nd). The posterior is uniform on [0,d]^n, hence

    pi_x0(D_y<0)=1,       integral D_y pi_x0=-1/2,
    grad r dot m_x0=3/2.                                     (9)

Therefore N=T in (2) throughout a sufficiently small receiver neighborhood. At the diagonal receiver the local density of G is -1/2 and that of the barycentric debt in (3) is 3/2. Signed occupation would have the opposite sign from every unit of positive target mass.

### Full-continuum smooth gate: rigorous rational envelope

Here h=1_[-1/2,1/2], w(t)=integral_0^1 exp(-|t|/q)dq, phi=h*w, and P_1 uses phi tensor n. Let ell=2r in [1,2]. By separation,

    P_1 f_n(x_0;ell)=p(ell)^n,
    p(ell)=(4/ell) integral_0^L phi((d+y)/ell)dy.

The function phi is even and nonincreasing on the positive axis: phi'(t)=w(t+1/2)-w(t-1/2)<=0 for t>=0. For 0<=t<=1/2,

    phi(t)=integral_0^1 q[2-exp(-(1/2+t)/q)-exp(-(1/2-t)/q)]dq.  (10)

The integrand in (10) is increasing in q: its derivative is the sum of two terms 1-(1+s)exp(-s)>=0. For t>1/2 we use the safe upper cap phi(t)<=phi(1/2), rather than an incorrect continuation of (10).

For an ell cell [ell_lo,ell_hi], positivity and monotonicity give

    p(ell)<= (4/ell_lo) integral_0^L phi((d+y)/ell_hi)dy.        (11)

Left Riemann sums in y and right Riemann sums in q both give upper bounds. Every exponential in the latter is replaced by the exact rational lower bound

    exp(-s)>= [1-u+u^2/2-u^3/6]^32, u=s/32, 0<=u<1;
    exp(-s)>=0 otherwise.                                   (12)

Indeed the cubic is the odd Taylor lower bound for exp(-u), is positive on [0,1], and taking the 32nd power preserves the inequality. Thus the guard's computed values are rigorous rational upper bounds on the entire continuum of ell, not grid maxima. With N subdivisions on each axis, stages N=8,16,32 give upper bounds approximately .746198, .699553, .676809. Exact rational comparison at N=32 proves

    sup_(1<=ell<=2) p(ell)<7/10,
    sup_window P_1 f_n(x_0)<(7/10)^n<=49/100<1/2, n>=2.       (13)

This is precisely the full-window gate, not merely a gate at r_*. If the auxiliary endpoint uses alpha=(1-epsilon)^n, choose epsilon=1/(128n^2); then alpha>=127/128, and 49/100<127/256<=alpha/2 as well. Joint continuity on the compact scale window preserves the strict smooth gate on an open neighborhood of x_0. The hard anchor, first-root partial-overlap margin, and negative-orientation formula (8) persist there too. This yields positive Lebesgue receiver volume satisfying the R81 minimal anchor and continuous-P_1 gates. No claim is made that it survives an optional additional Q_cont deletion or other later exceptional set. Dimension one is deliberately excluded from the full-window retained claim; the present envelope only gives the insufficient bound p<7/10 there.

For a concrete source-ray anchor mismatch, already in the one-dimensional factor let x=-2/5, y=1/5, r=4/5, z=-3/4. At the selected receiver A_(1/2)=2/5. At the transported lower-end receiver y+(1/2)z=-7/40, however, A_(1/2)=13/10>1. Thus the fixed-receiver anchor cannot be silently transported along a captured source ray. This factor calculation explains the geometry; the retained negative-orientation theorem uses n>=2 and (13).

## 5. Global lacunary signed degree: useful guard, not a fixed-window obstruction

Retain the R81 genuine input f_N=4 1_[0,1]+4 sum_(k=1)^N1_[100^k,2*100^k], at level 1. For y in [0,1] and z in [2/5,9/20], the R81 exact first-hit branches are

    M_(k-1)=4(1+sum_(j<k)100^j), B_k=100^k-M_(k-1)/4,
    x_k=[y+2z B_k]/(1+2z), r_k=2(B_k-y)/(1+2z).

All old sources are captured at the root, the kth block is partially captured, and no later block is captured. Before kth-block entry the average is <=M_(k-1)/[2(x_k-right_previous)]<1; after entry the increasing upper envelope [M_(k-1)+4(x+r-100^k)]/(2r) first reaches one at r_k and is exact nearby. Hence these are genuine global first hits.

At any regular first hit for this input, boundary densities are each 0 or 4. The implicit formula gives r' in {-2,0,2}; both endpoints zero would give a negative radial derivative and cannot be a first crossing. Therefore for every possible captured preimage with z in [2/5,9/20], D=1-zr'>=1/10>0. The N displayed branches yield signed degree at least N with NO opposite-sign preimage cancellation on this band. Branch jumps when an earlier root disappears account for the necessary resets; the full source-ray level set and its omitted roots still obey (6).

These branches occur at lacunary physical scales. This example DOES NOT refute a signed-degree bound in the retained window [1/2,1], nor does it assert that the smooth gate holds. Its role is to prohibit applying a global degree-one assertion to the first sheet without accounting for branch cuts. The actual fixed-window obstruction is Section 4: the negative inverse-Jacobian debt can equal the entire retained target mass.

## 6. What remains to be proved

A usable orientation argument must bound either the negative source occupation N in (2), or the barycentric derivative debt in (3), together with the chosen signed term, using the SAME retained selector and source mass W. The dense cube shows that these debts cannot be dismissed as rare after either gate. Formula (7) additionally requires payment of omitted ray sheets or branch-boundary flux; the first-crossing property at fixed centers does not remove them. The nested-source-ray estimate (5) provides only the explicit order-n count payment above, without inverse-Jacobian control.

The surviving possible route is a joint signed-plus-debt estimate which uses correlations with input mass rather than separate total variations or per-source bounds. No such square-root estimate is established here. In particular, none of these identities closes the general target.

## 7. Three-stage exact guard

The guard below uses Fraction throughout all certificate comparisons. Floating values are only human-readable summaries of exact rational upper bounds. It verifies the actual dense-cube first-root/anchor/orientation identities, checks the global-only lacunary first-hit and signed-degree bands at growing source counts, and performs three progressively finer full-continuum smooth-gate envelopes. It neither samples dx as a probability surrogate nor claims a new weak bound from finite checks.

```python
from fractions import Fraction as F

def elo(s):
    u=s/32
    if u>=1: return F(0)
    return (1-u+u*u/2-u*u*u/6)**32

def phi_upper(t,N):
    t=min(t,F(1,2)) # phi decreases; upper cap beyond the hard half-side
    total=F(0)
    for j in range(1,N+1):
        q=F(j,N)
        total+=q*(2-elo((F(1,2)+t)/q)-elo((F(1,2)-t)/q))
    return total/N

# Stage 1: genuine dense input, regular first hit and signed source Jacobian.
L=F(41,100);d=F(2,5);r=2*d
for n in (1,2,4,8,16,64,256):
    assert d<r<d+L and (2*(r-d)/r)**n==1
    assert (F(2,5))**n<F(1,2)
    grad=-F(2,n)
    for y in (F(1,10),F(1,5),F(3,10)):
        z=(-d-y)/r
        D=1-n*z*grad
        assert D==-y/d<0
    assert -F(1,2)==-n*F(d,2)/(n*d)
    eps=F(1,128*n*n)
    assert (1-eps)**n>=F(127,128)
# Exact source-ray transported-anchor mismatch.
y=F(1,5);z=F(-3,4);a=F(1,2)
assert y+a*z==F(-7,40)
assert 4*(y+a*z+a)/(2*a)==F(13,10)>1
assert F(2,5)<F(1,2)
print('stage1 actual dense first hit and negative orientation: 7 dimensions; anchor mismatch exact')

# Stage 2: global-only lacunary inputs, NOT the retained fixed window.
checks=0
for N in (1,4,16,64):
    for y in (F(0),F(1,3),F(1)):
        previous_x=F(-1)
        for k in range(1,N+1):
            R=100**k;old=[100**j for j in range(1,k)]
            M=F(4)*(1+sum(old));right=F(1) if k==1 else F(2*old[-1])
            B=F(R)-M/4
            for z in (F(2,5),F(9,20)):
                x=(y+2*z*B)/(1+2*z);r=2*(B-y)/(1+2*z)
                assert x-y==z*r and x>right and x<R
                assert x-r<0 and R<x+r<2*R
                assert M+4*(x+r-R)==2*r
                assert M/(2*(x-right))<1
                assert M+4*x-4*R<0 and r>R-x
                for rp in (F(-2),F(0),F(2)):
                    assert 1-z*rp>=F(1,10)
                assert previous_x<x
                previous_x=x;checks+=1
    print('stage2 global-only source count',N,'signed degree >=',N)
print('stage2 exact branch checks',checks)

# Stage 3: every bound covers ALL physical side-lengths ell in [1,2].
for N in (8,16,32):
    bounds=[]
    for k in range(N):
        lo=1+F(k,N);hi=lo+F(1,N)
        val=4*L/lo/N*sum((phi_upper((d+L*F(j,N))/hi,N)
                          for j in range(N)),F(0))
        bounds.append(val)
    upper=max(bounds)
    print('stage3 continuum envelope N',N,'upper',float(upper),'below .7',upper<F(7,10))
    if N==32:
        assert upper<F(7,10)
        assert upper**2<F(49,100)<F(127,256)<F(1,2)
print('PASS: full retained negative orientation for every n>=2; square-root target unproved')
```


# R82 parent: the correct common posterior entropy and component normalization

Status: exact all-input identities and a normalization obstruction, not a new weak bound. The new useful allocation theorem is in the transport component; this section checks which entropy quantity could legitimately enter that allocation problem. The updated D04 skill and its method/provenance/interface were read. E03 was also read: no tree budget is invoked because different receiver cubes do not define a common mass-conserving tree.

## 1. One actual joint probability law

Let f>=0 be integrable with W>0. Let E have positive finite Lebesgue measure, and let L(x) in [1,2] be a measurable actual hard level contact satisfying

    integral_{Q(x,L(x))} f(y)dy = lambda L(x)^n,

where Q has full side L. The R81 retained set and common first-contact selector satisfy this premise. Set P0(dy)=f(y)dy/W, U(dx)=1_E dx/|E| and

    pi_x(dy)=f(y)1_Q dy/[lambda L(x)^n],
    P(dx,dy)=U(dx)pi_x(dy), C=lambda|E|/W.

This is the same captured source law at the original Lebesgue receiver, not an independent-coordinate surrogate. Its Radon–Nikodym density relative to U tensor P0 is

    dP/d(U tensor P0) = W 1_Q/[lambda L(x)^n].       (1)

In particular W>=lambda L(x)^n and the logarithm on its support is between zero and log(W/lambda). Thus joint relative entropy is finite. All spaces are standard Borel, the displayed kernels are measurable, and D04's KL chain rule applies without subtracting infinite quantities. It gives the exact identity

    J := log(W/lambda)-n E_U log L
       = I_P(X;Y)+D(P_Y || P0).                    (2)

Here I_P is D(P || U tensor P_Y). The two right-hand terms are nonnegative and finite. There is no claim that either is bounded by dimension alone.

Define the canonical source occupation

    I(y)=integral_E 1_Q(x)(y) L(x)^(-n)dx.

Tonelli and the contact equation give integral f I=lambda|E|. The source marginal satisfies

    dP_Y/dP0=I(y)/C,
    D(P_Y||P0)=integral [I(y)/C] log[I(y)/C] P0(dy). (3)

Zero occupation is assigned the usual 0 log0=0. This source entropy is a normalized convex moment of the SAME occupation whose first moment is the desired weak ratio C. Formula (3) is not an estimate for that first moment.

For the fixed physical window the elementary pointwise bound is I(y)<=1+n log2: dominate each chosen kernel by sup_{1<=L<=2} H_L and integrate its radial density. The inner unit cube contributes1 and radii 1<2||x-y||infinity<2 contribute n log2. Consequently

    0<=D(P_Y||P0)<=log[(1+n log2)/C].              (4)

The RHS is well-defined because C<=1+n log2 by the same elementary integration. This O(n) strong payment does not imply C=O(sqrt(n)); applying (4) in reverse would be a logical error. One needs geometry of feasible allocations or a proved inequality linking additional structure to C.

## 2. Independent spatial components: raw mutual information grows freely

Take finitely many translated, disjoint copies of a compactly supported actual input and its chosen receiver subset. Separate them far enough that every selected cube of side at most2 meets only its own copy. With m identical copies, the source and receiver component labels agree and each is uniform. The exact source occupation in each copy is unchanged, as is C. But the mass W becomes mW and the distribution of L remains unchanged. Hence

    J_m=J_1+log m,
    D(P_Y^{(m)}||P0^{(m)})=D(P_Y^{(1)}||P0^{(1)}),
    I_m(X;Y)=I_1(X;Y)+log m.                       (5)

This is a genuine first-contact construction because remote copies cannot enter any earlier or selected cube. It does not assert that the noncompact smooth E2 gate is unchanged: its remote tails need a separate estimate before using such a gate. Equation (5) already excludes using a dimension-only upper bound for raw mutual information on the full actual first-contact class. It does not exclude a restricted gated theorem.

More generally, for source-disjoint components with W_j, |E_j| and common lambda, define a_j=|E_j|/|E| and b_j=W_j/W. Assuming finitely many positive components and no cross captures, the exact decomposition is

    D(P_Y||P0)=D(a||b)+sum_j a_j D(P_{Y|j}||P0_j),
    I(X;Y)=H(a)+sum_j a_j I_j(X;Y),
    C=sum_j b_j C_j, a_j=b_j C_j/C.               (6)

The ordinary label entropy H(a) can grow even when all component weak ratios equal the same constant. By contrast source relative entropy is unchanged under identical replication. A prospective entropy payment therefore has to specify a common geometric component construction and its source weights; simply deleting the label entropy without a legitimate decomposition is also invalid. The finite entropy identities in (6) follow by substituting the component product measures, or by D04 with the actual component label. Countable or non-disjoint components are not asserted here.

## 3. Actual positive L1 first-hit diagnostic

Take n=1, lambda=1, f=4 1_[0,1] and receivers x=-d with a=3/8<d<b=1/2. For r<=d capture is zero; for d<r<=2d the hard average is 2-2d/r, first equaling1 at r=2d. Thus L=4d in (3/2,2) is the global and window first level contact, with a strict crossing immediately afterwards. The anchor of side1 is 2-4d<1/2. The chosen receiver subset E has length1/8, W=4, C=1/32. No low-smooth-gate claim is made for this fixture.

At the contact the captured interval is [0,d], and pi_d is uniform on [0,d]. If d is uniform on (a,b), its source marginal density on [0,b] is

    rho(y)=log[b/max(a,y)]/(b-a).

Here P0 is uniform on [0,1]. Therefore

    J= -[(b log b-b)-(a log a-a)]/(b-a),
    D(P_Y||P0)=integral_0^b rho log rho,
    I(X;Y)=J-D(P_Y||P0).                           (7)

All formulas are analytic consequences of Fubini; the reported decimal values of the last two integrals are numerical, without interval certification. Copies translated by10j obey (5) on the displayed receiver subsets. They retain actual global first contacts since all selected radii are below1, while other copies are at distance greater8.

## 4. Three-stage verification and limits

Run `python3 -B entropy_probe.py`; it writes `entropy_results.json`. Seed820411. Stage1 checks120 finite common joint laws with exact rational normalization and floating logarithms; these are algebraic tests and not asserted to be spatial cube realizations. Stage2 checks333 exact rational points in the displayed positive L1 first-contact branch, including earlier-radius exclusion and the paid anchor. Its continuum posterior integral is recomputed with128,512,2048,8192 panels, with the last source entropy values differing by4.31e-9. Stage3 checks component replication on exact finite joint probabilities for1,2,4,8,16 copies. The continuum replication theorem is proved above independently of those finite tests.

Actual final diagnostics: J=0.830100963204603, source entropy approximately0.7605568094317425, mutual information approximately0.0695441537728605. These values do not estimate a dimension exponent. The unresolved goal remains a uniform weak estimate for the retained receiver set; neither (2), (4), nor removal of redundant labels proves it.


# R82 exact finite-window transport

The guard constructs 123,599 complete receiver cells for 17 finite atomic-source fixtures and certifies 34 optimal transport constants. It checks 1,402 nonempty source-subset Hall inequalities in total, then independently saturates every receiver demand by exact integer maximum flow. Optimal common-source transport improves the fixed captured-source posterior in several cases. Restricting transport to fresh sources can increase the optimal constant. These are finite-grid, original-Lebesgue-volume results, not a continuum first-hit or general weak-bound proof.

## Actual finite physical geometry

The physical input is mu=sum_i p_i delta_y_i, with p_i>0 and total mass W=1. Except for the explicitly identified source-splitting test, the sites are distinct. There are at most eight source labels and at most nine fixed rational cube side lengths in [1,2]. For every receiver cell and scale L, the average is exactly A_L=mu(x+[-L/2,L/2]^n)/L^n.

The guard deletes the paid unit-anchor event A_1>=lambda/2. Its volume is computed over the complete arrangement, and its fee lambda times volume is verified to be at most 2W. On the remainder it selects the first scale in the ordered finite library with A_L>lambda. It does not select a maximizing scale. Earlier grid scales have A_L<=lambda, but scales between grid entries are not tested. The selected mass generally exceeds lambda L^n; that overshoot is saved exactly.

All source faces y_ij+-L/2 enter the original dx arrangement. The fresh option also inserts y_ij+-qL/2 with q=1/2. Fields and neighborhoods are constant on every resulting rectangular cell. Rational midpoints identify those constants; no sampled-grid volume proxy is used. The outer complement has every hard field zero. Face boundaries have zero dx measure. Identical complete capture/inner-mask patterns are aggregated only by summing their exact volumes. At every physical scale, the integral of A_L over all cells is checked to equal W.

## Fresh neighborhoods with an available anchor premise

At a selected scale L<=2, the inner cube of side qL=L/2 is contained in the unit anchor cube. Therefore its old-source mass is strictly below lambda/2. The finite strict crossing has captured mass strictly above lambda L^n, so

    fresh mass > lambda L^n-lambda/2 >= lambda L^n/2 > 0.

Thus every retained row has a nonempty fresh neighborhood, and its demand lambda times row volume is legitimate for both transport graphs. The guard verifies the exact old mass, fresh mass and residual of this inequality at every retained pattern. It does not assume a continuous age bound, captured mass equal to lambda L^n or a 7/8 fresh fraction. The actual fresh/captured ratio is also saved. Its smallest observed value is 31/33 in the one-dimensional low-mass-anchor case, and 21/22 in the higher-dimensional low-mass-anchor cases. These observed ratios are not a uniform theorem.

## Exact Hall optimum and independent flow

For each retained row r, let N(r) be its captured or fresh source-label neighborhood and d_r=lambda v_r its receiver demand. The maximum normalized source load has exact optimum

    K = max over nonempty source subsets S
        [sum_{r:N(r) subset S} d_r] / [sum_{i in S} p_i].

Every source subset is included. An exact subset-sum transform computes the forced row demand; the saved arrays contain every subset mass and every forced demand, plus all maximizing subsets. A maximizing subset supplies a rational lower-bound certificate. There are no empty positive-demand neighborhoods.

The independent flow network has source-to-row capacities d_r, row-to-allowed-physical-source edges of capacity total demand, and physical-source-to-sink capacities K p_i. Rational capacities are multiplied by their common denominator and an integer Dinic algorithm finds a flow. The guard checks every capacity, conservation at every interior node, the source/sink balance, the residual cut and total-demand saturation. Thus the saved feasible flow matches the Hall lower bound exactly. The assigned mass divided by p_i is the optimal normalized source load.

The canonical posterior instead allocates each row as d_r p_i / sum_{j in N(r)}p_j. Its maximum load is compared with K. Its mass-weighted average normalized load is exactly total demand/W, which can be strictly below K because of a Hall bottleneck. Receiver demands use original dx volumes throughout.

For captured neighborhoods this is the actual hard captured-source posterior multiplied by the receiver demand. For fresh neighborhoods it is a normalized allocation conditional on the allowed fresh subset; it is not the full hard posterior. The output labels these two scopes separately, although both use the same allocation formula.

## Three stages and volume results

| Stage | Fixtures | Complete cells | Purpose |
|---|---:|---:|---|
| Pilots and source splitting | 6 | 356 | Single source, nonzero same-measure splitting, distinct cluster refinement |
| Correlated, lacunary and spikes | 5 | 7,890 | Uneven masses, diagonal geometry, random rational sites, low-mass old sources |
| Dimension, scales and threshold extension | 6 | 115,353 | n=1,2,3 axis families, nine-scale extension, fresh transport and coarse scales |

The table displays a selection of exact volume and transport values. Rounded decimals are readable representations of saved rational numbers, rather than numerical integrations.

| Fixture | Retained volume | Captured K | Fresh K | Captured-posterior maximum | Average load |
|---|---:|---:|---:|---:|---:|
| Single source, n=1 | 1 | 1/4 | 1/4 | 1/4 | 1/4 |
| Low-mass anchor, n=1 | 5/4 | 5/16 | 10/31 | 322/1023 | 5/16 |
| Distinct cluster, N=8 | 15/16 | 15/64 | 15/64 | 6647/26880 | 15/64 |
| Lacunary sites, n=1 | 1/8 | 1/20 | 1/20 | 1/20 | 1/64 |
| Density spike, n=2 | 133/64 | 133/512 | 133/512 | 10931/36960 | 133/512 |
| Diagonal cluster, n=2 | 3/4 | 3/32 | 3/32 | 15/128 | 3/32 |
| Random rational sites, n=2 | 283/64 | 891/2048 | 891/2048 | approximately 0.511241 | 283/1024 |
| Axis family, n=2 | 59/16 | 33/128 | 33/128 | 251/768 | 59/256 |
| Axis family, n=3 | 597/64 | 597/2048 | 597/2048 | 773/2048 | 597/2048 |
| Nine-scale family, n=3 | 3585/512 | 3585/8192 | 3585/8192 | 48281/98304 | 3585/8192 |
| Low-mass anchor, n=3 | 999/128 | 999/2048 | 999/2048 | 23253/44032 | 999/2048 |

In the n=3 axis family, the captured-posterior maximum is 773/597 times the optimum, approximately 1.295. The random two-dimensional example has Hall optimum approximately 0.435059 and posterior maximum approximately 0.511241, while its average load is only approximately 0.276367. The lacunary example also has K above average, so balancing cannot remove the actual restricted-neighborhood bottleneck.

For the same-input splitting test, the coarse source has sites -3/4,0,3/4 and weights 31/64,1/32,31/64 at lambda=1/4. Each atom is then split into two coincident labels of half mass, preserving the physical measure. Exact receiver volume, captured and fresh optima, all normalized posterior loads and every expanded neighborhood-row demand agree. The common optimal captured load is 5/16. Removing the central old source from the allowed graph raises the fresh optimum to 10/31. This tests same-measure labeling invariance; moving split labels to distinct positions changes the geometry and is not claimed invariant.

## Replay and boundaries

Run python3 transport_probe.py. It uses only the Python standard library and writes transport_results.json next to the script. The complete run takes approximately one second on the present machine. The deterministic random rational fixture uses seed 820611; all realized coordinates and weights are saved. JSON contains complete axes and mask patterns, exact volumes, grid averages, selector/gate decisions, source-subset Hall data, all network capacities and flows, and both optimal and posterior source profiles.

This is an exact finite physical side-scale and atomic-source model. It does not certify continuum first-hit selection, positive L1 approximation, the smooth-event deletion in the parent interface or a general dimension/source-count-independent transport bound. The fresh guarantee comes from the tested unit anchor and L<=2, not from an untested earlier scale. Hall reformulation gives an exact optimization and certificate language; it does not itself establish the missing weak bound.

A qualitative finite-scale L1 realization is available separately from the numerical certificate. First aggregate coincident labels at each physical site, then replace each resulting atom by a tiny normalized box of the same total mass. At every receiver away from the finitely many capture and inner faces, every source box is eventually wholly inside or outside each fixed cube. All averages, anchor decisions and strict-hit decisions then agree exactly with the atomic model, including equality plateaus. Bounded dominated convergence gives convergence of receiver event volumes. For a fixed Hall subset of these physical sites, erode its forced receiver cells and take the corresponding union of source boxes; this preserves the Hall lower bound in the limit. Equivalently, before aggregation use only cuts containing complete coincident-label groups. A partial group cannot force a row involving that site, and deleting its partial labels preserves forced demand while reducing its denominator, so it is unnecessary for a positive maximizing Hall ratio. The bridge does not identify a physical source-box union with an arbitrary partial-label subset. It does not automatically transfer a full L1 feasible upper transport, and does not replace finite-grid selection by continuum first hit.


# R82 independent audit: scope, exact certificates, and portable reproduction

**Conclusion.** The new extreme-low-smooth-ratio branch has a valid all-input payment of order \(\sqrt n\). The transport formulation and retained negative-orientation example are valid within their stated hypotheses. No remaining concrete arithmetic or scope defect was found in the frozen files. The general centered-cube weak bound \(C_n^\square\leq\sqrt n\,n^{o(1)}\) remains **unproved**: neither the middle likelihood branch nor the general fresh-source Hall capacity has been bounded at the target scale.

This audit used the L03 rational-certificate and D01 transport interfaces. Rational feasibility, exact inequalities, analytic arguments, floating diagnostics, and sampling uncertainty are reported separately. No unverified interval library or general transport existence theorem is inferred from a finite check. The audit changed only its own report and guard; it did not modify the authors' programs or operate Git.

## 1. Analytic review

**Common posterior entropy.** The parent uses the actual joint law \(P=U(dx)\pi_x(dy)\), with \(U\) the normalized original receiver measure and \(P_0=f(y)dy/W\). At contact the density relative to \(U\otimes P_0\) is \(W/(\lambda L_x^n)\) on the captured cube. Thus
\[
\log(W/\lambda)-n\mathbb E_U\log L_x
=I_P(X;Y)+D(P_Y\Vert P_0).
\]
The occupation density is \(P_Y/P_0=I(y)/C\), where \(C=\lambda|E|/W\). The sourcewise estimate \(I(y)\leq1+n\log2\) gives an upper bound on source KL and an order-\(n\) payment, not a reverse square-root implication. Disjoint spatial replication adds the component entropy to mutual information while preserving source KL and the normalized volume ratio. This obstruction is expressly ungated; no replica claim for the continuous E2 smooth gate is made.

**Extreme likelihood payment.** For the same actual hard posterior, put \(\ell(z)=\sum_j-\log\phi(z_j)\). The comparison \(\mathbb E_\pi e^{-\ell}\leq P_1/A\) remains valid because the smooth convolution also contains sources outside the hard cube. If \(A\geq\lambda\) and \(P_1/A\leq\tfrac12e^{-s}\), at least half the captured mass has \(\ell>s\). Monotonicity of the true even E2 factor gives the star-cone domination
\[
K_s(z)=H(z)\mathbf1\{\ell(z/(2\|z\|_\infty))>s\}.
\]
Its finite-window positive envelope has integral \((1+n\log2)\delta_s\). Consequently the original receiver volume costs at most \(2(1+n\log2)\delta_sW\), including adaptive common scales. Non-strict existence is handled by continuous fields on the compact scale interval and direct envelope domination; it is not justified by an unqualified dense-grid attainment assertion.

The independence used to estimate \(\delta_s\) belongs solely to the reference cone measure: a uniform face/sign and \(n-1\) uniform free coordinates. With edge value, mean \(\mu\), and range \(d\) as defined in the component, Hoeffding gives \(\delta_{s_n}\leq(n+2)^{-1/2}\) at
\[
s_n=\mathrm{edge}+(n-1)\mu+\frac d2\sqrt{(n-1)\log(n+2)}.
\]
This proves the stated all-input payment. It does not give independence of the actual source posterior. The ordinary ratio gate \(P_1/A\leq1/2\) has no corresponding small angular mass.

The off-corner angular construction is an actual positive L1 input with a common first hit, paid anchor removal, and full smooth gate in dimensions \(n\geq10\). Convexity of \(-\log\phi\) on the hard interior places it outside the newly paid extreme branch. Its actual angular KL and total correlation can grow arbitrarily. Translation/dilation continuity of the L1 input and posterior preserves any fixed finite information level on a positive-volume receiver neighborhood. The neighborhood need not have a uniform lower volume, so this is an obstruction to an information assumption, not a counterexample to the weak bound.

**Hall allocation and strict capture cuts.** The finite primal/dual and cut characterization use the same source measure and original receiver demands. The continuum sufficiency argument retains compact receiver/source spaces, continuous positive scale, and a closed allowed relation. Outer finite partitions, exact flows, and a weak limit preserve the receiver marginal, source capacity, and relation. This does not assert sufficiency for an arbitrary Borel relation without those hypotheses.

Section 4.1 correctly repairs a strictness issue: cutting exactly to the union of selected cubes may retain level contact but remove every subsequent strict crossing. The inflated compact unions \(N_\varepsilon\) retain a strict witness immediately after contact, with \(L_x<2\), and decrease to \(N_0\). Anchor and smooth upper gates are inherited. The resulting capacity/volume comparison is stated for the stable regular compact selector class. A lower bound on the middle likelihood ratio is not hereditary under this cut; the text repartitions the cut input into middle and already-paid extreme portions. It does not claim fresh-shell cut heredity.

The lacunary actual L1 example correctly distinguishes the unbounded canonical posterior load from a common reallocation with capacity below \(1/15\). Its fixed source intervals are disjoint and share no capacity twice. It is a global multiscale example, not a fixed-window square-root theorem. A general target-sized Hall bound remains missing.

**Orientation.** Signed degree and inverse-Jacobian occupation are distinct quantities. The two identities retain the negative-orientation and barycentric debts. Source-ray completion requires omitted-sheet or boundary payment; a count of oriented roots does not bound \(1/|D|\). The dense cube has negative orientation on its entire captured interior after both the actual anchor and full-continuum smooth gates. The whole-window smooth estimate is a rational monotone envelope, not a check at a few scales. Joint continuity supplies an open receiver neighborhood. This refutes free positivity or free signed cancellation under the minimal retained gates; it does not claim the optional primitive gate, a weak counterexample, or a fixed-window unbounded signed-degree result.

## 2. Independent arithmetic and geometry

The audit guard imports neither main program. It reconstructs physical cells with source-index sets, rather than reusing the producer's bitset or subset-transform implementation.

| Independent check | Actual result | Evidence scope |
|---|---:|---|
| Complete original receiver cells | 123,599 | Exact axes, volumes, all-scale captures, anchor deletion, earliest strict finite-grid winner, fresh subset and grouped rows |
| Hall/flow certificates | 34 | Exact optimum cut and feasible saturated flow at the same capacity |
| Source cuts | 1,402 | Brute forced-demand enumeration, independently of the production zeta transform |
| Flow arcs | 2,669 | Exact capacities, conservation, demands, source budgets, residual cut and assignments |
| Actual interval first-hit points | 333 | Rational L1 geometry |
| Independently chosen common laws | 12 | Exact probability normalization; logarithmic KL evaluation is floating |
| Unequal-coordinate orientation identities | 18 | Rational sign/algebra identities |
| Strict-cut/inflation examples | 6 | Exact actual L1 interval contacts and strict witnesses |

The separate E2 gate audit uses a different exponential lower bound: a fifth-order odd Taylor polynomial with 16 subdivisions, instead of the author's cubic polynomial with 32 subdivisions. Source, mixture, and physical-scale monotone sums give an exact rational upper strictly below \(7/10\). Its displayed approximation is \(0.6768070525429332\); that decimal is not itself an outward-rounded enclosure. The analytic gate persistence is separate from these finite identities.

The finite KL-chain maximum residual was \(1.6653345369377348\times10^{-16}\). An independently transformed continuum integral, with 32,768 Simpson panels, differed from the saved value by \(2.631610485082092\times10^{-10}\). These are diagnostics and do not certify logarithmic integration errors or a smooth-gated realization of the arbitrary finite common laws.

The transport JSON concerns positive labelled atomic sources and a finite registered scale set. Its winner uses strict overshoot, not an exact continuous level contact. Fresh normalization is conditional on the allowed fresh subset and is not the full hard posterior. Coincident labels are aggregated before the qualitative L1-box bridge; physical-site cuts or complete coincident groups are used. That bridge gives a lower-limit interpretation, not a certified full upper bound or preservation of a continuous first-hit selector.

The conditional guard's new Bonferroni-Hoeffding intervals have simultaneous 95% sampling coverage separately for the three-count family and the twelve-mean family, under the ideal sampling law. They apply to quadrature-defined observables. They exclude quadrature bias and machine-randomness certification. In particular zero sampled counts do not prove zero cone mass.

## 3. Frozen inputs and actual reproduction

Own temporary-copy standalone runs, with empty stderr and exit 0, reproduced both JSON files byte for byte: entropy in **0.053128709 s**, transport in **0.586944417 s**.

| File | SHA256 |
|---|---|
| entropy_probe.py | `28d206e71be42315055362ffc146e03e0e9109d250fa988ffe393e1cc9ebdd00` |
| entropy_results.json | `91e3a66c99fd2d3a27f3d793ec7bcb70e6c41441625b88368d7ea0f7069d1dfd` |
| transport_probe.py | `6eb09b0b8a5238a782da3c3668ae3a77d16e2489e6553fc89251945abea98732` |
| transport_results.json | `14fd30fcf0991bee39374cad743bd0faba655a58aa8bcc68bf07dd03ec3cfb1f` |
| transport embedded guard | `4f780ffb9191630aad0796f730dbc23dbc8fa84e9262f253a5686701509e9dcf` |
| conditional embedded guard | `6470bb790624b35cba4f0fb1187c2a58a4de83f3a4dfa10b92451fbb6c56aec8` |
| oriented embedded guard | `2cac949548f26a334720fd4a464e6328aba4fc02cff9b30022a4a855901befb2` |
| audit_guard.py | `3417e441260dd51b71a38207328a8453de85f3f168d5fa954b12ed431b0238db` |

The final audit guard ran in an isolated archive-style directory containing only the four main files, the extracted audit guard, and a merged `proof.md`. It found exactly four Python fences, recovered the three component guards by their frozen hashes, ran each with exit 0 and empty stderr, and passed all independent checks in **5.129634125 s**. A second run removed `proof.md` and supplied only the extracted three component guards alongside the four main files and audit guard; it passed in **5.133888125 s**. No component Markdown file, original workspace path, external skill bundle, or installed solver is required to execute the packaged guard. The bundled guard uses Python standard library only.

The lookup order is same-directory extracted component guard, component Markdown as a development fallback, then a matching frozen fence in merged `proof.md`. The merged proof route is the archive requirement. Main-file hashes are verified before the independent audit. Main-program byte reproduction is recorded above and is not redundantly repeated inside the guard.

**Final boundary.** The package certifies its finite geometry, cuts, rational flows, and the stated monotone E2 inequality; the analytic arguments establish the conditional all-input reductions. The middle actual smooth-ratio branch and target-size common source allocation remain research obligations. No numerical PASS closes those obligations.


## 独立审计核验脚本

```python
#!/usr/bin/env python3
"""Independent R82 complete dx geometry, Hall/flow and entropy accounting.
Exact finite transport is separate from E2 diagnostics and the open weak bound.
"""
from fractions import Fraction as Q
from pathlib import Path
from itertools import product
from functools import lru_cache
from collections import deque
import json,math,hashlib,re,subprocess,tempfile,sys,time
BASE=Path(__file__).resolve().parent

def mask_of(s):return sum(1<<i for i in s)
def subset_mass(S,p):return sum(p[i] for i in range(len(p)) if S>>i&1)

def saved_transport():
    data=json.loads((BASE/'transport_results.json').read_text());total_cells=certs=subsets=arcs=0
    for fixture in data['fixtures']:
        src=fixture['source'];n,N=src['n'],src['N'];ys=[list(map(Q,y)) for y in src['centers']];p=list(map(Q,src['weights']));Ls=list(map(Q,src['scales']));lam=Q(src['lambda_value']);q=Q(src['fresh_ratio_q']);K=len(Ls)
        assert all(a>0 for a in p) and sum(p)==Q(src['W']) and 1==Ls[0]<=Ls[-1]<=2 and q==Q(1,2)
        axes=[sorted({y[j]+a*L*sgn for y in ys for L in Ls for a in (Q(1),q) for sgn in (-Q(1,2),Q(1,2))}) for j in range(n)]
        arr=fixture['arrangement'];assert axes==[list(map(Q,a)) for a in arr['axes']]
        lengths=[[b-a for a,b in zip(axis,axis[1:])] for axis in axes];coordinates=[[(a+b)/2 for a,b in zip(axis,axis[1:])] for axis in axes]
        # Independent geometric sets, not the production bitset intersections.
        allowed=[]
        for j in range(n):
            allowed.append([[{i for i,y in enumerate(ys) if abs(x-y[j])<a*L/2} for L in Ls for a in (Q(1),q)] for x in coordinates[j]])
        rebuilt={};count=0;digest=hashlib.sha256()
        for indices in product(*(range(len(v)) for v in lengths)):
            vol=math.prod(lengths[j][indices[j]] for j in range(n));captures=[];inners=[]
            for k in range(K):
                captures.append(mask_of(set.intersection(*(allowed[j][indices[j]][2*k] for j in range(n)))))
                inners.append(mask_of(set.intersection(*(allowed[j][indices[j]][2*k+1] for j in range(n)))))
            key=tuple(captures+inners)
            if key not in rebuilt:rebuilt[key]=[Q(0),0]
            rebuilt[key][0]+=vol;rebuilt[key][1]+=1;count+=1
            digest.update((str(indices)+':'+str(vol)+':'+str(key)+'\n').encode())
        saved={tuple(r['captured_masks']+r['inner_masks']):[Q(r['volume']),r['cell_count']] for r in arr['patterns']}
        assert saved==rebuilt and count==arr['complete_cell_count'] and digest.hexdigest()==arr['cell_digest'];total_cells+=count
        integrated=[Q(0)]*K;anchor=retained_volume=Q(0);rows={kind:{} for kind in ('captured','fresh')}
        for row in arr['patterns']:
            cap,inner=row['captured_masks'],row['inner_masks'];vol=Q(row['volume']);v=[subset_mass(S,p)/L**n for S,L in zip(cap,Ls)]
            assert v==list(map(Q,row['averages']))
            paid=v[0]>=lam/2;hits=[k for k,a in enumerate(v) if a>lam];first=hits[0] if hits else None;keep=bool(hits) and not paid
            assert paid==row['paid_anchor'] and first==row['first_strict_scale_index'] and keep==row['retained']
            integrated=[a+b*vol for a,b in zip(integrated,v)]
            if paid:anchor+=vol
            if keep:
                k=first;C=cap[k];O=inner[k];F=C&~O;M=subset_mass(C,p);m=subset_mass(F,p)
                assert O&~cap[0]==0 and O&~C==0 and F>0
                assert subset_mass(O,p)<lam/2 and M>lam*Ls[k]**n and m>lam*Ls[k]**n-lam/2>=lam*Ls[k]**n/2
                assert C==row['captured_neighborhood'] and F==row['fresh_neighborhood']
                assert m==Q(row['fresh_mass']) and M==Q(row['captured_mass']) and M-lam*Ls[k]**n==Q(row['overshoot_mass'])
                retained_volume+=vol
                for kind,S in (('captured',C),('fresh',F)):
                    key=(S,k)
                    if key not in rows[kind]:rows[kind][key]=[Q(0),0]
                    rows[kind][key][0]+=vol;rows[kind][key][1]+=row['cell_count']
        assert integrated==[sum(p)]*K and anchor==Q(arr['paid_anchor_volume']) and lam*anchor<=2*sum(p)
        assert retained_volume==Q(arr['retained_volume']) and lam*retained_volume==Q(arr['retained_demand'])
        capacities=[]
        for kind in ('captured','fresh'):
            cert=fixture[kind+'_transport'];rr=cert['rows']
            assert {(r['neighborhood'],r['first_scale_index']):[Q(r['volume']),r['cell_count']] for r in rr}==rows[kind]
            demands=[Q(r['demand']) for r in rr];assert all(d==lam*Q(r['volume']) for d,r in zip(demands,rr))
            masses=[subset_mass(S,p) for S in range(1<<N)]
            # Brute subset sums are independent of production zeta transform.
            forced=[sum(d for d,r in zip(demands,rr) if r['neighborhood']&~S==0) for S in range(1<<N)]
            bound=max(forced[S]/masses[S] for S in range(1,1<<N))
            assert masses==list(map(Q,cert['source_subset_masses'])) and forced==list(map(Q,cert['source_subset_forced_demands']))
            assert bound==Q(cert['K_optimal']);capacities.append(bound)
            assert [S for S in range(1,1<<N) if forced[S]==bound*masses[S]]==cert['Hall_maximizers']
            witness=cert['Hall_lower_witness'];S=witness['source_subset'];assert Q(witness['ratio'])==forced[S]/masses[S]==bound
            total=sum(demands);flow=cert['maxflow'];R=len(rr);s=0;rs=1;ss=1+R;t=ss+N
            assert flow['source_node']==s and flow['sink_node']==t and flow['row_node_start']==rs and flow['physical_source_node_start']==ss
            expected={(s,rs+r):d for r,d in enumerate(demands)}
            expected.update({(rs+r,ss+i):total for r,row in enumerate(rr) for i in range(N) if row['neighborhood']>>i&1})
            expected.update({(ss+i,t):bound*pi for i,pi in enumerate(p)})
            records=[(a,b,Q(c),Q(f)) for a,b,c,f in flow['arcs']]
            assert {(a,b):c for a,b,c,f in records}==expected and len(records)==len(expected)
            balance=[Q(0)]*(t+1);residual=[[] for _ in balance];assigned=[Q(0)]*N;actual_assignments={}
            for a,b,c,f in records:
                assert 0<=f<=c;balance[a]-=f;balance[b]+=f
                if c>f:residual[a].append(b)
                if f>0:residual[b].append(a)
                if rs<=a<ss and ss<=b<t:
                    assigned[b-ss]+=f
                    if f:actual_assignments[(a-rs,b-ss)]=f
                if a==s:assert f==c
            assert balance[s]==-total and balance[t]==total and all(v==0 for i,v in enumerate(balance) if i not in (s,t))
            seen={s};work=deque([s])
            while work:
                a=work.popleft()
                for b in residual[a]:
                    if b not in seen:seen.add(b);work.append(b)
            assert t not in seen and sorted(seen)==flow['source_side']
            cut=sum(c for a,b,c,f in records if a in seen and b not in seen)
            assert cut==total==Q(flow['value'])==Q(flow['cut'])
            assert actual_assignments=={(r['row'],r['source']):Q(r['amount']) for r in flow['nonzero_assignments']}
            assert assigned==list(map(Q,cert['optimal_source_assigned_mass'])) and all(a<=bound*pi for a,pi in zip(assigned,p))
            loads=[a/pi for a,pi in zip(assigned,p)];assert loads==list(map(Q,cert['optimal_source_normalized_loads']))
            posterior=[sum(d*pi/subset_mass(row['neighborhood'],p) for row,d in zip(rr,demands) if row['neighborhood']>>i&1) for i,pi in enumerate(p)]
            assert posterior==list(map(Q,cert['canonical_posterior_assigned_mass'])) and sum(posterior)==total
            canonical=[a/pi for a,pi in zip(posterior,p)];assert canonical==list(map(Q,cert['canonical_posterior_normalized_loads']))
            assert bound<=max(canonical,default=Q(0))==Q(cert['canonical_posterior_max_load'])
            certs+=1;subsets+=(1<<N)-1;arcs+=len(records)
        assert capacities[0]<=capacities[1]
    assert total_cells==data['counts']['complete_dx_cells'] and certs==34 and subsets==1402
    return {'full_original_dx_cells':total_cells,'rational_Hall_and_flow_certificates':certs,'independent_brute_source_subsets':subsets,'exact_flow_arcs':arcs,'scope':'Positive labelled atomic source and finite first STRICT grid hit, anchor deletion and fresh q=1/2; full geometry, all source cuts and saved rational flows. No L1/continuous-firsthit/smooth-gate certificate.'}

def entropy_checks():
    data=json.loads((BASE/'entropy_results.json').read_text());geometry=0
    for D in (16,64,256):
        for j in range(1,D):
            d=Q(3,8)+Q(j,8*D);r=2*d;L=4*d
            assert Q(3,2)<L<2 and 4*(r-d)/(2*r)==1 and 4*(Q(1,2)-d)<Q(1,2)
            for a in (Q(1,4),Q(1,2),Q(3,4)):assert 2-2*d/(d+a*d)<1
            geometry+=1
    assert geometry==data['exact_branch_cases']==333
    # New independently chosen finite common laws; logarithms remain floating.
    chain_error=0.;laws=0
    for N in (2,3,7):
        prior=[Q(i+1,N*(N+1)//2) for i in range(N)]
        weights=[Q(1,7),Q(2,7),Q(4,7)]
        for offset in range(N):
            masks=[{i for i in range(N) if (i+offset+j)%N<=j%N} for j in range(3)]
            joint=[[a*prior[i]/sum(prior[k] for k in mask) if i in mask else Q(0) for i in range(N)] for a,mask in zip(weights,masks)]
            marginal=[sum(row[i] for row in joint) for i in range(N)];assert sum(marginal)==1
            total=source=mutual=0.
            for i,b in enumerate(marginal):
                if b:source+=float(b)*math.log(float(b/prior[i]))
            for j,row in enumerate(joint):
                assert sum(row)==weights[j]
                for i,b in enumerate(row):
                    if b:
                        total+=float(b)*math.log(float(b/(weights[j]*prior[i])))
                        mutual+=float(b)*math.log(float(b/(weights[j]*marginal[i])))
            chain_error=max(chain_error,abs(total-source-mutual));laws+=1
    assert chain_error<1e-12
    base=data['replications'][0]
    for r in data['replications']:
        assert abs(r['source']-base['source'])<1e-12
        assert abs(r['mutual']-base['mutual']-math.log(r['copies']))<1e-12
    # Alternative change of variable y=b exp(-u) for the continuum source KL.
    a,b=3/8,1/2;end=math.log(b/a);M=32768;step=end/M
    def fun(u):
        v=u/(b-a)
        return b*math.exp(-u)*v*math.log(v) if u else 0.
    integral=step/3*(fun(0)+fun(end)+sum((4 if j%2 else 2)*fun(j*step) for j in range(1,M)))
    plateau=end/(b-a);source=a*plateau*math.log(plateau)+integral
    saved=data['actual_l1_quadrature'][-1];difference=abs(source-saved['source'])
    assert difference<1e-8 and abs(saved['total']-saved['source']-saved['mutual'])<1e-14
    return {'exact_actual_L1_firsthit_points':geometry,'independent_finite_common_laws':laws,'floating_KL_chain_max_residual':chain_error,'alternative_continuum_KL_difference':difference,'scope':'Exact rational interval geometry; finite KL logs and alternate actual-source integral are floating diagnostics, no interval proof or smooth-gate claim.'}


@lru_cache(None)
def alternate_exp_lower(s):
    # Independent odd fifth-order lower polynomial, with sixteen subdivisions.
    u=s/16
    if u>=1:return Q(0)
    lower=1-u+u*u/2-u**3/6+u**4/24-u**5/120
    assert lower>0
    return lower**16

@lru_cache(None)
def alternate_phi_upper(t):
    N=32;t=min(t,Q(1,2));total=Q(0)
    for j in range(1,N+1):
        r=Q(j,N)
        total+=r*(2-alternate_exp_lower((Q(1,2)+t)/r)-alternate_exp_lower((Q(1,2)-t)/r))
    return total/N

def oriented_independent():
    # A different valid exp lower bound independently encloses the whole
    # physical-scale interval for the actual E2 dense source factor.
    a,d,N=Q(41,100),Q(2,5),32;upper=Q(0)
    for k in range(N):
        lo=1+Q(k,N);hi=lo+Q(1,N)
        value=4*a/lo/N*sum((alternate_phi_upper((d+a*Q(j,N))/hi) for j in range(N)),Q(0))
        upper=max(upper,value)
    assert upper<Q(7,10) and upper**2<Q(1,2)
    checks=0
    for n in (2,3,4,8,16,64):
        r=Q(4,5);ds=[d+Q((j%3)-1,1000) for j in range(n)]
        D=sum(1/(r-z) for z in ds)-n/r
        assert D==sum(z/(r*(r-z)) for z in ds)>0
        gradient=[-1/((r-z)*D) for z in ds]
        for fraction in (Q(1,4),Q(1,2),Q(3,4)):
            ys=[fraction*(r-z) for z in ds];zs=[(-z-y)/r for z,y in zip(ds,ys)]
            jacobian=1-sum(z*g for z,g in zip(zs,gradient))
            exact=-sum(y/(r*(r-z)*D) for y,z in zip(ys,ds))
            assert jacobian==exact<0;checks+=1
    return {'independent_actual_E2_continuum_upper_approx':float(upper),'upper_below_7_over_10_exact':True,'rational_orientation_identity_cases':checks,'scope':'Different odd-Taylor rational exponential lower bound gives rigorous monotone whole-window E2 factor upper; analytic continuity supplies positive-volume gate persistence. Signed-source orientation identities are exact.'}

MAIN_HASHES={
 'entropy_probe.py':'28d206e71be42315055362ffc146e03e0e9109d250fa988ffe393e1cc9ebdd00',
 'entropy_results.json':'91e3a66c99fd2d3a27f3d793ec7bcb70e6c41441625b88368d7ea0f7069d1dfd',
 'transport_probe.py':'6eb09b0b8a5238a782da3c3668ae3a77d16e2489e6553fc89251945abea98732',
 'transport_results.json':'14fd30fcf0991bee39374cad743bd0faba655a58aa8bcc68bf07dd03ec3cfb1f'}
COMPONENT_HASHES={
 'transport':'4f780ffb9191630aad0796f730dbc23dbc8fa84e9262f253a5686701509e9dcf',
 'conditional':'6470bb790624b35cba4f0fb1187c2a58a4de83f3a4dfa10b92451fbb6c56aec8',
 'oriented':'2cac949548f26a334720fd4a464e6328aba4fc02cff9b30022a4a855901befb2'}

def frozen_inputs():
    for name,expected in MAIN_HASHES.items():
        assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==expected,name
    return dict(MAIN_HASHES)

def component_payload(name,expected):
    # Archive path: proof.md alone holds all component guards. Extracted
    # *_guard.py takes priority, while separate MD files are development-only.
    candidates=[BASE/(name+'_guard.py')]
    for path in candidates:
        if path.is_file():
            raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==expected,path.name
            return raw,path.name
    for path in (BASE/(name+'.md'),BASE/'proof.md'):
        if path.is_file():
            fences=re.findall(r'^```python\n(.*?)^```[ \t]*$',path.read_text(),re.M|re.S)
            matched=[code.encode() for code in fences if hashlib.sha256(code.encode()).hexdigest()==expected]
            if matched:
                assert len(matched)==1,(name,'duplicate frozen fence')
                return matched[0],path.name
    raise FileNotFoundError('Need frozen '+name+'_guard.py or its hash-matching Python fence in proof.md')

def component_replays():
    receipts=[]
    for name,expected in COMPONENT_HASHES.items():
        payload,origin=component_payload(name,expected)
        with tempfile.TemporaryDirectory(prefix='r81-component-') as td:
            path=Path(td)/'guard.py';path.write_bytes(payload)
            start=time.perf_counter();run=subprocess.run([sys.executable,'-B',str(path)],cwd=td,capture_output=True,text=True,timeout=60)
            assert run.returncode==0 and not run.stderr,(name,run.returncode,run.stderr,run.stdout)
            receipts.append({'component':name,'sha256':expected,'origin':origin,'exit':0,'empty_stderr':True,'elapsed_seconds':round(time.perf_counter()-start,4)})
    return receipts



def strict_cut_checks():
    checks=0
    for a in (Q(2,5),Q(7,16),Q(15,32)):
        r=2*a
        assert 4*(Q(1,2)-a)<Q(1,2)
        for epsilon in (Q(1,16),Q(1,32)):
            cutoff=a+2*a*epsilon;witness=r*(1+epsilon/2)
            assert cutoff<1 and 0<witness-a<cutoff
            exact_cut_at_witness=4*a/(2*witness)
            inflated_at_witness=4*(witness-a)/(2*witness)
            assert exact_cut_at_witness<1<inflated_at_witness
            for t in (Q(1,4),Q(1,2),Q(3,4)):
                smaller=a+t*a
                assert 4*(smaller-a)/(2*smaller)<1
            checks+=1
    return {'exact_cut_strictness_repairs':checks,'scope':'Actual interval L1 source; exact capture cut loses strict crossing while inflated cut preserves it. General compact-neighborhood limit and gate inheritance are proved analytically.'}

def main():
    start=time.perf_counter();hashes=frozen_inputs();out={'status':'PASS','frozen_main_hashes':hashes,'component_replays':component_replays(),'transport':saved_transport(),'entropy':entropy_checks(),'orientation':oriented_independent(),'strict_cut':strict_cut_checks()};out['elapsed_seconds']=round(time.perf_counter()-start,4);print(json.dumps(out,sort_keys=True))
if __name__=='__main__':main()
```
