#!/usr/bin/env python3
"""Exact finite hard-window receiver/source transport on complete dx cells.

Positive atomic source, finite rational scales, paid unit anchor. No continuous
first-hit or L1-input assertion. All Hall subsets and independent integer flow.
"""
from fractions import Fraction as F
from pathlib import Path
from itertools import product
from collections import deque
from math import prod,lcm
import json,random,time,hashlib

SEED=820611


def clean(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [clean(v) for v in x]
    return x


def mass_table(weights):
    out=[F(0)]*(1<<len(weights))
    for mask in range(1,len(out)):
        bit=mask&-mask;out[mask]=out[mask^bit]+weights[bit.bit_length()-1]
    return out


def fixture(label,n,centers,weights,scales,lam):
    centers=[tuple(map(F,y)) for y in centers];weights=list(map(F,weights));scales=list(map(F,scales))
    assert all(p>0 for p in weights) and len(centers)<=10 and len(centers)==len(weights)
    assert scales==sorted(set(scales)) and scales[0]==1 and scales[-1]<=2
    return dict(label=label,n=n,N=len(centers),centers=centers,weights=weights,W=sum(weights),scales=scales,lambda_value=F(lam),fresh_ratio_q=F(1,2))


def cells(src):
    n,N,K=src['n'],src['N'],len(src['scales']);q=src['fresh_ratio_q'];full=(1<<N)-1
    mass=mass_table(src['weights']);axes=[];lengths=[];mids=[];tables=[]
    for j in range(n):
        axis=sorted({y[j]+a*L*side for y in src['centers'] for L in src['scales'] for a in (F(1),q) for side in (F(-1,2),F(1,2))})
        axes.append(axis);lengths.append([b-a for a,b in zip(axis,axis[1:])]);mids.append([(a+b)/2 for a,b in zip(axis,axis[1:])])
        table=[]
        for x in mids[-1]:
            row=[]
            for L in src['scales']:
                for factor in (F(1),q):
                    row.append(sum(1<<i for i,y in enumerate(src['centers']) if abs(x-y[j])<factor*L/2))
            table.append(row)
        tables.append(table)
    patterns={};cell_count=0;digest=hashlib.sha256()
    for indices in product(*(range(len(x)) for x in lengths)):
        vol=prod(lengths[j][indices[j]] for j in range(n));capture=[];old=[]
        for k in range(K):
            c=o=full
            for j in range(n):c&=tables[j][indices[j]][2*k];o&=tables[j][indices[j]][2*k+1]
            capture.append(c);old.append(o);assert o&c==o
        key=tuple(capture+old)
        if key not in patterns:patterns[key]=dict(volume=F(0),cell_count=0,representative=[mids[j][indices[j]] for j in range(n)])
        row=patterns[key];row['volume']+=vol;row['cell_count']+=1;cell_count+=1
        digest.update((str(indices)+':'+str(vol)+':'+str(key)+'\n').encode())
    records=[];retained=[];integrals=[F(0)]*K
    for key,item in patterns.items():
        capture=list(key[:K]);old=list(key[K:]);averages=[mass[c]/L**n for c,L in zip(capture,src['scales'])]
        hits=[k for k,a in enumerate(averages) if a>src['lambda_value']]
        first=hits[0] if hits else None;paid=averages[0]>=src['lambda_value']/2;keep=first is not None and not paid
        for k,a in enumerate(averages):integrals[k]+=a*item['volume']
        rec=dict(**item,captured_masks=capture,inner_masks=old,averages=averages,paid_anchor=paid,first_strict_scale_index=first,retained=keep)
        if keep:
            k=first;L=src['scales'][k];c=capture[k];o=old[k];fresh=c^o
            assert k>0 and fresh and mass[o]<=mass[capture[0]]<src['lambda_value']/2
            assert mass[c]>src['lambda_value']*L**n
            residual=mass[fresh]-(src['lambda_value']*L**n-src['lambda_value']/2)
            assert residual>0
            rec.update(captured_neighborhood=c,fresh_neighborhood=fresh,captured_mass=mass[c],fresh_mass=mass[fresh],
                       first_strict_scale=L,overshoot_mass=mass[c]-src['lambda_value']*L**n,
                       fresh_mass_over_lambda_scale_volume=mass[fresh]/(src['lambda_value']*L**n),
                       fresh_fraction_of_capture=mass[fresh]/mass[c],anchor_fresh_lower_bound=src['lambda_value']*L**n-src['lambda_value']/2,
                       strict_fresh_bound_residual=residual)
            retained.append(rec)
        records.append(rec)
    assert integrals==[src['W']]*K
    anchor_volume=sum(r['volume'] for r in records if r['paid_anchor']);assert src['lambda_value']*anchor_volume<=2*src['W']
    retained_volume=sum(r['volume'] for r in retained)
    return dict(axes=axes,complete_cell_count=cell_count,pattern_count=len(records),cell_digest=digest.hexdigest(),patterns=records,
                scale_average_integrals=integrals,paid_anchor_volume=anchor_volume,paid_anchor_fee=src['lambda_value']*anchor_volume,
                paid_anchor_budget=2*src['W'],positive_grid_event_volume=sum(r['volume'] for r in records if r['first_strict_scale_index'] is not None),
                retained_volume=retained_volume,retained_demand=src['lambda_value']*retained_volume,
                retained_cell_count=sum(r['cell_count'] for r in retained),retained_pattern_count=len(retained),
                min_fresh_mass_over_lambda_scale_volume=min((r['fresh_mass_over_lambda_scale_volume'] for r in retained),default=None),
                min_fresh_fraction_of_capture=min((r['fresh_fraction_of_capture'] for r in retained),default=None)),retained


def grouped_rows(src,retained,key):
    rows={}
    for r in retained:
        mask=r[key];k=r['first_strict_scale_index'];item=rows.setdefault((mask,k),dict(neighborhood=mask,first_scale_index=k,volume=F(0),cell_count=0))
        item['volume']+=r['volume'];item['cell_count']+=r['cell_count']
    out=list(rows.values())
    for row in out:row['demand']=src['lambda_value']*row['volume']
    return out


class Flow:
    def __init__(self,N):self.graph=[[] for _ in range(N)];self.original=[]
    def edge(self,a,b,c):
        ai=len(self.graph[a]);bi=len(self.graph[b]);self.graph[a].append([b,bi,c]);self.graph[b].append([a,ai,0]);self.original.append((a,b,c,ai))
    def maxflow(self,s,t):
        value=0;N=len(self.graph)
        while True:
            level=[-1]*N;level[s]=0;q=deque([s])
            while q:
                v=q.popleft()
                for w,rev,c in self.graph[v]:
                    if c and level[w]<0:level[w]=level[v]+1;q.append(w)
            if level[t]<0:break
            ptr=[0]*N
            def dfs(v,f):
                if v==t:return f
                while ptr[v]<len(self.graph[v]):
                    e=self.graph[v][ptr[v]];w,rev,c=e
                    if c and level[w]==level[v]+1:
                        z=dfs(w,min(f,c))
                        if z:e[2]-=z;self.graph[w][rev][2]+=z;return z
                    ptr[v]+=1
                return 0
            while True:
                z=dfs(s,sum(c for a,b,c,i in self.original if a==s))
                if not z:break
                value+=z
        reachable={s};q=deque([s])
        while q:
            v=q.popleft()
            for w,rev,c in self.graph[v]:
                if c and w not in reachable:reachable.add(w);q.append(w)
        return value,reachable


def transport(src,rows):
    N=src['N'];masses=mass_table(src['weights']);subset_demands=[F(0)]*(1<<N)
    for row in rows:
        assert row['neighborhood'];subset_demands[row['neighborhood']]+=row['demand']
    # Exact subset zeta transform: sum of demands whose neighborhood is in S.
    for i in range(N):
        for S in range(1<<N):
            if S>>i&1:subset_demands[S]+=subset_demands[S^(1<<i)]
    K=max((subset_demands[S]/masses[S] for S in range(1,1<<N)),default=F(0))
    maximizers=[S for S in range(1,1<<N) if subset_demands[S]==K*masses[S]]
    total=sum(row['demand'] for row in rows);assert K>=total/src['W']
    scale=1
    for z in [row['demand'] for row in rows]+[K*p for p in src['weights']]:scale=lcm(scale,z.denominator)
    R=len(rows);s=0;row_start=1;source_start=1+R;t=source_start+N;g=Flow(t+1)
    for r,row in enumerate(rows):
        g.edge(s,row_start+r,int(row['demand']*scale))
        for i in range(N):
            if row['neighborhood']>>i&1:g.edge(row_start+r,source_start+i,int(total*scale))
    for i,p in enumerate(src['weights']):g.edge(source_start+i,t,int(K*p*scale))
    value,reach=g.maxflow(s,t);flows=[];balance=[0]*(t+1)
    for a,b,c,idx in g.original:
        f=c-g.graph[a][idx][2];assert 0<=f<=c
        balance[a]-=f;balance[b]+=f;flows.append((a,b,F(c,scale),F(f,scale)))
    assert balance[s]==-value and balance[t]==value and all(balance[v]==0 for v in range(t+1) if v not in (s,t))
    cut=sum(c for a,b,c,idx in g.original if a in reach and b not in reach)
    assert value==cut==int(total*scale)
    assigned=[F(0)]*N;assignments=[]
    for a,b,c,f in flows:
        if row_start<=a<source_start and source_start<=b<t and f:
            r=a-row_start;i=b-source_start;assigned[i]+=f;assignments.append(dict(row=r,source=i,amount=f))
    loads=[z/p for z,p in zip(assigned,src['weights'])];assert max(loads,default=F(0))<=K
    posterior=[F(0)]*N
    for row in rows:
        M=masses[row['neighborhood']]
        for i,p in enumerate(src['weights']):
            if row['neighborhood']>>i&1:posterior[i]+=row['demand']*p/M
    posterior_loads=[z/p for z,p in zip(posterior,src['weights'])];Kpost=max(posterior_loads,default=F(0))
    assert K<=Kpost and sum(posterior)==total
    hall_residuals=[K*masses[S]-subset_demands[S] for S in range(1,1<<N)];assert min(hall_residuals,default=F(0))>=0
    # The maximizing source subset is also a lower-bound cut certificate.
    S=maximizers[0];forced=sum(row['demand'] for row in rows if row['neighborhood']&~S==0)
    assert forced==K*masses[S]
    return dict(rows=rows,K_optimal=K,all_nonempty_source_subsets_checked=(1<<N)-1,
                source_subset_masses=masses,source_subset_forced_demands=subset_demands,Hall_maximizers=maximizers,
                Hall_lower_witness=dict(source_subset=S,forced_demand=forced,source_mass=masses[S],ratio=forced/masses[S]),
                Hall_min_residual=min(hall_residuals,default=F(0)),total_demand=total,weighted_average_load=total/src['W'],
                maxflow=dict(integer_capacity_scale=scale,value=F(value,scale),cut=F(cut,scale),source_side=sorted(reach),
                             source_node=s,sink_node=t,row_node_start=row_start,physical_source_node_start=source_start,
                             arcs=flows,nonzero_assignments=assignments,capacity_bounds_verified=True,flow_conservation_verified=True,
                             all_receiver_demands_saturated=True),
                optimal_source_assigned_mass=assigned,optimal_source_normalized_loads=loads,
                canonical_posterior_assigned_mass=posterior,canonical_posterior_normalized_loads=posterior_loads,
                canonical_posterior_max_load=Kpost,posterior_minus_optimal_max_load=Kpost-K,
                posterior_over_optimal=Kpost/K if K else None)


def fixtures():
    L=[F(1),F(5,4),F(3,2),F(7,4),F(2)];out=[]
    out.append(('pilots_and_source_splitting',fixture('single_n1',1,[(0,)],[1],L,F(1,4))))
    coarse=fixture('same_input_coarse_n1',1,[(F(-3,4),),(0,),(F(3,4),)],[F(31,64),F(1,32),F(31,64)],L,F(1,4))
    out.append(('pilots_and_source_splitting',coarse))
    split=fixture('same_input_split_n1',1,[y for y in coarse['centers'] for _ in range(2)],[p/2 for p in coarse['weights'] for _ in range(2)],L,F(1,4))
    out.append(('pilots_and_source_splitting',split))
    for N in (2,5,8):
        ys=[(F(2*i-N+1,32*N),) for i in range(N)]
        out.append(('pilots_and_source_splitting',fixture('distinct_cluster_n1_N'+str(N),1,ys,[F(1,N)]*N,L,F(1,4))))
    out.append(('correlated_lacunary_and_spikes',fixture('lacunary_n1_N5',1,[(F(-3,2),),(F(-3,4),),(0,),(F(3,8),),(F(3,2),)],[F(1,16),F(1,8),F(1,2),F(1,4),F(1,16)],L,F(1,8))))
    out.append(('correlated_lacunary_and_spikes',fixture('density_spike_n2_N5',2,[(0,0),(F(1,32),0),(F(-1,32),0),(F(-7,8),F(3,4)),(F(7,8),F(-3,4))],[F(3,8),F(1,4),F(1,4),F(1,16),F(1,16)],L,F(1,8))))
    out.append(('correlated_lacunary_and_spikes',fixture('diagonal_correlated_n2_N6',2,[(F(2*i-5,8),F(2*i-5,8)) for i in range(6)],[F(1,6)]*6,L,F(1,8))))
    out.append(('correlated_lacunary_and_spikes',fixture('old_light_anchor_n2_N4',2,[(0,0),(F(-3,4),0),(F(3,4),0),(0,F(3,4))],[F(1,64),F(21,64),F(21,64),F(21,64)],L,F(1,8))))
    rng=random.Random(SEED)
    weights=[rng.randrange(1,12) for _ in range(7)];W=sum(weights)
    centers=[(F(rng.randrange(-12,13),8),F(rng.randrange(-8,9),8)) for _ in range(7)]
    out.append(('correlated_lacunary_and_spikes',fixture('random_rational_n2_N7',2,centers,[F(w,W) for w in weights],L,F(1,16))))
    for n in (1,2,3):
        ys=[tuple([F(-3,4)]+[F(0)]*(n-1)),tuple([F(0)]*n),tuple([F(3,4)]+[F(0)]*(n-1))]
        out.append(('dimension_scale_and_threshold_extension',fixture('axis_n'+str(n)+'_N3',n,ys,[F(1,4),F(1,2),F(1,4)],L,F(1,2**(n+2)))))
    out.append(('dimension_scale_and_threshold_extension',fixture('n3_dense_scale_N5',3,[tuple([F(2*i-4,8)]+[F(0)]*2) for i in range(5)],[F(1,5)]*5,[F(1)+F(j,8) for j in range(9)],F(1,16))))
    out.append(('dimension_scale_and_threshold_extension',fixture('old_light_anchor_n3_N4',3,[(0,0,0),(F(-3,4),0,0),(F(3,4),0,0),(0,F(3,4),0)],[F(1,64),F(21,64),F(21,64),F(21,64)],L,F(1,16))))
    out.append(('dimension_scale_and_threshold_extension',fixture('n2_coarse_scale_N3',2,[(F(-3,4),0),(0,0),(F(3,4),0)],[F(1,4),F(1,2),F(1,4)],[F(1),F(2)],F(1,8))))
    return out


def main():
    start=time.monotonic();records=[]
    for stage,src in fixtures():
        arr,retained=cells(src);captured=transport(src,grouped_rows(src,retained,'captured_neighborhood'));fresh=transport(src,grouped_rows(src,retained,'fresh_neighborhood'))
        captured['canonical_allocation_scope']='The actual hard captured-source posterior on the selected finite scale, multiplied by receiver demand.'
        fresh['canonical_allocation_scope']='The normalized allowed-fresh-source allocation, conditional on the fresh subset; not the full hard captured-source posterior.'
        assert fresh['K_optimal']>=captured['K_optimal']
        records.append(dict(stage=stage,source=src,arrangement=arr,captured_transport=captured,fresh_transport=fresh))
        print(src['label'],'cells',arr['complete_cell_count'],'volume',arr['retained_volume'],'K',str(captured['K_optimal']),str(fresh['K_optimal']),'seconds',round(time.monotonic()-start,3),flush=True)
    bylabel={r['source']['label']:r for r in records};a=bylabel['same_input_coarse_n1'];b=bylabel['same_input_split_n1']
    assert a['arrangement']['retained_volume']==b['arrangement']['retained_volume']
    for key in ('captured_transport','fresh_transport'):
        assert a[key]['K_optimal']==b[key]['K_optimal'] and a[key]['canonical_posterior_max_load']==b[key]['canonical_posterior_max_load']
        assert b[key]['canonical_posterior_normalized_loads']==[z for z in a[key]['canonical_posterior_normalized_loads'] for _ in range(2)]
        expand=lambda mask:sum((3<<(2*i)) for i in range(a['source']['N']) if mask>>i&1)
        expected={(expand(row['neighborhood']),row['first_scale_index']):row['demand'] for row in a[key]['rows']}
        actual={(row['neighborhood'],row['first_scale_index']):row['demand'] for row in b[key]['rows']}
        assert expected==actual
    out=dict(status='EXACT_HALL_AND_MAXFLOW_VERIFIED',dependencies='Python standard library only',seed=SEED,
             source_scope='Positive finite labelled atomic measure. Coincident split labels preserve the same physical measure. No L1-density or continuous first-hit claim.',
             selector='First STRICT A_L>lambda among the fixed rational side scales, after excluding paid anchor A_1>=lambda/2; not a maximizing scale.',
             fresh_scope='q=1/2 and L<=2 imply inner qL cube is inside the unit anchor. Old mass<lambda/2, captured mass>lambda L^n, so fresh mass>lambda L^n-lambda/2>=lambda L^n/2. No continuous age bound or threshold equality is assumed.',
             transport_formula='K=max_nonempty_S [sum_{rows:neighborhood subset S}lambda*row_volume]/[sum_i in S p_i]. Exact all-source-subset Hall oracle; independent integer maxflow verifies saturation at K.',
             canonical_posterior='Each row sends lambda*volume*p_i/neighborhood_mass to its allowed sources. Captured neighborhoods give the actual hard posterior; fresh neighborhoods give a fresh-conditioned allocation, not the full hard posterior.',
             counts=dict(stages=3,fixtures=len(records),complete_dx_cells=sum(r['arrangement']['complete_cell_count'] for r in records),
                         exact_transport_certificates=2*len(records),Hall_nonempty_subsets_checked=2*sum((1<<r['source']['N'])-1 for r in records)),
             source_splitting_invariance=dict(coarse='same_input_coarse_n1',split='same_input_split_n1',same_receiver_volume=True,same_captured_and_fresh_K=True,
                                              same_posterior_max_load=True,all_normalized_posterior_loads_duplicate_exactly=True,expanded_neighborhood_row_demands_match=True),
             fixtures=records,limitations=['Finite-grid strict hit can overshoot lambda; overshoot and fresh masses are saved exactly.',
                                          'This guard does not certify continuum first-hit transport, L1 approximation, a smooth-event deletion or a general weak bound.',
                                          'Hall reformulation and a feasible flow do not establish a source-count or dimension-uniform estimate.'])
    p=Path(__file__).with_name('transport_results.json');p.write_text(json.dumps(clean(out),sort_keys=True,indent=2)+'\n')
    print('PASS',out['counts'],'seconds',round(time.monotonic()-start,3),'bytes',p.stat().st_size,flush=True)


if __name__=='__main__':main()
