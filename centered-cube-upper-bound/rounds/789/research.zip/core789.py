"""R789: deletion and stationary conditional rank transport for actual peak records."""

import argparse
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform
import sys

import merges789 as geom


def total(values):
    return sum(values, F(0))


@dataclass(frozen=True)
class Record:
    left: tuple
    right: tuple
    middle: int
    mass: F

    @property
    def nodes(self):
        return (0, self.left), (1, self.right)


def original_records(n, stage):
    parents = geom.instances(n, stage)
    labels = range(len(parents))
    J = {(i, j): geom.intersection(parents[i], parents[j], n)
         for i, j in product(labels, repeat=2)}
    degrees, down = {}, {}
    for v in labels:
        edges = {u: J[v, u] * parents[u].owner / (parents[v].m * parents[u].m)
                 for u in labels if parents[u].m != parents[v].m
                 and 0 < J[v, u] <= F(3, 4) * min(parents[v].m, parents[u].m)}
        degrees[v] = total(edges.values())
        down[v] = {u for u in edges if parents[u].m < parents[v].m}
    marks, cells = geom.cells_and_marks(parents, n, down)
    epochs, first = geom.component_table(parents, J, n, max(1, n // 4), False)
    q = {v: geom.floor_log2(degrees[v]) for v in labels if down[v]}
    records = []
    old_total = F(0)
    for (a, wa), (b, wb) in product(marks.items(), repeat=2):
        av, bv = a[0], b[0]
        for v in sorted(set(a[1]) & set(b[1])):
            pa = parents[v]
            original = wa * wb * pa.owner / (pa.m**2 * degrees[v])
            old_total += original
            fraction = F((av + bv + v + len(a[1]) * len(b[1])) % 5, 4)
            if fraction:
                records.append(Record((a, first[av, bv][0], q[v]),
                                      (b, first[bv, av][0], q[v]), v, original * fraction))
    original_by_rows = total(parents[v].owner * (total(w for a, w in marks.items() if v in a[1])
                                                 / parents[v].m)**2 / degrees[v]
                             for v in q)
    assert original_by_rows == old_total > total(r.mass for r in records) > 0
    base = {node: marks[node[1][0]] for record in records for node in record.nodes}
    assert total(base.values()) <= 2 * len(epochs) * len(set(q.values())) * total(marks.values())
    return parents, records, base, cells, epochs, degrees, old_total


def degrees_for(records, active):
    d = defaultdict(F)
    for index in active:
        r = records[index]
        for node in r.nodes:
            d[node] += r.mass
    return d


def peel(records, base):
    original_ids = set(range(len(records)))
    init = degrees_for(records, original_ids)
    rates = sorted({mass / base[k] for k, mass in init.items()})
    cut = len(rates) // 4
    threshold = (rates[cut - 1] + rates[cut]) / 2
    active = set(original_ids)
    paid_node = set()
    removed = set()
    timeline = []
    wave_loss = F(0)
    while True:
        marg = degrees_for(records, active)
        low = {node for node, w in marg.items() if w < threshold * base[node]}
        if not low:
            break
        assert not (low & paid_node)
        hits = {idx for idx in active if any(node in low for node in records[idx].nodes)}
        assigned = defaultdict(F)
        both_sides = 0
        for idx in hits:
            ends = [node for node in records[idx].nodes if node in low]
            assigned[ends[0]] += records[idx].mass
            both_sides += len(ends) == 2
        mass = total(records[i].mass for i in hits)
        assert mass == sum(assigned.values())
        assert all(assigned[node] <= marg[node] < threshold * base[node] for node in low)
        cap = threshold * total(base[node] for node in low)
        assert 0 < mass < cap
        timeline.append(dict(records_removed=len(hits), first_low_nodes=len(low),
                             both_endpoints_low_but_single_payment=both_sides,
                             actual_removed=mass, threshold_times_new_node_base=cap,
                             actual_over_cap=mass / cap))
        assert not removed & hits
        active.difference_update(hits)
        removed.update(hits)
        paid_node.update(low)
        wave_loss += mass
    replay = set(original_ids)
    # A different schedule independently deletes with left and right sides in turn.
    while True:
        n = len(replay)
        for side in (1, 0):
            marg = degrees_for(records, replay)
            low = {k for k, w in marg.items() if k[0] == side and w < threshold * base[k]}
            replay = {i for i in replay if records[i].nodes[side] not in low}
        if len(replay) == n:
            break
    assert replay == active and len(timeline) >= 2 and active
    assert active.isdisjoint(removed) and active | removed == original_ids
    seed = total(r.mass for r in records)
    interior = total(records[i].mass for i in active)
    broad_bound = threshold * total(base[k] for k in paid_node)
    assert seed == interior + wave_loss <= interior + broad_bound
    min_ratio = min(x / base[k] for k, x in degrees_for(records, active).items())
    assert min_ratio >= threshold and wave_loss > 0
    return active, dict(
        initial_positive_records=len(records), retained_records=len(active),
        left_and_right_supported_nodes_before=len(init), threshold_t=threshold,
        waves=timeline, true_R_mass=seed, true_core_mass=interior, removed_mass=wave_loss,
        retained_mass_over_R=interior / seed, threshold_times_first_paid_bases=broad_bound,
        min_surviving_node_mass_over_its_original_base=min_ratio,
        ratio_of_true_loss_to_first_node_budget=wave_loss / broad_bound,
        all_removed_records_and_original_core_partition=True,
        alternate_right_left_schedule_same_core=True)


def overlap(a, b, l, h):
    return max(F(0), min(b, h) - max(a, l))


def rank_rotation(records, active, parents, side, delta):
    nodes = defaultdict(list)
    for i in sorted(active):
        nodes[records[i].nodes[side]].append(i)
    scale_of = lambda i: parents[records[i].middle].m
    R = total(records[i].mass for i in active)
    row, col = defaultdict(F), defaultdict(F)
    naive_row, naive_col = defaultdict(F), defaultdict(F)
    strict_up = strict_down = same = growth = rank_growth = F(0)
    wraps = F(0)
    B = F(17, 16)
    observed_cross = None
    kernels = defaultdict(dict)
    for node, block in nodes.items():
        order = sorted(block, key=lambda i: (scale_of(i), records[i].middle, i))
        M = total(records[i].mass for i in order)
        lo, bounds = F(0), {}
        for i in order:
            hi = lo + records[i].mass / M
            bounds[i] = lo, hi
            lo = hi
        assert lo == 1
        local_wrap = F(0)
        for i, j in product(order, repeat=2):
            a, b = bounds[i]
            l, h = bounds[j]
            normal = M * overlap(a + delta, b + delta, l, h)
            wrap = M * overlap(a + delta - 1, b + delta - 1, l, h)
            naive_row[i] += normal
            naive_col[j] += normal
            row[i] += normal + wrap
            col[j] += normal + wrap
            local_wrap += wrap
            if not normal + wrap:
                continue
            kernels[i][j] = (normal + wrap) / records[i].mass
            before, after = scale_of(i), scale_of(j)
            if after > before:
                assert not wrap
                strict_up += normal
            elif after < before:
                assert not normal
                strict_down += wrap
            else:
                same += normal + wrap
            if after > B * before:
                growth += normal
                if observed_cross is None:
                    observed_cross = dict(node=node, original_record=i, new_record=j,
                                          actual_m_ratio=after/before, positive_joint_mass=normal)
        # Independently integrate the ranks past the mass cutoff for a size growth B.
        for i in order:
            a, b = bounds[i]
            cut = total(records[j].mass for j in order if scale_of(j) <= B * scale_of(i)) / M
            rank_growth += M * overlap(a, b, cut - delta, 1 - delta)
        assert local_wrap == delta * M
        wraps += local_wrap
    assert all(row[i] == col[i] == records[i].mass for i in active)
    assert all(sum(kernels[i].values()) == 1 for i in active)
    assert strict_up + strict_down + same == R
    assert growth == rank_growth <= strict_up <= (1 - delta) * R
    assert strict_down <= wraps == delta * R
    deficit_row = total(records[i].mass - naive_row[i] for i in active)
    deficit_col = total(records[i].mass - naive_col[i] for i in active)
    assert all(naive_row[i] <= row[i] and naive_col[i] <= col[i] for i in active)
    assert deficit_row == deficit_col == wraps > 0
    return kernels, dict(read_side=side, delta=delta, conditioning_nodes=len(nodes),
                         true_core_joint_mass=R, scale_strict_up_equal_down_shares=[
                             strict_up/R, same/R, strict_down/R],
                         growth_ratio_test=B, fraction_of_true_mass_with_growth_over_B=growth/R,
                         growth_example=observed_cross,
                         rank_crossing_check_growth_mass=rank_growth,
                         unwrapped_only_missing_each_marginal=wraps,
                         fraction_of_each_marginal_lost_without_wrap=wraps/R)


def case(n, stage):
    parents, records, base, cells, epochs, d, raw = original_records(n, stage)
    core, deletion = peel(records, base)
    left_kernel, left = rank_rotation(records, core, parents, 0, F(1, 4))
    right_kernel, right = rank_rotation(records, core, parents, 1, F(1, 4))
    # Also certify stationarity after one left and one right decision in sequence.
    final = defaultdict(F)
    for i in sorted(core):
        for j, alpha in left_kernel[i].items():
            for k, beta in right_kernel[j].items():
                final[k] += records[i].mass * alpha * beta
    assert all(final[i] == records[i].mass for i in core)
    return dict(n=n, real_parent_count=len(parents), original_physical_price_cells=cells,
                physical_component_layers=epochs,
                number_of_actual_degree_bins=len({geom.floor_log2(d[v]) for v in
                                                   {r.middle for r in records}}),
                raw_unfiltered_original_peak_mass=raw, frozen_nonproduct_R=deletion["true_R_mass"],
                pruning=deletion, frozen_core_rank_turns=[left, right],
                sequential_left_then_right_preserves_full_record_law=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    out = parser.add_mutually_exclusive_group()
    out.add_argument("--output", type=Path)
    out.add_argument("--check", type=Path)
    args = parser.parse_args()
    data = dict(
        arithmetic="Fraction exact, zero roundoff",
        python={"executable": sys.executable, "version": platform.python_version(),
                "architecture": platform.machine()},
        command="python -B core789.py --check core789.json",
        local_same_directory_dependency={"file": "merges789.py",
            "sha256": sha256(Path(geom.__file__).read_bytes()).hexdigest()},
        scope=("Finite real cube shapes, nonuniform real prices, disjoint owners, named "
               "weak diagnostic hard relation and a nonproduct frozen R. True R masses "
               "use the full d_v. Base at a side node is exactly the untouched original "
               "arm mark mass; component and true d_v octaves are retained. Both first "
               "entry levels are evaluated in the corresponding direction. Common "
               "component graph in this instance gives the same epoch on both sides."),
        threshold=("Midpoint at one-quarter of the distinct original side-node load ratios. "
                   "Membership test removes the entire remaining incident edges at a low node. "
                   "The numerical B=17/16 size growth cut is a finite diagnostic."),
        cases=[case(n, j) for j, n in enumerate((4, 8, 16), 1)])
    content = (json.dumps(data, sort_keys=True, indent=2, default=str) + "\n").encode()
    if args.output:
        args.output.write_bytes(content)
    elif args.check:
        if args.check.read_bytes() != content:
            raise SystemExit("certificate differs")
        print("core789: original peaks, deletion and stationary conditional turns agree")
    else:
        print(content.decode(), end="")


if __name__ == "__main__":
    main()

