"""R789: two real price paths, true original peaks, and the common F denominator."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import combinations, product
import json
from pathlib import Path
import platform
import sys


PERIOD = F(1, 8)
ETA = F(1, 4)


def total(xs):
    return sum(xs, F(0))


def prod(xs):
    out = F(1)
    for x in xs:
        out *= x
    return out


@cache
def mu1(lo, hi):
    if lo >= hi:
        return F(0)

    def primitive(x):
        j = x // PERIOD
        r = x - j * PERIOD
        return j * PERIOD + r / 2 + max(F(0), r - PERIOD / 2)

    return primitive(hi) - primitive(lo)


def mu(box):
    return prod(mu1(lo, hi) for lo, hi in box)


def intersection(box1, box2):
    return tuple((max(a, c), min(b, d)) for (a, b), (c, d) in zip(box1, box2))


def boxes(n, pressure):
    # Relative first two center coordinates, radius. Remaining centers zero.
    rows = [("L", F(-9, 4), F(0), F(1)), ("left", F(-5, 4), F(0), F(1)),
            ("connector", F(0), F(1, 4), F(1)),
            ("right", F(5, 4), F(0), F(5, 4)), ("R", F(9, 4), F(0), F(1))]
    if pressure >= 2:
        rows.append(("left2", F(-11, 8), F(0), F(1)))
    if pressure >= 3:
        rows += [("connector2", F(0), F(-1, 4), F(1)),
                 ("right2", F(11, 8), F(0), F(1))]
    pool = list(range(len(rows)))
    centers = list(range(len(rows), len(rows) + (1, 2, 4)[pressure - 1]))
    rows += [("middle0", F(0), F(0), F(3, 2)),
             ("middle1", F(1, 16), F(0), F(13, 8)),
             ("middle2", F(-1, 16), F(0), F(27, 16)),
             ("middle3", F(0), F(-1, 8), F(25, 16))][:(1, 2, 4)[pressure - 1]]
    rows += [("upper", F(0), F(51, 16), F(31, 16))]
    a = 32 * n
    A = [tuple((x - s, x + s) for x in (c, d) + (F(0),) * (n - 2))
         for _, c, d, s in rows]
    E = [tuple((x - s/a, x + s/a) for x in (c, d) + (F(0),) * (n - 2))
         for _, c, d, s in rows]
    m = [(2 * s)**n for _, _, _, s in rows]
    I = [(2 * s / a)**n for _, _, _, s in rows]
    assert list(map(mu, A)) == m
    assert all(prod(hi - lo for lo, hi in own) == I[i] for i, own in enumerate(E))
    assert all(any(lo >= hi for lo, hi in intersection(E[i], E[j]))
               for i, j in combinations(range(len(A)), 2))
    assert mu(intersection(A[0], A[4])) == 0
    hard = {}
    for i, j in product(range(len(A)), repeat=2):
        mass = mu(intersection(A[i], A[j]))
        if m[i] != m[j] and 0 < mass <= ETA * min(m[i], m[j]):
            hard[i, j] = mass / (m[i] * m[j])
    return rows, A, m, I, pool, centers, hard


def membership_cells(A):
    records = {(1 << len(A)) - 1: (F(1), ())}
    for axis in range(len(A[0])):
        intervals = [box[axis] for box in A]
        cuts = sorted({x for ab in intervals for x in ab})
        nxt = {}
        for lo, hi in zip(cuts, cuts[1:]):
            signature = sum(1 << i for i, (a, b) in enumerate(intervals) if a <= lo < hi <= b)
            weight = mu1(lo, hi)
            for known, (value, x) in records.items():
                member = known & signature
                if member:
                    have, sample = nxt.get(member, (F(0), x + ((lo + hi) / 2,)))
                    nxt[member] = have + value * weight, sample
        records = nxt
    return records


def mul(left, right):
    result = {}
    for x, row in left.items():
        acc = defaultdict(F)
        for z, a in row.items():
            for y, b in right[z].items():
                acc[y] += a * b
        result[x] = dict(acc)
    return result


class Walk:
    def __init__(self, full, m, I, pool):
        self.pool = pool
        self.m, self.I = m, I
        self.poolbits = sum(1 << i for i in pool)
        self.cells = defaultdict(F)
        for mask, (weight, _) in full.items():
            if mask & self.poolbits:
                self.cells[mask & self.poolbits] += weight
        self.H = {x: total(I[i] / m[i] for i in pool if x & (1 << i)) for x in self.cells}
        self.Lambda = {x: self.H[x] * weight for x, weight in self.cells.items()}
        self.Y = total(I[i] for i in pool)
        assert total(self.Lambda.values()) == self.Y
        self.pick = {x: {i: I[i] / (m[i] * self.H[x])
                         for i in pool if x & (1 << i)} for x in self.cells}
        self.redraw = {i: {z: value / m[i] for z, value in self.cells.items() if z & (1 << i)}
                       for i in pool}
        assert all(sum(row.values()) == 1 for row in self.pick.values())
        assert all(sum(row.values()) == 1 for row in self.redraw.values())
        P = mul(self.pick, self.redraw)
        for x, z in product(self.cells, repeat=2):
            assert self.Lambda[x] * P[x].get(z, 0) == self.Lambda[z] * P[z].get(x, 0)
        assert all(sum(row.values()) == 1 for row in P.values())
        self.powers = [{s: {s: F(1)} for s in self.cells}, P]
        for step in range(2, 17):
            self.powers.append(mul(self.powers[step - 1], P))
        self.last_parent = [None] + [mul(self.powers[j - 1], self.pick) for j in range(1, 9)]
        self.parent_meeting = {(i, k): total(weight / (self.H[x] * m[i] * m[k])
                                                  for x, weight in self.cells.items()
                                                  if (x & (1 << i)) and (x & (1 << k)))
                               for i, k in product(pool, repeat=2)}

    def two_path(self, x, z, j, k):
        a, b = self.last_parent[j][x], self.last_parent[k][z]
        by_true_intersection = total(p * q * self.parent_meeting[i, l]
                                     for (i, p), (l, q) in product(a.items(), b.items()))
        by_reversible_price_kernel = self.powers[j + k][x].get(z, 0) / self.Lambda[z]
        assert by_true_intersection == by_reversible_price_kernel
        return by_true_intersection

    @cache
    def visits(self, x, targets, horizon):
        if not x:
            return F(0), F(0)
        no_hits = {x: F(1)}
        repeat_charge = F(0)
        first_hits = []
        for j in range(1, horizon + 1):
            repeat_charge += total(p for i, p in self.last_parent[j][x].items()
                                   if targets & (1 << i))
            next_no_hits = defaultdict(F)
            newly_found = F(0)
            for s, probability in no_hits.items():
                for i, p in self.pick[s].items():
                    if targets & (1 << i):
                        newly_found += probability * p
                    else:
                        for z, q in self.redraw[i].items():
                            next_no_hits[z] += probability * p * q
            no_hits = next_no_hits
            first_hits.append(newly_found)
        ran = sum(first_hits)
        assert ran == 1 - total(no_hits.values()) <= repeat_charge
        return ran, repeat_charge

    def time_envelopes(self, x, y):
        meeting = {(j, k): self.two_path(x, y, j, k) for j, k in product(range(1, 9), repeat=2)}
        h = {s: self.powers[s][x].get(y, 0) / self.Lambda[y] for s in range(2, 17)}
        assert h[2] == 0 and h[4] > 0
        result = []
        for T in (3, 5, 8):
            envelope = total(2 * h[s] / s for s in range(2, 2 * T + 1))
            quantities = []
            for p, q in product(range(1, T + 1), repeat=2):
                multiplicity = {s: sum(1 for j in range(1, p + 1) if 1 <= s - j <= q)
                                for s in range(2, 2 * T + 1)}
                assert all(F(v, p*q) <= F(2, s) for s, v in multiplicity.items())
                a = total(meeting[j, k] for j, k in product(range(1, p + 1), range(1, q + 1))) / (p*q)
                b = total(F(v, p*q) * h[s] for s, v in multiplicity.items())
                assert a == b < envelope
                quantities.append((a, p, q))
            best, p, q = max(quantities)
            result.append(dict(T=T, verified_time_pairs=T*T, maximizing_p_q=[p, q],
                               actual_max_times_pool_Y=best * self.Y,
                               upper_sum_2_hs_over_s_times_pool_Y=envelope * self.Y,
                               actual_over_upper=best / envelope))
        return dict(each_step_pair_identity_count=len(meeting),
                    h_2_and_h_4_times_pool_Y=[h[2]*self.Y, h[4]*self.Y],
                    h_s_times_pool_Y={s: value*self.Y for s, value in h.items()},
                    time_checks=result)


def original_peaks(A, m, I, centers, hard, full):
    alpha = {(i, x): I[i] * w / m[i] for x, (w, _) in full.items()
             for i in range(len(A)) if x & (1 << i)}
    for i in range(len(A)):
        assert total(w for (u, _), w in alpha.items() if u == i) == I[i]
    deg = {v: total(I[u] * value for (k, u), value in hard.items() if k == v)
           for v in centers}
    B = {v: {a for a in alpha if a[1] & (1 << v) and (v, a[0]) in hard and m[a[0]] < m[v]}
         for v in centers}
    dminus = {v: total(alpha[a] for a in B[v]) / m[v] for v in centers}
    for v in centers:
        assert dminus[v] == total(I[u] * value for (k, u), value in hard.items()
                                  if k == v and m[u] < m[v])
        assert 0 < dminus[v] < deg[v] and {u for u, x in B[v]} == {0, 4}
    F_ab, raw = defaultdict(F), {}
    for v in centers:
        for a, b in product(sorted(B[v]), repeat=2):
            mass = I[v] * alpha[a] * alpha[b] / (m[v]**2 * deg[v])
            raw[v, a, b] = mass
            F_ab[a, b] += I[v] / m[v]
        assert total(q for (j, a, b), q in raw.items() if j == v) == I[v]*dminus[v]**2/deg[v]
    observed = defaultdict(F)
    for (v, a, b), q in raw.items():
        observed[a, b] += q * m[v] * deg[v]
    assert all(observed[a, b] == alpha[a] * alpha[b] * f for (a, b), f in F_ab.items())
    return alpha, deg, dminus, B, F_ab, raw


def f_normalization(walk, alpha, deg, F_ab, raw, m, I):
    Y = total(alpha.values())
    checks = []
    for horizon in (1, 3, 5):
        h = {(x, i): p / I[i] for x, law in walk.last_parent[horizon].items()
             for i, p in law.items()}
        # Final label+price redraw, relative to actual alpha; no v or b is read.
        for a in alpha:
            x = a[1] & walk.poolbits
            assert total(w * h.get((x, i), 0) for (i, t), w in alpha.items()) == int(bool(x))
        appropriate = local_only = F(0)
        for (v, a, b), q in raw.items():
            value = h.get((a[1] & walk.poolbits, b[0]), 0)
            if value:
                weighted = q * m[v] * deg[v] * value
                appropriate += weighted / F_ab[a, b]
                local_only += weighted / (I[v] / m[v])
        direct = total(alpha[a] * alpha[b] * h.get((a[1] & walk.poolbits, b[0]), 0)
                       for a, b in F_ab)
        assert 0 < appropriate == direct <= Y and local_only >= appropriate
        checks.append(dict(horizon=horizon, original_divide_by_all_centers_F=appropriate,
                           direct_alpha_product_on_F_positive=direct, Y=Y,
                           fraction_of_Y=appropriate/Y, erroneous_separate_F_per_center=local_only))
    return checks


def exact_mask(A, point):
    return sum(1 << i for i, box in enumerate(A)
               if all(lo <= x <= hi for (lo, hi), x in zip(box, point)))


def case(n, pressure):
    names, A, m, I, pool, centers, hard = boxes(n, pressure)
    full = membership_cells(A)
    walk = Walk(full, m, I, pool)
    alpha, deg, dminus, B, F_ab, raw = original_peaks(A, m, I, centers, hard, full)
    y = (F(-11, 8),) + (F(0),) * (n - 1)
    z = (F(11, 8),) + (F(0),) * (n - 1)
    y_full, z_full = exact_mask(A, y), exact_mask(A, z)
    a, b = (0, y_full), (4, z_full)
    assert y_full in full and z_full in full
    assert all(a in B[v] and b in B[v] for v in centers)
    x, g = y_full & walk.poolbits, z_full & walk.poolbits
    marked_targets = sum(1 << i for i in pool if g & (1 << i) and
                         (i, b[0]) in hard and m[b[0]] < m[i])
    assert g and not marked_targets
    witness = []
    for step in (1, 2, 3, 5):
        occurrence, repeated = walk.visits(x, g, step)
        strict, _ = walk.visits(x, marked_targets, step)
        witness.append(dict(steps=step, physical_source_visit_once=occurrence,
                            marked_b_in_B_w_visit_once=strict,
                            erroneous_repeat_visit_sum=repeated))
    assert not witness[0]["physical_source_visit_once"] and not witness[1]["physical_source_visit_once"]
    assert witness[2]["physical_source_visit_once"] > 0
    assert witness[3]["erroneous_repeat_visit_sum"] > witness[3]["physical_source_visit_once"]
    assert mu(intersection(A[0], A[4])) == 0
    raw_mass = total(raw.values())
    directed_apart = [(record, mass) for record, mass in raw.items() if record[1][0] != record[2][0]]
    apart_mass = total(mass for record, mass in directed_apart)
    by_step = {}
    for step in (1, 2, 3, 5):
        arrived = total(w * walk.visits(a[1] & walk.poolbits, b[1] & walk.poolbits, step)[0]
                        for (v, a, b), w in directed_apart)
        by_step[step] = arrived
    assert by_step[1] == by_step[2] == 0 < by_step[3] <= by_step[5] < apart_mass
    f_report = f_normalization(walk, alpha, deg, F_ab, raw, m, I)
    if len(centers) > 1:
        assert f_report[-1]["erroneous_separate_F_per_center"] > f_report[-1]["original_divide_by_all_centers_F"]
    return dict(n=n, rows_names_center01_radius=names, true_m=m, disjoint_owner_I=I,
                bridge_pool=pool, original_centers=centers,
                true_full_and_down_d_by_center=[deg, dminus],
                full_source_membership_masks=len(full), usable_bridge_source_masks=len(walk.cells),
                raw_peak_mass_all_centers=raw_mass, raw_peak_mass_different_disjoint_arms=apart_mass,
                raw_paid_projected_amount_by_steps_for_disjoint_arms=by_step,
                raw_paid_share_by_steps_for_disjoint_arms={s:w/apart_mass for s,w in by_step.items()},
                named_true_price_pair=dict(y=y,z=z, actual_original_mark_labels=[a,b],
                                           physical_endpoints=[0,4],
                                           exact_F_ab=F_ab[a,b], center_contributions=[I[v]/m[v] for v in centers],
                                           actual_original_q_by_center=[raw[v,a,b] for v in centers],
                                           source_only_and_marked_predictions=witness),
                independent_two_way_meeting=walk.time_envelopes(x, g),
                literal_h_and_shared_F_check=f_report)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--output", type=Path)
    mode.add_argument("--check", type=Path)
    opt = parser.parse_args()
    result = dict(
        arithmetic="Fraction exact, no float",
        python={"executable":sys.executable, "version":platform.python_version(),
                "architecture":platform.machine()},
        command="python -B bridge789.py --check bridge789.json",
        assumptions=("Actual nonuniform AC period-1/8 price with densities 1/2 and 3/2. "
                     "All C_i=A_i with mu(C_i)=m_i, actual E_i disjoint. Diagnostic hard pairs "
                     "have distinct physical sizes and true intersection at most eta=1/4 of "
                     "the smaller source mass. Read the true first price. The bridge pool "
                     "is fixed before the run and excludes all original larger centers."),
        counted_event=("One-hit union for any selected true bridge label i with z in C_i. "
                       "A flagged true right arm additionally requires its label to lie below i "
                       "and meet its actual hard condition. Current v and right b are absent "
                       "from the path transition."),
        cases=[case(4,1),case(8,2),case(16,3)])
    value = (json.dumps(result, indent=2, sort_keys=True, default=str) + "\n").encode()
    if opt.output:
        opt.output.write_bytes(value)
    elif opt.check:
        if opt.check.read_bytes() != value:
            raise SystemExit("certificate differs")
        print("bridge789: true peaks, exact meeting identity, times and common F agree")
    else:
        print(value.decode(),end="")


if __name__ == "__main__":
    main()

