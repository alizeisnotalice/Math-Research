"""R789: whole-row collision charges on genuine nonuniform cube inputs."""

import argparse
from dataclasses import dataclass
from fractions import Fraction as F
from functools import cache
from itertools import combinations, product
from math import comb, factorial
import json
from pathlib import Path
import platform
import sys

import flint
from flint import arb, ctx, fmpq


ctx.prec = 256
PERIOD, DELTA, ETA = F(1, 8), F(1, 128), F(1, 8)
RICH_EXPONENT, SEPARATION_EXPONENT = F(1, 6), F(6)


def ar(q):
    q = F(q)
    return arb(fmpq(q.numerator, q.denominator))


def total(xs):
    return sum(xs, F(0))


def prod(xs):
    out = F(1)
    for x in xs:
        out *= x
    return out


@cache
def primitive(x):
    k = x // PERIOD
    r = x - k * PERIOD
    half_spike = PERIOD / 32
    inside = min(half_spike, r) + max(F(0), r - (PERIOD - half_spike))
    return k * PERIOD + r / 16 + 15 * inside


def mu1(lo, hi):
    return primitive(hi) - primitive(lo) if hi > lo else F(0)


def cube(center, s):
    return tuple((z - s, z + s) for z in center)


def meet(g, h):
    return tuple((max(a, c), min(b, d)) for (a, b), (c, d) in zip(g, h))


def linear_volume(box):
    return prod(max(F(0), hi - lo) for lo, hi in box)


def source(box):
    return prod(mu1(lo, hi) for lo, hi in box)


def has(container, piece):
    return all(a <= c <= d <= b for (a, b), (c, d) in zip(container, piece))


def volume_bin(m):
    b = m.numerator.bit_length() - m.denominator.bit_length()
    return b - (F(2)**b > m)


@cache
def qualifies(ratio, exponent):
    test = ar(ratio)
    threshold = ar(-exponent).exp()
    assert test < threshold or test > threshold
    return test > threshold


@dataclass(frozen=True)
class Parent:
    label: int
    panel: int
    direction: int
    clone: int
    s: F
    c: tuple
    A: tuple
    E: tuple
    m: F
    I: F


def scenario(n, lengths):
    data = []
    frames = []
    a = 32 * n
    for p, k in enumerate(lengths):
        assert k + 3 <= n
        origin = (F(0),) * (n - 1) + (F(12 * p),)
        axis_a, axis_b = k + 1, k + 2

        def make(tag, clone, s):
            center = list(origin)
            for j in range(k + 1):
                center[j] += (s - DELTA) * (1 if j == tag else -1)
            if clone in (0, 1):
                center[axis_a if clone == 0 else axis_b] += F(1, 8)
            center = tuple(center)
            A = cube(center, s)
            E = cube(center, s / a)
            m = (2 * s)**n
            I = (2 * s / a)**n
            assert source(A) == linear_volume(A) == m
            assert linear_volume(E) == I and has(A, E)
            obj = Parent(len(data), p, tag, clone, s, center, A, E, m, I)
            data.append(obj)
            return obj

        small = [make(i, j, F(1) if j < 2 else F(17, 16))
                 for i, j in product(range(k), range(3))]
        v = make(-1, 4, F(3, 2))
        neighbor_above = make(k, 5, F(7, 4))
        frames.append((k, origin, (axis_a, axis_b), small, v, neighbor_above))
    assert all(any(b <= c or d <= a for (a, b), (c, d) in zip(x.E, y.E))
               for x, y in combinations(data, 2))
    return data, frames


def real_degree(v, family):
    arms = {}
    incident = {}
    for w in family:
        I = meet(v.A, w.A)
        j_mu = source(I)
        j_lebesgue = linear_volume(I)
        if w.panel != v.panel:
            assert j_mu == j_lebesgue == 0
        if volume_bin(v.m) == volume_bin(w.m) or not 0 < j_mu <= ETA * min(v.m, w.m):
            continue
        k = j_mu / (v.m * w.m)
        incident[w.label] = {"true_mu_intersection": j_mu, "true_Leb_intersection": j_lebesgue,
                             "I_times_real_K": w.I * k}
        if w.m < v.m:
            arms[w.label] = w.I * k
    d = total(r["I_times_real_K"] for r in incident.values())
    dminus = total(arms.values())
    assert 0 < dminus < d
    return d, dminus, incident, arms


@cache
def relative_body_volume(n, s, S, b):
    a = 32 * n
    cube_r = S - s + (s + S) / a
    l1_r = 2 * b * s
    # Disjoint choices of k outside-cube coordinates give 2^n times the polynomial.
    return total(comb(n, k) * (cube_r / S)**(n - k) * (l1_r / S)**k / factorial(k)
                 for k in range(n + 1))


def oriented_pair(x, y, n):
    u, g = sorted((x, y), key=lambda p: (p.m, p.label))
    geom = meet(u.A, g.A)
    j0, j1 = linear_volume(geom), source(geom)
    small = u.s
    difference = g.s - small
    delta = tuple(z - w for z, w in zip(u.c, g.c))
    leakage = tuple(max(F(0), abs(x) - difference) for x in delta)
    scale_factors = tuple(max(F(0), 1 - x / (2 * small)) for x in leakage)
    assert j0 / u.m == prod(scale_factors)
    leb_pass = qualifies(j0 / u.m, RICH_EXPONENT)
    mu_pass_6 = qualifies(j1 / u.m, SEPARATION_EXPONENT)
    leb_pass_6 = qualifies(j0 / u.m, SEPARATION_EXPONENT)
    volume_ratio, worst, extremal = None, None, None
    if leb_pass:
        # Each coordinate attains its maximum at the marked true E corners.
        signs = tuple(1 if z >= 0 else -1 for z in delta)
        U = tuple(x + z * u.s / (32 * n) for x, z in zip(u.c, signs))
        W = tuple(y - z * g.s / (32 * n) for y, z in zip(g.c, signs))
        assert all(a <= x <= b for x, (a, b) in zip(U, u.E))
        assert all(a <= x <= b for x, (a, b) in zip(W, g.E))
        base = difference + (u.s + g.s) / (32 * n)
        worst = total(max(F(0), abs(x - y) - base) for x, y in zip(U, W))
        assert worst == sum(leakage) <= 2 * RICH_EXPONENT * u.s
        volume_ratio = relative_body_volume(n, u.s, g.s, RICH_EXPONENT)
        extremal = (u.label, g.label, j0 / u.m, j1 / u.m, worst, base, U, W)
    return dict(leb=j0 / u.m, mu=j1 / u.m, leb_pass=leb_pass,
                mu_pass_6=mu_pass_6, leb_pass_6=leb_pass_6,
                volume_ratio=volume_ratio, owner_excess=worst, witness=extremal)


def actual_visible_choice(frame, degree, arms, n):
    k, origin, axes, small, v, _ = frame
    lefts, g = small[:2], small[2]
    Vg = meet(v.A, g.A)
    observed_price = cube(origin, DELTA / 2)
    assert has(Vg, observed_price)
    # The actual visible owner W is in a fixed true half of E_g.
    lo, hi = g.E[0]
    observed_owner = ((lo, (lo + hi) / 2),) + g.E[1:]
    owner_fraction = linear_volume(observed_owner) / g.I
    assert owner_fraction == F(1, 2)
    fraction_at_price = source(observed_price) / source(Vg)
    assert fraction_at_price > 0
    incoming = [v.I / degree * arms[u.label] * arms[g.label] *
                fraction_at_price * owner_fraction for u in lefts]
    assert incoming[0] == incoming[1] > 0
    prediction_boxes = []
    exact_raw_true_support = []
    for axis, u in zip(axes, lefts):
        shift = tuple(x - y for x, y in zip(u.c, g.c))
        assert shift[axis] == F(1, 8)
        padding = (u.s + g.s) / (32 * n)
        prediction_boxes.append(cube(shift, padding))
        exact_raw_true_support.append(tuple((x0 - y1, x1 - y0)
                                            for (x0, x1), (y0, y1) in zip(u.E, observed_owner)))
    assert all(has(c, true) for c, true in zip(prediction_boxes, exact_raw_true_support))
    assert linear_volume(meet(*prediction_boxes)) == 0
    charge_if_only_g_z_W_seen = max(incoming)
    charge_if_u_seen_before_selecting = sum(incoming)
    # Neither source z nor even the exact W within its observed half
    # changes these equal weights: the two right laws are identical.
    return dict(middle=v.label, given_actual_visible_big_parent=g.label,
                hidden_eligible_real_small_parents=[u.label for u in lefts],
                active_coordinate_choice=axes, exact_observed_price_box=observed_price,
                exact_visible_true_E_half=observed_owner, true_mu_price_fraction=fraction_at_price,
                strictly_positive_each_full_old_peak_on_fiber=incoming,
                given_only_g_exact_z_and_W_best_one_box=charge_if_only_g_z_W_seen,
                given_u_before_selecting_box=charge_if_u_seen_before_selecting,
                visible_vs_revealed_charge_ratio=charge_if_only_g_z_W_seen /
                charge_if_u_seen_before_selecting,
                available_disjoint_displacement_boxes=prediction_boxes,
                each_box_Leb_over_m_large=linear_volume(prediction_boxes[0]) / g.m)


def row(n, family, frame):
    k, _, _, small, v, upper = frame
    d, down, incident, arms = real_degree(v, family)
    assert set(arms) == {a.label for a in small}
    assert set(incident) == set(arms) | {upper.label}
    expected_Q = v.I * down**2 / d
    peak = rich = rich_other_label = dense_only = rich_6 = rich_mu_6 = F(0)
    largest_ratio = largest_ratio_at_6 = F(0)
    distortion = F(0)
    witness_body = witness_density = None
    pairs = {}
    for i, x in enumerate(small):
        for y in small[i:]:
            pairs[x.label, y.label] = oriented_pair(x, y, n)
    for x, y in product(small, repeat=2):
        state = pairs[tuple(sorted((x.label, y.label)))]
        weight = (v.I * arms[x.label] / d) * arms[y.label]
        assert weight > 0
        peak += weight
        if state["leb_pass"]:
            assert x.direction == y.direction
            rich += weight
            if x.label != y.label:
                rich_other_label += weight
            largest_ratio = max(largest_ratio, state["volume_ratio"])
            if state["owner_excess"] and witness_body is None:
                witness_body = state["witness"]
        else:
            assert x.direction != y.direction
        if state["leb_pass_6"]:
            rich_6 += weight
            s, L = sorted((x.s, y.s))
            largest_ratio_at_6 = max(largest_ratio_at_6, relative_body_volume(n, s, L, F(6)))
        if state["mu_pass_6"]:
            rich_mu_6 += weight
            if not state["leb_pass_6"]:
                dense_only += weight
                if witness_density is None:
                    witness_density = [x.label, y.label, state["leb"], state["mu"]]
        if state["leb"]:
            distortion = max(distortion, state["mu"] / state["leb"])
    clusters = [total(arms[u.label] for u in small if u.direction == i) for i in range(k)]
    assert min(clusters) == max(clusters)
    by_row = v.I / d * total(w**2 for w in clusters)
    assert 0 < rich_other_label < rich == by_row == peak / k and peak == expected_Q
    assert witness_body and witness_density and dense_only > 0
    assert largest_ratio < 1
    assert distortion >= F(121, 16)**2
    return dict(middle=v.label, upward_label_in_full_degree=upper.label, n=n,
                direction_groups=k, genuine_downward_labels=len(arms),
                m_v=v.m, I_v=v.I, d_v=d, d_minus=down,
                actual_K_and_intersection_by_incident_label=incident,
                one_group_arms=[arms[u.label] for u in small[:3]],
                original_Q_peak_mass=peak, actual_rich_pair_mass=rich,
                actual_rich_pair_mass_distinct_endpoints=rich_other_label,
                actual_nonrich_peak_mass=peak - rich, collision_probability=rich / peak,
                collision_probability_formula=F(1, k),
                most_expensive_allowed_probe_body_Leb_over_actual_m_large=largest_ratio,
                coarse_exp6_probe_body_Leb_over_m_large=largest_ratio_at_6,
                distinct_parent_witness_ug_Leb_fraction_mu_fraction_excess_Binf_radius_U_W=witness_body,
                largest_true_mu_to_true_Leb_intersection_distortion=distortion,
                coarse_6_gate_mass_using_Leb=rich_6, coarse_6_gate_mass_using_mu=rich_mu_6,
                extra_misclassified_by_using_mu_at_6=dense_only,
                coarse_6_witness_endpoints_Leb_fraction_mu_fraction=witness_density,
                visible_information_test=actual_visible_choice(frame, d, arms, n))


def profile(n, lengths):
    family, frames = scenario(n, lengths)
    rows = [row(n, family, frame) for frame in frames]
    threshold = total(r["collision_probability"] for r in rows) / len(rows)
    Q = total(r["original_Q_peak_mass"] for r in rows)
    paid, rest = [r for r in rows if r["collision_probability"] >= threshold], [
        r for r in rows if r["collision_probability"] < threshold]
    paid_Q = total(r["original_Q_peak_mass"] for r in paid)
    paid_coll = total(r["actual_rich_pair_mass"] for r in paid)
    paid_other = total(r["actual_nonrich_peak_mass"] for r in paid)
    unpaid_Q = total(r["original_Q_peak_mass"] for r in rest)
    assert 0 < paid_Q == paid_coll + paid_other <= paid_coll / threshold
    assert 0 < unpaid_Q == Q - paid_Q and paid_other > paid_coll
    return dict(n=n, all_real_parent_count=len(family), two_distinguished_rows=rows,
                total_original_peak_mass=Q, collision_probability_diagnostic_threshold=threshold,
                whole_rows_paid_and_unpaid=[r["middle"] for r in paid] + [r["middle"] for r in rest],
                actual_whole_row_paid_and_remaining=[paid_Q, unpaid_Q],
                paid_to_total=paid_Q / Q,
                original_rich_and_nonrich_on_paid_rows=[paid_coll, paid_other],
                nonrich_share_in_paid_rows=paid_other / paid_Q,
                same_collision_charge_over_threshold=paid_coll / threshold,
                max_probe_body_Leb_ratio_in_either_row=max(
                    r["most_expensive_allowed_probe_body_Leb_over_actual_m_large"] for r in rows))


def report():
    assert mu1(-DELTA, DELTA) / (2 * DELTA) == F(121, 16)
    return dict(
        python={"executable": sys.executable, "version": platform.python_version(),
                "architecture": platform.machine(), "python_flint": flint.__version__},
        command="python -B geometry789.py --check geometry789.json",
        arithmetic="Fraction exact, Arb 256-bit comparisons only for exp diagnostic gates",
        geometry=("Two isolated panels. Each has k actual source directions with two "
                  "unit-radius parents shifted on distinct coordinates, one larger unshifted "
                  "arm, one center of radius 3/2 and its upper neighbor of radius 7/4. "
                  "The selected centers use all diagnostic incident neighbors in d_v. "
                  "All E are full disjoint cubes of radius s/(32n)."),
        source=("Period 1/8 on each independent coordinate. Base density 1/16 with "
                "15 added on a centered period spike of length period/16. Every "
                "full parent has its actual Lebesgue volume as source mass."),
        scope=("Finite true price and owner geometry, distinct volume bins and diagnostic "
               "source hard gate mu(I)<=eta*min(m); the full asymptotic entrance is outside "
               "the modeled acceptance. exp gate parameter 6 is only a contrast and can "
               "give a large prediction region."),
        gate_parameters=dict(eta=ETA, rich_b=RICH_EXPONENT,
                             contrast_b=SEPARATION_EXPONENT, internal_margin=DELTA),
        cases=[profile(8, (4, 5)), profile(16, (8, 12)), profile(32, (16, 24))])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    out = parser.add_mutually_exclusive_group()
    out.add_argument("--output", type=Path)
    out.add_argument("--check", type=Path)
    options = parser.parse_args()
    data = (json.dumps(report(), indent=2, sort_keys=True, default=str) + "\n").encode()
    if options.output:
        options.output.write_bytes(data)
    elif options.check:
        if options.check.read_bytes() != data:
            raise SystemExit("certificate differs")
        print("geometry789: all three true cube collision and prediction cases agree")
    else:
        print(data.decode(), end="")


if __name__ == "__main__":
    main()

