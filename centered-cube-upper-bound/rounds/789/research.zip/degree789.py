"""Audit of the actual same-degree traffic from larger middle cubes in round 789."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from flint import arb, fmpq, ctx
import json
from pathlib import Path

from merges789 import cells_and_marks, component_table, floor_log2, instances, intersection, total


def case(n, stage):
    p=instances(n,stage)
    labels=range(len(p))
    inter={(i,j):intersection(p[i],p[j],n) for i,j in product(labels,repeat=2)}
    d,down={},{}
    for v in labels:
        edges={u:inter[v,u]*p[u].owner/(p[v].m*p[u].m) for u in labels
               if p[u].m!=p[v].m and 0<inter[v,u]<=F(3,4)*min(p[v].m,p[u].m)}
        d[v]=total(edges.values())
        down[v]={u for u in edges if p[u].m<p[v].m}
    marks,_=cells_and_marks(p,n,down)
    epochs,table=component_table(p,inter,n,max(1,n//4),False)
    bins={v:floor_log2(d[v]) for v in labels if d[v] and down[v]}
    Y=total(z.owner for z in p)
    qset=set(bins.values())
    face=F(0)
    for a in marks:
        for m in sorted({p[v].m for v in a[1]}):
            face=max(face,total(p[v].owner for v in a[1] if p[v].m<=m)/m)
    G=defaultdict(F)
    bymid=defaultdict(lambda:defaultdict(F))
    records=[]
    for a,wa in marks.items():
        for b,wb in marks.items():
            mids=set(a[1]).intersection(b[1])
            j=table[a[0],b[0]][0]
            for v in mids:
                # A pre-existing nonproduct test on the two original price-mark histories.
                # It also depends on their memberships, so no independent arm redraw recovers it.
                phase=(a[0]+b[0]+v+len(a[1])*len(b[1]))%5
                survival=(F(0),F(1,4),F(1,2),F(3,4),F(1))[phase]
                if survival==0:
                    continue
                q=bins[v]
                key=(a,j,q)
                w=p[v].owner/p[v].m*survival
                bymid[key][v]+=w*wb
                G[key]+=w*wb
                M=p[v].m*d[v]
                records.append((key,v,b,wa*wb*w/M,M))
    assert G and all(sum(bymid[k].values())==s for k,s in G.items())
    dual=total(w*M/G[key] for key,v,b,w,M in records)
    expected=total(marks[a] for a,j,q in G)
    assert dual==expected and dual<=len(epochs)*len(qset)*Y
    raw=total(w for key,v,b,w,M in records)
    unweighted=defaultdict(lambda:defaultdict(F))
    tilted=defaultdict(lambda:defaultdict(F))
    for key,v,b,w,M in records:
        unweighted[key][v]+=w
        tilted[key][v]+=w*M
    distortion=F(0)
    for key, vv in bymid.items():
        norm=total(unweighted[key].values())
        tilt_norm=total(tilted[key].values())
        assert tilt_norm==marks[key[0]]*G[key]
        for v,val in vv.items():
            assert val/G[key]==tilted[key][v]/tilt_norm
        distance=total(abs(vv[v]/G[key]-unweighted[key][v]/norm) for v in vv)/2
        distortion=max(distortion,distance)
    # A data-specific smaller face bound is valid for precisely these finite inputs.
    # The proof uses the dimension-free common owner-volume upper bound in general.
    grow=F(17,16)
    factor=4*face*grow
    large_mass=F(0)
    high_records=0
    all_saturated=True
    peak_rema=F(0)
    maximum=F(0)
    for key,v,b,w,M in records:
        low=total(x for i,x in bymid[key].items() if p[i].m<=grow*p[v].m)
        high=G[key]-low
        maximum=max(maximum,low/(face*grow*M))
        assert low<=2*face*grow*M
        if G[key]>factor*M:
            high_records+=1
            assert 2*high>=G[key] and all(bins[i]==bins[v] for i in bymid[key])
            large_mass+=w
            peak_rema+=w*(1-factor*M/G[key])
            all_saturated=False
    # More severe diagnostic threshold. Cauchy or a conditional redraw is not used.
    ratios=sorted(G[key]/M for key,v,b,w,M in records)
    stress=ratios[len(ratios)//2]
    positive=[w for key,v,b,w,M in records if G[key]>stress*M]
    stress_left=total(w*(1-min(1,stress*M/G[key])) for key,v,b,w,M in records)
    assert stress_left>0 and sum(positive)>0
    return dict(n=n,positive_original_records=len(records),maximum_variation_between_true_and_size_weighted_mid_laws=distortion,active_degree_bins=len(qset),
                physical_epoch_count=len(epochs),original_Q=raw,
                column_sum_shared_by_all_middles=dual,independently_summed_paid_row_capacity=expected,
                data_specific_owner_prefix_constant=face,growth_ratio=grow,
                measured_max_low_mass_over_face_B_M=maximum,certified_upper_for_that_ratio=2,
                actually_tested_growth_fee_factor=factor,
                records_passing_growth_threshold=high_records,
                original_mass_share_above_growth_threshold=large_mass/raw,
                residual_at_growth_threshold_over_Q=peak_rema/raw,
                all_rows_fully_paid_under_finite_growth_test=all_saturated,
                diagnostic_median_threshold=stress,
                remaining_Q_share_at_median=stress_left/raw,
                relative_used_reference_mass=expected/Y)


def parameter_checks():
    ctx.prec=256
    coeff=F(3,2)*(F(1,2)+(1+F(1,2**12))/12)
    enc=arb(fmpq(coeff.numerator,coeff.denominator)).log()+arb(fmpq(11,100))
    assert enc<arb(fmpq(-1,50))
    aligned=[]
    for j,n in enumerate((4,8,16),1):
        p=instances(n,j)
        for x in p:
            assert all((16*w).denominator==1 for w in (x.c-x.s,x.c+x.s,-x.s,x.s))
        for a,b in product(p,repeat=2):
            volume=max(F(0),min(a.c+a.s,b.c+b.s)-max(a.c-a.s,b.c-b.s))*(2*min(a.s,b.s))**(n-1)
            assert intersection(a,b,n)==volume
        aligned.append({"n":n,"dilation":16,"physical_labels":len(p),"ordered_intersections":len(p)**2})
    return {"fixed_dilated_overlap_log_exponent":str(enc),"upper_comparison":"-1/50",
            "lower_model_integer_cell_checks":aligned,
            "scope":"The actual smoothed note models have unit mass per period in each coordinate. After dilation every full price-membership cell has integer endpoints. All their cell integrals then equal the product of the integer lengths, so original normalized ratios transfer. No conclusion about unaligned translates or the full lower-bound maximal level set."}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    group=p.add_mutually_exclusive_group(required=True)
    group.add_argument("--output",type=Path)
    group.add_argument("--check",type=Path)
    args=p.parse_args()
    results={"parameter_checks":parameter_checks(),"cases":[case(n,j) for j,n in enumerate((4,8,16),1)],
             "arithmetic":"Exact rational arithmetic, independent middle-sum and original-peak checks. The original test is nonproduct on the actual two arm marks. The tilted conditional law is checked against the original conditional law. The median test changes the payment threshold only; it does not imply the upward-witness conclusion."}
    data=(json.dumps(results,sort_keys=True,indent=2,default=str)+"\n").encode()
    if args.output:
        args.output.write_bytes(data)
    else:
        assert args.check.read_bytes()==data
        print("degree789: three exact checks of common-degree groups, weighted column budgets and physical growth bounds.")


if __name__=="__main__":
    main()
