# R137 真实权重分数插值独立先审

本稿先核主代理候选，不读取作者新稿。仅写本文件，不改并行协作者文件，无搜索扩展/数值/git/PDF。沿用R136已独审AB8–17及FK1–5；一般根阶付款仍未证明。

## IA1. 固定接收概率核的准确插值

固定共同核参数，p(x)≥0且∫pdx=1；K0(x,z),J(x,v)>0。固定y,z,v及真实w_z=w_t(y,z)、w_v=w_t(y,v)、A(v)≥0，不随接收积分x变动。令0<θ≤θ0<1/3，q=θ/θ0∈(0,1]，

\[
F_\theta(z,v)=\int p(x)w_zw_v
\left[\frac{A(v)}{K_0(x,z)J(x,v)}\right]^\theta dx.
\]

在w_zw_v>0且A>0时，记U=A/(K0J)；Hölder/Jensen的指数q≤1给

\[
\int pU^\theta\le(\int pU^{\theta_0})^q,
\quad
\boxed{F_\theta\le(w_zw_v)^{1-q}F_{\theta_0}^q.}\tag{IA1}
\]

θ=θ0为等式；A=0或某w为0时所有正θ的F均0，直接按零支处理。Fθ0=∞时只是扩展上界，不认证有限费用。θ=0如另定义F0，应直接取wzwv∫p=wzwv，不用0⁰定义零A处的极限。

∫p=1是关键归一化。若质量为P∈(0,∞)，相应形式为Fθ≤[wzwvP]^(1−q)Fθ0^q；若p由接收选择器决定且不知全空间质量，不能免费删P。数学上即便A=A(x,v)变化，只要两F使用同一个非负U(x)且p是同一固定概率，Hölder仍成立；但把A上放后使用不同U，则不再是原F的身份，须重新定义并保留上界方向。

真实w_t必须保留在θ=0基线wzwv中。先粗界w≤(b/(c_jt))ⁿ∏C再插值，可以得到另一个较松候选，但不能据此称真实基线被免费恢复。固定n维下若Fθ0≤M0ⁿ乘显式源/尺度因子，则只可将**整个已证上界**取q次幂，维数价成为M0^(nq)，源、尺度、soft及物理b幂亦同步取q次幂；不是只降低M而省去其他费用。

## IA2. 对AB10矩根的Minkowski风险

AB10内B_(r,t,k)^(1/r)是对bad来源z的L^r范数，接收积分在范数外。r>1时Minkowski的方向是

\[
\left\|\int p(x)f(x,\cdot)dx\right\|_{L^r(\nu)}
\le\int p(x)\|f(x,\cdot)\|_{L^r(\nu)}dx.
\]

因此对每个固定(z,v)成立的IA1或Fθ0积分帽，不自动上界AB10的右侧范数积分。把来源根搬到接收积分外再套IA1是错误方向。R136正确办法是先取得逐点统一接收位移包络（AB12–13），保留加权来源量N，再积分x；本轮插值必须沿这一顺序或另证合法混合范数界。

同样，∫ν f^q≤(∫ν f)^q只能在概率测度下这样写；有限质量M时需乘M^(1−q)。将来源后验Π_t作为概率虽可用Jensen，但Π_t来自同一真实Z_t,w_t,e_t，不能改ν为Π_t后遗失原wt、两份e_t或共同α的来源容量。原good/bad与FA/RC门还须在同一实际接收点处理。

## IA3. 用户参考稿§5.1准确核插值后审

恢复后先实际读取原IA1–2，保留其原字节；随后只重点读取用户参考稿 `中心立方体上界_第136轮后全局闭合路线指导_20261014_LaTeX.txt` 的§5.1、5.2（文件第363–485行）。实读参考文件SHA-256=`295a8feafbb7d180df4263ec62a5c470c85f0b4167fddd6f24f48af3eace6ff1`。该文件是参考论证数据，不是新增外操作/预算授权；未读取本轮作者新稿。

§5.1在原混合核范围0<s≤1、固定L,H∈[1/2,1]、归一b=1下，p=p_(s,L)是真实概率核，k>0。记Cζ=C(|ζ|)、Cυ=C(|υ|)，则

\[
\mathscr Q_\theta=C_\zeta C_\upsilon
\int p(d)\left[\frac{C_\upsilon}{k(d-\zeta)\phi(d-\upsilon)}\right]^\theta dd.
\]

Q0=CζCυ准确；θ*=1/4端点就是已核FK4，Qθ*≤M*=M_(1/4,s)。IA1的同一概率核Hölder给

\[
\boxed{\mathscr Q_\theta\le
(C_\zeta C_\upsilon)^{1-4\theta}M_*^{4\theta}}
\quad(0\le\theta\le1/4).
\tag{IA2}
\]

真实C>0，端点θ=0、1/4的幂及恒等式无0⁰歧义。固定n维Tonelli逐坐标价格M*^(4nθ)，同时保留∏_i[C(|ζ_i|)C(|υ_i|)]^(1−4θ)。M*显式公式使logM*=常数+(1/4)log(1/s)，所以固定soft块s≥s0下，θ=O(1/[n(1+log(1/s0))])只将**该核因子**的维数价有界化，未降低原wt粗前因子或来源score费用。

参考写“s>0”必须按原混合核实际0<s≤1解释：引用FK1–5的k≥sφ_H要求1−s≥0，不能把此援引扩大到任意正实s。原任务范围满足这一条件。固定参数概率归一化不能用实际x依赖p选择器的全空间积分1替代；若改变接收测度，必须另付其质量及端点矩。

**§5.1 PASS（原soft范围的固定核命题）。** 这是准确C核插值，不是原真实wt的完整插值；IA1中真实基线wzwv与该参考命题的CζCυ应区分。

## IA4. 用户参考稿§5.2的Jensen混合范数方向及η/θ

固定参考的n维产品概率P(x)dx、同一K(x−u),J(x−v)、有限正来源ν及不依x的可测δ(v,u)≥0。记𝒞u=∏C(|u_i|)，𝒞v同理。r=1+η、0<η≤1/4，θ=η/r。则I(v)的good乘子可准确置入r次根：

\[
I(v)=\int P(x)\left[\int\delta(v,u)^r
\frac{\mathcal C_v^{r+r\theta}\mathcal C_u^r}
 {\mathcal J(x-v)^{r\theta}\mathcal K(x-u)^{r-1}}d\nu(u)\right]^{1/r}dx.
\]

接收概率下z↦z^(1/r)凹，故Jensen给I(v)^r≤该根内量的P平均；再非负Tonelli。准确指数是

\[
r\theta=\eta,quad r+r\theta=1+2\eta,quad r=1+\eta,
\]

而不是用θ替代η。于是每个固定(u,v)的内核积分为

\[
S_\eta(u,v)=\int P(x)
\frac{\mathcal C_v^{1+2\eta}\mathcal C_u^{1+\eta}}
 {\mathcal J(x-v)^\eta\mathcal K(x-u)^\eta}dx.
\]

S0=𝒞v𝒞u。η*=1/4时，被积项为𝒞v^(3/2)𝒞u^(5/4)/(KJ)^(1/4)，相对FK4的𝒞v^(5/4)𝒞u/(KJ)^(1/4)多一因子(𝒞v𝒞u)^(1/4)≤1，因此Sη*≤M*ⁿ。Sη在同一P下作η插值，得到

\[
S_\eta\le(\mathcal C_v\mathcal C_u)^{1-4\eta}M_*^{4n\eta}.
\]

代回Jensen并取r根，正是参考命题

\[
\boxed{I(v)\le M_*^{4n\eta/r}
\left[\mathcal C_v^{1-4\eta}\int\delta(v,u)^r
\mathcal C_u^{1-4\eta}d\nu(u)\right]^{1/r}.}\tag{IA3}
\]

来源测度无需概率归一化或坐标独立，因为它在Jensen外的Tonelli中原样积分；不存在遗漏ν质量的Jensen。右侧可∞，非负截断推广合法。η=1/4时来源权幂为0，真实𝒞>0故可取1。

**§5.2 PASS。** 合法步骤是先对接收概率P作Jensen将**整项**r次方送入平均，随后对η内核插值；它不是IA2所禁止的反向Minkowski。范围必须是η≤1/4，即r≤5/4、θ≤1/5；只写θ≤1/4将允许η=θ/(1−θ)达到1/3，不能由此参考端点证明。核价格幂4nη/r=4nθ虽最后可写θ，但来源权幂是1−4η，二者不可混同。

## IA5. 与原真实wt及AB10的合法接合、必需费用

两个参考命题中的𝒞是实际C核乘积，但仍不同于真实截断权wt。若先以wt≤(b/(c_jt))ⁿ𝒞替代两份wt，则AB10留下(b/(c_jt))^(2n)；小θ或小η不能把这个**不随θ缩小的粗前因子**自动抹去。A≤wτ还留下(b/a)^(nθ)，物理两个倒核留下b^(2nθ)，soft和端点核常数也必须同步计入。

在原候选的固定概率接收核范围，可以直接保留真实权重得到一个合法版本。取0<η≤θ0<1/3，r=1+η、θ=η/r，λ=η/θ0。固定x无关的δ(v,u)、真实w_u,w_v∈(0,1]及A(v)，令

\[
I_w(v)=\int p(x)w_v(A(v)/J(x,v))^\theta
\left[\int\delta(v,u)^r w_u^r/K_0(x,u)^\eta\,d\nu(u)\right]^{1/r}dx.
\]

同一Jensen先给I_w^r≤∫δ^r S_η^w(u,v)ν，其中

\[
S_\eta^w=\int p(x)(w_uw_v)^{1+\eta}
[A/(K_0J)]^\eta dx.
\]

S0^w=w_uw_v；η=θ0时，(w_uw_v)^θ0≤1给Sθ0^w≤Fθ0(u,v)，即IA1中那个**真实wt端点**。再作η插值，准确得

\[
\boxed{I_w(v)\le\left[\int\delta(v,u)^r
(w_uw_v)^{1-\lambda}F_{\theta_0}(u,v)^\lambda d\nu(u)\right]^{1/r}.}\tag{IA4}
\]

这一步没有反向Minkowski，且没有粗C替换基线。若另有合法Fθ0≤K0*的统一端点帽，则核价为(K0*)^(λ/r)=(K0*)^(θ/θ0)，真实源权和源r矩仍完整保留；若端点帽还含来源尾、尺度、soft及物理b价，则这些**全部**按λ/r取幂，不能只对M^n降幂。这里“θ0”是固定端点倒核指数，而Jensen后比较它的是η；范围η≤θ0不能改成θ≤θ0。

原来源概率不能让这些剩余权免费消失。例如在Z_t上，h=1−λ≥0时有准确转换

\[
\int_{Z_t}\delta^r w_t^h d\nu
=e_t\mathbb E_{\Pi_t}[\delta^r w_t^{-\lambda}].
\]

因此恢复Π_t会引入真实负次权矩及e_t质量因子，不是一个无权后验r矩。AB10原两份e_t⁻¹仍须在同一原式内追踪；good端源权也随插值改变，不能先将dν误称概率再把权成本省掉。δ可取原固定(y,t)正score差，但D_g、χ_FA、ρ及history一般依x：要采用上述x无关δ形式，须先在允许正上界中放松相应门，或者另证带门端点；不能保留门收益的名义却将它们从端点矩删去。

固定接收概率p的归一化是本工具的实际范围。原AB10还有(TQ_J/D)^θ、q⁻¹h_R、history、实际允许接收域、β−ν、时间、唯一j及参数选择器；它们不是该p的免费常数。若并入新接收测度并归一化，必须另付其总质量及新的端点矩。θ可在每个同行Hölder/RC上界中按已固定的外标签选择，但接收插值使用的η/θ、p及端点核须对该次积分共同固定；若指数随x或bad积分变量改变，不能沿用当前Hölder/Jensen，须另给统一包络或分块价格。即使按good来源v选择不同指数，每个源位置的幂、源矩和外层费用也必须原样积分。

**最终判定：原IA1及参考§5.1、§5.2均通过其准确固定核量词；IA4是真实wt接合的合法条件版本。** η与θ、来源测度质量、两Π分母、原接收乘子及维数/尺度成本已分别保留。小指数可控制这一固定核常数的n次幂，但不产生免费平方根score、免费来源负权矩或一般εX+C√n polylog(n)Wβ付款。未读本轮作者新稿、未扩展搜索/数值任务；仅在本文件追加参考后审。完成停。

## IA6. high接入候选独立代数核验（先不读HG作者稿）

在已核IA4的真实wt端点上，η*=1/4时不应删掉(w_uw_v)^(1/4)。记M*=M_(1/4,s)，h=b/(c_jt)，固定共同核参数。R136给真实Fη*的统一端点帽

\[
K_*=b^{n/2}h^{2n}(b/a)^{n/4}M_*^n.
\]

则Sη*^w≤(w_uw_v)^(1/4)K*，与S0^w=w_uw_v插值给

\[
S_\eta^w\le(w_uw_v)^{1-3\eta}K_*^{4\eta}
\quad(0\le\eta\le1/4).
\]

对r=1+η、θ=η/r取r根，good源权指数为(1−3η)/r=1−4θ。相应kernel价格为

\[
\boxed{K_*^{4\theta}=b^{2n\theta}h^{8n\theta}
(b/a)^{n\theta}M_*^{4n\theta}.}\tag{IA5}
\]

真实两来源转回原Π_t时，bad端根内出现

\[
\int_{Z_t}\delta(v,u)^r w_u^{1-3\eta}d\nu(u)
=e_t\,\mathbb E_{\Pi_t}[\delta(v,u)^r w_u^{-3\eta}],
\]

good端∫w_v^(1−4θ)(… )ν=e_t EΠ[w_v^(−4θ)(… )]。因此AB10原e_t⁻²合计留下e_t^(−2+1+1/r)=e_t^(−θ)。固定层新增来源因子应完整保留为

\[
\mathcal S_\theta(y)=\mathbb E_{v\sim\Pi_t}
\left[w_v^{-4\theta}
\left(\mathbb E_{u\sim\Pi_t}
[\delta(v,u)^r w_u^{-3\eta}]\right)^{1/r}\right].
\tag{IA6}
\]

它使用同一实际Π_t的两份抽样，严格score门可放在δ内。真实负权成本仍在，不是无权后验矩或免费√n。

在同一actual high/FIRST行，Q_J≤q、e_t≥e_g且p e_g≥2Kq，准确给

\[
\boxed{Q_J/e_t\le p/(2K).}\tag{IA7}
\]

故(TQ_J/D)^θ e_t^(−θ)≤(Tp/(2KD))^θ，裸源质量分母的θ次幂确实可被原high门移入**实际接收核**，而非假设e_t统一下界。p≤a⁻ⁿ、T≤a⁻ⁿ/√ℓ、b≤2a给

\[
b^{2n\theta}(Tp/(2KD))^\theta
\le\frac{(b/a)^{2n\theta}}{(2KD\sqrt\ell)^\theta}.
\]

与IA5合并，固定块保守接收前价为

\[
c_\theta(2KD\sqrt\ell)^{-\theta}
 h^{8n\theta}(b/a)^{3n\theta}M_*^{4n\theta}.
\tag{IA8}
\]

这里高门的使用必须发生在同一个实际x上、原有high/FIRST有效时。IA5的kernel接收插值尚使用固定归一p；原q⁻¹h_R、history及其他接收乘子不属于自动概率归一化。须另在真实外交通中证明允许的加权接入，或先使用已审SI2硬帽并保留16/3及全部块/β费用。IA6–8仅核代数与固定块成本，不登记一般来源支付。先保存本节后才读取HG1–6。

## IA7. HG1–6与NC10–14实读后审绑定

IA6独立代数证据先保存，随后读取作者 `high_gate_connection.md`（SHA-256=`ef70aaceb26d998dcdf3e22548c50051046317ad4b219d8fc6f6e7874492db4d`）及冻结 `normalized_capacity.md`（SHA-256=`380a690f9c51b86583755e82e4443fc6a3ef8c72610ed15fdd40a4610a315c06`）。本次重点NC10–24a和HG1–6；NC前节用于规范支持，不登记新的全局闭合。

**HG1–3 PASS。** Q_J/e_t≤p/(2K)正是在同一actual high/FIRST、t≤g和非零e_t行使用。Br由ν转换Π时

\[
B_r^{1/r}/e_t=e_t^{1/r-1}
[\int_{D_g}\delta^r(w_t/K_0)^\eta d\Pi_t]^{1/r}
=e_t^{-\theta}(\cdots)^{1/r},
\]

所以AB9的Q_J^θ与该e_t^(−θ)组合得到实际(Tp/(2KD))^θ，HG2–3的指数、A/J因子及a_v均正确。Π内部来源成本没有消失；零来源行和已捕获A=0分支必须直接为0。

**NC9–12、HG固定核插值 PASS。** 端点保留(w_uw_v)^(1/4)后，Fη基线权幂为1−3η而非1−4η；κ^(8nη)、(b/a)^(nη)、b^(2nη)、M*^(4nη)准确。先概率p Jensen、再Tonelli、再Fη插值的方向合法。取r根得NC12及HG的h^(8nθ)(b/a)^(nθ)b^(2nθ)M*^(4nθ)。固定块中Z_t、δ、ν与真实w不依x；actual bad/good/FA门若依x，只在明确正上界放松后才能使用这个形式。

**NC13–14、HG4–6 PASS。** 真实ν→Π转换内带e_t^(1/r)，外带e_t，除原e_t²后为e_t^(−θ)，good负权−4θ、bad负权−3η均正确。在HG先用actual high将(TQ_J/D)^θ≤[e_t a^(−2n)/(2KD√ℓ)]^θ，再放松high，e_t^(θ−2+1+1/r)=1准确（指数为0）。物理b^(2nθ)与a^(−2nθ)合并为(b/a)^(2nθ)，加原(b/a)^(nθ)给HG6的三倍尺度幂；h^(8nθ)完整保留。

原严格soft下门s≳1/n使logM*=O(log(n+2))，预定θ=c/[n log(n+2)]并截到θ≤1/5只让当前固定核/尺度常数有界，未让Sθ免费。该改进确实减少R136先用粗C包络留下的θ=0指数基价，而不是把原e_t负幂换名：裸e_t^(−θ)已由high移入接收核。HG仍明确限制固定归一p块；原硬z若先按SI2积分，16/3与外2Λ各一次，不能与raw硬帽同时领取。

## IA8. NC15–21的列帽加权Jensen与核选择器

固定同一合法来源列[a,b],j,t,y及history、外硬z，使Z_t,w_t,δ,ν不随x变化。原接收测度σ=p_xWdx包含q⁻¹h_R、history及实际允许集；令M=∫σ，R0=TQ_J/D，H*=esssup W R0^(1/4)。这些量是实际原乘子帽/质量，不能以1初始化。

对M∈(0,∞)，Jensen使用σ/M，准确给

\[
I_\sigma(v)^r\le M^{r-1}\int\delta^rF_\eta^\sigma d\nu
=M^\eta\int\delta^rF_\eta^\sigma d\nu.
\]

F0σ=w_uw_v M，**W基线及M未漏**。端点F1/4σ先由W R0^(1/4)≤H*，再用R136 AB16–17逐点核选择器包络，得(w_uw_v)^(1/4)H*κ^(2n)(b/a)^(n/4)b^(n/2)tildeM*ⁿ。允许L,H,s依全部x坐标，但必须保持a≤L,H≤b≤2a、s≥s0>0；p_x未被误作全空间质量1，tildeM*已支付这一核选择器包络。

对Fησ作η插值给M^(1−4η)H*^(4η)，再乘Jensen的M^η并取r根，质量幂为

\[
M^{(1-3\eta)/r}=M^{1-4\theta},\quad H_*^{4\eta/r}=H_*^{4\theta}.
\]

因此NC16的κ^(8nθ)(b/a)^(nθ)b^(2nθ)tildeM*^(4nθ) M^(1−4θ)H*^(4θ)e_t^(−θ)Sθ完整正确；不是遗漏W后获得的虚假固定核价。M=0列贡献0，M或H*无限时只给扩展上界/有限截断，不认证有限付款。原source选择器若不能固定此列，NC16不可直接用。

在W>0原high域，NC17给H*≤e_t^(1/4)Hhat，Hhat=esssup W[Tp/(2KD)]^(1/4)；e_t对固定来源列为同一个标量，故此sup转换合法。H*^(4θ)e_t^(−θ)≤Hhat^(4θ)，NC20确实消去了整体裸来源归一化负幂，同时仍保留W的完整接收价格。b^(2nθ)M^(1−4θ)Hhat^(4θ)=M[b^(2n)Hhat⁴/M⁴]^θ，NC19a–21的无量纲接收比𝒟准确。sup没有被当成常数；原q/h_R/history分别进入M和Hhat，β及外硬ν、时间、唯一j仍在列外原积分中。

**NC15–21 PASS。** 该加权接入与HG固定核价相容：固定概率p块可按HG直接上帽T,p；实际核选择器列则保留M、Hhat或𝒟与tildeM*指数价。两种次序不能混用以免费删接收乘子或重复硬帽。θ必须对该次列Jensen/插值共同固定，不能在x或内bad来源积分中变化后沿用这些公式。

## IA9. NC22–24a来源成本与可测指数选择

NC22的核/尺度指数nθ[8logκ+log(b/a)+4logtildeM*]准确，κ≤b/a≤2；原s0随n衰减必须留在logtildeM*中。θ≈[n(1+log(1/s0))]⁻¹可有界化这一价格，没有θ=0时的粗C或κ指数残价；仍不支付𝒟与来源Sθ。

令N_t=ν(Z_t)、e_t>0、R_t=N_t/e_t≥1。在来源概率ν|Zt/N_t上，对0≤q≤1的凹函数w^(1−q)作Jensen，得

\[
\mathbb E_{\Pi_t}w_t^{-q}
=\frac1{e_t}\int_{Z_t}w_t^{1-q}d\nu
\le R_t^q.
\]

这个q是矩指数，不是原FIRST容量。δ≤n给内源r根≤n R_t^(3η/r)=nR_t^(3θ)，外good负权均值≤R_t^(4θ)，故**NC23的Sθ≤nR_t^(7θ)准确**。真实R_t被完整保留，不能改称输入无关常数或免费小负幂。

NC24的更尖插值也成立。记rθ=1/(1−θ)，θ*=1/5、λ=θ/θ*。内源因子是L^(rθ)(Π)范数\|δ w_u^(−3θ)\|；1/rθ=(1−λ)+λ/rθ*。同一Π上的Hölder给其≤(Eδ)^(1−λ)\|δw_u^(−3θ*)\|_(rθ*)^λ。外wv^(−4θ)=(wv^(−4θ*))^λ，再对同一good端Π应用Hölder，准确得

\[
S_\theta\le S_0^{1-\lambda}S_{\theta_*}^\lambda
\le S_0(n/S_0)^{\theta/\theta_*}R_t^{7\theta}.
\]

S0=0时δ=0在Π²下几乎处处，全部Sθ为0；有限ν、e_t>0下端点负权矩有限（但价格可很大），此时θ↓0确实Sθ→S0。该式没有将小θ变成额外√n：它保留真实零端点score费用S0。

指数可按同一来源列的可测M、𝒟、R_t、S0等数据预定，并在该列接收/来源积分中共同使用。若这些成本有限，可取足够小的单一θ控制核指数、θlog⁺𝒟、7θlogR_t及(θ/θ*)log(n/S0)；这只降低已列成本的倾斜价格，仍留下M S0外账。选单一指数或 countable rational limit 不是对每个θ重复求和容量。若成本为∞，任意正θ不把∞变有限，应保留扩展价或另取明确定义的θ=0基线，不能以“θ很小”免费吸收。θ依x或内bad u变化时当前列Jensen无效；若按good来源分别选择，外Sθ的共同λ插值也须重证。

**NC23–24及NC24a PASS。** NC24a与HG6完全一致：固定归一p块先用p,T帽与high，物理b价合并后为(2KD√ℓ)^(−θ)κ^(8nθ)(b/a)^(3nθ)M*^(4nθ)。对x依赖核选择器不能免费给这个fixedblock价，必须使用NC20–21的实际M、𝒟与tildeM*；这些量在恢复原β、硬ν、time、唯一j/history及signed2Λ后仍需共同付款。

**本次冻结后审最终判定：HG1–6、NC10–24a PASS（真实费用改进及准确加权接入）。** 核端点保留真实wt，核/尺度指数从原零端点粗基价改为O(nθ)；actual high/FIRST支付裸整体e_t^(−θ)，加权列Jensen未遗漏W基线或核选择器费用。新增改进是实际接口而非重命名旧费用。未付的准确量仍是NC21完整列价格，包括M𝒟^θSθ与原β/time/j/history共同外账；初期规范化诊断未被当成主闭合，源矩没有被免费支付。原N_Z不返还、N_Zc/Ndel各一次；未新增ε槽。仅追加本审文件，未扩展数值/搜索任务。完成停。
