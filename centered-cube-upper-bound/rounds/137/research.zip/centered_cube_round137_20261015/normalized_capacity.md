# R137：真实来源归一化插值与共同容量的退化阈值

状态：推导冻结，待独审。本稿只使用R136的AB8–17和FK1–5。目标仍为εX+C√n polylog(n)Wβ。结论将区分核常数改善和来源/score付款；不把固定来源的归一接收积分当作完整母式，不交换Br根与dx。ν可相关，无e_t下界，允许H<L₊，原s下门随n，原负项只用一次。

## NC1：量词与保留所有正门的规范化

固定任一实际合法完整行、时间t和good来源v。外硬来源仍记z，内bad来源记z′。令Π=Π_t=e_t^{-1}1_Zt w_tν，并在本节保留实际FA与Ψ：

\[
 f_v(z')=\mathbf1_{D_g}(z')[k_t(v)-k_t(z')]_+
 \chi_{FA}(v,z')\Psi(v,z'),\qquad
 m_v=\int f_v\,d\Pi.
 \tag{NC1}
\]

这里0≤χ_FA,Ψ≤1，按实际同行取值；若原门还有行依赖也一并保留。故f_v>0蕴含严格低score bad资格，m_v=0的行直接没有正交通。

令a_v=(1−DK₀(x−v)/(TA(v)))₊，b_v=J(x−v)/(TA(v))。只在A(v)>0、a_v>0、m_v>0且ρ(v)>0的分支推导；其他分支正交通为零。该分支满足

\[
 u_v=\frac{\alpha J(x-v)}{a_vTA(v)}\in[0,1),
 \qquad \rho(v)=a_v(1-u_v).
\]

定义真正概率测度和无量纲变量

\[
 d\mu_v(z')=\frac{f_v(z')}{m_v}d\Pi(z'),\qquad
 Z_v(z')=\frac{a_vTA(v)Q_J}{D J(x-v)e_t m_v}
 \frac{f_v(z')w_t(y,z')}{K_0(x-z')}.
 \tag{NC2}
\]

Z只在f_v>0的μ支持上定义，因s>0与实际w_t>0而严格为正。真实w_t和两端来源归一化均未用C包络替换。ν整体缩放时Π、μ、Z不变；这项同次性检查排除了把e_t隐藏为常数。

对0<θ<1、r=1/(1−θ)，AB9的Hölder证明对f_v原样成立，并可**精确改写**为

\[
 \boxed{\rho(v)m_v\le c_\theta a_vm_v\,
 \Bigl(\mathbb E_{\mu_v} Z_v^{\theta/(1-\theta)}\Bigr)^{1-\theta},
 \qquad c_\theta=\frac{\theta^\theta}{(1+\theta)^{1+\theta}}.}
 \tag{NC3}
\]

证明：把Br中的δ换为f_v，得到∫f_v^r w_t^r/K₀^{r−1}dν。用dΠ=w_t dν/e_t再除以a_vm_v，即得NC3。所有积分限于真实Z_t；门的r次幂也真实保留。只有在以后调用FK端点时才可对正项用f_v≤δ，不能在规范化时漏掉门。

## NC2：源内插值，再在完整母式插值

记

\[
 B_\theta(v)=a_vm_v
 \Bigl(\mathbb E_{\mu_v}Z_v^{\theta/(1-\theta)}\Bigr)^{1-\theta},
 \qquad B_0(v)=a_vm_v.
 \tag{NC4}
\]

固定0<θ₀<1/3，令λ=θ/θ₀∈[0,1]。对同一个μ_v、Z_v，Hölder给

\[
 B_\theta(v)\le B_0(v)^{1-\lambda}B_{\theta_0}(v)^\lambda.
 \tag{NC5}
\]

详证：令r₀=1/(1−θ₀)。在未归一形式中，∫f^rR^{r−1}dΠ是∫f和∫f^{r₀}R^{r₀−1}dΠ的Hölder插值；取1/r次幂后，两端指数分别为1−λ和λ。等价地，(1−θ)log E exp[θ logZ/(1−θ)]是log矩母函数的凸透视。这里用的是前一种明确Hölder证明，不需要任何独立性或可积对数假设。

以dΣ表示原全部实际外因素与good端概率：

\[
 d\Sigma=d\mathcal T\,\frac{dt}{t}\,
 \mathbf1_{S_g\cap\{\rho>0\}}(v)d\Pi_t(v),\qquad
 d\mathcal T=q^{-1}p(x-y)h_R(x-z)a_{history}
 \,dx\,d\beta(y)\,d\nu(z).
 \tag{NC6}
\]

原唯一j、种子/history求和、期望、合法时间、重尾或硬计数限制均在Σ内，不删除。FA与Ψ已在f_v内。有限原截断下令I_θ=∫B_θdΣ，实际原正交通P₊=∫ρm_vdΣ。由NC3–5及**外层同一Σ上的Hölder**，

\[
 \boxed{P_+\le c_\theta I_\theta
 \le c_\theta I_0^{1-\lambda}I_{\theta_0}^{\lambda}.}
 \tag{NC7}
\]

没有把dx与源内r范数逆向交换；Σ甚至无需归一化。真实w_t、e_t、β−ν、硬z、q、history以及自适应核选择器均在同一测度中。I₀有限时可先截断再取极限；若I₀或端点无限，NC7不给虚假的有限付款。

NC7给出一项可核验的价格改善：若在**同一实际Σ**上已有端点价I_{θ₀}≤K_n J₀（J₀必须是明确已付或保留全部费用的量），则价变为c_θ K_n^λ I₀^{1−λ}J₀^λ。核常数M^{nλ}没有M^{2n}一类θ=0基价。这不是把J₀当常数；I₀也必须支付。固定源FK4仅是取得该完整端点价的一个核片段，不能单独代入为I_{θ₀}。

## NC3：参考稿5.2的真实wt版本——先插值Jensen内层

本节核对用户新参考稿《第136轮后全局闭合路线指导》5.2，并保留原截断权。先固定b,c_j,t,y,Z_t及概率接收核p=P_{s,L}(x−y)，a≤L,H≤b≤2a。令w_u=w_t(y,u)、w_v=w_t(y,v)，κ=b/(c_jt)，r=1+η，0≤η≤1/4，θ=η/(1+η)。此处κ不是旧h时间端点。A(v)≤w_τ(y,v)，τ=a/c_j。定义

\[
 F_\eta(u,v)=\int p(x-y)
 \frac{w_u^{1+\eta}w_v^{1+\eta}A(v)^\eta}
 {[K_0(x-u)J(x-v)]^\eta}\,dx.
 \tag{NC8}
\]

F₀=w_uw_v。对η₀=1/4，**先**把w_u^{5/4}w_v^{5/4}拆为(w_uw_v)^{1/4}w_uw_v，再仅对后两份权使用w≤κⁿ∏C、A≤(b/a)ⁿ∏C。FK4–5在指数1/4的端点给

\[
 F_{1/4}(u,v)\le(w_uw_v)^{1/4}
 \kappa^{2n}(b/a)^{n/4}b^{n/2}M_*^n,
 \qquad M_*=M_{1/4,s}.
 \tag{NC9}
\]

物理逆核各带b^{n/4}，所以总幂为b^{n/2}。来源位置任意、ν无独立性假设。对同一个p做Hölder插值，

\[
 \boxed{F_\eta(u,v)\le(w_uw_v)^{1-3\eta}
 \kappa^{8n\eta}(b/a)^{n\eta}b^{2n\eta}M_*^{4n\eta}.}
 \tag{NC10}
\]

这是原wt版本的价格改进；没有预先把两端wt全部替成C，因此κ^{2n}不作为θ=0基价留下。η=0时右端准确等于原w_uw_v。

令δ(v,u)=[k_t(v)−k_t(u)]₊，取x无关的真实Z_t，定义

\[
 I(v)=\int p(x-y)w_v\frac{A(v)^\theta}{J(x-v)^\theta}
 \left[\int_{Z_t}\delta(v,u)^r
 \frac{w_u^r}{K_0(x-u)^\eta}d\nu(u)\right]^{1/r}dx.
\]

对概率p先用凹函数Jensen，再用非负Tonelli，有I(v)^r≤∫δ(v,u)^rF_η(u,v)dν(u)。代NC10，得

\[
 \boxed{I(v)\le K_\theta
 \left[w_v^{1-3\eta}\int_{Z_t}\delta(v,u)^r
 w_u^{1-3\eta}d\nu(u)\right]^{1/r},}
 \tag{NC11}
\]
\[
 K_\theta=\kappa^{8n\theta}(b/a)^{n\theta}
 b^{2n\theta}M_*^{4n\theta}.
 \tag{NC12}
\]

这一合法次序不同于把固定u的接收积分移过源内r范数。实际D_g(x)、S_g(x)、FA、Ψ等若依x，只能先在正上界中删除，或另将其保留在内层；NC11本身没有保留它们产生的任何免费收益。严格δ>0资格仍在。

## NC4：两端实际来源归一化后的准确费用

对NC11再积分good端ν(v)并除以e_t²，精确换回同一Π_t得

\[
 \boxed{e_t^{-2}\int_{Z_t} I(v)d\nu(v)
 \le K_\theta e_t^{-\theta}\mathcal S_\theta(y),}
 \tag{NC13}
\]
\[
 \mathcal S_\theta(y)=\int d\Pi_t(v)\,w_v^{-4\theta}
 \left[\int\delta(v,u)^{1+\eta}w_u^{-3\eta}
 d\Pi_t(u)\right]^{1/(1+\eta)}.
 \tag{NC14}
\]

核对：内ν换Π带e_t^{1/r}；外ν带e_t；除e_t²后留下e_t^{-θ}。good端w指数为(1−3η)/r−1=−4θ；bad端为−3η。因此未假定e_t下界，也没有把它隐藏为新常数。两份原归一化仍完全在NC13–14中，且ν缩放时e_t^{-θ}须与原Q_J^θ共同抵消。

θ=0时S₀=∫δdΠ_t²，不存在额外负权或来源总质量。小θ时新增的是实际弱负权w_v^{-4θ}、w_u^{-3η}以及e_t^{-θ}；不能由它们指数很小推断其积分有界。原ν相关和存活删源均保留。NC13是真实wt相对R136先包络法的改善，不是一般来源价格已经支付。

## NC5：完整外乘子及核选择器的同一列版本

以下给可直接检查的完整费用接口，而非把固定核证明当全局证明。固定一个[a,b]、j,t,y及history列，使Z_t、w_t、δ、ν不随接收x改变；原不能如此固定的来源选择器必须继续保留，不能免费改列。允许L(x),H(x),s(x)可测且a≤L,H≤b、s≥s₀>0。外硬来源z固定，不与内来源u混同。记

\[
 W(x)=q(x)^{-1}h_{R(x)}(x-z)a_{history}(x)
 \mathbf1_{\text{原接收允许集}}(x),\quad
 R_0(x)=T(x)Q_J(x)/D,
\]
\[
 d\sigma(x)=p_x(x-y)W(x)dx,\quad
 M=\int d\sigma,\quad
 H_*={\mathop{\rm ess\,sup}}_x W(x)R_0(x)^{1/4}.
 \tag{NC15}
\]

M与H_*是明确的原接收质量和乘子帽，可能无限，不默认为常数。H_*也可保留为实际加权FK端点积分以取得更小价；本稿选择sup版本使费用可直接核验。这里不再要求x↦p_x(x−y)的积分为1。

考虑AB10内同一列的正上界（先只删除x依赖的good/bad/FA/Ψ正门）

\[
 I_\sigma(v)=\int d\sigma(x)w_v
 \left[\frac{R_0(x)A(x,v)}{J(x-v)}\right]^\theta
 \left[\int_{Z_t}\delta(v,u)^r
 \frac{w_u^r}{K_0(x-u)^\eta}d\nu(u)\right]^{1/r}.
\]

对概率σ/M使用Jensen，得I_σ(v)^r≤M^η∫δ^rF_η^σdν，其中

\[
 F_\eta^\sigma=\int d\sigma(x)R_0(x)^\eta
 \frac{w_u^{1+\eta}w_v^{1+\eta}A(x,v)^\eta}
 {[K_0(x-u)J(x-v)]^\eta}.
\]

F₀^σ=w_uw_vM。用NC9的真实wt拆法，端点乘子不超过H_*；R136 AB16–17的逐点核选择器包络给

\[
 F_{1/4}^\sigma\le(w_uw_v)^{1/4}
 H_*\kappa^{2n}(b/a)^{n/4}b^{n/2}\widetilde M_*^n,
 \quad\widetilde M_*=\widetilde M_{1/4,s_0}.
\]

对F_η^σ整体插值，再乘Jensen的M^η，得到

\[
 \boxed{e_t^{-2}\int I_\sigma(v)d\nu(v)
 \le \kappa^{8n\theta}(b/a)^{n\theta}b^{2n\theta}
 \widetilde M_*^{4n\theta}
 M^{1-4\theta}H_*^{4\theta}
 e_t^{-\theta}\mathcal S_\theta(y).}
 \tag{NC16}
\]

因为(η+1−4η)/r=1−4θ，所以M的幂准确如上。M=0的列为零；对非零有限M与H_*先证明，其他情形用截断或扩展值解释。固定核可用M_*代\widetilde M_*。这一步明确支付核选择器，不把其非归一接收质量误认为1。

恢复原β(dy)、外硬ν(dz)、dt/t、唯一j、种子/history和期望后，NC16右端乘c_θ即是P₊的新可核验完整上界；signed价格再乘2Λ。外硬载体没有删掉，它同时进入M和H_*。TQ_J/q没有被当常数，而是进入H_*及M。β−ν不变。若原列分解并不固定Z_t,w_t，则NC16不能直接使用；仍可用NC7的全母式插值，但其完整端点价格必须另证。

## NC6：实际high/FIRST支付整体e_t负幂

这是接回原母式的关键一步，须在同一实际high行进行。原high为p(x−y)e_g(y)≥2Kq；FIRST给Q_J≤q；t≤g、Z_g⊂Z_t及w_t≥w_g给e_g≤e_t。因此

\[
 \boxed{\frac{Q_J(x)}{e_t(y)}\le\frac{p_x(x-y)}{2K}.}
 \tag{NC17}
\]

这不假定e_t绝对下界，不把q或ν总质量当常数。若非high分支，NC17不得使用。将AB9先精确换成Π形式，

\[
 \rho(v)m_v\le c_\theta a_v^{1+\theta}
 \left[\frac{TA(v)Q_J}{D J(x-v)e_t}\right]^\theta
 \left[\int f_v(u)^r
 \left(\frac{w_t(y,u)}{K_0(x-u)}\right)^\eta d\Pi_t(u)\right]^{1/r}.
 \tag{NC18}
\]

NC17把其中(TQ_J/(De_t))^θ逐点替成(Tp/(2KD))^θ；全部来源Π保持原样。额外p^θ进入真实接收积分，不是将Q_J先移出dx。

在NC5的同一来源列中，令W保留原high指标，门外W=0，并记

\[
 \widehat H={\mathop{\rm ess\,sup}}_{x\in\{W>0\}}
 W(x)\left[\frac{T(x)p_x(x-y)}{2KD}\right]^{1/4}.
 \tag{NC19}
\]

NC17给H_*≤e_t^{1/4}\widehat H。因此NC16中H_*^{4θ}e_t^{-θ}≤\widehat H^{4θ}，得到**整体来源归一化负幂已付**的同行价格

\[
 \boxed{e_t^{-2}\int I_\sigma(v)d\nu(v)
 \le\kappa^{8n\theta}(b/a)^{n\theta}b^{2n\theta}
 \widetilde M_*^{4n\theta}
 M^{1-4\theta}\widehat H^{4\theta}\mathcal S_\theta(y).}
 \tag{NC20}
\]

这里左边仍取NC5中R₀=TQ_J/D的实际原量。也可直接从NC18出发，以p为Jensen基准，把(Tp/(2KD))^η放入端点积分，得到同式。NC20保留真实q、硬z与history，它们在M和\widehat H中；没有把“已付整体e_t幂”误写成“全部来源费用已付”。Π里的弱负矩S_θ仍真实存在。

对M>0定义无量纲、可直接核查的接收比

\[
 \mathcal D=\frac{b^{2n}\widehat H^4}{M^4}.
\tag{NC19a}
\]

则NC20右端恰为

\[
 \boxed{M\,\kappa^{8n\theta}(b/a)^{n\theta}
 \widetilde M_*^{4n\theta}\mathcal D^\theta
 \mathcal S_\theta(y).}
 \tag{NC21}
\]

其中𝒟不被视为常数。这样整体e_t负幂不再被命名为余项；剩下的是明确接收乘子比及同一真实Π内的来源负矩。NC17来自既有high/FIRST，本稿新增的是它与真实wt的Jensen内层插值在NC20–21中的组合接口，不将high本身登记为新引理。

## NC7：小θ的实际收益、来源成本与可测选择

取η_*＝1/4，对应本混合范数接口的θ_*＝1/5。对0≤θ≤θ_*，核和尺度的全部维数价格为

\[
 \exp\!\left\{n\theta
 [8\log\kappa+\log(b/a)+4\log\widetilde M_*]\right\}.
 \tag{NC22}
\]

因t≥a/c_j，κ≤b/a≤2。固定s₀时log\widetilde M_*=O(1+log(1/s₀))；原s₀随n时应原样计入。取θ≲[n(1+log(1/s₀))]^{-1}，只对这一核/尺度价确能得到维数有界常数。没有C₀^{2n}或κ^{2n}的零端点残价。

来源弱负矩亦可给显式有限费用，而非仅改名。设N_t=ν(Z_t)<∞，R_t=N_t/e_t≥1。对0≤q≤1，由在Z_t上的ν/N_t对凹函数w^{1−q}使用Jensen，

\[
 \int w_t^{-q}d\Pi_t\le R_t^q.
\]

故δ≤n、3η≤3/4、4θ≤4/5给

\[
 \mathcal S_\theta\le nR_t^{7\theta}.
 \tag{NC23}
\]

R_t不被当常数；NC23保留真实删源质量和归一化比。可进一步保留零端点score量S₀=∫δdΠ_t²：与NC5相同的Hölder透视，再在good端Π积分，给

\[
 \mathcal S_\theta\le
 \mathcal S_0^{1-\theta/\theta_*}
 \mathcal S_{\theta_*}^{\theta/\theta_*}
 \le\mathcal S_0\,(n/\mathcal S_0)^{\theta/\theta_*}
 R_t^{7\theta}.
 \tag{NC24}
\]

S₀=0的列均为零。有限ν下这些矩有限，且θ↓0时S_θ→S₀。由此允许按同一来源列的可测数据选择θ，使NC22、D^θ、R_t^{7θ}等价格受控；例如取θ不超过各个正对数费用总和加1的倒数。只选一个θ或取有理θ上确界/下确界，无须按θ网格再次加总容量。θ不能在Jensen源积分内部对不同u随意选择；若θ依x变化，应重新使用逐行NC3而不能套固定θ的列积分。

对固定概率接收核块，主代理同目录[high_gate_connection.md](high_gate_connection.md)的HG5–6进一步使用实际p≤a⁻ⁿ、T≤a⁻ⁿ/√ℓ，给与NC13、NC17完全一致的具体核价

\[
 (2KD\sqrt\ell)^{-\theta}\kappa^{8n\theta}
 (b/a)^{3n\theta}M_*^{4n\theta}.
 \tag{NC24a}
\]

原soft下门使log M_*=O(log(n+2))，所以θ=c/[n log(n+2)]（且θ≤1/5）确实使NC24a一致有界。这是真正减少的固定核费用，不以未知W帽为唯一结论；真实S_θ及β/time/j预算仍需付款。该具体价不能自动授予x依赖选择器；其加权形式由NC20–21保留实际费用。

小θ没有自动把score变根阶：NC24在θ↓0时回到真实S₀。它的意义是以显式小指数支付核和来源倾斜，避免先前指数维数粗价；若S₀这一实际接收配对预算仍是O(n)，本接口不会凭θ选择将其改为O(√n)。这不是取消NC20的改善，而是指出其准确用途。

## NC8：共同α优化的归一化诊断及唯一剩余付款

为核查小θ是否另带隐藏score收益，在NC1的正ρ分支有精确恒等

\[
 \mathbb E_{\mu_v}\frac1{Z_v}
 =\frac{D J(x-v)}{a_vTA(v)Q_J}
 \int_{\{f_v>0\}}K_0(x-u)d\nu(u)
 \le\frac{\alpha J(x-v)}{a_vTA(v)}=u_v<1.
 \tag{NC25}
\]

因x↦x^{-q}凸，q=θ/(1−θ)，得到(E_μZ^q)^{1−θ}≥u_v^{-θ}≥1。故NC3的优化右端至少为c_θa_vm_v；在固定θ≤θ_*范围内至少为c_{θ_*}a_vm_v。共同α优化本身不提供额外的n^{-1/2}因子；需要真正的联合接收/来源几何，而非仅缩θ。这一诊断使用同一实际来源，不构造抽象反例。

本轮正向交付是NC10–14及NC17–21：保留真实wt的端点插值，将核/尺度费改为O(nθ)指数；合法Jensen–Tonelli处理源内根；实际high/FIRST支付整体e_t^{-θ}；固定来源列内允许实际核选择器，并明确列质量M、接收比D与来源弱负矩的全部费用。

现在准确需攻的**单一联合付款**是：在原允许列、唯一j、时间、种子/history与β(dy)ν(dz)上，对NC21完整右端（乘c_θ和signed2Λ）证明

\[
 2\Lambda\,\mathbb E\sum_j\int d\beta(y)d\nu(z)\frac{dt}{t}\,
 c_\theta M\,\kappa^{8n\theta}(b/a)^{n\theta}
 \widetilde M_*^{4n\theta}\mathcal D^\theta
 \mathcal S_\theta(y)
 \le\varepsilon X+C\sqrt n\,\operatorname{polylog}(n)W_\beta.
 \tag{NC26}
\]

NC26中列约束和history沿用NC6/15，不能跨列复用容量。可以选择更尖的实际加权端点代\widehat H的sup，但仍须在同一积分付款。若某些原来源选择器不能固定成该列，则该部分继续按NC7的全母式版本处理，不能声称NC26覆盖它。现有证明尚未给NC26一般根阶预算。

未退回N_Z，N_Zc和N_del仍按原负门各一次；未增加ε槽，未将SI2的硬帽与raw价格重复领取。没有修改其他代理文件，没有git/PDF。到此交付停止。
