#!/usr/bin/env python3
"""Stored-input HG1--3 algebra only; no producer or integration rerun."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib,datetime,traceback
ROOT=Path(__file__).resolve().parent
INPUT=ROOT.parent/'centered_cube_round136_20261014/active_traffic_v2.json'
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
OUT=ROOT/'high_gate_probe.json'
def save(data):OUT.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def exact(x):return F(str(x))
def mf(x):
 q=exact(x);return mp.mpf(q.numerator)/q.denominator
def enc(x):
 if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [enc(v) for v in x]
 if isinstance(x,mp.mpf):return mp.nstr(x,mp.mp.dps)
 return x
def relerr(a,b):return abs(a-b)/max(abs(b),mp.mpf('1e-2000'))
def le(a,b):return a<=b+mp.mpf('1e-70')*max(abs(a),abs(b),mp.mpf('1e-2000'))
def calc(case,segno,label,dps):
 mp.mp.dps=dps
 source=case['atoms'];seg=case['score_segments'][segno];lo,hi=exact(seg['lo']),exact(seg['hi'])
 ismid=label=='mid'; tf=lo if label=='lo' else hi; t=mp.sqrt(mf(lo*hi)) if ismid else mf(tf)
 exact_active=lambda al:exact(al)**2<lo*hi if ismid else exact(al)<tf
 wt=[];kt=[];nu=[mf(a['nu']) for a in source]
 for a in source:
  active=[exact_active(al) for al in a['thresholds']]
  kt.append(sum(active));wt.append(mp.fprod(mf(al)/t if flag else mp.mpf(1) for al,flag in zip(a['thresholds'],active)))
 et=mp.fsum(q*w for q,w in zip(nu,wt));pi=[q*w/et for q,w in zip(nu,wt)]
 dt=case['derived'];pa=case['parameters'];p,K,D,T,QJ,eg,q=[mf(x) for x in [dt['p'],pa['K'],pa['D'],dt['T'],dt['QJ'],dt['eg'],dt['q']]]
 n=case['n'];theta=1/(8*mp.mpf(n)*mp.log(n+2));r=1/(1-theta);ctheta=theta**theta/(1+theta)**(1+theta)
 atoms=[];pairs=[];check2=True;check3=True;nonzero_aggregate=0;nonzero_pairs=0
 for i,a in enumerate(source):
  A,J,K0,rho=[mf(a[k]) for k in ['A','J','K0','rho']]
  av=max(1-D*K0/(T*A),mp.mpf(0)) if A>0 else mp.mpf(0)
  pref=ctheta*av**(1+theta)*(T*p/(2*K*D))**theta*(A/J)**theta if A>0 and av>0 else mp.mpf(0)
  B=mp.mpf(0);M=mp.mpf(0);mean=mp.mpf(0)
  for j,z in enumerate(source):
   delta=max(kt[i]-kt[j],0);bad=z['bad'];k0j=mf(z['K0'])
   bterm=delta**r*wt[j]**r*k0j**(1-r)*nu[j] if bad and delta else mp.mpf(0)
   mterm=delta**r*(wt[j]/k0j)**(r-1)*pi[j] if bad and delta else mp.mpf(0)
   B+=bterm;M+=mterm;mean+=delta*pi[j] if bad else mp.mpf(0)
   lhs=rho*delta*pi[j] if bad else mp.mpf(0);rhs=pref*mterm**(1/r) if mterm else mp.mpf(0)
   applicable=a['good'] and bad and rho>0 and delta>0
   pair_pass=le(lhs,rhs) if applicable else True
   if applicable:nonzero_pairs+=1;check3=check3 and pair_pass
   pairs.append(dict(v=a['name'],z_prime=z['name'],kv=kt[i],kz=kt[j],delta=delta,v_good=a['good'],z_bad=bad,rho_v=rho,pi_z=pi[j],B_term=bterm,posterior_M_term=mterm,HG3_lhs=lhs,HG3_rhs=rhs,HG3_applicable_positive=applicable,HG3_pass=pair_pass,HG3_ratio=lhs/rhs if rhs>0 else None,zero_delta=delta==0,zero_rho=rho==0))
  lhs2=B**(1/r)/et if B else mp.mpf(0);rhs2=et**(-theta)*M**(1/r) if M else mp.mpf(0)
  err2=relerr(lhs2,rhs2) if lhs2 or rhs2 else mp.mpf(0);check2=check2 and err2<mp.mpf('1e-75')
  lhs3=rho*mean;rhs3=pref*M**(1/r) if M else mp.mpf(0);app=a['good'] and rho>0 and mean>0
  pass3=le(lhs3,rhs3) if app else True
  if app:nonzero_aggregate+=1;check3=check3 and pass3
  atoms.append(dict(name=a['name'],nu=nu[i],wt=wt[i],kt=kt[i],pi_t=pi[i],good=a['good'],bad=a['bad'],A=A,J=J,K0=K0,rho=rho,a_v=av,B_r=B,posterior_M_r=M,HG2_left=lhs2,HG2_right=rhs2,HG2_relative_error=err2,bad_delta_mean=mean,HG3_lhs=lhs3,HG3_rhs=rhs3,HG3_applicable_positive=app,HG3_pass=pass3,HG3_ratio=lhs3/rhs3 if rhs3>0 else None,zero_A=A==0,zero_rho=rho==0,zero_delta_mean=mean==0))
 eg_reconstructed=mp.fsum(mf(a['nu'])*mp.fprod(min(1,mf(al)/mf(dt['g'])) for al in a['thresholds']) for a in source)
 checks=dict(high_input=le(2*K*q,p*eg),FIRST_QJ=le(QJ,q),eg_le_et=le(eg,et),eg_reconstruction_consistent=relerr(eg_reconstructed,eg)<mp.mpf('1e-75'),HG1=le(QJ/et,p/(2*K)),Pi_normalization=abs(mp.fsum(pi)-1)<mp.mpf('1e-75'),HG2_all=check2,HG3_all_applicable=check3)
 return dict(case_id=case['id'],score_segment_index=segno,sample=label,time=t,time_exact_description='sqrt(lo*hi)' if ismid else str(tf),lo_exact=str(lo),hi_exact=str(hi),theta=theta,r=r,c_theta=ctheta,et=et,eg_input=eg,eg_reconstructed=eg_reconstructed,input_nu_sum=mp.fsum(nu),QJ=QJ,QJ_over_et=QJ/et,p_over_2K=p/(2*K),atoms=atoms,pairs=pairs,nonzero_HG3_aggregate_count=nonzero_aggregate,nonzero_HG3_pair_count=nonzero_pairs,checks=checks,FULL_certified=False)
def comparison(low,high):
 errs=[relerr(low['et'],high['et'])];scores=[a['kt'] for a in low['atoms']]==[a['kt'] for a in high['atoms']]
 for a,b in zip(low['atoms'],high['atoms']):
  for key in ['wt','pi_t','B_r','posterior_M_r','HG2_left','HG2_right','HG3_lhs','HG3_rhs']:
   if a[key] or b[key]:errs.append(relerr(a[key],b[key]))
 for a,b in zip(low['pairs'],high['pairs']):
  for key in ['B_term','posterior_M_term','HG3_lhs','HG3_rhs']:
   if a[key] or b[key]:errs.append(relerr(a[key],b[key]))
 return dict(max_relative_error=max(errs),exact_score_agreement=scores,stable=scores and max(errs)<mp.mpf('1e-75'))
def main():
 first_failure=None
 if OUT.exists():
  previous=json.loads(OUT.read_text())
  if previous.get('status')!='startup_failed':raise SystemExit('Refuse another algebra run')
  first_failure=previous['first_run_failure']
 original=json.loads(INPUT.read_text());assert len(original['cases'])==12
 sources=[ROOT/'high_gate_protocol.md',Path(__file__),INPUT,ROOT/'high_gate_connection.md',ROOT.parent/'centered_cube_round136_20261014/active_bad_geometry.md']
 data=dict(status='running',run_count=2,attempt=2,algebra_execution_count=1,first_run_failure=first_failure,recovery_note='Parent authorized missing-save repair after startup exit1 before any case; input/menu/math/tolerances unchanged.',started_utc=utc(),precision_dps=[90,120],input_sha256=sha(INPUT),sha256={str(p):sha(p) for p in sources},scope='Stored-input algebra of HG1/2/3 only; no old producer, receiver or time integration rerun',cases=[],exceptions=[])
 save(data)
 for case in original['cases']:
  result=dict(id=case['id'],stage=case['stage'],n=case['n'],input_score_segment_count=len(case['score_segments']),samples=[])
  for segno in range(len(case['score_segments'])):
   for label in ['lo','mid','hi']:
    try:
     low=calc(case,segno,label,90);high=calc(case,segno,label,120);high['precision_comparison']=comparison(low,high)
     high['status']='passed' if all(high['checks'].values()) and high['precision_comparison']['stable'] else 'failed';result['samples'].append(enc(high))
    except Exception as exc:
     rec=dict(case_id=case['id'],score_segment_index=segno,sample=label,status='exception',exception=repr(exc),traceback=traceback.format_exc());result['samples'].append(rec);data['exceptions'].append(rec)
  result['status']='passed' if all(a['status']=='passed' for a in result['samples']) else 'failed';data['cases'].append(result);save(data)
  print(case['id'],result['status'],'samples',len(result['samples']),'nonzero_pairs',sum(a.get('nonzero_HG3_pair_count',0) for a in result['samples']),flush=True)
 samples=[a for c in data['cases'] for a in c['samples']];valid=[a for a in samples if 'checks' in a]
 data['summary']=dict(case_count=len(data['cases']),cases_passed=sum(c['status']=='passed' for c in data['cases']),sample_count=len(samples),samples_passed=sum(a['status']=='passed' for a in samples),pair_record_count=sum(len(a['pairs']) for a in valid),nonzero_HG3_aggregate_count=sum(a['nonzero_HG3_aggregate_count'] for a in valid),nonzero_HG3_pair_count=sum(a['nonzero_HG3_pair_count'] for a in valid),zero_delta_pair_count=sum(b['zero_delta'] for a in valid for b in a['pairs']),zero_rho_pair_count=sum(b['zero_rho'] for a in valid for b in a['pairs']),max_relative_algebra_error=mp.nstr(max(mp.mpf(a['precision_comparison']['max_relative_error']) for a in valid),120) if valid else None,max_HG2_identity_relative_error=mp.nstr(max(mp.mpf(b['HG2_relative_error']) for a in valid for b in a['atoms']),120) if valid else None,failed_samples=[dict(case_id=a['case_id'],segment=a['score_segment_index'],sample=a['sample']) for a in samples if a['status']!='passed'],FULL_certified=False,new_total_integral_certified=False)
 data['status']='completed_with_failures' if data['exceptions'] or data['summary']['failed_samples'] else 'completed_algebra_checks';data['finished_utc']=utc();save(data);print(data['summary'],flush=True)
if __name__=='__main__':main()
