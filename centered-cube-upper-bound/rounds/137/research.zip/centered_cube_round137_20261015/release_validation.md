# R137 最终验收与复现

一般目标未闭合。作者冻结稿开头“待独审”是冻结时状态；其后IA6–9已独审HG1–6及NC10–24a通过，实际数学范围以审计为准。完整外费用没有被判为已付。

核数值12/12通过60/90位比较，HG代数12例102样本通过90/120位比较；有168个非零聚合HG3检查及168个非零单项检查，两类不可当成336个独立配置。共有3672来源对记录，零δ与零ρ计数可重叠，端点采样也保留重复。HG最大代数相对差约4.11e−89，HG2身份差约4.38e−120。首次启动缺少save函数退出、尚无案例计算；修复后第二次启动完成首次数学计算，traceback及失败脚本SHA保留在final_numeric_summary。

主代理逐行检查HG计算式、严格Fraction score端点与输入范围；未把存储值精度复核当作原始核重新认证。对核数值，符号截尾公式已由FK1下界与尾积分核对，有限积分仍不是区间封闭。便携入口在隔离Python模式导入两模块通过，120位复算I1第0段中点，与原保存e、原子、来源对及门逐项相同。没有重复整套producer。Python AST与LaTeX显示数学配对检查通过，未编译PDF。ZIP的CRC与manifest字节校验通过。

使用Python和mpmath==1.3.0，解压保留相邻的R135核依赖目录与R136冻结输入目录。在centered_cube_round137_20261015内执行：

```text
python3 -I replay.py imports
python3 -I replay.py kernel --case I1 --dps 90
python3 -I replay.py high --case I1 --segment 0 --sample mid --dps 120
```

输出排他创建；已有复算文件不覆盖。kernel模式可按MENU循环12例；high模式可按冻结v2各score_segments及lo/mid/hi循环。不要直接运行producer main来依赖本机历史散列路径。源码原字节冻结，R135依赖中的旧vendor目录若不存在，安装的mpmath仍可正常导入。

final_numeric_summary去掉可重建的分段积分/来源对长表，但保留参数、验收状态、关键标量、输入与原输出哈希及启动失败。R136 v2完整JSON在本包仅作为HG复现所必需的冻结输入提供；新输出不全量提交。用户参考LaTeX文本作为source_guidance_LaTeX.txt只保留一份，属于来源材料，不是本轮已证结果。PDF与重复续接提示词不复制。

阶段零来源摘录主代理实读核对FT10–11、AC11及R134 RC索引，未核清历史总吸收余额，本轮不新增ε槽；不做模型扣额比例估算。
