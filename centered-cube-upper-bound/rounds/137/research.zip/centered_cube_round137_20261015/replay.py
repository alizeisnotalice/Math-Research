#!/usr/bin/env python3
"""Portable frozen-calculation entry point; bypass producer-only historical hash reads."""
from pathlib import Path
import argparse,importlib.util,json,sys
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['imports','kernel','high']);ap.add_argument('--case',default='I1');ap.add_argument('--dps',type=int,default=90);ap.add_argument('--segment',type=int,default=0);ap.add_argument('--sample',choices=['lo','mid','hi'],default='mid');args=ap.parse_args()
def load(name):
 spec=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
if args.mode=='imports':
 load('normalized_probe');load('high_gate_probe');print('Both frozen calculation modules imported; no numerical rerun.');sys.exit()
if args.mode=='kernel':
 m=load('normalized_probe');row=next(row for row in m.MENU if row[1]==args.case);res=m.calc(row,args.dps)
else:
 m=load('high_gate_probe');data=json.loads(m.INPUT.read_text());case=next(c for c in data['cases'] if c['id']==args.case);res=m.calc(case,args.segment,args.sample,args.dps)
out=ROOT/('replay_'+args.mode+'_'+args.case+'_'+str(args.dps)+'.json')
with out.open('x') as f:json.dump(m.enc(res),f,ensure_ascii=False,indent=2)
print(out)
