#!/usr/bin/env python3
"""R137 finite normalized receiver moments; no original A or FULL certificate."""
from pathlib import Path
import importlib.util,json,hashlib,datetime,time,traceback
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'centered_cube_round135_20261014/real_joint_numeric.py'
spec=importlib.util.spec_from_file_location('true_kernel',SOURCE);k=importlib.util.module_from_spec(spec);spec.loader.exec_module(k);mp=k.mp
OUT=ROOT/'normalized_probe.json';R=512
MENU=[('base','I1',16,'.5','.5','.1',0,0),('base','I2',64,'1','1','.5',0,1),('base','I3',256,'.5','1','1',1,-1),('base','I4',16,'1','.5','.5',-1,1),('reverse','P1',16,'1','.5','.1',4,-4),('reverse','P2',64,'1','.5','.5',-4,4),('reverse','P3',256,'1','.5','1',1,-1),('reverse','P4',64,'1','.5','.1',0,4),('expanded','E1',16,'.5','.5','log2/n',4,4),('expanded','E2',64,'.5','1','log2/n',-4,-4),('expanded','E3',256,'1','1','log2/n',4,-4),('expanded','E4',256,'1','.5','log2/n',-4,0)]
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def enc(x):
 if isinstance(x,dict):return {key:enc(val) for key,val in x.items()}
 if isinstance(x,(list,tuple)):return [enc(val) for val in x]
 if isinstance(x,mp.mpf):return mp.nstr(x,mp.mp.dps)
 return x
def save(x):OUT.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def Ctrue(x):
 x=abs(mp.mpf(x))
 if x>=1:
  E=lambda y:mp.mpf(1)/3 if y==0 else mp.expint(4,y)
  return E(x-1)-2*E(x)+E(x+1)
 return k.Cfun(x)
def calc(row,dps):
 mp.mp.dps=dps
 stage,cid,n,Lt,Ht,st,vi,zi=row;L,H=mp.mpf(Lt),mp.mpf(Ht);s=mp.log(2)/n if st=='log2/n' else mp.mpf(st);v,z=mp.mpf(vi),mp.mpf(zi)
 theta=1/(mp.mpf(n)*mp.log(n+1));theta0=mp.mpf('.25');phiv=k.phi(v);Cv=Ctrue(v)
 def mixed(x,length):return ((1-s)*(1 if abs(x)<=length/2 else 0)+s*k.phi(x/length))/length
 special=[-L/2,L/2,z-H/2,z+H/2,v-mp.mpf('.5'),v+mp.mpf('.5')]
 extra=[mp.mpf(0),v,z]+[mp.mpf(sign*number) for sign in [-1,1] for number in [8,16,32,64,128,256]]
 breaks=sorted(set([mp.mpf(-R),mp.mpf(R)]+special+extra))
 a0=2/(5*mp.sqrt(mp.e));A0=2*mp.sqrt(mp.e)
 def moment(th):
  def integrand(d):
   receiver=mixed(d,L);bad=mixed(d-z,H);good=k.phi(d-v)
   return mp.exp(mp.log(receiver)+th*(mp.log(phiv)-mp.log(bad)-mp.log(good)))
  pieces=[]
  for lo,hi in zip(breaks,breaks[1:]):
   scale=integrand((lo+hi)/2)
   val=scale*mp.quad(lambda d:integrand(d)/scale,[lo,hi],method='tanh-sinh',maxdegree=8)
   pieces.append(dict(lo=lo,hi=hi,midpoint_scale=scale,integral=val))
  value=mp.fsum(p['integral'] for p in pieces);beta=1/L-th*(1+1/H)
  logB=th*(-2*mp.log(a0)-mp.log(s)+mp.log(phiv)+mp.log(1+abs(z))+mp.log(1+abs(v))+abs(z)/H+abs(v))
  tail=2*s*A0*mp.exp(logB-beta*R)/(L*beta)
  logJ=mp.log(value);logJ_C=logJ+th*mp.log(Cv/phiv)
  return dict(theta=th,pieces=pieces,finite_J_phi=value,log_J_phi=logJ,n_log_J_phi=n*logJ,finite_J_C=value*(Cv/phiv)**th,log_J_C=logJ_C,n_log_J_C=n*logJ_C,analytic_tail_bound=tail,tail_beta=beta,tail_log_B=logB,finite_estimate_plus_analytic_tail=value+tail,interval_certified=False)
 small=moment(theta);fixed=moment(theta0)
 lhs=small['log_J_phi'];rhs=theta/theta0*fixed['log_J_phi'];gap=rhs-lhs
 Cgap=theta/theta0*fixed['log_J_C']-small['log_J_C']
 zero_tail=2*s*(mp.expint(4,mp.mpf(R)/L-mp.mpf('.5'))-mp.expint(4,mp.mpf(R)/L+mp.mpf('.5')))
 multiplier=n*theta
 fees=dict(n_theta=multiplier,soft_fee=multiplier*mp.log(1/s),source_exponential_fee=multiplier*(abs(z)/H+abs(v)),source_polynomial_fee=multiplier*(mp.log(1+abs(z))+mp.log(1+abs(v))),phi_marker_fee=multiplier*mp.log(phiv),a0_fee=-2*multiplier*mp.log(a0),C_marker_shift=multiplier*mp.log(Cv/phiv))
 fees['combined_n_log_B']=mp.fsum(fees[key] for key in ['soft_fee','source_exponential_fee','source_polynomial_fee','phi_marker_fee','a0_fee'])
 checks=dict(parameter_range=mp.mpf('.5')<=L<=1 and mp.mpf('.5')<=H<=1 and 0<s<=1 and 0<theta<=theta0<mp.mpf(1)/3,strict_s_input=s>1-2**(-mp.mpf(1)/n),both_tail_beta_positive=small['tail_beta']>0 and fixed['tail_beta']>0,log_convex_numerical=gap>=-mp.mpf('1e-50'),C_gap_agrees=abs(Cgap-gap)<mp.mpf('1e-50'),both_J_positive=small['finite_J_phi']>0 and fixed['finite_J_phi']>0)
 return dict(id=cid,stage=stage,parameters=dict(n=n,L=L,H=H,s=s,s_expression=st,v=v,z=z,R=R,theta=theta,theta0=theta0),normalizers=dict(phi_v=phiv,C_v=Cv,C_over_phi=Cv/phiv,phi_marker_is_original_A=False),J0_full_exact=1,J0_analytic_tail=zero_tail,J0_finite_estimate=1-zero_tail,hard_phi_breakpoints=special,all_breakpoints=breaks,small_theta=small,fixed_theta0=fixed,comparison=dict(logJ_small=lhs,theta_ratio_logJ_theta0=rhs,log_convex_gap=gap,logJ_small_negative=lhs<0,logJ_theta0_negative=fixed['log_J_phi']<0,C_log_convex_gap=Cgap,n_logJ_small=n*lhs,n_logJ_theta0=n*fixed['log_J_phi'],n_interpolation_rhs=n*rhs),source_soft_fees=fees,checks=checks,FULL_certified=False,root_certified=False)
def main():
 if OUT.exists():raise SystemExit('Refuse second normalized producer run')
 sources=[ROOT/'numeric_protocol.md',Path(__file__),SOURCE,ROOT.parent/'centered_cube_round133_20261014/third_numeric.py',ROOT.parent/'centered_cube_round136_20261014/fractional_kernel_envelope.md']
 data=dict(status='running',run_count=1,started_utc=utc(),menu=MENU,precision_dps=[60,90],R=R,sha256={str(p):sha(p) for p in sources},restored_state='Protocol existed; no code, JSON or active producer at resume. This is the first and only producer start.',scope='One-dimensional normalized phi/C markers and finite real-dx moments only; marker not original A, no score/continuous input/FULL/outer budget',cases=[],exceptions=[])
 save(data)
 for row in MENU:
  start=time.monotonic()
  try:
   low=calc(row,60);high=calc(row,90)
   errs={key:abs(high[key]['finite_J_phi']-low[key]['finite_J_phi'])/high[key]['finite_J_phi'] for key in ['small_theta','fixed_theta0']}
   signs=low['comparison']['logJ_small_negative']==high['comparison']['logJ_small_negative'] and low['comparison']['logJ_theta0_negative']==high['comparison']['logJ_theta0_negative']
   high['precision_comparison']=dict(J_relative_errors=errs,log_signs_agree=signs,stable=signs and max(errs.values())<mp.mpf('1e-40'))
   high['status']='passed' if all(high['checks'].values()) and high['precision_comparison']['stable'] else 'failed';high['elapsed_seconds']=time.monotonic()-start
   data['cases'].append(enc(high));print(row[1],high['status'],'logJsmall',mp.nstr(high['comparison']['logJ_small'],8),'nlogsmall',mp.nstr(high['comparison']['n_logJ_small'],8),'nlogfixed',mp.nstr(high['comparison']['n_logJ_theta0'],8),'gap',mp.nstr(high['comparison']['log_convex_gap'],6),flush=True)
  except Exception as exc:
   rec=dict(id=row[1],status='exception',exception=repr(exc),traceback=traceback.format_exc());data['cases'].append(rec);data['exceptions'].append(rec);print(rec,flush=True)
  save(data)
 valid=[c for c in data['cases'] if 'comparison' in c]
 data['summary']=dict(case_count=len(data['cases']),passed=sum(c['status']=='passed' for c in valid),failed_ids=[c['id'] for c in data['cases'] if c['status']!='passed'],negative_logJ_small_ids=[c['id'] for c in valid if c['comparison']['logJ_small_negative']],max_relative_J_error=mp.nstr(max(mp.mpf(x) for c in valid for x in c['precision_comparison']['J_relative_errors'].values()),90) if valid else None,all_numerical_log_convex_checks_pass=all(c['checks']['log_convex_numerical'] for c in valid),conclusion='The fixed twelve one-dimensional rows test small-theta normalization of the kernel price. Read signed log values directly; s and source displacement fees are retained. Finite numerical consistency does not give a uniform adaptive/score budget or a root/FULL theorem.',interval_certified=False,root_certified=False,FULL_certified=False,no_rate_fit=True)
 data['status']='completed_with_failures' if data['exceptions'] or data['summary']['failed_ids'] else 'completed_numerical_checks';data['finished_utc']=utc();save(data);print(data['summary'],flush=True)
if __name__=='__main__':main()
