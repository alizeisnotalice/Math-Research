# R137：共同后验与 K₀ 容量参考的精确归一化

状态：先独立筛查命题，再推导。只读取 R136 `active_bad_geometry.md` AB8--10 及其明确的同 x RC 定义，不改作者/审计者文件，不运行反例菜单，不操作 Git/PDF。

已读取 D02 Gibbs/熵技能及方法、来源状态、课题接口；仅使用有限概率密度恒等式，不援引尚未核验的无限域变分原理。所有新迁移均在本稿直接推导。

## 1. 准确对象与筛查

固定任意有限非零非负 ν、严格正且有限的可测 w、K₀，要求 \(0<e=\int w\,d\nu<\infty\)，并令 \(d\Pi=w\,d\nu/e\)。原 w≤1 时 e 的有限性由 ν 有限自动保证，但不存在输入无关下界。k 取 \(\{0,\ldots,n\}\)，ν 可以任意相关。

保留实际 bad 集 B 与严格低 score 门。固定 good v，定义
\[
 \delta_v(z)=(k(v)-k(z))_+1_B(z),\quad
 a(v)=\mathbb E_\Pi\delta_v,\quad
 \mathcal B_r(v)=\int\delta_v(z)^r
 \frac{w(z)^r}{K_0(z)^{r-1}}\nu(dz),\quad r>1.
\tag{PB1}
\]
不将 δ 换成 k(v) 或免费 \(\sqrt n\)。\(k(v)=0\) 或 a(v)=0 时原交通与 B_r 均为零；下面只在 a(v)>0 时定义 score 倾斜概率。

令
\[
 R(z)=\frac{eK_0(z)}{w(z)}.
\]
直接换测度的候选为
\[
 \boxed{\frac{\mathcal B_r(v)}{e^r}
 =\mathbb E_\Pi\big[\delta_v^r R^{1-r}\big].}
\tag{PB2}
\]
这里 R 而非其倒数是容量密度，且 \(\mathbb E_\Pi[R1_B]=\int_BK_0\nu\)。R 一般不是均值为1的概率密度，也可能有单位；不能直接称 \(\mathbb E_\Pi\log R\) 为 KL，更不能从其一次容量均值控制逆幂矩。

为了与原 \(\alpha Q_J\) 精确匹配，应使用同一 bad 容量
\[
 0<C_B:=\int_BK_0\,d\nu<\infty,\qquad
 d\Sigma_B=1_BK_0\,d\nu/C_B.
\tag{PB3}
\]
若 C_B=0，则 K₀>0 使 ν(B)=0，原 bad 正项为零；若 C_B=∞，PB2 仍可作为扩展非负积分恒等式，但不能建立 PB3 的概率或有限 KL 差式。实际有限共同 FIRST/α 行给 C_B≤αQ_J/D，故允许使用同一个有限容量参考，不按 score 层另造容量。

## 2. 精确概率比与来源 score 倾斜

在 PB3 的域内，同一容量参考满足
\[
 \frac{d\Sigma_B}{d\Pi}(z)=1_B(z)\frac{R(z)}{C_B}.
\tag{PB4}
\]
对 a(v)>0，令 \(dP_v=\delta_vd\Pi/a(v)\)。它是严格低 score bad 来源上的概率，且 \(P_v\ll\Sigma_B\)。其密度比为
\[
 h_v(z):=\frac{dP_v}{d\Sigma_B}(z)
 =\frac{\delta_v(z)C_B}{a(v)R(z)}\quad(P_v\text{-a.e.}).
\tag{PB5}
\]
因此低 score 门仍在 δ 与 P_v 中；没有以全域 \(\delta\le n\) 抹掉它。所有 v 共用同一个 \(\Sigma_B\) 和 C_B，不按 v 或 score 层重新申请 \(\alpha Q_J\)。

定义实际有限概率矩（允许值 +∞）
\[
 D_r(P_v\Vert\Sigma_B)
 :=\frac1{r-1}\log\int h_v^r\,d\Sigma_B.
\]
这只是所写积分的记号，以下不把它视为已付预算。PB2--5 直接给精确恒等式
\[
 \boxed{\frac{\mathcal B_r(v)}{e^r}
 =C_B^{1-r}a(v)^r
 \exp\{(r-1)D_r(P_v\Vert\Sigma_B)\},}
\]
\[
 \boxed{\frac{\mathcal B_r(v)^{1/r}}e
 =a(v)C_B^{-\theta}
 \exp\{\theta D_r(P_v\Vert\Sigma_B)\},\qquad
 \theta=(r-1)/r.}
\tag{PB6}
\]
证明只需 \(dP_v=\delta_vd\Pi/a(v)\) 换测度；原 ν 的相关性没有任何影响。C_B 与 R 具有相同量纲，PB5 的比值无量纲；所有对数均作用于合法概率密度比。

原 bad Hölder 因子因而准确等于
\[
 C_B^\theta\frac{\mathcal B_r(v)^{1/r}}e
 =a(v)e^{\theta D_r(P_v\Vert\Sigma_B)}\ge a(v).
\tag{PB7}
\]
最后一步由 \(\int h_vd\Sigma_B=1\) 与凸性得到。它暴露了 Hölder 的来源失配代价；不是一个凭一次 K₀ 容量即可压低的收益。

## 3. 接近 r=1：仅在可积域内的熵费用

写 \(Y_v=\log h_v\)。由于 \(\int_{h_v<1}h_v|\log h_v|d\Sigma_B\le1/\mathrm e\)，其 P_v 下负部总有有限界；这里 \(\mathrm e\) 是自然常数，不是来源质量 e。为合法取 r↓1，以下明确假设存在 \(r_0>1\) 使
\[
 \int h_v^{r_0}d\Sigma_B<\infty.
\tag{PB8}
\]
该条件使 Y_v 正部可积，且提供一个实际正指数矩。于是 \(H_v:=KL(P_v\Vert\Sigma_B)=\mathbb E_{P_v}Y_v\) 有限。对 \(0<\varepsilon<r_0-1\)，
\[
 \log\mathbb E_{P_v}e^{\varepsilon Y_v}
 =\varepsilon D_{1+\varepsilon}(P_v\Vert\Sigma_B).
\]
在稍小的 ε 区间由 PB8 支配正部，负部用前述可积界处理，可逐项取导数，得到
\[
 D_{1+\varepsilon}(P_v\Vert\Sigma_B)=H_v+o(1).
\tag{PB9}
\]
由 Jensen 及 log-mgf 凸性，另有明确的一致区间控制
\[
 H_v\le D_r(P_v\Vert\Sigma_B)
 \le D_{r_0}(P_v\Vert\Sigma_B),\qquad1<r\le r_0.
\tag{PB10}
\]
因此
\[
 \log\frac{C_B^\theta\mathcal B_r(v)^{1/r}}{e,a(v)}
 =\theta D_r(P_v\Vert\Sigma_B)
 =\theta H_v+o(\theta).
\tag{PB11}
\]
这是接近 r=1 的可控表达，条件和费用均明确。PB8 只逐 v 成立时，不能把 PB9 的极限自由移入 good、时间、实际接收及 history 积分；那一步还须共同支配或外积分预算。仅声称有限 KL 也不能替代所需正指数矩核验；在无可积条件时不写 ∞−∞，保留 PB6 的扩展非负积分。

更具体地，令 p_B=Π(B)>0、\(\Pi_B=1_B\Pi/p_B\)。在实际对数比可积时，
\[
 H_v=KL(P_v\Vert\Pi_B)
 +\mathbb E_{P_v}\log\frac{C_B}{p_BR},
\tag{PB12}
\]
\[
 0\le KL(P_v\Vert\Pi_B)
 =\mathbb E_{P_v}\log\frac{\delta_vp_B}{a(v)}
 \le\log\frac{np_B}{a(v)}.
\]
PB12 第一部分是低 score 倾斜；第二部分才是真实后验与 K₀ 容量概率的核失配，并保留 e、w、K₀ 的比值。该第二项在 P_v 下不保证非负，不能逐项替换成未经证明的“熵预算”。Jensen/Gibbs 在此提供的是 log-mgf 对 KL 的下界或有条件变分式，不自动给 PB11 所需的上预算。

## 4. 原 good--ρ 联合中的完整概率表达

为与 AB9 的记号区分，本节写 \(m_v=a(v)=\mathbb E_{\Pi_t}\delta_v\)，并记原硬项余比
\[
 g_v=\left(1-\frac{DK_0(x-v)}{TA(v)}\right)_+,
 \qquad C_G(v)=\frac{TA(v)Q_J}{D J(x-v)}.
\]
g_v 是 AB9 原文的 a_v，不是来源 score 均值 m_v。只在 \(A>0,g_v>0,m_v>0\) 的相关 good 分支作除法；其他分支原正交通为零。

AB9 与 PB6 精确相接为
\[
 \rho(v)m_v\le
 c_\theta g_v^{1+\theta}m_v
 \left(\frac{C_G(v)}{C_B}\right)^\theta
 e^{\theta D_r(P_v\Vert\Sigma_B)}.
\tag{PB13}
\]
容量比 C_G/C_B 是无量纲的实际行比；PB13 在 ν 整体缩放下不变，因为 e、C_B、Q_J 和 C_G 同比例缩放，Π、P_v、Σ_B 与密度比 h_v 均不变。这排除了额外插入 \(\|\nu\|/e\) 的必要性，却不是这些比值已有共同外预算的证明。

若保留实际 FA/Ψ，把 δ_v 换为 \(f_v=\delta_v\chi_{FA}\Psi\) 即可原样定义 m_v、P_v、B_r 与 PB6--13；同一 bad 容量参考 Σ_B 不变，严格低 score 支持仍在。此扩展是对正门的真实保留，不给负项增加这些门。

参考稿 NC2 的无量纲变量在这个记号下恰为
\[
 Z_v^{NC}=g_v\frac{C_G(v)}{C_B}h_v,
 \qquad
 \mathbb E_{P_v}\log Z_v^{NC}
 =\log\frac{g_vC_G(v)}{C_B}+KL(P_v\Vert\Sigma_B),
\tag{PB14}
\]
其中第二式仅在前述可积域使用。它精确识别小 θ 的来源/容量费，而非新的免费熵。原 \(\alpha Q_J\ge DC_B\) 也直接给
\[
 \rho(v)\le\left(g_v-\frac{C_B}{C_G(v)}\right)_+.
\tag{PB15}
\]
所以小 θ 的 c_θ 折扣并未自动构成第二份捕获付款；PB14 的对数比和熵必须在原联合测度中核验。逐 v 选择一个极小 θ 来抵消很大熵，也不提供时间/接收积分的共同支配。

恢复原 raw 外测度与 good 来源概率，PB13 对原正项的合法上界是
\[
 P_+\le\int d\mathcal T\int\frac{dt}{t}
 \int_{S_g}c_\theta g_v^{1+\theta}m_v
 \left(\frac{C_G(v)}{C_B}\right)^\theta
 e^{\theta D_r(P_v\Vert\Sigma_B)}\,d\Pi_t(v).
\tag{PB16}
\]
d𝒯 保留真实 \(dx\)、\(q^{-1}p h_R\)、硬 z、\(\beta-\nu\)、唯一 j、种子/history 和实际 s/L/R/g 选择器；signed 外系数为 \(2\Lambda\)。Π_t(v) 仍有 good 端的 \(w_t/e_t\)，P_v 与密度比 h_v 保留 bad 端原 \(w_t/e_t\)。把概率式重新写回 ν 即返回 AB10 的两份 e_t 来源归一化，不允许把它们解释成容量常数。

## 5. 主代理新增 high/FIRST 接口的独立补核

仍在同一实际 x 的原 high 域，q>0，\(pe_g\ge2Kq\)，共同 FIRST 给 \(Q_J\le q\)，\(t\le g,Z_g\subset Z_t\) 与权重单调给 \(e_g\le e_t\)。故
\[
 \frac{Q_J}{e_t}\le\frac q{e_t}\le\frac q{e_g}\le\frac p{2K}.
\tag{PB17}
\]
定义保持原严格低 score bad 支持的实际后验矩
\[
 I_r(v)=\int_{B}\delta_v(z')^r
 \left(\frac{w_t(z')}{K_0(x-z')}\right)^{r-1}d\Pi_t(z').
\tag{PB18}
\]
PB2 的另一种准确写法为
\[
 \frac{\mathcal B_r(v)^{1/r}}{e_t}=e_t^{-\theta}I_r(v)^{1/r}.
\]
与 AB9 的 \(Q_J^\theta\) 合并，使用 PB17，独立得到
\[
 \boxed{\rho(v)m_v\le
 c_\theta g_v^{1+\theta}
 \left(\frac{Tp}{2KD}\right)^\theta
 \left(\frac{A(v)}{J(x-v)}\right)^\theta
 I_r(v)^{1/r}.}
\tag{PB19}
\]
结论 PASS。它确实由实际 high/FIRST 支付了一个裸 \(e_t^{-\theta}\) 整体来源幂：该幂与原共同容量 \(Q_J^\theta\) 合成为 \((Q_J/e_t)^\theta\)，再由同 x 的确定不等式控制。此处不是仅将未付来源矩换名，也没有用来源质量下界。

量纲核对：w_t、A、score 和 K/D 无量纲；p、T、J 均具有长度的 −n 次方量纲。I_r 的1/r次幂有长度的 nθ 次方，而 \([(Tp)(A/J)]^\theta\) 有长度的 −nθ 次方，PB19 两侧同为无量纲 score 交通。实际 q>0 的 high 行有 p、e_g、e_t>0；e_t=0 或 Q_J=0 按原零来源约定不贡献，A=0/g_v=0/k(v)=0 直接为零，不在这些行作 0·∞ 运算。若 I_r=∞，PB19 仅为扩展非负上界，不登记有限付款。

good 端来源积分后，完整式为
\[
 P_+\le c_\theta\int d\mathcal T\int\frac{dt}{t}
 \left(\frac{Tp}{2KD}\right)^\theta
 \int_{S_g}g_v^{1+\theta}(A/J)^\theta
 I_r(v)^{1/r}\,d\Pi_t(v).
\tag{PB20}
\]
真实 x 没有移除，p^θ 不得提出任意接收积分。PB18 仍使用真实 Π_t，含 bad 端 \(e_t^{-1}\)；PB20 的 good 端又含原 \(e_t^{-1}\)。Hölder 根使 bad 那份归一化以1/r幂进入上界，写回 ν 后显式为 \(e_t^{-(1+1/r)}\)；这说明裸分数幂受控而两份来源概率角色仍在，不能说来源分母已全部消失。

## 6. 结论与未付费用

成功：PB2、PB6 识别了实际容量密度 R=e_tK₀/w_t 及其逆幂，使用同一 Σ_B 匹配原 bad 容量；PB9--12 在可积条件下精确描述 r↓1 的熵费用；PB17--20 额外核准 high/FIRST 对一个整体来源分数幂的真实支付。没有调用 \(\|\nu\|/e_t\) 常数，没有分层重复领取 α 容量。

仍未支付：PB18 的真实 source score/核比矩、PB16 的容量比及后验失配熵、与 good ρ/接收 p^θ 的共同积分、时间/唯一 j/history/β−ν 总账。δ≤n 仅给相应粗 score 上界，不给 \(\sqrt n\)；θ 小只减小幂次，不控制熵、矩或原 score 均值。逐行有限或逐行小 θ 不能替代 \(\varepsilon X+C\sqrt n\operatorname{polylog}(n)W_\beta\) 的统一外预算。

负项原位：N_Z 已消费不返还，N_Zc/Ndel 各一次，未附本稿正门；没有新增误差槽或第二份 RC 捕获额度。一般中间硬层与根阶目标仍 UNPROVED。本稿给出所需归一化恒等式、有限积分域及一项实际可用的 high/FIRST 分数幂接口，到此冻结停止。
