# R137 主代理：high/FIRST 对整体来源归一化幂的真实控制

状态：候选推导，待独审。仅使用同一原实际行的 high、FIRST 和 t≤g；不假设来源独立，不认为以下来源负矩已付款。

## HG1 原同一行

设 e=e_t>0、e_g≤e_t，p e_g≥2Kq，Q_J≤q，D≥1。则
\[
 Q_J/e_t\le p/(2K).
\tag{HG1}
\]
原因是 Q_J≤q≤p e_g/(2K)≤p e_t/(2K)。e_g≤e_t由 Z_g⊂Z_t、w_g≤w_t给出；这些条件只能在原t≤g域内使用。e_t=0行原来源交通为零，不能除以e_t。

令r=1+η、θ=η/r、dΠ_t=1_Zt w_t dν/e_t。R136严格低score bad矩满足
\[
 B_r^{1/r}/e_t=e_t^{-\theta}
 \left[\int_{D_g\cap Z_t}\delta_t^r(w_t/K_0)^{r-1}d\Pi_t\right]^{1/r}.
\tag{HG2}
\]
所以AB9及HG1直接给实际同行估计
\[
 \rho(v)\int_{D_g}\delta_t d\Pi_t
 \le c_\theta a_v^{1+\theta}
 \left({Tp\over2KD}\right)^\theta
 \left({A(v)\over J(x-v)}\right)^\theta
 \left[\int_{D_g}\delta_t^r(w_t/K_0)^{r-1}d\Pi_t\right]^{1/r}.
\tag{HG3}
\]
这里没有裸e_t^−θ，但Π仍含真实归一化；并未宣称两份来源费用整体消失。外层raw q^−1h_Rhistory不能由此删去，p也仍依同一接收点。

## HG4 与真实w插值相接的固定核块价格

以下引用作者待审的真实w混合插值：固定[a,b]、j,y,t与概率接收核p=P_s,L，0<η≤1/4、θ=η/(1+η)，h=b/(c_jt)≤2，M_*=M_(1/4,s)。若A≤w_τ、τ=a/c_j，则
\[
 \int p\,w_t(v)(A/J)^\theta B_r(v)^{1/r}dx
 \le \mathcal K\left[w_t(v)^{1-3\eta}
 \int\delta_t^r w_t(u)^{1-3\eta}d\nu(u)\right]^{1/r},
\]
\[
 \mathcal K=h^{8n\theta}(b/a)^{n\theta}b^{2n\theta}M_*^{4n\theta}.
\]
此处可以先将x依赖bad/good正门上放，保留固定Z_t和δ，不能声称原集合固定。

在同一原块内，p≤a^−n，因为φ≤1且L≥a；T=c_j^(n/2)/(g^n√ell)≤a^−n/√ell。因此HG1在实际high域给
\[
 (TQ_J/D)^\theta\le[e_t a^{-2n}/(2KD\sqrt\ell)]^\theta.
\tag{HG4}
\]
只在用过HG4后才能去掉high指示作正上界。把右端从x积分移出是合法固定块操作；不需要把实际Q_J单独移出。

对原good端也积分并除e_t²后，e_t幂精确抵消：
\[
 e_t^{\theta-2}\int d\nu(v)
 [w_t(v)^{1-3\eta}\int\delta_t^r w_t(u)^{1-3\eta}d\nu(u)]^{1/r}
 =\int d\Pi_t(v)w_t(v)^{-4\theta}
 [\int\delta_t^r w_t(u)^{-3\eta}d\Pi_t(u)]^{1/r}.
\tag{HG5}
\]
得到明确核尺度价
\[
 \mathcal C_{n,\theta,s}=(2KD\sqrt\ell)^{-\theta}
 h^{8n\theta}(b/a)^{3n\theta}M_*^{4n\theta}.
\tag{HG6}
\]
所有量纲b因子已经通过a^−2nθ准确合并为(b/a)^2nθ，而非直接删除。

原严格soft下门s>1−2^(−1/n)保证log M_*=O(log(n+2))。取预定θ=c/[n log(n+2)]且θ≤1/5，则HG6一致有界（K,D固定正数）。这只证明固定接收概率核块中核/尺度显式费用的改善。它没有控制HG5的来源负小幂矩，没有提供跨j或实际x选择器的同价估计。

若先对原外硬z使用原q与硬帽，则q^−1∫h_Rhistory dν(z)≤16/3，可在原域内一次使用，再做上述正放松。该固定核分支的上界须乘16/3以及原2Λ，并保留β、time与j。若保留raw硬来源则不能重复乘16/3。核若随x选择，∫p未必为1，不能使用这里的概率Jensen。

## 当前总缺口

HG5里的双来源矩仍须在真实β、时间、唯一j及共同history下得到根阶输入质量预算；没有νmass/e_t统一帽。η小不自动使δ变为√n。此文不登记新增ε槽、不消费任何原负项，不声称原自适应全交通已闭合。
