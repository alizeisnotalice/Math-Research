# R137 阶段零账目索引：既付 RC 与 FT 低面积层

**限定来源。** 仅查看 `output/centered_cube_round125_20261014/` 和 `output/centered_cube_round134_20261014/`。两目录均存在。以下只摘录两目录原文中已经明确写出的系数、误差槽、X/β根量与负项身份，不推导新结论、不合计总 ε，也不推测总 ε_rem。链接行号是对应原文位置。

## 既有同价捕获付款（R125 AC；R134 所记 RC）

- **准确价格。** R125 已审 AC4 为
  \[
  2\Lambda\mathfrak P_{\mathcal Z^c,b_{\mathsf D}}
  \le \varepsilon_G X+C_G(\varepsilon_G)\sqrt n\,W_\beta,
  \]
  其中 \(\Lambda=128/119\)，全局先固定 \(0<\varepsilon_G\le1\)，且硬项保持原帽、仅放大软容量；见 [R125 overview，行 7–17](/Users/zhengzhihao/Desktop/T/output/centered_cube_round125_20261014/overview.md:7)。其行帽为 \(16/(3\ell)+D_n/\sqrt\ell\)，真实交通回代系数是 \(8\Lambda\)，放大分支的 X 系数恰为 \(\varepsilon_G\)；有限维分支沿用同一个 \(C_G(\varepsilon_G)\)，见 [R125 proof，行 254–286](/Users/zhengzhihao/Desktop/T/output/centered_cube_round125_20261014/proof.md:254)。
- **账目替换与负项身份。** R125 选择 AC11：以同价新捕获付款替换旧 G123 正项，不将两份捕获费相加。总账中列出的剩余正项及两负项为 \(-2\Lambda N_{\mathcal Z^c}-2\Lambda N_{del}\)；原文注明 \(N_{\mathcal Z}\) 已消费、不再使用，\(N_{\mathcal Z^c}\) 与 \(N_{del}\) 各保留一次，见 [R125 proof，行 150–162](/Users/zhengzhihao/Desktop/T/output/centered_cube_round125_20261014/proof.md:150)。
- **R134 对 RC 既付记录的转述。** R134 proof 的 RC 历史索引复述 RC8–9：行费仍为 \(16/(3\ell)+D/\sqrt\ell\)；\(D>1\) 时 X 系数恰为 ε，\(D=1\) 的小维支回到原有限维母核，RC9 使用原 \(C_G(\varepsilon)\)，没有额外捕获、节点或时间费。该 RC9 替换 AC11 捕获付款，不与 AC4 或 SC5 相加；负项和完整时间/来源积分身份也明确列在表内，见 [R134 proof，行 804–810](/Users/zhengzhihao/Desktop/T/output/centered_cube_round134_20261014/proof.md:804)。
- **RC 的 ε 槽状态。** R134 proof 对 R127 预算记录的转述是：预先在总吸收额内固定 \(\varepsilon_{RC},\varepsilon_B>0\)，\(\varepsilon_{RC}\le1\)，并以 \(\varepsilon_{RC}\) 构造、冻结 RC 的 \(D,\alpha_{rec},b_{rec}\)；转述要求 \(\varepsilon_{RC}+\varepsilon_B\le\varepsilon_{tot}\)。这是 R134 索引中的既有预算记录，不是本轮重新核验总额度；见 [R134 proof，行 812–817](/Users/zhengzhihao/Desktop/T/output/centered_cube_round134_20261014/proof.md:812)。

## R134 FT 低面积层

- **逐行时间价与交通系数。** 面积阈值记为 \(d\)，R134 给出 \(\mathscr F_d\le d[1+\log_+(n/4)]\)。使用原完整行总账 \(T_{small}\le4X\)，signed 外系数为 \(2\Lambda\)，故子层原始价格为
  \[
  2\Lambda P^{rem}_{\Delta\le d}
  \le 8\Lambda d[1+\log_+(n/4)]X.
  \]
  选 \(d=\varepsilon_d/[8\Lambda(1+\log_+(n/4))]\) 后，当前 \(\Delta\le d\) 子项至多 \(\varepsilon_dX\)；准确公式及“独立新槽”限定见 [R134 fa_time_geometry，行 105–132](/Users/zhengzhihao/Desktop/T/output/centered_cube_round134_20261014/fa_time_geometry.md:105)。
- **ε 是否已预先固定。** 面积层的 \(\varepsilon_d>0\) 在 R134 中是任取并需另行纳入最终总 ε 分配的**新独立槽**。原文明确未核验历史尚余的误差预算，不得据此声称有可用余额。R134 主集成也写明新槽需显式分配，见 [R134 main_integration，行 10–17](/Users/zhengzhihao/Desktop/T/output/centered_cube_round134_20261014/main_integration.md:10)。这与前段 RC 的预固定 \(\varepsilon_{RC}\) 是不同槽。
- **X 的已见定义及 Wβ 的处理。** 在本次允许查看的 R134 原文中，\(X\) 明确定义为 \(\lambda|E_0|<\infty\)，且 \(T_{small}=\mathbb E\sum_{V,j}\int d\mathcal T\le4X\)，见 [R134 proof，行 259–266](/Users/zhengzhihao/Desktop/T/output/centered_cube_round134_20261014/proof.md:259)。R125/R134 的本次引用位置把 \(W_\beta\) 用作既有 \(\sqrt n W_\beta\) 根项，但这两目录内本次读取到的付款摘录没有给出其定义式；因此这里只登记系数 \(C_G(\varepsilon)\sqrt n W_\beta\)，不为 \(W_\beta\) 补写含义。FT 低面积层只收费 \(\varepsilon_dX\)，没有新增 \(W_\beta\) 项。
- **负项和已付 RC 不得再次充当付款。** FT11 只对当前原正余项添加面积指示，不重付已经删除的 near/FA/RC 子支；\(\Delta>d\) 原位保留。\(N_{\mathcal Z}\) 不返还，\(N_{\mathcal Z^c}\) 与 \(N_{del}\) 各保留一次，且没有附加本层门；见 [R134 fa_time_geometry，行 128–132](/Users/zhengzhihao/Desktop/T/output/centered_cube_round134_20261014/fa_time_geometry.md:128)。raw 外测度已经含 \(q^{-1}h_R\nu\)，从 SI5 的 \((16/3)c_\xi\) 形式回到 raw 形式后，不能再在 \(8\Lambda\) 外重复乘 \(16/3\)；同段注明这一点。R134 main integration 也明确“不重新收费旧 FA/RC/SP/MA 部分”，见 [行 15–17](/Users/zhengzhihao/Desktop/T/output/centered_cube_round134_20261014/main_integration.md:15)。

## 范围说明

本文件只做指定两目录内的账目定位。上一份 `history_index.md` 没有实际完成最初要求的矩母函数/Shtarkov 检索；本文件不据此作任何“此前不存在”的结论。以上 RC 旧预算是 R134 proof 对既有记录的转述，FT 低面积层是 R134 当前的新条件付款；二者均不能推出总 \(\varepsilon_{rem}\)，本文件不估算该余额。
