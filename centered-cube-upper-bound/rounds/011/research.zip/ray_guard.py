#!/usr/bin/env python3
"""Deterministic rational guards; no sampling and no asymptotic fitting."""
from fractions import Fraction as F
from math import prod, floor, ceil
import json

def count(lo, hi, eta, K):
    return max(0, min(K-1, floor(hi/eta))-max(0, ceil(lo/eta))+1)

def mass(x, L, eta, K):
    return 2*eta**len(x)*prod(count(t-L/2,t+L/2,eta,K) for t in x)

def winner(x, eta, K):
    # All boundary arrival distances in [1,2], with ties grouped by set.
    scales={F(1),F(2)}
    for t in x:
        for k in range(max(0,ceil((t-1)/eta)),min(K-1,floor((t+1)/eta))+1):
            r=2*abs(t-k*eta)
            if 1<=r<=2: scales.add(r)
    best=max((mass(x,L,eta,K)/L**len(x),-L) for L in scales)
    return best[0],-best[1],len(scales)

def main():
    out={'arithmetic':'fractions.Fraction; deterministic; no random seed required'}
    # Phase 1: exact uniform-in-direction bounding constants, enlarged dimensions.
    rows=[]
    for n in [1,2,3,4,8,16,32,64,128,256,1024,4096]:
        eta=F(1,8*n); D=16*n; K=128*n*n
        interior=F(K-32*n,K)**n
        envelope=2*(1+eta)**n
        weak=F(1,2)*(1+F(1,8*n))**n
        assert interior>=F(3,4) and envelope<3 and weak<F(57,100)
        rows.append({'n':n,'interior_fraction_float':float(interior),'F_over_rn_upper_float':float(envelope),'true_fee_upper_float':float(weak),'rational_checks':True})
    out['dimension_guards']=rows
    # Phase 2: exact lattice box counts, both cone signs and non-face coordinates.
    checks=0
    for n in [1,2,4,8,16]:
        eta=F(1,8*n); D=16*n; K=128*n*n
        for sign in [-1,1]:
            omega=[F(sign)]+[F(((3*j)%9)-4,4) for j in range(1,n)]
            for y0 in [F(2),F(D,2),F(D-2)-eta]:
                y=[y0]*n
                previous=None
                for r in [F(1),F(9,8),F(3,2),F(15,8),F(2)]:
                    x=[t+r*u/2 for t,u in zip(y,omega)]
                    f=mass(x,r,eta,K)
                    assert f<=2*(r+eta)**n and f<3*r**n
                    assert mass(x,F(1),eta,K)>=2*(1-eta)**n>=F(7,4)
                    assert previous is None or previous<=f
                    previous=f; checks+=1
    out['exact_anchored_box_checks']=checks
    # Phase 3: actual continuous-window maxima, exact finite critical radii.
    maxima=[]
    for n in [1,2,3,4]:
        eta=F(1,8*n); D=16*n; K=128*n*n
        for label,x in [('interior',[F(D,2)+F(j+1,37)*eta for j in range(n)]),('edge',[F(-1,2)+F(j,41)*eta for j in range(n)]),('mixed',[F(2)+F(j+1,31)*eta for j in range(n)])]:
            H,L,c=winner(x,eta,K)
            assert H<=2*(1+eta)**n
            if label!='edge': assert H>1
            maxima.append({'n':n,'case':label,'H':str(H),'L':str(L),'critical_scales':c})
    out['exact_continuous_winners']=maxima
    # Full-space 1D weak-set length: union over all contiguous captured blocks.
    unions=[]
    for refine in [1,2,4]:
        eta=F(1,8*refine); D=16; K=int(D/eta); intervals=[]
        for j in range(K):
            for k in range(j,K):
                diameter=(k-j)*eta
                if diameter>2: break
                m=2*eta*(k-j+1)
                if m<=1: continue
                U=min(F(2),m)
                if diameter>=U: continue
                intervals.append((k*eta-U/2,j*eta+U/2))
        intervals.sort(); total=F(0); left=right=None
        for lo,hi in intervals:
            if right is None: left,right=lo,hi
            elif lo<=right: right=max(right,hi)
            else: total+=right-left; left,right=lo,hi
        if right is not None: total+=right-left
        assert total/(2*D)<F(57,100)
        unions.append({'refinement':refine,'atoms':K,'weak_length':str(total),'weak_ratio':str(total/(2*D))})
    out['full_space_1d_checks']=unions
    print(json.dumps(out,indent=2,ensure_ascii=False,sort_keys=True))
if __name__=='__main__': main()
