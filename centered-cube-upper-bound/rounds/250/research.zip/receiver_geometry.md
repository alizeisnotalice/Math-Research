# R250：共同接收容量筛查与首次未付的来源容量

本轮没有证明中间质量区间的根阶预算。下面保留一项严格的接收域截断弱型改进，完整接回 R249 CB1；其极重来源推论不是本轮一般问题的替代。随后说明直接共同可见性输运为什么尚不能使中间区间按一次来源质量结算。

## RG1　保留原测度的接收域截断

固定原来源 \(0\le\mu\le f\,dx\)、真实接收域 \(E\)、\(X_E=\lambda|E|\)，且
\[
 M f(x):=\sup_{a\le R\le b}h_R*f(x)\le4\lambda
 \quad(x\in E),\qquad 0<a\le b\le2a.
 \tag{1}
\]
这是原完整输入的 all-scale hard band，来源不是新的后验。按完整边长 \(d=a/n\) 网格记 \(\mu_i=\mu|_{C_i}\)、\(m_i=\|\mu_i\|\)，\(z_i\) 为格中心。定义
\[
 f_i=\mathbf1_E M\mu_i,\quad S_i=E\cap Q_{b+d}(z_i),
 \quad c_1=(1+1/n)^n,
\]
\[
 a_i=\min\{c_1m_i,\ 4\lambda|S_i|\}.
 \tag{2}
\]
两个候选都是真实弱型常数。第一项是 R249 CG2，对块内任意 L1 密度成立；第二项用 \(0\le f_i\le4\lambda\mathbf1_{S_i}\)。因此
\[
 u|\{f_i>u\}|\le a_i\qquad(u>0).
 \tag{3}
\]
若 \(a_i=0\)，\(f_i=0\) 几乎处处，可从接收响应中删去该零项；这不删原后验的来源。

取任一合法共同支持邻接图，包括粗图
\(i\sim j\iff\|z_i-z_j\|_\infty\le b+d\)，记
\[
 A_i=\sum_{j\sim i}a_j,\quad
 \mathcal B_E(\mu)=\sum_i a_i
 \left[3+2\log2+2\log(A_i/a_i)\right].
 \tag{4}
\]
图含自环，并且只用于分析；不作为原 transport 的新允许边。R249 LG1 对 (3) 直接给
\[
 u|\{\mathbf1_E M\mu>u\}|\le\mathcal B_E(\mu),
\quad
 \int_E M\mu\le\varepsilon X_E+
                  \frac4\varepsilon\mathcal B_E(\mu).
 \tag{5}
\]
第二式取截断 \(u=\varepsilon\lambda\)，保真实 \(dx\) 和 (1)。可数族使用非负 Tonelli/有限部分和；\(\sum a_i\le c_1\|\mu\|<\infty\)，右端也允许无穷。

此改进确实不会增加原局部熵价。对于有限对称含自环图，函数
\(\Phi(a)=(3+2\log2)\sum a_i+2\sum a_i\log(A_i/a_i)\)
逐坐标非减。正坐标上其第 \(k\) 个导数为
\[
 3+2\log2+2\left[\log(A_k/a_k)-1+
                   \sum_{i\sim k}a_i/A_i\right]\ge0,
\]
因为自环项和 \(\log x-1+1/x\ge0\) 已足够。零坐标用连续极限。因此 (2) 给
\(\mathcal B_E(\mu)\le c_1B_{\rm loc}(\mu)\)；可数图由非负有限限制极限得到相同结论。它使用实际接收支持大小，不要求各块独立或接收支持互斥。

## RG2　接回同一 partial flow 的完整费用

保 R249 CB1 的同一固定来源分解 \(\mu_d+\mu_p+\mu_r=\mu\)，低块阈值 \(\sigma=\lambda\sqrt n\)，以及真实可行 partial typed flow \(z\)。不改它的源子测度、原允许边、完整体积因子 \(F_I\)、共享目标帽或 profile 价 \(A(z)\)。仅将 residual 的 LG1 常数换为 (2)，可得
\[
\begin{split}
 \int_E M\mu\le{}&
 (\varepsilon_d+\varepsilon_p+\varepsilon_r)X_E
 +\frac{C_2^2(1+2/n)^{2n}\sigma\|\mu_d\|}
       {4\varepsilon_d\lambda}\\
 &+\frac{C_5^2\tau A(z)}{4\varepsilon_p\lambda}
 +\frac{4\mathcal B_E(\mu_r)}{\varepsilon_r}.
 \tag{6}
\end{split}
\]
这里每个来源只分配一次，三个 \(\varepsilon\) 费用只相加一次。原多网络组合、seed、互斥叶接收域和任何外乘常数仍按 CB1 原账处理。(6) 只作用于已经合法上放为这个硬来源积分的交通，不能自动支配原双后验余项。特别没有给原 \(\beta,\nu\) 安装新 cut，也没有删除完整 \(\Pi_t\) 中的来源。

## RG3　明确但不足的极重来源后果

粗邻接图度数至多 \(D_n=(4n+3)^n\)。Jensen 与对称性给
\[
 \mathcal B_E(\mu)\le L_n\sum_i a_i,
 \qquad L_n=3+2\log2+2\log D_n.
 \tag{7}
\]
对于任意由质量 \(m_i\ge M_*\) 的块组成的来源 \(\mu_H\)，不论块内密度或块间位置，
\[
 \sum_i a_i\le4\lambda(b+d)^n\frac{\|\mu_H\|}{M_*}.
\]
故选择
\[
 M_*:=\frac{4\lambda(b+d)^nL_n}{\sqrt n}
 \tag{8}
\]
便有 \(\mathcal B_E(\mu_H)\le\sqrt n\|\mu_H\|\)，(5) 给相应实际硬接收积分的根阶价。这不是点源结论，也不需要构造 partial flow。

但 (8) 与低块平滑阈值 \(m_{\rm low}=\lambda\sqrt n\,d^n\) 之间有明确差距：
\[
 \frac{M_*}{m_{\rm low}}=
 \frac{4L_n}{n}(nb/a+1)^n.
 \tag{9}
\]
它在原允许尺度下仍是指数级。因而极重组的付款没有解决本任务的中间组，也没有控制一般 \(\tau A(z)/\lambda+\mathcal B_E(\mu_r)\)。本稿不以 (8) 宣称本轮一般几何目标完成。

## RG4　共同可见性输运：精确边缘与缺失步骤

固定任意实际可测物理选择器 \(R(x)\in[a,b]\)，令
\[
 d\pi(y,x)=\mathbf1_E(x)h_{R(x)}(x-y)\,\mu(dy)dx.
 \tag{10}
\]
这是保共同来源和真实接收几何的非负测度；其两个边缘精确为
\[
 \pi_x(dx)=\mathbf1_E(x)(h_{R(x)}*\mu)(x)dx
                \le4\lambda\mathbf1_E(x)dx,
\]
\[
 \pi_y(dy)=O(y)\mu(dy),\qquad
 O(y)=\int_E h_{R(x)}(x-y)dx.
 \tag{11}
\]
原 all-scale upper band 控制第一个边缘；它没有把第二个变成一次来源质量。直接核包络只给
\[
 O(y)\le\int_{\mathbb R^n}\sup_{a\le R\le b}h_R(x-y)dx
       =1+n\log(b/a).
 \tag{12}
\]
等式由内核 \(Q_a\) 贡献一和立方体半径层 \(n\,dR/R\) 得到。这一线性价不能充作根阶 source capacity。

若改构另一个同可见性支持的输运并要求来源边缘至多 \(C\mu\)，则必须证明这个新的来源容量；target 的 (11) 本身没有提供它。若进一步使用原中间层下界，必须区分：\(h_{R(x)}*f\ge\lambda\) 只对 \(\mu=f\) 授予 \(\lambda\mathbf1_Edx\) 的 target demand，对一般子来源 \(\mu\le f\) 不成立。即使在 \(\mu=f\) 的合法下界分支，任何来源边缘 \(\le C\mu\)、目标边缘 \(=\lambda\mathbf1_Edx\) 的输运已直接蕴含 \(\lambda|E|\le C\|\mu\|\)。不能把这个待证容量当作聚合步骤的免费性质。

此外，(10) 允许同时改变全部坐标。它不是原至多 \(r\) 坐标的 typed 计划；若把它离散成该网络或多步计划，必须证明可行性，保每一步的真实 \(F_I\)、共享容量和合并费用。R249 typed Hall 只给 profile-weighted 邻域，不提供所需物理覆盖下界。这是本轮共同可见性路线停下的位置：**尚无把中间组的共同 target cap 转成一次来源帽，同时具有可支付 typed 几何费用的构造或不等式。**

## RG5　检查与交付范围

本机 Python 标准库实际核算了 (9) 在 \(b=2a\)、\(n=512,10^4,10^6\) 的对数差距，分别约为 \(3553.52489787\)、\(99039.8155186\)、\(14508663.0394\)。另对以下三个有限非负函数族，以正支持交叠定义邻接、以 \(\max_u u\#\{f_i\ge u\}\) 为各项弱常数，实际检查了支持局部弱型不等式的全部和函数值，共 8 项通过：

```
[[1,0,0,0],[0,2,0,0]]
[[1,3,0,0],[0,2,4,0],[0,0,1,5]]
[[2,2,2,0],[1,0,1,0],[0,4,0,0]]
```

这些是有限代数和参数核查，不是 FULL 构造、区间证书或普遍根阶证据。连续证明在 RG1–RG4 给出。本轮新辅助界是 (2)–(6)，中间来源的根阶付款未得；不追加新未付矩来声称闭合，停止本轮探索。
