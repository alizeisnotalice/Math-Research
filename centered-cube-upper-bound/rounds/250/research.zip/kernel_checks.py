"""Finite evidence for MK1/MK2: exact threshold geometry and MP quadrature."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,random
import mpmath as mp

def exact_threshold_tests():
    rng=random.Random(250)
    result=[]
    for phase,count in [('initial',6),('pressure',24),('expanded',96)]:
        for k in range(count):
            n=1+k%3
            points=[tuple(F(rng.randrange(-6,7),2) for _ in range(n)) for _ in range(2+k%11)]
            weights=[F(rng.randrange(1,10),3) for _ in points]
            x=tuple(F(rng.randrange(-3,4),2) for _ in range(n));u=F(1+k%13,4)
            dist=lambda p,q:max(abs(s-t) for s,t in zip(p,q))
            local=[sum((w for z,w in zip(points,weights) if dist(y,z)<=2),F()) for y in points]
            A=sum((w for y,w in zip(points,weights) if dist(x,y)<=1),F())
            low=F()
            for y,w,m in zip(points,weights,local):
                assert m>0
                r=2*dist(x,y)
                K=F(0) if r>2 else F(1) if r<=1 else r**(-n)
                if K:
                    assert m>=A
                if K<=u/(2*m):low+=w*K
            assert low<=u/2
            result.append({'phase':phase,'n':n,'sources':len(points),'u':str(u),'low_exact':str(low)})
    return result

def quadrature(dps):
    mp.mp.dps=dps
    result=[]
    for phase,ns in [('initial',[1,2]),('pressure',[8,32]),('expanded',[128,512])]:
        for n in ns:
            for a in [mp.mpf('0.5'),mp.mpf('1.5')]:
                b=2*a
                for q in [mp.mpf(1),mp.mpf('1.1'),mp.mpf('.5'),mp.power(2,-n),mp.power(2,-n-2)]:
                    # q=t*a^n; strict superlevel removes the entire plateau at q=1.
                    if q>=1:
                        explicit=mp.mpf(0);integral=mp.mpf(0)
                    else:
                        t=q/a**n;end=min(b,mp.power(t,-mp.mpf(1)/n))
                        integral=1+mp.quad(lambda r:n*mp.power(r,n-1)*mp.power(r,-n),[a,end])
                        explicit=1+min(n*mp.log(b/a),mp.log(1/q))
                    error=abs(integral-explicit)/(1+abs(explicit))
                    assert error<mp.power(10,-dps+8)
                    result.append({'phase':phase,'n':n,'a':str(a),'q':mp.nstr(q,25),
                                   'value':mp.nstr(explicit,25)})
    return result

if __name__=='__main__':
    exact=exact_threshold_tests();lo=quadrature(50);hi=quadrature(80);assert lo==hi
    out={'scope':'126 exact atomic finite threshold checks; 60 radial integral checks at 50/80 digits. Not L1/FULL instances or a directed interval proof.',
         'seed':250,'exact_checks':exact,'radial_checks':hi,'precisions':[50,80],
         'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'exact_threshold_checks':len(exact),'radial_checks':len(hi),'reported_precision_agreement':True}))
