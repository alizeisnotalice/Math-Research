#!/usr/bin/env python3
"""R250 positive-Lebesgue hardband cell certificates and height-aware fees."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import argparse,hashlib,json
import mpmath as mp

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fracvec(x):return [str(y) for y in x]
def fm(x):return mp.mpf(x.numerator)/x.denominator
def enc(x):return mp.nstr(x,50)
def piece(center,side,mass):return {'center':tuple(center),'side':side,'mass':mass,'density':mass/side**len(center)}
def uniform(n,k=1):
    side=F(1,k*n)
    return [piece(tuple(F(-1,2)+(F(i)+F(1,2))*side for i in idx),side,2*side**n) for idx in product(range(k*n),repeat=n)]
def menu():
    n2=lambda x:tuple(map(F,x));n3=lambda x:tuple(map(F,x))
    basic=[('initial','spread_unitcube_n2',2,uniform(2),[n2([0,0])],1),
      ('initial','single_concentrated_n2',2,[piece(n2([0,0]),F(1,2),F(2))],[n2([0,0])],1),
      ('pressure','adjacent_pair_n2',2,[piece(n2([0,0]),F(1,2),F(2)),piece(n2(['1/2',0]),F(1,2),F(2))],[n2(['1/4',0])],1),
      ('pressure','sparse_periodic_n2',2,[piece(n2(x),F(1,2),F(2)) for x in [(0,0),(4,0),(0,4),(4,4)]],[n2(x) for x in [(0,0),(4,0),(0,4),(4,4)]],1),
      ('expanded','spread_unitcube_n3',3,uniform(3),[n3([0,0,0])],1),
      ('expanded','anisotropic_cluster_n3',3,[piece(n3([F(i,3),0,0]),F(1,3),F(1)) for i in range(3)],[n3(['1/3',0,0])],1)]
    return basic+[('representation',f'same_unitcube_n2_k{k}',2,uniform(2,k),[n2([0,0])],k) for k in [2,4]]

def length(src_center,src_side,x,R):return max(F(),min(src_center+src_side/2,x+R/2)-max(src_center-src_side/2,x-R/2))
def bounds(p,center,rcside,R):
    low=high=p['density']
    for z,x in zip(p['center'],center):
        left,right=x-rcside/2,x+rcside/2
        ends=[length(z,p['side'],left,R),length(z,p['side'],right,R)]
        peak=min(right,max(left,z))
        low*=min(ends);high*=max(*ends,length(z,p['side'],peak,R))
    assert 0<=low<=high<=p['mass']
    return low,high

def candidates(n,anchors):
    points=set()
    for anchor in anchors:
        points.add(anchor)
        for j in range(n):
            for v in ([F(-1,2),F(-1,4),F(1,4),F(1,2)] if n==2 else [F(-1,4),F(1,4)]):
                z=list(anchor);z[j]+=v;points.add(tuple(z))
    return sorted(points)

def overlap_common(receiver,side,p,q,b=F(2)):
    out=F(1)
    for x,z,w in zip(receiver,p['center'],q['center']):
        lo=max(x-side/2,z-(b+p['side'])/2,w-(b+q['side'])/2)
        hi=min(x+side/2,z+(b+p['side'])/2,w+(b+q['side'])/2)
        out*=max(F(),hi-lo)
    return out>0

def geometry(spec):
    phase,name,n,ps,anchors,k=spec;rcside=F(1,16*n);grid=[F(8+j,8) for j in range(9)];records=[];bound_checks=0
    centers=candidates(n,anchors)
    assert all(any(abs(x-y)>=rcside for x,y in zip(a,b)) for idx,a in enumerate(centers) for b in centers[idx+1:])
    for center in centers:
        lowers=[];uppers=[]
        for R in grid:
            bl=bh=F()
            for p in ps:
                low,high=bounds(p,center,rcside,R);bl+=low;bh+=high;bound_checks+=1
            lowers.append(bl);uppers.append(bh)
        L=max(low/R**n for low,R in zip(lowers,grid))
        U=max(uppers[j+1]/grid[j]**n for j in range(len(grid)-1))
        assert U>=L
        certified=L>=1 and U<=4
        records.append({'center':fracvec(center),'lower_grid_mass_exact':fracvec(lowers),'upper_grid_mass_exact':fracvec(uppers),'octave_response_lower_exact':str(L),'octave_response_upper_exact':str(U),'in_E':certified})
    E=[tuple(F(x) for x in r['center']) for r in records if r['in_E']];volume=len(E)*rcside**n
    masses=[p['mass'] for p in ps];W=sum(masses,F());d0=F(1,n)
    coarse=[[j for j,q in enumerate(ps) if max(abs(x-y) for x,y in zip(p['center'],q['center']))<=2+d0] for p in ps]
    actual=[[j for j,q in enumerate(ps) if i==j or any(overlap_common(c,rcside,p,q) for c in E)] for i,p in enumerate(ps)]
    assert all(i in ns for i,ns in enumerate(actual))
    assert all(set(ns)<=set(coarse[i]) for i,ns in enumerate(actual))
    # Physical side-2b source neighborhood; certify constant mass on each separated cluster.
    min_distance=lambda p,q:max(max(F(),abs(x-y)-(p['side']+q['side'])/2) for x,y in zip(p['center'],q['center']))
    max_distance=lambda p,q:max(abs(x-y)+(p['side']+q['side'])/2 for x,y in zip(p['center'],q['center']))
    unseen=set(range(len(ps)));clusters=[]
    while unseen:
        component={min(unseen)};changed=True
        while changed:
            expanded=component|{j for i in component for j in unseen if min_distance(ps[i],ps[j])<=2}
            changed=expanded!=component;component=expanded
        unseen-=component;clusters.append(sorted(component))
    assert all(max_distance(ps[i],ps[j])<=2 for comp in clusters for i in comp for j in comp)
    assert all(min_distance(ps[i],ps[j])>2 for x,ca in enumerate(clusters) for cb in clusters[x+1:] for i in ca for j in cb)
    mb=[sum((masses[j] for comp in clusters if i in comp for j in comp),F()) for i in range(len(ps))]
    actualM=[sum((masses[j] for j in ns),F()) for ns in actual];coarseM=[sum((masses[j] for j in ns),F()) for ns in coarse]
    # Original sigma=lambda*sqrt(n): exact classification without square roots.
    concentrated=[p['density']**2>n for p in ps]
    return {'phase':phase,'name':name,'n':n,'a':'1','b':'2','lambda':'1','original_transport_d':str(d0),'analysis_piece_side':str(ps[0]['side']),'representation_k':k,'representation_scope':'finer pieces are only an analysis decomposition; original transport d and graph qualification unchanged','sources':[{'center':fracvec(p['center']),'side':str(p['side']),'mass':str(p['mass']),'density':str(p['density'])} for p in ps],'R_grid':fracvec(grid),'receiver_side':str(rcside),'receiver_cell_volume':str(rcside**n),'receiver_records':records,'E_cell_count':len(E),'E_volume_exact':str(volume),'source_mass_exact':str(W),'physical_source_clusters':clusters,'physical_mb_exact':fracvec(mb),'physical_cluster_scope':'within-cluster maximum Linfinity box-point distance <=b; between-cluster minimum >b; hence mu(Q_side2b(y)) constant on each source piece','coarse_neighbors':coarse,'actual_E_support_neighbors':actual,'coarse_neighbor_mass_exact':fracvec(coarseM),'actual_neighbor_mass_exact':fracvec(actualM),'source_mass_classification_sigma_sqrt_n':{'concentrated_mass':str(sum((p['mass'] for p,flag in zip(ps,concentrated) if flag),F())),'diffuse_mass':str(sum((p['mass'] for p,flag in zip(ps,concentrated) if not flag),F()))},'receiver_integral_lower_exact':str(sum((F(r['octave_response_lower_exact'])*rcside**n for r in records if r['in_E']),F())),'receiver_integral_upper_exact':str(sum((F(r['octave_response_upper_exact'])*rcside**n for r in records if r['in_E']),F())),'per_source_R_cell_bound_checks':bound_checks}

def height(row,dps):
    with mp.workdps(dps):
        masses=[F(p['mass']) for p in row['sources']];W=sum(masses,F());M=list(map(F,row['actual_neighbor_mass_exact']));Mc=list(map(F,row['coarse_neighbor_mass_exact']));n=row['n'];c1=(1+F(1,n))**n;piece_c1=(1+F(row['analysis_piece_side']))**n
        entropy=sum((fm(m)*mp.log(fm(v/m)) for m,v in zip(masses,M)),mp.mpf(0));coarse_entropy=sum((fm(m)*mp.log(fm(v/m)) for m,v in zip(masses,Mc)),mp.mpf(0));global_entropy=sum((fm(m)*mp.log(fm(W/m)) for m in masses),mp.mpf(0))
        old=(3+2*mp.log(2))*fm(W)+2*entropy
        fees=[]
        positive=lambda x:max(mp.mpf(0),x)
        primitive=lambda x,c:x+x*x/2-positive(x-c)**2/2
        for u in [F(1,4),F(1,2),F(1),F(2),F(3)]:
            mb=list(map(F,row['physical_mb_exact']))
            mesh=2*sum((fm(m)*(1+min(n*mp.log(2),mp.log(fm(2*v/u)))) for m,v in zip(masses,mb) if 2*v>u),mp.mpf(0))
            first=sum((m for m in masses if m>u),F())
            second=2*sum((fm(m)*(1+mp.log(fm(2*v/max(m,u)))) for m,v in zip(masses,M) if 2*v>u),mp.mpf(0))
            B=fm(first)+second
            assert B<=old+mp.mpf(10)**(-dps+6) and B>=0
            H_integral=mp.mpf(0);mesh_integral=mp.mpf(0)
            for m,v,mbv in zip(masses,M,mb):
                ci=mp.log(fm(2*v/m));vx=2*v
                H_integral+=fm(m)*(positive(mp.log(fm(m/u)))-positive(mp.log(fm(m/4)))+2*(primitive(positive(mp.log(fm(vx/u))),ci)-primitive(positive(mp.log(fm(vx/4))),ci)))
                mesh_integral+=2*fm(m)*(primitive(positive(mp.log(fm(2*mbv/u))),n*mp.log(2))-primitive(positive(mp.log(fm(2*mbv/4))),n*mp.log(2)))
            assert H_integral>=0 and mesh_integral>=0
            vol=F(row['E_volume_exact']);super_lower=sum((F(row['receiver_cell_volume']) for r in row['receiver_records'] if r['in_E'] and F(r['octave_response_lower_exact'])>u),F());super_upper=sum((F(row['receiver_cell_volume']) for r in row['receiver_records'] if r['in_E'] and F(r['octave_response_upper_exact'])>u),F())
            # This finite menu may verify the stronger upper proxy; keep its truth value separate.
            fees.append({'u':str(u),'mesh_free_candidate_fee':enc(mesh),'mesh_fee_per_mass':enc(mesh/fm(W)),'old_normalized_entropy_price':enc(old/fm(W)),'height_normalized_price':enc(B/fm(W)),'natural_piece_old_fee':enc(fm(piece_c1)*old),'natural_piece_height_fee':enc(fm(piece_c1)*B),'height_integral_without_c1':enc(H_integral),'mesh_integral_fee':enc(mesh_integral),'height_aware_B':enc(B),'old_B_loc':enc(old),'B_ratio_old':enc(B/old),'c1B':enc(fm(c1)*B),'superlevel_volume_lower_exact':str(super_lower),'superlevel_volume_upper_exact':str(super_upper),'strong_cell_upper_proxy_below_fee':bool(fm(u*super_upper)<=fm(c1)*B),'hard_integral_payment_upper':enc(fm(u*vol)+4*fm(c1)*B/fm(u)),'height_all_level_integral_upper_original_c1':enc(fm(u*vol)+fm(c1)*H_integral),'height_all_level_integral_upper_natural_c1':enc(fm(u*vol)+fm(piece_c1)*H_integral),'mesh_free_all_level_integral_upper':enc(fm(u*vol)+mesh_integral)})
        return {'c1_natural_piece_exact':str(piece_c1),'c1_original_grid_exact':str(c1),'actual_support_entropy':enc(entropy),'coarse_support_entropy':enc(coarse_entropy),'global_entropy':enc(global_entropy),'old_B_loc':enc(old),'fees':fees}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));ap.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md'));ap.add_argument('--basic-only',action='store_true');args=ap.parse_args()
    rows=[geometry(c) for c in menu()]
    out={'source_sha256':sha(__file__),'contract_sha256':sha(args.contract) if args.contract.exists() else None,'scope':'Finite positive-Lebesgue piecewise constant sources; exact rational receiver-cell and continuum-octave bounds. No FULL, transport-network replacement or general order inference. No QP/MATLAB needed in this round.','dependencies':{'python':'3.12.14','mpmath':mp.__version__},'height_formula_status':'not run' if args.basic_only else 'HT5/HT9 and MK2/MK3 evaluated; original-grid and natural-piece c1 both recorded','cases':rows}
    maxdiff=mp.mpf(0)
    if not args.basic_only:
        assert args.contract.exists()
        for row in rows:
            lo,hi=height(row,40),height(row,70)
            with mp.workdps(100):
                pairs=[(lo[k],hi[k]) for k in ['actual_support_entropy','coarse_support_entropy','global_entropy','old_B_loc']]+[(a[k],b[k]) for a,b in zip(lo['fees'],hi['fees']) for k in ['mesh_free_candidate_fee','mesh_fee_per_mass','old_normalized_entropy_price','height_normalized_price','natural_piece_old_fee','natural_piece_height_fee','height_integral_without_c1','mesh_integral_fee','height_aware_B','old_B_loc','B_ratio_old','c1B','hard_integral_payment_upper','height_all_level_integral_upper_original_c1','height_all_level_integral_upper_natural_c1','mesh_free_all_level_integral_upper']]
                delta=max((abs(mp.mpf(a)-mp.mpf(b))/max(1,abs(mp.mpf(b))) for a,b in pairs),default=mp.mpf(0));assert delta<mp.mpf('1e-25');maxdiff=max(maxdiff,delta)
            row.update({'mp40':lo,'mp70':hi,'precision_max_scaled_difference':enc(delta)})
        # Same physical density2 unit cube, fixed original constants and actual E.
        same=[row for row in rows if row['name'] in ['spread_unitcube_n2','same_unitcube_n2_k2','same_unitcube_n2_k4']]
        assert len({row['E_volume_exact'] for row in same})==1
        for j in range(1,5):assert len({row['mp70']['fees'][j]['height_aware_B'] for row in same})==1
        for j in range(5):assert len({row['mp70']['fees'][j]['mesh_free_candidate_fee'] for row in same})==1
        out['representation_summary']=[{'k':row['representation_k'],'source_piece_count':len(row['sources']),'E_volume_exact':row['E_volume_exact'],'old_B_loc':row['mp70']['old_B_loc'],'natural_piece_c1_exact':row['mp70']['c1_natural_piece_exact'],'old_normalized_entropy_u_half':row['mp70']['fees'][1]['old_normalized_entropy_price'],'height_normalized_u_half':row['mp70']['fees'][1]['height_normalized_price'],'natural_piece_old_fee_u_half':row['mp70']['fees'][1]['natural_piece_old_fee'],'natural_piece_height_fee_u_half':row['mp70']['fees'][1]['natural_piece_height_fee'],'height_B_u_half':row['mp70']['fees'][1]['height_aware_B'],'mesh_free_candidate_u_half':row['mp70']['fees'][1]['mesh_free_candidate_fee']} for row in same]
        out['precision_summary']={'max_scaled_difference':enc(maxdiff),'scope':'enc50 mp40/mp70 ordinary log evaluation, not interval error'}
    out['counts']={'basic_families':6,'representation_additions':2,'model_records':8,'source_pieces':sum(len(r['sources']) for r in rows),'receiver_candidates':sum(len(r['receiver_records']) for r in rows),'certified_E_cells':sum(r['E_cell_count'] for r in rows),'per_source_R_cell_bound_checks':sum(r['per_source_R_cell_bound_checks'] for r in rows),'height_fee_checks':0 if args.basic_only else 5*len(rows),'mesh_free_fee_checks':0 if args.basic_only else 5*len(rows),'closed_all_level_integrals':0 if args.basic_only else 10*len(rows)}
    args.output.write_text(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    for row in rows:print(row['name'],len(row['sources']),row['E_cell_count'],row['E_volume_exact'],flush=True)
    print(out['counts'])
if __name__=='__main__':main()
