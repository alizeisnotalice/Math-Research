# R250: receiver geometry and height-aware source costs

The objective remains the general arbitrary-positive-L1 centered-cube weak n^(1/2+o(1)) bound and its original joint-traffic accounting. R249 is frozen and pushed. This round must change the middle-source geometric estimate, not merely rename an unpaid objective.

Author responsibilities:
- Astra peak, receiver_geometry.md: actual receiver incidence and capacity qualification; receiver-cap weak constant as auxiliary only. No claim that an extreme-heavy-cell gate settles the middle source range.
- Sol compare, localization.md: height-aware truncation of support-local weak summation, exact level costs and integration, optional valid weighted-core pruning. Preserve the full low-threshold interval and shared-source qualifications.
- Sol numeric, numeric_checks.py/json and numeric_notes.md: six actual source families, positive-volume receiver boxes, exact Fraction continuum-octave bounds from a radius grid and monotone mass; three stages. Also subdivide one unchanged physical source to test artificial mesh-entropy dependence. No new QP merely to duplicate R249.
- Sol audit, audit.md: independently screen statements before authors; audit constants, source conservation, true receiver measure, all scales and claim scope.
- Main: continuous mesh-free kernel truncation, synthesis, independent reproduction and final archive.

Allowed tools are R249 CG/LG/CB1, the actual finite-band centered-cube kernel and elementary positive integration. Retain actual E and the original all-scale M f<=4 lambda cap when used. Do not infer sum_i M(mu_i)<=4 lambda from M(sum_i mu_i)<=4 lambda. Do not delete sources from original posteriors using an analysis-only superlevel decomposition. All typed plan/coupling qualifications from R248/R249 remain.

Numerical evidence must distinguish exact rational geometric enclosures from multiprecision logarithm comparisons. L03 is used only within that boundary; no generic directed-rounding library is certified. No order is extrapolated from n=2,3. Original r/transport grid is not changed by an analysis-only source subdivision.

Success is an independently checked new cost improvement or actual evidence changing the next proof decision. Root closure still requires a uniform total source price and legal return to the remaining double-posterior traffic. Preserve detailed LaTeX text, do not compile PDF; whitelist final README+research.zip and project overview, one commit/push after final verification.
