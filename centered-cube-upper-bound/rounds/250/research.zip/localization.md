# R250: height-truncated local summation and all-level receiver cost

This note owns only this file. It refines the R249 local weak-sum
price by the actual height and level-dependent support of each block.
It applies to arbitrary nonnegative L1 density inside every block.
The resulting costs are explicit source/receiver quantities and are
no larger than the old local-entropy costs. They are not asserted to
have a general root bound, and they do not bound the original unpaid
double-posterior traffic before a legitimate hard-source domination.

## HT1. Actual objects and the two distinct receiver bounds

Let mu be a finite nonnegative L1 density with mu<=f dx. Keep the
original finite-measure receiver E and its actual hard band

    Mmu(x):=sup_{a<=R<=b}h_R*mu(x)<=4lambda on E,
    0<a<=b<=2a, X=lambda|E|.

Use the complete grid cubes C_i=Q_d(z_i), d=a/n, and write
`mu_i=mu|C_i`, `m_i=||mu_i||>0`, `W=sum_i m_i`. Actual pieces C_i
intersect V may be contained in these full analysis cubes. Put

    f_i=1_E Mmu_i, F=1_E Mmu,
    c1=(1+1/n)^n<=e.

The distinct true bounds are

    F<=sum_i f_i,
    f_i<=m_i/a^n, f_i<=4lambda, F<=4lambda.           (HT1)

No bound `sum_i f_i<=4lambda` is used or claimed. Different source
blocks may attain their separate suprema at different scales.
R249 CG2 gives `t|{f_i>t}|<=c1 m_i`.

Choose one symmetric graph including self that covers all actual
simultaneously nonzero pairs f_i,f_j. The old explicit choice is
`|z_i-z_j|_infinity<=b+d`, since f_i is supported in
`E intersect Q_{b+d}(z_i)`. Set

    M_i=sum_{j similar i}m_j, M_i>=m_i>0.

These are masses of the same original source, not new selected
posterior sources. Countable families are allowed; M_i<=W<infinity.

## HT2. A true level-dependent tail envelope

For t>0 define r_i(t)=min{b,(m_i/t)^{1/n}} and

    V_i(t)=1_{m_i>t a^n}1_{t<4lambda}
                  |E intersect Q_{r_i(t)+d}(z_i)|,
    T_i(t)=min{c1 m_i/t,V_i(t)}.                     (HT2)

Then `|{f_i>t}|<=T_i(t)`. In fact if Mmu_i(x)>t, some original
R has mass response >t, hence m_i>tR^n>=ta^n and
`x in Q_{R+d}(z_i) subset Q_{r_i(t)+d}(z_i)`.
The additional cutoff t<4lambda follows from the individual bound
in HT1. This proof retains the block's original density and true dx;
it does not replace mu_i by a point mass or truncate a soft kernel.
The envelopes are nonincreasing and jointly measurable in t. Box
boundaries do not affect their Lebesgue volumes.

## HT3. The full single-level price, including all lower thresholds

For a global output level u in (0,4lambda), set the STATIC source
thresholds

    ell_i(u)=u m_i/(2M_i), 0<ell_i<=u/2,
    Psi_E(u)=u sum_i T_i(u)
       +2 sum_i [ell_i T_i(ell_i)
                           +integral_{ell_i}^u T_i(t)dt]. (HT3)

Then the exact weak price is

    u|{x in E:Mmu(x)>u}|<=Psi_E(u).                  (HT4)

Proof: first remove the union of {f_i>u}, costing at most
sum_i T_i(u). At any remaining x, its active indices form a clique.
Consequently M_i is at least the total active mass for each active i,
and sum_active m_i/M_i<=1. The sum of terms with f_i<=ell_i is thus
at most u/2. If F>u, the other terms have sum greater than u/2.
Their integral is bounded, term by term, by

    integral f_i 1_{ell_i<f_i<=u}
       <=ell_i |{f_i>ell_i}|+integral_{ell_i}^u|{f_i>t}|dt.

Insert HT2 and apply Markov to their sum. This proves HT4. Nonnegative
Tonelli handles countably many blocks directly; the active total mass
is finite, and the same clique argument applies. All middle levels
ell_i<=t<=u are paid explicitly in HT3. In particular a graph made
only from the smaller output-level boxes r_i(u) is not substituted
for the graph of actual supports: it could miss those middle levels.

## HT4. Closed height-truncated local entropy

Define the source-only, level-dependent quantity

    B_ht(u)=sum_{m_i>u a^n}m_i
       +2 sum_{2M_i>u a^n}m_i
             [1+log(2M_i/max{m_i,u a^n})].           (HT5)

Then, for every u in the stated range,

    Psi_E(u)<=c1 B_ht(u)<=c1 B_loc,
    B_loc=(3+2log2)W+2sum_i m_i log(M_i/m_i).         (HT6)

For the first term in HT3 use the height bound: only m_i>ua^n can
contribute and uT_i(u)<=c1m_i. For the middle term put h_i=m_i/a^n.
If h_i<=ell_i, its actual tail is zero throughout. Otherwise its
truncated weak layer cake costs at most

    c1m_i [1+log(min{u,h_i}/ell_i)]
      =c1m_i [1+log(2M_i/max{m_i,ua^n})].

The nonzero condition h_i>ell_i is precisely 2M_i>ua^n. This proves
HT5 with its strict endpoints. HT6 follows by enlarging its first sum
to W and its second logarithm to log(2M_i/m_i). No entropy or source
count is silently discarded.

The gain is not just a renamed target: m_i, M_i and u determine HT5
explicitly. When m_i<ua^n the logarithm no longer contains log(1/m_i)
at fixed M_i. Thus arbitrarily fine small-mass labels in a fixed
mass neighborhood no longer force their old individual-mass entropy
price. The sharper HT3 additionally uses actual E and the shrinking
boxes; no assertion that these geometric volumes are always small
is made.

## HT5. Real receiver integration, with every threshold paid

For any u0 in (0,4lambda), the genuine bound F<=4lambda and layer
cake, applied to F rather than sum_i f_i, prove

    integral_E Mmu dx
       <=u0 |E|+integral_{u0}^{4lambda}Psi_E(u)du/u
       <=u0 |E|+c1 integral_{u0}^{4lambda}B_ht(u)du/u. (HT7)

At u0=epsilon lambda, 0<epsilon<4, the only receiver error in HT7
is epsilon X. There is no free scale or output-threshold menu: its
entire remaining cost is the displayed integral. The cruder single
cutoff alternative is also valid,

    integral_E Mmu<=epsilon X
             +(4/epsilon)Psi_E(epsilon lambda)
       <=epsilon X+(4c1/epsilon)B_ht(epsilon lambda). (HT8)

Take the smaller scalar price when useful. In particular HT7 is at
most `epsilon X+c1 B_loc log(4/epsilon)`. It is not necessary to pay
the old fixed-cutoff factor 4/epsilon if the level integral is used.
No bound for sum_i f_i at the top level has entered this argument.

The height integral in HT7 has a closed expression. Set U=4lambda,

    h_i=m_i/a^n, v_i=2M_i/a^n, c_i=log(2M_i/m_i),
    Phi_c(x)=x+x^2/2-(x-c)_+^2/2 for x>=0.

Then

    integral_{u0}^U B_ht(u)du/u
      =sum_i m_i { [log(h_i/u0)]_+-[log(h_i/U)]_+
          +2[Phi_ci([log(v_i/u0)]_+)
                       -Phi_ci([log(v_i/U)]_+)] }.  (HT9)

Proof: the first indicator integrates to its two positive logarithms.
In the second term substitute x=log(v_i/u). Its integrand is zero
for x<=0 and is `1+min(c_i,x)` for x>0; Phi_c is its primitive.
Every bracket in HT9 is nonnegative. Thus Tonelli also proves the
identity for countable sources and permits infinite prices, though
the source-only truncations are finite at fixed positive u0 and W.

For h_i<=u0 the first bracket vanishes and the second primitive is
simply x+x^2/2 at both arguments, since c_i>=log(v_i/u0). This makes
the removal of the small individual mass entropy transparent.

## HT6. Inserting the improvement into the same original source budget

Apply these lemmas to exactly the residual mu_r of R249 CB1, with
its actual remaining masses and its same block-internal density.
Its cap follows from mu_r<=mu<=f, even when its blocks no longer
exceed the initial high-mass threshold. In CB1 replace the residual
term `4c1 B_loc(mu_r)/epsilon_r`, for 0<epsilon_r<4, by the smaller of

    (4/epsilon_r)Psi_E(epsilon_r lambda),
    integral_{epsilon_r lambda}^{4lambda}Psi_E(u)du/u,

or by their explicit height bounds from HT6/HT9. The error for this
part remains exactly epsilon_r X; the diffuse and profile-plan parts
retain their own previously allocated errors and all original costs.
The optional Gram comparison still needs the same certified source
plan and full F_I. No additional error share is created by evaluating
many levels, and no original source, posterior normalizer, cut,
rank, negative credit, or actual selector is changed.

This is a hard response result. The concentrated soft family has no
compact support of the form HT2, and no identical soft conclusion is
asserted. The old weak-sum local graph gave a worst-case O(n log n)
source price. HT5--9 can be strictly smaller on the actual masses and
receiver geometry, but that comparison does not prove a universal
root price: the surviving local M_i/(lambda a^n), or the explicit
box-overlap volumes in HT3, still need an original geometric budget.
The previously known full hard-octave strong L1 estimate is not
recounted as a new result here. The separate continuous source-local
bound being studied by the main author is not used in this proof.

## HT7. Bounded local check of the closed layer-cake arithmetic

The closed primitive HT9 was actually compared with piecewise
quadrature of its single-block integrand in local mpmath at 60
decimal digits. Seven pairs (h,v) were
`(.01,.1),(.1,1),(1,2),(2,4),(10,40),(.5,20),(.125,.25)`;
u0=.25 and U=4. All seven differences were below 1e-50; maximum
absolute difference was `4.97841222229e-60`. This only checks the
primitive arithmetic, not receiver geometry, FULL, or a dimension
bound. The separate numerical author was sent the complete HT2--9
formulas before its independent finite geometric computation.

```python
import mpmath as m
m.mp.dps=60
err=m.mpf(0)
for hs,vs in [('0.01','0.1'),('0.1','1'),('1','2'),('2','4'),
              ('10','40'),('0.5','20'),('0.125','0.25')]:
 h,v=m.mpf(hs),m.mpf(vs); l=m.mpf('0.25'); U=m.mpf(4)
 c=m.log(v/h)
 F=lambda x:x+x*x/2-max(x-c,0)**2/2
 pos=lambda x:max(x,0)
 closed=pos(m.log(h/l))-pos(m.log(h/U))+2*(
       F(pos(m.log(v/l)))-F(pos(m.log(v/U))))
 breaks=sorted(set([l,U]+[t for t in [h,v] if l<t<U]))
 def f(t):
  return ((1 if t<h else 0)+2*(
          1+m.log(v/max(h,t)) if t<v else 0))/t
 actual=sum(m.quad(f,[a,b]) for a,b in zip(breaks,breaks[1:]))
 err=max(err,abs(closed-actual))
 assert abs(closed-actual)<m.mpf('1e-50')
print('PASS 7',m.nstr(err,12))
```
