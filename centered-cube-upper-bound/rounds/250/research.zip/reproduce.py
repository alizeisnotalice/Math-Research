"""R250 independent rational receiver checks and complete numerical replay."""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,shutil,subprocess,sys

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify_geometry(c):
    n=c['n'];side=F(c['receiver_side']);grid=list(map(F,c['R_grid']))
    assert grid[0]==1 and grid[-1]==2 and all(x<y for x,y in zip(grid,grid[1:]))
    assert F(c['a'])==1 and F(c['b'])==2 and F(c['lambda'])==1
    sources=c['sources']; mass=sum((F(p['mass']) for p in sources),F())
    assert mass==F(c['source_mass_exact'])
    count=0;centers=[];E=[]
    for row in c['receiver_records']:
        center=list(map(F,row['center']));centers.append(center);los=[];his=[]
        for radius in grid:
            lo=hi=F()
            for p in sources:
                z=list(map(F,p['center']));d=F(p['side']);density=F(p['density'])
                assert density*d**n==F(p['mass'])
                pl=ph=density
                for j in range(n):
                    def overlap(x):
                        return max(F(),min(z[j]+d/2,x+radius/2)-max(z[j]-d/2,x-radius/2))
                    left,right=center[j]-side/2,center[j]+side/2
                    candidates=[left,right,min(right,max(left,z[j]))]
                    pl*=min(overlap(left),overlap(right))
                    ph*=max(overlap(x) for x in candidates)
                lo+=pl;hi+=ph;count+=1
            los.append(lo);his.append(hi)
        assert los==list(map(F,row['lower_grid_mass_exact']))
        assert his==list(map(F,row['upper_grid_mass_exact']))
        L=max(v/r**n for v,r in zip(los,grid))
        U=max(his[j+1]/grid[j]**n for j in range(len(grid)-1))
        assert L==F(row['octave_response_lower_exact']) and U==F(row['octave_response_upper_exact'])
        assert row['in_E']==(L>=1 and U<=4)
        if row['in_E']:E.append((center,L,U))
    for i,x in enumerate(centers):
        for y in centers[i+1:]:assert any(abs(a-b)>=side for a,b in zip(x,y))
    assert len(E)*side**n==F(c['E_volume_exact']) and len(E)==c['E_cell_count']
    assert sum((L*side**n for _,L,_ in E),F())==F(c['receiver_integral_lower_exact'])
    assert sum((U*side**n for _,_,U in E),F())==F(c['receiver_integral_upper_exact'])
    assert count==c['per_source_R_cell_bound_checks']
    return {'name':c['name'],'exact_checks':count,'receiver_volume':str(len(E)*side**n)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--output-dir',type=Path);args=ap.parse_args()
    root=Path(__file__).resolve().parent;manifest=json.loads((root/'manifest.json').read_text())['sha256']
    for name,digest in manifest.items():assert sha(root/name)==digest,name
    data=json.loads((root/'numeric_checks.json').read_text())
    assert data['source_sha256']==sha(root/'numeric_checks.py') and data['contract_sha256']==sha(root/'task_contract.md')
    assert len(data['cases'])==8
    result={'independent_geometry':[verify_geometry(c) for c in data['cases']],'manifest_files':len(manifest)}
    if not args.verify_only:
        assert args.output_dir is not None
        out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=False)
        for name in ['numeric_checks.py','kernel_checks.py','task_contract.md']:shutil.copy2(root/name,out/name)
        subprocess.run([sys.executable,str(out/'numeric_checks.py')],check=True,capture_output=True)
        subprocess.run([sys.executable,str(out/'kernel_checks.py')],check=True,capture_output=True)
        for name in ['numeric_checks.json','kernel_checks.json']:
            assert (out/name).read_bytes()==(root/name).read_bytes(),name
        result['both_json_byte_identical']=True
        (out/'receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    for name,digest in manifest.items():assert sha(root/name)==digest,name
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
