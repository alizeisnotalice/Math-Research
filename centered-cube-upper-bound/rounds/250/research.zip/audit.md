# R250 独立审核

## 命题先行筛查（未读作者localization/receiver稿）

首次目录仅见receiver_geometry.md，尚无合同/主稿；先依据主代理准确命题独立推导。只写audit.md，不改他人，不Git/PDF/spawn。

### 1. 高度截断的精确弱和

令a_i=c1 m_i、h_i=m_i/a^n，原support交图包含self且覆盖所有同时active对，M_i=Σ邻居m_j。固定u>0及U=u a^n，低阈ℓ_i=u m_i/(2M_i)。旧LG低段仍总≤u/2，不能因m_i≤U就删去该源或其邻居。big并集只可能来自m_i>U，故费用≤c1 Σ_{m_i>U}m_i/u。中段g_i=f_i1_{ℓ_i<f_i≤u}的真实上端b_i=min(u,h_i)；若b_i≤ℓ_i则g_i=0，否则截断layercake给

`∫g_i≤c1 m_i[1+log(b_i/ℓ_i)]`，`b_i/ℓ_i=2M_i/max(m_i,U)`。

因此精确的安全截断价为

`u |{Σf_i>u}| ≤ c1 [Σ_{m_i>U}m_i +2Σ_{2M_i>max(m_i,U)} m_i (1+log(2M_i/max(m_i,U)))]`。

因为M_i≥m_i>0，middle active条件可等价写2M_i>U。若只需较简上界，也可保全体middle的baseline 2Σm_i，并将log改为log_+(2M_i/max(m_i,U))，但不能把baseline也误算为无条件exact中段。U趋0时回到旧3+2log2+2entropy价。等号h_i=ℓ_i时middle严格为空；m_i=U时big严格为空；零质量行先删。

原E上只知M(Σµ_i)≤4λ，不是Σ_i Mµ_i≤4λ。应先用Mµ≤Σf_i取得超level帽，再对actual Mµ用原hardcap作receiver level分割，不能把Σf_i自身截到4λ。

### 2. 任意L1、连续尺度与细分稳定性

单块M_[a,b]µ_i的height≤m_i/a^n对全部连续R≥a成立，弱常数c1由原块support几何给出，不依块内密度。图必须用全部原support邻居，固定于u的source阈值允许，但不能将仅m_i>U者组成graph(u)并漏掉许多小块共同超过低阈的中段。

max(m_i,U)把微小块的log(1/m_i)替成物理mass阈U。固定n进一步细分网格d≤a/n时c1=(1+d/a)^n≤e，M_i始终是物理邻域质量而非邻居数；M_i≤W给Σm_i log_+(2M_i/max(m_i,U))≤W log_+(2W/U)，无额外细分的log块数。没有据此证明dimension-root，因为真实局部crowding/W/(u a^n)仍可能很大。

### 3. 连续mesh-free候选独立筛查

K_ab(z)=sup_{a≤R≤b}h_R(z)，按r=2||z||∞为a^−n（r≤a）、r^−n（a<r≤b）和0。故M_[a,b]µ≤K*µ，通常不是等式：此处已经把shared R放松成逐source的sup。对t>0，径向体积s^n精确给

`∫K1_{K>t} dz = 1_{t<a^-n}[1+min(n log(b/a), log(1/(t a^n)))]`。

t=a^-n处因core为plateau且用严格>，整式为0；t=b^-n的shell边界只有Lebesgue零测，不影响值。a=b也按同式退化为core。

设m_b(y)=µ(Q_{2b}(y))，fullside为2b。有限正Borelµ下m_b>0在µ-a.e.成立（可用countable小盒覆盖证明），其余置零。对fixed x可见源y∈Q_b(x)，整个Q_b(x)⊂Q_{2b}(y)，故m_b(y)≥µ(Q_b(x))。令t_y=u/(2m_b(y))，低kernel部分∫K1_{K≤t_y}dµ≤u/2；高部分Tonelli/Markov得

`u|{Mµ>u}|≤2∫1_{2m_b(y)>u a^n}[1+min(n log(b/a), log(2m_b(y)/(u a^n)))]µ(dy)`。

严格indicator和threshold端点正确。对原有限E与hardcap可再取u=ελ，得εX+(8/ε)乘上述不含2的source积分；若用其他ε分配须同步调整。该式不经mesh limit、支持任意有限正µ（因此涵盖原L1），去掉的是人工细分entropy，而非真实source crowding。其worst≤2(1+nlog(b/a))W，还是线性n；单纯per-source sup的1+nlog旧成本没有被冒称新root。可与已有receiver/source界取min，不无价修改原Π或β/ν。

初筛结论：height-local弱和与mesh-free候选在所列假设下PASS；一般交通/root仍未闭合。等待作者稿后审。

## 作者稿与主稿审核

已完整读取当前task_contract.md、localization.md、receiver_geometry.md及proof.tex.txt；初筛在读取作者推导前落盘。

- **localization HT1–9 PASS。** HT2的连续level支持盒以真实块质量和原密度得出；HT3保完整固定support图，big/middle分割及全部低阈层正确。HT5严格空中层条件、HT6旧价比较、HT7只对真实F=Mµ使用4λ、HT8单cutoff及HT9闭式原函数均正确。HT6在原CB1 residual上替换的是同一误差份额的正估计，不另领误差，也未推广到compact support不存在的soft族。
- **receiver_geometry RG1–4 PASS（辅助范围）。** ai=min(c1mi,4λ|Si|)确为单块弱常数；support-local熵泛函逐坐标非减的证明保留self项，零行只表响应为零而非从原posterior删源。极重块阈值仅条件子支，中间质量区间仍未付。真实incidence源边缘是O(y)µ(dy)，不是µ；O≤1+nlog(b/a)，且subsource没有f的原下hardband。旧熵泛函单调性不自动证明新高度截断泛函的同类单调性；本轮分别取合法价。
- **主proof MK1–3 PASS。** 逐source sup正放松、side2b的local mass、严格plateau端点、低核u/2控制、Markov/Tonelli与实际E上的全level积分逐步成立。一般有限Borel输入可按一致闭盒约定取半径有理逼近，有限质量保证相应最大响应与局部质量可测；原L1边界为dx零测。已明确1+nlog(b/a)是旧满列成本，并未包装为新维数阶。

独立实际执行localization.md内嵌7项mpmath60位原函数检查，输出`PASS 7 4.97841222229e-60`。仅是闭式layercake算术证据，不是FULL或区间证书。

## 数值源码初审（最终版本绑定待定）

numeric_checks.py的receiver是正体积不交盒；单源质量在盒内的上下值由一维overlap端点/峰值的精确Fraction乘积包络。每R网格区间使用`upper_mass(R_hi)/R_lo^n`，质量单调性覆盖全部连续R，未把有限R取样冒充全octave上帽。lower用任一网格响应下界。因此当前认证L>=λ、U<=4λ是明确的硬带工具范围，不等于原2λ<G0出生/原FULL资格。实际support图用原盒交集，细分仅分析表示；m_b经簇内最大距离≤b、簇间最小距离>b验证，没有把点质量代替原有限L1密度。40/70位log费用及高度primitive是普通多精度算术，Fraction几何部分另列。

kernel_checks.py的有限原子low/high阈值检验与50/80位径向积分分别匹配MK2低核步骤与MK1；它们未认证实际L1/FULL实例。最终归档执行归属和文件hash待文件冻结后统一记录。

## 最终整合结论与执行归属

**PASS，可以按所列范围冻结；无未修数学阻断。** 最终主稿的MK1–3与HTA–C忠实整合两条已核正估计；report保留一般根阶、集中soft及原双后验合法回代未闭合。高度截断相对旧局部熵的改进是明确的同源标量费用改进；不把极重门或新局部费用当作一般总账付款。

最终numeric_notes与源码/JSON自绑定一致。正式对象为6真实L1族加2同源细分表示：95候选receiver盒、63整盒E、10233项Fraction单源-R-cell质量包络；40项HT费用、40项mesh费用、80项闭式level积分求值。最后80项不是80个独立求积证书。mp40/70普通log算术的最大scaled差约1.75e-40，非区间。接收认证为λ≤Mµ≤4λ，不能据此宣称原strict birth/FULL实例；有限n2/3不推断一般阶。kernel套件126个原子阈值检查与60个50/80位径向积分，是定义步骤/核积分证据，非FULL。

本独审实际运行：①localization内嵌7项mp60 primitive检查全PASS；②直接调用最终reproduce.py的独立verify_geometry对8模型共10233项Fraction重核全PASS，8个receiver E体积均严格正；③两JSON源码/合同自绑定校验PASS。没有另跑两份完整JSON或冒称作者126+60套件由本审计执行。最终包外双脚本完整重算、字节比较及manifest前后核验由主代理随后执行，其回执另存。

reproduce.py已静审：先验manifest；独立重构每源盒与receiver盒在全部R格点的上下质量，使用mass单调包络覆盖连续区间并核正体积/互斥/积分brackets；完整模式向新外目录复制两脚本及合同，实际执行并比较两完整JSON，最后再验manifest。--verify-only不要求mpmath。代码没有依赖旧工作路径或声称重新求解旧QP。

## 冻结受审版本（SHA256）

不绑定audit自身；以下版本后的数学/数值变更需要重新核对，主代理归档receipt不改变本审计的执行归属。

|文件|SHA256|
|---|---|
|task_contract.md|`82d25952bc2a677065b9225c8de4837de9884e59a8f7d326420c1349c1cc1720`|
|proof.tex.txt|`ea8846885cb4ebe66bf590cd8615eba711c9ab05758500b1382e4852f41c4104`|
|localization.md|`ef5f4ed7184718025f272192c9594a4fe772637ca8d857dfc9175300270fab8b`|
|receiver_geometry.md|`d0d7448333d27ab84737bb9351997bce83103ae0627f614ad9c2c27eb7197852`|
|report.md|`37aaef11a967a70211071038389b827d4a04e4683f2154511c003e5a51621b7c`|
|reproduce.py|`9f286f9a82fb7a61ac6e681c2c0b956332c3ce84a1bb0870a0da0cd3f503a684`|
|numeric_checks.py|`3d85da37e9ad32e41be56a04b9ec3f3ce73fdb9c7c50c5f2aa05cad761ec789a`|
|numeric_checks.json|`3791d8be23d6126fce1c4b0de6cffec91f97f678db6095b6a8dd2d84c9699f28`|
|numeric_notes.md|`b3a9271a566808a5e35d88cb27a42f369f8a5504a8214f3a8e3fd21ef0566dd0`|
|kernel_checks.py|`c6bbabcfe9e33db3c86a070d9e5fd1082642199a93e6fdbaa762ca92ba5efbe1`|
|kernel_checks.json|`a893cdf78dd92113dc841f4da1eec67d95c42ea4bf83b7465dac27727a9b96c3`|

本轮审核已完成，audit.md至此停止写入。
