# R250：真实Lebesgue hardband、height费用和物理source-local费用

实际完成基础6族（初探2、压力2、扩大2）与同一来源的2个表示细分附加，共8 records。121个source pieces、95个receiver候选小cube、63个整cube被核入E，10233项逐source/R/receiver的Fraction overlap检查；40项HT阈值费用、40项mesh-free费用、80项全level闭式积分求值。最后这些是已证明公式的数值求值，不是80项独立求积恒等证书。本轮按父更新没有新QP/MATLAB计算，也未重跑R249 flow套件。

## 输入和先定方案

所有基础族均a=1,b=2,lambda=1，source是真实正Lebesgue分段常密度盒，f=mu。source cells原边长d0=1/n。receiver小cube边长1/(16n)，中心取表列anchor及少量轴向1/4偏移；n2另有1/2偏移压力。候选receiver cubes内部互不相交。所有source center、边长、mass、density和receiver center均逐项在JSON，无点源或点计数接收替代。

|阶段/族|n|source pieces与质量|实际E cube数|E真实Lebesgue测度|
|---|---:|---|---:|---:|
|初探spread_unitcube_n2|2|unitcube density2，4 pieces，总mass2|5|5/1024|
|初探single_concentrated_n2|2|边1/2单cell，mass2、density8|5|5/1024|
|压力adjacent_pair_n2|2|中心(0,0)、(1/2,0)，mass2各|9|9/1024|
|压力sparse_periodic_n2|2|中心(0,0),(4,0),(0,4),(4,4)，mass2各|20|5/256|
|扩大spread_unitcube_n3|3|unitcube density2，27 pieces，总mass2|7|7/110592|
|扩大anisotropic_cluster_n3|3|中心(0,0,0),(1/3,0,0),(2/3,0,0)，mass1各|7|7/110592|

spread指空间分布较铺开，不代表CG低块组：在本轮n2/3，density2仍大于原sigma=lambda sqrt(n)，脚本以density²>n精确分类，上表所有来源在该阈值下均属集中组。不能借名字假定diffuse付款。计数跨不同模型累加，不能把不同维数的E体积或重复表示的mass当一个全局输入相加。

先实际跑基础几何；compare localization.md HT5/HT9与主稿MK2/MK3经独审冻结后，才实际执行全部费用。没有自行猜截断常数。最终只在原6族上加两种analysis表示，未做大网格、优化搜索或新网络。

## 整receivercell及整个octave的精确核验

对source box每坐标，Q_R(x)与source interval的交长是正part的梯形函数。在receiver坐标interval上，最小交长取两个端点的最小值；最大交长取两个端点及投影source中心处的最大值。多坐标交体积为交长乘积，乘source density即得该piece在整个receiver小cube上的Fraction下/上界。对所有pieces正求和，保同一receiver x；不将来源响应当独立随机变量，也不声称各piece极值在同一x同时达到。

R网格是{1+j/8:j=0,...,8}。每receiver的lower为max_j lower_mass(R_j)/R_j^n。整个R in [R_j,R_{j+1}]，由质量随R单调有

response_R(x)<=upper_mass(R_{j+1})/R_j^n。

取各段最大值为整个[1,2]的upper，包含两端。只有lower>=1且upper<=4的整receivercube进入E，故该E上真实sup_{1<=R<=2} h_R*f在[lambda,4lambda]。这不是只验证9个尺度，也不声称所选E穷尽完整hardband。邻接pair族upper可等于4，非strict条件仍合法。

真实receiver积分也保exact bracket。例如二维unitcube：

3875/524288 <= integral_E M mu <= 69/8192。

单集中cell：39/4096 <= integral_E M mu <= 5/512；near pair：258017/10616832 <= integral_E M mu <= 57/2048。其余全部JSON保Fraction端点。E很小，这些例子不能说明一般接收费用紧致。

## 固定支持邻接、HT5/HT9与mesh-free式

旧support-local邻接使用E内两实际支持的共同正Lebesgue交，支持为E交Q_{b+d_i}(z_i)；通过三盒交体积精确核邻接。另保coarse center距离<=b+d0的图，逐项核actual图是其子图。图不随u切换，不能用更小graph(u)免费替换middle层，也没修改原transport允许边。

输出旧B_loc=(3+2log2)W+2sum m_i log(M_i/m_i)，以及u in {1/4,1/2,1,2,3}的HT5：

B_ht(u)=sum_{m_i>u}m_i+2sum_{2M_i>u}m_i[1+log(2M_i/max(m_i,u))]。

阈值比较是Fraction，保strict端点；日志用mp40/70。核所有40项0<=B_ht<=B_loc。单切支付和HT9的全部level闭式积分都输出。HT9用Phi_c(x)=x+x²/2-(x-c)_+²/2，未丢低阈值interval。只用真实M(sum mu_i)<=4lambda，绝不以此声称sum M(mu_i)<=4lambda。

对主稿mesh-free式，以精确box端点验证每个物理cluster内部最大Linfinity点距<=b、不同clusters最小点距>b。因此m_b(y)=mu(Q_side2b(y))确为其cluster总mass，在source piece上常数，而非用块中心采样替代。输出

Phi_mu(u)=2sum_i m_i 1_{2m_b>u}[1+min(n log2,log(2m_b/u))]，

以及其MK3全level积分。后者亦用上述primitive，只是c=n log2，乘2m_i。这个物理量对同一来源的分片完全不变。它是按已审主命题计算的费用，不是新的solver目标；n2/3不能据此推断一般root阶。

四个远隔单cell的support-local熵为0，global熵为8log4≈11.09035；其mesh-free价和真实receiver积分都是单cell例的4倍。这只是说明分离replicas在这里真正按来源可加，不证明任意局部团簇都有小价。

## 同一个物理unitcube的细分稳定性

二维unitcube density2，以analysis piece side1/(kn)、k=1,2,4表示。pieces数N=4,16,64，W始终2；三个模型的E、真实积分Fraction brackets完全相同。原transport d0=1/2没有改变，也没定义新可行流。

小piece的自然弱常数c1(k)=(1+d_piece)^2可用，同时JSON保原grid c1=9/4的保守费用。自然c1降低只是analysis常数变化，不是transport资格变化。为防raw值误导，另外输出除c1W后的规范化费用；在u=1/2：

|k|N|自然c1|旧规范化B_loc/W|HT规范化B_ht/W|物理mesh-free fee/W|
|---|---:|---:|---:|---:|---:|
|1|4|9/4|7.15888308336|6.15888308336|4.77258872224|
|2|16|25/16|9.93147180560|6.15888308336|4.77258872224|
|4|64|81/64|12.70406052784|6.15888308336|4.77258872224|

这里旧规范化价恰为C+2log N（C=3+2log2）；当所有m_i<=u时，新规范化HT价恰为2[1+log(2W/u)]，不再有log N。mesh-free还截于n log2。代码核u>=1/2的四个菜单HT价表示不变，全部五个u的mesh-free价表示不变。u=1/4时粗piece的mass尚大于u，HT有真实阈值过渡，未断言所有u都精确相同。

自然c1乘回后旧raw价依次32.2149738751、31.0358493925、32.1571532111，先降后升；不能把这一短菜单的raw非单调写成旧费用已不依网格。HT自然raw价为27.7149738751、19.2465096355、15.5896728048。人工细网格熵在固定正阈值下的去除是本轮的具体数值决策证据；有限三次细分不是渐近拟合或一般全源预算。

## 精度、范围与复现

几何及阈值判断用Python Fraction；这是有限有理盒算术，不称通用outward interval库证书。所有log和闭式费用以mp40/70独立计算，enc50保工作精度差。最大字段差/max(1,abs(high))=1.7518777744197576e-40；只是普通多精度一致性，不是严格log误差包围或80项独立quadrature校验。基础几何、完整公式版及最后状态标签版都已本机实际运行，未作额外timing replay。

无需MATLAB/numpy/scipy；本轮MATLAB会话未调用。依赖bundled Python3.12.14和vendor mpmath1.3.0。解压后在含脚本/合同的同目录完整复现：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 numeric_checks.py --contract task_contract.md --output replay.json
cmp numeric_checks.json replay.json
```

默认--output为相邻numeric_checks.json，--contract为相邻task_contract.md；可迁移两路径。--basic-only只执行几何，不是最终归档运行模式。JSON无runtime、时间戳和绝对路径；最终绑定Python/冻结合同SHA。counts基本字段：basic_families6、representation_additions2、model_records8、certified_E_cells63、per_source_R_cell_bound_checks10233、height_fee_checks40、mesh_free_fee_checks40、closed_all_level_integrals80。

冻结source SHA256：3d85da37e9ad32e41be56a04b9ec3f3ce73fdb9c7c50c5f2aa05cad761ec789a；JSON393686字节、SHA256：3791d8be23d6126fce1c4b0de6cffec91f97f678db6095b6a8dd2d84c9699f28；合同SHA256：82d25952bc2a677065b9225c8de4837de9884e59a8f7d326420c1349c1cc1720。
