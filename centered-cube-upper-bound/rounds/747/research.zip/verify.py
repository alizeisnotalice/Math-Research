from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
from math import isqrt, prod
from pathlib import Path

import flint
from flint import arb, ctx, fmpq


PRECISION = 256
Point = tuple[F, ...]


def exact(value):
    return str(value)


def point(*coordinates):
    return tuple(F(value) for value in coordinates)


def ball(value):
    value = F(value)
    return arb(fmpq(value.numerator, value.denominator))


def interval(value):
    return value.str(24)


@dataclass(frozen=True)
class Box:
    center: Point
    half: Point

    def contains(self, z):
        return all(abs(x - y) <= r for x, y, r in zip(z, self.center, self.half))

    def meets(self, other):
        return all(
            abs(x - y) <= r + s
            for x, y, r, s in zip(self.center, other.center, self.half, other.half)
        )

    def scaled(self, factor):
        return Box(self.center, tuple(factor * r for r in self.half))

    @property
    def lower(self):
        return tuple(x - r for x, r in zip(self.center, self.half))

    @property
    def upper(self):
        return tuple(x + r for x, r in zip(self.center, self.half))

    @property
    def volume(self):
        return prod(2 * r for r in self.half)


@dataclass(frozen=True)
class Row:
    center: Point
    radius: F

    @property
    def parent(self):
        return Box(self.center, (self.radius,) * len(self.center))

    @property
    def owner(self):
        return self.parent.scaled(F(1, 32 * len(self.center)))


@dataclass(frozen=True)
class Selected:
    row_id: int
    radius: F
    probe: Box


@dataclass(frozen=True)
class Fixture:
    name: str
    omega: Point
    gamma: F
    rows: tuple[Row, ...]
    atoms: tuple[tuple[Point, F], ...]
    primal: tuple[F, ...]
    priority: tuple[Point, ...] = ()


def box_contains_by_endpoints(box, z, strict=False):
    if strict:
        return all(lo < x < hi for lo, x, hi in zip(box.lower, z, box.upper))
    return all(lo <= x <= hi for lo, x, hi in zip(box.lower, z, box.upper))


def price(box, atoms):
    return sum((mass for z, mass in atoms if box.contains(z)), F(0))


def probe_for(fixture, row, z):
    return Box(z, tuple(row.radius * width for width in fixture.omega))


def eligible(fixture, row, z, probe):
    return row.parent.contains(z) and price(probe, fixture.atoms) >= (
        fixture.gamma * row.parent.volume
    )


def cell_representatives(lo, hi, breaks):
    endpoints = sorted({lo, hi, *(x for x in breaks if lo <= x <= hi)})
    return sorted(endpoints + [(x + y) / 2 for x, y in zip(endpoints, endpoints[1:])])


def continuous_candidates(fixture, row, selected):
    half = probe_for(fixture, row, row.center).half
    axes = []
    for axis, (lo, hi) in enumerate(zip(row.parent.lower, row.parent.upper)):
        atom_breaks = [
            z[axis] + sign * half[axis] for z, _ in fixture.atoms for sign in (-1, 1)
        ]
        blocker_breaks = [
            choice.probe.center[axis] + sign * (half[axis] + choice.probe.half[axis])
            for choice in selected
            for sign in (-1, 1)
        ]
        axes.append(cell_representatives(lo, hi, atom_breaks + blocker_breaks))
    return product(*axes)


def next_choice(fixture, row_ids, selected):
    first_centers = tuple(dict.fromkeys(fixture.priority + tuple(z for z, _ in fixture.atoms)))
    for prefer_atoms in (True, False):
        for row_id in row_ids:
            row = fixture.rows[row_id]
            centers = first_centers if prefer_atoms else continuous_candidates(fixture, row, selected)
            for z in centers:
                probe = probe_for(fixture, row, z)
                if eligible(fixture, row, z, probe) and not any(
                    probe.meets(old.probe) for old in selected
                ):
                    return Selected(row_id, row.radius, probe)
    return None


def select_probes(fixture):
    selected = []
    min_price = fixture.gamma * min(row.parent.volume for row in fixture.rows)
    total_price = sum(weight for _, weight in fixture.atoms)
    for radius in sorted({row.radius for row in fixture.rows}, reverse=True):
        row_ids = [i for i, row in enumerate(fixture.rows) if row.radius == radius]
        while True:
            new = next_choice(fixture, row_ids, selected)
            if new is None:
                break
            selected.append(new)
            assert len(selected) <= total_price // min_price
        # The breakpoints include both equality faces and interiors of complementary cells.
        for row_id in row_ids:
            row = fixture.rows[row_id]
            for z in continuous_candidates(fixture, row, selected):
                probe = probe_for(fixture, row, z)
                local_price = sum(
                    mass for w, mass in fixture.atoms if box_contains_by_endpoints(probe, w)
                )
                if local_price >= fixture.gamma * row.parent.volume:
                    assert any(
                        all(
                            max(lo, old_lo) <= min(hi, old_hi)
                            for lo, hi, old_lo, old_hi in zip(
                                probe.lower, probe.upper, old.probe.lower, old.probe.upper
                            )
                        )
                        for old in selected
                    )
    assert all(not left.probe.meets(right.probe) for left, right in combinations(selected, 2))
    return selected


def packing_certificate(fixture):
    parents = [row.parent for row in fixture.rows]
    axes = []
    for axis in range(len(fixture.omega)):
        bounds = sorted({v for box in parents for v in (box.lower[axis], box.upper[axis])})
        axes.append([(x + y) / 2 for x, y in zip(bounds, bounds[1:])])
    arrangements = {
        tuple(box_contains_by_endpoints(box, z, strict=True) for box in parents)
        for z in product(*axes)
    }
    maximum = max(
        sum(weight for weight, on in zip(fixture.primal, signature) if on)
        for signature in arrangements
    )
    assert maximum <= 1 and all(weight >= 0 for weight in fixture.primal)
    total_dual = sum(weight for _, weight in fixture.atoms)
    for z, _ in fixture.atoms:
        signature = tuple(box_contains_by_endpoints(box, z, strict=True) for box in parents)
        assert signature == tuple(box.contains(z) for box in parents)
        assert signature in arrangements
    for box in parents:
        assert price(box, fixture.atoms) >= box.volume
    objective = sum(weight * box.volume for weight, box in zip(fixture.primal, parents))
    assert objective == total_dual
    return {
        "primal_weights": list(map(exact, fixture.primal)),
        "maximum_primal_cell_load": exact(maximum),
        "dual_atoms": len(fixture.atoms),
        "matching_optimum": exact(objective),
        "positive_volume_signatures_checked": len(arrangements),
    }


def bin_tag(volume, base):
    if volume <= base:
        return 0
    tag = 1
    while volume > base * 2**tag:
        tag += 1
    return tag


def audit_fixture(fixture):
    n = len(fixture.omega)
    h = F(1) + F(1, 32 * n)
    assert all(width >= 0 for width in fixture.omega)
    assert sum(fixture.omega) <= 1
    assert all(not a.owner.meets(b.owner) for a, b in combinations(fixture.rows, 2))
    optimum = packing_certificate(fixture)

    selected = select_probes(fixture)
    expanded = [item.probe.scaled(2) for item in selected]
    owners = [
        next((k for k, box in enumerate(expanded) if box.contains(z)), None)
        for z, _ in fixture.atoms
    ]
    by_cluster = [
        {atom_id for atom_id, assigned in enumerate(owners) if assigned == k}
        for k in range(len(selected))
    ]
    # An independent set-difference construction of the same global partition.
    seen = set()
    for k, box in enumerate(expanded):
        cover = {
            atom_id
            for atom_id, (z, _) in enumerate(fixture.atoms)
            if box_contains_by_endpoints(box, z)
        }
        assert cover - seen == by_cluster[k]
        seen |= cover

    layer_count = bin_tag(F(1), fixture.gamma)
    level = -ball(fixture.gamma).log()
    constant = (
        ball(F(1, 32)) + 2 * (level / n).exp() * ball(sum(fixture.omega))
    ).exp()
    price_c = [price(choice.probe, fixture.atoms) for choice in selected]
    price_g = [
        sum((fixture.atoms[j][1] for j in atom_ids), F(0)) for atom_ids in by_cluster
    ]
    total_fee = F(0)
    all_qualified = set()
    row_reports = []
    groups = {}
    qualifying_contact = []
    doubled_boundary = []
    for atom_id, assigned in enumerate(owners):
        if assigned is not None:
            z, _ = fixture.atoms[atom_id]
            box = expanded[assigned]
            if any(
                r > 0 and abs(x - y) == r for x, y, r in zip(z, box.center, box.half)
            ):
                doubled_boundary.append([atom_id, assigned])

    for row_id, row in enumerate(fixture.rows):
        parent_price = price(row.parent, fixture.atoms)
        qualifying = set()
        share = [F(0)] * len(selected)
        equalities = []
        for atom_id, (z, value) in enumerate(fixture.atoms):
            probe = probe_for(fixture, row, z)
            local = price(probe, fixture.atoms)
            if not row.parent.contains(z) or local < fixture.gamma * row.parent.volume:
                continue
            qualifying.add(atom_id)
            if local == fixture.gamma * row.parent.volume:
                equalities.append(atom_id)
            cluster = owners[atom_id]
            assert cluster is not None and selected[cluster].radius >= row.radius
            share[cluster] += value
            for choice_id, other in enumerate(selected):
                if other.radius < row.radius or not probe.meets(other.probe):
                    continue
                if any(
                    r + s > 0 and abs(x - y) == r + s
                    for x, y, r, s in zip(
                        probe.center, other.probe.center, probe.half, other.probe.half
                    )
                ):
                    qualifying_contact.append([row_id, atom_id, choice_id])
        # Recompute all eligibility weights with an independent endpoint/mask formula.
        eligible_by_ranges = set()
        for atom_id, (z, _) in enumerate(fixture.atoms):
            if not box_contains_by_endpoints(row.parent, z):
                continue
            probe = probe_for(fixture, row, z)
            coordinate_masks = [
                {
                    ix for ix, (w, _) in enumerate(fixture.atoms) if lo <= w[axis] <= hi
                }
                for axis, (lo, hi) in enumerate(zip(probe.lower, probe.upper))
            ]
            admissible_ids = set.intersection(*coordinate_masks)
            local = sum(fixture.atoms[ix][1] for ix in admissible_ids)
            if local >= fixture.gamma * row.parent.volume:
                eligible_by_ranges.add(atom_id)
        assert qualifying == eligible_by_ranges
        expected = [
            sum((fixture.atoms[j][1] for j in qualifying & ids), F(0)) for ids in by_cluster
        ]
        assert share == expected
        qualified_price = sum((fixture.atoms[j][1] for j in qualifying), F(0))
        assert sum(share) == qualified_price
        all_qualified |= qualifying
        fees = [row.owner.volume * p / parent_price for p in share]
        total_fee += sum(fees)
        for k, fee in enumerate(fees):
            if fee:
                source_volume = (2 * selected[k].radius)**n
                tag = bin_tag(row.parent.volume, fixture.gamma * source_volume)
                assert 0 <= tag <= layer_count
                groups.setdefault((k, tag), []).append((row_id, fee))
        row_reports.append({
            "row": row_id,
            "volume": exact(row.parent.volume),
            "owner_volume": exact(row.owner.volume),
            "parent_price": exact(parent_price),
            "qualified_price": exact(qualified_price),
            "threshold_equalities": equalities,
            "allocations": [
                {"cluster": k, "fraction": exact(p / parent_price), "fee": exact(fees[k])}
                for k, p in enumerate(share) if p
            ],
        })

    bin_reports = []
    for (k, tag), entries in sorted(groups.items()):
        choice = selected[k]
        supporting_rows = [fixture.rows[row_id] for row_id, _ in entries]
        interval_parent = Box(
            choice.probe.center,
            tuple(
                h * max(row.radius for row in supporting_rows) + 2 * r
                for r in choice.probe.half
            ),
        )
        for row in supporting_rows:
            assert all(
                lo <= own_lo < own_hi <= hi for lo, own_lo, own_hi, hi in zip(
                    interval_parent.lower, row.owner.lower, row.owner.upper, interval_parent.upper
                )
            )
        actual_volume = sum(row.owner.volume for row in supporting_rows)
        fee = sum(value for _, value in entries)
        assert actual_volume <= interval_parent.volume
        if tag == 0:
            denominator = price_c[k]
            exact_bound = interval_parent.volume
            factor = interval_parent.volume / denominator
            assert fee <= exact_bound and ball(factor) < constant
        else:
            denominator = min(row.parent.volume for row in supporting_rows)
            factor = interval_parent.volume / denominator
            exact_bound = factor * price_g[k]
            assert fee <= exact_bound and ball(factor) < 2 * constant
        bin_reports.append({
            "cluster": k,
            "band": "low" if tag == 0 else tag,
            "rows": [row_id for row_id, _ in entries],
            "actual_owner_volume": exact(actual_volume),
            "actual_fee": exact(fee),
            "enclosure_volume": exact(interval_parent.volume),
            "enclosure_to_price_or_volume_ratio": exact(factor),
            "exact_enclosure_fee_upper": exact(exact_bound),
        })

    total_price = sum(weight for _, weight in fixture.atoms)
    assigned_price = sum(price_g)
    budget = sum(price_c) + assigned_price
    assert sum(price_c) <= total_price and assigned_price <= total_price and budget <= 2 * total_price
    assert total_fee == sum(F(entry["actual_fee"]) for entry in bin_reports)
    continuous_layers = []
    for k, choice in enumerate(selected):
        local = [record for record in bin_reports if record["cluster"] == k]
        fee = sum((F(record["actual_fee"]) for record in local), F(0))
        assert ball(fee) < constant * ball(price_c[k] + 2 * layer_count * price_g[k])

        high_ids = {row_id for record in local if record["band"] != "low" for row_id in record["rows"]}
        weighted_owners = [
            (fixture.rows[row_id].parent.volume, fixture.rows[row_id].owner.volume)
            for row_id in high_ids
        ]
        ceiling = (2 * choice.radius)**n
        floor = fixture.gamma * ceiling
        cuts = sorted({floor, ceiling, *(volume for volume, _ in weighted_owners)})
        endpoint_charge = sum(weight for _, weight in weighted_owners) / ceiling
        integral_charge = sum(
            (1 / left - 1 / right) * sum(weight for volume, weight in weighted_owners if volume <= left)
            for left, right in zip(cuts, cuts[1:])
        )
        high_ratio = sum(weight / volume for volume, weight in weighted_owners)
        high_fee = sum(F(record["actual_fee"]) for record in local if record["band"] != "low")
        assert endpoint_charge + integral_charge == high_ratio
        assert high_fee <= price_g[k] * high_ratio
        assert ball(high_ratio) < constant * (1 + level)
        assert ball(fee) < constant * (ball(price_c[k]) + (1 + level) * ball(price_g[k]))
        continuous_layers.append({
            "cluster": k,
            "high_owner_ratio": exact(high_ratio),
            "layer_endpoint": exact(endpoint_charge),
            "layer_integral": exact(integral_charge),
        })
    return {
        "name": fixture.name,
        "dimension": n,
        "gamma": exact(fixture.gamma),
        "omega": list(map(exact, fixture.omega)),
        "packing_certificate": optimum,
        "non_atom_selected_count": sum(
            choice.probe.center not in {z for z, _ in fixture.atoms} for choice in selected
        ),
        "selected": [
            {
                "cluster": k,
                "source_row": choice.row_id,
                "site": list(map(exact, choice.probe.center)),
                "radius": exact(choice.radius),
                "price_C": exact(price_c[k]),
                "price_G_C": exact(price_g[k]),
                "budget": exact(price_c[k] + price_g[k]),
            }
            for k, choice in enumerate(selected)
        ],
        "atom_assignments": owners,
        "closed_boundary_assignments": doubled_boundary,
        "closed_contacts_for_qualified_atoms": qualifying_contact,
        "rows": row_reports,
        "bands": bin_reports,
        "continuous_layer_identity": continuous_layers,
        "continuous_coefficient_per_b_C_arb": interval(constant * (1 + level)),
        "dyadic_coefficient_per_b_C_arb": interval(constant * (1 + 2 * layer_count)),
        "total_fee": exact(total_fee),
        "total_budget": exact(budget),
        "total_price": exact(total_price),
        "global_partitioned_price": exact(assigned_price),
        "unique_qualified_price": exact(sum(fixture.atoms[j][1] for j in all_qualified)),
        "sum_of_repeated_row_prices": exact(sum(F(row["qualified_price"]) for row in row_reports)),
        "sum_of_expanded_box_prices": exact(sum(price(box, fixture.atoms) for box in expanded)),
        "positive_bands_per_cluster_available": layer_count,
        "K_n_arb": interval(constant),
    }


def main_fixtures():
    return (
        Fixture(
            "two_axes_partial_with_closed_contact", point("1/2", "1/2"), F(1, 2),
            (
                Row(point(0, 0), F(2)),
                Row(point("3/4", "1/8"), F(1)),
                Row(point("-1/2", "3/8"), F(3, 2)),
            ),
            (
                (point(0, 0), F(6)), (point("1/2", 0), F(3)), (point("3/2", 0), F(2)),
                (point("-3/2", -1), F(1)), (point("-1/2", "3/2"), F(4)),
            ),
            (F(1), F(0), F(0)),
        ),
        Fixture(
            "one_fractional_row_across_three_sites", point("1/4"), F(1, 4),
            (
                Row(point(0), F(2)), Row(point("-5/8"), F(1)),
                Row(point("5/8"), F(5, 4)), Row(point("1/4"), F(1, 2)),
            ),
            (
                (point("-3/2"), F(5, 4)), (point("3/2"), F(5, 4)),
                (point(0), F(1, 2)), (point("-1/2"), F(1, 2)), (point("1/2"), F(1, 2)),
            ),
            (F(1), F(0), F(0), F(0)),
        ),
        Fixture(
            "degenerate_probe_one_zero_axis", point(0, "1/2"), F(1, 2),
            (Row(point(0, 0), F(1)), Row(point("3/8", "1/8"), F(1, 2))),
            ((point(0, 0), F(2)), (point(0, "3/4"), F(1)), (point("1/2", 0), F(1))),
            (F(1), F(0)),
        ),
        Fixture(
            "a_qualified_center_off_the_price_support", point("1/2"), F(1),
            (Row(point(0), F(1)),),
            ((point("-3/8"), F(1)), (point("3/8"), F(1))),
            (F(1),),
        ),
    )


def pressure_fixture(depth):
    radii = [F(6**b) for b in range(depth)]
    satellites = tuple((point(F(3, 2) * r), r) for r in radii)
    apex_price = 2 * radii[-1] - sum(radii)
    assert apex_price > 0
    return Fixture(
        f"contained_price_repeated_{depth}_times", point(1), F(1, 2),
        tuple(Row(point(F(3, 4) * r), r) for r in radii),
        ((point(0), apex_price),) + satellites,
        (F(0),) * (depth - 1) + (F(1),),
        tuple(z for z, _ in reversed(satellites)),
    )


def pressure_report(depth):
    fixture = pressure_fixture(depth)
    audited = audit_fixture(fixture)
    assigned = F(audited["global_partitioned_price"])
    duplicates = F(audited["sum_of_expanded_box_prices"])
    repeated_rows = F(audited["sum_of_repeated_row_prices"])
    budget = F(audited["total_budget"])
    assert len(audited["selected"]) == depth and all(
        abs(F(choice["site"][0])) <= 2 * F(choice["radius"]) for choice in audited["selected"]
    )
    assert all(a == 0 for a in audited["atom_assignments"])
    assert assigned == F(audited["total_price"])
    assert duplicates == repeated_rows
    assert F(depth, 4) < duplicates / budget
    return {
        "depth": depth,
        "shared_apex_price": exact(fixture.atoms[0][1]),
        "expanded_boxes_covering_the_apex": depth,
        "optimum": audited["packing_certificate"]["matching_optimum"],
        "actual_fee": audited["total_fee"],
        "global_partitioned_price": exact(assigned),
        "total_budget_including_disjoint_probes": exact(budget),
        "naive_expanded_or_per_row_price": exact(duplicates),
        "naive_to_global_partition_ratio": exact(duplicates / assigned),
        "naive_to_budget_ratio": exact(duplicates / budget),
        "naive_to_budget_ratio_decimal": round(float(duplicates / budget), 8),
    }


def fragmented_geometry(n):
    k = isqrt(n)
    m = 2**k
    epsilon = F(1, 16 * n)
    width = F(1, n)
    # Coordinates beyond the k varying signs are all exactly zero.
    indices = {
        sum((bit == 1) << axis for axis, bit in enumerate(code))
        for code in product((-1, 1), repeat=k)
    }
    assert len(indices) == m and min(indices) == 0 and max(indices) == m - 1
    assert F(1, 2) + epsilon < 1
    assert 2 * epsilon <= width and 1 - 2 * epsilon > 2 * width
    share = F(1, m)
    assert n * share**2 < 1
    assert ball(share) > (-arb(n).sqrt()).exp()
    # Unit primal weight and the normalized price have the same objective.
    parent_volume = 2**n
    assert m * (F(parent_volume) * share) == parent_volume
    return {
        "dimension": n,
        "sign_coordinates": k,
        "support_cubes": m,
        "explicit_centers_enumerated": len(indices),
        "support_half_width": exact(epsilon),
        "probe_half_width_each_axis": exact(width),
        "minimum_gap_in_some_coordinate": exact(1 - 2 * epsilon),
        "price_fraction_per_fragment": exact(share),
        "normalized_price_at_exponential_threshold": "1",
        "normalized_price_at_inverse_root_threshold": "0",
        "matching_optimum": str(parent_volume),
    }


def arb_scale(n):
    dimension = arb(n)
    length = dimension.sqrt()
    log2 = arb(2).log()
    exact_layer = (length / log2).ceil().unique_fmpz()
    assert exact_layer is not None
    layers = int(exact_layer)
    assert arb(layers - 1) < length / log2 < arb(layers)
    constant = (ball(F(1, 32)) + 2 * (length / dimension).exp()).exp()
    dyadic = constant * (1 + 2 * layers)
    continuous = constant * (1 + length)
    limit_continuous = (ball(F(1, 32)) + 2).exp()
    limit_dyadic = 2 * limit_continuous / log2
    uniform_dyadic = (ball(F(1, 32)) + 2 * ball(F(1, 4)).exp()).exp() * (2 / log2 + ball(F(3, 4)))
    assert limit_dyadic < dyadic / length < uniform_dyadic < 50
    assert limit_continuous < continuous / length < dyadic / length
    k = isqrt(n)
    negative_log_share = k * log2
    assert dimension.log() / 2 < negative_log_share < length
    return {
        "dimension": n,
        "L": interval(length),
        "dyadic_layers": layers,
        "K_n": interval(constant),
        "dyadic_coefficient_per_b_C": interval(dyadic),
        "continuous_coefficient_per_b_C": interval(continuous),
        "dyadic_coefficient_per_b_C_divided_by_sqrt_n": interval(dyadic / length),
        "continuous_coefficient_per_b_C_divided_by_sqrt_n": interval(continuous / length),
        "uniform_dyadic_coefficient_per_b_C_divided_by_sqrt_n_upper_for_n_ge_16": interval(uniform_dyadic),
        "limiting_dyadic_coefficient_per_b_C_divided_by_sqrt_n": interval(limit_dyadic),
        "limiting_continuous_coefficient_per_b_C_divided_by_sqrt_n": interval(limit_continuous),
        "fragment_count_log2_scalar_only": k,
    }


def audit():
    ctx.prec = PRECISION
    src = Path(__file__)
    output_name = "verify.json"
    fixtures = [audit_fixture(fixture) for fixture in main_fixtures()]
    assert fixtures[0]["closed_contacts_for_qualified_atoms"]
    assert fixtures[1]["closed_boundary_assignments"]
    rows = [row for fixture in fixtures for row in fixture["rows"]]
    assert any(len(row["allocations"]) > 1 for row in rows)
    assert any(0 < F(row["qualified_price"]) < F(row["parent_price"]) for row in rows)
    assert fixtures[-1]["non_atom_selected_count"] == 1
    return {
        "schema": "r747-cluster-charge-verification-v1",
        "runtime": {
            "python": platform.python_version(),
            "python_executable": sys.executable,
            "python_flint": flint.__version__,
            "arb_precision_bits": PRECISION,
            "script_sha256": hashlib.sha256(src.read_bytes()).hexdigest(),
            "working_directory_for_commands": "directory containing verify.py and verify.json",
            "write_command": [sys.executable, "-B", src.name, "--out", output_name],
            "rerun_command": [sys.executable, "-B", src.name, "--check", output_name],
        },
        "exact_small_fixtures": fixtures,
        "repeated_price_pressure": [pressure_report(depth) for depth in (4, 12, 32)],
        "fragmented_optimal_price_explicit": [fragmented_geometry(n) for n in (16, 64, 256)],
        "arb_scalar_only_L_sqrt_n": [arb_scale(n) for n in (16, 64, 256, 1024, 2**20, 2**40, 2**60)],
        "scope": [
            "Small fixtures use exact atom masses, rational coordinates, and full axis-aligned continuum greedy selection by endpoint/interval cells.",
            "Primal feasibility is checked on all positive-volume arrangement signatures. Dual representatives lie in parent interiors whenever covered.",
            "Split-price examples explicitly enumerate sign centers only. The support gap and single-fragment probe bounds are rational inequalities.",
            "High-dimensional Arb entries evaluate scalar constants and dyadic counts only.",
            "The coefficients are per cluster budget b_C. The family sum of the b_C is at most twice the total dual price, hence at most 2 P0 when the dual pricing is optimal.",
            "A byte-identical check uses the same recorded interpreter path, versions, and source code. Changing these fields requires checking mathematical payloads separately.",
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    paths = parser.add_mutually_exclusive_group(required=True)
    paths.add_argument("--out", type=Path)
    paths.add_argument("--check", type=Path)
    args = parser.parse_args()
    raw = json.dumps(audit(), ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if args.out:
        args.out.write_text(raw, encoding="utf-8")
        print(f"wrote {args.out} ({len(raw)} bytes)")
    else:
        expected = args.check.read_text(encoding="utf-8")
        if raw != expected:
            raise SystemExit("rerun differs from the saved JSON")
        print(f"identical rerun of {args.check} ({len(raw)} bytes)")


if __name__ == "__main__":
    main()
