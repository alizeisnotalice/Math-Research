# R236 two-slot posterior identity and actual-soft capacity

Only this file is owned by this auxiliary task. The authoritative input is
R235 `proof.tex.txt` in
`/Users/zhengzhihao/Desktop/T/output/centered_cube_round235_20261017_final_checkpoint/`,
especially (1)–(2), (4), (8), (12), and (15). The original finite truncation,
outer block, source histories, actual receiver set, and all gates remain fixed.
The global arbitrary-positive-L1 weak estimate is not asserted here.

## TS1. Scope and original capacities

Fix one original outer block V and one physical node. Write its finite source
measures as beta and nu, with nu <= beta <= f. Let q>0, 0<a<=b<=2a,
C0=16/3, and fix theta in (0,1/2] **before** x,y,v,j,M,t. All kernels below
are actual Lebesgue densities. With h=1[-1/2,1/2],
phi=h*integral_0^1 exp(-|.|/r)dr, and f_s=(1-s)h+s phi, put

    P_{s,L}(u)=L^{-n} product_i f_s(u_i/L).

At x in the original measurable receiver set Omega use its actual s=s(x),
and legal fixed physical node scales L*,A* in [a,b]. Set

    P_x(y)=P_{s(x),L*}(x-y),
    Q_x(v)=P_{s(x),A*}(x-v),

or Q_x(v)=J(x-v)=P_{1,b}(x-v) for the third leg. Original full future FIRST
at this same receiver gives

    integral P_x(y) beta(dy) <= q,
    integral Q_x(v) nu(dv) <= q.                         (TS1)

Indeed both moving kernels use the original current soft, their physical
scales are legal, and the J soft 1 is future. This invokes no backward
menu-soft FIRST and no FIRST on a cut source. Original large-n and margin
ancestry, including s<=1-d_n and d_n=1000 sqrt(log(n+2)/n), remains required
for an actual original instance; the algebra below has a larger domain.

The original hard local cap is (h_R*nu)(x)<=C0 q on Omega for every legal
fixed R in [a,b], where h_R(u)=R^{-n}1_{Q_R(0)}(u). In TS7–TS9 R is fixed
before x and the hard-source integral. In particular it is not an arbitrary
receiver-selected R(x).

## TS2. Exact affine posterior identity

Let f_i(s)=(1-s)a_i+s b_i with finite a_i,b_i>=0, weights lambda_i>=0,
m=sum_i lambda_i>0, and H_s=d0 product_i f_i(s)^{lambda_i}, d0>0.
Delete zero-weight factors. On a positive fiber and s,r in (0,1) put

    pi_i(s)=s b_i/f_i(s),
    p=m^{-1} sum_i lambda_i pi_i(s),
    Dpost(s,r)=sum_i lambda_i D(pi_i(s) || pi_i(r)),

where D is Bernoulli relative entropy. Then exactly

    log(H_r/H_s)
      =m[D(p||s)-D(p||r)]+Dpost(s,r).                  (TS2)

Proof: the two posterior likelihood ratios are
pi_i(s)/pi_i(r)=(s/r)f_i(r)/f_i(s) and
(1-pi_i(s))/(1-pi_i(r))=((1-s)/(1-r))f_i(r)/f_i(s).
Multiply their logs by pi_i(s),1-pi_i(s), respectively. Their sum is

    D(pi_i(s)||pi_i(r))
     =log(f_i(r)/f_i(s))
       -pi_i(s)log(r/s)-(1-pi_i(s))log((1-r)/(1-s)).

Weighted summation proves TS2. Each Dpost term is nonnegative by the
log-sum inequality (equivalently concavity of log). If a_i=0 or b_i=0,
the posterior is identically 1 or 0 and this term is zero; the same
identity follows with the usual 0 log 0 convention.

## TS3. Selected correction, including endpoints

Use the R235 one-sided posterior-angle menu: N=ceil(pi sqrt(n)),
Delta=pi/(2N), r_j=sin^2((j+1/2)Delta), and choose the first midpoint
angle >= arcsin sqrt(p), or the last midpoint if there is none. For m<=n,
the R235 elementary angle estimate gives

    m D(p||r_selected)<=9.

For completeness, if alpha=arcsin sqrt(p), beta=arcsin sqrt(r), then
|alpha-beta|<=Delta and sin(beta)cos(beta)>=Delta/pi. The sine addition
formula gives |p-r|/sqrt(r(1-r))<6 Delta. Hence
D(p||r)<= (p-r)^2/[r(1-r)] and mD<=36n Delta^2<=9.
TS2 therefore gives the **exact** corrected selected kernel

    Hcorr := exp[-mD(p||s)-Dpost(s,r)] H_r
           = H_s exp[-mD(p||r)] =: W H_s,
    exp(-9) H_s <= Hcorr <= H_s,     exp(-9)<=W<=1.    (TS3)

The correction is also <=H_r. Both facts are needed: the first recovers
actual-soft capacity; the second preserves domination by the old fixed-r
QG column. One must not discard Dpost and still claim TS3.

All menu labels are finite measurable functions of the original x,y,v.
For a zero H_s fiber define every corrected selected term to be zero.
When H_s>0 and s is an endpoint, TS2–TS3 hold by the same posterior
formulas with continuous entropy conventions, or by an interior limit.
For s=0 every positive factor has pi_i(0)=0, and for s=1 every positive
factor has pi_i(1)=1. The selected r stays interior, so these formulas are
finite. An endpoint-zero H_s needs only the stated zero convention.

For the two moving legs the source and target groups have weights 1-theta
and theta and total m=n. For the J leg the fixed J factor belongs to d0,
so m=n(1-theta). It is not correct to assign the J leg an extra soft
posterior group of mass n theta.

## TS4. What the posterior chain rule does and does not spend

For the two moving groups let u,v be the separate unweighted means of
their n current posterior probabilities. Then p=(1-theta)u+theta v and

    (1-theta)D(u||s)+theta D(v||s)
      =D(p||s)+(1-theta)D(u||p)+theta D(v||p).          (TS4)

Expand the entropies; all terms linear in u,v cancel. The last two
nonnegative terms are the exact loss in merging the group means.
Meanwhile Dpost itself splits exactly into the source transition sum
with coefficient 1-theta and target transition sum with coefficient
theta. These are different decompositions. In particular no inequality
Dpost >= the last two terms of TS4 is used or claimed. For r=s the former
is zero even when the group means differ.

Thus a single global negative KL cannot be booked independently in both
source slots. TS3 instead retains the full transition remainder once and
rewrites the complete joint kernel. It requires no independence between
the two sources, the selected label, or the actual receiver soft.

## TS5. Actual-soft joint kernel and target occupation

Applying TS3 to P^{1-theta}Q^theta gives, after summing its disjoint
selected labels, precisely

    Hcorr(x,y,v)=W(x,y,v) P_x(y)^{1-theta} Q_x(v)^theta. (TS5)

Let C(x,y,v) in [0,1] be a retained static measurable original gate, and
allow the original Z_tau(y) qualification inside it. All RN/capture
factors must have their separately proved range [0,1]; no extra capture
is imposed on a source to gain FIRST. Define

    zeta_act(x,y)=q^{-1} integral_{Z_tau(y)}
                    [C(x,y,v)W(x,y,v)]^{1/theta}
                    Q_x(v) nu(dv).

By TS1, 0<=zeta_act<=1. This remains true with W replaced by 1.
Both source dependences remain inside C and W. This is capacity at the
actual s(x), not capacity assigned to a backward-selected menu node.

Fixed-parameter QG is a separate alternative: Hcorr<=H_r allows the old
common-menu upper bound, with its explicit menu cost, when that is used.
TS5 does not turn an x-adaptive actual-soft column into a fixed-parameter
QG column at no cost.

## TS6. Two-slot operator at each receiver

Let p_theta=1/(1-theta). For any measurable W0(x,y,v) in [0,1], set
K_x(y,v)=W0 P_x(y)^{1-theta}Q_x(v)^theta and
T_x f(y)=integral K_x(y,v) f(v)nu(dv). Then

    ||T_x||_{Lp_theta(nu) -> Lp_theta(beta)}
      <= [integral P_x beta]^{1-theta}
         [integral Q_x nu]^theta <= q.                (TS6)

For complex f use |f|. Holder with exponents 1/theta,p_theta gives
|T_x f(y)|<=P_x(y)^{1-theta}(integral Q_x nu)^theta
||f||_{Lp_theta(nu)}. Raising to p_theta and integrating beta proves
the displayed bound. In particular W0=CW retains both joint posterior
corrections without factoring them into fictitious independent slots.

## TS7. Genuine Lebesgue column integration of the bare core

Set d_R(x)=(h_R*nu)(x)/(C0q). On Omega, 0<=d_R<=1. Tonelli and the
unit full-space column of this **fixed** hard kernel give

    integral_Omega d_R(x) dx <= nu(V)/(C0q).           (TS7)

Define K_Omega(y,v)=integral_Omega d_R(x)K_x(y,v)dx. Minkowski followed
by TS6 and TS7 gives the actual two-sided bare-core estimate

    ||T_Omega||_{Lp_theta(nu) -> Lp_theta(beta)}
       <= q integral_Omega d_R dx <= nu(V)/C0.        (TS8)

Use nonnegative simple truncations if an intermediate kernel is extended
valued; the norm bound and monotone convergence produce the final
bounded operator. All original receiver and source indicators can stay
in W0. No uncharged |Omega| or global nu(V)/(q a^n) occurs in TS8.

This is a bare-core geometric construct. It contains neither the inverse
clock weight w_*^{-theta} nor the conditional posterior Pi_t and its
y-dependent tests. It cannot be substituted directly for a bound on the
paid original clock. It also does not authorize summing arbitrarily many
physical nodes or original j at zero cost.

## TS8. Actual source mass exchange compatible with heavy reentry

With zeta_act from TS5 put

    S_act(y)=a^{-n theta} integral_Omega
              d_R(x) P_x(y)^{1-theta} zeta_act(x,y)^theta dx.

Then the precise mass exchange is

    integral S_act(y) beta(dy)
      <= nu(V)/C0 * [beta(V)/(q a^n)]^theta.           (TS9)

Indeed for each actual x, Holder in beta and TS1 yield

    integral P_x^{1-theta} zeta_act^theta beta
      <= (integral P_x beta)^{1-theta}
         (integral zeta_act beta)^theta
      <= q^{1-theta} beta(V)^theta.

Tonelli followed by TS7 proves TS9, including every power of q and a.
For beta(V)=0 or nu(V)=0 all relevant original integrals vanish; handle
these cases before formulas involving powers or normalizations. Finite
positive source masses are otherwise assumed, as in the original
truncation. This proof uses real Lebesgue dx, not receiver counting or an
unproved q|Omega| input bound. It preserves the exact hard column until
after the actual source-FIRST step.

The original fractional-good coefficient, physical covering fee, heavy
interval and heavy constant, and remaining j/M sum belong to the clock
reentry theorem. TS9 is its source exchange, not another payment of any
negative traffic. The C0 hard normalization is used once. The displayed
source congestion beta(V)/(q a^n) is explicit; no general input-budget
comparison is concluded merely from this formula.

## TS9. Exact role of nu <= beta

Absolute continuity alone gives a Radon--Nikodym density, not a bounded
density or a capacity comparison. The actual inherited domination is
stronger: nu<=beta, so dnu/dbeta<=1, nu(V)<=beta(V), and the inclusion
Lp(beta) -> Lp(nu) is contractive. Hence TS8 can also be read as an
operator on Lp(beta), with the target RN multiplier retained and bounded
by one. Summed over disjoint original V, nu-mass can be charged to beta
mass, and then to the input when its original disjointness is available.

TS9 itself needs the two actual FIRST inequalities, the hard column and
the finite masses; it does not require replacing nu by beta. Domination
does not identify their normalized posteriors, transpose the original
histories/high gates, or make the remaining degree/scale tests symmetric.

## TS10. Reproducible finite arithmetic diagnostic

The following local Python/mpmath calculation checks the exact posterior
identity (including zero hard factors), then finite two-slot operator and
mass-exchange inequalities. It is a scalar/discrete diagnostic, not a
FULL instance, directed-interval certificate, or a substitute for the
proof above. All its inputs are exact decimal/rational strings. The
reported tolerances only concern floating arithmetic. Run using Python
with mpmath available (this host uses mpmath 1.3.0 in the existing vendor
directory). No diagnostic changes the original large-n qualification.

```python
import mpmath as mp
mp.mp.dps = 70
D = lambda p,q: (mp.mpf(0) if p==0 else p*mp.log(p/q)) + (mp.mpf(0) if p==1 else (1-p)*mp.log((1-p)/(1-q)))
tables = [([1,0,1,0],[mp.mpf('.3'),mp.mpf('.2'),mp.mpf('.7'),mp.mpf('.1')]),
          ([1,1,1,1],[mp.mpf('.2'),mp.mpf('.6'),mp.mpf('.4'),mp.mpf('.8')])]
checks=0; maxerr=mp.mpf(0); maxround=mp.mpf(0)
for n in [2,16,512]:
    N=int(mp.ceil(mp.pi*mp.sqrt(n))); delta=mp.pi/(2*N)
    grid=[mp.sin((i+mp.mpf('.5'))*delta)**2 for i in range(N)]
    for s in map(mp.mpf,['.1','.5','.9']):
      for th in map(mp.mpf,['.1','.25','.5']):
       for aa,bb in tables:
        for fixedJ in [False,True]:
         lam=[n*(1-th)/2]*2 + ([mp.mpf(0)]*2 if fixedJ else [n*th/2]*2)
         m=sum(lam); fs=[(1-s)*a+s*b for a,b in zip(aa,bb)]
         ps=[s*b/f for b,f in zip(bb,fs)]; p=sum(l*z for l,z in zip(lam,ps))/m
         r=next((rr for rr in grid if rr>=p),grid[-1])
         fr=[(1-r)*a+r*b for a,b in zip(aa,bb)]
         pr=[r*b/f for b,f in zip(bb,fr)]
         lhs=sum(l*mp.log(g/f) for l,f,g in zip(lam,fs,fr))
         post=sum(l*D(z,w) for l,z,w in zip(lam,ps,pr))
         rhs=m*(D(p,s)-D(p,r))+post
         err=abs(lhs-rhs); maxerr=max(maxerr,err); maxround=max(maxround,m*D(p,r))
         assert err<mp.mpf('1e-60') and post>=-mp.mpf('1e-60') and m*D(p,r)<=9
         assert abs(mp.exp(-m*D(p,s)-post+lhs)-mp.exp(-m*D(p,r)))<mp.mpf('1e-60')
         checks+=1
C0=mp.mpf(16)/3; q=mp.mpf(1); beta=list(map(mp.mpf,['2','3','1'])); nu=list(map(mp.mpf,['.2','.4','.1']))
# Each hard column has counting-integral one, the finite analogue of fixed h_R.
H=[[mp.mpf(1)/4]*3 for _ in range(4)]
d=[sum(H[x][z]*nu[z] for z in range(3))/(C0*q) for x in range(4)]
P=[]; Q=[]
for x in range(4):
    row=[mp.mpf((x+2)*(y+1)+1) for y in range(3)]
    P.append([v/sum(row[y]*beta[y] for y in range(3)) for v in row])
    row=[mp.mpf((x+1)+(v+2)**2) for v in range(3)]
    Q.append([z/sum(row[v]*nu[v] for v in range(3)) for z in row])
maxmass=mp.mpf(0); maxop=mp.mpf(0)
for th in map(mp.mpf,['.1','.25','.5']):
    p=1/(1-th)
    C=lambda x,y,v: mp.mpf(1+(x+2*y+3*v)%7)/8
    zeta=[[sum(C(x,y,v)**(1/th)*Q[x][v]*nu[v] for v in range(3))/q for y in range(3)] for x in range(4)]
    S=[sum(d[x]*P[x][y]**(1-th)*zeta[x][y]**th for x in range(4)) for y in range(3)]
    ratio=sum(S[y]*beta[y] for y in range(3))/(sum(nu)/C0*(sum(beta)/q)**th)
    assert ratio<=1; maxmass=max(maxmass,ratio); checks+=1
    K=[[sum(d[x]*C(x,y,v)*P[x][y]**(1-th)*Q[x][v]**th for x in range(4)) for v in range(3)] for y in range(3)]
    for f in [[mp.mpf(1)]*3,[mp.mpf(1),mp.mpf(0),mp.mpf(0)],list(map(mp.mpf,['.2','3','1']))]:
        out=[sum(K[y][v]*f[v]*nu[v] for v in range(3)) for y in range(3)]
        lhs=sum(beta[y]*abs(out[y])**p for y in range(3))**(1/p)
        rhs=sum(nu)/C0*sum(nu[v]*abs(f[v])**p for v in range(3))**(1/p)
        ratio=lhs/rhs; assert ratio<=1; maxop=max(maxop,ratio); checks+=1
print('checks',checks,'max_identity_error',mp.nstr(maxerr,8))
print('max_rounding_KL',mp.nstr(maxround,20))
print('max_mass_ratio',mp.nstr(maxmass,20),'max_operator_ratio',mp.nstr(maxop,20))
```

Actual execution on this host (Python 3, mpmath 1.3.0, 70 decimal digits,
exit 0; the script was extracted from this file and executed verbatim):

```text
checks 120 max_identity_error 1.3909523e-68
max_rounding_KL 0.44300572862829273787
max_mass_ratio 0.6835141364338555572 max_operator_ratio 0.49609924722529134426
```

The 108 posterior checks and 12 finite capacity/operator checks support
the algebra and normalization only. They do not numerically certify a
general source-input budget or an original admissible FULL history.
