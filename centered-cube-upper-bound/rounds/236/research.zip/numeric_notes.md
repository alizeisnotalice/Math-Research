# R236 numerical notes

初始较高维方案因实际计算预算调整为下述菜单；未计入证据。

# Executed bounded menu and results

The earlier pending plan was superseded by the explicit permission to reduce dimension and prioritize the new identity/exchange bound. Executed: twelve genuine one-dimensional finite L1 receiver/source models and twelve independent general-n affine identities. No spatial simulation or high-dimensional geometry was run. The full-dimensional physical integrals here have dimension n=1; they do not qualify the original n>=2 or large-n branch.

Physical sources are uniform intervals centered at 0,.75,1.4 with halfwidth .1 and masses 1,.5,.125. Thus nu mass is1.625. Beta is either nu or nu plus mass2 uniform on [1.85,2.15], so nu/beta mass is1 or13/29. f=2beta and nu<=beta<=f. Omega=[-.25,.25], a=L=A=1, C=1 and Z_tau is relaxed to all sources. A fixed q=2 beta mass applies to the entire receiver domain and every future soft: p_s<=1 and thus integral f P_s<=2 beta mass. The original hard mass H_R is computed from exactly the same nu; d_R=H_R/(C0q), C0=16/3. Its total integral is at most nu mass/(C0q). This verifies the necessary local capacities without claiming capture, ancestry/history or FULL realization.

Initial: s=1/3, theta=.1/.5, each beta variant (four models). Stress: s=.8, theta=.01/.1, each beta variant (four). Expanded: s(x)=.2 for x<0 and .8 for x>=0, theta=.01/.1, each beta variant (four). Theta is fixed before x,y,v; actual s(x) is shared by the source and receiver factors. The actual one-dimensional menu has N=ceil(pi)=4 and its last midpoint exceeds .8. All source and receiver hard boundaries are split in quadrature. Compact source/receiver domains leave no omitted infinite integration tails.

The JSON reports beta-weighted Xi and S0 integrals, rather than relabeling their ratio as a fixed-y ratio. S0 is a R235-style Psharp comparator computed from the same *raw* T0; it is not the R235 normalized-Bmax target. Xi_posterior includes the newly retained Dpost. Its integrand is bounded by the actual-soft integrand using the exact posterior identity. No normalized-target capacity14 claim is assigned to raw T0.

Physical integration uses numpy float64 GL8/GL12, with actual phi values independently computed by mpmath at25/40dps. This is deliberately not described as a40-digit spatial integral. Four small-theta stress/expanded configurations also use GL24 with50dps phi values. The largest GL8/12 absolute change was3.04e-7; subsequent GL12/24 changes were at most4.15e-8. These are empirical refinement differences, not certified error bars. Labels vary with x,y,v, so ordinary quadrature includes piecewise selection changes.

At the final available order, raw beta-Xi/beta-S0 lies approximately [.724790,.914580]; posterior-corrected beta-Xi/beta-Sact lies [.945954,.995208]. Sact's beta-weighted integral divided by the proposed mass-exchange bound nu_mass/C0*(beta_mass/q)^theta lies [.029259,.086226]. Adding the extra beta mass lowers this fee ratio in the tested model; this is a finite mass-allocation observation, not a universal extremal statement. The bound here is intentionally not close to saturation: q is a safe global envelope and Omega is only part of the hard domain. n theta and n B_theta(s) are separately stored, not suppressed as constants.

The scalar identity menu has n=2,16,512, each moving m=n and J m=n(1-theta), each at (s,theta)=(.25,.1),(.95,.01), for twelve total. Three affine factors have weights n/4,n/3,5n/12 before the J multiplier, including one zero hard coefficient. Direct independent log evaluations at40 and70dps verify H_r exp[-m D(p||s)-Dpost]=H_s exp[-m D(p||r)]. Maximum70dps absolute log residual was1.390952306507783e-68; all selected mD(p||r)<=9. This checks implementation of the exact identity, not a general proof by finite samples.

The contract's full physical-node log-cubic sum is independently handled by the parent and is intentionally not duplicated in this worker's menu. No fitted dimension order or general FULL source-budget conclusion is claimed.

## Frozen replay

The final separate-output complete replay was byte-identical (40,054 JSON bytes). Actual timing was1.56s wall,1.54s user,.01s system. No time/output-path fields enter the JSON. Source SHA256: `a30d52f883b0390587fa84efec48e16f094d80d931c90eb44dd73dc1a22670ae`; JSON SHA256: `a0b90992659708c1cd5b570f81518f8b9519622afad478e76ed67e89df0cbaf2`; contract SHA256: `c79bea0a0f843c18359ad25c4025348334eafdc3b9de0324dae49a95d6460a98`. Frozen actual counts:12 physical L1 models (four with additional GL24 refinement) and12 general-n posterior identities.

## Local runtime and complete replay command

Actual executable: `/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`; Python `3.12.14`. NumPy `2.3.5` at `/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages/numpy/__init__.py`; mpmath `1.3.0` at `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor/mpmath/__init__.py`. The bundled Python supplies NumPy; the explicit vendor PYTHONPATH supplies mpmath. No dependency installation was performed.

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/236/work/numeric_checks.py \
--output /tmp/r236_numeric_replay.json
```

For a relocated package, change only the script/output paths; the source resolves its adjacent task_contract.md automatically. The script/JSON hashes above are unchanged by this notes-only update.
