# 第236轮：实际软参数几何与来源质量交换

一般 n^(1/2+o(1)) 一致弱型上界仍未闭合。本轮正成果是对原far正余项的一条新的全物理尺度价格；没有把其来源矩当作已付款。

## 目标与准确结果

R235用Psharp后再做posterior Holder，虽能合并目标菜单，却留下实际soft包络和局部倾斜费。本轮保精确的逐坐标后验KL余量：校正的唯一标签核等于原actual-soft乘积乘 exp(-mD(p||r))。它和原核相差一个已控常数，说明可以直接保接收点的原s(x)，不必给来源槽添Psharp。

固定原physical node后，target current/future FIRST给zeta_act<=1；source beta FIRST与Holder给source行界；hard单位质量核给真实Lebesgue列界。由此严格得到

    integral S_act(y) beta(dy) <= ||nu||/C0 * (||beta||/(q a^n))^theta.

这不是用未支付Omega体积替代原质量：真实receiver积分已由固定hard列归一化结算。不能把同一步直接用于未固定的R(x)。beta与nu仍是同一原source层级中的不同测度。

同原full posterior和growing-heavy时钟接回后，C0相消。另一独立价格使用R234近角soft菜单，保eN倍QG/Gini；两价估同一actual adaptive-soft列。以B=eN、R=1+log_+rho_beta+log_+K+logB、theta=1/(2R)、T=2log_+(B rho_beta)，在x<=T用新容量价，在x>T用指数衰减旧价。完整求和得到

    P_far(U) <= 12 Lambda e^4 D E sum_V ||nu_V|| R_V^3,
    D=9 exp(3/2)+2 sqrt(e), N=ceil(pi sqrt(n)).

新式没有外乘N；N只在logB中。theta由outer V一次决定，不依receiver、target、物理节点或时钟重选。R234原beta加权价格仍可保作替代价；两式不对所有source质量比自动排序。详细定义、全部常数、tail几何和以及零质量约定见proof.tex.txt；作者独立构件见geometry.md/two_slot.md。

## 未完成项与下一步

没有证明 E sum ||nu_V|| R_V^3 是输入质量的根阶预算；也没有免费支付Lambda、其它分支或历史复用。即使beta=nu，任意密度比仍可使该矩大，本轮不将有限数值或source包含关系当作一般证明。下一瓶颈是保持来源共同几何，局部化beta质量或支付nu加权历史尾，而不是重新引入未经证明的全局强不等式。

## 方法边界与工具

实际使用本机Python数学库做数值。F05技能用于审查两侧底测度和核界，E03用于提醒只有真实质量流/终端预算才能作跨层望远镜；本轮没有引用一个外部Schur/Bellman定理来补缺失历史条件。核心证明是自给的Holder、Tonelli、有限Bernoulli恒等式和正几何级数。

初始计划仅保label的Xi，随后精确后验余量显示直接actual-soft更适合真实容量，因此以后一条作为主结果。Xi对比保留在数值中作决策证据。没有展开反例排除研究，没有PDF编译。没有可可靠归属本轮的实际额度扣减数据。

## 实际数值范围

numeric_checks.py：12个真实一维有限L1模型+12个一般n的affine恒等式；三阶段配置、求积加密、40/70位恒等式复核，具体见numeric_notes.md。一维模型不是原n>=2/large-n/FULL实例；C=1、Ztau全source是已标明外放。实际模型用同一q和同一source，检查beta来源质量交换界。有限n不用于猜测阶数，浮点求积差不是区间证书。

scale_checks.py：三阶段30个配置，n=2..1024，logrho=-50..200，logK=-30..100，U包含空窗口，b/a包含1.01与2。实际遍历498143个正窗口物理节点，保regular grid和唯一cap，检查两价完整sum以及small/tail分账；总和/解析总界最大0.0014628222294698111。仅双精度算术，不认证FULL样本或渐近阶，解析阶由proof给出。

上述两类共54配置，分别计数，不能把498143节点当独立一般模型。独审的额外标量/有限cell检查单列于audit，不与主配置数混计。全部主结果JSON须包外重算逐字节比较，manifest运行前后核验；最终回执在仓库外检查点记录。reproduce.py不修改冻结包。

两槽作者在two_slot.md内嵌可执行脚本，108项后验和12项有限容量/算子诊断共120项；独审独立抽取运行通过。reproduce.py另把该代码复制到包外运行并核对固定输出。它与上述54主配置分开记数。峰值作者35项与独审59项仅作各自实际诊断记录，未归档独立脚本，不将它们冒称本驱动重放项。
