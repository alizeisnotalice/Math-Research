"""Finite arithmetic diagnostics for R236 scale settlement, not FULL examples."""
import math,json
from pathlib import Path

def one(n,logrho,logk,U,ratio):
 d=n*math.log1p(1/n); N=math.ceil(math.pi*math.sqrt(n)); logB=1+math.log(N)
 R=1+max(0,logrho)+max(0,logk)+logB; theta=1/(2*R)
 T=2*max(0,logB+logrho); ell=1+math.log(n)
 jmax=math.floor(n*math.log(ratio)/(2*d)); total=small=tail=0.; count=0
 for j in range(jmax+1):
  maxx=n*math.log(ratio)-2*j*d
  xs=[k*d for k in range(math.floor(maxx/d)+1)]
  if maxx-xs[-1]>1e-11:xs.append(maxx)
  for x in xs:
   z=x-U
   if z<=0:continue
   logA=-math.log(2*theta)+theta*(logrho-math.log(ell)-1.5*j*d+x)+math.log(-math.expm1(-2*theta*z))
   logG=logB+logrho-math.log(4)-2*j*d-x+math.log(z)
   outer=theta*(logk-math.log(3))
   total+=math.exp(min(logA,logG)+outer)
   if x<=T:small+=math.exp(logA+outer)
   else:tail+=math.exp(logG+outer)
   count+=1
 bound=(9*math.exp(1.5)+2*math.sqrt(math.e))*R**3
 assert total<=small+tail+1e-8*max(1,total)
 assert small<=9*math.exp(1.5)*R**3*(1+1e-10)
 assert tail<=2*math.sqrt(math.e)*R*(1+1e-10)
 return dict(n=n,logrho=logrho,logK=logk,U=U,ba=ratio,N=N,R=R,theta=theta,T=T,nodes=count,total=total,bound=bound,ratio=total/bound,small=small,tail=tail)

def main():
 stages={
 'explore':[(n,r,k,u,2.) for n in (2,8,32) for r,k,u in ((0.,0.,0.),(3.,2.,.5),(-5.,4.,2.))],
 'stress':[(n,r,k,u,ratio) for n in (16,64,128) for r,k,u,ratio in ((-50.,0.,0.,2.),(100.,50.,0.,2.),(0.,-30.,0.,1.01),(10.,2.,1000.,2.))],
 'expanded':[(n,r,k,u,2.) for n in (256,512,1024) for r,k,u in ((0.,0.,0.),(30.,10.,2.),(200.,100.,10.))]}
 rows=[dict(stage=stage,**one(*args)) for stage,items in stages.items() for args in items]
 # Local arithmetic corroboration of scale bounds; no empirical n-order claim.
 data=dict(description=__doc__,configurations=len(rows),max_ratio=max(r['ratio'] for r in rows),rows=rows)
 out=Path(__file__).with_suffix('.json');out.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(configurations=len(rows),max_ratio=data['max_ratio'],nodes=sum(r['nodes'] for r in rows))))
if __name__=='__main__':main()
