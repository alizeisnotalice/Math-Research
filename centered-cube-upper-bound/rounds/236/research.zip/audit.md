# R236 independent audit

## Statement-first checkpoint (before R236 author drafts)

The contract and frozen R235 proof were read first. The proposed response is legitimate with a common fixed theta in (0,1/2], fixed physical node, fixed original receiver domain Omega, and static capture C_r(x,y,v) in [0,1]. The selected-label supports are disjoint, so the new Xi response keeps the exact sum before Holder; its receiver integral is bounded by R235's Psharp response. The same actual-posterior heavy-clock coefficient applies. A t- or u-dependent capture cannot be silently put into this static column. Neither the source FIRST nor the response identity pays a spatial average by itself.

The exact affine identity has the stated positive posterior-divergence remainder. Thus the corrected selected kernel equals H_s exp(-m D(p||r)) and lies between exp(-9)H_s and H_s under the upward-angle rounding qualification. This comparison does not hold for the old raw selected kernel with that remainder omitted. Zero fibers are set to zero; interior s,r with affine endpoint coefficients zero cause no support discrepancy. Original s=0 requires its continuous endpoint convention.

The stronger direct actual-soft route is valid. At each original receiver, both node physical kernels with current s(x) are in the original simultaneous FIRST family; the fixed J target is also legal. With d_R=(h_R*nu)/(C0 q), zeta_act<=1 and beta<=f, beta-Holder gives integral_beta P_s,L^(1-theta) zeta_act^theta <= beta_mass^theta q^(1-theta). Fixed-node hard normalization gives integral_Omega d_R <= nu_mass/(C0 q). Therefore integral_beta S_act <= (nu_mass/C0)(beta_mass/(q a^n))^theta. The hard scale must already be fixed: an adaptive R(x) is not entitled to this unit-mass calculation. No identification of beta with nu or of their posteriors is used.

After beta integration, the actual node clock is bounded by nu_mass times (2theta)^-1 (rho_beta/ell)^theta c^(3theta n/2) exp(theta x)(1-exp(-2theta z)). The independent R234 nearest-angle menu gives e N times the old Gini bound for this same actual column. It is unnecessary to compare that actual column with the old raw selected column. Put B=e N, R=1+log_+rho_beta+log_+K+log B, T=2log_+(B rho_beta), theta=1/(2R). The small-x count and j sum are each at most 3R; the exponent is at most 3/2. The tail is bounded by 2 sqrt(e) R. Hence the all-node/all-j price is at most nu_mass (9 exp(3/2)+2 sqrt(e))R^3. Including three legs, two orientations and original 2 Lambda leaves 12 Lambda exp(4), with no exterior menu factor. Theta and every factor it determines remain inside the outer leaf sum if theta varies with that leaf.

These are bounds for the original far mother quantity under its inherited valid/heavy gates, not payments for all original branches. The nu-weighted log-cubed rho_beta moment, all historical leaf sums, and the other branch budgets still require an input bound. Dropping positive gates does not authorize reusing their conditions at newly enlarged receiver points; negative credit is untouched.

Independent local computation: 54 high-precision affine posterior/upgrid checks and five finite Lebesgue-cell two-source mass-exchange checks passed (mpmath 60 dps). The latter are abstract finite-cell checks, not FULL cube instances or a substitute for the analytic argument. These 59 checks were actually run as bounded diagnostics; their standalone code is not archived and they are not counted among the 54 formally replayable main configurations. The displayed scalar constant is 43.6326441744428396971158007167.

This initial checkpoint is superseded by the completed author-proof/replay audit and frozen conclusion below.

## Parent proof and executable checks

The complete parent proof (1)–(10) was read. Its actual-soft route uses the original simultaneous current/future FIRST only at original receiver points. The heavy inequality is used only on valid original heavy times; integrating its positive scalar majorant over the larger node interval does not restore an invalid posterior. Both copies of the actual posterior remain the same. The node Gini alternative is obtained independently through the nearest-angle menu with its full e N charge. The small-node count, j-geometric series, exact positive tail series and restoration of three legs/two orientations agree with (9)–(10). In particular the C0 in the new clock cancels the 1/C0 from the mass exchange. No receiver-volume term, posterior-source substitution or second hard cap is introduced.

Both numerical source files were read in full and independently executed once with the installed Python/math runtime. numeric_checks.py completed all 12 physical models and 12 posterior identities; its entire output was byte-identical to the frozen JSON (SHA256 a0b90992659708c1cd5b570f81518f8b9519622afad478e76ed67e89df0cbaf2). scale_checks.py was copied to a temporary directory before execution to avoid changing the shared output. Its 30 configurations and 498143 positive nodes completed, and the whole JSON was byte-identical (SHA256 33d92fd3be65406c4a9b732ac3b75a92720e0fc04cd8840c2bb93ebd760e571e). Its largest recorded price/bound ratio is 0.0014628222294698111, which is a finite diagnostic, not an optimality claim.

Physical numerics use true n=1 compact Lebesgue receiver/source integrals, fixed normalized hard occupancy from the same nu, beta=nu or a larger beta, and f=2 beta. They verify only upper local capacities, not the original selector equality, ancestral large-n conditions or FULL history. The soft selector is common to both physical slots. Float64 GL8/12 integration with mpmath kernel evaluation, and four GL24 refinements, is empirical quadrature rather than interval or high-digit spatial certification. Compact domains omit no infinite tails; selected-label changes are not certified by the refinement differences. The separate identity calculations are high precision scalar checks at n=2,16,512. The notes correctly separate these scopes and the retained Dpost from the earlier raw target; raw T0 is not assigned capacity 14.


## Author integration, revisions, and final conclusion

Both geometry.md (G1–G10) and two_slot.md (TS1–TS10) were read completely. The weighted affine identity, its endpoint/zero conventions, correction direction, static-capture qualification, original same-point FIRST, fixed-hard normalization and complete physical-grid sum agree with the parent proof. TS6–TS8's Lp operator estimate is a valid bare-core consequence of the two source capacities and fixed hard column; the text correctly excludes the inverse clock weight, conditional posterior, and any free summation over nodes. It is not used as a hidden substitute for the heavy-clock calculation.

The TS10 archived embedded script was extracted verbatim and independently executed: all 120 checks passed (108 posterior identities plus 12 finite mass/operator diagnostics). Its stdout exactly matched the final recorded output: maximum identity residual 1.3909523e-68, rounding KL 0.44300572862829273787, mass ratio 0.6835141364338555572, and operator ratio 0.49609924722529134426. These are algebra/finite-measure diagnostics, not FULL input certification. The geometry author's additional checks remain reported author diagnostics; they are not relabeled as this auditor's executions.

Final revisions requested by this audit were explicit n>=2, K_+=max(1,K), nonnegative affine coefficients/weights and the total-weight restriction m<=n when invoking the n-dependent menu. These are domain/notation repairs; they do not change the actual three-leg proof. The final report retains the unproved source moment and branch/history boundaries. The final driver copies the contract with the two numerical scripts to a new external directory, compares both complete JSON outputs, extracts/runs TS10 and compares its complete recorded stdout, and verifies the frozen manifest before and after. This audit has not executed the final manifest driver; the parent will record that separate receipt after freezing.

**Conclusion: pass within the stated original far-positive scope.** The actual receiver integral and physical/soft-selector costs are bounded as claimed, with final coefficient 12 Lambda exp(4)(9 exp(3/2)+2 sqrt(e)) and the explicit nu-weighted cubed logarithmic source price. There is no exterior soft-menu count. No general input bound for that price, historical source-reuse settlement, near/other complementary payment, or general arbitrary-positive-L1 root theorem is certified. No negative/deletion credit is spent.

The frozen hashes below exclude this audit itself. No further audit writes are intended after the final hash table.

| File | SHA256 |
| --- | --- |
| task_contract.md | `c79bea0a0f843c18359ad25c4025348334eafdc3b9de0324dae49a95d6460a98` |
| proof.tex.txt | `e61b8f76ff9452be72a98ef4117657484dae00deafb903647f7407ef75b3608c` |
| geometry.md | `4f5763cbb34606f90910db508c028d8362f957dbefe97c9a0c8059636dc422fb` |
| two_slot.md | `ad45004b9de137706c19e186f69e9d0bec1cae917b56ba10a31288c3bf38f34c` |
| report.md | `2c9f0ac9ecb5c292f66d0d99999c0f22396f25732c0c44f7ba14fa06da62b075` |
| numeric_checks.py | `a30d52f883b0390587fa84efec48e16f094d80d931c90eb44dd73dc1a22670ae` |
| numeric_checks.json | `a0b90992659708c1cd5b570f81518f8b9519622afad478e76ed67e89df0cbaf2` |
| numeric_notes.md | `bc1377d27f01f6de6f49af7d827466a94345658f72adba67cbb3a7f489b0ad91` |
| scale_checks.py | `383b66136c3ab9522baaf5981180ae8adca548fd712aa0fef3c8aa837f52ebd1` |
| scale_checks.json | `33d92fd3be65406c4a9b732ac3b75a92720e0fc04cd8840c2bb93ebd760e571e` |
| reproduce.py | `cd84902488237b677d558d31d52fefc125d47adf28da031329f8c29767473c50` |
