# R236：actual-soft 双槽 FIRST 与交换后的来源价

本文只处理原正 far 交通。新界保留原 receiver softness，先在两来源槽使用同一个 FIRST，再积分真实 hard 核；因此最终外来源质量是 `||ν||`，不再是上一轮的 `||β||`，且无外乘 soft 菜单数。仍未证明任意输入的根阶总预算：最后的 `ν` 加权三次对数来源矩必须列账。

## G1. 原对象和量词

固定原有限截断及原外资料 `(ω,V)`。记原同构造来源为 `0≤ν≤β≤f dx`，`0<a≤b≤2a`，`q,K>0`，`n≥2`，`C0=16/3`，`ell=1+log n`。本文跨 `j` 求和要求这些 `a,b,q,β,ν` 是同一份原资料；不能对各 `j` 换来源后再合计一次质量。

`Ω` 是同一原 receiver 集的合法静态上集，保留其 full FIRST 与全部实际尺度 hardband。尤其原 softness `s=s(x)` 是 receiver/history 选择，独立辅助 clock `t`，也不依被积分的来源 `y,v,z`。对于每个 `x∈Ω`、`A∈[a,b]`、`r≥s(x)`，原 full FIRST 给

\[
 \int P_{r,A}(x-w)f(w)dw\le q. \tag{G1.1}
\]

因此在原 `β,ν` 上均成立。这里是原完整 FIRST 的后果，不是在裁剪来源上重新定义 FIRST。对所有 `R∈[a,b]`，

\[
 (h_R*\nu)(x)\le C_0q\quad(x\in\Omega),\qquad
 h_R=R^{-n}1_{Q_R},\quad \int h_R=1. \tag{G1.2}
\]

所有剩余原 ancestry 资格仍保留：`s≤1−d_n`，`d_n=1000 sqrt(log(n+2)/n)`，`L≤b−2a/n`，`n>4·10^6 log(n+2)`。不满足资格或空窗的交通取零。以下核与 clock 引理可在低维验证，但低维例子不是原 FULL 实例。

固定 `(ω,V,j,y,t)` 后，原 `Z_t(y),w_t(y,v),e_t(y),Π_t(y,dv),k_t(y,v)` 不依 receiver `x` 或 hard 来源 `z`：

\[
 w_t(y,v)=\prod_{i=1}^n\min(1,A_i(y,v)/t),\quad
 e_t=\int_{Z_t(y)}w_t\,d\nu,\quad
 d\Pi_t=e_t^{-1}1_{Z_t(y)}w_t\,d\nu.
\]

`Z_t` 随 `t` 递减；`k_t=−∂log t log w_t∈[0,n]`（阈值处按 a.e.），原正 score 是 `δ_t(v,u)=(k_t(v)−k_t(u))_+`，其中 `v` 是 good 端。无效或 `e_t=0` 的行置零。两个槽始终使用这一同一原 `Π_t`，不条件化重归一。

指数 `θ∈(0,1/2]` 在 `(ω,V)` 级别冻结，早于 `x,y,v,z,j,M,t`。原 full FIRST 与下文直接 actual-soft 证明不要求 `θ≤d_n`。

## G2. 精确 posterior 余量：R235 raw 列缺失了什么

考虑一个固定物理节点的 affine product

\[
 H_s=d_0\prod_i f_i(s)^{\lambda_i},\quad
 f_i(s)=(1-s)a_i+sb_i,\quad a_i,b_i,d_0,\lambda_i\ge0,\quad
 m=\sum_i\lambda_i\le n.
\]

零权删去；`m=0` 为常量。正 interior product 必有 `d0>0`；对这样的产品定义

\[
 \pi_i(s)=\frac{sb_i}{f_i(s)},\quad
 p=\frac1m\sum_i\lambda_i\pi_i(s),\quad
 J_{s,r}=\sum_i\lambda_iD(\pi_i(s)\Vert\pi_i(r)).
\]

对 `r∈(0,1)` 有精确恒等式

\[
 \boxed{\log\frac{H_r}{H_s}
 =m[D(p\Vert s)-D(p\Vert r)]+J_{s,r}.} \tag{G2.1}
\]

证明只需逐因子写

\[
 D(\pi_i(s)\Vert\pi_i(r))
 =\pi_i(s)\log\frac{s}{r}
 +(1-\pi_i(s))\log\frac{1-s}{1-r}
 +\log\frac{f_i(r)}{f_i(s)}
\]

再乘权求和。`J≥0`。使用 R235 单一向上 posterior 角网格选点，其 `mD(p||r)≤9`，得

\[
 \boxed{e^{-9}H_s\le
 H_r e^{-mD(p\Vert s)-J_{s,r}}
 =H_se^{-mD(p\Vert r)}\le H_s.} \tag{G2.2}
\]

移动两腿 `m=n`，固定 J 腿 `m=n(1−θ)`，必须分别使用正确的 `m`。端点按连续极限；原产品为零时 corrected 产品定义为零。R235 raw 产品未扣 `J`，故不能反称旧 raw 产品本身受 `H_s` 控制。

这提供一个保 individual posterior 的严格改进，但下面的最强 receiver 结算直接保留 `H_s`，不先选 soft 节点；因此主界没有 `e^9` 外费。其另一个 QG 备选才使用 R234 最近角菜单，见 G7。

## G3. 原 good 与物理节点

原 good 资格和凹幂次可给

\[
 p_y1_{\rm good}\le(K/3)^\theta
 \sum_{i=1}^3p_y^{1-\theta}Q_i(x,v)^\theta w_g(y,v)^{-\theta}. \tag{G3.1}
\]

原三腿是 `P_{s,L}`、`P_{s,min(b,γL)}`、`J=P_{1,b}`。令 `γ=1+1/n`、`c=γ^{-j}`、`M0=a/c²`；仅考虑 `M0≤b`。节点从 `M0` 起按 `γ` 增长，末点截为 `b`，末点与正规点重合时不重复。两个朝向为

\[
 (L^*,R^*)=(M,c^2M)\quad\hbox{或}\quad(c^2M,M),
 \qquad g^*=cM.
\]

目标三腿节点分别为 `A*=L*`、`min(b,γL*)`、固定 `b`。这些尺度全部在 `[a,b]`。R229 已证向上物理 cover，保原捕获类且对全部 `θ≤1/2` 的总损失至多 `γ^{4n}≤e^4`。原逆权也沿合法方向转为 `w_*^{-θ}`，其中 `w_*=w_{g*}=bar w_{c²M}`。

重要的是：只放物理尺度，仍用原同一个 `s(x)`。写

\[
 P_y(x)=P_{s(x),L^*}(x-y),\qquad
 Q(x,v)=P_{s(x),A^*}(x-v)
\]

用于前两腿；第三腿 `Q(x,v)=J(x-v)`。由 G1.1，

\[
 \int P_y(x)\beta(dy)\le q,\qquad
 \int Q(x,v)\nu(dv)\le q. \tag{G3.2}
\]

`P_y`、`Q` 可以随 receiver 改变 softness；它们不必在 `x` 上归一化，本文也不如此使用。只有固定 soft 后才可调用原 QG 全空间列估计。

## G4. 静态捕获与 exact actual-soft 列

令 `0≤C_*(x,y,v)≤1` 保留已认证的物理节点静态 capture，独立 `t,u,z`。例如只在原 `R≤L` 支保相应 `Q_max(a,R*/γ³)(v)` 排除；原 `R>L` 支只有 upper-clamp 授统一 `Q_a(v)` 排除，lower-clamp 不授整个 core 排除。允许另保其它已认证静态正门。涉及 hard 来源、另一 posterior 槽或 clock 的原门在左侧保留或正放，不冒充 `C_*` 的乘积因子。

记

\[
 d_R(x)=\frac{(h_{R^*}*\nu)(x)}{C_0q},\qquad
 \zeta_{\rm act}(x,y)=q^{-1}\int_{Z_\tau(y)}
 C_*(x,y,v)^{1/\theta}Q(x,v)\nu(dv),\quad \tau=a/c.
\]

则 `0≤d_R,ζ_act≤1` 在 `Ω` 上成立，且

\[
 \int_\Omega d_R(x)dx\le\frac{\|\nu\|}{C_0q}. \tag{G4.1}
\]

后式是 Tonelli 和 hard 核归一，完全不要求全空间 `ν` 密度帽。保原 hard 来源的 exact 列为

\[
 F_{\rm act}(y,v)=q^{-1}\int_\Omega
 (h_{R^*}*\nu)(x)C_*(x,y,v)
 P_y(x)^{1-\theta}Q(x,v)^\theta w_*(y,v)^{-\theta}dx.
\]

定义真实 receiver 占用

\[
 S_{\rm act}(y)=a^{-n\theta}\int_\Omega
 d_R(x)P_y(x)^{1-\theta}\zeta_{\rm act}(x,y)^\theta dx. \tag{G4.2}
\]

所有这些量在固定节点下独立辅助 `t`。实际原 receiver/terminal/good 门限制左侧；用上面的静态上集及捕获，只作正上界，不创造新的 FIRST。

## G5. 保同一原 posterior 的 heavy-clock 接口

记 `x_M=n log(M/M0)`，`z=x_M−U`，`U≥0`，`h=g*exp(−U/n)`。`z≤0` 为空窗。原有效 heavy 时间包含于 `[τ,h]` 且满足

\[
 e_t>A_f(t/\tau)^n,\qquad
 A_f=\ell q a^n c^{-3n/2}. \tag{G5.1}
\]

对 `τ≤t≤h`，`w_t≤(g*/t)^n w_*`。固定 receiver 后，用 `δ≤k_v≤n`、另一槽总质量一和 Hölder 得

\[
 \begin{aligned}
 &\iint C_* Q(x,v)^\theta w_*^{-\theta}\delta_t(v,u)
                 d\Pi_t(v)d\Pi_t(u)\\
 &\quad\le n(g*/t)^{\theta n}
 \left[\frac1{e_t}\int_{Z_t}C_*^{1/\theta}Q(x,v)\nu(dv)\right]^\theta
 \le n(g*/t)^{\theta n}(q\zeta_{\rm act}/e_t)^\theta.
 \end{aligned} \tag{G5.2}
\]

在原 heavy 时间使用 G5.1，再将所得正 majorant 积到整个节点窗。乘真实 hard 来源与 `P_y^{1−θ}`，Tonelli 给

\[
 \boxed{\mathcal K_{jM}(y)\le
 \frac{C_0}{2\theta}\ell^{-\theta}c^{3\theta n/2}
 e^{\theta x_M}(1-e^{-2\theta z})S_{\rm act}(y).} \tag{G5.3}
\]

其 clock 积分正是
`n∫_τ^h (t/τ)^(−2θn)dt/t=(1−e^(−2θz))/(2θ)`。
`𝒦` 表示该 actual-soft 物理节点的原正交通上界，外层 `2Λe^4(K/3)^θ` 尚未乘入。只在实际 heavy 门内使用 floor；不把 floor 套给某个 subset 质量。无需 `e_t` 求导、持久来源、late 补费或任何删除负信用。

## G6. 双槽 FIRST 与 hard 核积分交换来源质量

这是本轮实际 receiver 付款。固定 `x` 后，来源 `β` 的 Hölder 与 G3.2 给

\[
 \begin{aligned}
 \int P_y(x)^{1-\theta}\zeta_{\rm act}(x,y)^\theta\beta(dy)
 &\le\left(\int P_y(x)\beta(dy)\right)^{1-\theta}
       \left(\int\zeta_{\rm act}(x,y)\beta(dy)\right)^\theta\\
 &\le q^{1-\theta}\|\beta\|^\theta.
 \end{aligned}
\]

`ζ` 可依 `y` 并含同一原 `Z_τ(y)`，不需要来源独立。再用 G4.1，得

\[
 \boxed{\int S_{\rm act}(y)\beta(dy)
 \le\frac{\|\nu\|}{C_0}
 \left(\frac{\|\beta\|}{q a^n}\right)^\theta.} \tag{G6.1}
\]

故 `ρβ=||β||/(qa^n)` 时，G5.3 的来源积分至多

\[
 \|\nu\|\,\frac1{2\theta}(\rho_\beta/\ell)^\theta
 c^{3\theta n/2}e^{\theta x_M}(1-e^{-2\theta z}). \tag{G6.2}
\]

`C0` 抵消。没有 `|Ω|` 余价，没有假设 `β=ν`，没有把不同节点 hard 核当成同一核。相较旧质量 majorant `||β||ρν^θ`，新质量项是 `||ν||ρβ^θ`，比例为 `(||ν||/||β||)^(1−θ)`；它利用真实嵌套 `ν≤β`，不是无条件交换两来源。

## G7. 同一节点的 QG 尾备选及菜单的准确位置

令 `N=ceil(π sqrt n)`、`B=eN`。R234 最近 posterior 角菜单对所有 affine factors 总权 `≤n` 给逐点 `H_s≤e∑_{r∈S_n}H_r`；前两腿总权 `n`、J 腿总权 `n(1−θ)`，均用同一菜单。此处将静态 capture 正放或保其合法 fixed-node 部分，才对每个固定 `r` 使用 R220/R224 的 fractional QG 列

\[
 F_r(y,v)\le\frac{\|\nu\|}{qM^n}.
\]

因此 adaptive actual-soft 列有此界的 `B=eN` 倍。没有在 `s(x)` 上直接调用固定参数 QG。

同一原 `Π_t` 的两个 score 是 iid，故

\[
 \iint(k_v-k_u)_+d\Pi_t^2
 =\int_0^n\Pi_t\{k>r\}\,[1-\Pi_t\{k>r\}]dr\le n/4.
\]

积分 clock，再积分 `β`，得到同一个 `𝒦` 的第二个界

\[
 \int\mathcal K_{jM}\,d\beta
 \le\|\nu\|\frac{B\rho_\beta}{4}
 c^{2n}e^{-x_M}(x_M-U)_+. \tag{G7.1}
\]

所以完整两价为

\[
 \boxed{\int\mathcal K_{jM}\,d\beta\le\|\nu\|
 \min\left\{\frac{(\rho_\beta/\ell)^\theta}{2\theta}
 c^{3\theta n/2}e^{\theta x_M}(1-e^{-2\theta z}),
 \frac{B\rho_\beta}{4}c^{2n}e^{-x_M}z\right\}.} \tag{G7.2}
\]

仅在 `z>0` 使用该式，其余为零。两个分支上界的是同一 actual-soft 节点交通；无需、也没有将 `Psharp` majorant 误套旧 QG。菜单费只在第二个分支，不是全式外费。

## G8. 全 j/M 求和：无 exterior N 的三次对数界

若 `||ν||=0` 则交通为零；若 `||β||=0` 则由嵌套也归零。否则固定本叶

\[
 R_0=1+\log_+\rho_\beta+\log_+K+\log B,\quad
 \theta=\frac1{2R_0},\quad T=2\log_+(B\rho_\beta).
\]

此选择在所有 receiver/node/time 之前冻结。记 `h_0=n log γ∈[log2,1]`，且 `log2≥2/3`。每个 `j` 的正规 `x_M` 为 `k h_0`，另至多一个截尾点；有限区间的端点重复不计。以下为正和上界，可扩展 `j≥0`。

**小 x≤T。** 节点数至多 `T/h0+2≤3R0`。又

\[
 \sum_{j\ge0}c^{3\theta n/2}
 =\frac1{1-e^{-3\theta h_0/2}}
 \le1+\frac2{3\theta h_0}\le3R_0.
\]

因 `T≤2(log B+log_+ρβ)`，

\[
 (K/3)^\theta\rho_\beta^\theta e^{\theta T}
 \le\exp\{\theta[\log_+K+3\log_+\rho_\beta+2\log B]\}
 \le e^{3/2}.
\]

用第一价、`ell^(−θ)≤1`、`1−exp(−2θz)≤1` 和 `1/(2θ)=R0`，小 `x` 全和至多

\[
 9e^{3/2}R_0^3\|\nu\|. \tag{G8.1}
\]

**大 x>T。** 对每个 `j`，正规尾从首个 `x0>T` 开始，写 `x0=T+s`、`0<s≤h0`，`q0=e^(−h0)≤1/2`，于是

\[
 \sum_{k\ge0}(x_0+kh_0)e^{-(x_0+kh_0)}
 =e^{-T-s}\left[\frac{T+s}{1-q_0}
 +\frac{h_0q_0}{(1-q_0)^2}\right]
 \le2(T+1)e^{-T}.
\]

最后一步用 `h0≤1` 和 `e^(−s)(T+s+1)≤T+1`。额外截尾点若大于 `T`，其 `x e^(−x)≤(T+1)e^(−T)`。故

\[
 \sum_{M:x_M>T}x_Me^{-x_M}\le3(T+1)e^{-T},\qquad
 \sum_{j\ge0}c^{2n}\le4/3.
\]

用第二价及 `z≤x_M`，`(K/3)^θ≤sqrt e`，`Bρβ e^(−T)≤1`，`T+1≤2R0`，得大 `x` 全和至多

\[
 2\sqrt e\,R_0\|\nu\|\le2\sqrt e\,R_0^3\|\nu\|. \tag{G8.2}
\]

这对所有 `U≥0` 一致；未用删除负项。每个腿/朝向的和已含 `(K/3)^θ`。

## G9. 原交通主结论与准确未付款范围

恢复原外因子 `2Λe^4`、三个腿和两个朝向，设

\[
 \widetilde D=9e^{3/2}+2\sqrt e.
\]

则原正 far 交通满足

\[
 \boxed{P_{\rm far}(U)\le12\Lambda e^4\widetilde D\,
 \mathbb E\sum_V\|\nu_V\|
 \left[1+\log_+\frac{\|\beta_V\|}{q_Va_V^n}
 +\log_+K+\log\big(e\lceil\pi\sqrt n\rceil\big)\right]^3.} \tag{G9.1}
\]

外数据的求和/期望仍是原数据，不换测度。此为所有实际尺度、所有实际 softness、全部 deficit、所有 `U≥0` 的原 far 分支；`U=0` 指该 far 分支的完整有效 clock，不含此前另分配的 near 或其它未付分支。若 `U≥n log(b/a)`，所有节点窗为空，交通为零。式 G9.1 无外乘 `N`、`sqrt n`、`C0`、`e^9` 或 entropy 的人工全局 penalty。

这是比只把 `Ω` 改名的占用量更强的付款：G6.1 已用原 hard 核和原两来源真正结清 receiver 积分，G8 已付所有 physical/j/soft-selector 费用。仍剩唯一明确的来源价

\[
 \mathbb E\sum_V\|\nu_V\|R_{0,V}^3.
\]

它不能免费由 `Wν`、`Wβ` 或 `||f||_1` 控制。特别 `ν=β` 时仍有来源对数矩；不声称一般输入终结。

作为明确已付范围，对任意原外资料子集若 `R0,V≤H_n`，其整个上述 far 交通≤`12Λe^4 Dtilde H_n³ Wν`；取 `H_n=n^(1/6)L_n` 得根阶 `sqrt n L_n³ Wν`。更一般只需该子集的 `||ν_V||R0,V³≤H_n³||β_V||`，便付同常数 `H_n³Wβ`。这些是本定理明确的付款范围，不是对所有来源免费授予的新假设。主成果本身是不要求这些限制的 G9.1。

## G10. 本机检查与证据范围

作者实际用本机 Python/mpmath、80 位精度运行了 35 个 G2 精确恒等式及 rounding 检查。核使用原一维 `h=1_[−1/2,1/2]` 和

\[
 \phi(x)=\begin{cases}
 1-E_3(1/2-x)-E_3(1/2+x),&|x|\le1/2,\\
 E_3(|x|-1/2)-E_3(|x|+1/2),&|x|>1/2,
 \end{cases}
\]

其中 `E3(t)=mpmath.expint(3,t)`，即原 `h*∫_0^1 exp(−|·|/r)dr`。坐标源位置周期为 `[0,.49,.7,2]`，目标位置周期为 `[.1,.5,1,4]`；每坐标两因子权分别 `1−θ,θ`。选点为 `idx=max(0,min(N−1,ceil(asin(sqrt(p))/Δ−.5)))`。

完整参数规则：先 `n=2`、`s∈{.01,.5,.99}`、`θ∈{.5,.1,.001}` 的 9 例；压力组 `n∈{16,64}`、`s∈{10^−30,1−10^−30}`、`θ∈{10^−6,.49}` 的 8 例；再扩展 `n∈{16,64}`、`s∈{.01,.5,.99}`、`θ∈{.5,.1,.001}` 的 18 例。每例核验 log 恒等式误差 `<10^−60`、`J≥−10^−65`、`mD(p||r)≤9`。实跑最大 log 误差 `1.72723371101889·10^−77`，最大 rounding cost `0.471819723962162`，全部通过。

这些是作者实际计算报告；严格证明是 G2 的代数推导。该检查不是 FULL 输入认证，也不拟合维数阶。独立 numeric 与 audit 的运行及其范围以本轮各自文件为准，本文不冒称已代其复跑。

本稿只依赖 R235 authoritative `proof.tex.txt`/`spatial_budget.md`、其已认证 R234 fractional physical/QG/最近角菜单和原 R117 FIRST/同构造来源资格。没有新的无证 tree/Schur 或负信用输入。
