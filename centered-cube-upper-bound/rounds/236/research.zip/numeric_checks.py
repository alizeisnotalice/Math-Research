#!/usr/bin/env python3
"""R236 bounded real one-dimensional L1 tool models; no FULL qualification.
Physical integration uses numpy float64 GL fed by independently 25/40dps
mpmath kernel evaluations. GL refinement is empirical, not interval error.
Posterior identities are separately evaluated at 40/70dps.
"""
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
import mpmath as mp
ROOT=Path(__file__).resolve().parent
C0=16/3
SOURCES=[(0.,.1,1.),(.75,.1,.5),(1.4,.1,.125)]
def phi(x):
 x=abs(mp.mpf(x));h=mp.mpf('.5')
 def E3(t):return h if not t else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
 return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def kl(p,q):
 if p==0:return -mp.log1p(-q)
 if p==1:return -mp.log(q)
 return p*mp.log(p/q)+(1-p)*mp.log((1-p)/(1-q))
def KLnp(p,q):
 p=np.clip(p,1e-300,1-1e-15)
 return p*np.log(p/q)+(1-p)*np.log((1-p)/(1-q))
def quad_nodes(lo,hi,order,breaks=()):
 z,w=np.polynomial.legendre.leggauss(order);pts=sorted(set([lo,hi]+[t for t in breaks if lo<t<hi]));xs=[];ws=[]
 for a,b in zip(pts,pts[1:]):xs.extend((a+b)/2+(b-a)*z/2);ws.extend(w*(b-a)/2)
 return np.array(xs),np.array(ws)
def density_nodes(x,components,order):
 xx=[];ww=[]
 for center,half,mass in components:
  t,w=quad_nodes(center-half,center+half,order,(x-.5,x+.5));xx.extend(t);ww.extend(w*mass/(2*half))
 return np.array(xx),np.array(ww)
CACHE={}
def kernel_table(extra,order,dps):
 key=(extra,order,dps)
 if key in CACHE:return CACHE[key]
 beta=SOURCES+([(2.,.15,2.)] if extra else []);breaks=[0.]
 for c,h,_ in SOURCES:
  breaks.extend([c-h-.5,c+h-.5,c-h+.5,c+h+.5])
 xs,xw=quad_nodes(-.25,.25,order,breaks);out=[]
 with mp.workdps(dps):
  for x,wx in zip(xs,xw):
   vs,vw=density_nodes(x,SOURCES,order);ys,yw=density_nodes(x,beta,order)
   def kernel(ds):return np.array([float(phi(str(t))) for t in ds]),(np.abs(ds)<=.5).astype(float)
   pv,hv=kernel(x-vs);py,hy=kernel(x-ys)
   hard=sum(m*max(0.,min(c+h,x+.5)-max(c-h,x-.5))/(2*h) for c,h,m in SOURCES)
   out.append((float(x),float(wx),vw,yw,pv,hv,py,hy,hard))
 CACHE[key]=out;return out

def physical(c,order,dps):
 theta=c['theta'];extra=c['extra_beta'];beta_mass=sum(v[2] for v in SOURCES)+(2 if extra else 0);nu_mass=sum(v[2] for v in SOURCES);q=2*beta_mass;N=math.ceil(math.pi);rs=np.sin((np.arange(N)+.5)*math.pi/(2*N))**2
 vals=dict(Xi_beta=0.,Xi_posterior_beta=0.,S0_beta=0.,Sact_beta=0.,dR_integral=0.);maxcap=0.;maxzeta=0.;maxmargin=-1.;maxdiff=0.
 for x,wx,vw,yw,pv,hv,py,hy,hard in kernel_table(extra,order,dps):
  s=c['s'] if c['s']!='split' else (.2 if x<0 else .8)
  fv=(1-s)*hv+s*pv;fy=(1-s)*hy+s*py;postv=s*pv/fv;posty=s*py/fy
  posterior=(1-theta)*posty[:,None]+theta*postv[None,:];j=np.clip(np.ceil(np.arcsin(np.sqrt(posterior))/(math.pi/(2*N))-.5).astype(int),0,N-1);r=rs[j]
  qr=(1-r)*hv[None,:]+r*pv[None,:];pr=(1-r)*hy[:,None]+r*py[:,None];D=KLnp(posterior,s)
  T0=np.exp(-D/theta)*qr
  xi=np.sum(pr**((1-theta)/theta)*T0*vw[None,:],axis=1)/q
  # Actual individual posterior relative entropy; total affine exponent m=1.
  prv=r*pv[None,:]/qr;pry=r*py[:,None]/pr
  # Continuous Bernoulli KL includes hard-core endpoint posterior1.
  def bd(p,z):
   with np.errstate(divide='ignore',invalid='ignore'):
    return np.where(p==1,-np.log(z),np.where(p==0,-np.log1p(-z),p*np.log(p/z)+(1-p)*np.log((1-p)/(1-z))))
  dp=(1-theta)*bd(posty[:,None],pry)+theta*bd(postv[None,:],prv)
  xip=np.sum(pr**((1-theta)/theta)*T0*np.exp(-dp/theta)*vw[None,:],axis=1)/q
  sharp=np.max((1-rs[:,None])*hy[None,:]+rs[:,None]*py[None,:],axis=0)
  s0=sharp**(1-theta)*(np.sum(T0*vw[None,:],axis=1)/q)**theta
  zeta=float(np.sum(fv*vw)/q);act=fy**(1-theta)*zeta**theta;dR=hard/(C0*q)
  vals['Xi_beta']+=wx*dR*float(np.sum(yw*xi**theta));vals['Xi_posterior_beta']+=wx*dR*float(np.sum(yw*xip**theta));vals['S0_beta']+=wx*dR*float(np.sum(yw*s0));vals['Sact_beta']+=wx*dR*float(np.sum(yw*act));vals['dR_integral']+=wx*dR
  maxcap=max(maxcap,float(2*np.sum(fy*yw)));maxzeta=max(maxzeta,zeta);maxmargin=max(maxmargin,s-rs[-1]);maxdiff=max(maxdiff,float(np.max(xip**theta-act)))
 bound=nu_mass/C0*(beta_mass/q)**theta
 assert maxcap<=q*(1+1e-12) and maxzeta<=1 and vals['Sact_beta']<=bound and vals['Xi_beta']<=vals['S0_beta']*(1+1e-12) and vals['Xi_posterior_beta']<=vals['Sact_beta']*(1+1e-12)
 vals.update(mass_exchange_bound=bound,Sact_over_bound=vals['Sact_beta']/bound,Xi_over_S0=vals['Xi_beta']/vals['S0_beta'],posterior_Xi_over_Sact=vals['Xi_posterior_beta']/vals['Sact_beta'],nu_mass=nu_mass,beta_mass=beta_mass,nu_over_beta=nu_mass/beta_mass,q=q,max_original_f_FIRST=maxcap,max_zeta=maxzeta,max_s_minus_lastnode=maxmargin,max_pointwise_posterior_minus_actual=maxdiff,n_theta=theta,n_Btheta_max=max(theta*t/(1-t)+math.log(1-t+t*math.exp(-theta/(1-t))) for t in ([.2,.8] if c['s']=='split' else [c['s']])) )
 return {k:format(v,'.16g') for k,v in vals.items()}

def identity(c,dps):
 with mp.workdps(dps):
  n=c['n'];theta=mp.mpf(c['theta']);s=mp.mpf(c['s']);J=c['J'];lam=[mp.mpf(n)/4,mp.mpf(n)/3,mp.mpf(n)*5/12];lam=[z*(1-theta) if J else z for z in lam];aa=list(map(mp.mpf,['1','0','.001']));bb=list(map(mp.mpf,['.02','1','3']));m=sum(lam);p0=[s*b/((1-s)*a+s*b) for a,b in zip(aa,bb)];p=sum(w*z for w,z in zip(lam,p0))/m;N=int(mp.ceil(mp.pi*mp.sqrt(n)));j=max(0,min(N-1,int(mp.ceil(mp.asin(mp.sqrt(p))/(mp.pi/(2*N))-.5))));r=mp.sin((j+mp.mpf('.5'))*mp.pi/(2*N))**2
  logH=lambda t:sum(w*mp.log((1-t)*a+t*b) for w,a,b in zip(lam,aa,bb));pr=[r*b/((1-r)*a+r*b) for a,b in zip(aa,bb)];dp=sum(w*kl(z,t) for w,z,t in zip(lam,p0,pr));left=logH(r)-m*kl(p,s)-dp;right=logH(s)-m*kl(p,r);err=abs(left-right);assert err<mp.mpf(10)**(-dps+8) and m*kl(p,r)<=9
  return {k:mp.nstr(v,32) for k,v in dict(m=m,p=p,r=r,Dpost=dp,identity_log_residual=err,grid_KL=m*kl(p,r),log_Hs=logH(s),n_theta=n*theta).items()}

def main(output):
 menus=[dict(stage=stage,s=s,theta=t,extra_beta=e) for stage,s,t in [('initial',1/3,.1),('initial',1/3,.5),('stress',.8,.01),('stress',.8,.1),('expanded','split',.01),('expanded','split',.1)] for e in (False,True)]
 rows=[]
 for c in menus:
  low=physical(c,8,25);high=physical(c,12,40);err=max(abs(float(low[k])-float(high[k])) for k in ['Xi_beta','Xi_posterior_beta','S0_beta','Sact_beta']);row=dict(configuration=c,GL8_mp25=low,GL12_mp40=high,absolute_refinement_difference=format(err,'.8g'))
  if c['theta']==.01:
   refined=physical(c,24,50);row['GL24_mp50']=refined;row['absolute_GL12_GL24_difference']=format(max(abs(float(high[k])-float(refined[k])) for k in ['Xi_beta','Xi_posterior_beta','S0_beta','Sact_beta']),'.8g')
  rows.append(row)
 ids=[]
 for stage,n in [('initial',2),('stress',16),('expanded',512)]:
  for J in (False,True):
   for s,t in [('.25','.1'),('.95','.01')]:
    c=dict(stage=stage,n=n,J=J,s=s,theta=t);a=identity(c,40);b=identity(c,70);ids.append(dict(configuration=c,mp40=a,mp70=b))
 payload=dict(scope='Finite real n=1 L1 receiver/source integration tools and general-n algebra identities; not FULL/history/original main dimension qualification.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_components=SOURCES,beta_extra_component=[2.,.15,2.],Omega=[-.25,.25],a_L_A=1,C_capture=1,C0='16/3',q_rule='2 beta mass, fixed all x and all s: density kernel <=1, f=2beta',physical_quadrature='Float64 tensor GL8/12 with hard-boundary splitting and independent mpmath25/40 kernel evaluations; noninterval refinement. No infinite integration tails: sources and receivers compact.',physical_rows=rows,posterior_identities=ids,counts=dict(physical_models=len(rows),posterior_identities=len(ids)),definitions={'Xi_beta':'integral beta(dy) integral_Omega d_R [q^-1 integral_nu P_selected(x-y)^((1-theta)/theta) T0_selected(x,v) dnu(v)]^theta dx','T0':'exp(-KL(p||s)/theta) P_selected(x-v), selected one-sided grid, physical m=n=1','Xi_posterior_beta':'same Xi, multiplying T0 by exp(-Dpost/theta); exact affine identity implies <= Sact pointwise','S0_beta':'same raw T0 with selected receiver P replaced by Psharp; R235-style comparator but raw target normalization','Sact_beta':'integral_Omega d_R (q^-1 integral P_s(x-v)dnu)^theta integral P_s(x-y)^(1-theta) dbeta(y) dx','dimensions':'Physical models n=1 explicitly permitted low-dimensional tools; independent identities n=2,16,512 for moving total m=n and J total m=n(1-theta)'})
 contract=ROOT/'task_contract.md'
 if contract.exists():payload['contract_sha256']=hashlib.sha256(contract.read_bytes()).hexdigest()
 Path(output).write_text(json.dumps(payload,indent=2,sort_keys=True,allow_nan=False)+'\n');print(payload['counts'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',default=str(ROOT/'numeric_checks.json'));main(p.parse_args().output)
