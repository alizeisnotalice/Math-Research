#!/usr/bin/env python3
"""Frozen-package verification and relocated full numerical replay; no PDF."""
import argparse,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    hashes=json.loads((ROOT/'manifest.json').read_text())
    for name,h in hashes.items():assert digest(ROOT/name)==h,name
    return len(hashes)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--output-dir',type=Path);args=ap.parse_args();count=verify()
    if args.verify_only:print('verified',count,'manifest hashes');return
    if args.output_dir is None:ap.error('--output-dir required')
    out=args.output_dir.resolve()
    if out==ROOT or ROOT in out.parents:ap.error('output must be outside package')
    env=os.environ.copy()
    out.mkdir(parents=True,exist_ok=False);runs=[]
    shutil.copyfile(ROOT/'task_contract.md',out/'task_contract.md')
    for stem in ('numeric_checks','scale_checks'):
        shutil.copyfile(ROOT/(stem+'.py'),out/(stem+'.py'))
        start=time.monotonic();cmd=[sys.executable,str(out/(stem+'.py'))]
        if stem=='numeric_checks':cmd += ['--output',str(out/(stem+'.json'))]
        subprocess.run(cmd,env=env,check=True)
        assert (out/(stem+'.json')).read_bytes()==(ROOT/(stem+'.json')).read_bytes(),stem+' entire JSON differs'
        runs.append({'driver':stem+'.py','entire_json_byte_identical':True,'json_sha256':digest(out/(stem+'.json')),'elapsed_seconds':time.monotonic()-start})
    embedded=(ROOT/'two_slot.md').read_text().split('```python\n',1)[1].split('```',1)[0]
    embedded_path=out/'two_slot_checks.py';embedded_path.write_text(embedded)
    expected=(ROOT/'two_slot.md').read_text().split('```text\n',1)[1].split('```',1)[0].strip()
    result=subprocess.run([sys.executable,str(embedded_path)],env=env,check=True,text=True,capture_output=True)
    assert result.stdout.strip()==expected,'embedded two-slot diagnostic output differs'
    runs.append({'driver':'two_slot.md embedded code','reported_output_exact_match':True,'checks':120})
    assert verify()==count
    receipt={'complete_replay':True,'manifest_hashes_before_and_after':count,'runs':runs,'python':sys.executable,'scope':'Finite affine posterior identities, true one-dimensional Lebesgue integrals, and finite physical-node sum arithmetic; ordinary float/high precision, not interval certification or FULL source/history payment. Requires the recorded local math-library versions for byte-identical replay.'}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
