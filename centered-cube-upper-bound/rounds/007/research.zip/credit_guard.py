from fractions import Fraction as F
from itertools import product
from functools import lru_cache
from collections import defaultdict
import json
# Expressions use 0 for rational constants, primes for coefficients of log(prime).
def add(dst,src,c=F(1)):
 for k,v in src.items():
  dst[k]=dst.get(k,F(0))+c*v
  if not dst[k]:del dst[k]
@lru_cache(None)
def factor(k):
 out={};d=2
 while d*d<=k:
  while k%d==0:out[d]=out.get(d,0)+1;k//=d
  d+=1
 if k>1:out[k]=out.get(k,0)+1
 return out
@lru_cache(None)
def logexpr(x):
 out={}
 for p,v in factor(x.numerator).items():out[p]=F(v)
 for p,v in factor(x.denominator).items():out[p]=out.get(p,F(0))-v
 return {p:v for p,v in out.items() if v}
@lru_cache(None)
def phi(h,tau):return {} if h<=tau else {p:tau*v for p,v in logexpr(h/tau).items()}
@lru_cache(None)
def kernel(B,A,p,tau):
 if A==0:return {},F(0)
 q=1-p;mean=B+p*A;upper=B+A;out={}
 l=max(tau,B);r=mean
 if r>l:
  add(out,logexpr(r/l),tau*q)
  add(out,{0:B/r-B/l},tau*q)
 l=max(tau,mean);r=upper
 if r>l:
  add(out,logexpr(r/l),-tau*p)
  add(out,{0:upper/l-upper/r},tau*p)
 k=F(0)
 if B<tau<upper:k=q*(tau-B) if tau<=mean else p*(upper-tau)
 return out,k
@lru_cache(None)
def prime_interval(p):
 x=F(p);k=0
 while x>=2:x/=2;k+=1
 def s(v):
  z=(v-1)/(v+1);a=sum((2*z**(2*j+1)/(2*j+1) for j in range(40)),F(0))
  return a,a+2*z**81/(81*(1-z*z))
 a,b=s(x);c,d=s(F(2));a+=k*c;b+=k*d;unit=2**96
 return F(a.numerator*unit//a.denominator,unit),F(-((-b.numerator*unit)//b.denominator),unit)
def output(e):
 lo=hi=e.get(0,F(0))
 for p,v in e.items():
  if p==0:continue
  a,b=prime_interval(p);lo+=v*(a if v>0 else b);hi+=v*(b if v>0 else a)
 return {'constant':str(e.get(0,F(0))),'prime_log_coefficients':{str(p):str(v) for p,v in sorted(e.items()) if p},'interval':[str(lo),str(hi)],'display':[float(lo),float(hi)]}
rows=[]
for n in [1,2,3]:
 points=list(product([F(-1,4),F(1,4)],repeat=n));N=len(points);scales=[F(1),F(3,2),F(2)]
 cuts=sorted({y[0]+sign*L/2 for y in points for L in scales for sign in [-1,1]})
 patterns=defaultdict(F);cells=0
 for ids in product(range(len(cuts)-1),repeat=n):
  x=[(cuts[j]+cuts[j+1])/2 for j in ids];volume=F(1)
  for j in ids:volume*=cuts[j+1]-cuts[j]
  masks=tuple(tuple(i for i,y in enumerate(points) if all(abs(xx-yy)<L/2 for xx,yy in zip(x,y))) for L in scales)
  patterns[masks]+=volume;cells+=1
 assert sum(patterns.values())==F(5,2)**n
 patterns=list(patterns.items());ops=[]
 def build(ids):
  if len(ids)==1:return
  mid=len(ids)//2;left=ids[:mid];right=ids[mid:];build(left);build(right);ops.append((left,right))
 build(list(range(N)))
 @lru_cache(None)
 def response(state,masks,policy="first"):
  vals=tuple(F(sum(state[i] for i in mask),N)/L**n for mask,L in zip(masks,scales))
  H=max(vals);idx=vals.index(H) if policy=="first" else max(j for j,v in enumerate(vals) if v==H);return H,idx,vals
 def functional(state,tau):
  out={}
  for masks,vol in patterns:
   H,_,_=response(state,masks);add(out,phi(H,tau),vol)
  return out
 for tau,policy in product([F(1,2),F(1,8),F(1,32)],["first","last"]):
  start=(1,)*N;states={start:F(1)};V={};T={};J={};entropy={};checks=0;transitions=0;peak=1
  for left,right in ops:
   nxt=defaultdict(F)
   for state,prob in states.items():
    il=[i for i in left if state[i]];ir=[i for i in right if state[i]];assert len(il)==len(ir)==1
    i,j=il[0],ir[0];u=state[i];v=state[j];p=F(u,u+v);q=1-p;m=F(u+v,N)
    sy=list(state);sy[i]+=v;sy[j]=0;sy=tuple(sy)
    sz=list(state);sz[j]+=u;sz[i]=0;sz=tuple(sz)
    nxt[sy]+=prob*p;nxt[sz]+=prob*q;transitions+=1
    add(entropy,logexpr(p),-prob*m*p);add(entropy,logexpr(q),-prob*m*q)
    for masks,vol in patterns:
     H,idx,vals=response(state,masks,policy);Hy,_,vy=response(sy,masks,policy);Hz,_,vz=response(sz,masks,policy)
     fy,fz=vy[idx],vz[idx];assert p*fy+q*fz==H and Hy>=fy and Hz>=fz
     B=min(fy,fz);A=abs(fy-fz);ph=p if fy>=fz else q
     vv,tt=kernel(B,A,ph,tau)
     frozen={};add(frozen,phi(H,tau));add(frozen,phi(fy,tau),-p);add(frozen,phi(fz,tau),-q)
     residual=dict(vv);add(residual,{0:-tt});add(residual,frozen,-1);assert not residual
     gain={};add(gain,phi(Hy,tau),p);add(gain,phi(Hz,tau),q);add(gain,phi(fy,tau),-p);add(gain,phi(fz,tau),-q)
     add(V,vv,prob*vol);add(T,{0:tt},prob*vol);add(J,gain,prob*vol);checks+=1
   states=dict(nxt);assert sum(states.values())==1;peak=max(peak,len(states))
  assert len(states)==N
  for state,prob in states.items():assert sum(state)==N and max(state)==N and prob==F(1,N)
  initial=functional(start,tau);terminal={}
  for state,prob in states.items():add(terminal,functional(state,tau),prob)
  deficit=dict(initial);add(deficit,terminal,-1)
  budget=dict(V);add(budget,T,-1);add(budget,J,-1)
  assert deficit==budget
  assert entropy=={2:F(n)}
  rows.append({'n':n,'N':N,'tau':str(tau),'winner_tie_policy':policy,'full_cells':cells,'compressed_capture_patterns':len(patterns),'state_transitions':transitions,'maximum_live_states':peak,'exact_local_identities':checks,'initial':output(initial),'terminal':output(terminal),'curvature_fee_V':output(V),'threshold_credit_T':output(T),'winner_reselection_credit_J':output(J),'actual_deficit':output(deficit),'entropy_certificate':output(entropy),'exact_global_identity':True})
endpoint_rows=[]
for A in [F(1),F(3,2),F(8)]:
 count=0;breakpoints=0
 for B in [F(0),F(1,4),F(1)]:
  for p in [F(1,8),F(1,2),F(7,8)]:
   mean=B+p*A;upper=B+A
   candidates={B,mean,upper,(B+mean)/2,(mean+upper)/2,upper+1}
   if B:candidates.add(B/2)
   for tau in sorted(candidates):
    if tau<=0:continue
    v,t=kernel(B,A,p,tau)
    f={};add(f,phi(mean,tau));add(f,phi(upper,tau),-p);add(f,phi(B,tau),-(1-p))
    e=dict(v);add(e,{0:-t});add(e,f,-1);assert not e
    count+=1;breakpoints+=tau in [B,mean,upper]
 endpoint_rows.append({'A':str(A),'exact_identities':count,'exact_breakpoint_cases':breakpoints})
entropy_rows=[]
for n in [1,4,8]:
 N=2**n
 for policy in ['balanced','sequential','largest_first']:
  masses=[1]*N;cost={};steps=0
  while len(masses)>1:
   if policy=='balanced':masses.sort()
   if policy=='largest_first':masses.sort(reverse=True)
   u=masses.pop(0);v=masses.pop(0);m=u+v;p=F(u,m);q=1-p
   assert p>=F(1,N) and q>=F(1,N)
   add(cost,logexpr(p),-F(m,N)*p);add(cost,logexpr(q),-F(m,N)*q)
   if policy=='sequential':masses.insert(0,m)
   else:masses.append(m)
   steps+=1
  assert cost=={2:F(n)} and masses==[N]
  entropy_rows.append({'n':n,'N':N,'policy':policy,'merges':steps,'exact_cost_n_log2':True})
print(json.dumps({'status':'PASS','scope':'Complete Lebesgue cell integration for finite J={1,3/2,2}; every history of the specified balanced physical rounding tree; not continuous-scale integration or an asymptotic bound','bits':96,'atanh_terms':40,'rounds':rows,'threshold_endpoint_rounds':endpoint_rows,'entropy_tree_rounds':entropy_rows},indent=2))
