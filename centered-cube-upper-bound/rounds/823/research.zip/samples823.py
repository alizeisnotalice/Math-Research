"""Four-dimensional R814 q95 sample: receiver-box interval certificates.

Reference law = exact original bilateral row weight conditioned on q=95,
t=t0,g=u1. Receivers are independently uniform in the actual owner boxes,
as in the explicit R814 receiver model, not an inferred original joint law.
Shared-z and iid records have identical one-draw marginals. Owner-box
extremes give exact enclosures, not exact integrals of the receiver function.
"""

import argparse, json, zipfile
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations_with_replacement
from math import factorial, prod


def extreme_ranges(boxes, m):
    if m == 1:
        return [F(0)] * 4, [F(0)] * 4
    low = []
    high = []
    for axis in range(4):
        spans = [box[axis] for box in boxes]
        low.append(max(F(0), max(a for a, b in spans) - min(b for a, b in spans)))
        high.append(max(b for a, b in spans) - min(a for a, b in spans))
    return low, high


def observables(boxes, m, T, s):
    low, high = extreme_ranges(boxes, m)
    expansion_lo = prod(1 + x / T for x in low)
    expansion_hi = prod(1 + x / T for x in high)
    overlap_lo = prod(max(F(0), 1 - x / s) for x in high)
    overlap_hi = prod(max(F(0), 1 - x / s) for x in low)
    return expansion_lo, expansion_hi, overlap_lo, overlap_hi


def evaluate(owner_weights, owner_boxes, m, T, s):
    ids = sorted(owner_weights)
    total = sum(owner_weights.values(), F(0))
    assert total > 0
    probs = {i: owner_weights[i] / total for i in ids}
    answer = [F(0)] * 4
    sumprob = F(0)
    # Multiset weights equal the sum over all ordered iid record tuples.
    for samples in combinations_with_replacement(ids, m):
        mult = F(factorial(m))
        for owner in ids:
            mult /= factorial(samples.count(owner))
        prob = mult * prod(probs[x] for x in samples)
        values = observables([owner_boxes[x] for x in samples], m, T, s)
        for j in range(4):
            answer[j] += prob * values[j]
        sumprob += prob
    assert sumprob == 1
    assert answer[0] <= answer[1] and answer[2] <= answer[3]
    return answer


def run(name, stage, saved):
    assert stage["dimension"] == 4 and saved["q_mask"] == 95
    parents = {p["id"]: p for p in stage["parents"]}
    mass = {c["mask"]: F(c["mass"]) for c in stage["cells"]}
    # All 230 actual two-source cell records across the cross-bin roots.
    assert (
        sum(len(r["z_masks"]) * len(r["q_masks"]) for r in stage["roots_cross"]) == 230
    )
    rebuilt = defaultdict(F)
    for root in stage["roots_cross"]:
        if 95 in root["q_masks"]:
            for z in root["z_masks"]:
                rebuilt[root["t"], root["u"], root["g"], z] += (
                    F(root["coefficient"]) * mass[z] * mass[95]
                )
    archived = {
        (r["t"], r["left_parent"], r["right_parent"], r["z_mask"]): F(r["weight"])
        for r in saved["rows"]
    }
    assert dict(rebuilt) == archived and len(archived) == 58
    # Fixed actual q-cell, actual middle t and actual right parent g.
    subset = [r for r in saved["rows"] if r["t"] == "t0" and r["right_parent"] == "u1"]
    assert len(subset) == 11
    owners = sorted({r["left_parent"] for r in subset})
    assert len(owners) >= 2
    by_z = defaultdict(lambda: defaultdict(F))
    marginal = defaultdict(F)
    for r in subset:
        w = F(r["weight"])
        by_z[r["z_mask"]][r["left_parent"]] += w
        marginal[r["left_parent"]] += w
    M = sum(marginal.values(), F(0))
    assert M == sum((sum(v.values(), F(0)) for v in by_z.values()), F(0))
    boxes = {u: [tuple(map(F, span)) for span in parents[u]["owner"]] for u in owners}
    T = max(2 * F(parents[u]["radius"]) for u in owners)
    s = 2 * F(parents["t0"]["radius"])
    print(
        "\nFIXTURE",
        name,
        "n=4",
        "cross_cell_records=230",
        "q95_records=58",
        "condition=(q95,t0,u1)",
        "selected=",
        len(subset),
        "distinct owners=",
        owners,
        "distinct z cells=",
        len(by_z),
    )
    print(
        "conditional original mass=",
        M,
        "reference q source mass=",
        mass[95],
        "original t0 full_d=",
        parents["t0"]["full_d"],
    )
    print(
        "physical side T=max(left actual cube sides)=",
        T,
        "central side s=",
        s,
        "owner volumes=",
        {u: parents[u]["owner_volume"] for u in owners},
    )
    print(
        "model: sample z,u by original positive row weights; then U uniform on actual E_u; iid vs draw z once and sample u conditionally"
    )
    print("individual owner probabilities=", {u: str(marginal[u] / M) for u in owners})
    for m in (1, 2, 4, 8):
        independent = evaluate(marginal, boxes, m, T, s)
        shared = [F(0)] * 4
        for z, weights in by_z.items():
            p = sum(weights.values(), F(0)) / M
            vals = evaluate(weights, boxes, m, T, s)
            for j in range(4):
                shared[j] += p * vals[j]
        if m == 1:
            assert independent == shared and independent == [1, 1, 1, 1]
        for label, values in [("independent", independent), ("same_z", shared)]:
            print(
                "m=",
                m,
                "coupling=",
                label,
                "box_expansion_bounds~=",
                float(values[0]),
                float(values[1]),
                "translated_central_cube_intersection_bounds~=",
                float(values[2]),
                float(values[3]),
            )
            print("  exact bounds=", *[str(v) for v in values])
    print(
        "scope: two physical scales T,s; no q-specific long-jump assumption, n=4 R813 high-dimensional gate empty"
    )


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True, help="R814 research.zip")
args = parser.parse_args()
with zipfile.ZipFile(args.archive) as z:
    saved = json.loads(z.read("cell814.json"))
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    ns = {"__name__": "archived_comb811"}
    exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
    name, n, h, middle, old = ns["FIXTURES"][-1]
    original = ns["fixture"](name, n, h, middle, old)
    run("original", original, saved["original"])
    run("rebuilt", rebuilt, saved["rebuilt"])
print(
    "\nPASS: exact rational endpoint enclosures with original record weights, not a claimed original joint receiver law"
)
