"""Finite R814 real-record coordinate-interval protocol diagnostics.

Source q is integrated against actual product-comb mu on its entire membership
cell by axis-mask dynamic programming, never replaced by its representative.
The observed T,U probe law is the R814 explicit independent-uniform owner-box
model; it is not claimed as an unconditional original-history joint law.
"""

import argparse, json, zipfile
from collections import defaultdict
from fractions import Fraction as F
from itertools import product


def lt_probability(a, b, c, d):
    """P(T<=U) for independent uniforms T in [a,b], U in [c,d]."""

    def pos2(v):
        return max(v, F(0)) ** 2

    value = (pos2(d - a) - pos2(d - b) - pos2(c - a) + pos2(c - b)) / (
        2 * (b - a) * (d - c)
    )
    assert 0 <= value <= 1
    return value


def bounds_by_mask(parents):
    boxes = [[tuple(map(F, axis)) for axis in p["box"]] for p in parents]
    axes = []
    for j in range(4):
        faces = sorted({F(-8), F(8), *(v for box in boxes for v in box[j])})
        seg = []
        for a, b in zip(faces, faces[1:]):
            m = (a + b) / 2
            bits = sum(
                p["bit"] for p, box in zip(parents, boxes) if box[j][0] < m < box[j][1]
            )
            seg.append((a, b, bits))
        axes.append(seg)
    bounds = {}
    for pieces in product(*axes):
        mask = pieces[0][2] & pieces[1][2] & pieces[2][2] & pieces[3][2]
        if not mask:
            continue
        if mask not in bounds:
            bounds[mask] = [[p[0], p[1]] for p in pieces]
        else:
            for j, p in enumerate(pieces):
                bounds[mask][j][0] = min(bounds[mask][j][0], p[0])
                bounds[mask][j][1] = max(bounds[mask][j][1], p[1])
    return bounds


def axis_options(stage, parents, t, u, j, which, ref, previous, wide, interval_mass):
    """Joint axis source-mu, test failure, next probe-order state."""
    tbox = [tuple(map(F, x)) for x in t["box"]]
    ubox = [tuple(map(F, x)) for x in u["box"]]
    owners = [tuple(map(F, x)) for x in t["owner"]]
    owneru = [tuple(map(F, x)) for x in u["owner"]]
    prob = lt_probability(*owners[j], *owneru[j])
    R = F(1, 4)
    faces = {F(-8), F(8)}
    for p in parents:
        for v in p["box"][j]:
            v = F(v)
            faces.add(v)
            if which == "dynamic":
                faces.add(v - R)
    faces = sorted(v for v in faces if -8 <= v <= 8)
    result = defaultdict(F)
    for a, b in zip(faces, faces[1:]):
        q = (a + b) / 2
        bits = 0
        for p in parents:
            lo, hi = map(F, p["box"][j])
            if lo < q < hi:
                bits += p["bit"]
        if which == "point":
            l = r = q
        elif which == "reference":
            l, r = min(q, ref), max(q, ref)
        elif which == "dynamic":
            l = r = q + (R if previous else 0)
        else:
            raise ValueError(which)
        success = (
            tbox[j][0] <= l and r <= tbox[j][1] and l <= ubox[j][1] and r >= ubox[j][0]
        )
        w = interval_mass(a, b, wide)
        if w:
            result[bits, int(not success), 0] += w * prob
            result[bits, int(not success), 1] += w * (1 - prob)
    return result


def source_distribution(stage, parents, t, u, qmask, which, order, refs, ns):
    allbits = (1 << len(parents)) - 1
    wide = F(stage["density"]["bump_half_width"])
    # state previous=0 means either first coordinate, or last T<=U.
    dp = {(allbits, 0, 0): F(1)}
    for axis in order:
        opts = {
            prev: axis_options(
                stage,
                parents,
                t,
                u,
                axis,
                which,
                refs[axis],
                prev,
                wide,
                ns["interval_mass"],
            )
            for prev in (0, 1)
        }
        new = defaultdict(F)
        for (mask, fail, previous), mass in dp.items():
            for (bits, bad, next_state), w in opts[previous].items():
                new[mask & bits, min(2, fail + bad), next_state] += mass * w
        dp = new
    return [
        sum((v for (mask, f, state), v in dp.items() if mask == qmask and f == i), F(0))
        for i in range(3)
    ]


def run(label, stage, ns):
    assert stage["dimension"] == 4
    parents = stage["parents"]
    lookup = {p["id"]: p for p in parents}
    masses = {c["mask"]: F(c["mass"]) for c in stage["cells"]}
    bounds = bounds_by_mask(parents)
    assert all(mask in bounds for mask in masses if mask)
    rows = defaultdict(F)
    count = 0
    for root in stage["roots_cross"]:
        t, u, g = (root[x] for x in ("t", "u", "g"))
        for z, q in product(root["z_masks"], root["q_masks"]):
            weight = F(root["coefficient"]) * masses[z] * masses[q]
            rows[t, u, q] += weight
            count += 1
    total = sum(rows.values(), F(0))
    assert count == 230 and total == F(stage["benchmarks"]["cross"]["mother"])
    print(
        "\nFIXTURE",
        label,
        "n=4 real (t,u,g,z,q) records=",
        count,
        "unique (t,u,q)=",
        len(rows),
        "total=",
        total,
    )
    for which in ("point", "reference", "dynamic"):
        for order in ((0, 1, 2, 3), (3, 2, 1, 0)):
            groups = defaultdict(lambda: [F(0), F(0), F(0)])
            overall = [F(0)] * 3
            for (t, u, q), weight in rows.items():
                refs = [(lo + hi) / 2 for lo, hi in bounds[q]]
                dist = source_distribution(
                    stage, parents, lookup[t], lookup[u], q, which, order, refs, ns
                )
                assert sum(dist, F(0)) == masses[q]
                group = (q, str(lookup[t]["volume_bin"]), str(lookup[u]["volume_bin"]))
                for i in range(3):
                    amount = weight * dist[i] / masses[q]
                    groups[group][i] += amount
                    overall[i] += amount
            assert sum(overall, F(0)) == total
            print(
                "protocol=",
                which,
                "order=",
                tuple(x + 1 for x in order),
                "0,1,2plus failures=",
                *[float(v / total) for v in overall],
                "zero covered=",
                float(overall[0] / total),
                "at_most_one covered=",
                float((overall[0] + overall[1]) / total)
            )
            print("  exact normalized=", *[str(v / total) for v in overall])
            # Report largest actual conditional (q,central-bin,left-bin) group.
            key = max(groups, key=lambda k: sum(groups[k], F(0)))
            weights = groups[key]
            M = sum(weights, F(0))
            assert M > 0
            print(
                "  largest q,tbin,ubin=",
                key,
                "group raw mass=",
                M,
                "group fail fractions=",
                *[float(v / M) for v in weights]
            )
    print(
        "READING point=q_j; reference=[q_j, midpoint of global q-cell coordinate bounds] uses only q-cell; dynamic on coordinate j uses only q and comparison T,U from the immediately preceding visited coordinate; no z read"
    )
    print(
        "SOURCE q distributed as actual mu conditioned on membership mask; owner probes independent uniform on actual E_t,E_u only under explicit R814 model. n=4 high-dimensional long-jump gate empty."
    )


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True)
args = parser.parse_args()
with zipfile.ZipFile(args.archive) as z:
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    ns = {"__name__": "archived_comb811"}
    exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
    name, n, h, middle, old = ns["FIXTURES"][-1]
    original = ns["fixture"](name, n, h, middle, old)
    run("original", original, ns)
    run("rebuilt", rebuilt, ns)
print("\nPASS exact rational q-cell integration under stated probe model")
