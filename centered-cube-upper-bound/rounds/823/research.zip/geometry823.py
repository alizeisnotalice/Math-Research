"""Exact sectional areas, reference one-coordinate moments and asymptotic prices."""
from fractions import Fraction as F
from itertools import product
from math import prod
from flint import arb, ctx


def fixed_success(t, u, width):
    return max(0,t-width)*(u+width)


def price_trials():
    cases = 0
    for t in (F(1),F(3,2),F(2)):
        for den in (8,17):
            for j in range((den+1)//2,den+1):
                u = t*F(j,den)
                star = (t-u)/2
                bound = (t+u)**2/4
                assert fixed_success(t,u,star)==bound
                widths = [t*k/32 for k in range(40)] + [star]
                for w in widths:
                    assert fixed_success(t,u,w)<=bound
                    if w<=t:
                        assert bound-fixed_success(t,u,w)==(w-star)**2
                    cases += 1
    print("exact sectional area tests",cases)


def interval_cut(lo,hi):
    # Split an interval at zero, to feed sign of the preceding true coordinate.
    return [max(F(0),min(hi,0)-lo), max(F(0),hi-max(lo,0))]


def sequential_trial(n,t,u):
    # q=0 and the returned candidate intervals all contain q.
    # Recursion uses only the preceding signs of the actual probes.
    star = (t-u)/2
    def integrate(depth, state):
        if depth==n:
            return F(1)
        lo,hi = ((-star/3,2*star/3) if state==0 else (-t/4,t/4))
        central = interval_cut(hi-t/2,lo+t/2)
        left = interval_cut(lo-u/2,hi+u/2)
        return sum(central[a]*left[b]*integrate(depth+1,int(a==b))
                   for a,b in product(range(2),repeat=2))
    actual = integrate(0,0)
    upper = ((t+u)**2/4)**n
    assert 0 < actual <= upper
    oracle = (t*(t+u))**n
    assert oracle > upper
    print("causal exact n",n,"area",actual,"product cap",upper,
          "area if both present coordinates disclosed",oracle)


def excess_integral(w,win,a,delta):
    # Positive-side hinge on [-w/2,w/2] translated by delta. Left and
    # right tails are integrated independently from endpoints.
    threshold = win/2+a
    points = sorted({-w/2,w/2} | {x for x in (-delta-threshold,-delta+threshold)
                                    if -w/2 < x < w/2})
    probability = mean = F(0)
    for x,y in zip(points,points[1:]):
        hinge = lambda z:max(F(0),abs(delta+z)-threshold)
        if hinge((x+y)/2)>0:
            probability += (y-x)/w
            mean += (y-x)*(hinge(x)+hinge(y))/(2*w)
    return probability,mean


def triangle_trials():
    total = 0
    for w in (F(2),F(3),F(4),F(7)):
        for gap in (F(1,128),F(1,32)):
            for a in (2*gap,3*gap,F(1,2)):
                for d in [-4,-2,-a,-a/2,0,a/2,a,2*a,2,4]:
                    d = F(d)
                    p,ex = excess_integral(w,w-2*gap,a,d)
                    v=max(F(0),abs(d)+gap-a)
                    assert p == min(v/w,F(1))
                    assert ex == (v*v-max(F(0),v-w)**2)/(2*w)
                    assert p <= max(F(0),abs(d)-a/2)/2
                    assert ex <= max(F(0),abs(d)-a/2)**2/4
                    total += 1
    print("exact triangular moment checks",total)


def asymptotic():
    old = {}
    for precision in (256,384):
        ctx.prec = precision
        for decade in (64,96,160,240):
            n = arb(10)**decade
            logn = (n+2).log()
            jump = n.sqrt() * logn**8
            depth = jump/(1024*(1+(n/jump).log()))
            drop = (-(jump-arb(2).log())/n).expm1()
            logarea = 2*n*(drop/2).log1p()
            assert logarea < -jump/2
            logmult = depth*((8*n/depth).log()+1)
            assert logmult < jump/32 and jump/n<arb(1)/4
            s = jump**2/(512*n)
            old_b0_upper = n.sqrt()*logn/(16*65536) + 1
            assert depth>100*old_b0_upper and s/8192>100*logn
            vals = (jump/n,depth/old_b0_upper,s/8192/logn,logarea/jump)
            if decade in old:
                assert all(a.overlaps(b) for a,b in zip(vals,old[decade]))
            old[decade]=vals
            print("Arb",precision,"n=10^",decade,"J/n,b_raw/b0_upper,s/(8192 ell),logarea/J",
                  *(v.str(11) for v in vals))
    print("functional root prices certified on four specified dimensions")


def actual_price_classes():
    # Scalar price strata only. These do not assert an original record exists.
    for precision in (256,384):
        ctx.prec = precision
        for power in (96,160,240):
            n = arb(10)**power
            jmin = n.sqrt()*(n+2).log()**8
            for theta in (arb(1)/16, arb(1)/2, arb(255)/256, 1/n.sqrt().sqrt()):
                actual = n*theta.log1p()
                p = jmin
                level = 0
                while 2*p <= actual:
                    p *= 2
                    level += 1
                assert p < actual < 2*p and p >= n*theta/4
                b_raw = p/(1024*(1+(n/p).log()))
                ratio = (b_raw-1)/n
                assert ratio > theta/(8192*(1+(4/theta).log()))
                assert p**2/(2**20*n**2) >= theta**2/2**24
                assert p/(128*n) >= theta/512
                assert b_raw*(1+(8*n/b_raw).log()) < p/32
                print("price class",precision,"n=10^",power,
                      "theta",theta.str(7),"level",level,
                      "lower b/n",ratio.str(7),
                      "facing fraction",(p**2/(2**20*n**2)).str(7))
    print("12 scalar price strata certified at two precisions")


if __name__=="__main__":
    price_trials()
    for dim in (1,2,4,6):
        sequential_trial(dim,F(1),F(3,4))
    triangle_trials()
    asymptotic()
    actual_price_classes()
