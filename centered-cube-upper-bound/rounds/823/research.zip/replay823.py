"""Replay round 823 on the exact R814 archive; usage: --r814 PATH."""
import argparse
from fractions import Fraction
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import platform
import subprocess
import sys
from tempfile import TemporaryDirectory
import zipfile

import flint

base = Path(__file__).resolve().parent
frozen = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"


def run(script, arguments, cwd):
    subprocess.run([sys.executable, "-E", "-B", str(script), *arguments], cwd=cwd, check=True)


def prices(archive):
    # Freeze the original price levels, sources and two actual receiver capacities.
    with TemporaryDirectory(prefix="prices-", dir=base) as temp, zipfile.ZipFile(archive) as z:
        work = Path(temp)
        for name in ("comb811.py", "mu814.py", "trade813.py", "comb814-rebuilt.json",
                     "mu814-original-1.json", "mu814-rebuilt-1.json"):
            (work / name).write_bytes(z.read(name))
        run("comb811.py", ["--output", "comb811.json"], work)
        for model, data in (("original", "comb811.json"), ("rebuilt", "comb814-rebuilt.json")):
            certificate = "mu814-" + model + "-1.json"
            run("mu814.py", ["--comb", data, "--trade-dir", ".", "--factor", "1",
                             "--out", certificate, "--check"], work)
            proof = json.loads((work / certificate).read_bytes())
            stage = json.loads((work / data).read_bytes())["stages"][-1]
            source = {row["mask"]: Fraction(row["mass"]) for row in stage["cells"]}
            assert proof["events"] == 357 and proof["columns"] == 1041
            source_bits = sum(p["bit"] for p in stage["parents"] if p["role"] == "old")
            multiplicity = max((mask & source_bits).bit_count() for mask in source)
            lam = Fraction(1, multiplicity)
            print("model", model, "exact original mass", proof["original_mass"], flush=True)
            original_mass = Fraction(proof["original_mass"])
            for result in proof["results"]:
                low, high = (Fraction(result[k]) for k in ("lower", "upper"))
                mode = result["mode"]
                usage = {}
                for left, right, mark, k, l, value in result["primal_positive"]:
                    key = (left, right, mark) if mode == 0 else (right, mark)
                    cap = lam * source[right]
                    usage[key] = usage.get(key, Fraction()) + Fraction(value)*min(cap,Fraction(1,1024))/cap
                spent_sources = sorted(str(k) for k,v in usage.items() if v==1)
                assert all(v<=1 for v in usage.values())
                assert spent_sources == sorted(result["saturated_sources"])
                spent_owners = []
                if mode == 2:
                    for side, ratios in enumerate(result["aggregated_global"]["owner_ratios"]):
                        assert all(Fraction(v)<=1 for v in ratios.values())
                        spent_owners.extend(str(side)+":"+k for k,v in ratios.items() if Fraction(v)==1)
                assert sorted(spent_owners) == sorted(result["saturated_owner_rows"])
                print("mode", mode, "payable fraction", float(low), float(high),
                      "exact feasible paid mass", original_mass*low,
                      "exactly saturated sources", len(spent_sources),
                      "source labels", spent_sources, "receiver rows", sorted(spent_owners), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--r814", type=Path, required=True)
    args = parser.parse_args()
    archive = args.r814.resolve()
    if not __debug__ or hashlib.sha256(archive.read_bytes()).hexdigest() != frozen:
        raise ValueError("Checking needs assertions and the exact R814 file.")
    print("Python", platform.python_version(), "python-flint", flint.__version__,
          "FLINT", flint.__FLINT_VERSION__, "NumPy",version("numpy"),"SciPy",version("scipy"),flush=True)
    print("Original round 814 archive SHA256", frozen, flush=True)
    prices(archive)
    for name in ("geometry823.py", "protocol823.py", "samples823.py"):
        print("\nRUN", name, flush=True)
        run(base/name, [] if name == "geometry823.py" else ["--archive", str(archive)], base)
    print("All round 823 experiments completed", flush=True)


if __name__ == "__main__":
    main()
