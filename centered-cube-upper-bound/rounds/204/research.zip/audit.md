# R204 independent audit

## 1. Premise screen before author proofs

Read `task_contract.md` before new author manuscripts. The auditor owns only this file, performs no Git/delegation/numerical run/PDF compilation, and does not modify other authors' work. The original sources, posterior, Lebesgue receiver measure and legal parameter family remain unchanged.

On a common legal patch a_v>0, k_v>=0, H_cap=alpha Q>=0, define d=1-k/a<=1, c=H_cap/a>=0, q_v=J_v/Q>0, zeta=c q_v, rho=(d-zeta)_+. The symbol q_v is a posterior density relative to nu, not a scalar probability or the original FIRST threshold. For
\[
\Psi(d,\zeta)=d_+^2-(d-\zeta)_+^2
\]
one has a C1 function on the stated domain, 0<=Psi<=1, Psi_d=2min(d_+,zeta) and Psi_zeta=2rho, both between zero and two. Thus the proposed bounded primitive is correct.

Let mathcal B=z_v^2 F_v=J_v h_v. For the spatial radial derivative D_x=X_y dot grad_x, exact chain rule gives
\[
N=-2\rho\zeta\mathcal B D_x\log q_v
=-\mathcal B D_x\Psi
+\mathcal B\Psi_dD_xd+\mathcal B\Psi_\zeta q_vD_xc.
\]
With compact support or justified tail removal, the first term integrates to integral Psi div(J_v h_v X_y). This contains both h_v times the single-J score and D_x h_v. Bounded Psi does not pay those real h_v, d or c derivatives, actual qualification changes or receiver boundaries. At a=0 the quotient variables are not automatically defined; the actual zero target and its entry trace must be kept separately. Boundedness of Psi alone does not supply an extension of c,d or BV of arbitrary gates.

## 2. Full material product and original time

For the true material derivative mathcal D=partial_logL+X_y dot grad, put T_K=mathcal D K+nK, P=mathcal B Psi and theta=min(d_+,zeta). With fixed reference b and source nu, mathcal D log q_v=D_x log q_v, so
\[
N=-T_P+\Psi T_{\mathcal B}
+2\mathcal B\theta\mathcal Dd
+2\mathcal B\rho q_v\mathcal Dc.
\]
Equivalently, for f=-Psi this is T_(mathcal B f)-f T_mathcalB plus the same two forces. The signs pass independent checking. Integrating over the receiver and/or an auxiliary L path keeps the actual endpoint term and all divergence/selector exchanges. A spatial integration-by-parts identity cannot silently erase the partial_logL component. Varying b, nu, original time or support adds its genuine measure/coefficient change. No upper reserve estimate is a lower bound for a compensating force.

## 3. Exact finite jumps and bounded sensitivity

For two valid states, the line segment in (d,zeta) remains in the domain. The integral-averaged gradients give Delta Psi=a_d Delta d+a_zeta Delta zeta. With arithmetic endpoint means,
\[
\Delta\zeta=\bar q\,\Delta c+\bar c\,\Delta q,
\qquad \Delta(\mathcal B\Psi)=\overline{\mathcal B}\,\Delta\Psi
+\overline\Psi\,\Delta\mathcal B.
\]
Positive q endpoints also satisfy Delta q=logarithmic_mean(q_plus,q_minus) Delta log q, with the continuous equal-endpoint value. These identities are exact; an endpoint gradient is not the finite chain rule. BV use requires actual traces, local boundedness and chain/product qualifications. Merely measurable states permit the finite differences but not a variation measure or summability.

The sensitivity zeta Psi_zeta<=d_+^2/2 yields, only for d,c frozen,
\[
|\Psi(d,cq_1)-\Psi(d,cq_0)|
\le d_+^2\min\{1,\tfrac12|\log(q_1/q_0)|\}.
\]
c=0 gives zero without dividing by c. The factor 1/2 is locally sharp at zeta=d/2. For the actual fixed-window J/Q, |partial_i log q|<=2L_phi/b, so the fixed-d,c spatial difference has the corresponding L_phi l1-distance bound. This is not a theorem freezing the original d or H_cap/a.

## 4. Candidate conditional score bound

If source-v coefficients d_v,c_v are actually frozen in x, h_v is an admissible C1 compact test with uniform |h_v|<=B_star and finite V_h=integral Pi(dv) J_v |D_x h_v|^2 dx, then integration by parts under the original one-slot J Pi gives
\[
\left|\int\Pi(dv)\int N_vdx\right|
\le\sqrt{T_\Psi}\left[B_\star\sqrt{nV_{\rm sc}+I_{\rm loc}C_w}
+\sqrt{V_h}\right],
\quad T_\Psi=\int\Pi(dv)J_v\Psi_v^2dx\le1.
\]
The moment C_w=integral |(v-y)/b|^2 dPi is the actual selected-source moment. This uses only single-kernel receiver product structure and the true Pi; no full-source position moment or source-coordinate independence is assumed. Infinite C_w leaves an infinite bound. Actual h includes denominator, cap and gate changes, and B_star may contain tiny-overlap costs. Those costs, original d/c forces, second slot and all outer beta/time/window fees have not been paid by this conditional estimate.

## 5. Actual normalization/amplitude joint candidate

The proposed original combined term J_nc=N-2mathcal B rho q_v mathcal D c has the exact identity
\[
J_{nc}=-T_P+\Psi T_{\mathcal B}+2\mathcal B\theta\mathcal Dd.
\]
For a true common flow and an admissible gate H, integration keeps -[integral HP] at the endpoints, integral P mathcal D H, and the two remaining terms. An upper bound may use the initial potential, positive gateflow, actual score/current mismatch/clamp and (mathcal Dd)_+; it does not remove those costs. The endpoint estimate integral P<=D B a_m requires the physical fixed cap and its appropriate soft/scale selector cost D. The J-score component is bounded by 3K_D only within the R201 qualifications. Actual merely measurable H permits exact finite state exchanges, not an invented BV formula.

The additional same-source capacity integral a_v Psi_v dnu<=2H_cap passes: Psi<=2zeta and integral q_v dnu=1. Zero-a slots are handled by their actual zero target before division. The original potential under Pi equals e^-1 integral eta (mathcal B/a)(a Psi)dnu on positive-a slots; its occupation factor is not paid by the unweighted capacity. Thus the combined identity eliminates a c-force only in that actual combination, not in every component separately, and does not yet certify a root-order original budget.

The stronger capacity form also passes. For a>0, u=(a-k)_+ and t=alpha J, sigma=a Psi=[u^2-(u-t)_+^2]/a satisfies sigma<=min(a d_+^2,2t d_+). The exact slack 2t-sigma is 2tk/a+t^2/a when t<=u and 2t-u^2/a when t>u. Set sigma=0 before division on zero/invalid-a slots. The same actual row gives integral U+.5 integral sigma<=Dq. For a fixed nonnegative occupation weight w, layer cake followed by each of these caps is valid; the stronger per-level integral of min(a d_+^2,2alpha d_+J) may also be used. Different levels do not select different actual sources, and different V cannot each reuse the same q without the original source account. None of these inequalities bounds the remaining occupation weight.

## 6. Parent moment extremality candidate

For nonnegative random U with mean mu>0 and finite second moment s2, the maximum of E(1-U)_+^2 over that moment class is 1-2mu+s2 if s2<=mu, and 1-mu^2/s2 if s2>=mu. The first majorant is (1-U)^2. For v=s2/mu>=1 the second is (1-U/v)^2; its pointwise majorization is valid on both sides of U=1. The law on {0,v} with probability mu^2/s2 at v attains the appropriate value in both cases. At v=1 the pointwise defect vanishes on all of [0,1], but the additional moment equality EU=EU^2 forces an actual optimizer to be supported on {0,1}. The parent corrected the auditor's initial conflation of these two equality statements; this correction does not change the moment bound or the loss of a uniform v-1 stability coefficient.

On the actual fixed joint measure, define S=integral mathcal B d_+^2 H, T=integral_(d>0) mathcal B d zeta H and U2=integral_(d>0) mathcal B zeta^2 H. If 0<S<infinity and U2<infinity, normalize by the first weight and use U=zeta/d. The stated bounds W<=S-2T+U2 for U2<=T and W<=S-T^2/U2 otherwise follow. T is finite by Cauchy; S=0, T=0 and infinite U2 are treated first, without infinity subtraction or zero division. All original alpha, posterior and qualification factors remain in the same measure. This is a sharp actual moment inequality, not a payment of the moments or the original path/interface costs.

For v>1 the majorant defect is exactly u(v-1)[2v-(v+1)u]/v^2 on 0<=u<=1 and (u-v)^2/v^2 on u>1. Concentration near 0 or v therefore retains the degenerating v-1 price. No physical attainability or strict expansion of a paid original branch follows from the abstract sharp two-atom law.

The later clipping candidate also passes: for a fixed tau>=1, replacing R by R_tau=min(R,tau) leaves (1-R)_+^2 exactly unchanged. With finite S, the weighted T_tau<=tau S and U_tau<=tau^2 S are finite, and the same two-branch bound applies without any untruncated second-moment assumption. Its normalized moments satisfy mu_tau^2<=s_tau<=tau mu_tau, so the matching two-point value v_tau=s_tau/mu_tau lies inside [0,tau]. Thus the bounded-support moment class is also sharp. Tau=1 is only the original primitive identity, not a newly paid estimate. Near-extremal statements concern the clipped ratio; at v_tau=tau they cannot locate an original value above tau. All original moment/occupation/path costs remain.

## 7. Full author review

Read complete `bounded_capture_primitive.md`, 221 lines, version `aeeb700e0c17404b0f4163817580ed8b71bcafcdbf1ab6c39b4174871794fb69`, after the independent screens. BP1–21 pass. In particular BP18's sign is correct: the diffuse derivative of P contains -N dx, and moving it across integral X dot DP=-n integral P leaves +n integral P plus the real whole-P jump. Cantor parts, common traces, legal positive-a domain and merely measurable limitations are explicitly retained. The two finite interpolation paths are not mixed, and the third rational jump has average derivatives 5/4 and 1/4 as stated. The conditional J Pi Cauchy price freezes d,c only under actual stated conditions and leaves all h/cap/source costs. No necessary revision was found; no actual whole-budget payment is inferred from this auxiliary manuscript.

Read complete `joint_capture_geometry.md`, 276 lines. JC1–23 mathematical claims pass: same-alpha source capacity and exact slack, actual Pi occupation return and layer-cake price, the original normalization/amplitude combination, AC-only common-flow account, fixed-cap score/endpoint component prices, and all gate/state entries and outer-source costs. Static capacity is never counted as repeated path variation. The necessary JC13 transcription correction was reread in final version `163845cfbc2a2779eb27824ccc515709bf1c9d1e8a26abe0b323c3b4ae24d93e`: denominator e a_v with a positive-a indicator and prior zero-slot convention. Its added scope sentence retains R201/R200 traces and does not promise a new whole-transport proof from the parent moment manuscript. No necessary revision remains.

Read complete `parent_capture_extremality.md` ME1–7 and `sharp_moment_checks.py`. The general sharp moment proof and matching abstract law are independent of finite support enumeration; exact defects and v-dependent stability, actual d>0 weighted return and zero/infinite guards are correct. The v=1 moment-class correction is explained accurately. The full transport operator means partial_logL mathcal B+div(X mathcal B), not multiplication by div X alone. The finite script checks 840+4320+17160=22320 laws plus a weighted return excluding the d=0,zeta>0 slot. Its exact arithmetic, matching two moments and stability checks have no necessary revision. No numerical execution was performed by this auditor.

Reread the added ME5 active-gate qualification and explicit transport-operator notation. If the actual measure includes rho>0, then R<1 and U<=T, so the high-branch optimizer geometry is not a statement about that active-only measure. Dropping only rho>0 on a common legally defined background keeps W but requires recomputing all S,T,U on the enlarged measure. Dropping high-A or other nonzero-W exclusions generally only enlarges W. This precise scope passes. The report's abstract moment-class claims are read with this actual-application qualification, not as a physical extremizer construction.

Read the later complete ME5a and the narrowly added clipping loop in the moment checker. Their common fixed tau, unchanged objective, finite clipped moments and bounded-support matching law agree with the independent screen. Each of the 22320 original cases is also checked at caps 1,2,16: the 66960 extra tests compare the exact original/clipped objectives and bounded second-moment feasibility, rerun the moment certificate, and verify zero defect at cap 1. No source/window or physical-attainability conclusion is inferred. No necessary revision remains.

## 8. Numerical static checkpoint

Read complete `capture_primitive_checks.py` and final `numeric_notes.md`, without executing them. Nine scalar/path fixtures exactly partition the affine (d,zeta) path at rational crossings; trapezoid and midpoint averages, endpoint-mean product rules and zero/active/saturated branches are correct. The repeated bounded cycle retains positive variation 5/4. Three abstract same-source models recompute the common alpha and actual finite gates at both endpoints, verify P+W=mathcal B d_+^2 and the sigma capacity, and do not label gate-excluded rho as a physical target. The two physical frozen-d,c,h phi examples retain the exact source midpoint threshold and all quadrature seams. The finite identity N-RHS+boundary=0 and analytic absolute-tail constants 64(X+1)exp(1/2-X) and 2(9+8X)exp(1/2-X) have the correct signs and factors. Notes distinguish Fraction evidence from noninterval quadrature and do not grant freezing the original coefficients. No necessary revision was found.

Read report and reproducer. The report distinguishes primitive reorganization, static capacity and sharp abstract moments from the unpaid original net potential flow/current interface/entry/selector budget. Source caps, actual moments and original energy are retained. The driver verifies a future manifest and uses both actual --output interfaces with complete JSON byte comparisons and fresh-path guards. This static review does not pre-certify its later execution. Parent skill-use records are not imported as unproved external theorems by this audit.

## 9. Final integration review and accepted scope

Read the full 923-line `proof.tex.txt`, including ME5a and its final numerical and stopping-range sections, against the three complete mathematical manuscripts. The primitive, exact finite chain, qualified diffuse/BV pairing, joint normalization/amplitude identity, single same-alpha source capacity and actual occupation return agree. The moment normalization, active-gate qualification, unchanged clipped objective, finite clipped moments and clipped-only near-extremal interpretation agree with ME5a. The text correctly distinguishes 22320 original moment configurations from 66960 capped configurations, and the 9 scalar/path, 3 abstract common-source and 2 frozen-coefficient physical examples. It does not pre-report execution of the future package driver. One necessary transcription repair was identified at the spatial IBP display: `=int` must be `=\int`; the repaired final version was reread at that display and incorporates that repair.

The final report and reproducer retain the same scope. Accepted results are the stated exact reorganization, static shared capacity and sharp abstract/actual weighted moment inequalities with their qualifications. They do not certify small actual gate variation, current k/a or target interfaces, net potential flow/reentry, source-dependent cap occupation, selector/window costs, physical attainability of an abstract optimizer, or a general original raw root-order budget. A bounded primitive is not a bound on its repeated positive variation. An auxiliary kernel square-root bound paired with the original n-order energy is not automatically a raw square-root bound.

This auditor performed full manuscript review and static script review only, with no numerical execution or PDF compilation. Author/parent execution reports are recorded at their stated finite evidence level. The file bindings below exclude this audit itself and the future manifest; final driver execution and archive status belong to the parent after this freeze.

## 10. Final SHA-256 bindings

The following are byte hashes of the twelve reviewed files. This table excludes the audit and future manifest.

| File | SHA-256 |
| --- | --- |
| `bounded_capture_primitive.md` | `aeeb700e0c17404b0f4163817580ed8b71bcafcdbf1ab6c39b4174871794fb69` |
| `capture_primitive_checks.json` | `3fec81a2434cdca204eb3a9745c3ac751b186425d3c544ddf9d6f2721d93f8b1` |
| `capture_primitive_checks.py` | `f69dab28d96ee98446c4c1f8ccefd6b29f7c0c2be852bfaf9376fd07efadee0d` |
| `joint_capture_geometry.md` | `163845cfbc2a2779eb27824ccc515709bf1c9d1e8a26abe0b323c3b4ae24d93e` |
| `numeric_notes.md` | `752dab1ec26f8d625a64474efd65920c3907eba3c0de1bcd81ef94a2ffa9be63` |
| `parent_capture_extremality.md` | `60a50094550213083642a7d0dbde542cf7c95e996abaa3601be74487b289a1b4` |
| `proof.tex.txt` | `82061e5724b0a1e235ccd3d892e61ef2771111c02e0bda90d48658f502c116da` |
| `report.md` | `394d1655287e3d6d4ef4c7237ebf42e1920c51efa072e412a99aa9c6dfa4de3e` |
| `reproduce.py` | `bf0ead36415afe06787228657ebb95cc0ecfdb794416be6e99b7833cdccab3d7` |
| `sharp_moment_checks.json` | `124bf88ad7fc2ae53418be7b8fd311aff9d0b74810756bc0abcacbb7c4a70c74` |
| `sharp_moment_checks.py` | `7df578f5a9992f2187bd42bf29ae565928cdc84bec3a9f9b091e12887c8a0297` |
| `task_contract.md` | `2eafffa106d8eb5f8a6e9b3994b452b17254f9924812df43a24053fa68117527` |

Final status: accepted within the qualifications and remaining costs above; no necessary revision remains. This audit is frozen.
