#!/usr/bin/env python3
"""Verify final files and replay finite evidence, not a general proof checker."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--verify-only',action='store_true')
parser.add_argument('--output-dir',type=Path)
parser.add_argument('--numeric-python',default=sys.executable)
args=parser.parse_args()
manifest=json.loads((root/'manifest.json').read_text())
for name,digest in manifest.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
print('Verified',len(manifest),'file hashes',flush=True)
if not args.verify_only:
    if args.output_dir is None:parser.error('--output-dir required')
    args.output_dir.mkdir(parents=True,exist_ok=True)
    for stem in ('sharp_moment_checks','capture_primitive_checks'):
        out=args.output_dir/(stem+'.json')
        if out.exists():parser.error('Use fresh output paths')
        subprocess.run([args.numeric_python,str(root/(stem+'.py')),'--output',str(out)],
                       check=True,env=os.environ.copy())
        assert out.read_bytes()==(root/out.name).read_bytes(),stem+' JSON differs'
        print(stem,'complete JSON byte-identical',flush=True)
