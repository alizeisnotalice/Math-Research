# R204：同一捕获储备的原函数容量与真实共同界面

状态：证明原 capture 与有界原函数共享的一份来源容量，以及保持实际权重的层积分价格；同时将原 normalization 与 capture/amplitude 导数合并，使自身 bias 反馈完全消失。没有证明中间 hard 域的一般原 raw 根阶预算。静态容量不被当作全路径正变差，原重新进入、current 硬面及可测门交换全部保留。

## JC1　原对象、零支与记号

固定原 `(ω,V,j,y,t)` 及合法窗口 b，ν=νV，
\[
 \eta(v)=1_{Z_t(y)}(v)w_t(y,v),\quad e=\int\eta\,d\nu>0,
 \quad\Pi=\eta\nu/e,
 \quad Q=\int J_v\nu(dv).
\]
此处 ν、η、e、Π 独立 receiver x 和当前运行 L；未假设 ν≤β。e=0 原行先零。J>0 且 ν有限非零时 Q>0。

原同一捕获量及剩余标量为
\[
 H_c=Dq-M_U,\quad M_U=\int U_v\nu(dv),\quad
 \alpha=H_c/Q\ge0.
\]
在实际 active/capture target 上令
\[
 a_v=T\Delta_v>0,\quad k_v=DK_{0v}\ge0,\quad
 d_v=1-k_v/a_v\le1,\quad c_v=H_c/a_v,\quad
 R_v=J_v/Q,\quad \zeta_v=c_vR_v=\alpha J_v/a_v,
 \quad \rho_v=(d_v-\zeta_v)_+.
\]
最后一式只在原 capture 内与原 ρ 同一。下面用于正容量上界的虚拟原函数可在所有 a>0 来源上按此代数定义；实际 target 门仍在 H 中，不能把虚拟 ρ 当作门外原交通。a≤0 的来源不在该正 active 对象内，实际被计费的 W、𝓟 与相关原函数质量均先取零，不写 0乘∞；这只是零支账法，不在那里使用 k/a 或 d 的公式。

原 target A=ρz，另记
\[
 S_v=p_v+p_v^++J_v,\quad z_v=J_v/S_v,\quad
 F_v={\min(p_y^2,B_v^2J_v^2)\over J_v},\quad
 \mathcal B_v=z_v^2F_v,\quad W_v=\rho_v^2\mathcal B_v.
 \tag{JC1}
\]
Bv 为所用真实帽。Bv=B0/Wg 时小重叠费用不消失。帽的参数变化另计，不混入“固定帽”导数。

## JC2　有界原函数与无倒 α 的链式结构

定义
\[
 \Psi(d,\zeta)=d_+^2-(d-\zeta)_+^2,\qquad
 \theta=\min(\zeta,d_+),\qquad \mathcal P_v=\mathcal B_v\Psi_v.
 \tag{JC2}
\]
因为 d≤1、ζ≥0，
\[
 0\le\Psi\le d_+^2\le1,\quad
 \Psi_\zeta=2\rho,\quad \Psi_d=2\theta.
 \tag{JC3}
\]
平方正部使 Ψ 为 C1；d=0 或 d=ζ 不产生该原函数自身的奇异导数。a=0 的参数比值仍需原资格/零支，不能由此自动跨过。

取 \(\mathcal D_y=\partial_{\log L}+(x-y)\cdot\nabla_x\)，以及密度 transport \(\mathcal T f=\mathcal D_y f+nf\)。固定 b、ν 时 \(\mathcal D_y\log R_v=(x-y)\cdot\nabla\log(J_v/Q)\)。在同一合法光滑正 a 分支，原 normalization 项为
\[
 N_v=-2\rho_v\zeta_v\mathcal B_v\,\mathcal D_y\log R_v.
\]
由于 \(\mathcal D\zeta=\zeta\mathcal D\log R+R\mathcal Dc\)，精确得到
\[
 \boxed{N_v=-\mathcal T\mathcal P_v+
 \Psi_v\mathcal T\mathcal B_v+
 2\mathcal B_v\theta_v\mathcal D_y d_v+
 2\mathcal B_v\rho_vR_v\mathcal D_y c_v.} \tag{JC4}
\]
这里没有除以 α 或 Hc。Hc=0 时 N=0，但实际 Dc 可非零，JC4 中各项仍须共同保留。改变 b、ν、η 或窗口时，R 的额外变化不能删去。

## JC3　真正合并原 normalization 与捕获变化

原 \(\mathcal D(\rho^2)\) 中已有 capture/amplitude 项
\[
 -2\rho_vR_v\mathcal D_y c_v,
 \qquad
 \mathcal D_y c_v={\mathcal D_y(Dq)-\mathcal D_yM_U\over a_v}
 -{H_c\over a_v^2}\mathcal D_y a_v.
\]
因此不是另造可减项，而是把原平方导数中的两项同账：
\[
 \boxed{N_v-2\mathcal B_v\rho_vR_v\mathcal D_y c_v
 =-\mathcal T\mathcal P_v+
 \Psi_v\mathcal T\mathcal B_v+
 2\mathcal B_v\theta_v\mathcal D_y d_v.} \tag{JC5}
\]
原 Hc/α 的导数在这份联合账中完全消去，不再需要对 R203 的 Ceff 求梯度后把自身 bias 当小误差。

原 current/amplitude 比值仍有
\[
 \mathcal D_y d_v=-{\mathcal D_y k_v\over a_v}
 +{k_v\over a_v^2}\mathcal D_y a_v,
 \tag{JC6}
\]
这些是实际 K0、TΔ 的变化，不是任意源函数。全平方进一步满足
\[
 W_v=\mathcal B_vd_{v,+}^2-\mathcal P_v,
 \qquad
 \mathcal T W_v=\mathcal T(\mathcal B_vd_{v,+}^2)-\mathcal T\mathcal P_v.
 \tag{JC7}
\]
JC7 只是用于核对完整账，不单独登记为新付款。关键新增来源信息在下一节；有界 P 不给其全路径总变差界。

## JC4　同 α 的联合来源容量

本节是逐 receiver、逐原行、完整同一 ν 的命题。令 a>0 时
\[
 u_v=(a_v-k_v)_+,\qquad t_v=\alpha J_v,\qquad
 s_v=a_v\Psi_v={u_v^2-(u_v-t_v)_+^2\over a_v}.
 \tag{JC8}
\]
a≤0 时 s=0。这里 s_v 不是原 soft 参数。为避免混淆，下文将测度写成 dσ=s_v dν。

**共同容量定理。** 原同一 α 满足
\[
 0\le s_v\le\min\{a_vd_{v,+}^2,\ 2\alpha d_{v,+}J_v\}
 \quad(a_v>0),
\]
\[
 \boxed{\|\sigma\|=\int a_v\Psi_v\nu(dv)
 \le2\alpha Q=2H_c,\qquad
 \int U_v\nu(dv)+\tfrac12\|\sigma\|\le Dq.} \tag{JC9}
\]
积分记号中的 aΨ 在 a≤0 处按零解释。第二式让实际 capture 和原函数质量共享同一份 Dq，不能分别各领 Dq 后相加。

证明：若 tv≤uv，sv=(2uvtv−tv²)/av；若 tv>uv，sv=uv²/av。两分支都给 sv≤uv²/av 和 sv≤2uvtv/av。再用 d+≤1，∫Jν=Q，得到 ||σ||≤2αQ。最后用 Hc=Dq−∫Uν。全程同一 α、同一 ν，无独立来源、质量帽或 ν≤β。

该定理是原归一化结构的完整来源容量，而非 μ=ν/||ν|| 的概率化。它仍是每个原 V/行的容量；不能将多个 V 的 Dq 直接相加后当一份 q 的预算。跨 V、j、窗口的原权重必须保留。

## JC5　容量的精确非负亏损与共同参数

定义 \(\mathcal L_v=2\alpha J_v-s_v\)。则
\[
 \mathcal L_v=
 \begin{cases}
 2t_vk_v/a_v+t_v^2/a_v,&a_v>0,\ t_v\le u_v,\\
 2t_v-u_v^2/a_v,&a_v>0,\ t_v>u_v,\\
 2t_v,&a_v\le0.
 \end{cases}
 \qquad \mathcal L_v\ge0.
 \tag{JC10}
\]
因此有真实精确式
\[
 \boxed{2H_c-\|\sigma\|=\int\mathcal L_v\nu(dv),\qquad
 Dq-\int U\,d\nu-\tfrac12\|\sigma\|
 =\tfrac12\int\mathcal L\,d\nu.} \tag{JC11}
\]
亏损保留实际 K0、αJ 与 a 的同点关系，不能把各来源上的 α 分开优化。特别小 k/a 与小 αJ/a 可使相应来源的容量接近上界；JC11 没有证明这些位置在原 weighted 交通下稀少。

对有界权 w，可精确写
\[
 \int w\,d\sigma=2\alpha\int wJ_v\nu(dv)-\int w\mathcal L_v\nu(dv).
 \tag{JC12}
\]
无界权只先用 w∧M；没有有限性时不能在极限中形成 ∞−∞。本稿不把 JC12 的负项挪去支付另一原分支。

## JC6　原 Π 权的精确回代与非 supremum 层价格

固定 receiver x 和同一行，将另一 u 槽的原 0≤H≤1 门保留为
\[
 \overline H_v=\int H(x,y,v,u,t)\Pi(du)\in[0,1].
\]
所有 good/high/history、low-score、所余分支资格仍在 H；该正积分不改变原 posterior。原函数的实际来源积分恰为
\[
 \boxed{\int\overline H_v\mathcal P_v\Pi(dv)
 =\int w_v\,\sigma(dv),\qquad
 w_v={\overline H_v\eta(v)\mathcal B_v\over ea_v}\cdot1_{\{a_v>0\}}.} \tag{JC13}
\]
这明确保留 η、e、𝓑/a。没有将静态 σ 容量直接当成原 Π 潜能的质量帽。

层积分可保真实来源分布，优于先取 sup w。对任何非负可测 w，Tonelli 及 JC9 给
\[
 \boxed{\int w\,d\sigma\le
 \int_0^\infty \min\left\{
 2H_c,\ 
 \int_{\{w>s,a>0\}}a_vd_{v,+}^2\nu(dv),\
 2\alpha\int_{\{w>s,a>0\}}d_{v,+}J_v\nu(dv)
 \right\}ds.} \tag{JC14}
\]
还可用更紧的同点上界
\[
 \int w\,d\sigma\le
 \int_0^\infty\int_{\{w>s,a>0\}}
 \min\{a_vd_{v,+}^2,2\alpha d_{v,+}J_v\}\nu(dv)ds.
 \tag{JC15}
\]
这些式子全部使用原同一来源和 α，不为每层重新分配 α，不声称各独立容量约束同时可达到。JC15 的被积尾质量已经≤2Hc；这个事实不授权把各层再领一份 Hc。它们是明确实际权的静态上界，尚需证明原 w 的层分布可付。

JC13 的倒 a 并非原交通中可随意加入的损失：它只是将真正 aΨ 容量换回 𝓑Ψ 的精确密度比。该比值可能大，不能用抽象 normalization 将它删除。

## JC7　共同流的可量化联合估计

本节显示的导数积分式只在具有真实绝对连续资格的共同合法路径上使用。若存在 BV 跳跃或奇异部分，须再按下一节的真实有限差分/乘积测度计入，不能只积几乎处处的光滑导数。令 r=logL，x积分保原接收域或用紧支 gate保留该域；ν、Π、b、j、t、y 固定。对于 0≤H≤1 的紧支光滑 gate，JC5 的原积分分部给
\[
 \begin{split}
 &\int_{r_0}^{r_1}\!\int H\,[N_v-2\mathcal B_v\rho_vR_v\mathcal D_yc_v],dxdr\\
 &=-\left[\int H\mathcal P_vdx\right]_{r_0}^{r_1}
 +\int_{r_0}^{r_1}\!\int \mathcal P_v\mathcal D_yH\,dxdr\\
 &\quad+\int_{r_0}^{r_1}\!\int H\Psi_v\mathcal T\mathcal B_v\,dxdr
 +2\int_{r_0}^{r_1}\!\int H\mathcal B_v\theta_v\mathcal D_yd_v\,dxdr.
 \end{split} \tag{JC16}
\]
Π² 或 β 可在同一有限可积截断上继续积分。完整负终值保留；若只取上界，可以只收初值，gate 正流、真实 physical transport 和 current 比值的正部。没有出现额外 log(m/e) 或 full/weighted posterior 中心偏差。

固定帽、未clamp且处于 smooth cell 时，R201 给
\[
 \mathcal T\mathcal B_v=\mathcal B_v\left[
 (2+\epsilon_v-2z_v)S_{yv}
 -2{(v-y)\cdot\nabla(p_v+p_v^+)\over S_v}\right],
 \quad S_{yv}=n+(x-y)\cdot\nabla\log J_v,
 \quad\epsilon_v\in\{-1,1\}.
 \tag{JC17}
\]
故 |2+ε−2z|≤3，Ψ≤1，score 分量的真正价格为
\[
 \int H\Psi\mathcal B|2+\epsilon-2z|\,|S_{yv}|dx
 \le3\int F_v|S_{yv}|dx. \tag{JC18}
\]
引用 R201 已审 physical score/截帽估计，固定参数时右端≤3K1(n,(v−y)/b,Bv)；若实际使用 selector 正包络，只能替成对应已付 D 的 KD。初始潜能同样有
\[
 \int H\mathcal P_vdx\le\int F_vdx\le D B_v a_m.
 \tag{JC19}
\]
a_m 为 R198 截帽反集中量；其固定来源/参数资格、软选择与尺度费用不得省略。固定 s,L 用 D=1；真实适应 L(x) 不能因此用 D=1。R201 给出的安全全 selector D=2√(2n)(1+2nlog2)，或使用已有更合适的单参数价。

JC18–19 是原联合公式中明确可估的分量，而非整片付款。target current 硬面、Lplus clamp、B变化及 JC6 的 Dd 仍有真实流量。仅 outer-y 的 p 硬面与材料运动的 transport 速度相符而抵消；不能把 target-v 硬面也说成自动抵消。实际迹按 R201/R200 保留；父本轮稿聚焦真实 weighted 二矩极值，不声称新证全部输运迹，本稿不删这些费用。

## JC8　可测原门、有限差分与重新进入

原 H 只可测时，JC16 不自动适用，也不因 Ψ 有界就自动获得 BV。可无条件保留的是每两个具有实际状态定义的正 a 端点间（零支端点先按 JC1 取零，并保留资格交换）
\[
 \boxed{W_+-W_-=
 (\mathcal B_+d_{+,+}^2-\mathcal B_-d_{-,+}^2)
 -(\mathcal P_+-\mathcal P_-).} \tag{JC20}
\]
其中 d_{+,+} 指 plus 状态 d 的正部，非新参数。该恒等保留 a、k、Hc、J/Q、帽及 current 状态的全部变化；两端 α 均必须由各自同一全来源 U 计算，不可自由挑选。

有原 gate 时令 h=min(H−,H+)。任何非负状态量 P 的精确交换为
\[
 H_+P_+-H_-P_-=h(P_+-P_-)
 +(H_+-H_-)_+P_+-(H_--H_+)_+P_-.
 \tag{JC21}
\]
对 W、𝓑d+²、𝓟分别使用，同一原测度下才可组合。新 high/history/eligibility 入口不能借旧行的负项抵消。若原 Π、来源或窗口改变，另加真实测度交换；固定 Π 的量词不能掩盖它。

共同当前 L 对同一窗口的 target 和 outer 来源共同，所以原同一界面的 signed 量应先按实际 βΠ²聚合，再取所需正部；不按 target 各自选择 α 或尺度。逐面容量 JC9 不允许在每次重新进入重复领 2Hc。全路径须保 𝓟 的实际净变化及 JC21 的入口项。

## JC9　外层来源、时间与尺度账

在 JC16 合法的分支，JC18–19 对原固定参考来源的正费用为
\[
 \mathbb E\sum_{V,j}\int_{I_j}{dt\over t}\int\beta_V(dy)
 \int\Pi_t(dv)\big[D B_v a_m+3\lambda_L K_D(n,(v-y)/b,B_v)\big],
 \tag{JC22}
\]
其中 λL 为实际共同路径长度；若路径/窗口不同，逐项保留或使用经核的统一上界。另一 Πu 的正门在取得上界时可放至1，但原 gate/共同流交换仍在 JC16、JC21 中。

原时间 Ij 只扩大到固定 j 的 ξ=cjt/b∈[1/2,1]与原定义域交集；e=0/域外行零。全部 j/time 的 T* 和独立窗口费用保留。这里的 Π 是原概率，不是全 ν/e；没有 ν≤β 假设。Bv=B0/Wg 的费用没有被 aΨ 容量自动消掉。

JC13–15 若用于支付端态，应把其实际 w、ν、α 放在相同 β/j/time 和 receiver dx 下积分。不能将每行 2Hc≤2Dq 积掉后复制为逐 V 的 q|E|。也不能把静态每层上界求和当成无层数的动态 Carleson 结论。

## JC10　取得的推进与尚缺的一条共同界面估计

本轮给出两项不同于对辅助 posterior 直接求梯度的准确推进：

* JC9–15：原 capture 和原函数共享一份 Dq 的真实来源容量，含精确非负亏损、原 Π 的实际密度比以及不先取 sup 的层价格。
* JC5、JC16：把原 normalization 与原 capture/amplitude 变化共同结算，α/Hc 导数和自身 bias 反馈完全消去；可估分量使用 physical J score，不引入新的 log(ν(V)/e) 因子。

但容量不能控制变化次数。当前最早未付的联合关系是：在原同一来源、同一 α、同一合法尺度状态下，**JC13 的实际加权潜能负向净流，与 current k/a 界面及 JC21 的真实入口，能否由 JC9 的共享捕获容量及共同 receiver 几何统一支付。** 例如有限共同尺度状态列中，应保的对象包含
\[
 \int dx\sum_i\left[
 \int\beta(dy)\iint\Pi_y(du)\Pi_y(dv)
 \{H_i\mathcal P_i-H_{i+1}\mathcal P_{i+1}\}
 \right]_+,
 \tag{JC23}
\]
并与 JC16/17 的同一 current/幅度项一起结算，而非把括号内各 target 正部相加。式中固定 j,t/window 的共同来源资格必须先成立；不同状态测度不共同则保交换。JC23 只是展示准确尚缺项，未给它新名字后宣称已付。

原 Γ、capture 门未证明 BV，真实 selector 也未被辅助路径替换。核级 √n 分量若最终作为 companion 配原 n 能量，仍可能只得 raw n^(3/4)。因此本稿不宣称一般根阶闭合，也不把一个人为的小潜能门作为新全覆盖分支。
