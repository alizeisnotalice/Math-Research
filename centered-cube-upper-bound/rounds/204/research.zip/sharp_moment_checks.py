#!/usr/bin/env python3
"""Exact finite rational checks for the nonnegative capture moment envelope."""
import argparse
from fractions import Fraction as F
import hashlib
from itertools import combinations_with_replacement
import json
from pathlib import Path

def objective(u):
    return max(F(0), 1-u)**2

def inspect(values, weights):
    mu=sum(w*u for w,u in zip(weights,values))
    second=sum(w*u*u for w,u in zip(weights,values))
    observed=sum(w*objective(u) for w,u in zip(weights,values))
    if mu == 0:
        assert second == 0 and observed == 1
        return 'zero', F(0), '0|0|1'
    assert second >= mu*mu
    v=second/mu
    upper=1-2*mu+second if second<=mu else 1-mu*mu/second
    assert observed<=upper<=1 and upper>=0
    mass=mu*mu/second
    assert 0<mass<=1
    assert mass*v==mu and mass*v*v==second
    matched=(1-mass)+mass*objective(v)
    assert matched==upper
    defect=upper-observed
    if v>=1:
        exact=sum(w*((1-u/v)**2-objective(u)) for w,u in zip(weights,values))
        assert defect==exact
        if v>1:
            for eps in (F(1,10),F(1,2)):
                lower_mass=sum(w for w,u in zip(weights,values) if eps<=u<=1)
                upper_mass=sum(w for w,u in zip(weights,values) if u>=1 and abs(u-v)>=eps*v)
                assert lower_mass*eps*(1-1/v)**2<=defect
                assert upper_mass*eps*eps<=defect
    else:
        assert defect==sum(w*max(F(0),u-1)**2 for w,u in zip(weights,values))
    return ('lower' if second<=mu else 'upper'),defect,'|'.join(map(str,(mu,second,observed,upper,defect)))

def run():
    stages=[
        ('initial',[F(0),F(1,4),F(1,2),F(1),F(3,2),F(2)],4),
        ('stress',[F(0),F(1,1024),F(1023,1024),F(1),F(1025,1024),F(2),F(16),F(1024)],7),
        ('expanded',[F(0),F(1,1000000),F(1,7),F(1,3),F(2,3),F(1),F(4,3),F(3),F(100),F(1000000)],11)]
    results=[]
    for label,grid,denominator in stages:
        digest=hashlib.sha256();counts={'zero':0,'lower':0,'upper':0};maxdefect=F(0)
        for values in combinations_with_replacement(grid,3):
            for i in range(denominator+1):
                for j in range(denominator-i+1):
                    weights=(F(i,denominator),F(j,denominator),F(denominator-i-j,denominator))
                    branch,defect,record=inspect(values,weights)
                    counts[branch]+=1;maxdefect=max(maxdefect,defect)
                    digest.update((str(values)+str(weights)+record+'\n').encode())
                    original=sum(w*objective(u) for w,u in zip(weights,values))
                    for cap in (F(1),F(2),F(16)):
                        capped=tuple(min(u,cap) for u in values)
                        capbranch,capdefect,caprecord=inspect(capped,weights)
                        cmu=sum(w*u for w,u in zip(weights,capped))
                        cs=sum(w*u*u for w,u in zip(weights,capped))
                        assert cs<=cap*cmu
                        assert sum(w*objective(u) for w,u in zip(weights,capped))==original
                        if cap==1:assert capdefect==0
                        digest.update(('cap='+str(cap)+'|'+caprecord+'\n').encode())
        results.append({'stage':label,'support_grid':list(map(str,grid)),
                        'weight_denominator':denominator,'counts':counts,
                        'case_count':sum(counts.values()),'capped_case_count':3*sum(counts.values()),
                        'max_defect':str(maxdefect),
                        'ordered_evidence_digest':digest.hexdigest()})
    # Actual weighted change of variables, including a d=0 source with nonzero zeta.
    sources=[(F(2),F(0),F(9)),(F(3,7),F(1,3),F(1,9)),
             (F(5,4),F(1),F(3,2)),(F(1,11),F(1,2),F(0))]
    S=sum(B*d*d for B,d,z in sources if d>0)
    T=sum(B*d*z for B,d,z in sources if d>0)
    U2=sum(B*z*z for B,d,z in sources if d>0)
    W=sum(B*max(F(0),d-z)**2 for B,d,z in sources)
    values=[z/d for B,d,z in sources if d>0]
    weights=[B*d*d/S for B,d,z in sources if d>0]
    branch,defect,_=inspect(values,weights)
    upper=S-2*T+U2 if U2<=T else S-T*T/U2
    assert W/S==sum(w*objective(u) for w,u in zip(weights,values))
    assert upper-W==S*defect
    return {'schema':'r204_sharp_capture_moments_v1','arithmetic':'Python fractions.Fraction only',
            'stages':results,'total_cases':sum(s['case_count'] for s in results),
            'caps':['1','2','16'],'total_capped_cases':sum(s['capped_case_count'] for s in results),
            'weighted_return':{'sources':[[str(x) for x in row] for row in sources],
                               'S':str(S),'T':str(T),'U2':str(U2),'W':str(W),
                               'branch':branch,'upper':str(upper),'defect':str(upper-W)},
            'status':'PASS_EXACT_FINITE',
            'scope':['Finite rational checks and matching abstract moment distributions.',
                     'The general theorem is proved separately by pointwise polynomial majorants.',
                     'No physical realization of abstract extremizers or original global budget is certified.']}

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'))
    args=parser.parse_args();result=run()
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('PASS exact rational cases:',result['total_cases'],'capped cases:',result['total_capped_cases'],'plus weighted return')
