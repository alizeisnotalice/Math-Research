#!/usr/bin/env python3
"""Exact primitive jumps and finite fixed-coefficient physical IBP checks."""
import argparse,hashlib,json,time
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent


def enc(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x


def positive(x):return max(F(0),x)


def primitive(d,z):
    assert d<=1 and z>=0
    rho=positive(d-z);value=positive(d)**2-rho*rho
    assert 0<=value<=1
    return value,rho


def state(d,c,q,B=1):
    d,c,q,B=map(F,(d,c,q,B));assert c>=0 and q>=0 and B>=0
    return {'d':d,'c':c,'q':q,'zeta':c*q,'B':B}


def jump(left,right):
    d,z=left['d'],left['zeta'];dd=right['d']-d;dz=right['zeta']-z
    cuts={F(0),F(1)}
    for start,slope in ((d,dd),(d-z,dd-dz)):
        if slope and 0<-start/slope<1:cuts.add(-start/slope)
    cuts=sorted(cuts);ad=az=mid_d=mid_z=F(0);pieces=[]
    def grad(theta):
        dt=d+theta*dd;zt=z+theta*dz
        rho=positive(dt-zt)
        return 2*(positive(dt)-rho),2*rho
    for lo,hi in zip(cuts,cuts[1:]):
        gl,gr=grad(lo),grad(hi);gm=grad((lo+hi)/2)
        ad+=(hi-lo)*(gl[0]+gr[0])/2;az+=(hi-lo)*(gl[1]+gr[1])/2
        mid_d+=(hi-lo)*gm[0];mid_z+=(hi-lo)*gm[1]
        pieces.append({'theta_left':lo,'theta_right':hi,'grad_left':gl,'grad_right':gr})
    assert ad==mid_d and az==mid_z
    pl,rl=primitive(d,z);pr,rr=primitive(right['d'],right['zeta']);delta=pr-pl
    assert delta==ad*dd+az*dz
    dc=right['c']-left['c'];dq=right['q']-left['q']
    assert dz==(left['q']+right['q'])/2*dc+(left['c']+right['c'])/2*dq
    deltaP=right['B']*pr-left['B']*pl
    product=(left['B']+right['B'])/2*delta+(pl+pr)/2*(right['B']-left['B'])
    assert deltaP==product
    return {'left':left,'right':right,'theta_cuts':cuts,'pieces':pieces,'average_derivative_d':ad,'average_derivative_zeta':az,
        'Psi_left':pl,'Psi_right':pr,'delta_Psi':delta,'delta_B_Psi':deltaP,
        'left_endpoint_gradient_prediction':grad(F(0))[0]*dd+grad(F(0))[1]*dz,
        'right_endpoint_gradient_prediction':grad(F(1))[0]*dd+grad(F(1))[1]*dz,'status':'PASS'}


def scalar_cases():
    specs=[
        ('initial','zero_branch',[state('-1/2',0,1),state(0,1,1)]),
        ('initial','active_branch',[state('3/4',0,2),state('3/4','1/4',1)]),
        ('initial','saturated_branch',[state('1/2',1,'1/2'),state('1/2',2,1)]),
        ('stress','cross_d_and_rho',[state('-1/2',0,1),state(1,'1/2',1)]),
        ('stress','endpoint_gradient_failure',[state(1,0,1),state(1,2,1)]),
        ('stress','simultaneous_c_q_change',[state(1,'1/4',2),state('1/2',1,1)]),
        ('expanded','large_denominators',[state('1001/1024','17/31','29/43'),state('-1/257','19/37','2/71')]),
        ('expanded','repeated_bounded_cycle',([state('3/4',0,2),state('3/4','1/4',1),state('1/2',2,1)]*4)+[state('3/4',0,2)]),
        ('expanded','coefficient_gate_change',[state(1,'1/4',1,0),state('1/2',1,'1/2','3/2')]),
    ]
    rows=[]
    for stage,name,states in specs:
        jumps=[jump(a,b) for a,b in zip(states,states[1:])]
        net=sum((j['delta_Psi'] for j in jumps),F(0));pv=sum((positive(j['delta_Psi']) for j in jumps),F(0))
        tv=sum((abs(j['delta_Psi']) for j in jumps),F(0))
        if name=='endpoint_gradient_failure':
            assert jumps[0]['delta_Psi']==1 and jumps[0]['left_endpoint_gradient_prediction']==4 and jumps[0]['right_endpoint_gradient_prediction']==0
        if name=='repeated_bounded_cycle':assert net==0 and pv==F(5,4) and tv==F(5,2)
        rows.append({'stage':stage,'name':name,'jumps':jumps,'net_delta_Psi':net,'positive_variation_Psi':pv,'total_variation_Psi':tv,'status':'PASS'})
    return rows


def source_state(p,a,k):
    p=F(p);a=list(map(F,a));k=list(map(F,k));nu=[F(1),F(1)];J=[F(1),F(1)];Qz=[F(1),F(41,100)];wg=[F(1,4),F(2,5)]
    C=F(3,2);Q=sum(j*m for j,m in zip(J,nu));assert sum(x*m for x,m in zip(k,nu))<=C
    E=[p*wg[i]<=Qz[i] and a[i]>0 for i in range(2)]
    U=sum((min(a[i],k[i])*nu[i] for i in range(2) if E[i]),F(0));Hcap=C-U;alpha=Hcap/Q;assert Hcap>=0
    targets=[]
    for i in range(2):
        d=1-k[i]/a[i];c=Hcap/a[i];q=J[i]/Q
        Fcap=min(p*p,(2*J[i])**2)/J[i]
        rawB=(J[i]/(3*Qz[i]))**2*Fcap;B=rawB if E[i] else F(0)
        s=state(d,c,q,B);psi,rho=primitive(d,c*q)
        A=rho*J[i]/(3*Qz[i]) if E[i] else F(0)
        W=B*rho*rho;P=B*psi;baseline=B*positive(d)**2
        assert W==A*A*Fcap and P+W==baseline
        targets.append({'state':s,'gate_E':E[i],'raw_B':rawB,'Psi':psi,'rho_auxiliary':rho,'P':P,'W':W,'baseline_B_dplus_squared':baseline,'A':A})
    sigma=[a[i]*targets[i]['Psi']*nu[i] for i in range(2)]
    assert sum(sigma)<=2*Hcap and U+sum(sigma)/2<=C
    return {'shared_source_sigma':sigma,'sum_sigma':sum(sigma),'twice_Hcap':2*Hcap,'capture_plus_half_sigma':U+sum(sigma)/2,'p':p,'a':a,'k':k,'nu':nu,'J':J,'Q_target':Qz,'wg':wg,'C':C,'Q_original_scalar':Q,
        'E':E,'U_capture':U,'Hcap':Hcap,'alpha':alpha,'targets':targets}


def common_source_cases():
    basea=[4,1];basek=[1,'1/2']
    specs=[('initial','coefficient_change_no_lost',source_state('9/10',basea,basek),source_state('19/20',basea,basek)),
        ('stress','capture_exit',source_state(1,basea,basek),source_state('6/5',basea,basek)),
        ('expanded','reentry_and_a_k_change',source_state('6/5',basea,basek),source_state('9/10',[3,2],['1/2','1/4']))]
    rows=[]
    for stage,name,left,right in specs:
        assert right['Hcap']-left['Hcap']==left['U_capture']-right['U_capture']
        records=[]
        for i in range(2):
            l,r=left['targets'][i],right['targets'][i];j=jump(l['state'],r['state'])
            dP=r['P']-l['P'];dW=r['W']-l['W'];dBase=r['baseline_B_dplus_squared']-l['baseline_B_dplus_squared']
            assert dP==j['delta_B_Psi'] and dP+dW==dBase
            records.append({'target':i,'jump':j,'delta_P':dP,'delta_W':dW,'delta_B_dplus_squared':dBase,'status':'PASS'})
        rows.append({'stage':stage,'name':name,'left':left,'right':right,'target_balances':records,'status':'PASS'})
    return rows


def physical_ibp(dps,shiftq):
    mp.mp.dps=dps;half=mp.mpf('.5');shift=mp.mpf(shiftq.numerator)/shiftq.denominator
    X=shift+(80 if dps==25 else 110);d=c=half
    @lru_cache(maxsize=65536)
    def phi(x):
        r=abs(x)
        return 1-mp.expint(3,half-r)-mp.expint(3,half+r) if r<=half else mp.expint(3,r-half)-mp.expint(3,r+half)
    def dp(x):
        r=abs(x)
        return mp.sign(x)*(mp.expint(2,r+half)-mp.expint(2,abs(r-half)))
    @lru_cache(maxsize=65536)
    def point(x):
        J=phi(x);other=phi(x-shift);Q=(J+other)/2;gJ=dp(x)/J;gQ=(dp(x)+dp(x-shift))/(J+other)
        zeta=c*J/Q;rho=max(mp.mpf(0),d-zeta);psi=d*d-rho*rho
        normalization=-2*rho*zeta*J*x*(gJ-gQ)
        rhs=psi*J*(1+x*gJ)
        return normalization,rhs,x*J*psi
    # Equal priors and even strictly decreasing phi make rho=0 at the exact
    # midpoint x=shift/2; no numerical root search is needed for this fixture.
    seams=sorted(set([-X,X,mp.mpf(0),shift/2,shift]+[a+b for a in (mp.mpf(0),shift) for b in (-half,half)]+list(map(mp.mpf,(-32,-16,-8,-4,-2,-1,1,2,4,8,16,32)))))
    N=mp.quad(lambda x:point(x)[0],seams);R=mp.quad(lambda x:point(x)[1],seams)
    boundary=point(X)[2]-point(-X)[2];residual=N-R+boundary
    assert abs(residual)<mp.mpf('1e-16')
    out=lambda x:mp.nstr(x,dps+5)
    return {'dps':dps,'normalization_integral':out(N),'IBP_right_integral':out(R),'finite_boundary':out(boundary),
        'residual_after_boundary':out(residual),'cutoff_X':out(X),'rho_zero_threshold':out(shift/2),
        'analytic_N_absolute_tail_upper':out(64*(X+1)*mp.exp(half-X)),
        'analytic_RHS_absolute_tail_upper':out(2*(9+8*X)*mp.exp(half-X)),
        'finite_seams':[out(x) for x in seams]}


def run(exact_only=False):
    scalar=scalar_cases();source=common_source_cases()
    if exact_only:return {'schema':'r204_primitive_exact_v1','scalar_cases':scalar,'common_source_cases':source,'status':'PASS_EXACT_ONLY'}
    physical=[]
    for shift in (F(1,2),F(2)):
        runs=[physical_ibp(dps,shift) for dps in (25,40)]
        diffs={key:abs(mp.mpf(runs[0][key])-mp.mpf(runs[1][key])) for key in ('normalization_integral','IBP_right_integral')}
        assert all(x<mp.mpf('1e-16') for x in diffs.values())
        physical.append({'source_positions':[F(0),shift],'source_prior':[F(1,2),F(1,2)],'target_v':F(0),'b':F(1),'frozen_d':F(1,2),'frozen_c':F(1,2),'h':F(1),
            'runs':runs,'precision_differences':{key:mp.nstr(x,12) for key,x in diffs.items()}})
    return {'schema':'r204_capture_primitive_v1','inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'dependencies':{'mpmath_version':mp.__version__,'mpmath_entry_sha256':hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()},
        'primitive_formula':'Psi=dplus^2-(d-zeta)plus^2, zeta=cq',
        'homotopy':'Straight in (d,zeta); not the generally curved path c(theta)q(theta). Endpoint product differences are exact arithmetic means.',
        'scalar_case_count':len(scalar),'scalar_cases':scalar,'common_source_case_count':len(source),'common_source_cases':source,
        'physical_case_count':len(physical),'physical_IBP':physical,'status':'PASS_FINITE_CHECKS',
        'limitations':['Fraction scalar homotopies/common-source arrays and noninterval physical IBP diagnostics are distinct evidence types.',
            'Gate-excluded targets have B=0; unmasked rho there is an algebraic auxiliary, not a claim of physical qualification.',
            'Fixed d,c,h physical examples do not grant freezing the original coefficients or actual alpha.',
            'Tail formulas bound mathematical truncation only, not quadrature or floating error.',
            'Bounded primitive values do not pay arbitrary total variation; the repeated finite cycle explicitly retains variation.',
            'No original geometry/FIRST/history/FULL certificate or dimension-order fit.']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'capture_primitive_checks.json');ap.add_argument('--exact-only',action='store_true');args=ap.parse_args()
    start=time.monotonic();result=run(args.exact_only);args.output.write_text(json.dumps(enc(result),indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':result['status'],'seconds':round(time.monotonic()-start,3)},sort_keys=True))
