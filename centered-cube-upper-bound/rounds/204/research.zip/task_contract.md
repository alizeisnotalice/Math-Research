# R204 原捕获有界原函数与共同界面

基线14e004ac44b0bcde3f6a548ef1c9e0de5f0b5ae5已推送，开始状态clean、main、SSH远端正确。上轮为实质进展：独审新尺度熵与signed材料桥、实际本机数值、单轮提交。一般n^(1/2+o(1))目标未完成。

本轮聚焦中间hard域的真实共同几何，不再尝试从虚假共同扩散获得Fisher耗散。固定原(ω,V,j,y,t)、Π=ην/e及窗口b，Q=∫Jvν，Hcap=Dq−MU=αQ，av=TΔv>0，kv=DK0v，d=1−k/a≤1，c=Hcap/a≥0，qv=Jv/Q，ζ=cqv，ρ=(d−ζ)+。仅在实际active/capture资格下与原ρ同一；门外保持真实target，不擅自延长原定义。

具体候选有界原函数 G(d,ζ)=d+²−(d−ζ)+²∈[0,1]。Gζ=2ρ，Gd=2(d+−ρ)。h=zv²Fv/Jv，原normalization项N=−2ρζhJv X·∇logqv。在有真实空间导数的共同分支，N=−Jv h X·∇G+Jv h Gd X·∇d+Jv h Gζ qv X·∇c。原c=0不用除c；任意measurable门只准有限差分，不能冒充BV。

关键主命题是：将此原函数放回真实材料流 D=∂logL+X·∇x、原h、相同α及共同hard/capture面，能否与实际变化联合支付一般根阶预算。不得仅把原N换名为新导数余项。需保∂logL端点/selector、Bv= B0/Wg、原target H及otherΠ槽、β和全部j/time/window费用。

分工：Astra high主原联合capture几何；Sol high辅助有界primitive、有限差分与合法IBP；Sol high先独筛后审；Sol medium在准确公式后本机数值/有理证书。父主要推导actual h transport回代并统一整合。各自独占指定文件，不改他人，不git/spawn，交付停止。参考仅必要R201–203责任稿。

允许已证工具：R201完整cap/材料transport与J score矩；R202CN1–5原α和ΠJ关系；R203MB signed材料配对及Stein系数/熵有限域。fullν无位置矩；只有selected carrier提供Cw。已知障碍：full/weighted系数差含整份Fisher抵消，任意门不保证BV，局部核sqrt(n)与原n能量可能最终仍n^.75。

先筛候选、初探数值、已有边界/删除压力测试、扩大范围；有限证据不能代替一般证明。只最终完整核验轮次后紧凑归档，保详细LaTeX不编译PDF，外部backup核验后清理自身work，单轮单提交推送main。没有完整一般证明不宣称闭合。
