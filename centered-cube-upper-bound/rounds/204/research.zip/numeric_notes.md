# R204 capture primitive checks

The finite checker first passed its exact-only run, then completed nine scalar jump/path fixtures, three same-source capture fixtures and two frozen-coefficient physical IBP cases. Fraction evidence and noninterval mpmath diagnostics are kept separate. These are not original geometry/FIRST/history or FULL certificates and do not pay a general budget.

## Exact scalar jumps

For d<=1,zeta>=0, Psi=dplus^2-(d-zeta)plus^2 is computed directly and checked in [0,1]. The homotopy is straight in (d,zeta). Rational crossings of d=0 and d-zeta=0 partition theta in [0,1]; on each piece both partial derivatives are affine. Trapezoidal and midpoint integrations independently agree exactly, giving delta-Psi=average-Psi_d delta-d+average-Psi_zeta delta-zeta.

The endpoint identity delta-zeta=bar(q)delta-c+bar(c)delta-q is checked separately. The auxiliary (d,zeta) line is not silently replaced with the generally curved product c(theta)q(theta). Likewise delta(B Psi)=bar(B)delta-Psi+bar(Psi)delta-B uses endpoint arithmetic means, not a single endpoint gradient.

The initial three fixtures cover zero, active and saturated branches. The pressure three cross the d/rho thresholds and change c and q simultaneously. For d=1,zeta:0->2, the true delta-Psi is 1; the left derivative predicts 4 and the right derivative predicts 0. The exact averaged zeta derivative is 1/2. The expanded fixtures include larger denominators, a coefficient/gate change and four cycles through Psi values 0,5/16,1/4,0. The cycle has net zero, positive variation 5/4 and total variation 5/2 despite Psi remaining in [0,1]. A bounded potential alone is therefore not booked as free total variation.

## Same-source capture balance

Three finite models recompute the same original scalar Q=sum nu J, U=sum_E min(a,k)nu, Hcap=C-U and alpha=Hcap/Q at both endpoints. No endpoint alpha is selected independently. The source gate is E={p wg<=Q_target,a>0}, with fixed other abstract gates. Source capacity sum k nu<=C and Hcap>=0 are checked. The models use B=E[J/(3Q_target)]^2 F, F=min(p^2,(2J)^2)/J. Consequently W=B rho^2 equals the directly computed A^2 F, and P=B Psi satisfies P+W=B dplus^2.

Initial p=.9->.95 has no lost source and both alphas zero; coefficient changes remain in B. Pressure p=1->1.2 loses the second target and gives alpha 0->1/4. Expanded p=1.2->.9 restores its gate while changing a to (3,2) and k to (1/2,1/4); alpha is recomputed as 1/4->3/8. Every target checks delta-P+delta-W=delta(B dplus^2), the homotopy formula and the full endpoint product identity. Gate-excluded rho values are algebraic auxiliaries multiplied by B=0, not claims of physical qualification outside the gate.

On these same positive-a states, the author's shared-source capacity is additionally checked: sigma_v=a_v Psi_v nu_v, sum sigma<=2Hcap and U+sum sigma/2<=C. For the exit and final reentry states, sum sigma is 35/64 and 149/128. These are finite algebra checks using the common source and reserve; no new geometry or budget theorem is inferred. No a=0 state is claimed to have been tested.

## Two physical frozen-coefficient IBP cases

The actual phi E3 density and E2 derivative are used with b=1, equal source priors, positions (0,1/2) or (0,2), target J=phi(x), fixed d=c=1/2 and h=1. Q is the two-source mixture, zeta=cJ/Q and rho=(d-zeta)plus. In these symmetric examples the rho threshold is exactly the source midpoint; it and every kernel seam are explicit quadrature cuts.

The script directly integrates N=-2rho zeta J x gradient log(J/Q) and Psi J(1+x gJ) at 25 and 40 decimal digits. The finite-cut identity is integral N - integral RHS + [x J Psi] at the endpoints =0. The corresponding integrals are approximately 0.005487348849 and 0.023158589626; maximum 25/40 difference is below 1.76e-28. At 40 digits, boundary-adjusted residuals are below 5.1e-49. These are numerical residuals, not rigorous roundoff enclosures.

Cutoffs are shift+80 or shift+110. Bounds rho<=1,zeta<=1,abs(gJ-gQ)<=16,abs(gJ)<=8 and phi(x)<=exp(1/2-abs(x)) yield omitted absolute tails <=64(X+1)exp(1/2-X) for N and <=2(9+8X)exp(1/2-X) for the RHS. They control analytic truncation only, not mpmath quadrature or rounding. Freezing d,c,h is legitimate only for these subexamples; the original variable coefficients, common alpha transport and qualification exchanges are not removed.

## Reproduction

Actual runtime was about 5.4 seconds. The script uses normal import mpmath 1.3.0, with no installation or embedded runtime path. Local command:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 capture_primitive_checks.py --output capture_primitive_checks.json
```

The local default Python is /opt/homebrew/opt/python@3.14/bin/python3.14. Relocation needs only the script and its local task_contract.md, whose filename hash is recorded; dependency version and entry-file SHA are also recorded. The optional --exact-only command was executed first with output in /tmp. A fresh temporary-directory copy was subsequently executed and complete JSON byte equality passed. No timing or absolute execution path enters deterministic JSON. Only the three assigned files were written. There is no fitted order, original selector or all-input closure claim.
