# R204：捕获项的有界原函数、共同跳跃与条件材料预算

状态：辅助证明。本文自洽证明原函数 Ψ 的有界性、微分、无除零的有限差分及合法 BV 跳跃链式；给出在冻结 d,c 且保真实 h 变化时、原 JΠ 自然测度下的显式根阶型价格。实际 d/c/h 的共同变化与原外层费用仍保留，不登记一般新付款。本文不处理 Astra 的完整 W 路径或实际净硬面主预算。

## BP1　原变量与资格

固定原 (ω,V,j,y,t)、窗口 b>0 及原来源 ν=νV。只在原 e=∫ηdν>0 行定义 Π=ην/e，η=1Zt wt；这些来源及权在 receiver x 微分中冻结，保持原 Π，绝不换成 J 后验，也不假 ν≤β。ν 任意有限正，m=ν(Rn)>0。置
\[
 J_v(x)=b^{-n}\prod_i\phi((x_i-v_i)/b),\quad
 Q(x)=\int J_z(x)\nu(dz),\quad q_v(x)=J_v(x)/Q(x)>0. \tag{BP1}
\]
这里 q_v 是核/全来源混合比，绝不与原共同 level q 混同。原 level 仍写 q，原量为
\[
 H_{\rm cap}=Dq-M_U=\alpha Q\ge0,\quad
 a_v=T\Delta_v>0,\quad k_v=DK_{0,v}\ge0,
\]
\[
 d_v=1-k_v/a_v\le1,\quad c_v=H_{\rm cap}/a_v\ge0,
 \quad\zeta_v=c_vq_v=\alpha J_v/a_v,\quad
 \rho_v=(d_v-\zeta_v)_+. \tag{BP2}
\]
本回代只在原有效 active/capture 资格内等于原ρ；原门外不以辅助定义覆盖原target。a=0、Q=0或e=0的无效行先按原零槽处理，不在那里定义这些商。严格正物理 J 和 m>0 保证Q>0；本文不要求 full ν 的位置矩。

按父稿统一记
\[
 \mathcal B_v=z_v^2F_v,\qquad h_v=\mathcal B_v/J_v,\qquad
 \mathcal P_v=\mathcal B_v\Psi(d_v,\zeta_v),\qquad X=x-y.
\]
mathcalB/h 中的原target、帽、other Πu 槽及所有资格保留。原normalization连续项为
\[
 N_v=-2\rho_v\zeta_v h_vJ_v\,X\cdot\nabla\log q_v. \tag{BP3}
\]
下文的 BV/C1 条件是实际应用资格，不能由“来自原门”自动推出。

## BP2　全域有界、偏导及边界

对 d≤1、ζ≥0 定义
\[
 \Psi(d,\zeta)=d_+^2-(d-\zeta)_+^2,\qquad \rho=(d-\zeta)_+. \tag{BP4}
\]
函数x↦x+²为C1，因此Ψ在此闭域上有C1延拓，并且
\[
 \boxed{0\le\Psi\le d_+^2\le1,\quad
 \Psi_d=2(d_+-\rho)=2\min(d_+,\zeta)\in[0,2],\quad
 \Psi_\zeta=2\rho\in[0,2].} \tag{BP5}
\]
所以Ψ分别随d、ζ非减。Ψd分别随d和ζ非减；Ψζ随d非减、随ζ非增。这里不声称两个偏导都沿所有方向非减。

证明：ζ≥0给0≤ρ≤d+，从而差平方非负且≤d+²。d≤0时两正部均0。d>0时，ζ≤d一支为Ψ=2dζ−ζ²、ρ=d−ζ；ζ≥d一支为Ψ=d²、ρ=0。逐支微分给BP5，在d=0及ζ=d处两侧偏导吻合。

边界无需任何除法：ζ=0时Ψ=0、Ψd=0、Ψζ=2d+；d=0时Ψ及两个偏导都0；ρ=0时Ψζ=0，但Ψd=2d+不一定0。c=0或α=0时ζ=0，原N=0；这不意味着改变c的导数项也可预先删去。所有公式保正部，允许d负。

## BP3　尖锐的乘法敏感度：无1/α或1/c

对固定d，
\[
 0\le\zeta\Psi_\zeta=2\zeta(d-\zeta)_+\le d_+^2/2. \tag{BP6}
\]
d>0时最大值在ζ=d/2，故1/2的局部常数尖锐。固定c≥0及q0,q1>0，在logq直线路径积分BP6并配合range界可得
\[
 \boxed{|\Psi(d,cq_1)-\Psi(d,cq_0)|
 \le d_+^2\min\{1,\tfrac12|\log(q_1/q_0)|\}.} \tag{BP7}
\]
c=0时两边左项恒0，不需除c。

原φ的已证log-Lipschitz界给|∂i logJv|≤Lφ/b。有限ν下局部微分交换合法，∂i logQ是同一核score的J后验平均，故
\[
 |\partial_i\log q_v|\le2L_\phi/b. \tag{BP8}
\]
不需fullν梯度或位置矩。因此仅在d,c冻结的receiver有限步中，
\[
 |\Psi(d,cq_v(x'))-\Psi(d,cq_v(x))|
 \le d_+^2\min\{1,L_\phi\|x'-x\|_1/b\}. \tag{BP9}
\]
这是真实核比的有界敏感度，不是原selector/capture可以冻结的证明，也不是无维度的位移积分费用。

## BP4　精确有限差分与共同硬面

给两状态d±≤1、ζ±≥0，令dθ=(1−θ)d−+θd+、ζθ=(1−θ)ζ−+θζ+，并定义
\[
 \langle\Psi_d\rangle=\int_0^1\Psi_d(d_\theta,\zeta_\theta)d\theta,
 \quad\langle\Psi_\zeta\rangle=\int_0^1\Psi_\zeta(d_\theta,\zeta_\theta)d\theta.
\]
域凸，基本微积分给精确式
\[
 \Delta\Psi=\langle\Psi_d\rangle\Delta d
              +\langle\Psi_\zeta\rangle\Delta\zeta. \tag{BP10}
\]
若ζ±=c±q±、c±≥0、q±>0，端点算术均值以bar记，则
\[
 \Delta\zeta=\bar q\,\Delta c+\bar c\,\Delta q,\quad
 \boxed{\Delta\Psi=\langle\Psi_d\rangle\Delta d
 +\langle\Psi_\zeta\rangle(\bar q\Delta c+\bar c\Delta q).} \tag{BP11}
\]
这是精确代数，并未令中间ζθ等于cθqθ。也可选择(dθ,cθ,qθ)直线路径，此时以ζθ=cθqθ逐点积分Ψζ(qθΔc+cθΔq)；总差相同，分项归属依已说明路径，不能混用两种中间态。

若mathcalB两端也变化，
\[
 \boxed{\Delta\mathcal P
 =\overline{\mathcal B}\,\Delta\Psi+\bar\Psi\,\Delta\mathcal B,}
 \quad\bar\Psi=(\Psi_++\Psi_-)/2. \tag{BP12}
\]
BP10中的平均梯度不同于BP12的端点算术平均。若确需logq形式，对正q±有Δq=LogMean(q+,q−)Δlogq，其中LogMean=(q+−q−)/(logq+−logq−)，相等时取连续值q。不能把该logmean换成任一端点q。

当硬面、capture、帽与资格同时变化时，BP10–12全部项一并保留；只求一个endpoint gradient一般错误。例如d=1、ζ从0到2，真ΔΨ=1，而左端梯度预测2×2=4、右端梯度预测0。若原固定fullν/b的receiver面上q连续，则Δq=0，但Δd、Δc与ΔmathcalB仍实际存在。若q也变，通常已涉及其他selector/prior/window交换，BP11只给代数，不授这些状态物理合法性。

任意measurable门只保证在选定两状态可用有限差分；没有路径总变差或迹结论。

## BP5　平滑材料链式与合法分部积分

写D=X·∇x，本节不是包含∂logL的全材料流。只在d,c,h实际C1、q为BP1的固定来源核比且具有下列可积/紧支条件时使用。ζ=cq直接给
\[
 D\zeta=qDc+\zeta D\log q,
\]
\[
 \boxed{N=-JhD\Psi+Jh\Psi_dDd+Jh\Psi_\zeta qDc.} \tag{BP13}
\]
它逐点等于BP3，不含1/α。c=0边界仍使用qDc形式；不能未经资格改成Dlogc。

若h有共同紧支且系数可积，或实际尾使相关边界项为零，
\[
 \boxed{\int Ndx=\int\Psi\,\operatorname{div}(JhX)dx
 +\int Jh(\Psi_dDd+\Psi_\zeta qDc)dx.} \tag{BP14}
\]
这是−∫Jh X∇Ψ的真实分部积分，正号无遗漏。令
\[
 S_{y,v}=n+X\cdot\nabla\log J_v,
\]
则第一项恰为∫JΨ[hS_yv+Dh]dx。因此可用的保守价格为
\[
 |\int N|\le\int J\Psi|hS_{y,v}+Dh|
 +\int Jh\{\Psi_d|Dd|+\Psi_\zeta q|Dc|\}, \tag{BP15}
\]
假定原h≥0；实值h把第二项h改成|h|。后两项是实际d/c变化费，不宣称已付。d=1−k/a和c=Hcap/a在a>0时满足
\[
 Dd=-Dk/a+(k/a^2)Da,\qquad
 Dc=DH_{\rm cap}/a-(H_{\rm cap}/a^2)Da. \tag{BP16}
\]
Hcap=αQ=Dq−MU的原共同导数完整保留，不能独立重选α、把Dq删掉或将各target的Da任意固定。若a趋0，BP16可能昂贵；该费用未由Ψ有界自动消除。

## BP6　BV资格、diffuse变化与非端点梯度跳跃

一个充分资格是：实际d,c,h局部BV并在所用紧区域有有限局部界，q为固定full来源的正C1函数；相关总变差配对与边界可积。d≤1,c≥0保持。更一般资格可另证明，但不能从原measurable gate推断。先在一维参数路径考虑这些条件，令“diff”包括绝对连续及Cantor部分，星号为相应精确代表。链式为
\[
 d\Psi^{\rm diff}=\Psi_d(d^*,\zeta^*)\,dd^{\rm diff}
       +\Psi_\zeta(d^*,\zeta^*)\,d\zeta^{\rm diff},
\]
\[
 d\zeta^{\rm diff}=q^*dc^{\rm diff}+c^*dq^{\rm diff},\quad
 d\mathcal P^{\rm diff}=\Psi^*d\mathcal B^{\rm diff}
                              +\mathcal B^*d\Psi^{\rm diff}. \tag{BP17}
\]
每个jump采用真实ΔΨ、ΔmathcalP，由BP10–12计算，而不是endpointgradient。全路径端点差等于这些diffuse积分与所有真实jump之和；右起/右末的闭端约定则跳和取(L0,L1]，不得把末端jump与左末态混配。

证明可由分割有限差分得到：先隔离大跳，在余下小振荡区间用C1梯度的一致连续性控制误差为其连续模乘总变差；分割细化误差趋0。再依总变差的可数可加性加入小跳，保留真实jump差。product差用BP12。此论证包含Cantor部分，不把一般BV误当分段光滑。空间BV式逐坐标切片后积分，jump测度为ΔmathcalP n dH^{n−1}，n从minus指向plus；分项共同面需先分成交叉的公共迹分区。

为清楚指出原连续N与jump的区别，设空间BV紧支的mathcalP=JhΨ，q仍连续C1。精确地
\[
 \begin{split}
 \int Ndx={}&n\int\mathcal Pdx
 +\int\Psi^* X\cdot D^{\rm diff}\mathcal B
 +\int\mathcal B^*\Psi_d X\cdot D^{\rm diff}d\\
 &+\int\mathcal B^*\Psi_\zeta q X\cdot D^{\rm diff}c
 +\int_{J_{\rm all}}(\mathcal P_+-\mathcal P_-)X\cdot n\,dH^{n-1}.
 \end{split} \tag{BP18}
\]
q的ac导数项已恰消成原N。Jall含所有实际共同jump；Cantor费用仍在diff。证明是将BP17代入∫X·DmathcalP=−n∫mathcalP；故右侧末项必须是整个mathcalP的真实jump。h或d/c若仅可测，BP18没有使用资格。不能将BP18中的jump项当为已付negative信用，也不能认为Ψ≤1就消除其总数或来源重用费。

## BP7　保原JΠ的条件来源矩根阶预算

现在给确切且有限的可用推论。固定原Π（总质量1），让d_v≤1、c_v≥0对receiver x为常数，但可依固定来源v及原外参数。h_v(x)为实际joint measurable、C1紧支系数（或由真实尾证明可合法去截断）。保原mathcalB、otherΠu与资格，只在这些实际条件确成立的支上使用。假设有真正统一的
\[
 |h_v(x)|\le B^*,\quad
 C_w=\int\|(v-y)/b\|_2^2\Pi(dv)<\infty,
\]
\[
 V_h=\int\Pi(dv)\int J_v(x)|Dh_v(x)|^2dx<\infty,
 \quad T_\Psi=\int\Pi(dv)\int J_v(x)\Psi(d_v,c_vq_v(x))^2dx\le1. \tag{BP19}
\]
这里TΨ不是新后验质量；不等式只用Ψ≤1与∫JΠ=1。已证R202/R203的物理材料score给同一joint下
\[
 \int\Pi(dv)\int J_v S_{y,v}^2dx
 =nV_{\rm sc}+I_{\rm loc}C_w,
 \quad V_{\rm sc}\le9/4,\ I_{\rm loc}\le64. \tag{BP20}
\]
这是实际noise/source矩，不能替换成fullν无矩的carrier。其证明为固定v展开X=(x−v)+(v−y)：单核尺度score均值0，不同坐标正交；偶性使尺度score与location score的交叉项为0；余下location平方产生Iloc||(v−y)/b||²。随后Tonelli沿实际Π积分。

对BP14逐v使用后Tonelli/Cauchy，得到
\[
 \boxed{\left|\int\Pi(dv)\int N_vdx\right|
 \le\sqrt{T_\Psi}\left[B^*\sqrt{nV_{\rm sc}+I_{\rm loc}C_w}
                                      +\sqrt{V_h}\right].} \tag{BP21}
\]
证明：冻结d,c使BP14的两个变化项为零。首项为∫ΠJΨhS，绝对值≤B*√TΨ√∫ΠJS²；第二项≤√TΨ√Vh。并未把πw当Π，也未把原实值signed积分换成绝对流量。若h不uniform bounded，可保精确∫ΠJ h²S²，不能免费用源依赖帽的最大值当常数。

BP21有真正的核/source矩根阶结构，但它是条件工具：实际d/c的费用如BP15、实际h梯度/界面如BP18不能丢。原Bv含1/Wg等，未证明B*或Vh的统一价格。若Cw无限该上界只作扩展值不claim有限价。fullν无位置矩完全允许，它仅通过q=J/Q进入本推论；所需Cw属于真实selectedΠ。原carrier若适用可代Cw≤17n(a/b)(5logn+1/2)，仍保a/b。

在固定来源中JvΠ(dv)=pw(x)πw,x(dv)，pw=∫JΠ，故BP19–21也可精确写成pw与πw的joint；此RN身份不添加裸m/e，也不消h_v的v依赖。不能分别假h_v光滑后以忽略后验导数的方式改成h_eff自由导数。

## BP8　小有理菜单与可复现公式

数值作者可仅用Fraction检验下列标量公式，不需φ求积；这些是代数资格而非原physical FULL实例。ρ=(d−cq)+，Ψ=d+²−ρ²：

| d | c | q_v | ζ | ρ | Ψ |
|---:|---:|---:|---:|---:|---:|
| −1/2 | 2 | 1/3 | 2/3 | 0 | 0 |
| 0 | 1 | 1 | 1 | 0 | 0 |
| 3/4 | 0 | 2 | 0 | 3/4 | 0 |
| 1 | 1/4 | 1 | 1/4 | 3/4 | 7/16 |
| 1/2 | 1 | 1/2 | 1/2 | 0 | 1/4 |
| 1/2 | 2 | 1 | 2 | 0 | 1/4 |

三个共同jump为(d,c,q)：(−1/2,0,1)→(1,1/2,1)，(1,0,1)→(1,2,1)，(1,1/4,2)→(1/2,1,1)。以(dθ,ζθ)直线，切点只有dθ=0或dθ−ζθ=0，均为有理；分段线性偏导可精确积分。最后一个例中Δd=−1/2、Δζ=1/2、平均Ψd=5/4、平均Ψζ=1/4，所以ΔΨ=−1/2。另有barqΔc+barcΔq=(3/2)(3/4)+(5/8)(−1)=1/2，检出误删共同q/c变化。共同mathcalB可取从2到3，检查BP12；mathcalP的真差必须与完整两项一致。

BP6也可写精确平方差：d>0、0≤ζ≤d时，d²/2−2ζ(d−ζ)=2(ζ−d/2)²；域外先用ρ0或d0分支。零c/ρ、negative d、跨两条阈值与共同产品变化均应覆盖。以上仅提供可执行有理fixture，没有声称已实际运行；实际数值证据归numeric责任文件。

## BP9　原预算回代边界与停止范围

成果是一个同原α/capture变量相容、有界且无α倒数的primitive，其局部q方向具有尖锐1/2敏感度，且共同jump与合法diffuse导数可精确保留；BP21为冻结d/c、实际h变化的条件来源矩预算。

它没有支付∂logL端点或L(x)selector、真实Da/Dk/DHcap、qualification进入、h及原帽的BV/迹，也没有支付otherΠu、outerβ、全部j/time/window与source重用。不同window必须保各自b、carrier比例与帽，不能把单窗常数无说明提出EΣV。所有归一化都在原同一状态进行，不重算α/Π，不假β≥ν。BP18或BP21不替代Astra实际净硬面/完整W主证明。任意原measurable门只准BP10–12，不自动进入BP14/18/21；一般弱型目标未闭合。至此停止，送全文独审。
