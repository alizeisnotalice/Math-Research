from fractions import Fraction as F
from random import Random
from math import comb

rng=Random(421)
counts={"finite_full_source_algebra":0,"native_tensor_centers":0,"parameter_and_positive_geometry":0}
for case in range(96):
    N=5; V=6
    f=[F(rng.randint(1,9),7) for _ in range(N)]
    c=[[rng.randrange(2) for _ in range(N)] for _ in range(V)]
    for j in range(V): c[j][j%N]=1
    a=[rng.randrange(2) for _ in range(N)];a[0]=1
    w=[F(rng.randint(1,5),11) for _ in range(V)]
    m=[sum(f[x]*c[j][x] for x in range(N)) for j in range(V)]
    ma=sum(f[x]*a[x] for x in range(N))
    I=[sum(f[x]*a[x]*c[j][x] for x in range(N)) for j in range(V)]
    Jmax=max(sum(w[j]*c[j][x]/m[j] for j in range(V)) for x in range(N))
    cap=max(sum(w[j]*c[j][x] for j in range(V)) for x in range(N))
    vmin=F(0); rhs1=F(0); exclusive=F(0); paid=F(0); remainder=F(0)
    theta=F(2,5)
    for j in range(V):
      for k in range(V):
        ij=sum(f[x]*c[j][x]*c[k][x] for x in range(N))
        iajk=sum(f[x]*a[x]*c[j][x]*c[k][x] for x in range(N))
        base=w[j]*w[k]*I[j]*I[k]/(ma*ma*m[j]*m[k])
        omega=ij/min(m[j],m[k])
        assert 0<=omega<=1 and omega<=ij/m[j]+ij/m[k]
        vmin+=base*omega
        rhs1+=base*ij/m[j]
        ex=w[j]*w[k]*(I[j]-iajk)*(I[k]-iajk)/(ma*ma*m[j]*m[k])
        direct=sum(f[x]*f[y]*a[x]*a[y]*c[j][x]*(1-c[k][x])*c[k][y]*(1-c[j][y]) for x in range(N) for y in range(N))
        assert direct==(I[j]-iajk)*(I[k]-iajk)
        chi=min(F(1),omega/theta)
        exclusive+=ex;paid+=ex*chi;remainder+=ex*(1-chi)
    one=Jmax*sum(w[j]*I[j] for j in range(V))/(ma*ma)
    assert rhs1<=one and vmin<=2*one<=2*Jmax*cap/ma
    assert paid+remainder==exclusive and paid<=vmin/theta
    counts["finite_full_source_algebra"]+=1
# Native Lebesgue model: q=1, child side1, parent side2, child centers
# in a cube side l<=1 entirely inside parent. Full f=1 on a finite larger box.
# Exact 1D double-center integral of overlap is l^2-l^3/3.
# Tensorization is only for this product example, not for arbitrary f.
for n in [4,9,16,36,64,100]:
  for l in [F(1,4),F(1,2),F(1)]:
    integral=(l*l-l*l*l/3)**n/F(4)**n
    K=F(2)**(n-1) # explicit general-K theorem, strict child mass1<2^n/K=2
    An_upper=1+F(7,10)*n
    assert integral<=2/K and integral<=2*An_upper/K
    counts["native_tensor_centers"]+=1
# Exact elementary certificates used in analytic all-n argument.
def taylor(x,N):
    term=F(1); ans=term
    for j in range(1,N+1): term*=x/j;ans+=term
    return ans
assert taylor(F(7,10),7)>2 # log2<.7
assert taylor(F(3),4)>16
assert 2*(1+F(7,10)*9)<16
counts["parameter_and_positive_geometry"]+=1
# n100 positive native-center neighborhood, full f=.75 background + common packet .01.
# Child side1, nominal center separation .99 along coordinate2; each coordinate
# center perturbation |e|<d=1/10000. Both centers have coordinate1=1.1+e1.
n=100;d=F(1,10000)
geo_upper=F(1,100)+2*d
# exp(2.5)<3^3=27, so theta_geo>1/27.
assert geo_upper<F(1,27)
# alpha=exp(.1)<=10/9; centers are outside each other's alpha-cubes.
assert F(99,100)-2*d>F(5,9)
# Common packet can be placed in a fixed positive intersection (coordinate2 width .0098).
assert F(1,100)-2*d>0
# theta_source<=142/exp10<142/Taylor10; compare packet fraction .01/.76=1/76.
assert taylor(F(10),24)>142*76
# matched q_child=.76; q_parent=.75+.01/2^100. Strict far follows e^10<3^10.
assert (F(3,4)*2**n+F(1,100))/F(19,25)>3**10
assert F(11,10)-d>1
# Fixed source points firstcoord .7 secondcoord +/-.9: parent/exclusive with margin.
assert F(9,10)-(F(99,200)+d)<F(1,2)
assert F(9,10)+(F(99,200)-d)>F(1,2)
counts["parameter_and_positive_geometry"]+=1
print('PASS',counts,'total',sum(counts.values()))
print('Finite algebra does not certify native center bounds; native tensor checks do not certify original history. Positive geometry has full matched f and positive center blocks, but no original rank/stage/path qualification.')
