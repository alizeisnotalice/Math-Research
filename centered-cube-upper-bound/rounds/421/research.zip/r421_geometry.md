# R421：实际双见证的来源交叠软付款

2026-10-20。本稿在同一 R420 正测度上支付来源交叠较大的软份额。新估计使用完整匹配质量和真实中心积分，不从几何交叠体积推断来源质量。一般根阶上界及占用层 P 仍未证明。

## 1. 精确对象与候选

沿用 R420 的完整原场、阶段及双 exclusive 提升。实际立方体边长 R_v∈[a,b]，b≤2a；m_v=f(Q_v)=q_vR_v^n，q_-≤q_v≤λ；μ(dv)=dv/m_v，σ(dA)=q_A dA，π_A=f1_QA/m_A，X_q=∫σ。记 A_n=1+n log(b/a)，K=e^{√n}，s=1+√n，h=s/(ε_0q_-)。A_n 是原生占用常数，不是入口常数。

原父 A 的两个初始实际见证满足 m_w,m_t<M:=m_A/K。定义
\[
 I_{Av}=f(Q_A\cap Q_v),\quad I_{wt}=f(Q_w\cap Q_t),\quad
 I_{Awt}=f(Q_A\cap Q_w\cap Q_t),
\]
\[
 \omega_{\min}(w,t)=\frac{I_{wt}}{\min(m_w,m_t)},\qquad
 \omega_{\max}(w,t)=\frac{I_{wt}}{\max(m_w,m_t)}.
\]
它们在 [0,1] 内。Iwt 是完整 f 的交叠，不限于父盒。

本轮主命题是每个正质量父 A 的真实双后验矩
\[
 \mathcal M_A^{\min}:=
 \int\pi_A(dy)\pi_A(dz)
 \int_{m_w,m_t<M}c_w(y)c_t(z)\omega_{\min}(w,t)\,\mu(dw)\mu(dt)
 \le\frac{2A_n}{Kq_-^2}. \tag{1}
\]
该命题不同于单纯固定来源的占用包络：两份来源积分、父匹配质量、严格远质量和真实中心体积在同一个估计中结算。其费用见第4节。

实际提升仍含 c_w(y)(1-c_w(z))c_t(z)(1-c_t(y))，其两来源积分恰为
\[
 (I_{Aw}-I_{Awt})(I_{At}-I_{Awt})/m_A^2. \tag{2}
\]
原费用中不删除(2)、原 old-source 条件分布、clock、stage、first-death、early、soft、rank、路径或重尾门。只有证明上界时以 IAw IAt 支配(2)。

## 2. 完整匹配的两次抵消：主证明

令 F_M={v∈E:m_v<M}。两个实际中心事实为
\[
 J(x):=\int c_v(x)\mu(dv)\le A_n/q_-, \tag{3}
\]
\[
 \int_{F_M}I_{Av}\,dv
 =\int_{Q_A}f(x)|\{v\in F_M:x\in Q_v\}|dx
 \le m_A M/q_-. \tag{4}
\]
(3) 是已证的 selectable-side-length 原生包络，包括最小边长基底：(1+n log(b/a))/q_-。(4) 独立地使用 m_v≥q_-R_v^n：可行边长小于 (M/q_-)^{1/n}，捕获固定 x 的实际中心位于该边长的中心盒中，体积至多 M/q_-。若该边长≤a，严格 F_M 为空；同一上界仍成立。未将选择器边长当独立积分变量。

由正 Tonelli，(1) 左侧等于
\[
 m_A^{-2}\int_{F_M^2}\frac{I_{Aw}I_{At}}{m_wm_t}
 \frac{I_{wt}}{\min(m_w,m_t)}\,dw\,dt.
\]
用 1/min≤1/m_w+1/m_t。对于 1/m_w 项，先使用 IAw≤m_w；固定 t 的完整来源匹配给
\[
 \int_{F_M}\frac{I_{wt}}{m_w}dw
 =\int_{Q_t}f(x)\int_{F_M}c_w(x)\mu(dw)dx
 \le m_t A_n/q_-.
\]
于是该项至多
\[
 \frac1{m_A^2}\int_{F_M}\frac{I_{At}}{m_t}
 \frac{m_tA_n}{q_-}dt
 \le\frac{A_n}{Kq_-^2},
\]
最后一步是(4)。另一项对称，证明(1)。两个项只是上界估计，实际支付仍是同一个对称软份额；不再额外乘 union 因子2。

所有积分非负，可先截断再 Tonelli；实际 m_v≥q_-a^n>0。父零质量无费用。来源集中、mass atoms、闭盒边界均不破坏证明。没有使用来源坐标独立性，也没有把来源匹配替换成体积匹配。

## 3. 附带的较精细 max-mass 版本（不另收费）

同一场还满足
\[
 \mathcal M_A^{\max}\le\frac2{Kq_-^2}. \tag{5}
\]
证明保留实际质量比例。用 IAt≤m_t 后，对固定 w，
\[
 \int_{F_M}\frac{I_{wt}}{\max(m_w,m_t)}dt
 \le\frac{m_w}{q_-}\left(1+\log\frac M{m_w}\right). \tag{6}
\]
确实，交换完整 f 后，固定 x∈Qw；用 r=(2||t-x||∞)^n 的中心体积变量，有 m_t≥q_-r，且捕获中心只能在 r<M/q_- 内。因此其内积分至多
\[
 \int_0^{M/q_-}\frac{dr}{\max(m_w,q_-r)}
 =q_-^{-1}[1+\log(M/m_w)].
\]
这是真实中心支配，不是对任意选择器自由积分其边长。继续抵消 m_w，剩下
\[
 \frac1{q_-m_A^2}\int_{F_M}I_{Aw}[1+\log(M/m_w)]dw.
\]
再次交换来源，每个 x 的中心积分至多
\[
 \int_0^{M/q_-}[1+\log(M/(q_-r))]dr=2M/q_-.
\]
中心点 r=0 为 Lebesgue 零集，log 奇性可积；得到(5)。主账采用 min 版本，其补集控制交叠相对于较小质量；(5)不是额外费用或额外信用。

## 4. 真实正分拆与全部费用

任取 θ_s>0，在原 R420 的同一完整提升测度上定义
\[
 \chi_s(w,t)=\min\{1,\omega_{\min}(w,t)/\theta_s\},\quad
 P_{421}=R_{420}[\chi_s],\quad R_{421}=R_{420}[1-\chi_s]. \tag{7}
\]
这是精确非负分拆，R420=P421+R421。θ_s≥1 也合法，只是不保证任何整支付清；不要求另造原 Γ 或重算 Di。

使用已审 R411 同标签合同
\[
 B_L=\frac\beta{2L}+\frac{C_{\rm col}}{(2-\varepsilon_0)(L-\varepsilon_0)}.
\]
原 soft/两个 exclusive 分母的界分别为 1/(2Lh²) 和 1/[(2−ε_0)(L−ε_0)h²]。先在完整原标签空间用 early≤bi、首次撤流分拆、Γi 嵌套及 Σibi(z)≤1 合并所有阶段，再用逐来源 β/Ccol，最后放松其他正门，才得到
\[
 P_{421}\le\frac{B_L}{h^2\theta_s}\int\sigma(dA)\mathcal M_A^{\min}
 \le\frac{2A_nB_L}{\theta_sKq_-^2h^2}X_q. \tag{8}
\]
χs 依赖冻结的实际 A,w,t 场，不依赖 i；故这一步与同标签阶段求和相容。不能逐占用层重复收(8)。同一全层费用也控制任一原占用层正限制。

取
\[
 \theta_s=\frac{2A_n}{K},\qquad
 \Delta_{421}=\frac{B_L}{q_-^2h^2}=\frac{\varepsilon_0^2B_L}{s^2}. \tag{9}
\]
则 P421≤Δ421 Xq，无新增 W 价。n≥9 时 θ_s<1：ln2<7/10，置 x=√n≥3，则 2(1+0.7x²)e^{-x} 严格递减（导数符号为 −1−0.7(x²−2x)<0），其 x=3 值小于14.6/16<1，由 e³>16。低维沿旧主账，或仅使用一般(8)，不偷用高维整支结论。

按 R420 主文的冻结常数 C420、V413、Fhat=(1−32δ−16η)^{-1}，令 C421=C420+Δ421，得到
\[
 G_0\le16\widehat F[R_{421}+C_{421}X_q+V_{413}W],
\]
\[
 B_H\le32\widehat F R_{421}+[E_{387}+32\widehat F C_{421}]X_q
       +[S_{390}+8s+32\widehat F V_{413}]W. \tag{10}
\]
完整原入口仅替换该槽，新增 64ΛFhatΔ421 Xq，余项系数仍64ΛFhat。原入口 H、A_entrance,n、Wν、旧 W 费用和已用信用保持各一次。未重新分配原 ε 或宣布总吸收余额足够。

## 5. 完整补集与新增支的范围

R421 保留 R420 的全部原标签、双中心互相 α*=e^{1/√n} 膨胀盒外侧及
\[
 |Q_w\cap Q_t|<e^{-\sqrt n/4}\max(|Q_w|,|Q_t|).
\]
并带精确软权
\[
 \left(1-\frac{I_{wt}}{\theta_s\min(m_w,m_t)}\right)_+.
\]
因此正支上还有 Iwt<θ_s min(m_w,m_t)。这两个“小交叠”是分别通过付款获得的不同事实。前者本身绝不推出后者；本轮专门利用完整 f 匹配支付其差别。

几何上该支可以在上一轮补集中非空。一个可核的 n=100 连续中心模型：父边长2、中心0；子边长1；两中心分别在 (1.1,±.495,0,…,0) 周围半宽 d=1/10000 的中心盒中。完整 f 为有限大盒内常数 .75 加位于所有这些父/子共同交叠中的正体积 packet，packet 总质量 .01。则 m_child=.76，m_parent=.75·2^100+.01，全部 q∈[.75,1] 且 strict far。子几何交叠比≤.0102<e^{-2.5}，互中心又在 α* 膨胀盒外；但来源交叠比≥.01/.76=1/76>2A100/e^10。共同 packet 以外仍有正背景 exclusive 来源，两源差集质量乘积严格正。该示例证明实际匹配和连续中心几何相容，不认证原 own-past、stage、clock、删除及终端路径；不声称已构造完整 R420 正历史实例，也不保证每一输入有固定比例可付。

本轮支付完整来源交叠软份额，但尚未证明剩余 R421 或任意占用层的 tX+Ct^{-p}sW。新补集是两个真实见证的交叠在几何体积和完整来源质量上都小；exclusive 来源量仍可大，不能据此直接宣称树守恒或终端付款。

## 6. 本机验证与证明边界

实际运行 `python3 /tmp/r421_geometry_check.py`，输出保存在 `r421_geometry.result.txt`：

```
PASS {'finite_full_source_algebra': 96, 'native_tensor_centers': 18, 'parameter_and_positive_geometry': 2} total 116
```

96 个 Fraction 完整非均匀来源模型核对差集乘积(2)、双矩的 min 分解、实际 Jmax/中心占用替代常数、软份额精确和与上界。它们是有限正中心 quadrature，不能认证原生 Lebesgue 包络。18 个连续 Lebesgue 中心模型使用有限大盒均匀 f、子边长1/父边长2、中心盒边长 l∈{1/4,1/2,1}；一维中心交叠积分为 l²−l³/3，故 n 维矩精确为 ((l²−l³/3)/4)^n，n=4,9,16,36,64,100。只对此示例作乘积化，非一般 f 坐标独立。它们验证通用 K>1 命题的有理 K=2^{n−1} 参数，不冒充原 K=e^{√n} 的完整历史。

最后两组有理证书验证 ln2<.7、e³>16 的 Taylor 下界以及上述 n100 几何/完整来源模型的不等式余量。中心径向两次 log 积分与所有维数价格由第2–4节解析证明，不以浮点拟合或有限计数代替。没有新增外部理论、旧负平方信用或未经证明的来源密度帽。
