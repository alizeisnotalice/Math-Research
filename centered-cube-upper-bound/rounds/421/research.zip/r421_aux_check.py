from fractions import Fraction as F
from itertools import product
from math import isqrt
from pathlib import Path
import json

def box(c,s): return tuple((x-s/2,x+s/2) for x in c)
def vol(B):
    r=F(1)
    for a,b in B:r*=b-a
    return r
def incidence(C,B,R):
    yes=all(l>=v-R/2 and r<=u+R/2 for (l,r),(u,v) in zip(C,B))
    no=any(r<=u-R/2 or l>=v+R/2 for (l,r),(u,v) in zip(C,B))
    assert yes or no,'source incidence changes on center block'
    return int(yes)
def disjoint(C,D):return any(b<=c or d<=a for (a,b),(c,d) in zip(C,D))
def geom_upper(U,R,V,S):
    p=F(1)
    for (a,b),(c,d) in zip(U,V):
        dist=max(F(0),c-b,a-d)
        p*=max(F(0),min(R,S,(R+S)/2-dist))
    return p/max(R,S)**len(U)

def model(n,Rt,qw,qt,l,overlap,outer=False,diagonal=False):
    M=F(2**n); mw=qw; mt=qt*Rt**n
    k=isqrt(n)+(isqrt(n)**2<n); K=F(3**k)
    assert M>K*max(mw,mt)
    c=F(9,20) if diagonal else F(3,10)
    wc=(-c,)*n if diagonal else (-c,)+(F(0),)*(n-1)
    tc=(c,)*n if diagonal else ((F(1,2) if outer else c),)+(F(0),)*(n-1)
    groups=[(box(wc,l),F(1)),(box(tc,F(1,16) if outer else l),Rt)]
    parent=box((F(0),)*n,F(1,32)); Rp=F(2)
    outmass=mt/4 if outer else F(0)
    common=overlap*min(mw,mt-outmass); src=[]
    def add(c,s,m):
        if m:src.append((box(c,s),m))
    side=F(1,64) if diagonal else F(1,16)
    add((F(0),)*n,side,common)
    lc=(F(-5,8),)*n if diagonal else (F(-5,8),)+(F(0),)*(n-1)
    rc=(F(5,8),)*n if diagonal else (F(5,8),)+(F(0),)*(n-1)
    add(lc,side,mw-common);add(rc,side,mt-outmass-common)
    ballast=(F(-7,8),F(7,8))+(F(0),)*(n-2) if diagonal else (F(7,8),)*n
    add(ballast,F(1,16),M-(mw+mt-outmass-common))
    if outer:add((F(17,16),)+(F(0),)*(n-1),F(1,128),outmass)
    assert all(disjoint(C,D) for i,(C,_) in enumerate(src) for D,_ in src[i+1:])
    assert all(disjoint(U,V) for i,(U,_) in enumerate(groups+[(parent,Rp)]) for V,_ in (groups+[(parent,Rp)])[i+1:])
    def mass(B,R):return sum(m*incidence(C,B,R) for C,m in src)
    assert mass(parent,Rp)==M
    ms=[mass(B,R) for B,R in groups];assert ms==[mw,mt]
    q=min(F(1),qw,qt);assert F(3,4)<=q and max(qw,qt)<=1
    Is=[sum(m*incidence(C,parent,Rp)*incidence(C,B,R) for C,m in src) for B,R in groups]
    rawmax=rawmin=first=second=F(0); lowgeom_highsource=0
    for i,(U,R) in enumerate(groups):
        for j,(V,S) in enumerate(groups):
            I=sum(m*incidence(C,U,R)*incidence(C,V,S) for C,m in src)
            base=vol(U)*vol(V)*Is[i]*Is[j]/(M*M*ms[i]*ms[j])
            rawmax+=base*I/max(ms[i],ms[j]);rawmin+=base*I/min(ms[i],ms[j])
            first+=base*I/ms[i];second+=base*I/ms[j]
            assert I<=min(ms[i],ms[j])
            if i!=j and geom_upper(U,R,V,S)<F(1,3**k) and I/min(ms[i],ms[j])>=F(1,2):lowgeom_highsource+=1
    Alower=1+F(2*n,3) # log 2 > 2/3, so this tests a STRICTER bound than true A_n.
    capmax=2/(K*q*q);capmin=2*Alower/(K*q*q)
    assert 0<rawmax<=rawmin<=first+second
    assert rawmax<=capmax and rawmin<=capmin
    assert first<=Alower/(K*q*q) and second<=Alower/(K*q*q)
    if outer:assert Is[1]<ms[1]
    return {'n':n,'outer':outer,'diagonal':diagonal,'rawmax':str(rawmax),'rawmin':str(rawmin),'max_ratio':str(rawmax/capmax),'min_ratio':str(rawmin/capmin),'min_gt_max':rawmin>rawmax,'lowgeom_highsource_pairs':lowgeom_highsource}

stages={
 'concentrated':[(n,F(1),q,F(1),F(1,64),o,False,True) for n,q,o in product([9,16],[F(3,4),F(1)],[F(1,2),F(1)])],
 'parent_external':[(n,F(5,4),q,F(1),F(1,8),o,True,False) for n,q,o in product([9,16],[F(3,4),F(1)],[F(0),F(1,2),F(1)])],
 'expanded':[(n,R,q,F(1),F(1,16),o,False,False) for n,R,q,o in product([25,36,64],[F(1),F(5,4)],[F(3,4),F(1)],[F(0),F(1,2),F(1)])]
}
results={name:[model(*row) for row in rows] for name,rows in stages.items()}
flat=[x for rows in results.values() for x in rows]
summary={'counts':{k:len(v) for k,v in results.items()},'total':len(flat),'positive':len(flat),'min_gt_max':sum(x['min_gt_max'] for x in flat),'lowgeom_highsource_pairs':sum(x['lowgeom_highsource_pairs'] for x in flat),'external_models':sum(x['outer'] for x in flat),'max_ratio':str(max(F(x['max_ratio']) for x in flat)),'min_ratio':str(max(F(x['min_ratio']) for x in flat))}
Path(__file__).with_name('r421_aux_result.json').write_text(json.dumps({'summary':summary,'results':results},indent=2)+'\n')
print('PASS',summary)
print('Exact continuous center blocks and full nonuniform L1 sources; all cube side lengths in [1,2], q in [3/4,1]. K certified above exp(sqrt(n)).')
print('No original R414/R420 stage, rank, history or final remaining-mask qualification claimed.')
print('r421_aux_result.json')
