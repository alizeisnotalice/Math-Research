# R421 independent audit — frozen

FINAL PASS within the stated R421 scope: native full-source min-mass joint moment, max-mass auxiliary moment, same-lift soft-fraction payment and complete displayed accounting. Independent derivation preceded author reading. Final main/README, both proofs and scripts reviewed; both scripts independently rerun, stdout and auxiliary JSON reproduced byte-for-byte. No full R421/root budget, P, universal positive fraction or complete-history nonempty fixture is certified. Only this audit file edited.

## Independent full-source moment verification

Let F_M={v:0<m_v<M}, M=m_A/K, I_Av=f(Q_A∩Q_v), I_wt=f(Q_w∩Q_t). These intersections use the SAME complete f, including source outside Q_A. Positive Tonelli converts the double π_A source integral into

m_A^-2∫_{F_M²} I_Aw I_At I_wt/[m_wm_t min(m_w,m_t)] dw dt.

Use1/min≤1/m_w+1/m_t. In the1/m_t term first I_At≤m_t, then

∫_{F_M}I_wt/m_t dt=∫_{Q_w}f(x)∫_{F_M}c_t(x)μ(dt)dx≤m_w J_max.

Thus that term is≤J_max m_A^-2∫_{F_M}I_Aw dw. Native selectable-side capture gives J_max=A_n/q_-, with its minimum-side base term retained. Strict far mass gives R_w<(M/q_-)^(1/n), so for each source y its admissible capturing center volume is≤M/q_-. Hence ∫_{F_M}I_Aw dw≤m_A M/q_- and the term is≤A_n/(Kq_-²). The symmetric term has the same price, yielding

S_A^min≤2A_n/(Kq_-²).

No coordinate independence, source-density cap, new receiver, q upper-factor or source-product-to-volume substitution occurs. The center-volume estimate is applied only AFTER integrating the true intersection masses. Strict mass atoms are excluded exactly; if(M/q_-)^(1/n)≤a the witness family is empty, including equality. All actual denominators are positive; zero parent mass has no original cost. Positive truncation/Tonelli gives the assertions without any∞−∞ manipulation.

The actual exclusive source integral remains (I_Aw−I_Awt)(I_At−I_Awt)/m_A². It is only upper-bounded by I_Aw I_At for the moment estimate. I_wt must NOT be replaced by I_Awt or geometric intersection volume. The proofs and tests retain this distinction.

## Independently verified max-mass supplement

For the max-mass normalized raw moment, cancel I_At≤m_t. For fixed w and source x∈Q_w, the true capturing t centers satisfy q_-ρ^n≤m_t<M, ρ=2||t−x||∞. Their integral of1/max(m_w,m_t) is at most

∫_0^{M/q_-}dv/max(m_w,q_-v)=[1+log(M/m_w)]/q_-.

Integrating full f over Q_w contributes m_w, cancelling the remaining m_w denominator. Swapping I_Aw with the original parent source then bounds the remaining center integral by

∫_0^{M/q_-}[1+log(M/(q_-v))]dv=2M/q_-.

Therefore S_A^max≤2/(Kq_-²). The origin has zero center measure and an integrable logarithmic singularity. Neither selected sides nor masses are integrated as independent free variables. This supplement does not use the A_n octave cap, and it is NOT another receipt. Min/max normalization and threshold choices differ; no paid-set inclusion or additive credit between the two variants is inferred.

## Original lift, soft fraction, threshold and price

On the SAME original R420 label space define θ_s=2A_n/K and χ=min(1,ω_min/θ_s). Then χ∈[0,1], χ≤ω_min/θ_s, and R420=P421+R421 exactly with factorsχ and1−χ. No new witness draw, normalized posterior or reconstructed Γ_i/D_i is introduced. The residual carries precisely(1−ω_min/θ_s)_+ and on its positive support I_wt<θ_s min(m_w,m_t). Equality at the source threshold is fully paid. These statements are valid for positive θ_s; n≥9 additionally ensuresθ_s<1.

The all-high-dimension threshold assertion is correct: A_n≤1+n log2<1+.7n, log2<.7 follows from a positive Taylor lower bound for e^.7, and e>2.5. For x=√n≥3, (2+1.4x²)e^-x is strictly decreasing and its value at3 is<14.6/(2.5)^3<1. The author's alternative e³>16 certificate is also valid. No floating exponential is required. Low-dimensional complete-core handling remains separate.

Original R411 soft/exclusive denominator bounds remain1/(2Lh²) externally and1/[(2−ε0)(L−ε0)h²] at the small endpoint. Common early/first-deletion stage summation uses the SAME original new z and Σ_i b_i(z)≤1, then original sourcewiseβ/C_col. The new χ depends only on frozen initial w,t and the full field, not a rebuilt schedule; later R420 probability restrictions may be dropped for a positive upper bound. Therefore

P421≤[B_L/(h²θ_s)]∫σ(dA)S_A^min
≤[2A_nB_L/(θ_sKq_-²h²)]X_q
=[B_L/(q_-²h²)]X_q=Δ421 X_q,
Δ421=ε0² B_L/(1+√n)².

B_L already includes both original endpoint caps. There is no extra union2, S, τ^-1 or λ/q_- and no new W price. The factor2 in the moment came from the min decomposition, not two separately charged events. All occupation layers and stages are one positive partition and are charged once. The hard threshold subevent and max-mass version are not charged again.

The residual retains all old source/clock/history/rank/early/cubic/current/initial/terminal labels, R419 mutual expanded-center exclusion and R420 small geometric overlap, plus its new soft weight. Its two full witness posteriors give the other box probability<θ_s and have affinity I_wt/√(m_wm_t)<θ_s. These are only pairwise consequences on actual surviving labels; they do not establish global orthogonality, covering, Carleson settlement, source refresh or history eligibility.

## Accounting and event ownership

This is a positive split INSIDE current R420, so no previous paid branch is charged again. The source-mass event differs from small Lebesgue overlap: arbitrary f may concentrate in that geometric intersection. Partial native models establish that those two quantities need not be small together, but do not certify a full original-history branch.

The final account retains Δ419, the D_n-containing Δ420 and all C413/V413 fees, and adds onlyΔ421 to form C421. Fhat=(1−32δ−16η)^−1 is unchanged; there is no newηG0 feedback. The coefficients16Fhat/32Fhat/64ΛFhat at G0/BH/entrance are correct; outside E387,S390,8s,H,A_entrance and all original source fees stay unchanged. No already used negative/cross/clock credit is restored, and no total X absorption is certified. General R421 and occupation-layer P remain open.

## Independent code runs and evidence scope

Final geometry script independently rerun:116 Fraction records, stdout byte-identical to delivered result. Its96 finite source-incidence/quadrature models verify full-mass algebra, exclusive-product identity, min decomposition and the soft split using their ACTUAL discrete J/capture constants. They do not test the native radial center bound. The18 native tensor fixed-parent center integrals correctly use(l²−l³/3)^n/4^n for uniform f and equal child side1; their K=2^(n−1) tests the general-K theorem, not an original complete history. The final2 records concern elementary parameter inequalities and a positive full-f center-block geometry construction.

The latter construction's background plus common packet yields matched child mass.76 and positive parent-exclusive background; the common packet can be placed in the fixed positive parent/child intersection. Its geometric overlap bound, mutual-center exclusion, source-overlap lower bound1/76, strict far mass and parent-outside margins are valid. The script tests selected fixed source points/exclusivity, not all original source-collar/current-D/own-past/heavy-tail/clock/history/terminal gates. No complete R420 nonempty or positive coverage fraction is certified by these records.

The auxiliary script was rerun in an isolated temporary directory so no author JSON was overwritten. Both regenerated stdout and JSON matched final delivered bytes. Its56 full nonuniform L1/continuous-center configurations are[8,12,36]. Source boxes and parent/child center blocks are disjoint as declared, and their all-or-nothing incidences are checked throughout each block. All masses/intersections thus follow the same full f; all selected sides lie in[1,2] and q∈[3/4,1]. In the12 exterior-source models I_At<m_t is genuine. The K_cert=3^ceil√n test is stricter than native K, and A_lower=1+2n/3<1+n log2 makes those particular finite min-bound tests stronger; this does not substitute for the general analytic proof.

The reported56 positive raw moments,30 min>max models and48 directed low-geometric/high-source-overlap pairs are reproduced exactly. They are RAW moment/partial geometry tests, not positive original exclusive/history costs; some common-source choices can make an exclusive numerator vanish despite a positive raw moment. The directed-pair count is not a number of complete flow instances. These records are not pooled with116 heterogeneous records as native full-contract samples. No floating calculation is used as a strict certificate here.

The auxiliary VC discussion is only a bounded scope observation: finite box-pattern complexity and the actual μ(E_<) normalization do not yield a source fee, and replacing μ by a posterior-weighted measure changes the original ranks. It is not a new theorem input or a second receipt. Workflow-skill labels provide no unverified external transfer theorem.

Final main/README and proofs have consistent prices and scopes. No substantive correction remains. The source-overlap fractional branch is paid at the stated X_q price; full root closure remains unproved.

## SHA-256 bindings

Final reviewed bytes below; later generated TeX/manifest/archive bytes are not bound by this record.

- `r421_main.md`: `edb53a0ba24542b06ad7d8562480dd0346ff5256cd105227fb13ee0a9f135ab7`
- `r421_readme.md`: `7c3a65ef19d614805f5ce5b6e4e9346944435f08cb15e6aac97152aec2f424b8`
- `r421_geometry.md`: `49e50cd47b517ab8bdb0fe055b2308f18eca2bfb288f2623f3ebfe52613ec7fc`
- `r421_aux.md`: `26813f2c2bd27417ab16d40ea21108269ffe7d5a65af24f7cbe70bc71937b136`
- `r421_geometry_check.py`: `3fab837fb098affb84b8174f5c4548805fc833682bcafac5e6eee5db31277e5d`
- `r421_aux_check.py`: `d18556fa7eb9c4370f0f49fade334a3943d1d11573d935be559123d01f91f18b`
- `r421_geometry.result.txt`: `98271b3fcfda6e9d7e8a6192e8d6baebb4a6cd33f969b64cf49e944c5e80b6a6`
- `r421_aux.result.txt`: `8c4e16d3677de77bf4cc29b3ed82a68b1d6d137330ef663edd8a9be1ea71e7de`
- `r421_aux_result.json`: `40ae6025ce52d311b9e00d55f49827fd956c13df6a1631cd43b90476212479a8`
- `r420_main.md`: `b2700b4186ff53dfd5df571e5c6e6b05497e9022c0ab3d8ba0a3d536033687e4`
- `r411_aux.md`: `08877dd6346771a4711a454fbf7704db27d0fd3a05f2dfbab45d69e0ac2c3823`
- `r414_main.md`: `4b22ddb135ac2f13eb1f282b7e5c965b293f2ea4ec259d5efa8a6f961e390ddc`

Frozen conclusion: one once-only soft fractional payment, no new W fee, no general remaining root budget.
