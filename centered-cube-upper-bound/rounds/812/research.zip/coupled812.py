#!/usr/bin/env python3
"""Exact valued two-sided flow for the shared source-pair contracts of R812."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from heapq import heappop, heappush
import json
from math import lcm
from pathlib import Path
import platform

from pairs812 import contracts, target_cells, total

ZERO=F(0)


def current_rows(stage,law,outward):
    parents={x["id"]:x for x in stage["parents"]}
    old={i:x for i,x in parents.items() if x["role"]=="old"}
    source={x["mask"]:F(x["mass"]) for x in stage["cells"]}
    reference,joint,maps=contracts(stage,law["law"],old,parents,source)
    saved=[(t,z,q,F(a),F(b),L,R,U,V) for t,z,q,a,b,L,R,U,V in law["all_actual_source_pairs"]]
    modes=tuple(maps)
    rebuilt=[(t,z,q,reference[t,z,q],joint[t,z,q],
              *(direction[t,z,q] for rule in maps.values() for direction in rule)) for t,z,q in sorted(reference)]
    assert rebuilt==saved
    assert total(reference.values())==F(law["reference_Lambda"]) and total(joint.values())==F(law["original_Gamma"])
    target={int(mask):F(v) for mask,v in outward.items()}
    assert target==target_cells(stage,old)
    return saved,modes,target


def make_network(rows,target,rule,theta,kappa):
    # Vertex order is s, left target cells, row entries/exits, right target cells, t.
    left={j:k+1 for k,j in enumerate(target)}
    base=1+len(left)
    right={j:k+base+2*len(rows) for k,j in enumerate(target)}
    sink=base+2*len(rows)+len(right)
    required_index=5+2*rule
    big=1+theta*total(row[3] for row in rows)
    edges=[]
    middle=[]
    for j,w in target.items():
        edges.append((0,left[j],kappa*w,ZERO))
    for k,row in enumerate(rows):
        value,ref=row[4],row[3]
        Li,Ri=row[required_index:required_index+2]
        enter,exit=base+2*k,base+2*k+1
        for j in target:
            if j&Li==Li:
                edges.append((left[j],enter,big,ZERO))
        middle.append(len(edges))
        edges.append((enter,exit,theta*ref,-value/ref))
        for j in target:
            if j&Ri==Ri:
                edges.append((exit,right[j],big,ZERO))
    for j,w in target.items():
        edges.append((right[j],sink,kappa*w,ZERO))
    mass_den=lcm(*(e[2].denominator for e in edges))
    cost_den=lcm(*(e[3].denominator for e in edges))
    scaled=[(u,v,int(cap*mass_den),int(cost*cost_den)) for u,v,cap,cost in edges]
    assert all(F(c,mass_den)==r[2] and F(w,cost_den)==r[3] for (u,v,c,w),r in zip(scaled,edges))
    return scaled,middle,sink,mass_den,cost_den


def feasible_potentials(n,arcs):
    """All vertices attach to an artificial source by zero-cost edges."""
    potential=[0]*n
    for _ in range(n):
        changed=False
        for u,v,c in arcs:
            if potential[u]+c<potential[v]:
                potential[v]=potential[u]+c
                changed=True
        if not changed:
            return potential
    raise AssertionError("negative-cost residual cycle")


def solve(edges,sink):
    n=sink+1
    adjacency=[[] for _ in range(n)]
    records=[]
    remaining=[]
    for u,v,cap,cost in edges:
        adjacency[u].append(len(records))
        records.append((v,cost))
        remaining.append(cap)
        adjacency[v].append(len(records))
        records.append((u,-cost))
        remaining.append(0)
    potential=feasible_potentials(n,[(u,v,c) for u,v,a,c in edges if a])
    sent=0
    iters=0
    while True:
        dist=[None]*n
        pred=[None]*n
        dist[0]=0
        queue=[(0,0)]
        while queue:
            d,u=heappop(queue)
            if d!=dist[u]:
                continue
            for j in adjacency[u]:
                if not remaining[j]:
                    continue
                v,c=records[j]
                reduced=c+potential[u]-potential[v]
                assert reduced>=0
                step=d+reduced
                if dist[v] is None or step<dist[v]:
                    dist[v]=step
                    pred[v]=j
                    heappush(queue,(step,v))
        if dist[sink] is None or dist[sink]-potential[0]+potential[sink]>=0:
            break
        fallback=max(d for d in dist if d is not None)
        potential=[u+(fallback if d is None else d) for u,d in zip(potential,dist)]
        path=[]
        v=sink
        while v:
            j=pred[v]
            path.append(j)
            v=records[j^1][0]
        assert len(path)<=n-1
        delta=min(remaining[j] for j in path)
        sent+=delta
        iters+=1
        for j in path:
            remaining[j]-=delta
            remaining[j^1]+=delta
    flow=[remaining[2*k+1] for k in range(len(edges))]
    arcs=[]
    for (u,v,cap,c),x in zip(edges,flow):
        if x<cap:
            arcs.append((u,v,c))
        if x:
            arcs.append((v,u,-c))
    # Add the optional return edge to certify unrestricted total flow, not just fixed-value cost.
    arcs.append((sink,0,0))
    if sent:
        arcs.append((0,sink,0))
    dual=feasible_potentials(n,arcs)
    return dict(flow_by_edge=[[k,x] for k,x in enumerate(flow) if x],node_potentials=dual,augmentations=iters)


def exact_optimum(edges,middle,sink,saved):
    sparse=dict(saved["flow_by_edge"])
    flow=[sparse.get(k,0) for k in range(len(edges))]
    assert len(sparse)==len(saved["flow_by_edge"]) and all(0<=k<len(edges) and v>0 for k,v in sparse.items())
    dual=saved["node_potentials"]
    assert len(dual)==sink+1
    total_flow=sum(flow[i] for i in middle)
    return_cap=1+sum(edges[i][2] for i in middle)
    arcs=edges+[(sink,0,return_cap,0)]
    balance=[0]*(sink+1)
    primal,dual_bound=0,0
    for (u,v,limit,c),x in zip(arcs,flow+[total_flow]):
        assert 0<=x<=limit
        balance[u]+=x
        balance[v]-=x
        r=c+dual[u]-dual[v]
        assert (x==limit or r>=0) and (x==0 or r<=0)
        primal+=c*x
        dual_bound+=limit*min(0,r)
    assert all(x==0 for x in balance) and primal==dual_bound<=0
    return -primal,total_flow,flow


def standalone_cut_benchmark(rows,target,rule,frozen,theta,kappa):
    paid_rows=set(range(len(rows)))
    side_inputs=[]
    for s,LorR in enumerate(("left","right")):
        req_i=5+2*rule+s
        cert=frozen[LorR]
        bad=set(cert["deficient_source_requirements"])
        paid_rows&={k for k,h in enumerate(rows) if h[req_i] not in bad}
        flow={(i,j):F(v) for i,j,v in cert["primal_flow_by_requirement"]}
        budget={int(i):F(v) for i,v in cert["source_reference_by_requirement"].items()}
        assert all(i&j==i and v>=0 for (i,j),v in flow.items())
        side_inputs.append((req_i,flow,budget))
    for req_i,flow,budget in side_inputs:
        by_target=defaultdict(F)
        for k in paid_rows:
            row=rows[k]
            r=row[req_i]
            pieces=[(j,w*row[3]/budget[r]) for (i,j),w in flow.items() if i==r]
            assert total(w for j,w in pieces)==theta*row[3]
            for j,w in pieces:
                by_target[j]+=w
        assert all(v<=kappa*target[j] for j,v in by_target.items())
    true_mass=theta*total(rows[k][4] for k in paid_rows)
    assert true_mass==F(frozen["original_shared_coin_paid_mass"])
    return true_mass,len(paid_rows)


def run_case(rows,modes,target,case,previous=None):
    theta,kappa=F(case["theta"]),F(case["right_Lebesgue_multiplier"])
    M=total(row[4] for row in rows)
    L=total(row[3] for row in rows)
    results={}
    for k,name in enumerate(modes):
        arcs,central,sink,mass_den,cost_den=make_network(rows,target,k,theta,kappa)
        cert=solve(arcs,sink) if previous is None else previous["modes"][name]["certificate"]
        paid,amount,flow=exact_optimum(arcs,central,sink,cert)
        paid_mass=F(paid,mass_den*cost_den)
        by_middle=defaultdict(F)
        for row,i in zip(rows,central):
            by_middle[row[0]]+=F(flow[i],mass_den)*row[4]/row[3]
        assert total(by_middle.values())==paid_mass
        benchmark,nrows=standalone_cut_benchmark(rows,target,k,case["methods"][name],theta,kappa)
        assert benchmark<=paid_mass<=theta*M
        results[name]=dict(original_optimum_paid_mass=paid_mass,original_optimum_paid_rate=paid_mass/M,
                           improvement_over_separate_cut_paid_rate=(paid_mass-benchmark)/M,
                           separate_cut_original_paid_rate=benchmark/M,separate_cut_fully_admitted_rows=nrows,
                           actual_pushed_reference_rate=F(amount,mass_den)/L,original_paid_by_t=dict(by_middle),
                           nonzero_pair_flow=[[j,flow[i]] for j,i in enumerate(central) if flow[i]],
                           whole_network_arc_count=len(arcs),whole_network_vertex_count=sink+1,
                           mass_denominator=mass_den,cost_denominator=cost_den,certificate=cert)
    A,B=results.values()
    assert A["original_optimum_paid_mass"]<=B["original_optimum_paid_mass"]
    return dict(case=case["name"],theta=theta,right_Lebesgue_multiplier=kappa,
                effective_right_multiplier=kappa/theta,
                exact_joint_paid_rate_gain_B_minus_A=B["original_optimum_paid_rate"]-A["original_optimum_paid_rate"],
                modes=results)


def certificate(comb_path,prior_path,old_output=None):
    comb=json.loads(comb_path.read_text())
    prior=json.loads(prior_path.read_text())
    replay={} if old_output is None else {(x["dimension"],x["law"]):x for x in old_output["comparisons"]}
    assert sha256(comb_path.read_bytes()).hexdigest()==prior["inputs_sha256"]["comb811.json"]
    records=[]
    for physical,fixture in zip(comb["stages"],prior["stages"],strict=True):
        n=physical["dimension"]
        assert n==fixture["dimension"]
        for law in fixture["laws"]:
            label=law["law"]
            if label=="all" and n!=4:
                continue
            rows,modes,target=current_rows(physical,law,fixture["target_Lebesgue_by_old_expanded_membership"])
            names={"unit","pressure_4/5_of_A_capacity"}
            if n==4 and label=="cross":
                names.add("pressure_1/2_of_A_capacity")
            old=replay.get((n,label))
            saved={} if old is None else {c["case"]:c for c in old["cases"]}
            cases=[run_case(rows,modes,target,s,saved.get(s["name"])) for s in law["cases"] if s["name"] in names]
            assert cases and all(x["original_optimum_paid_rate"]==1 for x in cases[0]["modes"].values())
            records.append(dict(dimension=n,law=label,original_Gamma=F(law["original_Gamma"]),reference_Lambda=F(law["reference_Lambda"]),
                                original_source_pairs=len(rows),cases=cases))
    return dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
                inputs_sha256={"comb811.json":sha256(comb_path.read_bytes()).hexdigest(),
                               "pairs812.json":sha256(prior_path.read_bytes()).hexdigest(),
                               "pairs812.py":sha256(Path(__file__).with_name("pairs812.py").read_bytes()).hexdigest()},
                certificate="Integer scaling is exact. Flow conserves the same amount through the entrance and exit of every true price pair. Reduced-cost inequalities on forward and reverse residual arcs, including the optional t-to-s edge, give a dual objective equal to the exact primal.",
                flow_layout="The original network edges are in make_network order. Flow integers divide by mass_denominator and edge cost/dual integers divide by cost_denominator. The zero-cost return edge is implicit, with its flow equal to the sum of all middle-edge flows.",
                scope="Finite genuine R811 comb contracts with the frozen R812 original two-price Gamma, Lambda and full d. A builds eligible target sets from its own price plus t; B uses both prices plus t. The common row throughput can depend on both prices in either mode. Separate Lebesgue pages on the two sides are each shared across all central fathers. Pressure cases change their common Lebesgue multiplier.",
                reproducibility="python -B coupled812.py --comb <comb811.json> --prior pairs812.json --check coupled812.json",
                comparisons=records)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comb",type=Path,required=True)
    parser.add_argument("--prior",type=Path,default=Path("pairs812.json"))
    modes=parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--output",type=Path)
    modes.add_argument("--check",type=Path)
    args=parser.parse_args()
    old=json.loads(args.check.read_text()) if args.check else None
    data=certificate(args.comb,args.prior,old)
    contents=(json.dumps(data,sort_keys=True,indent=2,default=str)+"\n").encode()
    if args.output:
        args.output.write_bytes(contents)
    else:
        assert args.check.read_bytes()==contents
    for d in data["comparisons"]:
        for case in d["cases"]:
            fmt=lambda x: f"{float(x):.10g}"
            print(d["dimension"],d["law"],case["case"],
                  [(fmt(x["separate_cut_original_paid_rate"]),fmt(x["original_optimum_paid_rate"]),
                    x["certificate"]["augmentations"]) for x in case["modes"].values()])
    if args.check:
        print("exact primal/dual replay; byte-identical")


if __name__=="__main__":
    main()
