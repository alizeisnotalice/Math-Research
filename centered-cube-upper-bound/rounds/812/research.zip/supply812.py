#!/usr/bin/env python3
"""Audit cross-supplier capacity and optimize a joint budget for the continuous comb."""
import argparse
import json
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from math import lcm, prod
from pathlib import Path

from coupled812 import exact_optimum, solve
from pairs812 import by_frozen_roots, reconstruct

ZERO = F(0)
ONE = F(1)


def box(parent, key):
    return tuple((F(lo), F(hi)) for lo, hi in parent[key])


def overlap(*boxes):
    return prod(max(ZERO, min(x[1] for x in intervals) - max(x[0] for x in intervals))
                for intervals in zip(*boxes))


def transport(left, right, reward, require_full=False):
    """Exact finite optimum with a checked residual-potential dual."""
    m, n = len(left), len(right)
    sink = 1 + m + n
    scale = lcm(*(v.denominator for v in left + right))
    values = [q + int(require_full) for q in reward]
    denom = lcm(*(x.denominator for x in values))
    upper = sum(left) + sum(right) + 1
    edges = [(0, 1+i, int(v*scale), 0) for i, v in enumerate(left)]
    edges += [(1+i, 1+m+j, int(upper*scale), -int(values[i*n+j]*denom))
              for i, j in product(range(m), range(n))]
    edges += [(1+m+j, sink, int(v*scale), 0) for j, v in enumerate(right)]
    cert = solve(edges, sink)
    scaled_value, mass, flow = exact_optimum(edges, list(range(m)), sink, cert)
    mass = F(mass, scale)
    if require_full:
        assert mass == sum(left) == sum(right)
    pairs = {(i, j): F(flow[m+i*n+j], scale)
             for i, j in product(range(m), range(n)) if flow[m+i*n+j]}
    value = F(scaled_value, scale*denom) - int(require_full)*mass
    assert value == sum(pairs[i,j]*reward[i*n+j] for i,j in pairs)
    return value, pairs


def check_stage(stage):
    parents = {p["id"]: p for p in stage["parents"]}
    suppliers = {i: p for i,p in parents.items() if p["role"] == "old"}
    names = list(suppliers)
    masses = {i: F(p["m"]) for i,p in parents.items()}
    bits = {i: p["bit"] for i,p in parents.items()}
    weights = {i: F(p["j"])/masses[i] for i,p in parents.items()}
    cells = {c["mask"]: F(c["mass"]) for c in stage["cells"]}
    mask = sum(bits[i] for i in names)
    load = F(1, max((s & mask).bit_count() for s in cells))
    a = {i: load*masses[i] for i in names}
    assert all(load*(s & mask).bit_count() <= 1 for s in cells)
    for i in parents:
        assert sum(w for s,w in cells.items() if s & bits[i]) == masses[i]
    assert sum(a.values()) <= sum(cells.values())
    traces = []
    largest_ratio = ZERO
    for i,j in product(names, repeat=2):
        cutoff = max(masses[i], masses[j])
        full = ZERO
        for t in stage["middle_labels"]:
            if masses[t] < cutoff:
                continue
            zi = sum(w for s,w in cells.items() if s & bits[t] and s & bits[i])
            qj = sum(w for s,w in cells.items() if s & bits[t] and s & bits[j])
            full += F(parents[t]["j"])*zi*qj/masses[t]**2
        ratio = full/min(masses[i],masses[j])
        largest_ratio = max(largest_ratio, ratio)
        traces.append((i, j, full, ratio))
    # The owner cores are disjoint, j_i <= |E_i|. For bins [M,2M)
    # sum b_t <= 2(1+1/(32n))**n, and summing over M adds a factor 2.
    assert largest_ratio <= 4*F(stage["h"])**stage["dimension"]
    hit = {(i,u): overlap(box(suppliers[i],"box"),box(suppliers[u],"expanded_box"))/masses[i]
           for i,u in product(names,repeat=2)}
    results = []
    for law in ("all", "cross"):
        ref, joint, ops = reconstruct(stage, law, suppliers, parents, cells)
        independent_roots, other_ops = by_frozen_roots(stage,law,parents,cells)
        assert joint == independent_roots and ops == other_ops
        reward = {(i,j): ZERO for i,j in product(names,repeat=2)}
        free_pair, coupled_pair, improved = ZERO, ZERO, 0
        for h, mass in joint.items():
            t,z,q = h
            labels = sorted(ops[h])
            coeff = {k: weights[k[0]]*weights[k[1]] for k in labels}
            norm = sum(coeff.values())
            assert mass == ref[h]*norm/F(parents[t]["full_d"])
            left = [i for i in names if z & bits[i] and masses[i] <= masses[t]]
            right = [j for j in names if q & bits[j] and masses[j] <= masses[t]]
            assert left and right
            phit = [sum(coeff[u,g]*hit[i,u]*hit[j,g] for u,g in labels)/norm
                    for i,j in product(left,right)]
            rows = [F(1,len(left))]*len(left)
            cols = [F(1,len(right))]*len(right)
            available, _ = transport(rows,cols,phit,require_full=True)
            indep = sum(phit)/len(phit)
            assert ZERO <= indep <= available <= ONE
            free_pair += mass*indep
            coupled_pair += mass*available
            improved += int(available > indep)
            for (i,j),v in zip(product(left,right),phit):
                reward[i,j] += mass*v/min(masses[i],masses[j])
        labels = list(product(names,repeat=2))
        values = [reward[ij] for ij in labels]
        capacities = [a[i] for i in names]
        optimal, plan = transport(capacities,capacities,values)
        diagonal = sum(a[i]*reward[i,i] for i in names)
        assert ZERO <= diagonal <= optimal
        # With D=max(m_i,m_j), the total row coefficient of ANY graph is <=2.
        max_row = max(sum(w/min(masses[names[i]],masses[names[j]]) for (i,j),w in plan.items()
                          if z & bits[names[i]] and q & bits[names[j]]
                          and masses[t] >= max(masses[names[i]],masses[names[j]]))
                      for t,z,q in joint)
        assert max_row <= 2
        total = sum(joint.values())
        results.append(dict(law=law, actual_rows=len(joint), true_mass=total,
                            supplier_weight=load, independent_fraction=free_pair/total,
                            coupled_fraction=coupled_pair/total, strict_rows=improved,
                            diagonal_raw_fraction=diagonal/total,
                            optimal_graph_raw_fraction=optimal/total,
                            fixed_half_graph_paid_fraction=optimal/(2*total),
                            max_active_graph_weight=max_row,
                            optimal_edges=[[names[i],names[j],w] for (i,j),w in sorted(plan.items())]))
    return dict(dimension=stage["dimension"],auxiliary_family=names,
                sum_packing_mass=sum(a.values()),reference_pair_loads=traces,
                max_reference_to_minimum_volume=largest_ratio,results=results)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comb",type=Path,required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--output",type=Path)
    group.add_argument("--check",type=Path)
    args = parser.parse_args()
    raw = args.comb.read_bytes()
    checks = [check_stage(s) for s in json.loads(raw)["stages"]]
    result = dict(input_sha256=sha256(raw).hexdigest(),stages=checks,
                  scope="Finite continuous periodic-density arrangements, two true price masks and original degrees; the old cubes form a feasible auxiliary portfolio. No high-dimensional near-extremality is assumed.",
                  arithmetic="fractions.Fraction; integer capacities and residual potentials verify every optimization.")
    data = (json.dumps(result,default=str,sort_keys=True,indent=2)+"\n").encode()
    if args.output:
        args.output.write_bytes(data)
    else:
        assert data == args.check.read_bytes()
    for row in checks:
        for x in row["results"]:
            print(row["dimension"],x["law"],x["actual_rows"],x["strict_rows"],
                  *(round(float(x[k]),10) for k in ("independent_fraction","coupled_fraction","diagonal_raw_fraction","optimal_graph_raw_fraction","max_active_graph_weight")))


if __name__ == "__main__":
    main()
