#!/usr/bin/env python3
"""Two-precision Arb checks of the scale threshold and interpolation exponents."""
import argparse
import json
from pathlib import Path

import flint
from flint import arb, ctx


def sample(k, bias, inv_eps, precision):
    ctx.prec = precision
    n = arb(1 << k)
    N = n + 2
    ell = N.log()
    u = ell**8 / n.sqrt()
    half_margin = (-u).exp() * ((u/2).expm1() - 1/(32*n)) / u
    order = 2*(bias+1)*inv_eps
    ratio = (((bias+1)*ell+ell.log())/order - ell/inv_eps).exp()
    return u, half_margin, ratio


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--output", type=Path)
    modes.add_argument("--check", type=Path)
    args = parser.parse_args()
    result = []
    for k in (16, 64, 128, 256, 512, 1024):
        for bias, inv_eps in ((0,4), (2,8), (8,16)):
            first = sample(k,bias,inv_eps,192)
            second = sample(k,bias,inv_eps,384)
            assert all(a.overlaps(b) for a,b in zip(first,second))
            u, margin, ratio = second
            assert 0 < ratio < 1
            if k >= 128:
                assert 0 < u < 1 and margin > arb(1)/16
            else:
                assert u > 1 and margin < arb(1)/16
            result.append(dict(log2_n=k,bias=bias,inv_epsilon=inv_eps,
                               moment_parameter=2*(bias+1)*inv_eps,
                               J_over_n=u.str(22),actual_radius_margin_over_u=margin.str(22),
                               interpolation_factor=ratio.str(22),
                               radius_margin_exceeds_one_sixteenth=(margin > arb(1)/16)))
    report = dict(implementation="python-flint "+flint.__version__,
                  precisions_in_bits=[192,384],values=result,
                  scope="Finite scalar checks at n=2^k. The geometric measure and endpoint inequality are not tested here.")
    data = (json.dumps(report,sort_keys=True,indent=2)+"\n").encode()
    if args.output:
        args.output.write_bytes(data)
    else:
        assert args.check.read_bytes() == data
    print("18 interval triples; all precision pairs overlap; short-radius margin passes at k=128,256,512,1024")


if __name__ == "__main__":
    main()
