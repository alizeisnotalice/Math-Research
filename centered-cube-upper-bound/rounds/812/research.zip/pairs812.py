#!/usr/bin/env python3
"""Common source-pair reference versus single-price membership on the R811 comb."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from itertools import product
import json
from math import prod
from pathlib import Path
import platform

ZERO=F(0)
ONE=F(1)


def total(items):
    return sum(items,ZERO)


def load_hall(path):
    spec=spec_from_file_location("frozen_hall811",path)
    module=module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def target_cells(stage,old):
    old_bits=sum(p["bit"] for p in old.values())
    target=defaultdict(F)
    for row in stage["expanded_target_cells"]:
        i=row["mask"]&old_bits
        if i:
            target[i]+=F(row["volume"])
    for mask in range(1<<len(stage["parents"])):
        if not mask or mask&old_bits!=mask:
            continue
        boxes=[p["expanded_box"] for p in old.values() if mask&p["bit"]]
        exact=prod(max(ZERO,min(F(B[k][1]) for B in boxes)-max(F(B[k][0]) for B in boxes))
                   for k in range(stage["dimension"]))
        assert exact==total(w for j,w in target.items() if j&mask==mask)
    return dict(sorted(target.items()))


def by_frozen_roots(stage,law,parents,mass):
    joint=defaultdict(F)
    accepted=defaultdict(set)
    for root in stage["roots_"+law]:
        t,u,g=(root[key] for key in ("t","u","g"))
        T,U,G=(parents[i] for i in (t,u,g))
        factor=F(T["j"])/F(T["full_d"])*(F(U["j"])/F(U["m"]))*(F(G["j"])/F(G["m"]))/F(T["m"])**2
        assert factor==F(root["coefficient"])
        zmask,qmask=root["z_masks"],root["q_masks"]
        calc=ZERO
        for z,q in product(zmask,qmask):
            need=T["bit"]|U["bit"]
            other=T["bit"]|G["bit"]
            assert z&need==need and q&other==other
            amount=factor*mass[z]*mass[q]
            calc+=amount
            joint[t,z,q]+=amount
            accepted[t,z,q].add((u,g))
        assert calc==F(root["root_mass"])==total(map(F,root["sectors_00_01_10_11"]))
    assert total(joint.values())==F(stage["benchmarks"][law]["mother"])
    return joint,accepted


def reconstruct(stage,law,old,parents,mass):
    reference,joint,choices={},{},{}
    for t,T in parents.items():
        if T["role"]!="middle":
            continue
        live=stage["degrees"][t]["old_terms"]
        arms={z:tuple(u for u in live if z&old[u]["bit"]) for z in mass if z&T["bit"]}
        b={u:F(old[u]["j"])/F(old[u]["m"]) for u in live}
        for z,q in product(arms,repeat=2):
            E={(u,g) for u,g in product(arms[z],arms[q])
               if law=="all" or old[u]["volume_bin"]!=old[g]["volume_bin"]}
            if not E:
                continue
            row=t,z,q
            ref=F(T["j"])*mass[z]*mass[q]/F(T["m"])**2
            reference[row]=ref
            joint[row]=ref/F(T["full_d"])*total(b[u]*b[g] for u,g in E)
            choices[row]=E
    assert reference and set(reference)==set(joint)
    return reference,joint,choices


def contracts(stage,law,old,parents,mass):
    reference,joint,choices=reconstruct(stage,law,old,parents,mass)
    check,actual=by_frozen_roots(stage,law,parents,mass)
    assert joint==check and choices==actual
    public_left,public_right=defaultdict(int),defaultdict(int)
    pair_left,pair_right=defaultdict(int),defaultdict(int)
    for (t,z,q),ops in choices.items():
        for u,g in ops:
            pair_left[t,z,q]|=old[u]["bit"]
            pair_right[t,z,q]|=old[g]["bit"]
            public_left[t,z]|=old[u]["bit"]
            public_right[t,q]|=old[g]["bit"]
    maps={}
    maps["A_own_true_price_and_t"]=(
        {(t,z,q):public_left[t,z] for t,z,q in reference},
        {(t,z,q):public_right[t,q] for t,z,q in reference})
    maps["B_full_true_price_pair_and_t"]=(dict(pair_left),dict(pair_right))
    for label,(L,R) in maps.items():
        assert all(L[t,z,q]==R[t,q,z] for t,z,q in reference)
    a,b=maps.values()
    for row in reference:
        assert b[0][row]&a[0][row]==b[0][row] and b[1][row]&a[1][row]==b[1][row]
        t,z,q=row
        assert reference[row]==reference[t,q,z] and joint[row]==joint[t,q,z]
    return reference,joint,maps


def loads(reference,requirement):
    grouped=defaultdict(F)
    for row,v in reference.items():
        grouped[requirement[row]]+=v
    return dict(sorted(grouped.items()))


def cut_options(source,target):
    masks=tuple(source)
    history=[((),ZERO,ZERO,0)]
    target_ids=tuple(target)
    neighbor_masks={i:sum(1<<j for j,d in enumerate(target_ids) if d&i==i) for i in source}
    volumes={0:ZERO}
    for i in masks:
        frontier=[]
        for S,m,_,N in history:
            U=N|neighbor_masks[i]
            if U not in volumes:
                volumes[U]=total(target[d] for k,d in enumerate(target_ids) if U&(1<<k))
            frontier.append((S+(i,),m+source[i],volumes[U],U))
        history+=frontier
    return [(S,m,V) for S,m,V,N in history]


def region_of_cut(rows,bad):
    mass,V=next((m,v) for S,m,v in rows if set(S)==set(bad))
    lower,upper=ZERO,None
    for S,m,v in rows:
        a,b=mass-m,V-v
        if b>0:
            bound=a/b
            upper=bound if upper is None else min(upper,bound)
        elif b<0:
            lower=max(lower,a/b)
        else:
            assert a>=0
    assert upper is None or lower<=upper
    return [lower,upper]


def checked_side(hall,reference,req,target,theta,kappa,rows):
    src=loads(reference,req)
    scale={k:kappa*v for k,v in target.items()}
    pushed,bad,chosen,m,cap,flow=hall.transport(src,{i:i for i in src},scale,theta)
    expected=max(theta*s-kappa*V for S,s,V in rows)
    assert theta*m-cap==expected and pushed==theta*total(reference.values())-expected
    feasible=total(v for (i,j),v in flow.items() if i not in bad)
    assert feasible==theta*total(w for row,w in reference.items() if req[row] not in bad)
    assert all(i&j==i for i,j in flow)
    assert all(total(w for (i,k),w in flow.items() if k==j)<=scale[j] for j in target)
    region=region_of_cut(rows,bad)
    assert region[0]<=kappa/theta and (region[1] is None or kappa/theta<=region[1])
    return dict(source_reference_by_requirement=src,deficient_source_requirements=sorted(bad),
                cut_target_masks=sorted(chosen),cut_source_mass=m,cut_target_capacity=cap,
                maximal_reference_deficit=expected,maximum_pushed_reference_mass=pushed,
                cut_stable_effective_capacity_interval=region,
                primal_flow_by_requirement=[[i,j,w] for (i,j),w in sorted(flow.items())]),bad


def compare_at(hall,reference,joint,maps,rows,target,theta,kappa,pressure):
    tests={}
    denominator=total(joint.values())
    for mode,(lhs,rhs) in maps.items():
        first,cut_l=checked_side(hall,reference,lhs,target,theta,kappa,rows[mode])
        second,cut_r=checked_side(hall,reference,rhs,target,theta,kappa,rows[mode])
        assert first==second
        legs=[total(w for row,w in joint.items() if req[row] not in bad)
              for req,bad in ((lhs,cut_l),(rhs,cut_r))]
        outside={row:w for row,w in joint.items() if lhs[row] not in cut_l and rhs[row] not in cut_r}
        covered=total(outside.values())
        assert covered<=min(legs)<=denominator and legs[0]==legs[1]
        by_middle=defaultdict(F)
        for (t,z,q),v in outside.items():
            by_middle[t]+=v
        tests[mode]=dict(left=first,right=second,original_both_qualified_mass=covered,
                         original_both_qualified_rate=covered/denominator,
                         original_both_qualified_by_t=dict(by_middle),original_one_slot_qualified_rate=legs[0]/denominator,
                         original_shared_coin_paid_mass=theta*covered,original_shared_coin_paid_rate=theta*covered/denominator,
                         separate_coin_paid_rate=theta**2*covered/denominator)
    A,B=tests.values()
    assert B["left"]["maximum_pushed_reference_mass"]>=A["left"]["maximum_pushed_reference_mass"]
    return dict(name=pressure,theta=theta,right_Lebesgue_multiplier=kappa,effective_multiplier=kappa/theta,
                methods=tests,paid_rate_gain_B_minus_A=B["original_shared_coin_paid_rate"]-A["original_shared_coin_paid_rate"])


def evaluate(stage,law,hall,old,parents,mass,target):
    reference,joint,maps=contracts(stage,law,old,parents,mass)
    M,L=total(joint.values()),total(reference.values())
    cuts={}
    critical={}
    for mode,(lhs,rhs) in maps.items():
        a,b=loads(reference,lhs),loads(reference,rhs)
        assert a==b and total(a.values())==L
        cuts[mode]=cut_options(a,target)
        c,S,m,v=max((m/v,S,m,v) for S,m,v in cuts[mode] if m)
        assert c<1
        critical[mode]=dict(min_uniform_full_capacity_multiplier=c,extremizing_source_cut=S,
                            source_mass=m,unscaled_target_volume=v,Hall_source_cut_count=len(cuts[mode]))
    acrit,bcrit=(x["min_uniform_full_capacity_multiplier"] for x in critical.values())
    assert bcrit<=acrit
    scenarios=[("unit",ONE,ONE),("critical_A",ONE,acrit)]
    scenarios += [(f"pressure_{f}_of_A_capacity",F(1,2),f*acrit/2) for f in (F(1,2),F(4,5),F(7,8))]
    tests=[compare_at(hall,reference,joint,maps,cuts,target,theta,kappa,name) for name,theta,kappa in scenarios]
    assert all(d["original_shared_coin_paid_rate"]==ONE for d in tests[0]["methods"].values())
    assert all(d["original_shared_coin_paid_rate"]==ONE for d in tests[1]["methods"].values())
    A,B=maps.values()
    changes=[row for row in reference if A[0][row]!=B[0][row]]
    bigger=[row for row in changes if total(v for k,v in target.items() if k&B[0][row]==B[0][row])
            > total(v for k,v in target.items() if k&A[0][row]==A[0][row])]
    rows=[[t,z,q,reference[t,z,q],joint[t,z,q],A[0][t,z,q],A[1][t,z,q],B[0][t,z,q],B[1][t,z,q]]
          for t,z,q in sorted(reference)]
    return dict(law=law,original_Gamma=M,reference_Lambda=L,actual_source_pair_count=len(rows),
                changed_left_requirements=len(changes),changed_left_original_Gamma_fraction=total(joint[row] for row in changes)/M,
                strict_left_right_domain_growth_rows=len(bigger),
                strict_left_right_domain_growth_Gamma_fraction=total(joint[row] for row in bigger)/M,
                critical_uniform_capacity=critical,cases=tests,all_actual_source_pairs=rows)


def stage_check(stage,hall):
    parents={p["id"]:p for p in stage["parents"]}
    old={u:p for u,p in parents.items() if p["role"]=="old"}
    mass={c["mask"]:F(c["mass"]) for c in stage["cells"]}
    target=target_cells(stage,old)
    laws=[evaluate(stage,law,hall,old,parents,mass,target) for law in ("all","cross")]
    if stage["dimension"]==4:
        cert=laws[1]["cases"][3]
        A,B=cert["methods"].values()
        assert A["original_both_qualified_mass"]==0 < B["original_both_qualified_mass"]
    return dict(dimension=stage["dimension"],stage=stage["stage"],old_parent_bits={u:p["bit"] for u,p in old.items()},
                middle_j_and_full_degree={t:[F(p["j"]),F(p["full_d"])] for t,p in parents.items() if p["role"]=="middle"},
                target_Lebesgue_by_old_expanded_membership=target,laws=laws)


def certificate(root):
    hall=load_hall(root/"hall811.py")
    truth=json.loads((root/"comb811.json").read_text())
    return dict(runtime={"python":platform.python_version(),"machine":platform.machine(),"scipy":hall.scipy.__version__},
                arithmetic="fractions.Fraction; all Hall subsets enumerated and exact primal flows checked; no solver called",
                inputs_sha256={p:sha256((root/p).read_bytes()).hexdigest()
                               for p in ("comb811.json","comb811.py","hall811.py")},
                source_row_fields=["t","z_original_mask","q_original_mask","Lambda","Gamma","A_left_required_old_labels",
                                   "A_right_required_old_labels","B_left_required_old_labels","B_right_required_old_labels"],
                scope="Three finite genuine comb fixtures across all downward old-arm pairs and cross-bin pairs. A knows its own price and t; B knows both prices and t. Common reference counts every genuinely active (t,z,q) once. All middle fathers share one Lebesgue target capacity on each side; the left/right budgets are separate equal copies. Right domains require only the selected expanded small fathers. Origin prices, physical owner halves and the original full degree stay fixed.",
                pressure="Kappa multiplies the right Lebesgue budget on each side equally for both methods. With common dilution theta, the effective capacity is kappa/theta. The pressure scale is calibrated from the smallest uniform full capacity of A in the same finite fixture. It is not the theorem's fixed capacity.",
                transfer="An exact max-flow row of total theta*Lambda is assigned proportionally within each group of identical right domains. Both sides must be outside their corresponding bad source cuts; a common Bernoulli(theta) then multiplies genuine joint Gamma once.",
                reproduce="python -B pairs812.py --r811-dir <R811 numerics> --check pairs812.json",
                stages=[stage_check(d,hall) for d in truth["stages"]])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--r811-dir",required=True,type=Path)
    gp=parser.add_mutually_exclusive_group(required=True)
    gp.add_argument("--output",type=Path)
    gp.add_argument("--check",type=Path)
    args=parser.parse_args()
    data=certificate(args.r811_dir)
    contents=(json.dumps(data,default=str,sort_keys=True,indent=2)+"\n").encode()
    if args.output:
        args.output.write_bytes(contents)
    else:
        assert args.check.read_bytes()==contents
    for stage in data["stages"]:
        for law in stage["laws"]:
            print(stage["dimension"],law["law"],law["actual_source_pair_count"],
                  [(test["name"],[round(float(x["original_both_qualified_rate"]),9) for x in test["methods"].values()])
                  for test in law["cases"]])
    if args.check:
        print("byte-identical")


if __name__=="__main__":
    main()
