#!/usr/bin/env python3
"""Replay the two-price mass, the exact primal-dual witnesses and the Arb checks."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile


def checked(data, expected, label):
    actual = sha256(data).hexdigest()
    if actual != expected:
        raise ValueError(f"SHA-256 mismatch for {label}: {actual} != {expected}")
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--previous", type=Path, required=True, help="round 811 research.zip")
    parser.add_argument("--work", type=Path, required=True, help="new output directory")
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    manifest = json.loads((here/"MANIFEST.json").read_bytes())
    members = {name: checked((here/name).read_bytes(),digest,name)
               for name,digest in manifest["members"].items()}
    prev = manifest["previous"]
    checked(args.previous.read_bytes(),prev["archive_sha256"],"R811 archive")
    with ZipFile(args.previous) as old:
        frozen = {name: checked(old.read(name),digest,name) for name,digest in prev["programs"].items()}
    out = args.work.resolve()
    out.mkdir(parents=True,exist_ok=False)
    for name, blob in {**frozen, **members}.items():
        if name.endswith(".py") or name in ("soft812.json","coupled812.json"):
            (out/name).write_bytes(blob)

    def run(stem, *arguments):
        subprocess.run([sys.executable,"-B",stem+".py",*arguments],cwd=out,check=True)

    run("comb811","--output","comb811.json")
    checked((out/"comb811.json").read_bytes(),prev["data_sha256"],"comb811.json")
    run("pairs812","--r811-dir",str(out),"--output","pairs812.json")
    checked((out/"pairs812.json").read_bytes(),manifest["results"]["pairs812.json"],"pairs812.json")
    run("coupled812","--comb","comb811.json","--prior","pairs812.json","--check","coupled812.json")
    run("soft812","--comb","comb811.json","--prior","pairs812.json","--hard","coupled812.json","--check","soft812.json")
    run("supply812","--comb","comb811.json","--output","supply812.json")
    run("scalars812","--output","scalars812.json")
    for name,digest in manifest["results"].items():
        checked((out/name).read_bytes(),digest,name)
        print("SHA256",digest,name)
    print("Verified 5 round 812 outputs, 2 frozen round 811 programs and the continuous input.")


if __name__ == "__main__":
    main()
