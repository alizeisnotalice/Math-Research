#!/usr/bin/env python3
"""Certified weighted soft retention for the same genuine source-pair contracts."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform

from coupled812 import current_rows, exact_optimum, make_network
from pairs812 import reconstruct, total

ZERO=F(0)
ONE=F(1)
B_RULE="B_full_true_price_pair_and_t"


def actual_payoffs(physical,rows,target):
    parents={p["id"]:p for p in physical["parents"]}
    old={u:p for u,p in parents.items() if p["role"]=="old"}
    mu={a["mask"]:F(a["mass"]) for a in physical["cells"]}
    ref,gamma,allowed=reconstruct(physical,"cross",old,parents,mu)
    columns=[]
    independence_witness=None
    worst_gap=ZERO
    masks=tuple(target)
    for i,row in enumerate(rows):
        h=row[:3]
        t,z,q=h
        J=F(parents[t]["full_d"])
        w={(u,g):F(old[u]["j"])*F(old[g]["j"])/(F(old[u]["m"])*F(old[g]["m"])*J)
           for u,g in allowed[h]}
        whole=total(w.values())
        assert row[3]==ref[h] and row[4]==gamma[h] and whole==gamma[h]/ref[h]
        for a,b in product(range(len(masks)),repeat=2):
            left=total(x for (u,g),x in w.items() if masks[a]&old[u]["bit"])
            right=total(x for (u,g),x in w.items() if masks[b]&old[g]["bit"])
            rho=total(x for (u,g),x in w.items() if masks[a]&old[u]["bit"] and masks[b]&old[g]["bit"])
            gap=abs(rho/whole-(left/whole)*(right/whole))
            if gap>worst_gap:
                worst_gap=gap
                independence_witness=dict(source_pair=h,left_mask=masks[a],right_mask=masks[b],
                                          exact_joint_fraction=rho/whole,incorrect_product_fraction=left*right/whole**2)
            if rho:
                columns.append((i,a,b,rho))
            assert 0<=rho<=min(left,right)<=whole
            if masks[a]&row[7]==row[7] and masks[b]&row[8]==row[8]:
                assert rho==whole
    return columns,independence_witness


def positions(column,n,k):
    h,a,b,_=column
    return h,n+a,n+k+b


def primal(amount,columns,caps,n,k):
    load=[ZERO]*len(caps)
    value=ZERO
    for j,x in amount.items():
        assert 0<=j<len(columns) and x>0
        column=columns[j]
        for i in positions(column,n,k):
            load[i]+=x
        value+=x*column[3]
    assert all(a<=b for a,b in zip(load,caps))
    return value,load


def dual(phi,psi,columns,caps,n,k):
    assert len(phi)==len(psi)==k and all(x>=0 for x in phi+psi)
    alpha=[ZERO]*n
    for h,a,b,rho in columns:
        alpha[h]=max(alpha[h],rho-phi[a]-psi[b])
    price=alpha+phi+psi
    return total(a*b for a,b in zip(price,caps)),price


def hard_lift(rows,target,columns,theta,kappa,frozen):
    arcs,centres,sink,unit,cost=make_network(rows,target,1,theta,kappa)
    opt,_,flow=exact_optimum(arcs,centres,sink,frozen["certificate"])
    assert F(opt,unit*cost)==F(frozen["original_optimum_paid_mass"])
    assert unit==frozen["mass_denominator"] and cost==frozen["cost_denominator"]
    n,k=len(rows),len(target)
    offset,right0=1+k,1+k+2*n
    incoming=[defaultdict(int) for _ in rows]
    outgoing=[defaultdict(int) for _ in rows]
    for (u,v,cap,c),x in zip(arcs,flow):
        if x and 1<=u<offset and offset<=v<right0:
            incoming[(v-offset)//2][u-1]+=x
        if x and offset<=u<right0 and right0<=v<sink:
            outgoing[(u-offset)//2][v-right0]+=x
    col_id={(h,a,b):i for i,(h,a,b,rho) in enumerate(columns)}
    plan={}
    for h,i in enumerate(centres):
        f=flow[i]
        assert sum(incoming[h].values())==f==sum(outgoing[h].values())
        for (a,u),(b,v) in product(incoming[h].items(),outgoing[h].items()):
            col=col_id[h,a,b]
            assert columns[col][3]==rows[h][4]/rows[h][3]
            plan[col]=F(u*v,f*unit)
    p=[F(x,cost) for x in frozen["certificate"]["node_potentials"]]
    assert p[0]==p[-1]
    phi=[max(ZERO,p[1+i]-p[0]) for i in range(k)]
    psi=[max(ZERO,p[-1]-p[right0+i]) for i in range(k)]
    return plan,phi,psi


def try_exact_primal(support,eqs,approx,caps):
    """Solve the selected active-capacity equations over the rationals."""
    pivots={}
    for i,members in eqs:
        rhs=caps[i]
        terms={j:ONE for j in members}
        while terms:
            j=min(terms)
            factor=terms.pop(j)
            if j not in pivots:
                pivots[j]=({key:x/factor for key,x in terms.items()},rhs/factor)
                break
            equation,v=pivots[j]
            rhs-=factor*v
            for key,x in equation.items():
                update=terms.get(key,ZERO)-factor*x
                if update:
                    terms[key]=update
                else:
                    terms.pop(key,None)
        else:
            if rhs:
                return None
    solution={j:approx[j] for j in support if j not in pivots}
    for j,(eq,v) in sorted(pivots.items(),reverse=True):
        solution[j]=v-total(x*solution[i] for i,x in eq.items())
    if any(x<0 for x in solution.values()):
        return None
    return {j:x for j,x in solution.items() if x}


def solve_proposal(columns,caps,n,k,Gamma,hard_prices):
    import numpy as np
    import scipy
    from scipy.optimize import linprog
    from scipy.sparse import coo_matrix

    ai,aj,ac,cost,scales=[],[],[],[],[]
    for j,column in enumerate(columns):
        ps=positions(column,n,k)
        scale=min(caps[i] for i in ps)
        scales.append(scale)
        cost.append(-float(scale*column[3]/Gamma))
        for i in ps:
            ai.append(i)
            aj.append(j)
            ac.append(float(scale/caps[i]))
    A=coo_matrix((ac,(ai,aj)),shape=(len(caps),len(columns))).tocsr()
    options={"dual_feasibility_tolerance":1e-10,"primal_feasibility_tolerance":1e-10}
    result=linprog(cost,A_ub=A,b_ub=np.ones(len(caps)),bounds=(0,None),method="highs",options=options)
    assert result.success
    # A proposal is rounded and then brought inside every exact physical budget.
    approx={j:scales[j]*F(float(x)).limit_denominator(10**13) for j,x in enumerate(result.x) if x>0}
    approx={j:x for j,x in approx.items() if x}
    load=[ZERO]*len(caps)
    for j,x in approx.items():
        for i in positions(columns[j],n,k):
            load[i]+=x
    shrink=max(ONE,max(x/y for x,y in zip(load,caps)))
    rounded={j:x/shrink for j,x in approx.items()}
    init_bound,prices=dual(*hard_prices,columns,caps,n,k)
    float_prices=[F(max(0.,float(z)))*Gamma/v for z,v in zip(-result.ineqlin.marginals,caps)]
    prices_aside=(float_prices[n:n+k],float_prices[n+k:])
    other_bound,other_prices=dual(*prices_aside,columns,caps,n,k)
    if other_bound<init_bound:
        best_prices,bound,prices=prices_aside,other_bound,other_prices
    else:
        best_prices,bound=hard_prices,init_bound
    best,source=rounded,"rationalized HiGHS proposal rescaled to satisfy every budget"
    # If the exact dual exposes the support, use only its zero-reduced-cost columns.
    support=[j for j in approx if total(prices[i] for i in positions(columns[j],n,k))==columns[j][3]]
    touching=defaultdict(list)
    for j in support:
        for i in positions(columns[j],n,k):
            touching[i].append(j)
    for tol in (1e-11,1e-8):
        strong={i for i,p in enumerate(prices) if p>0 or abs(float(result.ineqlin.residual[i]))<=tol}
        eqs=[(i,touching[i]) for i in sorted(strong)]
        solution=try_exact_primal(support,eqs,approx,caps)
        if solution is None:
            continue
        try:
            value,_=primal(solution,columns,caps,n,k)
        except AssertionError:
            continue
        if value>primal(best,columns,caps,n,k)[0]:
            best,source=solution,"exact rational solution of active-capacity equations on proposed support"
        if value==bound:
            break
    return best,best_prices,dict(proposal=scipy.__version__,external_solver="scipy.optimize.linprog highs",
                                  candidate_construction=source,proposal_objective_estimate=-float(result.fun))


def check_case(rows,target,columns,case,saved):
    n,k=len(rows),len(target)
    theta,kappa=F(case["theta"]),F(case["right_Lebesgue_multiplier"])
    Gamma=total(row[4] for row in rows)
    caps=[theta*row[3] for row in rows]+[kappa*v for v in target.values()]*2
    hard=case["modes"][B_RULE]
    H,phi,psi=hard_lift(rows,target,columns,theta,kappa,hard)
    vH,_=primal(H,columns,caps,n,k)
    assert vH/Gamma==F(hard["original_optimum_paid_rate"])
    hard_bound,_=dual(phi,psi,columns,caps,n,k)
    if saved is not None:
        cert=saved["certificate"]
        phi,psi=([F(x) for x in cert[k]] for k in ("left_potential","right_potential"))
        amount={j:F(x) for j,x in cert["columns_with_positive_primal_mass"]}
        assert len(amount)==len(cert["columns_with_positive_primal_mass"])
        diagnostics=saved["construction"]
    elif hard_bound==vH:
        amount=H
        diagnostics=dict(candidate_construction="B hard path-flow disintegration and its projected exact dual")
    else:
        amount,(phi,psi),diagnostics=solve_proposal(columns,caps,n,k,Gamma,(phi,psi))
    lower,_=primal(amount,columns,caps,n,k)
    upper,_=dual(phi,psi,columns,caps,n,k)
    assert vH<=lower<=upper<=theta*Gamma
    partial=[]
    for j,x in sorted(amount.items()):
        h,a,b,rho=columns[j]
        whole=rows[h][4]/rows[h][3]
        if rho<whole:
            partial.append(dict(source_pair=rows[h][:3],left_target_mask=tuple(target)[a],right_target_mask=tuple(target)[b],
                                physical_reference_flow=x,own_original_pair_fraction_retained=rho/whole,original_paid=x*rho))
    return dict(name=case["case"],theta=theta,kappa=kappa,effective_right_multiplier=kappa/theta,
                original_Gamma=Gamma,hard_B_optimum_rate=vH/Gamma,soft_optimum_rate_lower=lower/Gamma,
                soft_optimum_rate_upper=upper/Gamma,soft_certified_gap=(upper-lower)/Gamma,
                soft_certified_gain_over_B=(lower-vH)/Gamma,lower_attains_upper=(lower==upper),
                partial_value_route_count=len(partial),partial_value_original_paid=total(r["original_paid"] for r in partial),
                partial_value_witness=(None if not partial else max(partial,key=lambda d:d["original_paid"])),
                construction=diagnostics,certificate=dict(left_potential=phi,right_potential=psi,
                                    columns_with_positive_primal_mass=[[j,x] for j,x in sorted(amount.items())]))


def certificate(comb_path,prior_path,hard_path,old_output):
    physical=json.loads(comb_path.read_text())
    prior=json.loads(prior_path.read_text())
    hard=json.loads(hard_path.read_text())
    assert sha256(comb_path.read_bytes()).hexdigest()==prior["inputs_sha256"]["comb811.json"]==hard["inputs_sha256"]["comb811.json"]
    assert sha256(prior_path.read_bytes()).hexdigest()==hard["inputs_sha256"]["pairs812.json"]
    past={} if old_output is None else {(s["dimension"],c["name"]):c for s in old_output["stages"] for c in s["cases"]}
    out=[]
    for n in (3,4):
        cmb=next(s for s in physical["stages"] if s["dimension"]==n)
        prior_stage=next(s for s in prior["stages"] if s["dimension"]==n)
        law=next(r for r in prior_stage["laws"] if r["law"]=="cross")
        hcase=next(r for r in hard["comparisons"] if r["dimension"]==n and r["law"]=="cross")
        rows,_,target=current_rows(cmb,law,prior_stage["target_Lebesgue_by_old_expanded_membership"])
        columns,dependence=actual_payoffs(cmb,rows,target)
        names={"pressure_4/5_of_A_capacity"} if n==3 else {"unit","pressure_1/2_of_A_capacity","pressure_4/5_of_A_capacity"}
        cases=[check_case(rows,target,columns,c,past.get((n,c["case"]))) for c in hcase["cases"] if c["case"] in names]
        if n==3:
            assert all(rho==rows[h][4]/rows[h][3] for h,a,b,rho in columns)
        assert any(c["soft_certified_gain_over_B"]>0 for c in cases)==(n==4)
        out.append(dict(dimension=n,law="cross",original_source_pair_count=len(rows),positive_soft_column_count=len(columns),
                        original_conditional_dependence_witness=dependence,cases=cases))
    paths={"comb811.json":comb_path,"pairs812.json":prior_path,"coupled812.json":hard_path,
           "pairs812.py":Path(__file__).with_name("pairs812.py"),
           "coupled812.py":Path(__file__).with_name("coupled812.py")}
    return dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
                input_sha256={name:sha256(path.read_bytes()).hexdigest() for name,path in paths.items()},
                scope="Frozen finite comb cross-bin contracts. Each row's profit is the sum over actual compatible ordered old-parent label pairs, with their original full-degree weights. Each side charges one shared Lebesgue target budget and keeps the original price-pair reference Lambda.",
                program="x[h,a,b] is Lambda[h] times the fractional routing mass. It has row bound theta Lambda[h], column bounds kappa |a| and kappa |b|, and objective sum rho[h,a,b]*x[h,a,b]. Theta is already in the row bounds.",
                proof="The primal route and two nonnegative side potentials are rational. The verifier recomputes every row residual maximum against all positive-profit columns, including zero as a candidate. Matching bounds certify the optimum. The check path uses only the saved witnesses.",
                replay="python -B soft812.py --comb <comb811.json> --prior pairs812.json --hard coupled812.json --check soft812.json",stages=out)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comb",type=Path,required=True)
    parser.add_argument("--prior",type=Path,default=Path("pairs812.json"))
    parser.add_argument("--hard",type=Path,default=Path("coupled812.json"))
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--output",type=Path)
    mode.add_argument("--check",type=Path)
    args=parser.parse_args()
    old=json.loads(args.check.read_text()) if args.check else None
    data=certificate(args.comb,args.prior,args.hard,old)
    out=(json.dumps(data,default=str,indent=2,sort_keys=True)+"\n").encode()
    if args.output:
        args.output.write_bytes(out)
    else:
        assert args.check.read_bytes()==out
    for stage in data["stages"]:
        for c in stage["cases"]:
            print(stage["dimension"],c["name"],"hard lower upper gap partial",
                  *(f"{float(c[key]):.14g}" for key in ("hard_B_optimum_rate","soft_optimum_rate_lower",
                     "soft_optimum_rate_upper","soft_certified_gap")),c["partial_value_route_count"])
    if args.check:
        print("byte-identical exact primal/dual replay")


if __name__=="__main__":
    main()
