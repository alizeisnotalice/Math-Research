import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
from fractions import Fraction as F
import mpmath as mp
mp.mp.dps=50
checks=0
for aa,bb in [(1,1),(1,2),(2,1),(1,1000),(1000,1),(3,7)]:
    a,b=mp.mpf(aa),mp.mpf(bb)
    lo,hi=min(a,b),max(a,b)
    exact=lo*(2+mp.log(hi/lo))
    num=mp.quad(lambda t:1,[0,lo])
    if lo<hi:num+=mp.quad(lambda t:lo/t,[lo,hi])
    # Exact elementary infinite-tail integral, independently split above.
    num+=a*b/hi
    assert abs(num-exact)<mp.mpf('1e-45')
    assert exact<=a+b+mp.mpf('1e-45')
    assert exact<=2*mp.sqrt(a*b)+mp.mpf('1e-45')
    checks+=3
for ds in [(F(1,2),),(F(1,4),F(1,4)),(F(1,8),)*4,(F(1,16),)*8]:
    P=F(1)
    for x in ds:P*=1-x
    assert sum(ds)<=F(1,2) and P>=F(1,2)
    checks+=1
for n in (1,8,512):
    for D in (mp.mpf(0),mp.mpf('0.01'),mp.mpf(1),mp.mpf(n)):
        if D==0:B=mp.mpf(0)
        else:
            h0=mp.sqrt(D/n)
            pts=[mp.mpf(0)]+([h0] if h0<mp.mpf('.5') else [])+[mp.mpf('.5')]
            B=mp.quad(lambda h:min(n,D/(h*h))/(1-h),pts)
        assert B<=min(n*mp.log(2),4*mp.sqrt(n*D))+mp.mpf('1e-43')
        checks+=1
print('PASS',checks)
