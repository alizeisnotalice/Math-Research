# R280 interior 最终独立审核

结论：**PASS，无数学阻断。** 本审先完成独立 screen，再读取作者稿；没有根据作者稿反向修改已冻结 screen。

## 绑定版本

- 作者稿 `/tmp/r280_near.md`：SHA256 `287cafe8a6cd65e74f5cef1a8b0dbc489d124e124c2c7a5d1cbf33e0406a98cb`。
- 相应整合 `/tmp/r280_integration.md`：SHA256 `af9d5e94dc4b841b9921714f9a5e84143d9028a2972ccc6b2e716457e7b1d667`。
- 本审先前独立 screen `/tmp/r280_interior_screen.md`：SHA256 `b589580c98a4df3d9ad068b4d661e1b7bd4c850bf74bcf5e3069e385a52bac9a`。

## 1. 变化的 q(x)：作者常数确实不变

作者 N10 正确保留的是 F_C/q，而非先把 1/q 单独粗化。实际 FIRST 给 F_C/q(x)<=1，高度给 F_C/q(x)<=m_C/[q(x)L^n]<=m_C/[q_-L^n]，q_-=3lambda/4。因此

\[
F_C/q(x)\le\min(1,m_C/(q_-L^n)),\quad
G_C\le\min(4\lambda,n_C/R^n).
\]

无需 q 在 receiver 上恒定。这两式与 actual interior 的 L,R>=r_C 同时成立，得到 4lambda I(m_C/q_-,n_C/(4lambda))。径向体积变量 v=r_C^n 的推前 Lebesgue 测度正是 dv；没有维数因子漏掉。

\[
I(\alpha,\beta)=\min(\alpha,\beta)(2+\log(\max/\min))
\le2\sqrt{\alpha\beta}
\]

故每胞为 8/sqrt(3) sqrt(m_C n_C)，随机胞耦合至多乘2，最终 16/sqrt(3)。作者 N14 的另一条线性价 (16/3)m_C+n_C 也正确。

先前 screen 对可变 q 给出的 32/3 是一个**合法但较弱**的备用价，来自先分别粗化 q 与 F_C；作者上述保留归一 FIRST 的办法正确加强它。无需改已冻结 screen，也不能将较弱备选误读为对作者的阻断。

## 2. 精确 allocation 与来源保持

同胞概率 P_d(y-z)=prod_i(1-|y_i-z_i|/d)_+ 正确；原 near 上 P_d>=1/2。作者 N8 的分子不超过 P_d，故 A_int 在[0,1]，且在 near 上 A_bd=1-A_int 精确分割原积分。

只有用于估计时才采用 P_d^(-1)<=2。系数2的两个 grid majorant 不构成等式；作者没有混淆这两种层次。所有权可测、只依 x,y,z 与原物理选择器，不依辅助 v,u,t。原 posterior、来源及 actual near 条件均未改变。

每个胞的两个来源质量来自同一固定网格的真实限制；sum_C sqrt(m_Cn_C)<=sqrt(||rho||||nu||) 对无限胞先截断再单调极限。种子/终端叶处再作一次 Cauchy，得到同一原 W_rho,W_nu，没有胞数或邻接数费用，也没有 nu<=rho 假设。

## 3. 原完整 clock 与常数

原 upper-score good 槽 v 的 R2<=D 和 C(r)>=(1-r)_+ 给逐对 score<=min(n,D/(1-xi)^2)。这在完整两后验平均之前成立，未限制 bad 槽 u，也未改变任一后验的归一化。

xi=c_jt/b 位于[1/2,1]，原每行唯一 j 在应用该上界前保留。积分 <=min(n log2,4sqrt(nD))，D=0 的零行约定正确。A_int 在该时钟中静态，可先取此逐行 uniform 价，再作源积分。

因此

\[
2\Lambda\times\frac{16}{\sqrt3}\times4\sqrt{nD}
=\frac{128\Lambda}{\sqrt3}\sqrt{nD}
\]

与 N18 一致。原 outside 2Lambda 只计一次。若 D 随外数据变，作者明确保 B_D 的来源加权和或使用已经证明的统一阈值，未作不合法提出。

## 4. 整合稿的相应分割及范围

整合稿先把原时钟精确分成 physical top 与 middle；top 用 5Lambda sqrt(n)W_nu。仅对 middle 使用 A_int/A_bd 的精确分割，interior 用完整 clock 上界控制 middle 是合法的上界，不会把同一实际 top 项再放入剩余账。

因此所列

\[
P_{current}\le5\Lambda\sqrt n W_\nu+
\frac{128\Lambda}{\sqrt3}\sqrt{nD}\sqrt{W_\rho W_\nu}
+P_{boundary,middle}
\]

常数与分割均通过。原同一组不交终端叶的 W_rho,W_nu 总账已由主稿绑定原 R112/R273 来源定义；不自动授予其它重叠来源集合。

boundary 是原 middle、near、所有剩余门与 A_bd 的真实正项，包括 genuine soft offcore。其 grid 公式只是明确正 majorant，不是已经付款的范数。作者和整合稿都未声称总体闭合、边界小、或 interior 覆盖固定正比例。

## 5. 实际复跑

本审已从绑定 SHA 的 `/tmp/r280_near.md` 自动提取唯一 Python 代码块并在本机执行；首先核 SHA 相符，然后按作者 vendor 路径加载 mpmath，实际返回 `PASS 34`。

该复跑含50位普通数值的层积分及 clock 检查、Fraction 同胞概率检查。它不是 interval certificate，不认证 FULL 输入，也不代替 N10–N18 的解析证明。本审另在读作者稿前已执行5个 Fraction 同胞检查和8个层cake诊断，记录于独立 screen。

审核范围已完成；没有要求改动作者稿、整合稿或已冻结 screen。
