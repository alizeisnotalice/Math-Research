# R280 conditional integration audit

**Verdict: conditional PASS for the positive allocation and accounting algebra.** The main terminal-clock theorem is independently passed. The separate cell-interior inequality is an explicit pending input to this integration audit; its geometric proof is not certified here.

Bound integration text:

- `/tmp/r280_integration.md`
- SHA256 `af9d5e94dc4b841b9921714f9a5e84143d9028a2972ccc6b2e716457e7b1d667`.

The independently audited main source is `/tmp/r280_main.md`, SHA256 `3d0d666b065b22f468744105ac59ad143fb65609febcdfac13bee9a0a954af02`; its audit is `/tmp/r280_main_audit.md`, SHA256 `7de09c94ad1b8cc772293fa24e488f87072f38ecc86e28cc3f67fd1dace476af`.

## Definitions required for this conditional reading

The grid pair is the original soft/hard source pair **(y,z)**, not the two auxiliary posterior slots. Take an independent normalized uniform shift of the common side-d grid. Write S for the event y,z lie in the same cell C and I for `C subset Q_L(x) intersect Q_R(x)`, with actual physical L,R. On original near, `P_d(y-z)=E_shift 1_S>=1/2`. The allocations are

`A_int=E_shift[1_S I]/P_d`, `A_bd=1-A_int`.

They are defined on the original near domain, where the denominator is positive. They do not define new source measures or posteriors. I is static in the auxiliary clock at a fixed actual receiver/source row.

## Checked allocation and fees

1. `0<=A_int,A_bd<=1`, and `A_int+A_bd=1` exactly. Moreover

   `A_bd=E_shift[1_S(1-I)]/P_d`.

   Consequently both claimed bounds by twice the corresponding grid expectations hold. The boundary is the entire complementary allocation, including unretained nearby configurations and all soft receiver contributions outside the input hard cube. It is not merely a far-source set.

2. Split the currently unpaid original positive clock first into top and middle. Apply the passed `5Lambda sqrt(n)W_nu` theorem only to top. Split only middle by A_int/A_bd. This gives an exact nonnegative partition before any bound; no signed negative credit is resplit or reused.

3. The asserted interior source-mother bound must be for this **normalized A_int allocation**, already including the single factor `1/P_d<=2`. Taking it as the pending input `16/sqrt(3) sqrt(W_rho W_nu)`, the remaining coefficient is correct. The full score-clock cap is at most `4sqrt(nD)`: at fixed actual row use the pointwise score bound and `d xi/xi<=2d xi` on [1/2,1], then `integral_0^{1/2} min(n,D/h^2)dh<=2sqrt(nD)`. This remains an upper bound for the middle window. Multiplication by the original outside 2Lambda gives exactly `128Lambda/sqrt(3) sqrt(nD) sqrt(W_rho W_nu)`. Do not apply a second normalization factor two if it is already included in the cell input.

4. Bounding a middle-interior row by a whole-clock positive row price is legitimate. Although that price was proved on a larger clock, the actual charged allocation is still middle only; the top piece is not added to the left side a second time. Source mass can appear in the two numerical upper prices, as in any sum of bounds for disjoint subpieces; this does not authorize recording the same actual positive subpiece twice.

5. On the original terminal-leaf ledger, W_rho<=W_beta<=||f||_1 and W_nu<=||f||_1 are available. Combining per-leaf square-root masses into `sqrt(W_rho W_nu)` uses Cauchy over the probability seed and terminal-leaf index. If D depends on outer data, first retain `E sum_V sqrt(D_V)||rho_V||^{1/2}||nu_V||^{1/2}` or an explicitly justified uniform bound; do not pull a common sqrt(D) without qualification. No ancestor/j source duplication is allowed.

Thus, **conditional on the exact interior input specified above**, the final displayed integration inequality and its unpriced `P_boundary,middle` remainder are valid. The elementary scalar inequality `min(alpha,beta)(2+log(max/min))<=2sqrt(alpha beta)` is correct, with the zero-mass case understood continuously. Its geometric use belongs to the pending cell proof, not to this algebra audit.

No full interior proof, boundary budget, positive-coverage claim or global root closure is certified by this note. The original posterior, Q/J classification, source measures and signed credits are unchanged. No repository/Git/PDF file was modified.
