from fractions import Fraction as F
from math import log,sqrt
vectors=[[F(0)],[F(1,2)],[F(1,4),F(1,4)],
         [F(1,8)]*4,[F(1,32)]*16]
for xs in vectors:
    p=F(1)
    for x in xs:p*=1-x
    assert p>=1-sum(xs)>=F(1,2)
for A,B in [(1,1),(1,2),(1,16),(.01,1),(100,.1),(0,1),(1,0),(3,7)]:
    val=0 if not A or not B else min(A,B)*(2+log(max(A,B)/min(A,B)))
    assert val<=2*sqrt(A*B)+1e-12
print('PASS: 5 exact same-cell checks and 8 layer-cake checks')
