import mpmath as m
records=[]
for dps in (40,70):
    m.mp.dps=dps
    rows=[]
    checks=0
    for n0 in (1,8,512):
        n=m.mpf(n0)
        gamma=1+1/n
        for D in (m.mpf(0),n/100,n/4,n):
            H=m.mpf('.5')
            if D==0:
                I=bound=m.mpf(0)
            else:
                h0=m.sqrt(D/n)
                f=lambda h:min(n,D/(h*h))*(1+n*m.log(gamma/(1-h)))/(1-h)
                parts=[m.mpf(0)]+([h0] if 0<h0<H else [])+[H]
                I=m.quad(f,parts)
                if D>=n*H*H:
                    bound=4*n*H+2*n*n*H*H
                else:
                    bound=8*m.sqrt(n*D)-4*D/H+2*n*D+4*n*D*m.log(H*m.sqrt(n/D))
            assert I<=bound+m.mpf('1e-35')*max(1,abs(bound))
            checks+=1
            rows.append(I)
        delta=m.mpf('.5')*n**(-m.mpf('.75'))
        ell=-m.log(1-delta)
        exact=n*((1+n*m.log(gamma))*ell+n*ell*ell/2)
        bound=4*n*delta+2*n*n*delta*delta
        assert exact<=bound<=m.mpf('2.5')*m.sqrt(n)
        checks+=1
        rows.append(exact)
    records.append(rows)
    print('PASS',checks,'ordinary mp'+str(dps),'scalar checks')
m.mp.dps=70
print('max40/70absdiff',m.nstr(max(abs(a-b)
                                for a,b in zip(*records)),12))
