# R280 independent receiver/time screening

**Verdict: PASS under the stated original unique-band and input-FIRST qualifications.** The resulting scalar-window bound is a genuine original-positive source budget. In particular the terminal normalized-clock strip of width `delta=(1/2)n^(-3/4)` costs at most `5 Lambda sqrt(n) W_nu`, independently of the R2 cutoff. This does not pay the middle-clock remainder or the global goal. No R280 author proof was read.

## 1. Exact pointwise score bound and clock transformation

Use the original good-upper-score orientation `(k_t(v)-k_t(u))_+`; the R2 constraint is on this same v slot. Write `r_i=|y_i-v_i|/b`, `R2=sum_i min(r_i^2,1)`, and denote the normalized clock by `u0=c_j t/b` to avoid confusing it with the bad-source letter.

For every active coordinate, `C(r_i)<u0`. Since `C(r)>=(1-r)_+`, if 0<=u0<1 then activity forces `r_i>1-u0`. Consequently, on R2<=D,

`(k_t(v)-k_t(u))_+ <=k_t(v)<=M_D(u0):=min(n,D/(1-u0)^2)`.       (1)

This is a bound for every original pair before posterior integration, with no source independence. D=0 gives zero score, including at u0=1: R2=0 forces v=y and C(0)=1 is not strictly active. For D>0 the endpoint u0=1 may safely use M_D(1)=n; it has zero continuous clock measure. The two full posterior probabilities therefore disappear at this step. Empty/zero-degree rows have zero original contribution and require no posterior definition.

At fixed actual receiver x there is one original, source-independent j(x). For that row `dt/t=du0/u0` exactly, with no Jacobian or menu factor. The original valid clock gives

`a/b<=u0<=c_j g(x)/b<=1`.

Although the posterior at `t=b u0/c_j(x)` generally depends on x after this substitution, this is harmless **only because** it has already been bounded pointwise by (1) and its total probability mass. It is not being pulled outside a receiver integral as a fixed law.

The j indicator must be kept to this point. Summing `1{j(x)=j}` is at most one, so the common u0 integration is used once. It is not a sum of full clock lengths over j.

## 2. Input-FIRST and the actual hard-scale floor

Let U be a fixed measurable normalized-clock window in [a/b,1]. The other original masks may be removed positively. Drop near and terminal restrictions in H only as an upper bound:

`H(x,y)<=integral h_{R(x)}(x-z) nu_V(dz)`.

The right side no longer depends on y. On the original receiver domain apply the given actual input-FIRST inequality

`integral p_y(x) rho_V(dy)<=q`.

This cancels the outer q^{-1}. No comparison nu<=beta, target-node FIRST, receiver hardcap factor 16/3, or source-mass square is used.

One must still retain the physical validity indicator `u0<=c_{j(x)}g(x)/b`. On this support,

`b u0=c_jt<=c_jg<=gamma min(L,R)<=gamma R`,

so the actual hard scale is at least

`r_min(u0)=max(a,b u0/gamma)`.

For each hard source z, the exact positive cube envelope has mass

`integral sup_{r_min<=r<=b} h_r(x-z) dx =1+n log(b/r_min)`.

Indeed it equals r_min^{-n} inside Q_{r_min}, equals `(2||x-z||_infinity)^{-n}` on the radial shell up to b, and vanishes outside Q_b. Tonelli integrates this envelope against the actual nu_V. Only after the restricted-kernel domination is made may the original receiver/physical-validity indicators be removed. Dropping validity before establishing this floor would not justify the restricted envelope.

Therefore the sharp available scalar estimate is

`P_U <=2 Lambda E sum_V ||nu_V|| integral_U M_D(u0)`

`        *[1+n log(b/max(a,b u0/gamma))] du0/u0`.             (2)

For common D and window U it implies

`P_U <=2 Lambda W_nu integral_U M_D(u0)[1+n log(gamma/u0)]du0/u0`,

`W_nu=E sum_V ||nu_V||`.                                   (3)

These bounds keep the original outside 2 Lambda exactly once. They concern the currently unpaid original positive quantity or a smaller positive mask. Signed negative credits, carrier deletion atoms, and endpoint recoveries play no role.

If a,b or D vary with frozen outer data/leaf, retain the scalar price inside the corresponding source sum until taking a uniform bound. An arbitrary y-dependent D cannot be factored out through FIRST without a corresponding weighted FIRST estimate. No such extra assumption is supplied here. The D-free terminal bound below is uniform in all admissible outer a,b.

## 3. Closed scalar prices and endpoint cases

Let `H0=1-a/b in [0,1/2]` and h=1-u0. Denote the relaxed integral in (3) over the full allowed clock by I_D. It vanishes if H0=0 or D=0. Since `n log gamma<=1`, `1/(1-h)<=2`, and `-log(1-h)<=2h` for h<=1/2,

`I_D <=4 integral_0^H0 min(n,D/h^2) dh`

`       +4n integral_0^H0 h min(n,D/h^2) dh`.                (4)

For H0>0 this yields the explicit continuous piecewise bound

- If D>=n H0^2: `I_D<=4nH0+2n^2 H0^2`.
- If 0<D<n H0^2:

  `I_D<=8sqrt(nD)-4D/H0+2nD+4nD log(H0 sqrt(n/D))`.

The latter follows by splitting at h=sqrt(D/n). In particular it is at most

`8sqrt(nD)+2nD[1+log(nH0^2/D)]`

in that regime. It tends to zero with D. D>=n makes the R2 mask itself vacuous, whereas D>=nH0^2 only makes this scalar score bound equal to n throughout the allowed window; these two facts should not be conflated.

When the scalar score is n throughout the interval, its relaxed integral is exactly

`I_n=n[(1+n log gamma)ell+(n/2)ell^2]`, `ell=log(b/a)`.

Thus unrestricted full-clock use is only O(n^2)W_nu. Even a common D=O(log n) generally gives an order-nD-log(n/D) scalar price in (4), not a root-order full-clock payment. There is no hidden global closure in this inequality.

All actual clock endpoints are continuous dt/t endpoints; their individual choices have zero mass in this argument. No jump measure is silently being integrated as dt/t.

## 4. D-free terminal strip: a genuine root source payment

Restrict to the original normalized-clock terminal strip `u0>=1-delta`, delta>=0. Let `Hdelta=min(delta,H0)`. Without using any R2 mask, bound the score by n. Its relaxed scalar price is exactly

`J_delta=n[(1+n log gamma)ell_delta+(n/2)ell_delta^2]`,

`ell_delta=-log(1-Hdelta)`.

Since Hdelta<=1/2,

`J_delta<=4nHdelta+2n^2 Hdelta^2<=4n delta+2n^2 delta^2`.       (5)

Take `delta=(1/2)n^(-3/4)`, which is <=1/2 for all n>=1. Then

`4n delta+2n^2 delta^2=2n^(1/4)+(1/2)sqrt(n)<= (5/2)sqrt(n)`.

Consequently the **original current near positive traffic** in this subclock satisfies

`P_terminal<=5 Lambda sqrt(n) W_nu`.                         (6)

It includes all R2 values and both full auxiliary-source slots. If a particular row never reaches this terminal strip, its contribution is simply zero. The strip is defined using c_{j(x)}t/b, not t/g(x), and no per-row change to the original clock or posterior is made. A window of width n^{-1/2} would instead give an order-n term in (5); that wider strip is not root-paid by this argument.

The complementary middle clock, off-near traffic, and original signed/global remainder remain outside this payment. Registration is on the currently unpaid positive subset; old paid positive masks may be retained and old negative credits are not spent again.

## 5. Source ledger: when (6) is an input bound

For arbitrary indexed measures, `nu_V<=f dx` by itself does **not** imply `E sum_V ||nu_V||<=||f||_1`. Thus W_nu is retained in (2)–(6) unless the original source collection is verified.

For this exact original collection, necessary source snippets were independently read:

- R112 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round112_20261014/proof.tex.txt:508` explicitly says terminal V are disjoint, `alpha_V=mu_hi,omega|V`, `sigma_V<=alpha_V`, and the current hard tail `nu_V<=sigma_V`.
- R113 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/coupled_transport.md:68` onward explicitly preserves that already constructed hard nu while changing the soft network. This proof does not use the separate nu-to-beta comparison.
- R273 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round273_20261017_final_checkpoint/proof.tex.txt:9` explicitly retains `nu_V<=1_V f dx` on this same disjoint terminal-leaf collection, gives `W_nu<=||f||_1`, and prohibits copying it to ancestors or ratio bands.

Accordingly, when the task's original nu_V and terminal leaves are retained as stated, (6) gives the actual input budget

`P_terminal<=5 Lambda sqrt(n)||f||_1`.

No j duplication of hard mass occurs, because the unique-j normalized-clock argument has already eliminated that sum before source integration. If the source collection is changed or duplicated, retain W_nu and pay the new multiplicity separately. Neither source disjointness nor receiver disjointness was invented for a new collection.

## 6. Actual bounded mathematical-tool check

A local ordinary mpmath run checked 12 full-window scalar integral cases (n in {1,8,512}, D in {0,n/100,n/4,n}) plus 3 D-free terminal-strip cases at each of 40 and 70 digits. All 15 checks per precision passed against (4)/(5); the largest 40/70 absolute difference was approximately 2.80143981414e-37. These are scalar integration diagnostics, not interval certificates or original FULL input examples. The analytic proofs above supply the inequalities.

Reproduce with the local mpmath vendor path if necessary:

```python
import mpmath as m
records=[]
for dps in (40,70):
    m.mp.dps=dps
    rows=[]
    checks=0
    for n0 in (1,8,512):
        n=m.mpf(n0)
        gamma=1+1/n
        for D in (m.mpf(0),n/100,n/4,n):
            H=m.mpf('.5')
            if D==0:
                I=bound=m.mpf(0)
            else:
                h0=m.sqrt(D/n)
                f=lambda h:min(n,D/(h*h))*(1+n*m.log(gamma/(1-h)))/(1-h)
                parts=[m.mpf(0)]+([h0] if 0<h0<H else [])+[H]
                I=m.quad(f,parts)
                if D>=n*H*H:
                    bound=4*n*H+2*n*n*H*H
                else:
                    bound=8*m.sqrt(n*D)-4*D/H+2*n*D+4*n*D*m.log(H*m.sqrt(n/D))
            assert I<=bound+m.mpf('1e-35')*max(1,abs(bound))
            checks+=1
            rows.append(I)
        delta=m.mpf('.5')*n**(-m.mpf('.75'))
        ell=-m.log(1-delta)
        exact=n*((1+n*m.log(gamma))*ell+n*ell*ell/2)
        bound=4*n*delta+2*n*n*delta*delta
        assert exact<=bound<=m.mpf('2.5')*m.sqrt(n)
        checks+=1
        rows.append(exact)
    records.append(rows)
    print('PASS',checks,'ordinary mp'+str(dps),'scalar checks')
m.mp.dps=70
print('max40/70absdiff',m.nstr(max(abs(a-b)
                                for a,b in zip(*records)),12))
```

Only `/tmp/r280_screen.md` was written. No R280 author proof was read, no repository/Git/PDF action was performed, and the task stops at this explicit window/source theorem and its stated unproved complement.
