# R280 scalar global price and terminal-layer diagnostics

Completed18 global integral cases (initial3/stress4/expanded11),17 terminal-layer cases, and16 exact Fraction branch checks. Every ordinary40/60 comparison passed. There are357 compared numerical fields, including residual and margin fields; maximum scaled difference is3.14265161278406e-39, at the last global case's closed-versus-quadrature residual. These are scalar identities and finite diagnostics, not an original FULL, source-payment or dimension-order result.

## Independent piece formula

Write h=1-u, q=sqrt(D/n), a0=1+n log(1+1/n). D=0 is defined to give zero. If q>=1/2 the entire octave is saturated and I=J(n,1/2). Otherwise

I=J(n,q)+D{a0[B(1-q)-B(1/2)]-n[Q(1-q)-Q(1/2)]},

where

B(u)=log u-log(1-u)+1/(1-u),

Q(u)=.5 log²u+Li2(1-u)+log u/(1-u)-log u+log(1-u).

Direct differentiation gives B'=1/[u(1-u)²] and Q'=log u/[u(1-u)²]. Thus these formulas derive the exact piece integral, independently of numerical quadrature. For a layer of width delta<=1/2 use the same formula with1/2 replaced by1-delta and q comparison against delta.

J(n,delta)=n[a0 ell+n ell²/2], ell=-log(1-delta).

This is the exact saturated terminal-layer price. It does not assert that an arbitrary D mask is saturated there: the actual masked layer is separately evaluated with min(n,D/h²), split at q. In the script the terminal integral uses h=cut*x, and the outer integral uses h=q exp(v); all scale changes are explicit and no endpoint singularity is naively sampled. The D=1e-20 case is included. Closed-form cancellation is monitored by the actual40/60 comparison, not assumed harmless.

## Two elementary safe bounds

Since h<=1/2, 1/(1-h)<=2 and -log(1-h)<=2h. Let A0=int_0^.5 min(n,D/h²)dh and A1=int_0^.5 h min(n,D/h²)dh. Then

I <=2a0 A0+4n A1.

If q<1/2,D>0, A0=2sqrt(nD)-2D and A1=D/2+D log[(1/2)/q]. If q>=1/2, A0=n/2 and A1=n/8. D0 gives both zero. These are elementary analytical upper bounds, not deductions from the finite menu. The more conservative I<=2[1+n log(2gamma)]A0 is also checked. Sixteen Fraction cases n1/2/8/128 and q0,1/8,1/2,3/4 independently verify the exact A0 split formulas and branch/equality conventions.

## Actual menu and decisions

Initial: n1,2,8 with D1. Stress: n8 with D0,1e-20,n/4,n. The latter two have identical saturated prices,26.1446965511749. Expanded: n64,512,10000,100000000 with D1 and1/log(n+2).

|n|I(D1)|I(D1/log(n+2))|
|---:|---:|---:|
|64|217.359300317955|72.217395192291|
|512|2146.87548175894|443.285865958706|
|10000|55719.1542551665|7350.76544793270|
|100000000|1014681319.39013|62999537.5489978|

Terminal layers use n2,8,64,512,10000,100000000 and requested delta1/n or1/sqrt(n), with delta capped at1/2 to remain in the original octave. Only n2's1/sqrt(n) request needs that cap and is explicitly flagged. Each J formula is checked by independent direct quadrature, and the masked price with D=1/log(n+2) is independently checked against its own split quadrature and against J.

At n1e8, J(1/n)=2.50000001000000 and J(1/sqrt(n))=50025001.4583917. The corresponding masked/unmasked ratios are1 and.212522195293502. At n8 the ratios are1 and.817431376216631. A small terminal layer price therefore does not by itself pay the larger full-window integral. No asymptotic fit or universal order claim is based on these samples. All values and normalized terminal diagnostics are in the JSON.

## Evidence boundary and replay

mpmath40/60 is ordinary arithmetic and quadrature, not outward interval certification. Ninety-digit saved strings preserve the actual working-precision error, not90-digit accuracy. The domain is bounded, so there is no tail truncation. No original posterior/source/cube/history/high/FIRST conditions are constructed or certified. Exact Fraction arithmetic concerns only the stated branch-cap primitive.

Self-contained standard-library plus mpmath1.3.0, Python3.12.14:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
r280_numeric.py --output r280_numeric.json
```

The deterministic JSON binds the script SHA and contains no runtime, timestamp or output path. The final complete40/60 computation was actually run after adding the elementary sharper bound; no old numerical menu or repository file was touched.


## Final bounded residual-regime supplement

Three expanded global rows use the actual residual choice D=log(n+2), not its reciprocal: n64 gives I=600.884193744913; n10000 gives406549.960698860; n1e8 gives16006540202.2302. These rows use the same split closed primitive and independent quadrature; the earlier reciprocal-D rows remain separate. This finite computation does not turn the full-window price into a root payment.

Five additional terminal layers use delta=.5 n^(-3/4) at n1,16,256,10000,1e8. The actual J values are respectively1.41382670143725,2.56739618891976,6.02753315218606,22.5085036536807,1350.00064975029. All are below (5/2)sqrt(n), and the script also records2Lambda J and its upper5Lambda sqrt(n),Lambda=128/119. In these five layers the residual D=log(n+2) mask is saturated throughout, so masked=unmasked J (saving0); this is checked by the actual split comparison, not assumed for other layers.

The terminal root bound has an elementary analytic justification independent of the menu. For n>=1,delta<=1/2 and ell=-log(1-delta)<=2delta=n^(-3/4). Also nlog(1+1/n)<=1. Hence

J=n[(1+nloggamma)ell+n ell²/2]
 <=2n^(1/4)+(1/2)sqrt(n)
 <=(5/2)sqrt(n).

Multiplying by2Lambda gives5Lambda sqrt(n). This only pays the stated terminal layer. It is not an upper bound on the whole global I, which includes the outer portion. The displayed inequalities are analytical; ordinary40/60 numerical checks are corroboration, not interval certification. Final counts are18global+17terminal+16Fraction, with357precision fields and the same maximum scaled difference3.14265161278406e-39. The updated full menu was actually rerun once after this supplement.
