#!/usr/bin/env python3
"""R280 bounded scalar price integration; ordinary multiprecision, no FULL claim."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as m

def enc(x):return m.nstr(x,90)
def J(n,delta):
 if delta==0:return m.mpf(0)
 ell=-m.log1p(-delta);a=1+n*m.log1p(1/m.mpf(n))
 return n*(a*ell+n*ell*ell/2)
def B(u):return m.log(u)-m.log1p(-u)+1/(1-u)
def Q(u):
 l=m.log(u)
 return l*l/2+m.polylog(2,1-u)+l/(1-u)-l+m.log1p(-u)
def closed(n,D,delta=m.mpf('.5')):
 if D==0 or delta==0:return m.mpf(0)
 q=m.sqrt(D/n)
 if q>=delta:return J(n,delta)
 a=1+n*m.log1p(1/m.mpf(n));upper=1-q;lower=1-delta
 return J(n,q)+D*(a*(B(upper)-B(lower))-n*(Q(upper)-Q(lower)))
def quadrature(n,D,delta):
 if D==0 or delta==0:return m.mpf(0)
 q=m.sqrt(D/n);cut=min(delta,q);a=1+n*m.log1p(1/m.mpf(n))
 # h=q*x handles the shrinking terminal layer without sampling endpoint singularities.
 term=m.quad(lambda x:n*cut*(a-n*m.log1p(-cut*x))/(1-cut*x),[0,1])
 if q>=delta:return term
 # h=q*exp(v), so outer scale ratios need only a logarithmic interval.
 top=m.log(delta/q)
 outer=m.quad(lambda v:D*(a-n*m.log1p(-q*m.exp(v)))/(q*m.exp(v)*(1-q*m.exp(v))),[0,top/2,top])
 return term+outer
MENU=[('initial',1,'one'),('initial',2,'one'),('initial',8,'one'),('stress',8,'zero'),('stress',8,'tiny'),('stress',8,'quarter_n'),('stress',8,'n')]+[('expanded',n,kind) for n in [64,512,10000,100000000] for kind in ['one','invlog']]+[('expanded',n,'log') for n in [64,10000,100000000]]
def Dvalue(n,kind):
 return {'one':lambda:m.mpf(1),'zero':lambda:m.mpf(0),'tiny':lambda:m.mpf('1e-20'),'quarter_n':lambda:m.mpf(n)/4,'n':lambda:m.mpf(n),'invlog':lambda:1/m.log(n+2),'log':lambda:m.log(n+2)}[kind]()
def run(dps):
 with m.workdps(dps):
  rows=[];layers=[];tol=m.mpf(10)**(-dps+15)
  for phase,n,kind in MENU:
   nn=m.mpf(n);D=Dvalue(n,kind);cl=closed(nn,D);qu=quadrature(nn,D,m.mpf('.5'));q=m.sqrt(D/nn);a=1+nn*m.log1p(1/nn)
   integralcap=nn/2 if q>=m.mpf('.5') else 2*m.sqrt(nn*D)-2*D
   simple=2*(1+nn*m.log(2*(1+1/nn)))*integralcap
   firstmomentcap=nn/8 if q>=m.mpf('.5') else (m.mpf(0) if D==0 else D/2+D*m.log(m.mpf('.5')/q))
   sharper=2*a*integralcap+4*nn*firstmomentcap
   assert cl<=sharper+tol*max(1,abs(sharper))
   assert abs(cl-qu)/max(1,abs(cl))<tol and cl<=simple+tol*max(1,abs(simple))
   rows.append({'phase':phase,'n':n,'D_kind':kind,**{k:enc(v) for k,v in [('D',D),('split_h',q),('closed_integral',cl),('quad_integral',qu),('simple_upper_bound',simple),('simple_margin',simple-cl),('sharper_upper_bound',sharper),('sharper_margin',sharper-cl),('closed_quad_scaled_difference',abs(cl-qu)/max(1,abs(cl)))]},'whole_window_saturated':q>=m.mpf('.5')})
  layer_menu=[(n,typ) for n in [2,8,64,512,10000,100000000] for typ in ['1/n','1/sqrt_n']]+[(n,'half_n_minus_threequarters') for n in [1,16,256,10000,100000000]]
  for n,typ in layer_menu:
   nn=m.mpf(n)
   for _ in [None]:
    raw=1/nn if typ=='1/n' else 1/m.sqrt(nn) if typ=='1/sqrt_n' else m.mpf('.5')*nn**(-m.mpf(3)/4);delta=min(m.mpf('.5'),raw);value=J(nn,delta)
    a=1+nn*m.log1p(1/nn)
    direct=m.quad(lambda h:nn*(a-nn*m.log1p(-h))/(1-h),[0,delta/2,delta]);assert abs(value-direct)/max(1,abs(value))<tol
    D=m.log(n+2) if typ=='half_n_minus_threequarters' else 1/m.log(n+2);masked=closed(nn,D,delta);maskedquad=quadrature(nn,D,delta)
    assert abs(masked-maskedquad)/max(1,abs(masked))<tol and masked<=value+tol*max(1,abs(value))
    root_layer=typ=='half_n_minus_threequarters'
    if root_layer:
     assert -m.log1p(-delta)<=2*delta and nn*m.log1p(1/nn)<=1
     assert value<=m.mpf('2.5')*m.sqrt(nn)+tol
    root_fields={} if not root_layer else {'root_J_bound':enc(m.mpf('2.5')*m.sqrt(nn)),'root_J_margin':enc(m.mpf('2.5')*m.sqrt(nn)-value),'Lambda_exact':'128/119','full_2Lambda_J':enc(2*m.mpf(128)/119*value),'full_root_bound_5Lambda_sqrtn':enc(5*m.mpf(128)/119*m.sqrt(nn))}
    layers.append({'n':n,**root_fields,'delta_kind':typ,'delta_capped_at_half':raw>m.mpf('.5'),**{k:enc(v) for k,v in [('delta',delta),('ell',-m.log1p(-delta)),('J_closed',value),('J_quad',direct),('J_over_n_delta_plus_n2_delta2',value/(nn*delta+nn*nn*delta*delta)),('D_mask',D),('masked_closed',masked),('masked_quad',maskedquad),('masked_to_unmasked_ratio',masked/value),('mask_saving',value-masked)]}})
  return {'global_cases':rows,'terminal_layers':layers}
def exact_branch_checks():
 rows=[]
 for n in [1,2,8,128]:
  for q in [F(0),F(1,8),F(1,2),F(3,4)]:
   D=n*q*q;cut=min(q,F(1,2));initial=n*cut
   outer=F(0) if q==0 or q>=F(1,2) else D*(1/q-2)
   value=initial+outer;formula=F(n,2) if q>=F(1,2) else 2*n*q-2*D
   assert value==formula and value>=0
   rows.append({'n':n,'q_exact':str(q),'D_exact':str(D),'integral_min_n_D_over_h2_exact':str(value),'saturated':q>=F(1,2),'zero_convention':q==0})
 return rows
def numeric_fields(data):
 out={}
 for family in ['global_cases','terminal_layers']:
  for i,row in enumerate(data[family]):
   for k,v in row.items():
    if not isinstance(v,str) or k in ['phase','D_kind','delta_kind']:continue
    try:out[family+'/'+str(i)+'/'+k]=m.mpf(v)
    except ValueError:pass
 return out
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=p.parse_args();lo=run(40);hi=run(60)
 with m.workdps(110):
  x,y=numeric_fields(lo),numeric_fields(hi);diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);maximum=enc(diff[worst]);assert diff[worst]<m.mpf('1e-24')
 out={'schema':'R280-piecewise-scalar-price-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'global_integral_cases':len(MENU),'global_stage_counts':{'initial':3,'stress':4,'expanded':11},'terminal_layer_cases':17,'new_logD_global_cases':3,'new_root_terminal_cases':5,'exact_Fraction_branch_checks':16,'precision_field_comparisons':len(diff)},'mp40':lo,'mp60':hi,'precision_max_scaled_difference':maximum,'precision_worst_field':worst,'exact_branch_checks':exact_branch_checks(),'definitions':{'I':'int_.5^1 min(n,D/(1-u)^2)[1+n log(gamma/u)]du/u','gamma':'1+1/n','D0':'integral defined0','J':'n[(1+n loggamma)ell+n ell²/2],ell=-log(1-delta)','outer_primitive':'D[(1+nloggamma)B(u)-nQ(u)], B=logu-log(1-u)+1/(1-u); Q=.5log²u+Li2(1-u)+logu/(1-u)-logu+log(1-u)','simple_upper':'2[1+n log(2gamma)] int_0^.5 min(n,D/h²)dh','exact_cap_integral':'n/2 if D>=n/4; otherwise2sqrt(nD)-2D','sharper_upper':'2(1+nloggamma) A+4n B, A=int cap dh, B=int h cap dh; B=n/8 if q>=.5,otherwise D/2+Dlog(.5/q),D0 separately0'},'scope':['Scalar integral identities and finite price diagnostics only; no original FULL, high/FIRST, source payment or general-order conclusion.','Ordinary mpmath40/60, not interval certificates. Exact Fraction branches separately identified. q=sqrt(D/n) splits all integrals. Outer quadrature uses h=q exp(v), terminal uses h=cut*x. Closed outer primitive is independent of quadrature.','Five added root terminal layers use delta=.5 n^(-3/4), D=log(n+2); J<=2.5sqrt(n) checked, independently of global price. Other terminal delta is capped at.5 to retain original octave; n2 delta1/sqrt_n would exceed.5 and is explicitly flagged. Masked layer uses actual min(n,D/h²), with D=1/log(n+2).','90-digit saved strings retain working precision errors, not90-digit accuracy. Tiny-D cancellation in B/Q is monitored by40/60 comparison; no naive endpoint quadrature at h0.']}
 args.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':maximum,'worst':worst}))
if __name__=='__main__':main()
