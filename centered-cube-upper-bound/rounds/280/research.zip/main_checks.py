import math
def simpson(f,a,b,N=2000):
    if a==b:return 0.
    h=(b-a)/N
    return h/3*(f(a)+f(b)+sum((4 if k%2 else 2)*f(a+k*h) for k in range(1,N)))
count=0
for n in [1,2,8,32,256,4096]:
    ell=math.log(2); hg=math.log1p(1/n)
    F=ell*ell if hg>=ell else ell*ell/2+hg*ell-hg*hg/2
    bare=n*(ell+n*F)
    for D in [0,.01,1,math.log(n+2),n/4,n]:
        if D==0:val=0; bound=0
        else:
            def fun(v):
                h=-math.expm1(-v)
                score=n if h==0 else min(n,D/(h*h))
                return score*(1+n*min(ell,hg+v))
            cuts=[0,ell]
            if 0<ell-hg<ell:cuts.append(ell-hg)
            r=math.sqrt(D/n)
            if r<.5:cuts.append(-math.log1p(-r))
            cuts=sorted(set(cuts))
            val=sum(simpson(fun,a,b) for a,b in zip(cuts,cuts[1:]))
            bound=8*math.sqrt(n*D)+2*n*D*(1+max(0,math.log(n/(4*D))))
        assert val<=min(bare,bound)+1e-7*max(1,bare)
        count+=1
    delta=.5*n**(-.75); leng=-math.log1p(-delta)
    J=n*((1+n*hg)*leng+n*leng*leng/2)
    assert J<=2.5*math.sqrt(n)+1e-12
print({'global_integral_checks':count,'terminal_root_checks':6,'status':'PASS'})
