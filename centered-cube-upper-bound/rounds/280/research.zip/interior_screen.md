# R280 独立筛查：共同来源胞 interior 的两帽 layer-cake 付款

本稿在未读取 compare 作者稿的情况下独立核算。结论：所述命题成立；固定原 q 的常数 16/sqrt(3) 与原正交通常数 128Lambda/sqrt(3) 均正确。它支付的是随机共同胞的 interior 分配，不自动支付 boundary 分配。

## 1. 准确资格与对象

固定原种子、叶及共同 q,lambda>0，3lambda/4<=q<=lambda。原 rho、nu 为正有限来源，各自来自原固定来源限制，不假设 nu<=rho 或 nu<=beta。实际 receiver E 上

\[
\int P_{s(x),L(x)}(x-y)\rho(dy)\le q,
\qquad \int h_{R(x)}(x-z)\nu(dz)\le4\lambda.
\tag{A}
\]

s,L,R 是同一 receiver 的原选择器，不依 y,z；p_y=P_(s,L)(x-y)。仅需实际 (A)，不授任何节点 FIRST，也不需要改为 soft 上确界的帽。

取边长 d>0 的轴平行网格，平移 xi 在 [0,d)^n 上均匀。每胞 C 用完整边长 d 的半开立方体，中心 z_C；interior 指其闭包包含于两个实际核的 core：

\[
I_C(x)=1_{\{\overline C\subset Q_{L(x)}(x)\cap Q_{R(x)}(x)\}}
=1_{\{2\|x-z_C\|_\infty+d\le\min(L(x),R(x))\}}.
\]

这是原 receiver 参数的可测门，不涉及辅助来源 v/u 或重建后验。定义

\[
A_C=\rho(C),\quad B_C=\nu(C),\quad
F_C(x)=\int_C p_y(x)\rho(dy),\quad G_C(x)=\int_C h_R(x-z)\nu(dz).
\]

则对每个固定网格

\[
F_C\le\min(q,A_C/L^n),\qquad G_C\le\min(4\lambda,B_C/R^n).
\tag{B}
\]

第一项分别来自实际 (A) 和 f_s<=1；无需胞内来源密度上界或均匀性。

## 2. 一胞的严格 layer-cake 积分

在 I_C=1 上，令 r=2||x-z_C||_infty，则 L,R>=r。置 alpha=A_C/q、beta=B_C/(4lambda)。由 (B)

\[
I_C F_CG_C/q\le
4\lambda\min(1,\alpha/r^n)\min(1,\beta/r^n).
\]

r=0 时按连续上界定义。完整径向体积 |{r^n<=v}|=v，故正 Tonelli/一维层积分给

\[
\int_E I_C F_CG_C/q\,dx
\le4\lambda\int_0^\infty\min(1,\alpha/v)\min(1,\beta/v)dv.
\]

若 alpha,beta>0，设 alpha<=beta，右侧积分精确为

\[
\mathcal I(\alpha,\beta)
=\alpha+\alpha\log(\beta/\alpha)+\alpha
=\min(\alpha,\beta)\{2+\log(\max/\min)\}.
\tag{C}
\]

任一质量为零时取0。由 2+log t<=2sqrt(t)，t>=1，得

\[
\mathcal I\le2\sqrt{\alpha\beta},\qquad
\int_E I_C F_CG_C/q\le4\sqrt{\lambda/q}\sqrt{A_CB_C}
\le\frac8{\sqrt3}\sqrt{A_CB_C}.
\tag{D}
\]

这里对所有实际 L,R,s 一次成立；没有按比例带或尺度菜单求和。

## 3. 网格、原来源与 near 的正确分配

对任意 y,z，随机平移网格使其同胞的概率为

\[
p_d(y,z)=\prod_i(1-|y_i-z_i|/d)_+.
\]

若 ||y-z||_1<=d/2，则 p_d>=1-||y-z||_1/d>=1/2。因而原 near 双来源核可以正上放为 2 E_grid 1_samecell 倍原核，并按 I_C 与 1-I_C 分成两个非负 allocation。

这不是用系数2得到的逐点等式：两 allocation 的和可大于原 near 量。原 near 指示和其它原门可始终留在 allocation 中；证明 interior 上界时再正放它们。

由 (D)、每个网格胞不交及 Cauchy，

\[
2\mathbb E_{grid}\sum_C\int_E I_CF_CG_C/q
\le\frac{16}{\sqrt3}\sqrt{\|\rho\|\|\nu\|}.
\]

再对原叶和种子作一次 Cauchy，得到

\[
\boxed{\mathcal A_{int}\le\frac{16}{\sqrt3}\sqrt{W_\rho W_\nu}.}
\tag{E}
\]

可数网格先有限求和再正单调极限。不同来源不需独立随机模型；使用的是原母式本来存在的 rho(dy)nu(dz) 两槽积分。W 的叶集合始终是原同一组终端叶，不能复制祖先或 j。

若 q 并非常数而只知道每个 receiver 上 3lambda/4<=q(x)<=lambda，则不能在 (C) 中使用固定 alpha=A_C/q(x)。可改用 F_C<=min(lambda,A_C/L^n)、q(x)^(-1)<=4/(3lambda)，得到较宽的 allocation 常数 32/3。本文主常数 (E) 按原共同 q 资格使用。

## 4. 原小 R2 正交通的完整付款

原当前 good 槽 v 满足 R2(y,v)<=D 时，R280 主稿的逐行证明给

\[
\int_{\text{原有效 clock}}\iint\chi\,(k_t(v)-k_t(u))_+
 d\Pi_t(v)d\Pi_t(u)\,dt/t\le4\sqrt{nD}.
\tag{F}
\]

证明用 C(r)>=(1-r)_+、xi=c_jt/b>=1/2，得到 score<=min(n,D/(1-xi)²)，再积分。完整 Pi 未裁源；这是每个原 x,y,hard-z 行的上界，故原 hard-z/history 门即使存在，正放后仍合法。原 j(x) 唯一，先逐行换元，不额外复制 j。D=0 时连续交通为零。

将随机网格的 interior 门加入原 near 正交通，保 (F) 后再用 (E)。原外系数2Lambda给

\[
\boxed{P_{int}\le\frac{128\Lambda}{\sqrt3}\sqrt{nD}\sqrt{W_\rho W_\nu}
\le\frac{64\Lambda}{\sqrt3}\sqrt{nD}(W_\rho+W_\nu).}
\tag{G}
\]

对 R279 的 D=C0+C1log(n+2)，这是完整根阶多对数来源价，保其极大固定常数，不声称小维数实用。没有花费新的 epsilon X，也没有使用 nu<=beta。

此处 P_int 是上文系数2的原量 allocation。尚未付的是对应 boundary allocation：同胞 C 未同时包含于实际 source soft core 与 hard receiver cube。offcore 或靠窗边的来源可全部进入该 allocation；不能以随机平移或 near 条件直接断言它小。本稿没有把 (G) 宣称为整个 near 交通预算。

## 5. 本机有限检查

独立实际 Python/Fraction 检查了5组距离向量（含16坐标）下 p_d>=1-l1/d>=1/2；8组质量对（含零质量）检查 (C) 的显式值<=2sqrt(alpha beta)，全部 PASS。后者用标准库 log/sqrt 浮点，前者是精确有理；均非数学证明的替代。

```python
from fractions import Fraction as F
from math import log,sqrt
vectors=[[F(0)],[F(1,2)],[F(1,4),F(1,4)],
         [F(1,8)]*4,[F(1,32)]*16]
for xs in vectors:
    p=F(1)
    for x in xs:p*=1-x
    assert p>=1-sum(xs)>=F(1,2)
for A,B in [(1,1),(1,2),(1,16),(.01,1),(100,.1),(0,1),(1,0),(3,7)]:
    val=0 if not A or not B else min(A,B)*(2+log(max(A,B)/min(A,B)))
    assert val<=2*sqrt(A*B)+1e-12
print('PASS: 5 exact same-cell checks and 8 layer-cake checks')
```
