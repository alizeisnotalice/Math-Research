# R280 main-author independent audit

**Verdict: PASS for the scalar-window source bound and the original terminal-clock root payment.** Middle-clock traffic and global closure remain unproved.

Audited source read in full:

- `/tmp/r280_main.md`
- SHA256 `3d0d666b065b22f468744105ac59ad143fb65609febcdfac13bee9a0a954af02`.

The independent statement screen was saved before reading the author:

- `/tmp/r280_screen.md`
- SHA256 `b6f46f63431ffa548f32553b5c259a905f99e94565172500e41d863deb29e442`.

## Main deductions

1. **Score and physical time pass.** The R2 mask is on the same good/upper-score v slot. Strict activation and `C(r)>=(1-r)_+` give the pointwise bound (5) for every contributing pair; it is not attributed to the whole posterior carrier. D=0 contributes zero; the scalar convention at xi=1 has no continuous clock mass. The complete pair posterior is eliminated by this uniform score/probability bound before the physical-clock transformation is used downstream. The proof never treats the posterior at `t=b xi/c_j(x)` as x-independent.

2. **Unique-band/FIRST order passes.** The actual unique j mask is retained to the rowwise step, so the xi clock is shared once rather than charged separately for all j. The original validity `t<=g` and band give both L,R>=b xi/gamma. This validity is retained until the restricted hard-scale envelope is established. Dropping near/terminal hard restrictions makes the hard column independent of y, after which the actual input-FIRST cancels q^{-1}. No target-node FIRST, nu<=beta, or hardcap factor 16/3 is inserted. Extending the actual receiver integration only after these steps is legal.

3. **Radial hard envelope and closed scalar bounds pass.** The exact kernel mass in (8) is `1+n log(b/r)`, with the floor `r_*=max(a,b xi/gamma)`. Equations (7)–(9) legitimately dominate the actual selected hard column. Writing v=-log(xi) gives the exact scalar integral of `min(ell,log(gamma)+v)` in (11), including its clipping point. The two elementary integrals in section 4 yield (12) with the stated coefficients. D=0 is its continuous zero extension; D>=n gives a vacuous R2 mask and a bare scalar order-n^2 upper bound. Substitution of a fixed-constant-plus-log n cutoff yields only the stated order n log^2 n full-window bound, not root order.

4. **Terminal source payment passes.** The physical terminal strip, not a t/g strip, has width `(1/2)n^{-3/4}` in xi. Replacing score by n gives the explicit logarithmic integral in section 5. With `n log(gamma)<=1` and `-log(1-delta)<=2delta`, its price is at most `(5/2)sqrt(n)`. The original outside `2 Lambda` therefore gives precisely `5 Lambda sqrt(n) W_nu`, with no extra source/seed/j factor or epsilon X. The bound is independent of D and actual softness and applies to a smaller current-positive mask. It is charged once through a disjoint top/middle positive allocation; no old negative credit is altered.

5. **Source ledger passes with its original qualification.** The independently read primary R112 line 508 gives disjoint terminal V and `nu_V<=sigma_V<=alpha_V=mu_hi|V`; R113 retains this hard nu during the coupled soft change. The retained R273 source statement explicitly says `nu_V<=1_V f dx` on this same terminal collection, with no ancestor or j duplication. Consequently the author's `W_nu<=||f||_1` is justified here. It is not inferred from unrelated indexed measures each satisfying nu_V<=f, and no nu-to-beta relation is needed. If the collection is changed, retain W_nu and the corresponding multiplicity.

6. **The exact positive-layer representation (14) passes.** For `q0=2||x||_infinity<=b`,

   `h_b(x)+n integral_r^b h_R(x)dR/R`

   equals `b^{-n}+max(r,q0)^{-n}-b^{-n}=max(r,q0)^{-n}`. Outside Q_b it is zero. Thus it is the stated envelope, almost everywhere including harmless cube boundaries, and its mass is exactly (8). This identifies an explicit positive-envelope scale loss. This audit does not certify that this loss is optimal or the unique possible obstruction; the author's proposed further common-receiver improvement is not proved here.

## Numerical scope

The independent screen actually evaluated 15 scalar integral/terminal cases at each of mp40 and mp70, with reproducible code and precision limits. The author's separate 36 Simpson integrations plus 6 explicit terminal checks have the stated finite scalar scope and no certified integration-error bound; they were not independently rerun for this final review. Neither suite is used as proof or a FULL construction.

No necessary mathematical correction was found in the SHA-bound main source. The pending random-cell theorem and its proof are not certified by this main audit. No author/repository/Git/PDF file was changed. A separately requested conditional allocation audit, if provided, is distinct from this result.
