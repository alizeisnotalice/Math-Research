import json,hashlib,argparse
from pathlib import Path
from fractions import Fraction as F
import mpmath as m

def scalar(dps):
 with m.workdps(dps):
  rows=[]
  for phase,a,b in [('initial','1','1'),('initial','1','2'),('stress','1e-8','1'),('stress','0','1'),('expanded','1','1e12'),('expanded','1e6','1e-6')]:
   a,b=m.mpf(a),m.mpf(b);lo,hi=min(a,b),max(a,b)
   if lo==0:exact=quad=m.mpf(0)
   else:
    exact=lo*(2+m.log(hi/lo))
    # Separate exact endpoint regions and logarithmically change t=lo*exp(v) in the middle.
    quad=lo+m.quad(lambda v:lo,[0,m.log(hi/lo)])+lo*hi*m.quad(lambda v:m.exp(-v),[m.log(hi),m.inf])
   gm=2*m.sqrt(a*b);add=a+b
   assert abs(quad-exact)<=m.mpf(10)**(-dps+8)*max(1,exact)
   assert exact<=min(gm,add)+m.mpf(10)**(-dps+8)*max(1,exact)
   rows.append(dict(phase=phase,alpha=str(a),beta=str(b),closed=m.nstr(exact,80),integral=m.nstr(quad,80),geometric_bound=m.nstr(gm,80),additive_bound=m.nstr(add,80)))
  return rows
checks=[]
for n in [1,2,8,64,1024]:
 for typ in ['one','equal','ramp']:
  if typ=='one':r=[F(1,2)]+[F(0)]*(n-1)
  elif typ=='equal':r=[F(1,2*n)]*n
  else:r=[F(i+1,n*(n+1)) for i in range(n)]
  probability=F(1)
  for x in r:probability*=1-x
  assert sum(r)==F(1,2) and probability>=F(1,2)
  checks.append({'n':n,'profile':typ,'pass':True})
a=argparse.ArgumentParser();a.add_argument('--output',type=Path,required=True);args=a.parse_args()
lo,hi=scalar(40),scalar(60)
with m.workdps(90):
 diffs=[abs(m.mpf(x[k])-m.mpf(y[k]))/max(1,abs(m.mpf(y[k]))) for x,y in zip(lo,hi) for k in ['closed','integral','geometric_bound','additive_bound']]
 assert max(diffs)<m.mpf('1e-30')
 out={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mp40':lo,'mp60':hi,'exact_grid_checks':checks,'max_scaled_difference':m.nstr(max(diffs),60),'scope':'6 scalar mass pairs, 15 exact same-cell probabilities; no FULL source geometry, no rigorous interval quadrature. Source price follows analytic proof, not this menu.'}
args.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print('PASS',len(checks),'exact grid checks; 6 mass pairs at40/60; maxdiff',out['max_scaled_difference'])
