本轮使用 A02 外放松与正支配预算技能核对域包含、逐点支配及费用方向，不引用外部未读定理。几何证明自足；实际交通定义、FIRST、hardcap及终端来源账依赖原研究框架。

历史可移植依赖位于本项目：rounds/112/research.zip、rounds/273/research.zip、rounds/279/research.zip。R112主证明第508行附近：终端V不交，αV=μhi,ω|V，σV≤αV，νV≤σV。R273主证明首段明确同一终端集合νV≤1V fdx，Wν≤||f||1，不复制祖先或比例带。当前ρ≤β≤α，Wρ≤Wβ≤||f||1。R279的ns+R2阈值仅用于本轮interior的D，保留K、epsilon及极大常数依赖。

Numerical runtime: Python3.12.14; mpmath1.3.0. Local executable /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3; local library /Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor. On another machine use Python with mpmath installed. near_checks.py preserves its original optional local sys.path addition, then imports mpmath normally.
