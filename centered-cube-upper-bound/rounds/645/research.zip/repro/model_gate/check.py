#!/usr/bin/env python3
from fractions import Fraction as F
from math import comb
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from hashlib import sha256
import os,sys,time,resource,json

def work(n):
 start=time.perf_counter();cpu=time.process_time();cases=0;rs=[F(1,4),F(3,4),F(9,4),F(23,4),F(8*n+3,4)]
 p=[F(comb(n,k),2**n) for k in range(n+1)];pmax=max(p);assert (n+1)*pmax*pmax>=F(1,2)
 for r in rs:
  N=r.numerator//r.denominator;frac=r-N;assert frac in (F(1,4),F(3,4));A=2*(2*N+1);B=2*(2*N+(2 if frac==F(3,4) else 0));D=4*N+(1 if frac==F(1,4) else 3);assert A+B==2*D
  for q in range(n+1):
   coeff=[1]
   for a,b in [(A,B)]*(n-q)+[(B,A)]*q:
    nxt=[0]*(len(coeff)+1)
    for k,z in enumerate(coeff):nxt[k]+=a*z;nxt[k+1]+=b*z
    coeff=nxt
   assert sum(coeff)==(2*D)**n
   for k in range(n+1):
    Aqk=F(coeff[k],D**n*comb(n,k));assert Aqk>=0 and p[k]*Aqk<=1;cases+=1
 # exact central recurrence and explicit finite identities
 if n>=3 and n%2:
  pn2=F(comb(n-2,(n-2)//2),2**(n-2));assert pmax/pn2==F(n,n+1)
 if n>=2 and n%2==0:
  pn1=F(comb(n-1,(n-1)//2),2**(n-1));assert pmax==pn1
 return {'n':n,'radii':list(map(str,rs)),'q_k_checks':cases,'pmax':str(pmax),'central_residual':str((n+1)*pmax*pmax-F(1,2)),'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
if __name__=='__main__':
 start=time.perf_counter();ns=list(range(1,65));workers=min(15,os.cpu_count() or 1,len(ns))
 with ProcessPoolExecutor(max_workers=workers) as p:rows=list(p.map(work,ns))
 print(json.dumps({'results':rows,'workers':workers,'total_checks':sum(x['q_k_checks'] for x in rows),'wall_s':time.perf_counter()-start,'python':sys.version,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest()},indent=2))
