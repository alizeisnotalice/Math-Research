# Conditional deletion algebra

This package contains the verified polynomial comparison, normalized threshold and exact boundary checks. See INPUT.md for assumptions and RESULT.md for the proof. `check.py` contains the constants and writes `result.json` beside itself. To reproduce, use Python 3.12 with SymPy and run `python check.py` from any directory. Running it replaces the saved result with the current run's metadata and exact results.

Scope: the gate `h/V, q/V ≤ η²/121` applies only to the basic single-update loss bound proved in RESULT.md. It is not the later `ch+5L` gate, does not certify that the quadratic deletion hypothesis holds for a KKT solution, and does not establish a fixed-N geometric cutoff. Those require separate arguments.

RECEIPT.md identifies the actual earlier execution; packaging did not rerun the verified batch. Files use relative paths.
