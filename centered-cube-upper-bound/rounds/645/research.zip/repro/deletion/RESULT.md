# Conditional deletion algebra audit

The assumed hypotheses are V>0, 0<=h<=V, q>=0 and z²+(q−h)z<=h(V−h)+Vq. This calculation does not establish that any actual deletion or KKT solution satisfies them.

Put s=sqrt(V(h+q)) and B=h+s, and let p(x)=x²+(q−h)x−h(V−h)−Vq. Exact SymPy polynomial reduction modulo s²−V(h+q) gives p(B)=(h+q)(h+s)>=0. If z>B then p(z)−p(B)=(z−B)(z+B+q−h)>0 because z>B>=h and q>=0, contradicting p(z)<=0. Thus z<=h+sqrt(Vh+Vq), without requiring z>=0. For h=q=0, z²<=0 forces z=0, so the boundary is covered exactly; for h=0, q>0 the result is z<=sqrt(Vq). Fraction tests include both one-sided and simultaneous small h/V,q/V with exact polynomial residuals; they are checks, not the proof.

Assume additionally 0<=ell<=h, add<=sqrt(Vh), and 0<=κ=Rε<=4. The complete stated loss is at most ell+κ[h+sqrt(Vh+Vq)+sqrt(Vh)]. If h/V,q/V<=t, this is <=V[5t+4(sqrt(2)+1)sqrt(t)] <=V[5t+10sqrt(t)], using sqrt(2)<=3/2. For any 0<η<=1, the explicit choice t=η²/121 gives 5t+10sqrt(t)<=η(5/121+10/11)=115η/121<η. More generally for η>0 one may take t=min(1,η²)/121. The result keeps ell in the original loss; it uses ell<=h only for the last scalar bound.

If a separate geometric construction proves h/V<=A/N and q/V<=B/N for some A,B>=0 and integer cutoff N, the above sufficient condition is N>=121 max(A,B)/η² (round upward). This conditional O(η^-2) cutoff is not an assertion that such A,B bounds or a fixed-N deletion exist; their existence and dependencies on the original problem must be proved elsewhere.

Run: `python check.py`; Python 3.12.14, SymPy 1.14.0, single process, peak RSS 71,139,328 B; process wall about 0.3s. Exact inputs and outputs are check.py and result.json. No parallel or placeholder load was run.
