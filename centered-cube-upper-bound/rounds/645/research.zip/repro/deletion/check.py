from fractions import Fraction as F
from pathlib import Path
import sympy as s, json,sys,platform,time,resource
V,h,q,u=s.symbols('V h q u', nonnegative=True); assert s.simplify((h+u)**2+(q-h)*(h+u)-(h*(V-h)+V*q)).expand()==(-V*h-V*q+h**2+h*q+h*u+q*u+u**2)
remainder=s.factor(s.rem((h+u)**2+(q-h)*(h+u)-(h*(V-h)+V*q),u**2-V*(h+q),u))
assert s.expand(remainder-(h+q)*(h+u))==0
# explicit threshold t=eta²/121, valid 0<eta<=1
rows=[]
for eta in [F(1),F(1,2),F(1,10),F(1,100)]:
 t=eta**2/F(121);r=eta/F(11) # eta/11: exact square root(t)
 assert r*r==t
 # sqrt(2t)<=3/2 sqrt(t) strictly; budget at kappa=4
 bound=5*t+4*(F(3,2)+1)*r
 assert bound<=eta
 rows.append({'eta':str(eta),'t':str(t),'sqrt_t':str(r),'rational_bound_over_V':str(bound),'margin':str(eta-bound)})
# For q=h=0, z²<=0 and z>=0 implies z=0; for small rational parameters the polynomial root bound via a rational square root.
cases=[]
for k in (0,4,8,12,16):
 a=F(1,2**(2*k)); b=F(0); srt=F(1,2**k);r=a+srt; z=F(0);p=r*r+(b-a)*r-a*(1-a)-b
 assert p==(a+b)*r and p>=0
 cases.append({'h_over_V':str(a),'q_over_V':'0','bound_z_over_V':str(r),'polynomial_at_bound':str(p)})
joint=[]
for k in (1,4,8,12):
 for a,b in [(F(0),F(1,4**k)),(F(1,2*4**k),F(1,2*4**k))]:
  r=a+F(1,2**k);p=r*r+(b-a)*r-a*(1-a)-b;assert p==(a+b)*r and p>=0;joint.append({'h_over_V':str(a),'q_over_V':str(b),'bound_z_over_V':str(r),'polynomial_at_bound':str(p)})
out={'joint_cases':joint,'python':sys.version,'sympy':s.__version__,'platform':platform.platform(),'polynomial_at_h_plus_s':str(remainder),'thresholds':rows,'boundary_h_q_zero':'z²≤0, z≥0 implies z=0','small_rational_cases':cases,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
Path(__file__).with_name('result.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
