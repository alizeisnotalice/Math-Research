# Execution receipt

Previously executed `check.py` with the local math-research Python 3.12.14 and SymPy 1.14.0 in one process. The successful run took approximately 0.3 seconds wall time as observed in its tool execution; `result.json` records peak RSS 71,139,328 bytes. CPU time was not separately recorded. The program constants and exact results are included; no fresh batch was run during packaging.

SHA-256:

- `check.py`: `d80eb5b9e253734fa31bce1fe4924c1feee8d6c29fbabdc94eb41e8a430d0c05`
- `INPUT.md`: `1fa590d17e1038740dffb6f9be784d20994a48b231507a154b98c82a1ac270ca`
- `RESULT.md`: `a9de2989f2871acc1d8f1457ad02272c4ba56c215e35f060b5f3671a2ec536d7`
- `result.json`: `6a037388daab9c0c86c555b3bdcd1e1d774c00eeacd90f183fa397fe367ccb55`
- `README.md`: `2dac3504f30a333247bfe4098632dc86eb07097d9612ed2d0fb42b1e834b7e92`
