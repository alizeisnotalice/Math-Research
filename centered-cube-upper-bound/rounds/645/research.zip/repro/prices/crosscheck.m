k=[3.5,4]; A=k.^2./(8*(k+2)); B=k.^2./(k+2).^2;
for i=1:numel(k), fprintf('k=%g A=%.16g B=%.16g\n',k(i),A(i),B(i)); end
fprintf('MATLAB %s\n',version);
