# Sharp price bounds under the quadratic moment constraint

Let V=Σv_i>0, v_i≥0, r_i∈R and Σv_i(r_i²−r_i)≤0. Both formulas are sharp for every κ>0, hence for κ∈[7/2,4]. Set p_i=1+κr_i and t=κ²/[2(κ+2)]. The pointwise majorant

    p^− ≤ t(r−1/2)² = t/4 + t(r²−r)

holds because the right-hand side is nonnegative, and its difference from −1−κr is t[r+(κ+4)/(2κ)]². Summing and using the constraint yields Σv p^−≤κ²V/[8(κ+2)]. Equality is achieved by the two-point weighted law r=−(κ+4)/(2κ) with mass fraction κ²/[4(κ+2)²], and r=1/2 otherwise. Its quadratic moment is exactly zero.

For the nonpositive-price labels, the pointwise majorant

    1{r≤−1/κ} ≤ 4κ²(r−1/2)²/(κ+2)²
                    = κ²/(κ+2)² + [4κ²/(κ+2)²](r²−r)

holds: the quadratic is nonnegative everywhere and is at least 1 on the stated half-line. Summation gives Σ_{p≤0}v≤κ²V/(κ+2)². Equality uses r=−1/κ with weight κ²/(κ+2)² and r=1/2 otherwise; again the moment is exactly zero. The boundary r=−1/κ is included, so this is an equality for the nonpositive, not strictly negative, indicator.

Both constants increase in κ>0. At κ=7/2 they are 49/176 and 49/121; at κ=4 they are 1/3 and 4/9. These are universal moment bounds: equality laws establish optimality in this abstract class. They do not justify deleting labels or settle the genuine source cost or complete F budget.

SymPy 1.14.0 / Python 3.12.14 actually verified the identities, equality laws, monotonic derivatives and endpoint fractions: `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /usr/bin/time -l python verify.py`, in this folder; the original run used the local math-tools Python 3.12.14 interpreter. Wall 0.26s, user 0.23s, max RSS 73,367,552 bytes. Script SHA-256 5c6a74ab350a9ff936ad894f0e36d129fbb33194386370e78168f6f952271fbe; results.json SHA-256 68011a66276504757d115677b508a97986de45bb8742f56f5090b7a8a4b6daec.

A separate MATLAB batch cross-check ran `/Applications/MATLAB_R2026a.app/bin/matlab -batch "run('crosscheck.m')" -singleCompThread` from this folder. The actual earlier command was `/Applications/MATLAB_R2026a.app/bin/matlab -batch "run('/tmp/ccu_r645/price_numeric/crosscheck.m')" -singleCompThread -sd /tmp/ccu_r645/price_numeric`. R2026a Update 4 reported 0.2784090909090909 and 0.4049586776859504 at 3.5, and 0.3333333333333333 and 0.4444444444444444 at 4. Wall 31.94s, user 4.75s, max RSS 1,168,293,888 bytes. MATLAB floating output is a cross-check, not the rigorous proof; the existing MATLAB session was not altered.
