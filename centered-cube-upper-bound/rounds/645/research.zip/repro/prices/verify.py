from fractions import Fraction as F
from pathlib import Path
import sympy as s,json,sys,time,hashlib,resource
k,r=s.symbols('k r',positive=True,real=True); x=s.symbols('x',real=True)
t=k**2/(2*(k+2));C=t/4;u=-(k+4)/(2*k);A=k**2/(8*(k+2));B=k**2/(k+2)**2
q=t*(x-s.Rational(1,2))**2
assert s.simplify(q-(-1-k*x)-t*(x-u)**2)==0
assert s.simplify(q-C-t*(x*x-x))==0
p=x-s.Rational(1,2);indicator_q=4*k**2*p**2/(k+2)**2
assert s.simplify(indicator_q-B-4*k**2/(k+2)**2*(x*x-x))==0
assert s.simplify(indicator_q.subs(x,-1/k)-1)==0
w1=k**2/(4*(k+2)**2);w2=B
for w,at in [(w1,u),(w2,-1/k)]:
 assert s.simplify(w*(at*at-at)+(1-w)*(s.Rational(1,4)-s.Rational(1,2)))==0
 assert s.simplify(w+(1-w)-1)==0
assert s.simplify(w1*(-1-k*u)-A)==0
assert s.simplify(w2-B)==0
assert s.factor(s.diff(A,k))==k*(k+4)/(8*(k+2)**2)
assert s.factor(s.diff(B,k))==4*k/(k+2)**3
assert s.simplify(1-w2-4*(k+1)/(k+2)**2)==0
assert s.simplify(u+1/k)==-(k+2)/(2*k)
assert s.simplify(q.subs(x,u)-(-1-k*u))==0
assert s.simplify(q.subs(x,s.Rational(1,2)))==0
out=[]
for kv in (s.Rational(7,2),s.Rational(4)):
 vals={'k':str(kv),'negative_price_constant':str(A.subs(k,kv)),'nonpositive_owned_fraction':str(B.subs(k,kv)),'price_negative_atom':str(u.subs(k,kv)),'price_negative_weight':str(w1.subs(k,kv)),'nonpositive_atom':str((-1/k).subs(k,kv)),'nonpositive_weight':str(w2.subs(k,kv))}
 out.append(vals)
assert out[0]['negative_price_constant']=='49/176' and out[1]['negative_price_constant']=='1/3'
assert out[0]['nonpositive_owned_fraction']=='49/121' and out[1]['nonpositive_owned_fraction']=='4/9'
res={'status':'PASS','scope':'sharp algebraic bounds under signed real r and moment constraint, no source or complete F budget','identities':'symbolic for every k>0','endpoints':out,'python':sys.version,'sympy':s.__version__,'max_rss_platform_units':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
Path(__file__).with_name('results.json').write_text(json.dumps(res,indent=2)+'\n');print('PASS all symbolic identities; endpoint values',out)
