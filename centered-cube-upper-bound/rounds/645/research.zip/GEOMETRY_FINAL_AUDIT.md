# R645 final geometry/model-gate transplant audit

**Verdict: PASS for the corrected mathematical transplant in §§5–6.** The requested manuscript clarifications in §4 have now been reread and resolved. The report does not prove F_own or a general root/polylog weak bound.

Report: `/tmp/ccu_r645_final/REPORT.tex`

Read and verified final SHA-256: `34268b57bf0258a86eee68231f6f8924ba4766487b032376d19f4b76b1667aae`.

This pass compares the assigned sections with `/tmp/ccu_r645/JOINT_VARIATION_AUDIT.md` and `/tmp/ccu_r645/MODEL_GATE_AUDIT.md`. It does not redo their derivations, the 468320 checks, or audits owned by other agents. Only this audit was written.

## 1. Joint derivative, rent and quotient

The fixed-face formula has the correct factors and sign: K excludes ε, Kd=−εh, `dQ=(λ−h)·dd−εr·dv`, and R is held fixed. The same actual branch or same convex combination must supply both cost and receiver components. The report retains this requirement and expressly rejects promoting an owner-only mix to geometry support.

The positive normal correction b has the correct sign, active-only support and covariance upper bound. The effective receiver price is p+κb, while the source surcharge `κΣλ_jm_jb_j` and the receiver residual `−κb·dv` remain present. The unsupported rent=0 inference is completely removed. No claim remains that fixed-geometry ownership stationarity alone kills rent.

The source-normal quotient uses the same positive packet decomposition, arbitrary real c_K only as algebraic parameters, reciprocal weights 1/v_j and factor R sqrt(E). It correctly uses projection energy E, not the raw growth variance. The full-dilation residual vanishes with c_K=n. No separate per-time source budget or full-path bound is inferred.

At nonsmooth points, these are branch or common-mix statements. An owner-selected mixture is not asserted to be an actual derivative along every geometry path or to use the later canonical new α. The report preserves that distinction.

## 2. Conditional stress and unpaid geometry

The stress paragraph is conditional on a separately obtained genuine joint extremum and compatible common generalized-gradient/normal equations; it does not establish such an extremizer or its multipliers. The receiver blocks and cost t=1−r must belong to that same joint selection. In a mixed or degenerate configuration, a max-envelope shape derivative is not substituted for those blocks.

The cube velocity moves only coordinate i of all centers and uses s_j/n for each cube's common radius. It is a true cube deformation. The factor n in the cost radius derivative cancels correctly, and its contact-wall work gives `C_i−mean(C)`. All artificial normal work is retained. The velocity may fail to be tag feasible, so the equation is only a test of already valid normal equations. Signed multipliers, isotropic pressure, finite actual-Q jumps and the complete platform cost remain unpaid. The report does not turn traceless balancing into a sqrt(n) gain.

## 3. Periodic model gate and numerical scope

The model argument agrees with the independent audit: nonnegative column coefficients sum to 2^n for each independently chosen allowed radius, hence β=p_ke_k is a simultaneous feasible linear witness. The actual-Q gap follows directly from supporting-gradient testing of a zero-allowed linear optimizer and totals εΣp=ε. Neither β_k≤1 nor monotonicity of Q's linear part under feasible-set enlargement is used.

On κ≤4, the model gives `R≤5/p_max≤5sqrt[2(n+1)]`; on κ≥7/2 it gives `H≤5sqrt[2(n+1)]/(7P)`. The central recurrences printed in the report are correct. The uncompressed physical extension explicitly requires the single-column witness to be feasible at every true phase and applies the cost gap afresh in that actual problem, rather than asserting equality of compressed/uncompressed Q_ε.

The conclusions remain restricted to the specified periodic model. Finite families are mentioned only through the previously proved fixed-data limiting transfer, not a uniform boundary-free estimate for arbitrary finite geometry. The 468320 Fraction checks are described as auxiliary to the analytic proof, and neither those samples nor model LP values are called a general root bound. This audit did not rerun or certify the timing/tool receipt.

## 4. Requested clarifications, now resolved

1. The quotient currently writes `dot F`, but §4 already defines F=Σf_K as source supply. Introduce a distinct local objective, e.g. `D_loc=V−RQ` with fixed R, and use its derivative in the quotient. Otherwise this formula's left side is ambiguous and could literally refer to the wrong F.
2. The displayed rent chain ends in `≤ηV` without stating the required ζ–η selection in this report. Add `0<ζ≤η²/(4+η²)` (κ≤4 is already part of the frame). The preceding sharp covariance bound is correct for arbitrary ζ∈(0,1), but its last ηV bound is not.

These issues were present at the earlier checkpoint SHA `9d00fc24438da723d5b0160faa65a16d5da51be62404d0d298f9f4183c238375`. The corrected version explicitly defines the fixed-R local objective as mathscr D, uses its derivative in the quotient, and states `0<ζ≤η²/(4+η²)` before the rent bound. Both edits were actually reread.

For completeness, the binomial induction can be made explicit without new calculations: define a new dimension-indexed symbol `c_n=2^(−n)C(n,floor(n/2))`, distinct from the earlier column weights p_k. The odd normalized squares have consecutive ratio `(2m+3)^2/[(2m+2)(2m+4)]>1`, starting at 1/2; adjacent even values c_(2m+2)=c_(2m+1) then give the even case. The current two recurrences imply this result, so this is a clarity improvement, not a mathematical failure of the constant.

The final version also defines dimension-indexed c_n separately from column weights p_k and gives the odd-subsequence ratio before the even case. This clarification was reread and is correct. No unresolved substantive mathematical correction remains in the assigned sections. No numerical rerun or historical re-audit was performed. The complete D budget remains unproved. Stop.

Final TeX-only freeze: reread the repaired gamma maximization with text-form clique qualification and the preamble addition of mathrsfs. Independently verified SHA-256 `a58ea16b8163d1a39d59c54922931280c22aa88f26ae802159ffc932ca1d8c03`. No mathematics changed and no compilation or numerical rerun was performed. PASS unchanged.

Last text-only freeze: reread the two repaired Q_{mathrm{lin}} occurrences in the model-gate witness and cost-gap lines. Independently verified current REPORT SHA-256 `34268b57bf0258a86eee68231f6f8924ba4766487b032376d19f4b76b1667aae`. Mathematics and PASS verdict are unchanged; no compilation or numerical batch was rerun.
