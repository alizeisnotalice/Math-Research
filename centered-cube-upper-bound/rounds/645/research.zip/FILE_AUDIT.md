# R645 final-file audit

Scope: only `/tmp/ccu_r645_final/REPORT.tex`, the three `*_FINAL_AUDIT.md` files, and `repro/`. No mathematical certification or numerical script execution was performed. This file is excluded from its own manifest.

## Inventory and hash bindings

- Pre-manifest files: **18**; total size: **57,075 bytes**.
- The actual `REPORT.tex` SHA-256 is the requested final value: `34268b57bf0258a86eee68231f6f8924ba4766487b032376d19f4b76b1667aae`.
- All three final audits now cite that exact report SHA. The earlier pending hash-binding issue is resolved.
- No PDF, cache, temporary, bytecode, or repeated large payload files found. Largest file is `REPORT.tex` (19,627 bytes); all repro artifacts together are 19,681 bytes.

## Repro portability and receipt checks

- `repro/prices/verify.py` has no external input and writes its output beside itself. `results.json` records the exact packaged script SHA (`5c6a74…271fbe`). `crosscheck.m` is self-contained. `REPORT.md` distinguishes the prior run in `/tmp/ccu_r645/price_numeric` from the portable packaged invocation; no `/tmp` input dependency remains.
- `repro/deletion/check.py` writes `result.json` adjacent to itself; no external file inputs. `RECEIPT.md` says the captured run predates packaging and packaging did not rerun it. Its SHA entries for all six package files match the files present.
- `repro/model_gate/check.py` has no external file inputs. The packaged script SHA matches `receipt.json`'s `original_script_sha256`; all three `SHA256SUMS` entries verify. The receipt also records an `original_output_sha256`, but the corresponding full original `results.json` is intentionally absent; only the compact receipt is packaged, so that output digest cannot be rechecked from this directory. `README.md` separates the original batch from the packaged files and does not claim a rerun.
- Main report §7 says actual interpreters, versions, commands, inputs, outputs and timings are retained in repro, and the successful batches were not rerun during packaging. It also says no PDF was compiled. This matches the per-package receipts/docs above.

## Minimum file whitelist

Retain `REPORT.tex`, the three final audit files, and all current `repro/` files. The small Markdown notes explain assumptions and execution provenance; JSON files contain the recorded inputs/results/receipts; scripts are the portable checks. `repro/model_gate/SHA256SUMS` verifies its three listed files. There are no obvious duplicate large outputs to remove. The earlier stale REPORT SHA in BRIDGE has been updated and now matches the other audits.

## Independent SHA-256 manifest

Paths are relative to `/tmp/ccu_r645_final`; sizes are exact bytes.

| File | Bytes | SHA-256 |
|---|---:|---|
| `BRIDGE_FINAL_AUDIT.md` | 5,616 | `2c9306b7070bb1b0e1a5cd450a39ffdb70363dcd05266bf0ae2c756468bc2e1e` |
| `GEOMETRY_FINAL_AUDIT.md` | 6,816 | `8d32061d8b7569d43ae1c6fbd0b129e28d3a228c4a6400287ee4379298b3f3ca` |
| `LEDGER_FINAL_AUDIT.md` | 5,335 | `a1d65b71c26ffed15f311ea21a3f9c95527bac06a85723c4e51fdf9e268d25b1` |
| `REPORT.tex` | 19,627 | `34268b57bf0258a86eee68231f6f8924ba4766487b032376d19f4b76b1667aae` |
| `repro/deletion/INPUT.md` | 619 | `1fa590d17e1038740dffb6f9be784d20994a48b231507a154b98c82a1ac270ca` |
| `repro/deletion/README.md` | 882 | `2dac3504f30a333247bfe4098632dc86eb07097d9612ed2d0fb42b1e834b7e92` |
| `repro/deletion/RECEIPT.md` | 827 | `2e27e5f8dc8b6f8aab6e78bcd4e9c3b6e8fcf41555cfe57169ae8cca1fed6422` |
| `repro/deletion/RESULT.md` | 1,785 | `a9de2989f2871acc1d8f1457ad02272c4ba56c215e35f060b5f3671a2ec536d7` |
| `repro/deletion/check.py` | 1,809 | `d80eb5b9e253734fa31bce1fe4924c1feee8d6c29fbabdc94eb41e8a430d0c05` |
| `repro/deletion/result.json` | 2,833 | `6a037388daab9c0c86c555b3bdcd1e1d774c00eeacd90f183fa397fe367ccb55` |
| `repro/model_gate/README.md` | 2,327 | `101b367b79cecb992dff5c61b5a1844e21235ffe15af8333193baae80c480d12` |
| `repro/model_gate/SHA256SUMS` | 230 | `b607fa8ed0e5b795f7a7ed4f6f19ef9e661b6feb61047cf4ad1f881716ad99d1` |
| `repro/model_gate/check.py` | 1,811 | `c24e07d037c2559c1770321b3e4b4a2162e27758eb867658cdb38af228b20361` |
| `repro/model_gate/receipt.json` | 804 | `2d05767a8bef466e63124006262b7e8cbd9997b23e79ade3a1947e51b1ab7c09` |
| `repro/prices/REPORT.md` | 2,587 | `041cb1c38427724175a735494909d8dc5c5f567cbedf5b071333964362457fc2` |
| `repro/prices/crosscheck.m` | 152 | `fb4af74d4bbd1e649139f6512e9987a7b3cee1c67023fe25cbad337b0226c8e5` |
| `repro/prices/results.json` | 936 | `68011a66276504757d115677b508a97986de45bb8742f56f5090b7a8a4b6daec` |
| `repro/prices/verify.py` | 2,079 | `5c6a74ab350a9ff936ad894f0e36d129fbb33194386370e78168f6f952271fbe` |
