from pathlib import Path
import ast, hashlib, json, re, sys
import sympy as s
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for name,digest in manifest['sha256'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for f in root.rglob('*.py'): ast.parse(f.read_text())
report=(root/'REPORT.tex').read_text()
assert not any(ord(c)<32 and c not in '\n\t' for c in report)
assert report.count(r'\begin{document}')==report.count(r'\end{document}')==1
stack=[]
for sign,env in re.findall(r'\\(begin|end)\{([^}]+)\}',report):
    if sign=='begin':stack.append(env)
    else:assert stack.pop()==env,(sign,env)
assert not stack
V,h,q,z,k,r=s.symbols('V h q z k r')
assert s.expand((V-z)*(V-h+z+q)-(V-h)**2-(-z*z+(h-q)*z+h*(V-h)+V*q))==0
t=k*k/(2*(k+2))
assert s.simplify(t*(r-s.Rational(1,2))**2+1+k*r-t*(r+(k+4)/(2*k))**2)==0
assert s.simplify(k*k/(8*(k+2))-t/4)==0
assert s.simplify((2*z+3)**2-(2*z+2)*(2*z+4))==1
print(json.dumps({'status':'PASS','manifest_files':len(manifest['sha256']),'symbolic_identities':4,'python':sys.version.split()[0],'sympy':s.__version__,'full_numeric_batches_rerun':False,'pdf_compiled':False}))
