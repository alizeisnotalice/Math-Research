# R645 final bridge / price-direction transplant audit

Limited §§3–4 transplant audit against the already completed independent CONTACT_BRIDGE_AUDIT.md, JOINT_AUDIT.md and DUAL_DIRECTION_AUDIT.md. No proof, numerical batch, LP or scan was rerun. No report file was changed by this reviewer.

Audited REPORT.tex SHA256: `34268b57bf0258a86eee68231f6f8924ba4766487b032376d19f4b76b1667aae`.

Verdict: mathematical transplant PASS. All requested corrections are now confirmed; no correction remains pending in this limited scope.

## Final correction confirmation

The §4 packet identity now correctly reads `$\sum_{j\in K}\lambda_jr_j=0$`. The gamma maximum explicitly ranges over all original labels' actual new cliques; its formula now uses a valid `\text{ 为实际新 clique}` subscript. The preliminary ledger now defines `$L_0=\max_{\mathcal P_A}d\beta$`. These are the three requested fixes. The accidental intermediate gamma formatting was removed before this final binding. No new global mathematical claim was added in these corrections.

## PASS: §3 tagged recovery bridge

The statement retains a realizable same-N, same-epsilon, fixed complete old P_tag sequence, nondegenerate limiting radii and positive limiting old owners. It does not identify the limit's physical old packing with P_tag. Its warning that extra contact membership prevents equality of physical atomic old moments or saturation is correct: those physical closed-old moments are only at least the tagged m.

The action must already be strictly inside every displacement coordinate. Strict containment puts each old closed tag point in an actual positive-volume new intersection, so a shared tagged source of mass M becomes an actual AC new cover with row moments >=m. It is not called an old AC KKT normal or a new gradient normal.

Common center expansion preserves every positive pair, preserves strict separation and converts touching pairs into strict separation. Thus the entire positive-intersection graph, and by cube Helly the entire new packing polytope, stay unchanged. It does not cross an arbitrary wall and invoke generic continuity. Strict interior keeps the perturbed canonical action legal.

The actual ownership transfer by retaining each old piece inside its perturbed receiver and assigning the remaining union is correctly transplanted. Positive final weights and fixed new packing give actual alpha and Q' continuity. A strict complete margin therefore survives. Boundary good actions are not granted free internalization.

The retained-subset paragraph correctly freezes a limiting true-zero deletion and recovers a legal same-epsilon <=N complete successor. It does not claim those omitted rows remain exactly zero in every nearby full canonical family, or add tiny owner floors for free. This is the allowed larger complete-output comparison; it does not prove an all-original-rows/exact-zero-only output theorem without further hypotheses.

The same-class near-supremum cap D_k<=(S_hat_N-R_k)M_k correctly retains the nonnegative factor and Q'_k<=M_k. Taking limits and then removing the small graph-preserving perturbation yields the stated cap. The report expressly leaves nondegenerate compactness, attained geometric extrema, critical-endpoint one-sided recovery, support prices and contact jumps unpaid.

## PASS: §4 layer, supply and signed-price budgets

The threshold constants, strict E>0 condition, owned-mass V_t definition and actual union-minus-owner C_t are unchanged. The same threshold supplies V_t>=3E/8 and C_t<=8V Gp/(3kappa E).

The final text now correctly distinguishes soft supply F>=3epsilon E/4 from hard-layer supply F_t>=3epsilon E/8. It retains all old row demands, old minimum repair cost exactly F, and common-Z new repair B_Z(b)<=F. It calls supply distinct from gain. The threshold-average loss is explicitly required to pair with repair credit under the same distribution, resolving the earlier possible quantifier ambiguity.

Both negative-price bounds and their square majorants/equality supports are unchanged and correct in the abstract moment class. They do not authorize free row deletion or payment of its source/regularization costs.

## PASS: §4 projection and actual-alpha direction

The projection set uses the full old P_A, m beta=M and d beta>=Q; it contains lambda. Projection in diag(v/lambda^2), followed by mixing lambda, gives the stated positive beta, d-cost range, saturation of every positive source packet and owned squared error <=E. The text does not promote this owned norm to a full receiver-max envelope estimate.

With the full-label actual-new-clique gamma, beta/gamma is feasible and gamma>=1. The final inequality F/gamma<=B_Z(b)<=F correctly gives only an upper cap on T_Z. Single-dual exclusion is not presented as a uniform loss of the whole optimal face.

The actual retained KKT test correctly includes a_Z=sum_(not J)m_j beta_j and the actual sum_(J)w_j beta_j/alpha_j. Its Q' inequality is a **lower** bound, hence it cannot provide the desired D lower bound. No deletion credit, actual denominator or logarithmic-versus-linear distinction has been lost in the transplant.

The final report does not promote these permissions, supplies, signed budgets or upper caps into a complete positive joint budget. No mathematical correction remains required in this limited scope. Audit complete; stop.

Final hash rebind: two broken Q-linear TeX spellings in section 6 were subsequently repaired. These are pure TeX changes outside this sections 3-4 mathematical audit; no new claim is certified here. The SHA above binds that final report.
