# R645 正式主稿：§1–2、§7 总账终审

审核对象：`/tmp/ccu_r645_final/REPORT.tex`。
SHA-256：`34268b57bf0258a86eee68231f6f8924ba4766487b032376d19f4b76b1667aae`。

该最终版包括主代理说明的纯 TeX 修正；最近一次仅将§6两处损坏的线性值下标恢复为 `Q_{\mathrm{lin}}`。本审核§1–2、§7的数学范围和结论保持不变，未重新作数学审核。

**结论：所审三节通过，未发现需修正的实质错误。** 本审只对§1–2和§7作正式判定，对照本支 `GLOBAL_LEDGER_AUDIT.md`、`DELETION_AUDIT.md`，不替代其他独审对正文其余数学的审核。没有重推已审条目、重跑数值、修改正文或操作 Git。一般根阶预算仍未证明。

## 1. §1 的完整账及有符号净损失

旧真实 ownership 不交且覆盖实际 union；新接收中心位移没有错误除以a。λ、α均是各自完整实际正则问题的最优权，Q、Q′为其线性部分；同一旧 AC 来源和原输入f区分清楚。

对全部实际 canonical receivers，E_j⊂C_j/a、|E_j|=g_jv_j。正文的

\[
O=\sum|E_j|-|\cup E_j|\ge0,
\quad F_{\rm fill}=W-|\cup E_j|\ge0
\]

分别是非负 raw overlap与填充；Σg_jv_j−W=O−Ffill只是**有符号净损失**。没有把它误称为非负overlap。E_grow=Σg_jv_j−(1+κ)V等于ε倍raw增长方差，非negative，但不是Euler投影能量E或旧barrier差额。

完整恒等式

\[
D=E_{\rm grow}-O+F_{\rm fill}+RS
\]

通过。真实零owner删行不改变满标签receiver union至零测集；若采用另一种冻结子集输出，正文已要求另保留遗漏片费用，不能把满标签E_j式无条件套给该子集。

R643端点账亦保留全部scale/contact、linear删零及barrier项。按冻结定义，Z是满标签新linear容量减retained容量，B1是retained新linear容量减actual Q′；S中已含这些实际信用，不能重复相加。RB0≤4V只在κ≤4的临界范围使用，仍为V级未付项，正文没有把它当作根阶余项已付。

目标的“足够大H”仍须按冻结F合同解释为统一绝对阈值，不得随N、尺度或source退化。本节没有宣称该目标成立。

## 2. §2 任意删行及后继 lift 费用

一般删除定理的量词正确：任意H0，G非空，原λ为actual最优；没有universal/join假设。两次支持梯度与Cauchy给精确二次式，Qtilde减的是**旧全族Q**，q_H没有被漏掉。实际余ownership通过保留旧片并分配h−ℓ真实残片实现，保留行仍正；新增权的优化比较合法，继承权中间问题没有冒充完整实际覆盖。

因此

\[
Q_G\le Q+E_d,\quad
E_d=\epsilon h+\sqrt{\epsilon^2Vh+\epsilon Vq_H}
      +\epsilon\sqrt{Vh}
\]

以及L=ℓ+RE_d、M_G≤M+E_d−εℓ均与独审一致。新λ、m和μ须重求；后继 \(Q_+\le M_G\) 时的返回原R价格是 \((R-R_G)_+Q_+\le(1+\kappa)L\)，不是仅ℓ或RΔQ。因此c h+(1+κ)L和负的CL_nM_G必须保留，正文已明确。

### cutoff 6400及两种费用不可混用

逐row条件

\[
d_{\rm cut}\le\frac{\eta^2V}{6400N(a^{-n}+\epsilon^{-1})}
\]

确给w=h/V+q_H/(εV)≤η²/6400。所列L/V≤5w+8√w与(ch+5L)/V≤26w+40√w≤η对0<c≤1、η≤1、κ≤4成立。这支付完整leading lift，不替代另记M_G变化。h<V确保G非空，实际保留weights不归零。

较大总量阈值Σd≤η²εV/256在ε≤1时只付**单次输入更新**的基础ℓ+RΔQ；同η不保证后继ch+5L。正文已按独审明确：要用该形式付后继lift，先取参数η/4，得到Σd≤η²εV/4096，同时仍保M_G。没有把基础gate冒充全量lift。

critical范围也没有免费继承：原κ≥15/4、η≤1/4时保κ_G>7/2的示例通过；上界κ_G≤4来自同ε、≤N的校准supremum，而非删除不等式。任意删行可新造universal，必要时R642一次删除费用仍须结算。

### Hellinger与规范化

同几何正v,w、总量V的actual比较

\[
|Q(w)-Q(v)|\le\epsilon\sqrt{V^2-(\sum\sqrt{v_jw_j})^2}
\]

正确，无稳定face或Q凹性假设。ζ<1使w=(1−ζ)v+ζb仍正，给εV√ζ；物理应用中的b应是coverage-base分配，正文所选等分参考确实如此，可由真实cell切分实现。固定几何image base紧且正，允许在该像上取actual Q最小值；不推广为全几何attainment。

V=1下s≤a/2、组件整体平移排入[0,2Na]^n且保旧v,d,λ,Q,M通过。正文同时注明它改变未来跨组件contacts、不是原位置动作等价，故没有隐藏后继费用。

## 3. §7 的结论范围

本轮已付的是有限输入截断/正规化和特定当前receiver价格费用。§7正确保留同一次

\[
RS+E_{\rm grow}-O+F_{\rm fill}
\]

的正cV缺口，也明确没有统一收缩、可求和费用与受控终端的新递推。它没有把供应量、single-dual违规、tagged恢复权限、restricted periodic root gate或坐标平衡当成fulljoint付款。

同ε、至多N、实际新ownership/α与重求source的规则保留；本审没有发现用basic费用替代后继lift、将MG改成旧M、免费丢zeroowner或把κ边界自动传递的步骤。

**最终判定：§1–2、§7的完整总账和已证费用归档通过；本轮无根阶改善，full F_own及V级RB0仍未付。** 其他数学范围由指定独审负责，本文件不作额外认证。审核完成停止。
