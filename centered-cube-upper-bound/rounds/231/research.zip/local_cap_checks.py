#!/usr/bin/env python3
"""R231 finite joint local-cap scale/clock checks; not a source-budget proof."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent

def mpf(s):
 q=F(s);return mp.mpf(q.numerator)/q.denominator

def geom(q,N):
 if not N:return (q*0,)*3
 if q==1:return (N,F(N*(N-1),2),F(N*(N-1)*(2*N-1),6))
 qN=q**N;d=1-q
 return ((1-qN)/d,(q-N*qN+(N-1)*qN*q)/d**2,(q*(1+q)-qN*(N*N+(-2*N*N+2*N+1)*q+(N-1)**2*q*q))/d**3)

def exact_checks():
 cases=[]
 for q in (F(1,2),F(1,3),F(4,9)):
  for N in (0,1,2,7,32):
   g=geom(q,N);brute=tuple(sum((F(i)**p*q**i for i in range(N)),F(0)) for p in range(3));assert g==brute
   cases.append({'q':str(q),'N':N,'moments':[str(v) for v in g],'exact_match':True})
 cubic=[]
 for R in (0,1,2,8,64,512):
  direct=sum((sum(range(m%2,m+1,2)) for m in range(2*R+1)))
  formula=F(R*(R+1)*(4*R+5),6);assert direct==formula
  positive_count=sum(sum(1 for k in range(m%2,m+1,2) if k>0) for m in range(2*R+1));assert positive_count==R*(R+1)
  cubic.append({'R':R,'saturated_sum_div_h':str(formula),'saturated_positive_pair_count':R*(R+1),'exact_direct_match':True})
 transfer=[]
 for n in (2,16,512):
  gamma=1+F(1,n)
  for j in sorted(set((0,1,n//4))):
   c=gamma**(-j);M=F(2)/gamma
   for t in (F(1),(1+gamma)/2,gamma):
    m=M*c*c/(t*t)
    if m<1:continue
    for lam in (F(1),gamma):
     Ms=M*lam;g=M*c/t;d=c*g;ds=c*c*Ms;ratio=ds/d
     assert 1<=m<=M<=2 and 1<=c*c*Ms<=Ms<=2 and g*g==m*M and 1<=t<=gamma and ratio==t*lam and ratio<=gamma**2
     transfer.append({'n':n,'j':j,'t':str(t),'Mstar_over_M':str(lam),'dstar_over_d_exact':str(ratio),'upper_gamma_squared':str(gamma**2),'physical_a_b':[1,2],'c_gamma_power_sha256':hashlib.sha256(str(c).encode()).hexdigest(),'exact_bounds':True})
 return {'finite_geometric_moment_cases':cases,'saturated_cubic_identity_checks':cubic,'saturated_identity':'For U=0, all global m<=2R saturated: S_regular/h=R(R+1)(4R+5)/6. This algebraic identity, not a fitted curve, exposes a cubic term when the window includes these nodes.','saturated_count_identity':'For U=0, global m<=2R including unique cap: positive (j,node) count=R(R+1).','cap_transfer_cases':transfer,'cap_transfer_formula':'Let t=c sqrt(mM)/m in [1,gamma], M*/M=lambda in [1,gamma]; then d*/d=t lambda<=gamma^2. No gamma-only claim.','scope':'Exact finite rational implementation checks; general identities stated independently.'}

def menu():
 out=[]
 for n in (2,16,64):
  for b in ('1','101/100','2'):
   for T in ('-4','0','2','8'):
    for U in ('0','1/2','4'):out.append({'stage':'initial','n':n,'b':b,'T':T,'U':U})
 for n in (2,16,64):
  for J in (0,1,3):
   for off in ('-1e-25','0','1e-25'):
    out.append({'stage':'stress','n':n,'b_gamma_power':2*J,'T_node':2,'T_offset':off,'U_node':1,'U_offset':off})
 for n in (512,4096,1000000):
  for T in ('-1000','0','1','10','100','1000'):
   for U in ('0','3','100','beyond_cap'):out.append({'stage':'expanded','n':n,'b':'2','T':T,'U':U})
 for n in (2,64,1000000):out.append({'stage':'rho_zero','n':n,'b':'2','T':'0','U':'0','rho_zero':True})
 return out

def evaluate(c,dps,brute=False):
 with mp.workdps(dps):
  n=c['n'];h=n*mp.log(1+mp.mpf(1)/n)
  if 'b_gamma_power' in c:
   # Cap b<=2: use exact log identity or the actual b=2 cap, whichever is smaller.
   X=min(c['b_gamma_power']*h,n*mp.log(2));b=mp.exp(X/n)
  else:b=mpf(c['b']);X=n*mp.log(b)
  T=c['T_node']*h+mp.mpf(c['T_offset']) if 'T_node' in c else mpf(c['T'])
  U=c['U_node']*h+mp.mpf(c['U_offset']) if 'U_node' in c else (X+1 if c['U']=='beyond_cap' else mpf(c['U']))
  assert U>=0 and 1<=b<=2
  Jmax=int(mp.floor(X/(2*h)))
  while 2*(Jmax+1)*h<=X:Jmax+=1
  while Jmax>=0 and 2*Jmax*h>X:Jmax-=1
  regular_count=max(0,int(mp.ceil(X/h)))
  while regular_count and (regular_count-1)*h>=X:regular_count-=1
  while regular_count*h<X:regular_count+=1
  eff=T-U;Tw=max(T,U);regular=mp.mpf(0);countregular=mp.mpf(0);active_nodes=0;blocks=[]
  for parity in (0,1):
   K=parity+2*max(0,int(mp.floor((U/h-parity)/2))+1)
   while K*h<=U:K+=2
   while K>=2 and (K-2)*h>U:K-=2
   N=max(0,(regular_count-1-K)//2+1);sat=min(N,max(0,int(mp.floor((Tw-K*h)/(2*h)))+1))
   while sat and (K+2*(sat-1))*h>Tw:sat-=1
   while sat<N and (K+2*sat)*h<=Tw:sat+=1
   s0=K*h-U
   def polynomial_segment(start,count,q):
    if not count:return mp.mpf(0)
    N0=start+1;aa=h;bb=s0+h*(2*N0-1);cc=N0*s0+h*N0*(N0-1);G=geom(q,count)
    return aa*G[2]+bb*G[1]+cc*G[0]
   saturated=polynomial_segment(0,sat,mp.mpf(1));unsat=polynomial_segment(sat,N-sat,mp.exp(-2*h))*mp.exp(Tw-(K+2*sat)*h) if N>sat else mp.mpf(0)
   regular+=saturated+unsat
   count_sat=mp.mpf(sat*(sat+1))/2
   Gcount=geom(mp.exp(-2*h),N-sat);count_unsat=(Gcount[1]+(sat+1)*Gcount[0])*mp.exp(Tw-(K+2*sat)*h) if N>sat else mp.mpf(0)
   countregular+=count_sat+count_unsat
   active_nodes+=N*(N+1)//2
   blocks.append({'parity':parity,'first_positive_clock_integer':K,'global_m_count':N,'saturated_m_count':sat,'unsaturated_m_count':N-sat,'count_saturated_sum':mp.nstr(count_sat,32),'count_geometric_sum':mp.nstr(count_unsat,32),'saturated_sum':mp.nstr(saturated,32),'geometric_sum':mp.nstr(unsat,32)})
  capcount=max(0,min(Jmax+1,int(mp.ceil((X-U)/(2*h)))))
  while capcount and X-2*(capcount-1)*h<=U:capcount-=1
  while capcount<Jmax+1 and X-2*capcount*h>U:capcount+=1
  capclock=capcount*(X-U)-h*capcount*(capcount-1)
  cap=capclock*(mp.exp(Tw-X) if Tw<X else 1)
  countcap=capcount*(mp.exp(Tw-X) if Tw<X else 1)
  quadratic=(1+max(eff,mp.mpf(0)))**2;countbase=countregular+countcap;countnormalized=countbase/quadratic
  cubic=(1+max(eff,mp.mpf(0)))**3;base=regular+cap;normalized=base/cubic
  if c.get('rho_zero'):normalized=mp.mpf(0);actual=mp.mpf(0);regular=mp.mpf(0);cap=mp.mpf(0);countregular=mp.mpf(0);countcap=mp.mpf(0);countnormalized=mp.mpf(0);countactual=mp.mpf(0);blocks=[]
  else:actual=base*mp.exp(min(eff,mp.mpf(0)));countactual=countbase*mp.exp(min(eff,mp.mpf(0)))
  assert normalized<34 and countnormalized<11
  discrepancy=None;countdiscrepancy=None
  if brute:
   check=mp.mpf(0);countcheck=mp.mpf(0)
   for j in range(Jmax+1):
    first=2*j;kk=0
    while (first+kk)*h<X:
     clock=kk*h-U
     if clock>0:
      weight=min(1,mp.exp(Tw-(first+kk)*h));check+=weight*clock;countcheck+=weight
     kk+=1
    clock=X-first*h-U
    if clock>0:
     weight=min(1,mp.exp(Tw-X));check+=weight*clock;countcheck+=weight
   if c.get('rho_zero'):check=mp.mpf(0);countcheck=mp.mpf(0)
   discrepancy=abs(check/cubic-normalized)
   countdiscrepancy=abs(countcheck/quadratic-countnormalized)
   assert discrepancy<mp.mpf('1e-30') and countdiscrepancy<mp.mpf('1e-30')
  return {'count_C_over_A':mp.nstr(countactual,32),'count_regular_div_min_one_r':mp.nstr(countregular,32),'count_cap_div_min_one_r':mp.nstr(countcap,32),'count_C_over_proposed_quadratic_denominator':mp.nstr(countnormalized,32),'count_margin_to_11':mp.nstr(11-countnormalized,32),'brute_original_count_normalized_discrepancy':mp.nstr(countdiscrepancy,16) if countdiscrepancy is not None else None,'b':mp.nstr(b,32),'h':mp.nstr(h,32),'X_n_log_b':mp.nstr(X,32),'log_rho_over_A':mp.nstr(T,32),'U':mp.nstr(U,32),'log_effective_r':mp.nstr(eff,32),'j_count':Jmax+1,'regular_global_index_count':regular_count,'active_regular_j_node_pairs':active_nodes,'active_caps':capcount,'actual_empty_clock_window':X<=U,'rho_zero_branch':bool(c.get('rho_zero')),'zero_branch_ratio_convention':'For rho=0 the sum and bound are exactly zero; reported normalized value zero is a branch convention, not a 0/0 quotient.','blocks':blocks,'regular_sum_div_min_one_effective_r':mp.nstr(regular,32),'cap_sum_div_min_one_effective_r':mp.nstr(cap,32),'S_over_A':mp.nstr(actual,32),'S_over_proposed_denominator':mp.nstr(normalized,32),'margin_to_34':mp.nstr(34-normalized,32),'brute_original_double_sum_normalized_discrepancy':mp.nstr(discrepancy,16) if discrepancy is not None else None}

def main(output):
 rows=[];maxdiff=mp.mpf(0);maxcountdiff=mp.mpf(0)
 for c in menu():
  a=evaluate(c,40,c['n']<=64);b=evaluate(c,70)
  with mp.workdps(70):diff=abs(mp.mpf(a['S_over_proposed_denominator'])-mp.mpf(b['S_over_proposed_denominator']));maxdiff=max(maxdiff,diff);countdiff=abs(mp.mpf(a['count_C_over_proposed_quadratic_denominator'])-mp.mpf(b['count_C_over_proposed_quadratic_denominator']));maxcountdiff=max(maxcountdiff,countdiff)
  assert (a['j_count'],a['regular_global_index_count'],a['active_caps'])==(b['j_count'],b['regular_global_index_count'],b['active_caps'])
  rows.append({'configuration':c,'at_40dps':a,'at_70dps':b,'normalized_precision_difference':mp.nstr(diff,16),'count_normalized_precision_difference':mp.nstr(countdiff,16)})
 top=max(rows,key=lambda x:mp.mpf(x['at_70dps']['S_over_proposed_denominator']))
 counttop=max(rows,key=lambda x:mp.mpf(x['at_70dps']['count_C_over_proposed_quadratic_denominator']))
 result={'count_bound':'C=sum min(1,exp(T-l)) 1_{x>U} <=11 min(1,exp(T-U))(1+max(T-U,0))^2.','survivor_scope':'Auditor-approved analytical early/late survivor refinement motivates count summation; no new dynamic/history simulation or FULL certification performed.','schema':'R231_joint_local_cap_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'contract_sha256':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'exact_checks':exact_checks(),'tested_bound':'S <= 34 A min(1,r) (1+log_+r)^3, r=rho exp(-U)/A','normalization':'A=1 by homogeneity; input T=log(rho/A), no overflow via effective-r cancellation.','case_count':len(rows),'summary':{'maximum_normalized_ratio':top['at_70dps']['S_over_proposed_denominator'],'maximum_configuration':top['configuration'],'maximum_40_70dps_difference':mp.nstr(maxdiff,16),'count_maximum_normalized_ratio':counttop['at_70dps']['count_C_over_proposed_quadratic_denominator'],'count_maximum_configuration':counttop['configuration'],'count_maximum_40_70dps_difference':mp.nstr(maxcountdiff,16),'empty_clock_cases':sum(a['at_70dps']['actual_empty_clock_window'] for a in rows)},'results':rows,'scope':['Actual two-index j/node grid and every node clock preserved, with unique physical b cap per j.','Finite geometric block formulas avoid large double loops; small dimensions independently use the original double sum.','No constant or dimension-order proof inferred from these finite samples.','Exact discrete cubic identity is algebraic evidence for the proposed degree, not a fitted asymptotic.','mpmath arithmetic is ordinary high precision, not an outward interval certificate.','No original source-budget, histories, low-deficit complement, or FULL closure claim.']}
 output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['summary']))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'local_cap_checks.json');main(ap.parse_args().output)
