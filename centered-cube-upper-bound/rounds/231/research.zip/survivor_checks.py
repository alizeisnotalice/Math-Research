#!/usr/bin/env python3
"""Finite original-shaped weight/deletion checks; not FULL geometry."""
import argparse,hashlib,json
from pathlib import Path
import mpmath as mp
ROOT=Path(__file__).resolve().parent

def evaluate(n,skew,dps):
 with mp.workdps(dps):
  thresholds=[1-mp.mpf(1)/n,1-mp.mpf(1)/(2*n),mp.mpf(0),mp.mpf(0)]
  deaths=[mp.mpf(2),mp.mpf(2),mp.mpf('0.3'),mp.mpf('0.7')]
  masses=list(map(mp.mpf,('1','1','10','100') if not skew else ('0.0001','10','100000','0.001')))
  breaks=sorted(set([mp.mpf(0),mp.mpf(1)]+thresholds+deaths[2:]))
  def vals(t):
   ws=[mp.exp(-n*max(mp.mpf(0),t-th)) for th in thresholds]
   ks=[n if t>th else 0 for th in thresholds]
   active=[m*w if t<death else mp.mpf(0) for m,w,death in zip(masses,ws,deaths)]
   et=sum(active);pi=[w/et for w in active];hs=sum(active[:2])
   actual=sum(pi[i]*ks[i] for i in (0,1))
   comparison=sum(active[i]*ks[i] for i in (0,1))/hs
   pair=sum(pi[i]*pi[j]*max(0,ks[i]-ks[j]) for i in (0,1) for j in range(4))
   assert 0<=pair<=actual+mp.mpf('1e-35') and et>=hs>0
   return pair,actual,comparison
  integrals=[mp.fsum(mp.quad(lambda t: vals(t)[k],[lo,hi]) for lo,hi in zip(breaks,breaks[1:])) for k in range(3)]
  endpoint=mp.log((masses[0]+masses[1])/(masses[0]*mp.exp(-1)+masses[1]*mp.exp(-mp.mpf('.5'))))
  assert abs(integrals[2]-endpoint)<mp.mpf('1e-35')
  assert 0<=integrals[0]<=integrals[1]+mp.mpf('1e-35')<=endpoint+mp.mpf('1e-34') and endpoint<=1
  return {'n':n,'skew':skew,'precision':dps,'pair_integral':mp.nstr(integrals[0],30),'survivor_score_integral':mp.nstr(integrals[1],30),'normalized_survivor_score_integral':mp.nstr(integrals[2],30),'exact_endpoint_log_evaluated':mp.nstr(endpoint,30),'deficit_cap':'1','endpoint_difference':mp.nstr(abs(integrals[2]-endpoint),8)}

def main(out):
 rows=[]
 for n in (2,16,512):
  for skew in (False,True):
   lo=evaluate(n,skew,40);hi=evaluate(n,skew,70)
   for key in ('pair_integral','survivor_score_integral','normalized_survivor_score_integral','exact_endpoint_log_evaluated'):assert lo[key]==hi[key]
   rows.append({'at_40dps':lo,'at_70dps':hi,'30_digit_agreement':True})
 data={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'case_count':len(rows),'rows':rows,'scope':'Six finite nested-deletion models with weights product min(1,exp(theta-t)) and integer scores. Ordinary high-precision quadrature with exact breakpoints; not interval certification, original FULL input, or global source-tail budget. Analytic log-partition identity is proved separately.'}
 out.write_text(json.dumps(data,indent=2)+'\n');print('survivor models passed:',len(rows))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'survivor_checks.json');main(ap.parse_args().output)
