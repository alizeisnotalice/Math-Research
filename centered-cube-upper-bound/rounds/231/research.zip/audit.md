# R231 independent audit

## Statement-first screening (before R231 author proofs)

Read `task_contract.md`, the frozen R230 results, R222 SOCC11, and the narrow original clauses R128 RT2/RT4/650–658, R223 JB1 and R221 SL1. The following screening was completed before reading the new author proofs. Only this audit is edited.

### Persistent-survivor lemma and actual terminal-good qualification

For fixed \(y,j,g\), let \(S\subset Z_g\) persist on \([\tau,g]\). Define \(H_S(t)=\int_S w_t\,d\nu\). For \(0<\nu(S)<\infty\) and \(w_g\ge e^{-D}\) on S, this function is positive and absolutely continuous, with
\[
 -\partial_{\log t}H_S(t)=\int_S k_t w_t\,d\nu,
 \qquad e_t\ge H_S(t).
\]
Consequently
\[
 \int_\tau^g\int_S k_t\,d\Pi_t\,d\log t
 \le\log\frac{H_S(\tau)}{H_S(g)}\le D.
\]
The last step uses \(w_\tau\le1\); zero S-mass gives zero traffic. There is no derivative of the deleting normalizer \(e_t\), and no deletion credit. Since \((k_v-k_u)_+\le k_v\) and the other original posterior has mass at most one, the positive pair traffic with v restricted to S satisfies the same bound. Restriction to original valid clock times only decreases it.

This applies rowwise to an actual terminal-good low-deficit slice. The frozen R223 JB1 explicitly gives \(G=S_g\subset Z_g\), persistent on the original far interval; R128 fixes \(Z,w,e,\Pi\) independently of receiver x at fixed \((j,y,t)\). However good's original inequality \(pw_g\le KQ^*\) is an **upper** bound on \(w_g\), not the required lower bound. The full good set has no automatic finite uniform D. Its terminal choice and its low-deficit slice depend on x; those cannot be extracted from a receiver integral without a common dominating survivor set.

A local 50-digit tool check with two product-weight dimensions n=2,16, two persistent sources and one deleting source verified the expected inequalities (positive pair traffic ≤ persistent-score traffic ≤ log mass ratio ≤ D). These are finite clock diagnostics, not original spatial/history models; the general proof is the displayed potential argument.

### Low-deficit local-cap/QG interpolation

On the actual low-deficit branch \(w_{g(x)}(y,v)\ge e^{-D}\), R229 gives \(g^*/g\le\gamma^2\), so
\[
 w_{cg^*}(y,v)\ge\gamma^{-2n}w_{cg}(y,v)\ge\gamma^{-2n}e^{-D}.
\]
This node cutoff depends on fixed \((j,M,y,v)\), not x, t or the menu soft parameter. It must be retained when covering the actual receiver fibers. Let \(\Omega\) be the **original** allowed receiver domain. R221 SL1 grants \(h_B*\nu\le C_0q\) on \(\Omega\) for every legal \(B\in[a,b]\), \(C_0=16/3\). Therefore the hard-source/receiver column with its node cutoff is at most
\[
 qA,\qquad A=C_0\gamma^n e^{D/2},
\]
by first using that cap at \(R^*\), then \(\int\sqrt{P_1P_2}\le1\) for the two normalized densities. The alternative fixed-node QG bound gives \(\|\nu\|M^{-n}\). Taking their minimum is valid; it is not multiplication of two hard-cap credits. Dropping \(\Omega\) before the local-cap estimate would invalidate that estimate.

After the column is bounded uniformly in auxiliary sources, the same actual \(\Pi_t\otimes\Pi_t\) can use n/4. No source is conditionally renormalized. Put \(\rho=\|\nu\|/(qa^n)\), \(h=n\log\gamma\in[\log2,1]\), \(x=n\log(M/M_0)\), and \(s=x-U\). The remaining dimensionless node sum has terms
\[
 \min(A,\rho e^{-(2jh+x)})(x-U)_+.
\]
Its source data must be common over j, as established for the present original rows in R230. Extending numerical grid sums outside the physical node range only enlarges nonnegative algebraic sums; it does not instantiate an ineligible kernel node.

### Independent all-j counting proof

Set \(r=\rho e^{-U}/A\), \(L=\log_+r\), with the final shape defined as zero at r=0. For regular nodes \(s=s_0+kh\ge0\),
\[
 F(H):=\sum_{2jh+s\le H}s
 \le H(1+H)(1+2H)\le2(1+H)^3,
\]
because \(h\ge\log2>1/2\). Layer-cake integration against \(\min(1,re^{-t})\) now bounds the regular sum by
\[
 32A\min(1,r)(1+L)^3,
 \qquad 2\int_0^\infty e^{-v}(1+v)^3\,dv=32.
\]
For the at-most-one capped point per j, put \(T=n\log(b/a)\), \(H=T-U\). If H≤0, it contributes zero. Otherwise its weighted count is at most \(H(1+H)\le(1+H)^2\), all with the same factor \(\min(1,re^{-H})\). Using \(\sup_{v\ge0}(1+v)^2e^{-v}=4/e<2\) gives at most \(2A\min(1,r)(1+L)^2\). Thus the proposed total constant 34 is valid. The original three-leg/orientation/menu/Gini factor is \(6e^4N_n\), hence the cubic coefficient is 204 with the exterior \(2\Lambda\sqrt{K/3}\). The actual D-complement, \(e^{D/2}\), \(\sqrt K\) and any shallow complement remain unpaid.

### Verified survivor bridge and the quadratic refinement

The actual good-set qualification is sufficient for the proposed node survivor bridge. Let \(g_-=g^*/\gamma^2\le g(x)\) on a node fiber. If \(g_-\ge\tau=a/c\), define the **common dominating** set
\[
 S_*:=Z_{g_-}\cap\{w_{g_-}\ge e^{-D}\}.
\]
Every original terminal-good low-deficit point in that fiber lies in \(S_*\), by nested deletion and monotone weights. This does not recompute an original good gate; it is a positive enlargement. On the early node clock \(t\le g_-\), the survivor lemma gives D. The late slice \((g_-,g^*]\) has log length at most \(2\log\gamma\), so the same original posterior's n/4 bound gives at most \(1/2\). If \(g_-<\tau\), the entire node clock lies in such a short slice; directly use \(1/2\), without evaluating the process before its initial time. Original inactive masks remain zero throughout.

Hence the correctly qualified node time price is bounded by both \(n\ell_M/4\) and \(D+1/2\). In using this after a uniform column bound, retain \(\Omega\) and the node deficit cutoff until that bound is established, and retain the common \(S_*\) on the early slice. No x-dependent survivor set is moved unchanged through the receiver integral.

The unweighted regular count satisfies \(F_0(H)\le(1+H)(1+2H)\le2(1+H)^2\); its layer-cake price is at most \(10A\min(1,r)(1+L)^2\). The capped-node count is at most \(1+H\) and its price at most \(A\min(1,r)(1+L)\). Therefore the quadratic node sum has constant 11. With the direct factor \(24e^4N_n\) (the time bound already includes n/4), its coefficient is \(264(D+1/2)\). It can be used alongside the cubic bound as two upper bounds on the same positive traffic, taking their minimum rather than adding a new credit.

**Initial verified conclusion.** Both the cubic local-cap interpolation and the actual-terminal survivor refinement are legally available on the original low-deficit branch under the stated common-source conditions. Neither applies to the entire good set without that deficit restriction. Signed negative terms retain their original gates and ownership; no reverse traffic is manufactured from the positive potential estimate. The remaining deficit/source layers, K accounting and other unpaid branches prevent a global root conclusion. Proceed to author review, without a new source-density assumption or a full historical re-audit.

## Author and implementation review

Read all of the final refined `local_density_geometry.md`, including LD1/LD1c, LD3–10 and LD12–15. **Pass for the actual low-deficit cubic/quadratic bounds.** It correctly retains the actual receiver domain for the all-scale hard cap, the node cutoff for the inverse geometric weight, and the common persistent node set for the early clock. It then applies a uniform column bound before any posterior normalization. The two column bounds are alternatives on the same positive integral, and the cubic and quadratic total prices can be minimized leaf by leaf. It explicitly retains common-source-over-j qualifications and does not conditionally renormalize either posterior.

The final LD11 example has fixed \(B\ge0\), fixed K and D, and pays only the specified actual source/deficit subfamily. The \(e^{D/2}(D+1/2)\) cost remains explicit. U=0 covers the effective clock of this original far branch; it does not silently include near or other terminal complements. The high-deficit complement, general weighted logarithmic source moment and remaining K accounting are not paid.

Read the full `cap_column_interpolation.md`. CI3 is the direct positive receiver split, CI5–6 are the correct two/four product formulas, and CI9–10 are the exact clipping and layer-cake bounds. The hard integration variable cannot choose its own B or clipping level. The original capture classes and the real boundary-source portions are retained. The small one-dimensional strict-improvement example satisfies its stated local cap and has the claimed exact values; it is not an original FULL model. I requested the explicit exact-min qualification for CI7/8 rather than an arbitrary-w QG assertion; that repair is present. The original double-posterior return in CI11 retains all cut-dependent source weights and does not claim a free Gini normalization when its bracket still depends on auxiliary slots.

I also requested a measurability qualification for CI8's erosion-tail set when starting from arbitrary measurable B and an arbitrary finite source measure: rectangular B is sufficient, or the erosion must be known source-measurable. This does not affect the general positive split CI3 or the main low-deficit theorem. The final binding below will incorporate the scope repair.

Independently extracted and executed the CI companion's complete embedded Fraction script: **321 assertions passed**, including the exact values \(19/200,1/10,1/2,11/20\). These finite discrete/product checks support implementation and set algebra, not FULL/source-tail affordability.

Statically reviewed `local_cap_checks.py`, its full raw JSON and `numeric_notes.md`, then independently ran the complete final script at an external output path. All **210 configurations** passed; the full JSON was byte-identical to the archived file. The parity-block algorithm uses the correct finite geometric moments and preserves each j/node clock and unique cap. Small dimensions independently compare the original double sum; source-zero and empty-clock branches are explicit. The final extension computes the quadratic count without replacing the earlier cubic sum. Its output records **87 empty windows** and the finite saturated identities; ordinary 40/70-digit agreement is distinguished from a rigorous interval certificate.

Statically reviewed and independently ran the entire new `survivor_checks.py`: all **six finite nested-deletion models** passed, and its complete JSON was byte-identical to the archive. The model weights are n identical threshold factors in logarithmic time, with two persistent selected sources and two other sources deleting outside the persistent set. Splitting at every threshold and deletion makes the numerical log-potential comparison well-defined. The models verify only the stated normalized-clock identity at ordinary high precision; the original geometric survival qualification is established analytically from the frozen definitions, not inferred from these models. My earlier two auxiliary clock diagnostics were separate from these six archived cases.

Read the parent main proof in full and checked its refined equation (6): coefficients 204 and 264, physical units, same-column minimum, positive truncation limits and original far/deficit scope are consistent with the independent derivations. The explicit valid-time/zero-extension clarification before (2) is correct; the physical-t derivative there matches the dt/t score integral. No original signed negative item, deleting-normalizer derivative, extra hard cap, or node FIRST budget is used. Await only final scope/hash freeze.

## Final integration verdict — 2026-10-17, frozen

The requested CI8 measurability qualification is now present: its erosion-tail integral is restricted to rectangular B or another B whose erosion is known \(\nu\)-measurable; CI3's general measurable positive split remains unchanged. The explicit CI7 exact-min restriction, fixed \(B\ge0\) in the polynomial-congestion example, and U=0's restriction to the original far branch are all present in the final files. No new computation was required for these domain clarifications.

Read the final report and statically checked `reproduce.py`. The report stays within the main theorem: it identifies a genuinely paid bounded-deficit/polynomial-congestion source subfamily, with fixed K and the stated constants, but preserves the high-deficit complement, source logarithmic moment, K accounting and other original branches. Its proposed next joint-tail step is expressly unproved. The driver copies the contract and both scripts to a fresh external directory, runs each complete computation, compares each entire JSON byte-for-byte and verifies manifest hashes before and after. It inherits the documented local math environment. The parent's final frozen-package replay and external receipt occur after this audit; they are not pre-claimed here.

**Final verdict: pass for the R231 bounded results; no outstanding requested correction.** The original low-terminal-deficit branch now has a valid quadratic-logarithmic congestion price through a fixed persistent-source set, rather than a free substitution of x-dependent good sets. The local split/capture/clipping companion has the precise kernel and measurability qualifications. Both archived numerical computations were independently executed and reproduced in full; the CI embedded 321-check script was also independently run. No general arbitrary-positive-\(L^1\) root endpoint conclusion follows, and no negative or hard-cap credit is duplicated. Audit writing stops here.

Final reviewed SHA256 bindings (excluding this audit itself):

| File | SHA256 |
|---|---|
| task_contract.md | `1836917e20217d6662502fb67a93feee51f4920e8d999f56c49ae19c0980a5a6` |
| proof.tex.txt | `da568ecefff16f2eeaf665afb83871d13930b42433f14aed76c2af01a4108350` |
| report.md | `e5a5f8efb0861599b3a56e275c4923603c3984157f392cf95678e3b43a285b17` |
| reproduce.py | `00898d0ad81cf84c47d0a3212958a0218b8a304df18749560c421cd2a025f968` |
| local_density_geometry.md | `454afadab6707db9817542ca4dfb8b3f8cfc0a64c8b5d6e969c071f152d2ac3e` |
| cap_column_interpolation.md | `833fad312f95692fcb2fefae183ee5284c19f55ab9bf9c43bac559ce1382e3c8` |
| local_cap_checks.py | `55d80cfa8051e6ac3e20da4c173c25931075eefce4b124034cb46d1e761bbc0b` |
| local_cap_checks.json | `72ad0f68db4a01a71edc07791f0336990927a6f9e49a458f82a6d4cb374e5970` |
| numeric_notes.md | `3187c6a77bd2b3139f65d3c7b2df0cddf292dfdfdd028e5d92b9d28ebc0c46ac` |
| survivor_checks.py | `ac2feb514b45e04fe8f3a571ac0e8f19f15b50cdb9d6aa9b00c695efc9fd1f69` |
| survivor_checks.json | `10786827b23b38d6bdb496f5e3607614d4b5ef18bc02975f37cadb9a326756e3` |
