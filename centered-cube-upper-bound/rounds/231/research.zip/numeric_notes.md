# R231 运行前方案

按合同a=1、b∈[1,2]、gamma=1+1/n、h=nloggamma。j满足2jh≤X=nlog b，节点M=M0 gamma^k（M0=gamma^(2j)），regular节点严格小于b，末尾b恰一次。原量S/A=sum min(1,exp(T−l))(x−U)+，T=log(rho/A)，l=2jh+x。父级新解析候选为34 min(1,exp(T−U))(1+(T−U)+)^3；本任务检该归一比，保rho0及真空窗，不以原粗T³代替U依赖。

分块算法：所有regular节点全局指数m=2j+k，按m奇偶分块。对每parity令K为最小同奇偶正clock整数（Kh>U），该m的j-clock总和为N(Kh−U)+hN(N−1)，N=(m−K)/2+1，是m的二次多项式。按mh≤T的饱和段与指数段切开，后段用有限sum q^i、i q^i、i² q^i精确公式，不做大n双循环。cap按j的等差clock直接求和。若T<U，直接以Twork=U算归一量，原值乘exp(T−U)，消除极端rho造成下溢。n≤64另用原j/node双循环独立校对，不仅重复同公式。

三阶段固定菜单：initial n2/16/64、b1/1.01/2、若干T/U含rho0；stress u/T在同节点及其两侧、cap恰重合/微窄窗/超窗；expanded n512/4096/1e6、极端T−U与长窗。40/70dps全复核，记录每配置j/node数量、实际空分支、正规与cap分量、34的余量；不通过有限最大值宣称通用常数。用Fraction独立核有限几何矩公式与饱和三次多项式实现。cap转移只核已确认d*/d≤gamma²，不猜更强gamma；构造有理g的真实min/max比例及精确c_j=gamma^-j。只检本引理策略与转移，不认证原source/FULL。

## 当前有限checkpoint实际结果

实际210配置，n2/16/64为初始与边界，n512/4096/1e6为扩大；87个真实空clock窗，rho0另有明确零分支（所报归一比零为分支约定，不把0/0当商）。在n1e6最长窗中j数346574，等效活跃双索引节点数120113537476，使用有限parity多项式几何公式完成，未以全窗最大clock长度替代逐节点值。

所有40/70dps的32有效位归一比输出一致；n≤64用原j/节点双循环独立比较，最大归一差约1.38e−40。最大归一比S/[A min(1,r)(1+log_+r)^3]为1.248526899984607499627006720397，出现在n16,b2,T−4,U.5；expanded最大约1.10305。所有有限测试低于作者解析候选34。该有限最大值不证明更紧常数；没有为优化此菜单常数继续搜索。

15个Fraction有限几何矩公式与直接有理和一致；6个饱和多项式实现恒等式检查一致；38个真实[1,2]参数范围的cap转移有理配置通过，c_j精确gamma^-j、g²=mM，d*/d=t(M*/M)≤gamma²。不作gamma-only转移断言。饱和身份S/h=R(R+1)(4R+5)/6来自离散计数/求和公式，不是拟合；其一般性及三次必要性留作者独审，不扩展全局不可能性论证。

按父级最新指令，保持当前源码/JSON checkpoint，不实施尚未审定的新survivor/score-time改善，也不覆盖当前菜单结果。待有准确审定命题后另行接任务。这里只支持现联合尺度和策略，不认证source预算、终端 survivor 的新引理、history或FULL。

现checkpoint源码全复跑到独立--output临时路径，完整JSON逐字节一致，未覆盖现结果。当前JSON SHA256：224c40b506bf81d9d6d79849516afe3602de4634a1ab9fe39659c12abc4ad45f；源码SHA256：adf4fed3d3a6fecac00481ede0d61f013dcc2657797f0fa081cdc22cc7178344。记录完成，停等。

## 审计通过后的无score计数改进（最终扩展）

父级明确授权后保留旧源码/JSON外部checkpoint，再在同210菜单加入C=sum_{j,node:x>U} min(1,exp(T−l))，核候选C≤11 min(1,r)(1+log_+r)²，r=exp(T−U)。无新几何菜单。regular每个global m的计数是N=(m−K)/2+1，以有限几何0/1阶矩求和；cap取原正clock节点数量capcount乘相同cap权，没有score因子。rho0仍独立为零，真空窗原样保留。

实际最大归一计数比为1.1755181653648452939698128372585，出现在n16,b2,T−4,U.5；所有配置低于11，40/70dps的32有效位输出一致。n≤64原始j/node双循环独立count复核最大差约3.10e−40。6个Fraction饱和计数身份核R0/1/2/8/64/512精确成立：U0、global m≤2R含唯一末cap时，正(j,node)对数为R(R+1)。既有几何矩精确检查也同时覆盖这里的0/1阶矩。

旧有score三次和S的全部配置/40dps/70dps字段已逐项与外部旧checkpoint比较，完全相同；新增count字段不替换或伪造旧结果。此前hash为旧checkpoint，以下新hash为当前扩展交付。

所用survivor解析结论按父级审计通过版本记述：gminus=g*/gamma²≤原g；早期持久来源S=Z_gminus∩{w_gminus≥exp(−D)}，在完整normalizer e_t≥H_S下由−log H_S得积分k Pi_S≤D；晚期窗长≤2loggamma，用真归一Gini≤n/4得额外至多1/2。总实际score-time≤D+1/2使逐节点clock x价格可改由count付费，动机为log²而非继续优化三次菜单常数。本脚本只核count11及有限离散实现，没有新做动态/删除模拟，也不将这些有限检查当一般survivor证明；一般引理归独审负责。

有限最大值1.1755不证明通用11，更不认证原source budget、历史/FULL或低deficit补支。解析与数值证据保持分开。本次必要扩展完成后停止。

count扩展后的最终源码独立--output全JSON复跑逐字节一致。当前最终JSON SHA256：72ad0f68db4a01a71edc07791f0336990927a6f9e49a458f82a6d4cb374e5970；当前最终源码SHA256：55d80cfa8051e6ac3e20da4c173c25931075eefce4b124034cb46d1e761bbc0b。无runtime/输出路径字段；完成并停止。
