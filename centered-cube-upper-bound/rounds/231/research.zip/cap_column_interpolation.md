# R231：局部 cap 与截断列的来源尾插值

**范围。** 本稿给一条全参数的正核截断定理：选定一个不依 hard 积分变量的 receiver 区域，在其内部用原局部质量帽；在其外部保留同一个 hard 来源的精确剩余列。矩形截断和原已认证 capture 窗口下，两部分均有显式一维积分乘积公式。hard 窗口完全落在截断区域的来源从剩余列中消失，其他来源保留真实边界比例。因此结果比对两个整列上界取最小值更精细。它没有证明存在能免费结算全部来源尾的截断选择，亦未证明一般根阶付款。

## CI1 实际 receiver、核与允许的量词

读本轮 `task_contract.md`、R230 [source_budget.md SB5](/Users/zhengzhihao/Desktop/T/output/centered_cube_round230_20261017_final_checkpoint/source_budget.md:117)、R229 [adaptive_geometry.md AG1–7](/Users/zhengzhihao/Desktop/T/output/centered_cube_round229_20261016_final_checkpoint/adaptive_geometry.md:1) 及 R222 [source_occupancy.md SOCC1–11](/Users/zhengzhihao/Desktop/T/output/centered_cube_round222_20261016_final_checkpoint/source_occupancy.md:1)。本稿不重复本轮主低 terminal-deficit 的 logarithmic 来源价。

令 `ν` 是有限正来源测度，`q>0`，`0<a≤b≤2a`。实际 receiver 集 `Ω` 上保原完整 hardband，故

\[
 H_B(x):=\int h_B(x-z)\nu(dz)\le C_0q,
 \quad x\in\Omega,\quad a\le B\le b,
 \qquad h_B=B^{-n}1_{[-B/2,B/2]^n}. \tag{CI1}
\]

原应用 `C_0=16/3`。帽只在这些 receiver 中心成立；不授予新的锚点或 Ω 外的 hardband。以下所有积分允许以 a.e. 版本理解。

一维 `h=1_{[-1/2,1/2]}`、`φ=h*∫_0^1 e^{-|·|/r}dr`、`f_s=(1-s)h+sφ`。固定物理节点 `L,R,A∈[a,b]`、`A≥L` 及独立 `r,σ∈[0,1]`，令

\[
 j_i(\xi)=\sqrt{L^{-1}f_r((\xi-y_i)/L)\,
                         A^{-1}f_\sigma((\xi-v_i)/A)},\quad
 J(x;y,v)=\frac{\prod_i j_i(x_i)}{\sqrt{w}}, \tag{CI2}
\]

其中 `w>0` 是该固定节点的原几何权。R229 节点中 `w=\bar w_{c^2M}(y,v)`、`M=max(L,R)`；原三腿恰为 `(A,σ)=(L,r),(min(b,γL),r),(b,1)`。本定理本身只需 `J` 非负可积，不假设完整 affinity `∫J≤1`。普通 Cauchy 只给 `∫J≤w^{-1/2}`。

令 `𝒞` 为固定的已认证 capture 排除盒，或无排除时的空集，`G=ℝ^n\𝒞`、`J_G=1_GJ`。原门可继续乘在 `J_G h_R` 上；上放这些 `[0,1]` 门只使下文右侧增大。不得在节点重算 capture。

## CI2 正确的截断列定理

**定理。** 对任何可测 receiver 截断集 `B`，定义

\[
 T=\int_\Omega J_G(x)H_R(x)dx,\quad
 F_{\Omega,B}=\int_{\Omega\cap B}J_G(x)dx,\quad
 C_{\Omega,B}(z)=\int_{\Omega\setminus B}h_R(x-z)J_G(x)dx.
\]

则

\[
 \boxed{T\le C_0q F_{\Omega,B}
                  +\int C_{\Omega,B}(z)\nu(dz).} \tag{CI3}
\]

`B` 可以依 `ω,V,j`、物理/soft 节点、`y,v,u,t` 和整份冻结 `ν` 可测地选择，但必须在当前 `ν(dz)` 积分之前固定，不能依该 hard 积分变量 `z` 逐点选择。若依 z，第一项的 hard 来源积分不再是同一个 `H_R(x)`，CI1 不能这样使用。

**证明。** 将 `Ω` 分成 `Ω∩B` 与 `Ω\B`。前者逐点使用 CI1；后者仅用非负 Tonelli。这没有增加 receiver 域，也没有交换来源。一般非负版本由有限截断的单调极限成立。证毕。

记无 Ω 的显式外列与盒 cap 价为

\[
 C_B(z)=\int_{G\setminus B}h_R(x-z)J(x)dx,\qquad
 F_B=\int_{G\cap B}J(x)dx.
\]

因此 `F_{Ω,B}≤F_B`、`C_{Ω,B}≤C_B`。前者还可保真正的 receiver 大小：若 `J≤J_∞`，则

\[
 F_{\Omega,B}\le\min\{F_B,\ J_\infty|\Omega\cap B\cap G|\},\qquad
 J_\infty=\frac{f_r(0)^{n/2}f_\sigma(0)^{n/2}}
 {(LA)^{n/2}\sqrt w}. \tag{CI4}
\]

CI3 中两项是同一原量的互斥 receiver 分配，不能让两支各再领取整份 hard cap。`B=∅` 恢复原列路线，`B=ℝ^n` 恢复一次全 hard cap；中间 B 真正移除了相应来源列，未仅对两个完整数值取最小。

## CI3 三腿共同的 capture/截断乘积公式

令 `B=∏_i B_i` 为任意矩形（允许无界区间），`𝒞=∏_i C_i` 为已认证 capture 盒。定义

\[
 H_i(E)=\int_E j_i(\xi)d\xi,\qquad
 I_i(z;E)=\int_{[z_i-R/2,z_i+R/2]\cap E}j_i(\xi)d\xi.
\]

无 capture 时，下式所有含 C 的乘积直接定义为零；不是额外排除某个 `Q_0`。包含 capture 时，非负精确公式为

\[
 F_B=\frac{\prod_iH_i(B_i)-\prod_iH_i(B_i\cap C_i)}{\sqrt w}, \tag{CI5}
\]

\[
 \boxed{C_B(z)=\frac1{R^n\sqrt w}\left[
 \prod_iI_i(z;\mathbb R)-\prod_iI_i(z;C_i)
 -\prod_iI_i(z;B_i)+\prod_iI_i(z;B_i\cap C_i)\right].} \tag{CI6}
\]

公式来自 `1_{G\setminus B}=1-1_𝒞-1_B+1_{B∩𝒞}` 与乘积 Fubini。它是正集合积分，尽管展开式有负号，结果仍非负；不能分别给四项领取 cap 或来源价。

全部一维积分仅含实际 `f_r,f_σ`，没有未知 receiver 积分；CI5–6 同时适用三腿，第三腿只把 `A=b,σ=1` 代入。若某个因子或整列为零，按原非负积分取零，不除以该因子。

R229 原节点的 capture 继承准确为：实际 `R≤L` 朝向可取排除边长 `d_-=max(a,R^*/γ^3)`；实际 `R>L` 且原未触发下截断 `H_0≥a` 时可取 `d_+=a`；其余 `R>L` 支无排除。下截断不授完整 `Q_a` 排除。可对这几类互斥原支分别应用 CI3–6，不把上支支持给下支。

设 `B_G(z)=∫_G h_R(x-z)J(x)dx`。从此处起，凡调用 QG 的 CI7、CI8 及后续 QG 替换，均限定于 R229 的 exact-min 节点权 `w=\bar w_{min(L,R)}(y,v)` 与上述实际原三腿、已认证 capture 支持；一般任意 `w>0` 仅享有前述正核截断定理，不享有该 QG 上界。在此限定下，固定节点的 QG 给

\[
 0\le C_B(z)\le B_G(z)\le M^{-n}E(y,v)\Phi(y,z,v). \tag{CI7}
\]

`Φ` 仍是原同一来源的 capture 乘积差比例，无 capture 取1；若其比例分母为零，整列为零，取 `Φ=0` 即可。本稿不把不同 z 的 capture 比例互换。

## CI4 真实 source marginal：侵蚀内部不再收费

本节含侵蚀集的来源尾积分仅用于矩形 B，或已另行知道 `B⊖Q_R` 对 ν 可测的 B；CI3 的一般可测 B 定理不受此限制。定义 `B⊖Q_R={z:Q_R(z)⊂B}`。在该可测资格下，CI6 直接给

\[
 C_B(z)=0\quad(z\in B\ominus Q_R),
\]

因此 CI3–7 推出可直接使用的来源尾价

\[
 \boxed{T\le C_0q F_{\Omega,B}
 +M^{-n}\int_{(B\ominus Q_R)^c}
           E(y,v)\Phi(y,z,v)\nu(dz).} \tag{CI8}
\]

CI6 比 CI8 更强：边界 crossing 来源保留真实未覆盖比例，而非统统收一份整列。若 B 为中心 `x_0`、各边长 `S_i≥R` 的盒，侵蚀恰是同中心各边长 `S_i-R` 的盒；任一 `S_i<R` 时该侵蚀为空。边界用闭盒时按 `Q_R(z)⊂B` 的定义处理，Lebesgue receiver 零边界不改变列值。

这没有在 `x_0` 或 source 中心 z 使用 hardband。唯一的 cap 仍在原 Ω 内，因而即使 B 的中心不属于 Ω、或 source 在 Ω 外，CI3/8 依然合法。反之，若把 `F_{Ω,B}` 上放为 `F_B`，须付该全盒 affinity；不能因盒中心任意而假定 `H_R≤C_0q` 于盒的全部点。

## CI5 软 clipping 与层蛋糕形式

另有一个不要求 B 为盒的显式插值。对 `λ≥0`，先固定 `λ` 于 hard z 积分之外，令

\[
 B_G^\lambda(z)=\int_\Omega h_R(x-z)\min\{J_G(x),\lambda\}dx,
 \quad O_G(z)=R^{-n}|\Omega\cap G\cap Q_R(z)|\le1.
\]

由 `J_G=(J_G-λ)_++min(J_G,λ)`，得到

\[
 \boxed{T\le C_0q\int_\Omega(J_G-\lambda)_+dx
 +\int\min\{B_G(z),\lambda O_G(z)\}\nu(dz).} \tag{CI9}
\]

证明：高部分逐点 cap；低部分 Tonelli，且 `B_G^λ≤B_G` 及 `B_G^λ≤λO_G`。若使用纯 QG 数据，可将 `B_G(z)` 换成 CI7 的上界；这会削弱界，不能反向换。用 `O_G≤1` 又给截顶列 marginal `∫min{M^{-n}EΦ,λ}dν`。该 marginal 是已知固定核/来源权的截顶，不是给原 ν 新的点态密度帽。

层蛋糕精确写为

\[
 \int_\Omega(J_G-\lambda)_+dx
 =\int_\lambda^\infty|\Omega\cap\{J_G>r\}|dr,\quad
 B_G^\lambda(z)=R^{-n}\int_0^\lambda
  |\Omega\cap Q_R(z)\cap\{J_G>r\}|dr. \tag{CI10}
\]

故这里确实按 receiver 高度截列，保相同 source 的占用；没有使用 `ΣsupΠ=1` 或 source–receiver 免费交换。`λ=0` 与 `λ↑∞` 分别恢复全 cap 与全列路线。对任意可测有限/可数候选截断可以在这些已证正价中取最小；若取不可数 inf 并实际选择，另需相应可测性，不能省略。

## CI6 回代原三腿交通的费用

固定 `(ω,V,j,y,t)` 后，原 `Π_{y,t}`、score `δ` 不依 x。对每个 R229 物理节点、soft 菜单节点、朝向和腿，选择上述 source-independent B（或 λ），把 CI3 右侧除以原 q。对整个 `𝒫_U` 只使用该整支已认证的 G；若要使用 `H_0≥a` 的额外排除，则下式的 `𝒫_U` 先限制到该真实子交通，其他 capture 类须按原互斥分解另计，不能免费删去。得到合法上界

\[
 \begin{split}
 \mathcal P_U\le{}&2\Lambda\sqrt{K/3}\,4e^4\,
 \mathbb E\sum_{V,j}\sum_{\varepsilon,M,r,i}
 \int\beta_V(dy)\int_{I_M(U)}\frac{dt}{t}
 \iint\delta_{y,t}(v,u)\Pi_{y,t}(dv)\Pi_{y,t}(du)\\
 &\qquad\times\left[C_0F_{\Omega,B}
                 +q^{-1}\int C_{\Omega,B}(z)\nu_V(dz)\right].
 \end{split} \tag{CI11}
\]

可把方括号分别用 CI4–10 的显式上界替代。这里 `i=1,2,3`，`r∈S_n` 恰有 `N_n≤8+4√n log(n-1)` 个，`ε` 两朝向；每节点真实 clock 是 R230 的 `I_M(U)=[a/c,cM e^{-U/n}]`，空区间为零。菜单 `4` 与尺度覆盖 `e^4` 只付一次；不得另在三腿外暗乘或漏掉三。Ω 可取原实际 hardband receiver 域，或其保原 fiber/history 后的子域；上放到更大域仍须保 hardband。

若 B 依 v/u/t，则方括号也依这些槽，CI11 必须保持该共同权。不能将 R230 的 `∫δΠ²≤n/4` 直接作用后再提出一个并非统一上界的“平均 source tail”；需要先证明方括号的合法统一帽，或直接估这个加权 pair 积分。同样不能把 hard z 放入 Π，或在此已用 cap 的内部支再用整份 hard cap。原 `ρ_0`/FA/positive complements 只在覆盖允许的方向上放，负项及删除信用均未消费。

## CI7 严格改进的含义、有限检查与停止点

CI3 是接收区域上的分配，CI6 是可计算的列扣除，CI8 真正删去侵蚀内部的来源，而非把未算的原 receiver 积分改名。它可严格小于两个整列旧界。例如仅为核算术检查，取一维 `a=R=1,b=L=A=2,r=σ=0,y=v=0,w=1`，故 `J=1/2` 于 `[-1,1]`；`ν=δ_{-1/2}+(1/10)δ_{1/2}`、`q=C_0=1`、`Ω=[-4/5,-7/10]∪[1/10,1]`、`B=[-1,0]`，无 capture。Ω 上全部 `B_phys∈[1,2]` 的 cap 成立：含双原子的窗须 `B_phys≥1+2|x|≥6/5`，质量仅 `11/10`；单原子质量≤1。原积分为 `19/200`，CI3 保实际 Ω cap 但把外列上放全空间的价为 `1/10`；两个整列旧价分别是 `1/2` 与 `11/20`。该一维核检查不构造原 n≥512 FULL/history，也不是本稿一般结论的替代。

实际运行系统 Python `fractions.Fraction`，40组二维有限乘积核逐项检查非负四项差、CI3、clipping 两个列帽，并精确核对上述严格改进数值，共321项断言全部 PASS。一般 CI3–11 由本文 Tonelli、集合恒等式与已审 QG 证明，不依这些有限样本。

实际运行的完整短脚本如下，不需要第三方库。二维离散核仅检查正核/集合代数，不冒称实际 `φ` 或原局部 hardband 模型；最后一项才是上述真实一维核的精确分数核算。

```python
from fractions import Fraction as F
from itertools import product
checks=0
for seed in range(1,41):
    coord=[[F(1+((seed*(i+2)+j)%7),9) for j in range(5)] for i in range(2)]
    grid=list(product(range(5),repeat=2))
    def J(x): return coord[0][x[0]]*coord[1][x[1]]
    B={x for x in grid if x[0]<=2 and x[1]>=1}
    C={x for x in grid if x[0]>=1 and x[1]<=3}
    Z=[{x for x in grid if x[0]<=3 and x[1]<=2},
       {x for x in grid if x[0]>=2 and x[1]>=1}]
    masses=[F(2,3),F(5,7)]; hr=F(1,12)
    H={x:sum(m*hr for m,S in zip(masses,Z) if x in S) for x in grid}
    Omega={x for x in grid if x[0]+x[1]>=2}
    cap=max(H[x] for x in Omega)
    T=sum(J(x)*H[x] for x in Omega-C)
    capcost=cap*sum(J(x) for x in Omega.intersection(B)-C)
    cols=[]
    for S in Z:
        outside=sum(J(x)*hr for x in S-C-B)
        ie=hr*(sum(J(x) for x in S)-sum(J(x) for x in S&C)
               -sum(J(x) for x in S&B)+sum(J(x) for x in S&C&B))
        assert outside==ie and outside>=0; checks+=2
        cols.append(outside)
    assert T<=capcost+sum(m*c for m,c in zip(masses,cols)); checks+=1
    lam=F(seed%8,9)
    capclip=cap*sum(max(J(x)-lam,0) for x in Omega-C)
    fee=capclip
    for m,S in zip(masses,Z):
        exact=sum(min(J(x),lam)*hr for x in Omega.intersection(S)-C)
        occ=hr*len(Omega.intersection(S)-C)
        full=sum(J(x)*hr for x in S-C)
        assert exact<=min(full,lam*occ); checks+=1
        fee+=m*min(full,lam*occ)
    assert T<=fee; checks+=1
T=F(1,2)*(F(1,10)+F(1,10)*F(9,10))
cap_old=F(1,2)*(F(1,10)+F(9,10))
column_old=F(1,2)*(1+F(1,10))
hybrid=F(1,2)*F(1,10)+F(1,10)*F(1,2)
assert T<=hybrid<min(cap_old,column_old); checks+=1
print({'exact_fraction_assertions':checks,'result':'PASS',
       'strict_interpolation_example':{'actual':str(T),'hybrid':str(hybrid),
       'whole_cap':str(cap_old),'whole_column':str(column_old)}})
```

返回 `exact_fraction_assertions=321,result=PASS`，末项依次为 `19/200,1/10,1/2,11/20`。

**仍未付。** 在全域原交通中，尚无已证选择 B/λ 同时控制 CI11 的 cap 部分和真实 source-tail 部分，并支付全部节点、soft、clock、β 与两Π联合权。若截断以低 terminal deficit 为依据，该 deficit 门与其补域必须继续保留；本稿不从 cut 的可选性推出免费小尾，不把普通 `√(nWX)` 吸收当 root 付款。主线 logarithmic 全质量价与本稿局部列价可以对同一正量取较优合法上界，不能相加领取两次。有限结果止于此处。
