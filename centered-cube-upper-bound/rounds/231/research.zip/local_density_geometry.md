# R231：真实局部密度帽、持久 good 来源与二次对数结算

**主结果。** 在原far门 `t≤g exp(−U/n)` 和真实终端权分支 `−log w_g(y,v)≤D` 上，保原receiver局部密度帽、全部实际L/R/s、原三腿及terminal-good来源的持久存活资格，可将R230的线性来源拥挤费ρ换成显式二次对数费。记

\[
 C_0=16/3,\quad A_D=C_0\gamma^n e^{D/2}\le(16e/3)e^{D/2},\quad
 \rho_V=\frac{\|\nu_V\|}{q_Va_V^n},\quad
 \Psi_p(r)=\min(1,r)(1+\log_+r)^p,\quad\Psi_p(0)=0.
\]

对固定D,U≥0，

\[
 \boxed{P_{D,far}(U)\le
 2\Lambda\sqrt{K/3}\,(264e^4N_n)(D+\tfrac12)A_D\,
 \mathbb E\sum_V\|\beta_V\|
 \Psi_2\!\left(\frac{\rho_Ve^{-U}}{A_D}\right),
 \quad N_n\le8+4\sqrt n\log(n-1).}
 \tag{LD1}
\]

下文先证明不使用持久good资格的立方补充

\[
 P_{D,far}(U)\le
 2\Lambda\sqrt{K/3}\,(204e^4N_n)A_D\,
 \mathbb E\sum_V\|\beta_V\|
 \Psi_3\!\left(\frac{\rho_Ve^{-U}}{A_D}\right).
 \tag{LD1c}
\]

两种估计对每个原叶子分别成立，因此可在每叶取
`min{264(D+1/2)Psi_2(r),204Psi_3(r)}`后求和；不是两个可叠加信用。为保留立方求和的简洁记号，LD4中Ψ指Ψ_3。

对每个原(ω,V)，a、q、β、ν在j之间共同，这是当前R230已审来源合同；无此资格只能保LD10的未合并j式。D、U是固定截取原正项的参数，不在各receiver重新选择。D门不能从good资格推定；这是明确的真实分支。LD1不估 `−log w_g>D` 的互补原交通。

这是一条实际全参数分支的有价估计，不要求特殊soft或尺度族，也不以全局ν质量帽替代原局部帽。其代价包括e^{D/2}、D+1/2及真实来源对数矩，不能据此宣布一般root弱型闭合。LD11给一个明确已付款的来源子支。

## LD2 输入与准确局部帽积分

n≥2，γ=1+1/n，0<a≤L,R≤b≤2a。对当前固定(ω,V)，保真实可测receiver集合Ω，且

\[
 \nu(Q_B(x))\le C_0qB^n
 \quad\hbox{对每个 }x\in\Omega\hbox{ 及每个 }B\in[a,b].
 \tag{LD2}
\]

h_B=B^{-n}1_{Q_B}，所以 `H_Bν(x):=∫h_B(x−z)ν(dz)≤C0q` 于Ω。这是每个真实receiver的全合法尺度帽；没有断言 `||ν||≤Cqa^n`。

固定一个R229节点，令M=max(L*,R*)、m=min(L*,R*)=c_j²M，并记

\[
 f(x)=\sqrt{P_{r,L^*}(x-y)P_{\sigma,A^*}(x-v)},\qquad
 w_* =\bar w_m(y,v),\qquad
 \mathcal I=\int_\Omega\int\nu(dz)\,h_{R^*}(x-z)
 \frac{f(x)}{\sqrt{w_*}}1_{x\notin Q_d(v)}\,dx.
\]

前两原腿σ=r，A*=L*或min(b,γL*)；第三腿σ=1、A*=b。若无已认证排除，最后指示恒为1。R*仍在[a,b]，故LD2**直接适用于向上节点**。准确的两个入口是

\[
 \mathcal I\le
 \min\left\{
 \frac{C_0q}{\sqrt{w_*}}\int_{\Omega\setminus Q_d(v)} f(x)\,dx,
 \ \int\nu(dz)J_{i,\varepsilon,M,r}(y,z,v)
 \right\}.
 \tag{LD3}
\]

第二项J为R230 CG7的真实共同hard窗口积分（可保其乘积差）。第一项保Ω、共同两半密度及capture排除；不是先拆两个overlap。因为两密度均归一，Cauchy给 `∫f≤1`。第二项用QG时给 `≤||ν||M^{-n}`。LD3是对**同一个正积分**的两个上界取min，不是先用hard帽之后又乘一次QG收益。

原R≤L的B_hard=0可继承排除 `d=max(a,R*/γ³)`；仅在原H0≥a支，R>L朝向可再取d=a。H0<a支不作完整Qa排除。保留这些排除可以改善LD3；下面统一正上界丢弃它们≤1，因而不会误给节点capture资格。

## LD3 真实终端 deficit 传给节点

R229向上覆盖保同一个j，c=c_j=γ^{-j}。实际m/g∈[c/γ,c]，节点g*=cM*≥g。实际较大尺度增幅≤γ，较小尺度增幅≤γ³，故

\[
 1\le g^*/g\le\gamma^2.
\]

对α>0、d2≥d1，有 `min(1,α/d2)≥(d1/d2)min(1,α/d1)`。逐坐标相乘，原 `w_g=bar w_(cg)` 与节点 `w_*=bar w_(cg*)` 满足

\[
 w_*\ge(g/g^*)^n w_g\ge\gamma^{-2n}w_g.
 \tag{LD4}
\]

因此原分支 `w_g≥e^{-D}` 在其真实fiber上推出固定节点资格

\[
 G_{j,M}(y,v)=1_{\{\bar w_{c_j^2M}(y,v)\ge\gamma^{-2n}e^{-D}\}}=1.
 \tag{LD5}
\]

G只依节点和来源y,v，不依x或辅助t。覆盖时必须保此G；不能把原deficit门直接赋给节点而略去γ^{2n}。于是LD3给统一列上界

\[
 G_{j,M}(y,v)\mathcal I
 \le\min\{qA_D,\ \|\nu\|M^{-n}\}
 =q\min\{A_D,\rho(a/M)^n\}.
 \tag{LD6}
\]

G=0时左侧为零；G=1时由 `1/sqrt(w*)≤γ^n e^{D/2}` 得第一帽。两个帽都对所有y,v一致，因此随后可以按原Π⊗Π归一。此步没有用ν≤β，也没有给任何负项赋权。

## LD4 全j/节点/clock的三次对数求和

现在a,b,q,ν在j间共同。每个j从 `M0,j=a/c_j²` 开始按γ向上网格、末点截b，保节点clock

\[
 n\ell_{j,M}(U)=\bigl(n\log(M/M_{0,j})-U\bigr)_+.
\]

记

\[
 S(A,\rho,U)=\sum_{j:\,M_{0,j}\le b}\ \sum_{M\in\mathcal M_j}
 n\ell_{j,M}(U)\min\{A,\rho(a/M)^n\}.
\]

**全域求和引理。** 对任意A>0、ρ≥0、U≥0，

\[
 \boxed{S(A,\rho,U)\le34A\,
 \Psi(\rho e^{-U}/A).}
 \tag{LD7}
\]

ρ=0时两边为零。若 `U≥n log(b/a)`，所有原节点clock为空，S=0；LD7仍成立。

**正规网格证明。** 令 `h=n log γ`，则log2≤h≤1，尤其h≥1/2。令T=n log(b/a)，r=ρe^{-U}/A。正规节点为

\[
 n\log(M/a)=2jh+kh,\quad
 s=kh-U\ge0,\quad
 \frac{n\ell_{j,M}\min(A,\rho(a/M)^n)}A
 =s\min(1,r e^{-(2jh+s)}).
\]

首个k可取ceil(U/h)，于是s=s0+kh，s0∈[0,h)，等号处score为零。有限真实正规节点可正上放为j,k≥0的无限尾。对H≥0，定义加权格点计数

\[
 F(H)=\sum_{\substack{j,k\ge0\,:\ 2jh+s_0+kh\le H}}(s_0+kh).
\]

满足条件的j个数≤1+H/(2h)≤1+H；每个j下k个数≤1+H/h≤1+2H；每个权≤H。因此

\[
 F(H)\le H(1+H)(1+2H)\le2(1+H)^3.
\]

利用精确layer-cake

\[
 \min(1,re^{-z})=\int_0^1 1_{\{z\le\log(r/t)\}}\,dt,
\]

并对负的H将F置零。若0<r≤1，正规和除以A不超过

\[
 \int_0^r 2(1+\log(r/t))^3dt
 =2r\int_0^\infty e^{-v}(1+v)^3dv=32r.
\]

若r≥1，令L=logr≥0，正规和除以A不超过

\[
 2\int_0^\infty e^{-v}(1+L+v)^3dv
 =2[(1+L)^3+3(1+L)^2+6(1+L)+6]
 \le32(1+L)^3.
\]

两者合为 `S_regular≤32A Psi(r)`。这一层积分在实际shift s0上统一，不将clock偏移U舍掉。

**截b末点证明。** 每个j至多有一个额外非正规末点M=b。若b已是正规点不重复；上界允许只对真正额外点求和后再扩大。令H=T−U。H≤0时全零。H>0时截断点的归一权为

\[
 (H-2jh)_+\min(1,re^{-H}).
\]

由h≥1/2，正项j个数≤1+H，且每项≤H，得到

\[
 S_{cap}/A\le H(1+H)\min(1,re^{-H})
 \le(1+H)^2\min(1,re^{-H}).
\]

若r≤1，`e^{-H}(1+H)^2≤4/e<2`给上界2r。若r≥1、L=logr：H≤L时上界≤(1+L)²；H>L时写v=H−L，

\[
 e^{-v}(1+L+v)^2
 \le(1+L)^2e^{-v}(1+v)^2
 \le2(1+L)^2.
\]

所以 `S_cap≤2A min(1,r)(1+log_+r)^2≤2A Psi(r)`。加上正规32得到LD7。此证明没有把跨j的截b末点伪装成等间距节点，也没有重复计原末点。

## LD5 原三腿的完整回代及常数

原正母量为 `2Λ q^{-1}p_y h_R β(dy)ν(dz)Π_t(dv)Π_t(du)`，ρ、history、high、terminal good/bad及当前余量资格均保在实际χ中。截取其中Ω上的far且 `−log w_g≤D` 分支。原good比较给外sqrt(K/3)与三条半密度腿；R229覆盖给4e⁴及一份soft菜单。

固定(j,y,t)时，Π及score不依receiver x和hard来源z。保原Ω、node clock和LD5的G后先做receiver/hard-source联合积分，使用LD6。此时两个后验仍是**同一原Π**，每个时刻的iid score满足

\[
 \iint(k_t(v)-k_t(u))_+\,\Pi_t(dv)\Pi_t(du)\le n/4.
 \tag{LD8}
\]

过程外取零时是同一子概率，该界仍成立。原χ的其余正门只上放为1，不重算carrier。故对每一固定原(ω,V)有

\[
 P_{D,far,V}(U)
 \le2\Lambda\sqrt{K/3}\,(6e^4N_n)\|\beta_V\|\,
 S(A_D,\rho_V,U).
 \tag{LD9}
\]

常数6=4覆盖×3腿×2朝向×1/4 iid Gini。q在LD6中准确消去，ν(v/u)已由原Π归一，不再乘它们的全质量。hardν(z)没有先被删去：它在LD3–6中通过真实局部帽和独立QG列界的min结算。

若a,q,β,ν依j而非共同，只得到明示的未合并版本

\[
 2\Lambda\sqrt{K/3}\,(6e^4N_n)\,
 \mathbb E\sum_{V,j}\|\beta_{Vj}\|
 \sum_{M\in\mathcal M_{Vj}}n\ell_{j,M}(U)
 \min\{A_D,\rho_{Vj}(a_{Vj}/M)^n\}.
 \tag{LD10}
\]

不能对这种任意j变化直接套LD7。当前真实共同来源合同允许在LD9使用LD7，6×34=204，得到立方补充LD1c。全部实际L/R/s均由R229原三腿覆盖；自由独立第三尺度不在本命题内。

本路线使用局部帽与QG只是对同一列取min，没有再乘旧16/3费用。没有消费signed、suffix或删除负信用。若继续保LD3的capture共同窗口，可得到比LD6更小的列；本轮已证统一价不依赖这种额外改善。

## LD5a 持久good来源把每节点clock压到D+1/2

这里额外使用已独立核验的原资格：terminal-good集合 `G=S_g⊂Z_g`，且Z_t随t递减；固定(j,y,t)的原过程不依x。原v始终是good来源，u是bad来源。不能反过来使用，也不把原Π按good重新条件化。

固定一个节点g*=cM，定义 `g_-=g*/γ²≤g_actual`、τ=a/c。若g_-≥τ，令这个节点的**固定**来源集合为

\[
 S=Z_{j,g_-}(y)\cap\{v:w_{g_-}(y,v)\ge e^{-D}\}.
 \tag{LD12}
\]

实际纤维中的good且低D来源v满足 `v∈Z_gactual⊂Z_g-`，以及 `w_g-≥w_gactual≥e^-D`，故全部属于S。这不是把节点权赋给原good，而是由真实存活和权单调性推出的包含。

在早段τ≤t≤min(g_-,g*exp(−U/n))，S⊂Z_t。设

\[
 H_S(t)=\int_S w_t(y,v)\nu(dv).
\]

若ν(S)=0，早段贡献为零。否则
`e_t≥H_S(t)>0`，`H_S(τ)≤ν(S)`，`H_S(g_-)≥e^-D ν(S)`。w_t是原坐标threshold乘积，几乎处处满足 `−d w_t/dlogt=k_t w_t`；固定S后H_S绝对连续，并有同一积分公式。因此，不对删除后的e_t求导，便有

\[
 \int_\tau^{g_-}\int_S k_t(y,v)\Pi_t(y,dv)\,\frac{dt}{t}
 \le\int_\tau^{g_-}\frac{-dH_S(t)}{H_S(t)}
 =\log\frac{H_S(\tau)}{H_S(g_-)}\le D.
 \tag{LD13}
\]

实际早段若更短，只减少正积分。δ≤k_t(v)，且另一份原Π质量≤1，所以保v∈S后的pair正交通也≤D。原过程无效处共同域后验取零，实际积分只更小；H_S用于比较而非扩展实际过程或领取删除信用。

晚段位于 `[max(τ,g_-),g*exp(−U/n)]`，其对数长度≤2logγ。删去其余正门后使用原同Π的iid Gini n/4，费用≤`(n/2)logγ≤1/2`。若g_-<τ，整个节点clock均位于该短段，直接≤1/2；此时不在τ以前定义或调用Z_g-。

与此同时，整段仍有LD8的n ell/4界。因此完整节点clock可以支付

\[
 C_{j,M}\le\min\{n\ell_{j,M}(U)/4,\ D+1/2\}.
 \tag{LD14}
\]

使用顺序必须保真：点态覆盖保node cutoff、Ω及早段固定1_S；做LD6的统一列帽后，才按早/晚段支付。LD6统一于v，故这个固定来源指示可以一直保留；不会在receiver积分后丢掉所有good资格又追认它。晚段只是允许删除此正指示后用Gini。

### 二次对数节点计数

在LD4记号r=ρe^-U/A下，还有

\[
 \sum_{j,M:\,n\ell_{j,M}(U)>0}
 \min\{A,\rho(a/M)^n\}
 \le11A\Psi_2(r).
 \tag{LD15}
\]

证明沿用相同真实网格，但不再计score权s。正规格点数满足
`F0(H)≤(1+H)(1+2H)≤2(1+H)²`。相同layer-cake在r≤1时给
`2r∫exp(−v)(1+v)²dv=10r`，在r≥1、L=logr时给
`2[(1+L)²+2(1+L)+2]≤10(1+L)²`。正规部分≤10AΨ_2(r)。

每j的唯一截b末点数至多1+H，H=T−U>0；其总和除以A≤`(1+H)min(1,r exp(−H))`。r≤1时由 `exp(−H)(1+H)≤1` 给≤r；r≥1时按H≤L和H>L分开，后者写v=H−L并用 `exp(−v)(1+v)≤1`，得到≤1+L。因此末点部分≤AΨ_2(r)，合计11。零clock节点不需要支付；在计数上包含其端点只使上界更宽。

将LD14的D+1/2与LD15结合，保三腿、两朝向和soft菜单，原常数为
`4e⁴×3×2×11=264e⁴`，证明LD1。若用LD14的另一个分支，则仍得到已证LD1c；可以逐叶取两价的min。

## LD6 明确付款子支与保留的互补费用

令实际来源子族满足 `rho_V≤(n+1)^B`，B≥0为固定常数；同时只取真实terminal deficit≤D0，D0固定。由A_D≥1及U≥0，

\[
 A_D\Psi_2(\rho_Ve^{-U}/A_D)
 \le(16e/3)e^{D_0/2}[1+B\log(n+1)]^2.
\]

该来源子族的β质量和≤原W_β，故LD1给实际正交通预算

\[
 P_{D_0,far}^{\rho\le(n+1)^B}(U)
 \le2\Lambda\sqrt{K/3}\,(264e^4N_n)(D_0+1/2)
 (16e/3)e^{D_0/2}[1+B\log(n+1)]^2 W_\beta.
 \tag{LD11}
\]

当K、B、D0固定时，这是 `C sqrt n log^3(n+1) W_β` 的真实已付款分支，覆盖其全部实际soft和合法尺度。也可允许D0=O(log log(n+1))，但额外的e^{D0/2}(D0+1/2)必须保为polylog费用。这里没有通过改U而遗漏浅clock：LD11估选定U的far部分，尤其U=0时覆盖该原far分支的全部有效clock；不据此支付原near或其他终端互补分支。

一般输入仍有两项：真实高deficit `−log w_g>D0` 的互补正交通；以及低deficit来源上的加权二次对数矩 `E sum_V ||β_V|| Psi_2(rho_Ve^{-U}/A_D)`。原粗总质量只允许logρ约n logn，不能将该矩视作polylog(n)而免费覆盖全部来源。LD1把线性ρ降为二次对数是新结算，但没有消去这两个余项，也没有重新使用已付负账。

## LD7 本机核查

实际用本机mpmath 50位精度运行：n=2、16、512；U取0、半个网格步长、总可用长度的一半及空窗边界；r取0.1、1、10，共36组、45断言全部通过。每组直接枚举真实j、正规节点及唯一截b点，验证 `S/A≤34 Psi(r)` 和空窗零值。最大观测 `S/(A Psi(r))≈1.24730874063413382`。这只检查求和与端点实现，严格一般证明是LD4的layer-cake计算，不据数值优化常数或认证原FULL输入。随后另实际运行二次计数及每节点min(clock/4,D+1/2)检查：同36个(n,U,r)基础配置、D取0、0.5、3，共108组、171断言通过；归一二次节点数的最大观测比为1.4255010559537070483。此第二次运行不作为原S持久资格的数值证明，该资格由LD12–14的解析包含与独审原定义支持。

实际运行的复现代码：

```python
import mpmath as mp
mp.mp.dps=50
records=[]; checks=0
for n in (2,16,512):
    h=n*mp.log1p(mp.mpf(1)/n); T=n*mp.log(2)
    for U in (mp.mpf(0),h/2,T/2,T):
        gaps=[]
        for j in range(int(mp.floor(T/(2*h)))+1):
            xmax=T-2*j*h; kmax=int(mp.floor(xmax/h))
            for k in range(kmax+1):
                ss=k*h-U
                if ss>0: gaps.append((ss,2*j*h+ss))
            if xmax>kmax*h:
                ss=xmax-U
                if ss>0: gaps.append((ss,T-U))
        for r in (mp.mpf('0.1'),mp.mpf(1),mp.mpf(10)):
            S=mp.fsum(ss*min(mp.mpf(1),r*mp.exp(-z)) for ss,z in gaps)
            shape=min(1,r)*(1+max(mp.mpf(0),mp.log(r)))**3
            assert S<=34*shape; checks+=1
            if U>=T:
                assert S==0; checks+=1
            records.append((n,mp.nstr(U,12),mp.nstr(r,4),
                            mp.nstr(S,18),mp.nstr(S/shape,18)))
print('dps',mp.mp.dps,'cases',len(records),'assertions',checks)
print('max_ratio',max(mp.mpf(row[4]) for row in records))
for row in records: print(row)
```

第二次实际运行复现代码（相同mpmath环境）：

```python
import mpmath as mp
mp.mp.dps=50
checks=0; countmax=mp.mpf(0); cases=0
for n in (2,16,512):
    h=n*mp.log1p(mp.mpf(1)/n); T=n*mp.log(2)
    for U in (mp.mpf(0),h/2,T/2,T):
        gaps=[]
        for j in range(int(mp.floor(T/(2*h)))+1):
            xmax=T-2*j*h; kmax=int(mp.floor(xmax/h))
            for k in range(kmax+1):
                ss=k*h-U
                if ss>0: gaps.append((ss,2*j*h+ss))
            if xmax>kmax*h:
                ss=xmax-U
                if ss>0: gaps.append((ss,T-U))
        for r in (mp.mpf('0.1'),mp.mpf(1),mp.mpf(10)):
            terms=[(ss,min(mp.mpf(1),r*mp.exp(-z))) for ss,z in gaps]
            shape2=min(1,r)*(1+max(mp.mpf(0),mp.log(r)))**2
            count=mp.fsum(w for ss,w in terms)
            assert count<=11*shape2; checks+=1
            countmax=max(countmax,count/shape2)
            for D in (mp.mpf(0),mp.mpf('0.5'),mp.mpf(3)):
                value=mp.fsum(min(ss/4,D+mp.mpf('0.5'))*w for ss,w in terms)
                assert value<=11*(D+mp.mpf('0.5'))*shape2; checks+=1
                if U>=T:
                    assert value==0; checks+=1
                cases+=1
print('dps',mp.mp.dps,'cases',cases,'assertions',checks,
      'max_count_shape2',mp.nstr(countmax,20))
```

Python路径 `/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`，PYTHONPATH `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor`。只写本稿，不改其他工作文件。
