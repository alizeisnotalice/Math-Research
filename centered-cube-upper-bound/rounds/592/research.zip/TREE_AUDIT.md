# R592 同步closing的全尺度overlap桥独审

结论：在共同固定阈值t>0及真实坐标分离下，|EL(t)∩(EU(t)−he_j)|对0≤h≤g单调不减。适当postorder真实源树中，可以将各节点注入的体积上界转移至同一final配置的对应half-overlap。通过的是完整、未裁剪集合的同步比较；它不支付正overlap总和，不准许免费移动原固定paid set，也不提供uniform gain。

先独立核准确命题与证明结构；未作新输入扫描。所有标签保持正质量/原source class，Q的参数为side。

## 1. 横截面分量的中心守卫

来源满足max_L z_j≤a<b≤min_U z_j，g=b−a>0。固定其余n−1坐标后，每个实际C_S(t)切片是一个闭interval、点或空集。下侧非空interval的中心为(max_{i∈S}z_ij+min_{i∈S}z_ij)/2≤a；上侧相应≥b。其他轴是否接收只筛选这些实际interval，不改变其j轴中心。

需要检查union分量，而非把全部父interval相加。下侧一个连通分量为[ell,u]，选提供右端u的实际interval[ell_i,u]；ell≤ell_i且ell_i+u≤2a，所以ell+u≤2a。故此分量中心≤a。上侧分量取提供左端ell的interval[ell,u_i]，u_i≤u且ell+u_i≥2b，故分量中心≥b。有限interval union保证端点可由实际interval取得；degenerate点和touch合并不破坏结论。

## 2. 每对分量交长及全部pairs无重复

两分量中心c_L≤a、c_U≥b，半长p,q≥0。上侧平移−h后中心差Δ=c_U−h−c_L≥g−h≥0。在该范围，交长准确为

max(0,min(2p,2q,p+q−Δ))。

随着h增加，Δ减小且仍非负，故每对交长不减。上侧整组平移保持其自身分量结构；下侧不动。两侧各自不同分量内部不交，故不同pair的交片不重复计长（端点即便重合也为1维零测）。总交长就是全部有限pair交长之和，因此逐截面单调。

Fubini对所有其他坐标积分，得n维完整交体积单调。n=1直接是上述证明。闭盒等号h=g合法；若继续越过g则中心差可能变号，不在此结论范围。全尺度全部subset及zero/negative-width出生已在真实切片中处理，无来源独立/密度假设或父数量fee。

## 3. Postorder同步的准确条件

对一个固定label二叉树，要求处理每个节点时，其两个子组沿所选轴确实严格分离，步幅≤当时gap；若还用前一注入，则须≤b_n乘当时gap。每个节点内部descendants先处理，之后仅ancestor会整体平移该节点所有标签，incomparable节点不影响它。

一个充分的实现是由原始递归轴切分产生树：每次closing只把upper组沿所用轴向lower平移，不越过当时gap。这使当前节点的来源bbox不扩大；所以先前指定的ancestor子组分离不会被内部closing破坏。任意抽象source二叉树没有这项几何保证，不能默认适用。

在节点v，half-threshold I_v^pre经该节点closing后体积不减。后续ancestor共同平移其两子组，故该overlap体积此后不变。于是前一receiver注入的|B_v|≤|I_v^pre|可接到

|B_v|≤|I_v^final|。

这是每个节点同时指向同一最终真实source配置的体积比较。它本身不声称I_pre⊆I_after这种集合包含；如要实际点映射还须另给map。来源数、质量不变，最终仍是合法有限输入。若后续在已完成node内再做非刚性或非共同平移，该同步结论须重新证明。

## 4. 全费用限制：signed tree与固定P

在同一final配置、同一阈值t，对节点v定义完整E_v及

Z_v=E_v\(E_L∪E_U)，I_v=E_L∩E_U。

准确telescoping为

|E_root(t)|=W/t+Σ_internal(|Z_v(t)|−|I_v(t)|)。

因此只有signed差望远镜；未控制Z_v时不提供Σ|I_v|的source-linear上界。节点间final overlaps可在同一接收点叠加多层，注入没有使它们跨节点互斥。原λ注入与λ/2 overlap须保留两个阈值各自的完整身份及差项，不可混成一个threshold的tree望远镜。

此外这是一条未裁剪的全level比较。若原paid set P=H2∪G固定，则ancestor移动一般改变overlap与P的位置关系；不能把I_pre\P的体积也自动送入I_final\P，更不能各节点移动自己的P后仍只付原一次P。原丢失/新增/partial overlap及所有保留系数必须在最终总式中继续出现。

## 5. 可用结论及停止范围

可合法累计的是Σ|B_v|≤Σ|I_v^final|，条件为第3节真实同步过程。该式解决了节点上价不在同一几何配置的同步问题，但没有支付右侧正和。下一完整预算须保留对应signed cross gains及两阈值差/未用overlap，或给独立source-uniform付款；不能丢掉这些项后宣称增益。

本次为独立书面几何审核，未运行维数/输入扫描、LP或另造例子。已准许的全族同步桥通过；uniform gain仍未证明。完成此命题审核，停止扩展。
