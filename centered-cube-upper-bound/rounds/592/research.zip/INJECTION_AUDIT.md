# R592 共同cut的接收注入与minority分量独审

**通过准确分量；不认证完整gain。** |B_h|≤|I|的加强正确，跨全部原subset/scale一次成立；追加的原Z0 minority界及极值deficit身份也正确。以下给出独立推导、闭盒边界及可合法接入的完整预算方向。未读本轮作者长稿，未作新输入扫描或改动他人文件。

## 1. 准确对象与单次receiver注入

同一个原标签cut L/U沿第j轴，a=max_{i∈L}z_ij、b=min_{i∈U}z_ij、g=b−a>0。EL、EU是各侧原位置、原阈值λ的ALL-subset全level；PL、PU为各侧原位置λ/2全level，I=PL∩PU。所有r、R均为实际cube的side length。

令α=2^(1/n)，b_n=(α−1)/(α+1)，0≤h≤b_ng，c=(a+b−h)/2，B_h=(EU−he_j)∩EL。分

B_h^−={y∈B_h:y_j≤c}，B_h^+={y∈B_h:y_j>c}。

对下支y，取实际上侧非空subset见证，side R，故y+he_j∈C_upper(λ)。它的所有来源第j坐标≥b，所以

R≥2(b−y_j−h)≥g−h。

由于(α−1)(g−h)≥2h，半阈值同一subset的每面buffer至少h。从y+h回移至y仍在PU；y本在EL⊆PL。因此y∈I。

对上支y，取实际下侧非空subset见证，side r，所有来源第j坐标≤a，故

r≥2(y_j−a)>g−h。

同一buffer使y+he_j仍在PL；它本在EU⊆PU，故y+he_j∈I。

因此映射φ(y)=y（下支）、φ(y)=y+he_j（上支）把整个B_h送进原I。两支像分别位于第j坐标≤c和>c+h，互不相交；各支分别是identity/translation，保持Lebesgue测度且单射。所以

|B_h|=|φ(B_h^−)|+|φ(B_h^+)|≤|I|。

这里map仅按一个全局接收坐标阈值定义，不依赖选中的父或见证，故不存在按两父/尺度重复收费。无需可测选择实际witness；它们只用于证明给定分支的包含。源选择仍是一个共同cut，φ是分析用receiver注入，不是按receiver重建来源输入。

所有维度的其他坐标都不移动，保留原见证约束；λ/2扩大同一实际cube的每面，不能混淆成欧氏球扩张。闭盒可取临界h=b_ng及下支y_j=c的等号；两像仍因上支严格>c+h而不交。h=0时也是同一identity的分支划分。改用strict level时仅需除去有限盒边界，不影响体积。

步幅h=g/(4n)安全。b_n=tanh(log2/(2n))；tanh在正轴凹且tanh(0)=0，故n b_n≥tanh(log2/2)=1/3>1/4，适用于所有正整数n。

## 2. 可合法接入的完整预算方向

沿同一cut把上侧实际来源平移−he_j，0≤h≤b_ng<g。X_h为全部crossing父的实际移动盒并，包含负宽birth。所有这些盒在该范围单调扩张，X_0⊆X_h。令

A_h=EL∪X_h，E_h=A_h∪(EU−he_j)，E=EL∪EU∪X_0；

C_h=(EU−he_j)∩(X_h\EL)，O_h=EU∩A_h。

新pure-upper与A_h的碰撞恰分为不交的B_h和C_h，不能再按crossing父求和。因为|EU−h|=|EU|，完整有限并身份是

|E_h|−|E|=|X_h\E|+|O_h|−|B_h|−|C_h|。

真全尺度极值给左侧≤0，故注入允许

|X_h\E|+|O_h|≤|I|+|C_h|。

有near-max误差ζW时，乘λ后右侧另加ζW。这个式子准确定位下一未付量：纯纯B_h已可一次由I控制；pure–cross的C_h未支付。它仍是extremality给出的增长上方向限制，不是完整正增益下界。原完整half-threshold halo平移量(PU−h)\PU也不由本注入覆盖，不能连带删去。

若后续将I用作配对账正信用，需在同一个带系数总式中替换B_h；不能既免费以I付款，又不扣系数地将整份I重复算作另一独立收益。cross–cross交叠已经在完整X_h中计一次，不能重新发父数量费用。上述分解是当前可用的完整budget入口，不是新增source-linear总估计。

## 3. 追加独审：原未移动crossing的minority付款

设Z0=X_0\(EL∪EU)，0<ε<1；令Z_{0,U}^{small}为其中存在某原crossing witness S、m(S∩L)≤εm_S的点。量词是“存在实际原S”，不要求所有见证都满足该比例，也不是移动后新出生盒的抽象mask。

此y在原C_S(λ)内，故其纯U子集被同一Q(y,r_S)实际捕获，质量至少(1−ε)m_S。该子集在阈值(1−ε)λ的实际side至少r_S，因此

Z_{0,U}^{small}⊆E_U((1−ε)λ)\EU(λ)。

右侧排除EU来自Z0定义。用相同full-scale C_{n,d}对子输入/新阈值上价，且较低阈值集合包含EU，得到

λ|Z_{0,U}^{small}|≤C_{n,d}m_U/(1−ε)−λ|EU|
 =D_U+[ε/(1−ε)]C_{n,d}m_U，

D_U=C_{n,d}m_U−λ|EU|≥0。

没有逐父求和、位置独立或外部密度假设；重合标签及closed等号不影响实际subset证明，ε<1保证阈值和U见证质量为正。若某一minority mask确为该点集子集，可以同界。**不能直接套到fresh release X_h\E：** 那里的上侧来源是在移动位置被捕获，y+h可能已在旧EU，原difference subtraction和D_U费用须另证，不能默认继承。

真全尺度极值λ|E|=C_{n,d}W时，全并分解给

D_L+D_U=λ(|Z0|−|EL∩EU|)。

near-max λ|E|=(C_{n,d}−ζ)W时右侧另加ζW。由deficit选较小侧可给D_U≤(D_L+D_U)/2（必要时反转移动方向）；这与选m_U≤W/2不是同一个条件，不能无证同时假定。D_U和ε C_{n,d}m_U本身也未成为已付root费；不能把这个精确分量界写成全局source预算。large-minority与完整fresh release的有效下界仍缺。

## 4. 实际核验与结论范围

本机指定数学Python/SymPy1.14.0实际核对：临界h=b_ng时buffer残差为0；tanh(log2/2)=1/3；保留X_0⊆X_h的24个Boolean状态中，第2节完整并身份在加上平移体积抵消项后残差全0；第3节deficit系数分解残差为0。一般几何包含由以上独立书面证明，不依赖这些有限代数检查。

本次没有重跑几何枚举、LP、参数扫描或一般counterexample搜索。通过的是一次完整pure–pure碰撞的measure injection、原Z0 small-minority分量及准确的完整账。它们没有支付C_h、全halo平移、large-minority或产生所需uniform-d gain；不证明一般阶数改善。审核至此停止。
