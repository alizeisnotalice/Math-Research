#!/usr/bin/env python3
"""Fixed dimension calibration of gap-buffer fees; no geometry or LP."""
import argparse,hashlib,json,platform,resource,shlex,sys,time
from fractions import Fraction as F
from pathlib import Path
import sympy as sp
import flint
from flint import arb,ctx

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r592_RESULTS.json'));args=ap.parse_args()
 start=time.perf_counter();ctx.prec=512
 n,a,t=sp.symbols('n a t',positive=True);q,u,W=sp.symbols('q u W',positive=True)
 logq=n*sp.log((n+a)/(n-a));kernel=n*n/(n*n-t*t)
 symbolic={}
 def zero(name,value):
  value=sp.simplify(value);assert value==0;symbolic[name]=str(value)
 g=sp.symbols('g',positive=True)
 zero('radius_multiplier_substitution',1+2*(a*g/n)/(g-a*g/n)-(n+a)/(n-a))
 zero('logq_a_derivative_minus_2kernel',sp.diff(logq,a)-2*kernel.subs(t,a))
 zero('logq_at_alpha_zero',logq.subs(a,0))
 zero('kernel_minus_one',kernel-1-t*t/(n*n-t*t))
 zero('kernel_endpoint_difference',kernel.subs(t,a)-kernel-n*n*(a*a-t*t)/((n*n-a*a)*(n*n-t*t)))
 zero('kernel_n_derivative',sp.diff(kernel,n)+2*n*t*t/(n*n-t*t)**2)
 p_fair=1/(2*q);p_asym=1/(2*(1+(q-1)*u))
 zero('fair_symmetric_inflated_source_fee',2*q*p_fair*W-W)
 zero('asymmetric_source_fee',2*p_asym*(W*(1-u)+q*W*u)-W)
 zero('asymmetric_half_probability_gap',sp.Rational(1,2)-p_asym-(q-1)*u/(2*(1+(q-1)*u)))
 zero('asymmetric_lower_probability_gap',p_asym-1/(1+q)-(q-1)*(1-2*u)/(2*(1+q)*(1+(q-1)*u)))
 c=sp.log(2)/2
 zero('tanh_c_equals_one_third',sp.tanh(c).rewrite(sp.exp)-sp.Rational(1,3))
 x=sp.symbols('x',positive=True)
 zero('tanh_second_derivative',sp.diff(sp.tanh(x),x,2)+2*sp.tanh(x)/sp.cosh(x)**2)
 # Frozen grid: initial 24 cases, then n4096 for the initial alphas and
 # alpha1/2 at all nine frozen n values (12 additional cases).
 ns=[1,2,4,8,16,64,256,1024,4096];alphas=[F(1,16),F(1,8),F(1,4),F(1,2)]
 def af(v):v=F(v);return arb(v.numerator)/v.denominator
 def out(v):return {'Arb512':v.str(65),'absolute_radius':v.rad().str(15)}
 cases=[];exact_q={};dim_guards=[]
 for nn in ns:
  cc=arb(2).log()/2;bn=(cc/nn).tanh();nb=nn*bn
  if nn==1:assert (nb-af(F(1,3))).contains(0)
  else:assert nb>af(F(1,3))
  assert nb<af(F(1,2));assert cc<af(F(1,2));assert nb<cc
  dim_guards.append({'n':nn,'b_n':out(bn),'n_b_n':out(nb),'n_b_n_minus_one_third':out(nb-af(F(1,3))),'upper_log2_over2':out(cc),'lower_guard':'symbolic equality at n1' if nn==1 else 'Arb512 strict positive'})
  for aa in alphas:
   assert 0<aa<1 and aa<nn
   base=(nn+aa)/(nn-aa);qq=base**nn;exact_q[nn,aa]=qq
   L=nn*af(base).log();qball=L.exp();lower=2*af(aa);upper=2*af(aa)/(1-(af(aa)/nn)**2)
   assert L>lower and upper>L
   uniform_exact=(1+aa)/(1-aa);assert qq<=uniform_exact
   if nn==1:assert qq==uniform_exact
   fair=1/(2*qq);asym_lower=1/(1+qq)
   assert 0<fair<=F(1,2) and 1-2*fair>=0 and F(1,2)>=asym_lower>0
   guard=nb-af(aa);expected_pass=aa!=F(1,2)
   if expected_pass:assert guard>0
   else:assert guard<0
   cases.append({'n':nn,'alpha':str(aa),'stage':'initial' if nn!=4096 and aa!=F(1,2) else 'expanded_predeclared',
    'q_exact_compressed':{'base':str(base),'integer_exponent':nn},'q':out(qball),'log_q':out(L),'log_lower_2alpha':out(lower),'log_upper':out(upper),'log_lower_gap':out(L-lower),'log_upper_gap':out(upper-L),
    'uniform_q_upper_exact':str(uniform_exact),'uniform_q_bound_exact_rational_verified':True,
    'fair_probability_p':out(af(fair)),'fair_empty_probability':out(af(1-2*fair)),'fair_source_fee_over_W_exact':'1',
    'asymmetric_p_min_for_upper_mass_le_half':out(af(asym_lower)),'asymmetric_p_max_exact':'1/2',
    'collision_step_margin_n_b_n_minus_alpha':out(guard),'collision_step_allowed':expected_pass,'collision_pressure_note':'alpha=1/2 strictly exceeds collision threshold; fee calibration still valid' if not expected_pass else 'step valid in every dimension by analytic n*b_n>=1/3'})
 # Exact finite monotonicity checks, independent of the Arb logarithmic evaluation.
 alpha_checks=0;dimension_checks=0
 for nn in ns:
  for lo,hi in zip(alphas,alphas[1:]):assert exact_q[nn,lo]<exact_q[nn,hi];alpha_checks+=1
 for aa in alphas:
  for lo,hi in zip(ns,ns[1:]):assert exact_q[hi,aa]<exact_q[lo,aa];dimension_checks+=1
 result={'scope':'Gap-buffer dimension/source-fee calibration only. No complete receiver, halo, source-law gain, contraction, LP or general weak-bound certificate.',
 'formula_audit':{'gap_step':'h=alpha*g/n, g>0, 0<alpha<n','radius_multiplier':'1+2h/(g-h)=(n+alpha)/(n-alpha)','mass_multiplier':'q_n(alpha)=((n+alpha)/(n-alpha))^n','valid':True},
 'general_certificate':{'domain':'all real n>=1 and 0<alpha<1 (hence alpha<n except equality excluded at n1 alpha1)',
  'integral_identity':'log q_n(alpha)=2 integral_0^alpha n^2/(n^2-t^2) dt',
  'bounds':'2alpha <= log q <= 2alpha/(1-(alpha/n)^2) <= 2alpha/(1-alpha^2)',
  'monotonicity':'strictly increasing in alpha; strictly decreasing in n for alpha>0, since derivative_n kernel=-2n*t^2/(n^2-t^2)^2<0 for t>0',
  'uniform_sharper_q_bound':'exp(2alpha) < q_n(alpha) <= q_1(alpha)=(1+alpha)/(1-alpha), with upper equality only at n=1',
  'proof_level':'Direct integral/kernel inequalities on 0<=t<=alpha<n, not extrapolation from finite values'},
 'source_fee_certificate':{'partition_assumption':'m_L+m_U=W, m_L,m_U>=0, q>=1; for lower probability bound require m_U<=W/2',
  'fair_law':'p=1/(2q) on each side and 1-2p on empty; symmetric inflated charge 2qpW=W',
  'asymmetric_law':'p=W/[2(m_L+q*m_U)] on each side and 1-2p on empty; charge 2p(m_L+q*m_U)=W',
  'probability_bounds':'0<p<=1/2, and if m_U<=W/2 then p>=1/(1+q)',
  'price_scope':'This certifies the algebraic C_(n,d)*W upper charge assuming the separately justified side/threshold source estimates; it proves no lower gain.'},
 'collision_step_general_certificate':{'b_n':'tanh(log(2)/(2n))=(2^(1/n)-1)/(2^(1/n)+1)',
  'proof':'tanh is concave on [0,infinity), tanh(0)=0, so tanh(c/n)>=tanh(c)/n with c=log2/2 and tanh(c)=1/3. Also tanh(x)<x for x>0 and c<1/2.',
  'conclusion':'1/3<=n*b_n<log2/2<1/2; alpha1/16,1/8,1/4 valid for every n>=1; alpha1/2 fails for every n>=1',
  'not_gain':'Collision step admissibility is not a global collision payment or a contraction proof'},
 'symbolic_residuals':symbolic,'finite_grid':{'n':ns,'alpha':list(map(str,alphas)),'cases':len(cases),'exact_alpha_monotonicity_comparisons':alpha_checks,'exact_n_monotonicity_comparisons':dimension_checks},'dimension_collision_guards':dim_guards,'cases':cases,
 'execution':{'interpreter':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'precision_bits':ctx.prec,'processes':1,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]])},'all_assertions_passed':True}
 args.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'cases':len(cases),'symbolic_checks':len(symbolic),'exact_monotonicity_checks':alpha_checks+dimension_checks,'step_pass':sum(v['collision_step_allowed'] for v in cases),'step_pressure_fail':sum(not v['collision_step_allowed'] for v in cases),'execution':result['execution']}))
if __name__=='__main__':main()
