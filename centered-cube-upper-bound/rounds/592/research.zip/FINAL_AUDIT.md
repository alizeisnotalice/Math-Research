# R592 最终合并独审

**PASS，可归档；未发现当前版本必须修复项。** 通过的是报告实际声称的完整pure–pure注入、原minority分量、费用校准、真实reassembly比较及带余项的同步树账。未认证完整mixed支付、uniform gain或一般弱型阶数改善。

全文对象 `/tmp/ccu_r592_REPORT.tex`，最终SHA256：

`fa24239e0d6862339c2e3a21597da2047c16fbe1d1879633e2121bb65c40eb04`

本文件合并本轮先行、注入与树命题独立推导及最后整合核验；R591入口作为已审工具沿用。先独立核命题，再读指定作者及报告。未改报告/仓库，未编PDF、启新agent或扩大输入扫描。

## 已核数学及费用边界

- **完整对象与恢复。** 全尺度ALL-subset、≤d正标签的C_{n,d}和真极值均按原source class使用；零padding、固定d与uniform-d不混同。原P=H2∪G的c_G费只一次，G包含原atom例外，空间cap只对原位置及其限制输入继承。来源上价F(A)≤2Cm_A、固定gain的ηC≤(1+η)c_G+D及其uniform-d直接L1恢复合法，但gain未证。完整child半阈值PL/PU是明确的whole-child集合；其交集不能无证认作受限原eligible F中的同一贡献。

- **注入。** 按c=(a+b−h)/2分接收者，两支分别送至I及I内平移后的点，像位于≤c和>c+h，全部维度测度保持且不重收。实际witness侧长下界与(2^(1/n)−1)(g−h)≥2h对应准确。闭盒等号、h=0及其他轴约束保留；strict约定只差有限边界。整个B_h一次有|B_h|≤|I|，未按父/尺度叠加。n b_n≥1/3保证h=g/(4n)安全；这支付的是net纯并损失，不是无条件所有旧lost点。

- **完整mixed账。** X_0⊆X_h含负宽出生；Z_h、M、F定义给Z0\Z_h=M及F⊆Z_h\Z0。全输入极值身份推出(1)，其不等号方向及B0扣项正确。另一含C_h的全并分解也正确，pure–cross和整个half-halo平移未被删掉。

- **Minority和deficit。** 仅原Z0上的实际原crossing见证、m_L(S)≤εm_S，才落入原U输入((1−ε)λ)-level减去原λ-level。完整子输入一次上价给D_U+εCm_U/(1−ε)，不是逐父费。D_L+D_U=λ(|Z0|−|B0|)在真极值准确；near-max需加ζW。较小deficit侧与较小质量侧不能同时无证选择。式(3)的−Z0/2、+3B0/2及误差3ζW/2正确；ε=1/8所得9CW/14只是保守分量界，不是J_G收缩。fresh release不自动继承原annulus subtraction。

- **Buffer概率费。** 非空移动crossing见证r_S≥g−h。h=αg/n对应所需side放大(n+α)/(n−α)，质量因子q_n正确。两侧以1/(2q_n)各选一次、余下选空，实际来源上费为CW。只上侧降阈值时p=W/[2(m_L+q_nm_U)]合法；其下界1/(1+q_n)确须m_U≤W/2。报告未把它与小deficit选择拼接。log q的积分、上下界、随n/α方向及q_n≤q_1均由直接一般证明支持；α=1/2的fee可定义，但collision步在全部维数 inadmissible。

- **Compression/reassembly。** c=2^(-1/n)时每个原halfcore carrier的像真落入压缩子输入同core的λ见证；c^n=1/2及X_A,X_B≥0正确。全新输入的fresh-crossing减pure-overlap给精确I_c，允许为负；不能只保留old eligible crossing或删掉它。充分远有限平移确可使全部crossing为空且纯子输入分离，I_c=0。相同core、完整正体积carrier的正对角像约束给c_jr_S≤r_K及det≤m_K/m_S；这是限定机制的必要条件，不是所有重组的障碍。没有已证统一正reassembly收益。

## 同步树与固定P：最后修正已核

横截面先按各侧完整interval union合并连通分量。分量中心仍分别≤a、≥b；每对在0≤h≤g的非负中心距离减小、交长不减，且pair交片内部不重叠。Fubini给完整allscale overlap单调，没有父数费用。

Postorder过程用当时实际分离gap；报告现明确每节点0≤h_v≤b_ng_v，严格强于仅单调需要的h≤g。无gap/零motion节点K_v=0用普通threshold包含。后续ancestor共同平移整个node，故所有节点的post状态可同时解释为同一final输入的限制。移动前half-overlap与final集合不能直接混同；保留K_v后J_final(λ)≤J_final(λ/2)−K_v正确。

两个共同阈值的signed树式中W/λ项、Z差及root level差系数准确。Z_half−Z_full没有预定符号；丢掉K或crossing差均不能得到新gain。正overlap总和仍未支付。

固定P的最后限定正确：同一final输入先形成全部signed望远镜、再整体按原P裁剪，P内signed积分上界为|P|，并不强制depth费。final叶盒未必在原P内，但P外叶减项总量至多W/λ（半阈值2W/λ），也是一次费。尚不能逐节点私移P、把每次中间注入裁剪后原样同步，或把原空间source cap搬到新几何。报告准确区分这两层，未将signed抵消当作正费用总预算。

## 实际计算证据及代码范围

通读 `/tmp/ccu_r592_buffer_probe.py`，SHA256：

`cff02df797348e4bad0949405be3b471471982908a6ea7e15eed784c1e63e89d`

读取作者 `/tmp/ccu_r592_RESULTS.json`（SHA256 `3293320950887a6baecdb3396157dc2c60b62259f48f7439757bbb02f222a9cf`）、root `/tmp/ccu_r592_ROOT_REPLAY.json`（SHA256 `c8e31fa4b57bf0f0ff8e85b64e068738a1c70ad5a45146db38ef52fa10ad22d4`）及replay摘要。本人未再次执行该producer；root实际同代码重放已记录，数学payload排除execution后相同。这是same-code replay，不是第二个独立几何算法。

代码确实只校准n={1,2,4,8,16,64,256,1024,4096}和四个α，共36参数案例；12个SymPy残差为0，27+32=59个Fraction严格单调比较。27个collision步通过、9个α=1/2明确拒绝。q用精确有理base与整数幂，符号/概率等式无浮点回退；Arb512严格比较提供有限参数余量，每个记录球均有radius。n=1的n b_n=1/3由独立符号恒等式支持，不仅靠区间contains(0)。没有实际receiver arrangement、source-law gain、几何输入扫描、LP或MATLAB实验。一般n的解析界不是由36值外推。

本人在本轮实际用本机数学Python/SymPy核了完整outside/overlap/lost的8个Boolean状态、保留X0⊆Xh的完整翻译并24状态、临界buffer残差、tanh(log2/2)=1/3及minority系数分解。一般几何结论依赖书面推导；没有冒称执行作者probe或尚未运行的检查。

## 最终状态

可归档的是完整纯碰撞注入、一个原minority annulus分量、真实同步桥及保留全部项的账。尚需统一控制large-minority/mixed mask、fresh release、跨尺度正费用和最终两阈值crossing变化，或给完整有效重组收益。当前没有uniform-d fixed gain，故原一般L1目标仍未达成；报告的结论范围准确。最终独审结束。
