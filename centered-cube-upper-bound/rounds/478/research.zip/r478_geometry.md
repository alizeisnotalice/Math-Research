# R478：保留最大质量锚父及共同选择的对数尺度预算

## 1. 范围与新收据

沿 R477 的同一原接受测度 \(\Pi\)，\(\Pi_A=t(A)\sigma(dA)\)、\(0\le t\le S\)，\(\sigma=q_A dA\)、\(m_A=\mu(Q_A)=q_AR_A^n\)、\(r=\lambda/q\)、\(a\le R_A\le b\le2a\)。原 \((A,y,z)\) 密度为 \(\ell\sigma\pi_A^2\)，\(0\le\ell\le S\)。全部原历史不变。

本节**替换 R477 的辅助采样**，不对其已筛流重新假设旧来源条件律。得到一个保留最大质量父的整族正子流 \(\Xi_{\max}\)，同时支付该实际锚父的全局对数边长误差。旧主费用不能与本节替代费用重复相加。没有证明完整 \(|\Xi_{\max}|\) 的根阶上界。

记完整质量带为 \(J_j\)，对数宽度 \(L_j\le L\)，\(N\le1+[\log r+n\log(b/a)]/L\)，并保 R477 原 \(u_j,P_{x,j},\beta_j,b_A\) 的定义。令
\[
 D_*:=\log r+n\log(b/a),\qquad
 H=\max(1,S/\tau),\quad T=1024rSH,\quad \tau>0.
\tag{1}
\]
\(S=0\) 时原流为零。以下 \(S>0\)。删 \(u_j\le T\) 费用至多 \(T\mathcal M\)，\(\mathcal M\le NW\)；原父 \(t(A)<\tau\) 的实际费用至多 \(\tau X\)。同原 \(u_j\) 的闭中位门 \(\beta_j(A,x)\ge1/2\) 保留至少半个 high 流，随后删低 \(t\) 得
\[
 R_{\rm rank,t}\ge\tfrac12R_{\rm high}-\tau X.
\tag{2}
\]
不能先改变 \(t\) 后仍沿用旧 \(u_j\) 的中位结论。

## 2. 最大质量样本确实留在族中

给定原 \((A,x,j)\)，取 \(k=\lfloor u_j(x)/T\rfloor\ge1\) 个独立截断父
\(Q=P_{x,j}1_{m_B\le m_A}/\beta_j\)。固定父的亲和行上界为
\(\alpha'=8rS/u_j\)，故 \(k\alpha'\le1/(128H)\)。为每个样本独立附均匀标记，按“质量、标记”字典序选最大者 \(B_*\)；它也是最大质量样本，质量原子合法。

\(k\ge2\) 时同时保留以下事件：有向非对角总亲和 \(O\le4\alpha'k(k-1)\)；最大样本的增广闭秩 \(v\ge1/2\)；最大样本行和不超过 \(1/2\)；最大样本不捕获原 \(y,z\)；捕获任一旧来源的样本数不超过 \(k/4\)。五项失败概率分别不超过
\[
 \frac14,\quad 2^{-k}\le\frac14,\quad
 4(k-1)\alpha'\le\frac1{32},\quad
 2(S/\tau)k\alpha'\le\frac1{64},\quad
 8(S/\tau)\alpha'\le\frac1{16}.
\tag{3}
\]
第二项使用增广秩均匀分布。给定最大样本及 \(v\ge1/2\)，其余样本独立服从增广下截断律，密度至多 \(2Q\)，故最大行期望不超过 \(2(k-1)\alpha'\)，得到第三项。

最后两项保留原来源条件律：在 \(t(A)\ge\tau\) 上，原 \((y,z)\mid A\) 的密度为 \(\ell/t(A)\le S/\tau\)，样本给定 \((A,x)\) 与旧记录独立。对每个 \(m_B\le m_A\)，
\(\pi_A(Q_B)=I_{AB}/m_A\le\gamma_{AB}\)。最大样本律不超过 \(kQ\)，给第四项；普通样本的命中比例均值不超过 \(2(S/\tau)\alpha'\)，再用 Markov 给第五项。不要求两旧来源在实际条件律下独立。

失败概率总和至多 \(39/64\)。\(k=1\) 时不加最大秩门，亲和条件自动成立，唯一命中失败不超过 \(2(S/\tau)\alpha'<1/64\)。成功后删原行和大于 \(1/2\) 的索引，再删命中旧来源者；删数至多
\[
 8\alpha'k(k-1)+k/4\le(k-1)/16+k/4<k/2.
\]
最大父未被删除。保留族仍有 R477 的 Gram、共同来源、同带更小质量及整族旧双来源外部性质。按原索引删行的规则可测。

由 (2)–(3)，实际正子流满足
\[
 |\Xi_{\max}|\ge\frac{25}{64}(R_{\rm high}/2-\tau X),\qquad
 \boxed{R\le T\mathcal M+2\tau X+\frac{128}{25}|\Xi_{\max}|.}
\tag{4}
\]
\(L=\sqrt n\) 时第一项为显式 \(O_{r,S,\tau}(\sqrt n)W\)。\(2\tau X\) 是新增费用，不能从旧吸收额中自动扣除。

## 3. 真正积分掉选择重复：最大质量的有序边界公式

固定 \((j,x)\)，令 \(U=u_j(x)>T\)、\(F(m)=\int_{J_j\cap\{m_B\le m\}}t(B)c_B(x)\sigma(dB)/m_B\)。原父的来源投影正是 \(dF(m_A)\)，而 \(b_A(x)=F(m_A)\)。固定该层 \(k=\lfloor U/T\rfloor\)。原质量正下界保证所有对数有限。对截断样本最大质量，
\[
 \mathbb E\log\frac{m_A}{m_{B_*}}
 =\int_{\log m_j^-}^{\log m_A}
       \left[\frac{F(e^s)}{F(m_A)}\right]^k ds.
\tag{5}
\]
阈值恰等于原子的 \(s\) 是 Lebesgue 零集，不改变该式。此处真实 \(b_A^{-k}\) 并未删除，而被最大值分布保留。

对 \(k>1\)，交换 \(s\) 与真实父积分，闭 CDF 的右端 Stieltjes 和被递减函数积分控制：
\[
 \begin{aligned}
 \int dF(m_A)\,\mathbb E\log\frac{m_A}{m_{B_*}}
 &\le\int_{\log m_j^-}^{\log m_j^+}
 \frac{F(e^s)}{k-1}\left[1-\left(\frac{F(e^s)}U\right)^{k-1}\right]ds\\
 &\le\frac{UL_j}{k-1}\le3TL_j.
 \end{aligned}\tag{6}
\]
具体地，质量 \(m_A>e^s\) 的每个 CDF 原子，对应区间 \((F(m_A-),F(m_A)]\)，其右端值 \((F(e^s)/F(m_A))^k\) 不超过该区间平均；连续部分按同一 Stieltjes 换元。故总和不超过 \(\int_{F(e^s)}^U(F(e^s)/v)^k dv\)。\(F(e^s)=0\) 时被积项为零。最后用 \(U<(k+1)T\)。\(k=1\) 直接用 \(U<2T\)、对数差不超过 \(L_j\)，仍得 \(2TL_j\le3TL_j\)。

所有原门及成功筛选都是正限制，因此先保实际 \(\Xi_{\max}\)，再上放到未筛原父及原样本即可使用 (6)。原阶段/历史积分后恰为 \(t(A)\sigma\)，没有 stage 因子。由于 \(\sum_jL_j\le D_*\)，
\[
 \int_{\Xi_{\max}}\log\frac{m_A}{m_{B_*}}
 \le3TD_*W.
\tag{7}
\]
真实匹配关系给
\(n|\log(R_A/R_{B_*})|\le\log(m_A/m_{B_*})+\log r\)。故
\[
 \boxed{\quad
 \int_{\Xi_{\max}}|\log(R_A/R_{B_*})|
 \le\frac{3TD_*}{n}W+\frac{\log r}{n}|\Xi_{\max}|.
 \quad}\tag{8}
\]
再用 \(R\le SX\le SA_nW\)，\(A_n=1+n\log(b/a)\)，右侧至多
\([3TD_*/n+SA_n\log r/n]W=O_{r,S,\tau}(W)\)。这是**实际保留族锚父**的全局加权尺度误差预算，不再是可能被删的 raw 最大父标签。

## 4. 尚未支付的几何连接

(6) 对一个实际极值标签积分消去了 \(b_A^{-k}\) 的重复选择费用，但没有对整个共同核心取得原流下降。即使 \(R_A\) 与 \(R_{B_*}\) 接近，中心仍可相距一个边长，任意集中 \(f\) 也不允许将平移边界体积转成来源质量。\(B_*\) 捕获人工 \(x\) 且排除原 \(y,z\)，不意味着它与 \(A\) 的来源重叠较大。尚缺把这种有偿小尺度误差与**实际中心平移/双来源外部质量的跨父结算**联合起来的估计。没有由 (8) 推出无权 \(|\Xi_{\max}|\) 的根价，也不赋新父原历史。

## 5. 可复现小核验

以下只核质量原子上的最大值公式、闭端点 Stieltjes 估计和概率常数。质量取 \(2^{\text{level}}\)，对数按 \(\log2\) 为单位；不是原生立方体或完整历史实例。

```python
from fractions import Fraction as F
checks=0
profiles=[([0,1],[F(1),F(1)]),([0,2,3],[F(7),F(1,3),F(2)]),([0,1,4,5,7],[F(1,7),F(9),F(2,5),F(3),F(1,11)])]
for levels,weights in profiles:
 U=sum(weights);cum=[];running=F(0)
 for w in weights: running+=w;cum.append(running)
 L=levels[-1]-levels[0]
 for k in (1,2,3,7,17):
  exact=F(0)
  for a,wa in enumerate(weights):
   prev=F(0);total=F(0)
   for b in range(a+1):
    prob=(cum[b]**k-prev**k)/cum[a]**k
    exact+=wa*prob*(levels[a]-levels[b]);total+=prob;prev=cum[b]
   assert total==1;checks+=1
  T=U/(F(k)+F(1,2))
  assert 0<=exact<=3*T*L;checks+=1
  if k>1:
   tail=sum(F(levels[i+1]-levels[i])*cum[i]/(k-1)*(1-(cum[i]/U)**(k-1)) for i in range(len(levels)-1))
   assert exact<=tail<=U*L/(k-1);checks+=1
for H in (F(1),F(2),F(4)):
 for z in (F(3,2),F(5,2),F(7,2),F(15,2)):
  k=z.numerator//z.denominator;alpha=1/(128*H*z)
  if k==1:
   assert 2*H*alpha<=F(1,64);checks+=1
  else:
   bad=F(1,4)+F(1,2**k)+4*(k-1)*alpha+2*H*k*alpha+8*H*alpha
   assert bad<=F(39,64);checks+=1
   assert 8*alpha*k*(k-1)+F(k,4)<F(k,2);checks+=1
print('PASS 15 atomic maximum profiles and 12 success-bound cases;',checks,'Fraction assertions; no native-history claim')
```

实际运行输出：

```text
PASS 15 atomic maximum profiles and 12 success-bound cases; 98 Fraction assertions; no native-history claim
```
