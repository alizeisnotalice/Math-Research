from fractions import Fraction as F
from itertools import product
import json,sys
from pathlib import Path
checks=0
bad=F(1,4)+F(1,4)+F(1,32)+F(1,64)+F(1,16)
assert 1-bad==F(25,64); checks+=1
assert F(1,2)*(1-bad)==F(25,128); checks+=1
assert F(128,25)*F(25,64)==2; checks+=1
for weights in product([1,2,5],repeat=3):
 U=sum(weights); ranks=[]; w=0
 for wi in weights:
  w+=wi;ranks.append(F(w))
 for k in [1,2,3,4,8,16]:
  moment=F(0)
  for i,wi in enumerate(weights):
   prev=F(0)
   for j in range(i+1):
    prob=(ranks[j]**k-prev**k)/ranks[i]**k
    moment+=wi*prob*(i-j)
    prev=ranks[j]
  bound=F(2*U) if k==1 else F(2*U,k-1)
  assert 0<=moment<=bound;checks+=1
for k in range(1,257):
 assert F(k-1,16)+F(k,4)<F(k,2);checks+=1
 if k>=2:
  assert F(k+1,k-1)<=3;checks+=1
out={'python':sys.executable,'python_version':sys.version,'checks':checks,'method':'Fraction exact rational arithmetic','bad_probability':str(bad),'success':str(1-bad),'atom_distributions':27,'k_values':[1,2,3,4,8,16],'scope':'finite scalar consistency checks only; no original history or general theorem certified'}
open(Path(__file__).with_suffix('.json'),'w').write(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False))
