from fractions import Fraction as F
from pathlib import Path
import sys,platform,json,time
import sympy as sp
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=240
start=time.perf_counter();append_only='--append-high' in sys.argv
prior=json.loads((ROOT/'r478_numeric.json').read_text()) if append_only else None
checks=prior['checks'] if append_only else 0

def ck(v):
 global checks
 assert v
 checks+=1

def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator

def sv(v):return str(v)
if not append_only:
 # General obstruction: 1+sqrt(n)+log r >256 r is necessary.
 r=sp.symbols('r',positive=True)
 ck(sp.diff(sp.log(r)-256*r,r)==1/r-256)
 ck(F(1)-256==-255)
 ck(255**2==65025)
 # Bernoulli lower bound: (1-2eta/R)^(n-1)>=1-2eta(n-1), R>=1.
 # Integral plus plateau then has lower bound 1-delta+(1-delta+delta/n)L.
 # Check exact actual shell primitive derivatives in small dimensions only.
 R=sp.symbols('R',positive=True)
 for n in [1,2,4]:
  eta=sp.Rational(1,2*10**8*n)
  prim=n*sp.log(R)
  for k in range(1,n):prim-=sp.Rational(n,k)*sp.binomial(n-1,k)*(-2*eta)**k*R**(-k)
  ck(sp.cancel(sp.diff(prim,R)-n*(R-2*eta)**(n-1)/R**n)==0)

cases=prior['cases'][:] if append_only else []
parameters=[('initial',1,True),('initial',16,True),('near_threshold_pressure',256,True),('sharp_empty_pressure',65025,True),('first_dimension_nonempty',65026,True),('expanded_thin_radius',65536,True),('shell_only_threshold',65536,False),('shell_only_nonempty',65537,False),('native_k2_core',262144,True),('native_k4_core',1048576,True)]
for phase,n,plateau in (parameters[-2:] if append_only else parameters):
 delta=F(1,10**8);eta=delta/(2*n)
 L=arb(n).sqrt();b=(L/n).exp();one=arb(1)
 ck(eta>0);ck(2*eta<1)
 ck(b<2 or n==1) # L=1 at n1 exceeds octave; handled below.
 # For n1 retain one octave and L=log2 rather than impossible e^1.
 if n==1:L=arb(2).log();b=arb(2)
 ck(b<=2);ck(b>1)
 # Exact endpoints establish every selected cube contains core and stays
 # inside base support: a-R/2<=-eta and a+R/2<=b-eta for |a|<=b/2-eta.
 # Same coordinate bounds apply in every dimension.
 ck(F(1,2)-eta>0)
 radial_factor=1-ar(delta)+ar(delta/n)
 lower=radial_factor*L;upper=L
 if plateau:lower+=1-ar(delta);upper+=1
 ck(lower>0);ck(upper>lower)
 # Actual quantities use logarithms to avoid exponentiating tiny volumes.
 outer_side=b-2*ar(eta);base_side=2*(b-ar(eta));core_side=ar(2*eta)
 logW=n*base_side.log();logcore=n*core_side.log()
 logX=n*outer_side.log()
 if not plateau:
  # Remove the entire central fixed-radius cube from E.
  ratio=((1-2*ar(eta))/outer_side)**n
  ck(ratio<1);logX+=(1-ratio).log()
 logXW=logX-logW
 log_coreflow_X_lower=logcore+lower.log()-logX
 log_coreflow_X_upper=logcore+upper.log()-logX
 if upper<=256:status='ALL SOURCES HIGH-GATE EMPTY (global D<=core maximum<=256)';ck(upper<=256)
 elif lower>256:status='POSITIVE L1 CORE SATISFIES STRICT u>256';ck(lower>256)
 else:status='BRACKET UNDECIDED'
 if n in (65026,65537) or (n==65536 and plateau):ck(lower>256)
 if n==65025 or (n==65536 and not plateau):ck(upper<=256)
 # For moderate n independently evaluate exact expanded shell integral.
 exactsmall=None
 if n<=16:
  from math import comb
  shell=n*b.log()
  for k in range(1,n):shell+=ar(-F(n*comb(n-1,k),k)*(-2*eta)**k)*(b**(-k)-1)
  actual=shell+((1-2*ar(eta))**n if plateau else 0)
  if n==1:ck((actual-lower).contains(0))
  else:ck(actual>lower)
  ck(actual<upper)
  exactsmall=sv(actual)
 guaranteed_k=0
 if n in (262144,1048576):
  for kk in range(1,10):
   if lower>=256*kk and upper<256*(kk+1):guaranteed_k=kk;break
  ck(guaranteed_k>0)
 if n==262144:ck(guaranteed_k==2)
 if n==1048576:ck(guaranteed_k==4)
 cases.append(dict(phase=phase,n=n,plateau=plateau,eta=str(eta),delta=str(delta),t='1 STATIC ONLY',S='1',q='1',r='1',actual_mass='R^n (complete uniform L1 source density)',L=sv(L),selected_R_min='1',selected_R_max=sv(b),mass_band='[1, exp(L)]',D_core_lower=sv(lower),D_core_upper=sv(upper),small_n_actual_D_core=exactsmall,saturation_gap_upper=sv(upper-lower),strict_high_gate_status=status,log10_W=sv(logW/arb(10).log()),log10_R_upper_X=sv(logX/arb(10).log()),log10_core_contribution_upper=sv((logcore+upper.log())/arb(10).log()),log10_X_over_W=sv(logXW/arb(10).log()),log10_core_source_mass_over_W=sv((logcore-logW)/arb(10).log()),log10_core_flow_over_X_lower=sv(log_coreflow_X_lower/arb(10).log()),log10_core_flow_over_X_upper=sv(log_coreflow_X_upper/arb(10).log())))
 if n in (262144,1048576):cases[-1]['guaranteed_core_k_floor_u_over_256']=guaranteed_k
result=dict(scope='Ten fixed real continuous cube-selector fields. Complete finite uniform L1 f, static t=S=1. No original high-Z, stage or history certification.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r478_numeric.py',seconds=time.perf_counter()-start),checks=checks,cases=cases,exactness='Rational delta/eta; exact sqrt/log/exp formulas for L/b enclosed by Arb, symbolic small-n primitive derivatives and exact Bernoulli inequalities; 240-bit Arb enclosures of logs/exp and dimension thresholds. Large n is a formula-defined actual field, no discretization or massive array.')
(ROOT/'r478_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'checks;10 continuous formula-defined fields; high-n Bernoulli/Arb certificates, no history claim')
