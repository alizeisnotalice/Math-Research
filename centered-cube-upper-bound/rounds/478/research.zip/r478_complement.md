# R478：保最大父的原来源命中修复

本稿只证明父边缘截断与最大样本的命中收据。最大父的亲和行资格、其余样本删行及质量间距由本轮几何稿另证；这里不将窄边长比或排序本身记为全局付款。

## 1. 原场与不重建的辅助核

沿 `/tmp/r477_main.md`，原完整记录为 \(\Pi\)，其三元投影为
\[
\ell(A,y,z)\,\sigma(dA)\pi_A(dy)\pi_A(dz),\qquad 0\le\ell\le S,
\]
父边缘为 \(t(A)\sigma(dA)\)。所有阶段、时钟、两来源和未来门已经包含于原记录。附加 \(x\sim\pi_A\) 后，仍用原来的全部质量带及 \(u_j,P_{x,j}\)，不因随后删父而重建它们。记 \(r=\lambda/q\)，\(\mathcal M\le NW\)。

若 \(S=0\)，原流为零。以下 \(0<\tau\le S\)，置
\[
H=\max(1,S/\tau),\quad T=1024rSH,
\quad k_j(x)=\lfloor u_j(x)/T\rfloor.
\tag{1}
\]
先限制 \(u_j>T\)，并保原闭秩 \(\beta_j(A,x)=P_{x,j}\{m_B\le m_A\}\ge1/2\)。最后再删 \(t(A)<\tau\)。删父价格至多 \(\tau X\)，而不是每带再付一次。若 \(R_{\rm high}\) 为原高带流，剩余质量 \(R_0\) 满足
\[
R_0\ge \tfrac12R_{\rm high}-\tau X,
\qquad R\le R_{\rm high}+T\mathcal M.
\tag{2}
\]
闭CDF半量用于删父之前的原分布；删父后的分布不再被错误地称为 \(P_{x,j}\)。若 \(\tau>S\)，可直接全舍 \(R\le SX\le\tau X\)，无须下面构造。

## 2. 最大父仍排斥两条原来源的价格

固定保留的 \((A,x,j)\)，取 \(k=k_j(x)\ge1\) 个独立
\[
Q_{A,x,j}(dB)=\beta_j(A,x)^{-1}
 1_{m_B\le m_A}P_{x,j}(dB)
\]
样本。选质量最大的样本 \(B_*\)，并用独立连续标记破同质量并列（下述支配对任何可测破并列规则都成立）。对于任意可测集合，选中样本属于该集合蕴含至少一个样本属于它，故
\[
\mathcal L(B_*\mid A,x,j)\le kQ_{A,x,j}.
\tag{3}
\]
这包括任意质量原子，不需要连续秩。

在固定 \(A,x\) 下，两条旧来源的条件密度仍是 \(\ell(A,y,z)/t(A)\)，相对于 \(\pi_A^2\)；附加 \(x\) 未改变它。因 \(t(A)\ge\tau\)，该密度至多 \(S/\tau\)。样本选择只依 \(A,x\) 和辅助样本，不先依旧 \(y,z\) 筛选。于是对任何这样的样本父 \(B\)，
\[
\Pr(y\in Q_B\ \text{或}\ z\in Q_B\mid A,x,B)
 \le \frac{2S}{\tau}\frac{I_{AB}}{m_A},
\qquad I_{AB}=\mu(Q_A\cap Q_B).
\tag{4}
\]
原样本均满足 \(m_B\le m_A\)，所以
\(I_{AB}/m_A\le\gamma_{AB}=I_{AB}/\sqrt{m_Am_B}\)。R477 第2节的真实匹配闭秩行界对固定原父 \(A\) 同样适用：
\[
\int\gamma_{AB}Q_{A,x,j}(dB)\le\frac{8rS}{u_j(x)}.
\]
联用(3)–(4)，得到关键的一次条件概率收据
\[
\boxed{\Pr(B_*\text{ 捕获旧 }y\text{ 或旧 }z\mid A,x,j)
 \le \frac{16krS^2}{\tau u_j(x)}\le\frac1{64}.}
\tag{5}
\]
这里保留完整原来源联合分布；不假定接受后两来源独立。也没有赋予 \(B_*\) 原父历史。若再与亲和好事件相交，用无条件于该好事件的联合界/并集界即可；不能条件于它后重新声称样本独立。

因此最大父命中删除至多原 \(R_0\) 的 \(1/64\)。这修复了单用 \(\mathcal L(B_*)\le kQ\) 后沿旧全来源命中收据产生的 \(kW\) 损失：所付的新代价是 \(\tau X\) 和低带阈值从 \(256rS\) 增到 \(T\)，不是每带重新截断父。

若本轮独立几何证明在同一 \(R_0\) 上给最终族正限制 \(\Xi_*\) 满足 \(|\Xi_*|\ge25R_0/64\)，则仅代数恢复为
\[
R\le T\mathcal M+2\tau X+\frac{128}{25}|\Xi_*|
 \le1024rSHNW+2\tau X+\frac{128}{25}|\Xi_*|.
\tag{6}
\]
本稿证明的是(5)，不独立认证式(6)所引用的 \(25/64\) 几何成功率。固定 \(\tau,r,S\)，取 \(L=\sqrt n\) 后 \(N\le1+(\log r+n\log2)/\sqrt n\)，新增来源价是根阶。完整 \(\Xi_*\) 的预算仍需后续联合几何，不能把保住最大父等同于已经支付全余流。

## 3. 窄边长范围的实际边界

单带 \(m\in[M,e^LM]\) 给实际边长区间
\(R_-=(M/\lambda)^{1/n}\)、\(R_+=(e^LM/q)^{1/n}\)。对任意可测选择器，捕获 \(x\) 的中心满足 \(2\|A-x\|_\infty\le R_A\)，故径向正包络给
\[
\int_{J_j}c_A(x)R_A^{-n}dA
\le1+n\log(R_+/R_-)=1+L+\log r.
\]
因此 \(u_j\le S(1+L+\log r)\)。这只是原生容量界；边长比接近1时，径向Jacobian的 \(n\) 仍在。它不能单独把全带费用降为更小阶，也不说明原高带一定非空。本轮采用(5)的条件来源截断修复，没有再展开删后排序距离估计。

## 4. 实际有限核验

指定本机Python执行下列完整脚本，stdout为：

```text
PASS 75 exact Fraction assertions; finite mass/mark algebra only, no native-center or history realization.
```

前48项使用非乘积接受矩阵、同一完整来源质量计算样本质量和旧来源命中，核最大样本测度及密度截断方向；后27项核统一参数的 \(1/64\) 常数。它们是有限来源/质量代数检查，不是连续实际中心选择器或完整原历史构型，严格几何行界仍来自已证R477。

```python
from fractions import Fraction as F
from itertools import product
count = 0
mu = [F(1, 6), F(1, 3), F(1, 2)]
sets = [{0}, {0, 1}, {0, 2}]
m = [sum(mu[i] for i in b) for b in sets]
q = [F(1, 5), F(3, 10), F(1, 2)]
S = F(2)
for mode in range(3):
    ell = [[F((i + 2*j + mode) % 5, 2)
            for j in range(3)] for i in range(3)]
    t = sum(mu[i]*mu[j]*ell[i][j]
            for i in range(3) for j in range(3))
    old = [[mu[i]*mu[j]*ell[i][j]/t
            for j in range(3)] for i in range(3)]
    for k in range(1, 5):
        law = [F(0)]*3
        for seq in product(range(3), repeat=k):
            prob = F(1)
            for b in seq:
                prob *= q[b]
            chosen = max(seq, key=lambda b: m[b])
            law[chosen] += prob
        assert sum(law) == 1
        count += 1
        assert all(law[b] <= k*q[b] for b in range(3))
        count += 1
        hit = sum(law[b]*old[i][j]
                  for b in range(3) for i in range(3) for j in range(3)
                  if i in sets[b] or j in sets[b])
        assert hit <= (2*S/t)*sum(law[b]*m[b] for b in range(3))
        count += 1
        assert sum(law[b]*m[b] for b in range(3)) <= k*sum(q[b]*m[b] for b in range(3))
        count += 1
for S in [F(1, 2), F(1), F(3)]:
    for tau in [S, F(1, 2)*S, F(1, 10)*S]:
        r = F(4, 3)
        H = max(F(1), S/tau)
        T = 1024*r*S*H
        for u in [T + F(1, 7), 2*T, 5*T + F(1, 3)]:
            k = u // T
            assert 16*k*r*S*S/(tau*u) <= F(1, 64)
            count += 1
print(f'PASS {count} exact Fraction assertions; finite mass/mark algebra only, no native-center or history realization.')
```
