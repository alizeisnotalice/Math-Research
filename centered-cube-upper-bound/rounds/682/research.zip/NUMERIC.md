# R682 actual-owner leakage matrices and continuous packing envelope

## Decision

The exact finite cube experiments validate the orientation and both sides of the proposed owner-leak matrix budget, including genuine fractional leakage. They also give exact Schur positivity certificates. This is useful evidence for the operator formulation; it does not establish the missing link from the original key/receiver kernel to an iterated matrix expression.

For the **old parameter a=32n only**, the continuous packing envelope excludes the hard rate `T*=6144√n−(32n)^−n` for every integer `256≤n≤256362`. At `n=256363` the envelope first reaches that rate. Thus the earlier abstract equal-radius graph examples cannot model a common-witness hard core in this dimension range. Above the threshold, this particular packing argument stops excluding hard cores; it does not construct one.

## Six finite rational cube fixtures

For each `n=1,2,3`, set `a=32n`, `c0=1+1/a`, and radii

`(s0,s1,s2,s3)=(1,3/4,1/2,1/4)`.

All centers lie on the first coordinate axis. Start at `y0=0`. Two variants use respectively

- full leak: `y_(i+1)=y_i+c0*s_i*e1`;
- half leak: `y_(i+1)=y_i+s_i*e1`.

Take `Ai=Q(yi,si)` and actual owners `Fi=Bi=Q(yi,si/a)`. Thus `μi=|Fi|=(2si/a)^n`, `di=(2si)^n`, `qi=a^−n`. The code computes exact box-intersection volumes rather than assigning leak flags. All six fixtures have disjoint owners, and the expanded-center admission graph is exactly the adjacent chain `i→i+1`. Admission loads are either zero or `a^−n`, hence at most one. In the first variant `|F_(i+1)\Ai|=μ_(i+1)`; in the second it is exactly `μ_(i+1)/2`.

Define

`χij=1_(i<j)1_(yj∈Q(yi,c0 si))`,

`Pij=χij |Fj\Ai|/di`, `δn=(1+2/a)^n−1`.

The code checks the following with exact `Fraction` arithmetic:

1. Every row sum of P is at most δn.
2. Every column of `μP` is at most its corresponding owner mass μj.
3. For `r=0,...,5`, `μP^r 1≤δn^r U`, `U=Σμi`.
4. The matrix `δn diag(μ)−Pᵀdiag(μ)P` is diagonal with nonnegative exact rational entries, hence positive semidefinite.

The independent telescoping check for the chain is

`μP^r1 = θ^r a^(−nr) Σ_(j≥r)μj` for `r≤3`, and zero for `r≥4`,

where θ is one for full leakage and one half for partial leakage. This checks the matrix powers independently of their multiplication implementation.

| n | δn | full-leak row sums, in order |
|---|---|---|
| 1 | 1/16 | 3/128, 1/48, 1/64, 0 |
| 2 | 65/1024 | 9/65536, 1/9216, 1/16384, 0 |
| 3 | 7057/110592 | 1/2097152, 1/2985984, 1/7077888, 0 |

Half-leak row sums are exactly half the displayed values. For example, in dimension one the full-leak total masses at r=0,1,2,3 are `5/32,3/1024,3/65536,1/2097152`; the half-leak values are `5/32,3/2048,3/262144,1/16777216`.

These are actual finite cube owners with original center admission and unequal radii. The entire four-cube chain has empty common parent intersection, which the code also checks exactly. It is not an eligible strict core or an execution of the original high-threshold loss recursion.

## What the two matrix budgets mean

For a general admissible family, owner disjointness and later radius ordering give the row estimate: admitted later owners outside Ai lie inside the outer cube of radius `(1+2/a)si` and outside Ai, so their total volume is at most `δn di`. Center admission gives the column estimate:

`Σi μi Pij = Σ_(i<j) qi χij |Fj\Ai| ≤ μj Σ_(i<j)qiχij ≤ μj`.

The corresponding general Schur argument is exact. For any vector f,

`(Pf)i²≤(ΣjPij)(ΣjPij f_j²)≤δn ΣjPij f_j²`.

Multiplying by μi and summing gives `||Pf||²_(L²(μ))≤δn ||f||²_(L²(μ))`. Thus the proposed operator has norm at most `√δn` once its two budgets hold. The six finite PSD certificates are consistency checks for this orientation. A masked density correlation from the original complete key integral is a separate expression; no identification with `⟨f,Pg⟩`, no repeated-use independence, and no lower-degree kernel domination is inferred here.

## Actual shared-owner correlation and global stars

An additional one-dimensional rational fixture uses a=32 and `(yi,si)=(0,1),(1/10,9/10),(1,1/2)`, with Fi=Bi. The three small owners are disjoint. Both earlier parents have right endpoint one, and the last owner is centered at one. Consequently each earlier-parent leakage fraction on F2 is exactly one half, while their joint leakage fraction is **one half, not one quarter**. Admission loads are `(0,1/32,1/16)`.

The script partitions the real line at all parent and owner endpoints and computes the exact shared-owner load

`b_j(z)=Σ_(i<j) qi χij 1_(Ai^c)(z)` on Fj.

Here b2 is zero on the left half of F2 and 1/16 on its right half; b0 and b1 vanish on their owners. For every h=1,...,6 the exact total is

`Σj ∫Fj b_j(z)^h dz = (1/64)(1/16)^h ≤ δ1 U = 3/320`.

All six comparisons pass in exact rational arithmetic. This computation confirms that marginal leak probabilities cannot be multiplied, even with original admission and actual disjoint owners. The valid general star proof instead uses pointwise `0≤b_j≤1` from original center admission, hence `b_j^h≤b_j`, followed by the one-edge global budget. It pays δn U once, with no unjustified δn^h factor for a shared star. The chain power contraction concerns a different iterated matrix expression. Neither argument by itself removes the original shared-key/receiver mask.

## Continuous envelope and exact formulas

Fix a common witness z, minimum radius ρ and maximum radius R, and assume disjoint owner density at most one. For each owner point u, common-witness geometry implies `r=||u−z||∞≤c0 si`; with `si≥ρ`, its contribution is at most the envelope density

`[2 max(ρ,r/c0)]^−n` on `r≤c0R`.

The l-infinity radial volume derivative is `n 2^n r^(n−1)`. SymPy explicitly differentiates this volume and integrates the shell density, obtaining

`core rate=c0^n`,

`shell rate=n c0^n log(R/ρ)`,

`total envelope=c0^n[1+n log(R/ρ)]`.

These are envelope equalities, while the original finite-family rate is bounded above by them. A microband `R/ρ=exp(1/n)` has total envelope `2c0^n≈2.06349`, independently of dimension. In particular the equal-radius total is at most `c0^n≈1.03175`, which is far below the frozen hard rate.

Partition owner space a.e. by the signed coordinate attaining the maximum norm, choosing a deterministic tie rule on the null tie sets. There are 2n congruent signed radial face families, each with full envelope capacity

`c0^n[1/(2n)+(1/2)log(R/ρ)]`.

If owner support is restricted to d specified signed radial face families, its total capacity is at most d times that expression. For d coordinate families including both signs, the bound is doubled. This restriction does not permit the original density to be redistributed between faces.

**A signed radial owner face is not the first-violated receiver direction.** A source owner may split across several such radial faces, and these faces are defined relative to the common witness. The restriction becomes useful for the original direction argument only after a structural lemma relating these two partitions. Treating d observed receiver directions as d radial faces would be an additional unproved hypothesis.

## Old-a certified threshold and active-face requirements

Set `R/ρ=n/2`. SymPy verifies the integral identity; Python-flint Arb then evaluates with 192-bit ball arithmetic and strict interval comparisons. The first integer `n≥256` for which the global envelope is not below T* is **256363**.

At n=256362, `envelope/√n−6144` lies in the Arb ball centered at `−0.013467077264475828132853107565719219458834144471` with radius `7.84·10^−49`. At n=256363 it is centered at `0.000553653819679912345650500011821134267328936239` with radius `8.33·10^−49`.

To certify the entire lower interval, rather than merely adjacent samples, use that `c0(n)^n` increases and

`d/dn [n^−1/2+√n log(n/2)] = [log(n/2)+2−1/n]/(2√n)>0` for n≥2.

The tiny correction `(32n)^−n/√n` decreases for n≥256 and is at most the certified ball around `9.29082858843735786969·10^−1004` at n=256. Adding that uniform bound to the n=256362 negative comparison leaves it strictly negative. This proves the same first integer threshold for the actual T*, not just for `6144√n`.

| n | envelope/T* (approx.) | minimum signed radial face families | available |
|---|---:|---:|---:|
| 256 | 0.0130471 | impossible | 512 |
| 65536 | 0.446969 | impossible | 131072 |
| 256362 | 0.9999978081 | impossible | 512724 |
| 256363 | 1.0000000901 | 512726 | 512726 |
| 262144 | 1.01312954 | 517494 | 524288 |
| 1048576 | 2.26464194 | 926042 | 2097152 |
| 16777216 | 10.96563389 | 3059963 | 33554432 |

Each integer face requirement is certified by the two inequalities `(d−1)face_capacity<T*≤d face_capacity`; no floating ceiling is used. Near the threshold essentially every radial face is required. These are necessary capacities in a continuous relaxation, not constructions of finite original families.

## Preliminary simple free-a scalar contraction certificate

This branch changes the original construction parameter to

`a_n=1024 n²(9n)^n`, with `Λ=n^n`.

It requires reconstructing all original owners at the new parameter. The actual small-box fixtures and the threshold 256363 above retain a=32n; that threshold is not asserted for the new parameter, and its replacement was not computed.

The general proof is algebraic. For a≥4n, finite binomial domination by a geometric series gives

`δ(a)=(1+2/a)^n−1 ≤ Σ_(r≥1)(2n/a)^r ≤4n/a`.

SymPy verifies the exact identities

`a_n/[n Λ 9^n]=1024n`,

`4nΛ/a_n=1/[256n9^n]`.

Hence `√(δΛ)≤1/(16√n3^n)`. For n≥256, `k=ceil(128√n)≤129√n` and `T=6144√n−a^−n≥6143√n`. Therefore

`α=√(δΛ) k(k−1)/T ≤(16641/98288)3^−n <3^−n/4`.

The scalar comparison is exact: `1/4−16641/98288=7931/98288>0`. For k≥2 the terminal factor obeys

`α^(k−1)3^n/T ≤4^(−(k−1))3^(−n(k−2))/T ≤1/(4T)`.

The proof holds throughout the stated range. Bounded sanity checks at n=256,257,1024,256363 compute the exact integer k using integer square roots, verify the exact rational sample coefficient `k(k−1)/(98288n)<1/4`, and certify the logarithmic upper bounds with 192-bit Arb. No enormous a or a^−n is built, and no subtraction is used to evaluate the tiny δ. Sample log bounds and symbolic identities are retained in RESULT.json. Every check passed.

This certificate pays the scalar loss **if** the proposed endpoint density bridge has already delivered the factor `√(δΛ)` for the complete original kernel. Parameter algebra alone does not prove that bridge, remove a shared-owner correlation, or justify replacing the fixed complete kernel by a matrix expression.

## Stronger direct-leak parameter certificate

For direct leakage payment use the distinct parameter

`a_direct=1024 n²(9n)^n B^(2k)`, `B=3(n+1)^n`, `k=ceil(128√n)`.

The earlier simple free-a parameter remains a preliminary scalar certificate. All original owners must be rebuilt at a_direct for this branch. The old-a cube fixtures and old-a packing threshold are separate.

The same general δ bound now yields

`δΛ≤1/[256n9^n B^(2k)]`,

`α≤(16641/98288)3^−n B^−k`.

The separately proved whole-key envelope is the input

`D_r≤3^n U [Nτ]^(r−1)/r!`, `N=(n+1)^n`.

Because `τ=16384√n` and `T≥6143√n`, the exact comparison `16384/6143<3` gives `Nτ/T≤B`. Consequently

`F_(k−1)≤(3^n U/T) B^(k−2)`.

SymPy verifies the complete cancellation, rather than evaluating enormous parameters:

`[(16641/98288)3^−n B^−k] [(3^n U/T)B^(k−2)]`

`=(16641/98288) U/(TB²) < U/(4TB²)`.

This pays the complete normalized degree-k leakage directly, provided the independently proved masked leakage inequality and whole-key envelope apply. The clean degree-k term remains to be paid. The scalar computation does not itself prove either input.

Bounded 192-bit Arb checks at n=256,257,1024,256363 retain log B, log a_direct, log α_upper and log(normalized_leak_upper*T/U). The ratio to `U/(4TB²)` is certified below one by the same exact coefficient comparison. No astronomical a_direct, a_direct^−n, cancellation-prone δ, or geometric grid is constructed. The proof applies to the arbitrary geometric grid through its analytic inputs; these finite samples are sanity checks only. All exact cancellation and interval checks passed.

## Reproducibility

Command:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r682-20261116/NUMERIC.py
```

RESULT.json records Python, SymPy and python-flint versions, platform, source hash, all six exact matrices, their Schur certificates, exact powers, certified intervals, and input ranges. Final script SHA-256: `23d61d95864764d9019278a4174a2a9867be7ec8bc56657323e1de944a280b05`. Result SHA-256: `ae252e739a0d148c68516ef0bb9bd2c86ca2b13888f0eb863b6dcbd02647a4fb`. The final run finished in about 0.15 seconds, all assertions passed, errors are empty, and the Python process exited with code zero. No packages were installed, and no MATLAB, PDF, Git, or child agent was used.
