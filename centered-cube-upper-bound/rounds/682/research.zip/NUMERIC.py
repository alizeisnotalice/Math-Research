#!/usr/bin/env python3
"""R682 exact actual small-box matrices plus certified continuous owner envelope."""
from fractions import Fraction as Q
from pathlib import Path
from math import prod,isqrt
import hashlib,json,sys,time,platform
import sympy as sp
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
started=time.time();ctx.prec=192

def volume(box):return prod((hi-lo for lo,hi in box),start=Q(1))
def intersect(A,B):return prod((max(Q(0),min(a1,b1)-max(a0,b0)) for (a0,a1),(b0,b1) in zip(A,B)),start=Q(1))
def box(y,s):return [(v-s,v+s) for v in y]
def mv(mu,P):return [sum((mu[i]*P[i][j] for i in range(len(mu))),Q(0)) for j in range(len(mu))]
def strings(x):
 if isinstance(x,Q):return str(x)
 if isinstance(x,list):return [strings(v) for v in x]
 if isinstance(x,dict):return {k:strings(v) for k,v in x.items()}
 return x
models=[]
for n in (1,2,3):
 a=32*n;c0=1+Q(1,a);delta=(1+Q(2,a))**n-1;s=[Q(1),Q(3,4),Q(1,2),Q(1,4)]
 for variant in ('fully_outside','half_outside'):
  step=c0 if variant=='fully_outside' else Q(1)
  y=[[Q(0)]*n]
  for i in range(3):y.append([y[-1][0]+step*s[i]]+[Q(0)]*(n-1))
  A=[box(y[i],s[i]) for i in range(4)];F=[box(y[i],s[i]/a) for i in range(4)]
  mu=[volume(v) for v in F];di=[(2*v)**n for v in s];q=[mu[i]/di[i] for i in range(4)];U=sum(mu,Q(0))
  disjoint=all(intersect(F[i],F[j])==0 for i in range(4) for j in range(i+1,4));assert disjoint
  chi=[[int(i<j and all(abs(y[j][t]-y[i][t])<=c0*s[i] for t in range(n))) for j in range(4)] for i in range(4)]
  assert chi==[[int(j==i+1) for j in range(4)] for i in range(4)]
  loads=[sum((q[i]*chi[i][j] for i in range(4)),Q(0)) for j in range(4)];assert all(v<=1 for v in loads)
  leak=[[chi[i][j]*(mu[j]-intersect(F[j],A[i])) for j in range(4)] for i in range(4)]
  frac=Q(1) if variant=='fully_outside' else Q(1,2)
  assert all(leak[i][j]==frac*mu[j]*chi[i][j] for i in range(4) for j in range(4))
  P=[[leak[i][j]/di[i] for j in range(4)] for i in range(4)]
  row=[sum(v,Q(0)) for v in P];assert all(v<=delta for v in row)
  schur=[[delta*mu[j]*int(j==l)-sum((mu[i]*P[i][j]*P[i][l] for i in range(4)),Q(0)) for l in range(4)] for j in range(4)]
  assert all(schur[j][l]==0 for j in range(4) for l in range(4) if j!=l)
  assert all(schur[j][j]>=0 for j in range(4))
  col=mv(mu,P);assert all(col[j]<=mu[j] for j in range(4))
  powers=[];cur=mu
  for r in range(6):
   total=sum(cur,Q(0));budget=delta**r*U
   assert total<=budget
   # The telescoping exact chain formula independently checks matrix multiplication.
   direct=frac**r*Q(1,a)**(n*r)*sum(mu[r:],Q(0)) if r<4 else Q(0)
   assert total==direct
   powers.append({'r':r,'mu_P_r_ones':total,'delta_r_U':budget,'ratio_to_budget':total/budget,'row_contraction_passed':True})
   cur=mv(cur,P)
  globalI=A[0]
  common_volume=prod((max(Q(0),min(B[t][1] for B in A)-max(B[t][0] for B in A)) for t in range(n)),start=Q(1))
  assert common_volume==0
  models.append(strings({'n':n,'variant':variant,'a':a,'c0':c0,'delta_n':delta,'radii':s,'centers':y,'mu':mu,'d_i':di,'q_i':q,'U':U,'chi':chi,'admission_loads':loads,'owner_leak_volumes':leak,'P':P,'row_sums':row,'Schur_PSD_certificate_delta_diag_mu_minus_PT_diag_mu_P':schur,'Schur_PSD_exact_diagonal_nonnegative':True,'mu_P':col,'powers':powers,'owners_disjoint':disjoint,'common_parent_intersection_volume':common_volume,'scope':'Actual finite cube owners and admission; no full-chain common witness, strict cores, or original high-threshold recursion.'}))
# Actual shared-owner correlation: both earlier parents end at the same boundary.
a=32;cc=1+Q(1,a);ss=[Q(1),Q(9,10),Q(1,2)];yy=[Q(0),Q(1,10),Q(1)]
AA=[box([yy[i]],ss[i]) for i in range(3)];FF=[box([yy[i]],ss[i]/a) for i in range(3)]
mm=[volume(v) for v in FF];dd=[2*v for v in ss];qq=[mm[i]/dd[i] for i in range(3)]
assert all(intersect(FF[i],FF[j])==0 for i in range(3) for j in range(i+1,3))
ch=[[int(i<j and abs(yy[j]-yy[i])<=cc*ss[i]) for j in range(3)] for i in range(3)]
load=[sum((qq[i]*ch[i][j] for i in range(3)),Q(0)) for j in range(3)]
assert all(v<=1 for v in load)
leakfr=[(mm[2]-intersect(FF[2],AA[i]))/mm[2] for i in (0,1)]
endpoints=sorted(set([v for B in AA+FF for v in B[0]]));cells=[];star=[Q(0)]*6;joint=Q(0)
for left,right in zip(endpoints,endpoints[1:]):
 mid=(left+right)/2
 for j in range(3):
  if not FF[j][0][0]<mid<FF[j][0][1]:continue
  b=sum((qq[i]*ch[i][j]*int(not AA[i][0][0]<mid<AA[i][0][1]) for i in range(3)),Q(0))
  assert b<=1
  for h in range(1,7):star[h-1]+=(right-left)*b**h
  cells.append({'owner':j,'left':left,'right':right,'b':b})
  if j==2 and all(not AA[i][0][0]<mid<AA[i][0][1] for i in (0,1)):joint+=right-left
assert leakfr==[Q(1,2),Q(1,2)] and joint/mm[2]==Q(1,2)
assert joint/mm[2]!=leakfr[0]*leakfr[1]
delta=Q(1,16);UU=sum(mm,Q(0));assert all(v<=delta*UU for v in star)
assert star==[mm[2]/2*Q(1,16)**h for h in range(1,7)]
shared=strings({'n':1,'a':a,'centers':yy,'radii':ss,'mu':mm,'q':qq,'chi':ch,'admission_loads':load,'owner2_two_leak_fractions':leakfr,'owner2_joint_leak_fraction':joint/mm[2],'product_of_marginal_leak_fractions':leakfr[0]*leakfr[1],'endpoint_cells':cells,'star_moments_h1_to_h6':star,'delta_U':delta*UU,'star_budget_passed':True,'proof_route':'b_j<=1 by original center admission, so b_j^h<=b_j; integrate and use the global one-edge row budget, not a product of marginal leak probabilities.','scope':'Actual disjoint owners and admission; shared endpoint star only, no strict core or original high-threshold recursion.'})
# Symbolic radial calculation, rho<R. Differentiate exact l-infinity cube volume.
r,c,rho,R,nn=sp.symbols('r c rho R n',positive=True)
radial=sp.simplify(sp.diff((2*r)**nn,r)/(2*r/c)**nn)
assert sp.simplify(radial-nn*c**nn/r)==0
shell=sp.integrate(nn*c**nn/r,(r,rho*c,R*c))
assert sp.simplify(shell-nn*c**nn*sp.log(R/rho))==0
# Certified Arb envelope thresholds. No conversion through floating point.
def cpower(n):return (arb(1)+arb(1)/(32*n))**n
def eps(n):return (-arb(n)*(arb(32)*n).log()).exp()
def cap(n):return cpower(n)*(1+arb(n)*(arb(n)/2).log())
def target(n):return 6144*arb(n).sqrt()-eps(n)
def ratio_base(n):return cap(n)/arb(n).sqrt()
def reaches0(n):
 v=ratio_base(n)-6144
 assert v>0 or v<0
 return v>0
lo=256;hi=512
while not reaches0(hi):hi*=2
while hi-lo>1:
 mid=(lo+hi)//2
 if reaches0(mid):hi=mid
 else:lo=mid
threshold=hi
assert hi==lo+1 and cap(hi)>target(hi)
# ratio_base is strictly increasing n>=2; eps(n)/sqrt(n)<=eps(256)/16 on n>=256.
# This certifies all smaller n, not just the immediately preceding integer.
below_uniform=ratio_base(lo)-6144+eps(256)/16
assert below_uniform<0
samples=[]
for n in sorted(set((256,4096,65536,threshold-1,threshold,262144,1048576,16777216))):
 C=cap(n);T=target(n);face=C/(2*n)
 # Find minimal signed faces using interval comparisons only, capped at 2n+1=impossible.
 left=0;right=2*n+1
 while right-left>1:
  m=(left+right)//2
  if m*face>=T:right=m
  else:
   assert m*face<T
   left=m
 need=right
 if need<=2*n:assert need*face>=T and (need-1)*face<T
 samples.append({'n':n,'global_envelope':str(C),'shell_only_envelope':str(C-cpower(n)),'target_Tstar':str(T),'global_over_target':str(C/T),'single_signed_radial_face_capacity':str(face),'minimum_signed_face_families':need if need<=2*n else None,'available_signed_face_families':2*n,'packing_excludes_hard_rate':bool(C<T),'microband_lambda_exp_1_over_n_capacity':str(2*cpower(n))})
# Free-a branch: general rational algebra, separate from the old-a geometric fixtures.
coef=Q(16641,98288);assert coef<Q(1,4)
z=sp.symbols('z',positive=True,integer=True)
aa=1024*z**2*(9*z)**z
identity=sp.powsimp(aa/(z*z**z*9**z),force=True)
assert sp.simplify(identity-1024*z)==0
variance_bound=sp.powsimp(4*z*z**z/aa,force=True)
assert sp.simplify(variance_bound-1/(256*z*9**z))==0
parameter_samples=[]
for n in (256,257,1024,256363):
 kk=isqrt(16384*n)
 if kk*kk<16384*n:kk+=1
 assert kk>=2 and kk*kk>=16384*n and (kk-1)**2<16384*n
 # Exact k bound and exact coefficient, with no floating square root.
 assert kk*kk<=16641*n
 exact_coef=Q(kk*(kk-1),98288*n)
 assert exact_coef<=coef<Q(1,4)
 loga=arb(1024).log()+2*arb(n).log()+n*(9*arb(n)).log()
 log_alpha_bound=arb(exact_coef.numerator).log()-arb(exact_coef.denominator).log()-n*arb(3).log()
 log_alpha_over_quarter3=arb(4*exact_coef.numerator).log()-arb(exact_coef.denominator).log()
 assert log_alpha_over_quarter3<0
 terminal_log_ratio=-(kk-2)*(n*arb(3).log()+arb(4).log())
 assert terminal_log_ratio<0
 parameter_samples.append({'n':n,'k_ceil_128sqrt_n':kk,'log_a':str(loga),'sample_alpha_coefficient_before_3_to_minus_n':str(exact_coef),'log_alpha_upper':str(log_alpha_bound),'log_alpha_upper_over_quarter_times_3_to_minus_n':str(log_alpha_over_quarter3),'log_terminal_upper_over_1_over_4T':str(terminal_log_ratio)})
free_a={'scope':'PRELIMINARY simple free-a parameter algebra certificate; superseded for direct leakage payment by direct_a_parameter_certificate. Requires rebuilding all original owners with this new a; six cube fixtures and envelope threshold above retain old a=32n. No masked density bridge is proved by this scalar certificate.','a_formula':'1024*n^2*(9*n)^n','Lambda_formula':'n^n','exact_scalar_coefficient':str(coef),'quarter_minus_coefficient':str(Q(1,4)-coef),'exact_coefficient_less_than_quarter':True,'symbolic_a_over_n_Lambda_9n':str(identity),'symbolic_delta_Lambda_upper':str(variance_bound),'general_derivation':['a>=4n; binomial coefficients bound (1+2/a)^n-1 <= sum_(r>=1)(2n/a)^r <= 4n/a.','delta*Lambda <= 1/(256*n*9^n), hence sqrt(delta*Lambda) <= 1/(16*sqrt(n)*3^n).','For n>=256: k=ceil(128sqrt(n)) <=129sqrt(n); a^-n<=1<=sqrt(n), so T>=6143sqrt(n).','alpha <= [16641/98288]*3^-n < (1/4)*3^-n.','For k>=2: alpha^(k-1)*3^n/T <= 4^(-(k-1))*3^(-n*(k-2))/T <= 1/(4T).'],'terminal_normalized_ratio_bound':'4^(2-k)*3^(-n*(k-2)) <= 1 for k>=2','samples':parameter_samples,'arithmetic_note':'No giant a, a^-n, delta subtraction, or giant rational power is constructed. All scalar comparisons are exact Fraction; displayed log bounds use 192-bit Arb.'}
# Stronger direct-leak parameter: the earlier free-a certificate remains preliminary.
assert Q(16384,6143)<3
BB,KK,TT,UU=sp.symbols('B k T U',positive=True)
ccsym=sp.Rational(16641,98288)
alpha_expr=ccsym*3**(-z)*BB**(-KK)
key_expr=3**z*UU/TT*BB**(KK-2)
cancelled=sp.powsimp(alpha_expr*key_expr,force=True)
assert sp.simplify(cancelled-ccsym*UU/(TT*BB**2))==0
direct_samples=[]
for n in (256,257,1024,256363):
 kk=isqrt(16384*n)
 if kk*kk<16384*n:kk+=1
 logB=arb(3).log()+n*arb(n+1).log()
 loga0=arb(1024).log()+2*arb(n).log()+n*(9*arb(n)).log()
 loga=loga0+2*kk*logB
 logc=arb(16641).log()-arb(98288).log()
 logalpha=logc-n*arb(3).log()-kk*logB
 logleak_times_T_over_U=logc-2*logB
 logratio_to_quarter=arb(16641).log()-arb(24572).log()
 assert loga>loga0 and logratio_to_quarter<0
 direct_samples.append({'n':n,'k':kk,'log_B':str(logB),'log_a_direct':str(loga),'log_alpha_upper':str(logalpha),'log_normalized_leak_upper_times_T_over_U':str(logleak_times_T_over_U),'log_leak_upper_over_U_over_4TB2':str(logratio_to_quarter)})
direct_a={'scope':'Direct payment scalar certificate conditional on independently proved whole-key envelope and complete masked leakage inequality. The degree-k clean term remains. No arbitrary geometric grid is enumerated or replaced by samples.','a_direct':'1024*n^2*(9*n)^n*B^(2*k)','B':'3*(n+1)^n','k':'ceil(128*sqrt(n))','preliminary_parameter':'1024*n^2*(9*n)^n, retained separately above','delta_Lambda_upper':'1/(256*n*9^n*B^(2*k))','alpha_upper':'(16641/98288)*3^(-n)*B^(-k)','whole_key_envelope_input':'D_r <= 3^n*U*(N*tau)^(r-1)/r!, N=(n+1)^n; independently proved outside this numeric certificate','exact_tau_T_ratio_bound':str(Q(16384,6143)),'tau_T_ratio_less_than_3':True,'degree_kminus1_input':'F_(k-1) <= (3^n*U/T)*B^(k-2)','symbolic_cancelled_product':str(cancelled),'direct_normalized_leak_bound':'(16641/98288)*U/(T*B^2) < U/(4*T*B^2)','exact_margin_to_one_quarter':str(Q(1,4)-coef),'samples':direct_samples,'arithmetic_note':'Exact SymPy cancellation and Fraction comparisons; 192-bit Arb log-domain sample checks. No astronomical a_direct, delta subtraction, grid, or giant power is constructed.'}
out={'scope':'Six actual rational finite-owner matrix fixtures, separately a continuous packing envelope. Neither implements strict-core high-threshold original recursion. Max-radial owner faces are not receiver directions.','python':sys.version,'platform':platform.platform(),'sympy_version':sp.__version__,'python_flint_version':flint.__version__,'arb_precision_bits':ctx.prec,'command':[sys.executable,str(Path(__file__).resolve())],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'arithmetic':{'matrix':'Exact fractions.Fraction','envelope':'Symbolic SymPy identity, then 192-bit Arb ball arithmetic with strict sign comparisons'},'matrix_models':models,'shared_owner_correlation':shared,'symbolic':{'radial_integrand':str(radial),'shell_integral':str(shell),'global_formula':'c0^n [1+n log(R/rho)]','signed_face_formula':'c0^n [1/(2n)+(1/2) log(R/rho)]','window':'R/rho=n/2','microband':'R/rho=exp(1/n), global=2*c0^n'},'direct_a_parameter_certificate':direct_a,'free_a_parameter_certificate':free_a,'threshold':{'parameter_scope':'OLD a=32n only; new free-a envelope threshold is not computed','first_n_ge_256_not_excluded_by_global_packing':threshold,'at_previous_integer_ratio_minus_6144':str(ratio_base(lo)-6144),'at_threshold_ratio_minus_6144':str(ratio_base(hi)-6144),'uniform_small_n_epsilon_bound_used':str(eps(256)/16),'previous_ratio_with_uniform_epsilon':str(below_uniform),'monotonicity_proof':'c0(n)^n strictly increasing: log(1+x)-x/(1+x)>0; derivative of n^(-1/2)+sqrt(n)log(n/2)=[log(n/2)+2-1/n]/(2sqrt(n))>0 for n>=2. epsilon(n)/sqrt(n) decreasing for n>=256.'},'envelope_samples':samples,'all_assertions_passed':True,'errors':[],'elapsed_seconds':time.time()-started}
(ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('script_sha256','threshold','elapsed_seconds','all_assertions_passed')},indent=2))
print('RESULT.json sha256',hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest())
