from pathlib import Path
from fractions import Fraction as F
from math import prod
import json,hashlib,re,ast
from flint import arb,ctx
p=Path(__file__).resolve().parent;r=json.loads((p/'RESULT.json').read_text());ctx.prec=224
ast.parse((p/'NUMERIC.py').read_text());assert hashlib.sha256((p/'NUMERIC.py').read_bytes()).hexdigest()==r['script_sha256']
assert r['all_assertions_passed'] and not r['errors'] and len(r['matrix_models'])==6
for z in r['matrix_models']:
 n=z['n'];a=z['a'];s=list(map(F,z['radii']));y=[[F(t) for t in yy] for yy in z['centers']];mu=list(map(F,z['mu']));d=list(map(F,z['d_i']));P=[[F(t) for t in row] for row in z['P']];delta=(1+F(2,a))**n-1
 for i in range(4):
  assert mu[i]==(2*s[i]/a)**n and d[i]==(2*s[i])**n
  for j in range(4):
   gate=i<j and all(abs(y[i][t]-y[j][t])<=(1+F(1,a))*s[i] for t in range(n))
   overlap=prod(max(F(0),min(y[j][t]+s[j]/a,y[i][t]+s[i])-max(y[j][t]-s[j]/a,y[i][t]-s[i])) for t in range(n))
   assert P[i][j]==int(gate)*(mu[j]-overlap)/d[i]
 assert all(sum(row)<=delta for row in P)
 assert all(sum(mu[i]*P[i][j] for i in range(4))<=mu[j] for j in range(4))
 cur=mu[:]
 for h,stored in enumerate(z['powers']):
  assert sum(cur)==F(stored['mu_P_r_ones'])<=delta**h*sum(mu)
  cur=[sum(cur[i]*P[i][j] for i in range(4)) for j in range(4)]
 cert=[[delta*mu[j]*(j==l)-sum(mu[i]*P[i][j]*P[i][l] for i in range(4)) for l in range(4)] for j in range(4)]
 assert all(cert[j][j]>=0 for j in range(4)) and all(cert[j][l]==0 for j in range(4) for l in range(4) if j!=l)
z=r['shared_owner_correlation'];assert F(z['owner2_joint_leak_fraction'])==F(1,2)!=F(z['product_of_marginal_leak_fractions'])
for h,x in enumerate(z['star_moments_h1_to_h6'],1):assert F(x)==F(1,64)*F(1,16)**h<=F(z['delta_U'])
def ratio(n):return (arb(1)+arb(1)/(32*n))**n*(1+arb(n)*(arb(n)/2).log())/arb(n).sqrt()
eps256=(-arb(256)*(arb(32)*256).log()).exp()/16
assert ratio(256362)-6144+eps256<0 and ratio(256363)-6144>0
c=F(16641,98288);assert c<F(1,4) and F(16384,6143)<3
# Symbolic cancellation without materializing the enormous free parameter.
import sympy as sp
B,T=sp.symbols('B T',positive=True)
n,k=sp.symbols('n k',integer=True,positive=True)
cc=sp.Rational(16641,98288)
assert sp.simplify((cc*3**(-n)*B**(-k))*(3**n/T*B**(k-2))-cc/(T*B**2))==0
stack=[]
for m in re.finditer(r'\\(begin|end)\{([^}]+)\}',(p/'REPORT.tex').read_text()):
 if m[1]=='begin':stack.append(m[2])
 else:assert stack and stack.pop()==m[2]
assert not stack
if (p/'MANIFEST.json').exists():
 for name,v in json.loads((p/'MANIFEST.json').read_text())['members'].items():
  b=(p/name).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps(dict(passed=True,actual_box_models=6,shared_owner_moments=6,old_parameter_threshold=256363,arb_precision=224,direct_scalar_constant=str(c),scope='independent exact geometry/arithmetic and recorded integrity; not verification of unpaid clean bound')))
