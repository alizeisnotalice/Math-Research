# R682: direct leakage payment, complete clean integral still unpaid

The original all-L1/all-scales/Lebesgue pure C_n<=K sqrt(n) goal remains active and unproved. R682 pays the entire leaking sector of an exact lifted complete key integral; it does NOT pay the remaining clean sector. Read final REPORT + S2 + independent S3.

## Actual advance and required parameter distinction

Free finite entrance is valid for every a>0: Cn<=supfinite V_a/P0, with no a^n fee. Original admission/far/upper/core/cover constructions are revalidated for every a>=32n. Reconstruct all owners, q, recursion, groups, cores,Y at the newly chosen a; NEVER relabel R681's old owners as being in smaller boxes.

n>=256; tau=16384sqrt(n), k=ceil128sqrt(n), N=(n+1)^n, B=3N, Lambda=n^n. Choose once per dimension a=1024n²(9n)^n B^(2k), finite integer. Complexity and number of labels unrestricted. T=3tau/8-a^-n>=6143sqrt(n).

Globalowner operator Pij=1_i<j chiij |Fj\Ai|/di, mu_i=|Fi|, delta=(1+2/a)^n−1: P1<=delta1, muP<=mu, ||P||L2(mu)<=sqrt(delta). This uses real disjoint owners in the true thin enlarged cube, not an arbitrary density cap on f. Shared-owner stars use the SAME owner point; no product independence.

For each complete key m, greedy keep maximum labels and all their occurrences, assigning every deleted i to its actual retained killer pi_m(i). Define omega(m)=product over retained j of |Fj intersect all assigned Ai|/|Fj|. C_r=sum q^m/m! omega(m) integral K_m; L_r=D_r−C_r. Entire original key, deleted parents, real receiver, first core and causal mask retained. Independent keys have omega=1 and lie entirely in C_r.

Union bound, occurrence pair marking and Schur give L_r<=sqrt(delta Lambda)(r−1)D_(r−1). Correct factorial normalization is alpha_r=sqrt(delta Lambda)r(r−1)/T. Do not discard either r factor. Actual owner leak is NOT automatically a Markov path; the proof uses pair marking and two endpoint kernel domination.

A finite perturbed grid of <=N points in Ai stabs every Aj with positive overlap and sj>2si/n. Each point is off ALL parent faces. Thus coeligible source rate <=N tau. Wholehalo H_m subset3Ai and exact occurrence marking give D_r<=3^n U(N tau)^(r−1)/r!. This is a crude ALL-CORE bound with no inputcardinality fee. Do not claim it is itself root order.

At new a, alpha_k<=c*3^-n B^-k with c=16641/98288<1/4. Multiplying the crude normalized D_(k−1) bound gives k! L_k/T^k <=c U/(T B²)<U/4. This is DIRECT payment: no lower-degree clean sum or unpaid terminal is needed.

## Precise remaining task

G_k=k!C_k/T^k. Full account:
V <=(100/97)[G_k+U/(4TB²)],
V0 <=Cadm[U+(Kfar+Kup)U/tau+(100/97)(G_k+U/(4TB²))], P0>=U/tau.

Need genuine uniform G_k<=C U (or another complete packing payment). Keep exact omega and actual same kernel. Do not replace independent/nonadmitted clean keys by empty branch. Clean constraint says each deleted parent contains its assigned root's owner point; it does not say it contains all root points. Distinct retained roots may still have no common center-admission relation. No fresh-cut assumption, no hidden outgoing mass cap, no new graph-only reduction counted as progress.

## Computation and historical scope

NUMERIC uses exact Fraction actual finite cube chains (n1,2,3), shared-owner correlation, SymPy envelope, Arb certificates. Six chain models satisfy real owner/admission hypotheses but not hard strict-core recursion. The OLD-a32n capacity threshold256363 comes from the already known R658 radial envelope, not new global geometry and not a threshold for the new a. Signed radial owner faces are not receiver-violation directions.

Final a cancellations and logs checked at n256,257,1024,256363 without generating huge source families. General proofs are analytic. verify.py independently recomputes geometry,matrixpowers,sharedmoments,oldthreshold,scalarconstants and final integrity. No MATLAB/PDF launched. OneAstra/threeSol maximum; R682 agents stop after delivery. Next completed research round is R683, not another R682 commit.
