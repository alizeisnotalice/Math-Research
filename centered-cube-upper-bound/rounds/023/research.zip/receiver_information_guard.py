"""Finite real-Lebesgue receiver checks; not a uniform weak-type proof.
Midpoint quadrature has an explicit Lipschitz error bound. Float evaluations
of analytic count-tail bounds are not outward-rounded certificates.
"""
from fractions import Fraction as F
from math import exp,log,factorial,comb
from pathlib import Path
import json


def support_checks():
 rows=[]
 for h in [F(1,8),F(1,4),F(1,2)]:
  for eps in [F(1,2),F(1,8),F(1,1024),F(1,2**40)]:
   old=2-h; new=2*(1+eps)-h; x=(old+new)/4; L=2*x+h
   assert 1<L<4 and 2/L<1<2*(1+eps)/L
   assert new-old==2*eps>0
   rows.append(dict(h=str(h),epsilon=str(eps),new_receiver_mass_outside_old=str((new-old)/new),winner=str(L)))
 return rows


def tail(k,j):
 assert j>k
 return exp(-k)*k**j/factorial(j)/(1-k/(j+1))


def count_states(k,J):
 rows=[]; pn=exp(-k)
 for N in range(J+1):
  if N: pn*=k/N
  for i in range(N+1):rows.append((N,i,pn*comb(N,i)*2.0**(-N)))
 return rows


def spatial(k,d,K):
 # mu=.5 delta_(-d/4)+.5 delta_(d/4), a=1,b=2,tau=3/5.
 # Both atoms are in one fixed cell of diameter d. The original true
 # winner captures both, since r_far/r_near<2. Its E is one interval.
 length=5/3-d/2; J=6*k+32; states=count_states(k,J)
 A=B=S=C=0.0; select=0.0
 for j in range(K):
  x=length*((j+.5)/K-.5)
  r0=max(1.0,2*abs(x+d/4));r1=max(1.0,2*abs(x-d/4));rf=max(r0,r1)
  t0=rf/r0 if r0<r1 else 0.0
  t1=rf/r1 if r1<r0 else 0.0
  for N,i,p in states:
   v=max(N,i*t0,(N-i)*t1)/k
   A+=p*v/K
   B+=p*(v*log(v) if v else 0.0)/K
   S+=p*(v-1)**2/K
   C+=p*v*v/K
   if v>N/k+1e-14:select+=p/K
 # The omitted N>J tail has v>=N/k>1 and v<=(1+d)N/k.
 # Hence the same bound controls B and S tails; A uses first moment.
 T2=(k*k*tail(k,J-1)+k*tail(k,J))/(k*k)
 TB=(1+d)**2*T2; TA=(1+d)*tail(k,J)
 # |dv/dx|<=6N/k on E. For finite N<=J use a common log bound.
 L_A=6.0
 L_B=6*(1+log(k)+log((1+d)*J+1))
 L_S=12*((1+d)*(1+1/k)+1)
 err=lambda L:L*length/(4*K)
 # On each half-interval v has at most one peak. Its total variation
 # on the full interval is <=2*d*N/k. Midpoint error <=TV/(2*K).
 bvA=d/K
 bvB=d*(1+log(k)+log((1+d)*J+1))/K
 bvS=2*d*((1+d)*(1+1/k)+1)/K
 # Set V_J=0 on omitted histories: C/A^2-1 is its normalized chi-square.
 kl=B/A-log(A); chi=C/(A*A)-1
 assert A>=1-1e-10 and kl>=-1e-10 and kl<=chi+1e-9
 return dict(kappa=k,delta=d,midpoints=K,count_states=len(states),
             A=A,EVlogV=B,EV_square=C,E_noise_square=S,normalized_truncated_joint_KL=kl,truncated_chi_square=chi,
             reselection_probability=select,omitted_A_bound=TA,omitted_B_and_square_bound=TB,
             midpoint_A_error_bound=min(err(L_A),bvA),midpoint_B_error_bound=min(err(L_B),bvB),
             midpoint_square_error_bound=min(err(L_S),bvS),
             lipschitz_A_bound=err(L_A),lipschitz_B_bound=err(L_B),lipschitz_square_bound=err(L_S))


def main():
 rows=[spatial(k,d,K) for k in [1,4] for d in [1/32,1/128] for K in [128,512,2048]]
 # Convergence checks use proved quadrature envelopes, not fitted accuracy.
 for i in range(0,len(rows),3):
  for u,v in zip(rows[i:i+3],rows[i+1:i+3]):
   for key,ek in [('A','midpoint_A_error_bound'),('EVlogV','midpoint_B_error_bound'),('E_noise_square','midpoint_square_error_bound')]:
    assert abs(u[key]-v[key])<=u[ek]+v[ek]+1e-10
 out=dict(status='PASS finite interface checks',support=support_checks(),spatial=rows,
          scope='genuine 1D Lebesgue E and continuous winners; no high-weak-ratio or nearmax certification; float is not interval arithmetic')
 Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(dict(support_cases=len(out['support']),spatial_cases=len(rows),status=out['status'])))

if __name__=='__main__':main()
