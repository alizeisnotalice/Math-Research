#!/usr/bin/env python3
"""Reproduce the finite diagnostics in r294_transport.md; not a proof."""
from pathlib import Path
import sys

# Use the existing local mpmath installation if it is not on Python's path.
try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0, str(Path('/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')))
    import mpmath as mp

mp.mp.dps = 40
TOL = mp.mpf('1e-35')


def phi(x):
    x = abs(mp.mpf(x))
    half = mp.mpf('.5')
    if x <= half:
        return 1 - mp.expint(3, half - x) - mp.expint(3, half + x)
    return mp.expint(3, x - half) - mp.expint(3, x + half)


def f(s, x):
    return (1 - s) * (abs(x) <= mp.mpf('.5')) + s * phi(x)


def main():
    count = 0
    worst = mp.mpf(0)
    # 5 softnesses x 3 widths x 43 points x 3 shifts = 1935.
    # The two explicit boundary points duplicate grid entries, as in the original run.
    for s in map(mp.mpf, ['0', '0.0009765625', '0.0625', '0.5', '1']):
        for dl in map(mp.mpf, ['0.001', '0.1', '1']):
            points = [mp.mpf(k) / 10 for k in range(-20, 21)]
            points += [mp.mpf('-.5'), mp.mpf('.5')]
            for w in points:
                for u in [-dl / 2, mp.mpf(0), dl / 2]:
                    lhs = f(s, w)
                    rhs = mp.exp(4 * s * dl / (1 + dl)) * f(s, (w - u) / (1 + dl))
                    assert lhs <= rhs + TOL, (s, dl, w, u, lhs, rhs)
                    count += 1
                    if rhs:
                        worst = max(worst, lhs / rhs)
    assert count == 1935

    dimensions = [1, 2, 3, 16, 1024, 1000000]
    scale_pairs = [(mp.mpf(1), mp.mpf(2)),
                   (mp.mpf('1.5'), mp.mpf(1)),
                   (mp.mpf(2), mp.mpf(2))]
    for n in dimensions:
        assert mp.mpf(1) / n < 2 * mp.log1p(mp.mpf(1) / n)
        for L, R in scale_pairs:
            d = mp.mpf(1) / n
            assert mp.sqrt((L + d) * (R + d)) >= mp.sqrt(L * R) + d - TOL
            assert abs(mp.log(L / R)) - abs(mp.log((L + d) / (R + d))) <= d + TOL

    print('PASS soft shift-dilation scalar checks=', count,
          'max ratio=', mp.nstr(worst, 12))
    print('PASS ratio-band width and geometric-scale checks for n through 1000000')
    print('phi(1/2)=', mp.nstr(phi(mp.mpf('.5')), 25),
          'lower bound=', mp.nstr((1 - mp.exp(-1)) / 2, 25))


if __name__ == '__main__':
    main()
