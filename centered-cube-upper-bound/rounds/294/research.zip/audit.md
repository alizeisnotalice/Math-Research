# R294 independent preauthor audit

## Exact original data and independent normalization screen

Written before opening any new R294 author proof. Read R292 low-pe geometry Sections 1--5 and the final R293 column geometry. Fix original outer/terminal data and keep actual x-dependent q,s,L,R,g,j and all source/history masks. The accepted set Z=Z_(j,V)(y,g;q(x)) and full weighted mass e=integral_Z w_(j,g)(y,z)nu(dz) are original quantities. The weight is the original strictly positive product
 w_(j,g)(y,z)=product_i min(1,b C(|y_i-z_i|/b)/(c_j g)),
 C(d)=integral_[-1/2,1/2] max(h,phi)(u-d)du.
Thus 0<w<=1, e<=nu(Z), and e>0 on every retained heavy row. These facts do not localize e to the actual pair parent or hard cube.

The normalization
 dmu_(x,y)(z)=1_Z(z)w(y,z)nu(dz)/e
 is a probability measure for EACH actual row (x,y). It depends on x through q,g,j and the accepted tree threshold; it is not an outer frozen source or a posterior with a conserved original source marginal. For any retained positive pair mask a, the exact identity is
 (p/q)integral_Z h_R(x-z)a nu(dz)
   =(p e/q)integral h_R(x-z)a/w(y,z) dmu_(x,y)(z).
On original low pe, p e/q<2K, so the right side is at most 2K times that expectation. The reciprocal ORIGINAL w is mandatory. On the additional pair branch w>=delta>0 it may be bounded by delta^-1, but the branch and its complement must remain. Normalizing only w nu and then writing an unweighted h expectation drops 1/w and gives a LOWER quantity, not a valid majorant for original traffic.

The low-pe step cancels the mass e; it does not create an inverse-m gain in original traffic. Keeping min(p e/q,2K) with the exact mu identity is valid. Conversely, the original weighted traffic with w inserted has a simpler posterior expectation but is smaller than the original traffic.

## Source conservation and quantifier boundary

Positive Tonelli is legitimate with the row-dependent mu, but its z marginal is
 nu(dz) integral dx beta(dy) [1_Z w/e] times the chosen row/receiver weight.
The fact integral dmu=1 gives row normalization only; it does not bound this column occupation or make each original source used once. Any claimed mass-conserving overlap payment must prove an explicit bound on this source occupation after retaining the actual common x, or construct a fractional source matching with row/column budgets. An actual z sampled from original Z has the same original source identity, but a freely introduced auxiliary sample does not automatically retain hard capture, pair masks or accepted-history labels.

Actual beta FIRST and the actual hard cap may be consumed on the original receiver set. They are not source-density bounds and cannot be granted to the normalized mu, enlarged artificial scales, or source-position integrals. Replacing actual q by q_- in a positive numerical denominator is safe; replacing it in Z requires the enlarged q_- set as in R292, and that enlargement cannot replace e inside the low gate or posterior identity. All inverse-e expressions are restricted to heavy e>0 rows; zero soft response contributes zero.

## Positive source-level information already available

1. The exact posterior expectation above is valid and can carry any original positive mask. For a fixed row the weighted capture probability mu(A) is in [0,1], while unweighted source/capture ratios require the stated 1/w factor.

2. Define the SAME-original-set overlap E_orig(y,g;q)=integral_Z Gamma_(j,M)(g;y,z)nu(dz). The optional R114 column comparison Gamma<=C_n c_j^n g^-n w gives
 0<=zeta:=E_orig/[C_n c_j^n g^-n e]<=1.
Hence E_orig/q<=C_n ell_n m c_j^(n/2)zeta. This is an exact useful coherence ratio: large m can coexist with a small overlap fraction. It is not the R292 enlarged E^-; the latter includes extra q_- sources and cannot be bounded by the original e via this calculation. No bound on zeta averaged against original beta is asserted.

3. The posterior relative entropy against the normalized original source nu|Z/nu(Z) has the exact finite formula
 KL(mu || nu|Z/nu(Z))=log(nu(Z)/e)+integral log w dmu,
 so 0<=KL<=log(nu(Z)/e). The same formula with total nu mass gives an outer-source reference at explicit cost log(||nu||/e). Positivity and w<=1 justify these bounds; w log w is integrable against finite nu. This is genuine rowwise information, but its normalization mass/logarithm and its receiver-dependent posterior remain explicit. No source-conserving integration or uniform dimension bound follows from it alone.

4. The R293 actual fixed-band column has weak coefficient K_j=4gamma^n D and finite height min(a^-n A_n,2c_j^n g^-n(D+h_tau)). This gives the capped source concentration/rearrangement payments already proved, not a free beta-weighted weak convolution endpoint. The homogeneous majorant itself cannot replace the finite column in source convolution. Different j reuse sources; every coefficient and original unique-j allocation must be retained until a valid common budget is proved.

These are constructive identities and conditional interfaces. The unproved step is an actual source-conserving bound for the common-x occupation or overlap/coherence/entropy charge under the ORIGINAL low-pe and source caps. No new assumption beta<=constant Lebesgue density or nu<=beta is used, and no admissible-history counterexample campaign is undertaken. The low slot outer fee remains Lambda once.

## Executed local algebra diagnostic

Python Fraction verified 40 finite positive weighted-row normalization and original/posterior traffic identities exactly. mpmath at 40 digits verified the matching relative-entropy identity and interval [0,log(nu(Z)/e)], maximum identity discrepancy 4.9505e-41. These are algebraic diagnostics of the normalization, not original FULL/history instances or evidence of a new global source budget. The displayed formulas give the rigorous argument.

## Independent monotone-cap scale-envelope theorem screen

Before reading any proposed author proof of this new mechanism, the scalar theorem is valid: for nonnegative measurable integrable ray-nonincreasing H and nondecreasing A:[a,b]->[0,infinity], define tau(t)=t^n A(t), D(v)=integral min(H,v), U(v)=integral H 1{H<v}. Then
 integral sup_(a<=t<=b) min(t^-n H((x-y)/t),A(t))dx
 <=D(tau(b))+n integral_a^b U(tau(t))dt/t.
For t<t', p_t<=r p_t' with r=(t'/t)^n and A_t<=A_t'. If p_t'>=A_t', then F_t<=A_t' and no increment is needed; otherwise F_t<=r p_t'. Hence F_t<=F_t'+(r-1)p_t'1{p_t'<A_t'}. Telescoping over nested dyadic logarithmic meshes bounds the finite maximum by the endpoint plus these positive decrements. Integrating yields D(tau(b))+sum(e^(n Delta)-1)U(tau(right)). U(tau(t)) is monotone and bounded by ||H||1, so its right Riemann sums converge; strict increase of tau is unnecessary.

Every t<b is approximable from the right by these meshes, and F_t'>=(t/t')^n F_t. Thus the countable dense sup plus endpoint b equals the full sup, even at hard faces and without continuity assumptions on H or A. This also proves measurability. Extended caps A=0 or infinity are harmless, with U(infinity)=||H||1 and zero/infinity conventions handled by positive limits. The case a=b is just the endpoint term. For H=1_Q and tau(b)<=1 the bound is exact: U vanishes and the expanding saturated core has maximal integral tau(b)|Q|.

For application, a tree frozen at q_+=lambda has larger excluded set, so Z+ subset Zactual and e+<=eactual. Original low pe therefore gives p e+<2Klambda, permitting nondecreasing cap 2Klambda/e+(g) if e+ decreases in g. At e+=0 use cap infinity. This enlargement of cap does not replace original e or original low membership. The actual g must still be mapped explicitly to physical soft scale t=L, preserving the ratio orientation; the scalar theorem does not identify g with L automatically.

Executed local Python Fraction and 40-digit mpmath checks: 12 rational finite-mesh envelopes for a two-level ray-decreasing one-dimensional H and nondecreasing A(t)=c t^alpha, c in {.1,.5,1,2}, alpha in {0,1,2}, all lie below the exact analytic theorem budget. These are finite diagnostics, not a substitute for the monotone-mesh proof.

## Bounded transport author review

PASS for /tmp/r294_transport.md SHA256 74da682c08571efeb7651e3c1556402e54b299aa2c0cd8ab968a4acbe1259f7a. The actual soft-family shift/dilation lemma is valid: phi core minimum exceeds 1/4, |phi'|<=1, and log f_s has core Lipschitz constant 4s; outside the old core the enlarged shifted coordinate moves inward. This proves chi_s=(1+d/L)^n exp(4nsd/(L+d)), with closed hard faces retained. Passing the SAME common-soft supremum through this pointwise domination and clipping by the SAME tau has the correct upper-bound direction. The hard comparison has its full normalization factor.

Averaging conserves both original source masses exactly and gives the forward/backward response comparisons. Future upper caps on ORIGINAL sources at L+2d and R+2d are sufficient for transported caps at L+d,R+d. The soft future cap is explicitly an additional premise, not a consequence of actual FIRST. Restricting the interior to L,R<=b-2d keeps every invoked scale legal; the same softness must also be available there.

The ratio transport is correct: g+d<=g'<=(1+d/a)g and v-v'<=d/a<2log gamma when d<=a/n. The new unique band is j or j-1, and the two closed target envelopes use the OLD fixed profile/tau. The pointwise comparison precedes the receiver supremum and integration. The two target bands are a paid two-term majorant, not disjoint new source budgets.

Upper strips are independently source-paid using the original caps: A_top<=1+2nd/a<=3; first R>b-2d costs at most3W_nu, then L>b-2d costs at most16 Csoft_n W_beta. If b-2d<a the whole traffic has the stated direct FIRST/hard-envelope price. Lambda is multiplied once for this original raw low slot.

The generic averaged density W/d^n and exact R293 normalized ratio A_n(d/a)^n/K are retained. At d=O(a/n), source conservation does not prove useful concentration control. Thus the theorem proves legal source-mass conservation/transport and explicit boundary payments, subject to its future soft-cap premise for inherited caps; it does not establish the second, source-concentration bridge or global closure. No correction requested.

## Main inverse-variation proof review

PASS for the mathematical statements in /tmp/r294_main_geometry.md at SHA256 2bbbb571d40ea76c989aa8399406bf6a78b565ff2030f2f2a6751f439c163ce6, with G6's original tree interface to be bound again after the companion e+ proof. G1--G3 match the independent proof above, including hard faces, extended caps, countable measurable supremum and nested-mesh convergence.

G4 is correct: H(x)<tau(t)<=tau(b)(t/b)^n forces t>b[H(x)/tau(b)]^(1/n); the available log length is at most min(log(b/a),n^-1 log_+(tau(b)/H(x))). Tonelli gives exactly the stated finite truncated-entropy bound. G5 correctly uses U(u)<=u^delta R_delta and integrates n(t/b)^(n delta)dt/t, yielding [1-(a/b)^(n delta)]/delta. D(tau(b))<=tau(b)^delta R_delta supplies the additional 1. Thus the final prefactor 1+1/delta is correct with no hidden n; R_delta and the terminal cap remain genuine dimension/source costs. Finite positive tau(b) is stated for this specialization, and zero/infinity are separately handled.

For nonempty original bands, u_j(L)=min(b c_j,L/c_(j+1)) lies in [a/c_j,b c_j], is nondecreasing, and is at least every actual g of that band at physical soft scale L. A source mass e+ nonincreasing in g therefore gives the correct nondecreasing cap A_j(y,L). The application consumes actual hardcap/q<=16/3 before extending receivers and sums each j source fee explicitly. No beta FIRST or source-density property is assigned to H_sigma or the cap profile. G6 has no automatic root/global consequence when terminal e+ vanishes or fractional moments are large.

## Joint frozen-mass/root proof review

Reviewed /tmp/r294_joint_geometry.md at SHA256 b79b5962a9ee116fa3cad08ceec714a7a25df88f8a8270bb0652fef6711b0f9c. All substantive formulas Sections 1--7 pass. One legal-window clarification was requested before final binding: on the large-soft-scale long part use physical L>=a/c_j² (automatic for actual L>=R band), so c_j L remains in the legal g window; the proof must not evaluate e+(c_j L) below that window. This changes no constant.

The q_+ freeze correctly gives Z+ subset Zactual. If no lambda-light node exists both choices have the same fallback; otherwise the removed difference is bounded by the genuinely light A+, hence eactual-e+<=lambda t^n J_j(t) even when the smaller-q choice is a fallback. Since J_j<=sqrt(n) and lambda/q<=4/3, d0=4sqrt(n)/(3ell) is valid. The source mass is full and weighted; no pair-parent substitution is made.

The global legal map u_j(L) and resulting nondecreasing cap match main G6. The exact actual-sublevel profile is min(H,tau) outside the hard cube, while inside it is min(1,tau)1{f_sigma<=tau}. Continuity in common s and monotonicity on the core prove these exact formulas. The optional removed-core correction has the indispensable factor (a/b)^n: endpoint density b^-n min(1,tau_b) times removed volume a^n S_sigma(tau_b). All actual low traffic vanishes on that set; removing it decreases the endpoint by exactly C_j and cannot increase positive scale increments. J itself need not be ray-decreasing and is correctly not inserted into G1.

For high actual m>M+d0, e+(g)>h_j g^n with h_j=ell q_- M c_j^-n/2. Its strict superlevel root is an initial interval; below g* the needed lower mass bound holds, while a downward jump at g* is NOT assigned a false threshold. Source-dependent long endpoints are closed with the left cap only; actual endpoint traffic is assigned to the terminal strip. Singleton feasible windows are handled by strips.

Large orientation gives Theta_large=8K c_j^-n/2/(3ell M); small orientation gives Theta_small=8K c_j^(n/2)c_(j+1)^n/(3ell M). Terminal caps are respectively 2K gamma^n c_j^-n/2/(ell M) and 2K c_j^(3n/2)/(ell M), with strip ratio at most gamma. Their common long/strip ratio theta0=4/(3gamma^n)<=2/3 is correct. Thus (21) has exactly B_delta=(1+1/delta)theta0^delta+A_gamma, A_gamma=1+n log gamma<=2.

The small-orientation all-band sum is correctly [1-gamma^(-3n delta/2)]^-1; the large orientation instead has the growing sum of c_j^(-n delta/2). Full-soft R_delta, M,delta,K and the complementary m<=M+d0 budget remain explicit. The new source-linear small-orientation payment does not assert that polynomial M works at full softness or that the large orientation is paid at the decaying sign. No further correction requested.

Joint-proof final legal-window receipt: confirmed the current frozen file explicitly says “For this orientation the feasible soft scales also satisfy L>=a/c_j^2; restrict the long part accordingly.” This addresses the previously raised interface clarification. Final PASS binds SHA256 b79b5962a9ee116fa3cad08ceec714a7a25df88f8a8270bb0652fef6711b0f9c; no pending proof correction remains. The prior paragraph records the earlier read before this clarification, and is superseded on that point by this verified final receipt.

## Final README integration and frozen receipt

PASS. The final README matches all three mathematical proofs and their scope. Its simplified small-soft-scale price is correct: both the long cap and the terminal-strip cap are bounded by (8K/(3ell M))c_j^(3n/2); the long moment fee is at most (1+1/delta) times this cap^delta R_delta and the strip adds at most2 times it. Thus the displayed (16/3)(3+1/delta)R_delta(8K/(3ell M))^delta/[1-gamma^(-3n delta/2)] W_beta is valid. It retains actual m>M+d0, L<=R, original full weighted mass, all previous masks, source/band reuse fees, and Lambda once. The growing opposite-orientation band sum is not replaced by the small-orientation geometric series.

The generalized inverse-variation theorem is valid for all stated measurable ray-decreasing profiles and monotone caps. Its finite-terminal fractional-moment consequence retains the exact terminal cap and R_delta; zero caps are trivial and infinite caps retain the general theorem rather than imply an advantageous moment bound. The original q_+ source freeze, low-pe cap, optional core subtraction, strict root/left endpoint and transport future-cap qualifications are all explicit in the proofs. The final large-orientation legal long-window clarification was verified, so G6 and its refinements are fully bound to the audited original tree construction.

Executed independent local evidence in this audit consists of 40 exact posterior normalization/traffic identities with 40-digit KL checks and12 finite-mesh monotone-cap envelope checks. Parent reports actual reruns of the three frozen scripts, all PASS; no additional rerun was needed after the last mathematical freeze. The README treats those finite tests as diagnostics and retains all general gaps.

Final bound files:
- /tmp/r294_main_geometry.md: SHA256 2bbbb571d40ea76c989aa8399406bf6a78b565ff2030f2f2a6751f439c163ce6
- /tmp/r294_joint_geometry.md: SHA256 b79b5962a9ee116fa3cad08ceec714a7a25df88f8a8270bb0652fef6711b0f9c
- /tmp/r294_transport.md: SHA256 74da682c08571efeb7651e3c1556402e54b299aa2c0cd8ab968a4acbe1259f7a
- /tmp/r294_README.md: SHA256 a5cb6a922607fa3ee146e0f17140e7fda6f571995794671b23f1567ba55853d0

Exact remaining quantitative obligations: bound the original beta-weighted terminal/unsaturated profile functional and all band fees at root-polylog cost; for high-m root refinements retain the full-soft R_delta cost, the growing large-soft orientation, and the complementary actual m<=M+d0 traffic. Source averaging additionally needs useful concentration control at its legal response-comparison cost, with future soft caps proved where invoked. Original continuous high-score and initial/jump/deletion ledgers are outside this bounded payment and remain separate. No arbitrary-input root weak-type closure is proved.

Final verdict PASS; audit frozen. Only this owned temporary audit file was edited, with no repository, Git, PDF, or upstream author modifications.
