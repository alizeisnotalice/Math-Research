# R294: freezing the full low-pe mass and retaining its scale profile

## 1. Precise theorem and its limitation

Keep the original traffic

    dT=q(x)^(-1) p_(s(x),L(x))(x-y) h_(R(x))(x-z)
          a_omega(x,y,z) dx beta(dy)nu(dz),

with true receiver Lebesgue measure, 0<=a_omega<=1, original hard source z in Z_(j,g)(y), g=sqrt(LR), a<=L,R<=b<=2a, and the original unique ratio band

    c_(j+1)<=min(L,R)/g<=c_j,
    c_j=gamma^(-j), gamma=1+1/n.

Use q_-=3lambda/4<=q(x)<=lambda=q_+, FIRST integral p beta<=q, and the original full maximal hard cap, hence in particular h_R*nu(x)<=4lambda at actual receivers. The exact original low gate is

    p_y e_(j,g;q(x))(y)<2Kq(x),
    e_(j,g;q)(y)=integral_(Z_(j,g;q)(y)) w_(j,g)(y,z)nu(dz).

The full original weight and source set are retained. Set ell=1+log n. This note proves a quantitative receiver-independent lower comparison for e, and an explicit source-profile payment for ALL this low traffic. No new favorable gate is imposed. FIRST remains an original qualification; the particular upper estimate below consumes the original hard cap and low gate, not a surrogate FIRST statement.

Let e^+_(j,t)(y) denote the SAME original weighted mass with ONLY the tree light threshold frozen at q_+=lambda (defined precisely below). For a nonempty band and L in [a,b], define

    u_j(L)=min{b c_j,L/c_(j+1)},
    E_j(y,L)=e^+_(j,u_j(L))(y),
    A_j(y,L)=2Klambda/E_j(y,L),
    tau_j(y,L)=L^n A_j(y,L).                              (1)

If E_j=0, A_j=tau_j=infinity; this means no soft height restriction, not division by zero in the traffic.

For any fixed sigma covering actual softness, put

    f_s(v)=product_i [(1-s)h(v_i)+s phi(v_i)],
    H_sigma(v)=sup_(0<=s<=sigma) f_s(v),
    D_sigma(tau)=integral min(H_sigma,tau),
    U_sigma(tau)=integral H_sigma 1_{H_sigma<tau}.

At infinity both D and U equal integral H_sigma. At zero both are zero. The source-profile estimate is

    T_low <=(16/3) integral beta(dy) sum_(legal j) B_j(y),  (2)
    B_j(y)=D_sigma(tau_j(y,b))
             +n integral_a^b U_sigma(tau_j(y,L)) dL/L.    (3)

All original additional positive masks may remain on the left. The usual original low-raw outer factor Lambda multiplies (2) once. There is no high-score or posterior multiplier in (2). A source mass is not claimed to be disjoint between bands: the sum in (2) is explicit.

Compared with replacing the whole profile by its terminal cap and paying [1+n log(b/a)]D_sigma(tau_j(y,b)), (3) is always smaller or equal. Its scale integral pays the UNSATURATED tail U, not the clipped mass D. This is a rigorous reduction of the old fee, including for arbitrary concentrated sources. It does not establish that the beta-weighted sum in (2) is root-polylogarithmic. That precise remaining quantitative issue is stated in section 6.

## 2. Quantitative q_+ freezing, including the fallback

The original frozen finite tree path through y consists of nested cells. Its hard mass h(A)=nu(A) is nondecreasing along inclusion. The original threshold has the form

    H_j(t;q)=q t^n J_j(t),
    J_j(t)=max{1,sqrt(n)c_(j+1)^n,sqrt(n)(t/b)^n}.

Let A_(j,t;q)(y) be the coarsest path cell satisfying h(A)<=H_j(t;q), with the original finest-cell fallback when no cell satisfies it. Let A^+_(j,t)(y)=A_(j,t;lambda)(y). Retain the original frozen distance restriction D_V(y), and define

    Z^+_(j,t)(y)=D_V(y) intersect (T_0(y) minus A^+_(j,t)(y)),
    e^+_(j,t)(y)=integral_(Z^+_(j,t)(y)) w_(j,t)(y,z)nu(dz).

This is not a localization to a pair parent. It uses the full original nu and the full original product overlap weight, with 0<=w<=1.

Since q<=lambda, inclusion along the one path gives A_(q) subset A^+. Hence Z^+ subset Z_(q), and

    0<=e_(j,t;q)(y)-e^+_(j,t)(y)
       <=lambda t^n J_j(t).                              (4)

Here is the fallback check. If no lambda-light cell exists, no q-light cell exists either, so both choices are the same finest fallback and the difference is zero. If a lambda-light cell exists, A^+ really satisfies h(A^+)<=lambda t^n J_j(t). The removed source difference is a subset of A^+ minus A_(q), even if the latter is itself a fallback. Since w<=1, its weighted mass is at most h(A^+). This proves (4) in every case, including zero-mass nodes and equality at a threshold. No bound on the mass of a non-light fallback is used.

For the original

    m=e_(j,g;q)/(ell q c_j^(-n/2)g^n),

write m^+=e^+_(j,g)/(ell q c_j^(-n/2)g^n), retaining the actual q in this displayed normalization only. Then

    0<=m-m^+ <=(lambda/q)c_j^(n/2)J_j(g)/ell
                 <=4sqrt(n)/(3ell).                     (5)

The first bound is sharper and remains available. Thus actual m>M+4sqrt(n)/(3ell) forces m^+>M. This implication is quantitative; actual m>M alone is NOT asserted to force the same lower bound for m^+.

As t increases, the light threshold increases and A^+ can only grow. The weight w_(j,t) decreases in t. Consequently e^+ is nonincreasing. The finite-tree <= convention gives right continuity at deletions; continuity of the original overlap weight and dominated convergence give right continuity between them. All quantities are measurable frozen source functions, independent of receiver q(x). Their finiteness follows from w<=1 and nu having finite total mass.

## 3. Legal physical-scale mapping and actual low-gate transfer

The ratio band has physical g-window [a/c_j,b c_j]; if this interval is empty, the band contributes zero. For EVERY L in [a,b] in a nonempty band, u_j(L) in (1) lies in this legal window: L/c_(j+1)>=a/c_(j+1)>=a/c_j and b c_j>=a/c_j. No extrapolation of e^+ to illegal scales is needed.

At an actual pair of legal scales, g<=b c_j and L>=c_(j+1)g, so g<=u_j(L). Monotonicity therefore yields

    E_j(y,L)=e^+_(j,u_j(L))(y)
       <=e^+_(j,g)(y)<=e_(j,g;q(x))(y).

The actual low gate now implies

    p_(s,L)(x-y)<2Kq(x)/e_original
                 <=2Klambda/E_j(y,L)=A_j(y,L)            (6)

whenever E_j>0; if E_j=0 the last cap is unrestricted. Thus the actual soft response is bounded by

    F_(j,L)(x-y)=min{L^(-n)H_sigma((x-y)/L),A_j(y,L)}.     (7)

Both E_j and A_j are independent of x once y and the frozen outer data are fixed. The function A_j is nondecreasing and right-continuous in L, with infinity allowed. The normalized cap tau_j=L^n A_j is likewise nondecreasing, and is strictly increasing wherever it is finite and positive.

## 4. The inverse-time profile budget and proof of (2)

The following elementary envelope inequality is the companion result independently derived by the parent in R294. For integrable ray-nonincreasing H>=0, nondecreasing A(t)>=0, and tau(t)=t^n A(t),

    integral sup_(a<=t<=b) min{t^(-n)H(x/t),A(t)} dx
       <=D(tau(b))+n integral_a^b U(tau(t))dt/t.          (8)

The important sign is inverse time: an increasing cap produces no negative variation. For t<t', ray monotonicity gives p_t<=c p_t', c=(t'/t)^n, while A(t)<=A(t'). Therefore

    min(p_t,A(t))-min(p_t',A(t'))
       <=(c-1)p_t' 1_{p_t'<A(t')}.                       (9)

Apply (9) backwards along a finite partition, telescope from the endpoint, integrate x, and refine the partition. The endpoint integral is D(tau(b)); the integrated increments converge to the right side's n U integral. Monotone caps are Riemann integrable after composition with U apart from their countable discontinuities. Possible plateau levels of H only create countably many additional threshold discontinuities; strict increase of finite positive tau makes their scale preimages at most singletons. Truncation handles A=infinity, and monotone convergence handles all measurable nonnegative profiles. Equivalently, (8) is the integrated negative-variation bound for the truncated dilation family. It does not replace U by D.

On the original accepted receivers, integrate the original hard source first and use h_R*nu<=4lambda. Dropping original positive masks, while retaining low until (6), gives the j contribution at fixed y at most

    (4lambda/q_-) integral_x sup_(a<=L<=b) F_(j,L)(x-y)dx.

Since 4lambda/q_-=16/3, applying (8) proves (2)-(3). This proof uses actual common softness through H_sigma and actual simultaneous L,R before the legal positive relaxation. It grants no hard cap to enlarged/artificial scales. The countable dense-scale formulation of the envelope is justified by ray monotonicity and one-sided cap limits; positive Tonelli retains the true receiver measure.

To see the improvement explicitly,

    D_sigma(tau)-U_sigma(tau)
       =tau |{v:H_sigma(v)>=tau}|                         (10)

for finite tau>0. Thus (3) discards the saturated-core part of the old scale integral. In the hard profile H=1_Q, if tau(b)<1, U(tau(L))=0 throughout and (8) costs only tau(b), compared with [1+n log(b/a)]tau(b) under the old clipped-mass estimate. This hard example checks the general formula; the theorem itself allows full softness and all displacements.

## 5. Exact actual-sublevel geometry, beyond positive clipping

There is additional information in the actual low gate that (7) drops. Define the common-soft sublevel envelope

    J_(sigma,tau)(v)=sup{f_s(v):0<=s<=sigma, f_s(v)<=tau},

with supremum zero for an empty set. The <= condition is a safe closed majorant for the original strict gate. Let Q be the unit hard cube. Then exactly

    J_(sigma,tau)(v)=min(H_sigma(v),tau),             v outside Q;
    J_(sigma,tau)(v)=min(1,tau) 1_{f_sigma(v)<=tau},  v inside Q. (11)

Off Q, the continuous function s↦f_s(v) starts at zero, so its image contains every value from zero to its maximum. On Q, each factor 1-s+s phi(v_i) decreases with s, so the image is exactly [f_sigma(v),1]. This proves (11) without independent coordinate softness choices.

In particular, for 0<tau<1,

    integral J_(sigma,tau)
       =D_sigma(tau)-tau |{v in Q:f_sigma(v)>tau}|.        (12)

Unlike the clipped profile, the actual sublevel profile has no core contribution below the minimum of f_sigma on Q. That minimum is

    [1-sigma+sigma phi(1/2)]^n,
    phi(1/2)=integral_0^1 r(1-exp(-1/r))dr.

J need not be ray-nonincreasing, so inserting J into (8) would be unjustified. A valid combined correction is nevertheless available. Write

    S_sigma(tau)=|{v in Q:f_sigma(v)>tau}|,
    C_j(y)=(a/b)^n min(1,tau_j(y,b))S_sigma(tau_j(y,b)).

On x in Q_a(y) with f_sigma((x-y)/a)>tau_j(y,b), every actual L>=a and s<=sigma has

    f_s((x-y)/L)>=f_sigma((x-y)/a)>tau_j(y,b)>=tau_j(y,L).

Thus the original low traffic is zero on this receiver set. In the proof of (8), remove this set before integrating. The endpoint term alone decreases by exactly C_j(y), and the nonnegative increment terms cannot increase. Hence the refined general bound is

    T_low <=(16/3) integral beta(dy) sum_j [B_j(y)-C_j(y)]. (13)

At tau=infinity use S=0. The bracket is nonnegative because it bounds the nonnegative envelope restricted outside the excluded core. This correction is optional and may be small when a/b is small; its exact factor must not be omitted. It is an actual low-gate deduction, not an extra imposed gate. For sigma=0 and tau_j(y,b)<1, the entire original row is in fact zero, since every positive hard soft-kernel value has normalized height one; this stronger special conclusion is not claimed for sigma>0.

## 6. Exact remaining budget and actual finite checks

The new global profile reduction (13) removes the artificial n-times saturated-core fee and makes the original-source dependence explicit through the full e^+ profile. It also quantifies the precise loss between e^+ and actual e in (4)-(5). It neither assumes nu<=beta nor supplies a pointwise density cap, and it never replaces e by an actual pair's ancestor mass.

What is not proved is a uniform root source inequality of the form

    integral beta(dy) sum_j [B_j(y)-C_j(y)]
       <=C sqrt(n) polylog(n) [W_beta+W_nu].              (14)

Proving (14), or retaining more of the actual receiver caps before its row-envelope relaxation, is the remaining source-concentration step. This is a completely specified frozen-source functional, with no actual receiver selector remaining. Its dependence on e^+ and its source overlap is visible, rather than a renamed original traffic remainder. It must not be treated as already bounded by a Lebesgue weak estimate.

The only automatic bound is B_j<= [1+n log(b/a)]Csoft_n, where Csoft_n<=1+(pi/2)sqrt(n). The number of nonempty bands is at most 1+log(b/a)/(2log gamma). Thus the unrestricted worst-case sum supplied by this proof is polynomial and need not have root order. Unique original j does not eliminate this explicit sum after rowwise majorization. Formula (5) also shows exactly why transferring an original high-m claim to e^+ has a nonzero O(sqrt(n)/ell) additive fee.

Local Python calculations were actually run using exact Fraction arithmetic. They checked the coarsest-node/fallback inclusion and weighted mass difference for three stages: 40 paths of depth<=3, 160 of depth<=12, and 600 of depth<=40; all passed, including absent light nodes and zero masses. The inverse-time inequality (9) passed 2000 exact rational checks. The legal mapping u_j(L) passed tested bands and endpoint/interior L at n=1,2,10,100,10000. These are finite diagnostics; the proofs above establish the general statements. No original-history numerical closure was claimed.

## 7. High-m root, one short terminal strip, and a source payment across bands

The following refinement addresses the original HIGH-m portion without introducing an independent source-density condition. Fix M>0 and put d0=4sqrt(n)/(3ell). Work on original low traffic with actual m>M+d0. By (5), its frozen mass satisfies

    e^+_(j,g)(y)>h_j g^n,
    h_j=ell q_- M c_j^(-n/2).                            (15)

For each y,j let S_j(y)={t in [a/c_j,b c_j]:e^+_(j,t)(y)>h_j t^n}. If empty, this high branch has no actual receiver for that y,j. Otherwise set g_*=sup S_j. The quotient e^+(t)/t^n decreases, so S_j is an initial interval, possibly with its upper endpoint included. On every feasible t<g_*, e^+(t)>h_j t^n. At a jump at g_* the value e^+(g_*) may be smaller; it is NEVER assumed to satisfy the threshold. Limits from below, when that side exists, satisfy e^+(g_*-)>=h_j g_*^n. The singleton feasible-window case is covered entirely by the terminal strips below.

For the orientation L>=R, actual g/L lies in [c_(j+1),c_j]. Thus actual high-branch soft scales have L<=g_*/c_(j+1). Split them into

    long part: L<g_*/c_j,
    terminal strip: g_*/c_j<=L<=g_*/c_(j+1),

and intersect both with the physical [a,b]. For this orientation the feasible soft scales also satisfy L>=a/c_j^2; restrict the long part accordingly. On that long part, take u=c_j L rather than the coarser u in (1). Actual g<=u<g_*, and any feasible scale has u>=a/c_j. Therefore E(L)=e^+(c_j L) is a valid nonincreasing source profile. Its endpoint normalized height is bounded, in the left-limit sense if necessary, by

    Theta_large=8K c_j^(-n/2)/(3ell M).                   (16)

For the orientation L<=R, actual g/L lies in [1/c_j,1/c_(j+1)]. Split

    long part: L<c_(j+1)g_*,
    terminal strip: c_(j+1)g_*<=L<=c_j g_*.

On the long part use u=L/c_(j+1), obtaining

    Theta_small=8K c_j^(n/2)c_(j+1)^n/(3ell M).            (17)

Empty long parts cost zero. If a long part ends strictly below the root because b intervenes, the same bounds follow directly from (15). If it ends at the root, close the profile with its left cap; all actual endpoint traffic is allocated to the terminal strip. This avoids imposing a false lower bound on e^+(g_*). Endpoints can be assigned to exactly one of the two parts, and the original unique j is preserved.

For 0<delta<1 define the finite full-soft fractional integral

    R_delta=integral H_sigma(v)^(1-delta)dv.

It is finite: the finite positive product expansion of H_sigma and the exponential coordinate tails of phi give an integrable fractional-power majorant. Its dimension dependence is NOT suppressed. From (8) and tau(L)<=tau(T)(L/T)^n, the long part's envelope cost is at most

    D_sigma(Theta)+integral H_sigma
          min{n log(b/a),log_+(Theta/H_sigma)}
       <=(1+1/delta)Theta^delta R_delta.                 (18)

The identity underlying the first bound is positive Tonelli: if H_sigma(v)<tau(L), then L/T>(H_sigma(v)/tau(T))^(1/n). The endpoint and tail terms are bounded separately by Theta^delta R_delta and Theta^delta R_delta/delta. This is the shared R294 moment improvement to the inverse-time lemma; no scale factor A_n remains in (18).

The terminal strips need not pay the untruncated Csoft_n. The actual original low gate and m>M already imply

    f_s((x-y)/L)< tau_large,j
         :=2K gamma^n c_j^(-n/2)/(ell M),       L>=R;
    f_s((x-y)/L)< tau_small,j
         :=2K c_j^(3n/2)/(ell M),              L<=R.       (19)

Each strip has scale ratio at most gamma, even after physical clipping. The ordinary ray-decreasing scale envelope applied to min(H_sigma,tau_orientation,j) therefore costs at most

    A_gamma D_sigma(tau_orientation,j),
    A_gamma=1+n log gamma<=2.                            (20)

This includes a degenerate one-scale strip, with coefficient one rather than zero. No density assumption is needed; the original hard cap is used only at the original receivers, as in section 4.

There is a common ratio between the long and strip caps:

    Theta_orientation=theta0 tau_orientation,j,
    theta0=4/(3gamma^n)<=2/3.

Combining (18)-(20), and using D(tau)<=tau^delta R_delta, proves the explicit per-band source price

    T_(low,m>M+d0,orientation,j)
       <=(16/3) R_delta B_delta tau_orientation,j^delta W_beta,
    B_delta=(1+1/delta)theta0^delta+A_gamma.              (21)

One may retain the sharper beta integral restricted to nonempty root sets, and retain D in (20); (21) is a simple uniform source-linear consequence. Full original e and m appear in the left side.

For the SMALL-SOFT-SCALE orientation L<=R, the coefficients in (21) are summable over ALL original ratio bands, without declaring their source sets disjoint:

    T_(low,m>M+d0,L<=R)
       <=(16/3) R_delta B_delta
          (2K/(ell M))^delta
          [1-gamma^(-3n delta/2)]^(-1) W_beta.            (22)

The sum has been extended positively to j=0,1,...; this is valid regardless of the finite legal band cutoff. Equation (22) is a genuine source-linear payment of an original wide, high-m orientation across all bands. It is not restricted to a fixed displacement. Its displayed dependence on R_delta, M and delta is essential. It becomes a root-priced branch when those displayed factors are at most root-polylog size; no claim is made that polynomial M suffices for full softness.

For L>=R, the corresponding exact factor is instead

    (2K gamma^n/(ell M))^delta
         sum_(legal j) c_j^(-n delta/2).                 (23)

This grows toward the last legal band. There is no geometric-series gain of the sign in (22). Paying both orientations by the small-scale coefficient would be incorrect. Thus the large-soft-scale orientation, the cost of full-soft R_delta, and the complementary original m<=M+d0 traffic remain explicit. Equations (21)-(23) do not close the global root theorem.

The reproducible exact-arithmetic diagnostics are saved in /tmp/r294_tree_checks.py. A final run passed the 800 tree-path cases, 2000 inverse-time cases, legal-scale mapping checks, and 1138 root/orientation cover cases. These checks do not estimate R_delta or prove a global source budget.
