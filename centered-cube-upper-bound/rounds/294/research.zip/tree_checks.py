"""R294 finite rational diagnostics; no global theorem is inferred."""
from fractions import Fraction as F
import random
rng = random.Random(294)
stages = []
for stage, trials, depthmax in [(1, 40, 3), (2, 160, 12), (3, 600, 40)]:
    for _ in range(trials):
        depth = rng.randint(1, depthmax)
        masses = [F(rng.randint(0, 30), 7) for _ in range(depth)]
        weights = [F(rng.randint(0, 11), 11) for _ in range(depth)]
        lam = F(rng.randint(1, 20), 3)
        q = lam * F(rng.randint(9, 12), 12)
        shape = F(rng.randint(1, 80), 9)
        def chosen(threshold):
            good = [k for k in range(1, depth + 1) if sum(masses[:k]) <= threshold]
            return (max(good), True) if good else (1, False)
        k0, _ = chosen(q * shape)
        kp, exists = chosen(lam * shape)
        assert kp >= k0
        diff = sum(masses[i] * weights[i] for i in range(k0, kp))
        assert 0 <= diff <= lam * shape
        if not exists:
            assert diff == 0
    stages.append((stage, trials))
for _ in range(2000):
    p1 = F(rng.randint(0, 100), 17)
    factor = 1 + F(rng.randint(0, 30), 19)
    p0 = factor * p1 * F(rng.randint(0, 20), 20)
    cap1 = F(rng.randint(0, 100), 13)
    cap0 = cap1 * F(rng.randint(0, 20), 20)
    assert min(p0, cap0) - min(p1, cap1) <= (factor - 1) * p1 * (p1 < cap1)
for n in [1, 2, 10, 100, 10000]:
    gamma = 1 + F(1, n)
    for j in range(min(n, 30) + 1):
        c = gamma ** (-j)
        cp = c / gamma
        a, b = F(1), F(2)
        if a / c > b * c:
            continue
        for L in [a, (a + b) / 2, b]:
            u = min(b * c, L / cp)
            assert a / c <= u <= b * c
root_count = 0
for n in [1, 2, 5, 20, 100]:
    gamma = 1 + F(1, n)
    for j in range(n + 1):
        c, a, b = gamma ** (-j), F(1), F(2)
        cp = c / gamma
        lo, hi = a / c, b * c
        if lo > hi:
            continue
        root = (lo + hi) / 2
        for frac in [F(0), F(1, 4), F(1, 2), F(3, 4), F(1)]:
            g = lo + frac * (root - lo)
            for d in [cp, (cp + c) / 2, c]:
                for orientation in [0, 1]:
                    L, R = (g / d, g * d) if orientation == 0 else (g * d, g / d)
                    if not (a <= L <= b and a <= R <= b):
                        continue
                    edge = root / c if orientation == 0 else cp * root
                    top = root / cp if orientation == 0 else c * root
                    assert L <= top
                    if L < edge:
                        u = c * L if orientation == 0 else L / cp
                        assert g <= u < root and lo <= u <= hi
                    else:
                        assert edge <= L <= top
                    root_count += 1
        assert F(4, 3) / gamma ** n <= F(2, 3)
print({'status': 'PASS', 'tree_stages': stages, 'inverse_time_checks': 2000,
       'legal_mapping_dimensions': [1, 2, 10, 100, 10000],
       'root_orientation_checks': root_count})
