# R294: inverse variation removes the saturated core from dilation fees

## 1. A general geometric envelope theorem

Let n>=1, 0<a<=b<infinity. Let H:R^n->[0,infinity] be Borel measurable, integrable and nonincreasing on every ray away from zero. Let A:[a,b]->[0,infinity] be nondecreasing. Put

    p_t(x)=t^(-n)H(x/t), F_t(x)=min(p_t(x),A(t)),
    tau(t)=t^n A(t),
    D(u)=integral min(H(x),u)dx,
    U(u)=integral H(x)1{H(x)<u}dx.

Use D(0)=U(0)=0 and D(infinity)=U(infinity)=integral H. The value of H at points where it is infinite does not affect these Lebesgue integrals. Then

    integral sup_(a<=t<=b) F_t(x)dx
      <=D(tau(b))+n integral_a^b U(tau(t))dt/t.          (G1)

The saturated core contributes at the terminal scale only. The scale integral charges the UNSATURATED tail H<tau, not the clipped mass D(tau). The statement allows jump discontinuities in H along rays and in A, zero caps, infinite caps, singleton windows, and hard cube faces. It is not a smooth-score approximation.

## 2. Finite meshes and proof without derivatives

For t<t', ray monotonicity gives p_t <= r p_t', r=(t'/t)^n. Since A(t)<=A(t'),

    F_t <= F_t' +(r-1)p_t'1{p_t'<A(t')}.                (G2)

If p_t'>=A(t'), the right additional term is zero and F_t<=A(t)<=A(t')=F_t'. This includes equality. Otherwise F_t<=r p_t' and F_t'=p_t'. This proves (G2), with the STRICT indicator as displayed.

Choose nested uniform logarithmic partitions of [a,b], with mesh Delta=log(b/a)/2^k and nodes t_i. Applying (G2) backwards and summing only positive allowances yields

    max_i F_(t_i) <=F_b
       +(exp(n Delta)-1) sum_(i=1)^(2^k)
                         p_(t_i)1{p_(t_i)<A(t_i)}.

Integration and x=t_i u give

    integral max_i F_(t_i)
       <=D(tau(b))+(exp(n Delta)-1) sum_i U(tau(t_i)).  (G3)

The function U(tau(t)) is nondecreasing and bounded by integral H, so its right Riemann sums converge in logarithmic time. Also (exp(n Delta)-1)/Delta tends to n, for each fixed n.

The countable mesh supremum equals the full scale supremum. For any t<b, select mesh nodes t_k>=t with t_k->t. Ray monotonicity and cap monotonicity imply F_(t_k)>=(t/t_k)^n F_t. Therefore the mesh supremum is at least F_t; the reverse inequality is immediate. The endpoint b belongs to every mesh. This also proves measurability of the full supremum without assuming a continuous selector or dismissing selector-dependent hard faces. Monotone convergence for the nested maxima proves (G1). If a=b the assertion is equality.

## 3. The dimension factor cancels against the growth of the cap level

For 0<t<=b, monotonicity of A gives

    tau(t)<=tau(b)(t/b)^n.

Assume first 0<tau(b)<infinity. For each finite h>0, the logarithmic length of {t in[a,b]:h<tau(t)} is at most

    min{log(b/a), (1/n)log_+(tau(b)/h)}.

Consequently positive Tonelli yields

    n integral_a^b U(tau(t))dt/t
      <=integral H(x) min{n log(b/a),
                         log_+(tau(b)/H(x))}dx.       (G4)

This retains a finite truncated entropy even when the untruncated entropy diverges. Zero values of H contribute zero. Tau(b)=0 gives zero envelope. At tau(b)=infinity use (G1); the entropy specialization is not needed.

For any delta in (0,1) with R_delta=integral H^(1-delta)<infinity,

    U(u)<=u^delta R_delta,
    n integral_a^b U(tau(t))dt/t
       <=[1-(a/b)^(n delta)] tau(b)^delta R_delta/delta.

Since D(u)<=u^delta R_delta, a convenient scale-independent consequence is

    integral sup_t F_t
      <={1+[1-(a/b)^(n delta)]/delta}
                                      tau(b)^delta R_delta
      <=(1+1/delta) tau(b)^delta R_delta.              (G5)

No n or log(b/a) is hidden in the prefactor. The profile moment R_delta and terminal level tau(b), including their actual dimension and source dependence, MUST remain. This is not a uniform root theorem if R_delta tau(b)^delta is large. A source-dependent upper endpoint may replace b if fixed before receiver integration and if the cap bound there is proved.

## 4. Exact saturated hard-profile test

For H=1_(Q_1), U(u)=0 for u<=1 and U(u)=1 for u>1. If tau(b)<=1, monotonicity of A shows directly

    sup_t F_t(x)=A(b)1_(Q_b)(x),
    integral sup_t F_t=tau(b).

Thus (G1) is exact and charges no scale integral. In contrast the older uniform clipped envelope would cost [1+n log(b/a)]tau(b). This example verifies that the difference in (G1) is a real removed fee. The general proof in Sections 1-3 does not restrict H to a hard cube or the sources to special functions.

## 5. Transfer to the actual low-product traffic

Keep original beta,nu, q in[3lambda/4,lambda], actual soft L, hard R, common softness, original complete weighted e_g and all original positive masks. Original low means p_y e_g<2Kq. The original hard cap is used ON the receiver set before extending dx, giving hardcap/q<=16/3.

The companion source-geometry proof freezes the light block at q_+=lambda. Its original weighted remaining source mass e^+_j(y,g) satisfies e^+<=e_actual and is nonincreasing in g, with explicit light-block difference budget. It does not replace actual e_g in any posterior or gate.

For a nonempty original band set

    u_j(L)=min(b c_j,L/c_(j+1)),
    E_j(y,L)=e^+_j(y,u_j(L)),
    A_j(y,L)=2Klambda/E_j(y,L),

with A_j=infinity if E_j=0. This legal map is nondecreasing and dominates actual g in the band, so E_j(y,L)<=e_actual(y,g). Hence on actual low rows

    p_y<=min{L^(-n)H_sigma((x-y)/L), A_j(y,L)}.

The cap A_j is nondecreasing in L. All maps depend only on frozen source data and y, not receiver x; common softness may be bounded by sigma=1. Applying (G1) after the actual hard cap yields

    T_low <=(16/3) integral beta(dy) sum_(legal j)
       [D_sigma(tau_j(y,b))
             +n integral_a^b U_sigma(tau_j(y,L))dL/L]. (G6)

The sum retains the original exact outer source/seed weights. Different j are not declared source-disjoint. Actual original full e, low/high masks and forbidden sets remain unchanged on the left; enlargements on the right are positive only. The outside Lambda is paid once.

(G6) gives a density-free source-profile bound for the actual traffic. It improves the previous A_n D bound by charging only the unsaturated profile tail across scales; (G4)-(G5) give explicit sharper receipts when the terminal level is controlled. It does NOT guarantee such control for every arbitrary L1 source, especially if the frozen terminal remaining mass is zero. Full original high-m/root refinements and all ratio-band costs require the precise companion proof, not an assumed cap.

## 6. Verification and remaining task

Independent audit screened (G1)-(G3) before this proof was written. Local numerical work tests exact finite meshes, hard-face equality, cap jumps/zeros, and the continuous radial-step integral in three parameter stages. Numerical outputs are finite diagnostics and do not prove arbitrary-input closure.

The main new estimate is (G1), with the dimension-free scale prefactor in (G5). The remaining question is a global source-conserving use of these receipts, preserving actual ratio bands, original high-m thresholds and boundary/deletion costs. No generic source-density bound or endpoint convolution theorem is assumed. The original general n^(1/2+o(1)) weak bound is not asserted.
