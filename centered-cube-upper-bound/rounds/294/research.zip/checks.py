#!/usr/bin/env python3
"""R294 ray-step profile check in exact cube-volume coordinates; mpmath required."""
import json,random
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
R=random.Random(29420261018)
def mm(x):return mp.mpf(x.numerator)/x.denominator

def profile(n,widths,inc):
 V=[w**n for w in widths];heights=[sum(inc[j:]) for j in range(len(inc))]
 return V,heights

def DU(V,H,tau):
 D=F(0);U=F(0);prev=F(0)
 for v,h in zip(V,H):
  D+=min(h,tau)*(v-prev)
  if h<tau:U+=h*(v-prev)
  prev=v
 return D,U

def finite(n,V,H,times,caps):
 breaks=sorted(set([F(0)]+[t**n*v for t in times for v in V]));integral=F(0);eq=0;checks=0
 for lo,hi in zip(breaks,breaks[1:]):
  v=(lo+hi)/2;ps=[]
  for t,A in zip(times,caps):
   ht=next((h for vv,h in zip(V,H) if v<t**n*vv),F(0));ps.append(ht/t**n)
  fs=[min(p,A) for p,A in zip(ps,caps)];integral+=max(fs)*(hi-lo)
  for i in range(len(times)-1):
   q=(times[i+1]/times[i])**n
   assert ps[i]<=q*ps[i+1]
   extra=(q-1)*ps[i+1] if ps[i+1]<caps[i+1] else F(0)
   assert fs[i]<=fs[i+1]+extra;checks+=1
   if ps[i+1]==caps[i+1] and ps[i+1]>0:eq+=1
 D,_=DU(V,H,times[-1]**n*caps[-1]);bound=D
 for i in range(len(times)-1):bound+=((times[i+1]/times[i])**n-1)*DU(V,H,times[i+1]**n*caps[i+1])[1]
 assert integral<=bound
 return integral,bound,checks,eq

def continuous_pieces(n,V,H,times,caps):
 # At fixed scale endpoints: constant radial annuli. At each moving H jump:
 # p_t=h_j V_j/v; its local max is min(h_j V_j/v,A_interval).
 candidates=[]
 for t,A in zip(times,caps):
  prev=F(0)
  for v,h in zip(V,H):
   candidates.append((t**n*prev,t**n*v,min(h/t**n,A),0));prev=v
 for i in range(len(times)-1):
  for v,h in zip(V,H):candidates.append((times[i]**n*v,times[i+1]**n*v,h*v,caps[i]))
 points={F(0)}
 for lo,hi,c,A in candidates:
  points.update([lo,hi])
  if A and lo<c/A<hi:points.add(c/A)
 points=sorted(points);pieces=[]
 def form(cand,x):
  lo,hi,c,A=cand
  if not lo<x<hi:return F(0),0
  if not A:return c,0 # Fixed-scale candidate encoded A=0, already cap-clipped.
  return (A,0) if c/x>=A else (c,1)
 # Ambiguity: moving candidates with A=0 must contribute zero, not c.
 fixed=len(times)*len(V)
 def forms(x):
  out=[]
  for k,cand in enumerate(candidates):
   if k>=fixed and cand[3]==0:out.append((F(0),0))
   else:out.append(form(cand,x))
  return out
 def val(f,x):return f[0]/x if f[1] else f[0]
 for lo,hi in zip(points,points[1:]):
  mid=(lo+hi)/2;fs=forms(mid);extra=[]
  consts=[c for c,p in fs if not p and c];invs=[c for c,p in fs if p and c]
  # Only maximum constant and maximum inverse coefficient can determine the envelope.
  if consts and invs:
   cross=max(invs)/max(consts)
   if lo<cross<hi:extra=[cross]
  sub=[lo]+extra+[hi]
  for a,b in zip(sub,sub[1:]):
   x=(a+b)/2;best=max(forms(x),key=lambda f:val(f,x));pieces.append((a,b,*best))
 return pieces

def evaluate(case,dp,pieces):
 n,V,H,times,caps=case
 with mp.workdps(dp):
  endpoint=DU(V,H,times[-1]**n*caps[-1])[0];new=mm(endpoint)
  for i,A in enumerate(caps[:-1]):
   if not A:continue
   left=n*mp.log(mm(times[i]));right=n*mp.log(mm(times[i+1]));prev=F(0)
   for v,h in zip(V,H):
    cross=mp.log(mm(h/A));new+=mm(h*(v-prev))*max(mp.mpf(0),right-max(left,cross));prev=v
  old=mm(endpoint)*(1+n*mp.log(mm(times[-1]/times[0])))
  actual=sum(mm(c)*(mp.log(mm(b/a)) if power else mm(b-a)) for a,b,c,power in pieces if c)
  assert actual<=new+mp.mpf('1e-28')*max(1,new)
  assert new<=old+mp.mpf('1e-28')*max(1,old)
  tau=times[-1]**n*caps[-1];total_log=n*mp.log(mm(times[-1]/times[0]));tail_cap=mp.mpf(0);prev=F(0)
  for v,h in zip(V,H):
   tail_cap+=mm(h*(v-prev))*min(total_log,max(mp.mpf(0),mp.log(mm(tau/h)))) if tau else mp.mpf(0);prev=v
  tail=new-mm(endpoint);assert tail<=tail_cap+mp.mpf('1e-28')*max(1,tail_cap)
  receipts=[]
  for ds in ['.1','.5','.9']:
   delta=mp.mpf(ds);prev=F(0);moment=mp.mpf(0)
   for v,h in zip(V,H):moment+=mm(h)**(1-delta)*mm(v-prev);prev=v
   budget=mm(tau)**delta*moment if tau else mp.mpf(0)
   assert tail_cap<=budget/delta+mp.mpf('1e-28')*max(1,budget/delta)
   assert mm(endpoint)<=budget+mp.mpf('1e-28')*max(1,budget)
   receipt=(1+1/delta)*budget
   assert new<=receipt+mp.mpf('1e-28')*max(1,receipt);receipts.append(receipt)
  return tuple(+x for x in [actual,new,old,tail_cap,min(receipts)])

def makecase(n,kind):
 times=[F(1),F(3,2),F(2)]
 if kind=='lowcap_saving':V,H=profile(n,[F(1)],[F(1)]);caps=[F(0),F(1,2*2**n),F(1,2*2**n)]
 elif kind=='equality':V,H=profile(n,[F(1)],[F(1)]);caps=[F(1,2**n)]*3
 elif kind=='jump_equality':
  V,H=profile(n,[F(1,2),F(1),F(2)],[F(1),F(2),F(1)]);cap=H[0]/times[1]**n;caps=[F(0),cap,cap*2]
 else:
  widths=sorted(set([F(1,2),F(R.randint(2,6),2),F(3)]));inc=[F(R.randint(1,6),R.randint(1,4))*F(10)**R.randint(-5,5) for _ in widths];V,H=profile(n,widths,inc)
  raw=sorted([F(R.randint(0,20),R.randint(1,5)) for _ in times]);caps=[x/times[-1]**n for x in raw]
 return n,V,H,times,caps

def stage(ns,count):
 cases=[]
 for n in ns:
  for kind in ['lowcap_saving','equality','jump_equality']:cases.append((kind,makecase(n,kind)))
 for j in range(count):cases.append(('random',makecase(ns[j%len(ns)],'random')))
 checks=0;equals=0;pe=mp.mpf(0);maxratio=mp.mpf(0);rows=[];piececount=0;momentratio=mp.mpf(0)
 for kind,case in cases:
  n,V,H,times,caps=case;assert all(caps[i]<=caps[i+1] for i in range(len(caps)-1))
  finiteint,discrete,c,e=finite(n,V,H,times,caps);checks+=c;equals+=e
  pieces=continuous_pieces(n,V,H,times,caps);piececount+=len(pieces)
  low=evaluate(case,40,pieces);high=evaluate(case,60,pieces)
  with mp.workdps(100):
   err=max(abs(x-y)/max(1,abs(y)) for x,y in zip(low,high));assert err<mp.mpf('1e-27');pe=max(pe,err)
   assert mm(finiteint)<=high[0]+mp.mpf('1e-28')*max(1,high[0])
   if high[1]:maxratio=max(maxratio,high[0]/high[1])
   if high[4]:momentratio=max(momentratio,high[1]/high[4])
   if kind=='lowcap_saving':
    assert abs(high[0]-high[1])<mp.mpf('1e-28');rows.append({'n':n,'actual_continuous_sup_integral':mp.nstr(high[0],20),'new_tail_bound':mp.nstr(high[1],20),'old_endpoint_bound':mp.nstr(high[2],20),'old_over_new':mp.nstr(high[2]/high[1],20)})
 return {'cases':len(cases),'dimensions':ns,'finite_exact_supremum_cases':len(cases),'exact_one_step_pointwise_checks':checks,'positive_p_equals_cap_strict_indicator_cases':equals,'rational_continuous_envelope_pieces':piececount,'precision_runs':2*len(cases),'max_normalized_40_vs_60_error':mp.nstr(pe,12),'max_actual_to_new_bound_ratio':mp.nstr(maxratio,12),'moment_deltas':['1/10','1/2','9/10'],'moment_receipt_checks':3*len(cases),'max_new_to_best_moment_receipt_ratio':mp.nstr(momentratio,12),'max_discrete_or_continuous_or_moment_violation':'0','actual_savings_examples':rows}
settings=[('initial',[1,2,3],4),('hardedge_equality_jump_stress',[1,4,8,16],8),('expanded',[1,32,64,128,512,1000],12)]
stages=[dict(name=name,**stage(ns,count)) for name,ns,count in settings]
out={'status':'PASS','seed':29420261018,'scope':'Finite exact Fraction step-profile and scale-menu diagnostics; exact rational breakpoints for the actual continuous scale supremum integrated by40/60 logarithmic antiderivatives. H is a sum of positive centered cube indicators and A a nonnegative nondecreasing step function. No FULL/source closure or general theorem certificate.','volume_coordinate':'v=(2||x||infinity)^n, radial volume measure dv','new_bound':'D(b^n A(b))+n integral_a^b U(t^n A(t))dt/t, U(u)=integral H 1{H<u}','discrete_bound':'D(t_last^n A_last)+sum_i[(t_next/t_i)^n-1] U(t_next^n A_next)','old_bound':'D(b^n A(b))*(1+n log(b/a))','moment_bridge':'n integral U(tau(t))dt/t<=integral H min(nlog(b/a),log_+(tau_b/H))<=tau_b^delta/delta integral H^(1-delta); whole envelope<=(1+1/delta)tau_b^delta integral H^(1-delta)','stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
