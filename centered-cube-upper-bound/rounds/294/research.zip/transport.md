# R294 — source-conserving cube averaging, legal scale transport, and its remaining concentration cost

## 1. Screen and bounded conclusion

For an arbitrary integrable ray-decreasing profile V<=1, its mass D alone does not control translation by a source-block width. For example, V may be the indicator of a very thin rectangle containing zero. In dimension at least two, keep its volume D fixed by lengthening another side. For a shift in the thin direction, V(0)=1 but V(-u/(L+d))=0, however large a fixed multiplicative comparison constant is. Thus ray monotonicity proves dilation comparisons, but not source-translation comparisons. The same issue occurs for translated upper profiles: the mass of sup_{u in Q_d}V(.+u) need not be bounded by a dimension-free multiple of D.

For the ACTUAL R293 profile there is extra structure. This note proves a quantitative transport lemma for that profile and for the original selected soft/hard kernels. Uniform cube averaging of side d conserves both source masses. After changing each physical scale L to L+d, the product cost is at most

    C_d=(1+d/a)^(2n) exp(4n sigma d/a)
       <=exp((2+4sigma)nd/a).                            (1)

Hence d<=a/n gives C_d<=e^6. This holds for arbitrary positive L1 sources and actual variable scale selectors, not only fixed-scale special inputs. Actual same-receiver caps transfer only with the explicit additional future-scale caps in Section 4. Upper physical boundary strips have independent original-source payments in Section 6.

This transport does not yet remove R293's source-concentration fee. At its dimension-free width d=O(a/n), conservation only gives density W/d^n, which can be much too large. Section 7 states the exact remaining premise. No global root source closure is asserted.

## 2. A shift–dilation inequality for the actual soft family

Use Q_d=[-d/2,d/2]^n, h=1_{[-1/2,1/2]},

    w(t)=integral_0^1 exp(-|t|/r)dr,
    phi=h*w, f_s=(1-s)h+s phi,
    P_(s,L)(x)=L^(-n) product_i f_s(x_i/L).

These are the R293 kernels. The probability density phi is even and decreasing on the positive half-line. Moreover

    |phi'|<=1,
    c:=phi(1/2)=integral_0^1 r(1-exp(-1/r))dr
       >=(1-exp(-1))/2>1/4.

On the hard core [-1/2,1/2], f_s>=c and |f_s'|<=s, so log f_s is 4s-Lipschitz there. At s=0 the core value is one. Boundary values can be taken with the closed hard interval; boundary conventions do not affect source integrals for L1 densities.

Let L,d>0 and |u|<=d/2 in one dimension. For |x|>=L/2,

    |(x-u)/(L+d)| <= |x|/L.

Even monotonicity therefore gives f_s(x/L)<=f_s((x-u)/(L+d)) whenever the old point is outside the core; the new hard indicator can only add a positive term. For |x|<=L/2, both normalized points are in the core and

    |x/L-(x-u)/(L+d)|<=d/(L+d).

The preceding log bound applies. Multiplying the coordinate inequalities proves, for every u in Q_d,

    P_(s,L)(x)
       <=chi_s(L,d) P_(s,L+d)(x-u),
    chi_s(L,d):=(1+d/L)^n exp(4nsd/(L+d)).                (2)

Also, for the normalized hard cube kernel h_R,

    h_R(x)<=(1+d/R)^n h_(R+d)(x-u).                      (3)

The constant in (3) includes the actual normalization loss; this loss is not erased by source conservation.

For the common-soft clipped profile of R293,

    H_sigma(x)=sup_{0<=s<=sigma} product_i f_s(x_i),
    V(x)=min(H_sigma(x),tau),
    V_L(x)=L^(-n)V(x/L),

take the SAME common s supremum in the unnormalized version of (2), then clip by the SAME tau. Since min(Cz,tau)<=C min(z,tau) for C>=1, this proves

    V_L(x)<=chi_sigma(L,d)V_(L+d)(x-u).                  (4)

No independent-coordinate softness, convexity, or coordinatewise core-flatness assertion is needed. Equation (4) uses more than ray monotonicity; it is not claimed for general V from Section 1.

## 3. Exact source conservation and response comparison

Let U_d=d^(-n)1_{Q_d}, and define

    beta^d=beta*U_d, nu^d=nu*U_d.

The coupling beta(dy)U_d(u)du sends y to y+u, and similarly for nu. Nonnegative Tonelli gives EXACTLY

    W_(beta^d)=W_beta, W_(nu^d)=W_nu.                    (5)

Averaging (2) over this coupling gives, at every receiver where the integrals are defined,

    (P_(s,L)*beta)(x)
       <=chi_s(L,d)(P_(s,L+d)*beta^d)(x).               (6)

Applying (2) with the shift of the opposite sign also gives

    (P_(s,T)*beta^d)(x)
       <=chi_s(T,d)(P_(s,T+d)*beta)(x).                 (7)

Both statements have hard analogues with chi_h(T,d)=(1+d/T)^n. They are pointwise in s,L,T and therefore apply to arbitrary measurable receiver-dependent selectors. Finite sources and bounded physical kernels make all these responses finite. Positivity justifies all averages on infinite receiver domains.

For a selected original edge (y,z,x,s,L,R), equations (2)-(3) give, for EVERY u,v in Q_d,

    P_(s,L)(x-y) h_R(x-z)
       <=chi_s(L,d)chi_h(R,d)
          P_(s,L+d)(x-y-u)h_(R+d)(x-z-v).              (8)

For a<=L,R and s<=sigma this coefficient is <=C_d from (1). The same statement holds with P_(s,L) replaced by V_L, by (4).

All original e_g, m, q, low-pe, source, and history masks may be retained on the lifted OLD coordinates (x,y,z,u,v). They are not recomputed from beta^d or nu^d. Dropping those masks after (8) is a positive enlargement. It can lose useful original geometry, but cannot fabricate a new low-pe condition or a new FIRST identity. The denominator q(x) stays the original one.

## 4. Exactly which caps transport

An actual cap at the selected old scale L alone does not imply a cap at L+d. Here is the sufficient, explicit future-cap premise. At the SAME receiver x and softness s, assume the ORIGINAL source obeys

    (P_(s,L+2d)*beta)(x)<=q(x),
    (h_(R+2d)*nu)(x)<=4lambda.                          (9)

Then (7), at T=L+d and T=R+d, proves

    (P_(s,L+d)*beta^d)(x)<=chi_s(L+d,d)q(x),
    (h_(R+d)*nu^d)(x)<=chi_h(R+d,d)4lambda.             (10)

The two factors are respectively at most exp((1+4sigma)nd/a) and exp(nd/a). If the original full future FIRST and hard maximal cap supply (9), these are legitimate inherited upper caps. If FIRST only supplies the original selected response <=q, the first premise of (9) is a missing hypothesis and (10) must not be invoked.

Restricting L,R<=b-2d keeps all scales in (9) and (10) inside the original physical window [a,b]. No cap is granted above b. The soft menu must actually admit the same s at L+2d; this too is part of (9). The original accepted hard cap over every R in [a,b] does supply its displayed hard premise.

Only upper caps, with the displayed factors, transfer. No equality, new selector minimality, or new FIRST for averaged sources is proved. In particular the envelope V_L is not the actual selected soft response; (4) supplies no FIRST cap for V_L.

## 5. Transporting the original column and its ratio band

Write gamma=1+1/n and c_j=gamma^(-j). For an actual unique band use the half-open rule

    v:=|log(L/R)| in [2j log gamma,2(j+1)log gamma),

with the last finite endpoint closed. This is equivalent to the R293 min(L,R)/sqrt(LR) band. Put L'=L+d, R'=R+d, g=sqrt(LR), g'=sqrt(L'R'). Then

    g+d<=g'<=(1+d/a)g,
    0<=v-v'<=d|L-R|/(LR)<=d/a.                         (11)

The first inequality follows from L+R>=2sqrt(LR); the logarithmic inequality follows by integrating the derivative of log((L+t)/(R+t)). Since b<=2a, the last estimate is valid (indeed it can be sharpened). If d<=a/n, then d/a<2log gamma. Thus the new actual band is j or j-1; at j=0 it stays zero. Closed relaxed band envelopes cause no issue, since they contain these uniquely assigned scales.

Let Gamma_(j,int)^V(t;y,z) be the R293 column with the additional L,R<=b-2d restriction. Define Gamma_k^V at any nonnegative threshold by the same original physical menu, with zero for an empty menu. Equations (4), (3), and (11), pointwise BEFORE supremum and receiver integration, imply

    Gamma_(j,int)^V(t;y,z)
       <=C_d [Gamma_j^V(t+d;y+u,z+v)
                  +Gamma_(j-1)^V(t+d;y+u,z+v)]          (12)

for every u,v in Q_d, omitting j-1 at zero. Here the shift variable v in z+v is a vector; the scalar log ratio in (11) is only notation local to that equation.

Crucially BOTH terms on the right use the OLD fixed V, sigma and tau. The term with index j-1 is a geometric band envelope, not the default R292 clipped profile or threshold assigned to a different original band. All old labels and masks remain on the old coupling. No new low-pe claim is made.

Averaging (12) against the mass-preserving couplings gives

    integral beta(dy)nu(dz) Gamma_(j,int)^V(t;y,z)
       <=C_d integral beta^d(dy')nu^d(dz')
                    [Gamma_j^V(t+d;y',z')
                         +Gamma_(j-1)^V(t+d;y',z')].    (13)

Source conservation is exact, and the two target band envelopes are an explicit two-term cost. They are not disjoint new source allocations. Any subsequent sum over old j must retain its original coefficients. The proof uses finite bounded columns; their pair integrals are finite for finite sources. This avoids uncapped homogeneous convolution entirely.

## 6. Legal removal of the upper boundary strips

This section concerns the original raw receiver traffic, without its outside Lambda or other score. Assume the original actual response F=P_(s,L)*beta<=q, q>=3lambda/4, and h_R*nu<=4lambda at the actual receivers, as in R293. Keep all old masks until a positive upper bound is taken. Put B=b-2d.

For any ray-decreasing probability profile W, positive level sets and radial scaling give

    integral sup_(B<=T<=b) T^(-n)W(x/T)dx
       <=1+n log(b/B)                                  (14)

when B>0. For a star-shaped indicator the expression is its volume times this factor: integrate the core at B and the radial T^(-n) tail up to b. Layer cake proves (14) for W, since supremum may be moved inside the positive level integral only as an upper bound. Equality holds for the hard cube profile.

If B<a, then b-a<2d, and the WHOLE raw traffic is paid directly using original FIRST and the hard point-scale envelope:

    T<= [1+n log(b/a)]W_nu <=(1+2nd/a)W_nu.             (15)

Suppose B>=a. Split the ORIGINAL traffic disjointly first by R>B, then by R<=B and L>B, then the interior. On the first piece original FIRST gives

    T_(R>B)<=A_top W_nu,
    A_top:=1+n log(b/B)<=1+2nd/a.                       (16)

On the second piece use the ORIGINAL hard cap divided by q, hence the factor 16/3, before extending the receiver integral. The common-soft positive binomial envelope from R293 Section 3 has mass

    Csoft_n=sum_k max_s binom(n,k)s^k(1-s)^(n-k)
             <=1+(pi/2)sqrt(n).

Each constituent probability profile is ray-decreasing, so (14) gives

    T_(R<=B,L>B)<=(16/3)Csoft_n A_top W_beta.            (17)

Thus for d<=a/n, A_top<=3 and the two strips cost at most

    3W_nu+16 Csoft_n W_beta.                            (18)

These are source-linear original-cap payments. No cap above b, no transported FIRST, and no claim of density control is used. If the original traffic has the outside factor Lambda, multiply (15)-(18) by that factor ONCE. A separate clock/score is not inserted into these raw estimates.

Consequently the small transport width does not require an unpaid physical upper-boundary extension. It still requires (9) on the surviving interior if one wants transferred soft caps.

## 7. The precise unsolved source premise

Cube averaging proves only

    ||beta^d||_infinity<=W_beta/d^n,
    ||nu^d||_infinity<=W_nu/d^n.                        (19)

These bounds follow exactly from the convolution definition and can be nearly attained by a source concentrated in a much smaller cube. They are not density bounds relative to q or lambda. The original receiver cap, available only at actual receivers, supplies no general source-center bound. Even a GLOBAL original hard cap would at best give the elementary estimate 4lambda(a/d)^n for d<a by placing Q_d inside Q_a. At d=a/n this still costs n^n.

For comparison with the existing R293 receipt, put H0=a^(-n)A_n and K=4gamma^n D. Inserting the generic density from (19) into that receipt leaves the exact ratio

    H0 W_beta / [K(W_beta/d^n)]
       =A_n(d/a)^n/K.                                  (20)

Whenever (20)<=1, its cap/weak/density receipt is simply H0 W_beta: averaging has produced no weak-column gain. This happens in particular at fine width d=a/n whenever K>=A_n n^(-n), including the full hard profile. If K is smaller, one must retain the exact R293 formula; no contrary general assertion is made. Taking d comparable to a to reduce the density can instead make the response normalization (1+d/a)^n exponential and can consume the entire legal physical window.

This normalization is a real geometric loss for cube dilation. A source concentrated near zero and a central receiver have hard response approximately mL^(-n); after averaging into Q_d, the scale L+d still captures all the mass and has response m(L+d)^(-n). Their ratio approaches (1+d/L)^n. Without dilation, a receiver near a corner of Q_L captures only about 2^(-n) of a symmetrically smoothed tiny source. The latter example can satisfy the hard cap globally by taking m<=4lambda a^n. It diagnoses the transport step, not a complete original-history counterexample.

A sufficient missing bridge is therefore a source-conserving redistribution or allocation that proves BOTH:

* legal all-selector response comparison and inherited original caps at dimension-free or polylog cost; and
* a useful bound on the resulting ORIGINAL source concentration charge, or a density/local-mass bound with its exact dimension and mass costs, strong enough for the R293 source receipt.

Equations (2)-(18) give the first item at width O(a/n), subject to the explicitly stated future soft-cap premise. Equation (19) does not give the second item. Alternatively one could directly pay the mismatch between unsmoothed and coarsely smoothed sources with the actual caps; no such payment is proved here. The unsolved issue is this simultaneous scale-and-concentration control, not a renamed E^- tail or an endpoint convolution estimate.

## 8. Actual finite diagnostics and ownership

A local Python/mpmath run at 40 digits checked 1,935 one-dimensional shift–dilation inequalities, including s=0,1/1024,1/16,1/2,1, shifts at both cube endpoints, points inside/outside/on the hard boundary, and d/L=0.001,0.1,1. All passed; the largest normalized left/right ratio was 1. It also checked (11) and 1/n<2log(1+1/n) for n=1,2,3,16,1024,1000000. The computed phi(1/2) was 0.3903080328022398631614181, above the analytic lower bound 0.3160602794142788392022381. These finite scalar diagnostics are supplementary; Sections 2-6 supply the proofs. An initial diagnostic mixed Fraction and mpf comparison types and was corrected before the successful run.

Only this temporary Markdown deliverable was written. The inputs were R293 column geometry Sections 1-5 and source transfer Sections 1-4; no other author file, repository, or Git state was changed.
