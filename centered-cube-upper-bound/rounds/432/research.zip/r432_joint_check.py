from fractions import Fraction as F
from itertools import product

def length(I):return max(F(0),I[1]-I[0])
def intersect(*ints):return max(F(0),min(I[1] for I in ints)-max(I[0] for I in ints))
def exp_bounds(x,N=80):
    assert x>=0 and x<N+2
    term=lo=F(1)
    for k in range(1,N+1):term*=x/k;lo+=term
    first=term*x/(N+1)
    return lo,lo+first/(1-x/F(N+2))
def log2_lower(N=80):
    z=F(1,3)
    return sum(2*z**(2*k+1)/F(2*k+1) for k in range(N))
An_lo=1+log2_lower()
rows=[((-F(3,10),-F(1,5)),F(1)),((-F(1,10),F(0)),F(3,2)),((F(1,5),F(3,10)),F(2))]
# Complete f=1[-4,4]+25*spike*1[-1/50,1/50]; total added mass=spike.
def native_kernel(y,z,L,spike):
    val=F(0); positive=0
    for I,R in rows:
        assert I[1]-R/2<=-F(1,50) and I[0]+R/2>=F(1,50)
        assert I[0]-R/2>=-4 and I[1]+R/2<=4
        m=R+spike;q=m/R
        assert 1<=q<=F(4,3)
        vol=intersect(I,(y-R/2,y+R/2),(z-R/2,z+R/2))
        if m>L:
            val+=vol*q/(m*m);positive+=int(vol>0)
    D=abs(y-z)/2
    _,exhi=exp_bounds(D)
    assert L*exhi*val<=An_lo
    if abs(y-z)>2:assert val==0
    return positive>0
stages=[[(F(0),F(0),F(1,2),F(0)),(F(0),F(2,5),F(1),F(0)),(F(-1),F(1),F(1,2),F(1,10))],
        [(F(0),F(2,5),F(11,10),F(1,10)),(F(0),F(2,5),F(8,5),F(1,10)),(F(0),F(2,5),F(21,10),F(1,10))],
        [(F(-1,10),F(4,5),F(9,10),F(1,4)),(F(-1),F(6,5),F(1,2),F(1,4)),(F(1,4),F(9,10),F(7,4),F(1,4))]]
positive=0
for batch in stages:
    for args in batch:positive+=native_kernel(*args)
# Continuous source-local Schur identity: cells of width 1/10, spacings 10,
# b=2. Thus V(y)=mass of its own cell, and |y-z|<=b iff same cell.
source_checks=0
for masses in [[F(1),F(2),F(3)],[F(1,10),F(7,3),F(10)],[F(9),F(1),F(1,100)]]:
    W=sum(masses)
    local=sum(m*m/m for m in masses)
    global_price=sum(m*m/W for m in masses)
    assert local==W and global_price<=W
    assert all(m<=W for m in masses)
    source_checks+=1
# More general finite source marginal capacity test, an exact scalar interface:
# pair neighborhood includes every diagonal, symmetric; V_y=sum neighboring f.
# No geometric claim for these matrices.
weighted_checks=0
for masses in [[F(1),F(2),F(3)],[F(1,10),F(7,3),F(10)]]:
    for edges in product([0,1],repeat=3):
        C=[[int(i==j) for j in range(3)] for i in range(3)]
        for e,(i,j) in zip(edges,[(0,1),(0,2),(1,2)]):C[i][j]=C[j][i]=e
        V=[sum(C[i][j]*masses[j] for j in range(3)) for i in range(3)]
        val=sum(C[i][j]*masses[i]*masses[j]/max(V[i],V[j]) for i in range(3) for j in range(3))
        assert val<=sum(masses)
        weighted_checks+=1
print(f'PASS: native joint-center kernel 3/3/3={sum(map(len,stages))} cases ({positive} positive); continuous source-cell identities {source_checks}; finite weighted-interface checks {weighted_checks}.')
print('Native selector uses actual positive Lebesgue intervals, complete nonuniform f, q-band and strict mass cutoff. Not complete original stage/history/path fixtures.')
print('Source-cell tests verify only the local-mass integration interface; finite matrices are scalar checks, not cube models.')
print('Exponential upper and log(2) lower bounds are certified rational Taylor/atanh bounds.')
