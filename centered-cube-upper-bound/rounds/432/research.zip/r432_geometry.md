# R432：实际质量比自适应邻域的全尾中心预算

2026-10-20。主收据支付原 R431 上“至少一个 proper 节点进入自适应父邻域”的实际正分支，来源价为 \(2\Omega_{\rm cf}W\)，不新增 \(X_q\)。邻域取决于实际父、目标质量比，接近整父尺度；其中心预算对整个质量尾一次可和。累计原核风险有同一个一阶矩上界，但本附件不再为风险阈值另收费用。全余项仍未闭合。

## 1. 冻结对象与可检验命题

原 R431 场及原正流不变：
\[
m_v=f(Q_v)=q_vR_v^n,\quad q=q_-\le q_v\le\lambda,\quad
a\le R_v\le b\le2a,
\]
\[
\rho_x(dv)=c_v(x)\frac{dv}{m_v},\quad
\pi_A(dx)=\frac{f(x)c_A(x)}{m_A}dx,\quad
\sigma(dA)=q_A\,dA,\quad W=\int f.
\]
\(R_v\) 是立方体边长，\(A,v\) 均为真实 Lebesgue 接收中心。令
\[
\ell=\sqrt n,\quad K=e^\ell,\quad s=1+\ell,\quad
h=s/(\varepsilon _0q),\quad r=\lambda/q,\quad
M=J_*/h,\quad J_*=(1+n\log(b/a))/q.
\]
沿用 \(n\ge9,\ 0<\varepsilon _0\le1/2\)、\(S=\beta+C_{\rm col}\) 及 R431 全部原阶段、来源、时钟、首次删除、soft、路径及父质量标签。其正流记 \(\Pi431\)，总质量为 \(R431\)。特别地，每条原路径有
\[
m_A>K^2m_{v_0},\qquad m_{v_j}<m_{v_{j-1}}/K.
\tag{1}
\]
两路径仍各自保留原来源。它们只在原完整初始记录给定后的 raw 生成法下独立，不声称经过全部正限制后仍独立。

本轮固定以下 profile，不作参数优化：
\[
\mathfrak b(R)=\frac{R}{(1+\tfrac12\log R)^2},\qquad R\ge1.
\tag{2}
\]
对 proper 目标代数 \(j\ge1\)、真实目标 \(u\)，令
\[
H_j(u)=K^{j+2}m_u.
\]
当 \(m_A>H_j(u)\) 时定义
\[
\alpha_{B,j}(A,u)^n
=sK^{j+2}\mathfrak b\!\left(\frac{m_A}{H_j(u)}\right).
\tag{3}
\]
自适应目标事件为
\[
\mathcal N^B_j(A)=
\{u:m_A>H_j(u),\ A\in\alpha_{B,j}(A,u)Q_u\}.
\tag{4}
\]
质量等号不在 (4) 中；\(m_A\le H_j(u)\) 时不需要定义 (3)。

令
\[
N_B=\sum_{\text{两条来源路径}}\sum_{j=1}^{T_x}
1_{\mathcal N^B_j(A)}(v_j),
\tag{5}
\]
包括首次进入终端的一跳，不包括初始节点，也不在终止后重复计数。原 raw 前缀核下的概率及累计强度是
\[
p^B_j(A,x,v)=P_x(v,\mathcal N^B_j(A)),\qquad
\mathcal C_B=\sum_{x}\sum_{j=1}^{T_x}p^B_j(A,x,v_{j-1}).
\tag{6}
\]
它们没有按未来保留事件重新条件化。

**主命题：**
\[
\boxed{\ \int N_B\,d\Pi431\le2\Omega_{\rm cf}W,\qquad
\int\mathcal C_B\,d\Pi431\le2\Omega_{\rm cf}W.\ }
\tag{7}
\]
这里恰是 R431 的已有常数
\[
\Omega_{\rm cf}
=2Sr\,s[\Psi(M)+(1+\varepsilon _0)\Theta(M)],
\tag{8}
\]
\(\Theta(M)=\sum_{j\ge1}\min(1,M2^{-(j-1)})\)，
\(\Psi(M)=\sum_{k\ge0}\int_1^M u^{-1}\min(1,M/(2^ku))\,du\)；
\(M\le1\) 时令 \(\Psi=0\)，实际 active 输入为空。

式 (7) 的两个界是两种工具，不是可以免费叠加的两份信用。主账仅使用第一式支付 \(N_B\ge1\)。

## 2. 全质量尾的真实中心引理

固定真实目标 \(u\)、来源点 \(x\)、数 \(H,c>0\)。设 \(\mathfrak b:[1,\infty)\to[0,\infty)\) 可测非减，且
\[
\mathcal I_{\mathfrak b}=\int_1^\infty\mathfrak b(v)v^{-2}\,dv<\infty.
\]
在同一个任意可测实际选择器上，
\[
\begin{aligned}
&\int_E\frac{q_Ac_A(x)}{m_A}
1_{\{m_A>H,\ A\in[c\mathfrak b(m_A/H)]^{1/n}Q_u\}}\,dA\\
&\hspace{15mm}\le
\frac{\lambda cR_u^n}{H}\mathcal I_{\mathfrak b}.
\end{aligned}
\tag{9}
\]

证明使用实际质量的 layer cake：
\[
m_A^{-1}=\int_{m_A}^{\infty}r^{-2}\,dr.
\]
固定 \(r>H\)，被积父必须满足 \(H<m_A\le r\)。单调性保证其中心属于
\([c\mathfrak b(r/H)]^{1/n}Q_u\)，体积不超过
\(cR_u^n\mathfrak b(r/H)\)。以 \(q_A\le\lambda,c_A(x)\le1\) 上界并作非负换序，得到 (9)。

这里先保留了真实子水平条件 \(m_A=f(Q_A)\le r\)，随后仅以包含它的中心盒估计体积。没有将实际选择边长当成独立 \(dr\) 变量，没有以父体积估计任意来源质量，也没有把包络说成实际等式。实际质量原子不影响 Tonelli；原严格门 \(m_A>H\) 不被改为闭门。

对 (2)，
\[
\mathfrak b'(R)=
\frac{\tfrac12\log R}{(1+\tfrac12\log R)^3}\ge0,\quad
\mathfrak b(1)=1,\quad
\int_1^\infty\frac{\mathfrak b(R)}{R^2}dR
=\int_0^\infty(1+z/2)^{-2}dz=2.
\tag{10}
\]
若所有父质量另满足 \(m_A\le HT\), \(T>1\)，则 (9) 的常数还可替换为
\[
\int_1^T\frac{\mathfrak b(v)}{v^2}dv+
\frac{\mathfrak b(T)}T
=1+\left(1-\frac1{1+\tfrac12\log T}\right)^2\le2.
\tag{11}
\]
第二项不能省略：它是 layer cake 中 \(r\ge HT\) 的尾。\(T\downarrow1\) 时包络常数趋于 1，故不是一个遗漏基本中心盒的纯薄壳估计。若 \(T\le1\)，原严格质量支为空。

现在取 \(H=K^{j+2}m_u,\ c=sK^{j+2}\)，完整匹配给
\[
\boxed{\quad
\int_E\frac{q_Ac_A(x)}{m_A}
1_{\mathcal N^B_j(A)}(u)\,dA
\le\frac{2\lambda sR_u^n}{m_u}
=\frac{2\lambda s}{q_u}\le2rs.
\quad}
\tag{12}
\]
这是跨全部父质量尾的一次价格。临界线性扩张 \(\mathfrak b(R)=R\) 会使 (10) 发散；本轮固定对数校正恰保留有限总价，而非给每个质量窗再付一次。

## 3. 原流、可预测门和所有代数的来源结算

固定原阶段及完整初始记录。对每条 raw 路径保留前态指标
\[
I_{j-1}=1_{\{j\le T_x\}}
1_{\{m_A>K^{j+1}m_{v_{j-1}}\}}.
\tag{13}
\]
在 \(\Pi431\) 的实际路径上它等于该跳的 active 指标。若反事实下一跳 \(u\) 来自原严格 \(K\) 前缀，则
\[
I_{j-1}=1\ \Longrightarrow\
m_A>K^{j+1}m_{v_{j-1}}>K^{j+2}m_u.
\tag{14}
\]
因此 (4) 中的质量门对该反事实下一跳自动有效。它不需要继承任何未来历史、soft 或当前占用资格。

对于实际命中次数，先用 (13)，再正删除所有未来权 \(F\le1\)，有
\[
\mathbb E_{\rm raw}[F N_B]
\le
\mathbb E_{\rm raw}\sum_{x,j}I_{j-1}
1_{\mathcal N^B_j(A)}(v_j).
\tag{15}
\]
对累计概率则使用真正可预测的补偿：
\[
\mathbb E_{\rm raw}[F\mathcal C_B]
\le\mathbb E_{\rm raw}\sum_{x,j}I_{j-1}p^B_j
=\mathbb E_{\rm raw}\sum_{x,j}I_{j-1}
1_{\mathcal N^B_j(A)}(v_j).
\tag{16}
\]
不能把 (16) 最后的等号直接带上任意未来 \(F\)。两式保留原进入记录和 \(b_i\) 到阶段求和；不改变原实际流。严格质量下降和冻结质量范围保证有限深度；这是合法补偿的有限性理由，不是额外一层费用。

对每个 active 初始记录，R429 已证 exact-\(j\) 目标律在 active 部分满足
\[
Q_{x,j}(v_0,du)1_{\{Z_u>h\}}
\le\frac{\rho_x(du)}{T_u(x)}
\min\!\left(1,\frac{J(x)}{2^{j-1}T_u(x)}\right)
1_{\{Z_u>h\}}.
\tag{17}
\]
其源秩积分不超过 \(I_{j-1}(M)\)。完整质量原子位于 \(h\) 以上，因为 active 时 \(T_u^-\ge Z_u>h\)。终端部分由 R428 得
\[
Q_{x,j}^{\rm term}(v_0,du)
\le a_j\,1_{\{Z_u\le h\}}\rho_x(du)/h,\quad
a_j=\min(1,M2^{-(j-1)}),
\tag{18}
\]
且 \(\rho_x\{Z_u\le h\}\le(1+\varepsilon _0)h\)。

式 (17)、(18) 与初始记录一致，对初始子概率混合仍有效。将 (12) 代入，单个来源方向、第 \(j\) 代的来源价为
\[
2Sr\,s[I_{j-1}(M)+(1+\varepsilon _0)a_j]W.
\tag{19}
\]
这里原两父端 sourcewise 帽汇成一次 \(S\)；\(\sum_i b_i\le1\) 只在原共同阶段上使用。另一条 raw 路径质量至多 1，另一来源后验质量为 1，均仅在正上界中积分掉。初始总质量 \(SX_q\) 本身不能替代此逐来源合同。\(S\) 已含两个父端，不额外再乘 2；最后因子 2 仅来自两条有标签来源路径。

全部 \(j\ge1\) 和两路径求和得到 (7)。没有初始 Dirac，也没有 R429 的初始 \(2\log M\) 项；进入终端只计一次。无须实际路径避开新邻域，实际命中可以直接用 (15) 收费。

## 4. 实际新支、真实几何改进与完整费用

定义
\[
P_B=\Pi431[N_B\ge1],\qquad
\Pi^{\prime}=1_{\{N_B=0\}}\Pi431,\quad R^{\prime}=\Pi^{\prime}(1).
\]
由 (7)，
\[
\boxed{\quad R431=P_B+R^{\prime},\qquad
P_B\le2\Omega_{\rm cf}W.\quad}
\tag{20}
\]
本轮仅收费 (20)。风险矩 (7) 保留为工具；不另加 \(\mathcal C_B\) 阈值或其费用。原 R431 的 \(\mathcal C<\gamma\)、\(\mathcal P>t\)、全部原标签及父质量尾仍保留。

对任何剩余 proper 节点，由实际父子匹配，(3) 等价于
\[
\alpha_{B,j}(A,u)R_u
=R_A
\left[
\frac{s(q_A/q_u)}
{(1+\tfrac12\log(m_A/(K^{j+2}m_u)))^2}
\right]^{1/n}.
\tag{21}
\]
因此新补集满足真正父尺度的中心分离
\[
\frac{2\|A-u\|_\infty}{R_A}>
\left[
\frac{s(q_A/q_u)}
{(1+\tfrac12\log(m_A/(K^{j+2}m_u)))^2}
\right]^{1/n}
\ge\eta_n,
\tag{22}
\]
\[
D_{\max}=\log r+n\log(b/a),\qquad
\eta_n=\left[\frac{s}{r(1+D_{\max}/2)^2}\right]^{1/n}.
\]
只用了 \(0<\log(m_A/H_j(u))\le D_{\max}\)。若有任一 proper 节点，则 \(D_{\max}>3\sqrt n\)，所以该情形 \(\eta_n<1\)。固定原 \(r\)、octave 时 \(1-\eta_n=O(\log(n+2)/n)\)。没有 proper 节点的情形命中次数为零，不需要这一解释。

这是实际新中心几何：旧固定 \(\bar\alpha_j\) 的尺度只依赖代数，(21) 则随完整实际父质量尾扩大到接近整父尺度。它不是来源质量薄层估计；(22) 不控制集中 \(f\) 在边界的质量，也没有给新节点原历史资格。一般双来源余项仍未闭合。

仅本附件的中间账记
\[
C^{\prime}=C431,\qquad V^{\prime}=V431+2\Omega_{\rm cf}.
\]
所有原反馈和外项保持：
\[
G_0\le16\widehat F\{R^{\prime}+C431X_q+V^{\prime}W\},
\]
\[
B_H\le32\widehat F R^{\prime}
 +(E387+32\widehat F C431)X_q
 +(S390+8s+32\widehat F V^{\prime})W,
\]
\[
\mathrm{入口}\le\Lambda\{8\lambda HW+
2d_{\rm eff}A_{{\rm entrance},n}W_\nu/H+
64\widehat F R^{\prime}
 +(2E387+64\widehat F C431)X_q
 +(2S390+16s+64\widehat F V^{\prime})W\}.
\tag{23}
\]
新增入口价为 \(128\Lambda\widehat F\Omega_{\rm cf}W\)，无新增 \(X_q\)。旧 R428–431 来源费不退款、不重复扣减。本附件用带撇符号，组合主稿的最终 R432 还可有其他经过单独证明的顺序分支。

## 5. 实际三阶段证据及边界

实际运行 `/tmp/r432_geometry_check.py`，保存输出 `/tmp/r432_geometry.result.txt`。全程标准库 Fraction，指数、对数以解析余项作有理区间包围：

1. 9 个 profile/有限尾证书，从 \(R=1\) 到 \(2^{128}\)。核单调性对应的有理区间、(11) 两种公式、基本端点常数 1；无限面积 2 由 (10) 解析积分证明，不由有限数值外推。
2. 9 个 \(n=64,100,144\) 的真实连续中心模型。完整 \(f\) 是有界大盒的常数背景加中央正包；一个正体积小中心块选边长 1，其余父中心域选边长 2。全部质量由同一完整 \(f\) 精确计算，原 \(K=e^{\sqrt n}\) 保留。固定小端 \(u=x=0\)，新邻域内真实父体积以有理区间计算；9 例均严格大于原代数 \(j=1\) 的 \(\alpha_1\) 邻域，并满足相应单目标深父质量门。核 (12) 的真实中心积分。该模型没有认证两条完整路径、原占用阶段或全部原历史，故不声称原 \(P_B\) 在每个合法历史上必非空。
3. 9 个严格质量前缀双链模型，包含质量原子和严格等号检查。360 个自适应 profile 判定由有理区间认证；精确核 raw 可预测补偿、任意耦合未来正权下两个矩的上界、9 个正命中分支及 27 个风险阈值工具检查。此阶段是有限核证据，不冒充 Lebesgue 原生历史。

本轮实得的是 (9) 的一般实际中心全尾引理及 (20) 的根阶乘对数平方来源收据。仍缺的是在 (22) 的共同父尺度远离条件下，将保留原阶段、双来源及完整匹配的 \(R^{\prime}\) 联合结算；本附件没有用新的名字宣称该余项已经付款。
