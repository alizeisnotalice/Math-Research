# R432 独立最终审查

FINAL PASS（限定本轮）。已审最终主稿、几何稿、联合矩稿、README及三脚本，未发现必须修订的问题。通过范围是同一原Π431与列示继承合同下的自适应全尾中心容量、实际命中正分支及双来源局部质量—距离联合矩付款；不认证完整余流、全尺度或最终一般弱型上界。

## 必要证明与费用核对

- 非减profile g(R)=R/(1+½logR)² 的层积分为2。先保实际 m_A≤r 子水平，再以固定扩大盒包含中心域，Tonelli给2λcR_u^n/H。常数2已含底层贡献；有限上质量截断必须保 g(T)/T 尾项。实际选择器可变、严格质量原子与终端均没有被连续CDF假设替换。
- 目标依赖的H_j与邻域仍是原下一跳核可测集合。原前态I和strict跳保证所有反事实目标m_A>H_j；对实际命中与raw强度分别保I后正删未来权。均匀exact-j active/terminal界后，原逐来源阶段合同只计一次S，因子2仅两条路径。由此两个矩分别≤2ΩcfW；正式仅付actual N_g≥1，未重复付强度阈值。补集proper中心排斥公式及η_n界正确，不构成f薄边界质量界，不涵盖初始节点。
- 双来源父核先用完整匹配q_A/m_A²=1/(m_AR_A^n)，保边长b端base后得 A_n exp(−D)/L。H_mass虽依终端，父积分时固定来源与终端即可；原两生成链仅在完整初始记录给定后独立，未来限制正删除。两个exact-terminal-j,k一致次核可同时上放，初始子概率不重新归一。保共同父支持至最后的局部源积分，∫∫1_dist∞≤b ff/Vmax≤W，故不是两份W。局部量正性、W=0和零行均已处理。
- 在N_g=0上另付Z_joint≥A_n/s，两支互斥。ΔV=2Ωcf+Ss(1+ε0)²Θ²，C432=C431，V432=V431+ΔV；原Fhat、旧项及16/32/64系数完整保留，入口恰新增64ΛFhatΔVW，无新增X_q、退款或重复信用。固定列示参数依赖时根阶乘对数平方陈述正确；没有保证正支非空或固定比例。最终低联合指标交集仍未付。

## 实际复现与边界

在新隔离目录复制三脚本和MATLAB CSV，以系统python3分别执行，退出码均0；三个stdout与冻结结果逐字一致。另核CSV确有27行，独立核M及η公式；parent脚本按逐代积分加显式无限尾交叉核全部MATLAB费用。

保留分类：geometry为9个profile有理区间证书、9个真实full-f中心模型（n64/100/144）、9个有限双链模型/360判定/9正命中/27风险检查；joint为9连续中心核模型（6正）、3连续局部源积分及16标量接口；parent为18有理区间核与Decimal60诊断。复跑不增加模型数。native中心模型未实现完整原阶段、own-high、路径及历史资格；临时预筛算例不纳入正式统计或包。

已检查MATLAB脚本与实际输出、CSV，本审查未另行调用MATLAB。MATLAB27行及Python/Decimal浮点交叉均不是区间证书或一般阶数证明。一般结论来自上述解析证明及明确继承的原核/sourcewise合同，不以有限通过数量替代。

## 最终SHA-256绑定

- `r432_main.md`: `3b8e5d8731fb966a02772f9304d0ce000296f23461ce80cdeeb747632f0116d9`
- `r432_geometry.md`: `b83c2d096fdfa0ca78d3e5ac973c5e74cac5d5349b2c146cacc0c7da627ee8ab`
- `r432_joint.md`: `e320cbf0ed4deadaf056c4a01aa477c5b08527bc3ba9326a3f5feb88345ef20e`
- `r432_readme.md`: `1f490a8f8603944c88da9cf2a4022f759ce1f03837b89d0a199afda9b6052cd7`
- `r432_geometry_check.py`: `bd549d23d91dcebd3e924f79f32fb6c7510f45a7188cadc0c4060d4a9967e237`
- `r432_geometry.result.txt`: `531f818affa7672aa042582bd1b04fe4433979cfe49d762d01d1a8ce0d496c23`
- `r432_joint_check.py`: `e3f2cd6d2f55266ac52eec54781a88067b71a4531a650db8bd1db9d83cf60656`
- `r432_joint.result.txt`: `b18d2b63e4000cee61b6929149c5826803e8bc0c6a96b5272abafdec06c294b8`
- `r432_parent_check.py`: `754e0f6418de7724cd00fe50ffdcdc36660f7a50a594a361b98b678598659afc`
- `r432_parent.result.txt`: `2c6e22b5e906849d3e8877091a8433e3df21f27aeeb48e172a78c34dd08d14cf`
- `r432_parameters.m`: `0f8cda75da330476bd03526e7fe91d4ccf4ef443fc80cddd8d80f2e89fba21e6`
- `r432_matlab_parameters.csv`: `6200060117546a4a3747b7a9f5054c13a93530c8ff2363bd8048f7d39a0d5da5`
- `r432_matlab.result.txt`: `ea5cb9f19f94e6d0382e7690f603300a14cf86df77a4a824a399e2ba39a7e251`
