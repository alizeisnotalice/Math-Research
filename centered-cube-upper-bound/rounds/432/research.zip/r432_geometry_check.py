"""R432 rational interval certificates and exact finite compensation.
Native center examples retain full f matching, not the original stage history.
"""
from fractions import Fraction as F
from math import isqrt


def log_unit(x, terms=90):
    assert F(1) <= x <= F(2)
    z = (x-1)/(x+1)
    lower = sum((2*z**(2*k+1)/F(2*k+1) for k in range(terms)), F(0))
    tail = 2*z**(2*terms+1)/(F(2*terms+1)*(1-z*z))
    return lower, lower+tail


LOG2 = log_unit(F(2))


def log_interval(x):
    assert x > 0
    shift = 0
    while x < 1:
        x *= 2
        shift -= 1
    while x > 2:
        x /= 2
        shift += 1
    lo, hi = log_unit(x)
    if shift >= 0:
        return lo+shift*LOG2[0], hi+shift*LOG2[1]
    return lo+shift*LOG2[1], hi+shift*LOG2[0]


def exp_integer_interval(x, terms=180):
    assert 0 <= x < terms
    total = term = F(1)
    for k in range(1, terms+1):
        term *= F(x, k)
        total += term
    first_tail = term*F(x, terms+1)
    return total, total+first_tail/(1-F(x, terms+2))


def profile_interval(ratio):
    lo, hi = log_interval(ratio)
    assert lo >= 0
    return ratio/(1+hi/2)**2, ratio/(1+lo/2)**2


# Stage 1: analytic primitive evaluated by certified rational log intervals.
# Integral_1^T B(r)/r^2 dr = 2-2/(1+log(T)/2).
# The finite sublevel cap includes the remaining tail B(T)/T.
profile_cases = 0
previous = None
for ratio in [F(1), F(5,4), F(3,2), F(2), F(4), F(16), F(256),
              F(2)**32, F(2)**128]:
    blo, bhi = profile_interval(ratio)
    lo, hi = log_interval(ratio)
    assert 1 <= blo <= bhi <= ratio
    if previous is not None:
        assert previous[1] < blo
    previous = blo, bhi
    vlow, vhigh = 1+lo/2, 1+hi/2
    caplo = 1+(1-1/vlow)**2
    caphi = 1+(1-1/vhigh)**2
    assert 1 <= caplo <= caphi < 2
    assert 2-2/vlow+1/vlow**2 == caplo
    assert 2-2/vhigh+1/vhigh**2 == caphi
    if ratio == 1:
        assert caplo == caphi == 1  # base atom is not lost
    else:
        assert lo > 0  # B'(R)=(log R/2)/(1+log R/2)^3 > 0
    profile_cases += 1
print("Stage 1 PASS:", profile_cases,
      "rational interval profile/finite-cap certificates; base endpoint retained")


# Stage 2: genuine Lebesgue centers, actual K=exp(sqrt(n)), full nonuniform f.
# f=1_{[-4,4]^n}+P*1_packet/|packet|, packet centered at 0 of side eta/100.
# Child centers in Q_eta(0) select side 1; all other centers in
# Q_{2(1-eta)}(0) select side 2. All selected cubes capture the whole packet.
# Fixed child u=x=0; all father masses 2^n+P and child mass 1+P.
# Adaptive near father volume is beta^n-eta^n, calculated by log intervals.
native_cases = positive_extra = 0
eta = F(1,1000)
for n in [64, 100, 144]:
    ell = isqrt(n)
    assert ell*ell == n
    s = 1+ell
    for packet in [F(1,100), F(1,20), F(1,10)]:
        child, father = 1+packet, F(2)**n+packet
        qchild, qfather = child, father/F(2)**n
        q, lam = F(1), child
        loglo, loghi = log_interval(father/child)
        loglo -= 3*ell  # log(father/(K^3 child)), actual j=1
        loghi -= 3*ell
        assert loglo > 0
        beta_volume_lo = s*father/child/(1+loghi/2)**2
        beta_volume_hi = s*father/child/(1+loglo/2)**2
        elo, ehi = exp_integer_interval(3*ell)
        base_lo, base_hi = s*elo, s*ehi
        e1lo, e1hi = exp_integer_interval(1)
        e2lo, e2hi = exp_integer_interval(2*ell)
        original_alpha_hi = s*e2hi*(1+e1hi)**ell
        eelllo, eellhi = exp_integer_interval(ell)
        assert eta**n < base_lo < base_hi < beta_volume_lo
        assert original_alpha_hi < beta_volume_lo
        # The single target also has the R430 deep father ratio (no full path claim).
        assert father > eellhi*(original_alpha_hi/s)*child
        assert beta_volume_hi < (2*(1-eta))**n
        actual_lo = (beta_volume_lo-eta**n)/F(2)**n
        actual_hi = (beta_volume_hi-eta**n)/F(2)**n
        bound = 2*lam*s/qchild
        assert 0 < actual_lo <= actual_hi <= bound <= 2*(lam/q)*s
        assert 1 <= qfather <= qchild
        positive_extra += int(beta_volume_lo > base_hi)
        native_cases += 1
print("Stage 2 PASS:", native_cases,
      "full-f native center certificates at n=64,100,144;",
      positive_extra, "strict adaptive-volume gains")


def paths(seed, rho):
    masses = list(map(F, [1,1,2,3,8,16,64]))
    K, s, h = F(2), F(3), F(1,4)
    father = F(4096+seed*1024)
    prefix = [[u for u, mass in enumerate(masses) if mass < mv/K]
              for mv in masses]
    ranks = [sum((rho[u] for u in us), F(0)) for us in prefix]
    out = []
    decisions = 0

    def near(u, j):
        nonlocal decisions
        H = K**(j+2)*masses[u]
        if father <= H:
            return False  # includes strict mass equality
        lower, upper = profile_interval(father/H)
        # Rational normalized center volume; finite incidence diagnostic only.
        position = F((u+1)*(seed+2), 3)
        assert position < lower or position > upper
        decisions += 1
        return position < lower

    def walk(v, jprev, prob, risk, hits, gates, trace):
        if ranks[v] <= h:
            out.append((prob, risk, hits, gates, tuple(trace)))
            return
        j = jprev+1
        guard = father > K**(j+1)*masses[v]
        close = {u for u in prefix[v] if near(u, j)}
        probability = sum((rho[u] for u in close), F(0))/ranks[v]
        for u in prefix[v]:
            if guard:
                assert father > K**(j+2)*masses[u]
            walk(u, j, prob*rho[u]/ranks[v],
                 risk+int(guard)*probability,
                 hits+int(guard and u in close),
                 gates and guard, trace+[u])

    walk(len(masses)-1, 0, F(1), F(0), 0, True, [])
    assert sum((p[0] for p in out), F(0)) == 1
    meanrisk = sum((p[0]*p[1] for p in out), F(0))
    meanhits = sum((p[0]*p[2] for p in out), F(0))
    assert meanrisk == meanhits
    return out, meanrisk, decisions


# Stage 3: exact compensation, arbitrary coupled future mark, actual hit branch.
models = decisions = positive_paid = threshold_checks = 0
for seed in range(9):
    rho = [F(1+(seed+i) % 4, 3) for i in range(7)]
    left, lm, ld = paths(seed, rho)
    right, rm, rd = paths(seed+1, rho[::-1])
    decisions += ld+rd
    riskmoment = hitmoment = hitpaid = F(0)
    rows = []
    for a, x in enumerate(left):
        for b, z in enumerate(right):
            future = F((a+2*b+seed) % 6, 5) if x[3] and z[3] else F(0)
            weight = x[0]*z[0]*future
            risk, hits = x[1]+z[1], x[2]+z[2]
            riskmoment += weight*risk
            hitmoment += weight*hits
            hitpaid += weight*int(hits >= 1)
            rows.append((weight, risk))
    assert hitpaid <= hitmoment <= lm+rm
    assert riskmoment <= lm+rm
    positive_paid += int(hitpaid > 0)
    for gamma in [F(1,4), F(1,2), F(1)]:
        paid = sum((w for w, risk in rows if risk >= gamma), F(0))
        assert gamma*paid <= riskmoment
        threshold_checks += 1
    models += 1
assert positive_paid > 0
# Equality in the guard must be excluded; no regularization of the mass atom.
assert not (F(256) > F(2)**2*F(64))
print("Stage 3 PASS:", models, "joint finite flow models;", decisions,
      "certified profile decisions;", positive_paid,
      "positive hit branches;", threshold_checks, "risk-threshold checks")
print("Analytic integral to infinity equals 2; finite checks are not its proof.")
print("Native examples certify matched centers, not full original history or closure.")
