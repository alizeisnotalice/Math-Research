from fractions import Fraction as F
from math import comb
from decimal import Decimal, localcontext

def logbox(x,N=100):
    z=(x-1)/(x+1)
    assert 0<=z<1
    s=2*sum((z**(2*k+1)/F(2*k+1) for k in range(N)),F(0))
    return s,s+2*z**(2*N+1)/(F(2*N+1)*(1-z*z))

def expbox(x,N=220):
    assert x>=0 and x<N+2
    t=F(1); s=t
    for k in range(1,N+1):
        t=t*x/k; s+=t
    nextterm=t*x/(N+1)
    return s,s+nextterm/(1-x/F(N+2))

def verify(ds,a=F(1),b=F(2)):
    n=len(ds); l=max(a,max(ds)); assert l<b
    coeff=[F(1)]
    for d in ds:
        out=[F(0)]*(len(coeff)+1)
        for k,c in enumerate(coeff): out[k]+=c;out[k+1]-=c*d
        coeff=out
    base=sum((c/b**k for k,c in enumerate(coeff)),F(0))
    rat=base+sum((F(n,k)*c*(l**(-k)-b**(-k)) for k,c in enumerate(coeff) if k),F(0))
    loglo,loghi=logbox(b/l)
    upper=rat+n*loghi
    alo,ahi=logbox(b/a)
    elo,ehi=expbox(sum(ds,F(0))/b)
    boundlower=(1+n*alo)/ehi
    if any(ds): assert upper<=boundlower, (n,ds)
    else: assert rat==1 and l==a # equality: kernel=1+n log(b/a)
    return n

phases=[[(F(1,8),n) for n in (1,2,4,8,12,16)],[(F(3,2),n) for n in (1,2,4,8,12,16)],[(F(0),n) for n in (1,2,4,8,12,16)]]
for phase,rows in enumerate(phases,1):
    for d,n in rows:
        ds=[d if k%2==0 else d/2 for k in range(n)]
        verify(ds)
    print(f'phase {phase}: 6 exact rational interval checks PASS')
print('18 pair-center layer-cake coefficient checks PASS; zero-distance equality checked symbolically')
with localcontext() as ctx:
    ctx.prec=60
    for n in [9,16,64,256,1024,4096,65536]:
        dn=Decimal(n); s=1+dn.sqrt(); D=dn*Decimal(2).ln()
        eta=((s/(1+D/2)**2).ln()/dn).exp()
        loss=1-eta
        print(f'n={n} eta={eta:.16f} relative_radius_loss={loss:.8E}')
print('Decimal rows are diagnostics only; general order follows analytic radius formula')
from pathlib import Path
import csv, math
csvpath=Path(__file__).with_name('r432_matlab_parameters.csv')
if csvpath.exists():
    rows=list(csv.reader(csvpath.open()))
    for row in rows:
        n,eps,M,eta,geom,joint,norm=map(float,row)
        s=1+math.sqrt(n)
        # Independent integral of min(1,M/(2^k t))/t for each k,
        # then an explicit geometric infinite tail, not the closed Psi formula.
        if M<=1: psi=0.;theta=2*M
        else:
            L=math.ceil(math.log2(M));psi=0.;theta=0.
            for k in range(L+12):
                x=M/(2**k); theta+=min(1,x)
                if x>=M: psi+=math.log(M)
                elif x>=1: psi+=math.log(x)+1-x/M
                else: psi+=x*(1-1/M)
            tail=M*2**(1-(L+12))
            theta+=tail;psi+=tail*(1-1/M)
        eg=8*s*(psi+(1+eps)*theta)
        ej=2*s*(1+eps)**2*theta**2
        assert math.isclose(geom,eg,rel_tol=2e-12)
        assert math.isclose(joint,ej,rel_tol=2e-12)
        assert math.isclose(norm,(eg+ej)/(s*math.log(n+2)**2),rel_tol=2e-12)
    print('27 MATLAB rows cross-checked with explicit generation sum and infinite tail PASS (floating diagnostic)')
else:
    raise RuntimeError('Required same-folder MATLAB CSV missing')
