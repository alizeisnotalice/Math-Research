r432_n=[16 64 256 1024 4096 16384 65536 1048576 1099511627776];
r432_eps=[.5 .125 .03125];
r432_rows=[];
for nn=r432_n
 for ee=r432_eps
  ss=1+sqrt(nn); An=1+nn*log(2); MM=ee*An/ss;
  if MM<=1
   th=2*MM; ps=0;
  else
   LL=ceil(log2(MM));th=LL+2*MM*2^(-LL);
   ps=LL*(1+log(MM))-.5*log(2)*LL*(LL-1)-2+2*MM*2^(-LL);
  end
  Sc=2; rr=1;
  oc=2*Sc*rr*ss*(ps+(1+ee)*th);
  geom=2*oc;
  joint=Sc*ss*(1+ee)^2*th^2;
  eta=exp(log(ss/(rr*(1+.5*(log(rr)+nn*log(2)))^2))/nn);
  r432_rows(end+1,:)=[nn ee MM eta geom joint (geom+joint)/(ss*log(nn+2)^2)];
 end
end
writematrix(r432_rows,'/tmp/r432_matlab_parameters.csv');
fid=fopen('/tmp/r432_matlab.result.txt','w');
fprintf(fid,'MATLAB %s\n27 parameter rows; numerical diagnostics only\nnormalized total min=%.17g max=%.17g\n',version,min(r432_rows(:,7)),max(r432_rows(:,7)));
fclose(fid);
disp(fileread('/tmp/r432_matlab.result.txt'));
