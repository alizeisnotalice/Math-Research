#!/usr/bin/env python3
"""Round 41 exact guards, standard library only.
All interval arithmetic is Fraction arithmetic. Finite tests are not proofs of
kernel existence/nonexistence. The finite-prior extension is only a geometric
parameter guard; its theorem status is not promoted by this script.
"""
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from pathlib import Path
import json


def fs(q):
    return str(q.numerator) if q.denominator == 1 else f'{q.numerator}/{q.denominator}'


def dd(q):
    with localcontext() as ctx:
        ctx.prec = 70
        x = D(q.numerator)/D(q.denominator)
        return '0' if not x else format(x, '.22E')


def interval_length(I):
    return max(F(0), I[1]-I[0])


def intersection_length(I, J):
    return max(F(0), min(I[1],J[1])-max(I[0],J[0]))


def add_atom(atoms, location, mass):
    atoms[location] = atoms.get(location, F(0))+mass
    if not atoms[location]:
        del atoms[location]


def atom_list(atoms):
    return [[fs(location), fs(mass)] for location,mass in sorted(atoms.items())]


def ratio_specs():
    rows = [('integer_1',F(1),None), ('integer_2',F(2),None),
            ('integer_3',F(3),None), ('integer_5',F(5),None),
            ('noninteger_3_2',F(3,2),None), ('noninteger_5_3',F(5,3),None),
            ('noninteger_7_2',F(7,2),None)]
    rows += [(f'fine_1_plus_1_over_{n}',F(n+1,n),n) for n in (2,8,32,128,512)]
    return rows


def base_case(label, r, fine_n, a, x):
    b = a*r
    return {'ratio_label': label, 'ratio': fs(r), 'fine_dimension': fine_n,
            'a': fs(a), 'b': fs(b), 'x_translation': fs(x)}


def gap_case(label, r, fine_n, a, x):
    b, d = a*r, a*(r-1)/2
    offsets = {F(0), d/2, d, d+a/4, d+a/2, d+a, d+2*a}
    offsets |= {-z for z in offsets}
    I = (x-a/2,x+a/2)
    rows = []
    for offset in sorted(offsets):
        z = x+offset
        permitted_y = (z-b/2,z+b/2)
        direct_gap = interval_length(I)-intersection_length(I,permitted_y)
        formula = min(a,max(F(0),abs(z-x)-d))
        assert direct_gap == formula
        if abs(offset) <= d:
            region = 'inside_or_support_boundary'
            assert not formula
        elif abs(offset) >= d+a:
            region = 'far_outside_or_saturation_boundary'
            assert formula == a
        else:
            region = 'partial_gap'
        rows.append({'z': fs(z), 'region': region, 'direct_bad_y_length': fs(direct_gap),
                     'formula_gap': fs(formula)})
    result = base_case(label,r,fine_n,a,x)
    result.update({'test_count': len(rows), 'tests': rows,
                   'identity': 'length([x-a/2,x+a/2] minus [z-b/2,z+b/2]) = min(a,(abs(z-x)-(b-a)/2)_+)',
                   'scope': 'Exact interval identity, including boundary and saturation cases.', 'status': 'PASS'})
    return result


def recurrence_case(label,r,fine_n,a,x):
    b,d,c = a*r,a*(r-1)/2,1/r
    k = r.numerator//r.denominator
    N = k+1
    assert N*a > b
    I = (x-d,x+d)
    shifted_I = (x+N*a-d,x+N*a+d)
    assert shifted_I[0] > I[1]
    positive, negative, rhs = {}, {}, {}
    for j in range(N):
        p,q = x+a+d+j*a,x-d+j*a
        add_atom(positive,p,c)
        add_atom(negative,q,c)
        add_atom(rhs,p,c)
        add_atom(rhs,q,-c)
    assert all(z > I[1] for z in positive)
    inside_negative = {z:w for z,w in negative.items() if I[0] <= z <= I[1]}
    restricted_rhs = {z:w for z,w in rhs.items() if I[0] <= z <= I[1]}
    assert len(inside_negative) == k
    assert restricted_rhs == {z:-w for z,w in inside_negative.items()}
    required_mass = sum(inside_negative.values())
    assert required_mass == F(k)/r
    integer = r.denominator == 1
    assert (required_mass == 1) == integer
    right_endpoint_present = I[1] in inside_negative
    assert right_endpoint_present == integer
    result = base_case(label,r,fine_n,a,x)
    result.update({'N': N, 'N_a': fs(N*a), 'support_Ix': list(map(fs,I)),
                   'shifted_support_Ix_plus_Na': list(map(fs,shifted_I)),
                   'positive_atoms_all_outside_Ix': atom_list(positive),
                   'negative_atom_count_inside_Ix': len(inside_negative),
                   'required_restricted_Kx_atoms': atom_list(inside_negative),
                   'restricted_telescoping_rhs': atom_list(restricted_rhs),
                   'closed_right_endpoint_retained': right_endpoint_present,
                   'required_mass_under_kernel_hypothesis': fs(required_mass),
                   'mass_deficit_under_kernel_hypothesis': fs(1-required_mass),
                   'kernel_status': 'integer ratio: consistent required probability, explicit feasible kernel checked separately' if integer
                                    else 'noninteger ratio: deficient necessary measure under hypothesis, not a feasible kernel',
                   'scope': 'Sparse signed telescoping atoms; support and finite-measure recurrence are hypotheses supplied by the analytic argument.',
                   'status': 'PASS'})
    return result


def density_at(z, intervals):
    # Evaluation is only at strict cell midpoints; densities are defined a.e.
    return sum(q for lo,hi,q in intervals if lo < z < hi)


def partition_integrals(first, second):
    edges = sorted({u for lo,hi,q in first+second for u in (lo,hi)})
    if not edges:
        return F(0),F(0),F(0),0,[]
    edges = [edges[0]-1]+edges+[edges[-1]+1]
    mass_first = mass_second = l1 = F(0)
    tested = 0
    cells = []
    for lo,hi in zip(edges[:-1],edges[1:]):
        z = (lo+hi)/2
        assert all(z not in (a,b) for a,b,q in first+second)
        p,q = density_at(z,first),density_at(z,second)
        mass_first += (hi-lo)*p
        mass_second += (hi-lo)*q
        l1 += (hi-lo)*abs(p-q)
        tested += 1
        cells.append([fs(lo),fs(hi),fs(p),fs(q)])
    return mass_first,mass_second,l1,tested,cells


def integer_tiling_case(k,a,x,source_count):
    b = k*a
    # Parameter source is positive and genuinely has several atoms.
    raw_y = [F(-7,5),F(-1,4),F(3,8),F(11,6),F(13,5)][:source_count]
    source_weights = [F(2,3),F(5,7),F(7,4),F(3,2),F(9,8)][:source_count]
    ys = [x+q for q in raw_y]
    W = sum(source_weights)
    kernel = {a*(F(j)-F(k-1,2)):F(1,k) for j in range(k)}
    assert sum(kernel.values()) == 1 and all(q > 0 for q in kernel.values())
    first,second = [],[]
    for y,w in zip(ys,source_weights):
        for shift,probability in kernel.items():
            first.append((y+shift-a/2,y+shift+a/2,w*probability/a))
        second.append((y-b/2,y+b/2,w/b))
    mass_first,mass_second,l1,tested,cells = partition_integrals(first,second)
    assert mass_first == mass_second == W and l1 == 0
    return {'integer_ratio': k, 'a': fs(a), 'b': fs(b), 'x_translation': fs(x),
            'source_atom_count': source_count,
            'source_positions': list(map(fs,ys)), 'source_weights': list(map(fs,source_weights)),
            'feasible_additive_Markov_kernel_shifts_and_probabilities': atom_list(kernel),
            'source_mass': fs(W), 'output_mass': fs(mass_first),
            'integrated_absolute_density_error': fs(l1), 'midpoint_observation_count': tested,
            'exact_interval_densities': cells,
            'scope': 'Actual positive source, actual integer tiling kernel, exact density partition including exterior cells; endpoints have zero Lebesgue measure.',
            'kernel_status': 'feasible for every translation parameter', 'status': 'PASS'}


def finite_prior_geometry_case(label,r,fine_n,a,x):
    b,d = a*r,a*(r-1)/2
    N = r.numerator//r.denominator+1
    R = 2*(abs(x)+a+N*a+b)+1
    start_interval = (-R+a/2,R-a/2-N*a)
    orbit = [x+j*a for j in range(N+1)]
    assert 2*R > a+N*a
    assert start_interval[0] < x < start_interval[1]
    assert all(-R+a/2 < p < R-a/2 for p in orbit)
    assert all(-R < p-a/2 < p+a/2 < R for p in orbit)
    assert all(-R < x+j*a+a/2 < R for j in range(N))
    margins = [p-a/2+R for p in orbit]+[R-p-a/2 for p in orbit]
    result = base_case(label,r,fine_n,a,x)
    result.update({'prior_parameter_interval': [fs(-R),fs(R)], 'R': fs(R), 'N': N,
                   '2R_minus_a_minus_Na': fs(2*R-a-N*a),
                   'legal_start_interval': list(map(fs,start_interval)),
                   'orbit': list(map(fs,orbit)), 'minimum_input_parameter_margin': fs(min(margins)),
                   'support_radius_d': fs(d),
                   'scope': 'Geometric parameter guard only: orbit input-y intervals and local differentiation centers are strictly inside the finite prior. Does not prove Tonelli support, local a.e. differentiation, or finite-prior nonexistence.',
                   'analytic_extension_status': 'theorem-parameter guard of the proved finite-prior lemma, independently audited by parent team; these tests do not prove it',
                   'status': 'PASS'})
    return result


def candidate_tv_case(label,r,fine_n,a,x):
    b,d = a*r,a*(r-1)/2
    k = r.numerator//r.denominator
    length = k*a
    # A real probability kernel, but it has the wrong uniform output if r is not integral.
    kernel = { -d+j*a:F(1,k) for j in range(k)}
    required_atoms = {-d+j*a:1/r for j in range(k)}
    assert sum(kernel.values()) == 1
    first = [(x+shift-a/2,x+shift+a/2,q/a) for shift,q in kernel.items()]
    target = [(x-b/2,x+b/2,1/b)]
    small_I, big_I = (x-b/2,x-b/2+length),(x-b/2,x+b/2)
    small_uniform = [(small_I[0],small_I[1],1/length)]
    mass_first,mass_target,l1,tested,cells = partition_integrals(first,target)
    _,_,wrong_uniform_error,_,_ = partition_integrals(first,small_uniform)
    assert mass_first == mass_target == 1 and wrong_uniform_error == 0
    assert intersection_length(small_I,big_I) == length
    tv = l1/2
    expected = 1-F(k)/r
    assert tv == expected
    necessary_intervals = [(x+shift-a/2,x+shift+a/2,q/a) for shift,q in required_atoms.items()]
    required_mass,_,_,_,_ = partition_integrals(necessary_intervals,target)
    assert required_mass == F(k)/r
    tensor = []
    dimensions = sorted({1,2,8,32,128,512} | ({fine_n} if fine_n is not None else set()))
    for n in dimensions:
        Vsmall,Vbig = length**n,b**n
        # Exact integration on the contained small box and its complement in the big box.
        tensor_l1 = Vsmall*abs(1/Vsmall-1/Vbig)+(Vbig-Vsmall)/Vbig
        tensor_tv = tensor_l1/2
        formula = 1-(F(k)/r)**n
        assert tensor_tv == formula
        tensor.append({'dimension': n, 'direct_two_region_integral_TV': fs(tensor_tv),
                       'formula_TV': fs(formula), 'TV_decimal': dd(formula),
                       'scope': 'Contained small box versus target big box; exact tensor-volume identity.'})
    result = base_case(label,r,fine_n,a,x)
    result.update({'floor_ratio': k, 'normalized_candidate_shifts_and_probabilities': atom_list(kernel),
                   'necessary_unnormalized_atoms': atom_list(required_atoms),
                   'necessary_mass': fs(required_mass), 'candidate_output_mass': fs(mass_first),
                   'candidate_uniform_interval': list(map(fs,small_I)),
                   'candidate_uniform_length': fs(length),
                   'candidate_center_shift_from_parameter': fs((length-b)/2),
                   'target_uniform_interval': list(map(fs,big_I)), 'target_uniform_length': fs(b),
                   'one_dimensional_TV_direct_integral': fs(tv), 'one_dimensional_TV_formula': fs(expected),
                   'one_dimensional_TV_decimal': dd(tv), 'density_partition_count': tested,
                   'exact_interval_densities': cells, 'tensor_tests': tensor,
                   'kernel_status': 'feasible integer target garbling' if r.denominator == 1 else 'actual normalized Markov candidate; its wrong-center shorter output does not match the target',
                   'scope': 'Separates deficient measure forced by hypotheses from an actual normalized candidate and computes its exact error.',
                   'status': 'PASS'})
    return result



def atomic_posterior_energy(N,h,L):
    positions = [j*h for j in range(N)]
    g = [F((-1)**j) for j in range(N)]
    edges = sorted({y-L/2 for y in positions} | {y+L/2 for y in positions})
    edges = [edges[0]-h]+edges+[edges[-1]+h]
    energy = F(0)
    gram = [[F(0) for _ in range(N)] for _ in range(N)]
    partition = []
    for lo,hi in zip(edges[:-1],edges[1:]):
        x = (lo+hi)/2
        captured = tuple(j for j,y in enumerate(positions) if abs(x-y) < L/2)
        assert all(abs(x-y) != L/2 for y in positions)
        numerator = sum(g[j] for j in captured)
        count = len(captured)
        value = F(0) if not count else numerator**2/(L*count)
        contribution = (hi-lo)*value
        energy += contribution
        if count:
            coefficient = (hi-lo)/(L*count)
            for i in captured:
                for j in captured:
                    gram[i][j] += coefficient
        partition.append({'interval': [fs(lo),fs(hi)], 'captured_indices': list(captured),
                          'positive_source_count':count, 'signed_test_numerator':fs(numerator),
                          'energy_density':fs(value), 'energy_contribution':fs(contribution)})
    gram_pairing = sum(g[i]*g[j]*gram[i][j] for i in range(N) for j in range(N))
    assert energy == gram_pairing
    rows = [sum(row) for row in gram]
    assert rows == [F(1)]*N
    return energy,partition


def finite_atomic_probability_case(N,n,h):
    delta = F(1,n)
    a,b = 2*h,2*h*(1+delta)
    Ea,partition_a = atomic_posterior_energy(N,h,a)
    Eb,partition_b = atomic_posterior_energy(N,h,b)
    formula = 1+delta*(N-5)/(3*(1+delta))
    assert Ea == 1 and Eb == formula
    probability_gap = (Eb-Ea)/N
    identity_joint_tv = 1-(a/b)**n
    assert identity_joint_tv == 1-(F(n,n+1))**n
    _,_,resample_l1,resample_cells,_ = partition_integrals(
        [(-a/2,a/2,1/a)],[(-b/2,b/2,1/b)])
    collinear_resample_upper = resample_l1/2
    assert collinear_resample_upper == delta/(1+delta)
    assert collinear_resample_upper == 1-a/b == F(1,n+1)
    assert collinear_resample_upper <= identity_joint_tv
    approximate_markov_gap_lower = probability_gap/4 if N > 5 else F(0)
    if N > 5:
        assert approximate_markov_gap_lower == delta*(N-5)/(12*N*(1+delta))
        assert 0 < approximate_markov_gap_lower <= collinear_resample_upper <= identity_joint_tv
    assert (Eb > Ea) == (N > 5)
    if N == 5:
        assert Eb == Ea
    if N == 2:
        assert Eb == 1/(1+delta) < Ea
    return {'source_atom_count':N, 'dimension_n_and_inverse_delta':n, 'h':fs(h),
            'source_positions':[[fs(j*h)]+['0']*(n-1) for j in range(N)] if n <= 8 else
                               {'compressed': '(j h,0,...,0), j=0,...,N-1', 'dimension':n},
            'positive_raw_source_weights':'all 1', 'normalized_prior_probabilities':fs(F(1,N)),
            'signed_test_vector':[(-1)**j for j in range(N)],
            'delta':fs(delta), 'a':fs(a), 'b':fs(b),
            'raw_energy_a_direct_integral':fs(Ea), 'raw_energy_b_direct_integral':fs(Eb),
            'raw_energy_b_formula':fs(formula), 'energy_increase':fs(Eb-Ea),
            'probability_posterior_L2_energy_a':fs(Ea/N),
            'probability_posterior_L2_energy_b':fs(Eb/N),
            'probability_posterior_L2_gap':fs(probability_gap),
            'approximate_Markov_joint_TV_gap_over_4_lower_for_N_gt_5':fs(approximate_markov_gap_lower) if N>5 else None,
            'TV_lower_scope':'Parameter guard for the analytic gap/4 lemma supplied by parent; no optimization of kernels or optimality assertion. Applied only when N>5.',
            'collinear_resampling_first_coordinate_density_cells_checked':resample_cells,
            'collinear_source_dependent_resampling_joint_TV_upper_exact':fs(collinear_resample_upper),
            'collinear_source_dependent_resampling_joint_TV_upper_decimal':dd(collinear_resample_upper),
            'collinear_source_dependent_kernel':'Keep Z1=Xa1, discard coordinates 2,...,n, independently resample them from Uniform[-b/2,b/2]. Valid because every source has coordinates 2,...,n equal to 0.',
            'collinear_best_joint_TV_parameter_interval': [fs(approximate_markov_gap_lower),fs(collinear_resample_upper)] if N>5 else None,
            'collinear_resampling_scope':'Actual source-dependent candidate for this collinear family only, not arbitrary sources. Conditional and joint TV equal 1-a/b=delta/(1+delta); no optimality claim.',
            'identity_kernel_joint_TV_exact':fs(identity_joint_tv),
            'identity_kernel_joint_TV_decimal':dd(identity_joint_tv),
            'identity_TV_ambient_dimension':n,
            'identity_kernel_scope':'Actual identity Markov kernel: conditional noise laws are contained centered boxes, so joint TV for (Y,X) equals 1-(a/b)^ambient_n, independently of atom count N.',
            'partition_a':partition_a, 'partition_b':partition_b,
            'kernel_test_status':'strict posterior L2 increase; violates the necessary data-processing inequality for Y -> Xa -> Xb' if N>5 else
                                 ('equality control, does not imply existence' if N==5 else 'decrease control, does not imply existence'),
            'scope':'Actual positive equal-weight collinear source; g alone is signed. Exact one-dimensional full-boundary integral and source-Gram pairing. Other coordinates integrate over their common L-length interval, cancelling L^(n-1); normalized probability energies divide the raw energies by N.',
            'status':'PASS'}


def main():
    scales,translations = (F(1,3),F(1),F(7,4)),(F(-5,7),F(0),F(11,6))
    gaps,recurrences,priors,tvs,tilings = [],[],[],[],[]
    for label,r,fine_n in ratio_specs():
        for a in scales:
            for x in translations:
                gaps.append(gap_case(label,r,fine_n,a,x))
                recurrences.append(recurrence_case(label,r,fine_n,a,x))
                priors.append(finite_prior_geometry_case(label,r,fine_n,a,x))
                tvs.append(candidate_tv_case(label,r,fine_n,a,x))
    for k in (1,2,3,5):
        for a in scales:
            for x in translations:
                for count in (3,5):
                    tilings.append(integer_tiling_case(k,a,x,count))
    atomic_probability = [finite_atomic_probability_case(N,n,h)
                          for N in (2,5,6,8,16) for n in (2,8,32,128,512) for h in scales]
    noninteger_mass = [F(row['required_mass_under_kernel_hypothesis']) for row in recurrences if F(row['ratio']).denominator != 1]
    noninteger_tvs = [F(row['one_dimensional_TV_formula']) for row in tvs if F(row['ratio']).denominator != 1]
    all_tensor = [F(item['formula_TV']) for row in tvs for item in row['tensor_tests']]
    matched_fine = {row['fine_dimension']: item['TV_decimal'] for row in tvs if row['fine_dimension'] is not None
                    for item in row['tensor_tests'] if item['dimension'] == row['fine_dimension']}
    summary = {'status': 'PASS', 'case_count':len(gaps)+len(recurrences)+len(tilings)+len(priors)+len(tvs)+len(atomic_probability),
               'finite_atomic_probability_cases':len(atomic_probability),
               'strict_posterior_L2_increase_cases':sum(row['source_atom_count']>5 for row in atomic_probability),
               'posterior_L2_equality_control_cases':sum(row['source_atom_count']==5 for row in atomic_probability),
               'posterior_L2_decrease_control_cases':sum(row['source_atom_count']==2 for row in atomic_probability),
               'atomic_energy_boundary_partition_cells_checked':sum(len(row['partition_a'])+len(row['partition_b']) for row in atomic_probability),
               'positive_gap_over_4_lower_range_exact':list(map(fs,(min(F(row['approximate_Markov_joint_TV_gap_over_4_lower_for_N_gt_5']) for row in atomic_probability if row['source_atom_count']>5), max(F(row['approximate_Markov_joint_TV_gap_over_4_lower_for_N_gt_5']) for row in atomic_probability if row['source_atom_count']>5)))),
               'collinear_source_dependent_TV_upper_range_exact':list(map(fs,(min(F(row['collinear_source_dependent_resampling_joint_TV_upper_exact']) for row in atomic_probability), max(F(row['collinear_source_dependent_resampling_joint_TV_upper_exact']) for row in atomic_probability)))),
               'atomic_raw_energy_b_range_exact':list(map(fs,(min(F(row['raw_energy_b_direct_integral']) for row in atomic_probability), max(F(row['raw_energy_b_direct_integral']) for row in atomic_probability)))),
               'support_gap_cases':len(gaps), 'direct_gap_intersections_checked':sum(row['test_count'] for row in gaps),
               'sparse_recurrence_cases':len(recurrences),
               'integer_explicit_tiling_positive_source_cases':len(tilings),
               'integer_density_partition_cells_checked':sum(row['midpoint_observation_count'] for row in tilings),
               'finite_prior_geometry_parameter_cases':len(priors),
               'normalized_candidate_TV_cases':len(tvs),
               'candidate_density_partition_cells_checked':sum(row['density_partition_count'] for row in tvs),
               'tensor_two_region_TV_checks':len(all_tensor),
               'noninteger_required_mass_range_exact':list(map(fs,(min(noninteger_mass),max(noninteger_mass)))),
               'noninteger_1D_TV_range_exact':list(map(fs,(min(noninteger_tvs),max(noninteger_tvs)))),
               'all_tensor_TV_range_decimal':[dd(min(all_tensor)),dd(max(all_tensor))],
               'maximum_tensor_TV_complement_exact':fs(1-max(all_tensor)),
               'maximum_tensor_TV_complement_decimal':dd(1-max(all_tensor)),
               'tensor_TV_rounding_note':'Maximum TV rounds to 1 in short decimal presentation; exact TV is strictly below 1 for every finite dimension.',
               'matched_fine_dimension_tensor_TV_decimal':matched_fine,
               'minimum_finite_prior_orbit_margin':fs(min(F(row['minimum_input_parameter_margin']) for row in priors)),
               'scope':'Exact finite arithmetic guards. No floating-point boundary decisions, no kernel fitting, no numerical proof of the general garbling theorem or its finite-prior extension, no maximal-operator asymptotic claim.'}
    result = {'proof_file':'proof.md', 'arithmetic':'Fraction throughout; Decimal only for presentation of exact TV fractions.',
              'ratio_labels_include_duplicate_3_2_with_distinct_fine_provenance':True,
              'summary':summary,'support_gap':gaps,'sparse_recurrence':recurrences,
              'integer_tiling':tilings,'finite_prior_geometry_only':priors,'normalized_candidate_TV':tvs,
              'finite_atomic_probability_posterior_L2':atomic_probability}
    Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))


if __name__ == '__main__':
    main()
