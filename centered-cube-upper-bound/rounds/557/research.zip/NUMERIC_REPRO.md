# R557 数值最小复现材料

本子包仅覆盖固定 generic 点的有限混合探路、自方向积分对照、16个 τ=0 Arb 公式证书和标量/3×3符号核验。**未获稳定 n4 证据**；不认证期望收敛、全 Q 接收下界或根阶预算。角点有限点值比较已取消。

## 运行顺序

四个脚本使用自身目录的输入输出，不依赖当前工作目录、原 `/tmp` 文件或研究仓库。复制整个白名单到任意可写目录即可。Python须有 NumPy、SciPy、SymPy、mpmath、python-flint；实际版本、命令、源码hash及摘要见 NUMERIC_SUMMARY.json / NUMERIC_MANIFEST.json。

```sh
PY=/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python
OPENBLAS_NUM_THREADS=1 "$PY" /absolute/path/to/package/covariance_numeric.py
OPENBLAS_NUM_THREADS=1 "$PY" /absolute/path/to/package/cauchy_radial_certificate.py
OPENBLAS_NUM_THREADS=1 "$PY" /absolute/path/to/package/covariance_symbolic.py
OPENBLAS_NUM_THREADS=1 "$PY" /absolute/path/to/package/conditional_numeric.py
```

第一阶段原混合生成相邻 covariance_numeric.json；第二阶段Arb依赖它，符号脚本独立；第三阶段条件化复用原输入并读取Arb固定参数作交叉核验。条件脚本虽允许没有Arb文件时运行，但要获得本归档的16点交叉核验，应按上述顺序。主代理要求的三阶段已在本目录实际执行完毕；运行时cwd为 `/tmp`，不是脚本目录，验证相邻路径有效。

原JSON中的参数/seed不变：n=2、4，点由Uniform(.1,.9)^n、SeedSequence([5572026,n,0])产生，每维4批×64；batch b使用[5572026,n,b+1]。条件化不新增随机数。脚本导入NumPy前设置单线程BLAS；全部方向与正负径向半线都保留，无R/t/Z模型截尾。每维20秒停止规则也保留。

## 实跑摘要

| n/点 | 原F/4 | 原all/max方向比 | 条件化F/4 | ESS原→条件化 |
|---|---:|---:|---:|---:|
| 2/0 | .0256130492 | 1.26883546 | .0245412952 | 91.80→100.89 |
| 2/1 | .0277298102 | 1.25926044 | .0291916171 | 81.31→84.95 |
| 4/0 | .00264088678 | 1.51278795 | .00255305275 | 37.36→34.29 |
| 4/1 | .00231114271 | 1.42902376 | .00223563779 | 10.50→10.87 |

n4点1的条件化最大样本仍贡献28.93%，未解决稀有混合估计。n2仅小幅改善，n4有一例ESS恶化，故未观察到实质减噪。不同方向条件化不同，不能由逐项条件期望推出整个和必降方差；旧max不是条件化后的同一量。

两套脚本本次各维均完成256样本、无20秒停止或不良矩阵停止，无QUADPACK message。求积返回message完整保存，不因full_output而漏掉；固定普通点及最大reported-error/最窄width点均加严复核。原方法缩放指数≤−745置0属浮点范围损失，条件化方法将横向极小密度留在log域；归一权重仍可能下溢。详细计数在摘要中。求积器误差估计和加严一致性不是严格区间证书。

## 严格证书的准确范围

cauchy_radial_certificate.py在192bit Arb下，为原输入中预定选择的16组binary-float精确有理参数c,m检查闭式Omega严格在(0,4)，并以SymPy核部分分式残差0。Arb与独立浮点quad最大差约1.45e−13。conditional_numeric.py对这16个c_hex/m_hex使用自己的tau0普通Voigt积分，最大浮点差约1.43e−13；**这个浮点差本身不是区间证明**，不认证条件化全估计。

covariance_symbolic.py只核标量Gaussian-scale-mixture密度残差0，及一个精确非对角3×3协方差的Schur行列式/横向二次型残差0，不将有限符号例子当全Q下界。身份独审原件为 /tmp/r557_covariance_audit.md（本子包不修改或代替该原件）。

## 最终白名单与可再生文件

最终数值子包仅应包含：

- covariance_numeric.py
- conditional_numeric.py
- cauchy_radial_certificate.py
- covariance_symbolic.py
- cauchy_radial_certificate.json
- covariance_symbolic.json
- NUMERIC_SUMMARY.json
- NUMERIC_REPRO.md
- NUMERIC_MANIFEST.json

**排除** covariance_numeric.json、conditional_numeric.json：两者为可重生的大样本中间结果，本地实际运行后暂留，不能以目录全打包替代此白名单。先跑原混合即可重生后续所需输入，不需另附原始全样本文件。白名单总大小与每文件源码/结果SHA记录于manifest；manifest不自哈希。

源码hash应保持不变。重新运行时command、elapsed及依赖JSON的内容hash可能随路径/耗时变化，不能要求JSON逐字节相同；应检查固定点/seed、实际完成样本数与数值结果、告警及严格断言。未扩大扫描、未改研究仓库或原脚本/数据。

## 最终源码哈希字段修复与再次实跑

前一manifest的source_script_hashes记录了原始`/tmp/r557_*`脚本，而final_file_hashes记录相邻路径适配后的副本；字段命名未明确区分，因而不能把这两类值称为一致。现已将原件改列为original_source_script_hashes，将source_script_hashes统一定义为实际运行的最终可移植源码。最终四脚本已再次按完整依赖顺序实跑，全部退出0、数值结果不变；摘要中的运行时间及依赖hash已同步更新。

最终核验程序如下（将PACKAGE替换为本目录绝对路径；本次已实际执行，所有assert通过）：

```python
from pathlib import Path
import json, hashlib
r = Path("PACKAGE")
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((r / "NUMERIC_MANIFEST.json").read_text())
s = json.loads((r / "NUMERIC_SUMMARY.json").read_text())
for name, digest in m["source_script_hashes"].items():
    out = json.loads((r / name.replace(".py", ".json")).read_text())
    assert digest == m["final_file_hashes"][name]["sha256"]
    assert digest == sha(r / name) == out["script_sha256"]
    assert digest == s["final_script_sha256"][name]
for name, info in m["final_file_hashes"].items():
    assert sha(r / name) == info["sha256"]
for name, info in m["excluded_actual_runs"].items():
    assert sha(r / name) == info["sha256"]
a = json.loads((r / "conditional_numeric.json").read_text())
b = json.loads((r / "cauchy_radial_certificate.json").read_text())
assert a["source_sha256"] == b["source_sha256"] == sha(r / "covariance_numeric.json")
assert a["external_cauchy_reference"]["sha256"] == sha(r / "cauchy_radial_certificate.json")
print("PASS: all final source/output/summary/manifest and dependency hashes")
```

最后两项依赖检查需先重生被白名单排除的大JSON；白名单内容本身的哈希核验不要求附大JSON。原始历史脚本hash不参与最终可移植源码的相等断言。
