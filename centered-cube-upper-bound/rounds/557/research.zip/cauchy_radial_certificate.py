"""Finite Arb certificates for the exact tau=0 radial Cauchy integral.
Each input c,m is the exact rational represented by the recorded binary float.
No continuum/whole-cube certificate is claimed.
"""
from pathlib import Path
from fractions import Fraction
import json,sys,hashlib
import flint
from flint import arb,ctx
import numpy as np
from scipy.integrate import quad
import sympy as s
ctx.prec=192
r,m=s.symbols('r m',real=True);c=s.symbols('c',positive=True);q=m*m+c*c
partial=2*m/q**2/r+1/q/r**2+(-2*m/q**2*(r-m)+(m*m-c*c)/q**2)/((r-m)**2+c*c)
assert s.factor(partial-1/(r*r*((r-m)**2+c*c)))==0
source=Path(__file__).with_name('covariance_numeric.json')
raw=json.loads(source.read_text())['records'][0]
samples=raw['raw_samples'];indices={min(range(len(samples)),key=lambda i:samples[i]['t']),max(range(len(samples)),key=lambda i:samples[i]['t'])}
for ip in range(2):indices.add(max(range(len(samples)),key=lambda i:samples[i]['all'][ip]))
def exact(v):
 f=Fraction.from_float(float(v));return arb(f.numerator)/f.denominator
cases=[]
for i in sorted(indices):
 for ip,x in enumerate(raw['points']):
  for sign in [-1,1]:
   cf=float(np.pi*samples[i]['t']/2);mf=float((x[0]+sign*x[1])/2)
   ca=exact(cf);ma=exact(mf);b=arb(1)/2;Q=ma*ma+ca*ca
   angle=arb.pi()-((b-ma)/ca).atan()-((b+ma)/ca).atan()
   value=ca/arb.pi()*(2/(Q*b)+ma/(Q*Q)*(((b-ma)**2+ca*ca)/((b+ma)**2+ca*ca)).log()+(ma*ma-ca*ca)/(ca*Q*Q)*angle)
   assert value>0 and value<4
   # Only a floating cross-check of the exact formula; not a rigorous quadrature certificate.
   def f(u):
    if u==0:return 0.
    return cf/np.pi*(1/((1/u-mf)**2+cf**2)+1/((1/u+mf)**2+cf**2))
   ans,err=quad(f,0,2,epsabs=1e-12,epsrel=1e-11,limit=300)
   cases.append(dict(sample_index=i,point_index=ip,sign=sign,c_hex=cf.hex(),m_hex=mf.hex(),arb_interval=str(value),quad=ans,quad_reported_error=err,absolute_difference=float(abs(value.mid()-arb(ans)).mid())))
out=dict(command=f'{sys.executable} {__file__}',python=sys.version,python_flint=flint.__version__,sympy=s.__version__,precision_bits=ctx.prec,partial_fraction_residual='0',cases=cases,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Finite tau=0 exact binary-float input Arb formula certificates: 0<Omega<4. Float quadrature cross-check only. No general receiver or MC certificate.')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'cases':len(cases),'max_quad_difference':max(c['absolute_difference'] for c in cases),'all_strictly_between_0_and_4':True}))
