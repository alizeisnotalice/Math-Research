"""Exact scalar normalization for the actual vertex-spectrum Gaussian mixture.
No receiver inequality is certified by this script.
"""
from pathlib import Path
import sympy as s
import sys,json,hashlib
z,c,x=s.symbols('z c x',positive=True)
density=s.integrate(z/(s.pi*c)*s.exp(-(1+x*x/c**2)*z*z/2),(z,0,s.oo))
residual=s.simplify(density-c/(s.pi*(c*c+x*x)))
assert residual==0
Sigma=s.Matrix([[2,s.Rational(1,3),s.Rational(1,5)],[s.Rational(1,3),3,s.Rational(1,7)],[s.Rational(1,5),s.Rational(1,7),4]])
e=s.ones(3,1)
U=s.Matrix([[1/s.sqrt(2),1/s.sqrt(6)],[-1/s.sqrt(2),1/s.sqrt(6)],[0,-2/s.sqrt(6)]])
zv=s.Matrix(s.symbols('z0:3'))
B=Sigma.inv();a=(e.T*B*e)[0];C=U.T*Sigma*U
schur=s.simplify(Sigma.det()*a-3*C.det())
transverse=s.simplify((zv.T*B*zv)[0]-(e.T*B*zv)[0]**2/a-(zv.T*U*C.inv()*U.T*zv)[0])
assert schur==0 and transverse==0
out={'python':sys.version,'sympy':s.__version__,'command':f'{sys.executable} {__file__}','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'schur_determinant_residual':str(schur),'transverse_quadratic_residual':str(transverse),'scalar_density':str(s.simplify(density)),'residual':str(residual),'scope':'Scalar Gaussian-scale-mixture identity and one exact non-diagonal 3x3 Schur test only; no full-cube lower bound, no expectation substitution for covariance.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
