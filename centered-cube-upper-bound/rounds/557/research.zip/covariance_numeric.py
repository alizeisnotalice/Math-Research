"""R557 exact untruncated mixture; radial reciprocal quadrature, finite MC only."""
import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import quad,IntegrationWarning
from scipy.special import logsumexp
import itertools,json,time,sys,hashlib,warnings
SEED=5572026;START=time.monotonic()

def radial(a,m,strict=False):
 """Integral_.5^inf r^-2 exp(-a(r-m)^2/2)dr using z=1/r, no radial truncation."""
 sigma=1/np.sqrt(a);r0=max(.5,m);e0=.5*a*(r0-m)**2
 if m>=.5:rr=[m+u*sigma for u in [-8,-4,-2,-1,0,1,2,4,8]];width=min(2.,sigma/(r0*r0))
 else:
  scale=min(sigma,1/(a*(.5-m)));rr=[.5+u*scale for u in [0,1,2,4,8,16,32]];width=min(2.,4*scale)
 pts=sorted(set([0.,2.]+[float(1/r) for r in rr if r>=.5 and np.isfinite(r)]))
 underflow=[0]
 def f(z):
  if z==0:return 0.
  r=1/z;ex=-.5*a*(r-r0)*(r+r0-2*m)
  if ex<=-745:underflow[0]+=1;return 0.
  return np.exp(ex)
 total=err=0.;calls=0;warn=[];messages=[]
 with warnings.catch_warnings(record=True) as ws:
  warnings.simplefilter('always',IntegrationWarning)
  for lo,hi in zip(pts[:-1],pts[1:]):
   qr=quad(f,lo,hi,epsabs=max(1e-300,width*(1e-13 if strict else 1e-11)),epsrel=1e-9 if strict else 1e-7,limit=100,full_output=1)
   val,er,info=qr[:3]
   if len(qr)>3:messages.append(str(qr[3]))
   total+=val;err+=er;calls+=info['neval']
  warn=messages+[str(w.message) for w in ws]
 if total<=0 or not np.isfinite(total):raise ArithmeticError('nonpositive/nonfinite scaled radial integral')
 return np.log(total)-e0,dict(relative_error_estimate=float(err/total),evaluations=calls,warnings=warn,underflow_evaluations=underflow[0],width_estimate=float(width))

def summary_logs(logs):
 a=np.array(logs);tot=logsumexp(a);p=np.exp(a-tot);n=len(p)
 return dict(mean=float(np.exp(tot-np.log(n))),logmean=float(tot-np.log(n)),max_sample_fraction=float(p.max()),top_one_percent_fraction=float(np.sort(p)[-max(1,int(np.ceil(.01*n))):].sum()),contribution_ESS=float(1/np.sum(p*p)))

def run(n):
 begin=time.monotonic();points=np.random.default_rng(np.random.SeedSequence([SEED,n,0])).uniform(.1,.9,(2,n))
 dirs=np.array([(1,)+s for s in itertools.product([-1,1],repeat=n-1)],float);N=len(dirs)
 data=[];fail=None;checks=[];conditions=[];rad_errors=[];evals=0;warns=[];batches=[];pilot=None;worst_error=None;narrowest=None;underflows=0
 for batch in range(4):
  rng=np.random.default_rng(np.random.SeedSequence([SEED,n,batch+1]));indices=[]
  for within in range(64):
   if time.monotonic()-begin>=20:fail=dict(reason='20_second_dimension_budget',batch=batch,within_batch=within);break
   t=float(rng.exponential());z=rng.normal(size=N)
   if t<=0 or np.any(z==0):fail=dict(reason='zero_rng_draw',t=t,z=z.tolist());break
   zmin=np.min(np.abs(z));rows=(zmin/np.abs(z))[:,None]*dirs
   _,s,vt=np.linalg.svd(rows,full_matrices=False);cond=float((s[0]/s[-1])**2);conditions.append(cond)
   if not np.isfinite(cond) or cond>1e14:
    fail=dict(reason='ill_conditioned_covariance_not_discarded',condition=cond,t=t,z=z.tolist(),batch=batch,within_batch=within);break
   sd=(np.pi*t/(N*zmin))*s; logC=-n/2*np.log(2*np.pi)-np.log(sd).sum()
   wd=(dirs@vt.T)/sd; allpoints=[];maxpoints=[];directionlogs=[];branchshares=[];sample_warning_count=0
   for ip,x in enumerate(points):
    wx=(x@vt.T)/sd;con=[]
    for j,v in enumerate(wd):
     a=float(v@v);m=float(v@wx/a);res=wx-m*v;d=float(res@res)
     lp,ep=radial(a,m);lm,em=radial(a,-m)
     evals+=ep['evaluations']+em['evaluations'];rad_errors.extend([ep['relative_error_estimate'],em['relative_error_estimate']]);warns+=ep['warnings']+em['warnings'];sample_warning_count+=len(ep['warnings'])+len(em['warnings'])
     for mm,ll,ee in [(m,lp,ep),(-m,lm,em)]:
      underflows+=ee['underflow_evaluations']
      item=dict(a=a,m=mm,log_integral=ll,relative_error=ee['relative_error_estimate'],width=ee['width_estimate'],batch=batch,within=within,point=ip,direction=j)
      if worst_error is None or item['relative_error']>worst_error['relative_error']:worst_error=item
      if narrowest is None or item['width']<narrowest['width']:narrowest=item
     if batch==0 and within in [0,7] and j==0:
      sp,_=radial(a,m,True);sm,_=radial(a,-m,True);checks.append(dict(sample=within,point=ip,direction=j,absolute_log_difference=float(abs(logsumexp([sp,sm])-logsumexp([lp,lm])))))
     con.append(float(logC-np.log(4*N)-d/2+logsumexp([lp,lm])))
    allpoints.append(float(logsumexp(con)));maxpoints.append(float(max(con)));directionlogs.append(con);branchshares.append(float(np.exp(max(con)-logsumexp(con))))
   idx=len(data);indices.append(idx);data.append(dict(batch=batch,within=within,t=t,z=z.tolist(),condition=cond,all=allpoints,max=maxpoints,direction_logs=directionlogs,max_direction_share=branchshares,quadrature_diagnostic_failed=bool(sample_warning_count),quadrature_message_count=sample_warning_count))
   if len(data)==32:pilot=dict(samples=32,seconds=time.monotonic()-begin,projected_256_seconds=(time.monotonic()-begin)*8)
  if indices:
   batches.append(dict(batch=batch,seed=[SEED,n,batch+1],count=len(indices),points=[dict(all=summary_logs([data[k]['all'][p] for k in indices]),max=summary_logs([data[k]['max'][p] for k in indices]),ratio=float(np.exp(logsumexp([data[k]['all'][p] for k in indices])-logsumexp([data[k]['max'][p] for k in indices])))) for p in range(2)]))
  if fail:break
 for label,item in [('largest_reported_error',worst_error),('narrowest_width',narrowest)]:
  if item is not None:
   ls,ds=radial(item['a'],item['m'],True);checks.append(dict(selection=label,original=item,tight_log_integral=ls,absolute_log_difference=abs(ls-item['log_integral']),tight_diagnostics=ds))
 out=dict(n=n,points=points.tolist(),point_seed=[SEED,n,0],directions=dirs.tolist(),projective_direction_count=N,completed_samples=len(data),requested_samples=256,batches=batches,stop=fail,pilot=pilot,seconds=time.monotonic()-begin,condition_summary=dict(max=max(conditions) if conditions else None,over_1e12=int(sum(c>1e12 for c in conditions))),radial_integration=dict(calls=evals,max_reported_relative_error=max(rad_errors) if rad_errors else None,warnings=warns,tight_checks=checks,underflow_evaluations=underflows,underflow_policy='Scaled radial integrand exponent<=-745 assigned0; floating range loss, not exact arithmetic or model R/t/Z truncation.'),points_results=[],raw_samples=data)
 for p in range(2):
  if not data:break
  al=summary_logs([d['all'][p] for d in data]);ma=summary_logs([d['max'][p] for d in data]);ratio=np.exp(al['logmean']-ma['logmean'])
  means=np.array([b['points'][p]['all']['mean'] for b in batches]);mx=np.array([b['points'][p]['max']['mean'] for b in batches]);complete=all(b['count']==64 for b in batches)
  risks=[]
  if warns:risks.append('quadrature_message_diagnostic_failure')
  for name,v in [('all',al),('max',ma)]:
   if v['max_sample_fraction']>.1 or v['top_one_percent_fraction']>.5 or v['contribution_ESS']<32:risks.append(name+'_rare_contribution_warning')
  out['points_results'].append(dict(point_index=p,F_over4=al,maximum_direction_same_coefficient=ma,ratio=float(ratio),batch_standard_error_diagnostic=float(np.std(means,ddof=1)/np.sqrt(len(means))) if len(means)>1 and complete else None,paired_all_minus_max_batch_means=(means-mx).tolist(),max_direction_share_quantiles={str(q):float(np.quantile([d['max_direction_share'][p] for d in data],q)) for q in [0,.5,.9,1]},risk_flags=risks,status='finite_MC_diagnostics_only'+('_rare_event_unresolved' if risks else '')))
 return out

def main():
 records=[run(2),run(4)]
 result=dict(model=dict(F_over4='E_t,Z C_Sigma/(4N) sum_projective_d integral_|r|>.5 r^-2 exp[-(x-rd)^T Sigma^-1(x-rd)/2]dr',normalization='full and max projective direction both retain identical C/(4N) coefficient; max includes paired signed radial integrals',radii='integrated over full two half-lines, no R sampling/truncation',t='Exp(1)',Z='independent standard normals',directions='all signed directions with first coordinate1',point_distribution='Uniform(.1,.9)^n',seed=SEED,batches=4,batch_size=64),records=records,versions=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__),threads={k:os.environ[k] for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS']},command=f'{sys.executable} {Path(__file__)}',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.monotonic()-START,scope='Untruncated exact mixture model, floating radial quadrature and finite Monte Carlo; no expectation convergence, finite variance, full-Q minimum, weak bound, or rigorous numerical certification.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
 for r in records:print(r['n'],r['completed_samples'],r['stop'],r['seconds'],[(p['F_over4']['mean'],p['ratio'],p['risk_flags']) for p in r['points_results']])
if __name__=='__main__':main()
