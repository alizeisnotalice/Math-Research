"""R557 integrate each direction's own Gaussian mixing variable; reuse frozen inputs."""
import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,sys,time,hashlib,warnings
import numpy as np
import scipy
from scipy.integrate import quad,IntegrationWarning
from scipy.special import voigt_profile,logsumexp
import mpmath as mp
SOURCE=Path(__file__).with_name('covariance_numeric.json');START=time.monotonic()

def omega(tau,c,m,strict=False):
 w=max(tau,c);rlist=[]
 for centre in [m,-m,.5]:
  rlist.extend(centre+k*w for k in [-16,-8,-4,-2,-1,0,1,2,4,8,16])
 pts=sorted(set([0.,2.]+[float(1/r) for r in rlist if r>=.5 and np.isfinite(r)]))
 calls=0;total=error=0.;messages=[];zeros=[0];negative=[0]
 def f(z):
  if z==0:return 0.
  r=1/z;v=float(w*(voigt_profile(r-m,tau,c)+voigt_profile(-r-m,tau,c)))
  if not np.isfinite(v) or v<0:negative[0]+=1;raise ArithmeticError('invalid Voigt density')
  if v==0:zeros[0]+=1
  return v
 with warnings.catch_warnings(record=True) as ws:
  warnings.simplefilter('always',IntegrationWarning)
  for lo,hi in zip(pts[:-1],pts[1:]):
   result=quad(f,lo,hi,epsabs=max(1e-300,min(1.,w*c)*(1e-14 if strict else 1e-12)),epsrel=1e-9 if strict else 1e-7,limit=100,full_output=1)
   v,e,info=result[:3];total+=v;error+=e;calls+=info['neval']
   if len(result)>3:messages.append(str(result[3]))
  messages.extend(str(q.message) for q in ws)
 if total<=0 or not np.isfinite(total):raise ArithmeticError('invalid scaled Omega')
 return float(np.log(total)-np.log(w)),dict(relative_error_estimate=error/total,evaluations=calls,messages=messages,zero_voigt_evaluations=zeros[0],invalid_density_evaluations=negative[0],width=w)

def logs_summary(values):
 a=np.array(values);ls=logsumexp(a);p=np.exp(a-ls)
 return dict(mean=float(np.exp(ls-np.log(len(a)))),logmean=float(ls-np.log(len(a))),max_sample_fraction=float(p.max()),top_one_percent_fraction=float(np.sort(p)[-max(1,int(np.ceil(.01*len(p)))):].sum()),contribution_ESS=float(1/np.sum(p*p)),underflowed_normalized_weights=int(np.sum(p==0)))

def cauchy_formula(c,m):
 with mp.workdps(60):
  c=mp.mpf(c);m=mp.mpf(m);q=m*m+c*c;A=2*m/q**2;B=1/q;D=(m*m-c*c)/q**2
  def P(r):return A*mp.log(abs(r))-B/r-A/2*mp.log((r-m)**2+c*c)+D/c*mp.atan((r-m)/c)
  return float(D+c/mp.pi*(P(mp.mpf('-.5'))-P(mp.mpf('.5'))))

def run(original):
 n=original['n'];begin=time.monotonic();dirs=np.array(original['directions']);points=np.array(original['points']);N=len(dirs)
 bases=[]
 for d in dirs:
  e=d/np.sqrt(n);_,_,vt=np.linalg.svd(e[None,:],full_matrices=True);U=vt[1:].T
  bases.append((e,U))
 raw=[];failure=None;conditions=[];errors=[];warnings_all=[];checks=[];worst=None;narrowest=None;voigt_zeros=0;phi_underflows=0;calls=0;pilot=None
 for index,sample in enumerate(original['raw_samples']):
  if time.monotonic()-begin>=20:failure=dict(reason='20_second_dimension_budget',next_original_sample=index);break
  t=sample['t'];z=np.array(sample['z']);c=np.pi*t/N;contributions=[[] for x in points];samplewarn=[];rowinfo=[]
  for j,(e,U) in enumerate(bases):
   mask=np.arange(N)!=j;other=z[mask];zmin=np.min(np.abs(other));scale=c/zmin
   rows=(zmin/np.abs(other))[:,None]*dirs[mask];A=rows@U;b=rows@e
   left,s,vt=np.linalg.svd(A,full_matrices=False);condition=float((s[0]/s[-1])**2);conditions.append(condition)
   if not np.isfinite(condition) or condition>1e14:
    failure=dict(reason='ill_conditioned_transverse_C_not_discarded',sample=index,direction=j,condition=condition,t=t,z=z.tolist());break
   beta=vt.T@((left.T@b)/s);res=b-A@beta
   tau=0. if n==2 else float(scale*np.linalg.norm(res)/np.sqrt(n))
   rowinfo.append(dict(direction=j,condition=condition,tau=tau,residual_norm=float(np.linalg.norm(res)),n2_exact_orthogonality_used=n==2))
   for ip,x in enumerate(points):
    transverse=U.T@x;wx=(vt@transverse)/(scale*s)
    logphi=-(n-1)/2*np.log(2*np.pi)-np.log(scale*s).sum()-.5*(wx@wx)
    if logphi<-745:phi_underflows+=1
    m=float((e@x-beta@transverse)/np.sqrt(n))
    try:lo,diag=omega(tau,c,m)
    except Exception as exc:
     failure=dict(reason='radial_integration_exception',sample=index,direction=j,point=ip,error=repr(exc),tau=tau,c=c,m=m);break
    calls+=diag['evaluations'];errors.append(diag['relative_error_estimate']);samplewarn+=diag['messages'];voigt_zeros+=diag['zero_voigt_evaluations']
    item=dict(sample=index,direction=j,point=ip,tau=tau,c=c,m=m,log_omega=lo,reported_error=diag['relative_error_estimate'],width=diag['width'])
    if worst is None or item['reported_error']>worst['reported_error']:worst=item
    if narrowest is None or item['width']<narrowest['width']:narrowest=item
    if index in [0,7] and j==0:
     ls,ds=omega(tau,c,m,True);check=dict(selection='preselected',original=item,absolute_log_difference=abs(ls-lo),tight_diagnostics=ds)
     if n==2:
      exact=cauchy_formula(c,m);check.update(cauchy_formula_60d=exact,cauchy_relative_difference=float(abs(np.expm1(lo-np.log(exact)))))
     checks.append(check)
    contributions[ip].append(float(logphi+lo-np.log(4*N*np.sqrt(n))))
   if failure:break
  if failure:break
  warnings_all.extend(samplewarn);new=[float(logsumexp(q)) for q in contributions]
  raw.append(dict(original_sample_index=index,batch=sample['batch'],within=sample['within'],new_all_logs=new,direction_logs=contributions,projection_diagnostics=rowinfo,quadrature_diagnostic_failed=bool(samplewarn),quad_messages=samplewarn))
  if len(raw)==32:pilot=dict(completed=32,seconds=time.monotonic()-begin,projected_256_seconds=(time.monotonic()-begin)*8)
 for label,item in [('worst_reported_error',worst),('narrowest_width',narrowest)]:
  if item is not None:
   ls,ds=omega(item['tau'],item['c'],item['m'],True);checks.append(dict(selection=label,original=item,absolute_log_difference=abs(ls-item['log_omega']),tight_diagnostics=ds))
 point_results=[];batch_results=[]
 for batch in range(4):
  ids=[i for i,r in enumerate(raw) if r['batch']==batch]
  if ids:batch_results.append(dict(batch=batch,count=len(ids),points=[dict(old_all=logs_summary([original['raw_samples'][i]['all'][p] for i in ids]),new_all=logs_summary([raw[i]['new_all_logs'][p] for i in ids])) for p in range(2)]))
 for p in range(2):
  if not raw:break
  old=logs_summary([original['raw_samples'][i]['all'][p] for i in range(len(raw))]);new=logs_summary([r['new_all_logs'][p] for r in raw]);risks=[]
  for name,v in [('old',old),('new',new)]:
   if v['max_sample_fraction']>.1 or v['top_one_percent_fraction']>.5 or v['contribution_ESS']<32:risks.append(name+'_rare_contribution_warning')
  if warnings_all:risks.append('new_quadrature_diagnostic_failed')
  point_results.append(dict(point=p,old_all=old,new_all=new,new_over_old_mean=float(np.exp(new['logmean']-old['logmean'])),flags=risks))
 return dict(n=n,points=points.tolist(),N=N,completed_samples=len(raw),requested_samples=len(original['raw_samples']),stop=failure,pilot=pilot,seconds=time.monotonic()-begin,points_results=point_results,batches=batch_results,condition_max=max(conditions) if conditions else None,condition_over_1e12=sum(q>1e12 for q in conditions),radial_diagnostics=dict(function_evaluations=calls,max_reported_relative_error=max(errors) if errors else None,messages=warnings_all,tight_checks=checks,zero_voigt_evaluations=voigt_zeros,phi_log_below_minus745_count=phi_underflows,underflow_policy='Transverse density retained in log domain even below -745; float exp of normalized weights/summary may underflow and is counted. No r,t,Z model truncation; scipy Voigt and ordinary double arithmetic remain numerical approximations.'),raw_samples=raw)

def main():
 source_bytes=SOURCE.read_bytes();original=json.loads(source_bytes);records=[]
 for r in original['records']:records.append(run(r))
 certificate=Path(__file__).with_name('cauchy_radial_certificate.json');external_checks=[];certificate_hash=None
 if certificate.exists():
  cb=certificate.read_bytes();certificate_hash=hashlib.sha256(cb).hexdigest()
  for case in json.loads(cb)['cases']:
   c=float.fromhex(case['c_hex']);m=float.fromhex(case['m_hex']);lo,diag=omega(0.,c,m,True)
   external_checks.append(dict(c_hex=case['c_hex'],m_hex=case['m_hex'],our_omega=float(np.exp(lo)),independent_certified_case_float=case['quad'],absolute_difference=abs(float(np.exp(lo))-case['quad']),diagnostics=diag))
 result=dict(external_cauchy_reference=dict(path=str(certificate),sha256=certificate_hash,checks=external_checks,scope='Only compares identical fixed parameters to independent certificate float representations; not an interval certificate for our entire numerical estimator.'),model='Same F/4 exact mixture, sum_d phi_C(U^T x) Omega_c(tau,m)/(4N sqrt(n)); each summand independently integrates own Z_d, same original t/Z data, no new random draw',source_json=str(SOURCE),source_sha256=hashlib.sha256(source_bytes).hexdigest(),source_script_sha256=original['script_sha256'],records=records,versions=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,mpmath=mp.__version__),command=f'{sys.executable} {Path(__file__)}',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),threads={k:os.environ[k] for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS']},elapsed_seconds=time.monotonic()-START,scope='Different directions condition on different sigma-algebras. Summand conditionalization preserves means but no variance decrease theorem for total sum. No comparison to old max, no MC convergence or full-Q claim.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
 for r in records:print(r['n'],r['completed_samples'],r['stop'],r['seconds'],[(p['old_all']['mean'],p['new_all']['mean'],p['old_all']['contribution_ESS'],p['new_all']['contribution_ESS'],p['flags']) for p in r['points_results']])
if __name__=='__main__':main()
