# R147 共同 λ 上证书：运行前冻结计划

本计划在正式脚本首次运行前写入。所有工作仅限 q_extremal.md、q_extremal_check.py/json 和本计划。先前有一次临时 Python 探索，使用不同的基础补集 r<(n+1)ρ；该探索不作为本轮最终剩余域的结论，也不在本脚本重跑。

## 冻结输入与脚本

numeric_margin.json SHA256: 0f504950a5b4d7dc94e362171c0153c114fc601194e16e5df1d6f220c958798b
r146_numeric_score.json SHA256: 6e103db84e39cdd9bc8a874083f83a83bb1d5797ab180f4b86c1482940821879
q_extremal_check.py SHA256: 40a6463752e7c0a2f311d74b19dae2071ce7dd40d5583596f604e554051eecdf

numeric_margin 为其作者完成四次有记录执行后冻结的最终 JSON；最后一次仅修改 summary Decimal 精度，未扩菜单。本检查不重算原核，不变来源、原 ν、Q、q、e、μ、α 或 ρ。

## 域和数值承诺

- 当前补集固定为 terminal good∩{ρ>0}∩{r_t<2(2n+3)L_g mρ}，其中 m=μ(terminal good∩{ρ>0}) 整行固定，不按 t 或 score 更新。以 Fraction 解析已存十进制数形成严格补集，并检查与冻结标签一致。
- bad 保持原 terminal bad。检查目标为补集×bad 的所有正 score pair，保留实际 ρ，明确正放松 Ψ/FA；不把该放松当原 signed 交通。
- 同一 receiver-time 行只使用一个 λ。固定网格 λ=0 或 λ=10^(k/4)/L_t，k=-32,…,32，共66项，与探索使用的网格相同，不扩大。
- 每行计算 Uλ=(1+λL_t)^2 sup[ρδ/((1+λr_v)(1+λr_u))]/4，并与独立来源上帽 U0、该有限模型的实际正放松交通比较。网格最小值不是连续 infλ 的数值认证。
- 保留 initial/pressure/expanded 原阶段，报告空行、严格改善比例及 cap/U0 分布；只报告有限样本，不推断一般维数阶或原外预算。
- 主计算采用浮点，对每个非空 case/stage 选第一行和相对改善最强行（去重后至多10行），将已选 λ 的十进制打印值作为一个合法有理 λ，以 Fraction 检查共同质量帽、逐边支配、AM-GM、最终上界和相对 U0 的严格改善。这仅认证保存十进制数据的有限代数，不认证原真实核/标签。
- 原 FA closed/interior 的剩余样本计数与点权只作配套记录，不称为全窗积分或接收质量。

运行命令：`python3 q_extremal_check.py`。输出存在时脚本拒绝覆盖，输入或脚本 SHA 改变时拒绝运行。正式 producer 计划只执行一次；如失败，先披露失败与修订再运行，不静默改写记录。
