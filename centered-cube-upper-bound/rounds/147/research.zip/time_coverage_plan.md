# R147 original finite-model whole-time coverage protocol

Only time_coverage.py/json/plan.md/notes.md are owned. The prior time_gate_check files remain frozen. No kernel re-evaluation, new receiver/dx sampling, or use of 2070 sampled-time occupancy as a whole-time conclusion.

## Frozen inputs and selection

Read R136 active_traffic_v2.json, R142 numeric_receiver.json, R143 numeric_flux.py for the already audited primitive, R142 time_primitive_check.json for baseline comparisons, and final R147 numeric_margin.json. Select the same179 original positive receivers uniquely identified by numeric_margin receiver_time_margins: I1=11,P1=168. Preserve every original stage and distribution label. The179 consist of initial I1=2/P1=25; pressure P1=5; expanded I1=9/P1=138. Process those three stages in this order, with no data-dependent menu expansion.

R142 traffic.FA_caps contains original good/bad/ρ>0/Ψ/positive-score acceptance and original saved FA(lo,hi) intervals. Use those saved interval endpoints as frozen decimal rational inputs, not new recovery of exact original high-precision FA geometry. Check source eligibility, original Ψ and delta against each source score segment; intersect the new gate only with those original caps. Intersect each saved FA interval with its exact saved score-segment domain; retain raw endpoints and report any rounding-length clip (do not silently extend a score formula past its segment). Keep rho0/no-positive-score source cases zero; no source may be added from a sampled point.

## One new gate, full original time

Use N=2n+3, original common μQ_i=ν_iQ_i/q and terminal Gplus={good_i andρ_i>0}. Set m=ΣGplus μQ_i, e_g=Σν_i saved_wg_i, Lg=Kq/(p e_g), source r_i(t)=KQ_i/[p c_i t^(−k_i)]. New closed gate is r_i(t)≥2N Lg mρ_i. Rebuild m,Lg from the same original finite inputs, compare to numeric_margin's saved32-digit values, and do not renormalize μQ or replace Q by J.

For positiveρ andk_i>0, gate entry obeys

`t_entry^k_i = c_i/[Q_i e_g/(2Nρ_i ΣGplus νQ)]`.

This exact rational right-hand side uses cancellation of common p,q,K only as a check of the same gate. Determine empty/full/partial intersection with each cap by exact comparisons against lo^k_i andhi^k_i before taking a root; isolated equality endpoints have zero measure. In partial cases compute the root at the current mpmath precision. k_i=0 cannot have positive δ=(k_i−k_j)+; verify rather than divide0. m=0 would mean no eligible positive traffic and is handled explicitly, not divided by.

## Analytic integration and precision

Reuse R143 numeric_flux.primitive(u,A,B,C), which is safe to import (main guarded). Do not import R142 time_primitive_check.py because it executes/writes at module load. Two-score segments use the already proven rational endpoint formula; three-score segments use the same closed primitive and pair rank mapping as R142/R143. Integrate original pair `ρ_i ν_iν_j δ c_i c_j t^(−k_i−k_j)/e_t² dt/t` over full cap, paid intersection, and residual intersection independently. No numerical quadrature. Preserve120-digit c/score endpoints and savedfloat FA endpoints separately; do not repair frozen inputs into new geometry.

Run all179 at80 and120 decimal digits; these few hundred closed-form intervals are small enough to avoid subselecting. Require each row's whole=paid+residual up to1e−60 relative scale and nonnegativity, and relative80/120 changes for nonzero whole/paid/residual≤1e−40. Record both values and actual residuals. Compare whole outer-weighted F=(p hardmass/q)whole against R142 stored F_raw, or R142 audited primitive oracle for P1; allow the already used1e−8 relative tolerance and report actual difference. This is a frozen saved-kernel comparison, not exact-kernel certification.

## Outputs and interpretation

Save per cap entry, branch, original interval, integrated masses; per receiver whole/paid/residual and fractions at both precisions, original stage/distribution/gates; summaries by stage/case/distribution and source, maximum residual examples and all zero-residual counts. Aggregate sums are finite receiver-record sums, not dx integrals or probability estimates. Include input/script/plan SHA256 and explicit execution status. A nonzero residual disproves complete coverage only in this original finite time model; no remaining branch is silently removed or called paid. Stop after these four files are delivered.
