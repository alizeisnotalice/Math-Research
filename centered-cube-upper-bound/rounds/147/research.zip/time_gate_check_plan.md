# R147 exact time-gate and finite source-cap protocol

Only four owned files time_gate_check.py/json/plan.md/notes.md in this directory. Standard-library Fraction arithmetic, no quadrature/random search or old posterior/channel rerun. Verify a finite menu and endpoint cases, not FULL or the main proof.

For positive rational thresholds a_i,C,N, rational 0<τ<h and ρ∈[0,1], define w_t=∏min(1,a_i/t), k_t=#{a_i<t}, r_t=C/w_t. Split at every threshold in(τ,h). On a segment w=c t^-k and is continuous across rational endpoints. For ρ>0, cap w*=C/(Nρ), and direct integration in w gives

`J_l=(ρ/C)[min(w_lo,w*)−w_hi]_+`.

For k=0 this is zero, even if the gate holds throughout. Gate classification all/partial/empty retains endpoint equality separately. A partial gate time may be irrational; store exact equation `t^k=c/w*` and the rational interval containing it. Do not approximate that root or manufacture rational time samples. Check these segment values sum exactly to

`J=[min(ρ/r_τ,1/N)−ρ/r_h]_+ ≤1/N`.

ρ=0 is evaluated as J=0 without division; its traffic is zero even though r≥Nρ always holds.

## Frozen three-stage time menu: 21 cases, N=n+1

Initial six:
1–3: n1,a=(1/2),[τ,h]=[1/4,2],ρ=1/2, with w*=wτ, wh, and (wτ+wh)/2 respectively.
4: n2,a=(2,3),[1/4,1],ρ=1/2,w*=1 (constant segment on equality).
5: n2,a=(1/2,3/4),[1/4,2],ρ=0,C=1.
6: same n2 thresholds/window,ρ=1/2,w*=2wτ (full gate).

Pressure six:
7: n2,a=(1/2,1/2),[1/4,2],ρ=1/2,w*=(wτ+wh)/2 (nonrational partial root).
8: n4,a=(1/4,1/2,1,2),same window,ρ=1/2,w*=w_(1/2) (gate equality at a score breakpoint).
9: n4,a=(1/2)^4,same window,ρ=1/2,w*=wh/2 (empty gate).
10: n4,a=(3)^4,same window,ρ=1/2,w*=2 (constant full gate).
11–12: n4,a=(1/4,1/2,1,2),same window,w*=(wτ+wh)/2,ρ=1 and1/1000000.

Expanded nine: n=8,16,32 with periodic thresholds (1/8,1/2,3/4,3/2,3),window[1/4,2],ρ=2/3; each with w*=wτ,midpoint(wτ,wh),wh. For every ρ>0,C=Nρw*.

## Finite common-source budget: eight cases

For n=1,2,4,8,16,32 use four sources with ν=(1,2,3,1)/7, Q=(1,2,3,5),ρ=(0,1/4,2/3,1). Threshold vectors: (1/4)^n; alternating(1/2,3/2); periodic(1/2,1,3); (3)^n. Common window[1/4,2],N=n+1,K=1. Choose q=(∑νQ)×1 for odd index and×5/4 for even index, and p=λKq/e_h with λ=2 or3 alternating. Then L_t=Kq/(p e_t)≤1/λ≤1/2 on the full window, μQ_i=ν_iQ_i/q is a subprobability, and C_i=KQ_i/p.

Two near-saturation probes n4,16: first source thresholds(1/4)^n,second(3)^n;ν1=99/(200N+99),ν2=1−ν1,Q2=1,ρ1=1,ρ2=0. Set e_h=ν1 wh1+ν2, Q1=2Nν2/(e_h−2Nν1)>0, q=ν1Q1+ν2,p=2q/e_h,K=1. This fixes r_τ,1=N exactly without post-run tuning.

Check exact finite source certificate

`(1/2)∑μQ_i J_i ≤ (∑μQ_i)/(2N) ≤1/(2N)`.

Do not claim the actual L-weighted integral equals this cap. Instead split at all sources' threshold times; for each segment L is increasing, so exact endpoint bounds give `∑L_lo μQ_i J_i,l ≤ ∫L_t∑μQ_i ρ_i k_i/r_i 1gate dt/t ≤∑L_hi μQ_i J_i,l ≤(1/2)∑μQ_iJ_i`. Save both exact rational bounds, L maximum, all mass normalizations, gate roots, and cap slack. Neither deletion nor time-varyingρ is introduced.

Any failure is reported without broadening the menu; all completed identities and source caps use exact Fraction. No general theorem is claimed on the strength of these finitely many tests. Stop at delivery.
