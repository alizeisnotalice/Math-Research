# R147 numeric_margin frozen protocol (with main threshold amendment before run)

Own only numeric_margin_plan.md, numeric_margin.py/json/notes.md in this work directory. Other agents are active; do not edit their files, old rounds or Git. No new kernels, receivers, quadrature, continuous-time minima/integration, FULL or dimension fit.

## Inputs

R146 posterior/time2070 copied by parent to this work/r146_numeric_score.json, SHA6e103db84e39cdd9bc8a874083f83a83bb1d5797ab180f4b86c1482940821879; its original FA flags and printed-time saved-cap semantics remain distinct. Read R142 numeric_receiver.json SHA c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55 for selected179 receivers Q,p,q and same exact nu; R136 active_traffic_v2.json SHA1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de for original K,wg. Old data root /Users/zhengzhihao/Desktop/T/output. No arithmetic over unselected receiver rows.

R146 has6 distinct time models,537 receiver-time rows and2070 source/time sample records. Its posterior w,e,Pi are printed32-digit decimal values; reconstruct e=sum nu_exact*w_saved32 and Pi=nu_exact*w/e to maintain exact saved-weight normalization, compare to saved e/Pi and report rounding differences. This does not re-evaluate the kernels or coordinate thresholds. Main results are for the existing printed-time convention, and old high-precision segment-endpoint FA flags remain attached separately.

## Identities and margins

For all six sources at every selected receiver-time, define
muQ_i=Q_i nu_i/q (a subprobability, not forcibly normalised),
r_t,i=K Q_i/(p w_t,i), L=Kq/(p e_t).
Verify Pi_i=L muQ_i/r_t,i and sum Pi=1. Record sum muQ and any excess above1 due to independent savedfloat Q/q summation; never clamp. Also retain terminal r_g,i=K Q_i/(p wg_i), Delta_i=log(w_t,i/wg_i), and log(r_t)=log(r_g)−Delta identity. Q remains original(K1+K2+J)/3; no J substitution. Original receiver gates/good/bad/rho are immutable saved labels.

## Main threshold amendment (parent request before execution)

The candidate time-route threshold is r_t/rho>=N, not primarily a quadratic threshold. Test N=n,n+1,2(n+1) as predeclared main menu, with strict handling rho=0: zero traffic and ratio null, never divide0. Interpret threshold-covered weight as a candidate-covered branch, not numerically certified payment or whole-time coverage. Parent's analytic candidate integral bound remains pending audit; no time integral is computed here.

Keep original supplementary diagnostics r_t>=A, r_t/rho>=A for A=(n+1)^2 and (16/3)(n+1)^2. Preserve both scaled thresholds explicitly, exact rational16/3, with pending-paid-constant label. For the main N menu also report r_t>=N and terminal r_g/rho>=N to quantify how terminal margin changes under wt/wg.

## Finite descriptive contributions and stage handling

Attach per source/time r_t,r_g,Delta,r_t/rho, terminal ratio to all2070 original records; preserve actual scoreweight delta Pi_vPi_u and rho_scoreweight already computed in R146. Compare threshold coverage on same finite samples under five masks: all, original FA_closed, original FA_strict_interior, printed-time saved-cap closed, printed-time saved-cap strict interior. These masks additionally require saved good(v),bad(u),Psi and rho_v>0; the original179 necessary receiver gates are checked. Retain raw pair/samples counts and pointwise rho_scoreweight sums, with covered/residual fractions. No dx or dt/time-length weights, no inference from sample endpoint occupancy to positive time measure. Original pressure remains separate from iid flows.

By original initial/pressure/expanded and case, source and time label, report margin quantiles and covered/residual contributions. Main numerical question: P1 wide terminal good margin may or may not remain when w_t replaces wg; show both on the same points, without fitting exponent or claiming whole-window minima.

## Arithmetic/output

Decimal80 computation, Decimal120 recheck on distinct receiver/time/source margins and identities; report maximum residual/rounding differences and threshold boundary nearness. Save compact shared source-margin tables (537 rows×6 sources) and2070 indexed annotations rather than repeated whole kernels. Single script reconstructs all output from boundSHA inputs; runtimeUTC/elapsed excepted. Final report distinguishes identities, old receiver-label accuracy, finite threshold coverage and pending continuous-time/payment theorem. Complete and stop.

## 第二次运行前追加：共享m/Mrho新策略

第一版已经按原菜单运行；主代理提出共享质量增强后预先追加协议，第二次运行不新增接收点/time/核。固定同一receiver的Gplus={terminal good且rho>0的全部六源成员}，m=sum_Gplus muQ，Mrho=sum_Gplus rho muQ。CORE若rho=0排除；若rho>0即使此时score=0仍保留，禁止免费按当前delta删来源。muQ始终Qnu/q，不用muQ总质量或m重新归一。

新增主要Nstar=2n+3（I1为11，P1为35）三分支比较：原r_t>=Nstar rho_v；共享m分支r_t>=Nstar m rho_v；共享Mrho分支r_t>=Nstar Mrho。仅rho_v>0有交通，rho=0字段null。保存m、Mrho及Gplus，每receiver核三个原时间完全一致，不将时间点各自重新选择共同质量。保留第一版n,n+1,2(n+1)及附加quadratic表以供完整比较。

按同一原三阶段、source/time与五类FA mask统计新增分支covered/residual样本数及rho_scoreweight点权比例。主代理提出的1/(2N)或48Lambda sqrt(n)支付结论仍待独审，数值只检验分支覆盖，不凭有限点宣布全时间或全局付款。记录producer执行次数2，首版由新增预声明分支的第二版替代。

## 第三次运行前最终确定性加强：原high门slack

主代理明确最后一项，不再新增菜单。用R136 wg与R142 exact nu计算eg=sum nu wg，Lg=Kq/(p eg)。原high必要门给Lg<=1/2；计算并报告未截零的数值余量，核L_t<=Lg。仅在Nstar=2n+3共享m分支上新增slack r_t>=2Lg Nstar m rho_v，与原base r_t>=Nstar m rho_v及原Nstar rho_v同表比较；不加入Lh或其它参数。主代理提出同1/(2N)时间帽仍待数学审核，本诊断不作积分。

核代数消去2Lg m=2K sum_Gplus Q_i nu_i/(p eg)，保留Gplus全terminalgood rho>0集合；Lg和m都依receiver但不依time。优先报告I1与pressure原FA闭点/内部点的新增候选覆盖；保存所有旧阈值结果不混拼。实际执行producer第三次，前两版由本预声明最终策略版替代。没有新核、抽样、time点或积分。

## 最终精度一致性修订（不新增策略）

第三版检查后发现margin函数为80位，但summary中的Decimal点权累加仍使用Python默认28位。为与本协议80位口径一致，将默认Decimal context固定80位，再执行一次相同最终策略脚本（producer第四次，仅精度修订、无新菜单）。此前约1e−16的far残余本已在28位可分辨，最终仍保留其正值，不以float covered≈1替换为零。最终高精度margin和点权汇总均可由一次脚本执行复现。
