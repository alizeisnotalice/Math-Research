#!/usr/bin/env python3
"""Exact product-weight time-gate certificates; finite deterministic menu only."""
from fractions import Fraction as F
from pathlib import Path
from functools import reduce
from operator import mul
import json,hashlib,datetime,time
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def prod(xs):return reduce(mul,xs,F(1))
def w(a,t):return prod(min(F(1),x/t) for x in a)
def enc(x):
 if isinstance(x,F):return dict(numerator=str(x.numerator),denominator=str(x.denominator),decimal=format(float(x),'.16g'))
 if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [enc(v) for v in x]
 return x

def piece(a,lo,hi,rho,C,N):
 assert 0<lo<hi and C>0 and N>0 and 0<=rho<=1
 k=sum(x*x<lo*hi for x in a);co=prod(x for x in a if x*x<lo*hi);wl,wh=w(a,lo),w(a,hi);assert wl==co/lo**k and wh==co/hi**k and wl>=wh>0
 rrlo,rrhi=C/wl,C/wh;assert rrlo<=rrhi
 rec=dict(lo=lo,hi=hi,k=k,c=co,w_lo=wl,w_hi=wh,r_lo=rrlo,r_hi=rrhi)
 if not rho:return dict(**rec,gate='rho_zero_traffic',gate_holds_at_lo=True,gate_holds_at_hi=True,J=F(0),root=None)
 cap=C/(N*rho);J=rho/C*max(min(wl,cap)-wh,F(0));root=None
 if not k:gate='constant_equality' if cap==wl else ('constant_full_gate' if cap>wl else 'constant_empty_gate')
 elif cap>=wl:gate='full'
 elif cap<=wh:gate='endpoint_only_hi' if cap==wh else 'empty'
 else:gate='partial';root=dict(degree=k,t_power_equals=co/cap,isolating_interval=[lo,hi]);assert lo**k<co/cap<hi**k
 assert 0<=J<=F(1,N)
 return dict(**rec,cap_w=cap,gate=gate,gate_holds_at_lo=wl<=cap,gate_holds_at_hi=wh<=cap,J=J,root=root)
def time_case(a,tau,h,rho,C,N,cid,stage):
 assert all(x>0 for x in a);breaks=sorted(set([tau,h]+[x for x in a if tau<x<h]));ss=[piece(a,lo,hi,rho,C,N) for lo,hi in zip(breaks,breaks[1:])];J=sum((s['J'] for s in ss),F(0));rt,rh=C/w(a,tau),C/w(a,h);endpoint=max(min(rho/rt,F(1,N))-rho/rh,F(0)) if rho else F(0);assert J==endpoint and J<=F(1,N)
 return dict(id=cid,stage=stage,n=len(a),thresholds=a,tau=tau,h=h,rho=rho,C=C,N=N,breakpoints=breaks,r_tau=rt,r_h=rh,J_piece_sum=J,J_endpoint_formula=endpoint,identity_exact=True,upper_1_over_N=F(1,N),gate_equality_breakpoints=[t for t in breaks if C==N*rho*w(a,t)] if rho else [],segments=ss)
def time_menu():
 menu=[];tau=F(1,4);h=F(2)
 def add(stage,n,a,rho,mode,end=h):
  wl,wh=w(a,tau),w(a,end)
  cap={'start':wl,'end':wh,'mid':(wl+wh)/2,'twice_start':2*wl,'half_end':wh/2,'break_half':w(a,F(1,2))}.get(mode)
  C=(n+1)*rho*cap if rho else F(1);menu.append(time_case(a,tau,end,rho,C,n+1,len(menu)+1,stage))
 for mode in ['start','end','mid']:add('initial',1,[F(1,2)],F(1,2),mode)
 add('initial',2,[F(2),F(3)],F(1,2),'start',F(1));add('initial',2,[F(1,2),F(3,4)],F(0),'start');add('initial',2,[F(1,2),F(3,4)],F(1,2),'twice_start')
 add('pressure',2,[F(1,2)]*2,F(1,2),'mid');add('pressure',4,[F(1,4),F(1,2),F(1),F(2)],F(1,2),'break_half');add('pressure',4,[F(1,2)]*4,F(1,2),'half_end');add('pressure',4,[F(3)]*4,F(1,2),'twice_start')
 for rho in [F(1),F(1,1000000)]:add('pressure',4,[F(1,4),F(1,2),F(1),F(2)],rho,'mid')
 for n in [8,16,32]:
  a=[[F(1,8),F(1,2),F(3,4),F(3,2),F(3)][i%5] for i in range(n)]
  for mode in ['start','mid','end']:add('expanded',n,a,F(2,3),mode)
 assert len(menu)==21
 return menu

def source_case(n,near,index):
 tau,h=F(1,4),F(2);N=n+1;K=F(1)
 if near:
  aa=[[F(1,4)]*n,[F(3)]*n];nu=[F(99,200*N+99),1-F(99,200*N+99)];eh=sum(nu[i]*w(aa[i],h) for i in range(2));Q=[2*N*nu[1]/(eh-2*N*nu[0]),F(1)];rho=[F(1),F(0)];q=sum(x*y for x,y in zip(nu,Q));p=2*q/eh;label='near_saturation'
 else:
  aa=[[F(1,4)]*n,[[F(1,2),F(3,2)][i%2] for i in range(n)],[[F(1,2),F(1),F(3)][i%3] for i in range(n)],[F(3)]*n];nu=[F(1,7),F(2,7),F(3,7),F(1,7)];Q=list(map(F,[1,2,3,5]));rho=[F(0),F(1,4),F(2,3),F(1)];eh=sum(x*w(a,h) for x,a in zip(nu,aa));q=sum(x*y for x,y in zip(nu,Q))*(1 if index%2 else F(5,4));lam=2 if index%2 else 3;p=lam*q/eh;label='four_source'
 assert sum(nu)==1 and all(z>0 for z in Q);mu=[x*y/q for x,y in zip(nu,Q)];assert sum(mu)<=1;C=[K*z/p for z in Q];breaks=sorted(set([tau,h]+[x for a in aa for x in a if tau<x<h]));lower=upper=F(0);sumJ=[F(0)]*len(aa);segments=[]
 for lo,hi in zip(breaks,breaks[1:]):
  elo=sum(x*w(a,lo) for x,a in zip(nu,aa));ehi=sum(x*w(a,hi) for x,a in zip(nu,aa));Llo,Lhi=K*q/(p*elo),K*q/(p*ehi);assert 0<Llo<=Lhi<=F(1,2)
  pieces=[piece(a,lo,hi,r,cc,N) for a,r,cc in zip(aa,rho,C)];js=[r['J'] for r in pieces];g=sum(x*y for x,y in zip(mu,js));lower+=Llo*g;upper+=Lhi*g
  for i,z in enumerate(js):sumJ[i]+=z
  for t,e,L in [(lo,elo,Llo),(hi,ehi,Lhi)]:assert sum(L*mu[i]/(C[i]/w(aa[i],t)) for i in range(len(aa)))==1
  segments.append(dict(lo=lo,hi=hi,L_lo=Llo,L_hi=Lhi,mu_weighted_gate_piece=g,source_pieces=pieces))
 rows=[time_case(a,tau,h,r,cc,N,i,'source_budget') for i,(a,r,cc) in enumerate(zip(aa,rho,C))];assert sumJ==[z['J_piece_sum'] for z in rows];weighted=sum(x*y for x,y in zip(mu,sumJ));cap=weighted/2;masscap=sum(mu)/(2*N);target=F(1,2*N);assert 0<=lower<=upper<=cap<=masscap<=target
 if near:assert rows[0]['r_tau']==N
 return dict(n=n,kind=label,N=N,tau=tau,h=h,nu=nu,Q=Q,q=q,K=K,p=p,rho=rho,C=C,muQ=mu,muQ_total=sum(mu),e_h=eh,L_h=K*q/(p*eh),source_time_records=rows,common_segments=segments,mu_weighted_J=weighted,source_cap=cap,source_mass_cap=masscap,target_1_over_2N=target,actual_L_weighted_integral_lower=lower,actual_L_weighted_integral_upper=upper,actual_integral_computed_exactly=False,source_cap_over_target=cap/target,actual_lower_over_target=lower/target,actual_upper_over_target=upper/target,source_budget_exact=True)
def main():
 start=time.monotonic();tm=time_menu();sm=[source_case(n,False,i) for i,n in enumerate([1,2,4,8,16,32],1)]+[source_case(n,True,0) for n in [4,16]];gates={s['gate'] for r in tm for s in r['segments']};out=dict(status='completed_exact',scope='Finite product-weight full-window gate identities and finite common-source high budget only; no FULL or time-varying-rho claim',script_sha256=sha(Path(__file__)),plan_sha256=sha(ROOT/'time_gate_check_plan.md'),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),time_cases=tm,source_budget_cases=sm,summary=dict(time_case_count=len(tm),source_budget_count=len(sm),dimensions=sorted({r['n'] for r in tm+sm}),time_identity_failures=0,source_cap_failures=0,gate_types=sorted(gates),algebraic_partial_root_count=sum(s['root'] is not None for r in tm for s in r['segments']),all_arithmetic='Fraction, no root approximation, no quadrature',FULL=False),elapsed_seconds=time.monotonic()-start);(ROOT/'time_gate_check.json').write_text(json.dumps(enc(out),ensure_ascii=False,indent=2)+'\n')
 for r in tm:print('time',r['id'],'n',r['n'],'J',r['J_piece_sum'],'gates',[s['gate'] for s in r['segments']],flush=True)
 for r in sm:print('source',r['kind'],'n',r['n'],'cap/target',float(r['source_cap_over_target']),'actual bracket/target',float(r['actual_lower_over_target']),float(r['actual_upper_over_target']),flush=True)
 print('SUMMARY',out['summary'],flush=True)
if __name__=='__main__':main()
