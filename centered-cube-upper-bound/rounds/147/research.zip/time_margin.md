# R147：原有效 good 边际的全时间阈值付款

状态：证明一个保留原 ρ 的真实正子支付款。令 r_t(v)=KQ_x^*(v)/(p_xw_t(v))。对任意 N>0，原未付正项中 r_t(v)≥Nρ_v 的完整时间／来源价格至多1/(2N)；取 N=2n+3，付清外 hard 来源与原自适应接收尺度后，signed 价格≤48Λ√nW_β。余部 r_t<Nρ_v 原样保留，不声称一般问题闭合。没有加入人工面积权，没有使用 signed cuts 或返还负预算。

## TM1. 精确对象、旧接口与先行命题

固定原实际行 (ω,V,j,x,y,z,history)，保留任意相关 ν、原 β 和接收选择器。沿 R128 RT1–6：

\[
Q_x^*=(P_{s,L}+P_{s,L^+}+J_b)/3,\quad p_x=P_{s,L}(x-y),
\quad g=\sqrt{LR},\quad \tau=a/c_j,\quad h=g e^{-u_0/n}<g.
\]

本行的 p_x,Q_x^*,q,g,τ,h,T、共同 α 及原

\[
\rho_v=\left[1-\frac{DK_0(x-v)+\alpha(x)J_b(x-v)}{T A_v}\right]_+,
\qquad A_v=w_\tau(v)-w_h(v),
\tag{TM1}
\]

在内部时间积分中固定。A_v=0 或原捕获约定零行按原定义取ρ=0。ρ 的时间固定性也由 R135 area_flux.md 最后部分明确确认；本文不重用其中人工 e^{-aΔ} 权的付款。Q、p 对 x 的实际依赖没有冻结成全空间共同参数。

原 high 门 p_xe_g≥2Kq，来源存活集 Z_t 随 t 非增，w_t 非增，因此 t≤h<g 时 e_t≥e_g。原 FIRST 给 ∫Q_x^*dν≤q。定义同一实际行的次概率来源测度

\[
d\mu_Q(v)=\frac{Q_x^*(v)}q\,d\nu(v),\qquad \mu_Q(\mathbb R^n)\le1,
\]
\[
r_t(v)=\frac{KQ_x^*(v)}{p_xw_t(v)}=e^{a_t(v)},\qquad
F_t=\frac{Kq}{p_xe_t}\le\frac12.
\tag{TM2}
\]

原 high 排除本行 p_x=0、q=0、e_g=0 的有商情形；其余零交通行先作零处理。**准确换测度**是

\[
d\Pi_t(v)=1_{Z_t}(v)\,F_t\,r_t(v)^{-1}d\mu_Q(v).
\tag{TM3}
\]

这不是把 e_t 当成常数：TM3 保留实际 e_t，随后仅用原 high 与单调性已经给出的统一有价上界 F_t≤1/2。既未假设 e_t 的绝对下界，也未将 ν 总质量当成1。

令 Ω_rem 为所有旧已付正支剔除后的原合法未付域。特别保留原 terminal v∈S_g、u∈D_0、原 Ψ、ρ、FA、完整远窗及原 history；若此轮只研究 R144 低核比余部，则再保留原 c_x(v,u)<η_n。定义新正子支

\[
\boxed{\Omega_N=\Omega_{rem}\cap\{\rho_v>0,\ r_t(v)\ge N\rho_v\}.}
\tag{TM4}
\]

ρ=0 不产生交通，可按任意边界归类。N 是事先选定的共同数，不依正在积分的来源或 x 重选。先行命题为：固定行后，该子支在原两份 Π_t 与完整 J_far 时间积分下，去掉外 p_xh_Ra_ω/q 的内部价格≤1/(2N)。下面给出精确端点及全局价。

## TM2. 初探、压力与全时间恒等式

原坐标阈值权给几乎处处

\[
\frac{d\log r_t(v)}{d\log t}=k_t(v),\qquad
-\frac{d}{d\log t}\frac{\rho_v}{r_t(v)}
=\rho_vk_t(v)r_t(v)^{-1}.
\tag{TM5}
\]

w_t 连续、分段幂函数，故 r_t 连续非减；坐标阈值不产生原子跳跃。记 b_t=ρ_v/r_t，原始定义中没有新增乘在交通上的权。对任意 N>0，链式法则给精确式

\[
\boxed{\int_\tau^h\rho_vk_t(v)r_t(v)^{-1}
1_{\{r_t(v)\ge N\rho_v\}}\frac{dt}{t}
=\min\!\left\{\frac{\rho_v}{r_\tau(v)},\frac1N\right\}
-\min\!\left\{\frac{\rho_v}{r_h(v)},\frac1N\right\}
\le\frac1N.}
\tag{TM6}
\]

记该非负端点差为 E_N(v)。它比只保留1/N更强，包含末端尚余质量的扣减；此扣减属于同一正通量恒等式，不是原 N_Z 或 N_del。

**初探。** 若 h=τ，端点差为0；若 k_t=0，b_t 不变且该段没有通量；若 r_h<Nρ，全窗该子支为空；若 r_τ≥Nρ，则全窗以真实端点差计价。等号 r_t=Nρ 在平段上 k_t=0，不影响 dt/t 积分。

**压力。** 若不加 TM4 的真实正支限制，完整积分是 ρ_v(r_τ^{-1}−r_h^{-1})，初始 r_τ 可很小，不能凭 terminal good 的 r_g≥1 控制它。a_t=a_g−Δ_{t,g}，所以 a_g 大也不保证整窗 a_t 大。TM6 付的是每一来源真正进入 r_t≥Nρ 后的尾时间段，不是把最终 margin 倒灌到早期时间。

**扩大范围。** Z_t 可以按原历史删除来源，e_t 可变化或跳降；证明没有微分 Z_t、e_t 或归一化 Π_t。S_g⊂Z_g⊂Z_t 于 t≤g，可保留该实际资格，也可在正上界中删去多余指示。所有 x 依赖参数只要求在固定实际行的内部时间积分中不重选，这正是原 RT2–6 的合同。本稿未运行数值检验，不从有限记录推断覆盖量。

## TM3. 两份来源归一化与原负门保留

将原 Ψ、χ_FA、低核比与旧已付补集等正指示记为 χ_orig∈[0,1]，均按原值取。固定行的子支内部量为

\[
\begin{aligned}
I_N(r)=\int_{J_{far}}\frac{dt}{t}\int_{S_g}d\Pi_t(v)
\int_{D_0}d\Pi_t(u)\,
\rho_v\delta_t(v,u)\chi_{orig}
1_{\{r_t(v)\ge N\rho_v\}},
\end{aligned}
\tag{TM7}
\]

其中 δ_t=[k_t(v)−k_t(u)]_+≤k_t(v)。先只对正上界使用 χ_orig≤1、Π_t(D_0)≤1，再用 TM3，得到

\[
I_N(r)\le\int_{J_{far}}\frac{dt}{t}
F_t\int_{S_g}1_{Z_t}(v)\rho_vk_t(v)r_t(v)^{-1}
1_{\{r_t(v)\ge N\rho_v\}}d\mu_Q(v).
\]

以 F_t≤1/2、J_far⊂[τ,h]、非负 Tonelli 和 TM6，严格有

\[
\boxed{I_N(r)\le\frac12\int_{S_g}E_N(v)d\mu_Q(v)
\le\frac{\mu_Q(S_g)}{2N}\le\frac1{2N}.}
\tag{TM8}
\]

这里已真实处理两份 e_t 分母：一份在内 bad posterior 的概率质量中，一份在 TM3 的 F_t 中。没有借来源坐标独立性；μ_Q 是原共同 ν 的核加权次概率，而非新选的输入。共同 α 只保留在原固定 ρ 中，没有把其 reserve 再消费一次。

TM8 只放松正项。原 Ψ 内负项继续不附 FA 或ρ，futurebad、N_del 及 β−ν 各保留原账一次。时间阈值不是从负项删边，也没有 signed cut 的边界预算。

## TM4. 原 FA 与已付正支的准确交叠

R128 RT2 的原 χ_FA 是 ℓ_t(v)<B_FAδ_t，且 r_t=Kℓ_t。故新支在真实剩余域上的准确必要条件为

\[
\boxed{N\rho_v\le r_t(v)<KB_{FA}\delta_t(v,u).}
\tag{TM9}
\]

它与此前已经删除的 FA 高支 r_t≥KB_FAδ 不交，不能把后者重复算作本轮新覆盖。若 Nρ_v≥KB_FAδ，该 pair/time 没有新交通；若反向严格成立，则区间在代数上非空，但仍需原 good/bad、low、Ψ、history 等资格，不能据此声称已有 FULL 实例。

这是保留ρ阈值的意义：ρ 小时，实际 r_t 较小也能进入该子支；没有要求统一 α 下界。与忽略ρ的 r_t≥N 子支相比，TM4 覆盖更大，因为0≤ρ≤1。所有旧已付正集合须先从 Ω_rem 中删除，TM8 对这个交集仍然成立。

如果只作逐点粗界，同一 TM4 给内部量≤n/(2N)，继而用 JT14 的逐时间帽支付。本文先利用实际 k_t 和完整时间单调性把总量压到1/(2N)，消去该方法中的额外 n 乘法。它不是省略时间长度或把一段时间改成固定 t；TM6 已积分整个 [τ,h]。

## TM5. hard 来源、自适应接收与唯一 j 的最终价格

返回原 RT1 外层，准确先保留

\[
P_N=\mathbb E\sum_{V,j}\int d\beta_V(y)\int dx\,
1_{\{j(x)=j\}}1_{A_{hi}}p_x
\int\frac{h_{R(x)}(x-z)a_ω(x,y,z)}{q(x)}I_N(r)d\nu_V(z).
\tag{TM10}
\]

TM8 对每个实际 z/history 行均有同一数值帽。此时才使用原 hard 帽

\[
\frac1q\int h_R(x-z)a_ω(x,y,z)d\nu_V(z)\le\frac{16}3.
\]

于是完整来源与时间后的实际行系数≤8/(3N)。源与时间已经消尽，方可合并原唯一 j，并使用 R140 JT13 的真实自适应接收包络

\[
\int\sup_{s\in[0,1],L\in[a,b]}P_{s,L}(x-y)dx
\le3(2n+3)D_n,\qquad D_n\le3\sqrt n.
\]

没有免费冻结 s,L,R,H，没有再乘 j 数，也没有把 β 改成 dy 或 ν。由 W_β=EΣ_V‖β_V‖，得到

\[
\boxed{2ΛP_N\le
16Λ\frac{(2n+3)D_n}{N}W_β.}
\tag{TM11}
\]

此式没有 log2：实际时间已经在 TM6–8 完整积分，不能再套一次 JT14 的时间长度，也不能再次领取时间端点费用。原 c_j=γ^{-j}≤1、τ_j≥a、h≤bc_j≤b 全保留在前面的实际时间行中；不存在 κ_j 的新增无价幂。

取共同 N=2n+3，得到明确的根阶正子支付款

\[
\boxed{2ΛP_{2n+3}\le16ΛD_nW_β\le48Λ\sqrt nW_β,
\qquad Λ=128/119.}
\tag{TM12}
\]

作为比较，若仅用逐点 n/(2N) 再套 JT14，价格是

\[
16Λ\frac{n\log2\,(2n+3)D_n}{N}W_β.
\]

该粗法要 N 为 n² 量级才到根阶；TM11 允许 N 为 n 量级。因此它确实扩大可付有效 margin 区域，而不只是给原来同一阈值换一个名字。

## TM6. 精确余部与停止点

在所有旧已付正项之外，原正交通分为 TM4 与其补集；故原低核比余部（若作为本轮起点）满足

\[
\boxed{2ΛP_{low}^{rem}\le48Λ\sqrt nW_β
+2ΛP_{low}^{rem}\bigl[\rho_v>0,\ r_t(v)<(2n+3)\rho_v\bigr].}
\tag{TM13}
\]

右端剩余仍含原 FA、Ψ、bad/good、原 low c 门、两 e 分母、实际 q、外 hard ν、β、全部时间与层级。TM13 不声称右端剩余为空、小于新支或已付；a_g 或全 Q 宽比值本身均不能替代其实际时间条件。

可检覆盖字段仅需实际 r_t、ρ、δ、KB_FA 及原资格。若在一个 score 常值段 [t₀,t₁] 内 k_t(v)=k>0，则 r_t=r_{t₀}(t/t₀)^k，阈值进入点为 t₀(Nρ/r_{t₀})^{1/k} 截入该段；还须交上原 r_t<KB_FAδ 与 FA/Ψ 时间域。k=0 段不产生 TM6 的通量。不用等点命中率冒作 dt/t 覆盖。

本轮已证的是 TM11–12 的原正子支付款，历史依赖仅为原 high/FIRST、实际时间权导数、原 hard 帽与已证接收包络。一般根阶目标仍由 TM13 的补集阻挡。完成停止，仅写本文件。
