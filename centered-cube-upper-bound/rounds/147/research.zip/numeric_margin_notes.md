# R147 numeric_margin：时间余量与共同质量slack

已实际执行最终脚本，exit0，约1.18秒。输入为同work父代理复制的R146 frozen posterior/time JSON，以及R142选定179receiver和同一exact nu、R136原Q相关参数/wg。沿用2070个点、537 receiver-time、6时间模型；没有新核、接收点、时间点或积分。主策略在各次执行前追加协议，最终停止加菜单。

最终变化明确：原terminal宽good余量不必保留到r_t，但共享质量再保留原high门slack 2Lg后，本菜单原FA内部的I1和P1压力主贡献均进入候选分支；P1随机点的剩余仅为原far B来源的微小正交通。I1早端仍有实际剩余，点上覆盖绝非全时间付款。理论1/(2N)时间帽和48Lambda sqrt(n)费用由数学作者/审计判断，本数值不登记已付。

## 1. 同一Q、nu下的恒等式

muQ_i=Q_i nu_i/q，r_t,i=KQ_i/(p w_t,i)，L_t=Kq/(p e_t)，因此Pi_i=L_t muQ_i/r_t,i。muQ是原Qnu/q子概率，不按其总质量或m重新归一。全部537行的muQ总质量最大.87431216，无超1；Pi归一残差<=2e−80，逐source恒等式残差<=1.2e−79。

R146的w,e,Pi输出为32位decimal。本轮不重新算阈值或核，而用原exact nu和保存w重建e及Pi；与旧Pi最大绝对差1.12956e−32，与旧e最大相对差6.91245e−32。原必要门、good/bad/rho、Psi、FA资格均未重选。Q仍是原(K1+K2+J)/3，保存算术相对误差<=2.64856e−16，未以J替代。

terminal r_g=KQ/(p wg)，Delta=log(w_t/wg)，满足log r_t=log r_g−Delta，最大残差1e−78；全部Delta非负。P1三个时间Delta约10.2475、6.5952、2.94293，因此wt替换wg可让时间余量比terminal小约2.8万、732、19倍。P1压力点terminal r_g约24.57—37.29，但r_t/ρ在全部三点仅.000872—1.96916，原N=n+1=17分支完全不覆盖；不能把终端宽margin直接当时间分支资格。

## 2. 原门与三个预声明层次

初版主阈值N=n,n+1,2(n+1)均按r_t>=Nρ计算（另列r_t>=N与terminal r_g>=Nρ），rho=0零交通不除零。原FA内部点上，N=n+1的P1 initial/expanded覆盖rho score点权约92.8571%/92.9369%，压力0；I1全部不覆盖。附带quadratic (n+1)^2及16/3倍，仅作pendingconstant诊断，不将其费用称已付。

第二层固定Nstar=2n+3（I1为11，P1为35），Gplus为全部terminalgood且rho>0来源。m=sum_Gplus muQ，Mrho=sum_Gplus rho muQ，比较r_t>=Nstar ρ、r_t>=Nstar mρ及r_t>=Nstar Mrho。CORE只有rho=0时排除；rho>0即使score=0也保留，未免费按当前positive-delta删源。I1 m范围.08137—.12019，P1 .047996—.384447；三原时间的m/Mrho完全相同。

最终只加原high门的确定性slack：eg=sum nu wg，Lg=Kq/(p eg)<=1/2，并核L_t<=Lg。新增r_t>=2Lg Nstar mρ，与上面三条完整分支逐一比较；不使用Lh、不逐点挑参数。Lg最大.49141934，两个不等式均无正超额。2Lg m=2K sum_Gplus Qnu/(p eg)的q消去残差<=2e−80。

I1 Lg约.09223—.09582，2Lg m约.01501—.02303；P1 Lg约1.17e−6—.49142。P1压力点尤其有很小Lg，因而这项真实high门余量改变了此前0覆盖的结论。

## 3. 原FA内部：同一有限菜单的点权覆盖

以下全保留原necessary receiver门、good(v)bad(u)、rho_v>0、原Psi和R144原FA strict interior。权仅为已有rho_v delta Pi_vPi_u的有限点值，没有dt、dx或采样流归一化。表中都是候选分支覆盖，不能直接叫预算付款。

| case/阶段 | 原FA内部点 | 原Nstarρ覆盖 | 共享Nstar mρ覆盖 | 共享Nstar Mrho覆盖 | 最终2Lg Nstar mρ覆盖 |
|---|---:|---:|---:|---:|---:|
| I1 initial | 6 | 0% | 0% | 0% | 100% |
| I1 expanded | 27 | 0% | 0% | 0% | 100% |
| P1 initial | 68 | 92.8571% | 92.8571% | 92.8571% | 1−1.3736e−16 |
| P1 pressure | 15 | 0% | 0% | 0% | 100% |
| P1 expanded | 399 | 92.9368% | 95.2902% | 96.4673% | 1−1.2161e−16 |

最终样本个数覆盖：P1 initial44/68、pressure15/15、expanded270/399；I1全部33/33。P1残余恰是far B→G4的24+129=153个原FA内部点，G1/G2/G3全部进入最终候选分支。float覆盖率显示约1时，JSON仍单独保存上述严格正的residual_point_weight_fraction，未置零。

具体未覆盖正点示例：P1 expanded receiver526、source B→G4、原几何中点，r_t=.0094418674、rho=.9999999883、Lg=.0230363530、m=.2548152892、Nstar=35，而2Lg Nstar mρ约.411；rho score点权2.45355e−23。该余部很小但不是空集，不可免费删源或从有限数值推出全局可忽略。

## 4. 端点提醒：mid覆盖不是全时间覆盖

原R144 FA_closed和本轮printed-time saved-cap closed仍分开，保留R146已有端点舍入语义；strict interior一致。最终slack的原FAclosed点权覆盖如下：

| case/阶段 | 原FAclosed点 | 最终slack覆盖点权 | 剩余 |
|---|---:|---:|---:|
| I1 initial | 12 | 49.37197% | 50.62803% |
| I1 expanded | 54 | 49.37197% | 50.62803% |
| P1 initial | 167 | 1−8.1942e−17 | far来源正余部 |
| P1 pressure | 30 | 100% | 0个保存点 |
| P1 expanded | 942 | 1−7.9134e−17 | far来源正余部 |

I1内部三来源在几何中点均满足最终分支，但lo点仍全部在剩余支。printed-time closed包含hi舍入端点时I1覆盖约64.7326%，与原closed不相同。两种点权比例都不是dt积分，不能用中点全覆盖代替原时间窗的剩余审计。另agent负责连续时间/精确补集工作，本文件没有求连续最小值或重求积分。

## 5. 误差、数据接口与执行账

计算margins用Decimal80，并对537×6来源的基础Pi,muQ,r_t,r_g,Delta以120位核对，最大相对变化8.13e−80。全部rho=0来源保留null比值与零交通，原附加阈值菜单无相对距离<1e−10的source；这不是真实核区间证书，也不代表新增共享阈值获区间证明。最终点权累加也固定Decimal80，float仅用于描述分位和最终比例显示。

receiver_time_margins按receiver_time_id保存L、muQ_mass、Gplus、shared_m、shared_Mrho、Lg、Nstar；sources[v]保存Pi、muQ、r_t/r_g/rho/Delta，以及shared_mass_branches.slack_2Lg_shared_m_r_t_ge_2Nstar_Lg_m_rho。精确有限模型补集用同字段比较r_t<2*Nstar*Lg*shared_m*rho。sample_references按原2070顺序保留来源、原/打印FA、score点权；delta若需可从输入r146_numeric_score.json同序samples.actual_delta读取，不再重复核算。旧original_FA_interior_residual_Nplus1_examples只针对初版N=n+1，不是最终slack补集，勿混用。

运行账共四次：初版原阈值；运行前追加共同m/Mrho；运行前追加最后Lg slack；最后仅将summary Decimal默认28位修为80位作精度一致性重跑。最后一次没有新策略/菜单/核/样本，前三版由最终版本替代；far约1e−16正余部在28位本已可分辨，最终仍保留。最终脚本全部计算与汇总在一次执行中完成，输入/计划/脚本SHA写入JSON，可由绑定输入复现；UTC/耗时除外。

数值支持的是最后确定性high slack确实覆盖了此前压力/I1内部未覆的原正贡献，而不是一般问题已闭合。连续时间补集、剩余来源、所有history/层级和真实接收平均仍须相应数学付款。四文件完成冻结，停止。
